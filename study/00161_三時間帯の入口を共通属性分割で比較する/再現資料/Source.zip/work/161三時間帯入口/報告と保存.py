"""161の固定結果をMarkdownと再現可能な小型保存物へ整理する。"""
from pathlib import Path
from datetime import datetime,timezone
import gzip
import hashlib
import json
import shutil
import sys
import zipfile
import importlib.metadata

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from 学習する import ROOT,TRIAL,BOOK_SHA,sha,save


def md_table(headers: list, rows: list) -> str:
    """
    機能: 明示した列順でMarkdown表を作る。
    引数: headers(list[str])、rows(list[list[str]])は見出しと行。
    返り値: strは空行付きの表。
    """
    return '\n| '+' | '.join(headers)+' |\n| '+' | '.join('---' for _ in headers)+' |\n'+''.join('| '+' | '.join(map(str,r))+' |\n' for r in rows)+'\n'


def percentage(value: float|None) -> str:
    """
    機能: 未定義率を残して百分率表示にする。
    引数: value(float又はNone)は割合。
    返り値: strは表示文字列。
    """
    return f'{value:.2%}' if value is not None else '未定義'


# ----------------------------------------
def main() -> None:
    """
    機能: 正本・検査を束縛して結果文書、索引、Sourceと学習のZIPを作る。
    引数: なし。完了済み161の自然学習・取得・金融・独立検査を利用する。
    返り値: None。原板や共有cacheは複製しない。
    """
    assert sha(TRIAL/'条件.json')==BOOK_SHA
    book=json.loads((TRIAL/'条件.json').read_text(encoding='utf-8'))
    data=json.loads((TRIAL/'成果物/型付き四表.json').read_text(encoding='utf-8'))
    overall=[dict(zip(data['tables']['比較一覧']['headers'],r)) for r in data['tables']['比較一覧']['rows']]
    bands=[dict(zip(data['tables']['時間帯別']['headers'],r)) for r in data['tables']['時間帯別']['rows']]
    indexed={(r['政策'],r['期間']):r for r in overall}
    names={'COMMON':'共通条件','CONTEXT':'時間帯属性入り','SPLIT':'時間帯別学習'}
    checks={
        '学習の独立確認.json':'work/161独立確認/自然監査結果.json',
        '取得の独立確認.json':'work/161独立確認/取得自然監査結果.json',
        '金融の独立確認.json':'work/161独立確認/金融自然監査結果.json',
        '帯別学習と共通戻しの事後分解.json':'work/161独立確認/帯別学習と共通戻しの取得事後分解.json',
        '旧151学習の同体確認.json':'work/161過去探索の照合/自然学習の同体確認.json',
        '過去8政策の同体確認.json':'work/161過去探索の照合/取得政策の最終同体確認.json'}
    for name,source in checks.items():
        shutil.copyfile(ROOT/source,TRIAL/'検査'/name)
    diagnostic=ROOT/'work/161結果の診断'
    cause=(diagnostic/'原因と次の仮説.md').read_text(encoding='utf-8')
    cause+='\n\n正式保存時の参照：[条件](条件.json)、[主結果](README.md)、[診断根拠](成果物/診断根拠.json.gz)、[原因の追補](成果物/原因の追補.json.gz)。事後分解であり、161の採否・学習へ戻していない。\n'
    (TRIAL/'原因と次の仮説.md').write_text(cause,encoding='utf-8')
    for name in ('診断根拠.json','原因の追補.json','診断完了.json'):
        save(TRIAL/'成果物'/(name+'.gz'),json.loads((diagnostic/name).read_text(encoding='utf-8')))
    # ----------------------------------------
    rows=[]
    for mode in names:
        r=indexed[(mode+'_P65_A_F','全期')];late=indexed[(mode+'_P65_A_F','後25場')]
        rows.append([names[mode],r['取得'],percentage(r['到達済み先着率']),f"{r['利益総額']:,}",
            f"{r['損失総額']:,}",f"{r['既知差引']:+,}",f"{r['PF']:.3f}",r['金融未知'],f"{late['既知差引']:+,}"])
    report='# 00161 三時間帯の入口を共通・属性・分割で比較する\n\n2026-11-14。全73セッション・35,339判断q0・215モデルを実行した。**今回の条件では、三時間帯を属性へ加える案も、時間帯別に学習する案も、共通条件の入口精度を上回らなかった。新しい二案は採用しない。** [160の事後診断](../00160_入口を三時間帯で診断する/README.md)を採否へ組み込んだ新実験であり、160の数値の再分類ではない。\n\n'
    report+='## 主結果\n\n各方式へ同じ旧152A0複合回復補正を適用し、決済は旧strictH60/実BBOのIFD±125ptに揃えた。Nは純新規、Uは旧C1全保持、Fは当時の実取得が0の場だけ最初の旧C1信号を補完する固定参照政策。下表は事前固定した三つの`P65_A_F`で、全73場に最低1取得がある。金額は独立mini1枚、往復手数料77円と追加滑り控除1000円を差し引いた**既知分**。\n'
    report+=md_table(['方式','取得','到達済み先着率','利益円','損失円','既知差引円','PF','未知','後25場の既知差引円'],rows)
    report+='共通条件の全期黒字は後期まで安定していない。後25場の先着率は共通47.17%、属性入り48.33%、帯別48.80%。全期の金額や回数増加だけで採用を判断しない。\n\n純N単独の参加は共通23/73場・属性25/73場・帯別51/73場。Fの全場参加は旧信号補完の効果を含み、純新入口が全場で成立した結果とはしない。Fは未約定要求を取得に数えず、最初の旧信号時点の物理q1到達だけで決め、未来の新取得によって予約を取り消さない。各小時間帯への強制取得は課さない。\n\n'
    report+='## 三時間帯の差\n\n新しい採否・教師分割は判断q0の帯を使う。次表と時間帯別CSVは比較を揃えるため**実取得q1の帯**を表示する。NY09:30の境界は夏冬自動変換し、等号から米国後。\n'
    rows=[]
    for mode in names:
        for band in ('デイ','米国前','米国後'):
            r=next(r for r in bands if r['政策']==mode+'_P65_A_F' and r['期間']=='全期' and r['取得帯']==band)
            rows.append([names[mode],band,r['取得'],f"{r['順']}/{r['逆']}/{r['未到達']}/{r['観測不足']}",
                percentage(r['到達済み先着率']),f"{r['既知差引']:+,}",r['金融未知']])
    report+=md_table(['方式','取得帯','取得','順/逆/未/不足','到達済み率','既知差引円','金融未知'],rows)
    report+='帯別学習は米国前の全期先着を52.77%へ上げたが、その帯の既知差引は−701,372円。追加取得の集合が大きく変わっており、率の改善を同じ取引の改善や利益優位とは呼ばない。\n\n'
    report+='## 過去の探索で確認できたこと\n\n旧151のCOMMONは全35,339q0の買売確率・判断と、全65モデルの学習配列SHA・木構造SHAが完全一致した。旧151/152/153の主要8取得政策もcase・実側・stream・出生参照・時計まで一致した。再現確認と将来性能の検証は分ける。\n'
    rows=[]
    controls=[('COMMON_P65_U','旧151 P65＋C1'),('COMMON_P65_A_U','旧152 U0/A0＋C1'),('OLD152_U1','旧152 U1/B0＋C1'),('C1','旧C1'),('OLD153_U15','旧153 U15')]
    for policy,name in controls:
        r=indexed[(policy,'全期')]
        rows.append([name,r['取得'],percentage(r['到達済み先着率']),f"{r['利益総額']:,}",f"{r['損失総額']:,}",f"{r['既知差引']:+,}",r['金融未知']])
    report+=md_table(['固定対照','取得','到達済み率','利益円','損失円','既知差引円','未知'],rows)
    report+='旧152の複合回復補正には全期で改善があったが、COMMON新枝は旧152 A0そのものであり新しい時間帯効果ではない。153 U15の71.875%という当時の入口目標一旦達成は保持する。ただし93件中87件は旧C1、追加N15は6件・4順0逆1未1不足であり、少数の追加だけから高頻度への一般化を支持できない。今回70%を超えた全場参加の新政策はない。\n\n'
    report+='## 不調の原因と次の技術仮説\n\n10/23ナイト米国前の旧14逆行を同じq0から追跡した。共通は14買いを維持し14逆行。属性入りは5待機・9買いで9逆行。帯別は5待機・9売りで9順行、局所既知+108,307円となった。反転率を1−pで計算せず、反対側の実Ask/Bidで確認した。ただし帯別Nのそのナイト全体は155取得・32順56逆55未12不足・既知−656,242円。局所9勝を場全体の安定化とはしない。\n\n旧14件はMA・DIの向きが混在し、5分Hist/RSIが買いを支持しない一方、強反対背景Gが成立しないため短期回復Rを必須にせず買いを通していた。後25場のCOMMON新193件もすべてG外維持で46.11%。主な改善候補は、強い反対だけを検出する二分岐から、背景同方向・反対・混在を分け、混在時に構造回復・短期再加速・量を組み合わせる部分である。BB余地・ATR比・ヒゲで推進と終端を区別し、近接した同一構造を新しい独立エッジとして数え過ぎない仮説も残した。[原因と次の仮説](原因と次の仮説.md)。ここで新閾値を後付け採用していない。\n\n'
    report+='## 支持・探索自由度・限界\n\n共通/属性は65モデルずつ、帯別はデイ29・米国前28・米国後28の85モデル。過去20暦場・1000物理pair・8寄与場・3クラスを固定し、場開始時だけ学習した。帯不足7,122q0のうち3,799は当場COMMONへ、3,323は共通も未準備で待機した。時間属性は複数技術役割へ数えていない。\n\nSPLIT主Fの2908取得を分解すると、真の帯別モデル2747件は50.40%・既知−2,717,126円、COMMON戻し119件は71.11%・+366,145円、初C1補完42件は77.42%・+181,843円。したがって支持不足だけで不調を説明できず、共通戻しの4場の高率を帯別モデルへ帰属できない。[分解の正本](検査/帯別学習と共通戻しの事後分解.json)。純Nの帯別由来2749件との差2件はFの旧優先統合による。\n\n3方式×3閾値と、P65だけのA補正で12信号、N/U/Fの36政策、旧5対照の計41政策を事前固定した。各帯の最高条件を後から結合していない。それでも既知の160診断を踏まえた設計で、前48/後25とも既使用。未見11/10ナイト・11/11デイ、未実行の旧156は読まず保持した。近接入口は1時間の観測が重なり独立ではない。全場を除外せず、未取得・未到達・不足・金融未知を残した。未参加の仮想利益を機会損失として最適化していない。\n\n損益は独立入口1枚のIFD研究であり、片側10枚の数量制約付き口座収支ではない。旧strictH60の即時BBO決済代用で、157/160の場末短縮H60・D1と別契約である。今回トレーリングの優劣は変更していない。\n\n'
    report+='## 検査と再現\n\n別実装で教師集合255・215保存モデルの全再推論・106,017判断・A補正106,017・F876場判断・41政策81,332参照を確認した。金融は別パーサで元148観測全73場31,642case両実側63,284件を再読し、全CRC/解凍SHA・実Bid/Ask・先着・IFD費用を確認。四表93,415セルを独立集計で照合した。CSVは標準読取で全93,504セル（見出し89セルを含む）を再照合した。\n\n[条件JSON](条件.json) / [設定と結果・汎用表V8](設定と結果.md) / [CSV4表と読み方](閲覧資料.md) / [再現手順](再現手順.md)。条件SHA256 `'+BOOK_SHA+'`。全検査票と共有入力の指紋を保存し、Rawや4cacheの副本を増やしていない。初回集計の時間分母assertによる停止と、旧純B0の4物理aliasの由来属性訂正は[修正票](検査/修正と全取得同体の確認.json)へ記録。訂正で全取得集合・方向・先着・金額は変更していない。\n'
    (TRIAL/'README.md').write_text(report,encoding='utf-8')
    # ----------------------------------------
    reproduce='''# 161の再現手順

2026-11-14。既存固定試行を上書きせず、別checkoutへSourceを復元して実行する。正式成果物の閲覧は`work/`を必要としない。

## 入力と保存

共有正式148の100列定義、当時特徴、固定取得入力、取得対応、入口参照、正逆観測を参照する。物理/解凍SHAは[条件](条件.json)と学習・金融の入力確認へ記録した。新規に原板を走査せず、研究q0は35,339、正準研究q1教師は31,632、観測全caseは31,642である。C1出生は入口参照の`origins.birthQuote`を使い、観測のbirth=entryを出生へ流用しない。

- [再現Source.zip](再現資料/Source.zip)：`work/`以下の元相対位置を保持して復元する。旧151 data射影、過去教師選択、旧152純補正、逐次readerを含む。新Source/人工/独立監査/CSV作者を保存。
- [学習と採否.zip](再現資料/学習と採否.zip)：215数値モデル、全q0判断、場別教師監査、補正判断、41政策取得対応、完了票。生の特徴NPZ4cacheは複製しない。
- [入口とIFDの小型正本](成果物/入口とIFDの小型正本.json.gz)：使用した実側だけの金融原始値と政策所属。全母集団金融派生はSourceから旧148共有観測を再読すれば復元できる。
- [保存索引](再現資料/保存索引.json)：全保存物のサイズ・SHA、実行環境と入力参照。

## 学習と旧再現確認

Python3.14.3、NumPy2.5.4、CatBoost1.2.10、CPU1thread。時帯変換はzoneinfo+tzdata、独立金融監査はijson3.6.0。正確な版は保存索引へ記録する。元の自然実行はSHA固定した旧151の後発cache4本を使った。cacheは正式151後発生成物で、自然実行のF0より前から存在したことと、正式151初回F1より前に存在したことを混同しない。

cacheが無い別checkoutでは、Source.zipを元の相対位置へ展開し、学習と採否.zipから場別監査を取り出して次を実行できる。

```powershell
python -X utf8 work/161三時間帯入口/正式入力から学習を再現する.py work/161隔離再現 展開先/場別モデルと教師.json.gz
```

正式148の共有gzipから旧151のSHA固定Sourceで再射影し、同じ過去成熟選択・三方式を学習する。学習配列/木構造/教師のSHAを自然結果へ比較する。NPZやモデルJSONの時刻metadataによる物理byte同体は要求しない。この正式入力直結の追加CLI自体は今回全学習を重複実行していない。自然cache入力検査と、215モデルの保存JSON全再推論・独立教師再構築は実施済みである。

元cacheを持つ別checkoutでは`学習する.py`、`取得を結ぶ.py`、金融`outcomes161.py`のrunner、`集計する.py`の順に実行する。各Sourceの保存pathと固定出力先を確認し、未作成の作業先を使う。`correct`/`connect`は純関数として再用できる。ラベルを受けない出生判断を先に確定し、取得、金融を後段で結合する。

旧151正式ZIPと152/153正式選択は直接SHA/CRC確認して照合する。証拠は[旧151学習同体](検査/旧151学習の同体確認.json)・[8政策同体](検査/過去8政策の同体確認.json)。旧153と152は再探索せず保存政策を固定対照として継承した。旧156と未見2場は未使用。

## 金融・表の再現

`work/161三時間帯入口の金融/outcomes161.py`の`read_outcomes`は入口採否を受け取らず、正式148観測全73場を読了しCRC/解凍SHAを確認後に小表を確定する。strictH60 completeのF/A/NとCを区別する。IFDは最初touchの実BBO、なければcomplete endpoint、他は金融未知。Cでも早期touchがあれば金融既知。`net5`をtouch損益へ転用しない。

四表は型付きJSONを`CSVへ出力する.mjs`でartifact-toolに読み込み、全セル照合・再計算・inspect・表示確認を行ってUTF-8 BOM付きCSVへ出す。xlsxを生成しない。`CSVを独立再読する.py`でPython標準csv全セル再読。CSVが見られれば、表示確認画像やNode環境は閲覧に不要。

```powershell
node work/161三時間帯入口/CSVへ出力する.mjs study/00161_三時間帯の入口を共通属性分割で比較する/成果物/型付き四表.json outputs/隔離再現161
```

独立監査はSource.zip内の`work/161独立確認/`を参照。金融独立監査は作者と別のijsonで元全観測を読み直す。入口の3方式・閾値・A補正・N/U/Fを変えた場合は161を上書きせず新試行とする。
'''
    (TRIAL/'再現手順.md').write_text(reproduce,encoding='utf-8')
    # ----------------------------------------
    archive=TRIAL/'再現資料';archive.mkdir(exist_ok=True)
    source_files=set()
    folders=['161三時間帯入口','161三時間帯入口のモデル','161三時間帯入口のデータ','161三時間帯入口の金融',
        '161独立確認','161過去探索の照合','161結果の診断']
    for folder in folders:
        source_files.update(p for p in (ROOT/'work'/folder).iterdir() if p.is_file() and p.suffix in ('.py','.mjs','.md'))
    source_files.update(ROOT/p for p in ['work/151過去場判別/data151.py',
        'work/過去場だけの教師選択と時間区画重み/教師選択.py','work/152複合回復の入口/logic152.py','work/160時間帯診断/逐次読取.py'])
    with zipfile.ZipFile(archive/'Source.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as target:
        for p in sorted(source_files):
            target.write(p,p.relative_to(ROOT).as_posix())
    state_files=[p for p in (HERE/'自然学習').rglob('*') if p.is_file()]
    state_files += [p for p in (HERE/'選択').iterdir() if p.is_file() and p.name!='初回の選択完了.json']
    state_files += [ROOT/'work/161三時間帯入口の金融/自然射影/入力と算式の確認.json',
        ROOT/'work/161三時間帯入口の金融/自然射影/完了.json']
    with zipfile.ZipFile(archive/'学習と採否.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as target:
        for p in sorted(state_files):
            target.write(p,p.relative_to(ROOT).as_posix())
    runtime={name:importlib.metadata.version(name) for name in ('numpy','catboost','tzdata','ijson')}
    runtime.update(python=sys.version.split()[0],node='v24.22.1',artifact_tool='2.8.157')
    members={}
    for p in (archive/'Source.zip',archive/'学習と採否.zip'):
        with zipfile.ZipFile(p) as z:
            assert z.testzip() is None
            members[p.name]={'bytes':p.stat().st_size,'sha256':sha(p),'members':len(z.namelist())}
    save(archive/'保存索引.json',{'成功':True,'試行':161,'時計':datetime.now(timezone.utc).isoformat(),
        '条件SHA256':BOOK_SHA,'runtime':runtime,'archives':members,'inputs':book['inputs'],
        '共有入力の原板複製':False,'未見2場':False,'旧156実行':False,
        'formal_files':{str(p.relative_to(TRIAL)):{'bytes':p.stat().st_size,'sha256':sha(p)}
            for p in TRIAL.rglob('*') if p.is_file() and p.name!='保存索引.json'}})
    print(json.dumps({'成功':True,'archives':members,'runtime':runtime},ensure_ascii=False))


if __name__=='__main__':
    main()
