"""作業cacheが無い別checkoutで正式共有入力から161の数値モデルを復元する。"""
from pathlib import Path
import argparse
import gzip
import json
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from 学習する import ROOT,TRIAL,BOOK_SHA,module,sha,save


def main() -> None:
    """
    機能: 保存NPZのbyte同体を要求せず、正式148の射影から同じ学習・採否を再現する。
    引数: CLI output(Path)は未作成の隔離出力先。expected-audits(Path)は正式161場別監査。
    返り値: None。215モデル等を出力し、全配列/構造/教師SHAを旧自然実行へ照合する。
    """
    parser=argparse.ArgumentParser()
    parser.add_argument('output',type=Path)
    parser.add_argument('expected_audits',type=Path)
    args=parser.parse_args();assert not args.output.exists()
    assert sha(TRIAL/'条件.json')==BOOK_SHA
    book=json.loads((TRIAL/'条件.json').read_text(encoding='utf-8'))
    data=module(ROOT/'work/161三時間帯入口のデータ/data161.py','data161_replay')
    model=module(ROOT/'work/161三時間帯入口のモデル/model161.py','model161_replay')
    training=module(ROOT/'work/161三時間帯入口のモデル/training161.py','training161_replay')
    simulator=module(ROOT/'work/161三時間帯入口のモデル/simulate161.py','simulator161_replay')
    selector=module(ROOT/'work/過去場だけの教師選択と時間区画重み/教師選択.py','selector161_replay')
    simulator.validate_book(book,model,training)
    features=data.load_feature_from_formal()
    teachers=data.load_teacher_from_formal(features.feature_meta())
    columns,_=data.read_json_ref(data.FileRef(ROOT/'inputs/00148_全1分入口母集団/100特徴の列定義.json',book['catalog_definition_sha256']))
    args.output.mkdir(parents=True)
    decisions,audits=simulator.simulate(features,teachers,columns,features.q0_timeband,teachers.teacher_timeband,
        book,args.output,model,training,selector.select_past_teachers)
    expected=json.loads(gzip.decompress(args.expected_audits.read_bytes()))['rows']
    assert len(audits)==len(expected)==73
    for actual,wanted in zip(audits,expected,strict=True):
        assert actual['session']==wanted['session']
        for mode in ('COMMON','CONTEXT','SPLIT'):
            pairs=[(actual['models'][mode],wanted['models'][mode])] if mode!='SPLIT' else [
                (actual['models'][mode][b],wanted['models'][mode][b]) for b in actual['models'][mode]]
            for a,b in pairs:
                for name in ('ready','ready_reasons','canonical_teacher_sha256','training_feature_indices_sha256'):
                    assert a[name]==b[name]
                if a['ready']:
                    for name in ('training_array_sha256','structure_sha256'):
                        assert a['model'][name]==b['model'][name]
    save(args.output/'q0の判断.json.gz',{'成功':True,'試行':161,'q1結合前全件':True,'rows':decisions})
    save(args.output/'場別モデルと教師.json.gz',{'成功':True,'試行':161,'rows':audits})
    save(args.output/'正式入力からの再現確認.json',{'成功':True,'正式入力だけで射影':True,'場数':73,
        '配列と構造を全件照合':True,'物理モデルJSON同体は要求しない':'時刻等metadataが異なるため',
        'features':features.sources,'teachers':teachers.sources})


if __name__=='__main__':
    main()
