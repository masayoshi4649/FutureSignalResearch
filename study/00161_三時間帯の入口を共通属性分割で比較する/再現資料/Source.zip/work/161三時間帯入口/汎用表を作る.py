"""現行版8の全組み合わせを保持して161の利用範囲を記録する。"""
from pathlib import Path
import hashlib
import os
import re
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from 学習する import ROOT, TRIAL


def main() -> None:
    """
    機能: 63手法×9尺度を欠落なく複写し、設定IDと複合評価への対応を記す。
    引数: なし。版8を共有元として参照する。
    返り値: None。新試行の設定と結果.mdだけを作る。
    """
    source=ROOT/'docs/議論/手法と時間スケールの汎用表_版8.md'
    text=source.read_text(encoding='utf-8')
    body=text.split('## 手法×時間スケール',1)[1].split('## 設定明細',1)[0]
    body=body[body.index('### 指標'):]
    updates={}
    for method,description in [('I01','EMA8/21の傾き・差・距離'),('I03','MACD Hist水準・増分'),
        ('I04','RSI中心差・増分'),('I08','DI差/ADX水準・増分'),('I09','ATR/TR/125比')]:
        for scale in (3,4,5):
            updates[(method,scale)]='161-X：'+description+'。複合評価R161'
    for method,scale,description in [
        ('I01',0,'q0のEMA8/21との距離'),('I05',0,'q0のBB平均距離'),('I05',4,'BB15位置/σ/幅/実側余地'),
        ('I09',0,'q0距離のATR5正規化'),('P01',1,'実体/ヒゲ/終値位置'),('P01',3,'実体/ヒゲ/終値位置'),
        ('P02',1,'先行3分の高安端距離'),('P05',1,'1分終値増分'),('P06',0,'q0の先行3分端・余地'),
        ('V01',1,'観測量の前3分比'),('V01',3,'rvol5'),('B01',0,'q0正常BBO・spread<=20'),
        ('C01',0,'EMA/Hist/RSIを別入力、実split既知2役割以上'),('C02',0,'BB位置/RSIの木の複合'),
        ('C03',0,'BB/短期高安/観測量。長い支持抵抗の新生成なし'),('C04',0,'DI方向とADX強度を区別'),
        ('C07',0,'5/15/30分の別入力。全整合の手作業必須化なし'),
        ('M01',0,'CatBoost深さ3/128木＋3方式。単一木総当たりではない'),
        ('E01',0,'実BBO厳密H60・±125、F/A/N/C')]:
        updates[(method,scale)]='161-X/Q/M：'+description+'。複合評価R161'
    lines=[];count=0
    for line in body.splitlines():
        cells=[c.strip() for c in line.split('|')[1:-1]] if line.startswith('|') else []
        if len(cells)==11 and re.fullmatch(r'[A-Z][0-9]{2}',cells[0]):
            count+=1
            for scale in range(9):
                cells[scale+2]=updates.get((cells[0],scale),'未使用・未検証')
            line='| '+' | '.join(cells)+' |'
        lines.append(line)
    assert count==63
    body='\n'.join(lines)
    def replace_link(match: re.Match) -> str:
        """
        機能: 元版からの教材リンクを新試行から有効な相対位置へ移す。
        引数: match(re.Match)はMarkdownのリンク。
        返り値: strは移設済みリンク。
        """
        target=match.group(2)
        if '://' in target or target.startswith('#'):
            return match.group(0)
        location=(source.parent/target).resolve()
        return '['+match.group(1)+']('+os.path.relpath(location,TRIAL).replace('\\','/')+')'
    body=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',replace_link,body)
    prefix='# 161 設定と結果\n\n2026-11-14。[汎用表版8](../../docs/議論/手法と時間スケールの汎用表_版8.md)を63手法×9尺度=567セルで複写。元SHA256 `'+hashlib.sha256(source.read_bytes()).hexdigest()+'`。\n\n'
    prefix+='[条件](条件.json)と[結果](README.md)が正本。入力として提供した指標と、実際に木で採用された指標を区別する。複合成績を単独指標の効果とはしない。旧152/153の固定対照は旧設定を参照する。\n\n'
    suffix='''\n\n## 設定明細\n\n|設定ID|条件|\n|---|---|\n|161-X|正式148の当時100特徴、買売を実側2配列。確定5/15/30分・1分形状・q0 BBO。未知を0へ代用しない|\n|161-T|過去20暦場、全体正準物理q1、両実側H60完了・成熟strict<当場開始。1000pair/8寄与場/3クラス|\n|161-M|COMMON 100列、CONTEXT 100列+三帯onehot、SPLIT 帯内100列。128木/深さ3/率0.05/seed151、その他条件JSON。場開始時だけ学習|\n|161-S|q0のDAY/NY09:30前/以後、夏冬自動。時間属性は技術役割に不算入。帯不足は当場COMMONへ、共通不足は待機|\n|161-Q|0<spread<=20、-1<=q0Last−m1CloseのATR5比<=1。score=P(F)−P(A)、側差>=0.05、高score側だけを資格判定|\n|161-P|P(F)>=0.4、実split既知技術2役割以上、条件付きP(F)/(P(F)+P(A))>=0.70/0.65/0.60。実率の保証とはしない|\n|161-A|P65だけ旧152A0。G：30分EMA21傾き/DI、15分DIが元方向と逆、15分ADX>25。G内のみ1分実体/当時回復>0、5分HistΔ/RSIΔ>0、1分量の前3比>=1で実側Rを判定。片側のみ回復ならその側、両側/未知は待機|\n|161-L|N純新規/U旧87全保持/F最初旧信号時に新実取得0ならその1信号を補完。全場保証は固定旧参照継承の性質。後発新取得で予約取消しなし|\n|161-E|旧strictH60/±125。最初touchの実BBO、なければcomplete H60endpoint、他は金融未知。1mini100円/pt−往復77円−追加滑り1000円|\n\n## 複合条件と結果\n\nR161：3方式×3閾値＋3方式P65のA補正＝12信号、N/U/Fで36政策、固定C1/旧152B0/U1/旧153N15/U15の5対照、計41政策。各三帯で独立に最良を選んで結合する探索ではない。設定と成績は[四表](閲覧資料.md)、分岐で実際に採用した列・学習支持は保存モデルとモデル支持CSVへ記録する。支持不足と未使用を混同しない。\n\nE02の新追尾は対象外。今回の入口比較はIFD±125を揃え、出口改善との交絡を避ける。旧156や未見2場は未使用。全期・前48・後25とも既使用であり、過去順適用を未見検証とはしない。\n'''
    (TRIAL/'設定と結果.md').write_text(prefix+'## 手法×時間スケール\n\n'+body+suffix,encoding='utf-8')


if __name__=='__main__':
    main()
