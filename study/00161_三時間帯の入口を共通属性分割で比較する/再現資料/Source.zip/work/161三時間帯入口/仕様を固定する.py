"""161の自然学習前に、比較条件を正式な保存先へ固定する。"""
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
TRIAL=ROOT/'study/00161_三時間帯の入口を共通属性分割で比較する'


def main() -> None:
    """
    機能: 既存151の設定を基礎に比較政策と時計を固定し、新規試行を採番する。
    引数: なし。
    返り値: None。条件JSONと未実行のREADMEを保存する。
    """
    assert max(int(p.name[:5]) for p in (ROOT/'study').iterdir() if p.is_dir() and p.name[:5].isdigit())==160
    book=json.loads((ROOT/'work/151過去場判別/条件.json').read_text(encoding='utf-8'))
    book.update(trial=161,name='三時間帯の入口を共通属性分割で比較する')
    book['model_modes']=[{'id':'COMMON','context':False,'split':False},
        {'id':'CONTEXT','context':True,'split':False},{'id':'SPLIT','context':False,'split':True}]
    book['timebands']={'selection_clock':'canonical q0', 'report_clock':'実取得q1。q0帯は別記。',
        'boundary':'Night開始日America/New_York09:30をzoneinfoでUTC変換。等号から米国後。Dayは全てデイ。',
        'codes':{'DAY':0,'PRE_US':1,'POST_US':2},'train_clock':'各場開始時だけ学習。ナイト途中の再学習なし。',
        'split_support':'共通と同じ20暦場。1000物理pair/8寄与場/3クラス。帯絞込前に全体正準化。帯内で時区画重み再計算。',
        'split_fallback':'当該帯支持不足なら同じ場のCOMMON。COMMON未準備なら待機。時間属性は技術役割に数えない。'}
    signals=[f'{m}_{p}' for m in ('COMMON','CONTEXT','SPLIT') for p in ('P70','P65','P60')]
    signals += [f'{m}_P65_A' for m in ('COMMON','CONTEXT','SPLIT')]
    book['signal_policies']=signals
    book['main_policies']=[f'{m}_P65_A_F' for m in ('COMMON','CONTEXT','SPLIT')]
    book['policies']=[f'{s}_{c}' for s in signals for c in ('N','U','F')]+['C1','OLD152_B0_N','OLD152_U1','OLD153_N15','OLD153_U15']
    book['technical_correction']='P65だけ旧152logic152.choose A0を実側100Xに非改変適用。元方向失速G＋反対構造回復R。逆側へ元側確率を移さない。'
    book['linking']={'N':'純新規。最初q0を同物理q1の代表とする。',
        'U':'旧C1全87取得を保持して追加。衝突時C1優先。',
        'F':'各場で最初の旧C1真出生信号時点に、新規Nの実取得が0なら当該旧信号だけを予約し固定旧取得を継承。以後N継続。',
        'F_order':'最初信号は(time,index,source_line,id)順。実取得<=信号の認識は物理(time,index,source_line)のみ。未約定要求は0。後発N取得で予約取消しなし。同q1旧優先。',
        'F_limitation':'固定C1参照補完。純新入口や実口座保証とは区別。旧出生に結べないq0特徴を捏造しない。',
        'same_q1':'Nは最初q0。C1と競合するU/Fは旧優先。'}
    book['evaluation']={'population':'全73場、前48/後25とも既使用。未見2場は読まない。',
        'first_touch':'旧148strictH60/実側BBO/±125。両側は実側価格。completeのみF/A/N、他C。F/(F+A)を到達済み率とする。',
        'ifd':'旧IFD即時BBO代用。同±125最初touchで決済。touchなしcompleteならH60endpoint、他unknown。Cでも早期touchなら金融既知。',
        'cost':'1mini100円/pt。往復手数料77円＋片道5pt×2の追加控除1000円=C5合計1077円。',
        'not_account':'各入口独立1枚の研究集計。重複保有/片側10枚口座収支ではない。',
        'groups':'全期/前48/後25 × 全体/デイ/米国前/米国後。0取得場も全セッションCSVに保持。',
        'past_validity':'151COMMON全q0確率/判断と学習SHA、152A0/B0、153N15/U15を固定参照へ照合。全過去試行の再実行とは呼ばない。',
        'comparisons':41,'retraining_search':'3mode×3閾値＋P65A0。結果を見て閾値を再調整しない。'}
    book['主評価']='三時間帯を入口選択へ実際に組込み、共通/属性/分割を対照比較。全73場min1/到達済み70%/概ね1回毎時は別列。最高金額だけで採用しない。'
    TRIAL.mkdir()
    (TRIAL/'条件.json').write_text(json.dumps(book,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (TRIAL/'README.md').write_text('# 00161 三時間帯の入口を共通・属性・分割で比較する\n\n2026-11-14。自然学習前に[条件](条件.json)を固定。現在は未実行。160の事後分解を新入口の検証結果とは扱わない。\n\n全73場の旧151共通モデルを再現し、判断q0のデイ・ナイト米国前・米国後を使う属性モデルと帯別モデルを比較する。旧152の複合回復補正を共通に適用する。純新規N、旧全保持U、最初参加だけ旧参照を補完するFを区別する。固定補完による参加を純新入口の成果とはしない。\n',encoding='utf-8')
    print(json.dumps({'条件':str(TRIAL/'条件.json'),'SHA256':hashlib.sha256((TRIAL/'条件.json').read_bytes()).hexdigest()},ensure_ascii=False))


if __name__=='__main__':
    main()
