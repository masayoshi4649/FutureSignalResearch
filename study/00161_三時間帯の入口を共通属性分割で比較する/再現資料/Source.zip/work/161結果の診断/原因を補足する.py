"""固定161診断へ、支持不足・補正経路・相関・次仮説の事後追補を作る。"""
from collections import Counter, defaultdict
from pathlib import Path
import gzip
import json
import math

from 診断する import ROOT, HERE, TRIAL, MODES, POLICIES, metrics, read, records, render_table, pct, sha


# ----------------------------------------
def main() -> None:
    """
    機能: 同じ固定結果の有効モデル・金融ラベル内訳と技術的原因を記述する。
    引数: なし。新しい閾値・学習・政策は作らない。
    返り値: None。独立の追補JSONとMarkdownを新規保存する。
    """
    paths = {"根拠": HERE/"診断根拠.json", "小型": TRIAL/"成果物/入口とIFDの小型正本.json.gz", "判断": ROOT/"work/161三時間帯入口/自然学習/q0の判断.json.gz", "補正": ROOT/"work/161三時間帯入口/選択/補正q0の判断.json.gz", "四表": TRIAL/"成果物/型付き四表.json"}
    before = {str(path.relative_to(ROOT)): sha(path) for path in paths.values()}
    diagnostic, compact = read(paths["根拠"]), read(paths["小型"])
    raw = {row["event_id"]: row for row in read(paths["判断"])["rows"]}
    corrected = {row["event_id"]: row for row in read(paths["補正"])["rows"]}
    sessions = compact["全73場"]
    periods = {"全期": sessions, "前48場": sessions[:48], "後25場": sessions[48:]}
    actual_models, labels, reasons = [], [], []
    for mode in MODES:
        for period, scope in periods.items():
            rows = [row for row in compact["政策"] if row["policy"] == mode+"_P65_A_N" and row["session"] in scope]
            for effective in ("COMMON", "CONTEXT", "SPLIT", "WAIT"):
                subset = [row for row in rows if raw[row["event_id"]]["predictions"][mode]["effective_mode"] == effective]
                if subset:
                    actual_models.append({"要求方式": mode, "有効方式": effective, "期間": period, **metrics(subset)})
            for reason in sorted({corrected[row["event_id"]]["correction"][mode]["A0"]["reason"] for row in rows}):
                subset = [row for row in rows if corrected[row["event_id"]]["correction"][mode]["A0"]["reason"] == reason]
                reasons.append({"方式": mode, "期間": period, "補正理由": reason, **metrics(subset)})
            for label in "FANC":
                subset = [row for row in rows if row["label"] == label]
                labels.append({"方式": mode, "期間": period, "ラベル": label, **metrics(subset)})
    cluster = diagnostic["旧152の14逆行"]
    tracked = {}
    for mode in MODES:
        picked = [row["三方式"][mode]["実取得"]["N"] for row in cluster if row["三方式"][mode]["実取得"]["N"] is not None]
        tracked[mode] = {"取得": len(picked), "待機": 14-len(picked), "方向": dict(Counter(row["side"] for row in picked)), "先着": dict(Counter(row["label"] for row in picked)), "既知差引": sum(row["net"] for row in picked), "元P65方向": dict(Counter(row["三方式"][mode]["元P65方向"] for row in cluster)), "A補正理由": dict(Counter(row["三方式"][mode]["A補正"]["A0"]["reason"] for row in cluster)), "fallback件数": sum(row["三方式"][mode]["支持不足fallback"] for row in cluster)}
    proof = {"成功": True, "事後追補のみ": True, "新閾値": False, "新政策": False, "入力前後指紋": before, "有効モデル別": actual_models, "新枝のA補正理由別": reasons, "新枝の厳密ラベル別金融": labels, "旧14クラスタの三方式": tracked}
    assert all(sha(ROOT/path) == digest for path, digest in before.items())
    with (HERE/"原因の追補.json").open("w", encoding="utf-8", newline="\n") as output:
        json.dump(proof, output, ensure_ascii=False, indent=2, allow_nan=False)
        output.write("\n")
    text = "# 三時間帯比較の原因と次の仮説\n\n161の主3案は全73場参加を保ったが、到達済み70%と後期の安定利益を確認できなかった。時間帯を入力や教師へ足すだけでは、テクニカルの局面変化を十分に判別できなかった。以下は固定済み結果の事後診断であり、当試行へ条件を追加しない。\n\n"
    text += "## 支持不足とモデル自身の誤判別を分ける\n\nCOMMON/CONTEXTは65/73場で学習可能。SPLITはデイ29/37、米国前28/36、米国後28/36で帯別学習可能だった。全q0中のSPLIT fallbackはCOMMON3,799、WAIT3,323。次表は実取得したNだけを有効モデルへ分けたものである。\n\n"
    text += render_table(["要求", "有効モデル", "期間", "取得", "順/逆/未/不足", "到達済み率", "既知差引円"], [[row["要求方式"], row["有効方式"], row["期間"], row["取得"], "/".join(str(row[key]) for key in ("順", "逆", "未", "不足")), pct(row["到達済み率"]), row["既知差引"]] for row in actual_models if row["要求方式"] == "SPLIT"])
    text += "\n支持不足は初期の待機と共通モデルへの復帰を説明する。後期の分割モデル自身の成績とは分ける必要があり、窓や支持下限を結果を見て緩める根拠にはしない。\n\n## 元の入口を何が変えたか\n\nCOMMON Nは旧152 A0と748取得・402順263逆58未25不足、利益5,048,581円・損失3,889,484円で一致した。したがって、COMMON Fの参加増加は同じ新枝に固定C1初参加補完を加えた効果である。CONTEXTの属性追加も、SPLITの教師分割も全体の精度改善にはつながらなかった。\n\n"
    text += render_table(["方式", "期間", "A補正理由", "取得", "順/逆/未/不足", "到達済み率", "既知差引円"], [[row["方式"], row["期間"], row["補正理由"], row["取得"], "/".join(str(row[key]) for key in ("順", "逆", "未", "不足")), pct(row["到達済み率"]), row["既知差引"]] for row in reasons if row["期間"] == "後25場"])
    text += "\n## 14逆行を直せたことと場全体の成績は別\n\n"
    text += render_table(["方式", "旧14件で取得", "待機", "実側の順/逆", "既知差引円"], [[mode, tracked[mode]["取得"], tracked[mode]["待機"], str(tracked[mode]["先着"].get("F", 0))+"/"+str(tracked[mode]["先着"].get("A", 0)), tracked[mode]["既知差引"]] for mode in MODES])
    text += "\n旧14件は全て買い、合計−198,078円。CONTEXTは確率がP65へ達しない最初5件を待機し、残る9買いは逆行した。SPLITはP65自体が9件で売りを選び、5件は待機した。9売りは全て実逆側の先着Fで、A0が後から強反対背景内で反転させたものではない。全14件でSPLITのfallbackは0だった。\n\n一方、SPLIT Nの10/23ナイト全体は155取得・32順56逆55未12不足、既知−656,242円。同じ場の局所修復を、全場の安定化と呼ぶことはできない。14件だけを見て買いを一律に反転する政策も採用しない。\n\n## 技術から見た見逃し\n\nCOMMONの14件はG=falseで元方向維持となった。買い側30分EMA21傾きは+21.53、30分DI差は−0.81、15分DI差は+7.07、15分ADXは23.09と混在している。Gは30分EMAと30/15分DIが全て反対、かつ15分ADX>25を要求するため、こうした遷移状態を反対背景として扱わない。\n\nG外では回復Rを注文の必要条件にしていない。最初の17:31の1分実体比は未知、現在まで残る回復は0、買い側5分Hist増分−0.857・RSI増分−0.832、1分相対量0.645でも、COMMON P65の買いをそのまま維持した。背景方向が崩れ始めた局面で短期再加速を必須にしなかった、という設計上の穴を実例で確認できる。ただしこの一例だけから普遍的な有効条件を断定しない。\n\nこの14件の買いEMA8距離は−1.30～+0.20ATRで、単に上へ追い過ぎたケースではない。追値距離の上限だけでは拒否できない。ATR比の1分値幅は0～0.56、1分相対量は0.11～6.27と幅があり、量の大小単独で揃っていた群でもない。5分相対量rvol5は全14件で未知だったため、量の未知を数値0へ置き換えて解釈しない。\n\n## 場集中と標本の意味\n\nCOMMON Nの取得は最多5場へ53.07%、CONTEXT Nは58.62%集中した。10/22デイのCOMMON Nだけで118取得・96順18逆・既知+895,914円を占める一方、10/30デイは86取得・35順51逆・−301,622円、10/20ナイトは68取得・20順37逆・−309,005円である。\n\nSPLIT Nの最多5場比は26.53%へ下がったが、取得を広げても精度は改善しなかった。旧14件も17:31～17:45の15分間に近接しており、14個の独立した相場とは言えない。1時間先着の重なる入口を独立試行として信頼性を過大評価しない。ユーザーの許容する場ごとの頻度差は維持し、均等化や機会損失の最大化は行わない。\n\n## 次試行へ持ち越す仮説\n\n1. **背景が同方向・反対・混在の三状態を技術で定義する。** MAの傾き、DI差、ADXの変化を組み合わせ、反対背景G=falseをそのまま順行可能と扱わない。混在時は1分実体/現在生存回復、5分Hist/RSI再加速、量の確認で、順行・反転・待機を分ける。回復の未知と不成立は別に残す。\n2. **量を伴う推進と終端スパイクを分ける。** BBの余地・価格位置、ATR比値幅、実体/ヒゲ、Hist/RSI増分、相対量を組み合わせる。過熱や大商いだけで反転せず、反対側の構造回復を確認する。時帯は文脈として残し、時帯だけを売買方向の根拠にしない。\n3. **構造episodeと再武装を明示する。** 同じ背景票と同じ回復状態で連続するq0を別々の独立エッジとみなさず、押戻し・失敗突破・回復の状態遷移を再武装の条件にする。定時の回数上限ではなく、技術状態の変化で新しい出生を区別し、全対象時間の頻度と場参加を別に検証する。\n4. **共通幹と帯ごとの差分を分ける。** 現161の完全分割は教師関係を全て別モデルへ置いた。次は共通の技術状態を先に定義し、帯別に変える箇所を限定する仮説を結果前に固定する。3帯それぞれで自由に最良閾値を選ぶ探索へ戻さない。\n\nこれらは新しい未検証仮説であり、161の未達を後付けで達成へ置き換えるものではない。旧153 U15の入口目標一旦達成は保持する。追加実験をする場合は新試行番号・固定条件で比較する。\n"
    text = text.replace("背景方向が崩れ始めた局面で短期再加速を必須にしなかった、という設計上の穴を実例で確認できる。", "背景方向が混在し短期動力も買いを支持していない局面で、短期再加速を必須にしない設計だったことを実例で確認できる。")
    text = text.replace("量の大小単独で揃っていた群でもない。", "量の大小が一様な群でもない。")
    psychology = "心理面の仮説としては、上位平均へ過去の買い優勢が残る一方で、短期の追加買いが弱まり、利食いや戻り売りが相対的に強まった状態を考えられる。平均線の上向きは過去価格の記録であり、今の追加需要を直接測るものではない。Hist/RSIの増分、実体回復、量が担う別役割を確認する理由はここにある。ただし参加者の実際の意思や売買主体は本データから確認しておらず、市場心理を証明した事実とはしない。\n\n"
    text = text.replace("## 場集中と標本の意味", psychology+"## 場集中と標本の意味")
    (HERE/"原因と次の仮説.md").write_text(text, encoding="utf-8", newline="\n")
    print(json.dumps({"成功": True, "追補根拠SHA256": sha(HERE/"原因の追補.json"), "追補MD_SHA256": sha(HERE/"原因と次の仮説.md"), "14クラスタ": tracked}, ensure_ascii=False))


if __name__ == "__main__":
    main()
