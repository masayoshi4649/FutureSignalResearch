"""161の固定結果を事後分解し、政策を変更せず原因候補を整理する。"""
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
import gzip
import hashlib
import importlib.util
import json
import math
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
TRIAL = ROOT/"study/00161_三時間帯の入口を共通属性分割で比較する"
MODES = ("COMMON", "CONTEXT", "SPLIT")
POLICIES = tuple(mode+"_P65_A_"+suffix for mode in MODES for suffix in ("N", "F"))
BANDS = ("デイ", "米国前", "米国後")
TECHNICAL_KEYS = ("m30_ema21_delta_atr_to_side", "m15_di_difference_to_side", "m15_adx", "m5_hist_delta_atr_to_side", "m5_rsi_delta_to_side", "m1_body_ratio_to_side", "m1_body_reclaim_atr5_to_side", "m1_volume_relative_prior3", "rvol5", "bb15_forward_room_125_ratio_to_side", "q0_entry_minus_ema8_atr5_to_side", "m1_range_atr5_ratio", "q0_last_minus_prior3_forward_edge_atr5_to_side")


# ----------------------------------------
def sha(path: Path) -> str:
    """
    機能: 読み取り対象の物理指紋を求める。
    引数: path(Path)はファイル。
    返り値: strはSHA256。
    """
    with path.open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def read(path: Path) -> object:
    """
    機能: 完成済みJSON又はgzipを解釈する。
    引数: path(Path)は固定成果物。
    返り値: objectはJSON内容。入力は変更しない。
    """
    body = path.read_bytes()
    return json.loads(gzip.decompress(body) if path.suffix == ".gz" else body)


def module(path: Path) -> object:
    """
    機能: 既存入力部品をmain未実行で読み込む。
    引数: path(Path)はdata161のSource。
    返り値: objectはmodule。
    """
    spec = importlib.util.spec_from_file_location("診断用161入力", path)
    value = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = value
    spec.loader.exec_module(value)
    return value


def records(table: dict) -> list[dict]:
    """
    機能: Root型付き表の列順から辞書行を復元する。
    引数: table(dict)はheaders/rowsを持つ表。
    返り値: list[dict]は同じ値を持つ行。
    """
    assert len(table["headers"]) == len(set(table["headers"]))
    assert all(len(row) == len(table["headers"]) for row in table["rows"])
    return [dict(zip(table["headers"], row)) for row in table["rows"]]


def metrics(rows: list[dict]) -> dict:
    """
    機能: 固定された集合の厳密先着・金融・場集中を記述統計へ分ける。
    引数: rows(list[dict])は選択済み入口の小型行。
    返り値: dictは件数・三分母率・既知利益/損失・集中率。候補の選び直しはしない。
    """
    counts = Counter(row["label"] for row in rows)
    money = [row["net"] for row in rows if row["known"]]
    scenes = Counter(row["session"] for row in rows)
    profit, loss = sum(max(0, value) for value in money), -sum(min(0, value) for value in money)
    return {"取得": len(rows), "順": counts["F"], "逆": counts["A"], "未": counts["N"], "不足": counts["C"], "到達済み率": counts["F"]/(counts["F"]+counts["A"]) if counts["F"]+counts["A"] else None, "取得場": len(scenes), "金融既知": len(money), "金融未知": len(rows)-len(money), "利益": profit, "損失": loss, "既知差引": profit-loss, "PF": profit/loss if loss else None, "最多場の件数比": max(scenes.values(), default=0)/len(rows) if rows else None}


def render_table(headers: list[str], rows: list[list]) -> str:
    """
    機能: 小型診断表をMarkdownへ表示する。
    引数: headers(list[str])、rows(list[list])は列と表示済みセル。
    返り値: strはMarkdown表。
    """
    return "|"+"|".join(headers)+"|\n|"+"|".join("---" for _ in headers)+"|\n"+"\n".join("|"+"|".join(str(cell).replace("|", "/") for cell in row)+"|" for row in rows)+"\n"


def pct(value: float | None) -> str:
    """
    機能: 分母なしを未知のまま率へ整形する。
    引数: value(float又はNone)は比率。
    返り値: strは百分率又は未定義。
    """
    return "未定義" if value is None else "%.2f%%" % (value*100)


def jst(value: float) -> str:
    """
    機能: 保存UTC秒を日本時刻へ表示する。
    引数: value(float)はUTC秒。
    返り値: strは時分秒。
    """
    return datetime.fromtimestamp(value, ZoneInfo("Asia/Tokyo")).strftime("%H:%M:%S")


# ----------------------------------------
def main() -> None:
    """
    機能: 完成済み161四表・小型正本・当時判断を診断し再探索なしで保存する。
    引数: なし。Rootが完成させた固定成果物のみを読む。
    返り値: None。work/161結果の診断へJSON根拠とMarkdownを新規保存する。
    """
    paths = {
        "四表": TRIAL/"成果物/型付き四表.json",
        "小型正本": TRIAL/"成果物/入口とIFDの小型正本.json.gz",
        "選択": ROOT/"work/161三時間帯入口/選択/選択対応.json.gz",
        "補正判断": ROOT/"work/161三時間帯入口/選択/補正q0の判断.json.gz",
        "自然判断": ROOT/"work/161三時間帯入口/自然学習/q0の判断.json.gz",
        "モデル支持": ROOT/"work/161三時間帯入口/自然学習/場別モデルと教師.json.gz",
        "旧152": ROOT/"inputs/00152_複合回復の方向切替/選択対応.json.gz",
        "全case金融": ROOT/"work/161三時間帯入口の金融/自然射影/全caseの厳密先着とIFD.json.gz",
        "data161": ROOT/"work/161三時間帯入口のデータ/data161.py",
        "Root由来訂正": TRIAL/"検査/修正と全取得同体の確認.json",
    }
    before = {str(path.relative_to(ROOT)): sha(path) for path in paths.values()}
    root_tables, compact, selection = read(paths["四表"]), read(paths["小型正本"]), read(paths["選択"])
    assert root_tables["trial"] == compact["試行"] == selection["試行"] == 161
    all_rows = compact["政策"]
    sessions = compact["全73場"]
    assert sessions == selection["全73場"] and len(sessions) == 73
    indices = {session: i for i, session in enumerate(sessions)}
    periods = {"全期": sessions, "前48場": sessions[:48], "後25場": sessions[48:]}
    data = module(paths["data161"])
    features = data.load_feature_dataset()
    feature_by_event = {row["event_id"]: i for i, row in enumerate(features.q0_meta)}
    before.update({str(data.FEATURE_NPZ.path.relative_to(ROOT)): data.FEATURE_NPZ.sha256, str(data.FEATURE_META.path.relative_to(ROOT)): data.FEATURE_META.sha256})
    main_rows = {policy: [row for row in all_rows if row["policy"] == policy] for policy in POLICIES}
    groups, concentration, technology = [], {}, []
    corrected = {row["event_id"]: row for row in read(paths["補正判断"])["rows"]}
    raw = {row["event_id"]: row for row in read(paths["自然判断"])["rows"]}
    for policy, rows in main_rows.items():
        mode = policy.split("_", 1)[0]
        for period, scope in periods.items():
            for band in (-1, 0, 1, 2):
                subset = [row for row in rows if row["session"] in scope and (band < 0 or row["q1_timeband"] == band)]
                for branch in ("全体", "新枝", "旧補完"):
                    selected_rows = [row for row in subset if branch == "全体" or ((row["source_kind"] == "旧C1固定参照") == (branch == "旧補完"))]
                    groups.append({"政策": policy, "期間": period, "帯": "全体" if band < 0 else BANDS[band], "枝": branch, **metrics(selected_rows)})
        scenes = defaultdict(list)
        for row in rows:
            scenes[row["session"]].append(row)
        top = sorted(scenes, key=lambda session: (-len(scenes[session]), indices[session]))[:5]
        concentration[policy] = {"最多5場": [{"セッション": session, **metrics(scenes[session])} for session in top], "最多5場の取得比": sum(len(scenes[session]) for session in top)/len(rows) if rows else None, "新枝A補正理由": dict(Counter(corrected[row["event_id"]]["correction"][mode]["A0"]["reason"] for row in rows if row["event_id"] is not None)), "新枝flip数": sum(corrected[row["event_id"]]["correction"][mode]["A0"]["action"] == "flip" for row in rows if row["event_id"] is not None)}
        if policy.endswith("_N"):
            for period, scope in periods.items():
                for label in ("F", "A"):
                    sample = [row for row in rows if row["session"] in scope and row["label"] == label]
                    for key in TECHNICAL_KEYS:
                        position = features.columns.index(key)
                        values = [(features.buy_X if row["side"] == 1 else features.sell_X)[feature_by_event[row["event_id"]], position] for row in sample]
                        known = np.array([float(value) for value in values if math.isfinite(value)])
                        technology.append({"政策": policy, "期間": period, "ラベル": label, "列": key, "対象": len(sample), "既知": len(known), "中央値": float(np.median(known)) if len(known) else None, "第1四分位": float(np.quantile(known, .25)) if len(known) else None, "第3四分位": float(np.quantile(known, .75)) if len(known) else None})
    # ----------------------------------------
    # 旧152 U0に含まれた特定一場の14逆行を、事前のevent IDのまま追跡します。
    old, finance = read(paths["旧152"]), read(paths["全case金融"])
    old_c1 = {row["case_id"] for row in old["政策"]["C1"]}
    cluster = [row for row in old["政策"]["U0"] if row["session"] == "2026-10-23_Night" and row["case_id"] not in old_c1 and data.timeband(row["session"], finance[row["case_id"]]["entry_quote"]["time"]) == data.PRE_US]
    assert len(cluster) == 14 and all(finance[row["case_id"]][row["stream"]]["label"] == "A" for row in cluster)
    cluster_rows = []
    for source in cluster:
        event = source["event_id"]
        decision, original = corrected[event], raw[event]
        fi = feature_by_event[event]
        case = finance[source["case_id"]]
        details = {}
        for mode in MODES:
            vote = original["predictions"][mode]
            correction = decision["correction"][mode]
            direction = decision["decision"]["directions"][mode+"_P65_A"]
            chosen = {suffix: next((row for row in main_rows[mode+"_P65_A_"+suffix] if row["case_id"] == source["case_id"]), None) for suffix in ("N", "F")}
            details[mode] = {"元P65方向": decision["decision"]["directions"][mode+"_P65"], "A補正方向": direction, "旧側と同じ": direction == source["side"], "旧側から反転": direction == -source["side"], "予測方式": vote["effective_mode"], "支持不足fallback": vote["fallback"], "原予測理由": vote["prediction"]["reason"], "条件付き順行確率": vote["prediction"].get("conditional_forward"), "買売確率": vote["prediction"]["probabilities"], "A補正": correction, "実取得": {suffix: None if row is None else {key: row[key] for key in ("side", "label", "known", "net", "source_kind")} for suffix, row in chosen.items()}}
        value_by_side = {str(side): {key: None if not math.isfinite(float(vector[features.columns.index(key)])) else float(vector[features.columns.index(key)]) for key in TECHNICAL_KEYS} for side, vector in ((1, features.buy_X[fi]), (-1, features.sell_X[fi]))}
        cluster_rows.append({"event_id": event, "case_id": source["case_id"], "q0時間": jst(decision["q0_time"]), "取得時間": jst(case["entry_quote"]["time"]), "旧side": source["side"], "旧ラベル": "A", "旧net": case[source["stream"]]["net"], "実逆側ラベル": case["reverse" if source["stream"] == "original" else "original"]["label"], "実逆側net": case["reverse" if source["stream"] == "original" else "original"]["net"], "三方式": details, "当時技術値": value_by_side})
    audits = read(paths["モデル支持"])["rows"]
    supports = {"COMMON準備場": sum(a["models"]["COMMON"]["ready"] for a in audits), "CONTEXT準備場": sum(a["models"]["CONTEXT"]["ready"] for a in audits), "SPLIT帯別": {}, "SPLITfallback_q0": dict(sum((Counter(a["split_fallback_q0_counts"]) for a in audits), Counter()))}
    for band in (0, 1, 2):
        relevant = [a for a in audits if str(band) in a["models"]["SPLIT"]]
        supports["SPLIT帯別"][BANDS[band]] = {"対象場": len(relevant), "帯別準備場": sum(a["models"]["SPLIT"][str(band)]["ready"] for a in relevant), "不足理由": dict(Counter(reason for a in relevant for reason in a["models"]["SPLIT"][str(band)]["ready_reasons"]))}
    comparison = records(root_tables["tables"]["比較一覧"])
    overall = [row for row in comparison if row["政策"] in POLICIES]
    for root in overall:
        own = next(row for row in groups if row["政策"] == root["政策"] and row["期間"] == root["期間"] and row["帯"] == row["枝"] == "全体")
        assert (own["取得"], own["順"], own["逆"], own["利益"], own["損失"], own["既知差引"]) == tuple(root[key] for key in ("取得", "順", "逆", "利益総額", "損失総額", "既知差引"))
    assert all(sha(ROOT/path) == digest for path, digest in before.items())
    proof = {"成功": True, "試行": 161, "事後診断のみ": True, "新学習": False, "新閾値": False, "政策変更": False, "参照": before, "群別": groups, "場集中と補正": concentration, "支持": supports, "技術値の記述統計": technology, "旧152の14逆行": cluster_rows, "Root比較表との主要6政策18群同体": True}
    with (HERE/"診断根拠.json").open("w", encoding="utf-8", newline="\n") as output:
        json.dump(proof, output, ensure_ascii=False, indent=2, allow_nan=False)
        output.write("\n")
    text = "# 161の事後診断\n\n固定済みのCOMMON/CONTEXT/SPLIT P65_AのN/Fを比較する。全73場は既使用であり、前48/後25も独立未知期ではない。全期最高額で採用案を選ばず、帯・枝・場集中・支持を分ける。新閾値・新学習・政策の交換は行っていない。\n\n"
    text += "## 主Fの前後\n\n"
    text += render_table(["方式", "期間", "取得", "順/逆/未/不足", "到達済み率", "参加", "利益円", "損失円", "既知差引円", "未知"], [[row["政策"].split("_", 1)[0], row["期間"], row["取得"], "/".join(str(row[key]) for key in ("順", "逆", "未到達", "観測不足")), pct(row["到達済み先着率"]), str(row["取得場"])+"/"+str(row["対象場"]), row["利益総額"], row["損失総額"], row["既知差引"], row["金融未知"]] for row in overall if row["政策"].endswith("_F")])
    text += "\n## 純新枝Nと初参加補完F\n\n"
    text += render_table(["政策", "取得", "到達済み率", "参加", "毎時", "旧補完", "利益円", "損失円", "既知差引円", "最多場比"], [[row["政策"], row["取得"], pct(row["到達済み先着率"]), str(row["取得場"])+"/"+str(row["対象場"]), "%.3f"%row["取得毎時"], row["旧C1取得"], row["利益総額"], row["損失総額"], row["既知差引"], pct(row["最大場集中率"])] for row in overall if row["期間"] == "全期"])
    text += "\nFの全場参加は固定C1の最初信号による補完を含む。N単独の参加と精度とは区別する。旧補完の当時100Xを新q0へ捏造していない。\n\n## 三帯・前後の主F\n\n"
    text += render_table(["方式", "期間", "取得帯", "取得", "順/逆/未/不足", "到達済み率", "新/旧", "既知差引円"], [[row["政策"].split("_", 1)[0], row["期間"], row["帯"], row["取得"], "/".join(str(row[key]) for key in ("順", "逆", "未", "不足")), pct(row["到達済み率"]), str(next(x["取得"] for x in groups if x["政策"] == row["政策"] and x["期間"] == row["期間"] and x["帯"] == row["帯"] and x["枝"] == "新枝"))+"/"+str(next(x["取得"] for x in groups if x["政策"] == row["政策"] and x["期間"] == row["期間"] and x["帯"] == row["帯"] and x["枝"] == "旧補完")), row["既知差引"]] for row in groups if row["政策"].endswith("_F") and row["期間"] != "全期" and row["帯"] != "全体" and row["枝"] == "全体"])
    text += "\n## 旧152の10月23日ナイト米国前・14逆行\n\n同じ旧152 U0の新枝14件をcase/eventで固定追跡した。新方式による待機は回避件数として記述するが、決済後の取り逃がした利益を機会損失として最適化しない。\n\n"
    text += render_table(["q0", "旧側", "旧net", "実逆側", "COMMON N", "CONTEXT N", "SPLIT N"], [[row["q0時間"], row["旧side"], row["旧net"], row["実逆側ラベル"], *["待機" if row["三方式"][mode]["実取得"]["N"] is None else str(row["三方式"][mode]["実取得"]["N"]["side"])+"/"+row["三方式"][mode]["実取得"]["N"]["label"] for mode in MODES]] for row in cluster_rows])
    text += "\n## 系譜と解釈の範囲\n\nCOMMONは旧151と同じ100X・教師窓・固定パラメータを再学習する対照。P65_Aは旧152 A0の強反対背景G/両側回復Rを非改変適用する。旧152 B0/U1には追加のEMA8距離上限があり、P65_Aとの差を時間帯だけの効果と呼ばない。旧153は独立した先行域からの構造出生であり、学習モデルの閾値版ではない。旧153 U15の入口目標一旦達成は保持する。\n\n完全分割には同じ過去20暦場内で1000pair/8寄与場/3クラスを要求する。支持不足はCOMMONへ戻すため、SPLIT全成績は帯別モデルだけの成績ではない。準備数とfallbackは診断根拠JSONに残した。13技術列のF/A中央値・四分位も事後記述であり、それを新しい閾値へ反映していない。\n"
    (HERE/"結果の診断.md").write_text(text, encoding="utf-8", newline="\n")
    print(json.dumps({"成功": True, "主要政策": len(POLICIES), "群": len(groups), "旧逆行クラスタ": len(cluster_rows), "診断根拠SHA256": sha(HERE/"診断根拠.json"), "報告SHA256": sha(HERE/"結果の診断.md")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
