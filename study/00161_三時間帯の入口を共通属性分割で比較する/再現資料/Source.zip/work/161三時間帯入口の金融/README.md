# 161の先着とIFD純観測小表

2026-11-14。Rootの161 F0後通知を受領した。モデル・q0採否・政策の選択結果を引数へ取らず、正式148全73場の31,642物理caseを実元側と実逆側へ独立射影する。Raw、未見11/10ナイト・11/11デイ、156は読まない。

`outcomes161.read_outcomes(evidence=None)` は `dict[case_id]` を返す。各値は `session/entry_quote/original_side/execution_end/original/reverse`。両streamは `label/complete/status/direction/deadline/label_known_at/side/entry_price/mark_basis/mark/known/reason/points/net/net0/exit_quote/touch_quote/endpoint_quote` を持つ。`net` はC5、未知はNone。

旧厳密H60±125はcompleteだけをF/A/Nへ分け、不完全はtouch記録があってもCとする。ラベルの成熟時計はcomplete endpointである。IFDは最初125touchがあればその実Quote、無ければcomplete endpointで清算を代用する。Cでも早期touchがあれば金融既知。Cで未touchなら金額未知のまま。買いはAskで新規しBidで清算、売りはBidで新規しAskで清算する。

`points=side*(mark-entry_price)`、`net=points*100-77-1000`、`net0=points*100-77`。125の指値価格を返済約定と決め打ちせず、記録された最初touchの気配を使う。旧outcome.net5はendpointの金額なので使用しない。これは旧148の厳密H60/IFD約定代用であり、157/158のD1・force_close打切り出口、実mini板の注文約定や口座収支とは別である。

逐次器は `work/160時間帯診断/逐次読取.py`、SHA256 `2dd1e469ce8233cb757f2ba95b7f0a60e2bf163d7c59739462132d2ec8f17cac` を同体再用する。160の正式Sourceから復元可能で、161の保管対象にもこの参照と版を含める。全73sceneと末尾JSONを読み切り、gzip全CRC・物理SHA・解凍SHA・前後statを確認してから小表を確定する。原板・大観測の副本は保存しない。

固定取得入力は正式148 `inputs/00148_全1分入口母集団/固定取得入力.json.gz`、物理SHA `99f10a996ca6e8b6c428061f1b48624bbc479ec84c500a9633818d47e4298e2a`、解凍SHA `12c43fe60e0ffd5ffa44bec7b5f7dd3d60bb92b291e0008db23587dcf19536d3`。大観測は `study/00148_全1分知得から入口品質の母集団を固定する/成果物/固定取得の正逆観測.json.gz`、物理SHA `bd809bdf24400628817afee702063504c65682e6748a60e0f32d7690b7363c61`、解凍SHA `d1b4cab8a258203f04b5c1d081f57d10ed2a0c58ce4cc160ef571d5fac0ceffc`。

`prepare_finance161.py` で人工6群・構文/複数行関数コメント・UTF-8・Source前後一致を固定し、以後Sourceを停止する。その後 `run_finance161.py --output-dir work/161三時間帯入口の金融/自然射影` で未作成先へ `全caseの厳密先着とIFD.json.gz`、入力と算式の確認、完了票を保存する。gzip本文はラッパー無しのcase辞書であり、新政策の採否/集計を含まない。正式成果物への昇格と独立監査はRootの担当である。
