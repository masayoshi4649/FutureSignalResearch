"""161金融部品の人工・構文・UTF-8を確認してSourceを停止する。"""
from pathlib import Path
import ast
import json
import os
import subprocess
import sys

import outcomes161 as M

HERE = Path(__file__).resolve().parent


# ----------------------------------------
def main() -> None:
    """
    機能: 自然の金融計算前に人工6群とSource前後一致を固定する。
    引数: なし。
    返り値: None。未作成の準備票/停止票をUTF-8で出力する。
    """
    paths = [HERE/name for name in ("outcomes161.py", "test_outcomes161.py", "run_finance161.py", "prepare_finance161.py", "README.md")]
    before = {path.name: M.sha(path) for path in paths}
    assert M.sha(M.READER) == M.READER_SHA256
    for path in paths:
        if path.suffix == ".py":
            tree = ast.parse(path.read_text(encoding="utf-8"))
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    text = ast.get_docstring(node)
                    assert text and "\n" in text and all(word in text for word in ("機能", "引数", "返り値")), (path.name, node.name)
    command = [sys.executable, "-B", "-X", "utf8", str(HERE/"test_outcomes161.py")]
    process = subprocess.run(command, capture_output=True, cwd=HERE, env={**os.environ, "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8", "PYTHONDONTWRITEBYTECODE": "1"})
    stdout, stderr = process.stdout.decode("utf-8", "strict"), process.stderr.decode("utf-8", "strict")
    assert process.returncode == 0 and "\ufffd" not in stdout+stderr
    assert before == {path.name: M.sha(path) for path in paths} and M.sha(M.READER) == M.READER_SHA256
    proof = {"成功": True, "試行": 161, "人工主検査数": 6, "自然金融計算": False, "自然仕様調査": "F0後、最初sceneのキー名だけを部分読取。旧観測金融値/新採否は未算出。部分読取を全CRC検証と主張しない。", "新入口採否": False, "構文と日本語関数コメント": True, "UTF8_strict": True, "全源前後一致": True, "源": before, "逐次器": {"path": str(M.READER), "sha256": M.READER_SHA256}, "実行": {"引数": command, "終了値": process.returncode, "標準出力": stdout, "標準エラー": stderr}, "自然実行条件": "Rootの161 F0後通知と金融部品停止後の明示実行許可を受領済み。"}
    prep_path = HERE/"金融準備の確認.json"
    with prep_path.open("x", encoding="utf-8", newline="\n") as output:
        json.dump(proof, output, ensure_ascii=False, indent=2, allow_nan=False)
        output.write("\n")
    stop = {"成功": True, "編集停止": True, "準備票SHA256": M.sha(prep_path), "源": before, "逐次器SHA256": M.READER_SHA256}
    stop_path = HERE/"金融部品の停止.json"
    with stop_path.open("x", encoding="utf-8", newline="\n") as output:
        json.dump(stop, output, ensure_ascii=False, indent=2)
        output.write("\n")
    print(json.dumps({"成功": True, "outcomes161_SHA256": before["outcomes161.py"], "準備票SHA256": M.sha(prep_path), "停止票SHA256": M.sha(stop_path)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
