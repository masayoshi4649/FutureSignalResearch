"""161金融射影を人工BBOと人工gzipだけで確認する。"""
from pathlib import Path
from tempfile import TemporaryDirectory
import copy
import gzip
import hashlib
import json
import unittest

import outcomes161 as M


# ----------------------------------------
def fixture(side: int, direction: int, complete: bool) -> tuple:
    """
    機能: 実買/実売で同じ相対変化を持つ人工H60観測を作る。
    引数: side(int)は実側、direction(int)は先着-1/0/+1、complete(bool)は厳密完了。
    返り値: tuple[dict,dict]は人工streamと取得Quote。
    """
    entry = {"time": 100, "index": 10, "source_line": 11, "bid": 1000, "ask": 1010, "last": 1005, "quote_ok": True}
    price = entry["ask" if side == 1 else "bid"]
    point = direction*130
    mark = price+side*point
    touch = {**entry, "time": 101, "index": 12, "source_line": 13, "bid": mark if side == 1 else mark-10, "ask": mark+10 if side == 1 else mark} if direction else None
    endpoint = {**entry, "time": 3701, "index": 20, "source_line": 21, "bid": price+20 if side == 1 else price-30, "ask": price+30 if side == 1 else price-20} if complete else None
    outcome = {"seconds": 3600, "deadline": 3700, "status": "complete" if complete else "quality_lost", "touches": [{"width": 125, "direction": direction, "quote": touch}], "endpoint": endpoint, "net5": 999999999}
    return {"status": "filled", "axis": "BBO", "birth": {"side": side}, "entry": entry, "entry_price": price, "outcomes": [outcome]}, entry


# ----------------------------------------
class FinanceTests(unittest.TestCase):
    def test_mirror_and_gap(self) -> None:
        """
        機能: 両実側で125超ギャップの実Quote清算と費用を検査する。
        引数: self(FinanceTests)。
        返り値: None。
        """
        for side in (-1, 1):
            for direction in (-1, 1):
                stream, entry = fixture(side, direction, True)
                row = M.project_stream(stream, entry, side, 4000)
                self.assertEqual(row["label"], "F" if direction == 1 else "A")
                self.assertEqual(row["points"], direction*130)
                self.assertEqual(row["net"], direction*13000-1077)
                self.assertEqual(row["net0"], direction*13000-77)
                self.assertEqual(row["exit_quote"]["time"], 101)
                self.assertEqual(row["label_known_at"], 3701)
                self.assertEqual(row["mark_basis"], "Bid" if side == 1 else "Ask")

    def test_complete_neither(self) -> None:
        """
        機能: 未到達completeは期限BBOで清算し旧net5を無視する。
        引数: self(FinanceTests)。
        返り値: None。
        """
        for side in (-1, 1):
            stream, entry = fixture(side, 0, True)
            row = M.project_stream(stream, entry, side, 4000)
            self.assertEqual((row["label"], row["known"], row["points"], row["net"]), ("N", True, 20, 923))
            self.assertEqual(row["exit_quote"], row["endpoint_quote"])
            self.assertIsNone(row["touch_quote"])

    def test_censored_touch(self) -> None:
        """
        機能: Cの早期touchは金融既知でも厳密先着F/Aへ算入しない。
        引数: self(FinanceTests)。
        返り値: None。
        """
        for side in (-1, 1):
            for direction in (-1, 1):
                stream, entry = fixture(side, direction, False)
                row = M.project_stream(stream, entry, side, 4000)
                self.assertEqual(row["label"], "C")
                self.assertTrue(row["known"])
                self.assertIsNone(row["label_known_at"])
                self.assertEqual(row["net"], direction*13000-1077)

    def test_censored_unknown(self) -> None:
        """
        機能: Cで未touchなら未知を0円へ補完しない。
        引数: self(FinanceTests)。
        返り値: None。
        """
        stream, entry = fixture(1, 0, False)
        row = M.project_stream(stream, entry, 1, 4000)
        self.assertEqual((row["label"], row["known"]), ("C", False))
        self.assertIsNone(row["net"])
        self.assertIsNone(row["mark"])

    def test_integrity(self) -> None:
        """
        機能: side・実取得価格・期限・タッチ幅の不整合を拒否する。
        引数: self(FinanceTests)。
        返り値: None。
        """
        stream, entry = fixture(1, 1, True)
        for variant in range(4):
            altered = copy.deepcopy(stream)
            if variant == 0:
                altered["birth"]["side"] = -1
            elif variant == 1:
                altered["entry_price"] = entry["last"]
            elif variant == 2:
                altered["outcomes"][0]["endpoint"]["time"] = 3699
            else:
                altered["outcomes"][0]["touches"][0]["quote"]["bid"] = 1110
            with self.assertRaises(AssertionError):
                M.project_stream(altered, entry, 1, 4000)

    def test_reader_crc(self) -> None:
        """
        機能: 同体逐次器が人工日本語gzipを全読了しCRC/解凍指紋を確認する。
        引数: self(FinanceTests)。
        返り値: None。
        """
        reader = M.load_reader()
        value = {"success": True, "scenes": [{"session": "人工", "中身": "括弧{}と引用\\\"と日本語"}], "末尾": 42}
        body = json.dumps(value, ensure_ascii=False).encode("utf-8")
        with TemporaryDirectory() as directory:
            path = Path(directory)/"人工.json.gz"
            path.write_bytes(gzip.compress(body, mtime=0))
            evidence = {}
            self.assertEqual(list(reader.scenes(path, evidence)), value["scenes"])
            self.assertEqual(evidence["decoded_sha256"], hashlib.sha256(body).hexdigest())
            self.assertEqual(evidence["header"]["末尾"], 42)
            broken = bytearray(path.read_bytes())
            broken[-5] ^= 1
            path.write_bytes(broken)
            with self.assertRaises((gzip.BadGzipFile, EOFError)):
                list(reader.scenes(path, {}))


if __name__ == "__main__":
    unittest.main(verbosity=2)
