"""F0後だけ旧148純観測を小型gzipへ固定する161金融運転器。"""
from collections import Counter
from pathlib import Path
import argparse
import gzip
import hashlib
import json

import outcomes161 as M

HERE = Path(__file__).resolve().parent
F0 = M.ROOT / "study/00161_三時間帯の入口を共通属性分割で比較する/条件.json"
F0_SHA256 = "f22d735cefd0146aa4ec691a5adeeaf82c6961e746e88d7cdfd52fbcc25b46b8"


# ----------------------------------------
def save(path: Path, value: object) -> None:
    """
    機能: 小型証跡を未作成のUTF-8 JSONへ保存する。
    引数: path(Path)、value(object)は保存先と内容。
    返り値: None。
    """
    with path.open("x", encoding="utf-8", newline="\n") as output:
        json.dump(value, output, ensure_ascii=False, indent=2, allow_nan=False)
        output.write("\n")


def main() -> None:
    """
    機能: F0と停止Sourceを検査して全観測を小表へ射影し証跡を保存する。
    引数: CLI --output-dir(Path)は未作成出力先。
    返り値: None。新規入口採否やモデルを読まず、31642物理case両側だけを出力する。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    assert M.sha(F0) == F0_SHA256
    stop_path = HERE/"金融部品の停止.json"
    stop = json.loads(stop_path.read_bytes())
    assert stop["成功"] and stop["編集停止"]
    sources = {HERE/name: digest for name, digest in stop["源"].items()}
    assert all(M.sha(path) == digest for path, digest in sources.items()) and M.sha(M.READER) == M.READER_SHA256
    target = args.output_dir
    assert not target.exists()
    target.mkdir(parents=True)
    evidence = {}
    outcomes = M.read_outcomes(evidence)
    assert all(M.sha(path) == digest for path, digest in sources.items()) and M.sha(F0) == F0_SHA256
    body = json.dumps(outcomes, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode("utf-8")
    path = target/"全caseの厳密先着とIFD.json.gz"
    with path.open("xb") as physical:
        with gzip.GzipFile(fileobj=physical, filename="", mode="wb", mtime=0) as output:
            output.write(body)
    summary = {}
    for side, name in ((1, "BUY"), (-1, "SELL")):
        rows = [case["original" if case["original_side"] == side else "reverse"] for case in outcomes.values()]
        counts = Counter(row["label"] for row in rows)
        known = [row["net"] for row in rows if row["known"]]
        summary[name] = {"case数": len(rows), "厳密ラベル": {key: counts[key] for key in "FANC"}, "金融既知": len(known), "金融未知": len(rows)-len(known), "利益円": sum(max(0, value) for value in known), "損失絶対円": -sum(min(0, value) for value in known), "既知差引円": sum(known), "Cでも金融既知": sum(row["label"] == "C" and row["known"] for row in rows)}
    evidence.update({"F0": {"path": str(F0.relative_to(M.ROOT)), "sha256": F0_SHA256}, "停止票SHA256": M.sha(stop_path), "源": {str(path): digest for path, digest in sources.items()}, "小表": {"path": path.name, "physical_bytes": path.stat().st_size, "sha256": M.sha(path), "decoded_bytes": len(body), "decoded_sha256": hashlib.sha256(body).hexdigest()}, "全母集団の検査用合計": summary})
    save(target/"入力と算式の確認.json", evidence)
    save(target/"完了.json", {"成功": True, "試行": 161, "全73場": True, "case数": len(outcomes), "純観測射影のみ": True, "新入口採否": False, "全CRCと物理解凍SHA一致": True, "小表SHA256": M.sha(path), "確認票SHA256": M.sha(target/"入力と算式の確認.json"), "全源前後一致": True})
    print(json.dumps({"成功": True, "case数": len(outcomes), "gzip_bytes": path.stat().st_size, "gzip_SHA256": M.sha(path), "確認票SHA256": M.sha(target/"入力と算式の確認.json"), "全母集団の検査用合計": summary}, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
