"""161用に旧148全観測を選択非依存の厳密先着/IFD小表へ射影する。"""
from pathlib import Path
import copy
import gzip
import hashlib
import importlib.util
import json
import math

ROOT = Path(__file__).resolve().parents[2]
OBSERVATIONS = ROOT / "study/00148_全1分知得から入口品質の母集団を固定する/成果物/固定取得の正逆観測.json.gz"
OBSERVATIONS_SHA256 = "bd809bdf24400628817afee702063504c65682e6748a60e0f32d7690b7363c61"
OBSERVATIONS_DECODED_SHA256 = "d1b4cab8a258203f04b5c1d081f57d10ed2a0c58ce4cc160ef571d5fac0ceffc"
FIXED = ROOT / "inputs/00148_全1分入口母集団/固定取得入力.json.gz"
FIXED_SHA256 = "99f10a996ca6e8b6c428061f1b48624bbc479ec84c500a9633818d47e4298e2a"
FIXED_DECODED_SHA256 = "12c43fe60e0ffd5ffa44bec7b5f7dd3d60bb92b291e0008db23587dcf19536d3"
READER = ROOT / "work/160時間帯診断/逐次読取.py"
READER_SHA256 = "2dd1e469ce8233cb757f2ba95b7f0a60e2bf163d7c59739462132d2ec8f17cac"
POINT_YEN, ROUND_TRIP_FEE, C5_ROUND_TRIP_SLIPPAGE = 100, 77, 1000


# ----------------------------------------
def sha(path: Path) -> str:
    """
    機能: 大きな入力も固定サイズずつ物理SHA256へ流す。
    引数: path(Path)は対象ファイル。
    返り値: strは小文字16進SHA256。
    """
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def stat_key(path: Path) -> tuple:
    """
    機能: 入力の同一物理ファイル・サイズ・更新時計を固定する。
    引数: path(Path)は入力パス。
    返り値: tupleはdev/ino/size/mtime_ns。
    """
    stat = path.stat()
    return tuple(getattr(stat, key) for key in ("st_dev", "st_ino", "st_size", "st_mtime_ns"))


def load_reader(path: Path = READER) -> object:
    """
    機能: 旧160の逐次JSON読取器を同体SHAで再用する。
    引数: path(Path)は正式160から復元可能な元Source又はその同体。
    返り値: objectはscenes/shaを持つmodule。自然入力は開かない。
    """
    assert sha(path) == READER_SHA256
    spec = importlib.util.spec_from_file_location("固定160逐次読取_161金融", path)
    reader = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(reader)
    assert sha(path) == READER_SHA256
    return reader


def checked_quote(quote: dict) -> None:
    """
    機能: 約定代用に用いる正常BBOと原行時計の型を検査する。
    引数: quote(dict)は旧観測の気配票。
    返り値: None。不正値はAssertionErrorで拒否する。
    """
    assert type(quote["time"]) in (int, float) and math.isfinite(quote["time"])
    assert type(quote["index"]) is int and quote["index"] >= 0
    assert type(quote["source_line"]) is int and quote["source_line"] > 0
    assert quote["quote_ok"] is True and all(type(quote[k]) in (int, float) and math.isfinite(quote[k]) for k in ("bid", "ask"))
    assert 0 < quote["bid"] < quote["ask"]


# ----------------------------------------
def project_stream(stream: dict, entry_quote: dict, expected_side: int, execution_end: float) -> dict:
    """
    機能: 厳密H60先着ラベルと実BBOのタッチ/期限IFD金額を独立に計算する。
    引数: stream(dict)、entry_quote(dict)、expected_side(int)、execution_end(float)は実側の旧観測とザラバ終端。
    返り値: dictはF/A/N/C、既知/未知、IFD金額、entryprice/mark/exit/endpoint等の独立検算材料。
    """
    checked_quote(entry_quote)
    assert expected_side in (-1, 1) and stream["status"] == "filled" and stream["axis"] == "BBO"
    side = stream["birth"]["side"]
    assert side == expected_side and stream["entry"] == entry_quote
    entry_price = entry_quote["ask" if side == 1 else "bid"]
    assert stream["entry_price"] == entry_price
    horizons = [row for row in stream["outcomes"] if row["seconds"] == 3600]
    assert len(horizons) == 1
    outcome = horizons[0]
    assert outcome["deadline"] == entry_quote["time"] + 3600
    touches = [row for row in outcome["touches"] if row["width"] == 125]
    assert len(touches) == 1
    touch = touches[0]
    direction = touch["direction"]
    assert type(direction) is int and direction in (-1, 0, 1) and (touch["quote"] is None) == (direction == 0)
    complete = outcome["status"] == "complete"
    endpoint = outcome["endpoint"]
    assert (endpoint is not None) == complete
    for quote, is_endpoint in ((touch["quote"], False), (endpoint, True)):
        if quote is None:
            continue
        checked_quote(quote)
        assert quote["index"] > entry_quote["index"] and quote["source_line"] > entry_quote["source_line"] and quote["time"] < execution_end
        if is_endpoint:
            assert outcome["deadline"] <= quote["time"] <= outcome["deadline"] + 30
        else:
            assert entry_quote["time"] <= quote["time"] <= outcome["deadline"]
            movement = side * (quote["bid" if side == 1 else "ask"] - entry_price)
            assert movement >= 125-1e-9 if direction == 1 else movement <= -125+1e-9
    label = "C" if not complete else "F" if direction == 1 else "A" if direction == -1 else "N"
    exit_quote = touch["quote"] if direction else endpoint if complete else None
    known = exit_quote is not None
    mark = exit_quote["bid" if side == 1 else "ask"] if known else None
    points = side * (mark - entry_price) if known else None
    return {"label": label, "complete": complete, "status": outcome["status"], "direction": direction, "deadline": outcome["deadline"], "label_known_at": endpoint["time"] if complete else None, "side": side, "entry_price": entry_price, "mark_basis": "Bid" if side == 1 else "Ask", "mark": mark, "known": known, "reason": "順行到達" if direction == 1 else "逆行到達" if direction == -1 else "期限清算" if complete else "観測不足", "points": points, "net": points*POINT_YEN-ROUND_TRIP_FEE-C5_ROUND_TRIP_SLIPPAGE if known else None, "net0": points*POINT_YEN-ROUND_TRIP_FEE if known else None, "exit_quote": copy.deepcopy(exit_quote), "touch_quote": copy.deepcopy(touch["quote"]), "endpoint_quote": copy.deepcopy(endpoint)}


def project_case(case: dict, entry: dict, session: str, execution_end: float) -> dict:
    """
    機能: 同じ物理取得の元側と実逆側をそれぞれBBOで射影する。
    引数: case/entry(dict)、session(str)、execution_end(float)は旧caseと固定取得と場時計。
    返り値: dictはcaseの識別と両側独立ラベル/IFD。逆側を1-pから作らない。
    """
    assert case["id"] == entry["id"] and case["original_side"] == entry["side"]
    side = entry["side"]
    quote = entry["entry"]
    return {"session": session, "entry_quote": copy.deepcopy(quote), "original_side": side, "execution_end": execution_end, "original": project_stream(case["original"], quote, side, execution_end), "reverse": project_stream(case["reverse"], quote, -side, execution_end)}


# ----------------------------------------
def read_outcomes(evidence: dict | None = None, reader_path: Path = READER) -> dict[str, dict]:
    """
    機能: 正式148の全73場を逐次完読し全31,642case両側の純小表を返す。
    引数: evidence(dict又はNone)は入力/読取証跡の受け取り先、reader_path(Path)は指紋固定逐次器。
    返り値: dict[str,dict]はcase_idをキーとする純データ。q0採否・モデル・新規選択は受け取らない。
    """
    reader = load_reader(reader_path)
    before_fixed, before_observed = stat_key(FIXED), stat_key(OBSERVATIONS)
    assert sha(FIXED) == FIXED_SHA256 and sha(OBSERVATIONS) == OBSERVATIONS_SHA256
    with gzip.open(FIXED, "rb") as source:
        body = source.read()
    assert hashlib.sha256(body).hexdigest() == FIXED_DECODED_SHA256
    fixed = json.loads(body)
    assert fixed["expected_entry_count"] == 31642 and len(fixed["scenes"]) == 73
    assert fixed["scenes"][0]["session"] == "2026-09-21_Day" and fixed["scenes"][-1]["session"] == "2026-11-10_Day"
    outcomes, decoded, sessions = {}, {}, []
    for index, observed in enumerate(reader.scenes(OBSERVATIONS, decoded)):
        assert index < len(fixed["scenes"])
        scene = fixed["scenes"][index]
        assert observed["success"] and observed["session"] == scene["session"]
        assert observed["actual_sha256"] == scene["raw"]["sha256"] and observed["quality"] == observed["expected_quality"] == scene["expected_quality"] and observed["stat_before"] == observed["stat_after"]
        execution_end = scene["end"]-300
        limit = min(scene["force_close"], scene["end"]-3900)
        assert observed["execution_end"] == execution_end and observed["effective_entry_limit"] == limit
        entries = {row["id"]: row for row in scene["entries"]}
        assert len(entries) == len(scene["entries"]) == len(observed["cases"])
        found = set()
        for case in observed["cases"]:
            key = case["id"]
            assert key not in outcomes and key in entries and key not in found
            entry = entries[key]
            assert scene["start"] <= entry["entry"]["time"] < limit
            outcomes[key] = project_case(case, entry, scene["session"], execution_end)
            found.add(key)
        assert found == set(entries)
        sessions.append(scene["session"])
    header = decoded["header"]
    assert header["success"] and header["trial"] == 133 and header["input_sha256"] == FIXED_DECODED_SHA256 and header["source_entry_count"] == 31642
    assert len(sessions) == 73 and len(outcomes) == 31642 and decoded["decoded_sha256"] == OBSERVATIONS_DECODED_SHA256
    assert stat_key(FIXED) == before_fixed and stat_key(OBSERVATIONS) == before_observed
    assert sha(FIXED) == FIXED_SHA256 and sha(OBSERVATIONS) == OBSERVATIONS_SHA256 and sha(reader_path) == READER_SHA256
    if evidence is not None:
        evidence.update({"成功": True, "試行": 161, "全73場": sessions, "case数": len(outcomes), "実側数": len(outcomes)*2, "選択結果の読取": False, "自然新規選択": False, "費用": {"1枚pt円": POINT_YEN, "往復手数料円": ROUND_TRIP_FEE, "C5往復追加滑り円": C5_ROUND_TRIP_SLIPPAGE}, "固定入力": {"path": str(FIXED.relative_to(ROOT)), "sha256": FIXED_SHA256, "decoded_sha256": FIXED_DECODED_SHA256, "physical_bytes": before_fixed[2], "decoded_bytes": len(body), "全CRC確認": True, "stat_before": list(before_fixed), "stat_after": list(stat_key(FIXED))}, "正逆観測": {"path": str(OBSERVATIONS.relative_to(ROOT)), "sha256": OBSERVATIONS_SHA256, "decoded_sha256": decoded["decoded_sha256"], "physical_bytes": before_observed[2], "decoded_bytes": decoded["decoded_bytes"], "全CRC確認": True, "stat_before": list(before_observed), "stat_after": list(stat_key(OBSERVATIONS))}, "逐次器": {"path": str(reader_path), "sha256": READER_SHA256, "版": "160の停止済み一場JSON逐次器を同体再用"}, "式": "IFD=実125touchがあれば最初touchの実Bid/Ask、なければcomplete endpoint。side*(mark-entry_price)*100-77-1000。旧outcome.net5は使用しない。", "時計": "F/A/Nは厳密H60completeのみ。Cでも早期touchのIFD既知を許す。label_known_atはcomplete endpoint。"})
    return outcomes
