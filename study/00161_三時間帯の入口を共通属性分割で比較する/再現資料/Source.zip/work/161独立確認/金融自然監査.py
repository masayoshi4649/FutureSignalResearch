"""別逐次JSON実装で全148観測を再読し、161の金融小表と四表を検算する。"""
from collections import Counter
from pathlib import Path
import gzip
import hashlib
import importlib.util
import json
import math

import ijson

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
TRIAL = ROOT / 'study/00161_三時間帯の入口を共通属性分割で比較する'
BOOK_SHA = 'f22d735cefd0146aa4ec691a5adeeaf82c6961e746e88d7cdfd52fbcc25b46b8'
FINANCE = ROOT / 'work/161三時間帯入口の金融/自然射影/全caseの厳密先着とIFD.json.gz'
FINANCE_SHA = '9da5230477948fd863936595d52cb25db0687b38ff27fa2fdc74b72002e8cf9c'


def SHA(path: Path) -> str:
    """
    機能: 全物理bytesをSHA256へ流す。
    引数: path (Path) 対象。
    返り値: str 型のSHA256。
    """
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


# ----------------------------------------
def JSON(path: Path) -> dict:
    """
    機能: 小さいJSON又はgzipを完読する。
    引数: path (Path) 入力。
    返り値: dict 型の解析値。
    """
    with (gzip.open(path, 'rt', encoding='utf-8') if path.suffix == '.gz' else path.open(encoding='utf-8')) as source:
        return json.load(source)


# ----------------------------------------
class 解凍署名読取器:
    """ijsonの独立パーサへ渡しながら、解凍全bytesの指紋を残す。"""

    def __init__(self, source: object):
        """
        機能: バイナリ入力と解凍署名を初期化する。
        引数: source (object) gzipバイナリ読取器。
        返り値: None。
        """
        self.source = source
        self.digest = hashlib.sha256()
        self.size = 0

    def read(self, size: int = -1) -> bytes:
        """
        機能: 読取った解凍bytesへ署名する。
        引数: size (int) 最大bytes。
        返り値: bytes 型のデータ。
        """
        value = self.source.read(size)
        self.digest.update(value)
        self.size += len(value)
        return value

    def readinto(self, buffer: bytearray) -> int:
        """
        機能: ijsonのバイナリ読取APIへ署名付きデータを供給する。
        引数: buffer (bytearray) 出力領域。
        返り値: int 型の読取bytes数。
        """
        value = self.read(len(buffer))
        buffer[:len(value)] = value
        return len(value)


# ----------------------------------------
def 気配検査(q: dict, entry: dict, execution_end: float, deadline: float, endpoint: bool) -> None:
    """
    機能: 正常BBOと、entry以後の原行・ザラバ・H60時計を別算で確認する。
    引数: q/entry (dict) 気配、execution_end/deadline (float) 上限、endpoint (bool) 期限票か。
    返り値: None。不一致はAssertionError。
    """
    assert q['quote_ok'] is True and 0 < q['bid'] < q['ask']
    assert all(math.isfinite(q[k]) for k in ('time', 'bid', 'ask'))
    assert q['index'] > entry['index'] and q['source_line'] > entry['source_line'] and q['time'] < execution_end
    assert (deadline <= q['time'] <= deadline + 30) if endpoint else (entry['time'] <= q['time'] <= deadline)


# ----------------------------------------
def 実側別算(stream: dict, entry: dict, side: int, execution_end: float) -> dict:
    """
    機能: 元観測からstrictラベル・IFD出口・実Bid/Ask金額を独立再構成する。
    引数: stream/entry (dict) 元観測と取得、side (int) 実売買側、execution_end (float) ザラバ終端。
    返り値: dict 型の小表全値。旧net5は使用しない。
    """
    assert stream['status'] == 'filled' and stream['axis'] == 'BBO' and stream['birth']['side'] == side
    assert stream['entry'] == entry and entry['quote_ok'] is True and 0 < entry['bid'] < entry['ask']
    price = entry['ask'] if side > 0 else entry['bid']
    assert stream['entry_price'] == price
    h = [r for r in stream['outcomes'] if r['seconds'] == 3600]
    assert len(h) == 1
    h = h[0]
    deadline = entry['time'] + 3600
    assert h['deadline'] == deadline
    t = [r for r in h['touches'] if r['width'] == 125]
    assert len(t) == 1
    direction, touch = t[0]['direction'], t[0]['quote']
    assert type(direction) is int and direction in (-1, 0, 1)
    assert (touch is None) == (direction == 0)
    endpoint = h['endpoint']
    complete = h['status'] == 'complete'
    assert complete == (endpoint is not None)
    if touch is not None:
        気配検査(touch, entry, execution_end, deadline, False)
        p = side * ((touch['bid'] if side > 0 else touch['ask']) - price)
        assert (p >= 125 - 1e-9) if direction > 0 else (p <= -125 + 1e-9)
    if endpoint is not None: 気配検査(endpoint, entry, execution_end, deadline, True)
    label = {-1: 'A', 0: 'N', 1: 'F'}[direction] if complete else 'C'
    exit_quote = touch or endpoint
    known = exit_quote is not None
    mark = (exit_quote['bid'] if side > 0 else exit_quote['ask']) if known else None
    points = side * (mark - price) if known else None
    return {'label': label, 'complete': complete, 'status': h['status'], 'direction': direction,
            'deadline': deadline, 'label_known_at': endpoint['time'] if endpoint else None,
            'side': side, 'entry_price': price, 'mark_basis': 'Bid' if side > 0 else 'Ask',
            'mark': mark, 'known': known,
            'reason': '順行到達' if direction > 0 else '逆行到達' if direction < 0 else '期限清算' if complete else '観測不足',
            'points': points, 'net': points * 100 - 1077 if known else None,
            'net0': points * 100 - 77 if known else None,
            'exit_quote': exit_quote, 'touch_quote': touch, 'endpoint_quote': endpoint}


# ----------------------------------------
def 統計(rows: list[dict], eligible: list[str], hours: float) -> dict:
    """
    機能: 到達・未知・独立実現利益/損失・参加を別ループで集計する。
    引数: rows (list[dict]) 会員行、eligible (list[str]) 分母場、hours (float) 分母時間。
    返り値: dict 型の統計欄。
    """
    labels = Counter(r['label'] for r in rows)
    scenes = Counter(r['session'] for r in rows)
    nets = [r['net'] for r in rows if r['known']]
    profit = sum(n for n in nets if n > 0)
    loss = sum(-n for n in nets if n < 0)
    f, a, n, c = (labels[k] for k in ('F', 'A', 'N', 'C'))
    return {'取得': len(rows), '順': f, '逆': a, '未到達': n, '観測不足': c,
            '到達済み先着率': f / (f + a) if f + a else None,
            '完了分母順行率': f / (f + a + n) if f + a + n else None,
            '全取得分母順行率': f / len(rows) if rows else None,
            '対象場': len(eligible), '取得場': len(scenes), '未取得場': len(eligible) - len(scenes),
            '全場最低1': bool(eligible) and set(eligible).issubset(scenes), '対象時間': hours,
            '取得毎時': len(rows) / hours if hours else None,
            '利益総額': profit, '損失総額': loss, '既知差引': sum(nets), 'PF': profit / loss if loss else None,
            '金融既知': len(nets), '金融未知': len(rows) - len(nets),
            '新枝取得': sum(r['source_kind'] != '旧C1固定参照' for r in rows),
            '旧C1取得': sum(r['source_kind'] == '旧C1固定参照' for r in rows),
            '最大場集中率': max(scenes.values(), default=0) / len(rows) if rows else None}


# ----------------------------------------
def セル照合(expected: object, actual: object) -> None:
    """
    機能: 型付き値を比較し、浮動小数の算術順序誤差だけを許容する。
    引数: expected/actual (object) 値。
    返り値: None。不一致はAssertionError。
    """
    if type(expected) is float and type(actual) in (float, int):
        assert math.isclose(expected, actual, rel_tol=1e-12, abs_tol=1e-8), (expected, actual)
    else:
        assert type(expected) is type(actual) and expected == actual, (expected, actual)


# ----------------------------------------
def 主処理() -> dict:
    """
    機能: 元148全73場をijsonで再読し金融小表とRoot四表を全検算する。
    引数: なし。Root金融集計完了後の固定成果物を使用する。
    返り値: dict 型の読取・検算・全セル照合記録。
    """
    assert SHA(TRIAL / '条件.json') == BOOK_SHA and SHA(FINANCE) == FINANCE_SHA
    book = JSON(TRIAL / '条件.json')
    before = JSON(TRIAL / '検査/F2_金融集計前.json')['入力とSource']
    for path, digest in before.items(): assert SHA(ROOT / path) == digest
    formal_obs = ROOT / book['inputs']['observations']['path']
    formal_fixed = ROOT / book['inputs']['fixed']['path']
    assert SHA(formal_obs) == book['inputs']['observations']['sha256']
    assert SHA(formal_fixed) == book['inputs']['fixed']['sha256']
    fixed = JSON(formal_fixed)
    compact = JSON(FINANCE)
    expected = {}
    counters = Counter()
    with gzip.open(formal_obs, 'rb') as source:
        hashed = 解凍署名読取器(source)
        for i, observed in enumerate(ijson.items(hashed, 'scenes.item', use_float=True)):
            scene = fixed['scenes'][i]
            assert observed['session'] == scene['session'] and observed['success'] is True
            assert observed['actual_sha256'] == scene['raw']['sha256']
            assert observed['quality'] == observed['expected_quality'] == scene['expected_quality']
            assert observed['stat_before'] == observed['stat_after']
            entries = {r['id']: r for r in scene['entries']}
            assert len(observed['cases']) == len(entries)
            for case in observed['cases']:
                cid = case['id']
                assert cid not in expected
                entry = entries.pop(cid)
                quote, side = entry['entry'], entry['side']
                assert case['original_side'] == side
                end = scene['end'] - 300
                record = {'session': scene['session'], 'entry_quote': quote, 'original_side': side, 'execution_end': end,
                          'original': 実側別算(case['original'], quote, side, end),
                          'reverse': 実側別算(case['reverse'], quote, -side, end)}
                assert record == compact[cid], cid
                expected[cid] = record
                counters['全case金融原始値'] += 1
                counters['全実側IFD'] += 2
            assert not entries
            counters['元148観測の場'] += 1
            if (i + 1) % 10 == 0: print(json.dumps({'金融元観測監査場': i + 1, 'case': len(expected)}, ensure_ascii=False), flush=True)
        assert not hashed.read()
        decoded_sha, decoded_bytes = hashed.digest.hexdigest(), hashed.size
    assert decoded_sha == book['inputs']['observations']['decoded_sha256']
    assert len(expected) == len(compact) == 31642 and counters['元148観測の場'] == 73
    assert SHA(formal_obs) == book['inputs']['observations']['sha256']
    selected = JSON(ROOT / 'work/161三時間帯入口/選択/選択対応.json.gz')
    small = JSON(TRIAL / '成果物/入口とIFDの小型正本.json.gz')
    tables = JSON(TRIAL / '成果物/型付き四表.json')['tables']
    audits = JSON(ROOT / 'work/161三時間帯入口/自然学習/場別モデルと教師.json.gz')['rows']
    feature_meta = JSON(ROOT / 'work/151過去場判別の評価/入口選択/cache/feature_only/features_meta.json')
    scenes = {r['session']: r for r in feature_meta['scenes']}
    sessions = list(selected['全73場'])
    spec = importlib.util.spec_from_file_location('audit161_finance_pure', HERE / '独立純計算.py')
    oracle = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(oracle)
    memberships = []
    all_stats, band_stats, scene_stats, model_stats = [], [], [], []
    for policy in book['policies']:
        rows = []
        for member in selected['政策'][policy]:
            case = expected[member['case_id']]
            result = case[member['stream']]
            assert result['side'] == member['side']
            q = case['entry_quote']
            band = oracle.q0時帯(member['session'], int(q['time']))
            row = {'policy': policy, 'case_id': member['case_id'], 'session': member['session'], 'side': member['side'],
                   'stream': member['stream'], 'event_id': member['event_id'], 'source_kind': member['source_kind'],
                   'q0_timeband': member.get('q0_timeband'), 'q1_timeband': band, 'q1_time': q['time'],
                   'label': result['label'], 'known': result['known'], 'net': result['net'], 'entry_price': result['entry_price'],
                   'mark': result['mark'], 'points': result['points'], 'exit_quote': result['exit_quote'], 'reason': result['reason']}
            rows.append(row)
        memberships.extend(rows)
        for period, eligible in (('全期', sessions), ('前48場', sessions[:48]), ('後25場', sessions[48:])):
            subset = [r for r in rows if r['session'] in eligible]
            hours = sum(scenes[s]['end'] - 300 - scenes[s]['start'] for s in eligible) / 3600
            all_stats.append({'政策': policy, '期間': period, '取得帯': '全体', **統計(subset, eligible, hours)})
            for band, name in enumerate(('デイ', '米国前', '米国後')):
                es = [s for s in eligible if s.endswith('_Day') == (band == 0)]
                seconds = 0
                for s in es:
                    start, end = scenes[s]['start'], scenes[s]['end'] - 300
                    if band:
                        boundary = oracle.米国開始UTC(s.split('_')[0])
                        start, end = (start, min(end, boundary)) if band == 1 else (max(start, boundary), end)
                    seconds += max(0, end - start)
                band_stats.append({'政策': policy, '期間': period, '取得帯': name,
                                   **統計([r for r in subset if r['q1_timeband'] == band], es, seconds / 3600)})
        cumulative = 0
        for s in sessions:
            stats = 統計([r for r in rows if r['session'] == s], [s], (scenes[s]['end'] - 300 - scenes[s]['start']) / 3600)
            cumulative += stats['既知差引']
            scene_stats.append({'政策': policy, 'セッション': s, **stats, '既知累計収支': cumulative})
    assert memberships == small['政策']
    for audit in audits:
        entries = [('COMMON', '全帯', audit['models']['COMMON']), ('CONTEXT', '全帯', audit['models']['CONTEXT'])]
        entries.extend(('SPLIT', ('デイ', '米国前', '米国後')[int(b)], a) for b, a in audit['models']['SPLIT'].items())
        for mode, band, r in entries:
            model_stats.append({'セッション': audit['session'], '方式': mode, '判断帯': band, '学習可': r['ready'],
                                '不足理由': '/'.join(r['ready_reasons']), '物理pair': r['physical_pair_count'],
                                '寄与場': len(r['contributing_sessions']), '時区画': r['active_block_count'],
                                '最終成熟時計': r['max_label_known_at'],
                                '学習配列SHA256': r['model']['training_array_sha256'] if r['model'] else None,
                                '構造SHA256': r['model']['structure_sha256'] if r['model'] else None})
    for name, records in (('比較一覧', all_stats), ('時間帯別', band_stats), ('全セッション', scene_stats), ('モデル支持', model_stats)):
        t = tables[name]
        assert len(t['rows']) == len(records)
        for expected_row, actual_row in zip(records, t['rows']):
            assert len(actual_row) == len(t['headers'])
            for key, actual in zip(t['headers'], actual_row):
                セル照合(expected_row[key], actual)
                counters['四表全セル'] += 1
                if type(actual) in (int, float): counters['四表数値セル'] += 1
            counters[name + '行'] += 1
    for path, digest in before.items(): assert SHA(ROOT / path) == digest
    return {'成功': True, '試行': 161, '元観測逐次解析': 'ijson ' + ijson.__version__,
            '元148解凍SHA256': decoded_sha, '元148解凍bytes': decoded_bytes, '全CRC確認': True,
            '検査件数': dict(counters), '金融小表SHA256': FINANCE_SHA, '条件SHA256': BOOK_SHA,
            'F2入力とSource': before, '監査SourceSHA256': {p.name: SHA(p) for p in (Path(__file__), HERE / '独立純計算.py')}}


# ----------------------------------------
if __name__ == '__main__':
    result = 主処理()
    (HERE / '金融自然監査結果.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '検査件数': result['検査件数']}, ensure_ascii=False), flush=True)
