"""161の自然結果に依存しない、時帯・支持・確率判断の独立オラクル。"""
from collections import Counter
from datetime import date, datetime, timezone
from fractions import Fraction
import calendar
import math


def 既知有限(値: object) -> bool:
    """
    機能: None・NaN・無限大を既知数値から除く。
    引数: 値 (object) 数値又はNone。
    返り値: bool 型の既知かつ有限という判定。
    """
    return 値 is not None and math.isfinite(float(値))


# ----------------------------------------
def 米国開始UTC(夜間開始日: str) -> int:
    """
    機能: 2007年以降の米国夏時間則を暦算で独立に適用しNY09:30を返す。
    引数: 夜間開始日 (str) YYYY-MM-DD形式の夜間開始日。
    返り値: int 型のUTC Unix秒。IANA実装とは独立の検算用である。
    """
    d = date.fromisoformat(夜間開始日)
    assert d.year >= 2007
    march_sundays = [w[calendar.SUNDAY] for w in calendar.monthcalendar(d.year, 3) if w[calendar.SUNDAY]]
    november_sundays = [w[calendar.SUNDAY] for w in calendar.monthcalendar(d.year, 11) if w[calendar.SUNDAY]]
    summer = date(d.year, 3, march_sundays[1]) <= d < date(d.year, 11, november_sundays[0])
    return int(datetime(d.year, d.month, d.day, 13 if summer else 14, 30, tzinfo=timezone.utc).timestamp())


# ----------------------------------------
def q0時帯(セッション: str, 時刻: int) -> int:
    """
    機能: q0時刻からデイ0・米国前1・米国後2を独立判定する。
    引数: セッション (str) YYYY-MM-DD_Day又はNight、時刻 (int) UTC Unix秒。
    返り値: int 型の時帯。米国開始との等号は米国後へ含める。
    """
    d, kind = セッション.split('_')
    assert kind in ('Day', 'Night') and type(時刻) is int
    return 0 if kind == 'Day' else (1 if 時刻 < 米国開始UTC(d) else 2)


# ----------------------------------------
def 帯内重み(正準pair: list[dict], 時帯対応: dict[int, int], 帯: int) -> dict:
    """
    機能: 正準済み物理教師を帯へ限定し、有理数で重みと支持を計算する。
    引数: 正準pair (list[dict]) 共通選択済みpair、時帯対応 (dict[int,int]) source_index別時帯、帯 (int)。
    返り値: dict 型の支持・区画・有理数重み。母集団正準化を帯内でやり直さない。
    """
    assert type(帯) is int and 帯 in (0, 1, 2)
    pairs = [p for p in 正準pair if 時帯対応[p['source_index']] == 帯]
    assert len({p['source_index'] for p in pairs}) == len(pairs)
    blocks = Counter((p['session_index'], p['block_index']) for p in pairs)
    count, active = len(pairs), len(blocks)
    scenes = sorted({p['session_index'] for p in pairs})
    classes = sorted({y for p in pairs for y in (p['label_buy'], p['label_sell'])})
    weights = {p['source_index']: Fraction(count, active * blocks[p['session_index'], p['block_index']]) for p in pairs}
    reasons = []
    if count < 1000:
        reasons.append('physical_pairs_under_1000')
    if len(scenes) < 8:
        reasons.append('contributing_sessions_under_8')
    if classes != [-1, 0, 1]:
        reasons.append('three_classes_not_present')
    assert not count or sum(weights.values()) == count
    return {'indices': [p['source_index'] for p in pairs], 'weights': weights,
            'physical_pair_count': count, 'contributing_sessions': scenes,
            'classes': classes, 'active_block_count': active,
            'ready': not reasons, 'ready_reasons': reasons}


# ----------------------------------------
def 優勢側判断(買い: list, 売り: list, 買い確率: list | None, 売り確率: list | None,
            列: list[dict], 実分岐列: list[int], 閾値: dict[str, float]) -> dict:
    """
    機能: モデル確率から先に優勢側を選び、品質・既知技術役割・閾値を別算する。
    引数: 買い/売り (list) 実側100特徴、買い確率/売り確率 (list|None) A/N/F、
          列 (list[dict]) 元100列、実分岐列 (list[int]) 属性を含みうる列、閾値 (dict[str,float])。
    返り値: dict 型の方向・優勢側・役割・理由・条件付き確率。
    """
    result = {'directions': dict.fromkeys(閾値, 0), 'selected_side': 0, 'known_roles': [], 'reason': 'untrained'}
    if 買い確率 is None or 売り確率 is None:
        assert 買い確率 is None and 売り確率 is None
        return result
    scores = [p[2] - p[0] for p in (買い確率, 売り確率)]
    delta = scores[0] - scores[1]
    if abs(delta) < 0.05:
        result['reason'] = 'score_margin_under_0.05'
        return result
    side = 1 if delta >= 0.05 else -1
    x, p = (買い, 買い確率) if side == 1 else (売り, 売り確率)
    result['selected_side'] = side
    byname = {c['name']: i for i, c in enumerate(列)}
    spread, gap = (x[byname[n]] for n in ('q0_spread_points', 'q0_last_minus_m1_close_atr5_to_side'))
    if not 既知有限(spread) or not 既知有限(gap) or not (0 < spread <= 20 and -1 <= gap <= 1):
        result['reason'] = 'q0_common_not_met'
        return result
    excluded = {'q0_spread_points', 'q0_spread_125_ratio', 'q0_entry_minus_last_atr5_to_side'}
    roles = sorted({列[i]['role'] for i in 実分岐列 if 0 <= i < 100 and 列[i]['name'] not in excluded and 既知有限(x[i])})
    result['known_roles'] = roles
    if len(roles) < 2:
        result['reason'] = 'known_technical_roles_under_2'
        return result
    conditional = p[2] / (p[0] + p[2]) if p[0] + p[2] else None
    result['conditional_forward'] = conditional
    if p[2] < 0.4:
        result['reason'] = 'forward_probability_under_0.40'
        return result
    result['reason'] = 'threshold_wait'
    for name, limit in 閾値.items():
        if conditional is not None and conditional >= limit:
            result['directions'][name] = side
            result['reason'] = 'selected'
    return result


# ----------------------------------------
def 初参加補完(セッション: list[str], 新規取得: list[dict], 旧信号: list[dict]) -> list[dict]:
    """
    機能: 各場最初の本物C1出生までの新規実取得だけで、固定初参加補完を決める。
    引数: セッション (list[str]) 全対象場、 新規取得 (list[dict]) session/entry_key/q0_key/case_id、
          旧信号 (list[dict]) session/birth_key/case_id。Quote keyはtime/index/line、出生は末尾idを持つ。
    返り値: list[dict] 型の補完判断。先着・利益・将来価格を受け取らない。
    """
    result = []
    assert len(set(セッション)) == len(セッション)
    for session in セッション:
        candidates = [s for s in 旧信号 if s['session'] == session]
        assert candidates, ('旧固定信号のない場', session)
        assert all(len(s['birth_key']) == 4 for s in candidates)
        first = min(candidates, key=lambda s: tuple(s['birth_key']))
        birth_quote = tuple(first['birth_key'][:3])
        observed = []
        for entry in 新規取得:
            if entry['session'] != session:
                continue
            assert len(entry['entry_key']) == len(entry['q0_key']) == 3
            assert tuple(entry['q0_key']) < tuple(entry['entry_key'])
            if tuple(entry['entry_key']) <= birth_quote:
                observed.append(entry['case_id'])
        result.append({'session': session, 'first_c1_case': first['case_id'],
                       'birth_key': list(first['birth_key']), 'n_acquired_by_birth': len(set(observed)),
                       'fallback_case': first['case_id'] if not observed else None})
    return result


# ----------------------------------------
def 複合回復A0(元方向: int, 買い: list, 売り: list, 列: list[dict]) -> dict:
    """
    機能: 152のG内だけ実側回復を再確認するA0を、独立した三値判定で算出する。
    引数: 元方向 (int) -1/0/1、買い/売り (list) 100特徴、列 (list[dict]) 列定義。
    返り値: dict 型のside/reason/G。CHASE条件を持つB0は対象外である。
    """
    if 元方向 == 0:
        return {'side': 0, 'reason': 'source_wait', 'G': None}
    indices = {c['name']: i for i, c in enumerate(列)}
    vectors = {1: 買い, -1: 売り}
    gnames = ('m30_ema21_delta_to_side', 'm30_di_difference_to_side', 'm15_di_difference_to_side', 'm15_adx')
    g = [vectors[元方向][indices[n]] for n in gnames]
    if not all(既知有限(v) for v in g):
        return {'side': 0, 'reason': 'background_unknown', 'G': None}
    strong = bool(max(g[:3]) < 0 and g[3] > 25)
    if not strong:
        return {'side': 元方向, 'reason': 'outside_strong_opposition', 'G': False}
    recovered = {}
    names = ('m1_body_ratio_to_side', 'm1_body_reclaim_atr5_to_side',
             'q0_last_minus_m1_close_atr5_to_side', 'm5_hist_delta_to_side',
             'm5_rsi_delta_to_side', 'm1_volume_relative_prior3')
    for side in (1, -1):
        v = [vectors[side][indices[n]] for n in names]
        recovered[side] = bool(v[0] > 0 and v[1] + v[2] > 0 and v[3] > 0 and v[4] > 0 and v[5] >= 1) if all(既知有限(x) for x in v) else None
    same, opposite = recovered[元方向], recovered[-元方向]
    if same is None or opposite is None:
        return {'side': 0, 'reason': 'recovery_unknown', 'G': True}
    if same and opposite:
        return {'side': 0, 'reason': 'recovery_conflict', 'G': True}
    if same:
        return {'side': 元方向, 'reason': 'countertrend_recovery_confirmed', 'G': True}
    if opposite:
        return {'side': -元方向, 'reason': 'background_direction_recovery_confirmed', 'G': True}
    return {'side': 0, 'reason': 'neither_recovery', 'G': True}
