"""保存161モデルと全q0を、学習を行わない別実装で監査する。"""
from collections import Counter
from fractions import Fraction
from pathlib import Path
import gzip
import hashlib
import importlib.util
import json
import math
import sys

import numpy as np
from catboost import CatBoostClassifier, Pool

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
TRIAL = ROOT / 'study/00161_三時間帯の入口を共通属性分割で比較する'
OUT = ROOT / 'work/161三時間帯入口/自然学習'
CACHE = ROOT / 'work/151過去場判別の評価/入口選択/cache'
BOOK_SHA = 'f22d735cefd0146aa4ec691a5adeeaf82c6961e746e88d7cdfd52fbcc25b46b8'
CACHE_SHA = {
    'feature_only/features.npz': '5b309e0821403fcf1b122956fc6c9fe20ec5dfbe4327d7d674193b8e58f99b44',
    'feature_only/features_meta.json': '71df54db57a3093eb4de2f5ce26c654c758f9181e07f61660cb1a192f6fa4602',
    'teacher_only/teachers.npz': 'ec613a27461c32d1aa09aed4ecf3b013c2d7dc827d86ba642385698547f22689',
    'teacher_only/teachers_meta.json': '3b723ca78d5ddc8ab4f301d5f9ba18ee08bea4e0159a085558296f824d736106',
}


def SHA(場所: Path) -> str:
    """
    機能: ファイルの物理指紋を独立に計算する。
    引数: 場所 (Path) 読取対象。
    返り値: str 型のSHA256。
    """
    with 場所.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


# ----------------------------------------
def JSON読取(場所: Path) -> dict:
    """
    機能: UTF-8 JSON又はgzipを最後まで読み込む。
    引数: 場所 (Path) 正式又は固定作業入力。
    返り値: dict 型の値。gzipは全CRCを検査する。
    """
    with (gzip.open(場所, 'rt', encoding='utf-8') if 場所.suffix == '.gz' else 場所.open(encoding='utf-8')) as source:
        return json.load(source)


# ----------------------------------------
def 独立部品() -> object:
    """
    機能: 同じ監査領域の純計算オラクルだけを読込む。
    引数: なし。
    返り値: object 型の独立部品。
    """
    spec = importlib.util.spec_from_file_location('audit161_natural_pure', HERE / '独立純計算.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# ----------------------------------------
def 期待教師(rows: list[dict], starts: list[int], current: int, bands: list[int], band: int | None) -> dict:
    """
    機能: 窓・厳密成熟・全体正準化・帯内重みを別ループで組み立てる。
    引数: rows (list[dict]) 固定教師、starts (list[int]) 開始、current (int) 当場、bands (list[int])、band (int|None)。
    返り値: dict 型の正準pair・支持・重み・入力指紋用情報。
    """
    candidates = []
    for index, row in enumerate(rows):
        if not max(0, current - 20) <= row['session_index'] < current:
            continue
        known = row['known_at']
        if row['pair_complete'] is not True or known is None or not math.isfinite(known) or known >= starts[current]:
            continue
        if any(type(row[k]) is not int or row[k] not in (-1, 0, 1) for k in ('label_buy', 'label_sell')):
            continue
        candidates.append((index, row))
    candidates.sort(key=lambda item: (item[1]['session_index'], item[1]['q0_index'], item[1]['q0_line'], item[1]['event_id']))
    seen = set()
    selected = []
    for index, row in candidates:
        if row['case_id'] in seen:
            continue
        seen.add(row['case_id'])
        if band is None or bands[index] == band:
            selected.append((index, row))
    blocks = Counter((r['session_index'], math.floor((r['q0_time'] - starts[r['session_index']]) / 3600)) for _, r in selected)
    count, active = len(selected), len(blocks)
    classes = sorted({v for _, r in selected for v in (r['label_buy'], r['label_sell'])})
    scenes = sorted({r['session_index'] for _, r in selected})
    reasons = []
    if count < 1000: reasons.append('physical_pairs_under_1000')
    if len(scenes) < 8: reasons.append('contributing_sessions_under_8')
    if classes != [-1, 0, 1]: reasons.append('three_classes_not_present')
    weights = []
    for _, row in selected:
        key = (row['session_index'], math.floor((row['q0_time'] - starts[row['session_index']]) / 3600))
        weights.append(float(Fraction(count, active * blocks[key])))
    canonical = [(index, r['case_id'], r['event_id'], r['known_at'], w) for (index, r), w in zip(selected, weights)]
    feature_indices = [r['feature_index'] for _, r in selected] if not reasons else []
    return {'selected': selected, 'weights': weights, 'ready': not reasons, 'ready_reasons': reasons,
            'physical_pair_count': count, 'contributing_sessions': scenes, 'contributing_session_count': len(scenes),
            'classes': classes, 'active_block_count': active,
            'blocks': [{'session_index': s, 'block_index': b, 'physical_pairs': n,
                        'side_weight': float(Fraction(count, active * n))} for (s, b), n in sorted(blocks.items())],
            'canonical_teacher_sha256': hashlib.sha256(json.dumps(canonical, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest(),
            'training_feature_indices_sha256': hashlib.sha256(json.dumps(feature_indices, separators=(',', ':')).encode()).hexdigest(),
            'max_label_known_at': max((r['known_at'] for _, r in selected), default=None)}


# ----------------------------------------
def 学習配列(期待: dict, buy: np.ndarray, sell: np.ndarray, qbands: np.ndarray, context: bool) -> tuple:
    """
    機能: 独立選択pairからBUY/SELL交互の数値行・ラベル・重みを作る。
    引数: 期待 (dict) 別算教師、buy/sell (np.ndarray) 実側特徴、qbands (np.ndarray)、context (bool)。
    返り値: tuple 型のX/y/w。学習は行わない。
    """
    rows = [r for _, r in 期待['selected']]
    fi = [r['feature_index'] for r in rows]
    matrix = np.stack((buy[fi], sell[fi]), axis=1).reshape(-1, 100)
    if context:
        onehot = np.eye(3)[np.repeat(qbands[fi], 2)]
        matrix = np.concatenate((matrix, onehot), axis=1)
    labels = np.asarray([[r['label_buy'] + 1, r['label_sell'] + 1] for r in rows], dtype='<i8').reshape(-1)
    mass = np.repeat(np.asarray(期待['weights'], dtype='<f8'), 2)
    return np.ascontiguousarray(matrix, dtype='<f8'), labels, mass


# ----------------------------------------
def 配列SHA(配列: tuple, 列名: list[str]) -> str:
    """
    機能: 151契約と同じ名前・shape・bytes列を、別組立配列から署名する。
    引数: 配列 (tuple) X/y/w、列名 (list[str]) 元列又は属性付き列。
    返り値: str 型の学習入力SHA256。
    """
    signature = hashlib.sha256(json.dumps(列名, ensure_ascii=False, separators=(',', ':')).encode())
    for value in 配列:
        signature.update(str(value.shape).encode('ascii'))
        signature.update(value.tobytes())
    return signature.hexdigest()


# ----------------------------------------
def 分岐列(exported: dict, names: list[str]) -> list[int]:
    """
    機能: CatBoost公開JSONの実分岐を独立走査する。
    引数: exported (dict) 保存モデル、names (list[str]) 入力列。
    返り値: list[int] 型の実列番号。
    """
    fields = {f['feature_index']: f for f in exported['features_info']['float_features']}
    result = set()
    for tree in exported['oblivious_trees']:
        for split in tree.get('splits') or []:
            assert split['split_type'] == 'FloatFeature'
            field = fields[split['float_feature_index']]
            i = field['flat_feature_index']
            assert field['feature_id'] == names[i]
            result.add(i)
    return sorted(result)


# ----------------------------------------
def 主処理() -> dict:
    """
    機能: 全教師・全モデル・全q0を固定成果物へ独立照合する。
    引数: なし。161のF0・学習完了後だけ読取を行う。
    返り値: dict 型の監査正本。再学習・新採否・金融を行わない。
    """
    assert SHA(TRIAL / '条件.json') == BOOK_SHA
    book = JSON読取(TRIAL / '条件.json')
    f0 = JSON読取(TRIAL / '検査/F0_自然実行前.json')
    completed = JSON読取(OUT / '学習完了.json')
    assert completed['成功'] and f0['条件SHA256'] == completed['条件SHA256'] == BOOK_SHA
    for path, digest in f0['Source'].items(): assert SHA(ROOT / path) == digest
    for path, digest in CACHE_SHA.items(): assert SHA(CACHE / path) == digest
    for path, digest in completed['出力SHA256'].items(): assert SHA(OUT / path) == digest
    metadata = JSON読取(CACHE / 'feature_only/features_meta.json')
    teacher_meta = JSON読取(CACHE / 'teacher_only/teachers_meta.json')
    with np.load(CACHE / 'feature_only/features.npz', allow_pickle=False) as arrays:
        buy, sell, names = arrays['buy_X'].copy(), arrays['sell_X'].copy(), arrays['columns'].tolist()
    with np.load(CACHE / 'teacher_only/teachers.npz', allow_pickle=False) as arrays:
        canonical = arrays['canonical_feature_index'].copy()
        teacher_labels = arrays['labels'].copy()
        teacher_complete = arrays['pair_complete'].copy()
        teacher_known = arrays['known_at'].copy()
        assert arrays['side_order'].tolist() == [1, -1]
    q0 = metadata['q0_meta']
    scenes = metadata['scenes']
    rows = teacher_meta['rows']
    assert len(q0) == 35339 and len(scenes) == 73
    assert len(rows) == len(canonical) == len(teacher_labels) == len(teacher_complete) == len(teacher_known)
    oracle = 独立部品()
    qbands = np.asarray([oracle.q0時帯(r['session'], int(r['q0_time'])) for r in q0], dtype=np.int8)
    tbands = [int(qbands[i]) for i in canonical]
    for ti, row in enumerate(rows):
        assert row['feature_index'] == canonical[ti]
        fi = int(canonical[ti])
        assert all(row[k] == q0[fi][k] for k in q0[fi])
        assert row['aliases'][0] == row['event_id']
        assert row['alias_feature_indices'][0] == fi
        assert row['pair_complete'] == bool(teacher_complete[ti])
        if teacher_complete[ti]:
            assert [row['label_buy'], row['label_sell']] == teacher_labels[ti].tolist() and row['known_at'] == teacher_known[ti]
        else:
            assert np.isnan(teacher_labels[ti]).all() and math.isnan(teacher_known[ti])
    columns = JSON読取(ROOT / 'inputs/00148_全1分入口母集団/100特徴の列定義.json')
    if isinstance(columns, dict): columns = columns['columns']
    assert names == [c['name'] for c in columns]
    decisions = JSON読取(OUT / 'q0の判断.json.gz')['rows']
    audits = JSON読取(OUT / '場別モデルと教師.json.gz')['rows']
    assert len(decisions) == len(q0) and len(audits) == len(scenes)
    starts = [int(s['start']) for s in scenes]
    checks = Counter()
    max_error = 0.
    used_models = set()
    support_by_mode = Counter()
    fallback_by_band = Counter()
    for current, scene in enumerate(scenes):
        audit = audits[current]
        active = [i for i, r in enumerate(q0) if r['session_index'] == current]
        active_bands = sorted({int(qbands[i]) for i in active})
        assert audit['session_index'] == current and audit['session'] == scene['session']
        assert audit['active_timebands'] == active_bands and audit['no_retraining_within_scene'] is True
        expected = {'COMMON': 期待教師(rows, starts, current, tbands, None)}
        expected['CONTEXT'] = expected['COMMON']
        for band in active_bands: expected[f'SPLIT_{band}'] = 期待教師(rows, starts, current, tbands, band)
        model_runtime = {}
        for tag, selected in expected.items():
            model_audit = audit['models']['SPLIT'][tag[-1]] if tag.startswith('SPLIT_') else audit['models'][tag]
            for key in ('ready', 'ready_reasons', 'physical_pair_count', 'contributing_sessions', 'contributing_session_count',
                        'classes', 'active_block_count', 'blocks', 'canonical_teacher_sha256',
                        'training_feature_indices_sha256', 'max_label_known_at'):
                assert model_audit[key] == selected[key], (current, tag, key)
                checks['教師監査欄'] += 1
            assert model_audit['window'] == {'first_session_index': max(0, current - 20), 'last_session_index': current - 1,
                                             'calendar_session_count': min(current, 20), 'limit': 20}
            assert model_audit['maturity'] == {'known_at_strict_before': starts[current], 'pair_complete_required': True}
            assert selected['max_label_known_at'] is None or selected['max_label_known_at'] < starts[current]
            checks['教師集合'] += 1
            support_by_mode[tag.split('_')[0] + ('_ready' if selected['ready'] else '_unready')] += 1
            if not selected['ready']:
                assert model_audit['model_id'] is None and model_audit['model'] is None
                model_runtime[tag] = None
                continue
            context = tag == 'CONTEXT'
            model_names = names + (['context_day', 'context_pre_us', 'context_post_us'] if context else [])
            arrays = 学習配列(selected, buy, sell, qbands, context)
            ref = model_audit['model']
            assert ref['training_array_sha256'] == 配列SHA(arrays, model_names), (current, tag, '配列SHA')
            model_id = f'{current:03d}_{tag}'
            assert ref['model_id'] == model_id == model_audit['model_id']
            path = OUT / 'models' / (model_id + '.json')
            assert SHA(path) == ref['physical_sha256'] and ref['parameters'] == book['classifier_parameters']
            exported = JSON読取(path)
            used = 分岐列(exported, model_names)
            assert used == ref['used_indices']
            assert [model_names[i] for i in used] == ref['used_columns']
            structure = {k: exported[k] for k in ('features_info', 'oblivious_trees', 'scale_and_bias')}
            assert hashlib.sha256(json.dumps(structure, sort_keys=True, separators=(',', ':')).encode()).hexdigest() == ref['structure_sha256']
            learner = CatBoostClassifier()
            learner.load_model(str(path), format='json')
            assert list(learner.classes_) == [0, 1, 2]
            model_runtime[tag] = (learner, used, model_names)
            used_models.add(path.name)
            checks['保存モデルと入力SHA'] += 1
        for mode in ('COMMON', 'CONTEXT', 'SPLIT'):
            parts = [active] if mode != 'SPLIT' else [[i for i in active if qbands[i] == band] for band in active_bands]
            for indices in parts:
                band = int(qbands[indices[0]]) if mode == 'SPLIT' else None
                tag = mode if mode != 'SPLIT' else f'SPLIT_{band}'
                fallback = mode == 'SPLIT' and model_runtime[tag] is None
                runtime = model_runtime['COMMON'] if fallback else model_runtime[tag]
                effective = 'WAIT' if runtime is None else ('COMMON' if fallback else mode)
                fallback_reasons = expected[tag]['ready_reasons'] if fallback else []
                model_id = None if runtime is None else f'{current:03d}_' + ('COMMON' if fallback else tag)
                if runtime is None:
                    probabilities = [None] * (2 * len(indices))
                    used = []
                else:
                    learner, used, input_names = runtime
                    xx = np.concatenate((buy[indices], sell[indices]))
                    if mode == 'CONTEXT':
                        xx = np.concatenate((xx, np.eye(3)[np.tile(qbands[indices], 2)]), axis=1)
                    probabilities = np.asarray(learner.predict_proba(Pool(xx, feature_names=input_names), thread_count=1)).tolist()
                for offset, fi in enumerate(indices):
                    decision = decisions[fi]
                    assert all(decision[k] == v for k, v in q0[fi].items()) and decision['q0_timeband'] == int(qbands[fi])
                    pred = decision['predictions'][mode]
                    assert pred['requested_mode'] == mode and pred['effective_mode'] == effective
                    assert pred['model_id'] == model_id and pred['timeband'] == int(qbands[fi])
                    assert pred['fallback'] is fallback and pred['fallback_reasons'] == fallback_reasons
                    assert pred['used_indices'] == used and pred['technical_used_indices'] == [i for i in used if i < 100]
                    pb, ps = probabilities[offset], probabilities[offset + len(indices)]
                    actual_vote = pred['prediction']
                    if runtime is None:
                        assert actual_vote['probabilities'] is None
                    else:
                        saved_prob = actual_vote['probabilities']
                        a = np.asarray([pb, ps]); b = np.asarray([saved_prob['buy'], saved_prob['sell']])
                        error = float(np.max(np.abs(a - b)))
                        max_error = max(max_error, error)
                        assert np.allclose(a, b, rtol=2e-13, atol=2e-15), (fi, mode, error)
                    expected_vote = oracle.優勢側判断(buy[fi], sell[fi], pb, ps, columns, used, book['selection']['thresholds'])
                    for key, value in expected_vote.items():
                        if key == 'conditional_forward' and value is not None:
                            assert math.isclose(actual_vote[key], value, rel_tol=2e-13, abs_tol=2e-15)
                        else:
                            assert actual_vote[key] == value, (fi, mode, key)
                    for threshold, side in expected_vote['directions'].items():
                        assert decision['decision']['directions'][mode + '_' + threshold] == side
                    if fallback: fallback_by_band[str(band) + '_' + effective] += 1
                    checks['全q0方式判断'] += 1
        if (current + 1) % 10 == 0:
            print(json.dumps({'監査場': current + 1, '全73場': True, 'モデル確認': checks['保存モデルと入力SHA']}, ensure_ascii=False), flush=True)
    assert used_models == {p.name for p in (OUT / 'models').glob('*.json')}
    assert checks['全q0方式判断'] == 35339 * 3
    for path, digest in f0['Source'].items(): assert SHA(ROOT / path) == digest
    return {'成功': True, '試行': 161, '自然学習の再実行': False, '金融計算': False,
            '旧151正式照合': 'モデル担当が別監査', '検査件数': dict(checks), '保存確率との最大絶対差': max_error,
            '支持別モデル群': dict(support_by_mode), '帯別fallback_q0': dict(fallback_by_band),
            'q0独立暦算件数': {str(i): int(np.sum(qbands == i)) for i in (0, 1, 2)},
            '教師正準q0独立暦算件数': dict(Counter(map(str, tbands))),
            '条件SHA256': BOOK_SHA, 'F0_Source': f0['Source'],
            '監査SourceSHA256': {p.name: SHA(p) for p in (Path(__file__), HERE / '独立純計算.py')}}


# ----------------------------------------
if __name__ == '__main__':
    result = 主処理()
    (HERE / '自然監査結果.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)
