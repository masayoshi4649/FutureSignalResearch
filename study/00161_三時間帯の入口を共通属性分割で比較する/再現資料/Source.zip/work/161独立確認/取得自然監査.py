"""161の複合補正・物理取得・初参加補完を、金融情報なしで独立監査する。"""
from collections import Counter
from pathlib import Path
import gzip
import hashlib
import importlib.util
import json
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
TRIAL = ROOT / 'study/00161_三時間帯の入口を共通属性分割で比較する'
SELECTION = ROOT / 'work/161三時間帯入口/選択'
BOOK_SHA = 'f22d735cefd0146aa4ec691a5adeeaf82c6961e746e88d7cdfd52fbcc25b46b8'


def 読取(path: Path) -> dict:
    """
    機能: JSON又はgzip全体を読み、CRCを含めて検査する。
    引数: path (Path) 対象。
    返り値: dict 型の値。
    """
    with (gzip.open(path, 'rt', encoding='utf-8') if path.suffix == '.gz' else path.open(encoding='utf-8')) as source:
        return json.load(source)


# ----------------------------------------
def 指紋(path: Path) -> str:
    """
    機能: 物理SHAを独立計算する。
    引数: path (Path) 対象。
    返り値: str 型のSHA256。
    """
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


# ----------------------------------------
def 物理時計(quote: dict) -> tuple:
    """
    機能: 各気配の原行順序を文字列IDなしで表す。
    引数: quote (dict) time/index/source_lineを持つ気配。
    返り値: tuple 型の物理時計。
    """
    return tuple(quote[k] for k in ('time', 'index', 'source_line'))


# ----------------------------------------
def 主処理() -> dict:
    """
    機能: 全補正q0・41選択・876補完判断を独立に再構成して照合する。
    引数: なし。Root選択完了後の固定成果物を読み取る。
    返り値: dict 型の監査結果。先着/将来経路/利益/損失は読み込まない。
    """
    assert 指紋(TRIAL / '条件.json') == BOOK_SHA
    book = 読取(TRIAL / '条件.json')
    done = 読取(SELECTION / '選択完了.json')
    assert done['成功'] and done['条件SHA256'] == BOOK_SHA
    for path, digest in done['Sourceと判断'].items(): assert 指紋(ROOT / path) == digest
    for path, digest in done['出力'].items(): assert 指紋(SELECTION / path) == digest
    pure_spec = importlib.util.spec_from_file_location('audit161_selection_pure', HERE / '独立純計算.py')
    oracle = importlib.util.module_from_spec(pure_spec)
    pure_spec.loader.exec_module(oracle)
    raw = 読取(ROOT / 'work/161三時間帯入口/自然学習/q0の判断.json.gz')['rows']
    corrected = 読取(SELECTION / '補正q0の判断.json.gz')['rows']
    selected = 読取(SELECTION / '選択対応.json.gz')
    metadata_path = ROOT / book['inputs']['metadata']['path']
    capture_path = ROOT / book['inputs']['captures']['path']
    assert 指紋(metadata_path) == book['inputs']['metadata']['sha256']
    assert 指紋(capture_path) == book['inputs']['captures']['sha256']
    metadata, captures = 読取(metadata_path), 読取(capture_path)
    capmap = {r['event_id']: r for r in captures['rows']}
    desc = {r['case_id']: r for r in metadata['population148']['cases']}
    assert len(raw) == len(corrected) == len(capmap) == 35339
    columns = 読取(ROOT / 'inputs/00148_全1分入口母集団/100特徴の列定義.json')
    if isinstance(columns, dict): columns = columns['columns']
    feature_file = ROOT / 'work/151過去場判別の評価/入口選択/cache/feature_only/features.npz'
    assert 指紋(feature_file) == '5b309e0821403fcf1b122956fc6c9fe20ec5dfbe4327d7d674193b8e58f99b44'
    with np.load(feature_file, allow_pickle=False) as arrays:
        buy, sell = arrays['buy_X'].copy(), arrays['sell_X'].copy()
    checks = Counter()
    correction_branches = Counter()
    for fi, (r, d) in enumerate(zip(raw, corrected)):
        assert r['event_id'] == d['event_id'] and r['q0_timeband'] == d['q0_timeband']
        for policy, direction in r['decision']['directions'].items():
            assert d['decision']['directions'][policy] == direction
        for mode in ('COMMON', 'CONTEXT', 'SPLIT'):
            source = r['decision']['directions'][mode + '_P65']
            answer = oracle.複合回復A0(source, buy[fi], sell[fi], columns)
            actual = d['correction'][mode]
            assert actual['source_side'] == source and actual['A0']['side'] == answer['side']
            assert actual['A0']['reason'] == answer['reason']
            g = actual['G']
            assert (None if g is None else g['value']) is answer['G']
            policy = mode + '_P65_A'
            assert d['decision']['directions'][policy] == answer['side']
            assert d['decision']['conflicts'][policy] == (answer['reason'] == 'recovery_conflict')
            evidence = [e for e in d['decision']['evidence'] if e['rule'] == policy]
            assert len(evidence) == int(answer['side'] != 0)
            if evidence:
                e = evidence[0]
                assert e['signal_side'] == source and e['order_side'] == answer['side'] and e['reverse_probability_transferred'] is False
                expected_roles = {'方向', '強度', '勢い', '構造', '量'} if answer['G'] is True else set(r['predictions'][mode]['prediction']['known_roles']) | {'方向', '強度'}
                assert e['roles'] == sorted(expected_roles)
            correction_branches[mode + '/' + answer['reason']] += 1
            checks['複合補正q0'] += 1
    legacy = {}
    first_signals = []
    for e in metadata['entries']:
        origin = e['origins'][0]
        birth, entry = origin['birthQuote'], e['entry_quote']
        assert 物理時計(birth) < 物理時計(entry)
        legacy[e['id']] = {'case_id': e['id'], 'session': e['session'], 'side': e['native_side'], 'stream': 'original',
                            'event_id': None, 'q1': entry, 'q0': birth, 'contract': e['contract'], 'source_kind': '旧C1固定参照'}
        first_signals.append({'case_id': e['id'], 'session': e['session'], 'birth_key': [*物理時計(birth), e['id']]})
    assert len(legacy) == 87
    sessions = list(captures['sessions'])
    assert len(sessions) == len(set(sessions)) == 73
    expected_policies = {'C1': legacy}
    expected_f = {}
    counts = {}
    for signal in book['signal_policies']:
        new, count = {}, Counter()
        for d in corrected:
            side = d['decision']['directions'][signal]
            if side == 0: continue
            c = capmap[d['event_id']]
            assert (d['q0_time'], d['q0_index'], d['q0_line']) == 物理時計(c['q0'])
            count['born'] += 1
            count[c['status']] += 1
            if c['status'] != 'filled': continue
            cid = c['case_id']
            if cid in new:
                count['duplicate_q1'] += 1
                continue
            stream = c['buy_stream'] if side == 1 else c['sell_stream']
            assert stream == desc[cid]['buy_stream' if side == 1 else 'sell_stream']
            new[cid] = {'case_id': cid, 'session': d['session'], 'side': side, 'stream': stream, 'event_id': d['event_id'],
                        'q1': c['q1'], 'q0': c['q0'], 'contract': d['contract'], 'source_kind': '新q0'}
        counts[signal] = dict(count)
        expected_policies[signal + '_N'] = new
        expected_policies[signal + '_U'] = new | legacy
        oracle_entries = [{'session': r['session'], 'case_id': r['case_id'], 'q0_key': list(物理時計(r['q0'])),
                           'entry_key': list(物理時計(r['q1']))} for r in new.values()]
        decisions_f = oracle.初参加補完(sessions, oracle_entries, first_signals)
        supplement = {r['fallback_case']: legacy[r['fallback_case']] for r in decisions_f if r['fallback_case'] is not None}
        expected_policies[signal + '_F'] = new | supplement
        for row in decisions_f: expected_f[(signal, row['session'])] = row
    assert selected['候補と取得'] == counts
    for audit in selected['F因果監査']:
        key = audit['signal_policy'], audit['session']
        expected = expected_f.pop(key)
        assert audit['first_C1_case'] == expected['first_c1_case']
        assert [*物理時計(audit['first_C1_birth']), audit['first_C1_case']] == expected['birth_key']
        assert len(set(audit['new_filled_before_or_at_birth'])) == expected['n_acquired_by_birth']
        assert audit['reserve_C1'] is (expected['fallback_case'] is not None)
        assert audit['pending_new_does_not_count'] is True and audit['later_fill_does_not_cancel'] is True
        checks['初参加補完場判断'] += 1
    assert not expected_f
    oldfiles = {'OLD152_B0_N': (152, '00152_複合回復の方向切替', 'B0'), 'OLD152_U1': (152, '00152_複合回復の方向切替', 'U1'),
                'OLD153_N15': (153, '00153_先行高安の独立出生', 'N15'), 'OLD153_U15': (153, '00153_先行高安の独立出生', 'U15')}
    q1map = {r['case_id']: r['q1'] for r in captures['rows'] if r['status'] == 'filled'}
    q1map.update({cid: r['q1'] for cid, r in legacy.items()})
    for policy, (trial, folder, oldname) in oldfiles.items():
        old = 読取(ROOT / 'inputs' / folder / '選択対応.json.gz')
        assert old['試行'] == trial
        expected_policies[policy] = {r['case_id']: r | {'q1': q1map[r['case_id']], 'contract': desc[r['case_id']]['contract'],
                                                       'source_kind': '旧C1固定参照' if r['origin'] == 'C1' else '過去新枝固定参照'} for r in old['政策'][oldname]}
    participation = {}
    physical_counts = {}
    for policy, expected in expected_policies.items():
        actual = selected['政策'][policy]
        assert len(actual) == len(expected) == len({r['case_id'] for r in actual})
        stamps = set()
        scene_counts = Counter()
        for row in actual:
            e = expected[row['case_id']]
            assert all(row[k] == e[k] for k in ('case_id', 'session', 'side', 'stream', 'event_id', 'q1', 'source_kind'))
            stamp = (row['session'], e.get('contract', desc[row['case_id']]['contract']), *物理時計(row['q1']))
            assert stamp not in stamps, (policy, stamp)
            stamps.add(stamp)
            scene_counts[row['session']] += 1
            checks['取得参照行'] += 1
        zero = [s for s in sessions if scene_counts[s] == 0]
        if policy.endswith(('_F', '_U')) or policy == 'C1': assert not zero, (policy, zero)
        participation[policy] = {'全取得': len(actual), '参加場': len(sessions) - len(zero), '0取得場': zero, '全場最低1': not zero}
        physical_counts[policy] = len(stamps)
        checks['政策集合'] += 1
    assert set(expected_policies) == set(selected['政策']) == set(book['policies']) and checks['政策集合'] == 41
    for path, digest in done['Sourceと判断'].items(): assert 指紋(ROOT / path) == digest
    return {'成功': True, '試行': 161, '金融ラベルの読取': False, '金融計算': False,
            '検査件数': dict(checks), '補正分岐': dict(correction_branches), '政策別参加': participation,
            '政策別物理q1一意数': physical_counts, '条件SHA256': BOOK_SHA,
            '選択Sourceと判断': done['Sourceと判断'],
            '独立監査SourceSHA256': {p.name: 指紋(p) for p in (Path(__file__), HERE / '独立純計算.py')}}


# ----------------------------------------
if __name__ == '__main__':
    result = 主処理()
    (HERE / '取得自然監査結果.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '検査件数': result['検査件数']}, ensure_ascii=False), flush=True)
