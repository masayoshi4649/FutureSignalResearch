"""自然入力・ラベル・金融へ触れず161モデル部品を独立計算へ照合する。"""
from datetime import datetime, time
import hashlib
import importlib.util
import json
from pathlib import Path
import random
import sys
from zoneinfo import ZoneInfo

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent


class 窓外毒行(dict):
    """現場・未来・窓外教師の秘密欄を先に読む実装を人工的に検出する。"""

    def get(self, key: str, default: object = None) -> object:
        """
        機能: 所属場以外の欄へのアクセスを検出して失敗させる。
        引数: key (str) 参照キー、default (object) 未存在時の値。
        返り値: object 型の所属場。秘密欄はAssertionErrorで拒否する。
        """
        assert key == 'session_index', ('窓外教師の秘密欄を読んだ', key)
        return super().get(key, default)


# ----------------------------------------
def 読込(名前: str, 場所: Path) -> object:
    """
    機能: 名前を衝突させず、指定されたSourceだけをimportする。
    引数: 名前 (str) モジュール名、場所 (Path) PythonSource。
    返り値: object 型の読込済みモジュール。
    """
    spec = importlib.util.spec_from_file_location(名前, 場所)
    module = importlib.util.module_from_spec(spec)
    sys.modules[名前] = module
    spec.loader.exec_module(module)
    return module


# ----------------------------------------
def 人工列() -> list[dict]:
    """
    機能: 執行列と複数技術役割を持つ架空100特徴辞書を作る。
    引数: なし。
    返り値: list[dict] 型の100列。自然辞書を読み込まない。
    """
    result = [{'name': f'artificial_{i:03d}', 'role': ('direction', 'momentum', 'structure', 'volume')[i % 4]} for i in range(100)]
    for i, name in enumerate(('q0_spread_points', 'q0_spread_125_ratio', 'q0_entry_minus_last_atr5_to_side',
                              'q0_last_minus_m1_close_atr5_to_side')):
        result[i] = {'name': name, 'role': 'execution' if i < 3 else 'structure'}
    return result


# ----------------------------------------
def 主処理() -> dict:
    """
    機能: 暦境界・判断・属性・重みの人工反例を独立オラクルへ照合する。
    引数: なし。
    返り値: dict 型の件数・Source指紋。自然結果や自然学習を生成しない。
    """
    oracle = 読込('audit161_pure', HERE / '独立純計算.py')
    model_path = ROOT / 'work/161三時間帯入口のモデル/model161.py'
    training_path = ROOT / 'work/161三時間帯入口のモデル/training161.py'
    model = 読込('audit161_model', model_path)
    training = 読込('audit161_training', training_path)
    old = 読込('audit151_model', ROOT / 'work/151過去場判別/model151.py')
    selector_path = ROOT / 'work/過去場だけの教師選択と時間区画重み/教師選択.py'
    selector = 読込('audit161_teacher_selector', selector_path)
    logic152 = 読込('audit161_logic152', ROOT / 'work/152複合回復の入口/logic152.py')
    checks = {'暦境界': 0, '判断オラクル': 0, '旧151判断同体': 0, '属性列': 0, '帯内重み': 0,
              '窓外秘密欄の非参照': 0, '成熟等号と未知': 0, '正準化と時帯重複': 0,
              '初参加補完の因果時計': 0, '複合回復の別実装': 0}

    for d in ('2026-03-07', '2026-03-08', '2026-10-30', '2026-11-01', '2026-11-02'):
        expected = int(datetime.combine(datetime.fromisoformat(d).date(), time(9, 30), ZoneInfo('America/New_York')).timestamp())
        assert oracle.米国開始UTC(d) == expected
        for offset, band in ((-1, 1), (0, 2), (1, 2)):
            assert oracle.q0時帯(d + '_Night', expected + offset) == band
            assert oracle.q0時帯(d + '_Day', expected + offset) == 0
            checks['暦境界'] += 2

    columns = 人工列()
    thresholds = {'P70': .70, 'P65': .65, 'P60': .60}
    rng = random.Random(161)
    probability_pairs = [
        ([.2, .1, .7], [.4, .2, .4]),
        ([.2, .1, .7], [.2, .1, .7]),
        ([.0, .61, .39], [.4, .3, .3]),
        ([.175, .4, .425], [.4, .3, .3]),
        ([.3, .3, .4], [.4, .3, .3]),
        (None, None),
    ]
    for _ in range(60):
        p, q = [rng.random() for _ in range(3)], [rng.random() for _ in range(3)]
        probability_pairs.append(([v / sum(p) for v in p], [v / sum(q) for v in q]))
    for buy_p, sell_p in probability_pairs:
        for spread, gap in ((5, 0), (20, 1), (20, -1), (0, 0), (25, 0), (5, 1.01), (None, 0), (5, float('nan'))):
            for used in ([0, 1, 2, 100, 101, 102], [4], [4, 5], [4, 5, 100, 101, 102]):
                buy, sell = [1.] * 100, [2.] * 100
                buy[0], buy[3] = spread, gap
                sell[0], sell[3] = 5, 0
                expected = oracle.優勢側判断(buy, sell, buy_p, sell_p, columns, used, thresholds)
                actual = model.decide(buy, sell, buy_p, sell_p, columns, used, thresholds)
                for key, value in expected.items():
                    assert actual[key] == value, (key, actual, expected)
                checks['判断オラクル'] += 1
                oldactual = old.decide(buy, sell, buy_p, sell_p, columns, [i for i in used if i < 100], thresholds)
                assert actual == oldactual, (actual, oldactual)
                checks['旧151判断同体'] += 1

    x = np.asarray([[float('nan')] + [float(i) for i in range(99)], [7.] * 100])
    base = x.copy()
    for band in (0, 1, 2):
        out = model.with_context(x, np.asarray([band, band], dtype=np.int8))
        assert out.shape == (2, 103) and np.array_equal(out[:, :100], base, equal_nan=True)
        assert np.array_equal(out[:, 100:], np.eye(3)[[band, band]])
        assert np.array_equal(x, base, equal_nan=True)
        assert len(model.model_columns(columns, True)) == 103 and model.model_columns(columns, False) == columns
        checks['属性列'] += 1

    pairs, bands = [], {}
    for i in range(1280):
        pair = {'source_index': i, 'session_index': i % 8, 'block_index': (i // 8) % 4,
                'label_buy': i % 3 - 1, 'label_sell': (i + 1) % 3 - 1,
                'side_weight': 91.0}
        pairs.append(pair)
        bands[i] = 0 if i < 1000 else (1 if i < 1200 else 2)
    selected = {'window': {'limit': 20}, 'pairs': pairs, 'current_scene_index': 28,
                'current_scene_start': 200000, 'maturity': {'strict': True}, 'physical_pair_count': 1280}
    for band in (0, 1, 2):
        expected = oracle.帯内重み(pairs, bands, band)
        actual = training.select_timeband(selected, bands, band)
        for key in ('indices', 'physical_pair_count', 'contributing_sessions', 'classes', 'active_block_count', 'ready', 'ready_reasons'):
            assert actual[key] == expected[key], (key, actual, expected)
        for pair in actual['pairs']:
            assert pair['side_weight'] == float(expected['weights'][pair['source_index']])
        assert all(p['side_weight'] == 91.0 for p in pairs)
        checks['帯内重み'] += 1

    starts = [i * 10000 for i in range(31)]
    protected = [窓外毒行(session_index=i) for i in (0, 7, 28, 29, 30)]
    selected = selector.select_past_teachers(protected, starts, 28)
    assert selected['physical_pair_count'] == 0 and selected['filters']['outside_window'] == 5
    checks['窓外秘密欄の非参照'] += 5

    regular = {'case_id': 'physical1', 'event_id': 'event0', 'session_index': 27,
               'q0_index': 5, 'q0_line': 5, 'q0_time': 270000,
               'known_at': 279999, 'pair_complete': True, 'label_buy': 1, 'label_sell': -1}
    for patch, eligible in (({}, 1), ({'known_at': 280000}, 0), ({'known_at': None}, 0),
                            ({'known_at': float('nan')}, 0), ({'pair_complete': False}, 0),
                            ({'label_buy': None}, 0), ({'label_sell': 0}, 1)):
        selected = selector.select_past_teachers([regular | patch], starts, 28)
        assert selected['physical_pair_count'] == eligible
        checks['成熟等号と未知'] += 1
    alias = regular | {'event_id': 'event1', 'q0_index': 6, 'q0_line': 6, 'q0_time': 270001}
    selected = selector.select_past_teachers([alias, regular], starts, 28)
    assert selected['indices'] == [1] and selected['noncanonical_rows_removed'] == 1
    before = training.select_timeband(selected, {0: 2, 1: 1}, 1)
    after = training.select_timeband(selected, {0: 2, 1: 1}, 2)
    assert before['indices'] == [1] and after['indices'] == []
    checks['正準化と時帯重複'] += 1

    signals = [
        {'session': '人工場', 'birth_key': [10, 100, 110, 'b'], 'case_id': 'later_id'},
        {'session': '人工場', 'birth_key': [10, 100, 110, 'a'], 'case_id': 'first'},
        {'session': '人工場', 'birth_key': [12, 120, 130, '0'], 'case_id': 'later_quote'},
    ]
    for key, expected in (([9, 90, 100], None), ([10, 100, 109], None), ([10, 100, 110], None),
                          ([10, 100, 111], 'first'), ([11, 110, 120], 'first')):
        acquired = [{'session': '人工場', 'q0_key': [8, 80, 90], 'entry_key': key, 'case_id': 'N1'}]
        result = oracle.初参加補完(['人工場'], acquired, signals)[0]
        assert result['fallback_case'] == expected and result['first_c1_case'] == 'first'
        checks['初参加補完の因果時計'] += 1
    result = oracle.初参加補完(['人工場'], [], signals)[0]
    assert result['fallback_case'] == 'first' and result['n_acquired_by_birth'] == 0
    checks['初参加補完の因果時計'] += 1

    correction_columns = 人工列()
    keys = list(dict.fromkeys((*logic152.G_KEYS, *logic152.R_KEYS, logic152.CHASE)))
    existing_names = {c['name'] for c in correction_columns}
    for i, name in enumerate((k for k in keys if k not in existing_names), start=10): correction_columns[i]['name'] = name
    cindex = {c['name']: i for i, c in enumerate(correction_columns)}
    for example in range(1000):
        buy, sell = np.ones(100), np.ones(100)
        source = (0, 1, -1)[example % 3]
        for vector in (buy, sell):
            for name in keys: vector[cindex[name]] = rng.choice((-1., 0., 1., 2., 25., 26., float('nan')))
        if example % 2 == 0:
            for vector in (buy, sell):
                for name in logic152.G_KEYS[:3]: vector[cindex[name]] = -1.
                vector[cindex[logic152.G_KEYS[3]]] = 26.
        expected = oracle.複合回復A0(source, buy, sell, correction_columns)
        actual = logic152.choose(source, buy.tolist(), sell.tolist(), correction_columns)
        assert actual['A0']['side'] == expected['side'] and actual['A0']['reason'] == expected['reason']
        assert (None if actual['G'] is None else actual['G']['value']) is expected['G']
        checks['複合回復の別実装'] += 1

    return {'成功': True, '自然入力の読取': False, '自然採否の実行': False, '金融の実行': False,
            '検査件数': checks,
            '検査対象SHA256': {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                             for p in (model_path, training_path, selector_path, HERE / '独立純計算.py', Path(__file__))}}


# ----------------------------------------
if __name__ == '__main__':
    result = 主処理()
    target = HERE / '人工検査結果.json'
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))
