"""SPLITの実取得を帯別学習・共通戻し・旧補完へ分ける固定結果の事後診断。"""
from pathlib import Path
import gzip
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent


def JSON(path: Path) -> dict:
    """
    機能: gzipの全CRCを確認し小さなJSONを読み込む。
    引数: path (Path) 対象。
    返り値: dict 型の解析値。
    """
    with gzip.open(path, 'rt', encoding='utf-8') as source:
        return json.load(source)


# ----------------------------------------
def 主処理() -> dict:
    """
    機能: 確定取得へ保存された実効モデルを結び、帰属を別集計する。
    引数: なし。固定161成果物を読み取る。
    返り値: dict 型の3政策の事後分解。新しい入口を生成・採用しない。
    """
    paths = {'raw': ROOT / 'work/161三時間帯入口/自然学習/q0の判断.json.gz',
             'selection': ROOT / 'work/161三時間帯入口/選択/選択対応.json.gz',
             'finance': ROOT / 'work/161三時間帯入口の金融/自然射影/全caseの厳密先着とIFD.json.gz'}
    proofs = {k: hashlib.sha256(p.read_bytes()).hexdigest() for k, p in paths.items()}
    raw = JSON(paths['raw'])['rows']
    byevent = {r['event_id']: r for r in raw}
    selected = JSON(paths['selection'])['政策']
    finance = JSON(paths['finance'])
    result = {}
    for policy in ('SPLIT_P65_A_N', 'SPLIT_P65_A_F', 'SPLIT_P65_A_U'):
        groups = {}
        for r in selected[policy]:
            kind = byevent[r['event_id']]['predictions']['SPLIT']['effective_mode'] if r['event_id'] is not None else '旧C1固定参照'
            g = groups.setdefault(kind, {'取得': 0, '場': set(), 'F': 0, 'A': 0, 'N': 0, 'C': 0, '利益': 0, '損失': 0, '金融未知': 0})
            f = finance[r['case_id']][r['stream']]
            g['取得'] += 1
            g['場'].add(r['session'])
            g[f['label']] += 1
            if f['known']:
                g['利益'] += max(f['net'], 0)
                g['損失'] -= min(f['net'], 0)
            else:
                g['金融未知'] += 1
        for kind, g in groups.items():
            g['場数'] = len(g.pop('場'))
            g['到達済み先着率'] = g['F'] / (g['F'] + g['A']) if g['F'] + g['A'] else None
            g['既知差引'] = g['利益'] - g['損失']
        assert sum(g['取得'] for g in groups.values()) == len(selected[policy])
        result[policy] = groups
    assert proofs == {k: hashlib.sha256(p.read_bytes()).hexdigest() for k, p in paths.items()}
    return {'成功': True, '事後診断': True, '選択の変更': False,
            '注記': '既使用73場の固定結果の帰属分解。4場のCOMMON戻し等を新採用条件へしない。',
            '結果': result, '入力SHA256': proofs, 'SourceSHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}


# ----------------------------------------
if __name__ == '__main__':
    result = 主処理()
    (HERE / '帯別学習と共通戻しの取得事後分解.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '政策数': len(result['結果'])}, ensure_ascii=False))
