# 161の三時間帯入口モデル

2026-11-14作成。自然入力の再射影・学習・採否は未実行。Rootが固定する161のF0後にだけ利用する。

## 分担と固定条件

- `model161.py`：旧151と同じCatBoost 1.2.10/128木/深さ3/seed151、実買・実売の同じ判定規則。COMMON/SPLITは100特徴、CONTEXTは同じ100特徴とq0時帯の3列onehot。
- `training161.py`：旧選択器が過去20場・場開始より厳密に前に両側H60成熟・全体正準化したpairから、帯を限定する。帯内で再正準化しない。限定後に1時間区画重みを再正規化する。
- `simulate161.py`：場開始時に三方式を固定し、その場の全q0を判定する。取得・観測・q1を引数へ受け取らず、場内再学習をしない。
- `人工検査.py`：数値部品の人工検査。旧151と実CatBoostの配列/構造/確率同体を含む。
- `実行器の人工検査.py`：人工3,003q0/9fitで全判断、旧151同体、支持不足、後場ラベルの影響範囲を確認する。自然値は読まない。

元100列の並び・BUY/SELL実側X・未知NaNを維持する。帯はq0のDAY=0/PRE_US=1/POST_US=2であり、時帯そのものは技術役割に数えない。実分岐に使った原100列のうち、当該q0で有限な列から異なる技術役割2種類以上を必要とする。執行3列は役割から除外する。この役割判定は旧151の定義を継承し、当該木の経路だけに限定した寄与解析ではない。

全方式で20過去場・1,000物理pair・8支持場・全3クラスを必要とする。SPLITの帯別支持が不足した場合は、その場開始で固定したCOMMONを当該q0の実側Xへ適用する。COMMONも支持不足なら待機する。COMMON/CONTEXTに帯別支持下限を課さない。各場で出現する帯だけのSPLITを学習し、時帯境界でモデルを再学習しない。

## 入出力API

`simulate(features, teachers, columns, q0_timeband, teacher_timeband, book, output, model, training, teacher_selector)`は`(decisions, audits)`を返す。

- `features`：`columns/buy_X/sell_X/q0_meta/scenes`。Xは[全q0,100]。
- `teachers`：`rows`。旧151のグローバル正準物理pairを維持する。
- `columns`：元100列の列定義辞書。
- `q0_timeband/teacher_timeband`：np.int8等の厳密な整数0/1/2。後者はグローバル正準q0から射影済みとする。
- `book`：trial=161、`model_modes`はCOMMON/CONTEXT/SPLIT、`selection.thresholds`はP70=.70/P65=.65/P60=.60。旧151と同じ学習・判定定数を`validate_book`で検査する。
- `output`：未作成のモデル名を保存できる出力ディレクトリ。モデルは`models/場番号_方式[_帯番号].json`へ保存する。
- `model/training`：本ディレクトリの`model161.py/training161.py`。
- `teacher_selector`：旧`work/過去場だけの教師選択と時間区画重み/教師選択.py`の`select_past_teachers`。

`decisions`は全q0を元順序で保持し、`predictions[COMMON|CONTEXT|SPLIT]`に買売確率、理由、既知技術役割、要求方式、実効方式、実使用列、モデルID、帯、fallbackを保存する。`decision.directions`のIDは`COMMON_P70`等9個。`decision.evidence`は既存の取得結合器へ渡せる形とする。C1追加・A0補正・初参加補完・実BBO取得・IFD損益はRoot側の別工程であり、実行器は実施しない。

`audits`は場ごとの窓・成熟時計・支持・クラス・区画重み・正準教師SHA・学習配列SHA・モデル構造SHA・全実分岐列を保持する。`technical_used_indices`は原100列内の実分岐列を指し、執行列の除外と当該q0の有限性検査を済ませた`known_roles`とは区別する。教師pair全件の反復転記は行わず、固定入力と選択器から再現する。

## 人工検査の再現

リポジトリルートで実行する。

```powershell
& 'work/複合テクニカル学習環境/Scripts/python.exe' -X utf8 'work/161三時間帯入口のモデル/人工検査.py'
& 'work/複合テクニカル学習環境/Scripts/python.exe' -X utf8 'work/161三時間帯入口のモデル/実行器の人工検査.py'
```

初回は人工モデルの3ファイルを本フォルダの`人工モデル/`へ保存する。再実行ではその3ファイルだけを置換する。自然入力、旧151のSourceと結果、正式試行を変更しない。

2026-11-14の結果は人工部品7群・実行器5群成功。実CatBoostによる旧151 COMMONの学習配列/モデル構造/買売確率が同一。人工3,003q0のCOMMON原判断も旧151と全件同一。後場教師の反転はそれより前と当該場のモデル・判断へ影響しない。これは自然73場の成績を意味しない。
