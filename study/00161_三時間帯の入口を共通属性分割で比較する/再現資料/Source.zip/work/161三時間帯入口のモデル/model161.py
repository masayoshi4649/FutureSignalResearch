"""161の共通・時間帯属性入り・時間帯別に共用する売買対称モデル部品。"""
from pathlib import Path
import hashlib
import json
import math

PARAMS={'iterations':128,'depth':3,'learning_rate':.05,'l2_leaf_reg':10,
    'loss_function':'MultiClass','classes_count':3,'random_seed':151,
    'boosting_type':'Plain','bootstrap_type':'No','random_strength':0,
    'has_time':True,'nan_mode':'Min','use_best_model':False,
    'allow_writing_files':False,'verbose':False,'task_type':'CPU','thread_count':1}
EXCLUDED_ROLE_COLUMNS=frozenset(('q0_spread_points','q0_spread_125_ratio','q0_entry_minus_last_atr5_to_side'))
TIMEBAND_NAMES=('DAY','PRE_US','POST_US')
CONTEXT_NAMES=('context_day','context_pre_us','context_post_us')
BASE_FEATURE_COUNT=100


def model_columns(columns: list[dict],context: bool) -> list[dict]:
    """
    機能: 元100列の順序を保ち、属性入り方式だけに三つの時帯列を追加する。
    引数: columns (list[dict]) 元100列、context (bool) 属性列追加の有無。
    返り値: list[dict] 型の100列又は103列。属性列は技術役割に数えない。
    """
    assert len(columns)==BASE_FEATURE_COUNT and len({c['name'] for c in columns})==BASE_FEATURE_COUNT
    result=[dict(c) for c in columns]
    if context:
        result += [{'name':name,'role':'context','technical':False} for name in CONTEXT_NAMES]
    return result


# ----------------------------------------
def with_context(matrix: object,bands: object) -> object:
    """
    機能: 数値特徴へ当時q0の三時間帯onehotを加える。
    引数: matrix (object) [N,100]、bands (object) [N]の0/1/2整数。
    返り値: numpy.ndarray 型の[N,103]。元の数値・NaNを変更しない。
    """
    import numpy as np
    X=np.asarray(matrix,dtype=np.float64)
    raw=np.asarray(bands)
    assert X.ndim==2 and X.shape[1]==BASE_FEATURE_COUNT
    assert raw.ndim==1 and len(raw)==len(X) and raw.dtype.kind in ('i','u')
    assert np.isin(raw,(0,1,2)).all()
    onehot=np.zeros((len(X),3),dtype=np.float64)
    onehot[np.arange(len(X)),raw.astype(np.int64)]=1
    return np.concatenate((X,onehot),axis=1)


# ----------------------------------------
def split_indices(exported: dict,columns: list[dict]) -> list[int]:
    """
    機能: 保存された対称木の実分岐を入力列番号へ写す。
    引数: exported (dict) CatBoost公開JSON、columns (list[dict]) 100又は103列。
    返り値: list[int] 型の使用列番号。重要度による代用ではない。
    """
    names=[c['name'] for c in columns]
    assert len(names) in (100,103) and len(names)==len(set(names))
    fields={f['feature_index']:f for f in exported['features_info']['float_features']}
    used=set()
    for tree in exported['oblivious_trees']:
        for split in tree.get('splits') or []:
            assert split['split_type']=='FloatFeature'
            field=fields[split['float_feature_index']]
            index=field['flat_feature_index']
            assert 0<=index<len(names) and field['feature_id']==names[index]
            used.add(index)
    return sorted(used)


# ----------------------------------------
def known_roles(vector: object,columns: list[dict],indices: list[int]) -> list[str]:
    """
    機能: 当該q0で既知の実分岐技術列の役割だけを数える。
    引数: vector (object) 元100特徴、columns (list[dict]) 元100列、indices (list[int]) 使用列。
    返り値: list[str] 型の役割。時帯3列・執行3列・未知値は根拠に数えない。
    """
    assert len(vector)==len(columns)==BASE_FEATURE_COUNT
    roles=set()
    for index in indices:
        if index>=BASE_FEATURE_COUNT:
            continue
        assert index>=0
        value=vector[index]
        if columns[index]['name'] not in EXCLUDED_ROLE_COLUMNS and value is not None and math.isfinite(float(value)):
            roles.add(columns[index]['role'])
    return sorted(roles)


# ----------------------------------------
def fit_past(X: object,y: object,weights: object,columns: list[dict],model_path: Path) -> tuple:
    """
    機能: 呼出側が過去だけへ射影した数値配列から固定モデルを学習する。
    引数: X (object) [N,100|103]、y (object) 0=A/1=N/2=F、weights (object) 平均1の正重み、
          columns (list[dict]) 入力列、model_path (Path) 未作成の保存先。
    返り値: tuple[object,dict] 型のモデルと配列/構造の指紋。現在場・全期間ラベルを受け取らない。
    """
    import numpy as np
    import catboost
    from catboost import CatBoostClassifier,Pool
    assert catboost.__version__=='1.2.10'
    matrix=np.ascontiguousarray(X,dtype='<f8')
    raw_labels=np.asarray(y);raw_mass=np.asarray(weights)
    assert raw_labels.ndim==raw_mass.ndim==1 and raw_labels.dtype.kind in ('i','u')
    assert raw_mass.dtype.kind in ('i','u','f')
    labels=np.ascontiguousarray(raw_labels,dtype='<i8');mass=np.ascontiguousarray(raw_mass,dtype='<f8')
    assert matrix.ndim==2 and matrix.shape[1]==len(columns) and len(columns) in (100,103)
    assert len(matrix)==len(labels)==len(mass)>0 and set(labels.tolist())=={0,1,2}
    assert not np.isinf(matrix).any() and np.isfinite(mass).all() and (mass>0).all()
    assert math.isclose(float(mass.mean()),1,rel_tol=1e-12)
    names=[c['name'] for c in columns]
    signature=hashlib.sha256()
    signature.update(json.dumps(names,ensure_ascii=False,separators=(',',':')).encode('utf-8'))
    for array in (matrix,labels,mass):
        signature.update(str(array.shape).encode('ascii'));signature.update(array.tobytes())
    model=CatBoostClassifier(**PARAMS)
    model.fit(Pool(matrix,label=labels,weight=mass,feature_names=names))
    assert list(model.classes_)==[0,1,2] and not model_path.exists()
    model_path.parent.mkdir(parents=True,exist_ok=True)
    model.save_model(str(model_path),format='json')
    body=model_path.read_bytes();exported=json.loads(body)
    indices=split_indices(exported,columns)
    stable={name:exported[name] for name in ('features_info','oblivious_trees','scale_and_bias')}
    return model,{'status':'trained','model_file':model_path.name,'physical_sha256':hashlib.sha256(body).hexdigest(),
        'structure_sha256':hashlib.sha256(json.dumps(stable,sort_keys=True,separators=(',',':')).encode()).hexdigest(),
        'training_array_sha256':signature.hexdigest(),'used_indices':indices,
        'used_columns':[names[i] for i in indices],'technical_used_indices':[i for i in indices if i<100],
        'classes':list(map(int,model.classes_)),'parameters':dict(PARAMS),'catboost':catboost.__version__,
        'feature_count':len(columns)}


# ----------------------------------------
def predict_both(model: object,buy_X: object,sell_X: object,columns: list[dict]) -> tuple[list,list]:
    """
    機能: 同じ分類器・同じAPIで買売双方を予測する。
    引数: model (object)、buy_X/sell_X (object) 同数100又は103列、columns (list[dict])。
    返り値: tuple[list,list] 型の買売各[P(A),P(N),P(F)]。ラベルを受け取らない。
    """
    import numpy as np
    from catboost import Pool
    buy=np.asarray(buy_X,dtype=np.float64);sell=np.asarray(sell_X,dtype=np.float64)
    assert buy.shape==sell.shape and buy.ndim==2 and buy.shape[1]==len(columns)
    assert len(columns) in (100,103) and not np.isinf(buy).any() and not np.isinf(sell).any()
    if not len(buy):
        return [],[]
    classes=list(map(int,model.classes_));assert sorted(classes)==[0,1,2]
    positions=[classes.index(v) for v in (0,1,2)]
    pool=Pool(np.concatenate((buy,sell)),feature_names=[c['name'] for c in columns])
    values=np.asarray(model.predict_proba(pool,thread_count=1))[:,positions].tolist()
    return values[:len(buy)],values[len(buy):]


# ----------------------------------------
def decide(buy: object,sell: object,buy_p: list|None,sell_p: list|None,
           columns: list[dict],used_indices: list[int],thresholds: dict[str,float]) -> dict:
    """
    機能: 151と同じ共通品質・確率差・複数技術役割で閾値別方向を選ぶ。
    引数: buy/sell (object) 元100X、buy_p/sell_p (list|None)、columns (list[dict]) 元100列、
          used_indices (list[int]) 実分岐、thresholds (dict[str,float]) 条件付き順行確率閾値。
    返り値: dict 型の判断。高score側が不適格でも低score側へ代用しない。
    """
    result={'directions':{name:0 for name in thresholds},'probabilities':None,
            'scores':None,'selected_side':0,'known_roles':[],'reason':'untrained'}
    if buy_p is None or sell_p is None:
        assert buy_p is None and sell_p is None
        return result
    for p in (buy_p,sell_p):
        assert len(p)==3 and all(math.isfinite(float(v)) and 0<=v<=1 for v in p)
        assert math.isclose(sum(p),1,abs_tol=1e-9)
    a=buy_p[2]-buy_p[0];b=sell_p[2]-sell_p[0]
    result.update(probabilities={'buy':list(buy_p),'sell':list(sell_p)},scores={'buy':a,'sell':b})
    if a-b>=.05:
        side,vector,p=1,buy,buy_p
    elif b-a>=.05:
        side,vector,p=-1,sell,sell_p
    else:
        result['reason']='score_margin_under_0.05'
        return result
    result['selected_side']=side
    index={c['name']:i for i,c in enumerate(columns)}
    spread=vector[index['q0_spread_points']];gap=vector[index['q0_last_minus_m1_close_atr5_to_side']]
    if spread is None or gap is None or not math.isfinite(float(spread)) or not math.isfinite(float(gap)) or not (0<spread<=20 and -1<=gap<=1):
        result['reason']='q0_common_not_met'
        return result
    roles=known_roles(vector,columns,used_indices);result['known_roles']=roles
    if len(roles)<2:
        result['reason']='known_technical_roles_under_2'
        return result
    denominator=p[2]+p[0];conditional=p[2]/denominator if denominator>0 else None
    result['conditional_forward']=conditional
    if p[2]<.4:
        result['reason']='forward_probability_under_0.40'
        return result
    result['reason']='threshold_wait'
    for name,threshold in thresholds.items():
        assert 0<threshold<1
        if conditional is not None and conditional>=threshold:
            result['directions'][name]=side;result['reason']='selected'
    return result
