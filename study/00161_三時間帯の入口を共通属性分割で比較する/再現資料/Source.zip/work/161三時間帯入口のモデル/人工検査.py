"""161モデルの共通同体・時帯を技術と数えない制約・教師subsetを人工値で確認する。"""
from pathlib import Path
import importlib.util
import json
import math
import sys

import numpy as np
import model161 as model
import training161 as training

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def module(path: Path,name: str) -> object:
    """
    機能: 人工比較用に停止済み旧純部品をmainなしで読む。
    引数: path (Path)、name (str)。返り値: object 型のモジュール。
    """
    spec=importlib.util.spec_from_file_location(name,path)
    result=importlib.util.module_from_spec(spec);sys.modules[name]=result
    spec.loader.exec_module(result)
    return result


# ----------------------------------------
def columns() -> list[dict]:
    """
    機能: 共通品質名と異役割を持つ人工100列を作る。
    引数: なし。返り値: list[dict] 型の人工列定義。
    """
    names=['q0_spread_points','q0_spread_125_ratio','q0_entry_minus_last_atr5_to_side',
           'q0_last_minus_m1_close_atr5_to_side','人工構造','人工勢い']
    return [{'name':name,'role':'structure' if i==4 else 'momentum' if i==5 else 'trend'}
            for i,name in enumerate(names+[f'人工{i}' for i in range(6,100)])]


# ----------------------------------------
def teacher_fixture() -> tuple:
    """
    機能: 10過去場・2時間区画に分かれる人工教師を作る。
    引数: なし。返り値: tuple の元teacher行・帯配列・場開始。
    """
    starts=[100000+s*10000 for s in range(11)]
    rows=[];bands=[]
    for s in range(10):
        for j in range(300):
            i=len(rows);block=0 if j<100 else 1
            q0=starts[s]+block*3600+j
            rows.append({'case_id':f'case{i}','event_id':f'event{i}','session_index':s,
                'q0_index':j,'q0_line':j+1,'q0_time':q0,'known_at':q0+1,
                'pair_complete':True,'label_buy':j%3-1,'label_sell':1-j%3})
            bands.append(0 if j%2==0 else 1 if j%4==1 else 2)
    return rows,np.asarray(bands,dtype=np.int8),starts


# ----------------------------------------
def main() -> None:
    """
    機能: 自然値を読まず7群のモデル人工と旧151の同体比較を実行する。
    引数: なし。返り値: None。出力はwork内の人工モデルだけ。
    """
    base=columns();vector=np.zeros(100);vector[0]=10
    thresholds={'P70':.7,'P65':.65,'P60':.6}
    assert len(model.model_columns(base,False))==100 and len(model.model_columns(base,True))==103
    assert model.known_roles(vector,base,[4,100,101])==['structure']
    assert model.known_roles(vector,base,[0,1,2,100,101,102])==[]
    result=model.decide(vector,vector,[.1,.2,.7],[.6,.3,.1],base,[4,5,100],thresholds)
    assert result['directions']=={name:1 for name in thresholds}
    opposite=model.decide(vector,vector,[.6,.3,.1],[.1,.2,.7],base,[4,5,100],thresholds)
    assert opposite['directions']=={name:-1 for name in thresholds}
    insufficient=model.decide(vector,vector,[.1,.2,.7],[.6,.3,.1],base,[4,100,101],thresholds)
    assert insufficient['reason']=='known_technical_roles_under_2'
    missing=vector.copy();missing[5]=np.nan
    assert model.decide(missing,vector,[.1,.2,.7],[.6,.3,.1],base,[4,5],thresholds)['reason']=='known_technical_roles_under_2'
    bad=vector.copy();bad[0]=30
    denied=model.decide(bad,vector,[.1,.2,.7],[.6,.3,.1],base,[4,5],thresholds)
    assert denied['selected_side']==1 and not any(denied['directions'].values())

    # ----------------------------------------
    matrix=np.zeros((6,100));matrix[0,4]=np.nan
    augmented=model.with_context(matrix,np.asarray([0,0,1,1,2,2],dtype=np.int8))
    assert np.array_equal(augmented[:,:100],matrix,equal_nan=True)
    assert np.array_equal(augmented[:,100:],np.repeat(np.eye(3),2,axis=0))
    assert np.array_equal(augmented[0::2,100:],augmented[1::2,100:])

    # ----------------------------------------
    teacher=module(ROOT/'work/過去場だけの教師選択と時間区画重み/教師選択.py','teacher_art161')
    rows,bands,starts=teacher_fixture()
    selected=teacher.select_past_teachers(rows,starts,10)
    subset=training.select_timeband(selected,bands,0)
    assert selected['ready'] and subset['ready'] and subset['physical_pair_count']==1500
    assert len(subset['contributing_sessions'])==10
    assert math.isclose(subset['side_weight_mean'],1,rel_tol=1e-14)
    assert sorted(set(p['side_weight'] for p in subset['pairs']))==[.75,1.5]
    sparse=training.select_timeband(selected,bands,1)
    assert not sparse['ready'] and sparse['physical_pair_count']==750
    assert sparse['ready_reasons']==['physical_pairs_under_1000']
    assert selected['physical_pair_count']==3000 and all(p['side_weight'] in (.75,1.5) for p in selected['pairs'])
    first=selected['pairs'][0]['source_index']
    assert int(bands[first])==0 and first not in sparse['indices']
    audit=training.selection_audit(subset,[])
    assert len(audit['canonical_teacher_sha256'])==64 and audit['max_label_known_at']<starts[10]

    # ----------------------------------------
    output=HERE/'人工モデル'
    output.mkdir(exist_ok=True)
    X=np.zeros((90,100));y=np.arange(90,dtype=np.int64)%3;mass=np.ones(90)
    X[:,0]=10;X[:,4]=y;X[:,5]=np.arange(90)%7;X[0,8]=np.nan
    old=module(ROOT/'work/151過去場判別/model151.py','old_model_art161')
    old_path=output/'旧151.json';new_path=output/'共通161.json';context_path=output/'時帯161.json'
    for p in (old_path,new_path,context_path):
        if p.exists():
            assert p.resolve().is_relative_to(HERE.resolve())
            p.unlink()
    old_model,old_info=old.fit_past(X,y,mass,base,old_path)
    new_model,new_info=model.fit_past(X,y,mass,base,new_path)
    assert old_info['training_array_sha256']==new_info['training_array_sha256']
    assert old_info['structure_sha256']==new_info['structure_sha256']
    a,b=model.predict_both(new_model,X[:4],X[4:8],base)
    c,d=old.predict_both(old_model,X[:4],X[4:8],base)
    assert a==c and b==d
    flat=np.zeros_like(X);flat[:,0]=10
    context_X=model.with_context(flat,y.astype(np.int8))
    context_model,context_info=model.fit_past(context_X,y,mass,model.model_columns(base,True),context_path)
    assert any(i>=100 for i in context_info['used_indices'])
    assert model.known_roles(flat[0],base,context_info['used_indices'])==[]
    cp,sp=model.predict_both(context_model,context_X[:3],context_X[3:6],model.model_columns(base,True))
    for p in cp+sp:
        assert math.isclose(sum(p),1,abs_tol=1e-12)
    print(json.dumps({'成功':True,'人工群':7,'旧151共通の学習配列と構造同体':True,
                     '属性分岐を技術役割に数えない':True,'自然入力読取':False},ensure_ascii=False))


if __name__=='__main__':
    main()
