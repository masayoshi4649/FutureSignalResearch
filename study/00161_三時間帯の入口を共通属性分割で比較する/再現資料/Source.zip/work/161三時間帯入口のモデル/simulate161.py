"""161の三方式を場開始前に固定し、全q0を教師と切り離して判定する。"""
from pathlib import Path
from collections import Counter
import json
import math

MODES=[{'id':'COMMON','context':False,'split':False},
       {'id':'CONTEXT','context':True,'split':False},
       {'id':'SPLIT','context':False,'split':True}]
THRESHOLDS={'P70':.7,'P65':.65,'P60':.6}


def validate_book(book: dict,model: object,training: object) -> None:
    """
    機能: 共通方式・属性方式・帯別方式の固定仕様を自然入力の利用前に照合する。
    引数: book (dict) 固定条件、model/training (object) モデルと教師選択の部品。
    返り値: None。不一致は停止する。
    """
    assert book['trial']==161
    assert book['model_modes']==MODES
    assert book['classifier_parameters']==model.PARAMS
    setting=book['training'];selection=book['selection']
    assert setting['window_sessions']==training.WINDOW_SESSIONS==20
    assert setting['minimum_physical_pairs']==training.MIN_PAIRS==1000
    assert setting['minimum_contributing_sessions']==training.MIN_CONTRIBUTING_SESSIONS==8
    assert set(setting['minimum_classes'])==training.LABELS=={-1,0,1}
    assert setting['label_to_class']=={'-1':0,'0':1,'1':2}
    assert selection['thresholds']==THRESHOLDS
    assert selection['minimum_score_margin']==.05
    assert selection['minimum_forward_probability']==.4
    assert selection['minimum_known_roles']==2
    assert set(selection['role_excluded_columns'])==model.EXCLUDED_ROLE_COLUMNS
    assert selection['q1_for_prediction'] is False


# ----------------------------------------
def fit_selection(features: object,teachers: object,selected: dict,current: int,
                  q0_timeband: object,context: bool,model_id: str,output: Path,
                  model: object,training: object,columns: list[dict]) -> tuple:
    """
    機能: 一つの過去成熟選択を学習し、監査と数値モデルだけを返す。
    引数: features/teachers (object)、selected (dict)、current (int)、q0_timeband (object)、
          context (bool)、model_id (str)、output (Path)、model/training (object)、columns (list[dict])。
    返り値: tuple の実行用モデル束と監査。支持不足時は学習せずNoneを返す。
    """
    used_features=[];runtime=None;ref=None
    if selected['ready']:
        X,y,weights,used_features=training.training_arrays(features,teachers,selected,current,
            q0_timeband,context,model)
        input_columns=model.model_columns(columns,context)
        learner,ref=model.fit_past(X,y,weights,input_columns,output/'models'/f'{model_id}.json')
        ref={**ref,'model_id':model_id}
        runtime=(learner,ref,input_columns,context)
    audit=training.selection_audit(selected,used_features)
    audit.update(model_id=model_id if runtime is not None else None,context=context,model=ref)
    return runtime,audit


# ----------------------------------------
def predict_current(features: object,indices: list[int],runtime: tuple|None,
                    q0_timeband: object,model: object) -> tuple:
    """
    機能: 当場の特徴とq0時帯だけを固定済みモデルへ適用する。
    引数: features (object)、indices (list[int]) 当場行、runtime (tuple|None)、
          q0_timeband (object)、model (object)。
    返り値: tuple の買売確率と使用列。取得結合・観測・教師の引数を持たない。
    """
    if runtime is None:
        return [None]*len(indices),[None]*len(indices),[]
    learner,ref,columns,context=runtime
    buy=features.buy_X[indices];sell=features.sell_X[indices]
    if context:
        bands=q0_timeband[indices]
        buy=model.with_context(buy,bands);sell=model.with_context(sell,bands)
    buy_p,sell_p=model.predict_both(learner,buy,sell,columns)
    assert len(buy_p)==len(sell_p)==len(indices)
    return buy_p,sell_p,ref['used_indices']


# ----------------------------------------
def simulate(features: object,teachers: object,columns: list[dict],q0_timeband: object,
             teacher_timeband: object,book: dict,output: Path,model: object,
             training: object,teacher_selector: object) -> tuple[list,list]:
    """
    機能: 三方式を同じ場開始時計で比較し、取得を参照せず全q0の原判断を固定する。
    引数: features/teachers (object)、columns (list[dict]) 元100列、q0_timeband/teacher_timeband (object)、
          book (dict)、output (Path)、model/training (object)、teacher_selector (callable)。
    返り値: tuple[list,list] の全q0判断と場別監査。帯別支持不足は同じ当場の共通モデルへ戻す。
    """
    import numpy as np
    validate_book(book,model,training)
    assert list(features.columns)==[c['name'] for c in columns]
    assert len(columns)==100 and features.buy_X.shape==features.sell_X.shape==(len(features.q0_meta),100)
    bands=np.asarray(q0_timeband);teacher_bands=np.asarray(teacher_timeband)
    assert bands.ndim==teacher_bands.ndim==1
    assert len(bands)==len(features.q0_meta) and len(teacher_bands)==len(teachers.rows)
    assert bands.dtype.kind in ('i','u') and teacher_bands.dtype.kind in ('i','u')
    assert np.isin(bands,(0,1,2)).all() and np.isin(teacher_bands,(0,1,2)).all()
    raw_starts=[scene['start'] for scene in features.scenes]
    assert all(type(v) in (int,float) and math.isfinite(v) and int(v)==v for v in raw_starts)
    starts=[int(v) for v in raw_starts]
    assert starts==sorted(set(starts))
    assert len({q['event_id'] for q in features.q0_meta})==len(features.q0_meta)
    decisions=[];audits=[]
    for current,scene in enumerate(features.scenes):
        selected=teacher_selector(teachers.rows,starts,current)
        assert selected['current_scene_start']==scene['start']
        assert selected['window']['first_session_index']==max(0,current-20)
        active=[i for i,q in enumerate(features.q0_meta) if q['session_index']==current]
        active_bands=sorted(set(int(bands[i]) for i in active))
        common,common_audit=fit_selection(features,teachers,selected,current,bands,False,
            f'{current:03d}_COMMON',output,model,training,columns)
        context,context_audit=fit_selection(features,teachers,selected,current,bands,True,
            f'{current:03d}_CONTEXT',output,model,training,columns)
        runtimes={'COMMON':common,'CONTEXT':context};split_models={};split_audits={}
        for band in active_bands:
            subset=training.select_timeband(selected,teacher_bands,band)
            split_model,split_audit=fit_selection(features,teachers,subset,current,bands,False,
                f'{current:03d}_SPLIT_{band}',output,model,training,columns)
            split_models[band]=split_model
            split_audits[band]=split_audit
        forecasts={};reason_counts={};fallback_counts=Counter()
        for mode in ('COMMON','CONTEXT','SPLIT'):
            parts=([active] if mode!='SPLIT' else [[i for i in active if int(bands[i])==b] for b in active_bands])
            forecasts[mode]={};reason_counts[mode]=Counter()
            for indices in parts:
                if not indices:
                    continue
                band=int(bands[indices[0]]) if mode=='SPLIT' else None
                runtime=split_models[band] if mode=='SPLIT' else runtimes[mode]
                fallback=False;fallback_reasons=[]
                if mode=='SPLIT' and runtime is None:
                    fallback=True;fallback_reasons=split_audits[band]['ready_reasons']
                    runtime=common
                    fallback_counts['COMMON' if runtime is not None else 'WAIT']+=len(indices)
                buy_p,sell_p,used=predict_current(features,indices,runtime,bands,model)
                for offset,index in enumerate(indices):
                    vote=model.decide(features.buy_X[index],features.sell_X[index],buy_p[offset],sell_p[offset],
                        columns,used,THRESHOLDS)
                    info={'requested_mode':mode,'effective_mode':('COMMON' if fallback else mode) if runtime is not None else 'WAIT',
                        'model_id':runtime[1]['model_id'] if runtime is not None else None,
                        'timeband':int(bands[index]),'fallback':fallback,'fallback_reasons':list(fallback_reasons),
                        'used_indices':list(used),'technical_used_indices':[i for i in used if i<100]}
                    forecasts[mode][index]={'prediction':vote,**info}
                    reason_counts[mode][vote['reason']]+=1
        for index in active:
            q0=features.q0_meta[index];directions={};evidence=[];predictions={}
            for mode in ('COMMON','CONTEXT','SPLIT'):
                result=forecasts[mode][index];predictions[mode]=result
                vote=result['prediction']
                for threshold,side in vote['directions'].items():
                    policy=f'{mode}_{threshold}';directions[policy]=side
                    if side:
                        evidence.append({'rule':policy,'signal_side':side,'order_side':side,
                            'roles':list(vote['known_roles']),'model_id':result['model_id'],
                            'requested_mode':mode,'effective_mode':result['effective_mode'],
                            'timeband':int(bands[index]),'fallback':result['fallback']})
            decisions.append({**q0,'q0_timeband':int(bands[index]),'predictions':predictions,
                'decision':{'directions':directions,'conflicts':{name:False for name in directions},'evidence':evidence}})
        audits.append({'session_index':current,'session':scene['session'],'current_start':scene['start'],
            'all_current_feature_rows':len(active),'active_timebands':active_bands,
            'models':{'COMMON':common_audit,'CONTEXT':context_audit,
                      'SPLIT':{str(b):split_audits[b] for b in active_bands}},
            'split_fallback_q0_counts':dict(fallback_counts),
            'prediction_reasons':{mode:dict(counts) for mode,counts in reason_counts.items()},
            'no_retraining_within_scene':True})
        print(json.dumps({'場':current+1,'全場':len(features.scenes),'session':scene['session'],
            '共通学習':common is not None,'属性学習':context is not None,
            '帯別学習数':sum(v is not None for v in split_models.values()),
            '判断数':len(active),'帯別共通戻し':dict(fallback_counts)},ensure_ascii=False),flush=True)
    assert len(decisions)==len(features.q0_meta)
    assert [d['event_id'] for d in decisions]==[q['event_id'] for q in features.q0_meta]
    return decisions,audits
