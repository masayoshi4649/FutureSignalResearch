"""自然入力を読まず、三方式の学習時計・支持不足・旧151同体を検査する。"""
from contextlib import redirect_stdout
from pathlib import Path
from types import SimpleNamespace
import copy
import hashlib
import io
import json

import numpy as np
import model161
import simulate161
import training161
import 人工検査

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def fixture() -> tuple:
    """
    機能: 過去10場と当場を持つ人工の実側特徴・教師だけを作る。
    引数: なし。返り値: tuple のfeatures/teachers/元100列/教師帯。
    """
    rows,bands,starts=人工検査.teacher_fixture();base=人工検査.columns()
    for i,row in enumerate(rows):
        row['feature_index']=i
    meta=[{'event_id':row['event_id'],'session_index':row['session_index'],'q0_time':row['q0_time']}
          for row in rows]
    meta += [{'event_id':f'当場{i}','session_index':10,'q0_time':starts[10]+i+1} for i in range(3)]
    buy=np.zeros((len(meta),100));sell=np.zeros_like(buy)
    buy[:,0]=sell[:,0]=10;buy[:,4]=1;sell[:,4]=-1
    buy[:,5]=sell[:,5]=np.arange(len(meta))%7;buy[11,8]=np.nan;sell[12,8]=np.nan
    features=SimpleNamespace(columns=tuple(c['name'] for c in base),buy_X=buy,sell_X=sell,q0_meta=meta,
        scenes=[{'start':v,'session':f'人工場{s}'} for s,v in enumerate(starts)],
        q0_timeband=np.concatenate((bands,np.arange(3,dtype=np.int8))))
    teachers=SimpleNamespace(rows=rows)
    return features,teachers,base,bands


# ----------------------------------------
def book() -> dict:
    """
    機能: モデル部品の固定条件と同じ人工仕様を作る。
    引数: なし。返り値: dict 型の人工仕様。自然試行の採否には使わない。
    """
    return {'trial':161,'model_modes':copy.deepcopy(simulate161.MODES),
        'classifier_parameters':dict(model161.PARAMS),
        'training':{'window_sessions':20,'minimum_physical_pairs':1000,'minimum_contributing_sessions':8,
            'minimum_classes':[-1,0,1],'label_to_class':{'-1':0,'0':1,'1':2}},
        'selection':{'thresholds':dict(simulate161.THRESHOLDS),'minimum_score_margin':.05,
            'minimum_forward_probability':.4,'minimum_known_roles':2,
            'role_excluded_columns':sorted(model161.EXCLUDED_ROLE_COLUMNS),'q1_for_prediction':False}}


# ----------------------------------------
def fake_model(calls: list) -> object:
    """
    機能: 実学習を行わず数値引数を記録する人工モデル束を作る。
    引数: calls (list) 呼出記録。返り値: object 型の151互換部品。
    """
    def fit(X: object,y: object,weights: object,columns: list[dict],path: Path) -> tuple:
        """
        機能: 人工fitへ届いた列数・ラベル・重みを指紋で記録する。
        引数: X/y/weights (object)、columns (list[dict])、path (Path)。
        返り値: tuple の人工モデルと人工監査。ディスクへモデルを書かない。
        """
        assert X.shape[1] in (100,103) and set(y.tolist())=={0,1,2}
        assert np.isfinite(weights).all() and (weights>0).all() and abs(weights.mean()-1)<1e-12
        signature=hashlib.sha256(X.tobytes()+y.tobytes()+weights.tobytes()).hexdigest()
        calls.append({'name':path.name,'shape':list(X.shape),'sha':signature})
        return SimpleNamespace(signature=signature),{'training_array_sha256':signature,
            'structure_sha256':signature,'used_indices':[4,5]+([100] if len(columns)==103 else []),
            'model_file':path.name}
    # ----------------------------------------
    def predict(learner: object,buy: object,sell: object,columns: list[dict]) -> tuple:
        """
        機能: 実側特徴の符号を用いて人工確率を返す。
        引数: learner (object)、buy/sell (object)、columns (list[dict])。
        返り値: tuple の買売確率。教師・取得を読む経路を持たない。
        """
        assert len(buy)==len(sell) and buy.shape[1]==sell.shape[1]==len(columns)
        return [[.1,.2,.7] if row[4]>0 else [.6,.3,.1] for row in buy],\
               [[.1,.2,.7] if row[4]>0 else [.6,.3,.1] for row in sell]
    return SimpleNamespace(PARAMS=dict(model161.PARAMS),EXCLUDED_ROLE_COLUMNS=model161.EXCLUDED_ROLE_COLUMNS,
        model_columns=model161.model_columns,with_context=model161.with_context,fit_past=fit,
        predict_both=predict,decide=model161.decide)


# ----------------------------------------
def run(features: object,teachers: object,base: list[dict],bands: object,selector: object) -> tuple:
    """
    機能: 人工数値だけで三方式を走らせ呼出記録も返す。
    引数: features/teachers (object)、base (list[dict])、bands (object)、selector (callable)。
    返り値: tuple の判断・監査・fit記録。自然ファイルを開かない。
    """
    calls=[]
    with redirect_stdout(io.StringIO()):
        decisions,audits=simulate161.simulate(features,teachers,base,features.q0_timeband,bands,book(),
            HERE/'実行器人工出力',fake_model(calls),training161,selector)
    return decisions,audits,calls


# ----------------------------------------
def main() -> None:
    """
    機能: 三方式の過去時計・フォールバック・共通同体を人工で確かめる。
    引数: なし。返り値: None。自然学習・取得結合・採否は実施しない。
    """
    teacher=人工検査.module(ROOT/'work/過去場だけの教師選択と時間区画重み/教師選択.py','teacher_simart161')
    old=人工検査.module(ROOT/'work/151過去場判別/run151.py','old_run_simart161')
    features,teachers,base,bands=fixture()
    decisions,audits,calls=run(features,teachers,base,bands,teacher.select_past_teachers)
    assert len(decisions)==3003 and len(audits)==11 and len(calls)==9
    assert all(not audit['models']['COMMON']['ready'] for audit in audits[:8])
    assert all(audit['models']['COMMON']['ready'] for audit in audits[8:])
    assert all(set(row['decision']['directions'].values())=={0} for row in decisions[:2400])
    current=[r for r in decisions if r['session_index']==10]
    assert len(current)==3
    assert current[0]['predictions']['SPLIT']['effective_mode']=='SPLIT'
    assert all(r['predictions']['SPLIT']['effective_mode']=='COMMON' for r in current[1:])
    assert all(r['predictions']['SPLIT']['fallback'] for r in current[1:])
    assert all(r['predictions']['SPLIT']['fallback_reasons']==['physical_pairs_under_1000'] for r in current[1:])
    assert current[0]['predictions']['CONTEXT']['used_indices']==[4,5,100]
    assert current[0]['predictions']['CONTEXT']['prediction']['known_roles']==['momentum','structure']
    assert all(audit['no_retraining_within_scene'] for audit in audits)
    assert all(audit['models']['COMMON']['max_label_known_at']<audit['current_start']
               for audit in audits if audit['models']['COMMON']['ready'])

    # ----------------------------------------
    old_calls=[]
    with redirect_stdout(io.StringIO()):
        old_decisions,old_audits=old.simulate(features,teachers,base,
            {'classifier_parameters':dict(model161.PARAMS),'selection':{'thresholds':dict(simulate161.THRESHOLDS)}},
            HERE/'旧実行器人工出力',fake_model(old_calls),teacher.select_past_teachers)
    assert [d['prediction'] for d in old_decisions]==[d['predictions']['COMMON']['prediction'] for d in decisions]
    assert [c['sha'] for c in old_calls]==[c['sha'] for c in calls if '_COMMON.' in c['name']]
    assert [a['physical_pair_count'] for a in old_audits]==[a['models']['COMMON']['physical_pair_count'] for a in audits]

    # ----------------------------------------
    changed=SimpleNamespace(rows=copy.deepcopy(teachers.rows))
    for row in changed.rows:
        if row['session_index']==9:
            row['label_buy']=-row['label_buy'];row['label_sell']=-row['label_sell']
    changed_decisions,changed_audits,changed_calls=run(features,changed,base,bands,teacher.select_past_teachers)
    assert decisions[:3000]==changed_decisions[:3000]
    assert audits[:10]==changed_audits[:10]
    unchanged=[c for c in calls if not c['name'].startswith('010_')]
    assert unchanged==[c for c in changed_calls if not c['name'].startswith('010_')]
    assert calls!=changed_calls
    print(json.dumps({'成功':True,'人工群':5,'人工q0':len(decisions),'人工fit':len(calls),
        '旧151共通全q0同体':True,'後場ラベル変更が前場へ無影響':True,'自然入力読取':False},ensure_ascii=False))


if __name__=='__main__':
    main()
