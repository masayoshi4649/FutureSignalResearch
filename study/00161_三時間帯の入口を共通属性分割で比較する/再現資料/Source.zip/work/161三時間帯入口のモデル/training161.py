"""全体で正準化した過去教師から時帯subsetを作り、同じ区画重みで学習配列へ写す。"""
from collections import Counter
import copy
import hashlib
import json
import math
from numbers import Integral

WINDOW_SESSIONS=20
MIN_PAIRS=1000
MIN_CONTRIBUTING_SESSIONS=8
LABELS=frozenset((-1,0,1))


def select_timeband(selected: dict,teacher_timeband: object,band: int) -> dict:
    """
    機能: 共通選択器が過去・成熟・正準化した教師を一つの時間帯へ限定する。
    引数: selected (dict) 共通の選択結果、teacher_timeband (object) 元teacher行ごとの0/1/2、
          band (int) 対象帯。返り値: dict 型のsubset選択。正準化をやり直さず支持・重みだけ再計算する。
    """
    assert band in (0,1,2)
    assert selected['window']['limit']==WINDOW_SESSIONS
    pairs=[]
    for source in selected['pairs']:
        index=source['source_index'];value=teacher_timeband[index]
        assert isinstance(value,Integral) and not isinstance(value,bool) and value in (0,1,2)
        if int(value)==band:
            pairs.append(copy.deepcopy(source))
    blocks=Counter((p['session_index'],p['block_index']) for p in pairs)
    sessions={p['session_index'] for p in pairs}
    classes={v for p in pairs for v in (p['label_buy'],p['label_sell'])}
    count=len(pairs);active=len(blocks)
    for p in pairs:
        p['side_weight']=count/(active*blocks[p['session_index'],p['block_index']])
    reasons=[]
    if count<MIN_PAIRS:reasons.append('physical_pairs_under_1000')
    if len(sessions)<MIN_CONTRIBUTING_SESSIONS:reasons.append('contributing_sessions_under_8')
    if classes!=LABELS:reasons.append('three_classes_not_present')
    return {'ready':not reasons,'ready_reasons':reasons,'indices':[p['source_index'] for p in pairs],
        'pairs':pairs,'current_scene_index':selected['current_scene_index'],
        'current_scene_start':selected['current_scene_start'],'window':copy.deepcopy(selected['window']),
        'maturity':copy.deepcopy(selected['maturity']),'physical_pair_count':count,
        'contributing_sessions':sorted(sessions),'contributing_session_count':len(sessions),'classes':sorted(classes),
        'active_block_count':active,'blocks':[{'session_index':s,'block_index':b,'physical_pairs':n,
            'side_weight':count/(active*n)} for (s,b),n in sorted(blocks.items())],
        'side_weight_mean':sum(2*p['side_weight'] for p in pairs)/(2*count) if count else None,
        'weight_formula':'Npairs/(B_active*n_pairs_in_block)','native_fallback':False,
        'timeband':band,'canonicalization':'共通の過去成熟正準pairを先に固定し、時帯内で再正準化しない',
        'global_physical_pair_count':selected['physical_pair_count']}


# ----------------------------------------
def training_arrays(features: object,teachers: object,selected: dict,current_index: int,
                    q0_timeband: object,context: bool,model_module: object) -> tuple:
    """
    機能: 過去成熟subsetのBUY/SELL実側Xと三クラスを時系列の配列へ写す。
    引数: features/teachers (object)、selected (dict)、current_index (int)、q0_timeband (object)、
          context (bool)、model_module (object) onehot純部品。
    返り値: tuple のX/y/weights/元feature_index。現場・未来教師を許容しない。
    """
    import numpy as np
    assert selected['ready']
    indices=[];labels=[];mass=[]
    for p in selected['pairs']:
        row=teachers.rows[p['source_index']];index=row['feature_index'];q0=features.q0_meta[index]
        assert row['pair_complete'] and row['session_index']<current_index
        assert row['known_at']<features.scenes[current_index]['start']
        assert row['event_id']==q0['event_id']==p['event_id']
        assert row['session_index']==q0['session_index']
        assert row['q0_time']==q0['q0_time']==p['q0_time']
        assert (row['label_buy'],row['label_sell'])==(p['label_buy'],p['label_sell'])
        assert all(type(v) is int and v in LABELS for v in (row['label_buy'],row['label_sell']))
        if 'timeband' in selected:
            assert int(q0_timeband[index])==selected['timeband']
        indices.append(index);labels.extend((row['label_buy']+1,row['label_sell']+1))
        mass.extend((p['side_weight'],p['side_weight']))
    matrix=np.empty((2*len(indices),100),dtype=np.float64)
    matrix[0::2]=features.buy_X[indices];matrix[1::2]=features.sell_X[indices]
    if context:
        band=np.repeat(np.asarray(q0_timeband,dtype=np.int8)[indices],2)
        matrix=model_module.with_context(matrix,band)
    return matrix,np.asarray(labels,dtype=np.int64),np.asarray(mass,dtype=np.float64),indices


# ----------------------------------------
def selection_audit(selected: dict,feature_indices: list[int]) -> dict:
    """
    機能: 大量の教師反復転記を避け、再現可能な窓・支持・教師指紋を要約する。
    引数: selected (dict)、feature_indices (list[int])。返り値: dict 型の小さい監査情報。
    """
    pairs=selected['pairs']
    canonical=[(p['source_index'],p['case_id'],p['event_id'],p['known_at'],p['side_weight']) for p in pairs]
    signature=hashlib.sha256(json.dumps(canonical,ensure_ascii=False,separators=(',',':')).encode('utf-8')).hexdigest()
    result={k:copy.deepcopy(selected[k]) for k in ('ready','ready_reasons','current_scene_index','current_scene_start',
        'window','maturity','physical_pair_count','contributing_sessions','contributing_session_count','classes',
        'active_block_count','blocks','side_weight_mean','weight_formula')}
    result.update(canonical_teacher_sha256=signature,
        training_feature_indices_sha256=hashlib.sha256(json.dumps(feature_indices,separators=(',',':')).encode()).hexdigest(),
        max_label_known_at=max((p['known_at'] for p in pairs),default=None))
    if 'timeband' in selected:
        result['timeband']=selected['timeband']
        result['global_physical_pair_count']=selected['global_physical_pair_count']
    return result
