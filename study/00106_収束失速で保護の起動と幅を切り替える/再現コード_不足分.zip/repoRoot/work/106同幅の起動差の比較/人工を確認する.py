"""既存の停止Core型だけで8比較と狭い破損を検査する。金融を再実行しない。"""
from __future__ import annotations
import copy
import hashlib
import importlib.util
import json
from pathlib import Path

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
SPEC = importlib.util.spec_from_file_location('同幅比較の人工口', WORK / '同幅の起動差を比較する.py')
API = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(API)


def main() -> None:
    """
    機能: 既存人工四場の32比較と実入口属性/Source全値の狭い反証を行う。
    引数: なし。停止Core/停止E人工を読むだけで金融形成はしない。
    返り値: None。小さい確認JSONのみを保存する。
    """
    paths = sorted((ROOT / 'work/106可変保護の市場接続準備/人工_停止版').glob('*.json'))
    assert len(paths) == 4
    before, scenes = {}, []
    for path in paths:
        before[str(path)] = API.digest(path)
        value = API.load(path)['output']
        comparisons = API.compare_scene(value)
        assert len(comparisons) == 8
        for d in comparisons.values():
            assert d['全差額'] == d['同実入口差額'] + d['取得変更差額'] - d['前のみ実現額'] + d['後のみ実現額']
        scenes.append({'入力': str(path.relative_to(ROOT)), '比較数': 8, '比較': comparisons})
    original = API.load(paths[0])['output']
    after, prior = API.PAIRS[0]
    positions = original['books'][after]['positions']
    assert positions
    changed = copy.deepcopy(original)
    changed['books'][after]['positions'][0]['entry_quote']['source_line'] += 1
    value = API.compare_scene(changed)[after+'対'+prior]
    assert value['取得変更玉'] >= 1
    changed = copy.deepcopy(original)
    changed['books'][after]['positions'][0]['source']['birth_quantity'] += 1
    value = API.compare_scene(changed)[after+'対'+prior]
    assert value['前のみ玉'] >= 1 and value['後のみ玉'] >= 1
    rejected = 0
    for kind in ('重複玉', '起動policy偽装', '残玉', '正本純額破損', 'E早期audit欠落'):
        value = copy.deepcopy(original)
        b = value['books'][after]
        if kind == '重複玉':
            b['positions'].append(copy.deepcopy(b['positions'][0]))
        elif kind == '起動policy偽装':
            b['config']['activation_policy'] = 'LD10'
        elif kind == '残玉':
            b['positions'][0]['quantity'] = 1
        elif kind == '正本純額破損':
            b['totals']['net_yen'] += 1
        else:
            del value['early_audits'][after]
        try:
            API.compare_scene(value)
        except (AssertionError, KeyError, ValueError):
            rejected += 1
        else:
            raise AssertionError(kind+'を受理')
    early_paths = sorted((ROOT / 'work/収束失速で保護を早める会計案/人工_停止版').glob('*_E*_C*_D*.json'))
    assert len(early_paths) == 32
    early, normal = 0, 0
    for path in early_paths:
        before[str(path)] = API.digest(path)
        v = API.load(path)
        key = v['early_audit']['policy'] + '_C' + str(v['book']['config']['slip_pts']) + '_D' + str(v['book']['config']['delay_seconds'])
        a, b = API.activation_counts({'books': {key: v['book']}, 'early_audits': {key: v['early_audit']}}, key)
        normal += a
        early += b
    assert early > 0 and normal > 0
    assert {p: API.digest(Path(p)) for p in before} == before
    proof = {'成功': True, 'scope': '停止Core四型の保存Bookだけを旧103比較へ射影。金融再実行なし',
             '比較': scenes, '人工四場の比較数': 32, '全差額加法式': True,
             'entry_quote物理行差を取得変更へ分類': True, 'Source全値差を片側実参加へ分類': True,
             '既存E_API32の通常起動': normal, '既存E_API32の早期起動': early,
             'E_API32はCore市場出典と別scope': True, '破損拒否': rejected,
             '入力SHA256前': before, '入力SHA256後': before, '前後不変': True,
             '市場Native読取': 0, '全70_途中読取': 0, '金融再実行': 0, 'Raw_Source_退出後価格': 0}
    API.OLD.BASE.write_json(WORK / '人工確認_最終.json', proof)
    print(json.dumps({'成功': True, '比較': 32, '破損拒否': rejected, '早期': early}, ensure_ascii=False))


if __name__ == '__main__':
    main()
