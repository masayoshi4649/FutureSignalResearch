"""106のE1対W1/E2対W2を既存実入口比較だけで加法分解する。"""
from __future__ import annotations
import argparse
from collections import Counter
from decimal import Decimal
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OLD_PATH = ROOT / 'work/103多玉の保存集計/集計.py'
OLD_SHA = 'aa1f27f56a54db0288c6e48d83bd292f424af720a5573fa774349489b206bd57'
SAVED_SHA = '7451f6c6502ec7b5ca83d0ce296931f1abbb2b082d41003ccb8a907846736f47'
if hashlib.sha256(OLD_PATH.read_bytes()).hexdigest() != OLD_SHA:
    raise ValueError('旧103実入口比較の指紋差')
SPEC = importlib.util.spec_from_file_location('106同幅比較が無変更再用する103', OLD_PATH)
OLD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(OLD)
PAIRS = tuple((f'E{n}_C{c}_D{d}', f'W{n}_C{c}_D{d}') for n in (1, 2) for c in (0, 5) for d in (0, 1))


def digest(path: Path) -> str:
    """
    機能: 明示入力又はコードのSHA256を得る。
    引数: path(Path)はRoot固定対象。
    返り値: strは内容指紋。探索やSource形成は行わない。
    """
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def load(path: Path) -> dict:
    """
    機能: 半円をDecimalで保ちJSON/gzipを読む。
    引数: path(Path)は許可済み固定入力。
    返り値: dictは元値。価格や約定を再計算しない。
    """
    opener = gzip.open if path.suffix == '.gz' else open
    with opener(path, 'rt', encoding='utf-8-sig') as f:
        return json.load(f, parse_float=Decimal)


def bind(ref: dict, base: Path, before: dict) -> Path:
    """
    機能: FileRefの位置と実SHAを前指紋へ結ぶ。
    引数: ref(dict)、base(Path)、before(dict)は固定参照・根・前指紋。
    返り値: Pathは照合済み絶対path。
    """
    assert isinstance(ref['path'], str) and ref['path']
    assert isinstance(ref['sha256'], str) and len(ref['sha256']) == 64
    p = (base / ref['path']).resolve()
    assert digest(p) == ref['sha256'], str(p)
    assert str(p) not in before or before[str(p)] == ref['sha256']
    before[str(p)] = ref['sha256']
    return p


def comparison_input(book: dict) -> dict:
    """
    機能: 保存検算済みBookを旧103比較の公開入力へ無損失で射影する。
    引数: book(dict)は完結した実Book。Source全値・注文・取得quoteを残す。
    返り値: dictはpositions/orders/totals。新会計や仮想取引は作らない。
    """
    assert book['finished'] is True and book['complete'] is True and not book['failure']
    positions = {p['id']: p for p in book['positions'] or []}
    orders = {o['id']: o for o in book['orders'] or []}
    assert len(positions) == len(book['positions'] or []) and len(orders) == len(book['orders'] or [])
    for p in positions.values():
        assert p['quantity'] == p['reserved'] == 0 and isinstance(p['source'], dict)
        o = orders[p['entry_order_id']]
        assert o['kind'] == 'entry' and o['position_id'] == p['id']
    assert sum((p['realized_net'] for p in positions.values()), Decimal(0)) == book['totals']['net_yen']
    return {'positions': positions, 'orders': orders, 'totals': book['totals']}


def activation_counts(value: dict, key: str) -> tuple[int, int]:
    """
    機能: E別auditと歴史的起動flagから通常/早期を分ける。
    引数: value(dict)、key(str)はNative全値と実外政策名。
    返り値: tuple[int,int]は通常LD10/早期件数。欠落を早期0で隠さない。
    """
    positions = value['books'][key]['positions'] or []
    active = sum(p['protection_active'] for p in positions)
    if key.startswith('E'):
        audit = value['early_audits'][key]
        assert audit['policy'] == key.split('_')[0]
        rows = audit['positions'] or []
        assert {a['position_id'] for a in rows} == {p['id'] for p in positions if p['protection_active']}
        assert len(rows) == active and all(a['trigger'] in ('normal_ld10', 'early_warning') for a in rows)
        early = sum(a['trigger'] == 'early_warning' for a in rows)
    else:
        assert key not in value['early_audits']
        early = 0
    return active - early, early


def compare_scene(value: dict, summary_rows: dict | None = None) -> dict:
    """
    機能: 同じ幅選択規則の八組を旧103関数へそのまま渡す。
    引数: value(dict)、summary_rows(dict|None)はNativeと保存場別参照。
    返り値: dictは比較名→九欄加法分解・前後起動件数。採用順位は作らない。
    """
    assert value['trial'] == 106 and value['complete'] is True and len(value['books']) == 20
    out = {}
    for after, before in PAIRS:
        projected = {}
        counts = {}
        for key in (before, after):
            b = value['books'][key]
            p, c, d = key.split('_')
            activation = p if p.startswith('E') else 'LD10'
            assert b['key'] == f'{activation}_B5Q_P0_{c}_{d}'
            assert b['config']['activation_policy'] == activation and b['config']['policy'] == 'P0'
            assert b['config']['entry_timing'] == 'B5Q' and b['config']['slip_pts'] == int(c[1:]) and b['config']['delay_seconds'] == int(d[1:])
            projected[key] = comparison_input(b)
            counts[key] = activation_counts(value, key)
            if summary_rows is not None:
                row = summary_rows[key]
                assert row['net_yen'] == b['totals']['net_yen']
                assert (row['normal_ld10_activations'], row['early_warning_activations']) == counts[key]
        # ----------------------------------------
        # 関数本文/名前空間を差替えず旧103のSource全値joinと実入口判定を直接使う。
        comparison = OLD.compare_positions(projected[before], projected[after])
        comparison.update({'前の通常LD10起動': counts[before][0], '前の早期起動': counts[before][1],
                           '後の通常LD10起動': counts[after][0], '後の早期起動': counts[after][1]})
        out[after + '対' + before] = comparison
    return out


def generate(fixed_path: Path, fixed_sha: str, output: Path) -> dict:
    """
    機能: 金融/保存成功後の固定参照から八比較を別JSON/MDへ保存する。
    引数: fixed_path/output(Path)、fixed_sha(str)はRoot事後固定と新規保存先。
    返り値: dictは追加診断。金融/Source/Raw/退出後価格を再計算しない。
    """
    assert not output.exists() and digest(fixed_path) == fixed_sha
    f = load(fixed_path)
    assert f['version'] == 1 and f['trial'] == 106 and f['fixed'] is True and f['stage'] in ('first2', 'full70')
    before = {str(fixed_path.resolve()): fixed_sha, str(OLD_PATH): OLD_SHA}
    for module in (OLD.GRID, OLD.BASE):
        path = Path(module.__file__).resolve()
        before[str(path)] = digest(path)
    paths = {k: bind(f[k], fixed_path.parent, before) for k in ('completion', 'summary', 'saved_check', 'code')}
    assert paths['code'] == Path(__file__).resolve()
    complete, summary, saved = (load(paths[k]) for k in ('completion', 'summary', 'saved_check'))
    n = 2 if f['stage'] == 'first2' else 70
    assert complete['version'] == 1 and complete['trial'] == 106 and complete['stage'] == f['stage'] and complete['success'] is True
    assert complete['sessions'] == n and complete['books'] == 20*n and complete['books_per_scene'] == 20
    assert complete['unchanged'] and complete['before'] == complete['after'] and len(complete['results']) == n
    assert summary['試行'] == 106 and summary['成功'] is True and summary['stage'] == f['stage'] and summary['場数'] == n and summary['会計数'] == 20*n
    assert summary['前後不変'] and summary['入力codeSHA256前'] == summary['入力codeSHA256後']
    assert saved['成功'] is True and saved['会計'] == 20*n and saved['不一致数'] == 0 and saved['前後不変']
    assert saved['入力codeSHA256前'] == saved['入力codeSHA256後']
    assert saved['出力SHA256']['結果.json'] == f['summary']['sha256']
    for v in (summary, saved):
        assert v['completionSHA256'] == f['completion']['sha256'] and v['conditionSHA256'] == complete['condition_sha256'] and v['codeSHA256'] == SAVED_SHA
    rows = {(r['session'], r['key']): r for r in summary['場別']}
    assert len(rows) == len(summary['場別']) == 20*n
    result, sessions = {a+'対'+b: {'合計': Counter(), '場別': []} for a, b in PAIRS}, []
    summary_refs = {x['session']: x['native'] for x in summary['Native参照']}
    assert len(summary_refs) == n
    for task in complete['results']:
        sid = task['session']
        assert sid not in sessions and task['books'] == 20 and task['native'] == summary_refs[sid]
        path = bind(task['native'], paths['completion'].parent, before)
        assert saved['入力codeSHA256前'][str(path)] == task['native']['sha256']
        value = load(path)
        assert value['session']['id'] == sid and value['condition_sha256'] == complete['condition_sha256']
        comparisons = compare_scene(value, {k: rows[(sid, k)] for k in value['books']})
        for name, data in comparisons.items():
            result[name]['合計'].update(data)
            result[name]['場別'].append({'session': sid, **data})
        sessions.append(sid)
    for name, value in result.items():
        a, b = name.split('対')
        assert value['合計']['全差額'] == summary['集計'][a]['net_yen'] - summary['集計'][b]['net_yen']
        d = value['合計']
        assert d['全差額'] == d['同実入口差額'] + d['取得変更差額'] - d['前のみ実現額'] + d['後のみ実現額']
    after = {p: digest(Path(p)) for p in before}
    assert before == after
    value = {'試行': 106, '成功': True, 'scope': '同じ幅選択規則の起動政策差を保存済み実参加だけで分解。実際の幅/床経路同一や独立金融再生を主張しない',
             'stage': f['stage'], '場数': n, '比較数': 8, 'sessions': sessions, '比較': result,
             'Root固定SHA256': fixed_sha, '保存結果SHA256': f['summary']['sha256'], '金融完了SHA256': f['completion']['sha256'],
             '入力SHA256前': before, '入力SHA256後': after, '前後不変': True, '金融再実行': 0, 'Source再形成': 0,
             '未実施': ['退出後価格', '機会損失', 'MFE回収', '採用順位', '新閾値探索']}
    lines = ['# 同幅選択規則での起動差', '', value['scope'], '',
             '|比較|全差額|同実入口玉|同実入口退出差|取得変更玉|取得変更差|前のみ実額|後のみ実額|後の通常/早期起動|',
             '|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    for name, v in result.items():
        d = v['合計']
        lines.append(f"|{name}|{d['全差額']}|{d['同実入口玉']}|{d['同実入口差額']}|{d['取得変更玉']}|{d['取得変更差額']}|{d['前のみ実現額']}|{d['後のみ実現額']}|{d['後の通常LD10起動']}/{d['後の早期起動']}|")
    lines += ['', '全差額＝同実入口差＋取得変更差−前のみ実現額＋後のみ実現額。片側実額は実際に参加した側だけの値。',
              '同幅は1/2ATR選択規則の対応を意味する。起動時点差から公表消費・床・返済予約・後続実取得も変わり得る。',
              '各費用感度を独立市場例としない。未参加利益や退出後価格を補わない。', '', f"固定保存結果SHA256: {f['summary']['sha256']}"]
    output.mkdir(parents=True)
    OLD.BASE.write_json(output / '同幅の起動差.json', value)
    (output / '同幅の起動差.md').write_text('\n'.join(lines)+'\n', encoding='utf-8')
    return {'成功': True, '場数': n, '比較数': 8}


def main() -> None:
    """
    機能: Root事後固定を必要とする小さな診断CLIを公開する。
    引数: fixed/fixed-sha/outは固定JSON・実SHA・新規保存先。
    返り値: None。未成功市場や既存先を開いて更新しない。
    """
    p = argparse.ArgumentParser()
    p.add_argument('--fixed', type=Path, required=True)
    p.add_argument('--fixed-sha', required=True)
    p.add_argument('--out', type=Path, required=True)
    a = p.parse_args()
    print(generate(a.fixed.resolve(), a.fixed_sha, a.out.resolve()))


if __name__ == '__main__':
    main()
