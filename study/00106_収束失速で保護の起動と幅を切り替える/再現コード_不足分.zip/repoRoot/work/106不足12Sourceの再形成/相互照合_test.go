package main

import (
	"compress/gzip"
	"encoding/json"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"

	replay "github.com/masayoshi4649/SessionTradeExecuter/minisourcereplay104"
)

// writeModeFixture は公開再生APIだけから新保存結果と全JSONL人工を作ります。
//
// 引数: t(*testing.T)、dir/mode(string)、night(bool)は試験器・新規先・生成mode・場種です。
// 返り値: CaseReceiptはSource新規/約定0の非市場人工です。自然形成の成績ではありません。
func writeModeFixture(t *testing.T, dir, mode string, night bool) CaseReceipt {
	t.Helper()
	s, boards, candles := artificialInputs(night)
	row := CaseReceipt{Session: s.ID, Mode: mode}
	row.Records.Path = filepath.Join(dir, mode+".jsonl.gz")
	f, e := os.Create(row.Records.Path)
	if e != nil {
		t.Fatal(e)
	}
	z := gzip.NewWriter(f)
	rec := &Recorder{Sink: func(v SourceRecord) error { return json.NewEncoder(z).Encode(v) }}
	factory, e := rec.Factory(mode)
	if e != nil {
		t.Fatal(e)
	}
	value, e := replay.ReplayPrepared(s, boards, candles, factory)
	if e != nil {
		t.Fatal(e)
	}
	if e = z.Close(); e != nil {
		t.Fatal(e)
	}
	if e = f.Close(); e != nil {
		t.Fatal(e)
	}
	row.Counts = rec.Counts
	row.Records.SHA, e = digest(row.Records.Path)
	if e != nil {
		t.Fatal(e)
	}
	row.Result.Path = filepath.Join(dir, mode+".json")
	if e = writeNew(row.Result.Path, value); e != nil {
		t.Fatal(e)
	}
	row.Result.SHA, e = digest(row.Result.Path)
	if e != nil {
		t.Fatal(e)
	}
	return row
}

// Test106MutualFiles は新legacy/defaultの全保存bytes同体と破損拒否を確認します。
//
// 引数: t(*testing.T)は非市場人工の試験器です。
// 返り値: ありません。symmetricを相互同体の成功へ流用しません。
func Test106MutualFiles(t *testing.T) {
	for _, night := range []bool{false, true} {
		dir := t.TempDir()
		a := writeModeFixture(t, dir, "legacy", night)
		b := writeModeFixture(t, dir, "default", night)
		p, e := compareModeFiles(a, b)
		if e != nil || !p.Success || p.JSONLBytes <= 0 || a.Counts.Steps == 0 || a.Counts.Forces == 0 {
			t.Fatal("相互同体", p, e)
		}
		for _, name := range []string{"mode", "旧golden旗", "counts", "resultSHA", "recordSHA", "result本文", "record本文", "recordgzip破損"} {
			t.Run(name+"/"+a.Session, func(t *testing.T) {
				x, y := a, b
				switch name {
				case "mode":
					y.Mode = "symmetric"
				case "旧golden旗":
					y.Old93FullMatch = true
				case "counts":
					y.Counts.Calls++
				case "resultSHA":
					y.Result.SHA = strings.Repeat("0", 64)
				case "recordSHA":
					y.Records.SHA = strings.Repeat("0", 64)
				case "result本文":
					y.Result.Path = filepath.Join(t.TempDir(), "wrong.json")
					if e := os.WriteFile(y.Result.Path, []byte("{}\n"), 0600); e != nil {
						t.Fatal(e)
					}
					y.Result.SHA, _ = digest(y.Result.Path)
				case "record本文", "recordgzip破損":
					y.Records.Path = filepath.Join(t.TempDir(), "wrong.gz")
					f, e := os.Create(y.Records.Path)
					if e != nil {
						t.Fatal(e)
					}
					if name == "record本文" {
						z := gzip.NewWriter(f)
						_, _ = z.Write([]byte("{}\n"))
						_ = z.Close()
					} else {
						_, _ = f.Write([]byte("gzipではない"))
					}
					_ = f.Close()
					y.Records.SHA, _ = digest(y.Records.Path)
				}
				if _, e := compareModeFiles(x, y); e == nil {
					t.Fatal("不一致を受理")
				}
			})
		}
		if e := writeNew(a.Result.Path, map[string]int{"上書き": 1}); e == nil {
			t.Fatal("既存先を上書き")
		}
	}
}

// mutualMetadataFixture はfirst2の完全6caseと独立した2相互照合参照を作ります。
//
// 引数: ありません。
// 返り値: []CaseReceipt/[]MutualReceiptは手製のmetadataで実入力は含みません。
func mutualMetadataFixture() ([]CaseReceipt, []MutualReceipt) {
	rows := first2Fixture()
	pairs := []MutualReceipt{}
	for i, id := range expectedIDs()[:2] {
		a, b := rows[3*i], rows[3*i+1]
		pairs = append(pairs, MutualReceipt{Session: id, Success: true, LegacyResult: a.Result, DefaultResult: b.Result, LegacyRecords: a.Records, DefaultRecords: b.Records, ReplayResultBytesEqual: true, RecordsGzipBytesEqual: true, RecordsJSONLBytesEqual: true, JSONLSHA: strings.Repeat("c", 64), JSONLBytes: 1})
	}
	return rows, pairs
}

// Test106MutualMetadata はgoldenなしの先頭2成功が場・参照へ正確に結ぶことを確認します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: ありません。同体boolだけでは別参照や対称modeの成功を受理しません。
func Test106MutualMetadata(t *testing.T) {
	rows, pairs := mutualMetadataFixture()
	if e := validateMutual(rows, pairs, expectedIDs()[:2]); e != nil {
		t.Fatal(e)
	}
	for _, name := range []string{"欠落", "重複", "別場", "失敗", "JSON不一致", "gzip不一致", "本文不一致", "別参照", "別指紋", "空本文", "旧93旗", "順序"} {
		t.Run(name, func(t *testing.T) {
			r, p := mutualMetadataFixture()
			switch name {
			case "欠落":
				p = p[:1]
			case "重複":
				p[1] = p[0]
			case "別場":
				p[0].Session = "2026-11-06_Day"
			case "失敗":
				p[0].Success = false
			case "JSON不一致":
				p[0].ReplayResultBytesEqual = false
			case "gzip不一致":
				p[0].RecordsGzipBytesEqual = false
			case "本文不一致":
				p[0].RecordsJSONLBytesEqual = false
			case "別参照":
				p[0].DefaultRecords.Path = "other.gz"
			case "別指紋":
				r[1].Result.SHA = strings.Repeat("d", 64)
				p[0].DefaultResult = r[1].Result
			case "空本文":
				p[0].JSONLBytes = 0
			case "旧93旗":
				r[0].Old93FullMatch = true
			case "順序":
				r[0], r[1] = r[1], r[0]
			}
			if e := validateMutual(r, p, expectedIDs()[:2]); e == nil {
				t.Fatal("破損受理")
			}
		})
	}
}

// Test106ExactScenes は12場とfirst2/full12の対象を新価格を使わず検査します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: ありません。旧54/66集合、別順・重複を拒否します。
func Test106ExactScenes(t *testing.T) {
	sessions := []replay.InputSession{}
	scenes := []SceneRef{}
	for _, id := range expectedIDs() {
		sessions = append(sessions, replay.InputSession{ID: id})
		scenes = append(scenes, SceneRef{Session: id})
	}
	got, e := selectScenes(sessions, scenes)
	if e != nil || !reflect.DeepEqual(got, sessions) {
		t.Fatal(e)
	}
	got[0].ID = "外側slice変更"
	if sessions[0].ID != expectedIDs()[0] {
		t.Fatal("slice共有")
	}
	for _, name := range []string{"台帳不足", "台帳余分", "台帳重複", "条件不足", "条件別場", "条件逆順"} {
		t.Run(name, func(t *testing.T) {
			s := append([]replay.InputSession(nil), sessions...)
			c := append([]SceneRef(nil), scenes...)
			switch name {
			case "台帳不足":
				s = s[:3]
			case "台帳余分":
				s = append(s, s[0])
			case "台帳重複":
				s[1] = s[0]
			case "条件不足":
				c = c[:3]
			case "条件別場":
				c[0].Session = "2026-11-04_Day"
			case "条件逆順":
				c[0], c[1] = c[1], c[0]
			}
			if _, e := selectScenes(s, c); e == nil {
				t.Fatal("別集合を受理")
			}
		})
	}
}

// Test106StrategyCoverage は台帳に記した純戦略の固定code包含を検査します。
//
// 引数: t(*testing.T)は非市場metadata試験器です。
// 返り値: ありません。架空のpathだけを用い、原板・CSV・Source形成は行いません。
func Test106StrategyCoverage(t *testing.T) {
	root := t.TempDir()
	h := strings.Repeat("a", 64)
	m := replay.InputManifest{StrategyRoot: filepath.Join(root, "strategy"), StrategySHA256: map[string]string{"selected.go": h}}
	p := filepath.Join(m.StrategyRoot, "selected.go")
	code := map[string]string{p: h}
	if e := validateStrategyCoverage(code, root, m); e != nil {
		t.Fatal(e)
	}
	for _, name := range []string{"欠落", "別SHA", "別root", "正規重複"} {
		t.Run(name, func(t *testing.T) {
			c := map[string]string{p: h}
			x := m
			switch name {
			case "欠落":
				delete(c, p)
			case "別SHA":
				c[p] = strings.Repeat("b", 64)
			case "別root":
				x.StrategyRoot = filepath.Join(root, "other")
			case "正規重複":
				c[filepath.Join("strategy", "selected.go")] = h
			}
			if e := validateStrategyCoverage(c, root, x); e == nil {
				t.Fatal("純戦略の固定漏れを受理")
			}
		})
	}
}
