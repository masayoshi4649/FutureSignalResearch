# 106不足12場のSource再形成口（市場未実行）

停止105 Source CLI f52676b0を新module `github.com/masayoshi4649/SessionTradeExecuter/minisourcecli106` へ最小派生した。再生は旧minisourcereplay104（2104停止）、生成口はminisymmetric104（e519停止）を直接再用し、純43・元reader・暦・数量・Fill/Force・全通知内容は変更しない。`record.go` とgo.sumは105とbytes同体。

入力は70候補のうち、10/28・29・30、11/2・3・4のDay/Night計12だけ。`不足12入力台帳_候補.json` は72InputFileの旧宣言SHA/size/Contractをコピーしたmetadataで、原板/CSVの本文・新SHA・品質を再確認したものではない。Rootが正式条件をsealして初めて実行する。

## 仕様とargv

serialを採用する。各場ごとにlegacy/default/symmetricのSourceインスタンスを独立に作り全再生する。Sourceを共有するgoroutineや、3processへの分割・統合は実装していない。短縮のための分割が必要なら同一条件・first2・完全集合の別外周を改版し、成功済みとはしない。

```powershell
& 'work/106不足12Sourceの再形成/検査/不足12Source.exe' `
 --condition '<Root固定条件.json>' --condition-sha '<現物SHA>' `
 --stage first2 --out '<不存在の先頭2出力>'

& 'work/106不足12Sourceの再形成/検査/不足12Source.exe' `
 --condition '<同じRoot固定条件.json>' --condition-sha '<同じSHA>' `
 --stage full12 --first2 '<先頭2出力/完了.json>' --first2-sha '<そのSHA>' `
 --out '<不存在の全12出力>'
```

first2は10/28Day/Nightで6case・18Sourcebook、full12は36case・108Sourcebookを予定する。先頭2成功は同条件/code/binary/metadata・完全6case・legacy/default同体へ結ぶ。full12のbeforeには先頭2完了と全出力の指紋も入る。すべて新規出力だけを許容する。

### Condition exact（version1）

`version:1, trial:106, fixed:true, input_manifest:FileRef, generator_stop:FileRef, replay_stop:FileRef, binary:FileRef, code_sha256:map[path]SHA, scenes:[{session}]12, modes:[legacy,default,symmetric]`。

FileRefは `{path,sha256}`。相対FileRefは条件JSONのparent基準、codeキーはrepo基準又は絶対path。標準InputManifestはsource_root/純戦略repoを台帳parentから絶対化し、filesをsource_root基準で解決する。両停止SHAはe519/2104固定。実CLI main/record/相互照合/mod/sumと両停止所有集合、台帳純43もcodeへ包含する。実binaryのpath/SHAも一致必須。固定されるまで市場本文へ進まない。

### Completion exact（version1）

`version,trial:106,stage:first2|full12,success,condition_sha256,sessions:2|12,cases:6|36,before,after,unchanged,source_reformed,financial106_executed:false,legacy_default_matches:2|12,error?`。

各caseは `{session,mode,result:FileRef,records:FileRef,counts:{calls,steps,forces,signals,fills,closes,cancellations},old93_full_match:false,error?}`。resultは公開ReplayResult全JSON、recordsはStep/Forceの全商品SourceRecord JSONL gzip。空DeltaやCloses-onlyを落とさない。

各相互QAは `{session,success,legacy_result,default_result,legacy_records,default_records,replay_result_bytes_equal,records_gzip_bytes_equal,records_jsonl_bytes_equal,jsonl_sha256,jsonl_bytes}`。legacy/defaultの全Result bytesと全記録gzip/解凍JSONL bytesを除外なしで照合する。symmetricは別出力であり同体であるべきとしない。旧93golden/金融の成功をこの相互QAから作らない。限月・価格・経済効果を推定する処理は追加しない。

## 人工と依存

105の手製Observation/確定足と公開Prepared再生だけの空Source人工、全通知Marshal往復、半円/Targets等の型拒否、Root未固定拒否、正規path/停止所有包含、12ID集合/先頭6case/legacy-defaultの全bytes相互QAを継承する。実市場、自然非0Source、旧golden、新しい12場品質は未検証。

検査は `go test -json ./...`、`go vet ./...`、`go build -o 検査/不足12Source.exe .`。`検査/Go依存.json` は `go list -mod=readonly -deps -json .`、`Go依存の指紋.json` はその実解決Goソース/Embed/GoMod/local sum/Go toolの指紋台帳。stdlib/Go cacheのbodyをここへ複製しない。Metadata候補12を正式入力固定と誤読しない。

Source出力は全商品通知とReplayResultだけで、frame/価格Tapeは生成しない。106入出力wrapperが同じ全Observationから全board時計と新legacy基準Tapeを別に組み立てる。旧54Tapeで新12を代替しない。銀行の指標助走やW0/W1/W2金融はこのSource外周の仕事ではない。
