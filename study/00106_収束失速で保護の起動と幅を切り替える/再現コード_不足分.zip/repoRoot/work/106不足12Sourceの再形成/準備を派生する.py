"""停止105Source外周を不足12IDへ最小派生する。市場入力を読まない。"""

import difflib
import hashlib
import json
from pathlib import Path


def sha(path):
    """
    機能: コード/metadataのSHAを求める。
    引数: path(Path)は元停止又は候補台帳。
    返り値: strは内容指紋。市場ファイルは対象にしない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    """
    機能: 新dirへmain/record/相互QA/人工と12入力候補を同体又は最小差で保存する。
    引数: なし。
    返り値: None。旧105、再生、純戦略、Root正式試行を変更しない。
    """
    here = Path(__file__).resolve().parent
    root = here.parents[1]
    old = root / "work/105四場Sourceの再形成"
    stop = old / "停止.json"
    assert sha(stop) == "f52676b0cc55fe2fbdbb0f6524161950af4babbb5891513723a01b5f2618c28a"
    stopped = json.loads(stop.read_text(encoding="utf-8-sig"))
    for name, h in stopped["所有SHA256"].items(): assert sha(root / name) == h
    candidate = root / "work/106入力と既存Sourceの整理/標準入力台帳_70場_候補.json"
    evidence = root / "work/106入力と既存Sourceの整理/入力と既存参照の確認.json"
    assert sha(candidate) == "902c6b5147763de172c0199f79b13cdc08f9a5636b05e0575f19bffd2da627e8"
    assert sha(evidence) == "2e115634d0772864cb501a73f2a0e4b85f5c5185f63f84530aca5ba75e02cbdb"
    manifest, meta = json.loads(candidate.read_text(encoding="utf-8")), json.loads(evidence.read_text(encoding="utf-8"))
    ids = meta["不足Source_ID"]
    assert len(ids) == 12 and ids[:2] == ["2026-10-28_Day", "2026-10-28_Night"] and ids == meta["不足W0_ID"]
    selected = {**manifest, "sessions": [s for s in manifest["sessions"] if s["id"] in ids]}
    assert [s["id"] for s in selected["sessions"]] == ids and sum(len(s["files"]) for s in selected["sessions"]) == 72
    outputs = {}
    patches = []
    names = ("main.go", "record.go", "相互照合.go", "record_test.go", "guard_test.go", "相互照合_test.go", "go.mod", "go.sum")
    for name in names:
        src = old / name
        data = src.read_bytes()
        if name in ("record.go", "go.sum"):
            result = data
        else:
            text = data.decode("utf-8")
            original = text
            if name == "main.go":
                text = text.replace('return []string{"2026-11-05_Day", "2026-11-05_Night", "2026-11-06_Day", "2026-11-06_Night"}',
                    'return []string{' + ', '.join(json.dumps(s) for s in ids) + '}')
                text = text.replace('c.Trial != 105', 'c.Trial != 106').replace('f.Trial != 105', 'f.Trial != 106').replace('Trial: 105', 'Trial: 106')
                text = text.replace('len(c.Scenes) != 4', 'len(c.Scenes) != 12').replace('full4', 'full12')
                text = text.replace('Financial105Executed', 'Financial106Executed').replace('financial105_executed', 'financial106_executed')
                text = text.replace('固定後確認候補の4場だけ', '106不足12場だけ').replace('11月5日と6日のDay/Night', '10月28日から11月4日の不足Day/Night')
                text = text.replace('105LD10金融', '106金融')
            elif name == "go.mod":
                text = text.replace('/minisourcecli105', '/minisourcecli106')
            else:
                text = text.replace('Test105', 'Test106').replace('first2/full4', 'first2/full12').replace('正確な4場', '正確な12場').replace('4場の固定順', '12場の固定順').replace('4場不一致', '12場不一致')
                if name == "record_test.go":
                    text = text.replace('Trial: 105', 'Trial: 106').replace('make([]SceneRef, 4)', 'make([]SceneRef, len(expectedIDs()))')
            result = text.encode("utf-8")
            if result != data:
                patches.extend(difflib.unified_diff(original.splitlines(True), text.splitlines(True), fromfile='105/' + name, tofile='106/' + name))
        target = here / name
        with target.open("xb") as stream: stream.write(result)
        outputs[name] = sha(target)
    for name, value in (("不足12入力台帳_候補.json", selected), ("条件の雛形.json", {
        "version": 1, "trial": 106, "fixed": False,
        **{key: {"path": "", "sha256": ""} for key in ("input_manifest", "binary")},
        "generator_stop": {"path": (root / "work/104対称Sourceの生成口準備/停止.json").as_posix(), "sha256": "e5192a02340de79e41c8a38643e883375682bb8f4f9fe46f5c0b91ab64d3f1cc"},
        "replay_stop": {"path": (root / "work/104Source再生の接続準備/停止.json").as_posix(), "sha256": "2104b6609e160cf86133239554d7338d6c5ccc3446e434ad7a10751f5b39ec39"},
        "code_sha256": {}, "scenes": [{"session": sid} for sid in ids], "modes": ["legacy", "default", "symmetric"]})):
        with (here / name).open("x", encoding="utf-8", newline="\n") as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2); stream.write("\n")
    (here / "105との差分.patch").write_text("".join(patches), encoding="utf-8")
    with (here / "由来.json").open("x", encoding="utf-8", newline="\n") as stream:
        json.dump({"元停止": {"path": str(stop.relative_to(root)).replace('\\', '/'), "SHA256": sha(stop)},
            "元コードSHA256": {name: sha(old / name) for name in names}, "派生コードSHA256": outputs,
            "本文同体": ["record.go", "go.sum"], "差分": "trial106/stagefull12/12ID/financial106旗/新module名と人工metadataだけ。Source/再生/全通知/費用/価格/暦/式不変",
            "Manifest元": {"path": str(candidate.relative_to(root)).replace('\\', '/'), "SHA256": sha(candidate)},
            "不足12ID": ids, "宣言SHA継承": True, "市場本文/新内容SHA/Source実再形成": 0,
            "serial": "3modeを各場独立Sourceで順番に再生。共有Source instanceのgoroutine化/分割統合は未実装"}, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    assert all(sha(root / name) == h for name, h in stopped["所有SHA256"].items())
    print(json.dumps({"成功": True, "不足12場": ids, "宣言入力": 72, "record同体": outputs["record.go"] == sha(old / "record.go")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
