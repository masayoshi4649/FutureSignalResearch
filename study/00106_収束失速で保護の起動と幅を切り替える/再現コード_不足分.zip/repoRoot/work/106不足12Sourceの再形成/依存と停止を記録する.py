"""106Source外周のGo実依存/人工/元同体を市場前停止へ記録する。"""

import hashlib
import json
from pathlib import Path


def sha(path):
    """
    機能: コード/metadata/人工ログ/実行物のSHA256を求める。
    引数: path(Path)は市場データ以外の固定対象。
    返り値: strは指紋。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    """
    機能: UTF-8 metadataを読む。
    引数: path(Path)はGo環境又は元停止。
    返り値: dictは保存値。
    """
    return json.loads(path.read_text(encoding="utf-8-sig"))


def main():
    """
    機能: 実Go依存と全非市場検査を確認し停止JSONを新規保存する。
    引数: なし。
    返り値: None。原板/CSV/Source実結果/旧Nativeは読まない。
    """
    here = Path(__file__).resolve().parent; root = here.parents[1]; old = root / "work/105四場Sourceの再形成"
    stop = old / "停止.json"
    assert sha(stop) == "f52676b0cc55fe2fbdbb0f6524161950af4babbb5891513723a01b5f2618c28a"
    original = load(stop)
    assert all(sha(root / n) == h for n, h in original["所有SHA256"].items())
    assert (here / "record.go").read_bytes() == (old / "record.go").read_bytes()
    assert (here / "go.sum").read_bytes() == (old / "go.sum").read_bytes()
    env = load(here / "検査/Go環境.json")
    raw = (here / "検査/Go依存.json").read_text(encoding="utf-8-sig")
    decoder, offset, packages, files = json.JSONDecoder(), 0, [], {}
    fields = ("GoFiles", "CgoFiles", "CFiles", "CXXFiles", "MFiles", "HFiles", "FFiles", "SFiles", "SwigFiles", "SwigCXXFiles", "SysoFiles", "EmbedFiles")
    while offset < len(raw):
        while offset < len(raw) and raw[offset].isspace(): offset += 1
        if offset == len(raw): break
        pkg, offset = decoder.raw_decode(raw, offset)
        assert not pkg.get("Error")
        packages.append({"import": pkg["ImportPath"], "dir": pkg["Dir"], "standard": pkg.get("Standard", False), "module": pkg.get("Module")})
        for field in fields:
            for name in pkg.get(field, []):
                p = (Path(pkg["Dir"]) / name).resolve(); files[str(p)] = sha(p)
        module = pkg.get("Module", {})
        for value in (module, module.get("Replace", {})):
            if value.get("GoMod"):
                p = Path(value["GoMod"]).resolve(); files[str(p)] = sha(p)
            if value.get("Dir"):
                p = Path(value["Dir"]) / "go.sum"
                if p.is_file(): files[str(p.resolve())] = sha(p)
    for name in ("bin/go.exe", "pkg/tool/windows_amd64/compile.exe", "pkg/tool/windows_amd64/link.exe", "pkg/tool/windows_amd64/asm.exe", "pkg/tool/windows_amd64/buildid.exe"):
        p = Path(env["GOROOT"]) / name
        if p.is_file(): files[str(p.resolve())] = sha(p)
    closure_path = here / "Go依存の指紋.json"
    with closure_path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump({"成功": True, "Go環境": env, "package数": len(packages), "packages": packages, "実解決ファイルSHA256": files,
                   "body複製": 0, "市場データ読取": 0}, stream, ensure_ascii=False, indent=2); stream.write("\n")
    checks = {}
    for name in ("test", "vet", "build", "Go依存", "help"):
        checks[name] = int((here / "検査" / (name + ".exit.txt")).read_text(encoding="utf-8-sig").strip()); assert checks[name] == 0
    tests = [json.loads(row) for row in (here / "検査/test.jsonl").read_text(encoding="utf-8-sig").splitlines()]
    assert not any(row.get("Action") == "fail" for row in tests)
    top = [row["Test"] for row in tests if row.get("Action") == "pass" and "Test" in row and "/" not in row["Test"]]
    ids = [row["session"] for row in load(here / "条件の雛形.json")["scenes"]]
    candidate = load(here / "不足12入力台帳_候補.json")
    assert [s["id"] for s in candidate["sessions"]] == ids and len(ids) == 12
    base = load(root / "work/106入力と既存Sourceの整理/標準入力台帳_70場_候補.json")
    assert candidate["sessions"] == [s for s in base["sessions"] if s["id"] in ids]
    assert len(candidate["純戦略SHA256"]) == 43 and all(sha(Path(candidate["純戦略repo"]) / n) == h for n, h in candidate["純戦略SHA256"].items())
    after = {name: sha(Path(name)) for name in files}; assert files == after
    assert all(sha(root / n) == h for n, h in original["所有SHA256"].items())
    owned = {p.relative_to(root).as_posix(): sha(p) for p in here.iterdir() if p.is_file() and p.name != "停止.json"}
    value = {"成功": True, "市場前": True, "module": "github.com/masayoshi4649/SessionTradeExecuter/minisourcecli106",
        "元停止": {"path": stop.relative_to(root).as_posix(), "SHA256": sha(stop)}, "所有SHA256": owned,
        "record/go.sum全bytes同体": True, "旧105所有/純43前後不変": True, "再生/生成口": "停止2104/e519を変更せず直接再用",
        "入力候補": {"path": (here / "不足12入力台帳_候補.json").relative_to(root).as_posix(), "SHA256": sha(here / "不足12入力台帳_候補.json"), "場数": 12, "入力ref": 72, "市場内容SHA再計算": 0},
        "Go検査": {**checks, "top": len(top), "各top": top, "全pass名数": sum(row.get("Action") == "pass" and "Test" in row for row in tests)},
        "Go閉包": {"path": closure_path.relative_to(root).as_posix(), "SHA256": sha(closure_path), "packages": len(packages), "実ファイル": len(files), "前後同一": True},
        "exe": {"path": (here / "検査/不足12Source.exe").relative_to(root).as_posix(), "SHA256": sha(here / "検査/不足12Source.exe")},
        "stage": {"first2": {"sessions": ids[:2], "cases": 6, "Sourcebook": 18}, "full12": {"sessions": ids, "cases": 36, "Sourcebook": 108}},
        "serial": True, "3process分割/共有Sourceのgoroutine化": "未実装/未使用", "旧93golden": False,
        "全通知保存": "Step/Forceの全商品/空Delta/Closes-only/Targetsをrecord.go同体で保存。legacy/default全Result/記録gzipと解凍bytesを相互QA。symは別出力",
        "Source実市場/原板/CSV/新市場SHA/金融/旧Native本文読取実行": 0,
        "Root実行": "README argv/Condition schemaをRootが固定するまで禁止。first2成功後の同条件full12のみ"}
    p = here / "停止.json"
    with p.open("x", encoding="utf-8", newline="\n") as stream: json.dump(value, stream, ensure_ascii=False, indent=2); stream.write("\n")
    print(json.dumps({"成功": True, "停止SHA256": sha(p), "exeSHA256": value["exe"]["SHA256"], "GoPackages": len(packages), "GoFiles": len(files), "top": len(top)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
