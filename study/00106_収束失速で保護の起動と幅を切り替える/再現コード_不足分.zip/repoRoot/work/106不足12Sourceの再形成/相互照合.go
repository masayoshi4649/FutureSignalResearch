package main

import (
	"bytes"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"reflect"
	"strings"

	replay "github.com/masayoshi4649/SessionTradeExecuter/minisourcereplay104"
)

// MutualReceipt は新legacy/defaultの保存結果と全記録の相互同体だけを表します。
// 旧93のgoldenやsymmetricの正しさ、105LD10の成績は表しません。
type MutualReceipt struct {
	Session                string  `json:"session"`
	Success                bool    `json:"success"`
	LegacyResult           FileRef `json:"legacy_result"`
	DefaultResult          FileRef `json:"default_result"`
	LegacyRecords          FileRef `json:"legacy_records"`
	DefaultRecords         FileRef `json:"default_records"`
	ReplayResultBytesEqual bool    `json:"replay_result_bytes_equal"`
	RecordsGzipBytesEqual  bool    `json:"records_gzip_bytes_equal"`
	RecordsJSONLBytesEqual bool    `json:"records_jsonl_bytes_equal"`
	JSONLSHA               string  `json:"jsonl_sha256"`
	JSONLBytes             int64   `json:"jsonl_bytes"`
}

// selectScenes は台帳と条件が正確な12場を同順で持つことを検査します。
//
// 引数: sessions([]InputSession)、scenes([]SceneRef)は台帳と固定条件の場列です。
// 返り値: []InputSession/errorは独立した外側slice又は集合不一致です。入力価格は読みません。
func selectScenes(sessions []replay.InputSession, scenes []SceneRef) ([]replay.InputSession, error) {
	ids := expectedIDs()
	if len(sessions) != len(ids) || len(scenes) != len(ids) {
		return nil, fmt.Errorf("入力台帳/条件の12場不一致")
	}
	for i, id := range ids {
		if sessions[i].ID != id || scenes[i].Session != id {
			return nil, fmt.Errorf("12場の固定順が不一致:%d", i)
		}
	}
	return append([]replay.InputSession(nil), sessions...), nil
}

// validateStrategyCoverage は台帳の純戦略path/SHAも固定codeへ含めます。
//
// 引数: code(map[string]string)、root(string)、m(InputManifest)は固定code・repo・入力台帳です。
// 返り値: errorは台帳参照純戦略の固定漏れ又は正規path重複です。価格本文は開きません。
func validateStrategyCoverage(code map[string]string, root string, m replay.InputManifest) error {
	paths := map[string]string{}
	for name, h := range code {
		p, e := absolute(root, name)
		if e != nil {
			return e
		}
		key := strings.ToLower(filepath.Clean(p))
		if _, ok := paths[key]; ok {
			return fmt.Errorf("固定code正規path重複:%s", p)
		}
		paths[key] = h
	}
	for name, h := range m.StrategySHA256 {
		p, e := absolute(m.StrategyRoot, name)
		if e != nil || paths[strings.ToLower(filepath.Clean(p))] != h || !validSHA(h) {
			return fmt.Errorf("台帳純戦略が固定codeへ不足:%s", name)
		}
	}
	return nil
}

// decodedFingerprint はgzip全記録を逐次解凍して改行を含む本文SHAを求めます。
//
// 引数: path(string)は新規に生成した記録gzipです。
// 返り値: string/int64/errorはJSONL本文SHA・解凍bytes・破損です。全記録をRAMへ保持しません。
func decodedFingerprint(path string) (string, int64, error) {
	f, e := os.Open(path)
	if e != nil {
		return "", 0, e
	}
	defer f.Close()
	z, e := gzip.NewReader(f)
	if e != nil {
		return "", 0, e
	}
	defer z.Close()
	h := sha256.New()
	n, e := io.Copy(h, z)
	if e != nil {
		return "", n, e
	}
	return hex.EncodeToString(h.Sum(nil)), n, nil
}

// compareModeFiles は全ReplayResult bytesと全SourceRecord bytesを場単位で照合します。
//
// 引数: a/b(CaseReceipt)は同場の新legacy/default出力参照です。
// 返り値: MutualReceipt/errorは除外なしの相互同体証拠又は不一致です。symmetricは受けません。
func compareModeFiles(a, b CaseReceipt) (MutualReceipt, error) {
	p := MutualReceipt{Session: a.Session, LegacyResult: a.Result, DefaultResult: b.Result, LegacyRecords: a.Records, DefaultRecords: b.Records}
	if a.Session != b.Session || a.Mode != "legacy" || b.Mode != "default" || a.Error != "" || b.Error != "" || a.Old93FullMatch || b.Old93FullMatch || !reflect.DeepEqual(a.Counts, b.Counts) {
		return p, fmt.Errorf("相互照合の場/mode/件数/旧93旗が不正")
	}
	for _, ref := range []FileRef{a.Result, b.Result, a.Records, b.Records} {
		got, e := digest(ref.Path)
		if e != nil || !validSHA(ref.SHA) || got != ref.SHA {
			return p, fmt.Errorf("新出力SHA差:%s", ref.Path)
		}
	}
	x, e := os.ReadFile(a.Result.Path)
	if e != nil {
		return p, e
	}
	y, e := os.ReadFile(b.Result.Path)
	if e != nil {
		return p, e
	}
	p.ReplayResultBytesEqual = bytes.Equal(x, y)
	p.RecordsGzipBytesEqual = a.Records.SHA == b.Records.SHA
	ha, na, e := decodedFingerprint(a.Records.Path)
	if e != nil {
		return p, e
	}
	hb, nb, e := decodedFingerprint(b.Records.Path)
	if e != nil {
		return p, e
	}
	p.RecordsJSONLBytesEqual = ha == hb && na == nb
	p.JSONLSHA, p.JSONLBytes = ha, na
	p.Success = p.ReplayResultBytesEqual && p.RecordsGzipBytesEqual && p.RecordsJSONLBytesEqual
	if !p.Success {
		return p, fmt.Errorf("legacy/defaultの全ReplayResult又は全Record bytes差")
	}
	return p, nil
}

// validateMutual は先行段階の成功を正確な各場の2mode参照へ結びます。
//
// 引数: cases([]CaseReceipt)、pairs([]MutualReceipt)、ids([]string)はケース列・相互証拠・対象順です。
// 返り値: errorは欠落/重複/旧93成功誤記/別参照/同体指紋の不整合です。成果本文は開きません。
func validateMutual(cases []CaseReceipt, pairs []MutualReceipt, ids []string) error {
	if len(pairs) != len(ids) || len(cases) != 3*len(ids) {
		return fmt.Errorf("相互照合の場数/case数差")
	}
	for i, id := range ids {
		a, b, c := cases[i*3], cases[i*3+1], cases[i*3+2]
		for j, v := range []CaseReceipt{a, b, c} {
			if v.Session != id || v.Mode != []string{"legacy", "default", "symmetric"}[j] || v.Error != "" || v.Old93FullMatch {
				return fmt.Errorf("caseの固定順/旧93旗差:%s", id)
			}
			for _, ref := range []FileRef{v.Result, v.Records} {
				if strings.TrimSpace(ref.Path) == "" || !validSHA(ref.SHA) {
					return fmt.Errorf("case参照未固定:%s", id)
				}
			}
		}
		p := pairs[i]
		if p.Session != id || !p.Success || !p.ReplayResultBytesEqual || !p.RecordsGzipBytesEqual || !p.RecordsJSONLBytesEqual || !validSHA(p.JSONLSHA) || p.JSONLBytes <= 0 || p.LegacyResult != a.Result || p.DefaultResult != b.Result || p.LegacyRecords != a.Records || p.DefaultRecords != b.Records || a.Result.SHA != b.Result.SHA || a.Records.SHA != b.Records.SHA || !reflect.DeepEqual(a.Counts, b.Counts) {
			return fmt.Errorf("相互同体証拠の不整合:%s", id)
		}
	}
	return nil
}
