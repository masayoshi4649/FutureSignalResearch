package main

import (
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"reflect"
	"runtime"
	"strings"

	replay "github.com/masayoshi4649/SessionTradeExecuter/minisourcereplay104"
)

const GeneratorStopSHA = "e5192a02340de79e41c8a38643e883375682bb8f4f9fe46f5c0b91ab64d3f1cc"
const ReplayStopSHA = "2104b6609e160cf86133239554d7338d6c5ccc3446e434ad7a10751f5b39ec39"

type FileRef struct {
	Path string `json:"path"`
	SHA  string `json:"sha256"`
}
type SceneRef struct {
	Session string `json:"session"`
}
type Condition struct {
	Version       int               `json:"version"`
	Trial         int               `json:"trial"`
	Fixed         bool              `json:"fixed"`
	Manifest      FileRef           `json:"input_manifest"`
	GeneratorStop FileRef           `json:"generator_stop"`
	ReplayStop    FileRef           `json:"replay_stop"`
	Binary        FileRef           `json:"binary"`
	Code          map[string]string `json:"code_sha256"`
	Scenes        []SceneRef        `json:"scenes"`
	Modes         []string          `json:"modes"`
}
type Arguments struct{ Condition, ConditionSHA, Stage, Out, First2, First2SHA string }
type CaseReceipt struct {
	Session        string       `json:"session"`
	Mode           string       `json:"mode"`
	Result         FileRef      `json:"result"`
	Records        FileRef      `json:"records"`
	Counts         RecordCounts `json:"counts"`
	Old93FullMatch bool         `json:"old93_full_match"`
	Error          string       `json:"error,omitempty"`
}
type Completion struct {
	Version              int               `json:"version"`
	Trial                int               `json:"trial"`
	Stage                string            `json:"stage"`
	Success              bool              `json:"success"`
	ConditionSHA         string            `json:"condition_sha256"`
	Sessions             int               `json:"sessions"`
	Cases                []CaseReceipt     `json:"cases"`
	Before               map[string]string `json:"before"`
	After                map[string]string `json:"after"`
	Unchanged            bool              `json:"unchanged"`
	SourceFormed         bool              `json:"source_reformed"`
	Financial106Executed bool              `json:"financial106_executed"`
	Mutual               []MutualReceipt   `json:"legacy_default_matches"`
	Error                string            `json:"error,omitempty"`
}

type StoppedCode struct {
	Success bool              `json:"成功"`
	Owned   map[string]string `json:"所有SHA256"`
}

// cliDirectory は実行中CLIをビルドしたmain.goの実pathを返します。
//
// 引数: ありません。
// 返り値: string/errorは当CLIの絶対directory又はsource根拠不足です。
func cliDirectory() (string, error) {
	_, file, _, ok := runtime.Caller(0)
	if !ok || !filepath.IsAbs(file) || filepath.Base(file) != "main.go" {
		return "", fmt.Errorf("当CLIのsource path根拠がありません")
	}
	return filepath.Dir(file), nil
}

// validateCodeCoverage は当CLIと停止依存の正規path/SHA包含を検査します。
//
// 引数: code(map[string]string)、root/cliDir(string)、stops([]StoppedCode)は固定集合・repo・当CLI根拠・停止所有集合です。
// 返り値: errorは不足/別SHA/重複pathです。Go依存の探索は行いません。
func validateCodeCoverage(code map[string]string, root, cliDir string, stops []StoppedCode) error {
	normalized := map[string]string{}
	for name, h := range code {
		p, e := absolute(root, name)
		if e != nil || !validSHA(h) {
			return fmt.Errorf("固定codeのpath/SHAが不正です:%s", name)
		}
		key := strings.ToLower(filepath.Clean(p))
		if _, exists := normalized[key]; exists {
			return fmt.Errorf("固定codeの正規pathが重複しています:%s", p)
		}
		normalized[key] = h
	}
	for _, name := range []string{"record.go", "main.go", "相互照合.go", "go.mod", "go.sum"} {
		p, e := absolute(cliDir, name)
		if e != nil || normalized[strings.ToLower(filepath.Clean(p))] == "" {
			return fmt.Errorf("当CLIの実ファイルが未固定です:%s", name)
		}
	}
	for _, stop := range stops {
		if !stop.Success || len(stop.Owned) == 0 {
			return fmt.Errorf("依存停止の成功/所有集合が不正です")
		}
		for name, h := range stop.Owned {
			p, e := absolute(root, name)
			if e != nil || !validSHA(h) || normalized[strings.ToLower(filepath.Clean(p))] != h {
				return fmt.Errorf("停止依存の所有path/SHAが固定codeに不足しています:%s", name)
			}
		}
	}
	return nil
}

// validateFirst2Cases は先頭2場と3modeの正確な一意集合を検査します。
//
// 引数: cases([]CaseReceipt)は固定first2完了の6ケースです。
// 返り値: errorは欠落/重複/別ID/別mode/空参照/不正SHA/旧一致の誤記です。
func validateFirst2Cases(cases []CaseReceipt) error {
	wanted := map[string]bool{}
	for _, id := range expectedIDs()[:2] {
		for _, mode := range []string{"legacy", "default", "symmetric"} {
			wanted[id+"/"+mode] = true
		}
	}
	if len(cases) != len(wanted) {
		return fmt.Errorf("先頭2の6case集合が不正です")
	}
	seen := map[string]bool{}
	for _, row := range cases {
		key := row.Session + "/" + row.Mode
		if !wanted[key] || seen[key] {
			return fmt.Errorf("先頭2のcaseが重複又は対象外です:%s", key)
		}
		seen[key] = true
		if row.Error != "" || row.Old93FullMatch {
			return fmt.Errorf("先頭2の旧93成功の誤記/errorが不正です:%s", key)
		}
		for _, ref := range []FileRef{row.Result, row.Records} {
			if strings.TrimSpace(ref.Path) == "" || !validSHA(ref.SHA) {
				return fmt.Errorf("先頭2の成果参照が未固定です:%s", key)
			}
		}
	}
	return nil
}

// fingerprintOutput は出力hashの取得失敗を成功に補わず返します。
//
// 引数: path(string)はclose済みの新規出力です。
// 返り値: FileRef/errorはpath/SHA又は読取失敗です。
func fingerprintOutput(path string) (FileRef, error) {
	h, e := digest(path)
	return FileRef{Path: path, SHA: h}, e
}

// digest は明示された一ファイルを逐次hashします。
//
// 引数: path(string)は固定metadata又はRoot許可後の実入力です。
// 返り値: string/errorはSHA256又は読取失敗です。
func digest(path string) (string, error) {
	f, e := os.Open(path)
	if e != nil {
		return "", e
	}
	defer f.Close()
	h := sha256.New()
	if _, e = io.Copy(h, f); e != nil {
		return "", e
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}

// validSHA は未固定の空/不正SHAを拒否します。
//
// 引数: s(string)は期待指紋です。
// 返り値: boolは小文字64桁のとき真です。
func validSHA(s string) bool {
	b, e := hex.DecodeString(s)
	return e == nil && len(b) == 32 && strings.ToLower(s) == s
}

// absolute は明示した基準で相対pathを解決します。
//
// 引数: base/path(string)は基準と入力pathです。
// 返り値: string/errorは絶対path又は空pathです。
func absolute(base, path string) (string, error) {
	if path == "" {
		return "", fmt.Errorf("空path")
	}
	if !filepath.IsAbs(path) {
		path = filepath.Join(base, path)
	}
	return filepath.Abs(path)
}

// load は一つのJSON以外を拒否して読みます。
//
// 引数: path(string)、v(any)、strict(bool)は読取先・型・未知欄拒否です。
// 返り値: errorは型/末尾値等の破損です。
func load(path string, v any, strict bool) error {
	f, e := os.Open(path)
	if e != nil {
		return e
	}
	defer f.Close()
	d := json.NewDecoder(f)
	if strict {
		d.DisallowUnknownFields()
	}
	if e = d.Decode(v); e != nil {
		return e
	}
	var tail any
	if e = d.Decode(&tail); e != io.EOF {
		return fmt.Errorf("JSON末尾破損")
	}
	return nil
}

// writeNew は既存成果物を上書きせずJSONを保存します。
//
// 引数: path(string)、v(any)は新規保存先と公開値です。
// 返り値: errorは保存失敗です。
func writeNew(path string, v any) error {
	f, e := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if e != nil {
		return e
	}
	enc := json.NewEncoder(f)
	enc.SetEscapeHTML(false)
	e = enc.Encode(v)
	if close := f.Close(); e == nil {
		e = close
	}
	return e
}

// expectedIDs は106不足12場だけを返します。
//
// 引数: ありません。
// 返り値: []stringは10月28日から11月4日の不足Day/Nightを時計順に並べた値です。
func expectedIDs() []string {
	return []string{"2026-10-28_Day", "2026-10-28_Night", "2026-10-29_Day", "2026-10-29_Night", "2026-10-30_Day", "2026-10-30_Night", "2026-11-02_Day", "2026-11-02_Night", "2026-11-03_Day", "2026-11-03_Night", "2026-11-04_Day", "2026-11-04_Night"}
}

// Preflight はRoot条件を先に検査し、未固定のまま原板を開きません。
//
// 引数: a(Arguments)、root/exe(string)はCLI・repo基準・実行中binaryです。
// 返り値: Condition/InputManifest/対象場/map/errorは固定設定と前指紋又は拒否です。
func Preflight(a Arguments, root, exe string) (Condition, replay.InputManifest, []replay.InputSession, map[string]string, error) {
	var c Condition
	var m replay.InputManifest
	fail := func(e error) (Condition, replay.InputManifest, []replay.InputSession, map[string]string, error) {
		return c, m, nil, nil, e
	}
	if !validSHA(a.ConditionSHA) || (a.Stage != "first2" && a.Stage != "full12") {
		return fail(fmt.Errorf("Root条件SHA/stageが未固定です"))
	}
	cp, e := filepath.Abs(a.Condition)
	if e != nil {
		return fail(e)
	}
	h, e := digest(cp)
	if e != nil || h != a.ConditionSHA {
		return fail(fmt.Errorf("Root条件指紋差"))
	}
	if e = load(cp, &c, true); e != nil {
		return fail(e)
	}
	if c.Version != 1 || c.Trial != 106 || !c.Fixed || len(c.Scenes) != 12 || len(c.Code) == 0 || !reflect.DeepEqual(c.Modes, []string{"legacy", "default", "symmetric"}) || c.GeneratorStop.SHA != GeneratorStopSHA || c.ReplayStop.SHA != ReplayStopSHA {
		return fail(fmt.Errorf("Rootの全条件/生成口停止が未固定です"))
	}
	before := map[string]string{cp: h}
	base := filepath.Dir(cp)
	check := func(ref FileRef, dir string) (string, error) {
		if !validSHA(ref.SHA) {
			return "", fmt.Errorf("未固定SHA")
		}
		p, e := absolute(dir, ref.Path)
		if e != nil {
			return "", e
		}
		h, e := digest(p)
		if e != nil || h != ref.SHA {
			return "", fmt.Errorf("指紋差:%s", p)
		}
		before[p] = h
		return p, nil
	}
	for p, h := range c.Code {
		if _, e = check(FileRef{p, h}, root); e != nil {
			return fail(e)
		}
	}
	stops := []StoppedCode{}
	for _, ref := range []FileRef{c.GeneratorStop, c.ReplayStop} {
		p, e := check(ref, base)
		if e != nil {
			return fail(e)
		}
		var stop StoppedCode
		if e = load(p, &stop, false); e != nil {
			return fail(e)
		}
		stops = append(stops, stop)
	}
	cliDir, e := cliDirectory()
	if e != nil {
		return fail(e)
	}
	if e = validateCodeCoverage(c.Code, root, cliDir, stops); e != nil {
		return fail(e)
	}
	binary, e := check(c.Binary, base)
	if e != nil {
		return fail(e)
	}
	actual, e := filepath.Abs(exe)
	if e != nil || !strings.EqualFold(actual, binary) {
		return fail(fmt.Errorf("実binary path差"))
	}
	mp, e := check(c.Manifest, base)
	if e != nil {
		return fail(e)
	}
	if e = load(mp, &m, false); e != nil {
		return fail(e)
	}
	if !filepath.IsAbs(m.Root) {
		m.Root, _ = absolute(filepath.Dir(mp), m.Root)
	}
	if !filepath.IsAbs(m.StrategyRoot) {
		m.StrategyRoot, _ = absolute(filepath.Dir(mp), m.StrategyRoot)
	}
	if e = validateStrategyCoverage(c.Code, root, m); e != nil {
		return fail(e)
	}
	if e = replay.ValidateManifest(m); e != nil {
		return fail(e)
	}
	ids := expectedIDs()
	selected, e := selectScenes(m.Sessions, c.Scenes)
	if e != nil {
		return fail(e)
	}
	if a.Stage == "first2" {
		if a.First2 != "" || a.First2SHA != "" {
			return fail(fmt.Errorf("first2へ旧receipt指定"))
		}
		selected = selected[:2]
	} else {
		fp, e := check(FileRef{a.First2, a.First2SHA}, base)
		if e != nil {
			return fail(e)
		}
		var f Completion
		if e = load(fp, &f, true); e != nil {
			return fail(e)
		}
		if f.Version != 1 || !f.Success || f.Error != "" || f.Trial != 106 || f.Stage != "first2" || f.ConditionSHA != a.ConditionSHA || f.Sessions != 2 || !f.Unchanged || !reflect.DeepEqual(f.Before, f.After) || !f.SourceFormed || f.Financial106Executed {
			return fail(fmt.Errorf("同条件の先頭2成功が必要です"))
		}
		if e = validateFirst2Cases(f.Cases); e != nil {
			return fail(e)
		}
		if e = validateMutual(f.Cases, f.Mutual, ids[:2]); e != nil {
			return fail(e)
		}
		for p, h := range before {
			if p != fp && f.Before[p] != h {
				return fail(fmt.Errorf("first2とのcode/binary/固定metadata差:%s", p))
			}
		}
		for _, r := range f.Cases {
			if _, e = check(r.Result, filepath.Dir(fp)); e != nil {
				return fail(e)
			}
			if _, e = check(r.Records, filepath.Dir(fp)); e != nil {
				return fail(e)
			}
		}
	}
	// 全条件が固まった後だけ対象段階の6実入力をhashする。
	for _, s := range selected {
		for _, f := range s.Files {
			if _, e = check(FileRef{f.Path, f.SHA256}, m.Root); e != nil {
				return fail(e)
			}
		}
	}
	return c, m, selected, before, nil
}

// run はRoot固定後だけ全StepResultを逐次保存して新legacy/default相互の全保存値を照合します。
//
// 引数: a(Arguments)、root/exe(string)は起動設定です。
// 返り値: Completion/errorは新Source再形成の完了又は失敗です。106金融は実行しません。
func run(a Arguments, root, exe string) (Completion, error) {
	out := Completion{Version: 1, Trial: 106, Stage: a.Stage, ConditionSHA: a.ConditionSHA, Cases: []CaseReceipt{}, Mutual: []MutualReceipt{}}
	c, m, scenes, before, e := Preflight(a, root, exe)
	if e != nil {
		return out, e
	}
	out.Before = before
	out.Sessions = len(scenes)
	if a.Out == "" {
		return out, fmt.Errorf("新規出力先が必要")
	}
	dir, e := filepath.Abs(a.Out)
	if e != nil {
		return out, e
	}
	if _, e = os.Stat(dir); !os.IsNotExist(e) {
		return out, fmt.Errorf("既存出力を拒否")
	}
	if e = os.MkdirAll(filepath.Dir(dir), 0700); e != nil {
		return out, e
	}
	if e = os.Mkdir(dir, 0700); e != nil {
		return out, e
	}
	for _, input := range scenes {
		pairStart := len(out.Cases)
		for _, mode := range c.Modes {
			row := CaseReceipt{Session: input.ID, Mode: mode}
			prefix := filepath.Join(dir, input.ID+"_"+mode)
			deltaPath := prefix + ".deltas.jsonl.gz"
			f, e := os.OpenFile(deltaPath, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
			if e != nil {
				return out, e
			}
			z := gzip.NewWriter(f)
			enc := json.NewEncoder(z)
			recorder := &Recorder{Sink: func(v SourceRecord) error { return enc.Encode(v) }}
			factory, e := recorder.Factory(mode)
			var value replay.ReplayResult
			if e == nil {
				out.SourceFormed = true
				value, e = replay.ReplayWithFactory(m.Root, input, factory)
			}
			if close := z.Close(); e == nil {
				e = close
			}
			if close := f.Close(); e == nil {
				e = close
			}
			row.Counts = recorder.Counts
			var recordsError error
			row.Records, recordsError = fingerprintOutput(deltaPath)
			if e == nil {
				e = recordsError
			}
			if e == nil {
				row.Result.Path = prefix + ".result.json"
				e = writeNew(row.Result.Path, value)
				if e == nil {
					row.Result.SHA, e = digest(row.Result.Path)
				}
			}
			if e != nil {
				row.Error = e.Error()
				out.Error = input.ID + "/" + mode + ":" + e.Error()
			}
			out.Cases = append(out.Cases, row)
			if e != nil {
				break
			}
		}
		if out.Error == "" {
			proof, err := compareModeFiles(out.Cases[pairStart], out.Cases[pairStart+1])
			if err != nil {
				out.Error = input.ID + ":legacy/default:" + err.Error()
			} else {
				out.Mutual = append(out.Mutual, proof)
			}
		}
		if out.Error != "" {
			break
		}
	}
	out.After = map[string]string{}
	for p := range before {
		h, e := digest(p)
		out.After[p] = h
		if e != nil && out.Error == "" {
			out.Error = e.Error()
		}
	}
	out.Unchanged = reflect.DeepEqual(out.Before, out.After)
	if !out.Unchanged && out.Error == "" {
		out.Error = "入力/code/binary前後差"
	}
	if out.Error == "" {
		ids := []string{}
		for _, scene := range scenes {
			ids = append(ids, scene.ID)
		}
		if err := validateMutual(out.Cases, out.Mutual, ids); err != nil {
			out.Error = err.Error()
		}
	}
	out.Success = out.Error == "" && len(out.Cases) == 3*len(scenes)
	if e = writeNew(filepath.Join(dir, "完了.json"), out); e != nil {
		return out, e
	}
	if !out.Success {
		return out, fmt.Errorf("%s", out.Error)
	}
	return out, nil
}

// repository はcode相対pathのrepo基準を見つけます。
//
// 引数: ありません。
// 返り値: string/errorはstudy/scripts祖先又は未検出です。
func repository() (string, error) {
	p, e := os.Getwd()
	if e != nil {
		return "", e
	}
	for {
		a, ae := os.Stat(filepath.Join(p, "study"))
		b, be := os.Stat(filepath.Join(p, "scripts"))
		if ae == nil && be == nil && a.IsDir() && b.IsDir() {
			return p, nil
		}
		next := filepath.Dir(p)
		if next == p {
			return "", fmt.Errorf("repo基準なし")
		}
		p = next
	}
}

// main は条件未固定ならSourceや原板読込より前に終了します。
//
// 引数: CLIはcondition/condition-sha/stage/out/first2/first2-shaです。
// 返り値: ありません。未固定/対照差/未完結は終了1です。
func main() {
	a := Arguments{}
	flag.StringVar(&a.Condition, "condition", "", "Root固定条件")
	flag.StringVar(&a.ConditionSHA, "condition-sha", "", "条件SHA")
	flag.StringVar(&a.Stage, "stage", "first2", "first2/full12")
	flag.StringVar(&a.Out, "out", "", "新規出力")
	flag.StringVar(&a.First2, "first2", "", "同条件先頭2完了")
	flag.StringVar(&a.First2SHA, "first2-sha", "", "先頭2SHA")
	flag.Parse()
	root, e := repository()
	if e == nil {
		var exe string
		exe, e = os.Executable()
		if e == nil {
			_, e = run(a, root, exe)
		}
	}
	if e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
}
