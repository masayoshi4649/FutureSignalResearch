"""Root成功後だけ106 Native/Source結果/不足再現コードを正式保存する。"""

import argparse
from collections import Counter
import gzip
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import zipfile


ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
TRIAL = ROOT / "study/00106_収束失速で保護の起動と幅を切り替える"
CONDITION_SHA = "d9319e0f5757cd198329f8d4e272f1cc6af8b084ea8a8cd80bd10d77c39f809f"
SOURCE_SHA = "1b719602ba6beb7ebe6379bc7bfe362efef3ea402d3e200fd5fb810cfd4c56c1"
GOROOT = Path("C:/Program Files/Go")
MODCACHE = Path("C:/Users/masay/go/pkg/mod")
CODE_SUFFIX = {".go", ".py", ".md", ".json", ".mjs", ".js", ".mod", ".sum", ".patch", ".s", ".h"}


def need(value, reason):
    """
    機能: 保存前提又はbytes照合の失敗を明示する。
    引数: value(bool)、reason(str)は真偽と理由。
    返り値: None。偽ならValueError。
    """
    if not value:
        raise ValueError(reason)


def sha(path):
    """
    機能: 明示ファイルをstreamで指紋化する。
    引数: path(Path)はRoot許可後の保存物又はコードmetadata。
    返り値: strはSHA256。読取対象を探索しない。
    """
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path):
    """
    機能: 条件/停止/完了/保存計画のmetadataだけを読む。
    引数: path(Path)はsmall JSON。
    返り値: dict。金融Native/Source result本文のJSON解析には使わない。
    """
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write(path, value):
    """
    機能: UTF-8 JSONを排他的に新規保存する。
    引数: path(Path)、value(dict)は先と内容。
    返り値: None。既存ファイルを変更しない。
    """
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def valid_sha(value):
    """
    機能: 小文字の完全SHA256を検査する。
    引数: value(any)は宣言指紋。
    返り値: boolは64桁16進だけ真。
    """
    return isinstance(value, str) and len(value) == 64 and set(value) <= set("0123456789abcdef")


def resolve(ref, base, verify=True):
    """
    機能: FileRefを明示基準で解決し必要時だけ内容SHAを検査する。
    引数: ref(dict)、base(Path)、verify(bool)は参照・基準・内容読取指定。
    返り値: Path。容量metadataでverify=Falseならstat以外に本文を開かない。
    """
    need(isinstance(ref, dict) and set(ref) == {"path", "sha256"} and isinstance(ref["path"], str) and ref["path"].strip() and valid_sha(ref["sha256"]), "FileRef不正")
    path = (base / ref["path"]).resolve()
    need(path.is_file(), "参照ファイルなし:" + str(path))
    if verify:
        need(sha(path) == ref["sha256"], "FileRef SHA差:" + str(path))
    return path


def file_ref(path, base):
    """
    機能: 正式trialdir等を基準に相対参照を作る。
    引数: path/base(Path)は保存物と基準。
    返り値: dictはpath/sha256/bytes。
    """
    return {"path": os.path.relpath(path, base).replace("\\", "/"), "sha256": sha(path), "bytes": path.stat().st_size}


def safe(name):
    """
    機能: ZIP内の相対pathが復元可能で安全か検査する。
    引数: name(str)は論理rootを含むentry。
    返り値: boolは絶対/drive/親移動/逆slashなしだけ真。
    """
    return bool(name) and not name.startswith("/") and "\\" not in name and ":" not in name and ".." not in PurePosixPath(name).parts


def restore(path):
    """
    機能: 原位置を再配置用の独立rootと相対pathへ分離する。
    引数: path(Path)は解決済みコード位置。
    返り値: dictはroot/relative。GoRootは本文非同梱の環境参照。
    """
    for name, base in (("repoRoot", ROOT), ("neighborRoot", ROOT.parent), ("moduleCacheRoot", MODCACHE), ("goRoot", GOROOT)):
        if path.is_relative_to(base):
            rel = path.relative_to(base).as_posix()
            need(safe(rel), "復元相対path不正")
            return {"root": name, "relative": rel}
    raise ValueError("未定義root:" + str(path))


def read_plan(path, expected, published=False):
    """
    機能: Root作成の保存計画と市場前条件を固定する。
    引数: path(Path)、expected(str)、published(bool)は計画・SHA・正式書込要求。
    返り値: tupleは計画/条件/条件位置。未固定計画から正式書込しない。
    """
    need(valid_sha(expected) and sha(path) == expected, "保存計画SHA")
    p = load(path)
    need(p["version"] == 1 and p["trial"] == 106, "106保存計画")
    if published:
        need(p["fixed"] is True and p["root_authorized_after_success"] is True, "Root成功後の保存計画固定が必要")
    cp = resolve(p["condition"], path.parent)
    need(p["condition"]["sha256"] == CONDITION_SHA, "固定金融条件の改変禁止")
    c = load(cp)
    need(c["version"] == 1 and c["trial"] == 106 and c["fixed"] is True and len(c["code_sha256"]) == 1281, "市場前1281code")
    return p, c, cp


def metadata_cases(p, c, base, cp):
    """
    機能: Source12と標準70の完了metadataだけを検査する。
    引数: p/c(dict)、base/cp(Path)は保存計画/条件/各基準。
    返り値: tupleはSource完了/位置/70ID/Corpus。result/recordsは開かない。
    """
    sp = resolve(p["source_completion"], base)
    need(p["source_completion"]["sha256"] == SOURCE_SHA == c["source12_completion"]["sha256"] and sp == resolve(c["source12_completion"], cp.parent), "Source12固定参照")
    s = load(sp)
    need(s["version"] == 1 and s["trial"] == 106 and s["success"] is True and s["stage"] == "full12" and s["sessions"] == 12 and s["source_reformed"] is True and s["financial106_executed"] is False and not s.get("error"), "Source全12未成功")
    need(s["unchanged"] is True and s["before"] and s["before"] == s["after"], "Source前後不変")
    mp = resolve(c["input_manifest"], cp.parent); ids = [x["id"] for x in load(mp)["sessions"]]
    need(len(ids) == len(set(ids)) == 70 and ids == sorted(ids), "標準70集合")
    need(len(s["cases"]) == 36 and {(x["session"], x["mode"]) for x in s["cases"]} == {(i, mode) for i in ids[54:66] for mode in ("legacy", "default", "symmetric")}, "Source12x3一意集合")
    for x in s["cases"]:
        need(x["old93_full_match"] is False and not x.get("error"), "新12へ旧golden混入")
        resolve(x["result"], sp.parent, False); resolve(x["records"], sp.parent, False)
    corpus_path = resolve(c["source_corpus"], cp.parent)
    corpus = load(corpus_path)
    need(corpus["version"] == 1 and corpus["trial"] == 106 and corpus["fixed"] is True and [x["session"] for x in corpus["scenes"]] == ids, "Corpus70の時系列集合")
    for scene in corpus["scenes"]:
        if scene.get("w0_native"):
            scene["w0_native"]["path"] = str((corpus_path.parent / scene["w0_native"]["path"]).resolve())
    return s, sp, ids, corpus


def estimate(plan_path, plan_sha, output):
    """
    機能: 市場本文未読で先頭2サイズ/Source結果stat/コード所在を見積もる。
    引数: plan_path/output(Path)、plan_sha(str)は未固定計画と新規JSON先。
    返り値: dictは実測metadataと限定的外挿。全70部分結果を探さない。
    """
    need(not output.exists(), "見積先は新規")
    p, c, cp = read_plan(plan_path, plan_sha)
    s, sp, ids, corpus = metadata_cases(p, c, plan_path.parent, cp)
    firstp = resolve(p["financial_first2"], plan_path.parent); first = load(firstp)
    need(first["success"] is True and first["stage"] == "first2" and first["condition_sha256"] == CONDITION_SHA and first["sessions"] == 2 and first["books"] == 40 and [x["session"] for x in first["results"]] == ids[:2], "許可された金融先頭2metadata")
    native = [{"session": x["session"], "宣言SHA256": x["native"]["sha256"], "bytes": resolve(x["native"], firstp.parent, False).stat().st_size} for x in first["results"]]
    groups = {}
    source_rows = []
    for x in s["cases"]:
        size = resolve(x["result"], sp.parent, False).stat().st_size
        key = x["result"]["sha256"]
        need(key not in groups or groups[key] == size, "同宣言SHAのsize矛盾")
        groups[key] = size
        source_rows.append({"session": x["session"], "mode": x["mode"], "宣言SHA256": key, "bytes": size})
    roots, sizes = Counter(), Counter()
    for name in c["code_sha256"]:
        path = (ROOT / name).resolve(); r = restore(path)["root"]
        roots[r] += 1; sizes[r] += path.stat().st_size
    result = {"成功": True, "試行": 106, "scope": "metadata/statと許可先頭2だけ。全70部分Native/Source結果本文/Raw/CSV未読", "金融条件SHA256": CONDITION_SHA,
              "先頭2Native": native, "先頭2bytes計": sum(x["bytes"] for x in native), "単純70場外挿bytes": sum(x["bytes"] for x in native) * 35,
              "外挿の限界": "2場/3玉程度の小標本からの単純サイズ比。場別Source活動・保存点・audit件数により大差があり容量保証ではない",
              "Source12結果": source_rows, "宣言SHA別群数": len(groups), "宣言SHA別非圧縮bytes計": sum(groups.values()),
              "Source圧縮後": None, "Source圧縮後の未測定理由": "本文を開いていないため。実保存時に全36参照を現物SHA確認し、同SHAの結果だけgzip共用",
              "固定code数": len(c["code_sha256"]), "codeRoot件数": dict(roots), "codeRoot元size": dict(sizes),
              "GoRoot": "go1.24.2/全元SHA/原位置/サイズを索引。stdlib/tool本文は非同梱", "W0旧58": "旧104sym54/105sym4の元参照を共用。新20冊NativeのW0 fieldは削らない",
              "正式保存": "未実施", "市場本文/Raw/CSV/Source/金融実行": 0}
    write(output, result)
    return result


def validate_finance(v, ids):
    """
    機能: 全70金融の成功と一意集合を価格本文前に要求する。
    引数: v(dict)、ids(list[str])は金融完了metadataと固定70ID。
    返り値: None。失敗/途中結果を保存成功へ昇格しない。
    """
    need(v["version"] == 1 and v["trial"] == 106 and v["stage"] == "full70" and v["success"] is True and v["condition_sha256"] == CONDITION_SHA and not v.get("error"), "金融全70未成功")
    need(v["sessions"] == 70 and v["books_per_scene"] == 20 and v["books"] == 1400 and [x["session"] for x in v["results"]] == ids, "金融70/1400完全集合")
    need(v["unchanged"] is True and v["before"] and v["before"] == v["after"] and v["source_reexecuted"] is False and v["financial_executed"] is True, "金融前後不変/Source再形成なし")
    for i, x in enumerate(v["results"]):
        need(x["books"] == 20 and x["w0_control_books"] == 4 and not x.get("error"), "一場20/旧対照4未成功")
        need(x["control_kind"] == ("same_input_old103" if 54 <= i < 66 else "provided_old_book"), "既存58/追加12対照区分")


def bind_first2(p, finance, base, finance_base, ids):
    """
    機能: Root指定の先頭2成功を同条件full70の先頭bytesへ結ぶ。
    引数: p/finance(dict)、base/finance_base(Path)、ids(list[str])は計画/全完了/基準/固定ID。
    返り値: None。Native本文を読まず宣言SHA/完了metadataで検査する。
    """
    first_path = resolve(p["financial_first2"], base)
    need(first_path == resolve(finance["first2"], finance_base), "full70と同じfirst2参照")
    first = load(first_path)
    need(first["success"] is True and first["stage"] == "first2" and first["condition_sha256"] == CONDITION_SHA and first["sessions"] == 2 and first["books"] == 40 and [x["session"] for x in first["results"]] == ids[:2], "先頭2成功metadata")
    for i in range(2):
        for kind in ("native", "sidecar_header", "sidecar_records"):
            need(first["results"][i][kind]["sha256"] == finance["results"][i][kind]["sha256"], "同条件先頭2再処理bytes")


def copy_native(rows, base, target, trial):
    """
    機能: 完成Nativeを原bytesで複写し全参照を登録する。
    引数: rows(list[dict])、base/target/trial(Path)は完了行・元基準・新規候補dir・正式根。
    返り値: tupleは索引行と元指紋。JSON本文の解析や金融計算をしない。
    """
    target.mkdir(parents=True)
    result, before = [], {}
    for row in rows:
        source = resolve(row["native"], base)
        need(source.suffix == ".gz", "金融Nativeは完成gzip")
        dest = target / (row["session"] + ".Native.json.gz")
        with source.open("rb") as src, dest.open("xb") as dst:
            shutil.copyfileobj(src, dst)
        need(sha(dest) == row["native"]["sha256"], "Native同bytes差")
        before[str(source)] = row["native"]["sha256"]
        result.append({"session": row["session"], "path": "成果物_金融/Native/" + dest.name, "sha256": sha(dest), "bytes": dest.stat().st_size,
                       "会計": 20, "元": {"path": os.path.relpath(source, trial).replace("\\", "/"), "sha256": row["native"]["sha256"]}, "同bytes": True,
                       "公開sidecar": {k: {"path": os.path.relpath((base / row[k]["path"]).resolve(), trial).replace("\\", "/"), "sha256": row[k]["sha256"]} for k in ("sidecar_header", "sidecar_records")}})
    return result, before


def compress_source(cases, base, target):
    """
    機能: 全caseの現物SHAを確認し同contentのSource結果だけを共用gzipへ保存する。
    引数: cases(list[dict])、base/target(Path)はSource全36case/元根/候補dir。
    返り値: tupleは全case索引・unique群・元指紋。recordsは参照を保ち本文を開かない。
    """
    target.mkdir(parents=True)
    rows, groups, before = [], {}, {}
    for case in cases:
        source = resolve(case["result"], base)
        need(source.suffix == ".json", "Source結果JSONだけ")
        h = case["result"]["sha256"]; before[str(source)] = h
        if h not in groups:
            dest = target / (h + ".json.gz")
            with source.open("rb") as src, dest.open("xb") as dst:
                with gzip.GzipFile(filename="", mode="wb", fileobj=dst, compresslevel=6, mtime=0) as gz:
                    shutil.copyfileobj(src, gz)
            with gzip.open(dest, "rb") as stream:
                decoded = hashlib.file_digest(stream, "sha256").hexdigest()
            need(decoded == h, "Source gzip復元SHA差")
            groups[h] = {"path": "成果物_Source/Result/" + dest.name, "sha256": sha(dest), "bytes": dest.stat().st_size,
                         "原JSON_SHA256": h, "解凍SHA256": decoded, "元bytes": source.stat().st_size}
        records = dict(case["records"])
        records["path"] = str((base / records["path"]).resolve())
        rows.append({"session": case["session"], "mode": case["mode"], **groups[h], "元結果": {"path": str(source), "sha256": h},
                     "records_workRef": records, "旧93golden": False, "経済成績による選別": False})
    return rows, groups, before


def publish_data(plan_path, plan_sha, candidate):
    """
    機能: Root成功後に候補bytesを全照合してから正式保存する。
    引数: plan_path/candidate(Path)、plan_sha(str)はRoot封印計画/新規候補dir。
    返り値: dictは正式Native70/Source36索引。途中失敗から成功receiptを作らない。
    """
    need(not candidate.exists() and candidate.is_relative_to(OWN), "候補dirは本work内の新規先")
    p, c, cp = read_plan(plan_path, plan_sha, True)
    s, sp, ids, corpus = metadata_cases(p, c, plan_path.parent, cp)
    fp = resolve(p["financial_full70"], plan_path.parent); finance = load(fp)
    validate_finance(finance, ids)
    bind_first2(p, finance, plan_path.parent, fp.parent, ids)
    need((plan_path.parent / p["trial_dir"]).resolve() == TRIAL, "正式106だけを保存先にする")
    targets = [TRIAL / "成果物_金融", TRIAL / "成果物_Source", TRIAL / "NativeとSource結果の保存確認.json"]
    need(not any(x.exists() for x in targets), "正式保存先は全て新規")
    rows, before = copy_native(finance["results"], fp.parent, candidate / "成果物_金融/Native", TRIAL)
    sr, groups, more = compress_source(s["cases"], sp.parent, candidate / "成果物_Source/Result")
    before.update(more); before[str(fp)] = p["financial_full70"]["sha256"]; before[str(sp)] = SOURCE_SHA; before[str(cp)] = CONDITION_SHA
    old_refs = [{"session": x["session"], "kind": x["kind"], "w0_native": x.get("w0_native"), "市場golden": "既存保存58" if x.get("w0_native") else "追加12は同入力旧103新対照"} for x in corpus["scenes"]]
    write(candidate / "成果物_金融/Native参照台帳.json", {"成功": True, "試行": 106, "基準": "trialdir", "場数": 70, "金融会計": 1400,
          "元金融完了": file_ref(fp, TRIAL), "Native": rows, "W0旧参照の共用": old_refs,
          "公開sidecar": "元workのheader/records参照のみ。新20冊Native内の全金融fieldは保持", "金融本文JSON解析/再実行": 0})
    write(candidate / "成果物_Source/Source結果参照台帳.json", {"成功": True, "試行": 106, "基準": "trialdir", "場数": 12, "case数": 36,
          "元Source完了": file_ref(sp, TRIAL), "case": sr, "共用content群": len(groups), "scope": "Source連続会計の完成結果。106 B5Q可変保護20冊とは別。旧93golden対象外", "records保存": "work参照のみ"})
    need(all(sha(Path(k)) == h for k, h in before.items()), "保存元の前後変更")
    receipt = {"成功": True, "試行": 106, "計画SHA256": plan_sha, "金融完了SHA256": p["financial_full70"]["sha256"], "Source完了SHA256": SOURCE_SHA,
               "Native数": 70, "経済会計": 1400, "Sourcecase": 36, "Source共用gzip数": len(groups),
               "元指紋前": before, "元指紋後": dict(before), "前後不変": True, "Native同bytes": True, "Source解凍bytes同体": True,
               "市場/Raw/CSV/Source/金融/Viewer再実行": 0, "候補照合後の正式公開": True}
    # ----------------------------------------
    # 失敗し得る検査は候補で済ませる。正式先へは排他的rename、成功receiptは最後。
    for name in ("成果物_金融", "成果物_Source"):
        os.rename(candidate / name, TRIAL / name)
    write(targets[-1], receipt)
    return {k: receipt[k] for k in ("成功", "Native数", "経済会計", "Sourcecase", "Source共用gzip数")}


def collect_codes(p, c, base):
    """
    機能: 固定1281と追加small codeを全元path/SHAで列挙する。
    引数: p/c(dict)、base(Path)はRoot保存計画/市場条件/計画根。
    返り値: dictは原絶対path→所在情報。GoRootは本文非同梱、価格成果物を追加しない。
    """
    items = {}
    def add(path, expected, role):
        """
        機能: 一つの許可コード又はsmall metadataを固定する。
        引数: path(Path)、expected/role(str)は位置・期待指紋・区分。
        返り値: None。禁止拡張子/巨大JSON/人工全帳簿は拒否する。
        """
        path = path.resolve(); r = restore(path)
        need(sha(path) == expected, "code SHA差:" + str(path))
        if r["root"] != "goRoot":
            need(path.suffix in CODE_SUFFIX and not path.name.endswith((".Native.json", ".result.json", ".resources.json")), "コードZIP対象外:" + str(path))
            need(not (path.suffix == ".json" and any(part in ("人工_停止版", "人工", "成果物", "成果物_金融", "成果物_Source") for part in path.parts)), "全人工/市場JSONは非同梱")
            need(path.stat().st_size < 5_000_000, "small code/metadata上限")
        key = str(path)
        if key not in items:
            items[key] = {"original_path": path.as_posix(), "SHA256": expected, "bytes": path.stat().st_size, "restore": r, "roles": []}
        need(items[key]["SHA256"] == expected, "同path二指紋")
        if role not in items[key]["roles"]:
            items[key]["roles"].append(role)
    for name, h in c["code_sha256"].items():
        add(ROOT / name, h, "金融市場前固定1281")
    for ref in p["postprocess_stops"]:
        path = resolve(ref, base); s = load(path)
        need(s["成功"] is True, "追加停止未成功")
        add(path, ref["sha256"], "追加停止原文")
        for field in ("所有SHA256", "所有コードSHA256"):
            for name, h in s.get(field, {}).items():
                add(ROOT / name, h, "追加停止所有")
        # 保存器が実際に再用するPython推移先を落とさない。人工本文/Go cache等は別参照。
        for field in ("依存SHA256前", "由来SHA256", "依存SHA256"):
            if isinstance(s.get(field), dict):
                for name, h in s[field].items():
                    if Path(name).suffix == ".py" and valid_sha(h):
                        add(ROOT / name, h, "追加Python参照")
    for ref in p["extra_files"]:
        path = resolve(ref, base); add(path, ref["sha256"], "Root事後再現/保存helper")
    return items


def archive_codes(items, archives, base, target):
    """
    機能: 既存同SHA entryを共用し不足コードだけ新ZIPへ保存する。
    引数: items(dict)、archives(list[FileRef])、base/target(Path)は全所在・旧archive・基準・新規ZIP先。
    返り値: tupleは全所在/旧archive参照/新entry数。全新entry読戻しSHA/CRCを検査する。
    """
    need(not target.exists(), "新ZIP先が存在")
    by_sha, old_refs = {}, []
    for ref in archives:
        path = resolve(ref, base)
        relative = {"path": os.path.relpath(path, TRIAL).replace("\\", "/"), "sha256": ref["sha256"]}
        old_refs.append({**relative, "absolute_path": str(path)})
        with zipfile.ZipFile(path) as z:
            need(z.testzip() is None, "旧archive CRC差")
            for info in z.infolist():
                if not info.is_dir() and safe(info.filename):
                    h = hashlib.sha256(z.read(info)).hexdigest()
                    by_sha.setdefault(h, {"kind": "既存archive", "archive": relative, "entry": info.filename})
    missing = {}
    for item in items.values():
        if item["restore"]["root"] == "goRoot":
            item["location"] = {"kind": "外部Go環境", "version": "go1.24.2", "root": "goRoot", "relative": item["restore"]["relative"], "本文保存": False}
        elif item["SHA256"] in by_sha:
            item["location"] = by_sha[item["SHA256"]]
        else:
            name = item["restore"]["root"] + "/" + item["restore"]["relative"]
            need(safe(name) and name not in missing, "ZIP entry衝突")
            missing[name] = item
            item["location"] = {"kind": "新archive", "entry": name}
    with zipfile.ZipFile(target, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, item in sorted(missing.items()):
            z.write(item["original_path"], name)
    with zipfile.ZipFile(target) as z:
        need(z.testzip() is None and set(z.namelist()) == set(missing), "新ZIP CRC/集合差")
        for name, item in missing.items():
            need(safe(name) and hashlib.sha256(z.read(name)).hexdigest() == item["SHA256"], "新ZIP entry SHA差")
    return items, old_refs, len(missing)


def publish_code(plan_path, plan_sha, candidate):
    """
    機能: Root追加helper最終確定後に1281所在と不足ZIPを正式保存する。
    引数: plan_path/candidate(Path)、plan_sha(str)はRoot封印計画と新規候補dir。
    返り値: dictは所在数と新entry数。移植/再build/金融実行をしない。
    """
    p, c, cp = read_plan(plan_path, plan_sha, True)
    need(p["pending"] == [] and p["root_extra_code_final"] is True, "追加code/停止の未確定を補完しない")
    need(not candidate.exists() and candidate.is_relative_to(OWN) and (plan_path.parent / p["trial_dir"]).resolve() == TRIAL, "新規候補と正式106根")
    # 市場成功は小完了metadataだけで要求。本文はcodeZIPへ入れない。
    _, _, ids, _ = metadata_cases(p, c, plan_path.parent, cp)
    fp = resolve(p["financial_full70"], plan_path.parent); validate_finance(load(fp), ids)
    names = ("再現コード_不足分.zip", "再現コードの所在.json", "再現コード保存の確認.json")
    need(not any((TRIAL / n).exists() for n in names), "正式code保存は新規")
    items = collect_codes(p, c, plan_path.parent)
    plan_restore = restore(plan_path)
    items[str(plan_path)] = {"original_path": plan_path.as_posix(), "SHA256": plan_sha, "bytes": plan_path.stat().st_size,
                             "restore": plan_restore, "roles": ["Root成功後封印保存計画"]}
    candidate.mkdir(parents=True)
    items, old, new_count = archive_codes(items, p["old_archives"], plan_path.parent, candidate / names[0])
    need(sum("金融市場前固定1281" in x["roles"] for x in items.values()) == 1281, "固定1281所在欠落")
    need(all(sha(Path(x["original_path"])) == x["SHA256"] for x in items.values()), "コード/停止/条件前後差")
    need(all(sha(Path(x["absolute_path"])) == x["sha256"] for x in old), "旧archive前後差")
    zip_ref = {"path": names[0], "sha256": sha(candidate / names[0]), "bytes": (candidate / names[0]).stat().st_size}
    index = {"成功": True, "試行": 106, "計画SHA256": plan_sha, "金融条件": {"path": "金融条件.json", "sha256": CONDITION_SHA}, "金融条件SHA256": CONDITION_SHA, "固定code数": 1281,
             "全所在数": len(items), "新ZIP": zip_ref, "新entry数": new_count, "既存archive": old,
             "roots": {"repoRoot": str(ROOT), "neighborRoot": str(ROOT.parent), "moduleCacheRoot": str(MODCACHE), "goRoot": str(GOROOT)},
             "entries": list(items.values()), "Go環境": {"version": "go1.24.2", "本文非同梱": True, "説明": "GoRoot717件は取得版/元path/サイズ/実SHAで再現。標準ライブラリやtoolsを独自コードと重複複製しない"},
             "復元": "全entryをrestore.rootへrelativeで戻す。旧archive同SHA entryは同じ原位置へ復元。外部Go環境とNode依存は元版を用意する。移植や再build成功を主張しない",
             "除外": ["Raw/CSV", "価格Tape", "sidecar header/records本文", "金融Native", "Source result/全記録", "巨大人工全帳簿", "exe/Go tools本文", "node_modules/venv", "xlsx/画像/大log"],
             "未同梱人工": "testコードにある元fixture参照は元停止の指紋を維持し、全人工本文の同梱/コードZIPだけで全人工が直ちに動くとは主張しない"}
    write(candidate / names[1], index)
    proof = {"成功": True, "試行": 106, "計画SHA256": plan_sha, "固定1281所在欠落": 0, "全所在SHA前後不変": True,
             "新entry読戻しSHA一致": new_count, "新CRC差": 0, "危険path": 0, "旧archive不変": True,
             "codeZIP": zip_ref, "索引SHA256": sha(candidate / names[1]), "Raw/市場/Source/金融/Viewer/xlsx実行": 0}
    write(candidate / names[2], proof)
    for name in names:
        os.rename(candidate / name, TRIAL / name)
    return {"成功": True, "固定code数": 1281, "全所在数": len(items), "新ZIPentry": new_count, "ZIP_SHA256": zip_ref["sha256"]}


def main():
    """
    機能: metadata見積又はRoot許可後の正式保存を選ぶ。
    引数: action(str)、--plan/--plan-sha/--outは計画/明示指紋/新規候補先。
    返り値: None。未固定計画は正式保存を拒否する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("estimate", "data", "code"))
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--plan-sha", required=True)
    parser.add_argument("--out", type=Path, required=True)
    a = parser.parse_args()
    result = {"estimate": estimate, "data": publish_data, "code": publish_code}[a.action](a.plan.resolve(), a.plan_sha, a.out.resolve())
    print(json.dumps({k: v for k, v in result.items() if k in ("成功", "先頭2bytes計", "単純70場外挿bytes", "宣言SHA別群数", "宣言SHA別非圧縮bytes計", "codeRoot件数", "Native数", "経済会計", "Sourcecase", "Source共用gzip数", "固定code数", "全所在数", "新ZIPentry", "ZIP_SHA256")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
