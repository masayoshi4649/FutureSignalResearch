# 106 Native・追加Source結果・再現コードの正式保存準備

現段階は**workだけの準備**。全70金融の部分結果本文は読まない。容量見積は固定条件/完了/Corpus/標準台帳のmetadata、全12Source結果のファイルstat、Root許可済み金融先頭2Nativeのstatだけを使う。原板/CSV/価格Tape/Source全記録/public巨大recordsは開かず、複製しない。

## 保存単位

1. 新Native70 gzipは元20Bookの全fieldを削らず、その圧縮bytesを同体で`成果物_金融/Native`へ保存する。trialdir基準の`Native参照台帳.json`へ元SHA/size/公開sidecar参照を記録する。W0旧58の旧Nativeは追加コピーせず、104sym54/105sym4の元参照を共用する。追加12を旧市場goldenと呼ばない。
2. 追加Source12×3modeの**結果JSON36件**を全て登録する。実保存時に各現物SHAを照合し、同じcontent SHAだけを一つのmtime=0 gzipへ共用する。原JSON SHA＝解凍SHAを検査する。`成果物_Source/Result`と`Source結果参照台帳.json`へ、旧93golden対象外・records workRefを明記する。Source連続会計と可変保護20冊を混ぜない。
3. 固定1281codeの全元位置/SHA/sizeを所在索引へ残す。GoRoot717件は`go1.24.2`の元path/全SHAによる環境再構成参照であり、stdlibとtool exe本文は非同梱。残564件と追加保存/report/xlsx/Root小helperは、旧105/104/103コードZIPの同SHA entryを優先して共用し、不足分だけ`再現コード_不足分.zip`へ入れる。新ZIPの全entry SHA/CRCを読戻し照合する。

旧ZIP/原計画/条件/停止は変更しない。ZIP名は`repoRoot/…`、`neighborRoot/…`、`moduleCacheRoot/…`の安全prefixを使い、絶対path・drive・`../`をentryへ流さない。元論理位置と展開先は索引のrestoreへ分離する。Go/Node等の外部実行環境と巨大人工fixture本文は非同梱であり、コードZIPだけで全人工が直ちに動くとは主張しない。

## 現在の見積と未固定計画

`準備する.py`が`計画_未固定.json`、`容量のmetadata見積.json`、work候補ZIP/`コード所在候補.json`を作る。金融全70FileRefはnull、fixed=false、Root追加helper最終確定=falseのまま。正式書込へ使えない。

金融先頭2 gzipは254,451bytes、単純70場外挿は8,905,785bytes。2場/3玉程度という小標本のサイズ比なので、容量保証や成績の予測ではない。Source結果の圧縮後サイズは本文を開いていないので未測定。見積には宣言SHA別群数と非圧縮statの計だけを記録する。

## Root成功通知後の再現手順

元の未固定計画は保存したまま、Rootが別ファイルへコピーして次を封印する。

- `financial_full70`へ成功完了の完全FileRefを指定。`financial_first2`は固定済み先頭2成功を保持する。
- `fixed=true`、`root_authorized_after_success=true`。`trial_dir`は正式106だけ。FileRefは封印計画parent基準又は絶対path。
- code保存前にRoot追加の最後の小helper/固定JSON/停止を`extra_files`又は`postprocess_stops`へ完全SHAで追加する。本準備の`停止.json`もpostprocess_stopsへ追加する。
- 未受領のコード/停止を推定しない。最終集合が確定した時だけ`pending=[]`、`root_extra_code_final=true`。

封印計画のSHAを取得し、Rootが以下を実行する。準備担当はまだ実行しない。

```powershell
work/venvs/technical-tree/Scripts/python.exe -B -X utf8 `
  work/106正式保存の準備/保存する.py data `
  --plan <Root封印計画.json> --plan-sha <SHA256> `
  --out work/106正式保存の準備/実行/データ候補

work/venvs/technical-tree/Scripts/python.exe -B -X utf8 `
  work/106正式保存の準備/保存する.py code `
  --plan <同封印計画.json> --plan-sha <SHA256> `
  --out work/106正式保存の準備/実行/コード候補
```

両候補先は新規だけ。`data`は全70成功/1400冊/同条件/前後不変/旧58と追加12/first2の先頭bytesをmetadataで先検査してから、初めて完成結果bytesを読む。内容JSONを解析せず成績による保存選別をしない。候補側でSHAと復元を全て検査してから、正式先へ排他的に公開し、成功確認を最後に保存する。途中I/O失敗があれば成功確認を作らず停止する。既存正式保存の上書きはしない。

`code`は同じ全70成功metadataとRootの追加code最終確定を要求する。正式追加はZIP、所在索引、確認JSONだけ。README/設定/目次/完了記録や金融・Source・入力は変更しない。新たな移植/再build/Viewer/xlsx/金融の実行もしない。

## 人工と限界

`人工検査.py`は経済値を含まない手製bytesで、Native gzip同体、Source全caseと同SHAのみ共用、解凍SHA、旧ZIP entry共用/不足だけ新ZIP/全entry読戻し、危険path・偽SHA・既存先・金融未完/集合/対照区分の拒否を検査する。金融式や自然Sourceの再現人工ではない。

現在のwork候補ZIPは事後追加helperが揃う前の候補。後の封印計画を固定して再生成する正式archiveとは区別する。正式保存・全70Native本文・Source結果本文の読取は未実施。
