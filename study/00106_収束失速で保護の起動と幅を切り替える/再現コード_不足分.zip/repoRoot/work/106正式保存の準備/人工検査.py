"""106正式保存器のbytes/重複排除/path/未成功拒否だけを人工で確認する。"""

import gzip
import importlib.util
import json
from pathlib import Path
import zipfile


OWN = Path(__file__).resolve().parent
S = importlib.util.spec_from_file_location("106保存bytes人工", OWN / "保存する.py")
M = importlib.util.module_from_spec(S); S.loader.exec_module(M)


def fail(callback):
    """
    機能: 保存破損を拒否したことを記録する。
    引数: callback(callable)は一つの破損呼出し。
    返り値: strは拒否理由。通過は人工失敗。
    """
    try:
        callback()
    except (ValueError, KeyError, FileExistsError, gzip.BadGzipFile, EOFError) as e:
        return str(e)
    raise ValueError("破損を受理")


def ref(p):
    """
    機能: 手製bytesだけを人工参照へ写す。
    引数: p(Path)は人工ファイル。
    返り値: dictはpath/SHA。
    """
    return {"path": str(p), "sha256": M.sha(p)}


def main():
    """
    機能: bytes保存の最小人工をworkでのみ実行する。
    引数: なし。
    返り値: None。実Native/Source結果の内容を使わない。
    """
    out = OWN / "人工"
    M.need(not out.exists(), "人工は新規")
    out.mkdir()
    # 本文は取引/Sourceに見立てず、gzipとbytes同体だけの器具とする。
    a, b = out / "手製A.json", out / "手製B.json"
    a.write_text('{"型人工":"経済値を含まないA"}\n', encoding="utf-8")
    b.write_text('{"型人工":"経済値を含まないB"}\n', encoding="utf-8")
    records = out / "未使用records参照.jsonl.gz"; records.write_bytes("本文は開かない参照".encode("utf-8"))
    cases = [{"session": "手製", "mode": m, "result": ref(p), "records": ref(records)} for m, p in (("legacy", a), ("default", a), ("symmetric", b))]
    rows, groups, before = M.compress_source(cases, out, out / "Source保存")
    M.need(len(rows) == 3 and len(groups) == 2 and rows[0]["原JSON_SHA256"] == rows[1]["原JSON_SHA256"], "全case登録と同SHAのみ共用")
    native = out / "手製Native.gz"
    with native.open("xb") as dst:
        with gzip.GzipFile(filename="", mode="wb", fileobj=dst, mtime=0) as z:
            z.write(b"fakebytes-only-no-trading")
    nr = {"session": "手製", "native": ref(native), "sidecar_header": ref(a), "sidecar_records": ref(records)}
    copied, bn = M.copy_native([nr], out, out / "Native保存", M.TRIAL)
    M.need(len(copied) == 1 and copied[0]["sha256"] == M.sha(native), "Native圧縮bytes同体")
    errors = {}
    errors["偽SHA"] = fail(lambda: M.resolve({"path": str(a), "sha256": "a" * 64}, out))
    errors["空FileRef"] = fail(lambda: M.resolve({"path": "", "sha256": "a" * 64}, out))
    errors["既存Native先"] = fail(lambda: M.copy_native([nr], out, out / "Native保存", M.TRIAL))
    for path in ("../bad.py", "/bad.py", "C:/bad.py", "repoRoot\\bad.py"):
        M.need(not M.safe(path), "危険path拒否")
    ids = [f"手製{i:02d}" for i in range(70)]
    fin = {"version": 1, "trial": 106, "stage": "full70", "success": True, "condition_sha256": M.CONDITION_SHA, "sessions": 70, "books_per_scene": 20, "books": 1400,
           "results": [{"session": s, "books": 20, "w0_control_books": 4, "control_kind": "same_input_old103" if 54 <= i < 66 else "provided_old_book"} for i, s in enumerate(ids)],
           "unchanged": True, "before": {"手製": "a" * 64}, "after": {"手製": "a" * 64}, "source_reexecuted": False, "financial_executed": True}
    M.validate_finance(fin, ids)
    for name, edit in (("金融途中", lambda v: v.update(success=False)), ("場欠落", lambda v: v["results"].pop()), ("二重場", lambda v: v["results"][1].update(session=ids[0])), ("経済会計欠落", lambda v: v.update(books=1399)), ("新12へgolden", lambda v: v["results"][54].update(control_kind="provided_old_book"))):
        v = json.loads(json.dumps(fin)); edit(v); errors[name] = fail(lambda: M.validate_finance(v, ids))
    code_a, code_b = out / "同体.py", out / "不足.py"
    code_a.write_text('"""日本語の手製コードA。"""\n', encoding="utf-8")
    code_b.write_text('"""日本語の手製コードB。"""\n', encoding="utf-8")
    old = out / "旧コード.zip"
    with zipfile.ZipFile(old, "x") as z:
        z.write(code_a, "repoRoot/古い位置.py")
    items = {str(p): {"original_path": str(p), "SHA256": M.sha(p), "bytes": p.stat().st_size, "restore": {"root": "repoRoot", "relative": p.name}, "roles": ["手製"]} for p in (code_a, code_b)}
    items, _, n = M.archive_codes(items, [ref(old)], out, out / "新コード.zip")
    M.need(n == 1 and items[str(code_a)]["location"]["kind"] == "既存archive" and items[str(code_b)]["location"]["kind"] == "新archive", "旧SHA共用/不足だけ新ZIP")
    # gzip破損は復元SHA検査以前に検出する。
    bad = out / "破損.gz"; bad.write_bytes(b"bad-gzip")
    def read_bad():
        """
        機能: 手製破損gzipの復元を試みる。
        引数: なし。
        返り値: bytes。不正なので例外を期待する。
        """
        with gzip.open(bad, "rb") as stream:
            return stream.read()
    errors["gzip破損"] = fail(read_bad)
    M.need(all(M.sha(Path(k)) == h for k, h in {**before, **bn}.items()), "手製元前後不変")
    M.write(out / "人工確認.json", {"成功": True, "scope": "経済値を含まないbytes/metadata器具だけ", "Native同bytes": 1, "Source全case": 3, "Source共用gzip": 2,
            "旧ZIP同体参照": 1, "新entry読戻しSHA": 1, "CRC差": 0, "危険path拒否": 4, "拒否": errors,
            "実市場/Raw/CSV/Native/Source本文読取": 0, "正式保存": False})
    print(json.dumps({"成功": True, "拒否": len(errors), "危険path拒否": 4}, ensure_ascii=False))


if __name__ == "__main__":
    main()
