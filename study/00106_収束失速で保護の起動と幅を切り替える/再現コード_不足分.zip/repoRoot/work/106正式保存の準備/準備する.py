"""既存metadataとコードだけから106正式保存の未固定計画を作る。"""

import argparse
import importlib.util
import json
from pathlib import Path


OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[1]
S = importlib.util.spec_from_file_location("106正式保存の準備対象", OWN / "保存する.py")
M = importlib.util.module_from_spec(S); S.loader.exec_module(M)


def ref(path):
    """
    機能: 固定済みsmall code/metadataのFileRefを明示する。
    引数: path(Path)は既知のコード又はmetadata。
    返り値: dictは絶対path/SHA。市場価格本文を対象にしない。
    """
    return {"path": str(path.resolve()), "sha256": M.sha(path)}


def main():
    """
    機能: 未固定計画/metadata容量見積/コード所在候補をworkだけへ作る。
    引数: --out(Path)は新規work候補dir。省略時は本dir。
    返り値: None。正式保存/全70Native読取/Source結果本文読取はしない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=OWN)
    args = parser.parse_args()
    out = args.out.resolve()
    M.need(out.is_relative_to(OWN), "work候補は本準備dir内")
    out.mkdir(parents=True, exist_ok=True)
    target = out / "計画_未固定.json"
    M.need(not target.exists(), "未固定計画は新規")
    trial = M.TRIAL
    stopped = {
        "work/106可変保護の保存準備/停止.json": "3dd87ba97322a30c820d5b958f27d5846c4bce206e748ce0a88a962c881c9953",
        "work/106報告の準備/停止.json": "d1c8000effaa496405c0fe2ae574659943f8340271b06cad928b38a0f763692a",
        "work/106xlsx追記の準備/停止.json": "e118b176529276e427622f571ae6fab868db78eee4f37d1a241a463b6e03b717",
        "work/106同幅の起動差の比較/停止.json": "ade7c9ff2845dcc9cb817378ad85a3ac32508569ac4e1ee1fc6a6e3376065850"}
    for name, h in stopped.items():
        M.need(M.sha(ROOT / name) == h, "追加停止SHA差")
    old_dirs = [ROOT / "study/00105_固定SourceとLD10の四場追加確認", ROOT / "study/00104_重複時の方向裁定と元Sourceの再形成", ROOT / "study/00103_元の多玉と数量を保つ一定利益後の追尾"]
    names = [["再現コード_不足分.zip"], ["Source再現コード.zip", "主B追加コード.zip", "先頭2結合検査コード.zip", "保存と照合コード.zip"], ["再現コード.zip", "保存と照合のコード.zip"]]
    archives = [ref(folder / name) for folder, files in zip(old_dirs, names) for name in files]
    extras = list((ROOT / "work/106進行").glob("*.py")) + list((ROOT / "work/106進行").glob("*Go依存.json"))
    extras += list(OWN.glob("*.py")) + [OWN / "README.md"]
    # 所有コードは原計画live文書を入れず、既に固定されたSnapshotだけを市場条件から継承する。
    plan = {"version": 1, "trial": 106, "fixed": False, "root_authorized_after_success": False,
            "trial_dir": str(trial), "condition": ref(trial / "金融条件.json"),
            "source_completion": ref(ROOT / "work/106Source市場/全12場/完了.json"),
            "financial_first2": ref(ROOT / "work/106市場/先頭2場/完了.json"), "financial_full70": None,
            "postprocess_stops": [ref(ROOT / name) for name in stopped], "old_archives": archives,
            "extra_files": [ref(p) for p in sorted(set(extras))],
            "root_extra_code_final": False,
            "pending": ["金融full70成功FileRefをRootが指定", "Root追加helper最終集合を指定", "本準備の停止.jsonをpostprocess_stopsへ追加"],
            "禁止": ["準備中の全70部分Native本文読取", "Raw/CSV/価格Tape/巨大recordsの複製", "市場/Source/金融再実行", "正式文書/条件/旧ZIP変更"]}
    M.write(target, plan)
    M.estimate(target, M.sha(target), out / "容量のmetadata見積.json")
    p, c, _ = M.read_plan(target, M.sha(target))
    items = M.collect_codes(p, c, out)
    # 正式先ではなくwork候補でだけ旧ZIP同SHAと不足entryを検査する。
    archive = out / "候補コード_未公開.zip"
    items, old_refs, entries = M.archive_codes(items, p["old_archives"], out, archive)
    fixed = [x for x in items.values() if "金融市場前固定1281" in x["roles"]]
    M.need(len(fixed) == 1281 and sum(x["restore"]["root"] == "goRoot" for x in fixed) == 717, "固定1281/GoRoot717")
    M.write(out / "コード所在候補.json", {"成功": True, "scope": "未固定work候補。Root追加helperと本準備停止の追記前", "計画SHA256": M.sha(target),
            "金融条件SHA256": M.CONDITION_SHA, "固定code数": 1281, "GoRoot環境参照": 717,
            "全所在数": len(items), "新entry数": entries, "候補ZIP_SHA256": M.sha(archive), "候補ZIPbytes": archive.stat().st_size,
            "既存archive": old_refs, "entries": list(items.values()), "全entry読戻しSHA/CRC": "差0", "正式保存": False, "市場/Raw/CSV/Native/Source結果本文読取": 0})
    rejected = {}
    for action, fn in (("data", M.publish_data), ("code", M.publish_code)):
        try:
            fn(target, M.sha(target), out / (action + "_作成禁止"))
        except ValueError as e:
            rejected[action] = str(e)
        else:
            raise ValueError("未固定の正式保存を受理")
        M.need(not (out / (action + "_作成禁止")).exists(), "未固定なのに候補を作成")
    M.write(out / "未固定実入口の確認.json", {"成功": True, "計画SHA256": M.sha(target), "拒否": rejected, "候補作成": 0, "正式編集": 0, "市場Native本文読取": 0})
    print(json.dumps({"成功": True, "計画SHA256": M.sha(target), "候補全所在": len(items), "新entry": entries, "ZIP_SHA256": M.sha(archive)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
