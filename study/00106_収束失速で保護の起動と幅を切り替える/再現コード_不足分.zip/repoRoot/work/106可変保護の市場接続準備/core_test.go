package variableguardruntime

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"testing"

	continuous "github.com/masayoshi4649/SessionTradeExecuter/continuous101"
	"github.com/masayoshi4649/SessionTradeExecuter/internal/strategy"
	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	oldtype "github.com/masayoshi4649/SessionTradeExecuter/minichart"
	old "github.com/masayoshi4649/SessionTradeExecuter/minidelayed103"
	finance "github.com/masayoshi4649/SessionTradeExecuter/miniearlyguard"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	chart "github.com/masayoshi4649/SessionTradeExecuter/publicchart"
	stream "github.com/masayoshi4649/SessionTradeExecuter/publicsidecar"
)

type NativeBatch = finance.NativeBatch
type Session = finance.Session
type Observation = finance.Observation
type QuoteStamp = finance.QuoteStamp

// requestFixture は手製価格/CSV型と二市場同秒・Last0・不良BBOを明示します。
//
// 引数: side(int)は鏡像方向。返り値: Requestは市場入力でない短いDay場です。
func requestFixture(side int) continuous.Request {
	s := session()
	s.End = s.Start + 4200
	s.ForceClose = s.Start + 3600
	r := continuous.Request{Session: s, Scene: chart.Scene{ID: s.ID, Contract: "手製106限月", Start: s.Start}, Rows: []continuous.Row{}, Candles: []continuous.CandleEvent{}, Grids: []float64{}}
	for g := s.Start; g < s.End; g += 300 {
		r.Grids = append(r.Grids, g)
	}
	times := []float64{}
	for i := 0; i < 70; i++ {
		times = append(times, s.Start+float64(i*60))
	}
	g := s.Start + 1800
	for _, x := range []float64{1, 2, 3, 4, 5, 6, 7, 8, 9, 601, 3601 - 1800} {
		times = append(times, g+x)
	}
	sort.Float64s(times)
	line := int64(0)
	for _, at := range times {
		move := 0.0
		if at >= g+3 && at <= g+4 {
			move = 35
		}
		if at == g+5 {
			move = 70
		}
		if at == g+6 {
			move = 120
		}
		if at == g+7 {
			move = 60
		}
		if at >= g+600 {
			move = 30
		}
		o := observation(at, move, side, 0, false)
		if at == g+8 {
			o.Bid, o.Ask = 0, 0
		}
		if at == s.Start+600 {
			line++
			r.Rows = append(r.Rows, continuous.Row{Board: strategy.Board{Reference: "NK225", Time: at, Received: at, Last: 0, Bid: o.Bid, Ask: o.Ask}, PhysicalLine: line})
		}
		line++
		r.Rows = append(r.Rows, continuous.Row{Board: strategy.Board{Reference: "NK225", Time: at, Received: at, Last: o.Last, Bid: o.Bid, Ask: o.Ask, BidQuantity: 20, AskQuantity: 20}, PhysicalLine: line})
		r.Rows = append(r.Rows, continuous.Row{Board: strategy.Board{Reference: "TOPIX", Time: at, Received: at, Last: 2500, Bid: 2499.5, Ask: 2500.5}, PhysicalLine: int64(len(r.Rows) + 1)})
	}
	for _, ref := range []string{"NK225", "TOPIX"} {
		for i := 0; i < 8; i++ {
			start := s.Start + float64(i*300)
			base := 1000.0
			if ref == "TOPIX" {
				base = 2500
			}
			r.Candles = append(r.Candles, continuous.CandleEvent{Reference: ref, Interval: 300, At: start + 360, Candle: strategy.Candle{Time: start, Open: base, High: base + 20, Low: base - 20, Close: base, Closed: true}})
		}
	}
	return r
}

// sourceTapeFixture は停止producerのScalar/gridを使い手製Source通知だけを組みます。
//
// 引数: t(*testing.T)、req(Request)、side(int)は試験器と手製入力。
// 返り値: TapeはForce→grid→rawの合法列。Sourceアルゴリズムを実行しません。
func sourceTapeFixture(t *testing.T, req continuous.Request, side int, empty ...bool) tape.Tape {
	t.Helper()
	events := []tape.TapeEvent{}
	_, _, e := continuous.BuildToSink(req, nil, func(r continuous.Record) error {
		if r.Kind == "row" {
			q := r.Row.Scalar
			events = append(events, tape.TapeEvent{Kind: "quote", At: q.Time, Quote: &q})
		}
		if r.Kind == "control" && r.Control.Kind == "grid" {
			events = append(events, tape.TapeEvent{Kind: "grid", At: r.Control.At})
		}
		return nil
	})
	if e != nil {
		t.Fatal(e)
	}
	events = append(events, tape.TapeEvent{Kind: "force", At: req.Session.ForceClose})
	rank := map[string]int{"force": 0, "grid": 1, "quote": 2}
	sort.SliceStable(events, func(i, j int) bool {
		return events[i].At < events[j].At || events[i].At == events[j].At && rank[events[i].Kind] < rank[events[j].Kind]
	})
	src := newSource()
	g := req.Session.Start + 1800
	for i := range events {
		ev := &events[i]
		ev.Ordinal = i + 1
		if ev.Kind == "grid" {
			continue
		}
		var b NativeBatch
		if ev.Kind == "force" {
			b = src.force(ev.At)
			b.Delta.SourceLine = src.last.SourceLine
		} else {
			news := []native.Signal{}
			if ev.At == g-120 && !(len(empty) > 0 && empty[0]) {
				news = append(news, birth("初回", side, 6))
			}
			if ev.At == g+300 && !(len(empty) > 0 && empty[0]) {
				news = append(news, closeSignal("部分", "玉-初回", side, 3))
			}
			if ev.At == g+600 && !(len(empty) > 0 && empty[0]) {
				news = append(news, birth("追加", side, 4))
			}
			q := ev.Quote
			b = src.step(native.QuoteStamp{Time: q.Time, Index: q.Index, SourceLine: q.SourceLine, Last: q.Last, Bid: q.Bid, Ask: q.Ask, QuoteOK: q.QuoteOK}, news)
		}
		ev.Methods = []string{b.Method}
		ev.NonEmpty = []oldtype.NativeBatch{}
		if len(b.Delta.Signals)+len(b.Delta.Fills)+len(b.Delta.Cancellations)+len(b.Delta.Closes) > 0 {
			ev.NonEmpty = append(ev.NonEmpty, oldtype.NativeBatch{Method: b.Method, Delta: b.Delta})
		}
	}
	return tape.Tape{Version: 1, Scope: "手製Source公開通知。自然Source/市場入力ではない", Session: req.Session, Capabilities: tape.Capabilities(), Events: events}
}

// warmFixture は同限月の数値だけを助走する手製前場を作ります。
//
// 引数: main(Request)は手製本場。返り値: RequestはSource/金融なしの120足助走です。
func warmFixture(main continuous.Request) continuous.Request {
	start := main.Session.Start - 22000
	s := main.Session
	s.ID = "手製助走"
	s.Start = start
	s.End = start + 21600
	s.ForceClose = s.End - 600
	r := continuous.Request{Session: s, Scene: chart.Scene{ID: s.ID, Contract: main.Scene.Contract, Start: start}}
	for i := 0; i < 120; i++ {
		at := start + float64(i*180) + 1
		price := 1000 + float64(i)*.1
		r.Rows = append(r.Rows, continuous.Row{Board: strategy.Board{Reference: "NK225", Time: at, Received: at, Last: price, Bid: price - 5, Ask: price + 5}, PhysicalLine: int64(i + 1)})
	}
	return r
}

// streamFixture は停止dd34を直接使って小さな公開列を生成します。
//
// 引数: t(*testing.T)、req(Request)、input(Tape)、warm(bool)は手製値。
// 返り値: Header/[]Recordは旧Snapshot全値一致を含む非市場列です。
func streamFixture(t *testing.T, req continuous.Request, input tape.Tape, warm bool) (stream.Header, []stream.Record) {
	t.Helper()
	var seed *stream.Seed
	var e error
	if warm {
		seed, e = stream.Warm(warmFixture(req), nil)
		if e != nil {
			t.Fatal(e)
		}
	}
	rows := []stream.Record{}
	h, _, e := stream.Build(req, seed, SourceForces(input), func(r stream.Record) error { rows = append(rows, r); return nil })
	if e != nil {
		t.Fatal(e)
	}
	return h, rows
}

// TestTwentyBooks は買売/冷開始/助走を同入力旧103へ全時点対照します。
//
// 引数: t(*testing.T)、環境RUNTIME106_EXPORT(string)は試験器と明示人工先。
// 返り値: ありません。既存58市場goldenや新Source成績の成功へ広げません。
func TestTwentyBooks(t *testing.T) {
	for _, side := range []int{1, -1} {
		for _, warm := range []bool{false, true} {
			req := requestFixture(side)
			input := sourceTapeFixture(t, req, side)
			h, records := streamFixture(t, req, input, warm)
			core, e := NewCore(input, req.Scene.Contract, "手製二市場/Source通知。20金融の非市場接続", Control{Kind: "same_input_old103", HistoryClass: "artificial", AllPoints: true})
			if e != nil {
				t.Fatal(e)
			}
			r, e := Run(core, records, h)
			if e != nil {
				t.Fatal(side, warm, e)
			}
			if !r.Complete || len(r.Books) != 20 || !r.W0Control.All || r.W0Control.Books != 4 || r.W0Control.AllPointComparisons != 4*len(input.Events) || r.Counts.Resets != 1 {
				t.Fatal("完全20/旧4/Last0", r.W0Control)
			}
			if r.PublicDiagnostics.New3 != h.ThreePublications || r.PublicDiagnostics.NumericSeedCarried != warm {
				t.Fatal("公表単位/助走診断")
			}
			for _, b := range r.Books {
				if !b.Complete || b.Totals.EntryQuantity == 0 || b.Totals.OpenBuy+b.Totals.OpenSell+b.Totals.PendingBuy+b.Totals.PendingSell != 0 {
					t.Fatal("非0完結")
				}
				for _, order := range b.Orders {
					if p := order.ProtectionPoint; p != nil && order.Quantity > p.Quantity-p.Reserved {
						t.Fatal("Source予約へ重複保護")
					}
				}
			}
			t.Logf("side%d warm%t 20冊・旧103全時点%d・最終4", side, warm, r.W0Control.AllPointComparisons)
			if dir := os.Getenv("RUNTIME106_EXPORT"); dir != "" {
				var warmRequest *continuous.Request
				if warm {
					v := warmFixture(req)
					warmRequest = &v
				}
				b, _ := json.MarshalIndent(map[string]any{"scope": r.Scope, "request": req, "warmup_request": warmRequest, "tape": input, "header": h, "records": records, "output": r}, "", "  ")
				if e = os.WriteFile(filepath.Join(dir, fmt.Sprintf("方向%d_助走%t.json", side, warm)), b, 0600); e != nil {
					t.Fatal(e)
				}
			}
		}
	}
}

// copied は手製公開型を変更前の値と共有しないようcopyします。
//
// 引数: v(T)は手製型。返り値: Tは独立値です。市場本文は使いません。
func copied[T any](v T) T {
	b, e := json.Marshal(v)
	if e != nil {
		panic(e)
	}
	var out T
	if e = json.Unmarshal(b, &out); e != nil {
		panic(e)
	}
	return out
}

// TestProvidedControlScope は提供旧最終と同入力新対照を別classへ記録します。
//
// 引数: t(*testing.T)は人工の対照集合試験器。
// 返り値: ありません。提供した手製最終を既存58市場goldenとは呼びません。
func TestProvidedControlScope(t *testing.T) {
	req := requestFixture(1)
	input := sourceTapeFixture(t, req, 1)
	h, rows := streamFixture(t, req, input, false)
	first, e := NewCore(input, req.Scene.Contract, "手製対照", Control{Kind: "same_input_old103", HistoryClass: "artificial"})
	if e != nil {
		t.Fatal(e)
	}
	result, e := Run(first, rows, h)
	if e != nil {
		t.Fatal(e)
	}
	expected := map[string]old.ActualResult{}
	for _, c := range Configurations() {
		if c.Policy == "W0" {
			r := result.Books[Key(c)]
			b, _ := json.Marshal(r)
			var o old.ActualResult
			if e = json.Unmarshal(b, &o); e != nil {
				t.Fatal(e)
			}
			expected[o.Key] = o
		}
	}
	control := Control{Kind: "provided_old_book", HistoryClass: "artificial", ReferencePath: "明示手製の提供最終", ReferenceSHA: "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", Expected: expected}
	core, e := NewCore(input, req.Scene.Contract, "手製提供対照", control)
	if e != nil {
		t.Fatal(e)
	}
	r, e := Run(core, rows, h)
	if e != nil {
		t.Fatal(e)
	}
	if !r.W0Control.All || r.W0Control.Kind != "provided_old_book" || r.W0Control.HistoryClass != "artificial" || r.W0Control.AllPointComparisons != 0 || len(core.controls) != 0 {
		t.Fatal("対照を混同")
	}
	control.AllPoints = true
	if _, e = NewCore(input, req.Scene.Contract, "手製", control); e == nil {
		t.Fatal("最終を全時点へ偽装")
	}
}

// TestSinkGuards はSource/pub出典の破損を採用結果へ補いません。
//
// 引数: t(*testing.T)は小型手製Streamの試験器。
// 返り値: ありません。既存停止/市場入力は編集しません。
func TestSinkGuards(t *testing.T) {
	req := requestFixture(1)
	input := sourceTapeFixture(t, req, 1)
	h, rows := streamFixture(t, req, input, false)
	for _, name := range []string{"Scalar", "FeaturesIndex", "ChartIndex", "Forceordinal", "reset欠落", "reset全値差", "CMP", "未来source", "同秒gridraw", "同秒Forcepub", "Header", "Tape余剰"} {
		t.Run(name, func(t *testing.T) {
			streamRows := copied(rows)
			header := copied(h)
			tp := copied(input)
			find := func(kind string) int {
				for i, r := range streamRows {
					if r.Kind == kind {
						return i
					}
				}
				t.Fatal("人工種別不足", kind)
				return 0
			}
			switch name {
			case "Scalar":
				i := find("quote")
				streamRows[i].Scalar.Bid++
			case "FeaturesIndex":
				i := find("quote")
				*streamRows[i].Trigger.FeaturesIndex++
			case "ChartIndex":
				i := find("quote")
				streamRows[i].RawQuote.Index++
			case "Forceordinal":
				i := find("force")
				streamRows[i].Force.TapeOrdinal++
			case "reset欠落":
				i := find("reset")
				streamRows = append(streamRows[:i], streamRows[i+1:]...)
				for j := range streamRows {
					streamRows[j].Ordinal = j + 1
				}
				header.Records--
				header.Resets--
			case "reset全値差":
				i := find("reset")
				streamRows[i].Reset.Source.Last = -1
			case "CMP":
				i := find("publication")
				streamRows[i].Delivery.Buy.FrameSHA = "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb"
			case "未来source":
				i := find("publication")
				streamRows[i].Publication.Snapshot.Legacy.Three.LastSource.Time = streamRows[i].At
			case "同秒gridraw":
				a, b := -1, -1
				for i, r := range streamRows {
					if r.Kind == "grid" {
						for j := i + 1; j < len(streamRows) && streamRows[j].At == r.At; j++ {
							if streamRows[j].Kind == "quote" {
								a, b = i, j
								break
							}
						}
					}
					if a >= 0 {
						break
					}
				}
				if a < 0 {
					t.Fatal("同秒器具不足")
				}
				streamRows[a], streamRows[b] = streamRows[b], streamRows[a]
				for i := range streamRows {
					streamRows[i].Ordinal = i + 1
				}
			case "同秒Forcepub":
				f := find("force")
				p := -1
				for i, r := range streamRows {
					if r.Kind == "publication" && r.At == streamRows[f].At {
						p = i
						break
					}
				}
				if p < 0 {
					t.Fatal("同秒pub器具不足")
				}
				streamRows[p], streamRows[f] = streamRows[f], streamRows[p]
				for i := range streamRows {
					streamRows[i].Ordinal = i + 1
				}
			case "Header":
				header.PositiveNK++
			case "Tape余剰":
				extra := tp.Events[len(tp.Events)-1]
				extra.Ordinal = len(tp.Events) + 1
				extra.At += 1
				tp.Events = append(tp.Events, extra)
			}
			core, e := NewCore(tp, req.Scene.Contract, "手製破損", Control{Kind: "same_input_old103", HistoryClass: "artificial"})
			if e == nil {
				_, e = Run(core, streamRows, header)
			}
			if e == nil {
				t.Fatal("出典破損を受理")
			}
		})
	}
}

// TestEOFUnknown は未観測gridを足さずEOF Forceだけを旧Actorへ配送します。
//
// 引数: t(*testing.T)は空SourceだけのEOF型試験器。
// 返り値: ありません。観測外を保有/新規へ補完せずSkippedへ残します。
func TestEOFUnknown(t *testing.T) {
	req := requestFixture(1)
	rows := []continuous.Row{}
	for _, r := range req.Rows {
		if r.Board.Time < req.Session.Start+2400 {
			rows = append(rows, r)
		}
	}
	req.Rows = rows
	input := sourceTapeFixture(t, req, 1, true)
	h, records := streamFixture(t, req, input, false)
	core, e := NewCore(input, req.Scene.Contract, "手製EOF・空Source", Control{Kind: "same_input_old103", HistoryClass: "artificial", AllPoints: true})
	if e != nil {
		t.Fatal(e)
	}
	result, e := Run(core, records, h)
	if e != nil {
		t.Fatal(e)
	}
	if h.AfterEOFForces != 1 || len(result.SkippedGrids) == 0 || result.Counts.Grids >= len(req.Grids) {
		t.Fatal("EOF後の枠補完")
	}
	for _, b := range result.Books {
		if len(b.Positions) != 0 || b.Totals.EntryQuantity != 0 || !b.Complete {
			t.Fatal("EOF空を金融へ補完")
		}
	}
}
