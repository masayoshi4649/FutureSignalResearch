"""20会計Sinkの非市場対照・出典破損・停止依存を記録する。"""
from pathlib import Path
import hashlib
import json
import os
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def sha(path):
    """
    機能: 明示コード/停止metadata/人工のSHA256を求める。
    引数: path(Path)は市場本文でない参照。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def label(path):
    """
    機能: repo内を相対、外を絶対pathにする。
    引数: path(Path)は参照。
    返り値: strは再読可能な名前。
    """
    try:
        return path.relative_to(ROOT).as_posix()
    except ValueError:
        return str(path)


def save(path, value):
    """
    機能: 新規証拠だけを保存する。
    引数: path(Path)、value(dict)は新規先と公開値。
    返り値: None。
    """
    with path.open("x", encoding="utf-8", newline="\n") as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write("\n")


def run(args, **extra):
    """
    機能: 明示したGoの非市場人工だけを実行する。
    引数: args(list[str])、extra(dict)はコマンドと環境。
    返り値: CompletedProcessは成功した出力。失敗時は例外。
    """
    r = subprocess.run(args, cwd=HERE, capture_output=True, encoding="utf-8", **extra)
    if r.returncode:
        raise RuntimeError({"command": args, "exit": r.returncode, "stdout": r.stdout, "stderr": r.stderr})
    return r


def main():
    """
    機能: 指定Sinkの最終人工/依存不変を固定し新停止を保存する。
    引数: なし。
    返り値: None。市場I/O/Sourceアルゴリズムは実行しない。
    """
    assert not (HERE / "停止.json").exists()
    check, final = HERE / "検査", HERE / "人工_停止版"
    check.mkdir(exist_ok=True)
    final.mkdir()
    stops = {
        "work/収束失速で保護を早める会計案/停止.json": "68011a9c44cbf88f765216493d331849cb80efd95cfdf63d750bbfafe53e02c5",
        "work/収束可変幅の公開配送案/停止.json": "8c426b5791df0c3d327d0224ecfe48baac7c319a6d1fb776672cecdf79733015",
        "work/可変追尾の実場公開配送_助走対応/停止.json": "dd34a46724e7e604544fd60f66e97c0b914cb7593df828ab037a55378cc7244f",
        "work/103多玉の保護会計/停止.json": "e051a2401c8919835adfea52bf346d644707239fd030f0b13f101586b4c1d52b",
        "work/105四場の時計とLD10確認/停止.json": "0a41056d1a9d0c14d13e0bf23d3f78fe7ce1ffb42b13dd2dfb898d8f81802299",
    }
    before = {}
    for name, h in stops.items():
        p = ROOT / name
        assert sha(p) == h
        before[name] = h
        d = json.loads(p.read_text(encoding="utf-8-sig"))
        owned = d.get("所有コードSHA256", d.get("所有SHA256", {}))
        assert owned
        for path, expected in owned.items():
            assert sha(ROOT / path) == expected, path
            before[path] = expected
    dirs = run(["go", "list", "-deps", "-f", "{{if not .Standard}}{{.Dir}}{{end}}", "./..."]).stdout.splitlines()
    for directory in dirs:
        d = Path(directory)
        if d == HERE:
            continue
        for p in sorted(d.glob("*.go")):
            before[label(p)] = sha(p)
        for name in ["go.mod", "go.sum"]:
            p = d / name
            if p.is_file():
                before[label(p)] = sha(p)
    save(HERE / "元と依存の前指紋.json", before)
    # 手製Source helperは停止版のpackage変更だけ。
    src = ROOT / "work/収束失速で保護を早める会計案/source_fixture_test.go"
    assert (HERE / "source_fixture_test.go").read_text(encoding="utf-8-sig") == src.read_text(encoding="utf-8-sig").replace("package miniearlyguard", "package variableguardruntime")
    env = dict(os.environ, RUNTIME106_EXPORT=str(final))
    test = run(["go", "test", "-count=1", "-json", "./..."], env=env)
    log = check / "最終Go_test.jsonl"
    log.write_text(test.stdout, encoding="utf-8", newline="\n")
    events = [json.loads(s) for s in test.stdout.splitlines() if s]
    assert any(e.get("Action") == "pass" and "Test" not in e for e in events)
    names = [e["Test"] for e in events if e.get("Action") == "pass" and "Test" in e]
    vet, build = run(["go", "vet", "./..."]), run(["go", "build", "./..."])
    files = {label(p): sha(p) for p in sorted(final.glob("*.json"))}
    assert len(files) == 4
    nonzero, points, finals = 0, 0, 0
    for p in final.glob("*.json"):
        d = json.loads(p.read_text(encoding="utf-8"))
        r = d["output"]
        assert r["complete"] and len(r["books"]) == 20 and r["w0_control"]["all"]
        for b in r["books"].values():
            assert b["complete"] and b["totals"]["entry_quantity"] > 0
            nonzero += 1
        points += r["w0_control"]["all_point_comparisons"]
        finals += r["w0_control"]["books"]
    assert (nonzero, points, finals) == (80, 1536, 16)
    after = {name: sha(Path(name) if Path(name).is_absolute() else ROOT / name) for name in before}
    assert before == after
    save(HERE / "元と依存の前後照合.json", {"成功": True, "前": before, "後": after, "前後不変": True, "範囲": "停止コード/metadataとGo依存だけ。市場価格/Source/Tape/Native本文は読まない"})
    save(HERE / "由来と接続範囲.json", {"成功": True, "元停止": stops, "金融": "68011を直接import。Source/数量/費用/LD/幅/予約/約定算術の複写0", "Source配送": "旧103/105と同じRestoreBatches→quote/Force/grid三API。新20factory/外namespaceと厳密Stream結合だけ追加", "公開評価": "8c42を再実行し保存Delivery全JSONへ照合", "producer": "dd34を直接import。Seed/SourceをCoreで生成しない", "人工Source器具": {"元path": label(src), "元SHA256": sha(src), "新path": label(HERE / "source_fixture_test.go"), "package変更だけ": True}, "W0対照": "旧保存58最終/同入力旧103新対照12/手製を明示classで分離", "peer補強": ["Last0 reset.Sourceと後続RawQuoteを全field比較", "同時計pre-raw公表→Force→grid順位を検査"], "既存停止変更": False})
    receipt = {"成功": True, "Go成功top": sum("/" not in n for n in names), "小試験込成功": len(names), "test/vet/build": {"test": 0, "vet": vet.returncode, "build": build.returncode}, "Goログ": {"path": label(log), "SHA256": sha(log)}, "20会計人工": {"場面": 4, "非0冊": nonzero, "買売": True, "cold/paired助走": True, "全残0": True}, "W0別旧103": {"全時点全JSON除外0": points, "最終": finals, "市場golden": False}, "提供旧最終mode": "手製class=artificialでだけ検査。実58参照は未実施", "破損拒否": 12, "EOF空型": "未観測grid補完0・Force時計だけ・20空冊完結", "出典再構成": "Source固定Tape全消費/Scalar11全文/FeaturesIndexとChartAllIndex別/物理行/全board/Closes-only維持/公表C-M-P全fieldSHA", "停止版人工SHA256": files, "参照数": len(before), "前後不変": True, "市場/Raw/旧Native/Source本文読取": 0, "E早期発動の独立市場例": 0}
    save(check / "人工確認.json", receipt)
    owned = {label(p): sha(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name != "停止.json"}
    stop = {"成功": True, "scope": "試行106の非市場20会計Sink/Source固定Tapeと公開Streamの厳密結合", "module": "github.com/masayoshi4649/SessionTradeExecuter/variableguardruntime", "所有コードSHA256": owned, "元停止": stops, "API": "NewCore(Tape,contract,scope,Control)->Core; Feed(publicsidecar.Record); Finish(publicsidecar.Header)->Result", "外key": [p + "_C" + str(c) + "_D" + str(d) for p in ["W0", "W1", "W2", "E1", "E2"] for c in [0, 5] for d in [0, 1]], "内Key": "W系LD10_B5Q_P0_C...、E系E1/E2_B5Q_P0_C...全JSON原値", "W0対照": {"既存58": "provided_old_book/old_saved_58、最終全JSON", "追加12": "same_input_old103/same_input_new12、別旧Actor同入力の新対照", "人工": "class artificial、全時点1536/最終16"}, "人工確認": {"path": label(check / "人工確認.json"), "SHA256": sha(check / "人工確認.json")}, "元/依存前後不変": True, "参照指紋": {"path": label(HERE / "元と依存の前後照合.json"), "SHA256": sha(HERE / "元と依存の前後照合.json")}, "test/vet/build": {"test": 0, "vet": 0, "build": 0}, "金融/Source式変更": False, "Raw/市場/旧Native/Source結果本文読取": 0, "市場金融実行": 0, "実行物": "Go libraryのみ。市場CLIは別owner", "未実施": ["市場I/O条件/ファイル実体SHA・70集合bind", "市場Source/Stream/旧58W0参照の結合", "70場の金融本番と1400会計の成績", "全原行別金融engine独立監査"], "注意": "人工80非0は手製Source/価格/CSV型。E早期非0の別根拠は68011のAPI人工であり本Coreを自然市場発動の証明へ拡張しない"}
    save(HERE / "停止.json", stop)
    print(json.dumps({"停止": label(HERE / "停止.json"), "SHA256": sha(HERE / "停止.json"), "所有": len(owned), "Go成功top": receipt["Go成功top"], "小試験": len(names), "参照": len(before)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
