# 固定Source Tapeと公開Streamを20会計へ配送するCore

試行106の**非市場準備**。module `github.com/masayoshi4649/SessionTradeExecuter/variableguardruntime`。本dirはSource/Raw/CSV/市場価格を開くCLIを持たず、停止済み値を受ける逐次Sinkだけを所有する。市場I/O・条件固定・新規保存・70順のprivate Seed管理は別ownerの `work/106市場の入出力準備`。市場実行はまだ0。

## 停止依存と再用

- 金融：停止68011の `miniearlyguard` を直接import。Source所有/部分返済・B5Q・量/各側10・費用・約定遅延・予約・保護床/幅・E起動式はここへ複写しない。
- producer：助走対応dd34の `publicsidecar.Build/Warm/Record/Header` を直接import。Raw/Features/Chart形成はCoreから呼ばない。paired Seedの中身は非公開で、Coreへ渡さない。
- Source復元：固定 `lighttape97.RestoreBatches` を全active method順で使い、旧103 RunObserved/105 RunModeと同じ `quote→OnNativeStep`、`force→OnNativeForce`、`grid→OnEntryGrid` の配送を行う。元Source通知を作らない。Closes-onlyを含め全Deltaの名前付き外型だけを明示対応する。
- C/M/P：停止8c42のPipelineで保存Publicationを再評価し、保存Delivery全field/Frame・結果SHAと比較してからSendする。保存採否を期待値として転記しない。Send/resetは公表保管だけで、MTM/Quote/起動/約定を作らない。

旧103/105/68011/dd34/8c42の停止元は変更しない。

## APIと20設定

```go
c, err := NewCore(fixedTape, contract, scope, control)
h, nextSeed, err := publicsidecar.Build(request, previousSeed,
    SourceForces(fixedTape), c.Feed)
result, err := c.Finish(h)
```

`NewCore(input tape.Tape, contract, scope string, control Control)`、`Feed(publicsidecar.Record) error`、`Finish(publicsidecar.Header) (Result,error)`。小型人工用 `Run(core,records,header)` も同じFeedを通す。Coreで実行物/条件/ファイルSHAを認証することはなく、外周が固定値と明示参照を検査する。

固定順は **W0→W1→W2→E1→E2**、各C0D0/C0D1/C5D0/C5D1。外map keyは `W0_C0_D0` 等の20個。内Book.KeyはW系が `LD10_B5Q_P0_C0_D0` 等、E系が `E1_B5Q_P0_C0_D0` 等。同じ内LD10 KeyをW0/W1/W2の同じ会計と誤認しない。全設定の共通Policy=P0/EntryTiming=B5Q/Gate・Harvest・Risk・Exit空、USOpen=元Session。W系ActivationPolicy=LD10、E系=E1/E2。

`Result` は version1/trial106/scope/session/contract/configs/books20/width_audits20/early_audits8/counts/public_diagnostics/grid_times/skipped_grids/w0_control/tape_canonical_sha256/tape_unchanged/source_reexecuted=false/charts_recomputed=false/cmp_recomputed=true/complete。全金融fieldは内Bookへそのまま残し、大量の全原行Book Snapshotは保存しない。

`public_diagnostics` は一公表単位のC/M/P既知・成立数とnumeric_seed_carried。20政策/費用で同じ公表を20回数えない。Source自身の未知・保有・新規等は既存BookのGridTrace/Opportunityに残るので、この公開値診断と混同しない。

## quote/pubの統合契約

1. 同場の同じ標準6入力から作ったproducer Streamと固定Source Tapeを使う。生産側は同じ全board時計を使う。CoreはSourceを再形成せず、quote/Force/gridをTapeの**次ordinal**へ完全に結ぶ。
2. quoteはScalar11全値をTapeへ比較。TriggerのFeaturesIndex/物理Line、RawQuoteのChart全NK Index/物理Line、Time/BBO/Lastを分けて検査する。FeaturesIndexとChart AllIndexを同一視しない。TOPIXとLast0は金融Quoteへしない。
3. Forceは保存TapeのAt/ordinalへ結び、各methodの直前SourceLineはRestoreBatchesが検査する。Forceから架空のQuote/MTMを作らない。gridは同じ予定At・場・限月を使い、quoteに再時刻化しない。
4. 公表のlogical At/AvailableAtは足終端。ObservedClockはdrain契機の入力上限で、評価Atより後でもそれだけでfutureとはしない。形成に使うLastSourceが当足より未来なら停止8c42が拒否する。保存Deliveryも全値照合する。
5. 同時計pre-rawは停止producerどおり **publication→Force→grid→raw**。Source自身はForce→grid→quoteを維持。raw段階の同秒TOPIX・NK Last0・正NKは原行/merge順で消費し、pre-rawへ戻さない。
6. resetは元Last0 Quote全値を保持し、その後のraw_clock.RawQuoteと全文一致させる。古い公表の同ID再送を復活させず、unknownを支持に変えない。
7. EOF後は元Force時計だけを消費し、公表/Raw/gridを補わない。SkippedGridsをResultへ残す。予定分母を観測済みだけへ縮めたり、欠測を待機/保有へ補ったりしない。
8. producer成功Headerの全件数とTape全消費を検査し、全20冊のFinished/Complete/残所有予約0を要求する。Source入力のJSON指紋を前後で確認する。

## W0対照を区別する

`Control.Kind` は次のどちらか。

- `provided_old_book` / `HistoryClass=old_saved_58`：既存104 sym54＋105 sym4の旧保存LD10四冊。`Expected map[innerKey]old103.ActualResult`、`ReferencePath/SHA` を外周が実物へbindして提供する。Coreは最終全JSONだけを比較する。最終しか無い資料を全時点対照へ偽装しない。
- `same_input_old103` / `HistoryClass=same_input_new12`：不足12は旧市場goldenなし。同じ入力を別旧103Actor四冊へ新規配送し、最終全JSONを比較する。旧市場再現の成功と呼ばない。

手製は `HistoryClass=artificial` とする。`AllPoints=true` は同入力Actor対照の人工だけに使い、各Source event後にW0四冊を全JSON・除外0で検査する。市場ではfalseとし、全20Bookの毎原行JSON連鎖コピーは行わない。提供したpath/SHAの由来をCore自身が認証したという主張はせず、I/O wrapperの条件/前後指紋へ分離する。

## 外周へ必要な固定schema

I/O ownerは Root条件＋コード/実行物＋完全70の入力/source/Tape/W0参照をmetadataで固定し、first2→同条件full70の新規出力だけを使う。70は9/21Day cold開始→同限月numericだけcarry、場頭mask/形成/CMP reset、roll cold。前場の存在しない価格やSeedを補完しない。Scopeとcold/unknownは後段へ残す。

Source不足12の新通知/新Tapeと旧58の参照は明示的に分ける。SourceMode=symmetricをroot入力契約で固定する。Source/Tape/Native本文のstage認証、フィンガープリント、入力集合、path基準、Seed順序、逐次gzip保存は別I/O wrapperの責任。本CoreにRaw readerやSourceFactoryを加えない。

## 非市場人工

手製二市場・CSV型・Source公開通知だけを使う。Source器具は停止103/68011の同体テストhelperを再用し、Sourceアルゴリズムを実行しない。API人工の違法なquote→同秒Forceを並べ替えたのではなく、最初から固定Force→grid→rawの合法列を作る。

- 買売×cold/paired助走の4場面、各20非0/残0、計80冊。W0は別旧103と各384、計1,536全時点＋最終16全JSON・除外0。
- Source部分/追加・予約優先、同秒Force/grid、D0/D1、Last0/不良BBO、Indexの区別、seedの公開mask再初期化を通る。
- 提供最終の別modeは手製値をclass=artificialとしてのみ検査し、旧58市場の証拠を創作しない。
- Scalar/FeaturesIndex/ChartIndex/Forceordinal/reset全値/CMP出典/未来source/同秒位相/Header/Source余剰を狭く破損して拒否する。
- 空SourceのEOF人工は20冊0取引の正当完結。EOF Forceだけを残し未観測gridはSkippedへ残す。

暖機でC/M/Pが既知になることと、E早期起動が実際に発生することは別。本4場面をE早期発動の非0証明へ拡張せず、68011の早期16/通常16 API人工とscopeを分ける。市場損益・自然Source・全原行別金融engine監査・機会損失/MFE・退出後価格の計算は0。

検査は `go test -json ./...` / `go vet ./...` / `go build ./...`。`RUNTIME106_EXPORT` は小型手製fixtureの明示保存先のみ。市場CLIは別ownerが停止後に結合する。
