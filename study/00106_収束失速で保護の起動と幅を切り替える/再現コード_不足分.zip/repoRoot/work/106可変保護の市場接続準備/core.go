package variableguardruntime

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"reflect"

	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	oldtype "github.com/masayoshi4649/SessionTradeExecuter/minichart"
	old "github.com/masayoshi4649/SessionTradeExecuter/minidelayed103"
	finance "github.com/masayoshi4649/SessionTradeExecuter/miniearlyguard"
	chart "github.com/masayoshi4649/SessionTradeExecuter/publicchart"
	delivery "github.com/masayoshi4649/SessionTradeExecuter/publicdelivery"
	stream "github.com/masayoshi4649/SessionTradeExecuter/publicsidecar"
)

// Config は外policy名を金融の内Keyから分離します。
type Config struct {
	Policy string  `json:"policy"`
	Slip   float64 `json:"slip_pts"`
	Delay  int     `json:"delay_seconds"`
}

// Control は既存保存58と同入力新旧103対照を混同しない指定です。
type Control struct {
	Kind          string                      `json:"kind"`
	HistoryClass  string                      `json:"history_class"`
	ReferencePath string                      `json:"reference_path"`
	ReferenceSHA  string                      `json:"reference_sha256"`
	Expected      map[string]old.ActualResult `json:"-"`
	AllPoints     bool                        `json:"all_points"`
}
type Counts struct {
	Records      int `json:"records"`
	Quotes       int `json:"quotes"`
	Forces       int `json:"forces"`
	Grids        int `json:"grids"`
	Publications int `json:"publications"`
	Three        int `json:"three_publications"`
	Resets       int `json:"resets"`
	RawBoards    int `json:"raw_boards"`
}

// PublicRoleCounts は費用policyで反復加算しない一公表の既知/成立件数です。
type PublicRoleCounts struct {
	MKnown int `json:"M_known"`
	MPass  int `json:"M_pass"`
	PKnown int `json:"P_known"`
	PPass  int `json:"P_pass"`
}
type PublicDiagnostics struct {
	New3               int              `json:"new_three"`
	CKnown             int              `json:"C_known"`
	CPass              int              `json:"C_pass"`
	Buy                PublicRoleCounts `json:"buy"`
	Sell               PublicRoleCounts `json:"sell"`
	NumericSeedCarried bool             `json:"numeric_seed_carried"`
}
type ControlProof struct {
	Kind                string   `json:"kind"`
	HistoryClass        string   `json:"history_class"`
	Books               int      `json:"books"`
	All                 bool     `json:"all"`
	Excluded            []string `json:"excluded"`
	AllPointComparisons int      `json:"all_point_comparisons"`
	ReferencePath       string   `json:"reference_path"`
	ReferenceSHA        string   `json:"reference_sha256"`
	Scope               string   `json:"scope"`
}

// Result は停止金融全値を外policy/cost namespaceへ保存します。
type Result struct {
	Version           int                               `json:"version"`
	Trial             int                               `json:"trial"`
	Scope             string                            `json:"scope"`
	Session           finance.Session                   `json:"session"`
	Contract          string                            `json:"contract"`
	Configs           []Config                          `json:"configs"`
	Books             map[string]finance.ActualResult   `json:"books"`
	WidthAudits       map[string]finance.WidthBookAudit `json:"width_audits"`
	EarlyAudits       map[string]finance.EarlyBookAudit `json:"early_audits"`
	Counts            Counts                            `json:"counts"`
	PublicDiagnostics PublicDiagnostics                 `json:"public_diagnostics"`
	GridTimes         []float64                         `json:"grid_times"`
	SkippedGrids      []float64                         `json:"skipped_grids"`
	W0Control         ControlProof                      `json:"w0_control"`
	TapeSHA           string                            `json:"tape_canonical_sha256"`
	TapeUnchanged     bool                              `json:"tape_unchanged"`
	SourceReexecuted  bool                              `json:"source_reexecuted"`
	ChartRecomputed   bool                              `json:"charts_recomputed"`
	CMPRecomputed     bool                              `json:"cmp_recomputed"`
	Complete          bool                              `json:"complete"`
}

// Core は全原行Book copyを蓄積しない20会計Sinkです。Source/チャートを形成しません。
type Core struct {
	input                    tape.Tape
	contract, scope, tapeSHA string
	control                  Control
	configs                  []Config
	actors                   []*finance.ActualBook
	controls                 []*old.ActualBook
	pipeline                 *delivery.Pipeline
	cursor                   int
	last                     map[string]int64
	counts                   Counts
	publicStats              PublicDiagnostics
	lastAt                   float64
	haveAt, rawAt            bool
	rawAll                   map[string]int64
	pendingReset             map[string]chart.Quote
	preRank                  int
	grids                    []float64
	pointChecks, afterEOF    int
	eof                      bool
	failed                   error
	finished                 bool
}

// Configurations はW0/W1/W2/E1/E2各C0D0/C0D1/C5D0/C5D1を返します。
//
// 引数: なし。返り値: []Configは固定順20設定です。
func Configurations() []Config {
	out := []Config{}
	for _, p := range []string{"W0", "W1", "W2", "E1", "E2"} {
		for _, c := range []float64{0, 5} {
			for _, d := range []int{0, 1} {
				out = append(out, Config{p, c, d})
			}
		}
	}
	return out
}

// Key は内金融Keyを変更せず外policy/costだけを識別します。
//
// 引数: c(Config)は固定設定。返り値: stringはW0_C0_D0等です。
func Key(c Config) string { return fmt.Sprintf("%s_C%.0f_D%d", c.Policy, c.Slip, c.Delay) }

// digestValue は保存可能な全値のJSON SHAを求めます。
//
// 引数: value(any)はSource/Tape/公開値。返り値: string/errorは全JSONのSHAです。
func digestValue(value any) (string, error) {
	b, e := json.Marshal(value)
	if e != nil {
		return "", e
	}
	h := sha256.Sum256(b)
	return hex.EncodeToString(h[:]), nil
}

// sameJSON は許容やfield除外なしで全公開値を比較します。
//
// 引数: a/b(any)は公開型。返り値: boolは全JSON同体です。
func sameJSON(a, b any) bool {
	x, e := json.Marshal(a)
	if e != nil {
		return false
	}
	y, e := json.Marshal(b)
	return e == nil && bytes.Equal(x, y)
}

// NewCore は同じ固定Source入力へ20金融と明示W0対照を作ります。
//
// 引数: input(Tape)、contract/scope(string)、control(Control)は固定値と対照の由来です。
// 返り値: *Core/errorはSink又は未対応/不正指定です。FileRef実物の認証は外周の責務です。
func NewCore(input tape.Tape, contract, scope string, control Control) (*Core, error) {
	c := &Core{input: input, contract: contract, scope: scope, control: control, configs: Configurations(), pipeline: delivery.NewPipeline(), last: map[string]int64{}, rawAll: map[string]int64{}, pendingReset: map[string]chart.Quote{}, preRank: -1, grids: []float64{}}
	if input.Version != 1 || input.Scope == "" || scope == "" || contract == "" || !reflect.DeepEqual(input.Capabilities, tape.Capabilities()) {
		return nil, fmt.Errorf("固定Tape/明示scope/限月が必要")
	}
	if control.Kind != "same_input_old103" && control.Kind != "provided_old_book" {
		return nil, fmt.Errorf("W0対照modeが未定義")
	}
	if control.Kind == "same_input_old103" && control.HistoryClass != "same_input_new12" && control.HistoryClass != "artificial" {
		return nil, fmt.Errorf("新同入力対照の由来classが不正")
	}
	if control.Kind == "same_input_old103" && (len(control.Expected) != 0 || control.ReferencePath != "" || control.ReferenceSHA != "") {
		return nil, fmt.Errorf("新同入力対照へ旧goldenを混入")
	}
	if control.Kind == "provided_old_book" && (len(control.Expected) != 4 || control.ReferencePath == "" || len(control.ReferenceSHA) != 64 || (control.HistoryClass != "old_saved_58" && control.HistoryClass != "artificial")) {
		return nil, fmt.Errorf("旧保存四冊の明示参照不足")
	}
	if control.AllPoints && control.Kind != "same_input_old103" {
		return nil, fmt.Errorf("旧保存最終を全時点対照へ偽装")
	}
	previous := 0.0
	rank := map[string]int{"force": 0, "grid": 1, "quote": 2}
	previousRank := -1
	for i, e := range input.Events {
		r, ok := rank[e.Kind]
		if !ok || e.Ordinal != i+1 || math.IsNaN(e.At) || math.IsInf(e.At, 0) || e.At < previous || e.At == previous && r < previousRank {
			return nil, fmt.Errorf("Source Tape ordinal/位相差")
		}
		if e.At != previous {
			previousRank = -1
		}
		previous, previousRank = e.At, r
	}
	h, e := digestValue(input)
	if e != nil {
		return nil, e
	}
	c.tapeSHA = h
	for _, cfg := range c.configs {
		a := finance.ActorConfig{Policy: "P0", ActivationPolicy: finance.ActivationLD10, EntryTiming: "B5Q", USOpen: input.Session.USOpen, SlipPts: cfg.Slip, DelaySeconds: cfg.Delay}
		var b *finance.ActualBook
		if cfg.Policy == "E1" || cfg.Policy == "E2" {
			a.ActivationPolicy = finance.ActivationPolicy(cfg.Policy)
			b, e = finance.NewEarlyBook(input.Session, a, contract)
		} else {
			b, e = finance.NewWidthBook(input.Session, a, cfg.Policy, contract)
		}
		if e != nil {
			return nil, e
		}
		c.actors = append(c.actors, b)
		if cfg.Policy == "W0" {
			if control.Kind == "same_input_old103" {
				p, err := old.NewActualBook(input.Session, old.ActorConfig{Policy: "P0", ActivationPolicy: old.ActivationLD10, EntryTiming: "B5Q", USOpen: input.Session.USOpen, SlipPts: cfg.Slip, DelaySeconds: cfg.Delay})
				if err != nil {
					return nil, err
				}
				c.controls = append(c.controls, p)
			} else {
				p, ok := control.Expected[b.Snapshot().Key]
				if !ok || p.Session != input.Session || !p.Complete || !p.Finished || p.Config.ActivationPolicy != old.ActivationLD10 || p.Config.Policy != "P0" || p.Config.EntryTiming != "B5Q" || p.Config.SlipPts != cfg.Slip || p.Config.DelaySeconds != cfg.Delay {
					return nil, fmt.Errorf("旧保存対照の内Key/場/設定差")
				}
			}
		}
	}
	return c, nil
}

// fail は部分処理を成功へ補わず失敗を保持します。
//
// 引数: e(error)は原因。返り値: errorは同じ原因です。
func (c *Core) fail(e error) error { c.failed = e; return e }

// batches は全Deltaを変更せず新金融/旧103の名前付き外型へ対応します。
//
// 引数: in([]oldtype.NativeBatch)は固定復元列。返り値: 新/旧batch列は順序/nil/全値を保持します。
func batches(in []oldtype.NativeBatch) ([]finance.NativeBatch, []old.NativeBatch) {
	if in == nil {
		return nil, nil
	}
	n := make([]finance.NativeBatch, len(in))
	o := make([]old.NativeBatch, len(in))
	for i, b := range in {
		n[i] = finance.NativeBatch{Method: b.Method, Delta: b.Delta}
		o[i] = old.NativeBatch{Method: b.Method, Delta: b.Delta}
	}
	return n, o
}

// source は固定Tapeの次quote/Force/gridだけを同じ順で一度配送します。
//
// 引数: r(stream.Record)は対応済みの保存公開列。返り値: errorはSource結合/金融の不一致です。
func (c *Core) source(r stream.Record) error {
	if c.cursor >= len(c.input.Events) {
		return fmt.Errorf("Source Tapeより余剰配送")
	}
	event := c.input.Events[c.cursor]
	if event.Kind != r.Kind || event.At != r.At {
		return fmt.Errorf("Source Tape次ordinalとの種別/時計差:%d", event.Ordinal)
	}
	switch r.Kind {
	case "quote":
		if event.Quote == nil || r.Scalar == nil || !reflect.DeepEqual(*event.Quote, *r.Scalar) || event.Context != nil {
			return fmt.Errorf("固定Scalar11差")
		}
	case "force":
		if r.Force == nil || r.Force.TapeOrdinal != event.Ordinal || r.Force.At != event.At || event.Quote != nil || event.Context != nil {
			return fmt.Errorf("元Force ordinal/時計差")
		}
	case "grid":
		if r.Grid == nil || r.Grid.Legacy.At != event.At || r.Grid.Legacy.Scene.ID != c.input.Session.ID || r.Grid.Legacy.Scene.Contract != c.contract || r.Grid.Legacy.Scene.Start != c.input.Session.Start || event.Quote != nil || len(event.Methods)+len(event.NonEmpty) != 0 || event.Context != nil && event.Context.At != event.At {
			return fmt.Errorf("元5分grid差")
		}
	}
	if r.Kind == "grid" {
		for _, b := range c.actors {
			if e := b.OnEntryGrid(event.At); e != nil {
				return e
			}
		}
		for _, b := range c.controls {
			if e := b.OnEntryGrid(event.At); e != nil {
				return e
			}
		}
		c.grids = append(c.grids, event.At)
		c.counts.Grids++
	} else {
		full, e := tape.RestoreBatches(event, c.last)
		if e != nil {
			return e
		}
		before, e := digestValue(full)
		if e != nil {
			return e
		}
		n, o := batches(full)
		for _, b := range c.actors {
			if r.Kind == "quote" {
				e = b.OnNativeStep(event.Quote.Observation(), event.Quote.SourceLine, n)
			} else {
				e = b.OnNativeForce(event.At, n)
			}
			if e != nil {
				return e
			}
		}
		for _, b := range c.controls {
			if r.Kind == "quote" {
				e = b.OnNativeStep(event.Quote.Observation(), event.Quote.SourceLine, o)
			} else {
				e = b.OnNativeForce(event.At, o)
			}
			if e != nil {
				return e
			}
		}
		after, e := digestValue(full)
		if e != nil || before != after {
			return fmt.Errorf("共有Source通知を変更")
		}
		if r.Kind == "quote" {
			c.counts.Quotes++
		} else {
			c.counts.Forces++
		}
	}
	c.cursor++
	if c.control.AllPoints {
		for i, b := range c.controls {
			if !sameJSON(c.actors[i].Snapshot(), b.Snapshot()) {
				return fmt.Errorf("W0旧103全時点JSON差")
			}
			c.pointChecks++
		}
	}
	return nil
}
