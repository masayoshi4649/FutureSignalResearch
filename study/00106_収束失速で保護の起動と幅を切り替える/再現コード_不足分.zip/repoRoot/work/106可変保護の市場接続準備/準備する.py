"""停止済み会計と助走対応producerを新しい純Sinkへ参照する。"""
from pathlib import Path


def main():
    """
    機能: 新moduleの参照だけを作る。
    引数: なし。
    返り値: None。元停止/市場本文を変更しない。
    """
    here = Path(__file__).resolve().parent
    src = here.parent / "収束失速で保護を早める会計案"
    text = (src / "go.mod").read_text(encoding="utf-8-sig").replace("module github.com/masayoshi4649/SessionTradeExecuter/miniearlyguard", "module github.com/masayoshi4649/SessionTradeExecuter/variableguardruntime")
    text += "\nrequire github.com/masayoshi4649/SessionTradeExecuter/miniearlyguard v0.0.0\nreplace github.com/masayoshi4649/SessionTradeExecuter/miniearlyguard => ../収束失速で保護を早める会計案\nrequire github.com/masayoshi4649/SessionTradeExecuter/publicsidecar v0.0.0\nreplace github.com/masayoshi4649/SessionTradeExecuter/publicsidecar => ../可変追尾の実場公開配送_助走対応\nrequire github.com/masayoshi4649/SessionTradeExecuter/continuous101 v0.0.0\nreplace github.com/masayoshi4649/SessionTradeExecuter/continuous101 => ../../scripts/保護判断の連続技法入力\nrequire github.com/masayoshi4649/SessionTradeExecuter/lighttape97 v0.0.0\nreplace github.com/masayoshi4649/SessionTradeExecuter/lighttape97 => ../../scripts/固定通知と価格行の再生\n"
    (here / "go.mod").write_text(text, encoding="utf-8")
    (here / "go.sum").write_bytes((src / "go.sum").read_bytes())


if __name__ == "__main__":
    main()
