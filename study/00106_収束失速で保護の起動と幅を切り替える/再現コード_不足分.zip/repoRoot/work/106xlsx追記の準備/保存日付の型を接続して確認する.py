"""凍結QAを変えず、正当なOOXML日付型だけを読取時に1900serialへ接続する。"""
from __future__ import annotations
import argparse
import copy
from datetime import date, datetime, timezone
from decimal import Decimal
import hashlib
import importlib.util
import json
from pathlib import Path

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
QA_PATH = WORK / '保存後を確認する.py'
QA_SHA = 'f73f0dd4b194182c35dfe41653a8faa3cee66841fcf38321e23e3a8a4a469850'
assert hashlib.sha256(QA_PATH.read_bytes()).hexdigest() == QA_SHA
SPEC = importlib.util.spec_from_file_location('凍結106QAの日付型だけを接続', QA_PATH)
QA = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(QA)


def date_cell(cell: dict) -> dict:
    """
    機能: t=dの正当なISO UTC午前0時だけを比較用1900serialへ写す。
    引数: cell(dict)は読取専用OOXMLの値/型/式/スタイル。
    返り値: dictは独立copy。既存1900serial数値は保ち、文字列や不正時計は拒否する。
    """
    result = copy.deepcopy(cell)
    if cell['type'] == 'd':
        value = cell['value']
        assert isinstance(value, str) and value.endswith('Z')
        parsed = datetime.fromisoformat(value[:-1] + '+00:00')
        assert parsed.tzinfo is not None and parsed.utcoffset().total_seconds() == 0
        assert (parsed.hour, parsed.minute, parsed.second, parsed.microsecond) == (0, 0, 0, 0)
        result['value'] = Decimal((parsed.date() - date(1899, 12, 30)).days)
    else:
        assert cell['type'] in (None, 'n') and isinstance(cell['value'], Decimal)
        assert cell['value'].is_finite() and cell['value'] == cell['value'].to_integral_value()
    return result


def extra_fields(result: dict, cells: dict) -> None:
    """
    機能: 凍結QAの他の検査を保ち、区分ラベル/PF/待機と公表日付も正本へ結ぶ。
    引数: result(dict)、cells(dict)は保存正本と日付型接続後の新タブ。
    返り値: None。金額や分母の許容を拡張しない。
    """
    keys = [f'{p}_C{c}_D{d}' for p in ('W0', 'W1', 'W2', 'E1', 'E2') for c in (0, 5) for d in (0, 1)]
    labels = {'Day': '日中', 'Night': '夜間', 'old104_54': '旧104の54場', 'saved105_4': '105の4場', 'fresh106_12': '追加12場'}
    for i, key in enumerate(keys):
        p, c, d = key.split('_')
        row = 32 + i
        assert cells['A'+str(row)]['value'] == p and cells['B'+str(row)]['value'] == c+'/'+d
        for col, name in [('L', 'wait'), ('M', 'unknown')]:
            assert cells[col+str(row)]['value'] == result['集計'][key]['活動主表'][name]
    for start, field, kinds in [(58, '日夜', ('Day', 'Night')), (104, '履歴区分', ('old104_54', 'saved105_4', 'fresh106_12'))]:
        for i, (key, kind) in enumerate((k, t) for k in keys for t in kinds):
            p, c, d = key.split('_')
            row = start + i
            assert cells['A'+str(row)]['value'] == p and cells['B'+str(row)]['value'] == c+'/'+d
            pf = result['実現診断'][key][field][kind]['PF']
            assert cells['E'+str(row)]['value'] == '未定義' if pf is None else abs(cells['E'+str(row)]['value']-pf) < Decimal('1e-13')
    history = {r['session']: r['history_class'] for r in result['場別']}
    for i, sid in enumerate(sorted(history)):
        row = 1598 + i
        assert cells['A'+str(row)]['value'] == (date.fromisoformat(sid[:10]) - date(1899, 12, 30)).days
        assert cells['B'+str(row)]['value'] == labels[sid.split('_')[1]]
        assert cells['C'+str(row)]['value'] == labels[history[sid]]


def self_test() -> None:
    """
    機能: 正当ISO/旧serialと文字列・不正時刻の境界を確認する。
    引数: なし。
    返り値: None。workbookの作成/編集は行わない。
    """
    original = {'value': '2026-09-21T00:00:00.000Z', 'type': 'd', 'formula': None, 'style': '28'}
    assert date_cell(original)['value'] == 46286 and original['value'].endswith('Z')
    serial = {'value': Decimal(46286), 'type': None}
    assert date_cell(serial) == serial
    for value, kind in [('2026-09-21T00:00:00.000Z', 's'), ('2026-09-21T01:00:00Z', 'd'),
                        ('2026-09-21T00:00:00.001Z', 'd'), ('2026-02-30T00:00:00Z', 'd'),
                        ('2026-09-21T00:00:00+09:00', 'd'), ('2026-09-21', 'd')]:
        try:
            date_cell({'value': value, 'type': kind})
        except (AssertionError, ValueError):
            pass
        else:
            raise AssertionError('不正日付型を受理')


def main() -> None:
    """
    機能: 同じ凍結QAで旧保持と全正本照合を実施し、日付型の接続範囲を保存する。
    引数: fixed/fixed-sha/outはRootのxlsx事後固定と新しいQA先。
    返り値: None。ブック/旧QA/旧stopを編集しない。
    """
    p = argparse.ArgumentParser()
    p.add_argument('--fixed', type=Path, required=True)
    p.add_argument('--fixed-sha', required=True)
    p.add_argument('--out', type=Path, required=True)
    a = p.parse_args()
    assert QA.OLD.digest(a.fixed) == a.fixed_sha and not a.out.exists()
    fixed = json.loads(a.fixed.read_text(encoding='utf-8-sig'))
    source = (a.fixed.parent / fixed['summary']['path']).resolve()
    assert QA.OLD.digest(source) == fixed['summary']['sha256']
    self_test()
    before = QA.OLD.digest(QA.BOOK)
    proof = QA.compare(WORK/'106追記前.xlsx', QA.BOOK, True)
    result = json.loads(source.read_text(encoding='utf-8-sig'), parse_float=Decimal)
    _, _, all_cells = QA.OLD.read_workbook(QA.BOOK)
    original = all_cells[QA.TARGET]
    cells = copy.deepcopy(original)
    iso = serial = 0
    for row in list(range(170,1570)) + list(range(1598,1668)):
        key = 'A'+str(row)
        if cells[key]['type'] == 'd':
            iso += 1
        else:
            serial += 1
        cells[key] = date_cell(cells[key])
    QA.verify_source(result, cells)
    extra_fields(result, cells)
    assert all_cells[QA.TARGET] == original and QA.OLD.digest(QA.BOOK) == before
    proof.update({'成功': True, 'scope': '旧4タブ全保持と106全領域正本照合。t=d/ISO UTC午前0時の読取型だけ接続',
                  '新20_日夜40_履歴60_場別1400_比較16_公表70正本一致': True,
                  '日付型': {'ISO_UTC午前0時': iso, '旧1900serial': serial, '手製正常2_拒否6': True, '元セル値不変': True},
                  '正本SHA256': fixed['summary']['sha256'], 'Root固定SHA256': a.fixed_sha,
                  '旧QA_SHA256': QA_SHA, '新QA_SHA256': QA.OLD.digest(Path(__file__)),
                  'ブックSHA256前': before, 'ブックSHA256後': before, 'ブック再編集_再export_marker': 0})
    with a.out.open('x',encoding='utf-8',newline='\n') as f:
        json.dump(proof,f,ensure_ascii=False,indent=2)
        f.write('\n')
    print(json.dumps(proof,ensure_ascii=False))


if __name__ == '__main__':
    main()
