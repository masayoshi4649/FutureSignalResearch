"""106の第五タブ追記前後を読み、旧全セル/書式/図と新正本を照合する。"""
from __future__ import annotations
import argparse
from datetime import date
from decimal import Decimal
import hashlib
import importlib.util
import json
from pathlib import Path
import xml.etree.ElementTree as ET

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
BOOK = ROOT / 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/元アルゴリズムと現行代表候補の損益比較.xlsx'
BASE_SHA = '298fe652463db911177f8fa359240d7ff0f0b1e4bf804c4b155fedd55fbd03a9'
SHEETS = ['比較', 'セッション明細', '新条件102', '一定利益後103']
TARGET = '収束早期保護106'
SPEC = importlib.util.spec_from_file_location('旧103の読取専用OOXML', ROOT / 'work/xlsx比較_作成/103の保存比較QA.py')
OLD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(OLD)


def compare(before: Path, after: Path, appended: bool) -> dict:
    """
    機能: 旧四タブを全セル・全構造・全図表・旧スタイル定義で照合する。
    引数: before/after(Path)、appended(bool)は旧新と第五タブ追加の有無。
    返り値: dictは保持件数。xlsxを作成せず正当な差を勝手に除外しない。
    """
    assert OLD.digest(before) == BASE_SHA
    pa, sa, ca = OLD.read_workbook(before)
    pb, sb, cb = OLD.read_workbook(after)
    assert list(sa) == SHEETS and list(sb) == SHEETS + ([TARGET] if appended else [])
    proof = []
    for name in sa:
        assert ca[name] == cb[name], name + '全旧セル/式/型/スタイル差'
        assert OLD.normalized_part(pa, sa[name]) == OLD.normalized_part(pb, sb[name]), name + '全旧worksheet構造差'
        proof.append({'sheet': name, '旧全セル': len(ca[name]), '全値_式_型_スタイル_構造保持': True})
    objects = [n for n in pa if n.startswith(('xl/charts/', 'xl/drawings/', 'xl/tables/'))]
    assert set(objects) == {n for n in pb if n.startswith(('xl/charts/', 'xl/drawings/', 'xl/tables/'))}
    assert all(OLD.normalized_part(pa, n) == OLD.normalized_part(pb, n) for n in objects)
    for section in ('fonts', 'fills', 'borders', 'cellStyleXfs', 'cellXfs', 'cellStyles', 'dxfs', 'numFmts'):
        a = ET.fromstring(pa['xl/styles.xml']).find('m:' + section, OLD.NS)
        b = ET.fromstring(pb['xl/styles.xml']).find('m:' + section, OLD.NS)
        if a is not None:
            assert b is not None and len(b) >= len(a)
            assert all(ET.tostring(x) == ET.tostring(y) for x, y in zip(a, b)), section
    for field in ('definedNames', 'bookViews', 'workbookProtection'):
        a = ET.fromstring(pa['xl/workbook.xml']).find('m:' + field, OLD.NS)
        b = ET.fromstring(pb['xl/workbook.xml']).find('m:' + field, OLD.NS)
        assert (ET.tostring(a) if a is not None else None) == (ET.tostring(b) if b is not None else None)
    assert not [f'{name}!{key}' for name, cells in cb.items() for key, cell in cells.items() if cell['type'] == 'e']
    return {'旧4tab': proof, '旧図表parts保持': len(objects), '旧styles定義保持': True, '全ZIP_CRC': True}


def verify_source(result: dict, cells: dict) -> None:
    """
    機能: 保存後の106数値を正本全20・日夜40・履歴60・場別1400・比較16・公表70へ照合する。
    引数: result(dict)は正本集約、cells(dict)は新タブの解決済みOOXML。
    返り値: None。不一致を金融や値の許容で救済しない。
    """
    assert result['試行'] == 106 and result['成功'] and result['stage'] == 'full70'
    keys = [f'{p}_C{c}_D{d}' for p in ('W0', 'W1', 'W2', 'E1', 'E2') for c in (0, 5) for d in (0, 1)]
    labels = {'old104_54': '旧104の54場', 'saved105_4': '105の4場', 'fresh106_12': '追加12場', 'Day': '日中', 'Night': '夜間'}
    for i, key in enumerate(keys):
        v = result['集計'][key]
        row = 6 + i
        policy, cost, delay = key.split('_')
        assert cells['A' + str(row)]['value'] == policy and cells['B' + str(row)]['value'] == cost + '/' + delay
        for col, name in [('C', 'net_yen'), ('D', 'gross_yen'), ('E', 'fee_yen'), ('F', 'slip_yen'), ('H', '保存点連結時価DD'), ('I', 'positions'), ('J', 'entry_quantity'), ('P', 'unit_positive_closed_negative_yen'), ('Q', 'activated_closed_negative_yen'), ('R', 'narrowed_positions')]:
            assert cells[col + str(row)]['value'] == v[name], (key, col)
        assert cells['K' + str(row)]['value'] == v['活動主表']['active']
        assert cells['L' + str(row)]['value'] == 7840
        assert abs(cells['M' + str(row)]['value'] - Decimal(v['活動主表']['active']) / 7840) < Decimal('1e-14')
        assert (cells['G' + str(row)]['value'] == '未定義') if v['PF'] is None else abs(cells['G' + str(row)]['value'] - Decimal(str(v['PF']))) < Decimal('1e-13')
        assert cells['N' + str(row)]['value'] == ('達成' if v['活動主表']['active'] * 4 >= 7840 else '未達')
        assert cells['O' + str(row)]['value'] == ('達成' if v['活動主表']['active'] * 2 >= 7840 else '未達')
        f = 32 + i
        for col, name in [('C', 'unit_positive_positions'), ('D', 'unit_positive_closed_negative'), ('E', 'unit_positive_closed_negative_yen'), ('F', 'protection_activated_positions'), ('G', 'activated_closed_negative'), ('H', 'activated_closed_negative_yen'), ('I', 'normal_ld10_activations'), ('J', 'early_warning_activations'), ('K', 'narrowed_positions')]:
            assert cells[col + str(f)]['value'] == v[name], (key, col)
    for start, field, categories in [(58, '日夜', ('Day', 'Night')), (104, '履歴区分', ('old104_54', 'saved105_4', 'fresh106_12'))]:
        for i, (key, kind) in enumerate((k, t) for k in keys for t in categories):
            v = result['実現診断'][key][field][kind]
            row = start + i
            assert cells['C' + str(row)]['value'] == labels[kind]
            for col, name in [('D', 'net_yen'), ('F', '保存点連結時価DD'), ('G', 'positions'), ('H', 'entry_quantity'), ('L', 'unit_positive_closed_negative_yen'), ('M', 'activated_closed_negative_yen'), ('N', 'early_warning_activations')]:
                assert cells[col + str(row)]['value'] == v[name], (key, kind, col)
            for col, name in [('I', 'active'), ('J', 'denom')]:
                assert cells[col + str(row)]['value'] == v['活動主表'][name]
            assert abs(cells['K' + str(row)]['value'] - Decimal(v['活動主表']['active']) / v['活動主表']['denom']) < Decimal('1e-14')
    by_pair = {(x['session'], x['key']): x for x in result['場別']}
    sessions = sorted({x['session'] for x in result['場別']})
    assert len(by_pair) == 1400 and len(sessions) == 70
    for i, pair in enumerate((s, k) for s in sessions for k in keys):
        v = by_pair[pair]
        row = 170 + i
        policy, cost, delay = pair[1].split('_')
        assert cells['A' + str(row)]['value'] == (date.fromisoformat(pair[0][:10]) - date(1899, 12, 30)).days
        assert cells['B' + str(row)]['value'] == labels[pair[0].split('_')[1]]
        assert cells['C' + str(row)]['value'] == labels[v['history_class']]
        assert cells['D' + str(row)]['value'] == policy and cells['E' + str(row)]['value'] == cost + '/' + delay
        for col, name in [('F', 'gross_yen'), ('G', 'fee_yen'), ('H', 'slip_yen'), ('I', 'net_yen'), ('J', 'positions'), ('K', 'entry_quantity'), ('O', 'unit_positive_closed_negative_yen'), ('P', 'activated_closed_negative_yen'), ('Q', 'early_warning_activations'), ('R', 'narrowed_positions')]:
            assert cells[col + str(row)]['value'] == v[name], (pair, col)
        for col, name in [('L', 'active'), ('M', 'denom')]:
            assert cells[col + str(row)]['value'] == v['活動主表'][name]
        assert abs(cells['N' + str(row)]['value'] - Decimal(v['活動主表']['active']) / v['活動主表']['denom']) < Decimal('1e-14')
    for i, (policy, cost, delay) in enumerate((p, c, d) for p in ('W1', 'W2', 'E1', 'E2') for c in (0, 5) for d in (0, 1)):
        after, before = f'{policy}_C{cost}_D{delay}', f'W0_C{cost}_D{delay}'
        v = result['同実入口と実現額差'][after + '対' + before]['合計']
        row = 1576 + i
        assert cells['A' + str(row)]['value'] == after and cells['B' + str(row)]['value'] == before
        for col, name in zip('CDEFGHIJK', ('全差額', '同実入口玉', '同実入口差額', '取得変更玉', '取得変更差額', '前のみ玉', '前のみ実現額', '後のみ玉', '後のみ実現額')):
            assert cells[col + str(row)]['value'] == v[name]
    public = {v['session']: v for v in result['一公表単位の役割診断']}
    assert set(public) == set(sessions)
    for i, session in enumerate(sessions):
        row = 1598 + i
        v = public[session]
        expected = [v['new_three'], v['C_known'], v['C_pass']] + [v[side][name] for side in ('buy', 'sell') for name in ('M_known', 'M_pass', 'P_known', 'P_pass')]
        for col, amount in zip('EFGHIJKLMNO', expected):
            assert cells[col + str(row)]['value'] == amount
        assert cells['D' + str(row)]['value'] == ('1' if v['numeric_seed_carried'] else '0')


def main() -> None:
    """
    機能: 今回は既存読取基準、将来は第五タブ追記後の正本照合を実施する。
    引数: CLIのbaseline/source/source-sha/outは読取モードとRootの将来固定。
    返り値: None。小さなQAだけを新規保存しブックを編集しない。
    """
    p = argparse.ArgumentParser()
    p.add_argument('--baseline', action='store_true')
    p.add_argument('--source', type=Path)
    p.add_argument('--source-sha')
    p.add_argument('--out', type=Path, required=True)
    a = p.parse_args()
    before = BOOK if a.baseline else WORK / '106追記前.xlsx'
    proof = compare(before, BOOK, not a.baseline)
    if not a.baseline:
        assert a.source and a.source_sha and OLD.digest(a.source) == a.source_sha
        result = json.loads(a.source.read_text(encoding='utf-8-sig'), parse_float=Decimal)
        _, _, cells = OLD.read_workbook(BOOK)
        verify_source(result, cells[TARGET])
        proof['106全20_日夜40_履歴60_場別1400正本一致'] = True
        proof['正本SHA256'] = a.source_sha
    proof.update({'成功': True, 'scope': '既存4タブ読取baselineだけ' if a.baseline else '106追記後の旧4タブ保持と正本照合', 'ブックSHA256': OLD.digest(BOOK), 'xlsx編集_export_marker': 0, '106市場本文読取': 0 if a.baseline else 1})
    with a.out.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(proof, f, ensure_ascii=False, indent=2)
        f.write('\n')
    print(json.dumps(proof, ensure_ascii=False))


if __name__ == '__main__':
    main()
