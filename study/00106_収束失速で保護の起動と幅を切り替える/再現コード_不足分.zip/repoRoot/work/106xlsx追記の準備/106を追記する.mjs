/**
 * 106保存結果を第五タブへ追記するための準備コード。
 * 引数: CLIの--review/--appendとRoot事後固定は読取又は将来の追記を指定する。
 * 返り値: Promise<void>。Root事後固定のない市場入力と編集は拒否する。
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {FileBlob, SpreadsheetFile} from '@oai/artifact-tool';

const ROOT=path.resolve(import.meta.dirname,'../..'), WORK=import.meta.dirname;
export const BOOK=path.join(ROOT,'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/元アルゴリズムと現行代表候補の損益比較.xlsx');
export const BOOK_SHA='298fe652463db911177f8fa359240d7ff0f0b1e4bf804c4b155fedd55fbd03a9';
export const OLD_SHEETS=['比較','セッション明細','新条件102','一定利益後103'];
export const SHEET='収束早期保護106';
export const KEYS=['W0','W1','W2','E1','E2'].flatMap(p=>[0,5].flatMap(c=>[0,1].map(d=>`${p}_C${c}_D${d}`)));
const HISTORY=['old104_54','saved105_4','fresh106_12'];
const LABELS={old104_54:'旧104の54場',saved105_4:'105の4場',fresh106_12:'追加12場',Day:'日中',Night:'夜間'};
const FIELDS=['gross_yen','fee_yen','slip_yen','net_yen','positive_yen','negative_yen','positions','entry_quantity',
  'unit_positive_positions','unit_positive_closed_negative','unit_positive_closed_negative_yen',
  'protection_activated_positions','activated_closed_negative','activated_closed_negative_yen',
  'normal_ld10_activations','early_warning_activations','narrowed_positions'];
export const LAYOUT={summary:6,flags:32,daynight:58,history:104,detail:170,comparisons:1576,publications:1598};

/**
 * 内容指紋を求める。
 * @param {Uint8Array|string} bytes - 小入力又はブック。
 * @returns {string} SHA256。
 */
function sha(bytes){return crypto.createHash('sha256').update(bytes).digest('hex');}

/**
 * 保存集約の金額・二旗・参加分母を検査する。
 * @param {Object} row - 保存済み集約。
 * @param {number} denom - 主分母。
 * @returns {void} 欠落や不一致は例外。
 */
function checkRow(row,denom){
  for(const f of FIELDS)assert.ok(typeof row[f]==='number'&&Number.isFinite(row[f]),f);
  assert.equal(row.gross_yen-row.fee_yen-row.slip_yen,row.net_yen);
  assert.equal(row.positive_yen+row.negative_yen,row.net_yen);
  assert.ok(row.positive_yen>=0&&row.negative_yen<=0);
  assert.ok(row.unit_positive_closed_negative<=row.unit_positive_positions);
  assert.ok(row.activated_closed_negative<=row.protection_activated_positions);
  const a=row['活動主表'];assert.equal(a.denom,denom);
  assert.ok(['new','hold','active','wait','unknown'].every(k=>Number.isInteger(a[k])&&a[k]>=0));
  assert.equal(a.new+a.hold,a.active);assert.equal(a.active+a.wait+a.unknown,denom);
}

/**
 * 指定集約と場別の加算可能な値を照合する。DDは保存器の連結値を用いる。
 * @param {Object} row - 保存済み集約。
 * @param {Object[]} scenes - 対象場別。
 * @returns {void} 不一致なら例外。
 */
function checkAggregate(row,scenes){
  checkRow(row,scenes.reduce((s,r)=>s+r['活動主表'].denom,0));
  for(const f of FIELDS)assert.equal(row[f],scenes.reduce((s,r)=>s+r[f],0),f);
  for(const f of ['new','hold','active','wait','unknown'])assert.equal(row['活動主表'][f],scenes.reduce((s,r)=>s+r['活動主表'][f],0),f);
  assert.ok(Number.isFinite(row['保存点連結時価DD'])&&row['保存点連結時価DD']>=0);
  assert.ok(row.negative_yen===0?row.PF===null:typeof row.PF==='number'&&Math.abs(row.PF-row.positive_yen/-row.negative_yen)<1e-9);
}

/**
 * 正本の70場20設定を表示用配列へ射影する。
 * @param {Object} result - 検算済み保存結果。手製人工でも同じ型だけを使う。
 * @returns {Object} 集計20・二旗20・日夜40・履歴60・場別1400・比較16・公表70の表。
 */
export function prepareTables(result){
  assert.equal(result['試行'],106);assert.equal(result['成功'],true);assert.equal(result.stage,'full70');
  assert.equal(result['場数'],70);assert.equal(result['会計数'],1400);assert.equal(result['前後不変'],true);
  assert.deepEqual(result['入力codeSHA256前'],result['入力codeSHA256後']);
  assert.deepEqual(Object.keys(result['集計']).sort(),[...KEYS].sort());assert.equal(result['場別'].length,1400);
  const sessions=[...new Set(result['場別'].map(r=>r.session))].sort();assert.equal(sessions.length,70);
  const pairs=new Map();
  for(const r of result['場別']){
    assert.ok(KEYS.includes(r.key)&&HISTORY.includes(r.history_class));
    assert.ok(/^\d{4}-\d{2}-\d{2}_(Day|Night)$/.test(r.session));
    const pair=`${r.session}/${r.key}`;assert.ok(!pairs.has(pair));pairs.set(pair,r);
    checkRow(r,r.session.endsWith('_Day')?76:148);
  }
  const out={summary:[],flags:[],daynight:[],history:[],details:[],comparisons:[],publications:[],sessions};
  for(const key of KEYS){
    const scenes=sessions.map(s=>pairs.get(`${s}/${key}`));assert.ok(scenes.every(Boolean));
    const r=result['集計'][key];checkAggregate(r,scenes);assert.equal(r['活動主表'].denom,7840);
    assert.equal(r['活動副表'].denom,7560);
    const [policy,c,d]=key.split('_'),cost=`${c}/${d}`,a=r['活動主表'];
    out.summary.push([policy,cost,null,r.gross_yen,r.fee_yen,r.slip_yen,null,r['保存点連結時価DD'],r.positions,r.entry_quantity,a.active,a.denom,null,null,null,r.unit_positive_closed_negative_yen,r.activated_closed_negative_yen,r.narrowed_positions]);
    out.flags.push([policy,cost,r.unit_positive_positions,r.unit_positive_closed_negative,r.unit_positive_closed_negative_yen,
      r.protection_activated_positions,r.activated_closed_negative,r.activated_closed_negative_yen,
      r.normal_ld10_activations,r.early_warning_activations,r.narrowed_positions,a.wait,a.unknown]);
    for(const kind of ['Day','Night']){
      const rows=scenes.filter(s=>s.session.endsWith('_'+kind)),v=result['実現診断'][key]['日夜'][kind];
      checkAggregate(v,rows);out.daynight.push(groupRow(policy,cost,LABELS[kind],v));
    }
    for(const kind of HISTORY){
      const rows=scenes.filter(s=>s.history_class===kind);assert.equal(rows.length,kind==='old104_54'?54:kind==='saved105_4'?4:12);
      const v=result['実現診断'][key]['履歴区分'][kind];checkAggregate(v,rows);out.history.push(groupRow(policy,cost,LABELS[kind],v));
    }
  }
  for(const session of sessions)for(const key of KEYS){
    const r=pairs.get(`${session}/${key}`),[policy,c,d]=key.split('_'),a=r['活動主表'];
    out.details.push([new Date(`${session.slice(0,10)}T00:00:00Z`),LABELS[session.split('_')[1]],LABELS[r.history_class],policy,`${c}/${d}`,
      r.gross_yen,r.fee_yen,r.slip_yen,null,r.positions,r.entry_quantity,a.active,a.denom,null,
      r.unit_positive_closed_negative_yen,r.activated_closed_negative_yen,r.early_warning_activations,r.narrowed_positions]);
  }
  for(const policy of ['W1','W2','E1','E2'])for(const c of [0,5])for(const d of [0,1]){
    const after=`${policy}_C${c}_D${d}`,before=`W0_C${c}_D${d}`,v=result['同実入口と実現額差'][`${after}対${before}`]['合計'];
    for(const k of ['全差額','同実入口玉','同実入口差額','取得変更玉','取得変更差額','前のみ玉','前のみ実現額','後のみ玉','後のみ実現額'])assert.ok(typeof v[k]==='number'&&Number.isFinite(v[k]),k);
    assert.equal(v['全差額'],result['集計'][after].net_yen-result['集計'][before].net_yen);
    assert.equal(v['全差額'],v['同実入口差額']+v['取得変更差額']-v['前のみ実現額']+v['後のみ実現額']);
    out.comparisons.push([after,before,v['全差額'],v['同実入口玉'],v['同実入口差額'],v['取得変更玉'],v['取得変更差額'],v['前のみ玉'],v['前のみ実現額'],v['後のみ玉'],v['後のみ実現額']]);
  }
  const publications=new Map();for(const v of result['一公表単位の役割診断']){assert.ok(!publications.has(v.session));publications.set(v.session,v);}assert.deepEqual([...publications.keys()].sort(),sessions);
  for(const session of sessions){const v=publications.get(session),history=pairs.get(`${session}/${KEYS[0]}`).history_class;
    assert.equal(typeof v.numeric_seed_carried,'boolean');
    const counts=[v.new_three,v.C_known,v.C_pass,...['buy','sell'].flatMap(side=>['M_known','M_pass','P_known','P_pass'].map(k=>v[side][k]))];assert.ok(counts.every(n=>Number.isInteger(n)&&n>=0));
    out.publications.push([new Date(`${session.slice(0,10)}T00:00:00Z`),LABELS[session.split('_')[1]],LABELS[history],v.numeric_seed_carried,...counts]);}
  return out;
}

/**
 * 日夜又は履歴の同じ列を作る。
 * @param {string} policy - 外政策名。
 * @param {string} cost - 費用/遅延名。
 * @param {string} label - 区分。
 * @param {Object} r - 保存器の区分集約。
 * @returns {Array} 数値型を保った一行。
 */
function groupRow(policy,cost,label,r){const a=r['活動主表'];return [policy,cost,label,r.net_yen,r.PF??'未定義',r['保存点連結時価DD'],r.positions,r.entry_quantity,a.active,a.denom,null,r.unit_positive_closed_negative_yen,r.activated_closed_negative_yen,r.early_warning_activations];}

/**
 * 旧4タブの値・数式・図表参照を記録する。
 * @param {Object} book - Artifact Workbook。
 * @returns {Array} 原領域の保持基準。
 */
function snapshot(book){return OLD_SHEETS.map(name=>{const s=book.worksheets.getItem(name),r=s.getUsedRange();return {name,values:r.values,formulas:r.formulas,charts:s.charts.items.map(c=>({type:c.type,title:c.title.text,series:c.series.items.map(t=>({formula:t.formula,categoryFormula:t.categoryFormula}))}))};});}

/**
 * 現ブックを読取専用で確認する。
 * @returns {Promise<void>} PNGと小さな読取確認だけ。xlsx exportとmarkerは行わない。
 */
async function review(){
  assert.equal(sha(await fs.readFile(BOOK)),BOOK_SHA);const b=await SpreadsheetFile.importXlsx(await FileBlob.load(BOOK));
  for(let i=0;i<4;i++)assert.equal(b.worksheets.getItemAt(i).name,OLD_SHEETS[i]);
  assert.throws(()=>b.worksheets.getItem(SHEET));
  const prior=snapshot(b),image=await b.render({sheetName:OLD_SHEETS[3],range:'A79:L121',scale:1,format:'png'});
  await fs.writeFile(path.join(WORK,'現在の105追記.png'),new Uint8Array(await image.arrayBuffer()));
  const v=await b.inspect({kind:'sheet',include:'id,name',maxChars:2500});await fs.writeFile(path.join(WORK,'旧4タブの確認.ndjson'),v.ndjson);
  assert.equal(sha(await fs.readFile(BOOK)),BOOK_SHA);assert.deepEqual(snapshot(b),prior);
  await fs.writeFile(path.join(WORK,'読取確認.json'),JSON.stringify({'成功':true,'ブックSHA256':BOOK_SHA,'旧4タブ':OLD_SHEETS,'xlsx編集_export_marker':0,'106市場本文読取':0},null,2));
}

/**
 * FileRefのSHAを確認して小JSONを読む。
 * @param {Object} ref - path/sha256。
 * @param {string} base - 固定JSON基準。
 * @param {Map} inputs - 前指紋。
 * @param {boolean} json - JSON復号の有無。コードFileRefはfalse。
 * @returns {Promise<Object>} 値と絶対位置とSHA。
 */
async function readRef(ref,base,inputs,json=true){assert.ok(ref&&typeof ref.path==='string'&&/^[0-9a-f]{64}$/.test(ref.sha256));const p=path.resolve(base,ref.path),b=await fs.readFile(p);assert.equal(sha(b),ref.sha256);inputs.set(p,ref.sha256);return {path:p,sha256:ref.sha256,value:json?JSON.parse(b.toString('utf8').replace(/^\uFEFF/,'')):null};}

/**
 * Rootの金融・保存・Viewer成功後の事後固定だけを許可する。
 * @param {string} fixedPath - 固定JSON。
 * @param {string} fixedSHA - そのSHA。
 * @returns {Promise<Object>} 検査済み入力と表示配列。
 */
async function readFixed(fixedPath,fixedSHA){
  const inputs=new Map(),f=await readRef({path:fixedPath,sha256:fixedSHA},'.',inputs),x=f.value;
  assert.equal(x.version,1);assert.equal(x.trial,106);assert.equal(x.fixed,true);
  for(const k of ['result_ready','financial_checked','saved_checked','viewer_checked'])assert.equal(x[k],true);
  const refs={};for(const k of ['code','summary','financial_completion','saved_check','viewer_evidence'])refs[k]=await readRef(x[k],path.dirname(f.path),inputs,k!=='code');
  assert.equal(refs.code.path,path.resolve(import.meta.filename));
  const fin=refs.financial_completion.value,saved=refs.saved_check.value,result=refs.summary.value;
  assert.ok(fin.version===1&&fin.trial===106&&fin.stage==='full70'&&fin.success&&fin.sessions===70&&fin.books===1400&&fin.books_per_scene===20&&fin.unchanged);
  assert.deepEqual(fin.before,fin.after);assert.equal(saved['成功'],true);assert.equal(saved['会計'],1400);assert.equal(saved['不一致数'],0);
  assert.equal(saved.completionSHA256,refs.financial_completion.sha256);assert.equal(saved['出力SHA256']['結果.json'],refs.summary.sha256);
  assert.equal(result.completionSHA256,refs.financial_completion.sha256);
  assert.ok(refs.viewer_evidence.value['成功']===true||refs.viewer_evidence.value.success===true);
  assert.ok(typeof x.viewer_scope==='string'&&x.viewer_scope.trim());
  return {inputs,refs,fixed:x,tables:prepareTables(result)};
}

/**
 * 第五タブの指定範囲だけを作る。事前markerはRootが直前に一度実行する。
 * @param {string} fixedPath - Root事後固定。
 * @param {string} fixedSHA - 実SHA。
 * @returns {Promise<void>} 同じxlsxへ一回export。Rootの別途実編集指示が前提。
 */
async function append(fixedPath,fixedSHA){
  const v=await readFixed(fixedPath,fixedSHA);assert.equal(sha(await fs.readFile(BOOK)),BOOK_SHA);
  const b=await SpreadsheetFile.importXlsx(await FileBlob.load(BOOK)),prior=snapshot(b);assert.throws(()=>b.worksheets.getItem(SHEET));
  await fs.writeFile(path.join(WORK,'106追記前.xlsx'),await fs.readFile(BOOK),{flag:'wx'});
  const s=b.worksheets.add(SHEET);s.showGridLines=false;s.tabColor='#23354D';s.freezePanes.freezeRows(5);
  s.getRange('A1:R1667').format.font={name:'Arial',size:10,color:'#202A35'};s.getRange('A1:R1667').format.rowHeight=24;
  s.getRange('A1:R1667').format.verticalAlignment='center';s.getRange('A1:R1').format.columnWidth=15;
  s.getRange('A1').format.columnWidth=14;s.getRange('C1').format.columnWidth=20;
  s.getRange('A2:R2').merge();s.getRange('A2').values=[['収束・失速で保護の起動と幅を切り替える 106']];s.getRange('A2').format.font={name:'Arial',size:15,bold:true,color:'#23354D'};
  s.getRange('A3:R3').merge();s.getRange('A3').values=[['既使用70場・20政策感度。既存58場の旧保存対照と追加12場の同入力旧Actor対照を区別。']];
  const defs=[
    ['summary',['政策','費用/遅延','純損益（円）','粗額（円）','手数料（円）','仮定滑り（円）','取引PF','保存点DD','玉数','取得枚数','活動枠','主分母','参加率','最低25%','目標50%','u後赤字額','起動後赤字額','狭幅玉数']],
    ['flags',['政策','費用/遅延','u正益玉','u後赤字玉','u後赤字額','保護起動玉','起動後赤字玉','起動後赤字額','通常LD10起動','早期起動','狭幅玉数','待機枠','不能枠']],
    ['daynight',['政策','費用/遅延','日夜','純損益（円）','取引PF','保存点DD','玉数','取得枚数','活動枠','主分母','参加率','u後赤字額','起動後赤字額','早期起動']],
    ['history',['政策','費用/遅延','履歴区分','純損益（円）','取引PF','保存点DD','玉数','取得枚数','活動枠','主分母','参加率','u後赤字額','起動後赤字額','早期起動']],
    ['details',['開始日','日夜','履歴区分','政策','費用/遅延','粗額（円）','手数料（円）','仮定滑り（円）','純損益（円）','玉数','取得枚数','活動枠','主分母','参加率','u後赤字額','起動後赤字額','早期起動','狭幅玉数']],
    ['comparisons',['変更後','W0対照','全差額（円）','同実入口玉','同実入口差額','取得変更玉','取得変更差額','W0のみ玉','W0のみ実額','変更後のみ玉','変更後のみ実額']],
    ['publications',['開始日','日夜','履歴区分','数値種carry','新3分公表','C既知','C成立','買M既知','買M成立','買P既知','買P成立','売M既知','売M成立','売P既知','売P成立']]
  ];
  for(const [kind,headers]of defs){const start=LAYOUT[kind==='details'?'detail':kind],data=v.tables[kind],col=String.fromCharCode(64+headers.length),header=s.getRange(`A${start-1}:${col}${start-1}`);header.values=[headers];header.format={fill:'#23354D',font:{name:'Arial',size:10,bold:true,color:'#FFFFFF'},wrapText:true,rowHeight:40,horizontalAlignment:'center'};s.getRange(`A${start}:${col}${start+data.length-1}`).values=data;}
  const money='#,##0.0;[Red](#,##0.0);0';s.getRange('C6:R25').setNumberFormat(money);s.getRange('G6:G25').setNumberFormat('0.00');s.getRange('I6:L25').setNumberFormat('#,##0');s.getRange('R6:R25').setNumberFormat('#,##0');
  for(let i=0;i<20;i++){const n=6+i;s.getRange(`C${n}`).formulas=[[`=D${n}-E${n}-F${n}`]];s.getRange(`G${n}`).values=[[v.refs.summary.value['集計'][KEYS[i]].PF??'未定義']];s.getRange(`M${n}`).formulas=[[`=K${n}/L${n}`]];s.getRange(`N${n}`).formulas=[[`=IF(M${n}>=25%,"達成","未達")`]];s.getRange(`O${n}`).formulas=[[`=IF(M${n}>=50%,"達成","未達")`]];}
  s.getRange('M6:M25').setNumberFormat('0.00%');
  s.getRange('C32:M51').setNumberFormat('#,##0');s.getRange('E32:E51').setNumberFormat(money);s.getRange('H32:H51').setNumberFormat(money);
  for(const [kind,count]of [['daynight',40],['history',60]]){const start=LAYOUT[kind];s.getRange(`D${start}:N${start+count-1}`).setNumberFormat(money);s.getRange(`E${start}:E${start+count-1}`).setNumberFormat('0.00');s.getRange(`G${start}:J${start+count-1}`).setNumberFormat('#,##0');for(let n=start;n<start+count;n++)s.getRange(`K${n}`).formulas=[[`=I${n}/J${n}`]];s.getRange(`K${start}:K${start+count-1}`).setNumberFormat('0.00%');}
  s.getRange('A170:A1569').setNumberFormat('yyyy-mm-dd');s.getRange('F170:R1569').setNumberFormat(money);s.getRange('J170:M1569').setNumberFormat('#,##0');s.getRange('Q170:R1569').setNumberFormat('#,##0');s.getRange('N170:N1569').setNumberFormat('0.00%');
  for(let n=170;n<1570;n++){s.getRange(`I${n}`).formulas=[[`=F${n}-G${n}-H${n}`]];s.getRange(`N${n}`).formulas=[[`=L${n}/M${n}`]];}
  s.getRange('C1576:K1591').setNumberFormat(money);for(const col of ['D','F','H','J'])s.getRange(`${col}1576:${col}1591`).setNumberFormat('#,##0');
  s.getRange('A1598:A1667').setNumberFormat('yyyy-mm-dd');s.getRange('E1598:O1667').setNumberFormat('#,##0');
  const notes=['W0=LD10後2ATR、W1=C&Mで1ATR、W2=C&M&Pで1ATR。E1/E2は警戒と低い正益閾値で早期起動。',
    '片道手数料38.5円。C5は片道5pt仮定滑り、D1は1秒遅延。名目建値床は費用後黒字を保証せず、二旗と保存点DDは別。',
    '主7840枠。開始30分後〜Force未満、静観・欠測も分母へ残す。最低25%と目標50%は日夜も別確認。',
    '先頭cold・同限月numeric継承。70場は既使用であり、費用4感度や20政策を独立市場標本とはしない。',
    'Source・入口・数量を固定し、同実入口差と取得変更を分ける。機会損失・退出後利益・MFE回収は算出しない。',
    `Viewer確認範囲：${v.fixed.viewer_scope}`,`正本：${path.relative(ROOT,v.refs.summary.path).replaceAll('\\','/')}`,`正本SHA256：${v.refs.summary.sha256}`];
  for(let i=0;i<notes.length;i++){const n=[27,28,29,52,53,99,164,165][i];s.getRange(`A${n}:R${n}`).merge();s.getRange(`A${n}`).values=[[notes[i]]];s.getRange(`A${n}:R${n}`).format.wrapText=true;s.getRange(`A${n}:R${n}`).format.rowHeight=27;}
  b.recalculate();assert.deepEqual(snapshot(b),prior);
  for(let i=0;i<20;i++)assert.equal(s.getRange(`C${i+6}`).values[0][0],v.refs.summary.value['集計'][KEYS[i]].net_yen);
  for(const [range,name]of [['A2:R25','106全20.png'],['A31:M51','106二旗.png'],['A57:N77','106日夜先頭.png'],['A103:N123','106履歴先頭.png'],['A169:R183','106場別先頭.png'],['A1575:K1591','106同実入口差.png'],['A1597:O1612','106一公表診断.png']]){const im=await b.render({sheetName:SHEET,range,scale:1,format:'png'});await fs.writeFile(path.join(WORK,name),new Uint8Array(await im.arrayBuffer()));}
  const errors=await b.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:100},maxChars:4000});await fs.writeFile(path.join(WORK,'106式検査.ndjson'),errors.ndjson);
  for(const [p,h]of v.inputs)assert.equal(sha(await fs.readFile(p)),h);
  await(await SpreadsheetFile.exportXlsx(b)).save(BOOK);const saved=await SpreadsheetFile.importXlsx(await FileBlob.load(BOOK));assert.deepEqual(snapshot(saved),prior);
  await fs.writeFile(path.join(WORK,'106追記の確認.json'),JSON.stringify({'成功':true,'入力ブックSHA256':BOOK_SHA,'最終ブックSHA256':sha(await fs.readFile(BOOK)),'新タブ':SHEET,'旧4tab値_式_図参照保持':true,'全旧セル書式と構造OOXML保持':'別の保存後QA必須','入力SHA256':Object.fromEntries(v.inputs)},null,2));
}

// ----------------------------------------
// 準備中の既定動作は純importだけで、実入力を探索しない。
if(process.argv.includes('--review'))await review();
else if(process.argv.includes('--append')){const i=process.argv.indexOf('--append');await append(process.argv[i+1],process.argv[i+2]);}
