# 106のxlsx第五タブ追記準備

106市場金融・保存・Viewer成功後にだけ使う事後コード。今回はスプレッドシートskill全体・編集workflow・Artifact API・style・科学研究guidanceを読み、105停止builder `9235b992b95be3738d913e5df9cc3742bdb9d1afac4f00e75cd98b177c109ba9` を参考に別領域へ用意した。旧コード・市場入力・停止元は変更しない。

対象は既存単一 `outputs/01a1889f-f2af-7943-a047-543275ee9ed2/元アルゴリズムと現行代表候補の損益比較.xlsx`。現SHA256は `298fe652463db911177f8fa359240d7ff0f0b1e4bf804c4b155fedd55fbd03a9`。旧4タブと105のA79:L121を含む全既存セル・式・書式・図表を保持し、第五タブ `収束早期保護106` だけを追加する。原xlsxの新しい別名は増やさない。

|新タブの範囲|内容|
|---|---|
|A5:R25|W0/W1/W2/E1/E2×四感度の20集計。実額・費用・PF・保存点DD・枚数・主参加と25%/50%|
|A31:M51|u初正益後と保護起動後の赤字を別記。通常LD10・早期起動・狭幅・待機・不能|
|A57:N97|日夜別40集計|
|A103:N163|旧104の54・105の4・追加12の60集計|
|A169:R1569|70場×20の1400場別。開始日/日夜/履歴/政策/費用を同じ行へ保持|
|A1575:K1591|W1/W2/E1/E2対W0の16比較。同実入口差・取得変更・片側実参加を分離|
|A1597:O1667|一公表単位の70場診断。C/M/P既知/成立と数値種carry。20感度へ重複加算しない|

主7840・副7560の分母を保存結果へ照合する。表示の主率は活動枠/主分母。日夜・履歴のDDは保存器が連結した既存値を使い、場内DDの最大値や単純合計へ置き換えない。履歴区分は正本 `history_class` を使い、IDから旧goldenを推測しない。既存58場と新12場の対照方法を分ける。金額は半円を失わない数値型、日付はDate、PF未定義は「未定義」であり黒字安定の表示にしない。政策や費用感度を独立市場標本として加算しない。機会損失・退出後価格・MFE回収は使用しない。

## 準備段階の確認

- `--review` は既存ブックのimport/inspect/renderだけ。105追記のPNGを視認し、旧4タブ11,760セルと図表8部品の基準を読取専用OOXMLで保存した。
- 純入力人工は手製70場×20設定。自然Source・金融の実行結果を補完せず、集計20/二旗20/日夜40/履歴60/場別1400・比較16・公表70の形と算術、半円、無取引PF、欠測分母、14破損拒否を検査した。
- 新タブの実export/新renderは未実施。marker・ブック編集は行っていない。Root許可後にfirst2保存の結果・保存確認だけを欄名と型確認へ読み、全70の途中結果・Native・価格は読まない。結果を70場成功として補完しない。
- `@oai/artifact-tool` はloader cacheの `dependencies/node/node_modules` をこのworkのjunctionで参照する。著作にrepo-local別libraryを使わない。Pythonは既存103の読取専用OOXML関数を直接再用し、xlsx著作は行わない。

## 将来のRoot実行

金融・保存・Viewerの検証後、[雛形](実行固定の雛形.json)を**別のRoot実行固定JSON**へ保存する。全ready/checked/fixedを真にし、自己コード・保存結果・金融完了・保存確認・Viewer証拠の5FileRefへ実SHAを入れる。参照は固定JSONのdir基準。Viewerの `viewer_scope` は実際の検査範囲を記し、代表資源の確認を全1400 API成功へ広げない。

金融70場/20/1400・同じ前後SHA、保存1400差0・金融完了SHAと結果SHA、保存結果の70×20全一意集合・履歴54/4/12・二旗と日夜区分を確認してから編集に進む。Rootが別途実編集を指示するまで実行しない。

最初の編集コマンド直前にskillのmarkerをedit/1xlsxとして**一度だけ**成功実行する。今回は未実行。

```powershell
& 'C:/Users/masay/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe' `
  'C:/Users/masay/.cache/codex-runtimes/codex-primary-runtime/plugins/openai-primary-runtime/plugins/spreadsheets/skills/spreadsheets/container_tools/mark_artifact_operation_started.mjs' `
  --operation-kind edit --expected-output-count 1 --output-format xlsx

& 'C:/Users/masay/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe' `
  'work/106xlsx追記の準備/106を追記する.mjs' --append '<Root事後固定.json>' '<そのSHA256>'
```

旧ブックはworkの `106追記前.xlsx` へ同bytes退避し、新タブだけをArtifactで作る。recalculate・式検査・影響範囲render・旧値/式/図表参照確認後に同じ出力xlsxへexportする。その後、次の全旧セル/式/型/スタイル/構造・図表・旧スタイル定義・正本値照合を必須とする。

```powershell
& 'work/venvs/technical-tree/Scripts/python.exe' -B -X utf8 `
  'work/106xlsx追記の準備/保存後を確認する.py' `
  --source '<106結果.json>' --source-sha '<そのSHA256>' --out '<新規106保存後QA.json>'
```

新しい7画像の視認と保存後QAまで通る前に完了とはしない。差があれば検査を緩めずRootへ返す。Artifactの再計算・PNGをExcel本体での実行証明とはしない。原板・Tape・Native・金融・Source・Viewer APIをこのコードから再実行しない。

読取だけの再確認は `106を追記する.mjs --review`、純型人工は `純入力を検査する.mjs`。どちらもmarkerを呼ばずxlsxをexportしない。
