/**
 * 106表示用の集計射影を手製の70場20設定で検査する。
 * 引数: なし。実市場の損益・Native・原板を読まない。
 * 返り値: Promise<void>。xlsx作成/編集/markerは実行しない。
 */
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {prepareTables,KEYS} from './106を追記する.mjs';
const ROOT=path.resolve(import.meta.dirname,'../..');
const meta=JSON.parse(await fs.readFile(path.join(ROOT,'work/106入力と既存Sourceの整理/標準入力台帳_70場_候補.json'),'utf8'));

/**
 * 価格形成を伴わない保存集約型を作る。
 * @param {string} session - 既知metadataの場ID。
 * @param {string} key - 外20key。
 * @param {string} history - 履歴区分。
 * @returns {Object} 半円・待機・欠測・無取引を含む手製値。
 */
function row(session,key,history){
 const empty=key==='W2_C5_D1',cost=Number(key.split('_')[1].slice(1)),denom=session.endsWith('_Day')?76:148;
 const gross=empty?0:2000,fee=empty?0:77,slip=empty?0:cost*200,net=gross-fee-slip,positive=empty?0:2500.5;
 return {session,key,history_class:history,width_policy:key.split('_')[0],gross_yen:gross,fee_yen:fee,slip_yen:slip,net_yen:net,
  positive_yen:positive,negative_yen:net-positive,positions:empty?0:2,entry_quantity:empty?0:2,
  unit_positive_positions:empty?0:2,unit_positive_closed_negative:empty?0:1,unit_positive_closed_negative_yen:empty?0:-38.5,
  protection_activated_positions:empty?0:1,activated_closed_negative:empty?0:1,activated_closed_negative_yen:empty?0:-38.5,
  normal_ld10_activations:empty?0:1,early_warning_activations:empty?0:Number(key.startsWith('E')),narrowed_positions:empty?0:Number(!key.startsWith('W0')),
  '活動主表':{denom,new:empty?0:2,hold:empty?0:3,active:empty?0:5,wait:denom-(empty?0:5)-1,unknown:1}};
}

/**
 * 加算可能な型だけを合計しDDを手製宣言として区別する。
 * @param {Object[]} rows - 型人工の場別。
 * @returns {Object} 全体又は区分の保存集約型。
 */
function combine(rows){
 const v={};for(const f of Object.keys(rows[0]))if(typeof rows[0][f]==='number')v[f]=rows.reduce((s,r)=>s+r[f],0);
 v['活動主表']={};for(const f of ['denom','new','hold','active','wait','unknown'])v['活動主表'][f]=rows.reduce((s,r)=>s+r['活動主表'][f],0);
 v['保存点連結時価DD']=123.5;v.PF=v.negative_yen<0?v.positive_yen/-v.negative_yen:null;return v;
}

/**
 * 手製値を正式保存と同じ外20/履歴/日夜型へ並べる。
 * @returns {Object} 自然Source/金融成功を表さない人工。
 */
function fixture(){
 const r={'試行':106,'成功':true,stage:'full70','場数':70,'会計数':1400,'前後不変':true,'入力codeSHA256前':{},'入力codeSHA256後':{},'集計':{},'実現診断':{},'場別':[],'同実入口と実現額差':{},'一公表単位の役割診断':[],'scope':'手製保存集約の型人工。実金融再生と市場結果ではない'};
 for(const key of KEYS){const rows=meta.sessions.map((s,i)=>row(s.id,key,i<54?'old104_54':i<66?'fresh106_12':'saved105_4'));r['場別'].push(...rows);r['集計'][key]=combine(rows);r['集計'][key]['活動副表']={denom:7560};r['実現診断'][key]={'日夜':{},'履歴区分':{}};
  for(const k of ['Day','Night'])r['実現診断'][key]['日夜'][k]=combine(rows.filter(s=>s.session.endsWith('_'+k)));
  for(const k of ['old104_54','saved105_4','fresh106_12'])r['実現診断'][key]['履歴区分'][k]=combine(rows.filter(s=>s.history_class===k));}
 for(const p of ['W1','W2','E1','E2'])for(const c of [0,5])for(const d of [0,1]){const a=`${p}_C${c}_D${d}`,b=`W0_C${c}_D${d}`,empty=a==='W2_C5_D1',diff=r['集計'][a].net_yen-r['集計'][b].net_yen;
  r['同実入口と実現額差'][a+'対'+b]={'合計':{'全差額':diff,'同実入口玉':empty?0:140,'同実入口差額':0,'取得変更玉':0,'取得変更差額':0,'前のみ玉':empty?140:0,'前のみ実現額':empty?-diff:0,'後のみ玉':0,'後のみ実現額':0}};}
 r['一公表単位の役割診断']=meta.sessions.map((s,i)=>({session:s.id,new_three:10,C_known:7,C_pass:5,buy:{M_known:8,M_pass:3,P_known:5,P_pass:1},sell:{M_known:8,M_pass:4,P_known:6,P_pass:2},numeric_seed_carried:i>0}));
 return r;
}
const input=fixture(),prior=JSON.stringify(input),out=prepareTables(input);
assert.deepEqual([out.summary.length,out.flags.length,out.daynight.length,out.history.length,out.details.length],[20,20,40,60,1400]);
assert.equal(out.comparisons.length,16);assert.equal(out.publications.length,70);
assert.equal(JSON.stringify(input),prior);assert.equal(input['集計'].W2_C5_D1.PF,null);assert.equal(out.flags[0][4],-2695);
let rejected=0;
for(const mutate of [
 x=>x.stage='first2',x=>x['会計数']=1399,x=>x['場別'].pop(),x=>x['場別'][1]=structuredClone(x['場別'][0]),
 x=>x['場別'][0].history_class='old_saved_58',x=>x['集計'][KEYS[0]].net_yen++,x=>delete x['集計'][KEYS[0]].early_warning_activations,
 x=>x['場別'][0]['活動主表'].denom=72,x=>x['場別'][0]['活動主表'].unknown=0,x=>x['集計'][KEYS[0]].PF=null,
 x=>x['実現診断'][KEYS[0]]['履歴区分'].saved105_4.net_yen++,x=>x['集計'][KEYS[0]]['活動副表'].denom=7840,
 x=>x['同実入口と実現額差'].W1_C0_D0対W0_C0_D0['合計']['全差額']++,x=>x['一公表単位の役割診断'][1]=structuredClone(x['一公表単位の役割診断'][0])
]){const x=fixture();mutate(x);assert.throws(()=>prepareTables(x));rejected++;}
const proof={'成功':true,'scope':'手製の保存集約型だけ。市場損益/価格/金融形成なし','20集計':20,'日夜':40,'履歴区分':60,'場別':1400,'同実入口差':16,'一公表診断':70,'半円':true,'無取引PF未定義':true,'欠測を分母保持':true,'元入力不変':true,'破損拒否':rejected,'xlsx編集_export_marker':0,'106市場本文読取':0};
await fs.writeFile(path.join(import.meta.dirname,'純入力の人工確認.json'),JSON.stringify(proof,null,2)+'\n');console.log(JSON.stringify(proof));
