"""固定80の数値本文へ閉じた足の公開証跡だけを機械的に追加する。"""
from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
SOURCE = ROOT / "scripts/FAR後期15分移植/technical.go"
raw = SOURCE.read_text(encoding="utf-8-sig")
text = raw.replace("package far80\n", "package publicchart\n", 1)
anchor = "\tpublished                         bool\n"
assert text.count(anchor) == 1
text = text.replace(anchor, anchor + "\tclosed                            numericClosed\n", 1)
anchor = "\t*b = formingBar{start: end, width: b.width}\n"
assert text.count(anchor) == 1
addition = """\t// ----------------------------------------
\t// 既存計算の確定後、reset前の同じ形成値を公開用証跡へ写すだけです。
\tseries.closed = numericClosed{Start: b.start, End: end, Rows: b.count, Known: b.count > 0 && !b.bad}
\tif series.closed.Known {
\t\tseries.closed.Open, series.closed.High, series.closed.Low, series.closed.Close = b.open, b.high, b.low, b.close
\t}
"""
text = text.replace(anchor, addition + anchor, 1)
out = OWN / "numeric.go"
if out.exists():
    raise FileExistsError(out)
out.write_text(text, encoding="utf-8")
(OWN / "数値器の派生差分.patch").write_text("\n".join(difflib.unified_diff(raw.splitlines(), text.splitlines(), fromfile="固定80/technical.go", tofile="公開派生/numeric.go", lineterm="")) + "\n", encoding="utf-8")
pins = {SOURCE.relative_to(ROOT).as_posix(): hashlib.sha256(SOURCE.read_bytes()).hexdigest()}
(OWN / "派生時の根拠.json").write_text(json.dumps({"元SHA256": pins, "許可差": ["package名", "technicalSeries.closed値型追加", "formingBar確定後のOHLC写しのみ"], "数値式変更": 0, "Source金融": 0}, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
