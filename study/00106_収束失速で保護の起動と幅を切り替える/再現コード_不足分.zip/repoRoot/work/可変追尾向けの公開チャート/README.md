# 可変追尾へ供給する3分公開欄の非市場派生

module `github.com/masayoshi4649/SessionTradeExecuter/publicchart`、package `publicchart`。既存module・103/104・SourceAプロセスは変更しない。Source/金融/LD10/入口へは未接続。新試行は採番しない。

## 構成と変更範囲

停止済み `chartwarmup96` を直接呼ぶwrapperを権威値とし、旧 `Snapshot` 全fieldを `Snapshot.Legacy` に同体で残す。時計・公表・grid・原行順を別の実装で生成しない。

旧公開APIでは3分EMA8/21の個別Knownと確定OHLCを取り出せない。そのため固定80 `technical.go` を機械派生した `numeric.go` を同じQuoteと旧publication時計で並走する。追加は値型の閉足証跡と、元 `formingBar.advance` の確定後・reset前の同じOHLCを写す処理だけ。EMA/RSI/MACD/ATR、半開区間集約、欠足reset・初期SMA/暖機の計算本文は変えない。名前付き `TechnicalView` を元型へ明示変換し、各publication・grid・After・Snapshot・Sealで旧TechnicalView全文と一致しなければerrorにする。

これはprivate状態をreflectionで読む方法でも、Knownを本数/0非0から推定する方法でもない。派生数値器の同じprivate `.known` を読み出す。技法は二つの器で同じ式を計算するため、処理性能が改善したという主張はしない。生成scriptと[派生差分](数値器の派生差分.patch)、整形後の元計算復元証拠を残す。

## 公開APIと型

- `New(Scene,*Seed) (*Bank,error)`。Scene/Quoteは元公開型と同一。Seedはこのwrapper自身のSealからだけ得られるprivateなメモリ種。
- `Step(Quote,[]float64)` / `AdvanceObserved(float64,[]float64) (Batch,error)`。Batchは全publication、全grid、Afterを返す。
- `Snapshot() (Snapshot,error)`、`Seal() (Seed,Snapshot,error)`。Sealは観測時計を進めず形成足を締めない。
- 新 `Snapshot={legacy:旧warm.Snapshot,closed_three:追加3分証跡}`。元JSONの形へ盲目的に上書きせず、既存値と追加欄を分けた別入力版である。
- `closed_three` は `publication_id={session,contract,bar_end}`、`bar_start/bar_end/available_at/observed_clock`、`known`、`ema8_known/ema21_known/histogram_known/previous_histogram_known`、`ohlc={open,high,low,close}`、`raw_rows/valid_last_rows`、`has_last_source/last_source(Time,Index,Line,Last,Valid)`、`invalidated_at`。
- publicationは同じID、旧At/Three/Fifteen、場内 `publication_ordinal`、新Snapshotを持つ。全入力streamの配送ordinalは将来のsidecar保存adapter側の責務であり、このbankの公表番号と混同しない。

`Known`は元の「非空かつ不良Lastを含まない足」の契約であり、全時刻の連続受信やBBO品質を保証する値ではない。Last0直後は私有指標と閉足既知性もresetされ、古い良足を復活させない。空足・不良足でOHLCは未知、0を実価格として使わない。RawRowsには旧Evidenceの全入力行数、ValidLastRowsには形成器の有効Last数を記録する。両者が不良足で異なる場合を同じ数量と解釈しない。

## 公表時計と持越し

経路は **原行NK Last→当場起点の半開3/15分OHLC→固定指標→論理timer公表**。CSV1/5分をこの数値器へ流さず、Scalar11からEMA等を補完しない。旧warmが返したpublicationだけを一度ずつ配送し、同じ5分Snapshotを3本の新公表と数えない。

AvailableAtは旧論理公表時計、ObservedClockはそのtimerをdrainした入力価格時計の証跡で、後者が前者より後でも正常。実受信時刻やリアルタイム約定可能時刻と呼ばない。同秒timer→grid→rawの順で、境界rawの価格は新形成足へ入り、閉じた足へ混ぜない。TOPIX等でclockを進める呼出側の旧順序は変更しない。

同限月のSeedは旧sealed種と同時点の派生数値種だけを継承する。場頭では旧どおり形成足・公開maskを初期化する。限月rollでは双方数値を初期化。SeedはJSON永続化できず、既存の旧Seedだけをこの追加器の完全状態へ復元するAPIもない。新部品は助走から同じ入力を受ける必要がある。

## C/M/Pと金融への境界

停止純式 [4a30](../収束可変幅の公開側データ準備/停止.json) へ、旧Publication部分と追加個別Known/OHLCを明示的に渡す型接続人工を用意した。C/M/Pの論理やpivotをこのmoduleへ複写しない。左右2本の中心/確認/公表IDは純式側で生成し、当足Pを旧最新pivotで評価してから当足が新たに確認したpivotを登録する。

実Go型接続で、元ChartViewのJSONは無tagの `chart.Technical`、4a30の手製正規型は `chart.technical` だったことを確認した。新bridgeだけで既知1fieldを明示的に値copyしてからFrameへ渡す。元Go Legacy/4a30の停止本文・数値・時計は変更せず、この型対応を純式の数値形成証明とは呼ばない。

3分連続3本/欠測reset/同公表反復の扱い、15分は背景のみ、LD10起動後だけ、狭幅状態の保持、床非緩和、Source既予約優先・未予約残・同原行fill禁止は将来のconsumer側の要件。ここでは幅・床・注文・数量を計算しない。

## 人工と限界

非0の手製120足で旧全publication/全Snapshot・同秒grid・After、EMA8/21別暖機、OHLC高安終値を照合する。別人工で同秒別原行、Last0、空足、gap、ObservedClock後、Seal先締め禁止、部分暖機Seed/roll/分岐非共有を確認する。手製12公表をGo型Marshalし、既存純式へ買売対称で接続、5本目の当足Pは未知・6本目に既確認pivotの喪失となることを確認する。

```powershell
Set-Location '<repo>/work/可変追尾向けの公開チャート'
go test -v ./...
go vet ./...
go build ./...
# 明示的な型exportは新規dirのみ
$env:CHART_PUBLIC_EXPORT='<新規型人工dir>'
go test -v -run TestPublicTypeExport ./...
```

Raw/CSV/市場Tape/Native/価格sidecar本文は開かず、Source/金融・市場は運転していない。これは人工範囲での公開型と計算対応で、全54場の一致・市場品質・Source形成・LD10金融適用・新収益・機会損失評価の証明ではない。途中不一致error後に同じbankを継続利用しない。Rootが後に入力/コードを固定して市場接続する工程は別である。
