package publicchart

import (
	"encoding/json"
	"math"
	"os"
	"path/filepath"
	"reflect"
	"testing"

	warm "github.com/masayoshi4649/SessionTradeExecuter/chartwarmup96"
)

// equalBatch は公表・grid・Afterの旧全fieldが独立旧器と同体か調べます。
//
// 引数: t(*testing.T)、got(Batch)、want(warm.Batch)は新旧の同じAPI操作後です。
// 返り値: なし。違いがあれば人工を失敗させます。
func equalBatch(t *testing.T, got Batch, want warm.Batch) {
	t.Helper()
	if len(got.Publications) != len(want.Publications) || len(got.Grids) != len(want.Grids) || !reflect.DeepEqual(got.After.Legacy, want.After) {
		t.Fatal("旧Batch全値差")
	}
	for i, p := range got.Publications {
		q := want.Publications[i]
		if p.At != q.At || p.Three != q.Three || p.Fifteen != q.Fifteen || !reflect.DeepEqual(p.Snapshot.Legacy, q.Snapshot) {
			t.Fatal("旧公表全値差")
		}
	}
	for i, s := range got.Grids {
		if !reflect.DeepEqual(s.Legacy, want.Grids[i]) {
			t.Fatal("旧grid全値差")
		}
	}
}

// stepBoth は明示Quoteだけを新旧器へ一度ずつ配送します。
//
// 引数: t(*testing.T)、a(*Bank)、b(*warm.Bank)、q(Quote)、grids([]float64)です。
// 返り値: Batchは全値一致を確認した新出力です。
func stepBoth(t *testing.T, a *Bank, b *warm.Bank, q Quote, grids []float64) Batch {
	t.Helper()
	x, e := a.Step(q, grids)
	if e != nil {
		t.Fatal(e)
	}
	y, e := b.Step(q, grids)
	if e != nil {
		t.Fatal(e)
	}
	equalBatch(t, x, y)
	return x
}

// TestWarmupAllFieldsAndOHLC は手製120足で非0の全旧値と高安を確認します。
//
// 引数: t(*testing.T)は人工器です。
// 返り値: なし。3分EMA個別Knownは15分準備前にも観測します。
func TestWarmupAllFieldsAndOHLC(t *testing.T) {
	scene := Scene{ID: "人工Day", Contract: "人工限月", Start: 1000}
	a, _ := New(scene, nil)
	b, _ := warm.New(scene, nil)
	expected := map[int]OHLC{}
	pubs := 0
	for i := 0; i < 720; i++ {
		at, price := scene.Start+float64(i)*30, 1000+float64(i)/10+5*math.Sin(float64(i)/9)
		grids := []float64{}
		if i%10 == 0 {
			grids = append(grids, at)
		}
		x := stepBoth(t, a, b, Quote{Time: at, Index: int64(i), Line: int64(i + 1), Last: price, Bid: price - 1, Ask: price + 1, Valid: true}, grids)
		for _, p := range x.Publications {
			j := int((p.At-scene.Start)/180) - 1
			c := p.Snapshot.Three
			if !c.Known || c.OHLC != expected[j] || c.ValidLastRows != 6 || c.RawRows != 6 || c.LastSource.Time >= p.At || c.AvailableAt != p.At || c.BarEnd != p.At {
				t.Fatalf("手製OHLC/出典差: bar%d %+v", j, c)
			}
			if c.EMA8Known != (j >= 7) || c.EMA21Known != (j >= 20) {
				t.Fatalf("個別EMA準備差: bar%d", j)
			}
			if j == 20 && p.Snapshot.Legacy.Chart.Technical.TrendKnown {
				t.Fatal("15分準備前の3分Knownを区別できない")
			}
			pubs++
		}
		j := i / 6
		o, exists := expected[j]
		if !exists {
			o = OHLC{price, price, price, price}
		} else {
			o.High, o.Low, o.Close = math.Max(o.High, price), math.Min(o.Low, price), price
		}
		expected[j] = o
	}
	x, e := a.AdvanceObserved(scene.Start+21600, nil)
	if e != nil {
		t.Fatal(e)
	}
	y, _ := b.AdvanceObserved(scene.Start+21600, nil)
	equalBatch(t, x, y)
	if pubs != 119 || len(x.Publications) != 1 || x.Publications[0].Snapshot.Three.OHLC != expected[119] || !x.After.Legacy.Chart.Technical.TrendKnown || !x.After.Three.HistogramKnown || !x.After.Three.PreviousHistKnown {
		t.Fatal("非0暖機/最終公表不足")
	}
}

// TestBoundaryGapAndInvalidLast は同秒先公表・空足・不良失効・未来先締め禁止を確認します。
//
// 引数: t(*testing.T)は人工器です。
// 返り値: なし。ObservedClockの後値を当足へ混ぜません。
func TestBoundaryGapAndInvalidLast(t *testing.T) {
	scene := Scene{ID: "人工Day", Contract: "人工限月", Start: 1000}
	a, _ := New(scene, nil)
	b, _ := warm.New(scene, nil)
	stepBoth(t, a, b, Quote{Time: 1001, Index: 0, Line: 1, Last: 100, Valid: true}, nil)
	x := stepBoth(t, a, b, Quote{Time: 1180, Index: 1, Line: 2, Last: 900, Valid: true}, []float64{1180})
	if x.Publications[0].Snapshot.Three.OHLC.Close != 100 || x.Grids[0].Three.OHLC.High != 100 {
		t.Fatal("同秒rawが閉足へ混入")
	}
	x = stepBoth(t, a, b, Quote{Time: 1180, Index: 2, Line: 3, Last: 901, Valid: true}, nil)
	if len(x.Publications) != 0 {
		t.Fatal("同秒別原行で再公表")
	}
	x = stepBoth(t, a, b, Quote{Time: 1181, Index: 3, Line: 4, Last: 0, Valid: false}, nil)
	if x.After.Three.Known || x.After.Three.EMA8Known || x.After.Three.EMA21Known || x.After.Three.InvalidatedAt != 1181 {
		t.Fatal("Last0後に旧閉足を復活")
	}
	x, e := a.AdvanceObserved(1600, []float64{1300})
	if e != nil {
		t.Fatal(e)
	}
	y, _ := b.AdvanceObserved(1600, []float64{1300})
	equalBatch(t, x, y)
	if x.Grids[0].Legacy.ObservedClock != 1600 || len(x.Publications) != 2 || x.Publications[0].Snapshot.Three.Known || x.Publications[1].Snapshot.Three.Known {
		t.Fatal("空足/不良/観測上限差")
	}
	stepBoth(t, a, b, Quote{Time: 1601, Index: 4, Line: 5, Last: 200, Valid: true}, nil)
	_, ending, e := a.Seal()
	_, oldEnd, _ := b.Seal()
	if e != nil || !reflect.DeepEqual(ending.Legacy, oldEnd) || ending.Three.BarEnd != 1540 {
		t.Fatal("Sealが未来形成足を締めた")
	}
}

// seeded は人工の部分暖機種を作り、旧種と新種を同時点で返します。
//
// 引数: t(*testing.T)は人工器です。
// 返り値: Seed/warm.Seedは同じ12正常足だけのメモリ種です。
func seeded(t *testing.T) (Seed, warm.Seed) {
	t.Helper()
	s := Scene{ID: "人工前場", Contract: "人工限月", Start: 1000}
	a, _ := New(s, nil)
	b, _ := warm.New(s, nil)
	for i := 0; i < 12; i++ {
		stepBoth(t, a, b, Quote{Time: 1001 + float64(i)*180, Index: int64(i), Line: int64(i + 1), Last: 1000 + float64(i), Valid: true}, nil)
	}
	x, _ := a.AdvanceObserved(3160, nil)
	y, _ := b.AdvanceObserved(3160, nil)
	equalBatch(t, x, y)
	seed, _, e := a.Seal()
	old, _, oldErr := b.Seal()
	if e != nil || oldErr != nil {
		t.Fatal(e, oldErr)
	}
	return seed, old
}

// TestSeedRollAndCopies は部分暖機継承・roll・場頭mask・分岐非共有を確認します。
//
// 引数: t(*testing.T)は人工器です。
// 返り値: なし。数値持越しと当場の価格構造窓を混同しません。
func TestSeedRollAndCopies(t *testing.T) {
	seed, old := seeded(t)
	scene := Scene{ID: "人工次場", Contract: "人工限月", Start: 5000}
	a, e := New(scene, &seed)
	b, _ := warm.New(scene, &old)
	if e != nil {
		t.Fatal(e)
	}
	s, _ := a.Snapshot()
	if s.Three.EMA8Known || s.Three.EMA21Known || s.Three.Known || s.Three.BarEnd != 0 {
		t.Fatal("Seedから公開maskが漏れた")
	}
	other, _ := New(scene, &seed)
	untouched, _ := other.Snapshot()
	for i := 0; i < 10; i++ {
		x := stepBoth(t, a, b, Quote{Time: 5001 + float64(i)*180, Index: int64(i), Line: int64(i + 1), Last: 1100 + float64(i), Valid: true}, nil)
		if i == 9 && !x.After.Three.EMA21Known {
			t.Fatal("部分EMA暖機種が継承されない")
		}
	}
	afterOther, _ := other.Snapshot()
	if !reflect.DeepEqual(untouched, afterOther) {
		t.Fatal("Seed分岐が浅共有")
	}
	roll, _ := New(Scene{ID: "人工roll", Contract: "別限月", Start: 5000}, &seed)
	_, _ = roll.Step(Quote{Time: 5001, Index: 0, Line: 1, Last: 100, Valid: true}, nil)
	x, _ := roll.AdvanceObserved(5180, nil)
	if x.After.Three.EMA8Known || x.After.Three.EMA21Known || x.After.Legacy.CarriedNumericSeed {
		t.Fatal("roll種が漏れた")
	}
}

// TestPublicTypeExport は左右2確認の純式へ渡す手製公表型を保存します。
//
// 引数: t(*testing.T)と任意env CHART_PUBLIC_EXPORTが新規保存先です。
// 返り値: なし。全Snapshotと出典をGo型のまま保存し、市場OHLCではありません。
func TestPublicTypeExport(t *testing.T) {
	root := os.Getenv("CHART_PUBLIC_EXPORT")
	if root == "" {
		t.Skip("型exportは明示先がある時だけ")
	}
	scenes := map[string][]Publication{}
	for _, side := range []int{1, -1} {
		a, _ := New(Scene{ID: "人工方向", Contract: "人工限月", Start: 1000}, nil)
		rows := []Publication{}
		for i, rawPrice := range []float64{110, 105, 100, 103, 104, 98} {
			price := rawPrice
			if side == -1 {
				price = 2000 - price
			}
			if _, e := a.Step(Quote{Time: 1001 + float64(i)*180, Index: int64(i), Line: int64(i + 1), Last: price, Valid: true}, nil); e != nil {
				t.Fatal(e)
			}
			x, e := a.AdvanceObserved(1180+float64(i)*180, nil)
			if e != nil || len(x.Publications) != 1 {
				t.Fatal("公表不足", e)
			}
			rows = append(rows, x.Publications...)
		}
		name := "買い"
		if side == -1 {
			name = "売り"
		}
		scenes[name] = rows
	}
	data, e := json.MarshalIndent(map[string]any{"scope": "Go公開型の手製12公表。市場/Source/金融なし", "scenes": scenes}, "", "  ")
	if e != nil {
		t.Fatal(e)
	}
	if e = os.MkdirAll(root, 0700); e != nil {
		t.Fatal(e)
	}
	f, e := os.OpenFile(filepath.Join(root, "Go型の人工.json"), os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if e != nil {
		t.Fatal(e)
	}
	if _, e = f.Write(data); e != nil {
		t.Fatal(e)
	}
	if e = f.Close(); e != nil {
		t.Fatal(e)
	}
}
