"""Source全12とI/O停止が揃った後に106の70場/20設定の金融条件を固定する。"""

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess


ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / "study/00106_収束失速で保護の起動と幅を切り替える"
IO = ROOT / "work/106市場の入出力準備"
CORE = ROOT / "work/106可変保護の市場接続準備"
SIDECAR = ROOT / "work/可変追尾の実場公開配送_助走対応"


def sha(path):
    """
    機能: コード・小台帳・実行物のSHA256を得る。
    引数: path(Path)は固定対象。原板や市場金融本文は読まない。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    """
    機能: 小さい停止/条件/参照JSONを読む。
    引数: path(Path)はmetadata。
    返り値: dictは保存内容。
    """
    return json.loads(path.read_text(encoding="utf-8-sig"))


def main():
    """
    機能: 停止と完全なCorpusを固定し、金融前Snapshotと条件を新規保存する。
    引数: --io-stop-sha/--binary/--binary-sha(str)はRootが現物確認するI/O停止と実行物。
    返り値: None。参照不足・指紋差・既存先は停止する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--io-stop-sha", required=True)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--binary-sha", required=True)
    args = parser.parse_args()
    output = TRIAL / "金融条件.json"
    snapshot = TRIAL / "金融前仕様"
    assert not output.exists() and not snapshot.exists()
    io_stop = IO / "停止.json"
    assert len(args.io_stop_sha) == 64 and sha(io_stop) == args.io_stop_sha
    assert len(args.binary_sha) == 64 and sha(args.binary.resolve()) == args.binary_sha
    io_stopped = load(io_stop)
    assert (ROOT / io_stopped["実行物"]).resolve() == args.binary.resolve()
    assert io_stopped["実行物SHA256"] == args.binary_sha
    core_stop = CORE / "停止.json"
    sidecar_stop = SIDECAR / "停止.json"
    assert sha(core_stop) == "c465bd1696fe1e5d2f4c9b299712866c96b73b4126bf4883245acc47fec154f3"
    assert sha(sidecar_stop) == "dd34a46724e7e604544fd60f66e97c0b914cb7593df828ab037a55378cc7244f"
    corpus_path = TRIAL / "Source台帳_70場.json"
    corpus = load(corpus_path)
    assert corpus["version"] == 1 and corpus["trial"] == 106 and corpus["fixed"] and len(corpus["scenes"]) == 70
    input_path = TRIAL / "入力台帳_70場.json"
    assert sha(input_path) == "902c6b5147763de172c0199f79b13cdc08f9a5636b05e0575f19bffd2da627e8"
    completion = ROOT / "work/106Source市場/全12場/完了.json"
    assert corpus["source12_completion"]["sha256"] == sha(completion)
    done = load(completion)
    assert done["success"] and done["stage"] == "full12" and done["sessions"] == 12 and len(done["cases"]) == 36
    assert done["unchanged"] and done["condition_sha256"] == "ae3dd62d9b65bd5b41f750183422e5f596de8f1c623e234362a32e86a89165be"
    code, normalized = {}, {}

    def add(path, expected=None):
        """
        機能: 正規位置でコード/参照を一意に固定する。
        引数: path(Path)、expected(str|None)は対象と既存指紋。
        返り値: None。差又は重複した別内容は停止する。
        """
        path = path.resolve()
        actual = sha(path)
        assert expected is None or actual == expected, str(path)
        key = normalized.setdefault(path.as_posix().lower(), path.as_posix())
        assert key not in code or code[key] == actual, key
        code[key] = actual

    source_condition = TRIAL / "Source条件.json"
    for name, expected in load(source_condition)["code_sha256"].items():
        add(ROOT / name, expected)
    for directory in [CORE, SIDECAR, IO]:
        stopped = load(directory / "停止.json")
        assert stopped["成功"] is True
        owned = stopped.get("所有コードSHA256", stopped.get("所有SHA256"))
        assert owned
        for name, expected in owned.items():
            add(ROOT / name, expected)
        for name, expected in stopped.get("直接依存SHA256", {}).items():
            add(ROOT / name, expected)
        for name in ["元と依存の前指紋.json", "依存の前指紋.json"]:
            path = directory / name
            if path.exists():
                for item, expected in load(path).items():
                    assert isinstance(expected, str) and len(expected) == 64
                    add(ROOT / item, expected)
        add(directory / "停止.json")

    # ----------------------------------------
    # 実際のI/Oビルド対象から局所import/Embed/Moduleの閉包を求める。
    run = subprocess.run(["go", "list", "-mod=readonly", "-deps", "-json", "."], cwd=IO,
                         capture_output=True, encoding="utf-8", check=True)
    decoder, offset, packages = json.JSONDecoder(), 0, []
    while offset < len(run.stdout):
        while offset < len(run.stdout) and run.stdout[offset].isspace():
            offset += 1
        if offset == len(run.stdout):
            break
        package, offset = decoder.raw_decode(run.stdout, offset)
        directory = Path(package["Dir"]).resolve()
        if not directory.is_relative_to(ROOT.parent):
            continue
        names = sorted(set(package.get("GoFiles", []) + package.get("CgoFiles", []) + package.get("EmbedFiles", [])))
        for name in names:
            add(directory / name)
        module = package.get("Module", {})
        module = module.get("Replace", module)
        if module.get("Dir"):
            mod_dir = Path(module["Dir"]).resolve()
            if mod_dir.is_relative_to(ROOT.parent):
                for name in ["go.mod", "go.sum"]:
                    if (mod_dir / name).is_file():
                        add(mod_dir / name)
        packages.append({"import": package["ImportPath"], "directory": directory.as_posix(), "files": names})
    dependency = Path(__file__).parent / "金融Go依存.json"
    assert packages and not dependency.exists()
    dependency.write_text(json.dumps({"packages": packages}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    snapshot.mkdir()
    for name in ["README.md", "設定と結果.md"]:
        shutil.copyfile(TRIAL / name, snapshot / name)
        add(snapshot / name)
    for path in [dependency, Path(__file__), source_condition, Path(__file__).parent / "Source台帳を固定する.py",
                 ROOT / "work/106市場I/Oのpeer確認/最終確認.json",
                 ROOT / "work/106市場I/Oのpeer確認/Root固定helperの確認.json"]:
        add(path)
    metadata_stop = ROOT / "work/106入力と既存Sourceの整理/停止.json"
    references = {"input_manifest": input_path, "source_corpus": corpus_path, "metadata_stop": metadata_stop,
                  "sidecar_stop": sidecar_stop, "core_stop": core_stop, "source12_completion": completion,
                  "binary": args.binary.resolve()}
    value = {"version": 1, "trial": 106, "fixed": True,
             **{name: {"path": path.as_posix(), "sha256": sha(path)} for name, path in references.items()},
             "code_sha256": code,
             "configs": [{"policy": policy, "slip_pts": slip, "delay_seconds": delay}
                         for policy in ["W0", "W1", "W2", "E1", "E2"] for slip in [0, 5] for delay in [0, 1]],
             "seed_policy": "first_cold_then_contract_carry"}
    with output.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"path": output.relative_to(ROOT).as_posix(), "sha256": sha(output),
                      "固定code数": len(code), "局所Goパッケージ": len(packages)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
