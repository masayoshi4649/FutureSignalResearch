"""106の不足12場を再形成する前に計画・入力参照・完全Source実行物を固定する。"""

import hashlib
import json
from pathlib import Path
import shutil


ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / "study/00106_収束失速で保護の起動と幅を切り替える"
SOURCE = ROOT / "work/106不足12Sourceの再形成"
META = ROOT / "work/106入力と既存Sourceの整理"


def sha(path):
    """
    機能: 計画・コード・台帳等の指紋を取得する。
    引数: path(Path)は小さい参照又はコード。原板・CSV本文は読まない。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    """
    機能: 所定の小JSONを読む。
    引数: path(Path)は停止・候補入力・旧固定条件等。
    返り値: dictは保存内容。
    """
    return json.loads(path.read_text(encoding="utf-8-sig"))


def main():
    """
    機能: 既存SHA宣言と新12口を固定し、新規Source条件を保存する。
    引数: なし。106の12ID・3modeと70場計画を変更しない。
    返り値: None。旧Source依存や指紋の差、既存先は拒否する。
    """
    output = TRIAL / "Source条件.json"
    snapshot = TRIAL / "Source前仕様"
    assert not output.exists() and not snapshot.exists()
    stop_path = SOURCE / "停止.json"
    assert sha(stop_path) == "398931526c6ce9e12198c5305106c4407b910942c36c2c60b6267cea5f0ccfa2"
    stop = load(stop_path)
    meta_stop = META / "停止.json"
    assert sha(meta_stop) == "0a9ef9095da945572f98cd050defea60badfd738281cebd3aed9dcb5cc243376"
    master = META / "標準入力台帳_70場_候補.json"
    subset = SOURCE / "不足12入力台帳_候補.json"
    assert sha(master) == "902c6b5147763de172c0199f79b13cdc08f9a5636b05e0575f19bffd2da627e8"
    assert sha(subset) == "2befc71e825f45e305d948626627f72525b11d7cf9fa50c58116b85f61270b33"
    assert len(load(master)["sessions"]) == 70 and len(load(subset)["sessions"]) == 12
    shutil.copyfile(master, TRIAL / "入力台帳_70場.json")
    shutil.copyfile(subset, TRIAL / "Source入力台帳_12場.json")
    snapshot.mkdir()
    for name in ["README.md", "設定と結果.md"]:
        shutil.copyfile(TRIAL / name, snapshot / name)
    code, normalized = {}, {}

    def add(path, expected=None):
        """
        機能: 正規位置ごとにコード/参照を一意に固定する。
        引数: path(Path)、expected(str|None)は対象と既存指紋。
        返り値: None。指紋差又は同位置の別内容は停止する。
        """
        path = path.resolve()
        actual = sha(path)
        assert expected is None or actual == expected, str(path)
        key = normalized.setdefault(path.as_posix().lower(), path.as_posix())
        assert key not in code or code[key] == actual, key
        code[key] = actual

    prior = load(ROOT / "study/00105_固定SourceとLD10の四場追加確認/Source条件.json")
    for mapping in [prior["code_sha256"], stop["所有SHA256"], load(SOURCE / "Go依存の指紋.json")["実解決ファイルSHA256"]]:
        for name, expected in mapping.items():
            add(ROOT / name, expected)
    for path in [stop_path, meta_stop, META / "入力と既存参照の確認.json", master, subset,
                 TRIAL / "入力台帳_70場.json", TRIAL / "Source入力台帳_12場.json",
                 snapshot / "README.md", snapshot / "設定と結果.md", Path(__file__),
                 Path(__file__).parent / "設定表を作成する.py"]:
        add(path)
    condition = load(SOURCE / "条件の雛形.json")
    condition["fixed"] = True
    condition["input_manifest"] = {"path": (TRIAL / "Source入力台帳_12場.json").as_posix(), "sha256": sha(subset)}
    binary = SOURCE / "検査/不足12Source.exe"
    assert sha(binary) == "762d3c3ce0d6d8fd2fc67152358be4c18e7cfe1c6da58a05261288beaf9a768f"
    condition["binary"] = {"path": binary.as_posix(), "sha256": sha(binary)}
    condition["code_sha256"] = code
    with output.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(condition, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"path": output.relative_to(ROOT).as_posix(), "sha256": sha(output), "固定code数": len(code),
                      "位置づけ": "70/12入力は旧宣言SHAの参照固定。現在本文SHAの照合は固定CLIの実行前後で初めて行う。"}, ensure_ascii=False))


if __name__ == "__main__":
    main()
