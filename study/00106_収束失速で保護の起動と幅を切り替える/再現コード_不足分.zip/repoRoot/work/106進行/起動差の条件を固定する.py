"""成功済み106金融・保存を追加の実入口比較へ結ぶ。金融は再実行しない。"""

import argparse
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / "study/00106_収束失速で保護の起動と幅を切り替える"


def sha(path):
    """
    機能: 固定参照の内容指紋を求める。
    引数: path(Path)は小さい条件・結果・コード。
    返り値: strはSHA256。Native本文は読まない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    """
    機能: 成功した同一段階の金融・保存だけを追加診断へ事後固定する。
    引数: --stage(str)はfirst2又はfull70。
    返り値: None。新規の固定JSONとその指紋を保存・表示する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", choices=["first2", "full70"], required=True)
    args = parser.parse_args()
    first = args.stage == "first2"
    number = 2 if first else 70
    completion = ROOT / "work/106市場" / ("先頭2場" if first else "全70場") / "完了.json"
    saved_dir = ROOT / "work/106保存/先頭2場" if first else TRIAL / "成果物"
    summary, check = saved_dir / "結果.json", saved_dir / "保存会計の確認.json"
    code = ROOT / "work/106同幅の起動差の比較/同幅の起動差を比較する.py"
    stop = code.parent / "停止.json"
    assert sha(code) == "c5789a1784635f4c145479dd43583f423501b12543106479ef775d99d16818b2"
    assert sha(stop) == "ade7c9ff2845dcc9cb817378ad85a3ac32508569ac4e1ee1fc6a6e3376065850"
    done, result, checked = [json.loads(path.read_text(encoding="utf-8")) for path in [completion, summary, check]]
    assert done["success"] and done["unchanged"] and done["before"] == done["after"]
    assert done["stage"] == args.stage and done["sessions"] == number and done["books"] == number * 20
    assert result["成功"] and result["stage"] == args.stage and result["会計数"] == number * 20
    assert checked["成功"] and checked["前後不変"] and checked["不一致数"] == 0
    assert checked["出力SHA256"]["結果.json"] == sha(summary)
    assert result["completionSHA256"] == checked["completionSHA256"] == sha(completion)
    assert result["conditionSHA256"] == checked["conditionSHA256"] == done["condition_sha256"]
    destination = ROOT / "work/106起動差の実行固定" / (args.stage + ".json")
    destination.parent.mkdir(parents=True, exist_ok=True)
    value = {"version": 1, "trial": 106, "fixed": True, "stage": args.stage}
    for name, path in {"completion": completion, "summary": summary, "saved_check": check, "code": code}.items():
        value[name] = {"path": path.as_posix(), "sha256": sha(path)}
    with destination.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"path": destination.relative_to(ROOT).as_posix(), "sha256": sha(destination)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
