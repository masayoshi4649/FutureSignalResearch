"""106へ版5の全55×9表と固定したSource/保護設定を新規保存する。"""

from pathlib import Path
import re


ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / "study/00106_収束失速で保護の起動と幅を切り替える"


def main():
    """
    機能: 指標表の行と尺度を保持し、Source継承と追加三分足の役割を分ける。
    引数: なし。版5と固定済み105のSource設定を読む。
    返り値: None。既存先又は行数不一致なら停止する。
    """
    destination = TRIAL / "設定と結果.md"
    assert not destination.exists()
    original = (ROOT / "study/00105_固定SourceとLD10の四場追加確認/主金融前仕様/設定と結果.md").read_text(encoding="utf-8")
    table = original.split("# 手法と時間スケールの汎用表・版5", 1)[1].split("\n## 設定明細", 1)[0]
    table = "# 手法と時間スケールの汎用表・版5" + table
    table = table.replace("R04〜07", "R01〜20")
    lines, ids = [], []
    for line in table.splitlines():
        match = re.match(r"\| ([A-Z]\d{2}) \|", line)
        if match:
            identity = match.group(1)
            ids.append(identity)
            parts = line.split("|")
            assert len(parts) == 13
            if identity == "I01":
                parts[5] = " S11:EMA8/21差が3本厳密縮小C（R05〜20予定） "
                parts[7] = " K10:計算/既知性診断のみ・保護選別なし "
            elif identity == "I03":
                parts[5] = " S12:MACD12/26/9・s×Hist変化<0のM（R05〜20予定） "
                parts[7] = " K10:計算/既知性診断のみ・保護選別なし "
            elif identity == "P02":
                parts[5] = " S13:左2厳密/右2同値可の公表済pivot・当足判定後登録（R09〜12/R17〜20予定） "
            elif identity == "P07":
                parts[5] = " S13:s×(Close−前公表L)<0のP（R09〜12/R17〜20予定） "
            elif identity in ("I04", "I05", "I08"):
                parts[5] = parts[7] = " K10:bank計算/既知性のみ・売買選別未使用 "
            elif identity == "I09":
                parts[5] = parts[7] = " K10:独立bank計算のみ・起動/幅Aへ不使用 "
            elif identity == "C06":
                parts[3] = " K04/K06/K09:LD10/W0〜2/E1〜2の逐次保護（R01〜20予定） "
            elif identity == "E02":
                parts[3] = " S08/09元管理＋K04/06/09追加保護（R01〜20予定） "
            line = "|".join(parts)
        lines.append(line)
    assert len(ids) == len(set(ids)) == 55
    source_rows = [line for line in original.splitlines() if re.match(r"\| S\d{2} \|", line)]
    assert len(source_rows) == 10
    source_rows = [line.replace("R01〜03・R04〜07予定", "固定Source・主R01〜20予定")
                  .replace("本試行未検証", "106市場未検証") for line in source_rows]
    text = "# 00106：設定と結果\n\n"
    text += "市場実行前。既使用70場を全20保護/費用条件で評価する。版5全55手法×9尺度をコピーし、Source継承・保護で値を使うセル・計算診断のみ・追加未使用を分ける。未検証を0成績としない。\n\n"
    text += "\n".join(lines) + "\n\n## 設定明細（実行前）\n\n"
    text += "| 設定ID | 役割 | 閾値/内容 | 適用評価 | 状態 |\n| --- | --- | --- | --- | --- |\n"
    text += "\n".join(source_rows) + "\n"
    text += """| S11 | 追加収束・3分 | G=abs(EMA8−EMA21)、新確定足3本でG_t<G_(t−1)<G_(t−2)、各EMA既知必須 | R05〜20 | SourceのEMA15/60と別、単独効果未検証 |
| S12 | 追加勢い・3分 | MACD12/26/9、s×(Hist_t−Hist_(t−1))<0、未知/同値は支持にしない | R05〜20 | EMAと独立した二票とはしない |
| S13 | 追加構造・3分 | 最新の前公表局所Lにs×(Close−L)<0。左2厳密/右2同値可、当足の新確認Lは当足に不使用 | R09〜12/R17〜20 | 公表前の将来pivot不可、P未知を支持にしない |
| K01 | 追加Source QA | 不足12でlegacy独立形成。旧93goldenなし | Q01 | 経済採用0、市場未実行 |
| K02 | 追加Source QA | default独立形成、legacyと全Result/全記録同体 | Q02 | 相互同体を旧golden/利益成功にしない |
| K03 | 固定Source | 既存58を再用＋不足12のsymmetric。ER<=0.3、L/H両側成立は待機、他の元全式不変 | Q03/R01〜20 | 生成口e519と純43を固定参照 |
| K04 | 通常起動 | A=native ATR12固定Value、u円>=100×max(10,A) | R01〜20 | A未知は保留。3分ATRへ替えない |
| K05 | 新規判断 | B5Q/strict次5分一枠/開始30分除外、Actual US開始30分静観、元P締切/Force | R01〜20 | 主7840/副7560、欠測/US静観を分母に残す |
| K06 | 追尾幅/床 | 通常5ceil(2A/5)、狭幅max(5,5ceil(A/5))。W1/E1=C&M、W2/E2=C&M&Pで狭幅、終玉まで非拡大 | R01〜20 | 最低名目建値/前床以上。Source予約を優先 |
| K07 | 商品/約定/費用 | mini各側10、100円/pt、片道38.5円、C0/C5、D0/D1価格秒、同原行fill禁止 | R01〜20 | 実mini板/実測滑りではない |
| K08 | 参加 | 同枠実取得又は当時実保有の和集合。受理/遅いFill/欠測を分離 | R01〜20 | 最低25%/目標50%、日夜/場別も集計 |
| K09 | 早期起動 | E1/E2は通常LD10 OR u>=100max(10,0.5A)かつ既知C&M(/P)。通常同時成立は通常理由 | R13〜20 | 起動前latest利用可、別EarlyAuditへ根拠保存 |
| K10 | 公開/種 | 最初9/21Day cold、以後70全場時系列・同限月numeric種carry、場頭CMP/形成/mask reset、roll cold | R01〜20 | allboard→公表/Force/grid/raw、未知の補完なし |
| K11 | 保存/比較 | W0既存58最終Book全JSON、新12は別旧103Actor新対照。E専用起動・幅・公表根拠検算 | R01〜20 | 市場全原行の全状態再計算とは区別 |

## 複合評価と結果

Source Q01/Q02は追加12の生成口QA、Q03は主symmetric出典である。保護の経済会計へ重複加算しない。

| 評価ID | 外候補 | 内ActivationPolicy | 追加滑りpt/片道 | 追加価格秒 | 純額 | 参加/7840 | 状態 |
| --- | --- | --- | ---: | ---: | --- | --- | --- |
"""
    number = 0
    for policy in ("W0", "W1", "W2", "E1", "E2"):
        for slip in (0, 5):
            for delay in (0, 1):
                number += 1
                activation = "LD10" if policy.startswith("W") else policy
                text += f"| R{number:02d} | {policy} | {activation} | {slip} | {delay} | 未検証 | 未検証 | 実行前 |\n"
    text += "\n五候補×四費用感度×70場＝1,400経済会計。旧54/105四/不足12を併記し、価格期間の使用歴と単独指標の寄与を誤認しない。起動時機と幅はW0/W1/W2/E1/E2の差として比較し、未知・未使用・計算のみを成績へ補完しない。\n\n[計画](README.md) / [版5正本](../../docs/議論/手法と時間スケールの汎用表_版5.md)。\n"
    destination.write_text(text, encoding="utf-8")
    print("106の55手法×9尺度とS13/K11/R20の実行前表を新規保存")


if __name__ == "__main__":
    main()
