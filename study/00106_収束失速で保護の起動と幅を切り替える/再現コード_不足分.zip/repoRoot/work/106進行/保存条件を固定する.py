"""106金融の成功後に、20政策費用会計の保存実行を事後固定する。"""

import argparse
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / "study/00106_収束失速で保護の起動と幅を切り替える"


def sha(path):
    """
    機能: 小さい固定参照のSHA256を取得する。
    引数: path(Path)は条件・完了・保存コード等。
    返り値: strはSHA256。金融Native・原板をここでは読まない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    """
    機能: 成功した金融receiptと実保存コードを3参照へ固定する。
    引数: --stage(str)はfirst2/full70、--condition-sha(str)はRoot金融固定SHA。
    返り値: None。不成功・別条件・既存出力は拒否する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", required=True, choices=["first2", "full70"])
    parser.add_argument("--condition-sha", required=True)
    args = parser.parse_args()
    condition = TRIAL / "金融条件.json"
    assert len(args.condition_sha) == 64 and sha(condition) == args.condition_sha
    phase, count = ("先頭2場", 2) if args.stage == "first2" else ("全70場", 70)
    completion = ROOT / "work/106市場" / phase / "完了.json"
    done = json.loads(completion.read_text(encoding="utf-8-sig"))
    assert done["trial"] == 106 and done["success"] and done["unchanged"]
    assert done["stage"] == args.stage and done["condition_sha256"] == args.condition_sha
    assert done["sessions"] == count and done["books"] == 20 * count and done["books_per_scene"] == 20
    assert done["financial_executed"] and not done["source_reexecuted"]
    code = ROOT / "work/106可変保護の保存準備/集計.py"
    stop = ROOT / "work/106可変保護の保存準備/停止.json"
    assert sha(code) == "7451f6c6502ec7b5ca83d0ce296931f1abbb2b082d41003ccb8a907846736f47"
    assert sha(stop) == "3dd87ba97322a30c820d5b958f27d5846c4bce206e748ce0a88a962c881c9953"
    destination = ROOT / "work/106保存の実行固定" / (args.stage + ".json")
    destination.parent.mkdir(parents=True, exist_ok=True)
    assert not destination.exists()
    value = {"version": 1, "trial": 106, "stage": args.stage, "fixed": True}
    for name, path in {"condition": condition, "completion": completion, "code": code}.items():
        value[name] = {"path": path.as_posix(), "sha256": sha(path)}
    with destination.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"path": destination.relative_to(ROOT).as_posix(), "sha256": sha(destination)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
