"""不足12Sourceの成功後に、70場のSource/Tape/旧金融参照だけを固定する。"""

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / "study/00106_収束失速で保護の起動と幅を切り替える"
META = ROOT / "work/106入力と既存Sourceの整理/入力と既存参照の確認.json"


def sha(path):
    """
    機能: 小さいmetadataの指紋を取得する。
    引数: path(Path)は台帳・条件・完了で、原板/価格/金融本文は読まない。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    """
    機能: 所定のmetadata JSONを読む。
    引数: path(Path)は参照整理・Source完了・入力台帳。
    返り値: dictは保存内容。
    """
    return json.loads(path.read_text(encoding="utf-8-sig"))


def declared(ref):
    """
    機能: 既存metadata宣言をFileRefへ正規化する。
    引数: ref(dict)はpath/宣言SHA256を持つ旧参照。
    返り値: dictは絶対path/sha256。本文SHAを新しく計算したとはしない。
    """
    path, expected = Path(ref["path"]).resolve(), ref["宣言SHA256"]
    assert path.is_file() and len(expected) == 64
    if "stat" in ref:
        assert path.stat().st_size == ref["stat"]["size"]
    return {"path": path.as_posix(), "sha256": expected}


def main():
    """
    機能: 不足12完了と旧58metadataを合わせ、70場の完全な参照台帳を保存する。
    引数: なし。未完成placeholder・別順序・既存先は拒否する。
    返り値: None。Bodyの再生/Source生成/金融は行わない。
    """
    output = TRIAL / "Source台帳_70場.json"
    assert not output.exists()
    assert sha(META) == "2e115634d0772864cb501a73f2a0e4b85f5c5185f63f84530aca5ba75e02cbdb"
    metadata = load(META)
    input_path = TRIAL / "入力台帳_70場.json"
    assert sha(input_path) == "902c6b5147763de172c0199f79b13cdc08f9a5636b05e0575f19bffd2da627e8"
    completion = ROOT / "work/106Source市場/全12場/完了.json"
    done = load(completion)
    assert done["version"] == 1 and done["trial"] == 106 and done["stage"] == "full12" and done["success"]
    assert done["sessions"] == 12 and len(done["cases"]) == 36 and done["unchanged"]
    assert done["before"] == done["after"] and done["source_reformed"] and done["financial106_executed"] is False
    assert done["condition_sha256"] == "ae3dd62d9b65bd5b41f750183422e5f596de8f1c623e234362a32e86a89165be"
    assert len(done["legacy_default_matches"]) == 12 and all(row["success"] for row in done["legacy_default_matches"])
    cases = {(row["session"], row["mode"]): row for row in done["cases"]}
    assert len(cases) == 36 and all(not row["old93_full_match"] and not row.get("error") for row in cases.values())
    scenes = []
    for index, row in enumerate(metadata["場別"]):
        session = row["session"]
        item = {"session": session}
        if index < 54:
            assert row["Source"]["元試行"] == 104
            item.update(kind="old104_54", old_clock_tape=declared(row["frame_Tape_Force"]["元価格時計Tape"]),
                        source_records={"symmetric": declared(row["Source"]["3mode"]["symmetric"]["records"])},
                        w0_native=declared(row["W0旧市場対照"]["Native"]))
        elif index < 66:
            assert row["Source"] is None and row["W0旧市場対照"] is None
            records = {}
            for mode in ["legacy", "default", "symmetric"]:
                ref = cases[(session, mode)]["records"]
                path = (completion.parent / ref["path"]).resolve()
                assert path.is_file() and len(ref["sha256"]) == 64
                records[mode] = {"path": path.as_posix(), "sha256": ref["sha256"]}
            item.update(kind="fresh106_12", source_records=records)
        else:
            assert row["Source"]["元試行"] == 105
            item.update(kind="saved105_4", legacy_tape=declared(row["frame_Tape_Force"]["fresh_legacy_tape"]),
                        symmetric_tape=declared(row["frame_Tape_Force"]["symmetric_tape"]),
                        w0_native=declared(row["W0旧市場対照"]["Native"]))
        scenes.append(item)
    assert [row["session"] for row in scenes] == [row["id"] for row in load(input_path)["sessions"]]
    assert len(scenes) == 70
    value = {"version": 1, "trial": 106, "fixed": True,
             "input_manifest": {"path": input_path.as_posix(), "sha256": sha(input_path)},
             "source12_completion": {"path": completion.as_posix(), "sha256": sha(completion)}, "scenes": scenes}
    with output.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"path": output.relative_to(ROOT).as_posix(), "sha256": sha(output),
                      "場数": 70, "旧104": 54, "旧105": 4, "新106": 12,
                      "位置づけ": "参照指紋固定のみ。Tape/Source/Native本文と価格は金融口の前後で照合。"}, ensure_ascii=False))


if __name__ == "__main__":
    main()
