"""106全70の金融・保存・Viewer成功後に報告又はxlsxの入力を固定する。"""

import argparse
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / "study/00106_収束失速で保護の起動と幅を切り替える"
CODE = {
    "report": ("work/106報告の準備/報告を差し替える.py", "5a58edda4ee0373a56722237adbbafc717a8160d9cfb05daf2c7b84921e470a3"),
    "xlsx": ("work/106xlsx追記の準備/106を追記する.mjs", "4cf66042d70cfc5389366a4d90fd86bd305fcd1a281d5a05f8e2bcb8459fc57a"),
}


def sha(path):
    """
    機能: 報告用の小さい正本・コード参照の指紋を得る。
    引数: path(Path)は対象ファイル。
    返り値: strはSHA256。原板・Nativeを読まない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    """
    機能: UTF-8の小さいJSON参照を読む。
    引数: path(Path)は正本の実行・保存・Viewer証拠。
    返り値: dictは内容。未成功を成功へ補完しない。
    """
    return json.loads(path.read_text(encoding="utf-8"))


def main():
    """
    機能: 全70成功の実参照を一度だけ報告又はxlsxの固定JSONへ保存する。
    引数: --target(str)はreport/xlsx。
    返り値: None。文書・xlsx自体や金融を変更・実行しない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--target", choices=CODE, required=True)
    args = parser.parse_args()
    refs = {
        "summary": TRIAL / "成果物/結果.json",
        "saved_check": TRIAL / "成果物/保存会計の確認.json",
        "financial_completion": ROOT / "work/106市場/全70場/完了.json",
        "viewer_evidence": TRIAL / "検査/Viewer代表20資源.json",
    }
    result, checked, done, viewer = [load(refs[k]) for k in refs]
    assert done["success"] and done["unchanged"] and done["before"] == done["after"]
    assert done["stage"] == "full70" and done["sessions"] == 70 and done["books"] == 1400
    assert result["成功"] and result["stage"] == "full70" and result["場数"] == 70 and result["会計数"] == 1400
    assert checked["成功"] and checked["会計"] == checked["資源"] == 1400 and checked["不一致数"] == 0
    assert checked["前後不変"] and checked["入力codeSHA256前"] == checked["入力codeSHA256後"]
    assert checked["出力SHA256"]["結果.json"] == sha(refs["summary"])
    assert result["completionSHA256"] == checked["completionSHA256"] == sha(refs["financial_completion"])
    assert result["conditionSHA256"] == checked["conditionSHA256"] == done["condition_sha256"]
    assert viewer["成功"] and viewer["一覧"] == 1400 and viewer["実GET"] == 20 and viewer["前後不変"]
    assert viewer["入力SHA256"][str(refs["summary"])] == sha(refs["summary"])
    value = {"version": 1, "trial": 106, "fixed": True, "result_ready": True}
    code, digest = CODE[args.target]
    assert sha(ROOT / code) == digest
    if args.target == "report":
        refs.update({
            "condition": TRIAL / "金融条件.json",
            "source_completion": ROOT / "work/106Source市場/全12場/完了.json",
            "activation_comparison_json": TRIAL / "検査/同幅の起動差/同幅の起動差.json",
            "activation_comparison_md": TRIAL / "検査/同幅の起動差/同幅の起動差.md",
        })
        extra = load(refs["activation_comparison_json"])
        assert extra["成功"] and extra["stage"] == "full70" and extra["場数"] == 70 and extra["比較数"] == 8
    else:
        refs["code"] = ROOT / code
        value.update({"financial_checked": True, "saved_checked": True, "viewer_checked": True, "viewer_scope": viewer["scope"]})
    for name, path in refs.items():
        value[name] = {"path": path.as_posix(), "sha256": sha(path)}
    destination = ROOT / "work/106報告の実行固定" / (args.target + ".json")
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"path": destination.relative_to(ROOT).as_posix(), "sha256": sha(destination)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
