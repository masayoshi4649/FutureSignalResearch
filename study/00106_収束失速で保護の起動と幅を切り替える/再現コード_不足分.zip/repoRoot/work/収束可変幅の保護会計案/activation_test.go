package minivariableguard

import (
	"bytes"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"testing"

	old95 "github.com/masayoshi4649/SessionTradeExecuter/minigrid"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	legacy "github.com/masayoshi4649/SessionTradeExecuter/minishortfinance"
)

type step103 struct {
	Observation Observation   `json:"observation"`
	SourceLine  int64         `json:"source_line"`
	Batches     []NativeBatch `json:"batches"`
}
type timer103 struct {
	At      float64       `json:"at"`
	Batches []NativeBatch `json:"batches"`
}
type event103 struct {
	Kind  string `json:"kind"`
	Index int    `json:"index"`
}
type fixture103 struct {
	Session     Session                       `json:"session"`
	Scope       string                        `json:"scope"`
	Steps       []step103                     `json:"steps"`
	Timers      []timer103                    `json:"timers"`
	Grids       []float64                     `json:"grids"`
	Events      []event103                    `json:"events"`
	Actors      map[string]ActualResult       `json:"actors"`
	Baseline95  map[string]old95.ActualResult `json:"baseline95_p0"`
	Comparisons int                           `json:"comparisons"`
}

// equal103 は保存可能な全fieldを除外なしのJSON本文で照合します。
//
// 引数: t(*testing.T)、a/b(any)、label(string)は試験器と実値です。
// 返り値: ありません。nil/空配列やoptional欄の差も失敗です。
func equal103(t *testing.T, a, b any, label string) {
	t.Helper()
	x, e := json.Marshal(a)
	if e != nil {
		t.Fatal(e)
	}
	y, e := json.Marshal(b)
	if e != nil {
		t.Fatal(e)
	}
	if !bytes.Equal(x, y) {
		t.Fatalf("%s 全JSON差\n新%s\n旧%s", label, x, y)
	}
}

// batches95 は元Deltaを旧95の名前付き外型へ全値対応します。
//
// 引数: in([]NativeBatch)は不変の人工通知です。
// 返り値: []old95.NativeBatchはnilと配列順を保持します。
func batches95(in []NativeBatch) []old95.NativeBatch {
	if in == nil {
		return nil
	}
	out := make([]old95.NativeBatch, len(in))
	for i, b := range in {
		out[i] = old95.NativeBatch{Method: b.Method, Delta: b.Delta}
	}
	return out
}

// batchesLegacy は元Deltaを旧canonical外型へ全値対応します。
//
// 引数: in([]NativeBatch)は不変通知です。
// 返り値: []legacy.NativeBatchはnilと全Deltaを保持します。
func batchesLegacy(in []NativeBatch) []legacy.NativeBatch {
	if in == nil {
		return nil
	}
	out := make([]legacy.NativeBatch, len(in))
	for i, b := range in {
		out[i] = legacy.NativeBatch{Method: b.Method, Delta: b.Delta}
	}
	return out
}

// wave103 は手製SourceとATRの同一列を主12と無保護4へ配送します。
//
// 引数: t(*testing.T)、side(int)、unknownATR(bool)は試験器・鏡像・暖機ケースです。
// 返り値: fixture103は全公開入力/16最終/旧95P0四です。戦略や自然ATR形成の証明ではありません。
func wave103(t *testing.T, side int, unknownATR bool) fixture103 {
	t.Helper()
	s := session()
	grid := s.Start + 1800
	out := fixture103{Session: s, Scope: "手製Source/公開native ATRのAPI人工。主12とS0診断4、原板/Source形成/市場成績ではない。", Actors: map[string]ActualResult{}, Baseline95: map[string]old95.ActualResult{}}
	actors := map[string]*ActualBook{}
	priors := map[string]*old95.ActualBook{}
	keys := []string{}
	for _, policy := range []ActivationPolicy{"", ActivationLD05, ActivationLD10} {
		for _, c := range []float64{0, 5} {
			for _, d := range []int{0, 1} {
				cfg := ActorConfig{Policy: "P0", EntryTiming: "B5Q", SlipPts: c, DelaySeconds: d, ActivationPolicy: policy}
				b, e := NewActualBook(s, cfg)
				if e != nil {
					t.Fatal(e)
				}
				k := b.Snapshot().Key
				actors[k] = b
				keys = append(keys, k)
				if policy == "" {
					p, e := old95.NewActualBook(s, old95.ActorConfig{Policy: "P0", EntryTiming: "B5Q", SlipPts: c, DelaySeconds: d})
					if e != nil {
						t.Fatal(e)
					}
					priors[k] = p
				}
			}
		}
	}
	for _, c := range []float64{0, 5} {
		for _, d := range []int{0, 1} {
			b, e := NewActualBook(s, ActorConfig{Policy: "S0", EntryTiming: "B5Q", SlipPts: c, DelaySeconds: d})
			if e != nil {
				t.Fatal(e)
			}
			k := b.Snapshot().Key
			actors[k] = b
			keys = append(keys, k)
		}
	}
	compare := func() {
		for k, b := range priors {
			equal103(t, actors[k].Snapshot(), b.Snapshot(), k)
			out.Comparisons++
		}
	}
	src := newSource()
	index := int64(0)
	feed := func(at, move, atr float64, bad bool, news ...native.Signal) {
		o := observation(at, move, side, index, bad)
		o.ATR = atr
		o.E01.ATR = atr
		if atr == 0 {
			o.E01.ATRAvailable = 0
			o.E01.ATRNominal = 0
		}
		line := index + 20
		batch := src.step(stamp(o, line), news)
		in := []NativeBatch{batch}
		before, _ := json.Marshal(in)
		for _, k := range keys {
			if e := actors[k].OnNativeStep(o, line, in); e != nil {
				t.Fatal(k, e)
			}
		}
		for _, b := range priors {
			if e := b.OnNativeStep(o, line, batches95(in)); e != nil {
				t.Fatal(e)
			}
		}
		after, _ := json.Marshal(in)
		if !bytes.Equal(before, after) {
			t.Fatal("共用入力変更")
		}
		out.Events = append(out.Events, event103{"quote", len(out.Steps)})
		out.Steps = append(out.Steps, step103{o, line, in})
		index++
		compare()
	}
	callGrid := func(at float64) {
		for _, k := range keys {
			if e := actors[k].OnEntryGrid(at); e != nil {
				t.Fatal(e)
			}
		}
		for _, b := range priors {
			if e := b.OnEntryGrid(at); e != nil {
				t.Fatal(e)
			}
		}
		out.Events = append(out.Events, event103{"grid", len(out.Grids)})
		out.Grids = append(out.Grids, at)
		compare()
	}
	atr := 40.75
	if unknownATR {
		atr = 0
	}
	feed(grid-2, 0, atr, false, birth("初回", side, 6))
	feed(grid-1, 0, atr, false)
	callGrid(grid)
	feed(grid+1, 0, atr, false)
	feed(grid+2, 20, atr, false)
	for _, policy := range []string{"LD05", "LD10"} {
		p := actors[policy+"_B5Q_P0_C0_D0"].Snapshot().Positions[0]
		if p.Marks.FirstUnitPositive == nil || p.ProtectionActive {
			t.Fatal("初回u正と遅延起動の混同", policy)
		}
	}
	feed(grid+3, 25, atr, false, closeSignal("部分", "玉-初回", side, 3))
	feed(grid+4, 25, atr, false)
	atr = 40.75
	feed(grid+5, 70, atr, false)
	for _, policy := range []string{"LD05", "LD10"} {
		p := actors[policy+"_B5Q_P0_C5_D1"].Snapshot().Positions[0]
		if !p.ProtectionActive || p.ATR == nil || p.ATR.Value != 40.75 || p.ATR.Width != 85 || p.ActivationReason == "" {
			t.Fatal("起動又はraw ATRと丸め幅の混同", p)
		}
		if unknownATR && !p.ATR.AfterEntry {
			t.Fatal("未知ATRの初回既知固定")
		}
	}
	feed(grid+6, 120, 300, false)
	floor := *actors["LD10_B5Q_P0_C5_D1"].Snapshot().Positions[0].FloorGain
	feed(grid+7, 110, 1, false)
	if p := actors["LD10_B5Q_P0_C5_D1"].Snapshot().Positions[0]; *p.FloorGain < floor || p.ATR.Value != 40.75 || p.ATR.Width != 85 {
		t.Fatal("幅再固定又は床緩和")
	}
	feed(grid+8, 0, 40.75, false)
	feed(grid+8, 0, 40.75, true)
	feed(grid+9, -10, 40.75, false)
	// 親追加は別出生として同じ5分規則へ送り、源側可変量/現在量を維持する。
	feed(grid+298, 0, 40.75, false, birth("親追加", side, 4))
	feed(grid+299, 0, 40.75, false)
	callGrid(grid + 300)
	feed(grid+301, 0, 40.75, false)
	feed(grid+302, 30, 40.75, false)
	// Forceは同時計でfillを作らず、元Source返済だけを先に予約する。
	batch := src.force(grid + 302)
	batch.Delta.SourceLine = src.last.SourceLine
	in := []NativeBatch{batch}
	for _, k := range keys {
		if e := actors[k].OnNativeForce(grid+302, in); e != nil {
			t.Fatal(e)
		}
	}
	for _, b := range priors {
		if e := b.OnNativeForce(grid+302, batches95(in)); e != nil {
			t.Fatal(e)
		}
	}
	out.Events = append(out.Events, event103{"timer", len(out.Timers)})
	out.Timers = append(out.Timers, timer103{grid + 302, in})
	compare()
	feed(grid+302, 30, 40.75, true)
	feed(grid+302, 20, 40.75, false)
	feed(grid+303, 10, 40.75, false)
	for _, k := range keys {
		r, e := actors[k].Finish()
		if e != nil {
			t.Fatal(k, e)
		}
		out.Actors[k] = r
		if !r.Complete || r.Totals.OpenBuy+r.Totals.OpenSell+r.Totals.PendingBuy+r.Totals.PendingSell != 0 || r.Totals.EntryQuantity == 0 {
			t.Fatal("非0/完結不成立", k)
		}
		for _, p := range r.Positions {
			if p.Quantity != 0 || p.Reserved != 0 {
				t.Fatal("終了残")
			}
		}
		if r.Config.Policy == "S0" && (r.Metrics.ProtectionExitRequests != 0 || r.Metrics.ProtectionActivatedPositions != 0 || r.Metrics.UnitPositivePositions == 0) {
			t.Fatal("S0診断対照")
		}
		if r.Config.Policy == "S0" {
			// 初回6のうち3枚は1010→1025、残3枚と追加4枚はD0で1010→1020、D1で1010→1010。
			// 売り鏡像も同粗額。総10枚の往復費用770円、滑りは20片道分。
			gross := 11500 - 7000*float64(r.Config.DelaySeconds)
			expected := gross - 770 - 20*r.Config.SlipPts*100
			if r.Totals.GrossYen != gross || r.Totals.FeeYen != 770 || r.Totals.NetYen != expected {
				t.Fatal("S0独立手計算", r.Totals, expected)
			}
		}
	}
	for k, b := range priors {
		r, e := b.Finish()
		if e != nil {
			t.Fatal(e)
		}
		out.Baseline95[k] = r
		equal103(t, out.Actors[k], r, "旧95最終")
		out.Comparisons++
	}
	return out
}

// Test103PublicWave は旧95対照と主12/診断4を買売・未知ATRで結びます。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: ありません。元Sourceの発生や市場収支を検証しません。
func Test103PublicWave(t *testing.T) {
	for _, side := range []int{1, -1} {
		for _, unknown := range []bool{false, true} {
			t.Run(fmt.Sprintf("方向%d_未知ATR%t", side, unknown), func(t *testing.T) {
				f := wave103(t, side, unknown)
				if side == 1 { // 費用の半円を丸めず保持する返済片が実在する。
					found := false
					for _, fill := range f.Actors["B5Q_P0_C0_D0"].Fills {
						for _, a := range fill.Allocations {
							if a.EntryFeeYen == 115.5 && a.ExitFeeYen == 115.5 {
								found = true
							}
						}
					}
					if !found {
						t.Fatal("半円配賦未通過")
					}
				}
			})
		}
	}
}

// Test103Threshold は等号・非整数ATR・0益・未知を数値器の同じ単位で検査します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: ありません。市場格子へ価格を偽装しません。
func Test103Threshold(t *testing.T) {
	a := &ATRLock{Value: 40.75, Width: 85}
	for _, p := range []ActivationPolicy{ActivationLD05, ActivationLD10} {
		f := 0.5
		if p == ActivationLD10 {
			f = 1
		}
		cut := 100 * math.Max(10, f*a.Value)
		if !activationEligible(p, a, cut) || activationEligible(p, a, math.Nextafter(cut, math.Inf(-1))) || activationEligible(p, nil, 100000) {
			t.Fatal("LD等号/未知", p)
		}
	}
	if activationEligible("", nil, 0) || !activationEligible("", nil, .5) || activationEligible(ActivationLD05, &ATRLock{Value: 1}, 999.5) {
		t.Fatal("strict正/最低10pt")
	}
}

// Test103PublicThresholdEquality は公開Stepから費用後単価の等号起動へ到達します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: ありません。価格刻みを前提にしないAPIの数学境界です。
func Test103PublicThresholdEquality(t *testing.T) {
	for _, side := range []int{1, -1} {
		for _, policy := range []ActivationPolicy{ActivationLD05, ActivationLD10} {
			s := session()
			g := s.Start + 1800
			atr := 21.23
			if policy == ActivationLD05 {
				atr = 42.46
			}
			b, e := NewActualBook(s, ActorConfig{Policy: "P0", EntryTiming: "B5Q", ActivationPolicy: policy})
			if e != nil {
				t.Fatal(e)
			}
			src := newSource()
			i := int64(0)
			feed := func(at, move float64, news ...native.Signal) {
				o := observation(at, move, side, i, false)
				o.ATR = atr
				o.E01.ATR = atr
				d := []NativeBatch{src.step(stamp(o, i+20), news)}
				if e := b.OnNativeStep(o, i+20, d); e != nil {
					t.Fatal(e)
				}
				i++
			}
			feed(g-2, 0, birth("等号", side, 1))
			feed(g-1, 0)
			if e := b.OnEntryGrid(g); e != nil {
				t.Fatal(e)
			}
			feed(g+1, 0)
			feed(g+2, 31)
			if p := b.Snapshot().Positions[0]; p.ProtectionActive || p.Marks.FirstUnitPositive == nil {
				t.Fatal("等号直前")
			}
			feed(g+2, 32)
			p := b.Snapshot().Positions[0]
			if !p.ProtectionActive || p.Activation.UnitNet != 2123 {
				t.Fatal("公開等号起動", p)
			}
			d := []NativeBatch{src.force(g + 2)}
			if e := b.OnNativeForce(g+2, d); e != nil {
				t.Fatal(e)
			}
			feed(g+2, 32)
			if _, e := b.Finish(); e != nil {
				t.Fatal(e)
			}
		}
	}
}

// Test103Mirror は同じ時刻の算術価格鏡像で実会計と保護観測を比較します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: ありません。手製通知の対称であり自然Source生成の証明ではありません。
func Test103Mirror(t *testing.T) {
	a, b := wave103(t, 1, false), wave103(t, -1, false)
	for k, x := range a.Actors {
		y := b.Actors[k]
		equal103(t, x.Totals, y.Totals, "鏡像総額")
		equal103(t, x.Metrics, y.Metrics, "鏡像分母")
		equal103(t, x.GridMetrics, y.GridMetrics, "鏡像枠")
		if len(x.Fills) != len(y.Fills) || len(x.Orders) != len(y.Orders) {
			t.Fatal("鏡像件数")
		}
		for i, f := range x.Fills {
			g := y.Fills[i]
			if f.Side != -g.Side || f.Quantity != g.Quantity || f.Price+g.Price != 2000 || f.FeeYen != g.FeeYen || f.GrossYen != g.GrossYen || f.Reason != g.Reason {
				t.Fatal("鏡像fill")
			}
		}
		for i, p := range x.Positions {
			q := y.Positions[i]
			if (p.Activation == nil) != (q.Activation == nil) {
				t.Fatal("鏡像起動")
			}
			if p.Activation != nil && (p.Activation.UnitNet != q.Activation.UnitNet || p.Activation.Quote.Time != q.Activation.Quote.Time || p.Activation.GainPoints != q.Activation.GainPoints) {
				t.Fatal("鏡像起動値")
			}
		}
	}
}

// Test103ReservedAndSameTime はSource予約中の起動とstrict後続/D1を検査します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: ありません。全予約は追加返済せず、部分予約は未予約量だけを要求します。
func Test103ReservedAndSameTime(t *testing.T) {
	for _, side := range []int{1, -1} {
		for _, delay := range []int{0, 1} {
			for _, reserved := range []int{3, 6} {
				s := session()
				g := s.Start + 1800
				b, e := NewActualBook(s, ActorConfig{Policy: "P0", EntryTiming: "B5Q", DelaySeconds: delay, ActivationPolicy: ActivationLD05})
				if e != nil {
					t.Fatal(e)
				}
				src := newSource()
				index := int64(0)
				feed := func(at, move float64, news ...native.Signal) {
					o := observation(at, move, side, index, false)
					d := []NativeBatch{src.step(stamp(o, index+20), news)}
					if e := b.OnNativeStep(o, index+20, d); e != nil {
						t.Fatal(e)
					}
					index++
				}
				feed(g-2, 0, birth("予約", side, 6))
				feed(g-1, 0)
				if e := b.OnEntryGrid(g); e != nil {
					t.Fatal(e)
				}
				feed(g+1, 0)
				feed(g+2, 0, closeSignal("先行予約", "玉-予約", side, reserved))
				r := b.Snapshot()
				if r.Positions[0].Reserved != reserved || r.Positions[0].ProtectionActive {
					t.Fatal("Source先行予約")
				}
				feed(g+2, 70)
				r = b.Snapshot()
				p := r.Positions[0]
				if !p.ProtectionActive || p.Activation == nil || p.Activation.Reserved != reserved || r.Metrics.ProtectionExitRequests != 0 {
					t.Fatal("予約下の起動/二重返済")
				}
				if delay == 1 && p.Quantity != 6 {
					t.Fatal("D1が同秒fill")
				}
				if delay == 0 && p.Quantity != 6-reserved {
					t.Fatal("D0同時刻後Indexの適格fill")
				}
				// 同時計Forceはfillしない。全予約なら追加要求もしない。
				d := []NativeBatch{src.force(g + 2)}
				before := len(r.Fills)
				if e := b.OnNativeForce(g+2, d); e != nil {
					t.Fatal(e)
				}
				if len(b.Snapshot().Fills) != before {
					t.Fatal("Force架空fill")
				}
				feed(g+2, 0)
				feed(g+3, -10)
				out, e := b.Finish()
				if e != nil {
					t.Fatal(e)
				}
				if !out.Complete || out.Totals.CloseQuantity != 6 || out.Metrics.ProtectionExitRequests != 0 {
					t.Fatal("Source予約優先/完結")
				}
			}
		}
	}
}

// Test103SideCap は現在保有と未取得予約を含む各側10枚を検査します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: ありません。片側超過は切り詰め、反対側は独立上限です。
func Test103SideCap(t *testing.T) {
	s := session()
	g := s.Start + 1800
	b, e := NewActualBook(s, ActorConfig{Policy: "P0", EntryTiming: "B5Q", ActivationPolicy: ActivationLD10})
	if e != nil {
		t.Fatal(e)
	}
	src := newSource()
	i := int64(0)
	feed := func(at float64, news ...native.Signal) {
		o := observation(at, 0, 1, i, false)
		d := []NativeBatch{src.step(stamp(o, i+20), news)}
		if e := b.OnNativeStep(o, i+20, d); e != nil {
			t.Fatal(e)
		}
		i++
	}
	feed(g-2, birth("買6", 1, 6), birth("買6追加", 1, 6), birth("売10", -1, 10))
	feed(g - 1)
	if e := b.OnEntryGrid(g); e != nil {
		t.Fatal(e)
	}
	r := b.Snapshot()
	if r.Totals.PendingBuy != 10 || r.Totals.PendingSell != 10 || r.Metrics.CapClippedEntries != 1 {
		t.Fatal("予約込み各側10", r.Totals)
	}
	feed(g + 1)
	r = b.Snapshot()
	if r.Totals.OpenBuy != 10 || r.Totals.OpenSell != 10 {
		t.Fatal("両側各10保有")
	}
	d := []NativeBatch{src.force(g + 1)}
	if e := b.OnNativeForce(g+1, d); e != nil {
		t.Fatal(e)
	}
	feed(g + 1)
	r, e = b.Finish()
	if e != nil || !r.Complete || r.Totals.CloseQuantity != 20 {
		t.Fatal("上限器具完結", e)
	}
}

// Test103EmptyCanonical は旧canonical全API入力を空policyで全時点同値にします。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: ありません。手製gate許可を自然E3S証明と呼びません。
func Test103EmptyCanonical(t *testing.T) {
	for _, side := range []int{1, -1} {
		for _, harvest := range []string{"", "H0", "HG"} {
			for _, cost := range []float64{0, 5} {
				for _, delay := range []int{0, 1} {
					s := session()
					g := s.Start + 1800
					cfg := ActorConfig{Policy: "P0", EntryTiming: "B5Q", GatePolicy: "E3S", HarvestPolicy: harvest, SlipPts: cost, DelaySeconds: delay}
					b, e := NewActualBook(s, cfg)
					if e != nil {
						t.Fatal(e)
					}
					old, e := legacy.NewActualBook(s, legacy.ActorConfig{Policy: "P0", EntryTiming: "B5Q", GatePolicy: "E3S", HarvestPolicy: harvest, SlipPts: cost, DelaySeconds: delay})
					if e != nil {
						t.Fatal(e)
					}
					check := func() { equal103(t, b.Snapshot(), old.Snapshot(), "空policy旧canonical") }
					check()
					src := newSource()
					i := int64(0)
					feed := func(at, move float64, news ...native.Signal) {
						o := observation(at, move, side, i, false)
						d := []NativeBatch{src.step(stamp(o, i+30), news)}
						if e := b.OnNativeStep(o, i+30, d); e != nil {
							t.Fatal(e)
						}
						if e := old.OnNativeStep(o, i+30, batchesLegacy(d)); e != nil {
							t.Fatal(e)
						}
						i++
						check()
					}
					feed(g-2, 0, birth("正本", side, 5))
					feed(g-1, 0)
					if e := b.OnEntryGridWithGate(g, func(c EntryCandidate) (GateDecision, error) {
						return GateDecision{Policy: "E3S", SnapshotID: "手製許可", Known: true, Allowed: true, Role: "手製", Reason: "技法生成範囲外"}, nil
					}); e != nil {
						t.Fatal(e)
					}
					if e := old.OnEntryGridWithGate(g, func(c legacy.EntryCandidate) (legacy.GateDecision, error) {
						return legacy.GateDecision{Policy: "E3S", SnapshotID: "手製許可", Known: true, Allowed: true, Role: "手製", Reason: "技法生成範囲外"}, nil
					}); e != nil {
						t.Fatal(e)
					}
					check()
					feed(g+1, 0)
					feed(g+2, 30)
					feed(g+3, 60)
					feed(g+4, -20)
					feed(g+5, -20)
					d := []NativeBatch{src.force(g + 5)}
					if e := b.OnNativeForce(g+5, d); e != nil {
						t.Fatal(e)
					}
					if e := old.OnNativeForce(g+5, batchesLegacy(d)); e != nil {
						t.Fatal(e)
					}
					check()
					feed(g+5, -20)
					feed(g+6, -20)
					r, e := b.Finish()
					if e != nil {
						t.Fatal(e)
					}
					r0, e := old.Finish()
					if e != nil {
						t.Fatal(e)
					}
					equal103(t, r, r0, "空policy最終")
				}
			}
		}
	}
}

// Test103ConfigReject は未比較のpolicy混在と公開ATR破損を拒否します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: ありません。未知ATR0は正常な保留です。
func Test103ConfigReject(t *testing.T) {
	base := ActorConfig{Policy: "P0", EntryTiming: "B5Q", ActivationPolicy: ActivationLD05}
	for _, kind := range []string{"未定義", "Gate", "Harvest", "Risk", "Exit", "S0", "N"} {
		c := base
		switch kind {
		case "未定義":
			c.ActivationPolicy = "LD15"
		case "Gate":
			c.GatePolicy = "E3S"
		case "Harvest":
			c.HarvestPolicy = "H0"
		case "Risk":
			c.RiskPolicy = "R05"
		case "Exit":
			c.ExitPolicy = "X5"
		case "S0":
			c.Policy = "S0"
		case "N":
			c.EntryTiming = "N"
		}
		if _, e := NewActualBook(session(), c); e == nil {
			t.Fatal("誤設定成功", kind)
		}
	}
	for _, kind := range []string{"負ATR", "未来ATR", "非有限"} {
		b, e := NewActualBook(session(), base)
		if e != nil {
			t.Fatal(e)
		}
		o := observation(session().Start+1800, 0, 1, 0, false)
		switch kind {
		case "負ATR":
			o.ATR = -1
			o.E01.ATR = -1
		case "未来ATR":
			o.E01.ATRAvailable = o.Time + 1
		case "非有限":
			o.ATR = math.NaN()
			o.E01.ATR = o.ATR
		}
		if e := b.OnNativeStep(o, 1, nil); e == nil {
			t.Fatal("破損成功", kind)
		}
	}
}

// Test103Export は明示した未使用出力先だけへ実Go型の人工を保存します。
//
// 引数: t(*testing.T)、環境MINIDELAYED103_EXPORT(string)は試験器と新規出力先です。
// 返り値: ありません。通常はskipし、市場入力へは接続しません。
func Test103Export(t *testing.T) {
	root := os.Getenv("MINIDELAYED103_EXPORT")
	if root == "" {
		t.Skip("明示exportなし")
	}
	if _, e := os.Stat(root); !os.IsNotExist(e) {
		t.Fatal("出力先は新規だけ")
	}
	if e := os.MkdirAll(root, 0755); e != nil {
		t.Fatal(e)
	}
	for _, side := range []int{1, -1} {
		for _, unknown := range []bool{false, true} {
			f := wave103(t, side, unknown)
			data, e := json.MarshalIndent(f, "", "  ")
			if e != nil {
				t.Fatal(e)
			}
			name := filepath.Join(root, fmt.Sprintf("方向%d_未知ATR%t.json", side, unknown))
			if e = os.WriteFile(name, append(data, '\n'), 0644); e != nil {
				t.Fatal(e)
			}
		}
	}
}
