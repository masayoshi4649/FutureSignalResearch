# 公開3分足 → C/M/P → 停止可変幅会計の配送

未採番・非市場。module `github.com/masayoshi4649/SessionTradeExecuter/publicdelivery`、package `publicdelivery`。元publicchart f534・C/M/P 4a30・幅ec8d・会計c0bf・105の停止元は変更しない。

本moduleは、停止Go `publicchart.Publication` の **新しい3分公表** から、追加OHLC/EMA個別Knownを使ってFrameを作り、停止Pythonと同じC/M/Pを小Go読取器で評価する。値を作るのは既存値の比較と確定pivotの登録だけで、EMA/MACD/OHLCやSourceを再形成しない。Scalar11や5分snapshotの反復から3足を補完しない。

## 最小API

```go
p := NewPipeline()
d, err := p.Feed(publication, evaluationAt)
err = Send(d, widthBook) // OnWidthObservation/ResetWidthObservationのみ
err = p.Reset(at, "Last0/欠測等の出典付き理由", widthBook)
```

低水準の `FromPublication/Validate/NewTracker/Tracker.Feed/AsObservation` も公開する。`Receiver` は停止c0bfの公表保管/reset二関数だけであり、Sourceや金融Stepを呼べない。金融のLD10起動、Quantity、費用、予約、注文、約定をここで判定しない。通常2ATR/狭1ATRとLD10の閾値も変更しない。

`Delivery` は配送At・元Frame・C/M/P全結果・買売の `WidthObservation` を持つ。新公表だけ両方向を送り、同ID再送は `new=false,id` のみでBookへ再配送しない。初回/欠足/不良足のresetは公表保管より先にBookへ渡す。明示Last0 control等は `Reset` を使い、過去公表の同ID再送を復活させない。market sidecarや全board時計へ接続したruntimeは今回まだ作っていない。

## 数値と因果

- C：同場・同限月・180秒ずつ連続した異なる3公表。各足のEMA8/21が個別既知で、絶対間隔が2回strictに縮小。15分TrendKnownを追加要件にしない。
- M：直前2公表のhist個別既知。買いは今回hist−前hist<0、売りは>0。
- P：同じ公表済みOHLCから左右2本で確認した最新low/highを使う。左2はstrict、右2はtie可。**現在Pを評価してから** 当足で新たに確認したpivotを登録する。中心ID/終端、確認ID/終端、公表時刻を保存する。
- 欠足/場・限月変更/不良足は窓と構造を失効する。OHLC不足は構造を失効する。resetでlastを消さず、同pub内容変更・逆行・連続ordinal飛越を拒否する。Unknownはfalseへ変えない。
- 半開足の最後のSourceは `end−180 <= time < end`、line>0/index>=0。End/AvailableAt/TechnicalEnd/ID・OHLC形状を停止4a30と同じ規則で検査。評価時点より未来のend/availableは拒否する。
- ObservedClockは公表をdrainした入力上限。AvailableAt以上を要求するが、`ObservedClock<=評価At` は要求しない。真の受信時刻の証明とは呼ばない。`evaluationAt` は呼出側が実際に配送する時計で、形成に使った将来価格を過去へ戻してよい意味ではない。

Frame/ResultのSHAは停止ec8d `canonical_sha` と同じUTF-8/sort_keys形式。停止PythonはGo JSONを読むので、整数表記floatはJSON読取後のintに合わせる。非整数と指数表記はPythonの有限数形式へ正規化する。この対応もGo12全fieldと両方向型の照合対象で、金額へ許容を入れない。

## 非市場人工

1. 停止f534のGo型12公表（買売の別系列各6）をそのまま読み、Frame/C/M/P全fieldと両方向24入力を停止Python `to_frame/Tracker.feed/from_data` と比較。5本目で同足確認を先取りせず、6本目で前に公表したpivot喪失を使う。
2. 明示した手製制御型でreset・同ID・欠足・未知・後退・未来・OHLC破損を検査。これは新たなBank公表の形成を主張しない。
3. 新Bankへ明示手製価格列を入れた別人工を、停止c0bfの手製Source通知器具へ型接続。買売×W1/W2の4冊で、LD起動前は未消費、最初のLD起動markで既公表latestを消費し、reset後の同IDで復活しないことを確認。若いBankのC/Mはwarmup未知のままで、狭幅成立を捏造しない。自然Source・CSV・実場の全board/BBO出典結合は範囲外。

各買売系列は鏡像の手製器具であり独立市場例ではない。公表だけでBookへQuote/MTM/起動/注文を作らない。旧会計の全原行独立監査やW0市場対照の代用にしない。Rootから受領した105の実損失の大半がLD未起動側という帰属も、LD起動後だけの本部品で説明・改善した扱いにはしない。

`go test -json ./...` / `go vet ./...` / `go build ./...`。明示 `PUBLIC_DELIVERY_EXPORT` は小さな手製JSONの保存先だけ。`Python公開値と照合する.py <人工dir> <新証拠.json>` は停止Pythonの規則を直接importし、市場本文や金融を実行しない。

残件は、Rootによる新しい実場公表/reset sidecar、全board時計/当原行出典のbind、market条件固定、金融接続・実対照。今回それらの実行許可はない。早期起動への変更も別仮説であり本版には加えない。機会損失・MFE・退出後価格・新損益計算0。
