"""Go公開配送の手製値を停止4a30/ec8dへ全field接続する。"""
from dataclasses import asdict
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def sha(path):
    """
    機能: 明示したコード又は人工のSHA256を求める。
    引数: path(Path)は市場本文を含まない参照。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_module(name, path, expected):
    """
    機能: 停止コードを指紋で照合して読み込む。
    引数: name(str)、path(Path)、expected(str)はmodule名と実コード参照。
    返り値: ModuleTypeは固定純式。市場ファイルを開かない。
    """
    assert sha(path) == expected
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main():
    """
    機能: Go12公表と明示制御人工の全C/M/P・出典SHAをPythonで再計算する。
    引数: argv[1:3](str)は人工rootと新規証拠JSON。
    返り値: None。金融/Source/価格形成は実行しない。
    """
    bridge = load_module("停止f534の型射影", ROOT / "work/可変追尾向けの公開チャート/純式への型接続.py", "39a6ff72e94bdcb25f6344f8bb19fdeed8454fa9f7710737d0207e8a0efba18c")
    width = load_module("停止ec8dの型射影", ROOT / "work/一定利益後の収束可変幅の純式/幅と床の純state.py", "055db03ac7671fa1d18483efad3933f417bb1d1840db9c1ba838d53ebc2a0a44")
    source, out = Path(sys.argv[1]), Path(sys.argv[2])
    value = json.loads((source / "Go公開12の配送.json").read_text(encoding="utf-8"))
    trackers, differences = {}, []
    for i, case in enumerate(value["cases"]):
        tracker = trackers.setdefault(case["scene"], bridge.pure.Tracker())
        frame = bridge.to_frame(case["publication"])
        result = tracker.feed(frame)
        expected = {"frame": frame, "result": result, "buy": asdict(width.from_data(frame, result, 1)), "sell": asdict(width.from_data(frame, result, -1))}
        actual = {k: case["delivery"][k] for k in expected}
        if expected != actual:
            differences.append({"case": i, "expected": expected, "actual": actual})
    control = json.loads((source / "resetと欠足の型人工.json").read_text(encoding="utf-8"))
    tr = bridge.pure.Tracker()
    n = 0
    for i, event in enumerate(control["events"]):
        if "reset" in event:
            tr.reset(event["reset"])
        else:
            expected = tr.feed(event["frame"])
            n += 1
            if expected != event["result"]:
                differences.append({"control": i, "expected": expected, "actual": event["result"]})
    receipt = {"成功": not differences, "scope": "Go12手製公表のFrame/C/M/P全field/両方向WidthObservationと明示制御型だけ", "Go公開": len(value["cases"]), "両方向型": 2 * len(value["cases"]), "制御Frame": n, "不一致": differences, "入力SHA256": {p.name: sha(p) for p in source.glob("*.json")}, "停止4a30の再用": True, "停止ec8dfrom_dataの再用": True, "Source/金融/Raw/Native/市場実行": 0}
    with out.open("x", encoding="utf-8", newline="\n") as f:
        json.dump(receipt, f, ensure_ascii=False, indent=2)
        f.write("\n")
    if differences:
        raise SystemExit(1)
    print(json.dumps({"成功": True, "Go公開": len(value["cases"]), "両方向型": 24, "制御Frame": n, "SHA256": sha(out)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
