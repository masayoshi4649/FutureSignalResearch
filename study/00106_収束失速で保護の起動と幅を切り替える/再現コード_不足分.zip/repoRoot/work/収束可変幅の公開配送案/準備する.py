"""停止済み依存のmodule参照だけを新しい純配送moduleへ用意する。"""
from pathlib import Path


def main():
    """
    機能: 停止会計と公開チャートを参照するgo.mod/sumを作る。
    引数: なし。
    返り値: None。元停止/市場入力を変更しない。
    """
    here = Path(__file__).resolve().parent
    src = here.parent / "収束可変幅の保護会計案"
    mod = (src / "go.mod").read_text(encoding="utf-8-sig").replace("module github.com/masayoshi4649/SessionTradeExecuter/minivariableguard", "module github.com/masayoshi4649/SessionTradeExecuter/publicdelivery")
    mod += "\nrequire github.com/masayoshi4649/SessionTradeExecuter/minivariableguard v0.0.0\nreplace github.com/masayoshi4649/SessionTradeExecuter/minivariableguard => ../収束可変幅の保護会計案\nrequire github.com/masayoshi4649/SessionTradeExecuter/publicchart v0.0.0\nreplace github.com/masayoshi4649/SessionTradeExecuter/publicchart => ../可変追尾向けの公開チャート\n"
    (here / "go.mod").write_text(mod, encoding="utf-8")
    (here / "go.sum").write_bytes((src / "go.sum").read_bytes())


if __name__ == "__main__":
    main()
