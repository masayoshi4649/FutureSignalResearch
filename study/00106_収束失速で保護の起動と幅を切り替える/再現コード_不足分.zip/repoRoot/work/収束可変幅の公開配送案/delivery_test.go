package publicdelivery

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"

	finance "github.com/masayoshi4649/SessionTradeExecuter/minivariableguard"
	chart "github.com/masayoshi4649/SessionTradeExecuter/publicchart"
)

const artificialSHA = "a7419ce16a19c5b46b09ae8bd9394c8b3502692eb708b40b3505735ebedb7052"

// publicFixtures は停止f534のGo型12公表だけを読みます。
//
// 引数: t(*testing.T)は試験器。返り値: map[string][]Publicationは買売の手製公表です。市場本文を読みません。
func publicFixtures(t *testing.T) map[string][]chart.Publication {
	t.Helper()
	b, e := os.ReadFile("../可変追尾向けの公開チャート/人工_停止版/Go型の人工.json")
	if e != nil {
		t.Fatal(e)
	}
	h := sha256.Sum256(b)
	if hex.EncodeToString(h[:]) != artificialSHA {
		t.Fatal("元Go人工SHA差")
	}
	var v struct {
		Scenes map[string][]chart.Publication `json:"scenes"`
	}
	if e = json.Unmarshal(b, &v); e != nil {
		t.Fatal(e)
	}
	if len(v.Scenes) != 2 || len(v.Scenes["買い"]) != 6 || len(v.Scenes["売り"]) != 6 {
		t.Fatal("Go人工集合差")
	}
	return v.Scenes
}

// TestGoPublic12 は元Go12公表の全Frame/結果/両方向型を保存しpivot先取りを拒否します。
//
// 引数: t(*testing.T)、環境PUBLIC_DELIVERY_EXPORT(string)は試験器と明示人工dir。
// 返り値: ありません。値の新計算はC/M/PだけでEMA/OHLCを形成しません。
func TestGoPublic12(t *testing.T) {
	scenes := publicFixtures(t)
	cases := []map[string]any{}
	for _, name := range []string{"買い", "売り"} {
		pipe := NewPipeline()
		side := 1
		if name == "売り" {
			side = -1
		}
		for i, pub := range scenes[name] {
			d, e := pipe.Feed(pub, pub.At)
			if e != nil {
				t.Fatal(name, i, e)
			}
			role := d.Result.Buy
			if side < 0 {
				role = d.Result.Sell
			}
			if i == 4 && role.P.Known {
				t.Fatal("当足確認pivot先取り")
			}
			if i == 5 && (!role.P.Known || !*role.P.Passed || role.PriorPivot.CenterEnd != scenes[name][2].At || role.PriorPivot.ConfirmEnd != scenes[name][4].At) {
				t.Fatal("前公表pivot喪失", role)
			}
			cases = append(cases, map[string]any{"scene": name, "publication": pub, "delivery": d})
		}
		last := scenes[name][5]
		d, e := pipe.Feed(last, last.At)
		if e != nil || d.Result.New || d.Buy != nil || d.Sell != nil {
			t.Fatal("同ID再評価", e)
		}
		b, _ := json.Marshal(d.Result)
		var values map[string]any
		_ = json.Unmarshal(b, &values)
		if len(values) != 2 {
			t.Fatal("重複返り値型")
		}
	}
	if dir := os.Getenv("PUBLIC_DELIVERY_EXPORT"); dir != "" {
		b, _ := json.MarshalIndent(map[string]any{"scope": "停止f534のGo型12手製公表→Go C/M/P→停止会計境界型。市場/Source形成0", "cases": cases}, "", "  ")
		if e := os.WriteFile(filepath.Join(dir, "Go公開12の配送.json"), b, 0600); e != nil {
			t.Fatal(e)
		}
	}
}

// shiftedFrame は失効/欠足の検査だけに使う明示手製Frameを作ります。
//
// 引数: f(Frame)、seconds(float64)、ordinal(int)は元の手製型・時計差・順序。
// 返り値: Frameは値を補完しない制御人工。新たなBank公表の実証として使いません。
func shiftedFrame(f Frame, seconds float64, ordinal int) Frame {
	x := clone(f)
	x.End += seconds
	x.At += seconds
	x.TechnicalEnd += seconds
	x.AvailableAt += seconds
	x.ObservedClock += seconds
	x.Ordinal = ordinal
	x.ID = financeID(x.Session, x.Contract, x.End)
	if x.LastSource != nil {
		x.LastSource.Time += seconds
	}
	if x.OHLC != nil {
		x.OHLC.PublicationID = x.ID
	}
	return x
}

// financeID は公開識別の同じ三要素を返します。
//
// 引数: session/contract(string)、end(float64)は出典。返り値: stringは元Frameと同じJSON識別です。
func financeID(session, contract string, end float64) string {
	return finance.WidthPublicationID(session, contract, end)
}

// TestCMPControls はreset/同ID/欠足/warmup/未来・逆行を必要範囲で確認します。
//
// 引数: t(*testing.T)は手製制御型の試験器。
// 返り値: ありません。制御人工を実価格形成の成功としません。
func TestCMPControls(t *testing.T) {
	pubs := publicFixtures(t)["買い"]
	tracker := NewTracker()
	events := []map[string]any{}
	var last Frame
	for _, p := range pubs {
		f, e := FromPublication(p, p.At)
		if e != nil {
			t.Fatal(e)
		}
		r, e := tracker.Feed(f)
		if e != nil {
			t.Fatal(e)
		}
		events = append(events, map[string]any{"frame": f, "result": r})
		last = f
	}
	tracker.Reset("手製Last0")
	events = append(events, map[string]any{"reset": "手製Last0"})
	r, e := tracker.Feed(last)
	if e != nil || r.New {
		t.Fatal("reset後同pub復活")
	}
	events = append(events, map[string]any{"frame": last, "result": r})
	next := shiftedFrame(last, 180, last.Ordinal+1)
	r, e = tracker.Feed(next)
	if e != nil || r.C.Known || r.Buy.M.Known || r.Buy.P.Known {
		t.Fatal("reset後の窓復活", e)
	}
	events = append(events, map[string]any{"frame": next, "result": r})
	gap := shiftedFrame(next, 360, next.Ordinal+1)
	r, e = tracker.Feed(gap)
	if e != nil || r.ResetReason == "" {
		t.Fatal("欠足reset", e)
	}
	events = append(events, map[string]any{"frame": gap, "result": r})
	unknown := shiftedFrame(gap, 180, gap.Ordinal+1)
	unknown.DataKnown = false
	unknown.Known = Known{}
	unknown.OHLC = nil
	unknown.LastSource = nil
	r, e = tracker.Feed(unknown)
	if e != nil || r.ResetReason != "不良/空の確定足" || r.C.Known {
		t.Fatal("不良足未知", e)
	}
	events = append(events, map[string]any{"frame": unknown, "result": r})
	for _, name := range []string{"逆行", "同ID改変", "ordinal飛越", "未来source", "未来公表", "15分のみ", "OHLC差"} {
		t.Run(name, func(t *testing.T) {
			tr := NewTracker()
			f, _ := FromPublication(pubs[0], pubs[0].At)
			_, _ = tr.Feed(f)
			switch name {
			case "逆行":
				x := shiftedFrame(f, -180, f.Ordinal+1)
				if _, e := tr.Feed(x); e == nil {
					t.Fatal("逆行受理")
				}
			case "同ID改変":
				f.EMA8++
				if _, e := tr.Feed(f); e == nil {
					t.Fatal("同ID改変受理")
				}
			case "ordinal飛越":
				f = shiftedFrame(f, 180, f.Ordinal+2)
				if _, e := tr.Feed(f); e == nil {
					t.Fatal("ordinal飛越受理")
				}
			default:
				p := clone(pubs[1])
				at := p.At
				if name == "未来source" {
					p.Snapshot.Legacy.Three.LastSource.Time = p.At
				}
				if name == "未来公表" {
					at = p.At - 1
				}
				if name == "15分のみ" {
					p.Three = false
					p.Fifteen = true
				}
				if name == "OHLC差" {
					p.Snapshot.Three.OHLC.Close++
				}
				if _, e := FromPublication(p, at); e == nil {
					t.Fatal("型/未来破損受理")
				}
			}
		})
	}
	if dir := os.Getenv("PUBLIC_DELIVERY_EXPORT"); dir != "" {
		b, _ := json.MarshalIndent(map[string]any{"scope": "既存Go12からの明示手製制御型だけ。補完したBank公表ではない", "events": events}, "", "  ")
		if e := os.WriteFile(filepath.Join(dir, "resetと欠足の型人工.json"), b, 0600); e != nil {
			t.Fatal(e)
		}
	}
}

// TestIndividualKnownAndObservedClock は3分個別Knownとdrain上限を混同しません。
//
// 引数: t(*testing.T)は公開型だけの試験器。返り値: ありません。旧TrendKnownをCの前提へ加えません。
func TestIndividualKnownAndObservedClock(t *testing.T) {
	p := clone(publicFixtures(t)["買い"][5])
	p.Snapshot.Legacy.Chart.Technical.TrendKnown = false
	p.Snapshot.Legacy.Three.ObservedClock = p.At + 300
	f, e := FromPublication(p, p.At)
	if e != nil || f.Known.EMA8 != p.Snapshot.Three.EMA8Known || f.Known.EMA21 != p.Snapshot.Three.EMA21Known || f.ObservedClock <= p.At {
		t.Fatal("3分個別Known/ObservedClock", e)
	}
}
