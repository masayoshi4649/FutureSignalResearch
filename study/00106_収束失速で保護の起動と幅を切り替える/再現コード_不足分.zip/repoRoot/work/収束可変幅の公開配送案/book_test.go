package publicdelivery

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"testing"

	finance "github.com/masayoshi4649/SessionTradeExecuter/minivariableguard"
	chart "github.com/masayoshi4649/SessionTradeExecuter/publicchart"
)

type handStep struct {
	Observation finance.Observation   `json:"observation"`
	SourceLine  int64                 `json:"source_line"`
	Batches     []finance.NativeBatch `json:"batches"`
}
type handTimer struct {
	At      float64               `json:"at"`
	Batches []finance.NativeBatch `json:"batches"`
}
type handEvent struct {
	Kind  string `json:"kind"`
	Index int    `json:"index"`
}
type handFixture struct {
	Session finance.Session `json:"session"`
	Scope   string          `json:"scope"`
	Steps   []handStep      `json:"steps"`
	Timers  []handTimer     `json:"timers"`
	Grids   []float64       `json:"grids"`
	Events  []handEvent     `json:"events"`
}

// TestBookLatestActivation は新Bankの手製価格公表を停止Bookへ型配送します。
//
// 引数: t(*testing.T)、環境PUBLIC_DELIVERY_EXPORT(string)は試験器と人工先。
// 返り値: ありません。金融通知は停止c0bfの非市場器具だけで自然Sourceを作りません。
func TestBookLatestActivation(t *testing.T) {
	details := []map[string]any{}
	for _, side := range []int{1, -1} {
		path := fmt.Sprintf("../収束可変幅の保護会計案/人工_停止版/W0方向%d_未知false.json", side)
		raw, e := os.ReadFile(path)
		if e != nil {
			t.Fatal(e)
		}
		var value struct {
			Fixture handFixture `json:"fixture"`
		}
		if e = json.Unmarshal(raw, &value); e != nil {
			t.Fatal(e)
		}
		f := value.Fixture
		g := f.Session.Start + 1800
		bank, e := chart.New(chart.Scene{ID: f.Session.ID, Contract: "手製限月", Start: f.Session.Start}, nil)
		if e != nil {
			t.Fatal(e)
		}
		pipe := NewPipeline()
		books := []*finance.ActualBook{}
		for _, policy := range []string{"W1", "W2"} {
			b, e := finance.NewWidthBook(f.Session, finance.ActorConfig{Policy: "P0", ActivationPolicy: finance.ActivationLD10, EntryTiming: "B5Q"}, policy, "手製限月")
			if e != nil {
				t.Fatal(e)
			}
			books = append(books, b)
		}
		publicCount := 0
		var lastPub *chart.Publication
		deliver := func(batch chart.Batch, at float64) {
			for _, pub := range batch.Publications {
				if !pub.Three {
					continue
				}
				d, e := pipe.Feed(pub, at)
				if e != nil {
					t.Fatal(e)
				}
				for _, b := range books {
					if e = Send(d, b); e != nil {
						t.Fatal(e)
					}
				}
				publicCount++
				p := clone(pub)
				lastPub = &p
			}
		}
		// ----------------------------------------
		// 暖機価格は明示した手製列。金融の出生より前で、EMA/足値を補完していない。
		index := int64(0)
		for i := 0; i < 10; i++ {
			at := f.Session.Start + float64(i*180) + 1
			q := chart.Quote{Time: at, Index: index, Line: index + 1, Last: 1000 + float64(side*i), Bid: 990 + float64(side*i), Ask: 1010 + float64(side*i), Valid: true}
			batch, e := bank.Step(q, nil)
			if e != nil {
				t.Fatal(e)
			}
			deliver(batch, at)
			index++
		}
		activated := map[string]bool{}
		for _, ev := range f.Events {
			at := 0.0
			grids := []float64(nil)
			switch ev.Kind {
			case "quote":
				at = f.Steps[ev.Index].Observation.Time
			case "grid":
				at = f.Grids[ev.Index]
				grids = []float64{at}
			case "timer":
				at = f.Timers[ev.Index].At
			}
			batch, e := bank.AdvanceObserved(at, grids)
			if e != nil {
				t.Fatal(e)
			}
			deliver(batch, at)
			if ev.Kind == "quote" && at == g+6 {
				if lastPub == nil {
					t.Fatal("元公表なし")
				}
				receivers := []Receiver{}
				for _, b := range books {
					receivers = append(receivers, b)
				}
				if e := pipe.Reset(at, "手製Last0 control", receivers...); e != nil {
					t.Fatal(e)
				}
				d, e := pipe.Feed(*lastPub, at)
				if e != nil || d.Result.New {
					t.Fatal("制御後同ID復活", e)
				}
				for _, b := range books {
					beforeCount := b.WidthAudit().Observations
					if e = Send(d, b); e != nil {
						t.Fatal(e)
					}
					if b.WidthAudit().Observations != beforeCount {
						t.Fatal("重複のBook再配送")
					}
				}
			}
			if ev.Kind == "quote" {
				s := f.Steps[ev.Index]
				o := s.Observation
				batch, e = bank.Step(chart.Quote{Time: at, Index: index, Line: s.SourceLine, Last: o.Last, Bid: o.Bid, Ask: o.Ask, Valid: o.Last > 0}, nil)
				if e != nil {
					t.Fatal(e)
				}
				deliver(batch, at)
				index++
			}
			for _, b := range books {
				before := b.WidthAudit()
				var e error
				switch ev.Kind {
				case "quote":
					s := f.Steps[ev.Index]
					e = b.OnNativeStep(s.Observation, s.SourceLine, s.Batches)
				case "grid":
					e = b.OnEntryGrid(at)
				case "timer":
					e = b.OnNativeForce(at, f.Timers[ev.Index].Batches)
				}
				if e != nil {
					t.Fatal(e)
				}
				a := b.WidthAudit()
				if ev.Kind == "quote" && at == g+4 && a.Positions[0].State.Consumed != nil {
					t.Fatal("LD起動前に公表消費")
				}
				if ev.Kind == "quote" && at == g+5 {
					p := a.Positions[0]
					if !p.State.Active || p.State.Consumed == nil || *p.State.Consumed != finance.WidthPublicationID(f.Session.ID, "手製限月", g) || before.Positions[0].State.Active {
						t.Fatal("初起動latest利用", a)
					}
					activated[a.Policy] = true
				}
				if ev.Kind == "quote" && at == g+6 && a.Positions[0].State.Latest != nil {
					t.Fatal("Book reset後latest復活")
				}
			}
		}
		for _, b := range books {
			r, e := b.Finish()
			if e != nil {
				t.Fatal(e)
			}
			a := b.WidthAudit()
			if !activated[a.Policy] || !r.Complete || r.Totals.EntryQuantity == 0 || a.Observations == 0 {
				t.Fatal("型配送非0/初起動/完結")
			}
			details = append(details, map[string]any{"side": side, "policy": a.Policy, "publications": publicCount, "book": r, "audit": a, "latest_at_first_activation": finance.WidthPublicationID(f.Session.ID, "手製限月", g)})
		}
	}
	if dir := os.Getenv("PUBLIC_DELIVERY_EXPORT"); dir != "" {
		data, _ := json.MarshalIndent(map[string]any{"scope": "fresh Bank手製価格列→C/M/P→停止会計c0bfへの型配送。自然Source/Raw/市場/全board再生ではない", "details": details}, "", "  ")
		if e := os.WriteFile(filepath.Join(dir, "Book初起動の型接続.json"), data, 0600); e != nil {
			t.Fatal(e)
		}
	}
}
