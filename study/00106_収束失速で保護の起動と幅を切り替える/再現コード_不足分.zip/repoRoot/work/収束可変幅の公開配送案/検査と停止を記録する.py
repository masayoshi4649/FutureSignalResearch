"""停止純部品の公開配送を非市場人工と指紋へ結ぶ。"""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def sha(path):
    """
    機能: 指定コード/人工/停止metadataのSHA256を求める。
    引数: path(Path)は市場本文を含まない参照。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def label(path):
    """
    機能: repo内を相対、外を絶対pathとして表す。
    引数: path(Path)は参照。
    返り値: strは再読できる名前。
    """
    try:
        return path.relative_to(ROOT).as_posix()
    except ValueError:
        return str(path)


def save(path, value):
    """
    機能: 既存先へ上書きせず証拠JSONを保存する。
    引数: path(Path)、value(dict)は新規先と証拠。
    返り値: None。
    """
    with path.open("x", encoding="utf-8", newline="\n") as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write("\n")


def command(args, **extra):
    """
    機能: Go/Pythonの非市場人工だけを実行する。
    引数: args(list[str])、extra(dict)はコマンドと環境。
    返り値: CompletedProcessは成功した結果。失敗は例外。
    """
    r = subprocess.run(args, cwd=HERE, capture_output=True, encoding="utf-8", **extra)
    if r.returncode:
        raise RuntimeError({"command": args, "exit": r.returncode, "stdout": r.stdout, "stderr": r.stderr})
    return r


def main():
    """
    機能: 元停止不変・Go人工・Python全field・vet/buildを新停止へ保存する。
    引数: なし。
    返り値: None。実場sidecar/Raw/CSV/Source/金融本番は実行しない。
    """
    assert not (HERE / "停止.json").exists()
    check, final = HERE / "検査", HERE / "人工_停止版"
    check.mkdir(exist_ok=True)
    final.mkdir(exist_ok=True)
    assert not any(final.iterdir())
    refs = {}
    stops = {
        "work/可変追尾向けの公開チャート/停止.json": "f534631e19d8c04fa6f7beefe295178cd432ae1f099d1b9ef69781b5e4fccad6",
        "work/収束可変幅の公開側データ準備/停止.json": "4a30b0ddd1bd22941158b1cfa80d552a4677a11c4ffaf2a5b82c3a9527cad25f",
        "work/一定利益後の収束可変幅の純式/停止.json": "ec8d3e39795ea5b41cac5fd89bbfb8d409fdbff17848499248c4dea9c2c99f6b",
        "work/収束可変幅の保護会計案/停止.json": "c0bfc8cfc8f870e99f9c994d26173b4295b42dad1fde872a5b5ee91b7c09317a",
        "work/105四場Sourceの再形成/停止.json": "f52676b0cc55fe2fbdbb0f6524161950af4babbb5891513723a01b5f2618c28a",
        "work/105四場の時計とLD10確認/停止.json": "0a41056d1a9d0c14d13e0bf23d3f78fe7ce1ffb42b13dd2dfb898d8f81802299",
    }
    for name, expected in stops.items():
        sp = ROOT / name
        assert sha(sp) == expected
        refs[name] = expected
        d = json.loads(sp.read_text(encoding="utf-8-sig"))
        owned = d.get("所有コードSHA256", d.get("所有SHA256", d.get("所有ファイルSHA256", {})))
        assert owned
        for p, h in owned.items():
            assert sha(ROOT / p) == h, p
            refs[p] = h
    for name in ["work/可変追尾向けの公開チャート/人工_停止版/Go型の人工.json", "work/収束可変幅の保護会計案/人工_停止版/W0方向1_未知false.json", "work/収束可変幅の保護会計案/人工_停止版/W0方向-1_未知false.json"]:
        refs[name] = sha(ROOT / name)
    dirs = command(["go", "list", "-deps", "-f", "{{if not .Standard}}{{.Dir}}{{end}}", "./..."]).stdout.splitlines()
    for directory in dirs:
        d = Path(directory)
        if d == HERE:
            continue
        for p in sorted(d.glob("*.go")):
            refs[label(p)] = sha(p)
        for name in ["go.mod", "go.sum"]:
            p = d / name
            if p.is_file():
                refs[label(p)] = sha(p)
    before = dict(refs)
    save(HERE / "元と依存の前指紋.json", before)
    # ----------------------------------------
    env = dict(os.environ, PUBLIC_DELIVERY_EXPORT=str(final))
    test = command(["go", "test", "-count=1", "-json", "./..."], env=env)
    log = check / "最終Go_test.jsonl"
    log.write_text(test.stdout, encoding="utf-8", newline="\n")
    events = [json.loads(s) for s in test.stdout.splitlines() if s]
    assert any(e.get("Action") == "pass" and "Test" not in e for e in events)
    names = [e["Test"] for e in events if e.get("Action") == "pass" and "Test" in e]
    vet = command(["go", "vet", "./..."])
    build = command(["go", "build", "./..."])
    command([sys.executable, "-B", "-X", "utf8", str(HERE / "Python公開値と照合する.py"), str(final), str(check / "停止版Python全field照合.json")])
    result = json.loads((check / "停止版Python全field照合.json").read_text(encoding="utf-8"))
    assert result["成功"] and not result["不一致"]
    artifacts = {label(p): sha(p) for p in final.glob("*.json")}
    assert len(artifacts) == 3
    after = {name: sha(Path(name) if Path(name).is_absolute() else ROOT / name) for name in before}
    assert before == after
    save(HERE / "元と依存の前後照合.json", {"成功": True, "前": before, "後": after, "前後不変": True, "対象範囲": "停止owned/Go依存コードと明示された非市場人工のみ。実場価格参照は開かない"})
    provenance = {"成功": True, "元停止": stops, "実装対応": {"cmp.go": "4a30 from_publication/validate/Trackerを固定Go公開型へ移植。数値指標形成0", "delivery.go": "ec8d from_dataの型射影とcanonical_shaのGo JSON読取型を再現。金融はReceiver二APIだけ", "book_test.go": "f534公開Bankとc0bfの手製Source器具の型接続。Source自然形成/全board再生ではない"}, "原則": ["3分個別Known/OHLCを追加公開型から取得", "P評価後に当足確認pivot登録", "resetでlastを消さず旧ID復活なし", "Frame/結果SHAを含む両方向入力全fieldをPythonへ照合", "LD10起動/数量/費用/幅/床/注文は既存停止会計の責務"], "Source/旧金融/105の変更": False}
    save(HERE / "由来と接続範囲.json", provenance)
    receipt = {"成功": True, "test/vet/build": {"test": 0, "vet": vet.returncode, "build": build.returncode}, "Go成功top": sum("/" not in n for n in names), "小試験込成功": len(names), "Goログ": {"path": label(log), "SHA256": sha(log)}, "Go公開": 12, "PythonとC/M/P全field差": 0, "両方向WidthObservation": 24, "両方向全field/出典SHA差": 0, "制御Frame": 10, "Book型接続非0": 4, "Book型scope": "手製価格を新Bankで形成。手製Source器具を配送した買売W1/W2。若いBankのC/Mは未知のまま、初LD起動でlatestを消費。reset後同ID復活なし", "原行市場出典bind": "未実施", "Python照合": {"path": label(check / "停止版Python全field照合.json"), "SHA256": sha(check / "停止版Python全field照合.json")}, "停止版人工SHA256": artifacts, "前後不変": True, "参照数": len(before), "Raw/CSV/Tape/Native/Source市場本文読取": 0, "金融本番実行": 0}
    save(check / "人工確認.json", receipt)
    owned = {label(p): sha(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name != "停止.json"}
    stop = {"成功": True, "scope": "未採番・非市場。停止publicchartの新3分公表→停止同式C/M/P→停止会計c0bfの公表/reset二API", "module": "github.com/masayoshi4649/SessionTradeExecuter/publicdelivery", "所有コードSHA256": owned, "元停止": stops, "人工確認": {"path": label(check / "人工確認.json"), "SHA256": sha(check / "人工確認.json")}, "test/vet/build": {"test": 0, "vet": 0, "build": 0}, "旧停止/依存前後不変": True, "前後確認": {"path": label(HERE / "元と依存の前後照合.json"), "SHA256": sha(HERE / "元と依存の前後照合.json")}, "Source/LD10/金融式変更": False, "実場sidecar生成": 0, "Raw/CSV/Tape/Native/Source市場本文読取": 0, "金融本番実行": 0, "未実施": ["実場全publication/reset sidecar", "全board/Source/価格出典との市場bind", "市場W0対照/損益比較", "早期保護起動への変更", "採番/新市場条件固定"], "実行物": "Go libraryのみ。市場CLIなし", "限界": "新Go12と手製制御型/価格/Source器具の接続まで。市場成績/全原行別engine独立監査を表さない"}
    save(HERE / "停止.json", stop)
    print(json.dumps({"停止": label(HERE / "停止.json"), "SHA256": sha(HERE / "停止.json"), "所有": len(owned), "Go成功top": receipt["Go成功top"], "小試験": len(names), "参照": len(before)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
