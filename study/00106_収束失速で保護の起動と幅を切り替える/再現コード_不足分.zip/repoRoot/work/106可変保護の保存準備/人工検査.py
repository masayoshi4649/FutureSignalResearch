"""停止Go公開型だけで106保存境界と破損拒否を検査する。"""

import argparse
from collections import Counter
import copy
from decimal import Decimal
import importlib.util
import json
from pathlib import Path


OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[1]
SPEC = importlib.util.spec_from_file_location("106保存人工対象", OWN / "集計.py")
M = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)
CORE = ROOT / "work/106可変保護の市場接続準備"
FINANCE = ROOT / "work/収束失速で保護を早める会計案"
CORE_STOP = "c465bd1696fe1e5d2f4c9b299712866c96b73b4126bf4883245acc47fec154f3"
FINANCE_STOP = "68011a9c44cbf88f765216493d331849cb80efd95cfdf63d750bbfafe53e02c5"


def require_failure(name, callback):
    """
    機能: 一つの破損が検査を通過しないことを確認する。
    引数: name(str)、callback(callable)は破損名と呼出し。
    返り値: dictは拒否した診断。例外なしは人工失敗。
    """
    try:
        callback()
    except (ValueError, KeyError, TypeError, IndexError) as error:
        return {"名前": name, "拒否": True, "理由": str(error)}
    raise ValueError("破損を受理:" + name)


def verify_artifact(path, stop):
    """
    機能: 停止に宣言されたGo型人工のbytesを読取前に固定する。
    引数: path(Path)、stop(dict)は人工と成功停止。
    返り値: strは実指紋。市場成果物を代用しない。
    """
    got = M.digest(path)
    maps = [stop.get("人工確認", {}).get("人工SHA256", {}), stop.get("人工SHA256", {})]
    if "人工確認" in stop and isinstance(stop["人工確認"], dict) and stop["人工確認"].get("path"):
        p = ROOT / stop["人工確認"]["path"]
        if "SHA256" in stop["人工確認"]:
            M.equal(M.digest(p), stop["人工確認"]["SHA256"], "Go人工確認証拠SHA")
        proof = M.load(p)
        maps.extend([proof.get("人工SHA256", {}), proof.get("停止版人工SHA256", {})])
    entries = {str((ROOT / k).resolve()): v for one in maps for k, v in one.items()}
    M.equal(entries.get(str(path.resolve())), got, "停止Go型人工SHA")
    return got


def run(out):
    """
    機能: Core80/専用E32/型出力/必要破損だけを検査し新証拠を保存する。
    引数: out(Path)は新規人工結果dir。
    返り値: dictは件数。不正規な金融期待値を自作しない。
    """
    M.need(not out.exists(), "人工先は新規")
    M.equal(M.digest(CORE / "停止.json"), CORE_STOP, "Core停止")
    M.equal(M.digest(FINANCE / "停止.json"), FINANCE_STOP, "E金融停止")
    cs, fs = M.load(CORE / "停止.json"), M.load(FINANCE / "停止.json")
    before = {str(CORE / "停止.json"): CORE_STOP, str(FINANCE / "停止.json"): FINANCE_STOP}
    for stop in (cs, fs):
        for name, want in stop["所有コードSHA256"].items():
            p = (ROOT / name).resolve()
            M.equal(M.digest(p), want, "停止所有不変")
            before[str(p)] = want
    for mod in (M, M.PREVIOUS, M.PREVIOUS.BASE, M.OLD, M.GRID, M.BASE, M.PUBLIC, M.PUBLIC.pure):
        p = Path(mod.__file__).resolve(); before[str(p)] = M.digest(p)
    out.mkdir(parents=True)
    details, api, refusals, originals, rows = [], Counter(), [], [], []
    for path in sorted((CORE / "人工_停止版").glob("方向*.json")):
        before[str(path)] = verify_artifact(path, cs)
        v = M.load(path)
        original = copy.deepcopy(v)
        registry = M.registry_from_records(v["records"], v["output"])
        checked = M.inspect_scene(v["output"], registry, artificial=True)
        current_rows = M.scene_rows(v["output"], checked)
        M.equal([r["key"] for r in current_rows], list(M.KEYS), "外20の場別保存")
        rows.extend(current_rows)
        for k in M.KEYS:
            M.need(checked[k]["counts"]["positions"] > 0, "Core20全非0")
        target = out / path.stem
        target.mkdir()
        resources = M.save_viewer(v["output"], target, "手製APIの未使用市場参照")
        M.equal(len(resources), 20, "外20Viewer形式")
        for resource in resources:
            actual = [json.loads(line, parse_float=Decimal) for line in (target / resource["pnl_path"]).read_text(encoding="utf-8").splitlines()]
            expected = M.BASE.viewer_trades(v["output"]["books"][resource["method_id"]])
            M.equal(actual, expected, "Viewer保存再読と元約定全値")
        M.BASE.write_json(target / "一覧.resources.json", {"schema_version": 1, "path_base": "catalog", "resources": resources})
        M.equal(v, original, "Core入力深い不変")
        details.append({"人工": path.name, "会計": 20, "非0": 20, "Viewer形式": 20, "公表C/M/P": registry.diagnostics, "保存出典公表": len(registry)})
        originals.append((v, registry))
    M.equal(len(details), 4, "Core四鏡像/助走")
    summary, diagnosis = M.aggregate(rows)
    M.equal(set(summary), set(M.KEYS), "集計20本名")
    M.BASE.write_json(out / "型人工の集計.json", {"scope": "同一手製Dayを買売/助走の四器具へ反復した型確認。四つの独立市場場数ではない", "集計": summary, "実現診断": diagnosis})
    sample = None
    for path in sorted((FINANCE / "人工_停止版").glob("方向*.json")):
        before[str(path)] = verify_artifact(path, fs)
        v = M.load(path); original = copy.deepcopy(v)
        checked = M.inspect_api(v)
        M.need(checked["counts"]["positions"] > 0, "E API非0")
        M.equal(v, original, "E API深い不変")
        api["books"] += 1
        for a in v["early_audit"]["positions"]:
            api[a["trigger"]] += 1
        if sample is None and v["early_audit"]["positions"][0]["trigger"] == "early_warning":
            sample = v
    M.equal(dict(api), {"books": 32, "early_warning": 16, "normal_ld10": 16}, "専用E32 scope")
    def api_bad(name, edit):
        """
        機能: E32の実Go型一件へ単一破損を加え拒否を確認する。
        引数: name(str)、edit(callable)は破損名と独立copy編集。
        返り値: None。元artifactは変更しない。
        """
        v = copy.deepcopy(sample); edit(v)
        refusals.append(require_failure(name, lambda: M.inspect_api(v)))
    api_bad("EをLDへ偽装", lambda v: v["book"]["config"].update(activation_policy="LD10"))
    api_bad("E閾値改変", lambda v: v["early_audit"]["positions"][0].update(early_threshold_yen=1))
    api_bad("通常優先を偽称", lambda v: v["early_audit"]["positions"][0].update(trigger="normal_ld10"))
    api_bad("E起動出典欠落", lambda v: v["early_audit"].update(positions=[]))
    api_bad("未知警戒を支持", lambda v: v["early_audit"]["positions"][0]["observation"].update(c={"known": False, "passed": None}))
    api_bad("未来公表", lambda v: v["early_audit"]["positions"][0]["observation"].update(available_at=10**12))
    api_bad("狭幅理由の混同", lambda v: v["book"]["positions"][0].update(activation_reason="LD10"))
    api_bad("最終床緩和", lambda v: v["width_audit"]["positions"][0]["state"].update(floor_points=-1))
    api_bad("未起動へ狭幅", lambda v: v["width_audit"]["positions"][0]["state"].update(active=False))
    api_bad("幅の生ATR破損", lambda v: v["width_audit"]["positions"][0]["state"].update(atr_lock=41))
    api_bad("初狭幅の必要未知", lambda v: v["width_audit"]["positions"][0].update(first_narrow_condition={"known": False, "passed": None}))
    api_bad("幅counter破損", lambda v: v["width_audit"].update(updates=0))
    api_bad("半円費用破損", lambda v: v["book"]["fills"][0].update(fee_yen=Decimal("0.1")))
    api_bad("要求同原行fill", lambda v: v["book"]["fills"][0]["quote"].update(index=0))
    base, reg = originals[0]
    def core_bad(name, edit):
        """
        機能: Core全型に単一破損を与える。
        引数: name(str)、edit(callable)は破損名と編集。
        返り値: None。元の公開根拠台帳を検査に用いる。
        """
        v = copy.deepcopy(base); edit(v)
        refusals.append(require_failure(name, lambda: M.inspect_scene(v["output"], reg, artificial=True)))
    core_bad("E会計欠落", lambda v: v["output"]["books"].pop("E1_C0_D0"))
    core_bad("一公表を20倍計上", lambda v: v["output"]["public_diagnostics"].update(new_three=460))
    core_bad("Raw/FeaturesIndex混同の件数", lambda v: v["output"]["counts"].update(raw_boards=0))
    core_bad("市場goldenへ人工偽装", lambda v: v["output"]["w0_control"].update(history_class="old_saved_58"))
    core_bad("幅出典SHA破損", lambda v: v["output"]["width_audits"]["W1_C0_D0"]["positions"][0]["state"]["latest"].update(frame_sha256="c" * 64))
    v = copy.deepcopy(base)
    pub = next(r for r in v["records"] if r["kind"] == "publication")
    pub["delivery"]["result"]["C"] = {"known": True, "passed": True}
    refusals.append(require_failure("保存CMPの事後改変", lambda: M.registry_from_records(v["records"], v["output"])))
    v = copy.deepcopy(base)
    pub = next(r for r in v["records"] if r["kind"] == "publication")
    pub["publication"]["snapshot"]["closed_three"]["publication_id"]["bar_end"] += 1
    refusals.append(require_failure("公開IDの別足化", lambda: M.registry_from_records(v["records"], v["output"])))
    manifest = M.load(ROOT / "work/106入力と既存Sourceの整理/標準入力台帳_70場_候補.json")
    config = {"version": 1, "trial": 106, "fixed": True, "seed_policy": "first_cold_then_contract_carry", "core_stop": {"path": "手製Core停止", "sha256": CORE_STOP},
              "configs": [{"policy": p, "slip_pts": c, "delay_seconds": d} for p in M.POLICIES for c in (0, 5) for d in (0, 1)]}
    ref = {"path": "手製未読ファイル", "sha256": "a" * 64}
    comp = {"version": 1, "trial": 106, "stage": "full70", "success": True, "condition_sha256": "b" * 64,
            "sessions": 70, "books_per_scene": 20, "books": 1400, "unchanged": True, "before": {"手製": "c" * 64}, "after": {"手製": "c" * 64},
            "source_reexecuted": False, "features_recomputed": True, "charts_recomputed": True, "financial_executed": True,
            "seed_policy": config["seed_policy"], "first2": ref,
            "results": [{"session": s["id"], "books": 20, "w0_control_books": 4, "control_kind": "same_input_old103" if 54 <= i < 66 else "provided_old_book",
                         "native": ref, "sidecar_header": ref, "sidecar_records": ref} for i, s in enumerate(manifest["sessions"])]}
    M.validate_completion(config, comp, manifest, "full70", "b" * 64)
    def metadata_bad(name, edit):
        """
        機能: 市場本文を持たないmetadataで成功前提の拒否を確認する。
        引数: name(str)、edit(callable)は破損名と編集。
        返り値: None。市場FileRef本文は開かない。
        """
        c = copy.deepcopy(comp); edit(c)
        refusals.append(require_failure(name, lambda: M.validate_completion(config, c, manifest, "full70", "b" * 64)))
    metadata_bad("金融未完了", lambda c: c.update(success=False))
    metadata_bad("同条件違反", lambda c: c.update(condition_sha256="d" * 64))
    metadata_bad("1400会計欠落", lambda c: c.update(books=1399))
    metadata_bad("70場重複", lambda c: c["results"][1].update(session=c["results"][0]["session"]))
    metadata_bad("Source再形成の混同", lambda c: c.update(source_reexecuted=True))
    metadata_bad("新12に旧保存golden", lambda c: c["results"][54].update(control_kind="provided_old_book"))
    metadata_bad("前後差を無視", lambda c: c.update(after={"手製": "d" * 64}))
    metadata_bad("sidecar未固定", lambda c: c["results"][0].update(sidecar_records={"path": "", "sha256": "a" * 64}))
    metadata_bad("full前のfirst2なし", lambda c: c.pop("first2"))
    # 実入口guardは小metadataだけを作り、Native読取へ進めないことを確認する。
    meta = out / "未固定guard"; meta.mkdir()
    M.BASE.write_json(meta / "condition.json", {"version": 1, "trial": 106, "fixed": False})
    M.BASE.write_json(meta / "completion.json", {"success": False})
    fixed = {"version": 1, "trial": 106, "fixed": True, "stage": "first2",
             "condition": {"path": "condition.json", "sha256": M.digest(meta / "condition.json")},
             "completion": {"path": "completion.json", "sha256": M.digest(meta / "completion.json")},
             "code": {"path": str(OWN / "集計.py"), "sha256": M.digest(OWN / "集計.py")}}
    M.BASE.write_json(meta / "fixed.json", fixed)
    refusals.append(require_failure("未固定Root条件はNative読取前拒否", lambda: M.prepare(meta / "fixed.json", M.digest(meta / "fixed.json"), meta / "出力禁止")))
    M.need(not (meta / "出力禁止").exists(), "未固定に結果dirを作らない")
    after = {name: M.digest(Path(name)) for name in before}
    M.equal(after, before, "全人工入力/元コード前後不変")
    proof = {"成功": True, "Core": details, "Core非0会計": 80, "E専用API": dict(api), "合計会計": 112,
             "Viewer形式": 80, "破損拒否": refusals, "拒否数": len(refusals), "metadata正常": "70/1400・既存58対新12・本文なし",
             "入力前SHA256": before, "入力後SHA256": after, "前後不変": True, "市場/Raw/CSV/旧Native/新金融実行": 0,
             "限界": "Core80のE早期発動非0は保証せずAPI32の早期16/通常16と別scope。公表C/M/Pは再評価するが価格指標やSourceは形成せず、全quote別金融engineの独立再生でもない"}
    M.BASE.write_json(out / "人工確認.json", proof)
    return {"成功": True, "Core会計": 80, "EAPI会計": 32, "Viewer形式": 80, "拒否": len(refusals)}


def main():
    """
    機能: 人工出力を新規dirへ保存する。
    引数: --out(Path)は新規証拠先。
    返り値: None。実市場のCLIへ切替しない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(run(args.out.resolve()), ensure_ascii=False))


if __name__ == "__main__":
    main()
