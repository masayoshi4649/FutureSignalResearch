# 106のW/E保存会計と公開根拠の検査

市場未実行の準備版。`集計.py` は固定105（5192）→104（0409）→103（aa1f）→95（193a）→94（7c0c）の保存算術をSHA確認して再用する。Source/金融/価格指標を再形成せず、既存停止・正式コードは変更しない。

外KeyはW0/W1/W2/E1/E2×C0/C5×D0/D1の20個。内Book.Key/ConfigはW系のLD10、E系のE1/E2をそのまま検査する。EをLD10へ変更して旧検査を通す口はない。旧94へ渡す投影は**実Policy=P0の共通会計**とB5Q追加欄の分離だけであり、起動は元の実E玉と専用auditへ接続する。元関数本文は`types.FunctionType`の名前空間差し替えで再用する。

## 検査範囲

- 注文/Fillの所有・部分返済・入出BBO・strict後続index/物理行・遅延・片側10・半円費用・粗額/fee/slip/net・残/予約0・実Source通知・出生一枠・保存MTM/口座DD/二旗は旧共通規範を直接再用する。金額/数量/価格/時計の許容を広げない。
- Eは生native ATR値と現在残玉単価円から通常LD10優先ORを検査する。早期はLD05と既知C/M（E2はP追加）。専用auditの実Activation/理由/所有/閾値/観測・公開時計へ結ぶ。u初正益と起動を同一旗にしない。
- WidthAuditは通常2ATR/狭幅1ATRの5pt切上げ、実起動/峰/床、初狭幅の必要三値と実mark、終玉/sequence/update数を照合する。固定幅から狭幅への一方向変更なので最終床は`max(0,peak−選択幅)`と一致し、0より下へ緩めない。
- 保存sidecarの公表を停止Python C/M/P（2fde）と型射影（39a6）へ直接渡す。公開Frame/結果全値とSHA、両方向Observation、reset後に古い同IDを復活しないこと、当markの最新生存公表、20政策へ同じ公表を20件加算しない診断counterを結合する。RawからOHLC/EMA/ATR等を再計算する監査ではない。
- 既存58場は旧104sym54/105sym4の最終W0四冊を実物と全JSON除外0で再照合する。追加12場はCoreが同入力へ流した別旧103 Actorの最終対照であり、過去市場goldenではない。市場の全原行対照数は0として明示する。

少数保存点と全公開根拠の検算であり、全Quote別engineで金融を独立再生したことにはしない。Source全体の売買対称・自然Sourceの新規形成を証明しない。未参加/退出後価格/機会損失を評価しない。

## 型人工

```powershell
work/venvs/technical-tree/Scripts/python.exe -B -X utf8 `
  work/106可変保護の保存準備/人工検査.py --out <新規人工dir>
```

停止c465のCore四器具80非0冊、停止68011のE専用32冊（早期16/通常LD10 16）を別scopeで使用する。Core人工だけではE早期発動非0を保証しない。C/M/Pの手製公表・価格・Source通知はGoの固定公開型であり自然市場の実測ではない。Core四器具は同じ手製Dayの買売/助走違いで、独立四市場として数えない。Viewer形式80資源の保存再読までで、実HTTPは0。

## Root成功後の保存口（まだ実行しない）

Rootが金融成功後に次の**事後固定JSON**を新規保存し、SHAを明示する。市場前条件自体は変更しない。

```json
{
  "version": 1,
  "trial": 106,
  "fixed": true,
  "stage": "first2",
  "condition": {"path": "市場前条件.json", "sha256": "64桁"},
  "completion": {"path": "金融完了.json", "sha256": "64桁"},
  "code": {"path": "../../work/106可変保護の保存準備/集計.py", "sha256": "64桁"}
}
```

stageは`first2`又は`full70`。3FileRefは固定JSONのparent基準。市場条件内FileRefは市場条件parent、完了resultsの3FileRefは完了parent、SourceCorpus内はCorpus parent、code_sha256 keyはrepo基準又は絶対path。fallbackはない。Native20と公開Header/recordsだけを保存検算へ用い、Raw/CSVの再hashはせず市場条件と金融beforeの宣言指紋を照合する。Viewerは固定ManifestのNK225原板を絶対pathで参照し、原板を複製しない。

```powershell
work/venvs/technical-tree/Scripts/python.exe -B -X utf8 `
  work/106可変保護の保存準備/集計.py `
  --fixed <Rootの事後固定JSON> --fixed-sha <そのSHA256> --out <新規保存dir>
```

未固定/金融失敗/条件不一致/集合欠落はNativeより前に拒否する。full70は同条件first2の出典と先頭二場のNative/Header/records SHA一致が必要。出力は結果.json、一覧.resources.json、各実Fillのtrades、保存会計の確認.json。Native/sidecarは元path+SHA参照で再転記しない。全70なら1400経済会計、各政策の主分母7840・副7560。開始不足/欠測は分母に残す。

集計は実現額・正負・PF・u正益後赤字/未観測赤字・起動後赤字・起動/狭幅件数・保存点DD、日夜/日別、W0対各政策の同実入口/取得変更/片側実参加の加法分解を保存する。同じSourceIDだけで実入口一致とせず、Source全値と注文/取得quote・価格・量・時刻へ結ぶ。これは安定利益や採用の判定を新設するものではない。

市場I/O停止f211/Core停止c465は受領済み。Root条件・金融成功への実接続は未実施で、Rootの実行許可後に初めて確認する境界として残す。
