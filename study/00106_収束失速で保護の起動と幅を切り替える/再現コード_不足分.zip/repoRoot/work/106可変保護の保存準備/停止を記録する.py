"""106保存準備の人工証拠と再用境界を指紋で停止する。"""

import hashlib
import json
from pathlib import Path


OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[1]


def digest(path):
    """
    機能: 明示ファイルのSHA256を求める。
    引数: path(Path)はコード又は人工の小証拠。
    返り値: strは指紋。市場入力を探索しない。
    """
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write(path, value):
    """
    機能: 新規JSONだけを保存する。
    引数: path(Path)、value(dict)は保存先と内容。
    返り値: None。既存停止を上書きしない。
    """
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def main():
    """
    機能: 最終人工成功と全参照不変を再確認し準備停止を作る。
    引数: なし。
    返り値: None。金融/Source/Raw/旧Native/Viewerを実行しない。
    """
    proof_path = OWN / "人工/確定版/人工確認.json"
    proof = json.loads(proof_path.read_text(encoding="utf-8"))
    assert proof["成功"] and proof["Core非0会計"] == 80 and proof["E専用API"] == {"books": 32, "early_warning": 16, "normal_ld10": 16}
    assert proof["Viewer形式"] == 80 and proof["拒否数"] == 31 and proof["前後不変"]
    assert proof["入力前SHA256"] == proof["入力後SHA256"]
    for name, want in proof["入力後SHA256"].items():
        assert digest(Path(name)) == want, name
    origins = {
        "work/105LD10の保存準備/停止.json": "b90facc5612b6412ffcb760c8972c6cc6ad678eecb5922aa1082d5ef5b4db606",
        "work/104LD10の保存/停止.json": "b4859a859f7b5dbfd3094824186984a4f7068fadf2a8819d88958728d3db2504",
        "work/106可変保護の市場接続準備/停止.json": "c465bd1696fe1e5d2f4c9b299712866c96b73b4126bf4883245acc47fec154f3",
        "work/収束失速で保護を早める会計案/停止.json": "68011a9c44cbf88f765216493d331849cb80efd95cfdf63d750bbfafe53e02c5",
        "work/106市場の入出力準備/停止.json": "f211f764db4914a294452e2e99118c60de3153348fe76f8490ddfab15a510f0e"}
    for name, want in origins.items():
        assert digest(ROOT / name) == want, name
    ancestry = {
        "方針": "固定105→104→103→95→94保存算術を直接再用。共通会計本文/Source/金融式を複写又は変更しない",
        "共通会計": "103.verify_bookのcode objectを実config_for/GIRD_SPACE/verify_marksの専用名前空間で再用。内E1/E2の実Configを検証した後、実Policy=P0の部分だけ旧94共通会計へ投影する",
        "保存点": "94.verify_marksのcode objectを再用し初正益即起動の等式だけ実LD10/E起動auditへ分離。ATR非金融時計/切上げは103と同じIEEE64の演算順で照合。金額/数量/価格/時計の許容拡大なし",
        "新規保存検査": ["E通常優先OR/実Activation/所有/理由/公開根拠", "W/E幅/峰/非緩和床/初狭幅/終玉/別audit", "実公表Frame→固定C/M/P→SHA/両方向観測→当markの最新公表とreset", "既存58旧保存対照と新12同入力旧Actorを分離"],
        "公開型": "固定39a6のto_frameと2fdeのTrackerをSHA再用。指標/Source/金融は形成しない",
        "外周": "Root保存固定3Ref→金融成功→70集合/20設定/first2同条件→Native/Header/records→形式保存。実市場接続は未実施",
        "変更しない": ["旧1055192/1040409/103aa1f/95/94", "Core c465", "金融68011", "市場I/O f211", "Source106/43/入力"],
        "元停止SHA256": origins,
        "未実施": ["市場Native/Raw/CSV/旧市場Native読取", "Source/金融再実行", "全Quote別engine独立金融再生", "実Viewer通信"]}
    write(OWN / "由来と再用.json", ancestry)
    owned = {str(p.relative_to(ROOT)).replace("\\", "/"): digest(p) for p in
             (OWN / "集計.py", OWN / "人工検査.py", OWN / "停止を記録する.py", OWN / "README.md", OWN / "由来と再用.json")}
    outputs = {str(p.relative_to(ROOT)).replace("\\", "/"): digest(p) for p in (OWN / "人工/確定版").rglob("*") if p.is_file()}
    stop = {"成功": True, "scope": "106の非市場保存準備/実W/E設定と共通会計・公開根拠の型人工",
            "所有コードSHA256": owned, "集計コードSHA256": owned[str((OWN / "集計.py").relative_to(ROOT)).replace("\\", "/")],
            "元停止SHA256": origins, "依存SHA256前": proof["入力前SHA256"], "依存SHA256後": proof["入力後SHA256"], "前後不変": True,
            "人工確認": {"path": str(proof_path.relative_to(ROOT)).replace("\\", "/"), "SHA256": digest(proof_path)},
            "人工成果物SHA256": outputs, "Core非0会計": 80, "E専用API会計": 32, "E早期": 16, "E通常LD10": 16,
            "Viewer形式": 80, "破損拒否": 31, "不一致数": 0,
            "Root保存固定schema": {"version": 1, "trial": 106, "fixed": True, "stage": "first2|full70", "condition": "FileRef", "completion": "FileRef", "code": "FileRef"},
            "予定市場": {"場": 70, "経済会計": 1400, "主分母": 7840, "副分母": 7560, "旧保存W0": 58, "同入力旧103新対照": 12},
            "実市場/Raw/CSV/旧Native/Source形成/金融再生/ViewerAPI": 0,
            "限界": proof["限界"], "市場外周の実接続": "Root条件と金融成功後まで未実施。I/O最終schema f211を静的参照", "外部peer": "依頼済み、停止時点では返答未受領・成功へ加算しない"}
    write(OWN / "停止.json", stop)
    print(json.dumps({"成功": True, "停止SHA256": digest(OWN / "停止.json"), "集計コードSHA256": stop["集計コードSHA256"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
