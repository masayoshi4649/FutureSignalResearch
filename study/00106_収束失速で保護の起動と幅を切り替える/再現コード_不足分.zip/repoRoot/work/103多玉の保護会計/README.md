# 103 多玉Source会計の遅延起動prototype

市場実行前の人工限定module `github.com/masayoshi4649/SessionTradeExecuter/minidelayed103`、package `minidelayed103`。元は `scripts/短秒の複合退出の会計`。由来本文は変更しない。最初に固定した[仕様](仕様.md)と[16口座補足](診断対照の補足.md)を分けて残す。

公開APIは元と同型の `NewActualBook(Session, ActorConfig)`、`OnNativeStep(Observation,sourceLine,[]NativeBatch)`、`OnNativeForce(at,[]NativeBatch)`、`OnEntryGrid(at)`、`Snapshot()`、`Finish()`。Observation/Session/QuoteStampはnative93 alias。NativeBatch等は新moduleの名前付き型なので、旧型からMethod/Delta等を明示対応する。入力sliceや通知は不変で共有可能で、Snapshotは深いcopy。

追加設定は `ActivationPolicy` 型の `ActorConfig.ActivationPolicy`（JSON `activation_policy,omitempty`）。値は空/LD05/LD10。LDはGate/Harvest/Risk/Exit空のB5Q/P0に限定する。元のE3S設定は空Activationで互換維持する。S0はGate空B5Q/Activation空だけの追加診断で、保護義務を満たす新候補ではない。

主12順は空→LD05→LD10、それぞれC0D0/C0D1/C5D0/C5D1。Keyは `B5Q_P0_Cx_Dy`、`LD05_B5Q_P0_Cx_Dy`、`LD10_B5Q_P0_Cx_Dy`。末尾に `B5Q_S0_Cx_Dy` 四診断を置き全16。

現在残玉単価u円は旧式 `100*s*(返済BBO-entry)-77-2*SlipPts*100`。LD05は `u>=100*max(10,0.5*ATRLock.Value)`、LD10は `u>=100*max(10,ATRLock.Value)`。未知ATRは新起動保留。取得時又は初回既知に一度だけロックする元native ATRを使い、Chart ATR3へ置換しない。`Value`は未丸め、`Width=5*ceil(2*Value/5)`は旧追尾幅であり、Width/2は元ATRと同値でない。後の公開ATRで置換しない。

旧ピークは取得後から観測するため、LD起動時にリセットしない。起動後の最低名目建値/旧固定Width/非緩和床、Source予約優先、pre_fill観測→旧fill→Source→after_sourceだけ保護要求、未予約実量/strict後続Index/要求+Delayを保つ。FirstUnitPositiveのu>0は遅延起動と別。LD時だけ `position.activation_reason` を保存する。保護注文の旧reason/protection_pointと既存counterは維持する。S0は旧continueを使うだけで新数式なし。

B5Q出生一回・quiet・Source期限はそのままで、末尾30分の新除外を加えない。主分母6048/副観測5832はruntime/保存担当の契約であり、このmoduleは既存GridTraceの時計と値を保つ。Source側の買い優先重複などの固定例外を直した試行ではなく、自然Source完全鏡像を人工通知の鏡像から主張しない。

## 人工と実行

```powershell
Set-Location 'work/103多玉の保護会計'
go test -json -count=1 ./...
go vet ./...
go build ./...
# 新規の出力先だけを指定する。既存先は拒否。
$env:MINIDELAYED103_EXPORT = '<新規絶対path>'
go test -count=1 -run '^Test103Export$' ./...
Remove-Item Env:MINIDELAYED103_EXPORT
```

`人工/停止版` は実Go型Marshalの買売×ATR既知/初回未知4系列、各16の64非0口座。JSONはsession/scope/steps{observation,source_line,batches}/timers{at,batches}/grids/events{kind,index}/actors/baseline95_p0/comparisons。Sourceは手製の出生/部分返済/親追加/Forceで、自然戦略・板・ATRの計算を実行していない。exportのForce.SourceLineは直前の人工quoteの物理行を明示設定している（由来helperのAPI Force0を実入力と偽装していない）。源のFee0判断と外台帳費用は旧のまま。

空Activationの旧canonical E3S/P0/H0/HG各C/D×買売24経路を全API時点/最終で除外0比較する。Gate空P0は旧95四×4波で全時点/最終JSON除外0。S0は旧95constructorがB5Q/S0を拒否するため、旧95全文成功に含めずSource返済だけの粗額/費用/遅延差を手計算する。公開APIの数学等号、非整数ATR、現在単価と既実現益の分離、全/部分予約、同秒後Index/D1/Force、半円配賦、各側10、床非緩和/初回ロック、破損拒否を狭く検査する。

限界は手製Source/ATRのAPI人工であり、実Tapeへの接続・自然Source形成・入力品質・実市場成績は未検査。市場/Raw/Native読取・Source再形成・新売買実行0。旧H/短秒/X5等をLDへ組み合わせない。
