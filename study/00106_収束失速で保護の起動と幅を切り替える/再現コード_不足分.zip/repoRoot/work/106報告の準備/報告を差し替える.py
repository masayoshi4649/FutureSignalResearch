"""106の原計画を保存し、検証済み小集計だけを結果欄へ差し込む。"""
from __future__ import annotations

import argparse
from decimal import Decimal
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
BASE_PATH = ROOT / 'work/105報告の準備/報告を差し替える.py'
BASE_SHA = 'e09539c38606e999f2e7278c3b078dcb470f2ee334ab811b21cb921fbc065b15'
SAVED_PATH = ROOT / 'work/106可変保護の保存準備/集計.py'
SAVED_SHA = '7451f6c6502ec7b5ca83d0ce296931f1abbb2b082d41003ccb8a907846736f47'
KEYS = [f'{p}_C{c}_D{d}' for p in ('W0', 'W1', 'W2', 'E1', 'E2') for c in (0, 5) for d in (0, 1)]
GROUPS = {'old104_54': ('旧54', 54, 6048), 'saved105_4': ('105四', 4, 448), 'fresh106_12': ('追加12', 12, 1344)}
FIELDS = ['gross_yen', 'fee_yen', 'slip_yen', 'net_yen', 'positive_yen', 'negative_yen', 'positions', 'entry_quantity',
          'positive_positions', 'negative_positions', 'zero_positions', 'unit_positive_positions', 'unit_positive_closed_negative',
          'unit_positive_closed_negative_yen', 'unit_unobserved_closed_negative_yen', 'protection_activated_positions',
          'activated_closed_negative', 'activated_closed_negative_yen', 'normal_ld10_activations', 'early_warning_activations', 'narrowed_positions']
COMPS = ['全差額', '同実入口玉', '同実入口差額', '取得変更玉', '取得変更差額', '前のみ玉', '前のみ実現額', '後のみ玉', '後のみ実現額']
BEGIN, END = '<!-- REPORT106:RESULT:BEGIN -->', '<!-- REPORT106:RESULT:END -->'


def sha(path: Path) -> str:
    """
    機能: 明示したコード/原文/小JSONの内容指紋を返す。
    引数: path (Path) は対象ファイル。
    返り値: str はSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


assert sha(BASE_PATH) == BASE_SHA
spec = importlib.util.spec_from_file_location('stopped_report105', BASE_PATH)
BASE = importlib.util.module_from_spec(spec)
spec.loader.exec_module(BASE)
finite, amount, read_json, file_ref = BASE.finite, BASE.amount, BASE.read_json, BASE.file_ref


def validate_row(t: dict, denom: int, sub: int | None = None) -> None:
    """
    機能: 保存集計の算術・二旗・通常早期狭幅と参加を検査する。
    引数: t (dict)、denom (int)、sub (int|None) は集約値と既定分母。
    返り値: None。不明値を0へ補完せず不整合を拒否する。
    """
    for name in FIELDS:
        finite(t[name])
    assert t['gross_yen'] - t['fee_yen'] - t['slip_yen'] == t['net_yen'] == t['positive_yen'] + t['negative_yen']
    assert t['positive_yen'] >= 0 and t['negative_yen'] <= 0 and t['fee_yen'] >= 0 and t['slip_yen'] >= 0
    assert t['positive_positions'] + t['negative_positions'] + t['zero_positions'] == t['positions']
    assert t['unit_positive_closed_negative_yen'] + t['unit_unobserved_closed_negative_yen'] == t['negative_yen']
    assert 0 <= t['unit_positive_closed_negative'] <= t['unit_positive_positions'] <= t['positions']
    assert 0 <= t['activated_closed_negative'] <= t['protection_activated_positions'] <= t['positions']
    assert t['normal_ld10_activations'] + t['early_warning_activations'] == t['protection_activated_positions']
    assert 0 <= t['narrowed_positions'] <= t['protection_activated_positions']
    if 'PF' in t:
        assert (t['PF'] is None and t['negative_yen'] == 0) or t['negative_yen'] < 0 and abs(finite(t['PF']) - finite(t['positive_yen']) / -finite(t['negative_yen'])) < Decimal('1e-10')
    for label, n in [('活動主表', denom)] + ([('活動副表', sub)] if sub is not None else []):
        a = t[label]
        assert a['denom'] == n and a['new'] + a['hold'] == a['active'] and a['active'] + a['wait'] + a['unknown'] == n
        assert all(type(a[k]) is int and a[k] >= 0 for k in ('new', 'hold', 'active', 'wait', 'unknown', 'denom'))
        assert abs(finite(a['参加率']) - Decimal(a['active']) / n) < Decimal('1e-12')


def validate_result(r: dict, sessions: list[str], contracts: list[str]) -> None:
    """
    機能: 全70/1400の小集計、履歴/日夜、実入口加法分解と公表母数を照合する。
    引数: r (dict)、sessions/contracts (list[str]) は保存結果と固定metadata。
    返り値: None。Native/注文/価格を開かない。
    """
    assert r['試行'] == 106 and r['成功'] is True and r['stage'] == 'full70' and r['場数'] == 70 and r['会計数'] == 1400
    assert len(sessions) == len(set(sessions)) == 70 and len({s[:10] for s in sessions}) == 35
    assert set(r['集計']) == set(KEYS) and r['前後不変'] is True and r['入力codeSHA256前'] == r['入力codeSHA256後']
    assert len(r['場別']) == 1400
    pairs = {(x['session'], x['key']): x for x in r['場別']}
    assert len(pairs) == 1400 and set(pairs) == {(s, k) for s in sessions for k in KEYS}
    for key in KEYS:
        t = r['集計'][key]
        validate_row(t, 7840, 7560)
        assert finite(t['保存点連結時価DD']) >= 0
        for field in FIELDS:
            assert sum(pairs[s, key][field] for s in sessions) == t[field]
        assert sum(pairs[s, key]['活動主表']['active'] for s in sessions) == t['活動主表']['active']
        for s in sessions:
            row = pairs[s, key]
            validate_row(row, 76 if s.endswith('_Day') else 148, 72 if s.endswith('_Day') else 144)
            assert row['history_class'] in GROUPS and row['width_policy'] == key.split('_')[0]
        diagnosis = r['実現診断'][key]
        for kind, n in [('Day', 2660), ('Night', 5180)]:
            validate_row(diagnosis['日夜'][kind], n)
        assert sum(v['net_yen'] for v in diagnosis['日夜'].values()) == t['net_yen']
        assert len(diagnosis['日別']) == 35 and {v['開始日'] for v in diagnosis['日別']} == {s[:10] for s in sessions}
        assert sum(v['net_yen'] for v in diagnosis['日別']) == t['net_yen']
        assert set(diagnosis['履歴区分']) == set(GROUPS)
        for group, (_, count, denom) in GROUPS.items():
            rows = [pairs[s, key] for s in sessions if pairs[s, key]['history_class'] == group]
            assert len(rows) == count
            validate_row(diagnosis['履歴区分'][group], denom)
            assert sum(v['net_yen'] for v in rows) == diagnosis['履歴区分'][group]['net_yen']
        if key.startswith('W'):
            assert t['early_warning_activations'] == 0
        if key.startswith('W0'):
            assert t['narrowed_positions'] == 0
    expected = {f'{p}_C{c}_D{d}対W0_C{c}_D{d}' for p in ('W1', 'W2', 'E1', 'E2') for c in (0, 5) for d in (0, 1)}
    assert set(r['同実入口と実現額差']) == expected
    for name, value in r['同実入口と実現額差'].items():
        new, old = name.split('対')
        t = value['合計']
        assert all(field in t for field in COMPS)
        assert t['全差額'] == r['集計'][new]['net_yen'] - r['集計'][old]['net_yen'] == t['同実入口差額'] + t['取得変更差額'] - t['前のみ実現額'] + t['後のみ実現額']
        assert len(value['場別']) == 70 and {v['session'] for v in value['場別']} == set(sessions)
        for field in COMPS:
            assert sum(v[field] for v in value['場別']) == t[field]
    controls = r['W0対照']
    assert len(controls) == 70 and {x['session'] for x in controls} == set(sessions)
    assert sum(x['kind'] == 'provided_old_book' for x in controls) == 58
    assert sum(x['kind'] == 'same_input_old103' for x in controls) == 12
    for x in controls:
        assert x['all'] is True and x['books'] == 4 and x['excluded'] == [] and x['all_point_comparisons'] == 0
        assert x['history_class'] == ('old_saved_58' if x['kind'] == 'provided_old_book' else 'same_input_new12')
    diagnostics = r['一公表単位の役割診断']
    assert len(diagnostics) == 70 and {v['session'] for v in diagnostics} == set(sessions)
    by_id = {v['session']: v for v in diagnostics}
    for i, s in enumerate(sessions):
        v = by_id[s]
        assert type(v['numeric_seed_carried']) is bool and v['numeric_seed_carried'] == (i > 0 and contracts[i] == contracts[i - 1])
        n = v['new_three']
        assert type(n) is int and 0 <= v['C_pass'] <= v['C_known'] <= n
        for side in ('buy', 'sell'):
            assert all(0 <= v[side][p + '_pass'] <= v[side][p + '_known'] <= n for p in ('M', 'P'))


def validate_activation_comparison(extra: dict, r: dict) -> None:
    """
    機能: 別診断8本を同費用の実現差と通常/早期起動件数へ結ぶ。
    引数: extra/r (dict) は固定別診断と保存集計。
    返り値: None。金融/幅経路を同一だと仮定しない。
    """
    assert extra['試行'] == 106 and extra['成功'] is True and extra['stage'] == 'full70' and extra['場数'] == 70 and extra['比較数'] == 8
    assert extra['前後不変'] is True and extra['入力SHA256前'] == extra['入力SHA256後'] and extra['金融再実行'] == 0
    names = {f'E{n}_C{c}_D{d}対W{n}_C{c}_D{d}' for n in (1, 2) for c in (0, 5) for d in (0, 1)}
    assert set(extra['比較']) == names
    sessions = {x['session'] for x in r['場別']}
    for name, comparison in extra['比較'].items():
        new, old = name.split('対'); total = comparison['合計']
        assert total['全差額'] == r['集計'][new]['net_yen'] - r['集計'][old]['net_yen']
        assert total['全差額'] == total['同実入口差額'] + total['取得変更差額'] - total['前のみ実現額'] + total['後のみ実現額']
        assert len(comparison['場別']) == 70 and {x['session'] for x in comparison['場別']} == sessions
        for field in COMPS:
            assert sum(x[field] for x in comparison['場別']) == total[field]
        for label, key in [('前', old), ('後', new)]:
            assert total[label+'の通常LD10起動'] == r['集計'][key]['normal_ld10_activations']
            assert total[label+'の早期起動'] == r['集計'][key]['early_warning_activations']


def prepare(path: Path, expected: str) -> tuple[dict, dict, dict]:
    """
    機能: Root事後固定の小JSONと金融/保存/条件/Source完了だけを指紋結合する。
    引数: path (Path)、expected (str) は明示固定とSHA。
    返り値: tuple[dict,dict,dict] は実集計・入力指紋・Viewer確認scope。
    """
    assert sha(path) == expected
    fixed = read_json(path)
    assert fixed['version'] == 1 and fixed['trial'] == 106 and fixed['fixed'] is True and fixed['result_ready'] is True
    before = {str(path.resolve()): expected}
    files = {k: file_ref(fixed[k], path.resolve().parent, before) for k in ('summary', 'saved_check', 'financial_completion', 'condition', 'source_completion')}
    r, saved, financial, condition, source = (read_json(files[k]) for k in ('summary', 'saved_check', 'financial_completion', 'condition', 'source_completion'))
    assert sha(SAVED_PATH) == SAVED_SHA == r['codeSHA256'] == saved['codeSHA256']
    assert r['conditionSHA256'] == saved['conditionSHA256'] == sha(files['condition']) == financial['condition_sha256']
    assert r['completionSHA256'] == saved['completionSHA256'] == sha(files['financial_completion'])
    assert saved['成功'] is True and saved['会計'] == saved['資源'] == 1400 and saved['不一致数'] == 0 and saved['前後不変'] is True
    assert saved['出力SHA256']['結果.json'] == sha(files['summary']) and saved['入力codeSHA256前'] == saved['入力codeSHA256後']
    assert financial['success'] is True and financial['stage'] == 'full70' and financial['sessions'] == 70 and financial['books_per_scene'] == 20 and financial['books'] == 1400
    assert financial['unchanged'] is True and financial['before'] == financial['after'] and financial['source_reexecuted'] is False
    assert source['success'] is True and source['stage'] == 'full12' and source['sessions'] == 12 and len(source['cases']) == 36 and len(source['legacy_default_matches']) == 12
    assert source['unchanged'] is True and source['before'] == source['after'] and source['financial106_executed'] is False
    assert condition['source12_completion']['sha256'] == sha(files['source_completion'])
    manifest_path = file_ref(condition['input_manifest'], files['condition'].parent, before)
    manifest = read_json(manifest_path)
    sessions = [x['id'] for x in manifest['sessions']]
    assert [x['session'] for x in financial['results']] == sessions and all(x['books'] == 20 and x['w0_control_books'] == 4 and not x.get('error') for x in financial['results'])
    assert r['Native参照'] == [{k: x[k] for k in ('session', 'native', 'sidecar_header', 'sidecar_records')} for x in financial['results']]
    validate_result(r, sessions, [x['contract'] for x in manifest['sessions']])
    viewer = {'確認': False, 'scope': '実Viewer未確認。保存形式の資源と実HTTPは別証拠'}
    if 'viewer_evidence' in fixed:
        vp = file_ref(fixed['viewer_evidence'], path.parent, before)
        v = read_json(vp)
        assert v['成功'] is True and isinstance(v['scope'], str) and v['scope'].strip()
        viewer = {'確認': True, 'scope': v['scope'], 'SHA256': sha(vp)}
    links = []
    if 'activation_comparison_json' in fixed:
        extra_path = file_ref(fixed['activation_comparison_json'], path.parent, before)
        extra = read_json(extra_path)
        validate_activation_comparison(extra, r)
        assert sha(files['summary']) in extra['入力SHA256前'].values() and sha(files['financial_completion']) in extra['入力SHA256前'].values()
        links.append(('同幅の起動差JSON', extra_path, sha(extra_path)))
    if 'activation_comparison_md' in fixed:
        assert 'activation_comparison_json' in fixed
        extra_path = file_ref(fixed['activation_comparison_md'], path.parent, before)
        links.append(('同幅の起動差MD', extra_path, sha(extra_path)))
    formal = ROOT / 'study/00106_収束失速で保護の起動と幅を切り替える'
    viewer['additional_links'] = [{'label': label, 'href': Path(os.path.relpath(p, formal)).as_posix(), 'sha256': h} for label, p, h in links]
    assert all(sha(Path(p)) == s for p, s in before.items())
    return r, before, viewer


def table(headers: list[str], rows: list[list[str]]) -> str:
    """
    機能: 複合結果をMarkdownの比較表へ整形する。
    引数: headers/rows (list) は見出しと表示済み値。
    返り値: str は表本文。
    """
    return '\n'.join(['| ' + ' | '.join(headers) + ' |', '| ' + ' | '.join(['---'] * len(headers)) + ' |'] + ['| ' + ' | '.join(row) + ' |' for row in rows])


def rate(n: int | None, d: int | None) -> str:
    """
    機能: 未検証・分母0・既知の率を区別する。
    引数: n/d (int|None) は分子と分母。
    返り値: str は百分率又は未検証/未定義。
    """
    return '未検証' if n is None or d is None else '未定義（分母0）' if d == 0 else f'{Decimal(n) / d:.2%}'


def result_block(r: dict | None, viewer: dict) -> str:
    """
    機能: 全20・二旗・起動/幅・参加・区分・公表・実入口分解を報告する。
    引数: r (dict|None)、viewer (dict) は小集計又は未検証と実確認scope。
    返り値: str は結果欄のみ。新しい売買閾値を作らない。
    """
    get = lambda k, f: r['集計'][k][f] if r else None
    rows = []
    for i, k in enumerate(KEYS):
        t = r['集計'][k] if r else None
        pf = '未検証' if t is None else '未定義（負額0）' if t['PF'] is None else f'{finite(t["PF"]):.4f}'
        rows.append([f'R{i+1:02d} {k}'] + [amount(get(k, f)) for f in ('gross_yen', 'fee_yen', 'slip_yen', 'net_yen', 'positive_yen', 'negative_yen')] + [pf, amount(get(k, '保存点連結時価DD')), f'{amount(get(k,"positions"))}/{amount(get(k,"entry_quantity"))}'])
    lines = [BEGIN, '## 106の結果欄', '', '**未取込・未検証。実績値はnull。**' if r is None else '全70場/1,400会計の保存結果を金融/条件/Sourceの固定指紋へ結合した。計算/保存成功と、研究目標・採用・未知期間安定性は別に判断する。', '',
             table(['評価/外Key', '粗額円', 'fee円', '仮定slip円', '純額円', '全正額円', '全負額円', 'PF', '保存点DD円', '玉/取得枚'], rows), '',
             '### u正益後と保護起動後の赤字', '']
    lines += [table(['Key', 'u正益玉', 'u後赤字玉/円', 'u未観測赤字円', '起動玉', '起動後赤字玉/円'], [[k, amount(get(k, 'unit_positive_positions')), f'{amount(get(k,"unit_positive_closed_negative"))}/{amount(get(k,"unit_positive_closed_negative_yen"))}', amount(get(k, 'unit_unobserved_closed_negative_yen')), amount(get(k, 'protection_activated_positions')), f'{amount(get(k,"activated_closed_negative"))}/{amount(get(k,"activated_closed_negative_yen"))}'] for k in KEYS]), '',
              'u>0の最初の観測とLD10/Eの起動は別旗。各旗の観測玉をそれぞれの分母とし、起動後赤字の少なさだけでu正益後の全損失が減ったとはしない。全負額・DD・最終純額も区別する。', '',
              '### 通常/早期起動と狭幅', '', table(['Key', '通常LD10起動', 'E早期警戒起動', '一度狭幅になった玉'], [[k] + [amount(get(k, f)) for f in ('normal_ld10_activations', 'early_warning_activations', 'narrowed_positions')] for k in KEYS]), '',
              '通常LD10と早期条件の同時成立は通常として記録。W0/W1/W2は起動を変更せず、E1/E2は別の早期ORである。幅の保持・名目建値床は実約定の費用後黒字を保証しない。', '',
              '### 日夜と参加（主7,840・副7,560）', '']
    rows = []
    for k in KEYS:
        t = r['集計'][k] if r else None
        d = r['実現診断'][k]['日夜'] if r else None
        a, b = (d['Day'], d['Night']) if d else (None, None)
        status = '未検証' if t is None else ('達成' if 4*t['活動主表']['active'] >= 7840 else '未達') + '/' + ('達成' if 2*t['活動主表']['active'] >= 7840 else '未達')
        rows.append([k, amount(a['net_yen'] if a else None), rate(a['活動主表']['active'] if a else None, 2660), amount(b['net_yen'] if b else None), rate(b['活動主表']['active'] if b else None, 5180), amount(t['活動主表']['active'] if t else None), rate(t['活動主表']['active'] if t else None, 7840), rate(t['活動副表']['active'] if t else None, 7560), status])
    lines += [table(['Key', '日中純額円', '日中参加/2660', '夜間純額円', '夜間参加/5180', '全体参加枠', '主率/7840', '副率/7560', '最低25/目標50'], rows), '',
              '最低25%・目標50%は全体と日夜/場別を分ける。保有と同枠実取得の和集合で、受理だけのnewを約定とせず、欠測/US静観も分母へ残す。副表で新規時計自体を変えない。', '',
              '### 履歴区分・日別', '']
    rows = []
    for k in KEYS:
        g = r['実現診断'][k]['履歴区分'] if r else None
        rows.append([k] + [amount(g[name]['net_yen'] if g else None) for name in GROUPS])
    lines += [table(['Key'] + [v[0] + '純額円' for v in GROUPS.values()], rows), '',
              '旧54・105四・追加12を全て併記。70セッション/35開始日であり、20政策費用や複数玉を独立日へ水増ししない。全て既使用の探索で、105を見た後の仮説を同じ四場で改善しても未見確認と呼ばない。日別35行と日夜/履歴の合計は全体へ照合する。', '',
              '### 一公表単位のC/M/P既知性とcold/carry', '']
    if r:
        ds = r['一公表単位の役割診断']; n = sum(v['new_three'] for v in ds)
        known = [('C', sum(v['C_known'] for v in ds), sum(v['C_pass'] for v in ds))] + [(side + '/' + p, sum(v[side][p + '_known'] for v in ds), sum(v[side][p + '_pass'] for v in ds)) for side in ('buy', 'sell') for p in ('M', 'P')]
        role_rows = [[label, amount(n), amount(yes), rate(yes, n), amount(passed)] for label, yes, passed in known]
        seed = f'数値種carry {sum(v["numeric_seed_carried"] for v in ds)}場、cold/roll {sum(not v["numeric_seed_carried"] for v in ds)}場。'
    else:
        role_rows = [[label] + ['未検証'] * 4 for label in ('C', 'buy/M', 'buy/P', 'sell/M', 'sell/P')]; seed = 'cold/carryの実観測場数は未検証。'
    lines += [table(['役割', '新3分公表母数', '既知', '既知率', 'strict成立'], role_rows), '', seed + ' 計画は9/21 Day cold→同限月数値carry、場頭CMP/形成/mask reset、roll cold。公表を20冊分重複加算せず、未知を支持/不成立へ補完しない。EMA/MACDは同じ価格由来で独立二票ではない。', '',
              '### W0対照と実現差の分解', '', ('W0対照の実績は未検証。計画は旧保存最終4冊×58の全JSON除外0照合と、追加12の同入力旧Actor四冊の新対照。' if r is None else 'W0の既存58は旧保存最終4冊×58を全JSON除外0照合。追加12は同入力へ旧103 Actor四冊を新配送する対照。') + '追加12に過去市場goldenはなく、市場全原行の別engine再計算を実施したとはしない。', '']
    rows = []
    for p in ('W1', 'W2', 'E1', 'E2'):
        for c in (0, 5):
            for d in (0, 1):
                name = f'{p}_C{c}_D{d}対W0_C{c}_D{d}'; t = r['同実入口と実現額差'][name]['合計'] if r else None
                rows.append([name] + [amount(t[f] if t else None) for f in COMPS])
    lines += [table(['比較'] + COMPS, rows), '',
              '全差額＝同実入口差額＋取得変更差額−前のみ実現額＋後のみ実現額。Source全値と要求/実取得の指紋が一致した入口だけを同実入口と呼ぶ。取得変更・片側のみも各政策が実際に行った取引額で、未参加の仮想利益ではない。C5/D1は動的別運転で、C0から固定控除した比較へ置換しない。', '',
              '### 同じ幅選択規則での起動差（別診断）', '',
              (' / '.join(f'[{x["label"]}]({x["href"]})（SHA256 `{x["sha256"]}`）' for x in viewer['additional_links']) if viewer.get('additional_links') else 'E1対W1・E2対W2の各4費用、計8比較の別診断は未取込・未検証。'), '',
              'W0対の16比較と混ぜず、起動時機を近い政策間で比べる。同じ幅選択規則でも、起動後の実際の床/幅経路や参加は同一とは限らない。売買条件を変更する追加探索ではなく、固定政策間の実入口/実現額分解である。', '',
              '幅/起動時機/その後の実参加が変わる複合比較であり、純額差をC/M/Pの単独因果効果へ帰属しない。機会損失、退出後価格、MFE回収率、仮想約定・ROIを計算しない。', '',
              'Viewer確認：' + viewer['scope'] + '。保存資源と実HTTPの成功を混同しない。', END, '']
    return '\n'.join(lines)


def render(r: dict | None, viewer: dict) -> tuple[dict[str, bytes], dict]:
    """
    機能: 全55×9/S13/K11を原文同体に保ちR20と結果欄だけを更新する。
    引数: r (dict|None)、viewer (dict) は検査済み小集計又は未検証。
    返り値: tuple[dict,dict] は新文書bytesと原計画指紋。
    """
    originals = {n: (WORK / '原文' / n).read_bytes() for n in ('README.md', '設定と結果.md')}
    readme, settings = (originals[n].decode('utf-8-sig') for n in ('README.md', '設定と結果.md'))
    assert BEGIN not in readme and BEGIN not in settings
    before = settings
    if r:
        rows = settings.splitlines()
        for i, key in enumerate(KEYS):
            rid = f'R{i+1:02d}'; found = [j for j, line in enumerate(rows) if line.startswith(f'| {rid} |')]
            assert len(found) == 1
            parts = rows[found[0]].split('|'); t = r['集計'][key]
            parts[6], parts[7], parts[8] = ' ' + amount(t['net_yen']) + '円 ', ' ' + rate(t['活動主表']['active'], 7840) + ' ', ' full70金融/保存確認済み '
            rows[found[0]] = '|'.join(parts)
        settings = '\n'.join(rows) + '\n'
    catalogue = lambda text: [line for line in text.splitlines() if re.match(r'^\| (?:I|C|P|V|B|X|M|E)\d{2} \|', line)]
    for pattern, count in [(r'^\| S\d{2} \|', 13), (r'^\| K\d{2} \|', 11)]:
        a = [x for x in before.splitlines() if re.match(pattern, x)]; b = [x for x in settings.splitlines() if re.match(pattern, x)]
        assert a == b and len(b) == count
    assert catalogue(before) == catalogue(settings) and len(catalogue(settings)) == 55
    assert all(len(row.split('|')) - 2 == 11 for row in catalogue(settings))
    assert len(re.findall(r'^\| R\d{2} \|', settings, re.M)) == 20
    prefix = ('<!-- REPORT106:STATUS:BEGIN -->\n**報告準備：実績は未検証/null。**\n' if r is None else '<!-- REPORT106:STATUS:BEGIN -->\n**全70の金融/保存結果を指紋結合した報告。採用/目標達成/未知安定性とは別。**\n')
    prefix += '原計画の同bytesは `原計画/` へ保存。原文の未実行や予定は保存時点の記録で、実績は結果欄を参照する。\n<!-- REPORT106:STATUS:END -->\n\n'
    block = result_block(r, viewer)
    readme_body = block + '\n<details>\n<summary>保存時の原計画</summary>\n\n' + readme + '\n</details>\n' if r else readme + '\n' + block
    output = {'README.md': (prefix + readme_body).encode('utf-8'), '設定と結果.md': (prefix + settings + '\n' + block).encode('utf-8')}
    output.update({'原計画/' + n: b for n, b in originals.items()})
    return output, {n: hashlib.sha256(b).hexdigest() for n, b in originals.items()}


def main() -> None:
    """
    機能: 未検証草案又はRoot許可後の新規実報告を生成し全文checkする。
    引数: --out/--fixed/--fixed-sha/--check は新規先と事後固定/再生成照合。
    返り値: None。正式文書を直接上書きせずxlsxにも触れない。
    """
    parser = argparse.ArgumentParser(); parser.add_argument('--out', type=Path, required=True); parser.add_argument('--fixed', type=Path); parser.add_argument('--fixed-sha'); parser.add_argument('--check', action='store_true'); args = parser.parse_args()
    assert (args.fixed is None) == (args.fixed_sha is None)
    r, inputs, viewer = prepare(args.fixed, args.fixed_sha) if args.fixed else (None, {}, {'確認': False, 'scope': '未確認'})
    output, plans = render(r, viewer)
    projection = {'試行': 106, '状態': '未検証' if r is None else '全70保存小集計の表示', '実績未取込': r is None, '計画': {'場': 70, '開始日': 35, '会計': 1400, '主分母': 7840, '副分母': 7560},
                  '集計': {k: {f: None if r is None else r['集計'][k][f] for f in FIELDS} for k in KEYS}, '機会損失/退出後仮想利益': '未算出'}
    output['結果欄の値.json'] = (json.dumps(projection, ensure_ascii=False, indent=2, default=str) + '\n').encode('utf-8')
    if args.check:
        assert args.out.is_dir() and all((args.out / n).read_bytes() == b for n, b in output.items())
    else:
        args.out.mkdir(parents=True, exist_ok=False)
        for n, b in output.items():
            p = args.out / n; p.parent.mkdir(exist_ok=True, parents=True)
            with p.open('xb') as stream: stream.write(b)
    assert all(sha(Path(p)) == s for p, s in inputs.items())
    print(json.dumps({'成功': True, 'scope': '未検証草案' if r is None else '全70保存小集計の報告', 'check': args.check, 'codeSHA256': sha(Path(__file__)), '入力SHA256': inputs, '原計画SHA256': plans, '55x9/S13K11/R20保持': True, '正式編集/Native/Raw/Source/金融/API/xlsx': 0}, ensure_ascii=False))


if __name__ == '__main__':
    main()
