"""固定済み小集計の場別と集約の型を、報告修正版だけへ接続する。"""
from __future__ import annotations

from copy import deepcopy
import importlib.util
from pathlib import Path
import unittest

WORK = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('report106_actual_shape', WORK / '報告を差し替える_実型対応.py')
R = importlib.util.module_from_spec(spec)
spec.loader.exec_module(R)


class ActualShapeTests(unittest.TestCase):
    """金融を再計算せず、固定保存JSONの正規型と率欠落拒否を確認する。"""

    @classmethod
    def setUpClass(cls) -> None:
        """
        機能: Root固定参照から小集計だけを指紋確認して読む。
        引数: cls (type[ActualShapeTests]) は検査クラス。
        返り値: None。Native/原板/Source/金融/APIを実行しない。
        """
        fixed = R.ROOT / 'work/106報告の実行固定/report.json'
        assert R.sha(fixed) == 'd0ce95569c9b562d4223e60472243bc3b727a16f07bf33a005f11263dc57853c'
        f = R.read_json(fixed)
        cls.before = {}
        cls.summary_path = R.file_ref(f['summary'], fixed.parent, cls.before)
        value = R.read_json(cls.summary_path)
        cls.scene = value['場別'][0]
        cls.aggregate = value['集計'][cls.scene['key']]

    def test_scene_counts(self) -> None:
        """
        機能: 保存実型の場別countsを率の補完なしで検査する。
        引数: self (ActualShapeTests) は検査インスタンス。
        返り値: None。主副の整数分子・分母・和が一致することを要求する。
        """
        self.assertTrue(all('参加率' not in self.scene[k] for k in ('活動主表', '活動副表')))
        R.validate_row(self.scene, 76, 72, scene=True)
        broken = deepcopy(self.scene)
        broken['活動主表']['active'] += 1
        with self.assertRaises(AssertionError):
            R.validate_row(broken, 76, 72, scene=True)

    def test_aggregate_rate_required(self) -> None:
        """
        機能: 集約の主副保存率を必須とし、欠落と別率を拒否する。
        引数: self (ActualShapeTests) は検査インスタンス。
        返り値: None。場別用の免除を集約へ流用しない。
        """
        R.validate_row(self.aggregate, 7840, 7560)
        for label in ('活動主表', '活動副表'):
            with self.subTest(label=label):
                broken = deepcopy(self.aggregate)
                del broken[label]['参加率']
                with self.assertRaises(KeyError):
                    R.validate_row(broken, 7840, 7560)
        broken = deepcopy(self.aggregate)
        broken['活動主表']['参加率'] = 0
        with self.assertRaises(AssertionError):
            R.validate_row(broken, 7840, 7560)

    @classmethod
    def tearDownClass(cls) -> None:
        """
        機能: 検査中に固定保存JSONを変えていないことを確認する。
        引数: cls (type[ActualShapeTests]) は検査クラス。
        返り値: None。入力の前後SHA一致を要求する。
        """
        assert all(R.sha(Path(p)) == s for p, s in cls.before.items())


if __name__ == '__main__':
    unittest.main()
