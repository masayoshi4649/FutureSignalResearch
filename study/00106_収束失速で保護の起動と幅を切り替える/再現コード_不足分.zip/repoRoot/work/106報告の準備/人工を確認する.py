"""報告の表示/算術/未検証区別を手製小集計だけで検査する。"""
from __future__ import annotations

from copy import deepcopy
from decimal import Decimal
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

WORK = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('report106', WORK / '報告を差し替える.py')
R = importlib.util.module_from_spec(spec)
spec.loader.exec_module(R)


def combine(rows: list[dict]) -> dict:
    """
    機能: 手製のflat集約だけを報告検査へまとめる。
    引数: rows (list[dict]) は人工値で実Source/取引ではない。
    返り値: dict は同じ人工算術の集約。
    """
    out = {f: sum(x[f] for x in rows) for f in R.FIELDS}
    out['PF'] = Decimal(out['positive_yen']) / -out['negative_yen'] if out['negative_yen'] else None
    out['保存点連結時価DD'] = 1000000
    for label in ('活動主表', '活動副表'):
        out[label] = {f: sum(x[label][f] for x in rows) for f in ('denom', 'new', 'hold', 'active', 'wait', 'unknown')}
        a = out[label]
        a['参加率'] = Decimal(a['active']) / a['denom']
    return out


def fixture() -> tuple[dict, list[str], list[str]]:
    """
    機能: 既読70IDに独立の架空集約を置きschemaと合計だけを検査する。
    引数: なし。
    返り値: tuple[dict,list,list] は人工集約/場名/手製限月。市場成績ではない。
    """
    m = R.read_json(R.ROOT / 'work/106入力と既存Sourceの整理/標準入力台帳_70場_候補.json')
    sessions = [x['id'] for x in m['sessions']]
    contracts = ['手製A'] * 35 + ['手製B'] * 35
    rows = []
    for i, s in enumerate(sessions):
        group = 'old104_54' if i < 54 else 'fresh106_12' if i < 66 else 'saved105_4'
        for k in R.KEYS:
            pi = ('W0', 'W1', 'W2', 'E1', 'E2').index(k.split('_')[0])
            net = (100 if i % 3 else -50) + 2 * pi
            negative = int(net < 0)
            row = {f: 0 for f in R.FIELDS}
            row.update(session=s, key=k, history_class=group, width_policy=k.split('_')[0], gross_yen=net + 77, fee_yen=77, net_yen=net,
                       positive_yen=max(net, 0), negative_yen=min(net, 0), positions=1, entry_quantity=1,
                       positive_positions=1-negative, negative_positions=negative, unit_positive_positions=1,
                       unit_positive_closed_negative=negative, unit_positive_closed_negative_yen=min(net, 0),
                       protection_activated_positions=1, activated_closed_negative=negative, activated_closed_negative_yen=min(net, 0),
                       early_warning_activations=int(k.startswith('E') and i % 2 == 0), narrowed_positions=int(pi > 0 and i % 2 == 0))
            row['normal_ld10_activations'] = 1-row['early_warning_activations']
            for label, denom in [('活動主表', 76 if s.endswith('_Day') else 148), ('活動副表', 72 if s.endswith('_Day') else 144)]:
                row[label] = {'denom': denom, 'new': 1, 'hold': 1, 'active': 2, 'wait': denom-2, 'unknown': 0, '参加率': Decimal(2)/denom}
            rows.append(row)
    summary, diagnosis = {}, {}
    for k in R.KEYS:
        selected = [x for x in rows if x['key'] == k]
        summary[k] = combine(selected)
        diagnosis[k] = {'日夜': {kind: combine([x for x in selected if x['session'].endswith('_'+kind)]) for kind in ('Day', 'Night')},
                        '日別': [{'開始日': d, **combine([x for x in selected if x['session'].startswith(d)])} for d in sorted({s[:10] for s in sessions})],
                        '履歴区分': {g: combine([x for x in selected if x['history_class'] == g]) for g in R.GROUPS}}
    comparisons = {}
    for pi, p in enumerate(('W0', 'W1', 'W2', 'E1', 'E2')):
        if p == 'W0':
            continue
        for c in (0, 5):
            for d in (0, 1):
                items = []
                for s in sessions:
                    v = {f: 0 for f in R.COMPS}; v.update(session=s, 全差額=2*pi, 同実入口玉=1, 同実入口差額=2*pi); items.append(v)
                comparisons[f'{p}_C{c}_D{d}対W0_C{c}_D{d}'] = {'合計': {f: sum(x[f] for x in items) for f in R.COMPS}, '場別': items}
    controls = [{'session': s, 'kind': 'same_input_old103' if 54 <= i < 66 else 'provided_old_book',
                 'history_class': 'same_input_new12' if 54 <= i < 66 else 'old_saved_58', 'all': True, 'books': 4, 'excluded': [], 'all_point_comparisons': 0} for i, s in enumerate(sessions)]
    public = [{'session': s, 'new_three': 2, 'C_known': 1, 'C_pass': 0,
               'buy': {'M_known': 2, 'M_pass': 1, 'P_known': 0, 'P_pass': 0}, 'sell': {'M_known': 2, 'M_pass': 1, 'P_known': 0, 'P_pass': 0},
               'numeric_seed_carried': i > 0 and contracts[i] == contracts[i-1]} for i, s in enumerate(sessions)]
    return {'試行': 106, '成功': True, 'stage': 'full70', '場数': 70, '会計数': 1400, '集計': summary, '実現診断': diagnosis, '場別': rows,
            '同実入口と実現額差': comparisons, 'W0対照': controls, '一公表単位の役割診断': public,
            '前後不変': True, '入力codeSHA256前': {'手製': 'a'}, '入力codeSHA256後': {'手製': 'a'}}, sessions, contracts


class Tests(unittest.TestCase):
    """市場未読の報告型と原計画保持を検査する。"""

    def test_draft_null_and_plan(self):
        """
        機能: 未検証表示と原文bytes/全表保持を確認する。
        引数: self (Tests) は人工器。
        返り値: None。
        """
        out, _ = R.render(None, {'scope': '未確認'})
        self.assertIn('未検証/null', out['README.md'].decode('utf-8'))
        self.assertIn('対照の実績は未検証', out['README.md'].decode('utf-8'))
        for name in ('README.md', '設定と結果.md'):
            self.assertEqual(out['原計画/'+name], (WORK/'原文'/name).read_bytes())

    def test_typed_fixture(self):
        """
        機能: 手製全20の算術・三区分・公表母数・比較を表示する。
        引数: self (Tests) は人工器。
        返り値: None。実市場の成績へ採用しない。
        """
        r, sessions, contracts = fixture()
        R.validate_result(r, sessions, contracts)
        out, _ = R.render(r, {'scope': '手製の限定確認'})
        self.assertIn('R20 E2_C5_D1', out['README.md'].decode('utf-8'))
        self.assertIn('未達/未達', out['README.md'].decode('utf-8'))
        self.assertEqual(R.amount(Decimal('0.5')), '0.5')
        self.assertEqual(R.rate(0, 0), '未定義（分母0）')

    def test_corrupt_rejections(self):
        """
        機能: 未完/集合/算術/旗/分母/同入口/公表の破損を拒否する。
        引数: self (Tests) は人工器。
        返り値: None。
        """
        for name in ('first2', '1399冊', '20Key不足', '費用', '二旗', '早期二重', '主分母', '区分欠落', '差額', '公表重複', 'carry偽装'):
            with self.subTest(name=name):
                r, sessions, contracts = fixture(); k = R.KEYS[0]
                if name == 'first2': r['stage'] = 'first2'
                elif name == '1399冊': r['会計数'] = 1399
                elif name == '20Key不足': r['集計'].pop(R.KEYS[-1])
                elif name == '費用': r['集計'][k]['fee_yen'] += 1
                elif name == '二旗': r['集計'][k]['unit_positive_closed_negative'] = 999
                elif name == '早期二重': r['集計'][k]['early_warning_activations'] += 1
                elif name == '主分母': r['集計'][k]['活動主表']['denom'] -= 1
                elif name == '区分欠落': r['実現診断'][k]['履歴区分'].pop('fresh106_12')
                elif name == '差額': next(iter(r['同実入口と実現額差'].values()))['合計']['同実入口差額'] += 1
                elif name == '公表重複': r['一公表単位の役割診断'][1] = r['一公表単位の役割診断'][0]
                elif name == 'carry偽装': r['一公表単位の役割診断'][0]['numeric_seed_carried'] = True
                with self.assertRaises((AssertionError, KeyError)):
                    R.validate_result(r, sessions, contracts)

    def test_original_missing(self):
        """
        機能: 元planの欠落を既知の0行へ置換しない。
        引数: self (Tests) は人工器。
        返り値: None。
        """
        for removed in ('| I01 |', '| S13 |', '| K11 |', '| R20 |'):
            with tempfile.TemporaryDirectory() as tmp:
                p = Path(tmp); (p/'原文').mkdir()
                for name in ('README.md', '設定と結果.md'):
                    text = (WORK/'原文'/name).read_text(encoding='utf-8')
                    (p/'原文'/name).write_text('\n'.join(x for x in text.splitlines() if not x.startswith(removed)), encoding='utf-8')
                with patch.object(R, 'WORK', p):
                    with self.assertRaises(AssertionError):
                        R.render(None, {'scope': '未確認'})

    def test_not_ready_before_result(self):
        """
        機能: 市場結果の開封許可が無ければ結果FileRefより前で拒否する。
        引数: self (Tests) は人工器。
        返り値: None。
        """
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp)/'固定.json'
            p.write_text(json.dumps({'version': 1, 'trial': 106, 'fixed': True, 'result_ready': False, 'summary': {'path': '開かない結果.json', 'sha256': 'a'*64}}), encoding='utf-8')
            with self.assertRaises(AssertionError): R.prepare(p, R.sha(p))

    def test_separate_activation_diagnostic(self):
        """
        機能: 8本の別対比較を保存正本差と照合し途中/加法式破損を拒否する。
        引数: self (Tests) は手製人工器。
        返り値: None。実金融とNativeを読み直さない。
        """
        r, sessions, _ = fixture()
        extra = {'試行': 106, '成功': True, 'stage': 'full70', '場数': 70, '比較数': 8,
                 '前後不変': True, '入力SHA256前': {'手製': 'a'}, '入力SHA256後': {'手製': 'a'}, '金融再実行': 0, '比較': {}}
        for n in (1, 2):
            for c in (0, 5):
                for d in (0, 1):
                    a, b = f'W{n}_C{c}_D{d}', f'E{n}_C{c}_D{d}'
                    rows = []
                    for s in sessions:
                        row = {k: 0 for k in R.COMPS}; row.update(session=s, 全差額=4, 同実入口玉=1, 同実入口差額=4); rows.append(row)
                    total = {k: sum(x[k] for x in rows) for k in R.COMPS}
                    for label, key in [('前', a), ('後', b)]:
                        total[label+'の通常LD10起動'] = r['集計'][key]['normal_ld10_activations']
                        total[label+'の早期起動'] = r['集計'][key]['early_warning_activations']
                    extra['比較'][b+'対'+a] = {'合計': total, '場別': rows}
        R.validate_activation_comparison(extra, r)
        for kind in ('first2', '加法式', '起動二重', '場数欠落'):
            broken = deepcopy(extra)
            if kind == 'first2': broken['stage'] = 'first2'
            elif kind == '加法式': next(iter(broken['比較'].values()))['合計']['同実入口差額'] += 1
            elif kind == '起動二重': next(iter(broken['比較'].values()))['合計']['後の早期起動'] += 1
            else: next(iter(broken['比較'].values()))['場別'].pop()
            with self.assertRaises(AssertionError): R.validate_activation_comparison(broken, r)


if __name__ == '__main__':
    unittest.main(verbosity=2)
