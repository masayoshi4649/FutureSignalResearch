"""106報告器を未検証草案・原計画・人工だけへ結び停止する。"""
from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path
import subprocess
import sys

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]


def sha(path: Path) -> str:
    """
    機能: 明示コード・文書・小JSONの指紋を返す。
    引数: path (Path) は対象。
    返り値: str はSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(args: list[str], log: str) -> dict:
    """
    機能: 手製検査又は草案/checkだけを実行し結果を保存する。
    引数: args (list[str])、log (str) は命令とログ名。
    返り値: dict は終了0とログSHA。不成立で停止する。
    """
    p = subprocess.run(args, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False)
    dest = WORK / '検査' / log
    dest.write_bytes(p.stdout)
    assert p.returncode == 0, p.stdout.decode('utf-8', errors='replace')
    return {'命令': args, '終了': p.returncode, 'ログ': str(dest.relative_to(ROOT)), 'SHA256': sha(dest)}


def main() -> None:
    """
    機能: 未検証草案と原計画保持を検査して新規停止JSONへ保存する。
    引数: なし。実結果取込みモードを呼ばない。
    返り値: None。正式文書/金融/Native/Raw/Viewer/xlsxの実行編集0。
    """
    assert not (WORK / '停止.json').exists()
    (WORK / '検査').mkdir(exist_ok=False)
    before = json.loads((WORK / '原文と由来の前指紋.json').read_text(encoding='utf-8'))
    assert all(sha(ROOT / p) == s for p, s in before.items())
    py = [sys.executable, '-B', '-X', 'utf8']
    checks = [run(py + [str(WORK / '人工を確認する.py')], '人工.txt')]
    helper, draft = str(WORK / '報告を差し替える.py'), str(WORK / '草案_停止版')
    checks.append(run(py + [helper, '--out', draft], '草案生成.json'))
    checks.append(run(py + [helper, '--out', draft, '--check'], '草案check.json'))
    values = json.loads((Path(draft) / '結果欄の値.json').read_text(encoding='utf-8'))
    assert values['状態'] == '未検証' and values['実績未取込'] is True
    assert len(values['集計']) == 20 and all(v is None for row in values['集計'].values() for v in row.values())
    for name in ('README.md', '設定と結果.md'):
        assert (Path(draft) / '原計画' / name).read_bytes() == (WORK / '原文' / name).read_bytes()
    for p in WORK.glob('*.py'):
        ast.parse(p.read_text(encoding='utf-8'), filename=str(p))
    assert all(sha(ROOT / p) == s for p, s in before.items())
    own = ['報告を差し替える.py', '人工を確認する.py', '検査と停止を記録する.py', 'README.md', '実結果の固定雛形.json', '原文/README.md', '原文/設定と結果.md']
    proof = {'成功': True, 'scope': '106報告の未検証草案・手製小集計と保存schemaだけ',
             '所有コードSHA256': {str((WORK / p).relative_to(ROOT)): sha(WORK / p) for p in own},
             '原文と由来SHA256': before, '前後不変': True, '検査': checks,
             '人工': {'トップ': 6, '破損拒否': 20, '元計画欠落': 4, '全70手製集約': True, '別起動8比較の加法式': True},
             '原計画保持': {'55手法': 55, '尺度': 9, 'S設定': 13, 'K設定': 11, 'R評価': 20, '原bytes2文書': True},
             '未検証実績': '全null', '市場70実績読取': 0, 'first2実績採用': 0,
             '出力SHA256': {str(p.relative_to(Path(draft))): sha(p) for p in Path(draft).rglob('*') if p.is_file()},
             '後段受口': 'Root事後固定5FileRef、optional viewer_evidence/activation_comparison_json/activation_comparison_md',
             '検査対象外': ['実full70金融/保存結果の接続', '新8対比較の実JSON接続', '実Viewer', '正式文書反映', '未知期間安定性/実採用'],
             'Raw/Source/Native/金融/API/xlsx実行': 0, '正式文書/停止元編集': 0}
    with (WORK / '停止.json').open('x', encoding='utf-8') as stream:
        json.dump(proof, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'成功': True, '停止SHA256': sha(WORK / '停止.json'), 'helperSHA256': sha(WORK / '報告を差し替える.py')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
