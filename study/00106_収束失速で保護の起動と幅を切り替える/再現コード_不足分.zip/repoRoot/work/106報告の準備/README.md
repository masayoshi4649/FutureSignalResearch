# 106の報告準備

正式106のREADME/設定と結果を保存時のbytesで`原文/`へ保管し、正式を変更せず結果欄を作る小helper。市場全70の結果は未読。実績は未検証/null、準備/計算/保存の成功を経済目標や採用へ置換しない。xlsxは別担当で、本helperは扱わない。

105停止e095のFileRef/Decimal/表示関数だけをSHA importする。仕上4453は原文保持と証拠scopeの参考とし、106の金融/保存/市場コードを変更しない。保存schemaは停止3dd87/集計7451の公開型へ合わせた。

```powershell
work/venvs/technical-tree/Scripts/python.exe -B -X utf8 `
  work/106報告の準備/報告を差し替える.py --out <存在しない草案dir>
work/venvs/technical-tree/Scripts/python.exe -B -X utf8 `
  work/106報告の準備/報告を差し替える.py --out <同草案dir> --check
```

全55×9、S01〜13/K01〜11の24行は原文行を保持。R01〜20は費用/政策/内Activationを保持し、Root許可後の実結果取込で純額・参加・状態だけを更新する。READMEの未実行表記は原計画として区別し、元2文書は`原計画/`に同bytes保持する。`結果欄の値.json`は未取込なら実績全null。実取込時のDecimalは表示用JSONでは文字列で保存し、金額正本を置換しない。

## 報告欄

- 全20の粗額、実費用、仮定滑り、純額、正負額、PF、保存点DD、玉/枚。C5/D1は動的別運転。
- u正益後赤字/u未観測赤字と保護起動後赤字を別分母。通常LD10・E早期・狭幅も別件数。
- 日中2660/夜間5180、主7840/副7560、最低25%・目標50%。欠測/US静観を分母へ残す。
- old104_54 / saved105_4 / fresh106_12の三群と日別35の合計を全体へ照合。70セッション・35開始日を20政策費用や玉数で水増ししない。
- 公表は各場一回のnew_three/C_known/pass、buy/sellのM/P_known/passで集約する。cold/carryは場と限月に照合し、20会計分へ重複加算しない。
- W0既存58の旧最終四冊全文と、新12の同入力旧Actor四冊を区別。市場全原行の別engine照合ではない。
- W0対16比較は同実入口・取得変更・前のみ/後のみの実現額を加法分解。SourceIDだけを同実入口の根拠としない。

W0/W1/W2は主に起動後の幅、E1/E2は早期ORも変わる。同実入口の差でも幅経路・起動時機・その後の参加が複合するため、差額をC/M/P単独の因果効果としない。機会損失、退出後値幅、MFE回収率、仮想約定、ROIは計算しない。

## Rootの事後固定（将来）

`version:1,trial:106,fixed:true,result_ready:true`と5FileRefを新しいJSONへ固定する。必須は`summary`（保存結果）、`saved_check`、`financial_completion`、`condition`、`source_completion`（追加12全Source）。FileRefはfixed JSON parent基準。保存コード7451、条件/金融/保存指紋、全70/1400/35日、Source12/36case、入力前後同一を検査してから実績を読む。first2の40会計を全70へ採用しない。

```powershell
work/venvs/technical-tree/Scripts/python.exe -B -X utf8 `
  work/106報告の準備/報告を差し替える.py `
  --fixed <実結果の事後固定.json> --fixed-sha <実SHA> --out <新規報告dir>
# 同入力からの全生成bytes一致
work/venvs/technical-tree/Scripts/python.exe -B -X utf8 `
  work/106報告の準備/報告を差し替える.py `
  --fixed <同fixed> --fixed-sha <同SHA> --out <同報告dir> --check
```

本helperは正式へ直接copyしない。Rootが結果・関連証拠を確認後に正式反映する。草案中の相対リンクは正式106の位置を基準とする。

`viewer_evidence`はoptional。提供された成功JSONの実scopeをそのまま記し、代表確認を全件HTTPへ拡大しない。未提供は未確認のまま。

起動時機を近い政策間で比較する別診断8本（E1対W1/E2対W2、各4費用）は、`activation_comparison_json`/`activation_comparison_md`の2FileRefで後から結ぶ。未提供は未取込・未検証。JSONは全差額加法式・同費用の保存純額差・前後通常/早期起動と合うこと、同じsummary/financial SHAを入力にしたことを確認する。別診断のファイル名は`同幅の起動差.json/md`。同じ幅選択規則であり、実際の床/幅経路まで同一という意味ではない。元保存正本を変更しない。

## 人工と未実施

人工は手製集約だけで未検証表示、全20/三群/二旗/参加/公表/実入口の算術、原plan欠落、未完first2混入、別診断8本の破損を拒否する。架空値を実市場成績へ採用しない。実Raw/CSV/Native/Source/金融/Viewer/xlsxは0、正式106/旧停止の編集0。
