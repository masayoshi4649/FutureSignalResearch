"""停止c0bfを変更せずE1/E2の最小外周を派生する。"""
from pathlib import Path


def main():
    """
    機能: 旧可変幅本体を新module/packageへ同体派生する。
    引数: なし。
    返り値: None。市場・旧Native本文を開かない。
    """
    here = Path(__file__).resolve().parent
    old = here.parent / "収束可変幅の保護会計案"
    for p in old.glob("*.go"):
        (here / p.name).write_text(p.read_text(encoding="utf-8-sig").replace("package minivariableguard", "package miniearlyguard"), encoding="utf-8")
    mod = (old / "go.mod").read_text(encoding="utf-8-sig").replace("module github.com/masayoshi4649/SessionTradeExecuter/minivariableguard", "module github.com/masayoshi4649/SessionTradeExecuter/miniearlyguard")
    mod += "\nrequire github.com/masayoshi4649/SessionTradeExecuter/minivariableguard v0.0.0\nreplace github.com/masayoshi4649/SessionTradeExecuter/minivariableguard => ../収束可変幅の保護会計案\nrequire github.com/masayoshi4649/SessionTradeExecuter/publicdelivery v0.0.0\nreplace github.com/masayoshi4649/SessionTradeExecuter/publicdelivery => ../収束可変幅の公開配送案\nrequire github.com/masayoshi4649/SessionTradeExecuter/publicchart v0.0.0\nreplace github.com/masayoshi4649/SessionTradeExecuter/publicchart => ../可変追尾向けの公開チャート\n"
    (here / "go.mod").write_text(mod, encoding="utf-8")
    (here / "go.sum").write_bytes((old / "go.sum").read_bytes())


if __name__ == "__main__":
    main()
