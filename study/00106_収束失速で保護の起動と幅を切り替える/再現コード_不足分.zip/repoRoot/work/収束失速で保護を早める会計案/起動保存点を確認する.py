"""非市場Go型のE1/E2初回起動点だけを独立算術で検査する。"""
from pathlib import Path
import hashlib
import json
import sys


def main():
    """
    機能: 初回起動点のu/ATR二閾値/警戒/enum/公開出典を検査する。
    引数: argv[1:3](str)は人工rootと新証拠先。
    返り値: None。全原行初回適格性や独立金融engine再生は主張しない。
    """
    root, out = Path(sys.argv[1]), Path(sys.argv[2])
    counts = {"books": 0, "early_warning": 0, "normal_ld10": 0}
    inputs = {}
    for p in sorted(root.glob("方向*.json")):
        raw = p.read_bytes()
        inputs[p.name] = hashlib.sha256(raw).hexdigest()
        v = json.loads(raw)
        b, audit = v["book"], v["early_audit"]
        policy = b["config"]["activation_policy"]
        assert policy in ("E1", "E2") and b["key"].startswith(policy + "_") and audit["policy"] == policy
        positions = {x["id"]: x for x in b["positions"]}
        for a in audit["positions"]:
            pos, point = positions[a["position_id"]], a["point"]
            assert point == pos["activation"] and a["atr_value"] == pos["atr"]["value"]
            gain = float(pos["side"]) * (point["mark_price"] - pos["entry_price"])
            unit = gain * 100 - (77 + 2 * b["config"]["slip_pts"] * 100)
            assert unit == point["unit_net"]
            low = 100 * max(10, 0.5 * a["atr_value"])
            normal = 100 * max(10, a["atr_value"])
            assert low == a["early_threshold_yen"] and normal == a["normal_threshold_yen"]
            if a["trigger"] == "normal_ld10":
                assert unit >= normal
            else:
                assert a["trigger"] == "early_warning" and low <= unit < normal
                o = a["observation"]
                assert o is not None and o["end"] <= point["quote"]["time"] and o["available_at"] <= point["quote"]["time"]
                for key in (("c", "m") if policy == "E1" else ("c", "m", "p")):
                    assert o[key] == {"known": True, "passed": True}
                assert a["warning"] == {"known": True, "passed": True}
            assert pos["activation_reason"].startswith(policy)
            counts[a["trigger"]] += 1
        counts["books"] += 1
    assert counts == {"books": 32, "early_warning": 16, "normal_ld10": 16}
    value = {"成功": True, "scope": "非市場Go32冊の保存初回点の実額u・固定ATR閾値・警戒出典のみ。全原行/初回適格の独立再生ではない", "counts": counts, "入力SHA256": inputs, "市場/Raw/旧Native読取": 0}
    with out.open("x", encoding="utf-8", newline="\n") as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write("\n")
    print(json.dumps({"成功": True, "counts": counts}, ensure_ascii=False))


if __name__ == "__main__":
    main()
