"""E1/E2の限定派生を非市場の旧全文対照と指紋へ結ぶ。"""
from pathlib import Path
import difflib
import hashlib
import json
import os
import re
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OLD = HERE.parent / "収束可変幅の保護会計案"


def sha(path):
    """
    機能: コード/停止metadata/手製人工だけのSHA256を求める。
    引数: path(Path)は明示した参照。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def label(path):
    """
    機能: repo内を相対、外を絶対pathへ表示する。
    引数: path(Path)は参照。
    返り値: strは再読可能な名前。
    """
    try:
        return path.relative_to(ROOT).as_posix()
    except ValueError:
        return str(path)


def save(path, value):
    """
    機能: 新しい証拠JSONだけを保存する。
    引数: path(Path)、value(dict)は新規先と証拠。
    返り値: None。
    """
    with path.open("x", encoding="utf-8", newline="\n") as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write("\n")


def run(args, **extra):
    """
    機能: 明示した非市場Go/人工Pythonコマンドを実行する。
    引数: args(list[str])、extra(dict)はコマンドと環境。
    返り値: CompletedProcessは成功した終了値と出力。失敗時は例外。
    """
    r = subprocess.run(args, cwd=HERE, capture_output=True, encoding="utf-8", **extra)
    if r.returncode:
        raise RuntimeError({"command": args, "exit": r.returncode, "stdout": r.stdout, "stderr": r.stderr})
    return r


def inverse(name, text):
    """
    機能: 宣言したE拡張だけを逆置換して停止c0bf本文へ戻す。
    引数: name(str)、text(str)は新Goファイル名と本文。
    返り値: strは元packageのコード。他の差は後の全文比較で拒否する。
    """
    text = text.replace("package miniearlyguard", "package minivariableguard")
    if name == "activation.go":
        text = re.sub(r'(?m)^\s*ActivationE[12]\s+ActivationPolicy\s*=\s*"E[12]"\s*\n', "", text)
        text = text.replace("case ActivationLD05, ActivationLD10, ActivationE1, ActivationE2:", "case ActivationLD05, ActivationLD10:")
        text = text.replace("\tif isEarlyActivation(policy) {\n\t\treturn false\n\t}\n", "", 1)
    if name == "actual.go":
        text = text.replace('\tif isEarlyActivation(cfg.ActivationPolicy) {\n\t\treturn nil, fmt.Errorf("E1/E2は公表出典付きNewEarlyBookを使ってください")\n\t}\n', "", 1)
        text = text.replace("\t\tif err := b.activateProtection(p, point); err != nil {\n\t\t\treturn err\n\t\t}\n", "\t\tif !p.ProtectionActive && activationEligible(b.result.Config.ActivationPolicy, p.ATR, unit) {\n\t\t\tp.ProtectionActive = true\n\t\t\tcopy := point\n\t\t\tp.Activation = &copy\n\t\t\tp.ActivationReason = activationReason(b.result.Config.ActivationPolicy)\n\t\t}\n", 1)
        text = text.replace("\t\t\t\tif isEarlyActivation(b.result.Config.ActivationPolicy) {\n\t\t\t\t\treason = earlyExitReason(b.result.Config.ActivationPolicy)\n\t\t\t\t}\n", "", 1)
    if name == "width_book.go":
        text = re.sub(r"(?m)^\s*Activations\s+map\[string\]EarlyActivationAudit\s*\n", "", text)
    if name == "width_state.go":
        text = text.replace(' && policy != "E1" && policy != "E2"', "").replace('if s.Policy == "W2" || s.Policy == "E2" {', 'if s.Policy == "W2" {')
    return text


def main():
    """
    機能: 元コード復元・旧W全JSON対照・E人工を新停止へ保存する。
    引数: なし。
    返り値: None。Raw/CSV/市場Source/旧Native/金融本番は実行しない。
    """
    assert not (HERE / "停止.json").exists()
    check, final = HERE / "検査", HERE / "人工_停止版"
    check.mkdir(exist_ok=True)
    final.mkdir()
    stops = {
        "work/収束可変幅の保護会計案/停止.json": "c0bfc8cfc8f870e99f9c994d26173b4295b42dad1fde872a5b5ee91b7c09317a",
        "work/収束可変幅の公開配送案/停止.json": "8c426b5791df0c3d327d0224ecfe48baac7c319a6d1fb776672cecdf79733015",
        "work/105四場Sourceの再形成/停止.json": "f52676b0cc55fe2fbdbb0f6524161950af4babbb5891513723a01b5f2618c28a",
        "work/105四場の時計とLD10確認/停止.json": "0a41056d1a9d0c14d13e0bf23d3f78fe7ce1ffb42b13dd2dfb898d8f81802299",
    }
    before = {}
    for name, h in stops.items():
        p = ROOT / name
        assert sha(p) == h
        before[name] = h
        d = json.loads(p.read_text(encoding="utf-8-sig"))
        owned = d.get("所有コードSHA256", d.get("所有SHA256", {}))
        assert owned
        for path, expected in owned.items():
            assert sha(ROOT / path) == expected, path
            before[path] = expected
    for name in ["docs/議論/追尾起動前後の赤字と早期保護の切替候補.md", "work/収束可変幅の公開配送案/人工_停止版/Go公開12の配送.json"]:
        before[name] = sha(ROOT / name)
    dirs = run(["go", "list", "-deps", "-f", "{{if not .Standard}}{{.Dir}}{{end}}", "./..."]).stdout.splitlines()
    for directory in dirs:
        d = Path(directory)
        if d == HERE:
            continue
        for p in sorted(d.glob("*.go")):
            before[label(p)] = sha(p)
        for name in ["go.mod", "go.sum"]:
            p = d / name
            if p.is_file():
                before[label(p)] = sha(p)
    save(HERE / "元と依存の前指紋.json", before)
    # ----------------------------------------
    mapping, patch = {}, []
    for p in sorted(OLD.glob("*.go")):
        n = HERE / p.name
        old, new = p.read_text(encoding="utf-8-sig"), n.read_text(encoding="utf-8-sig")
        restored = inverse(p.name, new)
        assert run(["gofmt"], input=restored).stdout == run(["gofmt"], input=old).stdout, p.name
        mapping[p.name] = {"旧path": label(p), "旧SHA256": sha(p), "新path": label(n), "新SHA256": sha(n), "package/E宣言差逆置換gofmt全文同体": True}
        if p.name in ["activation.go", "actual.go", "width_book.go", "width_state.go"]:
            patch.extend(difflib.unified_diff(old.splitlines(True), new.splitlines(True), fromfile=label(p), tofile=label(n)))
    (HERE / "E拡張の限定差分.patch").write_text("".join(patch), encoding="utf-8", newline="\n")
    assert (HERE / "go.sum").read_bytes() == (OLD / "go.sum").read_bytes()
    save(HERE / "由来と本文確認.json", {"成功": True, "元停止": stops, "対応": mapping, "新規": ["early.go", "early_test.go", "public_adapter.go", "public_adapter_test.go"], "既存金融field": "actual_types.goはpackage変更だけ。ActivationPolicy enum値E1/E2と既存理由fieldを明示使用", "Source/費用/数量/予約/約定順変更": False, "旧保存validator": "E1/E2未対応。後段に新検算が必要"})
    env = dict(os.environ, EARLY_EXPORT=str(final), WIDTH_PURE_EXPORT=str(final / "旧W純状態.json"))
    test = run(["go", "test", "-count=1", "-json", "./..."], env=env)
    log = check / "最終Go_test.jsonl"
    log.write_text(test.stdout, encoding="utf-8", newline="\n")
    events = [json.loads(s) for s in test.stdout.splitlines() if s]
    assert any(e.get("Action") == "pass" and "Test" not in e for e in events)
    names = [e["Test"] for e in events if e.get("Action") == "pass" and "Test" in e]
    vet, build = run(["go", "vet", "./..."]), run(["go", "build", "./..."])
    run([sys.executable, "-B", "-X", "utf8", str(OLD / "停止純幅と照合する.py"), str(final / "旧W純状態.json"), str(check / "旧Wの停止Python照合.json")])
    run([sys.executable, "-B", "-X", "utf8", str(HERE / "起動保存点を確認する.py"), str(final), str(check / "E初回起動保存点の算術確認.json")])
    artifacts = {label(p): sha(p) for p in sorted(final.glob("*.json"))}
    assert len(artifacts) == 33
    after = {name: sha(Path(name) if Path(name).is_absolute() else ROOT / name) for name in before}
    assert before == after
    save(HERE / "元と依存の前後照合.json", {"成功": True, "前": before, "後": after, "前後不変": True, "範囲": "元停止owned/Goコード/根拠MD/明示手製人工だけ。実価格/市場結果本文は読まない"})
    receipt = {"成功": True, "Go成功top": sum("/" not in n for n in names), "小試験込成功": len(names), "test/vet/build": {"test": 0, "vet": vet.returncode, "build": build.returncode}, "Goログ": {"path": label(log), "SHA256": sha(log)}, "旧W0/W1/W2全JSON除外0": {"非0冊": 48, "全時点Book": 1056, "全時点WidthAudit": 1056, "最終Book": 48, "最終WidthAudit": 48, "除外": []}, "E基本API": {"非0冊": 32, "早期": 16, "通常LD10": 16, "Side/C/D/ATR既知未知": True}, "EのSource予約優先": {"非0冊": 16, "保護要求": 0}, "未知/否定/reset/未来fallback": {"小ケース": 11, "通常LD10維持": True}, "単価>=閾値": "2037.5円の隣接IEEE値/等号、4075円同時成立の通常優先8点。内部MTM純判定で金融形成とは別", "公開配送8c42のnamed型": {"公表": 12, "両方向全field": 24, "公表だけの起動/注文": 0}, "旧W純幅Python": {"ケース": 48, "全field差": 0}, "E保存初回点の独立算術": {"path": label(check / "E初回起動保存点の算術確認.json"), "SHA256": sha(check / "E初回起動保存点の算術確認.json"), "全経路再生": False}, "人工SHA256": artifacts, "参照数": len(before), "前後不変": True, "Raw/CSV/旧Native/Source市場本文読取": 0, "金融本番実行": 0}
    save(check / "人工確認.json", receipt)
    owned = {label(p): sha(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name != "停止.json"}
    stop = {"成功": True, "scope": "未採番・非市場。通常LD10又はLD05水準＋既知警戒で起動するE1/E2の小派生", "module": "github.com/masayoshi4649/SessionTradeExecuter/miniearlyguard", "所有コードSHA256": owned, "元停止": stops, "人工確認": {"path": label(check / "人工確認.json"), "SHA256": sha(check / "人工確認.json")}, "旧W全JSON": "全時点Book/WidthAudit各1056・最終各48・除外0", "新enum": ["E1", "E2"], "新起動audit": "EarlyAudit。通常LD10/早期を区別、MTMと全公表根拠を保持", "新金融field": False, "旧保存validator": "新政策未対応。新検算/新receiptが別途必要", "元/105停止前後不変": True, "参照指紋": {"path": label(HERE / "元と依存の前後照合.json"), "SHA256": sha(HERE / "元と依存の前後照合.json")}, "test/vet/build": {"test": 0, "vet": 0, "build": 0}, "Raw/CSV/旧Native/Source市場本文読取": 0, "金融本番実行": 0, "新採番/条件/実場結合/収益採用": False, "実行物": "Go libraryだけ。市場CLIなし", "未実施": ["C/M/P実場sidecarとのSource/価格出典bind", "市場運転と実現成績", "E専用保存/独立全経路検算", "未使用期間での採用確認"], "限界": "非0人工は手製DayのSource/ATR/CMPと売買鏡像・C/D感度。独立市場例や自然Source形成の証明ではない"}
    save(HERE / "停止.json", stop)
    print(json.dumps({"停止": label(HERE / "停止.json"), "SHA256": sha(HERE / "停止.json"), "所有": len(owned), "Go成功top": receipt["Go成功top"], "小試験": len(names), "参照": len(before)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
