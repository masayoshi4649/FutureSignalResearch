# 収束・失速警戒で保護を早める非市場会計案

未採番。module `github.com/masayoshi4649/SessionTradeExecuter/miniearlyguard`、package `miniearlyguard`。停止c0bfを最小派生し、元W0/W1/W2・105・公開配送8c42を変更しない。[根拠メモ](../../docs/議論/追尾起動前後の赤字と早期保護の切替候補.md)の未採用候補を手製公開型だけで確認する。市場/Raw/CSV/旧Native/実Source結果本文は開かない。

105ではLD未起動側に大半のu正益後最終赤字があった。LD起動後の狭幅だけの効果と早期起動の効果を混ぜない。この案も105を見た後の仮説であり、収益改善・未使用期間での成功・採用を意味しない。

## 新政策

`u` は旧会計が正常な返済側気配から計算した残玉一枚の費用後円単価。閾値は **取得時又は初回既知で固定したnative ATR12のValue** を使い、丸め幅Widthへ置換しない。

|ActivationPolicy|起動のOR条件|警戒成立時の幅|
|---|---|---|
|E1|通常LD10 `u>=100*max(10,ATRValue)`、又は `u>=100*max(10,0.5*ATRValue)` かつ既知C&M|約1ATR（5pt切上げ、最低5）|
|E2|同じ通常LD10、又は同じ一定利益かつ既知C&M&P|同左|

通常LD10と警戒条件が同時成立した場合は **通常LD10到達** を起動理由にする。早期だったと誤記しない。警戒なし/必要未知/resetでも通常LD10は必ず維持する。ATR未知はどちらも保留。公表だけで起動しない。LD05水準と警戒が同時に実正常markで揃った時だけ早める。

通常幅は旧2ATR、警戒成立時は1ATRへ一度だけ狭め、終玉まで広げない。起動前latestを保存し、初めて閾値に到達したmarkで使える。同ID再送・未知・未来・resetを支持へ変換せず、resetで既存狭幅/峰/床を緩めない。床は `max(0, 観測PeakGain−選択幅, 前床)`。元のSource予約を優先し、未予約実残だけをafter_sourceで要求。同原行fill禁止、C0/C5・D0/D1・部分返済・Force・各側10も元のまま。

## 明示する型

`ActorConfig.ActivationPolicy` は新enum `E1` / `E2`。Keyは `E1_B5Q_P0_C0_D0` 等、Position.ActivationReasonはE政策と通常/早期を明示する。元LD10と名乗ったまま中身を変更しない。新しい金融fieldは足していない。

```go
b, err := NewEarlyBook(session, ActorConfig{
    Policy: "P0", EntryTiming: "B5Q", ActivationPolicy: ActivationE1,
    SlipPts: 0, DelaySeconds: 0,
}, contract)
```

Eは専用constructor必須。旧 `NewActualBook` / `NewWidthBook(W0/W1/W2)` にEを渡すと拒否する。旧W0/W1/W2は以前と同じAPI・Config・Key・全金融JSON・別WidthAuditを維持する。

- `WidthAudit()`：E1/E2名の幅state、初回狭幅MTM・公表全文。純幅のC/M又はC/M/P評価・通常/狭幅丸めは元規則を保つ。
- `EarlyAudit()`：最初の起動だけの別audit。`trigger=normal_ld10|early_warning`、当時MTM、ATRValue、二閾値、警戒三値、使った公開Observation全値を保持する。後続の値で上書きしない。
- `PublicReceiver{Book:b}`：停止公開配送8c42の旧named型を全field明示変換する薄いadapter。`delivery.Send(d, PublicReceiver{Book:b})` を使える。元の公開配送は編集しない。

起動点の `Position.Activation` は旧MTM型であり、EarlyAuditのPointと全文一致。u初回正益flagやQuantity/Reservedを前倒ししない。公表後の価格を起動点へ戻さない。

## 検査範囲

旧W0/W1/W2を、買売×ATR既知未知×C/Dの48冊で停止c0bfの独立Bookへ配送。全時点1,056件＋同数WidthAudit、最終48件＋WidthAuditを全JSON・除外0で比較する。元の手製Source器具から通知を作り、旧Nativeや市場成績を期待値として読まない。

E1/E2は買売×ATR既知未知×C0/C5×D0/D1の32非0冊。40.75ATRの通常閾値4075円/早期閾値2037.5円を区別し、P未知→既知、通常fallback、Source部分/追加・予約、狭幅、同秒悪化気配、Force、残0を確認する。さらにSource全予約優先16冊、必要未知/既知否定/reset同ID/未来拒否の狭い境界、停止公開12型→新named型24全field対応も検査する。

外部C/M/Pは手製の既知性・結果型であり、EMA/OHLC/pivotをこの会計で形成しない。公開型のData出典・公表時計は配送側の責務。自然市場でそれらの警戒が発生していた証明ではない。旧Wの保存算術は使えても、**旧保存validatorはE1/E2起動と新理由を未対応**。P0初回正益やLD10成立へ誤って戻さず、後段に新しい起動・公表・幅の検算が必要。本版に市場保存CLIはない。

`go test -json ./...` / `go vet ./...` / `go build ./...`。`EARLY_EXPORT` は明示した非市場JSONの出力先のみ。実場sidecar結合・金融本番・新条件・採番・収益による候補選別・機会損失/MFE/退出後価格の評価は未実施。
