package publicsidecar

import (
	"encoding/json"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"reflect"
	"testing"

	continuous "github.com/masayoshi4649/SessionTradeExecuter/continuous101"
	"github.com/masayoshi4649/SessionTradeExecuter/internal/strategy"
	chart "github.com/masayoshi4649/SessionTradeExecuter/publicchart"
)

// fixture はSource/金融を持たない二市場の手製公開入力を作ります。
//
// 引数: start(float64)、side(int)は場頭と人工価格の鏡像符号です。
// 返り値: continuous.Request/[]Forceは全boardと時計参照だけです。
func fixture(start float64, side int) (continuous.Request, []Force) {
	s := strategy.Session{ID: "手製Day", Kind: "Day", Start: start, End: start + 4200, ForceClose: start + 3600}
	r := continuous.Request{Session: s, Scene: chart.Scene{ID: s.ID, Contract: "手製限月", Start: s.Start}}
	for at := s.Start; at < s.End; at += 300 {
		r.Grids = append(r.Grids, at)
	}
	line := int64(0)
	for i := 0; i < 70; i++ {
		at := start + float64(i)*60
		price := 10000 + float64(side)*(float64(i)+8*math.Sin(float64(i)/3))
		// 同時計TOPIXを意図的に後ろへ置き、旧stable mergeへそのまま委ねる。
		line++
		last := price
		if i == 10 {
			last = 0
		}
		r.Rows = append(r.Rows, continuous.Row{Board: strategy.Board{Reference: "NK225", Time: at, Received: at, Last: last, Bid: price - 5, Ask: price + 5}, PhysicalLine: line})
		if i == 10 {
			line++
			r.Rows = append(r.Rows, continuous.Row{Board: strategy.Board{Reference: "NK225", Time: at, Received: at, Last: price, Bid: price - 5, Ask: price + 5}, PhysicalLine: line})
		}
		r.Rows = append(r.Rows, continuous.Row{Board: strategy.Board{Reference: "TOPIX", Time: at, Received: at, Last: 2500, Bid: 2499.5, Ask: 2500.5}, PhysicalLine: int64(i + 1)})
	}
	return r, []Force{{At: s.ForceClose, TapeOrdinal: 99}}
}

// collect は手製入力を同じ逐次APIへ送り、型人工だけをメモリへ保存します。
//
// 引数: req(continuous.Request)、seed(*Seed)、forces([]Force)は人工の公開値です。
// 返り値: Header/*Seed/[]Record/errorは人工の公開配送結果です。
func collect(req continuous.Request, seed *Seed, forces []Force) (Header, *Seed, []Record, error) {
	records := []Record{}
	h, next, err := Build(req, seed, forces, func(r Record) error {
		records = append(records, r)
		return nil
	})
	return h, next, records, err
}

// TestAllBoardMirror は鏡像・Last0・全公表・Scalar出典・入力不変を確認します。
//
// 引数: t(*testing.T)はGo人工器です。
// 返り値: なし。不一致で失敗します。市場標本には数えません。
func TestAllBoardMirror(t *testing.T) {
	for _, side := range []int{1, -1} {
		req, forces := fixture(1000000, side)
		before, _ := json.Marshal(req)
		h, _, records, err := collect(req, nil, forces)
		if err != nil || !h.Success || !h.LegacyAllStateMatch || h.RawBoards != 141 || h.PositiveNK != 70 || h.Resets != 1 || h.Publications < 20 || h.Publications != h.ThreePublications || h.Forces != 1 {
			t.Fatalf("鏡像%d: %+v %v", side, h, err)
		}
		indexDifference, prior := false, req.Session.Start
		pubs := map[string]bool{}
		for i, r := range records {
			if r.Ordinal != i+1 || r.At < prior {
				t.Fatal("配送順差")
			}
			prior = r.At
			if r.Kind == "publication" {
				id := fmt.Sprint(r.Publication.ID)
				if pubs[id] || r.Delivery == nil || !r.Delivery.Result.New || r.Publication.At > r.Trigger.Time || r.Publication.Snapshot.Three.LastSource.Time >= r.Publication.At {
					t.Fatal("新公表/形成出典差")
				}
				pubs[id] = true
			}
			if r.Kind == "quote" {
				if r.Scalar.SourceLine != r.RawQuote.Line || r.Scalar.Last != r.RawQuote.Last || r.Scalar.Index != *r.Trigger.FeaturesIndex {
					t.Fatal("金融Scalar出典差")
				}
				indexDifference = indexDifference || r.Scalar.Index != r.RawQuote.Index
			}
			if r.Kind == "raw_clock" && r.Trigger.Market == "NK225" && r.RawQuote.Valid {
				t.Fatal("正NKを金融から落とした")
			}
		}
		after, _ := json.Marshal(req)
		if !reflect.DeepEqual(before, after) || !indexDifference || h.SourceReexecuted || h.FinancialExecuted || h.MarketExecuted {
			t.Fatal("入力変更/Index混同/範囲誤り")
		}
	}
}

// TestSameClockAndBadBBO はpublication→Force→grid→原行を固定します。
//
// 引数: t(*testing.T)は人工器です。
// 返り値: なし。同秒境界と不良BBOの正Last配送を確認します。
func TestSameClockAndBadBBO(t *testing.T) {
	req, forces := fixture(1000000, 1)
	req.Session.ForceClose = req.Session.Start + 900
	forces[0].At = req.Session.ForceClose
	for i := range req.Rows {
		if req.Rows[i].Board.Reference == "NK225" && req.Rows[i].Board.Time == forces[0].At {
			req.Rows[i].Board.Bid, req.Rows[i].Board.Ask = 10100, 10000
		}
	}
	_, _, records, err := collect(req, nil, forces)
	if err != nil {
		t.Fatal(err)
	}
	kinds := []string{}
	bad := false
	for _, r := range records {
		if r.At == forces[0].At {
			kinds = append(kinds, r.Kind)
			if r.Kind == "quote" {
				bad = !r.Scalar.QuoteOK
			}
		}
	}
	if len(kinds) < 5 || !reflect.DeepEqual(kinds[:3], []string{"publication", "force", "grid"}) || !bad {
		t.Fatalf("同時計/不良BBO差: %v", kinds)
	}
}

// TestNightForce はP締切と場末の二時計を逆順にせず渡す境界を確認します。
//
// 引数: t(*testing.T)は手製Nightの人工器です。
// 返り値: なし。新しいSource通知やU出生を生成しません。
func TestNightForce(t *testing.T) {
	req, forces := fixture(1000000, 1)
	req.Session.Kind = "Night"
	req.Session.USOpen = req.Session.Start + 1800
	forces = append([]Force{{At: req.Session.USOpen - 900, TapeOrdinal: 19}}, forces...)
	h, _, _, err := collect(req, nil, forces)
	if err != nil || h.Forces != 2 || !h.Success {
		t.Fatalf("Night二時計差 %+v %v", h, err)
	}
	forces[1].TapeOrdinal = 18
	if h, _, _, err = collect(req, nil, forces); err == nil || h.Success {
		t.Fatal("Source元ordinal逆行受理")
	}
}

// TestEOFAndTOPIXClock はTOPIXだけの上限とEOF未来公表禁止を確認します。
//
// 引数: t(*testing.T)は人工器です。
// 返り値: なし。Source通知も新しい価格も作りません。
func TestEOFAndTOPIXClock(t *testing.T) {
	req, forces := fixture(1000000, 1)
	kept := []continuous.Row{}
	for _, r := range req.Rows {
		if r.Board.Time <= req.Session.Start+360 && !(r.Board.Reference == "NK225" && r.Board.Time == req.Session.Start+360) {
			kept = append(kept, r)
		}
	}
	req.Rows = kept
	h, _, records, err := collect(req, nil, forces)
	if err != nil || h.AfterEOFForces != 1 || h.Publications != 2 || h.Grids != 2 || h.Ending.Legacy.At != req.Session.Start+360 || len(h.SkippedGrids) == 0 {
		t.Fatalf("EOF/全board差 %+v %v", h, err)
	}
	for _, r := range records {
		if r.Kind != "force" && r.At > req.Session.Start+360 {
			t.Fatal("EOF未来値生成")
		}
	}
	last := records[len(records)-1]
	if last.Kind != "force" || !last.AfterEOF || last.RawQuote != nil || last.Scalar != nil || last.Publication != nil {
		t.Fatal("EOF Forceへ価格/公表混入")
	}
}

// TestPairedSeed は旧Seed単体を受けず同限月/rollを両bankへ同じ操作で渡します。
//
// 引数: t(*testing.T)は人工器です。
// 返り値: なし。JSONからSeedを復元できるとは主張しません。
func TestPairedSeed(t *testing.T) {
	req, f := fixture(1000000, 1)
	_, seed, _, err := collect(req, nil, f)
	if err != nil {
		t.Fatal(err)
	}
	next, nf := fixture(req.Session.End+1000, 1)
	next.Session.ID, next.Scene.ID = "次手製Day", "次手製Day"
	h, _, _, err := collect(next, seed, nf)
	if err != nil || !h.Ending.Legacy.CarriedNumericSeed {
		t.Fatalf("同限月Seed差 %v", err)
	}
	next.Scene.Contract = "別限月"
	h, _, _, err = collect(next, seed, nf)
	if err != nil || h.Ending.Legacy.CarriedNumericSeed {
		t.Fatalf("roll差 %v", err)
	}
	if h, _, _, err = collect(next, &Seed{legacy: seed.legacy}, nf); err == nil || h.Success {
		t.Fatal("片側だけのSeed受理")
	}
}

// TestRejectBoundaries は時計・出典・欠落・sink失敗を成功へ変換しないことを確認します。
//
// 引数: t(*testing.T)は人工器です。
// 返り値: なし。各拒否は追加の金融閾値ではありません。
func TestRejectBoundaries(t *testing.T) {
	for _, name := range []string{"Force不足", "Force別時計", "Force元ordinal欠落", "物理行重複", "Received差", "市場外", "未来grid"} {
		t.Run(name, func(t *testing.T) {
			req, f := fixture(1000000, 1)
			switch name {
			case "Force不足":
				f = nil
			case "Force別時計":
				f[0].At++
			case "Force元ordinal欠落":
				f[0].TapeOrdinal = 0
			case "物理行重複":
				req.Rows = append(req.Rows, req.Rows[0])
			case "Received差":
				req.Rows[0].Board.Received++
			case "市場外":
				req.Rows[0].Board.Reference = "不明市場"
			case "未来grid":
				req.Grids = append(req.Grids, req.Session.End)
			}
			h, _, _, err := collect(req, nil, f)
			if err == nil || h.Success {
				t.Fatal("破損受理")
			}
		})
	}
	req, f := fixture(1000000, 1)
	if h, _, err := Build(req, nil, f, nil); err == nil || h.Success {
		t.Fatal("nil sink受理")
	}
	if h, _, err := Build(req, nil, f, func(Record) error { return fmt.Errorf("手製出力失敗") }); err == nil || h.Success {
		t.Fatal("出力失敗を成功化")
	}
}

// TestTypeExport は明示した新規dirだけへ買売の公開型人工を保存します。
//
// 引数: t(*testing.T)、環境PUBLIC_SIDECAR_EXPORT(string)は人工の保存先です。
// 返り値: なし。市場入力を開かずSource/金融を実行しません。
func TestTypeExport(t *testing.T) {
	dir := os.Getenv("PUBLIC_SIDECAR_EXPORT")
	if dir == "" {
		t.Skip("型保存は明示時だけ")
	}
	if err := os.Mkdir(dir, 0755); err != nil {
		t.Fatal(err)
	}
	for _, side := range []int{1, -1} {
		r, f := fixture(1000000, side)
		h, _, records, err := collect(r, nil, f)
		if err != nil {
			t.Fatal(err)
		}
		body, err := json.Marshal(struct {
			Scope   string   `json:"scope"`
			Header  Header   `json:"header"`
			Records []Record `json:"records"`
		}{"二市場・Last0・BBO・時計の手製器具。自然Source/金融/市場値ではない", h, records})
		if err != nil {
			t.Fatal(err)
		}
		if err = os.WriteFile(filepath.Join(dir, fmt.Sprintf("方向%d.json", side)), body, 0644); err != nil {
			t.Fatal(err)
		}
	}
}
