"""公開配送adapterの手製検査と停止指紋だけを新規保存する。"""
from __future__ import annotations

import hashlib
import difflib
import json
import os
from pathlib import Path
import subprocess

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]


def sha(path: Path) -> str:
    """
    機能: 明示コード・人工の内容指紋を計算する。
    引数: path (Path) は小型対象ファイル。
    返り値: str はSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(args: list[str], name: str, env: dict | None = None) -> dict:
    """
    機能: 非市場のGo検査を実行し全出力と終了値を保存する。
    引数: args (list[str])、name (str)、env (dict|None) は命令・新規ログ名・環境。
    返り値: dict は命令と終了値。非0で停止する。
    """
    result = subprocess.run(args, cwd=WORK, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False)
    log = WORK / '検査' / name
    log.write_bytes(result.stdout)
    assert result.returncode == 0, (args, result.stdout.decode('utf-8', errors='replace'))
    return {'命令': args, '終了': result.returncode, 'ログ': str(log.relative_to(ROOT)), 'SHA256': sha(log)}


def main() -> None:
    """
    機能: 人工・依存不変を検査し当部品の停止JSONを新規保存する。
    引数: なし。実市場用の入力や実行モードを持たない。
    返り値: None。元停止と正式試行を変更しない。
    """
    assert not (WORK / '停止.json').exists()
    (WORK / '検査').mkdir(exist_ok=False)
    before = json.loads((WORK / '元と依存の前指紋.json').read_text(encoding='utf-8'))
    assert all(sha(Path(p) if Path(p).is_absolute() else ROOT / p) == s for p, s in before.items())
    runs = [run(['go', 'test', '-json', './...'], '通常Go_test.jsonl'),
            run(['go', 'vet', './...'], 'vet.txt'), run(['go', 'build', './...'], 'build.txt')]
    env = os.environ.copy()
    env['PUBLIC_SIDECAR_EXPORT'] = str(WORK / '人工_停止版')
    runs.append(run(['go', 'test', '-run', '^TestTypeExport$', '-v', './...'], '型export.txt', env))
    original = ROOT / 'work/可変追尾の実場公開配送の準備'
    assert sha(original / '停止.json') == '8a96b31ef1bb23f8f13cf31d05da6ec0a207b23c8c56099f64d40f4479b50341'
    old_source = (original / 'sidecar.go').read_text(encoding='utf-8')
    new_source = (WORK / 'sidecar.go').read_text(encoding='utf-8')
    assert old_source.split('// Build は')[0] == new_source.split('// Build は')[0]
    old_body = old_source[old_source.index('\th := Header'):]
    new_body = new_source[new_source.index('\th := Header'):]
    start, end = new_body.index('\tif warmOnly {'), new_body.index('\tvar oldSeed')
    old_check = old_body[old_body.index('\tif err := checkForces'):old_body.index('\tvar oldSeed')]
    assert new_body[:start] + old_check + new_body[end:] == old_body
    (WORK / '派生差分.patch').write_text(''.join(difflib.unified_diff(old_source.splitlines(True), new_source.splitlines(True), fromfile='元8a96/sidecar.go', tofile='助走対応/sidecar.go')), encoding='utf-8')
    artifacts = {}
    counts = []
    for path in sorted((WORK / '人工_停止版').glob('*.json')):
        artifacts[str(path.relative_to(ROOT))] = sha(path)
        value = json.loads(path.read_text(encoding='utf-8'))
        h, rows = value['header'], value['records']
        assert h['success'] is True and h['legacy_all_state_match'] is True
        assert h['source_reexecuted'] is False and h['financial_executed'] is False and h['market_executed'] is False
        assert h['records'] == len(rows) and h['positive_nk'] == sum(r['kind'] == 'quote' for r in rows)
        assert all(r['ordinal'] == i + 1 for i, r in enumerate(rows))
        assert path.read_bytes() == (original / '人工_停止版' / path.name).read_bytes()
        counts.append({'人工': path.name, **{k: h[k] for k in ['records', 'raw_boards', 'positive_nk', 'all_board_grids', 'publications', 'three_publications', 'resets', 'force_clocks']}})
    assert len(artifacts) == 2
    assert all(sha(Path(p) if Path(p).is_absolute() else ROOT / p) == s for p, s in before.items())
    own = ['sidecar.go', 'sidecar_test.go', 'warm_test.go', 'go.mod', 'go.sum', 'README.md', '計画.md', '検査を記録する.py']
    proof = {'成功': True, 'scope': '手製二市場の全board公開配送口。市場・Source・金融再生なし',
             '所有コードSHA256': {str((WORK / p).relative_to(ROOT)): sha(WORK / p) for p in own},
             '元停止SHA256': {p: s for p, s in before.items() if Path(p).name == '停止.json'},
             '元と依存の前指紋SHA256': sha(WORK / '元と依存の前指紋.json'),
             '元と依存の前後不変': True, '元不変数': len(before), '検査': runs,
             '派生元停止SHA256': sha(original / '停止.json'), 'Build内部loopの旧本文復元一致': True,
             'Build型人工2本bytes同体': True, 'Warm': {'SourceTape必要': False, 'SourceForce参照': 0, '金融成果物': 0,
                 '同助走BuildとpairedSeed同体': True, '次場全Record/公表/状態同体': True,
                 '連続Warm同限月carry': True, 'rollはcold同体': True, 'Last0終端EOF先締めなし': True,
                 'CSV/gridなし助走': True},
             '派生差分SHA256': sha(WORK / '派生差分.patch'),
             '型人工SHA256': artifacts, '型人工計数': counts,
             '検査範囲': ['旧全publication/grid/raw/EndingのSnapshot全field一致', 'Source形成なしのForce時計参照',
                       '同秒pub/Force/grid/raw', 'TOPIX/Last0全board上限', 'Indexと物理行区別',
                       '不良BBO正LastをScalarから落とさない', 'EOF先締め禁止', '同限月/rollの組Seed',
                       '入力不変', '出力失敗/不正型拒否'],
             '未実施': ['実Raw/CSV/Tape/Native/市場sidecar読取又は生成', '自然Source全通知とのbind',
                     '金融Actor接続/全MTM/幅・早期政策/成績', '既存54又は105四場での性能/同値',
                     '永続Seed/実場助走不足の補完'],
             'Source再形成': 0, '金融実行': 0, 'Raw/CSV/市場Native読取': 0,
             '市場CLI': False, '旧正式編集': 0, '機会損失評価': False}
    with (WORK / '停止.json').open('x', encoding='utf-8') as stream:
        json.dump(proof, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'成功': True, '停止SHA256': sha(WORK / '停止.json'), '型人工': counts}, ensure_ascii=False))


if __name__ == '__main__':
    main()
