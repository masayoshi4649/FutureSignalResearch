# 全board時計から新3分公表をquoteへ渡す口・純助走対応

非市場部品。module/package は `publicsidecar`。Source・金融・ファイルreaderを呼ばない。既存105・publicchart f534・公開配送8c426b・continuous/warmの停止本文は変更しない。

```go
header, nextSeed, err := publicsidecar.Build(request, previousSeed, forceClockRefs, sink)
nextWarmSeed, err := publicsidecar.Warm(warmRequest, previousSeed)
```

`request` は既存 `continuous.Request`。将来の入力口では105と同じClockCarrier/LoadRequestを使い、全board・CSV・予定gridをRoot固定後に供給する。今回はこのloaderや市場CLIを用意せず、実Raw/CSV/Source/Tape/Native/価格sidecarを読まない。既使用の元54場/105四場を未見とは呼ばない。

## 実装と出力

`continuous.BuildToSink` を直接importし、非公開のprepare/Features/parserを複写しない。旧公表/gridは次のrawが届くまで保管する。同じ原行の `Last/Bid/Ask/Time/AllIndex/Line` を追加 `publicchart.Bank` へ渡し、各publication/grid/raw/Endingで旧Snapshot全欄の辞書射影SHAと状態欄を一致確認する。旧FeaturesのScalar11は値copyだけで、ATR/EMA/OHLCへ相互補完しない。

Sinkへ単一ordinalで渡す種類は `publication`、`force`、`grid`、`quote`、`raw_clock`、`reset`。quoteは旧正NK Scalar11を完全保持する。`raw_quote.index` はChartの全NK原行Index、`scalar.index` は旧Features正NK Index。Last0が入ると両者は異なり、補正/置換しない。各Triggerに市場・物理行・merge順を残す。同秒別原行も別Record。

publicationは元公開値全文と、新3分公表についてのみC/M/P両方向の `Delivery` を保存する。Scalarや5分反復からpubを増やさず、ActorにもSendしない。Rootの新W/E会計用Receiverは別部品で明示型変換する。

同時計順は **新公表→Source Force時計→grid→原行**。公表の評価Atは旧論理公表At、AvailableAtも元値を保持する。ObservedClockはdrainを許した入力価格時計であり、実受信時計ではない。形成へ当原行を入れる前の閉足だけを公表する。

`force_clock` は既存SourceTapeから呼出側が固定する時計と元ordinalの参照だけ。NativeBatchやSource終了通知を作らない。今回の予定集合検査は、そのTapeの正当性/全通知同値を証明するものではない。実場ではSourceTapeのquote/grid/Force全対応を別途固定・照合する必要がある。

TOPIXもNK Last0も旧全board時計を進める。Last0は追加Bankへ実値で渡してからC/M/Pのresetを保存し、金融quoteへ追加しない。Last正/BBO不良は旧Scalar.QuoteOKのままquoteへ残す。EOFで閉足/gridを先締めせずSealする。EOF後の残Force時計は `after_eof_force_clock=true` で明記し、bankの時計・公表・Quote/MTMを更新しない。

## SourceTapeを使わない純Warm

元8a96停止を別dirへ保持し、Buildの本文を内部 `build` 一つへ移した。Buildは従来どおりForce時計/元ordinalの厳密検査を通し、全Record/Headerの型・意味を維持する。旧買売型人工とのbytes同体を確認する。

追加 `Warm(Request,*Seed) (*Seed,error)` は同じ内部loopで二つのBankへ同時系列を渡し、Force参照0、sink破棄でprivate pairedSeedだけを返す。SourceTape・Source元ordinal・Source通知を作らず、金融成果物も作らない。CSV Candle/5分gridsは助走種の形成に必要なく、両欄を空にしたRequestでも同じRaw Last系列から同じ種を作る（Rows/Session/Sceneは必要）。旧producerによる原行型検査と全公表/状態の一致は維持する。

## Seedと実場接続の未了

Seedは同じ入力を通した旧warmと追加publicchartの非公開ペア。当部品でSealした種しか受けず、片側種・旧HeaderEnding/Scalarからの復元を許可しない。冷開始は未知をそのまま保持。同限月は旧数値だけを持ち越し、場頭の形成・公開mask・C/M/P窓は初期化、rollで数値を初期化する。JSON永続Seedはない。

Rootの後段固定事項は、助走/場順/限月/冷開始方針、助走Raw Lastの全board出典、評価場の入力6refsとSourceTape参照、全boardと各Scalar/Force/gridの完全集合、コード/実行物・出力版。Root検討中の旧80全66＋105四＝70評価は既使用を含み、今回未実行である。現在の `Header.market_executed=false` はこの非市場器具の範囲であり、将来の実場wrapperは実行分類を別receiptへ記録する。本部品の成功を実場再現成功へ転記しない。

Requestは旧loader同様に全boardをRAMへ保持する型。追加側は原行を複写せず位置索引を持ち、Recordは逐次sinkへ送る。旧producerの辞書/headerは既存方式で保持する。実場容量・性能・再起動/永続種・市場出典・新金融/収益は未検証。

## 人工

```powershell
Set-Location '<repo>/work/可変追尾の実場公開配送の準備'
go test -v ./...
go vet ./...
go build ./...
$env:PUBLIC_SIDECAR_EXPORT='<新規人工directory>'
go test -run TestTypeExport -v ./...
```

買売の手製二市場、同秒TOPIX先行、Last0→同秒別NK、BBO不良、timer/Force/grid同秒、EOF/TOPIX上限、同限月/roll/片側Seed拒否、入力不変と出力失敗を確認する。公表の形成・既知性は元bankへ委ね、若いBankで未知のC/Mを成立へ補完しない。人工の原価格/Force元ordinalは手製で、自然Source通知や実場位相の成功ではない。

純Warmは同じ助走をBuildで流した種と除外0同体、次場の全180Record/23公表/全状態を買売両系列で同体照合する。CSV/gridなし助走、連続Warmの同限月carry、roll＝cold、Last0で終わるEOF、先締めなし、BuildのForce欠落拒否維持も確認する。暖機公表は種形成のため内部で計算するだけで、後の場のC/M/P履歴へ持ち越さない。

機会損失・退出後価格・仮想利益・新損益・閾値探索は扱わない。
