package publicsidecar

import (
	"reflect"
	"testing"

	continuous "github.com/masayoshi4649/SessionTradeExecuter/continuous101"
)

// TestWarmMatchesBuildNext は同じ助走の純Warmと既存Buildから次場の全値を比較します。
//
// 引数: t(*testing.T)はSource/金融を持たない人工器です。
// 返り値: なし。Seedだけでなく次場の全Record/Headerを除外0で比較します。
func TestWarmMatchesBuildNext(t *testing.T) {
	for _, side := range []int{1, -1} {
		req, f := fixture(1000000, side)
		_, buildSeed, _, err := collect(req, nil, f)
		if err != nil {
			t.Fatal(err)
		}
		warmSeed, err := Warm(req, nil)
		if err != nil || !reflect.DeepEqual(warmSeed, buildSeed) {
			t.Fatalf("助走後の組Seed差: %v", err)
		}
		lastOnly := req
		lastOnly.Grids, lastOnly.Candles = nil, nil
		lastSeed, err := Warm(lastOnly, nil)
		if err != nil || !reflect.DeepEqual(lastSeed, buildSeed) {
			t.Fatalf("CSV/gridなしの原Last助走種差: %v", err)
		}
		next, nf := fixture(req.Session.End+1000, side)
		next.Session.ID, next.Scene.ID = "次の手製場", "次の手製場"
		a, _, ar, err := collect(next, warmSeed, nf)
		if err != nil {
			t.Fatal(err)
		}
		b, afterBuild, br, err := collect(next, buildSeed, nf)
		if err != nil || !reflect.DeepEqual(a, b) || !reflect.DeepEqual(ar, br) || !a.Ending.Legacy.CarriedNumericSeed {
			t.Fatalf("次場の全公表/全状態差: %v", err)
		}
		afterWarm, err := Warm(next, warmSeed)
		if err != nil || !reflect.DeepEqual(afterWarm, afterBuild) {
			t.Fatalf("連続Warmの同限月種差: %v", err)
		}
		cold, _, cr, err := collect(next, nil, nf)
		if err != nil || cold.Ending.Legacy.CarriedNumericSeed || reflect.DeepEqual(ar, cr) {
			t.Fatalf("coldとの差を失った: %v", err)
		}
		t.Logf("鏡像%d: 次場%dRecord/全%d公表/全状態が同体、coldと別", side, len(ar), a.Publications)
	}
}

// TestWarmRollAndEOF は同限月反復助走・roll・Last0終端・EOF先締め禁止を比較します。
//
// 引数: t(*testing.T)は手製公開入力の人工器です。
// 返り値: なし。Source時計がなくても数値種だけを同体で作ります。
func TestWarmRollAndEOF(t *testing.T) {
	for _, cut := range []bool{false, true} {
		req, f := fixture(1000000, 1)
		if cut {
			rows := []continuous.Row{}
			for _, r := range req.Rows {
				if r.Board.Time < req.Session.Start+600 || r.Board.Time == req.Session.Start+600 && (r.Board.Reference == "TOPIX" || r.Board.Last == 0) {
					rows = append(rows, r)
				}
			}
			req.Rows = rows
		}
		full, a, _, err := collect(req, nil, f)
		if err != nil {
			t.Fatal(err)
		}
		b, err := Warm(req, nil)
		if err != nil || !reflect.DeepEqual(a, b) {
			t.Fatalf("EOF/Last0 Seed差 %v", err)
		}
		forceCount := 0
		pure, _, err := build(req, nil, nil, func(r Record) error {
			if r.Kind == "force" {
				forceCount++
			}
			return nil
		}, true)
		if err != nil || forceCount != 0 || pure.Forces != 0 || pure.ForceClockOnly || !reflect.DeepEqual(pure.Ending, full.Ending) || !reflect.DeepEqual(pure.SkippedGrids, full.SkippedGrids) {
			t.Fatalf("純助走へForce混入/EOF差: %v", err)
		}
		if cut && (pure.Ending.Legacy.At != req.Session.Start+600 || pure.Ending.Legacy.LastInput.Valid || len(pure.SkippedGrids) == 0) {
			t.Fatal("Last0終端を先締め/0補完")
		}
		next, nf := fixture(req.Session.End+1000, 1)
		next.Session.ID, next.Scene.ID = "rollの手製場", "rollの手製場"
		next.Scene.Contract = "別限月"
		roll, _, rr, err := collect(next, b, nf)
		if err != nil {
			t.Fatal(err)
		}
		cold, _, cr, err := collect(next, nil, nf)
		if err != nil || roll.Ending.Legacy.CarriedNumericSeed || !reflect.DeepEqual(roll, cold) || !reflect.DeepEqual(rr, cr) {
			t.Fatalf("rollはcoldと同体でない: %v", err)
		}
		rollSeed, err := Warm(next, b)
		if err != nil {
			t.Fatal(err)
		}
		coldSeed, err := Warm(next, nil)
		if err != nil || !reflect.DeepEqual(rollSeed, coldSeed) {
			t.Fatalf("純Warmのroll種差: %v", err)
		}
	}
}

// TestWarmRejectAndBuildStrict は純助走追加が既存BuildのForce要件を緩めないことを確認します。
//
// 引数: t(*testing.T)は非市場人工器です。
// 返り値: なし。不正入力/片側Seedで次種を返しません。
func TestWarmRejectAndBuildStrict(t *testing.T) {
	req, _ := fixture(1000000, 1)
	if h, next, _, err := collect(req, nil, nil); err == nil || h.Success || next != nil {
		t.Fatal("BuildのForce欠落を受理")
	}
	if next, err := Warm(req, &Seed{}); err == nil || next != nil {
		t.Fatal("純助走で不完全Seed受理")
	}
	req.Rows[0].Board.Received++
	if next, err := Warm(req, nil); err == nil || next != nil {
		t.Fatal("不正原行から種を返した")
	}
}
