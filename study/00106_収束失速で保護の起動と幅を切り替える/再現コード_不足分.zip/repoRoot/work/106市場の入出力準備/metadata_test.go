package main

import (
	"bytes"
	"compress/gzip"
	"encoding/json"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"

	continuous "github.com/masayoshi4649/SessionTradeExecuter/continuous101"
	stream "github.com/masayoshi4649/SessionTradeExecuter/publicsidecar"
	binder "github.com/masayoshi4649/SessionTradeExecuter/sourceclock104"
	core "github.com/masayoshi4649/SessionTradeExecuter/variableguardruntime"
)

// layoutFixture は既読の標準metadataだけを使い本文を持たない参照器具を作ります。
//
// 引数: t(*testing.T)は人工器。返り値: Condition/InputManifestは70順とFileRef型だけの器具です。
func layoutFixture(t *testing.T) (Condition, continuous.InputManifest) {
	t.Helper()
	var m continuous.InputManifest
	if e := decode("../106入力と既存Sourceの整理/標準入力台帳_70場_候補.json", &m, false, true); e != nil {
		t.Fatal(e)
	}
	r := func(name string) FileRef { return FileRef{Path: "手製参照/" + name, SHA: strings.Repeat("a", 64)} }
	c := Condition{Version: 1, Trial: 106, Fixed: true, Manifest: r("manifest"), Corpus: r("corpus"), MetadataStop: r("metadata"), SidecarStop: r("sidecar"), CoreStop: r("core"), Source12Full: r("sourcefull"), Binary: r("binary"), Configs: core.Configurations(), SeedPolicy: "first_cold_then_contract_carry"}
	c.Manifest.SHA = ManifestSHA
	c.MetadataStop.SHA = MetadataStopSHA
	c.SidecarStop.SHA = SidecarStopSHA
	for i, in := range m.Sessions {
		s := SceneRef{Session: in.ID}
		switch {
		case i < 54:
			s.Kind = "old104_54"
			clock, w0 := r(in.ID+".clock"), r(in.ID+".w0")
			s.Clock, s.W0 = &clock, &w0
			s.Records = map[string]FileRef{"symmetric": r(in.ID + ".sym")}
		case i < 66:
			s.Kind = "fresh106_12"
			s.Records = map[string]FileRef{}
			for _, mode := range []string{"legacy", "default", "symmetric"} {
				s.Records[mode] = r(in.ID + mode)
			}
		default:
			s.Kind = "saved105_4"
			legacy, sym, w0 := r(in.ID+".legacy"), r(in.ID+".sym"), r(in.ID+".w0")
			s.Legacy, s.Sym, s.W0 = &legacy, &sym, &w0
		}
		c.Scenes = append(c.Scenes, s)
	}
	return c, m
}

// TestLayoutGuards は70順/三分類/20設定/未知参照を本文前に拒否します。
//
// 引数: t(*testing.T)は人工器。返り値: なし。実FileRefの本文を開きません。
func TestLayoutGuards(t *testing.T) {
	c, m := layoutFixture(t)
	if e := validateLayout(c, m); e != nil {
		t.Fatal(e)
	}
	for _, name := range []string{"未固定", "69場", "順序", "重複", "19設定", "設定重複", "Seed変更", "旧54別分類", "旧W0不足", "新12旧golden", "新12未完成", "105片Tape", "余分Source", "6入力不足"} {
		t.Run(name, func(t *testing.T) {
			c, m := layoutFixture(t)
			switch name {
			case "未固定":
				c.Fixed = false
			case "69場":
				c.Scenes = c.Scenes[:69]
			case "順序":
				c.Scenes[0], c.Scenes[1] = c.Scenes[1], c.Scenes[0]
			case "重複":
				c.Scenes[1] = c.Scenes[0]
			case "19設定":
				c.Configs = c.Configs[:19]
			case "設定重複":
				c.Configs[1] = c.Configs[0]
			case "Seed変更":
				c.SeedPolicy = "各場cold"
			case "旧54別分類":
				c.Scenes[0].Kind = "fresh106_12"
			case "旧W0不足":
				c.Scenes[0].W0 = nil
			case "新12旧golden":
				r := c.Manifest
				c.Scenes[54].W0 = &r
			case "新12未完成":
				delete(c.Scenes[54].Records, "symmetric")
			case "105片Tape":
				c.Scenes[66].Legacy = nil
			case "余分Source":
				c.Scenes[0].Records["default"] = c.Manifest
			case "6入力不足":
				delete(m.Sessions[0].Files, "TOPIX_book")
			}
			if validateLayout(c, m) == nil {
				t.Fatal("不正layout受理")
			}
		})
	}
}

// sourceFixture はSource12完了schemaだけの手製相互QAを作ります。
//
// 引数: c(Condition)は70参照の器具。返り値: Source12Completionは本文を持たないmetadataです。
func sourceFixture(c Condition) Source12Completion {
	b := false
	s := Source12Completion{Version: 1, Trial: 106, Stage: "full12", Success: true, Sessions: 12, Unchanged: true, Formed: true, Financial: &b, Before: map[string]string{"手製固定入力": strings.Repeat("b", 64)}, After: map[string]string{"手製固定入力": strings.Repeat("b", 64)}}
	for _, scene := range c.Scenes[54:66] {
		rows := map[string]SourceCase{}
		for _, mode := range []string{"legacy", "default", "symmetric"} {
			r := SourceCase{Session: scene.Session, Mode: mode, Records: scene.Records[mode], Result: FileRef{Path: "手製結果/" + scene.Session + mode, SHA: strings.Repeat("c", 64)}}
			s.Cases = append(s.Cases, r)
			rows[mode] = r
		}
		s.Mutual = append(s.Mutual, SourceMutual{Session: scene.Session, Success: true, Legacy: rows["legacy"].Records, Default: rows["default"].Records, LegacyResult: rows["legacy"].Result, DefaultResult: rows["default"].Result, ResultEqual: true, GzipEqual: true, JSONEqual: true})
	}
	return s
}

// TestSourceCompletionGuards は完成後だけ生成するCorpusのSource完了結合を確認します。
//
// 引数: t(*testing.T)は人工器。返り値: なし。未完成Sourceを成功へ変換しません。
func TestSourceCompletionGuards(t *testing.T) {
	c, _ := layoutFixture(t)
	if e := validateSource12(sourceFixture(c), c); e != nil {
		t.Fatal(e)
	}
	for _, name := range []string{"未完了", "first2", "不足case", "重複case", "別ID", "別mode", "oldgolden", "参照SHA", "相互不足", "相互重複", "相互不一致", "finance欠落", "finance実行", "前後差"} {
		t.Run(name, func(t *testing.T) {
			c, _ := layoutFixture(t)
			s := sourceFixture(c)
			switch name {
			case "未完了":
				s.Success = false
			case "first2":
				s.Stage = "first2"
			case "不足case":
				s.Cases = s.Cases[:35]
			case "重複case":
				s.Cases[1] = s.Cases[0]
			case "別ID":
				s.Cases[0].Session = "別場"
			case "別mode":
				s.Cases[0].Mode = "別mode"
			case "oldgolden":
				s.Cases[0].Match = true
			case "参照SHA":
				s.Cases[0].Records.SHA = strings.Repeat("d", 64)
			case "相互不足":
				s.Mutual = s.Mutual[:11]
			case "相互重複":
				s.Mutual[1] = s.Mutual[0]
			case "相互不一致":
				s.Mutual[0].JSONEqual = false
			case "finance欠落":
				s.Financial = nil
			case "finance実行":
				b := true
				s.Financial = &b
			case "前後差":
				s.After = map[string]string{"別入力": "別SHA"}
			}
			if validateSource12(s, c) == nil {
				t.Fatal("不正Source完了受理")
			}
		})
	}
}

// TestFirst2Guards は条件/出力/件数/前後を同一のfirst2に結びます。
//
// 引数: t(*testing.T)はmetadata人工器。返り値: なし。市場成功の架空receiptを正式保存しません。
func TestFirst2Guards(t *testing.T) {
	c, _ := layoutFixture(t)
	makeProof := func() Completion {
		h := strings.Repeat("a", 64)
		v := Completion{Version: 1, Trial: 106, Stage: "first2", Success: true, ConditionSHA: h, Sessions: 2, BooksPerScene: 20, Books: 40, Unchanged: true, SeedPolicy: c.SeedPolicy, FinancialExecuted: true, FeaturesRecomputed: true, ChartsRecomputed: true, Before: map[string]string{"手製入力": h}, After: map[string]string{"手製入力": h}}
		for _, s := range c.Scenes[:2] {
			r := FileRef{"手製出力/" + s.Session, h}
			v.Results = append(v.Results, SceneOutput{Session: s.Session, Native: r, Header: r, Records: r, Books: 20, W0Books: 4, ControlKind: "provided_old_book"})
		}
		return v
	}
	if e := validateFirst2(makeProof(), c, strings.Repeat("a", 64)); e != nil {
		t.Fatal(e)
	}
	for _, name := range []string{"別条件", "未成功", "39冊", "順序", "出力SHA欠落", "W0不足", "前後差", "Source再形成"} {
		t.Run(name, func(t *testing.T) {
			v := makeProof()
			switch name {
			case "別条件":
				v.ConditionSHA = strings.Repeat("b", 64)
			case "未成功":
				v.Success = false
			case "39冊":
				v.Books = 39
			case "順序":
				v.Results[0], v.Results[1] = v.Results[1], v.Results[0]
			case "出力SHA欠落":
				v.Results[0].Records.SHA = ""
			case "W0不足":
				v.Results[0].W0Books = 3
			case "前後差":
				v.After = map[string]string{}
			case "Source再形成":
				v.SourceReexecuted = true
			}
			if validateFirst2(v, c, strings.Repeat("a", 64)) == nil {
				t.Fatal("不正first2受理")
			}
		})
	}
}

// TestCoreTypeRoundTrip は停止Coreの非0型人工だけをgzip/Native/Recordsへ往復します。
//
// 引数: t(*testing.T)は人工器。返り値: なし。Go金融と純式を再実行しません。
func TestCoreTypeRoundTrip(t *testing.T) {
	paths, e := filepath.Glob("../106可変保護の市場接続準備/人工_停止版/*.json")
	if e != nil || len(paths) != 4 {
		t.Skip("Core停止型4件を待つ")
	}
	for _, path := range paths {
		var value struct {
			Header  stream.Header   `json:"header"`
			Records []stream.Record `json:"records"`
			Output  core.Result     `json:"output"`
		}
		if e = decode(path, &value, false, false); e != nil {
			t.Fatal(e)
		}
		if len(value.Output.Books) != 20 || !value.Output.Complete {
			t.Fatal("停止Core型の完結差")
		}
		body := Native{Result: value.Output, ConditionSHA: strings.Repeat("a", 64)}
		out := filepath.Join(t.TempDir(), "Native.json.gz")
		if e = writeNew(out, body, true); e != nil {
			t.Fatal(e)
		}
		var round Native
		if e = decode(out, &round, true, true); e != nil || !reflect.DeepEqual(body, round) {
			t.Fatalf("全Native field往復差:%v", e)
		}
		if writeNew(out, body, true) == nil {
			t.Fatal("既存出力上書き")
		}
		buf := bytes.Buffer{}
		z := gzip.NewWriter(&buf)
		enc := json.NewEncoder(z)
		for _, r := range value.Records {
			if e = enc.Encode(r); e != nil {
				t.Fatal(e)
			}
		}
		if e = z.Close(); e != nil {
			t.Fatal(e)
		}
		zr, e := gzip.NewReader(bytes.NewReader(buf.Bytes()))
		if e != nil {
			t.Fatal(e)
		}
		dec := json.NewDecoder(zr)
		dec.DisallowUnknownFields()
		for _, r := range value.Records {
			var rr stream.Record
			if e = dec.Decode(&rr); e != nil || !reflect.DeepEqual(r, rr) {
				t.Fatalf("Record全値往復差:%v", e)
			}
		}
		if e = zr.Close(); e != nil {
			t.Fatal(e)
		}
	}
}

// TestRejectBeforePayload は未固定条件/不正stageで出力dirを作らないことを確認します。
//
// 引数: t(*testing.T)は非市場人工器。返り値: なし。Raw/Source/Nativeを参照しません。
func TestRejectBeforePayload(t *testing.T) {
	for _, stage := range []string{"", "full54", "first2", "full70"} {
		out := filepath.Join(t.TempDir(), "出力")
		e := runMarket(Arguments{Condition: "存在しない手製条件.json", ConditionSHA: strings.Repeat("a", 64), Stage: stage, Out: out})
		if e == nil {
			t.Fatal("未固定受理")
		}
		if _, e = os.Stat(out); !os.IsNotExist(e) {
			t.Fatal("入力検査前に出力作成")
		}
	}
	if strictBytes([]byte(`{"policy":"W0","未知":1}`), &core.Config{}) == nil {
		t.Fatal("未知field破棄")
	}
}

// TestFreshClockTyped105 は既存の小型手製4型から新legacy組立/全3Bindを再接続します。
//
// 引数: t(*testing.T)は人工器。返り値: なし。実105/追加12の価格やSource本文を開きません。
func TestFreshClockTyped105(t *testing.T) {
	for _, id := range []string{"2026-11-05_Day", "2026-11-05_Night", "2026-11-06_Day", "2026-11-06_Night"} {
		var fixture struct {
			Artificial bool                             `json:"artificial"`
			Scope      string                           `json:"scope"`
			Request    continuous.Request               `json:"request"`
			Records    map[string][]binder.SourceRecord `json:"records"`
		}
		if e := decode("../105四場の時計とLD10確認/人工/"+id+".json", &fixture, false, true); e != nil {
			t.Fatal(e)
		}
		if !fixture.Artificial || fixture.Scope == "" {
			t.Fatal("人工宣言不足")
		}
		frames := []ClockFrame{}
		_, _, e := continuous.BuildToSink(fixture.Request, nil, func(r continuous.Record) error {
			if r.Kind == "row" {
				q := r.Row.Scalar
				frames = append(frames, ClockFrame{len(frames) + 1, "quote", q.Time, &q})
			} else if r.Control != nil && r.Control.Kind == "grid" {
				frames = append(frames, ClockFrame{len(frames) + 1, "grid", r.Control.At, nil})
			}
			return nil
		})
		if e != nil {
			t.Fatal(e)
		}
		legacy, proof, e := BuildLegacyTape(fixture.Request.Session, frames, fixture.Records["legacy"])
		if e != nil || proof.Rows == 0 || proof.Grids == 0 {
			t.Fatalf("新clockの手製接続差:%v", e)
		}
		for _, mode := range []string{"legacy", "default", "symmetric"} {
			if _, _, e = binder.Bind(legacy, fixture.Records[mode], mode); e != nil {
				t.Fatal(e)
			}
		}
	}
}
