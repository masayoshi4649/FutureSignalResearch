package main

import (
	"compress/gzip"
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"reflect"

	continuous "github.com/masayoshi4649/SessionTradeExecuter/continuous101"
	stream "github.com/masayoshi4649/SessionTradeExecuter/publicsidecar"
	core "github.com/masayoshi4649/SessionTradeExecuter/variableguardruntime"
)

type Arguments struct{ Condition, ConditionSHA, Stage, Out, First2, First2SHA string }

type SceneOutput struct {
	Session     string  `json:"session"`
	Native      FileRef `json:"native"`
	Header      FileRef `json:"sidecar_header"`
	Records     FileRef `json:"sidecar_records"`
	Books       int     `json:"books"`
	W0Books     int     `json:"w0_control_books"`
	ControlKind string  `json:"control_kind"`
	Error       string  `json:"error,omitempty"`
}

type Completion struct {
	Version            int               `json:"version"`
	Trial              int               `json:"trial"`
	Stage              string            `json:"stage"`
	Success            bool              `json:"success"`
	ConditionSHA       string            `json:"condition_sha256"`
	Sessions           int               `json:"sessions"`
	BooksPerScene      int               `json:"books_per_scene"`
	Books              int               `json:"books"`
	Results            []SceneOutput     `json:"results"`
	Before             map[string]string `json:"before"`
	After              map[string]string `json:"after"`
	Unchanged          bool              `json:"unchanged"`
	First2             *FileRef          `json:"first2,omitempty"`
	SeedPolicy         string            `json:"seed_policy"`
	SourceReexecuted   bool              `json:"source_reexecuted"`
	FeaturesRecomputed bool              `json:"features_recomputed"`
	ChartsRecomputed   bool              `json:"charts_recomputed"`
	FinancialExecuted  bool              `json:"financial_executed"`
	Error              string            `json:"error,omitempty"`
}

// Provenance はCore内の形成0と外周でのFeatures/チャート形成を区別します。
type Provenance struct {
	Scene              SceneRef                `json:"scene_input"`
	Input              continuous.InputSession `json:"raw_input"`
	Manifest           FileRef                 `json:"manifest"`
	SeedPolicy         string                  `json:"seed_policy"`
	FirstSceneCold     bool                    `json:"first_scene_cold"`
	FeaturesRecomputed bool                    `json:"features_recomputed"`
	ChartsRecomputed   bool                    `json:"charts_recomputed"`
	SourceReexecuted   bool                    `json:"source_reexecuted"`
}

type Native struct {
	core.Result
	ConditionSHA string     `json:"condition_sha256"`
	Pipeline     Provenance `json:"pipeline_provenance"`
}
type PublicHeader struct {
	Version      int           `json:"version"`
	Trial        int           `json:"trial"`
	ConditionSHA string        `json:"condition_sha256"`
	Header       stream.Header `json:"header"`
	RecordsSHA   string        `json:"records_gzip_sha256"`
	Pipeline     Provenance    `json:"pipeline_provenance"`
}

// validateFirst2 は同一条件の二場・40冊成功と全出力参照を型として確認します。
//
// 引数: v(Completion)、c(Condition)、expected(string)は前段成功・同条件・条件SHAです。
// 返り値: errorは未完結/別条件/余剰/順序差です。
func validateFirst2(v Completion, c Condition, expected string) error {
	if v.Version != 1 || v.Trial != 106 || v.Stage != "first2" || !v.Success || v.Sessions != 2 || v.BooksPerScene != 20 || v.Books != 40 || len(v.Results) != 2 || v.ConditionSHA != expected || !v.Unchanged || len(v.Before) == 0 || !reflect.DeepEqual(v.Before, v.After) || v.Error != "" || v.SourceReexecuted || !v.FinancialExecuted || !v.ChartsRecomputed || !v.FeaturesRecomputed || v.SeedPolicy != c.SeedPolicy {
		return fmt.Errorf("first2完了metadata差")
	}
	for i, r := range v.Results {
		if r.Session != c.Scenes[i].Session || r.Books != 20 || r.W0Books != 4 || r.ControlKind != "provided_old_book" || r.Error != "" || !refShape(r.Native) || !refShape(r.Header) || !refShape(r.Records) {
			return fmt.Errorf("first2出力集合差")
		}
	}
	return nil
}

// refsAfter は全入力とコードの処理後SHAを取り、前指紋へ補完しません。
//
// 引数: before(map[string]string)は実際に開いた固定参照です。
// 返り値: map[string]string/errorは実指紋又は読取・内容差です。
func refsAfter(before map[string]string) (map[string]string, error) {
	out := map[string]string{}
	for p, want := range before {
		got, e := fileSHA(p)
		if e != nil {
			return out, e
		}
		out[p] = got
		if got != want {
			return out, fmt.Errorf("入力/コード前後差:%s", p)
		}
	}
	return out, nil
}

// runMarket はRoot固定後だけ一つのprivate Seedを70時系列へ連続配送します。
//
// 引数: args(Arguments)は固定条件・段階・新規出力です。
// 返り値: errorは未固定/接続/金融/保存不成立です。full70はfirst2を含めcoldから再処理します。
func runMarket(args Arguments) error {
	out, e := filepath.Abs(args.Out)
	if e != nil || args.Out == "" {
		return fmt.Errorf("新規出力dir必須")
	}
	if _, e = os.Stat(out); !os.IsNotExist(e) {
		return fmt.Errorf("既存又は不正出力dir")
	}
	p, e := prepare(args.Condition, args.ConditionSHA, args.Stage)
	if e != nil {
		return e
	}
	var first Completion
	var firstRef *FileRef
	if args.Stage == "full70" {
		path, err := checkRef(FileRef{args.First2, args.First2SHA}, ".", p.Before)
		if err != nil {
			return err
		}
		if err = decode(path, &first, false, true); err != nil {
			return err
		}
		if err = validateFirst2(first, p.Condition, args.ConditionSHA); err != nil {
			return err
		}
		for _, r := range first.Results {
			for _, ref := range []FileRef{r.Native, r.Header, r.Records} {
				if _, err = checkRef(ref, filepath.Dir(path), p.Before); err != nil {
					return err
				}
			}
		}
		firstRef = &FileRef{path, args.First2SHA}
	} else if args.First2 != "" || args.First2SHA != "" {
		return fmt.Errorf("first2へ前段成功を混入")
	}
	if e = os.MkdirAll(filepath.Dir(out), 0755); e != nil {
		return e
	}
	if e = os.Mkdir(out, 0755); e != nil {
		return e
	}
	completion := Completion{Version: 1, Trial: 106, Stage: args.Stage, ConditionSHA: args.ConditionSHA, BooksPerScene: 20, Before: p.Before, Results: []SceneOutput{}, First2: firstRef, SeedPolicy: p.Condition.SeedPolicy}
	var seed *stream.Seed
	var runErr error
	for i := 0; i < p.Count; i++ {
		scene := p.Condition.Scenes[i]
		row := SceneOutput{Session: scene.Session}
		loaded, err := loadScene(p, i)
		for path, h := range loaded.Before {
			completion.Before[path] = h
		}
		if err != nil {
			row.Error = err.Error()
			completion.Results = append(completion.Results, row)
			runErr = err
			break
		}
		c, err := core.NewCore(loaded.Tape, p.Manifest.Sessions[i].Contract, "106固定Sourceと因果公表から20会計。Core自身は形成せず外周provenanceと分離", loaded.Control)
		if err != nil {
			row.Error = err.Error()
			completion.Results = append(completion.Results, row)
			runErr = err
			break
		}
		recordPath := filepath.Join(out, scene.Session+".public.records.jsonl.gz")
		f, err := os.OpenFile(recordPath, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
		if err != nil {
			runErr = err
			row.Error = err.Error()
			completion.Results = append(completion.Results, row)
			break
		}
		z := gzip.NewWriter(f)
		encoder := json.NewEncoder(z)
		completion.FeaturesRecomputed, completion.ChartsRecomputed, completion.FinancialExecuted = true, true, true
		header, next, err := stream.Build(loaded.Request, seed, core.SourceForces(loaded.Tape), func(r stream.Record) error {
			if e := c.Feed(r); e != nil {
				return e
			}
			return encoder.Encode(r)
		})
		if closeErr := z.Close(); err == nil {
			err = closeErr
		}
		if closeErr := f.Close(); err == nil {
			err = closeErr
		}
		if err != nil {
			row.Error = err.Error()
			completion.Results = append(completion.Results, row)
			runErr = err
			break
		}
		result, err := c.Finish(header)
		if err == nil && (!result.Complete || len(result.Books) != 20 || !result.W0Control.All || result.W0Control.Books != 4 || len(result.W0Control.Excluded) != 0) {
			err = fmt.Errorf("20冊完結/W0四全文差")
		}
		if err != nil {
			row.Error = err.Error()
			completion.Results = append(completion.Results, row)
			runErr = err
			break
		}
		provenance := Provenance{Scene: scene, Input: p.Manifest.Sessions[i], Manifest: p.Condition.Manifest, SeedPolicy: p.Condition.SeedPolicy, FirstSceneCold: i == 0, FeaturesRecomputed: true, ChartsRecomputed: true}
		recordSHA, err := fileSHA(recordPath)
		if err != nil {
			runErr = err
			row.Error = err.Error()
			completion.Results = append(completion.Results, row)
			break
		}
		headerPath := filepath.Join(out, scene.Session+".public.header.json")
		err = writeNew(headerPath, PublicHeader{1, 106, args.ConditionSHA, header, recordSHA, provenance}, false)
		nativePath := filepath.Join(out, scene.Session+".Native.json.gz")
		if err == nil {
			err = writeNew(nativePath, Native{Result: result, ConditionSHA: args.ConditionSHA, Pipeline: provenance}, true)
		}
		if err != nil {
			runErr = err
			row.Error = err.Error()
			completion.Results = append(completion.Results, row)
			break
		}
		headerSHA, err := fileSHA(headerPath)
		if err == nil {
			var nativeSHA string
			nativeSHA, err = fileSHA(nativePath)
			if err == nil {
				row.Native = FileRef{nativePath, nativeSHA}
				row.Header = FileRef{headerPath, headerSHA}
				row.Records = FileRef{recordPath, recordSHA}
				row.Books = 20
				row.W0Books = 4
				row.ControlKind = result.W0Control.Kind
			}
		}
		if err == nil && args.Stage == "full70" && i < 2 {
			old := first.Results[i]
			if row.Native.SHA != old.Native.SHA || row.Header.SHA != old.Header.SHA || row.Records.SHA != old.Records.SHA {
				err = fmt.Errorf("同条件first2再処理の全出力bytes差")
			}
		}
		if err != nil {
			runErr = err
			row.Error = err.Error()
			completion.Results = append(completion.Results, row)
			break
		}
		completion.Results = append(completion.Results, row)
		completion.Sessions++
		completion.Books += 20
		seed = next
		fmt.Fprintf(os.Stderr, "106 %d/%d %s 20冊/W0四\n", i+1, p.Count, scene.Session)
	}
	completion.After, e = refsAfter(completion.Before)
	completion.Unchanged = e == nil && reflect.DeepEqual(completion.Before, completion.After)
	if runErr == nil {
		runErr = e
	}
	if runErr == nil && (completion.Sessions != p.Count || completion.Books != 20*p.Count) {
		runErr = fmt.Errorf("対象場/会計数未完結")
	}
	completion.Success = runErr == nil
	if runErr != nil {
		completion.Error = runErr.Error()
	}
	if err := writeNew(filepath.Join(out, "完了.json"), completion, false); err != nil {
		return err
	}
	return runErr
}

// main は固定条件を必要とする市場CLIだけを公開します。
//
// 引数: os.Args([]string)はRoot固定とfirst2/full70、新規出力です。
// 返り値: なし。不成立時は非0終了し未完了を成功へ補いません。
func main() {
	var a Arguments
	flag.StringVar(&a.Condition, "condition", "", "Root固定JSON")
	flag.StringVar(&a.ConditionSHA, "condition-sha", "", "Root固定SHA")
	flag.StringVar(&a.Stage, "stage", "", "first2/full70")
	flag.StringVar(&a.Out, "out", "", "新規出力dir")
	flag.StringVar(&a.First2, "first2", "", "同条件先頭2完了")
	flag.StringVar(&a.First2SHA, "first2-sha", "", "同先頭2SHA")
	flag.Parse()
	if flag.NArg() != 0 {
		fmt.Fprintln(os.Stderr, "余分な引数")
		os.Exit(1)
	}
	if e := runMarket(a); e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
}
