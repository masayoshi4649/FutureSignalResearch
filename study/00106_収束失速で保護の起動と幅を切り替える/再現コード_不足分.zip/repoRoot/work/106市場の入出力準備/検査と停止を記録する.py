"""106 I/Oのコード・metadata・型人工だけを検査し停止指紋を作る。"""
from __future__ import annotations

import difflib
import hashlib
import json
from pathlib import Path
import subprocess

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]


def sha(path: Path) -> str:
    """
    機能: 明示したコード/metadataの内容指紋を返す。
    引数: path (Path) は小対象ファイル。
    返り値: str はSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(args: list[str], log: str, expected: int = 0) -> dict:
    """
    機能: 非市場のGo検査又は未固定CLI拒否を保存する。
    引数: args (list[str])、log (str)、expected (int) は命令・保存名・期待終了値。
    返り値: dict は命令と実終了値。違えば停止する。
    """
    result = subprocess.run(args, cwd=WORK, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False)
    p = WORK / '検査' / log
    p.write_bytes(result.stdout)
    assert result.returncode == expected, result.stdout.decode('utf-8', errors='replace')
    return {'命令': args, '終了': result.returncode, 'ログ': str(p.relative_to(ROOT)), 'SHA256': sha(p)}


def main() -> None:
    """
    機能: 人工・旧本文の由来・依存不変を確認し新規停止JSONを保存する。
    引数: なし。Source/Raw/Native市場を読むモードはない。
    返り値: None。実行物は一度だけ生成しRootが後で同bytesを固定する。
    """
    assert not (WORK / '停止.json').exists()
    (WORK / '検査').mkdir(exist_ok=False)
    deps = json.loads((WORK / '直接依存の前指紋.json').read_text(encoding='utf-8'))
    assert all(sha(ROOT / p) == s for p, s in deps.items())
    old = (ROOT / 'work/105四場の時計とLD10確認/clock_tape.go').read_text(encoding='utf-8')
    new = (WORK / 'fresh_clock.go').read_text(encoding='utf-8')
    for start, end in [('func methodsAt(', '// sourceEvents は'), ('func sourceEvents(', '// BuildLegacyTape は')]:
        assert old[old.index(start):old.index(end)].strip() == new[new.index(start):new.index(end)].strip()
    a = old[old.index('func BuildLegacyTape('):old.index('// BuildFromRequest は')].strip()
    b = new[new.index('func BuildLegacyTape('):].strip()
    b = b.replace('clockCarrier(s)', 'followup.ClockCarrier(s.ID)').replace('106追加12場のScalar11', '105新6入力のScalar11')
    assert a == b
    assert (WORK / 'io.go').read_bytes() == (ROOT / 'work/105四場の時計とLD10確認/io104.go').read_bytes()
    patch = ''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True), fromfile='105停止/clock_tape.go', tofile='106外周/fresh_clock.go'))
    (WORK / '105時計からの差分.patch').write_text(patch, encoding='utf-8')
    checks = [run(['go', 'test', '-json', './...'], 'Go_test.jsonl'), run(['go', 'vet', './...'], 'vet.txt')]
    exe = WORK / '検査/可変保護.exe'
    checks.append(run(['go', 'build', '-o', str(exe), '.'], 'build.txt'))
    checks.append(run([str(exe), '--condition', str(WORK / '条件の雛形.json'), '--condition-sha', sha(WORK / '条件の雛形.json'),
                       '--stage', 'first2', '--out', str(WORK / '検査/作成禁止')], '未固定CLI拒否.txt', 1))
    assert not (WORK / '検査/作成禁止').exists()
    events = [json.loads(line) for line in (WORK / '検査/Go_test.jsonl').read_text(encoding='utf-8').splitlines()]
    assert not any(e.get('Action') == 'skip' for e in events)
    assert all(sha(ROOT / p) == s for p, s in deps.items())
    own = ['main.go', 'metadata.go', 'load.go', 'fresh_clock.go', 'io.go', 'metadata_test.go', 'prepare_test.go',
           'go.mod', 'go.sum', 'README.md', '条件の雛形.json', '検査と停止を記録する.py']
    proof = {'成功': True, 'scope': '106 I/Oの非市場コード/小metadata/既存Go型だけ。実first2/full70未実行',
             '所有コードSHA256': {str((WORK / p).relative_to(ROOT)): sha(WORK / p) for p in own},
             '実行物': str(exe.relative_to(ROOT)), '実行物SHA256': sha(exe), '直接依存SHA256': deps,
             '直接依存前後不変': True, '検査': checks,
             '通常トップ成功': sum(e.get('Action') == 'pass' and 'Test' in e and '/' not in e['Test'] for e in events),
             'Go小試験成功': sum(e.get('Action') == 'pass' and 'Test' in e for e in events),
             '型保存往復': {'Core型人工': 4, '非0会計': 80, '金融再計算': 0, 'Native/全Record未知fieldを捨てない': True},
             '新時計の人工接続': {'旧105手製型': 4, '全3Bind': 12, '実価格/実Source証明': False},
             '旧IO本文bytes同体': True, '旧mini全通知/Scalar/Force順本文の復元一致': True,
             '許可変更': ['汎用SessionClockによる予定carrier（4場限定解除）', '106出力Scope', 'wrapperのRoot固定/SourceCorpus/連続Seed/保存I/O'],
             '差分SHA256': sha(WORK / '105時計からの差分.patch'),
             'Core独立peerSHA256': sha(WORK / 'Coreの独立読取確認.json'),
             'CLI': '--condition --condition-sha --stage first2|full70 --out NEW [--first2 --first2-sha]',
             'Seed': '9/21Day coldから同限月carry。full70は先頭2も再処理し三出力SHA一致',
             '未実証': ['実RootSourceCorpus/完了12接続', '実Raw/CSV/Source/Tape/Native読取', '実first2/full70金融1400', '実場容量/性能/再起動', '未知期間安定性/実mini約定'],
             '市場入力本文読取': 0, 'Source再形成': 0, '金融再生': 0, '旧停止/正式編集': 0, '機会損失評価': False}
    with (WORK / '停止.json').open('x', encoding='utf-8') as stream:
        json.dump(proof, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'成功': True, '停止SHA256': sha(WORK / '停止.json'), '実行物SHA256': sha(exe),
                      '通常トップ成功': proof['通常トップ成功'], 'Go小試験成功': proof['Go小試験成功']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
