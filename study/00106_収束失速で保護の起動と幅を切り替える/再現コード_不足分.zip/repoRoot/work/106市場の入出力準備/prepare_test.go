package main

import (
	"os"
	"path/filepath"
	"testing"
)

// TestPrepareMetadataPositive は実際の停止/当コードを手製Corpusへ結び正常順を確認します。
//
// 引数: t(*testing.T)はmetadata人工器。返り値: なし。Raw/Source/Tape/Native payloadは存在せず開きません。
func TestPrepareMetadataPositive(t *testing.T) {
	c, _ := layoutFixture(t)
	repo, e := filepath.Abs("../..")
	if e != nil {
		t.Fatal(e)
	}
	dir := t.TempDir()
	ref := func(path string) FileRef {
		abs, err := filepath.Abs(path)
		if err != nil {
			t.Fatal(err)
		}
		h, err := fileSHA(abs)
		if err != nil {
			t.Fatal(err)
		}
		return FileRef{abs, h}
	}
	c.Manifest = ref("../106入力と既存Sourceの整理/標準入力台帳_70場_候補.json")
	c.MetadataStop = ref("../106入力と既存Sourceの整理/停止.json")
	c.SidecarStop = ref("../可変追尾の実場公開配送_助走対応/停止.json")
	c.CoreStop = ref("../106可変保護の市場接続準備/停止.json")
	exe, e := os.Executable()
	if e != nil {
		t.Fatal(e)
	}
	c.Binary = ref(exe)
	c.Code = map[string]string{}
	for _, r := range []FileRef{c.SidecarStop, c.CoreStop} {
		var stop struct {
			Owned map[string]string `json:"所有コードSHA256"`
		}
		if e = decode(r.Path, &stop, false, false); e != nil {
			t.Fatal(e)
		}
		for name, h := range stop.Owned {
			c.Code[filepath.Join(repo, name)] = h
		}
	}
	for _, name := range []string{"main.go", "metadata.go", "load.go", "fresh_clock.go", "io.go", "go.mod", "go.sum"} {
		r := ref(name)
		c.Code[r.Path] = r.SHA
	}
	sourcePath := filepath.Join(dir, "手製Source完了.json")
	if e = writeNew(sourcePath, sourceFixture(c), false); e != nil {
		t.Fatal(e)
	}
	c.Source12Full = ref(sourcePath)
	corpusPath := filepath.Join(dir, "手製Corpus.json")
	if e = writeNew(corpusPath, SourceCorpus{Version: 1, Trial: 106, Fixed: true, Manifest: c.Manifest, Source12Full: c.Source12Full, Scenes: c.Scenes}, false); e != nil {
		t.Fatal(e)
	}
	c.Corpus = ref(corpusPath)
	conditionPath := filepath.Join(dir, "手製条件.json")
	if e = writeNew(conditionPath, c, false); e != nil {
		t.Fatal(e)
	}
	conditionRef := ref(conditionPath)
	for _, stage := range []string{"first2", "full70"} {
		p, e := prepare(conditionPath, conditionRef.SHA, stage)
		if e != nil || len(p.Condition.Scenes) != 70 || len(p.Before) < 10 {
			t.Fatalf("正常metadata接続差:%v", e)
		}
		expected := 2
		if stage == "full70" {
			expected = 70
		}
		if p.Count != expected || !filepath.IsAbs(p.Condition.Scenes[0].Clock.Path) {
			t.Fatal("stage/Corpus path解決差")
		}
	}
}
