# 106市場のI/O準備

Root固定後だけ実行するGo CLI。非市場の型/metadata検査で停止し、今回Raw/CSV/市場Source/Tape/Nativeを読まない。Source生成や金融式をこのmoduleへ実装せず、停止Core c465、paired producer dd34、既存reader/Binderを直接importする。正式106・旧試行・停止元を変更しない。

## Rootの固定口

Conditionは `version:1,trial:106,fixed:true,input_manifest,source_corpus,metadata_stop,sidecar_stop,core_stop,source12_completion,binary,code_sha256,configs,seed_policy`。FileRefは`{path,sha256}`で条件dir基準、codeはrepo基準。`configs`はCore固定のW0/W1/W2/E1/E2×C0/C5×D0/D1の20順。`seed_policy`は`first_cold_then_contract_carry`。

SourceCorpusは `version:1,trial:106,fixed:true,input_manifest:FileRef,source12_completion:FileRef,scenes:[70]`。FileRefはCorpus dir基準。Root helperはSource全12完了後に実参照から生成し、未完了12のplaceholderを保存しない。

|位置/分類|必須scene欄|用途|
|---|---|---|
|0〜53 `old104_54`|session,old_clock_tape,source_records:{symmetric},w0_native|旧100時計Tapeと104全Source記録を純Bind、既存104のsymmetric_内LD10四が旧W0|
|54〜65 `fresh106_12`|session,source_records:{legacy,default,symmetric}|新全board/Scalarと新legacy全通知で基準Tape、全3Bind、symだけ経済20冊。旧goldenを置かない|
|66〜69 `saved105_4`|session,legacy_tape,symmetric_tape,w0_native|二TapeのScalar11/制御時計一致、symを経済20冊。旧105内LD10四がW0|

標準70manifest SHA902c6b、metadata停止0a9ef9、producer停止dd34をpin。Source12の全36case/12相互QA・生成成功/金融未実行・全record参照がCorpusと一致しなければ本文へ進まない。Source条件の追加照合はRoot Corpus helperの固定を参照する。既存58のFileRefはRootが既存参照metadataから生成する。Root条件SHAをコードへ埋めず、実行引数と完了receiptへ結ぶ。

`code_sha256`には当実ファイルmain/metadata/load/fresh_clock/io/go.mod/go.sum、Core/producer各停止の所有全集合と実Go依存閉包をRootが固定する。Core/producer停止JSON自身もFileRefで固定する。起動中exeの実体SHAも照合し、再buildした別exeを代用しない。

## 時系列と保存

workerは1。9/21 Dayをcold、以後の全70を同じprivate Seedで連続処理する。同限月数値carry、場頭のCMP/形成/公開mask reset、roll cold。場ごとのActorは新規で、玉を持ち越さない。full70でも先頭2をcoldから再処理し、同一条件first2のNative/header/records三出力SHAへ一致させる。JSONからSeedを捏造・再開しない。

各場で新規の `.Native.json.gz`、`.public.header.json`、`.public.records.jsonl.gz` を保存。Source→金融の順序/費用/幅/早期起動はCore・Actorの責務。SinkはCore.Feed成功後にRecordを逐次JSONLへ書く。Source/Gate/金融式やparserを複写しない。型付きNativeはCore.Resultをtopへ全値保存し、condition_sha256とpipeline_provenanceだけを加える。

Core内の `charts_recomputed=false` はCore自身が形成しない意味。外周はRawからFeatures/追加Bankを進めるため `pipeline_provenance.features_recomputed/charts_recomputed=true`。内部producer Headerのmarket_executed=false等はAPI部品の範囲であり、当外周の実入力実行分類はCompletionの段階/成功/入力SHA/financial_executedで記録する。これらを市場性能や安定収益の証明へ読み替えない。

Nativeの `w0_control` は既存58=provided_old_book/old_saved_58、追加12=same_input_old103/same_input_new12。後者は同入力で新たに配送した旧Actor四であり既存市場goldenではない。productionの全時点Snapshot比較はfalse、最終四冊は全Book JSON除外0。保存80非0型の往復を市場金融成功へ転記しない。

新12の `fresh_clock.go` は105純組立を別fileへ機械派生し、候補4限定carrierを既存汎用SessionClockへ置換した。mini全Delta・空Step・Closes-only・全商品順・Force直前Line・Scalar11・Force→grid→rawの本文を維持する。Scopeの105/新4場という旧記述は由来であり、新12出力Scopeは106へ区別した。新legacy基準TapeはRAM内で、全新Tapeの重複保存はしない。参照SourceRecordsとcanonicalTapeSHAから再構成可能。

## Rootの実行（今回は未実行）

```powershell
& '<このdir>/検査/可変保護.exe' --condition '<金融Root固定.json>' --condition-sha '<実SHA>' `
  --stage first2 --out '<存在しない先頭2dir>'
& '<同じexe>' --condition '<同じ金融Root固定.json>' --condition-sha '<同SHA>' `
  --stage full70 --first2 '<先頭2dir>/完了.json' --first2-sha '<その実SHA>' `
  --out '<存在しない全70dir>'
```

Completionはversion/trial/stage/success/condition_sha256/sessions/books_per_scene20/books/results/before/after/unchanged/first2?/seed_policy/source_reexecutedfalse/features_recomputedtrue/charts_recomputedtrue/financial_executed/error?。resultsは一意順に `{session,native,sidecar_header,sidecar_records,books:20,w0_control_books:4,control_kind,error?}`。first2は2場40冊、full70は70場1400冊、失敗はsuccess=false/終了非0。既存dir/fileを上書きせず、失敗成果物を成功へ補完しない。

主7840/副7560の参加集計は別保存器で行う。本CLIで分母や参加gateを変更しない。旧66と105四は既使用。未知期間安定性/実mini約定/新しい損益は未検証。機会損失・退出後値幅・仮想利益を算出しない。Viewer/サーバー操作0。

## 検査範囲

metadataの70順/三分類/Source36/first2継承の狭い破損拒否、実停止と当コードを手製Corpusへ結んだ正常prepare（payload不存在のため非読取）、停止Core4型80非0のNative/Record gzip全field往復、既存105手製4型のfresh clock/Binder接続を行う。旧105停止/金融人工の自然Source形成を証明しない。新しい全70金融・Raw読取・実first2はRootの固定後まで未実施。
