package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"path/filepath"
	"reflect"

	continuous "github.com/masayoshi4649/SessionTradeExecuter/continuous101"
	followup "github.com/masayoshi4649/SessionTradeExecuter/fixedfollowup"
	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	old "github.com/masayoshi4649/SessionTradeExecuter/minidelayed103"
	binder "github.com/masayoshi4649/SessionTradeExecuter/sourceclock104"
	core "github.com/masayoshi4649/SessionTradeExecuter/variableguardruntime"
)

type Loaded struct {
	Request  continuous.Request
	Tape     tape.Tape
	Control  core.Control
	Quality  map[string]continuous.RawQuality
	Bindings map[string]binder.Proof
	Before   map[string]string
}

// strictBytes は旧Bookの未知fieldや末尾値を落とさず拒否します。
//
// 引数: raw([]byte)、out(any)は既存JSONと型です。返り値: errorは型/余剰データ差です。
func strictBytes(raw []byte, out any) error {
	d := json.NewDecoder(bytes.NewReader(raw))
	d.DisallowUnknownFields()
	if e := d.Decode(out); e != nil {
		return e
	}
	var tail any
	if e := d.Decode(&tail); e != io.EOF {
		return fmt.Errorf("JSON末尾差")
	}
	return nil
}

// extractW0 は既存58Nativeから四Bookだけを原field/内Keyのまま取り出します。
//
// 引数: path/kind(string)はRoot固定Nativeと104/105由来です。
// 返り値: map[string]old.ActualResult/errorは旧LD10四又は別型です。金融本文は再計算しません。
func extractW0(path, kind string) (map[string]old.ActualResult, error) {
	var envelope map[string]json.RawMessage
	if e := decode(path, &envelope, true, false); e != nil {
		return nil, e
	}
	var books map[string]json.RawMessage
	if e := json.Unmarshal(envelope["books"], &books); e != nil {
		return nil, e
	}
	out := map[string]old.ActualResult{}
	for _, c := range []float64{0, 5} {
		for _, d := range []int{0, 1} {
			key := fmt.Sprintf("LD10_B5Q_P0_C%.0f_D%d", c, d)
			outer := key
			if kind == "old104_54" {
				outer = "symmetric_" + key
			}
			body, ok := books[outer]
			if !ok {
				return nil, fmt.Errorf("既存W0内四不足:%s", outer)
			}
			var value old.ActualResult
			if e := strictBytes(body, &value); e != nil {
				return nil, e
			}
			if value.Key != key {
				return nil, fmt.Errorf("旧W0内Key差")
			}
			out[key] = value
		}
	}
	return out, nil
}

// sameClockTape はSource通知やScopeを同一視せずScalar11と制御全列を照合します。
//
// 引数: a/b(tape.Tape)は同じ105のlegacy/symmetric二入力です。
// 返り値: errorは価格/時計/集合の差です。Source採否の同体を要求しません。
func sameClockTape(a, b tape.Tape) error {
	if a.Version != 1 || b.Version != 1 || a.Session != b.Session || !reflect.DeepEqual(a.Capabilities, b.Capabilities) || len(a.Events) != len(b.Events) {
		return fmt.Errorf("二Tapeの場/集合差")
	}
	for i, x := range a.Events {
		y := b.Events[i]
		if x.Ordinal != y.Ordinal || x.Kind != y.Kind || x.At != y.At || !reflect.DeepEqual(x.Quote, y.Quote) {
			return fmt.Errorf("二TapeのScalar/時計差")
		}
	}
	return nil
}

// loadScene はRoot固定後だけ実入力を旧readerと純Bindへ渡します。
//
// 引数: p(Prepared)、i(int)は固定条件と時系列位置です。
// 返り値: Loaded/errorは原行/Source/旧W0参照又は指紋・型の差です。Sourceを再形成しません。
func loadScene(p Prepared, i int) (Loaded, error) {
	out := Loaded{Before: map[string]string{}, Bindings: map[string]binder.Proof{}}
	s := p.Condition.Scenes[i]
	input := p.Manifest.Sessions[i]
	session, e := followup.SessionClock(s.Session)
	if e != nil {
		return out, e
	}
	carrier, e := clockCarrier(session)
	if e != nil {
		return out, e
	}
	manifestPath, _ := absolute(p.Base, p.Condition.Manifest.Path)
	dataRoot, e := absolute(filepath.Dir(manifestPath), p.Manifest.Root)
	if e != nil {
		return out, e
	}
	for _, f := range input.Files {
		if _, e = checkRef(FileRef{f.Path, f.SHA256}, dataRoot, out.Before); e != nil {
			return out, e
		}
	}
	refs := []*FileRef{s.Clock, s.Legacy, s.Sym, s.W0}
	for _, r := range refs {
		if r != nil {
			if _, e = checkRef(*r, p.Base, out.Before); e != nil {
				return out, e
			}
		}
	}
	for _, r := range s.Records {
		if _, e = checkRef(r, p.Base, out.Before); e != nil {
			return out, e
		}
	}
	out.Request, out.Quality, e = continuous.LoadRequest(input, dataRoot, carrier)
	if e != nil {
		return out, e
	}
	readTape := func(ref FileRef) (tape.Tape, error) {
		var t tape.Tape
		path, _ := absolute(p.Base, ref.Path)
		err := decode(path, &t, true, true)
		if err == nil && (t.Session != session || t.Version != 1 || !reflect.DeepEqual(t.Capabilities, tape.Capabilities())) {
			err = fmt.Errorf("固定Tape場/版/能力差")
		}
		return t, err
	}
	readSource := func(ref FileRef) ([]binder.SourceRecord, error) {
		path, _ := absolute(p.Base, ref.Path)
		r, _, err := readRecords(path)
		return r, err
	}
	switch s.Kind {
	case "old104_54":
		base, err := readTape(*s.Clock)
		if err != nil {
			return out, err
		}
		r, err := readSource(s.Records["symmetric"])
		if err != nil {
			return out, err
		}
		var proof binder.Proof
		out.Tape, proof, e = binder.Bind(base, r, "symmetric")
		out.Bindings["symmetric"] = proof
	case "saved105_4":
		legacy, err := readTape(*s.Legacy)
		if err != nil {
			return out, err
		}
		out.Tape, e = readTape(*s.Sym)
		if e == nil {
			e = sameClockTape(legacy, out.Tape)
		}
	case "fresh106_12":
		all := map[string][]binder.SourceRecord{}
		for _, mode := range []string{"legacy", "default", "symmetric"} {
			all[mode], e = readSource(s.Records[mode])
			if e != nil {
				return out, e
			}
		}
		left, _ := json.Marshal(all["legacy"])
		right, _ := json.Marshal(all["default"])
		if !bytes.Equal(left, right) {
			return out, fmt.Errorf("新12 legacy/default全記録差")
		}
		frames := []ClockFrame{}
		_, _, e = continuous.BuildToSink(out.Request, nil, func(r continuous.Record) error {
			if r.Kind == "row" && r.Row != nil {
				q := r.Row.Scalar
				frames = append(frames, ClockFrame{len(frames) + 1, "quote", q.Time, &q})
			} else if r.Kind == "control" && r.Control != nil && r.Control.Kind == "grid" {
				frames = append(frames, ClockFrame{len(frames) + 1, "grid", r.Control.At, nil})
			}
			return nil
		})
		if e != nil {
			return out, e
		}
		var legacy tape.Tape
		legacy, _, e = BuildLegacyTape(session, frames, all["legacy"])
		if e != nil {
			return out, e
		}
		for _, mode := range []string{"legacy", "default", "symmetric"} {
			bound, proof, err := binder.Bind(legacy, all[mode], mode)
			if err != nil {
				return out, err
			}
			out.Bindings[mode] = proof
			if mode == "symmetric" {
				out.Tape = bound
			}
		}
	default:
		return out, fmt.Errorf("Source分類不正")
	}
	if e != nil {
		return out, e
	}
	if s.W0 != nil {
		path, _ := absolute(p.Base, s.W0.Path)
		expected, err := extractW0(path, s.Kind)
		if err != nil {
			return out, err
		}
		out.Control = core.Control{Kind: "provided_old_book", HistoryClass: "old_saved_58", ReferencePath: path, ReferenceSHA: s.W0.SHA, Expected: expected, AllPoints: false}
	} else {
		out.Control = core.Control{Kind: "same_input_old103", HistoryClass: "same_input_new12", AllPoints: false}
	}
	return out, nil
}
