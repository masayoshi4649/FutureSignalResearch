package main

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"reflect"
	"runtime"

	continuous "github.com/masayoshi4649/SessionTradeExecuter/continuous101"
	core "github.com/masayoshi4649/SessionTradeExecuter/variableguardruntime"
)

const MetadataStopSHA = "0a9ef9095da945572f98cd050defea60badfd738281cebd3aed9dcb5cc243376"
const ManifestSHA = "902c6b5147763de172c0199f79b13cdc08f9a5636b05e0575f19bffd2da627e8"
const SidecarStopSHA = "dd34a46724e7e604544fd60f66e97c0b914cb7593df828ab037a55378cc7244f"

// SceneRef は三種類のSource時計と旧W0対照を明示的に分離します。
type SceneRef struct {
	Session string             `json:"session"`
	Kind    string             `json:"kind"`
	Clock   *FileRef           `json:"old_clock_tape,omitempty"`
	Legacy  *FileRef           `json:"legacy_tape,omitempty"`
	Sym     *FileRef           `json:"symmetric_tape,omitempty"`
	Records map[string]FileRef `json:"source_records,omitempty"`
	W0      *FileRef           `json:"w0_native,omitempty"`
}

// Condition はRootが市場前に固定する一つの70場条件です。
type Condition struct {
	Version      int               `json:"version"`
	Trial        int               `json:"trial"`
	Fixed        bool              `json:"fixed"`
	Manifest     FileRef           `json:"input_manifest"`
	Corpus       FileRef           `json:"source_corpus"`
	MetadataStop FileRef           `json:"metadata_stop"`
	SidecarStop  FileRef           `json:"sidecar_stop"`
	CoreStop     FileRef           `json:"core_stop"`
	Source12Full FileRef           `json:"source12_completion"`
	Binary       FileRef           `json:"binary"`
	Code         map[string]string `json:"code_sha256"`
	Configs      []core.Config     `json:"configs"`
	Scenes       []SceneRef        `json:"-"`
	SeedPolicy   string            `json:"seed_policy"`
}

// SourceCorpus は未完成参照を含まない70場のSource/時計/W0固定台帳です。
type SourceCorpus struct {
	Version      int        `json:"version"`
	Trial        int        `json:"trial"`
	Fixed        bool       `json:"fixed"`
	Manifest     FileRef    `json:"input_manifest"`
	Source12Full FileRef    `json:"source12_completion"`
	Scenes       []SceneRef `json:"scenes"`
}

type SourceMutual struct {
	Session       string  `json:"session"`
	Success       bool    `json:"success"`
	Legacy        FileRef `json:"legacy_records"`
	Default       FileRef `json:"default_records"`
	LegacyResult  FileRef `json:"legacy_result"`
	DefaultResult FileRef `json:"default_result"`
	ResultEqual   bool    `json:"replay_result_bytes_equal"`
	GzipEqual     bool    `json:"records_gzip_bytes_equal"`
	JSONEqual     bool    `json:"records_jsonl_bytes_equal"`
}

type Source12Completion struct {
	Version   int               `json:"version"`
	Trial     int               `json:"trial"`
	Stage     string            `json:"stage"`
	Success   bool              `json:"success"`
	Sessions  int               `json:"sessions"`
	Cases     []SourceCase      `json:"cases"`
	Mutual    []SourceMutual    `json:"legacy_default_matches"`
	Before    map[string]string `json:"before"`
	After     map[string]string `json:"after"`
	Unchanged bool              `json:"unchanged"`
	Formed    bool              `json:"source_reformed"`
	Financial *bool             `json:"financial106_executed"`
	Error     string            `json:"error,omitempty"`
}

type Prepared struct {
	Condition Condition
	Manifest  continuous.InputManifest
	Base      string
	Root      string
	Before    map[string]string
	Count     int
}

// fileSHA は明示したファイルを逐次読み内容指紋を求めます。
//
// 引数: path(string)は固定参照です。返り値: string/errorはSHA256又はI/O不正です。
func fileSHA(path string) (string, error) {
	f, e := os.Open(path)
	if e != nil {
		return "", e
	}
	defer f.Close()
	h := sha256.New()
	if _, e = io.Copy(h, f); e != nil {
		return "", e
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}

// refShape は本文を開く前にFileRefの明示値を検査します。
//
// 引数: r(FileRef)はRoot参照です。返り値: boolは空でないpathとSHAならtrueです。
func refShape(r FileRef) bool { return r.Path != "" && validSHA(r.SHA) }

// checkRef は同一基準のFileRefを前後指紋へ登録します。
//
// 引数: r(FileRef)、base(string)、before(map[string]string)は参照・根・前指紋です。
// 返り値: string/errorは絶対path又は未固定/内容差です。
func checkRef(r FileRef, base string, before map[string]string) (string, error) {
	if !refShape(r) {
		return "", fmt.Errorf("未固定FileRef")
	}
	p, e := absolute(base, r.Path)
	if e != nil {
		return "", e
	}
	h, e := fileSHA(p)
	if e != nil || h != r.SHA {
		return "", fmt.Errorf("FileRef内容差:%s", p)
	}
	if old, ok := before[p]; ok && old != h {
		return "", fmt.Errorf("同pathの二重SHA")
	}
	before[p] = h
	return p, nil
}

// validateLayout は標準70場順・20設定・Source分類を本文読取前に検査します。
//
// 引数: c(Condition)、m(continuous.InputManifest)はRoot条件と標準台帳です。
// 返り値: errorは集合/分類/対照/未固定の差です。原板やSourceを開きません。
func validateLayout(c Condition, m continuous.InputManifest) error {
	if c.Version != 1 || c.Trial != 106 || !c.Fixed || c.SeedPolicy != "first_cold_then_contract_carry" || len(c.Scenes) != 70 || len(m.Sessions) != 70 || !reflect.DeepEqual(c.Configs, core.Configurations()) {
		return fmt.Errorf("106固定70/20設定/Seed方針不正")
	}
	if c.Manifest.SHA != ManifestSHA || c.MetadataStop.SHA != MetadataStopSHA || c.SidecarStop.SHA != SidecarStopSHA {
		return fmt.Errorf("標準入力/元停止差")
	}
	for _, r := range []FileRef{c.Manifest, c.Corpus, c.MetadataStop, c.SidecarStop, c.CoreStop, c.Source12Full, c.Binary} {
		if !refShape(r) {
			return fmt.Errorf("固定参照不足")
		}
	}
	seen := map[string]bool{}
	for i, s := range c.Scenes {
		id := m.Sessions[i].ID
		if s.Session != id || seen[id] || m.Sessions[i].Contract == "" || len(m.Sessions[i].Files) != 6 || i > 0 && id <= m.Sessions[i-1].ID {
			return fmt.Errorf("70時系列/限月/入力集合差")
		}
		seen[id] = true
		for _, name := range []string{"NK225_book", "NK225_candle_60", "NK225_candle_300", "TOPIX_book", "TOPIX_candle_60", "TOPIX_candle_300"} {
			f, ok := m.Sessions[i].Files[name]
			if !ok || f.Path == "" || !validSHA(f.SHA256) || f.Size <= 0 {
				return fmt.Errorf("6入力参照差")
			}
		}
		switch {
		case i < 54:
			if s.Kind != "old104_54" || s.Clock == nil || s.W0 == nil || s.Legacy != nil || s.Sym != nil || len(s.Records) != 1 {
				return fmt.Errorf("旧54の参照型差")
			}
			if !refShape(*s.Clock) || !refShape(*s.W0) || !refShape(s.Records["symmetric"]) {
				return fmt.Errorf("旧54参照不足")
			}
		case i < 66:
			if s.Kind != "fresh106_12" || s.Clock != nil || s.Legacy != nil || s.Sym != nil || s.W0 != nil || len(s.Records) != 3 {
				return fmt.Errorf("新12へ旧golden混入/参照型差")
			}
			for _, mode := range []string{"legacy", "default", "symmetric"} {
				if !refShape(s.Records[mode]) {
					return fmt.Errorf("新12の3mode不足")
				}
			}
		default:
			if s.Kind != "saved105_4" || s.Clock != nil || s.Legacy == nil || s.Sym == nil || s.W0 == nil || len(s.Records) != 0 || !refShape(*s.Legacy) || !refShape(*s.Sym) || !refShape(*s.W0) {
				return fmt.Errorf("105二Tape/旧対照不足")
			}
		}
	}
	return nil
}

// validateSource12 は生成済み12場の完了metadataとRoot参照の全一意集合を結びます。
//
// 引数: s(Source12Completion)、c(Condition)は上流成功と全70参照です。
// 返り値: errorは未完了/旧golden混入/重複/由来差です。Source本文を開きません。
func validateSource12(s Source12Completion, c Condition) error {
	if s.Version != 1 || s.Trial != 106 || s.Stage != "full12" || !s.Success || s.Sessions != 12 || len(s.Cases) != 36 || len(s.Mutual) != 12 || !s.Unchanged || !reflect.DeepEqual(s.Before, s.After) || len(s.Before) == 0 || !s.Formed || s.Financial == nil || *s.Financial || s.Error != "" {
		return fmt.Errorf("新12Source成功metadata不足")
	}
	expected := map[string]SceneRef{}
	for _, r := range c.Scenes[54:66] {
		expected[r.Session] = r
	}
	cases := map[string]SourceCase{}
	for _, r := range s.Cases {
		scene, ok := expected[r.Session]
		k := r.Session + "/" + r.Mode
		if !ok || r.Error != "" || r.Match || !refShape(r.Result) || !refShape(r.Records) || scene.Records[r.Mode] != r.Records {
			return fmt.Errorf("新12Source case参照差")
		}
		if _, ok = cases[k]; ok {
			return fmt.Errorf("新12Source重複")
		}
		cases[k] = r
	}
	seen := map[string]bool{}
	for _, m := range s.Mutual {
		_, ok := expected[m.Session]
		l, lok := cases[m.Session+"/legacy"]
		d, dok := cases[m.Session+"/default"]
		if !ok || !lok || !dok || seen[m.Session] || !m.Success || !m.ResultEqual || !m.GzipEqual || !m.JSONEqual || m.Legacy != l.Records || m.Default != d.Records || m.LegacyResult != l.Result || m.DefaultResult != d.Result {
			return fmt.Errorf("新12Source相互QA差")
		}
		seen[m.Session] = true
	}
	return nil
}

// prepare はコード/実行物/Root条件と小metadataを全て確認してから実入力読取を許します。
//
// 引数: condition/expected/stage(string)は固定JSON・SHA・段階です。
// 返り値: Prepared/errorは選択済み口又は不正です。Raw/Tape/Native本文はまだ読みません。
func prepare(condition, expected, stage string) (Prepared, error) {
	p := Prepared{Before: map[string]string{}}
	if stage != "first2" && stage != "full70" {
		return p, fmt.Errorf("stageはfirst2/full70のみ")
	}
	path, e := checkRef(FileRef{condition, expected}, ".", p.Before)
	if e != nil {
		return p, e
	}
	p.Base = filepath.Dir(path)
	if e = decode(path, &p.Condition, false, true); e != nil {
		return p, e
	}
	c := p.Condition
	manifest, e := checkRef(c.Manifest, p.Base, p.Before)
	if e != nil {
		return p, e
	}
	if e = decode(manifest, &p.Manifest, false, true); e != nil {
		return p, e
	}
	corpusPath, e := checkRef(c.Corpus, p.Base, p.Before)
	if e != nil {
		return p, e
	}
	var corpus SourceCorpus
	if e = decode(corpusPath, &corpus, false, true); e != nil {
		return p, e
	}
	cm, e := absolute(filepath.Dir(corpusPath), corpus.Manifest.Path)
	if e != nil {
		return p, e
	}
	cs, e := absolute(filepath.Dir(corpusPath), corpus.Source12Full.Path)
	if e != nil {
		return p, e
	}
	expectedSource, e := absolute(p.Base, c.Source12Full.Path)
	if e != nil {
		return p, e
	}
	if corpus.Version != 1 || corpus.Trial != 106 || !corpus.Fixed || corpus.Manifest.SHA != c.Manifest.SHA || !samePath(cm, manifest) || corpus.Source12Full.SHA != c.Source12Full.SHA || !samePath(cs, expectedSource) {
		return p, fmt.Errorf("SourceCorpusの同一入力/Source完了差")
	}
	for i := range corpus.Scenes {
		if e = normalizeScene(&corpus.Scenes[i], filepath.Dir(corpusPath)); e != nil {
			return p, e
		}
	}
	c.Scenes = corpus.Scenes
	p.Condition.Scenes = corpus.Scenes
	if e = validateLayout(c, p.Manifest); e != nil {
		return p, e
	}
	_, file, _, ok := runtime.Caller(0)
	if !ok {
		return p, fmt.Errorf("実wrapperコード根拠なし")
	}
	p.Root = filepath.Clean(filepath.Join(filepath.Dir(file), "../.."))
	for name, sha := range c.Code {
		if _, e = checkRef(FileRef{name, sha}, p.Root, p.Before); e != nil {
			return p, e
		}
	}
	for _, n := range []string{"main.go", "metadata.go", "load.go", "fresh_clock.go", "io.go", "go.mod", "go.sum"} {
		a, _ := filepath.Abs(filepath.Join(filepath.Dir(file), n))
		if p.Before[a] == "" {
			return p, fmt.Errorf("実wrapper所有code不足:%s", n)
		}
	}
	for _, ref := range []FileRef{c.MetadataStop, c.SidecarStop, c.CoreStop} {
		sp, err := checkRef(ref, p.Base, p.Before)
		if err != nil {
			return p, err
		}
		var stop struct {
			Success bool              `json:"成功"`
			Owned   map[string]string `json:"所有コードSHA256"`
		}
		if err = decode(sp, &stop, false, false); err != nil || !stop.Success || ref.SHA != MetadataStopSHA && len(stop.Owned) == 0 {
			return p, fmt.Errorf("停止成功不足")
		}
		for name, sha := range stop.Owned {
			abs, err := absolute(p.Root, name)
			if err != nil || p.Before[abs] != sha {
				return p, fmt.Errorf("停止所有コード不足:%s", name)
			}
		}
	}
	exe, e := os.Executable()
	if e != nil {
		return p, e
	}
	binary, e := checkRef(c.Binary, p.Base, p.Before)
	if e != nil {
		return p, e
	}
	a, _ := filepath.Abs(exe)
	if !samePath(a, binary) {
		return p, fmt.Errorf("固定実行物と起動物が違う")
	}
	source, e := checkRef(c.Source12Full, p.Base, p.Before)
	if e != nil {
		return p, e
	}
	var full Source12Completion
	if e = decode(source, &full, false, false); e != nil {
		return p, e
	}
	for i := range full.Cases {
		for _, r := range []*FileRef{&full.Cases[i].Records, &full.Cases[i].Result} {
			if !refShape(*r) {
				return p, fmt.Errorf("Source完了の未固定case参照")
			}
			abs, err := absolute(filepath.Dir(source), r.Path)
			if err != nil {
				return p, err
			}
			r.Path = abs
		}
	}
	for i := range full.Mutual {
		m := &full.Mutual[i]
		for _, r := range []*FileRef{&m.Legacy, &m.Default, &m.LegacyResult, &m.DefaultResult} {
			if !refShape(*r) {
				return p, fmt.Errorf("Source相互QAの未固定参照")
			}
			abs, err := absolute(filepath.Dir(source), r.Path)
			if err != nil {
				return p, err
			}
			r.Path = abs
		}
	}
	if e = validateSource12(full, c); e != nil {
		return p, e
	}
	p.Count = 70
	if stage == "first2" {
		p.Count = 2
	}
	return p, nil
}

// normalizeScene はCorpus基準のFileRefを絶対位置へ明示解決します。
//
// 引数: s(*SceneRef)、base(string)は一場の固定参照とCorpusの根です。
// 返り値: errorは空path/不正SHAです。本文を開いたり旧型へfallbackしません。
func normalizeScene(s *SceneRef, base string) error {
	for _, r := range []*FileRef{s.Clock, s.Legacy, s.Sym, s.W0} {
		if r != nil {
			if !refShape(*r) {
				return fmt.Errorf("Corpus未固定参照")
			}
			p, e := absolute(base, r.Path)
			if e != nil {
				return e
			}
			r.Path = p
		}
	}
	for k, r := range s.Records {
		if !refShape(r) {
			return fmt.Errorf("Corpus未固定Source")
		}
		p, e := absolute(base, r.Path)
		if e != nil {
			return e
		}
		r.Path = p
		s.Records[k] = r
	}
	return nil
}

// samePath はWindows上の絶対path表記差だけを比較します。
//
// 引数: a/b(string)は絶対path。返り値: boolは同じ正規pathならtrueです。
func samePath(a, b string) bool {
	a, _ = filepath.Abs(a)
	b, _ = filepath.Abs(b)
	return filepath.Clean(a) == filepath.Clean(b)
}
