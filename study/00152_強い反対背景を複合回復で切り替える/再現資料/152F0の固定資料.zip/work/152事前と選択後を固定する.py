"""152の追加判別を自然評価前後で固定し、金融判断から切り離す。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json

ROOT = Path(__file__).resolve().parent.parent
HERE = ROOT / 'work/152複合回復の入口'
STUDY = ROOT / 'study/00152_強い反対背景を複合回復で切り替える'
BOOK = ROOT / 'inputs/00152_複合回復の方向切替/条件.json'


def sha(path: Path) -> str:
    """
    機能: 物理ファイルを小分けに指紋化する。
    引数: path(Path)。返り値: strはSHA256。
    """
    result = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1048576), b''):
            result.update(block)
    return result.hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: F0でbook/源/3文書を固定し、F1で同体と全選択を束縛する。
    引数: CLI stage(str:F0/F1)、output-dir(Path)。返り値: None。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', choices=('F0', 'F1'), required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    files = set()
    previous = None
    if args.stage == 'F0':
        book = json.loads(BOOK.read_bytes())
        assert book['trial'] == 152 and book['primary'] == 'U1'
        files.update(ROOT / row['path'] for row in book['features_source'].values())
        files.update(ROOT / book['source151'][name]['path'] for name in ('zip', 'f1', 'book'))
        files.update(ROOT / path for path in book['sources'])
        files.update((BOOK, Path(__file__).resolve(),
            ROOT / 'inputs/00148_全1分入口母集団/100特徴の列定義.json',
            ROOT / 'study/00151_広い複合テクニカルを過去場だけで判別する/検査/正式保存の最終確認.json'))
        for name in ('logic152.py', '選択する.py', '人工検査.py', 'README.md', '準備する.py',
                     '準備の確認.json', '停止.json', '条件.json'):
            files.add(HERE / name)
        independent = ROOT / 'work/152純判定と運転の独立準備'
        assert independent.exists()
        files.update(p for p in independent.iterdir() if p.is_file())
        document_prep = ROOT / 'work/152正式準備'
        assert document_prep.exists()
        files.update(p for p in document_prep.iterdir() if p.is_file())
        files.add(ROOT / 'docs/議論/手法と時間スケールの汎用表_版7.md')
        for name in ('README.md', '条件.md', '設定と結果.md'):
            path = STUDY / name
            target = output / 'F0実行前文書' / name
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as sink:
                sink.write(path.read_bytes())
            files.add(path)
    else:
        f0 = output / 'F0入口選択前.json'
        previous = sha(f0)
        old = json.loads(f0.read_bytes())
        for name, expected in old['ファイル'].items():
            assert sha(ROOT / name) == expected, name
            files.add(ROOT / name)
        files.add(f0)
        selected = output / '入口選択'
        for name in ('q0の判断.json', '選択対応.json', '選択の確認.json'):
            files.add(selected / name)
        selection = json.loads((selected / '選択対応.json').read_bytes())
        assert selection['成功'] and selection['試行'] == 152
        assert selection['主政策'] == 'U1' and selection['book_sha256'] == sha(BOOK)
    result = {'成功': True, '試行': 152, '段階': args.stage,
        'UTC': datetime.now(timezone.utc).isoformat(), '前段階SHA256': previous,
        '主政策': 'U1', '比較': 'U0', '固定対照': 'U65',
        '全73場既使用/151後の事後着想': True, '追加2場価格未読': True,
        '継承151予測は各時点の過去成熟教師由来': True,
        '152判断へ教師又はq1を渡す': False,
        'ファイル': {p.relative_to(ROOT).as_posix(): sha(p) for p in sorted(files)}}
    target = output / ('F0入口選択前.json' if args.stage == 'F0' else 'F1入口選択後.json')
    with target.open('x', encoding='utf-8', newline='\n') as sink:
        json.dump(result, sink, ensure_ascii=False, indent=2, allow_nan=False)
        sink.write('\n')
    print(json.dumps({'成功': True, '段階': args.stage, '指紋数': len(files),
        'sha256': sha(target)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
