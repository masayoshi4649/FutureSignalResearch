"""152の式と運転境界を、自然資料を使わず別算術/人工I/Oで確認する。"""
from pathlib import Path
from types import SimpleNamespace
import copy
import hashlib
import importlib.util
import inspect
import itertools
import json
import math
import os
import sys
import uuid
import zipfile
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[2]
FOLDER=ROOT/'work/152複合回復の入口'
OWN=Path(__file__).resolve().parent
KEY_G=('m30_ema21_delta_to_side','m30_di_difference_to_side','m15_di_difference_to_side','m15_adx')
KEY_R=('m1_body_ratio_to_side','m1_body_reclaim_atr5_to_side','q0_last_minus_m1_close_atr5_to_side','m5_hist_delta_to_side','m5_rsi_delta_to_side','m1_volume_relative_prior3')
DIST='q0_entry_minus_ema8_atr5_to_side'


def sha(path: Path) -> str:
    """
    機能: 小型Sourceと人工資料を物理指紋化する。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def load(path: Path,name: str) -> object:
    """
    機能: Sourceをmain呼出しなしで私有importする。
    引数: path(Path)、name(str)。
    返り値: objectはモジュール。自然CLIは起動しない。
    """
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value


# ----------------------------------------
def numeric(value: object) -> float|None:
    """
    機能: 別実装でNone/NaNと有限数を区別する。
    引数: value(object)は人工値。
    返り値: float|None。bool/文字列/無限大は例外。
    """
    if value is None:return None
    if type(value)not in (int,float):raise ValueError('型')
    result=float(value)
    if math.isnan(result):return None
    if not math.isfinite(result):raise ValueError('非有限')
    return result


# ----------------------------------------
def oracle(side: int,buy: list,sell: list,index: dict) -> dict:
    """
    機能: bookの論理をSource定数/計算関数なしで独立評価する。
    引数: side(int)、buy/sell(list)、index(dict)。
    返り値: dictはG/R既知値とA/B方向・追い値判定。
    """
    if type(side)is not int or side not in (-1,0,1):raise ValueError('方向')
    if not side:return {'A':0,'B':0,'G':None,'R':{},'chase':None}
    vectors={1:buy,-1:sell};g=[numeric(vectors[side][index[k]])for k in KEY_G]
    g_known=all(x is not None for x in g)
    g_value=(max(g[:3])<0 and g[3]>25)if g_known else None
    r={}
    for target in (1,-1):
        values=[numeric(vectors[target][index[k]])for k in KEY_R]
        known=all(x is not None for x in values);live=None
        if values[1]is not None and values[2]is not None:
            live=math.fsum([values[1],values[2]])
            if not math.isfinite(live):raise ValueError('派生非有限')
        flag=(min(values[0],live,values[3],values[4])>0 and values[5]>=1)if known else None
        r[target]=(known,flag)
    target=0
    if g_known:
        if not g_value:target=side
        elif r[side][0]and r[-side][0]:
            if r[side][1]!=r[-side][1]:target=side if r[side][1]else -side
    chase=None;b=target
    if target:
        distance=numeric(vectors[target][index[DIST]]);passed=None if distance is None else distance<=1
        chase=(target,distance is not None,passed)
        if passed is not True:b=0
    return {'A':target,'B':b,'G':(g_known,g_value),'R':r,'chase':chase}


# ----------------------------------------
def reduced(value: dict) -> dict:
    """
    機能: Sourceの返り値を独立oracleと同じ論点へ射影する。
    引数: value(dict)はchoose返り値。
    返り値: dictは方向/既知/G/R/追い値のみ。
    """
    g=value['G'];chase=value['chase']
    return {'A':value['A0']['side'],'B':value['B0']['side'],
        'G':None if g is None else(g['known'],g['value']),
        'R':{int(k):(v['known'],v['value'])for k,v in value['R_by_side'].items()},
        'chase':None if chase is None else(chase['side'],chase['known'],chase['pass'])}


# ----------------------------------------
def main() -> None:
    """
    機能: 純式・境界・符号・project先検査・ZIP1member・後結合を人工で検査する。
    引数: なし。Source/旧151/自然148/151q0・152採否・金融・Rawは変更/読取しない。
    返り値: None。純dict潜在強化点は固定bookの実入力と分けて記録する。
    """
    paths=[FOLDER/'logic152.py',FOLDER/'選択する.py',FOLDER/'条件.json',
        ROOT/'work/151過去場判別/data151.py',ROOT/'scripts/入口研究/固定特徴から可読条件を選択する.py',
        ROOT/'study/00151_広い複合テクニカルを過去場だけで判別する/検査/正式保存の最終確認.json',
        ROOT/'study/00151_広い複合テクニカルを過去場だけで判別する/保管索引.json']
    before={p.relative_to(ROOT).as_posix():sha(p)for p in paths}
    assert sha(FOLDER/'条件.json')=='7805b17d8125b15c8f28d6d874a0a53e2066e92f858df21b41e0e61454167067'
    book=json.loads((FOLDER/'条件.json').read_bytes());logic=load(FOLDER/'logic152.py','independent_logic152');driver=load(FOLDER/'選択する.py','independent_driver152')
    catalog=json.loads((ROOT/'inputs/00148_全1分入口母集団/100特徴の列定義.json').read_bytes());names=[r['name']for r in catalog];index={name:i for i,name in enumerate(names)}
    groups=[];comparisons=0

    def vector(g: tuple=(-1,-2,-3,30),recovered: bool=False,distance: float=.5) -> list:
        """
        機能: 必要列だけを明示した人工100行を作る。
        引数: g(tuple)は4背景、recovered(bool)、distance(float)。
        返り値: listは自然値を含まない100列。
        """
        result=[None]*100
        for key,value in zip(KEY_G,g):result[index[key]]=value
        values=(.5,.3,.2,.1,.1,1)if recovered else(-.5,-.3,-.2,-.1,-.1,1)
        for key,value in zip(KEY_R,values):result[index[key]]=value
        result[index[DIST]]=distance;return result

    def compare(side: int,buy: list,sell: list) -> dict:
        """
        機能: 1人工を別算術・入力不変・価格反射の側交換と比較する。
        引数: side(int)、buy/sell(list)。
        返り値: dictはSource出力。
        """
        nonlocal comparisons
        prior=repr((buy,sell,catalog));actual=logic.choose(side,buy,sell,catalog)
        assert reduced(actual)==oracle(side,buy,sell,index)
        assert repr((buy,sell,catalog))==prior
        mirrored=logic.choose(-side,sell,buy,catalog)
        assert mirrored['A0']['side']==-actual['A0']['side']and mirrored['B0']['side']==-actual['B0']['side']
        assert mirrored['A0']['reason']==actual['A0']['reason']and mirrored['B0']['reason']==actual['B0']['reason']
        comparisons+=1;return actual

    for direction in (1,-1):
        for g in itertools.product((-1,0,1,None),repeat=3):
            for adx in (25,math.nextafter(25,math.inf),None,float('nan')):
                compare(direction,vector((*g,adx),True),vector((1,2,3,30),False))
    groups.append('G全known/負方向ゼロ/ADX25strict/NoneNaNを独立全組合せ比較')
    for same,opposite in itertools.product((False,True),repeat=2):
        compare(1,vector(recovered=same),vector((1,2,3,30),opposite))
    for target in (1,-1):
        for key in KEY_R:
            for value in (None,float('nan'),0,math.nextafter(0,math.inf)):
                buy=vector(recovered=True);sell=vector((1,2,3,30),False)
                (buy if target==1 else sell)[index[key]]=value;compare(1,buy,sell)
    for value in (math.nextafter(1,-math.inf),1,math.nextafter(1,math.inf)):
        buy=vector(recovered=True);buy[index[KEY_R[5]]]=value;compare(1,buy,vector((1,2,3,30),False))
    buy=vector(recovered=True);buy[index[KEY_R[1]]]=.5;buy[index[KEY_R[2]]]=-.5
    assert compare(1,buy,vector((1,2,3,30),False))['A0']['side']==0
    groups.append('R全必要known/両側確認/両true又は両false待機/量1含む/生存回復和ゼロ')
    for distance in (-100,1,math.nextafter(1,math.inf),None,float('nan')):
        actual=compare(1,vector(recovered=False,distance=.2),vector((1,2,3,30),True,distance))
        assert actual['A0']['side']==-1
        assert actual['B0']['side']==(-1 if distance is not None and not math.isnan(distance)and distance<=1 else 0)
    assert compare(1,vector(recovered=False,distance=100),vector((1,2,3,30),True,.5))['B0']['side']==-1
    assert compare(1,vector((0,-2,-3,30),False),vector((1,2,3,30),False))['A0']['side']==1
    groups.append('flip後の実側EMA8距離/上限1等号可/下限なし/G外維持にもB追い値を適用')
    rejected=0
    for bad_side in (True,False,1.0,-1.0,2,None):
        try:logic.choose(bad_side,vector(),vector(),names)
        except ValueError:rejected+=1
        else:raise AssertionError('s型拒否失敗')
    for key in (*KEY_G,*KEY_R,DIST):
        for bad in (True,False,float('inf'),float('-inf'),'1'):
            buy=vector(recovered=True);buy[index[key]]=bad
            try:logic.choose(1,buy,vector((1,2,3,30),False),names)
            except(ValueError,OverflowError):rejected+=1
            else:raise AssertionError((key,bad))
    duplicate=names.copy();duplicate[-1]=duplicate[0]
    try:logic.choose(1,vector(),vector(),duplicate)
    except ValueError:rejected+=1
    else:raise AssertionError('重複列通過')
    assert list(inspect.signature(logic.choose).parameters)==['s','buy','sell','columns']
    groups.append('bool/無限大/文字型/非三値方向/列重複拒否、q1又は教師を引数へ持たない')

    class Row:
        """人工1行のtolistだけを提供する。"""
        def __init__(self,value):
            """
            機能: 人工行を保持する。
            引数: value(list)。返り値: None。
            """
            self.value=value
        def tolist(self):
            """
            機能: 人工のPython配列を返す。
            引数: self(Row)。返り値: list。
            """
            return list(self.value)

    meta=[{'event_id':f'人工{i}','session':f'人工場{i}','contract':'人工限月','session_index':i,'q0_time':100+i,'q0_index':i+1,'q0_line':i+2}for i in range(2)]
    features=SimpleNamespace(columns=names,q0_meta=meta,buy_X=[Row(vector(recovered=False)),Row(vector(recovered=True))],sell_X=[Row(vector((1,2,3,30),True)),Row(vector((1,2,3,30),False))],scenes=[{'session':m['session']}for m in meta])
    source={'成功':True,'試行':151,'当場ラベルをモデルへ渡す':False,'rows':[{**m,'model_id':8,'decision':{'directions':{'P65':1}},'prediction':{'known_roles':['方向','構造'],'conditional_forward':.66}}for m in meta]}
    prior=copy.deepcopy(source);actual=driver.project(source,features,logic);assert source==prior
    assert actual[0]['decision']['directions']['A0']==-1
    for row in actual:
        for evidence in row['decision']['evidence']:
            assert evidence['new_prediction_probability']is None and evidence['source_prediction_side']==1
            assert set(evidence['roles'])<={'方向','強度','勢い','構造','値幅','量'}
    assert actual[0]['source_prediction_conditional']==.66
    calls=[];spy=SimpleNamespace(choose=lambda *args:calls.append(args)or logic.choose(*args))
    for key,value in [('q0_index',999),('session_index',999)]:
        bad=copy.deepcopy(source);bad['rows'][-1][key]=value
        try:driver.project(bad,features,spy)
        except AssertionError:pass
        else:raise AssertionError('meta不一致通過')
        assert not calls
    for value in (True,False,1.0,None):
        bad=copy.deepcopy(source);bad['rows'][-1]['decision']['directions']['P65']=value
        try:driver.project(bad,features,spy)
        except AssertionError:pass
        else:raise AssertionError('P65三値型差通過')
        assert not calls
    bad=copy.deepcopy(source);bad['rows'][-1]['prediction']['known_roles']=['方向','架空']
    try:driver.project(bad,features,spy)
    except AssertionError:pass
    else:raise AssertionError('未知role通過')
    assert not calls
    groups.append('全q0meta/三値/6roleをchoose前に検査しflipへ元予測65%を付け替えない')
    limit_meta=copy.deepcopy(source);limit_meta['rows'][0]['session_index']=False
    assert len(driver.project(limit_meta,features,logic))==2

    sandbox=OWN/'人工work'/uuid.uuid4().hex;sandbox.mkdir(parents=True)
    original_zip=zipfile.ZipFile;reads=[]
    member=book['source151']['member']
    payload=json.dumps(source,ensure_ascii=False).encode();member_sha=hashlib.sha256(payload).hexdigest()
    zip_path=sandbox/'人工151.zip'
    with original_zip(zip_path,'x')as archive:
        archive.writestr(member,payload)
        archive.writestr('models/人工.json',payload)
        for i in range(67):archive.writestr(f'その他/{i}.txt','本文は読まない')
    f1_path=sandbox/'人工F1.json';f1_path.write_text(json.dumps({'試行':151,'ファイル':{member:member_sha,'models/人工.json':member_sha}},ensure_ascii=False),encoding='utf-8')
    artifact_book={'source151':{'member':member,'member_sha256':member_sha,'member_bytes':len(payload),
        'f1':{'path':str(f1_path),'sha256':sha(f1_path)},'zip':{'path':str(zip_path),'sha256':sha(zip_path),'bytes':zip_path.stat().st_size}}}

    class TrackedZip:
        """人工ZIPでread対象member名だけを記録する。"""
        def __init__(self,*args,**kwargs):
            """
            機能: 元ZipFileで人工ZIPを開く。
            引数: args/kwargsはZipFile引数。返り値: None。
            """
            self.archive=original_zip(*args,**kwargs)
        def __enter__(self):
            """
            機能: 記録器を返す。引数: self。返り値: TrackedZip。
            """
            return self
        def __exit__(self,*args):
            """
            機能: ZIPを閉じる。引数: args。返り値: None。
            """
            self.archive.close()
        def namelist(self):
            """
            機能: 中央目録を返す。引数: self。返り値: list[str]。
            """
            return self.archive.namelist()
        def getinfo(self,name):
            """
            機能: memberのmetadataを返す。引数: name(str)。返り値: ZipInfo。
            """
            return self.archive.getinfo(name)
        def read(self,name):
            """
            機能: 読取名を記録する。引数: name(str)。返り値: bytes。
            """
            reads.append(name);return self.archive.read(name)

    with patch.object(driver.zipfile,'ZipFile',TrackedZip):
        assert driver.read_source(artifact_book)==source and reads==[member]
        changed=copy.deepcopy(artifact_book);changed['source151']['member_sha256']='0'*64;reads.clear()
        try:driver.read_source(changed)
        except AssertionError:pass
        else:raise AssertionError('F1 memberのSHA差通過')
        assert not reads
        changed=copy.deepcopy(artifact_book);changed['source151']['f1']['sha256']='0'*64
        try:driver.read_source(changed)
        except AssertionError:pass
        else:raise AssertionError('F1物理SHA差通過')
        assert not reads
        changed=copy.deepcopy(artifact_book);changed['source151']['member']='models/人工.json'
        assert driver.read_source(changed)==source and reads==['models/人工.json']
    groups.append('固定q0一memberのみread/F1物理とmember SHAを先検査。変更bookのliteral境界は限界へ分離')
    driver.validate_book(copy.deepcopy(book))
    changed=copy.deepcopy(book);changed['formula']['G']['m15_adx_strict_above']=24
    try:driver.validate_book(changed)
    except AssertionError:pass
    else:raise AssertionError('G閾値book差を許可')
    groups.append('現採用bookの数値/主政策/unionを照合し閾値改変を拒否')
    _main_and_union(driver,logic,book,catalog,features,source,sandbox,groups)
    after={p.relative_to(ROOT).as_posix():sha(p)for p in paths};assert before==after
    result={'成功':True,'編集停止':True,'区分':'152実行前の独立静的/人工確認','人工主群':groups,'群数':len(groups),'純式比較件数':comparisons,'数値型等の拒否件数':rejected,
        'Source前後SHA同体':before,'自然148/151q0本文/152採否/金融/Raw/追加2場読取':False,
        '作者計算をoracleへimport':False,'Source/旧151変更':False,
        '純dict潜在強化点と実自然の区別':[
            'projectのmeta比較は==でありsession_index=Falseが0と一致する人工は通る。現F1/ZIP物理SHA固定の自然入力に型差があることは調べておらず、s三値はtype intで別途厳格拒否。',
            'read_sourceは固定bookの指定一memberだけを読む。book/F1を共に改変した人工はmodel名memberを指定可能で、関数内literal whitelistはない。7805採用bookはq0正本を指定しF0物理束縛するため自然の重大差/ブロッカーとしない。'],
        '人工sandbox':sandbox.relative_to(ROOT).as_posix(),'重大未解決':[]}
    target=OWN/'独立人工の確認.json'
    with target.open('x',encoding='utf-8',newline='\n')as output:json.dump(result,output,ensure_ascii=False,indent=2);output.write('\n')
    print(json.dumps({'成功':True,'群数':len(groups),'純式比較':comparisons,'SHA256':sha(target)},ensure_ascii=False))


# ----------------------------------------
def _main_and_union(driver: object,logic: object,book: dict,catalog: list,features: object,source: dict,sandbox: Path,groups: list) -> None:
    """
    機能: 私有2行のI/O縮約で保存順とC1優先unionを検査する。
    引数: modules/人工book/features/source、sandbox(Path)、groups(list)。
    返り値: None。採用bookの実数35,339は別validate_book確認済みでここだけ2行へ縮約。
    """
    events=[];source=copy.deepcopy(source);book=copy.deepcopy(book);book['feature_rows']=2
    session_ids=[item['session']for item in features.scenes]

    def put(rel: str,body: bytes) -> Path:
        """
        機能: 人工I/Oだけの小型ファイルを作る。
        引数: rel(str)、body(bytes)。返り値: Path。
        """
        path=sandbox/rel;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(body);return path

    for key,item in book['features_source'].items():
        path=put('inputs/'+key+'.json',key.encode());item.update(path=path.relative_to(sandbox).as_posix(),sha256=sha(path),decoded_sha256=sha(path))
    book['sources']={}
    for name in ('data151.py','logic152.py','link.py'):
        path=put('work/'+name,name.encode());book['sources'][path.relative_to(sandbox).as_posix()]=sha(path)
    for key in ('f1','book','zip'):
        path=put('inputs/151_'+key+'.bin',key.encode());book['source151'][key].update(path=path.relative_to(sandbox).as_posix(),sha256=sha(path))
    catalog_path=put('inputs/00148_全1分入口母集団/100特徴の列定義.json',json.dumps(catalog,ensure_ascii=False).encode());book['catalog_definition_sha256']=sha(catalog_path)
    path=put('work/book.json',json.dumps(book,ensure_ascii=False).encode())
    out=sandbox/'work/output'
    base=[{'case_id':'旧人工','side':-1,'origin':'C1'}]
    direct={'P65':[{'case_id':'旧人工','side':1},{'case_id':'P新','side':-1}],
        'A0':[{'case_id':'旧人工','side':1},{'case_id':'A新','side':1}],
        'B0':[{'case_id':'旧人工','side':1},{'case_id':'B新','side':-1}]}

    def helper_connect(decisions,captures,descriptors,sessions,link_book):
        """
        機能: 既存凍結linkへの引数を確認しunion用人工2ケースを返す。
        引数: connectの各人工値。返り値: dict。
        """
        assert (out/'q0の判断.json').exists()and events.index('saved_q0')<events.index('read_captures')<events.index('read_metadata')
        assert link_book['main_id']=='U1'and link_book['union_rules']==['B0']and link_book['legacy_count']==87
        events.append('connect')
        return {'政策':{'C1':copy.deepcopy(base),**copy.deepcopy(direct),'U1':[*copy.deepcopy(base),copy.deepcopy(direct['B0'][1])]},
            '旧C1重複':[{'case_id':'旧人工','legacy_side':-1,'new_side':1,'opposite':True}]}

    helper=SimpleNamespace(connect=helper_connect)

    def read_ref(ref):
        """
        機能: capture/metaを読む順番だけを検査する人工reader。
        引数: ref(dict)はFileRefの人工代用。返り値: tuple。
        """
        kind=Path(ref['path']).stem;events.append('read_'+kind)
        assert(out/'q0の判断.json').exists()
        return ({'sessions':session_ids,'rows':[]}if kind=='captures'else {'sessions':session_ids,'population148':{'cases':[]}}),{}

    fake_data=SimpleNamespace(FileRef=lambda path,h,d:{'path':path},load_feature_dataset=lambda *args:events.append('features_only')or features,read_ref=read_ref)

    def get_module(path,name):
        """
        機能: mainの依存を人工専用部品へ差す。
        引数: path(Path)、name(str)。返り値: object。
        """
        return logic if path.name=='logic152.py'else fake_data if path.name=='data151.py'else helper

    original_save=driver.save

    def save(path,value):
        """
        機能: 実際の排他保存後にq0保存順だけを記録する。
        引数: path(Path)、value(dict)。返り値: None。
        """
        original_save(path,value)
        if path.name=='q0の判断.json':events.append('saved_q0')

    def artifact_reader(book):
        """
        機能: 自然ZIPではなく先に検証済みの人工2行を返す。
        引数: book(dict)。返り値: dict。
        """
        events.append('source_q0');return source

    cwd=Path.cwd()
    try:
        os.chdir(sandbox)
        argv=['人工152','--book','work/book.json','--book-sha256',sha(path),'--output-dir','work/output','--execute-after-f0']
        with patch.object(driver,'ROOT',sandbox),patch.object(driver,'HERE',sandbox/'work'),patch.object(driver,'validate_book',lambda value:None),patch.object(driver,'module',get_module),patch.object(driver,'read_source',artifact_reader),patch.object(driver,'save',save),patch.object(sys,'argv',argv):driver.main()
    finally:os.chdir(cwd)
    result=json.loads((out/'選択対応.json').read_bytes())
    for policy in ('U1','U0','U65'):
        assert next(row for row in result['政策'][policy]if row['case_id']=='旧人工')['side']==-1
        assert result['旧C1重複'][policy][0]['opposite']is True
    assert {row['case_id']for row in result['政策']['U0']}=={'旧人工','A新'}
    assert {row['case_id']for row in result['政策']['U65']}=={'旧人工','P新'}
    assert {row['case_id']for row in result['政策']['U1']}=={'旧人工','B新'}
    assert events==['features_only','source_q0','saved_q0','read_captures','read_metadata','connect']
    groups.append('main相対book/output resolve、全project後にq0排他保存→capture→meta→connect（2人工行へ縮約）')
    groups.append('旧C1反対方向alias優先保持、主U1=B0・比較U0=A0・U65=P65を混ぜない（共通link自体は凍結2f46参照）')


if __name__=='__main__':main()
