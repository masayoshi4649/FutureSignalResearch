"""152の採用済み条件を自然未実行の正式3文書へ固定する。"""
from pathlib import Path
import hashlib
import json
import os
import re

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
FORMAL = ROOT / 'study/00152_強い反対背景を複合回復で切り替える'
DESIGN = ROOT / 'work/152複合回復の設計案/設計案.md'
BOOK = ROOT / 'work/152複合回復の入口/条件.json'
PERMANENT_BOOK = ROOT / 'inputs/00152_複合回復の方向切替/条件.json'
V7 = ROOT / 'docs/議論/手法と時間スケールの汎用表_版7.md'


def digest(path: Path) -> str:
    """
    機能: 小型文書の物理SHA256を求める。
    引数: path(Path)。
    返り値: str。自然特徴や金融入力を開かない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def relocate(match: re.Match) -> str:
    """
    機能: 共通表の相対リンクを正式文書の起点へ移す。
    引数: match(re.Match)はMarkdownリンク。
    返り値: str。同じ実在対象を参照するリンク。
    """
    target = match.group(2)
    if '://' in target or target.startswith('#'):
        return match.group(0)
    path, sep, anchor = target.partition('#')
    resolved = (V7.parent / path).resolve()
    assert resolved.exists(), target
    relative = os.path.relpath(resolved, FORMAL).replace('\\', '/')
    return f'[{match.group(1)}]({relative}{sep}{anchor})'


def configure_table(text: str) -> str:
    """
    機能: 版7の57手法9尺度を保ち、152の使用セルへ設定を記入する。
    引数: text(str)は教材リンク移設後の原表。
    返り値: str。複合成績を指標単独の効果へ転記しない。
    """
    cells = {}
    inherited = '152-S：継承P65の入力；新閾値なし・152未検証'
    for ident in ('I01', 'I03', 'I04', 'I08', 'I09'):
        for scale in (3, 4, 5):
            cells[ident, scale] = inherited
    cells['I05', 4] = inherited
    for ident, scales in {'P01': (1, 3), 'P05': (0, 1, 3, 4, 5),
                          'P06': (1,), 'V01': (1, 3)}.items():
        for scale in scales:
            cells[ident, scale] = inherited
    direct = {
        ('I01', 3): '152-B：最終t側(P0−EMA8)×t/ATR5≤1；U1・未実行',
        ('I01', 5): '152-G：元s側EMA21Δ<0（生pt）；U1/U0・未実行',
        ('I03', 3): '152-R：各t側Hist実Δ>0（生pt）；U1/U0・未実行',
        ('I04', 3): '152-R：各t側RSI実Δ>0（RSIpt）；U1/U0・未実行',
        ('I08', 4): '152-G：元s側DI差<0/ADX>25；U1/U0・未実行',
        ('I08', 5): '152-G：元s側DI差<0；U1/U0・未実行',
        ('I09', 3): '152-R/B：ATR5>0で回復/距離尺度；U1・未実行',
        ('P01', 1): '152-R：r実体比_t>0；U1/U0・未実行',
        ('P04', 0): '152-R：t×(Last0−p.Open)/ATR5>0；U1/U0・未実行',
        ('P04', 1): '152-R：p/r現在回復・両R片側だけ；U1/U0・未実行',
        ('V01', 1): '152-R：r量/先行3平均≥1；U1/U0・未実行',
        ('C01', 0): '152-A：G内のMA/Hist/RSI＋構造/量；複合・未実行',
        ('C04', 4): '152-G：15分DI方向/ADX強度；複合・未実行',
        ('C07', 0): '152-G/R：30/15背景＋5勢い＋1分/Last；未実行',
        ('B01', 0): '152-L/B：q0実側距離・q1正常BBO継承；未実行',
        ('M01', 0): '152-S：151の保存P65だけ継承；新学習/推論なし',
        ('E01', 0): '152-E：実BBO/±125主・660比較；未実行',
        ('E01', 5): '152-E：H30副・±25/50/100/125/200；未実行',
        ('E01', 6): '152-E：H60±125主・他幅副；未実行',
        ('E02', 0): '対象外：口座利益保護/追尾を新評価しない',
    }
    cells.update(direct)
    result = []
    for line in text.splitlines():
        parts = line.split('|')
        if re.match(r'^\|\s+[A-Z]\d{2}\s+\|', line) and len(parts) == 13:
            ident = parts[1].strip()
            for scale in range(9):
                value = cells.get((ident, scale), '未使用・未検証')
                if ident.startswith('X') or ident == 'V05':
                    value = '対象外・新検証なし'
                parts[scale + 3] = f' {value} '
            line = '|'.join(parts)
        result.append(line)
    return '\n'.join(result) + '\n'


def main() -> None:
    """
    機能: 番号・採用指紋・513セルを確認し、152だけを新規作成する。
    引数: なし。
    返り値: None。旧試行・Source・共通目次を編集しない。
    """
    assert not FORMAL.exists()
    numbers = [int(p.name[:5]) for p in (ROOT / 'study').iterdir()
               if p.is_dir() and re.match(r'^\d{5}_', p.name)]
    assert max(numbers) == 151
    assert digest(DESIGN) == '309eb2130f02f7c7d70a9234899ff82c6c691a543e870063cd4d38313c444043'
    assert digest(BOOK) == '7805b17d8125b15c8f28d6d874a0a53e2066e92f858df21b41e0e61454167067'
    book = json.loads(BOOK.read_bytes())
    assert book['primary'] == 'U1' and book['comparison'] == 'U0' and book['fixed_control'] == 'U65'
    PERMANENT_BOOK.parent.mkdir(parents=True, exist_ok=True)
    if PERMANENT_BOOK.exists():
        assert PERMANENT_BOOK.read_bytes() == BOOK.read_bytes()
    else:
        PERMANENT_BOOK.write_bytes(BOOK.read_bytes())
    FORMAL.mkdir()
    readme = '''# 152 強い反対背景を複合回復で切り替える

**自然選択・金融は未実行。主U1（B＋旧C1）、比較U0（A＋旧C1）、固定対照U65（保存P65＋旧C1）を結果を見る前に固定する。** 準備は[条件](条件.md)と[設定と結果](設定と結果.md)を正本とし、結果後に主を交換しない。

保存P65の非ゼロ方向だけを対象に、強い反対背景では両方向の現在回復を確認する。元方向の回復だけが成立すれば維持し、背景方向の回復だけなら切り替え、確認できなければ待つ。主Bはさらに最終注文側のq0実側が5分EMA8から順向きに1ATRを超えて離れた候補を抑える。新しいモデル・特徴・定時入口は作らない。

## 仮説と役割

| 役割 | 採用する情報 | 判断の範囲 |
| --- | --- | --- |
| 方向・強さ | 30分EMA21実増分、30/15分DI差、15分ADX>25 | P65へ逆らう強い背景Gを分類。ADXだけで方向を決めない |
| 価格構造 | 最新1分rの実体と、q0Lastの隣接前足p.Openに対する回復 | 終値だけの回復がq0でも残るかを確認 |
| 勢い | 5分Hist実増分とRSI実増分 | 同じ勢い役割の整合確認。独立票2つとは数えない |
| 量 | r量/先行3足平均量≥1 | 回復足r自身の量。将来の量を使わない |
| 取得位置 | 最終注文側のq0 Ask/Bid−EMA8をATR5で測る | Aから位置上限だけを追加したBを分離 |

心理の仮説は「強い反対背景で逆張りを維持するにも、背景側へ方向を変えるにも、価格回復・動力・量の同調を求める」。実際の参加者の注文意図や反転完了を証明するものではない。ADXの一般的な解釈は[方向と強さ](../../docs/technical-analysis/組み合わせ/DMIとADXによる方向と強さ.md)を参照する。25と1ATRは自然成績で最適化した値ではなく、今回の固定仮説である。

## 入力・時計・対照

[151の保存判断](../00151_広い複合テクニカルを過去場だけで判別する/README.md)と[148の母集団](../00148_全1分知得から入口品質の母集団を固定する/README.md)を共有参照する。全35,339q0を保持し、取得済みP65だけから再出発しない。保存P65が待機なら152も新方向を生まない。買売100列は既に各実側Ask0/Bid0で別計算されており、反対側を一律negateしない。

152はq0の全判断を保存してからq1対応・旧C1表を結合する。q1の存在・価格・後続品質・先着・損益はG/R/Bに渡さない。148の別Raw+1秒、最初正常BBO、TTL・最新足品質を変更しない。同q1は最初q0を採用し、旧C1全87と重なるときは旧C1を優先する。C1へ新gateを掛けない。

11政策はC0/C1/RC1/P65/RP65/U65/A0/B0/U0/U1/RU1。C0はC1内の旧81、実逆は保存された反対BBO streamで評価する。NB0はB0の接続用aliasで、独立の取引数・金融政策として二重加算しない。

## 評価・費用・未実行の結果

主は実BBO/H60/±125pt。到達済み先着率70%以上・全73場最低1取得・全時間平均概ね1回/hを別々にも共同でも判定する。待機の増加で少数群だけを残して達成扱いにしない。回数の場間偏りは許容し、同じ物理q1を水増ししない。

11政策×全体/前48/後25×BBO/Last×H30/H60×幅25/50/100/125/200の660比較を予定する。利益・損失・差引と未知件数、完了分母率・全取得分母率・未到達・観測不足を分ける。数量1mini=100円/pt、往復税込77円、C5は追加1,000円。Last金額は未算出/null、未知を0円にしない。

**152の候補数・取得数・率・利益・損失はまだ未算出。** 入口IFDの独立代用であり、重複建玉を束ねた口座収支・可変枚数・必須追尾の評価ではない。元P65確率を切替側の確信度へ転用しない。

## 限界と再現

全73場は既使用で、151結果を見た後の仮説。親151の過去場限定学習を継承しても、152を独立未知期での検証とは呼ばない。近接q0とH60窓の依存、q1共有、ラージ代理板とmini実約定の差、CSV公表モデルと実受信時計の差を維持する。方向を変えた側の注文戦略・構造capの再構築も行わない。

正式採用後のRoot F0固定→q0選択→F1固定→金融の順で実行する。実行はまだ行っていない。入力指紋とCLIは[条件](条件.md)、513セルと設定IDは[設定と結果](設定と結果.md)へ記録した。大入力は既存147/148/151の恒久保存を参照し、重複複写しない。152の選択・比較・全73場・入口のCSV/閲覧資料は実行後に恒久化する予定で、現在は未生成。新しいxlsxは作らない。
'''
    condition = '''# 152 実行前の採用条件

2026-11-12。**自然選択・金融未実行、F0前。** 152の主U1・比較U0・固定対照U65を固定する。[採用元の設計案](../../work/152複合回復の設計案/設計案.md)はA/B未採用時の原文であり、そこで未確定とした主/比較は[最終book](../../inputs/00152_複合回復の方向切替/条件.json)の採用で確定した。条件を結果に合わせて変更しない。

## 152-S：固定入力と旧判断

NK225、既使用73場。母集団は148のeligible35,339q0。151の保存q0判断の `decision.directions.P65` をs∈{−1,0,+1}とする。152は過去教師の再射影・学習・モデル再推論・確率再校正・新X生成を行わない。s=0は待機のまま。s≠0の全q0を対象にし、P65の取得成立だけへ絞らない。

q0のsession/contract/time/index/lineとfeaturesを全件照合してから新判断を始める。親ZIPはq0判断の指定一memberだけを読み、modelsや旧取得選択memberを開かない。全100列の辞書順・式・known/nullは148から不変更。P0_tは買Ask0/売Bid0で、q1実価格ではない。買売保存配列を各側で読み、一律の符号反転で補わない。

## 152-G：強い反対背景

元P65側sの次の4入力が全てknownであるときだけ真偽を判定する。

```text
G(s) = m30_ema21_delta_to_side(s) < 0
   AND m30_di_difference_to_side(s) < 0
   AND m15_di_difference_to_side(s) < 0
   AND m15_adx > 25
```

EMA実増分は価格pt、DI/ADXは指標尺度。ATR正規化列に置き換えてknownを変えない。1つでも未知ならG未知とし、既知falseによる短絡で未知を消さない。方向0又はADX=25は、4入力全knownならG false。G falseではAは元s維持、G未知では待機する。ADXは無符号の強度であり方向はDI/EMAが担う。

## 152-R：両側の現在回復

rは最新1分、pは実隣接前1分。t∈{s,−s}の各保存配列を用いる。

```text
liveReclaim(t) = m1_body_reclaim_atr5_to_side(t)
               + q0_last_minus_m1_close_atr5_to_side(t)
               = t*(Last0−p.Open)/ATR5

R(t) = m1_body_ratio_to_side(t) > 0
   AND liveReclaim(t) > 0
   AND m5_hist_delta_to_side(t) > 0
   AND m5_rsi_delta_to_side(t) > 0
   AND m1_volume_relative_prior3 >= 1
```

実体比=t*(r.Close−r.Open)/(r.High−r.Low)。量はr.Volume/当場連続先行3本の平均量でrを分母に含めない。Hist実増分は価格pt、RSI実増分はRSIpt。Rの6列すべてknownが必須で、欠ければR未知。実体/live/HistΔ/RSIΔの等号0はfalse、量=1はtrue。未知を既知0にしない。有限値の和がoverflowなら入力errorとし、None/NaNは未知、inf/bool等不正型は拒否する。

live回復はr.Closeだけでなくq0Lastで残る回復であり、q1保持や将来のリテスト成立を意味しない。HistとRSIを独立した2系統の票として加算しない。R同時両trueは正常な符号対称データでは原理上ないが、防御的に待機し矛盾を残す。

## 152-A：方向切替

| 保存s/背景/回復 | A0の注文方向t |
| --- | --- |
| s=0 | 0 |
| s≠0、G false | s |
| G未知 | 0 |
| G true、両R全known、R(s)trueだけ | s（逆張り維持） |
| G true、両R全known、R(−s)trueだけ | −s（背景側への切替） |
| G true、どちらかR未知・両false・両true | 0 |

元sの保存P65確率は出典として残し、−sの予測確率を捏造しない。切替はTAの新仮説である。G falseの枝はR確認を新たに必須とせず、保存P65を維持する。

## 152-B：最終注文側の追い掛け上限

A0の結果t≠0にだけ、t側 `q0_entry_minus_ema8_atr5_to_side = t*(P0_t−EMA8_5)/ATR5 <= 1` を追加する。=1を含み、>1又は未知ならB0は待機。負側下限は設けず、絶対値制限にしない。元sの位置を先に掛けない。切替側はt側Ask0/Bid0の保存値を使い、元側のnegate補完をしない。不成立時は反対方向へ再選択せず、将来EMAへ戻る指値待機にも変更しない。

## 152-L：出生判断と取得の分離

全35,339q0の判断を保存後、初めて148captures/metadataを読み取得へ結ぶ。q1の有無・価格・品質・ラベル、旧C1の未来取得表はG/R/A/Bに渡さない。

取得は148の独立pendingを継承する。q0と別Raw、1秒以上後、L/TTL strict、最新1分品質、最初正常Bid<Askという固定処理を変えない。q1同一物理caseの新候補はq0index→q0line→event IDの最初でcanonicalにする。後発aliasが方向を取り直さない。全73場を残し、未取得も0場として参加分母へ残す。場ごとの回数均等割当や毎時強制エントリーはしない。

旧C1全87を統合時に保護する。同q1はC1が方向競合でも優先し、旧C1へ152gateを掛けない。C0旧81はC1のsubset。直接接続NB0=B0はaliasのみで、独立の金融政策や頻度へ二重加算しない。

## 政策と比較数

| 政策 | 内容 | 位置付け |
| --- | --- | --- |
| C0 | C1内の旧81 | 固定対照 |
| C1 | 旧145全87 | 固定対照 |
| RC1 | C1実逆 | 反転診断 |
| P65 | 保存P65の同q0方向/取得 | 固定対照 |
| RP65 | P65実逆 | 反転診断 |
| U65 | P65＋旧C1、C1優先 | 固定対照 |
| A0 | G/RによるAの新取得のみ | 方向確認比較 |
| B0 | A＋最終注文側1ATR上限の新取得のみ | 新主の単独分 |
| U0 | A0＋旧C1、C1優先 | 比較 |
| U1 | B0＋旧C1、C1優先 | **主** |
| RU1 | U1全件の実逆 | 主の反転診断 |

11政策×3区分（全体/前48/後25）×BBO/Last×H30/H60×幅25/50/100/125/200=660比較。主をH60/±125実BBOから結果後に交換しない。全場最低1と全時間平均概ね1/h、到達済み先着70%以上をそれぞれ及び共同で判定する。主U1の同q1重複除去後の取得を数える。頻度分母はsum(scene.end−300−scene.start)/3600、区間の名目時計と実取得可用時間を混同しない。

F/A/N/C（順側先着/逆側先着/未到達/観測不足）を別計数。到達済み率F/(F+A)、H完了分母率F/(F+A+N)、全取得分母率F/(F+A+N+C)を併記し、分母0はnull。censorをneitherへ入れず、H不足でも既知touchとIFD価格/金額既知性を別に保持する。反転は保存反対側BBO streamを再評価し1−pとしない。

## 152-E：費用と解釈

数量は独立1mini=100円/pt。往復税込77円、C5は追加1,000円なので費用後損益=pt×100−1,077円。C0費用は追加滑りなしの77円で、政策名C0と費用名C0を区別する。利益合計・損失絶対額合計・差引・既知/未知件数を保存する。Lastの金額はnull、金額未知を0円へ埋めない。全73場累計は未知1件でも以降の全件確定差引nullを保持し、既知分累計と分ける。

入口IFDの独立評価で、建玉を重ねた実口座・可変枚数・必須トレーリングの成果ではない。ラージ代理板/mini実行の差と、反転側の新規注文geometryを再構築していない限界を明記する。

## 入力指紋と実行順

'''
    condition += f'''採用元設計案SHA256 `{digest(DESIGN)}`。最終bookSHA256 `{digest(BOOK)}`。100列定義SHA256 `{book['catalog_definition_sha256']}`。[100列定義](../../inputs/00148_全1分入口母集団/100特徴の列定義.json)の辞書順・未知を変更しない。

| 共有入力 | 物理SHA256 | 解凍SHA256 |
| --- | --- | --- |
'''
    for row in book['features_source'].values():
        condition += f"| [{Path(row['path']).name}](../../{row['path']}) | `{row['sha256']}` | `{row['decoded_sha256']}` |\n"
    source = book['source151']
    condition += f'''
親151の[ZIP](../../{source['zip']['path']})物理SHA256 `{source['zip']['sha256']}`、{source['zip']['bytes']:,} bytes。読むmemberは `{source['member']}` のみ、解凍{source['member_bytes']:,} bytes/SHA256 `{source['member_sha256']}`。[親F1](../../{source['f1']['path']})SHA256 `{source['f1']['sha256']}`へ束縛する。

[純判断・CLIの説明](../../work/152複合回復の入口/README.md)に従い、Rootが源と入力のSHAをF0へ固定後に実行する。152選択→F1固定→金融の順。自然採否数・金額はまだ未算出。SourceのCLI・準備票最終SHAはF0前に停止版を別確認し、正式保管でSource/固定資料を一度だけ恒久保存する。現在のworkリンクは実行前の作業源であり、完成後の閲覧資源をworkだけには依存させない。

```powershell
& 'work/複合テクニカル学習環境/Scripts/python.exe' -X utf8 `
  'work/152複合回復の入口/選択する.py' `
  --book 'inputs/00152_複合回復の方向切替/条件.json' `
  --book-sha256 '{digest(BOOK)}' `
  --output-dir 'work/152複合回復の評価/入口選択' `
  --execute-after-f0
```

上は未実行の予定コマンド。金融は別運転でF1/F2と保存観測を照合する。全セッション/比較/入口CSVと閲覧資料は実行後に作成する。新xlsxは生成しない。

## 一般説明・心理仮説・適用限界

方向と強さの分離は[DMI/ADXの教材](../../docs/technical-analysis/組み合わせ/DMIとADXによる方向と強さ.md)を参照する。採用元案は2026-11-12確認の[Fidelity DMI](https://www.fidelity.com/learning-center/trading-investing/technical-analysis/technical-indicator-guide/DMI)を出典としてADX>25を採った。25がNK225で成功する閾値という主張ではない。1ATR上限とG/Rの複合ANDは本研究独自の未検証仮説。

心理は「逆らう背景にも、その背景方向へ切り替える場合にも、価格・動力・量の確認を要求する」という仮説。反転完成・実注文圧力の証明ではない。149の低ADX端回復や150の突破失敗/再試行と部品は重なるが、152は保存P65からの条件付き方向変更で、既存手法の再発見や単独指標の効果としない。

全73場既使用・151後の事後着想で独立未知期でない。親モデルのpast-only教師境界は継承するが152の閾値を未知期で選んだことにはならない。近接H60窓/同場/買売pairの依存、q0とq1の遅れ、CSV知得モデルと実受信時刻の違いは残る。待機増だけで70達成としない。長い高安/VWAP/VWMA、新アンカー、新学習や新特徴は混ぜない。
'''
    condition += '''
## F0前のSource停止版への束縛

Source作者の[準備票](../../work/152複合回復の入口/準備の確認.json) SHA256 `60358de4d930b885e36d8d75f553d21def6497d88aad772ec40e8a4f42cdc41a`、[停止票](../../work/152複合回復の入口/停止.json) SHA256 `3910670316454cb6bdb9af7c29b34a006874886da8842a3514f1dbc5a7d92707`へ束縛する。作者人工8群成功はSourceの準備証跡であり、自然152の成績ではない。Sourceの独立検査は別担当、本文は正式文書作者の自己確認である。

| 停止Source | SHA256 |
| --- | --- |
| 純判断logic152.py | `e9d7bff7f1b02636ddb1b2ea30afaa16540cb3966d55c94edd0eb4e409c77b62` |
| 選択する.py | `e430e730b04155b8ab7b6b2616e1629aa9101e9b489e52ad2e5e1b44aa66dbee` |
| 恒久book | `7805b17d8125b15c8f28d6d874a0a53e2066e92f858df21b41e0e61454167067` |

旧準備book ad9923d6版から、CLI相対パス正規化・親151bookの恒久参照・6役割の出典表示・Source自己SHA束縛をF0前に補正した。G/R/Bの数値と主/比較は変更していない。正式は上の最終7805版だけを採用し、旧版を実行入力としない。
'''
    raw_v7 = V7.read_text(encoding='utf-8')
    table = raw_v7.split('## 手法×時間スケール', 1)[1].split('## 設定明細', 1)[0]
    table = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', relocate, table)
    table = configure_table(table)
    table = table.replace('全セルは未設定・未検証。',
                          '該当セルは設定済み、自然評価は全て未実行。未使用・未検証等は各セルに記す。', 1)
    settings = f'''# 152 設定と結果・実行前準備

**自然選択・金融未実行。** 主U1、比較U0、固定対照U65。[条件](条件.md)の固定仮説を適用し、結果で閾値や主を交換しない。

[汎用表版7](../../docs/議論/手法と時間スケールの汎用表_版7.md) SHA256 `{digest(V7)}`。57手法×9尺度=513セルの構造・ID・時間列をコピーし、教材リンクの起点を移した。該当セルに152-G/R/B等の設定IDと短い閾値を記入し、継承P65の入力と152で直接適用する条件を分けた。複合評価の成績を各指標単独の効果へ転記しない。欠損時は条件どおり未知/待機とし、自然データ不足件数は未計数である。

## 手法×時間スケール{table}
## 152の設定明細

| 設定ID | 手法ID・尺度 | 役割と固定設定 | 適用・状態 |
| --- | --- | --- | --- |
| 152-S | M01、既存1/5/15/30分100列 | 保存151 P65方向を継承。新学習/再推論/再校正なし | 35,339q0全保持。152未検証 |
| 152-G | I01・I08、30/15分 | 元sのEMA21Δ30<0・DI30<0・DI15<0・ADX15>25。全4known | G false keep/G unknown wait。未検証 |
| 152-R1 | P01/P04、1分＋原行 | 実体比_t>0、live回復_t=x29+x92>0 | R6列全known、両側で確認。未検証 |
| 152-R2 | I03/I04、5分 | HistΔ_t>0、RSIΔ_t>0。生尺度の実増分 | 同じ勢い役割。未検証 |
| 152-R3 | V01、1分 | r量/当場先行3平均量≥1。rを分母から除外 | 回復rと同足量。未検証 |
| 152-A | C01/C04/C07＋P01＋V01 | G内は両Rknown、片側trueのみ採用。他wait | A0/U0。未検証 |
| 152-B | I01/I09、5分＋原行 | 最終t側 t*(Ask0又はBid0−EMA8)/ATR5≤1、下限なし | B0/U1主。未知wait。未検証 |
| 152-L | B01、逐次 | q0全判断後q1結合、同q1最初、旧C1優先 | 148取得条件継承、未検証 |
| 152-E | E01、原板/30/60分 | 実BBO主H60±125、11政策660、1mini/77円/C5追加1000円 | 先着/IFD/頻度を分離。未実行 |
| 152-P | E02 | 利益保護・口座数量/追尾の新比較なし | 対象外、入口IFD代用だけ |

GのEMA/Hist/DIの符号確認でATR正規化列を代用せずknownを増減させない。live回復とBの距離はATR5>0が必要。100列の他指標は親151に入力済みだが、152で新しく閾値を置いたことにはならない。BB15は152の新gateに使わず、VWAP/VWMA/日足/別幅3分の新生成も行わない。

## 複合比較と結果欄

| 評価ID | 政策 | 件数・率・利益/損失 | 実行状態 |
| --- | --- | --- | --- |
| 152-U1 | B0＋C1、C1優先 | 未算出 | 主・未実行 |
| 152-U0 | A0＋C1、C1優先 | 未算出 | 比較・未実行 |
| 152-U65 | P65＋C1、C1優先 | 未算出 | 固定対照・未実行 |
| 152-ALL | C0/C1/RC1/P65/RP65/U65/A0/B0/U0/U1/RU1 | 全73場/660条件を予定 | 未実行 |

70%以上・全73min1・全時間概ね1/hを別々にも共同でも判定する。F/A/N/C、完了/全件分母、金額既知/未知、累計未知を別記する。各場均等の回数割当はない。結果後もこの513セルと採用条件原文を保持し、結果は末尾へ追記する。
'''
    for name, text in [('README.md', readme), ('条件.md', condition), ('設定と結果.md', settings)]:
        (FORMAL / name).write_text(text, encoding='utf-8')
    print(json.dumps({'成功': True, '作成先': FORMAL.relative_to(ROOT).as_posix(),
                      '旧最大番号': max(numbers), '自然選択又は金融': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
