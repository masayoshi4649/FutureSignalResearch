"""152正式3文書と実行前bookの構造・リンク・停止版への束縛を確認する。"""
from pathlib import Path
import hashlib
import json
import re
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
FORMAL = ROOT / 'study/00152_強い反対背景を複合回復で切り替える'
SOURCE = ROOT / 'work/152複合回復の入口'
V7 = ROOT / 'docs/議論/手法と時間スケールの汎用表_版7.md'
BOOK = ROOT / 'inputs/00152_複合回復の方向切替/条件.json'


def fingerprint(path: Path) -> dict:
    """
    機能: 小型Sourceと文書のサイズ・SHAを記録する。
    引数: path(Path)。
    返り値: dict。自然入力本文と金融を開かない。
    """
    raw = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def rows(text: str) -> list[list[str]]:
    """
    機能: 他の追記表と分け、57手法の9尺度行を抽出する。
    引数: text(str)。
    返り値: list[list[str]]。セルのID/手法/9尺度を保持する。
    """
    return [line.split('|')[1:-1] for line in text.splitlines()
            if re.match(r'^\|\s+[A-Z]\d{2}\s+\|', line) and len(line.split('|')) == 13]


def main() -> None:
    """
    機能: 採用条件の不変更、513の設定、全リンクと源指紋を確認して停止票を保存する。
    引数: なし。
    返り値: None。正式/Source/自然出力/旧試行を編集しない。
    """
    docs = [FORMAL / name for name in ('README.md', '条件.md', '設定と結果.md')]
    small = [V7, BOOK, SOURCE / '条件.json', SOURCE / '停止.json', SOURCE / '準備の確認.json']
    paths = docs + small
    before = {p: fingerprint(p) for p in paths}
    expected_book = '7805b17d8125b15c8f28d6d874a0a53e2066e92f858df21b41e0e61454167067'
    assert fingerprint(BOOK)['sha256'] == expected_book
    assert BOOK.read_bytes() == (SOURCE / '条件.json').read_bytes()
    assert fingerprint(SOURCE / '停止.json')['sha256'] == '3910670316454cb6bdb9af7c29b34a006874886da8842a3514f1dbc5a7d92707'
    assert fingerprint(SOURCE / '準備の確認.json')['sha256'] == '60358de4d930b885e36d8d75f553d21def6497d88aad772ec40e8a4f42cdc41a'
    stop = json.loads((SOURCE / '停止.json').read_bytes())
    for path, expected in stop['源'].items():
        p = ROOT / path
        assert fingerprint(p)['sha256'] == expected
        before[p] = fingerprint(p)
    original_rows = rows(V7.read_text(encoding='utf-8'))
    configured = rows(docs[2].read_text(encoding='utf-8'))
    assert '全セルは未設定・未検証。' not in docs[2].read_text(encoding='utf-8')
    assert '該当セルは設定済み、自然評価は全て未実行。' in docs[2].read_text(encoding='utf-8')
    preceding = docs[2].read_bytes().replace(
        '該当セルは設定済み、自然評価は全て未実行。未使用・未検証等は各セルに記す。'.encode('utf-8'),
        '全セルは未設定・未検証。'.encode('utf-8'), 1)
    assert hashlib.sha256(preceding).hexdigest() == 'ebc973a04d7df27d4ee170f66ea1e45844eee091250e3d7505a3a2084053580c'
    assert len(original_rows) == len(configured) == 57
    assert [r[0] for r in original_rows] == [r[0] for r in configured]
    assert len({r[0] for r in configured}) == 57
    assert all(len(r[2:]) == 9 for r in configured)
    label = re.compile(r'^\s*\[([^]]+)\]')
    assert [label.match(r[1]).group(1) for r in original_rows] == [label.match(r[1]).group(1) for r in configured]
    header = '| ID | 手法 | 原板・逐次 | 1分 | 3分 | 5分 | 15分 | 30分 | 60分 | セッション足 | 日足 |'
    assert docs[2].read_text(encoding='utf-8').count(header) == V7.read_text(encoding='utf-8').count(header)
    by_id = {r[0].strip(): r[2:] for r in configured}
    for ident, scale, token in [('I01', 5, '152-G'), ('I01', 3, '152-B'),
                                ('I03', 3, '152-R'), ('I04', 3, '152-R'),
                                ('I08', 4, 'ADX>25'), ('I08', 5, 'DI差<0'),
                                ('P01', 1, '実体比'), ('V01', 1, '先行3'),
                                ('I09', 3, 'ATR5>0'), ('M01', 0, '新学習/推論なし')]:
        assert token in by_id[ident][scale]
    assert all('未設定・未検証' not in cell for r in configured for cell in r[2:])
    book = json.loads(BOOK.read_bytes())
    assert book['primary'] == 'U1' and book['comparison'] == 'U0' and book['fixed_control'] == 'U65'
    assert len(book['policies']) == 11 and len(set(book['policies'])) == 11
    text = docs[1].read_text(encoding='utf-8')
    for row in book['features_source'].values():
        assert row['sha256'] in text and row['decoded_sha256'] in text
    for fragment in ('m30_ema21_delta_to_side(s) < 0', 'm15_adx > 25',
                     'm5_hist_delta_to_side(t) > 0', 'm5_rsi_delta_to_side(t) > 0',
                     'm1_volume_relative_prior3 >= 1', 'q0_entry_minus_ema8_atr5_to_side',
                     '全73場', '660比較', '新方向を生まない'):
        # 方向不生成の説明はREADMEにも置く。
        assert fragment in text or fragment in docs[0].read_text(encoding='utf-8')
    link_count = 0
    for p in docs:
        for target in re.findall(r'\]\(([^)]+)\)', p.read_text(encoding='utf-8')):
            if '://' in target or target.startswith('#'):
                continue
            local = unquote(target.strip('<>').split('#', 1)[0])
            assert (p.parent / local).exists(), (p.name, target)
            link_count += 1
    assert before == {p: fingerprint(p) for p in before}
    proof = {'成功': True, '試行': 152, '編集停止': True,
             '正式3MDは自然選択と金融未実行': True, '旧最大151から採番': True,
             '前停止表ebc973から説明文1文だけを変更_閾値行不変': True,
             '汎用表': {'版': 7, '手法': 57, '尺度': 9, 'セル': 513,
                        'ID手法順時間列維持': True, 'G_R_B該当セル設定済み': True,
                        '元表513本文の全同値とは主張しない': True},
             '主': 'U1', '比較': 'U0', '固定対照': 'U65', '比較条件数': 660,
             'book永久1回保存同体': fingerprint(BOOK), 'ローカルリンク実在': link_count,
             'Source作者停止版同体': True, '全確認源前後同体': True,
             '自然特徴_151判断本文_教師_金融_Raw_CSV_追加2場読取': False,
             'Source数学の独立検査': False, '正式文書作者の自己確認': True,
             '旧151以前_Source_目次変更': False, '対象指紋': list(before.values()),
             '確認器': fingerprint(Path(__file__)),
             '生成器': fingerprint(HERE / '正式文書を作る.py')}
    target = HERE / '準備の確認.json'
    target.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, 'セル': 513, 'リンク': link_count,
                      '準備票SHA256': fingerprint(target)['sha256'],
                      '正式3MD': [fingerprint(p) for p in docs]}, ensure_ascii=False))


if __name__ == '__main__':
    main()
