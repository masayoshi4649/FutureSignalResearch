"""152の純判定・ZIP限定読取・取得後結合だけを人工で確認する。"""
from pathlib import Path
from types import SimpleNamespace
import copy
import inspect
import json
import tempfile
import unittest
from unittest.mock import patch
import zipfile
import numpy as np

import logic152 as logic
from importlib.util import spec_from_file_location, module_from_spec

HERE = Path(__file__).resolve().parent
s = spec_from_file_location('run152test', HERE / '選択する.py')
run = module_from_spec(s)
s.loader.exec_module(run)
NEEDED = sorted(set((*logic.G_KEYS, *logic.R_KEYS, logic.CHASE)))
NAMES = sorted(NEEDED + [f'人工追加{i:03}' for i in range(100 - len(NEEDED))])
INDEX = {n: i for i, n in enumerate(NAMES)}


def vectors() -> tuple:
    """
    機能: 強反対背景で買いの回復だけが成立する100列を作る。
    引数: なし。
    返り値: tuple[list,list]は独立した買売配列。
    """
    buy, sell = [0.] * 100, [0.] * 100
    for t, vector in ((1, buy), (-1, sell)):
        for key in logic.G_KEYS[:3]:
            vector[INDEX[key]] = -t
        vector[INDEX['m15_adx']] = 26
        for key in logic.R_KEYS:
            vector[INDEX[key]] = t
        vector[INDEX['m1_volume_relative_prior3']] = 1
        vector[INDEX[logic.CHASE]] = .5
    return buy, sell


class Tests(unittest.TestCase):
    def test_既知境界と未知(self):
        """
        機能: ADX25・方向0・量1・回復0と全必要knownを確認する。
        引数: self(Tests)。
        返り値: None。
        """
        buy, sell = vectors()
        self.assertEqual(logic.choose(1, buy, sell, NAMES)['B0']['side'], 1)
        for key, value in [('m15_adx', 25), ('m30_di_difference_to_side', 0)]:
            b = list(buy);b[INDEX[key]] = value
            self.assertFalse(logic.choose(1, b, sell, NAMES)['G']['value'])
            self.assertEqual(logic.choose(1, b, sell, NAMES)['A0']['side'], 1)
        b = list(buy);b[INDEX['m15_adx']] = 25;b[INDEX['m30_di_difference_to_side']] = None
        self.assertIsNone(logic.choose(1, b, sell, NAMES)['G']['value'])
        self.assertEqual(logic.choose(1, b, sell, NAMES)['A0']['side'], 0)
        for key, value in [('m1_volume_relative_prior3', .999), ('m1_body_ratio_to_side', 0), ('m5_hist_delta_to_side', 0), ('m5_rsi_delta_to_side', 0), ('m1_body_reclaim_atr5_to_side', None)]:
            b = list(buy);b[INDEX[key]] = value
            self.assertEqual(logic.choose(1, b, sell, NAMES)['A0']['side'], 0)
        b = list(buy);b[INDEX['m1_body_reclaim_atr5_to_side']] = -1
        self.assertEqual(logic.choose(1, b, sell, NAMES)['R_by_side']['1']['values']['live_reclaim'], 0)
        self.assertEqual(logic.choose(1, b, sell, NAMES)['A0']['side'], 0)

    def test_切替側chaseと下限なし(self):
        """
        機能: 元側でなく最終側の実BBO位置で1ATR等号を判定する。
        引数: self(Tests)。
        返り値: None。
        """
        buy, sell = vectors()
        for key in logic.R_KEYS:
            if key != 'm1_volume_relative_prior3':
                buy[INDEX[key]], sell[INDEX[key]] = -1, 1
        buy[INDEX[logic.CHASE]] = 999
        for value, expected in [(1, -1), (1.001, 0), (-999, -1), (None, 0)]:
            sell[INDEX[logic.CHASE]] = value
            row = logic.choose(1, buy, sell, NAMES)
            self.assertEqual(row['A0']['side'], -1)
            self.assertEqual(row['B0']['side'], expected)
            self.assertEqual(row['chase']['side'], -1)

    def test_売買鏡像と非改変(self):
        """
        機能: 同一物理価格反射に対応する買売配列交換で方向鏡像を検査する。
        引数: self(Tests)。
        返り値: None。
        """
        buy, sell = vectors();before = copy.deepcopy((buy, sell, NAMES))
        a = logic.choose(1, buy, sell, NAMES)
        b = logic.choose(-1, sell, buy, NAMES)
        for key in ('A0', 'B0'):
            self.assertEqual(a[key]['side'], -b[key]['side'])
            self.assertEqual(a[key]['action'], b[key]['action'])
        self.assertEqual(a['G'], b['G'])
        self.assertEqual((buy, sell, NAMES), before)
        a['G']['values']['m15_adx'] = 999
        self.assertEqual(buy[INDEX['m15_adx']], 26)
        self.assertEqual(logic.choose(0, buy, sell, NAMES)['A0']['side'], 0)
        self.assertEqual(list(inspect.signature(logic.choose).parameters), ['s', 'buy', 'sell', 'columns'])

    def test_競合と不正(self):
        """
        機能: 不可能な両R成立を防御待機しNaN/inf/派生overflowを区別する。
        引数: self(Tests)。
        返り値: None。
        """
        self.assertEqual(logic.branch(1, {'known': True, 'value': True}, {'1': {'known': True, 'value': True}, '-1': {'known': True, 'value': True}}), (0, 'recovery_conflict'))
        buy, sell = vectors();buy[INDEX['m15_adx']] = float('nan')
        self.assertEqual(logic.choose(1, buy, sell, NAMES)['A0']['side'], 0)
        buy[INDEX['m15_adx']] = float('inf')
        with self.assertRaises(ValueError):logic.choose(1, buy, sell, NAMES)
        buy, sell = vectors();buy[INDEX['m1_body_reclaim_atr5_to_side']] = 1e308;buy[INDEX['q0_last_minus_m1_close_atr5_to_side']] = 1e308
        with self.assertRaises(ValueError):logic.choose(1, buy, sell, NAMES)
        with self.assertRaises(ValueError):logic.choose(True, buy, sell, NAMES)

    def test_全q0識別を判断前検査(self):
        """
        機能: 最後のq0不一致でもchooseを1回も呼ばず拒否する。
        引数: self(Tests)。
        返り値: None。
        """
        buy, sell = vectors();meta = [dict(event_id=str(i), session='人工', contract='X', session_index=0, q0_time=i, q0_index=i, q0_line=i+1) for i in range(3)]
        rows = [{**r, 'decision': {'directions': {'P65': 1}}, 'model_id': 0, 'prediction': {'known_roles': ['値幅', '方向']}} for r in meta]
        features = SimpleNamespace(q0_meta=meta, buy_X=np.array([buy]*3), sell_X=np.array([sell]*3), columns=NAMES)
        source = {'成功': True, '試行': 151, '当場ラベルをモデルへ渡す': False, 'rows': rows}
        result = run.project(source, features, logic)
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0]['decision']['evidence'][0]['roles'], ['値幅', '方向'])
        self.assertEqual(result[0]['decision']['evidence'][1]['roles'], ['方向', '強度', '勢い', '構造', '量'])
        source['rows'][-1]['q0_line'] = 999
        def forbidden(*args):
            """
            機能: 全件検査前に呼ばれたら失敗する人工spy。
            引数: args(tuple)。
            返り値: None。常にAssertionError。
            """
            raise AssertionError('判断が先行')
        with self.assertRaises(AssertionError):run.project(source, features, SimpleNamespace(choose=forbidden))

    def test_相対CLIと継承metadata(self):
        """
        機能: 相対bookを絶対化し、G外維持の役割とoriginを分離する。
        引数: self(Tests)。
        返り値: None。
        """
        def stop_at_sha(path):
            """
            機能: 実入力を開かずCLIで絶対化済みか確認して中断する。
            引数: path(Path)。
            返り値: None。人工用RuntimeError。
            """
            self.assertTrue(path.is_absolute())
            raise RuntimeError('人工入力前停止')
        argv = ['選択する.py', '--book', '相対book.json', '--book-sha256', '0'*64,
                '--output-dir', '相対出力', '--execute-after-f0']
        with patch.object(run.sys, 'argv', argv), patch.object(run, 'sha', stop_at_sha):
            with self.assertRaisesRegex(RuntimeError, '人工入力前停止'):run.main()
        buy, sell = vectors();buy[INDEX['m15_adx']] = 25
        meta = dict(event_id='a', session='人工', contract='X', session_index=0, q0_time=1, q0_index=1, q0_line=2)
        source = {'成功': True, '試行': 151, '当場ラベルをモデルへ渡す': False,
                  'rows': [{**meta, 'model_id': 0, 'prediction': {'known_roles': ['値幅', '構造']}, 'decision': {'directions': {'P65': 1}}}]}
        features = SimpleNamespace(q0_meta=[meta], buy_X=np.array([buy]), sell_X=np.array([sell]), columns=NAMES)
        row = run.project(source, features, logic)[0]
        self.assertEqual(row['decision']['evidence'][0]['roles'], ['値幅', '構造'])
        self.assertEqual(set(row['decision']['evidence'][1]['roles']), {'値幅', '構造', '方向', '強度'})
        self.assertIn('G_false_maintain', row['decision']['evidence'][1]['origin_tags'])

    def test_C1優先と同q1抑止(self):
        """
        機能: 全q0後の結合で売格納C1を保護し同新q1を一度だけ数える。
        引数: self(Tests)。
        返り値: None。
        """
        helper = run.module(run.ROOT/'scripts/入口研究/固定特徴から可読条件を選択する.py', 'helper152artificial')
        sessions = [f'人工{i:02}' for i in range(73)]
        cases = [dict(case_id=str(i), session=sessions[i%73], contract='X', original_side=-1, buy_stream='reverse', sell_stream='original', c1_reused=True) for i in range(87)]
        cases.append(dict(case_id='new', session=sessions[0], contract='X', original_side=1, buy_stream='original', sell_stream='reverse', c1_reused=False))
        decisions, captures = [], []
        for i, (case, stream, status) in enumerate([('0', 'reverse', 'filled'), ('new', 'original', 'filled'), ('new', 'original', 'filled'), (None, None, 'expired')]):
            q = {'time': i, 'index': i, 'source_line': i+1}
            meta = dict(event_id=str(i), session=sessions[0], contract='X', q0_time=i, q0_index=i, q0_line=i+1)
            decision = {'directions': {p: 1 for p in ('P65','A0','B0','NB0')}, 'conflicts': {p: False for p in ('P65','A0','B0','NB0')}, 'evidence': [{'rule': p, 'signal_side': 1, 'order_side': 1} for p in ('P65','A0','B0')]}
            decisions.append({**meta, 'decision': decision})
            captures.append(dict(event_id=str(i), session=sessions[0], contract='X', q0=q, status=status, case_id=case, buy_stream=stream, sell_stream='original' if case=='0' else 'reverse'))
        before = copy.deepcopy((decisions, captures, cases))
        result = run.connect(decisions, {'rows': captures}, {'population148': {'cases': cases}}, sessions, helper)
        for p in ('U1','U0','U65'):
            self.assertEqual(len(result['政策'][p]), 88)
            self.assertEqual(next(r for r in result['政策'][p] if r['case_id']=='0')['side'], -1)
        self.assertEqual(len(result['政策']['B0']), 2)
        self.assertEqual(result['候補と取得']['B0']['duplicate_q1'], 1)
        self.assertEqual((decisions, captures, cases), before)

    def test_ZIP一memberとF1結合(self):
        """
        機能: 人工ZIPのq0だけを読み不正modelsは開かずF1期待SHAを強制する。
        引数: self(Tests)。
        返り値: None。
        """
        import hashlib
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp);path = root/'人工.zip';body = b'{"rows":[]}'
            with zipfile.ZipFile(path, 'w') as z:
                z.writestr('q0.json', body)
                for i in range(68):z.writestr(f'models/{i}.json', 'JSONではない'.encode('utf-8'))
            h = hashlib.sha256(body).hexdigest();f1 = root/'F1.json';f1.write_text(json.dumps({'ファイル': {'q0.json': h}}), encoding='utf-8')
            book = {'source151': {'zip': {'path': str(path), 'bytes': path.stat().st_size, 'sha256': run.sha(path)}, 'member': 'q0.json', 'member_bytes': len(body), 'member_sha256': h, 'f1': {'path': str(f1), 'sha256': run.sha(f1)}}}
            self.assertEqual(run.read_source(book), {'rows': []})
            book['source151']['member_sha256'] = '0'*64
            with self.assertRaises(AssertionError):run.read_source(book)


if __name__ == '__main__':
    unittest.main(verbosity=2)
