"""152は固定151のq0判断だけを継承し、全判断後に取得対応へ結ぶ。"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 入力を複写せず物理SHAを求める。
    引数: path(Path)。
    返り値: str。
    """
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def module(path: Path, name: str) -> object:
    """
    機能: mainを実行せず固定部品を私有importする。
    引数: path(Path)、name(str)。
    返り値: object。
    """
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    sys.modules[name] = result
    spec.loader.exec_module(result)
    return result


def save(path: Path, value: dict) -> None:
    """
    機能: UTF8の排他JSONを書き、既存の研究票を上書きしない。
    引数: path(Path)、value(dict)。
    返り値: None。
    """
    with path.open('x', encoding='utf-8') as f:
        json.dump(value, f, ensure_ascii=False, indent=2, allow_nan=False)
        f.write('\n')


def validate_book(book: dict) -> None:
    """
    機能: 固定主/比較・式の境界・入力scopeを数値読取前に照合する。
    引数: book(dict)。
    返り値: None。不一致はassertで停止。
    """
    assert book['trial'] == 152 and book['parent_trial'] == 148
    assert (book['primary'], book['comparison'], book['fixed_control']) == ('U1', 'U0', 'U65')
    assert (book['session_count'], book['feature_rows'], book['catalog_count'], book['legacy_count']) == (73, 35339, 100, 87)
    assert book['inherited_model_trained'] and not book['new_learning_or_prediction']
    assert book['formula'] == {
        'G': {'all_required_known': True, 'negative': ['m30_ema21_delta_to_side', 'm30_di_difference_to_side', 'm15_di_difference_to_side'], 'm15_adx_strict_above': 25, 'false': 'keep_P65', 'unknown': 'wait'},
        'R': {'all_required_known': True, 'strict_positive': ['m1_body_ratio_to_side', 'live_reclaim', 'm5_hist_delta_to_side', 'm5_rsi_delta_to_side'], 'live_reclaim': ['m1_body_reclaim_atr5_to_side', 'q0_last_minus_m1_close_atr5_to_side'], 'volume_column': 'm1_volume_relative_prior3', 'volume_at_least': 1, 'same_t_pair_single_true': True, 'unknown_or_neither_or_conflict': 'wait'},
        'B': {'column': 'q0_entry_minus_ema8_atr5_to_side', 'final_order_side': True, 'upper_inclusive': 1, 'lower': None, 'unknown': 'wait'}}
    assert book['linking'] == {'rules': ['P65', 'A0', 'B0'], 'union_id': 'NB0', 'union_rules': ['B0'], 'legacy_id': 'C1', 'main_id': 'U1', 'other_unions': {'U0': 'A0', 'U65': 'P65'}, 'c1_priority': True, 'all_q0_before_q1': True}
    assert set(book['features_source']) == {'features', 'fixed', 'captures', 'metadata'}


def read_source(book: dict) -> dict:
    """
    機能: F1期待SHAへ結合したZIPのq0 member一つだけを読む。
    引数: book(dict)。
    返り値: dictは保存151判断。models/選択対応memberは読まない。
    """
    source = book['source151']
    f1_path = ROOT / source['f1']['path']
    assert sha(f1_path) == source['f1']['sha256']
    f1 = json.loads(f1_path.read_bytes())
    declared = [h for p, h in f1['ファイル'].items() if p.replace('\\', '/') == source['member'] or p.replace('\\', '/').endswith('/' + source['member'])]
    assert declared == [source['member_sha256']]
    path = ROOT / source['zip']['path']
    before = (path.stat().st_size, path.stat().st_mtime_ns)
    assert before[0] == source['zip']['bytes'] and sha(path) == source['zip']['sha256']
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names)) == 69 and source['member'] in names
        assert archive.getinfo(source['member']).file_size == source['member_bytes']
        body = archive.read(source['member'])
    assert hashlib.sha256(body).hexdigest() == source['member_sha256']
    assert (path.stat().st_size, path.stat().st_mtime_ns) == before and sha(path) == source['zip']['sha256']
    return json.loads(body)


def project(source: dict, features: object, chooser: object) -> list:
    """
    機能: 全q0の識別/方向三値を先に検査し、その後に純判断を行う。
    引数: source(dict)、features(object)は特徴専用、chooser(object)。
    返り値: list[dict]は全q0判断。取得対応・教師は受け取らない。
    """
    assert source['成功'] and source['試行'] == 151 and not source['当場ラベルをモデルへ渡す']
    assert len(source['rows']) == len(features.q0_meta)
    assert len({r['event_id'] for r in source['rows']}) == len(source['rows'])
    for row, meta in zip(source['rows'], features.q0_meta):
        assert all(row[key] == meta[key] for key in ('event_id', 'session', 'contract', 'session_index', 'q0_time', 'q0_index', 'q0_line'))
        side = row['decision']['directions']['P65']
        assert type(side) is int and side in (-1, 0, 1)
        inherited_roles = row['prediction']['known_roles']
        assert isinstance(inherited_roles, list) and len(inherited_roles) == len(set(inherited_roles))
        assert set(inherited_roles) <= {'方向', '強度', '勢い', '構造', '値幅', '量'}
        assert not side or len(inherited_roles) >= 2
    out = []
    for i, (row, meta) in enumerate(zip(source['rows'], features.q0_meta)):
        s = row['decision']['directions']['P65']
        chosen = chooser.choose(s, features.buy_X[i].tolist(), features.sell_X[i].tolist(), list(features.columns))
        a, b = chosen['A0']['side'], chosen['B0']['side']
        directions = {'P65': s, 'A0': a, 'B0': b, 'NB0': b}
        conflicts = {k: chosen['A0']['reason'] == 'recovery_conflict' if k in ('A0', 'B0', 'NB0') else False for k in directions}
        evidence = []
        for k, t in directions.items():
            if not t or k == 'NB0':
                continue
            if k == 'P65':
                roles = list(row['prediction']['known_roles'])
                tags = ['inherited_P65']
            elif chosen['G']['value'] is True:
                roles = ['方向', '強度', '勢い', '構造', '量']
                tags = ['technical_recovery', 'keep_P65' if t == s else 'flip_to_background']
            else:
                roles = sorted(set(row['prediction']['known_roles']) | {'方向', '強度'})
                tags = ['inherited_P65', 'G_false_maintain']
            if k == 'B0':
                roles = sorted(set(roles) | {'構造'})
            evidence.append({'rule': k, 'signal_side': s, 'order_side': t, 'roles': roles,
                'origin_tags': tags, 'source_prediction_side': s, 'new_prediction_probability': None})
        out.append({**meta, 'source_model_id': row['model_id'], 'source_P65_side': s,
            'source_prediction_conditional': row['prediction'].get('conditional_forward'),
            'technical': chosen, 'decision': {'directions': directions, 'conflicts': conflicts, 'evidence': evidence}})
    return out


def connect(decisions: list, captures: dict, metadata: dict, sessions: list, helper: object) -> dict:
    """
    機能: 全判断完成後だけ取得へ結び、旧C1優先の3unionを作る。
    引数: decisions(list)、captures/metadata(dict)、sessions(list)、helper(object)。
    返り値: dictは8つの直接選択政策。金融側でC0/実逆を派生する。
    """
    link_book = {'rules': [{'id': p} for p in ('P65', 'A0', 'B0')], 'union_rules': ['B0'], 'union_id': 'NB0', 'legacy_id': 'C1', 'main_id': 'U1', 'session_count': len(sessions), 'legacy_count': 87}
    out = helper.connect(decisions, captures['rows'], metadata['population148']['cases'], sessions, link_book)
    baseline = {r['case_id']: r for r in out['政策']['C1']}
    overlaps = {'U1': out.pop('旧C1重複')}
    for union, policy in (('U0', 'A0'), ('U65', 'P65')):
        merged, collision = dict(baseline), []
        for row in out['政策'][policy]:
            key = row['case_id']
            if key in merged:
                collision.append({'case_id': key, 'legacy_side': merged[key]['side'], 'new_side': row['side'], 'opposite': merged[key]['side'] != row['side']})
            else:
                merged[key] = row
        out['政策'][union] = list(merged.values())
        overlaps[union] = collision
    out['旧C1重複'] = overlaps
    return out


def main() -> None:
    """
    機能: RootのF0実行許可後だけ固定q0選択と取得結合を保存する。
    引数: CLI book(Path)/book-sha256(str)/output-dir(Path)/execute-after-f0(bool)。
    返り値: None。教師射影/学習/推論/金融は呼ばない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--book', type=Path, required=True)
    parser.add_argument('--book-sha256', required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--execute-after-f0', action='store_true')
    args = parser.parse_args()
    args.book = args.book.resolve()
    args.output_dir = args.output_dir.resolve()
    assert args.execute_after_f0 and not args.output_dir.exists()
    assert sha(args.book) == args.book_sha256
    book = json.loads(args.book.read_bytes())
    validate_book(book)
    paths = {ROOT / p: h for p, h in book['sources'].items()}
    paths[args.book] = args.book_sha256
    for value in book['features_source'].values():
        paths[ROOT / value['path']] = value['sha256']
    for key in ('f1', 'book', 'zip'):
        row = book['source151'][key]
        paths[ROOT / row['path']] = row['sha256']
    catalog_path = ROOT / 'inputs/00148_全1分入口母集団/100特徴の列定義.json'
    paths[catalog_path] = book['catalog_definition_sha256']
    assert all(sha(p) == h for p, h in paths.items())
    before = {str(p): [p.stat().st_size, p.stat().st_mtime_ns] for p in paths}
    data = module(ROOT / 'work/151過去場判別/data151.py', 'feature_only151for152')
    helper = module(ROOT / 'scripts/入口研究/固定特徴から可読条件を選択する.py', 'link152')
    logic = module(HERE / 'logic152.py', 'logic152')
    refs = {k: data.FileRef(ROOT / v['path'], v['sha256'], v['decoded_sha256']) for k, v in book['features_source'].items()}
    features = data.load_feature_dataset(refs['features'], refs['fixed'])
    assert list(features.columns) == [r['name'] for r in json.loads(catalog_path.read_bytes())]
    decisions = project(read_source(book), features, logic)
    assert len(decisions) == book['feature_rows']
    args.output_dir.mkdir(parents=True)
    save(args.output_dir / 'q0の判断.json', {'成功': True, '試行': 152, '出生判断数': len(decisions),
        'q1結合前に全件判断': True, '新学習又は新推論': False, '継承予測は過去教師で学習': True, 'rows': decisions})
    # ----------------------------------------
    # 取得対応と旧C1未来表は全q0判断の保存後に初めて接続へ渡します。
    captures, _ = data.read_ref(refs['captures'])
    metadata, _ = data.read_ref(refs['metadata'])
    sessions = [r['session'] for r in features.scenes]
    assert captures['sessions'] == metadata['sessions'] == sessions
    result = connect(decisions, captures, metadata, sessions, helper)
    save(args.output_dir / '選択対応.json', {'成功': True, '試行': 152, 'book_sha256': args.book_sha256,
        'source151_q0_sha256': book['source151']['member_sha256'], '主政策': 'U1', **result})
    assert all(sha(p) == h for p, h in paths.items()) and before == {str(p): [p.stat().st_size, p.stat().st_mtime_ns] for p in paths}
    save(args.output_dir / '選択の確認.json', {'成功': True, '試行': 152, '新学習又は金融': False,
        '全q0判断後に取得結合': True, 'ZIP読取member': book['source151']['member'],
        'models又は旧選択member読取': False, '主比較は自然評価前採用': True,
        '入力': {str(p.relative_to(ROOT)).replace('\\','/'): h for p, h in paths.items()},
        '全入力前後SHA_stat同体': True, '政策別取得数': {k: len(v) for k, v in result['政策'].items()},
        '出力': {p.name: sha(p) for p in args.output_dir.iterdir() if p.is_file()}})
    print(json.dumps({'成功': True, '政策別取得数': {k: len(v) for k, v in result['政策'].items()}}, ensure_ascii=False))


if __name__ == '__main__':
    main()
