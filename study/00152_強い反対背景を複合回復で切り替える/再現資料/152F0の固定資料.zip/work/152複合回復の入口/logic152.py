"""152の保存P65方向を、当時100列だけで複合回復へ分岐する。"""
import math

G_KEYS = ('m30_ema21_delta_to_side', 'm30_di_difference_to_side', 'm15_di_difference_to_side', 'm15_adx')
R_KEYS = ('m1_body_ratio_to_side', 'm1_body_reclaim_atr5_to_side',
          'q0_last_minus_m1_close_atr5_to_side', 'm5_hist_delta_to_side',
          'm5_rsi_delta_to_side', 'm1_volume_relative_prior3')
CHASE = 'q0_entry_minus_ema8_atr5_to_side'


def number(value) -> float | None:
    """
    機能: None/NaNを未知として保持し、非有限や非数値を拒否する。
    引数: value(float|int|None)。
    返り値: float|None。boolと無限大はValueError。
    """
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError('数値型ではない')
    result = float(value)
    if math.isnan(result):
        return None
    if not math.isfinite(result):
        raise ValueError('無限大は入力不正')
    return result


def values(vector: list, index: dict, keys: tuple) -> dict:
    """
    機能: 入力を変更せず指定列だけの値と既知性を取り出す。
    引数: vector(list)、index(dict[str,int])、keys(tuple[str])。
    返り値: dict[str,float|None]。
    """
    return {key: number(vector[index[key]]) for key in keys}


def background(v: dict) -> dict:
    """
    機能: 全必要knownを要求して強い反対背景Gを判定する。
    引数: v(dict[str,float|None])はG4列。
    返り値: dictはknown/value/values。ADX=25又は方向0はfalse。
    """
    known = all(x is not None for x in v.values())
    flag = all(v[k] < 0 for k in G_KEYS[:3]) and v[G_KEYS[3]] > 25 if known else None
    return {'known': known, 'value': flag, 'values': dict(v)}


def recovery(v: dict) -> dict:
    """
    機能: 実体・現在生存回復・5分動力・同r量の全known確認を行う。
    引数: v(dict[str,float|None])はR6列。
    返り値: dictはknown/value/values。量=1を含み他のゼロはfalse。
    """
    out = dict(v)
    a, b = v[R_KEYS[1]], v[R_KEYS[2]]
    live = a + b if a is not None and b is not None else None
    if live is not None and not math.isfinite(live):
        raise ValueError('生存回復の派生overflow')
    out['live_reclaim'] = live
    known = all(x is not None for x in v.values())
    flag = (v[R_KEYS[0]] > 0 and live > 0 and v[R_KEYS[3]] > 0
            and v[R_KEYS[4]] > 0 and v[R_KEYS[5]] >= 1) if known else None
    return {'known': known, 'value': flag, 'values': out}


def branch(s: int, g: dict, r: dict) -> tuple:
    """
    機能: G外維持、未知待機、G内の両R確定片側だけを選ぶ。
    引数: s(int±1)、g(dict)、r(dict[str,dict])。
    返り値: tuple[int,str]はA0方向と理由。両trueは防御待機。
    """
    if not g['known']:
        return 0, 'background_unknown'
    if g['value'] is False:
        return s, 'outside_strong_opposition'
    same, opposite = r[str(s)], r[str(-s)]
    if not same['known'] or not opposite['known']:
        return 0, 'recovery_unknown'
    if same['value'] and opposite['value']:
        return 0, 'recovery_conflict'
    if same['value']:
        return s, 'countertrend_recovery_confirmed'
    if opposite['value']:
        return -s, 'background_direction_recovery_confirmed'
    return 0, 'neither_recovery'


def action(s: int, t: int, reason: str) -> dict:
    """
    機能: 元P65と区別して新方向/操作/理由を記述する。
    引数: s/t(int)、reason(str)。
    返り値: dict。flip側へ元予測確率を付与しない。
    """
    return {'side': t, 'action': 'wait' if t == 0 else 'keep' if t == s else 'flip', 'reason': reason}


def choose(s: int, buy: list, sell: list, columns: list) -> dict:
    """
    機能: 保存P65と買売100XだけでA0/B0を副作用なく判定する。
    引数: s(int−1/0/+1)、buy/sell(list[float|None])、columns(list[dict|str])。
    返り値: dictはsource_side/G/R_by_side/A0/B0/chase。q1/教師引数なし。
    """
    if type(s) is not int or s not in (-1, 0, 1):
        raise ValueError('元方向は三値int')
    names = [c['name'] if isinstance(c, dict) else c for c in columns]
    if len(names) != len(set(names)) or len(names) != 100 or len(buy) != 100 or len(sell) != 100:
        raise ValueError('100列scope差')
    index = {name: i for i, name in enumerate(names)}
    if not set((*G_KEYS, *R_KEYS, CHASE)) <= set(index):
        raise ValueError('必要列不足')
    out = {'source_side': s, 'G': None, 'R_by_side': {},
           'A0': action(s, 0, 'source_wait'), 'B0': action(s, 0, 'source_wait'), 'chase': None}
    if s == 0:
        return out
    vectors = {1: buy, -1: sell}
    g = background(values(vectors[s], index, G_KEYS))
    r = {str(t): recovery(values(vectors[t], index, R_KEYS)) for t in (1, -1)}
    t, reason = branch(s, g, r)
    out.update(G=g, R_by_side=r, A0=action(s, t, reason), B0=action(s, t, reason))
    if t:
        distance = number(vectors[t][index[CHASE]])
        passed = distance <= 1 if distance is not None else None
        out['chase'] = {'side': t, 'known': distance is not None, 'value': distance, 'pass': passed}
        if passed is not True:
            out['B0'] = action(s, 0, 'chase_unknown' if passed is None else 'chase_above_one_atr')
    return out
