# 152 複合回復による固定P65方向の確認

2026-11-12。Rootが[事前設計](../152複合回復の設計案/設計案.md)を自然採否・新金融の評価前に採用した。準備中/F0未固定。主はB＋旧C1のU1、比較はA＋旧C1のU0、固定対照はP65＋旧C1のU65。結果後に主を交換しない。152の学習・推論・Raw走査・観測再生は行わない。

## 純判断

`logic152.choose(s:int,buy:list,sell:list,columns:list)->dict` は、保存P65三値と同q0の買売100列だけを受け、入力を変更せずG/R/A0/B0/chaseを返す。None/NaNは未知、無限大/不正型/派生overflowは入力error。q1・教師・C1表は引数にない。

Gは元P65側30EMA21実増分<0・DI30差<0・DI15差<0・ADX15>25の全known AND。G falseは元P65維持、未知は待機。ADX=25/方向0はG false。R(t)はr実体比>0、q0生存回復>0、Hist5実増分>0、RSI5実増分>0、r量/先行3平均≥1の全known。生存回復は `t*(Last0−p.Open)/ATR5=x29+x92` でありr.Close単独回復やq1保持ではない。

G trueでは両側Rが確定し一方だけtrueの方向を選ぶ。R(s)だけなら維持、R(−s)だけなら切替、未知/両false/両trueは待機。厳密対称入力では両trueは原理上なく、防御的に矛盾を残す。Rの厳密正条件の等号0は不成立、量=1は成立。

B0はA0の最終方向tの `q0_entry_minus_ema8_atr5_to_side <=1` を追加。未知又は>1で待機、=1を含む。負側絶対乖離は制限しない。元sの列の先掛けやnegate補完で切替側を作らない。元P65予測65%を切替方向の確信度へ付与しない。

## 入力・運転API

`条件.json` は親151 ZIP物理SHA・q0 member SHA/サイズ・F1 SHA・親book SHA、共有148特徴/fixed/captures/metadataの物理/解凍SHA、100列定義SHA、再用data/helper SHAを固定する。ZIP69源のうちq0判断memberだけをreadし、models/旧選択memberは開かない。ZIPとF1のメタデータ確認だけを準備段階で行い、自然q0本文はまだ読んでいない。

RootがF0を固定し独立レビュー後にのみ実行する。

```powershell
& 'work/複合テクニカル学習環境/Scripts/python.exe' -X utf8 `
  'work/152複合回復の入口/選択する.py' `
  --book 'work/152複合回復の入口/条件.json' `
  --book-sha256 '<固定した条件SHA>' `
  --output-dir 'work/152複合回復の評価/入口選択' `
  --execute-after-f0
```

`data151.load_feature_dataset` の特徴専用射影だけを再用し、教師projector/モデルを呼ばない。全35,339q0のevent/session/contract/session_index/time/index/lineと元P65方向三値を全件検査してからchooseを始める。100列は固定辞書名と厳密一致させる。全q0の判断を保存した後にだけcaptures/metadataを読んでhelper.connectへ渡す。先着ラベル・q1価格や成否はq0判断に入らない。148のTTL/品質/最初正常BBO取得は変更しない。

## 出力schema

- `q0の判断.json`：`{成功,試行:152,出生判断数,q1結合前に全件判断,rows:[{event_id,session,contract,session_index,q0_time,q0_index,q0_line,source_model_id,source_P65_side,source_prediction_conditional,technical,decision}]}`。technicalは純chooseの全known/値/理由、decisionはdirections/conflicts/evidence。100列全体は再転記しない。
- `選択対応.json`：従来helperの`政策/候補と取得/旧C1重複/全73場`。直接政策はP65/A0/B0/NB0/C1/U1/U0/U65の8個、NB0はB0接続aliasで金融件数へ二重加算しない。
- `選択の確認.json`：全入力物理SHA、前後stat/SHA、ZIP member限定、出力SHA/取得件数。gzip/解凍の検査は固定data151のFileRef readerも継承する。

各参照は `{case_id,session,side,stream,event_id,feature_ref,q0_time,q0_index,q0_line,成立ID,evidence,origin}` の既存型。全q0判断後、同q1はC1優先・C1外は最初q0index→line→ID。後発aliasで方向を取り直さない。旧C1重複はU1/U0/U65別dict。金融側はC0 subset、RC1/RP65/RU1実逆を派生し11政策660比較を行う。Sourceでは実逆対照の予測を捏造しない。

## 人工と由来

`人工検査.py` は8主：known/等号、切替側chase、買売鏡像/非改変、競合/不正、全q0識別の先検査、相対CLI/継承metadata、旧C1優先/同q1抑止、ZIP一member/F1結合。役割は既存6分類を使い、P65の元known_rolesを保持する。G外維持は元役割＋実読取Gの方向/強度、G内は両Rから方向/強度/構造/勢い/量、Bの位置は構造とする。継承/維持/切替はorigin_tagsへ分離し、flipへ元モデル確率や役割を新モデルの根拠として転用しない。準備票はUTF8 strictの子Python、構文/複数行型付き関数コメント、源の前後同体を残す。自然採否/金融はRootが後で行う。

149のR3（低ADX端）、150のFD/RT（端突破失敗等）と部品は共通するが、152は固定P65の方向修正と両方向の現在回復を対象にする。再発見・一般則としない。Hist/RSIは同じ勢い役割で二重票にしない。全73既使用・151後着想・近接H60依存、金額は独立IFD代用で実口座収支ではない点を維持する。長い高安/VWAPは混ぜず別仮説。全73min1/平均概ね1h/同幅70は別及び共同評価で、待機で小群だけを残して達成扱いにしない。
