"""152は自然本文を開かず人工とコード/条件指紋を固定する。"""
from pathlib import Path
import ast
import hashlib
import json
import os
import subprocess
import sys
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def sha(path: Path) -> str:
    """
    機能: コードと固定ZIPの物理bytesを指紋化する。
    引数: path(Path)。
    返り値: str。
    """
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def main() -> None:
    """
    機能: 人工/コメント/ZIP中央目録だけを確認し自然未実行の票を作る。
    引数: なし。
    返り値: None。自然q0member/特徴/取得対応/金融本文は読まない。
    """
    own = sorted([*HERE.glob('*.py'), HERE/'条件.json', HERE/'README.md'])
    source = {str(p.relative_to(ROOT)).replace('\\','/'): sha(p) for p in own}
    for path in HERE.glob('*.py'):
        tree = ast.parse(path.read_text(encoding='utf-8'))
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                doc = ast.get_docstring(node)
                assert doc and '\n' in doc and all(k in doc for k in ('機能:', '引数:', '返り値:')), node.name
    env = dict(os.environ, PYTHONUTF8='1', PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1')
    test = subprocess.run([sys.executable, '-X', 'utf8', str(HERE/'人工検査.py')], capture_output=True,
        text=True, encoding='utf-8', errors='strict', env=env)
    assert test.returncode == 0 and '\ufffd' not in test.stdout + test.stderr
    import importlib.util
    spec = importlib.util.spec_from_file_location('run152prepare', HERE/'選択する.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    book = json.loads((HERE/'条件.json').read_bytes())
    module.validate_book(book)
    dependency = {p: h for p, h in book['sources'].items()}
    dependency[book['source151']['f1']['path']] = book['source151']['f1']['sha256']
    dependency[book['source151']['book']['path']] = book['source151']['book']['sha256']
    dependency[book['source151']['zip']['path']] = book['source151']['zip']['sha256']
    dependency['inputs/00148_全1分入口母集団/100特徴の列定義.json'] = book['catalog_definition_sha256']
    assert all(sha(ROOT/p) == h for p, h in dependency.items())
    f1 = json.loads((ROOT/book['source151']['f1']['path']).read_bytes())
    assert f1['ファイル'][book['source151']['member']] == book['source151']['member_sha256']
    with zipfile.ZipFile(ROOT/book['source151']['zip']['path']) as archive:
        info = archive.getinfo(book['source151']['member'])
        assert len(archive.infolist()) == 69 and info.file_size == book['source151']['member_bytes']
    guard = subprocess.run([sys.executable, '-X', 'utf8', str(HERE/'選択する.py'), '--book', '存在しない人工.json',
        '--book-sha256', '0'*64, '--output-dir', '存在しない人工出力'], capture_output=True,
        text=True, encoding='utf-8', errors='strict', env=env)
    assert guard.returncode != 0 and 'AssertionError' in guard.stderr and 'FileNotFoundError' not in guard.stderr
    assert all(sha(ROOT/p) == h for p, h in source.items())
    proof = {'成功': True, '試行': 152, '自然採否又は金融実行': False, '自然q0又は特徴本文読取': False,
        '教師射影又は学習又は推論': False, 'Raw又はCSV又は追加2場': False,
        'ZIPは中央目録と物理SHAのみ': True, '継承q0member期待SHA': book['source151']['member_sha256'],
        '人工主数': 8, '構文と複数行型付き関数コメント': True, 'UTF8_strict': True,
        '実行許可無しは入力I_O前拒否': True, '全自源前後SHA同体': True,
        '人工': {'終了値': test.returncode, '標準出力': test.stdout, '標準エラー': test.stderr},
        '源': source, '固定依存': dependency,
        '主U1比較U0対照U65は自然評価前採用': True,
        'CLI': '--book --book-sha256 --output-dir --execute-after-f0'}
    target = HERE/'準備の確認.json'
    with target.open('x', encoding='utf-8') as f:
        json.dump(proof, f, ensure_ascii=False, indent=2)
        f.write('\n')
    with (HERE/'停止.json').open('x', encoding='utf-8') as f:
        json.dump({'成功': True, '編集停止': True, '自然本文未読': True, '準備票SHA256': sha(target), '源': source}, f, ensure_ascii=False, indent=2)
        f.write('\n')
    print(json.dumps({'成功': True, '準備票SHA256': sha(target), '停止SHA256': sha(HERE/'停止.json')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
