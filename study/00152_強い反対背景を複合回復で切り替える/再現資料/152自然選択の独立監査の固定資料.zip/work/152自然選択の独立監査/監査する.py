"""152を保存特徴と151q0だけから別算術で再構成し、後段で取得を独立結合する。"""
from pathlib import Path
from collections import Counter
import argparse
import gzip
import hashlib
import json
import math
import zipfile

ROOT=Path(__file__).resolve().parents[2]
G_FIELDS=('m30_ema21_delta_to_side','m30_di_difference_to_side','m15_di_difference_to_side','m15_adx')
R_FIELDS=('m1_body_ratio_to_side','m1_body_reclaim_atr5_to_side','q0_last_minus_m1_close_atr5_to_side','m5_hist_delta_to_side','m5_rsi_delta_to_side','m1_volume_relative_prior3')
CHASE='q0_entry_minus_ema8_atr5_to_side'
META=('event_id','session','contract','session_index','q0_time','q0_index','q0_line')
ROLES={'方向','強度','勢い','構造','値幅','量'}


def sha(path: Path) -> str:
    """
    機能: 明示入力だけの物理指紋を固定bufferで求める。
    引数: path(Path)。返り値: str。
    """
    value=hashlib.sha256()
    with path.open('rb')as source:
        for block in iter(lambda:source.read(1<<20),b''):value.update(block)
    return value.hexdigest()


# ----------------------------------------
def read(path: Path,physical: str,decoded: str|None=None) -> object:
    """
    機能: SHA/全gzip CRCを検査し、解凍副本を書かずJSONを読む。
    引数: path(Path)、physical(str)、decoded(str|None)。返り値: object。
    """
    assert sha(path)==physical
    with (gzip.open(path,'rb')if path.suffix=='.gz'else path.open('rb'))as source:body=source.read()
    assert decoded is None or hashlib.sha256(body).hexdigest()==decoded
    return json.loads(body)


# ----------------------------------------
def known(value: object) -> float|None:
    """
    機能: 必要列の有限既知と未知をSourceを使わず判別する。
    引数: value(object)。返り値: float|None。bool/非有限は不正。
    """
    if value is None:return None
    assert type(value)in (int,float)
    value=float(value)
    if math.isnan(value):return None
    assert math.isfinite(value);return value


# ----------------------------------------
def operation(old: int,new: int,reason: str) -> dict:
    """
    機能: 方向と操作の表示を独立に作る。
    引数: old/new(int)、reason(str)。返り値: dict。
    """
    return {'side':new,'action':'wait'if new==0 else 'keep'if old==new else 'flip','reason':reason}


# ----------------------------------------
def technical(side: int,buy: list,sell: list,index: dict) -> dict:
    """
    機能: G/Rの既知性・派生和・両側状態・最終実側Bを別実装で評価する。
    引数: side(int)、buy/sell(list)、index(dict)。返り値: dictは全technical。
    """
    assert type(side)is int and side in (-1,0,1)
    output={'source_side':side,'G':None,'R_by_side':{},'A0':operation(side,0,'source_wait'),'B0':operation(side,0,'source_wait'),'chase':None}
    if side==0:return output
    vectors={1:buy,-1:sell}
    background={key:known(vectors[side][index[key]])for key in G_FIELDS}
    ready=all(value is not None for value in background.values())
    opposed=(max(background[key]for key in G_FIELDS[:3])<0 and background[G_FIELDS[3]]>25)if ready else None
    output['G']={'known':ready,'value':opposed,'values':background}
    recovery={}
    for target in (1,-1):
        values={key:known(vectors[target][index[key]])for key in R_FIELDS}
        a,b=values[R_FIELDS[1]],values[R_FIELDS[2]]
        live=None if a is None or b is None else math.fsum((a,b))
        assert live is None or math.isfinite(live)
        complete=all(value is not None for value in values.values())
        passed=(min(values[R_FIELDS[0]],live,values[R_FIELDS[3]],values[R_FIELDS[4]])>0 and values[R_FIELDS[5]]>=1)if complete else None
        values['live_reclaim']=live
        recovery[target]={'known':complete,'value':passed,'values':values}
    output['R_by_side']={str(target):recovery[target]for target in (1,-1)}
    target=0;reason='background_unknown'
    if ready and opposed is False:target=side;reason='outside_strong_opposition'
    elif ready:
        current,other=recovery[side],recovery[-side]
        if not current['known']or not other['known']:reason='recovery_unknown'
        elif current['value']and other['value']:reason='recovery_conflict'
        elif current['value']:target=side;reason='countertrend_recovery_confirmed'
        elif other['value']:target=-side;reason='background_direction_recovery_confirmed'
        else:reason='neither_recovery'
    output['A0']=operation(side,target,reason);output['B0']=operation(side,target,reason)
    if target:
        distance=known(vectors[target][index[CHASE]])
        passed=None if distance is None else distance<=1
        output['chase']={'side':target,'known':distance is not None,'value':distance,'pass':passed}
        if passed is not True:output['B0']=operation(side,0,'chase_unknown'if passed is None else 'chase_above_one_atr')
    return output


# ----------------------------------------
def decision(source: dict,meta: dict,buy: list,sell: list,index: dict) -> dict:
    """
    機能: 元予測・技術方向・role/originを混ぜず全判断1行を再構成する。
    引数: source/meta(dict)、buy/sell(list)、index(dict)。返り値: dict。
    """
    side=source['decision']['directions']['P65'];tech=technical(side,buy,sell,index)
    a,b=tech['A0']['side'],tech['B0']['side'];directions={'P65':side,'A0':a,'B0':b,'NB0':b};evidence=[]
    for name,target in directions.items():
        if not target or name=='NB0':continue
        if name=='P65':roles=list(source['prediction']['known_roles']);tags=['inherited_P65']
        elif tech['G']['value']is True:roles=['方向','強度','勢い','構造','量'];tags=['technical_recovery','keep_P65'if target==side else 'flip_to_background']
        else:roles=sorted(set(source['prediction']['known_roles'])|{'方向','強度'});tags=['inherited_P65','G_false_maintain']
        if name=='B0':roles=sorted(set(roles)|{'構造'})
        evidence.append({'rule':name,'signal_side':side,'order_side':target,'roles':roles,'origin_tags':tags,'source_prediction_side':side,'new_prediction_probability':None})
    return {**meta,'source_model_id':source['model_id'],'source_P65_side':side,
        'source_prediction_conditional':source['prediction'].get('conditional_forward'),'technical':tech,
        'decision':{'directions':directions,'conflicts':{name:(tech['A0']['reason']=='recovery_conflict'if name!='P65'else False)for name in directions},'evidence':evidence}}


# ----------------------------------------
def equal(expected: object,actual: object,path: str='') -> int:
    """
    機能: 全キー/配列順/型付き末端を差分path付きで照合する。
    引数: expected/actual(object)、path(str)。返り値: intは末端比較数。
    """
    if isinstance(expected,dict):
        assert isinstance(actual,dict)and set(expected)==set(actual),path
        return sum(equal(v,actual[k],path+'/'+str(k))for k,v in expected.items())
    if isinstance(expected,list):
        assert isinstance(actual,list)and len(expected)==len(actual),path
        return sum(equal(v,actual[i],path+'/'+str(i))for i,v in enumerate(expected))
    if expected is None:assert actual is None,path
    elif isinstance(expected,bool):assert type(actual)is bool and actual==expected,path
    elif type(expected)in (int,float):assert type(actual)in (int,float)and math.isfinite(actual)and actual==expected,(path,expected,actual)
    else:assert type(actual)is type(expected)and actual==expected,(path,expected,actual)
    return 1


# ----------------------------------------
def join(rows: list,captures: dict,metadata: dict,sessions: list) -> dict:
    """
    機能: 再構成済み判断だけを取得表へ結び、canonicalとC1優先を独立に作る。
    引数: rows(list)、captures/metadata(dict)、sessions(list)。返り値: dictは全選択。
    """
    caps={row['event_id']:row for row in captures['rows']};descriptors=metadata['population148']['cases'];cases={row['case_id']:row for row in descriptors}
    assert len(caps)==len(rows)==len({row['event_id']for row in rows})and len(cases)==len(descriptors)
    assert set(caps)=={row['event_id']for row in rows}and captures['sessions']==metadata['sessions']==sessions
    order={sid:i for i,sid in enumerate(sessions)};names=('P65','A0','B0','NB0');counts={name:Counter()for name in names};first={name:{}for name in names}
    for row in sorted(rows,key=lambda v:(order[v['session']],v['q0_index'],v['q0_line'],v['event_id'])):
        cap=caps[row['event_id']]
        assert cap['session']==row['session']and cap['contract']==row['contract']
        assert [cap['q0'][key]for key in ('time','index','source_line')]==[row[key]for key in ('q0_time','q0_index','q0_line')]
        for name in names:
            if row['decision']['conflicts'][name]:counts[name]['conflict_wait']+=1
            side=row['decision']['directions'][name]
            if side==0:continue
            counts[name]['born']+=1;counts[name][cap['status']]+=1
            if cap['status']!='filled':continue
            key=cap['case_id'];desc=cases[key]
            assert (desc['session'],desc['contract'])==(row['session'],row['contract'])
            stream_key='buy_stream'if side==1 else 'sell_stream';assert cap[stream_key]==desc[stream_key]
            if key in first[name]:counts[name]['duplicate_q1']+=1;continue
            hits=[hit for hit in row['decision']['evidence']if hit['order_side']==side and hit['rule']==('B0'if name=='NB0'else name)]
            first[name][key]={'case_id':key,'session':row['session'],'side':side,'stream':cap[stream_key],
                'event_id':row['event_id'],'feature_ref':row['event_id'],'q0_time':row['q0_time'],'q0_index':row['q0_index'],'q0_line':row['q0_line'],
                '成立ID':sorted({hit['rule']for hit in hits}),'evidence':hits,'origin':name}
    legacy={row['case_id']:{'case_id':row['case_id'],'session':row['session'],'side':row['original_side'],'stream':'original','event_id':None,'feature_ref':None,'origin':'C1'}for row in descriptors if row['c1_reused']}
    assert len(legacy)==87
    policies={name:list(items.values())for name,items in first.items()};policies['C1']=list(legacy.values());collisions={}
    for union,new in [('U1','NB0'),('U0','A0'),('U65','P65')]:
        output=dict(legacy);overlap=[]
        for key,row in first[new].items():
            if key in legacy:overlap.append({'case_id':key,'legacy_side':legacy[key]['side'],'new_side':row['side'],'opposite':legacy[key]['side']!=row['side']})
            else:output[key]=row
        policies[union]=list(output.values());collisions[union]=overlap
    return {'政策':policies,'候補と取得':{name:dict(value)for name,value in counts.items()},'旧C1重複':collisions,'全73場':sessions,'選択時の金融ラベル利用':False}


# ----------------------------------------
def main() -> None:
    """
    機能: Root F1通知後だけ全自然判断を独立再構成し、後段で取得を照合する。
    引数: CLI --f0/--f1/--book/--run-dir/--output-dir(Path)と各sha256(str)。
    返り値: None。Source/金融/教師/Rawをimport又は読取しない。
    """
    parser=argparse.ArgumentParser()
    for name in ('f0','f1','book','run-dir','output-dir'):parser.add_argument('--'+name,type=Path,required=True)
    for name in ('f0-sha256','f1-sha256','book-sha256'):parser.add_argument('--'+name,required=True)
    args=parser.parse_args();f0=read(args.f0,args.f0_sha256);f1=read(args.f1,args.f1_sha256);book=read(args.book,args.book_sha256)
    assert f0['試行']==f1['試行']==book['trial']==152 and f1['前段階SHA256']==args.f0_sha256
    files={**f0['ファイル'],**f1['ファイル']};assert all(f1['ファイル'].get(name)==digest for name,digest in f0['ファイル'].items())
    assert all(sha(ROOT/name)==digest for name,digest in files.items())
    before={name:(sha(ROOT/name),(ROOT/name).stat().st_size,(ROOT/name).stat().st_mtime_ns)for name in files}
    refs=book['features_source'];features=read(ROOT/refs['features']['path'],refs['features']['sha256'],refs['features']['decoded_sha256'])
    source_ref=book['source151'];zip_path=ROOT/source_ref['zip']['path'];assert sha(zip_path)==source_ref['zip']['sha256']
    source_f1=read(ROOT/source_ref['f1']['path'],source_ref['f1']['sha256'])
    assert source_f1['ファイル'][source_ref['member']]==source_ref['member_sha256']
    with zipfile.ZipFile(zip_path)as archive:body=archive.read(source_ref['member'])
    assert hashlib.sha256(body).hexdigest()==source_ref['member_sha256'];source=json.loads(body);del body
    paths={name:args.run_dir/name for name in ('q0の判断.json','選択対応.json','選択の確認.json')}
    actual=read(paths['q0の判断.json'],files[paths['q0の判断.json'].resolve().relative_to(ROOT).as_posix()])
    assert actual['成功']and actual['試行']==152 and actual['出生判断数']==35339 and actual['q1結合前に全件判断']and not actual['新学習又は新推論']
    assert source['成功']and source['試行']==151 and not source['当場ラベルをモデルへ渡す']
    assert features['success']and features['trial']==148 and not features['financial_labels_used']
    columns=[item['name']for item in features['catalog']];assert len(columns)==100 and columns==sorted(set(columns))
    index={name:i for i,name in enumerate(columns)};sessions=features['sessions'];assert len(sessions)==73
    assert len(features['rows'])==len(source['rows'])==len(actual['rows'])==35339
    reconstructed=[];cells=0;reasons=Counter();digest=hashlib.sha256()
    for pos,(fr,old,now)in enumerate(zip(features['rows'],source['rows'],actual['rows'])):
        q=fr['metadata']['q0'];meta={'event_id':fr['event_id'],'session':fr['session'],'contract':fr['contract'],
            'session_index':sessions.index(fr['session']),'q0_time':q['time'],'q0_index':q['index'],'q0_line':q['source_line']}
        assert all(old[key]==meta[key]for key in META)
        side=old['decision']['directions']['P65'];assert type(side)is int and side in (-1,0,1)
        roles=old['prediction']['known_roles'];assert isinstance(roles,list)and len(roles)==len(set(roles))and set(roles)<=ROLES and(not side or len(roles)>=2)
        assert fr['buy']['side']==1 and fr['sell']['side']==-1 and len(fr['buy']['x'])==len(fr['sell']['x'])==100
        row=decision(old,meta,fr['buy']['x'],fr['sell']['x'],index);cells+=equal(row,now,'q0/'+str(pos))
        digest.update(json.dumps(row,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode());digest.update(b'\n')
        reasons['A0/'+row['technical']['A0']['reason']]+=1;reasons['B0/'+row['technical']['B0']['reason']]+=1
        reconstructed.append({**meta,'decision':row['decision']})
    # ----------------------------------------
    # 技術再構成と照合を終えてから、取得対応・metadataを初めて構造として読みます。
    captures=read(ROOT/refs['captures']['path'],refs['captures']['sha256'],refs['captures']['decoded_sha256'])
    metadata=read(ROOT/refs['metadata']['path'],refs['metadata']['sha256'],refs['metadata']['decoded_sha256'])
    result=join(reconstructed,captures,metadata,sessions)
    expected={'成功':True,'試行':152,'book_sha256':args.book_sha256,'source151_q0_sha256':source_ref['member_sha256'],'主政策':'U1',**result}
    selected=read(paths['選択対応.json'],files[paths['選択対応.json'].resolve().relative_to(ROOT).as_posix()]);cells+=equal(expected,selected,'選択対応')
    check=read(paths['選択の確認.json'],files[paths['選択の確認.json'].resolve().relative_to(ROOT).as_posix()])
    counts={policy:len(rows)for policy,rows in result['政策'].items()};assert check['成功']and check['全q0判断後に取得結合']and check['全入力前後SHA_stat同体']
    assert check['政策別取得数']==counts and check['ZIP読取member']==source_ref['member']and not check['models又は旧選択member読取']
    assert before=={name:(sha(ROOT/name),(ROOT/name).stat().st_size,(ROOT/name).stat().st_mtime_ns)for name in files}
    proof={'成功':True,'編集停止':True,'試行':152,'F0_SHA256':args.f0_sha256,'F1_SHA256':args.f1_sha256,'bookSHA256':args.book_sha256,
        '全q0再構成数':len(reconstructed),'末端比較数':cells,'全G_R_B_未知_役割_origin_元予測情報一致':True,
        '全政策所属とcanonical_C1優先一致':True,'政策別取得数':counts,'候補と取得':result['候補と取得'],
        '全q0再構成の正規JSON行SHA256':digest.hexdigest(),'理由分布':dict(reasons),'固定源前後同体':{name:value[0]for name,value in before.items()},
        '順序':'純G/R/B全35339再構成後にcaptures/metaを読んで独立結合。',
        '152新Source_choose_project_connect_import':False,'151ZIP読取':'固定q0 memberだけ。モデル/旧選択memberは読まない。',
        '新しい選び直し/再学習/金融観測/教師/Raw/追加2場':False,
        '限界':'148特徴と取得代用を固定入力として用いる。100列算術・実受信・未保存Raw firstnormal・将来成績は再検証しない。'}
    args.output_dir.mkdir(parents=True,exist_ok=True);target=args.output_dir/'監査の確認.json'
    with target.open('x',encoding='utf-8',newline='\n')as output:json.dump(proof,output,ensure_ascii=False,indent=2);output.write('\n')
    print(json.dumps({'成功':True,'全q0':len(reconstructed),'末端比較':cells,'政策別取得数':counts,'SHA256':sha(target)},ensure_ascii=False))


if __name__=='__main__':main()
