"""152自然監査器の別算術・結合を人工だけで先確認する。"""
from pathlib import Path
import hashlib
import importlib.util
import itertools
import json
import math
import 監査する as audit


def main() -> None:
    """
    機能: 既存独立oracleとの全状態比較とC1/canonical人工を実行する。
    引数: なし。自然q0・採否・金融・Root新Sourceは開かない。
    返り値: None。確認票だけ新規保存する。
    """
    own=Path(__file__).resolve().parent;root=own.parents[1]
    path=root/'work/152純判定と運転の独立準備/独立人工.py'
    spec=importlib.util.spec_from_file_location('旧独立oracle',path);prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)
    names=[*audit.G_FIELDS,*audit.R_FIELDS,audit.CHASE]+[f'人工列{i}'for i in range(89)];assert len(names)==100
    index={name:i for i,name in enumerate(names)};count=0

    def vector(g,yes):
        """
        機能: 必要11列だけの人工ベクトルを作る。
        引数: g(tuple)、yes(bool)。返り値: list。
        """
        values=[None]*100
        for key,value in zip(audit.G_FIELDS,g):values[index[key]]=value
        for key,value in zip(audit.R_FIELDS,(.5,.3,.2,.1,.1,1)if yes else(-.5,-.3,-.2,-.1,-.1,1)):values[index[key]]=value
        values[index[audit.CHASE]]=.5;return values

    for side in (1,-1):
        for g in itertools.product((-1,0,1,None),repeat=3):
            for adx in (25,math.nextafter(25,math.inf),None,float('nan')):
                buy=vector((*g,adx),True);sell=vector((1,2,3,30),False)
                value=audit.technical(side,buy,sell,index)
                assert prior.reduced(value)==prior.oracle(side,buy,sell,index);count+=1
    sessions=[f'人工場{i:02d}'for i in range(73)]
    descriptors=[{'case_id':f'旧{i}','session':sessions[i%73],'contract':'人工限月','original_side':-1,
        'buy_stream':'reverse','sell_stream':'original','c1_reused':True}for i in range(87)]
    descriptors.append({'case_id':'新','session':sessions[0],'contract':'人工限月','original_side':1,'buy_stream':'original','sell_stream':'reverse','c1_reused':False})
    rows=[];caps=[]
    for i,(key,status)in enumerate([('旧0','filled'),('新','filled'),('新','filled'),(None,'quality_lost')]):
        meta={'event_id':f'E{i}','session':sessions[0],'contract':'人工限月','session_index':0,'q0_time':100+i,'q0_index':i,'q0_line':i+1}
        source={'model_id':8,'prediction':{'known_roles':['方向','構造'],'conditional_forward':.66},'decision':{'directions':{'P65':1}}}
        row=audit.decision(source,meta,vector((-1,-2,-3,30),False),vector((1,2,3,30),True),index);rows.append(row)
        caps.append({'event_id':meta['event_id'],'session':sessions[0],'contract':'人工限月','q0':{'time':100+i,'index':i,'source_line':i+1},
            'status':status,'case_id':key,'buy_stream':'reverse'if key=='旧0'else'original','sell_stream':'original'if key=='旧0'else'reverse'})
    value=audit.join(rows,{'rows':caps,'sessions':sessions},{'population148':{'cases':descriptors},'sessions':sessions},sessions)
    assert all(len(value['政策'][p])==88 for p in ('U1','U0','U65'))
    assert next(r for r in value['政策']['U1']if r['case_id']=='旧0')['side']==-1
    assert next(r for r in value['政策']['U1']if r['case_id']=='新')['event_id']=='E1'
    assert next(r for r in value['政策']['U1']if r['case_id']=='新')['origin']=='NB0'
    assert value['旧C1重複']['U65'][0]['opposite']is True
    assert value['候補と取得']['B0']['duplicate_q1']==1 and value['候補と取得']['B0']['quality_lost']==1
    rejected=False
    try:audit.equal({'値':True},{'値':1})
    except AssertionError:rejected=True
    assert rejected
    proof={'成功':True,'区分':'独立算術器と結合の人工準備','純式比較':count,'canonical/C1優先/反対alias/取消計数':True,
        '既存独立575oracleを再用_作者計算は不使用':True,'Source':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in(own/'監査する.py',Path(__file__))},
        '自然152/148_151q0/金融/Raw読取':False}
    target=own/'準備の確認.json'
    with target.open('x',encoding='utf-8',newline='\n')as output:json.dump(proof,output,ensure_ascii=False,indent=2);output.write('\n')
    print('人工準備成功 '+hashlib.sha256(target.read_bytes()).hexdigest())


if __name__=='__main__':main()
