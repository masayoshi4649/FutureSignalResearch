# 152 純判定と運転の独立準備確認

確認日：2026-11-12。Sourceは変更せず、静的確認と自然値を含まない人工だけで検査した。自然148/151q0本文・152採否件数・金融・Raw・追加2場は未読。採用bookは7805b17d…、判定e9d7bff7…、運転e430e730…へ束縛する。

Gは元P65側で3方向すべて負かつADX15>25、必要4値すべてknown。Rは各実側について実体>0、現在生存回復=(r.Close−p.Open)/ATR5+(Last−r.Close)/ATR5>0、Hist5/RSI5増分>0、同r量/先行3平均≥1、必要6値すべてknown。G外は元側維持、G未知は待機、G内では両側Rが確定し片側だけtrueの場合だけその側を選ぶ。未知/両false/両trueは待機。Bは最終注文側の実Ask/Bid由来EMA8距離≤1で、上限等号可・下限なし。flip前の側を参照しない。

独立oracleはSourceの計算・定数をimportせず、別定義の必要列と標準演算で575人工を比較した。未知があっても偽があるからknownにしない点、ADX25/量1/liveゼロ、bool/無限大/文字型と三値方向、mirror側交換、入力不変を確認した。

運転は全q0の7識別meta・P65三値・6role scopeを先に検査する。最後の行が不正な人工でも先のchooseが呼ばれないことを確認。元予測値はsource_prediction_conditional/source_prediction_sideとして残し、flip後の新確率はNone。6技術役割を超える架空roleを受け入れない。

ZIP読取人工は69memberの自作ZIPで、固定q0 memberだけがreadされたこと、F1物理/member SHA不一致が本文読取前に止まることをspyで確認した。モデルや実自然のq0は開いていない。mainの順序確認は私有I/Oで2行へ縮約し、bookの実数scope検査は別途現bookに対して実行した。mainのこの人工だけvalidate_bookを私有置換し、実際の判定/project/save/接続を動かしたため、35,339行の自然実行検査ではない。凍結common link2f46自体の再実装はせず、呼出bookと返り値によるU1/U0/U65の旧C1優先を検査した。

確認した順序は特徴専用load→固定151q0→全chooseとq0排他保存→capture構造読取→meta構造読取→接続。入力の物理SHA/statを先に読むことは、capture/metaをchooseへ渡すことと区別する。相対book/outputはresolveで絶対化され、Root固定票の指紋を持つ実自然入力へ同じ式を適用する。

## 純dict APIの潜在強化点（自然の重大差ではない）

1. projectのmeta一致はPython == なのでsession_index=Falseが0と同値になる人工は通る。採用F1/ZIPは物理SHAで束縛済みで、この人工が実入力にあることを示さない。P65方向自体はtype intの三値検査でboolを拒否する。
2. read_sourceはbook指定の一memberだけを読む。bookと人工F1を共に変更すればmodel名memberも指定でき、関数内のq0 literal whitelistではない。採用7805bookはq0正本を指しRoot F0で固定するため、現自然の未来情報利用やブロッカーとしない。

Rootの指示どおりこの2点を実自然の条件不一致と混ぜず、Sourceを変更していない。独立人工で得た取得数は人工fixture内だけであり、新152の自然件数を計数していない。証跡は独立人工の確認.json、最終指紋は準備の確認.jsonを参照する。
