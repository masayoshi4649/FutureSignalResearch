"""自然入力なしで152複合回復参照・660比較・F1/F2・未知累計を検査する。"""
from pathlib import Path
import copy
import importlib.util
import json
import tempfile
import unittest

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def module(path: Path,name: str):
    """
    機能: mainを実行せず停止済み人工部品を読む。
    引数: path(Path)、name(str)。返り値: ModuleType。
    """
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value


m=module(HERE/'集計する.py','aggregate152test')
old=module(ROOT/'work/151過去場判別の金融集計/人工検査.py','fixture151for152')


def fixture(empty: bool=False) -> tuple:
    """
    機能: 旧87を保護しP65/A/Bの直接参照と3unionを人工で作る。
    引数: empty(bool)はA/Bだけ空。返り値: tuple。
    """
    records,sessions,fixed,prior,meta,parent,arith,members=old.fixture()
    legacy=copy.deepcopy(prior['政策']['C1']);policies={'C1':legacy};overlaps={}
    for policy,n in [('P65',3),('A0',0 if empty else 2),('B0',0 if empty else 1)]:
        rows=[]
        for r in prior['政策']['P65'][:n]:
            row=copy.deepcopy(r);row['origin']=policy;row['成立ID']=[policy];row['evidence']=[{'rule':policy}];rows.append(row)
        policies[policy]=rows
    for union,new in [('U65','P65'),('U0','A0'),('U1','B0')]:
        policies[union]=list(reversed(copy.deepcopy(legacy)))
        base={r['case_id']:r for r in legacy}
        overlaps[union]=[{'case_id':r['case_id'],'opposite':r['side']!=base[r['case_id']]['side']}for r in policies[new]]
    policies['NB0']=copy.deepcopy(policies['B0'])
    selection={'成功':True,'試行':152,'選択時の金融ラベル利用':False,'政策':policies,'旧C1重複':overlaps,'候補と取得':{p:{'born':len(r)}for p,r in policies.items()},'全73場':sessions}
    parent.POLICIES=m.POLICIES;arith.POLICIES=m.POLICIES;arith.selected=m.selected
    return m.bind_choices(records,members,selection,False),sessions,fixed,selection,meta,parent,arith,members


class Tests(unittest.TestCase):
    """自然なし6主群。"""

    def test_旧151全統計と改変拒否(self) -> None:
        """
        機能: 旧P65/U65の120条件を全キー照合し差1個でも拒否する。
        引数: self(Tests)。返り値: None。
        """
        records,sessions,fixed,_,_,parent,arith,_=fixture()
        values,*_=parent.calculate(records,sessions,fixed['scenes'],arith)
        prior={'集計':copy.deepcopy(values)}
        proof=m.prior151_check(values,prior);self.assertEqual(proof['条件数'],120);self.assertEqual(proof['統計セル数'],2880)
        prior['集計']['validation']['U65']['Last']['1800']['25']['entries']+=1
        with self.assertRaises(AssertionError):m.prior151_check(values,prior)

    def test_660三表とC1優先と反転(self) -> None:
        """
        機能: 11政策の660比較/時刻順/逆参照元metadataを確認する。
        引数: self(Tests)。返り値: None。
        """
        records,sessions,fixed,selection,meta,parent,arith,_=fixture();values,p,f,goals,overlaps=parent.calculate(records,sessions,fixed['scenes'],arith);tables,curves=m.tables(records,sessions,values,p,f,overlaps,selection,meta,parent,arith)
        self.assertEqual([(len(t['rows']),len(t['headers']))for t in tables],[(660,34),(87,47),(73,63)]);self.assertEqual(tables[1]['rows'][0][4],'人工00/0')
        record=records['人工00/0'];self.assertEqual(record['choices']['B0']['side'],1);self.assertEqual(record['choices']['U1']['side'],-1);self.assertEqual(record['choices']['RP65']['side'],-1)
        self.assertEqual(record['choices']['RP65']['source_selected_side'],1);self.assertTrue(record['choices']['RP65']['counterfactual_reverse']);self.assertEqual(record['choices']['RP65']['reverse_of_policy'],'P65')
        self.assertEqual(curves['U1'][sessions[-1]]['累計既知差引'],values['all']['U1']['BBO']['3600']['125']['ifd_net5_sum'])
        self.assertNotIn('NB0',values['all'])

    def test_空P群とLast金額null(self) -> None:
        """
        機能: 新取得0でも全73と旧87を保ち率未定を0%へ変えない。
        引数: self(Tests)。返り値: None。
        """
        records,sessions,fixed,selection,meta,parent,arith,_=fixture(True);values,p,f,goals,overlaps=parent.calculate(records,sessions,fixed['scenes'],arith);tables,_=m.tables(records,sessions,values,p,f,overlaps,selection,meta,parent,arith)
        self.assertEqual(values['all']['B0']['BBO']['3600']['125']['entries'],0);self.assertIsNone(values['all']['B0']['BBO']['3600']['125']['resolved_rate']);self.assertEqual(p['all']['B0']['取得場数'],0);self.assertEqual(len(tables[2]['rows']),73)
        self.assertIsNone(values['all']['U1']['Last']['3600']['125']['ifd_net5_sum'])

    def test_C1優先破壊を拒否(self) -> None:
        """
        機能: 旧取得と重なる新側でU1を上書きした票を拒否する。
        引数: self(Tests)。返り値: None。
        """
        records,_,_,selection,_,_,_,members=fixture();legacy_id=selection['政策']['B0'][0]['case_id']
        for row in selection['政策']['U1']:
            if row['case_id']==legacy_id:row['side']=-row['side'];row['stream']='reverse'
        with self.assertRaises(AssertionError):m.bind_choices(records,members,selection,False)

    def test_別F1F2の固定結合(self) -> None:
        """
        機能: 小固定票でF1/F2の入替・同票流用を拒否する。
        引数: self(Tests)。返り値: None。
        """
        with tempfile.TemporaryDirectory()as folder:
            root=Path(folder);selection=root/'選択.json';selection.write_text('{}',encoding='utf-8');h=m.sha(selection);f1=root/'F1.json';f1.write_text(json.dumps({'ファイル':{str(selection):h}}),encoding='utf-8');a=m.sha(f1);f2=root/'F2.json';f2.write_text(json.dumps({'ファイル':{str(selection):h,str(f1):a}}),encoding='utf-8');b=m.sha(f2)
            m.verify_freezes(f1,a,f2,b,selection,h)
            with self.assertRaises(AssertionError):m.verify_freezes(f1,a,f1,a,selection,h)
            with self.assertRaises((AssertionError,KeyError)):m.verify_freezes(f2,b,f1,a,selection,h)

    def test_既知touchと費用未知累計(self) -> None:
        """
        機能: H不足既知touch清算・C5=1077円・未知のnull不可逆を維持する。
        引数: self(Tests)。返り値: None。
        """
        records,_,_,_,_,_,arith,_=fixture();record=records['人工00/0'];c=m.selected(record,'U1','BBO');c['outcomes'][1]['status']='censored';c['outcomes'][1]['endpoint']=None;stats=arith.stats([record],'U1','BBO',3600,125);self.assertEqual((stats['complete'],stats['ifd_known']),(0,1));self.assertEqual(stats['ifd_net5_sum'],12500-1077)
        a=m.cumulative_step({}, {'ifd_net5_profit':100,'ifd_net5_loss':0,'ifd_unknown':1});b=m.cumulative_step(a,{'ifd_net5_profit':200,'ifd_net5_loss':20,'ifd_unknown':0});self.assertEqual(b['累計既知差引'],280);self.assertIsNone(b['累計全件確定差引'])


if __name__=='__main__':
    unittest.main(verbosity=2)
