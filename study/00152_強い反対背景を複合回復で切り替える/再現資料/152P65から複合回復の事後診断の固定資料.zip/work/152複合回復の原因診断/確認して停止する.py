"""152の事後診断を人工/指紋/分母整合で停止する。"""
from pathlib import Path
import ast
import hashlib
import json
import os
import subprocess
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def sha(path: Path) -> str:
    """
    機能: 入出力の物理bytesを複写せず指紋化する。
    引数: path(Path)。
    返り値: str。
    """
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()


def main() -> None:
    """
    機能: 既存成立群の分母・元正本一致・人工を照合し停止票を保存する。
    引数: なし。
    返り値: None。新採否評価/金融再走査を実行しない。
    """
    proof=json.loads((HERE/'診断の確認.json').read_bytes());data=json.loads((HERE/'診断.json').read_bytes())
    assert proof['成功'] and proof['全源前後SHA_stat同体'] and data['旧正本一致セル']==201
    assert all(sha(ROOT/r['path'])==r['sha256'] for r in proof['源'])
    own=sorted([*HERE.glob('*.py'),*HERE.glob('*.md')]);source={str(p.relative_to(ROOT)).replace('\\','/'):sha(p) for p in own}
    for path in HERE.glob('*.py'):
        tree=ast.parse(path.read_text(encoding='utf-8'))
        for node in ast.walk(tree):
            if isinstance(node,ast.FunctionDef):
                doc=ast.get_docstring(node);assert doc and '\n' in doc and all(w in doc for w in ('機能:','引数:','返り値:'))
    for part,result in data['部別'].items():
        for p,policy in result['政策'].items():
            assert sum(x['元方向']['件数'] for x in policy['A0分岐別'].values())==policy['全成立']['元方向']['件数']
        for name,link in result['取得集合の接続'].items():
            assert link['新側のみ成立集合']['元方向']['件数']==0
            assert link['共通異event数']==0
    post=data['部別']['validation']['政策']
    assert post['A0']['A0分岐別']['outside_strong_opposition']['元方向']['件数']==193
    assert post['B0']['A0分岐別']['outside_strong_opposition']['元方向']['件数']==151
    env=dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1')
    test=subprocess.run([sys.executable,'-X','utf8',str(HERE/'人工検査.py')],capture_output=True,text=True,encoding='utf-8',errors='strict',env=env)
    assert test.returncode==0 and '\ufffd' not in test.stdout+test.stderr
    assert all(sha(ROOT/p)==h for p,h in source.items())
    value={'成功':True,'編集停止':True,'旧固定正本一致セル':201,'人工主数':2,'構文と複数行型付き関数コメント':True,
        'UTF8_strict':True,'全源前後同体':True,'全分岐分母和一致':True,'新側のみcase又は異event取り直し':False,
        '新ルール採否又は閾値変更':False,'Raw又はCSV又は追加2場':False,
        '人工':{'終了値':test.returncode,'標準出力':test.stdout,'標準エラー':test.stderr},'源':source,
        '成果物':{p.name:sha(p) for p in HERE.glob('*.json') if p.name not in ('最終の確認.json','停止.json')}}
    target=HERE/'最終の確認.json'
    with target.open('x',encoding='utf-8') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
    with (HERE/'停止.json').open('x',encoding='utf-8') as f:json.dump({'成功':True,'編集停止':True,'最終確認SHA256':sha(target),'源':source,'成果物':value['成果物']},f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps({'成功':True,'最終確認SHA256':sha(target),'停止SHA256':sha(HERE/'停止.json')},ensure_ascii=False))


if __name__=='__main__':
    main()
