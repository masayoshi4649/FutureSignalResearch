"""152事後接続の分母・方向差・q0段階を人工で確認する。"""
from pathlib import Path
import importlib.util
import unittest

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('diag152artificial',HERE/'診断する.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


def row(key: str,side: int,state: str,net,reverse_state: str,reverse_net) -> dict:
    """
    機能: q1対応検査だけの小型成立記録を作る。
    引数: key(str)、side(int)、state/reverse_state(str)、net/reverse_net(float|None)。
    返り値: dict。
    """
    return {'session':'人工','case_id':key,'event_id':key,'side':side,'physical':('人工',key),
        'native':{'state':state,'ifd_known':net is not None,'net5':net},
        'inverse':{'state':reverse_state,'ifd_known':reverse_net is not None,'net5':reverse_net}}


class Tests(unittest.TestCase):
    def test_方向変更と集合差(self):
        """
        機能: 同q1変更と旧側だけ/新側だけの成立を分ける。
        引数: self(Tests)。
        返り値: None。
        """
        old=m.module();a=row('共通',1,'F',100,'A',-200);b=row('共通',-1,'A',-200,'F',100);b['event_id']='別event'
        before=[a,row('旧だけ',1,'C',None,'C',None)];after=[b,row('新だけ',1,'N',-77,'N',-77)]
        got=m.transition(before,after,old)
        self.assertEqual(got['共通異event数'],1)
        self.assertEqual(got['方向変更']['件数'],1)
        self.assertEqual(got['方向変更']['両既知C5差_後引く前'],-300)
        self.assertEqual(got['旧側のみ成立集合_機会損失ではない']['元方向']['IFD未知'],1)
        self.assertEqual(got['新側のみ成立集合']['元方向']['件数'],1)

    def test_未知と段階分母(self):
        """
        機能: 未知をfalseへせず、親capture成立と当政策待機を区別する。
        引数: self(Tests)。
        返り値: None。
        """
        self.assertEqual([m.truth(None),m.truth(False),m.truth(True)],['unknown','false','true'])
        q=[{'event_id':'a','source_P65_side':1,'technical':{'A0':{'reason':'outside_strong_opposition','side':1},'B0':{'reason':'chase_above_one_atr','side':0}}}]
        out=m.stage(q,{'a':{'status':'filled'}})
        self.assertEqual(out['P65非ゼロq0数'],1)
        self.assertEqual(out['B0理由']['chase_above_one_atr']['当政策非ゼロq0数'],0)
        self.assertEqual(out['B0理由']['chase_above_one_atr']['親capture_status'],{'filled':1})


if __name__=='__main__':
    unittest.main(verbosity=2)
