"""152の固定caseと保存G/R/B分岐だけを事後比較する。"""
from pathlib import Path
from collections import Counter
import gzip
import hashlib
import importlib.util
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
BASE = ROOT/'work/152複合回復の評価'
DECISION = BASE/'入口選択/q0の判断.json'
SELECT = BASE/'入口選択/選択対応.json'
SUMMARY = BASE/'金融診断/集計.json'
OBS = ROOT/'work/148全1分母集団の評価/固定取得の正逆観測.json'
CAPTURE = ROOT/'inputs/00148_全1分入口母集団/取得対応.json.gz'
PARENT = ROOT/'work/149局面の位置と急変と実反転の診断/診断する.py'
POLICIES = ('P65','A0','B0','U65','U0','U1')
REASONS = ('outside_strong_opposition','countertrend_recovery_confirmed','background_direction_recovery_confirmed',
           'background_unknown','recovery_unknown','neither_recovery','recovery_conflict','source_wait','legacy_C1')
EXPECTED = {DECISION:'1015e22e62ade1f8873a79b568b2b6cc872d66a4a493db0995a764ad9d5d2997',
    SELECT:'d77fcb20976b6207039e31912058894fdf1cc31c7aaae604739df82d2d74110c',
    SUMMARY:'baa76c4a4827204ec3a4673eed4881f66ab2a0ad4d996de8cf8a5bc7e818add5',
    OBS:'d1b4cab8a258203f04b5c1d081f57d10ed2a0c58ce4cc160ef571d5fac0ceffc',
    CAPTURE:'7c27420abe6af0867f6cf3d8fd838205da3ed099df8db8e5b5d62892cbadf6bc',
    PARENT:'963044ab01273131755f4f6df963af986e49a44d0100fa6258c4b340f1e9140a'}


def sha(path: Path) -> str:
    """
    機能: 共有入力を複写せず物理bytesのSHAを求める。
    引数: path(Path)。
    返り値: str。
    """
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()


def module() -> object:
    """
    機能: 固定旧診断の保存quote実側算術とstream readerを私有再用する。
    引数: なし。
    返り値: object。旧mainは呼ばない。
    """
    spec=importlib.util.spec_from_file_location('fixed149diagnostic152',PARENT)
    value=importlib.util.module_from_spec(spec);sys.modules[spec.name]=value;spec.loader.exec_module(value)
    return value


def truth(value: bool | None) -> str:
    """
    機能: 保存known真偽をゼロ補完せず3群へ写す。
    引数: value(bool|None)。
    返り値: str。
    """
    assert value is None or type(value) is bool
    return 'unknown' if value is None else 'true' if value else 'false'


def stats(rows: list, old: object) -> dict:
    """
    機能: 成立集合の元/実逆を同q1で記述する。
    引数: rows(list[dict])、old(object)。
    返り値: dictは全件/FANC/費用/未知/実逆行列。
    """
    return old.paired(rows)


def transition(before: list, after: list, old: object) -> dict:
    """
    機能: 同q1の方向変更と成立集合差を分けて記述する。
    引数: before/after(list[dict])、old(object)。
    返り値: dict。待機の機会損失を算出しない。
    """
    a,b={r['case_id']:r for r in before},{r['case_id']:r for r in after}
    common=set(a)&set(b);same=[];changed=[];event_changed=0;matrix={x:{y:0 for y in 'FANC'} for x in 'FANC'}
    for key in common:
        x,y=a[key],b[key]
        assert x['physical']==y['physical']
        event_changed+=x['event_id']!=y['event_id']
        if x['side']==y['side']:
            assert x['native']==y['native'];same.append(y)
        else:
            assert x['side']==-y['side'];changed.append((x,y));matrix[x['native']['state']][y['native']['state']]+=1
    known=[(x,y) for x,y in changed if x['native']['ifd_known'] and y['native']['ifd_known']]
    return {'共通case数':len(common),'共通同event数':len(common)-event_changed,'共通異event数':event_changed,
        '同方向維持':stats(same,old),'方向変更':{'件数':len(changed),
            '変更前成立実績':old.summarize([x for x,y in changed],'native'),
            '変更後成立実績':old.summarize([y for x,y in changed],'native'),
            '旧方向→新方向行列':matrix,'両IFD既知':len(known),
            '両既知C5差_後引く前':sum(y['native']['net5']-x['native']['net5'] for x,y in known) if known else None,
            '前だけ既知':sum(x['native']['ifd_known'] and not y['native']['ifd_known'] for x,y in changed),
            '後だけ既知':sum(y['native']['ifd_known'] and not x['native']['ifd_known'] for x,y in changed)},
        '旧側のみ成立集合_機会損失ではない':stats([a[k] for k in set(a)-set(b)],old),
        '新側のみ成立集合':stats([b[k] for k in set(b)-set(a)],old)}


def stage(qrows: list, captures: dict) -> dict:
    """
    機能: P65非ゼロq0を固定A/B理由と取得statusで数える。
    引数: qrows(list[dict])、captures(dict[str,dict])。
    返り値: dict。q0数とunique case数を混同しない。
    """
    active=[r for r in qrows if r['source_P65_side']]
    out={'全q0数':len(qrows),'P65非ゼロq0数':len(active),'A0理由':{},'B0理由':{}}
    for policy in ('A0','B0'):
        reasons=sorted({r['technical'][policy]['reason'] for r in active})
        for reason in reasons:
            group=[r for r in active if r['technical'][policy]['reason']==reason]
            out[policy+'理由'][reason]={'q0数':len(group),'当政策非ゼロq0数':sum(r['technical'][policy]['side']!=0 for r in group),
                '親capture_status':dict(Counter(captures[r['event_id']]['status'] for r in group))}
    return out


def main() -> None:
    """
    機能: 固定152判断/成立参照を保存正逆へ結合し小型事後票を作る。
    引数: なし。
    返り値: None。新条件採否・学習・Raw再走査は呼ばない。
    """
    sources={**EXPECTED,HERE/'診断範囲.md':sha(HERE/'診断範囲.md'),Path(__file__):sha(Path(__file__))}
    assert all(sha(p)==h for p,h in sources.items())
    before={str(p):[p.stat().st_size,p.stat().st_mtime_ns] for p in sources}
    decisions=json.loads(DECISION.read_bytes());selection=json.loads(SELECT.read_bytes());summary=json.loads(SUMMARY.read_bytes())
    qrows=decisions['rows'];qmap={r['event_id']:r for r in qrows};sessions=selection['全73場'];assert len(qmap)==len(qrows)==35339 and len(sessions)==73
    with gzip.open(CAPTURE,'rb') as f:body=f.read()
    assert hashlib.sha256(body).hexdigest()=='e433b79f87411c34232acac57a8aed191da71bcd1888376b19196099cbf9909a'
    cap={r['event_id']:r for r in json.loads(body)['rows']};assert set(cap)==set(qmap)
    for key,row in qmap.items():
        c=cap[key];assert c['session']==row['session'] and c['contract']==row['contract']
        assert (c['q0']['time'],c['q0']['index'],c['q0']['source_line'])==(row['q0_time'],row['q0_index'],row['q0_line'])
    old=module();needed={r['case_id'] for p in POLICIES for r in selection['政策'][p]};cases={};scene_count=0
    for scene in old.array_items(OBS,'scenes'):
        assert scene['success'] and scene['session']==sessions[scene_count];scene_count+=1
        for case in scene['cases']:
            if case['id'] in needed:cases[case['id']]=(scene['session'],case)
    assert scene_count==73 and set(cases)==needed
    policy_rows={}
    for policy in POLICIES:
        rows=[];physical=set()
        for choice in selection['政策'][policy]:
            sid,case=cases[choice['case_id']];stream=choice['stream'];reverse='reverse' if stream=='original' else 'original';q1=case[stream]['entry']
            assert sid==choice['session'] and case[stream]['birth']['side']==choice['side'] and case[reverse]['entry']==q1
            key=(sid,q1['time'],q1['index'],q1['source_line']);assert key not in physical;physical.add(key)
            q=qmap.get(choice['event_id']);tech=q['technical'] if q else None
            if policy in ('P65','A0','B0'):
                assert q and q['decision']['directions'][policy]==choice['side']
            rows.append({'session':sid,'case_id':choice['case_id'],'event_id':choice['event_id'],'side':choice['side'],
                'physical':key,'reason':tech['A0']['reason'] if tech else 'legacy_C1',
                'chase':tech['B0']['reason'] if tech else 'legacy_C1',
                'R_source':truth(tech['R_by_side'][str(q['source_P65_side'])]['value']) if tech and q['source_P65_side'] else 'unknown',
                'G':truth(tech['G']['value']) if tech and tech['G'] else 'unknown',
                'native':old.one(case[stream]),'inverse':old.one(case[reverse])})
        policy_rows[policy]=rows
    result={};checked=0
    for part,scope in [('all',sessions),('train',sessions[:48]),('validation',sessions[48:])]:
        current={p:[r for r in rows if r['session'] in scope] for p,rows in policy_rows.items()}
        result[part]={'政策':{},'取得集合の接続':{},'全q0段階':stage([r for r in qrows if r['session'] in scope],cap)}
        for policy,rows in current.items():
            total=stats(rows,old);v=total['元方向'];fixed=summary['集計'][part][policy]['BBO']['3600']['125']
            for a,b in [('件数','entries'),('F','forward'),('A','adverse'),('N','neither'),('C','censored'),('IFD既知','ifd_known'),('IFD未知','ifd_unknown'),('C5利益','ifd_net5_profit'),('C5損失絶対','ifd_net5_loss'),('C5差引','ifd_net5_sum')]:
                assert v[a]==fixed[b],(part,policy,a);checked+=1
            if policy=='U1':
                inv=total['実逆'];fixed_inv=summary['集計'][part]['RU1']['BBO']['3600']['125']
                for a,b in [('件数','entries'),('F','forward'),('A','adverse'),('N','neither'),('C','censored'),('IFD未知','ifd_unknown'),('C5差引','ifd_net5_sum')]:assert inv[a]==fixed_inv[b];checked+=1
            bins={reason:stats([r for r in rows if r['reason']==reason],old) for reason in REASONS}
            assert sum(x['元方向']['件数'] for x in bins.values())==len(rows)
            outside=[r for r in rows if r['reason']=='outside_strong_opposition']
            result[part]['政策'][policy]={'全成立':total,'A0分岐別':bins,
                'G外の保存R元側':{t:stats([r for r in outside if r['R_source']==t],old) for t in ('true','false','unknown')},
                'B0段階別':{reason:stats([r for r in rows if r['chase']==reason],old) for reason in sorted({r['chase'] for r in rows})}}
        for a,b in [('P65','A0'),('A0','B0'),('P65','B0'),('U65','U0'),('U0','U1')]:
            result[part]['取得集合の接続'][a+'→'+b]=transition(current[a],current[b],old)
    oct15={'全q0段階':stage([r for r in qrows if r['session']=='2026-10-15_Day'],cap),
        '政策':{p:{'全成立':stats([r for r in rows if r['session']=='2026-10-15_Day'],old),
            '分岐別':{reason:stats([r for r in rows if r['session']=='2026-10-15_Day' and r['reason']==reason],old) for reason in REASONS}}
            for p,rows in policy_rows.items()}}
    output={'成功':True,'試行':152,'全73場':sessions,'全期既使用':True,'新条件採否又は金融評価':False,
        '用途':'既に成立した固定政策の事後接続。待機の機会損失を採点しない。',
        '部別':result,'10月15日Day':oct15,'旧正本一致セル':checked,'全件原値転載':False}
    assert all(sha(p)==h for p,h in sources.items()) and before=={str(p):[p.stat().st_size,p.stat().st_mtime_ns] for p in sources}
    target=HERE/'診断.json'
    with target.open('x',encoding='utf-8') as f:json.dump(output,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
    proof={'成功':True,'全源前後SHA_stat同体':True,'旧正本一致セル':checked,'Raw又はCSV又は追加2場':False,
        'Source又は閾値変更':False,'新採否条件評価':False,'源':[{'path':str(p.relative_to(ROOT)).replace('\\','/'),'sha256':h,'bytes':before[str(p)][0]} for p,h in sources.items()],
        '出力SHA256':sha(target)}
    (HERE/'診断の確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'正本一致':checked,'部別政策':{k:{p:r['全成立']['元方向'] for p,r in v['政策'].items()} for k,v in result.items()}},ensure_ascii=False))


if __name__=='__main__':
    main()
