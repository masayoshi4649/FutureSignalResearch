"""152の固定条件を保持し、停止監査後だけ正式結果を反映する。"""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
FORMAL = ROOT / 'study/00152_強い反対背景を複合回復で切り替える'
OUTPUT = '../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/152_複合回復による方向切替'


def sha(path: Path) -> str:
    """
    機能: 小型文書と金融正本のSHA256を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def number(value: int | float | None, decimals: int = 0) -> str:
    """
    機能: 未知を0へ補完せず表用の数値へ整形する。
    引数: value(int|float|None)、decimals(int)。返り値: str。
    """
    return '未定義' if value is None else f'{value:,.{decimals}f}'


def table(data: dict, part: str, policies: tuple[str, ...]) -> str:
    """
    機能: H60±125実BBOの正本値から政策表を作る。
    引数: data(dict)、part(str)、policies(tuple[str,...])。返り値: str。
    """
    lines = ['| 政策 | 取得 | 順/逆/未/不足 | 到達済み率 | C5利益円 | C5損失絶対円 | C5差引円 | IFD未知 |',
             '| --- | ---: | --- | ---: | ---: | ---: | ---: | ---: |']
    for policy in policies:
        row = data['集計'][part][policy]['BBO']['3600']['125']
        rate = None if row['resolved_rate'] is None else row['resolved_rate'] * 100
        counts = '/'.join(str(row[k]) for k in ('forward', 'adverse', 'neither', 'censored'))
        lines.append(f"| {policy} | {row['entries']} | {counts} | {number(rate, 2)}% | "
                     f"{number(row['ifd_net5_profit'])} | {number(row['ifd_net5_loss'])} | "
                     f"{number(row['ifd_net5_sum'])} | {row['ifd_unknown']} |")
    return '\n'.join(lines)


def main() -> None:
    """
    機能: 自然全件監査成功を確認しREADME更新と条件/設定末尾追記を行う。
    引数: CLI --audit(Path)/--audit-sha256(str)。返り値: None。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--audit', type=Path, required=True)
    parser.add_argument('--audit-sha256', required=True)
    args = parser.parse_args()
    assert sha(args.audit) == args.audit_sha256
    audit = json.loads(args.audit.read_bytes())
    assert audit.get('成功') is True
    summary = FORMAL / '成果物/集計.json'
    assert sha(summary) == 'baa76c4a4827204ec3a4673eed4881f66ab2a0ad4d996de8cf8a5bc7e818add5'
    data = json.loads(summary.read_bytes())
    original = json.loads(gzip.decompress((FORMAL / '検査/F0実行前文書.json.gz').read_bytes()))
    before = {Path(row['path']).name: row['本文'] for row in original['文書']}
    assert all((FORMAL / name).read_bytes() == text.encode('utf-8') for name, text in before.items())
    common = '''全表は実BBO/H60/±125pt、数量独立1mini、往復77円＋C5追加1,000円。金額はIFD既知分の小計で、未知を0円にしていない。先着F/A/N/CとIFD清算既知性は別で、同時建玉を束ねた口座収支・必須追尾の評価ではない。C0という政策名と追加滑りなしC0費用を区別する。'''
    all_table = table(data, 'all', tuple(data['集計']['all']))
    front_table = table(data, 'train', ('P65', 'A0', 'B0', 'U65', 'U0', 'U1'))
    back_table = table(data, 'validation', ('P65', 'A0', 'B0', 'U65', 'U0', 'U1'))
    readme = f'''# 152 強い反対背景を複合回復で切り替える

**実行済み・主U1は未達。** 到達済み先着率62.63%（372順/222逆）、697取得・全73場、全時間平均0.9668回/時。C5既知利益4,724,429円/損失3,374,174円/差引+1,350,255円、IFD未知12件。後25場は49.13%・既知差引−240,706円で、70%と後期の安定性を確認できなかった。比較U0/U65へ主を交換しない。

## 何を比較したか

固定151 P65の非ゼロ方向を、30分EMA21・30/15分DI・15分ADXによる強い反対背景Gで分類した。G内は1分実体・q0Lastで残る前実体回復・5分Hist/RSI増分・同足相対量を各方向で確認し、片側だけが成立すれば維持/切替、未知や両側不成立なら待機するAを比較した。主BはAの最終注文側に5分EMA8から順向き1ATR以内の上限を追加した。G外のAは元P65を維持する。

旧C1全87を保護したU1=B＋C1を主、U0=A＋C1を比較、U65=P65＋C1を固定対照とした。新学習・再推論・新特徴・Raw走査は行っていない。買売は同じ条件を各実側Ask0/Bid0配列に適用し、全q0判断後にだけq1を結合した。[実行前条件](条件.md)と[設定済み513セル](設定と結果.md)はF0原文を保持している。そこに残る「未実行」はF0時点の記録で、現在の実行状態は本READMEと末尾結果節に示す。

## 全体結果

{all_table}

{common}

主U1のH完了分母率は372/667=55.77%、全取得分母率は372/697=53.37%。到達済み率62.63%だけへ分母を縮めて目標達成としない。既知685/未知12、追加滑りなし費用C0の既知差引は+2,035,255円。全件確定口座利益を意味しない。

| 主の共同判定 | 実測 | 判定 |
| --- | --- | --- |
| 到達済み先着70%以上 | 372/594=62.6263% | 未達 |
| 全対象73場で最低1取得 | 73/73、各場1～77取得 | 達成 |
| 全時間平均1回/時以上 | 697/720.9167h=0.9668246回/時 | 未達 |
| 3条件共同 | 上記を同時判定 | 未達 |

名目新規可時間だけなら1.0758回/時だが、主の全時間頻度へ置き換えない。回数の場間偏りは許容し、同q1を重複計数していない。

## 前48場・後25場

### 前48場（参考）

{front_table}

### 後25場（参考）

{back_table}

主U1は前48場68.17%/+1,590,961円（未知11）に対し、後25場49.13%/−240,706円（未知1）。新B0だけなら後25場47.02%/−281,627円で、旧C1保護を新条件の優位と混同しない。全73場は既使用で151後の事後着想のため、前後は独立未知期の成績ではない。

## 件数の変化と解釈

P65は1,126出生/1,118取得、Aは755/748、Bは620/614。Bのうち旧C1と同q1の4件は保護され、U1は697取得となった。P65→A→Bでは方向維持/切替/待機があるため、異なる政策の金額差を同じ取引の改善と即断しない。U65からU1で全体率・既知差引は改善したが、70%と後期安定は未達で、Bの追加によるU0との差引改善も全体では確認できない。

一般説明は方向をDI/MA、強さをADX、勢いをHist/RSI、構造を実体/現在Last、量を同r相対量、位置を最終側EMA8距離と分けるもの。心理は「背景へ逆らう場合も背景へ戻す場合も回復・動力・量の確認を要求する」という仮説であり、参加者の意思や反転完了の証明ではない。事後の枝別診断は[根拠](根拠/固定P65から複合回復へ変えた結果.md)へ分離し、新閾値を採用していない。

事後の同case照合では18件の方向変更が、旧P65の10順8逆から新A0の7順11逆へ悪化した。一方、強反対背景で新たに待機した旧成立集合370件は旧記録で逆行が多かった。全体の改善を切替成功と同一視しない。後25のA0全193件/B0全151件はG外維持で、今回のG内回復枝が後期の不調を直したわけではない。G外へRを一律追加する新規則もここでは採用していない。

## 入力・再現・閲覧

[152固定book](../../inputs/00152_複合回復の方向切替/条件.json)、[新3JSONの保存案内](../../inputs/00152_複合回復の方向切替/README.md)、[保管索引](保管索引.json)、[再現手順](再現手順.md)、[閲覧資料](閲覧資料.md)。親151の保存q0判断・モデルZIPと148の100特徴/取得対応/正逆観測は共有し複写していない。新3JSONだけ各1gzipを保存した。

[全セッションCSV]({OUTPUT}/全セッション.csv)から確認し、[入口別診断CSV]({OUTPUT}/入口別診断.csv)、[660比較CSV]({OUTPUT}/正逆比較.csv)で分解する。新xlsxは生成していない。[自然判断の独立監査](検査/自然選択の独立監査.json)と[金融660比較の独立検算](検査/金融独立検算.json)、[CSV再読](検査/CSV独立再読.json)を分けた。

本研究は入口IFD代用であり、実miniの約定・10枚可変数量・保有重複・必須トレーリングの実運用収支を評価していない。元P65確率を切替側の確信度へ移さない。全期既使用、近接H60/同場依存、反転側geometry未再構築、CSV公表と実受信時計の差を残す。**主U1の採用達成とはせず、固定済みの152条件を後から変更しない。**
'''
    appended = f'''

## 2026-11-12 実行結果（F0採用条件は不変更）

本文の準備時「未実行」はF0の記録として保持した。現在は自然選択/金融/独立監査まで実行済みで、主U1は70%・全時間1/hを満たさず共同未達。主や閾値は交換していない。

{all_table}

主U1は697取得/73場、平均0.9668246回/時。到達済372/594=62.6263%、H完了372/667=55.7721%、全取得372/697=53.3716%。既知685/未知12。前48場68.1710%/+1,590,961円、後25場49.1329%/−240,706円。元条件の513構造と各閾値は保持し、結果を指標単独の効果としていない。

{common}

[結果の読み方](README.md) / [正本](成果物/集計.json) / [再現手順](再現手順.md) / [閲覧資料](閲覧資料.md)。
'''
    (HERE / 'README草稿.md').write_text(readme, encoding='utf-8')
    (HERE / '結果追記草稿.md').write_text(appended, encoding='utf-8')
    (FORMAL / 'README.md').write_bytes(readme.encode('utf-8'))
    for name in ('条件.md', '設定と結果.md'):
        (FORMAL / name).write_bytes((before[name] + appended).encode('utf-8'))
    result = {'成功': True, '試行': 152, '主U1未達': True, '自然全件監査SHA256': args.audit_sha256,
              '実行前文書先退避': True, '条件と設定F0全文prefix保持': True,
              '閾値又は主変更': False, '正式3MD': {name: sha(FORMAL / name) for name in before},
              '結果正本SHA256': sha(summary), '更新器SHA256': sha(Path(__file__))}
    (HERE / '結果反映の確認.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
