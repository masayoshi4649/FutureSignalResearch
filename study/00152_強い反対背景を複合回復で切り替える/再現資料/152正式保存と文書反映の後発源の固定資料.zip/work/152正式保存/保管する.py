"""152の通知済み固定票・新3JSON・金融証跡を一度保存する。"""
from pathlib import Path
import gzip
import hashlib
import importlib.util
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
FORMAL_REL = 'study/00152_強い反対背景を複合回復で切り替える'
INPUT_REL = 'inputs/00152_複合回復の方向切替'
FORMAL = ROOT / FORMAL_REL
RUNTIME = ROOT / 'work/152複合回復の評価'
FREEZES = {
    'F0': ('F0入口選択前.json', 'c880033142c9d539dd7ed6c695d923b806ecd5ec307c42a5d4ac1ff639739d21'),
    'F1': ('F1入口選択後.json', '7111973cb5abcd4fb90a145b103357efd8204a1f684c226c0633fd9c74681aaa'),
    'F2': ('F2金融集計前.json', 'f1e4b5067ec96004bfa9053c041e2ea68901403623c70f03347d0edb91ee1a7f'),
}


def library():
    """
    機能: 151の保存小関数を読取専用で再用し、保存先だけ152へ分離する。
    引数: なし。
    返り値: ModuleType。旧151のファイルを変更しない。
    """
    path = ROOT / 'work/151正式保存/保存部品.py'
    spec = importlib.util.spec_from_file_location('shared151archive_for152', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.FORMAL_REL = FORMAL_REL
    module.INPUT_REL = INPUT_REL
    original = module.pack_zip

    def pack(entries: dict, target: Path, aliases: dict | None = None) -> dict:
        """
        機能: 再用resolveの新ZIP名だけを152へ改めて格納する。
        引数: entries(dict)、target(Path)、aliases(dict|None)。
        返り値: dict。元151 Sourceと保存実体は不変更。
        """
        target = target.with_name(target.name.replace('151', '152', 1))
        return original(entries, target, aliases)

    module.pack_zip = pack
    return module


def references(groups: dict) -> dict:
    """
    機能: 一度保存した源を次段階で再圧縮しないためpath索引へ射影する。
    引数: groups(dict)はresolveの保存参照。
    返り値: dict[str,dict]。全ZIP内pathとSHAを保持する。
    """
    result = {}
    for key, items in groups.items():
        if isinstance(items, list):
            for item in items:
                if '復元先' in item:
                    result[item['復元先']] = item
        if isinstance(items, dict) and '格納源' in items:
            for item in items['格納源']:
                result[item['path']] = {'復元先': item['path'], 'sha256': item['sha256'],
                    '保存元ZIP': items['保存元ZIP'], 'ZIP_SHA256': items['ZIP_SHA256'],
                    'ZIP内path': item['ZIP内path'], 'bytes': item['bytes']}
    return result


def main() -> None:
    """
    機能: 固定段階と原文を先退避し、生成3JSON/金融を非重複で恒久化する。
    引数: なし。Root通知済み指紋だけを読む。
    返り値: None。自然再実行・再計算・正式3MDの更新はしない。
    """
    lib = library()
    index_path = FORMAL / '保管索引.json'
    assert not index_path.exists()
    stage_values = {}
    for stage, (name, expected) in FREEZES.items():
        path = RUNTIME / name
        assert lib.sha(path) == expected
        value = json.loads(path.read_bytes())
        assert value['成功'] and value['試行'] == 152
        files = lib.normalized_files(value['ファイル'])
        assert all(lib.sha(ROOT / p) == h for p, h in files.items())
        stage_values[stage] = value
    files0 = lib.normalized_files(stage_values['F0']['ファイル'])
    docs, existing = [], {}
    for name in ('README.md', '条件.md', '設定と結果.md'):
        rel = FORMAL_REL + '/' + name
        source = RUNTIME / 'F0実行前文書' / name
        body = source.read_bytes()
        assert hashlib.sha256(body).hexdigest() == files0[rel] == lib.sha(FORMAL / name)
        assert all(lib.normalized_files(v['ファイル'])[rel] == files0[rel] for v in stage_values.values())
        docs.append({'path': rel, 'bytes': len(body), 'sha256': files0[rel], '本文': body.decode('utf-8')})
    snapshot = FORMAL / '検査/F0実行前文書.json.gz'
    lib.write_new(snapshot, gzip.compress(lib.json_bytes({'試行': 152, '段階': 'F0',
        '固定SHA256': FREEZES['F0'][1], '文書': docs, '実行前Root退避': True,
        'F1_F2も同じ3文書SHA': True, '結果文書から事前固定を後造り': False}), mtime=0))
    for row in docs:
        existing[row['path']] = {'復元先': row['path'], 'sha256': row['sha256'],
            'bytes': row['bytes'], '形式': '文書snapshot', '保存元': snapshot.relative_to(ROOT).as_posix(),
            '保存SHA256': lib.sha(snapshot), '抽出キー': row['path']}
    index = {'試行': 152, '段階': '固定原文と生成3JSON/金融を保存。自然監査/事後根拠/正式結果は後段。',
             '主政策': 'U1', '比較': 'U0', '固定対照': 'U65',
             '実行前文書': {'保存元': snapshot.relative_to(ROOT).as_posix(), '保存SHA256': lib.sha(snapshot)},
             '新モデル生成': False, '共有151モデルと148大入力の新複写': False, '固定段階': {}}
    generated = []
    f1files = lib.normalized_files(stage_values['F1']['ファイル'])
    for name in ('q0の判断.json', '選択対応.json', '選択の確認.json'):
        source = RUNTIME / '入口選択' / name
        rel = source.relative_to(ROOT).as_posix()
        record = lib.save_file(source, ROOT / INPUT_REL / (name + '.gz'), f1files[rel], True)
        lib.check_reference(record, f1files[rel])
        generated.append(record)
        existing[rel] = record
    index['152新生成3JSONを各1gzip保存'] = generated
    for stage, (name, expected) in FREEZES.items():
        record = lib.save_file(RUNTIME / name, FORMAL / '検査' / name, expected)
        existing[record['復元先']] = record
        resolved = lib.resolve(stage_values[stage]['ファイル'], stage, existing)
        existing.update(references(resolved))
        index['固定段階'][stage] = {'SHA256': expected, '原文': record,
            '全源数': len(stage_values[stage]['ファイル']), '全源復元参照': resolved}
    financial = RUNTIME / '金融診断'
    assert lib.sha(financial / '集計.json') == 'baa76c4a4827204ec3a4673eed4881f66ab2a0ad4d996de8cf8a5bc7e818add5'
    assert lib.sha(financial / 'CSV用の表.json') == '9490219016d91272740c343cf91d3498ae7ce740d5135f8fa40be06fce96a8f6'
    artifacts = []
    for name, dest, packed in [('集計.json', '成果物/集計.json', False),
        ('CSV用の表.json', '成果物/CSV用の表.json.gz', True),
        ('集計完了.json', '成果物/集計完了.json', False),
        ('独立検算.json', '検査/金融独立検算.json', False),
        ('CSV独立再読.json', '検査/CSV独立再読.json', False)]:
        source = financial / name
        record = lib.save_file(source, FORMAL / dest, lib.sha(source), packed)
        lib.check_reference(record, record['解凍SHA256'])
        artifacts.append(record)
    index['金融とCSV証跡'] = artifacts
    output = ROOT / 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/152_複合回復による方向切替'
    index['CSV正本'] = [{'path': p.relative_to(ROOT).as_posix(), 'sha256': lib.sha(p),
                         'bytes': p.stat().st_size} for p in sorted(output.glob('*.csv'))]
    assert len(index['CSV正本']) == 3
    index['CSV作成確認'] = lib.save_file(output / 'CSVの確認.json', FORMAL / '検査/CSV作成の確認.json', lib.sha(output / 'CSVの確認.json'))
    images = sorted((output / '支援画像').glob('*.png'))
    assert len(images) == 3
    index['CSV支援画像'] = [{'path': p.relative_to(ROOT).as_posix(), 'sha256': lib.sha(p)} for p in images]
    index['Root表示確認'] = 'Root通知：59798セル/31530数値を独立再読、3支援画像を視認済み。'
    index['Source独立準備の時点注意'] = 'F0には成功c107人工票と人工Sourceを含む。README/準備票等の後発追加はF0事前4点固定と遡及して主張しない。'
    lib.write_new(index_path, lib.json_bytes(index))
    proof = {'成功': True, '試行': 152, '正式3MD結果更新前退避済み': True,
             'F0_F1_F2全源保存又は共有参照': True, '新3JSON各1gzip': True,
             '全新保存bytes再読照合': True, '新モデル又は大共有入力の新複写': False,
             'Source_正式3MD_旧151以前変更': False, '自然再生成又は金融再計算': False,
             '保管索引SHA256': lib.sha(index_path), '再用保存関数': {
                 'path': 'work/151正式保存/保存部品.py', 'sha256': lib.sha(ROOT / 'work/151正式保存/保存部品.py')},
             '保存器SHA256': lib.sha(Path(__file__))}
    lib.write_new(HERE / '先退避の確認.json', lib.json_bytes(proof))
    print(json.dumps({'成功': True, '新3JSON': len(generated),
        '固定源数': {k: len(v['ファイル']) for k, v in stage_values.items()},
        '先退避票SHA256': lib.sha(HERE / '先退避の確認.json')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
