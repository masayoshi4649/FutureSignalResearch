"""152の共有入力・CSV閲覧・固定選択の再集計案内を恒久化する。"""
from pathlib import Path
import importlib.util
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
FORMAL = ROOT / 'study/00152_強い反対背景を複合回復で切り替える'


def main() -> None:
    """
    機能: 索引に基づく入力/閲覧/再現文書を新規作成する。
    引数: なし。返り値: None。大入力・旧151・Root目次を編集しない。
    """
    spec = importlib.util.spec_from_file_location('base152docs', HERE / '保管する.py')
    base = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(base)
    lib = base.library()
    index = json.loads((FORMAL / '保管索引.json').read_bytes())
    rows = ['| 新保存 | 物理bytes | 物理SHA256 | 解凍bytes | 解凍SHA256 |',
            '| --- | ---: | --- | ---: | --- |']
    for item in index['152新生成3JSONを各1gzip保存']:
        name = Path(item['保存元']).name
        rows.append(f"| [{name}]({name}) | {item['保存bytes']:,} | `{item['保存SHA256']}` | "
                    f"{item['解凍bytes']:,} | `{item['解凍SHA256']}` |")
    inputs = '''# 152 複合回復の方向切替・恒久入力

152は保存済み151 P65方向を当時100列で確認し、主U1/比較U0/対照U65を自然評価前に固定した。[条件](条件.json)のSHA256は `7805b17d8125b15c8f28d6d874a0a53e2066e92f858df21b41e0e61454167067`。新モデル・再学習・再推論・Raw走査はない。

''' + '\n'.join(rows) + '''

上の3JSONだけを各1gzipで保存し、全CRC/解凍SHAを再読照合した。q0判断は全35,339件、取得対応は全判断後の結合。候補数・取得数・旧C1優先統合は別に扱う。

[共有151モデル/q0判断ZIP](../00151_過去場だけの複合判別/学習と選択の正本.zip)物理SHA256 `61e4826a61e06440b7914b3e9eff0539ab5f8632d389a83515108f9a46f423cb`、[共有148特徴等](../00148_全1分入口母集団/README.md)、[共有148正逆観測](../../study/00148_全1分知得から入口品質の母集団を固定する/成果物/固定取得の正逆観測.json.gz)を参照し、新たに複写していない。旧C1全87も共有固定入力から保護する。

実行前F0/F1/F2・Source小ZIP・事後監査の時点は[保管索引](../../study/00152_強い反対背景を複合回復で切り替える/保管索引.json)へ残した。[正式結果](../../study/00152_強い反対背景を複合回復で切り替える/README.md)は主未達で、母集団整備や主の収益が入口70%達成を意味しない。復元は[再現手順](../../study/00152_強い反対背景を複合回復で切り替える/再現手順.md)に従い、同じSHAの既存源を上書きしない。
'''
    viewer = '''# 152のCSVを見る

最初は[全セッションCSV](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/152_複合回復による方向切替/全セッション.csv)を開く。全73場とU1/B0/C1の利益・損失・差引・未知・累計を残した。未知が累積した後の全件確定差引はnullで、既知小計と分ける。

[入口別診断CSV](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/152_複合回復による方向切替/入口別診断.csv)は主U1の697取得、[正逆比較CSV](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/152_複合回復による方向切替/正逆比較.csv)は11政策660条件。主はU1/全体/BBO/H60/±125で、結果後に比較へ交換しない。新xlsxは生成していない。

主は62.63%・0.9668回/時で共同未達。後25場は49.13%・既知差引−240,706円/未知1。金額は独立1mini入口IFD代用で、実口座・可変数量・必須追尾の収支ではない。[README](README.md)、[金融正本](成果物/集計.json)、[再現手順](再現手順.md)を参照する。

RootはCSV59,798セル/数値31,530セルの独立再読と3支援画像を確認した。[CSV再読票](検査/CSV独立再読.json)と[作成票](検査/CSV作成の確認.json)は算術検算とは別証拠。[原因短報](根拠/固定P65から複合回復へ変えた結果.md)の群は事後で、新規条件や主の差替えを採用していない。
'''
    replay = '''# 152の保存資料から再現する

[保管索引](保管索引.json)に全固定源の元path・保存実体・物理/解凍SHAを記録した。[F0](検査/F0入口選択前.json)は判断前、[F1](検査/F1入口選択後.json)は全q0判断/取得対応後、[F2](検査/F2金融集計前.json)は金融集計前である。実行前3MDは[F0原文gzip](検査/F0実行前文書.json.gz)に保存し、F1/F2も同じ文書SHAだった。結果追記済みMDをF0原文として扱わない。

## 入力とSource

[152入力](../../inputs/00152_複合回復の方向切替/README.md)にはbookと新3JSON各1gzipだけを置く。モデル65個と元P65/q0は151の単一ZIP、100特徴・取得対応・大正逆観測は148を共有する。モデルの再学習/再推論は今回不要。Sourceは再現資料のF0/F1/F2小ZIPと共有保存先へ指紋で結んだ。新Sourceを作って再計測した結果ではない。

Source復元では索引の元相対pathを用い、不足するworkファイルだけを取り出す。既存源のSHAが違えば停止し、旧源や正式文書を上書きしない。別環境では同じリポジトリ相対構造を作り、Windowsで記録された絶対参照がある場合は同じ作業ルートを用意する。共有データを再複写してRootを偽装しない。

## 選択の再現

固定bookと保存151 ZIP一member/共有100Xだけで全35,339q0を判断し、全判断保存後にcaptures/metaを結ぶ。CLIは実行前条件とSource READMEに保存した。選択生成の再実行はRoot F0と同じSHAのSource/入力、排他の未作成出力先を用いる。C1未来表をG/R/Bへ渡さず、q1をq0特徴にしない。

[自然選択の独立監査](検査/自然選択の独立監査.json)は作者choose/project/connectをimportせず全35,339q0/1,144,168末端と全政策所属/canonical/C1優先を照合した。事後監査README/準備票の追加はF0前4点の固定へ遡及せず、索引で後発と明記する。F0に入ったのは成功c107人工票と人工Sourceである。

## 保存選択と観測から660比較を再集計する

```powershell
python -X utf8 'study/00152_強い反対背景を複合回復で切り替える/再現資料/保存選択から再集計する.py' `
  --output-dir 'work/152再現用の新規出力'
```

不足する小型work源と固定選択/F1/F2だけを保存実体から復元し、既存源不一致は拒否する。152の学習/選択・Raw再走査をせず、共有148の保存BBO/Last4streamを凍結算術へ渡す。集計とtyped三表の全bytesを保存正本へ照合する。[再現確認](検査/保存観測からの再現確認.json)に結果を残した。金融[660比較/15,840キーの別算術票](検査/金融独立検算.json)と[CSV独立再読](検査/CSV独立再読.json)は別検査である。

## 事後知見の境界

[固定P65からの原因診断](根拠/固定P65から複合回復へ変えた結果.md)は成立集合の変化・18方向変更・後25場を分けた。18切替の悪化、G外に残った後期不調、R条件追加で容量を失う懸念は次の問いで、152に新規閾値を付けて再選択していない。全73既使用・151後着想・近接H60依存を残し、実mini/口座利益保護の成功とはしない。
'''
    for path, text in [(ROOT / 'inputs/00152_複合回復の方向切替/README.md', inputs),
                       (FORMAL / '閲覧資料.md', viewer), (FORMAL / '再現手順.md', replay)]:
        lib.write_new(path, text.encode('utf-8'))
    lib.save_file(HERE / '保存選択から再集計する.py', FORMAL / '再現資料/保存選択から再集計する.py',
                  lib.sha(HERE / '保存選択から再集計する.py'))
    replayed = HERE / '保存選択の再集計/保存観測からの再現確認.json'
    assert replayed.exists()
    lib.save_file(replayed, FORMAL / '検査/保存観測からの再現確認.json', lib.sha(replayed))
    print(json.dumps({'成功': True, '152入力_閲覧_再現案内': True}, ensure_ascii=False))


if __name__ == '__main__':
    main()
