"""152のF0条件原文・513セル・全源復元・リンクを確認し最終停止する。"""
from pathlib import Path
import gzip
import hashlib
import importlib.util
import json
import re
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
FORMAL = ROOT / 'study/00152_強い反対背景を複合回復で切り替える'


def main() -> None:
    """
    機能: 固定源の保存実体と現在Source不変を確認し、結果文書の停止票を作る。
    引数: なし。返り値: None。閾値/旧試行/Sourceを変更しない。
    """
    spec = importlib.util.spec_from_file_location('save152final_base', HERE / '保管する.py')
    base = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(base)
    lib = base.library()
    index_path = FORMAL / '保管索引.json'
    index = json.loads(index_path.read_bytes())
    existing = {}
    for stage in index['固定段階'].values():
        existing.update(base.references(stage['全源復元参照']))
    for record in index['152新生成3JSONを各1gzip保存']:
        existing[record['復元先']] = record
    for record in index['金融とCSV証跡']:
        existing[record['復元先']] = record
    source_files = {p.relative_to(ROOT).as_posix(): lib.sha(p)
                    for p in HERE.glob('*.py')}
    source_files[HERE.joinpath('先退避の確認.json').relative_to(ROOT).as_posix()] = lib.sha(HERE / '先退避の確認.json')
    if '正式保存と文書反映の後発源' not in index:
        index['正式保存と文書反映の後発源'] = lib.resolve(source_files, '正式保存と文書反映の後発源', existing)
        index['段階'] = '全固定源/3生成gzip/金融/CSV/独立監査/原因診断/再現を保存。主U1未達、最終停止。'
        index_path.write_bytes(lib.json_bytes(index))
    snapshot = json.loads(gzip.decompress((FORMAL / '検査/F0実行前文書.json.gz').read_bytes()))
    original = {Path(row['path']).name: row for row in snapshot['文書']}
    docs = [FORMAL / name for name in ('README.md', '条件.md', '設定と結果.md')]
    before = {p: lib.sha(p) for p in docs}
    for name in ('条件.md', '設定と結果.md'):
        assert (FORMAL / name).read_bytes().startswith(original[name]['本文'].encode('utf-8'))
    pattern = re.compile(r'^\|\s+[A-Z]\d{2}\s+\|')
    tables = []
    for text in (original['設定と結果.md']['本文'], docs[2].read_text(encoding='utf-8')):
        rows = [line for line in text.splitlines() if pattern.match(line) and len(line.split('|')) == 13]
        tables.append(rows)
    assert tables[0] == tables[1] and len(tables[1]) == 57
    assert len({r.split('|')[1].strip() for r in tables[1]}) == 57
    assert all(len(r.split('|')[3:-1]) == 9 for r in tables[1])
    assert '全セルは未設定・未検証。' not in docs[2].read_text(encoding='utf-8')
    intro = docs[0].read_text(encoding='utf-8').split('\n\n')[1]
    assert '実行済み' in intro and '主U1' in intro and '未達' in intro
    summary_path = FORMAL / '成果物/集計.json'
    assert lib.sha(summary_path) == 'baa76c4a4827204ec3a4673eed4881f66ab2a0ad4d996de8cf8a5bc7e818add5'
    summary = json.loads(summary_path.read_bytes())
    assert summary['主評価'] == {'全場最低1': True, '到達済70%': False, '全時間毎時1以上': False, '三目標共同': False}
    restored, unique, source_before = {}, {}, {}
    for label, stage in index['固定段階'].items():
        frozen = json.loads((ROOT / stage['原文']['保存元']).read_bytes())
        refs = base.references(stage['全源復元参照'])
        restored[label] = 0
        for rel, expected in frozen['ファイル'].items():
            ref = refs[rel]
            lib.check_reference(ref, expected)
            restored[label] += 1
            unique[rel] = expected
            if not rel.startswith(FORMAL.relative_to(ROOT).as_posix() + '/'):
                assert lib.sha(ROOT / rel) == expected, rel
                source_before[rel] = expected
    for record in index['152新生成3JSONを各1gzip保存'] + index['金融とCSV証跡']:
        lib.check_reference(record, record['解凍SHA256'])
    stage = index['正式保存と文書反映の後発源']
    for rel, expected in source_files.items():
        lib.check_reference(base.references(stage)[rel], expected)
    link_count = 0
    targets = [*docs, FORMAL / '閲覧資料.md', FORMAL / '再現手順.md',
               ROOT / 'inputs/00152_複合回復の方向切替/README.md']
    for path in targets:
        for target in re.findall(r'\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
            if '://' in target or target.startswith('#'):
                continue
            local = unquote(target.strip('<>').split('#', 1)[0])
            assert (path.parent / local).exists(), (path.relative_to(ROOT).as_posix(), target)
            link_count += 1
    assert before == {p: lib.sha(p) for p in docs}
    assert all(lib.sha(ROOT / rel) == expected for rel, expected in source_before.items())
    replay = json.loads((FORMAL / '検査/保存観測からの再現確認.json').read_bytes())
    assert replay['成功'] and replay['正本と三表bytes再現']
    author = {'成功': True, '試行': 152, '編集停止': True,
        '条件_設定F0全bytes_prefix保持': True, 'V7': {'手法': 57, '尺度': 9, 'セル': 513,
            'F0設定済み全行同体': True, '原V7全セルの未設定本文と同値とは主張しない': True},
        'README先頭': '実行済み・主U1未達', '主交換_閾値変更': False,
        'ローカルリンク実在': link_count, '正式3MD': {p.name: lib.sha(p) for p in docs},
        '主の判定は正本同体': summary['主評価'],
        '数値の独立算術はRoot660比較15840キーへ分離': True,
        'CSV再読は59798セル31530数値_Root3画像視認へ分離': True,
        '固定源保存実体からの復元件数': restored, '固定源unique': len(unique),
        'Source前後同体': True, '新3JSON各1gzip再読同体': True,
        '保存選択と共有観測から正本三表bytes再現': True,
        'Source独立後発資料をF0事前固定へ遡及': False,
        '新モデル又は大共有入力の複写': False, 'Raw_CSV_追加2場の新読取': False,
        '文書作者の自己確認である': True, '確認器SHA256': lib.sha(Path(__file__))}
    author_path = FORMAL / '検査/正式資料の最終反映確認.json'
    lib.write_new(author_path, lib.json_bytes(author))
    final = {'成功': True, '試行': 152, '編集停止': True,
        '保管索引SHA256': lib.sha(index_path), '正式作者最終票SHA256': lib.sha(author_path),
        'F0_F1_F2固定源復元同体': restored, '新3gzipと正本三表同体': True,
        '正式3MD_513_リンク': True, '主U1未達で採用達成にしない': True,
        '旧151以前と固定Source不変更': True}
    lib.write_new(FORMAL / '検査/正式保存の最終確認.json', lib.json_bytes(final))
    lib.write_new(HERE / '停止の確認.json', lib.json_bytes({**final,
        '正式最終票SHA256': lib.sha(FORMAL / '検査/正式保存の最終確認.json'),
        '正式3MD': author['正式3MD'], '保存最小源': list(source_files)}))
    print(json.dumps({'成功': True, '513': True, 'リンク': link_count,
        '正式作者最終票SHA256': lib.sha(author_path),
        '正式保存最終票SHA256': lib.sha(FORMAL / '検査/正式保存の最終確認.json'),
        '停止票SHA256': lib.sha(HERE / '停止の確認.json'),
        '索引SHA256': lib.sha(index_path)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
