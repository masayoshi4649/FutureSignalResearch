"""152の独立監査や原因診断を元固定段階へ遡及せず保存する。"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
FORMAL = ROOT / 'study/00152_強い反対背景を複合回復で切り替える'


def main() -> None:
    """
    機能: 停止票で通知された小型一式と大診断JSONだけを非重複で保管する。
    引数: CLI --phase(audit|cause)、--folder(Path)、--stop(Path)、--stop-sha256(str)。
    返り値: None。152 Source・旧151・実行前F0/F1/F2を編集しない。
    """
    p = argparse.ArgumentParser()
    p.add_argument('--phase', choices=('audit', 'cause'), required=True)
    p.add_argument('--folder', type=Path, required=True)
    p.add_argument('--stop', type=Path, required=True)
    p.add_argument('--stop-sha256', required=True)
    args = p.parse_args()
    args.folder = args.folder.resolve()
    args.stop = args.stop.resolve()
    spec = importlib.util.spec_from_file_location('archive152_base', HERE / '保管する.py')
    base = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(base)
    lib = base.library()
    assert lib.sha(args.stop) == args.stop_sha256
    stop = json.loads(args.stop.read_bytes())
    assert stop.get('成功') is True
    index_path = FORMAL / '保管索引.json'
    index = json.loads(index_path.read_bytes())
    key = '自然選択の独立監査' if args.phase == 'audit' else 'P65から複合回復の事後診断'
    assert key not in index
    existing = {}
    pending = [index]
    while pending:
        item = pending.pop()
        if isinstance(item, list):
            pending.extend(item)
        elif isinstance(item, dict):
            if '復元先' in item and ('解凍SHA256' in item or 'sha256' in item):
                existing[item['復元先']] = item
            if '格納源' in item and '保存元ZIP' in item:
                for entry in item['格納源']:
                    existing[entry['path']] = {'復元先': entry['path'], 'sha256': entry['sha256'],
                        '保存元ZIP': item['保存元ZIP'], 'ZIP_SHA256': item['ZIP_SHA256'],
                        'ZIP内path': entry['ZIP内path'], 'bytes': entry['bytes']}
            pending.extend(item.values())
    if args.phase == 'audit':
        files = {args.folder / name: item['SHA256'] for name, item in stop['保存対象'].items()}
        files[args.stop] = args.stop_sha256
        primary = args.folder / '自然確認/監査の確認.json'
        target = FORMAL / '検査/自然選択の独立監査.json'
        expected = lib.sha(primary)
        if target.exists():
            assert lib.sha(target) == expected
            saved = [{'保存元': target.relative_to(ROOT).as_posix(),
                '復元先': primary.relative_to(ROOT).as_posix(), '形式': '同体',
                '保存SHA256': expected, '解凍SHA256': expected,
                '保存bytes': target.stat().st_size, '解凍bytes': primary.stat().st_size}]
        else:
            saved = [lib.save_file(primary, target, expected)]
        # ----------------------------------------
        # 事前固定に含まれないREADME/準備票も後発として時点を分離します。
        prior = ROOT / 'work/152純判定と運転の独立準備'
        extra = {f: lib.sha(f) for f in prior.iterdir() if f.is_file() and f.suffix in ('.py', '.json', '.md', '.txt')}
        files.update(extra)
    else:
        files = {f: lib.sha(f) for f in args.folder.rglob('*')
                 if f.is_file() and f.suffix in ('.py', '.json', '.md', '.txt') and '__pycache__' not in f.parts}
        saved = []
        for f, expected in list(files.items()):
            if f.name == '短報.md':
                saved.append(lib.save_file(f, FORMAL / '根拠/固定P65から複合回復へ変えた結果.md', expected))
            elif f.suffix == '.json' and f.stat().st_size > 100_000:
                saved.append(lib.save_file(f, FORMAL / '根拠' / (f.stem + '.json.gz'), expected, True))
    for record in saved:
        existing[record['復元先']] = record
    refs = lib.resolve({f.relative_to(ROOT).as_posix(): expected for f, expected in files.items()},
                       key, existing)
    index[key] = {'停止SHA256': args.stop_sha256, '正本': saved, '復元参照': refs,
                  'F0_F1事前固定へ遡及': False, '新ルール採用': False}
    index_path.write_bytes(lib.json_bytes(index))
    print(json.dumps({'成功': True, '保存区分': key, '小型源': len(files),
                       '索引SHA256': lib.sha(index_path)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
