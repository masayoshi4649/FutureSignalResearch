"""133期限別集計を、自然結果を開かず可変cohortと未知の人工境界で確認する。"""
from pathlib import Path
import copy
import importlib.util
import subprocess
import sys
import unittest

OWN = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('133人工用CLI', OWN / '集計する.py')
RUN = importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(RUN)
C = RUN.CALC


def quote(at: float, index: int, bid: float = 1000, ask: float = 1010, last: float = 1005) -> dict:
    """
    機能: 人工の正常Quoteを作る。
    引数: at/bid/ask/last(float)、index(int)。返り値: dict。
    """
    return {'clock': '人工', 'time': at, 'index': index, 'source_line': index + 1,
            'bid': bid, 'ask': ask, 'last': last, 'quote_ok': True}


# ----------------------------------------
def candidate(side: int, entry: dict, chart: bool, unknown: bool) -> dict:
    """
    機能: 両H・全5幅の独立した正逆価格観測を人工生成する。
    引数: side(int)、entry(dict)、chart/unknown(bool)。返り値: dict。
    """
    price = entry['last'] if chart else entry['ask'] if side == 1 else entry['bid']
    point = quote(entry['time'] + 5, entry['index'] + 1, 1140, 1150, 1145)
    mark = point['last'] if chart else point['bid'] if side == 1 else point['ask']
    gain = side * (mark - price); outcomes = []
    for h in (1800, 3600):
        lost = unknown and h == 3600
        endpoint = None if lost else quote(entry['time'] + h, entry['index'] + 2, 1140, 1150, 1145)
        touches = []
        for width in (25, 50, 100, 125, 200):
            direction = 0 if lost else 1 if gain >= width else -1 if gain <= -width else 0
            touches.append({'width': width, 'direction': direction, 'quote': copy.deepcopy(point) if direction else None})
        outcomes.append({'seconds': h, 'deadline': entry['time'] + h, 'status': 'gap_censored' if lost else 'complete',
                         'touches': touches, 'endpoint': endpoint, 'points': None if lost else gain,
                         'net0': None if chart or lost else gain * 100 - 77,
                         'net5': None if chart or lost else gain * 100 - 1077})
    return {'status': 'filled', 'birth': {'side': side}, 'entry': copy.deepcopy(entry), 'entry_price': price,
            'outcomes': outcomes}


# ----------------------------------------
def fixture() -> tuple[dict, dict, dict]:
    """
    機能: L0は2件、L1は3件、0取得場を含む全73場を作る。
    引数: なし。返り値: tuple[dict,dict,dict]は結果/metadata/固定入力。
    """
    fixed_scenes = []; result_scenes = []; entries = []; coverage = {}; sessions = [f'人工{i:03d}' for i in range(73)]
    for i, sid in enumerate(sessions):
        start = 10000 + i * 20000; raw = {'path': '未作成の人工原板', 'sha256': 'a' * 64}
        quality = {'lines': 100, 'source_parser_accepted': 100, 'source_delivered': 100}
        fixed = {'session': sid, 'start': start, 'end': start + 10000, 'force_close': start + 9400,
                 'raw': raw, 'expected_quality': quality, 'entries': []}
        scene = {'session': sid, 'success': True, 'raw': raw, 'actual_sha256': raw['sha256'],
                 'stat_before': {'bytes': 100}, 'stat_after': {'bytes': 100}, 'quality': quality, 'expected_quality': quality,
                 'execution_end': start + 9700, 'source_force_close': start + 9400, 'effective_entry_limit': start + 6100,
                 'source_entries': 0, 'cases': []}
        coverage[sid] = {'L0': False, 'L1': False}
        for model in ('L0', 'L1'):
            if not ((model == 'L0' and i in (0, 48)) or (model == 'L1' and i in (0, 1, 72))): continue
            identity = model + '/' + sid; source_id = sid; entry = quote(start + 100, 2)
            b = quote(start + 98, 1)
            birth = {'id': source_id, 'side': 1, 'time': b['time'], 'index': b['index'], 'source_line': b['source_line'], 'quote': b}
            fields = {k: {'known': True, 'value': v} for k, v in
                      (('body5_signed_ratio_to_source', 0), ('ema21_delta30_to_B0', 1), ('hist5_atr_to_B0', .2), ('atr5', 10))}
            d = {'source_side': 1, 'b0_side': 1, 't8_side': -1, 'selected_side': -1, 'e0_protected': False,
                 'fields': fields, 'refs': [{'id': '人工足', 'width_seconds': 300, 'end': start + 30,
                                           'delivered': {'time': start + 90, 'index': 0, 'source_line': 1}}]}
            m = {'session': sid, 'id': identity, 'model': model, 'source_id': source_id,
                 'legacy_id': source_id if model == 'L0' else None, 'source_side': 1, 'selected_side': -1,
                 'strategy': 'trend', 'path': 'strong', 'birth': birth, 'entry': entry, 'direction': d}
            case = {'id': identity, 'original_side': 1}
            for name, side, chart in (('original', 1, False), ('reverse', -1, False), ('chart_original', 1, True), ('chart_reverse', -1, True)):
                case[name] = candidate(side, entry, chart, model == 'L1' and i == 72)
            scene['cases'].append(case); fixed['entries'].append({'id': identity, 'side': 1, 'entry': entry})
            entries.append(m); coverage[sid][model] = True
        scene['source_entries'] = len(scene['cases']); fixed_scenes.append(fixed); result_scenes.append(scene)
    fixed = {'scenes': fixed_scenes, 'expected_entry_count': len(entries)}
    metadata = {'success': True, 'trial': 133, 'new_outcomes_read': False, 'fixed_input_sha256': '人工固定入力',
                'sessions': sessions, 'entries': entries, 'counts': {'L0': 2, 'L1': 3}, 'coverage': coverage}
    result = {'success': True, 'trial': 133, 'input_sha256': '人工固定入力', 'scene_count': 73,
              'widths': [25, 50, 100, 125, 200], 'horizons': [1800, 3600], 'source_entry_count': len(entries), 'scenes': result_scenes}
    return result, metadata, fixed


# ----------------------------------------
class Artificial133(unittest.TestCase):
    """母集団・分母・取得時計・未知の混同を人工で拒否する。"""

    def setUp(self) -> None:
        """
        機能: 各検査へ独立した人工集合と私有算術moduleを用意する。
        引数: self(Artificial133)。返り値: None。
        """
        self.result, self.meta, self.fixed = fixture()
        self.rows, self.sessions, self.phase = RUN.prepare_records(self.result, self.meta, self.fixed)
        self.module = C.load_arithmetic()
        self.aggregate, self.coverage = C.aggregate(self.rows, self.sessions, self.module)

    def test_可変cohortと前後分割を混ぜない(self) -> None:
        """
        機能: 2対3取得と前後48/25を別に集計する。
        引数: self(Artificial133)。返り値: None。
        """
        for p in ('O0', 'L0'): self.assertEqual(self.aggregate['all'][p]['BBO']['3600']['125']['entries'], 2)
        for p in ('O1', 'L1', 'R1'): self.assertEqual(self.aggregate['all'][p]['BBO']['3600']['125']['entries'], 3)
        self.assertEqual(self.aggregate['validation']['L0']['BBO']['3600']['125']['entries'], 1)
        self.assertEqual(self.aggregate['validation']['L1']['BBO']['3600']['125']['entries'], 1)
        self.assertFalse(C.goal(self.aggregate, self.coverage)['両条件達成'])
        self.assertEqual(self.coverage['all']['L1']['未取得場数'], 70)

    def test_0取得と0knownを0円にしない(self) -> None:
        """
        機能: 空集合と観測不足だけの金額を未知にする。
        引数: self(Artificial133)。返り値: None。
        """
        empty, participation = C.aggregate([], self.sessions, self.module)
        s = empty['all']['L1']['BBO']['3600']['125']
        self.assertEqual((s['entries'], s['ifd_known']), (0, 0)); self.assertIsNone(s['ifd_net5_sum'])
        self.assertFalse(C.goal(empty, participation)['到達済み先着70%以上'])
        rows = [r for r in self.rows if r['model'] == 'L1' and r['session'] == '人工072']
        s = self.module.stats(rows, 'L1', 'BBO', 3600, 125)
        self.assertEqual((s['ifd_known'], s['ifd_unknown']), (0, 1)); self.assertIsNone(s['ifd_net5_profit'])

    def test_既知0円とLast金額null(self) -> None:
        """
        機能: 既知の金額0と未知を区別し、Lastへ金額を作らない。
        引数: self(Artificial133)。返り値: None。
        """
        for part in self.aggregate.values():
            for p in C.POLICIES:
                for horizons in part[p]['Last'].values():
                    for s in horizons.values(): self.assertIsNone(s['ifd_net5_sum'])
        self.module.ifd = lambda *args: {'known': True, 'reason': '人工の既知0', 'points': 0, 'net0': 0, 'net5': 0}
        s = self.module.stats(C.subset(self.rows, 'L1', self.sessions), 'L1', 'BBO', 3600, 125)
        self.assertEqual((s['ifd_known'], s['ifd_net5_sum']), (3, 0))

    def test_同群だけペア差を作る(self) -> None:
        """
        機能: 主L1と同群O1だけをペア化し、L0/L1を拒否する。
        引数: self(Artificial133)。返り値: None。
        """
        p = C.paired(self.rows, 'L1', 'O1', self.module)
        self.assertEqual((p['両側既知'], p['両側未知'], p['C5既知ペア差引円']), (2, 1, -56000))
        with self.assertRaises(AssertionError): C.paired(self.rows, 'L1', 'L0', self.module)
        with self.assertRaises(AssertionError): C.selected(self.rows[0], 'L1', 'BBO')

    def test_bootstrapはL1とO1だけ(self) -> None:
        """
        機能: L0を加えても主のクラスタ再標本化を変えない。
        引数: self(Artificial133)。返り値: None。
        """
        a = C.bootstrap(self.rows, self.sessions); b = C.bootstrap([r for r in self.rows if r['model'] == 'L1'], self.sessions)
        self.assertEqual(a, b); self.assertEqual((a['回数'], a['seed']), (5000, 124))
        self.assertEqual(a['政策']['L1']['O1との同群両側既知ペア平均差95区間'], [-28000, -28000])
        self.assertFalse(a['異なる取得時計のL0とL1をcaseペア化'])

    def test_3表と適用外nullと未取得場(self) -> None:
        """
        機能: 入口5行・全73行を保持し、別cohortへ0円を入れない。
        引数: self(Artificial133)。返り値: None。
        """
        tables = C.tables(self.rows, self.sessions, self.aggregate, self.coverage, self.module)
        self.assertEqual([len(t['rows']) for t in tables], [300, 5, 73])
        detail = tables[1]; row = detail['rows'][0]
        self.assertEqual(row[detail['headers'].index('取得集合')], 'L0')
        self.assertIsNone(row[detail['headers'].index('L1向き')]); self.assertIsNone(row[detail['headers'].index('L1125C5代用円')])
        sessions = tables[2]; empty = sessions['rows'][2]
        self.assertEqual(empty[sessions['headers'].index('L1取得数')], 0)
        self.assertIsNone(empty[sessions['headers'].index('L1C5既知差引円')])

    def test_未来phaseと結合改変を拒否(self) -> None:
        """
        機能: 同件数でも方向・Quote・phaseが違えば保存前に拒否する。
        引数: self(Artificial133)。返り値: None。
        """
        bad = copy.deepcopy(self.meta); bad['entries'][0]['selected_side'] *= -1
        with self.assertRaises(AssertionError): RUN.prepare_records(self.result, bad, self.fixed)
        bad = copy.deepcopy(self.result); case = bad['scenes'][0]['cases'][0]
        case['original']['outcomes'][0]['touches'][0]['quote']['time'] = bad['scenes'][0]['execution_end']
        with self.assertRaises(AssertionError): RUN.prepare_records(bad, self.meta, self.fixed)
        bad = copy.deepcopy(self.result); bad['scenes'][0]['cases'][0]['chart_original']['outcomes'][0]['net0'] = 1
        with self.assertRaises(AssertionError): RUN.prepare_records(bad, self.meta, self.fixed)

    def test_F1なしCLIは読取前に拒否(self) -> None:
        """
        機能: 入力SHA/F1を省略した自然CLIを開始しない。
        引数: self(Artificial133)。返り値: None。
        """
        r = subprocess.run([sys.executable, '-X', 'utf8', str(OWN / '集計する.py')], capture_output=True, text=True, encoding='utf-8')
        self.assertEqual(r.returncode, 2); self.assertIn('--f1', r.stderr)


if __name__ == '__main__':
    unittest.main(verbosity=2)
