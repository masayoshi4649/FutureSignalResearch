"""133の非金融Source生成をF0で固定し、元79同体検査後に金融前入力へ渡す。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
PLAN = ROOT / 'work/強い入口の探索期限を延ばす次仮説'
OWN = ROOT / 'work/133探索期限の評価'
FORMAL = ROOT / 'study/00133_全場参加を維持して強い入口の探索期限を延ばす'
INPUT = ROOT / 'work/122全場入力/入力.json'
INPUT_SHA = '6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec'
SOURCE_EXE = PLAN / 'Source入口の再生器/Source入口.exe'
SOURCE_EXE_SHA = 'e6d216ffbbc9ec8d640d5d482d163de3ac289c1f46392469abb9d66eb47a905e'
PREP = PLAN / '準備の確認.json'
PREP_SHA = '86c6669f29b6d9f175b514258783689efdd9e5cab40412a1c9c8faff85381b2e'


def sha(path: Path) -> str:
    """
    機能: ファイル全体の指紋を計算する。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def save(path: Path, value: dict) -> None:
    """
    機能: 未作成のJSONへUTF-8で保存する。
    引数: path(Path)、value(dict)。
    返り値: None。
    """
    with path.open('x', encoding='utf-8', newline='\n') as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False); handle.write('\n')


# ----------------------------------------
def verify(fixed: dict) -> None:
    """
    機能: 出生前に固定した全宣言ファイルの現在指紋を確認する。
    引数: fixed(dict)はF0の内容。
    返り値: None。不一致は直ちに停止する。
    """
    for name, expected in fixed['ファイル'].items():
        assert sha(Path(name)) == expected, name


# ----------------------------------------
def main() -> None:
    """
    機能: 出生前固定と明示Source走査を分け、L0同体確認後だけ転送する。
    引数: CLI --mode(str、固定/出生)を使用する。
    返り値: None。このスクリプトは正逆金融走査を行わない。
    """
    parser = argparse.ArgumentParser(description='133の出生前固定とSource非金融走査')
    parser.add_argument('--mode', choices=('固定', '出生'), required=True)
    args = parser.parse_args()
    OWN.mkdir(parents=True, exist_ok=True)
    f0 = OWN / 'F0.json'
    if args.mode == '固定':
        assert sha(INPUT) == INPUT_SHA and sha(PREP) == PREP_SHA and sha(SOURCE_EXE) == SOURCE_EXE_SHA
        preparation = json.loads(PREP.read_text('utf-8'))
        assert preparation['success'] and preparation['natural_raw_read'] is False
        assert preparation['financial_labels_generated'] is False
        files = {ROOT / name for name in preparation['source_and_dependency_hashes']}
        for name, expected in preparation['source_and_dependency_hashes'].items():
            assert sha(ROOT / name) == expected, name
        files.update((INPUT, PREP, SOURCE_EXE, Path(__file__).resolve(), ROOT / 'work/133Source取得を固定入力へ渡す.py',
                      ROOT / 'inputs/00124_同入口正逆の共用入力/入力.json.gz',
                      ROOT / 'work/T8の15分位相による切替案/choices.json'))
        for folder in (FORMAL, ROOT / 'work/133固定取得の正逆評価器'):
            files.update(p for p in folder.rglob('*') if p.is_file() and p.suffix in ('.go', '.mod', '.py', '.md', '.exe'))
        files.update(p for p in PLAN.glob('*') if p.is_file() and p.suffix in ('.py', '.md', '.json'))
        save(f0, {'成功': True, '試行': 133, '段階': '出生前F0', 'UTC': datetime.now(timezone.utc).isoformat(),
                  '主': 'L1・P3の強い技術入口をEnd−4020まで探索、全73最低1取得とH60±125で70%の両条件',
                  '対照': 'L0旧3h。E0保護と固定T8、Source geometry後の正逆方向診断',
                  'Source走査は非金融': True, '次の正逆金融は別F1が必要': True,
                  'ファイル': {str(p): sha(p) for p in sorted(files)}})
        print(json.dumps({'F0_SHA256': sha(f0), '固定ファイル数': len(files)}, ensure_ascii=False)); return
    fixed = json.loads(f0.read_text('utf-8')); verify(fixed)
    output = OWN / 'Sourceの出生と取得.json'
    command = [str(SOURCE_EXE), '--input', str(INPUT), '--expected-sha', INPUT_SHA,
               '--output', str(output), '--workers', '8', '--execute-after-f0']
    print('固定済みSource出生・取得を走査。新しい先着・金融計算はしません。', flush=True)
    subprocess.run(command, cwd=ROOT, check=True); verify(fixed)
    source = json.loads(output.read_text('utf-8'))
    assert source['scene_count'] == len(source['scenes']) == 73
    assert all(scene['success'] for scene in source['scenes']) and source['outcomes_computed'] is False
    result_sha = sha(output)
    check_command = [sys.executable, '-X', 'utf8', str(PLAN / 'L0と旧79件を照合する.py'),
                     '--result', str(output), '--expected-sha', result_sha, '--output', str(OWN / 'L0旧79の同体確認.json')]
    subprocess.run(check_command, cwd=ROOT, check=True); verify(fixed)
    transfer_command = [sys.executable, '-X', 'utf8', str(ROOT / 'work/133Source取得を固定入力へ渡す.py'),
                        '--source', str(output), '--sha256', result_sha, '--output-dir', str(OWN / '固定入力')]
    subprocess.run(transfer_command, cwd=ROOT, check=True); verify(fixed)
    assert sha(output) == result_sha
    save(OWN / '出生段階の完了.json', {'成功': True, '試行': 133, 'F0_SHA256': sha(f0),
          'Source_SHA256': result_sha, '全固定源前後同体': True, 'L0旧79確認SHA256': sha(OWN / 'L0旧79の同体確認.json'),
          '固定取得入力SHA256': sha(OWN / '固定入力/固定取得入力.json'),
          '方向と出生SHA256': sha(OWN / '固定入力/方向と出生.json'), '新金融未実行': True,
          '実行列': [command, check_command, transfer_command]})
    print('133の非金融Source・L0同体・金融前入力の固定が完了。', flush=True)


if __name__ == '__main__':
    main()
