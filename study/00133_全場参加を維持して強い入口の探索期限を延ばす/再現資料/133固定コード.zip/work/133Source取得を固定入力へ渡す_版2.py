"""133の非金融Source取得を固定正逆入力と小型方向metadataへ渡す。"""
from pathlib import Path
from collections import Counter
import argparse
import gzip
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parent.parent
METADATA = ROOT / 'inputs/00124_同入口正逆の共用入力/入力.json.gz'
DECODED_SHA = 'b2368b1f42c16e8c96a3acd098c58a902807a3b6a5023d6d4b1e75261f3ee51b'
SOURCE_INPUT_SHA = '6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec'
BASE_CHOICES = ROOT / 'work/T8の15分位相による切替案/choices.json'
BASE_CHOICES_SHA = 'cdf1f0c6248d76222d49c7d872094cce20edecb7f52aa9e725d1040aa51f17c3'


def digest(data: bytes) -> str:
    """
    機能: bytesの指紋を求める。
    引数: data(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(data).hexdigest()


# ----------------------------------------
def number(fields: dict, key: str) -> float | None:
    """
    機能: Goの既知maskと有限値を保ち、未知の格納0を数値に使わない。
    引数: fields(dict)、key(str)。
    返り値: float|None。
    """
    value = fields[key]
    assert type(value['known']) is bool
    if not value['known']:
        return None
    result = value['value']
    assert type(result) in (int, float) and math.isfinite(result)
    return result


# ----------------------------------------
def verify_direction(direction: dict, original: int, path: str) -> None:
    """
    機能: Source生成時に凍結したB0/T8/E0保護の式を独立に再確認する。
    引数: direction(dict)、original(int)、path(str)。
    返り値: None。不一致で停止する。
    """
    assert type(original) is int and original in (-1, 1)
    fields = direction['fields']
    body = number(fields, 'body5_signed_ratio_to_source')
    b0 = -original if body is not None and .5 <= body < .75 else original
    long = number(fields, 'ema21_delta30_to_B0')
    hist = number(fields, 'hist5_atr_to_B0')
    t8 = -b0 if long is not None and long >= 0 and hist is not None and hist >= .1 else b0
    assert direction['source_side'] == original and direction['b0_side'] == b0 and direction['t8_side'] == t8
    assert direction['e0_protected'] is (path == 'E0')
    assert direction['selected_side'] == (original if path == 'E0' else t8)
    width = number(fields, 'high5') - number(fields, 'low5')
    assert width >= 0 and width == number(fields, 'range5')
    if width > 0:
        expected = original * (number(fields, 'close5') - number(fields, 'open5')) / width
        assert body is not None and math.isclose(body, expected, rel_tol=1e-12, abs_tol=1e-12)
    else:
        assert body is None


# ----------------------------------------
def save(path: Path, value: dict) -> str:
    """
    機能: 未作成先へUTF-8のJSONを保存する。
    引数: path(Path)、value(dict)。
    返り値: strは保存bytesのSHA256。
    """
    with path.open('x', encoding='utf-8', newline='\n') as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False); handle.write('\n')
    return digest(path.read_bytes())


# ----------------------------------------
def main() -> None:
    """
    機能: F0後のSource結果を指紋照合し、金融前に固定する二つの入力を作る。
    引数: CLI --source(Path)、--sha256(str)、--output-dir(Path)を使用する。
    返り値: None。正逆結果・原板・新しい金融値を読み込まない。
    """
    parser = argparse.ArgumentParser(description='133の非金融Sourceから固定取得へ渡す')
    parser.add_argument('--source', required=True, type=Path)
    parser.add_argument('--sha256', required=True)
    parser.add_argument('--output-dir', required=True, type=Path)
    args = parser.parse_args()
    body = args.source.read_bytes(); assert digest(body) == args.sha256
    source = json.loads(body)
    assert source['trial'] == 133 and source['input_sha256'] == SOURCE_INPUT_SHA
    assert source['scene_count'] == len(source['scenes']) == 73 and source['outcomes_computed'] is False
    assert source['selected_direction_order_eligibility_rebuilt'] is False
    raw_metadata = gzip.decompress(METADATA.read_bytes()); assert digest(raw_metadata) == DECODED_SHA
    base = json.loads(raw_metadata)
    old_body = BASE_CHOICES.read_bytes(); assert digest(old_body) == BASE_CHOICES_SHA
    old_choices = {(r['session'], r['id']): r for r in json.loads(old_body)['choices']}
    assert len(old_choices) == 79
    assert len(base['scenes']) == 73
    assert [s['session'] for s in base['scenes']] == [s['session'] for s in source['scenes']]
    scenes, rows, coverage, attempts = [], [], {}, {}
    for meta, scene in zip(base['scenes'], source['scenes']):
        sid = meta['session']
        assert scene['success']
        assert all(scene['raw'][key] == meta['raw'][key] for key in ('path', 'sha256'))
        assert scene['actual_sha256'] == meta['raw']['sha256']
        assert set(meta['raw']) <= {'path', 'sha256', 'bytes', 'mod_time_ns'}
        for key in ('bytes', 'mod_time_ns'):
            stat_key = 'mtime_ns' if key == 'mod_time_ns' else key
            if key in meta['raw']:
                assert scene['stat_before'][stat_key] == meta['raw'][key]
            if key in scene['raw']:
                assert scene['stat_before'][stat_key] == scene['raw'][key]
        assert scene['quality'] == scene['expected_quality'] == meta['expected_quality']
        assert scene['stat_before'] == scene['stat_after']
        cutoff = min(meta['force_close'], meta['end'] - 3900)
        assert scene['source_force_close'] == meta['force_close'] and scene['entry_cutoff'] == cutoff
        assert scene['execution_end'] == meta['end'] - 300
        assert scene['fallback_at'] == {'L0': meta['start'] + 10800, 'L1': meta['end'] - 4020}
        fixed = {k: meta[k] for k in ('session', 'contract', 'start', 'end', 'force_close', 'raw', 'expected_accepted', 'expected_quality')}
        fixed['entries'] = []
        counts = Counter(); statuses = {'L0': Counter(), 'L1': Counter()}
        for candidate in scene['candidates']:
            model = candidate['policy']
            if model not in ('L0', 'L1'):
                assert model == 'E0'
                continue
            assert 'outcomes' not in candidate and 'last_normal_time' not in candidate
            statuses[model][candidate['status']] += 1
            quote = candidate['entry']
            if quote is None:
                continue
            assert candidate['status'] == 'filled'
            birth = candidate['birth']; original = birth['side']; direction = candidate['direction']
            verify_direction(direction, original, candidate['path'])
            assert birth['quote']['time'] == birth['time'] and birth['quote']['index'] == birth['index']
            assert birth['quote']['source_line'] == birth['source_line']
            assert all(birth[k] <= quote[k] for k in ('time', 'index', 'source_line'))
            assert meta['start'] <= birth['time'] <= quote['time'] < cutoff
            assert quote['quote_ok'] and 0 < quote['bid'] < quote['ask']
            assert candidate['entry_price'] == (quote['ask'] if original == 1 else quote['bid'])
            for ref in direction['refs']:
                assert ref['end'] <= ref['delivered']['time']
                assert all(ref['delivered'][k] <= birth[k] for k in ('time', 'index', 'source_line'))
            assert any(ref['width_seconds'] == 300 for ref in direction['refs'])
            identity = model + '/' + birth['id']
            strategy = 'E0' if candidate['path'] == 'E0' else candidate['decision']['strategy']
            assert strategy in ('E0', 'trend', 'reversal', 'deadline')
            fixed['entries'].append({'id': identity, 'side': original, 'entry': quote})
            rows.append({'session': sid, 'id': identity, 'model': model, 'source_id': birth['id'],
                         'legacy_id': birth['id'].replace('/補完/L0/', '/補完/P3/') if model == 'L0' else None,
                         'source_side': original, 'selected_side': direction['selected_side'],
                         'strategy': strategy, 'path': candidate['path'], 'birth': birth, 'entry': quote,
                         'direction': direction})
            counts[model] += 1
        assert all(scene['coverage'][model] == bool(counts[model]) for model in ('L0', 'L1'))
        coverage[sid] = {model: bool(counts[model]) for model in ('L0', 'L1')}
        attempts[sid] = {model: dict(statuses[model]) for model in ('L0', 'L1')}
        assert len({entry['id'] for entry in fixed['entries']}) == len(fixed['entries'])
        scenes.append(fixed)
    assert len({(r['session'], r['id']) for r in rows}) == len(rows)
    old_rows = [r for r in rows if r['model'] == 'L0']
    assert len(old_rows) == 79 and {(r['session'], r['legacy_id']) for r in old_rows} == set(old_choices)
    for row in old_rows:
        old = old_choices[row['session'], row['legacy_id']]
        assert row['source_side'] == old['original_side'] and row['selected_side'] == old['choices']['T8']['side']
        assert row['strategy'] == old['strategy'] and row['path'] == old['path']
        assert all(row['birth'][k] == old['birth'][k] and row['entry'][k] == old['entry'][k]
                   for k in ('time', 'index', 'source_line'))
    assert digest(BASE_CHOICES.read_bytes()) == BASE_CHOICES_SHA
    assert digest(args.source.read_bytes()) == args.sha256
    args.output_dir.mkdir(parents=True, exist_ok=False)
    input_sha = save(args.output_dir / '固定取得入力.json', {'scenes': scenes, 'expected_entry_count': len(rows)})
    metadata_sha = save(args.output_dir / '方向と出生.json', {'success': True, 'trial': 133,
        'source_sha256': args.sha256, 'fixed_input_sha256': input_sha,
        'source_input_sha256': SOURCE_INPUT_SHA, 'sessions': [s['session'] for s in scenes],
        'entries': rows, 'coverage': coverage, 'attempts': attempts,
        'counts': dict(Counter(r['model'] for r in rows)), 'new_outcomes_read': False})
    save(args.output_dir / '転送の確認.json', {'成功': True, '試行': 133, 'Source前後SHA256': args.sha256,
         '固定取得入力SHA256': input_sha, '方向と出生SHA256': metadata_sha, '全場': 73,
         '取得件数': dict(Counter(r['model'] for r in rows)),
         '取得場数': {model: sum(c[model] for c in coverage.values()) for model in ('L0', 'L1')},
         'L0旧79の方向と出生取得時計同体': True, '旧方向票SHA256': BASE_CHOICES_SHA,
         '原板読取': False, '新金融読取': False, 'コードSHA256': digest(Path(__file__).read_bytes())})
    print(json.dumps({'成功': True, '固定取得入力SHA256': input_sha, '方向と出生SHA256': metadata_sha}, ensure_ascii=False))


if __name__ == '__main__':
    main()
