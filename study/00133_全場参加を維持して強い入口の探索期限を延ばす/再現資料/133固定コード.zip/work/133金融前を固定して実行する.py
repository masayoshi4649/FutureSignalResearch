"""133のSource取得と方向をF1で固定し、正逆観測と集計を別の明示段階で実行する。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
OWN = ROOT / 'work/133探索期限の評価'
FIXED = OWN / '固定入力/固定取得入力.json'
META = OWN / '固定入力/方向と出生.json'
KERNEL = ROOT / 'work/133固定取得の正逆評価器/固定取得の正逆評価.exe'
AGG = ROOT / 'work/133期限別の集計'
FORMAL = ROOT / 'study/00133_全場参加を維持して強い入口の探索期限を延ばす'


def sha(path: Path) -> str:
    """
    機能: ファイル全体の指紋を求める。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def save(path: Path, value: dict) -> None:
    """
    機能: UTF-8のJSONを未作成先へ保存する。
    引数: path(Path)、value(dict)。
    返り値: None。
    """
    with path.open('x', encoding='utf-8', newline='\n') as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False); handle.write('\n')


# ----------------------------------------
def verify(fixed: dict) -> None:
    """
    機能: 金融前に固定した全宣言ファイルを照合する。
    引数: fixed(dict)はファイルとSHAの対応表を持つ。
    返り値: None。不一致で停止する。
    """
    for name, expected in fixed['ファイル'].items():
        assert sha(Path(name)) == expected, name


# ----------------------------------------
def verify_result(data: dict, fixed_input: dict) -> None:
    """
    機能: 全73場・全固定取得・正逆観測の対象とphase境界を確認する。
    引数: data(dict)は正逆観測、fixed_input(dict)はF1入力。
    返り値: None。境界以後の価格を許可しない。
    """
    assert data['success'] and data['trial'] == 133 and data['scene_count'] == len(data['scenes']) == 73
    assert data['source_entry_count'] == fixed_input['expected_entry_count']
    assert [s['session'] for s in data['scenes']] == [s['session'] for s in fixed_input['scenes']]
    for scene, original in zip(data['scenes'], fixed_input['scenes']):
        assert scene['success'] and scene['quality'] == original['expected_quality']
        assert scene['stat_before'] == scene['stat_after'] and scene['actual_sha256'] == original['raw']['sha256']
        end = original['end'] - 300; limit = min(original['force_close'], end - 3600)
        assert scene['execution_end'] == end and scene['effective_entry_limit'] == limit
        wanted = {c['id']: c for c in original['entries']}
        assert {c['id'] for c in scene['cases']} == set(wanted) and len(scene['cases']) == len(wanted)
        for case in scene['cases']:
            entry = wanted[case['id']]
            assert case['original_side'] == entry['side']
            for key in ('original', 'reverse', 'chart_original', 'chart_reverse'):
                candidate = case[key]
                assert candidate['entry'] == entry['entry'] and candidate['entry']['time'] < limit
                for outcome in candidate['outcomes']:
                    if outcome['endpoint'] is not None:
                        assert outcome['endpoint']['time'] < end
                    for touch in outcome['touches']:
                        if touch['quote'] is not None:
                            assert touch['quote']['time'] < end


# ----------------------------------------
def main() -> None:
    """
    機能: 金融前固定、正逆Raw観測、集計の三段階を実行する。
    引数: CLI --mode(str、固定/再生/集計)を使用する。
    返り値: None。主L1と全73場参加の条件を結果後に変更しない。
    """
    parser = argparse.ArgumentParser(description='133のF1固定後だけ正逆観測/金融集計を実行する')
    parser.add_argument('--mode', choices=('固定', '再生', '集計'), required=True)
    args = parser.parse_args()
    f1 = OWN / 'F1.json'
    if args.mode == '固定':
        f0 = json.loads((OWN / 'F0.json').read_text('utf-8')); verify(f0)
        assert sha(FIXED) == '5efb1b9ef1f1130d4507f926601f8cabe50757463d7523858351833abc6d0b5e'
        assert sha(META) == 'a328f6b902e9ace8d4d764974570f6beeacda91bd099933d1b716b68875a49d2'
        assert (AGG / '集計する.py').is_file() and (AGG / '人工検査.py').is_file() and (AGG / '条件.md').is_file()
        specification = importlib.util.spec_from_file_location('133金融前の集計宣言', AGG / '集計する.py')
        declared = importlib.util.module_from_spec(specification); specification.loader.exec_module(declared)
        assert all(sha(path) == expected for path, expected in declared.SOURCES.items())
        files = {Path(name) for name in f0['ファイル']}
        files.update(declared.SOURCES)
        files.update((OWN / 'F0.json', OWN / '出生段階の完了.json', OWN / 'Sourceの出生と取得.json',
                      OWN / 'L0旧79の同体確認.json', FIXED, META, OWN / '固定入力/転送の確認.json',
                      OWN / '転送形式の補修.md', ROOT / 'work/133Source取得を固定入力へ渡す_版2.py', Path(__file__).resolve(),
                      ROOT / 'work/124入口の原因分析/集計する.py',
                      ROOT / 'work/124入口の正逆比較/全73場の正逆結果.json',
                      ROOT / 'work/131既存入口の位相切替評価/集計.json'))
        for folder in (AGG, FORMAL):
            files.update(p for p in folder.rglob('*') if p.is_file() and p.suffix in ('.py', '.md', '.json'))
        save(f1, {'成功': True, '試行': 133, '段階': '金融前F1', 'UTC': datetime.now(timezone.utc).isoformat(),
                  '主': 'L1・全73場最低1取得と実BBO/H60±125で70%以上の両方',
                  '政策': ['O0', 'L0', 'O1', 'L1', 'R1'], '副の採用で主を交換しない': True,
                  'ファイル': {str(p): sha(p) for p in sorted(files)}})
        print(json.dumps({'F1_SHA256': sha(f1), '固定ファイル数': len(files)}, ensure_ascii=False)); return
    fixed = json.loads(f1.read_text('utf-8')); verify(fixed)
    output = OWN / '固定取得の正逆観測.json'
    if args.mode == '再生':
        command = [str(KERNEL), '--input', str(FIXED), '--sha256', sha(FIXED),
                   '--output', str(output), '--workers', '8']
        subprocess.run(command, cwd=ROOT, check=True); verify(fixed)
        verify_result(json.loads(output.read_text('utf-8')), json.loads(FIXED.read_text('utf-8')))
        save(OWN / '正逆観測の完了.json', {'成功': True, '試行': 133, 'F1_SHA256': sha(f1),
             '全固定源前後同体': True, '観測SHA256': sha(output), '実行列': command})
        return
    command = [sys.executable, '-X', 'utf8', str(AGG / '集計する.py'), '--f1', str(f1), '--f1-sha256', sha(f1),
               '--fixed-input', str(FIXED), '--fixed-input-sha256', sha(FIXED),
               '--metadata', str(META), '--metadata-sha256', sha(META),
               '--result', str(output), '--result-sha256', sha(output), '--output-dir', str(AGG)]
    subprocess.run(command, cwd=ROOT, check=True); verify(fixed)
    save(OWN / '金融段階の完了.json', {'成功': True, '試行': 133, 'F1_SHA256': sha(f1),
         '全固定源前後同体': True, '集計SHA256': sha(AGG / '集計.json'),
         'CSV用の表SHA256': sha(AGG / 'CSV用の表.json'), '実行列': command})


if __name__ == '__main__':
    main()
