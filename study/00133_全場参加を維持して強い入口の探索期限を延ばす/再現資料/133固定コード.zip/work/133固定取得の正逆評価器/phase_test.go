package holdingohlc113

import "testing"

// TestPhaseBoundary133 は終端等号の価格を先着・期限へ流さないことを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。自然データは使用しません。
func TestPhaseBoundary133(t *testing.T) {
	for _, chart := range []bool{false, true} {
		q := fixedQuoteTest133(100, 0, 995, 1005, 1000)
		c := fixedCandidate133("人工", 1, q, chart)
		x := fixedQuoteTest133(200, 1, 1995, 2005, 2000)
		if chart {
			chartOutcome133(c, x, 100, 200)
		} else {
			outcome133(c, x, 100, 200)
		}
		for _, o := range c.Outcomes {
			if o.Status != "phase_censored" || o.Endpoint != nil || o.Net5 != nil {
				t.Fatal("終端等号を清算へ使用")
			}
			for _, touch := range o.Touches {
				if touch.Direction != 0 || touch.Quote != nil {
					t.Fatal("終端等号を先着へ使用")
				}
			}
		}
	}
}

// TestKnownTouchBeforePhase133 は終端以前の既知先着を観測打切りで消さないことを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestKnownTouchBeforePhase133(t *testing.T) {
	q := fixedQuoteTest133(100, 0, 995, 1005, 1000)
	c := fixedCandidate133("人工", 1, q, false)
	x := fixedQuoteTest133(199, 1, 1140, 1150, 1145)
	outcome133(c, x, 100, 200)
	outcome133(c, fixedQuoteTest133(500, 2, 500, 510, 505), 199, 200)
	for _, o := range c.Outcomes {
		if o.Status != "phase_censored" || o.Touches[3].Direction != 1 || o.Touches[3].Quote.Time != 199 {
			t.Fatal("既知125先着を変更")
		}
	}
}

// TestCompleteBeforePhase133 は既に完了した観測へ終端の新情報を混ぜないことを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestCompleteBeforePhase133(t *testing.T) {
	q := fixedQuoteTest133(100, 0, 995, 1005, 1000)
	c := fixedCandidate133("人工", 1, q, false)
	for i := range c.Outcomes {
		c.Outcomes[i].Status = "complete"
	}
	if !phaseCut133(c, fixedQuoteTest133(200, 1, 500, 510, 505), 200) {
		t.Fatal("境界判定差")
	}
	for _, o := range c.Outcomes {
		if o.Status != "complete" {
			t.Fatal("完了済みを打切りへ変更")
		}
	}
}

// TestLatestEntryBoundary133 は60分を残せない取得の等号を入力段階で拒否します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestLatestEntryBoundary133(t *testing.T) {
	s := rawFixtureTest133(t, false)
	s.End = s.Entries[0].Entry.Time + 300 + 3600
	if _, err := validateEntries133(s); err == nil {
		t.Fatal("H60限界等号を許可")
	}
}
