package holdingohlc113

import (
	"bufio"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"os"
	"sync"
)

var Widths133 = []float64{25, 50, 100, 125, 200}
var Horizons133 = []float64{1800, 3600}

type FixedEntry133 struct {
	ID    string `json:"id"`
	Side  int    `json:"side"`
	Entry Quote  `json:"entry"`
}
type Scene133 struct {
	Session          string          `json:"session"`
	Contract         string          `json:"contract"`
	Start            float64         `json:"start"`
	End              float64         `json:"end"`
	ForceClose       float64         `json:"force_close"`
	Raw              FileRef         `json:"raw"`
	ExpectedAccepted int64           `json:"expected_accepted"`
	ExpectedQuality  *Counts         `json:"expected_quality"`
	Entries          []FixedEntry133 `json:"entries"`
}
type Input133 struct {
	Scenes             []Scene133 `json:"scenes"`
	ExpectedEntryCount int        `json:"expected_entry_count"`
}
type Signal133 struct {
	ID    string  `json:"id"`
	Side  int     `json:"side"`
	Time  float64 `json:"time"`
	Index int64   `json:"index"`
	Line  int64   `json:"source_line"`
	Quote Quote   `json:"quote"`
}
type First133 struct {
	Width     float64 `json:"width"`
	Direction int     `json:"direction"`
	Quote     *Quote  `json:"quote"`
}
type Outcome133 struct {
	Seconds  float64    `json:"seconds"`
	Deadline float64    `json:"deadline"`
	Status   string     `json:"status"`
	Touches  []First133 `json:"touches"`
	Endpoint *Quote     `json:"endpoint"`
	Points   *float64   `json:"points"`
	Net0     *float64   `json:"net0"`
	Net5     *float64   `json:"net5"`
}
type Candidate133 struct {
	Status         string       `json:"status"`
	Axis           string       `json:"axis"`
	Birth          Signal133    `json:"birth"`
	Entry          *Quote       `json:"entry"`
	EntryPrice     *float64     `json:"entry_price"`
	LastNormalTime float64      `json:"last_normal_time"`
	Outcomes       []Outcome133 `json:"outcomes"`
}
type Case133 struct {
	ID            string        `json:"id"`
	OriginalSide  int           `json:"original_side"`
	Original      *Candidate133 `json:"original"`
	Reverse       *Candidate133 `json:"reverse"`
	ChartOriginal *Candidate133 `json:"chart_original"`
	ChartReverse  *Candidate133 `json:"chart_reverse"`
}
type Result133 struct {
	ExecutionEnd        float64    `json:"execution_end"`
	EffectiveEntryLimit float64    `json:"effective_entry_limit"`
	SourceForceClose    float64    `json:"source_force_close"`
	Session             string     `json:"session"`
	Success             bool       `json:"success"`
	Error               string     `json:"error,omitempty"`
	Raw                 FileRef    `json:"raw"`
	ActualSHA           string     `json:"actual_sha256"`
	Before              FileStat   `json:"stat_before"`
	After               FileStat   `json:"stat_after"`
	RawEncoding         string     `json:"raw_encoding"`
	Quality             Counts     `json:"quality"`
	ExpectedQuality     *Counts    `json:"expected_quality"`
	Cases               []*Case133 `json:"cases"`
	RawPasses           int        `json:"raw_passes"`
	SourceEntries       int        `json:"source_entries"`
}

// fixedCandidate133 は元の取得原行に正又は逆の取得価格を固定します。
//
// 引数: id(string)、side(int)、q(Quote)、chart(bool)。返り値: *Candidate133です。
func fixedCandidate133(id string, side int, q Quote, chart bool) *Candidate133 {
	price := q.Ask
	axis := "BBO"
	if side < 0 {
		price = q.Bid
	}
	if chart {
		price = q.Last
		axis = "Last価格方向診断"
	}
	x := q
	c := &Candidate133{Status: "filled", Axis: axis, Birth: Signal133{ID: id, Side: side, Time: q.Time, Index: q.Index, Line: q.SourceLine, Quote: q}, Entry: &x, EntryPrice: &price, LastNormalTime: q.Time, Outcomes: []Outcome133{}}
	for _, h := range Horizons133 {
		o := Outcome133{Seconds: h, Deadline: q.Time + h, Status: "pending", Touches: []First133{}}
		for _, w := range Widths133 {
			o.Touches = append(o.Touches, First133{Width: w})
		}
		c.Outcomes = append(c.Outcomes, o)
	}
	return c
}

// fixedCase133 は同じ取得原行のBBO正逆とLast参考正逆を一組にします。
//
// 引数: source(FixedEntry133)、q(Quote)。返り値: *Case133です。
func fixedCase133(source FixedEntry133, q Quote) *Case133 {
	return &Case133{ID: source.ID, OriginalSide: source.Side, Original: fixedCandidate133(source.ID, source.Side, q, false), Reverse: fixedCandidate133(source.ID, -source.Side, q, false), ChartOriginal: fixedCandidate133(source.ID, source.Side, q, true), ChartReverse: fixedCandidate133(source.ID, -source.Side, q, true)}
}

// candidates133 は同時刻から始まる四つの独立観測を返します。
//
// 引数: c(*Case133)。返り値: []*Candidate133です。
func candidates133(c *Case133) []*Candidate133 {
	return []*Candidate133{c.Original, c.Reverse, c.ChartOriginal, c.ChartReverse}
}

// stepCase133 はBBOに固定kernel、価格参考にmarkだけLastのkernelを適用します。
//
// 引数: c(*Case133)、q(Quote)、previous/end(float64)。返り値: boolは未完了が残る場合です。
func stepCase133(c *Case133, q Quote, previous, end float64) bool {
	outcome133(c.Original, q, previous, end)
	outcome133(c.Reverse, q, previous, end)
	chartOutcome133(c.ChartOriginal, q, previous, end)
	chartOutcome133(c.ChartReverse, q, previous, end)
	for _, candidate := range candidates133(c) {
		for _, o := range candidate.Outcomes {
			if o.Status == "pending" {
				return true
			}
		}
	}
	return false
}

// finalize133 は未完了を打切りにし、約定不可の参考観測の金額を保存しません。
//
// 引数: c(*Case133)。返り値: ありません。価格方向・先着の値は変更しません。
func finalize133(c *Case133) {
	for _, candidate := range candidates133(c) {
		for i := range candidate.Outcomes {
			o := &candidate.Outcomes[i]
			if o.Status == "pending" {
				o.Status = "eof_censored"
			}
			if candidate.Axis != "BBO" {
				o.Net0 = nil
				o.Net5 = nil
			}
		}
	}
}

// validateEntries133 は固定取得表の重複・時点・正常BBOをmetadataで確認します。
//
// 引数: s(Scene133)。返り値: map[int64][]FixedEntry133/errorは物理行別要求です。
func validateEntries133(s Scene133) (map[int64][]FixedEntry133, error) {
	byLine := map[int64][]FixedEntry133{}
	ids := map[string]bool{}
	for _, e := range s.Entries {
		q := e.Entry
		if e.ID == "" || ids[e.ID] || (e.Side != 1 && e.Side != -1) || !finite(q.Time, q.Last, q.Bid, q.Ask) || q.Time < s.Start || q.Time >= math.Min(s.ForceClose, s.End-300-3600) || q.Index < 0 || q.Index >= s.ExpectedAccepted || q.SourceLine < q.Index+1 || q.Clock == "" || !q.QuoteOK || !normal(q) || q.Last <= 0 {
			return nil, fmt.Errorf("固定取得のid/方向/時計/原行/BBO差:%s", e.ID)
		}
		ids[e.ID] = true
		byLine[q.SourceLine] = append(byLine[q.SourceLine], e)
	}
	return byLine, nil
}

// scan133 は全Rawを一走査し、元の取得原行を全項目同体で正逆観測へ結合します。
//
// 引数: s(Scene133)。返り値: Result133/errorです。新規判断やTTLを再実行しません。
func scan133(s Scene133) (out Result133, err error) {
	out = Result133{Session: s.Session, Raw: s.Raw, ExpectedQuality: s.ExpectedQuality, Cases: []*Case133{}, RawPasses: 1, SourceEntries: len(s.Entries), ExecutionEnd: s.End - 300, EffectiveEntryLimit: math.Min(s.ForceClose, s.End-300-3600), SourceForceClose: s.ForceClose}
	wanted, e := validateEntries133(s)
	if e != nil {
		return out, e
	}
	f, e := os.Open(s.Raw.Path)
	if e != nil {
		return out, e
	}
	defer f.Close()
	before, e := f.Stat()
	if e != nil {
		return out, e
	}
	out.Before = FileStat{Bytes: before.Size(), ModTimeNS: before.ModTime().UnixNano()}
	h := sha256.New()
	tee := io.TeeReader(f, h)
	z, encoding, e := rawStream133(tee)
	if e != nil {
		return out, e
	}
	defer z.Close()
	out.RawEncoding = encoding
	scan := bufio.NewScanner(z)
	scan.Buffer(make([]byte, 65536), 8*1024*1024)
	scene := Scene{Session: s.Session, Contract: s.Contract, Start: s.Start, End: s.End, Raw: s.Raw}
	previous := s.Start
	var index int64
	contracts := map[string]bool{}
	active := []*Case133{}
	matched := 0
	for scan.Scan() {
		out.Quality.Lines++
		oldTime := previous
		q, reason, next, e := decodeRow(scan.Bytes(), out.Quality.Lines, index, scene, previous, &out.Quality, contracts)
		previous = next
		if e != nil {
			return out, e
		}
		if q != nil {
			index++
		}
		for _, target := range wanted[out.Quality.Lines] {
			if q == nil || target.Entry != *q {
				return out, fmt.Errorf("元取得原行全値差:%s 行%d 理由%s", target.ID, out.Quality.Lines, reason)
			}
			c := fixedCase133(target, *q)
			out.Cases = append(out.Cases, c)
			active = append(active, c)
			matched++
		}
		if q == nil {
			continue
		}
		keep := active[:0]
		for _, c := range active {
			if stepCase133(c, *q, oldTime, s.End-300) {
				keep = append(keep, c)
			}
		}
		active = keep
	}
	if e = scan.Err(); e != nil {
		return out, e
	}
	if _, e = io.Copy(io.Discard, tee); e != nil {
		return out, e
	}
	after, e := f.Stat()
	if e != nil {
		return out, e
	}
	out.After = FileStat{Bytes: after.Size(), ModTimeNS: after.ModTime().UnixNano()}
	out.ActualSHA = hex.EncodeToString(h.Sum(nil))
	if out.Raw.SHA256 != out.ActualSHA || out.Before != out.After {
		return out, fmt.Errorf("Raw SHA/stat差")
	}
	if len(contracts) != 1 || !contracts[s.Contract] || index != s.ExpectedAccepted || matched != len(s.Entries) {
		return out, fmt.Errorf("限月/採用数/固定取得結合数差")
	}
	if s.ExpectedQuality != nil && out.Quality != *s.ExpectedQuality {
		return out, fmt.Errorf("全行quality差")
	}
	for _, c := range out.Cases {
		finalize133(c)
	}
	out.Success = true
	return out, nil
}

// validSHA133 はRoot固定SHAの小文字16進64桁形式を確認します。
//
// 引数: value(string)。返り値: boolです。
func validSHA133(value string) bool {
	if len(value) != 64 {
		return false
	}
	for _, c := range value {
		if !(c >= '0' && c <= '9') && !(c >= 'a' && c <= 'f') {
			return false
		}
	}
	return true
}

// validateInput133 は全73場と入力で固定した可変取得数を確認します。
//
// 引数: in(Input133)、workers(int)。返り値: errorです。データ本文は開きません。
func validateInput133(in Input133, workers int) error {
	if len(in.Scenes) != 73 || workers < 1 || workers > 8 {
		return fmt.Errorf("73場/並列数差")
	}
	previous := 0.0
	seen := map[string]bool{}
	entries := 0
	for _, s := range in.Scenes {
		if s.Session == "" || seen[s.Session] || s.Contract == "" || !finite(s.Start, s.End, s.ForceClose) || s.Start <= previous || s.End < s.ForceClose || s.ForceClose <= s.Start || s.End-300-3600 <= s.Start || s.Raw.Path == "" || !validSHA133(s.Raw.SHA256) || s.ExpectedAccepted <= 0 || s.ExpectedQuality == nil {
			return fmt.Errorf("場/原板/期待品質宣言差:%s", s.Session)
		}
		seen[s.Session] = true
		previous = s.End
		if s.ExpectedQuality.Delivered != s.ExpectedAccepted || s.ExpectedQuality.Accepted < s.ExpectedQuality.Delivered || s.ExpectedQuality.Lines < s.ExpectedQuality.Accepted {
			return fmt.Errorf("品質と採用数差")
		}
		if _, e := validateEntries133(s); e != nil {
			return e
		}
		entries += len(s.Entries)
	}
	if in.ExpectedEntryCount <= 0 || entries != in.ExpectedEntryCount {
		return fmt.Errorf("固定入力の宣言取得数と異なる:%d", entries)
	}
	return nil
}

// Run133 はRoot固定の小型取得表を用い全73場を最大8並列で保存します。
//
// 引数: input/expected/output(string)、workers(int)。返り値: errorです。
func Run133(input, expected, output string, workers int) error {
	if !validSHA133(expected) {
		return fmt.Errorf("固定SHAを指定")
	}
	data, e := os.ReadFile(input)
	if e != nil {
		return e
	}
	initial := sha256.Sum256(data)
	if hex.EncodeToString(initial[:]) != expected {
		return fmt.Errorf("入力SHA差")
	}
	var in Input133
	if e = json.Unmarshal(data, &in); e != nil {
		return e
	}
	if e = validateInput133(in, workers); e != nil {
		return e
	}
	if _, e = os.Stat(output); !os.IsNotExist(e) {
		return fmt.Errorf("未作成出力だけ")
	}
	results := make([]Result133, len(in.Scenes))
	jobs := make(chan int)
	var wg sync.WaitGroup
	for i := 0; i < workers; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for at := range jobs {
				r, e := scan133(in.Scenes[at])
				if e != nil {
					r.Error = e.Error()
				}
				results[at] = r
				fmt.Printf("%s 成功=%t %s\n", r.Session, r.Success, r.Error)
			}
		}()
	}
	for i := range in.Scenes {
		jobs <- i
	}
	close(jobs)
	wg.Wait()
	for _, r := range results {
		if !r.Success {
			return fmt.Errorf("%s:%s", r.Session, r.Error)
		}
	}
	out := map[string]any{"execution_model": "ザラバEnd-300未満、H60を残す取得限界、価格時計", "trial": 133, "success": true, "input_sha256": expected, "scenes": results, "scene_count": 73, "source_entry_count": in.ExpectedEntryCount, "horizons": Horizons133, "widths": Widths133, "candidate_quantity": 1, "portfolio_pnl": false, "fixed_source_entry_clock": true, "new_entry_gate_replayed": false, "chart_money_is_nil": true, "chart_model": "Last→Lastの約定不可の価格方向参考。正常BBO/欠測/期限対象RawはBBOと共通", "ifd_model": "先着touch.quoteの瞬時清算BBOを用いる別集計用証拠。実IFD約定・遅延・待ち行列の証明ではない"}
	encoded, e := json.MarshalIndent(out, "", "  ")
	if e != nil {
		return e
	}
	after, e := os.ReadFile(input)
	if e != nil {
		return e
	}
	if sha256.Sum256(after) != initial {
		return fmt.Errorf("入力前後差")
	}
	f, e := os.OpenFile(output, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if e != nil {
		return e
	}
	defer f.Close()
	_, e = f.Write(append(encoded, '\n'))
	return e
}
