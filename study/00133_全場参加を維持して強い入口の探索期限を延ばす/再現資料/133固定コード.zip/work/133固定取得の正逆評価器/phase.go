package holdingohlc113

// phaseCut133 はザラバ終端以降の未完了だけを打ち切り、既知touchと完了観測を保持します。
//
// 引数: c(*Candidate133)、q(Quote)、executionEnd(float64)は等号を除外する境界です。
// 返り値: boolは現在行が境界以降の場合に真です。Last/BBOへ同じ順序で適用します。
func phaseCut133(c *Candidate133, q Quote, executionEnd float64) bool {
	if q.Time < executionEnd {
		return false
	}
	for i := range c.Outcomes {
		if c.Outcomes[i].Status == "pending" {
			c.Outcomes[i].Status = "phase_censored"
		}
	}
	return true
}
