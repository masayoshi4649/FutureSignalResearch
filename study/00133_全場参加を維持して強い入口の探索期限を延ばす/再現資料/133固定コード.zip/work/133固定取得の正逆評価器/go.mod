module entryexperiment133

go 1.24.2
