# 133：固定取得を実BBO正逆で評価する後段

2026-11-11、自然Raw未実行。Source探索器が先に保存した出生・実取得時計を固定してから使う。新しい注文条件をこの後段で選ばない。元124の固定取得評価器を複製し、同幅先着と期限清算の算術を保持する。

## 入力と変更

全73場を時系列で残す。`scenes[].entries`の各`id/side/entry`は前段で確定したSource方向とQuoteで、原行番号・採用index・価格・時計を全値照合する。L0/L1はIDへ接頭辞を付けて区別し、入力の`expected_entry_count`を固定した総数にする。0取得の場も削らない。旧124の79件固定を、宣言総数との一致へ変更する。各場の限月・原板SHA/stat・全行品質11値の検査は維持する。

取得代用の限界は`min(Source force_close, Scene.End−300−3600)`、等号以上を拒否する。NK225ザラバの観測終端は`Scene.End−300`とし、等号以後の行は未完了だけを`phase_censored`へ変える。既知touchと完了を保持し、価格時計のgapや価格変化を評価する前に境界を適用する。全原板は終端後も読んでSHA/stat/品質を検査するが、新しいtouch/endpointには使わない。場別結果に`execution_end/effective_entry_limit/source_force_close`を残す。

正逆BBOとLast参考を同じ取得原行から作る。新規買Ask・売Bid、清算買Bid・売Ask。初行は先着判定に使わず、H30/60、同幅25/50/100/125/200を独立に保存する。gap300秒、期限endpoint30秒猶予、未知を0へ埋めない元算術は維持する。Lastの金額は最後にnullへ戻す。

mini1枚100円/pt、往復77円、C5は追加1,000円。IFD代用の到達清算は後段集計が既知touch.quoteから計算し、未到達かつH完了だけ期限清算する。元のSource geometryを通った時点の正逆方向診断であり、反転方向のcap/hold/risk・TTL適格性や実mini板・実IFDを再構築したものではない。

## 再現

準備時は`go test ./...`、`go vet ./...`、`go build -o 固定取得の正逆評価.exe ./cmd/run`。元の4人工検査に加え、境界等号、境界前の既知先着、完了保持、H60を残す取得限界を検査する。自然入力を読む前にRootが前段結果・入力・コード・条件を固定する。

自然実行のCLIは`固定取得の正逆評価.exe --input <入力> --sha256 <固定SHA> --output <未作成先> --workers 8`。具体的なフラグ名は`cmd/run/main.go`を正本とし、金融前の固定時に実行列を検査する。
