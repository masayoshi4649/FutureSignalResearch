"""133の後段を自然入力なしで検査し、固定算術の差分と実行版を保存する。"""
from pathlib import Path
import difflib
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
SOURCE = ROOT / 'work/124入口の正逆比較'


def sha(path: Path) -> str:
    """
    機能: ファイル全体の指紋を求める。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def execute(command: list[str]) -> dict:
    """
    機能: 前の失敗を無視せず一つの準備コマンドを実行する。
    引数: command(list[str])はshellを通さない引数列。
    返り値: dictは成功終了した標準出力・標準エラーと実行列。
    """
    result = subprocess.run(command, cwd=OWN, check=True, capture_output=True, text=True, encoding='utf-8')
    return {'実行列': command, '終了': result.returncode, '標準出力': result.stdout, '標準エラー': result.stderr}


# ----------------------------------------
def main() -> None:
    """
    機能: 人工8検査・vet・buildと元kernelの差分を記録する。
    引数: なし。
    返り値: None。自然Raw、前段結果、新しい金融結果は開かない。
    """
    sources = list(OWN.rglob('*.go')) + [OWN / 'go.mod', OWN / 'README.md', Path(__file__)]
    before = {str(p.relative_to(OWN)): sha(p) for p in sources}
    equality = {}
    for name in ('outcome.go', 'chart_outcome.go'):
        original = (SOURCE / name).read_text('utf-8')
        current = (OWN / name).read_text('utf-8').replace('133', '124')
        current = current.replace('\tif phaseCut124(c, q, force) {\n\t\treturn\n\t}\n', '')
        assert current == original, name
        equality[name] = '133への名前変更とphase guard以外は124と全文一致'
    for name in ('reader.go', 'types.go'):
        assert (SOURCE / name).read_text('utf-8') == (OWN / name).read_text('utf-8'), name
        equality[name] = '全文一致'
    tests = execute(['go', 'test', '-count=1', '-json', './...'])
    records = [json.loads(line) for line in tests['標準出力'].splitlines() if line.startswith('{')]
    names = [r['Test'] for r in records if r.get('Action') == 'pass' and 'Test' in r]
    assert len(names) == 8 and len(set(names)) == 8
    vet = execute(['go', 'vet', './...'])
    build = execute(['go', 'build', '-o', '固定取得の正逆評価.exe', './cmd/run'])
    version = execute(['go', 'version'])
    assert before == {str(p.relative_to(OWN)): sha(p) for p in sources}
    delta = ''.join(difflib.unified_diff((SOURCE / 'entry.go').read_text('utf-8').splitlines(True),
                                      (OWN / 'entry.go').read_text('utf-8').splitlines(True),
                                      fromfile='元124/entry.go', tofile='新133/entry.go'))
    with (OWN / '入口制約の差分.patch').open('x', encoding='utf-8', newline='\n') as handle:
        handle.write(delta)
    proof = {'成功': True, '自然Raw未読': True, '新金融未実行': True, '人工成功': names,
             '固定算術の同体': equality, 'コード仕様の前後指紋': before,
             '人工': tests, 'vet': vet, 'build': build, 'Go版': version['標準出力'].strip(),
             '実行物SHA256': sha(OWN / '固定取得の正逆評価.exe'),
             '取得限界': 'min(Source force_close, End−300−H60)、等号拒否',
             '観測境界': 'q>=End−300は未完了だけphase_censored。既知touch/完了を保持',
             '差分SHA256': sha(OWN / '入口制約の差分.patch')}
    with (OWN / '準備の確認.json').open('x', encoding='utf-8', newline='\n') as handle:
        json.dump(proof, handle, ensure_ascii=False, indent=2); handle.write('\n')
    print(json.dumps({'成功': True, '人工成功': len(names), '準備SHA256': sha(OWN / '準備の確認.json'),
                      '実行物SHA256': proof['実行物SHA256']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
