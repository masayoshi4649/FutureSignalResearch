package holdingohlc113

import (
	"bufio"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"os"
	"reflect"
	"sort"
	"time"
)

// finite は価格・時計・金額の非有限を拒否します。
//
// 引数: values(...float64)は検査値。返り値: boolは全て有限なら真です。
func finite(values ...float64) bool {
	for _, v := range values {
		if math.IsNaN(v) || math.IsInf(v, 0) {
			return false
		}
	}
	return true
}

// normal はSourceの実評価と同じ有限の正Bid<Askだけを認めます。
//
// 引数: q(Quote)は原行。返り値: boolは正常BBOです。数量を条件に加えません。
func normal(q Quote) bool { return finite(q.Bid, q.Ask) && q.Bid > 0 && q.Ask > q.Bid }

// add は既知系列のOHLCと同値極値の最初/最後の原行だけを更新します。
//
// 引数: s(*Series)、value(float64)、q(Quote)は集計先と当値。返り値: ありません。
func (s *Series) add(value float64, q Quote) {
	point := Point{Value: value, Quote: q}
	if s.Count == 0 {
		s.Open = &point
		s.High = &Extreme{Value: value, First: q, Last: q}
		s.Low = &Extreme{Value: value, First: q, Last: q}
	} else {
		if value > s.High.Value {
			s.High = &Extreme{Value: value, First: q, Last: q}
		} else if value == s.High.Value {
			s.High.Last = q
		}
		if value < s.Low.Value {
			s.Low = &Extreme{Value: value, First: q, Last: q}
		} else if value == s.Low.Value {
			s.Low.Last = q
		}
	}
	s.Close = &point
	s.Count++
}

// equalQuote は元clock文字列が無くても保存Quoteの全数値と物理境界を照合します。
//
// 引数: expected/actual(Quote)は台帳と原行。返り値: boolは全利用fieldが同体です。
func equalQuote(expected, actual Quote) bool {
	clock := expected.Clock
	expected.Clock = ""
	actualClock := actual.Clock
	actual.Clock = ""
	return expected == actual && (clock == "" || clock == actualClock)
}

// validateScene は不正な範囲・重複・未登録queryを本文前に拒否します。
//
// 引数: s(Scene)は認証後の当場query。返り値: errorは構成不正です。
func validateScene(s Scene) error {
	if s.Session == "" || s.Contract == "" || !finite(s.Start, s.End, s.Cutoff) || s.End < s.Start || s.Raw.Path == "" || len(s.Raw.SHA256) != 64 {
		return fmt.Errorf("場・Raw参照が不正")
	}
	ids := map[string]bool{}
	pairs := map[[2]int64]string{}
	for _, p := range s.PriceIntervals {
		if p.ID == "" || ids[p.ID] || p.Session != s.Session || p.Start.SourceLine < 1 || p.End.SourceLine < p.Start.SourceLine || p.Start.Index < 0 || p.End.Index < p.Start.Index || !finite(p.Start.Time, p.End.Time, p.Start.Last, p.Start.Bid, p.Start.Ask, p.End.Last, p.End.Bid, p.End.Ask) || p.Start.Time < s.Start || p.End.Time > s.End || p.End.Time < p.Start.Time || !p.StartInclusive || !p.EndInclusive {
			return fmt.Errorf("価格区間の場・境界・inclusive・重複が不正:%s", p.ID)
		}
		pair := [2]int64{p.Start.SourceLine, p.End.SourceLine}
		if previous, ok := pairs[pair]; ok {
			return fmt.Errorf("同一価格区間はIDを共有する:%s/%s", previous, p.ID)
		}
		pairs[pair] = p.ID
		ids[p.ID] = true
	}
	queries := map[string]bool{}
	for _, q := range s.StateSlices {
		if q.ID == "" || queries[q.ID] || !ids[q.IntervalID] || (q.Side != 1 && q.Side != -1) || q.N < 1 || q.Q0 < q.N || q.Q0 > 10 || !finite(q.EntryPrice, q.R, q.K) || q.EntryPrice <= 0 || q.K < 0 {
			return fmt.Errorf("R/n一定queryが不正:%s", q.ID)
		}
		queries[q.ID] = true
		if len(q.Thresholds) != 3 || q.Thresholds[0] != (Threshold{ID: "positive", WholeYen: 0, Strict: true}) || q.Thresholds[1] != (Threshold{ID: "H50", WholeYen: float64(q.Q0) * 5000}) || q.Thresholds[2] != (Threshold{ID: "H100", WholeYen: float64(q.Q0) * 10000}) {
			return fmt.Errorf("正益/H50/H100の閾値定義差:%s", q.ID)
		}
	}
	witnessIDs := map[string]bool{}
	for _, w := range s.WitnessRequests {
		if w.ID == "" || witnessIDs[w.ID] || w.Session != s.Session || w.Index < 0 || w.SourceLine < 1 {
			return fmt.Errorf("原行witness要求が不正")
		}
		witnessIDs[w.ID] = true
	}
	return nil
}

type priceWork struct {
	value   PriceResult
	queries []*StateResult
}

// add は状態片内の初回符号変化だけを保存します。
//
// 引数: r(*Returns)、value(float64)、q(Quote)は符号履歴と当時の費用後値。返り値: ありません。
func (r *Returns) add(value float64, q Quote) {
	point := Point{Value: value, Quote: q}
	if value > 0 && r.FirstPositive == nil {
		r.FirstPositive = &point
	}
	if value <= 0 {
		if r.FirstNonpositive == nil {
			r.FirstNonpositive = &point
		}
		if r.FirstPositive != nil && r.FirstNonpositiveAfterPositive == nil {
			r.FirstNonpositiveAfterPositive = &point
		}
	}
	if value < 0 {
		if r.FirstNegative == nil {
			r.FirstNegative = &point
		}
		if r.FirstPositive != nil && r.FirstNegativeAfterPositive == nil {
			r.FirstNegativeAfterPositive = &point
		}
	}
}

// decodeRow はSource111の原板採用規則を独立コードで照合します。
//
// 引数: raw([]byte)、line/index(int64)、scene(Scene)、previous(float64)、counts(*Counts)、contracts(map[string]bool)。
// 返り値: *Quote/reason/nextPrevious/errorは配送行・除外理由・直前採用時計・壊れたJSON等です。
func decodeRow(raw []byte, line, index int64, scene Scene, previous float64, counts *Counts, contracts map[string]bool) (*Quote, string, float64, error) {
	var fields map[string]json.RawMessage
	if err := json.Unmarshal(raw, &fields); err != nil {
		return nil, "", previous, fmt.Errorf("物理%d JSON:%w", line, err)
	}
	var symbol string
	if err := json.Unmarshal(fields["Symbol"], &symbol); err != nil {
		return nil, "", previous, fmt.Errorf("物理%d Symbol:%w", line, err)
	}
	contracts[symbol] = true
	if len(fields["CurrentPriceTime"]) == 0 {
		counts.ClockMissing++
		return nil, "clock_missing", previous, nil
	}
	var clock string
	if err := json.Unmarshal(fields["CurrentPriceTime"], &clock); err != nil {
		return nil, "", previous, fmt.Errorf("物理%d CurrentPriceTime型:%w", line, err)
	}
	at, err := time.Parse(time.RFC3339Nano, clock)
	if err != nil {
		counts.ClockInvalid++
		return nil, "clock_invalid", previous, nil
	}
	stamp := float64(at.UnixNano()) / 1e9
	if !finite(stamp) || stamp < scene.Start || stamp > scene.End {
		counts.Outside++
		return nil, "outside_session", previous, nil
	}
	if stamp < previous {
		counts.Backward++
		return nil, "backward_clock", previous, nil
	}
	var last float64
	if len(fields["CurrentPrice"]) > 0 {
		if err = json.Unmarshal(fields["CurrentPrice"], &last); err != nil {
			return nil, "", previous, fmt.Errorf("物理%d CurrentPrice型/非有限:%w", line, err)
		}
	}
	if !finite(last) {
		counts.LastNonFinite++
		return nil, "last_non_finite", previous, nil
	}
	if last <= 0 {
		counts.LastNonPositive++
		return nil, "last_non_positive", previous, nil
	}
	// ----------------------------------------
	// 最良以外を値として保存しませんが、旧parserと同じ10深度のJSON型を検査します。
	q := Quote{Clock: clock, Time: stamp, Index: index, SourceLine: line, Last: last}
	for i := 1; i <= 10; i++ {
		var buy, sell struct{ Price, Qty float64 }
		if err = json.Unmarshal(fields[fmt.Sprintf("Buy%d", i)], &buy); err != nil {
			return nil, "", previous, fmt.Errorf("物理%d Buy%d:%w", line, i, err)
		}
		if err = json.Unmarshal(fields[fmt.Sprintf("Sell%d", i)], &sell); err != nil {
			return nil, "", previous, fmt.Errorf("物理%d Sell%d:%w", line, i, err)
		}
		if i == 1 {
			q.Bid, q.Ask = buy.Price, sell.Price
		}
	}
	q.QuoteOK = normal(q)
	counts.Accepted++
	if !q.QuoteOK {
		counts.BadBBO++
	}
	if scene.Cutoff > 0 && stamp >= scene.Cutoff {
		counts.CutoffExcluded++
		return nil, "cutoff_excluded", stamp, nil
	}
	counts.Delivered++
	return &q, "", stamp, nil
}

// apply は一つの当時原行を価格系列と登録済みW閾値へ渡します。
//
// 引数: work(*priceWork)、q(Quote)は活動区間と当行。返り値: errorは非有限の金融計算です。
func apply(work *priceWork, q Quote) error {
	work.value.AcceptedRows++
	work.value.Last.add(q.Last, q)
	if !q.QuoteOK {
		work.value.BadBBORows++
		for _, state := range work.queries {
			state.BadBBORows++
		}
		return nil
	}
	work.value.Bid.add(q.Bid, q)
	work.value.Ask.add(q.Ask, q)
	for _, state := range work.queries {
		mark := q.Bid
		if state.Query.Side < 0 {
			mark = q.Ask
		}
		gain := float64(state.Query.Side) * (mark - state.Query.EntryPrice)
		whole := state.Query.R + float64(state.Query.N)*(100*gain-state.Query.K)
		if !finite(whole) {
			return fmt.Errorf("非有限W:%s", state.Query.ID)
		}
		state.WholeYen.add(whole, q)
		state.WholeReturns.add(whole, q)
		state.UnitReturns.add(100*gain-state.Query.K, q)
		for i := range state.Thresholds {
			threshold := &state.Thresholds[i]
			passed := whole >= threshold.Threshold.WholeYen
			if threshold.Threshold.Strict {
				passed = whole > threshold.Threshold.WholeYen
			}
			if passed && threshold.First == nil {
				threshold.First = &Point{Value: whole, Quote: q}
			}
		}
	}
	return nil
}

// ScanFile は圧縮SHAを同時計算する一走査で保有中だけの極値と到達原行を返します。
//
// 引数: scene(Scene)はRoot固定後に選んだ当場のRawとqueryです。
// 返り値: SceneResult/errorは全境界同体・期待SHA同体の成功又は不完了です。市場戦略は実行しません。
func ScanFile(scene Scene) (result SceneResult, err error) {
	result = SceneResult{Version: 1, Trial: 113, SourceTrial: 112, Session: scene.Session, Raw: scene.Raw, PriceIntervals: map[string]PriceResult{}, StateQueries: map[string]StateResult{}, Witnesses: map[string]WitnessResult{}, ClockBasis: "CurrentPriceTime。実受信時刻は不明。同時計は採用Index/物理source_lineで区別", RawPasses: 1}
	if err = validateScene(scene); err != nil {
		return result, err
	}
	works := make([]*priceWork, 0, len(scene.PriceIntervals))
	byID := map[string]*priceWork{}
	for _, interval := range scene.PriceIntervals {
		work := &priceWork{value: PriceResult{Interval: interval, Excluded: map[string]int64{}}}
		works = append(works, work)
		byID[interval.ID] = work
	}
	states := make([]*StateResult, 0, len(scene.StateSlices))
	for _, query := range scene.StateSlices {
		state := &StateResult{Query: query, Thresholds: []ThresholdResult{}}
		for _, t := range query.Thresholds {
			state.Thresholds = append(state.Thresholds, ThresholdResult{Threshold: t})
		}
		states = append(states, state)
		byID[query.IntervalID].queries = append(byID[query.IntervalID].queries, state)
	}
	sort.Slice(works, func(i, j int) bool {
		return works[i].value.Interval.Start.SourceLine < works[j].value.Interval.Start.SourceLine
	})
	file, err := os.Open(scene.Raw.Path)
	if err != nil {
		return result, err
	}
	defer file.Close()
	before, err := file.Stat()
	if err != nil {
		return result, err
	}
	result.Before = FileStat{Bytes: before.Size(), ModTimeNS: before.ModTime().UnixNano()}
	if scene.RawBytes > 0 && scene.RawBytes != before.Size() {
		return result, fmt.Errorf("圧縮sizeの期待差")
	}
	hash := sha256.New()
	tee := io.TeeReader(file, hash)
	z, err := gzip.NewReader(tee)
	if err != nil {
		return result, err
	}
	defer z.Close()
	scan := bufio.NewScanner(z)
	scan.Buffer(make([]byte, 65536), 8*1024*1024)
	contracts := map[string]bool{}
	witnessLines := map[int64][]WitnessRequest{}
	for _, w := range scene.WitnessRequests {
		witnessLines[w.SourceLine] = append(witnessLines[w.SourceLine], w)
	}
	previous := scene.Start
	var index int64
	cursor := 0
	active := []*priceWork{}
	for scan.Scan() {
		result.Quality.Lines++
		line := result.Quality.Lines
		q, reason, next, e := decodeRow(scan.Bytes(), line, index, scene, previous, &result.Quality, contracts)
		if e != nil {
			return result, e
		}
		previous = next
		if q != nil {
			index++
		}
		for _, w := range witnessLines[line] {
			if q == nil || q.Index != w.Index {
				return result, fmt.Errorf("保存原行witnessの未採用又はIndex差:%s 行%d 理由%s", w.ID, line, reason)
			}
			result.Witnesses[w.ID] = WitnessResult{Request: w, Found: true, IndexMatched: true, Quote: *q}
		}
		for cursor < len(works) && works[cursor].value.Interval.Start.SourceLine <= line {
			active = append(active, works[cursor])
			cursor++
		}
		keep := active[:0]
		for _, work := range active {
			v := &work.value
			v.RawRows++
			if line == v.Interval.Start.SourceLine {
				if q == nil || !equalQuote(v.Interval.Start, *q) {
					return result, fmt.Errorf("新規/区間開始Quote不一致:%s 行%d 理由%s", v.Interval.ID, line, reason)
				}
				v.StartMatched = true
			}
			if line == v.Interval.End.SourceLine {
				if q == nil || !equalQuote(v.Interval.End, *q) {
					return result, fmt.Errorf("最終返済/区間終了Quote不一致:%s 行%d 理由%s", v.Interval.ID, line, reason)
				}
				v.EndMatched = true
			}
			if q == nil {
				v.Excluded[reason]++
			} else if e = apply(work, *q); e != nil {
				return result, e
			}
			if line < v.Interval.End.SourceLine {
				keep = append(keep, work)
			}
		}
		active = keep
	}
	if err = scan.Err(); err != nil {
		return result, err
	}
	// ----------------------------------------
	// gzip検査後も圧縮末尾まで同じ読取器を使い、再走査せず全bytes指紋を確定します。
	if _, err = io.Copy(io.Discard, tee); err != nil {
		return result, err
	}
	result.ActualSHA256 = hex.EncodeToString(hash.Sum(nil))
	result.CompressedBytes = before.Size()
	after, err := file.Stat()
	if err != nil {
		return result, err
	}
	result.After = FileStat{Bytes: after.Size(), ModTimeNS: after.ModTime().UnixNano()}
	if result.ActualSHA256 != scene.Raw.SHA256 || !reflect.DeepEqual(result.Before, result.After) {
		return result, fmt.Errorf("走査同時計算SHA又は前後stat差")
	}
	for symbol := range contracts {
		result.Contracts = append(result.Contracts, symbol)
	}
	sort.Strings(result.Contracts)
	if len(result.Contracts) != 1 || result.Contracts[0] != scene.Contract {
		return result, fmt.Errorf("原板Symbol/限月差")
	}
	if cursor != len(works) || len(active) != 0 {
		return result, fmt.Errorf("EOFまでに要求境界が現れない")
	}
	if len(result.Witnesses) != len(scene.WitnessRequests) {
		return result, fmt.Errorf("EOFまでに保存原行witnessが現れない")
	}
	for _, work := range works {
		v := work.value
		if !v.StartMatched || !v.EndMatched || v.Last.Count != v.Interval.End.Index-v.Interval.Start.Index+1 {
			return result, fmt.Errorf("境界又は採用Index区間件数差:%s", v.Interval.ID)
		}
		result.PriceIntervals[v.Interval.ID] = v
	}
	for _, state := range states {
		result.StateQueries[state.Query.ID] = *state
	}
	result.Success = true
	return result, nil
}
