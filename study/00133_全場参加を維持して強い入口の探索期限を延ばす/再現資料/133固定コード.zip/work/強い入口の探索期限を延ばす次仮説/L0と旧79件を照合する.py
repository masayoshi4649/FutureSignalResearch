"""F0後に生成されたSource結果を旧123の非金融項目へ照合する。金融ラベルを計算しない。"""
import argparse
import copy
import hashlib
import json
import math
from pathlib import Path


def sha(path: Path) -> str:
    """
    機能: SHA256を計算する。
    引数: path(Path)は対象。
    返り値: strは小文字16進SHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def normalized(candidate: dict, new: bool) -> dict:
    """
    機能: 金融項目と新方向票を除き、L0の識別子だけを旧P3へ対応させる。
    引数: candidate(dict)、new(bool)はSource候補と新旧指定。
    返り値: dictは元出生/要求/取得geometryの私有copy。
    """
    result=copy.deepcopy(candidate)
    for key in ('outcomes','last_normal_time','direction'):result.pop(key,None)
    if new:
        assert result['policy']=='L0'
        result['policy']='P3'
        result['birth']['id']=result['birth']['id'].replace('/補完/L0/','/補完/P3/')
    return result


def number(fields: dict, key: str) -> float | None:
    """
    機能: GoのKnown/value票を未知から区別して読む。
    引数: fields(dict)、key(str)は票と項目。
    返り値: float|Noneは有限の既知値又は未知。未知の格納値を判断に使わない。
    """
    item=fields[key];assert type(item['known']) is bool
    if not item['known']:return None
    value=item['value'];assert type(value) in (int,float) and math.isfinite(value)
    return value


def same_number(actual: float | None, expected: float | None) -> None:
    """
    機能: 未知maskを保持して数値を照合する。
    引数: actual/expected(float|None)は実値と期待値。
    返り値: None。不一致はAssertionError。
    """
    if actual is None or expected is None:assert actual is expected
    else:assert math.isclose(actual,expected,rel_tol=1e-12,abs_tol=1e-10),(actual,expected)


def validate_direction(candidate: dict) -> None:
    """
    機能: 保存した当時原値だけからB0/T8/E0保護を別の式で照合する。
    引数: candidate(dict)はSource候補。未来の価格や結果を使わない。
    返り値: None。不一致はAssertionError。
    """
    d=candidate['direction'];side=candidate['birth']['side'];fields=d['fields']
    assert side in (-1,1) and d['source_side']==side
    o,h,l,c=(number(fields,k) for k in ('open5','high5','low5','close5'))
    assert None not in (o,h,l,c) and 0<l<=min(o,c)<=max(o,c)<=h
    body=side*(c-o)/(h-l) if h>l else None
    same_number(number(fields,'body5_signed_ratio_to_source'),body)
    b0=-side if body is not None and .5<=body<.75 else side
    long=number(fields,'ema21_delta30_raw');hist=number(fields,'hist5_raw');atr=number(fields,'atr5')
    long=None if long is None else b0*long
    hist_atr=b0*hist/atr if hist is not None and atr is not None and atr>0 else None
    same_number(number(fields,'ema21_delta30_to_B0'),long)
    same_number(number(fields,'hist5_atr_to_B0'),hist_atr)
    t8=-b0 if long is not None and long>=0 and hist_atr is not None and hist_atr>=.1 else b0
    selected=side if candidate['path']=='E0' else t8
    assert (d['b0_side'],d['t8_side'],d['selected_side'],d['e0_protected'])==(b0,t8,selected,candidate['path']=='E0')
    for ref in d['refs']:
        stamp=ref['delivered'];birth=candidate['birth']
        assert stamp['time']<=birth['time'] and stamp['index']<=birth['index'] and stamp['source_line']<=birth['source_line']


def compare(old: dict, new: dict, prior_choices: dict, clock_meta: dict) -> dict:
    """
    機能: L0の全79取得を旧Source123P3へ照合し、L1を含む全73場の参加を保持する。
    引数: old/new/prior_choices/clock_meta(dict)は旧Source結果、新Source結果、131票、時計監査。
    返り値: dictは非金融照合と参加件数。L1未取得も削除せず記録する。
    """
    assert old['success'] and old['trial']==123 and new['success'] and new['trial']==133
    assert new['outcomes_computed'] is False and new['selected_direction_order_eligibility_rebuilt'] is False
    assert old['input_sha256']==new['input_sha256']=='6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec'
    assert len(old['scenes'])==len(new['scenes'])==73
    prior={(x['session'],x['id']):x for x in prior_choices['choices']};assert len(prior)==79
    clocks={x['session']:x for x in clock_meta['scene_clock_meta']}
    entries=0;directions=0;scenes=[]
    for a,b in zip(old['scenes'],new['scenes']):
        assert a['session']==b['session'] and a['success'] and b['success']
        session=a['session'];cm=clocks[session]
        assert b['entry_cutoff']==min(cm['source_force_close'],cm['execution_end']-3600)
        assert b['execution_end']==cm['execution_end'] and b['source_force_close']==cm['source_force_close']
        assert b['fallback_at']=={'L0':cm['L0_deadline'],'L1':cm['L1_deadline']}
        for key in ('quality','expected_quality','raw','actual_sha256','raw_encoding','publications','events','detector_stats'):
            assert a[key]==b[key],(session,key)
        old_filled={x['birth']['id']:x for x in a['candidates'] if x['policy']=='P3' and x['status']=='filled'}
        new_filled={x['birth']['id'].replace('/補完/L0/','/補完/P3/'):x for x in b['candidates'] if x['policy']=='L0' and x['status']=='filled'}
        assert old_filled.keys()==new_filled.keys(),(session,'L0取得集合差')
        assert old_filled,(session,'旧73場が欠けた')
        for identity,x in new_filled.items():
            assert normalized(old_filled[identity],False)==normalized(x,True),(session,identity,'元出生/要求/取得差')
            ref=prior[(session,identity)];d=x['direction']
            assert (d['source_side'],d['b0_side'],d['t8_side'])==(ref['original_side'],ref['b0_side'],ref['t8_side'])
            expected=ref['original_side'] if x['path']=='E0' else ref['t8_side']
            assert d['selected_side']==expected
            for key,oldkey in (('body5_signed_ratio_to_source','candle5_body_signed_ratio'),
                               ('ema21_delta30_to_B0','ema21_delta_signed_30'),('hist5_atr_to_B0','hist_atr_signed_5')):
                actual=number(d['fields'],key)
                expect=ref['values_to_B0'][oldkey]
                same_number(actual,expect)
            expected_refs=[{k:r[k] for k in ('id','width_seconds','end','delivered')} for r in ref['refs']]
            assert d['refs']==expected_refs
            directions+=1
        for candidate in b['candidates']:
            assert 'outcomes' not in candidate and 'last_normal_time' not in candidate
            validate_direction(candidate)
            if candidate['status']!='filled':continue
            q=candidate['entry'];r=candidate['request']
            assert q['quote_ok'] and 0<q['bid']<q['ask'] and q['time']<b['entry_cutoff'] and q['time']<candidate['expires']
            assert q['index']>r['index'] and q['source_line']>r['source_line'] and q['time']>=r['time']+1
            assert candidate['entry_price']==(q['ask'] if candidate['birth']['side']>0 else q['bid'])
        counts={p:sum(x['status']=='filled' and x['policy']==p for x in b['candidates']) for p in ('L0','L1')}
        assert b['coverage']=={p:counts[p]>0 for p in ('L0','L1')}
        for p in ('L0','L1'):
            assert sum(x['status']=='filled' and x['policy']==p and x['path']!='E0' for x in b['candidates'])<=1
        scenes.append({'session':session,'entries':counts,'covered':b['coverage']})
        entries+=len(old_filled)
    assert entries==directions==79
    return {'success':True,'L0_old79_Source_items_identical':True,'L0_79_fixed_directions_identical':True,
            'full73_metadata_events_stats_equal':True,'all_saved_directions_independently_verified':True,
            'Source_geometry_and_selected_direction_separate':True,'outcomes_compared_or_computed':False,
            'scenes':scenes,'L0_entries':79,'L0_covered_sessions':73,
            'L1_entries':sum(x['entries']['L1'] for x in scenes),
            'L1_covered_sessions':sum(x['covered']['L1'] for x in scenes),
            'L1_uncovered_sessions':[x['session'] for x in scenes if not x['covered']['L1']]}


def main() -> None:
    """
    機能: RootのF0後に指定されたSource結果だけを指紋付きで照合する。
    引数: --result(Path)、--expected-sha(str)、--output(Path)は新結果と指紋・新規証跡先。
    返り値: None。Rawを開かず非金融比較proofを保存する。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--result',type=Path,required=True)
    parser.add_argument('--expected-sha',required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();here=Path(__file__).resolve().parent;root=here.parents[1]
    sources={args.result:args.expected_sha,
             root/'work/123全場参加の入口比較/全73場の入口結果.json':'9823c9b3f257d97462f295e696b649d41a10ea538dd816490d70e60b34c4146f',
             root/'work/T8の15分位相による切替案/choices.json':'cdf1f0c6248d76222d49c7d872094cce20edecb7f52aa9e725d1040aa51f17c3',
             here/'旧79件の時計と新期限.json':'5b16fa8bccf4d90008a56daa742ac8b4cc1a7179ea2fe7178f1151907f25b9ba'}
    assert all(sha(p)==h for p,h in sources.items())
    load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
    keys=list(sources)
    result=compare(load(keys[1]),load(keys[0]),load(keys[2]),load(keys[3]))
    assert all(sha(p)==h for p,h in sources.items())
    result['source_hashes_before_after_equal']=True
    result['source_hashes']={str(p.resolve()):h for p,h in sources.items()}
    result['code_sha256']=sha(Path(__file__))
    assert not args.output.exists()
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'success':True,'proof_sha256':sha(args.output),'L0_entries':79,
                      'L1_entries':result['L1_entries'],'L1_covered_sessions':result['L1_covered_sessions']},ensure_ascii=False))


if __name__=='__main__':main()
