"""Source133の人工検査、元方式との文字列同体、全実依存の指紋を固定する。自然再生はしない。"""
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path


def sha(path: Path) -> str:
    """
    機能: SHA256を計算する。
    引数: path(Path)は対象。
    返り値: strは小文字16進SHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def go_body(text: str, marker: str) -> str:
    """
    機能: Goの指定宣言を対応する波括弧まで取り出す。
    引数: text(str)、marker(str)はコードと宣言開始。
    返り値: strは関数又は構造体の宣言。
    """
    start=text.index(marker);opening=text.index('{',start);depth=0
    for i in range(opening,len(text)):
        if text[i]=='{':depth+=1
        elif text[i]=='}':
            depth-=1
            if depth==0:return text[start:i+1]
    raise AssertionError(marker)


def objects(text: str) -> list[dict]:
    """
    機能: go listの連続JSONを読み取る。
    引数: text(str)はgo listの標準出力。
    返り値: list[dict]は列挙されたpackage。
    """
    decoder=json.JSONDecoder();i=0;result=[]
    while i<len(text):
        while i<len(text) and text[i].isspace():i+=1
        if i>=len(text):break
        item,i=decoder.raw_decode(text,i);result.append(item)
    return result


def run(command: list[str], directory: Path) -> dict:
    """
    機能: 自然再生以外の検査/ビルドコマンドを実行し失敗を止める。
    引数: command(list[str])、directory(Path)は引数列と作業フォルダ。
    返り値: dictは終了コードと標準出力/標準エラー。
    """
    p=subprocess.run(command,cwd=directory,text=True,encoding='utf-8',capture_output=True)
    assert p.returncode==0,(command,p.stdout,p.stderr)
    return {'command':command,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}


def main() -> None:
    """
    機能: 最終Sourceコード・実依存を前後照合し、人工20主とPython4主の証跡を保存する。
    引数: なし。Goコードと既存の小型時計metadataだけを読み、自然Raw/新出生/金融を開かない。
    返り値: None。準備確認JSONを新規保存する。
    """
    here=Path(__file__).resolve().parent;root=here.parents[1];module=here/'Source入口の再生器'
    deps=run(['go','list','-deps','-test','-json','./...'],module)
    packages=objects(deps['stdout']);dependency_files=set();modules={}
    for p in packages:
        m=p.get('Module')
        if not m:continue
        modules[m['Path']]={k:m[k] for k in ('Dir','GoMod','GoVersion','Replace') if k in m}
        if m.get('GoMod'):dependency_files.add(Path(m['GoMod']))
        directory=Path(p['Dir'])
        for key in ('GoFiles','CgoFiles','TestGoFiles','XTestGoFiles','EmbedFiles'):
            for name in p.get(key,[]):
                file=directory/name
                if file.is_file() and file.resolve().is_relative_to(root.resolve()):dependency_files.add(file.resolve())
    owned={p.resolve() for p in here.rglob('*') if p.is_file() and (p.suffix in ('.go','.py','.md') or p.name in ('go.mod','go.sum'))}
    old=root/'work/123全場参加の入口比較'
    original={p.resolve() for p in old.rglob('*') if p.is_file() and (p.suffix=='.go' or p.name in ('go.mod','go.sum'))}
    # 121の120参照は比較test専用。今回のSource実行/Sourceテストがリンクしたpackageと区別する。
    legacy=root/'work/120入口の1分構造'
    legacy_test_only={p.resolve() for p in legacy.glob('*') if p.is_file() and (p.suffix=='.go' or p.name=='go.mod')}
    tracked=owned|original|dependency_files|legacy_test_only
    before={str(p.relative_to(root.resolve())):sha(p) for p in sorted(tracked)}
    text=lambda p:p.read_text(encoding='utf-8-sig')
    checks={}
    for file in ('score.go','validation.go','stream.go'):
        checks[file+'_identifier_only']=text(module/file).replace('133','123')==text(old/file)
        assert checks[file+'_identifier_only'],file
    for name in ('finite','normal','decodeRow'):
        checks['parser_'+name+'_same_LF']=go_body(text(module/'reader.go'),f'func {name}(')==go_body(text(old/'reader.go'),f'func {name}(')
        assert checks['parser_'+name+'_same_LF'],name
    for name in ('pending','processPending'):
        checks[name+'_same_identifier_only']=go_body(text(module/'entry.go'),f'func {name}133(').replace('133','123')==go_body(text(old/'entry.go'),f'func {name}123(')
        assert checks[name+'_same_identifier_only'],name
    assert 'policy' not in go_body(text(module/'score.go'),'func score133(')
    assert 'policy' not in go_body(text(module/'score.go'),'func strong133(')
    checks['score_strong_have_no_policy_branch']=True
    logs=[run(['go','version'],module),run(['go','test','-count=1','-v','./...'],module),
          run(['go','vet','./...'],module),run(['go','build','-o','Source入口.exe','./cmd/source133'],module),
          run([sys.executable,'-X','utf8','非金融照合の人工検査.py'],here)]
    go_tests=sorted({line.split('Test',1)[1].split('/')[0].strip() for line in logs[1]['stdout'].splitlines() if line.startswith('=== RUN   Test')})
    assert len(go_tests)==20,len(go_tests)
    assert 'Ran 4 tests' in logs[-1]['stderr']
    after={str(p.relative_to(root.resolve())):sha(p) for p in sorted(tracked)};assert before==after
    proof={'success':True,'stage':'133 Source入口の金融前準備','go_primary_tests':20,'python_primary_tests':4,
           'source_identifier_and_parser_checks':checks,'source_and_dependency_hashes':before,
           'compiled_and_test_module_graph':modules,
           'compiled_local_package_imports':sorted({p['ImportPath'] for p in packages if p.get('Module')}),
           'legacy_120_comparison_test_only_not_linked':{str(p.relative_to(root.resolve())):sha(p) for p in sorted(legacy_test_only)},
           '115_threeframe_values_are_input122_already_generated_not_recomputed':True,
           'all_tracked_sources_before_after_equal':True,'executable_sha256':sha(module/'Source入口.exe'),
           'logs':logs,'go_primary_test_names':go_tests,
           'small_clock_audits':{p.name:sha(p) for p in (here/'旧79件の時計と新期限.json',here/'公表末尾の期限可用性.json')},
           'natural_raw_read':False,'natural_new_source_result_generated':False,'financial_labels_generated':False,
           'new_or_old_financial_items_used_to_select_clock':False,'L0_old79_natural_parity_not_yet_executed':True,
           'selected_direction_order_eligibility_rebuilt':False}
    out=here/'準備の確認.json';assert not out.exists()
    out.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'success':True,'proof_sha256':sha(out),'tracked_files':len(before),'executable_sha256':proof['executable_sha256'],
                      'go_primary_tests':20,'python_primary_tests':4},ensure_ascii=False))


if __name__=='__main__':main()
