"""固定122入力の公表配送末尾だけでL1期限への到達可否を予備点検する。Rawは読まない。"""
import datetime
import hashlib
import json
from pathlib import Path


def sha(path: Path) -> str:
    """
    機能: SHA256を計算する。
    引数: path(Path)は対象。
    返り値: strは小文字16進SHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def clock(at: float | None) -> str | None:
    """
    機能: 価格時計を日本時間のISO表記にする。
    引数: at(float|None)はUnix秒又は未公表。
    返り値: str|Noneは時刻又は未知。
    """
    if at is None:return None
    return datetime.datetime.fromtimestamp(at,datetime.timezone(datetime.timedelta(hours=9))).isoformat()


def main() -> None:
    """
    機能: 全73場の公表末尾とL1期限を比較し、名目期限とのズレを保存する。
    引数: なし。固定Input122を読み、公表stamp/endとscene時計以外の価格・金融を集計しない。
    返り値: None。新しいmetadata予備点検JSONを保存する。
    """
    here=Path(__file__).resolve().parent;root=here.parents[1]
    path=root/'work/122全場入力/入力.json'
    expected='6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec'
    assert sha(path)==expected
    data=json.loads(path.read_text(encoding='utf-8-sig'));assert len(data['scenes'])==73
    rows=[]
    for s in data['scenes']:
        ps=s['publications'];last=max(ps,key=lambda p:(p['stamp']['time'],p['stamp']['index'],p['stamp']['source_line'])) if ps else None
        deadline=s['end']-300-3600-120;stamp=last['stamp'] if last else None
        rows.append({'session':s['session'],'nominal_start':s['start'],'nominal_end':s['end'],
                     'L1_deadline':deadline,'L1_deadline_clock':clock(deadline),
                     'last_publication_stamp':stamp,'last_publication_clock':clock(stamp['time']) if stamp else None,
                     'last_publication_end':last['frame']['frame']['end'] if last else None,
                     'last_publication_before_L1_deadline':None if stamp is None else stamp['time']<deadline,
                     'no_publications':not ps,'publication_count':len(ps),
                     'seconds_last_delivery_minus_L1':None if stamp is None else stamp['time']-deadline,
                     'raw_last_quote_known_from_this_audit':False})
    before=[r['session'] for r in rows if r['last_publication_before_L1_deadline']]
    result={'success':True,'input_sha256':expected,'scene_count':73,'publication_count':sum(r['publication_count'] for r in rows),
            'last_publication_before_L1_count':len(before),'last_publication_before_L1_sessions':before,
            'no_publication_sessions':[r['session'] for r in rows if r['no_publications']],
            'raw_last_quote_not_inferred':True,'natural_raw_read':False,'new_financial_evaluation':False,
            'rows':rows}
    assert sha(path)==expected
    out=here/'公表末尾の期限可用性.json';assert not out.exists()
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'success':True,'sha256':sha(out),'early_sessions':before,'count':len(before),
                      'details':[r for r in rows if r['session'] in before]},ensure_ascii=False))


if __name__=='__main__':main()
