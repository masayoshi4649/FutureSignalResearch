package holdingohlc113

import (
	"fmt"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// ----------------------------------------
// validSHA133 はStageBで固定するSHAの小文字16進64桁形式を確認します。
//
// 引数: value(string)。返り値: bool。入力本文や対象原板を読みません。
func validSHA133(value string) bool {
	if len(value) != 64 {
		return false
	}
	for _, c := range value {
		if !(c >= '0' && c <= '9') && !(c >= 'a' && c <= 'f') {
			return false
		}
	}
	return true
}

// ----------------------------------------
// validateInput133 は全73場の順序・Scope・公表因果と任意の品質metadataを検査します。
//
// 引数: in(Input133)、workers(int)。返り値: int/errorは公表総数と不整合です。
// 公表数0を許し、候補0場を取り除かず、原板本文の読み出しは行いません。
func validateInput133(in Input133, workers int) (int, error) {
	if len(in.Scenes) != 73 || workers < 1 || workers > 8 {
		return 0, fmt.Errorf("73場/並列条件差")
	}
	pubs := 0
	seen := map[string]bool{}
	previousEnd := 0.0
	previousSession := ""
	for _, s := range in.Scenes {
		if s.Session == "" || seen[s.Session] || s.Session <= previousSession || s.Contract == "" || !finite(s.Start, s.End, s.ForceClose) || s.Start <= previousEnd || s.ForceClose <= s.Start || s.ForceClose > s.End || s.Raw.Path == "" || !validSHA133(s.Raw.SHA256) || s.ExpectedAccepted <= 0 {
			return 0, fmt.Errorf("場定義又は順序差: %s", s.Session)
		}
		seen[s.Session] = true
		previousEnd = s.End
		previousSession = s.Session
		if c := s.ExpectedQuality; c != nil {
			for _, n := range []int64{c.Lines, c.ClockMissing, c.ClockInvalid, c.Outside, c.Backward, c.LastNonPositive, c.LastNonFinite, c.BadBBO, c.Accepted, c.CutoffExcluded, c.Delivered} {
				if n < 0 {
					return 0, fmt.Errorf("負の品質件数: %s", s.Session)
				}
			}
			if c.Delivered != s.ExpectedAccepted || c.Accepted < c.Delivered || c.Lines < c.Accepted {
				return 0, fmt.Errorf("品質件数と採用数の差: %s", s.Session)
			}
		}
		bank := rules.NewBank()
		if err := bank.StartSession(s.Session, s.Contract); err != nil {
			return 0, err
		}
		ids := map[string]bool{}
		var previous *rules.Stamp
		for _, pub := range s.Publications {
			stamp, f := pub.Stamp, pub.Frame.Frame
			if f.SessionID != s.Session || f.Contract != s.Contract || !finite(stamp.Time) || stamp.Time < s.Start || stamp.Time > s.End || stamp.Index < 0 || int64(stamp.Index) >= s.ExpectedAccepted || stamp.Line < 1 {
				return 0, fmt.Errorf("公表Scope/配送範囲差: %s", s.Session)
			}
			if previous != nil && (stamp.Time < previous.Time || stamp.Index < previous.Index || stamp.Line < previous.Line || (stamp.Index == previous.Index && (stamp.Time != previous.Time || stamp.Line != previous.Line)) || (stamp.Index > previous.Index && stamp.Line <= previous.Line)) {
				return 0, fmt.Errorf("公表原行順序差: %s", s.Session)
			}
			key := fmt.Sprintf("%d/%s", f.Width, f.ID)
			if ids[key] {
				return 0, fmt.Errorf("同公表ID重複: %s", s.Session)
			}
			ids[key] = true
			if err := bank.Add(pub); err != nil {
				return 0, fmt.Errorf("公表値/因果差 %s: %w", s.Session, err)
			}
			x := stamp
			previous = &x
		}
		pubs += len(s.Publications)
	}
	return pubs, nil
}
