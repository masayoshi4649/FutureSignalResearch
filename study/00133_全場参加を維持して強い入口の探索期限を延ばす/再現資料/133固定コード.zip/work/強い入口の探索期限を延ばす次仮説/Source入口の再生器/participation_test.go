package holdingohlc113

import (
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"testing"
)

// TestSupplementFillAndPriority133 は補完の取得・同Raw優先取消・再試行を人工価格で検査します。
//
// 引数: t(*testing.T)。返り値: ありません。市場データは使いません。
func TestSupplementFillAndPriority133(t *testing.T) {
	for _, side := range []int{1, -1} {
		q := testQuote133(100, 0, 95, 105)
		d := Decision133{Eligible: true, Side: side, Components: map[string]rules.Value{"ATR5": {Known: true, Value: 10}}}
		scene := Scene133{Session: "s", Contract: "X", ForceClose: 5000}
		c := supplement133("L0", "deadline", d, q, scene)
		pending133(c, testQuote133(100, 1, 95, 105), 5000)
		if c.Entry != nil {
			t.Fatal("同秒取得")
		}
		covered := map[string]bool{}
		keep, fills := processPending133([]*Candidate133{c}, testQuote133(101, 2, 95, 105), 5000, covered, map[string]bool{})
		if len(keep) != 0 || len(fills) != 1 || !covered["L0"] || c.RiskAtDecision != nil {
			t.Fatal("補完取得をE0専用riskで拒否")
		}
		want := 105.0
		if side < 0 {
			want = 95
		}
		if *c.EntryPrice != want {
			t.Fatal("買Ask/売Bid差")
		}
		// ----------------------------------------
		// 先にリストへ入っている補完でも、同Rawに出生したE0が優先される。
		old := supplement133("L0", "strong", d, q, scene)
		at := testQuote133(101, 1, 95, 105)
		e0, err := new133(testEvent133(at, side), at, 0, scene)
		if err != nil {
			t.Fatal(err)
		}
		e0.Policy = "L0"
		covered = map[string]bool{}
		keep, fills = processPending133([]*Candidate133{old, e0}, at, 5000, covered, map[string]bool{"L0": true})
		if old.Status != "cancelled_e0_priority" || old.Entry != nil || len(fills) != 0 || len(keep) != 1 || covered["L0"] {
			t.Fatal("E0同Raw優先差")
		}
		// ----------------------------------------
		// E0取得成立を補完より先に数え、取得済み場へ追加補完しない。
		old = supplement133("L0", "strong", d, q, scene)
		e0, err = new133(testEvent133(q, side), q, 0, scene)
		if err != nil {
			t.Fatal(err)
		}
		e0.Policy = "L0"
		covered = map[string]bool{}
		keep, fills = processPending133([]*Candidate133{old, e0}, testQuote133(101, 1, 95, 105), 5000, covered, map[string]bool{})
		if len(keep) != 0 || len(fills) != 1 || fills[0] != e0 || old.Status != "cancelled_already_entered" || old.Entry != nil || !covered["L0"] {
			t.Fatal("E0取得後取消差")
		}
		// ----------------------------------------
		// 期限切れは参加と数えず、後の別要求だけを取得する。
		old = supplement133("L0", "deadline", d, q, scene)
		covered = map[string]bool{}
		keep, fills = processPending133([]*Candidate133{old}, testQuote133(130, 1, 95, 105), 5000, covered, map[string]bool{})
		if len(keep) != 0 || len(fills) != 0 || covered["L0"] || old.Status != "unfilled_expired" {
			t.Fatal("30秒TTL境界差")
		}
		next := supplement133("L0", "deadline", d, testQuote133(131, 2, 95, 105), scene)
		_, fills = processPending133([]*Candidate133{next}, testQuote133(132, 3, 95, 105), 5000, covered, map[string]bool{})
		if len(fills) != 1 || !covered["L0"] || old.Entry != nil {
			t.Fatal("未取得後の再要求差")
		}
	}
}
