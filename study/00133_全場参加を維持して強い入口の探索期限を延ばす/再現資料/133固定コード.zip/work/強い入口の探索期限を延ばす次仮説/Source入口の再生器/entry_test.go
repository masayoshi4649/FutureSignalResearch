package holdingohlc113

import (
	"fmt"
	birth "github.com/masayoshi4649/SessionTradeExecuter/entrybirth121"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"testing"
)

// testQuote133 は正常BBOを持つ手製原行を返します。
//
// 引数: at(float64)、index(int64)、bid/ask(float64)。返り値: Quoteです。
func testQuote133(at float64, index int64, bid, ask float64) Quote {
	return Quote{Time: at, Index: index, SourceLine: index + 1, Last: (bid + ask) / 2, Bid: bid, Ask: ask, QuoteOK: true}
}

// testEvent133 は市場データに依存しない手製1分パターン票を返します。
//
// 引数: q(Quote)、side(int)。返り値: birth.Eventです。
func testEvent133(q Quote, side int) birth.Event {
	cap, invalidation := 110.0, 90.0
	if side < 0 {
		cap, invalidation = 90, 110
	}
	return birth.Event{ID: fmt.Sprintf("s/E0/%d/000001", side), CohortID: fmt.Sprintf("s/E0/%d/000001", side), Scope: birth.Scope{SessionID: "s", Contract: "X"}, Policy: "E0", Side: side, At: quote133(q), EntryCap: cap, Invalidation: invalidation, Fields: map[string]rules.Value{"atr5": {Known: true, Value: 100}, "hold_boundary": {Known: true, Value: 100 - float64(side)*5}, "hold_minimum": {Known: true, Value: 0}, "hold_strict": {Known: true, Value: 1}}}
}

// TestDelayedEntryMirror133 は要求後原行1秒と買売鏡像の初回正常BBO取得を検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestDelayedEntryMirror133(t *testing.T) {
	for _, side := range []int{1, -1} {
		q := testQuote133(100, 0, 95, 105)
		c, err := new133(testEvent133(q, side), q, 0, Scene133{Session: "s", Contract: "X", ForceClose: 5000})
		if err != nil || c.Expires != 130 || c.Limit != nil || c.CohortID != testEvent133(q, side).CohortID {
			t.Fatal("出生要求", err)
		}
		pending133(c, testQuote133(100, 1, 95, 105), 5000)
		pending133(c, testQuote133(101, 0, 95, 105), 5000)
		bad := testQuote133(101, 1, 95, 105)
		bad.QuoteOK = false
		pending133(c, bad, 5000)
		if c.Entry != nil || c.Evaluation != nil {
			t.Fatal("同秒・同原行・不正BBOで取得")
		}
		x := testQuote133(102, 2, 95, 105)
		pending133(c, x, 5000)
		want := x.Ask
		if side < 0 {
			want = x.Bid
		}
		if c.Entry == nil || *c.Entry != x || *c.EntryPrice != want || c.Status != "filled" || *c.RiskAtDecision != 15 {
			t.Fatalf("初回正常BBO又は鏡像差 %+v", c)
		}
		pending133(c, testQuote133(103, 3, 85, 95), 5000)
		if *c.EntryPrice != want || c.Evaluation.Index != 2 {
			t.Fatal("既取得を改変")
		}
	}
}

// TestCapRiskRejectAndBoundary133 は価格上限・リスク否定の即時取消と境界を検査します。
//
// 引数: t(*testing.T)。返り値: ありません。拒否後の有利化を待ちません。
func TestCapRiskRejectAndBoundary133(t *testing.T) {
	for _, side := range []int{1, -1} {
		for _, test := range []struct {
			name string
			risk float64
			cap  bool
			want string
		}{{"上限", 15, true, "entry_cap_rejected"}, {"ゼロ", 0, false, "risk_rejected"}, {"負", -1, false, "risk_rejected"}, {"過大", 51, false, "risk_rejected"}, {"等号", 50, false, "filled"}} {
			t.Run(fmt.Sprintf("%d%s", side, test.name), func(t *testing.T) {
				q := testQuote133(100, 0, 95, 105)
				e := testEvent133(q, side)
				price := 105.0
				if side < 0 {
					price = 95
				}
				e.Invalidation = price - float64(side)*test.risk
				if test.cap {
					e.EntryCap = price - float64(side)
					e.Fields["hold_boundary"] = rules.Value{Known: true, Value: 100}
				}
				c, err := new133(e, q, 0, Scene133{Session: "s", Contract: "X", ForceClose: 5000})
				if err != nil {
					t.Fatal(err)
				}
				pending133(c, testQuote133(101, 1, 95, 105), 5000)
				if c.Status != test.want || c.Evaluation == nil || *c.RiskAtDecision != test.risk {
					t.Fatalf("拒否又は境界差 %+v", c)
				}
				if test.want != "filled" {
					pending133(c, testQuote133(102, 2, 96, 104), 5000)
					if c.Entry != nil || c.Evaluation.Index != 1 || c.Status != test.want {
						t.Fatal("拒否後に改善を待って取得")
					}
				}
			})
		}
		for _, test := range []struct {
			strict   bool
			distance float64
			want     string
		}{{true, 1, "filled"}, {true, 0, "structure_lost"}, {true, -1, "structure_lost"}, {false, 5, "filled"}, {false, 4, "structure_lost"}} {
			q := testQuote133(100, 0, 95, 105)
			e := testEvent133(q, side)
			e.Fields["hold_boundary"] = rules.Value{Known: true, Value: 100 - float64(side)*test.distance}
			strict, minimum := 0.0, 5.0
			if test.strict {
				strict, minimum = 1, 0
			}
			e.Fields["hold_strict"] = rules.Value{Known: true, Value: strict}
			e.Fields["hold_minimum"] = rules.Value{Known: true, Value: minimum}
			if test.want == "structure_lost" {
				e.Invalidation = 105
				if side < 0 {
					e.Invalidation = 95
				}
			}
			c, err := new133(e, q, 0, Scene133{Session: "s", Contract: "X", ForceClose: 5000})
			if err != nil {
				t.Fatal(err)
			}
			pending133(c, testQuote133(101, 1, 95, 105), 5000)
			if c.Status != test.want {
				t.Fatalf("構造維持の鏡像/等号差 side=%d strict=%t distance=%g got=%s", side, test.strict, test.distance, c.Status)
			}
			if test.want == "structure_lost" {
				pending133(c, testQuote133(102, 2, 95, 105), 5000)
				if c.Entry != nil || c.Evaluation.Index != 1 {
					t.Fatal("構造崩壊後に待機")
				}
			}
		}
	}
	q := testQuote133(100, 0, 995, 1005)
	e := testEvent133(q, 1)
	e.EntryCap, e.Invalidation = 1010, 905
	e.Fields["atr5"] = rules.Value{Known: true, Value: 1000}
	c, _ := new133(e, q, 0, Scene133{Session: "s", Contract: "X", ForceClose: 5000})
	pending133(c, testQuote133(101, 1, 995, 1005), 5000)
	if c.Status != "filled" || c.MaximumRisk != 100 {
		t.Fatal("100pt上限の等号差")
	}
}

// TestIdentityExpiryAndForce133 はScope/当原行と期限等号・ForceClose後出生を検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestIdentityExpiryAndForce133(t *testing.T) {
	q := testQuote133(100, 0, 95, 105)
	s := Scene133{Session: "s", Contract: "X", ForceClose: 5000}
	e := testEvent133(q, 1)
	wrong := e
	wrong.CohortID = ""
	if _, err := new133(wrong, q, 0, s); err == nil {
		t.Fatal("基礎出生系列IDなしを受理")
	}
	wrong = e
	wrong.Scope.Contract = "Y"
	if _, err := new133(wrong, q, 0, s); err == nil {
		t.Fatal("異限月受理")
	}
	wrong = e
	wrong.At.Last++
	if _, err := new133(wrong, q, 0, s); err == nil {
		t.Fatal("当原行差を受理")
	}
	wrong = e
	wrong.Fields = map[string]rules.Value{"atr5": {}}
	if _, err := new133(wrong, q, 0, s); err == nil {
		t.Fatal("未知ATR受理")
	}
	c, _ := new133(e, q, 0, s)
	pending133(c, testQuote133(130, 1, 95, 105), 5000)
	if c.Status != "unfilled_expired" || c.Evaluation != nil {
		t.Fatal("30秒等号で新規評価")
	}
	s.ForceClose = 100
	c, _ = new133(e, q, 0, s)
	if c.Request != nil || c.Status != "force_close" || c.Expires != 100 {
		t.Fatal("ForceClose後出生に要求")
	}
	s.ForceClose = 101
	c, _ = new133(e, q, 0, s)
	pending133(c, testQuote133(101, 1, 95, 105), 101)
	if c.Status != "force_close" || c.Entry != nil {
		t.Fatal("ForceClose等号に取得")
	}
}
