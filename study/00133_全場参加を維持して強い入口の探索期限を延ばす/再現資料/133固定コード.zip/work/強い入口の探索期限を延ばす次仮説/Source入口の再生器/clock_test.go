package holdingohlc113

import (
	"math"
	"testing"
)

// TestDeadlinesAndEntryCutoff133 は固定3h、新しい絶対期限、等号の取得禁止を検査します。
//
// 引数: t(*testing.T)は人工検査です。
// 返り値: ありません。自然Raw又は金融ラベルを使いません。
func TestDeadlinesAndEntryCutoff133(t *testing.T) {
	for _, duration := range []float64{7 * 3600, 13 * 3600} {
		original := Scene133{Session: "s", Contract: "X", Start: 100000, End: 100000 + duration, ForceClose: 100000 + duration - 600}
		s, err := sourceScene133(original)
		if err != nil || s.ForceClose != original.End-3900 || original.ForceClose != original.End-600 {
			t.Fatal("共通限界又は元非改変", err)
		}
		if deadlineAt133("L0", s) != original.Start+10800 || deadlineAt133("L1", s) != original.End-4020 || !math.IsInf(deadlineAt133("E0", s), 1) {
			t.Fatal("固定期限差")
		}
		for _, side := range []int{1, -1} {
			before := testQuote133(s.ForceClose-2, 0, 95, 105)
			c := supplement133("L1", "deadline", Decision133{Side: side}, before, s)
			if c.Expires != s.ForceClose {
				t.Fatal("30秒TTLより共通限界優先")
			}
			pending133(c, testQuote133(s.ForceClose-1, 1, 95, 105), s.ForceClose)
			if c.Entry == nil {
				t.Fatal("限界前の後原行1秒を拒否")
			}
			c = supplement133("L1", "deadline", Decision133{Side: side}, before, s)
			pending133(c, testQuote133(s.ForceClose, 1, 95, 105), s.ForceClose)
			if c.Entry != nil || c.Status != "force_close" {
				t.Fatal("限界等号で取得")
			}
			e := testEvent133(before, side)
			c, err = new133(e, before, 0, s)
			if err != nil {
				t.Fatal(err)
			}
			pending133(c, testQuote133(s.ForceClose, 1, 95, 105), s.ForceClose)
			if c.Entry != nil || c.Status != "force_close" {
				t.Fatal("E0だけ共通限界を越えた")
			}
		}
	}
}

// TestUnknownOrNoBBOIsNotCoverage133 は待ちや要求だけで参加を成功にしません。
//
// 引数: t(*testing.T)は人工検査です。
// 返り値: ありません。
func TestUnknownOrNoBBOIsNotCoverage133(t *testing.T) {
	c := supplement133("L1", "deadline", Decision133{Side: 1}, testQuote133(100, 0, 95, 105), Scene133{Session: "s", ForceClose: 5000})
	covered := map[string]bool{}
	bad := testQuote133(101, 1, 100, 100)
	keep, fills := processPending133([]*Candidate133{c}, bad, 5000, covered, map[string]bool{})
	if len(keep) != 1 || len(fills) != 0 || covered["L1"] {
		t.Fatal("異常BBOや要求を参加成功とした")
	}
}
