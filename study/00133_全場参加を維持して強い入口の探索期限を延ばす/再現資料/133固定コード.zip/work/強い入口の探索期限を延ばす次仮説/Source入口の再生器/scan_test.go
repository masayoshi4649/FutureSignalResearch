package holdingohlc113

import (
	"bytes"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
	"time"
)

// artificialLine133 は市場入力を使わず10深度の手製Raw行を作ります。
//
// 引数: t(*testing.T)、at(float64)、last/bid/ask(float64)は検査と人工価格時計です。
// 返り値: []byteは一行分のJSONと改行です。
func artificialLine133(t *testing.T, at, last, bid, ask float64) []byte {
	t.Helper()
	row := map[string]any{"Symbol": "X", "CurrentPriceTime": time.Unix(int64(at), 0).UTC().Format(time.RFC3339Nano), "CurrentPrice": last}
	for i := 1; i <= 10; i++ {
		row[fmt.Sprintf("Buy%d", i)] = map[string]float64{"Price": bid - float64(i-1), "Qty": 1}
		row[fmt.Sprintf("Sell%d", i)] = map[string]float64{"Price": ask + float64(i-1), "Qty": 1}
	}
	encoded, err := json.Marshal(row)
	if err != nil {
		t.Fatal(err)
	}
	return append(encoded, '\n')
}

// TestPlainGzipParserAndQuality133 は物理圧縮の違いで採用価格・時計・品質が変わらないことを検査します。
//
// 引数: t(*testing.T)は人工検査です。
// 返り値: ありません。元decodeRowの関数を人工行へ適用します。
func TestPlainGzipParserAndQuality133(t *testing.T) {
	plain := artificialLine133(t, 100, 107, 105, 110)
	var packed bytes.Buffer
	writer := gzip.NewWriter(&packed)
	if _, err := writer.Write(plain); err != nil {
		t.Fatal(err)
	}
	if err := writer.Close(); err != nil {
		t.Fatal(err)
	}
	var prior *Quote
	var priorCounts Counts
	for i, data := range [][]byte{plain, packed.Bytes()} {
		stream, encoding, err := rawStream133(bytes.NewReader(data))
		if err != nil {
			t.Fatal(err)
		}
		decoded, err := io.ReadAll(stream)
		stream.Close()
		if err != nil || !bytes.Equal(decoded, plain) {
			t.Fatal("人工stream差", err)
		}
		if encoding != []string{"plain", "gzip"}[i] {
			t.Fatal("magic判定差")
		}
		counts := Counts{Lines: 1}
		q, reason, stamp, err := decodeRow(bytes.TrimSpace(decoded), 1, 0, Scene{Start: 0, End: 200}, 0, &counts, map[string]bool{})
		if err != nil || reason != "" || stamp != 100 || q == nil || counts.Delivered != 1 || counts.Accepted != 1 || counts.BadBBO != 0 {
			t.Fatal("人工parser差", err)
		}
		if i > 0 && (!reflect.DeepEqual(q, prior) || counts != priorCounts) {
			t.Fatal("圧縮で採用結果差")
		}
		prior = q
		priorCounts = counts
	}
}

// TestArtificialSourceScanNoFinance133 は旧3h/新期限の差と取得のみのJSONを一走査で検査します。
//
// 引数: t(*testing.T)は人工検査です。
// 返り値: ありません。Rawはt.TempDirに作る5行の人工入力だけです。
func TestArtificialSourceScanNoFinance133(t *testing.T) {
	times := []float64{100000, 100801, 100802, 115980, 115981}
	var plain []byte
	for _, at := range times {
		plain = append(plain, artificialLine133(t, at, 107, 105, 110)...)
	}
	path := filepath.Join(t.TempDir(), "人工.jsonl")
	if err := os.WriteFile(path, plain, 0600); err != nil {
		t.Fatal(err)
	}
	digest := sha256.Sum256(plain)
	s := Scene133{Session: "s", Contract: "X", Start: 90000, End: 120000, ForceClose: 119400,
		Raw: FileRef{Path: path, SHA256: hex.EncodeToString(digest[:])}, ExpectedAccepted: 5,
		ExpectedQuality: &Counts{Lines: 5, Accepted: 5, Delivered: 5}}
	for i, x := range []struct {
		at, end float64
		index   int
	}{{100000, 99940, 0}, {100801, 100740, 1}, {115980, 115920, 3}} {
		p := scorePublication133("s", 300, x.index, x.end)
		p.Frame.Frame.ID = fmt.Sprintf("s/5/%d", i)
		p.Stamp.Time = x.at
		s.Publications = append(s.Publications, p)
	}
	result, err := scan133([]Scene133{s}, 0)
	if err != nil {
		t.Fatal(err)
	}
	if !result.Success || result.RawPasses != 1 || result.Quality != *s.ExpectedQuality || !result.Coverage["L0"] || !result.Coverage["L1"] {
		t.Fatal("一走査/全品質/取得参加差", result)
	}
	counts := map[string]int{}
	for _, c := range result.Candidates {
		if c.Status != "filled" {
			continue
		}
		counts[c.Policy]++
		if c.Direction.SourceSide != c.Birth.Side || c.Direction.SelectedSide != 1 || c.Entry == nil {
			t.Fatal("元方向と複合方向差")
		}
		if c.Policy == "L0" && (c.Birth.Time != 100801 || c.Entry.Time != 100802) {
			t.Fatal("L0時計差")
		}
		if c.Policy == "L1" && (c.Birth.Time != 115980 || c.Entry.Time != 115981) {
			t.Fatal("L1時計差")
		}
	}
	if counts["L0"] != 1 || counts["L1"] != 1 {
		t.Fatal("補完1取得差")
	}
	encoded, err := json.Marshal(result)
	if err != nil {
		t.Fatal(err)
	}
	for _, field := range []string{"\"outcomes\"", "\"touches\"", "\"net0\"", "\"net5\"", "\"endpoint\""} {
		if bytes.Contains(encoded, []byte(field)) {
			t.Fatal("Source結果へ金融項目混入", field)
		}
	}
}

// Test73ValidationAndInputSHA133 は73場0公表の定義保持と入力SHAの先行拒否を検査します。
//
// 引数: t(*testing.T)は人工検査です。
// 返り値: ありません。未知SHAでは入力ファイルすら読みません。
func Test73ValidationAndInputSHA133(t *testing.T) {
	var in Input133
	for i := 0; i < 73; i++ {
		start := float64(100000 + i*40000)
		in.Scenes = append(in.Scenes, Scene133{Session: fmt.Sprintf("s%03d", i), Contract: "X", Start: start, End: start + 30000, ForceClose: start + 29400, Raw: FileRef{Path: "人工", SHA256: strings.Repeat("a", 64)}, ExpectedAccepted: 1, ExpectedQuality: &Counts{Lines: 1, Accepted: 1, Delivered: 1}})
	}
	pubs, err := validateInput133(in, 1)
	if err != nil || pubs != 0 {
		t.Fatal("0公表場の定義削除", err)
	}
	short := in
	short.Scenes = short.Scenes[:72]
	if _, err := validateInput133(short, 1); err == nil {
		t.Fatal("72場受理")
	}
	if err := Run133("存在しない人工入力", "unknown", filepath.Join(t.TempDir(), "未生成.json"), 1); err == nil || !strings.Contains(err.Error(), "SHA") {
		t.Fatal("未知SHA guard差", err)
	}
}

// TestL0L1StrongSameSnapshot133 は政策名を変えても期限前の技術条件が変わらないことを確認します。
//
// 引数: t(*testing.T)は人工検査です。
// 返り値: ありません。旧P3のscore/strongにはpolicy引数がなく、差は期限だけです。
func TestL0L1StrongSameSnapshot133(t *testing.T) {
	for _, mirror := range []bool{false, true} {
		bank, window, q := scoreFixture133(t, true, mirror, nil)
		scene := Scene133{Session: "current", Contract: "X", Start: q.Time - 1000, End: q.Time + 24200, ForceClose: q.Time + 23600}
		var prior *Candidate133
		for _, policy := range []string{"L0", "L1"} {
			if q.Time >= deadlineAt133(policy, scene) {
				t.Fatal("人工は両期限前が必要")
			}
			decision, err := score133(bank, q, window)
			if err != nil {
				t.Fatal(err)
			}
			strong, ok := strong133(decision)
			if !ok {
				t.Fatal("共通strongが不成立")
			}
			c := supplement133(policy, "strong", strong, q, scene)
			snapshot, err := bank.Current(quote133(q))
			if err != nil {
				t.Fatal(err)
			}
			c.Direction, err = direction133(c.Birth.Side, c.Path, snapshot)
			if err != nil {
				t.Fatal(err)
			}
			if prior != nil && (c.Birth.Side != prior.Birth.Side || c.Birth.Quote != prior.Birth.Quote ||
				!reflect.DeepEqual(c.Decision, prior.Decision) || !reflect.DeepEqual(c.Direction, prior.Direction)) {
				t.Fatal("期限前に政策名だけでstrong又は方向が変化")
			}
			prior = c
		}
	}
}
