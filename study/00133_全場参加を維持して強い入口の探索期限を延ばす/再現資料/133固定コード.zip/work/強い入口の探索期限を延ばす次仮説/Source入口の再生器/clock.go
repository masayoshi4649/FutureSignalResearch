package holdingohlc113

import (
	"fmt"
	"math"
)

// sourceScene133 は新規取得の共通限界をH60の前へ固定し、元定義を変更しません。
//
// 引数: s(Scene133)は元122の場定義です。
// 返り値: Scene133/errorはForceCloseだけをmin(元,End-300-3600)へした私有copy又は不正理由です。
// 最初の2分は補完要求の猶予であり、通信受信時刻や必ず正常BBOが来ることを保証しません。
func sourceScene133(s Scene133) (Scene133, error) {
	if !finite(s.Start, s.End, s.ForceClose) || s.ForceClose <= s.Start || s.ForceClose > s.End {
		return s, fmt.Errorf("Source新規時計が不正:%s", s.Session)
	}
	s.ForceClose = math.Min(s.ForceClose, s.End-300-3600)
	if s.End-300-3600-120 <= s.Start || s.ForceClose <= s.Start {
		return s, fmt.Errorf("H60と補完余裕を置けない場:%s", s.Session)
	}
	return s, nil
}
