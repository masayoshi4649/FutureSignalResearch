package holdingohlc113

import (
	"encoding/json"
	"math"
	"testing"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// snapshotDirection133 は、未来情報を含まない人工の5/30分公表を作ります。
//
// 引数: side(int)、body/long/hist(float64)は元方向基準の比と値です。
// 返り値: rules.Snapshotは各境界検査が独立に変更できる値です。
func snapshotDirection133(side int, body, long, hist float64) rules.Snapshot {
	s := rules.Snapshot{SessionID: "人工Day", Contract: "人工限月", AsOf: rules.Quote{Time: 10000, Index: 100, Line: 101, Last: 150}, Frames: map[int]rules.Publication{}}
	for _, width := range []int{300, 1800} {
		end, at, index := 9900.0, 9962.0, 95
		if width == 1800 {
			end, at, index = 9000, 9062, 90
		}
		f := rules.ChartFrame{ID: "人工5", SessionID: s.SessionID, Contract: s.Contract, Width: width,
			Start: end - float64(width), End: end, AvailableAt: end + 60, DeliveryAt: at,
			PriceKnown: true, OHLC: rules.OHLC{Open: 150 - float64(side)*body*50, High: 200, Low: 100, Close: 150 + float64(side)*body*50}}
		if width == 300 {
			f.Technical.ATR = rules.Value{Known: true, Value: 10}
			f.Technical.Histogram = rules.Value{Known: true, Value: float64(side) * hist * 10}
		} else {
			f.ID = "人工30"
			f.Technical.EMA21Delta = rules.Value{Known: true, Value: float64(side) * long}
		}
		p := rules.Publication{Stamp: rules.Stamp{Time: at, Index: index, Line: index + 1}, Frame: rules.Frame{Frame: f}}
		s.Frames[width] = p
		s.Refs = append(s.Refs, rules.Ref{ID: f.ID, Width: width, End: end, Delivered: p.Stamp})
	}
	return s
}

// TestDirection133BodyBounds は、B0の半開区間と未知の扱いを確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestDirection133BodyBounds(t *testing.T) {
	for _, tc := range []struct {
		body float64
		want int
	}{{0, 1}, {.49999, 1}, {.5, -1}, {.74999, -1}, {.75, 1}} {
		s := snapshotDirection133(1, tc.body, -1, 0)
		d, err := direction133(1, "strong", s)
		if err != nil || d.B0Side != tc.want {
			t.Fatalf("実体境界 %g: %+v %v", tc.body, d, err)
		}
	}
	s := snapshotDirection133(1, 0, 0, .1)
	p := s.Frames[300]
	p.Frame.Frame.OHLC = rules.OHLC{Open: 150, High: 150, Low: 150, Close: 150}
	s.Frames[300] = p
	d, err := direction133(1, "strong", s)
	if err != nil || d.Fields["body5_signed_ratio_to_source"].Known || d.B0Side != 1 || d.T8Side != -1 {
		t.Fatalf("幅0ではB0未知keep、T8は別判定: %+v %v", d, err)
	}
}

// TestDirection133T8Bounds は、長期0とHist/ATR=.1の包含、未知とATR0を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestDirection133T8Bounds(t *testing.T) {
	for _, tc := range []struct {
		long, hist float64
		want       int
	}{{0, .1, -1}, {-.00001, .1, 1}, {1, .09999, 1}} {
		d, err := direction133(1, "deadline", snapshotDirection133(1, 0, tc.long, tc.hist))
		if err != nil || d.T8Side != tc.want {
			t.Fatalf("T8境界: %+v %v", d, err)
		}
	}
	for _, field := range []string{"long", "long_missing", "long_price_unknown", "hist", "atr0"} {
		s := snapshotDirection133(1, 0, 1, .2)
		if field == "long" {
			p := s.Frames[1800]
			p.Frame.Frame.Technical.EMA21Delta = rules.Value{Value: math.NaN()}
			s.Frames[1800] = p
		} else if field == "long_missing" {
			delete(s.Frames, 1800)
			s.Refs = s.Refs[:1]
		} else if field == "long_price_unknown" {
			p := s.Frames[1800]
			p.Frame.Frame.PriceKnown = false
			s.Frames[1800] = p
		} else {
			p := s.Frames[300]
			if field == "hist" {
				p.Frame.Frame.Technical.Histogram = rules.Value{Value: math.NaN()}
			} else {
				p.Frame.Frame.Technical.ATR.Value = 0
			}
			s.Frames[300] = p
		}
		d, err := direction133(1, "strong", s)
		if err != nil || d.T8Side != 1 {
			t.Fatalf("未知/ATR0: %s %+v %v", field, d, err)
		}
		if _, err := json.Marshal(d); err != nil {
			t.Fatalf("未知の非有限格納値を出力へ写した: %v", err)
		}
	}
}

// TestDirection133BasisAndE0 は、B0への符号変換とE0の元方向保護を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestDirection133BasisAndE0(t *testing.T) {
	s := snapshotDirection133(1, .6, -1, -.2)
	d, err := direction133(1, "strong", s)
	if err != nil || d.B0Side != -1 || d.T8Side != 1 || d.Fields["ema21_delta30_to_B0"].Value != 1 || d.Fields["hist5_atr_to_B0"].Value != .2 {
		t.Fatalf("B0基準: %+v %v", d, err)
	}
	for _, body := range []float64{0, .6} {
		for _, path := range []string{"E0", "strong", "deadline"} {
			d, err := direction133(1, path, snapshotDirection133(1, body, 1, .2))
			if err != nil {
				t.Fatal(err)
			}
			if path == "E0" {
				if !d.E0Protected || d.SelectedSide != 1 {
					t.Fatalf("E0非保護: %+v", d)
				}
			} else if d.E0Protected || d.SelectedSide != d.T8Side {
				t.Fatalf("補完方向: %+v", d)
			}
		}
	}
}

// TestDirection133Mirror は、価格反射と売買反転で同じ条件になることを確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestDirection133Mirror(t *testing.T) {
	for _, body := range []float64{0, .5, .6, .75} {
		s := snapshotDirection133(1, body, 1, .2)
		reflected := snapshotDirection133(-1, body, 1, .2)
		for _, path := range []string{"E0", "strong"} {
			a, e1 := direction133(1, path, s)
			b, e2 := direction133(-1, path, reflected)
			if e1 != nil || e2 != nil || a.SourceSide != -b.SourceSide || a.B0Side != -b.B0Side || a.T8Side != -b.T8Side || a.SelectedSide != -b.SelectedSide || a.E0Protected != b.E0Protected {
				t.Fatalf("売買鏡像: %+v %+v %v %v", a, b, e1, e2)
			}
			for _, key := range []string{"body5_signed_ratio_to_source", "ema21_delta30_to_B0", "hist5_atr_to_B0", "atr5"} {
				if a.Fields[key] != b.Fields[key] {
					t.Fatalf("鏡像の基準値: %s", key)
				}
			}
		}
	}
}

// TestDirection133RejectsInvalid は、既知非有限・未来・不整合を方向生成前に拒否します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestDirection133RejectsInvalid(t *testing.T) {
	for _, bad := range []string{"side", "path", "five_missing", "five_unknown", "hist_nan", "long_inf", "future_line", "ref", "overflow"} {
		s := snapshotDirection133(1, 0, 1, .2)
		side, path := 1, "strong"
		switch bad {
		case "side":
			side = 0
		case "path":
			path = " "
		case "five_missing":
			delete(s.Frames, 300)
		case "five_unknown":
			p := s.Frames[300]
			p.Frame.Frame.PriceKnown = false
			s.Frames[300] = p
		case "hist_nan":
			p := s.Frames[300]
			p.Frame.Frame.Technical.Histogram.Value = math.NaN()
			s.Frames[300] = p
		case "long_inf":
			p := s.Frames[1800]
			p.Frame.Frame.Technical.EMA21Delta.Value = math.Inf(1)
			s.Frames[1800] = p
		case "future_line":
			p := s.Frames[300]
			p.Stamp.Line = s.AsOf.Line + 1
			s.Frames[300] = p
			s.Refs[0].Delivered = p.Stamp
		case "ref":
			s.Refs[0].ID = "別公表"
		case "overflow":
			p := s.Frames[300]
			p.Frame.Frame.Technical.Histogram.Value = math.MaxFloat64
			p.Frame.Frame.Technical.ATR.Value = math.SmallestNonzeroFloat64
			s.Frames[300] = p
		}
		if _, err := direction133(side, path, s); err == nil {
			t.Fatalf("不正入力を受理: %s", bad)
		}
	}
}

// TestDirection133NoMutation は、入力と出力の可変参照を共有しないことを確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestDirection133NoMutation(t *testing.T) {
	s := snapshotDirection133(1, .6, -1, -.2)
	before, err := json.Marshal(s)
	if err != nil {
		t.Fatal(err)
	}
	d, err := direction133(1, "strong", s)
	if err != nil {
		t.Fatal(err)
	}
	d.Refs[0].ID = "出力側だけ変更"
	d.Fields["atr5"] = rules.Value{Known: true, Value: 999}
	after, err := json.Marshal(s)
	if err != nil || string(before) != string(after) {
		t.Fatalf("入力を変更: %v", err)
	}
}
