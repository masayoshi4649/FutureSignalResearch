// source133 は金融計算のないSource出生と取得の一走査だけを明示実行します。
package main

import (
	"flag"
	"fmt"
	"os"
	source "sourceentry133"
)

// main はF0後の明示フラグと固定入力指紋を受け、未作成の出生結果だけを保存します。
//
// 引数: コマンドラインのinput/expected-sha/output/workersとexecute-after-f0。
// 返り値: ありません。実行許可フラグ不足又は不整合は非0終了です。
func main() {
	input := flag.String("input", "", "固定122入力")
	expected := flag.String("expected-sha", "", "F0で固定した入力SHA256")
	output := flag.String("output", "", "未作成のSource結果JSON")
	workers := flag.Int("workers", 8, "並列場数1..8")
	execute := flag.Bool("execute-after-f0", false, "RootのF0固定後だけ明示する")
	flag.Parse()
	if !*execute || *input == "" || *output == "" {
		fmt.Fprintln(os.Stderr, "F0後の明示実行と入力/出力が必要")
		os.Exit(2)
	}
	if err := source.Run133(*input, *expected, *output, *workers); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
