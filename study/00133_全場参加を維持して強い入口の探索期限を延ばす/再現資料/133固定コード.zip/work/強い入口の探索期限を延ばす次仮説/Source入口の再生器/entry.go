package holdingohlc113

import (
	"bufio"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"os"
	"sync"

	birth "github.com/masayoshi4649/SessionTradeExecuter/entrybirth121"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

var Policies133 = []string{"E0", "L0", "L1"}

type Scene133 struct {
	Session          string              `json:"session"`
	Contract         string              `json:"contract"`
	Start            float64             `json:"start"`
	End              float64             `json:"end"`
	ForceClose       float64             `json:"force_close"`
	Raw              FileRef             `json:"raw"`
	ExpectedAccepted int64               `json:"expected_accepted"`
	ExpectedQuality  *Counts             `json:"expected_quality,omitempty"`
	Publications     []rules.Publication `json:"publications"`
}
type Input133 struct {
	Scenes []Scene133 `json:"scenes"`
}
type Signal133 struct {
	ID    string  `json:"id"`
	Side  int     `json:"side"`
	Time  float64 `json:"time"`
	Index int64   `json:"index"`
	Line  int64   `json:"source_line"`
	Quote Quote   `json:"quote"`
}
type Candidate133 struct {
	Path           string       `json:"path"`
	Decision       *Decision133 `json:"decision,omitempty"`
	Policy         string       `json:"policy"`
	CohortID       string       `json:"cohort_id"`
	Birth          Signal133    `json:"birth"`
	Event          int          `json:"event"`
	Request        *Quote       `json:"request"`
	Expires        float64      `json:"expires"`
	Limit          *float64     `json:"limit"`
	EntryCap       float64      `json:"entry_cap"`
	Invalidation   float64      `json:"invalidation"`
	ATR5           float64      `json:"atr5"`
	MaximumRisk    float64      `json:"maximum_risk"`
	HoldBoundary   float64      `json:"hold_boundary"`
	HoldMinimum    float64      `json:"hold_minimum"`
	HoldStrict     bool         `json:"hold_strict"`
	RiskAtDecision *float64     `json:"risk_at_decision"`
	Evaluation     *Quote       `json:"evaluation"`
	Status         string       `json:"status"`
	Entry          *Quote       `json:"entry"`
	EntryPrice     *float64     `json:"entry_price"`
	Direction      Direction133 `json:"direction"`
}
type Participation133 struct {
	ScoreChecks      uint64       `json:"score_checks"`
	Unknown          uint64       `json:"unknown"`
	Unresolved       uint64       `json:"unresolved"`
	StrongDenied     uint64       `json:"strong_denied"`
	Requests         uint64       `json:"requests"`
	FirstUnavailable *Decision133 `json:"first_unavailable,omitempty"`
	LastUnavailable  *Decision133 `json:"last_unavailable,omitempty"`
}
type Result133 struct {
	Session           string                       `json:"session"`
	Success           bool                         `json:"success"`
	Error             string                       `json:"error,omitempty"`
	Raw               FileRef                      `json:"raw"`
	ActualSHA         string                       `json:"actual_sha256"`
	Before            FileStat                     `json:"stat_before"`
	After             FileStat                     `json:"stat_after"`
	Quality           Counts                       `json:"quality"`
	ExpectedQuality   *Counts                      `json:"expected_quality,omitempty"`
	RawEncoding       string                       `json:"raw_encoding"`
	Publications      int                          `json:"publications"`
	Events            []birth.Event                `json:"events"`
	DetectorStats     birth.Stats                  `json:"detector_stats"`
	Candidates        []*Candidate133              `json:"candidates"`
	RawPasses         int                          `json:"raw_passes"`
	SourceSignalsUsed bool                         `json:"source_signals_used"`
	Participation     map[string]*Participation133 `json:"participation"`
	SourceForceClose  float64                      `json:"source_force_close"`
	EntryCutoff       float64                      `json:"entry_cutoff"`
	ExecutionEnd      float64                      `json:"execution_end"`
	FallbackAt        map[string]float64           `json:"fallback_at"`
	Coverage          map[string]bool              `json:"coverage"`
}

// ----------------------------------------
// quote133 は原板気配を発生器の当時価格時計へ射影します。
//
// 引数: q(Quote)。返り値: rules.QuoteはTime/Index/物理行/Lastです。
func quote133(q Quote) rules.Quote {
	return rules.Quote{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine), Last: q.Last}
}

// ----------------------------------------
// policy133 は事前固定したE0/L0/L1の3政策だけを認めます。
//
// 引数: policy(string)。返り値: boolは固定候補である場合です。
func policy133(policy string) bool {
	for _, p := range Policies133 {
		if policy == p {
			return true
		}
	}
	return false
}

// ----------------------------------------
// new133 は1分パターンの成立原行に独立1miniの成行要求を作ります。
//
// 引数: e(birth.Event)、q(Quote)、at(int)、s(Scene133)。返り値: *Candidate133/errorです。
func new133(e birth.Event, q Quote, at int, s Scene133) (*Candidate133, error) {
	if e.ID == "" || e.CohortID == "" || e.Scope.SessionID != s.Session || e.Scope.Contract != s.Contract || !policy133(string(e.Policy)) || (e.Side != 1 && e.Side != -1) || e.At != quote133(q) {
		return nil, fmt.Errorf("イベントの場/限月/候補/原行差")
	}
	atr, ok := e.Fields["atr5"]
	if !ok || !atr.Known || !finite(atr.Value, e.EntryCap, e.Invalidation) || atr.Value <= 0 || e.EntryCap <= 0 || e.Invalidation <= 0 {
		return nil, fmt.Errorf("イベントのATR/価格上限/否定境界が不明又は不正")
	}
	boundary, boundaryOK := e.Fields["hold_boundary"]
	minimum, minimumOK := e.Fields["hold_minimum"]
	strict, strictOK := e.Fields["hold_strict"]
	if !boundaryOK || !minimumOK || !strictOK || !boundary.Known || !minimum.Known || !strict.Known || !finite(boundary.Value, minimum.Value, strict.Value) || boundary.Value <= 0 || (strict.Value != 0 && strict.Value != 1) || (minimum.Value != 0 && minimum.Value != 5) || (strict.Value == 1 && minimum.Value != 0) {
		return nil, fmt.Errorf("イベントの取得時構造維持条件が不明又は不正")
	}
	x := q
	c := &Candidate133{Path: "E0", Policy: string(e.Policy), CohortID: e.CohortID, Birth: Signal133{ID: e.ID, Side: e.Side, Time: q.Time, Index: q.Index, Line: q.SourceLine, Quote: q}, Event: at, Request: &x, Expires: math.Min(q.Time+30, s.ForceClose), EntryCap: e.EntryCap, Invalidation: e.Invalidation, ATR5: atr.Value, MaximumRisk: math.Min(100, .5*atr.Value), HoldBoundary: boundary.Value, HoldMinimum: minimum.Value, HoldStrict: strict.Value == 1, Status: "pending"}
	if q.Time >= s.ForceClose {
		c.Status = "force_close"
		c.Request = nil
	}
	return c, nil
}

// ----------------------------------------
// fill133 は元方向geometryの取得時点だけを記録し、金融観測を開始しません。
//
// 引数: c(*Candidate133)、q(Quote)、price(float64)。返り値: ありません。
func fill133(c *Candidate133, q Quote, price float64) {
	x := q
	c.Entry = &x
	c.EntryPrice = &price
	c.Status = "filled"
}

// ----------------------------------------
// pending133 は期限と後原行1秒を満たす最初の正常BBOだけで取得を決めます。
//
// 引数: c(*Candidate133)、q(Quote)、force(float64)。返り値: ありません。
// 価格上限・構造維持・否定境界までのリスクが不適なら即取消し、有利化まで待ちません。
func pending133(c *Candidate133, q Quote, force float64) {
	if c.Status != "pending" || c.Entry != nil {
		return
	}
	if q.Time >= force {
		c.Status = "force_close"
		return
	}
	if q.Time >= c.Expires {
		c.Status = "unfilled_expired"
		return
	}
	if c.Request == nil || q.Index <= c.Request.Index || q.SourceLine <= c.Request.SourceLine || q.Time < c.Request.Time+1 || !q.QuoteOK || !normal(q) {
		return
	}
	x := q
	c.Evaluation = &x
	price := q.Ask
	if c.Birth.Side < 0 {
		price = q.Bid
	}
	if c.Path != "E0" {
		fill133(c, q, price)
		return
	}
	risk := float64(c.Birth.Side) * (price - c.Invalidation)
	c.RiskAtDecision = &risk
	if float64(c.Birth.Side)*(price-c.EntryCap) > 0 {
		c.Status = "entry_cap_rejected"
		return
	}
	hold := float64(c.Birth.Side) * (q.Last - c.HoldBoundary)
	if (c.HoldStrict && hold <= 0) || (!c.HoldStrict && hold < c.HoldMinimum) {
		c.Status = "structure_lost"
		return
	}
	if risk <= 0 || risk > c.MaximumRisk {
		c.Status = "risk_rejected"
		return
	}
	fill133(c, q, price)
}

// ----------------------------------------
// supplement133 は確定済み技術票から独立1miniの補完成行要求を作ります。
//
// 引数: policy/path(string)、d(Decision133)、q(Quote)、s(Scene133)。返り値: *Candidate133。
func supplement133(policy, path string, d Decision133, q Quote, s Scene133) *Candidate133 {
	x := q
	id := fmt.Sprintf("%s/補完/%s/%d", s.Session, policy, q.Index)
	cohort := fmt.Sprintf("%s/複合/%d/%d", s.Session, q.Index, d.Side)
	return &Candidate133{Path: path, Decision: &d, Policy: policy, CohortID: cohort,
		Birth: Signal133{ID: id, Side: d.Side, Time: q.Time, Index: q.Index, Line: q.SourceLine, Quote: q},
		Event: -1, Request: &x, Expires: math.Min(q.Time+30, s.ForceClose), ATR5: d.Components["ATR5"].Value,
		Status: "pending"}
}

// ----------------------------------------
// deadlineAt133 は補完政策の絶対価格時計の期限を返します。
//
// 引数: policy(string)、s(Scene133)。返り値: float64は絶対価格時計。E0には正の無限大です。
func deadlineAt133(policy string, s Scene133) float64 {
	switch policy {
	case "L0":
		return s.Start + 10800
	case "L1":
		return s.End - 300 - 3600 - 120
	}
	return math.Inf(1)
}

// ----------------------------------------
// hasPending133 は当政策の未終了新規要求があるか確認します。
//
// 引数: pending([]*Candidate133)、policy(string)。返り値: boolです。
func hasPending133(pending []*Candidate133, policy string) bool {
	for _, c := range pending {
		if c.Policy == policy && c.Status == "pending" {
			return true
		}
	}
	return false
}

// ----------------------------------------
// unavailable133 は不明又は同率の技術票の件数と最初/最後だけを保存します。
//
// 引数: stats(*Participation133)、d(Decision133)。返り値: ありません。
func unavailable133(stats *Participation133, d Decision133) {
	if !d.Eligible {
		stats.Unknown++
	} else {
		stats.Unresolved++
	}
	x := d
	if stats.FirstUnavailable == nil {
		stats.FirstUnavailable = &x
	}
	stats.LastUnavailable = &x
}

// ----------------------------------------
// processPending133 はE0を先に処理し、未参加時だけ補完要求の取得を許します。
//
// 引数: pending([]*Candidate133)、q(Quote)、force(float64)、covered/e0Born(map[string]bool)。
// 返り値: []*Candidate133二つは残る要求と今回の新規取得です。coveredは取得時だけ更新します。
func processPending133(pending []*Candidate133, q Quote, force float64, covered, e0Born map[string]bool) ([]*Candidate133, []*Candidate133) {
	keep := make([]*Candidate133, 0, len(pending))
	filled := []*Candidate133{}
	for _, c := range pending {
		if c.Path != "E0" {
			continue
		}
		pending133(c, q, force)
		if c.Entry != nil {
			filled = append(filled, c)
			covered[c.Policy] = true
		} else if c.Status == "pending" {
			keep = append(keep, c)
		}
	}
	for _, c := range pending {
		if c.Path == "E0" {
			continue
		}
		if covered[c.Policy] {
			c.Status = "cancelled_already_entered"
			continue
		}
		if e0Born[c.Policy] {
			c.Status = "cancelled_e0_priority"
			continue
		}
		pending133(c, q, force)
		if c.Entry != nil {
			filled = append(filled, c)
			covered[c.Policy] = true
		} else if c.Status == "pending" {
			keep = append(keep, c)
		}
	}
	return keep, filled
}

// ----------------------------------------
// scan133 は当場Rawを一走査し、公表・1分パターン・新規要求・取得時計だけを配送します。
//
// 引数: all([]Scene133)、at(int)。返り値: Result133/error。Source新規と取消は入力型に含めません。
func scan133(all []Scene133, at int) (out Result133, err error) {
	s := all[at]
	sourceForce := s.ForceClose
	s, err = sourceScene133(s)
	if err != nil {
		return out, err
	}
	out = Result133{Session: s.Session, Raw: s.Raw, Candidates: []*Candidate133{}, Events: []birth.Event{}, RawPasses: 1, ExpectedQuality: s.ExpectedQuality, Participation: map[string]*Participation133{}}
	for _, p := range Policies133[1:] {
		out.Participation[p] = &Participation133{}
	}
	bank := rules.NewBank()
	for i := 0; i < at; i++ {
		p := all[i]
		if err = bank.StartSession(p.Session, p.Contract); err != nil {
			return out, err
		}
		for _, pub := range p.Publications {
			if pub.Stamp.Time >= s.Start {
				return out, fmt.Errorf("前史が当場へ侵入")
			}
			if err = bank.Add(pub); err != nil {
				return out, err
			}
		}
	}
	if err = bank.StartSession(s.Session, s.Contract); err != nil {
		return out, err
	}
	detector := birth.NewDetector()
	if err = detector.StartSession(s.Session, s.Contract); err != nil {
		return out, err
	}
	f, e := os.Open(s.Raw.Path)
	if e != nil {
		return out, e
	}
	defer f.Close()
	before, e := f.Stat()
	if e != nil {
		return out, e
	}
	out.Before = FileStat{Bytes: before.Size(), ModTimeNS: before.ModTime().UnixNano()}
	hash := sha256.New()
	tee := io.TeeReader(f, hash)
	z, encoding, e := rawStream133(tee)
	if e != nil {
		return out, e
	}
	defer z.Close()
	out.RawEncoding = encoding
	scan := bufio.NewScanner(z)
	scan.Buffer(make([]byte, 65536), 8*1024*1024)
	scene := Scene{Session: s.Session, Contract: s.Contract, Start: s.Start, End: s.End, Raw: s.Raw}
	previous := s.Start
	var index int64
	pi := 0
	contracts := map[string]bool{}
	seen := map[string]bool{}
	pending := []*Candidate133{}
	covered := map[string]bool{}
	window := &Window133{}
	for scan.Scan() {
		out.Quality.Lines++
		q, _, next, e := decodeRow(scan.Bytes(), out.Quality.Lines, index, scene, previous, &out.Quality, contracts)
		previous = next
		if e != nil {
			return out, e
		}
		if q == nil {
			continue
		}
		index++
		for pi < len(s.Publications) && int64(s.Publications[pi].Stamp.Index) <= q.Index {
			pub := s.Publications[pi]
			if int64(pub.Stamp.Index) != q.Index || int64(pub.Stamp.Line) != q.SourceLine || pub.Stamp.Time != q.Time {
				return out, fmt.Errorf("公表実配送行差")
			}
			if err = bank.Add(pub); err != nil {
				return out, err
			}
			window.observe(pub)
			pi++
		}
		events, e := detector.Observe(bank, quote133(*q))
		if e != nil {
			return out, e
		}
		e0Born := map[string]bool{}
		for _, event := range events {
			if event.Policy != "E0" {
				continue
			}
			if seen[event.ID] {
				return out, fmt.Errorf("イベントID重複")
			}
			seen[event.ID] = true
			eventIndex := len(out.Events)
			out.Events = append(out.Events, event)
			for _, policy := range Policies133 {
				c, e := new133(event, *q, eventIndex, s)
				if e != nil {
					return out, e
				}
				c.Policy = policy
				snap, err := bank.Current(quote133(*q))
				if err != nil {
					return out, err
				}
				c.Direction, err = direction133(c.Birth.Side, c.Path, snap)
				if err != nil {
					return out, err
				}
				out.Candidates = append(out.Candidates, c)
				if c.Status == "pending" {
					pending = append(pending, c)
					e0Born[policy] = true
				}
			}
		}
		// ----------------------------------------
		// 同RawのE0要求・取得を、補完要求の取消しと取得より先に評価する。
		var newFills []*Candidate133
		pending, newFills = processPending133(pending, *q, s.ForceClose, covered, e0Born)
		_ = newFills
		// ----------------------------------------
		// 未取得の政策だけで当時の技術票を評価し、注文後に方向を変えない。
		var decision *Decision133
		for _, policy := range Policies133[1:] {
			if covered[policy] || hasPending133(pending, policy) || q.Time >= s.ForceClose {
				continue
			}
			if decision == nil {
				d, e := score133(bank, *q, window)
				if e != nil {
					return out, e
				}
				decision = &d
			}
			d := *decision
			stats := out.Participation[policy]
			stats.ScoreChecks++
			if !d.Eligible {
				unavailable133(stats, d)
				continue
			}
			path := "deadline"
			if q.Time < deadlineAt133(policy, s) {
				strong, ok := strong133(d)
				if !ok {
					stats.StrongDenied++
					continue
				}
				d = strong
				path = "strong"
			} else if d.Side == 0 {
				unavailable133(stats, d)
				continue
			}
			c := supplement133(policy, path, d, *q, s)
			snap, err := bank.Current(quote133(*q))
			if err != nil {
				return out, err
			}
			c.Direction, err = direction133(c.Birth.Side, c.Path, snap)
			if err != nil {
				return out, err
			}
			out.Candidates = append(out.Candidates, c)
			pending = append(pending, c)
			stats.Requests++
		}

	}
	if e = scan.Err(); e != nil {
		return out, e
	}
	if _, e = io.Copy(io.Discard, tee); e != nil {
		return out, e
	}
	after, e := f.Stat()
	if e != nil {
		return out, e
	}
	out.After = FileStat{Bytes: after.Size(), ModTimeNS: after.ModTime().UnixNano()}
	out.ActualSHA = hex.EncodeToString(hash.Sum(nil))
	if out.ActualSHA != s.Raw.SHA256 || out.Before != out.After {
		return out, fmt.Errorf("Raw SHA/stat差")
	}
	if len(contracts) != 1 || !contracts[s.Contract] || index != s.ExpectedAccepted || pi != len(s.Publications) {
		return out, fmt.Errorf("限月/全採用数/公表配送数差")
	}
	if s.ExpectedQuality != nil && out.Quality != *s.ExpectedQuality {
		return out, fmt.Errorf("全行品質metadata差")
	}
	for _, c := range pending {
		c.Status = "eof_unfilled"
	}

	for _, policy := range Policies133 {
		count, supplements := 0, 0
		for _, c := range out.Candidates {
			if c.Policy != policy {
				continue
			}
			if c.Path == "E0" {
				count++
			} else if c.Entry != nil {
				supplements++
			}
		}
		if count != len(out.Events) || supplements > 1 {
			return out, fmt.Errorf("E0保持又は補完1取得上限の差")
		}
	}
	out.DetectorStats = detector.Stats()
	out.Publications = pi
	out.SourceForceClose = sourceForce
	out.EntryCutoff = s.ForceClose
	out.ExecutionEnd = s.End - 300
	out.FallbackAt = map[string]float64{"L0": deadlineAt133("L0", s), "L1": deadlineAt133("L1", s)}
	out.Coverage = map[string]bool{}
	for _, p := range Policies133[1:] {
		out.Coverage[p] = covered[p]
	}
	out.Success = true
	return out, nil
}

// ----------------------------------------
// Run133 はRoot固定済み入力を用い、最大8場並列で未作成結果へ保存します。
//
// 引数: input/expected/output(string)、workers(int)。返り値: errorは指紋・配送・保存の不整合です。
func Run133(input, expected, output string, workers int) error {
	if !validSHA133(expected) {
		return fmt.Errorf("F1固定の入力SHA小文字64桁を指定してください")
	}
	data, err := os.ReadFile(input)
	if err != nil {
		return err
	}
	sum := sha256.Sum256(data)
	if hex.EncodeToString(sum[:]) != expected {
		return fmt.Errorf("入力SHA差")
	}
	var in Input133
	if err = json.Unmarshal(data, &in); err != nil {
		return err
	}
	pubs, err := validateInput133(in, workers)
	if err != nil {
		return err
	}
	if _, err = os.Stat(output); !os.IsNotExist(err) {
		return fmt.Errorf("新規先だけ")
	}
	results := make([]Result133, len(in.Scenes))
	jobs := make(chan int)
	var wg sync.WaitGroup
	for i := 0; i < workers; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for at := range jobs {
				r, e := scan133(in.Scenes, at)
				if e != nil {
					r.Error = e.Error()
				}
				results[at] = r
				fmt.Printf("%s 成功=%t %s\n", r.Session, r.Success, r.Error)
			}
		}()
	}
	for i := range in.Scenes {
		jobs <- i
	}
	close(jobs)
	wg.Wait()
	for _, r := range results {
		if !r.Success {
			return fmt.Errorf("%s: %s", r.Session, r.Error)
		}
	}
	encoded, err := json.MarshalIndent(map[string]any{"trial": 133, "success": true, "input_sha256": expected, "policies": Policies133, "scenes": results, "scene_count": len(in.Scenes), "publication_count": pubs, "portfolio_pnl": false, "candidate_quantity": 1, "source_signals_used": false, "stage": "Source入口のみ・金融未計算", "source_geometry_order_eligibility": true, "selected_direction_order_eligibility_rebuilt": false, "outcomes_computed": false, "entry_clock": "1秒後原行/30秒TTL・全方向とも元geometryで生まれた取得時計"}, "", "  ")
	if err != nil {
		return err
	}
	after, err := os.ReadFile(input)
	if err != nil {
		return err
	}
	if sha256.Sum256(after) != sum {
		return fmt.Errorf("入力前後差")
	}
	f, err := os.OpenFile(output, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if err != nil {
		return err
	}
	defer f.Close()
	_, err = f.Write(append(encoded, '\n'))
	return err
}
