package holdingohlc113

import (
	"fmt"
	"math"
	"strings"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// Direction133 は、元方向と固定B0/T8の計算、E0保護を分けて保存します。
//
// Fieldsの未知はKnown=falseのまま保持し、Refsは入力sliceを共有しません。
type Direction133 struct {
	SourceSide   int                    `json:"source_side"`
	B0Side       int                    `json:"b0_side"`
	T8Side       int                    `json:"t8_side"`
	SelectedSide int                    `json:"selected_side"`
	E0Protected  bool                   `json:"e0_protected"`
	Fields       map[string]rules.Value `json:"fields"`
	Refs         []rules.Ref            `json:"refs"`
}

// finiteDirection133 は、既知値と計算結果に非有限値が無いか確認します。
//
// 引数: value(float64)。返り値: boolは有限なら真です。
func finiteDirection133(value float64) bool {
	return !math.IsNaN(value) && !math.IsInf(value, 0)
}

// valueDirection133 は、未知の格納値を判断に使わず未知maskを保持します。
//
// 引数: value(rules.Value)。返り値: rules.Valueは既知値又はKnown=falseの値です。
func valueDirection133(value rules.Value) rules.Value {
	if !value.Known {
		return rules.Value{}
	}
	return value
}

// validateDirectionSnapshot133 は、当時の公表と参照の対応を純粋に検査します。
//
// 引数: s(rules.Snapshot)は同じRaw行の全公表を配送した後の値です。
// 返り値: errorは場・時計・参照・既知数値の不正です。未成熟の30分は許可します。
func validateDirectionSnapshot133(s rules.Snapshot) error {
	if s.SessionID == "" || s.Contract == "" || !finiteDirection133(s.AsOf.Time) ||
		!finiteDirection133(s.AsOf.Last) || s.AsOf.Last <= 0 || s.AsOf.Index < 0 || s.AsOf.Line < 1 {
		return fmt.Errorf("方向計算の場・限月・現在原行が不正です")
	}
	if p, ok := s.Frames[300]; !ok || !p.Frame.Frame.PriceKnown {
		return fmt.Errorf("方向計算には価格既知の当場5分公表が必要です")
	}
	if len(s.Refs) != len(s.Frames) {
		return fmt.Errorf("方向計算の公表と参照の件数が異なります")
	}
	seen := map[int]bool{}
	for _, ref := range s.Refs {
		p, ok := s.Frames[ref.Width]
		if !ok || seen[ref.Width] {
			return fmt.Errorf("方向計算の参照が欠落又は重複しています")
		}
		f := p.Frame.Frame
		if ref != (rules.Ref{ID: f.ID, Width: f.Width, End: f.End, Delivered: p.Stamp}) {
			return fmt.Errorf("方向計算の参照と公表が一致しません")
		}
		seen[ref.Width] = true
	}
	for width, p := range s.Frames {
		f := p.Frame.Frame
		if (width != 300 && width != 900 && width != 1800) || f.Width != width ||
			f.ID == "" || f.SessionID != s.SessionID || f.Contract != s.Contract {
			return fmt.Errorf("方向計算の公表識別・幅・場・限月が不正です")
		}
		for _, v := range []float64{f.Start, f.End, f.AvailableAt, f.DeliveryAt, p.Stamp.Time} {
			if !finiteDirection133(v) {
				return fmt.Errorf("方向計算の公表時計が非有限です")
			}
		}
		if f.Start > f.End || f.End > f.AvailableAt || f.AvailableAt > f.DeliveryAt ||
			f.DeliveryAt > p.Stamp.Time || p.Stamp.Time > s.AsOf.Time ||
			p.Stamp.Index < 0 || p.Stamp.Line < 1 || p.Stamp.Index > s.AsOf.Index || p.Stamp.Line > s.AsOf.Line ||
			s.AsOf.Time >= f.End+float64(width)+60 {
			return fmt.Errorf("方向計算の公表が未来又は期限切れです")
		}
		if f.PriceKnown {
			o := f.OHLC
			if !finiteDirection133(o.Open) || !finiteDirection133(o.High) || !finiteDirection133(o.Low) ||
				!finiteDirection133(o.Close) || o.Low <= 0 || o.High < o.Low ||
				o.Open < o.Low || o.Open > o.High || o.Close < o.Low || o.Close > o.High {
				return fmt.Errorf("方向計算の既知OHLCが不正です")
			}
		}
		if f.VolumeKnown && (!finiteDirection133(f.Volume) || f.Volume < 0) {
			return fmt.Errorf("方向計算の既知出来高が不正です")
		}
		t, d := f.Technical, p.Frame.DMI
		values := []rules.Value{t.EMA8, t.EMA21, t.EMA8Delta, t.EMA21Delta, t.Gap, t.ATR, t.PreviousATR,
			t.TR, t.RSI, t.PreviousRSI, t.Histogram, t.PreviousHistogram, d.PlusDI, d.MinusDI, d.ADX, d.PreviousADX}
		for _, value := range values {
			if value.Known && !finiteDirection133(value.Value) {
				return fmt.Errorf("方向計算の既知テクニカル値が非有限です")
			}
		}
	}
	if s.RVOL5.Known && !finiteDirection133(s.RVOL5.Value) {
		return fmt.Errorf("方向計算の既知RVOLが非有限です")
	}
	if s.BB15.Known {
		for _, value := range []float64{s.BB15.Mean, s.BB15.Sigma, s.BB15.Upper, s.BB15.Lower} {
			if !finiteDirection133(value) {
				return fmt.Errorf("方向計算の既知BBが非有限です")
			}
		}
	}
	return nil
}

// direction133 は、固定B0/T8を当時の公表から計算しE0の元方向を保護します。
//
// 引数: originalSide(int)は±1、path(string)はE0又は補完経路、s(rules.Snapshot)は同Raw全配送後です。
// 返り値: Direction133/errorは方向・既知mask・原値・独立参照、又は不正引数の拒否です。
// 同Rawの配送が全て済んだこと自体は呼出側が保証し、この関数は保存時計の因果を検査します。
func direction133(originalSide int, path string, s rules.Snapshot) (Direction133, error) {
	if (originalSide != 1 && originalSide != -1) || strings.TrimSpace(path) == "" {
		return Direction133{}, fmt.Errorf("方向計算の元方向又は経路が不正です")
	}
	if err := validateDirectionSnapshot133(s); err != nil {
		return Direction133{}, err
	}
	f5 := s.Frames[300].Frame.Frame
	width := f5.OHLC.High - f5.OHLC.Low
	body := float64(originalSide) * (f5.OHLC.Close - f5.OHLC.Open)
	ratio := rules.Value{}
	if width > 0 {
		ratio = rules.Value{Known: true, Value: body / width}
	}
	b0 := originalSide
	if ratio.Known && ratio.Value >= .5 && ratio.Value < .75 {
		b0 = -originalSide
	}
	// ----------------------------------------
	// 実体比の未知はB0だけをkeepし、T8の別の既知条件は通常通り評価します。
	atr := valueDirection133(f5.Technical.ATR)
	hist := valueDirection133(f5.Technical.Histogram)
	long := rules.Value{}
	if p30, ok := s.Frames[1800]; ok && p30.Frame.Frame.PriceKnown {
		long = valueDirection133(p30.Frame.Frame.Technical.EMA21Delta)
	}
	longToB0 := long
	if longToB0.Known {
		longToB0.Value *= float64(b0)
	}
	histToB0 := hist
	if histToB0.Known {
		histToB0.Value *= float64(b0)
	}
	histATR := rules.Value{}
	if histToB0.Known && atr.Known && atr.Value > 0 {
		histATR = rules.Value{Known: true, Value: histToB0.Value / atr.Value}
	}
	t8 := b0
	if longToB0.Known && longToB0.Value >= 0 && histATR.Known && histATR.Value >= .1 {
		t8 = -b0
	}
	fields := map[string]rules.Value{
		"body5_signed_ratio_to_source": ratio, "ema21_delta30_to_B0": longToB0,
		"hist5_atr_to_B0": histATR, "atr5": atr, "hist5_raw": hist, "ema21_delta30_raw": long,
		"hist5_to_B0": histToB0, "open5": {Known: true, Value: f5.OHLC.Open},
		"high5": {Known: true, Value: f5.OHLC.High}, "low5": {Known: true, Value: f5.OHLC.Low},
		"close5": {Known: true, Value: f5.OHLC.Close}, "range5": {Known: true, Value: width},
		"body5_to_source_pt": {Known: true, Value: body},
	}
	for _, field := range fields {
		if field.Known && !finiteDirection133(field.Value) {
			return Direction133{}, fmt.Errorf("方向計算の派生値が非有限です")
		}
	}
	selected := t8
	protected := path == "E0"
	if protected {
		selected = originalSide
	}
	return Direction133{SourceSide: originalSide, B0Side: b0, T8Side: t8, SelectedSide: selected,
		E0Protected: protected, Fields: fields, Refs: append([]rules.Ref(nil), s.Refs...)}, nil
}
