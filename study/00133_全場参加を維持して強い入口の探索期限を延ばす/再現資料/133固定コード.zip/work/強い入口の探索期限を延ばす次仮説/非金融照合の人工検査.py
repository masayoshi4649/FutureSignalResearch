"""Source出生の対照比較と固定方向の独立式を人工検査する。自然結果を読まない。"""
import copy
import importlib.util
from pathlib import Path
import unittest

spec=importlib.util.spec_from_file_location('comparison',Path(__file__).with_name('L0と旧79件を照合する.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


def fixture(side: int=1, path: str='strong') -> dict:
    """
    機能: 5分足とMACD/MAだけの手製方向票を作る。
    引数: side(int)、path(str)は元方向と型。
    返り値: dictは金融ラベルを持たないSource候補。
    """
    raw={'open5':100,'high5':110,'low5':90,'close5':105,'body5_signed_ratio_to_source':side*.25,
         'ema21_delta30_raw':side,'hist5_raw':side*2,'atr5':20,
         'ema21_delta30_to_B0':1,'hist5_atr_to_B0':.1}
    d={'source_side':side,'b0_side':side,'t8_side':-side,'selected_side':side if path=='E0' else -side,
       'e0_protected':path=='E0','fields':{k:{'known':True,'value':v} for k,v in raw.items()},'refs':[]}
    return {'birth':{'id':'s/補完/L0/1','side':side,'time':100,'index':1,'source_line':2},
            'policy':'L0','path':path,'direction':d}


class Tests(unittest.TestCase):
    """未知・境界・識別子・金融分離の4主検査。"""
    def test_nonfinance_normalization(self):
        """
        機能: 既存の金融値はSource比較へ使わず、入力を変更しない。
        引数: self(Tests)。返り値: None。
        """
        new=fixture();old=m.normalized(new,True);old['outcomes']=[{'net5':-999999}];old['last_normal_time']=9999
        prior=copy.deepcopy(old);self.assertEqual(m.normalized(old,False),m.normalized(new,True));self.assertEqual(old,prior)
        changed=copy.deepcopy(new);changed['birth']['time']=101
        self.assertNotEqual(m.normalized(old,False),m.normalized(changed,True))

    def test_fixed_direction_boundary_and_e0(self):
        """
        機能: .1等号の反転とE0保護を独立式へ通す。
        引数: self(Tests)。返り値: None。
        """
        for side in (1,-1):
            for path in ('strong','deadline','E0'):m.validate_direction(fixture(side,path))

    def test_unknown_not_zero(self):
        """
        機能: 30分未知を既知0の反転条件と混ぜない。
        引数: self(Tests)。返り値: None。
        """
        x=fixture()
        for key in ('ema21_delta30_raw','ema21_delta30_to_B0'):x['direction']['fields'][key]={'known':False,'value':0}
        x['direction']['t8_side']=1;x['direction']['selected_side']=1;m.validate_direction(x)
        x['direction']['t8_side']=-1
        with self.assertRaises(AssertionError):m.validate_direction(x)

    def test_nonfinite_or_future_ref_rejected(self):
        """
        機能: 既知非有限値や未来参照を拒否する。
        引数: self(Tests)。返り値: None。
        """
        x=fixture();x['direction']['fields']['atr5']['value']=float('nan')
        with self.assertRaises(AssertionError):m.validate_direction(x)
        x=fixture();x['direction']['refs']=[{'delivered':{'time':101,'index':1,'source_line':2}}]
        with self.assertRaises(AssertionError):m.validate_direction(x)


if __name__=='__main__':unittest.main()
