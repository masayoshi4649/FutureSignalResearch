"""保存観測だけを新workで再集計し、再現用パス台帳以外の全正本と一致を確認する。"""
from pathlib import Path
import copy
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
FORMAL = ROOT / 'study/00133_全場参加を維持して強い入口の探索期限を延ばす'
RESTORED = ROOT / 'work/133正式保存の復元確認'


def sha(path: Path) -> str:
    """
    機能: ファイル内容の指紋を返す。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: Rawに触れず保存正逆観測を再集計し、原集計と全三表の同体を確認する。
    引数: なし。
    返り値: None。新しい仮説/閾値/入力で評価せず、元の結果を上書きしない。
    """
    assert RESTORED.is_relative_to(ROOT / 'work') and RESTORED.exists()
    manifest = json.loads((FORMAL / '保管索引.json').read_bytes())
    run = RESTORED / 'work/133探索期限の評価'
    ledger = run / '再現用パス台帳.json'
    fixed = run / '固定入力/固定取得入力.json'
    metadata = run / '固定入力/方向と出生.json'
    observed = run / '固定取得の正逆観測.json'
    output = RESTORED / 'work/133保存観測からの再集計'
    assert not output.exists()
    command = [sys.executable, '-X', 'utf8', str(RESTORED / 'work/133期限別の集計/集計する.py'),
               '--f1', str(ledger), '--f1-sha256', sha(ledger),
               '--fixed-input', str(fixed), '--fixed-input-sha256', sha(fixed),
               '--metadata', str(metadata), '--metadata-sha256', sha(metadata),
               '--result', str(observed), '--result-sha256', sha(observed), '--output-dir', str(output)]
    executed = subprocess.run(command, cwd=RESTORED, text=True, encoding='utf-8', capture_output=True)
    assert executed.returncode == 0, (executed.stdout, executed.stderr)
    replay = json.loads((output / '集計.json').read_bytes())
    original = json.loads((FORMAL / '成果物/集計.json').read_bytes())
    assert replay['F1_SHA256'] == sha(ledger) and original['F1_SHA256'] == '98379bf9359ab918db931f649298fec88826bb2df71330c459612eec786c70a3'
    normalized = copy.deepcopy(replay)
    normalized['F1_SHA256'] = original['F1_SHA256']
    assert normalized == original
    table_sha = sha(output / 'CSV用の表.json')
    assert table_sha == 'eab6af830eb9c68f68dfb4cc594d0c2f8e5f3f057e3997a92a1d056a7f00c59b'
    assert sha(observed) == manifest['新正逆観測']['解凍SHA256']
    assert sha(run / 'F1.json') == original['F1_SHA256']
    value = {'成功': True, '試行': 133, '原F1は同体保持': True,
             '原F1_SHA256': original['F1_SHA256'], '再現用パス台帳SHA256': sha(ledger),
             '台帳は新しい事前F1ではない': True, '保存観測から再集計': True,
             '再現差はF1_SHA256という台帳参照だけ': True, 'その他の全正本フィールド同体': True,
             '全三表JSON_SHA256同体': table_sha, '新仮説の金融実行': False,
             'Source/Raw再走査': False, '177MB本文読取': False, '新CSV生成': False,
             '実行列': command, 'stdout': executed.stdout, 'stderr': executed.stderr,
             'コードSHA256': sha(Path(__file__))}
    with (FORMAL / '検査/保存観測からの再現確認.json').open('x', encoding='utf-8', newline='\n') as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2); handle.write('\n')
    print(json.dumps({'成功': True, '三表SHA256': table_sha, '原F1不変': True,
                      'F1参照以外の全正本同体': True, 'Raw再走査': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
