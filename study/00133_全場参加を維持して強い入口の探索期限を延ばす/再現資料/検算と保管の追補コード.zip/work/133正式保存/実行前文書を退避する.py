"""133のF0/F1全MDを、正式な結果記述を行う前に同体で圧縮退避する。"""
from pathlib import Path
import gzip
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
FORMAL = ROOT / 'study/00133_全場参加を維持して強い入口の探索期限を延ばす'
RUN = ROOT / 'work/133探索期限の評価'


def sha(body: bytes) -> str:
    """
    機能: 保存する原文の指紋を返す。
    引数: body(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: F0/F1指紋と全MD現物を照合して、共通本文を一度だけ保存する。
    引数: なし。
    返り値: None。金融・原板・Source入力を再実行/読取しない。
    """
    stages = {}
    documents = {}
    for name, expected in [('F0', '4b581c827391405db747f4c043f5252378ec21ce78ffec89d4339eb81aace01c'),
                           ('F1', '98379bf9359ab918db931f649298fec88826bb2df71330c459612eec786c70a3')]:
        body = (RUN / (name + '.json')).read_bytes()
        assert sha(body) == expected
        fixed = json.loads(body)
        paths = []
        for path, value in fixed['ファイル'].items():
            p = Path(path)
            if p.suffix.lower() != '.md':
                continue
            raw = p.read_bytes(); assert sha(raw) == value, p
            relative = p.relative_to(ROOT).as_posix()
            record = {'path': relative, 'bytes': len(raw), 'sha256': value, '本文': raw.decode('utf-8')}
            assert relative not in documents or documents[relative] == record
            documents[relative] = record; paths.append(relative)
        stages[name] = {'sha256': expected, 'MD数': len(paths), 'MD': paths}
        destination = FORMAL / '検査' / (name + '.json')
        destination.parent.mkdir(exist_ok=True)
        with destination.open('xb') as handle:
            handle.write(body)
    value = {'試行': 133, '段階': stages, '共通原文は一度保存': True,
             '文書': list(documents.values())}
    raw = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    packed = gzip.compress(raw, mtime=0)
    destination = FORMAL / '検査/実行前文書.json.gz'
    with destination.open('xb') as handle:
        handle.write(packed)
    for record in json.loads(gzip.decompress(packed))['文書']:
        assert sha(record['本文'].encode('utf-8')) == record['sha256']
    proof = {'成功': True, '試行': 133, 'F0_MD数': stages['F0']['MD数'], 'F1_MD数': stages['F1']['MD数'],
             '重複を除く全MD原文数': len(documents), 'gzipSHA256': sha(packed), '解凍SHA256': sha(raw),
             '正式結果編集前の原文退避': True, '全原文と復元SHA一致': True,
             '金融再実行': False, 'Raw読取': False}
    (FORMAL / '検査/実行前文書の確認.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(proof, ensure_ascii=False))


if __name__ == '__main__':
    main()
