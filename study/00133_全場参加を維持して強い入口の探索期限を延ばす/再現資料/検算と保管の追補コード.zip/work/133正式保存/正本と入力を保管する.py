"""133のSource/固定入力を一度だけ保存し、F0/F1コードと正逆結果を保管する。"""
from pathlib import Path
import gzip
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
FORMAL = ROOT / 'study/00133_全場参加を維持して強い入口の探索期限を延ばす'
RUN = ROOT / 'work/133探索期限の評価'
AGG = ROOT / 'work/133期限別の集計'
INPUTS = ROOT / 'inputs/00133_探索期限延長の共用入力'


def sha(body: bytes) -> str:
    """
    機能: 保存内容の指紋を返す。
    引数: body(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


# ----------------------------------------
def put(path: Path, body: bytes) -> None:
    """
    機能: 未作成先へ同体bytesを保存する。
    引数: path(Path)、body(bytes)。
    返り値: None。既存の正式資源へ上書きしない。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as handle:
        handle.write(body)


# ----------------------------------------
def packed(source: Path, destination: Path, expected: str) -> dict:
    """
    機能: 固定JSONを一度gzip化して、元bytesと保存bytesの指紋を残す。
    引数: source/destination(Path)、expected(str)は元JSONのSHA256。
    返り値: dictは保存先/元/サイズ/SHAの記録。
    """
    body = source.read_bytes(); assert sha(body) == expected
    encoded = gzip.compress(body, mtime=0)
    assert gzip.decompress(encoded) == body
    put(destination, encoded)
    return {'保存元': destination.relative_to(ROOT).as_posix(), '復元先': source.relative_to(ROOT).as_posix(),
            '保存bytes': len(encoded), '保存SHA256': sha(encoded), '解凍bytes': len(body), '解凍SHA256': sha(body),
            '形式': 'gzip'}


# ----------------------------------------
def main() -> None:
    """
    機能: 非重複入力・金融正本・指紋・小型コードを永久保存する。
    引数: なし。
    返り値: None。Raw/177MB共用入力の本文を読まず、金融再計算もしない。
    """
    assert (FORMAL / '検査/実行前文書.json.gz').is_file()
    f0 = json.loads((RUN / 'F0.json').read_bytes()); f1 = json.loads((RUN / 'F1.json').read_bytes())
    inputs = [
        packed(RUN / 'Sourceの出生と取得.json', INPUTS / 'Sourceの出生と取得.json.gz', '4c9449b620c15a63c00f9810eeaa52fc8f0eb5f92f7ea2d124cc9db12cc728f6'),
        packed(RUN / '固定入力/固定取得入力.json', INPUTS / '固定取得入力.json.gz', '5efb1b9ef1f1130d4507f926601f8cabe50757463d7523858351833abc6d0b5e'),
        packed(RUN / '固定入力/方向と出生.json', INPUTS / '方向と出生.json.gz', 'a328f6b902e9ace8d4d764974570f6beeacda91bd099933d1b716b68875a49d2'),
    ]
    financial = packed(RUN / '固定取得の正逆観測.json', FORMAL / '成果物/固定取得の正逆観測.json.gz', sha((RUN / '固定取得の正逆観測.json').read_bytes()))
    aggregate = (AGG / '集計.json').read_bytes()
    assert sha(aggregate) == '21e686aa350f6b093ae83b0503acecc006df38905b74478315967648f2d5858b'
    put(FORMAL / '成果物/集計.json', aggregate)
    references = []
    for source, target, form in [
        ('inputs/00124_同入口正逆の共用入力/入力.json.gz', 'inputs/00124_同入口正逆の共用入力/入力.json.gz', '同体'),
        ('study/00124_逆行の原因と売買反転を同じ入口で検証する/成果物/集計.json.gz', 'work/124入口の原因分析/集計.json', 'gzip'),
        ('study/00124_逆行の原因と売買反転を同じ入口で検証する/成果物/全73場の正逆結果.json.gz', 'work/124入口の正逆比較/全73場の正逆結果.json', 'gzip'),
        ('study/00131_中期MACDの位相で複合入口の方向を切り替える/成果物/集計.json', 'work/131既存入口の位相切替評価/集計.json', '同体'),
        ('inputs/00131_T8の15分位相切替/choices.json.gz', 'work/T8の15分位相による切替案/choices.json', 'gzip'),
    ]:
        body = (ROOT / source).read_bytes()
        expanded = gzip.decompress(body) if form == 'gzip' else body
        assert sha(expanded) == f1['ファイル'][str(ROOT / target)]
        references.append({'保存元': source, '復元先': target, '形式': form,
                           '保存SHA256': sha(body), '解凍SHA256': sha(expanded)})
    destinations = {
        'work/133探索期限の評価/F0.json': FORMAL / '検査/F0.json',
        'work/133探索期限の評価/L0旧79の同体確認.json': FORMAL / '検査/L0旧79の同体確認.json',
        'work/133探索期限の評価/出生段階の完了.json': FORMAL / '検査/出生段階の完了.json',
        'work/133探索期限の評価/固定入力/転送の確認.json': FORMAL / '検査/転送の確認.json',
        'work/133期限別の集計/準備の確認.json': FORMAL / '検査/集計器の準備確認.json',
        'work/強い入口の探索期限を延ばす次仮説/元コードの指紋.json': FORMAL / '検査/Sourceの元コード指紋.json',
        'work/強い入口の探索期限を延ばす次仮説/公表末尾の期限可用性.json': FORMAL / '根拠/公表末尾の期限可用性.json.gz',
        'work/強い入口の探索期限を延ばす次仮説/旧79件の時計と新期限.json': FORMAL / '根拠/旧79件の時計と新期限.json.gz',
        'work/強い入口の探索期限を延ばす次仮説/準備の確認.json': FORMAL / '検査/Sourceの準備確認.json',
    }
    small = []
    for name, destination in destinations.items():
        body = (ROOT / name).read_bytes()
        assert sha(body) == f1['ファイル'][str(ROOT / name)]
        form = 'gzip' if destination.suffix == '.gz' else '同体'
        encoded = gzip.compress(body, mtime=0) if form == 'gzip' else body
        if destination.exists():
            assert destination.read_bytes() == encoded
        else:
            put(destination, encoded)
        small.append({'保存元': destination.relative_to(ROOT).as_posix(), '復元先': name, '形式': form,
                      '保存SHA256': sha(encoded), '解凍SHA256': sha(body)})
    for source, target in [(RUN / '正逆観測の完了.json', '正逆観測の完了.json'),
                           (RUN / '金融段階の完了.json', '金融段階の完了.json'),
                           (AGG / '集計完了.json', '集計完了.json')]:
        put(FORMAL / '検査' / target, source.read_bytes())
    put(FORMAL / '根拠/転送形式の補修.md', (RUN / '転送形式の補修.md').read_bytes())
    for source in ('124からの由来.json', '準備の確認.json'):
        put(FORMAL / '根拠/正逆器の準備' / source, (ROOT / 'work/133固定取得の正逆評価器' / source).read_bytes())
    frozen = {}
    for stage, values in [('F0', f0), ('F1', f1)]:
        for name, expected in values['ファイル'].items():
            if Path(name).suffix in ('.go', '.mod', '.py', '.md'):
                body = Path(name).read_bytes(); assert sha(body) == expected, name
                relative = Path(name).relative_to(ROOT).as_posix()
                assert relative not in frozen or frozen[relative]['sha256'] == expected
                frozen.setdefault(relative, {'bytes': body, 'sha256': expected, '段階': []})['段階'].append(stage)
    archive = FORMAL / '再現資料/133固定コード.zip'
    archive.parent.mkdir(exist_ok=True)
    index = []
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, item in sorted(frozen.items()):
            z.writestr(name, item['bytes'])
            index.append({'path': name, 'bytes': len(item['bytes']), 'sha256': item['sha256'], '段階': item['段階']})
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for item in index:
            assert sha(z.read(item['path'])) == item['sha256']
    external = [{'path': Path(name).relative_to(ROOT).as_posix(), 'sha256': expected,
                 'bytes': Path(name).stat().st_size,
                 '理由': '177MB共用生成入力は122手順を参照し再複製しない' if Path(name).suffix == '.json' else 'Go実行体は源と版から再ビルド、元のexeSHAは監査記録に保持'}
                for name, expected in f1['ファイル'].items()
                if Path(name).suffix == '.exe' or name.endswith('122全場入力\\入力.json')]
    assert len(external) == 3
    value = {'試行': 133, '新共用入力': inputs, '新正逆観測': financial,
             '集計SHA256': sha(aggregate), '共有参照': references, '小型段階証跡': small,
             '固定コード': {'ZIP': archive.name, 'ZIP_SHA256': sha(archive.read_bytes()),
                            'ZIP_bytes': archive.stat().st_size, '格納源数': len(index), '格納源': index},
             '意図して複製しない固定源': external, 'Raw複製': False, '177MB本文読取': False,
             'Source再走査': False, '金融再計算': False, '転送v1原文': 'work/133Source取得を固定入力へ渡す.py',
             '金融前採用転送v2': 'work/133Source取得を固定入力へ渡す_版2.py'}
    put(FORMAL / '保管索引.json', (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    put(INPUTS / '指紋.json', (json.dumps({'試行': 133, '共用入力': inputs}, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    print(json.dumps({'成功': True, '固定コード源': len(index), 'ZIP_SHA256': value['固定コード']['ZIP_SHA256'],
                      '新共用gzip': len(inputs), '共用gzip合計bytes': sum(x['保存bytes'] for x in inputs),
                      '正逆観測gzipbytes': financial['保存bytes'], 'Raw/177MB複製': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
