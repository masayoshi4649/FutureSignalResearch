"""133の独立検算・CSV・準備補足と結果後の再現コードを、F0/F1源と分けて保存する。"""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
FORMAL = ROOT / 'study/00133_全場参加を維持して強い入口の探索期限を延ばす'
OUTPUT = ROOT / 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/133期限別CSV'


def sha(body: bytes) -> str:
    """
    機能: 保存内容の指紋を返す。
    引数: body(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


# ----------------------------------------
def copy(source: Path, destination: Path) -> None:
    """
    機能: 停止済み証跡を未作成の正式先へ同体保存する。
    引数: source/destination(Path)。
    返り値: None。
    """
    assert not destination.exists()
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open('xb') as handle:
        handle.write(source.read_bytes())


# ----------------------------------------
def main() -> None:
    """
    機能: 結果後の検算と閲覧/再現補助を原固定コードと別のZIPへ保管する。
    引数: なし。
    返り値: None。新しい金融条件・Raw走査・CSV生成を行わない。
    """
    independent = ROOT / 'work/133独立検算'
    assert sha((independent / '独立確認.json').read_bytes()) == '103f5338124f8465c1d7b3f7ce093c8933d5e02fc807c7237eded6b9c07eac04'
    for source, target in [
        (independent / '独立確認.json', FORMAL / '検査/独立確認.json'),
        (independent / '完了.json', FORMAL / '検査/独立検算の完了.json'),
        (ROOT / 'work/133期限別CSV出力/独立再読.json', FORMAL / '検査/CSV独立再読.json'),
        (OUTPUT / 'CSVの確認.json', FORMAL / '検査/CSVの確認.json'),
    ]:
        copy(source, target)
    text = (independent / 'README.md').read_text('utf-8')
    text += '\n検算コードと人工コードは[後発コードZIP](../再現資料/検算と保管の追補コード.zip)へ同体保管した。検算JSONは停止済み正本を転記し、132以前の成果物は変更していない。\n'
    (FORMAL / '検査/独立検算.md').write_text(text, encoding='utf-8')
    extras = [
        (ROOT / 'work/133固定取得kernelの独立準備レビュー', FORMAL / '検査/金融前準備/kernel'),
        (ROOT / 'work/133期限別の集計準備補足', FORMAL / '検査/金融前準備/集計接続'),
    ]
    extra_code = []
    for source, destination in extras:
        for p in source.iterdir():
            if not p.is_file():
                continue
            if p.suffix in ('.py', '.go') or p.name == 'overlay.json':
                extra_code.append(p)
            if p.suffix == '.json' and p.name != 'overlay.json':
                copy(p, destination / p.name)
            if p.name == 'README.md':
                text = p.read_text('utf-8')
                for name in ('確認する.py', '追加人工_test.go', 'overlay.json'):
                    text = text.replace('](' + name + ')', '](../../../再現資料/検算と保管の追補コード.zip)')
                destination.mkdir(parents=True, exist_ok=True)
                (destination / p.name).write_text(text, encoding='utf-8')
    files = [independent / '検算する.py', independent / '人工検査.py',
             ROOT / 'work/133期限別CSV出力/出力する.mjs', ROOT / 'work/133期限別CSV出力/CSVを独立再読する.py',
             FORMAL / '再現資料/保存資料を復元する.py', FORMAL / '再現資料/保管を確認する.py']
    files += sorted((ROOT / 'work/133正式保存').glob('*.py')) + extra_code
    unique = sorted(set(files))
    archive = FORMAL / '再現資料/検算と保管の追補コード.zip'
    index = []
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in unique:
            name = p.relative_to(ROOT).as_posix(); body = p.read_bytes()
            z.writestr(name, body)
            index.append({'path': name, 'bytes': len(body), 'sha256': sha(body),
                          '区分': '結果後に保管した検算/閲覧/再現資源。F0/F1源とは別'})
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for item in index:
            assert sha(z.read(item['path'])) == item['sha256']
    manifest_path = FORMAL / '保管索引.json'
    manifest = json.loads(manifest_path.read_bytes())
    manifest['後発コード'] = {'ZIP': archive.name, 'ZIP_SHA256': sha(archive.read_bytes()),
                              'ZIP_bytes': archive.stat().st_size, '格納源数': len(index), '格納源': index}
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '後発コード源': len(index), 'ZIP_SHA256': manifest['後発コード']['ZIP_SHA256'],
                      '独立全条件': 300, '独立表セル': 22123}, ensure_ascii=False))


if __name__ == '__main__':
    main()
