package holdingohlc113

import (
	"fmt"
	"strings"
	"testing"
)

// metadataReview133 は、未作成の人工pathだけを持つ73場metadataを作ります。
//
// 引数: なし。返り値: Input133は原板を開かず検査できる人工入力です。
func metadataReview133() Input133 {
	in := Input133{ExpectedEntryCount: 1}
	for i := 0; i < 73; i++ {
		start := 100.0 + float64(i)*20000
		s := Scene133{Session: fmt.Sprintf("人工%03d", i), Contract: "人工限月", Start: start,
			End: start + 10000, ForceClose: start + 9400,
			Raw:              FileRef{Path: "存在しない人工原板", SHA256: strings.Repeat("a", 64)},
			ExpectedAccepted: 5, ExpectedQuality: &Counts{Lines: 5, Accepted: 5, Delivered: 5}}
		if i == 0 {
			q := Quote{Clock: "人工", Time: start + 100, Index: 0, SourceLine: 1, Last: 105, Bid: 100, Ask: 110, QuoteOK: true}
			s.Entries = []FixedEntry133{{ID: "L0/人工", Side: 1, Entry: q}}
		}
		in.Scenes = append(in.Scenes, s)
	}
	return in
}

// TestReview133VariableCountAndEmptyScenes は、0取得場を消さず宣言総数だけを検査します。
//
// 引数: t(*testing.T)。返り値: なし。人工pathの本文は開きません。
func TestReview133VariableCountAndEmptyScenes(t *testing.T) {
	in := metadataReview133()
	if err := validateInput133(in, 1); err != nil {
		t.Fatal(err)
	}
	x := in.Scenes[0].Entries[0]
	x.ID = "L1/人工"
	in.Scenes[0].Entries = append(in.Scenes[0].Entries, x)
	in.ExpectedEntryCount = 2
	if err := validateInput133(in, 8); err != nil {
		t.Fatalf("同原行の別cohortを拒否: %v", err)
	}
	in.ExpectedEntryCount = 3
	if err := validateInput133(in, 1); err == nil {
		t.Fatal("宣言総数の不一致を受理")
	}
	in = metadataReview133()
	in.Scenes = in.Scenes[:72]
	if err := validateInput133(in, 1); err == nil {
		t.Fatal("0取得場を含めた全73場を検査しない")
	}
}

// TestReview133BothEntryLimits は、Source限界とH60限界の小さい側の等号拒否を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestReview133BothEntryLimits(t *testing.T) {
	for _, sourceFirst := range []bool{true, false} {
		s := metadataReview133().Scenes[0]
		limit := s.End - 3900
		if sourceFirst {
			s.ForceClose = s.Start + 1000
			limit = s.ForceClose
		}
		s.Entries[0].Entry.Time = limit
		if _, err := validateEntries133(s); err == nil {
			t.Fatal("取得限界の等号を受理")
		}
		s.Entries[0].Entry.Time = limit - 1
		if _, err := validateEntries133(s); err != nil {
			t.Fatalf("取得限界の直前を拒否: %v", err)
		}
	}
}

// TestReview133PhasePriorityAndMixedCompletion は、phaseをgapより先に適用し既知情報を保ちます。
//
// 引数: t(*testing.T)。返り値: なし。正常BBOでない境界後の行も人工で確認します。
func TestReview133PhasePriorityAndMixedCompletion(t *testing.T) {
	for _, chart := range []bool{false, true} {
		entry := fixedQuoteTest133(100, 0, 995, 1005, 1000)
		c := fixedCandidate133("人工", 1, entry, chart)
		complete := fixedQuoteTest133(1900, 1, 1020, 1030, 1025)
		c.Outcomes[0].Status = "complete"
		c.Outcomes[0].Endpoint = &complete
		touch := fixedQuoteTest133(1999, 2, 1140, 1150, 1145)
		c.Outcomes[1].Touches[3].Direction = 1
		c.Outcomes[1].Touches[3].Quote = &touch
		after := fixedQuoteTest133(4000, 3, 500, 510, 505)
		after.QuoteOK = false
		if chart {
			chartOutcome133(c, after, 1000, 3400)
		} else {
			outcome133(c, after, 1000, 3400)
		}
		if c.Outcomes[0].Status != "complete" || c.Outcomes[0].Endpoint != &complete {
			t.Fatal("H30完了を変更")
		}
		if c.Outcomes[1].Status != "phase_censored" || c.Outcomes[1].Touches[3].Quote != &touch || c.Outcomes[1].Endpoint != nil {
			t.Fatal("phaseの優先又はH60既知touchの保持に失敗")
		}
		if c.LastNormalTime != entry.Time {
			t.Fatal("境界後の行を正常観測時計へ混入")
		}
	}
}
