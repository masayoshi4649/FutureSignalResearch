"""133固定取得kernelの元算術と人工境界を、自然入力なしで独立に確認する。"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
KERNEL = ROOT / 'work/133固定取得の正逆評価器'
ORIGINAL = ROOT / 'work/124入口の正逆比較'


def sha(path: Path) -> str:
    """
    機能: コード又は人工証跡の指紋を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def function(text: str, name: str) -> str:
    """
    機能: 対象Goファイルのトップレベル関数本文を取り出す。
    引数: text/name(str)。返り値: str。
    """
    found = re.findall(r'(?ms)^func ' + re.escape(name) + r'\(.*?^\}', text)
    assert len(found) == 1, name
    return found[0]


# ----------------------------------------
def execute(command: list[str]) -> dict:
    """
    機能: 自然入力を指定しない人工Go検査だけを実行する。
    引数: command(list[str])。返り値: dictは終了と出力。
    """
    result = subprocess.run(command, cwd=KERNEL, capture_output=True, encoding='utf-8', text=True)
    assert result.returncode == 0, (command, result.stdout, result.stderr)
    return {'command': command, 'returncode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}


# ----------------------------------------
def main() -> None:
    """
    機能: 元算術/原板走査/可変総数/phase境界の確認を新規保存する。
    引数: なし。返り値: None。自然Raw・前段cohort・金融結果を開かない。
    """
    proof = KERNEL / '準備の確認.json'
    assert sha(proof) == '34ff92b612108c498344a46cd45ca9a2691d4c2c88c31befd1b3057be9ea7d48'
    root_ready = json.loads(proof.read_text('utf-8'))
    files = sorted(list(KERNEL.rglob('*.go')) + [KERNEL / 'go.mod', KERNEL / 'README.md',
                   KERNEL / '準備を確認する.py', proof, KERNEL / '固定取得の正逆評価.exe'])
    before = {str(p.relative_to(ROOT)): sha(p) for p in files}
    assert sha(KERNEL / '固定取得の正逆評価.exe') == root_ready['実行物SHA256']
    for relative, expected in root_ready['コード仕様の前後指紋'].items():
        assert sha(KERNEL / relative) == expected
    same = {}; original_fingerprints = {}
    for name in ('reader.go', 'types.go', 'stream.go', 'outcome.go', 'chart_outcome.go'):
        old = (ORIGINAL / name).read_text('utf-8')
        new = (KERNEL / name).read_text('utf-8')
        normalized = new.replace('133', '124') if name not in ('reader.go', 'types.go') else new
        if name in ('outcome.go', 'chart_outcome.go'):
            normalized = normalized.replace('\tif phaseCut124(c, q, force) {\n\t\treturn\n\t}\n', '')
        assert normalized == old, name
        same[name] = {'名前とphase guard以外のテキスト一致': True,
                      '元bytesSHA256': sha(ORIGINAL / name), '新bytesSHA256': sha(KERNEL / name),
                      '注記': '比較時はUTF8改行を正規化。reader/typesは改行以外の本文が全文一致'}
        original_fingerprints[name] = sha(ORIGINAL / name)
    old_entry = (ORIGINAL / 'entry.go').read_text('utf-8')
    new_entry = (KERNEL / 'entry.go').read_text('utf-8').replace('133', '124')
    unchanged = ('fixedCandidate124', 'fixedCase124', 'candidates124', 'stepCase124', 'finalize124', 'validSHA124')
    for name in unchanged: assert function(old_entry, name) == function(new_entry, name)
    assert 'q.Time >= math.Min(s.ForceClose, s.End-300-3600)' in new_entry
    assert 'in.ExpectedEntryCount <= 0 || entries != in.ExpectedEntryCount' in new_entry
    assert 'if stepCase124(c, *q, oldTime, s.End-300)' in new_entry
    for token in ('for scan.Scan()', 'io.Copy(io.Discard, tee)', 'out.Raw.SHA256 != out.ActualSHA',
                  'out.Before != out.After', 'index != s.ExpectedAccepted', 'out.Quality != *s.ExpectedQuality'):
        assert token in function(new_entry, 'scan124'), token
    phase = (KERNEL / 'phase.go').read_text('utf-8')
    assert 'q.Time < executionEnd' in phase and 'Status == "pending"' in phase
    overlay = OWN / 'overlay.json'; overlay_map = json.loads(overlay.read_text('utf-8'))
    target = KERNEL / '独立追加人工_test.go'
    assert not target.exists() and overlay_map == {'Replace': {str(target): str(OWN / '追加人工_test.go')}}
    tests = execute(['go', 'test', '-count=1', '-json', '-overlay=' + str(overlay), './...'])
    records = [json.loads(line) for line in tests['stdout'].splitlines() if line.startswith('{')]
    names = [r['Test'] for r in records if r.get('Action') == 'pass' and 'Test' in r]
    assert len(names) == len(set(names)) == 11
    assert set(root_ready['人工成功']) <= set(names)
    assert {n for n in names if n.startswith('TestReview133')} == {
        'TestReview133VariableCountAndEmptyScenes', 'TestReview133BothEntryLimits', 'TestReview133PhasePriorityAndMixedCompletion'}
    vet = execute(['go', 'vet', '-overlay=' + str(overlay), './...'])
    after = {str(p.relative_to(ROOT)): sha(p) for p in files}
    assert before == after and not target.exists()
    assert all(sha(ORIGINAL / name) == h for name, h in original_fingerprints.items())
    result = {'成功': True, '試行': 133, '段階': '固定取得kernelの自然入力前の独立準備レビュー',
              'UTC': datetime.now(timezone.utc).isoformat(), 'Root準備SHA256': sha(proof),
              '同体照合': same, '名前以外不変の関数': list(unchanged), '人工成功': names, '人工': tests, 'vet': vet,
              '全コード仕様実行物の前後SHA256': before, '前後不変': True,
              '追加人工': {'方式': 'Go overlay。元kernelに物理ファイルを追加しない', '件数': 3,
                           'SHA256': sha(OWN / '追加人工_test.go')},
              '確認範囲': ['期待取得総数を1/2に変更して正しく受理し不一致拒否、0取得場を含む全73場保持',
                           'Source force_closeとEnd−3900の小さい側の等号拒否、直前受理',
                           'BBO/Last両方でphaseを価格/gapより先に適用、H30完了とH60既知touchを保持',
                           '元の価格/費用/欠測算術、SHA/stat/全Raw行品質の走査とCLI引数をコード確認'],
              'build確認': 'Root保存exeのSHAとRoot成功証跡へ一致。独立Go testはcmd/runもコンパイル。重複exeを生成しない',
              '自然Raw読取': False, 'Stage1結果又は自然金融結果読取': False, 'Rootコード変更': False,
              '限界': 'L0/L1の自然cohort・全73場取得の成立・実ラベル/損益・真の受信時計/実IFDは未検証',
              '重大な未解決': [], '検査コードSHA256': sha(Path(__file__))}
    with (OWN / '準備の独立確認.json').open('x', encoding='utf-8', newline='\n') as handle:
        json.dump(result, handle, ensure_ascii=False, indent=2, allow_nan=False); handle.write('\n')
    print(json.dumps({'成功': True, '人工': len(names), '確認SHA256': sha(OWN / '準備の独立確認.json')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
