"""133の非金融コホートと保存正逆Quoteを独立式で検算する。Root/124算術はimportしない。"""
import copy
import datetime
import hashlib
import json
import math
from collections import Counter
from fractions import Fraction
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
POLICIES=('O0','L0','O1','L1','R1')
DISPLAY=('L1','R1','O1','L0','O0')
MODEL={'O0':'L0','L0':'L0','O1':'L1','L1':'L1','R1':'L1'}
WIDTHS=(25,50,100,125,200)
HORIZONS=(1800,3600)
AXES=('BBO','Last')


def sha(path: Path) -> str:
    """
    機能: ファイルのSHA256を求める。
    引数: path(Path)は対象。
    返り値: strは小文字16進SHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def equal(actual: object, expected: object, location: str='') -> int:
    """
    機能: 型・未知・有限数値を区別して再帰照合する。
    引数: actual/expected(object)、location(str)は実値・期待値・位置。
    返り値: intは一致した末端値の数。不一致はAssertionError。
    """
    if isinstance(expected,dict):
        assert isinstance(actual,dict) and actual.keys()==expected.keys(),(location,'keys')
        return sum(equal(actual[k],v,location+'/'+str(k)) for k,v in expected.items())
    if isinstance(expected,list):
        assert isinstance(actual,list) and len(actual)==len(expected),(location,'length')
        return sum(equal(a,b,location+'/'+str(i)) for i,(a,b) in enumerate(zip(actual,expected)))
    if expected is None or type(expected) is bool:
        assert type(actual) is type(expected) and actual==expected,(location,actual,expected)
    elif type(expected) in (int,float):
        assert type(actual) in (int,float) and math.isfinite(actual) and math.isclose(actual,expected,rel_tol=1e-12,abs_tol=1e-8),(location,actual,expected)
    else:assert actual==expected,(location,actual,expected)
    return 1


def number(fields: dict, key: str) -> float | None:
    """
    機能: 既知の有限値だけを取り出し、未知はNoneにする。
    引数: fields(dict)、key(str)は保存票と項目。
    返り値: float|Noneは既知値又は未知。
    """
    f=fields[key];assert type(f['known']) is bool
    if not f['known']:return None
    value=f['value'];assert type(value) in (int,float) and math.isfinite(value)
    return value


def direction(meta: dict) -> None:
    """
    機能: 当時の原値から固定B0/T8とE0保護を再計算する。
    引数: meta(dict)は金融結果を含まない出生票。
    返り値: None。不一致はAssertionError。
    """
    d=meta['direction'];f=d['fields'];side=meta['source_side']
    o,h,l,c=(number(f,k) for k in ('open5','high5','low5','close5'))
    assert side in (-1,1) and None not in (o,h,l,c) and 0<l<=min(o,c)<=max(o,c)<=h
    body=side*(c-o)/(h-l) if h>l else None
    equal(number(f,'body5_signed_ratio_to_source'),body,'body')
    b0=-side if body is not None and Fraction(1,2)<=body<Fraction(3,4) else side
    raw_long=number(f,'ema21_delta30_raw');raw_hist=number(f,'hist5_raw');atr=number(f,'atr5')
    long=None if raw_long is None else b0*raw_long
    hist=b0*raw_hist/atr if raw_hist is not None and atr is not None and atr>0 else None
    equal(number(f,'ema21_delta30_to_B0'),long,'long');equal(number(f,'hist5_atr_to_B0'),hist,'hist')
    t8=-b0 if long is not None and hist is not None and long>=0 and hist>=.1 else b0
    chosen=side if meta['path']=='E0' else t8
    assert (d['source_side'],d['b0_side'],d['t8_side'],d['selected_side'],d['e0_protected'])==(side,b0,t8,chosen,meta['path']=='E0')
    assert meta['selected_side']==chosen
    for ref in d['refs']:
        q=ref['delivered'];b=meta['birth']
        assert q['time']<=b['time'] and q['index']<=b['index'] and q['source_line']<=b['source_line']
        assert b['time']<ref['end']+ref['width_seconds']+60


def strong(candidate: dict) -> None:
    """
    機能: L1通常入口の保存当時成分が旧123の強条件を満たすか照合する。
    引数: candidate(dict)はSource出生/取得候補。
    返り値: None。新しい閾値や金融ラベルを使わない。
    """
    d=candidate['decision'];f=d['components'];side=candidate['birth']['side'];get=lambda k:number(f,k)
    assert d['eligible'] and d['side']==side
    assert get('RVOL5') is not None and get('RVOL5')>=1
    assert get('TR5') is not None and get('previous_ATR5') is not None and get('TR5')<=2*get('previous_ATR5')
    if d['strategy']=='trend':
        assert all(get(k) is not None and side*get(k)>0 for k in ('5_gap','5_ema8_delta','5_ema21_delta','5_di_delta'))
        assert all(get(k) is None or side*get(k)>=0 for k in ('15_T','30_T'))
        assert get('RSI5') is not None and 0<=side*(get('RSI5')-50)<=20
        assert all(get(k) is not None and side*get(k)>0 for k in ('Hist5','M','P'))
        assert d['score']['known'] and abs(d['score']['value'])>=.5
    else:
        assert d['strategy']=='reversal'
        assert all(get(k) is not None for k in ('prior3_low','prior3_high','previous_RSI5','RSI_delta','Hist_delta','ADX5','previous_ADX5'))
        assert get('ADX5')<get('previous_ADX5') and side*(get('previous_RSI5')-50)<=-15
        assert side*get('RSI_delta')>0 and side*get('Hist_delta')>0
        extreme=get('L5') if side>0 else get('H5');boundary=get('prior3_low') if side>0 else get('prior3_high')
        assert side*(extreme-boundary)<0 and side*(get('C5')-boundary)>=5
        assert get('prior3_low')<=get('C5')<=get('prior3_high') and side*(get('Last')-boundary)>=5


def nonfinancial(source: dict, fixed: dict, metadata: dict) -> dict:
    """
    機能: 全73場のSource取得、要求時計、当時型、方向票と転送を独立確認する。
    引数: source/fixed/metadata(dict)はStage1結果・固定入力・金融前出生票。
    返り値: dictは型/参加/方向の確認。金融ファイルを必要としない。
    """
    assert source['success'] and source['trial']==133 and source['outcomes_computed'] is False
    assert len(source['scenes'])==len(fixed['scenes'])==len(metadata['sessions'])==73
    mmap={(m['session'],m['id']):m for m in metadata['entries']};assert len(mmap)==158
    assert fixed['expected_entry_count']==158
    types={p:Counter() for p in ('L0','L1')};coverage={};seen=set();strong_count=0
    for s,f in zip(source['scenes'],fixed['scenes']):
        sid=s['session'];assert sid==f['session'] and s['success']
        assert s['execution_end']==f['end']-300 and s['entry_cutoff']==min(f['force_close'],f['end']-3900)
        assert s['fallback_at']=={'L0':f['start']+10800,'L1':f['end']-4020}
        assert s['quality']==s['expected_quality']==f['expected_quality']
        inputs={e['id']:e for e in f['entries']}
        counts=Counter()
        for c in s['candidates']:
            if c['policy'] not in ('L0','L1') or c['status']!='filled':continue
            p=c['policy'];identity=p+'/'+c['birth']['id'];key=(sid,identity)
            assert key in mmap and key not in seen;seen.add(key);m=mmap[key]
            assert inputs[identity]=={'id':identity,'side':c['birth']['side'],'entry':c['entry']}
            for a,b in (('source_id',c['birth']['id']),('birth',c['birth']),('entry',c['entry']),('direction',c['direction'])):equal(m[a],b)
            assert m['source_side']==c['birth']['side'] and m['model']==p
            q=c['entry'];r=c['request']
            assert q['time']<s['entry_cutoff'] and q['time']<c['expires'] and q['time']>=r['time']+1
            assert q['index']>r['index'] and q['source_line']>r['source_line'] and q['quote_ok'] and 0<q['bid']<q['ask']
            assert c['entry_price']==(q['ask'] if c['birth']['side']>0 else q['bid'])
            direction(m)
            if c['path']=='E0':
                event=s['events'][c['event']]
                assert event['id']==c['birth']['id'] and event['side']==c['birth']['side'] and m['strategy']=='E0'
                assert c['direction']['e0_protected'] and c['direction']['selected_side']==c['birth']['side']
                risk=c['birth']['side']*(c['entry_price']-c['invalidation'])
                assert 0<risk<=min(100,.5*c['atr5']) and c['birth']['side']*(c['entry_price']-c['entry_cap'])<=0
                hold=c['birth']['side']*(q['last']-c['hold_boundary'])
                assert hold>0 if c['hold_strict'] else hold>=c['hold_minimum']
            elif c['path']=='strong':
                assert c['birth']['time']<s['fallback_at'][p]
                strong(c);strong_count+=1
                assert m['strategy']==c['decision']['strategy']
            else:
                assert c['path']=='deadline' and c['birth']['time']>=s['fallback_at'][p] and m['strategy']=='deadline'
            types[p][m['strategy']]+=1;counts[p]+=1
        coverage[sid]={p:counts[p]>0 for p in ('L0','L1')}
        assert coverage[sid]==metadata['coverage'][sid]==s['coverage']
        assert len(inputs)==sum(counts.values())
    assert seen==set(mmap)
    assert all(all(c.values()) for c in coverage.values())
    return {'success':True,'rows':158,'scenes':73,'types':{k:dict(v) for k,v in types.items()},
            'strong_conditions_verified':strong_count,'all_models_79_entries_73_sessions':True,
            'all_entries_before_H60_limit':True,'all_saved_directions_verified':158,
            'Source_geometry_is_not_selected_direction_order_eligibility':True}


# ----------------------------------------
def observation(candidate: dict, horizon: int) -> dict:
    """
    機能: 指定期限の観測を一意に取り出す。
    引数: candidate(dict)、horizon(int)は候補と秒数。
    返り値: dictは観測。
    """
    matches=[o for o in candidate['outcomes'] if o['seconds']==horizon];assert len(matches)==1
    return matches[0]


def touch(outcome: dict, width: int) -> dict:
    """
    機能: 同幅の保存先着を一意に取り出す。
    引数: outcome(dict)、width(int)は観測とpt。
    返り値: dictは先着票。
    """
    matches=[t for t in outcome['touches'] if t['width']==width];assert len(matches)==1
    return matches[0]


def side_for(record: dict, policy: str) -> int:
    """
    機能: 固定した5政策の向きを保存票から選ぶ。
    引数: record(dict)、policy(str)は結合票と政策。
    返り値: intは±1。勝敗を使わない。
    """
    m=record['meta']
    return m['source_side'] if policy in ('O0','O1') else -m['selected_side'] if policy=='R1' else m['selected_side']


def choose(record: dict, policy: str, axis: str) -> dict:
    """
    機能: 同じ取得Quoteの実正逆又はLast参考候補を選ぶ。
    引数: record(dict)、policy/axis(str)は結合票・政策・価格軸。
    返り値: dictは保存候補。
    """
    assert record['meta']['model']==MODEL[policy]
    name='original' if side_for(record,policy)==record['case']['original_side'] else 'reverse'
    return record['case'][('chart_' if axis=='Last' else '')+name]


def points(candidate: dict, quote: dict, axis: str) -> int | float:
    """
    機能: 保存清算Quoteから実側の符号付き値幅を計算する。
    引数: candidate/quote(dict)、axis(str)は取得・清算・軸。
    返り値: int|floatはpt。
    """
    side=candidate['birth']['side'];mark=quote['last'] if axis=='Last' else quote['bid'] if side>0 else quote['ask']
    return side*(mark-candidate['entry_price'])


def ifd(candidate: dict, horizon: int, width: int, axis: str) -> dict:
    """
    機能: 既知touch優先でIFD代用を算出し、H不足の未到達は未知にする。
    引数: candidate(dict)、horizon/width(int)、axis(str)は方向と観測条件。
    返り値: dictは既知/理由/pt/C0/C5。Lastの金額はNone。
    """
    o=observation(candidate,horizon);t=touch(o,width)
    if t['direction']:
        quote=t['quote'];reason='順行到達' if t['direction']>0 else '逆行到達'
    elif o['status']=='complete':quote=o['endpoint'];reason='期限清算'
    else:return {'known':False,'reason':'観測不足','points':None,'net0':None,'net5':None}
    assert quote is not None
    p=points(candidate,quote,axis)
    return {'known':True,'reason':reason,'points':p,
            'net0':p*100-77 if axis=='BBO' else None,'net5':p*100-1077 if axis=='BBO' else None}


def stats(records: list[dict], policy: str, axis: str, horizon: int, width: int) -> dict:
    """
    機能: 保存QuoteとFractionから全率/分母/利益/損失/PFを独立集計する。
    引数: records(list[dict])、policy/axis(str)、horizon/width(int)は取得集合と条件。
    返り値: dictは主算術集計。Root集計/124算術を呼ばない。
    """
    selected=[choose(r,policy,axis) for r in records]
    complete=[observation(c,horizon) for c in selected if observation(c,horizon)['status']=='complete']
    counts=Counter(touch(o,width)['direction'] for o in complete);forward=counts[1];adverse=counts[-1];resolved=forward+adverse
    exits=[ifd(c,horizon,width,axis) for c in selected];known=[e for e in exits if e['known']]
    money=[e['net5'] for e in known] if axis=='BBO' else []
    profit=sum(x for x in money if x>0);loss=-sum(x for x in money if x<0)
    return {'entries':len(records),'sessions':len({r['session'] for r in records}),
            'complete':len(complete),'censored':len(selected)-len(complete),
            'forward':forward,'adverse':adverse,'neither':counts[0],'resolved':resolved,
            'resolved_rate':float(Fraction(forward,resolved)) if resolved else None,
            'complete_rate':float(Fraction(forward,len(complete))) if complete else None,
            'target70':Fraction(forward,resolved)>=Fraction(7,10) if resolved else None,
            'target70_all':Fraction(forward,len(complete))>=Fraction(7,10) if complete else None,
            'ifd_known':len(known),'ifd_unknown':len(exits)-len(known),
            'ifd_exits':dict(Counter(e['reason'] for e in exits)),
            'ifd_net0_sum':sum(e['net0'] for e in known) if axis=='BBO' and known else None,
            'ifd_net5_sum':sum(money) if money else None,
            'ifd_net5_mean':float(Fraction(sum(money))/len(money)) if money else None,
            'ifd_net5_profit':profit if money else None,'ifd_net5_loss':loss if money else None,
            'ifd_net5_pf':float(Fraction(profit)/Fraction(loss)) if loss else None,
            'ifd_net5_positive':sum(x>0 for x in money) if axis=='BBO' else None,
            'ifd_points_mean':float(Fraction(sum(e['points'] for e in known))/len(known)) if known else None,
            'flips':sum(c['birth']['side']!=r['case']['original_side'] for c,r in zip(selected,records))}


def subset(records: list[dict], policy: str, sessions: list[str]) -> list[dict]:
    """
    機能: 政策が属する取得集合と場だけを選ぶ。
    引数: records(list[dict])、policy(str)、sessions(list[str])は全票・政策・場順。
    返り値: list[dict]は母集団を混ぜない部分集合。
    """
    return [r for r in records if r['meta']['model']==MODEL[policy] and r['session'] in sessions]


def join(result: dict, fixed: dict, metadata: dict) -> tuple[list[dict],list[str],dict]:
    """
    機能: 全4価格streamを固定取得に結合し、phase/清算価格を独立点検する。
    引数: result/fixed/metadata(dict)は観測・固定取得・出生票。
    返り値: tuple[list[dict],list[str],dict]は全票・73場順・検査件数。
    """
    mmap={(m['session'],m['id']):m for m in metadata['entries']};seen=set();records=[];counts=Counter()
    assert result['success'] and result['trial']==133 and result['source_entry_count']==158
    sessions=[]
    for s,f in zip(result['scenes'],fixed['scenes']):
        sid=s['session'];sessions.append(sid);assert sid==f['session'] and s['success']
        boundary=f['end']-300;limit=min(f['force_close'],boundary-3600)
        assert s['execution_end']==boundary and s['effective_entry_limit']==limit and s['source_force_close']==f['force_close']
        assert s['quality']==s['expected_quality']==f['expected_quality'] and s['actual_sha256']==f['raw']['sha256']
        inputs={e['id']:e for e in f['entries']};assert len(inputs)==len(s['cases'])
        for c in s['cases']:
            key=(sid,c['id']);assert key in mmap and key not in seen;seen.add(key);m=mmap[key];entry=inputs[c['id']]['entry']
            assert c['original_side']==inputs[c['id']]['side']==m['source_side'] and entry==m['entry'] and entry['time']<limit
            for name in ('original','reverse','chart_original','chart_reverse'):
                stream=c[name];axis='Last' if name.startswith('chart') else 'BBO'
                side=c['original_side']*(1 if name.endswith('original') else -1)
                assert stream['status']=='filled' and stream['birth']['side']==side and stream['entry']==entry
                assert stream['entry_price']==(entry['last'] if axis=='Last' else entry['ask'] if side>0 else entry['bid'])
                counts['stream検査']+=1;counts['entry検査']+=1
                assert tuple(o['seconds'] for o in stream['outcomes'])==HORIZONS
                for o in stream['outcomes']:
                    assert o['deadline']==entry['time']+o['seconds'] and tuple(t['width'] for t in o['touches'])==WIDTHS
                    assert (o['endpoint'] is not None)==(o['status']=='complete')
                    q=o['endpoint']
                    if q is not None:
                        assert o['deadline']<=q['time']<=o['deadline']+30 and q['time']<boundary
                        assert q['index']>entry['index'] and q['source_line']>entry['source_line'] and q['quote_ok'] and 0<q['bid']<q['ask']
                        p=points(stream,q,axis);equal(o['points'],p,'endpoint points')
                        equal(o['net0'],p*100-77 if axis=='BBO' else None,'endpoint C0')
                        equal(o['net5'],p*100-1077 if axis=='BBO' else None,'endpoint C5')
                        counts['endpoint検査']+=1
                    else:assert o['points'] is None and o['net0'] is None and o['net5'] is None
                    for t in o['touches']:
                        assert type(t['direction']) is int and t['direction'] in (-1,0,1)
                        q=t['quote'];assert (q is None)==(t['direction']==0)
                        if q is None:continue
                        assert entry['time']<=q['time']<=o['deadline'] and q['time']<boundary
                        assert q['index']>entry['index'] and q['source_line']>entry['source_line'] and q['quote_ok'] and 0<q['bid']<q['ask']
                        p=points(stream,q,axis)
                        assert p>=t['width'] if t['direction']>0 else p<=-t['width']
                        counts['touch検査']+=1
            records.append({'session':sid,'case':c,'meta':m})
    assert len(sessions)==len(set(sessions))==73 and seen==set(mmap) and len(records)==158
    return records,sessions,dict(counts)


def jst(at: float) -> str:
    """
    機能: Unix秒を閲覧表の日本時間書式へ変換する。
    引数: at(float)は時刻。
    返り値: strは秒精度のJST。
    """
    return datetime.datetime.fromtimestamp(at,datetime.timezone(datetime.timedelta(hours=9))).isoformat(sep=' ')


def tables_check(tables: list[dict], records: list[dict], sessions: list[str], values: dict, participation: dict) -> dict:
    """
    機能: 独立集計と当時metadataからCSV用3表の全セルを照合する。
    引数: tables/records/sessions(list)、values/participation(dict)は表と独立期待値。
    返り値: dictは行列数と照合セル数。実CSVの再読・描画は別担当の検査である。
    """
    assert [(t['name'],len(t['rows']),len(t['headers'])) for t in tables]==[('正逆比較',300,29),('入口別診断',158,54),('全セッション',73,67)]
    parts={'all':sessions,'train':sessions[:48],'validation':sessions[48:]};cells=0
    t=tables[0];seen=set()
    for row in t['rows']:
        actual=dict(zip(t['headers'],row));part=actual['区分'];policy=actual['政策'];axis=actual['価格軸']
        h=int(actual['評価分']*60);w=actual['同幅pt'];key=(part,policy,axis,h,w)
        assert key not in seen;seen.add(key);s=values[part][policy][axis][str(h)][str(w)];p=participation[part][MODEL[policy]]
        expected={'試行':133,'区分':part,'政策':policy,'取得集合':MODEL[policy],'価格軸':axis,'評価分':h/60,'同幅pt':w,
                  '対象場数':len(parts[part]),'取得場数':s['sessions'],'取得数':s['entries'],'Source向きからの反転数':s['flips'],
                  '全場最低1取得':p['全場最低1取得'],'全H完了':s['complete'],'観測不足':s['censored'],
                  '順行先着':s['forward'],'逆行先着':s['adverse'],'両方未到達':s['neither'],
                  '到達済み順行率':s['resolved_rate'],'未到達込順行率':s['complete_rate'],'到達済み70%達成':s['target70'],
                  '参加と70%両達成':bool(p['全場最低1取得'] and s['target70'] is True),
                  'IFD代用既知':s['ifd_known'],'IFD代用未知':s['ifd_unknown'],'C0代用差引円':s['ifd_net0_sum'],
                  'C5代用利益円':s['ifd_net5_profit'],'C5代用損失絶対円':s['ifd_net5_loss'],
                  'C5代用差引円':s['ifd_net5_sum'],'C5代用平均円':s['ifd_net5_mean'],'C5代用PF':s['ifd_net5_pf']}
        cells+=equal(actual,expected,'比較表/'+str(key))
    assert len(seen)==300
    t=tables[1];assert [r[t['headers'].index('出生ID')] for r in t['rows']]==[r['case']['id'] for r in records]
    for row,r in zip(t['rows'],records):
        m=r['meta'];d=m['direction'];f=d['fields'];c=r['case']
        expected={'試行':133,'参考区分':'train' if r['session'] in sessions[:48] else 'validation','セッション':r['session'],
                  '取得集合':m['model'],'出生ID':c['id'],'Source出生ID':m['source_id'],'入口経路':m['path'],
                  'Source向き':c['original_side'],'B0向き':d['b0_side'],'T8向き':d['t8_side'],
                  '選択向き':m['selected_side'],'E0保護':d['e0_protected'],'出生JST':jst(m['birth']['time']),
                  '取得JST':jst(m['entry']['time']),'元取得価格':c['original']['entry_price'],'逆取得価格':c['reverse']['entry_price']}
        for key,value,known in (('body5_signed_ratio_to_source','5分実体比_Source','実体既知'),
                                ('ema21_delta30_to_B0','30分EMA21増分_B0','長期既知'),
                                ('hist5_atr_to_B0','5分HistATR_B0','勢い既知'),('atr5','ATR5','ATR既知')):
            x=number(f,key);expected[value]=x;expected[known]=x is not None
        for policy in DISPLAY:
            names=[policy+x for x in ('向き','125全H','125先着','IFD既知','IFD清算','125C5代用円')]
            if MODEL[policy]!=m['model']:expected.update(dict.fromkeys(names,None));continue
            candidate=choose(r,policy,'BBO');o=observation(candidate,3600);e=ifd(candidate,3600,125,'BBO')
            expected.update(zip(names,[candidate['birth']['side'],o['status'],touch(o,125)['direction'],e['known'],e['reason'],e['net5']]))
        cells+=equal(dict(zip(t['headers'],row)),expected,'入口表/'+c['id'])
    t=tables[2];assert [r[t['headers'].index('セッション')] for r in t['rows']]==sessions
    cumulative={p:0 for p in DISPLAY};unknown={p:0 for p in DISPLAY}
    for i,(row,sid) in enumerate(zip(t['rows'],sessions)):
        counts={model:sum(r['session']==sid and r['meta']['model']==model for r in records) for model in ('L0','L1')}
        expected={'試行':133,'セッション':sid,'参考区分':'train' if i<48 else 'validation','L0取得数':counts['L0'],
                  'L1取得数':counts['L1'],'L0最低1取得':counts['L0']>0,'L1最低1取得':counts['L1']>0}
        for policy in DISPLAY:
            s=stats(subset(records,policy,[sid]),policy,'BBO',3600,125)
            cumulative[policy]+=s['ifd_net5_sum'] or 0;unknown[policy]+=s['ifd_unknown']
            expected.update({policy+'反転数':s['flips'],policy+'125順':s['forward'],policy+'125逆':s['adverse'],
                             policy+'125未到達':s['neither'],policy+'全H不足':s['censored'],policy+'IFD既知':s['ifd_known'],
                             policy+'IFD未知':s['ifd_unknown'],policy+'C5利益円':s['ifd_net5_profit'],policy+'C5損失絶対円':s['ifd_net5_loss'],
                             policy+'C5既知差引円':s['ifd_net5_sum'],policy+'C5既知累計円（口座収支ではない）':cumulative[policy],
                             policy+'累計IFD未知':unknown[policy]})
        cells+=equal(dict(zip(t['headers'],row)),expected,'場表/'+sid)
    assert cells==300*29+158*54+73*67
    return {'success':True,'table_dimensions':[[300,29],[158,54],[73,67]],'all_data_cells_equal':cells,
            'actual_csv_reread_or_render':False}


def main() -> None:
    """
    機能: 固定SHAと全独立式を確認し、全300条件・3表・旧140条件の証跡を保存する。
    引数: なし。許可された固定JSONだけを読み、RawやRoot/124算術を実行しない。
    返り値: None。独立確認JSONを新規保存する。
    """
    paths={
        'source':('work/133探索期限の評価/Sourceの出生と取得.json','4c9449b620c15a63c00f9810eeaa52fc8f0eb5f92f7ea2d124cc9db12cc728f6'),
        'fixed':('work/133探索期限の評価/固定入力/固定取得入力.json','5efb1b9ef1f1130d4507f926601f8cabe50757463d7523858351833abc6d0b5e'),
        'metadata':('work/133探索期限の評価/固定入力/方向と出生.json','a328f6b902e9ace8d4d764974570f6beeacda91bd099933d1b716b68875a49d2'),
        'result':('work/133探索期限の評価/固定取得の正逆観測.json','ee0d7d48cb49dec48ebdcd8c16db305d722da988ebbbb4a34036c7fdfc80409a'),
        'aggregate':('work/133期限別の集計/集計.json','21e686aa350f6b093ae83b0503acecc006df38905b74478315967648f2d5858b'),
        'tables':('work/133期限別の集計/CSV用の表.json','eab6af830eb9c68f68dfb4cc594d0c2f8e5f3f057e3997a92a1d056a7f00c59b'),
        'oldpairs':('work/124入口の正逆比較/全73場の正逆結果.json','25517066b291a0434211190299b9f0195e67f9a7d2e89c801d5b9e6b4b51c3a1'),
        'old124':('work/124入口の原因分析/集計.json','1ca939bd2c619f6d2a3926999cb1b8e57726d48f2584b798cc6688e42ece49f8'),
        'old131':('work/131既存入口の位相切替評価/集計.json','252a8d1744fe340b57a23db5c46d7dc7abd467fdfa59d273ce42f497b04843f3')}
    assert all(sha(ROOT/p)==h for p,h in paths.values())
    load=lambda key:json.loads((ROOT/paths[key][0]).read_text(encoding='utf-8-sig'))
    source,fixed,metadata=load('source'),load('fixed'),load('metadata')
    nonfinancial_proof=nonfinancial(source,fixed,metadata)
    result=load('result');aggregate=load('aggregate');table_data=load('tables')
    assert result['input_sha256']==paths['fixed'][1] and metadata['fixed_input_sha256']==paths['fixed'][1]
    assert metadata['source_sha256']==paths['source'][1] and metadata['new_outcomes_read'] is False
    records,sessions,phase=join(result,fixed,metadata)
    parts={'all':sessions,'train':sessions[:48],'validation':sessions[48:]}
    values={};participation={};condition_count=0;scalar_count=0
    for part,ids in parts.items():
        values[part]={};participation[part]={}
        for model in ('L0','L1'):
            rs=[r for r in records if r['meta']['model']==model and r['session'] in ids]
            missing=[sid for sid in ids if not any(r['session']==sid for r in rs)]
            participation[part][model]={'対象場数':len(ids),'取得数':len(rs),'取得場数':len(ids)-len(missing),
                                        '未取得場数':len(missing),'未取得場':missing,'全場最低1取得':not missing}
        for policy in POLICIES:
            rs=subset(records,policy,ids);values[part][policy]={}
            for axis in AXES:
                values[part][policy][axis]={}
                for horizon in HORIZONS:
                    values[part][policy][axis][str(horizon)]={}
                    for width in WIDTHS:
                        s=stats(rs,policy,axis,horizon,width);values[part][policy][axis][str(horizon)][str(width)]=s
                        scalar_count+=equal(aggregate['集計'][part][policy][axis][str(horizon)][str(width)],s,
                                            f'集計/{part}/{policy}/{axis}/{horizon}/{width}')
                        condition_count+=1
    assert condition_count==300
    equal(aggregate['参加'],participation,'参加');equal(aggregate['全4streamのphase検査'],phase,'phase')
    main=values['all']['L1']['BBO']['3600']['125'];p=participation['all']['L1']
    goal={'主':'L1/全73場/実BBO/H60/±125pt','全73場最低1取得':p['全場最低1取得'],
          '到達済み先着70%以上':main['target70'],'両条件達成':bool(p['全場最低1取得'] and main['target70'] is True),
          '順':main['forward'],'逆':main['adverse'],'未到達':main['neither'],'全H不足':main['censored'],
          '到達済み率':main['resolved_rate'],'未到達込率':main['complete_rate'],'参加':p}
    equal(aggregate['主評価'],goal,'主評価')
    oldpairs,old124,old131=load('oldpairs'),load('old124'),load('old131')
    prior={(s['session'],c['id']):c for s in oldpairs['scenes'] for c in s['cases']}
    old_case_count=0;labels=0
    for r in records:
        if r['meta']['model']!='L0':continue
        old=prior[(r['session'],r['meta']['legacy_id'])];new=r['case'];assert old['original_side']==new['original_side']
        for name in ('original','reverse','chart_original','chart_reverse'):
            for field in ('entry','entry_price','outcomes'):equal(new[name][field],old[name][field],f'旧case/{name}/{field}')
            assert new[name]['birth']['side']==old[name]['birth']['side'];labels+=len(HORIZONS)*len(WIDTHS)
        old_case_count+=1
    assert old_case_count==79 and labels==3160
    old_conditions=0
    for axis in AXES:
        for h in HORIZONS:
            for w in WIDTHS:
                equal(values['all']['O0'][axis][str(h)][str(w)],old124['集計']['O0'][axis][str(h)][str(w)],'旧124')
                old_conditions+=1
    for part in parts:
        for policy,oldpolicy in (('O0','O0'),('L0','T8')):
            for axis in AXES:
                for h in HORIZONS:
                    for w in WIDTHS:
                        equal(values[part][policy][axis][str(h)][str(w)],old131['集計'][part][oldpolicy][axis][str(h)][str(w)],'旧131')
                        old_conditions+=1
    assert old_conditions==140
    table_proof=tables_check(table_data['tables'],records,sessions,values,participation)
    assert aggregate['L0とL1のcaseペア差'] is None
    known_pairs=[];known_types=Counter()
    for r in subset(records,'L1',sessions):
        x=ifd(choose(r,'L1','BBO'),3600,125,'BBO');y=ifd(choose(r,'O1','BBO'),3600,125,'BBO')
        kind='both' if x['known'] and y['known'] else 'policy' if x['known'] else 'reference' if y['known'] else 'none'
        known_types[kind]+=1
        if kind=='both':known_pairs.append(x['net5']-y['net5'])
    paired={'政策':'L1','同群の対照':'O1','取得集合':'L1','同case数':79,'両側既知':known_types['both'],
            '政策だけ既知':known_types['policy'],'対照だけ既知':known_types['reference'],'両側未知':known_types['none'],
            'C5既知ペア差引円':sum(known_pairs),
            'C5既知ペア平均差円':float(Fraction(sum(known_pairs))/len(known_pairs)) if known_pairs else None}
    equal(aggregate['主L1と同群O1の両側既知ペア差'],paired,'同群ペア差')
    assert all(sha(ROOT/p)==h for p,h in paths.values())
    proof={'success':True,'trial':133,'nonfinancial_cohort':nonfinancial_proof,'condition_count':condition_count,
           'aggregate_leaf_values_checked':scalar_count,'participation':participation,'phase_checks':phase,
           'table_checks':table_proof,'old_conditions_identical':old_conditions,'old_cases_identical':old_case_count,
           'old_stream_H_width_observations_identical':labels,'main':main,
           'front48':values['train']['L1']['BBO']['3600']['125'],'back25':values['validation']['L1']['BBO']['3600']['125'],
           'L0_main':values['all']['L0']['BBO']['3600']['125'],'source_hashes_before_after_equal':True,
           'sources':{p:h for p,h in paths.values()},'code_sha256':sha(Path(__file__)),
           'Root_or_124_arithmetic_imported':False,'raw_reread':False,'bootstrap_reimplemented':False,
           'source_conditions_or_parameters_edited':False,'independent_unknown_period':False,
           'first_touch_within_missing_gap_reconstructed':False}
    out=HERE/'独立確認.json';assert not out.exists()
    out.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'success':True,'proof_sha256':sha(out),'conditions':condition_count,'table_cells':table_proof['all_data_cells_equal'],
                      'main':main,'back25':proof['back25'],'old_conditions':old_conditions},ensure_ascii=False))


if __name__=='__main__':main()
