"""128の固定原文・小型再現入力・成果を、金融再生せず保管する。"""
from pathlib import Path
import gzip
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent.parent
OWN = ROOT/'work/128Raw時計の評価'
FORMAL = ROOT/'study/00128_Raw価格時計で構造回復の出生を比較する'
INPUTS = ROOT/'inputs/00128_Raw価格時計の独立出生'


def digest(path: Path) -> str:
    """
    機能: ファイルの全bytesを逐次指紋化する。本文を解釈しない。
    引数: path(Path)。返り値: strはSHA256。
    """
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(1048576), b''):
            h.update(data)
    return h.hexdigest()


# ----------------------------------------
def sha(data: bytes) -> str:
    """
    機能: 小型bytesの指紋を求める。
    引数: data(bytes)。返り値: strはSHA256。
    """
    return hashlib.sha256(data).hexdigest()


# ----------------------------------------
def save(path: Path, value: dict) -> None:
    """
    機能: 未作成先へUTF-8 JSONを保存する。
    引数: path(Path)、value(dict)。返り値: None。
    """
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n')


# ----------------------------------------
def exact(source: Path, target: Path) -> dict:
    """
    機能: 原文を同bytesで未作成先へ保存する。
    引数: source/target(Path)。返り値: dictは由来と指紋。
    """
    data = source.read_bytes()
    with target.open('xb') as stream:
        stream.write(data)
    assert target.read_bytes() == data
    return {'source':source.relative_to(ROOT).as_posix(), 'target':target.relative_to(ROOT).as_posix(),
            'bytes':len(data), 'sha256':sha(data)}


# ----------------------------------------
def compressed(source: Path, target: Path) -> dict:
    """
    機能: 圧縮後の解凍bytesを照合して保存する。JSON値を解釈しない。
    引数: source/target(Path)。返り値: dictは圧縮/元の指紋。
    """
    data = source.read_bytes()
    encoded = gzip.compress(data, mtime=0)
    with target.open('xb') as stream:
        stream.write(encoded)
    assert gzip.decompress(target.read_bytes()) == data
    return {'source':source.relative_to(ROOT).as_posix(), 'target':target.relative_to(ROOT).as_posix(),
            'bytes':len(encoded), 'sha256':sha(encoded), 'decoded_bytes':len(data), 'decoded_sha256':sha(data)}


# ----------------------------------------
def code_zip(target: Path, paths: list[Path]) -> dict:
    """
    機能: 相対pathを保つZIPを作成し全CRCと指紋を確認する。
    引数: target(Path)、paths(list[Path])。返り値: dictは復元索引。
    """
    entries = []
    with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(set(paths)):
            name = path.relative_to(ROOT).as_posix()
            data = path.read_bytes()
            info = zipfile.ZipInfo(name, (1980,1,1,0,0,0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, data)
            entries.append({'entry':name, 'restore_relative':name, 'bytes':len(data), 'sha256':sha(data)})
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None
        for entry in entries:
            assert sha(archive.read(entry['entry'])) == entry['sha256']
            entry['crc32'] = f"{archive.getinfo(entry['entry']).CRC:08x}"
    return {'zip':{'path':target.name, 'bytes':target.stat().st_size, 'sha256':digest(target)}, 'entries':entries}


# ----------------------------------------
def main() -> None:
    """
    機能: F0全文書保存後、2入力・2結果・集計・コード・小型検査を恒久保存する。
    引数: なし。返り値: None。原板読取・金融再生・CSV生成は行わない。
    """
    for path in (FORMAL/'検査', FORMAL/'成果物', FORMAL/'再現資料', INPUTS):
        path.mkdir(exist_ok=True)
    assert digest(OWN/'F0.json') == '16e1eb2ac52119e60180fa33322b36742646fb9a68f5ea34b38876cf739cc870'
    assert digest(OWN/'F1.json') == '8f94cebf15c8512b08778c31a5f7d87546ea504e0ac1d8a3d5e312c439dc4d2e'
    f0 = json.loads((OWN/'F0.json').read_text('utf-8'))
    f1 = json.loads((OWN/'F1.json').read_text('utf-8'))
    for name, expected in {**f0['ファイル'], **f1['ファイル']}.items():
        assert digest(Path(name)) == expected, name
    # ----------------------------------------
    # 結果を追記する前に、F0のMD全9点を可逆な同bytesで保存する。
    originals = []
    for name, expected in f0['ファイル'].items():
        path = Path(name)
        if path.suffix != '.md':
            continue
        data = path.read_bytes()
        text = data.decode('utf-8')
        assert text.encode('utf-8') == data
        originals.append({'restore_relative':path.relative_to(ROOT).as_posix(), 'bytes':len(data),
                          'sha256':expected, 'utf8_text':text})
    assert len(originals) == 9
    encoded = (json.dumps({'trial':128, 'F0_sha256':digest(OWN/'F0.json'), '原文':originals},
                          ensure_ascii=False, indent=2)+'\n').encode('utf-8')
    data = gzip.compress(encoded, mtime=0)
    with (FORMAL/'検査/実行前文書.json.gz').open('xb') as stream:
        stream.write(data)
    assert gzip.decompress(data) == encoded
    save(FORMAL/'検査/実行前原文の確認.json', {'成功':True, '原文数':9, '結果更新前保存':True,
         'gzip_bytes':len(data), 'gzip_sha256':sha(data), 'decoded_bytes':len(encoded),
         'decoded_sha256':sha(encoded), '原文':[{k:v for k,v in o.items() if k != 'utf8_text'} for o in originals]})
    copied = [exact(OWN/'F0.json', FORMAL/'検査/F0.json'), exact(OWN/'F1.json', FORMAL/'検査/F1.json')]
    inputs = []
    artifacts = []
    for model in ('gap300', 'gap300_delay60'):
        inputs.append(compressed(OWN/f'{model}入力.json', INPUTS/f'{model}入力.json.gz'))
        artifacts.append(compressed(OWN/f'{model}結果.json', FORMAL/'成果物'/f'{model}結果.json.gz'))
        artifacts.append(compressed(OWN/f'{model}集計/集計.json', FORMAL/'成果物'/f'{model}集計.json.gz'))
        for source, name in [(OWN/f'{model}再生完了.json',f'{model}再生完了.json'),
                             (OWN/f'{model}集計完了.json',f'{model}集計完了.json'),
                             (OWN/f'{model}集計/集計完了.json',f'{model}集計の入力確認.json'),
                             (ROOT/f'work/128Raw時計の独立検算/{model}の独立検算.json',f'{model}の独立検算.json')]:
            copied.append(exact(source,FORMAL/'検査'/name))
    save(INPUTS/'指紋.json',{'trial':128, 'inputs':inputs, 'raw_duplicated':False,
        'publications_177MB_duplicated':False, 'raw_clock_publications_duplicated':False,
        'birth_counter_duplicated':False, 'recipe':'study/00128_Raw価格時計で構造回復の出生を比較する/再現資料/再現手順.md'})
    artifacts.append(compressed(ROOT/'work/128全場のRaw公表/summary.json', FORMAL/'成果物/足生成summary.json.gz'))
    for source, name in [(OWN/'足完了の独立確認.json','足完了の独立確認.json'),
        (ROOT/'work/128Raw価格時計の全場足生成/F0前の準備確認.json','足生成器の人工検査.json'),
        (ROOT/'work/128Raw価格時計の全場足生成/試作コードの複写.json','数値原文の複写.json'),
        (ROOT/'work/128Raw時計の独立検算/準備完了.json','独立検算の準備完了.json'),
        (ROOT/'work/128Raw時計の独立検算/人工検査.json','独立検算の人工検査.json'),
        (ROOT/'work/128Raw時計の独立検算/完了.json','独立検算の完了.json'),
        (ROOT/'work/128Raw時計CSV出力/独立再読の確認.json','CSV独立再読.json'),
        (ROOT/'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/128Raw時計CSV/CSVの確認.json','CSVの確認.json')]:
        copied.append(exact(source,FORMAL/'検査'/name))
    copied.append(exact(ROOT/'work/128Raw出生の集計/条件.md',FORMAL/'根拠/集計条件.md'))
    paths = [Path(p) for p in f0['ファイル'] if Path(p).suffix in ('.py','.go') or Path(p).name == 'go.mod']
    paths += [ROOT/'work/128閲覧表をまとめる.py', ROOT/'work/128Raw時計CSV出力/出力する.mjs',
              ROOT/'work/128Raw時計CSV出力/CSVを独立再読する.py', Path(__file__).resolve()]
    paths += [p for p in (ROOT/'work/128Raw時計の独立検算').iterdir() if p.suffix in ('.py','.md')]
    index = code_zip(FORMAL/'再現資料/128コード.zip',paths)
    index['trial'] = 128
    index['F0_sha256'] = digest(OWN/'F0.json')
    index['F0_source_count'] = sum(Path(p).suffix in ('.py','.go') or Path(p).name == 'go.mod' for p in f0['ファイル'])
    index['shared_124_financial_module_included'] = True
    index['independent_checker_external'] = {'archive':'../../00124_逆行の原因と売買反転を同じ入口で検証する/再現資料/検算と保存の追補コード.zip',
        'entry':'work/124正逆の独立検算/検算する.py', 'sha256':'0305f507a74f9728fbdb1ecabe406a3bfcb2f8657a4d1ee2556ca50dbe6585be'}
    save(FORMAL/'再現資料/コード復元索引.json',index)
    for name, expected in {**f0['ファイル'], **f1['ファイル']}.items():
        assert digest(Path(name)) == expected, name
    save(FORMAL/'検査/保存の確認.json',{'成功':True, '試行':128, '金融再実行なし':True,
        'F0全9原文を結果更新前に保存':True, '保存前後F0F1全ファイル同体':True,
        'コピー':copied, '共用入力':inputs, '圧縮成果':artifacts, 'コードZIP':index['zip'],
        'Rawと177MBと公表3gzipとcounter全件は複製しない':True, '保存コードSHA256':digest(Path(__file__))})
    print(json.dumps({'成功':True,'F0原文数':9,'inputs':inputs,'成果':artifacts,'code':index['zip']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
