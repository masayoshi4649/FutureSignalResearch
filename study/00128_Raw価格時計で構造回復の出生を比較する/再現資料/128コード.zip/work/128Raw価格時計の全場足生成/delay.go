package rawpricebars

import (
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"math"
)

type Dropped struct {
	ID         string      `json:"id"`
	End        float64     `json:"end"`
	EligibleAt float64     `json:"eligible_at"`
	ClosedAt   rules.Stamp `json:"closed_at"`
}
type Delay struct {
	bank      *rules.Bank
	queue     []Publication
	delivered int
	started   bool
	contract  string
}

// newDelay は即時Bankと共有しない遅延公開窓を作ります。
//
// 引数: なし。返り値: *Delayです。
func newDelay() *Delay { return &Delay{bank: rules.NewBank()} }

// start は前場の未配送を持ち込まず、検証済み同限月の配送窓だけを継承します。
//
// 引数: s(Scene)、carry(bool)。返り値: errorです。
func (d *Delay) start(s Scene, carry bool) error {
	if len(d.queue) != 0 {
		return fmt.Errorf("EOF queueを処理してから場替わりが必要")
	}
	if !carry || !d.started || d.contract != s.Contract {
		d.bank = rules.NewBank()
	}
	if err := d.bank.StartSession(s.Session, s.Contract); err != nil {
		return err
	}
	d.started = true
	d.contract = s.Contract
	d.delivered = 0
	return nil
}

// release は同じgap300完成値をEnd+60以降の最初の採用Rawへ遅延配送します。
//
// 引数: pubs([]Publication)、q(Quote)。返り値: []Publication/errorです。
func (d *Delay) release(pubs []Publication, q Quote) ([]Publication, error) {
	d.queue = append(d.queue, pubs...)
	result := []Publication{}
	for len(d.queue) > 0 {
		original := d.queue[0]
		f := original.Frame.Frame
		eligible := math.Max(f.End+60, original.Stamp.Time)
		if q.Time < eligible {
			break
		}
		d.queue = d.queue[1:]
		p := original
		closed := original.Stamp
		p.ClosedAt = &closed
		p.Stamp = rules.Stamp{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine)}
		p.Frame.Frame.NominalAvailable = f.End + 60
		p.Frame.Frame.AvailableAt = eligible
		p.Frame.Frame.DeliveryAt = q.Time
		p.Frame.Frame.RecordOrdinal = uint64(q.Index + 1)
		p.Model = "同じgap300確定値のEnd+60遅延公表・受信時計ではない"
		v, err := convert(p)
		if err != nil {
			return nil, err
		}
		if err = d.bank.Add(v); err != nil {
			return nil, err
		}
		d.delivered++
		result = append(result, p)
	}
	return result, nil
}

// eof は時計を進めず未配送の参照だけを落とし、次場へ持ち込みません。
//
// 引数: なし。返り値: []Droppedです。
func (d *Delay) eof() []Dropped {
	dropped := []Dropped{}
	for _, p := range d.queue {
		dropped = append(dropped, Dropped{ID: p.Frame.Frame.ID, End: p.Frame.Frame.End, EligibleAt: math.Max(p.Frame.Frame.End+60, p.Stamp.Time), ClosedAt: p.Stamp})
	}
	d.queue = nil
	return dropped
}
