package rawpricebars

import (
	"bufio"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	old "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
	"io"
	"os"
	"reflect"
	"time"
)

// normal は旧parserと同じ正Bid<Askだけを判定します。
//
// 引数: q(Quote)。返り値: boolです。
func normal(q Quote) bool { return finite(q.Bid, q.Ask) && q.Bid > 0 && q.Ask > q.Bid }

// quantity は当Rawの数量値/時計だけを解釈します。
//
// 引数: raw([]byte)。返り値: *float64/*float64は既知量/時計又はnilです。
func quantity(raw []byte) (*float64, *float64) {
	var fields map[string]json.RawMessage
	if json.Unmarshal(raw, &fields) != nil {
		return nil, nil
	}
	var volume *float64
	var text string
	if json.Unmarshal(fields["TradingVolume"], &volume) != nil || volume == nil || !finite(*volume) || *volume < 0 || json.Unmarshal(fields["TradingVolumeTime"], &text) != nil {
		return nil, nil
	}
	t, err := time.Parse(time.RFC3339Nano, text)
	if err != nil {
		return volume, nil
	}
	x := float64(t.UnixNano()) / 1e9
	return volume, &x
}

type GeneratedScene struct {
	Session          string                 `json:"session"`
	Contract         string                 `json:"contract"`
	Start            float64                `json:"start"`
	End              float64                `json:"end"`
	ForceClose       float64                `json:"force_close"`
	Raw              old.FileRef            `json:"raw"`
	ExpectedAccepted int64                  `json:"expected_accepted"`
	ExpectedQuality  *Counts                `json:"expected_quality"`
	Counts           Counts                 `json:"counts"`
	CarryFrom        string                 `json:"carry_from,omitempty"`
	Publications     []Publication          `json:"publications"`
	Stats            Stats                  `json:"generator_stats"`
	Delivered        int                    `json:"publications_delivered"`
	Dropped          []Dropped              `json:"eof_undelivered"`
	Ready            map[string]int         `json:"ready_observations"`
	FirstReady       map[string]rules.Stamp `json:"first_ready"`
}
type SceneSummary struct {
	Session   string         `json:"session"`
	Counts    Counts         `json:"counts"`
	ActualSHA string         `json:"actual_sha256"`
	RawPasses int            `json:"raw_passes"`
	CarryFrom string         `json:"carry_from,omitempty"`
	Models    []ModelSummary `json:"models"`
}
type ModelSummary struct {
	Name           string                 `json:"name"`
	Stats          Stats                  `json:"generator_stats"`
	Delivered      int                    `json:"publications_delivered"`
	EOFUndelivered int                    `json:"eof_undelivered"`
	Ready          map[string]int         `json:"ready_observations"`
	FirstReady     map[string]rules.Stamp `json:"first_ready"`
	PriceKnown     map[int]int            `json:"price_known"`
	VolumeKnown    map[int]int            `json:"volume_known"`
}

// readiness は現在までに配送された公表窓だけで助走を集計します。
//
// 引数: target(*GeneratedScene)、snapshot(rules.Snapshot)、q(Quote)。返り値: ありません。
func readiness(target *GeneratedScene, s rules.Snapshot, q Quote) {
	f := s.Frames[300].Frame.Frame
	t := f.Technical
	keys := map[string]bool{"EMA21_5": f.PriceKnown && t.EMA21.Known, "ATR5": f.PriceKnown && t.ATR.Known, "RSI5": f.PriceKnown && t.RSI.Known, "Hist5": f.PriceKnown && t.Histogram.Known, "ADX5": f.PriceKnown && s.Frames[300].Frame.DMI.ADX.Known, "BB15": s.BB15.Known, "RVOL5": s.RVOL5.Known}
	for key, ok := range keys {
		if ok {
			target.Ready[key]++
			if _, exists := target.FirstReady[key]; !exists {
				target.FirstReady[key] = rules.Stamp{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine)}
			}
		}
	}
}

// scanScene は各Rawを1回だけ走査し、2品質生成器と同値遅延対照へ配送します。
//
// 引数: scene(Scene)、gs([2]*Generator)、delay(*Delay)、carryFrom(string)。返り値: [3]GeneratedScene/SceneSummary/errorです。
func scanScene(scene Scene, gs [2]*Generator, delay *Delay, carryFrom string) ([3]GeneratedScene, SceneSummary, error) {
	output := [3]GeneratedScene{}
	summary := SceneSummary{Session: scene.Session, RawPasses: 1, CarryFrom: carryFrom}
	for i := range output {
		output[i] = GeneratedScene{Session: scene.Session, Contract: scene.Contract, Start: scene.Start, End: scene.End, ForceClose: scene.ForceClose, Raw: scene.Raw, ExpectedAccepted: scene.ExpectedAccepted, ExpectedQuality: scene.ExpectedQuality, CarryFrom: carryFrom, Publications: []Publication{}, Dropped: []Dropped{}, Ready: map[string]int{}, FirstReady: map[string]rules.Stamp{}}
	}
	f, err := os.Open(scene.Raw.Path)
	if err != nil {
		return output, summary, err
	}
	defer f.Close()
	before, err := f.Stat()
	if err != nil {
		return output, summary, err
	}
	if scene.Raw.Bytes > 0 && scene.Raw.Bytes != before.Size() {
		return output, summary, fmt.Errorf("原板bytes差")
	}
	for i := range output {
		output[i].Raw.Bytes = before.Size()
	}
	for _, g := range gs {
		g.session.Input.Bytes = before.Size()
	}
	h := sha256.New()
	buffer := bufio.NewReader(io.TeeReader(f, h))
	header, err := buffer.Peek(2)
	if err != nil {
		return output, summary, err
	}
	var stream io.Reader = buffer
	if header[0] == 0x1f && header[1] == 0x8b {
		z, e := gzip.NewReader(buffer)
		if e != nil {
			return output, summary, e
		}
		defer z.Close()
		stream = z
	}
	scanner := bufio.NewScanner(stream)
	scanner.Buffer(make([]byte, 65536), 4<<20)
	previous := scene.Start
	index := int64(0)
	contracts := map[string]bool{}
	for scanner.Scan() {
		summary.Counts.Lines++
		raw := scanner.Bytes()
		q, reason, next, e := decodeRow(raw, summary.Counts.Lines, index, scene, previous, &summary.Counts, contracts)
		if e != nil {
			return output, summary, e
		}
		previous = next
		if q == nil {
			if reason == "clock_invalid" || reason == "clock_missing" || reason == "backward_clock" {
				for _, g := range gs {
					g.RejectClock(reason)
				}
			}
			continue
		}
		volume, stamp := quantity(raw)
		observation := Observation{Quote: *q, Volume: volume, VolumeTime: stamp}
		var mainPubs []Publication
		for i, g := range gs {
			pubs, e := g.Observe(observation)
			if e != nil {
				return output, summary, e
			}
			output[i].Publications = append(output[i].Publications, pubs...)
			if i == 0 {
				mainPubs = pubs
			}
			if len(pubs) > 0 {
				snap, e := g.Current(rules.Quote{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine), Last: q.Last})
				if e != nil {
					return output, summary, e
				}
				readiness(&output[i], snap, *q)
			}
		}
		pubs, e := delay.release(mainPubs, *q)
		if e != nil {
			return output, summary, e
		}
		output[2].Publications = append(output[2].Publications, pubs...)
		if len(pubs) > 0 {
			snap, e := delay.bank.Current(rules.Quote{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine), Last: q.Last})
			if e != nil {
				return output, summary, e
			}
			readiness(&output[2], snap, *q)
		}
		index++
	}
	if err = scanner.Err(); err != nil {
		return output, summary, err
	}
	if _, err = io.Copy(io.Discard, buffer); err != nil {
		return output, summary, err
	}
	summary.ActualSHA = hex.EncodeToString(h.Sum(nil))
	after, err := f.Stat()
	if err != nil {
		return output, summary, err
	}
	pathAfter, err := os.Stat(scene.Raw.Path)
	if err != nil {
		return output, summary, err
	}
	if summary.ActualSHA != scene.Raw.SHA256 || before.Size() != after.Size() || !before.ModTime().Equal(after.ModTime()) || !os.SameFile(before, pathAfter) || before.Size() != pathAfter.Size() || !before.ModTime().Equal(pathAfter.ModTime()) || summary.Counts.Accepted != scene.ExpectedAccepted || scene.ExpectedQuality == nil || !reflect.DeepEqual(summary.Counts, *scene.ExpectedQuality) || len(contracts) != 1 || !contracts[scene.Contract] {
		return output, summary, fmt.Errorf("原板SHA/stat/11品質/採用数/限月差:%s", scene.Session)
	}
	output[2].Dropped = delay.eof()
	names := [3]string{"gap300", "gap60", "gap300_delay60"}
	for i := range output {
		output[i].Counts = summary.Counts
		output[i].Stats = gs[i%2].Stats()
		if i == 2 {
			output[i].Stats = gs[0].Stats()
		}
		output[i].Delivered = len(output[i].Publications)
		prices, volumes := map[int]int{}, map[int]int{}
		for _, p := range output[i].Publications {
			f := p.Frame.Frame
			if f.PriceKnown {
				prices[f.WidthSeconds]++
			}
			if f.VolumeKnown {
				volumes[f.WidthSeconds]++
			}
		}
		summary.Models = append(summary.Models, ModelSummary{Name: names[i], Stats: output[i].Stats, Delivered: output[i].Delivered, EOFUndelivered: len(output[i].Dropped), Ready: output[i].Ready, FirstReady: output[i].FirstReady, PriceKnown: prices, VolumeKnown: volumes})
	}
	for _, g := range gs {
		if int64(g.Stats().Accepted) != summary.Counts.Delivered {
			return output, summary, fmt.Errorf("生成器配送数差")
		}
	}
	return output, summary, nil
}
