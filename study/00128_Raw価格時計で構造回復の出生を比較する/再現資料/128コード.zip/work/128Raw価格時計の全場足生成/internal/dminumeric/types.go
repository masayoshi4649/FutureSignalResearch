// Package threeframe115 は旧三時間軸の公表へ独立DMIと取得前構造だけを足します。
package dminumeric

import old "github.com/masayoshi4649/SessionTradeExecuter/threeframe"

type Value = old.Value

// DMI は今回と直前の方向性を、数値の既知性とともに保持します。
type DMI struct {
	PlusDI          Value  `json:"plus_di"`
	MinusDI         Value  `json:"minus_di"`
	DX              Value  `json:"dx"`
	ADX             Value  `json:"adx"`
	PreviousPlusDI  Value  `json:"previous_plus_di"`
	PreviousMinusDI Value  `json:"previous_minus_di"`
	PreviousADX     Value  `json:"previous_adx"`
	Bars            uint64 `json:"bars"`
	Differences     uint64 `json:"differences"`
	DXCount         int    `json:"dx_count"`
}

// Structure は現在足を含めない直前3本の当場5分足高安です。
type Structure struct {
	Known bool          `json:"known"`
	High  float64       `json:"high"`
	Low   float64       `json:"low"`
	Refs  [3]old.BarRef `json:"refs"`
}

// Frame は旧公表全文を変更せず、新しい二役だけを別項目へ保持します。
type Frame struct {
	Frame     old.Frame `json:"frame"`
	DMI       DMI       `json:"dmi"`
	Structure Structure `json:"structure"`
}

// ScaleSnapshot は当場の現在公表と、前史数値種だけの既知性を分けます。
type ScaleSnapshot struct {
	WidthSeconds  int           `json:"width_seconds"`
	HasCurrent    bool          `json:"has_current"`
	Fresh         bool          `json:"fresh"`
	SeedOnly      bool          `json:"seed_only"`
	Current       Frame         `json:"current"`
	SeedTechnical old.Technical `json:"seed_technical"`
	SeedDMI       DMI           `json:"seed_dmi"`
}

// Snapshot は旧公表と同じasof時計を持つ独立値です。
type Snapshot struct {
	Session          old.Session      `json:"session"`
	AsOf             float64          `json:"as_of"`
	ReplayObservedAt float64          `json:"replay_observed_at"`
	HasObserved      bool             `json:"has_observed"`
	RecordOrdinal    uint64           `json:"record_ordinal"`
	Sealed           bool             `json:"sealed"`
	Scales           [3]ScaleSnapshot `json:"scales"`
}

// Scale は指定幅の公表を参照共有のない値として返します。
//
// 引数: widthSeconds(int)は300/900/1800秒です。
// 返り値: ScaleSnapshot/boolは対応値と対応幅があったことです。
func (s Snapshot) Scale(widthSeconds int) (ScaleSnapshot, bool) {
	for _, scale := range s.Scales {
		if scale.WidthSeconds == widthSeconds {
			return scale, true
		}
	}
	return ScaleSnapshot{}, false
}

// DMISeedInfo は数値種の全状態指紋と助走本数を公開します。
type DMISeedInfo struct {
	WidthSeconds int    `json:"width_seconds"`
	Bars         uint64 `json:"bars"`
	Differences  uint64 `json:"differences"`
	DXCount      int    `json:"dx_count"`
	StateSHA256  string `json:"state_sha256"`
	Last         DMI    `json:"last"`
}

// SeedInfo は旧seedとDMI種の組を識別し、外から数値を組み立てさせません。
type SeedInfo struct {
	Version int            `json:"version"`
	Old     old.SeedInfo   `json:"old"`
	DMI     [3]DMISeedInfo `json:"dmi"`
	SHA256  string         `json:"sha256"`
}

// Definition は既定の数値契約をRootの固定条件へ渡します。
type Definition struct {
	Version                    int    `json:"version"`
	DMIPeriod                  int    `json:"dmi_period"`
	FirstDIBars                int    `json:"first_di_bars"`
	FirstADXBars               int    `json:"first_adx_bars"`
	TieDM                      string `json:"tie_dm"`
	Undefined                  string `json:"undefined"`
	ADXNeedsConsecutiveDX      bool   `json:"adx_needs_consecutive_dx"`
	NumericOnlySameContract    bool   `json:"numeric_only_same_contract"`
	DonchianPreviousBars       int    `json:"donchian_previous_bars"`
	DonchianIncludesCurrent    bool   `json:"donchian_includes_current"`
	DonchianCurrentSessionOnly bool   `json:"donchian_current_session_only"`
}

// DeclaredDefinition は市場条件を持たない115の公開契約を返します。
//
// 引数: なし。
// 返り値: DefinitionはDMI14と前3本構造の固定された定義です。
func DeclaredDefinition() Definition {
	return Definition{115, 14, 15, 28, "up>downかつup>0なら+DM=up、down>upかつdown>0なら-DM=down、それ以外は両0", "平滑TR又は平滑DM和が0ならDMI/ADX未知。連続DX窓reset", true, true, 3, false, true}
}
