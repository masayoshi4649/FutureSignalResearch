package dminumeric

import (
	"fmt"
	"math"

	old "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
)

type rma struct {
	Count int
	Sum   float64
	Value float64
	Known bool
}

// update は14個の初期SMAと、それ以降のWilder平均を進めます。
//
// 引数: value(float64)は有限で非負のDM/TR/DXです。
// 返り値: なし。有限性は公表をcommitする前に別途検査します。
func (m *rma) update(value float64) {
	if !m.Known {
		m.Count++
		m.Sum += value
		if m.Count == 14 {
			m.Value, m.Known = m.Sum/14, true
		}
		return
	}
	m.Value = (m.Value*13 + value) / 14
}

type dmiState struct {
	Previous    old.OHLC
	HasPrevious bool
	Plus        rma
	Minus       rma
	TR          rma
	ADX         rma
	Bars        uint64
	Differences uint64
	DXCount     int
	Latest      DMI
}

// finite は追加数値の非有限を拒否します。
//
// 引数: values(...float64)は数値の候補です。
// 返り値: boolは全て有限の場合だけ真です。
func finite(values ...float64) bool {
	for _, value := range values {
		if math.IsNaN(value) || math.IsInf(value, 0) {
			return false
		}
	}
	return true
}

// validDMI は私有種を含めた追加数値の有限性を検査します。
//
// 引数: state(dmiState)は更新候補又は同限月種です。
// 返り値: boolは有限な有効状態の場合だけ真です。
func validDMI(state dmiState) bool {
	if !finite(state.Previous.Open, state.Previous.High, state.Previous.Low, state.Previous.Close) || state.DXCount < 0 {
		return false
	}
	for _, mean := range []rma{state.Plus, state.Minus, state.TR, state.ADX} {
		if !finite(mean.Sum, mean.Value) || mean.Sum < 0 || mean.Value < 0 || mean.Count < 0 || mean.Count > 14 || mean.Known != (mean.Count == 14) {
			return false
		}
	}
	for _, value := range []Value{state.Latest.PlusDI, state.Latest.MinusDI, state.Latest.DX, state.Latest.ADX,
		state.Latest.PreviousPlusDI, state.Latest.PreviousMinusDI, state.Latest.PreviousADX} {
		if !finite(value.Value) || value.Known && (value.Value < 0 || value.Value > 100+1e-10) {
			return false
		}
	}
	return true
}

// advance は確定済みの一足だけを独立DMIへ入力します。
//
// 引数: frame(old.Frame)は旧公開器が順に公表した値です。
// 返り値: DMI/errorは現在/直前値又は追加計算の破損です。価格欠測は全resetします。
func (s *dmiState) advance(frame old.Frame) (DMI, error) {
	if !frame.PriceKnown {
		*s = dmiState{}
		return DMI{}, nil
	}
	previous := s.Latest
	value := DMI{PreviousPlusDI: previous.PlusDI, PreviousMinusDI: previous.MinusDI, PreviousADX: previous.ADX}
	s.Bars++
	if s.HasPrevious {
		up, down := frame.OHLC.High-s.Previous.High, s.Previous.Low-frame.OHLC.Low
		plus, minus := 0.0, 0.0
		if up > down && up > 0 {
			plus = up
		}
		if down > up && down > 0 {
			minus = down
		}
		tr := math.Max(frame.OHLC.High-frame.OHLC.Low,
			math.Max(math.Abs(frame.OHLC.High-s.Previous.Close), math.Abs(frame.OHLC.Low-s.Previous.Close)))
		s.Plus.update(plus)
		s.Minus.update(minus)
		s.TR.update(tr)
		s.Differences++
		if s.TR.Known && s.Plus.Known && s.Minus.Known && s.TR.Value > 0 && s.Plus.Value+s.Minus.Value > 0 {
			value.PlusDI = Value{Known: true, Value: 100 * (s.Plus.Value / s.TR.Value)}
			value.MinusDI = Value{Known: true, Value: 100 * (s.Minus.Value / s.TR.Value)}
			value.DX = Value{Known: true, Value: 100 * (math.Abs(s.Plus.Value-s.Minus.Value) / (s.Plus.Value + s.Minus.Value))}
			s.ADX.update(value.DX.Value)
			s.DXCount++
			if s.ADX.Known {
				value.ADX = Value{Known: true, Value: s.ADX.Value}
			}
		} else {
			// ----------------------------------------
			// 不定DXを飛ばして古いADXを現在値にせず、14連続DXを再び要求します。
			s.ADX, s.DXCount = rma{}, 0
		}
	}
	s.Previous, s.HasPrevious = frame.OHLC, true
	value.Bars, value.Differences, value.DXCount = s.Bars, s.Differences, s.DXCount
	s.Latest = value
	if !validDMI(*s) {
		return DMI{}, fmt.Errorf("DMI追加数値が非有限又は定義範囲外")
	}
	return value, nil
}

type structureState struct {
	Bars  [3]old.OHLC
	Refs  [3]old.BarRef
	Count int
}

// advance は現在足を加える前の当場3本だけから境界を返します。
//
// 引数: frame(old.Frame)は当場の公表済み5分足です。
// 返り値: Structureは現在を含めない連続3本の高安と出典。欠測でcoldへ戻ります。
func (s *structureState) advance(frame old.Frame) Structure {
	if frame.WidthSeconds != 300 {
		return Structure{}
	}
	if !frame.PriceKnown {
		*s = structureState{}
		return Structure{}
	}
	if s.Count > 0 && s.Refs[s.Count-1].End != frame.Start {
		*s = structureState{}
	}
	value := Structure{}
	if s.Count == 3 {
		value = Structure{true, s.Bars[0].High, s.Bars[0].Low, s.Refs}
		for _, bar := range s.Bars[1:] {
			value.High = math.Max(value.High, bar.High)
			value.Low = math.Min(value.Low, bar.Low)
		}
	}
	if s.Count == 3 {
		copy(s.Bars[:2], s.Bars[1:])
		copy(s.Refs[:2], s.Refs[1:])
		s.Count = 2
	}
	s.Bars[s.Count] = frame.OHLC
	s.Refs[s.Count] = old.BarRef{ID: frame.ID, Start: frame.Start, End: frame.End, PublishedAt: frame.DeliveryAt}
	s.Count++
	return value
}
