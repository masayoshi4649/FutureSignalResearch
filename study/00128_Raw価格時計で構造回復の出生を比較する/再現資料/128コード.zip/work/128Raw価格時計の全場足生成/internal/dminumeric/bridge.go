package dminumeric

import (
	old "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
	ext "github.com/masayoshi4649/SessionTradeExecuter/threeframe115"
)

type State struct {
	dmi       dmiState
	structure structureState
}

// StartSession は同限月のRaw数値だけを継承し構造窓を消去します。
//
// 引数: carry(bool)はRaw由来DMI継承の指定。返り値: なし。
func (s *State) StartSession(carry bool) {
	if !carry {
		s.dmi = dmiState{}
	}
	s.structure = structureState{}
}

// Apply は115原文のDMIと直前3本構造を一度だけ更新します。
//
// 引数: f(old.Frame)は因果的に閉鎖済みの足。返り値: ext.Frame/errorは既存公開型又は原子拒否。
func (s *State) Apply(f old.Frame) (ext.Frame, error) {
	next := *s
	dmi, err := next.dmi.advance(f)
	if err != nil {
		return ext.Frame{}, err
	}
	result := ext.Frame{Frame: f, DMI: ext.DMI(dmi), Structure: ext.Structure(next.structure.advance(f))}
	*s = next
	return result, nil
}
