package rawpricebars

import (
	"encoding/json"
	"math"
	"reflect"
	"testing"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	old "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
	ext "github.com/masayoshi4649/SessionTradeExecuter/threeframe115"
)

// observation は金融結果を含まない人工Rawを作ります。
//
// 引数: at/price/volume(float64)、index(int64)。返り値: Observationは当時の人工値。
func observation(at, price, volume float64, index int64) Observation {
	t := at
	v := volume
	return Observation{Quote: Quote{Time: at, Index: index, SourceLine: index + 1, Last: price, Bid: price - 5, Ask: price + 5, QuoteOK: true}, Volume: &v, VolumeTime: &t}
}

// artificial は同じOHLCを原文APIと新Raw足へ渡す人工列を作ります。
//
// 引数: count(int)、mirror(bool)。返り値: []Observation/[]old.ChildBarは原行と期待5分。
func artificial(count int, mirror bool) ([]Observation, []old.ChildBar) {
	quotes := []Observation{}
	children := []old.ChildBar{}
	for i := 0; i < count; i++ {
		o := 1000 + float64((i*37)%101)
		h, l, c := o+30, o-20, o+10*math.Cos(float64(i))
		values := []float64{o, h, l, c}
		times := []float64{0, 40, 80, 299}
		if mirror {
			o, h, l, c = 3000-o, 3000-l, 3000-h, 3000-c
			for j := range values {
				values[j] = 3000 - values[j]
			}
		}
		for j, v := range values {
			quotes = append(quotes, observation(100200+float64(i*300)+times[j], v, float64(i*4+j), int64(len(quotes))))
		}
		children = append(children, old.ChildBar{Start: 100200 + float64(i*300), End: 100200 + float64((i+1)*300), OHLC: old.OHLC{Open: o, High: h, Low: l, Close: c}, Volume: 4, Closed: true, VolumeKnown: i > 0, Input: old.FileRef{Path: "人工Raw", SHA256: "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", Bytes: 1}, Row: uint64(i + 1)})
	}
	quotes = append(quotes, observation(100200+float64(count*300), 1000, float64(count*4), int64(len(quotes))))
	return quotes, children
}

// runArtificial は原行を順に渡し全公表を保持します。
//
// 引数: t(*testing.T)、quotes([]Observation)、end(float64)、gap(float64)。返り値: *Generator/[]Publication。
func runArtificial(t *testing.T, quotes []Observation, end, gap float64) (*Generator, []Publication) {
	t.Helper()
	g, e := New(Config{MaxGapSeconds: gap})
	if e != nil {
		t.Fatal(e)
	}
	if e = g.StartSession(Session{ID: "人工", Contract: "同限月", Start: 100200, End: end}, false); e != nil {
		t.Fatal(e)
	}
	all := []Publication{}
	for _, q := range quotes {
		ps, e := g.Observe(q)
		if e != nil {
			t.Fatal(e)
		}
		all = append(all, ps...)
	}
	return g, all
}

// TestCausalClosureAndFuture は境界行を次足へ入れ、将来変更が公表を変えないことを検査します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestCausalClosureAndFuture(t *testing.T) {
	qs, _ := artificial(4, false)
	g, e := New(Config{MaxGapSeconds: 300})
	if e != nil {
		t.Fatal(e)
	}
	_ = g.StartSession(Session{ID: "人工", Contract: "同限月", Start: 100200, End: 103200}, false)
	for _, q := range qs[:4] {
		ps, e := g.Observe(q)
		if e != nil || len(ps) != 0 {
			t.Fatalf("未確定足を公表:%v %d", e, len(ps))
		}
	}
	ps, e := g.Observe(qs[4])
	if e != nil || len(ps) != 1 {
		t.Fatal(e, len(ps))
	}
	f := ps[0].Frame.Frame
	if f.OHLC.Close != qs[3].Quote.Last || f.DeliveryAt != qs[4].Quote.Time || f.AvailableAt != f.End {
		t.Fatal(f)
	}
	before, _ := json.Marshal(ps)
	for _, q := range qs[5:] {
		q.Quote.Last += 500
		_, e = g.Observe(q)
		if e != nil {
			t.Fatal(e)
		}
	}
	after, _ := json.Marshal(ps)
	if string(before) != string(after) {
		t.Fatal("過去公表がalias又は将来値で変化")
	}
	if !g.Stats().TerminalUnclosed {
		t.Fatal("EOFで形成中足を確定扱い")
	}
}

// TestOriginalNumericParity は同じ人工OHLCについて旧public APIの数値と全公表を照合します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestOriginalNumericParity(t *testing.T) {
	qs, children := artificial(180, false)
	g, ps := runArtificial(t, qs, 154500, 300)
	b, e := ext.BeginSession(old.Session{ID: "人工", Contract: "同限月", Start: 100200, End: 154500, EOF: 154260}, children, nil)
	if e != nil {
		t.Fatal(e)
	}
	oldFrames, e := b.AdvanceObserved(154260, 1)
	if e != nil {
		t.Fatal(e)
	}
	if len(ps) != len(oldFrames) {
		t.Fatal(len(ps), len(oldFrames))
	}
	for i, p := range ps {
		a, z := p.Frame, oldFrames[i]
		if a.Frame.WidthSeconds != z.Frame.WidthSeconds || a.Frame.End != z.Frame.End || !reflect.DeepEqual(a.Frame.Technical, z.Frame.Technical) || !reflect.DeepEqual(a.DMI, z.DMI) || a.Structure.Known != z.Structure.Known || a.Structure.High != z.Structure.High || a.Structure.Low != z.Structure.Low {
			t.Fatalf("原文数値差:%d", i)
		}
	}
	s, e := g.Current(rules.Quote{Time: qs[len(qs)-1].Quote.Time, Index: len(qs) - 1, Line: len(qs), Last: 1000})
	if e != nil {
		t.Fatal(e)
	}
	if !s.RVOL5.Known || !s.BB15.Known || !s.Frames[300].Frame.Frame.Technical.Histogram.Known || !s.Frames[1800].Frame.DMI.ADX.Known {
		t.Fatal("助走不足", s.RVOL5, s.BB15)
	}
}

// TestGapUnknownAndQuantity は空窓・大gap・数量の初回/減少/非有限を未知として残すことを検査します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestGapUnknownAndQuantity(t *testing.T) {
	g, e := New(Config{MaxGapSeconds: 60})
	if e != nil {
		t.Fatal(e)
	}
	_ = g.StartSession(Session{ID: "人工", Contract: "同限月", Start: 100200, End: 103200}, false)
	_, _ = g.Observe(observation(100201, 100, 100, 0))
	ps, e := g.Observe(observation(101101, 110, 200, 1))
	if e != nil {
		t.Fatal(e)
	}
	if len(ps) != 4 {
		t.Fatal(len(ps))
	}
	for _, p := range ps {
		if p.Frame.Frame.PriceKnown || p.Frame.Frame.VolumeKnown {
			t.Fatal("gap/空窓を既知へ補完")
		}
	}
	q := observation(101120, 120, 10, 2)
	_, _ = g.Observe(q)
	inf := math.Inf(1)
	q = observation(101130, 119, 11, 3)
	q.Volume = &inf
	_, _ = g.Observe(q)
	g.RejectClock("人工後退")
	ps, e = g.Observe(observation(101400, 118, 20, 4))
	if e != nil {
		t.Fatal(e)
	}
	if ps[0].Frame.Frame.PriceKnown || ps[0].Frame.Frame.VolumeKnown || g.Stats().VolumeUnknown == 0 || g.Stats().RejectedClocks != 1 {
		t.Fatal(g.Stats())
	}
}

// TestMirrorCarryAndContract は買売鏡像・Raw数値継承・限月resetを検査します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestMirrorCarryAndContract(t *testing.T) {
	a, _ := artificial(42, false)
	b, _ := artificial(42, true)
	g, pa := runArtificial(t, a, 113100, 300)
	_, pb := runArtificial(t, b, 113100, 300)
	for i, x := range pa {
		y := pb[i]
		ta, tb := x.Frame.Frame.Technical, y.Frame.Frame.Technical
		if ta.RSI.Known && math.Abs(ta.RSI.Value+tb.RSI.Value-100) > 1e-8 {
			t.Fatal("RSI鏡像")
		}
		if ta.Histogram.Known && math.Abs(ta.Histogram.Value+tb.Histogram.Value) > 1e-8 {
			t.Fatal("Hist鏡像")
		}
	}
	if e := g.StartSession(Session{ID: "次場", Contract: "同限月", Start: 114000, End: 117000}, true); e != nil {
		t.Fatal(e)
	}
	_, _ = g.Observe(observation(114000, 1000, 1, 0))
	ps, e := g.Observe(observation(114300, 1001, 2, 1))
	if e != nil || len(ps) != 1 || !ps[0].Frame.Frame.Technical.EMA21.Known {
		t.Fatal("Raw助走が継承されない", e)
	}
	if e = g.StartSession(Session{ID: "別限月", Contract: "新限月", Start: 118200, End: 121200}, true); e != nil {
		t.Fatal(e)
	}
	_, _ = g.Observe(observation(118200, 1000, 1, 0))
	ps, e = g.Observe(observation(118500, 1001, 2, 1))
	if e != nil || len(ps) != 1 || ps[0].Frame.Frame.Technical.EMA8.Known {
		t.Fatal("限月でcoldにならない", e)
	}
}

// TestUnlocatedClockAndTerminal は未形成の時計欠測を足へ割り当てず、場末尾等号を最終足へ含めます。
//
// 引数: t(*testing.T)。返り値: なし。
func TestUnlocatedClockAndTerminal(t *testing.T) {
	g, e := New(Config{MaxGapSeconds: 300})
	if e != nil {
		t.Fatal(e)
	}
	if e = g.StartSession(Session{ID: "人工", Contract: "同限月", Start: 100200, End: 100800}, false); e != nil {
		t.Fatal(e)
	}
	g.RejectClock("開始前か不明の時計欠測")
	_, _ = g.Observe(observation(100200, 1000, 1, 0))
	ps, e := g.Observe(observation(100500, 1005, 2, 1))
	if e != nil || len(ps) != 1 || !ps[0].Frame.Frame.PriceKnown {
		t.Fatal(e, ps)
	}
	ps, e = g.Observe(observation(100800, 1010, 3, 2))
	if e != nil || len(ps) != 1 || ps[0].Frame.Frame.OHLC.Close != 1010 || g.Stats().TerminalUnclosed {
		t.Fatal(e, ps, g.Stats())
	}
	if g.Stats().UnlocatedClocks != 1 {
		t.Fatal(g.Stats())
	}
}
