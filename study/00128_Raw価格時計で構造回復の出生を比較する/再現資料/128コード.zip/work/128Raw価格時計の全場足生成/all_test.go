package rawpricebars

import (
	"compress/gzip"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
	"time"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	old "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
)

// fixture は人工Rawだけを一時フォルダへ作り、独立に件数を定義します。
//
// 引数: t(*testing.T)、folder/contract(string)、n/bars(int)、start(float64)。返り値: Sceneです。
func fixture(t *testing.T, folder, contract string, n, bars int, start float64) Scene {
	t.Helper()
	lines := []string{}
	for i := 0; i <= bars; i++ {
		at := start + float64(i*300)
		stamp := time.Unix(int64(at), 0).UTC().Format(time.RFC3339Nano)
		price := 1000 + float64((i*13+n*7)%101)
		row := map[string]any{"Symbol": contract, "CurrentPriceTime": stamp, "CurrentPrice": price, "TradingVolumeTime": stamp, "TradingVolume": i}
		for depth := 1; depth <= 10; depth++ {
			row[fmt.Sprintf("Buy%d", depth)] = map[string]any{"Price": price - 5, "Qty": 1}
			row[fmt.Sprintf("Sell%d", depth)] = map[string]any{"Price": price + 5, "Qty": 1}
		}
		data, e := json.Marshal(row)
		if e != nil {
			t.Fatal(e)
		}
		lines = append(lines, string(data))
	}
	body := []byte(strings.Join(lines, "\n") + "\n")
	path := filepath.Join(folder, fmt.Sprintf("人工_%02d.jsonl", n))
	if e := os.WriteFile(path, body, 0600); e != nil {
		t.Fatal(e)
	}
	suffix := "Day"
	if n%2 == 1 {
		suffix = "Night"
	}
	count := int64(bars + 1)
	return Scene{Session: fmt.Sprintf("人工_%02d_%s", n, suffix), Contract: contract, Start: start, End: start + float64(bars*300), ForceClose: start + float64(bars*300), Raw: old.FileRef{Path: path, SHA256: hashBytes(body), Bytes: int64(len(body))}, ExpectedAccepted: count, ExpectedQuality: &Counts{Lines: count, Accepted: count, Delivered: count}}
}

// readGenerated は人工出力gzipを読み、圧縮/解凍指紋を独立照合します。
//
// 引数: t(*testing.T)、folder(string)、artifact(Artifact)。返り値: []GeneratedSceneです。
func readGenerated(t *testing.T, folder string, artifact Artifact) []GeneratedScene {
	t.Helper()
	body, e := os.ReadFile(filepath.Join(folder, artifact.Path))
	if e != nil {
		t.Fatal(e)
	}
	if hashBytes(body) != artifact.SHA {
		t.Fatal("gzip SHA差")
	}
	f, e := os.Open(filepath.Join(folder, artifact.Path))
	if e != nil {
		t.Fatal(e)
	}
	defer f.Close()
	z, e := gzip.NewReader(f)
	if e != nil {
		t.Fatal(e)
	}
	defer z.Close()
	decoded, e := io.ReadAll(z)
	if e != nil {
		t.Fatal(e)
	}
	if hashBytes(decoded) != artifact.DecodedSHA {
		t.Fatal("解凍SHA差")
	}
	var value struct {
		Success bool             `json:"success"`
		Scenes  []GeneratedScene `json:"scenes"`
	}
	if e = json.Unmarshal(decoded, &value); e != nil {
		t.Fatal(e)
	}
	if !value.Success {
		t.Fatal("成功フラグなし")
	}
	return value.Scenes
}

// TestMetadataIgnoresCSVAndRequiresQuality は旧完成公表を足生成へ混入させないことを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestMetadataIgnoresCSVAndRequiresQuality(t *testing.T) {
	s := fixture(t, t.TempDir(), "A", 0, 6, 100200)
	base := map[string]any{"session": s.Session, "contract": s.Contract, "start": s.Start, "end": s.End, "force_close": s.ForceClose, "raw": s.Raw, "expected_accepted": s.ExpectedAccepted, "expected_quality": s.ExpectedQuality, "publications": []any{map[string]any{"future_price": 999999}}}
	a, _ := json.Marshal(map[string]any{"scenes": []any{base}})
	x, e := DecodeMetadata(a)
	if e != nil {
		t.Fatal(e)
	}
	base["publications"] = []any{map[string]any{"future_price": 1}}
	b, _ := json.Marshal(map[string]any{"scenes": []any{base}})
	y, e := DecodeMetadata(b)
	if e != nil || !reflect.DeepEqual(x, y) {
		t.Fatal("CSV完成値がmetadataへ混入")
	}
	delete(base, "expected_quality")
	c, _ := json.Marshal(map[string]any{"scenes": []any{base}})
	if _, e = DecodeMetadata(c); e == nil {
		t.Fatal("品質欠落を許可")
	}
	if e = ValidatePlan(x, true); e == nil {
		t.Fatal("2場以下を自然全73として許可")
	}
}

// TestDelayedCopyAndEOF は完成値同体・別Bank・最初の適格Raw・EOF落ちを検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestDelayedCopyAndEOF(t *testing.T) {
	scene := Scene{Session: "人工_Day", Contract: "A", Start: 100200, End: 100800}
	g, e := New(Config{MaxGapSeconds: 300})
	if e != nil {
		t.Fatal(e)
	}
	if e = g.StartSession(Session{ID: scene.Session, Contract: scene.Contract, Start: scene.Start, End: scene.End}, false); e != nil {
		t.Fatal(e)
	}
	lag := newDelay()
	if e = lag.start(scene, false); e != nil {
		t.Fatal(e)
	}
	observations := []Observation{observation(100200, 1000, 0, 0), observation(100499, 1010, 1, 1), observation(100500, 1020, 2, 2), observation(100530, 1030, 3, 3), observation(100560, 1025, 4, 4), observation(100800, 1040, 5, 5)}
	var immediate Publication
	delivered := 0
	for _, o := range observations {
		pubs, e := g.Observe(o)
		if e != nil {
			t.Fatal(e)
		}
		if len(pubs) > 0 && pubs[0].Frame.Frame.End == 100500 {
			immediate = pubs[0]
		}
		released, e := lag.release(pubs, o.Quote)
		if e != nil {
			t.Fatal(e)
		}
		if o.Quote.Time == 100530 {
			snap, e := lag.bank.Current(rules.Quote{Time: o.Quote.Time, Index: int(o.Quote.Index), Line: int(o.Quote.SourceLine), Last: o.Quote.Last})
			if e != nil {
				t.Fatal(e)
			}
			if len(snap.Frames) > 0 {
				t.Fatal("遅延前のBankへ未来公表")
			}
		}
		for _, p := range released {
			delivered++
			if p.Stamp.Time != 100560 || p.Frame.Frame.AvailableAt != 100560 || p.Frame.Frame.DeliveryAt != 100560 || p.ClosedAt == nil || *p.ClosedAt != immediate.Stamp {
				t.Fatal("遅延時計差")
			}
			p.Stamp = immediate.Stamp
			p.Frame.Frame.NominalAvailable = immediate.Frame.Frame.NominalAvailable
			p.Frame.Frame.AvailableAt = immediate.Frame.Frame.AvailableAt
			p.Frame.Frame.DeliveryAt = immediate.Frame.Frame.DeliveryAt
			p.Frame.Frame.RecordOrdinal = immediate.Frame.Frame.RecordOrdinal
			p.Model = immediate.Model
			p.ClosedAt = nil
			if !reflect.DeepEqual(p, immediate) {
				t.Fatal("時計以外の完成値が変化")
			}
		}
	}
	dropped := lag.eof()
	if delivered != 1 || len(dropped) != 1 || dropped[0].End != 100800 || len(lag.queue) != 0 {
		t.Fatal("EOFで架空配送又は次場queue持越し")
	}
}

// TestAll73SequentialCarryAndCold は全73・3gzip・carry/限月cold・逐次出力を人工検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestAll73SequentialCarryAndCold(t *testing.T) {
	folder := t.TempDir()
	plan := []Scene{}
	for i := 0; i < 73; i++ {
		contract := "B"
		if i < 2 {
			contract = "A"
		}
		plan = append(plan, fixture(t, folder, contract, i, 24, 100200+float64(i*10800)))
	}
	output := filepath.Join(folder, "validated")
	plan[0].Raw.Bytes = 0
	summary, e := RunAll(plan, CarryValidated, "人工Input", output)
	if e != nil {
		t.Fatal(e)
	}
	if !summary.Success || summary.RawPasses != 73 || len(summary.Artifacts) != 3 {
		t.Fatal("全73一走査差")
	}
	scenes := readGenerated(t, output, summary.Artifacts[0])
	if len(scenes) != 73 || scenes[0].CarryFrom != "" || scenes[1].CarryFrom != plan[0].Session || scenes[2].CarryFrom != "" || scenes[3].CarryFrom != plan[2].Session {
		t.Fatal("連続同限月carry条件差")
	}
	if !scenes[1].Publications[0].Frame.Frame.Technical.PreviousEMA21.Known || scenes[2].Publications[0].Frame.Frame.Technical.PreviousEMA21.Known {
		t.Fatal("numeric継承/限月reset差")
	}
	if scenes[0].Publications[0].Frame.Frame.Children[0].Input.Bytes <= 0 {
		t.Fatal("元metadataのbytes省略時に実Raw statの由来が欠落")
	}
	for _, artifact := range summary.Artifacts {
		if len(readGenerated(t, output, artifact)) != 73 {
			t.Fatal("モデル別場数差")
		}
	}
	coldOut := filepath.Join(folder, "cold")
	cold, e := runPlan(plan[:2], CarryCold, "人工Input", coldOut, false)
	if e != nil {
		t.Fatal(e)
	}
	cs := readGenerated(t, coldOut, cold.Artifacts[0])
	if cs[1].CarryFrom != "" || cs[1].Publications[0].Frame.Frame.Technical.PreviousEMA21.Known {
		t.Fatal("cold-eachに前場numeric混入")
	}
	if _, e = runPlan(plan[:2], "", "人工Input", filepath.Join(folder, "no-policy"), false); e == nil {
		t.Fatal("carry未指定を許可")
	}
}

// TestQualityFailureStopsBeforeNext は失敗場の状態を次場へcarryせず成功名も生成しないことを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestQualityFailureStopsBeforeNext(t *testing.T) {
	folder := t.TempDir()
	a := fixture(t, folder, "A", 0, 6, 100200)
	b := fixture(t, folder, "A", 1, 6, 103800)
	a.ExpectedQuality.BadBBO = 1
	b.Raw.Path = filepath.Join(folder, "次場は開いてはいけない.jsonl")
	output := filepath.Join(folder, "failed")
	summary, e := runPlan([]Scene{a, b}, CarryValidated, "人工Input", output, false)
	if e == nil || !strings.Contains(e.Error(), "11品質") || summary.RawPasses != 0 || len(summary.Scenes) != 0 {
		t.Fatal("品質失敗後に次場へ進んだ")
	}
	if _, e = os.Stat(filepath.Join(output, "gap300.json.gz")); !os.IsNotExist(e) {
		t.Fatal("失敗を成功名へ公開")
	}
}
