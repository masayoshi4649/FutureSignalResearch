package rawpricebars

import (
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	old "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
	ext "github.com/masayoshi4649/SessionTradeExecuter/threeframe115"
)

type Config struct {
	MaxGapSeconds float64 `json:"max_gap_seconds"`
}
type Session struct {
	ID       string      `json:"session"`
	Contract string      `json:"contract"`
	Start    float64     `json:"start"`
	End      float64     `json:"end"`
	Input    old.FileRef `json:"raw_input"`
}
type Counts struct {
	Lines           int64 `json:"lines"`
	ClockMissing    int64 `json:"clock_missing"`
	ClockInvalid    int64 `json:"clock_invalid"`
	Outside         int64 `json:"outside_session"`
	Backward        int64 `json:"backward_clock"`
	LastNonPositive int64 `json:"last_non_positive"`
	LastNonFinite   int64 `json:"last_non_finite"`
	BadBBO          int64 `json:"bad_bbo"`
	Accepted        int64 `json:"source_parser_accepted"`
	CutoffExcluded  int64 `json:"cutoff_excluded"`
	Delivered       int64 `json:"source_delivered"`
}
type Scene struct {
	Session          string      `json:"session"`
	Contract         string      `json:"contract"`
	Start            float64     `json:"start"`
	End              float64     `json:"end"`
	Cutoff           float64     `json:"cutoff"`
	ForceClose       float64     `json:"force_close"`
	Raw              old.FileRef `json:"raw"`
	ExpectedAccepted int64       `json:"expected_accepted"`
	ExpectedQuality  *Counts     `json:"expected_quality"`
}
type Quote struct {
	Clock      string  `json:"clock"`
	Time       float64 `json:"time"`
	Index      int64   `json:"index"`
	SourceLine int64   `json:"source_line"`
	Last       float64 `json:"last"`
	Bid        float64 `json:"bid"`
	Ask        float64 `json:"ask"`
	QuoteOK    bool    `json:"quote_ok"`
}
type Observation struct {
	Quote      Quote    `json:"quote"`
	Volume     *float64 `json:"volume"`
	VolumeTime *float64 `json:"volume_time"`
}
type Quality struct {
	Rows    int      `json:"rows"`
	Reasons []string `json:"reasons"`
	First   *Quote   `json:"first"`
	Last    *Quote   `json:"last"`
}
type Publication struct {
	Stamp    rules.Stamp  `json:"stamp"`
	Frame    ext.Frame    `json:"frame"`
	Quality  Quality      `json:"raw_quality"`
	Model    string       `json:"model"`
	ClosedAt *rules.Stamp `json:"causal_close_stamp,omitempty"`
}
type Stats struct {
	Accepted         int  `json:"accepted"`
	GapOverLimit     int  `json:"gap_over_limit"`
	GapOver60        int  `json:"gap_over_60"`
	RejectedClocks   int  `json:"rejected_clocks"`
	UnlocatedClocks  int  `json:"clock_reject_before_first_price"`
	VolumeReset      int  `json:"volume_reset"`
	VolumeUnknown    int  `json:"volume_unknown"`
	Empty5           int  `json:"empty_5"`
	Unknown5         int  `json:"unknown_5"`
	Publications     int  `json:"publications"`
	TerminalUnclosed bool `json:"terminal_unclosed"`
}
type bar struct {
	Start       float64
	OHLC        old.OHLC
	Volume      float64
	Has         bool
	VolumeKnown bool
	Bad         bool
	Quality     Quality
}
