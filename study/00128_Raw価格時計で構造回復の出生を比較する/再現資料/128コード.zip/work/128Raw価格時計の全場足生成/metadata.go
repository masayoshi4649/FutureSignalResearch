package rawpricebars

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"strings"

	old "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
)

const FixedInputSHA = "6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec"
const CarryValidated = "validated-same-contract"
const CarryCold = "cold-each"

var qualityKeys = []string{"lines", "clock_missing", "clock_invalid", "outside_session", "backward_clock", "last_non_positive", "last_non_finite", "bad_bbo", "source_parser_accepted", "cutoff_excluded", "source_delivered"}

// hashBytes は、与えたバイト列のSHA256を返します。
//
// 引数: data([]byte)。返り値: stringです。
func hashBytes(data []byte) string { v := sha256.Sum256(data); return hex.EncodeToString(v[:]) }

// DecodeMetadata はscene/Raw参照/11品質だけを読み、旧公表やCSV値を型へ持ちません。
//
// 引数: data([]byte)はInput JSON。返り値: []Scene/errorです。
func DecodeMetadata(data []byte) ([]Scene, error) {
	type meta struct {
		Session  string          `json:"session"`
		Contract string          `json:"contract"`
		Start    float64         `json:"start"`
		End      float64         `json:"end"`
		Force    float64         `json:"force_close"`
		Raw      old.FileRef     `json:"raw"`
		Accepted int64           `json:"expected_accepted"`
		Quality  json.RawMessage `json:"expected_quality"`
	}
	var input struct {
		Scenes []meta `json:"scenes"`
	}
	if err := json.Unmarshal(data, &input); err != nil {
		return nil, err
	}
	scenes := []Scene{}
	for _, m := range input.Scenes {
		var values map[string]int64
		if len(m.Quality) == 0 {
			return nil, fmt.Errorf("品質必須:%s", m.Session)
		}
		if err := json.Unmarshal(m.Quality, &values); err != nil {
			return nil, err
		}
		if len(values) != len(qualityKeys) {
			return nil, fmt.Errorf("品質11項目が必要:%s", m.Session)
		}
		for _, key := range qualityKeys {
			v, ok := values[key]
			if !ok || v < 0 {
				return nil, fmt.Errorf("品質field不足/負:%s/%s", m.Session, key)
			}
		}
		quality := &Counts{}
		if err := json.Unmarshal(m.Quality, quality); err != nil {
			return nil, err
		}
		scenes = append(scenes, Scene{Session: m.Session, Contract: m.Contract, Start: m.Start, End: m.End, ForceClose: m.Force, Raw: m.Raw, ExpectedAccepted: m.Accepted, ExpectedQuality: quality})
	}
	return scenes, nil
}

// ValidatePlan は重複・順序・品質・限月参照と全73場を自然走査前に検査します。
//
// 引数: scenes([]Scene)、all73(bool)。返り値: errorです。人工ではall73=falseも使います。
func ValidatePlan(scenes []Scene, all73 bool) error {
	if len(scenes) == 0 || all73 && len(scenes) != 73 {
		return fmt.Errorf("全73場計画が必要")
	}
	ids := map[string]bool{}
	paths := map[string]bool{}
	days, nights := 0, 0
	for i, s := range scenes {
		if s.Session == "" || s.Contract == "" || ids[s.Session] || paths[s.Raw.Path] || s.Raw.Path == "" || len(s.Raw.SHA256) != 64 || s.Raw.Bytes < 0 || !finite(s.Start, s.End, s.ForceClose) || s.End <= s.Start || s.ForceClose <= s.Start || s.ForceClose > s.End || math.Mod(s.Start, 300) != 0 || math.Mod(s.End-s.Start, 300) != 0 || s.Cutoff != 0 {
			return fmt.Errorf("場/時計/原板参照差:%s", s.Session)
		}
		if _, err := hex.DecodeString(s.Raw.SHA256); err != nil {
			return err
		}
		if s.ExpectedQuality == nil {
			return fmt.Errorf("品質必須:%s", s.Session)
		}
		q := s.ExpectedQuality
		for _, v := range []int64{q.Lines, q.ClockMissing, q.ClockInvalid, q.Outside, q.Backward, q.LastNonPositive, q.LastNonFinite, q.BadBBO, q.Accepted, q.CutoffExcluded, q.Delivered} {
			if v < 0 {
				return fmt.Errorf("負の品質:%s", s.Session)
			}
		}
		if s.ExpectedAccepted <= 0 || q.Accepted != s.ExpectedAccepted || q.Delivered != q.Accepted || q.CutoffExcluded != 0 || q.BadBBO > q.Accepted || q.Lines != q.Accepted+q.ClockMissing+q.ClockInvalid+q.Outside+q.Backward+q.LastNonPositive+q.LastNonFinite {
			return fmt.Errorf("品質算術差:%s", s.Session)
		}
		if i > 0 && (s.Start <= scenes[i-1].Start || s.Start < scenes[i-1].End) {
			return fmt.Errorf("場順序/重複差")
		}
		if strings.HasSuffix(s.Session, "_Day") {
			days++
		}
		if strings.HasSuffix(s.Session, "_Night") {
			nights++
		}
		ids[s.Session] = true
		paths[s.Raw.Path] = true
	}
	if all73 && (days != 37 || nights != 36) {
		return fmt.Errorf("Day37/Night36の計画差")
	}
	return nil
}

// LoadMetadata は固定Inputを検証しますが、publicationsの値を生成器へ渡しません。
//
// 引数: path/expected(string)。返り値: []Scene/errorです。Rawは読みません。
func LoadMetadata(path, expected string) ([]Scene, error) {
	if expected != FixedInputSHA {
		return nil, fmt.Errorf("固定Input SHA指定差")
	}
	before, err := os.Stat(path)
	if err != nil {
		return nil, err
	}
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	if hashBytes(data) != expected {
		return nil, fmt.Errorf("Input SHA差")
	}
	scenes, err := DecodeMetadata(data)
	if err != nil {
		return nil, err
	}
	if err = ValidatePlan(scenes, true); err != nil {
		return nil, err
	}
	after, err := os.Stat(path)
	if err != nil {
		return nil, err
	}
	if before.Size() != after.Size() || !before.ModTime().Equal(after.ModTime()) || !os.SameFile(before, after) {
		return nil, fmt.Errorf("Input stat前後差")
	}
	return scenes, nil
}
