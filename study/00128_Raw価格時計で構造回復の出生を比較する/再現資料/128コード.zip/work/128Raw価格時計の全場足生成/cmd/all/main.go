package main

import (
	"flag"
	"fmt"
	"os"
	raw "rawpricebars128"
)

// main は明示carryと全場実行指定が揃った時だけ自然Raw走査を開始します。
//
// 引数: input/sha256/output/carry(string)、execute-all(bool)。返り値: ありません。
func main() {
	input := flag.String("input", "", "固定122 metadata Input")
	sha := flag.String("sha256", "", "Input SHA256")
	output := flag.String("output", "", "新規出力フォルダ")
	carry := flag.String("carry", "", "validated-same-contract 又はcold-each")
	execute := flag.Bool("execute-all", false, "全73場の非金融足生成を明示実行")
	flag.Parse()
	if !*execute || *input == "" || *output == "" || (*carry != raw.CarryValidated && *carry != raw.CarryCold) {
		fmt.Fprintln(os.Stderr, "--execute-all/--input/--output/--carryの明示が必要。まだRawを読んでいません。")
		os.Exit(2)
	}
	scenes, e := raw.LoadMetadata(*input, *sha)
	if e != nil {
		panic(e)
	}
	result, e := raw.RunAll(scenes, *carry, *sha, *output)
	if e != nil {
		panic(e)
	}
	fmt.Printf("成功=%v 全場=%d Raw走査=%d 出力モデル=%d 金融ラベル=false\n", result.Success, len(result.Scenes), result.RawPasses, len(result.Artifacts))
}
