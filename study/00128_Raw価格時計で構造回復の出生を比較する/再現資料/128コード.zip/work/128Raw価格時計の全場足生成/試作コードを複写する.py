"""確定済み2場試作の小型ソースだけを別モジュールへ複写する。原板/結果未読。"""
from pathlib import Path
import hashlib
import json

OWN=Path(__file__).resolve().parent
SOURCE=OWN.parent/'Raw価格時計の足生成'


def sha(data: bytes) -> str:
    """
    機能: バイト列のSHA256を返す。
    引数: data(bytes)。返り値: str。
    """
    return hashlib.sha256(data).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 数値本体とgenerator/decoder/testsを新しい場所へ可逆に複写する。
    引数: なし。返り値: None。exe/7MB結果/Raw/177MB入力を開かない。
    """
    relative=['decoder.go','generator.go','generator_test.go','types.go','go.mod']
    relative.extend(str(p.relative_to(SOURCE)).replace('\\','/') for p in (SOURCE/'internal').rglob('*.go'))
    entries=[]
    for name in sorted(relative):
        source=SOURCE/name;target=OWN/name;data=source.read_bytes();copied=data
        if name=='go.mod': copied=data.replace(b'module rawpricebars\n',b'module rawpricebars128\n')
        if name=='generator.go': copied=data.replace(b'"rawpricebars/internal/',b'"rawpricebars128/internal/')
        target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as stream:stream.write(copied)
        entries.append({'path':name,'元SHA256':sha(data),'複写SHA256':sha(copied),'bytes':len(copied),'差':'module名/internal importだけ' if copied!=data else '全bytes同体'})
    result={'成功':True,'用途':'128の全場Raw足生成準備','原板読取':False,'入力読取':False,'金融ラベル読取':False,'exe/結果複写':False,
            '元試作コード':str(SOURCE),'entries':entries,'旧reader/cmd/sample':'2場限定/CSVパリティ部分はコピーせず、metadata専用全場reader/CLIを新規作成する。'}
    with (OWN/'試作コードの複写.json').open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'成功':True,'小型ソース数':len(entries),'合計bytes':sum(e['bytes'] for e in entries)},ensure_ascii=False))


if __name__=='__main__':
    main()
