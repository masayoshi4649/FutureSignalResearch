package rawpricebars

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"sort"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	old "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
	"rawpricebars128/internal/basenumeric"
	"rawpricebars128/internal/dminumeric"
)

type Generator struct {
	config     Config
	session    Session
	started    bool
	last       *Quote
	active     bar
	nextEnd    float64
	volume     *float64
	volumeTime *float64
	children   map[float64]Publication
	numeric    [3]basenumeric.State
	dmi        [3]dminumeric.State
	bank       *rules.Bank
	stats      Stats
}

// finite は有限値を判定します。
//
// 引数: xs(...float64)は検査対象。返り値: boolは全て有限なら真。
func finite(xs ...float64) bool {
	for _, x := range xs {
		if math.IsNaN(x) || math.IsInf(x, 0) {
			return false
		}
	}
	return true
}

// New はgap閾値を明示した空のRaw足生成器を作ります。
//
// 引数: config(Config)は正の最大価格時計差。返り値: *Generator/errorは生成器又は設定拒否。
func New(config Config) (*Generator, error) {
	if !finite(config.MaxGapSeconds) || config.MaxGapSeconds <= 0 {
		return nil, fmt.Errorf("正のgap閾値が必要")
	}
	return &Generator{config: config, bank: rules.NewBank()}, nil
}

// StartSession はRaw由来の数値だけを指定により継承します。
//
// 引数: session(Session)、carry(bool)は場と同限月Raw数値の継承。返り値: errorは場の重複/逆転等。
func (g *Generator) StartSession(session Session, carry bool) error {
	if session.ID == "" || session.Contract == "" || !finite(session.Start, session.End) || session.End <= session.Start || math.Mod(session.Start, 300) != 0 || math.Mod(session.End-session.Start, 300) != 0 {
		return fmt.Errorf("場の識別/時計/5分格子が不正")
	}
	if g.started && (session.Start <= g.session.Start || session.Start < g.session.End) {
		return fmt.Errorf("場が重複又は逆転")
	}
	carry = carry && g.started && session.Contract == g.session.Contract
	for i := range g.numeric {
		g.numeric[i].StartSession(carry)
		g.dmi[i].StartSession(carry)
	}
	if !carry {
		g.bank = rules.NewBank()
	}
	if err := g.bank.StartSession(session.ID, session.Contract); err != nil {
		return err
	}
	g.session, g.started = session, true
	g.last, g.volume, g.volumeTime = nil, nil, nil
	g.active = bar{Start: session.Start, VolumeKnown: true}
	g.nextEnd, g.children, g.stats = session.Start+300, map[float64]Publication{}, Stats{}
	return nil
}

// reason は現在形成中の足へ重複しない品質理由を加えます。
//
// 引数: b(*bar)、text(string)は足と理由。返り値: なし。
func reason(b *bar, text string) {
	for _, x := range b.Quality.Reasons {
		if x == text {
			return
		}
	}
	b.Quality.Reasons = append(b.Quality.Reasons, text)
}

// RejectClock は破棄された時計行を現在足の未知へ反映します。
//
// 引数: text(string)は無効/後退の理由。返り値: なし。既公表足を訂正しません。
func (g *Generator) RejectClock(text string) {
	g.stats.RejectedClocks++
	if g.started && g.last != nil {
		g.active.Bad, g.active.VolumeKnown = true, false
		reason(&g.active, text)
	} else if g.started {
		g.stats.UnlocatedClocks++
	}
	g.volume, g.volumeTime = nil, nil
}

// add は当時の価格と観測累積増分を現在の足へ加えます。
//
// 引数: o(Observation)は現在Rawの価格/数量。返り値: なし。
func (g *Generator) add(o Observation) {
	q := o.Quote
	b := &g.active
	if !b.Has {
		b.OHLC = old.OHLC{Open: q.Last, High: q.Last, Low: q.Last, Close: q.Last}
		x := q
		b.Quality.First = &x
	}
	b.Has = true
	b.OHLC.High, b.OHLC.Low, b.OHLC.Close = math.Max(b.OHLC.High, q.Last), math.Min(b.OHLC.Low, q.Last), q.Last
	b.Quality.Rows++
	x := q
	b.Quality.Last = &x
	if o.Volume == nil || o.VolumeTime == nil || !finite(*o.Volume, *o.VolumeTime) || *o.Volume < 0 || *o.VolumeTime > q.Time {
		b.VolumeKnown = false
		reason(b, "数量又は数量時計が未知/先行")
		g.volume, g.volumeTime = nil, nil
		g.stats.VolumeUnknown++
		return
	}
	if g.volume == nil || *o.Volume < *g.volume || *o.VolumeTime < *g.volumeTime {
		b.VolumeKnown = false
		reason(b, "数量初回基準又は減少/後退reset")
		g.stats.VolumeReset++
	} else {
		sum := b.Volume + *o.Volume - *g.volume
		if !finite(sum) {
			b.VolumeKnown = false
			reason(b, "数量和の非有限")
			g.volume, g.volumeTime = nil, nil
			g.stats.VolumeUnknown++
			return
		}
		b.Volume = sum
	}
	v, t := *o.Volume, *o.VolumeTime
	g.volume, g.volumeTime = &v, &t
}

// digest は因果的に判明した足内容だけを識別子へ結びます。
//
// 引数: value(any)は足と当時出典。返り値: string/errorはSHA又は非有限値等。
func digest(value any) (string, error) {
	b, err := json.Marshal(value)
	if err != nil {
		return "", err
	}
	x := sha256.Sum256(b)
	return hex.EncodeToString(x[:]), nil
}

// convert は既存118の公開型へ値と既知性をJSON定義通りに接続します。
//
// 引数: p(Publication)は旧115の型を用いる新公表。返り値: rules.Publication/error。
func convert(p Publication) (rules.Publication, error) {
	b, err := json.Marshal(p)
	if err != nil {
		return rules.Publication{}, err
	}
	var v rules.Publication
	err = json.Unmarshal(b, &v)
	return v, err
}

// emit は数値本体と118のBB/RVOLを更新して確定値を公表します。
//
// 引数: f(old.Frame)、quality(Quality)、q(Quote)は閉鎖足/品質/閉鎖確認行。返り値: Publication/error。
func (g *Generator) emit(f old.Frame, quality Quality, q Quote) (Publication, error) {
	i := 0
	if f.WidthSeconds == 900 {
		i = 1
	} else if f.WidthSeconds == 1800 {
		i = 2
	}
	f.SessionID, f.Contract = g.session.ID, g.session.Contract
	f.NominalAvailable, f.AvailableAt, f.ObservedAt, f.DeliveryAt = f.End, f.End, q.Time, q.Time
	f.RecordOrdinal, f.PublicationOrdinal = uint64(q.Index+1), uint64(g.stats.Publications+1)
	sort.Strings(quality.Reasons)
	id, err := digest(struct {
		Session, Contract       string
		Width                   int
		Start, End              float64
		OHLC                    old.OHLC
		Volume                  float64
		PriceKnown, VolumeKnown bool
		Quality                 Quality
	}{
		g.session.ID, g.session.Contract, f.WidthSeconds, f.Start, f.End, f.OHLC, f.Volume, f.PriceKnown, f.VolumeKnown, quality})
	if err != nil {
		return Publication{}, err
	}
	f.ID = "raw-price-clock:" + id
	f.ChildrenSHA256, err = digest(f.Children)
	if err != nil {
		return Publication{}, err
	}
	f, err = g.numeric[i].Apply(f)
	if err != nil {
		return Publication{}, err
	}
	x, err := g.dmi[i].Apply(f)
	if err != nil {
		return Publication{}, err
	}
	p := Publication{Stamp: rules.Stamp{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine)}, Frame: x, Quality: quality, Model: "Raw価格時計の閉鎖足・受信時計ではない"}
	v, err := convert(p)
	if err != nil {
		return Publication{}, err
	}
	if err = g.bank.Add(v); err != nil {
		return Publication{}, err
	}
	g.stats.Publications++
	return p, nil
}

// closeFive は5分と同じ足終の15/30分をこの順で確定します。
//
// 引数: q(Quote)は最初の後続Raw、gap(bool)は閾値超過。返り値: []Publication/error。
func (g *Generator) closeFive(q Quote, gap bool) ([]Publication, error) {
	b, end := g.active, g.nextEnd
	if gap && g.last != nil && math.Max(g.last.Time, b.Start) < math.Min(q.Time, end) {
		b.Bad, b.VolumeKnown = true, false
		reason(&b, "価格時計のgapが閾値超過")
	}
	if !b.Has {
		b.Bad, b.VolumeKnown = true, false
		reason(&b, "無価格の空5分")
		g.stats.Empty5++
	}
	if b.Bad {
		g.stats.Unknown5++
	}
	f := old.Frame{WidthSeconds: 300, Start: b.Start, End: end, OHLC: b.OHLC, Volume: b.Volume,
		PriceKnown: b.Has && !b.Bad, VolumeKnown: b.Has && b.VolumeKnown, ChildCount: 1}
	childID, err := digest(b)
	if err != nil {
		return nil, err
	}
	firstLine := uint64(0)
	if b.Quality.First != nil {
		firstLine = uint64(b.Quality.First.SourceLine)
	}
	f.Children[0] = old.ChildRef{ID: "raw-child:" + childID, Start: b.Start, End: end, Present: b.Has,
		PriceKnown: f.PriceKnown, VolumeKnown: f.VolumeKnown, Input: g.session.Input, Row: firstLine}
	f.Reason = "Raw観測価格/数量proxy"
	if b.Bad {
		f.Reason = "Raw品質不足"
	}
	p, err := g.emit(f, b.Quality, q)
	if err != nil {
		return nil, err
	}
	g.children[b.Start] = p
	result := []Publication{p}
	for _, width := range []int{900, 1800} {
		if math.Mod(end-g.session.Start, float64(width)) != 0 {
			continue
		}
		parent := old.Frame{WidthSeconds: width, Start: end - float64(width), End: end, PriceKnown: true, VolumeKnown: true, ChildCount: width / 300, Reason: "Raw子5分の集約"}
		quality := Quality{}
		for j := 0; j < parent.ChildCount; j++ {
			child := g.children[parent.Start+float64(j*300)]
			x := child.Frame.Frame
			parent.Children[j] = old.ChildRef{ID: x.ID, Start: x.Start, End: x.End, Present: true, PriceKnown: x.PriceKnown, VolumeKnown: x.VolumeKnown}
			if j == 0 {
				parent.OHLC = x.OHLC
			} else {
				parent.OHLC.High = math.Max(parent.OHLC.High, x.OHLC.High)
				parent.OHLC.Low = math.Min(parent.OHLC.Low, x.OHLC.Low)
				parent.OHLC.Close = x.OHLC.Close
			}
			parent.PriceKnown = parent.PriceKnown && x.PriceKnown
			parent.VolumeKnown = parent.VolumeKnown && x.VolumeKnown
			parent.Volume += x.Volume
			quality.Rows += child.Quality.Rows
			quality.Reasons = append(quality.Reasons, child.Quality.Reasons...)
			if quality.First == nil && child.Quality.First != nil {
				quality.First = child.Quality.First
			}
			if child.Quality.Last != nil {
				quality.Last = child.Quality.Last
			}
		}
		pub, e := g.emit(parent, quality, q)
		if e != nil {
			return nil, e
		}
		result = append(result, pub)
	}
	for start := range g.children {
		if start < end-1800 {
			delete(g.children, start)
		}
	}
	g.nextEnd += 300
	g.active = bar{Start: end, VolumeKnown: true}
	return result, nil
}

// Observe はRaw価格時計が足終へ到達した時だけ前足を閉じます。
//
// 引数: o(Observation)は既採用Raw順の現在値。返り値: []Publication/error。EOFで未来タイマーを進めません。
func (g *Generator) Observe(o Observation) ([]Publication, error) {
	q := o.Quote
	if !g.started || !finite(q.Time, q.Last) || q.Last <= 0 || q.Index < 0 || q.SourceLine < 1 || q.Time < g.session.Start || q.Time > g.session.End {
		return nil, fmt.Errorf("採用Raw時計/価格/場が不正")
	}
	if g.last != nil && (q.Time < g.last.Time || q.Index <= g.last.Index || q.SourceLine <= g.last.SourceLine) {
		return nil, fmt.Errorf("既採用Rawの原順が不正")
	}
	gap := g.last == nil && q.Time-g.session.Start > g.config.MaxGapSeconds
	if gap {
		g.stats.GapOverLimit++
	}
	if g.last != nil {
		if q.Time-g.last.Time > 60 {
			g.stats.GapOver60++
		}
		gap = q.Time-g.last.Time > g.config.MaxGapSeconds
		if gap {
			g.stats.GapOverLimit++
			g.volume, g.volumeTime = nil, nil
		}
	}
	result := []Publication{}
	terminal := q.Time == g.session.End
	for g.nextEnd <= q.Time && g.nextEnd <= g.session.End {
		if terminal && g.nextEnd == g.session.End {
			g.add(o)
		}
		pubs, err := g.closeFive(q, gap)
		if err != nil {
			return nil, err
		}
		result = append(result, pubs...)
	}
	if !terminal {
		if gap && q.Time > g.active.Start {
			g.active.Bad, g.active.VolumeKnown = true, false
			reason(&g.active, "価格時計gap直後の部分足")
		}
		g.add(o)
	}
	x := q
	g.last = &x
	g.stats.Accepted++
	return result, nil
}

// Current は既存118と同じfresh規則でBB/RVOLを含む当時Snapshotを返します。
//
// 引数: q(rules.Quote)は現在原行。返り値: rules.Snapshot/error。fresh=End+足幅+60は118固定のままです。
func (g *Generator) Current(q rules.Quote) (rules.Snapshot, error) { return g.bank.Current(q) }

// Stats は終端未閉鎖も含む品質件数の値copyを返します。
//
// 引数: なし。返り値: Statsは公表/品質の集計。
func (g *Generator) Stats() Stats { s := g.stats; s.TerminalUnclosed = g.active.Has; return s }
