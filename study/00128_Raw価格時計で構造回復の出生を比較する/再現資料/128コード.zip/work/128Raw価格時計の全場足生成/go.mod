module rawpricebars128

go 1.24.2

require (
	github.com/masayoshi4649/SessionTradeExecuter/threeframe v0.0.0
	github.com/masayoshi4649/SessionTradeExecuter/threeframe115 v0.0.0
	github.com/masayoshi4649/SessionTradeExecuter/entryrules118 v0.0.0
)

replace github.com/masayoshi4649/SessionTradeExecuter/threeframe => ../三時間軸の公開器
replace github.com/masayoshi4649/SessionTradeExecuter/threeframe115 => ../115三時間軸と方向性の公開
replace github.com/masayoshi4649/SessionTradeExecuter/entryrules118 => ../118複数技法の入口条件
