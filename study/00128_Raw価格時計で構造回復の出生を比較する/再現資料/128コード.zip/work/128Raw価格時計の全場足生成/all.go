package rawpricebars

import (
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"hash"
	"io"
	"os"
	"path/filepath"
)

type Artifact struct {
	Name       string `json:"name"`
	Path       string `json:"path"`
	Bytes      int64  `json:"bytes"`
	SHA        string `json:"sha256"`
	DecodedSHA string `json:"decoded_sha256"`
}
type AllSummary struct {
	Success         bool           `json:"success"`
	InputSHA        string         `json:"input_metadata_sha256"`
	CarryPolicy     string         `json:"carry_policy"`
	Clock           string         `json:"clock"`
	RawPasses       int            `json:"raw_passes"`
	Scenes          []SceneSummary `json:"scenes"`
	Artifacts       []Artifact     `json:"artifacts"`
	FinancialLabels bool           `json:"financial_labels"`
	CSVSeed         bool           `json:"csv_seed"`
}
type sceneStream struct {
	name    string
	partial string
	final   string
	file    *os.File
	gzip    *gzip.Writer
	writer  io.Writer
	decoded hash.Hash
	count   int
	closed  bool
}

// newStream は、成功するまで.partialに留めるモデル別gzipを作ります。
//
// 引数: folder/name/policy/inputSHA(string)、gap/delay(int)。返り値: *sceneStream/errorです。
func newStream(folder, name, policy, inputSHA string, gap, delay int) (*sceneStream, error) {
	final := filepath.Join(folder, name+".json.gz")
	f, e := os.OpenFile(final+".partial", os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if e != nil {
		return nil, e
	}
	z := gzip.NewWriter(f)
	h := sha256.New()
	s := &sceneStream{name: name, partial: final + ".partial", final: final, file: f, gzip: z, decoded: h, writer: io.MultiWriter(z, h)}
	header, e := json.Marshal(map[string]any{"model": map[string]any{"name": name, "max_gap_seconds": gap, "delay_seconds": delay, "carry_policy": policy}, "input_metadata_sha256": inputSHA, "clock": "CurrentPriceTime・受信時刻実測ではない"})
	if e != nil {
		s.abort()
		return nil, e
	}
	if _, e = s.writer.Write(append(header[:len(header)-1], []byte(",\"scenes\":[")...)); e != nil {
		s.abort()
		return nil, e
	}
	return s, nil
}

// add は、Raw完全照合に成功した1場だけを逐次出力します。
//
// 引数: scene(GeneratedScene)。返り値: errorです。
func (s *sceneStream) add(scene GeneratedScene) error {
	if s.count > 0 {
		if _, e := io.WriteString(s.writer, ","); e != nil {
			return e
		}
	}
	body, e := json.Marshal(scene)
	if e != nil {
		return e
	}
	if _, e = s.writer.Write(body); e != nil {
		return e
	}
	s.count++
	return nil
}

// abort は、失敗途中のgzipを閉じます。成功名へ変更しません。
//
// 引数: なし。返り値: ありません。
func (s *sceneStream) abort() {
	if s.closed {
		return
	}
	_ = s.gzip.Close()
	_ = s.file.Close()
	s.closed = true
}

// finish は、全場成功後だけsuccessとgzip終端を書き、指紋を保存します。
//
// 引数: なし。返り値: Artifact/errorです。
func (s *sceneStream) finish() (Artifact, error) {
	if _, e := fmt.Fprintf(s.writer, "],\"success\":true,\"scene_count\":%d}\n", s.count); e != nil {
		return Artifact{}, e
	}
	if e := s.gzip.Close(); e != nil {
		return Artifact{}, e
	}
	if e := s.file.Close(); e != nil {
		return Artifact{}, e
	}
	s.closed = true
	if e := os.Rename(s.partial, s.final); e != nil {
		return Artifact{}, e
	}
	f, e := os.Open(s.final)
	if e != nil {
		return Artifact{}, e
	}
	defer f.Close()
	h := sha256.New()
	if _, e = io.Copy(h, f); e != nil {
		return Artifact{}, e
	}
	stat, e := f.Stat()
	if e != nil {
		return Artifact{}, e
	}
	return Artifact{Name: s.name, Path: filepath.Base(s.final), Bytes: stat.Size(), SHA: hex.EncodeToString(h.Sum(nil)), DecodedSHA: hex.EncodeToString(s.decoded.Sum(nil))}, nil
}

// RunAll は、固定73場の主300/診断60/同値delay60をRaw各1回で生成します。
//
// 引数: scenes([]Scene)、policy/inputSHA/outputFolder(string)。返り値: AllSummary/errorです。
func RunAll(scenes []Scene, policy, inputSHA, outputFolder string) (AllSummary, error) {
	return runPlan(scenes, policy, inputSHA, outputFolder, true)
}

// runPlan は、完全成功した直前場の同限月数値だけを継承します。
//
// 引数: scenes([]Scene)、policy/inputSHA/outputFolder(string)、all73(bool)。返り値: AllSummary/errorです。falseは人工だけです。
func runPlan(scenes []Scene, policy, inputSHA, outputFolder string, all73 bool) (AllSummary, error) {
	summary := AllSummary{InputSHA: inputSHA, CarryPolicy: policy, Clock: "CurrentPriceTime・受信時計実測ではない", Scenes: []SceneSummary{}, Artifacts: []Artifact{}}
	if policy != CarryValidated && policy != CarryCold {
		return summary, fmt.Errorf("carry方針の明示が必要")
	}
	if e := ValidatePlan(scenes, all73); e != nil {
		return summary, e
	}
	if e := os.Mkdir(outputFolder, 0700); e != nil {
		return summary, e
	}
	names := [3]string{"gap300", "gap60", "gap300_delay60"}
	streams := [3]*sceneStream{}
	for i, name := range names {
		gap, wait := 300, 0
		if i == 1 {
			gap = 60
		}
		if i == 2 {
			wait = 60
		}
		s, e := newStream(outputFolder, name, policy, inputSHA, gap, wait)
		if e != nil {
			for _, x := range streams {
				if x != nil {
					x.abort()
				}
			}
			return summary, e
		}
		streams[i] = s
	}
	defer func() {
		for _, s := range streams {
			s.abort()
		}
	}()
	primary, e := New(Config{MaxGapSeconds: 300})
	if e != nil {
		return summary, e
	}
	diagnostic, e := New(Config{MaxGapSeconds: 60})
	if e != nil {
		return summary, e
	}
	gs := [2]*Generator{primary, diagnostic}
	delay := newDelay()
	for i, scene := range scenes {
		carry := policy == CarryValidated && i > 0 && scenes[i-1].Contract == scene.Contract
		from := ""
		if carry {
			from = scenes[i-1].Session
		}
		for _, g := range gs {
			if e = g.StartSession(Session{ID: scene.Session, Contract: scene.Contract, Start: scene.Start, End: scene.End, Input: scene.Raw}, carry); e != nil {
				return summary, e
			}
		}
		if e = delay.start(scene, carry); e != nil {
			return summary, e
		}
		generated, scanned, e := scanScene(scene, gs, delay, from)
		if e != nil {
			return summary, e
		}
		for model := range streams {
			if e = streams[model].add(generated[model]); e != nil {
				return summary, e
			}
		}
		summary.Scenes = append(summary.Scenes, scanned)
		summary.RawPasses++
		fmt.Printf("足生成 %s 採用=%d 公表300=%d 遅延=%d 診断60=%d\n", scene.Session, scanned.Counts.Accepted, len(generated[0].Publications), len(generated[2].Publications), len(generated[1].Publications))
	}
	for _, stream := range streams {
		artifact, e := stream.finish()
		if e != nil {
			return summary, e
		}
		summary.Artifacts = append(summary.Artifacts, artifact)
	}
	summary.Success = true
	body, e := json.MarshalIndent(summary, "", "  ")
	if e != nil {
		return summary, e
	}
	f, e := os.OpenFile(filepath.Join(outputFolder, "summary.json"), os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if e != nil {
		return summary, e
	}
	if _, e = f.Write(append(body, '\n')); e != nil {
		_ = f.Close()
		return summary, e
	}
	if e = f.Close(); e != nil {
		return summary, e
	}
	return summary, nil
}
