"""128の主と保留対照を、モデル名付きのCSV用3表へまとめる。"""
from pathlib import Path
import argparse
import hashlib
import json

ROOT=Path(__file__).resolve().parent.parent
OWN=ROOT/'work/128Raw時計の評価'


def main() -> None:
    """
    機能: 固定済み2モデルのセルを改変せず先頭に公表モデル列だけ付ける。
    引数: CLI --primary-sha256/--delayed-sha256(str)。返り値: None。
    """
    parser=argparse.ArgumentParser(description='128の2モデルを閲覧3表へ転記')
    parser.add_argument('--primary-sha256',required=True);parser.add_argument('--delayed-sha256',required=True)
    args=parser.parse_args()
    sources=[];proof=[]
    for name,label,expected in (('gap300','即時（主）',args.primary_sha256),('gap300_delay60','60秒保留（対照）',args.delayed_sha256)):
        path=OWN/f'{name}集計/CSV用の表.json';raw=path.read_bytes();assert hashlib.sha256(raw).hexdigest()==expected
        data=json.loads(raw);assert data['成功'] and data['試行']==128
        sources.append((label,data['tables']));proof.append({'モデル':name,'ラベル':label,'正本表SHA256':expected})
    tables=[]
    for index in range(3):
        first=sources[0][1][index];assert first['headers']==sources[1][1][index]['headers']
        headers=['公表モデル']+first['headers'];rows=[]
        for label,source in sources:
            table=source[index];assert table['name']==first['name']
            transformed=[[label]+row for row in table['rows']]
            assert [r[1:] for r in transformed]==table['rows']
            rows.extend(transformed)
        assert len(set(headers))==len(headers) and all(len(r)==len(headers) for r in rows)
        tables.append({'name':first['name'],'headers':headers,'rows':rows})
    assert len(tables[0]['rows'])==280 and len(tables[2]['rows'])==146
    output=OWN/'CSV用の閲覧表.json'
    value={'試行':128,'成功':True,'元表':proof,'セル値の変更':False,'追加列':'公表モデル','tables':tables}
    raw=(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode('utf-8')
    with output.open('xb') as stream: stream.write(raw)
    print(json.dumps({'成功':True,'SHA256':hashlib.sha256(raw).hexdigest(),'行列':[(t['name'],len(t['rows']),len(t['headers'])) for t in tables]},ensure_ascii=False))


if __name__=='__main__':
    main()
