package holdingohlc113

var Widths128 = []float64{25, 50, 100, 125, 200}
var Horizons128 = []float64{1800, 3600}

type FixedEntry128 struct {
	ID    string `json:"id"`
	Side  int    `json:"side"`
	Entry Quote  `json:"entry"`
}
type Scene128 struct {
	Session          string     `json:"session"`
	Contract         string     `json:"contract"`
	Start            float64    `json:"start"`
	End              float64    `json:"end"`
	ForceClose       float64    `json:"force_close"`
	Raw              FileRef    `json:"raw"`
	ExpectedAccepted int64      `json:"expected_accepted"`
	ExpectedQuality  *Counts    `json:"expected_quality"`
	Events           []Birth128 `json:"events"`
}
type Input128 struct {
	Scenes []Scene128 `json:"scenes"`
}
type Signal128 struct {
	ID    string  `json:"id"`
	Side  int     `json:"side"`
	Time  float64 `json:"time"`
	Index int64   `json:"index"`
	Line  int64   `json:"source_line"`
	Quote Quote   `json:"quote"`
}
type First128 struct {
	Width     float64 `json:"width"`
	Direction int     `json:"direction"`
	Quote     *Quote  `json:"quote"`
}
type Outcome128 struct {
	Seconds  float64    `json:"seconds"`
	Deadline float64    `json:"deadline"`
	Status   string     `json:"status"`
	Touches  []First128 `json:"touches"`
	Endpoint *Quote     `json:"endpoint"`
	Points   *float64   `json:"points"`
	Net0     *float64   `json:"net0"`
	Net5     *float64   `json:"net5"`
}
type Candidate128 struct {
	Status         string       `json:"status"`
	Axis           string       `json:"axis"`
	Birth          Signal128    `json:"birth"`
	Entry          *Quote       `json:"entry"`
	EntryPrice     *float64     `json:"entry_price"`
	LastNormalTime float64      `json:"last_normal_time"`
	Outcomes       []Outcome128 `json:"outcomes"`
}
type Case128 struct {
	SourceEvent   Birth128      `json:"source_event"`
	RequestQuote  *Quote        `json:"request_quote"`
	ID            string        `json:"id"`
	OriginalSide  int           `json:"original_side"`
	Original      *Candidate128 `json:"original"`
	Reverse       *Candidate128 `json:"reverse"`
	ChartOriginal *Candidate128 `json:"chart_original"`
	ChartReverse  *Candidate128 `json:"chart_reverse"`
}
type Result128 struct {
	Births          []*BirthResult128 `json:"births"`
	Session         string            `json:"session"`
	Success         bool              `json:"success"`
	Error           string            `json:"error,omitempty"`
	Raw             FileRef           `json:"raw"`
	ActualSHA       string            `json:"actual_sha256"`
	Before          FileStat          `json:"stat_before"`
	After           FileStat          `json:"stat_after"`
	RawEncoding     string            `json:"raw_encoding"`
	Quality         Counts            `json:"quality"`
	ExpectedQuality *Counts           `json:"expected_quality"`
	Cases           []*Case128        `json:"cases"`
	RawPasses       int               `json:"raw_passes"`
	SourceEntries   int               `json:"source_entries"`
}

// fixedCandidate128 は元の取得原行に正又は逆の取得価格を固定します。
//
// 引数: id(string)、side(int)、q(Quote)、chart(bool)。返り値: *Candidate128です。
func fixedCandidate128(id string, side int, q Quote, chart bool) *Candidate128 {
	price := q.Ask
	axis := "BBO"
	if side < 0 {
		price = q.Bid
	}
	if chart {
		price = q.Last
		axis = "Last価格方向診断"
	}
	x := q
	c := &Candidate128{Status: "filled", Axis: axis, Birth: Signal128{ID: id, Side: side, Time: q.Time, Index: q.Index, Line: q.SourceLine, Quote: q}, Entry: &x, EntryPrice: &price, LastNormalTime: q.Time, Outcomes: []Outcome128{}}
	for _, h := range Horizons128 {
		o := Outcome128{Seconds: h, Deadline: q.Time + h, Status: "pending", Touches: []First128{}}
		for _, w := range Widths128 {
			o.Touches = append(o.Touches, First128{Width: w})
		}
		c.Outcomes = append(c.Outcomes, o)
	}
	return c
}

// fixedCase128 は同じ取得原行のBBO正逆とLast参考正逆を一組にします。
//
// 引数: source(FixedEntry128)、q(Quote)。返り値: *Case128です。
func fixedCase128(source FixedEntry128, q Quote) *Case128 {
	return &Case128{ID: source.ID, OriginalSide: source.Side, Original: fixedCandidate128(source.ID, source.Side, q, false), Reverse: fixedCandidate128(source.ID, -source.Side, q, false), ChartOriginal: fixedCandidate128(source.ID, source.Side, q, true), ChartReverse: fixedCandidate128(source.ID, -source.Side, q, true)}
}

// candidates128 は同時刻から始まる四つの独立観測を返します。
//
// 引数: c(*Case128)。返り値: []*Candidate128です。
func candidates128(c *Case128) []*Candidate128 {
	return []*Candidate128{c.Original, c.Reverse, c.ChartOriginal, c.ChartReverse}
}

// stepCase128 はBBOに固定kernel、価格参考にmarkだけLastのkernelを適用します。
//
// 引数: c(*Case128)、q(Quote)、previous/end(float64)。返り値: boolは未完了が残る場合です。
func stepCase128(c *Case128, q Quote, previous, end float64) bool {
	outcome128(c.Original, q, previous, end)
	outcome128(c.Reverse, q, previous, end)
	chartOutcome128(c.ChartOriginal, q, previous, end)
	chartOutcome128(c.ChartReverse, q, previous, end)
	for _, candidate := range candidates128(c) {
		for _, o := range candidate.Outcomes {
			if o.Status == "pending" {
				return true
			}
		}
	}
	return false
}

// finalize128 は未完了を打切りにし、約定不可の参考観測の金額を保存しません。
//
// 引数: c(*Case128)。返り値: ありません。価格方向・先着の値は変更しません。
func finalize128(c *Case128) {
	for _, candidate := range candidates128(c) {
		for i := range candidate.Outcomes {
			o := &candidate.Outcomes[i]
			if o.Status == "pending" {
				o.Status = "eof_censored"
			}
			if candidate.Axis != "BBO" {
				o.Net0 = nil
				o.Net5 = nil
			}
		}
	}
}
