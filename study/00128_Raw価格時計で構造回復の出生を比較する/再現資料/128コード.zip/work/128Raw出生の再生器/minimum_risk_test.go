package holdingohlc113

import "testing"

// TestMinimumRiskMirror128 は入力で指定した最小距離を実取得側でも守ることを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestMinimumRiskMirror128(t *testing.T) {
	for _, reverse := range []bool{false, true} {
		for _, risk := range []float64{5, 10} {
			q := artificialQuote128(100, 0, 995, 1000, 1000)
			e := artificialBirth128(q)
			e.HoldBoundary = 1000
			e.EntryCap = 1050
			e.MinimumRisk = 10
			e.Invalidation = 1010 - risk
			fill := artificialQuote128(101, 1, 1000, 1010, 1000)
			if reverse {
				e = mirrorBirth128(e, 3000)
				q = mirrorQuote128(q, 3000)
				fill = mirrorQuote128(fill, 3000)
			}
			s := Scene128{Start: 90, End: 5000, ForceClose: 4900, ExpectedAccepted: 10, Events: []Birth128{e}}
			if _, err := validateBirths128(s); err != nil {
				t.Fatal(err)
			}
			r := request128(e, q, 4900)
			got := pendingBirth128(r, fill, 4900)
			if got != (risk == 10) {
				t.Fatalf("最小riskの鏡像/包含境界差:%t %g %s", reverse, risk, r.Status)
			}
		}
	}
}
