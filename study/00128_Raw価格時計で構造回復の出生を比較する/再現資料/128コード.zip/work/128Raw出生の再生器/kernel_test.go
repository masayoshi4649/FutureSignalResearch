package holdingohlc113

import (
	"testing"
	"time"
)

// fixedQuoteTest128 は人工取得・観測の全Quoteを作ります。
//
// 引数: at(float64)、index(int64)、bid/ask/last(float64)。返り値: Quoteです。
func fixedQuoteTest128(at float64, index int64, bid, ask, last float64) Quote {
	return Quote{Clock: time.Unix(int64(at), 0).UTC().Format(time.RFC3339), Time: at, Index: index, SourceLine: index + 1, Last: last, Bid: bid, Ask: ask, QuoteOK: true}
}

// TestFixedClockPricesAndSpread128 は正逆の再取得とspreadによる両負けを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestFixedClockPricesAndSpread128(t *testing.T) {
	q := fixedQuoteTest128(100, 0, 100, 130, 115)
	c := fixedCase128(FixedEntry128{ID: "人工", Side: 1, Entry: q}, q)
	if *c.Original.EntryPrice != 130 || *c.Reverse.EntryPrice != 100 || *c.ChartOriginal.EntryPrice != 115 || *c.ChartReverse.EntryPrice != 115 || c.Original.Birth.Side != 1 || c.Reverse.Birth.Side != -1 {
		t.Fatal("同原行の価格・方向差")
	}
	stepCase128(c, q, 100, 5000)
	for _, v := range candidates128(c) {
		if v.Outcomes[0].Touches[0].Direction != 0 {
			t.Fatal("取得原行を先着観測に混入")
		}
	}
	stepCase128(c, fixedQuoteTest128(101, 1, 100, 130, 115), 100, 5000)
	if c.Original.Outcomes[0].Touches[0].Direction != -1 || c.Reverse.Outcomes[0].Touches[0].Direction != -1 {
		t.Fatal("勝敗ラベル単純反転で両負けを消した")
	}
	if c.ChartOriginal.Outcomes[0].Touches[0].Direction != 0 || c.ChartReverse.Outcomes[0].Touches[0].Direction != 0 {
		t.Fatal("Last診断へspreadを混ぜた")
	}
	stepCase128(c, fixedQuoteTest128(102, 2, 140, 150, 145), 101, 5000)
	if c.ChartOriginal.Outcomes[0].Touches[0].Direction != 1 || c.ChartReverse.Outcomes[0].Touches[0].Direction != -1 {
		t.Fatal("Last方向の正逆差")
	}
}

// TestDeadlineKernelAndChartMoney128 は同期限原行・BBO恒等式・chart金額nilを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestDeadlineKernelAndChartMoney128(t *testing.T) {
	q := fixedQuoteTest128(100, 0, 95, 100, 98)
	c := fixedCase128(FixedEntry128{ID: "人工", Side: 1, Entry: q}, q)
	previous := 100.0
	index := int64(1)
	for at := 300.0; at < 1900; at += 200 {
		stepCase128(c, fixedQuoteTest128(at, index, 100, 105, 103), previous, 5000)
		previous = at
		index++
	}
	end := fixedQuoteTest128(1900, index, 110, 115, 112)
	stepCase128(c, end, previous, 5000)
	for _, v := range candidates128(c) {
		if v.Outcomes[0].Status != "complete" || *v.Outcomes[0].Endpoint != end {
			t.Fatal("同じ正常期限原行で評価しない")
		}
	}
	a, b := c.Original.Outcomes[0], c.Reverse.Outcomes[0]
	if *a.Points != 10 || *b.Points != -20 || *a.Net0 != 923 || *b.Net0 != -2077 || *a.Net0+*b.Net0 != -1154 {
		t.Fatal("反転価格・費用・spread恒等式差")
	}
	stepCase128(c, fixedQuoteTest128(1900, index+1, 250, 255, 252), 1900, 5000)
	if c.Original.Outcomes[0].Touches[0].Direction != 0 || c.ChartOriginal.Outcomes[0].Touches[0].Direction != 0 {
		t.Fatal("期限同秒の後続原行を再観測")
	}
	finalize128(c)
	if c.ChartOriginal.Outcomes[0].Points == nil || *c.ChartOriginal.Outcomes[0].Points != 14 || c.ChartOriginal.Outcomes[0].Net0 != nil || c.ChartReverse.Outcomes[0].Net5 != nil || c.ChartOriginal.Outcomes[1].Status != "eof_censored" {
		t.Fatal("chartに金融金額又はEOF未完了を保存")
	}
	if c.Original.Outcomes[0].Net0 == nil || *c.Original.Outcomes[0].Net0 != 923 {
		t.Fatal("BBO金融評価を消した")
	}
}

// TestGapAndNormalQuoteParity128 はchartも同じ欠測・正常BBO条件へ揃えることを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestGapAndNormalQuoteParity128(t *testing.T) {
	q := fixedQuoteTest128(100, 0, 95, 100, 98)
	for _, bboGap := range []bool{false, true} {
		c := fixedCase128(FixedEntry128{ID: "人工", Side: 1, Entry: q}, q)
		next := fixedQuoteTest128(401, 1, 195, 200, 198)
		previous := 100.0
		want := "gap_censored"
		if bboGap {
			next.QuoteOK = false
			previous = 400
			want = "bbo_gap_censored"
		}
		stepCase128(c, next, previous, 5000)
		finalize128(c)
		for _, v := range candidates128(c) {
			for _, o := range v.Outcomes {
				if o.Status != want || o.Points != nil || o.Net0 != nil || o.Touches[0].Direction != 0 {
					t.Fatal("正常BBO/欠測/未補完条件が軸間で異なる")
				}
			}
		}
	}
}
