"""機能: 128のR1既知IFDを保存票だけから分解する。

引数: なし。Rootが許可した即時/保留の固定結果・集計だけを使う。
返り値: なし。R先頭の損失診断.jsonを新規保存する。Rawを読まない。
"""

import hashlib
import importlib.util
import json
from collections import Counter,defaultdict
from pathlib import Path


def sha(path: Path) -> str:
    """機能: SHA256を求める。

    引数: path (Path) は対象。
    返り値: str は小文字16進表記。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def amounts(rows: list[dict]) -> dict:
    """機能: 既知清算の利益と損失を別に合計する。

    引数: rows (list[dict]) は既知IFD票。
    返り値: dict はC0/C5とpt内訳。
    """
    out={'件数':len(rows),'pt内訳':dict(Counter(r['ifd']['points'] for r in rows))}
    for key in ('net0','net5'):
        values=[r['ifd'][key] for r in rows]
        out[key]={'利益':sum(v for v in values if v>0),'損失絶対':-sum(v for v in values if v<0),
                  '差引':sum(values),'利益件数':sum(v>0 for v in values),'損失件数':sum(v<0 for v in values)}
    return out


def book(quote: dict) -> dict:
    """機能: 保存価格と板乖離を新ラベルなしで示す。

    引数: quote (dict) は保存されたQuote。
    返り値: dict は元Quote・spread・LastとBBO帯の距離。
    """
    return {'quote':quote,'spread':quote['ask']-quote['bid'],
            'LastのBBO帯外距離':max(0,quote['bid']-quote['last'],quote['last']-quote['ask'])}


def saved_neighbours(case: dict,exit_quote: dict) -> dict:
    """機能: 保存された少数の節目から直近の前後票を探す。

    引数: case (dict)、exit_quote (dict) は保存ケースと清算原行。
    返り値: dict は保存票上の前後。Rawの直前直後とは主張しない。
    """
    key=lambda q:(q['time'],q['index'],q['source_line'])
    points={key(case['request_quote']):case['request_quote'],key(case['original']['entry']):case['original']['entry']}
    for name in ('original','reverse','chart_original','chart_reverse'):
        for o in case[name]['outcomes']:
            for q in [o['endpoint'],*[t['quote'] for t in o['touches']]]:
                if q is not None:points[key(q)]=q
    before=[k for k in points if k<key(exit_quote)]
    after=[k for k in points if k>key(exit_quote)]
    return {'保存節目の直近前':book(points[max(before)]) if before else None,
            '保存節目の直近後':book(points[min(after)]) if after else None,
            '注意':'各幅の最初到達/期限/取得票だけの疎な抜粋。Raw隣接行やその間の価格gapは復元できない。'}


# ----------------------------------------
BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[1]
OWN=ROOT/'work/128Raw時計の評価'
HELPER=ROOT/'work/124正逆の独立検算/検算する.py'
fixed={HELPER:'0305f507a74f9728fbdb1ecabe406a3bfcb2f8657a4d1ee2556ca50dbe6585be',
       OWN/'gap300結果.json':'a13f7016ef55d9aed070b5fc4b3a8949999e2cbb739756fe967250ceae19e95f',
       OWN/'gap300集計/集計.json':'d2477020814fac299573237dee8fbcc6c81f863b180a4a1bdaf3d2422386c41e',
       OWN/'gap300_delay60結果.json':'4e5411490b82b05458db3dd7490039b6bc198d51e55d9cd3e7984d15958e26c5',
       OWN/'gap300_delay60集計/集計.json':'3966e77cbb514ffc41f34c50a32eb8aabc0908c3fc003e49ead5a2a1dd310ca0'}
before={str(p):sha(p) for p in (*fixed,Path(__file__).resolve())}
assert all(before[str(p)]==h for p,h in fixed.items())
spec=importlib.util.spec_from_file_location('自作124の保存票算術',HELPER);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
output={}
for model in ('gap300','gap300_delay60'):
    data=json.loads((OWN/f'{model}結果.json').read_bytes())
    aggregate=json.loads((OWN/f'{model}集計/集計.json').read_bytes())
    cases={(s['session'],c['id']):(s,c) for s in data['scenes'] for c in s['cases']}
    rows=[]
    for ref in aggregate['政策取得ID']['R1']:
        scene,case=cases[(ref['session'],ref['id'])]
        c=case['original'];side=c['birth']['side'];o=helper.observation(c,3600);t=helper.touch(o,125)
        value=helper.ifd_value(c,3600,125,'BBO');q=t['quote'] if t['direction'] else o['endpoint'] if o['status']=='complete' else None
        row={**ref,'side':side,'entry_price':c['entry_price'],'entry':book(c['entry']),
             'H60状態':o['status'],'保存125先着':t['direction'],'ifd':value,
             'exit':book(q) if q else None,'exit_mark':(q['bid'] if side>0 else q['ask']) if q else None,
             'Last入口からLast清算までの順変化pt':side*(q['last']-c['entry']['last']) if q else None,
             '逆行125ptの超過pt':max(0,-value['points']-125) if value['known'] else None,
             'H不足でもtouch既知':o['status']!='complete' and t['direction']!=0,
             'candidate_last_normal_time':c['last_normal_time'],
             '全Raw採用行のうち清算Indexより後の件数':scene['quality']['source_parser_accepted']-q['index']-1 if q else None}
        if q:
            assert helper.points(c,q,'BBO')==value['points']
            row['保存節目前後']=saved_neighbours(case,q)
        rows.append(row)
    known=[r for r in rows if r['ifd']['known']]
    status=defaultdict(list);reasons=defaultdict(list)
    for row in known:
        status[row['H60状態']].append(row);reasons[row['ifd']['reason']].append(row)
    saved=aggregate['集計']['R1']['BBO']['3600']['125']
    total=amounts(known)
    assert total['net5']['利益']==saved['ifd_net5_profit'] and total['net5']['損失絶対']==saved['ifd_net5_loss'] and total['net5']['差引']==saved['ifd_net5_sum']
    output[model]={'R1主集計':saved,'全既知IFDの合計':total,'H状態別既知清算':{k:amounts(v) for k,v in status.items()},
                   '清算理由別':{k:amounts(v) for k,v in reasons.items()},'最大損失3':sorted(known,key=lambda r:(r['ifd']['net5'],r['session'],r['id']))[:3],
                   '全R1票':rows}
after={str(p):sha(p) for p in (*fixed,Path(__file__).resolve())};assert before==after
out={'成功':True,'試行':128,'事後診断':True,'前SHA256':before,'後SHA256':after,'前後不変':True,'モデル':output,
     'Raw再読':False,'新金融ラベル計算':False,'Root集計関数import':False,
     'gapの確認範囲':'保存票のH状態と既存kernel仕様を参照。gap>300はtouch判定前に打切る仕様だが、直前Raw/正常BBOは保存されず、その秒差を独立再計算できない。',
     '価格品質の限界':'QuoteOKは有限正Bid<Ask。Lastとの同時性・同一市場での実約定可能性・mini実板を保証しない。LastがBBO外でも自動除外せず旧結果を保存する。'}
p=BASE/'R先頭の損失診断.json'
with p.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'成功':True,'SHA256':sha(p),'合計':{k:v['全既知IFDの合計'] for k,v in output.items()}},ensure_ascii=False))
