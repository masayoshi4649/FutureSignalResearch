package threeframe115

import (
	"encoding/json"
	"math"
	"reflect"
	"strings"
	"testing"

	old "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
)

// fixture は実CSVを使わない正規格子の手製足を作ります。
//
// 引数: count(int)、side(int)は子足数と鏡像方向です。
// 返り値: old.Session/[]old.ChildBarは独立人工だけの入力です。
func fixture(count, side int) (old.Session, []old.ChildBar) {
	start := 1800000000.0
	scene := old.Session{ID: "人工", Contract: "人工限月", Start: start, End: start + float64(count+1)*300, EOF: start + float64(count)*300 + 60}
	children := []old.ChildBar{}
	for i := 0; i < count; i++ {
		close := 10000 + float64(i)
		bar := old.OHLC{Open: close - .5, High: close + 2, Low: close - 2, Close: close}
		if side == -1 {
			bar = old.OHLC{Open: 30000 - bar.Open, High: 30000 - bar.Low, Low: 30000 - bar.High, Close: 30000 - bar.Close}
		}
		children = append(children, old.ChildBar{Start: start + float64(i)*300, End: start + float64(i+1)*300, OHLC: bar, Volume: 100,
			Closed: true, VolumeKnown: true, Input: old.FileRef{Path: "人工.csv", SHA256: strings.Repeat("a", 64), Bytes: 100}, Row: uint64(i + 2)})
	}
	return scene, children
}

// begin は人工の開始エラーを試験失敗にします。
//
// 引数: t(*testing.T)、scene(old.Session)、children([]old.ChildBar)、seed(*Seed|nil)は人工条件です。
// 返り値: *Bankは開始済み公開器です。
func begin(t *testing.T, scene old.Session, children []old.ChildBar, seed *Seed) *Bank {
	t.Helper()
	bank, err := BeginSession(scene, children, seed)
	if err != nil {
		t.Fatal(err)
	}
	return bank
}

// near は独立した解析値と追加値を比較します。
//
// 引数: t(*testing.T)、value/want(float64)は実値と解析値です。
// 返り値: なし。非有限又は許容差超なら失敗します。
func near(t *testing.T, value, want float64) {
	t.Helper()
	if !finite(value) || math.Abs(value-want) > 1e-10 {
		t.Fatalf("数値差 %.17g / %.17g", value, want)
	}
}

// TestOldFramesAndLinearDMI は旧全文同体と3尺度の線形解析解を確認します。
//
// 引数: t(*testing.T)は人工検査器です。
// 返り値: なし。共有データや市場結果は読みません。
func TestOldFramesAndLinearDMI(t *testing.T) {
	scene, children := fixture(240, 1)
	bank := begin(t, scene, children, nil)
	prior, err := old.BeginSession(scene, children, nil)
	if err != nil {
		t.Fatal(err)
	}
	counts := map[int]int{}
	for ordinal, at := uint64(1), scene.Start+360; at <= scene.EOF; ordinal, at = ordinal+1, at+300 {
		frames, err := bank.AdvanceObserved(at, ordinal)
		if err != nil {
			t.Fatal(err)
		}
		original, err := prior.AdvanceObserved(at, ordinal)
		if err != nil || len(original) != len(frames) {
			t.Fatal("旧公表数差", err)
		}
		for i, frame := range frames {
			if !reflect.DeepEqual(frame.Frame, original[i]) {
				t.Fatal("旧Frameの全値差")
			}
			width := frame.Frame.WidthSeconds
			counts[width]++
			bars := counts[width]
			if frame.DMI.PlusDI.Known != (bars >= 15) || frame.DMI.ADX.Known != (bars >= 28) {
				t.Fatal("DI15足/ADX28足の境界差", width, bars, frame.DMI)
			}
			if frame.DMI.PlusDI.Known {
				step := float64(width / 300)
				near(t, frame.DMI.PlusDI.Value, 100*step/(step+3))
				near(t, frame.DMI.MinusDI.Value, 0)
			}
			if frame.DMI.ADX.Known {
				near(t, frame.DMI.ADX.Value, 100)
			}
			if width == 300 && frame.Structure.Known != (bars >= 4) {
				t.Fatal("前3本構造の初回差")
			}
		}
	}
	if !reflect.DeepEqual(counts, map[int]int{300: 240, 900: 80, 1800: 40}) {
		t.Fatal(counts)
	}
}

// TestMirrorAndPrevious は買売鏡像と直前DI/ADXの既知性を確認します。
//
// 引数: t(*testing.T)は人工検査器です。
// 返り値: なし。平均線/価格を追加計算用に偽装しません。
func TestMirrorAndPrevious(t *testing.T) {
	scene, buy := fixture(180, 1)
	_, sell := fixture(180, -1)
	a, b := begin(t, scene, buy, nil), begin(t, scene, sell, nil)
	x, err := a.AdvanceObserved(scene.EOF, 1)
	if err != nil {
		t.Fatal(err)
	}
	y, err := b.AdvanceObserved(scene.EOF, 1)
	if err != nil || len(x) != len(y) {
		t.Fatal(err)
	}
	previous := map[int]DMI{}
	for i, frame := range x {
		mirror := y[i]
		if frame.DMI.PlusDI != mirror.DMI.MinusDI || frame.DMI.MinusDI != mirror.DMI.PlusDI || frame.DMI.ADX != mirror.DMI.ADX {
			t.Fatal("方向鏡像差")
		}
		p := previous[frame.Frame.WidthSeconds]
		if frame.DMI.PreviousPlusDI != p.PlusDI || frame.DMI.PreviousMinusDI != p.MinusDI || frame.DMI.PreviousADX != p.ADX {
			t.Fatal("直前値差")
		}
		previous[frame.Frame.WidthSeconds] = frame.DMI
		if frame.Structure.Known {
			near(t, frame.Structure.High, 30000-mirror.Structure.Low)
			near(t, frame.Structure.Low, 30000-mirror.Structure.High)
		}
	}
}

// TestUndefinedAndEqualDM はTR0/DM和0と14連続DXの再助走を確認します。
//
// 引数: t(*testing.T)は手製数値の検査器です。
// 返り値: なし。高安同幅は方向票を作りません。
func TestUndefinedAndEqualDM(t *testing.T) {
	for _, zeroRange := range []bool{false, true} {
		state := dmiState{}
		for i := 0; i < 30; i++ {
			bar := old.OHLC{Open: 100, High: 102, Low: 98, Close: 100}
			if zeroRange {
				bar.High, bar.Low = 100, 100
			}
			value, err := state.advance(old.Frame{PriceKnown: true, OHLC: bar})
			if err != nil || value.PlusDI.Known || value.MinusDI.Known || value.ADX.Known || state.DXCount != 0 {
				t.Fatal("0分母が既知", value, err)
			}
		}
		for i := 1; i <= 14; i++ {
			p := 100 + float64(i)
			value, err := state.advance(old.Frame{PriceKnown: true, OHLC: old.OHLC{Open: p, High: p + 2, Low: p - 2, Close: p}})
			if err != nil || value.ADX.Known != (i == 14) {
				t.Fatal("連続DXの助走差", i, value, err)
			}
		}
	}
	state := dmiState{}
	for i := 0; i < 30; i++ {
		value, err := state.advance(old.Frame{PriceKnown: true, OHLC: old.OHLC{Open: 100, High: 102 + float64(i), Low: 98 - float64(i), Close: 100}})
		if err != nil || value.PlusDI.Known || value.MinusDI.Known || state.Plus.Value != 0 || state.Minus.Value != 0 {
			t.Fatal("同幅DMで方向が生じた", value, err)
		}
	}
}

// TestPreviousThreeExcludesCurrent は現在足の極値と未来足を境界へ混ぜないことを確認します。
//
// 引数: t(*testing.T)は人工検査器です。
// 返り値: なし。各refは直前3本の当場公表です。
func TestPreviousThreeExcludesCurrent(t *testing.T) {
	scene, children := fixture(8, 1)
	children[3].OHLC.High = 99999
	bank := begin(t, scene, children, nil)
	frames, err := bank.AdvanceObserved(scene.Start+1260, 1)
	if err != nil {
		t.Fatal(err)
	}
	last := frames[len(frames)-1]
	if last.Frame.WidthSeconds != 300 || !last.Structure.Known {
		t.Fatal("4本目構造が不明")
	}
	near(t, last.Structure.High, 10004)
	near(t, last.Structure.Low, 9998)
	for i, source := range last.Structure.Refs {
		if source.Start != children[i].Start || source.End != children[i].End || source.End > last.Frame.Start || source.ID == last.Frame.ID {
			t.Fatal("構造refが現在又は未来")
		}
	}
}

// TestMissingResetsAndVolumeDoesNot は欠足の影響尺度と量だけ未知の独立性を確認します。
//
// 引数: t(*testing.T)は人工検査器です。
// 返り値: なし。旧価格未知Frameを正常値で補いません。
func TestMissingResetsAndVolumeDoesNot(t *testing.T) {
	scene, children := fixture(180, 1)
	full := begin(t, scene, children, nil)
	original, err := full.AdvanceObserved(scene.EOF, 1)
	if err != nil {
		t.Fatal(err)
	}
	volume := append([]old.ChildBar{}, children...)
	volume[70].VolumeKnown = false
	bank := begin(t, scene, volume, nil)
	x, err := bank.AdvanceObserved(scene.EOF, 1)
	if err != nil {
		t.Fatal(err)
	}
	for i := range x {
		if original[i].DMI != x[i].DMI || original[i].Frame.Technical != x[i].Frame.Technical {
			t.Fatal("量未知で価格数値が変化")
		}
	}
	missing := append([]old.ChildBar{}, children[:70]...)
	missing = append(missing, children[71:]...)
	bank = begin(t, scene, missing, nil)
	x, err = bank.AdvanceObserved(scene.EOF, 1)
	if err != nil {
		t.Fatal(err)
	}
	unknown := map[int]int{}
	for _, frame := range x {
		if !frame.Frame.PriceKnown {
			unknown[frame.Frame.WidthSeconds]++
			if frame.DMI != (DMI{}) || frame.Structure.Known {
				t.Fatal("欠足で追加状態が残った")
			}
		}
	}
	if !reflect.DeepEqual(unknown, map[int]int{300: 1, 900: 1, 1800: 1}) {
		t.Fatal(unknown)
	}
}

// TestSeedCarryMaskAndRoll は数値のみ同限月継承と構造cold/限月resetを確認します。
//
// 引数: t(*testing.T)は人工検査器です。
// 返り値: なし。種の二後継は互いに状態を共有しません。
func TestSeedCarryMaskAndRoll(t *testing.T) {
	scene, children := fixture(240, 1)
	bank := begin(t, scene, children, nil)
	if _, err := bank.AdvanceObserved(scene.EOF, 1); err != nil {
		t.Fatal(err)
	}
	seed, _, err := bank.Seal()
	if err != nil || seed.Info().SHA256 == "" || !seed.Info().Old.Sealed {
		t.Fatal(err)
	}
	next, bars := fixture(12, 1)
	shift := scene.End + 300 - next.Start
	next.Start, next.End, next.EOF = next.Start+shift, next.End+shift, next.EOF+shift
	next.ID = "後続場"
	for i := range bars {
		bars[i].Start, bars[i].End = bars[i].Start+shift, bars[i].End+shift
	}
	a, b := begin(t, next, bars, &seed), begin(t, next, bars, &seed)
	if _, err := a.AdvanceObserved(next.Start, 1); err != nil {
		t.Fatal(err)
	}
	start, err := a.SnapshotAt(next.Start)
	if err != nil {
		t.Fatal(err)
	}
	for _, scale := range start.Scales {
		if scale.HasCurrent || !scale.SeedOnly || !scale.SeedDMI.ADX.Known {
			t.Fatal("種だけで当場値が公開された")
		}
	}
	if _, err = a.AdvanceObserved(next.Start+1860, 2); err != nil {
		t.Fatal(err)
	}
	snapshot, _ := a.SnapshotAt(next.Start + 1860)
	for _, scale := range snapshot.Scales {
		if !scale.HasCurrent || !scale.Current.DMI.ADX.Known || scale.WidthSeconds != 300 && scale.Current.Structure.Known {
			t.Fatal("継承数値/幅の公開差")
		}
	}
	if _, err = b.AdvanceObserved(next.Start, 1); err != nil {
		t.Fatal(err)
	}
	bStart, _ := b.SnapshotAt(next.Start)
	if !reflect.DeepEqual(start, bStart) {
		t.Fatal("種の別後継へ波及")
	}
	next.Contract = "別限月"
	c := begin(t, next, bars, &seed)
	if _, err = c.AdvanceObserved(next.Start+1860, 1); err != nil {
		t.Fatal(err)
	}
	rolled, _ := c.SnapshotAt(next.Start + 1860)
	if rolled.Scales[2].Current.DMI.PlusDI.Known || rolled.Scales[2].SeedOnly || rolled.Scales[2].SeedDMI.ADX.Known {
		t.Fatal("限月を跨いで数値carry")
	}
}

// TestClockAsOfCopyAndSeal は現在原行・同秒・未来不参照・値copy・未完足を確認します。
//
// 引数: t(*testing.T)は人工検査器です。
// 返り値: なし。EOFまでの強制進行をSealへ混ぜません。
func TestClockAsOfCopyAndSeal(t *testing.T) {
	scene, children := fixture(12, 1)
	bank := begin(t, scene, children, nil)
	due := scene.Start + 360
	frames, err := bank.AdvanceObserved(due+100, 1)
	if err != nil || len(frames) != 1 || frames[0].Frame.DeliveryAt != due+100 {
		t.Fatal("遅配を過去へ戻した", err)
	}
	before, err := bank.SnapshotAt(due)
	if err != nil || before.Scales[0].HasCurrent {
		t.Fatal("未配送の過去asofへ混入", err)
	}
	frames[0].Frame.OHLC.High, frames[0].DMI.Bars = 99999, 999
	current, _ := bank.SnapshotAt(due + 100)
	if current.Scales[0].Current.DMI.Bars != 1 || current.Scales[0].Current.Frame.OHLC.High == 99999 {
		t.Fatal("返り値から内部へ波及")
	}
	x, err := bank.AdvanceObserved(due+100, 2)
	if err != nil || len(x) != 0 {
		t.Fatal("同秒後原行で再公表", err)
	}
	if _, err = bank.AdvanceObserved(due+99, 3); err == nil {
		t.Fatal("逆行時計を受理")
	}
	seed, end, err := bank.Seal()
	if err != nil || seed.Info().Old.HistoryBars[0] != 1 || end.AsOf != due+100 {
		t.Fatal("sealで未完足を締めた", err)
	}
	if _, _, err = bank.Seal(); err == nil {
		t.Fatal("二度seal")
	}
}

// TestAdditionalFailureIsAtomic は追加計算失敗時に旧/新の観測をcommitしないことを確認します。
//
// 引数: t(*testing.T)は私有状態の破壊人工です。
// 返り値: なし。現実の市場入力を使いません。
func TestAdditionalFailureIsAtomic(t *testing.T) {
	scene, children := fixture(5, 1)
	bank := begin(t, scene, children, nil)
	if _, err := bank.AdvanceObserved(scene.Start+360, 1); err != nil {
		t.Fatal(err)
	}
	bank.dmi[0].Plus = rma{Count: 13, Sum: math.MaxFloat64 / 2}
	bank.dmi[0].Minus = rma{Count: 14, Known: true}
	bank.dmi[0].TR = rma{Count: 14, Sum: 14, Value: 1, Known: true}
	before, _ := bank.SnapshotAt(scene.Start + 360)
	oldBefore, _ := json.Marshal(before)
	if _, err := bank.AdvanceObserved(scene.Start+660, 2); err == nil {
		t.Fatal("破損DMIが公表された")
	}
	after, _ := bank.SnapshotAt(scene.Start + 360)
	oldAfter, _ := json.Marshal(after)
	if string(oldBefore) != string(oldAfter) {
		t.Fatal("追加失敗で旧状態が進んだ")
	}
}

// TestDecimalIndependentAlternation は非線形ADXを別言語Decimal70桁の基準へ照合します。
//
// 引数: t(*testing.T)は検査器です。
// 返り値: なし。初期14差分は上昇2が7回/下降1が7回、TRは全て4の手計算です。
func TestDecimalIndependentAlternation(t *testing.T) {
	golden := map[int][4]float64{
		28: {26.2792517338374661288503080541, 11.8603741330812669355748459729, 37.8055035229455114556832061506, 35.4029198346563699268224614729},
		29: {24.4021623242776471196467146217, 12.7989188378611764401766426892, 31.1906082402400764042084945334, 35.1020404350552061037786066915},
		40: {26.0711234330974259408839268728, 11.9644382834512870295580365636, 37.0881472837787166720837017819, 34.6730903848596815406161555713},
	}
	state, price := dmiState{}, 100.0
	for i := 0; i < 40; i++ {
		if i > 0 && i%2 == 1 {
			price += 2
		} else if i > 0 {
			price--
		}
		value, err := state.advance(old.Frame{PriceKnown: true, OHLC: old.OHLC{Open: price, High: price + 2, Low: price - 2, Close: price}})
		if err != nil {
			t.Fatal(err)
		}
		if i == 14 {
			near(t, value.PlusDI.Value, 25)
			near(t, value.MinusDI.Value, 12.5)
			near(t, value.DX.Value, 100.0/3)
		}
		if expected, exists := golden[i+1]; exists {
			if !value.ADX.Known {
				t.Fatal("非線形ADXが未準備")
			}
			for j, actual := range []float64{value.PlusDI.Value, value.MinusDI.Value, value.DX.Value, value.ADX.Value} {
				near(t, actual, expected[j])
			}
		}
	}
}

// TestFutureTailCannotChangePublished は未来側の値を変えても当時数値が同じことを確認します。
//
// 引数: t(*testing.T)は手製二経路の比較器です。
// 返り値: なし。識別用CSV全体SHAの変更はFrame IDの差と分けます。
func TestFutureTailCannotChangePublished(t *testing.T) {
	scene, children := fixture(120, 1)
	changed := append([]old.ChildBar{}, children...)
	for i := range changed {
		changed[i].Input.SHA256 = strings.Repeat("b", 64)
		if i >= 90 {
			changed[i].OHLC.High += 1000
		}
	}
	a, b := begin(t, scene, children, nil), begin(t, scene, changed, nil)
	x, err := a.AdvanceObserved(scene.Start+90*300+60, 1)
	if err != nil {
		t.Fatal(err)
	}
	y, err := b.AdvanceObserved(scene.Start+90*300+60, 1)
	if err != nil || len(x) != len(y) {
		t.Fatal(err)
	}
	for i := range x {
		if x[i].DMI != y[i].DMI || x[i].Frame.Technical != y[i].Frame.Technical || x[i].Frame.OHLC != y[i].Frame.OHLC ||
			x[i].Structure.Known != y[i].Structure.Known || x[i].Structure.High != y[i].Structure.High || x[i].Structure.Low != y[i].Structure.Low {
			t.Fatal("未配送の未来価格が当時値へ混入")
		}
	}
}
