package threeframe115

import (
	"encoding/json"
	"flag"
	"os"
	"path/filepath"
	"testing"
)

var exportDirectory = flag.String("export-dir", "", "未作成の人工公開先")

// TestExportArtificial は公開APIだけで手製二方向の成熟数値と当場coldを保存します。
//
// 引数: t(*testing.T)、CLI export-dir(string)は検査器と任意の新規先です。
// 返り値: なし。市場入力なしの定義/公表/種を独立検査へ渡します。
func TestExportArtificial(t *testing.T) {
	if *exportDirectory == "" {
		return
	}
	if _, err := os.Stat(*exportDirectory); !os.IsNotExist(err) {
		t.Fatal("人工公開は未作成先だけ")
	}
	if err := os.Mkdir(*exportDirectory, 0700); err != nil {
		t.Fatal(err)
	}
	cases := []any{}
	for _, side := range []int{1, -1} {
		scene, children := fixture(240, side)
		bank := begin(t, scene, children, nil)
		frames, err := bank.AdvanceObserved(scene.EOF, 1)
		if err != nil {
			t.Fatal(err)
		}
		seed, snapshot, err := bank.Seal()
		if err != nil {
			t.Fatal(err)
		}
		cases = append(cases, map[string]any{"side": side, "last": frames[len(frames)-1], "snapshot": snapshot, "seed_info": seed.Info()})
	}
	for name, value := range map[string]any{"実定義.json": DeclaredDefinition(), "買売人工.json": map[string]any{"trial": 115, "artificial": true, "cases": cases}} {
		data, err := json.MarshalIndent(value, "", "  ")
		if err != nil {
			t.Fatal(err)
		}
		file, err := os.OpenFile(filepath.Join(*exportDirectory, name), os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
		if err != nil {
			t.Fatal(err)
		}
		_, writeErr := file.Write(append(data, '\n'))
		closeErr := file.Close()
		if writeErr != nil || closeErr != nil {
			t.Fatal(writeErr, closeErr)
		}
	}
}
