package threeframe115

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"

	old "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
)

var widths = [3]int{300, 900, 1800}

// Seed はSealだけが作る同限月の数値種で、構造窓や当場公表を含みません。
type Seed struct {
	old    old.Seed
	dmi    [3]dmiState
	sealed bool
}

// stateSHA は全私有数値を含む決定的JSONの指紋を返します。
//
// 引数: value(any)は有限な数値種です。
// 返り値: stringはSHA256。不正な非有限値等では空文字です。
func stateSHA(value any) string {
	data, err := json.Marshal(value)
	if err != nil {
		return ""
	}
	sum := sha256.Sum256(data)
	return hex.EncodeToString(sum[:])
}

// Info は旧seedと追加DMIの全状態を指紋へ結びます。
//
// 引数: なし。
// 返り値: SeedInfoは値copyで、種の数値を外から変更する口を持ちません。
func (s Seed) Info() SeedInfo {
	info := SeedInfo{Version: 115, Old: s.old.Info()}
	for i, state := range s.dmi {
		info.DMI[i] = DMISeedInfo{widths[i], state.Bars, state.Differences, state.DXCount, stateSHA(state), state.Latest}
	}
	if s.sealed && info.Old.Sealed {
		info.SHA256 = stateSHA(struct {
			Old old.SeedInfo
			DMI [3]dmiState
		}{info.Old, s.dmi})
	}
	return info
}

// Bank は旧純公開器と独立追加数値を同じ公表順で扱います。
type Bank struct {
	old       *old.Bank
	dmi       [3]dmiState
	seedView  [3]DMI
	structure structureState
	history   [3][]Frame
	sealed    bool
}

// BeginSession は旧の時計/子足/種検査を再用し、当場構造と配送履歴をcoldにします。
//
// 引数: scene(old.Session)、children([]old.ChildBar)、seed(*Seed|nil)は当場・固定子足・前場数値種です。
// 返り値: *Bank/errorは独立公開器又は旧/追加種の不整合です。
func BeginSession(scene old.Session, children []old.ChildBar, seed *Seed) (*Bank, error) {
	var prior *old.Seed
	if seed != nil {
		if !seed.sealed || seed.Info().SHA256 == "" {
			return nil, fmt.Errorf("115のsealed数値種だけを受理")
		}
		for _, state := range seed.dmi {
			if !validDMI(state) {
				return nil, fmt.Errorf("115のDMI種が破損")
			}
		}
		prior = &seed.old
	}
	base, err := old.BeginSession(scene, children, prior)
	if err != nil {
		return nil, err
	}
	b := &Bank{old: base}
	if seed != nil && seed.old.Info().Session.Contract == scene.Contract {
		b.dmi = seed.dmi
		for i, state := range b.dmi {
			b.seedView[i] = state.Latest
		}
	}
	return b, nil
}

// AdvanceObserved は旧公表全文/順序を保ち、追加計算も成功してから一括commitします。
//
// 引数: at(float64)、ordinal(uint64)は現在の観測時計とstrict増加する入力識別です。
// 返り値: []Frame/errorは新公表又は時計/数値の拒否。同秒別原行で重複公表しません。
func (b *Bank) AdvanceObserved(at float64, ordinal uint64) ([]Frame, error) {
	if b == nil || b.old == nil || b.sealed {
		return nil, fmt.Errorf("115公開器が未開始又はsealed")
	}
	base := *b.old
	frames, err := base.AdvanceObserved(at, ordinal)
	if err != nil {
		return nil, err
	}
	states, structure := b.dmi, b.structure
	result := []Frame{}
	for _, frame := range frames {
		index := 0
		for widths[index] != frame.WidthSeconds {
			index++
		}
		dmi, err := states[index].advance(frame)
		if err != nil {
			return nil, err
		}
		result = append(result, Frame{frame, dmi, structure.advance(frame)})
	}
	// ----------------------------------------
	// 旧の履歴sliceは既存要素を変更せず末尾へ追加するだけで、旧Bank自身は依存側で公開されません。
	b.old, b.dmi, b.structure = &base, states, structure
	for _, frame := range result {
		for i, width := range widths {
			if frame.Frame.WidthSeconds == width {
				b.history[i] = append(b.history[i], frame)
			}
		}
	}
	return result, nil
}

// extend は旧Snapshotのasof/現在mask/鮮度へ同じ公表IDの追加値だけを結びます。
//
// 引数: base(old.Snapshot)は旧公開器の値copyです。
// 返り値: Snapshot/errorは同じ時計の拡張値又は内部の公表対応不整合です。
func (b *Bank) extend(base old.Snapshot) (Snapshot, error) {
	snapshot := Snapshot{Session: base.Session, AsOf: base.AsOf, ReplayObservedAt: base.ReplayObservedAt,
		HasObserved: base.HasObserved, RecordOrdinal: base.RecordOrdinal, Sealed: base.Sealed}
	for i, scale := range base.Scales {
		value := ScaleSnapshot{WidthSeconds: scale.WidthSeconds, HasCurrent: scale.HasCurrent, Fresh: scale.Fresh,
			SeedOnly: scale.SeedOnly, SeedTechnical: scale.SeedTechnical, SeedDMI: b.seedView[i]}
		if scale.HasCurrent {
			found := false
			for j := len(b.history[i]) - 1; j >= 0; j-- {
				if b.history[i][j].Frame.ID == scale.Current.ID {
					value.Current, found = b.history[i][j], true
					break
				}
			}
			if !found {
				return Snapshot{}, fmt.Errorf("115の追加値に旧公表IDがない")
			}
		}
		snapshot.Scales[i] = value
	}
	return snapshot, nil
}

// SnapshotAt は当時までに配送された旧Frameと追加値だけを返します。
//
// 引数: at(float64)は観測frontier以前の当場時計です。
// 返り値: Snapshot/errorは独立値copy又は未来/未開始の拒否です。
func (b *Bank) SnapshotAt(at float64) (Snapshot, error) {
	if b == nil || b.old == nil {
		return Snapshot{}, fmt.Errorf("115公開器が未開始")
	}
	base, err := b.old.SnapshotAt(at)
	if err != nil {
		return Snapshot{}, err
	}
	return b.extend(base)
}

// Seal は新しい足を公表せず、旧種とDMI数値だけを同時点で閉じます。
//
// 引数: なし。
// 返り値: Seed/Snapshot/errorは不透明数値種・末尾値又は未開始/重複sealの拒否です。
func (b *Bank) Seal() (Seed, Snapshot, error) {
	if b == nil || b.old == nil || b.sealed {
		return Seed{}, Snapshot{}, fmt.Errorf("115公開器が未開始又はsealed")
	}
	base := *b.old
	seed, end, err := base.Seal()
	if err != nil {
		return Seed{}, Snapshot{}, err
	}
	snapshot, err := b.extend(end)
	if err != nil {
		return Seed{}, Snapshot{}, err
	}
	result := Seed{seed, b.dmi, true}
	if result.Info().SHA256 == "" {
		return Seed{}, Snapshot{}, fmt.Errorf("115数値種の符号化失敗")
	}
	b.old, b.sealed = &base, true
	return result, snapshot, nil
}
