"""115公開wrapperを手製人工・実Go閉包・旧コード不変とともに停止する。"""

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess


OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[1]
NAMES = ('types.go', 'numeric.go', 'bank.go', 'bank_test.go', 'export_test.go', 'go.mod', 'README.md', '検査して停止する.py')
DEPENDENCIES = {
    '旧threeframe': (ROOT / 'work/三時間軸の公開器/停止.json', 'b6b1a326cc98f67e13ec1962a19bac001eda743880b74a13066a2307c5944895'),
    '保持する111保護bank': (ROOT / 'work/111連続保護のチャート公開/停止.json', '38c01e07d276310c6c1d803dca11e27979fc9286cf64d9a495e60485ea7264bd'),
}


def sha(path: Path) -> str:
    """機能: 明示コードと小metadataのSHA256を返す。

    引数: path(Path)は認証対象。
    返り値: strは全bytes指紋。市場入力を渡さない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def ref(path: Path) -> dict:
    """機能: 解決絶対pathとSHAの参照を返す。

    引数: path(Path)は明示ファイル。
    返り値: dictは2項目のFileRef。
    """
    return {'path': str(path.resolve()), 'sha256': sha(path)}


def write(path: Path, value: dict) -> dict:
    """機能: 新しいJSON証拠をUTF-8で保存する。

    引数: path(Path)、value(dict)は未作成先と有限JSON。
    返り値: dictは保存物Ref。上書きしない。
    """
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    return ref(path)


def command(args: list[str]) -> str:
    """機能: 市場を呼ばないGo検査又はmetadataコマンドを実行する。

    引数: args(list[str])は明示した引数列。
    返り値: strは成功した標準出力。失敗は例外にする。
    """
    result = subprocess.run(args, cwd=OWN, capture_output=True, text=True, encoding='utf-8', timeout=120)
    if result.returncode:
        raise ValueError('Go検査失敗: ' + ' '.join(args) + '\n' + result.stdout + result.stderr)
    return result.stdout + result.stderr


def closure() -> tuple[dict, dict]:
    """機能: Goが実選択した依存ソースとGo環境を列挙する。

    引数: なし。
    返り値: tuple[dict,dict]は依存絶対path/SHAとGo環境。
    """
    environment = json.loads(command(['go', 'env', '-json', 'GOROOT', 'GOVERSION', 'GOOS', 'GOARCH']))
    if environment['GOVERSION'] != 'go1.24.2':
        raise ValueError('旧純公開器と同じGo1.24.2が必要')
    text = command(['go', 'list', '-deps', '-test', '-json', './...'])
    decoder, files = json.JSONDecoder(), {}
    while text.strip():
        item, end = decoder.raw_decode(text.lstrip())
        text = text.lstrip()[end:]
        if item.get('ImportPath', '').endswith('.test'):
            continue
        directory = item.get('Dir')
        if not directory:
            continue
        for field in ('GoFiles', 'CgoFiles', 'SFiles', 'CFiles', 'HFiles', 'SysoFiles', 'EmbedFiles', 'TestGoFiles', 'XTestGoFiles'):
            for name in item.get(field, []):
                path = (Path(directory) / name).resolve()
                if path.is_file():
                    files[str(path)] = sha(path)
        module = item.get('Module', {})
        if module.get('GoMod'):
            path = Path(module['GoMod']).resolve()
            files[str(path)] = sha(path)
    compiler = Path(environment['GOROOT']) / 'bin/go.exe'
    files[str(compiler)] = sha(compiler)
    return files, environment


def stop(output: Path) -> dict:
    """機能: 人工/実API/閉包と旧コードの前後不変を固定する。

    引数: output(Path)は新規証拠folder。
    返り値: dictは停止/定義/API/人工Ref。CSV/Raw/Native本文を読まない。
    """
    if output.exists():
        raise ValueError('停止先は未作成だけ')
    owned = {str(OWN / name): sha(OWN / name) for name in NAMES}
    preserved, references = {}, {}
    for name, (path, expected) in DEPENDENCIES.items():
        if sha(path) != expected:
            raise ValueError('旧停止SHA差: ' + name)
        data = json.loads(path.read_text(encoding='utf-8'))
        if data.get('成功') is not True:
            raise ValueError('旧停止が不成功')
        references[name] = ref(path)
        preserved[str(path)] = expected
        for field in ('所有コードSHA256', 'コードSHA256前'):
            preserved.update(data.get(field, {}))
    dependencies, environment = closure()
    before = {**dependencies, **preserved, **owned}
    if any(sha(Path(path)) != expected for path, expected in before.items()):
        raise ValueError('旧/新コードの事前指紋不一致')
    output.mkdir(parents=True)
    log = command(['go', 'test', '-json', '-count=1', '-cover', './...', '-args', '-export-dir', str(output / '人工')])
    (output / 'Go_test.jsonl').write_text(log, encoding='utf-8', newline='\n')
    tests = [json.loads(line) for line in log.splitlines() if line.startswith('{')]
    passed = [item['Test'] for item in tests if item.get('Action') == 'pass' and 'Test' in item and '/' not in item['Test']]
    if len(passed) != 11:
        raise ValueError('11主人工が必要')
    for name, args in [('Go_vet.txt', ['go', 'vet', './...']), ('Go_build.txt', ['go', 'build', './...']), ('API.txt', ['go', 'doc', '-all', '.'])]:
        (output / name).write_text(command(args), encoding='utf-8', newline='\n')
    after = {path: sha(Path(path)) for path in before}
    if before != after:
        raise ValueError('旧/新の所有・依存コードが変化')
    declaration, artificial = ref(output / '人工/実定義.json'), ref(output / '人工/買売人工.json')
    api = ref(output / 'API.txt')
    goroot = Path(environment['GOROOT']).resolve()
    standard = {path: digest for path, digest in dependencies.items() if Path(path).is_relative_to(goroot) and Path(path).suffix != '.exe'}
    record = {'試行': 115, 'trial': 115, '成功': True, '停止': True, '市場前': True,
              '停止UTC': datetime.now(timezone.utc).isoformat(), 'module': 'github.com/masayoshi4649/SessionTradeExecuter/threeframe115',
              '所有コードSHA256': owned, '依存停止': references, '実Go依存コードSHA256': dependencies, 'GoRootコードSHA256': standard,
              '全固定コードSHA256': before, 'コードSHA256前': before, 'コードSHA256後': after, '前後不変': True,
              'Go環境': environment, '主人工': passed, '主人工数': len(passed), '実定義': declaration, 'API': api, '人工': artificial,
              '旧Frame無加工同体': True, '追加失敗原子拒否': True, '指標未知/前史/当場構造cold': True,
              '原板/CSV/Native/11月09本文読取': False, '金融/Source/市場実行': False, '採用': False, '研究目標達成': False}
    stopped = write(output / '停止.json', record)
    return {'成功': True, '停止': stopped, '実定義': declaration, 'API': api, '人工': artificial}


def main() -> None:
    """機能: 未作成先へ115公開wrapperの停止を記録する。

    引数: CLI output(str)は新規出力folder。
    返り値: なし。少量のRefだけを表示する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(stop(args.output.resolve()), ensure_ascii=False))


if __name__ == '__main__':
    main()
