"""新しいRaw因果公表のv4出生を、同じ取得条件の128入力へ渡す。"""
from pathlib import Path
from collections import Counter
import argparse
import gzip
import hashlib
import importlib.util
import json

ROOT=Path(__file__).resolve().parents[2]


def sha(data: bytes) -> str:
    """
    機能: 入力bytesのSHA256を求める。
    引数: data(bytes)。返り値: str。
    """
    return hashlib.sha256(data).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 旧79入口を使わず全73場と0出生も保存し、因果参照を照合する。
    引数: CLI出生・公表・各SHA256・未作成出力(Path/str)。返り値: None。
    """
    parser=argparse.ArgumentParser(description='128のRaw公表出生を取得入力へ転記')
    for name in ('births','publications','output'): parser.add_argument('--'+name,type=Path,required=True)
    for name in ('births-sha256','publications-sha256'): parser.add_argument('--'+name,required=True)
    args=parser.parse_args()
    count_bytes=args.births.read_bytes();pub_bytes=args.publications.read_bytes()
    assert sha(count_bytes)==args.births_sha256 and sha(pub_bytes)==args.publications_sha256
    source=json.loads(count_bytes)
    assert source['成功'] and source['金融ラベル使用'] is False and source['Raw読取'] is False
    assert source['入力SHA256']==args.publications_sha256
    pubs_input=json.loads(gzip.decompress(pub_bytes) if pub_bytes[:2]==b'\x1f\x8b' else pub_bytes)
    pubs={p['frame']['frame']['id']:p for scene in pubs_input['scenes'] for p in scene['publications']}
    adapter=ROOT/'work/126独立出生の事前案/出生v4を渡す.py'
    assert sha(adapter.read_bytes())=='80486867fe275f2bcf2089ac4ae0b1e50349a153db2fd49b784836ea8f2537c8'
    spec=importlib.util.spec_from_file_location('旧v4の背景mask',adapter)
    old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
    by_session={s['session']:[] for s in pubs_input['scenes']};feasible=Counter()
    for event in source['出生']:
        e=event;refs={r['id']:r for r in e['frameRefs']+e['stage_refs']};current={}
        for ref in e['frameRefs']:
            if ref['width_seconds'] not in current: current[ref['width_seconds']]=pubs[ref['id']]
        for ref in refs.values():
            stamp=ref['delivered'];assert all(stamp[k]<=e['pub_stamp'][k] for k in ('time','index','source_line'))
        side=e['side'];atr=e['atr'];hold_risk=side*(e['trigger_level']-e['invalidation'])
        possible=max(10,hold_risk)<=min(125,1.5*atr,side*(e['entry_cap']-e['invalidation']))
        feasible['metadata可' if possible else '追加125上限で不可']+=1
        assert 0<=side*(e['trigger_close']-e['trigger_level'])<=.5*atr+1e-8
        assert 10-1e-8<=side*(e['trigger_close']-e['invalidation'])<=1.5*atr+1e-8
        row={'id':'128/'+e['id'],'mode':e['pattern'],'side':side,'at':e['pub_stamp'],
             'entry_cap':e['entry_cap'],'invalidation':e['invalidation'],'atr5':atr,
             'hold_boundary':e['trigger_level'],'hold_minimum':0,'minimum_risk':10,'refs':list(refs.values()),
             'fields':{'source_id':e['id'],'confirm_close':e['trigger_close'],'confirm_level':e['trigger_level'],
                       'risk_min':10,'risk_max':1.5*atr,'entry_ttl_seconds':30,'stage_refs':e['stage_refs'],
                       'background_5_15_30':{str(w//60):old.frame_mask(current.get(w)) for w in (300,900,1800)},
                       'root_extra_risk125_feasible':possible,**e['role_mask']}}
        by_session[e['session']].append(row)
    metadata=ROOT/'work/124入口の原因分析/入力.json';meta_bytes=metadata.read_bytes()
    assert sha(meta_bytes)=='b2368b1f42c16e8c96a3acd098c58a902807a3b6a5023d6d4b1e75261f3ee51b'
    scenes=[]
    for scene in json.loads(meta_bytes)['scenes']:
        row={k:scene[k] for k in ('session','contract','start','end','force_close','raw','expected_accepted','expected_quality')}
        row['events']=sorted(by_session[scene['session']],key=lambda e:(e['at']['source_line'],e['id']))
        scenes.append(row)
    assert len(scenes)==73 and sum(len(s['events']) for s in scenes)==len(source['出生'])
    model=pubs_input.get('model',{})
    value={'trial':128,'source_version':'v4_'+model.get('name','旧公表の確認'),'source_model':model,'source_entry_births_used':False,
           'publications_sha256':args.publications_sha256,'births_sha256':args.births_sha256,
           'metadata_feasibility':dict(feasible),'scenes':scenes}
    data=(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode('utf-8')
    with args.output.open('xb') as stream: stream.write(data)
    print(json.dumps({'成功':True,'出生':len(source['出生']),'全場':73,'出生有場':sum(bool(s['events']) for s in scenes),'SHA256':sha(data),'metadata':dict(feasible)},ensure_ascii=False))


if __name__=='__main__':
    main()
