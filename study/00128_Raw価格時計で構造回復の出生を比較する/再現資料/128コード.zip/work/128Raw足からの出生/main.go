package main

import (
	"bytes"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"math"
	"os"
	"sort"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

type Scene struct {
	Session    string              `json:"session"`
	Contract   string              `json:"contract"`
	Start      float64             `json:"start"`
	End        float64             `json:"end"`
	ForceClose float64             `json:"force_close"`
	Pubs       []rules.Publication `json:"publications"`
}
type Input struct {
	Scenes []Scene `json:"scenes"`
}
type Snap struct {
	Pub  rules.Publication
	View rules.Snapshot
}
type Wait struct {
	ContactMask  map[string]any
	RangeLow     float64
	RangeHigh    float64
	RangeRefs    []rules.Ref
	Path         string
	Phase        int
	First        Snap
	Second       Snap
	Boundary     float64
	Failed       bool
	Trigger      float64
	Invalidation float64
	LastBirth    float64
}
type Event struct {
	Session      string         `json:"session"`
	ID           string         `json:"id"`
	Side         int            `json:"side"`
	Pattern      string         `json:"pattern"`
	PubStamp     rules.Stamp    `json:"pub_stamp"`
	FrameRefs    []rules.Ref    `json:"frameRefs"`
	StageRefs    []rules.Ref    `json:"stage_refs"`
	TriggerClose float64        `json:"trigger_close"`
	TriggerLevel float64        `json:"trigger_level"`
	Invalidation float64        `json:"invalidation"`
	ATR          float64        `json:"atr"`
	EntryCap     float64        `json:"entry_cap"`
	EntryTTL     int            `json:"entry_ttl_seconds"`
	RoleMask     map[string]any `json:"role_mask"`
}
type Detector struct {
	Background map[int]Snap
	Scene      Scene
	History    []Snap
	Slots      map[string]*Wait
	Stats      map[string]int
	Events     []Event
}

// digest は、与えたバイト列のSHA256を返します。
//
// 引数: data([]byte)。返り値: stringは小文字16進表記です。
func digest(data []byte) string { v := sha256.Sum256(data); return hex.EncodeToString(v[:]) }

// known は、必要な値が全て既知かを返します。
//
// 引数: values(...rules.Value)。返り値: bool。未知を0へ補いません。
func known(values ...rules.Value) bool {
	for _, v := range values {
		if !v.Known {
			return false
		}
	}
	return true
}

// direction は、MA並びと両傾きの全既知・厳密同方向を判定します。
//
// 引数: t(rules.Technical)。返り値: intは±1/中立0、boolは必要値既知です。
func direction(t rules.Technical) (int, bool) {
	if !known(t.Gap, t.EMA8Delta, t.EMA21Delta) {
		return 0, false
	}
	if t.Gap.Value > 0 && t.EMA8Delta.Value > 0 && t.EMA21Delta.Value > 0 {
		return 1, true
	}
	if t.Gap.Value < 0 && t.EMA8Delta.Value < 0 && t.EMA21Delta.Value < 0 {
		return -1, true
	}
	return 0, true
}

// upper は、15/30分の当時方向と未知maskを返します。
//
// 引数: q(Snap)、side(int)。返り値: boolは既知反対無し、mapは各方向又はnilです。
func upper(q Snap, side int) (bool, map[string]any) {
	ok := true
	mask := map[string]any{}
	for _, w := range []int{900, 1800} {
		key := fmt.Sprintf("upper%d", w/60)
		mask[key] = nil
		if p, exists := q.View.Frames[w]; exists && p.Frame.Frame.PriceKnown {
			if d, k := direction(p.Frame.Frame.Technical); k {
				mask[key] = d
				if d == -side {
					ok = false
				}
			}
		}
	}
	return ok, mask
}

// momentum は、RSI/MACD増分が指定方向へともに正か判定します。
//
// 引数: q(Snap)、side(int)。返り値: boolです。
func momentum(q Snap, side int) bool {
	t := q.Pub.Frame.Frame.Technical
	s := float64(side)
	return known(t.Histogram, t.PreviousHistogram, t.RSI, t.PreviousRSI) && s*(t.Histogram.Value-t.PreviousHistogram.Value) > 0 && s*(t.RSI.Value-t.PreviousRSI.Value) > 0
}

// common は、確認に必要な値幅・勢い・量の既知性と値幅/量閾値を判定します。
//
// 引数: q(Snap)。返り値: boolです。
func common(q Snap) bool {
	t := q.Pub.Frame.Frame.Technical
	return known(t.ATR, t.PreviousATR, t.TR, t.Histogram, t.PreviousHistogram, t.RSI, t.PreviousRSI, q.View.RVOL5) && t.ATR.Value > 0 && t.PreviousATR.Value > 0 && t.TR.Value <= 2*t.PreviousATR.Value && q.View.RVOL5.Value >= .5
}

// rejection は、反転方向の実体又は逆側ヒゲを判定します。
//
// 引数: o(rules.OHLC)、side(int)。返り値: boolです。
func rejection(o rules.OHLC, side int) bool {
	if float64(side)*(o.Close-o.Open) > 0 {
		return true
	}
	span := o.High - o.Low
	if span <= 0 {
		return false
	}
	wick := math.Min(o.Open, o.Close) - o.Low
	if side < 0 {
		wick = o.High - math.Max(o.Open, o.Close)
	}
	return wick/span >= .25
}

// reference は、当時の公表を短い参照へ変換します。
//
// 引数: q(Snap)。返り値: rules.Refです。
func reference(q Snap) rules.Ref {
	f := q.Pub.Frame.Frame
	return rules.Ref{ID: f.ID, Width: f.Width, End: f.End, Delivered: q.Pub.Stamp}
}

// clear は、出生cooldownを保持して状態を初期化します。
//
// 引数: w(*Wait)。返り値: ありません。
func clear(w *Wait) { last := w.LastBirth; *w = Wait{LastBirth: last} }

// newDetector は、当場だけの価格状態を初期化します。
//
// 引数: scene(Scene)。返り値: *Detectorです。
func newDetector(scene Scene) *Detector {
	return &Detector{Background: map[int]Snap{}, Scene: scene, Slots: map[string]*Wait{}, Stats: map[string]int{}, Events: []Event{}}
}

// emit は、足終値で成立した候補を保存します。RawのLast又は約定とは扱いません。
//
// 引数: key/pattern(string)、side(int)、w(*Wait)、q(Snap)。返り値: ありません。
func (d *Detector) emit(key, pattern string, side int, w *Wait, q Snap) {
	f := q.Pub.Frame.Frame
	t := f.Technical
	_, mask := upper(q, side)
	mask["price_structure"] = true
	mask["momentum_rsi_macd"] = true
	mask["atr5"] = true
	mask["volume_rvol"] = true
	mask["bb15_known"] = q.View.BB15.Known
	mask["rvol5"] = q.View.RVOL5.Value
	mask["previous_atr5"] = t.PreviousATR.Value
	mask["tr5"] = t.TR.Value
	mask["failed_breakout_branch"] = w.Failed
	mask["volume_weak"] = q.View.RVOL5.Value < 1
	mask["two_stage_recovery"] = w.First.Pub.Frame.Frame.ID == w.Second.Pub.Frame.Frame.ID
	refs := append([]rules.Ref(nil), q.View.Refs...)
	if pattern == "T" {
		mask["T_path"] = w.Path
	}
	if pattern == "Q" {
		refs = append(refs, w.RangeRefs...)
		mask["range_low"] = w.RangeLow
		mask["range_high"] = w.RangeHigh
		mask["contact_regime"] = w.ContactMask
		mask["momentum_rsi_macd"] = nil
		mask["momentum_rule"] = "OR"
		mask["volume_very_weak"] = q.View.RVOL5.Value < .5
		mask["rsi_delta_known"] = known(t.RSI, t.PreviousRSI)
		mask["hist_delta_known"] = known(t.Histogram, t.PreviousHistogram)
		mask["rsi_delta_pass"] = known(t.RSI, t.PreviousRSI) && float64(side)*(t.RSI.Value-t.PreviousRSI.Value) > 0
		mask["hist_delta_pass"] = known(t.Histogram, t.PreviousHistogram) && float64(side)*(t.Histogram.Value-t.PreviousHistogram.Value) > 0
	}
	if pattern == "S" {
		refs = append(refs, w.RangeRefs...)
		mask["compression_low"] = w.RangeLow
		mask["compression_high"] = w.RangeHigh
		mask["S_path"] = w.Path
	}
	d.Events = append(d.Events, Event{Session: d.Scene.Session, ID: fmt.Sprintf("%s/%s/%d/%d", d.Scene.Session, pattern, side, q.Pub.Stamp.Index), Side: side, Pattern: pattern, PubStamp: q.Pub.Stamp, FrameRefs: refs, StageRefs: []rules.Ref{reference(w.First), reference(w.Second), reference(q)}, TriggerClose: f.OHLC.Close, TriggerLevel: w.Trigger, Invalidation: w.Invalidation, ATR: t.ATR.Value, EntryCap: w.Trigger + float64(side)*.5*t.ATR.Value, EntryTTL: 30, RoleMask: mask})
	d.Stats[key+"出生"]++
	w.LastBirth = q.Pub.Stamp.Time
	clear(w)
}

// second は、回復確認の水準と無効化構造を固定します。
//
// 引数: w(*Wait)、q(Snap)、side(int)、includeFirst(bool)。返り値: ありません。
func second(w *Wait, q Snap, side int, includeFirst bool) {
	o := q.Pub.Frame.Frame.OHLC
	w.Second = q
	w.Phase = 2
	if side > 0 {
		w.Trigger = o.High + 5
		w.Invalidation = o.Low - 5
		if includeFirst {
			w.Invalidation = math.Min(o.Low, w.First.Pub.Frame.Frame.OHLC.Low) - 5
		}
	} else {
		w.Trigger = o.Low - 5
		w.Invalidation = o.High + 5
		if includeFirst {
			w.Invalidation = math.Max(o.High, w.First.Pub.Frame.Frame.OHLC.High) + 5
		}
	}
}

// confirmation は、追い過ぎ・無効化距離と共通確認を判定します。
//
// 引数: w(*Wait)、q(Snap)、side(int)。返り値: boolです。
func confirmation(w *Wait, q Snap, side int) bool {
	f := q.Pub.Frame.Frame
	s := float64(side)
	a := f.Technical.ATR.Value
	return common(q) && momentum(q, side) && s*(f.OHLC.Close-w.Trigger) >= 0 && s*(f.OHLC.Close-w.Trigger) <= .5*a && s*(f.OHLC.Close-w.Invalidation) >= 10 && s*(f.OHLC.Close-w.Invalidation) <= 1.5*a
}

// armR は、過伸長/失敗突破の領域接触だけを保存します。
//
// 引数: w(*Wait)、q(Snap)、side(int)、history([]Snap)。返り値: boolは待機成立です。
func armR(w *Wait, q Snap, side int, history []Snap) bool {
	f := q.Pub.Frame.Frame
	t := f.Technical
	s := float64(side)
	if len(history) < 4 || !t.ATR.Known || t.ATR.Value <= 0 {
		return false
	}
	stretch := t.EMA21.Known && s*(f.OHLC.Close-t.EMA21.Value) <= -t.ATR.Value
	if q.View.BB15.Known {
		stretch = stretch || (side > 0 && f.OHLC.Close <= q.View.BB15.Lower) || (side < 0 && f.OHLC.Close >= q.View.BB15.Upper)
	}
	lo, hi := math.Inf(1), math.Inf(-1)
	for _, v := range history[len(history)-4 : len(history)-1] {
		o := v.Pub.Frame.Frame.OHLC
		lo = math.Min(lo, o.Low)
		hi = math.Max(hi, o.High)
	}
	failed := (side > 0 && f.OHLC.Low <= lo-5) || (side < 0 && f.OHLC.High >= hi+5)
	if !stretch && !failed {
		return false
	}
	w.Phase = 1
	w.First = q
	w.Failed = failed && !stretch
	w.Boundary = lo
	if side < 0 {
		w.Boundary = hi
	}
	return true
}

// armT は、5分方向と利用可能な上位方向から順行待機を作ります。
//
// 引数: w(*Wait)、q(Snap)、side(int)。返り値: boolです。
func armT(w *Wait, q Snap, side int) bool {
	t := q.Pub.Frame.Frame.Technical
	dir, k := direction(t)
	ok, _ := upper(q, side)
	s := float64(side)
	if !k || dir != side || !ok || !known(t.ATR, t.Histogram, t.RSI) || t.ATR.Value <= 0 || s*t.Histogram.Value <= 0 || s*(t.RSI.Value-50) < 0 || s*(t.RSI.Value-50) > 20 {
		return false
	}
	w.Phase = 1
	w.First = q
	return true
}

// pullback は、EMA/BB帯接触と減速、構造維持を判定します。
//
// 引数: q/previous(Snap)、side(int)。返り値: boolです。
func pullback(q, previous Snap, side int) bool {
	f := q.Pub.Frame.Frame
	t := f.Technical
	s := float64(side)
	if !known(t.ATR, t.EMA8, t.EMA21) || t.ATR.Value <= 0 {
		return false
	}
	a := t.ATR.Value
	o := f.OHLC
	lo := math.Min(t.EMA8.Value, t.EMA21.Value) - .25*a
	hi := math.Max(t.EMA8.Value, t.EMA21.Value) + .25*a
	contact := o.Low <= hi && o.High >= lo
	if q.View.BB15.Known {
		contact = contact || (o.Low <= q.View.BB15.Mean+.25*a && o.High >= q.View.BB15.Mean-.25*a)
	}
	slow := s*(o.Close-previous.Pub.Frame.Frame.OHLC.Close) <= 0 || (known(t.Histogram, t.PreviousHistogram) && s*(t.Histogram.Value-t.PreviousHistogram.Value) < 0)
	return contact && slow && s*(o.Close-t.EMA21.Value) >= -.5*a
}

// step は、異なる確定足だけで各状態を一段階進めます。
//
// 引数: q(Snap)は新規5分公表。返り値: ありません。
func (d *Detector) step(q Snap) {
	f := q.Pub.Frame.Frame
	if !f.PriceKnown {
		d.History = nil
		d.Background = map[int]Snap{}
		for _, w := range d.Slots {
			clear(w)
		}
		d.Stats["5分価格未知reset"]++
		return
	}
	if len(d.History) > 0 && f.End-d.History[len(d.History)-1].Pub.Frame.Frame.End != 300 {
		d.History = nil
		d.Background = map[int]Snap{}
		for _, w := range d.Slots {
			clear(w)
		}
		d.Stats["5分欠足reset"]++
	}
	d.History = append(d.History, q)
	if len(d.History) > 7 {
		d.History = d.History[len(d.History)-7:]
	}
	if q.Pub.Stamp.Time >= d.Scene.ForceClose {
		d.Stats["新規期限後5分"]++
		return
	}
	d.Stats["評価5分"]++
	defer d.refreshBackground(q)
	t := f.Technical
	if t.ATR.Known && t.ATR.Value > 0 {
		d.Stats["ATR5既知"]++
	}
	if known(t.Histogram, t.PreviousHistogram, t.RSI, t.PreviousRSI) {
		d.Stats["RSI_MACD増分既知"]++
	}
	if q.View.RVOL5.Known {
		d.Stats["RVOL5既知"]++
	}
	_, m := upper(q, 1)
	if m["upper15"] == nil {
		d.Stats["15分方向未知"]++
	}
	if m["upper30"] == nil {
		d.Stats["30分方向未知"]++
	}
	for _, pattern := range []string{"R", "T", "S", "Q"} {
		for _, side := range []int{1, -1} {
			key := fmt.Sprintf("%s/%d/", pattern, side)
			w := d.Slots[key]
			if w == nil {
				w = &Wait{}
				d.Slots[key] = w
			}
			if pattern == "Q" {
				d.stepQ(key, side, w, q)
				continue
			}
			if pattern == "S" {
				d.stepS(key, side, w, q)
				continue
			}
			if w.Phase > 0 {
				base := w.First.Pub.Frame.Frame.End
				ttl := 900.0
				if pattern == "T" {
					ttl = 1800
				}
				if w.Phase == 2 {
					base = w.Second.Pub.Frame.Frame.End
					ttl = 900
				}
				if f.End-base > ttl {
					clear(w)
					d.Stats[key+"失効"]++
				}
			}
			if w.Phase == 2 && ((side > 0 && f.OHLC.Low <= w.Invalidation) || (side < 0 && f.OHLC.High >= w.Invalidation)) {
				clear(w)
				d.Stats[key+"構造失効"]++
			}
			switch w.Phase {
			case 0:
				if w.LastBirth > 0 && q.Pub.Stamp.Time-w.LastBirth < 600 {
					continue
				}
				if pattern == "T" && d.rearmPullback(w, q, side) {
					d.Stats[key+"持続背景の新押戻し"]++
					continue
				}
				if pattern == "R" && armR2(w, q, side, d.History) {
					d.Stats[key+"同足侵入拒否"]++
					continue
				}
				if (pattern == "R" && armR(w, q, side, d.History)) || (pattern == "T" && armT(w, q, side)) {
					d.Stats[key+"領域"]++
				}
			case 1:
				if pattern == "R" {
					if momentum(q, side) && rejection(f.OHLC, side) && (!w.Failed || float64(side)*(f.OHLC.Close-w.Boundary) >= 5) {
						second(w, q, side, true)
						d.Stats[key+"中間"]++
					}
				} else if len(d.History) >= 2 && pullback(q, d.History[len(d.History)-2], side) {
					second(w, q, side, false)
					d.Stats[key+"中間"]++
				}
			case 2:
				if !confirmation(w, q, side) {
					d.Stats[key+"確認未成立"]++
					continue
				}
				if pattern == "T" {
					k := known(f.Technical.Gap, f.Technical.EMA21Delta)
					dir := 0
					if k && float64(side)*f.Technical.Gap.Value > 0 && float64(side)*f.Technical.EMA21Delta.Value >= 0 {
						dir = side
					}
					ok, _ := upper(q, side)
					t := f.Technical
					s := float64(side)
					if !k || dir != side || !ok || s*t.Histogram.Value <= 0 || s*(t.RSI.Value-50) < 0 || s*(t.RSI.Value-50) > 20 {
						d.Stats[key+"方向未回復"]++
						continue
					}
				}
				d.emit(key, pattern, side, w, q)
			}
		}
	}
}

// main は、公表だけを時系列に配送し出生と全場カバレッジを保存します。
//
// 引数: なし。返り値: ありません。Raw/金融結果/勝敗は読みません。
func main() {
	path := flag.String("input", "", "公表入力JSON")
	expected := flag.String("sha256", "", "期待SHA256")
	output := flag.String("output", "", "未作成の出生出力JSON")
	flag.Parse()
	if *path == "" || len(*expected) != 64 || *output == "" {
		panic("入力・指紋・新規先が必要")
	}
	data, e := os.ReadFile(*path)
	if e != nil {
		panic(e)
	}
	inputSHA := *expected
	if digest(data) != inputSHA {
		panic("入力SHA差")
	}
	decoded := data
	if len(data) >= 2 && data[0] == 0x1f && data[1] == 0x8b {
		reader, err := gzip.NewReader(bytes.NewReader(data))
		if err != nil {
			panic(err)
		}
		decoded, err = io.ReadAll(reader)
		closeErr := reader.Close()
		if err != nil {
			panic(err)
		}
		if closeErr != nil {
			panic(closeErr)
		}
	}
	var input Input
	if e = json.Unmarshal(decoded, &input); e != nil {
		panic(e)
	}
	if len(input.Scenes) != 73 {
		panic("全73場でない")
	}
	bank := rules.NewBank()
	all := []Event{}
	rows := []map[string]any{}
	counts := map[string]int{"R": 0, "T": 0}
	covered := 0
	for _, scene := range input.Scenes {
		if e = bank.StartSession(scene.Session, scene.Contract); e != nil {
			panic(e)
		}
		d := newDetector(scene)
		for i := 0; i < len(scene.Pubs); {
			first := scene.Pubs[i]
			j := i
			five := []rules.Publication{}
			for j < len(scene.Pubs) && scene.Pubs[j].Stamp == first.Stamp {
				p := scene.Pubs[j]
				if e = bank.Add(p); e != nil {
					panic(e)
				}
				if p.Frame.Frame.Width == 300 {
					five = append(five, p)
				}
				j++
			}
			for _, p := range five {
				f := p.Frame.Frame
				if p.Stamp.Time >= f.End+360 {
					d.Stats["5分配送fresh外"]++
					d.History = nil
					d.Background = map[int]Snap{}
					for _, w := range d.Slots {
						clear(w)
					}
					continue
				}
				last := f.OHLC.Close
				if !f.PriceKnown {
					last = 1
				}
				view, err := bank.Current(rules.Quote{Time: p.Stamp.Time, Index: p.Stamp.Index, Line: p.Stamp.Line, Last: last})
				if err != nil {
					panic(err)
				}
				d.step(Snap{Pub: p, View: view})
			}
			i = j
		}
		per := map[string]int{"R": 0, "T": 0}
		for _, event := range d.Events {
			counts[event.Pattern]++
			per[event.Pattern]++
		}
		if len(d.Events) > 0 {
			covered++
		}
		all = append(all, d.Events...)
		rows = append(rows, map[string]any{"session": scene.Session, "R": per["R"], "T": per["T"], "S": per["S"], "Q": per["Q"], "出生数": len(d.Events), "pub出生あり": len(d.Events) > 0, "実取得検査": false, "段階件数": d.Stats})
	}
	sort.SliceStable(all, func(i, j int) bool {
		if all[i].PubStamp.Time != all[j].PubStamp.Time {
			return all[i].PubStamp.Time < all[j].PubStamp.Time
		}
		return all[i].ID < all[j].ID
	})
	seen := map[string]bool{}
	for _, event := range all {
		if seen[event.ID] {
			panic("出生ID重複")
		}
		seen[event.ID] = true
		for _, ref := range append(event.FrameRefs, event.StageRefs...) {
			if ref.Delivered.Time > event.PubStamp.Time || ref.Delivered.Index > event.PubStamp.Index || ref.Delivered.Line > event.PubStamp.Line {
				panic("未来参照")
			}
		}
	}
	value := map[string]any{"成功": true, "仕様": "旧v4の技術関数同体・別の因果公表入力", "入力SHA256": inputSHA, "金融ラベル使用": false, "Raw読取": false, "Source79参照": false, "全場数": 73, "出生有場": covered, "出生0場": 73 - covered, "政策別出生数": counts, "出生": all, "全セッション": rows, "注意": "公表確定足での候補。trigger_closeは配送RawLastではない。実BBO取得・先着・損益未評価。"}
	b, e := json.MarshalIndent(value, "", "  ")
	if e != nil {
		panic(e)
	}
	b = append(b, '\n')
	file, e := os.OpenFile(*output, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0644)
	if e != nil {
		panic(e)
	}
	if _, e = file.Write(b); e != nil {
		panic(e)
	}
	file.Close()
	fmt.Printf("全73場、出生有%d/0場%d、R%d/T%d/S%d/Q%d、イベント%d、SHA%s\n", covered, 73-covered, counts["R"], counts["T"], counts["S"], counts["Q"], len(all), digest(b))
}

// armR2 は、同一足の領域侵入とClose回復を一度だけ保存します。
//
// 引数: w(*Wait)、q(Snap)、side(int)、history([]Snap)。返り値: boolは同足拒否の成立です。
func armR2(w *Wait, q Snap, side int, history []Snap) bool {
	f := q.Pub.Frame.Frame
	t := f.Technical
	s := float64(side)
	if len(history) < 4 || !t.ATR.Known || t.ATR.Value <= 0 || !momentum(q, side) || !rejection(f.OHLC, side) {
		return false
	}
	lo, hi := math.Inf(1), math.Inf(-1)
	for _, v := range history[len(history)-4 : len(history)-1] {
		o := v.Pub.Frame.Frame.OHLC
		lo = math.Min(lo, o.Low)
		hi = math.Max(hi, o.High)
	}
	levels := []float64{lo}
	extreme := f.OHLC.Low
	if side < 0 {
		levels[0] = hi
		extreme = f.OHLC.High
	}
	if t.EMA21.Known {
		levels = append(levels, t.EMA21.Value-s*t.ATR.Value)
	}
	if q.View.BB15.Known {
		bound := q.View.BB15.Lower
		if side < 0 {
			bound = q.View.BB15.Upper
		}
		levels = append(levels, bound)
	}
	for _, boundary := range levels {
		if s*(extreme-boundary) <= -5 && s*(f.OHLC.Close-boundary) >= 5 {
			w.First = q
			w.Failed = true
			w.Boundary = boundary
			second(w, q, side, true)
			return true
		}
	}
	return false
}

// armS は、過去6本の収束レンジを当時情報だけで固定します。
//
// 引数: w(*Wait)、q(Snap)、history([]Snap)。返り値: boolです。
func armS(w *Wait, q Snap, history []Snap) bool {
	if len(history) < 6 {
		return false
	}
	t := q.Pub.Frame.Frame.Technical
	if !t.ATR.Known || t.ATR.Value <= 0 {
		return false
	}
	lo, hi := math.Inf(1), math.Inf(-1)
	refs := []rules.Ref{}
	for _, v := range history[len(history)-6:] {
		o := v.Pub.Frame.Frame.OHLC
		lo = math.Min(lo, o.Low)
		hi = math.Max(hi, o.High)
		refs = append(refs, reference(v))
	}
	compressed := t.Gap.Known && math.Abs(t.Gap.Value) <= .5*t.ATR.Value
	if p, exists := q.View.Frames[900]; exists && q.View.BB15.Known && p.Frame.Frame.Technical.ATR.Known && p.Frame.Frame.Technical.ATR.Value > 0 {
		compressed = compressed || q.View.BB15.Upper-q.View.BB15.Lower <= 3*p.Frame.Frame.Technical.ATR.Value
	}
	if hi-lo > 3*t.ATR.Value || !compressed {
		return false
	}
	w.Phase = 1
	w.First = q
	w.RangeLow = lo
	w.RangeHigh = hi
	w.RangeRefs = refs
	return true
}

// stepS は、収束後の放れと、追わず待つ再試験を分けます。
//
// 引数: key(string)、side(int)、w(*Wait)、q(Snap)。返り値: ありません。
func (d *Detector) stepS(key string, side int, w *Wait, q Snap) {
	f := q.Pub.Frame.Frame
	s := float64(side)
	if w.Phase > 0 {
		base := w.First.Pub.Frame.Frame.End
		ttl := 1800.0
		if w.Phase == 2 {
			base = w.Second.Pub.Frame.Frame.End
			ttl = 900
		}
		if f.End-base > ttl {
			clear(w)
			d.Stats[key+"失効"]++
		}
	}
	if w.Phase == 2 && ((side > 0 && f.OHLC.Low <= w.Invalidation) || (side < 0 && f.OHLC.High >= w.Invalidation)) {
		clear(w)
		d.Stats[key+"構造失効"]++
	}
	switch w.Phase {
	case 0:
		if w.LastBirth > 0 && q.Pub.Stamp.Time-w.LastBirth < 600 {
			return
		}
		if armS(w, q, d.History) {
			d.Stats[key+"収束"]++
		}
	case 1:
		if len(d.History) < 2 || !common(q) || !momentum(q, side) {
			return
		}
		previous := d.History[len(d.History)-2].Pub.Frame.Frame
		boundary := w.RangeHigh
		if side < 0 {
			boundary = w.RangeLow
		}
		if s*(f.OHLC.Close-boundary) < 5 || !f.VolumeKnown || !previous.VolumeKnown || f.Volume <= previous.Volume || !known(f.Technical.TR, previous.Technical.TR) || f.Technical.TR.Value <= previous.Technical.TR.Value {
			return
		}
		w.Boundary = boundary
		w.Trigger = boundary + s*5
		w.Second = q
		w.Phase = 2
		w.Path = "break"
		w.Invalidation = f.OHLC.Low - 5
		if side < 0 {
			w.Invalidation = f.OHLC.High + 5
		}
		d.Stats[key+"放れ"]++
		if confirmation(w, q, side) {
			d.emit(key, "S", side, w, q)
		} else {
			d.Stats[key+"再試験待機"]++
		}
	case 2:
		a := f.Technical.ATR.Value
		contact := (side > 0 && f.OHLC.Low <= w.Boundary+.25*a) || (side < 0 && f.OHLC.High >= w.Boundary-.25*a)
		if !contact || !rejection(f.OHLC, side) {
			return
		}
		old := w.Invalidation
		w.Invalidation = f.OHLC.Low - 5
		if side < 0 {
			w.Invalidation = f.OHLC.High + 5
		}
		if confirmation(w, q, side) {
			w.Path = "retest"
			d.emit(key, "S", side, w, q)
		} else {
			w.Invalidation = old
			d.Stats[key+"確認未成立"]++
		}
	}
}

// persistent は、短期傾きの一時変化と背景の消失を区別します。
//
// 引数: q(Snap)、side(int)。返り値: boolです。
func persistent(q Snap, side int) bool {
	t := q.Pub.Frame.Frame.Technical
	s := float64(side)
	ok, _ := upper(q, side)
	return known(t.Gap, t.EMA21Delta) && s*t.Gap.Value > 0 && s*t.EMA21Delta.Value >= 0 && ok
}

// refreshBackground は、当足の全判定後にだけ背景cacheを更新します。
//
// 引数: q(Snap)。返り値: ありません。
func (d *Detector) refreshBackground(q Snap) {
	for _, side := range []int{1, -1} {
		if !persistent(q, side) {
			delete(d.Background, side)
			continue
		}
		w := &Wait{}
		if armT(w, q, side) {
			d.Background[side] = q
		} else if old, ok := d.Background[side]; ok && q.Pub.Frame.Frame.End-old.Pub.Frame.Frame.End > 1800 {
			delete(d.Background, side)
		}
	}
}

// rearmPullback は、前足までの背景を使い当足を新しい押戻しへ保存します。
//
// 引数: w(*Wait)、q(Snap)、side(int)。返り値: boolです。
func (d *Detector) rearmPullback(w *Wait, q Snap, side int) bool {
	old, ok := d.Background[side]
	if !ok || !persistent(q, side) || len(d.History) < 2 {
		return false
	}
	delta := q.Pub.Frame.Frame.End - old.Pub.Frame.Frame.End
	if delta <= 0 || delta > 1800 || !pullback(q, d.History[len(d.History)-2], side) {
		return false
	}
	w.First = old
	second(w, q, side, false)
	w.Path = "background_persist"
	return true
}

// strongCounter は、既知の強く非減速な逆向きトレンドを拒否します。
//
// 引数: q(Snap)、side(int)。返り値: boolは逆張り拒否です。
func strongCounter(q Snap, side int) bool {
	frames := []rules.Publication{q.Pub}
	if p, ok := q.View.Frames[1800]; ok && p.Frame.Frame.PriceKnown {
		frames = append(frames, p)
	}
	for _, p := range frames {
		dir, k := direction(p.Frame.Frame.Technical)
		a := p.Frame.DMI
		if k && dir == -side && known(a.ADX, a.PreviousADX) && a.ADX.Value >= 25 && a.ADX.Value >= a.PreviousADX.Value {
			return true
		}
	}
	return false
}

// weak は、局所の方向の弱さを既知値だけから判定します。
//
// 引数: q(Snap)。返り値: boolとmapは成立と各当時maskです。
func weak(q Snap) (bool, map[string]any) {
	t := q.Pub.Frame.Frame.Technical
	a := q.Pub.Frame.DMI
	gap := known(t.Gap, t.ATR) && t.ATR.Value > 0 && math.Abs(t.Gap.Value) <= .5*t.ATR.Value
	low := a.ADX.Known && a.ADX.Value <= 20
	fall := known(a.ADX, a.PreviousADX) && a.ADX.Value < a.PreviousADX.Value
	return gap || low || fall, map[string]any{"gap_compressed": gap, "adx5_low": low, "adx5_falling": fall, "adx5_known": a.ADX.Known}
}

// armQ は、前6本レンジ内の接触と拒否足を保存します。
//
// 引数: w(*Wait)、q(Snap)、side(int)、history([]Snap)。返り値: boolです。
func armQ(w *Wait, q Snap, side int, history []Snap) bool {
	if len(history) < 7 || strongCounter(q, side) {
		return false
	}
	f := q.Pub.Frame.Frame
	t := f.Technical
	ok, mask := weak(q)
	if !ok || !t.ATR.Known || t.ATR.Value <= 0 || !rejection(f.OHLC, side) {
		return false
	}
	lo, hi := math.Inf(1), math.Inf(-1)
	refs := []rules.Ref{}
	for _, v := range history[len(history)-7 : len(history)-1] {
		o := v.Pub.Frame.Frame.OHLC
		lo = math.Min(lo, o.Low)
		hi = math.Max(hi, o.High)
		refs = append(refs, reference(v))
	}
	if hi <= lo || f.OHLC.Close < lo || f.OHLC.Close > hi {
		return false
	}
	contact := (side > 0 && f.OHLC.Low <= lo+.2*(hi-lo)) || (side < 0 && f.OHLC.High >= hi-.2*(hi-lo))
	if !contact {
		return false
	}
	w.First = q
	w.Second = q
	w.Phase = 2
	w.RangeLow = lo
	w.RangeHigh = hi
	w.RangeRefs = refs
	w.ContactMask = mask
	w.Trigger = f.OHLC.Close + float64(side)*5
	w.Invalidation = f.OHLC.Low - 5
	if side < 0 {
		w.Invalidation = f.OHLC.High + 5
	}
	return true
}

// confirmQ は、二足の回復とRSI又はHist改善、既知正量を確認します。
//
// 引数: w(*Wait)、q(Snap)、side(int)。返り値: boolです。
func confirmQ(w *Wait, q Snap, side int) bool {
	f := q.Pub.Frame.Frame
	t := f.Technical
	s := float64(side)
	v := q.View.RVOL5
	rsi := known(t.RSI, t.PreviousRSI) && s*(t.RSI.Value-t.PreviousRSI.Value) > 0
	hist := known(t.Histogram, t.PreviousHistogram) && s*(t.Histogram.Value-t.PreviousHistogram.Value) > 0
	if strongCounter(q, side) || !rsi && !hist || !known(t.ATR, t.PreviousATR, t.TR, v) || t.ATR.Value <= 0 || t.PreviousATR.Value <= 0 || t.TR.Value < 0 || t.TR.Value > 2*t.PreviousATR.Value || !f.VolumeKnown || f.Volume <= 0 || v.Value <= 0 || v.Value > 1.5 {
		return false
	}
	if f.OHLC.Close < w.RangeLow || f.OHLC.Close > w.RangeHigh {
		return false
	}
	delta := s * (f.OHLC.Close - w.Trigger)
	risk := s * (f.OHLC.Close - w.Invalidation)
	return delta >= 0 && delta <= .5*t.ATR.Value && risk >= 10 && risk <= 1.5*t.ATR.Value
}

// stepQ は、旧setup失効後も当足を新接触として再評価します。
//
// 引数: key(string)、side(int)、w(*Wait)、q(Snap)。返り値: ありません。
func (d *Detector) stepQ(key string, side int, w *Wait, q Snap) {
	f := q.Pub.Frame.Frame
	if w.Phase > 0 && f.End-w.First.Pub.Frame.Frame.End > 300 {
		clear(w)
		d.Stats[key+"失効"]++
	}
	if w.Phase == 2 && ((side > 0 && f.OHLC.Low <= w.Invalidation) || (side < 0 && f.OHLC.High >= w.Invalidation)) {
		clear(w)
		d.Stats[key+"構造失効"]++
	}
	if w.Phase == 0 {
		if w.LastBirth > 0 && q.Pub.Stamp.Time-w.LastBirth < 600 {
			return
		}
		if armQ(w, q, side, d.History) {
			d.Stats[key+"接触拒否"]++
		}
		return
	}
	if f.End-w.First.Pub.Frame.Frame.End == 300 {
		if confirmQ(w, q, side) {
			d.emit(key, "Q", side, w, q)
		} else {
			clear(w)
			d.Stats[key+"確認未成立"]++
			if armQ(w, q, side, d.History) {
				d.Stats[key+"接触拒否"]++
			}
		}
	}
}
