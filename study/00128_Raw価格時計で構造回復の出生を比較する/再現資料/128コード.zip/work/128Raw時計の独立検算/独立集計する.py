"""機能: 128の政策選択と主要140集計をRoot関数を使わず照合する。

引数: CLIで2系統のmodelと結果・出生入力・集計の既知SHA256を必須指定する。
返り値: なし。系統別の独立検算JSONを新規保存する。Rawを読まない。
"""

import argparse
import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path


def sha(path: Path) -> str:
    """機能: ファイルのSHA256を求める。

    引数: path (Path) は対象。
    返り値: str は小文字16進表記。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def first(rows: list[dict], only: str | None = None) -> dict | None:
    """機能: 実取得順と既定優先から最初の一例を独立選択する。

    引数: rows (list[dict]) は同場の取得、only (str | None) はmode限定。
    返り値: dict | None は選んだ例又は全Raw未解決/取得なし。
    """
    groups = {}
    for row in rows:
        if only is not None and row["mode"] != only:
            continue
        q = row["case"]["original"]["entry"]
        groups.setdefault((q["time"], q["index"], q["source_line"]), []).append(row)
    for key in sorted(groups):
        current = groups[key]
        role = min("RTSQ".index(r["mode"]) for r in current)
        current = [r for r in current if "RTSQ".index(r["mode"]) == role]
        distance = min(r["risk"] for r in current)
        current = [r for r in current if r["risk"] == distance]
        if len({r["case"]["original_side"] for r in current}) > 1:
            continue
        return sorted(current, key=lambda r: r["case"]["id"])[0]
    return None


def pick(row: dict, policy: str, axis: str) -> dict:
    """機能: FRだけを同時点の実逆側へ切り替える。

    引数: row (dict)、policy/axis (str) は例・政策・価格軸。
    返り値: dict は固定された元/逆候補。
    """
    return row["case"][("chart_" if axis == "Last" else "") + ("reverse" if policy == "FR" else "original")]


# ----------------------------------------
def audit(data: dict, source: dict, aggregate: dict, helper: object) -> dict:
    """機能: 保存票・独自F0選択・140比較・固定前48/後25の集計を検算する。

    引数: data/source/aggregate (dict) は結果・出生入力・集計、helper (object) は自作算術。
    返り値: dict は照合した値と範囲。不一致時はAssertionError。
    """
    assert data["success"] and data["trial"] == 128 and data["candidate_quantity"] == 1
    assert not data["portfolio_pnl"] and not data["source_entry_births_used"]
    assert len(data["scenes"]) == len(source["scenes"]) == 73
    POLICIES = ("F0", "FR", "A0", "R1", "T1", "S1", "Q1")
    selected = {p: [] for p in POLICIES}
    counts = Counter()
    sessions = []
    for scene, original in zip(data["scenes"], source["scenes"]):
        sid = scene["session"]
        sessions.append(sid)
        assert sid == original["session"] and scene["success"]
        assert scene["actual_sha256"] == original["raw"]["sha256"] and scene["stat_before"] == scene["stat_after"]
        assert scene["expected_quality"] == original["expected_quality"] == scene["quality"] and scene["raw_passes"] == 1
        assert [b["event"] for b in scene["births"]] == original["events"]
        births = {b["event"]["id"]: b for b in scene["births"]}
        cases = {c["id"]: c for c in scene["cases"]}
        assert len(births) == len(scene["births"]) and len(cases) == len(scene["cases"])
        assert set(cases) == {k for k, b in births.items() if b["status"] == "filled"}
        rows = []
        for identifier, birth in births.items():
            e = birth["event"]
            maximum = min(125, 1.5 * e["atr5"])
            assert e["minimum_risk"] == 10
            helper.equal(birth["maximum_risk"], maximum, "最大risk")
            helper.equal(birth["expires"], min(e["at"]["time"] + 30, original["force_close"]), "TTL")
            counts[birth["status"]] += 1
            request, evaluation = birth["request"], birth["evaluation"]
            if request is not None:
                assert all(request[k] == e["at"][k] for k in ("time", "index", "source_line"))
                assert e["side"] * (request["last"] - e["hold_boundary"]) >= e["hold_minimum"]
                assert e["side"] * (request["last"] - e["entry_cap"]) <= 0
            if evaluation is not None:
                assert request is not None and evaluation["time"] >= request["time"] + 1 and evaluation["time"] < birth["expires"]
                assert evaluation["time"] < original["force_close"] and evaluation["index"] > request["index"] and evaluation["source_line"] > request["source_line"]
                assert evaluation["quote_ok"] and 0 < evaluation["bid"] < evaluation["ask"]
                price = evaluation["ask"] if e["side"] > 0 else evaluation["bid"]
                helper.equal(birth["risk"], e["side"] * (price - e["invalidation"]), "評価risk")
            if identifier not in cases:
                assert birth["entry"] is None
                continue
            c = cases[identifier]
            assert c["source_event"] == e and c["request_quote"] == request and birth["entry"] == evaluation
            assert e["minimum_risk"] <= birth["risk"] <= maximum
            assert c["original"]["entry"] == c["reverse"]["entry"] == birth["entry"]
            price = evaluation["ask"] if e["side"] > 0 else evaluation["bid"]
            assert c["original"]["entry_price"] == price and e["side"] * (price - e["entry_cap"]) <= 0
            assert e["side"] * (evaluation["last"] - e["hold_boundary"]) >= e["hold_minimum"]
            assert c["reverse"]["entry_price"] == (evaluation["bid"] if e["side"] > 0 else evaluation["ask"])
            assert c["original"]["birth"]["side"] == e["side"] == c["original_side"] and c["reverse"]["birth"]["side"] == -e["side"]
            for name in ("chart_original", "chart_reverse"):
                assert c[name]["entry"] == evaluation and c[name]["entry_price"] == evaluation["last"]
                assert all(o["net0"] is None and o["net5"] is None for o in c[name]["outcomes"])
            rows.append({"session": sid, "case": c, "risk": birth["risk"], "mode": e["mode"]})
        chosen = first(rows)
        if chosen:
            selected["F0"].append(chosen)
            selected["FR"].append(chosen)
        selected["A0"].extend(sorted(rows, key=lambda r: (tuple(r["case"]["original"]["entry"][k] for k in ("time", "index", "source_line")), "RTSQ".index(r["mode"]), r["risk"], r["case"]["id"])))
        for mode in "RTSQ":
            chosen = first(rows, mode)
            if chosen:
                selected[mode + "1"].append(chosen)
    assert len(sessions) == len(set(sessions)) == 73 and sessions == sorted(sessions)
    assert sum(counts.values()) == sum(len(s["events"]) for s in source["scenes"])
    assert len(selected["A0"]) == counts["filled"]
    stats, coverage = {}, {}
    values_checked = 0
    for policy, rows in selected.items():
        identities = [{"session": r["session"], "id": r["case"]["id"]} for r in rows]
        assert identities == aggregate["政策取得ID"][policy]
        filled_sessions = {r["session"] for r in rows}
        cov = {"target_sessions": 73, "filled_sessions": len(filled_sessions), "entries": len(rows),
               "empty_sessions": [s for s in sessions if s not in filled_sessions], "all_sessions_filled": len(filled_sessions) == 73}
        assert cov == aggregate["coverage"][policy]
        coverage[policy], stats[policy] = cov, {}
        for axis in ("BBO", "Last"):
            stats[policy][axis] = {}
            for horizon in (1800, 3600):
                stats[policy][axis][str(horizon)] = {}
                for width in (25, 50, 100, 125, 200):
                    values = helper.independent_stats(rows, policy, axis, horizon, width)
                    saved = aggregate["集計"][policy][axis][str(horizon)][str(width)]
                    assert set(values) == set(saved)
                    for key, value in values.items():
                        helper.equal(saved[key], value, f"{policy}/{axis}/{horizon}/{width}/{key}")
                        values_checked += 1
                    stats[policy][axis][str(horizon)][str(width)] = values
    assert dict(counts) == aggregate["出生状態"]
    assert aggregate["出生mode"] == dict(Counter(e["mode"] for s in source["scenes"] for e in s["events"]))

    assert aggregate["出生数"] == sum(counts.values()) and aggregate["全取得候補数"] == counts["filled"]
    assert aggregate["主先着70達成"] == stats["F0"]["BBO"]["3600"]["125"]["target70"]
    assert aggregate["主全73場取得"] == coverage["F0"]["all_sessions_filled"]
    assert aggregate["主両条件達成"] == (stats["F0"]["BBO"]["3600"]["125"]["target70"] is True and coverage["F0"]["all_sessions_filled"])
    chronological = {}
    for label, part in (("前48場", sessions[:48]), ("後25場", sessions[48:])):
        group = [r for r in selected["F0"] if r["session"] in part]
        report = {"対象場数": len(part), "取得場数": len({r["session"] for r in group}),
                  "主": helper.independent_stats(group, "F0", "BBO", 3600, 125),
                  "実逆": helper.independent_stats(group, "FR", "BBO", 3600, 125)}
        saved = aggregate["時系列参考"][label]
        assert set(saved) == set(report)
        for key in ("対象場数", "取得場数"):
            assert saved[key] == report[key]
            values_checked += 1
        for key in ("主", "実逆"):
            assert set(saved[key]) == set(report[key])
            for item, value in report[key].items():
                helper.equal(saved[key][item], value, f"{label}/{key}/{item}")
                values_checked += 1
        chronological[label] = report
    return {"成功": True, "試行": 128, "全出生": sum(counts.values()), "全取得": counts["filled"],
            "全場": 73, "政策ID/coverage同体": True, "全140組": True, "集計値照合数": values_checked,
            "出生状態": dict(counts), "coverage": coverage,
            "主H60_125": {p: stats[p]["BBO"]["3600"]["125"] for p in POLICIES},
            "H60_Last125": {p: stats[p]["Last"]["3600"]["125"] for p in POLICIES},
            "時系列参考": chronological, "Root集計関数import": False,
            "独立算術": "自作124検算器のFraction式のみ再用、政策選択は別実装。",
            "自然Raw再読": False, "金融再生": False,
            "限界": "bootstrap・全表・Raw先着最初性の再走査は対象外。"}


# ----------------------------------------
def load_helper() -> object:
    """機能: 自作124検算の固定算術だけを読み込む。

    引数: なし。
    返り値: object はpickをFR専用へ差し替えた補助モジュール。
    """
    path = Path(__file__).resolve().parents[2] / "work/124正逆の独立検算/検算する.py"
    assert sha(path) == "0305f507a74f9728fbdb1ecabe406a3bfcb2f8657a4d1ee2556ca50dbe6585be"
    spec = importlib.util.spec_from_file_location("own_independent_arithmetic124", path)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    helper.pick = pick
    return helper


# ----------------------------------------
def main() -> None:
    """機能: Root通知後に明示した指紋でだけ自然128の保存結果を検算する。

    引数: CLI model (str)、result/input/aggregate-sha256 (str)、output (Path | None)。
    返り値: None。新規先へ系統別証跡を保存し、読み書き前後の指紋を照合する。
    """
    parser = argparse.ArgumentParser(description="128の即時/同値遅延を結果SHA通知後に独立検算する")
    parser.add_argument("--model", choices=("gap300", "gap300_delay60"), required=True)
    for kind in ("result", "input", "aggregate"):
        parser.add_argument("--" + kind + "-sha256", required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    for value in (args.result_sha256, args.input_sha256, args.aggregate_sha256):
        assert len(value) == 64 and all(c in "0123456789abcdef" for c in value), "期待SHA256が必要"
    root = Path(__file__).resolve().parents[2]
    own = root / "work/128Raw時計の評価"
    result = own / f"{args.model}結果.json"
    source = own / f"{args.model}入力.json"
    aggregate = own / f"{args.model}集計/集計.json"
    helper_path = root / "work/124正逆の独立検算/検算する.py"
    fixed = {result: args.result_sha256, source: args.input_sha256, aggregate: args.aggregate_sha256,
             helper_path: "0305f507a74f9728fbdb1ecabe406a3bfcb2f8657a4d1ee2556ca50dbe6585be"}
    before = {str(p): sha(p) for p in (*fixed, Path(__file__).resolve())}
    assert all(before[str(p)] == expected for p, expected in fixed.items())
    data, source_data, aggregate_data = [json.loads(p.read_bytes()) for p in (result, source, aggregate)]
    assert data["input_sha256"] == args.input_sha256
    assert source_data["trial"] == 128 and not source_data["source_entry_births_used"]
    assert source_data["source_model"]["name"] == args.model
    assert aggregate_data["再生結果SHA256"] == args.result_sha256 and aggregate_data["出生入力SHA256"] == args.input_sha256
    out = audit(data, source_data, aggregate_data, load_helper())
    after = {str(p): sha(p) for p in (*fixed, Path(__file__).resolve())}
    assert before == after
    out.update({"model": args.model, "前SHA256": before, "後SHA256": after, "前後不変": True})
    dest = args.output or Path(__file__).resolve().parent / f"{args.model}の独立検算.json"
    with dest.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(out, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"成功": True, "model": args.model, "SHA256": sha(dest), "照合値": out["集計値照合数"],
                      "主": out["主H60_125"]["F0"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
