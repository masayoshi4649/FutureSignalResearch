"""機能: 128独立検算器を自然市場データなしで検査する。

引数: なし。人工73場と人工気配をメモリー上で作る。
返り値: なし。人工検査.jsonを新規保存する。
"""

import contextlib
import copy
import hashlib
import importlib.util
import io
import json
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

BASE=Path(__file__).resolve().parent
CODE=BASE/'独立集計する.py'
spec=importlib.util.spec_from_file_location('独立128の人工対象',CODE)
target=importlib.util.module_from_spec(spec)
spec.loader.exec_module(target)
HELPER=target.load_helper()
POLICIES=('F0','FR','A0','R1','T1','S1','Q1')


def quote(time: int, index: int, line: int, last: int=1000) -> dict:
    """機能: 正常BBOを持つ人工気配を作る。

    引数: time/index/line/last (int) は時計・順序・価格。
    返り値: dict は人工の気配。
    """
    return {'time':time,'index':index,'source_line':line,'last':last,'bid':last-5,'ask':last,'quote_ok':True}


def candidate(entry: dict, side: int, chart: bool=False) -> dict:
    """機能: 同Raw正逆の人工観測を作る。

    引数: entry (dict)、side (int)、chart (bool) は取得気配・向き・Last参考指定。
    返り値: dict は2期限5幅の確定票。
    """
    price=entry['last'] if chart else entry['ask'] if side>0 else entry['bid']
    observations=[]
    for horizon in (1800,3600):
        touches=[]
        for width in (25,50,100,125,200):
            q=quote(entry['time']+10,2,3,1005+width)
            touches.append({'width':width,'direction':side,'quote':q})
        endpoint=quote(entry['time']+horizon,3,4,1100)
        points=side*((endpoint['last'] if chart else endpoint['bid'] if side>0 else endpoint['ask'])-price)
        observations.append({'seconds':horizon,'deadline':entry['time']+horizon,'status':'complete',
                             'touches':touches,'endpoint':endpoint,'points':points,
                             'net0':None if chart else points*100-77,'net5':None if chart else points*100-1077})
    return {'status':'filled','birth':{'side':side},'entry':entry,'entry_price':price,'outcomes':observations}


def fixture(with_births: bool) -> tuple:
    """機能: 0又は3出生の人工73場と比較正本を構成する。

    引数: with_births (bool) は2取得と1棄却の追加指定。
    返り値: tuple は人工結果・出生入力・集計。
    """
    scenes=[];sources=[];rows=[];counts={}
    for index in range(73):
        start=index*10000
        sid=f'人工場{index:03d}'
        original={'session':sid,'start':start,'end':start+5000,'force_close':start+4500,
                  'raw':{'path':'存在しない人工Raw','sha256':'a'*64},'expected_quality':{'人工':1},'events':[]}
        scene={'session':sid,'success':True,'actual_sha256':'a'*64,'stat_before':{'人工':1},'stat_after':{'人工':1},
               'quality':{'人工':1},'expected_quality':{'人工':1},'raw_passes':1,'births':[],'cases':[]}
        if with_births and index in (0,1,48):
            mode='R' if index==0 else 'Q'
            event={'id':f'人工/{index}','mode':mode,'side':1,'at':{'time':start+100,'index':0,'source_line':1},
                   'atr5':100,'minimum_risk':10,'entry_cap':1100,'invalidation':900,'hold_boundary':950,'hold_minimum':0}
            birth={'event':event,'maximum_risk':125,'expires':start+130,'status':'birth_cap_rejected',
                   'request':None,'evaluation':None,'entry':None,'risk':None}
            if index!=1:
                request=quote(start+100,0,1);entry=quote(start+101,1,2)
                birth.update({'status':'filled','request':request,'evaluation':entry,'entry':entry,'risk':100})
                case={'id':event['id'],'source_event':event,'request_quote':request,'original_side':1,
                      'original':candidate(entry,1),'reverse':candidate(entry,-1),
                      'chart_original':candidate(entry,1,True),'chart_reverse':candidate(entry,-1,True)}
                scene['cases'].append(case)
                rows.append({'session':sid,'case':case,'risk':100,'mode':mode})
            counts[birth['status']]=counts.get(birth['status'],0)+1
            scene['births'].append(birth);original['events'].append(event)
        scenes.append(scene);sources.append(original)
    selected={p:rows[:] if p in ('F0','FR','A0') else [r for r in rows if r['mode']==p[0]] for p in POLICIES}
    coverage={p:{'target_sessions':73,'filled_sessions':len(values),'entries':len(values),
                 'empty_sessions':[s['session'] for s in scenes if s['session'] not in {r['session'] for r in values}],
                 'all_sessions_filled':False} for p,values in selected.items()}
    stats={p:{axis:{str(h):{str(w):HELPER.independent_stats(values,p,axis,h,w) for w in (25,50,100,125,200)} for h in (1800,3600)} for axis in ('BBO','Last')} for p,values in selected.items()}
    chronological={}
    for label,part in (('前48場',scenes[:48]),('後25場',scenes[48:])):
        ids={s['session'] for s in part};group=[r for r in rows if r['session'] in ids]
        chronological[label]={'対象場数':len(part),'取得場数':len(group),
                              '主':HELPER.independent_stats(group,'F0','BBO',3600,125),
                              '実逆':HELPER.independent_stats(group,'FR','BBO',3600,125)}
    data={'success':True,'trial':128,'candidate_quantity':1,'portfolio_pnl':False,'source_entry_births_used':False,'scenes':scenes}
    source={'scenes':sources}
    aggregate={'政策取得ID':{p:[{'session':r['session'],'id':r['case']['id']} for r in values] for p,values in selected.items()},
               'coverage':coverage,'集計':stats,'出生状態':counts,'出生mode':{'R':1,'Q':2} if with_births else {},'出生数':3 if with_births else 0,'全取得候補数':2 if with_births else 0,
               '主先着70達成':True if with_births else None,'主全73場取得':False,'主両条件達成':False,'時系列参考':chronological}
    return data,source,aggregate


class ArtificialTests(unittest.TestCase):
    """機能: 独自選択・可変母数・指紋必須性の人工検査をまとめる。

    引数: unittestがケースを生成する。
    返り値: 各検査はNoneで、不一致時に失敗する。
    """

    def test_first_physical_order_and_tie(self) -> None:
        """機能: 後のRを優先せず、同Raw反対tieではRaw全体を見送る。

        引数: self (ArtificialTests)。
        返り値: None。
        """
        def row(time: int, mode: str, side: int, risk: float, name: str) -> dict:
            """機能: 選択だけに必要な人工取得を作る。

            引数: time (int)、mode/name (str)、side (int)、risk (float)。
            返り値: dict は選択票。
            """
            return {'mode':mode,'risk':risk,'case':{'id':name,'original_side':side,'original':{'entry':quote(time,time,time+1)}}}
        q=row(100,'Q',1,20,'早Q');r=row(101,'R',1,20,'遅R')
        self.assertIs(target.first([r,q]),q)
        a=row(100,'R',1,10,'A');b=row(100,'R',-1,10,'B');t=row(100,'T',1,5,'T')
        self.assertIs(target.first([a,b,t,r]),r)
        same=row(100,'R',1,10,'C')
        self.assertIs(target.first([same,a]),a)
        tiny=row(100,'R',-1,10-1e-10,'極小差')
        self.assertIs(target.first([a,tiny]),tiny)

    def test_zero_all73_and_variable_births(self) -> None:
        """機能: 全73が0取得でも保持し、650固定を要求しない。

        引数: self (ArtificialTests)。
        返り値: None。
        """
        blank=target.audit(*fixture(False),HELPER)
        self.assertEqual(blank['全出生'],0)
        self.assertEqual(blank['coverage']['F0']['empty_sessions'],[f'人工場{i:03d}' for i in range(73)])
        populated=target.audit(*fixture(True),HELPER)
        self.assertEqual((populated['全出生'],populated['全取得']),(3,2))
        self.assertEqual(populated['主H60_125']['F0']['forward'],2)
        self.assertEqual(populated['主H60_125']['FR']['adverse'],2)
        self.assertEqual(populated['時系列参考']['前48場']['取得場数'],1)
        self.assertEqual(populated['時系列参考']['後25場']['取得場数'],1)

    def test_changed_count_or_temporal_value_rejected(self) -> None:
        """機能: 件数又は期間別分母の改変を独立照合で拒否する。

        引数: self (ArtificialTests)。
        返り値: None。
        """
        data,source,aggregate=fixture(True)
        bad=copy.deepcopy(aggregate);bad['出生数']=650
        with self.assertRaises(AssertionError):target.audit(data,source,bad,HELPER)
        bad=copy.deepcopy(aggregate);bad['時系列参考']['後25場']['主']['forward']=2
        with self.assertRaises(AssertionError):target.audit(data,source,bad,HELPER)
        bad=copy.deepcopy(data);bad['scenes'].pop()
        with self.assertRaises(AssertionError):target.audit(bad,source,aggregate,HELPER)

    def test_expected_sha_mandatory_before_any_file(self) -> None:
        """機能: 期待SHAなしのCLIが結果を開く前に終了することを確認する。

        引数: self (ArtificialTests)。
        返り値: None。
        """
        for model in ('gap300','gap300_delay60'):
            with patch.object(sys,'argv',['独立集計する.py','--model',model]),patch.object(target,'sha',side_effect=AssertionError('結果を開いた')) as guard,contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit) as stop:target.main()
                self.assertEqual(stop.exception.code,2)
                self.assertEqual(guard.call_count,0)


# ----------------------------------------
if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(ArtificialTests)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    assert result.wasSuccessful()
    output={'成功':True,'試行':128,'人工主検査数':result.testsRun,'自然128入力/足/結果読取':False,
            'Root集計関数import':False,'算術のみ自作124検算を再用':True,
            'ソースSHA256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (CODE,Path(__file__).resolve())}}
    dest=BASE/'人工検査.json'
    with dest.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(output,ensure_ascii=False))
