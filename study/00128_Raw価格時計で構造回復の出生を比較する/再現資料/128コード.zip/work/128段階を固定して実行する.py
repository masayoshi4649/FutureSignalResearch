"""Raw足生成前F0と、金融前F1を分けて128を実行する。"""
from pathlib import Path
from datetime import datetime,timezone
import argparse
import hashlib
import json
import subprocess
import sys

ROOT=Path(__file__).resolve().parent.parent
OWN=ROOT/'work/128Raw時計の評価'
FORMAL=ROOT/'study/00128_Raw価格時計で構造回復の出生を比較する'
BAR=ROOT/'work/128Raw価格時計の全場足生成'
BIRTH=ROOT/'work/128Raw足からの出生'
ENGINE=ROOT/'work/128Raw出生の再生器'
AGG=ROOT/'work/128Raw出生の集計'
MODELS=('gap300','gap300_delay60')


def sha(path: Path) -> str:
    """
    機能: 指定ファイル全体のSHA256を返す。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def save(path: Path,value: dict) -> None:
    """
    機能: UTF-8記録を未作成先へだけ保存する。
    引数: path(Path)、value(dict)。返り値: None。
    """
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')


# ----------------------------------------
def verify(fixed: dict) -> None:
    """
    機能: 保存した全ファイルの指紋を再照合する。
    引数: fixed(dict)。返り値: None。
    """
    for name,expected in fixed['ファイル'].items():
        assert sha(Path(name))==expected,name


# ----------------------------------------
def main() -> None:
    """
    機能: コード事前固定→生成入力固定→モデル別の再生・集計を行う。
    引数: CLI mode(str)、model(str)。返り値: None。
    """
    parser=argparse.ArgumentParser(description='128の二段階固定と金融評価')
    parser.add_argument('--mode',choices=('F0','F1','再生','集計'),required=True)
    parser.add_argument('--model',choices=MODELS)
    args=parser.parse_args();OWN.mkdir(exist_ok=True)
    if args.mode=='F0':
        folders=(BAR,BIRTH,ENGINE,AGG,ROOT/'work/三時間軸の公開器',ROOT/'work/115三時間軸と方向性の公開',ROOT/'work/118複数技法の入口条件')
        files={Path(__file__).resolve(),ROOT/'work/124入口の原因分析/集計する.py',ROOT/'work/126独立出生の事前案/出生v4を渡す.py'}
        for folder in folders:
            files.update(p for p in folder.rglob('*') if p.is_file() and (p.suffix in ('.go','.py') or p.name=='go.mod'))
        files.update(FORMAL.glob('*.md'));files.update((FORMAL/'根拠').glob('*.md'));files.add(AGG/'条件.md')
        files.update(p for p in BAR.glob('*.md') if p.is_file())
        for folder in (BAR,BIRTH,ENGINE):
            exes=list(folder.glob('*.exe'));assert len(exes)==1,(folder,exes);files.add(exes[0])
        files.add(ROOT/'work/122全場入力/入力.json');files.add(ROOT/'work/124入口の原因分析/入力.json')
        fixed={'成功':True,'試行':128,'段階':'F0・新足生成前','UTC':datetime.now(timezone.utc).isoformat(),
               '主':'gap300即時・F0最初取得・実BBO・H60±125・全73取得とresolved70%',
               '対照':'同じ完成足をEnd+60以降の採用Rawへ配送。gap60は品質診断。',
               'ファイル':{str(p):sha(p) for p in sorted(files)}}
        save(OWN/'F0.json',fixed);print(json.dumps({'F0':sha(OWN/'F0.json'),'ファイル数':len(files)},ensure_ascii=False));return
    f0=json.loads((OWN/'F0.json').read_text(encoding='utf-8'));verify(f0)
    if args.mode=='F1':
        files={}
        for model in MODELS:
            for path in (ROOT/'work/128全場のRaw公表'/f'{model}.json.gz',OWN/f'{model}出生.json',OWN/f'{model}入力.json'):
                files[str(path)]=sha(path)
            source=json.loads((OWN/f'{model}入力.json').read_text(encoding='utf-8'))
            assert source['trial']==128 and len(source['scenes'])==73
        save(OWN/'F1.json',{'成功':True,'試行':128,'段階':'F1・金融前','F0_SHA256':sha(OWN/'F0.json'),
                            'UTC':datetime.now(timezone.utc).isoformat(),'ファイル':files})
        print(json.dumps({'F1':sha(OWN/'F1.json')},ensure_ascii=False));return
    f1=json.loads((OWN/'F1.json').read_text(encoding='utf-8'));verify(f1)
    assert f1['F0_SHA256']==sha(OWN/'F0.json') and args.model
    model=args.model;input_path=OWN/f'{model}入力.json';output=OWN/f'{model}結果.json'
    if args.mode=='再生':
        assert not output.exists()
        command=[str(ENGINE/'独立出生の再生.exe'),'--input',str(input_path),'--sha256',sha(input_path),'--output',str(output),'--workers','4']
        subprocess.run(command,cwd=ENGINE,check=True);verify(f0);verify(f1)
        data=json.loads(output.read_text(encoding='utf-8'))
        assert data['trial']==128 and data['success'] and len(data['scenes'])==73 and all(s['success'] for s in data['scenes'])
        save(OWN/f'{model}再生完了.json',{'成功':True,'結果SHA256':sha(output),'F1_SHA256':sha(OWN/'F1.json'),'前後同体':True,'コマンド':command})
        print(json.dumps({'再生完了':model,'結果SHA256':sha(output)},ensure_ascii=False));return
    done=json.loads((OWN/f'{model}再生完了.json').read_text(encoding='utf-8'));assert done['結果SHA256']==sha(output)
    command=[sys.executable,'-X','utf8',str(AGG/'集計する.py'),'--result',str(output),'--sha256',sha(output),
             '--input-sha256',sha(input_path),'--input',str(input_path),'--output-dir',str(OWN/f'{model}集計')]
    subprocess.run(command,cwd=ROOT,check=True);verify(f0);verify(f1)
    save(OWN/f'{model}集計完了.json',{'成功':True,'集計SHA256':sha(OWN/f'{model}集計/集計.json'),'F1_SHA256':sha(OWN/'F1.json'),'前後同体':True})


if __name__=='__main__':
    main()
