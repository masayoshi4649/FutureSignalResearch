"""128正式保存の原文・ZIP・入力・成果・目次リンクを検査する。金融を再実行しない。"""
from pathlib import Path
import gzip
import hashlib
import json
import re
import urllib.parse
import zipfile

ROOT = Path(__file__).resolve().parent.parent
FORMAL = ROOT/'study/00128_Raw価格時計で構造回復の出生を比較する'


def sha(data: bytes) -> str:
    """
    機能: bytesのSHA256を求める。
    引数: data(bytes)。返り値: str。
    """
    return hashlib.sha256(data).hexdigest()


# ----------------------------------------
def digest(path: Path) -> str:
    """
    機能: 本文を解釈せずファイルを逐次指紋化する。
    引数: path(Path)。返り値: strはSHA256。
    """
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda:stream.read(1048576),b''):
            h.update(data)
    return h.hexdigest()


# ----------------------------------------
def read(path: Path) -> dict:
    """
    機能: 小型JSONを読み込む。
    引数: path(Path)。返り値: dict。
    """
    return json.loads(path.read_text('utf-8'))


# ----------------------------------------
def main() -> None:
    """
    機能: 固定数値と保存bytes・参照の整合だけを確認し新規proofへ保存する。
    引数: なし。返り値: None。原板・自然金融実行・CSV再生成は行わない。
    """
    f0=read(FORMAL/'検査/F0.json');f1=read(FORMAL/'検査/F1.json')
    assert digest(FORMAL/'検査/F0.json')=='16e1eb2ac52119e60180fa33322b36742646fb9a68f5ea34b38876cf739cc870'
    assert digest(FORMAL/'検査/F1.json')=='8f94cebf15c8512b08778c31a5f7d87546ea504e0ac1d8a3d5e312c439dc4d2e'
    originals=json.loads(gzip.decompress((FORMAL/'検査/実行前文書.json.gz').read_bytes()))['原文']
    expected_md={Path(k).relative_to(ROOT).as_posix():v for k,v in f0['ファイル'].items() if Path(k).suffix=='.md'}
    assert len(originals)==len(expected_md)==9
    for item in originals:
        data=item['utf8_text'].encode('utf-8')
        assert len(data)==item['bytes'] and sha(data)==item['sha256']==expected_md[item['restore_relative']]
    current=0
    for name,expected in {**f0['ファイル'],**f1['ファイル']}.items():
        p=Path(name)
        if p in (FORMAL/'README.md',FORMAL/'設定と結果.md'):
            continue
        assert digest(p)==expected,name
        current+=1
    # ----------------------------------------
    index=read(FORMAL/'再現資料/コード復元索引.json')
    archive_path=FORMAL/'再現資料'/index['zip']['path']
    assert digest(archive_path)==index['zip']['sha256']
    with zipfile.ZipFile(archive_path) as archive:
        assert archive.testzip() is None
        assert len(index['entries'])==len(archive.namelist())
        for entry in index['entries']:
            assert sha(archive.read(entry['entry']))==entry['sha256']
            assert f"{archive.getinfo(entry['entry']).CRC:08x}"==entry['crc32']
    saved=read(FORMAL/'検査/保存の確認.json')
    for item in saved['共用入力']+saved['圧縮成果']:
        encoded=(ROOT/item['target']).read_bytes()
        decoded=gzip.decompress(encoded)
        assert len(encoded)==item['bytes'] and sha(encoded)==item['sha256']
        assert len(decoded)==item['decoded_bytes'] and sha(decoded)==item['decoded_sha256']
        assert sha(decoded)==digest(ROOT/item['source'])
    # ----------------------------------------
    for model,expected in [('gap300',(68,60,8,22,25,13,65,3,292844,453849,-161005)),
                           ('gap300_delay60',(62,52,10,18,26,8,59,3,247306,466849,-219543))]:
        aggregate=json.loads(gzip.decompress((FORMAL/f'成果物/{model}集計.json.gz').read_bytes()))
        s=aggregate['集計']['F0']['BBO']['3600']['125']
        keys=('entries','complete','censored','forward','adverse','neither','ifd_known','ifd_unknown','ifd_net5_profit','ifd_net5_loss','ifd_net5_sum')
        assert tuple(s[k] for k in keys)==expected
        assert aggregate['対象場数']==73 and not aggregate['主両条件達成']
        assert len(aggregate['集計'])==7
        proof=read(FORMAL/f'検査/{model}の独立検算.json')
        assert proof['集計値照合数']==3460
    csv=read(FORMAL/'検査/CSVの確認.json')
    folder=ROOT/'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/128Raw時計CSV'
    for name,info in csv['出力'].items():
        assert digest(folder/name)==info['sha256']
    # ----------------------------------------
    files=list(FORMAL.rglob('*.md'))+[ROOT/'inputs/00128_Raw価格時計の独立出生/README.md',
          ROOT/'docs/議論/Raw足の即時公表と取得集合の変化を分ける.md',folder/'README.md']
    links=0
    for path in files:
        text=path.read_text('utf-8')
        for value in re.findall(r'\]\(([^\n]*?)\)',text):
            if '://' in value or value.startswith('#'):
                continue
            target=urllib.parse.unquote(value.strip('<>').split('#')[0])
            assert (path.parent/target).exists(),(path,value)
            links+=1
    for rel in ('README.md','study/README.md','docs/README.md','docs/議論/README.md'):
        path=ROOT/rel;text=path.read_text('utf-8');section=text.split('\n\n')[1]
        assert '[128：' in section and '46.81%' in section and '−161,005' in section
        for value in re.findall(r'\]\(([^\n]*?)\)',section):
            assert (path.parent/urllib.parse.unquote(value)).exists()
            links+=1
    setting=(FORMAL/'設定と結果.md').read_text('utf-8')
    rows=[line for line in setting.splitlines() if re.match(r'^\| (I\d|C\d|P\d|V\d|B\d|X\d|M\d|E\d)',line)]
    assert len(rows)==56 and all(len(line.split('|'))-2==11 for line in rows)
    formal_bytes=sum(p.stat().st_size for p in FORMAL.rglob('*') if p.is_file())
    input_bytes=sum(p.stat().st_size for p in (ROOT/'inputs/00128_Raw価格時計の独立出生').rglob('*') if p.is_file())
    out={'成功':True,'試行':128,'金融再実行':False,'原板読取':False,'CSV生成':False,
         'F0全9原文復元':True,'現版のF0F1コード入力と未更新文書の指紋照合数':current,
         '結果更新した文書':['README.md','設定と結果.md'],'コードZIP':index['zip'],
         'ZIP全entry検査数':len(index['entries']),'取得入力と圧縮成果の復元一致':True,
         '主2モデルの固定値一致':True,'独立算術検算の参照値数':6920,'CSV3正本SHA不変':True,
         '手法尺度セル数':504,'ローカル参照確認数':links,'文書件数':len(files),
         '公式2ページ確認日':'2026-11-11','終端気配の清算可能性は別問題':True,
         '正式保存bytes_このproof前':formal_bytes,'共用inputs総bytes':input_bytes,
         '検査コードSHA256':digest(Path(__file__)),
         '正式文書':{str(p.relative_to(ROOT)).replace('\\','/'):digest(p) for p in files}}
    target=FORMAL/'検査/正式化の確認.json'
    with target.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(out,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'成功':True,'proofSHA256':digest(target),'zip':index['zip'],'links':links,
                      '正式bytes':formal_bytes,'inputsbytes':input_bytes},ensure_ascii=False))


if __name__=='__main__':
    main()
