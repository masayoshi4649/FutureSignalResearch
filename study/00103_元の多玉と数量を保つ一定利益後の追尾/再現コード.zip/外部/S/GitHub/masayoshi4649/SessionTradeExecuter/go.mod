module github.com/masayoshi4649/SessionTradeExecuter

go 1.24.0

require (
	github.com/BurntSushi/toml v1.5.0
	github.com/expr-lang/expr v1.17.8
	github.com/gorilla/websocket v1.5.3
	golang.org/x/sys v0.31.0
	modernc.org/sqlite v1.36.3
)

require (
	github.com/dustin/go-humanize v1.0.1 // indirect
	github.com/google/uuid v1.6.0 // indirect
	github.com/mattn/go-isatty v0.0.20 // indirect
	github.com/ncruces/go-strftime v0.1.9 // indirect
	github.com/remyoudompheng/bigfft v0.0.0-20230129092748-24d4a6f8daec // indirect
	golang.org/x/exp v0.0.0-20230315142452-642cacee5cc0 // indirect
	modernc.org/libc v1.61.13 // indirect
	modernc.org/mathutil v1.7.1 // indirect
	modernc.org/memory v1.8.2 // indirect
)
