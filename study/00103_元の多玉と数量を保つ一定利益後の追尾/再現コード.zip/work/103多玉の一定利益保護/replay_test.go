package delayedreplay103

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"

	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	oldtype "github.com/masayoshi4649/SessionTradeExecuter/minichart"
	finance "github.com/masayoshi4649/SessionTradeExecuter/minidelayed103"
	old95 "github.com/masayoshi4649/SessionTradeExecuter/minigrid"
)

type financeFixture struct {
	Session finance.Session `json:"session"`
	Scope   string          `json:"scope"`
	Steps   []struct {
		Observation finance.Observation   `json:"observation"`
		Line        int64                 `json:"source_line"`
		Batches     []finance.NativeBatch `json:"batches"`
	} `json:"steps"`
	Timers []struct {
		At      float64               `json:"at"`
		Batches []finance.NativeBatch `json:"batches"`
	} `json:"timers"`
	Grids  []float64 `json:"grids"`
	Events []struct {
		Kind  string `json:"kind"`
		Index int    `json:"index"`
	} `json:"events"`
	Actors   map[string]json.RawMessage `json:"actors"`
	Baseline map[string]json.RawMessage `json:"baseline95_p0"`
}

// fixtureTape は金融担当の停止Go公開型を順序も値も変えずTapeへ射影します。
//
// 引数: f(financeFixture)は手製Source/ATR人工です。
// 返り値: tape.Tape/errorは公開Scalar/Source/grid又は出典破損です。Gate文脈を作りません。
func fixtureTape(f financeFixture) (tape.Tape, error) {
	out := tape.Tape{Version: 1, Scope: "103金融停止Go公開型からのGate無し配送人工・自然Source/ATR形成ではない", Session: f.Session, Capabilities: tape.Capabilities(), Events: []tape.TapeEvent{}}
	convert := func(in []finance.NativeBatch) []oldtype.NativeBatch {
		if in == nil {
			return nil
		}
		out := make([]oldtype.NativeBatch, len(in))
		for i, v := range in {
			out[i] = oldtype.NativeBatch{Method: v.Method, Delta: v.Delta}
		}
		return out
	}
	for i, call := range f.Events {
		e := tape.TapeEvent{Ordinal: i + 1}
		switch call.Kind {
		case "quote":
			if call.Index < 0 || call.Index >= len(f.Steps) {
				return out, fmt.Errorf("人工step参照")
			}
			s := f.Steps[call.Index]
			q, err := tape.ProjectQuote(s.Observation, s.Line)
			if err != nil {
				return out, err
			}
			e.Kind, e.At, e.Quote = "quote", q.Time, &q
			e.Methods, e.NonEmpty, err = tape.CompressBatches(convert(s.Batches))
			if err != nil {
				return out, err
			}
		case "timer":
			if call.Index < 0 || call.Index >= len(f.Timers) {
				return out, fmt.Errorf("人工timer参照")
			}
			s := f.Timers[call.Index]
			e.Kind, e.At = "force", s.At
			var err error
			e.Methods, e.NonEmpty, err = tape.CompressBatches(convert(s.Batches))
			if err != nil {
				return out, err
			}
		case "grid":
			if call.Index < 0 || call.Index >= len(f.Grids) {
				return out, fmt.Errorf("人工grid参照")
			}
			e.Kind, e.At = "grid", f.Grids[call.Index]
		default:
			return out, fmt.Errorf("人工call種別不正")
		}
		out.Events = append(out.Events, e)
	}
	return out, nil
}

// loadFixture は署名済み金融人工1件だけを読みます。
//
// 引数: t(*testing.T)、name(string)は検査と人工名です。
// 返り値: financeFixtureは停止manifestへSHA結合した公開値です。市場は開きません。
func loadFixture(t *testing.T, name string) financeFixture {
	t.Helper()
	root := filepath.Join("..", "103多玉の保護会計")
	stop := filepath.Join(root, "停止.json")
	s, e := FileSHA(stop)
	if e != nil || s != "e051a2401c8919835adfea52bf346d644707239fd030f0b13f101586b4c1d52b" {
		t.Fatal("金融停止指紋", s, e)
	}
	var manifest struct {
		Artificial struct {
			Files map[string]string `json:"型人工SHA256"`
		} `json:"人工確認"`
	}
	if e = decodeFile(stop, &manifest, false); e != nil {
		t.Fatal(e)
	}
	path := filepath.Join(root, "人工", "停止版", name+".json")
	sha, e := FileSHA(path)
	if e != nil {
		t.Fatal(e)
	}
	found := false
	for p, v := range manifest.Artificial.Files {
		if filepath.Base(p) == name+".json" && v == sha {
			found = true
		}
	}
	if !found {
		t.Fatal("金融Go型人工指紋へ未結合", name, sha)
	}
	var f financeFixture
	if e = decodeFile(path, &f, false); e != nil {
		t.Fatal(e)
	}
	return f
}

// equalJSON はunknown欄/nil/空配列を除外せず全公開値を比較します。
//
// 引数: a/b(any)は公開型又はjson.RawMessageです。返り値: boolは全JSON値一致です。
func equalJSON(a, b any) bool {
	ab, ae := json.Marshal(a)
	bb, be := json.Marshal(b)
	if ae != nil || be != nil {
		return false
	}
	var av, bv any
	if json.Unmarshal(ab, &av) != nil || json.Unmarshal(bb, &bv) != nil {
		return false
	}
	return reflect.DeepEqual(av, bv)
}

// TestRuntime103GoTyped は停止4人工の全16と旧95P0四を結合します。
//
// 引数: t(*testing.T)は検査。返り値: なし。自然Source/実市場の証明ではありません。
func TestRuntime103GoTyped(t *testing.T) {
	for _, name := range []string{"方向1_未知ATRfalse", "方向1_未知ATRtrue", "方向-1_未知ATRfalse", "方向-1_未知ATRtrue"} {
		t.Run(name, func(t *testing.T) {
			f := loadFixture(t, name)
			input, e := fixtureTape(f)
			if e != nil {
				t.Fatal(e)
			}
			old := map[string]*old95.ActualBook{}
			for _, c := range Configurations() {
				if c.Policy != "P0" || c.Activation != "" {
					continue
				}
				b, e := old95.NewActualBook(f.Session, old95.ActorConfig{Policy: "P0", EntryTiming: "B5Q", USOpen: f.Session.USOpen, SlipPts: c.Slip, DelaySeconds: c.Delay})
				if e != nil {
					t.Fatal(e)
				}
				old[ConfigKey(c)] = b
			}
			last := map[string]int64{}
			comparisons := 0
			observed := func(event tape.TapeEvent, books map[string]finance.ActualResult) error {
				var batches []oldtype.NativeBatch
				var e error
				if event.Kind != "grid" {
					batches, e = tape.RestoreBatches(event, last)
					if e != nil {
						return e
					}
				}
				for key, b := range old {
					converted := make([]old95.NativeBatch, len(batches))
					for i, v := range batches {
						converted[i] = old95.NativeBatch{Method: v.Method, Delta: v.Delta}
					}
					switch event.Kind {
					case "quote":
						e = b.OnNativeStep(event.Quote.Observation(), event.Quote.SourceLine, converted)
					case "force":
						e = b.OnNativeForce(event.At, converted)
					case "grid":
						e = b.OnEntryGrid(event.At)
					}
					if e != nil {
						return e
					}
					if !equalJSON(books[key], b.Snapshot()) {
						return fmt.Errorf("旧95全時点差:%s ordinal%d", key, event.Ordinal)
					}
					comparisons++
				}
				return nil
			}
			out, e := RunObserved(input, observed)
			if e != nil {
				t.Fatal(e)
			}
			if len(out.Books) != 16 || len(out.MainKeys) != 12 || len(out.DiagnosticKeys) != 4 || !out.Complete || !out.InputUnchanged || out.SourceReexecuted || out.GateExecuted {
				t.Fatal("16/分離/不変")
			}
			for key, b := range out.Books {
				if b.Totals.EntryQuantity == 0 || !equalJSON(b, f.Actors[key]) {
					t.Fatalf("停止実型全JSON差/非0: %s", key)
				}
			}
			if e = CompareP0(out, f.Baseline); e != nil {
				t.Fatal(e)
			}
			for key, b := range old {
				v, e := b.Finish()
				if e != nil || !equalJSON(out.Books[key], v) {
					t.Fatal("旧95Finish全文", key, e)
				}
			}
			if comparisons != 4*len(input.Events) {
				t.Fatal("全時点集合")
			}
			t.Logf("16非0・旧95全時点%d/最終4・Gate callback0", comparisons)
			if p := os.Getenv("DELAYED103_EXPORT"); p != "" {
				if e = os.MkdirAll(p, 0700); e != nil {
					t.Fatal(e)
				}
				value := map[string]any{"scope": input.Scope, "tape": input, "output": out, "baseline95_p0": f.Baseline, "全時点P0比較": comparisons, "Gate実行": 0, "金融型人工": name}
				if e = writeNew(filepath.Join(p, name+".json"), value, false); e != nil {
					t.Fatal(e)
				}
			}
		})
	}
}

// TestRuntime103NarrowCorruptions は配送と旧対照の少数破損を拒否します。
//
// 引数: t(*testing.T)は検査。返り値: なし。停止入力を改変せずcopy器具だけを壊します。
func TestRuntime103NarrowCorruptions(t *testing.T) {
	f := loadFixture(t, "方向1_未知ATRfalse")
	input, e := fixtureTape(f)
	if e != nil {
		t.Fatal(e)
	}
	body, _ := json.Marshal(input)
	for _, name := range []string{"ordinal", "clock", "quote_time", "source_line", "capabilities", "grid_quote"} {
		t.Run(name, func(t *testing.T) {
			var bad tape.Tape
			_ = json.Unmarshal(body, &bad)
			switch name {
			case "ordinal":
				bad.Events[0].Ordinal = 2
			case "clock":
				bad.Events[len(bad.Events)-1].At = 1
			case "capabilities":
				bad.Capabilities = []string{"不明"}
			default:
				for i := range bad.Events {
					ev := &bad.Events[i]
					if name == "grid_quote" && ev.Kind == "grid" {
						ev.Quote = &tape.ScalarQuote{}
						break
					}
					if ev.Kind == "quote" && name != "grid_quote" {
						if name == "quote_time" {
							ev.Quote.Time++
						} else if name == "source_line" {
							ev.Quote.SourceLine = 0
						}
						break
					}
				}
			}
			if _, e := RunTape(bad); e == nil {
				t.Fatal("破損を受理")
			}
		})
	}
	out, e := RunTape(input)
	if e != nil {
		t.Fatal(e)
	}
	baseline := map[string]json.RawMessage{}
	for k, v := range f.Baseline {
		baseline[k] = v
	}
	for k := range baseline {
		baseline[k] = json.RawMessage(`{"偽対照":true}`)
		break
	}
	if e = CompareP0(out, baseline); e == nil {
		t.Fatal("旧P0 field破損を受理")
	}
	for i, e := range input.Events {
		if e.Kind == "quote" && e.Quote.Time > f.Grids[0]+1 {
			input.Events = input.Events[:i+1]
			break
		}
	}
	if _, e = RunTape(input); e == nil {
		t.Fatal("未完結を成功化")
	}
}

// TestRuntime103Configuration は主12/診断4の本名順を検査します。
//
// 引数: t(*testing.T)は検査。返り値: なし。
func TestRuntime103Configuration(t *testing.T) {
	c := Configurations()
	if len(c) != 16 || ConfigKey(c[0]) != "B5Q_P0_C0_D0" || ConfigKey(c[4]) != "LD05_B5Q_P0_C0_D0" || ConfigKey(c[8]) != "LD10_B5Q_P0_C0_D0" || ConfigKey(c[12]) != "B5Q_S0_C0_D0" {
		t.Fatal("固定順差")
	}
	for _, v := range c[12:] {
		if v.Policy != "S0" || v.Activation != "" || strings.HasPrefix(ConfigKey(v), "LD") {
			t.Fatal("S0診断の誤分類")
		}
	}
}
