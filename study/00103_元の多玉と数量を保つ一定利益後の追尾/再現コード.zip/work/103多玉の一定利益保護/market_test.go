package delayedreplay103

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	finance "github.com/masayoshi4649/SessionTradeExecuter/minidelayed103"
)

// metadataFixture は実市場を読まず許可54と完全16設定を型人工で作ります。
//
// 引数: t(*testing.T)は検査。返り値: Arguments/string/stringは設定/repo/模擬実行物です。
func metadataFixture(t *testing.T) (Arguments, string, string) {
	t.Helper()
	root := t.TempDir()
	code := map[string]string{}
	for _, name := range []string{"replay.go", "market.go", "cmd/replay/main.go", "go.mod", "go.sum"} {
		p := filepath.Join(root, name)
		if e := os.MkdirAll(filepath.Dir(p), 0700); e != nil {
			t.Fatal(e)
		}
		if e := os.WriteFile(p, []byte("人工metadata"), 0600); e != nil {
			t.Fatal(e)
		}
		code[name], _ = FileSHA(p)
	}
	exe := filepath.Join(root, "103.exe")
	if e := os.WriteFile(exe, []byte("実行しない模擬実行物"), 0600); e != nil {
		t.Fatal(e)
	}
	bsha, _ := FileSHA(exe)
	c := Condition{Version: 1, Trial: 103, Fixed: true, Configs: Configurations(), Code: code, Binary: FileRef{exe, bsha}}
	entries := []map[string]string{}
	zone := time.FixedZone("JST", 9*3600)
	for _, id := range AllowedSessions() {
		date, _ := time.ParseInLocation("2006-01-02", id[:10], zone)
		kind := "Day"
		start := date.Add(8*time.Hour + 45*time.Minute)
		end := date.Add(15*time.Hour + 45*time.Minute)
		us := 0.0
		method := "D164_15"
		if strings.HasSuffix(id, "Night") {
			kind = "Night"
			start = date.Add(17 * time.Hour)
			end = date.Add(30 * time.Hour)
			us = float64(date.Add(22*time.Hour + 30*time.Minute).Unix())
			method = "P164_06"
		}
		s := finance.Session{ID: id, Kind: kind, Start: float64(start.Unix()), End: float64(end.Unix()), ForceClose: float64(end.Add(-10 * time.Minute).Unix()), USOpen: us}
		q := tape.ScalarQuote{Time: s.Start + 1, Received: s.Start + 1, Index: 0, SourceLine: 10, Last: 50000, Bid: 50000, Ask: 50005, QuoteOK: true}
		input := tape.Tape{Version: 1, Scope: "CLIの空口座metadata人工・Source生成ではない", Session: s, Capabilities: tape.Capabilities(), Events: []tape.TapeEvent{{Ordinal: 1, Kind: "quote", At: q.Time, Quote: &q, Methods: []string{method}}, {Ordinal: 2, Kind: "grid", At: s.Start + 1800}, {Ordinal: 3, Kind: "force", At: s.ForceClose, Methods: []string{method}}}}
		p := filepath.Join(root, "入力", id+".json")
		if e := os.MkdirAll(filepath.Dir(p), 0700); e != nil {
			t.Fatal(e)
		}
		if e := writeNew(p, input, false); e != nil {
			t.Fatal(e)
		}
		sha, _ := FileSHA(p)
		relative, _ := filepath.Rel(root, p)
		c.Scenes = append(c.Scenes, SceneInput{id, FileRef{relative, sha}})
		entries = append(entries, map[string]string{"session": id, "path": relative, "sha256": sha})
	}
	index := filepath.Join(root, "index.json")
	if e := writeNew(index, map[string]any{"version": 1, "stage": "full54", "entries": entries}, false); e != nil {
		t.Fatal(e)
	}
	sha, _ := FileSHA(index)
	c.Index = FileRef{index, sha}
	cp := filepath.Join(root, "条件.json")
	if e := writeNew(cp, c, false); e != nil {
		t.Fatal(e)
	}
	sha, _ = FileSHA(cp)
	return Arguments{Condition: cp, ConditionSHA: sha, Stage: "first2", Out: filepath.Join(root, "先頭2"), Workers: 2}, root, exe
}

// TestMarket103Metadata は未固定/集合/指紋を金融前に拒否します。
//
// 引数: t(*testing.T)は検査。返り値: なし。市場ファイルを使いません。
func TestMarket103Metadata(t *testing.T) {
	for _, name := range []string{"正常", "未固定", "53場", "新日", "主12だけ", "入力偽SHA", "台帳と別path", "別binary", "空SHA", "workers5", "full先頭なし"} {
		t.Run(name, func(t *testing.T) {
			a, root, exe := metadataFixture(t)
			var c Condition
			if e := decodeFile(a.Condition, &c, true); e != nil {
				t.Fatal(e)
			}
			switch name {
			case "未固定":
				c.Fixed = false
			case "53場":
				c.Scenes = c.Scenes[:53]
			case "新日":
				c.Scenes[4].Session = "2026-11-01_Day"
			case "主12だけ":
				c.Configs = c.Configs[:12]
			case "入力偽SHA":
				c.Scenes[0].Tape.SHA = strings.Repeat("0", 64)
			case "台帳と別path":
				c.Scenes[0].Tape.Path = c.Scenes[1].Tape.Path
			case "別binary":
				c.Binary.Path = "別.exe"
			case "workers5":
				a.Workers = 5
			case "full先頭なし":
				a.Stage = "full54"
			}
			if name != "正常" && name != "空SHA" && name != "workers5" && name != "full先頭なし" {
				a.Condition = filepath.Join(root, "別条件.json")
				if e := writeNew(a.Condition, c, false); e != nil {
					t.Fatal(e)
				}
				a.ConditionSHA, _ = FileSHA(a.Condition)
			}
			if name == "空SHA" {
				a.ConditionSHA = ""
			}
			_, scenes, _, e := Prepare(a, root, exe)
			if name == "正常" {
				if e != nil || len(scenes) != 2 {
					t.Fatal(e)
				}
			} else if e == nil {
				t.Fatal("metadata破損を受理")
			}
			if _, e = os.Stat(a.Out); !os.IsNotExist(e) {
				t.Fatal("guard中に出力を作成")
			}
		})
	}
}

// TestMarket103First2Chain は空32会計と同条件full54の準備境界を確認します。
//
// 引数: t(*testing.T)は検査。返り値: なし。全54金融は走らせません。
func TestMarket103First2Chain(t *testing.T) {
	a, root, exe := metadataFixture(t)
	r, e := RunMarket(a, root, exe)
	if e != nil || !r.Success || r.Books != 32 || r.MainBooks != 24 || r.DiagnosticBooks != 8 || !r.Unchanged {
		t.Fatalf("先頭32空会計: %+v %v", r, e)
	}
	for _, s := range r.Results {
		if s.Books != 16 || len(s.Totals) != 16 {
			t.Fatal("16集合")
		}
		sha, e := FileSHA(s.Path)
		if e != nil || sha != s.SHA {
			t.Fatal("出力指紋")
		}
	}
	a.First2 = filepath.Join(a.Out, "完了.json")
	a.First2SHA, _ = FileSHA(a.First2)
	a.Stage = "full54"
	a.Out = filepath.Join(root, "全54は未実行")
	_, scenes, _, e := Prepare(a, root, exe)
	if e != nil || len(scenes) != 54 {
		t.Fatal("同条件2→54metadata", e)
	}
	if _, e = os.Stat(a.Out); !os.IsNotExist(e) {
		t.Fatal("未実行full出力を作成")
	}
	r.Success = false
	b, _ := json.Marshal(r)
	bad := filepath.Join(root, "先頭失敗.json")
	if e = os.WriteFile(bad, b, 0600); e != nil {
		t.Fatal(e)
	}
	a.First2 = bad
	a.First2SHA, _ = FileSHA(bad)
	if _, _, _, e = Prepare(a, root, exe); e == nil {
		t.Fatal("first2失敗を成功化")
	}
}
