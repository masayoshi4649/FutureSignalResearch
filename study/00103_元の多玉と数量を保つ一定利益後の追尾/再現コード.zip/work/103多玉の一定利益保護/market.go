package delayedreplay103

import (
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"reflect"
	"sort"
	"strings"
	"sync"
	"time"

	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
)

type FileRef struct {
	Path string `json:"path"`
	SHA  string `json:"sha256"`
}
type SceneInput struct {
	Session string  `json:"session"`
	Tape    FileRef `json:"tape"`
}
type Condition struct {
	Version int               `json:"version"`
	Trial   int               `json:"trial"`
	Fixed   bool              `json:"fixed"`
	Scenes  []SceneInput      `json:"scenes"`
	Configs []Config          `json:"configs"`
	Code    map[string]string `json:"code_sha256"`
	Binary  FileRef           `json:"binary"`
	Index   FileRef           `json:"input_index"`
}
type Arguments struct {
	Condition, ConditionSHA, Stage, Out, First2, First2SHA string
	Workers                                                int
}
type SceneReceipt struct {
	Session string             `json:"session"`
	Path    string             `json:"path,omitempty"`
	SHA     string             `json:"sha256,omitempty"`
	Books   int                `json:"books"`
	Error   string             `json:"error,omitempty"`
	Totals  map[string]Summary `json:"totals,omitempty"`
}
type Summary struct {
	Gross         float64 `json:"gross"`
	Fee           float64 `json:"fee"`
	Slip          float64 `json:"slip"`
	Net           float64 `json:"net"`
	EntryQuantity int     `json:"entry_quantity"`
	Positions     int     `json:"positions"`
}
type Completion struct {
	Version          int               `json:"version"`
	Trial            int               `json:"trial"`
	Success          bool              `json:"success"`
	Stage            string            `json:"stage"`
	ConditionSHA     string            `json:"condition_sha256"`
	Scenes           int               `json:"scenes"`
	Books            int               `json:"books"`
	BooksPerScene    int               `json:"books_per_scene"`
	MainBooks        int               `json:"main_books"`
	DiagnosticBooks  int               `json:"diagnostic_books"`
	Configs          []Config          `json:"configs"`
	Results          []SceneReceipt    `json:"results"`
	Before           map[string]string `json:"input_code_sha256_before"`
	After            map[string]string `json:"input_code_sha256_after"`
	Unchanged        bool              `json:"input_code_unchanged"`
	First2           *FileRef          `json:"first2,omitempty"`
	SourceReexecuted bool              `json:"source_reexecuted"`
	ChartsRecomputed bool              `json:"charts_recomputed"`
	GateExecuted     bool              `json:"gate_executed"`
	RawCSVRead       int               `json:"raw_csv_read"`
	DiagnosticScope  string            `json:"diagnostic_scope"`
	Error            string            `json:"error,omitempty"`
}

// FileSHA は指定された通常ファイルを逐次hashします。
//
// 引数: path(string)は明示された入力です。返り値: string/errorはSHA256又は不正です。
func FileSHA(path string) (string, error) {
	f, e := os.Open(path)
	if e != nil {
		return "", e
	}
	defer f.Close()
	s, e := f.Stat()
	if e != nil {
		return "", e
	}
	if !s.Mode().IsRegular() {
		return "", fmt.Errorf("通常ファイルではありません: %s", path)
	}
	h := sha256.New()
	if _, e = io.Copy(h, f); e != nil {
		return "", e
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}

// validSHA は未固定/不正な指紋を拒否します。
//
// 引数: s(string)は期待SHA。返り値: boolは小文字64桁なら真です。
func validSHA(s string) bool {
	b, e := hex.DecodeString(s)
	return e == nil && len(b) == 32 && strings.ToLower(s) == s
}

// absolute はFileRefの相対基準を固定します。
//
// 引数: base/path(string)は基準/指定path。返り値: string/errorは絶対pathです。
func absolute(base, path string) (string, error) {
	if path == "" {
		return "", fmt.Errorf("空path")
	}
	if !filepath.IsAbs(path) {
		path = filepath.Join(base, path)
	}
	return filepath.Abs(path)
}

// decodeFile は1JSONだけを読んで設定の未知欄と末尾混入を拒否します。
//
// 引数: path(string)、out(any)、strict(bool)は入力/出力/未知欄拒否です。
// 返り値: errorは型/余剰値等の破損です。
func decodeFile(path string, out any, strict bool) error {
	f, e := os.Open(path)
	if e != nil {
		return e
	}
	defer f.Close()
	var r io.Reader = f
	var z *gzip.Reader
	if strings.HasSuffix(path, ".gz") {
		z, e = gzip.NewReader(f)
		if e != nil {
			return e
		}
		defer z.Close()
		r = z
	}
	d := json.NewDecoder(r)
	if strict {
		d.DisallowUnknownFields()
	}
	if e = d.Decode(out); e != nil {
		return e
	}
	var tail any
	if e = d.Decode(&tail); e != io.EOF {
		return fmt.Errorf("JSON末尾値又は破損: %v", e)
	}
	return nil
}

// AllowedSessions は既使用27開始日×昼夜だけを返します。
//
// 引数: なし。返り値: []stringは先頭2から全54の固定順です。
func AllowedSessions() []string {
	out := []string{}
	for d := time.Date(2026, 9, 21, 0, 0, 0, 0, time.UTC); !d.After(time.Date(2026, 10, 27, 0, 0, 0, 0, time.UTC)); d = d.AddDate(0, 0, 1) {
		if d.Weekday() != time.Saturday && d.Weekday() != time.Sunday {
			out = append(out, d.Format("2006-01-02")+"_Day", d.Format("2006-01-02")+"_Night")
		}
	}
	return out
}

// Prepare は実金融より前に固定条件・台帳集合・指紋を結びます。
//
// 引数: args(Arguments)、root/executable(string)はCLI/repo/実行物です。
// 返り値: Condition/[]SceneInput/map[string]string/errorは設定/対象/前指紋又は拒否です。
func Prepare(args Arguments, root, executable string) (Condition, []SceneInput, map[string]string, error) {
	var c Condition
	fail := func(e error) (Condition, []SceneInput, map[string]string, error) { return c, nil, nil, e }
	if !validSHA(args.ConditionSHA) || args.Stage != "first2" && args.Stage != "full54" || args.Workers < 1 || args.Workers > 4 {
		return fail(fmt.Errorf("条件SHA/stage/workers未固定又は不正"))
	}
	cp, e := filepath.Abs(args.Condition)
	if e != nil {
		return fail(e)
	}
	h, e := FileSHA(cp)
	if e != nil || h != args.ConditionSHA {
		return fail(fmt.Errorf("条件SHA不一致: %v", e))
	}
	if e = decodeFile(cp, &c, true); e != nil {
		return fail(e)
	}
	if c.Version != 1 || c.Trial != 103 || !c.Fixed || len(c.Scenes) != 54 || !reflect.DeepEqual(c.Configs, Configurations()) || len(c.Code) == 0 {
		return fail(fmt.Errorf("固定103/全54/主12診断4設定不一致"))
	}
	base := filepath.Dir(cp)
	before := map[string]string{cp: h}
	check := func(ref FileRef, dir string) error {
		if !validSHA(ref.SHA) {
			return fmt.Errorf("未固定SHA: %s", ref.Path)
		}
		p, e := absolute(dir, ref.Path)
		if e != nil {
			return e
		}
		v, e := FileSHA(p)
		if e != nil {
			return e
		}
		if v != ref.SHA {
			return fmt.Errorf("指紋不一致: %s", p)
		}
		if prior, ok := before[p]; ok && prior != v {
			return fmt.Errorf("同path別指紋")
		}
		before[p] = v
		return nil
	}
	ids := AllowedSessions()
	seen := map[string]bool{}
	for i := range c.Scenes {
		s := &c.Scenes[i]
		if s.Session != ids[i] || !validSHA(s.Tape.SHA) {
			return fail(fmt.Errorf("許可54/Source入力未固定: %d", i))
		}
		s.Tape.Path, e = absolute(base, s.Tape.Path)
		if e != nil {
			return fail(e)
		}
		key := strings.ToLower(s.Tape.Path)
		if seen[key] {
			return fail(fmt.Errorf("Tape path重複"))
		}
		seen[key] = true
	}
	for p, v := range c.Code {
		if e = check(FileRef{p, v}, root); e != nil {
			return fail(e)
		}
	}
	for _, name := range []string{"replay.go", "market.go", "main.go", "go.mod", "go.sum"} {
		found := false
		for p := range c.Code {
			if filepath.Base(p) == name {
				found = true
			}
		}
		if !found {
			return fail(fmt.Errorf("所有code欠落: %s", name))
		}
	}
	binary, e := absolute(base, c.Binary.Path)
	if e != nil {
		return fail(e)
	}
	actual, e := filepath.Abs(executable)
	if e != nil || !strings.EqualFold(binary, actual) {
		return fail(fmt.Errorf("実行binary path不一致"))
	}
	if e = check(c.Binary, base); e != nil {
		return fail(e)
	}
	if e = check(c.Index, base); e != nil {
		return fail(e)
	}
	indexPath, _ := absolute(base, c.Index.Path)
	var index struct {
		Version int    `json:"version"`
		Stage   string `json:"stage"`
		Entries []struct {
			Session string `json:"session"`
			Path    string `json:"path"`
			SHA     string `json:"sha256"`
		} `json:"entries"`
	}
	if e = decodeFile(indexPath, &index, false); e != nil {
		return fail(e)
	}
	if index.Version != 1 || index.Stage != "full54" || len(index.Entries) != 54 {
		return fail(fmt.Errorf("固定Tape台帳の全54集合不一致"))
	}
	for i, r := range index.Entries {
		p, e := absolute(filepath.Dir(indexPath), r.Path)
		s := c.Scenes[i]
		if e != nil || r.Session != s.Session || !strings.EqualFold(p, s.Tape.Path) || r.SHA != s.Tape.SHA {
			return fail(fmt.Errorf("Tape台帳と条件の入力対不一致: %s", s.Session))
		}
	}
	scenes := c.Scenes
	if args.Stage == "first2" {
		scenes = scenes[:2]
	}
	for _, s := range scenes {
		if e = check(s.Tape, base); e != nil {
			return fail(e)
		}
	}
	if args.Stage == "full54" {
		if e = check(FileRef{args.First2, args.First2SHA}, base); e != nil {
			return fail(fmt.Errorf("先頭2完了: %w", e))
		}
		path, _ := absolute(base, args.First2)
		var first Completion
		if e = decodeFile(path, &first, true); e != nil {
			return fail(e)
		}
		if !first.Success || first.Version != 1 || first.Trial != 103 || first.Stage != "first2" || first.ConditionSHA != args.ConditionSHA || first.Scenes != 2 || first.Books != 32 || first.BooksPerScene != 16 || first.MainBooks != 24 || first.DiagnosticBooks != 8 || !first.Unchanged || !reflect.DeepEqual(first.Before, first.After) || !reflect.DeepEqual(first.Configs, c.Configs) || len(first.Results) != 2 || first.SourceReexecuted || first.ChartsRecomputed || first.GateExecuted || first.RawCSVRead != 0 || first.Error != "" {
			return fail(fmt.Errorf("先頭2の同条件/全32/不変不一致"))
		}
		for i, r := range first.Results {
			if r.Session != ids[i] || r.Books != 16 || r.Error != "" || len(r.Totals) != 16 || first.Before[c.Scenes[i].Tape.Path] != c.Scenes[i].Tape.SHA {
				return fail(fmt.Errorf("先頭2の入力/全16不一致"))
			}
			for _, cfg := range c.Configs {
				if _, ok := r.Totals[ConfigKey(cfg)]; !ok {
					return fail(fmt.Errorf("先頭2集計key欠落"))
				}
			}
			if e = check(FileRef{r.Path, r.SHA}, filepath.Dir(path)); e != nil {
				return fail(e)
			}
		}
		for _, p := range []string{cp, binary, indexPath} {
			if first.Before[p] != before[p] {
				return fail(fmt.Errorf("先頭2との固定指紋差: %s", p))
			}
		}
		for p, v := range c.Code {
			a, _ := absolute(root, p)
			if first.Before[a] != v {
				return fail(fmt.Errorf("先頭2とのcode差: %s", p))
			}
		}
	} else if args.First2 != "" || args.First2SHA != "" {
		return fail(fmt.Errorf("first2へ先頭receiptを指定できません"))
	}
	return c, scenes, before, nil
}

// writeNew は既存結果を上書きせずJSON又はgzipを保存します。
//
// 引数: path(string)、value(any)、compressed(bool)は保存先/値/圧縮です。
// 返り値: errorは保存失敗です。
func writeNew(path string, value any, compressed bool) error {
	f, e := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if e != nil {
		return e
	}
	var w io.Writer = f
	var z *gzip.Writer
	if compressed {
		z = gzip.NewWriter(f)
		w = z
	}
	enc := json.NewEncoder(w)
	enc.SetEscapeHTML(false)
	e = enc.Encode(value)
	if z != nil {
		if ze := z.Close(); e == nil {
			e = ze
		}
	}
	if fe := f.Close(); e == nil {
		e = fe
	}
	return e
}

// RunMarket は明示固定Tapeだけを最大4場並列で配送します。
//
// 引数: args(Arguments)、root/executable(string)は実行設定です。
// 返り値: Completion/errorは完了metadata又は失敗です。Source/Rawを実行しません。
func RunMarket(args Arguments, root, executable string) (Completion, error) {
	out := Completion{Version: 1, Trial: 103, Stage: args.Stage, ConditionSHA: args.ConditionSHA, Configs: Configurations(), BooksPerScene: 16, Results: []SceneReceipt{}, DiagnosticScope: "S0四冊は元Source返済のみ。利益保護義務未充足・新候補として採用不可"}
	_, scenes, before, e := Prepare(args, root, executable)
	if e != nil {
		return out, e
	}
	out.Before = before
	out.Scenes = len(scenes)
	if args.Stage == "full54" {
		p, _ := absolute(filepath.Dir(args.Condition), args.First2)
		out.First2 = &FileRef{p, args.First2SHA}
	}
	dir, e := filepath.Abs(args.Out)
	if e != nil || args.Out == "" {
		return out, fmt.Errorf("新規出力先が必要")
	}
	if _, e = os.Stat(dir); !os.IsNotExist(e) {
		return out, fmt.Errorf("既存又は不正な出力先")
	}
	if e = os.MkdirAll(filepath.Dir(dir), 0700); e != nil {
		return out, e
	}
	if e = os.Mkdir(dir, 0700); e != nil {
		return out, e
	}
	jobs := make(chan SceneInput)
	results := make(chan SceneReceipt)
	var wg sync.WaitGroup
	for worker := 0; worker < args.Workers; worker++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for s := range jobs {
				entry := SceneReceipt{Session: s.Session}
				var input tape.Tape
				err := decodeFile(s.Tape.Path, &input, true)
				var r RunResult
				if err == nil && input.Session.ID != s.Session {
					err = fmt.Errorf("Tapeの場不一致")
				}
				if err == nil {
					r, err = RunTape(input)
				}
				if err == nil {
					entry.Path = filepath.Join(dir, s.Session+".json.gz")
					err = writeNew(entry.Path, r, true)
				}
				if err == nil {
					entry.SHA, err = FileSHA(entry.Path)
				}
				if err != nil {
					entry.Error = err.Error()
				} else {
					entry.Books = len(r.Books)
					entry.Totals = map[string]Summary{}
					for key, b := range r.Books {
						n := 0
						for _, p := range b.Positions {
							if p.InitialQuantity > 0 {
								n++
							}
						}
						entry.Totals[key] = Summary{b.Totals.GrossYen, b.Totals.FeeYen, b.Totals.SlipYen, b.Totals.NetYen, b.Totals.EntryQuantity, n}
					}
				}
				results <- entry
			}
		}()
	}
	go func() {
		for _, s := range scenes {
			jobs <- s
		}
		close(jobs)
		wg.Wait()
		close(results)
	}()
	for r := range results {
		out.Results = append(out.Results, r)
		out.Books += r.Books
		if r.Error != "" && out.Error == "" {
			out.Error = r.Session + ": " + r.Error
		}
		fmt.Fprintf(os.Stderr, "%d/%d %s 会計%d %s\n", len(out.Results), len(scenes), r.Session, r.Books, r.Error)
	}
	sort.Slice(out.Results, func(i, j int) bool { return out.Results[i].Session < out.Results[j].Session })
	out.After = map[string]string{}
	for p := range before {
		v, err := FileSHA(p)
		if err != nil && out.Error == "" {
			out.Error = err.Error()
		}
		out.After[p] = v
	}
	out.Unchanged = reflect.DeepEqual(out.Before, out.After)
	if !out.Unchanged && out.Error == "" {
		out.Error = "code/input/binary前後不一致"
	}
	out.Success = out.Error == "" && out.Books == 16*len(scenes)
	if out.Success {
		out.MainBooks = 12 * len(scenes)
		out.DiagnosticBooks = 4 * len(scenes)
	}
	if e = writeNew(filepath.Join(dir, "完了.json"), out, false); e != nil {
		return out, e
	}
	if !out.Success {
		return out, fmt.Errorf("%s", out.Error)
	}
	return out, nil
}
