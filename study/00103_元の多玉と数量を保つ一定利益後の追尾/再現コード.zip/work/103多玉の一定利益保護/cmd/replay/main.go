package main

import (
	"flag"
	"fmt"
	"os"
	"path/filepath"

	replay "github.com/masayoshi4649/SessionTradeExecuter/delayedreplay103"
)

// repository はrepo相対コード指紋の基準を見つけます。
//
// 引数: なし。返り値: string/errorはstudy/scriptsを持つ祖先です。
func repository() (string, error) {
	p, e := os.Getwd()
	if e != nil {
		return "", e
	}
	for {
		a, ae := os.Stat(filepath.Join(p, "study"))
		b, be := os.Stat(filepath.Join(p, "scripts"))
		if ae == nil && be == nil && a.IsDir() && b.IsDir() {
			return p, nil
		}
		q := filepath.Dir(p)
		if q == p {
			return "", fmt.Errorf("repo基準がありません")
		}
		p = q
	}
}

// main はRoot固定後だけ起動する市場再生CLIです。
//
// 引数: CLI引数。返り値: なし。未固定/未完結は終了1です。
func main() {
	a := replay.Arguments{}
	flag.StringVar(&a.Condition, "condition", "", "固定条件JSON")
	flag.StringVar(&a.ConditionSHA, "condition-sha", "", "固定条件SHA256")
	flag.StringVar(&a.Stage, "stage", "first2", "first2/full54")
	flag.StringVar(&a.Out, "out", "", "新規出力先")
	flag.StringVar(&a.First2, "first2", "", "同条件first2完了JSON")
	flag.StringVar(&a.First2SHA, "first2-sha", "", "first2完了SHA256")
	flag.IntVar(&a.Workers, "workers", 1, "並列1..4")
	flag.Parse()
	if flag.NArg() != 0 {
		fmt.Fprintln(os.Stderr, "不明な位置引数")
		os.Exit(1)
	}
	root, e := repository()
	if e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
	exe, e := os.Executable()
	if e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
	r, e := replay.RunMarket(a, root, exe)
	if e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
	fmt.Printf("成功 %s %d場 主%d 診断%d\n", r.Stage, r.Scenes, r.MainBooks, r.DiagnosticBooks)
}
