package delayedreplay103

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"reflect"

	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	oldtype "github.com/masayoshi4649/SessionTradeExecuter/minichart"
	finance "github.com/masayoshi4649/SessionTradeExecuter/minidelayed103"
)

// Config は元B5Qを変えず起動・費用・遅延だけを明示します。
//
// Policy=S0は保護義務未充足の診断対照です。新候補へ算入しません。
type Config struct {
	Policy     string                   `json:"policy"`
	Activation finance.ActivationPolicy `json:"activation_policy"`
	Slip       float64                  `json:"slip_pts"`
	Delay      int                      `json:"delay_seconds"`
}
type EventCounts struct {
	Quotes int `json:"quotes"`
	Forces int `json:"forces"`
	Grids  int `json:"grids"`
}
type RunResult struct {
	Version          int                             `json:"version"`
	Trial            int                             `json:"trial"`
	Session          finance.Session                 `json:"session"`
	Books            map[string]finance.ActualResult `json:"books"`
	MainKeys         []string                        `json:"main_keys"`
	DiagnosticKeys   []string                        `json:"diagnostic_keys"`
	GridTimes        []float64                       `json:"grid_times"`
	Events           EventCounts                     `json:"events"`
	TapeCanonicalSHA string                          `json:"tape_canonical_sha256"`
	InputUnchanged   bool                            `json:"input_unchanged"`
	SourceReexecuted bool                            `json:"source_reexecuted"`
	ChartsRecomputed bool                            `json:"charts_recomputed"`
	GateExecuted     bool                            `json:"gate_executed"`
	Complete         bool                            `json:"complete"`
	Scope            string                          `json:"scope"`
}

// Configurations は主12と採用不可の診断4を固定順に返します。
//
// 引数: なし。返り値: []ConfigはP0/LD05/LD10各C/D後にS0各C/Dです。
func Configurations() []Config {
	out := []Config{}
	for _, a := range []finance.ActivationPolicy{finance.ActivationLegacy, finance.ActivationLD05, finance.ActivationLD10} {
		for _, c := range []float64{0, 5} {
			for _, d := range []int{0, 1} {
				out = append(out, Config{"P0", a, c, d})
			}
		}
	}
	for _, c := range []float64{0, 5} {
		for _, d := range []int{0, 1} {
			out = append(out, Config{"S0", finance.ActivationLegacy, c, d})
		}
	}
	return out
}

// ConfigKey は金融の旧B5Qキーを保ちLDだけを接頭辞へ分離します。
//
// 引数: cfg(Config)は設定です。返り値: stringは期待する本名です。
func ConfigKey(cfg Config) string {
	prefix := ""
	if cfg.Activation != "" {
		prefix = string(cfg.Activation) + "_"
	}
	return fmt.Sprintf("%sB5Q_%s_C%.0f_D%d", prefix, cfg.Policy, cfg.Slip, cfg.Delay)
}

// ConvertBatches は公開Deltaを変更せず名前付き外型だけを対応します。
//
// 引数: values([]oldtype.NativeBatch)は停止Tapeの復元通知です。
// 返り値: []finance.NativeBatchはnil/空配列も保持する同値通知です。
func ConvertBatches(values []oldtype.NativeBatch) []finance.NativeBatch {
	if values == nil {
		return nil
	}
	out := make([]finance.NativeBatch, len(values))
	for i, v := range values {
		out[i] = finance.NativeBatch{Method: v.Method, Delta: v.Delta}
	}
	return out
}

// SnapshotObserver は人工で全時点の空policy対照を確認する読取callbackです。
//
// 引数: TapeEventは読取対象、map[string]ActualResultは当配送後の独立copyです。
// 返り値: errorは人工対照の不一致です。市場ではnilにします。
type SnapshotObserver func(tape.TapeEvent, map[string]finance.ActualResult) error

// RunTape は保存Source/Scalar/gridの同じ順だけで全16口座を完結させます。
//
// 引数: input(tape.Tape)はRootが固定する既存入力です。
// 返り値: RunResult/errorは全会計又は未完結/出典不正です。Source/指標を生成しません。
func RunTape(input tape.Tape) (RunResult, error) { return RunObserved(input, nil) }

// RunObserved は人工全時点対照用の観測口を持つ共通配送です。
//
// 引数: input(Tape)、observer(SnapshotObserver又はnil)は入力と読取口です。
// 返り値: RunResult/errorは全16結果又は失敗です。未来値や期待採否を作りません。
func RunObserved(input tape.Tape, observer SnapshotObserver) (RunResult, error) {
	out := RunResult{Version: 1, Trial: 103, Session: input.Session, Books: map[string]finance.ActualResult{}, MainKeys: []string{}, DiagnosticKeys: []string{}, GridTimes: []float64{}, Scope: "固定Sourceの多玉/可変量/B5Qと比例返済を維持。主12起動比較＋S0診断4（保護義務未充足・採用不可）。Source/チャート/Gate再実行なし"}
	if input.Version != 1 || input.Scope == "" || !reflect.DeepEqual(input.Capabilities, tape.Capabilities()) {
		return out, fmt.Errorf("Tape版/対応範囲不一致")
	}
	before, e := json.Marshal(input)
	if e != nil {
		return out, e
	}
	sum := sha256.Sum256(before)
	out.TapeCanonicalSHA = hex.EncodeToString(sum[:])
	configs := Configurations()
	actors := make([]*finance.ActualBook, 0, len(configs))
	for _, cfg := range configs {
		b, e := finance.NewActualBook(input.Session, finance.ActorConfig{Policy: cfg.Policy, ActivationPolicy: cfg.Activation, SlipPts: cfg.Slip, DelaySeconds: cfg.Delay, EntryTiming: "B5Q", USOpen: input.Session.USOpen})
		if e != nil {
			return out, e
		}
		key := b.Snapshot().Key
		if key != ConfigKey(cfg) {
			return out, fmt.Errorf("金融key差: %s != %s", key, ConfigKey(cfg))
		}
		actors = append(actors, b)
		if cfg.Policy == "S0" {
			out.DiagnosticKeys = append(out.DiagnosticKeys, key)
		} else {
			out.MainKeys = append(out.MainKeys, key)
		}
	}
	previous := 0.0
	last := map[string]int64{}
	lastGrid := input.Session.Start - 1
	for i, event := range input.Events {
		if event.Ordinal != i+1 || event.At < previous {
			return out, fmt.Errorf("Tape順序不正: %d", i+1)
		}
		previous = event.At
		switch event.Kind {
		case "quote", "force":
			if event.Context != nil {
				return out, fmt.Errorf("Source行へ技法contextが混入")
			}
			if event.Kind == "quote" && (event.Quote == nil || event.Quote.Time != event.At) {
				return out, fmt.Errorf("Scalar時計不一致")
			}
			if event.Kind == "force" && event.Quote != nil {
				return out, fmt.Errorf("Forceへ架空Quoteが混入")
			}
			batches, e := tape.RestoreBatches(event, last)
			if e != nil {
				return out, e
			}
			batchBefore, e := json.Marshal(batches)
			if e != nil {
				return out, e
			}
			for j, b := range actors {
				if event.Kind == "quote" {
					e = b.OnNativeStep(event.Quote.Observation(), event.Quote.SourceLine, ConvertBatches(batches))
				} else {
					e = b.OnNativeForce(event.At, ConvertBatches(batches))
				}
				if e != nil {
					return out, fmt.Errorf("%s %s ordinal%d: %w", input.Session.ID, ConfigKey(configs[j]), event.Ordinal, e)
				}
			}
			batchAfter, e := json.Marshal(batches)
			if e != nil {
				return out, e
			}
			if !bytes.Equal(batchBefore, batchAfter) {
				return out, fmt.Errorf("共用Source通知を変更")
			}
			if event.Kind == "quote" {
				out.Events.Quotes++
			} else {
				out.Events.Forces++
			}
		case "grid":
			if event.Quote != nil || len(event.Methods)+len(event.NonEmpty) != 0 || event.Context != nil && event.Context.At != event.At || event.At <= lastGrid {
				return out, fmt.Errorf("保存gridの時計/Source混入/重複")
			}
			lastGrid = event.At
			for j, b := range actors {
				if e = b.OnEntryGrid(event.At); e != nil {
					return out, fmt.Errorf("%s %s grid%.0f: %w", input.Session.ID, ConfigKey(configs[j]), event.At, e)
				}
			}
			out.GridTimes = append(out.GridTimes, event.At)
			out.Events.Grids++
		default:
			return out, fmt.Errorf("不明イベント: %s", event.Kind)
		}
		if observer != nil {
			snapshots := map[string]finance.ActualResult{}
			for j, b := range actors {
				snapshots[ConfigKey(configs[j])] = b.Snapshot()
			}
			if e = observer(event, snapshots); e != nil {
				return out, e
			}
		}
	}
	for j, b := range actors {
		r, e := b.Finish()
		if e != nil {
			return out, fmt.Errorf("%s %s Finish: %w", input.Session.ID, ConfigKey(configs[j]), e)
		}
		key := ConfigKey(configs[j])
		if r.Key != key || !r.Finished || !r.Complete || r.Failure != "" || r.Totals.OpenBuy != 0 || r.Totals.OpenSell != 0 || r.Totals.PendingBuy != 0 || r.Totals.PendingSell != 0 {
			return out, fmt.Errorf("未完結口座: %s", key)
		}
		out.Books[key] = r
	}
	after, e := json.Marshal(input)
	if e != nil {
		return out, e
	}
	out.InputUnchanged = bytes.Equal(before, after)
	if !out.InputUnchanged || len(out.Books) != 16 || len(out.MainKeys) != 12 || len(out.DiagnosticKeys) != 4 {
		return out, fmt.Errorf("入力不変/主12診断4集合不一致")
	}
	out.Complete = true
	return out, nil
}

// CompareP0 は主旧P0四帳簿だけを未知fieldも残した全JSONで比較します。
//
// 引数: actual(RunResult)、baseline(map[string]json.RawMessage)は新結果と明示旧対照です。
// 返り値: errorは本文差です。LD/S0やenvelopeを旧一致へ代用しません。
func CompareP0(actual RunResult, baseline map[string]json.RawMessage) error {
	if len(baseline) != 4 {
		return fmt.Errorf("旧P0対照は四帳簿が必要")
	}
	for _, cfg := range Configurations() {
		if cfg.Policy != "P0" || cfg.Activation != "" {
			continue
		}
		key := ConfigKey(cfg)
		r, ok := actual.Books[key]
		raw, found := baseline[key]
		if !ok || !found {
			return fmt.Errorf("旧P0対照key欠落: %s", key)
		}
		if !json.Valid(raw) {
			return fmt.Errorf("旧P0対照JSON破損: %s", key)
		}
		a, e := json.Marshal(r)
		if e != nil {
			return e
		}
		var av, bv any
		ad := json.NewDecoder(bytes.NewReader(a))
		ad.UseNumber()
		bd := json.NewDecoder(bytes.NewReader(raw))
		bd.UseNumber()
		if e = ad.Decode(&av); e != nil {
			return e
		}
		if e = bd.Decode(&bv); e != nil {
			return e
		}
		if !reflect.DeepEqual(av, bv) {
			return fmt.Errorf("旧P0全文不一致: %s", key)
		}
	}
	return nil
}
