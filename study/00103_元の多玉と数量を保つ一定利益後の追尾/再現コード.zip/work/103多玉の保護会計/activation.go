package minidelayed103

import (
	"fmt"
	"math"
)

// ActivationPolicy は旧正益即起動と取得ATR基準の遅延起動を区別します。
type ActivationPolicy string

const (
	ActivationLegacy     ActivationPolicy = ""
	ActivationLD05       ActivationPolicy = "LD05"
	ActivationLD10       ActivationPolicy = "LD10"
	ActivationLD05Reason                  = "費用後残玉単価が10pt又は取得ATRの0.5倍以上で保護起動"
	ActivationLD10Reason                  = "費用後残玉単価が10pt又は取得ATRの1倍以上で保護起動"
)

// validateActivationConfig は遅延起動へ未比較の入口・出口を重ねる誤接続を拒否します。
//
// 引数: cfg(ActorConfig)は公開設定です。
// 返り値: errorは未知政策又は未比較の組合せです。空政策の旧APIは維持します。
func validateActivationConfig(cfg ActorConfig) error {
	switch cfg.ActivationPolicy {
	case ActivationLegacy:
		return nil
	case ActivationLD05, ActivationLD10:
		if cfg.Policy != "P0" || cfg.EntryTiming != "B5Q" || cfg.GatePolicy != "" || cfg.HarvestPolicy != "" || cfg.RiskPolicy != "" || cfg.ExitPolicy != "" {
			return fmt.Errorf("LDはGate/Harvest/Risk/Exit空のB5Q/P0専用です")
		}
		return nil
	default:
		return fmt.Errorf("未定義の利益保護起動政策です:%s", cfg.ActivationPolicy)
	}
}

// activationEligible は現在残玉の費用後単価だけで起動を判定します。
//
// 引数: policy(ActivationPolicy)、atr(*ATRLock)、unitYen(float64)は政策・一度固定した元ATR・残玉単価円です。
// 返り値: boolは起動条件成立です。ATR未知ならLDは保留し、旧空政策は従来のstrict正を維持します。
func activationEligible(policy ActivationPolicy, atr *ATRLock, unitYen float64) bool {
	if policy == ActivationLegacy {
		return unitYen > 0
	}
	if atr == nil {
		return false
	}
	factor := 0.5
	if policy == ActivationLD10 {
		factor = 1
	}
	return unitYen >= 100*math.Max(10, factor*atr.Value)
}

// activationReason はLDの起動証拠だけへ政策の意味を付けます。
//
// 引数: policy(ActivationPolicy)はconstructorで確認した政策です。
// 返り値: stringは新政策の理由又は旧JSONを増やさない空文字です。
func activationReason(policy ActivationPolicy) string {
	switch policy {
	case ActivationLD05:
		return ActivationLD05Reason
	case ActivationLD10:
		return ActivationLD10Reason
	}
	return ""
}
