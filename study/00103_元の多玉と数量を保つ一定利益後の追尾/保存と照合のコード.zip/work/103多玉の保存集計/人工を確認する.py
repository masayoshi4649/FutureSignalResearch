"""103の停止済みGo型と狭い手製境界で保存算術と表示型を確認する。"""

from copy import deepcopy
from decimal import Decimal
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SPEC = importlib.util.spec_from_file_location("103保存人工の対象", HERE / "集計.py")
M = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)
FIXTURES = ROOT / "work/103多玉の保護会計/人工/停止版"
STOP = ROOT / "work/103多玉の保護会計/停止.json"
STOP_SHA = "e051a2401c8919835adfea52bf346d644707239fd030f0b13f101586b4c1d52b"


def reject(value, mutate):
    """
    機能: 元Go型を変えず複写への一破損が拒否されることを確認する。
    引数: value(dict)、mutate(callable)は元型と破損注入。
    返り値: None。破損が成功すれば例外。
    """
    broken = deepcopy(value)
    mutate(broken)
    try:
        M.inspect_scene(broken)
    except (ValueError, KeyError):
        return
    raise AssertionError("保存破損を成功扱い")


def empty_scene(value):
    """
    機能: Viewer空資源と欠測分母だけの型器具を作る。
    引数: value(dict)はSession/設定の出典となる停止Go型。
    返り値: dictは手製空型。自然Sourceや金融再生の結果ではない。
    """
    out = deepcopy(value)
    for b in out["actors"].values():
        for name in ("orders", "fills", "positions", "source_events", "entry_opportunities", "grid_traces"):
            b[name] = []
        b["metrics"] = {k: 0 for k in b["metrics"]}
        b["grid_metrics"] = {k: 0 for k in b["grid_metrics"]}
        b["totals"] = {k: 0 for k in b["totals"]}
        b["account"] = {k: (0 if k in ("max_drawdown", "count", "max_gap_seconds") else None) for k in b["account"]}
    return out


def main():
    """
    機能: Go64口座・空型・半円・LD・分子境界と狭い破損を検査する。
    引数: なし。Root許可の停止人工とコードだけを読む。
    返り値: None。新規人工receiptを保存する。
    """
    assert M.digest(STOP) == STOP_SHA
    paths = sorted(FIXTURES.glob("*.json"))
    assert len(paths) == 4
    before = {str(p): M.digest(p) for p in [STOP, M.GRID_PATH, M.GRID.BASE_PATH] + paths}
    values = [M.load(p) for p in paths]
    books = positions = fills = partial = compare_count = 0
    for value in values:
        frozen = M.freeze(value)
        checked = M.inspect_scene(value)
        assert M.freeze(value) == frozen
        for key, r in checked.items():
            books += 1; positions += len(r["positions"])
            shown = M.BASE.viewer_trades(r["book"])
            fills += len(shown)
            assert len(shown) == len(r["book"]["fills"])
            for trade, fill in zip(shown, r["book"]["fills"]):
                assert trade["source_line"] == fill["quote"]["source_line"]
                assert trade["fee_yen"] == fill["fee_yen"] + fill["slip_yen"]
            for p in r["positions"].values():
                partial += sum(f["action"] == "close" and f["position_id"] == p["id"] for f in r["book"]["fills"]) > 1
            stat = M.combine([M.summarize_book(r["book"], r)])
            assert stat["net_yen"] == r["totals"]["net_yen"]
        for key in M.MAIN_KEYS[4:]:
            M.compare_positions(checked[key.split("_", 1)[1]], checked[key]); compare_count += 1
    assert (books, positions, fills) == (64, 128, 320) and partial > 0
    empty = empty_scene(values[0]); ec = M.inspect_scene(empty)
    for r in ec.values():
        s = M.combine([M.summarize_book(r["book"], r)])
        assert s["PF"] is None and s["positions"] == 0
        assert s["活動主表"]["active"] == 0 and s["活動主表"]["unknown"] == 76
        assert not s["活動主表"]["最低25%"] and M.BASE.viewer_trades(r["book"]) == []
    key = "LD05_B5Q_P0_C0_D0"
    target = values[0]["actors"][key]["positions"][0]
    assert target["atr"]["value"] == Decimal("40.75") and target["atr"]["width"] == 85
    bound = deepcopy(target)
    bound["activation"] = deepcopy(bound["marks"]["first_unit_positive"])
    for point in bound["marks"].values():
        if point is not None: point["unit_net"] = 0
    bound["activation"]["unit_net"] = Decimal("2037.5")
    bound["marks"]["first_unit_positive"] = deepcopy(bound["activation"])
    M.verify_activation(bound, None, "P0", "LD05")
    bound["activation"]["unit_net"] = Decimal("2037.0")
    try:
        M.verify_activation(bound, None, "P0", "LD05")
    except ValueError:
        pass
    else:
        raise AssertionError("非整数ATR閾値未達の起動")
    mutations = [
        lambda v: v["actors"][M.KEYS[0]]["fills"][0].update(fee_yen=Decimal("0.000000001")),
        lambda v: v["actors"][M.KEYS[0]]["fills"][-1].update(net_contribution_yen=Decimal("0.000000001")),
        lambda v: v["actors"][M.KEYS[0]]["fills"][0]["quote"].update(source_line=1),
        lambda v: v["actors"][M.KEYS[0]]["fills"][-1]["allocations"][0].update(quantity=99),
        lambda v: v["actors"][M.KEYS[0]]["positions"][0]["source"].update(parent="他出生"),
        lambda v: v["actors"][key]["positions"][0].update(activation_reason="旧P0"),
        lambda v: v["actors"][key]["positions"][0].update(activation=deepcopy(v["actors"][key]["positions"][0]["marks"]["first_unit_positive"])),
        lambda v: v["actors"][key]["positions"][0]["atr"].update(width=80),
        lambda v: v["actors"][key]["config"].update(activation_policy=""),
        lambda v: v["actors"].pop(M.KEYS[-1]),
        lambda v: v["actors"][M.KEYS[0]]["grid_traces"][0].update(open_buy=99),
        lambda v: v["actors"][M.DIAGNOSTIC_KEYS[0]]["positions"][0].update(protection_active=True),
    ]
    for mutate in mutations: reject(values[0], mutate)
    # 参加率の狭い型器具。遅いfillを要求元枠の主newへ戻さない。
    s = values[0]["session"]; g = s["start"] + 1800
    thin = {"session": s, "grid_traces": [{"at": g + i * 300, "open_buy": int(i == 2), "open_sell": 0, "unknown_count": 0, "us_quiet": None} for i in range(3)],
            "entry_opportunities": [{"status": "accepted", "evaluated_at": g, "entry_order_id": "遅い"}, {"status": "accepted", "evaluated_at": g + 600, "entry_order_id": "同枠"}],
            "fills": [{"order_id": "遅い", "action": "new", "quote": {"time": g + 301}}, {"order_id": "同枠", "action": "new", "quote": {"time": g + 601}}]}
    part = M.participation(thin, {"orders": {}})
    assert part["active"] == part["new"] == 1 and part["hold"] == 0
    assert part["受理new"] == part["後の取得を戻したnew"] == part["実fill時刻bucket"] == 2
    assert part["遅い取得の要求枠"] == 1 and part["当時実保有"] == 1 and part["unknown"] == 73
    # 全Source値を使うため、同じsignal_idでも親の差は同実入口にしない。
    a = M.inspect_scene(values[0])[M.KEYS[0]]
    b = {**a, "positions": deepcopy(a["positions"])}
    next(iter(b["positions"].values()))["source"]["parent"] = "別の親"
    diff = M.compare_positions(a, b)
    assert diff["前のみ玉"] == diff["後のみ玉"] == 1 and diff["全差額"] == 0
    with tempfile.TemporaryDirectory() as t:
        p = Path(t) / "固定.json"
        M.BASE.write_json(p, {"version": 1, "trial": 103, "fixed": False, "stage": "full54"})
        try: M.prepare(p, M.digest(p), Path(t) / "新規")
        except ValueError: pass
        else: raise AssertionError("未固定でNativeへ進行")
        rows = M.BASE.viewer_trades(a["book"])
        M.BASE.write_json(Path(t) / "Viewer型.json", {"schema_version": 1, "resources": [{"point_value": 100, "pnl_format": "trades"}], "trades": rows})
        assert M.load(Path(t) / "Viewer型.json")["trades"] == rows
    assert before == {p: M.digest(Path(p)) for p in before}
    receipt = {"成功": True, "scope": "停止Go型の保存算術/部分配賦/LD保存点/参加列/Viewer型。Source/金融/原板再生なし",
               "Go場面": 4, "Go会計": books, "実玉": positions, "部分返済玉": partial, "Viewer全実Fill行": fills,
               "比較接続": compare_count, "手製空会計": 16, "非整数ATRとLD等号境界": True, "狭い破損拒否": len(mutations),
               "参加の同枠遅延_二重除外_欠測": True, "Source全値join": True, "未固定本文前拒否": True,
               "金融停止SHA256": STOP_SHA, "入力SHA256前": before, "入力SHA256後": before, "前後不変": True,
               "codeSHA256": {p.name: M.digest(p) for p in (HERE / "集計.py", Path(__file__))}, "市場Native_Raw_Tape本文_金融_Source_HTTP": 0}
    M.BASE.write_json(HERE / "人工確認_停止版.json", receipt)
    print(json.dumps(receipt, ensure_ascii=False, default=M.BASE.serial))


if __name__ == "__main__":
    main()
