# 103 多玉の保存集計

2026-11-09。市場損益を読む前の保存器。主12口座（P0／LD05／LD10×C0/C5×D0/D1）と、無保護S0の診断4口座を分ける。市場Native・原板・CSV・実Tape本文は今回読まず、金融／Source／特徴形成／HTTPは実行していない。

固定94の部分所有・返済配賦・MTM・Viewer変換と、固定95の出生一枠・Source比例返済・grid照合をSHA指定で再用する。旧規範を書き換えず、関数のcode objectと独立した名前空間を使用する。新規政策名を旧政策に偽装した保存結果は作らない。

## 検算範囲と限界

- 実gross、片道38.5円、片道仮定滑りC×100円、全返済片の入口／出口費用、純現金寄与、最終純額をDecimalで厳密検算する。半円を丸めない。
- 注文／Fill／配賦／実玉のID・全SourceIdentity・方向・部分量・BBO、要求より後のIndex／物理行、D0/D1、Sourceのceil比例返済、予約込み余力、各側10枚、全残0を確認する。同秒でも原行／位相を区別する。
- 保存されたu/W点・口座極値／DD点を、実Fillの履歴とpre_fill／after_sourceに結ぶ。保存極値からflatな場間のDDを連結する。最初eligible行の約定、全原行の極値取り落とし、起動の真の初回を別engineで再形成した証明ではない。
- 旧P0だけActivationとFirstUnitPositiveの等式を維持。LDはATRLock.Valueの元IEEE64計算による円閾値・既知時計・理由・初正益以後の順を検査する。保存された適格点より遅い起動も拒否するが、未保存の全原行を再構成しない。
- ATRのageは元float64時計差、Widthは`5*ceil(2*Value/5)`の元演算順に結ぶ。Width/2を元ATRにしない。金額やBBOの比較へfloat許容を広げない。

旧94の`verify_marks`で置換する照合は、初正益即起動の等式（LD専用規範へ）、ATR age、2ATR幅の3項だけ。他の保存点・符号・極値・金額の照合は元関数のまま。旧95のSource／grid規範も、103本名の対応だけを名前空間へ渡す。configの追加起動政策・position.activation_reasonは元正本に保ち別検算し、共通金融の射影にだけ含めない。未使用Risk/HG/技法退出の状態や要求が混入すれば拒否する。

旧95と新P0の**市場JSON全文同値はRootの別証拠**であり、本保存器が成功trueへ補わない。S0はSource返済だけの診断用で、利益保護義務を満たす採用候補にはしない。固定Sourceの買い優先例外を保護の対称性で解消したとも呼ばない。

## 参加率

主表は`[Start+1800, ForceClose)`の5分全予定、Day76／Night148、全54で6,048枠。副表は`[Start+1800, End-1800)`で5,832枠。USquiet、Source不在・返済予約、個別P締切、既知拒否、欠測／UNKNOWNを分母から落とさない。

主newは**当枠で受理したentryが同じ[t,t+300)に実Fillした枠**。当gridの`open_buy+open_sell>0`をHOLDとし、和集合を一枠で数える。受理のみ、要求元枠に後の成功を全部戻したnew、実Fill時刻bucket、遅い取得を別列にする。欠測gridはUNKNOWNとし、後の所有で埋めない。既存gridの当時open自体は固定Timeline／Source位相へ照合する。

25%／50%は各口座ごとに判定する。12主口座や費用反復を独立した市場例12倍にしない。S0の活動率も診断列として表示するが採用数へ足さない。

## 集計と出力

実現粗額／fee／slip／net、正負・0玉／PF、回数／枚数、u正益後とProtectionActivated後の最終赤字を別分母で集計する。Source／保護の要求・約定・数量・返済片純額を排他に分類し、全実現額との和を確認する。保存点連結DD、日夜・開始日別・売買別、場別活動を出す。0玉や0純額を黒字扱いしない。

P0対LD05／LD10の8系列はSourceIdentity全値で出生対応し、要求時計／要求quote全値／取得quote全値／Side／価格／初期量／SourceHoldが一致する場合だけ同実入口の退出差にする。他は取得変更・前だけ／後だけの実参加額に分け、加法一致を検査する。ID文字列を分割して元Sourceを推測しない。

`結果.json`、`結果.md`、`保存会計の確認.json`、`一覧.resources.json`、16×54の実約定`.trades.jsonl`を新規保存する。Viewer schema1、mini点価100、fee_yenは指定fee＋仮定slip。物理source_lineは元Fill.Quote.SourceLineを使い、FeaturesIndexに置き換えない。内部Book全件はNative参照とSHAで残し、重複レポートへ転記しない。

機会損失、未参加／退出後価格、MFE／理想峰、資本金不明ROIは算出しない。

## 最小固定とCLI

金融のfull54成功後、Rootが次の3FileRefを実SHAで固定する。相対pathは固定JSONのディレクトリ基準。未固定はNative本文前に拒否する。

```json
{
  "version": 1,
  "trial": 103,
  "fixed": true,
  "stage": "full54",
  "condition": {"path": "条件.json", "sha256": "実SHA"},
  "completion": {"path": "金融完了.json", "sha256": "実SHA"},
  "code": {"path": "集計.py", "sha256": "保存器の実SHA"}
}
```

```powershell
python -B -X utf8 work/103多玉の保存集計/集計.py `
  --fixed <Root固定JSON> --fixed-sha <そのSHA> --out <存在しない新規dir>
```

条件と完了の全16設定、完全54場、864会計（主648／診断216）、同条件、金融の入力code前後一致、各Native SHA、保存器自身のSHAを先に確認する。架空の全原行独立成功receiptは要求しない。本番の保存CLIは今回未実行。Rootが実成功値で固定してから実行する。

## 人工と由来

金融停止`e051a240…`のGo型4場面64会計、128玉（部分返済64玉）、実Fill320行、32ペアを保存検算した。12破損を拒否し、手製空16資源、非整数ATR／LD等号、非二進有限ATRの厳密な閾値、遅いFillを主newへ戻さない分子、欠測、未固定拒否を確認した。

runtime停止`9e899ea0…`の4出力型は、既に検算した金融64口座へ全値一致した。ここでは金融検算を再走査せず対応だけを保存。人工Source・ATRを自然Source生成／実CSV形成と呼ばない。

`人工確認_停止版.json`、`metadata人工確認_停止版.json`、`runtime型の接続.json`が現在コードへの証拠。初回receiptは履歴として保持する。metadata人工の54件はprepareだけの手製型で、実金融成功や市場Nativeを作ったものではない。

```powershell
python -B -X utf8 work/103多玉の保存集計/人工を確認する.py
python -B -X utf8 work/103多玉の保存集計/metadataと非整数境界を確認する.py
```

receiptは新規作成専用なので、再実行には別のreceipt先を用意する。出典コードのSHAと変更境界は[由来と検算範囲.json](由来と検算範囲.json)へ記録する。
