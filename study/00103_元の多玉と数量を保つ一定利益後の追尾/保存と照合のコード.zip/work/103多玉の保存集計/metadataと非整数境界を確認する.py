"""103保存器の小型metadataと非二進有限ATRの境界だけを検査する。"""

from copy import deepcopy
from decimal import Decimal
import importlib.util
from pathlib import Path
import tempfile


HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("103保存metadataの対象", HERE / "集計.py")
M = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)


def main():
    """
    機能: 本文を開かない54場metadataと起動閾値の演算境界を確認する。
    引数: なし。全て手製metadata又は停止Go型の一玉だけ。
    返り値: None。市場成功や金融独立再生を作らない。
    """
    fixture = M.load(M.ROOT / "work/103多玉の保護会計/人工/停止版/方向1_未知ATRfalse.json")
    p = deepcopy(fixture["actors"]["LD05_B5Q_P0_C0_D0"]["positions"][0])
    for point in p["marks"].values():
        if point is not None: point["unit_net"] = 0
    p["activation"] = deepcopy(p["marks"]["first_unit_positive"])
    p["marks"]["first_unit_positive"] = deepcopy(p["activation"])
    p["atr"]["value"] = Decimal("40.75000000000001")
    p["activation"]["unit_net"] = Decimal("2037.5")
    try: M.verify_activation(p, None, "P0", "LD05")
    except ValueError: pass
    else: raise AssertionError("元IEEE64未達を十進数丸めで採用")
    p["activation"]["unit_net"] = Decimal("2038")
    M.verify_activation(p, None, "P0", "LD05")
    positive = rejected = 0
    with tempfile.TemporaryDirectory() as temp:
        root = Path(temp)
        sessions = []; day = M.date(2026, 9, 21)
        while day <= M.date(2026, 10, 27):
            if day.weekday() < 5: sessions.extend(f"{day.isoformat()}_{kind}" for kind in ("Day", "Night"))
            day += M.timedelta(days=1)
        # この54本文は読まないmetadata器具。金融出力として使用しない。
        tasks = []
        for sid in sessions:
            native = root / (sid + ".json.gz")
            native.write_bytes(b"metadata-only-not-financial-gzip")
            tasks.append({"session": sid, "path": str(native), "sha256": M.digest(native), "books": 16, "totals": {k: {} for k in M.KEYS}})
        dep = M.ROOT / "work/103多玉の一定利益保護/replay.go"
        dependency = {str(dep): M.digest(dep)}
        condition = {"version": 1, "trial": 103, "fixed": True, "configs": M.configurations(), "code_sha256": dependency, "scenes": [{"session": sid} for sid in sessions]}
        cp = root / "condition.json"; M.BASE.write_json(cp, condition)
        done = {"version": 1, "trial": 103, "success": True, "stage": "full54", "scenes": 54, "books_per_scene": 16, "books": 864, "main_books": 648, "diagnostic_books": 216,
                "configs": M.configurations(), "condition_sha256": M.digest(cp), "input_code_unchanged": True,
                "input_code_sha256_before": dependency, "input_code_sha256_after": dependency,
                "source_reexecuted": False, "charts_recomputed": False, "gate_executed": False, "raw_csv_read": 0, "results": tasks}
        dp = root / "done.json"; M.BASE.write_json(dp, done)
        def run_fixed(name, completion):
            """
            機能: 新規固定3参照を手製metadataへ結びprepareだけ呼ぶ。
            引数: name(str)、completion(dict)は器具名と完了の型。
            返り値: tupleはprepareの結果。Native本文を開かない。
            """
            receipt = root / (name + "-done.json"); M.BASE.write_json(receipt, completion)
            code = HERE / "集計.py"
            fixed = {"version": 1, "trial": 103, "fixed": True, "stage": "full54", "condition": {"path": str(cp), "sha256": M.digest(cp)},
                     "completion": {"path": str(receipt), "sha256": M.digest(receipt)}, "code": {"path": str(code), "sha256": M.digest(code)}}
            fp = root / (name + ".json"); M.BASE.write_json(fp, fixed)
            return M.prepare(fp, M.digest(fp), root / (name + "-out"))
        result = run_fixed("正常metadata", done)
        assert len(result[0]) == 54
        positive += 1
        mutations = [lambda d: d.update(success=False), lambda d: d.update(books=863),
                     lambda d: d.update(condition_sha256="0" * 64), lambda d: d["results"].pop(),
                     lambda d: d["results"][0].update(sha256="0" * 64)]
        for n, mutation in enumerate(mutations):
            broken = deepcopy(done); mutation(broken)
            try: run_fixed("破損" + str(n), broken)
            except ValueError: rejected += 1
            else: raise AssertionError("不正完了metadataを受理")
    M.BASE.write_json(HERE / "metadata人工確認_停止版.json", {"成功": True, "scope": "手製metadataでprepareだけ。金融成功又はNative本文を作る検査ではない",
                      "正常metadata": positive, "拒否": rejected, "非二進有限ATRの元IEEE64閾値": True,
                      "codeSHA256": {p.name: M.digest(p) for p in (HERE / "集計.py", Path(__file__))}, "市場_Raw_金融_Source_HTTP": 0})


if __name__ == "__main__":
    main()
