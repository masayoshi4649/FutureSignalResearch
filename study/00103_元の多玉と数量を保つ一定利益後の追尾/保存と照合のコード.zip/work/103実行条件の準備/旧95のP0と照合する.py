"""新103の追加policy空P0を固定95の同じ四口座へ全JSON比較する。"""

import argparse
from decimal import Decimal
import gzip
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
PROOF = ROOT / "study/00095_5分判断と開始30分見送り/完了記録.json"
PROOF_SHA = "b7df0d9f793fca1ee9fbb489e045b927f8cf4b46e0e81a6c199920f128e4d943"
KEYS = [f"B5Q_P0_C{c}_D{d}" for c in (0, 5) for d in (0, 1)]


def digest(path: Path) -> str:
    """
    機能: 明示した入力の圧縮bytes又はmetadataをhashする。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path: Path):
    """
    機能: 保存JSONを整数とDecimalのまま読む。
    引数: path(Path)は指紋確認済みのJSON/gzip。
    返り値: dict/listは元field・null・配列順を維持する。
    """
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8") as stream:
        return json.load(stream, parse_float=Decimal)


def compare(a, b, at: str, differences: list) -> int:
    """
    機能: 型・全key・配列順を保持して全値を比較する。
    引数: a/b(JSON値)、at(str)、differences(list)は新旧・位置・差分先。
    返り値: intは比較した末端と構造の項目数。
    """
    if isinstance(a, dict) and isinstance(b, dict):
        if a.keys() != b.keys():
            differences.append({"位置": at, "新のみkey": sorted(a.keys()-b.keys()), "旧のみkey": sorted(b.keys()-a.keys())})
        return 1 + sum(compare(a[k], b[k], at+"/"+k, differences) for k in a.keys() & b.keys())
    if isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            differences.append({"位置": at, "新配列長": len(a), "旧配列長": len(b)})
        return 1 + sum(compare(x, y, at+"/"+str(i), differences) for i, (x, y) in enumerate(zip(a, b)))
    numeric = all(isinstance(v, (int, Decimal)) and not isinstance(v, bool) for v in (a, b))
    if not (a == b and (numeric or type(a) is type(b))):
        differences.append({"位置": at, "新": repr(a), "旧": repr(b)})
    return 1


def main() -> None:
    """
    機能: 正常終了したfirst2又はfull54のP0四だけを旧95へ照合する。
    引数: --completion/--completion-sha、--outは金融完了と新規保存先。
    返り値: None。差があれば非0終了し、未照合やLDを成功補完しない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--completion", type=Path, required=True)
    parser.add_argument("--completion-sha", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    assert not args.out.exists()
    completion = args.completion.resolve()
    assert digest(completion) == args.completion_sha and digest(PROOF) == PROOF_SHA
    run, proof = read(completion), read(PROOF)
    assert run["success"] and run["trial"] == 103 and run["books_per_scene"] == 16 and run["input_code_unchanged"]
    expected = 2 if run["stage"] == "first2" else 54
    assert run["stage"] in ("first2", "full54") and run["scenes"] == expected and run["books"] == expected*16
    before = {str(completion): args.completion_sha, str(PROOF): PROOF_SHA, str(Path(__file__).resolve()): digest(Path(__file__).resolve())}
    details, count = [], 0
    for scene in run["results"]:
        sid = scene["session"]
        current = Path(scene["path"])
        if not current.is_absolute():
            current = completion.parent / current
        old = PROOF.parent / "成果物" / (sid+".json.gz")
        assert digest(current) == scene["sha256"]
        assert digest(old) == proof["自己を除く正式指紋"]["成果物/"+sid+".json.gz"]
        before[str(current)], before[str(old)] = scene["sha256"], digest(old)
        a, b = read(current), read(old)
        assert a["session"]["id"] == b["session"] == sid
        differences, fields = [], 0
        for key in KEYS:
            fields += compare(a["books"][key], b["books"][key], key, differences)
        details.append({"session": sid, "会計": 4, "照合項目": fields, "差分数": len(differences), "差分先頭": differences[:20]})
        count += fields
    assert before == {p: digest(Path(p)) for p in before}
    same = all(row["差分数"] == 0 for row in details)
    result = {"成功": same, "scope": "新103追加policy空P0四Bookと固定95B5Q四の全JSON・除外0",
              "stage": run["stage"], "場数": expected, "会計数": expected*4, "照合項目数": count,
              "除外": [], "LD対照": False, "S0対照": False, "金融再実行": 0, "Source再形成": 0,
              "入力コードSHA256前後": before, "前後不変": True, "details": details}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(json.dumps({"成功": same, "場数": expected, "会計数": expected*4, "照合項目数": count,
                      "差分数": sum(r["差分数"] for r in details)}, ensure_ascii=False))
    if not same:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
