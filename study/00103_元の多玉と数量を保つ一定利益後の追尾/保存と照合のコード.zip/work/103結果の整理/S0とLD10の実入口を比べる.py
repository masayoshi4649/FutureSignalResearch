"""103の追加保護なし診断とLD10の同実入口を、保存Nativeで照合する。"""

from collections import Counter
from decimal import Decimal
import gzip
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
STUDY = ROOT / "study/00103_元の多玉と数量を保つ一定利益後の追尾"


def sha(path: Path) -> str:
    """
    機能: 入力またはコードの内容指紋を求める。
    引数: path(Path)は実在ファイル。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def freeze(value: object) -> object:
    """
    機能: JSON全公開値を同一性の比較に使える形へ変換する。
    引数: value(object)はJSON値。
    返り値: objectはキー順に依存しない再帰値。
    """
    if isinstance(value, dict):
        return tuple((key, freeze(item)) for key, item in sorted(value.items()))
    if isinstance(value, list):
        return tuple(freeze(item) for item in value)
    return value


def signature(position: dict, orders: dict) -> tuple:
    """
    機能: 同じSourceの実要求・実取得の全公開属性を比較する。
    引数: position(dict)、orders(dict)は玉とID別注文。
    返り値: tupleは要求時計と気配・取得気配/価格/方向/枚数/元所有ID。
    """
    order = orders[position["entry_order_id"]]
    return (order["request_time"], freeze(order["request_quote"]), freeze(position["entry_quote"]),
            position["entry_price"], position["side"], position["initial_quantity"], position["source_hold_id"])


def compare(before: dict, after: dict) -> dict:
    """
    機能: Source全値で所有を結び、実現差を同実入口と実参加差へ分ける。
    引数: before(dict)、after(dict)は同場・同費用の完成会計。
    返り値: dictは件数・実現差額。未参加や決済後の仮想利益を含めない。
    """
    aa = {freeze(p["source"]): p for p in before["positions"]}
    bb = {freeze(p["source"]): p for p in after["positions"]}
    assert len(aa) == len(before["positions"]) and len(bb) == len(after["positions"])
    orders_a = {o["id"]: o for o in before["orders"]}
    orders_b = {o["id"]: o for o in after["orders"]}
    result = Counter()
    for source in aa.keys() | bb.keys():
        a, b = aa.get(source), bb.get(source)
        if a is None:
            result["LDのみ玉"] += 1
            result["LDのみ実現額"] += b["realized_net"]
        elif b is None:
            result["S0のみ玉"] += 1
            result["S0のみ実現額"] += a["realized_net"]
        else:
            kind = "同実入口" if signature(a, orders_a) == signature(b, orders_b) else "取得変更"
            result[kind + "玉"] += 1
            result[kind + "差額"] += b["realized_net"] - a["realized_net"]
    result["全差額"] = after["totals"]["net_yen"] - before["totals"]["net_yen"]
    assert result["全差額"] == result["同実入口差額"] + result["取得変更差額"] - result["S0のみ実現額"] + result["LDのみ実現額"]
    return {key: result[key] for key in ("全差額", "同実入口玉", "同実入口差額", "取得変更玉", "取得変更差額", "S0のみ玉", "S0のみ実現額", "LDのみ玉", "LDのみ実現額")}


def main() -> None:
    """
    機能: 新たな金融再生をせず54場の四つの完成会計対照を検査する。
    引数: なし。103正式金融完了を入力指紋の正本とする。
    返り値: None。限定した事後診断の証拠を新規保存する。
    """
    output = STUDY / "検査/全54場/S0対LD10の同実入口.json"
    assert not output.exists()
    receipt_path = STUDY / "検査/全54場/金融完了.json"
    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    assert receipt["success"] and receipt["scenes"] == 54
    paths = {receipt_path, Path(__file__)}
    pairs = {}
    totals = {}
    for c, d in ((0, 0), (0, 1), (5, 0), (5, 1)):
        key = f"C{c}_D{d}"
        pairs[key] = []
        totals[key] = Counter()
    for scene in receipt["results"]:
        path = Path(scene["path"])
        assert sha(path) == scene["sha256"]
        paths.add(path)
        native = json.loads(gzip.decompress(path.read_bytes()), parse_float=Decimal)
        for key in pairs:
            row = compare(native["books"][f"B5Q_S0_{key}"], native["books"][f"LD10_B5Q_P0_{key}"])
            totals[key].update(row)
            pairs[key].append({"session": scene["session"], **row})
    fingerprints = {str(p.relative_to(ROOT)): sha(p) for p in sorted(paths)}
    for name, expected in fingerprints.items():
        assert sha(ROOT / name) == expected
    proof = {"成功": True, "scope": "103同費用/同遅延のS0診断対LD10の実要求・実取得の照合。事後診断でありSourceや金融の再実行ではない",
             "場数": 54, "比較会計対": 216, "集計": totals, "場別": pairs,
             "入力コードSHA256": fingerprints, "前後不変": True, "金融再実行": 0, "Source再形成": 0,
             "S0は利益保護義務未充足の診断専用": True}
    def number(value: Decimal) -> int | float:
        """
        機能: 検査差額をJSONの数値へ保存する。
        引数: value(Decimal)は保存会計の数値。
        返り値: int|floatは整数又は半円を保った数値。
        """
        assert isinstance(value, Decimal)
        return int(value) if value == value.to_integral() else float(value)
    output.write_text(json.dumps(proof, ensure_ascii=False, indent=2, default=number) + "\n", encoding="utf-8")
    print(json.dumps({"成功": True, "集計": totals}, ensure_ascii=False, default=number))


if __name__ == "__main__":
    main()
