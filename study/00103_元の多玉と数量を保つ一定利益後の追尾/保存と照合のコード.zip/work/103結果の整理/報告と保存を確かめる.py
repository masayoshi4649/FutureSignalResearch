"""103の報告・保存・固定コードを照合し、再現資料の参照を残す。"""

import hashlib
import json
from pathlib import Path
import re


ROOT = Path(__file__).resolve().parents[2]
STUDY = ROOT / "study/00103_元の多玉と数量を保つ一定利益後の追尾"


def sha(path: Path) -> str:
    """
    機能: 一つの実在ファイルの内容指紋を求める。
    引数: path(Path)は読取対象。
    返り値: strはSHA256の16進表記。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path: Path) -> dict:
    """
    機能: UTF-8の保存JSONを読み込む。
    引数: path(Path)は保存先。
    返り値: dictは保存した内容。
    """
    return json.loads(path.read_text(encoding="utf-8-sig"))


def main() -> None:
    """
    機能: 金融の再実行をせず103の保存物と文書リンクを検査する。
    引数: なし。固定103と生成済みの保存物だけを参照する。
    返り値: None。成功時だけ限定した検査証拠を書き出す。
    """
    output = STUDY / "検査/報告と保存の確認.json"
    assert not output.exists()
    condition = read(STUDY / "条件.json")
    result = read(STUDY / "成果物/結果.json")
    saved = read(STUDY / "成果物/保存会計の確認.json")
    financial = read(STUDY / "検査/全54場/金融完了.json")
    baseline = read(STUDY / "検査/全54場/旧95P0全文対照.json")
    viewer = read(STUDY / "検査/全54場/Viewer代表4資源.json")
    assert saved["成功"] and saved["会計"] == saved["資源"] == 864
    assert saved["不一致数"] == 0 and saved["前後不変"]
    assert financial["success"] and financial["scenes"] == 54 and financial["books"] == 864
    assert not financial["source_reexecuted"] and not financial["charts_recomputed"]
    assert baseline["成功"] and baseline["会計数"] == 216 and baseline["照合項目数"] == 1655919
    assert viewer["成功"] and viewer["実GET資源"] == 4 and viewer["一覧資源数"] == 864
    assert sha(STUDY / "条件.json") == saved["conditionSHA256"] == financial["condition_sha256"]
    assert sha(STUDY / "検査/全54場/金融完了.json") == saved["completionSHA256"]

    # ----------------------------------------
    # 固定コード・資料と保存出力を内容指紋で照合する。
    for name, expected in condition["code_sha256"].items():
        path = Path(name)
        if not path.is_absolute():
            path = ROOT / path
        assert sha(path) == expected, name
    for name, expected in saved["出力SHA256"].items():
        assert sha(STUDY / "成果物" / name) == expected, name
    assert len(result["集計"]) == 16
    for key, value in result["集計"].items():
        assert value["open_buy"] == value["open_sell"] == value["pending_buy"] == value["pending_sell"] == 0
        assert value["entry_quantity"] == value["close_quantity"]
        assert value["net_yen"] == value["gross_yen"] - value["fee_yen"] - value["slip_yen"]
        activity = value["活動主表"]
        assert activity["denom"] == 6048
        assert activity["active"] == activity["new"] + activity["hold"]
        assert activity["active"] + activity["wait"] + activity["unknown"] == 6048
        assert activity["欠測"] == activity["遅い取得の要求枠"] == 0
    assert len(result["P0対LDの同実入口と実参加差"]) == 8
    for rows in result["P0対LDの同実入口と実参加差"].values():
        assert len(rows) == 54
        for row in rows:
            assert row["取得変更玉"] == row["前のみ玉"] == row["後のみ玉"] == 0
            assert row["全差額"] == row["同実入口差額"]

    # ----------------------------------------
    # ライブ文書だけを確認し、固定済み実行前資料には触れない。
    missing = []
    checked = []
    for name in ["README.md", "設定と結果.md"]:
        path = STUDY / name
        text = path.read_text(encoding="utf-8-sig")
        for target in re.findall(r"\]\(([^)]+)\)", text):
            if target.startswith(("http:", "https:", "#")):
                continue
            target = target.split("#", 1)[0].strip("<>")
            if target and not (path.parent / target).exists():
                missing.append({"文書": name, "参照": target})
        checked.append({"path": name, "sha256": sha(path)})
    assert not missing, missing
    proof = {"成功": True, "scope": "固定212コード/資料、保存出力指紋、16集計算術、同実入口8比較、ライブ2文書リンクの確認。独立全原行再生ではない",
             "固定コード資料数": len(condition["code_sha256"]), "金融会計": 864, "保存会計": 864,
             "旧95全文対照会計": 216, "旧95対照項目": 1655919, "同実入口比較": 8,
             "Viewer一覧": 864, "Viewer実GET": 4, "文書": checked, "リンク欠損": missing,
             "確認コード": {"path": str(Path(__file__).relative_to(ROOT)), "sha256": sha(Path(__file__))},
             "研究目標達成": False, "実運用採用": False, "金融再実行": 0, "Source再形成": 0}
    output.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"成功": True, "固定コード資料数": len(condition["code_sha256"]), "会計": 864, "リンク欠損": len(missing)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
