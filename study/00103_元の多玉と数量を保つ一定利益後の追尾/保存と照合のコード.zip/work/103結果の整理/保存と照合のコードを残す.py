"""金融実行前ZIPを変更せず、103の保存・照合コードを別に保存する。"""

import hashlib
import json
from pathlib import Path
import zipfile


def main() -> None:
    """
    機能: 保存器と事後照合コードを元の相対配置付きで小さく保存する。
    引数: なし。103で実行したPythonコードと固定資料だけを含める。
    返り値: None。原板・金融Native・既存金融ZIPは複製しない。
    """
    root = Path(__file__).resolve().parents[2]
    study = root / "study/00103_元の多玉と数量を保つ一定利益後の追尾"
    archive = study / "保存と照合のコード.zip"
    manifest = study / "保存と照合のコード.json"
    assert not archive.exists() and not manifest.exists()
    inputs = [
        "work/103多玉の保存集計/集計.py", "work/103多玉の保存集計/人工を確認する.py",
        "work/103多玉の保存集計/metadataと非整数境界を確認する.py", "work/103多玉の保存集計/README.md",
        "work/103多玉の保存集計/停止.json", "work/103多玉の保存集計/人工確認_停止版.json",
        "work/103多玉の保存集計/metadata人工確認_停止版.json", "work/103多玉の保存集計/由来と検算範囲.json",
        "work/103多玉の保存集計/runtime型の接続.json", "work/103保存の実行固定/全54場.json",
        "work/103実行条件の準備/旧95のP0と照合する.py",
        "scripts/FAR連続出生と個別利益追尾/集計.py", "scripts/FAR5分判断と出生一回の監査/集計.py",
        "work/103結果の整理/Viewerの4資源を確認する.py", "work/103結果の整理/S0とLD10の実入口を比べる.py",
        "work/103結果の整理/報告と保存を確かめる.py", "work/103結果の整理/保存と照合のコードを残す.py",
    ]
    fingerprints = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in inputs}
    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED) as out:
        for name in inputs:
            item = zipfile.ZipInfo(name, date_time=(2026, 11, 9, 0, 0, 0))
            item.compress_type = zipfile.ZIP_DEFLATED
            out.writestr(item, (root / name).read_bytes())
    with zipfile.ZipFile(archive) as saved:
        assert saved.namelist() == inputs
        for name, expected in fingerprints.items():
            assert hashlib.sha256(saved.read(name)).hexdigest() == expected
            assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected
    proof = {"成功": True, "scope": "103保存/事後照合のコード17件。金融実行前コードZIPとは別。展開先はrepoルート",
             "ZIP": {"path": archive.name, "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(), "bytes": archive.stat().st_size},
             "相対path_SHA256": fingerprints, "原板複製": 0, "金融再実行": 0, "前後不変": True}
    manifest.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"成功": True, "コード資料数": len(inputs), "ZIPbytes": archive.stat().st_size}, ensure_ascii=False))


if __name__ == "__main__":
    main()
