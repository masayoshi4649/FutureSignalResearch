"""
138の出力用JSONと3点のCSVを標準ライブラリだけで照合する。

金融・入口条件は再計算せず、JSONで与えられた型と値の転記を検査する。
実行時だけ指定JSONと指定CSVを読み、成功時に新規の確認JSONを保存する。
"""

from __future__ import annotations

import argparse
import codecs
import csv
import hashlib
import io
import json
import os
from decimal import Decimal, InvalidOperation
from pathlib import Path
import re
from typing import Any


TABLE_NAMES = ("正逆比較", "入口別診断", "全セッション")
NUMBER_PATTERN = re.compile(r"[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?\Z")
SHA_PATTERN = re.compile(r"[0-9a-f]{64}\Z")


# ----------------------------------------
def require(condition: bool, message: str) -> None:
    """
    機能: 検査条件が満たされない場合に処理を中止する。
    引数: condition(bool)は検査結果、message(str)は失敗の説明。
    返り値: None。失敗時はValueErrorを送出する。
    """
    if not condition:
        raise ValueError(message)


# ----------------------------------------
def absolute_path(value: str | Path) -> Path:
    """
    機能: 指定パスを文字列の正規化で絶対パスへ変換する。
    引数: value(str | Path)は入力パス。
    返り値: Path型の絶対パス。
    """
    return Path(os.path.abspath(os.path.normpath(str(value))))


# ----------------------------------------
def digest(data: bytes) -> str:
    """
    機能: 読み取ったバイト列のSHA256を求める。
    引数: data(bytes)は対象の全バイト列。
    返り値: str型の小文字16進SHA256。
    """
    return hashlib.sha256(data).hexdigest()


# ----------------------------------------
def reject_constant(value: str) -> None:
    """
    機能: JSONの非有限数値を拒否する。
    引数: value(str)はNaN又はInfinity等の定数表現。
    返り値: None。常にValueErrorを送出する。
    """
    raise ValueError(f"JSONの非有限値は使用できない: {value}")


# ----------------------------------------
def decode_tables(data: bytes) -> list[dict[str, Any]]:
    """
    機能: 出力用JSONを数値の十進表現を保って読み、3表の構造を検査する。
    引数: data(bytes)はtables配列を持つJSONのバイト列。
    返り値: list[dict[str, Any]]型の表。行順・列順・型は入力どおり保持する。
    """
    root = json.loads(
        data.decode("utf-8-sig"),
        parse_float=Decimal,
        parse_int=int,
        parse_constant=reject_constant,
    )
    require(isinstance(root, dict), "JSONの最上位はtablesを持つオブジェクトであること")
    tables = root.get("tables")
    require(isinstance(tables, list) and len(tables) == 3, "tablesは3表であること")
    names: list[str] = []
    for table in tables:
        require(isinstance(table, dict), "各tableはオブジェクトであること")
        name = table.get("name")
        require(isinstance(name, str) and name in TABLE_NAMES, f"対象外の表名: {name!r}")
        names.append(name)
        headers = table.get("headers")
        rows = table.get("rows")
        require(isinstance(headers, list) and len(headers) > 0, f"{name}: headersがない")
        require(all(isinstance(value, str) for value in headers), f"{name}: ヘッダは文字列のみ")
        require(len(set(headers)) == len(headers), f"{name}: ヘッダが重複している")
        require(isinstance(rows, list), f"{name}: rowsは配列であること")
        for row_index, row in enumerate(rows, start=1):
            require(isinstance(row, list) and len(row) == len(headers), f"{name}: 第{row_index}行の列数不一致")
            for column_index, value in enumerate(row, start=1):
                valid = value is None or isinstance(value, (str, bool, int, Decimal))
                require(valid, f"{name}: 第{row_index}行第{column_index}列がscalarではない")
                if isinstance(value, Decimal):
                    require(value.is_finite(), f"{name}: 第{row_index}行第{column_index}列が非有限")
    require(set(names) == set(TABLE_NAMES), "3表の名前が重複又は欠落している")
    return tables


# ----------------------------------------
def compare_cell(expected: Any, actual: str, location: str, counts: dict[str, int]) -> None:
    """
    機能: JSONの元の型に従いCSVの1セルを照合し、型別の検査件数を加算する。
    引数: expected(Any)は所与のscalar、actual(str)はCSVセル、location(str)は位置、counts(dict[str, int])は件数。
    返り値: None。不一致時はValueErrorを送出する。数値の許容差は設けない。
    """
    counts["全セル比較数"] += 1
    if expected is None:
        require(actual == "", f"{location}: nullが空欄ではない")
        counts["null比較数"] += 1
        return
    if isinstance(expected, str):
        require(actual == expected, f"{location}: 文字列不一致 {actual!r} != {expected!r}")
        counts["文字列比較数"] += 1
        if expected == "":
            counts["空文字比較数"] += 1
        return
    if isinstance(expected, bool):
        target = "true" if expected else "false"
        require(actual == target, f"{location}: 真偽値不一致 {actual!r} != {target!r}")
        counts["真偽値比較数"] += 1
        return
    require(isinstance(expected, (int, Decimal)), f"{location}: 未対応のJSON型")
    require(bool(NUMBER_PATTERN.fullmatch(actual)), f"{location}: CSVが数値表現ではない {actual!r}")
    try:
        converted = Decimal(actual)
    except InvalidOperation as error:
        raise ValueError(f"{location}: CSVの数値をDecimalへ変換できない") from error
    target_number = Decimal(expected) if isinstance(expected, int) else expected
    require(converted.is_finite() and converted == target_number, f"{location}: 数値不一致 {actual!r} != {str(target_number)!r}")
    counts["数値比較数"] += 1
    if target_number == 0:
        counts["数値零比較数"] += 1


# ----------------------------------------
def inspect_table(table: dict[str, Any], path: Path, data: bytes) -> dict[str, Any]:
    """
    機能: UTF-8 BOM、CSV構造、ヘッダ及び全データセルをJSONの1表へ照合する。
    引数: table(dict[str, Any])は元表、path(Path)はCSV所在、data(bytes)はCSVの読取バイト列。
    返り値: dict[str, Any]型の表別件数とSHA256。CSVを数値型へ自動推測しない。
    """
    name = table["name"]
    require(data.startswith(codecs.BOM_UTF8), f"{name}: UTF-8 BOMがない")
    text = data[len(codecs.BOM_UTF8):].decode("utf-8", errors="strict")
    parsed = list(csv.reader(io.StringIO(text, newline=""), strict=True))
    require(len(parsed) == len(table["rows"]) + 1, f"{name}: ヘッダを含む行数不一致")
    require(parsed[0] == table["headers"], f"{name}: ヘッダ又はその順序が不一致")
    counts = {
        "全セル比較数": 0,
        "数値比較数": 0,
        "数値零比較数": 0,
        "文字列比較数": 0,
        "空文字比較数": 0,
        "真偽値比較数": 0,
        "null比較数": 0,
    }
    for row_index, (expected_row, actual_row) in enumerate(zip(table["rows"], parsed[1:]), start=1):
        require(len(actual_row) == len(table["headers"]), f"{name}: 第{row_index}行の列数不一致")
        for column_index, (expected, actual) in enumerate(zip(expected_row, actual_row), start=1):
            compare_cell(expected, actual, f"{name} 第{row_index}行第{column_index}列", counts)
    return {
        "表名": name,
        "CSV": {"path": str(path), "sha256": digest(data)},
        "行数": len(table["rows"]),
        "列数": len(table["headers"]),
        "ヘッダ比較数": len(table["headers"]),
        "UTF8BOM": True,
        **counts,
    }


# ----------------------------------------
def run(input_path: Path, expected_sha256: str, folder: Path, output_path: Path) -> dict[str, Any]:
    """
    機能: 指定JSONと3CSVを照合し、全入力の前後SHA256同体を確認して新規確認JSONを保存する。
    引数: input_path(Path)はJSON、expected_sha256(str)は期待SHA、folder(Path)はCSV所在、output_path(Path)は未作成の確認先。
    返り値: dict[str, Any]型の成功記録。金融、Native、Raw又は他CSVを追加読取しない。
    """
    input_path = absolute_path(input_path)
    folder = absolute_path(folder)
    output_path = absolute_path(output_path)
    require(bool(SHA_PATTERN.fullmatch(expected_sha256)), "--sha256は小文字64桁であること")
    require(not output_path.exists(), f"確認先が既に存在する: {output_path}")
    require(folder.is_dir(), f"CSVフォルダが存在しない: {folder}")
    input_data = input_path.read_bytes()
    require(digest(input_data) == expected_sha256, "指定JSONのSHA256不一致")
    before = {str(input_path): expected_sha256}
    tables = decode_tables(input_data)
    results: list[dict[str, Any]] = []
    for table in tables:
        csv_path = folder / f"{table['name']}.csv"
        require(csv_path != input_path and csv_path != output_path, "入力又は確認先とCSVの所在が重複している")
        csv_data = csv_path.read_bytes()
        before[str(csv_path)] = digest(csv_data)
        results.append(inspect_table(table, csv_path, csv_data))
    after = {path: digest(Path(path).read_bytes()) for path in before}
    require(before == after, "JSON又はCSVが照合中に変化した")
    result = {
        "試行": 138,
        "成功": True,
        "入力": {"path": str(input_path), "sha256": expected_sha256},
        "表数": len(results),
        "表別": results,
        "全データセル比較数": sum(item["全セル比較数"] for item in results),
        "数値比較数": sum(item["数値比較数"] for item in results),
        "数値零比較数": sum(item["数値零比較数"] for item in results),
        "null比較数": sum(item["null比較数"] for item in results),
        "空文字比較数": sum(item["空文字比較数"] for item in results),
        "入力SHA256": before,
        "後SHA256": after,
        "前後不変": True,
        "数値照合": "Decimalによる値の完全一致。許容差なし。指数表記と末尾零の表記差だけは値同体とする。",
        "文字列照合": "JSONで文字列のセルは先頭零を含め完全一致。数値への自動変換を行わない。",
        "真偽値照合": "JSON booleanに対応するCSVは小文字true又はfalseに完全一致。",
        "空欄の限界": "nullと空文字はCSV上で共に空欄となり、CSV単体では区別不能。入力JSONの型ごとに件数を記録する。数値零を空欄として受理しない。",
        "検査範囲": "指定された3表の転記、行列数、型別全セル、UTF-8 BOM、指定入力の前後SHA256。",
        "非対象": ["金融及び技術条件の再計算", "独立1mini期限評価の片側上限10枚口座への合算", "未約定を損益零へ補完する評価"],
        "金融再計算": False,
        "運用口座への合算": False,
        "Native読取": 0,
        "Raw読取": 0,
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    encoded = (json.dumps(result, ensure_ascii=False, allow_nan=False, indent=2) + "\n").encode("utf-8")
    with output_path.open("xb") as handle:
        handle.write(encoded)
    return result


# ----------------------------------------
def main() -> None:
    """
    機能: 指定された出力用JSONとCSVフォルダを引数から受け取り独立再読を実行する。
    引数: なし。CLIの--input、--sha256、--folder、--outputを使用する。
    返り値: None。成功時は確認先と件数を標準出力へ表示し、不一致時は例外で終了する。
    """
    parser = argparse.ArgumentParser(description="138の3CSVをJSONの型と値へ独立照合する")
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--sha256", required=True)
    parser.add_argument("--folder", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    result = run(args.input, args.sha256, args.folder, args.output)
    print(json.dumps({
        "成功": True,
        "確認": str(absolute_path(args.output)),
        "表数": result["表数"],
        "全データセル比較数": result["全データセル比較数"],
        "数値比較数": result["数値比較数"],
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
