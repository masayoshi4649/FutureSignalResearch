"""コード・条件・入力参照だけを指紋化し、成績によらないfamily棚卸しを固定する。"""
from pathlib import Path
import hashlib
import json

OWN = Path(__file__).resolve().parent
ROOT = OWN.parent.parent
INVENTORY = ROOT / 'work/頻度研究へ使う既存入口streamの所在/棚卸し.json'


# ----------------------------------------
def sha(path: Path) -> str:
    """
    機能: 明示したコード・条件・派生入力のbytes指紋を得る。
    引数: path(Path)。返り値: str。原板やNative本文には使わない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 読取元の前後不変と純出生入力の指紋、転記参照を分けて保存する。
    引数: なし。返り値: None。新Raw/CSV/金融/採番/閾値最適化を行わない。
    """
    relative = [
        'work/頻度研究へ使う既存入口streamの所在/README.md',
        'work/頻度研究へ使う既存入口streamの所在/棚卸し.json',
        'work/118入口比較/入力を準備する.py', 'work/118入口比較/entry.go', 'work/118入口比較/F1.json',
        'work/118複数技法の入口条件/README.md', 'work/118複数技法の入口条件/rules.go',
        'work/118複数技法の入口条件/bank.go',
        'work/118実在庫とSource通知の接続候補/接続口と所有を分ける案.md',
        'scripts/FAR元三手法のmini連続再現/types.go', 'scripts/FAR元三手法のmini連続再現/adapter.go',
        'work/111元時計の連続再現/api.go', 'work/111元時計の連続再現/adapter.go',
        'work/111元時計の連続再現/replay.go',
        'work/126独立出生の事前案/条件_v1.md', 'work/126独立出生の事前案/条件_v2.md',
        'work/126独立出生の事前案/条件_v3.md', 'work/126独立出生の事前案/条件_v4.md',
        'work/126独立出生の事前案/v4/main.go', 'work/126独立出生の事前案/出生v4を渡す.py',
        'work/127独立出生の評価/入力を作る.py', 'work/独立出生の再生器/engine.go',
        'work/128Raw足からの出生/main.go', 'work/128Raw足からの出生/再生入力を作る.py',
        'work/128Raw出生の再生器/engine.go',
        'work/129短期回復の出生/仕様.md', 'work/129短期回復の出生/context.go',
        'work/129短期回復の出生/detector.go', 'work/129短期回復の出生/types.go',
        'work/129短期回復の出生/minute.go', 'work/129短期回復の出生/scanner.go',
        'work/129短期回復の出生/minute_reuse.go',
        'work/129執行区間を限定する評価器/engine.go', 'work/129執行区間を限定する評価器/phase.go',
        'work/137公表時に既知の短期回復を確認する/条件.md',
        'work/137既知回復をSourceへ接続する/接続の条件.md',
    ]
    files = [ROOT / path for path in relative]
    files += [ROOT.parent / 'SessionTradeExecuter/internal/strategy' / name for name in
              ('methods.go', 'selected_source.go', 'selected_day164_policy.go', 'selected_night_policy.go')]
    own_files = [OWN / name for name in ('README.md', 'Sourceの種別だけを抽出する.py',
                                       'Source558の初期と追加.json', '指紋を保存する.py')]
    before = {str(path.relative_to(ROOT) if path.is_relative_to(ROOT) else path): sha(path)
              for path in files + own_files}
    assert sha(OWN / 'Source558の初期と追加.json') == '654476d552a4fd4ac9737219703627eb2ff0b4b5e5e912b2d2521ecca36e34ad'
    source_meta = json.loads((OWN / 'Source558の初期と追加.json').read_text('utf-8'))
    assert source_meta['通知数'] == 558 and source_meta['親episode']['全親数'] == 456
    inventory = json.loads(INVENTORY.read_text('utf-8'))
    births = []
    for row in inventory['純出生入力照合']:
        declared = row['純出生入力']; path = ROOT / declared['path']
        assert path.stat().st_size == declared['bytes'] and sha(path) == declared['sha256']
        births.append({'label': row['label'], **declared, '今回の検査': '圧縮bytesのSHA/size。本文未読'})
    references = [{'label': row['label'], **row['保存資料'], '今回の検査': '既存在庫の参照指紋を転記。金融本文未読'}
                  for row in inventory['保存stream'] if row['label'].startswith(('118 ', '127 ', '128 ', '129 '))]
    assert before == {str(path.relative_to(ROOT) if path.is_relative_to(ROOT) else path): sha(path)
                      for path in files + own_files}
    value = {'成功': True, '段階': '次138の技術family候補整理。採用/採番/金融なし',
             'コードと条件の前後SHA256': before, 'Source558入力': source_meta['入力'],
             'Source558結果': {'初期': 353, '遅延初期': 103, '追加': 102, '不明': 0, '親数': 456,
                             '通知とholdとfillの全件識別同体': 558},
             '純出生入力のbytes検査': births, '保存stream参照の転記': references,
             '公表モデルの指紋_コードと既知由来から': {
                 'CSV122': '6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec',
                 'Raw即時gap300_gzip': 'e382858a62865b321449279d9653f5b1c644c97f6c4254cbae8dd9d3ea065e62',
                 'Raw60秒遅延gap300_gzip': 'ce2add7e0a01fd1ab31c0510194b4647144c01034701f548253c307f6334c830'},
             '127と128のfamilyは同一': True, '提案組合せ数': 2,
             '親はSource側単位であり独立技術setupを保証しない': True,
             'Source70場外の3場を0と断定': False, '前後同体': True,
             '新金融又は先着成績による選択': False, '新RawとCSV本文読取': False,
             '元Native本文読取': False, '追加2場読取': False,
             '実行した自然読取': 'Root許可118入力から識別metadataのみ。出力に価格/損益/outcomeなし',
             '既存Source戦略の版の限界': '隣接リポジトリは今回読取時の指紋。当時Source111全依存の同体再監査は実行していない'}
    target = OWN / '入力と条件の指紋.json'
    target.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '指紋SHA256': sha(target), '条件コード件数': len(before),
                      'Source小型JSON_SHA256': sha(OWN / 'Source558の初期と追加.json')}, ensure_ascii=True))


if __name__ == '__main__':
    main()
