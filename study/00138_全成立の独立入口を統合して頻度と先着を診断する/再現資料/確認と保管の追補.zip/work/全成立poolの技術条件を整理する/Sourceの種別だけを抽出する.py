"""許可された118生成入力から、558通知の識別と初期/追加だけを抽出する。"""
from collections import Counter, defaultdict
from pathlib import Path
import hashlib
import json

OWN = Path(__file__).resolve().parent
ROOT = OWN.parent.parent
SOURCE = ROOT / 'work/118入口比較/入力.json'
EXPECTED = '574771f654937036b48c78eceadb46a4c5ff3c10265f60b0ec7879efb0d862c3'


# ----------------------------------------
def canonical(method: str) -> str:
    """
    機能: 許可された元三手法の名前だけを正規化する。
    引数: method(str)。返り値: str。不明な手法は補完しない。
    """
    method = method if method.startswith('NK225_') else 'NK225_' + method
    assert method in ('NK225_D164_15', 'NK225_P164_06', 'NK225_U165_03')
    return method


# ----------------------------------------
def extract(data: dict) -> dict:
    """
    機能: signalsから識別子・種別・親・数量・fill識別/Stampだけを値copyする。
    引数: data(dict)。返り値: dict。価格・損益・outcome・Native本文を表示/比較しない。
    """
    rows = []; seen = set(); parents = defaultdict(list); checks = Counter()
    for scene in data['scenes']:
        for original in scene['signals']:
            method = canonical(original['method'])
            key = (scene['session'], method, original['id'])
            assert key not in seen; seen.add(key)
            hold, fill = original.get('source_paper_hold'), original.get('source_paper_entry_fill')
            row = {'session': key[0], 'method': method, 'id': original['id'],
                   'source_paper_hold': None, 'source_paper_entry_fill': None}
            if hold is not None:
                row['source_paper_hold'] = {name: hold[name] for name in
                                          ('kind', 'parent', 'source_id', 'entry_id', 'initial_quantity')}
                assert hold['entry_id'] == original['id']; checks['hold_entry_id一致'] += 1
                parents[(scene['session'], method, hold['parent'])].append(row)
            if fill is not None:
                row['source_paper_entry_fill'] = {name: fill[name] for name in
                                                ('signal_id', 'execution_id', 'hold_id', 'time')}
                row['source_paper_entry_fill']['stamp'] = {name: fill['quote'][name] for name in
                                                          ('time', 'index', 'source_line')}
                assert fill['signal_id'] == original['id'] and fill['time'] == fill['quote']['time']
                checks['fill_signal_idとStamp一致'] += 1
                if hold is not None:
                    assert fill['hold_id'] == hold['hold_id']; checks['fill_hold_id一致'] += 1
            rows.append(row)
    assert len(rows) == len(seen) == 558 and len(data['scenes']) == 70
    kinds = Counter(row['source_paper_hold']['kind'] if row['source_paper_hold'] else '不明' for row in rows)
    methods = {method: dict(Counter(row['source_paper_hold']['kind'] if row['source_paper_hold'] else '不明'
                                  for row in rows if row['method'] == method))
               for method in sorted({row['method'] for row in rows})}
    stats = Counter()
    for group in parents.values():
        count = Counter(row['source_paper_hold']['kind'] for row in group)
        initial = count['initial'] + count['delayed_initial']
        stats['全親数'] += 1; stats['初期系あり親数'] += bool(initial)
        stats['追加のみ親数'] += not initial; stats['初期系通知が複数の親数'] += initial > 1
        stats['追加あり親数'] += count['source_add'] > 0
    return {'通知数': 558, '対象場': 70, 'kind別': dict(kinds), '手法別kind': methods,
            '親episode': dict(stats), '全件join検査': dict(checks), '行': rows}


# ----------------------------------------
def main() -> None:
    """
    機能: 許可SHAを照合して非金融metadataを抽出し、元入力不変を確認する。
    引数: なし。返り値: None。原板・CSV・Native・新金融・閾値探索を実行しない。
    """
    raw = SOURCE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == EXPECTED
    extracted = extract(json.loads(raw))
    value = {'成功': True, '入力': {'path': str(SOURCE.relative_to(ROOT)), 'bytes': len(raw), 'sha256': EXPECTED},
             '抽出対象': '許可されたsignalsの識別子・Source hold種別/親・fill識別/Stampのみ',
             **extracted, '価格と損益とoutcomeとNative本文の比較': False, '頻度採用と新金融': False,
             '限界': '親はSource側parentであり、独立した技術setupや研究側実在庫のflat-to-flatを保証しない'}
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == EXPECTED
    target = OWN / 'Source558の初期と追加.json'
    target.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '出力SHA256': hashlib.sha256(target.read_bytes()).hexdigest(),
                      'kind別': extracted['kind別'], '親episode': extracted['親episode']}, ensure_ascii=True))


if __name__ == '__main__':
    main()
