"""138の固定取得をfamily/技術状態/出生時計へ分け、主を変更せず原因を診断する。"""
from collections import Counter, defaultdict
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import math

OWN = Path(__file__).resolve().parent
ROOT = OWN.parent.parent
AGG = ROOT / 'work/138全成立入口と頻度の集計/集計する.py'
AGG_SHA = 'e8671638600dc4b23ef9256ba5be535f20c6f8e1d5097457a56fbea9fb30c1f1'
REFS = {
    'manifest': ('work/全成立poolの非金融manifest/manifest.json', 'e7ba444fd66f9ca52e10e929eeb31d21076f97afa161de738dabca14a8ff8e35'),
    'fixed': ('work/138全成立入口の評価/固定入力_版2/固定取得入力.json', '0c83e525dec3079ce188d942069c0d137c94f39009339752ec8227ec9ecb4ce7'),
    'metadata': ('work/138全成立入口の評価/固定入力_版2/入口参照.json', '75e4993571bdef17839aad3324acc6ee9ce09b3cb1f4ecad70637a1e01ccefd0'),
    'queries': ('work/138全成立入口の評価/固定入力_版2/特徴照会.json', '81442c3ebaa3065213d0844417bb0462cfa3e5d0a05c4f44edfb3fb14191e75c'),
    'features': ('work/138全成立入口の評価/全出生の当時特徴.json', 'c2b9b8efeb65ba22b2dac3147fdefa3b513cb5cc61cd69249864065f2fcca6e4'),
}


# ----------------------------------------
def sha(path: Path) -> str:
    """
    機能: 明示ファイルのbytes指紋を得る。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def load_aggregator() -> object:
    """
    機能: 固定138の向き選択/phase検査と私有124算術だけを再用する。
    引数: なし。返り値: object。mainや旧金融ファイル読取は呼ばない。
    """
    assert sha(AGG) == AGG_SHA
    spec = importlib.util.spec_from_file_location('138原因用の固定集計', AGG)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module


# ----------------------------------------
def read_nonfinancial() -> dict:
    """
    機能: 固定manifest/取得metadata/出生特徴だけを認証して読む。
    引数: なし。返り値: dict。先着や損益結果は含めない。
    """
    docs = {}
    for name, (relative, expected) in REFS.items():
        path = ROOT / relative; assert sha(path) == expected
        docs[name] = json.loads(path.read_text('utf-8'))
    assert docs['manifest']['financial_labels_used'] is False
    assert docs['features']['financial_labels_used'] is False and docs['features']['entry_prices_used'] is False
    return docs


# ----------------------------------------
def origins_for(candidate: dict, model: str, relations: dict, features: dict) -> list[dict]:
    """
    機能: canonicalの全originを自身の出生特徴へ結合する。
    引数: candidate(dict)、model(str)、relations/features(dict)。返り値: list[dict]。
    """
    out = []
    for i, origin in enumerate(candidate['origins']):
        relation = relations[(model + '/' + candidate['id'], i)]
        feature = features[relation['query_id']]
        assert relation['side'] == origin['side'] == candidate['side'] == feature['query']['side']
        assert all(feature['query']['birthQuote'][k] == origin['birthQuote'][k] for k in ('time', 'index', 'source_line', 'last'))
        out.append({'origin': origin, 'feature': feature})
    return out


# ----------------------------------------
def distribution(values: list[float]) -> dict:
    """
    機能: 件数と線形補間分位を計算する。
    引数: values(list[float])。返り値: dict。空集合はnull。
    """
    xs = sorted(values)
    def quantile(p: float) -> float | None:
        """機能: 分位値を求める。引数: p(float)。返り値: float|None。"""
        if not xs: return None
        at = (len(xs) - 1) * p; i = int(at); f = at - i
        return xs[i] + f * (xs[min(i + 1, len(xs) - 1)] - xs[i])
    return {'件数': len(xs), '最小': min(xs) if xs else None, '中央値': quantile(.5),
            'p95': quantile(.95), '最大': max(xs) if xs else None,
            '平均': sum(xs) / len(xs) if xs else None}


# ----------------------------------------
def lag(candidate: dict, attachments: list[dict]) -> dict:
    """
    機能: originごとの出生待機と当初参照の時計を測る。
    引数: candidate(dict)、attachments(list[dict])。返り値: dict。単一の出生を捏造しない。
    """
    rows = []
    for item in attachments:
        origin, feature = item['origin'], item['feature']; delta = candidate['entryQuote']['time'] - origin['birthQuote']['time']
        assert delta >= 0
        feet = {}
        for minute in (5, 15, 30):
            foot = feature['feet']['m%d' % minute]
            feet[str(minute)] = None if foot is None else {
                '取得時の当初foot_End年齢秒': candidate['entryQuote']['time'] - foot['end'],
                '取得時の当初foot_配送年齢秒': candidate['entryQuote']['time'] - foot['delivered']['time'],
                '当初footのfresh期限を跨ぐ': candidate['entryQuote']['time'] >= foot['end'] + minute * 60 + 60}
        position = origin.get('position_origin') or {}
        rows.append({'family': origin['family'], 'query_id': feature['query']['id'], '出生から取得秒': delta,
                     'Source種別': position.get('initial_or_add', '対象外'), '当初参照': feet})
    return {'canonical_id': candidate['id'], 'session': candidate['session'], 'baseline': candidate['baseline'],
            'origin数': len(rows), '最短出生待機秒': min(r['出生から取得秒'] for r in rows),
            '最長出生待機秒': max(r['出生から取得秒'] for r in rows), 'origins': rows}


# ----------------------------------------
def lag_summary(rows: list[dict]) -> dict:
    """
    機能: canonical最短/最長とfamily別origin分布を混同せずまとめる。
    引数: rows(list[dict])。返り値: dict。分布は金融を使わない。
    """
    flat = [o for r in rows for o in r['origins']]; families = {}
    for family in sorted({o['family'] for o in flat}):
        selected = [o for o in flat if o['family'] == family]
        families[family] = {'origin別出生取得遅延': distribution([o['出生から取得秒'] for o in selected]),
                            'Source種別': dict(Counter(o['Source種別'] for o in selected)),
                            '当初refの時計': {str(m): {'refあり': sum(o['当初参照'][str(m)] is not None for o in selected),
                                '取得前にfresh失効': sum(o['当初参照'][str(m)] is not None and o['当初参照'][str(m)]['当初footのfresh期限を跨ぐ'] for o in selected)} for m in (5, 15, 30)}}
    return {'canonical数': len(rows), 'origin数': len(flat), '単一出生は選ばない': True,
            'canonical最短出生待機秒': distribution([r['最短出生待機秒'] for r in rows]),
            'canonical最長出生待機秒': distribution([r['最長出生待機秒'] for r in rows]), 'family別origin': families,
            '限界': '出生前のSource政策待機と、取得時までの新公表は未再生。当初ref失効は最新背景の未知を意味しない'}


# ----------------------------------------
def value(feature: dict, name: str) -> float | None:
    """
    機能: known値だけを取得する。
    引数: feature(dict)、name(str)。返り値: float|None。
    """
    v = feature['values'].get(name, {'known': False, 'value': None})
    return v['value'] if v['known'] else None


# ----------------------------------------
def tri_and(values: list[bool | None]) -> bool | None:
    """
    機能: 既知否定を優先する三値AND。
    引数: values(list[bool|None])。返り値: bool|None。
    """
    return False if False in values else None if None in values else True


# ----------------------------------------
def feature_states(feature: dict, catalog: dict) -> dict:
    """
    機能: 固定した符号/旧境界/複合状態で出生特徴を記述する。
    引数: feature/catalog(dict)。返り値: dict[str,str]。勝敗で境界を動かさない。
    """
    out = {}
    def test(name: str, predicate: object) -> bool | None:
        """機能: 未知を保持して述語を適用。引数: name(str)、predicate(callable)。返り値: bool|None。"""
        v = value(feature, name); return predicate(v) if v is not None else None
    def sign(names: list[str]) -> str:
        """機能: 全同方向と混在/未知を区別。引数: names(list[str])。返り値: str。"""
        vs = [value(feature, n) for n in names]
        return '未知' if None in vs else '全同向' if all(v > 0 for v in vs) else '全逆向' if all(v < 0 for v in vs) else '混在又は0'
    ma = ['m%d_%s_to_side' % (m, n) for m in (5, 15, 30) for n in ('gap', 'ema8_delta', 'ema21_delta')]
    out['三軸MA9値'] = sign(ma)
    out['15と30分背景4値'] = sign(['m%d_%s_to_side' % (m, n) for m in (15, 30) for n in ('gap', 'ema21_delta')])
    for role in sorted({d['role'] for d in catalog.values()}):
        vs = [feature['values'][n]['known'] for n, d in catalog.items() if d['role'] == role]
        out['役割既知/' + role] = '全既知' if all(vs) else '全未知' if not any(vs) else '一部未知'
    specifications = {
        'Hist5増分': ('m5_hist_delta_to_side', lambda v: '改善' if v > 0 else '失速' if v < 0 else '0'),
        'RSI5変化': ('m5_rsi_delta_to_side', lambda v: '10超スパイク' if abs(v) > 10 else '10以内'),
        'ADX15': ('m15_adx', lambda v: '20以上' if v >= 20 else '20未満'),
        'TR前ATR5比': ('m5_tr_previous_atr_ratio', lambda v: '2超' if v > 2 else '2以内'),
        'RVOL5': ('rvol5', lambda v: '.5未満' if v < .5 else '.5以上1未満' if v < 1 else '1以上1.5以下' if v <= 1.5 else '1.5超'),
        'EMA21位置5': ('m5_price_ema21_atr_to_side', lambda v: '順側1ATR以上' if v >= 1 else '逆側1ATR以下' if v <= -1 else '間'),
        'BB15位置': ('bb15_position_sigma_to_side', lambda v: '順側2σ以上' if v >= 2 else '逆側2σ以下' if v <= -2 else '帯内'),
        '5分実体': ('m5_body_ratio_to_side', lambda v: '方向実体' if v > 0 else '反対実体' if v < 0 else '0'),
    }
    for name, (field, function) in specifications.items():
        v = value(feature, field); out[name] = '未知' if v is None else function(v)
    trend = tri_and([test(n, lambda v: v > 0) for n in ma] + [test('m15_adx', lambda v: v >= 20),
        test('m5_hist_to_side', lambda v: v > 0), test('m5_rsi_center_to_side', lambda v: v >= 0),
        test('rvol5', lambda v: v >= .5), test('m5_tr_previous_atr_ratio', lambda v: v <= 2)])
    weak_parts = [test('m15_adx', lambda v: v <= 20), test('m30_adx_delta', lambda v: v < 0)]
    weak = True if True in weak_parts else None if None in weak_parts else False
    reversal = tri_and([weak, test('m5_body_ratio_to_side', lambda v: v > 0), test('m5_hist_delta_to_side', lambda v: v > 0),
        test('m5_rsi_delta_to_side', lambda v: v > 0), test('rvol5', lambda v: v >= 1), test('m5_tr_previous_atr_ratio', lambda v: v <= 2)])
    out['複合/順行整合'] = '未知' if trend is None else '成立' if trend else '不成立'
    out['複合/弱化と実体勢い量'] = '未知' if reversal is None else '成立' if reversal else '不成立'
    return out


# ----------------------------------------
def combined_states(attachments: list[dict], catalog: dict) -> dict:
    """
    機能: 複数originの不一致を保持し一つを都合よく選ばない。
    引数: attachments(list[dict])、catalog(dict)。返り値: dict[str,str]。
    """
    states = [feature_states(item['feature'], catalog) for item in attachments]
    return {name: states[0][name] if len({s[name] for s in states}) == 1 else 'origin間不一致' for name in states[0]}


# ----------------------------------------
def measures(rows: list[dict], module: object, control: bool = False) -> dict:
    """
    機能: 固定H60±125のnativeと実逆を別streamで集計する。
    引数: rows(list[dict])、module(object)、control(bool)。返り値: dict。
    """
    return {name: module.stats(rows, policy, 'BBO', 3600, 125) for name, policy in
            ([('native', 'C0')] if control else [('native', 'P0'), ('実逆', 'R0')])}


# ----------------------------------------
def diagnose(rows: list[dict], sessions: list[str], module: object, catalog: dict) -> dict:
    """
    機能: 全体とbaseline/追加、family、技術状態を非排他性を保って診断する。
    引数: rows/sessions(list)、module(object)、catalog(dict)。返り値: dict。
    """
    pool = [r for r in rows if r['model'] == 'P0']; controls = [r for r in rows if r['model'] == 'C0']
    assert len({r['case']['id'] for r in pool}) == len(pool)
    all_family = sorted({o['origin']['family'] for r in pool for o in r['attachments']})
    output = {'全体': [], 'family別': [], '技術状態別_追加のみ': []}
    for part, ids in (('全体', sessions), ('前48', sessions[:48]), ('後25', sessions[48:])):
        part_rows = [r for r in pool if r['session'] in ids]
        for subset, subset_rows in (('全P0', part_rows), ('baseline', [r for r in part_rows if r['canonical']['baseline']]),
                                    ('追加', [r for r in part_rows if not r['canonical']['baseline']])):
            for side, side_rows in (('両側', subset_rows), ('買', [r for r in subset_rows if r['case']['original_side'] == 1]),
                                    ('売', [r for r in subset_rows if r['case']['original_side'] == -1])):
                output['全体'].append({'区分': part, '集合': subset, '側': side, '数値': measures(side_rows, module)})
                for family in all_family:
                    family_rows = [r for r in side_rows if family in {o['origin']['family'] for o in r['attachments']}]
                    output['family別'].append({'区分': part, '集合': subset, '側': side, 'family': family, '数値': measures(family_rows, module)})
        extra = [r for r in part_rows if not r['canonical']['baseline']]
        groups = defaultdict(list)
        for r in extra:
            for name, state in combined_states(r['attachments'], catalog).items(): groups[name, state].append(r)
        for (name, state), group in sorted(groups.items()):
            output['技術状態別_追加のみ'].append({'区分': part, '状態名': name, '状態': state, '数値': measures(group, module)})
    alias = [{'id': r['case']['id'], 'session': r['session'], 'baseline': r['canonical']['baseline'],
              'origin数': len(r['attachments']), 'families': sorted({o['origin']['family'] for o in r['attachments']})}
             for r in pool if len(r['attachments']) > 1]
    output['重複alias'] = {'canonical取得数': len(pool), 'origin総数': sum(len(r['attachments']) for r in pool),
                       '追加alias数': sum(len(r['attachments']) - 1 for r in pool), '複数origin群': alias,
                       'family別は重なりがあり合計不可': True}
    output['C0固定対照'] = measures(controls, module, True)
    return output


# ----------------------------------------
def main() -> None:
    """
    機能: 非金融遅延を準備し、Root F1/結果指紋指定後だけ金融を結合する。
    引数: CLI --mode/--f1/--f1-sha256/--result/--result-sha256。返り値: None。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', required=True, choices=('prepare', 'evaluate'))
    for name in ('f1', 'result'):
        parser.add_argument('--' + name, type=Path); parser.add_argument('--' + name + '-sha256')
    args = parser.parse_args()
    if args.mode == 'evaluate':
        assert args.f1 and args.result and args.f1_sha256 and args.result_sha256
        assert sha(args.f1) == args.f1_sha256
        f1 = json.loads(args.f1.read_text('utf-8')); declared = {Path(p).resolve(): h for p, h in f1['ファイル'].items()}
        assert declared[AGG.resolve()] == AGG_SHA and sha(args.result) == args.result_sha256
        for name in ('manifest', 'fixed', 'metadata'):
            relative, h = REFS[name]; assert declared[(ROOT / relative).resolve()] == h
    own_before = {n: sha(OWN / n) for n in ('条件.md', '診断する.py', '人工検査.py')}
    documents = read_nonfinancial(); query = documents['queries']; features = documents['features']
    relation = {(r['entry_id'], r['origin_index']): r for r in query['relations']}
    fmap = {r['query']['id']: r for r in features['rows']}
    candidates = documents['manifest']['P0']; assert len(candidates) == 752
    attachments = {c['id']: origins_for(c, 'P0', relation, fmap) for c in candidates}
    lag_rows = [lag(c, attachments[c['id']]) for c in candidates]
    waits = {'成功': True, '金融使用': False, '集合': 'P0全752 canonical、originは別分布',
             '要約': lag_summary(lag_rows), '候補別': lag_rows}
    wait_path = OWN / '出生待機と参照時計.json'
    wait_path.write_text(json.dumps(waits, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    if args.mode == 'prepare':
        print(json.dumps({'成功': True, '金融未読': True, '遅延SHA256': sha(wait_path)}, ensure_ascii=False)); return
    aggregate = load_aggregator(); module = aggregate.load_arithmetic()
    result = json.loads(args.result.read_text('utf-8'))
    rows, sessions, phase = aggregate.prepare(result, documents['fixed'], documents['metadata'], documents['manifest'])
    for r in rows:
        r['attachments'] = origins_for(r['canonical'], r['model'], relation, fmap)
    value = diagnose(rows, sessions, module, features['catalog'])
    assert sum(r['canonical']['baseline'] for r in rows if r['model'] == 'P0') == 81
    assert value['重複alias']['追加alias数'] == 17
    summary_path = ROOT / 'work/138全成立入口と頻度の集計/集計.json'
    assert sha(summary_path) == '6ef283db667603884b42260affce732ba5c9b31731d24b1bb18f9e96ee4b3486'
    summary = json.loads(summary_path.read_text('utf-8'))
    whole = next(r for r in value['全体'] if (r['区分'], r['集合'], r['側']) == ('全体', '全P0', '両側'))['数値']
    assert whole['native'] == summary['集計']['all']['P0']['BBO']['3600']['125']
    assert whole['実逆'] == summary['集計']['all']['R0']['BBO']['3600']['125']
    assert value['C0固定対照']['native'] == summary['集計']['all']['C0']['BBO']['3600']['125']
    assert own_before == {n: sha(OWN / n) for n in own_before}
    assert all(sha(ROOT / p) == h for p, h in REFS.values()) and sha(args.result) == args.result_sha256
    value.update({'成功': True, '試行': 138, 'F1_SHA256': args.f1_sha256, '結果SHA256': args.result_sha256,
                  '診断コードSHA256': own_before, '遅延SHA256': sha(wait_path), 'phase再検査': phase,
                  '主の交換': False, '新Raw_CSV読取': False, '追加2場読取': False,
                  '解釈': '既使用73場の事後原因記述。特徴はCSV overlay、family群は重なる。139へ仮説を送るが138の主は変更しない'})
    target = OWN / '原因診断.json'
    target.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '原因診断SHA256': sha(target), '遅延SHA256': sha(wait_path), '全体': whole}, ensure_ascii=False))


if __name__ == '__main__':
    main()
