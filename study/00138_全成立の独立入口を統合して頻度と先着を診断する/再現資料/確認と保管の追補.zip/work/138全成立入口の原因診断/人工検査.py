"""自然金融を開かず138原因診断のalias/向き/費用/未知/時計を人工確認する。"""
from pathlib import Path
import copy
import importlib.util
import subprocess
import sys
import unittest

OWN = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('138原因人工', OWN / '診断する.py')
D = importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(D)


# ----------------------------------------
def stream(side: int, direction: int, status: str = 'complete') -> dict:
    """
    機能: 実BBO側が独立に±125へ届く人工観測を作る。
    引数: side/direction(int)、status(str)。返り値: dict。
    """
    entry = {'bid': 1000, 'ask': 1010, 'last': 1005}
    price = entry['ask'] if side == 1 else entry['bid']
    mark = price + side * direction * 125
    point = {'bid': mark if side == 1 else mark - 10, 'ask': mark + 10 if side == 1 else mark, 'last': mark}
    return {'birth': {'side': side}, 'entry_price': price, 'entry': entry,
            'outcomes': [{'seconds': 3600, 'status': status, 'touches': [{'width': 125, 'direction': direction, 'quote': point if direction else None}],
                          'endpoint': point if status == 'complete' else None}]}


# ----------------------------------------
def feature(known: bool = False, sign: int = 1) -> dict:
    """
    機能: 全9MA等の人工特徴を作り、未知と既知否定を分ける。
    引数: known(bool)、sign(int)。返り値: dict。
    """
    values = {'m%d_%s_to_side' % (m, n): sign for m in (5, 15, 30) for n in ('gap', 'ema8_delta', 'ema21_delta')}
    values.update({'m15_adx': 25, 'm30_adx_delta': -1, 'm5_hist_to_side': 1, 'm5_hist_delta_to_side': 1,
                   'm5_rsi_center_to_side': 5, 'm5_rsi_delta_to_side': 1, 'm5_body_ratio_to_side': .5,
                   'm5_tr_previous_atr_ratio': 1, 'rvol5': 1})
    return {'values': {k: {'known': known, 'value': v if known else None} for k, v in values.items()}}


# ----------------------------------------
def record(identity: str, side: int, baseline: bool, families: list[str], direction: int, status: str = 'complete') -> dict:
    """
    機能: 一つのcanonicalに複数aliasを持つ人工行を作る。
    引数: identity(str)、side/direction(int)、baseline(bool)、families(list[str])、status(str)。返り値: dict。
    """
    return {'session': '場0', 'model': 'P0', 'canonical': {'baseline': baseline},
            'meta': {'source_side': -side}, 'case': {'id': identity, 'original_side': side,
                'original': stream(side, direction, status), 'reverse': stream(-side, -1 if direction else 0, status)},
            'attachments': [{'origin': {'family': family}, 'feature': feature()} for family in families]}


# ----------------------------------------
class Tests(unittest.TestCase):
    """人工だけで原因分類の集計契約を検査する。"""

    def setUp(self) -> None:
        """機能: 私有算術と人工3例を用意。引数: self(Tests)。返り値: None。"""
        self.module = D.load_aggregator().load_arithmetic()
        self.rows = [record('一', 1, True, ['甲'], 1), record('二', -1, False, ['甲', '乙'], -1),
                     record('三', 1, False, ['丙'], 0, 'gap_censored')]
        control = copy.deepcopy(self.rows[0]); control['model'] = 'C0'; self.rows.append(control)
        self.catalog = {'rvol5': {'role': '量'}}

    def test_aliasを全体で水増ししない(self) -> None:
        """機能: 全体3例とalias4、family非排他を区別。引数: self(Tests)。返り値: None。"""
        output = D.diagnose(self.rows, ['場0'], self.module, self.catalog)
        self.assertEqual(output['重複alias']['canonical取得数'], 3)
        self.assertEqual(output['重複alias']['origin総数'], 4)
        self.assertEqual(output['重複alias']['追加alias数'], 1)
        whole = next(x for x in output['全体'] if (x['区分'], x['集合'], x['側']) == ('全体', '全P0', '両側'))
        self.assertEqual(whole['数値']['native']['entries'], 3)
        family = [x for x in output['family別'] if (x['区分'], x['集合'], x['側']) == ('全体', '全P0', '両側')]
        self.assertEqual(sum(x['数値']['native']['entries'] for x in family), 4)

    def test_nativeと実逆は補数でなく費用を保持(self) -> None:
        """機能: 両側損失とIFD未知、77+1000費用を確認。引数: self(Tests)。返り値: None。"""
        metrics = D.measures(self.rows[:3], self.module)
        self.assertEqual((metrics['native']['forward'], metrics['native']['adverse'], metrics['native']['censored']), (1, 1, 1))
        self.assertEqual(metrics['実逆']['resolved_rate'], 0)
        self.assertNotEqual(metrics['実逆']['resolved_rate'], 1 - metrics['native']['resolved_rate'])
        self.assertEqual((metrics['native']['ifd_known'], metrics['native']['ifd_unknown']), (2, 1))
        self.assertEqual((metrics['native']['ifd_net5_profit'], metrics['native']['ifd_net5_loss']), (11423, 13577))
        control = D.measures([self.rows[3]], self.module, True)
        self.assertEqual(control['native']['forward'], 1)  # metaのSource逆向きで再反転しない。

    def test_全未知を0支持にせず複合状態を分離(self) -> None:
        """機能: 三値ANDと複数技法を確認。引数: self(Tests)。返り値: None。"""
        unknown = D.feature_states(feature(), self.catalog)
        self.assertEqual(unknown['複合/順行整合'], '未知')
        self.assertEqual(D.feature_states(feature(True), self.catalog)['複合/順行整合'], '成立')
        self.assertEqual(D.feature_states(feature(True, -1), self.catalog)['複合/順行整合'], '不成立')
        self.assertIs(D.tri_and([None, False]), False)
        self.assertIsNone(D.tri_and([None, True]))

    def test_origin不一致で都合の良いものを選ばない(self) -> None:
        """機能: 同じ取得の異なる出生特徴を保持。引数: self(Tests)。返り値: None。"""
        row = copy.deepcopy(self.rows[1]); row['attachments'][0]['feature'] = feature(True)
        state = D.combined_states(row['attachments'], self.catalog)
        self.assertEqual(state['三軸MA9値'], 'origin間不一致')

    def test_遅延はoriginごとに当初refの失効と分離(self) -> None:
        """機能: 最短20秒/最長300秒を単一出生へしない。引数: self(Tests)。返り値: None。"""
        attachments = []
        for birth, end in ((100, 0), (380, 300)):
            attachments.append({'origin': {'family': '人工', 'birthQuote': {'time': birth}},
                'feature': {'query': {'id': str(birth)}, 'feet': {'m5': {'end': end, 'delivered': {'time': end + 65}}, 'm15': None, 'm30': None}}})
        row = D.lag({'id': '同取得', 'session': '場0', 'baseline': False, 'entryQuote': {'time': 400}}, attachments)
        self.assertEqual((row['最短出生待機秒'], row['最長出生待機秒']), (20, 300))
        self.assertTrue(row['origins'][0]['当初参照']['5']['当初footのfresh期限を跨ぐ'])
        self.assertFalse(row['origins'][1]['当初参照']['5']['当初footのfresh期限を跨ぐ'])
        self.assertEqual(D.lag_summary([row])['canonical数'], 1)

    def test_F1指定なしで自然金融を開かない(self) -> None:
        """機能: evaluateが結果読取前に停止することを確認。引数: self(Tests)。返り値: None。"""
        result = subprocess.run([sys.executable, '-X', 'utf8', str(OWN / '診断する.py'), '--mode', 'evaluate'], capture_output=True)
        self.assertNotEqual(result.returncode, 0)


if __name__ == '__main__':
    unittest.main(verbosity=2)
