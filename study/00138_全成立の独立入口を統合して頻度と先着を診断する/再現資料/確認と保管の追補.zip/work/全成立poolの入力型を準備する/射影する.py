"""保存済み取得のmetadataだけを共通型へ射影する。poolの選択・金融は実装しない。"""
import copy
import gzip
import hashlib
import json
import math
from collections import Counter
from pathlib import Path
from typing import TypedDict

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
INVENTORY=ROOT/'work/頻度研究へ使う既存入口streamの所在/棚卸し.json'
COMMON=ROOT/'inputs/00124_同入口正逆の共用入力/入力.json.gz'
COMMON_SHA='b2368b1f42c16e8c96a3acd098c58a902807a3b6a5023d6d4b1e75261f3ee51b'
BASELINE=ROOT/'work/137既知回復の評価/固定入力/方向と出生.json'
BASELINE_SHA='86f33705ba40fd3ba1b845557a2368e44c2802635082fc3bad69346770103f93'
VARIANTS={
 '118 Source558':('far_m0','FAR保存通知・M0市場取得代用',558,None),
 '127 CSV公表 Q/R/S/T':('v4_csv','CSV_End+60',164,'technical_v4_publication'),
 '128 Raw即時 Q/R/S/T':('v4_raw_immediate','Raw価格時計_gap300_即時',264,'technical_v4_publication'),
 '128 Raw60秒遅延 Q/R/S/T':('v4_raw_delay60','Raw価格時計_gap300_60秒保留',168,'technical_v4_publication'),
 '129 新C1/C2/C3':('short_129','Raw価格時計_gap300_即時',42,None),
}


class Candidate(TypedDict):
    """価格時刻・物理行・由来を保存し、採否を未決定のまま保持する型。"""
    family: str
    variant: str
    source_file_sha: str
    source_locator: dict
    session: str
    contract: str|None
    id: str
    side: int
    birthQuote: dict
    entryQuote: dict
    publication_model: str
    original_execution: str
    position_origin: dict
    raw_ref: dict
    availability: dict


def sha(body: bytes) -> str:
    """
    機能: 入力bytesのSHA256を求める。
    引数: body(bytes)は保存ファイル又は解凍内容。
    返り値: strは指紋。
    """
    return hashlib.sha256(body).hexdigest()


def metadata_hook(pairs: list[tuple]) -> dict:
    """
    機能: 観測成績を除去し、outcomesの存在/件数/キーだけを残す。
    引数: pairs(list[tuple])はJSONオブジェクト。
    返り値: dictはtouch方向・到達価格・金額を使えないmetadata。
    """
    d=dict(pairs)
    if 'outcomes' in d:
        rows=d['outcomes']
        d['outcomes']={'present':True,'record_count':len(rows),'record_keys':sorted(set().union(*(set(r) for r in rows))) if rows else []}
    for k in ('touches','endpoint','points','net0','net5'):d.pop(k,None)
    return d


def load(path: Path,expected: str|None=None,decoded_expected: str|None=None) -> tuple[dict,dict]:
    """
    機能: 明示した小型保存JSONだけを読み、metadataへ縮約する。
    引数: path(Path)、expected/decoded_expected(str|None)は場所と期待SHA。
    返り値: tuple[dict,dict]は縮約内容と由来。原板/CSVは対象外。
    """
    assert path.suffix in ('.json','.gz') and path.stat().st_size<10_000_000
    raw=path.read_bytes();decoded=gzip.decompress(raw) if path.suffix=='.gz' else raw
    assert expected is None or sha(raw)==expected
    assert decoded_expected is None or sha(decoded)==decoded_expected
    assert len(decoded)<25_000_000
    return json.loads(decoded,object_pairs_hook=metadata_hook),{'path':path.relative_to(ROOT).as_posix(),'sha256':sha(raw),'decoded_sha256':sha(decoded),'bytes':len(raw)}


def stamp(q: dict) -> tuple:
    """
    機能: 時刻/index/物理行を失わず検査する。
    引数: q(dict)は元のQuote又はStamp。
    返り値: tupleは価格時刻と元の採用/物理順。
    """
    values=q['time'],q['index'],q.get('source_line',q.get('line'))
    assert all(type(v) in (int,float) and math.isfinite(v) for v in values)
    return values


def quote_copy(q: dict) -> dict:
    """
    機能: 元Quoteに保存された価格と原行だけを値copyする。
    引数: q(dict)は保存Quote。
    返り値: dictは欠けたフィールドを補完しないQuote。
    """
    stamp(q)
    return {k:copy.deepcopy(q[k]) for k in ('clock','time','index','source_line','line','last','bid','ask','quote_ok') if k in q}


def available(meta: dict,scene: dict,birth: dict,entry: dict,raw: dict) -> dict:
    """
    機能: 現行phase/原板/品質との差を除外せず候補へ注記する。
    引数: meta/scene/birth/entry/raw(dict)は共用場・元場・時計・原板参照。
    返り値: dictは採否未決定の可用性情報。
    """
    limit=min(meta['force_close'],meta['end']-3900)
    return {'raw_sha_matches_common':raw.get('sha256')==meta['raw']['sha256'],
        'raw_path_matches_common':raw.get('path')==meta['raw']['path'],
        'quality_matches_common':scene.get('quality')==meta['expected_quality'] if 'quality' in scene else None,
        'stat_before_after_equal':scene['stat_before']==scene['stat_after'] if 'stat_before' in scene and 'stat_after' in scene else None,
        'continuous_end':meta['end']-300,'current_H60_entry_limit':limit,
        'birth_before_current_H60_limit':birth['time']<limit,'entry_before_current_H60_limit':entry['time']<limit,
        'entry_before_continuous_end':entry['time']<meta['end']-300,
        'original_execution_end':scene.get('execution_end'),'original_entry_limit':scene.get('effective_force_close'),
        'phase_or_eligibility_replayed':False,'raw_row_index_equivalence_reproved':False}


def project(label: str,data: dict,source: dict,common: dict) -> tuple[list[Candidate],dict]:
    """
    機能: 指定保存版の全取得を1つのvariant内で共通候補へ写す。
    引数: label(str)、data/source/common(dict)は保存結果・由来・共用73場。
    返り値: tupleは候補と件数監査。公表variantを混ぜてpoolへ採用しない。
    """
    variant,model,expected,exclusive=VARIANTS[label];rows=[];schema=Counter();case_count=0;outcome_shapes=Counter()
    for si,scene in enumerate(data['scenes']):
        sid=scene['session'];meta=common[sid];key='candidates' if variant=='far_m0' else 'births'
        cases={c['id']:c for c in scene.get('cases',[])}
        for ci,c in enumerate(scene[key]):
            if c.get('entry') is None or variant=='far_m0' and c.get('policy')!='M0':continue
            assert c['status']=='filled';entry=quote_copy(c['entry'])
            if variant=='far_m0':
                b=c['birth'];birth=quote_copy(b['quote']);family='FAR/'+b['method'];birth_source='birth.quote'
                position={'known':False,'initial_or_add':None,'reason':'118保存Signalに初期/追加・元枚数なし。ID/1枚から推定しない',
                          'method':b['method'],'accepted_s0':b['accepted_s0'],'filled_s0':b['filled_s0'],'research_quantity':data.get('candidate_quantity')}
                observation=c.get('outcomes');assert observation and observation['present'];outcome_shapes[str(observation)]+=1
            else:
                b=c['event'];at=b['at'];request=c.get('request')
                assert request is not None and stamp(request)==stamp(at),'出生Quoteを取得Quoteで代用しない'
                birth=quote_copy(request);birth_source='request_same_stamp_as_event.at'
                family=('技術v4/' if variant.startswith('v4_') else '短期回復129/')+b['mode']
                position={'known':True,'initial_or_add':'対象外','reason':'Source保有を再現しない独立候補','research_quantity':data.get('candidate_quantity')}
                assert b['id'] in cases;case_count+=1
                for axis in ('original','reverse','chart_original','chart_reverse'):
                    shape=cases[b['id']][axis].get('outcomes');assert shape and shape['present'];outcome_shapes[str(shape)]+=1
            assert type(b['side']) is int and b['side'] in (-1,1) and stamp(birth)[0]<=stamp(entry)[0]
            raw=copy.deepcopy(scene['raw']);assert scene['actual_sha256']==raw['sha256']
            availability=available(meta,scene,birth,entry,raw)
            contract=meta['contract'] if availability['raw_sha_matches_common'] else None
            record={'family':family,'variant':variant,'exclusive_variant_group':exclusive,'source_file_sha':source['sha256'],
                'source_locator':{'file':source['path'],'scene_index':si,'candidate_key':key,'candidate_index':ci},
                'session':sid,'contract':contract,'contract_basis':'共用124の同sessionかつ同原板SHA' if contract else '原板差のため未確定',
                'id':b['id'],'side':b['side'],'birthQuote':birth,'birth_quote_source':birth_source,'entryQuote':entry,
                'publication_model':model,'original_execution':'118 M0の元方向市場取得代用' if variant=='far_m0' else '元保存版の次原行1秒後・正常BBO/cap/hold/risk取得',
                'position_origin':position,'raw_ref':raw,'availability':availability,'role':'追加候補・採否未決定'}
            rows.append(record);schema.update(c.keys())
    assert len(rows)==expected
    assert len({(r['session'],r['id']) for r in rows})==len(rows)
    observed={s['session'] for s in data['scenes']};missing=[s for s in common if s not in observed]
    stamps={(r['session'],stamp(r['entryQuote'])) for r in rows}
    return rows,{'variant':variant,'label':label,'source':source,'candidate_count':len(rows),'source_sessions':len(observed),
        'filled_sessions':len({r['session'] for r in rows}),'unrecorded_target_sessions':missing,
        'entry_raw_unique':len(stamps),'same_entry_raw_extra_records':len(rows)-len(stamps),'families':dict(Counter(r['family'] for r in rows)),
        'raw_sha_mismatch_records':sum(r['contract'] is None for r in rows),
        'quality_mismatch_or_missing_records':sum(r['availability']['quality_matches_common'] is not True for r in rows),
        'stat_unknown_records':sum(r['availability']['stat_before_after_equal'] is None for r in rows),
        'past_current_H60_limit_records':sum(not r['availability']['entry_before_current_H60_limit'] for r in rows),
        'outside_continuous_records':sum(not r['availability']['entry_before_continuous_end'] for r in rows),
        'birth_quote_source':dict(Counter(r['birth_quote_source'] for r in rows)),'position_role_unknown_records':sum(not r['position_origin']['known'] for r in rows),
        'candidate_keys':sorted(schema),'matching_case_records':case_count,'outcomes_presence_only':dict(outcome_shapes),
        'exclusive_variant_group':exclusive,'pool_selected':False}


def baseline(data: dict,source: dict,common: dict) -> tuple[list[Candidate],dict]:
    """
    機能: 旧137A0の81候補を方向も選択も変更せず固定対照として写す。
    引数: data/source/common(dict)は非金融metadata・由来・共用場。
    返り値: tupleは固定候補と監査。元geometryと選択方向の違いも保存する。
    """
    rows=[]
    for i,r in enumerate(data['entries']):
        if r['model']!='A0':continue
        meta=common[r['session']];raw=copy.deepcopy(meta['raw']);b=quote_copy(r['birth']['quote']);q=quote_copy(r['entryQuote'])
        rows.append({'family':'固定137/A0','variant':'fixed137_A0','exclusive_variant_group':None,'source_file_sha':source['sha256'],
            'source_locator':{'file':source['path'],'entry_index':i},'session':r['session'],'contract':meta['contract'],'id':r['id'],
            'origin_id':r['source_id'],'side':r['selected_side'],'source_side':r['source_side'],'side_basis':r['direction_policy'],
            'birthQuote':b,'birth_quote_source':'metadata.birth.quote','entryQuote':q,'publication_model':'CSV_End+60',
            'original_execution':'137固定取得時点の選択方向。反転側注文適格性は未再構築',
            'position_origin':{'known':True,'initial_or_add':'対象外','reason':'既使用期の全場min1固定対照','kind':r['kind']},
            'raw_ref':raw,'availability':available(meta,{},b,q,raw),'role':'全場min1固定対照・不変更'})
    assert len(rows)==81 and len({r['session'] for r in rows})==73
    return rows,{'variant':'fixed137_A0','source':source,'candidate_count':81,'filled_sessions':73,'direction_unchanged':True,'role':'固定対照','pool_selected':False}


def variant_check(chosen: list[str]) -> None:
    """
    機能: 将来の明示選択で同じv4 familyの公表版を二重採用しない。
    引数: chosen(list[str])は未使用の選択案ID。
    返り値: None。混在なら停止。本作業で版の選択はしない。
    """
    assert len(set(chosen)&{'v4_csv','v4_raw_immediate','v4_raw_delay60'})<=1,'同familyの別公表を二重に足さない'


def main() -> None:
    """
    機能: metadata射影を監査し、小型の型/件数/不足だけを保存する。
    引数: なし。明示した保存資料だけを読む。
    返り値: None。元本文や全候補の複写、pool採用、金融は生成しない。
    """
    inventory,invsrc=load(INVENTORY);base,basesrc=load(COMMON,decoded_expected=COMMON_SHA)
    common={s['session']:s for s in base['scenes']};assert list(common)==inventory['基準対象73場']
    summary=[];fingerprints={invsrc['path']:invsrc['sha256'],basesrc['path']:basesrc['sha256']}
    for label in VARIANTS:
        spec=next(s for s in inventory['保存stream'] if s['label']==label)['保存資料']
        data,source=load(ROOT/spec['path'],spec['sha256'],spec['decoded_sha256']);rows,audit=project(label,data,source,common)
        summary.append(audit);fingerprints[source['path']]=source['sha256']
    data,source=load(BASELINE,BASELINE_SHA);rows,audit=baseline(data,source,common);summary.append(audit);fingerprints[source['path']]=source['sha256']
    assert all(sha((ROOT/p).read_bytes())==h for p,h in fingerprints.items())
    result={'成功':True,'性質':'metadata型と不足の準備。試行採番/優先/金融なし','sources':fingerprints,'variants':summary,
        'publication_variant_selected':False,'candidate_pool_flattened':False,'original_data_copied':False,
        '129旧対照':{'扱い':'128即時の同系264取得と重複するため追加variantに含めない'},
        'outcomes_values_read':False,'raw_or_CSV_or_new_financial_or_additional2_sessions_read':False,'code_sha256':sha(Path(__file__).read_bytes())}
    path=HERE/'型と不足の確認.json';assert not path.exists();path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'出力SHA256':sha(path.read_bytes()),'variants':[{k:v for k,v in r.items() if k in ('variant','candidate_count','entry_raw_unique','past_current_H60_limit_records','outside_continuous_records','raw_sha_mismatch_records','stat_unknown_records','quality_mismatch_or_missing_records')} for r in summary]},ensure_ascii=False))


if __name__=='__main__':main()
