"""射影型の時計・未知・代替版の排他を人工だけで確認する。"""
import importlib.util
import unittest
from pathlib import Path

SPEC=importlib.util.spec_from_file_location('射影型',Path(__file__).with_name('射影する.py'))
M=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(M)


class Tests(unittest.TestCase):
    """取得の採否や金融を決めず、metadataの保存だけを検査する。"""

    def test_outcomes_are_not_retained(self) -> None:
        """
        機能: 金融値とtouch方向を保持せず存在だけを残すことを検査する。
        引数: self(Tests)は検査状態。
        返り値: None。
        """
        import json
        value=json.loads('{"outcomes":[{"seconds":1800,"touches":[{"direction":-1}],"net5":123}],"id":"人工"}',object_pairs_hook=M.metadata_hook)
        self.assertEqual(value['outcomes']['record_count'],1)
        self.assertEqual(value['outcomes']['present'],True)
        self.assertNotIn('123',str(value));self.assertNotIn('direction',str(value))

    def test_variant_exclusion(self) -> None:
        """
        機能: 同family公表の二重加算を拒否する。
        引数: self(Tests)は検査状態。
        返り値: None。
        """
        M.variant_check(['far_m0','v4_raw_immediate','short_129','fixed137_A0'])
        with self.assertRaises(AssertionError):M.variant_check(['v4_csv','v4_raw_immediate'])

    def test_quote_and_boundary(self) -> None:
        """
        機能: 原行・未知の非補完と新規限界の等号flagsを検査する。
        引数: self(Tests)は検査状態。
        返り値: None。
        """
        q={'time':6100,'index':3,'source_line':7,'last':100};out=M.quote_copy(q);out['last']=200
        self.assertEqual(q['last'],100);self.assertNotIn('bid',out);self.assertNotIn('clock',out)
        meta={'start':0,'end':10000,'force_close':9400,'raw':{'path':'人工','sha256':'a'},'expected_quality':{}}
        a=M.available(meta,{},q,q,{'path':'人工','sha256':'b'})
        self.assertFalse(a['entry_before_current_H60_limit']);self.assertFalse(a['raw_sha_matches_common']);self.assertIsNone(a['stat_before_after_equal'])


if __name__=='__main__':unittest.main(verbosity=2)
