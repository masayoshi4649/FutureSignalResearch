# 全成立poolの共通入力型の準備

2026-11-12。保存済みcaseのmetadataだけを確認し、優先順位・pool採用・金融・試行採番を行っていない。元JSON本文と全候補列は複写せず、射影関数と小型の件数/不足監査を保存した。原板・自然CSV・新金融・追加2場は未読。outcomesは存在とレコード数/構造だけを残し、touch方向・到達価格・金額を使わない。

|variant|全取得|取得Rawの種類|現H60新規限界以降|場数|
|---|---:|---:|---:|---:|
|FAR M0|558|548|38|70|
|v4 CSV|164|161|13|73|
|v4 Raw即時|264|255|28|73|
|v4 Raw60秒保留|168|164|15|73|
|129新C1/C2/C3|42|42|9|73|
|固定137A0|81|既存固定対照|既存検査を継承|73|

全取得の時刻/index/物理行は保持される。118はbirth.quote、127/128/129は全取得でrequestの3項がevent.atと一致したので、そのrequestを出生Quoteとして出典付きで保持できる。取得Quoteで出生価格を補完しない。M0は同Rawの別通知も残す。Source.sideや保存取得・選択を変更しない。

共通型はfamily、variant、source_file_sha、source_locator、session、contract、id、side、birthQuote、entryQuote、publication_model、original_execution、position_origin、raw_ref、availability。型と射影関数は[射影する.py](射影する.py)。contractは共用124の同session・同原板SHAへ結合し、原板差があれば未確定とする。137A0はselected_sideを保持し、元geometryのsource_sideと未再構築の反転適格性を区別する。

M0のSignalにはmethod・accepted_s0・filled_s0はあるが、初期/追加と元枚数はない。IDや独立1枚から推定しない。本段階ではnullとし、別のSource親子台帳との結合は次の非金融manifestで行う。v4/129は保有・追加を再現しない独立候補なので初期/追加は対象外。137A0は全場min1の固定対照とし、方向を変更しない。

FARは元method、v4はQ/R/S/T、129はC1/C2/C3をfamilyにする。127CSV/128即時/128保留は同じv4 familyのalternativeであり、3列を足して独立回数にしない。129旧264取得は128即時と重複するため別variantを作らない。公表版は値・量proxy・助走も違い得るので、時刻だけの差とも呼ばない。

共用73場との原板SHA/品質差は全5variantで0。M0だけstat前後が558件未保存。70場外の11/09 Day/Night・11/10 Dayは未観測で、0取得へ変換しない。全候補のザラバ終了以降の取得は0だが、現H60新規限界min(force_close,End−3900)より後の取得は表の件数がある。ここでは除外せずflagsとし、旧観測を新phaseで使えると断定しない。原板SHA一致だけで採用index定義まで再証明したとも扱わない。

再現は `python work/全成立poolの入力型を準備する/射影する.py`、人工は同フォルダの人工検査.py。監査JSONは上書き拒否。3人工で成績値の非保持、v4版の排他、原行/未知の非補完と限界等号を確認する。型と不足の確認.jsonに全元ファイル・圧縮/解凍SHA・件数を残し、候補列のflattenやpool頻度をここでは生成しない。
