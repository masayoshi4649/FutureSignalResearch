"""138独立検算の分母・未知・費用・native正逆・phase・頻度を人工検査する。"""
from pathlib import Path
import copy
import importlib.util
import unittest

SPEC = importlib.util.spec_from_file_location('138独立検査器', Path(__file__).with_name('検算する.py'))
CHECK = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(CHECK)
M = CHECK.M


def candidate(side: int = 1, axis: str = 'BBO', status: str = 'complete', direction: int = 0) -> dict:
    """
    機能: 一つの期限価格を持つ人工候補を作る。
    引数: side(int)、axis/status(str)、direction(int)。
    返り値: dictは自然価格を使わない候補。
    """
    entry = {'time': 0, 'index': 1, 'source_line': 1, 'last': 1005, 'bid': 1000, 'ask': 1010, 'quote_ok': True}
    quote = {'time': 3600, 'index': 2, 'source_line': 2, 'last': 1010, 'bid': 1005, 'ask': 1015, 'quote_ok': True}
    price = entry['last'] if axis == 'Last' else entry['ask'] if side > 0 else entry['bid']
    return {'birth': {'side': side}, 'entry': entry, 'entry_price': price, 'outcomes': [
        {'seconds': 3600, 'status': status, 'deadline': 3600, 'endpoint': quote if status == 'complete' else None,
         'touches': [{'width': 5, 'direction': direction, 'quote': quote if direction else None}]}]}


# ----------------------------------------
def full_candidate(side: int = 1, axis: str = 'BBO') -> dict:
    """
    機能: 二つのHと五つの幅を持つ正常な人工streamを作る。
    引数: side(int)、axis(str)。
    返り値: dictはnative/実逆に再利用できる人工票。
    """
    c = candidate(side, axis); c['status'] = 'filled'; c['outcomes'] = []
    for h in M.HORIZONS:
        center = 1005 + side * 300
        q = {'time': h, 'index': h + 2, 'source_line': h + 2, 'last': center,
             'bid': center - 5, 'ask': center + 5, 'quote_ok': True}
        value = M.points(c, q, axis)
        c['outcomes'].append({'seconds': h, 'status': 'complete', 'deadline': h, 'endpoint': q,
            'points': value, 'net0': value * 100 - 77 if axis == 'BBO' else None,
            'net5': value * 100 - 1077 if axis == 'BBO' else None,
            'touches': [{'width': w, 'direction': 1, 'quote': copy.deepcopy(q)} for w in M.WIDTHS]})
    return c


# ----------------------------------------
def record(c: dict, model: str = 'P0') -> dict:
    """
    機能: 人工候補をnative方向の結合票へ入れる。
    引数: c(dict)、model(str)。
    返り値: dictは検査用record。
    """
    side = c['birth']['side']
    return {'session': '人工場', 'case': {'original': c, 'original_side': side},
            'meta': {'model': model, 'selected_side': side}}


class IndependentTests(unittest.TestCase):
    """自然の取得・観測結果を開かずに独立式の契約を確認する。"""

    def test_known_touch_survives_later_censor(self) -> None:
        """
        機能: 後のH不足でも既知touchによる清算を保持する。
        引数: self(IndependentTests)。
        返り値: None。
        """
        c = candidate(status='phase_censored', direction=-1)
        self.assertEqual(M.ifd(c, 3600, 5, 'BBO'), {'known': True, 'reason': '逆行到達', 'points': -5, 'net0': -577, 'net5': -1577})
        s = M.stats([record(c)], 'P0', 'BBO', 3600, 5)
        self.assertEqual((s['entries'], s['complete'], s['censored'], s['resolved'], s['ifd_known']), (1, 0, 1, 0, 1))
        self.assertIsNone(s['resolved_rate'])

    def test_unknown_is_not_zero(self) -> None:
        """
        機能: 未到達H不足を0円・無取引へ変換しない。
        引数: self(IndependentTests)。
        返り値: None。
        """
        c = candidate(status='gap_censored')
        self.assertEqual(M.ifd(c, 3600, 5, 'BBO'), {'known': False, 'reason': '観測不足', 'points': None, 'net0': None, 'net5': None})
        s = M.stats([record(c)], 'P0', 'BBO', 3600, 5)
        self.assertEqual((s['entries'], s['censored'], s['ifd_unknown']), (1, 1, 1))
        self.assertIsNone(s['ifd_net5_sum']); self.assertIsNone(s['ifd_net5_profit'])

    def test_costs_last_and_deadline(self) -> None:
        """
        機能: 期限清算・77/1077円・Last金額nullを確認する。
        引数: self(IndependentTests)。
        返り値: None。
        """
        x = M.ifd(candidate(), 3600, 5, 'BBO')
        self.assertEqual((x['reason'], x['points'], x['net0'], x['net5']), ('期限清算', -5, -577, -1577))
        y = M.ifd(candidate(axis='Last'), 3600, 5, 'Last')
        self.assertEqual(y['points'], 5); self.assertIsNone(y['net0']); self.assertIsNone(y['net5'])
        c = candidate(); c['outcomes'][0]['endpoint']['bid'] = 1030
        self.assertEqual(M.ifd(c, 3600, 5, 'BBO')['net5'], 923)

    def test_denominators_and_actual_both_sides_loss(self) -> None:
        """
        機能: H完了先着分母と実BBO正逆双方の損失を確認する。
        引数: self(IndependentTests)。
        返り値: None。
        """
        rows = [record(candidate(direction=1)), record(candidate(direction=-1)), record(candidate()),
                record(candidate(status='phase_censored', direction=1)), record(candidate(status='gap_censored'))]
        s = M.stats(rows, 'P0', 'BBO', 3600, 5)
        self.assertEqual((s['entries'], s['complete'], s['censored'], s['forward'], s['adverse'], s['neither'], s['resolved']), (5, 3, 2, 1, 1, 1, 2))
        self.assertEqual(s['resolved_rate'], .5); self.assertEqual(s['ifd_known'], 4)
        a = M.ifd(candidate(1), 3600, 5, 'BBO'); b = M.ifd(candidate(-1), 3600, 5, 'BBO')
        self.assertEqual((a['points'], b['points']), (-5, -15))

    def test_native_direction_and_flip_basis(self) -> None:
        """
        機能: P0/C0のnativeとR0実逆、native反転数の基準を確認する。
        引数: self(IndependentTests)。
        返り値: None。
        """
        r = record(candidate(-1)); r['case']['reverse'] = candidate(1)
        self.assertEqual(M.side_for(r, 'P0'), -1); self.assertEqual(M.side_for(r, 'R0'), 1)
        self.assertIs(M.choose(r, 'P0', 'BBO'), r['case']['original'])
        self.assertIs(M.choose(r, 'R0', 'BBO'), r['case']['reverse'])
        self.assertEqual(M.stats([r], 'P0', 'BBO', 3600, 5)['flips'], 0)
        self.assertEqual(M.stats([r], 'R0', 'BBO', 3600, 5)['flips'], 1)

    def test_phase_strict_boundary_and_endpoint_window(self) -> None:
        """
        機能: ザラバ終端等号拒否、期限+30秒等号許可、未来原行拒否を確認する。
        引数: self(IndependentTests)。
        返り値: None。
        """
        c = full_candidate(); entry = c['entry']
        self.assertEqual(CHECK.validate_stream(c, entry, 1, 'BBO', 4000)['touch検査'], 10)
        for field in ('time', 'index', 'source_line'):
            bad = copy.deepcopy(c)
            if field == 'time':
                bad['outcomes'][1]['endpoint'][field] = 4000
            else:
                bad['outcomes'][1]['endpoint'][field] = entry[field]
            with self.assertRaises(AssertionError):
                CHECK.validate_stream(bad, entry, 1, 'BBO', 4000)
        plus = copy.deepcopy(c); plus['outcomes'][1]['endpoint']['time'] = 3630
        CHECK.validate_stream(plus, entry, 1, 'BBO', 4000)
        plus['outcomes'][1]['endpoint']['time'] = 3630.001
        with self.assertRaises(AssertionError):
            CHECK.validate_stream(plus, entry, 1, 'BBO', 4000)

    def test_weighted_frequency(self) -> None:
        """
        機能: 全時間加重平均・0回の場・場別単純平均を区別する。
        引数: self(IndependentTests)。
        返り値: None。
        """
        sessions = [f'人工{i:03d}' for i in range(73)]; scenes = []; rows = []
        for i, sid in enumerate(sessions):
            end = 7500 if i == 0 else 14700
            scenes.append({'session': sid, 'start': 0, 'end': end, 'force_close': end - 600})
            rows.append({'session': sid, 'meta': {'model': 'P0'}})
        f = M.frequency(rows, sessions, scenes)
        self.assertAlmostEqual(f['all']['P0']['全時間平均件数毎時'], 73/290)
        self.assertNotAlmostEqual(f['all']['P0']['全時間平均件数毎時'], f['all']['P0']['場別頻度分布']['単純平均_主平均ではない'])
        self.assertEqual(f['all']['C0']['場別頻度分布']['0取得場数'], 73)

    def test_old_control_stream_swap(self) -> None:
        """
        機能: 旧Sourceとselectedが逆の1件を含む81件の四stream対応入替を確認する。
        引数: self(IndependentTests)。
        返り値: None。
        """
        rows = []; old_cases = []; old_meta = []
        for i in range(81):
            identifier = 'A0/人工/' + str(i); old = {'id': identifier, 'original_side': 1}
            for name, side, axis in [('original', 1, 'BBO'), ('reverse', -1, 'BBO'), ('chart_original', 1, 'Last'), ('chart_reverse', -1, 'Last')]:
                old[name] = full_candidate(side, axis)
            selected = -1 if i == 0 else 1
            mapping = {'original': 'reverse' if selected < 0 else 'original', 'reverse': 'original' if selected < 0 else 'reverse'}
            new = {'id': 'C0/' + identifier, 'original_side': selected}
            for a, b in mapping.items():
                new[a] = copy.deepcopy(old[b]); new['chart_' + a] = copy.deepcopy(old['chart_' + b])
            rows.append({'session': '人工場', 'case': new, 'meta': {'model': 'C0', 'selected_side': selected, 'candidate_id': identifier}})
            old_cases.append(old); old_meta.append({'session': '人工場', 'id': identifier, 'model': 'A0', 'selected_side': selected})
        values = {p: {'C0': {a: {str(h): {str(w): M.stats(rows, 'C0', a, h, w) for w in M.WIDTHS} for h in M.HORIZONS} for a in M.AXES}} for p in ('all', 'train', 'validation')}
        old_values = {p: {'A0': copy.deepcopy(values[p]['C0'])} for p in values}
        for part in old_values.values():
            for axis in part['A0'].values():
                for horizon in axis.values():
                    for condition in horizon.values():
                        condition['flips'] = 1
        proof = CHECK.baseline(rows, values, {'scenes': [{'session': '人工場', 'cases': old_cases}]}, {'集計': old_values}, {'entries': old_meta})
        self.assertEqual(proof['四streamのH幅ラベル'], 3240)
        self.assertEqual(proof['方向反転数以外の全条件同体'], 60)
        bad = copy.deepcopy(rows); bad[0]['case']['original'] = old_cases[0]['original']
        with self.assertRaises(AssertionError):
            CHECK.baseline(bad, values, {'scenes': [{'session': '人工場', 'cases': old_cases}]}, {'集計': old_values}, {'entries': old_meta})


if __name__ == '__main__':
    unittest.main(verbosity=2)
