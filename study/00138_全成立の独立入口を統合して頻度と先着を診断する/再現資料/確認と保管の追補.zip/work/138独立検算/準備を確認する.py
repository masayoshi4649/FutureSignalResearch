"""138の金融入力を開かず、独立式の人工と固定metadata接続だけを点検する。"""
from pathlib import Path
from collections import Counter
import argparse
import ast
import importlib.util
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('138独立準備', HERE / '検算する.py')
CHECK = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(CHECK)
M = CHECK.M


def main() -> None:
    """
    機能: 自然金融未読で人工8群と833固定取得の非金融由来を点検する。
    引数: CLI --output-name(str)は未作成のproof名。
    返り値: None。F1・観測・集計・表・Raw/CSV/追加2場は開かない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--output-name', default='準備の確認.json')
    args = parser.parse_args()
    assert Path(args.output_name).name == args.output_name and args.output_name.endswith('.json')
    code_files = [HERE / n for n in ('算術.py', '検算する.py', '人工検査.py', '準備を確認する.py')]
    before = {p.name: M.sha(p) for p in code_files}
    completed = subprocess.run([sys.executable, '-X', 'utf8', str(HERE / '人工検査.py')], capture_output=True, text=True, encoding='utf-8', check=True)
    assert 'Ran 8 tests' in completed.stderr and completed.stderr.rstrip().endswith('OK')
    refusal = subprocess.run([sys.executable, '-X', 'utf8', str(HERE / '検算する.py')], capture_output=True, text=True, encoding='utf-8')
    assert refusal.returncode == 2 and '--f1' in refusal.stderr and '--result' in refusal.stderr
    values = {}
    sources = {}
    for name, (relative, expected) in {'fixed': CHECK.FIXED, 'metadata': CHECK.META, 'manifest': CHECK.MANIFEST,
            'old137metadata': CHECK.OLD['metadata']}.items():
        path = ROOT / relative; assert M.sha(path) == expected
        values[name] = json.loads(path.read_text('utf-8'))
        sources[relative] = expected
    fixed, meta, manifest = values['fixed'], values['metadata'], values['manifest']
    assert not manifest['financial_labels_used'] and manifest['raw_CSV_financial_additional2_read'] is False
    mmap = {(m['session'], m['id']): m for m in meta['entries']}; seen = set(); rows = []
    assert len(mmap) == fixed['expected_entry_count'] == 833 and len(fixed['scenes']) == 73
    model_counts = Counter(); identities = {k: {} for k in M.MODELS}
    for scene in fixed['scenes']:
        boundary = scene['end'] - 300; limit = min(scene['force_close'], boundary - 3600)
        for entry in scene['entries']:
            key = scene['session'], entry['id']; assert key in mmap and key not in seen; seen.add(key)
            m = mmap[key]; quote = entry['entry']; source = manifest[m['model']][m['manifest_index']]
            assert m['contract'] == source['contract'] == scene['contract'] and source['session'] == scene['session']
            assert source['id'] == m['candidate_id'] and source['side'] == m['selected_side'] == entry['side']
            assert m['baseline'] == source['baseline'] and scene['start'] <= quote['time'] < limit
            assert m['origin_count'] == len(source['origins'])
            assert sorted(m['origin_families']) == sorted({o['family'] for o in source['origins']})
            for field in ('time', 'index', 'source_line', 'last', 'bid', 'ask', 'quote_ok'):
                assert quote[field] == source['entryQuote'][field]
            assert {o['entryQuote']['clock'] for o in source['origins']} == {quote['clock']}
            identity = scene['session'], scene['contract'], quote['time'], quote['index'], quote['source_line']
            assert identity not in identities[m['model']]
            identities[m['model']][identity] = entry['side']
            rows.append({'session': scene['session'], 'meta': m}); model_counts[m['model']] += 1
    assert seen == set(mmap) and model_counts == {'C0': 81, 'P0': 752}
    assert all(identities['P0'][k] == side for k, side in identities['C0'].items())
    old = {(x['session'], x['id']): x for x in values['old137metadata']['entries'] if x['model'] == 'A0'}
    assert len(old) == 81
    controls = [x for x in meta['entries'] if x['model'] == 'C0']
    assert len(controls) == 81
    for m in controls:
        previous = old[m['session'], m['candidate_id']]
        assert previous['selected_side'] == m['selected_side']
    sessions = [s['session'] for s in fixed['scenes']]
    freq = M.frequency(rows, sessions, fixed['scenes'])
    assert freq['all']['P0']['取得数'] == 752 and freq['all']['P0']['場別頻度分布']['0取得場数'] == 0
    assert freq['all']['C0']['取得数'] == 81 and freq['all']['C0']['場別頻度分布']['0取得場数'] == 0
    for model in M.MODELS:
        M.equal(freq['all'][model]['全時間平均件数毎時'], manifest['frequency'][model]['weighted_entries_per_full_hour'])
    imports = {}
    for p in (HERE / '算術.py', HERE / '検算する.py'):
        tree = ast.parse(p.read_text('utf-8'))
        imports[p.name] = [n.module if isinstance(n, ast.ImportFrom) else ','.join(x.name for x in n.names)
            for n in ast.walk(tree) if isinstance(n, (ast.Import, ast.ImportFrom))]
    assert before == {p.name: M.sha(p) for p in code_files}
    assert all(M.sha(ROOT / p) == h for p, h in sources.items())
    schema_source = ROOT / 'work/138全成立入口と頻度の集計/集計する.py'
    tree = ast.parse(schema_source.read_text('utf-8'))
    schema = {}
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id in ('COMPARISON_HEADERS','DETAIL_HEADERS','SCENE_HEADERS') for t in node.targets):
            schema[node.targets[0].id] = ast.literal_eval(node.value)
    for policy in M.POLICIES:
        schema['DETAIL_HEADERS'] += [policy+s for s in ('方向','125全H','125先着','IFD既知','清算','125C5代用円')]
    for suffix in ('取得数','最低1取得','全時間頻度','名目新規可時間頻度'):
        schema['SCENE_HEADERS'] += [m+suffix for m in ('P0','C0')]
    for policy in M.POLICIES:
        schema['SCENE_HEADERS'] += [policy+s for s in ('反転数','125順','125逆','125未到達','全H不足','IFD既知','IFD未知','C5利益円','C5損失絶対円','C5既知差引円','C5既知累計円_口座収支ではない','累計IFD未知')]
    assert [len(schema[k]) for k in ('COMPARISON_HEADERS','DETAIL_HEADERS','SCENE_HEADERS')] == [34,36,49]
    schema_file = HERE / '金融前の表列契約.json'
    schema_value = {'Root静的契約源SHA256': M.sha(schema_source), 'Root金融関数をimport':False,
        '形状':[[180,34],[833,36],[73,49]], '総データセル':39685,'headers':schema}
    if schema_file.exists():
        assert json.loads(schema_file.read_bytes()) == schema_value
    else:
        schema_file.write_text(json.dumps(schema_value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    proof = {'成功': True, '試行': 138, '段階': '金融前の独立算術準備・三表列契約接続済み', '人工主検査': 8, '人工成功': True,
        '金融SHA無指定CLI拒否': True, '全833取得/73場metadata接続': True, '各modelの取得': dict(model_counts),
        '各modelの取得原行重複': 0, 'C0全81をP0に同方向保持': True, 'C0旧137A0 selected方向同体': 81,
        'canonical clockは全originと同体': True, '新規phase等号不可': True,
        '独自式の非金融頻度': {k: freq['all'][k] for k in M.MODELS}, '固定入力前後同体': True,
        'コード前後同体': before, '入力SHA256': sources, '静的import一覧': imports,
        '自然F1/観測/集計/表を読取': False, '旧137金融観測/集計を読取': False,
        'Raw/CSV/追加2場を読取': False, '固定124/Root138金融関数をimport': False,
        '三表列契約接続':True, '三表全セル検算予定':39685, '表列契約SHA256':M.sha(schema_file),
        '金融検算完了ではない': True}
    out = HERE / args.output_name; assert not out.exists()
    out.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    (HERE / '人工ログ.txt').write_text(completed.stderr, encoding='utf-8')
    print(json.dumps({'成功': True, '準備proofSHA256': M.sha(out), '人工': 8, '自然金融読取': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
