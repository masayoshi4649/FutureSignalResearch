"""138の固定取得と保存観測を独立式で照合する。金融SHA通知後だけ実行する。"""
from pathlib import Path
from collections import Counter
import argparse
import importlib.util
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('138独立算術', HERE / '算術.py')
M = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)

FIXED = ('work/138全成立入口の評価/固定入力_版2/固定取得入力.json', '0c83e525dec3079ce188d942069c0d137c94f39009339752ec8227ec9ecb4ce7')
META = ('work/138全成立入口の評価/固定入力_版2/入口参照.json', '75e4993571bdef17839aad3324acc6ee9ce09b3cb1f4ecad70637a1e01ccefd0')
MANIFEST = ('work/全成立poolの非金融manifest/manifest.json', 'e7ba444fd66f9ca52e10e929eeb31d21076f97afa161de738dabca14a8ff8e35')
OLD = {
    'observations': ('work/137既知回復の評価/固定取得の正逆観測.json', 'f0adca92cf1f1db25e75e4d92187952e2920ea7126b3790ece89df1c7f00369a'),
    'aggregate': ('work/137既知回復と頻度の集計/集計.json', 'f7c73cc87948fa17174e3909f89aa63d74abe76191bf435788e71cb0d400548b'),
    'metadata': ('work/137既知回復の評価/固定入力/方向と出生.json', '86f33705ba40fd3ba1b845557a2368e44c2802635082fc3bad69346770103f93'),
}


def validate_stream(stream: dict, entry: dict, side: int, axis: str, boundary: float) -> dict:
    """
    機能: 保存Quoteの価格・方向・H・ザラバ境界と金額を独立式で確認する。
    引数: stream/entry(dict)、side(int)、axis(str)、boundary(float)。
    返り値: dictはstream/entry/endpoint/touch検査数。Rawの初回touchを再走査しない。
    """
    assert stream['status'] == 'filled' and stream['birth']['side'] == side and stream['entry'] == entry
    assert entry['quote_ok'] and 0 < entry['bid'] < entry['ask'] and entry['last'] > 0
    assert stream['entry_price'] == (entry['last'] if axis == 'Last' else entry['ask'] if side > 0 else entry['bid'])
    assert tuple(o['seconds'] for o in stream['outcomes']) == M.HORIZONS
    count = Counter({'stream検査': 1, 'entry検査': 1})
    for o in stream['outcomes']:
        assert o['deadline'] == entry['time'] + o['seconds']
        assert tuple(t['width'] for t in o['touches']) == M.WIDTHS
        assert (o['endpoint'] is not None) == (o['status'] == 'complete')
        q = o['endpoint']
        if q is not None:
            assert o['deadline'] <= q['time'] <= o['deadline'] + 30 and q['time'] < boundary
            assert q['index'] > entry['index'] and q['source_line'] > entry['source_line']
            assert q['quote_ok'] and 0 < q['bid'] < q['ask'] and q['last'] > 0
            value = M.points(stream, q, axis)
            M.equal(o['points'], value)
            M.equal(o['net0'], value * 100 - 77 if axis == 'BBO' else None)
            M.equal(o['net5'], value * 100 - 1077 if axis == 'BBO' else None)
            count['endpoint検査'] += 1
        else:
            assert o['points'] is None and o['net0'] is None and o['net5'] is None
        for t in o['touches']:
            assert type(t['direction']) is int and t['direction'] in (-1, 0, 1)
            q = t['quote']; assert (q is None) == (t['direction'] == 0)
            if q is None:
                continue
            assert entry['time'] <= q['time'] <= o['deadline'] and q['time'] < boundary
            assert q['index'] > entry['index'] and q['source_line'] > entry['source_line']
            assert q['quote_ok'] and 0 < q['bid'] < q['ask'] and q['last'] > 0
            value = M.points(stream, q, axis)
            assert value >= t['width'] if t['direction'] > 0 else value <= -t['width']
            count['touch検査'] += 1
    return dict(count)


# ----------------------------------------
def join(result: dict, fixed: dict, meta: dict, manifest: dict) -> tuple:
    """
    機能: 833取得とnative方向・由来・4価格streamを結合し、区間を点検する。
    引数: result/fixed/meta/manifest(dict)は固定済み票。
    返り値: tupleは全records・場順・phase件数。
    """
    assert result['success'] and result['trial'] == 133 and result['source_entry_count'] == 833
    assert fixed['expected_entry_count'] == 833 and meta['trial'] == 138 and meta['success']
    assert meta['fixed_input_sha256'] == result['input_sha256'] == FIXED[1]
    assert meta['manifest_sha256'] == MANIFEST[1]
    mmap = {(e['session'], e['id']): e for e in meta['entries']}
    assert len(mmap) == 833 and Counter(e['model'] for e in meta['entries']) == {'C0': 81, 'P0': 752}
    records = []; sessions = []; seen = set(); counts = Counter()
    assert len(result['scenes']) == len(fixed['scenes']) == 73
    for scene, source in zip(result['scenes'], fixed['scenes']):
        sid = scene['session']; sessions.append(sid)
        assert sid == source['session'] and scene['success']
        boundary = source['end'] - 300; limit = min(source['force_close'], boundary - 3600)
        assert scene['execution_end'] == boundary and scene['effective_entry_limit'] == limit
        assert scene['source_force_close'] == source['force_close']
        assert scene['quality'] == scene['expected_quality'] == source['expected_quality']
        assert scene['actual_sha256'] == source['raw']['sha256']
        assert scene['stat_before'] == scene['stat_after']
        inputs = {e['id']: e for e in source['entries']}; assert len(inputs) == len(scene['cases'])
        for case in scene['cases']:
            key = sid, case['id']; assert key in mmap and key not in seen; seen.add(key)
            m = mmap[key]; original = inputs[case['id']]; entry = original['entry']
            assert m['model'] in M.MODELS and m['contract'] == source['contract']
            assert case['original_side'] == original['side'] == m['selected_side']
            assert source['start'] <= entry['time'] < limit and entry['clock']
            origin = manifest[m['model']][m['manifest_index']]
            assert origin['id'] == m['candidate_id'] and origin['session'] == sid and origin['contract'] == source['contract']
            assert origin['side'] == m['selected_side'] and origin['baseline'] == m['baseline']
            assert m['origin_count'] == len(origin['origins'])
            assert sorted(m['origin_families']) == sorted({o['family'] for o in origin['origins']})
            for field in ('time', 'index', 'source_line', 'last', 'bid', 'ask', 'quote_ok'):
                assert entry[field] == origin['entryQuote'][field]
            clocks = {o['entryQuote']['clock'] for o in origin['origins']}
            assert clocks == {entry['clock']}
            for name in ('original', 'reverse', 'chart_original', 'chart_reverse'):
                side = case['original_side'] * (1 if name.endswith('original') else -1)
                counts.update(validate_stream(case[name], entry, side, 'Last' if name.startswith('chart_') else 'BBO', boundary))
            records.append({'session': sid, 'case': case, 'meta': m, 'canonical': origin, 'scene': source})
    assert len(sessions) == len(set(sessions)) == 73 and seen == set(mmap)
    for model in M.MODELS:
        stamps = [(r['session'], tuple(r['case']['original']['entry'][k] for k in ('time', 'index', 'source_line'))) for r in records if r['meta']['model'] == model]
        assert len(stamps) == len(set(stamps))
    return records, sessions, dict(counts)


# ----------------------------------------
def calculate(records: list, sessions: list, scenes: list) -> tuple:
    """
    機能: 独自式で全180条件・参加・頻度・主評価を計算する。
    引数: records/sessions/scenes(list)は固定票・全場順・時計。
    返り値: tupleは集計/参加/頻度/主評価。
    """
    parts = {'all': sessions, 'train': sessions[:48], 'validation': sessions[48:]}
    values = {}; participation = {}
    for part, ids in parts.items():
        participation[part] = {}; values[part] = {}
        for model in M.MODELS:
            rows = [r for r in records if r['meta']['model'] == model and r['session'] in ids]
            missing = [sid for sid in ids if not any(r['session'] == sid for r in rows)]
            participation[part][model] = {'対象場数': len(ids), '取得数': len(rows), '取得場数': len(ids) - len(missing),
                '未取得場数': len(missing), '未取得場': missing, '全場最低1取得': not missing and bool(ids)}
        for policy in M.POLICIES:
            values[part][policy] = {axis: {str(h): {str(w): M.stats(M.subset(records, policy, ids), policy, axis, h, w)
                for w in M.WIDTHS} for h in M.HORIZONS} for axis in M.AXES}
    freq = M.frequency(records, sessions, scenes)
    freq['定義'] = '全時間=sum(end-300-start)/3600。名目新規可時間=sum(min(force_close,end-3900)-start)/3600は副評価'
    s = values['all']['P0']['BBO']['3600']['125']; p = participation['all']['P0']
    rate = s['target70'] is True; hourly = freq['all']['P0']['全時間平均1件毎時以上']
    goal = {'主': 'P0/native/全73場/実BBO/H60/±125pt', '全73場最低1取得': p['全場最低1取得'],
        '到達済み先着70%以上': rate, '入口品質の両条件達成': bool(p['全場最低1取得'] and rate),
        '全時間平均1件毎時以上': hourly, '三項目すべて達成': bool(p['全場最低1取得'] and rate and hourly),
        '順': s['forward'], '逆': s['adverse'], '未到達': s['neither'], '全H不足': s['censored'],
        '到達済み率': s['resolved_rate'], '完了分母率': s['complete_rate'],
        '全件分母率': s['forward'] / s['entries'] if s['entries'] else None,
        '全時間平均件数毎時': freq['all']['P0']['全時間平均件数毎時'], '参加': p}
    return values, participation, freq, goal


# ----------------------------------------
def baseline(records: list, values: dict, old_result: dict, old_aggregate: dict, old_meta: dict) -> dict:
    """
    機能: C0旧137A0の81取得・4streamラベル・60条件を向き対応させて照合する。
    引数: records(list)、values/old_result/old_aggregate/old_meta(dict)。
    返り値: dictは同体件数。flipsだけ旧元方向基準と新native基準を分ける。
    """
    reference = {(s['session'], c['id']): c for s in old_result['scenes'] for c in s['cases']}
    old_m = {(e['session'], e['id']): e for e in old_meta['entries']}
    count = 0; labels = 0
    for row in records:
        m = row['meta']
        if m['model'] != 'C0':
            continue
        key = row['session'], m['candidate_id']; prior = reference[key]; pm = old_m[key]
        assert pm['model'] == 'A0' and pm['selected_side'] == row['case']['original_side']
        native_old = 'original' if pm['selected_side'] == prior['original_side'] else 'reverse'
        reverse_old = 'reverse' if native_old == 'original' else 'original'
        for new_name, old_name in [('original', native_old), ('reverse', reverse_old),
                ('chart_original', 'chart_' + native_old), ('chart_reverse', 'chart_' + reverse_old)]:
            for field in ('entry', 'entry_price', 'outcomes'):
                M.equal(row['case'][new_name][field], prior[old_name][field], '旧137/' + str(key) + '/' + field)
            labels += 10
        count += 1
    assert count == 81 and labels == 3240
    conditions = 0; flip_changes = []
    for part in ('all', 'train', 'validation'):
        for axis in M.AXES:
            for h in M.HORIZONS:
                for w in M.WIDTHS:
                    new = values[part]['C0'][axis][str(h)][str(w)]
                    old = old_aggregate['集計'][part]['A0'][axis][str(h)][str(w)]
                    assert new['flips'] == 0
                    M.equal({k: v for k, v in new.items() if k != 'flips'}, {k: v for k, v in old.items() if k != 'flips'}, '旧137条件')
                    flip_changes.append({'区分': part, '軸': axis, 'H': h, '幅': w, '旧Source基準': old['flips'], '新native基準': 0})
                    conditions += 1
    assert conditions == 60
    return {'成功': True, 'C0旧137A0取得': count, '四streamのH幅ラベル': labels,
        '方向反転数以外の全条件同体': conditions, 'flipsの基準差': flip_changes, '旧固定資料変更': False}


# ----------------------------------------
def tables_check(tables: list, records: list, sessions: list, values: dict, participation: dict, freq: dict) -> dict:
    """
    機能: 金融前に合意した三表の独立期待値を照合する。
    引数: tables/records/sessions(list)、values/participation/freq(dict)。
    返り値: dictは三表39685セルの確認。実CSVの再読・描画は別検査。
    """
    expected_headers = [
        ['試行','区分','政策','取得集合','価格軸','評価分','同幅pt','対象場数','取得場数','取得数',
         'native向きからの反転数','全場最低1取得','全H完了','観測不足','順行先着','逆行先着','両方未到達',
         '到達済み順行率','完了分母順行率','全取得分母順行率','到達済み70%達成','参加と70%両達成',
         '全時間平均件数毎時','名目新規可時間平均件数毎時','全時間平均1件毎時以上','参加と70%と頻度すべて達成',
         'IFD代用既知','IFD代用未知','C0代用差引円','C5代用利益円','C5代用損失絶対円','C5代用差引円','C5代用平均円','C5代用PF'],
        ['試行','参考区分','セッション','取得集合','固定取得ID','候補ID','native方向','固定対照由来','origin数',
         'origin系統','origin版','初期親数','親種別','取得JST','元取得価格','逆取得価格','H60新規限界JST','原板SHA256'],
        ['試行','セッション','参考区分','ザラバ時間h','名目新規可時間h'],
    ]
    for policy in M.POLICIES:
        expected_headers[1] += [policy + s for s in ('方向','125全H','125先着','IFD既知','清算','125C5代用円')]
    for suffix in ('取得数','最低1取得','全時間頻度','名目新規可時間頻度'):
        expected_headers[2] += [m + suffix for m in ('P0','C0')]
    for policy in M.POLICIES:
        expected_headers[2] += [policy + s for s in ('反転数','125順','125逆','125未到達','全H不足','IFD既知','IFD未知',
            'C5利益円','C5損失絶対円','C5既知差引円','C5既知累計円_口座収支ではない','累計IFD未知')]
    assert [(t['name'], len(t['rows']), len(t['headers'])) for t in tables] == [('正逆比較',180,34),('入口別診断',833,36),('全セッション',73,49)]
    assert [t['headers'] for t in tables] == expected_headers
    count = 0; seen = set()
    for row in tables[0]['rows']:
        actual = dict(zip(tables[0]['headers'], row)); part = actual['区分']; policy = actual['政策']
        axis = actual['価格軸']; h = int(actual['評価分'] * 60); w = actual['同幅pt']
        key = part, policy, axis, h, w; assert key not in seen; seen.add(key)
        s = values[part][policy][axis][str(h)][str(w)]
        p = participation[part][M.MODEL[policy]]; f = freq[part][M.MODEL[policy]]
        quality = bool(p['全場最低1取得'] and s['target70'] is True)
        expected = {'試行':138,'区分':part,'政策':policy,'取得集合':M.MODEL[policy],'価格軸':axis,'評価分':h/60,'同幅pt':w,
            '対象場数':p['対象場数'],'取得場数':s['sessions'],'取得数':s['entries'],'native向きからの反転数':s['flips'],
            '全場最低1取得':p['全場最低1取得'],'全H完了':s['complete'],'観測不足':s['censored'],
            '順行先着':s['forward'],'逆行先着':s['adverse'],'両方未到達':s['neither'],'到達済み順行率':s['resolved_rate'],
            '完了分母順行率':s['complete_rate'],'全取得分母順行率':s['forward']/s['entries'] if s['entries'] else None,
            '到達済み70%達成':s['target70'],'参加と70%両達成':quality,'全時間平均件数毎時':f['全時間平均件数毎時'],
            '名目新規可時間平均件数毎時':f['名目新規可時間平均件数毎時'],'全時間平均1件毎時以上':f['全時間平均1件毎時以上'],
            '参加と70%と頻度すべて達成':quality and f['全時間平均1件毎時以上'], 'IFD代用既知':s['ifd_known'],
            'IFD代用未知':s['ifd_unknown'],'C0代用差引円':s['ifd_net0_sum'],'C5代用利益円':s['ifd_net5_profit'],
            'C5代用損失絶対円':s['ifd_net5_loss'],'C5代用差引円':s['ifd_net5_sum'],'C5代用平均円':s['ifd_net5_mean'],'C5代用PF':s['ifd_net5_pf']}
        count += M.equal(actual, expected, '比較表/' + str(key))
    assert seen == {(part,p,a,h,w) for part in ('all','train','validation') for p in M.POLICIES for a in M.AXES for h in M.HORIZONS for w in M.WIDTHS}
    assert [r[tables[1]['headers'].index('固定取得ID')] for r in tables[1]['rows']] == [r['case']['id'] for r in records]
    for raw_row, record in zip(tables[1]['rows'], records):
        m = record['meta']; c = record['case']; origin = record['canonical']; scene = record['scene']
        parents = {tuple(o['position_origin']['parent_key']) for o in origin['origins'] if 'parent_key' in o['position_origin']}
        kinds = sorted({o['position_origin']['initial_or_add'] for o in origin['origins'] if o['position_origin'].get('initial_or_add') is not None})
        expected = {'試行':138,'参考区分':'train' if record['session'] in sessions[:48] else 'validation',
            'セッション':record['session'],'取得集合':m['model'],'固定取得ID':c['id'],'候補ID':m['candidate_id'],
            'native方向':c['original_side'],'固定対照由来':m['baseline'],'origin数':m['origin_count'],
            'origin系統':'|'.join(sorted({o['family'] for o in origin['origins']})),
            'origin版':'|'.join(sorted({o['variant'] for o in origin['origins']})), '初期親数':len(parents),'親種別':'|'.join(kinds),
            '取得JST':M.jst(c['original']['entry']['time']),'元取得価格':c['original']['entry_price'],'逆取得価格':c['reverse']['entry_price'],
            'H60新規限界JST':M.jst(min(scene['force_close'],scene['end']-3900)),'原板SHA256':scene['raw']['sha256']}
        for policy in M.POLICIES:
            names = [policy + s for s in ('方向','125全H','125先着','IFD既知','清算','125C5代用円')]
            if m['model'] != M.MODEL[policy]:
                expected.update(dict.fromkeys(names, None)); continue
            chosen = M.choose(record, policy, 'BBO'); o = M.observation(chosen, 3600); exit = M.ifd(chosen,3600,125,'BBO')
            expected.update(zip(names, [chosen['birth']['side'],o['status'],M.touch(o,125)['direction'],exit['known'],exit['reason'],exit['net5']]))
        count += M.equal(dict(zip(tables[1]['headers'],raw_row)),expected,'入口表/'+c['id'])
    assert [r[tables[2]['headers'].index('セッション')] for r in tables[2]['rows']] == sessions
    cumulative = Counter(); unknown = Counter()
    for i, (raw_row, sid) in enumerate(zip(tables[2]['rows'], sessions)):
        f = freq['場別'][sid]
        expected = {'試行':138,'セッション':sid,'参考区分':'train' if i<48 else 'validation',
            'ザラバ時間h':f['全時間h'],'名目新規可時間h':f['名目新規可時間h']}
        for model in M.MODELS:
            v = f['models'][model]
            expected.update({model+'取得数':v['取得数'],model+'最低1取得':bool(v['取得数']),
                model+'全時間頻度':v['全時間頻度'],model+'名目新規可時間頻度':v['名目新規可時間頻度']})
        for policy in M.POLICIES:
            s = M.stats(M.subset(records,policy,[sid]),policy,'BBO',3600,125)
            cumulative[policy] += s['ifd_net5_sum'] or 0; unknown[policy] += s['ifd_unknown']
            expected.update({policy+'反転数':s['flips'],policy+'125順':s['forward'],policy+'125逆':s['adverse'],
                policy+'125未到達':s['neither'],policy+'全H不足':s['censored'],policy+'IFD既知':s['ifd_known'],
                policy+'IFD未知':s['ifd_unknown'],policy+'C5利益円':s['ifd_net5_profit'],policy+'C5損失絶対円':s['ifd_net5_loss'],
                policy+'C5既知差引円':s['ifd_net5_sum'],policy+'C5既知累計円_口座収支ではない':cumulative[policy],policy+'累計IFD未知':unknown[policy]})
        count += M.equal(dict(zip(tables[2]['headers'],raw_row)),expected,'場表/'+sid)
    assert count == 39685
    return {'success':True,'table_dimensions':[[180,34],[833,36],[73,49]],'all_data_cells_equal':count,'actual_csv_reread_or_render':False}


# ----------------------------------------
def main() -> None:
    """
    機能: Rootから明示通知されたF1/観測/集計/表SHAを照合後にだけ自然検算する。
    引数: CLI --f1/--result/--aggregate/--tables(Path)と各--sha256(str)。
    返り値: None。未知SHA・出力上書き・無指定実行は拒否する。
    """
    parser = argparse.ArgumentParser()
    for name in ('f1', 'result', 'aggregate', 'tables'):
        parser.add_argument('--' + name, type=Path, required=True)
        parser.add_argument('--' + name + '-sha256', required=True)
    args = parser.parse_args(); paths = {name: (getattr(args, name).resolve(), getattr(args, name + '_sha256')) for name in ('f1', 'result', 'aggregate', 'tables')}
    paths.update({'fixed': (ROOT / FIXED[0], FIXED[1]), 'metadata': (ROOT / META[0], META[1]),
        'manifest': (ROOT / MANIFEST[0], MANIFEST[1]), **{'old_' + k: (ROOT / p, h) for k, (p, h) in OLD.items()}})
    assert all(len(h) == 64 and all(c in '0123456789abcdef' for c in h) and M.sha(p) == h for p, h in paths.values())
    load = lambda name: json.loads(paths[name][0].read_text('utf-8-sig'))
    f1 = load('f1'); declared = {Path(p).resolve(): h for p, h in f1['ファイル'].items()}
    assert declared[ROOT / FIXED[0]] == FIXED[1] and declared[ROOT / META[0]] == META[1]
    fixed, meta, manifest = load('fixed'), load('metadata'), load('manifest')
    result, aggregate, tables = load('result'), load('aggregate'), load('tables')
    assert aggregate['試行'] == 138 and aggregate['主政策'] == 'P0' and aggregate['F1_SHA256'] == paths['f1'][1]
    assert aggregate['固定入力SHA256'] == FIXED[1] and aggregate['入口参照SHA256'] == META[1] and aggregate['自然結果SHA256'] == paths['result'][1]
    assert aggregate['manifestSHA256'] == MANIFEST[1] and aggregate['取得集合数'] == {'P0':752,'C0':81}
    assert aggregate['異母集団caseペア差'] is None and aggregate['全73場は既使用'] is True
    assert aggregate['独立未知期検証'] is False and aggregate['口座収支'] is False and aggregate['実IFD'] is False
    records, sessions, phase = join(result, fixed, meta, manifest)
    values, participation, freq, goal = calculate(records, sessions, fixed['scenes'])
    leaves = M.equal(aggregate['集計'], values, '全180条件')
    M.equal(aggregate['参加'], participation); M.equal(aggregate['頻度'], freq)
    M.equal(aggregate['主評価'], goal); M.equal(aggregate['全4streamのphase検査'], phase)
    old = baseline(records, values, load('old_observations'), load('old_aggregate'), load('old_metadata'))
    M.equal(aggregate['旧C0同体'], {'成功':True,'旧137A0件数':81,'4stream全H幅照合':3240,
        '旧60条件_反転数基準差以外同体':60, '反転数基準':'旧Source方向相対から新native方向相対へ変更。C0新0、旧全体31','旧結果変更':False})
    table_proof = tables_check(tables['tables'], records, sessions, values, participation, freq)
    assert all(M.sha(p) == h for p, h in paths.values())
    proof = {'success': True, 'trial': 138, 'condition_count': 180, 'aggregate_leaf_values_checked': leaves,
        'entries': 833, 'sessions': 73, 'phase_checks': phase, 'participation': participation, 'frequency': freq,
        'table_checks': table_proof, 'old_C0': old, 'main': values['all']['P0']['BBO']['3600']['125'],
        'front48': values['train']['P0']['BBO']['3600']['125'], 'back25': values['validation']['P0']['BBO']['3600']['125'],
        'main_policies': {p: values['all'][p]['BBO']['3600']['125'] for p in M.POLICIES},
        'source_hashes_before_after_equal': True, 'sources': {str(p): h for p, h in paths.values()},
        'Root_124_138_arithmetic_imported': False, 'raw_CSV_additional2_read': False,
        'bootstrap_reimplemented': False, 'actual_csv_reread_or_render': False,
        'Root_bridge_or_financial_calculator_author': False, 'formal_protocol_author': True,
        'source_conditions_or_parameters_edited': False, 'independent_unknown_period': False,
        'own_code_sha256': {p.name: M.sha(p) for p in (HERE / '検算する.py', HERE / '算術.py')}}
    out = HERE / '独立確認.json'; assert not out.exists()
    out.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, 'proof_SHA256': M.sha(out), '主': proof['main'], '表': table_proof}, ensure_ascii=False))


if __name__ == '__main__':
    main()
