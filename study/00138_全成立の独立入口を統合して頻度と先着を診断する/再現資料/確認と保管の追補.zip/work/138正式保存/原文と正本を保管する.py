"""138のF0/F1原文と最小再現入力を、結果文書の編集前に保管する。"""
from pathlib import Path
import gzip
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
FORMAL = next((ROOT / 'study').glob('00138_*'))
OWN = ROOT / 'work/138全成立入口の評価'


def sha(body: bytes) -> str:
    """
    機能: 原文の指紋を求める。
    引数: body(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


# ----------------------------------------
def put(path: Path, body: bytes) -> None:
    """
    機能: 未作成の保存先へ原文を保存する。
    引数: path(Path)、body(bytes)。
    返り値: None。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as handle:
        handle.write(body)


# ----------------------------------------
def save(source: Path, destination: Path, packed: bool) -> dict:
    """
    機能: 同体又は一度だけgzip保存し復元票を返す。
    引数: source/destination(Path)、packed(bool)。
    返り値: dictは保存元/復元先/サイズ/指紋。
    """
    raw = source.read_bytes(); saved = gzip.compress(raw, mtime=0) if packed else raw
    put(destination, saved)
    return {'保存元': destination.relative_to(ROOT).as_posix(), '復元先': source.relative_to(ROOT).as_posix(),
        '形式': 'gzip' if packed else '同体', '保存bytes': len(saved), '保存SHA256': sha(saved), '解凍bytes': len(raw), '解凍SHA256': sha(raw)}


# ----------------------------------------
def main() -> None:
    """
    機能: 全50F1源と特徴F0を保存し、巨大入力/実行体/既存圧縮は重複しない。
    引数: なし。
    返り値: None。Raw・177MB/77MB入力・追加2場は読まない。
    """
    original = (OWN / 'F1.json').read_bytes(); assert sha(original) == '9a50916835b2e54da4f3f03e4c0ec3f9e2b5d44d3decbe71375b670762d771f1'
    f1 = json.loads(original); assert len(f1['ファイル']) == 50
    f0raw = (OWN / 'F0特徴.json').read_bytes(); f0 = json.loads(f0raw)
    assert len(f0['ファイル']) == 27 and set(f0['ファイル']) <= set(f1['ファイル'])
    for stage, body, value in [('F1',original,f1), ('F0特徴',f0raw,f0)]:
        put(FORMAL / '検査' / (stage + '.json'), body)
        docs = []
        for name, expected in value['ファイル'].items():
            p = Path(name)
            if p.suffix != '.md':
                continue
            b = p.read_bytes(); assert sha(b) == expected
            docs.append({'path':p.relative_to(ROOT).as_posix(),'bytes':len(b),'sha256':expected,'本文':b.decode('utf-8')})
        snap = {'試行':138,'段階':stage+'固定MDの結果編集前原文','原本SHA256':sha(body),'文書数':len(docs),
            '正式文書数':sum(x['path'].startswith('study/') for x in docs),'文書':docs,'金融後に事前固定を偽造':False}
        put(FORMAL / '検査' / ('実行前文書_' + stage + '.json.gz'), gzip.compress((json.dumps(snap,ensure_ascii=False,indent=2)+'\n').encode('utf-8'),mtime=0))
    prior133 = next((ROOT / 'study').glob('00133_*')); oldcode = json.loads((prior133/'保管索引.json').read_bytes())['固定コード']
    codezip = prior133 / '再現資料' / oldcode['ZIP']; assert sha(codezip.read_bytes()) == oldcode['ZIP_SHA256']
    by_sha = {x['sha256']: x['path'] for x in oldcode['格納源']}
    prior137 = next((ROOT / 'study').glob('00137_*')); old137 = json.loads((prior137/'保管索引.json').read_bytes())
    shared_inputs = []
    for p in [ROOT/'inputs/00124_同入口正逆の共用入力/入力.json.gz',
              next((ROOT/'study').glob('00118_*'))/'成果物/全70場の入口結果.json.gz',
              next((ROOT/'study').glob('00128_*'))/'成果物/gap300結果.json.gz',
              next((ROOT/'study').glob('00129_*'))/'成果物/新入口結果.json.gz']:
        b = p.read_bytes(); rel = p.relative_to(ROOT).as_posix()
        shared_inputs.append({'保存元':rel,'復元先':rel,'形式':'同体','保存SHA256':sha(b),'解凍SHA256':sha(b)})
    shared_inputs += [x for x in old137['新金融入力'] if x['復元先'].endswith('/方向と出生.json')]
    shared_inputs += [old137['保存済み正逆観測'],old137['集計正本']]
    new_inputs = []
    input_sources = [OWN/'固定入力_版2'/name for name in ('固定取得入力.json','入口参照.json','特徴照会.json')]
    input_sources += [ROOT/'work/全成立poolの非金融manifest/manifest.json',ROOT/'work/全成立poolの技術条件を整理する/Source558の初期と追加.json',
                     ROOT/'work/頻度研究へ使う既存入口streamの所在/棚卸し.json']
    for source in input_sources:
        new_inputs.append(save(source,ROOT/'inputs/00138_全成立入口の共用入力'/(source.name+'.gz'),True))
    inputs = {x['復元先']:x for x in shared_inputs + new_inputs}
    for item in inputs.values():
        raw = (ROOT/item['保存元']).read_bytes(); assert sha(raw)==item['保存SHA256']
        decoded = gzip.decompress(raw) if item['形式']=='gzip' else raw
        assert sha(decoded)==item['解凍SHA256']
    saved = []; fresh = []; bodies = {}; excluded = []
    for name, expected in f1['ファイル'].items():
        p = Path(name); rel = p.relative_to(ROOT).as_posix()
        if rel=='work/122全場入力/入力.json' or p.suffix=='.exe':
            excluded.append({'path':rel,'bytes':p.stat().st_size,'sha256':expected,'理由':'共用巨大入力/2実行体はコピーせず生成元/固定指紋/別ビルドを参照'})
            continue
        if rel in inputs:
            assert inputs[rel]['解凍SHA256']==expected
            continue
        body = p.read_bytes(); assert len(body)<2_000_000 and sha(body)==expected
        if expected in by_sha:
            saved.append({'ZIP内path':by_sha[expected],'復元先':rel,'bytes':len(body),'sha256':expected})
        else:
            fresh.append({'path':rel,'bytes':len(body),'sha256':expected});bodies[rel]=body
    assert len(excluded)==3 and len(saved)+len(fresh)+len(inputs)==47
    archive = FORMAL/'再現資料/138金融前固定資料.zip';archive.parent.mkdir(exist_ok=True)
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for item in fresh:
            z.writestr(item['path'],bodies[item['path']])
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for item in fresh:assert sha(z.read(item['path']))==item['sha256']
    with zipfile.ZipFile(codezip) as z:
        for item in saved:assert sha(z.read(item['ZIP内path']))==item['sha256']
    observed = save(OWN/'固定取得の正逆観測.json',FORMAL/'成果物/固定取得の正逆観測.json.gz',True)
    features = save(OWN/'全出生の当時特徴.json',ROOT/'inputs/00138_全成立入口の共用入力/全出生の当時特徴.json.gz',True)
    aggregate = save(ROOT/'work/138全成立入口と頻度の集計/集計.json',FORMAL/'成果物/集計.json',False)
    for source,target in [(OWN/'Rootの金融とCSVの確定.json','Rootの金融とCSVの確定.json'),(OWN/'金融段階の完了.json','金融段階の完了.json'),
        (OWN/'正逆観測の完了.json','正逆観測の完了.json'),(OWN/'当時特徴の完了.json','当時特徴の完了.json'),
        (ROOT/'work/138全成立入口と頻度の集計/集計完了.json','集計完了.json'),
        (ROOT/'work/138全成立CSV出力/CSV再読の確認.json','CSV再読の確認.json'),
        (ROOT/'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/138全成立CSV/CSVの確認.json','CSVの確認.json'),
        (ROOT/'work/138独立検算/独立確認.json','独立金融_独立確認.json'),(ROOT/'work/138独立検算/完了.json','独立金融_完了.json')]:
        save(source,FORMAL/'検査'/target,False)
    kernel = [x for x in oldcode['格納源'] if x['path'].startswith('work/133固定取得の正逆評価器/')]
    m = {'試行':138,'段階':'金融前原文/正本保存完了、結果編集前','F1_SHA256':sha(original),'F1直接源':50,
        'F0特徴_SHA256':sha(f0raw),'F0特徴直接源':27,
        '追加固定資料':{'ZIP':archive.name,'ZIP_SHA256':sha(archive.read_bytes()),'ZIP_bytes':archive.stat().st_size,'格納源数':len(fresh),'格納源':fresh},
        '共有固定コード':{'保存元ZIP':codezip.relative_to(ROOT).as_posix(),'ZIP_SHA256':oldcode['ZIP_SHA256'],'格納源数':len(saved),'格納源':saved},
        '共有入力':shared_inputs,'新共用入力':new_inputs,'特徴診断入力':features,'保存済み正逆観測':observed,'集計正本':aggregate,
        '意図して複製しないF1源':excluded,
        '後段再現用の継承源':{'保存元ZIP':codezip.relative_to(ROOT).as_posix(),'ZIP_SHA256':oldcode['ZIP_SHA256'],'格納源数':len(kernel),'格納源':kernel,
            '扱い':'F1はexe指紋を直接固定。133保存源は同体再現用であり138直接F1へ後付け追加したとはしない'},
        '固定入力版':'版2。clock文字列は全origin一致から金融前復元、初回途中版は不採用',
        '巨大入力/原板/実行体の複写':False,'原板/177MB/77MB/追加2場読取':False,'新金融観測':False}
    put(FORMAL/'保管索引.json',(json.dumps(m,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    print(json.dumps({'成功':True,'F1源':50,'復元可能':47,'新ZIP源':len(fresh),'共有源':len(saved),'共有入力':len(shared_inputs),
        '新入力gzip':len(new_inputs)+1,'新ZIP_SHA256':m['追加固定資料']['ZIP_SHA256']},ensure_ascii=False))


if __name__=='__main__':
    main()
