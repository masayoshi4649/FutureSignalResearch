"""Root準備中の139を、本文に触れず4索引へ案内する。"""
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
NAME='00139_全取得を維持して価格位置と別役割で方向を切り替える'


def main() -> None:
    """
    機能: 未実行139の案内を138結果の次へ追加する。
    引数: なし。
    返り値: None。139本文/条件/学習入力/金融結果を読まず変更しない。
    """
    assert (ROOT/'study'/NAME/'README.md').exists()
    for name,prefix in [('README.md','study/'),('study/README.md',''),('docs/README.md','../study/'),('docs/議論/README.md','../../study/')]:
        path=ROOT/name;body=path.read_text('utf-8');assert '[139：' not in body
        head,first,rest=body.split('\n\n',2);assert '[138：' in first
        line=f'[139：価格位置と別役割で方向を切替]({prefix}{NAME}/README.md)は準備中。752全取得を維持し旧81を保護、位置×別役割の28候補を前48場で選択して後25場へ評価する案。自然学習・金融結果は未実行で、138の752/52.33%へ後付けしていない。両期間とも既使用であり未知期検証ではない。'
        path.write_text(head+'\n\n'+first+'\n\n'+line+'\n\n'+rest,encoding='utf-8')


if __name__=='__main__':
    main()
