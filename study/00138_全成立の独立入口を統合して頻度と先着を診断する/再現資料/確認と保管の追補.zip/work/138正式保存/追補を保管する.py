"""138の独立検算・小型依存・原因・閲覧/保管コードを固定源とは別に保存する。"""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[2]
FORMAL=next((ROOT/'study').glob('00138_*'))


def sha(body: bytes) -> str:
    """
    機能: 後発原文の指紋を求める。
    引数: body(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 重複を避けて再現の小型依存と独立/原因コードを保管する。
    引数: なし。
    返り値: None。F0/F1・条件・旧試行・巨大入力を変更しない。
    """
    files=list((ROOT/'work/138正式保存').glob('*.py'))+list((FORMAL/'再現資料').glob('*.py'))
    files += [ROOT/'work/138正式文書を準備する.py',ROOT/'work/138正式文書の準備確認.json']
    groups=[('138独立検算',{'独立確認.json','完了.json','人工ログ.txt'}),
        ('全成立poolの入力型を準備する',set()),
        ('全成立poolの技術条件を整理する',{'Source558の初期と追加.json'}),
        ('頻度研究へ使う既存入口streamの所在',{'棚卸し.json'}),
        ('138当時特徴の独立確認',{'独立確認.json','照合と既知性.json'}),
        ('138全成立入口の原因診断',{'原因診断.json','出生待機と参照時計.json','独立確認.json','完了.json','完了の確認.json'})]
    for folder,skip in groups:
        for p in (ROOT/'work'/folder).iterdir():
            if p.is_file() and p.name not in skip and p.suffix in ('.py','.md','.json','.txt'):
                files.append(p)
    files += [ROOT/'work/138全成立CSV出力'/n for n in ('出力する.mjs','CSVを独立再読する.py','由来.json')]
    fixture=ROOT/'work/全成立poolの当時特徴/実照会schema_test.go.txt'
    if fixture.exists():files.append(fixture)
    mpath=FORMAL/'保管索引.json';m=json.loads(mpath.read_bytes())
    known={x['sha256'] for x in m['追加固定資料']['格納源']}|{x['sha256'] for x in m['共有固定コード']['格納源']}
    known|={x['解凍SHA256'] for x in m['新共用入力']}
    index=[];duplicates=[];archive=FORMAL/'再現資料/確認と保管の追補.zip'
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(set(files)):
            body=p.read_bytes();rel=p.relative_to(ROOT).as_posix();h=sha(body)
            if h in known:
                duplicates.append({'path':rel,'sha256':h,'扱い':'同体は既保存の源/入力を参照'});continue
            z.writestr(rel,body);index.append({'path':rel,'bytes':len(body),'sha256':h,
                '区分':'F1直接リスト外の再現依存、金融前独立検算源、金融後の原因/閲覧/保管を区別して保存'})
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for x in index:assert sha(z.read(x['path']))==x['sha256']
    m['後発資料']={'ZIP':archive.name,'ZIP_SHA256':sha(archive.read_bytes()),'ZIP_bytes':archive.stat().st_size,'格納源数':len(index),'格納源':index,'重複保存しない源':duplicates}
    m['独立金融検算']={'proof':'検査/独立金融_独立確認.json','SHA256':'df44490220483e2cd004b1ddbe84406ae2c6dcb4f4748db2d2260ffb131eb9f8',
        '停止票':'検査/独立金融_完了.json','全180条件':True,'表39685セル':True,'人工8':True,'担当は正式protocol作者':True,'担当はRootbridge/金融集計器作者':False}
    m['間接固定の射影依存']={'path':'work/全成立poolの入力型を準備する/射影する.py','sha256':'b7a7bdc32e29ceef4d4070ad32e8b45c462412a98e8abf7022df3898739c3f9b',
        '扱い':'manifest内で指紋固定された依存。138直接F1へ後付け追加したとはしない。後発ZIPに同体保管'}
    m['段階']='金融・独立算術・CSV・保存観測の再現完了。主52.33%で70未達、752/73・1.043h達成'
    mpath.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'後発源':len(index),'同体を共有参照':len(duplicates),'後発ZIP_SHA256':m['後発資料']['ZIP_SHA256']},ensure_ascii=False))


if __name__=='__main__':
    main()
