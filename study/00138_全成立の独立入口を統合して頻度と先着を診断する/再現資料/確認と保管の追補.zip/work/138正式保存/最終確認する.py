"""138の原文・504セル・入力指紋・独立検算・CSV・再現とリンクを最終確認する。"""
from pathlib import Path
import gzip
import hashlib
import json
import re
import zipfile

ROOT=Path(__file__).resolve().parents[2]
FORMAL=next((ROOT/'study').glob('00138_*'))


def sha(body: bytes) -> str:
    """
    機能: 正式資源の指紋を求める。
    引数: body(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


# ----------------------------------------
def cells(body: str) -> list:
    """
    機能: 版6の56行504セルを順序付きで取り出す。
    引数: body(str)。
    返り値: listはIDと全尺度値。
    """
    result=[]
    for line in body.splitlines():
        if re.match(r'^\| [A-Z]+\d{2} \|',line):
            row=[x.strip() for x in line.strip('|').split('|')]
            if len(row)==11:result.append([row[0],row[2:]])
    assert len(result)==56 and sum(len(x[1]) for x in result)==504
    return result


# ----------------------------------------
def main() -> None:
    """
    機能: 正式138の保存状態を照合して完了票を作る。
    引数: なし。
    返り値: None。Raw/巨大入力/追加2場/新金融へ触れない。
    """
    m=json.loads((FORMAL/'保管索引.json').read_bytes());doc_counts=[]
    for stage,count in [('F1',7),('F0特徴',4)]:
        body=(FORMAL/('検査/'+stage+'.json')).read_bytes();assert sha(body)==m[stage+'_SHA256']
        snapshot=json.loads(gzip.decompress((FORMAL/('検査/実行前文書_'+stage+'.json.gz')).read_bytes()))
        assert snapshot['文書数']==count and snapshot['正式文書数']==3
        for item in snapshot['文書']:assert sha(item['本文'].encode('utf-8'))==item['sha256']
        old=next(x['本文'] for x in snapshot['文書'] if x['path'].endswith('00138_全成立の独立入口を統合して頻度と先着を診断する/設定と結果.md'))
        assert cells(old)==cells((FORMAL/'設定と結果.md').read_text('utf-8'))
        condition=next(x['本文'] for x in snapshot['文書'] if x['path'].endswith('00138_全成立の独立入口を統合して頻度と先着を診断する/条件.md'))
        assert condition.encode('utf-8')==(FORMAL/'条件.md').read_bytes();doc_counts.append(count)
    for key in ('追加固定資料','後発資料'):
        item=m[key];path=FORMAL/'再現資料'/item['ZIP'];assert sha(path.read_bytes())==item['ZIP_SHA256']
        with zipfile.ZipFile(path) as z:
            assert z.testzip() is None
            for record in item['格納源']:assert sha(z.read(record['path']))==record['sha256']
    item=m['共有固定コード'];path=ROOT/item['保存元ZIP'];assert sha(path.read_bytes())==item['ZIP_SHA256']
    with zipfile.ZipFile(path) as z:
        for source in item['格納源']:assert sha(z.read(source['ZIP内path']))==source['sha256']
    for item in m['共有入力']+m['新共用入力']+[m['特徴診断入力'],m['保存済み正逆観測']]:
        body=(ROOT/item['保存元']).read_bytes();assert sha(body)==item['保存SHA256']
        raw=gzip.decompress(body) if item['形式']=='gzip' else body;assert sha(raw)==item['解凍SHA256']
    for item in m['原因と特徴の小資料']:
        raw=(ROOT/item['保存元']).read_bytes();assert sha(raw)==item['保存SHA256']
        if item['形式']=='gzip' if '形式' in item else False:
            assert sha(gzip.decompress(raw))==item['解凍SHA256']
    cause_stop=(FORMAL/'根拠/原因診断/完了の確認.json').read_bytes()
    assert sha(cause_stop)=='ebb912233e11480adfef2e84e4e76be05069f63ae6b2d2b27b4f8fa4573487c9'
    assert sha((FORMAL/'根拠/特徴の独立確認/独立確認.json').read_bytes())=='70ef7555624a7f102fdca5e4de0b4e3cbc2e0c82089509910ae6975c140c06b9'
    aggregate=(FORMAL/'成果物/集計.json').read_bytes();assert sha(aggregate)=='6ef283db667603884b42260affce732ba5c9b31731d24b1bb18f9e96ee4b3486'
    value=json.loads(aggregate);main=value['集計']['all']['P0']['BBO']['3600']['125']
    assert [main[k] for k in ('entries','forward','adverse','neither','censored','ifd_known','ifd_unknown','ifd_net5_profit','ifd_net5_loss','ifd_net5_sum','ifd_net0_sum')]==[752,326,297,76,53,732,20,4217125,4631489,-414364,317636]
    assert value['主評価']['全73場最低1取得'] and value['主評価']['全時間平均1件毎時以上'] and not value['主評価']['到達済み先着70%以上']
    independent=(FORMAL/'検査/独立金融_独立確認.json').read_bytes();assert sha(independent)=='df44490220483e2cd004b1ddbe84406ae2c6dcb4f4748db2d2260ffb131eb9f8'
    stop=json.loads((FORMAL/'検査/独立金融_完了.json').read_bytes());assert stop['編集停止'] and stop['人工成功'] and stop['人工主検査数']==8 and not stop['準備固定からコード変更']
    rootbody=(FORMAL/'検査/Rootの金融とCSVの確定.json').read_bytes();assert sha(rootbody)=='1eab8ca6f15c1ceeaad8099ff895a6eb3a02c85e6d2cdd77a8bbda10787f0951'
    rootproof=json.loads(rootbody);assert rootproof['F1原文前後同体'] and rootproof['三表プレビュー確認'] and rootproof['CSV作成marker']=={'回数':1,'表数':3,'形式':'csv'}
    csv=json.loads((FORMAL/'検査/CSV再読の確認.json').read_bytes());assert csv['全データセル比較数']==39685 and csv['数値比較数']==16951 and csv['前後不変']
    output=ROOT/'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/138全成立CSV'
    for row in csv['表別']:assert sha((output/Path(row['CSV']['path']).name).read_bytes())==row['CSV']['sha256']
    assert not list(output.glob('*.xlsx'))
    replay=json.loads((FORMAL/'検査/保存観測の再現確認.json').read_bytes());assert replay['F1直接47/50源同体'] and replay['全数値/旧対照/phase/頻度一致']
    assert replay['三表全bytes一致_SHA256']=='c8a83240c0345662353af42d5eeafa306bd68a710f53985be01dc0676c5f2f5d'
    mpost=m['後発資料']
    with zipfile.ZipFile(FORMAL/'再現資料'/mpost['ZIP']) as z:
        assert sha(z.read('work/全成立poolの入力型を準備する/射影する.py'))=='b7a7bdc32e29ceef4d4070ad32e8b45c462412a98e8abf7022df3898739c3f9b'
        assert sha(z.read('work/全成立poolの技術条件を整理する/Sourceの種別だけを抽出する.py'))=='59f76d60e4321879a5855ceb33894c7ab7909da1df1fe96278f09935ed3a9796'
    docs=list(FORMAL.rglob('*.md'))+[output/'README.md'];indices=[ROOT/x for x in ('README.md','study/README.md','docs/README.md','docs/議論/README.md')];links=0
    for p in docs+indices:
        body=p.read_text('utf-8')
        if p in indices:
            assert '[138：' in body and '[139：' in body;body='\n\n'.join(body.split('\n\n')[1:3])
        for target in re.findall(r'\]\(([^)]+)\)',body):
            if target.startswith(('https:','http:','#','mailto:')):continue
            dest=(p.parent/target.strip('<>').split('#',1)[0]).resolve();assert dest.exists(),(str(p),target);links+=1
    proof={'成功':True,'試行':138,'正式保存完了':True,'F1/特徴F0全原文MD':doc_counts,'正式原文MD':3,
        '条件と56手法504セル不変':True,'F1直接50源中47源を同体復元':True,'未複写は177MBと2exe':True,
        '入力/manifest/親識別/在庫/特徴の新gzip':7,'原板/177MB/77MB/追加2場読取':False,'新金融/Source/CSV生成':False,
        '独立算術条件':180,'独立表セル':39685,'独立人工':8,'旧C0対照件数/4streamラベル/条件':[81,3240,60],
        'phase':value['全4streamのphase検査'],'実CSVセル/数値':[39685,16951],'Root三プレビュー':True,
        '保存833観測の全数値と三表bytes再現':True,'主P0':main,'頻度':value['頻度']['all']['P0'],
        '全期既使用':True,'目標70未達':True,'4索引':True,'139は準備中リンクのみで本文変更なし':True,'ローカルリンク数':links,'重大不足':[],
        'F1_SHA256':m['F1_SHA256'],'保管索引SHA256':sha((FORMAL/'保管索引.json').read_bytes()),'後発ZIP_SHA256':mpost['ZIP_SHA256'],
        '確認コードSHA256':sha(Path(__file__).read_bytes())}
    out=FORMAL/'検査/正式保存の最終確認.json';assert not out.exists();out.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'最終確認SHA256':sha(out.read_bytes()),'重大不足':[],'ローカルリンク':links},ensure_ascii=False))


if __name__=='__main__':
    main()
