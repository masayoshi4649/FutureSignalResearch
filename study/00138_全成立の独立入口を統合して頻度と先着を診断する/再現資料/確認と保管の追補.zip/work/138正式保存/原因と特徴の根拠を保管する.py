"""138の停止済み原因と特徴確認を正式化し、金融前条件と区別する。"""
from pathlib import Path
import gzip
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
FORMAL=next((ROOT/'study').glob('00138_*'))


def sha(body: bytes) -> str:
    """
    機能: 小型根拠の指紋を求める。
    引数: body(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


# ----------------------------------------
def save(source: Path, target: Path, packed: bool=False) -> dict:
    """
    機能: 停止済み原文を同体又はgzipで保存する。
    引数: source/target(Path)、packed(bool)。
    返り値: dictは原文/保存の指紋と由来。
    """
    raw=source.read_bytes();body=gzip.compress(raw,mtime=0) if packed else raw
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as handle:handle.write(body)
    return {'由来':source.relative_to(ROOT).as_posix(),'保存元':target.relative_to(ROOT).as_posix(),'形式':'gzip' if packed else '同体',
        '保存bytes':len(body),'保存SHA256':sha(body),'解凍bytes':len(raw),'解凍SHA256':sha(raw)}


# ----------------------------------------
def main() -> None:
    """
    機能: 原因診断と非金融特徴確認を、事後の根拠として保存する。
    引数: なし。
    返り値: None。Raw/巨大入力/旧試行/条件を変更しない。
    """
    cause=ROOT/'work/138全成立入口の原因診断';features=ROOT/'work/138当時特徴の独立確認'
    assert sha((cause/'README.md').read_bytes())=='b2731e3dfe8337e89db1b35e28aa17692a87e3776de46de8871c5f23754cbf89'
    assert sha((cause/'完了の確認.json').read_bytes())=='ebb912233e11480adfef2e84e4e76be05069f63ae6b2d2b27b4f8fa4573487c9'
    records=[]
    for source in ('原因診断.json','出生待機と参照時計.json','条件.md','準備の確認.json','完了の確認.json'):
        packed=source.endswith('.json') and source not in ('準備の確認.json','完了の確認.json')
        records.append(save(cause/source,FORMAL/'根拠/原因診断'/(source+'.gz' if packed else source),packed))
    body=(cause/'README.md').read_text('utf-8')
    body=body.replace('](原因診断.json)','](原因診断.json.gz)').replace('](出生待機と参照時計.json)','](出生待機と参照時計.json.gz)')
    body=body.replace('[診断する.py](診断する.py)','[診断する.py（追補ZIP）](../../再現資料/確認と保管の追補.zip)')
    header='保存注記：値・条件は停止済み原文のまま、JSONへのリンクをgzip先へ、コードへのリンクを追補ZIPへ調整した。原文MDもZIPへ保存する。\n\n'
    title,rest=body.split('\n',1)
    target=FORMAL/'根拠/原因診断/README.md';target.write_text(title+'\n\n'+header+rest.lstrip(),encoding='utf-8')
    records.append({'由来':(cause/'README.md').relative_to(ROOT).as_posix(),'保存元':target.relative_to(ROOT).as_posix(),
        '原文SHA256':'b2731e3dfe8337e89db1b35e28aa17692a87e3776de46de8871c5f23754cbf89','保存SHA256':sha(target.read_bytes()),'変更':'保存先リンクとその注記だけ'})
    for name in ('README.md','照合と既知性.json','独立確認.json'):
        records.append(save(features/name,FORMAL/'根拠/特徴の独立確認'/name))
    mpath=FORMAL/'保管索引.json';m=json.loads(mpath.read_bytes());m['原因と特徴の小資料']=records
    prior=json.loads((next((ROOT/'study').glob('00135_*'))/'保管索引.json').read_bytes())
    m['追加の検算用共有参照']=[x for x in prior['新共用入力'] if x['復元先'].endswith('/公表の再生結果.json')]
    m['追加の検算用共有参照'] += [x for x in prior['共有参照'] if x['復元先'].endswith('/全79例の当時特徴.json')]
    assert len(m['追加の検算用共有参照'])==2
    mpath.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    readme=FORMAL/'README.md';text=readme.read_text('utf-8')
    anchor='詳細な事後原因の小資料は、固定結果と分けて扱う。'
    addition='''[停止済みの原因短報](根拠/原因診断/README.md)では、追加671は286順279逆・50.62%/−614,358円。D164追加208は45.18%/−424,939円、短期C1追加31は29.63%/−169,387円で、その実逆も55.56%/＋2,613円に留まった。familyは重複origin群なので行の合計を全体にしない。MA9値全同向98件は57.69%、別役割も加えた順行複合46件は54.76%で、後半は44.44%へ下がった。出生→取得中央値3秒/p95 22秒・当初5分参照の期限跨ぎ6/420であり、待機だけが主因という支持も薄い。これらは事後診断で、138の方向を変更していない。

[特徴の非金融独立確認](根拠/特徴の独立確認/README.md)は769照会/74列、2,289足refs/fresh、850origin対応と、旧79の5,846特徴値・旧124の3,792生指標を照合した。Raw原生背景のknownへ外挿せず、未知を反転シグナルにしない。'''
    assert anchor in text;readme.write_text(text.replace(anchor,addition),encoding='utf-8')
    repro=FORMAL/'再現手順.md';text=repro.read_text('utf-8')
    text+='''

## 停止済みの原因と特徴確認

[原因短報](根拠/原因診断/README.md)、[事後診断の条件](根拠/原因診断/条件.md)、[原因JSONgzip](根拠/原因診断/原因診断.json.gz)、[出生待機/参照時計gzip](根拠/原因診断/出生待機と参照時計.json.gz)、[完了票](根拠/原因診断/完了の確認.json)を保存した。原文MDは追補ZIP、正式本文は保存先リンクだけ調整した。familyは重複群であり合算しない。138の主P0/native・実逆・C0の全主数値は正式集計と同体。診断は凍結138/124算術を再用しており、金融独立検算とは別の作業である。

[特徴の独立確認](根拠/特徴の独立確認/README.md)と[proof](根拠/特徴の独立確認/独立確認.json)は金融未読の非金融確認。旧79全74列と旧124生指標を別Pythonで照合した。`--with-features --with-post`で追加2つの共有参照（135公表再生/124当時特徴）も復元し、保存出力だけの確認を再現できる。元の177MB公表は読まない。

原因の出生時計prepare/evaluateは追補ZIPのコードと条件に従う。入力が置かれた元相対位置を新workに保ち、既存出力を上書きしない。原因で見た全期を未知期とせず、選別規則の学習は139以降へ分ける。139の本文・学習は本試行の再現に含めない。
'''
    repro.write_text(text,encoding='utf-8')
    print(json.dumps({'成功':True,'小型関連資料':len(records),'原因の主交換/条件変更':False},ensure_ascii=False))


if __name__=='__main__':
    main()
