"""金融ラベルなしで769出生の当時特徴と旧79の生特徴を独立照合する。"""
from collections import Counter, defaultdict
from pathlib import Path
import hashlib
import json
import math

OWN = Path(__file__).resolve().parent
ROOT = OWN.parent.parent
FILES = {
    'features': ('work/138全成立入口の評価/全出生の当時特徴.json', 'c2b9b8efeb65ba22b2dac3147fdefa3b513cb5cc61cd69249864065f2fcca6e4'),
    'queries': ('work/138全成立入口の評価/固定入力_版2/特徴照会.json', '81442c3ebaa3065213d0844417bb0462cfa3e5d0a05c4f44edfb3fb14191e75c'),
    'f0': ('work/138全成立入口の評価/F0特徴.json', '250495ac34020adad7dcd0147045064c1995c290effb8b8f16a4298775c56643'),
    'csv79': ('work/同じ79出生における公表差の診断/公表の再生結果.json', '1c034b7b55e9d5e10ed2ca9f25d4ffd5c17d5b187667dd46b69a845e6d4e7b81'),
    'old124': ('work/124当時特徴の診断/全79例の当時特徴.json', 'e4f0bf25156c1fe732b186c5c5d90b6e9f95718985a440d8eb7005588f734774'),
}


# ----------------------------------------
def sha(path: Path) -> str:
    """
    機能: 許可された非金融出力とコードの指紋を得る。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def number(value: dict) -> float | None:
    """
    機能: 既知有限値だけを計算へ渡す。
    引数: value(dict)。返り値: float|None。未知の格納0は使わない。
    """
    if not value['known']:
        return None
    assert type(value['value']) in (int, float) and math.isfinite(value['value'])
    return value['value']


# ----------------------------------------
def ratio(value: float | None, denominator: float | None) -> float | None:
    """
    機能: 既知正の分母だけで正規化する。
    引数: value/denominator(float|None)。返り値: float|None。
    """
    return value / denominator if value is not None and denominator is not None and denominator > 0 else None


# ----------------------------------------
def key(session: str, quote: dict) -> tuple:
    """
    機能: 向きと独立した出生原行キーを作る。
    引数: session(str)、quote(dict)。返り値: tuple。
    """
    return session, *(quote[name] for name in ('time', 'index', 'source_line', 'last'))


# ----------------------------------------
def expected(snapshot: dict, side: int, last: float, names: set) -> dict:
    """
    機能: 旧CSV Snapshotの生値から74特徴をPythonで独立に再計算する。
    引数: snapshot(dict)、side(int)、last(float)、names(set)。返り値: dict[str,float|None]。
    """
    out = dict.fromkeys(names)
    for minute in (5, 15, 30):
        p = snapshot['frames'].get(str(minute * 60))
        if not p or not p['frame']['frame']['price_known']:
            continue
        f = p['frame']['frame']; raw = f['technical']; dmi = p['frame']['dmi']
        t = {name: number(v) for name, v in raw.items()}
        d = {name: number(v) for name, v in dmi.items()}
        prefix = 'm%d_' % minute
        for name, native in (('gap', 'gap'), ('ema8_delta', 'ema8_delta'), ('ema21_delta', 'ema21_delta'), ('hist', 'histogram')):
            v = side * t[native] if t[native] is not None else None
            out[prefix + name + '_to_side'] = v; out[prefix + name + '_atr_to_side'] = ratio(v, t['atr'])
        out[prefix + 'di_difference_to_side'] = side * (d['plus_di'] - d['minus_di']) if d['plus_di'] is not None and d['minus_di'] is not None else None
        out[prefix + 'adx'] = d['adx']
        out[prefix + 'adx_delta'] = d['adx'] - d['previous_adx'] if d['adx'] is not None and d['previous_adx'] is not None else None
        out[prefix + 'rsi_center_to_side'] = side * (t['rsi'] - 50) if t['rsi'] is not None else None
        out[prefix + 'rsi_delta_to_side'] = side * (t['rsi'] - t['previous_rsi']) if t['rsi'] is not None and t['previous_rsi'] is not None else None
        hd = side * (t['histogram'] - t['previous_histogram']) if t['histogram'] is not None and t['previous_histogram'] is not None else None
        out[prefix + 'hist_delta_to_side'] = hd; out[prefix + 'hist_delta_atr_to_side'] = ratio(hd, t['atr'])
        for name in ('ema8', 'ema21'):
            out[prefix + 'price_' + name + '_atr_to_side'] = ratio(side * (last - t[name]) if t[name] is not None else None, t['atr'])
        out[prefix + 'atr'] = t['atr']; out[prefix + 'tr_atr_ratio'] = ratio(t['tr'], t['atr'])
        out[prefix + 'atr_tr_ratio'] = ratio(t['atr'], t['tr']); out[prefix + 'tr_previous_atr_ratio'] = ratio(t['tr'], t['previous_atr'])
        if minute == 5:
            o = f['ohlc']; width = o['high'] - o['low']; body = side * (o['close'] - o['open'])
            out['m5_range'] = width; out['m5_body_to_side'] = body
            if width > 0:
                upper = o['high'] - max(o['open'], o['close']); lower = min(o['open'], o['close']) - o['low']
                out['m5_body_ratio_to_side'] = body / width
                out['m5_forward_wick_ratio'] = (upper if side == 1 else lower) / width
                out['m5_opposite_wick_ratio'] = (lower if side == 1 else upper) / width
                out['m5_close_position_to_side'] = (o['close'] - o['low']) / width if side == 1 else (o['high'] - o['close']) / width
    out['rvol5'] = number(snapshot['rvol5'])
    bb = snapshot['bb15']
    if bb['known']:
        out['bb15_sigma'] = bb['sigma']
        if bb['sigma'] > 0:
            out['bb15_position_sigma_to_side'] = side * (last - bb['mean']) / bb['sigma']
            out['bb15_percent_to_side'] = (last - bb['lower']) / (bb['upper'] - bb['lower']) if side == 1 else 1 - (last - bb['lower']) / (bb['upper'] - bb['lower'])
        frame = snapshot['frames'].get('900')
        if frame and frame['frame']['frame']['price_known']:
            out['bb15_width_atr_ratio'] = ratio(bb['upper'] - bb['lower'], number(frame['frame']['frame']['technical']['atr']))
    assert set(out) == names
    return out


# ----------------------------------------
def main() -> None:
    """
    機能: 769照会の因果/knownと旧79出生の全74列を独立照合して小型証跡を作る。
    引数: なし。返り値: None。金融ラベル・Raw・CSV本文・177MB公表は読まない。
    """
    documents = {}
    for name, (relative, expected_sha) in FILES.items():
        path = ROOT / relative; assert sha(path) == expected_sha
        documents[name] = json.loads(path.read_text('utf-8'))
    new, query_doc, old = documents['features'], documents['queries'], documents['old124']
    assert new['success'] and not new['financial_labels_used'] and not new['entry_prices_used']
    assert new['query_count'] == len(new['rows']) == 769 and new['source_scene_count'] == 73
    assert new['input_sha256'] == '6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec'
    assert new['queries_sha256'] == FILES['queries'][1]
    assert [row['query'] for row in new['rows']] == query_doc['queries']
    names = set(new['catalog']); assert len(names) == 74
    rows = {row['query']['id']: row for row in new['rows']}; assert len(rows) == 769
    known = Counter(); widths = {}; foot_count = 0
    for row in rows.values():
        q = row['query']; assert set(row['values']) == set(row['known_mask']) == names
        for name, v in row['values'].items():
            assert type(v['known']) is bool and row['known_mask'][name] is v['known']
            if v['known']: number(v); known[name] += 1
            else: assert v['value'] is None
        feet = row['feet']; assert set(feet) == {'m5', 'm15', 'm30'}
        refs = {r['width_seconds']: r for r in row['refs']}; assert len(refs) == len(row['refs'])
        for minute in (5, 15, 30):
            p = feet['m%d' % minute]
            if p is None:
                assert minute * 60 not in refs
                assert all(not v['known'] for name, v in row['values'].items() if name.startswith('m%d_' % minute))
                continue
            foot_count += 1; stamp = p['delivered']; ref = refs[minute * 60]
            assert p['width_seconds'] == minute * 60 and p['id'] == ref['id'] and p['end'] == ref['end'] and stamp == ref['delivered']
            assert p['end'] <= p['available_at'] <= p['delivery_at'] <= stamp['time'] <= q['birthQuote']['time']
            assert stamp['index'] <= q['birthQuote']['index'] and stamp['source_line'] <= q['birthQuote']['source_line']
            assert q['birthQuote']['time'] < p['end'] + minute * 60 + 60
            assert p['market_age_seconds'] == q['birthQuote']['time'] - p['end'] and p['delivery_age_seconds'] == q['birthQuote']['time'] - stamp['time']
            if not p['price_known']:
                assert all(not v['known'] for name, v in row['values'].items() if name.startswith('m%d_' % minute))
        if row['values']['bb15_sigma']['known']:
            sigma = row['values']['bb15_sigma']['value']; assert row['flags']['bb15_sigma_zero'] is (sigma == 0)
            assert row['values']['bb15_position_sigma_to_side']['known'] is (sigma > 0)
        else:
            assert row['flags']['bb15_sigma_zero'] is None and not row['values']['bb15_position_sigma_to_side']['known']
        if row['values']['m5_range']['known']:
            span = row['values']['m5_range']['value']; assert row['flags']['m5_range_zero'] is (span == 0)
            if span == 0:
                assert not row['values']['m5_body_ratio_to_side']['known']
            else:
                b = row['values']['m5_body_ratio_to_side']['value']; f = row['values']['m5_forward_wick_ratio']['value']; o = row['values']['m5_opposite_wick_ratio']['value']
                assert math.isclose(abs(b) + f + o, 1, abs_tol=1e-10)
                assert 0 <= row['values']['m5_close_position_to_side']['value'] <= 1
    assert {r['query']['session'] for r in rows.values()}.__len__() == 73
    family_ids = defaultdict(set)
    for relation in query_doc['relations']:
        assert relation['query_id'] in rows and relation['side'] == rows[relation['query_id']]['query']['side']
        family_ids[relation['family']].add(relation['query_id'])
    assert len(query_doc['relations']) == 850

    # ----------------------------------------
    # 出生だけで旧79へ結び、Source旧方向とは別のQuery.sideで生値から射影し直します。
    csv_rows = [r for r in documents['csv79']['rows'] if r['model'] == 'csv']; assert len(csv_rows) == 79
    oldmap = {(r['session'], r['id']): r for r in old['features']}; assert len(oldmap) == 79
    baseline = {r['query_id'] for r in query_doc['relations'] if r['model'] == 'C0'}; assert len(baseline) == 81
    baseline_by_birth = {key(rows[qid]['query']['session'], rows[qid]['query']['birthQuote']): rows[qid] for qid in baseline}
    assert len(baseline_by_birth) == 81
    compared = Counter(); mismatch = []; native_mismatch = []
    native_names = {'ema8': 'ema8', 'ema21': 'ema21', 'gap': 'gap', 'ema8_delta': 'ema8_delta', 'ema21_delta': 'ema21_delta',
                    'atr': 'atr', 'previous_atr': 'previous_atr', 'tr': 'tr', 'rsi': 'rsi', 'previous_rsi': 'previous_rsi',
                    'histogram': 'hist', 'previous_histogram': 'previous_hist', 'plus_di': 'plus_di', 'minus_di': 'minus_di', 'adx': 'adx', 'previous_adx': 'previous_adx'}
    matched = set()
    for previous in csv_rows:
        birth_key = key(previous['session'], previous['quote']); assert birth_key in baseline_by_birth
        current = baseline_by_birth[birth_key]; q = current['query']; snapshot = previous['snapshot']; matched.add(q['id'])
        assert snapshot['asof'] == q['birthQuote'] and snapshot['refs'] == current['refs'] and (snapshot['missing'] or []) == current['missing']
        derived = expected(snapshot, q['side'], q['birthQuote']['last'], names)
        for name, want in derived.items():
            got = number(current['values'][name]); compared['旧79全74列'] += 1
            if (got is None) != (want is None) or got is not None and not math.isclose(got, want, rel_tol=1e-12, abs_tol=1e-9):
                mismatch.append({'id': previous['id'], 'field': name, 'expected': want, 'actual': got})
        original = oldmap[previous['session'], previous['id']]
        assert key(original['session'], original['birth_quote']) == birth_key
        for minute in (5, 15, 30):
            frame = snapshot['frames'].get(str(minute * 60)); numeric = {}
            if frame and frame['frame']['frame']['price_known']:
                numeric = {**frame['frame']['frame']['technical'], **frame['frame']['dmi']}
            for raw_name, feature_name in native_names.items():
                want = number(numeric[raw_name]) if raw_name in numeric else None
                got = number(original['features'][feature_name + '_' + str(minute)])
                compared['旧124の生指標'] += 1
                if (got is None) != (want is None) or got is not None and got != want:
                    native_mismatch.append({'id': previous['id'], 'field': feature_name + '_' + str(minute), 'expected': want, 'actual': got})
    assert len(matched) == 79
    for minute in (5, 15, 30):
        prefix = 'm%d_' % minute; columns = [name for name in names if name.startswith(prefix) and not name.startswith('m5_body') and name not in ('m5_range', 'm5_forward_wick_ratio', 'm5_opposite_wick_ratio', 'm5_close_position_to_side')]
        widths[str(minute)] = {'fresh足あり': sum(r['feet']['m%d' % minute] is not None for r in rows.values()),
                              '価格既知': sum(r['feet']['m%d' % minute] is not None and r['feet']['m%d' % minute]['price_known'] for r in rows.values()),
                              'Gap既知': known[prefix + 'gap_to_side'], 'ADX既知': known[prefix + 'adx'], 'Hist既知': known[prefix + 'hist_to_side'],
                              '基本21列すべて既知': sum(all(r['values'][name]['known'] for name in columns) for r in rows.values())}
    special = {name: {'既知': known[name], '未知': 769 - known[name], '未知率': (769 - known[name]) / 769}
               for name in ('rvol5', 'bb15_sigma', 'bb15_position_sigma_to_side')}
    summary = {'照会数': 769, '対象場': 73, 'relations数': 850, '公表因果を確認した足数': foot_count,
               '幅別known': widths, '量とBB': special, '全列の既知と未知': {name: {'既知': known[name], '未知': 769 - known[name]} for name in sorted(names)},
               'family別unique照会': {family: {'照会': len(ids), 'RVOL未知': sum(not rows[q]['values']['rvol5']['known'] for q in ids),
                                            'BB位置未知': sum(not rows[q]['values']['bb15_position_sigma_to_side']['known'] for q in ids)} for family, ids in sorted(family_ids.items())},
               '旧79照合数': dict(compared), '旧79全74列の差': mismatch, '旧124生指標の差': native_mismatch,
               '旧79の参照と出生同体': True, '旧124原方向でなくQuery方向へ符号射影': True}
    (OWN / '照合と既知性.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    assert not mismatch and not native_mismatch, (mismatch[:3], native_mismatch[:3])
    assert all(sha(ROOT / relative) == h for relative, h in FILES.values())
    proof = {'成功': True, '入力前後SHA256': {relative: h for relative, h in FILES.values()},
             '診断コードSHA256': sha(Path(__file__)), '照合と既知性SHA256': sha(OWN / '照合と既知性.json'),
             '769全列known_nullと配送freshと850結合': True, '旧79全74列同体': True, '旧124生指標同体': True,
             'exporterコードimport又は実行': False, '177MB公表又は新Raw又はCSV本文読取': False,
             '金融ラベル又は先着又は損益読取': False, '追加2場読取': False, '特徴コード変更': False,
             '限界': 'CSV122の診断overlay。128/129原生Raw背景のknownへ外挿しない'}
    target = OWN / '独立確認.json'; target.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'success': True, 'proof_sha256': sha(target), 'old79_checks': dict(compared), 'widths': widths, 'special': special}, ensure_ascii=True))


if __name__ == '__main__':
    main()
