"""既存保存JSONの候補metadataだけを棚卸しし、勝敗・損益・新しい市場を評価しない。"""
from pathlib import Path
from collections import Counter, defaultdict
import gzip
import hashlib
import json
import math

ROOT=Path(__file__).resolve().parents[2]
OWN=Path(__file__).resolve().parent


def sha(body: bytes) -> str:
    """
    機能: 読んだ保存資料の指紋を返す。
    引数: body(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


# ----------------------------------------
def load(path: Path) -> tuple[dict, dict]:
    """
    機能: 明示した小型保存結果だけを読み、ファイルと解凍指紋を返す。
    引数: path(Path)。
    返り値: tuple[dict,dict]はJSONとmetadata。Raw/CSV/177MB入力は対象外。
    """
    assert path.suffix in ('.json','.gz') and path.stat().st_size<10_000_000
    body=path.read_bytes();decoded=gzip.decompress(body) if path.suffix=='.gz' else body
    assert len(decoded)<25_000_000
    return json.loads(decoded),{'path':path.relative_to(ROOT).as_posix(),'bytes':len(body),'sha256':sha(body),
                               'decoded_bytes':len(decoded),'decoded_sha256':sha(decoded)}


# ----------------------------------------
def stamp(value: object) -> tuple | None:
    """
    機能: 保存時刻/index/物理行の存在だけを検査する。
    引数: value(object)。
    返り値: tuple|Noneは三値又は情報不足。価格フィールドを使わない。
    """
    if not isinstance(value,dict):return None
    line=value.get('source_line',value.get('line'))
    values=(value.get('time'),value.get('index'),line)
    if any(type(v) not in (int,float) or not math.isfinite(v) for v in values):return None
    return values


# ----------------------------------------
def policy(c: dict) -> str:
    """
    機能: 実験政策又は技術familyを取得する。
    引数: c(dict)は保存候補。
    返り値: strはpolicy/mode。不足時は不明。
    """
    if 'policy' in c:return c['policy']
    e=c.get('event');return e.get('mode','不明') if isinstance(e,dict) else '不明'


# ----------------------------------------
def birth(c: dict) -> tuple[dict,object]:
    """
    機能: 出生の方向/IDとその原行metadataを読む。
    引数: c(dict)。
    返り値: tuple[dict,object]は識別辞書と出生Stamp候補。
    """
    if isinstance(c.get('birth'),dict):
        b=c['birth'];return b,b.get('quote',b)
    e=c.get('event',{});return e,e.get('at')


# ----------------------------------------
def inventory(label: str, data: dict, source: dict, target: list[str]) -> dict:
    """
    機能: 政策ごとに全出生/要求/取得・方向・場の欠落・時刻保持を数える。
    引数: label(str)、data/source(dict)、target(list[str])は現在73場。
    返り値: dictはmetadataだけの集約。outcomes/価格/金額は参照しない。
    """
    scenes=data['scenes'];sessions=[s['session'] for s in scenes];assert len(set(sessions))==len(sessions)
    groups=defaultdict(list);case_counts=Counter();event_kinds=Counter();all_entries=set();all_entries_side=set();birth_ids=[]
    for s in scenes:
        sid=s['session']
        for e in s.get('events',[]):event_kinds[str(e.get('kind',e.get('policy',e.get('mode','不明'))))]+=1
        for c in s.get('candidates',s.get('births',[])):
            key=policy(c);groups[key].append((sid,c));b,_=birth(c)
            birth_ids.append((sid,b.get('id')))
            q=stamp(c.get('entry'))
            if q is not None:
                all_entries.add((sid,*q));all_entries_side.add((sid,b.get('side'),*q))
        for c in s.get('cases',[]):case_counts[c.get('source_event',{}).get('mode','不明')]+=1
    rows=[]
    for key,items in sorted(groups.items()):
        births=Counter();entries=Counter();bside=Counter();eside=Counter();statuses=Counter();methods=Counter();requests=0
        bstamp=0;rstamp=0;estamp=0;entry_count=0;unique=set()
        for sid,c in items:
            b,q=birth(c);births[sid]+=1;bside[str(b.get('side','不明'))]+=1;statuses[c.get('status','不明')]+=1
            if 'method' in b:methods[b['method']]+=1
            bstamp+=stamp(q) is not None
            if c.get('request') is not None:requests+=1;rstamp+=stamp(c['request']) is not None
            if c.get('entry') is not None:
                entry_count+=1;entries[sid]+=1;eside[str(b.get('side','不明'))]+=1
                st=stamp(c['entry']);estamp+=st is not None
                if st is not None:unique.add((sid,*st))
        rows.append({'種類':key,'出生又は候補':len(items),'要求':requests,'取得':entry_count,'出生方向':dict(bside),'取得方向':dict(eside),
                     '取得した場':len(entries),'自己対象場':len(sessions),'自己対象内min1欠落':[x for x in sessions if not entries[x]],
                     '現73場のうち記録対象外':[x for x in target if x not in sessions],
                     '出生Stamp保持':{'確認':bstamp,'対象':len(items)},'要求Stamp保持':{'確認':rstamp,'対象':requests},
                     '取得Stamp保持':{'確認':estamp,'対象':entry_count},'同policy取得原行ユニーク':len(unique),
                     '場別最大取得':max(entries.values(),default=0),'後段cases内mode件数':case_counts.get(key),
                     'status件数':dict(statuses),'元FAR手法':dict(methods)})
    return {'label':label,'保存資料':source,'対象場':len(sessions),'期間':[min(sessions),max(sessions)],
            '現73場のうち記録対象外':[x for x in target if x not in sessions],
            '候補列':'candidates' if any('candidates' in s for s in scenes) else 'births',
            '全候補数':sum(len(x) for x in groups.values()),'全要求数':sum(x['要求'] for x in rows),'全取得レコード数':sum(x['取得'] for x in rows),
            '全政策union取得原行数':len(all_entries),'全政策union方向付き取得原行数':len(all_entries_side),
            'events種類別':dict(event_kinds),'後段cases件数':sum(case_counts.values()),'後段cases_mode別':dict(case_counts),
            '政策別':rows,'原候補ID集合件数':len(set(birth_ids)),
            '全件性':'candidates/birthsは全保存列。127/128/129のcasesも全取得とIDで突合する。最初1選別は後段集計。政策複製とfamily重複を合算しない'}


# ----------------------------------------
def observations(data: dict) -> dict:
    """
    機能: 全取得のH30/H60観測がどこへ保存されているか、キーとレコード件数だけを確認する。
    引数: data(dict)は保存結果。
    返り値: dictは軸・H・touch/endpoint構造。touch方向/価格/金額/statusの値を評価しない。
    """
    axes=defaultdict(list);fills=set();cases=set()
    direct=any('candidates' in s for s in data['scenes'])
    for s in data['scenes']:
        if direct:
            for c in s['candidates']:
                if c.get('entry') is not None:axes['同方向BBO'].append(c)
        else:
            for b in s['births']:
                if b.get('entry') is not None:fills.add((s['session'],b['event']['id']))
            for c in s['cases']:
                identity=(s['session'],c['source_event']['id']);assert identity not in cases;cases.add(identity)
                for field,label in [('original','同方向BBO'),('reverse','実逆BBO'),('chart_original','同方向Last'),('chart_reverse','実逆Last')]:
                    assert field in c;axes[label].append(c[field])
    if not direct:assert fills==cases
    result={}
    for axis,rows in axes.items():
        hs=Counter();touch_count=0;outcome_keys=Counter();touch_keys=Counter();widths=set();endpoints=0;missing=0;h_pairs=Counter()
        for row in rows:
            values=row.get('outcomes')
            if not isinstance(values,list):missing+=1;continue
            hset=[]
            for o in values:
                h=o.get('seconds');hs[str(h)]+=1;hset.append(h)
                for k in o:outcome_keys[k]+=1
                endpoints+='endpoint' in o
                touches=o.get('touches')
                if isinstance(touches,list):
                    touch_count+=len(touches)
                    for touch in touches:
                        widths.add(touch.get('width'))
                        for k in touch:touch_keys[k]+=1
            h_pairs[str(sorted(hset))]+=1
        assert missing==0 and set(hs)=={'1800','3600'} and all(n==len(rows) for n in hs.values())
        result[axis]={'対象取得レコード':len(rows),'outcomes欠落':missing,'取得ごとのH集合':dict(h_pairs),'H別outcomeレコード数':dict(hs),
                      'touchレコード数':touch_count,'touch幅設定':sorted(widths),'outcomeキー出現数':dict(outcome_keys),
                      'touchキー出現数':dict(touch_keys),'endpointキー保持レコード数':endpoints,
                      '注記':'キーと件数だけ。quote/endpointのnullは未到達/不足等であり、値の方向や損益は判定していない'}
    return {'保存位置':'候補自身outcomes' if direct else '全取得IDと一致するcasesの4軸outcomes',
            '全births取得IDとcasesID同体':None if direct else True,'全births取得数':None if direct else len(fills),
            '全case数':None if direct else len(cases),'先頭1だけの観測ではない':True,'軸':result,
            '不足軸':[] if not direct else ['実逆BBO','同方向Last','実逆Last']}


# ----------------------------------------
def main() -> None:
    """
    機能: 111/118～121/127～129の既存候補在庫を短いJSONとMDへ保存する。
    引数: なし。
    返り値: None。新市場・新金融・137条件を読み書きせず、成績の優劣を付けない。
    """
    assert not (OWN/'完了.json').exists()
    dirs={n:next(p for p in (ROOT/'study').iterdir() if p.name.startswith(f'{n:05}_')) for n in (111,118,119,120,121,127,128,129)}
    specs=[('118 Source558',118,'全70場の入口結果.json.gz'),('119 領域/確認/再試験',119,'全70場の入口結果.json.gz'),
           ('120 1分構造',120,'全70場の入口結果.json.gz'),('121 失速と量',121,'全70場の入口結果.json.gz'),
           ('127 CSV公表 Q/R/S/T',127,'全73場の独立出生結果.json.gz'),('128 Raw即時 Q/R/S/T',128,'gap300結果.json.gz'),
           ('128 Raw60秒遅延 Q/R/S/T',128,'gap300_delay60結果.json.gz'),('129 新C1/C2/C3',129,'新入口結果.json.gz'),
           ('129 旧Q/R/S/Tの区間対照',129,'元出生区間対照結果.json.gz')]
    data={};sources={}
    for label,n,name in specs:data[label],sources[label]=load(dirs[n]/'成果物'/name)
    target=[s['session'] for s in data['127 CSV公表 Q/R/S/T']['scenes']];assert len(target)==73
    records=[inventory(label,data[label],sources[label],target) for label,_,_ in specs]
    for record in records:
        record['保存済み観測の構造']=observations(data[record['label']])
        record['執行区間仕様キー']=data[record['label']].get('execution_phase_rule','専用キーなし。元試行の時計/区間を確認してから再利用する')
    input_specs=[('127 CSV公表 Q/R/S/T','inputs/00127_独立出生/出生イベント_v4.json.gz'),
                 ('128 Raw即時 Q/R/S/T','inputs/00128_Raw価格時計の独立出生/gap300入力.json.gz'),
                 ('128 Raw60秒遅延 Q/R/S/T','inputs/00128_Raw価格時計の独立出生/gap300_delay60入力.json.gz'),
                 ('129 新C1/C2/C3','inputs/00129_短期構造回復/入力.json.gz')]
    checks=[]
    for label,path in input_specs:
        a,info=load(ROOT/path)
        events=[(e['session'],e['id']) for e in a['events']] if 'events' in a else [(s['session'],e['id']) for s in a['scenes'] for e in s['events']]
        rows=[(s['session'],c['event']['id']) for s in data[label]['scenes'] for c in s['births']]
        assert len(events)==len(rows) and set(events)==set(rows)
        checks.append({'label':label,'純出生入力':info,'全入力イベント数':len(events),'結果birthsとの全ID同体':True})
    original,orig_source=load(dirs[111]/'成果物/結果.json')
    selected=[r for r in original['場別'] if r['key']=='S0_C0_D0'];assert len(selected)==70
    counts={k:sum(r[k] for r in selected) for k in ('native_new_signals','native_new_fills','entry_requests','entry_fills')}
    assert set(counts.values())=={558}
    source558=next(r for r in records if r['label']=='118 Source558');m0=next(r for r in source558['政策別'] if r['種類']=='M0')
    assert m0['出生又は候補']==m0['要求']==m0['取得']==558
    origin={'label':'111 FAR元Source','資料':orig_source,'取得元条件':'S0_C0_D0を1条件だけ数える。24保護条件を合計しない',
            '対象場':70,'期間':source558['期間'],'保存metadata件数':counts,'Native参照台帳件数':len(original['Native参照']),
            '全558の直接扱える候補列':'118のM0/birth。method/side/time/index/source_line/request/entryを保持',
            '111個別Native本文':'未読。元の各取得時計と118 M0代用時計の同一性をこの棚卸しでは断定しない',
            'Nativeの場所とSHA':'111成果物/結果.jsonのNative参照70件を参照。重いNativeを再読/複写しない',
            '元通知同体の保存根拠':original['金融側Source対照'], '現73場のうち記録対象外':source558['現73場のうち記録対象外']}
    value={'成功':True,'性質':'候補metadata在庫。勝敗/損益の順位付けなし','基準対象73場':target,'Source111':origin,'保存stream':records,'純出生入力照合':checks,
           '読むフィールド':'session/policy/mode/side/id/method/status/request/entryとStamp。outcomesはキーと件数のみ。touch方向/価格/金額の値や勝敗は集計しない',
           '未読/未実行':{'自然Raw':True,'価格CSV':True,'177MB入力':True,'新金融':True,'追加2場':True,'外部取得':True,'111個別Native本文':True},
           '注意':['119の3取得方式や120/121の条件派生は同じ出生を共有し得る','127 CSV/128即時/遅延/129対照は同familyの別入力/別執行区間で、独立familyとして足さない','127/128/129は全取得IDとcasesが同体で4軸/H30H60の保存観測あり。最初1は後段集計の選別','118〜121は全取得の同方向BBO観測のみ。逆BBO/Lastを1−p等で捏造しない','既存観測を再利用する際も旧時計/ザラバ区間/幅設定/費用/欠測規則を新条件と照合する','70場資料の追加3場は未観測。不参加0とは同一視しない','母集団・同取得原行/重複出生・Source保有依存を新試行で揃えてから頻度を数える'],
           'コードSHA256':sha(Path(__file__).read_bytes())}
    (OWN/'棚卸し.json').write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    lines=['# 頻度研究へ使う既存入口streamの所在','',
           '2026-11-12。既存保存JSONの件数・方向・時刻/index/物理行だけを確認した。勝敗/損益の比較、新しい先着計算、自然Raw/CSV/追加2場の読取はしていない。全パス・ファイル/解凍SHA・方向別/未取得場は[棚卸しJSON](棚卸し.json)。','',
           '111の元FAR Sourceは70場・558通知/558取得（S0_C0_D0）。118 M0は同じ558通知を全保持し、method・side・出生/要求/取得Stampを直接読める。111の各Native本文は再読せず、個別元取得時計とM0代用時計が同一とは断定しない。','',
           '|保存列/政策|出生又は候補|要求|取得|取得場/自己母集団|min1欠落|場内最大取得|','|---|---:|---:|---:|---|---:|---:|']
    for record in records:
        for row in record['政策別']:
            lines.append(f"|{record['label']} / {row['種類']}|{row['出生又は候補']}|{row['要求']}|{row['取得']}|{row['取得した場']}/{row['自己対象場']}|{len(row['自己対象内min1欠落'])}|{row['場別最大取得']}|")
    lines += ['', '127/128/129は**全births・要求・取得**を保存し、全取得IDとcasesのID集合も一致した。最初1を選ぶのは後段集計であり、cases自体は先頭だけではない。純出生入力4系列の全IDとbirths列も一致した。','',
              'これらは全取得について同方向BBO・実逆BBO・同方向Last・実逆Lastの4軸、H30/H60各1outcomeと各5幅touches/endpointキーを保持する。127は全164取得、128即時264/遅延168、129新42/区間対照264の全件。118〜121も取得候補自身に全取得のH30/H60同方向BBO観測があるが、逆BBO/Last軸はない。キー/レコード件数だけを検査し、到達方向・価格・金額は集計していない。','',
              '119/120/121のcandidatesも政策ごとの全候補列で、各行に取得Stampがある。119は領域出生345を3方式へ複製した1035候補であり、3倍の独立出生ではない。policy別時刻保持数はJSONに残す。','',
              '118のM0/L50/L100/L200は同じ通知の取得方式対照。119のzone/confirm/retest、120と121の派生、127/128各時計と129区間対照も重複し得るため、合計で独立した技術family数や頻度を水増ししない。現73場との対象差はJSONの記録対象外リストへ分け、70場外の3場を取得0と断定しない。','',
              '次の候補在庫として全取得の位置情報と保存観測を取り出せる。どれが有利かは未判定。新試行で共通期間・最新ザラバ/新規限界・買売対称条件・同原行重複・Source保有依存を揃え、保存観測の旧時計/幅/費用/欠測規則が使えるか照合する。逆側欠落を1−pで補わず、全場min1と平均概ね1回/時と同幅先着70%を別々に評価する。','',
              '元データ本文は複写しない。再現はこのフォルダの `python -X utf8 棚卸しする.py`（同名出力が無い新作業先）。入力パスは明示した保存成果/小型純出生JSONだけで、全Raw走査・外部取得・137条件変更は行わない。']
    (OWN/'README.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'保存stream':len(records),'政策列':sum(len(r['政策別']) for r in records),'純出生全ID照合':len(checks),'JSON_SHA256':sha((OWN/'棚卸し.json').read_bytes())},ensure_ascii=False))


if __name__=='__main__':
    main()
