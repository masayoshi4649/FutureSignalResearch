"""poolの同Raw統合/競合/固定対照/親対応だけを人工で検査する。"""
import copy
import importlib.util
import unittest
from pathlib import Path

SPEC=importlib.util.spec_from_file_location('非金融manifest',Path(__file__).with_name('作成する.py'))
M=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(M)


def row(sid: str,identity: str,at: int,side: int=1) -> dict:
    """
    機能: 人工の取得metadataを作る。
    引数: sid/identity(str)、at/side(int)は場・ID・原行・向き。
    返り値: dictは金融値を持たない候補。
    """
    return {'id':identity,'session':sid,'contract':'人工','side':side,'variant':'人工',
        'entryQuote':{'time':at,'index':at,'source_line':at+1,'last':100,'bid':99,'ask':101,'quote_ok':True},
        'availability':{'raw_sha_matches_common':True,'entry_before_current_H60_limit':True}}


def fixed() -> tuple[list[dict],dict]:
    """
    機能: 73場81固定候補の人工対照を作る。
    引数: なし。
    返り値: tupleは固定候補と場時計。
    """
    common={f'人工{i:03d}':{'start':0,'end':10000,'force_close':9400} for i in range(73)}
    rows=[row(sid,f'基準{i}',100) for i,sid in enumerate(common)]
    rows += [row(sid,f'基準追加{i}',101) for i,sid in enumerate(list(common)[:8])]
    return rows,common


class Tests(unittest.TestCase):
    """結果やIDで勝者を選ばない統合規則を確認する。"""
    def test_merge_conflict_baseline_and_phase(self) -> None:
        """
        機能: 同向統合・反対待機・基準優先・phase保留を検査する。
        引数: self(Tests)は検査状態。
        返り値: None。
        """
        base,common=fixed();sid=next(iter(common));extra=[row(sid,'同向1',1000),row(sid,'同向2',1000),row(sid,'対立1',1001),row(sid,'対立2',1001,-1),row(sid,'基準と逆',100,-1)]
        late=row(sid,'限界後',6100);late['availability']['entry_before_current_H60_limit']=False;extra.append(late)
        before=copy.deepcopy((base,extra));c,p,d=M.assemble(base,extra,common)
        self.assertEqual(len(c),81);self.assertEqual(len(p),82);self.assertEqual(len(d['opposite_side_wait_groups']),1)
        self.assertEqual(len(d['baseline_kept_despite_other_side']),1);self.assertEqual(len(d['phase_exclusions']),1)
        self.assertEqual((base,extra),before)
        kept=next(x for x in p if x['id']=='基準0');self.assertEqual(kept['side'],1);self.assertEqual(len(kept['origins']),2)
        merged=next(x for x in p if not x['baseline']);self.assertEqual(len(merged['origins']),2);self.assertIsNone(merged['birthQuote'])

    def test_same_raw_price_contradiction(self) -> None:
        """
        機能: 原行同一なのに価格が異なる記録を黙って合体しないことを検査する。
        引数: self(Tests)は検査状態。
        返り値: None。
        """
        b,c=fixed();extra=[row(next(iter(c)),'矛盾',100)];extra[0]['entryQuote']['last']=101
        with self.assertRaises(AssertionError):M.assemble(b,extra,c)

    def test_initial_parent_join(self) -> None:
        """
        機能: 人工558通知を456初期親/102追加へ厳密結合する。
        引数: self(Tests)は検査状態。
        返り値: None。
        """
        rows=[];ledger={'成功':True,'行':[]}
        for i in range(558):
            identity=f'人工{i}';r=row('人工場',identity,i+2);r['family']='FAR/NK225_D164_15';rows.append(r)
            kind='initial' if i<353 else 'delayed_initial' if i<456 else 'source_add';parent=i if i<456 else i-456
            ledger['行'].append({'session':'人工場','method':'NK225_D164_15','id':identity,
                'source_paper_hold':{'kind':kind,'parent':f'親{parent}','source_id':f'源{parent}','entry_id':identity},
                'source_paper_entry_fill':{'signal_id':identity,'hold_id':identity+'-玉','time':i,'stamp':{'time':i,'index':i,'source_line':i+1}}})
        initial,added,audit=M.attach_initial(rows,ledger)
        self.assertEqual(len(initial),456);self.assertEqual(len(added),102);self.assertEqual(audit['initial_parent_count'],456)
        self.assertEqual(audit['source_fill_stamp_equals_M0_proxy_entry'],0)
        ledger['行'][0]['source_paper_entry_fill']['signal_id']='誤ID'
        with self.assertRaises(AssertionError):M.attach_initial(rows,ledger)

    def test_frequency_and_min1(self) -> None:
        """
        機能: 未取得場を残し全時間加重頻度を計算することを検査する。
        引数: self(Tests)は検査状態。
        返り値: None。
        """
        rows,common=fixed();f=M.frequencies(rows,common)
        self.assertTrue(f['all_sessions_min1']);self.assertEqual(f['filled_sessions'],73)
        f=M.frequencies(rows[:1],common);self.assertFalse(f['all_sessions_min1']);self.assertEqual(f['scene_distribution']['zero_entry_sessions'],72)


if __name__=='__main__':unittest.main(verbosity=2)
