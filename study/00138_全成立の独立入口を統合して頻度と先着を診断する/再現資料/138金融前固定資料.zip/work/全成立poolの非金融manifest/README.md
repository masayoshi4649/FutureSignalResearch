# 全成立poolの非金融manifest

2026-11-12。[条件.md](条件.md)をmetadata計算より先に保存し、poolの優先・初期限定・phase・重複/競合を固定した。先着/損益・自然Raw/CSV・追加2場は未読で、旧137・正式・凍結射影コードを変更していない。

P0は752件/全73場、全時間720.9167時間に対して1.0431164件/時となった。全場min1は達成、各場1件/時以上は40/73場。場別頻度は最小0.154839・中央値1.012048・最大2.891566件/時であり、「全場が毎時1件」という意味ではない。C0旧81件の方向・取得時計は不変更、頻度0.112356953件/時である。これは金融前の件数であり、70%先着率や利益はまだ未検証。

素材は固定81＋初期系456＋Raw即時264＋129新42＝843。初期系はinitial353・delayed_initial103で、source_add102は主へ追加しない。phase除外は初期系35・即時28・129新9＝72、残り771 originsから同方向/固定対照の重複17件を統合、反対side競合1群2件を待機として752件にした。原板/限月差の除外0、baselineと反対方向の群0。全originsを残すので統合後も出典を失わない。

M0全558を(session,canonical method,id)で台帳へ厳密結合し、初期親456を確認した。統合後に表れる初期親は420。Source元約定StampとM0市場代用entryの3項が同じなのは8件、550件は異なる。元Sourceのfillを研究側M0取得と同一時刻とせず、IDと親の対応として両方を保持する。初期数量やIDを確信度として使っていない。元Source保有に依存した通知である点も残す。

`manifest.json` のC0は旧137A0全81、P0は統合752。各canonicalはid/session/contract/side/entryQuote/baseline/originsを持つ。新canonical IDは取得原行の内容hashから作り、IDで勝者を選ばない。baselineは既存selected_side、他は保存元sideであり、R0の実BBO観測は後段F1以後に行う。

複数originsは出生時刻が異なり得るため、canonical.birthQuoteはnull、代表出生を未選択とした。特徴Queryはcanonicalごとに各originを展開し、`origin.birthQuote`と`origin.source_file_sha`/`source_locator`を使う。Queryのnative sideはcanonical.sideを使い、origin.side/source_sideも由来として保持する。現データでは保持群のsideは一致しているが、baseline優先規則は反対originがあってもbaselineを変えない。出生や特徴時点を最も有利なoriginへ選び直さない。

originsのsource_file_shaは圧縮保存ファイル等の実bytes SHA、source_locatorは元ファイルのscene/candidatesまたはbirths添字、固定137はmetadata.entries添字。raw_refは元原板path/SHAであり、Raw本文の複写ではない。既にmanifestにbirth/entryの保存Quoteがあるため、特徴用に旧価格本文を再複写せず、この参照を再利用できる。FARのposition_originには台帳SHA・join key・親・元fillが加わる。単一canonicalの金融観測時点はentryQuoteで、各originの技術特徴時点はそれぞれのbirthQuoteと分ける。

再現は `python work/全成立poolの非金融manifest/作成する.py`（未作成出力先のみ）、人工は同フォルダの人工検査.py。4群で同方向統合/反対待機/baseline優先/phase、同Raw価格矛盾、558親joinと誤ID拒否、全場分母を確認する。`概要.json`は小型の件数/分布、manifestはoriginsと全除外理由を持つ。大入力本文・outcomes・Native本文はコピーしていない。
