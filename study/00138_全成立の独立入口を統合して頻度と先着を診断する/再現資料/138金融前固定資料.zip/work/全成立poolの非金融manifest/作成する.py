"""固定条件から親/取得metadataだけを統合する。原板・CSV・先着/損益は読まない。"""
import copy
import hashlib
import importlib.util
import json
from collections import Counter,defaultdict
from fractions import Fraction
from pathlib import Path
from statistics import median

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
PROJECTOR=ROOT/'work/全成立poolの入力型を準備する/射影する.py'
PROJECTOR_SHA='b7a7bdc32e29ceef4d4070ad32e8b45c462412a98e8abf7022df3898739c3f9b'
LEDGER=ROOT/'work/全成立poolの技術条件を整理する/Source558の初期と追加.json'
LEDGER_SHA='654476d552a4fd4ac9737219703627eb2ff0b4b5e5e912b2d2521ecca36e34ad'
PRICE_KEYS=('time','index','source_line','last','bid','ask','quote_ok')


def sha(data: bytes) -> str:
    """
    機能: 指紋を求める。
    引数: data(bytes)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(data).hexdigest()


def canonical_method(method: str) -> str:
    """
    機能: 保存台帳と同じ3手法の正規名を確認する。
    引数: method(str)は元method。
    返り値: strは正規名。未知aliasを推測しない。
    """
    assert method in ('NK225_D164_15','NK225_P164_06','NK225_U165_03')
    return method


def point(row: dict) -> tuple:
    """
    機能: 同一取得原行の群キーを作る。
    引数: row(dict)は候補metadata。
    返り値: tupleは場/限月/time/index/物理行。
    """
    q=row['entryQuote']
    return row['session'],row['contract'],q['time'],q['index'],q['source_line']


def attach_initial(rows: list[dict],ledger: dict) -> tuple[list[dict],list[dict],dict]:
    """
    機能: M0全558通知を元親台帳へ結合し、初期系だけを候補へ残す。
    引数: rows(list[dict])、ledger(dict)は全M0とSource識別台帳。
    返り値: tupleは初期系456・除外追加102・親対応の検査。
    """
    index={(r['session'],canonical_method(r['method']),r['id']):r for r in ledger['行']}
    assert ledger['成功'] and len(index)==len(ledger['行'])==len(rows)==558
    parents=set();initial=[];added=[];seen=set();kinds=Counter();source_fill_equals_proxy=0
    for original in rows:
        method=canonical_method(original['family'].split('/',1)[1]);key=original['session'],method,original['id']
        assert key in index and key not in seen;seen.add(key);source=index[key]
        h,f=source['source_paper_hold'],source['source_paper_entry_fill'];kind=h['kind'];kinds[kind]+=1
        assert h['entry_id']==f['signal_id']==original['id'] and f['hold_id']==original['id']+'-玉'
        assert f['stamp']['time']==f['time'] and h['parent'] and h['source_id']
        r=copy.deepcopy(original);parent=[r['session'],method,h['parent']]
        r['position_origin']={'known':True,'initial_or_add':kind,'parent_key':parent,'source_hold':copy.deepcopy(h),
            'source_entry_fill':copy.deepcopy(f),'ledger_sha256':LEDGER_SHA,'ledger_join_key':list(key),
            'research_execution':'118 M0の1秒後市場取得代用。元Source約定と同時計とはしない'}
        q=r['entryQuote'];source_fill_equals_proxy+=all(f['stamp'][k]==q[k] for k in ('time','index','source_line'))
        if kind in ('initial','delayed_initial'):
            assert tuple(parent) not in parents;parents.add(tuple(parent));initial.append(r)
        else:assert kind=='source_add';r['exclusion_reason']='source_addを主poolへ追加しない';added.append(r)
    assert seen==set(index) and kinds==Counter({'initial':353,'delayed_initial':103,'source_add':102})
    assert len(initial)==len(parents)==456 and len(added)==102
    return initial,added,{'joined_notifications':558,'kind_counts':dict(kinds),'all_parents':456,'initial_parent_count':456,
        'source_fill_stamp_equals_M0_proxy_entry':source_fill_equals_proxy,'source_fill_stamp_differs_M0_proxy_entry':558-source_fill_equals_proxy,
        'join_keys':['session','canonical method','id'],'IDs_or_initial_quantity_used_as_confidence':False}


def core(row: dict,baseline: bool=False) -> dict:
    """
    機能: 取得の同一性だけからcanonical候補の核を作る。
    引数: row(dict)、baseline(bool)は一致確認済み候補と固定対照区分。
    返り値: dictは単一出生を捏造しない取得候補。
    """
    key=point(row)
    identity=row['id'] if baseline else 'pool/'+sha(json.dumps(key,ensure_ascii=False,separators=(',',':')).encode('utf-8'))[:24]
    q=copy.deepcopy(row['entryQuote']) if baseline else {k:row['entryQuote'][k] for k in PRICE_KEYS}
    return {'id':identity,'session':row['session'],'contract':row['contract'],'side':row['side'],'entryQuote':q,
        'baseline':baseline,'birthQuote':None,'birth_clock_policy':'各originの出生を保持。単一代表出生は未選択'}


def assemble(baseline: list[dict],extra: list[dict],common: dict) -> tuple[list[dict],list[dict],dict]:
    """
    機能: baseline優先・同side統合・反対side待機の固定規則だけでmanifestを作る。
    引数: baseline/extra(list[dict])、common(dict)は固定81・初期系等・全73場。
    返り値: tupleはC0/P0候補と除外/統合記録。
    """
    assert len(baseline)==81 and len({r['session'] for r in baseline})==73
    assert len({point(r) for r in baseline})==81
    groups=defaultdict(list);excluded=[];phase_counts=Counter();scope_counts=Counter()
    for r in baseline:
        assert r['contract'] is not None and r['availability']['raw_sha_matches_common'] and r['availability']['entry_before_current_H60_limit']
        groups[point(r)].append((True,r))
    for r in extra:
        reason=None
        if r['contract'] is None or not r['availability']['raw_sha_matches_common']:reason='共用73場の原板/限月不一致';scope_counts[r['variant']]+=1
        elif not r['availability']['entry_before_current_H60_limit']:reason='H60新規限界以降';phase_counts[r['variant']]+=1
        if reason:excluded.append({'reason':reason,'origin':r});continue
        groups[point(r)].append((False,r))
    c0=[];p0=[];duplicates=[];conflicts=[];baseline_conflicts=[]
    for key,items in groups.items():
        origins=[r for _,r in items];reference=origins[0]['entryQuote']
        assert all(all(r['entryQuote'][k]==reference[k] for k in PRICE_KEYS) for r in origins),'同原行の価格/正常性が矛盾'
        fixed=[r for isbase,r in items if isbase]
        if fixed:
            assert len(fixed)==1
            c=core(fixed[0],True);c['origins']=[copy.deepcopy(fixed[0])];c0.append(c)
            p=core(fixed[0],True);p['origins']=copy.deepcopy(origins);p0.append(p)
            if any(r['side']!=fixed[0]['side'] for r in origins):baseline_conflicts.append({'group':list(key),'retained_baseline_id':c['id'],'origins':copy.deepcopy(origins)})
        elif len({r['side'] for r in origins})==1:
            p=core(origins[0]);p['origins']=copy.deepcopy(origins);p0.append(p)
        else:
            conflicts.append({'group':list(key),'reason':'反対side競合・待機','origins':copy.deepcopy(origins)});continue
        if len(origins)>1:duplicates.append({'group':list(key),'origin_count':len(origins),'retained_id':p['id'],'baseline_priority':bool(fixed)})
    order={sid:i for i,sid in enumerate(common)}
    sorter=lambda r:(order[r['session']],r['entryQuote']['time'],r['entryQuote']['index'],r['entryQuote']['source_line'])
    c0.sort(key=sorter);p0.sort(key=sorter)
    assert len(c0)==81 and len({point(r) for r in p0})==len(p0)
    pmap={r['id']:r for r in p0}
    for r in c0:
        for field in ('id','session','contract','side','entryQuote','baseline'):assert r[field]==pmap[r['id']][field]
    assert all(any(r['session']==sid for r in p0) for sid in common)
    detail={'phase_exclusions':excluded,'phase_counts':dict(phase_counts),'scope_mismatch_counts':dict(scope_counts),
        'merged_groups':duplicates,'opposite_side_wait_groups':conflicts,'baseline_kept_despite_other_side':baseline_conflicts,
        'eligible_origin_count':sum(len(v) for v in groups.values()),'same_direction_or_baseline_merged_extra_origins':sum(d['origin_count']-1 for d in duplicates),
        'opposite_wait_origins':sum(len(g['origins']) for g in conflicts)}
    return c0,p0,detail


def frequencies(rows: list[dict],common: dict) -> dict:
    """
    機能: 全73場ザラバ時計の加重頻度と場別分布を計算する。
    引数: rows(list[dict])、common(dict)はcanonical候補と全場。
    返り値: dictは金融前の件数・頻度・min1。
    """
    counts=Counter(r['session'] for r in rows);rates=[];scene_rows=[];total=Fraction(0);entry_total=Fraction(0)
    for sid,s in common.items():
        hours=Fraction(s['end']-300-s['start'])/3600;entry=Fraction(min(s['force_close'],s['end']-3900)-s['start'])/3600
        assert hours>0 and entry>0;total+=hours;entry_total+=entry;rate=counts[sid]/hours;rates.append(rate)
        scene_rows.append({'session':sid,'entries':counts[sid],'full_hours':float(hours),'nominal_entry_hours':float(entry),
            'entries_per_full_hour':float(rate),'min1':counts[sid]>=1})
    return {'entry_count':len(rows),'target_sessions':73,'filled_sessions':sum(v['min1'] for v in scene_rows),
        'all_sessions_min1':all(v['min1'] for v in scene_rows),'full_hours':float(total),'nominal_entry_hours':float(entry_total),
        'weighted_entries_per_full_hour':float(len(rows)/total),'weighted_entries_per_nominal_entry_hour':float(len(rows)/entry_total),
        'weighted_at_least_one_per_hour':len(rows)>=total,'scene_distribution':{'min':float(min(rates)),'median':float(median(rates)),
            'max':float(max(rates)),'zero_entry_sessions':sum(v==0 for v in rates),'at_least_one_per_hour_sessions':sum(v>=1 for v in rates)},
        'scenes':scene_rows}


def main() -> None:
    """
    機能: 固定条件MDと既存metadataからだけ非金融manifestを保存する。
    引数: なし。元本文や金融ラベルは複写しない。
    返り値: None。C0/P0と全除外理由を未作成先へ保存する。
    """
    assert sha(PROJECTOR.read_bytes())==PROJECTOR_SHA
    spec=importlib.util.spec_from_file_location('固定射影',PROJECTOR);p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
    p.variant_check(['far_m0','v4_raw_immediate','short_129','fixed137_A0'])
    inv,isrc=p.load(p.INVENTORY);base,bsrc=p.load(p.COMMON,decoded_expected=p.COMMON_SHA);common={s['session']:s for s in base['scenes']}
    sources={isrc['path']:isrc['sha256'],bsrc['path']:bsrc['sha256']};materials={}
    for label in ('118 Source558','128 Raw即時 Q/R/S/T','129 新C1/C2/C3'):
        file=next(r for r in inv['保存stream'] if r['label']==label)['保存資料'];data,source=p.load(ROOT/file['path'],file['sha256'],file['decoded_sha256'])
        rows,_=p.project(label,data,source,common);materials[rows[0]['variant']]=rows;sources[source['path']]=source['sha256']
    data,basesrc=p.load(p.BASELINE,p.BASELINE_SHA);fixed,_=p.baseline(data,basesrc,common);sources[basesrc['path']]=basesrc['sha256']
    ledger,lsrc=p.load(LEDGER,LEDGER_SHA);sources[lsrc['path']]=lsrc['sha256']
    initial,added,parent_audit=attach_initial(materials['far_m0'],ledger)
    c0,p0,detail=assemble(fixed,initial+materials['v4_raw_immediate']+materials['short_129'],common)
    counts={'fixed137_A0':81,'far_M0_all':558,'far_initial_or_delayed':456,'source_add_excluded':102,'v4_raw_immediate':264,'short_129':42}
    represented={tuple(o['position_origin']['parent_key']) for r in p0 for o in r['origins'] if o['variant']=='far_m0'}
    parent_audit['represented_initial_parents']=len(represented)
    assert all(sha((ROOT/n).read_bytes())==h for n,h in sources.items())
    manifest={'success':True,'financial_labels_used':False,'new_trial_assigned':False,'policy_native':'P0','policy_control':'C0',
        'spec_sha256':sha((HERE/'条件.md').read_bytes()),'code_sha256':sha(Path(__file__).read_bytes()),'projector_sha256':PROJECTOR_SHA,'sources':sources,
        'material_counts':counts,'parent_audit':parent_audit,'C0':c0,'P0':p0,'source_add_excluded':added,'integration':detail,
        'frequency':{'C0':frequencies(c0,common),'P0':frequencies(p0,common)},
        'alternatives_not_added':['127 CSV','128 Raw遅延60秒','129旧264対照'],'raw_CSV_financial_additional2_read':False,
        'large_source_inputs_copied':False,'source_position_dependency':'FAR通知は元保有条件依存。独立1mini候補であり実口座利益ではない',
        'feature_query_policy':'複数originsの出生は全て保持。canonicalの単一出生/特徴時点はまだ選ばない'}
    target=HERE/'manifest.json';assert not target.exists();target.write_text(json.dumps(manifest,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    short={'success':True,'manifest_sha256':sha(target.read_bytes()),'material_counts':counts,'parent_audit':parent_audit,
        'phase_counts':detail['phase_counts'],'scope_mismatches':detail['scope_mismatch_counts'],'merged_groups':len(detail['merged_groups']),
        'merged_extra_origins':detail['same_direction_or_baseline_merged_extra_origins'],'opposite_wait_groups':len(detail['opposite_side_wait_groups']),
        'opposite_wait_origins':detail['opposite_wait_origins'],'baseline_other_side_groups':len(detail['baseline_kept_despite_other_side']),
        'frequency':{k:{name:v for name,v in freq.items() if name!='scenes'} for k,freq in manifest['frequency'].items()}}
    path=HERE/'概要.json';assert not path.exists();path.write_text(json.dumps(short,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(short,ensure_ascii=False))


if __name__=='__main__':main()
