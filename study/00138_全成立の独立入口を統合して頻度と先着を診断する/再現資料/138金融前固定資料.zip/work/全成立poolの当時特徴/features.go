package main

import (
	"fmt"
	"math"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// ----------------------------------------
// number は既知有限値だけを保持し、未知をnullへ変換します。
//
// 引数: known(bool)、v(float64)。返り値: Valueです。
func number(known bool, v float64) Value {
	if !known || math.IsNaN(v) || math.IsInf(v, 0) {
		return Value{}
	}
	return Value{Known: true, Value: &v}
}

// ----------------------------------------
// normalize は分母が既知正の場合だけ比率を計算します。
//
// 引数: known(bool)、v(float64)、denominator(rules.Value)。返り値: Valueです。
func normalize(known bool, v float64, denominator rules.Value) Value {
	if !known || !denominator.Known || denominator.Value <= 0 {
		return Value{}
	}
	return number(true, v/denominator.Value)
}

// ----------------------------------------
// catalog は方向・強度・勢い・値幅・量・構造の意味を全列で固定します。
//
// 引数: なし。返り値: map[string]Definitionです。価格尺度だけを各足ATRで正規化します。
func catalog() map[string]Definition {
	out := map[string]Definition{}
	base := map[string]Definition{
		"gap_to_side":             {"方向", "pt", "s*Gap"},
		"gap_atr_to_side":         {"方向", "ATR比", "s*Gap/ATR"},
		"ema8_delta_to_side":      {"方向", "pt", "s*EMA8増分"},
		"ema8_delta_atr_to_side":  {"方向", "ATR比", "s*EMA8増分/ATR"},
		"ema21_delta_to_side":     {"方向", "pt", "s*EMA21増分"},
		"ema21_delta_atr_to_side": {"方向", "ATR比", "s*EMA21増分/ATR"},
		"di_difference_to_side":   {"方向", "指標pt", "s*(PlusDI-MinusDI)"},
		"adx":                     {"強度", "指標pt", "ADX。売買方向を掛けない"},
		"adx_delta":               {"強度", "指標pt", "ADX-前ADX。売買方向を掛けない"},
		"rsi_center_to_side":      {"勢い", "指標pt", "s*(RSI-50)"},
		"rsi_delta_to_side":       {"勢い", "指標pt", "s*(RSI-前RSI)"},
		"hist_to_side":            {"勢い", "pt", "s*Hist"},
		"hist_atr_to_side":        {"勢い", "ATR比", "s*Hist/ATR"},
		"hist_delta_to_side":      {"勢い", "pt", "s*(Hist-前Hist)"},
		"hist_delta_atr_to_side":  {"勢い", "ATR比", "s*(Hist-前Hist)/ATR"},
		"price_ema8_atr_to_side":  {"構造", "ATR比", "s*(出生Last-EMA8)/ATR"},
		"price_ema21_atr_to_side": {"構造", "ATR比", "s*(出生Last-EMA21)/ATR"},
		"atr":                     {"値幅", "pt", "ATR"},
		"tr_atr_ratio":            {"値幅", "比", "TR/ATR"},
		"atr_tr_ratio":            {"値幅", "比", "ATR/TR。TR=0なら未知"},
		"tr_previous_atr_ratio":   {"値幅", "比", "TR/前ATR"},
	}
	for _, minute := range []int{5, 15, 30} {
		for name, def := range base {
			out[fmt.Sprintf("m%d_%s", minute, name)] = def
		}
	}
	for name, def := range map[string]Definition{
		"m5_range":                    {"構造", "pt", "High-Low"},
		"m5_body_to_side":             {"構造", "pt", "s*(Close-Open)"},
		"m5_body_ratio_to_side":       {"構造", "比", "s*(Close-Open)/(High-Low)"},
		"m5_forward_wick_ratio":       {"構造", "比", "買は上ヒゲ、売は下ヒゲを足幅で割る"},
		"m5_opposite_wick_ratio":      {"構造", "比", "買は下ヒゲ、売は上ヒゲを足幅で割る"},
		"m5_close_position_to_side":   {"構造", "比", "買は(Close-Low)/足幅、売は(High-Close)/足幅"},
		"rvol5":                       {"量", "比", "118Bankの当5分量/前20公表平均量"},
		"bb15_sigma":                  {"値幅", "pt", "118Bankの当公表を含む20終値の母標準偏差"},
		"bb15_position_sigma_to_side": {"構造", "σ比", "s*(出生Last-BB15中心)/sigma"},
		"bb15_percent_to_side":        {"構造", "比", "買percentB、売1-percentB"},
		"bb15_width_atr_ratio":        {"値幅", "ATR比", "BB15幅/ATR15"},
	} {
		out[name] = def
	}
	return out
}

// ----------------------------------------
// features は当時Snapshotを出生方向へ射影し、未知maskと当場fresh足を保存します。
//
// 引数: query(Query)、snapshot(rules.Snapshot)。返り値: Rowです。
func features(query Query, snapshot rules.Snapshot) Row {
	r := Row{Query: query, Values: map[string]Value{}, KnownMask: map[string]bool{}, Feet: map[string]*Foot{},
		Refs: append([]rules.Ref{}, snapshot.Refs...), Missing: append([]string{}, snapshot.Missing...),
		Flags: map[string]*bool{"m5_range_zero": nil, "bb15_sigma_zero": nil}}
	for name := range catalog() {
		r.Values[name] = Value{}
	}
	s := float64(query.Side)
	for _, width := range []int{300, 900, 1800} {
		key := fmt.Sprintf("m%d", width/60)
		p, present := snapshot.Frames[width]
		r.Feet[key] = nil
		if !present {
			continue
		}
		f := p.Frame.Frame
		r.Feet[key] = &Foot{f.ID, width, f.End, f.AvailableAt, f.DeliveryAt, p.Stamp, f.PriceKnown, f.VolumeKnown,
			query.BirthQuote.Time - f.End, query.BirthQuote.Time - p.Stamp.Time}
		if !f.PriceKnown {
			continue
		}
		t, d := f.Technical, p.Frame.DMI
		set := func(name string, value Value) { r.Values[key+"_"+name] = value }
		for _, item := range []struct {
			name string
			role rules.Value
		}{
			{"gap", t.Gap}, {"ema8_delta", t.EMA8Delta}, {"ema21_delta", t.EMA21Delta}, {"hist", t.Histogram},
		} {
			set(item.name+"_to_side", number(item.role.Known, s*item.role.Value))
			set(item.name+"_atr_to_side", normalize(item.role.Known, s*item.role.Value, t.ATR))
		}
		set("di_difference_to_side", number(d.PlusDI.Known && d.MinusDI.Known, s*(d.PlusDI.Value-d.MinusDI.Value)))
		set("adx", number(d.ADX.Known, d.ADX.Value))
		set("adx_delta", number(d.ADX.Known && d.PreviousADX.Known, d.ADX.Value-d.PreviousADX.Value))
		set("rsi_center_to_side", number(t.RSI.Known, s*(t.RSI.Value-50)))
		set("rsi_delta_to_side", number(t.RSI.Known && t.PreviousRSI.Known, s*(t.RSI.Value-t.PreviousRSI.Value)))
		hk := t.Histogram.Known && t.PreviousHistogram.Known
		hd := s * (t.Histogram.Value - t.PreviousHistogram.Value)
		set("hist_delta_to_side", number(hk, hd))
		set("hist_delta_atr_to_side", normalize(hk, hd, t.ATR))
		set("price_ema8_atr_to_side", normalize(t.EMA8.Known, s*(query.BirthQuote.Last-t.EMA8.Value), t.ATR))
		set("price_ema21_atr_to_side", normalize(t.EMA21.Known, s*(query.BirthQuote.Last-t.EMA21.Value), t.ATR))
		set("atr", number(t.ATR.Known, t.ATR.Value))
		set("tr_atr_ratio", normalize(t.TR.Known, t.TR.Value, t.ATR))
		set("atr_tr_ratio", normalize(t.ATR.Known, t.ATR.Value, t.TR))
		set("tr_previous_atr_ratio", normalize(t.TR.Known, t.TR.Value, t.PreviousATR))
		if width == 300 {
			o := f.OHLC
			span := o.High - o.Low
			zero := span == 0
			r.Flags["m5_range_zero"] = &zero
			r.Values["m5_range"] = number(true, span)
			r.Values["m5_body_to_side"] = number(true, s*(o.Close-o.Open))
			if span > 0 {
				forward, opposite := o.High-math.Max(o.Open, o.Close), math.Min(o.Open, o.Close)-o.Low
				position := (o.Close - o.Low) / span
				if query.Side < 0 {
					forward, opposite = opposite, forward
					position = 1 - position
				}
				r.Values["m5_body_ratio_to_side"] = number(true, s*(o.Close-o.Open)/span)
				r.Values["m5_forward_wick_ratio"] = number(true, forward/span)
				r.Values["m5_opposite_wick_ratio"] = number(true, opposite/span)
				r.Values["m5_close_position_to_side"] = number(true, position)
			}
		}
	}
	r.Values["rvol5"] = number(snapshot.RVOL5.Known, snapshot.RVOL5.Value)
	bb := snapshot.BB15
	if bb.Known {
		zero := bb.Sigma == 0
		r.Flags["bb15_sigma_zero"] = &zero
		r.Values["bb15_sigma"] = number(true, bb.Sigma)
		if bb.Sigma > 0 {
			r.Values["bb15_position_sigma_to_side"] = number(true, s*(query.BirthQuote.Last-bb.Mean)/bb.Sigma)
			position := (query.BirthQuote.Last - bb.Lower) / (bb.Upper - bb.Lower)
			if query.Side < 0 {
				position = 1 - position
			}
			r.Values["bb15_percent_to_side"] = number(true, position)
		}
		if p, ok := snapshot.Frames[900]; ok && p.Frame.Frame.PriceKnown {
			r.Values["bb15_width_atr_ratio"] = normalize(true, bb.Upper-bb.Lower, p.Frame.Frame.Technical.ATR)
		}
	}
	for name, value := range r.Values {
		r.KnownMask[name] = value.Known
	}
	return r
}
