package main

import (
	"fmt"
	"math"
	"sort"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// ----------------------------------------
// finite は時計と価格の有限性を検査します。
//
// 引数: values(...float64)。返り値: boolです。
func finite(values ...float64) bool {
	for _, value := range values {
		if math.IsNaN(value) || math.IsInf(value, 0) {
			return false
		}
	}
	return true
}

// ----------------------------------------
// validQuery は出生原行のみを許し、取得・結果を必要としない問い合わせを検査します。
//
// 引数: query(Query)。返り値: errorは不正な識別/方向/出生です。
func validQuery(query Query) error {
	q := query.BirthQuote
	if query.ID == "" || query.Session == "" || query.Contract == "" || (query.Side != 1 && query.Side != -1) ||
		!finite(q.Time, q.Last) || q.Last <= 0 || q.Index < 0 || q.Line < q.Index+1 {
		return fmt.Errorf("queryの識別/方向/出生原行が不正")
	}
	return nil
}

// ----------------------------------------
// deliver は既存Bankへ公表を渡し、別場・別限月・配送逆転を拒否します。
//
// 引数: bank(*rules.Bank)、scene(Scene)、index(int)。返り値: errorです。
func deliver(bank *rules.Bank, scene Scene, index int) error {
	p := scene.Publications[index]
	f := p.Frame.Frame
	if f.SessionID != scene.Session || f.Contract != scene.Contract {
		return fmt.Errorf("公表の場/限月が入力場と不一致")
	}
	if index > 0 {
		previous := scene.Publications[index-1].Stamp
		if p.Stamp.Time < previous.Time || p.Stamp.Index < previous.Index || p.Stamp.Line < previous.Line ||
			(p.Stamp.Index == previous.Index && p.Stamp != previous) {
			return fmt.Errorf("公表配送順又は同原行Stampが不正")
		}
	}
	return bank.Add(p)
}

// ----------------------------------------
// Replay は各origin出生まで同Rawの全公表を配送し、残りも次場seedへ反映します。
//
// 引数: input(Input)、queries([]Query)。返り値: []Row/error。Raw・Entry・ラベルは受け取りません。
func Replay(input Input, queries []Query) ([]Row, error) {
	bySession := map[string][]int{}
	seenQuery := map[string]bool{}
	for index, query := range queries {
		if err := validQuery(query); err != nil {
			return nil, err
		}
		key := query.Session + "\x00" + query.ID
		if seenQuery[key] {
			return nil, fmt.Errorf("同場query IDが重複")
		}
		seenQuery[key] = true
		bySession[query.Session] = append(bySession[query.Session], index)
	}
	rows := make([]Row, len(queries))
	bank := rules.NewBank()
	seenScene := map[string]bool{}
	previousSession := ""
	for _, scene := range input.Scenes {
		if scene.Session == "" || seenScene[scene.Session] || scene.Session <= previousSession || scene.Contract == "" ||
			!finite(scene.Start, scene.End) || scene.End <= scene.Start {
			return nil, fmt.Errorf("入力場の識別/順序/時計が不正")
		}
		seenScene[scene.Session] = true
		previousSession = scene.Session
		if err := bank.StartSession(scene.Session, scene.Contract); err != nil {
			return nil, err
		}
		indices := append([]int(nil), bySession[scene.Session]...)
		sort.SliceStable(indices, func(i, j int) bool {
			return queries[indices[i]].BirthQuote.Index < queries[indices[j]].BirthQuote.Index
		})
		pi := 0
		var previous *rules.Quote
		for _, index := range indices {
			query := queries[index]
			q := query.BirthQuote
			if query.Contract != scene.Contract || q.Time < scene.Start || q.Time > scene.End {
				return nil, fmt.Errorf("queryの当場/限月/時計差")
			}
			if previous != nil && ((q.Index == previous.Index && q != *previous) || q.Time < previous.Time || q.Line < previous.Line) {
				return nil, fmt.Errorf("query原行の改変又は順序差")
			}
			for pi < len(scene.Publications) && scene.Publications[pi].Stamp.Index <= q.Index {
				p := scene.Publications[pi]
				if p.Stamp.Time > q.Time || p.Stamp.Line > q.Line ||
					(p.Stamp.Index == q.Index && (p.Stamp.Time != q.Time || p.Stamp.Line != q.Line)) {
					return nil, fmt.Errorf("出生indexと公表time/物理行の因果差")
				}
				if err := deliver(bank, scene, pi); err != nil {
					return nil, err
				}
				pi++
			}
			snapshot, err := bank.Current(q)
			if err != nil {
				return nil, err
			}
			for _, ref := range snapshot.Refs {
				if ref.End > q.Time || ref.Delivered.Time > q.Time || ref.Delivered.Index > q.Index || ref.Delivered.Line > q.Line {
					return nil, fmt.Errorf("当時Snapshotに未来公表")
				}
			}
			rows[index] = features(query, snapshot)
			z := q
			previous = &z
		}
		// ----------------------------------------
		// 当場の問い合わせ後の公表も取り込み、次場の数値carryを欠落させません。
		for pi < len(scene.Publications) {
			if err := deliver(bank, scene, pi); err != nil {
				return nil, err
			}
			pi++
		}
	}
	for session := range bySession {
		if !seenScene[session] {
			return nil, fmt.Errorf("query場が入力に存在しない")
		}
	}
	return rows, nil
}
