package main

import rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"

// Query は一つのoriginの出生だけを指定します。取得価格やラベルを受け取りません。
type Query struct {
	ID         string      `json:"id"`
	Session    string      `json:"session"`
	Contract   string      `json:"contract"`
	Side       int         `json:"side"`
	BirthQuote rules.Quote `json:"birthQuote"`
}

type Queries struct {
	Success     *bool      `json:"success,omitempty"`
	Trial       *int       `json:"trial,omitempty"`
	ManifestSHA string     `json:"manifest_sha256,omitempty"`
	Queries     []Query    `json:"queries"`
	Relations   []Relation `json:"relations,omitempty"`
}

// Relation は照会元の識別だけを許します。特徴計算はこの値を使いません。
type Relation struct {
	EntryID       string `json:"entry_id"`
	QueryID       string `json:"query_id"`
	Model         string `json:"model"`
	ManifestIndex int    `json:"manifest_index"`
	OriginIndex   int    `json:"origin_index"`
	Family        string `json:"family"`
	Side          int    `json:"side"`
	SelectedSide  int    `json:"selected_side"`
}

type Scene struct {
	Session      string              `json:"session"`
	Contract     string              `json:"contract"`
	Start        float64             `json:"start"`
	End          float64             `json:"end"`
	Publications []rules.Publication `json:"publications"`
}

type Input struct {
	Scenes []Scene `json:"scenes"`
}

// Value は未知をnullとし、既知の0と区別します。
type Value struct {
	Known bool     `json:"known"`
	Value *float64 `json:"value"`
}

type Definition struct {
	Role    string `json:"role"`
	Unit    string `json:"unit"`
	Formula string `json:"formula"`
}

type Foot struct {
	ID          string      `json:"id"`
	Width       int         `json:"width_seconds"`
	End         float64     `json:"end"`
	AvailableAt float64     `json:"available_at"`
	DeliveryAt  float64     `json:"delivery_at"`
	Delivered   rules.Stamp `json:"delivered"`
	PriceKnown  bool        `json:"price_known"`
	VolumeKnown bool        `json:"volume_known"`
	MarketAge   float64     `json:"market_age_seconds"`
	DeliveryAge float64     `json:"delivery_age_seconds"`
}

type Row struct {
	Query     Query            `json:"query"`
	Values    map[string]Value `json:"values"`
	KnownMask map[string]bool  `json:"known_mask"`
	Feet      map[string]*Foot `json:"feet"`
	Refs      []rules.Ref      `json:"refs"`
	Missing   []string         `json:"missing"`
	Flags     map[string]*bool `json:"flags"`
}
