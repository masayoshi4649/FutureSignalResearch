"""全成立poolの特徴exporterを人工と許可queryのschemaだけで確認する。"""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

OWN = Path(__file__).resolve().parent
ROOT = OWN.parent.parent
QUERY = ROOT / 'work/138全成立入口の評価/固定入力/特徴照会.json'
QUERY_SHA = '81442c3ebaa3065213d0844417bb0462cfa3e5d0a05c4f44edfb3fb14191e75c'


# ----------------------------------------
def sha(path: Path) -> str:
    """
    機能: コード・許可query metadataのbytes指紋を得る。
    引数: path(Path)。返り値: str。自然公表/Raw/CSV/金融には使わない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def execute(spec: tuple[str, list[str]]) -> tuple[str, subprocess.CompletedProcess]:
    """
    機能: 自然Replayを含まないGo人工/静的検査/build/schemaだけを実行する。
    引数: spec(tuple[str,list[str]])。返り値: tuple[str,CompletedProcess]。
    """
    name, command = spec
    env = dict(os.environ, POOL_QUERY_SCHEMA_PATH=str(QUERY), POOL_QUERY_SCHEMA_SHA=QUERY_SHA)
    return name, subprocess.run(command, cwd=OWN, env=env, capture_output=True, text=True, encoding='utf-8')


# ----------------------------------------
def main() -> None:
    """
    機能: 人工7群・Root照会schema・実効118依存の前後同体を証明する。
    引数: なし。返り値: None。177MB公表の自然特徴/金融は実行しない。
    """
    sys.stdout.reconfigure(encoding='utf-8')
    names = ['go.mod', 'types.go', 'features.go', 'replay.go', 'main.go', 'exporter_test.go',
             '条件.md', '実照会schema_test.go.txt', '準備を確認する.py']
    before = {name: sha(OWN / name) for name in names}
    dependency = ROOT / 'work/118複数技法の入口条件'
    effective = json.loads(subprocess.check_output(['go', 'list', '-json',
        'github.com/masayoshi4649/SessionTradeExecuter/entryrules118'], cwd=OWN, text=True, encoding='utf-8'))
    assert Path(effective['Dir']).resolve() == dependency.resolve()
    assert set(effective['GoFiles']) == {'bank.go', 'rules.go', 'types.go'}
    sources = {str(dependency / name): sha(dependency / name) for name in
               effective['GoFiles'] + ['go.mod']}
    assert sha(QUERY) == QUERY_SHA
    virtual = OWN / '独立実照会schema_test.go'
    assert not virtual.exists()
    overlay = OWN / 'schemaだけ確認するoverlay.json'
    overlay.write_text(json.dumps({'Replace': {str(virtual): str(OWN / '実照会schema_test.go.txt')}},
                                  ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    commands = [('人工', ['go', 'test', '-count=1', '-json', './...']),
                ('静的検査', ['go', 'vet', './...']),
                ('build', ['go', 'build', '-o', '当時特徴.exe', '.']),
                ('許可照会schema', ['go', 'test', '-count=1', '-json', '-overlay', str(overlay),
                                 '-run', '^TestRootQuerySchemaOnly$', './...'])]
    checks = {}
    with ThreadPoolExecutor(max_workers=4) as pool:
        for name, result in pool.map(execute, commands):
            assert result.returncode == 0, result.stdout + result.stderr
            log = OWN / (name + 'のログ.txt'); log.write_text(result.stdout + result.stderr, encoding='utf-8')
            checks[name] = {'exit_code': result.returncode, 'log_sha256': sha(log)}
            if name in ('人工', '許可照会schema'):
                events = [json.loads(line) for line in result.stdout.splitlines() if line.startswith('{')]
                passed = [event['Test'] for event in events if event.get('Action') == 'pass' and event.get('Test')]
                assert len(passed) == (7 if name == '人工' else 1)
                assert not any(event.get('Action') in ('skip', 'fail') for event in events)
                checks[name]['passed'] = passed
    assert before == {name: sha(OWN / name) for name in names}
    assert sources == {str(dependency / name): sha(dependency / name) for name in effective['GoFiles'] + ['go.mod']}
    assert sha(QUERY) == QUERY_SHA and not virtual.exists()
    proof = {'成功': True, '段階': 'コード/人工準備。自然特徴のReplayなし', '本部品SHA256': before,
             '実効118依存SHA256': sources, 'Go版': subprocess.check_output(['go', 'version'], text=True).strip(),
             '実行ファイルSHA256': sha(OWN / '当時特徴.exe'), '検査': checks, '特徴数': 74,
             '自然公表入力': '固定122 SHA6a6cd…・177MB本文は未読',
             '許可query_metadata_SHA256': QUERY_SHA, 'query_schema件数': 769, 'relations_schema件数': 850,
             '同Raw全公表配送と残りseed': True, '未来公表の非依存': True,
             '未知nullと既知0': True, '売買鏡像': True, '前後同体': True,
             'CSV特徴は128と129の原生Raw背景と同一でない': True,
             '自然特徴計算': False, 'Entry価格と金融ラベル使用': False, '新Rawと価格CSV読取': False,
             '追加2場読取': False, '模型学習と閾値探索': False, '新採番': False}
    target = OWN / '準備の確認.json'
    target.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'success': True, 'proof_sha256': sha(target), 'code': before,
                      'executable_sha256': proof['実行ファイルSHA256']}, ensure_ascii=True))


if __name__ == '__main__':
    main()
