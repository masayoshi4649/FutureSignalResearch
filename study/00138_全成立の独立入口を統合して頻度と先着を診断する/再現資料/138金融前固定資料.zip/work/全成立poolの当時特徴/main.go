package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
)

const csv122SHA = "6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec"

// ----------------------------------------
// digest は明示された入力bytesの指紋を返します。
//
// 引数: data([]byte)。返り値: stringです。
func digest(data []byte) string { v := sha256.Sum256(data); return hex.EncodeToString(v[:]) }

// ----------------------------------------
// decodeQueries は定義した出生キーだけを受け付け、Entry/ラベルの混入を拒否します。
//
// 引数: data([]byte)。返り値: Queries/errorです。
func decodeQueries(data []byte) (Queries, error) {
	var result Queries
	d := json.NewDecoder(bytes.NewReader(data))
	d.DisallowUnknownFields()
	if err := d.Decode(&result); err != nil {
		return result, err
	}
	var extra any
	if err := d.Decode(&extra); err != io.EOF {
		return result, fmt.Errorf("query JSONの後続値又は末尾不正")
	}
	return result, nil
}

// ----------------------------------------
// run は固定122公表と明示queryの指紋を確認した後だけ特徴JSONを新規保存します。
//
// 引数: なし（flag指定）。返り値: errorです。自然実行はRootの条件/入力固定後に限ります。
func run() error {
	inputPath := flag.String("input", "", "固定122公表入力JSON")
	expected := flag.String("sha256", "", "固定122のSHA256")
	queryPath := flag.String("queries", "", "出生queryのみのJSON")
	querySHA := flag.String("queries-sha256", "", "query JSONのSHA256")
	output := flag.String("output", "", "未作成の出力JSON")
	flag.Parse()
	if *inputPath == "" || *expected != csv122SHA || *queryPath == "" || len(*querySHA) != 64 || *output == "" {
		return fmt.Errorf("固定122入力/query/各指紋/未作成出力が必要")
	}
	if _, err := hex.DecodeString(*querySHA); err != nil {
		return fmt.Errorf("query SHAの形式不正")
	}
	if _, err := os.Stat(*output); !os.IsNotExist(err) {
		return fmt.Errorf("出力は未作成先だけを許可")
	}
	inBefore, err := os.Stat(*inputPath)
	if err != nil {
		return err
	}
	queryBefore, err := os.Stat(*queryPath)
	if err != nil {
		return err
	}
	data, err := os.ReadFile(*inputPath)
	if err != nil {
		return err
	}
	qdata, err := os.ReadFile(*queryPath)
	if err != nil {
		return err
	}
	if digest(data) != *expected || digest(qdata) != *querySHA {
		return fmt.Errorf("入力/query SHA差")
	}
	var input Input
	if err = json.Unmarshal(data, &input); err != nil {
		return err
	}
	if len(input.Scenes) != 73 {
		return fmt.Errorf("固定122の全73場でない")
	}
	queries, err := decodeQueries(qdata)
	if err != nil {
		return err
	}
	rows, err := Replay(input, queries.Queries)
	if err != nil {
		return err
	}
	dataAfter, err := os.ReadFile(*inputPath)
	if err != nil {
		return err
	}
	queryAfterBytes, err := os.ReadFile(*queryPath)
	if err != nil {
		return err
	}
	inAfter, err := os.Stat(*inputPath)
	if err != nil {
		return err
	}
	queryAfter, err := os.Stat(*queryPath)
	if err != nil {
		return err
	}
	if digest(dataAfter) != *expected || digest(queryAfterBytes) != *querySHA || inBefore.Size() != inAfter.Size() ||
		inBefore.ModTime() != inAfter.ModTime() || queryBefore.Size() != queryAfter.Size() || queryBefore.ModTime() != queryAfter.ModTime() {
		return fmt.Errorf("入力/queryの前後SHA又はstat差")
	}
	value := struct {
		Success  bool                  `json:"success"`
		Version  int                   `json:"version"`
		InputSHA string                `json:"input_sha256"`
		QuerySHA string                `json:"queries_sha256"`
		Scenes   int                   `json:"source_scene_count"`
		Count    int                   `json:"query_count"`
		Catalog  map[string]Definition `json:"catalog"`
		Rows     []Row                 `json:"rows"`
		Labels   bool                  `json:"financial_labels_used"`
		Entry    bool                  `json:"entry_prices_used"`
	}{true, 1, *expected, *querySHA, len(input.Scenes), len(rows), catalog(), rows, false, false}
	encoded, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		return err
	}
	encoded = append(encoded, '\n')
	if err = os.MkdirAll(filepath.Dir(*output), 0755); err != nil {
		return err
	}
	f, err := os.OpenFile(*output, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0644)
	if err != nil {
		return err
	}
	_, writeErr := f.Write(encoded)
	closeErr := f.Close()
	if writeErr != nil {
		return writeErr
	}
	if closeErr != nil {
		return closeErr
	}
	fmt.Printf("特徴%d件・入力73場・出力SHA256=%s\n", len(rows), digest(encoded))
	return nil
}

// ----------------------------------------
// main は明示CLIだけを起動し、不正入力時に成功を表示しません。
//
// 引数: なし。返り値: なし。
func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
