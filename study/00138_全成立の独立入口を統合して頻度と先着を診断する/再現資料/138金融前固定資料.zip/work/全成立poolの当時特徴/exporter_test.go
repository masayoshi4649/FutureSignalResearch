package main

import (
	"encoding/json"
	"fmt"
	"math"
	"reflect"
	"strings"
	"testing"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// ----------------------------------------
// known は人工の既知値を作ります。
//
// 引数: v(float64)。返り値: rules.Valueです。
func known(v float64) rules.Value { return rules.Value{Known: true, Value: v} }

// ----------------------------------------
// publication は既知の時計/価格/指標を持つ人工公表を作ります。
//
// 引数: session/contract(string)、width/index(int)、end(float64)。返り値: rules.Publicationです。
func publication(session, contract string, width, index int, end float64) rules.Publication {
	t := rules.Technical{EMA8: known(102), EMA21: known(100), EMA8Delta: known(.5), EMA21Delta: known(.25), Gap: known(2),
		ATR: known(10), PreviousATR: known(8), TR: known(12), RSI: known(60), PreviousRSI: known(55), Histogram: known(1), PreviousHistogram: known(.5)}
	return rules.Publication{Stamp: rules.Stamp{Time: end + 65, Index: index, Line: index + 1},
		Frame: rules.Frame{Frame: rules.ChartFrame{ID: fmt.Sprintf("%s/%d/%v", session, width, end), SessionID: session, Contract: contract,
			Width: width, Start: end - float64(width), End: end, AvailableAt: end + 60, DeliveryAt: end + 65, PriceKnown: true, VolumeKnown: true, Volume: 10,
			OHLC: rules.OHLC{Open: 103, High: 114, Low: 98, Close: 108}, Technical: t},
			DMI: rules.DMI{PlusDI: known(30), MinusDI: known(10), ADX: known(25), PreviousADX: known(20)}}}
}

// ----------------------------------------
// fixture は同Rawの5/15/30分公表と、その出生照会を作ります。
//
// 引数: なし。返り値: Input/Queryです。自然ファイルを読みません。
func fixture() (Input, Query) {
	scene := Scene{Session: "A", Contract: "K", Start: 0, End: 4000}
	for _, w := range []int{300, 900, 1800} {
		scene.Publications = append(scene.Publications, publication("A", "K", w, 10, 1800))
	}
	return Input{Scenes: []Scene{scene}}, Query{ID: "人工origin", Session: "A", Contract: "K", Side: 1, BirthQuote: rules.Quote{Time: 1865, Index: 10, Line: 11, Last: 110}}
}

// ----------------------------------------
// cloneInput は検査用の値copyを作ります。
//
// 引数: input(Input)。返り値: Inputです。
func cloneInput(input Input) Input {
	data, _ := json.Marshal(input)
	var out Input
	_ = json.Unmarshal(data, &out)
	return out
}

// ----------------------------------------
// requireValue は既知値と許容丸め誤差を検査します。
//
// 引数: t(*testing.T)、row(Row)、key(string)、want(float64)。返り値: なし。
func requireValue(t *testing.T, row Row, key string, want float64) {
	t.Helper()
	v := row.Values[key]
	if !v.Known || v.Value == nil || math.Abs(*v.Value-want) > 1e-10 {
		t.Fatalf("%s: %+v want %v", key, v, want)
	}
}

// ----------------------------------------
// TestSameRawAllPublications は全同Raw配送と役割/正規化尺度の分離を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestSameRawAllPublications(t *testing.T) {
	in, q := fixture()
	saved := cloneInput(in)
	rows, err := Replay(in, []Query{q})
	if err != nil || len(rows) != 1 {
		t.Fatal(err)
	}
	r := rows[0]
	if len(r.Refs) != 3 || r.Feet["m30"] == nil || len(r.Values) != len(catalog()) || len(r.KnownMask) != len(catalog()) {
		t.Fatal("同Raw公表又は全列mask不足")
	}
	for _, k := range []string{"m5", "m15", "m30"} {
		requireValue(t, r, k+"_gap_atr_to_side", .2)
		requireValue(t, r, k+"_hist_delta_atr_to_side", .05)
		requireValue(t, r, k+"_adx", 25)
		requireValue(t, r, k+"_di_difference_to_side", 20)
		requireValue(t, r, k+"_rsi_center_to_side", 10)
		requireValue(t, r, k+"_price_ema21_atr_to_side", 1)
	}
	requireValue(t, r, "m5_tr_atr_ratio", 1.2)
	requireValue(t, r, "m5_atr_tr_ratio", 10.0/12)
	roles := map[string]bool{"方向": true, "強度": true, "勢い": true, "値幅": true, "量": true, "構造": true}
	for key, d := range catalog() {
		if !roles[d.Role] || d.Formula == "" || r.KnownMask[key] != r.Values[key].Known {
			t.Fatal("role/mask差")
		}
	}
	if !reflect.DeepEqual(in, saved) {
		t.Fatal("入力を改変")
	}
}

// ----------------------------------------
// TestFuturePublicationIndependence は未来の公表値が早い出生の特徴へ混入しないことを確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestFuturePublicationIndependence(t *testing.T) {
	in, q := fixture()
	future := publication("A", "K", 300, 20, 2100)
	in.Scenes[0].Publications = append(in.Scenes[0].Publications, future)
	a, err := Replay(in, []Query{q})
	if err != nil {
		t.Fatal(err)
	}
	in.Scenes[0].Publications[3].Frame.Frame.Technical.Histogram = known(1e6)
	b, err := Replay(in, []Query{q})
	if err != nil || !reflect.DeepEqual(a, b) {
		t.Fatal("未来値へ依存", err)
	}
	for _, mode := range []string{"未来time", "未来line"} {
		bad, _ := fixture()
		if mode == "未来time" {
			bad.Scenes[0].Publications[0].Stamp.Time++
		}
		if mode == "未来line" {
			bad.Scenes[0].Publications[0].Stamp.Line++
		}
		if _, err := Replay(bad, []Query{q}); err == nil {
			t.Fatal("同indexの未来配送を許可")
		}
	}
}

// ----------------------------------------
// TestMirrorAndDirectionFreeStrength は鏡像の向き特徴を同値、ADX等を非方向量として確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestMirrorAndDirectionFreeStrength(t *testing.T) {
	in, q := fixture()
	a, err := Replay(in, []Query{q})
	if err != nil {
		t.Fatal(err)
	}
	for i := range in.Scenes[0].Publications {
		p := &in.Scenes[0].Publications[i]
		o := p.Frame.Frame.OHLC
		p.Frame.Frame.OHLC = rules.OHLC{Open: 300 - o.Open, High: 300 - o.Low, Low: 300 - o.High, Close: 300 - o.Close}
		x := &p.Frame.Frame.Technical
		x.EMA8.Value = 300 - x.EMA8.Value
		x.EMA21.Value = 300 - x.EMA21.Value
		for _, v := range []*rules.Value{&x.Gap, &x.EMA8Delta, &x.EMA21Delta, &x.Histogram, &x.PreviousHistogram} {
			v.Value = -v.Value
		}
		x.RSI.Value = 100 - x.RSI.Value
		x.PreviousRSI.Value = 100 - x.PreviousRSI.Value
		p.Frame.DMI.PlusDI, p.Frame.DMI.MinusDI = p.Frame.DMI.MinusDI, p.Frame.DMI.PlusDI
	}
	q.Side = -1
	q.BirthQuote.Last = 300 - q.BirthQuote.Last
	b, err := Replay(in, []Query{q})
	if err != nil {
		t.Fatal(err)
	}
	for key, v := range a[0].Values {
		u := b[0].Values[key]
		if v.Known != u.Known {
			t.Fatal("鏡像known差")
		}
		if v.Known && math.Abs(*v.Value-*u.Value) > 1e-10 {
			t.Fatalf("鏡像値差 %s", key)
		}
	}
}

// ----------------------------------------
// TestUnknownZeroAndFreshEquality は未知null・既知0・ATR0・足幅0・fresh等号を区別します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestUnknownZeroAndFreshEquality(t *testing.T) {
	in, q := fixture()
	p := &in.Scenes[0].Publications[0]
	p.Frame.Frame.Technical.ATR = known(0)
	p.Frame.Frame.Technical.Histogram = known(0)
	p.Frame.Frame.OHLC = rules.OHLC{Open: 100, High: 100, Low: 100, Close: 100}
	r, err := Replay(in, []Query{q})
	if err != nil {
		t.Fatal(err)
	}
	requireValue(t, r[0], "m5_hist_to_side", 0)
	if r[0].Values["m5_hist_atr_to_side"].Known || r[0].Values["m5_body_ratio_to_side"].Value != nil || !*r[0].Flags["m5_range_zero"] {
		t.Fatal("0を未知と混同")
	}
	encoded, _ := json.Marshal(r[0].Values["m5_hist_atr_to_side"])
	if string(encoded) != "{\"known\":false,\"value\":null}" {
		t.Fatal("未知のJSONがnullでない")
	}
	in, q = fixture()
	q.BirthQuote.Index++
	q.BirthQuote.Line++
	q.BirthQuote.Time = 2160
	r, err = Replay(in, []Query{q})
	if err != nil || r[0].Feet["m5"] != nil || r[0].Values["m5_gap_to_side"].Known {
		t.Fatal("fresh等号を許可", err)
	}
	q.BirthQuote.Time = 2159
	r, err = Replay(in, []Query{q})
	if err != nil || r[0].Feet["m5"] == nil {
		t.Fatal("fresh内を拒否", err)
	}
	in.Scenes[0].Publications = nil
	r, err = Replay(in, []Query{q})
	if err != nil {
		t.Fatal(err)
	}
	for _, v := range r[0].Values {
		if v.Known || v.Value != nil {
			t.Fatal("公表欠測を0補完")
		}
	}
}

// ----------------------------------------
// TestRvolAndPriceUnknown は量の既知性を価格指標と混同せず、前20本窓を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestRvolAndPriceUnknown(t *testing.T) {
	in := Input{Scenes: []Scene{{Session: "A", Contract: "K", Start: 0, End: 7000}}}
	for i := 1; i <= 21; i++ {
		in.Scenes[0].Publications = append(in.Scenes[0].Publications, publication("A", "K", 300, i*10, float64(i*300)))
	}
	last := &in.Scenes[0].Publications[20]
	last.Frame.Frame.Volume = 20
	last.Frame.Frame.PriceKnown = false
	q := Query{ID: "量", Session: "A", Contract: "K", Side: 1, BirthQuote: rules.Quote{Time: 6365, Index: 210, Line: 211, Last: 110}}
	r, err := Replay(in, []Query{q})
	if err != nil {
		t.Fatal(err)
	}
	requireValue(t, r[0], "rvol5", 2)
	if r[0].Values["m5_hist_to_side"].Known || r[0].Feet["m5"].PriceKnown {
		t.Fatal("価格未知を既知指標に利用")
	}
	last.Frame.Frame.Volume = 0
	r, err = Replay(in, []Query{q})
	if err != nil {
		t.Fatal(err)
	}
	requireValue(t, r[0], "rvol5", 0)
	in.Scenes[0].Publications[3].Frame.Frame.VolumeKnown = false
	r, err = Replay(in, []Query{q})
	if err != nil || r[0].Values["rvol5"].Known {
		t.Fatal("量未知を飛ばした")
	}
}

// ----------------------------------------
// TestRemainingPublicationsSeedAndContract は照会後/照会0場の公表を次場へcarryし、異限月では切ります。
//
// 引数: t(*testing.T)。返り値: なし。
func TestRemainingPublicationsSeedAndContract(t *testing.T) {
	a := Scene{Session: "A", Contract: "K", Start: 0, End: 20000}
	for i := 1; i <= 20; i++ {
		p := publication("A", "K", 900, i*10, float64(i*900))
		p.Frame.Frame.OHLC = rules.OHLC{Open: 100, High: 101, Low: 99, Close: 100}
		a.Publications = append(a.Publications, p)
	}
	b := Scene{Session: "B", Contract: "K", Start: 21000, End: 23000}
	p := publication("B", "K", 900, 10, 21600)
	p.Frame.Frame.OHLC = rules.OHLC{Open: 100, High: 101, Low: 99, Close: 100}
	b.Publications = []rules.Publication{p}
	in := Input{Scenes: []Scene{a, b}}
	q := Query{ID: "窓", Session: "B", Contract: "K", Side: 1, BirthQuote: rules.Quote{Time: 21665, Index: 10, Line: 11, Last: 100}}
	r, err := Replay(in, []Query{q})
	if err != nil {
		t.Fatal(err)
	}
	requireValue(t, r[0], "bb15_sigma", 0)
	if r[0].Flags["bb15_sigma_zero"] == nil || !*r[0].Flags["bb15_sigma_zero"] || r[0].Values["bb15_position_sigma_to_side"].Known {
		t.Fatal("sigma0を位置比にした")
	}
	// Aにも早いqueryを置いても、その後の19公表がseedへ反映されます。
	early := Query{ID: "早い窓", Session: "A", Contract: "K", Side: 1, BirthQuote: rules.Quote{Time: 965, Index: 10, Line: 11, Last: 100}}
	r, err = Replay(in, []Query{q, early})
	if err != nil || r[0].Query.ID != "窓" || !r[0].Values["bb15_sigma"].Known {
		t.Fatal("出力順又は残り公表carry差", err)
	}
	for i := range in.Scenes[0].Publications {
		close := float64(91 + i)
		in.Scenes[0].Publications[i].Frame.Frame.OHLC = rules.OHLC{Open: close, High: close + 1, Low: close - 1, Close: close}
	}
	in.Scenes[1].Publications[0].Frame.Frame.OHLC = rules.OHLC{Open: 111, High: 112, Low: 110, Close: 111}
	q.BirthQuote.Last = 112
	r, err = Replay(in, []Query{q})
	if err != nil {
		t.Fatal(err)
	}
	requireValue(t, r[0], "bb15_sigma", math.Sqrt(33.25))
	requireValue(t, r[0], "bb15_position_sigma_to_side", 10.5/math.Sqrt(33.25))
	requireValue(t, r[0], "bb15_percent_to_side", .5+10.5/(4*math.Sqrt(33.25)))
	in.Scenes[1].Contract = "Z"
	in.Scenes[1].Publications[0].Frame.Frame.Contract = "Z"
	q.Contract = "Z"
	r, err = Replay(in, []Query{q})
	if err != nil || r[0].Values["bb15_sigma"].Known {
		t.Fatal("異限月へ窓をcarry", err)
	}
}

// ----------------------------------------
// TestQuerySchemaAndInvalidInput はorigin別Queryだけを受け、Entryやラベル等を拒否します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestQuerySchemaAndInvalidInput(t *testing.T) {
	in, q := fixture()
	data, _ := json.Marshal(Queries{Queries: []Query{q}})
	parsed, err := decodeQueries(data)
	if err != nil || len(parsed.Queries) != 1 {
		t.Fatal(err)
	}
	metadata := `{"success":true,"trial":138,"manifest_sha256":"人工","queries":` + strings.TrimSuffix(strings.TrimPrefix(string(data), `{"queries":`), `}`) + `,"relations":[{"entry_id":"入口","query_id":"人工origin","model":"P0","manifest_index":0,"origin_index":0,"family":"人工","side":1,"selected_side":-1}]}`
	if _, err := decodeQueries([]byte(metadata)); err != nil {
		t.Fatal("識別relationsを持つschemaを拒否", err)
	}
	for _, member := range []string{"entry", "label", "source_kind"} {
		bad := strings.Replace(string(data), "\"birthQuote\":", "\""+member+"\":123,\"birthQuote\":", 1)
		if _, err = decodeQueries([]byte(bad)); err == nil {
			t.Fatal("余分なEntry/label等を許可")
		}
	}
	for _, mutate := range []func(*Query){func(x *Query) { x.Side = 0 }, func(x *Query) { x.Contract = "異限月" }, func(x *Query) { x.BirthQuote.Last = math.NaN() }} {
		bad := q
		mutate(&bad)
		if _, err = Replay(in, []Query{bad}); err == nil {
			t.Fatal("不正queryを許可")
		}
	}
	if _, err = Replay(in, []Query{q, q}); err == nil {
		t.Fatal("重複IDを許可")
	}
	bad := q
	bad.ID = "別origin"
	bad.BirthQuote.Last++
	if _, err = Replay(in, []Query{q, bad}); err == nil {
		t.Fatal("同原行のLast差を許可")
	}
	inputKnown := cloneInput(in)
	inputKnown.Scenes[0].Publications[0].Frame.Frame.Technical.Gap = known(math.Inf(1))
	if _, err = Replay(inputKnown, []Query{q}); err == nil {
		t.Fatal("既知非有限値を許可")
	}
}
