"""138の全成立入口を金融前に固定し、実BBO正逆観測と集計を分離する。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
OWN = ROOT / 'work/138全成立入口の評価'
FORMAL = ROOT / 'study/00138_全成立の独立入口を統合して頻度と先着を診断する'
AGG = ROOT / 'work/138全成立入口と頻度の集計'
FEATURES = ROOT / 'work/全成立poolの当時特徴'
MANIFEST = ROOT / 'work/全成立poolの非金融manifest'
FIXED = OWN / '固定入力_版2/固定取得入力.json'
META = OWN / '固定入力_版2/入口参照.json'
KERNEL = ROOT / 'work/133固定取得の正逆評価器/固定取得の正逆評価.exe'
HELPER = ROOT / 'work/133金融前を固定して実行する.py'
EXPECTED = {
    FIXED: '0c83e525dec3079ce188d942069c0d137c94f39009339752ec8227ec9ecb4ce7',
    META: '75e4993571bdef17839aad3324acc6ee9ce09b3cb1f4ecad70637a1e01ccefd0',
    OWN / '固定入力_版2/特徴照会.json': '81442c3ebaa3065213d0844417bb0462cfa3e5d0a05c4f44edfb3fb14191e75c',
    MANIFEST / 'manifest.json': 'e7ba444fd66f9ca52e10e929eeb31d21076f97afa161de738dabca14a8ff8e35',
    KERNEL: '033cf22a052e985bc61aa020a04fa6d499119051aaa39bb2adb715a4af1e7736',
    ROOT / 'work/122全場入力/入力.json': '6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec',
    FEATURES / '準備の確認.json': '28b5817e6ec53789fa2cd86da52e4d4b3e1dfac3a28e259f796642223332d48b',
    FEATURES / '当時特徴.exe': 'b758a702fce4b503cfa845d0ae9ab74a09e4f38640d477d9f7355eb0fb41eaa3',
}


def sha(path: Path) -> str:
    """
    機能: ファイル全体の固定指紋を計算する。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def load(path: Path, name: str) -> object:
    """
    機能: mainを実行せず既存検査関数を読み込む。
    引数: path(Path)とname(str)はモジュールの位置と私有名。
    返り値: objectは読み込んだモジュール。
    """
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# ----------------------------------------
def main() -> None:
    """
    機能: 金融前固定、実正逆観測、固定算術の集計を順に実行する。
    引数: CLI --mode(str)は固定、再生、集計のいずれか。
    返り値: None。保存済み観測の上書きはしない。
    """
    parser = argparse.ArgumentParser(description='138の金融前固定と段階実行')
    parser.add_argument('--mode', choices=('特徴固定', '特徴', '固定', '再生', '集計'), required=True)
    args = parser.parse_args()
    helper = load(HELPER, '138の凍結検査')
    f1 = OWN / 'F1.json'
    feature_f0 = OWN / 'F0特徴.json'
    if args.mode == '特徴固定':
        files = set(EXPECTED) | {HELPER, Path(__file__).resolve()}
        for path, expected in EXPECTED.items():
            assert sha(path) == expected, path
        for folder in (FEATURES, FORMAL):
            files.update(p for p in folder.rglob('*') if p.is_file() and p.suffix in ('.py', '.md', '.json', '.go', '.mod', '.exe'))
        proof = json.loads((FEATURES / '準備の確認.json').read_bytes())
        for name, expected in proof['実効118依存SHA256'].items():
            assert sha(Path(name)) == expected, name
            files.add(Path(name))
        helper.save(feature_f0, {'成功': True, '試行': 138, '段階': '当時特徴前F0',
            'UTC': datetime.now(timezone.utc).isoformat(), '金融ラベル不使用': True,
            '方向や取得選別への特徴利用': False, 'CSV公表の診断overlay': True,
            'ファイル': {str(p): sha(p) for p in sorted(files)}})
        print(json.dumps({'特徴F0_SHA256': sha(feature_f0), '固定ファイル数': len(files)}, ensure_ascii=False))
        return
    if args.mode == '特徴':
        fixed_features = json.loads(feature_f0.read_bytes())
        helper.verify(fixed_features)
        feature_result = OWN / '全出生の当時特徴.json'
        assert not feature_result.exists(), '保存済み特徴は再計算し直さない'
        command = [str(FEATURES / '当時特徴.exe'), '--input', str(ROOT / 'work/122全場入力/入力.json'),
            '--sha256', EXPECTED[ROOT / 'work/122全場入力/入力.json'],
            '--queries', str(OWN / '固定入力_版2/特徴照会.json'),
            '--queries-sha256', EXPECTED[OWN / '固定入力_版2/特徴照会.json'], '--output', str(feature_result)]
        subprocess.run(command, cwd=ROOT, check=True)
        helper.verify(fixed_features)
        value = json.loads(feature_result.read_bytes())
        assert value['success'] and value['query_count'] == 769 and value['source_scene_count'] == 73
        assert value['financial_labels_used'] is False and value['entry_prices_used'] is False
        helper.save(OWN / '当時特徴の完了.json', {'成功': True, '試行': 138,
            'F0特徴SHA256': sha(feature_f0), '特徴SHA256': sha(feature_result), '固定源前後同体': True, '実行列': command})
        return
    if args.mode == '固定':
        for path, expected in EXPECTED.items():
            assert sha(path) == expected, path
        assert all((FORMAL / name).is_file() for name in ('README.md', '条件.md', '設定と結果.md'))
        assert all((AGG / name).is_file() for name in ('集計する.py', '人工検査.py', '条件.md', '準備の確認.json'))
        files = set(EXPECTED) | {HELPER, Path(__file__).resolve(), ROOT / 'work/138全成立入口を固定入力へ渡す.py'}
        if feature_f0.exists():
            files.add(feature_f0)
        declared = load(AGG / '集計する.py', '138金融前の固定宣言')
        for path, expected in declared.SOURCES.items():
            assert sha(path) == expected, path
        files.update(declared.SOURCES)
        feature_proof = json.loads((FEATURES / '準備の確認.json').read_bytes())
        for name, expected in feature_proof['実効118依存SHA256'].items():
            path = Path(name)
            assert sha(path) == expected, path
            files.add(path)
        for folder in (FORMAL, AGG, FEATURES, MANIFEST, OWN / '固定入力_版2'):
            files.update(p for p in folder.rglob('*') if p.is_file() and p.suffix in ('.py', '.md', '.json', '.go', '.mod', '.sum', '.exe'))
        manifest = json.loads((MANIFEST / 'manifest.json').read_bytes())
        files.update(ROOT / name for name in manifest['sources'])
        helper.save(f1, {'成功': True, '試行': 138, '段階': '金融前F1',
            'UTC': datetime.now(timezone.utc).isoformat(), '主': 'P0/実BBO/取得後60分/同幅125pt',
            '政策': ['P0', 'C0', 'R0'], '取得集合': {'P0': 752, 'C0': 81},
            '全場最低1取得': True, '毎時定時強制': False, '各場回数上限': False,
            '結果後の方向学習は次試行': True, '追加2場は未読': True,
            'ファイル': {str(p): sha(p) for p in sorted(files)}})
        print(json.dumps({'F1_SHA256': sha(f1), '固定ファイル数': len(files)}, ensure_ascii=False))
        return
    fixed = json.loads(f1.read_bytes())
    helper.verify(fixed)
    result = OWN / '固定取得の正逆観測.json'
    if args.mode == '再生':
        assert not result.exists(), '保存済み観測は再生し直さない'
        command = [str(KERNEL), '--input', str(FIXED), '--sha256', sha(FIXED), '--output', str(result), '--workers', '8']
        subprocess.run(command, cwd=ROOT, check=True)
        helper.verify(fixed)
        helper.verify_result(json.loads(result.read_bytes()), json.loads(FIXED.read_bytes()))
        helper.save(OWN / '正逆観測の完了.json', {'成功': True, '試行': 138, 'kernel版': 133,
            'F1_SHA256': sha(f1), '観測SHA256': sha(result), '固定源前後同体': True, '実行列': command})
        return
    command = [sys.executable, '-X', 'utf8', str(AGG / '集計する.py'),
        '--f1', str(f1), '--f1-sha256', sha(f1), '--fixed-input', str(FIXED), '--fixed-input-sha256', sha(FIXED),
        '--metadata', str(META), '--metadata-sha256', sha(META),
        '--result', str(result), '--result-sha256', sha(result), '--output-dir', str(AGG)]
    subprocess.run(command, cwd=ROOT, check=True)
    helper.verify(fixed)
    helper.save(OWN / '金融段階の完了.json', {'成功': True, '試行': 138, 'F1_SHA256': sha(f1),
        '集計SHA256': sha(AGG / '集計.json'), 'CSV用の表SHA256': sha(AGG / 'CSV用の表.json'),
        '固定源前後同体': True, '実行列': command})


if __name__ == '__main__':
    main()
