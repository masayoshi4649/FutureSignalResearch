"""138のRoot金融前固定後だけ、native poolと固定対照を集計する。"""
import argparse
import copy
import hashlib
import importlib.util
import json
import math
from collections import Counter
from pathlib import Path
from statistics import median

ROOT=Path(__file__).resolve().parents[2]
OWN=Path(__file__).resolve().parent
MODULE=ROOT/'work/124入口の原因分析/集計する.py'
MANIFEST=ROOT/'work/全成立poolの非金融manifest/manifest.json'
OLD137=ROOT/'work/137既知回復と頻度の集計/集計.json'
OLD_PAIRS=ROOT/'work/137既知回復の評価/固定取得の正逆観測.json'
SOURCES={MODULE:'8479ca348231ffd77a637360797750833c9e6617c7fc4a6502e015c7a1d9f04a',
 MANIFEST:'e7ba444fd66f9ca52e10e929eeb31d21076f97afa161de738dabca14a8ff8e35',
 OLD137:'f7c73cc87948fa17174e3909f89aa63d74abe76191bf435788e71cb0d400548b',
 OLD_PAIRS:'f0adca92cf1f1db25e75e4d92187952e2920ea7126b3790ece89df1c7f00369a'}
POLICIES=('P0','C0','R0');MODELS=('P0','C0');MODEL={'P0':'P0','C0':'C0','R0':'P0'}
AXES=('BBO','Last');HORIZONS=(1800,3600);WIDTHS=(25,50,100,125,200)
COMPARISON_HEADERS=['試行','区分','政策','取得集合','価格軸','評価分','同幅pt','対象場数','取得場数','取得数',
 'native向きからの反転数','全場最低1取得','全H完了','観測不足','順行先着','逆行先着','両方未到達',
 '到達済み順行率','完了分母順行率','全取得分母順行率','到達済み70%達成','参加と70%両達成',
 '全時間平均件数毎時','名目新規可時間平均件数毎時','全時間平均1件毎時以上','参加と70%と頻度すべて達成',
 'IFD代用既知','IFD代用未知','C0代用差引円','C5代用利益円','C5代用損失絶対円','C5代用差引円','C5代用平均円','C5代用PF']
DETAIL_HEADERS=['試行','参考区分','セッション','取得集合','固定取得ID','候補ID','native方向','固定対照由来','origin数',
 'origin系統','origin版','初期親数','親種別','取得JST','元取得価格','逆取得価格','H60新規限界JST','原板SHA256']
for _policy in POLICIES:DETAIL_HEADERS += [_policy+s for s in ('方向','125全H','125先着','IFD既知','清算','125C5代用円')]
SCENE_HEADERS=['試行','セッション','参考区分','ザラバ時間h','名目新規可時間h']
for _suffix in ('取得数','最低1取得','全時間頻度','名目新規可時間頻度'):SCENE_HEADERS += [m+_suffix for m in MODELS]
for _policy in POLICIES:SCENE_HEADERS += [_policy+s for s in ('反転数','125順','125逆','125未到達','全H不足','IFD既知','IFD未知','C5利益円','C5損失絶対円','C5既知差引円','C5既知累計円_口座収支ではない','累計IFD未知')]


def sha(path: Path) -> str:
    """
    機能: ファイル指紋を求める。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def selected(r: dict,p: str,axis: str) -> dict:
    """
    機能: native又は実逆の保存streamを選ぶ。
    引数: r(dict)、p/axis(str)は行と政策/軸。
    返り値: dictは候補。T8を再適用しない。
    """
    assert p in POLICIES and axis in AXES and r['model']==MODEL[p]
    return r['case'][('chart_' if axis=='Last' else '')+('reverse' if p=='R0' else 'original')]


def subset(rows: list[dict],p: str,ids: list[str]) -> list[dict]:
    """
    機能: 政策自身の母集団と対象場を選ぶ。
    引数: rows(list[dict])、p(str)、ids(list[str])は全行・政策・場。
    返り値: list[dict]は部分集合。
    """
    return [r for r in rows if r['model']==MODEL[p] and r['session'] in ids]


def load_arithmetic() -> object:
    """
    機能: 凍結124算術を私有importし、政策選択のみ差し替える。
    引数: なし。
    返り値: objectは固定stats/ifd。元ファイルは変更しない。
    """
    assert sha(MODULE)==SOURCES[MODULE]
    spec=importlib.util.spec_from_file_location('138私有124',MODULE);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    m.selected=selected;m.POLICIES=POLICIES
    return m


def prepare(result: dict,fixed: dict,metadata: dict,manifest: dict) -> tuple[list[dict],list[str],dict]:
    """
    機能: 固定入力/参照/manifestへ正逆観測を結合しphaseを検査する。
    引数: result/fixed/metadata/manifest(dict)は保存資料。
    返り値: tupleは全行・73場順・検査件数。
    """
    assert metadata['success'] and metadata['trial']==138 and result['success'] and result['trial']==133
    assert metadata['manifest_sha256']==SOURCES[MANIFEST] and result['source_entry_count']==fixed['expected_entry_count']==833
    mmap={(m['session'],m['id']):m for m in metadata['entries']};assert len(mmap)==833
    rows=[];sessions=[];seen=set();phase=Counter()
    for s,f in zip(result['scenes'],fixed['scenes']):
        sid=s['session'];sessions.append(sid);assert sid==f['session'] and s['success']
        assert s['actual_sha256']==f['raw']['sha256'] and s['quality']==s['expected_quality']==f['expected_quality'] and s['stat_before']==s['stat_after']
        end=f['end']-300;limit=min(f['force_close'],end-3600)
        assert s['execution_end']==end and s['effective_entry_limit']==limit and s['source_force_close']==f['force_close']
        entries={e['id']:e for e in f['entries']};assert len(entries)==len(s['cases'])
        for c in s['cases']:
            key=(sid,c['id']);assert key not in seen and key in mmap;seen.add(key);m=mmap[key];e=entries[c['id']];q=e['entry']
            assert m['model'] in MODELS and m['contract']==f['contract'] and c['id']==m['model']+'/'+m['candidate_id']
            origin=manifest[m['model']][m['manifest_index']]
            assert origin['id']==m['candidate_id'] and origin['session']==sid and origin['contract']==m['contract']
            assert c['original_side']==e['side']==m['selected_side']==origin['side'] and m['origin_count']==len(origin['origins'])
            assert m['baseline'] is origin['baseline']
            assert all(q[k]==origin['entryQuote'][k] for k in ('time','index','source_line','last','bid','ask','quote_ok'))
            clocks={o['entryQuote'].get('clock') for o in origin['origins']}
            assert len(clocks)==1 and q['clock'] in clocks and q['clock']
            assert q['clock'] and q['quote_ok'] and 0<q['bid']<q['ask'] and q['time']<limit
            for name in ('original','reverse','chart_original','chart_reverse'):
                stream=c[name];chart=name.startswith('chart');side=e['side'] if name.endswith('original') else -e['side']
                assert stream['status']=='filled' and stream['entry']==q and stream['birth']['side']==side
                assert stream['entry_price']==(q['last'] if chart else q['ask'] if side>0 else q['bid'])
                phase['stream検査']+=1;phase['entry検査']+=1
                assert [o['seconds'] for o in stream['outcomes']]==list(HORIZONS)
                for o in stream['outcomes']:
                    assert o['deadline']==q['time']+o['seconds'] and [t['width'] for t in o['touches']]==list(WIDTHS)
                    assert (o['endpoint'] is not None)==(o['status']=='complete')
                    if o['endpoint'] is not None:
                        a=o['endpoint'];assert o['deadline']<=a['time']<=o['deadline']+30 and a['time']<end and a['quote_ok'] and 0<a['bid']<a['ask']
                        assert a['index']>q['index'] and a['source_line']>q['source_line'];phase['endpoint検査']+=1
                    for t in o['touches']:
                        assert t['direction'] in (-1,0,1) and (t['quote'] is None)==(t['direction']==0)
                        if t['quote'] is not None:
                            a=t['quote'];assert q['time']<=a['time']<=o['deadline'] and a['time']<end and a['quote_ok'] and 0<a['bid']<a['ask']
                            assert a['index']>q['index'] and a['source_line']>q['source_line'];phase['touch検査']+=1
                    if chart:assert o['net0'] is None and o['net5'] is None
            rows.append({'session':sid,'model':m['model'],'meta':m,'canonical':origin,'case':c,'scene':f})
    assert len(sessions)==len(set(sessions))==73 and len(rows)==833 and seen==set(mmap)
    assert Counter(r['model'] for r in rows)=={'C0':81,'P0':752}
    return rows,sessions,dict(phase)


def frequency(rows: list[dict],sessions: list[str],scenes: list[dict]) -> dict:
    """
    機能: 全場ザラバ時間の加重頻度と場別分布を計算する。
    引数: rows/sessions/scenes(list)は取得と場時計。
    返り値: dictは名目時計による頻度。
    """
    scope={s['session']:s for s in scenes};counts=Counter((r['model'],r['session']) for r in rows);per={}
    for sid in sessions:
        s=scope[sid];h=(s['end']-300-s['start'])/3600;eh=(min(s['force_close'],s['end']-3900)-s['start'])/3600;assert h>0 and eh>0
        per[sid]={'全時間h':h,'名目新規可時間h':eh,'models':{m:{'取得数':counts[m,sid],'全時間頻度':counts[m,sid]/h,'名目新規可時間頻度':counts[m,sid]/eh} for m in MODELS}}
    out={'定義':'全時間=sum(end-300-start)/3600。名目新規可時間=sum(min(force_close,end-3900)-start)/3600は副評価','場別':per,'各場回数cap':False,'毎時強制':False}
    for part,ids in (('all',sessions),('train',sessions[:48]),('validation',sessions[48:])):
        out[part]={};h=sum(per[s]['全時間h'] for s in ids);eh=sum(per[s]['名目新規可時間h'] for s in ids)
        for m in MODELS:
            n=sum(counts[m,s] for s in ids);rates=[per[s]['models'][m]['全時間頻度'] for s in ids]
            out[part][m]={'対象場数':len(ids),'取得数':n,'全時間h':h,'名目新規可時間h':eh,'全時間平均件数毎時':n/h,'名目新規可時間平均件数毎時':n/eh,
                '全時間平均1件毎時以上':n/h>=1,'場別頻度分布':{'最小':min(rates),'中央値':median(rates),'最大':max(rates),'単純平均_主平均ではない':sum(rates)/len(rates),
                '0取得場数':sum(v==0 for v in rates),'1件毎時以上場数':sum(v>=1 for v in rates)}}
    return out


def calculate(rows: list[dict],sessions: list[str],scenes: list[dict],module: object) -> tuple[dict,dict,dict,dict]:
    """
    機能: 3政策180条件と参加・頻度・主判定を固定算術で作る。
    引数: rows/sessions/scenes(list)、module(object)は資料と私有算術。
    返り値: tupleは集計・参加・頻度・主判定。
    """
    values={};participation={}
    for part,ids in (('all',sessions),('train',sessions[:48]),('validation',sessions[48:])):
        values[part]={};participation[part]={}
        for model in MODELS:
            rs=[r for r in rows if r['model']==model and r['session'] in ids];missing=[sid for sid in ids if not any(r['session']==sid for r in rs)]
            participation[part][model]={'対象場数':len(ids),'取得数':len(rs),'取得場数':len(ids)-len(missing),'未取得場数':len(missing),'未取得場':missing,'全場最低1取得':not missing and bool(ids)}
        for p in POLICIES:values[part][p]={a:{str(h):{str(w):module.stats(subset(rows,p,ids),p,a,h,w) for w in WIDTHS} for h in HORIZONS} for a in AXES}
    freq=frequency(rows,sessions,scenes);s=values['all']['P0']['BBO']['3600']['125'];part=participation['all']['P0'];rate=s['target70'] is True;hour=freq['all']['P0']['全時間平均1件毎時以上']
    goal={'主':'P0/native/全73場/実BBO/H60/±125pt','全73場最低1取得':part['全場最低1取得'],'到達済み先着70%以上':rate,
        '入口品質の両条件達成':bool(part['全場最低1取得'] and rate),'全時間平均1件毎時以上':hour,'三項目すべて達成':bool(part['全場最低1取得'] and rate and hour),
        '順':s['forward'],'逆':s['adverse'],'未到達':s['neither'],'全H不足':s['censored'],'到達済み率':s['resolved_rate'],'完了分母率':s['complete_rate'],
        '全件分母率':s['forward']/s['entries'] if s['entries'] else None,'全時間平均件数毎時':freq['all']['P0']['全時間平均件数毎時'],'参加':part}
    return values,participation,freq,goal


def baseline_check(rows: list[dict],values: dict,old: dict,pairs: dict) -> dict:
    """
    機能: C0を旧137A0の選択方向と全60条件へ照合する。
    引数: rows(list[dict])、values/old/pairs(dict)は新旧資料。
    返り値: dictは基準差を明示した同体検査。
    """
    lookup={(s['session'],c['id']):c for s in pairs['scenes'] for c in s['cases']};n=0;labels=0
    for r in rows:
        if r['model']!='C0':continue
        before=lookup[r['session'],r['meta']['candidate_id']];side=r['case']['original_side']
        for name in ('original','reverse','chart_original','chart_reverse'):
            wanted=side if name.endswith('original') else -side;chart=name.startswith('chart')
            prior=before[('chart_' if chart else '')+('original' if wanted==before['original_side'] else 'reverse')]
            for k in ('entry','entry_price','outcomes'):assert r['case'][name][k]==prior[k],(r['case']['id'],name,k)
            labels+=10
        n+=1
    assert n==81;count=0
    for part in ('all','train','validation'):
        for a in AXES:
            for h in HORIZONS:
                for w in WIDTHS:
                    current=copy.deepcopy(values[part]['C0'][a][str(h)][str(w)]);prior=copy.deepcopy(old['集計'][part]['A0'][a][str(h)][str(w)])
                    assert current.pop('flips')==0;prior.pop('flips');assert current==prior,(part,a,h,w);count+=1
    return {'成功':True,'旧137A0件数':n,'4stream全H幅照合':labels,'旧60条件_反転数基準差以外同体':count,
        '反転数基準':'旧Source方向相対から新native方向相対へ変更。C0新0、旧全体31','旧結果変更':False}


def tables(rows: list[dict],sessions: list[str],values: dict,participation: dict,freq: dict,module: object) -> list[dict]:
    """
    機能: 180比較・833入口・73場の型付き3表を作る。
    引数: rows/sessions(list)、values/participation/freq(dict)、module(object)は固定資料。
    返り値: list[dict]は数値/文字列/bool/nullだけの表。
    """
    comparison=[]
    for part in ('all','train','validation'):
        for p in POLICIES:
            v=participation[part][MODEL[p]];f=freq[part][MODEL[p]]
            for a in AXES:
                for h in HORIZONS:
                    for w in WIDTHS:
                        s=values[part][p][a][str(h)][str(w)];quality=bool(v['全場最低1取得'] and s['target70'] is True)
                        comparison.append([138,part,p,MODEL[p],a,h/60,w,v['対象場数'],s['sessions'],s['entries'],s['flips'],v['全場最低1取得'],s['complete'],s['censored'],s['forward'],s['adverse'],s['neither'],
                            s['resolved_rate'],s['complete_rate'],s['forward']/s['entries'] if s['entries'] else None,s['target70'],quality,f['全時間平均件数毎時'],f['名目新規可時間平均件数毎時'],f['全時間平均1件毎時以上'],quality and f['全時間平均1件毎時以上'],
                            s['ifd_known'],s['ifd_unknown'],s['ifd_net0_sum'],s['ifd_net5_profit'],s['ifd_net5_loss'],s['ifd_net5_sum'],s['ifd_net5_mean'],s['ifd_net5_pf']])
    detail=[]
    for r in rows:
        m=r['meta'];c=r['case'];origin=r['canonical'];parents={tuple(o['position_origin']['parent_key']) for o in origin['origins'] if 'parent_key' in o['position_origin']}
        kinds=sorted({o['position_origin']['initial_or_add'] for o in origin['origins'] if o['position_origin'].get('initial_or_add') is not None})
        row=[138,'train' if r['session'] in sessions[:48] else 'validation',r['session'],r['model'],c['id'],m['candidate_id'],c['original_side'],m['baseline'],m['origin_count'],
            '|'.join(sorted({o['family'] for o in origin['origins']})),'|'.join(sorted({o['variant'] for o in origin['origins']})),len(parents),'|'.join(kinds),module.jst(c['original']['entry']['time']),
            c['original']['entry_price'],c['reverse']['entry_price'],module.jst(min(r['scene']['force_close'],r['scene']['end']-3900)),r['scene']['raw']['sha256']]
        for p in POLICIES:
            if r['model']!=MODEL[p]:row += [None]*6;continue
            q=selected(r,p,'BBO');o=module.observation(q,3600);e=module.ifd(q,o,125,'BBO');row += [q['birth']['side'],o['status'],module.touch(o,125)['direction'],e['known'],e['reason'],e['net5']]
        detail.append(row)
    scene_rows=[];cumulative=Counter();unknown=Counter()
    for i,sid in enumerate(sessions):
        f=freq['場別'][sid];row=[138,sid,'train' if i<48 else 'validation',f['全時間h'],f['名目新規可時間h']]
        row += [f['models'][m]['取得数'] for m in MODELS]+[bool(f['models'][m]['取得数']) for m in MODELS]+[f['models'][m]['全時間頻度'] for m in MODELS]+[f['models'][m]['名目新規可時間頻度'] for m in MODELS]
        for p in POLICIES:
            s=module.stats(subset(rows,p,[sid]),p,'BBO',3600,125);cumulative[p]+=s['ifd_net5_sum'] or 0;unknown[p]+=s['ifd_unknown']
            row += [s['flips'],s['forward'],s['adverse'],s['neither'],s['censored'],s['ifd_known'],s['ifd_unknown'],s['ifd_net5_profit'],s['ifd_net5_loss'],s['ifd_net5_sum'],cumulative[p],unknown[p]]
        scene_rows.append(row)
    result=[{'name':'正逆比較','headers':COMPARISON_HEADERS,'rows':comparison},{'name':'入口別診断','headers':DETAIL_HEADERS,'rows':detail},{'name':'全セッション','headers':SCENE_HEADERS,'rows':scene_rows}]
    assert [(len(t['rows']),len(t['headers'])) for t in result]==[(180,34),(833,36),(73,49)]
    assert all(len(set(t['headers']))==len(t['headers']) and all(len(r)==len(t['headers']) and all(v is None or type(v) in (int,float,str,bool) for v in r) for r in t['rows']) for t in result)
    return result


def main() -> None:
    """
    機能: Root F1と明示SHAを先確認してから自然金融だけを集計する。
    引数: CLI --f1/--fixed-input/--metadata/--resultと各-sha256、--output-dir。
    返り値: None。既存出力は上書きしない。
    """
    parser=argparse.ArgumentParser(description='138の金融前固定後集計')
    for n in ('f1','fixed-input','metadata','result'):parser.add_argument('--'+n,required=True,type=Path);parser.add_argument('--'+n+'-sha256',required=True)
    parser.add_argument('--output-dir',required=True,type=Path);args=parser.parse_args()
    paths={n:getattr(args,n.replace('-','_')).resolve() for n in ('f1','fixed-input','metadata','result')};expected={n:getattr(args,n.replace('-','_')+'_sha256') for n in paths}
    assert all(len(h)==64 and all(c in '0123456789abcdef' for c in h) for h in expected.values()) and sha(paths['f1'])==expected['f1']
    f1=json.loads(paths['f1'].read_text(encoding='utf-8'));declared={Path(p).resolve():h for p,h in f1['ファイル'].items()}
    local=[OWN/n for n in ('条件.md','集計する.py','人工検査.py')]
    assert all(declared[p.resolve()]==sha(p) for p in local)
    assert all(declared[p.resolve()]==h and sha(p)==h for p,h in SOURCES.items())
    assert all(declared[paths[n]]==expected[n] for n in ('fixed-input','metadata'))
    checks={**SOURCES,**{paths[n]:expected[n] for n in paths},**{p:sha(p) for p in local}}
    assert all(sha(p)==h for p,h in checks.items())
    dest=args.output_dir;dest.mkdir(parents=True,exist_ok=True);assert not any((dest/n).exists() for n in ('集計.json','CSV用の表.json','集計完了.json'))
    # ----------------------------------------
    # 自然金融の本文はF1・入力・コード・全依存の指紋を確認した後だけ開きます。
    fixed=json.loads(paths['fixed-input'].read_text(encoding='utf-8'));meta=json.loads(paths['metadata'].read_text(encoding='utf-8'));result=json.loads(paths['result'].read_text(encoding='utf-8'))
    assert meta['fixed_input_sha256']==result['input_sha256']==expected['fixed-input']
    manifest=json.loads(MANIFEST.read_text(encoding='utf-8'));rows,sessions,phase=prepare(result,fixed,meta,manifest);module=load_arithmetic()
    values,participation,freq,goal=calculate(rows,sessions,fixed['scenes'],module)
    baseline=baseline_check(rows,values,json.loads(OLD137.read_text(encoding='utf-8')),json.loads(OLD_PAIRS.read_text(encoding='utf-8')))
    result_tables=tables(rows,sessions,values,participation,freq,module)
    out={'成功':True,'試行':138,'主政策':'P0','主評価':goal,'後段engine試行':result['trial'],'全場数':73,'取得集合数':{'P0':752,'C0':81},
        '集計':values,'参加':participation,'頻度':freq,'全4streamのphase検査':phase,'旧C0同体':baseline,
        '異母集団caseペア差':None,'全73場は既使用':True,'独立未知期検証':False,'bootstrap再実装':False,'bootstrap':'今回未計算',
        'F1_SHA256':expected['f1'],'固定入力SHA256':expected['fixed-input'],'入口参照SHA256':expected['metadata'],'自然結果SHA256':expected['result'],
        'manifestSHA256':SOURCES[MANIFEST],'口座収支':False,'実IFD':False,'反転方向の注文適格性再構築':False,
        '数量費用':'独立mini1枚100円/pt、往復77円、C5追加1000円。Last金額null','反転数基準':'native相対。旧137のSource相対とは区別'}
    assert all(sha(p)==h for p,h in checks.items())
    module.save(dest/'集計.json',out);module.save(dest/'CSV用の表.json',{'成功':True,'試行':138,'主政策':'P0','tables':result_tables})
    module.save(dest/'集計完了.json',{'成功':True,'試行':138,'前後SHA256':{str(p):h for p,h in checks.items()},'前後不変':True,
        '表行数':[len(t['rows']) for t in result_tables],'表列数':[len(t['headers']) for t in result_tables],
        '集計SHA256':sha(dest/'集計.json'),'表SHA256':sha(dest/'CSV用の表.json')})
    print(json.dumps({'成功':True,'主評価':goal,'表形状':[(len(t['rows']),len(t['headers'])) for t in result_tables]},ensure_ascii=False))


if __name__=='__main__':main()
