"""138金融集計器の人工検査。自然結果・Raw・CSVは開かない。"""
import copy
import importlib.util
import unittest
from unittest.mock import patch
from pathlib import Path

SPEC=importlib.util.spec_from_file_location('集計138',Path(__file__).with_name('集計する.py'))
M=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(M)


def quote(at: int,index: int,price: int=100) -> dict:
    """
    機能: 正常BBOを持つ人工Quoteを作る。
    引数: at/index/price(int)は価格時計・原行・価格。
    返り値: dictは人工行。
    """
    return {'clock':'人工','time':at,'index':index,'source_line':index+1000,'last':price,'bid':price-1,'ask':price+1,'quote_ok':True}


def candidate(identity: str,side: int,q: dict,chart: bool=False) -> dict:
    """
    機能: 期限だけで清算する人工streamを作る。
    引数: identity(str)、side(int)、q(dict)、chart(bool)はID・向き・取得・軸。
    返り値: dictは自然市場を使わない観測。
    """
    price=q['last'] if chart else q['ask'] if side>0 else q['bid'];outcomes=[]
    for h in M.HORIZONS:
        end=quote(q['time']+h,q['index']+h,110);mark=end['last'] if chart else end['bid'] if side>0 else end['ask'];points=side*(mark-price)
        outcomes.append({'seconds':h,'deadline':q['time']+h,'status':'complete','touches':[{'width':w,'direction':0,'quote':None} for w in M.WIDTHS],
            'endpoint':end,'points':points,'net0':None if chart else points*100-77,'net5':None if chart else points*100-1077})
    return {'status':'filled','birth':{'id':identity,'side':side,'time':q['time'],'index':q['index'],'source_line':q['source_line'],'quote':q},
        'entry':q,'entry_price':price,'outcomes':outcomes}


def fixture() -> tuple[dict,dict,dict,dict]:
    """
    機能: 73場・C081/P0752の人工資料を作る。
    引数: なし。
    返り値: tupleは結果・固定入力・参照・manifest。
    """
    result={'success':True,'trial':133,'source_entry_count':833,'scenes':[]};fixed={'expected_entry_count':833,'scenes':[]}
    metadata={'success':True,'trial':138,'manifest_sha256':M.SOURCES[M.MANIFEST],'entries':[]};manifest={'C0':[],'P0':[]}
    for i in range(73):
        sid=f'人工{i:03d}';raw={'path':'人工・開かない','sha256':'a'*64};quality={'人工':1}
        scene={'session':sid,'contract':'人工限月','start':0,'end':15000,'force_close':14400,'raw':raw,'expected_quality':quality,'expected_accepted':1,'entries':[]}
        out={'session':sid,'success':True,'actual_sha256':'a'*64,'quality':quality,'expected_quality':quality,'stat_before':{'bytes':1},'stat_after':{'bytes':1},
            'execution_end':14700,'effective_entry_limit':11100,'source_force_close':14400,'cases':[]}
        for model,n in (('C0',2 if i<8 else 1),('P0',11 if i<22 else 10)):
            for j in range(n):
                q=quote(100+j,1000+j);side=1 if j%2==0 else -1;identity=f'{sid}/候補{j}';full=model+'/'+identity
                baseline=j<(2 if i<8 else 1)
                origin={'family':'人工family','variant':'人工variant','position_origin':{'initial_or_add':'対象外'},'entryQuote':q}
                c={'id':identity,'session':sid,'contract':'人工限月','side':side,'entryQuote':q,'baseline':baseline,'origins':[origin]}
                m={'id':full,'model':model,'candidate_id':identity,'session':sid,'contract':'人工限月','selected_side':side,'baseline':baseline,'manifest_index':len(manifest[model]),'origin_count':1}
                manifest[model].append(c);metadata['entries'].append(m);scene['entries'].append({'id':full,'side':side,'entry':q})
                out['cases'].append({'id':full,'original_side':side,'original':candidate(full,side,q),'reverse':candidate(full,-side,q),
                    'chart_original':candidate(full,side,q,True),'chart_reverse':candidate(full,-side,q,True)})
        fixed['scenes'].append(scene);result['scenes'].append(out)
    return result,fixed,metadata,manifest


class Tests(unittest.TestCase):
    """F1前の人工算術・母集団・phase・表を検査する。"""
    @classmethod
    def setUpClass(cls) -> None:
        """
        機能: 凍結124コードだけを私有読込する。
        引数: cls(type)はクラス。
        返り値: None。自然結果は読まない。
        """
        cls.module=M.load_arithmetic()

    def test_all_tables_and_populations(self) -> None:
        """
        機能: 833ケース・180条件・3表とnative反転の分母を検査する。
        引数: self(Tests)は検査状態。
        返り値: None。
        """
        result,fixed,metadata,manifest=fixture();rows,sessions,phase=M.prepare(result,fixed,metadata,manifest)
        values,participation,freq,goal=M.calculate(rows,sessions,fixed['scenes'],self.module)
        tables=M.tables(rows,sessions,values,participation,freq,self.module)
        self.assertEqual([(len(t['rows']),len(t['headers'])) for t in tables],[(180,34),(833,36),(73,49)])
        self.assertEqual(values['all']['C0']['BBO']['3600']['125']['entries'],81)
        self.assertEqual(values['all']['P0']['BBO']['3600']['125']['entries'],752)
        self.assertEqual(values['all']['C0']['BBO']['3600']['125']['flips'],0)
        self.assertEqual(values['all']['R0']['BBO']['3600']['125']['flips'],752)
        self.assertTrue(participation['all']['P0']['全場最低1取得']);self.assertEqual(phase['stream検査'],3332)
        self.assertIsNone(values['all']['P0']['Last']['3600']['125']['ifd_net5_sum'])
        self.assertEqual(sum(len(a)*len(h)*len(w) for a in [M.AXES] for h in [M.HORIZONS] for w in [M.WIDTHS]),20)

    def test_legacy_control_side_rebase(self) -> None:
        """
        機能: 旧選択向きを新nativeへ移したC0と旧flipsの基準差を検査する。
        引数: self(Tests)は検査状態。
        返り値: None。
        """
        result,fixed,metadata,manifest=fixture();rows,sessions,_=M.prepare(result,fixed,metadata,manifest)
        values,_,_,_=M.calculate(rows,sessions,fixed['scenes'],self.module);old={'集計':{part:{'A0':copy.deepcopy(v['C0'])} for part,v in values.items()}}
        for part in old['集計']:
            for a in M.AXES:
                for h in M.HORIZONS:
                    for w in M.WIDTHS:old['集計'][part]['A0'][a][str(h)][str(w)]['flips']=31
        pairs={'scenes':[]}
        for scene in result['scenes']:
            cases=[]
            for c in scene['cases']:
                if not c['id'].startswith('C0/'):continue
                cases.append({'id':c['id'][3:],'original_side':-c['original_side'],'original':c['reverse'],'reverse':c['original'],
                    'chart_original':c['chart_reverse'],'chart_reverse':c['chart_original']})
            pairs['scenes'].append({'session':scene['session'],'cases':cases})
        checked=M.baseline_check(rows,values,old,pairs)
        self.assertEqual(checked['旧60条件_反転数基準差以外同体'],60);self.assertEqual(checked['4stream全H幅照合'],3240)

    def test_phase_and_metadata_corruption(self) -> None:
        """
        機能: 参照side不一致とザラバ等号endpointを拒否する。
        引数: self(Tests)は検査状態。
        返り値: None。
        """
        r,f,m,a=fixture();m['entries'][0]['selected_side']*=-1
        with self.assertRaises(AssertionError):M.prepare(r,f,m,a)
        r,f,m,a=fixture();r['scenes'][0]['cases'][0]['original']['outcomes'][0]['endpoint']['time']=14700
        with self.assertRaises(AssertionError):M.prepare(r,f,m,a)

    def test_touch_priority_unknown_costs(self) -> None:
        """
        機能: H不足でも既知touchを優先し、未到達は未知、C5費用を確認する。
        引数: self(Tests)は検査状態。
        返り値: None。
        """
        q=quote(100,1000);c=candidate('人工',1,q);o=c['outcomes'][1];o['status']='gap_censored';o['endpoint']=None
        self.assertFalse(self.module.ifd(c,o,125,'BBO')['known'])
        hit=quote(110,1010,230);o['touches'][3]={'width':125,'direction':1,'quote':hit}
        e=self.module.ifd(c,o,125,'BBO');self.assertTrue(e['known']);self.assertEqual(e['points'],128);self.assertEqual(e['net0'],12723);self.assertEqual(e['net5'],11723)
        self.assertIsNone(self.module.ifd(c,o,125,'Last')['net5'])

    def test_unknown_sha_before_io(self) -> None:
        """
        機能: F1未知SHAを入力読取より前に拒否することを検査する。
        引数: self(Tests)は検査状態。
        返り値: None。自然金融は開かない。
        """
        args=['集計する.py']
        for n in ('f1','fixed-input','metadata','result'):args += ['--'+n,'存在しない人工.json','--'+n+'-sha256','unknown']
        args += ['--output-dir','未作成の人工出力']
        with patch('sys.argv',args),patch.object(M,'sha',side_effect=RuntimeError('読取に進んだ')):
            with self.assertRaises(AssertionError):M.main()


if __name__=='__main__':unittest.main(verbosity=2)
