"""138の非金融manifestを価格側固定の正逆観測入力へ射影する。"""
from pathlib import Path
from collections import Counter
import copy
import gzip
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parent.parent
OWN = ROOT / 'work/138全成立入口の評価'
MANIFEST = ROOT / 'work/全成立poolの非金融manifest/manifest.json'
MANIFEST_SHA = 'e7ba444fd66f9ca52e10e929eeb31d21076f97afa161de738dabca14a8ff8e35'
BASE = ROOT / 'inputs/00124_同入口正逆の共用入力/入力.json.gz'
BASE_DECODED_SHA = 'b2368b1f42c16e8c96a3acd098c58a902807a3b6a5023d6d4b1e75261f3ee51b'


def sha(data: bytes) -> str:
    """
    機能: バイト列のSHA256を算出する。
    引数: data(bytes)は検査する内容。
    返り値: strは16進指紋。
    """
    return hashlib.sha256(data).hexdigest()


# ----------------------------------------
def save(path: Path, data: dict) -> str:
    """
    機能: 新規JSONをUTF-8で一度保存する。
    引数: path(Path)は保存先、data(dict)は値。
    返り値: strは保存ファイルのSHA256。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(data, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')
    return sha(path.read_bytes())


# ----------------------------------------
def stamp(quote: dict) -> tuple:
    """
    機能: 価格時計と採用順、物理行の固定キーを検査する。
    引数: quote(dict)は保存Quote。
    返り値: tupleは時刻、採用順、物理行。
    """
    assert type(quote['time']) in (int, float) and math.isfinite(quote['time'])
    assert type(quote['index']) is int and quote['index'] >= 0
    assert type(quote['source_line']) is int and quote['source_line'] > 0
    return tuple(quote[k] for k in ('time', 'index', 'source_line'))


# ----------------------------------------
def main() -> None:
    """
    機能: 条件不変の833観測入力と出生別の特徴照会を作る。
    引数: なし。金融・原板・CSVは読み込まない。
    返り値: None。入力指紋または因果関係の不一致は停止する。
    """
    manifest_bytes = MANIFEST.read_bytes()
    assert sha(manifest_bytes) == MANIFEST_SHA
    manifest = json.loads(manifest_bytes)
    assert manifest['success'] and manifest['financial_labels_used'] is False
    assert [len(manifest[k]) for k in ('C0', 'P0')] == [81, 752]
    for name, expected in manifest['sources'].items():
        assert sha((ROOT / name).read_bytes()) == expected, name
    base_bytes = gzip.decompress(BASE.read_bytes())
    assert sha(base_bytes) == BASE_DECODED_SHA
    base = json.loads(base_bytes)
    scenes = copy.deepcopy(base['scenes'])
    assert len(scenes) == 73
    by_session = {s['session']: s for s in scenes}
    assert len(by_session) == 73
    for scene in scenes:
        scene['entries'] = []
    metadata = []
    queries = {}
    relations = []
    for model in ('C0', 'P0'):
        seen = set()
        for index, candidate in enumerate(manifest[model]):
            scene = by_session[candidate['session']]
            assert candidate['contract'] == scene['contract']
            q = candidate['entryQuote']
            entry_stamp = stamp(q)
            assert q['quote_ok'] is True and 0 < q['bid'] < q['ask'] and q['last'] > 0
            assert scene['start'] <= q['time'] < min(scene['force_close'], scene['end'] - 3900)
            key = (candidate['session'], *entry_stamp)
            assert key not in seen
            seen.add(key)
            side = candidate['side']
            assert type(side) is int and side in (-1, 1)
            identity = model + '/' + candidate['id']
            clocks = {o['entryQuote']['clock'] for o in candidate['origins']}
            assert len(clocks) == 1 and all(isinstance(c, str) and c for c in clocks)
            kernel_quote = copy.deepcopy(q)
            kernel_quote['clock'] = next(iter(clocks))
            if 'clock' in q:
                assert q['clock'] == kernel_quote['clock']
            scene['entries'].append({'id': identity, 'side': side, 'entry': kernel_quote})
            metadata.append({'id': identity, 'model': model, 'candidate_id': candidate['id'],
                'session': candidate['session'], 'contract': candidate['contract'], 'selected_side': side,
                'baseline': candidate['baseline'], 'manifest_index': index,
                'origin_count': len(candidate['origins']), 'origin_families': sorted({o['family'] for o in candidate['origins']})})
            for origin_index, origin in enumerate(candidate['origins']):
                assert origin['raw_ref']['sha256'] == scene['raw']['sha256']
                assert Path(origin['raw_ref']['path']) == Path(scene['raw']['path'])
                assert stamp(origin['entryQuote']) == entry_stamp
                assert all(origin['entryQuote'][k] == q[k] for k in ('last', 'bid', 'ask', 'quote_ok'))
                b = origin['birthQuote']
                bs = stamp(b)
                assert all(x <= y for x, y in zip(bs, entry_stamp))
                assert scene['start'] <= b['time'] < min(scene['force_close'], scene['end'] - 3900)
                assert b['last'] > 0 and origin['side'] in (-1, 1)
                query_key = json.dumps([origin['source_file_sha'], origin['source_locator'],
                    origin['side'], bs], ensure_ascii=False, sort_keys=True, separators=(',', ':'))
                query_id = 'origin/' + sha(query_key.encode('utf-8'))[:32]
                query = {'id': query_id, 'session': candidate['session'], 'contract': candidate['contract'],
                    'side': origin['side'], 'birthQuote': {k: b[k] for k in ('time', 'index', 'source_line', 'last')}}
                if query_id in queries:
                    assert queries[query_id] == query
                else:
                    queries[query_id] = query
                relations.append({'entry_id': identity, 'query_id': query_id, 'model': model,
                    'manifest_index': index, 'origin_index': origin_index, 'family': origin['family'],
                    'side': origin['side'], 'selected_side': side})
    for scene in scenes:
        scene['entries'].sort(key=lambda e: (*stamp(e['entry']), e['id']))
    assert len(metadata) == 833 and len({m['id'] for m in metadata}) == 833
    for model in ('C0', 'P0'):
        counts = Counter(m['session'] for m in metadata if m['model'] == model)
        assert set(counts) == set(by_session) and min(counts.values()) >= 1
    fixed_sha = save(OWN / '固定入力_版2/固定取得入力.json', {'scenes': scenes, 'expected_entry_count': 833})
    meta_sha = save(OWN / '固定入力_版2/入口参照.json', {'success': True, 'trial': 138,
        'manifest_sha256': MANIFEST_SHA, 'fixed_input_sha256': fixed_sha, 'entries': metadata})
    query_sha = save(OWN / '固定入力_版2/特徴照会.json', {'success': True, 'trial': 138,
        'manifest_sha256': MANIFEST_SHA, 'queries': list(queries.values()), 'relations': relations})
    proof = {'成功': True, '試行': 138, '金融未読': True, 'Raw_CSV未読': True,
        'manifest_SHA256': MANIFEST_SHA, '固定入力SHA256': fixed_sha, '入口参照SHA256': meta_sha,
        '特徴照会SHA256': query_sha, '観測数': 833, '出生照会数': len(queries),
        '照会対応数': len(relations), 'C0': 81, 'P0': 752,
        'kernel_originalは選択方向': True, '異なる出生の単一化': False,
        '時計文字列は各origin保存値を一致確認して復元': True,
        '金融前補修': '初回canonicalに省略されたclockを復元。数値時点と方向、出生照会は不変更。',
        'コードSHA256': sha(Path(__file__).read_bytes())}
    proof_sha = save(OWN / '固定入力_版2/転送の確認.json', proof)
    print(json.dumps({**proof, '確認SHA256': proof_sha}, ensure_ascii=False))


if __name__ == '__main__':
    main()
