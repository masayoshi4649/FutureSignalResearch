"""閲覧保存後のpending解消と最終説明の現在版を読み取り確認する。"""
from pathlib import Path
import hashlib
import json
import re

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 対象ファイルの現在の全byte指紋を計算する。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def main() -> None:
    """
    機能: 前の確認票を保持し、4リンク・現在説明・CSV非変更を最終票へ記録する。
    引数: なし。再探索・元金融再計算・マーカー実行は行わない。
    返り値: None。最終範囲と説明の完了.jsonを追加する。
    """
    previous=HERE/'最終範囲と説明の確認.json';old=json.loads(previous.read_bytes())
    assert old['成功'] and len(old['保存待ちリンク_pending'])==4
    resolved=[]
    for ref in old['保存待ちリンク_pending']:
        source=ROOT/ref['文書'];target=(source.parent/ref['リンク']).resolve()
        assert target.is_file();resolved.append({**ref,'解消':True,'対象SHA256':sha(target)})
    documents=[ROOT/p for p in old['Sourceと対象'] if p.endswith('.md')]
    current={p.relative_to(ROOT).as_posix():sha(p) for p in documents}
    for path,limit in ((ROOT/'README.md',12),(ROOT/'docs/README.md',12),(ROOT/'study/README.md',16)):
        head='\n'.join(path.read_text(encoding='utf-8').splitlines()[:limit])
        assert not any(word in head for word in ('進行中','比較中','確認中','継続検証中'))
    csv_refs={p:h for p,h in old['Sourceと対象'].items() if p.endswith('.csv')}
    assert len(csv_refs)==4 and all(sha(ROOT/p)==h for p,h in csv_refs.items())
    trial=ROOT/'study/00171_三時間帯で順行と回復失敗の確認を切り替える'
    viewer=trial/'閲覧資料.md';text=viewer.read_text(encoding='utf-8')
    for phrase in ('出口診断','数量枠を再生していない','609','972,107','3,350,000','既使用','全件収支','独立の未見検証とは呼ばない'):
        assert phrase in text,phrase
    for link in re.findall(r'\[[^\]]+\]\(([^)]+)\)',text):
        if '://' in link or link.startswith('#'):continue
        assert (viewer.parent/link.strip('<>').split('#')[0]).exists(),link
    discussion=(ROOT/'docs/議論/三帯の複合入口を有望候補として一旦止める.md').read_text(encoding='utf-8')
    for phrase in ('609','4,322,107','972,107','3,350,000','数量枠から再生した別の運用収支ではない','67.442','既使用'):
        assert phrase in discussion,phrase
    stop=trial/'検査/閲覧資料/閲覧資料の停止.json'
    assert sha(stop)=='28d59426a9cf02e6988acf5232b1d768e42a8951fde211d57047909c679c2a20'
    result={'成功':True,'確認日':'2026-11-15','旧確認票SHA256':sha(previous),'旧確認票を保持':True,
        '解消した4リンク':resolved,'保存待ちリンク_pending':[],'現在のglobal指紋':current,
        '閲覧資料SHA256':sha(viewer),'閲覧資料の停止SHA256':sha(stop),'CSV4正本不変':csv_refs,
        '説明Scope整合':True,'旧進行中表現解消':True,'共通知見の共通既知ペア説明整合':True,
        '元金融再計算_探索_マーカー_元資料変更':False,
        '範囲':'pending4解消・現在global/閲覧説明だけの最終読み取り確認。171主保存の停止検査を代行したものではない。'}
    path=HERE/'最終範囲と説明の完了.json';path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'pending':0,'完了票SHA256':sha(path)},ensure_ascii=False))


if __name__=='__main__':
    main()
