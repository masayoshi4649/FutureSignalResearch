"""171の停止判断・公開目次・閲覧CSVの分母と説明範囲を読み取り監査する。"""
from pathlib import Path
from collections import Counter
import csv
import hashlib
import json
import math
import re

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
OUT=ROOT/'outputs/00171_複合入口と数量枠の比較'
MAIN=ROOT/'docs/議論/三帯の複合入口を有望候補として一旦止める.md'


def sha(path: Path) -> str:
    """
    機能: 読み取り対象の全byteを指紋化する。
    引数: path(Path)は対象ファイル。
    返り値: strはSHA256。
    """
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def number(value: str) -> float|None:
    """
    機能: CSVの空欄を数値0へせず未定義として読む。
    引数: value(str)は数値列文字列。
    返り値: float又はNoneは数値又は空欄。
    """
    return float(value) if value!='' else None


def main() -> None:
    """
    機能: 主要値・未知・数量・頻度・固定範囲とリンクを独立に確認する。
    引数: なし。新規データ・探索・CSV/文書編集を行わない。
    返り値: None。成功点と保存待ちリンクを区別した監査票をworkへ保存する。
    """
    documents=[MAIN,ROOT/'README.md',ROOT/'docs/README.md',ROOT/'docs/議論/README.md',ROOT/'study/README.md',ROOT/'AGENTS.md']
    csv_paths=[OUT/name for name in ('候補比較.csv','全セッション.csv','時間帯別.csv','条件一覧.csv')]
    before={p.relative_to(ROOT).as_posix():sha(p) for p in [Path(__file__),*documents,*csv_paths]}
    tables={}
    for path in csv_paths:
        with path.open(encoding='utf-8-sig',newline='') as stream:
            reader=csv.DictReader(stream);rows=list(reader);headers=reader.fieldnames
        assert headers and len(headers)==len(set(headers)) and all(None not in row for row in rows)
        tables[path.stem]={'headers':headers,'rows':rows}
    comparison=tables['候補比較']['rows'];sessions=tables['全セッション']['rows'];bands=tables['時間帯別']['rows']
    assert len({row['候補ID'] for row in comparison})==22
    full=next(row for row in comparison if row['候補ID']=='171_MAIN' and row['期間']=='全80場')
    expected={'対象場数':80,'取得数':644,'参加場数':80,'順先着F':230,'逆先着A':81,'未到達N':298,'観測不足C':35,
              '損益既知数':609,'費用後勝ち数':385,'費用後負け数':224,'既知利益_円':7760355,'既知損失_円':3438248,'既知差引_円':4322107}
    for name,value in expected.items():assert number(full[name])==value,name
    assert math.isclose(number(full['到達済み先着率_pct']),100*230/311,rel_tol=1e-12)
    assert math.isclose(number(full['既知決済勝率_pct']),100*385/609,rel_tol=1e-12)
    hours=793+20/60
    assert math.isclose(number(full['回毎時']),644/hours,rel_tol=1e-12) and full['全件収支_円']==''
    rows=[row for row in sessions if row['候補ID']=='171_MAIN'];assert len(rows)==80 and len({row['セッション'] for row in rows})==80
    assert all(number(row['取得数'])>=1 for row in rows)
    for name in ('取得数','順先着F','逆先着A','未到達N','観測不足C','損益既知数','費用後勝ち数','費用後負け数','既知利益_円','既知損失_円','既知差引_円'):
        assert sum(number(row[name]) for row in rows)==expected[name],name
    assert number(rows[-1]['既知累計差引_円'])==4322107 and number(rows[-1]['累計観測不足C'])==35 and rows[-1]['全件累計収支_円']==''
    # 数値は別担当が元NPZ全接続を検算済み。本監査は全行の意味/加法/未定義保持を確認する。
    for tab in ('候補比較','全セッション','時間帯別'):
        for row in tables[tab]['rows']:
            count=number(row['取得数']);f=number(row['順先着F']);a=number(row['逆先着A']);n=number(row['未到達N']);c=number(row['観測不足C'])
            assert count==f+a+n+c and number(row['損益既知数'])+c==count
            assert number(row['既知利益_円'])-number(row['既知損失_円'])==number(row['既知差引_円'])
            rate=number(row['到達済み先着率_pct'])
            if f+a:assert math.isclose(rate,100*f/(f+a),rel_tol=1e-12)
            else:assert rate is None
            if c:assert row['全件収支_円']==''
            else:assert number(row['全件収支_円'])==number(row['既知差引_円'])
    text=MAIN.read_text(encoding='utf-8')
    for phrase in ('研究上の有望候補','一旦止める','前48','67.442','null','既使用','新規独立未見とは呼ばない',
                   '将来の70%再現','全件確定収支と称さない','各要求mini一枚','未決予約','385/609',
                   '単純IFD','利益保護'):
        assert phrase in text,phrase
    # 主張の値はCSVの当該q0帯と一致。支持と赤字を隠していない。
    front=next(row for row in comparison if row['候補ID']=='171_MAIN' and row['期間']=='旧73場・前48場')
    assert math.isclose(number(front['到達済み先着率_pct']),100*87/129,rel_tol=1e-12)
    ny_old=next(row for row in bands if row['候補ID']=='171_MAIN' and row['期間']=='旧73場' and row['分類時計']=='q0出生' and row['時間帯']=='ナイト米国前')
    ny_new=next(row for row in bands if row['候補ID']=='171_MAIN' and row['期間']=='追加7場' and row['分類時計']=='q0出生' and row['時間帯']=='ナイト米国前')
    assert number(ny_old['既知差引_円'])==-47396 and number(ny_new['既知差引_円'])==-68694
    conditions='\n'.join(' '.join(row.values()) for row in tables['条件一覧']['rows'])
    for phrase in ('各1枚','買売各10枚','未決予約','既使用','全件収支','同取得125','数量再生なし','出口診断'):
        assert phrase in conditions,phrase
    # 全リンクを機械確認し、新規保存中の171資料と無関係な既存リンクを区別する。
    pending=[];missing=[];work_links=[];links=0
    for path in documents:
        body=path.read_text(encoding='utf-8');assert '\ufffd' not in body
        for target in re.findall(r'\[[^\]]+\]\(([^)]+)\)',body):
            target=target.strip('<>')
            if '://' in target or target.startswith('#'):continue
            resolved=(path.parent/target.split('#')[0]).resolve();links+=1
            if 'work' in resolved.parts:work_links.append({'文書':path.relative_to(ROOT).as_posix(),'リンク':target})
            if not resolved.exists():
                item={'文書':path.relative_to(ROOT).as_posix(),'リンク':target}
                if '00171_' in str(resolved) and resolved.name in ('閲覧資料.md','保存索引.json','Source.zip'):
                    pending.append(item)
                else:missing.append(item)
    assert not work_links
    # 更新対象の目次先頭は完了形。旧試行本文の当時の未達判定には介入しない。
    stale=[]
    for path,limit in ((ROOT/'README.md',12),(ROOT/'docs/README.md',12),(ROOT/'study/README.md',16)):
        head='\n'.join(path.read_text(encoding='utf-8').splitlines()[:limit])
        if any(word in head for word in ('進行中','比較中','確認中','継続検証中')):stale.append(path.relative_to(ROOT).as_posix())
    assert all(sha(ROOT/path)==value for path,value in before.items())
    result={'成功':not missing and not stale,'読み取り監査':True,'Sourceと対象':before,
        '主要値_分母_全80加法':True,'先着率と決済勝率を区別':True,'未知全収支空欄':True,'数量_費用_頻度':True,
        '旧前半とNY前赤字_A_B_nullを明記':True,'追加7既使用_未見保証しない':True,
        '125固定は後続ユーザー指示で解除済み':True,'新探索だけを一旦停止_実運用自動注文の達成ではない':True,
        '四CSV行数':{name:len(value['rows']) for name,value in tables.items()},
        '全CSVセル数_ヘッダー込み':sum((len(v['rows'])+1)*len(v['headers']) for v in tables.values()),
        '確認リンク数':links,'workだけの恒久リンク':work_links,'保存待ちリンク_pending':pending,'他のリンク切れ':missing,
        '目次の旧現況残り':stale,'元資料変更':False,
        '範囲':'財務数値の元NPZ全接続QAは閲覧担当の別票。こちらは分母/説明/加法/リンクを監査し、CSV生成又はmarkerを実行しない。'}
    (HERE/'最終範囲と説明の確認.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':result['成功'],'pending':pending,'missing':missing,'stale':stale,'票SHA256':sha(HERE/'最終範囲と説明の確認.json')},ensure_ascii=False))


if __name__=='__main__':
    main()
