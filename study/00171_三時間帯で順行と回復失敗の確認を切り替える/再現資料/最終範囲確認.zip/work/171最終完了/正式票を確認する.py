"""主保存・閲覧保存・最終範囲の停止票を確認して根拠を恒久保存する。"""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[2]
TRIAL=ROOT/'study/00171_三時間帯で順行と回復失敗の確認を切り替える'


def sha(path: Path) -> str:
    """
    機能: 停止票と成果物の全物理内容を指紋化する。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    with path.open('rb') as source:return hashlib.file_digest(source,'sha256').hexdigest()


def read(path: Path) -> dict:
    """
    機能: UTF-8の検査票を読み込む。
    引数: path(Path)。
    返り値: dictはJSON内容。
    """
    return json.loads(path.read_text(encoding='utf-8'))


def main() -> None:
    """
    機能: 完了済み独立票・正式停止票・CSV正本を最終照合し、範囲確認を正規資源へ移す。
    引数: なし。新規探索や金融再計算は行わない。
    返り値: None。最終範囲確認ZIPと最終完了確認JSONを保存する。
    """
    main_stop=TRIAL/'検査/主保存の停止.json'
    assert sha(main_stop)=='8d13b91349aa1d313eb3429787f6bc241bf0a4f1605812be0a9565a1da798fb5'
    stopped=read(main_stop);assert stopped['成功']
    for ref in stopped['主保存ファイル']:
        path=ROOT/ref['path'];assert path.stat().st_size==ref['bytes'] and sha(path)==ref['sha256']
    view_stop=TRIAL/'検査/閲覧資料/閲覧資料の停止.json'
    assert read(view_stop)['成功'] and sha(view_stop)=='28d59426a9cf02e6988acf5232b1d768e42a8951fde211d57047909c679c2a20'
    scope_dir=ROOT/'work/171最終範囲確認';scope_path=scope_dir/'最終範囲と説明の完了.json'
    assert sha(scope_path)=='144e5d8b36bd384e9e21f49a5a36df97e0b281f674502eca0606d8167597c67f'
    scope=read(scope_path);assert scope['成功'] and scope['保存待ちリンク_pending']==[]
    for mapping in (scope['現在のglobal指紋'],scope['CSV4正本不変']):
        for name,digest in mapping.items():assert sha(ROOT/name)==digest,name
    output=ROOT/'outputs/00171_複合入口と数量枠の比較'
    assert len(list(output.iterdir()))==4 and all(p.suffix=='.csv' for p in output.iterdir())
    archive=TRIAL/'再現資料/最終範囲確認.zip';assert not archive.exists()
    paths=list(sorted(scope_dir.iterdir()))+[Path(__file__)]
    refs={p.relative_to(ROOT).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in paths if p.is_file()}
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as package:
        for name in refs:package.write(ROOT/name,arcname=name)
    with zipfile.ZipFile(archive) as package:
        assert package.testzip() is None and set(package.namelist())==set(refs)
        for name,ref in refs.items():assert hashlib.sha256(package.read(name)).hexdigest()==ref['sha256']
    completed={'成功':True,'確認日':'2026-11-15','新探索を一旦終了':True,
        '主保存停止':{'path':main_stop.relative_to(ROOT).as_posix(),'sha256':sha(main_stop)},
        '閲覧資料停止':{'path':view_stop.relative_to(ROOT).as_posix(),'sha256':sha(view_stop)},
        '最終範囲独立票':{'sha256':sha(scope_path),'保存先':archive.relative_to(ROOT).as_posix()},
        '最終範囲ZIP':{'bytes':archive.stat().st_size,'sha256':sha(archive),'members':refs},
        'CSV正本':scope['CSV4正本不変'],'現在のglobal指紋':scope['現在のglobal指紋'],
        '注意':'研究段階の有望固定入口。全件収支は未知35件を含み未確定。前半/米国前の弱さ・追加期の既使用性を維持する。'}
    target=TRIAL/'検査/最終完了確認.json';assert not target.exists()
    target.write_text(json.dumps(completed,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'主停止同体ファイル':len(stopped['主保存ファイル']),
        '最終範囲ZIP_member':len(refs),'CSV':4,'最終完了SHA256':sha(target)},ensure_ascii=False))


if __name__=='__main__':
    main()
