"""取得参照と共用金融配列から閲覧四表を独立に検算する。"""
from pathlib import Path
from collections import Counter
from datetime import datetime
from zoneinfo import ZoneInfo
import argparse
import csv
import gzip
import hashlib
import io
import json
import math
import sys
import zipfile

import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
INPUTS={}
ARCHIVES=[]
METRICS=('取得数','参加場数','回毎時','順先着F','逆先着A','未到達N','観測不足C',
    '到達済み先着率_pct','損益既知数','費用後勝ち数','費用後負け数','既知決済勝率_pct',
    '既知利益_円','既知損失_円','既知差引_円','PF_利益÷損失','旧C1以外取得数','旧C1取得数','全件収支_円')


def digest(body: bytes) -> str:
    """
    機能: 全物理バイトの指紋を計算する。
    引数: body(bytes)はファイルの内容。
    返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


def source(name: str) -> bytes:
    """
    機能: 正式資源又は正式ZIP内の元パスを指紋付きで読む。
    引数: name(str)はリポジトリ相対の原パス。
    返り値: bytesはCRC確認済みZIPメンバー又は元ファイル。
    """
    canonical=name
    if name.startswith('work/167固定入口の別期間/比較/'):
        canonical=name.replace('work/167固定入口の別期間/比較/',
            'study/00167_固定した複合入口を追加七場へ適用する/成果物/',1)
    target=ROOT/canonical
    matches=[(path,name) for path,names in ARCHIVES if name in names]
    if name.startswith('work/') and matches:
        path,member=matches[0]
        with zipfile.ZipFile(path) as archive:body=archive.read(member)
        resolved={'archive':path.relative_to(ROOT).as_posix(),'member':member}
    else:
        body=target.read_bytes();resolved={'path':canonical}
    INPUTS[name]={**resolved,'bytes':len(body),'sha256':digest(body)}
    return body


def read(name: str) -> dict:
    """
    機能: 正本JSONをgzipのCRCまで確認して読む。
    引数: name(str)は原パス。
    返り値: dictはJSON内容。
    """
    body=source(name)
    return json.loads(gzip.decompress(body) if body[:2]==b'\x1f\x8b' else body)


def save(name: str,value: dict) -> None:
    """
    機能: 独立検査の結果だけを日本語JSONへ保存する。
    引数: name(str)は新出力名、value(dict)は有限値とnullの内容。
    返り値: None。CSVや元正本は変更しない。
    """
    (HERE/name).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')


def ny_open(session: str) -> float:
    """
    機能: セッション日の米国09:30を夏冬時間込みで求める。
    引数: session(str)はセッション名。
    返り値: floatはUTC秒。
    """
    return datetime.fromisoformat(session[:10]+'T09:30').replace(tzinfo=ZoneInfo('America/New_York')).timestamp()


def phase(session: str,at: float) -> int:
    """
    機能: 出生又は取得の時刻を三帯へ分ける。
    引数: session(str)、at(float)はUTC秒。
    返り値: intはデイ0、米国前1、以後2。
    """
    return 0 if session.endswith('_Day') else 1 if at<ny_open(session) else 2


def load_period(new: bool) -> dict:
    """
    機能: 正式の出生・100列順序・共用金融配列を結ぶ。
    引数: new(bool)は追加七場を選ぶフラグ。
    返り値: dictは場順・q0順・数値配列・全ザラバ時間。
    """
    base='inputs/00167_追加七場の入口と共用価格索引' if new else 'inputs/00148_全1分入口母集団'
    population=base+'/入口母集団' if new else base
    ledger=read(population+'/出生台帳.json.gz')
    features=read(population+'/当時特徴.json.gz')
    numeric=base+'/自然数値表' if new else 'inputs/00163_任意幅の共用価格索引/数値表'
    meta=read(numeric+'/任意幅識別.json.gz')
    with np.load(io.BytesIO(source(numeric+'/任意幅配列.npz')),allow_pickle=False) as z:
        arrays={k:z[k].copy() for k in ('label','direction','known','net5','entry_time','session_index')}
    scenes=ledger['scenes'];sessions=[s['session'] for s in scenes]
    assert sessions==meta['session_order']
    events=[{'id':r['event_id'],'session':r['session'],'at':r['metadata']['q0']['time']} for r in features['rows']]
    hours=[]
    for scene in scenes:
        start=scene['start'];end=scene['end']-300
        if scene['session'].endswith('_Day'):hours.append(((end-start)/3600,0,0))
        else:
            split=ny_open(scene['session'])
            hours.append((0,max(0,min(end,split)-start)/3600,max(0,end-max(split,start))/3600))
    return {'new':new,'meta':meta,'arrays':arrays,'events':events,'scenes':scenes,'sessions':sessions,'hours':hours}


def selections(record: dict,context: dict,uniform: int|None=None) -> list:
    """
    機能: 固定取得参照を実側と出生時計を保った一件列へする。
    引数: record(dict)、context(dict)、uniform(int|None)は任意の対照幅。
    返り値: list[dict]は金融値をまだ集計していない取得列。
    """
    result=[]
    for i,case in enumerate(record['cases']):
        side=record['sides'][i];event=record['events'][i]
        assert side in (0,1) and event>=0
        row={'case':case,'side':side,'event':event,'wi':record['widths'][i],
             'origin':record.get('origins',[0]*len(record['cases']))[i]}
        if uniform is not None:row['wi']=context['meta']['widths'].index(uniform)
        result.append(row)
    assert len({r['case'] for r in result})==len(result)
    return result


def financial(rows: list,context: dict,hi: int) -> list:
    """
    機能: 各取得を原配列へ直接結びIFD_FIRSTと既知損益を作る。
    引数: rows(list[dict])、context(dict)、hi(int)は期限添字。
    返り値: list[dict]はq0/q1帯・FANC・損益既知を含む。
    """
    result=[];a=context['arrays'];meta=context['meta']
    for row in rows:
        case,side,wi=row['case'],row['side'],row['wi'];key=(case,side,wi,hi)
        known=bool(a['known'][key]);direction=int(a['direction'][key]);strict=int(a['label'][key])
        label=direction if known and direction in (-1,1) else 0 if strict==0 else 2
        assert (label==2)==(not known)
        money=int(a['net5'][key]);assert known or money==0
        si=int(a['session_index'][case]);session=context['sessions'][si]
        assert meta['sessions'][case]==session
        if row['event'] is None:q0=row['q0']
        else:
            event=context['events'][row['event']];assert event['session']==session;q0=event['at']
        result.append({**row,'label':label,'known':known,'net':money if known else None,'scene':si,
            'q0':phase(session,q0),'q1':phase(session,float(a['entry_time'][case]))})
    return result


def summarize(rows: list,context: dict,eligible: list,band: int|None=None,clock: str|None=None) -> dict:
    """
    機能: 単純ループで件数・率・既知利益損失を集計する。
    引数: rows(list[dict])、context(dict)、eligible(list[int])、band(int|None)、clock(str|None)。
    返り値: dictはCSVの共通19列に対応する値。
    """
    hours=sum(sum(context['hours'][s]) if band is None else context['hours'][s][band] for s in eligible)
    use=[r for r in rows if r['scene'] in eligible and (band is None or r[clock]==band)]
    labels=Counter(r['label'] for r in use);money=[r['net'] for r in use if r['known']]
    f,a,n,c=(labels[v] for v in (1,-1,0,2));profit=sum(max(v,0) for v in money);loss=-sum(min(v,0) for v in money)
    count=len(use);old=sum(r['origin']==1 for r in use)
    assert count==f+a+n+c and count==len(money)+c
    return dict(zip(METRICS,[count,len({r['scene'] for r in use}),count/hours if hours else None,f,a,n,c,
        100*f/(f+a) if f+a else None,len(money),sum(v>0 for v in money),sum(v<0 for v in money),
        100*sum(v>0 for v in money)/len(money) if money else None,profit,loss,profit-loss,
        profit/loss if loss else None,count-old,old,profit-loss if c==0 else None],strict=True))


def compare(got: dict,want: dict,where: object) -> int:
    """
    機能: 未知を同一視せず独立計算と表の各数値を照合する。
    引数: got/want(dict)は共通列、where(object)は失敗箇所。
    返り値: intは照合した列数。
    """
    for name,value in want.items():
        other=got[name]
        if value is None:assert other is None,(where,name,other,value)
        elif isinstance(value,int):assert other==value,(where,name,other,value)
        else:assert other is not None and math.isclose(other,value,rel_tol=1e-12,abs_tol=1e-10),(where,name,other,value)
    return len(want)


def pairs(rows: list,context: dict,hi: int) -> dict:
    """
    機能: 同一case・実側・期限で両出口が金融既知の集合を比較する。
    引数: rows(list[dict])は主案固定取得、context(dict)、hi(int)。
    返り値: dictは共通既知と除外集合の件数・利益損失・差引。
    """
    a=context['arrays'];wi125=context['meta']['widths'].index(125);groups={k:[] for k in ('both','main_only','125_only','neither')}
    for r in rows:
        left=(r['case'],r['side'],r['wi'],hi);right=(r['case'],r['side'],wi125,hi)
        lk,rk=bool(a['known'][left]),bool(a['known'][right]);name='both' if lk and rk else 'main_only' if lk else '125_only' if rk else 'neither'
        groups[name].append((int(a['net5'][left]) if lk else None,int(a['net5'][right]) if rk else None))
    def accounting(index: int) -> dict:
        """
        機能: 共通既知集合の一方の出口だけを会計集計する。
        引数: index(int)は主案0又は同取得125の1。
        返り値: dictは件数・利益・損失・差引。
        """
        money=[p[index] for p in groups['both']];profit=sum(max(v,0) for v in money);loss=-sum(min(v,0) for v in money)
        return {'件数':len(money),'利益_円':profit,'損失_円':loss,'差引_円':profit-loss}
    main=accounting(0);control=accounting(1)
    return {'同一取得数':len(rows),'両金融既知数':len(groups['both']),'主案のみ既知数':len(groups['main_only']),
        '125のみ既知数':len(groups['125_only']),'両未知数':len(groups['neither']),
        '主案_共通既知':main,'同取得125_共通既知':control,'共通既知差引差_円':main['差引_円']-control['差引_円'],
        '集合照合SHA256':digest(json.dumps([(context['meta']['case_ids'][r['case']],r['side'],r['wi'],hi) for r in rows],separators=(',',':')).encode())}


def validate_old_controls(legacy: dict,context: dict) -> dict:
    """
    機能: 旧C1・152・153の閲覧取得を各正式選択正本へ照合する。
    引数: legacy(dict)は閲覧準備記録、context(dict)は旧73場。
    返り値: dictは正本同体を確認した固定取得件数。
    """
    mapping={v:i for i,v in enumerate(context['meta']['case_ids'])}
    events={v['id']:i for i,v in enumerate(context['events'])};report={}
    original=read('inputs/00148_全1分入口母集団/入口参照.json.gz')
    for name in ('C1','00152_U0','00153_U15'):
        p=next(p for p in legacy['policies'] if p['id']==name)
        if name=='C1':
            expected=[(mapping[r['id']],r['native_side'],None,125,1) for r in original['entries']]
        else:
            path='inputs/00152_複合回復の方向切替/選択対応.json.gz' if name=='00152_U0' else 'inputs/00153_先行高安の独立出生/選択対応.json.gz'
            control=read(path)['政策'][name.split('_')[1]]
            expected=[(mapping[r['case_id']],r['side'],events.get(r['event_id']),125,1 if r['origin']=='C1' else 0) for r in control]
        actual=[tuple(r[:5]) for r in p['selection']]
        assert actual==expected,(name,'正式選択との不一致')
        report[name]=len(expected)
    return report


def main() -> None:
    """
    機能: 全四CSVを元取得と数値表から検算し共通既知出口診断を残す。
    引数: CLI --root(Path)、--output(Path)は任意の再現先。
    返り値: None。独自検査票を生成し元CSV・Sourceには書かない。
    """
    global ROOT,HERE,ARCHIVES
    parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,default=ROOT);parser.add_argument('--output',type=Path,default=HERE)
    args=parser.parse_args();ROOT=args.root.resolve();HERE=args.output.resolve();HERE.mkdir(parents=True,exist_ok=True)
    sys.stdout.reconfigure(encoding='utf-8')
    for number in (165,166,168,170,171):
        for directory in (ROOT/'study').glob(f'{number:05d}_*'):
            for path in sorted((directory/'再現資料').glob('*.zip')):
                with zipfile.ZipFile(path) as archive:ARCHIVES.append((path,set(archive.namelist())))
    tables=read('work/入口検証CSV/tables.json')
    assert INPUTS['work/入口検証CSV/tables.json']['sha256']=='d07f94581db990d79d1b1d064531405f80e5dd17236c87c18fe9872cc455b855'
    parsed={};csvproof={};cell_count=0
    for name,table in tables['tables'].items():
        path='outputs/00171_複合入口と数量枠の比較/'+name+'.csv'
        body=source(path);rows=list(csv.reader(io.StringIO(body.decode('utf-8-sig'))))
        assert rows[0]==table['headers'] and len(rows)==len(table['rows'])+1
        result=[]
        for got,want in zip(rows[1:],table['rows'],strict=True):
            assert len(got)==len(want);values=[]
            for i,(text,value) in enumerate(zip(got,want,strict=True)):
                kind=table['column_types'][i]['type']
                if value is None:assert text=='';values.append(None)
                elif kind=='text':assert text==value;values.append(text)
                else:
                    parsed_value=int(text) if kind=='integer' else float(text)
                    assert parsed_value==value;values.append(parsed_value)
            result.append(dict(zip(table['headers'],values,strict=True)))
        parsed[name]=result;cell_count+=len(rows)*len(rows[0])
        csvproof[name]={'行数':len(result),'列数':len(rows[0]),'sha256':digest(body)}
    # ----------------------------------------
    # 元の政策位置と取得列を使う。CSV作者・各Context・統計関数は一切importしない。
    old=load_period(False);new=load_period(True);groups={};policy_sources={}
    legacy=read('work/166閲覧集計/政策と取得.json')
    old_controls=validate_old_controls(legacy,old)
    for p in legacy['policies']:
        rows=[]
        for case,direction,event,width,origin,tier in p['selection']:
            row={'case':case,'side':0 if direction==1 else 1,'event':event,'wi':old['meta']['widths'].index(width),'origin':origin}
            if event is None:
                row['q0']=next(r['legacy_q0']['time'] for r in legacy['cases'] if r['case_index']==case)
            rows.append(row)
        hi=old['meta']['horizon_ids'].index(p['horizon'])
        groups[p['id']]=[(old,financial(rows,old,hi))];policy_sources[p['id']]='旧13政策の固定取得列＋正式金融NPZ'
    settings=read('study/00167_固定した複合入口を追加七場へ適用する/条件.json')
    refs167=read('work/167固定入口の別期間/比較/全取得参照.json')['rows']
    for candidate in settings['candidates']:
        ref=next(r for r in refs167 if r['id']==candidate['id']);hi=new['meta']['horizon_ids'].index(candidate['horizon'])
        for uniform in (None,125):
            identity='167_'+candidate['id']+('_BRANCH' if uniform is None else '_W125')
            groups[identity]=[(new,financial(selections(ref,new,uniform),new,hi))];policy_sources[identity]='167正式固定取得＋正式金融NPZ'
        identity='168_'+candidate['id'];groups[identity]=[]
        for context,folder in ((old,'旧73比較'),(new,'追加7比較')):
            refs=read('work/168数量枠の因果再生/'+folder+'/全取得参照.json')['rows'];ref=next(r for r in refs if r['id']==candidate['id'])
            hi=context['meta']['horizon_ids'].index(candidate['horizon'])
            groups[identity].append((context,financial(selections(ref,context),context,hi)))
        policy_sources[identity]='168数量枠後の固定取得＋正式金融NPZ'
    pair_report={}
    for p in read('work/入口検証CSV/追加政策.json')['policies']:
        groups[p['id']]=[];policy_sources[p['id']]='固定主案の数量枠後の取得参照＋正式金融NPZ'
        for context,field in ((old,'old_reference'),(new,'new_reference')):
            ref=next(r for r in read(p[field])['rows'] if r['id']==p['reference_id'])
            hi=context['meta']['horizon_ids'].index(p['candidate']['horizon']);rows=selections(ref,context,p.get('uniform_width'))
            groups[p['id']].append((context,financial(rows,context,hi)))
            if p['id']=='171_MAIN':pair_report['追加7場' if context['new'] else '旧73場']=pairs(rows,context,hi)
    # ----------------------------------------
    # 同取得125は数量枠を再生しない。両known集合の診断は採否にも頻度にも使わない。
    both=pair_report['旧73場'];extra=pair_report['追加7場'];total={}
    for key in ('同一取得数','両金融既知数','主案のみ既知数','125のみ既知数','両未知数','共通既知差引差_円'):
        total[key]=both[key]+extra[key]
    for name in ('主案_共通既知','同取得125_共通既知'):
        total[name]={k:both[name][k]+extra[name][k] for k in both[name]}
    pair_report['全80場']=total
    pair_report={'成功':True,'目的':'固定した同一case・同一実側・H60における両金融既知集合の事後出口診断',
        '数量枠再生':False,'入口採用への使用':False,'頻度と全場目標の再判定':False,'費用':'C5・各要求mini1枚',
        '期間':pair_report,'SourceSHA256':digest(Path(__file__).read_bytes())}
    save('共通既知の出口診断.json',pair_report)
    tested=0;comparison_by_id={};sessions_by_id={}
    for row in parsed['候補比較']:comparison_by_id.setdefault(row['候補ID'],[]).append(row)
    for row in parsed['全セッション']:sessions_by_id.setdefault(row['候補ID'],[]).append(row)
    assert set(groups)==set(comparison_by_id)==set(sessions_by_id) and len(groups)==22
    calculated={};all_scenes_checked=0
    for identity,periods in groups.items():
        calculated[identity]={};net=0;c=0
        for context,rows in periods:
            n=len(context['sessions']);base_label='追加7場' if context['new'] else '旧73場'
            labels=[(base_label,list(range(n)))]
            if not context['new']:labels.extend([(base_label+'・前48場',list(range(48))),(base_label+'・後25場',list(range(48,73)))])
            for label,eligible in labels:calculated[identity][label]=summarize(rows,context,eligible)
            for si,session in enumerate(context['sessions']):
                target=next(r for r in sessions_by_id[identity] if r['セッション']==session)
                want=summarize(rows,context,[si]);tested+=compare(target,want,(identity,session));all_scenes_checked+=1
                net+=want['既知差引_円'];c+=want['観測不足C']
                tested+=compare(target,{'既知累計差引_円':net,'累計観測不足C':c,'全件累計収支_円':net if c==0 else None},(identity,session,'累計'))
            for target in [r for r in parsed['時間帯別'] if r['候補ID']==identity]:
                label=target['期間'];canonical=label.replace('全期','旧73場').replace('前48場','旧73場・前48場').replace('後25場','旧73場・後25場') if label in ('全期','前48場','後25場') else label
                if canonical not in dict(labels):continue
                eligible=dict(labels)[canonical];band=('デイ','ナイト米国前','ナイト米国後').index(target['時間帯'])
                clock='q0' if target['分類時計']=='q0出生' else 'q1'
                wanted=summarize(rows,context,eligible,band,clock)
                tested+=compare(target,wanted,(identity,label,clock,band))
                assert target['対象場数']==sum(context['hours'][si][band]>0 for si in eligible)
        for target in comparison_by_id[identity]:
            label=target['期間'];canonical={'全期':'旧73場','前48場':'旧73場・前48場','後25場':'旧73場・後25場'}.get(label,label)
            if canonical=='全80場':
                wants=[]
                for context,rows in periods:wants.append(summarize(rows,context,list(range(len(context['sessions'])))))
                values={k:sum(m[k] for m in wants) for k in METRICS if k not in ('回毎時','到達済み先着率_pct','既知決済勝率_pct','PF_利益÷損失','全件収支_円')}
                f,a=values['順先着F'],values['逆先着A'];known=values['損益既知数'];loss=values['既知損失_円']
                values.update({'回毎時':values['取得数']/sum(sum(sum(h) for h in context['hours']) for context,rows in periods),
                    '到達済み先着率_pct':100*f/(f+a) if f+a else None,'既知決済勝率_pct':100*values['費用後勝ち数']/known if known else None,
                    'PF_利益÷損失':values['既知利益_円']/loss if loss else None,'全件収支_円':values['既知差引_円'] if values['観測不足C']==0 else None})
            else:values=calculated[identity][canonical]
            tested+=compare(target,values,(identity,label));assert target['対象場数']==(80 if canonical=='全80場' else 7 if canonical=='追加7場' else 48 if '前48' in canonical else 25 if '後25' in canonical else 73)
    for name,ref in INPUTS.items():
        if 'archive' in ref:
            with zipfile.ZipFile(ROOT/ref['archive']) as archive:body=archive.read(ref['member'])
        else:body=(ROOT/ref['path']).read_bytes()
        assert len(body)==ref['bytes'] and digest(body)==ref['sha256'],(name,'終了時の指紋変化')
    proof={'成功':True,'SourceSHA256':digest(Path(__file__).read_bytes()),'型付きJSON_SHA256':INPUTS['work/入口検証CSV/tables.json']['sha256'],
        'CSV':csvproof,'型付き全セル照合':cell_count,'元金融配列からの独立数値照合':tested,'候補数':len(groups),'全セッション行照合':all_scenes_checked,
        '独立範囲':['CSV標準再読と元型付き全セル','全22固定取得の実側・幅・期限から金融NPZ直接参照','全比較・全場・前後・q0q1三帯・未知と既知累計','171同取得125の共通金融既知ペア'],
        '検算の限界':['入口出生と数量枠の全要求再生は親独立QA参照','Raw再解析や実mini約定は本検査の対象外','旧13政策の固定取得列は閲覧準備入力を使用。候補の再探索はしない'],
        '旧三対照の正式選択同体':old_controls,'候補の元取得':policy_sources,'入力':INPUTS,'全入力の終了時SHA再照合':True,
        '元正本不変更':True,'CSV再生成':False,'マーカー再実行':False,
        '依存':{'Python':sys.version,'NumPy':np.__version__}}
    save('閲覧四表の独立接続.json',proof)
    print(json.dumps({'成功':True,'全セル':cell_count,'数値':tested,'候補':len(groups),'全場':all_scenes_checked,'共通既知':pair_report['期間']['全80場']},ensure_ascii=False))


if __name__=='__main__':
    main()
