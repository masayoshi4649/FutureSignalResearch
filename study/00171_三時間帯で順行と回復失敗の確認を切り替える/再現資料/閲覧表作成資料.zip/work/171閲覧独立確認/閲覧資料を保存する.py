"""閲覧四CSVを変更せず、作成入力と独立接続検査を一度保存する。"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib
import json
import re
import subprocess
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
TRIAL=ROOT/'study/00171_三時間帯で順行と回復失敗の確認を切り替える'


def sha(path: Path) -> str:
    """
    機能: 保存前後を全物理内容で照合する。
    引数: path(Path)は対象ファイル。
    返り値: strはSHA256。
    """
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def ref(path: Path) -> dict:
    """
    機能: 正式保存先をサイズ・指紋とともに参照する。
    引数: path(Path)は既存ファイル。
    返り値: dictは相対パスとbytesとSHA256。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':sha(path)}


def read(path: Path) -> dict:
    """
    機能: 日本語JSONを読む。
    引数: path(Path)は対象。
    返り値: dictは標準JSON内容。
    """
    return json.loads(path.read_bytes())


def save(path: Path,value: dict) -> None:
    """
    機能: 新規の保存票だけを日本語UTF-8で保存する。
    引数: path(Path)は保存先、value(dict)は内容。
    返り値: None。
    """
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')


def archive(destination: Path,paths: list) -> dict:
    """
    機能: 作成入力とSourceだけをZIP化し全メンバーCRC・SHAを確認する。
    引数: destination(Path)、paths(list[Path])は複製を許す小資源。
    返り値: dictはZIP参照と全メンバー指紋。
    """
    before={p.relative_to(ROOT).as_posix():ref(p) for p in paths}
    destination.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(destination,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name in sorted(before):z.write(ROOT/name,arcname=name)
    with zipfile.ZipFile(destination) as z:
        assert z.testzip() is None and len(z.namelist())==len(before)
        for name,value in before.items():
            body=z.read(name)
            assert len(body)==value['bytes'] and hashlib.sha256(body).hexdigest()==value['sha256']
            assert ref(ROOT/name)==value
    return {**ref(destination),'members':before,'全CRC_SHA_元bytes同体':True}


def document(pair: dict) -> str:
    """
    機能: 四CSVの読み方と同一取得の共通既知診断を簡潔に記す。
    引数: pair(dict)は独立再計算した事後診断。
    返り値: strは閲覧資料Markdown。
    """
    rows=[]
    for name,values in pair['期間'].items():
        m=values['主案_共通既知'];c=values['同取得125_共通既知']
        rows.append(f"| {name} | {values['両金融既知数']} | {m['利益_円']:,} / {m['損失_円']:,} / {m['差引_円']:+,} | {c['利益_円']:,} / {c['損失_円']:,} / {c['差引_円']:+,} | {values['共通既知差引差_円']:+,} |")
    return '''# 閲覧するCSVと数値の読み方

2026-11-15。最初は[候補比較.csv](../../outputs/00171_複合入口と数量枠の比較/候補比較.csv)を開き、`171_MAIN`の全80場、旧73場、追加7場を読む。各候補は別の売買条件なので、候補間の金額を合算しない。

| CSV | 内容 | 主な絞り込み |
| --- | --- | --- |
| [候補比較](../../outputs/00171_複合入口と数量枠の比較/候補比較.csv) | 22候補・68行。件数、先着、利益、損失、差引、PF、既知・未知 | 候補ID、期間 |
| [全セッション](../../outputs/00171_複合入口と数量枠の比較/全セッション.csv) | 1,377行。取得0の場も残す。場ごとの金額と累計 | 候補ID、セッション |
| [時間帯別](../../outputs/00171_複合入口と数量枠の比較/時間帯別.csv) | 378行。デイ・ナイト米国前・以後、出生q0と取得q1の各分解 | 候補ID、期間、分類時計 |
| [条件一覧](../../outputs/00171_複合入口と数量枠の比較/条件一覧.csv) | 77行。複合技術、時間軸、費用、数量と各対照の役割 | 範囲・候補ID、項目 |

`171_MAIN`が本試行の事前主案。`168_PRIMARY`は同じ複合技術幹の旧数量枠対照、`166_MAIN`は片側上限を適用する前の独立一枚合算、`170_MAIN`はATR幅の事前主案である。`166_FRONT`は前48場選択、166の幅・期限違いは近傍比較。`C1`・`00152_U0`・`00153_U15`は旧固定入口の今回の時計による再観測で、当時の正本を変更していない。169および170・171の前48場A/Bが不採用だった結果を、全期で発見した別案へ置換していない。

旧73場は2026-09-21デイ〜11-10デイ、追加7場は11-10ナイト〜11-13ナイト。追加7場は167で初めて固定案へ適用し、その後の170・171では既使用の比較期間である。171の追加期を独立の未見検証とは呼ばない。

## 金額・率・空欄

- 金額は各要求mini1枚・1pt=100円。往復手数料77円、正常BBOによるスプレッドに加えて片道5pt相当ずつ・往復1,000円の追加滑りを控除したC5。毎回10枚へ乗算した値ではない。168・170・171主案は買い・売り各10枚を上限とする数量枠後の取得である。
- `既知利益_円`は金融既知の正損益合計、`既知損失_円`は負損益の絶対額合計、`既知差引_円`はその差。観測不足Cを0円の損益とした全口座収支ではない。
- `到達済み先着率_pct`はF/(F+A)×100。未到達Nと観測不足Cを除く条件付きの率であり、全取得の勝率ではない。`既知決済勝率_pct`は費用後正損益件数/損益既知件数×100で、Nの期限決済も含む。値73.95は73.95%を表す。
- `全件収支_円`はC=0の時だけ値を持つ。空欄は未確定であり、取得0の0円とは異なる。既知累計は既知部分だけを加算し、累計Cが一つでもあれば`全件累計収支_円`は空欄のまま残る。
- 三帯は米国09:30を夏冬時間込みで区分する。q0出生とq1取得は同じ取得列の別分類であり、両時計の行を合計しない。`回毎時`の分母は対象の全ザラバ時間で、静観した時間も含む。

## 同取得±125ptの比較範囲

`171_SAME125`は`171_MAIN`で取得した同じcase・同じ実側をH60・±125ptへ再観測した**出口診断**である。出口を125ptに変えて数量枠を再生していないため、別の運用候補や別口座の実現可能な収支として扱わない。

全80場の既知合計は主案が利益7,760,355円・損失3,438,248円、同取得125が利益4,216,587円・損失3,424,174円。ただし金融既知は主案609件、125は631件であり、未知35件対13件と集合が異なる。この差引差3,529,694円のすべてを出口効果と断言しない。

両方が金融既知の同case・同sideだけを独立に再計算した結果は次のとおり。金額の三つ組は「利益 / 損失 / 差引」、単位は円。

| 期間 | 共通既知件数 | 主案の枝幅 | 同取得125 | 差引の差 |
| --- | --- | --- | --- | --- |
'''+ '\n'.join(rows)+'''

全80場の除外内訳は、主案だけ既知0件、125だけ既知22件、両方未知13件。全既知差引差と共通既知差引差との差179,694円は既知集合の差に由来する。これは出口の事後比較であり、入口採用条件の追加や、選別後取引だけでの頻度・全場参加目標の判定には使わない。詳細は[共通既知の診断](検査/閲覧資料/共通既知の出口診断.json)に残した。

## 確認と再現

作成者の根拠は、保存ZIP内の型付きJSON・作成器・作成確認・標準CSV再読確認である。作者はartifact-toolで全セルとプレビューを確認し、標準CSV再読で44,067セルを照合した。

これと別に、[独立接続票](検査/閲覧資料/閲覧四表の独立接続.json)では作者のContext・統計関数を呼ばず、正式取得参照と共用金融NPZへ直接添字で接続し、22候補の全場・全比較・前後・q0/q1三帯・未知累計の38,768数値と全44,067セルを検算した。旧C1・152・153の取得列も各正式選択入力と同体。入口出生・数量枠の全要求再生は各親試行の独立QAに委ね、本検査はRawの再解析や実miniの約定検証を追加していない。

[作成資料ZIP](再現資料/閲覧表作成資料.zip)には最終型付き四表、旧13対照の型付き表・固定取得記録、作成器と生成確認、独立検査Sourceを一度だけ保存した。CSVはoutputsの4正本を参照し、NPZ・原板・母集団は親正式資源を参照する。[保存索引](再現資料/閲覧資料の保存索引.json)に全SHAとZIP内の元パスを記録した。作成時Node.jsは24.22.1、artifact-toolは2.8.157（作成担当の記録）、独立数値検査はPython3.14.3・NumPy2.5.4。

CSVを変更せず再検算するには、作成資料ZIPから`work/171閲覧独立確認/四表と共通既知を検査する.py`だけを任意の作業先へ展開し、リポジトリルートで次を実行する。検査Sourceは親ZIPと共用inputsを優先して読み、元workの金融ファイルを必要としない。

```powershell
& 'work/複合テクニカル学習環境/Scripts/python.exe' -X utf8 '<展開先>/四表と共通既知を検査する.py' --root (Get-Location).Path --output 'work/171閲覧の再検算'
```

この保存作業ではCSVの再生成・作成開始マーカーの再実行・171主Sourceや主統計の変更を行っていない。[閲覧保存の検査](検査/閲覧資料/閲覧資料の確認.json)と[停止票](検査/閲覧資料/閲覧資料の停止.json)は主保存の検査と分離した。
'''


def main() -> None:
    """
    機能: 小入力をZIP化して正式資源だけで再検算後、最後に閲覧MDを確定する。
    引数: なし。既存のCSVと停止済Sourceだけを読み込む。
    返り値: None。主保存のMD・索引・停止には書かない。
    """
    sys.stdout.reconfigure(encoding='utf-8')
    output=ROOT/'outputs/00171_複合入口と数量枠の比較'
    originals=[*output.glob('*.csv'),ROOT/'work/入口検証CSV/tables.json',TRIAL/'条件.json']
    before={p.relative_to(ROOT).as_posix():ref(p) for p in originals}
    assert len(list(output.glob('*.csv')))==4 and sha(ROOT/'work/入口検証CSV/tables.json')=='d07f94581db990d79d1b1d064531405f80e5dd17236c87c18fe9872cc455b855'
    primary_archives=list((TRIAL/'再現資料').glob('*統計*.zip'))
    assert len(primary_archives)==1,'171主統計ZIPの完成後に保存する'
    root_sources=[p for p in (ROOT/'work/入口検証CSV').iterdir() if p.is_file() and p.suffix in ('.py','.mjs','.json')]
    old_sources=[p for p in (ROOT/'work/166閲覧集計').iterdir() if p.is_file() and p.suffix in ('.py','.json','.md')]
    paths=root_sources+old_sources+[Path(__file__),HERE/'四表と共通既知を検査する.py']
    assert not any(p.suffix in ('.csv','.npz','.png','.gz','.exe') for p in paths)
    created=archive(TRIAL/'再現資料/閲覧表作成資料.zip',paths)
    checks=TRIAL/'検査/閲覧資料';checks.mkdir(parents=True,exist_ok=True)
    result=subprocess.run([sys.executable,'-X','utf8',str(HERE/'四表と共通既知を検査する.py'),
        '--root',str(ROOT),'--output',str(checks)],cwd=ROOT,encoding='utf-8',capture_output=True)
    assert result.returncode==0,(result.stdout,result.stderr)
    proof=read(checks/'閲覧四表の独立接続.json');pair=read(checks/'共通既知の出口診断.json')
    assert all('archive' in r or not r['path'].startswith('work/') for r in proof['入力'].values()),'正式資源のみの再検算が必要'
    for name,value in before.items():assert ref(ROOT/name)==value
    parents=set(r['archive'] for r in proof['入力'].values() if 'archive' in r)
    fixed_inputs=[r for r in proof['入力'].values() if 'path' in r and r['path'].startswith('inputs/')]
    index={'成功':True,'作成日':'2026-11-15','試行':171,'用途':'四CSVの閲覧と作成入力・独立接続検査の保存',
        'CSV正本':[ref(p) for p in sorted(output.glob('*.csv'))],'CSV再複製':False,'資料ZIP':created,
        '親正式ZIP':[ref(ROOT/p) for p in sorted(parents) if ROOT/p!=TRIAL/'再現資料/閲覧表作成資料.zip'],
        '共用正式入力':fixed_inputs,'独立接続票':ref(checks/'閲覧四表の独立接続.json'),
        '共通既知の出口診断':ref(checks/'共通既知の出口診断.json'),
        'Root作成根拠':['work/入口検証CSV/作成確認.json','work/入口検証CSV/独立再読確認.json','work/入口検証CSV/型付き接続の確認.json'],
        '独立検査Source':'work/171閲覧独立確認/四表と共通既知を検査する.py',
        '依存':{'Node.js':'24.22.1（作成確認票）','artifact-tool':'2.8.157（作成担当報告）',**proof['依存']},
        '除外':['CSV正本の再複製','共用NPZ・原板の再複製','node_modules','PNG','venv','作成開始マーカー再実行'],
        '検査範囲':proof['独立範囲'],'限界':proof['検算の限界']}
    save(TRIAL/'再現資料/閲覧資料の保存索引.json',index)
    # ----------------------------------------
    # MDはすべての参照先が確定した最後に置き、主保存側は変更しない。
    md=TRIAL/'閲覧資料.md';md.write_text(document(pair),encoding='utf-8')
    links=[]
    for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',md.read_text(encoding='utf-8')):
        if target.startswith(('https://','http://','#')):continue
        links.append(target)
    checked={'成功':True,'SourceSHA256':sha(Path(__file__)),'ZIP全CRC_SHA_元bytes':True,'ZIPメンバー数':len(created['members']),
        '正式資源のみで独立再計算':True,'独立全セル照合':proof['型付き全セル照合'],'独立数値照合':proof['元金融配列からの独立数値照合'],
        '独立候補数':proof['候補数'],'独立全場行数':proof['全セッション行照合'],'閲覧MDリンク数':len(links),'元正本不変':before,
        '同取得125の数量枠再生なしを明示':True,'共通既知以外の差額を出口効果としない':True,'CSV再生成':False,'マーカー再実行':False}
    save(checks/'閲覧資料の確認.json',checked)
    frozen=[md,TRIAL/'再現資料/閲覧資料の保存索引.json',TRIAL/'再現資料/閲覧表作成資料.zip',
        checks/'閲覧四表の独立接続.json',checks/'共通既知の出口診断.json',checks/'閲覧資料の確認.json']
    save(checks/'閲覧資料の停止.json',{'成功':True,'停止UTC':datetime.now(timezone.utc).isoformat(),'対象':'閲覧資料だけ。171主保存と分離',
        'files':[ref(p) for p in frozen],'元正本不変更':True})
    for target in links:assert (md.parent/target.split('#')[0]).resolve().exists(),target
    print(json.dumps({'成功':True,'ZIP':ref(TRIAL/'再現資料/閲覧表作成資料.zip'),'停止':ref(checks/'閲覧資料の停止.json')},ensure_ascii=False))


if __name__=='__main__':
    main()
