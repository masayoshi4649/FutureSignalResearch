"""研究の固定入口を共通IFDで再観測し、CSV作成前の型付き四表へする。"""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import importlib.util
import json
import math
import sys
import time

import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
HELPER=ROOT/'work/165自然独立確認/自然値を独立検算する.py'
spec=importlib.util.spec_from_file_location('view166_independent',HELPER)
independent=importlib.util.module_from_spec(spec);spec.loader.exec_module(independent)
read=independent.read;save=independent.save;sha=independent.sha;match=independent.match
FIELDS=independent.FIELDS
JST=timezone(timedelta(hours=9))


def native_number(value: float) -> int|float|None:
    """
    機能: 数値をJSONネイティブ型へし、未定義はnullへする。
    引数: value(float)は集計値。
    返り値: int/float/Noneは有限数値又は未定義。
    """
    if not math.isfinite(value):return None
    return int(value) if value.is_integer() else value


def metrics(values: np.ndarray) -> dict:
    """
    機能: 27個の独立統計を名前へ対応付ける。
    引数: values(np.ndarray[float,27])は集計。
    返り値: dict[str,int|float|None]は型付き指標。
    """
    return {name:native_number(float(value)) for name,value in zip(FIELDS,values,strict=True)}


def percentage(value: int|float|None) -> float|None:
    """
    機能: CSVの列見出しに合わせ率を百分率の数値へする。
    引数: value(int/float/None)は0..1比率。
    返り値: float又はNoneは百分率又は未定義。
    """
    return value*100 if value is not None else None


def table(headers: list,rows: list) -> dict:
    """
    機能: 長方形と列型を検査し、四表の共通構造を作る。
    引数: headers(list[str])、rows(list[list])は列と行。
    返り値: dictはheaders/rows/column_typesを持つ。
    """
    assert len(headers)==len(set(headers)) and all(len(row)==len(headers) for row in rows)
    types=[]
    for column,name in enumerate(headers):
        values=[row[column] for row in rows];finite=[v for v in values if v is not None]
        kind='text' if any(isinstance(v,str) for v in finite) else 'integer' if all(isinstance(v,int) for v in finite) else 'number'
        assert all(isinstance(v,str) if kind=='text' else isinstance(v,(int,float)) for v in finite),name
        assert all(not isinstance(v,float) or math.isfinite(v) for v in finite),name
        types.append({'name':name,'type':kind,'nullable':any(v is None for v in values)})
    return {'headers':headers,'rows':rows,'column_types':types}


def main() -> None:
    """
    機能: 13候補の比較・全73場・三帯・条件費用を元配列へ全照合して保存する。
    引数: なし。固定旧73場の正本だけを読む。CSV・xlsxは生成しない。
    返り値: None。tables.json、政策と取得.json、小検査票を保存する。
    """
    sys.stdout.reconfigure(encoding='utf-8');begin=time.monotonic()
    p166=ROOT/'work/166可用指標の階層化';p165=ROOT/'work/165順行と回復失敗の複合'
    p164=ROOT/'work/164先着確定と反転比較';data=ROOT/'work/163任意幅の数値化/自然数値表'
    cache=ROOT/'work/151過去場判別の評価/入口選択/cache/feature_only'
    paths=[Path(__file__),HELPER,cache/'features_meta.json',data/'任意幅配列.npz',data/'任意幅識別.json.gz',
           ROOT/'inputs/00148_全1分入口母集団/取得対応.json.gz',ROOT/'inputs/00148_全1分入口母集団/入口参照.json.gz',
           ROOT/'inputs/00152_複合回復の方向切替/選択対応.json.gz',ROOT/'inputs/00153_先行高安の独立出生/選択対応.json.gz',
           p164/'比較/統計軸.json',p164/'比較/最初到達の統計配列.npz',
           ROOT/'work/163入口と任意幅/全出生/出生400.npz',ROOT/'work/163入口と任意幅/全出生/全出生の確認.json',
           p165/'比較/統計軸.json',p165/'比較/主案と探索結果.json',p165/'比較/全取得参照.json.gz',p165/'比較/複合入口の統計配列.npz',
           p165/'全出生/複合と技術補完.npz',p166/'比較/統計軸.json',p166/'比較/主案と探索結果.json',
           p166/'比較/全取得参照.json.gz',p166/'比較/階層化入口の統計配列.npz',p166/'全出生/階層化の出生.npz',
           ROOT/'study/00166_未公表の長期指標を捏造せず局所技術で参加を補う/条件.json',
           ROOT/'work/165自然独立確認/自然の独立確認.json',ROOT/'work/166自然独立確認/自然の独立確認.json']
    before={p.relative_to(ROOT).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in paths}
    feature=read(paths[2]);q0=feature['q0_meta'];scenes=feature['scenes'];meta=read(paths[4]);mapping={name:i for i,name in enumerate(meta['case_ids'])}
    event_map={row['event_id']:i for i,row in enumerate(q0)};captures=read(paths[5]);capture_map={r['event_id']:r for r in captures['rows']}
    capture_rows=[capture_map[row['event_id']] for row in q0]
    with np.load(paths[3],allow_pickle=False) as source:arrays={name:source[name].copy() for name in source.files}
    legacy_input=read(paths[6]);legacy_by_case={row['id']:row for row in legacy_input['entries']}
    legacy=[(mapping[row['id']],0 if row['native_side']==1 else 1,-1,1) for row in legacy_input['entries']]
    axes164=read(paths[9]);axes165=read(paths[13]);report165=read(paths[14]);axes166=read(paths[18]);report166=read(paths[19])
    with np.load(paths[16],allow_pickle=False) as source:m165=source['metrics'].copy()
    with np.load(paths[17],allow_pickle=False) as source:b165={name:source[name].copy() for name in source.files}
    with np.load(paths[21],allow_pickle=False) as source:m166=source['metrics'].copy()
    with np.load(paths[22],allow_pickle=False) as source:b166={name:source[name].copy() for name in source.files}
    refs165={(row['profile'],row['integration']):row for row in read(paths[15])['rows']}
    refs166={(row['profile'],row['hierarchy'],row['integration']):row for row in read(paths[20])['rows']}
    hours=np.zeros((73,3))
    for si,scene in enumerate(scenes):
        end=scene['end']-300
        if scene['session'].endswith('_Day'):hours[si,0]=(end-scene['start'])/3600
        else:
            boundary=independent.ny_open(scene['session']);hours[si,1]=(min(boundary,end)-scene['start'])/3600
            hours[si,2]=(end-max(boundary,scene['start']))/3600
    assert abs(float(hours.sum())-(720+55/60))<1e-10
    policies=[]
    def add166(identifier: str,name: str,position: list,status: str) -> None:
        """
        機能: 166の位置指定政策を実取得・固定幅付きで登録する。
        引数: identifier/name/status(str)、position(list[int])は六軸位置。
        返り値: None。policiesへ追加する。
        """
        pi,li,mi,fi,hi,ti=position;profile=axes166['profiles'][pi]['id'];hierarchy=axes166['hierarchies'][li]['id']
        ref=refs166[profile,hierarchy,axes166['integrations'][ti]]
        rows=list(zip(ref['cases'],ref['sides'],ref['events'],ref['origins'],strict=True))
        widths=independent.widths_for(rows,b166['branches'][pi],axes166['momentum_widths'][mi],axes166['fade_widths'][fi],(150,200)[ti],meta['widths'])
        policies.append({'id':identifier,'name':name,'kind':status,'trial':166,'position':position,
                         'description':{'profile':profile,'hierarchy':hierarchy,'momentum_width':axes166['momentum_widths'][mi],
                                        'fade_width':axes166['fade_widths'][fi],'technical_width':(150,200)[ti],
                                        'horizon':axes166['horizons'][hi],'integration':axes166['integrations'][ti]},
                         'rows':rows,'tiers':ref['tiers'],'widths':widths,'hi':hi,'expected':m166[tuple(position)][...,:27]})
    main_position=report166['事前固定主案']['position']
    add166('166_MAIN','166 事前主案',main_position,'既使用期の事前固定主案')
    add166('166_FRONT','166 前48場で選択',report166['前48場だけで選択']['position'],'前48場選択・後25場固定適用。既使用期')
    old_control_names=('C1','00152_U0','00153_U15')
    with np.load(paths[10],allow_pickle=False) as source:
        controls164=source['controls'].copy()
        ex_position=[axes164['規則順'].index('EX0076'),axes164['発火方式'].index('ALL'),axes164['方向'].index('REVERSE'),
                     axes164['幅'].index(400),axes164['時計'].index('H60'),axes164['統合'].index('U')]
        ex_expected=source['metrics'][tuple(ex_position)].copy()
    for control,name in zip(old_control_names,('旧C1入口 ±125','旧152 U0入口 ±125','旧153 U15入口 ±125'),strict=True):
        if control=='C1':rows=legacy
        else:
            selected=read(paths[7 if control=='00152_U0' else 8])['政策'][control.split('_')[1]]
            rows=[(mapping[row['case_id']],0 if row['side']==1 else 1,event_map.get(row['event_id'],-1),1 if row['origin']=='C1' else 0) for row in selected]
        wi=meta['widths'].index(125);hi=meta['horizon_ids'].index('H60')
        ci=axes164['旧対照順'].index(control)
        expected=np.c_[controls164[ci,wi,hi],np.zeros((3,2))]
        expected[:,-1]=expected[:,independent.FIELDS.index('new_count')]
        policies.append({'id':control,'name':name,'kind':'旧固定入口の今回IFD_FIRST再観測。旧正本判定は変更しない',
                         'trial':int(control[:5]) if control!='C1' else 148,'position':None,
                         'description':{'fixed_entry':control,'width':125,'horizon':'H60','classification':'IFD_FIRST'},
                         'rows':rows,'tiers':[0]*len(rows),'widths':np.full(len(rows),wi,dtype=np.int8),'hi':hi,'expected':expected})
    with np.load(paths[11],allow_pickle=False) as source:
        ri=read(paths[12])['規則順'].index('EX0076');directions=-source['ALL'][ri]
    core=independent.link(directions,capture_rows,mapping);rows=independent.merged(core,legacy)
    expected=np.c_[ex_expected,np.zeros((3,2))];expected[:,-1]=expected[:,independent.FIELDS.index('new_count')]
    policies.append({'id':'164_EX76_REVERSE','name':'164 EX0076反転＋旧87保持','kind':'全期探索で見つけた旧参照併用対照',
                     'trial':164,'position':ex_position,'description':{'rule':'EX0076','mode':'ALL','orientation':'REVERSE','width':400,'horizon':'H60','integration':'U'},
                     'rows':rows,'tiers':[0]*len(rows),'widths':np.full(len(rows),meta['widths'].index(400),dtype=np.int8),
                     'hi':meta['horizon_ids'].index('H60'),'expected':expected})
    primary165=report165['事前固定主案'];pi,mi,fi,hi,ii=primary165['position'];ref=refs165[primary165['profile']['id'],primary165['integration']]
    rows=list(zip(ref['cases'],ref['sides'],ref['events'],ref['origins'],strict=True))
    widths=independent.widths_for(rows,b165['branches'][pi],primary165['momentum_width'],primary165['fade_width'],200,meta['widths'])
    policies.append({'id':'165_MAIN','name':'165 主案・局所補完前','kind':'166の固定対照。全73場参加は未達',
                     'trial':165,'position':primary165['position'],
                     'description':{'profile':primary165['profile']['id'],'momentum_width':primary165['momentum_width'],
                                    'fade_width':primary165['fade_width'],'technical_width':200,'integration':'T200','horizon':primary165['horizon']},
                     'rows':rows,'tiers':[1 if row[3]==2 else 0 for row in rows],'widths':widths,'hi':hi,'expected':m165[tuple(primary165['position'])]})
    for identifier,name,axis,value in (
        ('166_M175','166 順行幅175','momentum',175),('166_M225','166 順行幅225','momentum',225),
        ('166_F350','166 反転幅350','fade',350),('166_F500','166 反転幅500','fade',500),
        ('166_H30','166 期限30分','horizon','H30'),('166_H120','166 期限120分','horizon','H120')):
        position=main_position.copy()
        if axis=='momentum':position[2]=axes166['momentum_widths'].index(value)
        elif axis=='fade':position[3]=axes166['fade_widths'].index(value)
        else:position[4]=axes166['horizons'].index(value)
        add166(identifier,name,position,'166主案の近傍。全期比較であり別の事前主案ではない')
    assert len(policies)==13 and len({p['id'] for p in policies})==13
    # ----------------------------------------
    # 表の率は百分率数値、未定義はnull。全収支はCを一件でも含めばnullとする。
    comparison=[];session_rows=[];timeband_rows=[];serialized=[];all_cases=set();all_events=set();tested=0
    metric_columns=('count','scenes','per_hour','F','A','N','C','rate','known','wins','loss_trades','realized_win_rate','profit','loss','net','pf','new_count','old_count')
    metric_headers=('取得数','参加場数','回毎時','順先着F','逆先着A','未到達N','観測不足C','到達済み先着率_pct','損益既知数','費用後勝ち数','費用後負け数','既知決済勝率_pct','既知利益_円','既知損失_円','既知差引_円','PF_利益÷損失','旧C1以外取得数','旧C1取得数')
    def metric_row(value: dict) -> list:
        """
        機能: 共通の見やすい列順に指標を並べる。
        引数: value(dict)は27指標。
        返り値: listは表の共通数値列。
        """
        return [percentage(value[name]) if name in ('rate','realized_win_rate') else value[name] for name in metric_columns]
    periods=('全期','前48場','後25場')
    for policy in policies:
        rows=policy['rows'];widths=policy['widths'];hi=policy['hi']
        scene=np.asarray([arrays['session_index'][row[0]] for row in rows],dtype=np.int16)
        assert len({row[0] for row in rows})==len(rows)
        period_values=[]
        for period,label in enumerate(periods):
            eligible=np.arange(73)<48 if period==1 else np.arange(73)>=48 if period==2 else np.ones(73,dtype=bool)
            value=independent.summarize(rows,widths,hi,arrays,hours,eligible[scene],eligible)
            match(value,policy['expected'][period],(policy['id'],label));tested+=len(FIELDS)
            result=metrics(value);period_values.append(result)
            comparison.append([policy['id'],policy['name'],label,int(eligible.sum())]+metric_row(result)+[result['net'] if result['unknown']==0 else None])
        cumulative=0;cumulative_unknown=0;scene_values=[]
        for si,item in enumerate(scenes):
            eligible=np.arange(73)==si;result=metrics(independent.summarize(rows,widths,hi,arrays,hours,scene==si,eligible))
            scene_values.append(result);cumulative+=result['net'];cumulative_unknown+=result['unknown']
            session_rows.append([policy['id'],item['session']]+metric_row(result)+[
                result['net'] if result['unknown']==0 else None,cumulative,cumulative_unknown,cumulative if cumulative_unknown==0 else None])
        full=period_values[0]
        for name in ('count','F','A','N','C','profit','loss','net','known','unknown','wins','loss_trades','new_count','old_count'):
            assert sum(value[name] for value in scene_values)==full[name],(policy['id'],'73場加法',name)
            assert period_values[1][name]+period_values[2][name]==full[name],(policy['id'],'前後加法',name)
        q0_times=[]
        for case,side,event,origin in rows:
            if event>=0:q0_times.append(q0[event]['q0_time']);all_events.add(event)
            else:q0_times.append(legacy_by_case[meta['case_ids'][case]]['origins'][0]['birthQuote']['time'])
            all_cases.add(case)
        for clock,times in (('q0出生',q0_times),('q1取得',[arrays['entry_time'][row[0]] for row in rows])):
            bands=np.asarray([independent.band(meta['sessions'][row[0]],float(at)) for row,at in zip(rows,times,strict=True)])
            for period,label in enumerate(periods):
                eligible_period=np.arange(73)<48 if period==1 else np.arange(73)>=48 if period==2 else np.ones(73,dtype=bool)
                values=[]
                for phase,name in enumerate(('デイ','ナイト米国前','ナイト米国後')):
                    eligible=eligible_period&(hours[:,phase]>0);mask=eligible[scene]&(bands==phase)
                    result=metrics(independent.summarize(rows,widths,hi,arrays,hours[:,phase],mask,eligible));values.append(result)
                    timeband_rows.append([policy['id'],label,clock,name,int(eligible.sum())]+metric_row(result)+[result['net'] if result['unknown']==0 else None])
                for name in ('count','F','A','N','C','profit','loss','net','known','unknown','wins','loss_trades','new_count','old_count'):
                    assert sum(value[name] for value in values)==period_values[period][name],(policy['id'],label,clock,name)
        serialized.append({'id':policy['id'],'name':policy['name'],'kind':policy['kind'],'trial':policy['trial'],
                           'position':policy['position'],'description':policy['description'],
                           'selection_columns':['case_index','side','event_index','width_points','origin','tier'],
                           'selection':[[case,1 if side==0 else -1,event if event>=0 else None,meta['widths'][int(width)],origin,int(tier)]
                                        for (case,side,event,origin),width,tier in zip(rows,widths,policy['tiers'],strict=True)],
                           'horizon':meta['horizon_ids'][hi],'periods':dict(zip(periods,period_values,strict=True))})
    # ----------------------------------------
    # 定義と費用も表に含め、主表だけ読んでも未知と勝率を混同しないようにする。
    conditions=[]
    for key,value,note in (
        ('対象','NK225・旧73場','2026-09-21_Day〜2026-11-10_Day。新7場は含めない'),
        ('数量','各入口mini1枚の独立合算','重複保有を許す研究集計。片側10枚上限付き口座収支ではない'),
        ('費用条件','C5','実BBOスプレッドに加え、手数料往復77円と追加往復滑り1000円を控除'),
        ('倍率_円毎pt',100,'日経225mini 1枚'),('片道手数料_円',38.5,'ユーザー提示の税込額'),
        ('往復手数料_円',77,'38.5円×2'),('追加片道滑り_pt',5,'実BBO以外の費用感度仮定'),
        ('追加往復滑り_円',1000,'5pt×2×100円。実際の確定滑りではない'),
        ('追加往復固定費用_円',1077,'手数料77円＋滑り1000円。実BBOスプレッドは価格に含む'),
        ('先着分類','IFD_FIRST','打切り前に最初のIFDが確定したF/Aを、その後の観測欠損でCに戻さない'),
        ('到達済み先着率','100×F/(F+A)','未到達Nと観測不足Cは分母外。決済勝率とは異なる'),
        ('既知決済勝率','100×費用後利益が正の件数/損益既知数','期限未到達のBBO清算も含む'),
        ('N','両側未到達で期限完了','期限BBOで清算した費用後損益を利益/損失へ算入'),
        ('C','IFD未確定かつ観測不足','損益未知。確定損益0円として扱わない'),
        ('既知差引_円','損益既知分の利益−損失','Cを解決した全収支ではない。全件未知のみなら既知和0でも収支確定ではない'),
        ('全件収支_円','C=0なら既知差引、C>0なら空欄','空欄は未知又は未定義。取引0件の0円と区別'),
        ('累計','場順の既知差引を加算','累計C>0なら全件累計収支は空欄。未知解決前に全収支と称さない'),
        ('PF_利益÷損失','既知利益÷既知損失','損失0なら未定義で空欄'),
        ('判断時計','1分候補の当時q0','5分/15分の定時新規を強制しない。指標の足幅とは別'),
        ('取得時計','q1の正常BBO','候補成立・発注要求だけでは取得数に加えない'),
        ('三時間帯','デイ/ナイトNY09:30前/以後','夏冬自動変換、NY開始同時刻は以後。q0出生/q1取得を別掲'),
        ('頻度分母_時間',720+55/60,'全73場の対象ザラバ。デイ15:40/ナイト05:55前まで'),
        ('場参加','取得数1以上の場','ゼロ取得場も73場表から除外しない'),
        ('旧手法の扱い','固定入口を今回の共通IFDで再観測','旧153の一旦達成判断・旧条件・既存試行は書き換えない'),
        ('未見性','旧73場は既使用','前48場で選択→後25場固定適用も独立未見と呼ばない'),
        ('推定範囲','ラージ板からminiへ約定を代用','mini実板・待ち行列・約定遅延・数量制約は未再現'),
        ('資料順','166_MAIN →166_FRONT →旧対照→近傍','全期最高額だけで主案を置換しない')
    ):conditions.append(['共通',key,str(value),note])
    for policy in policies:
        descriptor=policy['description']
        conditions.extend([[policy['id'],'名称',policy['name'],policy['kind']],
                           [policy['id'],'政策条件',json.dumps(descriptor,ensure_ascii=False,separators=(',',':')),'取得と幅は政策と取得.jsonで再利用可能'],
                           [policy['id'],'入力参照',f"試行{policy['trial']}",'旧固定入口は今回の共通IFD_FIRSTで再観測']])
    result_tables={
        '候補比較':table(['候補ID','候補名','期間','対象場数',*metric_headers,'全件収支_円'],comparison),
        '全セッション':table(['候補ID','セッション',*metric_headers,'全件収支_円','既知累計差引_円','累計観測不足C','全件累計収支_円'],session_rows),
        '時間帯別':table(['候補ID','期間','分類時計','時間帯','対象場数',*metric_headers,'全件収支_円'],timeband_rows),
        '条件一覧':table(['範囲_候補ID','項目','値','根拠_注記'],conditions)}
    assert all(sha(ROOT/name)==record['sha256'] for name,record in before.items())
    selections={'成功':True,'trial':166,'inputs':before,'cost':'C5','classification':'IFD_FIRST',
                'origin_codes':{'0':'主新規又は旧技術入口','1':'旧C1参照','2':'新技術初参加補完'},
                'tier_codes':{'0':'主又は対象外','1':'旧T','2':'長期未知時の局所'},'policies':serialized,
                'cases':[{'case_index':case,'case_id':meta['case_ids'][case],'session':meta['sessions'][case],
                          'q1':[float(arrays['entry_time'][case]),int(arrays['entry_index'][case]),int(arrays['entry_line'][case])],
                          'buy_entry_price':float(arrays['entry_price'][case,0]),'sell_entry_price':float(arrays['entry_price'][case,1]),
                          'legacy_q0':legacy_by_case[meta['case_ids'][case]]['origins'][0]['birthQuote'] if meta['case_ids'][case] in legacy_by_case else None}
                         for case in sorted(all_cases)],
                'events':[{'event_index':event,**q0[event]} for event in sorted(all_events)],
                'financial_array_ref':str(paths[3].relative_to(ROOT)).replace('\\','/'),
                'financial_array_sha256':before[paths[3].relative_to(ROOT).as_posix()]['sha256']}
    save(HERE/'政策と取得.json',selections)
    save(HERE/'tables.json',{'成功':True,'trial':166,'title':'旧73場の入口とIFD幅比較','inputs':before,
                            '率の数値単位':'pctは百分率。例71.75=71.75%。nullは空欄で保存。',
                            'selection_ref':'政策と取得.json','selection_sha256':sha(HERE/'政策と取得.json'),'tables':result_tables})
    save(HERE/'型付き集計の確認.json',{'成功':True,'候補数':len(policies),'期間数':3,'全73場を各候補へ保持':True,
         '表行数':{name:len(value['rows']) for name,value in result_tables.items()},'元配列比較統計セル数':tested,
         '全場加法と三帯加法':True,'零取得と未知と累計を区別':True,'元入力不変':True,'未見7場読取':False,
         'SourceSHA256':sha(Path(__file__)),'tables_SHA256':sha(HERE/'tables.json'),'政策と取得_SHA256':sha(HERE/'政策と取得.json'),
         'CSVとxlsx生成':False,'経過秒':time.monotonic()-begin})
    print(json.dumps({'成功':True,'候補数':len(policies),'表行数':{name:len(value['rows']) for name,value in result_tables.items()},
                      'tables_SHA256':sha(HERE/'tables.json')},ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
