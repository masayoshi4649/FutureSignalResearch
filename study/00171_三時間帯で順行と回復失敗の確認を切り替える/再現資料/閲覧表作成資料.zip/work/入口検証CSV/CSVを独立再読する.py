"""保存CSVを標準ライブラリで全セル再読し、会計と先着の加法を確認する。"""
from pathlib import Path
from collections import defaultdict
import csv
import hashlib
import json
import math
import sys


def digest(path: Path) -> str:
    """
    機能: 検査対象の全物理ファイルをSHA256へ変える。
    引数: path(Path)。
    返り値: strは十六進SHA256。
    """
    with path.open('rb') as source:return hashlib.file_digest(source,'sha256').hexdigest()


def main(source: Path,directory: Path) -> None:
    """
    機能: 四CSVの全値と、取得・先着・損益・累計を独立に検査する。
    引数: source(Path)は型付きJSON、directory(Path)はCSV保存先。
    返り値: None。全セル照合数と候補別加法の検査票を保存する。
    """
    data=json.loads(source.read_text(encoding='utf-8'));report={};records={}
    for name,table in data['tables'].items():
        path=directory/(name+'.csv')
        with path.open(encoding='utf-8-sig',newline='') as stream:actual=list(csv.reader(stream))
        assert actual[0]==table['headers']
        assert len(actual)==len(table['rows'])+1
        typed=[]
        for ri,(got,want) in enumerate(zip(actual[1:],table['rows'],strict=True)):
            assert len(got)==len(want)
            converted=[]
            for j,(cell,value) in enumerate(zip(got,want,strict=True)):
                kind=table['column_types'][j]['type']
                if value is None:assert cell=='';(converted.append(None))
                elif kind=='text':assert cell==value;(converted.append(cell))
                elif kind=='integer':
                    parsed=int(cell);assert parsed==value;(converted.append(parsed))
                else:
                    parsed=float(cell);assert math.isfinite(parsed) and parsed==value,(name,ri,j,parsed,value)
                    converted.append(parsed)
            typed.append(dict(zip(table['headers'],converted,strict=True)))
        records[name]=typed
        report[name]={'行数':len(typed),'列数':len(table['headers']),
            '全セル照合':len(actual)*len(table['headers']),'sha256':digest(path)}
    # ----------------------------------------
    # 四捨五入後の率を合計せず、先着件数と金額だけから各取得群を再構成する。
    sessions=defaultdict(list)
    for row in records['全セッション']:sessions[row['候補ID']].append(row)
    additive=('取得数','順先着F','逆先着A','未到達N','観測不足C','損益既知数',
        '費用後勝ち数','費用後負け数','既知利益_円','既知損失_円','既知差引_円','旧C1以外取得数','旧C1取得数')
    checked=[]
    for identity,rows in sessions.items():
        prior_net=0;prior_c=0
        for row in rows:
            assert row['取得数']==sum(row[k] for k in ('順先着F','逆先着A','未到達N','観測不足C'))
            assert row['既知差引_円']==row['既知利益_円']-row['既知損失_円']
            assert row['取得数']==row['損益既知数']+row['観測不足C']
            prior_net+=row['既知差引_円'];prior_c+=row['観測不足C']
            assert row['既知累計差引_円']==prior_net and row['累計観測不足C']==prior_c
            assert row['全件収支_円']==(row['既知差引_円'] if row['観測不足C']==0 else None)
            assert row['全件累計収支_円']==(prior_net if prior_c==0 else None)
        candidates=[r for r in records['候補比較'] if r['候補ID']==identity]
        preference=('全80場','全期','追加7場','旧73場')
        total=next(r for period in preference for r in candidates if r['期間']==period)
        for field in additive:assert sum(r[field] for r in rows)==total[field],(identity,field)
        f,a=total['順先着F'],total['逆先着A']
        if f+a:assert abs(total['到達済み先着率_pct']-100*f/(f+a))<1e-12
        assert total['対象場数']==len(rows)
        assert total['参加場数']==sum(r['取得数']>0 for r in rows)
        checked.append(identity)
    result={'成功':True,'SourceSHA256':digest(Path(__file__)),'型付き入力SHA256':digest(source),
        'CSV':report,'全場加法確認候補':checked,'未知収支と既知累計を別確認':True}
    target=Path(__file__).resolve().parent/'独立再読確認.json'
    target.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'全セル照合':sum(v['全セル照合'] for v in report.values()),'候補':len(checked)},ensure_ascii=False))


if __name__=='__main__':
    assert len(sys.argv)==3
    main(Path(sys.argv[1]),Path(sys.argv[2]))
