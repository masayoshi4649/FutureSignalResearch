"""既存対照・固定追加期間・数量枠を一組の閲覧四表へまとめる。"""
from pathlib import Path
import sys
import copy
import numpy as np
from 追加表の基盤 import ROOT,read,sha,append_policy,update_types,add_reference,metric_row

sys.path.insert(0,str(ROOT/'work/167固定入口の別期間'))
import 適用基盤167 as BASE
from 共通163 import save
from 評価基盤 import Selection


def from_reference(record: dict,context: object) -> tuple:
    """
    機能: 固定済みの取得配列を共通Selectionへ復元する。
    引数: record(dict)は取得参照、context(GenericContext)は同じ母集団。
    返り値: tuple[Selection,np.ndarray]は全取得と取得ごとの幅添字。
    """
    cases=np.array(record['cases'],dtype=np.int32);events=np.array(record['events'],dtype=np.int32)
    result=Selection(cases,np.array(record['sides'],dtype=np.int8),events,
        context.event_phases[events],np.zeros(len(cases),dtype=bool))
    assert len(cases)==len(set(cases.tolist()))
    return result,np.array(record['widths'],dtype=np.int8)


def add_total(data: dict,identity: str,label: str,old: dict,new: dict) -> None:
    """
    機能: 旧73と追加7の加算可能な数値から全80場の行を作る。
    引数: data(dict)、identity/label(str)、old/new(dict)は各範囲の統計。
    返り値: None。全80の一行を追加し、率を比率の平均で作らない。
    """
    total={k:old[k]+new[k] for k in ('count','F','A','N','C','known','unknown','wins','loss_trades',
        'profit','loss','net','scenes','eligible_scenes','hours')}
    total.update(rate=total['F']/(total['F']+total['A']) if total['F']+total['A'] else None,
        per_hour=total['count']/total['hours'],pf=total['profit']/total['loss'] if total['loss'] else None,
        realized_win_rate=total['wins']/total['known'] if total['known'] else None,
        all_net=total['net'] if total['unknown']==0 else None)
    data['tables']['候補比較']['rows'].append([identity,label,'全80場',80,*metric_row(total)])


def main() -> None:
    """
    機能: 検算済み13対照に167/168と固定済み169選択を接続する。
    引数: なし。完成した各結果の取得参照を使い、入口や幅を再選択しない。
    返り値: None。artifact作者へ渡す型付きJSONと入力指紋を保存する。
    """
    here=Path(__file__).resolve().parent;out=here/'tables.json'
    initial=ROOT/'work/166閲覧集計/tables.json';data=copy.deepcopy(read(initial))
    assert sha(initial)=='f3cd4cf6f47930926411da001bb70dfd93fed32e4b5053e5124ff26a7ab4c9b0'
    add_reference(data,initial)
    old0=BASE.Context165();old=BASE.GenericContext(old0.features,old0.table,old0.capture_rows)
    directory=ROOT/'work/167追加七場の入力';features,captures,_=BASE.load_features(directory/'入口母集団')
    adapter=BASE.module(ROOT/'work/166可変場の数値化/arrays166.py','arrays166_csv')
    complete=read(directory/'生成の完了.json');assert complete['成功']
    new=BASE.GenericContext(features,adapter.load_table(directory/'自然数値表',complete['cache']),captures)
    setting=read(ROOT/'study/00167_固定した複合入口を追加七場へ適用する/条件.json')
    references_path=ROOT/'work/167固定入口の別期間/比較/全取得参照.json'
    references=read(references_path)['rows'];add_reference(data,references_path)
    for candidate in setting['candidates']:
        reference=next(r for r in references if r['id']==candidate['id'])
        selected,widths=from_reference(reference,new);hi=new.table.horizons.index(candidate['horizon'])
        for uniform in (None,125):
            identity='167_'+candidate['id']+('_BRANCH' if uniform is None else '_W125')
            use=widths if uniform is None else np.full(len(widths),new.table.widths.index(125),dtype=np.int8)
            append_policy(data,identity,'追加期間・'+candidate['id']+('枝幅' if uniform is None else '同取得±125'),
                new,selected,use,hi,'追加7場')
            data['tables']['条件一覧']['rows'].append([identity,'固定条件',
                f"{candidate['profile']['id']} / {candidate['hierarchy']['id']} / {candidate['integration']} / {candidate['horizon']}",
                '入口は167の価格参照前に固定。同取得125対照から主案を交換しない。'])
    for candidate in setting['candidates']:
        identity='168_'+candidate['id'];values=[];cumulative=None
        for label,context,folder in [('旧73場',old,'旧73比較'),('追加7場',new,'追加7比較')]:
            path=ROOT/f'work/168数量枠の因果再生/{folder}/全取得参照.json'
            reference=next(r for r in read(path)['rows'] if r['id']==candidate['id']);add_reference(data,path)
            selected,widths=from_reference(reference,context)
            result=append_policy(data,identity,'数量枠・'+candidate['id'],context,selected,widths,
                context.table.horizons.index(candidate['horizon']),label,cumulative,old_periods=label=='旧73場')
            values.append(result['metrics']);cumulative=result['cumulative']
        add_total(data,identity,'数量枠・'+candidate['id'],*values)
        data['tables']['条件一覧']['rows'].append([identity,'数量枠','買売各10枚・注文各1枚・未決予約を含む',
            '枠不足はそのq0要求を棄却し次q0で再判断。未知は場末まで枠保持、全件収支未確定を0にしない。'])
    # ----------------------------------------
    # 追加探索は選択が封印され、指定期間の比較が完成した後でのみ接続する。
    additional=here/'追加政策.json'
    latest_trial=169;priority_order=[]
    if additional.exists():
        extra=read(additional);assert extra['成功']
        latest_trial=max(latest_trial,extra.get('trial',169))
        priority_order=extra.get('priority_order',[])
        for item in extra['policies']:
            candidate=item['candidate'];identity=item['id'];values=[];cumulative=None
            for label,context,path_name in [('旧73場',old,'old_reference'),('追加7場',new,'new_reference')]:
                if not item.get(path_name):continue
                path=ROOT/item[path_name];add_reference(data,path)
                reference=next(r for r in read(path)['rows'] if r['id']==item['reference_id'])
                selected,widths=from_reference(reference,context)
                if item.get('uniform_width') is not None:
                    widths=np.full(len(widths),context.table.widths.index(item['uniform_width']),dtype=np.int8)
                result=append_policy(data,identity,item['label'],context,selected,widths,
                    context.table.horizons.index(candidate['horizon']),label,cumulative,old_periods=label=='旧73場')
                values.append(result['metrics']);cumulative=result['cumulative']
            if len(values)==2:add_total(data,identity,item['label'],*values)
            width_text=(f"{candidate['momentum_width']},{candidate['fade_width']}pt"
                if 'momentum_width' in candidate else
                f"{candidate['momentum_atr_multiplier']},{candidate['fade_atr_multiplier']}ATR / {candidate['timeband_scale']}")
            if item.get('uniform_width') is not None:width_text=f"同一取得の全枝±{item['uniform_width']}pt再観測"
            data['tables']['条件一覧']['rows'].append([identity,'固定選択条件',
                f"{candidate['profile']['id']} / {candidate['hierarchy']['id']} / {candidate['integration']} / {candidate['horizon']} / {width_text}",
                item.get('note','前48場固定選択、cap10。新7場の全候補探索はせず、A/Bを結果で交換しない。')])
    data['tables']['条件一覧']['rows'].extend([
        ['共通','追加期間','2026-11-10_Night〜2026-11-13_Nightの7場',
            '166旧73場と別に評価。167固定二案の出生は金融入力前に封印。'],
        ['共通','数量比較','168以降はcap10、166/167等の従来行は独立一枚合算',
            '同じ候補名でも数量枠が違うのでIDを分ける。mini固定10枚へ損益を乗算しない。']])
    for row in data['tables']['条件一覧']['rows']:
        if row[0]=='共通' and row[1]=='対象':
            row[2]='NK225・旧73場＋追加7場（全80場）'
            row[3]='旧対照は旧73場のみ。171/168/170の固定主案は両期間を分けて比較。'
        elif row[0]=='共通' and row[1]=='数量':
            row[2]='候補別：独立1枚／片側10枚上限'
            row[3]='171/168/170は注文各1枚・買売各10枚。166/167等は独立1枚合算。同取得125は数量再生なしの出口診断。'
    data.update(trial=latest_trial,title='複合入口・任意幅・追加期間・数量枠の比較')
    # 主結果を先頭にし、全80の後に期間分解を読む。場の原記録は各候補内で日付順を保つ。
    identities=list(dict.fromkeys(row[0] for row in data['tables']['候補比較']['rows']))
    ordered=list(dict.fromkeys(priority_order+identities));rank={name:i for i,name in enumerate(ordered)}
    def period_rank(name: str) -> int:
        """
        機能: 合計から期間分解へ読む順番を決める。
        引数: name(str)は期間名。
        返り値: intは表示優先順。数値の選択基準には使用しない。
        """
        if name=='全80場':return 0
        if name in ('全期','旧73場'):return 1
        if '前48' in name:return 2
        if '後25' in name:return 3
        return 4
    data['tables']['候補比較']['rows'].sort(key=lambda r:(rank[r[0]],period_rank(r[2])))
    data['tables']['全セッション']['rows'].sort(key=lambda r:(rank[r[0]],r[1]))
    data['tables']['時間帯別']['rows'].sort(key=lambda r:(rank[r[0]],period_rank(r[1])))
    add_reference(data,Path(__file__));add_reference(data,here/'追加表の基盤.py')
    update_types(data)
    save(out,data)
    save(here/'型付き接続の確認.json',{'成功':True,'出力SHA256':sha(out),
        '表':{k:{'行数':len(v['rows']),'列数':len(v['headers'])} for k,v in data['tables'].items()},
        '初期13対照の数値は変更なし':True,'率は分子分母を加算して算出':True})
    print(__import__('json').dumps({'成功':True,'出力SHA256':sha(out),'表':{k:len(v['rows']) for k,v in data['tables'].items()}},ensure_ascii=False))


if __name__=='__main__':
    main()
