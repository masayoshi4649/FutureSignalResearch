import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {Workbook} from '@oai/artifact-tool';

const here=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(here,'../..');
const input=path.resolve(process.argv[2]);
const output=path.resolve(process.argv[3]);

/**
 * 機能: 入力と出力の全物理内容をSHA256へ変える。
 * @param {Buffer|string} value - 指紋を記録する内容。
 * @returns {string} 十六進のSHA256。
 */
function sha(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

/**
 * 機能: 型付き一セルを引用規則に従うCSV文字列へ変える。
 * @param {number|string|boolean|null} value - 元の型付き値。
 * @returns {string} 未定義nullを空欄としたCSV一セル。
 */
function field(value) {
  const text=value===null?'':String(value);
  return /[",\r\n]/.test(text)?'"'+text.replaceAll('"','""')+'"':text;
}

// ----------------------------------------
assert.ok(output.startsWith(path.join(root,'outputs')+path.sep));
const bytes=await fs.readFile(input);
const data=JSON.parse(bytes);
let previousProof=null;
try { previousProof=JSON.parse(await fs.readFile(path.join(here,'作成確認.json'),'utf8')); }
catch (error) { if(error.code!=='ENOENT') throw error; }
assert.equal(data.成功,true);
assert.deepEqual(Object.keys(data.tables),['候補比較','全セッション','時間帯別','条件一覧']);
for (const [name,ref] of Object.entries(data.inputs)) {
  assert.equal(sha(await fs.readFile(path.resolve(root,ref.path??name))),ref.sha256);
}
const workbook=Workbook.create();
const tables=[];
for (const [name,t] of Object.entries(data.tables)) {
  const original=[t.headers,...t.rows];
  assert.ok(original.every(r=>r.length===t.headers.length));
  assert.equal(t.column_types.length,t.headers.length);
  for (const row of t.rows) {
    for (let j=0;j<row.length;j++) {
      const value=row[j],spec=t.column_types[j];
      if (value===null) assert.equal(spec.nullable,true);
      else if (spec.type==='text') assert.equal(typeof value,'string');
      else {
        assert.equal(typeof value,'number');
        assert.ok(Number.isFinite(value));
        if (spec.type==='integer') assert.ok(Number.isSafeInteger(value));
      }
    }
  }
  const sheet=workbook.worksheets.add(name);
  sheet.showGridLines=false;
  const range=sheet.getRangeByIndexes(0,0,original.length,t.headers.length);
  range.values=original;
  range.format.font={name:'Arial',size:10};
  range.format.verticalAlignment='center';
  sheet.getRangeByIndexes(0,0,1,t.headers.length).format={fill:'#334155',
    font:{name:'Arial',size:10,color:'#FFFFFF',bold:true},wrapText:true,
    horizontalAlignment:'center',rowHeight:46};
  for (let j=0;j<t.headers.length;j++) {
    const column=sheet.getRangeByIndexes(0,j,original.length,1);
    const body=sheet.getRangeByIndexes(1,j,t.rows.length,1);
    const type=t.column_types[j].type;
    column.format.columnWidthPx=type==='text'?(j===0?185:145):112;
    if (name==='候補比較' && j===1) column.format.columnWidthPx=260;
    if (t.headers[j].endsWith('_pct')) column.format.columnWidthPx=135;
    if (name==='条件一覧') column.format.columnWidthPx=[190,180,370,500][j];
    if (type==='integer') body.setNumberFormat('#,##0');
    else if (type==='number') body.setNumberFormat(t.headers[j].endsWith('_pct')?'0.00"%"':'0.000');
    else body.format.horizontalAlignment='left';
  }
  sheet.freezePanes.freezeRows(1);
  tables.push({name,t,original,sheet,range});
}
workbook.recalculate();
await fs.mkdir(output,{recursive:true});
const previewDirectory=path.join(here,'表示確認');
await fs.mkdir(previewDirectory,{recursive:true});
const proof={成功:true,試行:data.trial,入力SHA256:sha(bytes),元正本:data.inputs,node:process.version,
  出力器SHA256:sha(await fs.readFile(fileURLToPath(import.meta.url))),表:{}};
for (const {name,t,original,range} of tables) {
  const actual=range.values;
  assert.deepEqual(actual,original);
  assert.ok(range.formulas.flat().every(v=>v===''||v===null||v===undefined));
  const body='\uFEFF'+actual.map(r=>r.map(field).join(',')).join('\r\n')+'\r\n';
  const csvPath=path.join(output,name+'.csv');
  try {
    const existing=await fs.readFile(csvPath);
    assert.equal(sha(existing),previousProof?.表?.[name]?.SHA256,'既存CSVは前回の作者正本と一致する必要がある');
  } catch (error) { if(error.code!=='ENOENT') throw error; }
  await fs.writeFile(csvPath,body,{encoding:'utf8',flag:'w'});
  const end=name==='条件一覧'?'D':'M';
  const inspection=await workbook.inspect({kind:'table',range:name+'!A1:'+end+'8',
    include:'values,formulas',tableMaxRows:8,tableMaxCols:13,maxChars:1000});
  const preview=await workbook.render({sheetName:name,range:'A1:'+end+'9',scale:1,format:'png'});
  await fs.writeFile(path.join(previewDirectory,name+'.png'),new Uint8Array(await preview.arrayBuffer()),{flag:'w'});
  proof.表[name]={データ行:t.rows.length,列:t.headers.length,全セル照合:actual.length*t.headers.length,
    SHA256:sha(body),inspect:inspection.ndjson};
}
const errors=await workbook.inspect({kind:'match',
  searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',
  options:{useRegex:true,maxResults:10},maxChars:1000});
proof.エラー走査=errors.ndjson;
assert.equal(sha(await fs.readFile(input)),sha(bytes));
for (const [name,ref] of Object.entries(data.inputs)) {
  assert.equal(sha(await fs.readFile(path.resolve(root,ref.path??name))),ref.sha256);
}
await fs.writeFile(path.join(here,'作成確認.json'),JSON.stringify(proof,null,2)+'\n',{encoding:'utf8',flag:'w'});
console.log(JSON.stringify({成功:true,表:Object.fromEntries(Object.entries(proof.表).map(([k,v])=>[k,
  {データ行:v.データ行,列:v.列,全セル照合:v.全セル照合,SHA256:v.SHA256}]))}));
