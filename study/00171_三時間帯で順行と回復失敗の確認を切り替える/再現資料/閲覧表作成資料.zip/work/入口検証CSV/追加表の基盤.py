"""固定期間と数量枠の結果を既存四表と同じ列定義へ接続する。"""
from pathlib import Path
import sys
import copy
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work/167固定入口の別期間'))
from 適用基盤167 import statistics,read,sha


def metric_row(m: dict) -> list:
    """
    機能: 率の百分値・未知全収支を含む共通19列を作る。
    引数: m(dict)は任意場statisticsの出力。
    返り値: listは取得数から全件収支までの型付き値。
    """
    return [m['count'],m['scenes'],m['per_hour'],m['F'],m['A'],m['N'],m['C'],
        None if m['rate'] is None else 100*m['rate'],m['known'],m['wins'],m['loss_trades'],
        None if m['realized_win_rate'] is None else 100*m['realized_win_rate'],
        m['profit'],m['loss'],m['net'],m['pf'],m['count'],0,m['all_net']]


def append_policy(data: dict,identity: str,label: str,context: object,selected: object,
                  widths: np.ndarray,hi: int,period_label: str,
                  cumulative: dict | None=None,old_periods: bool=False) -> dict:
    """
    機能: 一候補の全場・全取得を落とさず四表へ追記する。
    引数: data(dict)、identity/label/period_label(str)、context(GenericContext)、selected(Selection)、
          widths(np.ndarray[int])、hi(int)、cumulative(dict|None)、old_periods(bool)。
    返り値: dictは全期統計と更新後の累計。dataの行を追記する。
    """
    n=len(context.scenes);scenes=context.case_scene[selected.cases]
    periods=[(period_label,np.ones(n,dtype=bool))]
    if old_periods:
        assert n==73
        periods.extend([(period_label+'・前48場',np.arange(n)<48),(period_label+'・後25場',np.arange(n)>=48)])
    total=None
    for period,eligible in periods:
        metric=statistics(context,selected,widths,hi,eligible[scenes],eligible)
        if total is None:total=metric
        data['tables']['候補比較']['rows'].append([identity,label,period,int(eligible.sum()),*metric_row(metric)])
        for clock,phases in [('q0出生',selected.phases),('q1取得',context.case_phases[selected.cases])]:
            for band,name in enumerate(('デイ','ナイト米国前','ナイト米国後')):
                eligible_band=eligible&(context.hours[:,band]>0)
                metric=statistics(context,selected,widths,hi,eligible[scenes]&(phases==band),eligible_band,
                    float(context.hours[eligible,band].sum()))
                data['tables']['時間帯別']['rows'].append([identity,period,clock,name,int(eligible_band.sum()),*metric_row(metric)])
    current=copy.deepcopy(cumulative) if cumulative is not None else {'net':0,'unknown':0}
    for scene,session in enumerate(context.sessions):
        eligible=np.arange(n)==scene
        metric=statistics(context,selected,widths,hi,scenes==scene,eligible)
        current['net']+=metric['net'];current['unknown']+=metric['unknown']
        data['tables']['全セッション']['rows'].append([identity,session,*metric_row(metric),
            current['net'],current['unknown'],current['net'] if current['unknown']==0 else None])
    return {'metrics':total,'cumulative':current}


def update_types(data: dict) -> None:
    """
    機能: 新たな0到達・0取得を含め、実際のnullを列定義へ反映する。
    引数: data(dict)は全四表。
    返り値: None。型は既存定義を保ちnullableだけ実値に合わせる。
    """
    for table in data['tables'].values():
        for j,spec in enumerate(table['column_types']):
            spec['nullable']=any(row[j] is None for row in table['rows'])
        assert all(len(row)==len(table['headers']) for row in table['rows'])


def add_reference(data: dict,path: Path) -> None:
    """
    機能: CSVへ追加した元結果を一度だけ指紋参照へ加える。
    引数: data(dict)、path(Path)は追加正本。
    返り値: None。全原入力を大量転記せずpathとSHAを保持する。
    """
    data['inputs'][path.relative_to(ROOT).as_posix()]={'path':path.relative_to(ROOT).as_posix(),'sha256':sha(path)}
