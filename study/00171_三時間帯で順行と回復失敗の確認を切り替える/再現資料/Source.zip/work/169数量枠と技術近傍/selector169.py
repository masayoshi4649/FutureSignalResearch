"""169の前48場統計だけからA/Bを選ぶ純部品。ファイル・後半・金融原始値は受け取らない。"""
import numpy as np

Z95=1.959963984540054
REQUIRED=('count','F','A','N','C','known','unknown','profit','loss','net','scenes','all_scenes','per_hour')


def derived(values: np.ndarray,fields: list[str]) -> dict:
    """
    機能: 先着・費用後PF・Wilson下限を基本計数から計算し整合性を検査する。
    引数: values(np.ndarray[...,F])、fields(list[str])は一意な列名。
    返り値: dict[str,np.ndarray]は同じ前置形状の指標。ゼロ到達率とゼロ利益損失PFはNaN。
    """
    column={name:values[...,fields.index(name)] for name in REQUIRED}
    for name in ('count','F','A','N','C','known','unknown','scenes'):
        value=column[name]
        if not np.isfinite(value).all() or np.any(value<0) or np.any(value!=np.floor(value)):
            raise ValueError(f'{name}は非負の有限整数である必要がある')
    count=column['count'];resolved=column['F']+column['A']
    if not np.array_equal(resolved+column['N']+column['C'],count):raise ValueError('F+A+N+Cとcountが不整合')
    if not np.array_equal(column['known']+column['unknown'],count):raise ValueError('known+unknownとcountが不整合')
    if np.any(column['scenes']>48) or np.any(column['scenes']>count):raise ValueError('前48場の取得場数が不整合')
    flag=column['all_scenes']
    if not np.isfinite(flag).all() or not np.isin(flag,(0.,1.)).all():raise ValueError('all_scenesは0/1の真偽値である必要がある')
    for name in ('profit','loss','net','per_hour'):
        if not np.isfinite(column[name]).all():raise ValueError(f'{name}は有限値である必要がある')
    if np.any(column['profit']<0) or np.any(column['loss']<0) or np.any(column['per_hour']<0):
        raise ValueError('利益・損失・頻度は非負である必要がある')
    if not np.allclose(column['net'],column['profit']-column['loss'],rtol=0,atol=1e-6):
        raise ValueError('netとprofit-lossが不整合')
    rate=np.divide(column['F'],resolved,out=np.full_like(count,np.nan),where=resolved>0)
    pf=np.divide(column['profit'],column['loss'],out=np.full_like(count,np.nan),where=column['loss']>0)
    pf=np.where((column['loss']==0)&(column['profit']>0),np.inf,pf)
    unknown_fraction=np.divide(column['unknown'],count,out=np.full_like(count,np.nan),where=count>0)
    wilson=np.full_like(count,np.nan);mask=resolved>0;n=resolved[mask];p=rate[mask];z2=Z95**2
    wilson[mask]=(p+z2/(2*n)-Z95*np.sqrt(p*(1-p)/n+z2/(4*n*n)))/(1+z2/n)
    if 'rate' in fields:
        supplied=values[...,fields.index('rate')]
        if not np.allclose(supplied,rate,rtol=0,atol=1e-10,equal_nan=True):raise ValueError('保存rateとF/(F+A)が不整合')
    return {**column,'resolved':resolved,'rate':rate,'pf':pf,'unknown_fraction':unknown_fraction,'wilson95_lower':wilson}


def choose(mask: np.ndarray,values: dict) -> dict:
    """
    機能: 適格政策をWilson下限・取得数・PF・安定添字の順で順位付けする。
    引数: mask(np.ndarray[N,bool])、values(dict[str,np.ndarray[N]])。
    返り値: dictはeligible/ranking/position/score。適格なしはpositionとscoreがNone。
    """
    indices=np.flatnonzero(mask)
    if len(indices):
        order=np.lexsort((indices,-values['pf'][indices],-values['count'][indices],-values['wilson95_lower'][indices]))
        ranking=indices[order];position=int(ranking[0]);score=float(values['wilson95_lower'][position])
    else:ranking=indices;position=None;score=None
    return {'eligible':mask.copy(),'ranking':ranking,'position':position,'score':score}


def select_front48(metrics: np.ndarray,bands: np.ndarray,fields: list[str],book: dict) -> dict:
    """
    機能: 前48場の固定支持を満たすAと三帯支持を重ねたBを純粋に選ぶ。
    引数: metrics(np.ndarray[N,F])は前48場だけ、bands(np.ndarray[N,3,F])は同期間q0三帯だけ、
          fields(list[str])は共通列名、book(dict)は固定169条件。Nは安定政策順、自然実行では3840。
    返り値: dictはA/Bのeligible/ranking/position/score、derived/band_derivedとstable_position。
            後25場・追加七場・全期成績・policy金融原始値を渡す引数は存在しない。
    """
    if not isinstance(fields,list) or len(fields)!=len(set(fields)):raise ValueError('fieldsは一意な列名listである必要がある')
    missing=[name for name in REQUIRED if name not in fields]
    if missing:raise ValueError(f'必要列がない:{missing}')
    metrics=np.asarray(metrics,dtype=float);bands=np.asarray(bands,dtype=float)
    if metrics.ndim!=2 or metrics.shape[1]!=len(fields) or bands.shape!=(len(metrics),3,len(fields)):
        raise ValueError('入力形状は前48[N,F]とq0三帯[N,3,F]だけを許す')
    if book.get('trial')!=169:raise ValueError('169の固定条件が必要')
    support=book['base_support'];expected={'minimum_count':250,'minimum_resolved':100,'minimum_rate':.7,
        'minimum_per_hour':.75,'all_48_scenes':True,'maximum_unknown_fraction':.1,'minimum_pf':1.2,'minimum_net':0}
    if support!=expected:raise ValueError('固定base_supportと異なる条件は新試行で扱う')
    if set(book['selectors'])!={'A','B'}:raise ValueError('固定A/Bを要求する')
    values=derived(metrics,fields);band_values=derived(bands,fields)
    for name in ('count','F','A','N','C','known','unknown','profit','loss','net'):
        if not np.allclose(values[name],band_values[name].sum(axis=1),rtol=0,atol=1e-6):
            raise ValueError(f'前48全体とq0三帯の{name}合計が不整合')
    base=(values['count']>=support['minimum_count'])&(values['resolved']>=support['minimum_resolved'])
    base&=(values['rate']>=support['minimum_rate'])&(values['per_hour']>=support['minimum_per_hour'])
    base&=(values['all_scenes']==1)&(values['scenes']==48)
    base&=(values['unknown_fraction']<=support['maximum_unknown_fraction'])
    base&=(values['pf']>=support['minimum_pf'])&(values['net']>support['minimum_net'])
    band_ok=(band_values['resolved']>=6)&(band_values['rate']>=.55)&(band_values['pf']>=1.05)&(band_values['net']>0)
    robust=base&band_ok.all(axis=1)
    return {'A':choose(base,values),'B':choose(robust,values),'derived':values,'band_derived':band_values,
        'band_eligible':band_ok,'stable_position':np.arange(len(metrics),dtype=np.int64),
        'training_scope':'前48場のみ、q0三帯。後半・追加場の入力なし。','wilson_z':Z95}
