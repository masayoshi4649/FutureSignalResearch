"""当時の未決予約・取得・決済イベントだけで片側数量枠を再生する170の配列幅版純部品。"""
import heapq
import math
import numpy as np


def replay(event_keys: list,event_scenes: np.ndarray,scene_starts: np.ndarray,scene_ends: np.ndarray,
           captures: list,core: np.ndarray,branches: np.ndarray,technical: np.ndarray,tiers: np.ndarray,
           momentum_width: np.ndarray,fade_width: np.ndarray,technical_width: int,exit_lookup: object,
           capacity: int|None=None,after_seconds: int=2700) -> dict:
    """
    機能: q0要求を順に受け、受理時の予約枠・実取得・到来した決済だけで数量制限する。
    引数: event_keys(list[tuple])は時刻/index/line、event_scenes(np.ndarray[N])、
          scene_starts/scene_ends(np.ndarray[S])は場時計、captures(list[dict])は
          status/finish_keyを持ち、filledではcase(int)/fill_keyも持つ純時計記録。
          core/branches/technical/tiers(np.ndarray[N])は固定出生、主二width(np.ndarray[N])は当時対称幅、technical_width(int)は固定補完幅。
          exit_lookup(callable)は取得後だけ(case,side0買1売,width)から既知exit秒又は未知Noneを返す。
          capacity(int|None)は両側それぞれの枠、Noneは無制限、after_seconds(int)は補完開始秒。
    返り値: dictは取得records、全要求requests、場別audits。金融net/labelを引数に取らない。
            未来exitはキューへ置くだけで、その時刻が来るまで枠を解放しない。
    """
    n=len(event_keys);s=len(scene_starts)
    assert len(captures)==n and len(scene_ends)==s and np.shape(event_scenes)==(n,)
    for array in (core,branches,technical,tiers):assert np.shape(array)==(n,)
    assert np.isin(core,(-1,0,1)).all() and np.isin(technical,(-1,0,1)).all()
    assert np.array_equal(np.asarray(branches)==-1,np.asarray(core)==0)
    assert np.isin(np.asarray(branches)[np.asarray(core)!=0],(0,1)).all()
    assert np.isin(np.asarray(tiers)[np.asarray(technical)!=0],(1,2)).all()
    assert capacity is None or (type(capacity) is int and capacity>0)
    assert type(technical_width) is int and technical_width>0
    momentum_width=np.asarray(momentum_width);fade_width=np.asarray(fade_width)
    assert momentum_width.shape==fade_width.shape==(n,)
    assert np.issubdtype(momentum_width.dtype,np.integer) and np.issubdtype(fade_width.dtype,np.integer)
    assert (momentum_width>=0).all() and (fade_width>=0).all()
    chosen_width=np.where(np.asarray(branches)==0,momentum_width,fade_width)
    core=np.where(chosen_width>0,core,0).astype(np.int8)
    branches=np.where(core!=0,branches,-1).astype(np.int8)
    assert np.isfinite(scene_starts).all() and np.isfinite(scene_ends).all()
    assert np.all(np.asarray(scene_ends)>np.asarray(scene_starts))
    previous=None
    for event,key in enumerate(event_keys):
        assert len(key)==3 and all(math.isfinite(v) for v in key)
        scene=int(event_scenes[event]);assert 0<=scene<s and scene_starts[scene]<=key[0]<scene_ends[scene]
        current=(scene,*key);assert previous is None or current>previous;previous=current
    records=[];requests=[];audits=[];serial=0
    # ----------------------------------------
    # 場ごとに状態を閉じる。未知建玉は場末まで保有し、価格0の決済は作らない。
    for scene in range(s):
        events=np.flatnonzero(np.asarray(event_scenes)==scene)
        held=np.zeros(2,dtype=np.int64);pending_count=np.zeros(2,dtype=np.int64)
        pending={};positions={};seen_cases=set();queue=[];ever_acquired=False
        audit={'scene_index':scene,'events':len(events),'accepted_core':0,'accepted_technical':0,
            'quantity_rejected_core':0,'quantity_rejected_technical':0,'quantity_rejected_by_side':[0,0],
            'alias_fills_skipped':0,'cancelled':0,'filled':0,'unknown_held_to_end':0,
            'peak_held':[0,0],'peak_pending':[0,0],'peak_reserved_total':[0,0],
            'technical_wait_core_pending':0,'pending_at_scene_end':[0,0]}

        def observe() -> None:
            """
            機能: 保有・未決・合計の最大と枠不変式を確認する。
            引数: なし。場内状態を参照する。
            返り値: None。
            """
            assert (held>=0).all() and (pending_count>=0).all()
            if capacity is not None:assert (held+pending_count<=capacity).all()
            for name,values in [('peak_held',held),('peak_pending',pending_count),('peak_reserved_total',held+pending_count)]:
                audit[name]=np.maximum(audit[name],values).tolist()

        def advance(now: tuple) -> None:
            """
            機能: 現在原行までに到来した取得/取消/決済だけを状態へ反映する。
            引数: now(tuple)は当時原行キー。
            返り値: None。同秒exitの原行不明は無限index/lineで秒末まで保有する。
            """
            nonlocal ever_acquired,serial
            while queue and queue[0][0]<=now:
                key,_,kind,token=heapq.heappop(queue)
                if kind=='exit':
                    position=positions.pop(token);held[position['side']]-=1;observe();continue
                request=pending.pop(token);side=request['side'];pending_count[side]-=1
                if kind=='cancel':audit['cancelled']+=1;observe();continue
                assert kind=='fill';case=request['case']
                if case in seen_cases:
                    audit['alias_fills_skipped']+=1;observe();continue
                seen_cases.add(case);ever_acquired=True;held[side]+=1;audit['filled']+=1
                record={name:request[name] for name in ('event','case','side','width','origin','tier')}
                records.append(record);positions[token]=record
                exit_time=exit_lookup(case,side,record['width'])
                if exit_time is None:
                    exit_time=float(scene_ends[scene]);audit['unknown_held_to_end']+=1
                else:
                    assert math.isfinite(exit_time) and key[0]<=exit_time<=scene_ends[scene]
                serial+=1;heapq.heappush(queue,((float(exit_time),math.inf,math.inf),serial,'exit',token));observe()

        def request(event: int,side: int,width: int,origin: int,tier: int) -> None:
            """
            機能: 空き枠がある要求だけを受理し、未決予約と将来の時計イベントを作る。
            引数: event/side/width/origin/tier(int)は当時の要求情報。
            返り値: None。数量棄却は未決として数えず、そのq0で別側へ代用しない。
            """
            nonlocal serial
            row={'event':int(event),'scene_index':scene,'side':side,'width':width,'origin':origin,'tier':tier,
                'at':list(event_keys[event]),'held_before':int(held[side]),'pending_before':int(pending_count[side])}
            if capacity is not None and held[side]+pending_count[side]>=capacity:
                row['accepted']=False;requests.append(row)
                audit['quantity_rejected_core' if origin==0 else 'quantity_rejected_technical']+=1
                audit['quantity_rejected_by_side'][side]+=1;return
            row['accepted']=True;requests.append(row)
            capture=captures[event];key=tuple(capture['fill_key'] if capture['status']=='filled' else capture['finish_key'])
            assert event_keys[event]<=key and key[0]>=event_keys[event][0]
            token=len(requests)-1;pending[token]={**row,'case':int(capture['case']) if capture['status']=='filled' else -1}
            pending_count[side]+=1;audit['accepted_core' if origin==0 else 'accepted_technical']+=1
            serial+=1;heapq.heappush(queue,(key,serial,'fill' if capture['status']=='filled' else 'cancel',token));observe()

        for event in events:
            event=int(event);now=tuple(event_keys[event]);advance(now)
            if core[event]!=0:
                width=int(momentum_width[event] if branches[event]==0 else fade_width[event])
                request(event,0 if core[event]==1 else 1,width,0,0);continue
            if now[0]<scene_starts[scene]+after_seconds or ever_acquired or technical[event]==0:continue
            if any(value['origin']==2 for value in pending.values()):continue
            if any(value['origin']==0 for value in pending.values()):
                audit['technical_wait_core_pending']+=1;continue
            request(event,0 if technical[event]==1 else 1,technical_width,2,int(tiers[event]))
        advance((float(scene_ends[scene]),math.inf,math.inf))
        audit['pending_at_scene_end']=pending_count.tolist()
        audit['held_at_scene_end']=held.tolist();assert not positions and (held==0).all()
        audits.append(audit)
    records.sort(key=lambda r:(r['event'],r['origin']))
    assert len({r['case'] for r in records})==len(records)
    return {'records':records,'requests':requests,'audits':audits,'capacity':capacity,
        'contracts_per_request':1,'exit_clock':'同秒決済は秒末解放、未知は場末まで保持'}
