"""当時ATRとq0三帯だけから主枝の対称幅を選ぶ純関数。"""
import numpy as np


def choose_widths(atr: np.ndarray,phases: np.ndarray,momentum_multiplier: float,
                  fade_multiplier: float,scale: dict,grid: list) -> dict:
    """
    機能: ATR×枝倍率×当時三帯倍率以上の最小gridを選び、上限へclampする。
    引数: atr(np.ndarray[N])は当時M5 ATR、phases(np.ndarray[N])は0DAY/1PRE/2POST、
          momentum_multiplier/fade_multiplier(float)は事前倍率、scale(dict)はDAY/PRE/POST倍率、
          grid(list[number])は厳密昇順の正の整数幅。
    返り値: dictはmomentum_widths/fade_widths[N]int64とvalid[N]bool。
            ATR非有限/非正は両幅0で未知を保持し、教師・取得・金融を入力に取らない。
    """
    values=np.asarray(atr,dtype=np.float64);bands=np.asarray(phases)
    assert values.ndim==1 and bands.shape==values.shape and np.isin(bands,(0,1,2)).all()
    assert np.isfinite(momentum_multiplier) and momentum_multiplier>0
    assert np.isfinite(fade_multiplier) and fade_multiplier>0
    widths=np.asarray(grid,dtype=np.float64)
    assert widths.ndim==1 and len(widths)>0 and np.isfinite(widths).all()
    assert (widths>0).all() and (widths==np.floor(widths)).all() and (np.diff(widths)>0).all()
    scales=np.array([scale[name] for name in ('DAY','PRE','POST')],dtype=np.float64)
    assert np.isfinite(scales).all() and (scales>0).all()
    valid=np.isfinite(values)&(values>0);result={'valid':valid}
    for name,multiplier in [('momentum_widths',momentum_multiplier),('fade_widths',fade_multiplier)]:
        with np.errstate(over='ignore',invalid='ignore'):target=values*multiplier*scales[bands.astype(int)]
        index=np.minimum(np.searchsorted(widths,target,side='left'),len(widths)-1)
        chosen=widths[index].astype(np.int64);result[name]=np.where(valid,chosen,0)
    return result
