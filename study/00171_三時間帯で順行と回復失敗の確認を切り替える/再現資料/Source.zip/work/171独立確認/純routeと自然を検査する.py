"""171の全純出生、全配列、支持全金融、層別oracle、固定二期間を確認する。"""
from pathlib import Path
from types import SimpleNamespace
from itertools import product
from concurrent.futures import ProcessPoolExecutor
import importlib.util
import math
import sys
import time

import numpy as np

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
AUTHOR=ROOT/'work/171三帯の入口切替';OUT=AUTHOR/'旧73探索'
BOOK=ROOT/'study/00171_三時間帯で順行と回復失敗の確認を切り替える/条件.json'
BOOK_SHA='c310ea07df25078b2b811fc5422849c07277eef88fcd0a0693d581a6fa9dc766'


def module(path: Path,name: str) -> object:
    """
    機能: mainを呼ばず独立関数又は比較対象を読む。
    引数: path(Path)、name(str)はSourceと識別名。
    返り値: objectはmodule。
    """
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec)
    sys.modules[name]=value;spec.loader.exec_module(value);return value


PREVIOUS=ROOT/'work/167_168自然独立確認/出生と全自然政策を検算する.py'
QA170=ROOT/'work/170自然独立確認/旧七十三場を層別検算する.py'
previous=module(PREVIOUS,'qa171_previous');qa170=module(QA170,'qa171_quantity')
read=previous.read;save=previous.save;sha=previous.sha
ENGINE_PATH=ROOT/'work/168数量枠の因果再生/engine168.py'
engine=module(ENGINE_PATH,'unchanged_engine168_for171')


def confirmation(original: np.ndarray,confirm: np.ndarray,background: np.ndarray,q0: list,lifetime: int) -> np.ndarray:
    """
    機能: 反対側armを行順に保持し、全場履歴で初確認を消費する独立式。
    引数: original(np.ndarray[N])、confirm/background(np.ndarray[2,N])、q0(list[dict])、lifetime(int秒)。
    返り値: np.ndarray[int8,N]は確認時だけの反対方向。帯境界でresetしない。
    """
    active={1:None,-1:None};output=[];previous_direction=0
    for event,row in enumerate(q0):
        now=row['q0_time']
        if event==0 or row['session_index']!=q0[event-1]['session_index'] or now-q0[event-1]['q0_time']>180:
            active={1:None,-1:None};previous_direction=0
        direction=int(original[event])
        if direction and direction!=previous_direction:active[-direction]=now
        hits=[]
        for side in (1,-1):
            at=active[side]
            if at is None:continue
            if now-at>lifetime:active[side]=None;continue
            si=0 if side==1 else 1
            if confirm[si,event] and background[si,event]:hits.append(side);active[side]=None
        output.append(hits[0] if len(hits)==1 else 0);previous_direction=direction
    return np.asarray(output,dtype=np.int8)


def option_births(data: object,profile: dict,options: list,catalog: dict) -> tuple:
    """
    機能: 元技術条件・長期4票・確認動力から8候補を別式で計算する。
    引数: data(SimpleNamespace)、profile(dict)、options(list[dict])、catalog(dict)は特徴と固定辞書。
    返り値: tuple[np.ndarray,np.ndarray]は8方向と枝。
    """
    mp=previous.rule_direction(data,catalog[profile['momentum']]);original=previous.rule_direction(data,catalog[profile['fade']])
    index={name:i for i,name in enumerate(data.columns)};votes=[];basic=[];strong=[]
    for side in (data.buy,data.sell):
        a={name:side[:,index[name]] for name in data.columns}
        long=side[:,[index[f'm{m}_{name}'] for m in (15,30) for name in ('ema21_delta_to_side','di_difference_to_side')]]
        votes.append(np.where(np.isfinite(long).all(axis=1),(long>0).sum(axis=1),np.nan))
        flag=(a['m5_hist_delta_to_side']>0)&(a['m5_rsi_delta_to_side']>0)&(a['q0_last_minus_m1_close_atr5_to_side']>0)&\
             (np.abs(a['m5_rsi_delta_to_side'])<=12)&(a['q0_spread_points']>0)&\
             (a['q0_spread_points']<=catalog[profile['fade']]['settings']['spread_max'])&\
             (np.abs(a['q0_last_minus_m1_close_atr5_to_side'])<=1)
        basic.append(flag);strong.append(flag&(a['m5_di_difference_to_side']>0)&(a['m1_volume_relative_prior3']>=.75))
    votes=np.stack(votes);basic=np.stack(basic);strong=np.stack(strong);directions=[];branches=[]
    for option in options:
        if option['timing']=='OFF':directions.append(mp.copy());branches.append(np.where(mp!=0,0,-1).astype(np.int8));continue
        k=option['background'];background=np.ones_like(votes,dtype=bool) if k==0 else np.isfinite(votes)&(votes>=k)
        if option['timing']=='IMMEDIATE':
            fade=np.asarray([-int(side) if side and background[0 if side==-1 else 1,event] else 0 for event,side in enumerate(original)],dtype=np.int8)
        else:
            minutes=5 if option['timing'].startswith('CONF5') else 10
            fade=confirmation(original,strong if option['timing'].endswith('STRONG') else basic,background,data.q0,minutes*60)
        direction=np.asarray([0 if x and y and x!=y else x if x else y for x,y in zip(mp,fade,strict=True)],dtype=np.int8)
        branch=np.asarray([-1 if not side else 0 if x else 1 for side,x in zip(direction,mp,strict=True)],dtype=np.int8)
        directions.append(direction);branches.append(branch)
    return np.stack(directions),np.stack(branches)


def route(options: tuple,phases: np.ndarray,pre: int,post: int) -> tuple:
    """
    機能: 全場で評価済みの式を、各q0の帯だけで選ぶ。
    引数: options(tuple[方向,枝])、phases(np.ndarray[N])、pre/post(int)は固定候補番号。
    返り値: tuple[np.ndarray,np.ndarray]は当時方向と枝。
    """
    selected=np.where(phases==0,0,np.where(phases==1,pre,post))
    return tuple(array[selected,np.arange(len(phases))].copy() for array in options)


def invariants(metrics: np.ndarray,bands: np.ndarray,fields: list) -> dict:
    """
    機能: 全5120政策の金融/分解/枠/未知の不変式を確認する。
    引数: metrics/bands(np.ndarray)、fields(list[str])は保存全配列。
    返り値: dictはセル数。
    """
    f={name:i for i,name in enumerate(fields)};v=lambda n:metrics[...,f[n]];b=lambda n:bands[...,f[n]]
    for get in (v,b):
        assert np.array_equal(get('F')+get('A')+get('N')+get('C'),get('count'))
        assert np.array_equal(get('known')+get('unknown'),get('count')) and np.array_equal(get('unknown'),get('C'))
        assert np.array_equal(get('profit')-get('loss'),get('net'))
        assert np.array_equal(get('core_count')+get('old_technical_count')+get('local_technical_count'),get('count'))
        assert np.allclose(get('rate'),qa170.divide(get('F'),get('F')+get('A')),equal_nan=True)
        assert np.allclose(get('realized_win_rate'),qa170.divide(get('wins'),get('known')),equal_nan=True)
        assert np.array_equal(np.isnan(get('all_net')),get('unknown')>0)
        valid=get('unknown')==0;assert np.array_equal(get('all_net')[valid],get('net')[valid])
    names=('count','F','A','N','C','known','unknown','profit','loss','net','wins','loss_trades','core_count','old_technical_count','local_technical_count')
    for name in names:
        assert np.array_equal(v(name)[...,0],v(name)[...,1]+v(name)[...,2])
        assert np.array_equal(b(name)[...,0,:,:],b(name)[...,1,:,:]+b(name)[...,2,:,:])
        for clock in (0,1):assert np.array_equal(b(name)[...,clock,:].sum(axis=-1),v(name))
    for prefix in ('peak_reserved','peak_held','peak_pending'):
        for side in ('buy','sell'):
            value=v(prefix+'_'+side);assert np.all((value>=0)&(value<=10))
            assert np.array_equal(value[...,0],np.maximum(value[...,1],value[...,2]))
    return {'metrics':int(metrics.size),'bands':int(bands.size),'全不変式':True}


G=None


def initialize(oracle_positions: set) -> None:
    """
    機能: 旧73の共用入力と全5120統計をworkerへ一度だけ読み込む。
    引数: oracle_positions(set[tuple])は取得も独立再生する政策。
    返り値: None。追加7入力は読まない。
    """
    global G
    data=previous.load_dataset(True);setting=read(BOOK);axes=read(OUT/'統計軸.json')
    with np.load(OUT/'三帯入口の統計配列.npz',allow_pickle=False) as source:m=source['metrics'].copy();b=source['bands'].copy()
    with np.load(AUTHOR/'全出生/三帯入口の出生.npz',allow_pickle=False) as source:born={name:source[name].copy() for name in source.files}
    G=SimpleNamespace(data=data,setting=setting,fields=axes['fields'],metrics=m,bands=b,birth=born,oracles=oracle_positions)


def evaluate(position: tuple) -> dict:
    """
    機能: 支持/層別政策を未変更168engineで取得し、金融は別式で全分解再計算する。
    引数: position(tuple[int,...])はprofile/PRE/POST/二幅。
    返り値: dictは検査数。指定層別政策では一覧oracle全要求取得も照合する。
    """
    p,pre,post,m,w=position;data=G.data;setting=G.setting;f={name:i for i,name in enumerate(G.fields)}
    born={'core':G.birth['directions'][p,pre,post],'branches':G.birth['branches'][p,pre,post],
          'technical':G.birth['technical'],'tier':G.birth['tier']}
    choice={'momentum_width':setting['momentum_widths'][m],'fade_width':setting['fade_widths'][w],'horizon':'H60','integration':'H200'}
    args=previous.oracle_data(data,born,choice);actual=engine.replay(**args,capacity=10);oracle_requests=oracle_records=0
    if position in G.oracles:
        variable={**args,'momentum_width':np.full(len(data.q0),choice['momentum_width'],dtype=np.int64),
                  'fade_width':np.full(len(data.q0),choice['fade_width'],dtype=np.int64)}
        expected=qa170.oracle(variable,10)
        assert actual['records']==expected['records'] and actual['requests']==expected['requests'],position
        for a,b in zip(actual['audits'],expected['audits'],strict=True):
            for key,value in b.items():assert a[key]==value
        oracle_requests=len(expected['requests']);oracle_records=len(expected['records'])
    records=actual['records'];rows=[(r['case'],r['side'],r['event'],r['origin']) for r in records]
    widths=np.asarray([data.meta['widths'].index(r['width']) for r in records],dtype=np.int8)
    scene=np.asarray([data.arrays['session_index'][r['case']] for r in records],dtype=np.int16)
    origin=np.asarray([r['origin'] for r in records],dtype=np.int8);tier=np.asarray([r['tier'] for r in records],dtype=np.int8)
    hi=data.meta['horizon_ids'].index('H60');cells=0
    for period,scope in enumerate((np.ones(73,dtype=bool),np.arange(73)<48,np.arange(73)>=48)):
        mask=scope[scene];value=previous.statistics(data,rows,widths,hi,mask,scope)
        value.update(core_count=int(np.sum(mask&(origin==0))),old_technical_count=int(np.sum(mask&(tier==1))),local_technical_count=int(np.sum(mask&(tier==2))))
        audits=[a for a in actual['audits'] if scope[a['scene_index']]]
        value.update(quantity_rejected_core=sum(a['quantity_rejected_core'] for a in audits),quantity_rejected_technical=sum(a['quantity_rejected_technical'] for a in audits))
        for prefix,key in (('peak_reserved','peak_reserved_total'),('peak_held','peak_held'),('peak_pending','peak_pending')):
            peak=np.max([a[key] for a in audits],axis=0);value[prefix+'_buy']=int(peak[0]);value[prefix+'_sell']=int(peak[1])
        for name,v in value.items():
            got=G.metrics[position+(period,f[name])]
            assert np.isnan(got) if v is None else math.isclose(got,v,rel_tol=1e-12,abs_tol=1e-9),(position,period,name,got,v)
            cells+=1
        for clock in (0,1):
            phases=previous.phases(data,rows,'q0' if clock==0 else 'q1')
            for band in range(3):
                eligible=scope&(data.hours[:,band]>0);mask2=mask&(phases==band)
                value=previous.statistics(data,rows,widths,hi,mask2,eligible,float(data.hours[eligible,band].sum()))
                value.update(core_count=int(np.sum(mask2&(origin==0))),old_technical_count=int(np.sum(mask2&(tier==1))),local_technical_count=int(np.sum(mask2&(tier==2))))
                for name,v in value.items():
                    got=G.bands[position+(period,clock,band,f[name])]
                    assert np.isnan(got) if v is None else math.isclose(got,v,rel_tol=1e-12,abs_tol=1e-9),(position,period,clock,band,name,got,v)
                    cells+=1
    return {'position':list(position),'financial_cells':cells,'records':len(records),'oracle_requests':oracle_requests,'oracle_records':oracle_records}


def main() -> None:
    """
    機能: 純route全出生、全5120不変式、全支持1392金融と層別oracle、固定主案二期間を検査する。
    引数: なし。探索や閾値変更、CSV変更は行わない。
    返り値: None。独立検査票・位置・停止を保存する。
    """
    sys.stdout.reconfigure(encoding='utf-8');begin=time.monotonic();assert sha(BOOK)==BOOK_SHA
    paths=[Path(__file__),PREVIOUS,QA170,BOOK,ENGINE_PATH,AUTHOR/'route171.py',AUTHOR/'出生を固定する.py',AUTHOR/'探索する.py',
           AUTHOR/'全出生/三帯入口の出生.npz',AUTHOR/'全出生/出生の確認.json',OUT/'三帯入口の統計配列.npz',OUT/'統計軸.json',
           OUT/'主案と前半A-Bの封印.json',OUT/'全期発見の上位.json',AUTHOR/'追加7固定候補の出生.npz',
           AUTHOR/'固定主案を二期間に適用する.py',AUTHOR/'固定候補を再生する.py',AUTHOR/'固定候補二期間の完了.json']
    for folder in ('旧73固定候補','追加7固定候補'):
        paths.extend(AUTHOR/folder/name for name in ('固定候補の数量比較.json','全取得参照.json','数量と要求の監査.json.gz'))
    before={p.relative_to(ROOT).as_posix():sha(p) for p in paths};setting=read(BOOK);axes=read(paths[11]);seal=read(paths[12]);found=read(paths[13])
    assert sha(ENGINE_PATH)=='a2f728bf7e7c925495d01670f1bbf89d88aaea6b8e207490e080d6c2d9f21050'
    data=previous.load_dataset(True);library=module(ROOT/'work/162複合入口候補/rules162.py','catalog_for171');catalog={r['id']:r for r in library.candidate_catalog()}
    target=module(AUTHOR/'route171.py','pure_route171_target')
    features=SimpleNamespace(buy_X=data.buy,sell_X=data.sell,columns=data.columns,q0_meta=data.q0,
                             q0_timeband=np.asarray([previous.io.band(q['session'],q['q0_time']) for q in data.q0],dtype=np.int8),scenes=data.scenes)
    with np.load(paths[8],allow_pickle=False) as source:born={name:source[name].copy() for name in source.files}
    pure_cells=0;option_cache={}
    parent165=read(ROOT/'work/165順行と回復失敗の複合/全出生/全出生の確認.json');lookup165={r['id']:i for i,r in enumerate(parent165['profiles'])}
    with np.load(ROOT/'work/165順行と回復失敗の複合/全出生/複合と技術補完.npz',allow_pickle=False) as old:
        for p,name in enumerate(setting['core_profiles']):
            mp,ex,_,_=name.split('_',3);profile={'momentum':mp,'fade':ex};options=option_births(data,profile,setting['pre_options'],catalog);option_cache[p]=options
            actual=target.option_births(features,profile,setting['pre_options'])
            assert np.array_equal(actual['directions'],options[0]) and np.array_equal(actual['branches'],options[1])
            for oi,option in enumerate(setting['pre_options']):
                if option['timing']=='OFF':continue
                key=f"{mp}_{ex}_B{option['background']}_{option['timing']}";row=lookup165[key]
                assert np.array_equal(options[0][oi],old['directions'][row]) and np.array_equal(options[1][oi],old['branches'][row])
            for pre,post in product(range(8),range(8)):
                expected=route(options,features.q0_timeband,pre,post)
                assert np.array_equal(expected[0],born['directions'][p,pre,post]) and np.array_equal(expected[1],born['branches'][p,pre,post])
                pure_cells+=expected[0].size*2
    # CONFのarmが帯をまたぐ例と両方向消費・prefixを自然とは別の人工で確認する。
    q=[{'session_index':0,'q0_time':t} for t in (0,60,120,180,240)]
    original=np.array([1,1,0,0,0]);confirm=np.zeros((2,5),dtype=bool);confirm[1,3]=True;background=np.ones((2,5),dtype=bool)
    fade=confirmation(original,confirm,background,q,300);assert fade.tolist()==[0,0,0,-1,0]
    d=np.ones(5,dtype=np.int8);b=np.zeros(5,dtype=np.int8);off=np.zeros(5,dtype=np.int8);wait=np.full(5,-1,dtype=np.int8)
    current=target.route(d,b,off,wait,fade,np.where(fade!=0,1,-1).astype(np.int8),np.array([1,1,1,2,2]))
    assert current[0].tolist()==[0,0,0,-1,0]
    artificial_rows=0
    for p in (0,1):
        profile={'momentum':setting['core_profiles'][p].split('_')[0],'fade':setting['core_profiles'][p].split('_')[1]}
        n=360;small=SimpleNamespace(**{**vars(data),'buy':data.buy[:n].copy(),'sell':data.sell[:n].copy(),'q0':data.q0[:n]})
        options=option_births(small,profile,setting['pre_options'],catalog)
        mirror=SimpleNamespace(**{**vars(small),'buy':small.sell,'sell':small.buy})
        reflected=option_births(mirror,profile,setting['pre_options'],catalog)
        assert np.array_equal(options[0],-reflected[0]) and np.array_equal(options[1],reflected[1])
        for cut in (0,1,179,359):
            poisoned=SimpleNamespace(**{**vars(small),'buy':small.buy.copy(),'sell':small.sell.copy()})
            poisoned.buy[cut:]=np.nan;poisoned.sell[cut:]=np.nan
            changed=option_births(poisoned,profile,setting['pre_options'],catalog)
            assert np.array_equal(changed[0][:,:cut],options[0][:,:cut]) and np.array_equal(changed[1][:,:cut],options[1][:,:cut])
            artificial_rows+=cut
    with np.load(paths[10],allow_pickle=False) as source:metrics=source['metrics'].copy();bands=source['bands'].copy()
    invariant=invariants(metrics,bands,axes['fields']);f={name:i for i,name in enumerate(axes['fields'])};flat=metrics.reshape(5120,3,len(f));full=flat[:,0];front=flat[:,1];back=flat[:,2];s=setting['discovery_support']
    supported=(full[:,f['count']]>=200)&(full[:,f['F']]+full[:,f['A']]>=100)&(full[:,f['all_scenes']]==1)&(full[:,f['rate']]>=.7)&\
              (front[:,f['F']]+front[:,f['A']]>=30)&(back[:,f['F']]+back[:,f['A']]>=30)&\
              (front[:,f['rate']]>=.65)&(back[:,f['rate']]>=.65)&(full[:,f['unknown']]<=.1*full[:,f['count']])&\
              (front[:,f['net']]>0)&(back[:,f['net']]>0)
    assert supported.sum()==found['支持合格']==1392
    shape=metrics.shape[:-2];support_positions={tuple(map(int,np.unravel_index(i,shape))) for i in np.flatnonzero(supported)}
    oracle_positions={tuple(seal['事前固定主案']['position'])}|{tuple(r['position']) for r in found['上位']}
    for p,pre,post in product(range(4),range(8),range(8)):oracle_positions.add((p,pre,post,(p+pre+post)%5,(p+2*pre+post)%4))
    positions=support_positions|oracle_positions
    pf=qa170.divide(front[:,f['profit']],front[:,f['loss']]);pf=np.where((front[:,f['loss']]==0)&(front[:,f['profit']]>0),np.inf,pf)
    base=(front[:,f['count']]>=250)&(front[:,f['F']]+front[:,f['A']]>=100)&(front[:,f['rate']]>=.7)&\
         (front[:,f['per_hour']]>=.75)&(front[:,f['scenes']]==48)&(front[:,f['all_scenes']]==1)&\
         (front[:,f['unknown']]<=.1*front[:,f['count']])&(pf>=1.2)&(front[:,f['net']]>0)
    assert not base.any() and seal['選択']=={'A':None,'B':None}
    results=[]
    with ProcessPoolExecutor(max_workers=3,initializer=initialize,initargs=(oracle_positions,)) as pool:
        for index,result in enumerate(pool.map(evaluate,sorted(positions),chunksize=8),1):
            results.append(result)
            if index%160==0:print(__import__('json').dumps({'金融検算':index,'全対象':len(positions),'秒':round(time.monotonic()-begin)},ensure_ascii=False),flush=True)
    # ----------------------------------------
    # 固定主案の両期間は全要求と全場/三帯/枝/売買を独立照合する。
    fixed=[];fixed_cells=0;fixed_requests=0;fixed_records=0;new_seal_cells=0
    primary=seal['事前固定主案']['candidate']
    for old,folder in ((True,'旧73固定候補'),(False,'追加7固定候補')):
        current=data if old else previous.load_dataset(False);mp=primary['profile']['momentum'];ex=primary['profile']['fade']
        options=option_births(current,{'momentum':mp,'fade':ex},setting['pre_options'],catalog)
        phase=np.asarray([previous.io.band(q['session'],q['q0_time']) for q in current.q0],dtype=np.int8)
        lookup={r['id']:i for i,r in enumerate(setting['pre_options'])};core,branch=route(options,phase,lookup[primary['pre']],lookup[primary['post']])
        base_born=previous.births(current,primary,catalog);base_born['core']=core;base_born['branches']=branch
        if not old:
            with np.load(paths[14],allow_pickle=False) as sealed:
                for name,value in base_born.items():assert np.array_equal(sealed[primary['id']+'__'+name],value);new_seal_cells+=value.size
        args=previous.oracle_data(current,base_born,primary)
        var={**args,'momentum_width':np.full(len(current.q0),primary['momentum_width'],dtype=np.int64),
                     'fade_width':np.full(len(current.q0),primary['fade_width'],dtype=np.int64)}
        expected=qa170.oracle(var,10);fixed_requests+=len(expected['requests']);fixed_records+=len(expected['records'])
        reports=read(AUTHOR/folder/'固定候補の数量比較.json')['rows'];ref=read(AUTHOR/folder/'全取得参照.json')['rows'][0];audit=read(AUTHOR/folder/'数量と要求の監査.json.gz')['rows'][0]
        assert len(reports)==1 and audit['requests']==expected['requests']
        rows=[(r['case'],r['side'],r['event'],r['origin']) for r in expected['records']]
        widths=np.asarray([current.meta['widths'].index(r['width']) for r in expected['records']],dtype=np.int8);tiers=[r['tier'] for r in expected['records']]
        previous.reference_match(current,rows,widths,tiers,ref)
        actual=reports[0]['cap10'];fixed_cells+=previous.audit_financial_parts(current,rows,widths,tiers,base_born,primary,
            actual['periods']['全期'],actual['scenes'],actual['timebands'],actual['branches'],actual['sides'],'168')
        for a,b in zip(audit['audits'],expected['audits'],strict=True):
            for key,value in b.items():assert a[key]==value
        if old:
            for name,report in actual['periods'].items():
                for field in ('count','F','A','N','C','profit','loss','net','known','unknown','rate'):
                    assert report[field]==seal['事前固定主案']['periods'][name][field]
        fixed.append({'期間':'旧73' if old else '追加7','metrics':actual['periods']['全期']})
    assert all(sha(ROOT/path)==h for path,h in before.items())
    save(HERE/'171の独立確認.json',{'成功':True,'trial':171,'Sourceと入力':before,'純全方向枝照合セル':pure_cells,
         '元165八式の純再計算同体':True,'CONF全場履歴と帯跨ぎ':True,'mirrorと未来毒の接頭行':artificial_rows,
         '全5120不変式':invariant,'全期支持数':1392,'支持全金融検算':True,'金融検算政策数':len(results),
         '金融再計算セル':sum(r['financial_cells'] for r in results),'独立一覧oracle政策数':len(oracle_positions),
         '独立一覧全要求':sum(r['oracle_requests'] for r in results),'独立一覧全取得':sum(r['oracle_records'] for r in results),
         '前48A適格数':int(base.sum()),'A_B_null同体':True,'固定二期間全統計セル':fixed_cells,
         '固定二期間全要求':fixed_requests,'固定二期間全取得':fixed_records,'追加金融前出生照合セル':new_seal_cells,
         '固定二期間':fixed,'追加7は既使用基準':True,'CSV_JSON変更':False,'元Source結果変更':False,
         '限界':'全5120は不変式。支持全件等の金融は未変更168engineの取得を元NPZから別集計。独立一覧oracleの全要求再生は主案/上位/層別に限定。第二Raw parser全面再走査や実mini約定保証ではない。',
         '経過秒':time.monotonic()-begin})
    save(HERE/'金融検算の政策位置.json',{'成功':True,'rows':results})
    save(HERE/'独立確認の停止.json',{'成功':True,'SourceSHA256':sha(Path(__file__)),
         '検査票SHA256':sha(HERE/'171の独立確認.json'),'位置票SHA256':sha(HERE/'金融検算の政策位置.json'),'元入力不変':True})
    print(__import__('json').dumps({'成功':True,'金融政策':len(results),'独立oracle政策':len(oracle_positions),
         '検査票SHA256':sha(HERE/'171の独立確認.json')},ensure_ascii=False))


if __name__=='__main__':
    main()
