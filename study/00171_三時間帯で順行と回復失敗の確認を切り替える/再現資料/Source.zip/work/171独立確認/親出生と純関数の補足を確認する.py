"""171のOFFと補完の親全q0同体、実純関数の鏡像/未来prefixを補足確認する。"""
from pathlib import Path
from types import SimpleNamespace
import importlib.util
import sys

import numpy as np

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('qa171_supplement',HERE/'純routeと自然を検査する.py')
qa=importlib.util.module_from_spec(spec);sys.modules[spec.name]=qa;spec.loader.exec_module(qa)


def main() -> None:
    """
    機能: 純OFFの元163・固定補完の元166同体と、作者純関数への鏡像/未来毒を検査する。
    引数: なし。新探索・閾値変更・CSV変更を行わない。
    返り値: None。前の自然QAを変更せず補足票を追加する。
    """
    sys.stdout.reconfigure(encoding='utf-8');data=qa.previous.load_dataset(True);setting=qa.read(qa.BOOK)
    library=qa.module(ROOT/'work/162複合入口候補/rules162.py','catalog171_supplement');catalog={r['id']:r for r in library.candidate_catalog()}
    target=qa.module(qa.AUTHOR/'route171.py','pure171_supplement');proof163=qa.read(ROOT/'work/163入口と任意幅/全出生/全出生の確認.json')
    paths=[Path(__file__),HERE/'純routeと自然を検査する.py',qa.AUTHOR/'route171.py',qa.AUTHOR/'全出生/三帯入口の出生.npz',
           ROOT/'work/163入口と任意幅/全出生/出生200.npz',ROOT/'work/163入口と任意幅/全出生/全出生の確認.json',
           ROOT/'work/166可用指標の階層化/全出生/階層化の出生.npz']
    before={p.relative_to(ROOT).as_posix():qa.sha(p) for p in paths}
    with np.load(paths[4],allow_pickle=False) as old163,np.load(paths[3],allow_pickle=False) as born,np.load(paths[6],allow_pickle=False) as old166:
        all163=old163['ALL'];compared=0
        for name in ('MP0057','MP0058'):
            independent=qa.previous.rule_direction(data,catalog[name]);row=proof163['規則順'].index(name)
            assert np.array_equal(independent,all163[row]);compared+=len(independent)
        choice=qa.read(qa.OUT/'主案と前半A-Bの封印.json')['事前固定主案']['candidate']
        pure=SimpleNamespace(buy=data.buy,sell=data.sell,columns=data.columns,q0=data.q0,scenes=data.scenes)
        fallback=qa.previous.births(pure,choice,catalog)
        assert np.array_equal(born['technical'],old166['technical'][2,1]) and np.array_equal(born['tier'],old166['technical_tier'][2,1])
        assert np.array_equal(born['technical'],fallback['technical']) and np.array_equal(born['tier'],fallback['tier'])
    mirror_rows=0;prefix_rows=0;nonzero=0
    for mp,ex in (('MP0057','EX0075'),('MP0058','EX0076')):
        direction=qa.previous.rule_direction(data,catalog[mp]);start=max(0,int(np.flatnonzero(direction)[0])-20);end=start+360
        features=SimpleNamespace(buy_X=data.buy[start:end].copy(),sell_X=data.sell[start:end].copy(),columns=data.columns,q0_meta=data.q0[start:end])
        profile={'momentum':mp,'fade':ex};actual=target.option_births(features,profile,setting['pre_options'])
        reflected=SimpleNamespace(**{**vars(features),'buy_X':features.sell_X,'sell_X':features.buy_X})
        mirror=target.option_births(reflected,profile,setting['pre_options'])
        assert np.array_equal(actual['directions'],-mirror['directions']) and np.array_equal(actual['branches'],mirror['branches'])
        nonzero+=int(np.count_nonzero(actual['directions']));mirror_rows+=len(features.q0_meta)
        for cut in (0,1,179,359):
            changed=SimpleNamespace(**{**vars(features),'buy_X':features.buy_X.copy(),'sell_X':features.sell_X.copy()})
            changed.buy_X[cut:]=np.nan;changed.sell_X[cut:]=np.nan;future=target.option_births(changed,profile,setting['pre_options'])
            assert np.array_equal(actual['directions'][:,:cut],future['directions'][:,:cut])
            assert np.array_equal(actual['branches'][:,:cut],future['branches'][:,:cut]);prefix_rows+=cut
    assert nonzero>0 and all(qa.sha(ROOT/p)==h for p,h in before.items())
    qa.save(HERE/'親出生と純関数の補足確認.json',{'成功':True,'Sourceと入力':before,'元163_OFF用MP全q0セル':compared,
        '元166と独立式の全補完方向tier同体':True,'全補完方向tierセル':len(data.q0)*2,
        '作者純optionの鏡像行':mirror_rows,'作者純optionの未来prefix行':prefix_rows,'対象窓の非0出生':nonzero,
        '元の自然QA_Source_結果不変':True,'CSV変更':False})
    print(__import__('json').dumps({'成功':True,'検査票SHA256':qa.sha(HERE/'親出生と純関数の補足確認.json')},ensure_ascii=False))


if __name__=='__main__':
    main()
