"""170の当時幅選択・配列engineを独立のceil/list実装と旧168で確認する。"""
from pathlib import Path
import ast
import copy
import importlib.util
import math
import sys
import time

import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
AUTHOR=ROOT/'work/170ATRと三時間帯'
BOOK=ROOT/'study/00170_ATRと三時間帯の幅で複合入口を数量枠に適合させる/条件.json'
BOOK_SHA='c7c0ebeaebc51a24b256c74ad0dfe1aeaa1d7ff8d4ee019d25d5d92f064a0f1b'


def module(path: Path,name: str) -> object:
    """
    機能: mainを呼ばず純関数だけを読み込む。
    引数: path(Path)、name(str)はSourceと識別名。
    返り値: objectはmodule。
    """
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec)
    sys.modules[name]=value;spec.loader.exec_module(value);return value


IO_PATH=ROOT/'work/165自然独立確認/自然値を独立検算する.py'
io=module(IO_PATH,'independent_io170');read=io.read;save=io.save;sha=io.sha
width=module(AUTHOR/'width170.py','width170_target');engine=module(AUTHOR/'engine170.py','engine170_target')
oldengine=module(ROOT/'work/168数量枠の因果再生/engine168.py','engine168_control170')
oldqa=module(ROOT/'work/168数量枠の独立確認/独立人工を確認する.py','independent168_fixture170')


def width_oracle(values: np.ndarray,phases: np.ndarray,mm: float,fm: float,scale: dict,grid: list) -> dict:
    """
    機能: searchsortedを使わず、整数gridを順に照合して当時幅を選ぶ。
    引数: values/phases(np.ndarray)、mm/fm(float)、scale(dict)、grid(list[int])。
    返り値: dictはvalid・二枝幅。
    """
    valid=np.asarray([math.isfinite(float(a)) and a>0 for a in values],dtype=bool)
    result={'valid':valid}
    for key,multiplier in (('momentum_widths',mm),('fade_widths',fm)):
        chosen=[]
        for atr,phase,known in zip(values,phases,valid,strict=True):
            if not known:chosen.append(0);continue
            target=float(atr)*float(multiplier)*float(scale[('DAY','PRE','POST')[int(phase)]])
            chosen.append(next((int(w) for w in grid if w>=target),int(grid[-1])))
        result[key]=np.asarray(chosen,dtype=np.int64)
    return result


def variable_oracle(data: dict,capacity: int|None) -> dict:
    """
    機能: heapを使わず、全時計イベントの一覧から配列幅の予約・取得・決済を再生する。
    引数: data(dict)は人工時計・固定方向・当時幅、capacity(int|None)は片側上限。
    返り値: dictはrecords/requests/peaks。net・label・将来の利益額を入力に持たない。
    """
    records=[];requests=[];peaks=[];serial=0
    for scene,end in enumerate(data['scene_ends']):
        held=[0,0];pending=[0,0];calendar=[];waiting={};seen=set();ever=False;peak=[0,0]
        for event in np.flatnonzero(data['event_scenes']==scene).tolist()+[None]:
            now=(float(end),math.inf,math.inf) if event is None else tuple(data['event_keys'][event])
            while calendar:
                ni=min(range(len(calendar)),key=lambda i:calendar[i][:2]);key,order,kind,row=calendar[ni]
                if key>now:break
                calendar.pop(ni);side=row['side']
                if kind=='release':held[side]-=1;continue
                pending[side]-=1;waiting.pop(order)
                if kind=='cancel':continue
                if row['case'] in seen:continue
                seen.add(row['case']);held[side]+=1;ever=True
                records.append({k:row[k] for k in ('event','case','side','width','origin','tier')})
                exit_time=data['exit_lookup'](row['case'],side,row['width']);release=end if exit_time is None else exit_time
                serial+=1;calendar.append(((float(release),math.inf,math.inf),serial,'release',row))
            if event is None:break
            original=int(data['core'][event]);tech=int(data['technical'][event])
            chosen=int(data['momentum_width'][event] if data['branches'][event]==0 else data['fade_width'][event])
            core=original if chosen>0 else 0
            if core:side=0 if core>0 else 1;origin=0;tier=0;selected_width=chosen
            else:
                if now[0]<data['scene_starts'][scene]+data['after_seconds'] or ever or not tech:continue
                if waiting:continue
                side=0 if tech>0 else 1;origin=2;tier=int(data['tiers'][event]);selected_width=data['technical_width']
            request={'event':event,'scene_index':scene,'side':side,'width':selected_width,'origin':origin,'tier':tier,
                     'at':list(now),'held_before':held[side],'pending_before':pending[side],
                     'accepted':capacity is None or held[side]+pending[side]<capacity}
            requests.append(request)
            if not request['accepted']:continue
            capture=data['captures'][event];kind='fill' if capture['status']=='filled' else 'cancel'
            key=tuple(capture['fill_key'] if kind=='fill' else capture['finish_key'])
            row={**request,'case':capture['case'] if kind=='fill' else -1}
            pending[side]+=1;serial+=1;calendar.append((key,serial,kind,row));waiting[serial]=row
            peak=[max(peak[s],held[s]+pending[s]) for s in (0,1)]
        assert held==[0,0];peaks.append(peak)
    records.sort(key=lambda row:(row['event'],row['origin']))
    return {'records':records,'requests':requests,'peaks':peaks}


def compare(data: dict,capacity: int|None) -> dict:
    """
    機能: 配列engineと独立一覧oracleの全要求・取得・予約ピークを比較する。
    引数: data(dict)、capacity(int|None)は人工入力と枠。
    返り値: dictは作者engineの結果。
    """
    actual=engine.replay(**data,capacity=capacity);expected=variable_oracle(data,capacity)
    assert actual['records']==expected['records'] and actual['requests']==expected['requests']
    assert [a['peak_reserved_total'] for a in actual['audits']]==expected['peaks']
    return actual


def main() -> None:
    """
    機能: 純幅・可変幅枠・定数同体・当時帯・金融未入力封印を独立確認する。
    引数: なし。170旧73の金融探索結果と追加7の成績は読まない。
    返り値: None。独立人工/幅封印確認と停止票を保存する。
    """
    sys.stdout.reconfigure(encoding='utf-8');begin=time.monotonic();assert sha(BOOK)==BOOK_SHA
    cache=ROOT/'work/151過去場判別の評価/入口選択/cache/feature_only'
    paths=[Path(__file__),IO_PATH,BOOK,AUTHOR/'width170.py',AUTHOR/'engine170.py',AUTHOR/'幅を固定する.py',
           AUTHOR/'幅の人工検査.py',AUTHOR/'幅の人工確認.json',AUTHOR/'168からの幅差分.diff',AUTHOR/'探索する.py',
           ROOT/'work/168数量枠の因果再生/engine168.py',ROOT/'work/168数量枠の独立確認/独立人工を確認する.py',
           ROOT/'work/169数量枠と技術近傍/selector169.py',AUTHOR/'全幅/当時ATRの幅.npz',AUTHOR/'全幅/幅の確認.json',
           ROOT/'study/00170_ATRと三時間帯の幅で複合入口を数量枠に適合させる/検査/F0_ATR幅固定前.json',
           cache/'features.npz',cache/'features_meta.json']
    before={p.relative_to(ROOT).as_posix():sha(p) for p in paths};setting=read(BOOK)
    grid=setting['width_grid'];phase_scale=setting['timeband_scales'][1]
    rng=np.random.default_rng(20261115170);raw=np.r_[0.,-1.,np.nan,np.inf,-np.inf,1e308,
            np.nextafter(np.asarray(grid)/3,0),np.asarray(grid)/3,np.nextafter(np.asarray(grid)/3,np.inf),rng.uniform(.001,900,4000)]
    phases=rng.integers(0,3,len(raw));width_cells=0
    for scale in setting['timeband_scales']:
        for mm in setting['momentum_atr_multipliers']:
            for fm in setting['fade_atr_multipliers']:
                actual=width.choose_widths(raw,phases,mm,fm,scale,grid);expected=width_oracle(raw,phases,mm,fm,scale,grid)
                for key in actual:assert np.array_equal(actual[key],expected[key]);width_cells+=actual[key].size
    for cut in (0,1,17,1000,len(raw)):
        clean=width.choose_widths(raw,phases,3,6,phase_scale,grid);changed=raw.copy();changed[cut:]=0
        altered=phases.copy();altered[cut:]=2;other=width.choose_widths(changed,altered,3,6,phase_scale,grid)
        for key in clean:assert np.array_equal(clean[key][:cut],other[key][:cut])
    rejected=0
    for invalid_grid in ([],[0,150],[150,150],[200,150],[150.5,200],[150,np.inf]):
        try:width.choose_widths(np.array([100.]),np.array([0]),3,6,phase_scale,invalid_grid)
        except AssertionError:rejected+=1
        else:raise AssertionError(invalid_grid)
    # ----------------------------------------
    # 168の定数版と全結果を比較。可変版は別の一覧oracleへ比較する。
    constant_rows=0;variable_rows=0;prefix_rows=0;mirror_rows=0
    for sample in range(240):
        n=60;times=(2700+np.arange(n)*2).tolist();core=rng.choice((-1,0,1),n).tolist();tech=rng.choice((-1,0,1),n).tolist()
        data=oldqa.fixture(times,core,tech);exits={}
        for first in range(0,n,2):
            at=float(times[first+1]+rng.integers(1,20));key=(at,first*10+7,first*10+7);cancel=rng.random()<.2
            for event in (first,first+1):
                data['captures'][event]=({'status':'cancelled','finish_key':key} if cancel else
                    {'status':'filled','case':first,'fill_key':key,'finish_key':key})
            exits[first]=None if rng.random()<.15 else at+float(rng.integers(0,40))
        data['exit_lookup']=lambda case,side,w:exits[case] if exits[case] is None else exits[case]+w/1000
        capacity=(None,1,2,10)[sample%4]
        expected=oldengine.replay(**data,capacity=capacity)
        fixed={**data,'momentum_width':np.full(n,200,dtype=np.int64),'fade_width':np.full(n,400,dtype=np.int64)}
        actual=engine.replay(**fixed,capacity=capacity);assert actual==expected;constant_rows+=n
        varying={**data,'momentum_width':rng.choice([0,*grid],n),'fade_width':rng.choice([0,*grid],n)}
        actual=compare(varying,capacity);variable_rows+=n
        reflected={**varying,'core':-varying['core'],'technical':-varying['technical']}
        other=compare(reflected,capacity)
        assert len(actual['records'])==len(other['records'])
        for a,b in zip(actual['records'],other['records'],strict=True):
            assert all(a[k]==b[k] for k in a if k!='side') and a['side']==1-b['side']
        assert [a['peak_reserved_total'][::-1] for a in actual['audits']]==[a['peak_reserved_total'] for a in other['audits']];mirror_rows+=n
        cut=sample%n;mutated={**varying,'momentum_width':varying['momentum_width'].copy(),'fade_width':varying['fade_width'].copy()}
        mutated['momentum_width'][cut:]=0;mutated['fade_width'][cut:]=1000
        future=compare(mutated,capacity)
        assert [r for r in actual['requests'] if r['event']<cut]==[r for r in future['requests'] if r['event']<cut]
        prefix_rows+=cut
    # ----------------------------------------
    # 要求時の幅を取得後の更新で変更せず、未知exitは枠を保持する。
    frozen=oldqa.fixture([2700,2701,2705],[1,0,1],[0,0,0]);seen=[]
    frozen['momentum_width']=np.array([150,1000,1000]);frozen['fade_width']=np.array([400,1000,1000])
    def frozen_exit(case: int,side: int,w: int) -> float|None:
        """
        機能: 幅の受け渡しを記録し、取得後に過去の元配列を変更する人工lookup。
        引数: case/side/w(int)は既に取得した建玉。
        返り値: Noneは未知であり、場末まで保持する。
        """
        seen.append((case,side,w));frozen['momentum_width'][0]=1000;return None
    frozen['exit_lookup']=frozen_exit
    fixed_result=engine.replay(**frozen,capacity=1)
    assert seen==[(0,0,150)] and fixed_result['records'][0]['width']==150
    assert fixed_result['requests'][-1]['accepted'] is False and fixed_result['audits'][0]['unknown_held_to_end']==1
    same=oldqa.fixture([0,1,6,7],[1,1,1,1]);same['captures'][0]['fill_key']=(2.,8,8)
    same['momentum_width']=np.full(4,200);same['fade_width']=np.full(4,400)
    same['exit_lookup']=lambda case,side,w:6. if case==0 else 9000.
    assert [r['event'] for r in compare(same,1)['records']]==[0,3]
    unknown=oldqa.fixture([2700],[1],[1]);unknown['momentum_width']=np.array([0]);unknown['fade_width']=np.array([0])
    assert compare(unknown,1)['records'][0]['origin']==2
    # ----------------------------------------
    # Source変更が幅入力部分だけであり、nested制御と前48/q0選択の時計を維持する。
    old_tree=ast.parse(paths[10].read_text(encoding='utf-8'));new_tree=ast.parse(paths[4].read_text(encoding='utf-8'))
    for name in ('advance','request','observe'):
        a=next(n for n in ast.walk(old_tree) if isinstance(n,ast.FunctionDef) and n.name==name)
        b=next(n for n in ast.walk(new_tree) if isinstance(n,ast.FunctionDef) and n.name==name)
        assert ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False),name
    runner=ast.parse(paths[9].read_text(encoding='utf-8'))
    call=next(n for n in ast.walk(runner) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='select_front48')
    assert ast.unparse(call.args[0])=='flat[:, 1, :]'
    assert ast.unparse(call.args[1])=='flat_bands[:, 1, 0, :, :]'
    # ----------------------------------------
    # 金融を読まず、既存特徴のATRと当時q0帯だけで全封印幅を再計算する。
    proof=read(paths[14]);f0=read(paths[15]);assert proof['金融未入力'] and f0['金融未入力']
    assert proof['条件SHA256']==BOOK_SHA and proof['files'][paths[13].name]['sha256']==sha(paths[13])
    for path,digest in proof['Source'].items():assert sha(ROOT/path)==digest
    metadata=read(cache/'features_meta.json');q0=metadata['q0_meta']
    with np.load(cache/'features.npz',allow_pickle=False) as source:
        columns=source['columns'].tolist();ci=columns.index('m5_atr');atr=source['buy_X'][:,ci].copy()
        assert np.array_equal(atr,source['sell_X'][:,ci],equal_nan=True)
    phase=np.asarray([io.band(row['session'],row['q0_time']) for row in q0],dtype=np.int8)
    seal_cells=0
    with np.load(paths[13],allow_pickle=False) as sealed:
        assert np.array_equal(sealed['phases'],phase)
        valid=np.isfinite(atr)&(atr>0);assert np.array_equal(valid,sealed['valid'])
        for si,scale in enumerate(setting['timeband_scales']):
            for mi,multiplier in enumerate(setting['momentum_atr_multipliers']):
                expected=width_oracle(atr,phase,multiplier,setting['fade_atr_multipliers'][0],scale,grid)
                assert np.array_equal(sealed['momentum'][si,mi],expected['momentum_widths']);seal_cells+=len(atr)
            for fi,multiplier in enumerate(setting['fade_atr_multipliers']):
                expected=width_oracle(atr,phase,setting['momentum_atr_multipliers'][0],multiplier,scale,grid)
                assert np.array_equal(sealed['fade'][si,fi],expected['fade_widths']);seal_cells+=len(atr)
    # 夏冬のNY開始と同時刻の帯分類を実際のq0尺度で確認する。
    summer=io.ny_open('2026-10-30_Night');winter=io.ny_open('2026-11-02_Night')
    assert __import__('datetime').datetime.fromtimestamp(summer,__import__('datetime').timezone.utc).hour==13
    assert __import__('datetime').datetime.fromtimestamp(winter,__import__('datetime').timezone.utc).hour==14
    for session,at in (('2026-10-30_Night',summer),('2026-11-02_Night',winter)):
        assert [io.band(session,at+x) for x in (-1,0,1)]==[1,2,2]
    assert all(sha(ROOT/path)==digest for path,digest in before.items())
    save(HERE/'純幅とengineの独立確認.json',{'成功':True,'trial':170,'条件SHA256':BOOK_SHA,'Sourceと入力':before,
         '独立ceil幅照合セル':width_cells,'非法grid拒否数':rejected,'168定数配列全結果同体行数':constant_rows,
         '独立一覧oracle可変幅行数':variable_rows,'買売反射行数':mirror_rows,'未来幅prefix照合行数':prefix_rows,
         '可変幅の要求後固定':True,'未知exitは場末保持':True,'同秒exitは秒末解放':True,'ATR未知時の固定T補完':True,
         '168とnested制御AST同体':True,'selector169は前48とq0帯だけ':True,
         '旧73封印幅の全照合セル':seal_cells,'全q0':len(q0),'当時帯とvalid全同体':True,'phase_DSTと等号':True,
         '幅再計算の金融入力':False,'新7成績読取':False,'170旧73金融探索結果読取':False,'CSV_JSON変更':False,
         '限界':'当時幅全配列と純engine/Sourceの確認。170の自然4096政策の取得・損益・選択の検算は別途。',
         '経過秒':time.monotonic()-begin})
    save(HERE/'純幅確認の停止.json',{'成功':True,'SourceSHA256':sha(Path(__file__)),
         '検査票SHA256':sha(HERE/'純幅とengineの独立確認.json'),'元Source不変':True})
    print(__import__('json').dumps({'成功':True,'封印幅セル':seal_cells,'独立可変engine行':variable_rows,
          '検査票SHA256':sha(HERE/'純幅とengineの独立確認.json')},ensure_ascii=False))


if __name__=='__main__':
    main()
