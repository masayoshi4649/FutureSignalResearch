"""正式共有入力と171正本から全期探索又は固定候補二期間を隔離再現する。"""
from pathlib import Path
from io import BytesIO
import argparse
import importlib.util
import importlib
import json
import sys
import zipfile
import numpy as np

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
TRIAL=ROOT/'study/00171_三時間帯で順行と回復失敗の確認を切り替える'
ENGINE=ROOT/'work/171三帯の入口切替'


class SerialExecutor:
    """正式特徴の実行時接続を維持し、取引式を変えずCPU実行だけを直列化する。"""
    def __init__(self,max_workers: int,initializer: object) -> None:
        """
        機能: 同じprocessで共有入力初期化関数を準備する。
        引数: max_workers(int)は互換引数、initializer(callable)は元の初期化。
        返り値: None。
        """
        self.initializer=initializer

    def __enter__(self) -> object:
        """
        機能: 元初期化を同じprocessで実行する。
        引数: self(SerialExecutor)。
        返り値: selfは直列executor。
        """
        self.initializer();return self

    def __exit__(self,*args: object) -> None:
        """
        機能: context managerを終了する。
        引数: args(tuple)は例外情報。
        返り値: None。例外を抑制しない。
        """
        return None

    def map(self,function: object,positions: object,chunksize: int) -> object:
        """
        機能: 元の政策順のまま計算を反復する。
        引数: function(callable)、positions(iterable)、chunksize(int)は互換引数。
        返り値: objectはmap iterator。
        """
        return map(function,positions)


def load(path: Path,name: str) -> object:
    """
    機能: mainを呼ばず指定Sourceを登録名で読み込む。
    引数: path(Path)、name(str)。
    返り値: objectはmodule。
    """
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec)
    sys.modules[name]=value;spec.loader.exec_module(value);return value


# ----------------------------------------
def main() -> None:
    """
    機能: 元Sourceと正式試行を変更せず、正式148特徴/共有163金融/共有167新期から再現する。
    引数: CLI --mode(str)はscreen又はfixed。正式特徴の注入を保つため再探索は直列化する。
    返り値: None。配列又は固定二期間の意味値同体を確認しworkへ保存する。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--mode',choices=('screen','fixed'),required=True)
    args=parser.parse_args()
    helper=load(ROOT/'work/163_164正式保存/正式入力から再現する.py','正式再現共通171')
    assert helper.sha(TRIAL/'条件.json')=='c310ea07df25078b2b811fc5422849c07277eef88fcd0a0693d581a6fa9dc766'
    reference=TRIAL/'再現資料/出生と全統計正本.zip'
    helper.restore(helper.T162/'再現資料/出生と探索.zip',('work/162可変幅評価/自然射影/',))
    helper.restore(helper.T163/'再現資料/出生と統計正本.zip',('work/163入口と任意幅/全出生/出生200.npz',
        'work/163入口と任意幅/全出生/全出生の確認.json','work/162複合入口候補/候補辞書.json','work/162複合入口候補/履歴候補辞書.json'))
    for name in ('00165_順行と回復失敗を組み合わせ技術条件で初参加を補う','00166_未公表の長期指標を捏造せず局所技術で参加を補う'):
        prefix='work/165順行と回復失敗の複合/全出生/' if name.startswith('00165') else 'work/166可用指標の階層化/全出生/'
        helper.restore(ROOT/'study'/name/'再現資料/出生と統計正本.zip',(prefix,))
    alias=ROOT/'work/163任意幅の数値化/自然数値表'
    assert helper.sha(alias/'任意幅配列.npz')==helper.sha(ROOT/'inputs/00163_任意幅の共用価格索引/数値表/任意幅配列.npz')
    sys.path.insert(0,str(ROOT/'work/162入口探索'))
    common=helper.module(ROOT/'work/162入口探索/共通.py','共通');factory=common.data_module
    features=factory().load_feature_from_formal()
    def formal_data() -> object:
        """
        機能: 作業cacheを複製せず正式148から同体射影した旧73特徴を接続する。
        引数: なし。
        返り値: objectはload_feature_datasetのみを実行時接続した固定データmodule。
        """
        value=factory();value.load_feature_dataset=lambda:features;return value
    common.data_module=formal_data
    sys.path.insert(0,str(ENGINE));qa=HERE/('再現_'+args.mode);assert not qa.exists();qa.mkdir()
    (qa/'条件.json').write_bytes((TRIAL/'条件.json').read_bytes())
    checked=0
    if args.mode=='screen':
        assert not(ENGINE/'全出生').exists() and not(ENGINE/'旧73探索').exists()
        helper.module(ENGINE/'出生の人工検査.py','再現171人工').main()
        birth=helper.module(ENGINE/'出生を固定する.py','再現171出生');birth.TRIAL=qa;birth.main()
        screen=importlib.import_module('探索する');screen.TRIAL=qa;screen.ProcessPoolExecutor=SerialExecutor
        sys.argv=[str(ENGINE/'探索する.py'),'--workers','1'];screen.main()
        checked+=helper.compare_arrays(reference,'work/171三帯の入口切替/全出生/')
        checked+=helper.compare_arrays(reference,'work/171三帯の入口切替/旧73探索/')
    else:
        apply=helper.module(ENGINE/'固定候補を再生する.py','再現171固定')
        with zipfile.ZipFile(reference) as archive:
            seal=json.loads(archive.read('work/171三帯の入口切替/旧73探索/主案と前半A-Bの封印.json'))
            setting=json.loads((TRIAL/'条件.json').read_bytes())
            candidates=[seal['事前固定主案']['candidate']]+[v['candidate'] for v in seal['選択'].values() if v is not None]
            canonical=ROOT/'inputs/00167_追加七場の入口と共用価格索引'
            newfeatures,captures,_=apply.R168.BASE.load_features(canonical/'入口母集団')
            born={}
            for candidate in candidates:
                for key,value in apply.births(newfeatures,candidate,setting).items():born[candidate['id']+'__'+key]=value
            with np.load(BytesIO(archive.read('work/171三帯の入口切替/追加7固定候補の出生.npz')),allow_pickle=False) as expected:
                assert set(expected.files)==set(born)
                for key,value in born.items():assert np.array_equal(value,expected[key],equal_nan=True);checked+=1
            proof=json.loads((canonical/'生成の完了.json').read_bytes())
            adapter=apply.R168.BASE.module(ROOT/'work/166可変場の数値化/arrays166.py','再現171数値')
            table=adapter.load_table(canonical/'自然数値表',proof['cache'])
            new=apply.R168.BASE.GenericContext(newfeatures,table,captures)
            old0=apply.R168.BASE.Context165();old=apply.R168.BASE.GenericContext(old0.features,old0.table,old0.capture_rows)
            for label,context in [('旧73',old),('追加7',new)]:
                output=qa/label;actual=apply.run_context(context,candidates,setting,output)
                expected=json.loads(archive.read('work/171三帯の入口切替/'+label+'固定候補/固定候補の数量比較.json'))
                assert actual==expected
                actual=json.loads((output/'全取得参照.json').read_bytes())
                expected=json.loads(archive.read('work/171三帯の入口切替/'+label+'固定候補/全取得参照.json'))
                assert actual==expected;checked+=2
    result={'成功':True,'mode':args.mode,'照合数':checked,'正式正本SHA256':helper.sha(reference),
        '注意':'研究入力の再現。新しい未見性能又は実注文の検証ではない。'}
    (qa/'再現確認.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':main()
