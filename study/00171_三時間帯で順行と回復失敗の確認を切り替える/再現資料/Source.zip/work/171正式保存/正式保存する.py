"""171の有望主案と未達・未知を同時に残し、共有入力を複製せず正式保存する。"""
from pathlib import Path
import importlib.util
import importlib.metadata
import json
import os
import platform
import re
import shutil
import sys

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
TRIAL=ROOT/'study/00171_三時間帯で順行と回復失敗の確認を切り替える'
AUTHOR=ROOT/'work/171三帯の入口切替';QA=ROOT/'work/171独立確認'
BOOK_SHA='c310ea07df25078b2b811fc5422849c07277eef88fcd0a0693d581a6fa9dc766'
spec=importlib.util.spec_from_file_location('正式保存共通171',ROOT/'work/163_164正式保存/正式保存する.py')
B=importlib.util.module_from_spec(spec);spec.loader.exec_module(B)


def settings() -> None:
    """
    機能: 版8の63手法×9尺度を複写し、171の実参照と閾値を記す。
    引数: なし。
    返り値: None。未使用を有効性の否定又はデータ不足と混同しない。
    """
    source=ROOT/'docs/議論/手法と時間スケールの汎用表_版8.md'
    body=source.read_text(encoding='utf-8').split('## 手法×時間スケール',1)[1].split('## 設定明細',1)[0]
    body=body[body.index('### 指標'):];used={}
    for scale in (3,4,5):
        used[('I01',scale)]='EMA21傾き。旧T方向票とB2/B3の背景票'
        used[('I08',scale)]='DI差。'+('MPのADX水準/増分' if scale==4 else '旧T方向票/局所/背景票')
    for scale in (3,4):
        used[('I03',scale)]='Hist水準/増分'+('・ATR比・CONF動力' if scale==3 else '。MP水準/旧T増分')
        used[('I04',scale)]='RSI中心差/増分・急変制限' if scale==3 else '旧TのRSI増分'
    for method,scale,note in [('I01',0,'q0 EMA8距離/ATR5'),('I05',0,'Tの順側BB余地/200pt'),
        ('I05',4,'EXの反対端σ位置、旧Tのabsσ<=1'),('I09',0,'q0距離・1分終値乖離のATR5比。170ATR幅は使用しない'),
        ('I09',3,'Hist/ATR5、TR/ATR5'),('P01',3,'実体・終値位置・反対ヒゲ'),
        ('P05',0,'CONFのq0Last−m1Close実側ATR比>0'),('V01',1,'相対観測量の前3分比。rvol5は未使用'),
        ('B01',0,'0<spread<=10/20、absq0gap<=1ATR'),('C01',0,'方向・MACD/RSI・実体・量の複合、単一技法の効果とはしない'),
        ('C02',0,'EXのBB端/ヒゲ/回復動力/量から反対側の継続を検証'),('C04',0,'DI方向とADX強度/増分を別役割で使う'),
        ('C07',0,'5/15/30方向票、15/30背景票、q0帯による技術切替'),
        ('E01',0,'主MP150～250/失速300～500/補完200pt、H60 IFD_FIRST、cap10・未決予約')]:used[(method,scale)]=note
    lines=[];count=0
    for line in body.splitlines():
        cells=[c.strip() for c in line.split('|')[1:-1]] if line.startswith('|') else []
        if len(cells)==11 and re.fullmatch('[A-Z][0-9]{2}',cells[0]):
            count+=1
            for scale in range(9):cells[2+scale]='S171-X/Q：'+used[(cells[0],scale)]+'。R171' if (cells[0],scale) in used else '未使用・未検証'
            line='| '+' | '.join(cells)+' |'
        lines.append(line)
    assert count==63
    def relink(match: re.Match) -> str:
        """
        機能: 元版の教材リンクを試行からの相対位置へ移す。
        引数: match(re.Match)。
        返り値: strはMarkdownリンク。
        """
        target=match.group(2)
        if '://' in target or target.startswith('#'):return match.group(0)
        return '['+match.group(1)+']('+os.path.relpath((source.parent/target).resolve(),TRIAL).replace('\\','/')+')'
    body=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',relink,'\n'.join(lines))
    text='# 171 設定と結果\n\n2026-11-15。[汎用表版8](../../docs/議論/手法と時間スケールの汎用表_版8.md)の全63手法×9尺度=567セルを複写。元SHA256 `'+B.sha(source)+'`。\n\n'
    text+='使用欄は複合評価での参照であり、指標単独の効果ではない。原100Xに列が存在しても未使用のrvol5等と、今回未生成のVWAP/一目等を区別する。必要値未知を0/中立へ補完しない。木/HGBTのM01/M02、170ATR可変幅、新追尾E02は今回は未使用。\n\n## 手法×時間スケール\n\n'+body
    text+='''

## 設定明細

|設定ID|短い閾値・用途|複合評価|
|---|---|---|
|S171-MP|MP0057/58：Hist5/ATR>=0.1、Hist15>0、HistΔ5>=0、RSI中心>=0かつ<=25、RSIΔ5>0、ADX15>=25・Δ>=0、量>=0.75、spread<=10/20、absq0gap<=1|順行|
|S171-EX|EX0075/76：元回復側BB位置<=−2σ、反対ヒゲ>=0.2、RSI中心<=5、RSIΔ/HistΔ>0、実体>=0、量>=0.5、spread<=10/20、absq0gap<=1。新注文は元回復の反対側|回復失敗|
|S171-B|新注文側15/30分EMA21傾き/DI差の4票>=2/3。4列全known。B0は追加filterなし|背景|
|S171-CONF|元EXへの遷移で反対側arm、5/10分以内の初確認だけ。BASIC=新側HistΔ/RSIΔ/q0gap>0、absRSIΔ<=12、気配/乖離gate。STRONGはDI>0・量>=0.75追加|確認|
|S171-ROUTE|DAYはB0IMMEDIATE、PRE/POSTは各8技術式。OFF=MOMENTUM_ONLYもMP複合を継続。全場CONF履歴を先に計算しq0帯で選ぶ、帯境界にarm/resetを追加しない|256入口|
|S171-MERGE|MPとfade片方/同方向は採用、反対は待機。両同側はMP幅優先。同物理q1は最初要求、alias水増しなし|全候補|
|S171-T8|EMA/DIの5/15/30方向、Hist/RSI5/15動力、実体/終値、量、BB位置/余地、EMA8距離/TRの8票。必要17列全known、5票以上・側差1以上。方向/動力役割・追値/RSI急変等のgate含め20列|旧T固定200|
|S171-L6|長期HistΔが当時まで未公表かつ180分経過だけ、M5 EMA/DI/HistΔ/RSIΔ/実体終値/相対量6票中4以上。方向1・動力1、RSI−5..25/absΔ<=12、absEMA8距離<=1、TR/ATR<=2、量>=0.5。score7列、gate12列全known|局所固定200|
|S171-H|L180_S4/H200。旧T非0を優先、T0時だけ局所。有限0の長期HistΔも公表として現在行から局所禁止。主取得0・主pendingなし・開始45分以後だけ補完、取消後再試行|技術初参加|
|S171-CAP|要求1mini、買売各10枚、pendingも枠予約。数量棄却後次q0再判断。T予約後の後発主で未来取消しなし。exit秒の原行不明は秒末解放、未知は場末まで枠保持|168未改変|
|S171-E|MP150/175/200/225/250、fade300/350/400/500、補完200。各取得で対称幅を固定しH60 IFDFIRST。100円/pt、往復77円+追加滑り1000円、実両側BBO|単純IFD|
|S171-A/B|前48だけ、250取得/100到達/全48場/70%以上/0.75回毎時/未知<=10%/PF>=1.2/差引>0、Wilson95下限→count→PF→安定添字。Bはq0三帯各6到達/55%以上/PF>=1.05/差引>0追加|両null|

R171：4基礎×8PRE×8POST×5MP幅×4fade幅=5,120政策。主案はMP0057_EX0076、PRE元のまま・POST主MPのみ、200/400H60。補完はPOSTでも残す。全期発見支持1,392と、事前主案・前48A/B・既使用追加7確認を別保存する。[主結果](README.md)と[心理と限界](条件心理と限界.md)を参照。
'''
    (TRIAL/'設定と結果.md').write_text(text,encoding='utf-8')


def docs() -> None:
    """
    機能: 主案の全80・前後・帯を記し、A/B不適格や未知を隠さず残す。
    引数: なし。
    返り値: None。閲覧表は別担当の完成ファイルへだけリンクする。
    """
    aggregate=B.read(AUTHOR/'旧73探索/主案の全80加法.json');seal=B.read(AUTHOR/'旧73探索/主案と前半A-Bの封印.json')
    periods={'旧73既使用':aggregate['旧73'],'追加7既使用基準':aggregate['追加7既使用基準'],'全80加法':aggregate['全80加法']}
    root='# 171 三帯の技術切替で得た有望主案\n\n2026-11-15。**新しい候補探索を一旦停止し、研究候補として保存する。** 事前固定主案は、数量枠込みの全80場で644取得・230順81逆、到達済み先着率73.955%、平均0.812回/時（約74分に1回）、全場最低1取得。既知利益7,760,355円・損失3,438,248円・差引4,322,107円、PF2.257だった。\n\n'
    root+='一方、旧前48場の先着率は67.44%で70%へ届かず、前48だけのA/Bは両null。米国前は全80合算で赤字、追加7は既使用の基準期間で、新規独立未見の合格とは称さない。実運用の保証ではなく、次に検証すべき固定研究候補とする。\n\n## 仮説と固定条件\n\n'
    root+='[条件.json](条件.json)SHA256 `'+BOOK_SHA+'`。基礎はMP0057/58の複合順行と、EX0075/76の弱い回復へ逆らう複合入口。DAYは元技術を固定し、PRE/POSTで背景方向、後続動力/価格確認、主順行専用の8案を切り替えた。CONFは165の全場履歴から作り、q0帯だけでルートする。NY09:30の夏冬変換と等号以後をPOSTへ区分し、境界でarm/resetや強制決済を追加しない。\n\n'
    root+='**事前主案**：MP0057_EX0076_B0_IMMEDIATE、PREは元のまま、POSTの主新規はMPのみ。MP±200pt・回復失敗±400pt・技術補完±200pt、H60。L180_S4/H200の旧T/局所補完はPOSTでも維持する。全期bestを主案へ交換していない。\n\n'
    root+='4基礎×8PRE×8POST×5順行幅×4失速幅=5,120政策を比較。全期発見支持1,392は既使用探索で、前48だけの採用条件とは別。A/Bはいずれもnullを保持し、追加7へは主案だけを適用した。\n\n## 入力・費用・数量\n\n'
    root+='旧73場は35,339適格q0・31,642物理case、追加7は3,608適格q0・3,250物理case。母集団は固定された全1分知得q0/取得q1で、全原板毎行に新規判断する実運用の検証ではない。複数の技術役割と未知の扱いは[全V8設定表](設定と結果.md)へ記録した。売買は同じ実側正規化式。\n\n'
    root+='各要求mini1枚、買い/売り各10枚の未決+保有枠を168未改変engineで再生。数量棄却は次q0で再判断し、同物理q1のaliasは最初要求だけを取得する。未知決済は場末まで枠を占有、同秒exitの原行不明は秒末まで保有する。単純な10枚損益への乗算ではない。全対象ザラバ793時間20分（DAY08:45～15:40、Night17:00～05:55）を頻度分母とし、プレクロージングを即時約定可能としない。既存取得母集団の新規限界は継承した。\n\n'
    root+='実BBOはBUY Ask/SELL Bid取得、反対側で清算。1pt=100円、税込片道38.5円（往復77円）と追加往復滑り1000円を控除し、スプレッドも実側へ含む。対称IFD又はH60未到達の期限BBOで決済する。mini実板・待ち行列・通信遅延・証拠金等の実運用条件は未検証。\n\n## 主案の結果\n'
    root+=B.metric_table({'periods':periods})
    root+='\nF/A/N/Cは順側先着/逆側先着/未到達/観測不足。全80の到達済み分母は311件、N298件・C35件を別に残す。**費用後実現決済勝率は385/609=63.218%**であり、先着73.955%と同一ではない。C35件を0円へ埋めず、全件収支はnull。表は既知分の利益・損失・差引である。\n\n'
    root+='## 旧73の前後と未解決点\n'
    root+=B.metric_table(seal['事前固定主案'])
    root+='\n主案の旧前48は333取得・87順42逆・67.44%・0.700回/時。後25は106順27逆・79.70%で、全期だけを安定性と解釈しない。全5,120政策でも前48の70%以上は0件で、固定A/B支持に適格なし。前後はいずれも既使用である。\n\n## q0三帯の全80加法\n'
    root+=B.metric_table({'periods':aggregate['q0三帯']})
    root+='\nDAYが全体を支える。NY前は24順28逆・46.15%、差引−116,090円で未解決。NY後も36順21逆・63.16%、89取得で低頻度。全体70%超を各帯70%と読み替えない。帯はq0出生であり、q1取得帯は別正本に残す。\n\n## 検査と到達点\n\n'
    root+='独立純出生18,093,568方向/枝セルが一致。全5,120統計に不変式、全報告支持等1,581政策で金融1,000,773セル、独立一覧oracle296政策で186,958要求/164,122取得を照合。固定主案は両期間759要求/644取得と全場・帯・枝・売買・未知・数量が一致した。全5,120政策の全取得を別engineで再生した主張ではない。\n\n'
    root+='[心理と限界](条件心理と限界.md)、[再現手順](再現手順.md)、[正本索引](再現資料/保存索引.json)、[独立確認票](検査/171の独立確認.json)を参照。'
    if (TRIAL/'閲覧資料.md').exists():root+=' [閲覧資料](閲覧資料.md)にRootの最終CSV4表を整理した。'
    else:root+=' 閲覧CSV4表は別担当の閲覧資料へ接続する。'
    root+='\n';(TRIAL/'README.md').write_text(root,encoding='utf-8')
    cause='''# 技術の役割・心理仮説と限界

2026-11-15。一般的な技法の役割、市場心理の仮説、今回の確認事実を区別する。

MPはMACD/RSIの持続、ADXの強さ、量が伴う方向へ乗る。EXはBB端、反対ヒゲ、元側の短期回復、実体、量を組み合わせ、その回復が続かず元方向に吸収される局面を反対側注文で調べる。売り/買いは符号反転した同条件であり、単なる過熱だけの逆張りではない。

主MPにはRSI水準上限があるが、独立のRSI急変vetoは追加していない。急変上限を持つCONF/Tと条件を混同しない。

背景B2/3は実注文側の15/30分EMA/DI4票、CONFは元回復arm後のHist/RSI/現在価格の確認、STRONGはDIと量も要求する。判断対象は異なる役割の組合せで、指標の数だけを独立の証拠とはみなさない。

時間帯で参加者や情報流入が変われば、短い回復が継続するか・元方向へ戻るかも変わり得る、という心理仮説を立てた。DAYの技術幹を保持し、米国後の主失速を外す案を結果前に固定した。T/局所補完は残す。時間帯そのものの因果効果を同定したわけではない。

[Bollinger本人のCMT講演](https://cmtassociation.org/wp-content/uploads/2024/01/Bollinger-Trading-Bands-1.pdf)（2026-11-14確認）の複数指標と価格動作の考え方を参考にするが、原典は本候補の利益を証明しない。CONFは165の全場履歴で先に評価し、帯境界で新armを作らず、既に消費した確認を後から再利用しない。

確認事実として、全帯を元のままにした80幅政策は169固定技術と同体、全routeでDAYは不変だった。主案全80は73.955%・全場参加・平均約74分に1取得、PF2.257。しかし旧前48は67.44%、NY前は全80でも赤字。DAYの84.16%が全体を支え、夜間も一様に70%を達成したという結論ではない。

旧T8票は長中短の情報を要し、15分Hist本体34本/増分35本の連続助走不足で成立できない9デイがあった。166以来の局所6票は当時まで長期増分が一度も有限でない場に限る。有限0を中立として穴埋めせず、有限公表が出た当行から局所禁止。局所10件は1順2逆7未到達・差引−32,770円で、全場参加の補完単独が高精度とは言わない。

前48A/Bは両null。全期発見1,392候補をその代わりへ交換せず、事前主案だけを追加7へ適用した。追加7の167/168/170基準は既に参照されていたため、171では既使用の基準期である。少数追加7や多数試行の全80合算を新規独立未見の保証にしない。

全80の観測不足35件は確定利益/損失へ推定補完しない。数量枠は再生したが、ラージBBOによるmini約定代用、通信/注文遅延、待ち行列、証拠金、実保護注文は未検証。先着率と決済勝率、費用後PFと全件収支の未確定を分ける。

ユーザーの「良い結論が出たら一旦停止」に従い、新候補の探索を一旦終える。研究候補として固定し、残る前半/NY前の問題や未検証条件は消さない。次に条件を変える場合は新試行とする。
'''
    (TRIAL/'条件心理と限界.md').write_text(cause,encoding='utf-8');settings()


def reproduction() -> None:
    """
    機能: Source共有・入力正本・隔離再現の手順と実施範囲を記す。
    引数: なし。
    返り値: None。workだけに依存する閲覧経路を作らない。
    """
    text='''# 171 再現手順

2026-11-15。Python3.14.3/NumPy2.5.4/ijson3.6.0/tzdata2026.6、Windows。Source/正本の全member・サイズ・SHAと親入力は[保存索引](再現資料/保存索引.json)に保持する。

- [Source.zip](再現資料/Source.zip)：171純route/出生/探索/固定二期間/自己確認、未改変168engine、167可変S基盤、169純選択器、可変場adapter、独立171と依存oracleの小型Source。
- [出生と全統計正本.zip](再現資料/出生と全統計正本.zip)：全256route出生、全5120統計と軸、事前主案/A-B封印、全期発見先頭40、旧73と追加7の主案出生/全取得/全場/二時計三帯/枝/数量、加法と自己確認。NPZ/gzipは既圧縮の元byteをそのまま外側ZIPへ格納する。
- [共有163](../../inputs/00163_任意幅の共用価格索引/README.md)：旧73の価格索引/純観測/金融配列。原板・161cacheを再保存しない。
- [共有167](../../inputs/00167_追加七場の入口と共用価格索引/README.md)：追加7の母集団/価格索引/純観測/金融。正本は一組だけで、171へ複写しない。

正式148入力と、162→163→164→165→166の必要Source.zipをリポジトリルートへ展開し、最後に171Source.zipを展開する。旧出生は各親の正式正本ZIPから復元する。旧161の作業feature2cacheは複製せず、ラッパーが正式148の当時特徴・固定取得から同体射影する。

元Sourceの固定work数値表パスを共有163へJunctionで結ぶ（既存なら作らない）。

```powershell
New-Item -ItemType Junction -Path 'work/163任意幅の数値化/自然数値表' -Target (Resolve-Path -LiteralPath 'inputs/00163_任意幅の共用価格索引/数値表')
& 'work/複合テクニカル学習環境/Scripts/python.exe' -X utf8 'work/171正式保存/正式入力から再現する.py' --mode screen
```

全出生/旧73探索が未作成の隔離checkoutでだけ実行する。元Source byteは変更せず、正式特徴loadと検査票保存先を実行時接続し、CPU poolを同一processの直列mapへ接続する。候補式/約定/数量/統計は同じで、実行秒や実行worker数は当時と異なる。全出力NPZ配列をNaN込みで正本へ照合する。Sourceの取引ロジックや正式条件は変更しない。

事前主案とnonnullA/Bだけの旧73・追加7再現は別mode。

```powershell
& 'work/複合テクニカル学習環境/Scripts/python.exe' -X utf8 'work/171正式保存/正式入力から再現する.py' --mode fixed
```

このmodeは元の封印候補をZIPから読み、追加7の純出生を金融表より先に作って元NPZへ照合する。共有167からGenericContextを構成し、固定候補の全取得参照と全報告JSONを正本へ照合する。追加7の全5120探索はしない。追加7は既使用基準であり再現自体も新しい未見検証ではない。

保存時には新ラッパーのcompile/--helpのみ確認しており、このラッパーで全探索を再度走らせたわけではない。作者の自然実行・独立QA・ラッパー準備を区別する。独立QAは当時のcacheを使うSourceも含み、再実行には親151/161の復元経路が必要。本体の固定候補再現は正式148射影でcache複製を避ける。

実施済み独立確認は純18,093,568方向/枝、全5,120不変式、支持等1,581政策の金融1,000,773セル、一覧oracle296政策186,958要求/164,122取得、固定二期間759要求/644取得。全5,120の全取得を別engineで再生したとは称さない。CSV接続は別担当の[閲覧資料](閲覧資料.md)へ記す。

自己確認の元169対照80政策は、当時の169正本SHAを票へ記録した。169統計の恒久保存は169側へ参照し、171へ3.56MBを複製しない。本体171の計算再現には169統計は不要である。
'''
    if not(TRIAL/'閲覧資料.md').exists():text=text.replace('[閲覧資料](閲覧資料.md)','閲覧資料.md')
    (TRIAL/'再現手順.md').write_text(text,encoding='utf-8')


# ----------------------------------------
def main() -> None:
    """
    機能: 主4MD、Sourceと全数値正本、指紋索引を保存する。
    引数: なし。CSV/閲覧側の資料・global・条件・自然値は変更しない。
    返り値: None。独立171票を正式コピーし、共用入力を再複製しない。
    """
    assert B.sha(TRIAL/'条件.json')==BOOK_SHA
    assert B.sha(QA/'171の独立確認.json')=='4d7c937426ba9a8fa7cdd6e32a8b7a1799316f71f41d39fa036adf66c7c188f1'
    sources=B.source_files(AUTHOR.relative_to(ROOT).as_posix())+B.source_files('work/171独立確認')+B.source_files('work/171正式保存')
    sources=[p for p in sources if p.suffix!='.txt' and p.name not in ('追加7固定候補の出生.npz','固定候補二期間の完了.json')]
    needed=['work/168数量枠の因果再生/engine168.py','work/168数量枠の因果再生/再生する.py',
        'work/168数量枠の因果再生/部品の停止.json','work/167固定入口の別期間/適用基盤167.py',
        'work/166可変場の数値化/arrays166.py','work/166可変場の数値化/数値化の停止.json',
        'work/169数量枠と技術近傍/selector169.py','work/169数量枠と技術近傍/選択の人工確認.json',
        'work/167_168自然独立確認/出生と全自然政策を検算する.py',
        'work/170自然独立確認/旧七十三場を層別検算する.py','work/170純幅独立確認/幅と配列engineを検査する.py',
        'work/170ATRと三時間帯/width170.py','work/170ATRと三時間帯/engine170.py',
        'work/168数量枠の独立確認/独立人工を確認する.py']
    sources +=[ROOT/path for path in needed]
    data=[p for folder in ('全出生','旧73探索','旧73固定候補','追加7固定候補') for p in (AUTHOR/folder).iterdir() if p.is_file()]
    data +=[AUTHOR/'追加7固定候補の出生.npz',AUTHOR/'固定候補二期間の完了.json']
    before={path:B.sha(path) for path in set(sources+data)}
    docs();reproduction()
    for filename in ('171の独立確認.json','親出生と純関数の補足確認.json','全確認の停止.json'):
        shutil.copyfile(QA/filename,TRIAL/'検査'/filename)
    output=TRIAL/'再現資料';output.mkdir(exist_ok=True)
    source_members=B.archive(output/'Source.zip',sources);data_members=B.archive(output/'出生と全統計正本.zip',data)
    refs=[B.reference(ROOT/'inputs/00163_任意幅の共用価格索引/保存索引.json'),
        B.reference(ROOT/'inputs/00167_追加七場の入口と共用価格索引/保存索引.json')]
    for name in ('00162_複合入口を広く探索し値幅ごとに過去選択する','00163_履歴を含む複合入口を任意幅と場末まで検証する',
        '00164_IFD最初到達の確定時計で入口と反転を比較する','00165_順行と回復失敗を組み合わせ技術条件で初参加を補う','00166_未公表の長期指標を捏造せず局所技術で参加を補う'):
        refs.append(B.reference(ROOT/'study'/name/'再現資料/Source.zip'))
    for name,archive in [('00162_複合入口を広く探索し値幅ごとに過去選択する','出生と探索.zip'),
        ('00163_履歴を含む複合入口を任意幅と場末まで検証する','出生と統計正本.zip'),
        ('00165_順行と回復失敗を組み合わせ技術条件で初参加を補う','出生と統計正本.zip'),
        ('00166_未公表の長期指標を捏造せず局所技術で参加を補う','出生と統計正本.zip')]:
        refs.append(B.reference(ROOT/'study'/name/'再現資料'/archive))
    index={'成功':True,'試行':171,'条件':B.reference(TRIAL/'条件.json'),
        '実行環境':{'Python':sys.version,'NumPy':importlib.metadata.version('numpy'),'ijson':importlib.metadata.version('ijson'),
            'tzdata':importlib.metadata.version('tzdata'),'OS':platform.platform(),'旧73探索workers':8},
        '正本':[{'archive':B.reference(output/'Source.zip'),'members':source_members},
            {'archive':B.reference(output/'出生と全統計正本.zip'),'members':data_members}],
        '共有入力と祖先':refs,'非重複':'Raw/共有163/167の入口母集団/金融配列/161cache/祖先出生を171へ複製しない。',
        '保存検査':'全member CRC/byte/SHAと元Source/数値前後同体。保存資料・閲覧資料は担当を分離。',
        '区別':'主案/全期発見/前48A-Bnull/既使用追加7を混同しない。新候補探索は一旦終了。'}
    B.save(output/'保存索引.json',index)
    assert all(B.sha(path)==digest for path,digest in before.items()) and B.sha(TRIAL/'条件.json')==BOOK_SHA
    print(json.dumps({'成功':True,'保存索引':B.reference(output/'保存索引.json'),'Source前後同体':len(before)},ensure_ascii=False))


if __name__=='__main__':main()
