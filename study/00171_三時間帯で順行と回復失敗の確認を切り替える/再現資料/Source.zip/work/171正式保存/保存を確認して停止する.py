"""171主保存のCRC/指紋/文書/主要数値を確認し、閲覧側と分けて停止する。"""
from pathlib import Path
import hashlib
import json
import re
import zipfile

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
TRIAL=ROOT/'study/00171_三時間帯で順行と回復失敗の確認を切り替える'
DOCS=('README.md','設定と結果.md','条件心理と限界.md','再現手順.md')


def sha(path: Path) -> str:
    """
    機能: 全物理ファイルを読了して指紋化する。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    with path.open('rb') as source:return hashlib.file_digest(source,'sha256').hexdigest()


def read(path: Path) -> object:
    """
    機能: 標準JSONを解析する。
    引数: path(Path)。
    返り値: objectは解析値。
    """
    return json.loads(path.read_bytes())


def ref(path: Path) -> dict:
    """
    機能: 主資料をサイズとSHAで参照する。
    引数: path(Path)。
    返り値: dictはリポジトリ相対参照。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':sha(path)}


def check_ref(record: dict) -> None:
    """
    機能: 索引が指す実体を確認する。
    引数: record(dict)。
    返り値: None。
    """
    path=ROOT/record['path'];assert path.stat().st_size==record['bytes'] and sha(path)==record['sha256']


# ----------------------------------------
def main() -> None:
    """
    機能: 主4MDと二ZIP/親索引/独立171票を検査し主保存だけを停止する。
    引数: なし。CSV/閲覧表資料とその独立停止は変更せず別担当へ残す。
    返り値: None。主保存確認と停止票を正式検査へ保存する。
    """
    index_path=TRIAL/'再現資料/保存索引.json';index=read(index_path);assert index['成功'] and index['試行']==171
    check_ref(index['条件']);members=0
    for group in index['正本']:
        check_ref(group['archive'])
        with zipfile.ZipFile(ROOT/group['archive']['path']) as archive:
            assert archive.testzip() is None
            assert set(archive.namelist())=={item['path'] for item in group['members']}
            for item in group['members']:
                body=archive.read(item['path']);assert len(body)==item['bytes'] and hashlib.sha256(body).hexdigest()==item['sha256']
                check_ref(item);members+=1
                assert not item['path'].startswith(('inputs/','work/167追加七場の入力/原板','work/163任意幅'))
    for item in index['共有入力と祖先']:check_ref(item)
    links=0;texts=[]
    for filename in DOCS:
        path=TRIAL/filename;text=path.read_text(encoding='utf-8',errors='strict');texts.append(text)
        for target in re.findall(r'\[[^\]]+\]\(([^)]+)\)',text):
            if '://' in target or target.startswith('#'):continue
            actual=(path.parent/target.split('#')[0]).resolve()
            assert actual.exists() and not actual.is_relative_to((ROOT/'work').resolve()),(filename,target)
            links+=1
    rows=[line for line in texts[1].splitlines() if re.match(r'^\| [A-Z][0-9]{2} \|',line)]
    assert len(rows)==63 and all(len(line.split('|')[1:-1])==11 for line in rows)
    readme=texts[0]
    required=('644','230','81','298','35','73.955%','7,760,355','3,438,248','4,322,107','63.218%',
        '67.44%','−116,090','既使用','両null','未改変','5,120','1,581','1,000,773','759','実運用')
    assert all(word in readme for word in required),[word for word in required if word not in readme]
    assert 'RSIΔ5>0、' in texts[1] and 'RSIΔ5>0.5' not in texts[1]
    assert sha(TRIAL/'検査/171の独立確認.json')=='4d7c937426ba9a8fa7cdd6e32a8b7a1799316f71f41d39fa036adf66c7c188f1'
    assert read(TRIAL/'検査/親出生と純関数の補足確認.json')['成功']
    assert read(ROOT/'work/171三帯の入口切替/旧73探索/自然統計の自己確認.json')['成功']
    assert read(ROOT/'work/171三帯の入口切替/旧73探索/主案と前半A-Bの封印.json')['選択']=={'A':None,'B':None}
    proof={'成功':True,'範囲':'主正式保存の自己確認。自然計算の独立検査は171独立票へ参照。',
        '主4文書':{name:ref(TRIAL/name) for name in DOCS},'ローカルリンク':links,'V8全手法':63,'V8全セル':567,
        'ZIP全member':members,'主保存索引':ref(index_path),'主要数値と閾値表記':True,'AとBのnull不変':True,
        '閲覧資料は別担当で不変更':True,'保存確認Source':ref(Path(__file__))}
    path=TRIAL/'検査/主保存の確認.json';path.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    paths=[TRIAL/name for name in DOCS]+[TRIAL/'条件.json',path,index_path,
        TRIAL/'再現資料/Source.zip',TRIAL/'再現資料/出生と全統計正本.zip',TRIAL/'検査/171の独立確認.json',
        TRIAL/'検査/親出生と純関数の補足確認.json',TRIAL/'検査/全確認の停止.json']
    stop={'成功':True,'主保存ファイル':[ref(p) for p in paths],
        '範囲':'主4MD/Source/全数値/主索引/主QAだけ。CSV/閲覧側/globalは各担当の停止へ参照。新候補探索は一旦終了。'}
    path=TRIAL/'検査/主保存の停止.json';path.write_text(json.dumps(stop,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'確認':ref(TRIAL/'検査/主保存の確認.json'),'停止':ref(path),'member':members,'links':links},ensure_ascii=False))


if __name__=='__main__':main()
