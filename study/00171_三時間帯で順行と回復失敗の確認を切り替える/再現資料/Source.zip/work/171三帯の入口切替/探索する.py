"""三帯で入口確認を切り替えた5120政策を168cap10で再生する。"""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from itertools import product
import argparse
import json
import sys
import time
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
TRIAL=ROOT/'study/00171_三時間帯で順行と回復失敗の確認を切り替える'
BOOK_SHA='c310ea07df25078b2b811fc5422849c07277eef88fcd0a0693d581a6fa9dc766'
ENGINE_SHA='a2f728bf7e7c925495d01670f1bbf89d88aaea6b8e207490e080d6c2d9f21050'
sys.path.insert(0,str(ROOT/'work/168数量枠の因果再生'))
import 再生する as R168
from 共通163 import read,save,sha
sys.path.insert(0,str(ROOT/'work/169数量枠と技術近傍'))
import selector169

FIELDS=('count','F','A','N','C','rate','complete_rate','all_rate','profit','loss','net','pf','known','unknown',
    'all_net','wins','loss_trades','realized_win_rate','scenes','eligible_scenes','all_scenes','hours','per_hour',
    'max_scene_share','hold_mean_seconds','hold_median_seconds','quantity_rejected_core','quantity_rejected_technical',
    'peak_reserved_buy','peak_reserved_sell','peak_held_buy','peak_held_sell','peak_pending_buy','peak_pending_sell',
    'core_count','old_technical_count','local_technical_count')
PERIODS=('全期','前48場','後25場')
WORKER_CONTEXT=None;WORKER_CAPTURES=None;WORKER_BIRTH=None;WORKER_SETTING=None


def initialize_worker() -> None:
    """
    機能: 各CPU workerで旧73場の固定入力だけを一度読み共用する。
    引数: なし。
    返り値: None。新7場・167自然結果は読まない。
    """
    global WORKER_CONTEXT,WORKER_CAPTURES,WORKER_BIRTH,WORKER_SETTING
    assert sha(ROOT/'work/168数量枠の因果再生/engine168.py')==ENGINE_SHA
    WORKER_SETTING=read(TRIAL/'条件.json');assert sha(TRIAL/'条件.json')==BOOK_SHA
    old=R168.BASE.Context165();WORKER_CONTEXT=R168.BASE.GenericContext(old.features,old.table,old.capture_rows)
    assert len(WORKER_CONTEXT.scenes)==73
    assert WORKER_SETTING['horizon'] in WORKER_CONTEXT.table.horizons
    WORKER_CAPTURES=R168.capture_descriptors(WORKER_CONTEXT)
    path=HERE/'全出生/三帯入口の出生.npz';proof=read(path.parent/'出生の確認.json')
    assert proof['金融未入力'] and sha(path)==proof['files'][path.name]['sha256']
    assert [p['id'] for p in proof['profiles']]==WORKER_SETTING['core_profiles']
    assert proof['pre_options']==WORKER_SETTING['pre_options'] and proof['post_options']==WORKER_SETTING['post_options']
    with np.load(path,allow_pickle=False) as source:WORKER_BIRTH={name:source[name].copy() for name in source.files}
    assert np.array_equal(WORKER_BIRTH['phases'],WORKER_CONTEXT.event_phases)


def candidate(position: tuple,setting: dict) -> dict:
    """
    機能: 安定した五添字から再利用可能な固定候補を作る。
    引数: position(tuple[int,...])、setting(dict)は171固定条件。
    返り値: dictは167/168 runnerへ渡せる候補。
    """
    pi,pre,post,mi,fi=position;name=setting['core_profiles'][pi]
    mp,ex,background,timing=name.split('_',3)
    return {'id':'P%d_PRE%d_POST%d_M%d_F%d'%position,
        'profile':{'id':name,'momentum':mp,'fade':ex,'background':int(background[1:]),'timing':timing},
        'pre':setting['pre_options'][pre]['id'],'post':setting['post_options'][post]['id'],
        'hierarchy':{'id':'L180_S4','after_minutes':180,'minimum_score':4},
        'momentum_width':setting['momentum_widths'][mi],'fade_width':setting['fade_widths'][fi],
        'horizon':setting['horizon'],'integration':'H200',
        'scope':'171旧73発見。A/Bは前48固定、全期bestへ交換しない。追加期も既使用基準。'}


def vector(value: dict) -> np.ndarray:
    """
    機能: 未定義NoneをNaNのまま共通配列へ置く。
    引数: value(dict)は統計と数量診断。
    返り値: np.ndarray[len(FIELDS)]はfloat64。
    """
    return np.array([np.nan if value.get(name) is None else value[name] for name in FIELDS],dtype=np.float64)


def evaluate(position: tuple) -> tuple:
    """
    機能: 幅/期限ごとに新しくcap再生し、全期・前後・q0/q1三帯を集計する。
    引数: position(tuple[int,...])は五政策添字。
    返り値: tupleは位置、三期間統計、三期間×二時計×三帯統計。
    """
    context=WORKER_CONTEXT;setting=WORKER_SETTING;born=WORKER_BIRTH
    pi,pre,post,mi,fi=position;choice=candidate(position,setting)
    hi=context.table.horizons.index(setting['horizon'])
    birth={'core':born['directions'][pi,pre,post],'branches':born['branches'][pi,pre,post],
        'technical':born['technical'],'tier':born['tier']}
    width_map={int(w):i for i,w in enumerate(context.table.widths)}
    def exit_lookup(case: int,side: int,width: int) -> float|None:
        """
        機能: 当該幅/期限の決済時計だけを未改変engineへ渡す。
        引数: case/side/width(int)。
        返り値: floatは既知exit秒、Noneは未知。
        """
        wi=width_map[width]
        return float(context.arrays['exit_time'][case,side,wi,hi]) if context.arrays['known'][case,side,wi,hi] else None
    result=R168.engine168.replay(context.event_keys,context.event_scenes,
        np.array([s['start'] for s in context.scenes]),np.array([s['end'] for s in context.scenes]),
        WORKER_CAPTURES,birth['core'],birth['branches'],birth['technical'],birth['tier'],
        choice['momentum_width'],choice['fade_width'],int(choice['integration'][1:]),exit_lookup,capacity=10)
    rows=result['records'];events=np.array([r['event'] for r in rows],dtype=np.int32)
    selected=R168.Selection(np.array([r['case'] for r in rows],dtype=np.int32),np.array([r['side'] for r in rows],dtype=np.int8),
        events,context.event_phases[events],np.zeros(len(rows),dtype=bool))
    widths=np.array([width_map[r['width']] for r in rows],dtype=np.int8)
    origins=np.array([r['origin'] for r in rows],dtype=np.int8);tiers=np.array([r['tier'] for r in rows],dtype=np.int8)
    scene=context.case_scene[selected.cases];metrics=np.empty((3,len(FIELDS)));bands=np.empty((3,2,3,len(FIELDS)))
    for period,eligible in enumerate((np.ones(73,dtype=bool),np.arange(73)<48,np.arange(73)>=48)):
        mask=eligible[scene];value=R168.BASE.statistics(context,selected,widths,hi,mask,eligible)
        audits=[a for a in result['audits'] if eligible[a['scene_index']]]
        value.update(quantity_rejected_core=sum(a['quantity_rejected_core'] for a in audits),
            quantity_rejected_technical=sum(a['quantity_rejected_technical'] for a in audits),
            core_count=int(np.sum(mask&(origins==0))),old_technical_count=int(np.sum(mask&(origins==2)&(tiers==1))),
            local_technical_count=int(np.sum(mask&(origins==2)&(tiers==2))))
        for prefix,key in [('peak_reserved','peak_reserved_total'),('peak_held','peak_held'),('peak_pending','peak_pending')]:
            peak=np.max([a[key] for a in audits],axis=0)
            value[prefix+'_buy']=int(peak[0]);value[prefix+'_sell']=int(peak[1])
        metrics[period]=vector(value)
        for clock,phases in enumerate((selected.phases,context.case_phases[selected.cases])):
            for band in range(3):
                scope=eligible&(context.hours[:,band]>0)
                band_mask=mask&(phases==band)
                value=R168.BASE.statistics(context,selected,widths,hi,band_mask,scope,float(context.hours[scope,band].sum()))
                value.update(core_count=int(np.sum(band_mask&(origins==0))),
                    old_technical_count=int(np.sum(band_mask&(origins==2)&(tiers==1))),
                    local_technical_count=int(np.sum(band_mask&(origins==2)&(tiers==2))))
                bands[period,clock,band]=vector(value)
    return position,metrics,bands


def materialize(values: np.ndarray) -> dict:
    """
    機能: 三期間統計をJSON標準の数値/nullへ変換する。
    引数: values(np.ndarray[3,F])。
    返り値: dictは期間別指標。
    """
    return {period:{name:float(v) if np.isfinite(v) else None for name,v in zip(FIELDS,row,strict=True)}
        for period,row in zip(PERIODS,values,strict=True)}


# ----------------------------------------
def main() -> None:
    """
    機能: 旧73だけの5120再生を保存し、後25を選択へ渡さずA/Bを封印する。
    引数: CLI --workers(int)はCPU並列数、既定8。
    返り値: None。Source/数値正本/前半A/Bと全期発見を分けて保存する。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--workers',type=int,default=8);args=parser.parse_args()
    assert 1<=args.workers<=16 and sha(TRIAL/'条件.json')==BOOK_SHA
    setting=read(TRIAL/'条件.json');out=HERE/'旧73探索';assert not out.exists()
    assert sha(ROOT/'work/168数量枠の因果再生/engine168.py')==ENGINE_SHA
    assert read(ROOT/'work/168数量枠の因果再生/部品の停止.json')['成功']
    artificial=read(HERE/'出生の人工確認.json');assert artificial['成功']
    assert artificial['Source']['route171.py']==sha(HERE/'route171.py')
    paths=[Path(__file__),HERE/'route171.py',HERE/'出生を固定する.py',HERE/'出生の人工確認.json',
        HERE/'全出生/三帯入口の出生.npz',HERE/'全出生/出生の確認.json',
        ROOT/'work/169数量枠と技術近傍/selector169.py',ROOT/'work/169数量枠と技術近傍/選択の人工確認.json',
        ROOT/'work/168数量枠の因果再生/engine168.py',ROOT/'work/168数量枠の因果再生/再生する.py',
        ROOT/'work/168数量枠の因果再生/部品の停止.json',ROOT/'work/167固定入口の別期間/適用基盤167.py']
    before={p.relative_to(ROOT).as_posix():sha(p) for p in paths}
    save(TRIAL/'検査/F0_旧七十三場の数量探索前.json',{'成功':True,'条件SHA256':BOOK_SHA,'Sourceと入力':before,
        '追加七場成績未読':True,'選択入力は前48とq0帯だけ':True})
    shape=(4,8,8,5,4);positions=list(product(*(range(n) for n in shape)));assert len(positions)==5120
    metrics=np.full((*shape,3,len(FIELDS)),np.nan);bands=np.full((*shape,3,2,3,len(FIELDS)),np.nan)
    out.mkdir();begin=time.monotonic()
    with ProcessPoolExecutor(max_workers=args.workers,initializer=initialize_worker) as pool:
        for index,(position,value,band_values) in enumerate(pool.map(evaluate,positions,chunksize=4),1):
            metrics[position]=value;bands[position]=band_values
            if index%320==0:print(json.dumps({'完了':index,'全政策':5120,'秒':round(time.monotonic()-begin)},ensure_ascii=False),flush=True)
    np.savez_compressed(out/'三帯入口の統計配列.npz',metrics=metrics,bands=bands)
    save(out/'統計軸.json',{'成功':True,'shape':list(metrics.shape),'bands_shape':list(bands.shape),'fields':FIELDS,
        'core_profiles':setting['core_profiles'],'pre_options':setting['pre_options'],'post_options':setting['post_options'],
        'momentum_widths':setting['momentum_widths'],'fade_widths':setting['fade_widths'],
        'horizon':setting['horizon'],'integration':'H200','hierarchy':'L180_S4','periods':PERIODS,
        'band_clocks':['q0','q1'],'bands':['DAY','NY前','NY後'],
        'band_unknown':'数量棄却/ピークは帯別未集計NaN。金融未知/all_net未確定もNaN。0円実績へ置換しない。'})
    flat=metrics.reshape(5120,3,len(FIELDS));flat_bands=bands.reshape(5120,3,2,3,len(FIELDS))
    selection=selector169.select_front48(flat[:,1,:],flat_bands[:,1,0,:,:],list(FIELDS),{**setting,'trial':169})
    chosen={}
    for key in ('A','B'):
        row=selection[key];index=row['position']
        if index is None:chosen[key]=None;continue
        position=positions[index];choice=candidate(position,setting);choice['id']=key
        chosen[key]={'candidate':choice,'position':list(position),'flat_index':int(index),
            'score':row['score'],'eligible_count':int(np.sum(row['eligible'])),
            '前48のみ選択':True,'periods':materialize(flat[index]),
            'front_q0_bands':{name:{field:float(v) if np.isfinite(v) else None for field,v in zip(FIELDS,flat_bands[index,1,0,bi],strict=True)}
                for bi,name in enumerate(('DAY','NY前','NY後'))}}
    main=setting['main_profile']
    main_position=(setting['core_profiles'].index(main['profile']),
        next(i for i,p in enumerate(setting['pre_options']) if p['id']==main['pre']),
        next(i for i,p in enumerate(setting['post_options']) if p['id']==main['post']),
        setting['momentum_widths'].index(main['momentum_width']),setting['fade_widths'].index(main['fade_width']))
    primary={'candidate':candidate(main_position,setting),'position':list(main_position),'periods':materialize(metrics[main_position])}
    primary['candidate']['id']='PRIMARY171'
    save(out/'主案と前半A-Bの封印.json',{'成功':True,'条件SHA256':BOOK_SHA,'追加七場成績未読':True,
        'Sourceと入力':before,'統計正本SHA256':sha(out/'三帯入口の統計配列.npz'),'選択':chosen,'事前固定主案':primary,
        '注意':'後25は既使用。全期発見へ交換せず、追加7へは事前主案と固定A/Bだけを渡す。追加7も既使用基準。'})
    f={name:i for i,name in enumerate(FIELDS)};full=flat[:,0];front=flat[:,1];back=flat[:,2];support=setting['discovery_support']
    mask=(full[:,f['count']]>=max(support['minimum_count'],support['minimum_new_count']))&(full[:,f['F']]+full[:,f['A']]>=support['minimum_resolved'])&\
        (full[:,f['all_scenes']]==1)&(full[:,f['rate']]>=support['minimum_rate'])&\
        (front[:,f['F']]+front[:,f['A']]>=support['minimum_resolved_each_period'])&\
        (back[:,f['F']]+back[:,f['A']]>=support['minimum_resolved_each_period'])&\
        (front[:,f['rate']]>=support['minimum_rate_each_period'])&(back[:,f['rate']]>=support['minimum_rate_each_period'])&\
        (full[:,f['unknown']]<=support['maximum_financial_unknown_fraction']*full[:,f['count']])&\
        (front[:,f['net']]>0)&(back[:,f['net']]>0)
    found=sorted(np.flatnonzero(mask),key=lambda i:(-full[i,f['count']],-full[i,f['rate']],int(i)))
    save(out/'全期発見の上位.json',{'成功':True,'全期発見で未見ではない':True,'支持合格':len(found),
        '上位':[{'candidate':candidate(positions[i],setting),'position':list(positions[i]),'periods':materialize(flat[i])} for i in found[:40]]})
    assert all(sha(ROOT/path)==digest for path,digest in before.items())
    save(out/'完了.json',{'成功':True,'条件SHA256':BOOK_SHA,'Sourceと入力':before,'追加七場成績未読':True,
        'workers':args.workers,'経過秒':time.monotonic()-begin,
        'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in out.iterdir() if p.is_file()}})
    print(json.dumps({'成功':True,'支持':len(found),'選択':chosen,'主案':primary},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
