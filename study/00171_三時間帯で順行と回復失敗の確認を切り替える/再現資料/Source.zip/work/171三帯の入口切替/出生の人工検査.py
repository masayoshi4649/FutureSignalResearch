"""171純route・全場確認履歴・売買反射・夏冬境界を人工確認する。"""
from pathlib import Path
from types import SimpleNamespace
from zoneinfo import ZoneInfo
import datetime
import hashlib
import json
import numpy as np
import route171 as M

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 純出生Sourceの指紋を計算する。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    with path.open('rb') as source:return hashlib.file_digest(source,'sha256').hexdigest()


def main() -> None:
    """
    機能: 自然特徴・金融を読まずphase選択と未来不変/反射を人工確認する。
    引数: なし。
    返り値: None。人工票を保存する。
    """
    book=json.loads((ROOT/'study/00171_三時間帯で順行と回復失敗の確認を切り替える/条件.json').read_bytes())
    n=9;phases=np.array([0,0,0,1,1,1,2,2,2]);day=np.ones(n,dtype=np.int8);pre=-day;post=np.zeros(n,dtype=np.int8)
    a,b=M.route(day,np.zeros(n,dtype=np.int8),pre,np.ones(n,dtype=np.int8),post,np.full(n,-1,dtype=np.int8),phases)
    assert a.tolist()==[1,1,1,-1,-1,-1,0,0,0] and b.tolist()==[0,0,0,1,1,1,-1,-1,-1]
    checks=['phase行だけのroute・DAY不変・OFF待機と枝の整合']
    data=M.BASE.data_module()
    for date in [(2026,10,30),(2026,11,2)]:
        stamp=datetime.datetime(*date,9,30,tzinfo=ZoneInfo('America/New_York')).timestamp()
        session=f'{date[0]:04d}-{date[1]:02d}-{date[2]:02d}_Night'
        assert data.us_open_time(session)==stamp
        assert [data.timeband(session,stamp+delta) for delta in (-1,0,1)]==[1,2,2]
    checks.append('NY09:30夏冬の直前/等号/直後をZoneInfo独立時計へ照合')
    catalog=json.loads((ROOT/'inputs/00148_全1分入口母集団/100特徴の列定義.json').read_bytes());columns=[x['name'] for x in catalog]
    index={name:i for i,name in enumerate(columns)};rng=np.random.default_rng(171);mirror_rows=0;prefix_rows=0;born=0
    profile={'id':'MP0057_EX0076_B0_IMMEDIATE','momentum':'MP0057','fade':'EX0076','background':0,'timing':'IMMEDIATE'}
    for repeat in range(16):
        n=80;buy=rng.normal(size=(n,100));sell=rng.normal(size=(n,100))
        for x in (buy,sell):
            x[:,index['q0_spread_points']]=5;x[:,index['m1_volume_relative_prior3']]=1
            x[:,index['m15_adx']]=25;x[:,index['m15_adx_delta']]=1
            x[:,index['m5_rsi_center_to_side']]*=10;x[:,index['bb15_position_sigma_to_side']]*=2
            x[:,index['q0_last_minus_m1_close_atr5_to_side']]*=.25
            x[:,index['m5_opposite_wick_ratio']]=.4
        metadata=[{'session_index':0,'q0_time':10800+i*60,'contract':'人工'} for i in range(n)]
        features=SimpleNamespace(buy_X=buy,sell_X=sell,columns=columns,q0_meta=metadata,
            q0_timeband=np.repeat([0,1,2],[20,30,30]),scenes=[{'start':0}])
        candidate={'profile':profile,'pre':'CONF10_BASIC','post':'CONF5_STRONG',
            'hierarchy':{'id':'L180_S4','after_minutes':180,'minimum_score':4},'integration':'H200'}
        first=M.births(features,candidate,book);born+=np.count_nonzero(first['core'])
        mirrored=SimpleNamespace(**{**vars(features),'buy_X':sell,'sell_X':buy});other=M.births(mirrored,candidate,book)
        for key in ('core','technical','oldtechnical','local'):assert np.array_equal(first[key],-other[key]),key
        assert np.array_equal(first['branches'],other['branches']);assert np.array_equal(first['tier'],other['tier'])
        mirror_rows+=n
        for cut in (1,39,79):
            a=buy.copy();b=sell.copy();a[cut:]=np.nan;b[cut:]=np.nan
            changed=SimpleNamespace(**{**vars(features),'buy_X':a,'sell_X':b})
            later=M.births(changed,candidate,book)
            for key in first:assert np.array_equal(first[key][:cut],later[key][:cut]),(key,cut)
            prefix_rows+=cut
    assert born>0
    checks.append('16人工場の全場CONF履歴route・買売反射・後続特徴毒でも全返り値の接頭不変')
    proof={'成功':True,'自然特徴と金融未入力':True,'検査群':checks,'鏡像行数':mirror_rows,'接頭行数':prefix_rows,
        '人工主出生':int(born),'Source':{p.name:sha(p) for p in [HERE/'route171.py',Path(__file__)]}}
    (HERE/'出生の人工確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':main()
