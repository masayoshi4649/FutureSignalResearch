"""171全保存配列・DAY不変・元技術対照・封印候補二期間を自己確認する。"""
from pathlib import Path
import hashlib
import json
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'work/169数量枠と技術近傍'))
import selector169


def sha(path: Path) -> str:
    """
    機能: 対象ファイルを全読了し物理指紋化する。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    with path.open('rb') as source:return hashlib.file_digest(source,'sha256').hexdigest()


def main() -> None:
    """
    機能: 全5120不変式・旧169対照80政策・DAY全route不変・主案の旧73経路同体を確認する。
    引数: なし。A/Bは前48だけで再計算し、追加7は封印後の主案報告照合だけに用いる。
    返り値: None。自己確認票と主案二期間の加法正本を保存する。
    """
    folder=HERE/'旧73探索';axes=json.loads((folder/'統計軸.json').read_bytes());fields=axes['fields'];f={n:i for i,n in enumerate(fields)}
    path=folder/'三帯入口の統計配列.npz'
    with np.load(path,allow_pickle=False) as archive:
        cube=archive['metrics'];band_cube=archive['bands'];values=cube.reshape(5120,3,len(fields));bands=band_cube.reshape(5120,3,2,3,len(fields))
    additive=('count','F','A','N','C','profit','loss','net','known','unknown','wins','loss_trades','core_count','old_technical_count','local_technical_count')
    for name in additive:
        i=f[name];assert np.array_equal(values[:,0,i],values[:,1,i]+values[:,2,i])
        for clock in (0,1):assert np.array_equal(values[:,:,i],bands[:,:,clock,:,i].sum(axis=2))
    assert np.array_equal(sum(values[:,:,f[n]] for n in ('F','A','N','C')),values[:,:,f['count']])
    assert np.array_equal(values[:,:,f['known']]+values[:,:,f['unknown']],values[:,:,f['count']])
    assert np.array_equal(values[:,:,f['C']],values[:,:,f['unknown']])
    assert np.array_equal(values[:,:,f['profit']]-values[:,:,f['loss']],values[:,:,f['net']])
    assert np.all(values[:,:,[f['peak_reserved_buy'],f['peak_reserved_sell']]]<=10)
    for pi in range(4):
        for mi in range(5):
            for fi in range(4):
                day=band_cube[pi,:,:,mi,fi,:,:,0,:]
                assert np.array_equal(day,np.broadcast_to(day[0,0],day.shape),equal_nan=True)
    previous=ROOT/'work/169数量枠と技術近傍/旧73探索/数量枠探索の統計配列.npz'
    with np.load(previous,allow_pickle=False) as old:
        for pi in range(4):
            for mi in range(5):
                for fi in range(4):
                    assert np.array_equal(cube[pi,0,0,mi,fi],old['metrics'][pi,2,mi,fi+1,1,1],equal_nan=True)
                    assert np.array_equal(band_cube[pi,0,0,mi,fi],old['bands'][pi,2,mi,fi+1,1,1],equal_nan=True)
    book=json.loads((ROOT/'study/00171_三時間帯で順行と回復失敗の確認を切り替える/条件.json').read_bytes())
    selected=selector169.select_front48(values[:,1],bands[:,1,0],fields,{**book,'trial':169})
    seal_path=folder/'主案と前半A-Bの封印.json';sealed=json.loads(seal_path.read_bytes())
    assert sealed['選択']=={'A':None,'B':None} and selected['A']['position'] is selected['B']['position'] is None
    old=json.loads((HERE/'旧73固定候補/固定候補の数量比較.json').read_bytes())['rows'][0]['cap10']
    new=json.loads((HERE/'追加7固定候補/固定候補の数量比較.json').read_bytes())['rows'][0]['cap10']
    index=np.ravel_multi_index(tuple(sealed['事前固定主案']['position']),(4,8,8,5,4));checked=0
    for pi,period in enumerate(axes['periods']):
        for name,actual in old['periods'][period].items():
            if name not in f:continue
            expected=values[index,pi,f[name]]
            if actual is None:assert np.isnan(expected)
            else:assert actual==expected,(period,name)
            checked+=1
    sum_fields=('count','F','A','N','C','profit','loss','net','known','unknown','wins','loss_trades','scenes','eligible_scenes','hours')
    def combine(a: dict,b: dict) -> dict:
        """
        機能: 重複しない旧73/追加7の主案加法と再計算率を求める。
        引数: a/b(dict)は同じ主案の別期間統計。
        返り値: dictは全80の既知/未知を分けた合算。
        """
        result={name:a[name]+b[name] for name in sum_fields};n=result['F']+result['A']
        result.update(rate=result['F']/n if n else None,pf=result['profit']/result['loss'] if result['loss'] else None,
            per_hour=result['count']/result['hours'] if result['hours'] else None,
            all_scenes=a['all_scenes'] and b['all_scenes'],all_net=None if result['unknown'] else result['net'],
            realized_win_rate=result['wins']/result['known'] if result['known'] else None)
        return result
    total=combine(old['periods']['全期'],new['periods']['全期'])
    combined={'成功':True,'旧73':old['periods']['全期'],'追加7既使用基準':new['periods']['全期'],'全80加法':total,
        'q0三帯':{name:combine(old['timebands']['q0'][name],new['timebands']['q0'][name]) for name in ('DAY','NY前','NY後')},
        '注意':'追加7は171選択時点の新規独立未見ではない。A/Bnullは追加数値で変更しない。全収支は未知35件を含み未確定。'}
    (folder/'主案の全80加法.json').write_text(json.dumps(combined,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    proof={'成功':True,'範囲':'全保存配列の不変式・対照80政策同体・封印候補旧73経路同体と二期間加法。独立自然再生ではない。',
        '全政策':5120,'元技術対照政策数':80,'DAY全route不変':True,'主案旧73同体欄':checked,'AとBの封印不変':True,
        '統計正本SHA256':sha(path),'SourceSHA256':sha(Path(__file__))}
    (folder/'自然統計の自己確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'確認':proof,'全80':total},ensure_ascii=False))


if __name__=='__main__':main()
