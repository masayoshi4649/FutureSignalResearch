"""金融未入力165/163出生をq0帯で組み替え、新しい171出生を封印する。"""
from pathlib import Path
import sys
import numpy as np
import route171

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
TRIAL=ROOT/'study/00171_三時間帯で順行と回復失敗の確認を切り替える'
BOOK_SHA='c310ea07df25078b2b811fc5422849c07277eef88fcd0a0693d581a6fa9dc766'
sys.path.insert(0,str(ROOT/'work/163入口と任意幅'))
from 共通163 import read,save,sha,data_module


def main() -> None:
    """
    機能: 4基礎×8PRE×8POSTのq0方向と枝を金融前に封印する。
    引数: なし。未改変165/163/166出生と当時純特徴/三帯だけを読む。
    返り値: None。全出生/三帯入口の出生.npzと同体/Source/特徴証拠を保存する。
    """
    assert sha(TRIAL/'条件.json')==BOOK_SHA;setting=read(TRIAL/'条件.json');out=HERE/'全出生';assert not out.exists()
    assert setting['pre_options']==setting['post_options']
    artificial=read(HERE/'出生の人工確認.json');assert artificial['成功']
    assert artificial['Source']['route171.py']==sha(HERE/'route171.py')
    parent165=ROOT/'work/165順行と回復失敗の複合/全出生';p165=read(parent165/'全出生の確認.json')
    parent163=ROOT/'work/163入口と任意幅/全出生';p163=read(parent163/'全出生の確認.json')
    parent166=ROOT/'work/166可用指標の階層化/全出生';p166=read(parent166/'全出生の確認.json')
    paths=[Path(__file__),HERE/'route171.py',HERE/'出生の人工確認.json',
        parent165/'複合と技術補完.npz',parent165/'全出生の確認.json',parent163/'出生200.npz',parent163/'全出生の確認.json',
        parent166/'階層化の出生.npz',parent166/'全出生の確認.json']
    before={p.relative_to(ROOT).as_posix():sha(p) for p in paths}
    for proof,path in [(p165,parent165/'複合と技術補完.npz'),(p163,parent163/'出生200.npz'),(p166,parent166/'階層化の出生.npz')]:
        assert proof['成功'] and proof['金融未入力'] and sha(path)==proof['files'][path.name]['sha256']
    save(TRIAL/'検査/F0_三帯出生固定前.json',{'成功':True,'条件SHA256':BOOK_SHA,'金融未入力':True,'Sourceと出生':before})
    with np.load(parent165/'複合と技術補完.npz',allow_pickle=False) as a,np.load(parent163/'出生200.npz',allow_pickle=False) as b,np.load(parent166/'階層化の出生.npz',allow_pickle=False) as c:
        source165={name:a[name].copy() for name in a.files};source163=b['ALL'].copy()
        technical=c['technical'][2,1].copy();tier=c['technical_tier'][2,1].copy()
    assert p166['hierarchies'][2]['id']=='L180_S4' and p166['technical_widths'][1]==200
    lookup165={p['id']:i for i,p in enumerate(p165['profiles'])};lookup163={name:i for i,name in enumerate(p163['規則順'])}
    features=data_module().load_feature_dataset();phases=features.q0_timeband;n=len(phases);assert n==35339
    data=data_module();assert np.array_equal(phases,np.array([data.timeband(q['session'],q['q0_time']) for q in features.q0_meta]))
    directions=np.empty((4,8,8,n),dtype=np.int8);branches=np.empty_like(directions);profiles=[];checks=[]
    for pi,name in enumerate(setting['core_profiles']):
        profile=p165['profiles'][lookup165[name]].copy();profiles.append(profile)
        mp=source163[lookup163[profile['momentum']]];options_d=[];options_b=[]
        for option in setting['pre_options']:
            if option['timing']=='OFF':a=mp;b=np.where(mp!=0,0,-1).astype(np.int8)
            else:
                key=f"{profile['momentum']}_{profile['fade']}_B{option['background']}_{option['timing']}"
                index=lookup165[key];a=source165['directions'][index];b=source165['branches'][index]
            options_d.append(a);options_b.append(b)
        pure=route171.option_births(features,profile,setting['pre_options'])
        assert np.array_equal(pure['directions'],np.stack(options_d)) and np.array_equal(pure['branches'],np.stack(options_b))
        for pre in range(8):
            for post in range(8):
                directions[pi,pre,post],branches[pi,pre,post]=route171.route(options_d[0],options_b[0],options_d[pre],options_b[pre],options_d[post],options_b[post],phases)
                assert np.array_equal(directions[pi,pre,post,phases==0],options_d[0][phases==0])
        assert np.array_equal(directions[pi,0,0],source165['directions'][lookup165[name]])
        checks.append({'profile':name,'純特徴再計算と旧8式同体':True,'全帯元にしたとき165同体':True})
    out.mkdir();path=out/'三帯入口の出生.npz'
    np.savez_compressed(path,directions=directions,branches=branches,technical=technical,tier=tier,phases=phases)
    assert all(sha(ROOT/p)==digest for p,digest in before.items())
    save(out/'出生の確認.json',{'成功':True,'金融未入力':True,'条件SHA256':BOOK_SHA,'Sourceと出生':before,'features':features.sources,
        'profiles':profiles,'pre_options':setting['pre_options'],'post_options':setting['post_options'],'同体確認':checks,
        'shape':list(directions.shape),'補完':'L180_S4/H200の166同体、全q0未改変',
        'files':{path.name:{'bytes':path.stat().st_size,'sha256':sha(path)}}})
    print({'成功':True,'出生SHA256':sha(path),'全q0方向数':directions.size})


if __name__=='__main__':main()
