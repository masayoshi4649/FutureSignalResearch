"""封印済み三帯主案と前半選択だけを旧73・追加7へ適用する。"""
from pathlib import Path
import json
import numpy as np
import 固定候補を再生する as apply

ROOT=apply.ROOT
HERE=Path(__file__).resolve().parent
BASE=apply.R168.BASE
read,save,sha=apply.R168.read,apply.R168.save,apply.R168.sha
TRIAL=ROOT/'study/00171_三時間帯で順行と回復失敗の確認を切り替える'


def main() -> None:
    """
    機能: 事前主案を交換せず、追加金融入力前に純出生を保存して二期間へ適用する。
    引数: なし。固定主案とnonnull前半選択のみを利用し、発見上位は追加へ適用しない。
    返り値: None。固定候補の二期間結果、全取得参照、Sourceと出生の前後指紋を保存する。
    """
    setting=read(TRIAL/'条件.json')
    assert sha(TRIAL/'条件.json')=='c310ea07df25078b2b811fc5422849c07277eef88fcd0a0693d581a6fa9dc766'
    seal_path=HERE/'旧73探索/主案と前半A-Bの封印.json'
    assert sha(seal_path)=='2dada6882201c2fc9b17be105959a5243a987478d4f746e7a36d9701ceaffd4c'
    seal=read(seal_path);assert seal['成功']
    candidates=[seal['事前固定主案']['candidate']]
    candidates.extend(value['candidate'] for value in seal['選択'].values() if value is not None)
    assert 1<=len(candidates)<=3
    directory=ROOT/'work/167追加七場の入力'
    paths=[Path(__file__),HERE/'固定候補を再生する.py',HERE/'route171.py',seal_path,
        ROOT/'work/168数量枠の因果再生/engine168.py',directory/'生成の完了.json',directory/'入口母集団/完了.json']
    before={p.relative_to(ROOT).as_posix():sha(p) for p in paths}
    features,captures,_=BASE.load_features(directory/'入口母集団')
    born={};prepared={}
    for candidate in candidates:
        result=apply.births(features,candidate,setting);prepared[candidate['id']]=result
        for key,value in result.items():born[candidate['id']+'__'+key]=value
    path=HERE/'追加7固定候補の出生.npz';assert not path.exists()
    np.savez_compressed(path,**born)
    save(TRIAL/'検査/F1_追加固定候補の金融前封印.json',{'成功':True,'Sourceと入力':before,
        '今回出生の金融数値表未入力':True,'新規独立未見ではない':True,'出生SHA256':sha(path),'候補':candidates})
    numeric=read(directory/'生成の完了.json');assert numeric['成功']
    adapter=BASE.module(ROOT/'work/166可変場の数値化/arrays166.py','arrays166_for171')
    table=adapter.load_table(directory/'自然数値表',numeric['cache'])
    new=BASE.GenericContext(features,table,captures)
    old0=BASE.Context165();old=BASE.GenericContext(old0.features,old0.table,old0.capture_rows)
    reports=[]
    for label,context,folder in [('旧73',old,'旧73固定候補'),('追加7',new,'追加7固定候補')]:
        result=apply.run_context(context,candidates,setting,HERE/folder)
        if label=='追加7':
            for candidate in candidates:
                actual=apply.births(features,candidate,setting)
                for key,value in actual.items():assert np.array_equal(value,prepared[candidate['id']][key],equal_nan=True)
        reports.extend({'period':label,'id':r['id'],'metrics':r['cap10']['periods']['全期']} for r in result['rows'])
        save(HERE/folder/'完了.json',{'成功':True,'条件SHA256':sha(TRIAL/'条件.json'),'Sourceと入力':before,
            'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in (HERE/folder).iterdir() if p.is_file()}})
    assert all(sha(ROOT/p)==v for p,v in before.items())
    save(HERE/'固定候補二期間の完了.json',{'成功':True,'Sourceと入力':before,'出生SHA256':sha(path),'rows':reports})
    print(json.dumps({'成功':True,'rows':reports},ensure_ascii=False))


if __name__=='__main__':
    main()
