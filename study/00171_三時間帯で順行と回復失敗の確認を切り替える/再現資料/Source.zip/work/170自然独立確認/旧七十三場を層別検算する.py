"""170の全配列不変式と全支持/主案/層別政策を独立の自然oracleで検算する。"""
from pathlib import Path
from itertools import product
import importlib.util
import math
import sys
import time

import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
AUTHOR=ROOT/'work/170ATRと三時間帯'
OUT=AUTHOR/'旧73探索'
BOOK=ROOT/'study/00170_ATRと三時間帯の幅で複合入口を数量枠に適合させる/条件.json'
BOOK_SHA='c7c0ebeaebc51a24b256c74ad0dfe1aeaa1d7ff8d4ee019d25d5d92f064a0f1b'


def module(path: Path,name: str) -> object:
    """
    機能: 実行mainを呼ばず独立式又は比較対象を取り込む。
    引数: path(Path)、name(str)はSourceと識別名。
    返り値: objectはmodule。
    """
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec)
    sys.modules[name]=value;spec.loader.exec_module(value);return value


PREVIOUS_PATH=ROOT/'work/167_168自然独立確認/出生と全自然政策を検算する.py'
PURE_PATH=ROOT/'work/170純幅独立確認/幅と配列engineを検査する.py'
previous=module(PREVIOUS_PATH,'independent_natural170');pure=module(PURE_PATH,'independent_pure170')
read=previous.read;save=previous.save;sha=previous.sha


def oracle(data: dict,capacity: int=10) -> dict:
    """
    機能: 一覧イベント走査で全要求・取得・三種類の場別ピークを再生する。
    引数: data(dict)は当時出生・時計・幅、capacity(int)は片側上限。
    返り値: dictはrecords/requests/audits。数量判断にnet/labelを入力しない。
    """
    records=[];requests=[];audits=[];serial=0
    for scene,end in enumerate(data['scene_ends']):
        held=[0,0];pending=[0,0];calendar=[];waiting={};seen=set();ever=False
        audit={'scene_index':scene,'quantity_rejected_core':0,'quantity_rejected_technical':0,
               'peak_reserved_total':[0,0],'peak_held':[0,0],'peak_pending':[0,0]}
        def observe() -> None:
            """
            機能: 片側枠不変式と各同時数ピークを更新する。
            引数: なし。
            返り値: None。場内状態のみ参照する。
            """
            assert all(0<=held[side]+pending[side]<=capacity for side in (0,1))
            for name,value in (('peak_reserved_total',[held[s]+pending[s] for s in (0,1)]),('peak_held',held),('peak_pending',pending)):
                audit[name]=[max(a,b) for a,b in zip(audit[name],value,strict=True)]
        for event in np.flatnonzero(data['event_scenes']==scene).tolist()+[None]:
            now=(float(end),math.inf,math.inf) if event is None else tuple(data['event_keys'][event])
            while calendar:
                ni=min(range(len(calendar)),key=lambda i:calendar[i][:2]);key,order,kind,row=calendar[ni]
                if key>now:break
                calendar.pop(ni);side=row['side']
                if kind=='release':held[side]-=1;observe();continue
                pending[side]-=1;waiting.pop(order)
                if kind=='cancel':observe();continue
                if row['case'] in seen:observe();continue
                seen.add(row['case']);held[side]+=1;ever=True;observe()
                records.append({k:row[k] for k in ('event','case','side','width','origin','tier')})
                at=data['exit_lookup'](row['case'],side,row['width']);release=end if at is None else at
                serial+=1;calendar.append(((float(release),math.inf,math.inf),serial,'release',row))
            if event is None:break
            core=int(data['core'][event]);technical=int(data['technical'][event])
            width=int(data['momentum_width'][event] if data['branches'][event]==0 else data['fade_width'][event])
            if width<=0:core=0
            if core:side=0 if core>0 else 1;origin=0;tier=0
            else:
                if now[0]<data['scene_starts'][scene]+data['after_seconds'] or ever or technical==0 or waiting:continue
                side=0 if technical>0 else 1;origin=2;tier=int(data['tiers'][event]);width=data['technical_width']
            request={'event':event,'scene_index':scene,'side':side,'width':width,'origin':origin,'tier':tier,
                     'at':list(now),'held_before':held[side],'pending_before':pending[side],
                     'accepted':held[side]+pending[side]<capacity}
            requests.append(request)
            if not request['accepted']:
                audit['quantity_rejected_core' if origin==0 else 'quantity_rejected_technical']+=1;continue
            capture=data['captures'][event];kind='fill' if capture['status']=='filled' else 'cancel'
            key=tuple(capture['fill_key'] if kind=='fill' else capture['finish_key']);row={**request,'case':capture['case'] if kind=='fill' else -1}
            pending[side]+=1;serial+=1;calendar.append((key,serial,kind,row));waiting[serial]=row;observe()
        assert held==pending==[0,0];audits.append(audit)
    records.sort(key=lambda row:(row['event'],row['origin']))
    return {'records':records,'requests':requests,'audits':audits}


def divide(a: np.ndarray,b: np.ndarray) -> np.ndarray:
    """
    機能: 分母0を未定義NaNにする。
    引数: a/b(np.ndarray)は分子と分母。
    返り値: np.ndarrayは率。
    """
    return np.divide(a,b,out=np.full(np.broadcast_shapes(np.shape(a),np.shape(b)),np.nan),where=np.asarray(b)!=0)


def verify_array(metrics: np.ndarray,bands: np.ndarray,counts: np.ndarray,fields: list) -> dict:
    """
    機能: 全4096政策に金融・取得分解・時計・幅分布の不変式を適用する。
    引数: metrics/bands/counts(np.ndarray)、fields(list[str])は保存された全配列。
    返り値: dictは検査セルと範囲。
    """
    f={name:i for i,name in enumerate(fields)};v=lambda name:metrics[...,f[name]];b=lambda name:bands[...,f[name]]
    for array,get in ((metrics,v),(bands,b)):
        assert np.array_equal(get('F')+get('A')+get('N')+get('C'),get('count'))
        assert np.array_equal(get('known')+get('unknown'),get('count')) and np.array_equal(get('C'),get('unknown'))
        assert np.array_equal(get('profit')-get('loss'),get('net'))
        assert np.array_equal(get('core_count')+get('old_technical_count')+get('local_technical_count'),get('count'))
        assert np.allclose(get('rate'),divide(get('F'),get('F')+get('A')),equal_nan=True)
        assert np.allclose(get('all_rate'),divide(get('F'),get('count')),equal_nan=True)
        assert np.allclose(get('realized_win_rate'),divide(get('wins'),get('known')),equal_nan=True)
        assert np.array_equal(np.isnan(get('all_net')),get('unknown')>0)
        mask=get('unknown')==0;assert np.array_equal(get('all_net')[mask],get('net')[mask])
        assert np.all(get('wins')+get('loss_trades')<=get('known'))
    additive=('count','F','A','N','C','profit','loss','net','known','unknown','wins','loss_trades','core_count','old_technical_count','local_technical_count')
    for name in (*additive,'quantity_rejected_core','quantity_rejected_technical'):
        value=v(name);assert np.array_equal(value[...,0],value[...,1]+value[...,2]),name
    for name in additive:
        value=b(name);assert np.array_equal(value[...,0,:,:],value[...,1,:,:]+value[...,2,:,:]),('帯前後',name)
        for clock in range(2):assert np.array_equal(value[...,clock,:].sum(axis=-1),v(name)),('三帯加法',clock,name)
    for prefix in ('peak_reserved','peak_held','peak_pending'):
        for side in ('buy','sell'):
            values=v(prefix+'_'+side);assert np.all((values>=0)&(values<=10))
            assert np.array_equal(values[...,0],np.maximum(values[...,1],values[...,2]))
            assert np.isnan(b(prefix+'_'+side)).all()
    assert np.array_equal(counts.sum(axis=(-1,-2)),v('count'))
    assert np.array_equal(counts[...,0,:,:],counts[...,1,:,:]+counts[...,2,:,:])
    assert np.array_equal(counts[...,0,:].sum(axis=-1)+counts[...,1,:].sum(axis=-1),v('core_count'))
    assert np.array_equal(counts[...,2,:].sum(axis=-1),v('old_technical_count'))
    assert np.array_equal(counts[...,3,:].sum(axis=-1),v('local_technical_count'))
    return {'全4096統計セル':int(metrics.size),'全帯統計セル':int(bands.size),'全幅分布セル':int(counts.size),'不変式':True}


def main() -> None:
    """
    機能: 全支持82政策・事前主案・各軸層別政策を独立replay/金融で検算する。
    引数: なし。旧73場だけを読み、追加7場・170追加適用は開かない。
    返り値: None。検査範囲・全支持位置・選択nullの検算と停止票を保存する。
    """
    sys.stdout.reconfigure(encoding='utf-8');begin=time.monotonic();assert sha(BOOK)==BOOK_SHA
    paths=[Path(__file__),PREVIOUS_PATH,PURE_PATH,BOOK,AUTHOR/'engine170.py',AUTHOR/'width170.py',AUTHOR/'探索する.py',
           OUT/'ATR数量探索の統計配列.npz',OUT/'統計軸.json',OUT/'主案と前半A-Bの封印.json',OUT/'全期発見の上位.json',OUT/'完了.json',
           AUTHOR/'全幅/当時ATRの幅.npz',AUTHOR/'全幅/幅の確認.json',
           ROOT/'work/166可用指標の階層化/全出生/階層化の出生.npz',
           ROOT/'work/163任意幅の数値化/自然数値表/任意幅配列.npz',
           ROOT/'work/151過去場判別の評価/入口選択/cache/feature_only/features.npz',
           ROOT/'work/151過去場判別の評価/入口選択/cache/feature_only/features_meta.json',
           ROOT/'inputs/00148_全1分入口母集団/取得対応.json.gz']
    before={path.relative_to(ROOT).as_posix():sha(path) for path in paths};setting=read(BOOK);axes=read(paths[8]);seal=read(paths[9]);found=read(paths[10])
    with np.load(paths[7],allow_pickle=False) as source:
        metrics=source['metrics'].copy();bands=source['bands'].copy();counts=source['width_counts'].copy()
    f={name:i for i,name in enumerate(axes['fields'])};invariants=verify_array(metrics,bands,counts,axes['fields'])
    flat=metrics.reshape(4096,3,len(f));full=flat[:,0];front=flat[:,1];back=flat[:,2];support=setting['discovery_support']
    supported=(full[:,f['count']]>=max(support['minimum_count'],support['minimum_new_count']))&\
              (full[:,f['F']]+full[:,f['A']]>=support['minimum_resolved'])&(full[:,f['all_scenes']]==1)&\
              (full[:,f['rate']]>=support['minimum_rate'])&(front[:,f['F']]+front[:,f['A']]>=support['minimum_resolved_each_period'])&\
              (back[:,f['F']]+back[:,f['A']]>=support['minimum_resolved_each_period'])&\
              (front[:,f['rate']]>=support['minimum_rate_each_period'])&(back[:,f['rate']]>=support['minimum_rate_each_period'])&\
              (full[:,f['unknown']]<=support['maximum_financial_unknown_fraction']*full[:,f['count']])&\
              (front[:,f['net']]>0)&(back[:,f['net']]>0)
    assert int(supported.sum())==found['支持合格']==82
    shape=metrics.shape[:-2];supported_positions={tuple(map(int,np.unravel_index(i,shape))) for i in np.flatnonzero(supported)}
    positions=set(supported_positions);positions.add(tuple(seal['事前固定主案']['position']))
    for p,l,s,t in product(range(4),range(4),range(2),range(2)):
        positions.add((p,l,(p+l)%4,(2*p+l)%4,s,(p+2*l+s+t)%4,t))
    for h,m,w in product(range(4),range(4),range(4)):
        positions.add(((h+m)%4,(h+w)%4,m,w,(m+w)%2,h,(h+m+w)%2))
    # 前48選択を支持式から独立算出し、A/B nullを確認する。
    base=setting['base_support'];resolved=front[:,f['F']]+front[:,f['A']]
    pf=divide(front[:,f['profit']],front[:,f['loss']]);pf=np.where((front[:,f['loss']]==0)&(front[:,f['profit']]>0),np.inf,pf)
    eligible=(front[:,f['count']]>=base['minimum_count'])&(resolved>=base['minimum_resolved'])&\
             (front[:,f['rate']]>=base['minimum_rate'])&(front[:,f['per_hour']]>=base['minimum_per_hour'])&\
             (front[:,f['scenes']]==48)&(front[:,f['all_scenes']]==1)&\
             (front[:,f['unknown']]<=base['maximum_unknown_fraction']*front[:,f['count']])&\
             (pf>=base['minimum_pf'])&(front[:,f['net']]>base['minimum_net'])
    assert not eligible.any() and seal['選択']['A'] is None and seal['選択']['B'] is None
    # ----------------------------------------
    # 取得原板と固定出生・幅を読み、支持/層別候補だけを独立一覧で全要求再生する。
    data=previous.load_dataset(True)
    with np.load(paths[12],allow_pickle=False) as source:widths={name:source[name].copy() for name in source.files}
    with np.load(paths[14],allow_pickle=False) as source:birth={name:source[name].copy() for name in source.files}
    financial_cells=0;request_rows=0;record_rows=0;results=[]
    for index,position in enumerate(sorted(positions),1):
        p,l,m,w,s,h,t=position
        born={'core':birth['directions'][p],'branches':birth['branches'][p],'technical':birth['technical'][l,t],'tier':birth['technical_tier'][l,t]}
        candidate={'horizon':setting['horizons'][h],'integration':setting['integration'][t],
                   'momentum_width':200,'fade_width':400}
        inputs=previous.oracle_data(data,born,candidate)
        inputs['momentum_width']=widths['momentum'][s,m];inputs['fade_width']=widths['fade'][s,w]
        expected=oracle(inputs,10);actual=pure.engine.replay(**inputs,capacity=10)
        assert expected['records']==actual['records'] and expected['requests']==actual['requests'],position
        for a,b in zip(expected['audits'],actual['audits'],strict=True):
            for name in a:assert a[name]==b[name],(position,name)
        request_rows+=len(expected['requests']);record_rows+=len(expected['records'])
        rows=[(r['case'],r['side'],r['event'],r['origin']) for r in expected['records']]
        wi=np.asarray([data.meta['widths'].index(r['width']) for r in expected['records']],dtype=np.int8)
        chosen=np.asarray([r['tier'] for r in expected['records']],dtype=np.int8)
        scenes=np.asarray([data.arrays['session_index'][r['case']] for r in expected['records']],dtype=np.int16)
        origin=np.asarray([r['origin'] for r in expected['records']],dtype=np.int8)
        branch=np.asarray([int(born['branches'][r['event']]) if r['origin']==0 else 2 if r['tier']==1 else 3 for r in expected['records']])
        record_width=np.asarray([r['width'] for r in expected['records']]);grid_index=np.searchsorted(setting['width_grid'],record_width)
        for period,scope in enumerate((np.ones(73,dtype=bool),np.arange(73)<48,np.arange(73)>=48)):
            mask=scope[scenes];value=previous.statistics(data,rows,wi,h,mask,scope)
            value.update(core_count=int(np.sum(mask&(origin==0))),old_technical_count=int(np.sum(mask&(chosen==1))),
                         local_technical_count=int(np.sum(mask&(chosen==2))))
            audit=[a for a in expected['audits'] if scope[a['scene_index']]]
            value.update(quantity_rejected_core=sum(a['quantity_rejected_core'] for a in audit),
                         quantity_rejected_technical=sum(a['quantity_rejected_technical'] for a in audit))
            for prefix,key in (('peak_reserved','peak_reserved_total'),('peak_held','peak_held'),('peak_pending','peak_pending')):
                peak=np.max([a[key] for a in audit],axis=0);value[prefix+'_buy']=int(peak[0]);value[prefix+'_sell']=int(peak[1])
            for name,v in value.items():
                got=metrics[position+(period,f[name])]
                assert np.isnan(got) if v is None else math.isclose(got,v,rel_tol=1e-12,abs_tol=1e-9),(position,period,name,got,v)
                financial_cells+=1
            for clock in range(2):
                phases=previous.phases(data,rows,'q0' if clock==0 else 'q1')
                for band in range(3):
                    eligible_scene=scope&(data.hours[:,band]>0);selected=mask&(phases==band)
                    value=previous.statistics(data,rows,wi,h,selected,eligible_scene,float(data.hours[eligible_scene,band].sum()))
                    value.update(core_count=int(np.sum(selected&(origin==0))),old_technical_count=int(np.sum(selected&(chosen==1))),
                                 local_technical_count=int(np.sum(selected&(chosen==2))))
                    for name,v in value.items():
                        got=bands[position+(period,clock,band,f[name])]
                        assert np.isnan(got) if v is None else math.isclose(got,v,rel_tol=1e-12,abs_tol=1e-9),(position,period,clock,band,name,got,v)
                        financial_cells+=1
            for bi in range(4):
                histogram=np.bincount(grid_index[mask&(branch==bi)],minlength=len(setting['width_grid']))
                assert np.array_equal(histogram,counts[position+(period,bi)]),(position,period,bi)
        results.append({'position':list(position),'支持82に含む':position in supported_positions,
                        '要求数':len(expected['requests']),'取得数':len(expected['records']),
                        '先着':[int(metrics[position+(0,f[name])]) for name in ('F','A','N','C')],
                        '利益':int(metrics[position+(0,f['profit'])]),'損失':int(metrics[position+(0,f['loss'])])})
        if index%32==0:print(__import__('json').dumps({'独立政策':index,'全対象':len(positions),'経過秒':round(time.monotonic()-begin)},ensure_ascii=False),flush=True)
    assert all(sha(ROOT/path)==digest for path,digest in before.items())
    save(HERE/'旧七十三場の独立確認.json',{'成功':True,'trial':170,'条件SHA256':BOOK_SHA,'Sourceと入力':before,
         '全配列不変式':invariants,'全政策数':4096,'独立再生政策数':len(positions),'支持82は全再生':True,
         '事前主案を再生':True,'層別設計':'主4×階層4×帯倍率2×補完2の64点と期限4×順行倍率4×失速倍率4の64点を、他軸の均等巡回で追加。重複除去。',
         '全要求独立照合数':request_rows,'全取得属性独立照合数':record_rows,'再集計統計セル':financial_cells,
         '前48A適格数':int(eligible.sum()),'A_B_null同体':True,'全幅分布の層別再計算':True,
         '独立oracle金融入力':'known/exit_timeだけで時計を登録し、net/labelは受け取らない。',
         '本監査の追加7成績読取':False,'CSV_JSON変更':False,'元入力変更':False,
         '限界':'全4096は不変式検査。全4096の全取得を独立再生したわけではない。旧73は既使用であり、未見性能を示さない。',
         '経過秒':time.monotonic()-begin})
    save(HERE/'全支持と層別の位置.json',{'成功':True,'rows':results})
    save(HERE/'自然確認の停止.json',{'成功':True,'SourceSHA256':sha(Path(__file__)),
         '検査票SHA256':sha(HERE/'旧七十三場の独立確認.json'),'位置票SHA256':sha(HERE/'全支持と層別の位置.json'),'元入力不変':True})
    print(__import__('json').dumps({'成功':True,'独立再生政策':len(positions),'全支持':82,'検査票SHA256':sha(HERE/'旧七十三場の独立確認.json')},ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
