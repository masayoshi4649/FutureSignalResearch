# 112の独立会計・保存（市場前）

Actorは `Actor停止.json` で固定済み。Python保存は別の所有7ファイルと `会計停止.json` で固定する。旧111保存299・P c39・Actor6503・旧正式資料は変更しない。原板や価格CSVを再走査せず、112 Nativeと当場の正式111 Nativeを再読する。

## 会計と旧対照

`金融の独立検算.py` は停止111の純会計をSHA認証して再用する。全注文・約定・実所有・片側上限10mini・片道税込38.5円・C0/C5・D0/D1・Sourceの部分返済と予約・u/W保存点・保存点DD・最後の残玉予約0を独立計算する。通常幅期待式だけを本名政策のceil5(max200,2A)又はceil5(max400,4A)へ明示対応する。後知りATRの付替えを許さない。

`保存集計の共通部.py` は111の実現正負・平均損益・PF・実保有時間・数量秒・売買別・Source/保護返済別・保存点連結DDの関数をcode同体で再用する。新政策を旧policyへ偽装しない。六政策の真の保護定義をPython側にも明示し、Snapshot.definitionを全値検査する。

旧111対照はS0/W100/B100×4の12冊とSource全JSON。StreamScopeの説明、protection112/protection111の監査型版名、正確な追加definitionだけを分離する。注文・約定・所有・費用・床・時刻・u/W・C/M/P/B・Decision・その他監査fieldは削除しない。Go側の対照件数・許可版差件数も独立結果へ照合する。新W400/P100/P400は旧対照対象外で、真のID・200/400通常幅・M AND Pを保つ。

独立Pは別folderの停止済み純Python監査を接続する。Goを期待値として呼ばない。BeforeSnapshotと全中間純要求点は保存されていないため、exact/boundedの既知限界を継承し、未保存要求点は別計数する。MTMは全実Fillから時点配賦を再構成するが、最初の適格正常原行そのものや全Raw極値の取り落としを別走査で証明したとは呼ばない。

## Root固定と実行

`保存する.py --fixed <絶対要求> --sha256 <SHA> --output <未作成先>`。

要求は `version=1, trial=112, fixed=true, market_native_read_authorized=true, stage=first2/base54/full70`。FileRefは絶対 `path/sha256` とし、`condition/completion/code_stop/P_stop/actor_stop/protection_code` を持つ。`code_stop` は新しい会計停止、`P_stop` は112独立P停止、`actor_stop` はActor停止54dc、`protection_code` はそのP停止の所有物に含まれる実監査Pythonとする。

`scenes` は予定全場順に `{session,native,reference111,history_class,market_path}` を含む。元54は `original54`、追加16は `additional16`。Nativeとreference111の名はともに `<session>.Native.json.gz`。112完了記録からの全24N・旧111全12N・Source同体・原文oracle対照・前後不変を先に確認する。full70は認証済み54成果物のRef再用と追加16再生を区別し、再用Nativeを再生で証明したとは呼ばない。11/09は予定集合に入れない。

## 出力

`結果.json`、`保存会計の確認.json`、`一覧.resources.json`、全24×場数の `.trades.jsonl`。first2は48行、base54は1296行、full70は1680行。0取引も残す。約定資料は書き出した全行を別会計で再読して費用後純額とflatを検査する。HTTP・描画確認は別工程。

CSV用schemaは111同形：`Actor設定/主key/集計/場別/前後不変/会計数`、各金融列 `gross_yen/fee_yen/slip_yen/net_yen/positive_yen/negative_yen/positive_positions/negative_positions/zero_positions/PF/win_rate/average_profit_yen/average_loss_yen/average_profit_loss_ratio`。損失は負値、勝率は同値も含む全完結実玉が分母、分母0はnull。`頻度診断` は実保有秒・数量秒等で、固定5分/15分参加率を作らない。`保護定義/旧111対照` だけを追加する。CSV生成はRootが別途行う。

## 人工と停止

RootがSHA固定したCore手製48冊と旧111対を用い、6主で全会計/P/旧24対照、7種の金融破壊、金額/C/definition/Source偽装拒否、0取引24とnull比率、48Viewer保存再読、予定集合と遅延前fill拒否を検査する。自然FAR生成・市場実績の証明ではない。

```powershell
python -X utf8 会計の人工検査.py
python -X utf8 会計を検査して停止する.py --p-stop <絶対P停止> --p-sha256 <SHA>
```

実市場・Raw・価格CSV・11/09本文読取は0、金融Go再実行なし。研究目標達成・採用はfalseとする。
