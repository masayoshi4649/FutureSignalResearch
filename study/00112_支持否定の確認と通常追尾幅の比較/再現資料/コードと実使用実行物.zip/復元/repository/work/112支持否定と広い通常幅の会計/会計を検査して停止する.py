"""112の独立会計・旧対照・Viewer人工をActorとは別の所有集合で固定する。"""

import argparse
from collections import Counter
import json
from pathlib import Path
import subprocess
import sys

import 保存集計の共通部 as S
import 会計の人工検査 as T


OWN = Path(__file__).resolve().parent
OWNED = ('金融の独立検算.py', '保存集計の共通部.py', '保存の入力ゲート.py', '保存する.py', '会計の人工検査.py', '会計を検査して停止する.py', '会計_README.md')
ACTOR_STOP = '54dc421f0c35cbd5736725955a02fb6cd11f70f3c8a7b646b954722781264006'


def stop(pstop: Path, psha: str) -> dict:
    """機能: Actor/P停止を認証し全手製会計と所有前後不変を別停止へ固定する。

    引数: pstop(Path)、psha(str)は独立P112の明示停止と期待SHA。
    返り値: dictは会計停止Ref。市場Nativeを読まない。
    """
    output = OWN / '会計検査'
    S.need(not output.exists() and not (OWN / '会計停止.json').exists(), '112会計停止は新規先')
    actor_path = OWN / 'Actor停止.json'
    S.equal(S.digest(actor_path), ACTOR_STOP, '112 Actor停止不変')
    S.equal(S.digest(pstop), psha, '112独立P停止SHA')
    actor, pure = S.load(actor_path), S.load(pstop)
    S.need(pure['成功'] is True and pure['市場前'] is True, '112 P市場前成功')
    before = {str(OWN / name): S.digest(OWN / name) for name in OWNED}
    reused = {str(S.A.PREVIOUS_PATH): S.A.PREVIOUS_SHA, str(S.PREVIOUS_PATH): S.PREVIOUS_SHA,
              str(S.A.BASE_PATH) if hasattr(S.A, 'BASE_PATH') else str(S.A.OLD.BASE_PATH): S.A.OLD.BASE_SHA,
              str(actor_path): ACTOR_STOP, str(pstop): psha, str(T.MANIFEST): T.MANIFEST_SHA}
    reused.update(actor['所有コードSHA256'])
    reused.update(pure['所有ファイルSHA256'])
    reused.update({r['path']: r['sha256'] for r in S.load(T.MANIFEST)['Native'].values()})
    S.need(all(S.digest(Path(path)) == expected for path, expected in reused.items()), '112会計再用参照の全現物')
    output.mkdir()
    test = subprocess.run([sys.executable, '-X', 'utf8', str(OWN / '会計の人工検査.py')], cwd=OWN,
                          capture_output=True, text=True, encoding='utf-8', timeout=60)
    log = output / '人工検査.txt'
    log.write_text(test.stdout + test.stderr, encoding='utf-8', newline='\n')
    S.need(test.returncode == 0, '112会計の全人工成功')
    protection = T.protection()
    values, counts = T.fixtures(), Counter()
    for side in ('買い', '売り'):
        result = S.inspect_scene(values[side], values[side + '_111'], protection, artificial=True)
        for checked in result['checked'].values():
            counts.update(checked['protection_counts'].get('counts', {}))
    after = {path: S.digest(Path(path)) for path in before}
    S.equal(after, before, '112会計所有の前後不変')
    S.need(all(S.digest(Path(path)) == expected for path, expected in reused.items()), '112会計再用/Actor/P/旧停止の前後不変')
    evidence = {'試行': 112, '成功': True, '市場前': True, '主人工': 6, 'Core手製会計': 48, '旧111全金融対照': 24,
                'Source全値同体': True, 'P保存点': dict(counts), '0取引24保持': True, 'Viewer48保存再読': True,
                'ログ': {'path': str(log), 'sha256': S.digest(log)}, '所有ファイルSHA256前': before,
                '所有ファイルSHA256後': after, '前後不変': True, '実市場/Raw/価格CSV/11月09日本文': False}
    evidence_path = output / '人工確認.json'
    S.BASE.write_json(evidence_path, evidence)
    record = {'試行': 112, '成功': True, '市場前': True, '所有ファイルSHA256': before, '再用ファイルSHA256': reused,
              'Actor停止': {'path': str(actor_path), 'sha256': ACTOR_STOP}, 'P停止': {'path': str(pstop), 'sha256': psha},
              '人工確認': {'path': str(evidence_path), 'sha256': S.digest(evidence_path)}, '前後不変': True,
              '実市場/Raw/価格CSV/11月09日本文': False, '研究目標達成': False, '採用': False}
    path = OWN / '会計停止.json'
    S.BASE.write_json(path, record)
    return {'成功': True, '停止': {'path': str(path), 'sha256': S.digest(path)}}


def main() -> None:
    """機能: P停止の明示参照だけから112会計の人工固定を呼ぶ。

    引数: CLI p-stop/p-sha256(str)はP停止絶対位置と期待SHA。
    返り値: None。会計停止Refだけを表示する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--p-stop', required=True, type=Path)
    parser.add_argument('--p-sha256', required=True)
    args = parser.parse_args()
    print(json.dumps(stop(args.p_stop.resolve(), args.p_sha256), ensure_ascii=False))


if __name__ == '__main__':
    main()
