"""112の独立保存をRoot固定・全成功・停止codeの認証後だけに制限する。"""

from datetime import date, timedelta
from pathlib import Path
import re

import 保存集計の共通部 as S


def reference(value: dict, before: dict) -> Path:
    """機能: 明示絶対FileRefをSHA認証して前後不変台帳へ結ぶ。

    引数: value(dict)、before(dict)はpath/sha256参照と認証台帳。
    返り値: Pathは認証済み絶対位置。
    """
    S.equal(set(value), {'path', 'sha256'}, '112 FileRef集合')
    path = Path(value['path'])
    S.need(path.is_absolute() and re.fullmatch('[a-f0-9]{64}', value['sha256']) is not None, '112絶対Ref/SHA')
    path = path.resolve()
    S.equal(S.digest(path), value['sha256'], '112明示参照の実物')
    S.need(str(path) not in before or before[str(path)] == value['sha256'], '同位置の指紋衝突')
    before[str(path)] = value['sha256']
    return path


def planned_sessions(stage: str) -> list[str]:
    """機能: 元54と追加16の予定集合を欠落させず列挙する。

    引数: stage(str)はfirst2/base54/full70。
    返り値: list[str]は日付順のDay/Night。11/09を含めない。
    """
    S.need(stage in ('first2', 'base54', 'full70'), '112保存stage')
    end = date(2026, 9, 21) if stage == 'first2' else date(2026, 10, 27) if stage == 'base54' else date(2026, 11, 6)
    current, result = date(2026, 9, 21), []
    while current <= end:
        if current.weekday() < 5:
            result.extend(f'{current.isoformat()}_{kind}' for kind in ('Day', 'Night'))
        current += timedelta(days=1)
    S.equal(len(result), {'first2': 2, 'base54': 54, 'full70': 70}[stage], '112予定全場数')
    return result


def prepare(fixed_path: Path, fixed_sha: str, output: Path) -> tuple:
    """機能: Rootの市場解禁・112成功・保存/P/Actor停止・全Native参照を先に認証する。

    引数: fixed_path/output(Path)、fixed_sha(str)は固定要求・新規先・期待SHA。
    返り値: tupleは場task・指紋台帳・証拠・Pコード参照。Raw本文を読まない。
    """
    S.need(not output.exists(), '112保存先は未作成')
    before = {}
    reference({'path': str(fixed_path), 'sha256': fixed_sha}, before)
    fixed = S.load(fixed_path)
    S.need(fixed['version'] == 1 and fixed['trial'] == 112 and fixed['fixed'] is True
           and fixed['market_native_read_authorized'] is True, '112 Root固定/市場Native解禁')
    expected = planned_sessions(fixed['stage'])
    values = {}
    for name in ('condition', 'completion', 'code_stop', 'P_stop', 'actor_stop'):
        values[name] = S.load(reference(fixed[name], before))
    stopped, pure = values['code_stop'], values['P_stop']
    S.need(stopped['成功'] is True and stopped['市場前'] is True and stopped['試行'] == 112, '112保存器の市場前停止')
    S.equal(stopped['Actor停止'], fixed['actor_stop'], '112 Actor停止結合')
    S.equal(stopped['P停止'], fixed['P_stop'], '112独立P停止結合')
    own = stopped['所有ファイルSHA256']
    required = {'金融の独立検算.py', '保存集計の共通部.py', '保存の入力ゲート.py', '保存する.py', '会計の人工検査.py', '会計を検査して停止する.py', '会計_README.md'}
    S.equal({Path(p).name for p in own}, required, '112保存器の所有集合')
    S.equal({Path(p).parent for p in own}, {Path(__file__).resolve().parent}, '112現在の保存器だけ')
    for path, sha in {**own, **stopped['再用ファイルSHA256']}.items():
        reference({'path': path, 'sha256': sha}, before)
    S.need(pure['成功'] is True and pure['市場前'] is True, '112 P監査の市場前停止')
    for path, sha in pure['所有ファイルSHA256'].items():
        reference({'path': path, 'sha256': sha}, before)
    protection_path = reference(fixed['protection_code'], before)
    S.equal(pure['所有ファイルSHA256'].get(str(protection_path)), fixed['protection_code']['sha256'], '112停止Pの実監査コード')
    actor = values['actor_stop']
    S.need(actor['試行'] == 112 and actor['成功'] is True and actor['市場前'] is True, '112 Actor市場前停止')
    for path, sha in actor['所有コードSHA256'].items():
        reference({'path': path, 'sha256': sha}, before)
    condition, completion = values['condition'], values['completion']
    S.need(condition['trial'] == 112 and condition['fixed'] is True, '112市場事前条件')
    S.equal(condition['actual_configurations'], list(S.A.CONFIGS), '112条件の本名24')
    S.equal(condition['dependency_stops']['actor'], fixed['actor_stop'], '112条件と実Actor停止')
    S.equal(condition['dependency_stops']['pure'], actor['純保護停止'], '112条件と純Go停止')
    for path, sha in condition['code_sha256'].items():
        code = Path(path)
        code = (code if code.is_absolute() else S.ROOT / code).resolve()
        reference({'path': str(code), 'sha256': sha}, before)
        S.equal(completion['before'].get(str(code)), sha, '112金融完了の同code')
    S.need(completion['trial'] == 112 and completion['success'] is True and completion['stage'] == fixed['stage']
           and completion['sessions'] == len(expected) and completion['books'] == 24 * len(expected), '112全24N成功')
    S.equal((completion['reused_sessions'], completion['replayed_sessions']),
            (54, 16) if fixed['stage'] == 'full70' else (0, len(expected)), '112認証再用と新規再生の区別')
    S.equal(completion['condition_sha256'], fixed['condition']['sha256'], '112同市場条件')
    S.need(completion['unchanged'] is True and completion['before'] == completion['after'], '112金融入力code不変')
    S.need(completion['all_reference111_equal'] is True and completion['all_source111_equal'] is True
           and completion['reference111_comparisons'] == 12 * len(expected), '112旧111全12N/Source対照')
    S.need(completion['all_original166_reference_events_equal'] is True and completion['historical_saved_events_equal'] is False
           and completion['all_original_signal_full_json_equal'] is False, '112元oracle/歴史同体の区別')
    S.equal([r['session'] for r in completion['results']], expected, '112金融の全予定場順')
    S.equal([r['session'] for r in fixed['scenes']], expected, '112保存要求の全予定場順')
    tasks = []
    for final, task in zip(completion['results'], fixed['scenes']):
        S.need(final['books'] == 24 and final['S0_comparisons'] == 4 and final['S0_equal'] is True and final['complete'] is True
               and final['open_quantity'] == final['pending_quantity'] == 0, '112場別残/予約0')
        S.need(final['reference111_comparisons'] == 12 and final['reference111_equal'] is True and final['source111_equal'] is True,
               '112場別旧111対照')
        S.equal(task['native'], final['native'], '112完了のNative参照')
        S.equal(task['reference111'], final['reference111'], '112完了の正式111参照')
        sid = task['session']
        native, prior = reference(task['native'], before), reference(task['reference111'], before)
        S.need(native.name == prior.name == sid + '.Native.json.gz', '112/111の同場Native本名')
        S.equal(task['history_class'], 'original54' if sid[:10] <= '2026-10-27' else 'additional16', '112元54/追加16')
        S.need(isinstance(task['market_path'], str) and task['market_path'], '112価格の参照文字列')
        tasks.append({**task, 'resolved_native': native, 'resolved_reference111': prior})
    proofs = {'stage': fixed['stage'], 'Root保存要求SHA256': fixed_sha, '金融条件SHA256': fixed['condition']['sha256'],
              '金融完了SHA256': fixed['completion']['sha256'], '保存器停止SHA256': fixed['code_stop']['sha256'],
              '独立P停止SHA256': fixed['P_stop']['sha256'], 'Actor停止SHA256': fixed['actor_stop']['sha256']}
    return tasks, before, proofs, protection_path
