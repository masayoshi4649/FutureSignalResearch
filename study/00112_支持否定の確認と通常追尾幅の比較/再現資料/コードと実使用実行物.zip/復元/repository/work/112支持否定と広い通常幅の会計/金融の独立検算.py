"""停止111の純会計を再用し、112の本名通常幅だけを独立算術へ接続する。"""

import ast
import hashlib
import importlib.util
import inspect
import math
from pathlib import Path
import textwrap


ROOT = Path(__file__).resolve().parents[2]
PREVIOUS_PATH = ROOT / 'work/111連続保護の独立保存/会計の独立検算.py'
PREVIOUS_SHA = '4c5f72dbbb31209c673b77f5171b73129a9a684951fc8c75361c601f7cc14e08'
if hashlib.sha256(PREVIOUS_PATH.read_bytes()).hexdigest() != PREVIOUS_SHA:
    raise ValueError('停止111会計の実物SHA差')
SPEC = importlib.util.spec_from_file_location('112が再用する停止111会計', PREVIOUS_PATH)
OLD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(OLD)
BASE, need, equal, number, money = OLD.BASE, OLD.need, OLD.equal, OLD.number, OLD.money
CONFIGS = tuple({'policy': p, 'slip_pts': c, 'delay_seconds': d}
                for p in ('S0', 'W100', 'B100', 'W400', 'P100', 'P400') for c in (0, 5) for d in (0, 1))


def key_for(config: dict) -> str:
    """機能: 112の本名24設定から口座識別子を作る。

    引数: config(dict)はpolicy/slip_pts/delay_seconds。
    返り値: strは本名key。不正条件はValueError。
    """
    need(config in CONFIGS and set(config) == {'policy', 'slip_pts', 'delay_seconds'}, '112の宣言外設定')
    return f"{config['policy']}_C{config['slip_pts']}_D{config['delay_seconds']}"


BY_KEY = {key_for(c): c for c in CONFIGS}
KEYS = tuple(BY_KEY)


def normal_width(policy: str, atr) -> int:
    """機能: 112の通常幅を政策本名からIEEE64の元式どおり独立計算する。

    引数: policy(str)、atr(number)は政策と取得時ATR。
    返り値: intはceil5(max200,2A)又はceil5(max400,4A)。
    """
    need(policy in ('W100', 'B100', 'W400', 'P100', 'P400'), '通常幅の本名政策')
    minimum, multiplier = (400, 4) if policy in ('W400', 'P400') else (200, 2)
    return 5 * math.ceil(max(minimum, multiplier * float(atr)) / 5)


def marks_function():
    """機能: 停止111のMTM検算から幅期待式一つだけを本名112へ接続する。

    引数: なし。
    返り値: functionは所有/u/W/保存点/ATR時計を同体再用する。保護判定は別P監査。
    """
    tree = ast.parse(textwrap.dedent(inspect.getsource(OLD.verify_marks)))
    matches = [node for node in ast.walk(tree) if isinstance(node, ast.Call)
               and ast.unparse(node) == "equal(atr['width'], 5 * math.ceil(max(200, 2 * float(atr['value'])) / 5), '取得時通常幅')"]
    equal(len(matches), 1, '旧111の通常幅期待式は一つ')
    matches[0].args[1] = ast.parse("normal_width(policy, atr['value'])", mode='eval').body
    space = {**vars(OLD), 'normal_width': normal_width, '__file__': __file__}
    exec(compile(ast.fix_missing_locations(tree), __file__ + ':停止111保存MTM', 'exec'), space)
    return space['verify_marks']


VERIFY_MARKS = marks_function()


def accounting_function():
    """機能: 既存の政策非依存AST会計器へ新しい幅検算だけを注入する。

    引数: なし。
    返り値: functionは全注文/約定/費用/Source部分配賦/保存DDを再読する。
    """
    tree = ast.parse(textwrap.dedent(inspect.getsource(OLD.accounting_function)))
    space = {**vars(OLD), 'verify_marks': VERIFY_MARKS, '__file__': __file__}
    exec(compile(ast.fix_missing_locations(tree), __file__ + ':停止111純会計作成', 'exec'), space)
    return space['accounting_function']()


PURE_ACCOUNTING = accounting_function()


def verify_finance(book: dict, config: dict) -> dict:
    """機能: 112の全金融台帳を本名設定と純算術だけで独立検査する。

    引数: book/config(dict)は原値の実口座と112設定。
    返り値: dictはtotals/counts/orders/positions/timeline/book。原値を変えない。
    """
    equal(book['key'], key_for(config), '112本名key')
    equal(book['config'], config, '112本名設定')
    before = repr(book)
    finance = PURE_ACCOUNTING(book, config, config['policy'])
    OLD.verify_source_reservations(book, finance)
    for event in book['source_events']:
        need(type(event['side']) is int and event['side'] in (-1, 1), '112元通知の方向型')
        if event['order_id']:
            equal(event['side'], finance['orders'][event['order_id']]['side'], '112元通知と実注文の方向')
    for fill in book['fills']:
        order = finance['orders'][fill['order_id']]
        need(fill['quote']['source_line'] > order['request_quote']['source_line'], '112の要求後物理行')
    equal(book['metrics']['timer_calls'], 0, '112研究側timerなし')
    if config['policy'] != 'S0':
        fallback = sum(p['atr'] is None for p in book['positions'])
        equal(book['metrics'].get('atr_unknown_fallback_positions', 0), fallback, '112未知ATRの固定fallback数')
        finance['counts']['atr_unknown_fallback_positions'] = fallback
    equal(repr(book), before, '112金融原値不変')
    return {**finance, 'book': book}
