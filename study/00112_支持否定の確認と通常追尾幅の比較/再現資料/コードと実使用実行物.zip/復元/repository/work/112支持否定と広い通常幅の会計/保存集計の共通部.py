"""112の金融集計と旧111全金融対照を、Goを呼ばない保存台帳の算術で扱う。"""

from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from types import FunctionType

import 金融の独立検算 as A


ROOT = Path(__file__).resolve().parents[2]
PREVIOUS_PATH = ROOT / 'work/111連続保護の独立保存/集計.py'
PREVIOUS_SHA = 'c6e6df9067da9452a978881325f3e96a677d946e3e5643eb3614d41684d0dbc0'
if hashlib.sha256(PREVIOUS_PATH.read_bytes()).hexdigest() != PREVIOUS_SHA:
    raise ValueError('停止111保存集計の実物SHA差')
SPEC = importlib.util.spec_from_file_location('112が再用する停止111保存集計', PREVIOUS_PATH)
OLD = importlib.util.module_from_spec(SPEC)
sys.path.insert(0, str(PREVIOUS_PATH.parent))
try:
    SPEC.loader.exec_module(OLD)
finally:
    sys.path.pop(0)
BASE, need, equal = A.BASE, A.need, A.equal
KEYS, BY_KEY = A.KEYS, A.BY_KEY
SPACE = {**vars(OLD), 'A': A, 'KEYS': KEYS, 'BY_KEY': BY_KEY}


def borrow(name: str):
    """機能: 固定111の政策非依存関数をcode同体で新しい本名環境へ結ぶ。

    引数: name(str)は事前に指定する金融集計又は保存再読関数名。
    返り値: functionは元codeと返り値仕様を維持した関数。
    """
    original = getattr(OLD, name)
    result = FunctionType(original.__code__, SPACE, name, original.__defaults__, original.__closure__)
    result.__kwdefaults__ = original.__kwdefaults__
    SPACE[name] = result
    return result


digest, load = OLD.digest, OLD.load
profit_statistics = borrow('profit_statistics')
holding_diagnostics = borrow('holding_diagnostics')
summarize_book = borrow('summarize_book')
combine = borrow('combine')
source_projection = borrow('source_projection')
verify_source = borrow('verify_source')
verify_viewer = borrow('verify_viewer')


def definition(policy: str) -> dict:
    """機能: 112の説明定義を研究条件の明示表から独立構築する。

    引数: policy(str)は本名六政策。
    返り値: dictは版・起動・幅・警戒・技術狭幅の全定義。Goを呼ばない。
    """
    need(policy in ('S0', 'W100', 'B100', 'W400', 'P100', 'P400'), '112定義の本名政策')
    result = {'version': 112, 'policy': policy, 'enabled': policy != 'S0', 'threshold_points': 100,
              'normal_width_minimum': 200, 'atr_multiplier': 2, 'warning_formula': 'M AND(C OR P)', 'technical_narrowing': False}
    if policy == 'S0':
        result.update(threshold_points=0, normal_width_minimum=0, atr_multiplier=0, warning_formula='追加保護なし')
    if policy in ('W400', 'P400'):
        result.update(normal_width_minimum=400, atr_multiplier=4)
    if policy == 'B100':
        result.update(warning_formula='M AND(C OR B OR P)', technical_narrowing=True)
    if policy in ('P100', 'P400'):
        result.update(warning_formula='M AND P', technical_narrowing=True)
    return result


def separate_definition(value, expected: dict) -> int:
    """機能: 新Snapshotの追加定義だけを厳密照合後に分離する。

    引数: value(any)、expected(dict)は独立copyしたJSON部分木と明示定義。
    返り値: intは分離Snapshot数。C/M/P/Bや金額は変更しない。
    """
    count = 0
    if isinstance(value, list):
        for child in value:
            count += separate_definition(child, expected)
    elif isinstance(value, dict):
        if 'definition' in value:
            need('entry' in value and 'normal_width' in value, '純Snapshot以外の定義分離を禁止')
            equal(value['definition'], expected, '112の真の幅/警戒定義')
            del value['definition']
            count += 1
        for child in value.values():
            count += separate_definition(child, expected)
    return count


def compare_reference111(value: dict, prior: dict) -> dict:
    """機能: 112の共通12冊とSource全値を旧111保存Nativeへ独立照合する。

    引数: value/prior(dict)は112 Nativeと認証済み旧111 Native。
    返り値: dictは12全金融JSON対照と許可版差の件数。完結性は別検査。
    """
    need(value['trial'] == 112 and prior['actual']['trial'] == 111, '112/111の明示版')
    equal(value['source'], prior['source'], '元Source111の全JSON同体')
    equal(value['actual']['scope'], prior['actual']['scope'], '112/111の場・限月・設定')
    details = {}
    for key in (k for k in KEYS if BY_KEY[k]['policy'] in ('S0', 'W100', 'B100')):
        left = deepcopy(value['actual']['books'][key])
        right = deepcopy(prior['actual']['books'][key])
        policy = BY_KEY[key]['policy']
        equal(left['config'], BY_KEY[key], '共通12の新本名設定')
        equal(right['config'], BY_KEY[key], '共通12の旧本名設定')
        need(left['stream_scope'].startswith('112:') and right['stream_scope'].startswith('111:'), '版付き説明Scope')
        changed = left['stream_scope'] != right['stream_scope']
        left['stream_scope'] = right['stream_scope'] = ''
        renamed = 0
        for position in left['positions']:
            need('protection111' not in position, '112へ旧監査field混入なし')
            if 'protection112' in position:
                position['protection111'] = position.pop('protection112')
                renamed += 1
        separated = separate_definition(left, definition(policy))
        equal(left, right, '112/111の旧3政策全金融JSON.' + key)
        details[key] = {'policy': policy, 'stream_scope_difference': changed, 'audit_field_renames': renamed,
                        'definition_snapshots': separated, 'all_financial_equal': True}
    need(len(details) == 12, '旧3政策×4対照')
    trace = value['reference111']
    need(trace['comparisons'] == 12 and trace['all_financial_equal'] is True and trace['source_equal'] is True, 'Core旧111対照成功')
    equal(trace['details'], details, 'Goの対照版差件数とPython全値照合')
    return {'comparisons': 12, 'all_financial_equal': True, 'source_equal': True, 'details': details}


def inspect_scene(value: dict, prior: dict, protection, artificial: bool = False) -> dict:
    """機能: 112全24金融と独立P監査・元Source・旧12対照を結合する。

    引数: value/prior(dict)、protection(module)、artificial(bool)は112/111 Native・停止P・手製Source区分。
    返り値: dictはchecked/source/reference111。金融再生・原板再走査はしない。
    """
    actual = value['actual']
    need(value['version'] == 1 and value['trial'] == 112 and actual['version'] == 1 and actual['trial'] == 112
         and actual['complete'] is True, '112全24の完結Native')
    equal(actual['configurations'], list(A.CONFIGS), '112本名24設定と順序')
    equal(set(actual['books']), set(KEYS), '112全24冊集合')
    equal(actual['entry_grid_seconds'], None, '112の研究側新規時計なし')
    equal(actual['extra_opening_quiet_seconds'], 0, '112の研究側開始静観なし')
    equal(actual['explicit_timers'], 0, '112研究側timerなし')
    equal(actual['chart_seed_mode'], 'cold_each_session', '112当場cold')
    equal(actual['scope']['session'], value['source']['session'], '112のSource場')
    equal(actual['scope']['contract'], value['source']['contract'], '112のSource限月')
    equal(actual['counts']['publications'], len(actual['publications'] or []), '112公開数')
    equal(actual['counts']['resets'], len(actual['resets'] or []), '112reset数')
    context = {k: actual[k] for k in ('scope', 'publications', 'resets', 'counts', 'final_chart')}
    checked = {}
    for key, config in BY_KEY.items():
        book = actual['books'][key]
        equal(book['session'], actual['scope']['session'], '112全24の同場')
        equal(book['metrics']['rows'], actual['counts']['rows'], '112全24の原行数')
        equal(book['metrics']['bad_quote_rows'], actual['counts']['bad_quotes'], '112全24の欠気配数')
        finance = A.verify_finance(book, config)
        finance['protection_counts'] = protection.verify_protection(book, config, finance, context)
        checked[key] = finance
    return {'checked': checked, 'source': verify_source(value, artificial=artificial), 'reference111': compare_reference111(value, prior)}


def save_viewer(value: dict, output: Path, market_path: str) -> list[dict]:
    """機能: 本名112の全24実約定をViewer schema1へ新規保存する。

    引数: value(dict)、output(Path)、market_path(str)は検算済み112・新規先・価格参照。
    返り値: list[dict]は0約定を含む24資源。価格本文やHTTPを読まない。
    """
    resources = []
    sid = value['actual']['scope']['session']['id']
    for key in KEYS:
        name = f'112_{key}_{sid}.trades.jsonl'
        with (output / name).open('x', encoding='utf-8', newline='\n') as stream:
            for row in BASE.viewer_trades(value['actual']['books'][key]):
                stream.write(json.dumps(row, ensure_ascii=False, default=BASE.serial, allow_nan=False) + '\n')
        resources.append({'id': f'112_{key}_{sid}', 'title': f'支持否定と広い通常幅 {key} {sid}',
                          'symbol': 'NK225', 'product': 'NK225mini', 'session': sid, 'method_id': key,
                          'point_value': 100, 'pnl_format': 'trades', 'pnl_basis': 'net', 'pnl_path': name, 'market_path': market_path})
    return resources
