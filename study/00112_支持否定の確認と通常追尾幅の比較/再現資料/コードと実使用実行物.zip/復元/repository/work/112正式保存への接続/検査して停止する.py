"""112正式保存の差分人工を実行し、旧ownedとは別に所有4ファイルを固定する。"""

import argparse
from pathlib import Path
import subprocess
import sys
import json

import 正式保存する as F
import 人工検査 as T


def stop(output: Path) -> dict:
    """機能: 非市場の保存人工と所有・既存共通コードの前後不変を固定する。

    引数: output(Path)は未作成の検査先。
    返り値: dictは112正式保存停止Ref。市場/Raw/実CSVを読まない。
    """
    F.need(not output.exists(), '112正式保存の証拠は新規')
    owned = {str(F.OWN / n): F.sha(F.OWN / n) for n in ('正式保存する.py', '人工検査.py', '検査して停止する.py', 'README.md')}
    reused = {str(F.PREVIOUS_PATH): F.PREVIOUS_SHA, str(T.FIXTURE_PATH): T.FIXTURE_SHA,
              str(F.C.LEGACY_PATH): F.C.LEGACY_SHA, str(F.C.ZIP_PATH): F.C.ZIP_SHA,
              str(F.ROOT / 'work/109再現コードの準備/ZIPを正式保存する.py'): 'cb263d54b70bbb6ca94d227736fce98748a623d014924b960660039d8f98eae2'}
    protected = {
        'work/112支持否定と広い通常幅の会計/Actor停止.json': '54dc421f0c35cbd5736725955a02fb6cd11f70f3c8a7b646b954722781264006',
        'work/112支持否定と広い通常幅の会計/会計停止.json': '7408e520143de90b77e5368f9a3f22f235f4555e34f026b306902fb1cae820f8',
        'work/112支持否定と通常幅の独立P監査/P停止.json': 'c873e82630e647b9731e013e8be2786424818248503ec6765e797e49ef430048'}
    for relative, expected in protected.items():
        path = F.ROOT / relative
        F.need(F.sha(path) == expected, '既停止112のSHA不変')
        reused[str(path)] = expected
        value = F.read({'path': str(path), 'sha256': expected}, {})
        reused.update(value.get('所有コードSHA256', {}))
        reused.update(value.get('所有ファイルSHA256', {}))
    F.need(all(F.sha(Path(p)) == h for p, h in reused.items()), '112正式保存の再用元実物')
    output.mkdir()
    test = subprocess.run([sys.executable, '-X', 'utf8', str(F.OWN / '人工検査.py')], cwd=F.OWN,
                          capture_output=True, text=True, encoding='utf-8', timeout=60)
    log = output / '人工検査.txt'
    log.write_text(test.stdout + test.stderr, encoding='utf-8', newline='\n')
    F.need(test.returncode == 0, '112正式保存人工の全成功')
    F.need(all(F.sha(Path(p)) == h for p, h in {**owned, **reused}.items()), '112正式保存の所有/旧コード前後不変')
    evidence = {'試行': 112, '成功': True, '市場前': True, '主人工': 3,
                '器具': '停止111の手製70場/空約定1680を112schemaへ適応。仮Native・仮旧ZIP・仮CSV成功metadataのみ。',
                '旧111同体コード参照化': True, '新ZIP全SHA/CRC/安全集合': True, 'CSV本文非複写': True,
                'CSV第三算術検査': False, '破壊/不成功/欠落/遡り/既存先拒否': True, '前後不変': True, 'ログ': F.ref(log),
                '実市場/Raw/価格CSV/実CSV/11月09日本文': False}
    proof = output / '人工確認.json'
    F.write_json(proof, evidence)
    record = {'試行': 112, '成功': True, '市場前': True, '所有ファイルSHA256': owned, '再用ファイルSHA256': reused,
              '人工確認': F.ref(proof), '前後不変': True, '実市場/Raw/価格CSV/実CSV/11月09日本文': False,
              '研究目標達成': False, '採用': False}
    path = output / '停止.json'
    F.write_json(path, record)
    return {'成功': True, '停止': F.ref(path)}


def main() -> None:
    """機能: 未作成先へ112正式保存器の市場前停止を作る。

    引数: CLI output(str)は新規証拠先。
    返り値: None。停止Refだけを表示する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(stop(args.output.resolve()), ensure_ascii=False))


if __name__ == '__main__':
    main()
