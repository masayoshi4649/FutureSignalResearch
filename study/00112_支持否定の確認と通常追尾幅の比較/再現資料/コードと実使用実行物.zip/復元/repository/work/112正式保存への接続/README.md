# 112の正式保存への接続（市場前）

Rootの112全70成功と独立会計成功後にだけ、新しい正本を同bytes保存する。既正式111のSource・chart・純戦略等は元path/SHAを照合して既存ZIP又は正式metadata所在へ結び、本文や旧ZIPを再複製しない。Actor停止54dc、会計停止7408、P停止c873、旧111は不変とする。

## Root要求

`正式保存する.py --request <絶対要求JSON> --request-sha <期待SHA>`。

要求は `version=1,trial=112,fixed=true,stage=full70,market_native_read_authorized=true`。

- `refs` 必須：`condition,market,result,saved_check,core_stop,actor_stop,pure_stop,save_stop,P_stop,formal_stop,legacy111_index,legacy111_zip,legacy111_formal_save,csv_check,same_entry_code,same_entry_request`。絶対FileRefとする。
- `legacy111_index/zip/formal_save` は既正式111のコード所在索引・ZIP・正式保存確認の同じ組。原文oracle54、Source/chart、共有入力の既存根拠へ辿るために保持する。
- `same_entry_code` はRootの40対照を行う薄いPython、`same_entry_request` はそのRoot要求。新しい比較停止は要求しない。比較結果と準備の拒否検査は `extra_refs` で保存する。
- `csv_refs` は `候補別集計.csv/全セッション.csv` のFileRef二点。outputsが唯一正本で、本器はコピーしない。`csv_check` はRootの既存標準csv/Decimal独立再読成功を使う。
- `csv_check` は成功true/試行112/場別行数1680/候補数24/数値比較数正/全場累計再計算true/未定義比率は空欄true/前後不変true/入力SHA256=後SHA256/Raw読取0/金融再実行false。入力SHA256の結果と二CSVの絶対pathを各Refへ照合する。第三の算術読取器や人工CSVは追加しない。
- `go_environment:{version:"go1.24.2",root:<絶対GoRoot>}` と `restore_roots` は111と同じ形。repository根とmodule_cache根、必要な外部コード根を明示する。
- `code_refs:[{ref,role}]` は新Rootコード・必要な追加依存。`extra_refs:[{ref,target,role}]` は診断・成功記録・文書。targetは `診断/検査/再現資料` 内の新規相対先。CSV本体は受け付けない。

## 保存するもの

正式先は `study/00112_支持否定の確認と通常追尾幅の比較/`。

- `成果物/`：独立結果・保存検算・一覧・全1680約定ファイル。0取引も保持する。
- `成果物_金融/Native/`：112の全70Native。元54成功のRef再用と追加16再生を区別し、一度ずつ同bytesで保存する。各場の正式111 Nativeは参照だけで再複製しない。
- `検査/`：112条件・市場成功・停止・Root要求・CSV再読成功・正式保存確認等。
- `再現資料/`：新コード/実使用exeだけのZIP、元pathと復元先を持つコード所在索引、既正式111/共有入力参照、CSV二点の所在、再現手順。
- Rootが明示した同入口40対照等の後段診断。Root完了記録・Viewer追加検査は後段の別資料でよい。

旧111保存器81faの安全な参照・コピーと既存109/110のZIP三関数を再用する。コード収集は111と同体で、112が実行しない旧oracle実行物の自動同梱tupleだけをASTで一箇所外す。旧oracleは既正式111参照へ残る。新実exeはcondition.executableを保存する。

コードは元pathで重複排除し、同SHA・同容量の既正式111 ZIP entry又は正式metadataがあれば参照へ分離する。pathが新しくても同bytesのコードは旧entryから新しいrestore位置へ復元できるよう記録する。新ZIPは全entry SHA/CRC/サイズ/安全名/集合を照合する。GoRoot本文は索引のみで、Go1.24.2と実選択標準Goの全SHAが同じ環境が別途必要。

## 準備検査

手製metadata・仮Native・空約定と仮の既正式111 ZIPだけを使い、112正本保存・旧部品の参照化・新ZIP・CSV非複製・破壊拒否を人工検査する。市場結果や実CSVはRoot要求固定前に読まない。原板/価格CSV本文、金融再実行、11/09本文は0。採用・研究目標達成はfalse。

```powershell
python -X utf8 人工検査.py
python -X utf8 検査して停止する.py --output <未作成の証拠先>
```
