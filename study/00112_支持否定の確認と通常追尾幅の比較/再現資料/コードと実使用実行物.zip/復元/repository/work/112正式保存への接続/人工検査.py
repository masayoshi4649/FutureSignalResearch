"""112正式保存の差分だけを、停止111の手製fixtureを適応して検査する。"""

from copy import deepcopy
import importlib.util
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import zipfile

import 正式保存する as F


FIXTURE_PATH = F.ROOT / 'work/111正式保存への接続/人工検査.py'
FIXTURE_SHA = 'ff8f68906fa8cabdc97a371095025bb7c2da95bc8fcc08365ba8def87bbcd78b'


def make_fixture(base: Path) -> dict:
    """機能: 停止111の70場器具を112の参照schemaへ適応する。

    引数: base(Path)は新規一時領域。
    返り値: dictは仮正式先・Root仮要求。実市場・実CSVは使わない。
    """
    F.need(F.sha(FIXTURE_PATH) == FIXTURE_SHA, '停止111の手製fixture SHA')
    spec = importlib.util.spec_from_file_location('112が使う停止111人工器具', FIXTURE_PATH)
    old = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(old)
    old.F = SimpleNamespace(ROOT=F.ROOT, OWN=F.OWN, sha=F.sha, ref=F.ref, write_json=F.write_json,
                            CONFIGS=F.CONFIGS, KEYS=F.KEYS, sessions=F.C.sessions)
    fixture = old.make_fixture(base)
    request, source = fixture['request'], fixture['source']

    def put(name: str, value: dict) -> dict:
        """機能: 明示人工metadataを新規保存してFileRefを得る。

        引数: name(str)、value(dict)は手製名と本文。
        返り値: dictは人工Ref。
        """
        path = source / name
        F.write_json(path, value)
        return F.ref(path)

    refs = request['refs']
    condition = deepcopy(fixture['values']['condition'])
    condition.update(trial=112, reference111={'condition': {'人工': True}, 'market': {'人工': True}, 'native_catalog': {'人工': True}})
    condition.pop('oracle_executable')
    refs['condition'] = put('condition112.json', condition)
    market = deepcopy(fixture['values']['market'])
    market.update(trial=112, condition_sha256=refs['condition']['sha256'], reference111_comparisons=840,
                  all_reference111_equal=True, all_source111_equal=True)
    prior_folder = source / '仮正式111Native'
    prior_folder.mkdir()
    for row in market['results']:
        path = prior_folder / (row['session'] + '.Native.json.gz')
        path.write_bytes(('旧111を複写しない仮参照' + row['session']).encode())
        row.update(reference111=F.ref(path), reference111_comparisons=12, reference111_equal=True, source111_equal=True)
    refs['market'] = put('market112.json', market)
    refs['save_stop'] = put('save_stop112.json', {'成功': True, '市場前': True, 'Actor停止': refs['actor_stop'], 'P停止': refs['P_stop'], '所有ファイルSHA256': {}})
    result = deepcopy(fixture['values']['result'])
    result.update(試行=112, 金融条件SHA256=refs['condition']['sha256'], 金融完了SHA256=refs['market']['sha256'],
                  Actor停止SHA256=refs['actor_stop']['sha256'], 保存器停止SHA256=refs['save_stop']['sha256'], 独立P停止SHA256=refs['P_stop']['sha256'],
                  旧111対照=[{'session': r['session'], 'comparisons': 12, 'all_financial_equal': True} for r in market['results']])
    for row, completed in zip(result['Native参照'], market['results']):
        row['reference111'] = completed['reference111']
    saved_dir = Path(refs['result']['path']).parent
    catalog_path = saved_dir / '一覧.resources.json'
    catalog = F.read(F.ref(catalog_path), {})
    output_sha = {}
    for resource in catalog['resources']:
        old_name = resource['pnl_path']
        new_name = old_name.replace('111_', '112_', 1)
        (saved_dir / old_name).rename(saved_dir / new_name)
        resource['id'] = resource['id'].replace('111_', '112_', 1)
        resource['pnl_path'] = new_name
        output_sha[new_name] = F.sha(saved_dir / new_name)
    catalog_path.unlink()
    F.write_json(catalog_path, catalog)
    output_sha[catalog_path.name] = F.sha(catalog_path)
    result_path = saved_dir / '結果112.json'
    F.write_json(result_path, result)
    # 正本名だけを同bytesで置き換える操作も人工領域内に限定します。
    (saved_dir / '結果.json').unlink()
    result_path.rename(saved_dir / '結果.json')
    refs['result'] = F.ref(saved_dir / '結果.json')
    output_sha['結果.json'] = refs['result']['sha256']
    saved = deepcopy(fixture['values']['saved_check'])
    saved.update(試行=112, 金融条件SHA256=refs['condition']['sha256'], 金融完了SHA256=refs['market']['sha256'],
                 旧111全金融比較=840, 全Source111同体=True, 出力SHA256=output_sha)
    refs['saved_check'] = put('saved_check112.json', saved)
    # ----------------------------------------
    # 仮の既正式111 ZIPを作り、旧コードを新ZIPから分離する経路を試します。
    legacy_root = source / '既正式111'
    (legacy_root / '再現資料').mkdir(parents=True)
    (legacy_root / '検査').mkdir()
    prior_sources = [fixture['custom'], F.PREVIOUS_PATH, F.C.LEGACY_PATH, F.C.ZIP_PATH,
                     F.ROOT / 'work/109再現コードの準備/ZIPを正式保存する.py']
    legacy_rows = [{'original_path': str(p), 'sha256': F.sha(p), 'bytes': p.stat().st_size,
                    'kind': 'コードと宣言', 'roles': ['手製旧コード'],
                    'restore': {'root': 'repository', 'relative': p.relative_to(F.ROOT).as_posix()},
                    'location': {'kind': 'このZIP', 'entry': f'legacy/{i}_{p.name}'}} for i, p in enumerate(prior_sources)]
    legacy_zip = legacy_root / '再現資料/コードと実使用実行物.zip'
    F.Z.write_zip(legacy_zip, legacy_rows)
    refs['legacy111_zip'] = F.ref(legacy_zip)
    legacy_index = legacy_root / '再現資料/コード所在索引.json'
    F.write_json(legacy_index, {'試行': 111, '成功': True, 'ZIP': refs['legacy111_zip'], 'entries': legacy_rows})
    refs['legacy111_index'] = F.ref(legacy_index)
    legacy_save = legacy_root / '検査/正式保存の確認.json'
    F.write_json(legacy_save, {'試行': 111, '成功': True, 'ZIP': refs['legacy111_zip'], 'コード所在索引': refs['legacy111_index'], '前後不変': True})
    refs['legacy111_formal_save'] = F.ref(legacy_save)
    same_code = source / '同入口の手製コード.py'
    same_code.write_text('# 実行しない手製比較器\n', encoding='utf-8')
    refs['same_entry_code'] = F.ref(same_code)
    refs['same_entry_request'] = put('同入口要求.json', {'試行': 112, '人工': True})
    outputs = source / 'outputs'
    outputs.mkdir()
    csv_refs = {}
    for name in ('候補別集計.csv', '全セッション.csv'):
        path = outputs / name
        path.write_bytes(b'not-real-csv\n')
        csv_refs[name] = F.ref(path)
    hashes = {refs['result']['path']: refs['result']['sha256'], **{r['path']: r['sha256'] for r in csv_refs.values()}}
    refs['csv_check'] = put('Root仮CSV再読成功.json', {'成功': True, '試行': 112, '場別行数': 1680, '候補数': 24, '数値比較数': 1,
                                                  '全場累計再計算': True, '未定義比率は空欄': True, '前後不変': True,
                                                  '入力SHA256': hashes, '後SHA256': hashes, 'Raw読取': 0, '金融再実行': False})
    request.update(trial=112, refs={name: refs[name] for name in F.REQUIRED}, csv_refs=csv_refs, extra_refs=[])
    request_ref = put('正式要求112.json', request)
    # 保存検算は結果と同folderという正式契約を人工でも保ちます。
    check_path = saved_dir / '保存会計の確認112.json'
    F.write_json(check_path, saved)
    request['refs']['saved_check'] = F.ref(check_path)
    request_ref = put('正式要求112_確定.json', request)
    return {**fixture, 'ref': request_ref, 'request': request, 'outputs': outputs, 'legacy_root': legacy_root}


class Formal112Tests(unittest.TestCase):
    """112同bytes保存と旧111参照化だけを検査する。"""

    def setUp(self) -> None:
        """機能: repo内の一時人工領域を準備する。

        引数: self(Formal112Tests)は検査器。
        返り値: None。
        """
        self.tmp = tempfile.TemporaryDirectory(prefix='112正式人工_', dir=F.OWN)
        self.root = Path(self.tmp.name)

    def tearDown(self) -> None:
        """機能: 標準の一時管理で人工領域だけを片付ける。

        引数: self(Formal112Tests)は検査器。
        返り値: None。
        """
        self.tmp.cleanup()

    def test_full_save_and_reference_only(self) -> None:
        """機能: 70Native/1680資源を保存し、旧111 ZIPとCSVの非複製を確認する。

        引数: self(Formal112Tests)は検査器。
        返り値: None。仮CSV成功metadataを使いCSV算術を再検査しない。
        """
        fixture = make_fixture(self.root / '成功')
        with patch.object(F, 'TRIAL', fixture['trial']), patch.object(F, 'OUTPUTS', fixture['outputs']):
            result = F.execute(fixture['ref'])
            proof, index = F.read(result['確認'], {}), F.read(result['索引'], {})
            self.assertEqual(proof['Native数'], 70)
            self.assertEqual(len(list((fixture['trial'] / '成果物').glob('*.trades.jsonl'))), 1680)
            self.assertGreaterEqual(index['既正式111参照数'], 5)
            self.assertFalse(list(fixture['trial'].rglob('*.csv')))
            self.assertEqual(len(list(fixture['trial'].rglob('*.zip'))), 1)
            with zipfile.ZipFile(result['ZIP']['path']) as archive:
                self.assertIsNone(archive.testzip())
                self.assertTrue(all('仮GoRoot' not in n for n in archive.namelist()))
            self.assertTrue(proof['前後不変'])
            with self.assertRaises(ValueError):
                F.execute(fixture['ref'])

    def test_native_and_csv_sha_corruption_rejected(self) -> None:
        """機能: 仮Native又は唯一正本CSVの変更を正式書込み前に拒否する。

        引数: self(Formal112Tests)は検査器。
        返り値: None。
        """
        for kind in ('Native', 'CSV'):
            fixture = make_fixture(self.root / kind)
            target = Path(fixture['request']['csv_refs']['全セッション.csv']['path']) if kind == 'CSV' else Path(F.read(fixture['request']['refs']['market'], {})['results'][0]['native']['path'])
            target.write_bytes(b'changed')
            with patch.object(F, 'TRIAL', fixture['trial']), patch.object(F, 'OUTPUTS', fixture['outputs']), self.assertRaises(ValueError):
                F.prepare(fixture['ref'])
            self.assertFalse(fixture['trial'].exists())

    def test_missing_success_and_unsafe_extra_rejected(self) -> None:
        """機能: 不成功の市場、旧12欠落、遡り保存先を拒否する。

        引数: self(Formal112Tests)は検査器。
        返り値: None。
        """
        fixture = make_fixture(self.root / '拒否')
        values = {n: F.read(r, {}) for n, r in fixture['request']['refs'].items() if n not in ('same_entry_code', 'legacy111_zip')}
        for kind in ('failed', 'old12', 'source', 'zip'):
            copy = deepcopy(values)
            if kind == 'failed':
                copy['market']['success'] = False
            elif kind == 'old12':
                copy['market']['reference111_comparisons'] -= 1
            elif kind == 'source':
                copy['market']['all_source111_equal'] = False
            else:
                copy['legacy111_index']['ZIP']['sha256'] = '0' * 64
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                F.validate(copy, fixture['request'])
        bad = deepcopy(fixture['request'])
        bad['extra_refs'] = [{'ref': bad['refs']['same_entry_request'], 'target': '診断/../../外部.json', 'role': '拒否人工'}]
        path = fixture['source'] / 'badextra.json'
        F.write_json(path, bad)
        with patch.object(F, 'TRIAL', fixture['trial']), patch.object(F, 'OUTPUTS', fixture['outputs']), self.assertRaises(ValueError):
            F.prepare(F.ref(path))


if __name__ == '__main__':
    unittest.main(verbosity=2)
