"""112正本を同bytes保存し、既正式111の同体コードは複製せず参照する。"""

import argparse
import ast
from copy import deepcopy
import importlib.util
import inspect
from pathlib import Path
import json
import re
import shutil
import textwrap
import zipfile


OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[1]
TRIAL = ROOT / 'study/00112_支持否定の確認と通常追尾幅の比較'
OUTPUTS = ROOT / 'outputs'
PREVIOUS_PATH = ROOT / 'work/111正式保存への接続/正式保存する.py'
PREVIOUS_SHA = 'dd670dd308b79372b0010eca7e0e602fb9af77db5e95c4cbc95d7548d3c1c44e'
import hashlib
if hashlib.sha256(PREVIOUS_PATH.read_bytes()).hexdigest() != PREVIOUS_SHA:
    raise ValueError('停止111正式保存器のSHA差')
SPEC = importlib.util.spec_from_file_location('112が再用する111正式保存共通部', PREVIOUS_PATH)
C = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(C)
need, sha, bind, read, write_json, Z = C.need, C.sha, C.bind, C.read, C.write_json, C.Z
CONFIGS = tuple({'policy': p, 'slip_pts': c, 'delay_seconds': d}
                for p in ('S0', 'W100', 'B100', 'W400', 'P100', 'P400') for c in (0, 5) for d in (0, 1))
KEYS = tuple(f"{r['policy']}_C{r['slip_pts']}_D{r['delay_seconds']}" for r in CONFIGS)
REQUIRED = {'condition', 'market', 'result', 'saved_check', 'core_stop', 'actor_stop', 'pure_stop', 'save_stop', 'P_stop',
            'same_entry_code', 'same_entry_request', 'formal_stop', 'legacy111_index', 'legacy111_zip', 'legacy111_formal_save', 'csv_check'}


def ref(path: Path) -> dict:
    """機能: 明示成果物の絶対位置と全bytes指紋を返す。

    引数: path(Path)は対象。
    返り値: dictはpath/sha256のFileRef。
    """
    return {'path': str(path.resolve()), 'sha256': sha(path)}


def validate(values: dict, request: dict) -> list[str]:
    """機能: 112全70・独立1680・旧111対照840と正式111依存を結ぶ。

    引数: values/request(dict)は認証済みmetadataとRoot固定要求。
    返り値: list[str]は全70場。金融やCSVを再生成しない。
    """
    condition, market, result, saved = (values[k] for k in ('condition', 'market', 'result', 'saved_check'))
    refs, expected = request['refs'], C.sessions()
    need(condition['trial'] == 112 and condition['fixed'] is True and condition['actual_configurations'] == list(CONFIGS), '112本名条件と24宣言')
    need(condition['entry_grid_seconds'] is None and condition['extra_opening_quiet_seconds'] == 0 and condition['chart_seed_mode'] == 'cold_each_session', '112元連続時計')
    need(condition['runtime_stop'] == refs['core_stop'] and condition['dependency_stops']['actor'] == refs['actor_stop']
         and condition['dependency_stops']['pure'] == refs['pure_stop'], '112実Core/Actor/純Go停止')
    need(market['trial'] == 112 and market['success'] is True and market['stage'] == 'full70'
         and (market['sessions'], market['books'], market['reused_sessions'], market['replayed_sessions']) == (70, 1680, 54, 16), '112全70の成功と認証再用54/再生16')
    need(market['condition_sha256'] == refs['condition']['sha256'] and market['unchanged'] is True
         and market['before'] and market['before'] == market['after'], '112同条件と入力不変')
    need(market['reference111_comparisons'] == 840 and market['all_reference111_equal'] is True and market['all_source111_equal'] is True, '112旧111全12N/Source対照')
    need(market['all_original166_reference_events_equal'] is True and market['historical_saved_events_equal'] is False
         and market['all_original_signal_full_json_equal'] is False, '原文oracleと歴史同体の区別')
    need([r['session'] for r in market['results']] == expected, '112市場全70順序')
    need(all(r['books'] == 24 and r['S0_comparisons'] == 4 and r['S0_equal'] is True and r['complete'] is True
             and r['open_quantity'] == r['pending_quantity'] == 0 and r['reference111_comparisons'] == 12
             and r['reference111_equal'] is True and r['source111_equal'] is True for r in market['results']), '112全場の24冊/旧12/残予約0')
    need(result['試行'] == 112 and result['成功'] is True and result['stage'] == 'full70'
         and result['場数'] == 70 and result['会計数'] == 1680 and result['主key'] == list(KEYS), '112独立全1680')
    need(result['前後不変'] is True and result['入力codeSHA256前'] == result['入力codeSHA256後'] and result['採用'] is False
         and result['研究目標達成'] is False, '112独立不変/採用と区別')
    need(result['金融条件SHA256'] == saved['金融条件SHA256'] == refs['condition']['sha256']
         and result['金融完了SHA256'] == saved['金融完了SHA256'] == refs['market']['sha256'], '112独立から金融成功への結合')
    need(result['Actor停止SHA256'] == refs['actor_stop']['sha256'] and result['保存器停止SHA256'] == refs['save_stop']['sha256']
         and result['独立P停止SHA256'] == refs['P_stop']['sha256'], '112独立の全停止結合')
    need(saved['成功'] is True and saved['前後不変'] is True and saved['不一致数'] == 0 and saved['会計数'] == saved['資源'] == 1680
         and saved['旧111全金融比較'] == 840 and saved['全Source111同体'] is True and saved['全残玉予約0'] is True, '112保存全件検算')
    need(saved['出力SHA256']['結果.json'] == refs['result']['sha256'], '112結果と検算の結合')
    need(len(result['場別']) == 1680 and set(result['集計']) == set(KEYS) and len(result['旧111対照']) == 70, '112全0取引保持')
    for key in KEYS:
        need([r['session'] for r in result['場別'] if r['key'] == key] == expected, '112同条件の全70場.' + key)
    legacy_index, legacy_saved = values['legacy111_index'], values['legacy111_formal_save']
    need(legacy_index['試行'] == 111 and legacy_index['成功'] is True and legacy_index['ZIP'] == refs['legacy111_zip'], '既正式111のコード索引/ZIP')
    need(legacy_saved['試行'] == 111 and legacy_saved['成功'] is True and legacy_saved['ZIP'] == refs['legacy111_zip']
         and legacy_saved['コード所在索引'] == refs['legacy111_index'] and legacy_saved['前後不変'] is True, '既正式111保存成功の同体')
    for name in ('core_stop', 'actor_stop', 'pure_stop', 'save_stop', 'P_stop', 'formal_stop'):
        need(values[name]['成功'] is True, '112成功した停止だけ.' + name)
    need(values['formal_stop']['市場前'] is True, '112正式保存器の市場前停止')
    need(values['save_stop']['Actor停止'] == refs['actor_stop'] and values['save_stop']['P停止'] == refs['P_stop'], '112会計停止のActor/P')
    return expected


def selected_code_function():
    """機能: 停止111のコード収集から旧oracle実行物の自動同梱だけを外す。

    引数: なし。
    返り値: functionは単一executableを使う112の同体コード収集。旧oracleは既正式Refに残す。
    """
    tree = ast.parse(textwrap.dedent(inspect.getsource(C.code_rows)))
    matches = [node for node in ast.walk(tree) if isinstance(node, ast.Tuple)
               and ast.unparse(node) == "('executable', 'oracle_executable')"]
    need(len(matches) == 1, '旧111コード収集の実行物tuple一箇所')
    matches[0].elts = [ast.Constant(value='executable')]
    namespace = dict(vars(C))
    exec(compile(ast.fix_missing_locations(tree), __file__ + ':停止111コード収集の実行物一箇所差', 'exec'), namespace)
    return namespace['code_rows']


SELECTED_CODE = selected_code_function()


def code_rows(condition: dict, values: dict, request: dict, before: dict, copied: dict) -> tuple[list, list]:
    """機能: 既正式111の同体コードを参照へ分離し、新しい112だけをZIP計画へ入れる。

    引数: condition/values/request/before/copied(dict)は条件・停止・Root要求・指紋・新規metadata所在。
    返り値: tuple[list,list]は全コード所在索引と新規ZIP行。旧ZIP本文を複写しない。
    """
    augmented = dict(request)
    augmented['code_refs'] = list(request.get('code_refs', [])) + [
        {'ref': request['refs']['same_entry_code'], 'role': 'Rootの同入口40対照器'},
        {'ref': {'path': str(PREVIOUS_PATH), 'sha256': PREVIOUS_SHA}, 'role': '変更しない111正式保存の共通器'}]
    index, ignored_archive = SELECTED_CODE(condition, values, augmented, before, copied)
    legacy_by_path = {str(Path(r['original_path']).resolve()).casefold(): r for r in values['legacy111_index']['entries']}
    legacy_by_sha = {}
    for row in values['legacy111_index']['entries']:
        if row['location']['kind'] == 'このZIP':
            legacy_by_sha.setdefault(row['sha256'], row)
    archived = []
    archive_path = Path(request['refs']['legacy111_zip']['path'])
    # ----------------------------------------
    # 同体部品は既存ZIP内のentry bytesも認証し、新ZIPへ入れません。
    with zipfile.ZipFile(archive_path) as archive:
        for row in index:
            if row['kind'] == 'GoRoot環境参照' or row['location']['kind'] != 'このZIP':
                continue
            prior = legacy_by_path.get(row['original_path'].casefold())
            if prior is None or prior['sha256'] != row['sha256']:
                prior = legacy_by_sha.get(row['sha256'])
            if prior is not None and prior['sha256'] == row['sha256'] and prior['bytes'] == row['bytes']:
                location = prior['location']
                if location['kind'] == 'このZIP':
                    entry = location['entry']
                    need(Z.safe(entry), '既正式111の安全なentry')
                    body = archive.read(entry)
                    need(hashlib.sha256(body).hexdigest() == row['sha256'] and len(body) == row['bytes'], '既正式111の同体コード全bytes')
                    row['kind'] = '既正式111コード参照'
                    row['location'] = {'kind': '既正式111のZIP', 'archive': request['refs']['legacy111_zip'],
                                       'index': request['refs']['legacy111_index'], 'entry': entry, 'legacy_original_path': prior['original_path']}
                    continue
                if location['kind'] == '正式同bytes成果物':
                    target = Path(request['refs']['legacy111_formal_save']['path']).parent.parent / location['relative']
                    bind({'path': str(target), 'sha256': row['sha256']}, before)
                    row['kind'] = '既正式111metadata参照'
                    row['location'] = {'kind': '既正式111成果物', 'ref': {'path': str(target), 'sha256': row['sha256']}}
                    continue
            archived.append(row)
    return index, archived


def prepare(request_ref: dict) -> dict:
    """機能: Root全成功Refと全保存先を、正式先作成前に一度で認証する。

    引数: request_ref(dict)はRootの112全70正式保存固定。
    返り値: dictは同bytesコピー・新コードZIP・CSV外部所在の全計画。
    """
    before = {}
    request = read(request_ref, before)
    need(request['version'] == 1 and request['trial'] == 112 and request['fixed'] is True and request['stage'] == 'full70'
         and request['market_native_read_authorized'] is True, 'Rootの112正式保存解禁')
    need(REQUIRED <= set(request['refs']), '112正式保存の必須参照')
    values = {}
    for name, value in request['refs'].items():
        need(re.fullmatch('[A-Za-z0-9_]+', name), '安全なRef名')
        if name in ('legacy111_zip', 'same_entry_code'):
            bind(value, before)
        else:
            values[name] = read(value, before)
    expected = validate(values, request)
    formal = values['formal_stop']
    need(set(formal['所有ファイルSHA256']) == {str(OWN / n) for n in ('正式保存する.py', '人工検査.py', '検査して停止する.py', 'README.md')}, 'この112正式保存器だけ')
    for path, digest in formal['所有ファイルSHA256'].items():
        bind({'path': path, 'sha256': digest}, before)
    plans, targets, copied = [], set(), {}

    def add(value: dict, relative: str) -> None:
        """機能: 同じ元pathを二重複製せず安全な試行内の新規先へ予約する。

        引数: value(dict)、relative(str)はFileRefと試行内相対先。
        返り値: None。RootのCSV正本を複製しない。
        """
        source = bind(value, before)
        need(source.suffix != '.csv', 'CSV本文はoutputs唯一正本')
        need(Z.safe(relative), '安全な新規正式相対位置')
        target = (TRIAL / relative).resolve()
        need(target.is_relative_to(TRIAL.resolve()) and not target.exists() and str(target).casefold() not in targets, '試行内の新規先だけ')
        need(str(source) not in copied, '元pathの正式二重複写なし')
        targets.add(str(target).casefold())
        copied[str(source)] = relative
        plans.append({'source': str(source), 'target': str(target), 'relative': relative, 'sha256': value['sha256']})

    result, saved, market = (values[k] for k in ('result', 'saved_check', 'market'))
    saved_dir = Path(request['refs']['result']['path']).parent.resolve()
    need(Path(request['refs']['saved_check']['path']).parent.resolve() == saved_dir, '独立正本と検算の同じfolder')
    files = {'結果.json', '一覧.resources.json'} | {f'112_{key}_{sid}.trades.jsonl' for sid in expected for key in KEYS}
    need(set(saved['出力SHA256']) == files, '112全1682出力集合')
    for name in sorted(files):
        add({'path': str(saved_dir / name), 'sha256': saved['出力SHA256'][name]}, '成果物/' + name)
    add(request['refs']['saved_check'], '成果物/保存会計の確認.json')
    catalog = read({'path': str(saved_dir / '一覧.resources.json'), 'sha256': saved['出力SHA256']['一覧.resources.json']}, before)
    need(catalog['schema_version'] == 1 and catalog['path_base'] == 'catalog' and len(catalog['resources']) == 1680, '112 Viewer全1680')
    need({r['id'] for r in catalog['resources']} == {f'112_{key}_{sid}' for sid in expected for key in KEYS}
         and {r['pnl_path'] for r in catalog['resources']} == files - {'結果.json', '一覧.resources.json'}, '112 Viewer ID/約定集合')
    native = []
    need([r['session'] for r in result['Native参照']] == expected, '112独立Native全70順序')
    for row, completed in zip(result['Native参照'], market['results']):
        source = {'path': row['path'], 'sha256': row['sha256']}
        need(source == completed['native'] and row['reference111'] == completed['reference111'], '112金融/独立/正式111の参照同体')
        path, sid = Path(source['path']), row['session']
        need(path.name == sid + '.Native.json.gz', '112 Nativeの本名')
        relative = '成果物_金融/Native/' + path.name
        add(source, relative)
        bind(row['reference111'], before)
        native.append({'session': sid, 'relative': relative, 'sha256': source['sha256'], 'bytes': path.stat().st_size,
                       'origin': source, 'reference111': row['reference111'], '同bytes': True})
    for name, value in request['refs'].items():
        if name not in ('result', 'saved_check', 'legacy111_zip', 'legacy111_index', 'legacy111_formal_save', 'same_entry_code'):
            add(value, '検査/' + name + '.json')
    if 'prior54' in market:
        add(market['prior54'], '検査/元54成功.json')
    for item in request.get('extra_refs', []):
        need(set(item) == {'ref', 'target', 'role'} and item['target'].split('/')[0] in ('診断', '検査', '再現資料'), '明示後段extra')
        need(Path(item['ref']['path']).suffix in ('.json', '.md', '.py', '.mjs', '.ps1'), '後段は根拠/診断/文書。CSV本体を複写しない')
        add(item['ref'], item['target'])
    add(request_ref, '検査/正式保存の要求.json')
    # ----------------------------------------
    # CSVはRootの再読成功記録へ結び、現在SHAを確認するだけです。
    csv_check = values['csv_check']
    need(csv_check.get('成功') is True and csv_check.get('試行') == 112 and csv_check['場別行数'] == 1680
         and csv_check['候補数'] == 24 and csv_check['全場累計再計算'] is True and csv_check['未定義比率は空欄'] is True
         and csv_check['数値比較数'] > 0
         and csv_check['前後不変'] is True and csv_check['入力SHA256'] == csv_check['後SHA256']
         and csv_check['Raw読取'] == 0 and csv_check['金融再実行'] is False, 'Rootの112 CSV独立全件再読成功')
    need(csv_check['入力SHA256'].get(str(Path(request['refs']['result']['path']).resolve())) == request['refs']['result']['sha256'],
         'CSV成功から112独立結果への結合')
    need(set(request['csv_refs']) == {'候補別集計.csv', '全セッション.csv'}, 'Root CSVは二点だけ')
    csv_external = {}
    for name, value in request['csv_refs'].items():
        path = bind(value, before)
        need(path.is_relative_to(OUTPUTS.resolve()) and path.name == name
             and csv_check['入力SHA256'].get(str(path)) == value['sha256'], 'outputs唯一正本とRoot成功SHA')
        csv_external[name] = value
    index, archived = code_rows(values['condition'], values, request, before, copied)
    generated = ['成果物_金融/Native参照台帳.json', '再現資料/コードと実使用実行物.zip', '再現資料/コード所在索引.json',
                 '再現資料/入力と既正式111の参照.json', '再現資料/CSV所在と確認.json', '再現資料/再現手順.md', '検査/正式保存の確認.json']
    need(all(not (TRIAL / p).exists() and str((TRIAL / p).resolve()).casefold() not in targets for p in generated), '生成先の全新規性')
    return {'request': request, 'before': before, 'plans': plans, 'native': native, 'index': index, 'archived': archived, 'csv': csv_external}


def execute(request_ref: dict) -> dict:
    """機能: 112の全計画を同bytes保存し、新規コードZIPだけを作成・全検査する。

    引数: request_ref(dict)はRoot固定要求。
    返り値: dictは正式確認・ZIP・索引Ref。CSV正本や旧111本文を増やさない。
    """
    plan = prepare(request_ref)
    copied = []
    for row in plan['plans']:
        source, target = Path(row['source']), Path(row['target'])
        need(sha(source) == row['sha256'] and not target.exists(), 'コピー直前の不変/未使用')
        target.parent.mkdir(parents=True, exist_ok=True)
        with source.open('rb') as src, target.open('xb') as dst:
            shutil.copyfileobj(src, dst)
        need(sha(source) == sha(target) == row['sha256'], '正式コピーの同bytes')
        copied.append({'relative': row['relative'], 'origin': {'path': row['source'], 'sha256': row['sha256']},
                       'sha256': row['sha256'], 'bytes': target.stat().st_size, '同bytes': True})
    native_path = TRIAL / '成果物_金融/Native参照台帳.json'
    write_json(native_path, {'試行': 112, '成功': True, '場数': 70, '会計数': 1680, 'Native': plan['native'], '旧111複写': False})
    destination = TRIAL / '再現資料'
    destination.mkdir(parents=True, exist_ok=True)
    archive_path = destination / 'コードと実使用実行物.zip'
    Z.write_zip(archive_path, plan['archived'])
    checks = Z.verify_zip(archive_path, plan['archived'])
    for row in plan['index']:
        if row['location']['kind'] == 'このZIP':
            row['location'].update(checks[row['location']['entry']])
    index_path = destination / 'コード所在索引.json'
    legacy_count = sum(r['kind'].startswith('既正式111') for r in plan['index'])
    index = {'試行': 112, '成功': True, 'Root要求': request_ref, 'ZIP': ref(archive_path), 'entries': plan['index'],
             'restore_roots': plan['request']['restore_roots'], 'go_environment': plan['request']['go_environment'],
             '同梱数': len(plan['archived']), '既正式111参照数': legacy_count,
             'GoRoot索引数': sum(r['kind'] == 'GoRoot環境参照' for r in plan['index']), '旧111ZIP複写': False,
             '全entrySHA/CRC/安全名/集合': True, '研究目標達成': False, '採用': False}
    write_json(index_path, index)
    external_path = destination / '入力と既正式111の参照.json'
    condition = read(plan['request']['refs']['condition'], {})
    write_json(external_path, {'試行': 112, '成功': True, '既正式111': {name: plan['request']['refs'][name] for name in ('legacy111_index', 'legacy111_zip', 'legacy111_formal_save')},
                               '共用入力台帳': condition['manifest'], '原文oracle54': condition['original166_references'], '正式111金融基準': condition['reference111'],
                               '原板/価格CSV本文複写': False, '旧111本文/ZIP全複写': False})
    csv_path = destination / 'CSV所在と確認.json'
    write_json(csv_path, {'試行': 112, '成功': True, 'CSV': plan['csv'], 'Root独立再読成功': plan['request']['refs']['csv_check'],
                         '現在SHA照合': True, 'CSV本文の正式側複写': False, '唯一正本': 'outputs'})
    procedure = destination / '再現手順.md'
    with procedure.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write('# 112の再現資料\n\n112の新コードと実使用実行物だけを新ZIPへ保存した。同体のSource111・chart111・旧純戦略等はコード所在索引の既正式111 ZIP/成果物Refから元のrestore位置へ復元する。旧ZIPは複製していない。GoRootは索引のみで、Go1.24.2と全選択SHAが同じ標準Go環境を別途用意する。\n\n原板・価格CSVは共用入力台帳の同SHAだけを使う。元54成功から追加16を再生した全70が正本で、認証済み54をRaw再生で再証明したとは呼ばない。112旧12条件とSourceの全金融同体は別証拠を参照する。独立会計/P/CSVは金融を再実行していない。\n\nCSV二点はoutputsが唯一正本で、CSV所在と確認.jsonのRoot独立再読成功RefとSHAを参照する。Root完了記録やViewer追加確認は後段別資料となる。研究目標達成と採用はfalse。\n')
    need(all(sha(Path(r['source'])) == sha(Path(r['target'])) == r['sha256'] for r in plan['plans']), '全コピー最終同bytes')
    after = {path: sha(Path(path)) for path in plan['before']}
    need(after == plan['before'], '全入力code/既正式111/CSVの前後不変')
    proof_path = TRIAL / '検査/正式保存の確認.json'
    write_json(proof_path, {'試行': 112, '成功': True, 'Root要求': request_ref, '同bytes成果物': copied,
                           'Native台帳': ref(native_path), 'Native数': 70, '会計数': 1680, 'Viewer資源': 1680,
                           'ZIP': ref(archive_path), 'コード所在索引': ref(index_path), 'CSV所在': ref(csv_path), '入力参照': ref(external_path),
                           '同梱entry数': len(plan['archived']), '既正式111参照数': legacy_count, '全entrySHA/CRC/安全名/集合': True,
                           '入力SHA256前': plan['before'], '入力SHA256後': after, '前後不変': True,
                           '旧111/Raw/価格CSV本文/CSV二点の複写': False, '金融再実行': False, '11月09日本文読取': False,
                           '研究目標達成': False, '採用': False})
    return {'成功': True, '確認': ref(proof_path), 'ZIP': ref(archive_path), '索引': ref(index_path),
            'Native台帳': ref(native_path), 'CSV所在': ref(csv_path), '新同梱数': len(plan['archived']), '既正式111参照数': legacy_count}


def main() -> None:
    """機能: 全70成功後のRoot要求と期待SHAだけから正式保存する。

    引数: CLI request/request-sha(str)はRoot要求絶対位置と指紋。
    返り値: None。小さな正式Refだけを表示する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--request', type=Path, required=True)
    parser.add_argument('--request-sha', required=True)
    args = parser.parse_args()
    print(json.dumps(execute({'path': str(args.request.resolve()), 'sha256': args.request_sha}), ensure_ascii=False))


if __name__ == '__main__':
    main()
