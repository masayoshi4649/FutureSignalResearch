"""112の版6汎用表へ、金融結果を入れずに予定設定と閾値を記す。"""

from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
PRIOR = ROOT / 'study/00111_元の連続判断と必須追尾の再基準化/設定と結果.md'
TARGET = ROOT / 'study/00112_支持否定の確認と通常追尾幅の比較/設定と結果.md'


def main() -> None:
    """機能: 56手法×9尺度の識別を保ち、112の予定閾値を割り当てる。

    引数: なし。入力は固定111の明細と既存112初期表。
    返り値: None。予定設定を保存する。市場実行・損益補完は行わない。
    """
    old = PRIOR.read_text(encoding='utf-8')
    current = TARGET.read_text(encoding='utf-8')
    if '版6の56手法×9尺度をコピーした初期資料。' not in current:
        raise ValueError('初期表以外は上書きしない')
    catalog = old[old.index('# 手法と時間スケール'):old.index('## 設定明細')]
    catalog = catalog.replace('本試行のカタログは版6。', '112のカタログは版6。以下は予定設定で市場未実行。')
    catalog = catalog.replace('R13〜24', 'R09〜12/R17〜24').replace('R17〜24。CとB', 'R09〜12。CとB')
    lines = catalog.splitlines()
    edits = {
        'I01': {4: '予定S06：EMA8/21の幅3公表strict縮小→R09〜12。P系列では診断のみ'},
        'I05': {4: '予定S08：BB20母σ2、幅3公表strict縮小→R09〜12。P系列では診断のみ'},
    }
    ids = []
    for index, line in enumerate(lines):
        if not re.match(r'^\| [A-Z]\d{2} \|', line):
            continue
        cells = [cell.strip() for cell in line.strip('|').split('|')]
        identity = cells[0]
        if len(cells) != 11:
            raise ValueError('9尺度の列差: ' + identity)
        ids.append(identity)
        for column, replacement in edits.get(identity, {}).items():
            cells[column] = replacement
        cells = [cell.replace('使用S', '予定S') if '予定S' not in cell else cell for cell in cells]
        lines[index] = '| ' + ' | '.join(cells) + ' |'
    if len(ids) != 56 or len(set(ids)) != 56:
        raise ValueError('56手法の行集合差')
    details = old[old.index('## 設定明細'):old.index('## 複合条件と結果')]
    details = details.replace('## 設定明細（最終固定F3）', '## 設定明細（市場前の予定）')
    details = details.replace('F3条件と再現資料', '112条件固定後の再現資料')
    details = details.replace('R13〜24', 'R09〜12/R17〜24')
    replacements = {
        'S04': '| S04 | I09・源5分→実取得時固定 | 通常保護幅のA_entry | 源ATR12、最小3本、5分足終端+60秒の公開済み値を実新規で固定 | 未知ならW100/B100/P100は200pt、W400/P400は400ptへ固定。後で付け替えない | R05〜24、S13 | 追加公表器のATR14とは別 |',
        'S06': '| S06 | I01・確定3分 | 収束C | D=abs(EMA8−EMA21)、連続既知3公表 | D_t<D_prev<D_prev2、等号は偽 | R09〜12のB100警戒。新Pでは生値を診断保存 | Cだけで反転としない |',
        'S07': '| S07 | I03・確定3分 | 勢いの失速M | MACD-H=(EMA12−EMA26)−signalEMA9、現前公表 | side×(H_t−H_prev)<0、0は偽 | R09〜12/R17〜24 | 未知は三値unknown。新規選別なし |',
        'S08': '| S08 | I05・確定3分 | BB収縮B | 終値20本のSMA、母σ、上下±2σ、生幅4σ | 幅_t<幅_prev<幅_prev2。20本でBB既知、22本以降B既知。ゼロ幅は既知、%b未知 | R09〜12のB100警戒。新Pでは生値を診断保存 | 接触や縮小だけを反転としない |',
        'S12': '| S12 | P05/E02・逐次 | 一定利益の必須起動 | q0=実玉初期枚数、n=予約込み残枚数、R=先行返済済み往復費用後額。g=side×(返済側BBO−実取得)、K=77+200S円、u=100g−K、W=R+n×u | S0以外はW>=q0×10000円で起動（H100固定）。等号を含む | R05〜24。S0は追加Stateなし | 別玉・反対側と相殺せず、峰は起動時から追う |',
        'S13': '| S13 | C06・逐次、警戒は3分 | 通常幅と複合狭幅 | W100/B100/P100はceil5(max(200,2A_entry))、W400/P400はceil5(max(400,4A_entry))。狭幅=min(既知A_entry,V_current)のceil5、最低10pt、通常幅以下 | B100はM AND(C OR B OR P)、P100/P400はM AND P。W100/W400は狭幅なし。初回警戒真でラッチし解除しない。両尺度未知なら現幅を保持 | R05〜24 | 生C/M/P/Bを変更せず、本名policyとdefinitionを保存 |',
        'S14': '| S14 | C06/E02・逐次 | 最低費用床・全玉床・非緩和 | 費用床=5ceil((K+500)/500)。L初期0円、F_W=5ceil((nK+L−R)/(500n))。F=max(旧F,費用床,F_W,ceil5(起動後峰−選択幅),適格構造床) | L=max(旧L,0,R+100nF−nK)。C0床10pt、C5床20pt。F/Lを不利に緩めない | R05〜24。構造候補はR09〜12/R17〜24だけ | 半円整数ceil。遅延・gap後の純益保証ではない |',
    }
    output = []
    for line in details.splitlines():
        match = re.match(r'^\| (S\d{2}) \|', line)
        output.append(replacements.get(match.group(1), line) if match else line)
    settings = '\n'.join(output)
    # ----------------------------------------
    # 計画の24条件を未実行のまま記録し、旧試行の結果を転記しない。
    rows = ['## 複合条件と結果（市場未実行）', '',
            '| 評価ID | 条件ID | 使用設定 | 結果 |', '| --- | --- | --- | --- |']
    number = 0
    for policy in ('S0', 'W100', 'B100', 'W400', 'P100', 'P400'):
        for slip in (0, 5):
            for delay in (0, 1):
                number += 1
                used = 'S01〜03/S16〜17' if policy == 'S0' else 'S01〜05/S12〜17'
                if policy in ('B100', 'P100', 'P400'):
                    used = 'S01〜17（S06/S08の値による狭幅選別はB100だけ）'
                rows.append(f'| R{number:02} | {policy}_C{slip}_D{delay} | {used} | 未実行 |')
    header = ('# 00112：設定と結果\n\n版6の56手法×9尺度を保持し、112で予定する設定ID・閾値・複合評価IDを記す。'
              '市場条件は未固定、市場未実行。未実行を0円に置き換えない。\n\n[計画](README.md) / '
              '[設計案](設計候補.json)。旧111の同じ指標準備と会計から、通常幅と警戒条件だけを別々に変える。\n\n')
    TARGET.write_text(header + '\n'.join(lines).rstrip() + '\n\n' + settings.rstrip() +
                      '\n\n' + '\n'.join(rows) + '\n', encoding='utf-8', newline='\n')
    print('112の予定設定を保存。56手法・504セル・S01〜17・R01〜24、市場未実行。')


if __name__ == '__main__':
    main()
