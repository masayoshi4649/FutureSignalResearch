"""112の実宣言と計画を照合し、市場前の金融条件を新規固定する。"""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def digest(path: Path) -> str:
    """機能: 明示した参照の指紋を算出する。

    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def authenticate(ref: dict) -> Path:
    """機能: metadata・コードだけの絶対参照を照合する。

    引数: ref(dict)はpath/sha256。
    返り値: Pathは認証済み位置。
    """
    path = Path(ref['path'])
    if not path.is_absolute() or digest(path) != ref['sha256']:
        raise ValueError('固定参照の現物差: ' + str(path))
    return path


def main() -> None:
    """機能: 六政策・24組と旧111参照、全コードを検査して固定する。

    引数: なし。停止済み112の素材と111の正式条件を用いる。
    返り値: None。条件と固定確認を新規保存し、金融再生は行わない。
    """
    material = ROOT / 'work/112支持否定と通常幅の連続比較/条件の素材.json'
    assert digest(material) == 'd9b65f9c94ffb7c1c60826f43e1022ba1f610d0cade011e1494383864b246ae3'
    data = json.loads(material.read_text(encoding='utf-8'))
    assert data['version'] == 1 and data['trial'] == 112 and data['fixed'] is False
    assert data['policy'] == 'original166_source111_support_pivot_comparison112'
    assert data['source_trial'] == 111 and data['actual_policy'] == 'support_pivot_normal_width112'
    assert data['chart_seed_mode'] == 'cold_each_session'
    assert data['entry_grid_seconds'] is None and data['extra_opening_quiet_seconds'] == 0
    assert data['parallel_method'] == 'isolated_session_process112_v1' and data['parallel_max_workers'] == 16
    assert data['runtime_stop']['sha256'] == '42782f38f7767b9763b04983ace2e5e7fa134bb579f816e0d215d6901d70369d'
    assert data['executable']['sha256'] == '50776128c85ee39fc271e662a02f220ab2b6a88ff10b2b92fce57d1c4fab4d1c'
    policies = ('S0', 'W100', 'B100', 'W400', 'P100', 'P400')
    actual = [{'policy': p, 'slip_pts': c, 'delay_seconds': t}
              for p in policies for c in (0, 5) for t in (0, 1)]
    pure = [{'policy': p, 'slip_points': c, 'delay_seconds': t}
            for p in policies for c in (0, 5) for t in (0, 1)]
    assert data['actual_configurations'] == actual and data['pure_configurations'] == pure
    expected = []
    for p in policies:
        enabled = p != 'S0'
        wide = p in ('W400', 'P400')
        warning = ('追加保護なし' if p == 'S0' else 'M AND(C OR B OR P)' if p == 'B100'
                   else 'M AND P' if p in ('P100', 'P400') else 'M AND(C OR P)')
        expected.append({'version': 112, 'policy': p, 'enabled': enabled,
                         'threshold_points': 100 if enabled else 0,
                         'normal_width_minimum': (400 if wide else 200) if enabled else 0,
                         'atr_multiplier': (4 if wide else 2) if enabled else 0,
                         'warning_formula': warning,
                         'technical_narrowing': p in ('B100', 'P100', 'P400')})
    assert data['policy_definitions'] == expected
    refs = [data['manifest'], data['executable'], data['runtime_stop'],
            *data['dependency_stops'].values(), data['actual_declaration'],
            data['pure_declaration'], data['chart_declaration'], *data['reference111'].values()]
    for ref in refs:
        authenticate(ref)
    old = json.loads(Path(data['reference111']['condition']['path']).read_text(encoding='utf-8'))
    for name in ('FAR_commit', 'strategy_commit', 'manifest', 'original166_references'):
        assert data[name] == old[name], name
    assert len(data['original166_references']) == 54
    assert len(data['code_sha256']) == 1040
    for path, sha in data['code_sha256'].items():
        assert 'JP_OSE_Data' not in path and not path.endswith('.Native.json.gz')
        authenticate({'path': path, 'sha256': sha})
    # ----------------------------------------
    # 技術定義を変えず、Rootの市場前固定だけを有効にする。
    data['fixed'] = True
    target = ROOT / 'work/112進行/F1_支持否定と通常幅の金融条件.json'
    with target.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    proof = {'試行': 112, '成功': True, '市場前固定': True,
             '素材': {'path': str(material), 'sha256': digest(material)},
             '条件': {'path': str(target), 'sha256': digest(target)},
             '全コード照合': 1040, '実政策数': 6, '実条件数': 24,
             '変更': 'fixedをfalseからtrueへ変更しただけ。金融定義・コード・入力は素材と同体。',
             'Raw読取': 0, '市場Native読取': 0, '11月09読取': False,
             '原文oracle再走': False, '旧111改変': False}
    with (target.parent / 'F1_市場前固定の確認.json').open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(proof, ensure_ascii=False))


if __name__ == '__main__':
    main()
