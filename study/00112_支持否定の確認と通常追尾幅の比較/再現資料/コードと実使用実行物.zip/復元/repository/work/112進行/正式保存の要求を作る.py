"""112の全段階成功とCSV再読後に、正式保存の明示参照を固定する。"""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUTPUT = ROOT / 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/112損益CSV'


def reference(path: Path) -> dict:
    """機能: 正本の絶対位置とバイト指紋を得る。

    引数: path(Path)は明示した入力。
    返り値: dictはFileRef。存在しなければ例外。
    """
    return {'path': str(path.resolve()), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def main() -> None:
    """機能: 112の全70・独立・同入口・CSV成功を結んだ要求を保存する。

    引数: なし。入力は明示した112正本だけ。
    返り値: None。Root要求を新規保存する。市場再生・Raw複写はしない。
    """
    paths = {
        'condition': 'work/112進行/F1_支持否定と通常幅の金融条件.json',
        'market': 'work/112市場/全70場/完了.json',
        'result': 'work/112独立保存/全70場/結果.json',
        'saved_check': 'work/112独立保存/全70場/保存会計の確認.json',
        'core_stop': 'work/112支持否定と通常幅の連続比較/停止.json',
        'actor_stop': 'work/112支持否定と広い通常幅の会計/Actor停止.json',
        'pure_stop': 'work/112支持否定の必須確認と通常幅のみ/停止.json',
        'save_stop': 'work/112支持否定と広い通常幅の会計/会計停止.json',
        'P_stop': 'work/112支持否定と通常幅の独立P監査/P停止.json',
        'formal_stop': 'work/112正式保存への接続/検査_停止版/停止.json',
        'legacy111_index': 'study/00111_元の連続判断と必須追尾の再基準化/再現資料/コード所在索引.json',
        'legacy111_zip': 'study/00111_元の連続判断と必須追尾の再基準化/再現資料/コードと実使用実行物.zip',
        'legacy111_formal_save': 'study/00111_元の連続判断と必須追尾の再基準化/検査/正式保存の確認.json',
        'same_entry_code': 'work/112同じ入口の実現比較/比較する.py',
        'same_entry_request': 'work/112進行/C1_全70場の同入口比較要求.json',
    }
    refs = {name: reference(ROOT / path) for name, path in paths.items()}
    refs['csv_check'] = reference(OUTPUT / 'CSVの独立再読.json')
    expected_stops = {
        'condition': '893fa4dbaa0525f0f37579e750a46d5e846a9dbc83bf4b816e16e97e4527ad69',
        'core_stop': '42782f38f7767b9763b04983ace2e5e7fa134bb579f816e0d215d6901d70369d',
        'actor_stop': '54dc421f0c35cbd5736725955a02fb6cd11f70f3c8a7b646b954722781264006',
        'pure_stop': 'b7748c29ae5c6bc44a66a112421809f888c85321652a0d9bfbb3c7f4022dd835',
        'save_stop': '7408e520143de90b77e5368f9a3f22f235f4555e34f026b306902fb1cae820f8',
        'P_stop': 'c873e82630e647b9731e013e8be2786424818248503ec6765e797e49ef430048',
        'formal_stop': '9d10d39c7f16b9578f8cf4a9cc391f5403dbca837bc8336c665a64c9c2c94090',
        'same_entry_code': 'e10b4c027eceff575682a552086cb48e52aac7c970de6e3dee3a80939324a445',
    }
    for name, sha in expected_stops.items():
        assert refs[name]['sha256'] == sha, name
    same = ROOT / 'work/112同入口比較/全70場/結果.json'
    compared = json.loads(same.read_text(encoding='utf-8'))
    assert compared['成功'] and compared['試行'] == 112 and compared['全対照数'] == 2800 and compared['前後不変']
    extras = [
        (same, '診断/同入口の実現比較/結果.json', '40対照×70の全実現差'),
        (ROOT / 'work/112同じ入口の実現比較/準備検査/確認.json', '検査/同入口の準備確認.json', '解禁なし拒否と市場前準備'),
        (ROOT / 'work/112同じ入口の実現比較/解釈文の修正記録.json', '検査/同入口の解釈文の修正.json', '演算無変更の説明修正'),
        (ROOT / 'work/112進行/F1_市場前固定の確認.json', '検査/金融条件の固定確認.json', '全1040コードと24宣言の事前固定'),
        (ROOT / 'work/112市場/先頭2場/完了.json', '検査/先頭2金融成功.json', '段階成功'),
        (ROOT / 'work/112独立保存/先頭2場/保存会計の確認.json', '検査/先頭2独立保存確認.json', '48会計の独立確認'),
        (ROOT / 'work/112独立保存/元54場/保存会計の確認.json', '検査/元54独立保存確認.json', '1296会計の独立確認'),
        (OUTPUT / 'CSVの確認.json', '検査/CSVの生成確認.json', 'artifact-toolの表再計算と出力指紋'),
        (ROOT / 'work/112専用Viewer8096/Viewer取得を確認する.py', '再現資料/Viewer取得を確認する.py', '後段HTTP確認用コード'),
    ]
    for name in ('調査.md', '索引.json', '検査.json'):
        extras.append((ROOT / 'work/112元三手法のテクニカル対応' / name,
                       '診断/元三手法の技法/' + name, '固定元手法の技法と保護範囲の対応'))
    code_paths = [Path(__file__), ROOT / 'work/112進行/条件を固定する.py',
                  ROOT / 'work/112進行/独立保存の要求を作る.py',
                  ROOT / 'work/112進行/設定表を整える.py',
                  ROOT / 'work/112損益CSVの出力/出力する.mjs',
                  ROOT / 'work/112損益CSVの出力/CSVを独立再読する.py',
                  ROOT / 'work/111同じ入口の実現比較/比較する.py',
                  ROOT / 'work/112専用Viewer8096/Viewer取得を確認する.py',
                  ROOT / 'work/112専用Viewer8096/conf/viewer.toml']
    old_request = json.loads((ROOT / 'work/111進行/正式保存の要求.json').read_text(encoding='utf-8'))
    request = {'version': 1, 'trial': 112, 'fixed': True, 'stage': 'full70',
               'market_native_read_authorized': True, 'refs': refs,
               'csv_refs': {name: reference(OUTPUT / name) for name in ('候補別集計.csv', '全セッション.csv')},
               'go_environment': old_request['go_environment'], 'restore_roots': old_request['restore_roots'],
               'code_refs': [{'ref': reference(path), 'role': 'Rootの再現と検算コード'} for path in code_paths],
               'extra_refs': [{'ref': reference(path), 'target': target, 'role': role} for path, target, role in extras]}
    target = ROOT / 'work/112進行/正式保存の要求_R2.json'
    with target.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(request, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'成功': True, '要求': reference(target)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
