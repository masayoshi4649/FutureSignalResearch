"""成功済み112市場と同じ全場順から独立保存の固定要求を作る。"""

import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def reference(path: Path, expected: str | None = None) -> dict:
    """機能: 明示ファイルを認証し絶対参照へする。

    引数: path(Path)、expected(str|None)は位置と既知指紋。
    返り値: dictはpath/sha256。差は例外。
    """
    path = path.resolve()
    sha = hashlib.sha256(path.read_bytes()).hexdigest()
    if expected is not None and expected != sha:
        raise ValueError('保存要求の入力指紋差: ' + str(path))
    return {'path': str(path), 'sha256': sha}


def main() -> None:
    """機能: first2/base54/full70の独立保存要求を新規保存する。

    引数: CLI stage/completion/output(str)は段階・金融成功・要求の新規先。
    返り値: None。Raw・Native本文を読まず要求Refを表示する。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', choices=('first2', 'base54', 'full70'), required=True)
    parser.add_argument('--completion', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    completion_path = Path(args.completion).resolve()
    completed = json.loads(completion_path.read_text(encoding='utf-8'))
    assert completed['trial'] == 112 and completed['stage'] == args.stage and completed['success'] is True
    condition = reference(ROOT / 'work/112進行/F1_支持否定と通常幅の金融条件.json',
                          '893fa4dbaa0525f0f37579e750a46d5e846a9dbc83bf4b816e16e97e4527ad69')
    assert completed['condition_sha256'] == condition['sha256']
    assert completed['all_reference111_equal'] and completed['all_source111_equal']
    manifest = json.loads((ROOT / 'study/00106_収束失速で保護の起動と幅を切り替える/入力台帳_70場.json').read_text(encoding='utf-8'))
    scenes = {r['id']: r for r in manifest['sessions']}
    tasks = []
    for row in completed['results']:
        sid = row['session']
        tasks.append({'session': sid, 'native': row['native'], 'reference111': row['reference111'],
                      'history_class': 'original54' if sid[:10] <= '2026-10-27' else 'additional16',
                      'market_path': str((Path(manifest['source_root']) / scenes[sid]['files']['NK225_book']['path']).resolve())})
    request = {'version': 1, 'trial': 112, 'fixed': True, 'market_native_read_authorized': True,
               'stage': args.stage, 'condition': condition, 'completion': reference(completion_path),
               'code_stop': reference(ROOT / 'work/112支持否定と広い通常幅の会計/会計停止.json',
                                      '7408e520143de90b77e5368f9a3f22f235f4555e34f026b306902fb1cae820f8'),
               'P_stop': reference(ROOT / 'work/112支持否定と通常幅の独立P監査/P停止.json',
                                   'c873e82630e647b9731e013e8be2786424818248503ec6765e797e49ef430048'),
               'actor_stop': reference(ROOT / 'work/112支持否定と広い通常幅の会計/Actor停止.json',
                                       '54dc421f0c35cbd5736725955a02fb6cd11f70f3c8a7b646b954722781264006'),
               'protection_code': reference(ROOT / 'work/112支持否定と通常幅の独立P監査/新保護の独立監査.py',
                                            '7c43fe01133e028476ad5946b620cd566270eddbf76055fc8fdc18f8f8942a37'),
               'scenes': tasks}
    target = Path(args.output).resolve()
    with target.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(request, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'成功': True, '場数': len(tasks), '要求': reference(target)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
