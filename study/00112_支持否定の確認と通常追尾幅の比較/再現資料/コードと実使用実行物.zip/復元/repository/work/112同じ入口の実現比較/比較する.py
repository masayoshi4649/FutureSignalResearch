"""112の成立した実玉を対応付け、通常幅と支持否定の変更を実現額で分ける。"""

import argparse
from decimal import Decimal
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PRIOR = ROOT / 'work/111同じ入口の実現比較/比較する.py'
PRIOR_SHA = '3bfe0d2c285021cc4fd90f8bc0c4c117d2d1331b9fbd2820913f818ea472715a'
POLICIES = ('S0', 'W100', 'B100', 'W400', 'P100', 'P400')
KEYS = tuple(f'{p}_C{c}_D{d}' for p in POLICIES for c in (0, 5) for d in (0, 1))
PAIRS = tuple([('S0', p) for p in POLICIES[1:]] +
              [('W100', 'W400'), ('W100', 'P100'), ('W400', 'P400'),
               ('P100', 'P400'), ('B100', 'P100')])


def prior_module():
    """機能: 固定111の同入口・実現差演算だけを無変更で再用する。

    引数: なし。
    返り値: moduleは指紋確認済みの関数群。111のmainや市場gateを起動しない。
    """
    import hashlib
    if hashlib.sha256(PRIOR.read_bytes()).hexdigest() != PRIOR_SHA:
        raise ValueError('固定111の比較演算の改変')
    spec = importlib.util.spec_from_file_location('固定111の実入口比較', PRIOR)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> None:
    """機能: 独立成功後の112全Nativeから40対照の実現差を保存する。

    引数: CLI fixed/sha256/output(str)はRoot要求、期待指紋、新規保存先。
    返り値: None。全予定場・実現額・前後指紋を検査して結果Refを表示する。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--fixed', required=True)
    parser.add_argument('--sha256', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    lib = prior_module()
    before = {}
    request = lib.load(lib.reference({'path': str(Path(args.fixed).resolve()),
                                      'sha256': args.sha256}, before))
    lib.need(request['trial'] == 112 and request['fixed'] is True and
             request['market_native_read_authorized'] is True, '112の固定した比較要求')
    code = lib.reference(request['code'], before)
    lib.need(code == Path(__file__).resolve(), '実使用の比較code')
    lib.reference({'path': str(PRIOR), 'sha256': PRIOR_SHA}, before)
    condition = lib.load(lib.reference(request['condition'], before))
    complete = lib.load(lib.reference(request['completion'], before))
    saved = lib.load(lib.reference(request['saved_result'], before))
    checked = lib.load(lib.reference(request['saved_check'], before))
    stage = request['stage']
    expected = lib.sessions(stage)
    n = len(expected)
    lib.need(condition['trial'] == 112 and condition['fixed'] is True, '112の市場条件')
    lib.need(complete['trial'] == 112 and complete['success'] is True and
             complete['stage'] == stage and complete['sessions'] == n and
             complete['books'] == 24 * n and complete['unchanged'] is True and
             complete['before'] == complete['after'] and
             complete['condition_sha256'] == request['condition']['sha256'], '全金融成功')
    for item in (saved, checked):
        lib.need(item['試行'] == 112 and item['成功'] is True and item['stage'] == stage and
                 item['場数'] == n and item['会計数'] == 24 * n and item['前後不変'] is True,
                 '同段階の独立会計成功')
        lib.need(item['金融条件SHA256'] == request['condition']['sha256'] and
                 item['金融完了SHA256'] == request['completion']['sha256'], '独立検算の金融参照')
    lib.need(checked['出力SHA256']['結果.json'] == request['saved_result']['sha256'] and
             checked['全残玉予約0'] is True and checked['不一致数'] == 0, '保存後独立照合')
    lib.need(tuple(saved['主key']) == KEYS, '112の全24予定条件')
    lib.need([x['session'] for x in complete['results']] == expected and
             [x['session'] for x in saved['Native参照']] == expected, '全予定場順')
    financial = {(r['session'], r['key']): r['net_yen'] for r in saved['場別']}
    lib.need(len(financial) == 24 * n and set(financial) ==
             {(sid, key) for sid in expected for key in KEYS}, '0件を含む全会計保持')
    output = Path(args.output).resolve()
    lib.need(not output.exists(), '実現比較の保存先は新規')
    rows = []
    for scene, stored in zip(complete['results'], saved['Native参照']):
        ref = {'path': stored['path'], 'sha256': stored['sha256']}
        lib.need(scene['native'] == ref, '市場と独立保存のNative同体')
        value = lib.load(lib.reference(ref, before))
        actual = value['actual']
        lib.need(actual['complete'] is True and value['S0_equal'] is True and
                 value['S0_comparisons'] == 4 and
                 actual['scope']['session']['id'] == scene['session'], '当場の金融完結')
        books = actual['books']
        lib.need(set(books) == set(KEYS), '当場の全24冊')
        for key in KEYS:
            lib.need(books[key]['key'] == key and books[key]['totals']['net_yen'] ==
                     financial[(scene['session'], key)], '各実会計と独立結果の純額')
        for c in (0, 5):
            for d in (0, 1):
                for left, right in PAIRS:
                    compared = lib.compare_books(books[f'{left}_C{c}_D{d}'],
                                                 books[f'{right}_C{c}_D{d}'])
                    rows.append({'session': scene['session'], **compared})
    aggregate = lib.aggregate(rows)
    lib.need(len(rows) == 40 * n and len(aggregate) == 40, '40対照の全場保持')
    for row in aggregate:
        lib.need(row['前全純額円'] == saved['集計'][row['前key']]['net_yen'] and
                 row['後全純額円'] == saved['集計'][row['後key']]['net_yen'], '実現差と独立合計')
    after = {name: lib.digest(Path(name)) for name in before}
    lib.need(before == after, '比較codeと金融正本の前後不変')
    output.mkdir(parents=True, exist_ok=False)
    result = {'試行': 112, '成功': True, 'stage': stage, '場数': n, '全対照数': len(rows),
              '集計': aggregate, '場別': rows, '前後不変': True, 'before': before, 'after': after,
              '比較要求SHA256': args.sha256, '比較演算再用': {'path': str(PRIOR), 'sha256': PRIOR_SHA},
              '解釈': ['同じSource出生・実原行・方向・量・価格が全同体の場合だけ同入口。',
                       'W100→W400/P100→P400は通常幅、B100→P100は警戒式の条件差。',
                       'W100→P100/W400→P400は複合狭幅と適格構造床の追加であり、P単独効果ではない。',
                       '全実現差を共通玉・入口変更・前だけ・後だけの成立取引へ分解。',
                       '未参加や決済後の仮想利益・機会損失は計算しない。'],
              '市場閾値変更': False, '採用': False, '研究目標達成': False}
    ref = lib.write(output / '結果.json', result)
    print(json.dumps({'成功': True, '場数': n, '対照数': len(rows), '結果': ref}, ensure_ascii=False))


if __name__ == '__main__':
    main()
