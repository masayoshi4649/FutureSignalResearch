# 112 実名政策の独立保護監査

停止111のP算術を明示派生し、112のS0/W100/B100/W400/P100/P400を本名のまま検算する。policyを旧名へ変換せず、C/Bをマスクせず、Entry.ATRを倍にしない。definitionの8field、全玉H100、通常幅200/400と2/4ATR、M AND P、technical_narrowingを独立に期待計算する。

API：`verify_protection(book,config,finance,context)->dict`。financeは112会計`金融の独立検算.verify_finance`の結果、contextはRootActualのscope/publications/resets/counts/final_chart原値。監査keyはprotection112。W100/B100の自己保護reasonは固定111対照の文字列を維持し、新三政策は112の実名理由を検査する。

Go期待値は呼ばず、PythonのFractionと半円単位、三値で照合する。起動点・隣接sequence・明示BeforeSnapshotはexact、その他の少数保存点は旧Lの可解区間とpostL/床/峰の必要条件をboundedとして別計数する。未保存の中間要求は会計/要求MTMまでで、全純状態を復元したとはしない。同秒の公表原行Index/reset統合順、次正常原行の最初性は保存証拠の限界を継承する。

```powershell
python .\保護監査の人工検査.py --stop .\P停止.json
```

手計算8主、RootがSHA付きで明示したCore112手製買売48冊、定義/政策偽装/Cマスクの破壊反例、Python AST差を検査する。Core人工は自然FAR生成や実市場の成績ではない。旧111追加24冊を別の市場結果として混ぜない。停止後は同じPコードを保存器へ接続する。

原板・市場・価格CSV・11月09日・金融再走・未参加/退出後仮想利益を使用しない。純112/Actor112/旧P111/会計の実物指紋と前後同体を停止へ記録する。
