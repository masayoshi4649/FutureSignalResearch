"""112の実名政策を手計算・破壊例・Root手製48冊で独立検算する。"""

import argparse
import ast
from copy import deepcopy
from datetime import datetime, timezone
from decimal import Decimal
import gzip
import hashlib
import json
from pathlib import Path
import unittest

import 新保護の独立監査 as P


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OLD_P = ROOT / 'work/111連続保護の独立保存/新保護の独立監査.py'
OLD_P_SHA = '85be246502840083f511800081d7ccaf0bd8c97ad681b0f72d2c612552ddc420'
PURE_STOP = ROOT / 'work/112支持否定の必須確認と通常幅のみ/停止.json'
PURE_SHA = 'b7748c29ae5c6bc44a66a112421809f888c85321652a0d9bfbb3c7f4022dd835'
ACTOR_STOP = ROOT / 'work/112支持否定と広い通常幅の会計/Actor停止.json'
ACTOR_SHA = '54dc421f0c35cbd5736725955a02fb6cd11f70f3c8a7b646b954722781264006'
FIXTURE = ROOT / 'work/112支持否定と通常幅の連続比較/人工_独立保存用/人工.json'
FIXTURE_SHA = '2e02ce0e255583546f4b631a53667a5e710b585d92f6dbe79cb0ee68ee2b5619'
DEFINITIONS = {
    'W100': (200, 2, 'M AND(C OR P)', False),
    'B100': (200, 2, 'M AND(C OR B OR P)', True),
    'W400': (400, 4, 'M AND(C OR P)', False),
    'P100': (200, 2, 'M AND P', True),
    'P400': (400, 4, 'M AND P', True),
}


def digest(path: Path) -> str:
    """機能: 明示した人工・コード・停止metadataの実物SHA256を返す。

    引数: path(Path)は非市場ファイル。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_ref(path: Path, expected: str, compressed=False) -> dict:
    """機能: Root解禁の人工だけを指紋認証後に読む。

    引数: path(Path)、expected(str)、compressed(bool)は許可済み参照。
    返り値: dictはDecimalを保つ人工JSON。
    """
    raw = path.read_bytes()
    P.need(hashlib.sha256(raw).hexdigest() == expected, '人工又は停止のSHA差')
    return json.loads(gzip.decompress(raw) if compressed else raw, parse_float=Decimal)


def initial(policy='W100', side=1, slip=0, atr=False) -> dict:
    """機能: 宣言値を呼ばず、手計算の初期状態を明示して作る。

    引数: policy(str)、side/slip(int)、atr(bool)は実名/鏡像/費用/ATR150の人工。
    返り値: dictは価格1000・q0=2の手製状態。
    """
    minimum, multiple, formula, tech = DEFINITIONS[policy]
    definition = {'version': 112, 'policy': policy, 'enabled': True, 'threshold_points': 100,
                  'normal_width_minimum': minimum, 'atr_multiplier': multiple,
                  'warning_formula': formula, 'technical_narrowing': tech}
    width = (600 if minimum == 400 else 300) if atr else minimum
    entry = {'scope': {'session': '人工場', 'contract': '人工限月', 'start': 0}, 'policy': policy,
             'side': side, 'price': 1000, 'at': 10, 'initial_quantity': 2, 'slip_points': slip,
             'atr': {'id': '取得ATR', 'value': 150, 'available_at': 10} if atr else None}
    return {'definition': definition, 'entry': entry, 'threshold_points': 100,
            'normal_width': width, 'atr_unknown_fallback': not atr, 'cost_per_unit_yen': 77 if slip == 0 else 1077,
            'minimum_floor': 10 if slip == 0 else 20, 'active': False, 'activated_at': None,
            'narrowed': False, 'narrowed_at': None, 'peak_points': None, 'width_points': width,
            'floor_points': None, 'whole_target_yen': 0, 'closed_net_yen': 0,
            'remaining': 2, 'reserved': 0, 'latest': None, 'at': 10, 'sequence': 0, 'finished': False}


def point(before: dict, gain, seq: int, phase='pre_fill', **changes) -> dict:
    """機能: 期待算術を含めず保存点の器を作る。

    引数: before(dict)、gain(number/None)、seq(int)、phase(str)、changes(dict)は人工入力。
    返り値: dictは期待Snapshot/Decisionを手で記入する器。
    """
    snapshot = deepcopy(before)
    snapshot.update(at=20+seq, sequence=seq)
    snapshot.update(changes)
    quote = None if gain is None else {'index': seq, 'source_line': seq, 'time': snapshot['at'],
                                     'bid': 1000 + before['entry']['side'] * gain,
                                     'ask': 1000 + before['entry']['side'] * gain}
    decision = {**{k: 0 for k in ('c', 'm', 'p', 'b', 'warning')},
                **{k: None for k in P.PRICE_KEYS}, 'activated_now': False, 'narrowed_now': False,
                'width_source': '', 'protect_price_valid': False, 'floor_hit': False, 'all_reserved_hit': False,
                'free_quantity': snapshot['remaining']-snapshot['reserved'], 'eligible_exit_quantity': 0}
    return {'at': snapshot['at'], 'phase': phase, 'quote': quote, 'snapshot': snapshot,
            'decision': decision, 'exit_order_id': ''}


def activated(policy='W100', side=1, slip=0, atr=False) -> tuple[dict, dict]:
    """機能: H100の起動点を明示した整数期待値で作る。

    引数: policy/side/slip/atrはinitialと同じ型。返り値: tuple[dict,dict]は初期状態と手計算点。
    """
    old = initial(policy, side, slip, atr)
    gain, floor, fw = (105, 10, 5) if slip == 0 else (115, 20, 15)
    p = point(old, gain, 1)
    p['snapshot'].update(active=True, activated_at=21, peak_points=gain, floor_points=floor, whole_target_yen=1846)
    p['decision'].update(gain_points=gain, unit_net_yen=10423, whole_net_yen=20846,
                         activated_now=True, width_source='取得時固定通常幅', whole_floor=fw,
                         peak_floor=gain-old['normal_width'], protect_price=1000+side*floor, protect_price_valid=True)
    return old, p


def publication(entry: dict, p_value: int) -> dict:
    """機能: 生C/B真を保ったままPの真偽未知だけを価格関係で作る。

    引数: entry(dict)、p_value(int)は取得とP三値。返り値: dictは手製公表。
    """
    side = entry['side']
    pivot = None if p_value == 0 else {'scope': entry['scope'], 'id': 'prior', 'kind': 'low' if side == 1 else 'high',
                                     'price': 1000+side*50, 'center_start': 0, 'center_end': 180,
                                     'confirm_end': 180, 'published_at': 180}
    return {'scope': entry['scope'], 'id': '公表', 'ordinal': 1, 'start': 0, 'end': 180, 'available_at': 180,
            'c': 2, 'm': 2, 'v': 20, 'close': 1000+side*(45 if p_value == 2 else 100),
            'prior_pivot': pivot, 'bb': {'contraction': 2}}


class PureAuditTests(unittest.TestCase):
    """112の新分岐と継承する全玉算術を別の手計算で確認する。"""

    def test_真の定義と取得ATRを偽装しない(self):
        """機能: 6政策の定義を独立値へ照合し、幅/ATR/Policyの改変を拒否する。

        引数: self(TestCase)。返り値: None。
        """
        for policy in DEFINITIONS:
            for atr in (False, True):
                old = initial(policy, atr=atr)
                P.check_state_fixed(old, old['entry'])
                damaged = deepcopy(old)
                damaged['definition']['atr_multiplier'] += 2
                with self.assertRaises(ValueError):
                    P.check_state_fixed(damaged, old['entry'])
                damaged = deepcopy(old)
                damaged['normal_width'] += 5
                with self.assertRaises(ValueError):
                    P.check_state_fixed(damaged, old['entry'])
        self.assertFalse(P.definition_for('S0')['enabled'])
        for unknown in ('U100', 'T100', 'B50'):
            with self.assertRaises(ValueError):
                P.definition_for(unknown)

    def test_全5政策同じH100と買売費用(self):
        """機能: 全玉H100を、幅やP条件と独立に必須起動する。

        引数: self(TestCase)。返り値: None。
        """
        for policy in DEFINITIONS:
            for side in (1, -1):
                for slip in (0, 5):
                    old, p = activated(policy, side, slip)
                    P.verify_exact_point(old, p)
                    below = point(old, 100, 1)
                    unit = 9923 if slip == 0 else 8923
                    below['decision'].update(gain_points=100, unit_net_yen=unit, whole_net_yen=unit*2)
                    P.verify_exact_point(old, below)

    def test_広幅だけの差とATR150の保持(self):
        """機能: 200/400と2/4ATRの実定義を別の手計算床へ照合する。

        引数: self(TestCase)。返り値: None。
        """
        for policy in DEFINITIONS:
            for atr in (False, True):
                _, first = activated(policy, atr=atr)
                old = first['snapshot']
                wide = policy in ('W400', 'P400')
                floor = (10 if wide else 300) if atr else (200 if wide else 400)
                target = {10: 1846, 200: 39846, 300: 59846, 400: 79846}[floor]
                p = point(old, 600, 2, peak_points=600, floor_points=floor, whole_target_yen=target)
                p['decision'].update(gain_points=600, unit_net_yen=59923, whole_net_yen=119846,
                                     width_source='取得時固定通常幅', whole_floor=10,
                                     peak_floor=600-old['normal_width'], protect_price=1000+floor, protect_price_valid=True)
                P.verify_exact_point(old, p)
                if atr:
                    self.assertEqual(p['snapshot']['entry']['atr']['value'], 150)

    def test_P偽未知でもCとB真を保持して通常追尾(self):
        """機能: M AND Pを本名で計算しC/Bのマスクをせず旧Bを対照にする。

        引数: self(TestCase)。返り値: None。
        """
        for policy in DEFINITIONS:
            for side in (1, -1):
                for truth in (0, 1, 2):
                    old = activated(policy, side)[1]['snapshot']
                    pub = publication(old['entry'], truth)
                    narrowed = policy == 'B100' or policy in ('P100', 'P400') and truth == 2
                    warning = 2 if policy not in ('P100', 'P400') else truth
                    p = point(old, 100, 2, latest=pub, at=600)
                    p['at'] = p['quote']['time'] = 600
                    p['decision'].update(c=2, m=2, p=truth, b=2, warning=warning,
                                         gain_points=100, unit_net_yen=9923, whole_net_yen=19846,
                                         width_source='取得時固定通常幅', whole_floor=10,
                                         peak_floor=105-old['normal_width'], protect_price=1000+side*10, protect_price_valid=True)
                    if narrowed:
                        p['snapshot'].update(narrowed=True, narrowed_at=600, width_points=20,
                                             floor_points=85, whole_target_yen=16846)
                        p['decision'].update(narrowed_now=True, width_source='狭幅現V', peak_floor=85,
                                             protect_price=1000+side*85)
                    P.verify_exact_point(old, p)

    def test_半円部分返済と先行損失をL床へ入れる(self):
        """機能: q0を維持しR/nから全玉床を厳密ceilする。

        引数: self(TestCase)。返り値: None。
        """
        for policy in DEFINITIONS:
            old = activated(policy)[1]['snapshot']
            p = point(old, 50, 2, 'after_source', remaining=1, closed_net_yen=-9076.5,
                      floor_points=110, whole_target_yen=1846.5)
            p['decision'].update(gain_points=50, unit_net_yen=4923, whole_net_yen=-4153.5,
                                 width_source='取得時固定通常幅', whole_floor=110,
                                 peak_floor=105-old['normal_width'], protect_price=1110,
                                 protect_price_valid=True, floor_hit=True, eligible_exit_quantity=1)
            P.verify_exact_point(old, p)
            damaged = deepcopy(p)
            damaged['decision']['whole_floor'] = 105
            with self.assertRaises(ValueError):
                P.verify_exact_point(old, damaged)
        self.assertEqual(P.ceil_multiple((77-600)/100), -5)

    def test_床等号全予約とnil価格最終残0(self):
        """機能: 位相/予約/価格未知/残0を区別し架空価格を作らない。

        引数: self(TestCase)。返り値: None。
        """
        for policy in DEFINITIONS:
            old = activated(policy)[1]['snapshot']
            for reserved in (0, 2):
                p = point(old, 10, 2, 'after_source', reserved=reserved)
                p['decision'].update(gain_points=10, unit_net_yen=923, whole_net_yen=1846,
                                     width_source='取得時固定通常幅', whole_floor=10,
                                     peak_floor=105-old['normal_width'], protect_price=1010,
                                     protect_price_valid=True, floor_hit=True, all_reserved_hit=reserved == 2,
                                     eligible_exit_quantity=2-reserved)
                P.verify_exact_point(old, p)
            P.verify_exact_point(old, point(old, None, 2))
            ended = point(old, 10, 2, remaining=0, closed_net_yen=1846, finished=True)
            P.verify_exact_point(old, ended)

    def test_未知三値のANDを偽へ潰さない(self):
        """機能: P未知/M偽とP偽/M未知を三値真理表どおり扱う。

        引数: self(TestCase)。返り値: None。
        """
        self.assertEqual(P.truth_and(2, 0), 0)
        self.assertEqual(P.truth_and(1, 0), 1)
        self.assertEqual(P.truth_and(0, 1), 1)
        self.assertEqual(P.truth_and(2, 2), 2)
        self.assertEqual(P.warnings(None, 'P400', -1), {'c': 0, 'm': 0, 'p': 0, 'b': 0, 'warning': 0})

    def test_旧L区間とexactを区別(self):
        """機能: 保存間隔が空く場合も可解旧Lと現在床を検査する。

        引数: self(TestCase)。返り値: None。
        """
        old, p = activated('W400')
        p['snapshot']['sequence'] = 9
        P.verify_bounded_point(p, old)
        damaged = deepcopy(p)
        damaged['decision']['whole_floor'] = -500
        with self.assertRaises(ValueError):
            P.verify_bounded_point(damaged, old)


def core_fixture() -> dict:
    """機能: Root解禁の112手製48冊を全会計/P照合し定義/生Cの破壊を拒否する。

    引数: なし。返り値: dictは件数・入力指紋・破壊例。市場は読まない。
    """
    manifest = read_ref(FIXTURE, FIXTURE_SHA)
    P.need(manifest['人工'] is True and manifest['市場'] is False and manifest['試行'] == 112 and manifest['会計数'] == 48,
           'Root手製112だけ')
    total, books, mutations, refs = {}, 0, [], {}
    for name, ref in manifest['Native'].items():
        if name.endswith('_111'):
            continue
        data = read_ref(Path(ref['path']), ref['sha256'], True)
        P.need(data['trial'] == 112 and data['actual']['trial'] == 112, '112実名包み')
        refs[ref['path']] = ref['sha256']
        actual = data['actual']
        context = {k: actual[k] for k in ('scope', 'publications', 'resets', 'counts', 'final_chart')}
        P.need(len(actual['books']) == 24, '112本名24冊')
        for book_value in actual['books'].values():
            finance = P.FINANCE.verify_finance(book_value, book_value['config'])
            result = P.verify_protection(book_value, book_value['config'], finance, context)
            books += 1
            for key, value in result['counts'].items():
                total[key] = total.get(key, 0) + value
        original = actual['books']['P400_C0_D0']
        for label in ('幅倍率', '政策偽装', 'Cマスク'):
            damaged = deepcopy(original)
            position = damaged['positions'][0]
            audit = position['protection112']
            if label == '幅倍率':
                audit['initial']['definition']['atr_multiplier'] = 2
            elif label == '政策偽装':
                audit['initial']['entry']['policy'] = 'W100'
            else:
                trace = next(audit[k] for k in P.TRACE_NAMES if audit[k] is not None and audit[k]['snapshot']['latest'] is not None)
                trace['snapshot']['latest']['c'] = 1 if trace['snapshot']['latest']['c'] != 1 else 2
            try:
                P.verify_protection(damaged, damaged['config'], P.FINANCE.verify_finance(damaged, damaged['config']), context)
            except ValueError:
                mutations.append(label)
            else:
                raise ValueError('112破壊を未検出/' + label)
    P.need(books == 48, '112手製の買売48冊')
    return {'冊数': books, 'counts': total, '破壊検出数': len(mutations), '破壊': mutations,
            'manifest': {'path': str(FIXTURE), 'sha256': FIXTURE_SHA}, '人工本体': refs,
            '市場': False, '自然FAR通知': False, '旧111追加24は読取/再検査していない': True}


def ast_difference() -> dict:
    """機能: 停止P111から変更した独立算術関数を列挙する。

    引数: なし。返り値: dictはPython ASTの関数差。Go期待値を呼ばない。
    """
    P.need(digest(OLD_P) == OLD_P_SHA, '停止P111実物差')
    old = {n.name: ast.dump(n, include_attributes=False) for n in ast.parse(OLD_P.read_text(encoding='utf-8')).body if isinstance(n, ast.FunctionDef)}
    new_path = HERE / '新保護の独立監査.py'
    new = {n.name: ast.dump(n, include_attributes=False) for n in ast.parse(new_path.read_text(encoding='utf-8')).body if isinstance(n, ast.FunctionDef)}
    changed = sorted(n for n in old.keys() & new.keys() if old[n] != new[n])
    P.need(set(changed) == {'warnings', 'fixed_parameters', 'check_state_fixed', 'expected_point', 'verify_bounded_point', 'verify_protection'}, '予定したP112関数差')
    P.need(set(new)-set(old) == {'definition_for'} and not set(old)-set(new), 'P112の追加/削除差')
    return {'変更': changed, '追加': ['definition_for'], '削除': [], '旧': {'path': str(OLD_P), 'sha256': OLD_P_SHA}}


def main() -> None:
    """機能: 手計算とRoot人工を同体コードで照合しP112停止JSONへ保存する。

    引数: CLI --stop(Path)は任意の新規停止先。返り値: None。市場を開かない。
    """
    parser = argparse.ArgumentParser(description='112実名政策の独立P監査の人工')
    parser.add_argument('--stop', type=Path)
    args = parser.parse_args()
    owned_paths = [HERE / '新保護の独立監査.py', Path(__file__).resolve(), HERE / 'README.md']
    before = {str(p): digest(p) for p in owned_paths}
    refs = {str(PURE_STOP): PURE_SHA, str(ACTOR_STOP): ACTOR_SHA, str(OLD_P): OLD_P_SHA,
            str(P.FINANCE_PATH): digest(P.FINANCE_PATH), str(P.FINANCE.PREVIOUS_PATH): P.FINANCE.PREVIOUS_SHA,
            str(P.FINANCE.OLD.BASE_PATH): P.FINANCE.OLD.BASE_SHA}
    P.need(all(digest(Path(p)) == h for p, h in refs.items()), '純/Actor/会計の停止実物差')
    tests = unittest.defaultTestLoader.loadTestsFromTestCase(PureAuditTests)
    result = unittest.TextTestRunner(verbosity=2).run(tests)
    P.need(result.wasSuccessful(), '112手計算の不一致')
    fixture = core_fixture()
    difference = ast_difference()
    P.need(before == {p: digest(Path(p)) for p in before}, 'P112所有前後変更')
    P.need(all(digest(Path(p)) == h for p, h in refs.items()), 'P112停止依存前後変更')
    stop = {'試行': 112, '成功': True, '市場前': True, 'UTC': datetime.now(timezone.utc).isoformat(),
            '所有ファイルSHA256': before, '所有前後同体': True, '依存': refs, '依存前後同体': True,
            '手計算主人工数': result.testsRun, 'Root_API人工': fixture, 'Python_AST差': difference,
            'API': 'verify_protection(book,config,finance,context)->dict。不整合はValueError。',
            '金融再走': False, 'Go期待値呼出': False, '政策/ATR/C/B偽装': False,
            '証明範囲': '本名112と全definitionを独立固定。旧P111のexact/bounded監査を継承。',
            '限界': ['全原行を別エンジンで再走しない。', '非隣接点の旧L/峰の完全再現や全要求の純状態を証明しない。',
                     '原行Indexを保存しない公表は同秒因果/reset統合順の完全証明をしない。', 'Raw未読で次正常原行の最初性を証明しない。'],
            '市場/Raw/価格CSV/11月09日本文': False, '未参加/退出後仮想利益': False}
    if args.stop:
        P.need(not args.stop.exists(), '既存P停止を上書きしない')
        args.stop.write_text(json.dumps(stop, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '主人工': result.testsRun, 'Root48': fixture['counts']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
