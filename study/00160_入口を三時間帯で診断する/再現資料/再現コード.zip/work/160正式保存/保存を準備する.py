"""第160試行の小さい再現源と入力参照を、正式化前のステージへ保存する。"""
from __future__ import annotations

from pathlib import Path
import ast
import datetime
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
TRIAL = ROOT / 'study/00160_入口を三時間帯で診断する'
SOURCE = ROOT / 'work/160時間帯診断'


def sha(path: Path) -> str:
    """
    機能: 対象ファイルを一定サイズで読み、物理SHA256を求める。
    引数: path (Path) 指紋を調べるファイル。
    返り値: str 型の十六進SHA256。
    """
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def save_json(path: Path, value: object) -> None:
    """
    機能: 小さい索引や保存票をUTF-8で新規保存する。
    引数: path (Path) 保存先、value (object) JSONへ直列化できる値。
    返り値: None。既存ファイルは上書きしない。
    """
    with path.open('x', encoding='utf-8', newline='\n') as target:
        json.dump(value, target, ensure_ascii=False, indent=2, allow_nan=False)
        target.write('\n')


def reference(path: Path, decoded: str | None = None) -> dict:
    """
    機能: 大入力を複写せず、由来path・サイズ・SHAだけを記録する。
    引数: path (Path) 原本、decoded (str | None) 条件に記録された解凍SHA。
    返り値: dict 型の参照情報。解凍再検査を本保存で行ったとは記録しない。
    """
    return {
        'path': path.relative_to(ROOT).as_posix(),
        'bytes': path.stat().st_size,
        'sha256': sha(path),
        '解凍SHA256の参照値': decoded,
        '本保存による解凍再走査': False,
    }


def main() -> None:
    """
    機能: 固定源同体とZIPの全格納bytes/CRCを確認してステージを作る。
    引数: なし。
    返り値: None。自然診断・学習・CSV生成は実行せず、正式保存の完了を主張しない。
    """
    expected_spec = 'fe8fe057f137008df5eba43b953d6e4e66d3bd3e07266971b1c8cdbe57acc3a9'
    expected_f0 = '77bbcde9e4a8a82db1e7600d70a168833e318dd6ca6b1943f7cde43c119709ec'
    specification = TRIAL / '実行条件.md'
    f0_path = TRIAL / '検査/診断再開前のソース固定.json'
    assert sha(specification) == expected_spec and sha(f0_path) == expected_f0
    f0 = json.loads(f0_path.read_bytes())
    for name, digest in f0['ソース'].items():
        assert sha(ROOT / name) == digest, name

    # ----------------------------------------
    # 根拠入力は巨大な原文を再保存せず、停止源の定数と現物へ束縛する。
    syntax = ast.parse((SOURCE / '診断する.py').read_text(encoding='utf-8'))
    input_node = next(
        item.value for item in syntax.body
        if isinstance(item, ast.Assign)
        and any(isinstance(target, ast.Name) and target.id == 'INPUTS' for target in item.targets)
    )
    fixed_inputs = ast.literal_eval(input_node)
    inputs = {}
    for name, (relative, physical, decoded) in fixed_inputs.items():
        path = ROOT / relative
        inputs[name] = reference(path, decoded)
        assert inputs[name]['sha256'] == physical

    # ----------------------------------------
    # 現行6小源、初回固定源ZIP、事前票を元の相対配置で保存する。
    source_names = (
        '条件を作成する.py', '診断する.py', '逐次読取.py', '人工検査.py',
        'CSVへ出力する.mjs', 'CSVを独立再読する.py', '初回固定のコード.zip',
        '完了票を回復する.py',
    )
    evidence_names = (
        '診断条件の固定.json', '診断前のソース固定.json',
        '診断再開前のソース固定.json', '初回実行の管理参照消失.json',
        '完了票の回復.json',
    )
    files = [SOURCE / name for name in source_names]
    files += [specification] + [TRIAL / '検査' / name for name in evidence_names]
    files += [TRIAL / '成果物/完了の確認.json', Path(__file__).resolve()]
    assert len(files) == len(set(files)) == 16
    initial = SOURCE / '初回固定のコード.zip'
    with zipfile.ZipFile(initial) as previous:
        assert previous.testzip() is None
        old_f0 = json.loads((TRIAL / '検査/診断前のソース固定.json').read_bytes())
        for name, digest in old_f0['ソース'].items():
            assert hashlib.sha256(previous.read(name.replace('\\', '/'))).hexdigest() == digest

    manifest = {
        '試行': 160,
        '保存範囲': '事前固定源と後発CSV源の保存ステージ。自然結果の最終保存ではない。',
        'コードとCSV源が全てF0前だったとは主張しない': True,
        '大入力と金融本文とCSVを重複格納しない': True,
        '格納': {},
    }
    archive = HERE / '再現コード.zip'
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as target:
        for file in files:
            body = file.read_bytes()
            name = file.relative_to(ROOT).as_posix()
            digest = hashlib.sha256(body).hexdigest()
            target.writestr(name, body)
            manifest['格納'][name] = {'sha256': digest, 'bytes': len(body)}
        target.writestr('manifest.json', (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    with zipfile.ZipFile(archive) as source:
        assert source.testzip() is None
        assert set(source.namelist()) == set(manifest['格納']) | {'manifest.json'}
        for name, item in manifest['格納'].items():
            body = source.read(name)
            assert len(body) == item['bytes'] and hashlib.sha256(body).hexdigest() == item['sha256']
            assert sha(ROOT / name) == item['sha256'], name

    # ----------------------------------------
    # 実行中断と完了票のpath失敗を、診断本体の変更や成功へ読み替えない。
    sdk_path = Path('C:/Users/masay/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@oai/artifact-tool/package.json')
    sdk = json.loads(sdk_path.read_bytes())
    index = {
        '成功': True,
        '試行': 160,
        '保存日時UTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        '段階': 'Root完了票回復後、CSV・独立確認待ちのステージ',
        '実行条件': reference(specification),
        '再開前F0': reference(f0_path),
        '入力参照': inputs,
        '環境': {
            'Python': f0['Python'], 'tzdata': f0['tzdata'], 'Node': 'v24.22.1',
            'artifact-tool': sdk['version'], 'SDKのmetadataSHA256': sha(sdk_path),
            'SDKを同梱しない': True,
        },
        'コードZIP': reference(archive),
        '格納源': manifest['格納'],
        '保存作業の自然診断再実行': False,
        '保存作業のCSV生成': False,
        '保存作業の学習': False,
        '保存作業のRaw読取': False,
        '最終保存の完了は未主張': True,
        '後発で追加する資料': ['最新CSV3表の指紋', '独立照合の票と小源'],
    }
    save_json(HERE / 'ステージ索引.json', index)
    save_json(HERE / 'ステージの確認.json', {
        '成功': True, '試行': 160, '全16格納源bytes同体': True, 'ZIP全CRC成功': True,
        '初回ZIPと初回F0の全源同体': True, '再開前F0の現物源同体': True,
        'コードZIP_SHA256': sha(archive), '索引SHA256': sha(HERE / 'ステージ索引.json'),
        '保存器SHA256': sha(Path(__file__)), '自然再実行': False,
        'Rootの金融数値や独立結果を確認した票ではない': True,
    })
    print(json.dumps({
        '成功': True, '段階': 'ステージ', '格納源数': len(files),
        'ZIP_SHA256': sha(archive), '索引SHA256': sha(HERE / 'ステージ索引.json'),
        'artifact-tool': sdk['version'],
    }, ensure_ascii=False))


if __name__ == '__main__':
    main()
