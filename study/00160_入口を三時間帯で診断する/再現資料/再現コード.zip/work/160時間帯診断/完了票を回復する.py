"""診断済み2JSONを変えず、完了票だけの相対path例外を回復する。"""
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
STUDY=ROOT/'study/00160_入口を三時間帯で診断する'


def sha(path: Path) -> str:
    """
    機能: 全ファイルの物理SHA256を逐次計算する。
    引数: path (Path)。返り値: str 型のSHA256。
    """
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()


def main() -> None:
    """
    機能: 完読証拠とSource不変を確認し、既存成果物の完了票を新規保存する。
    引数: なし。返り値: None。原板・自然ラベル再分類・金融再計算は行わない。
    """
    out=STUDY/'成果物';f0path=STUDY/'検査/診断再開前のソース固定.json'
    assert sha(f0path)=='77bbcde9e4a8a82db1e7600d70a168833e318dd6ca6b1943f7cde43c119709ec'
    f0=json.loads(f0path.read_bytes())
    for file,h in f0['ソース'].items():assert sha(ROOT/file)==h
    before={p.name:sha(p) for p in out.glob('*.json')}
    assert set(before)=={'型付き三表.json','小さい取得対応.json'}
    table=json.loads((out/'型付き三表.json').read_bytes())
    rows=json.loads((out/'小さい取得対応.json').read_bytes())
    assert table['success'] and rows['success'] and table['trial']==rows['trial']==160
    assert len(rows['rows'])==837 and len(rows['scenes'])==73
    assert sum(len(r['memberships']) for r in rows['rows'])==924
    assert {k:len(t['rows']) for k,t in table['tables'].items()}=={'入口時間帯別':54,'出口時間帯別':54,'全セッション':1314}
    assert table['inputs']==rows['inputs']
    for ref in table['inputs'].values():
        assert sha(ROOT/ref['path'])==ref['sha256']
        if ref['path'].endswith('.gz'):
            assert ref['all_scenes']==73 and ref['gzip_crc_checked']
    log=ROOT/'work/160時間帯診断/再開_stderr.log'
    body=log.read_text(encoding='utf-8')
    assert 'ValueError' in body and 'relative_to' in body and '73' in body
    assert before=={p.name:sha(p) for p in out.glob('*.json')}
    evidence={'成功':True,'試行':160,'元運転は完了票の相対path処理で例外終了':True,
              '数値出力後の停止':'p.relative_to(ROOT) で相対Pathと絶対ROOTを比較したValueError',
              '回復範囲':'2JSONの保存確認と完了票のみ。元コマンドの正常終了を主張しない。',
              '入力の全73場CRC完読証拠を確認':True,'数値2JSON不変更':True,'固定Source不変更':True,
              'Raw読取':False,'自然再分類と金融再計算':False,
              '出力':{p.name:{'path':str(p.resolve().relative_to(ROOT)),'sha256':sha(p),'bytes':p.stat().st_size} for p in out.glob('*.json')},
              '入力':table['inputs'],'回復器SHA256':sha(Path(__file__)),'例外ログSHA256':sha(log)}
    for p in (out/'完了の確認.json',STUDY/'検査/完了票の回復.json'):
        assert not p.exists()
        p.write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'出力':evidence['出力'],'数値再計算':False},ensure_ascii=False))


if __name__=='__main__':
    main()
