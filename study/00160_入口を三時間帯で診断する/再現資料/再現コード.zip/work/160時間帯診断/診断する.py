"""固定837取得を三時間帯へ分類し、旧先着と現行出口損益を別時計で診断する。"""
from __future__ import annotations
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
import argparse
import hashlib
import json
import math
import sys

import 逐次読取 as reader

ROOT=Path(__file__).resolve().parents[2]
STUDY=ROOT/'study/00160_入口を三時間帯で診断する'
BASES=('153U15','152U0')
BINS=('デイ','ナイト米国前','ナイト米国後')
POLICIES=('F125S125','T125W100TP250','A11_PROFIT_BUDGET')
SCOPES=('全73場','前48場','後25場')
SPEC_SHA='fe8fe057f137008df5eba43b953d6e4e66d3bd3e07266971b1c8cdbe57acc3a9'
INPUTS={
 'fixed':('inputs/00157_固定入口と価格経路/固定入口入力.json','eabf9819351ef77fec44a7a132a8df13fd8a3aee7c3be6d87ac81dabe34ce279',None),
 'observations':('study/00148_全1分知得から入口品質の母集団を固定する/成果物/固定取得の正逆観測.json.gz','bd809bdf24400628817afee702063504c65682e6748a60e0f32d7690b7363c61','d1b4cab8a258203f04b5c1d081f57d10ed2a0c58ce4cc160ef571d5fac0ceffc'),
 'exits':('study/00158_複合技術で出口の役割と局面を切り替える/成果物/出口結果.json.gz','70a4c3178206bbb3c8641901c7515f2121da11c28403b88c3f8e6f93cc0baa6c','3c3df90244de838056ca7c98857ffe7b8f85514807e90194c07f73129ec277c7'),
}


def us_open(session: str) -> float:
    """
    機能: 場開始日のニューヨーク09:30を夏冬自動調整でUnix秒へ変換する。
    引数: session (str) YYYY-MM-DD_Day/Night。返り値: float 型のUnix秒。
    """
    day=datetime.strptime(session[:10],'%Y-%m-%d')
    return day.replace(hour=9,minute=30,tzinfo=ZoneInfo('America/New_York')).timestamp()


def classify(session: str,at: float) -> dict:
    """
    機能: 実取得の主三区分と旧FAR移行帯を別々に定義する。
    引数: session (str)、at (float) 取得Unix秒。返り値: dict 型の分類。
    """
    assert math.isfinite(at)
    opening=us_open(session)
    if session.endswith('_Day'):
        return {'bin':'デイ','far_window':'デイ','transition':False,'us_open':opening,'crosses_open':False,'dst':None}
    assert session.endswith('_Night')
    return {'bin':'ナイト米国前' if at<opening else 'ナイト米国後',
      'far_window':'旧FAR-P帯' if at<opening-900 else '旧FAR移行帯' if at<opening+900 else '旧FAR-U帯',
      'transition':opening-900<=at<opening+900,'us_open':opening,
      'crosses_open':at<opening<=at+3600,
      'dst':'夏時間' if datetime.fromtimestamp(opening,ZoneInfo('America/New_York')).dst().total_seconds() else '標準時間'}


def old_label(candidate: dict) -> dict:
    """
    機能: 旧厳密H60の完了要件と125先着の記録方向を分離する。
    引数: candidate (dict) 選択streamの旧観測。返り値: dict 型の旧ラベル。
    """
    horizons=[h for h in candidate['outcomes'] if h['seconds']==3600]
    assert len(horizons)==1
    outcome=horizons[0]
    touches=[t for t in outcome['touches'] if t['width']==125]
    assert len(touches)==1
    touch=touches[0];direction=touch['direction']
    assert direction in (-1,0,1)
    state='C' if outcome['status']!='complete' else 'F' if direction==1 else 'A' if direction==-1 else 'N'
    return {'state':state,'recorded_direction':direction,'status':outcome['status'],
            'touch_time':touch.get('quote',{}).get('time') if touch.get('quote') else None,'deadline':outcome['deadline']}


def entry_metrics(rows: list[dict]) -> dict:
    """
    機能: 到達済み・H完了・全取得の三つの分母を保持する。
    引数: rows (list[dict]) 同一群の取得。返り値: dict 型の件数と率。
    """
    counts=Counter(r['old']['state'] for r in rows)
    f,a,n,c=[counts[s] for s in 'FANC']
    ratio=lambda numerator,denominator: numerator/denominator if denominator else None
    return {'取得数':len(rows),'順':f,'逆':a,'未到達':n,'観測不足':c,
            '到達済み先着率':ratio(f,f+a),'H完了分母率':ratio(f,f+a+n),'全取得分母率':ratio(f,len(rows)),
            '取得のある場数':len({r['session'] for r in rows}),
            '移行帯取得数':sum(r['transition'] for r in rows),
            '取得後H60が米国開始を跨ぐ数':sum(r['crosses_open'] for r in rows)}


def money_metrics(rows: list[dict],policy: str) -> dict:
    """
    機能: 現行H60/D1/C5の判明損益と未知、同一取得IFD差を別集計する。
    引数: rows (list[dict])、policy (str)。返り値: dict 型の金額・分母。
    """
    known=[r['money'][policy] for r in rows if r['money'][policy]['status']=='closed']
    profits=[r['profit_yen'] for r in known]
    assert all(v is not None and math.isfinite(v) for v in profits)
    plus=sum(max(0,v) for v in profits);minus=-sum(min(0,v) for v in profits)
    both=[r for r in rows if r['money'][policy]['status']==r['money']['F125S125']['status']=='closed']
    return {'取得数':len(rows),'決済既知':len(known),'損益未知':len(rows)-len(known),
            '利益総額円':plus,'損失総額円':minus,'既知差引円':plus-minus,'PF':plus/minus if minus else None,
            '全件確定差引円':plus-minus if len(known)==len(rows) else None,
            'IFD対応既知数':len(both),'IFD対応差分円':sum(r['money'][policy]['profit_yen']-r['money']['F125S125']['profit_yen'] for r in both)}


def projected(path: Path,wanted: str,decoded: str,callback) -> dict:
    """
    機能: 全場を逐次完読し、物理/解凍指紋・CRCと前後statを検査する。
    引数: path (Path)、wanted/decoded (str)、callback (Callable)。返り値: dict 型の証拠。
    """
    before=path.stat();assert reader.sha(path)==wanted
    evidence={};count=0
    for scene in reader.scenes(path,evidence):
        callback(scene,count);count+=1
        if count%12==0:print(f'{path.name}：{count}/73場完読',file=sys.stderr)
    assert count==73 and evidence['decoded_sha256']==decoded
    after=path.stat();assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns)
    assert reader.sha(path)==wanted
    return {'path':str(path.relative_to(ROOT)),'sha256':wanted,'decoded_sha256':decoded,
            'physical_bytes':after.st_size,'decoded_bytes':evidence['decoded_bytes'],'all_scenes':count,'gzip_crc_checked':True}


def acquire() -> tuple[list[dict],list[dict],dict]:
    """
    機能: 固定入口に旧先着と現行3出口を実側・取得全Quoteで結合する。
    引数: なし。返り値: tuple の物理行・全場metadata・入力参照。
    """
    relative,h,_=INPUTS['fixed'];p=ROOT/relative
    assert reader.sha(p)==h;fixed=json.loads(p.read_bytes())
    scenes=fixed['scenes'];assert len(scenes)==73
    rows=[];by_id={};references={'fixed':{'path':relative,'sha256':h,'bytes':p.stat().st_size}}
    for index,scene in enumerate(scenes):
        for c in scene['cases']:
            row={'id':c['id'],'session':scene['session'],'session_index':index,'entry_time':c['entry']['time'],
                 'side':c['side'],'stream':c['stream'],'entry_price':c['entry_price'],'entry':c['entry'],
                 **classify(scene['session'],c['entry']['time']),
                 'memberships':[{'policy':m['policy'],'origin':'旧C1' if m['source_selection_ref'].get('origin')=='C1' else '追加入口'} for m in c['memberships']]}
            key=(row['session'],row['id']);assert key not in by_id
            rows.append(row);by_id[key]=row
    assert len(rows)==837 and sum(len(r['memberships']) for r in rows)==924

    # ----------------------------------------
    # 旧先着の完了条件を現行返済の期限へ置換しない。
    found=set()
    def observations(scene: dict,index: int) -> None:
        """
        機能: 一場の旧観測を選択実側へ結ぶ。
        引数: scene (dict)、index (int)。返り値: None。
        """
        assert scene['session']==scenes[index]['session']
        for c in scene['cases']:
            key=(scene['session'],c['id'])
            if key not in by_id:continue
            assert key not in found;found.add(key);row=by_id[key];candidate=c[row['stream']]
            assert candidate['birth']['side']==row['side'] and candidate['status']=='filled'
            assert candidate['entry']==row['entry'] and candidate['entry_price']==row['entry_price']
            row['old']=old_label(candidate)
    relative,h,decoded=INPUTS['observations']
    references['observations']=projected(ROOT/relative,h,decoded,observations)
    assert len(found)==837

    # ----------------------------------------
    # 158の既存金融正本から主時計3政策だけ射影する。
    found=set()
    def exits(scene: dict,index: int) -> None:
        """
        機能: 一場の固定3出口を結ぶ。
        引数: scene (dict)、index (int)。返り値: None。
        """
        assert scene['session']==scenes[index]['session']
        for c in scene['cases']:
            key=(scene['session'],c['id']);assert key in by_id and key not in found;found.add(key);row=by_id[key]
            assert c['side']==row['side'] and c['stream']==row['stream'] and c['entry']==row['entry'] and c['entry_price']==row['entry_price']
            money={}
            for result in c['results']:
                if result['policy'] not in POLICIES or (result['horizon'],result['delay'],result['cost'])!=('H60','D1','C5'):continue
                assert result['policy'] not in money and result['status'] in ('closed','unknown')
                money[result['policy']]={k:result.get(k) for k in ('status','profit_yen','profit_after_positive_loss','profit_after125_loss','held_seconds')}
            assert len(money)==3;row['money']=money
    relative,h,decoded=INPUTS['exits'];references['exits']=projected(ROOT/relative,h,decoded,exits)
    assert len(found)==837
    for base,expected in [('153U15',(93,46,18,22,7)),('152U0',(831,442,280,78,31))]:
        items=[r for r in rows if any(m['policy']==base for m in r['memberships'])]
        m=entry_metrics(items);assert tuple(m[k] for k in ('取得数','順','逆','未到達','観測不足'))==expected
        m=money_metrics(items,'F125S125')
        assert (m['利益総額円'],m['損失総額円'],m['損益未知'])==({'153U15':(545842,327464,7),'152U0':(5328809,4055563,29)}[base])
    metadata=[{k:v for k,v in scene.items() if k not in ('cases','source_scene','raw')} for scene in scenes]
    for row in rows:del row['entry']
    return rows,metadata,references


def scope_match(row: dict,scope: str) -> bool:
    """
    機能: 前後区間を固定場番号で選ぶ。
    引数: row (dict)、scope (str)。返り値: bool 型の所属判定。
    """
    return scope=='全73場' or (row['session_index']<48 if scope=='前48場' else row['session_index']>=48)


def build(rows: list[dict],scenes: list[dict]) -> dict:
    """
    機能: 群別入口・3出口・全セッションの型付き3表を作る。
    引数: rows (list[dict])、scenes (list[dict])。返り値: dict 型の3表。
    """
    entrance=[];financial=[];sessions=[];extra={}
    for base in BASES:
        members=[{**r,'origin':m['origin']} for r in rows for m in r['memberships'] if m['policy']==base]
        for scope in SCOPES:
            scoped=[r for r in members if scope_match(r,scope)]
            for label in BINS:
                selected=[r for r in scoped if r['bin']==label]
                for origin in ('全入口','旧C1','追加入口'):
                    branch=selected if origin=='全入口' else [r for r in selected if r['origin']==origin]
                    m=entry_metrics(branch)
                    entrance.append([base,scope,label,origin,*m.values()])
                for policy in POLICIES:
                    m=money_metrics(selected,policy)
                    financial.append([base,scope,label,policy,*m.values()])
            extra[base+'/'+scope]={}
            for column in ('far_window','dst'):
                extra[base+'/'+scope][column]={value:{'入口':entry_metrics([r for r in scoped if r[column]==value]),
                    '金融':{p:money_metrics([r for r in scoped if r[column]==value],p) for p in POLICIES}}
                    for value in sorted({r[column] for r in scoped if r[column] is not None})}
        for policy in POLICIES:
            for label in BINS:
                cumulative=unknown=0
                for scene in scenes:
                    session=scene['session'];applicable=(session.endswith('_Day'))==(label=='デイ')
                    selected=[r for r in members if r['session']==session and r['bin']==label]
                    assert applicable or not selected
                    e=entry_metrics(selected);m=money_metrics(selected,policy)
                    cumulative+=m['既知差引円'];unknown+=m['損益未知']
                    sessions.append([base,session,label,'対象' if applicable else '対象外',policy,
                        *([e[k] for k in ('取得数','順','逆','未到達','観測不足','到達済み先着率')] if applicable else [None]*6),
                        *([m[k] for k in ('決済既知','損益未知','利益総額円','損失総額円','既知差引円','PF')] if applicable else [None]*6),
                        cumulative if applicable else None,unknown if applicable else None,
                        cumulative if applicable and not unknown else None])
    assert len(entrance)==54 and len(financial)==54 and len(sessions)==1314
    tables={'入口時間帯別':{'headers':['入口','区間','時間帯','入口枝',*entry_metrics([])],'rows':entrance},
      '出口時間帯別':{'headers':['入口','区間','時間帯','出口',*money_metrics([],POLICIES[0])],'rows':financial},
      '全セッション':{'headers':['入口','セッション','時間帯','対象区分','出口','取得数','順','逆','未到達','観測不足','到達済み先着率',
         '決済既知','損益未知','利益総額円','損失総額円','既知差引円','PF','累計既知差引円','累計損益未知','全件確定累計円'],'rows':sessions}}
    assert all(len(row)==len(t['headers']) for t in tables.values() for row in t['rows'])
    return {'success':True,'trial':160,'tables':tables,'補助分類':extra,
      '先着時計':'旧取得後厳密60分・全窓完了要件、±125pt',
      '金融時計':'min(取得+3600, Source強制返済)、H60/D1/C5、ラージBBO・mini1枚換算',
      '区分時計':'実取得の事後分類。新規選択のq0区分とは別','新入口採否':False,'Raw再走査':False}


def main() -> None:
    """
    機能: 事前条件とSource固定を検査して自然の既存ラベル診断を一度保存する。
    引数: CLI --f0/--f0-sha256/--output-dir。返り値: None。
    """
    parser=argparse.ArgumentParser()
    parser.add_argument('--f0',type=Path,required=True);parser.add_argument('--f0-sha256',required=True)
    parser.add_argument('--output-dir',type=Path,required=True);options=parser.parse_args()
    assert reader.sha(STUDY/'実行条件.md')==SPEC_SHA
    assert reader.sha(options.f0)==options.f0_sha256 and not options.output_dir.exists()
    f0=json.loads(options.f0.read_bytes())
    for file,h in f0['ソース'].items():assert reader.sha(ROOT/file)==h
    rows,scenes,references=acquire();result=build(rows,scenes)
    result['inputs']=references;result['specification_sha256']=SPEC_SHA
    options.output_dir.mkdir(parents=True,exist_ok=False)
    for name,value in [('型付き三表.json',result),('小さい取得対応.json',{'success':True,'trial':160,'inputs':references,'scenes':scenes,'rows':rows})]:
        p=options.output_dir/name
        with p.open('x',encoding='utf-8',newline='\n') as target:json.dump(value,target,ensure_ascii=False,allow_nan=False,separators=(',',':'));target.write('\n')
    for file,h in f0['ソース'].items():assert reader.sha(ROOT/file)==h
    done={'成功':True,'試行':160,'物理取得':len(rows),'所属':sum(len(r['memberships']) for r in rows),'入力':references,
          '固定ソース不変':True,'自然学習':False,'Raw読取':False,
          '出力':{p.name:{'path':str(p.relative_to(ROOT)),'sha256':reader.sha(p),'bytes':p.stat().st_size} for p in options.output_dir.glob('*.json')}}
    (options.output_dir/'完了の確認.json').write_text(json.dumps(done,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'取得数':len(rows),'表':{k:len(v['rows']) for k,v in result['tables'].items()}},ensure_ascii=False))


if __name__=='__main__':
    main()
