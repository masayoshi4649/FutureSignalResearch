"""時間帯の等号、夏冬、旧ラベル、未知と対象外を自然値なしで確認する。"""
from pathlib import Path
from datetime import datetime,timedelta
import gzip
import hashlib
import json

import 診断する as diag
import 逐次読取 as reader


def main() -> None:
    """
    機能: 160の5人工群を実行する。
    引数: なし。返り値: None。自然損益・時間帯集計を読み込まない。
    """
    for day,expected in [('2026-09-21','22:30'),('2026-10-30','22:30'),('2026-11-02','23:30'),('2026-11-10','23:30')]:
        opening=diag.us_open(day+'_Night')
        assert datetime.fromtimestamp(opening,diag.ZoneInfo('Asia/Tokyo')).strftime('%H:%M')==expected
        for delta,window in [(-901,'旧FAR-P帯'),(-900,'旧FAR移行帯'),(-1,'旧FAR移行帯'),(0,'旧FAR移行帯'),(899,'旧FAR移行帯'),(900,'旧FAR-U帯')]:
            v=diag.classify(day+'_Night',opening+delta)
            assert v['far_window']==window and v['bin']==('ナイト米国前' if delta<0 else 'ナイト米国後')
            assert v['transition']==(-900<=delta<900)
        assert diag.classify(day+'_Night',opening-3600)['crosses_open']
        assert not diag.classify(day+'_Night',opening-3600.1)['crosses_open']
        assert not diag.classify(day+'_Night',opening)['crosses_open']
        assert diag.classify(day+'_Day',opening)['bin']=='デイ'

    # ----------------------------------------
    for status,direction,state in [('complete',1,'F'),('complete',-1,'A'),('complete',0,'N'),('endpoint_missing',1,'C')]:
        c={'outcomes':[{'seconds':3600,'status':status,'deadline':4000,'touches':[{'width':125,'direction':direction,'quote':{'time':2000} if direction else None}]}]}
        assert diag.old_label(c)['state']==state

    rows=[]
    for i,(status,value) in enumerate([('closed',1000),('closed',-2000),('unknown',None)]):
        rows.append({'session':'A','transition':False,'crosses_open':False,'old':{'state':'FANC'[i]},
                     'money':{p:{'status':status,'profit_yen':value} for p in diag.POLICIES}})
    m=diag.money_metrics(rows,diag.POLICIES[0]);assert m['利益総額円']==1000 and m['損失総額円']==2000 and m['PF']==.5
    assert m['全件確定差引円'] is None and m['損益未知']==1 and m['IFD対応差分円']==0
    e=diag.entry_metrics(rows);assert e['到達済み先着率']==.5 and e['H完了分母率']==1/3 and e['全取得分母率']==1/3

    # ----------------------------------------
    p=Path(__file__).with_name('人工の逐次読取.json.gz')
    fixture={'success':True,'scenes':[{'session':'人工A','cases':[{'text':'日本語}\\"[]','value':123}]}], 'tail':{'known':None}}
    body=(json.dumps(fixture,ensure_ascii=False,indent=2)+'\r\n').encode('utf-8')
    with gzip.open(p,'wb') as target:target.write(body)
    evidence={};got=list(reader.scenes(p,evidence))
    assert got==fixture['scenes'] and evidence['header']['tail']==fixture['tail']
    assert evidence['decoded_sha256']==hashlib.sha256(body).hexdigest() and evidence['decoded_bytes']==len(body)

    # ----------------------------------------
    scenes=[{'session':(datetime(2026,9,21)+timedelta(days=i//2)).strftime('%Y-%m-%d')+('_Day' if i%2==0 else '_Night')} for i in range(73)]
    row={**rows[0],'session':scenes[0]['session'],'session_index':0,'bin':'デイ','far_window':'デイ','dst':None,
         'memberships':[{'policy':base,'origin':'旧C1'} for base in diag.BASES]}
    result=diag.build([row],scenes)
    assert {k:len(v['rows']) for k,v in result['tables'].items()}=={'入口時間帯別':54,'出口時間帯別':54,'全セッション':1314}
    t=result['tables']['全セッション'];data=[dict(zip(t['headers'],v)) for v in t['rows']]
    assert all(r['取得数'] is None for r in data if r['対象区分']=='対象外')
    assert any(r['取得数']==0 for r in data if r['対象区分']=='対象')
    print('成功：夏冬/等号、旧完了ラベル、未知と三分母、逐次CRC/文字列、全場対象外の5人工群')


if __name__=='__main__':
    main()
