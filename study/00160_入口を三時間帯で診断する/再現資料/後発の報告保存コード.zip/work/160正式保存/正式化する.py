"""第160試行の停止済み小源と確認票を正式配置へ同体保存する。"""
from __future__ import annotations

from pathlib import Path, PurePosixPath
import datetime
import hashlib
import io
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
TRIAL = ROOT / 'study/00160_入口を三時間帯で診断する'
REPLAY = TRIAL / '再現資料'
CHECKS = TRIAL / '検査'
VIEW = ROOT / 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/00160_入口の三時間帯診断'


def sha(path: Path) -> str:
    """
    機能: ファイルの全物理bytesからSHA256を計算する。
    引数: path (Path) 指紋化するファイル。
    返り値: str 型の十六進SHA256。
    """
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def save_json(path: Path, value: object) -> None:
    """
    機能: 索引や確認票をUTF-8で新規保存する。
    引数: path (Path)、value (object) JSONへ直列化できる値。
    返り値: None。既存の票を上書きしない。
    """
    with path.open('x', encoding='utf-8', newline='\n') as target:
        json.dump(value, target, ensure_ascii=False, indent=2, allow_nan=False)
        target.write('\n')


def ref(path: Path) -> dict:
    """
    機能: 正式資源や生成物の相対path・サイズ・物理指紋を記録する。
    引数: path (Path) 現存するファイル。
    返り値: dict 型の参照情報。
    """
    resolved = path.resolve()
    assert resolved.is_relative_to(ROOT)
    return {'path': resolved.relative_to(ROOT).as_posix(), 'sha256': sha(resolved), 'bytes': resolved.stat().st_size}


def copy_exact(source: Path, destination: Path, expected: str | None = None) -> dict:
    """
    機能: 指紋を確かめた小さいファイルを同体コピーする。
    引数: source (Path)、destination (Path)、expected (str | None) 期待SHA。
    返り値: dict 型の正式コピー参照。既存先は同体の場合だけ保持する。
    """
    digest = sha(source)
    assert expected is None or digest == expected, str(source)
    assert destination.resolve().is_relative_to(TRIAL)
    if destination.exists():
        assert sha(destination) == digest, str(destination)
    else:
        shutil.copyfile(source, destination)
    assert sha(source) == sha(destination) == digest
    return ref(destination)


def verify_zip(path: Path, compare_current: bool) -> dict:
    """
    機能: 格納bytesとCRC・manifestを検査し、Pythonの構文だけを確認する。
    引数: path (Path)、compare_current (bool) 現在の同名Sourceとの同体も要求するか。
    返り値: dict 型の格納数・Python数。自然処理や人工は起動しない。
    """
    count = syntax_count = nested_count = 0
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        manifest = json.loads(archive.read('manifest.json'))
        items = manifest.get('格納') or manifest.get('files')
        assert isinstance(items, dict)
        assert set(archive.namelist()) == set(items) | {'manifest.json'}
        for name, item in items.items():
            relative = PurePosixPath(name)
            assert not relative.is_absolute() and '..' not in relative.parts
            body = archive.read(name)
            assert len(body) == item['bytes'] and hashlib.sha256(body).hexdigest() == item['sha256']
            if compare_current:
                assert sha(ROOT / name) == item['sha256'], name
            if name.endswith('.py'):
                compile(body.decode('utf-8-sig'), name, 'exec')
                syntax_count += 1
            if name.endswith('.zip'):
                with zipfile.ZipFile(io.BytesIO(body)) as nested:
                    assert nested.testzip() is None
                nested_count += 1
            count += 1
    return {'格納数': count, 'Python構文確認数': syntax_count, '内包ZIPのCRC確認数': nested_count, '全CRC': True}


def main() -> None:
    """
    機能: 再現資料・独立票・CSV確認を正式化し、最終保存票を作る。
    引数: なし。
    返り値: None。既存の数値・条件・Sourceを変更せず、大入力を再走査しない。
    """
    REPLAY.mkdir(exist_ok=True)
    CHECKS.mkdir(exist_ok=True)
    stage = json.loads((HERE / 'ステージ索引.json').read_bytes())
    for name, item in stage['格納源'].items():
        assert sha(ROOT / name) == item['sha256'], name
    assert sha(TRIAL / '実行条件.md') == 'fe8fe057f137008df5eba43b953d6e4e66d3bd3e07266971b1c8cdbe57acc3a9'
    f0 = json.loads((TRIAL / '検査/診断再開前のソース固定.json').read_bytes())
    for name, digest in f0['ソース'].items():
        assert sha(ROOT / name) == digest, name

    # ----------------------------------------
    # 独立票と閲覧用CSVを、それぞれの正本と指紋で結び付ける。
    expected = {
        '型付き三表.json': '64ed7becf05f29bd2e8e740909853080c208b69fff5d6aae81ba710dc21413ec',
        '小さい取得対応.json': 'f856b228a06db69cc26240263f0bf6633e48dbdb1d3f639e4e2f4f2a54f88451',
    }
    generated = {name: ref(TRIAL / '成果物' / name) for name in expected}
    assert {name: item['sha256'] for name, item in generated.items()} == expected
    audit_dir = ROOT / 'work/160独立確認'
    audit_path = audit_dir / '自然確認/独立確認.json'
    assert sha(audit_path) == 'a2dbfb89b7442386c733851d1eda7a827dd8693ce3ecb09c0057f6bb0bb02e62'
    audit = json.loads(audit_path.read_bytes())
    assert audit['成功'] and audit['固定物理取得'] == 837 and audit['所属'] == 924
    assert audit['射影照合末端'] == 30802 and audit['三表照合末端'] == 27895 and audit['補助分類末端'] == 1230
    expected_csv = {
        '入口時間帯別': '5db57073debec1f9a4c42151a61b9291a26f070be2097ca5a0c1efe9e847231f',
        '出口時間帯別': 'd0041836da2b024118937bc944e29b2fd4c029e735b69883d09b7a0d9ec42b9d',
        '全セッション': '23eeb9729b92207a340420b2a32ed83cc469d214b9d303686dfc18b1a8feda32',
    }
    csv_refs = {name: ref(VIEW / (name + '.csv')) for name in expected_csv}
    assert {name: item['sha256'] for name, item in csv_refs.items()} == expected_csv
    csv_proof = json.loads((VIEW / '独立再読.json').read_bytes())
    assert csv_proof['成功'] and sum(item['全セル一致'] for item in csv_proof['表'].values()) == 27895
    assert {name: item['SHA256'] for name, item in csv_proof['表'].items()} == expected_csv
    assert not list(VIEW.glob('*.xlsx'))
    creation = json.loads((VIEW / '作成確認.json').read_bytes())
    assert creation['入力SHA256'] == expected['型付き三表.json']
    assert creation['出力器SHA256'] == sha(ROOT / 'work/160時間帯診断/CSVへ出力する.mjs')
    assert {name: item['SHA256'] for name, item in creation['表'].items()} == expected_csv

    copies = {}
    pairs = (
        (HERE / '再現コード.zip', REPLAY / '再現コード.zip', '71c47ac0f73e5c90412d643a5c0a124085c1ca0c7bbbb2453f2f6a8767737d44'),
        (audit_dir / '独立確認コード.zip', REPLAY / '独立確認コード.zip', '795b3bf9d8d8df25970a0328e9ae1ba067c6654b91c775ddaa0e26ca5dc0e9f6'),
        (audit_path, CHECKS / '時間帯と全数値の独立確認.json', 'a2dbfb89b7442386c733851d1eda7a827dd8693ce3ecb09c0057f6bb0bb02e62'),
        (audit_dir / '停止の確認.json', CHECKS / '独立確認の停止.json', '2b987176dfab6c2d6cd71f5765b4b5b947fae724a8fb3224479ecd55f196309f'),
        (VIEW / '作成確認.json', CHECKS / 'CSV作成の確認.json', None),
        (VIEW / '独立再読.json', CHECKS / 'CSV全セルの標準再読.json', None),
        (HERE / 'ステージの確認.json', CHECKS / '再現資料の準備確認.json', None),
        (HERE / 'ステージの停止.json', CHECKS / '再現資料の初回ステージ停止.json', '9aac1bc9576d47c0475f75dd2dcb2376214a34c82d785c1ca1415961e1cf8645'),
        (ROOT / 'work/160時間帯診断/再開_stderr.log', CHECKS / '再開時の例外ログ.txt', None),
    )
    for source, destination, digest in pairs:
        copies[destination.name] = copy_exact(source, destination, digest)

    # ----------------------------------------
    # 報告生成と今回の正式化は後発小源として別ZIPへ保存する。
    extra_files = [ROOT / 'work/160時間帯診断/報告を作成する.py', Path(__file__).resolve(),
                   HERE / 'ステージ索引.json', HERE / 'ステージの確認.json', HERE / 'ステージの停止.json']
    extra_manifest = {'試行': 160, '金融前F0へ遡及して格納しない': True,
                      '保存目的': '後発の報告来歴と保存小源。既存の正式文書へ再実行して上書きしない。', '格納': {}}
    extra_zip = REPLAY / '後発の報告保存コード.zip'
    with zipfile.ZipFile(extra_zip, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as target:
        for source in extra_files:
            body = source.read_bytes()
            name = source.relative_to(ROOT).as_posix()
            target.writestr(name, body)
            extra_manifest['格納'][name] = {'sha256': hashlib.sha256(body).hexdigest(), 'bytes': len(body)}
        target.writestr('manifest.json', (json.dumps(extra_manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    zip_checks = {path.name: verify_zip(path, True) for path in (
        REPLAY / '再現コード.zip', REPLAY / '独立確認コード.zip', extra_zip)}

    # ----------------------------------------
    # 正式案内は来歴と確認範囲だけを更新し、Root専有の主文書は編集しない。
    text = (HERE / 'README.md').read_text(encoding='utf-8')
    first = 'この文書は正式配置 `study/00160_入口を三時間帯で診断する/再現資料/` に置く前提の案内である。現在の保存作業はステージであり、CSVと独立照合の最終票は後発で追加する。'
    assert first in text
    text = text.replace(first, '第160試行の小源・確認票を正式保存した。[保管索引](保管索引.json)と[保存確認](../検査/再現資料の保存確認.json)に、入力参照・全ZIPの格納指紋・独立票・最新CSV3表の同体を記録する。')
    text = text.replace('Rootと独立側の確認票は、それぞれの対象範囲を分けて後発に保存する。',
                        'Rootと独立側の確認票は、それぞれの対象範囲を分けて後発として正式保存した。')
    text += '''

## 後発の報告と独立照合

[後発の報告保存コードZIP](後発の報告保存コード.zip)へ、Rootの報告生成器と今回の正式化器、初回ステージ索引/票を別保存した。主再現ZIPや旧F0へ追加していない。報告生成器は来歴用であり、完成したREADME・設定表・閲覧案内などへ再実行して上書きしない。Rootが後から加えた文書のリンクと独立状態の追記は、金融・入口の変更とは分ける。

[独立確認コードZIP](独立確認コード.zip)と[時間帯・全数値の独立票](../検査/時間帯と全数値の独立確認.json)を保存した。独立側は2026年JSTの夏冬閉形式とFractionで、作者の時間帯分類・集計器をimportせず計算した。汎用JSON Readerだけは同体共用である。837取得の30,802末端、三表27,895末端（ヘッダー49、データ27,846）、補助分類1,230末端が一致した。金融は2,511状態のうち既知2,422の実返済BBO・費用と、未知89の保持を確認した。

この独立照合は、148観測の全原行再生、利益後赤字フラグや保有秒数の原行からの別再計算、未見データの予測性能確認を意味しない。親の当該フラグと秒数は薄い射影への転記同体を確認した範囲である。独立側にも初回のpath slash表記差による停止があり、私有期待側だけ修正して同じ作者結果へ再照合した履歴を、独立ZIPと票へ保持した。

CSVは[作成票](../検査/CSV作成の確認.json)と[標準CSV全セル再読票](../検査/CSV全セルの標準再読.json)を同体コピーした。入口54行×15列、出口54行×14列、全セッション1,314行×20列、ヘッダーを含む27,895セルが元型付き表と一致する。3表示の視認はRootが実施した。保存作業でCSVや表示画像を再生成していない。

再開時の元の例外ログは[正式コピー](../検査/再開時の例外ログ.txt)として残した。Rootの完了票回復と独立側のメタデータ修正を、元運転の正常終了や自然結果の再計算へ読み替えない。
'''
    readme_path = REPLAY / 'README.md'
    assert not readme_path.exists()
    readme_path.write_text(text, encoding='utf-8', newline='\n')

    index = {
        '成功': True, '試行': 160, '保存日時UTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        '段階': '小源と再現資料の正式保存完了。Root専有の主文書と目次は別確認。',
        '初回ステージの停止SHA256': sha(HERE / 'ステージの停止.json'),
        '条件': ref(TRIAL / '実行条件.md'), '再開前F0': ref(TRIAL / '検査/診断再開前のソース固定.json'),
        '入力参照': stage['入力参照'], '環境': stage['環境'],
        '現行固定Source': stage['格納源'], '後発Source': extra_manifest['格納'],
        '結果は同体参照のみ': generated, 'CSVは同体参照のみ': csv_refs,
        '正式コピー': copies, 'README': ref(readme_path),
        '再現ZIP': {path.name: ref(path) for path in (REPLAY / '再現コード.zip', REPLAY / '独立確認コード.zip', extra_zip)},
        'ZIP確認': zip_checks,
        '独立票とCSV標準再読の同体': True,
        '保存による自然診断・金融・学習・Raw再実行': False,
        '保存によるCSVと画像の再生成': False,
        '大入力と型付き表と薄い対応の複写': False,
        '全源が金融前F0で固定されていたとは主張しない': True,
    }
    save_json(REPLAY / '保管索引.json', index)
    proof = {
        '成功': True, '試行': 160, '保存作業の範囲': '小源・確認票・再現案内の同体保存',
        '保管索引': ref(REPLAY / '保管索引.json'), '再現README': ref(readme_path),
        'ZIP確認': zip_checks, '自然独立票SHA256': copies['時間帯と全数値の独立確認.json']['sha256'],
        'CSV3指紋': expected_csv, 'CSV標準再読セル': 27895,
        'Source・条件・金融2JSONとCSV不変更': True,
        '金融や自然の診断を再実行しない': True, '保存器SHA256': sha(Path(__file__)),
    }
    for name, item in generated.items():
        assert sha(TRIAL / '成果物' / name) == item['sha256']
    for name, item in csv_refs.items():
        assert sha(VIEW / (name + '.csv')) == item['sha256']
    for name, digest in f0['ソース'].items():
        assert sha(ROOT / name) == digest
    save_json(CHECKS / '再現資料の保存確認.json', proof)
    print(json.dumps({
        '成功': True, '保管索引SHA256': sha(REPLAY / '保管索引.json'),
        '保存確認SHA256': sha(CHECKS / '再現資料の保存確認.json'),
        'ZIP': {name: item['sha256'] for name, item in index['再現ZIP'].items()},
        'CSV標準再読セル': 27895,
    }, ensure_ascii=False))


if __name__ == '__main__':
    main()
