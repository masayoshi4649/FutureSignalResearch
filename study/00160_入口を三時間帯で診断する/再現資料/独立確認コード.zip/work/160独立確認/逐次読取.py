"""機能: 巨大な親結果を場単位に完読し全CRC・解凍SHAを確認する。"""
from pathlib import Path
import gzip
import hashlib
import json


def sha(path: Path) -> str:
    """機能: 全物理bytesを逐次SHAへ流す。

    引数: path(Path)。返り値: str。
    """
    value = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            value.update(block)
    return value.hexdigest()


class Reader:
    """機能: 一場objectだけを保持し、大きいobjectを繰返し解釈しない。"""

    def __init__(self, source):
        """機能: 読取器と解凍指紋を初期化する。

        引数: source(TextIO)。返り値: None。
        """
        self.source, self.buffer, self.at = source, '', 0
        self.digest, self.size = hashlib.sha256(), 0
        self.decoder = json.JSONDecoder(parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))

    def more(self):
        """機能: 次chunkを読み解凍bytesへ加算する。

        引数: なし。返り値: bool。
        """
        value = self.source.read(1 << 18)
        if not value:
            return False
        raw = value.encode('utf-8')
        self.digest.update(raw)
        self.size += len(raw)
        self.buffer, self.at = self.buffer[self.at:] + value, 0
        return True

    def space(self):
        """機能: JSON空白を消費する。

        引数: なし。返り値: None。
        """
        while True:
            while self.at < len(self.buffer) and self.buffer[self.at].isspace():
                self.at += 1
            if self.at < len(self.buffer) or not self.more():
                return

    def token(self, wanted):
        """機能: 構造文字を一つ検査する。

        引数: wanted(str)。返り値: None。
        """
        self.space()
        assert self.buffer[self.at:self.at+1] == wanted
        self.at += 1

    def value(self):
        """機能: 小さいヘッダ値を解釈する。

        引数: なし。返り値: JSON値。
        """
        self.space()
        while True:
            try:
                result, end = self.decoder.raw_decode(self.buffer, self.at)
                if type(result) in (int, float) and end == len(self.buffer) and self.more():
                    continue
                self.at = end
                return result
            except json.JSONDecodeError:
                assert self.more(), 'JSON途中EOF'

    def scene(self):
        """機能: 文字列内の括弧とescapeを区別し一場を一回だけ解釈する。

        引数: なし。返り値: dict。
        """
        self.space()
        assert self.buffer[self.at:self.at+1] == '{'
        pieces, depth, quoted, escaped = [], 0, False, False
        while True:
            start = self.at
            while self.at < len(self.buffer):
                char = self.buffer[self.at]
                self.at += 1
                if quoted:
                    if escaped:
                        escaped = False
                    elif char == '\\':
                        escaped = True
                    elif char == '"':
                        quoted = False
                elif char == '"':
                    quoted = True
                elif char in '{[':
                    depth += 1
                elif char in '}]':
                    depth -= 1
                    if depth == 0:
                        pieces.append(self.buffer[start:self.at])
                        return json.loads(''.join(pieces), parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
            pieces.append(self.buffer[start:self.at])
            assert self.more(), '場JSON途中EOF'


def scenes(path: Path, evidence: dict):
    """機能: 小headerと全sceneを一回完読し解凍指紋を確定する。

    引数: path(Path)、evidence(dict)。返り値: Iterator[dict]。
    """
    opener = gzip.open if path.suffix == '.gz' else open
    with opener(path, 'rt', encoding='utf-8', newline='') as source:
        reader = Reader(source)
        reader.token('{')
        header = {}
        while True:
            key = reader.value()
            reader.token(':')
            assert key not in header
            if key == 'scenes':
                break
            header[key] = reader.value()
            reader.token(',')
        evidence['header'] = header
        reader.token('[')
        while True:
            reader.space()
            if reader.buffer[reader.at:reader.at+1] == ']':
                reader.token(']')
                break
            yield reader.scene()
            reader.space()
            if reader.buffer[reader.at:reader.at+1] == ',':
                reader.token(',')
            else:
                reader.token(']')
                break
        reader.space()
        while reader.buffer[reader.at:reader.at+1] == ',':
            reader.token(',')
            key = reader.value()
            assert key not in header and key != 'scenes'
            reader.token(':')
            header[key] = reader.value()
            reader.space()
        reader.token('}')
        reader.space()
        assert reader.at == len(reader.buffer) and not source.read()
        evidence['decoded_sha256'] = reader.digest.hexdigest()
        evidence['decoded_bytes'] = reader.size
