"""160の三時間帯・旧先着・現行金融を作者集計器なしで再計算する。"""
from __future__ import annotations
from collections import defaultdict
from datetime import datetime, timezone, timedelta, date
from pathlib import Path
from fractions import Fraction
import argparse
import gzip
import hashlib
import json
import math
import sys

import 算術と時計 as arithmetic
import 逐次読取 as reader

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
SPEC=ROOT/'study/00160_入口を三時間帯で診断する/実行条件.md'
SPEC_SHA='fe8fe057f137008df5eba43b953d6e4e66d3bd3e07266971b1c8cdbe57acc3a9'
FIXED=ROOT/'inputs/00157_固定入口と価格経路/固定入口入力.json'
OBS=ROOT/'study/00148_全1分知得から入口品質の母集団を固定する/成果物/固定取得の正逆観測.json.gz'
EXITS=ROOT/'study/00158_複合技術で出口の役割と局面を切り替える/成果物/出口結果.json.gz'
INPUTS={
 FIXED:('eabf9819351ef77fec44a7a132a8df13fd8a3aee7c3be6d87ac81dabe34ce279',None),
 OBS:('bd809bdf24400628817afee702063504c65682e6748a60e0f32d7690b7363c61','d1b4cab8a258203f04b5c1d081f57d10ed2a0c58ce4cc160ef571d5fac0ceffc'),
 EXITS:('70a4c3178206bbb3c8641901c7515f2121da11c28403b88c3f8e6f93cc0baa6c','3c3df90244de838056ca7c98857ffe7b8f85514807e90194c07f73129ec277c7'),
}
BASES=('153U15','152U0')
LABELS=('デイ','ナイト米国前','ナイト米国後')
POLICIES=arithmetic.EXITS
SCOPES=('全73場','前48場','後25場')


def source_ref(path: Path) -> dict:
    """
    機能: 物理指紋とサイズを小さく記録する。
    引数: path (Path)。返り値: dict 型の保存参照。
    """
    return {'path':str(path.relative_to(ROOT)),'sha256':reader.sha(path),'bytes':path.stat().st_size}


def read_scenes(path: Path, evidence: dict):
    """
    機能: 既存の二つのgzipを全CRC・両指紋・前後stat付きで完読する。
    引数: path (Path)、evidence (dict)。返り値: Iterator[dict] 型の場。
    """
    wanted,decoded=INPUTS[path]
    before=path.stat();assert reader.sha(path)==wanted
    info={};count=0
    for scene in reader.scenes(path,info):
        yield scene
        count+=1
        if count%12==0:print(f'独立 {path.name}: {count}/73場',file=sys.stderr,flush=True)
    assert count==73 and info['decoded_sha256']==decoded
    after=path.stat()
    assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns)
    assert reader.sha(path)==wanted
    evidence[path.name]={'path':str(path.relative_to(ROOT)),'sha256':wanted,
        'decoded_sha256':decoded,'physical_bytes':after.st_size,'decoded_bytes':info['decoded_bytes'],
        '全73場完読':True,'全gzip_CRC':True,'前後stat同体':True}


def partition(scene: dict, fixed: dict) -> dict:
    """
    機能: ZoneInfoを使わず2026年の切替日で分類とNY境界を求める。
    引数: scene (dict)、fixed (dict)。返り値: dict 型のRoot形式の時間属性。
    """
    result=arithmetic.clock_group(scene,fixed['entry'])
    labels={'DAY':'デイ','NIGHT_PRE_US':'ナイト米国前','NIGHT_POST_US':'ナイト米国後'}
    aux={'FAR_P':'旧FAR-P帯','TRANSITION':'旧FAR移行帯','FAR_U':'旧FAR-U帯',None:'デイ'}
    opening=result['us_open_time']
    if opening is None:
        start=datetime.fromtimestamp(scene['start'],arithmetic.JST)
        opening=start.replace(hour=22 if start.date()<date(2026,11,1) else 23,minute=30,second=0,microsecond=0).timestamp()
    return {'bin':labels[result['band']],'far_window':aux[result['far_aux']],
        'transition':result['transition_15m'],'us_open':opening,
        'crosses_open':result['nominal_h60_crosses_us_open'],
        'dst':{'SUMMER':'夏時間','STANDARD':'標準時間',None:None}[result['dst']]}


def selected_membership(rows: list[dict],base: str,scope: str) -> list[dict]:
    """
    機能: 所属と固定場番号で群を選び、共有87を物理二重化しない。
    引数: rows (list[dict])、base/scope (str)。返り値: list[dict] 型の群。
    """
    output=[]
    for r in rows:
        if scope=='前48場' and r['session_index']>=48:continue
        if scope=='後25場' and r['session_index']<48:continue
        for membership in r['memberships']:
            if membership['policy']==base:output.append({**r,'origin':membership['origin']})
    return output


def ratio(a: int,b: int):
    """
    機能: 分母0を未知のままにし、有理数で率を計算する。
    引数: a/b (int)。返り値: float 又はNone。
    """
    return float(Fraction(a,b)) if b else None


def entry_metrics(rows: list[dict]) -> dict:
    """
    機能: 作者のCounterを使わず各ラベル数と三分母を独立計数する。
    引数: rows (list[dict])。返り値: dict 型の先着診断。
    """
    f,a,n,c=(sum(row['old']['state']==label for row in rows) for label in 'FANC')
    assert f+a+n+c==len(rows)
    return {'取得数':len(rows),'順':f,'逆':a,'未到達':n,'観測不足':c,
        '到達済み先着率':ratio(f,f+a),'H完了分母率':ratio(f,f+a+n),'全取得分母率':ratio(f,len(rows)),
        '取得のある場数':len(set(row['session'] for row in rows)),
        '移行帯取得数':sum(1 for row in rows if row['transition']),
        '取得後H60が米国開始を跨ぐ数':sum(1 for row in rows if row['crosses_open'])}


def money_metrics(rows: list[dict],policy: str) -> dict:
    """
    機能: 有理数による正負別合計・未知・対応差を計算する。
    引数: rows (list[dict])、policy (str)。返り値: dict 型の金融診断。
    """
    positives=Fraction(0);negatives=Fraction(0);known=both=0;delta=Fraction(0)
    for r in rows:
        a=r['money'][policy];b=r['money']['F125S125']
        if a['status']!='closed':
            assert a['profit_yen'] is None
            continue
        value=arithmetic.number(a['profit_yen']);known+=1
        if value>0:positives+=value
        elif value<0:negatives-=value
        if b['status']=='closed':both+=1;delta+=value-arithmetic.number(b['profit_yen'])
    net=positives-negatives
    return {'取得数':len(rows),'決済既知':known,'損益未知':len(rows)-known,
        '利益総額円':arithmetic.value_json(positives),'損失総額円':arithmetic.value_json(negatives),
        '既知差引円':arithmetic.value_json(net),'PF':float(positives/negatives) if negatives else None,
        '全件確定差引円':arithmetic.value_json(net) if len(rows)==known else None,
        'IFD対応既知数':both,'IFD対応差分円':arithmetic.value_json(delta)}


def compare(actual,expected,path: str='') -> tuple[int,int]:
    """
    機能: 型・辞書・列・整数を厳密、有限小数だけ適切な許容差で照合する。
    引数: actual/expected (object)、path (str)。返り値: tuple[int,int] 型の末端数/非null数。
    """
    if isinstance(expected,dict):
        assert isinstance(actual,dict) and set(actual)==set(expected),(path,'keys',set(actual)^set(expected))
        counts=[compare(actual[k],v,path+'/'+str(k)) for k,v in expected.items()]
        return sum(c[0] for c in counts),sum(c[1] for c in counts)
    if isinstance(expected,list):
        assert isinstance(actual,list) and len(actual)==len(expected),(path,'list')
        counts=[compare(a,b,path+'/'+str(i)) for i,(a,b) in enumerate(zip(actual,expected,strict=True))]
        return sum(c[0] for c in counts),sum(c[1] for c in counts)
    if expected is None:
        assert actual is None,(path,actual,expected)
    elif type(expected) is bool or type(expected) is int or isinstance(expected,str):
        assert type(actual) is type(expected) and actual==expected,(path,actual,expected)
    elif isinstance(expected,float):
        assert type(actual) in (int,float) and math.isfinite(actual) and math.isclose(actual,expected,rel_tol=1e-13,abs_tol=1e-9),(path,actual,expected)
    else:raise AssertionError((path,type(expected)))
    return 1,int(expected is not None)


def tables(rows: list[dict],scenes: list[dict]) -> tuple[dict,dict]:
    """
    機能: 固定列規約に従う3表と副分類を別実装で再作成する。
    引数: rows (list[dict])、scenes (list[dict])。返り値: tuple[dict,dict] 型の表/補助分類。
    """
    entrants=[];exits=[];sessions=[];aux={}
    for base in BASES:
        for scope in SCOPES:
            members=selected_membership(rows,base,scope)
            for label in LABELS:
                selected=[r for r in members if r['bin']==label]
                for origin in ('全入口','旧C1','追加入口'):
                    branch=selected if origin=='全入口' else [r for r in selected if r['origin']==origin]
                    entrants.append([base,scope,label,origin,*entry_metrics(branch).values()])
                for policy in POLICIES:exits.append([base,scope,label,policy,*money_metrics(selected,policy).values()])
            auxiliary={}
            for column in ('far_window','dst'):
                auxiliary[column]={}
                for value in sorted(set(r[column] for r in members if r[column] is not None)):
                    selected=[r for r in members if r[column]==value]
                    auxiliary[column][value]={'入口':entry_metrics(selected),'金融':{p:money_metrics(selected,p) for p in POLICIES}}
            aux[base+'/'+scope]=auxiliary
        members=selected_membership(rows,base,'全73場')
        for policy in POLICIES:
            for label in LABELS:
                cumulative=Fraction(0);unknown=0
                for scene in scenes:
                    key=scene['session'];eligible=(key.endswith('_Day') and label=='デイ') or (key.endswith('_Night') and label!='デイ')
                    selected=[r for r in members if r['session']==key and r['bin']==label]
                    assert eligible or not selected
                    if eligible:
                        e,m=entry_metrics(selected),money_metrics(selected,policy)
                        cumulative+=arithmetic.number(m['既知差引円']);unknown+=m['損益未知']
                        values=[e[k] for k in ('取得数','順','逆','未到達','観測不足','到達済み先着率')]
                        values += [m[k] for k in ('決済既知','損益未知','利益総額円','損失総額円','既知差引円','PF')]
                        values += [arithmetic.value_json(cumulative),unknown,arithmetic.value_json(cumulative) if unknown==0 else None]
                    else:values=[None]*15
                    sessions.append([base,key,label,'対象' if eligible else '対象外',policy,*values])
    result={'入口時間帯別':{'headers':['入口','区間','時間帯','入口枝',*entry_metrics([])],'rows':entrants},
        '出口時間帯別':{'headers':['入口','区間','時間帯','出口',*money_metrics([],POLICIES[0])],'rows':exits},
        '全セッション':{'headers':['入口','セッション','時間帯','対象区分','出口','取得数','順','逆','未到達','観測不足','到達済み先着率','決済既知','損益未知','利益総額円','損失総額円','既知差引円','PF','累計既知差引円','累計損益未知','全件確定累計円'],'rows':sessions}}
    return result,aux


def execute(options: argparse.Namespace) -> dict:
    """
    機能: 独立射影・別算術集計を正式160出力へ照合する。
    引数: options (Namespace) 明示された成果path/SHA。返り値: dict 型の確認票。
    """
    assert reader.sha(SPEC)==SPEC_SHA and not options.output.exists()
    assert reader.sha(options.projection)==options.projection_sha256
    assert reader.sha(options.tables)==options.tables_sha256
    root_projection=json.loads(options.projection.read_bytes());root_tables=json.loads(options.tables.read_bytes())
    assert root_projection['success'] and root_projection['trial']==root_tables['trial']==160
    before={p:source_ref(p) for p in (FIXED,OBS,EXITS,options.projection,options.tables)}
    assert before[FIXED]['sha256']==INPUTS[FIXED][0]
    fixed=json.loads(FIXED.read_bytes());fixed_scenes=fixed['scenes'];assert len(fixed_scenes)==73
    rows=[];indexes={};fixed_cases={};scene_index={scene['session']:i for i,scene in enumerate(fixed_scenes)}
    assert len(scene_index)==73
    for i,scene in enumerate(fixed_scenes):
        for f in scene['cases']:
            key=(scene['session'],f['id']);assert key not in indexes
            row={'id':f['id'],'session':scene['session'],'session_index':i,'entry_time':f['entry']['time'],
                'side':f['side'],'stream':f['stream'],'entry_price':f['entry_price'],**partition(scene,f),
                'memberships':[{'policy':m['policy'],'origin':'旧C1' if m['source_selection_ref'].get('origin')=='C1' else '追加入口'} for m in f['memberships']]}
            rows.append(row);indexes[key]=row;fixed_cases[key]=f
    assert len(rows)==837 and sum(len(r['memberships']) for r in rows)==924

    # ----------------------------------------
    evidence={};seen=set()
    for i,scene in enumerate(read_scenes(OBS,evidence)):
        assert scene['session']==fixed_scenes[i]['session']
        for c in scene['cases']:
            key=(scene['session'],c['id'])
            if key not in indexes:continue
            assert key not in seen;seen.add(key)
            f=fixed_cases[key];projection=arithmetic.legacy_projection(f,c)
            assert c[f['stream']]['entry']==f['entry']
            touch=[t for o in c[f['stream']]['outcomes'] if o['seconds']==3600 for t in o['touches'] if t['width']==125][0]
            indexes[key]['old']={'state':projection['label'],'recorded_direction':projection['recorded_touch_direction'],
                'status':projection['h_status'],'touch_time':touch['quote']['time'] if touch.get('quote') else None,'deadline':projection['deadline']}
    assert len(seen)==837

    # ----------------------------------------
    seen=set()
    for i,scene in enumerate(read_scenes(EXITS,evidence)):
        key_scene=scene['session'];fscene=fixed_scenes[i]
        assert fscene['session']==key_scene
        for c in scene['cases']:
            key=(key_scene,c['id']);assert key in indexes and key not in seen;seen.add(key)
            f=fixed_cases[key];validated=arithmetic.financial_projection(fscene,f,c)
            assert c['stream']==f['stream'] and c['entry']==f['entry']
            money={}
            for p in POLICIES:
                saved=[r for r in c['results'] if (r['policy'],r['horizon'],r['delay'],r['cost'])==(p,'H60','D1','C5')][0]
                money[p]={k:saved.get(k) for k in ('status','profit_yen','profit_after_positive_loss','profit_after125_loss','held_seconds')}
                assert validated[p]['known']==(money[p]['status']=='closed') and validated[p]['net']==money[p]['profit_yen']
            indexes[key]['money']=money
    assert len(seen)==837
    metadata=[{k:v for k,v in s.items() if k not in ('cases','source_scene','raw')} for s in fixed_scenes]
    refs={'fixed':{'path':FIXED.relative_to(ROOT).as_posix(),'sha256':INPUTS[FIXED][0],'bytes':FIXED.stat().st_size}}
    for key,p in [('observations',OBS),('exits',EXITS)]:
        info=evidence[p.name]
        refs[key]={'path':str(p.relative_to(ROOT)),'sha256':INPUTS[p][0],'decoded_sha256':INPUTS[p][1],
            'physical_bytes':info['physical_bytes'],'decoded_bytes':info['decoded_bytes'],'all_scenes':73,'gzip_crc_checked':True}
    expected={'success':True,'trial':160,'inputs':refs,'scenes':metadata,'rows':rows}
    made,aux=tables(rows,metadata)
    cache=options.output.parent/'独立期待の作業キャッシュ.json.gz'
    cache.parent.mkdir(parents=True,exist_ok=True)
    assert not cache.exists()
    with gzip.open(cache,'wt',encoding='utf-8',newline='') as target:
        json.dump({'projection':expected,'tables':made,'auxiliary':aux,'inputs':evidence},target,ensure_ascii=False,allow_nan=False,separators=(',',':'))
    compared=compare(root_projection,expected,'projection')
    table_counts=compare(root_tables['tables'],made,'tables');aux_counts=compare(root_tables['補助分類'],aux,'auxiliary')
    totals={}
    for base,expected_counts in [('153U15',(93,46,18,22,7)),('152U0',(831,442,280,78,31))]:
        members=selected_membership(rows,base,'全73場');m=entry_metrics(members)
        assert tuple(m[k] for k in ('取得数','順','逆','未到達','観測不足'))==expected_counts
        totals[base]={'入口':m,'金融':{p:money_metrics(members,p) for p in POLICIES}}
        assert len({r['session'] for r in members})==73
    assert reader.sha(SPEC)==SPEC_SHA
    for p,e in before.items():assert source_ref(p)==e
    proof={'成功':True,'試行':160,'仕様SHA256':SPEC_SHA,'独立計算':'JST閉形式の2026年夏冬境界、Fraction金融/率、作者集計器importなし',
        '汎用JSON読取だけ共用':True,'自然再学習':False,'Raw読取':False,'全73場':True,'固定物理取得':837,'所属':924,
        '射影照合末端':compared[0],'射影非null末端':compared[1],'三表照合末端':table_counts[0],'三表非null末端':table_counts[1],
        '補助分類末端':aux_counts[0],'表のデータ行':{k:len(v['rows']) for k,v in made.items()},
        '入力':{str(p.relative_to(ROOT)):e for p,e in before.items()},'gzip読取証拠':evidence,'全体復元':totals,
        '検算Source':{p.name:reader.sha(p) for p in sorted(HERE.glob('*.py'))},
        '初回メタデータ停止':json.loads((HERE/'初回パス表記停止.json').read_bytes()),
        '独立期待の作業キャッシュ':{'path':str(cache.relative_to(ROOT)),'sha256':reader.sha(cache),'正式資料へ全件重複保存しない':True}}
    options.output.parent.mkdir(parents=True,exist_ok=True)
    options.output.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return proof


def main() -> None:
    """
    機能: 明示された自然成果の指紋に束縛して独立検算を実行する。
    引数: CLI 引数。返り値: None 型。
    """
    parser=argparse.ArgumentParser()
    for key in ('projection','tables','output'):parser.add_argument('--'+key,type=Path,required=True)
    for key in ('projection-sha256','tables-sha256'):parser.add_argument('--'+key,required=True)
    options=parser.parse_args()
    for name in ('projection','tables','output'):setattr(options,name,getattr(options,name).resolve())
    result=execute(options)
    print(json.dumps({'成功':result['成功'],'射影末端':result['射影照合末端'],'表':result['表のデータ行']},ensure_ascii=False))


if __name__=='__main__':
    main()
