"""機能: 固定入口の旧先着と別時計金融を混同せず独立射影する。"""
from datetime import datetime, timezone, timedelta, date
from fractions import Fraction
import math

JST = timezone(timedelta(hours=9))
POLICIES = ('153U15', '152U0')
EXITS = ('F125S125', 'T125W100TP250', 'A11_PROFIT_BUDGET')
QUOTE_KEYS = ('time', 'index', 'source_line', 'clock', 'last', 'bid', 'ask', 'quote_ok')


def number(value) -> Fraction:
    """機能: boolを拒否し保存数値を有理数へ写す。

    引数: value(int又はfloat)。返り値: Fraction。
    """
    assert type(value) in (int, float) and math.isfinite(value)
    return Fraction(str(value))


def value_json(value: Fraction):
    """機能: 有理数をJSON数値へ写す。

    引数: value(Fraction)。返り値: int又はfloat。
    """
    return int(value) if value.denominator == 1 else float(value)


def quote_tuple(q):
    """機能: 省略clockを含む全8Quoteを比較可能にする。

    引数: q(dict)。返り値: tuple。
    """
    return tuple(q.get(k, '' if k == 'clock' else None) for k in QUOTE_KEYS)


def clock_group(scene: dict, entry: dict) -> dict:
    """機能: 固定160規約の実取得時間帯を金融情報なしで計算する。

    引数: scene(dict)、entry(dict型q1)。返り値: dict。
    2026年固定73場用で、NYの2026年11月1日切替をJST閉形式で別実装する。
    """
    stamp = float(number(entry['time']))
    start = datetime.fromtimestamp(float(number(scene['start'])), JST)
    local = datetime.fromtimestamp(stamp, JST)
    assert start.year == 2026 and start.date().isoformat() == scene['session'].split('_')[0]
    assert scene['start'] <= stamp < scene['continuous_end']
    assert scene['session'] not in ('2026-11-10_Night', '2026-11-11_Day')
    if scene['session'].endswith('_Day'):
        return {'band': 'DAY', 'us_open_time': None, 'transition_15m': False,
                'far_aux': None, 'nominal_h60_crosses_us_open': False,
                'dst': None, 'entry_jst': local.isoformat()}
    assert scene['session'].endswith('_Night')
    summer = start.date() < date(2026, 11, 1)
    boundary = start.replace(hour=22 if summer else 23, minute=30, second=0, microsecond=0).timestamp()
    transition = boundary-900 <= stamp < boundary+900
    return {'band': 'NIGHT_PRE_US' if stamp < boundary else 'NIGHT_POST_US',
            'us_open_time': boundary, 'transition_15m': transition,
            'far_aux': 'TRANSITION' if transition else 'FAR_P' if stamp < boundary-900 else 'FAR_U',
            'nominal_h60_crosses_us_open': stamp < boundary <= stamp+3600,
            'dst': 'SUMMER' if summer else 'STANDARD', 'entry_jst': local.isoformat()}


def legacy_projection(fixed: dict, observed_case: dict) -> dict:
    """機能: 旧H60/125のHcompleteラベルと旧即時IFDを別計算する。

    引数: fixed(dict型157case)、observed_case(dict型148case)。返り値: dict。
    """
    assert fixed['id'] == observed_case['id'] and fixed['stream'] in ('original', 'reverse')
    candidate = observed_case[fixed['stream']]
    assert candidate['status'] == 'filled' and candidate['axis'] == 'BBO'
    assert candidate['birth']['side'] == fixed['side']
    assert quote_tuple(candidate['entry']) == quote_tuple(fixed['entry'])
    assert candidate['entry_price'] == fixed['entry_price']
    outcomes = [o for o in candidate['outcomes'] if o['seconds'] == 3600]
    assert len(outcomes) == 1
    outcome = outcomes[0]
    assert number(outcome['deadline']) == number(fixed['entry']['time'])+3600
    touches = [t for t in outcome['touches'] if t['width'] == 125]
    assert len(touches) == 1
    touch = touches[0]
    assert type(touch['direction']) is int and touch['direction'] in (-1, 0, 1)
    complete = outcome['status'] == 'complete'
    label = 'C' if not complete else {1: 'F', -1: 'A', 0: 'N'}[touch['direction']]
    quote = touch['quote'] if touch['direction'] else outcome['endpoint'] if complete else None
    result = {'h_status': outcome['status'], 'label': label, 'recorded_touch_direction': touch['direction'],
              'deadline': outcome['deadline'], 'ifd_known': quote is not None,
              'ifd_reason': '不足' if quote is None else '順到達' if touch['direction'] == 1 else
                            '逆到達' if touch['direction'] == -1 else 'H期限',
              'ifd_exit': quote, 'ifd_points': None, 'ifd_net0': None, 'ifd_net5': None}
    if quote is not None:
        assert quote['quote_ok'] and 0 < quote['bid'] < quote['ask']
        mark = quote['bid' if fixed['side'] == 1 else 'ask']
        gross = fixed['side']*(number(mark)-number(fixed['entry_price']))
        result.update(ifd_points=value_json(gross), ifd_net0=value_json(100*gross-77),
                      ifd_net5=value_json(100*gross-1077))
    return result


def financial_projection(scene: dict, fixed: dict, observed_case: dict) -> dict:
    """機能: 158の三出口H60/D1/C5 cashを実fillから独立検査する。

    引数: scene/fixed/observed_case(dict)。返り値: dict。
    """
    assert fixed['id'] == observed_case['id'] and fixed['side'] == observed_case['side']
    assert fixed['entry_price'] == observed_case['entry_price']
    assert quote_tuple(fixed['entry']) == quote_tuple(observed_case['entry'])
    results = {}
    for policy in EXITS:
        rows = [r for r in observed_case['results'] if (r['policy'], r['horizon'], r['delay'], r['cost']) ==
                (policy, 'H60', 'D1', 'C5')]
        assert len(rows) == 1
        row = rows[0]
        assert row['fee_yen'] == 1077
        assert number(row['deadline']) == min(number(fixed['entry']['time'])+3600, number(scene['force_close']))
        if row['status'] == 'unknown':
            assert row['profit_yen'] is None and row['fill'] is None
            results[policy] = {'known': False, 'net': None, 'unknown_reason': row['unknown_reason']}
            continue
        assert row['status'] == 'closed'
        fill, trigger = row['fill'], row['trigger']
        assert fill['quote_ok'] and 0 < fill['bid'] < fill['ask']
        assert trigger['time']+1 <= fill['time'] <= trigger['time']+30
        assert fill['time'] < scene['continuous_end']
        if trigger['quote'] is not None:
            assert fill['index'] > trigger['quote']['index'] and fill['source_line'] > trigger['quote']['source_line']
        gross = fixed['side']*(number(fill['bid' if fixed['side'] == 1 else 'ask'])-number(fixed['entry_price']))
        net = 100*gross-1077
        assert abs(number(row['profit_yen'])-net) < Fraction(1, 10000000)
        results[policy] = {'known': True, 'net': value_json(net), 'unknown_reason': None}
    return results


def label_totals(rows: list[dict]) -> dict:
    """機能: F/A/N/Cと三つの率だけを独立集計する。

    引数: rows(list[dict]型のlegacy_projection)。返り値: dict。
    """
    counts = {name: sum(r['label'] == name for r in rows) for name in 'FANC'}
    assert sum(counts.values()) == len(rows)
    f, a, n, c = (counts[x] for x in 'FANC')
    return {**counts, 'entries': len(rows), 'ifd_known': sum(r['ifd_known'] for r in rows),
            'ifd_unknown': sum(not r['ifd_known'] for r in rows),
            'resolved_rate': f/(f+a) if f+a else None,
            'complete_rate': f/(f+a+n) if f+a+n else None,
            'all_entry_rate': f/len(rows) if rows else None}
