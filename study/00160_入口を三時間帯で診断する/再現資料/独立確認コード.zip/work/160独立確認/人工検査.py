"""160独立側の時計・観測・費用・表の欠値を人工で確認する。"""
from datetime import datetime,timedelta
from pathlib import Path
import json

import 算術と時計 as arithmetic
import 独立確認する as audit


def quote(at: int,bid: int=10000,ask: int=10010,index: int=1) -> dict:
    """
    機能: 人工の正常気配を作る。
    引数: at/bid/ask/index (int)。返り値: dict 型の8項目Quote。
    """
    return {'time':at,'index':index,'source_line':index+3,'clock':'人工','last':bid,'bid':bid,'ask':ask,'quote_ok':True}


def main() -> None:
    """
    機能: 自然の結果を読まず独立検算器の6人工群を検査する。
    引数: なし。返り値: None 型。
    """
    for day,hour in [('2026-09-21',22),('2026-10-30',22),('2026-11-02',23),('2026-11-09',23)]:
        start=datetime.strptime(day,'%Y-%m-%d').replace(hour=17,tzinfo=arithmetic.JST)
        opening=start.replace(hour=hour,minute=30).timestamp()
        scene={'session':day+'_Night','start':start.timestamp(),'continuous_end':(start+timedelta(days=1)).replace(hour=5,minute=55).timestamp()}
        for delta,group,far,transition in [(-901,'ナイト米国前','旧FAR-P帯',False),(-900,'ナイト米国前','旧FAR移行帯',True),
            (-1,'ナイト米国前','旧FAR移行帯',True),(0,'ナイト米国後','旧FAR移行帯',True),(899,'ナイト米国後','旧FAR移行帯',True),(900,'ナイト米国後','旧FAR-U帯',False)]:
            value=audit.partition(scene,{'entry':{'time':opening+delta}})
            assert (value['bin'],value['far_window'],value['transition'],value['us_open'])==(group,far,transition,opening)
        assert audit.partition(scene,{'entry':{'time':opening-3600}})['crosses_open']
        assert not audit.partition(scene,{'entry':{'time':opening-3600.1}})['crosses_open']
        assert not audit.partition(scene,{'entry':{'time':opening}})['crosses_open']
    day_scene={'session':'2026-11-02_Day','start':datetime(2026,11,2,8,45,tzinfo=arithmetic.JST).timestamp(),
               'continuous_end':datetime(2026,11,2,15,40,tzinfo=arithmetic.JST).timestamp()}
    day_fixed={'entry':{'time':datetime(2026,11,2,12,tzinfo=arithmetic.JST).timestamp()}}
    day=audit.partition(day_scene,day_fixed)
    assert day['bin']=='デイ' and not day['transition'] and day['dst'] is None

    # ----------------------------------------
    q=quote(1000);f={'id':'人工','side':1,'stream':'original','entry':q,'entry_price':10010}
    for status,direction,label in [('complete',1,'F'),('complete',-1,'A'),('complete',0,'N'),('endpoint_missing',1,'C'),('endpoint_missing',0,'C')]:
        exit_quote=quote(1100,10140,10150,index=4)
        outcome={'seconds':3600,'deadline':4600,'status':status,
            'touches':[{'width':125,'direction':direction,'quote':exit_quote if direction else None}],
            'endpoint':quote(4601,10020,10030,index=9) if status=='complete' else None,'net5':999999}
        observed={'id':'人工','original':{'status':'filled','axis':'BBO','birth':{'side':1},'entry':q,'entry_price':10010,'outcomes':[outcome]}}
        result=arithmetic.legacy_projection(f,observed)
        assert result['label']==label and result['ifd_known']==(bool(direction) or status=='complete')
        if direction:assert result['ifd_net5']==11923
        elif status=='complete':assert result['ifd_net5']==-77
        else:assert result['ifd_net5'] is None

    # ----------------------------------------
    candidate={'id':'人工','side':1,'entry':q,'entry_price':10010,'results':[]}
    for p in audit.POLICIES:
        candidate['results'].append({'policy':p,'horizon':'H60','delay':'D1','cost':'C5','fee_yen':1077,
            'deadline':4600,'status':'closed','fill':quote(1202,10140,10150,index=10),
            'trigger':{'time':1200,'quote':quote(1200,10130,10140,index=9)},'profit_yen':11923})
    result=arithmetic.financial_projection({'force_close':5000,'continuous_end':6000},f,candidate)
    assert all(value['known'] and value['net']==11923 for value in result.values())
    candidate['results'][0].update(status='unknown',fill=None,profit_yen=None,unknown_reason='人工')
    result=arithmetic.financial_projection({'force_close':5000,'continuous_end':6000},f,candidate)
    assert not result[audit.POLICIES[0]]['known'] and result[audit.POLICIES[0]]['net'] is None

    # ----------------------------------------
    rows=[]
    for i,(label,status,net) in enumerate([('F','closed',1000),('A','closed',-2000),('C','unknown',None)]):
        rows.append({'old':{'state':label},'money':{p:{'status':status,'profit_yen':net} for p in audit.POLICIES},
            'session':'2026-09-21_Day','session_index':0,'transition':False,'crosses_open':False,'bin':'デイ',
            'far_window':'デイ','dst':None,'memberships':[{'policy':b,'origin':'旧C1'} for b in audit.BASES]})
    e=audit.entry_metrics(rows);m=audit.money_metrics(rows,audit.POLICIES[0])
    assert (e['取得数'],e['順'],e['逆'],e['未到達'],e['観測不足'])==(3,1,1,0,1)
    assert e['到達済み先着率']==.5 and e['H完了分母率']==.5 and e['全取得分母率']==1/3
    assert (m['利益総額円'],m['損失総額円'],m['既知差引円'],m['PF'],m['損益未知'])==(1000,2000,-1000,.5,1)
    assert m['全件確定差引円'] is None and m['IFD対応差分円']==0

    # ----------------------------------------
    scenes=[{'session':(datetime(2026,9,21)+timedelta(days=i//2)).strftime('%Y-%m-%d')+('_Day' if i%2==0 else '_Night')} for i in range(73)]
    made,aux=audit.tables(rows,scenes)
    assert {k:len(v['rows']) for k,v in made.items()}=={'入口時間帯別':54,'出口時間帯別':54,'全セッション':1314}
    table=made['全セッション'];values=[dict(zip(table['headers'],r,strict=True)) for r in table['rows']]
    assert all(r['取得数'] is None for r in values if r['対象区分']=='対象外')
    assert any(r['取得数']==0 for r in values if r['対象区分']=='対象')
    assert all(r['全件確定累計円'] is None for r in values if r['入口']=='153U15' and r['時間帯']=='デイ' and r['対象区分']=='対象')

    # ----------------------------------------
    assert audit.compare({'a':[None,1,True,0.5]},{'a':[None,1,True,0.5]})==(4,3)
    try:audit.compare({'a':True},{'a':1})
    except AssertionError:pass
    else:raise AssertionError('boolとintを同じにした')
    print('成功：時計境界、旧先着/旧IFD、現行実fill費用、未知と三分母、対象外累計、型照合の6人工群')


if __name__=='__main__':
    main()
