"""入口の三時間帯比較設計で読んだ固定小源と恒久入力参照を記録する。"""
from pathlib import Path
import ast
import datetime
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def digest(path: Path) -> str:
    """
    機能: 全物理bytesを逐次SHA256へ写す。
    引数: path (Path) 指紋化する既存ファイル。
    返り値: str 型のSHA256。
    """
    value=hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda:source.read(1<<20),b''):
            value.update(block)
    return value.hexdigest()


def main() -> None:
    """
    機能: 新しい学習や採否をせず、出典・設計短報・静的読取範囲を保存する。
    引数: なし。
    返り値: None。既存の正式入力・Sourceは変更しない。
    """
    book_path=ROOT/'inputs/00151_過去場だけの複合判別/条件.json'
    assert digest(book_path)=='09bad678c01cc7db614137647161ec695f20cb148770987a515ee4cfa71f8f2d'
    book=json.loads(book_path.read_bytes())
    assert book['training']['window_sessions']==20 and book['training']['minimum_physical_pairs']==1000
    assert book['training']['minimum_contributing_sessions']==8 and book['classifier_parameters']['iterations']==128
    sources=[
      'AGENTS.md',
      'study/00160_入口を三時間帯で診断する/実行条件.md',
      'study/00148_全1分知得から入口品質の母集団を固定する/README.md',
      'study/00151_広い複合テクニカルを過去場だけで判別する/条件.md',
      'inputs/00151_過去場だけの複合判別/条件.json',
      'work/151過去場判別/run151.py','work/151過去場判別/model151.py','work/151過去場判別/data151.py',
      'work/152複合回復の入口/logic152.py','work/153独立出生の入口/logic153.py',
      'inputs/00148_全1分入口母集団/100特徴の列定義.json',
    ]
    refs={}
    for relative in sources:
        p=ROOT/relative
        refs[relative]={'sha256':digest(p),'bytes':p.stat().st_size}
        if p.suffix=='.py':
            ast.parse(p.read_text(encoding='utf-8'))
    assert refs['study/00160_入口を三時間帯で診断する/実行条件.md']['sha256']=='fe8fe057f137008df5eba43b953d6e4e66d3bd3e07266971b1c8cdbe57acc3a9'
    inputs={}
    for name,item in book['inputs'].items():
        p=ROOT/item['path']
        assert digest(p)==item['sha256'],name
        inputs[name]={**item,'physical_bytes':p.stat().st_size,'構造又は金融本文の追加解析':False}
    out={'成功':True,'試行':160,'用途':'次の入口探索の設計参照。160集計と新入口採否・学習は行わない。',
      '原151book':'09bad678c01cc7db614137647161ec695f20cb148770987a515ee4cfa71f8f2d',
      '読取小源':refs,'次試行で再用する恒久入力':inputs,
      '母集団の出典':'study/00148_全1分知得から入口品質の母集団を固定する/README.md',
      '件数':{'全適格q0':35339,'各実側特徴':100,'研究q1':31632,'全観測case':31642,'旧C1':87},
      '注意':'入力の物理SHAは照合したが、今回gzipの全解凍CRC/数式/旧教師射影を再実行していない。由来の解凍SHAは151固定bookの参照値。'}
    path=HERE/'入力とSourceの参照.json'
    assert not path.exists()
    path.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    files={str(p.relative_to(ROOT)):{'sha256':digest(p),'bytes':p.stat().st_size}
           for p in (HERE/'次の入口探索の設計.md',HERE/'入力とSourceの参照.json',Path(__file__))}
    stop={'成功':True,'試行':160,'停止日時UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      '段階':'読み取り専用の次試行設計を停止','files':files,'新学習':False,'新入口採否':False,
      '自然の時間帯別損益集計':False,'Raw走査':False,'未見2場と156の読取':False,
      '変更範囲':'work/160入口探索の調査/内だけ'}
    path=HERE/'停止.json'
    assert not path.exists()
    path.write_text(json.dumps(stop,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'短報SHA256':files[str((HERE/'次の入口探索の設計.md').relative_to(ROOT))]['sha256'],
       '参照SHA256':digest(HERE/'入力とSourceの参照.json'),'停止SHA256':digest(path)},ensure_ascii=False))


if __name__=='__main__':
    main()
