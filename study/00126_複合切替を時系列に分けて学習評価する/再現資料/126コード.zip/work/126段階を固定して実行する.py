"""126の入力分割・学習・モデル固定・評価を別段階で実行する。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import subprocess
import sys

ROOT=Path(__file__).resolve().parent.parent
OWN=ROOT/'work/126複合切替の探索'
FORMAL=ROOT/'study/00126_複合切替を時系列に分けて学習評価する'
CATALOG='6833188e81aadea2611116da95ba58eef2aacfc047bbc76b628a32ebcbc1145a'


def sha(path: Path) -> str:
    """
    機能: ファイル全バイトをSHA256で指紋化する。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def read(path: Path) -> dict:
    """
    機能: UTF-8 JSONを読み取る。
    引数: path(Path)。返り値: dict。
    """
    return json.loads(path.read_text(encoding='utf-8'))


# ----------------------------------------
def save(path: Path,value: dict) -> None:
    """
    機能: 未作成先だけへ固定記録を保存する。
    引数: path(Path)、value(dict)。返り値: None。
    """
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')


# ----------------------------------------
def verify(fixed: dict) -> None:
    """
    機能: F1のコード・入力・事前文書が同体であることを確認する。
    引数: fixed(dict)。返り値: None。
    """
    expected={**fixed['コード'],**fixed['入力'],**fixed['事前文書']}
    assert all(sha(Path(p))==s for p,s in expected.items())


# ----------------------------------------
def main() -> None:
    """
    機能: F1→物理分割→学習→モデルSHA固定→評価を順番に進める。
    引数: CLI --mode(str)。返り値: None。
    """
    parser=argparse.ArgumentParser(description='126の段階固定と実行')
    parser.add_argument('--mode',choices=('固定','分割','学習','評価'),required=True)
    mode=parser.parse_args().mode
    f1=OWN/'F1.json'
    if mode=='固定':
        inputs=[ROOT/'work/124入口の正逆比較/全73場の正逆結果.json',ROOT/'work/124当時特徴の診断/全79例の当時特徴.json',ROOT/'work/125足の実体と反転切替/choices.json']
        code=list(OWN.glob('*.py'))+[Path(__file__).resolve(),ROOT/'work/124入口の原因分析/集計する.py']
        docs=[FORMAL/'README.md',FORMAL/'設定と結果.md',OWN/'条件.md',OWN/'探索範囲.json',OWN/'時系列分割.json']
        assert all(p.is_file() for p in inputs+code+docs) and sha(OWN/'探索範囲.json')==CATALOG
        assert not any((OWN/name).exists() for name in ('学習入力.json','評価入力.json','学習モデル.json','集計.json'))
        value={'成功':True,'試行':126,'固定UTC':datetime.now(timezone.utc).isoformat(),'主政策':'T8','主評価区分':'validation','主同幅pt':125,'主秒':3600,
               '分割':'前48場53取得を学習、後25場26取得を評価。B0は全73場探索由来、未知期間ではない。',
               'コード':{str(p):sha(p) for p in code},'入力':{str(p):sha(p) for p in inputs},'事前文書':{str(p):sha(p) for p in docs}}
        save(f1,value); print(json.dumps({'固定':True,'F1_SHA256':sha(f1),'コード数':len(code)},ensure_ascii=False));return
    fixed=read(f1);verify(fixed)
    if mode=='分割':
        command=[sys.executable,'-X','utf8',str(OWN/'入力を分割する.py'),'--fixed-catalog-sha256',CATALOG]
        subprocess.run(command,cwd=ROOT,check=True);verify(fixed)
        paths=[OWN/'学習入力.json',OWN/'評価入力.json',OWN/'分割の確認.json']
        save(OWN/'分割固定.json',{'成功':True,'試行':126,'F1_SHA256':sha(f1),'固定入力':{str(p):sha(p) for p in paths},'範囲':'分割器は両側を読み場IDで結合のみ。次の学習器には学習側だけを渡す。'})
        return
    split=read(OWN/'分割固定.json')
    assert all(sha(Path(p))==s for p,s in split['固定入力'].items())
    if mode=='学習':
        command=[sys.executable,'-X','utf8',str(OWN/'探索する.py'),'--mode','train','--fixed-catalog-sha256',CATALOG]
        subprocess.run(command,cwd=ROOT,check=True);verify(fixed)
        assert all(sha(Path(p))==s for p,s in split['固定入力'].items())
        model=OWN/'学習モデル.json'
        save(OWN/'モデル固定.json',{'成功':True,'試行':126,'F1_SHA256':sha(f1),'分割固定SHA256':sha(OWN/'分割固定.json'),'モデルSHA256':sha(model),'モデルbytes':model.stat().st_size,'評価前固定':True})
        print(json.dumps({'学習完了':True,'モデルSHA256':sha(model)},ensure_ascii=False));return
    model=read(OWN/'モデル固定.json');assert model['評価前固定'] and model['モデルSHA256']==sha(OWN/'学習モデル.json')
    command=[sys.executable,'-X','utf8',str(OWN/'探索する.py'),'--mode','evaluate','--fixed-catalog-sha256',CATALOG,'--model-sha256',model['モデルSHA256']]
    subprocess.run(command,cwd=ROOT,check=True);verify(fixed)
    assert model['モデルSHA256']==sha(OWN/'学習モデル.json') and all(sha(Path(p))==s for p,s in split['固定入力'].items())
    save(OWN/'段階実行完了.json',{'成功':True,'試行':126,'F1_SHA256':sha(f1),'モデル固定SHA256':sha(OWN/'モデル固定.json'),'集計SHA256':sha(OWN/'集計.json'),'表SHA256':sha(OWN/'CSV用の表.json'),'コード入力文書モデル前後同体':True})


if __name__=='__main__':
    main()
