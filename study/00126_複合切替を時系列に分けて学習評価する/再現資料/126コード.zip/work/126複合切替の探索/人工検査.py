"""126の有限探索・未知・買売鏡像・物理分割・後半非参照を人工データだけで検査する。"""
from pathlib import Path
from fractions import Fraction
from itertools import product
from tempfile import TemporaryDirectory
from unittest.mock import patch
import copy
import hashlib
import importlib.util
import json
import unittest
import learner

OWN = Path(__file__).resolve().parent


def load(path: Path,name: str):
    """
    機能: mainを実行せず検査対象のコードだけを読む。
    引数: path(Path)、name(str)。返り値: Pythonモジュール。
    """
    spec = importlib.util.spec_from_file_location(name,path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# ----------------------------------------
runner = load(OWN/'探索する.py','runner126_artificial')
splitter = load(OWN/'入力を分割する.py','splitter126_artificial')


def sha(path: Path) -> str:
    """
    機能: 人工ファイルの指紋を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def dump(path: Path,value: dict) -> None:
    """
    機能: 人工fixtureをUTF-8で保存する。
    引数: path(Path)、value(dict)。返り値: None。
    """
    path.write_text(json.dumps(value,ensure_ascii=False),encoding='utf-8')


# ----------------------------------------
def pure_rows() -> tuple[list[dict],list[dict]]:
    """
    機能: 異役割の二条件ANDだけに反転優位がある人工学習表を作る。
    引数: なし。返り値: tuple[list[dict],list[dict]]。
    """
    atoms = [{'id':'A','role':'MA','feature':'a','threshold':0},
             {'id':'B','role':'勢い','feature':'b','threshold':0},
             {'id':'C','role':'量','feature':'c','threshold':1}]
    rows = []
    for i in range(80):
        a,b = (-1 if i%4<2 else 1),(-1 if i%2==0 else 1)
        wanted = a<0 and b>=0
        rows.append({'id':i,'values':{'a':a,'b':b,'c':.5 if i%3==0 else 1.5},'complete':True,
                     'base_utility':-1 if wanted else 1,'flip_utility':1 if wanted else -1,
                     'base_c5':Fraction(-100 if wanted else 100),'flip_c5':Fraction(100 if wanted else -100)})
    return rows,atoms


# ----------------------------------------
def exhaustive(rows: list[dict],atoms: list[dict],minimum: int) -> dict:
    """
    機能: 小さい人工集合の全木を直接列挙し、DPを別算法で検算する。
    引数: rows(list[dict])、atoms(list[dict])、minimum(int)。返り値: dictは最良候補。
    """
    best = {'id':'B0','tree':None,'gain':0,'money_gain':Fraction(0),'complexity':0,'score':0}
    for root in atoms:
        children = [None]+[{'atom':a,'flip_branch':b} for a in atoms if a['role']!=root['role'] for b in (True,False)]
        for left,right in product(children,repeat=2):
            if left is None and right is None:
                continue
            valid = True
            for root_branch,child in ((True,left),(False,right)):
                if child is None:
                    continue
                groups = {True:[],False:[]}
                for r in rows:
                    rv = r['values'].get(root['feature'])
                    cv = r['values'].get(child['atom']['feature'])
                    if rv is None or cv is None or (rv<root['threshold'])!=root_branch or not r['complete']:
                        continue
                    groups[cv<child['atom']['threshold']].append(r)
                flip = groups[child['flip_branch']]
                gain = sum(r['flip_utility']-r['base_utility'] for r in flip)
                pairs = [r for r in flip if r['base_c5'] is not None and r['flip_c5'] is not None]
                money = sum((r['flip_c5']-r['base_c5'] for r in pairs),Fraction(0))
                if min(map(len,groups.values()))<minimum or gain<=0 or money<=0:
                    valid = False
                    break
            if not valid:
                continue
            tree = {'root':root,'left':left,'right':right}
            flips = [r for r in rows if learner.apply(tree,r['values'])[0] and r['complete']]
            gain = sum(r['flip_utility']-r['base_utility'] for r in flips)
            money = sum((r['flip_c5']-r['base_c5'] for r in flips if r['base_c5'] is not None and r['flip_c5'] is not None),Fraction(0))
            complexity = 1+2*sum(c is not None for c in (left,right))
            candidate = {'id':learner.model_id(tree),'tree':tree,'gain':gain,'money_gain':money,
                         'complexity':complexity,'score':gain-complexity}
            if candidate['score']>0 and learner.better(candidate,best):
                best = candidate
    return best


# ----------------------------------------
def fixture() -> tuple[dict,dict,dict,dict]:
    """
    機能: 自然価格を使わず、53/26件・48/25場の全軸正逆fixtureを作る。
    引数: なし。返り値: tuple[dict,dict,dict,dict]は人工ペア・特徴・B0票・分割。
    """
    names = [f'人工{i:02d}' for i in range(73)]
    scenes = [{'session':s,'success':True,'cases':[]} for s in names]
    features,base = [],[]
    atoms = learner.catalogue()
    for i in range(79):
        si = i if i<73 else i-73 if i<78 else 48
        sid,side,key = names[si],1 if i%2==0 else -1,f'人工ID{i}'
        q = {'time':10000.+i,'index':i+1,'source_line':i+1,'bid':1000.,'ask':1010.,'last':1005.}
        end = dict(q,time=q['time']+3600,index=1000+i,source_line=1000+i,bid=1200.,ask=1210.,last=1205.)
        case = {'id':key,'original_side':side}
        for axis,reverse in product(('BBO','Last'),(False,True)):
            s = -side if reverse else side
            price = q['last'] if axis=='Last' else q['ask'] if s==1 else q['bid']
            mark = end['last'] if axis=='Last' else end['bid'] if s==1 else end['ask']
            points = s*(mark-price)
            outcomes = []
            for h in (1800,3600):
                endpoint = dict(end,time=q['time']+h)
                outcomes.append({'seconds':h,'deadline':q['time']+h,'status':'complete','endpoint':endpoint,'points':points,
                    'net0':points*100-77 if axis=='BBO' else None,'net5':points*100-1077 if axis=='BBO' else None,
                    'touches':[{'width':w,'direction':1 if points>=w else -1 if points<=-w else 0,
                                'quote':endpoint if abs(points)>=w else None} for w in (25,50,100,125,200)]})
            name = ('chart_' if axis=='Last' else '')+('reverse' if reverse else 'original')
            case[name] = {'birth':{'side':s},'entry':q,'entry_price':price,'outcomes':outcomes}
        fs = {a['feature']:{'known':True,'value':0.} for a in atoms}
        fs['candle5_body_signed_ratio'] = {'known':True,'value':.6 if i%3==0 else .9}
        fs['rvol5'] = {'known':True,'value':1.5}
        f = {'session':sid,'id':key,'original_side':side,'features':fs,'entry_quote':q,'strategy':'人工'}
        features.append(f)
        base.append({'session':sid,'id':key,'choices':{'T1':{'side':learner.b0_side(f)}}})
        scenes[si]['cases'].append(case)
    split = {'sessions':names,'train_sessions':names[:48],'validation_sessions':names[48:]}
    return {'scenes':scenes},{'features':features},{'choices':base},split


# ----------------------------------------
class Artificial126(unittest.TestCase):
    """126の自然金融実行前の人工検査。"""

    def test_catalogue_and_price_mirror(self) -> None:
        """
        機能: 45固定条件・body除外とB0変換の買売対称を検査する。
        引数: self(Artificial126)。返り値: None。
        """
        atoms = learner.catalogue()
        self.assertEqual(len(atoms),45)
        self.assertFalse(any('candle' in a['feature'] or 'body' in a['feature'] for a in atoms))
        for side in (-1,1):
            o,h,l,c = 100.,200.,100.,160.
            mo,mh,ml,mc = 1000-o,1000-l,1000-h,1000-c
            body = side*(c-o)/(h-l)
            mirror_body = -side*(mc-mo)/(mh-ml)
            self.assertEqual(body,mirror_body)
            # ----------------------------------------
            # RSI->100-RSI、Hist/EMA傾き->符号反転、sideも反転すると元向き符号値は同じ。
            rsi,hist,slope = 63.,12.,3.
            fs = {'candle5_body_signed_ratio':{'known':True,'value':body},
                  'rsi_center_signed_5':{'known':True,'value':side*(rsi-50)},
                  'hist_atr_signed_5':{'known':True,'value':side*hist/100},
                  'ema8_delta_signed_5':{'known':True,'value':side*slope},
                  'rvol5':{'known':True,'value':1.5}}
            ms = copy.deepcopy(fs)
            ms['rsi_center_signed_5']['value'] = -side*((100-rsi)-50)
            ms['hist_atr_signed_5']['value'] = -side*(-hist)/100
            ms['ema8_delta_signed_5']['value'] = -side*(-slope)
            a = {'original_side':side,'features':fs}
            b = {'original_side':-side,'features':ms}
            self.assertEqual(learner.b0_side(a),-learner.b0_side(b))
            self.assertEqual(learner.transformed_values(a,atoms),learner.transformed_values(b,atoms))

    def test_dp_matches_exhaustive(self) -> None:
        """
        機能: DP最良木を全木直接列挙と照合する。
        引数: self(Artificial126)。返り値: None。
        """
        rows,atoms = pure_rows()
        for minimum in (6,8):
            model = learner.learn(rows,atoms,minimum)
            brute = exhaustive(rows,atoms,minimum)
            for field in ('id','score','gain','complexity'):
                self.assertEqual(model[field],brute[field])
            self.assertGreater(model['score'],0)
            self.assertEqual(Fraction(model['money_gain']),brute['money_gain'])

    def test_unknown_minleaf_cost_and_two_roles(self) -> None:
        """
        機能: 未知保持・末端最小数・負の費用差・同役割禁止を検査する。
        引数: self(Artificial126)。返り値: None。
        """
        rows,atoms = pure_rows()
        model = learner.learn(rows,atoms,8)
        tree = model['tree']
        self.assertFalse(learner.apply(tree,{})[0])
        root_value = -1 if tree['root']['threshold']==0 else .5
        self.assertFalse(learner.apply(tree,{tree['root']['feature']:root_value})[0])
        self.assertIsNone(learner.learn(rows[:12],atoms,8)['tree'])
        expensive = copy.deepcopy(rows)
        for row in expensive:
            row['flip_c5'] = row['base_c5']-1
        self.assertIsNone(learner.learn(expensive,atoms,8)['tree'])
        same_role = [{**a,'role':'同一'} for a in atoms]
        self.assertIsNone(learner.learn(rows,same_role,8)['tree'])
        censored = copy.deepcopy(rows)
        for row in censored:
            row['complete'] = False
            row['base_utility'] = row['flip_utility'] = None
        self.assertIsNone(learner.learn(censored,atoms,8)['tree'])

    def test_physical_partition_and_train_read_isolation(self) -> None:
        """
        機能: 人工53/26物理分割から、学習が評価入力を開かないことを実際に監視する。
        引数: self(Artificial126)。返り値: None。
        """
        pairs,features,base,split = fixture()
        original = copy.deepcopy((pairs,features,base))
        packages = splitter.partition(pairs,features,base,split)
        self.assertEqual((pairs,features,base),original)
        self.assertEqual([len(packages[k]['records']) for k in ('train','validation')],[53,26])
        module = runner.module124()
        with TemporaryDirectory(prefix='研究126人工_') as directory:
            folder = Path(directory)
            previous_own = runner.OWN
            runner.OWN = folder
            try:
                (folder/'条件.md').write_text('人工仕様のみ',encoding='utf-8')
                # ----------------------------------------
                # 本番コードの同体検査だけに必要な写し。自然の入力/結果はコピーしない。
                (folder/'learner.py').write_bytes((OWN/'learner.py').read_bytes())
                plan = {'primary':'T8','atoms':learner.catalogue(),'spec_sha256':sha(folder/'条件.md'),
                        'feature_sha256':'人工特徴','base_choices_sha256':'人工B0'}
                dump(folder/'探索範囲.json',plan)
                dump(folder/'時系列分割.json',split)
                common = {'catalog_sha256':sha(folder/'探索範囲.json'),'split_sha256':sha(folder/'時系列分割.json'),
                          'spec_sha256':plan['spec_sha256'],'feature_sha256':'人工特徴','base_choices_sha256':'人工B0',
                          'pair_sha256':'25517066b291a0434211190299b9f0195e67f9a7d2e89c801d5b9e6b4b51c3a1'}
                for kind,name in (('train','学習入力.json'),('validation','評価入力.json')):
                    packages[kind]['fixed_inputs'] = common
                    dump(folder/name,packages[kind])
                dump(folder/'分割の確認.json',{'成功':True,'学習入力SHA256':sha(folder/'学習入力.json'),
                                             '評価入力SHA256':sha(folder/'評価入力.json')})
                original_text,original_bytes = Path.read_text,Path.read_bytes
                opened = []
                def guard_text(path,*args,**kwargs):
                    """
                    機能: 学習中の禁止入力読込を遮断する。
                    引数: path(Path)、args/kwargs(可変引数)。返り値: str。
                    """
                    opened.append(path.name)
                    self.assertNotIn(path.name,('評価入力.json','全73場の正逆結果.json','全79例の当時特徴.json'))
                    return original_text(path,*args,**kwargs)
                def guard_bytes(path,*args,**kwargs):
                    """
                    機能: SHA目的でも評価入力を開かないことを監視する。
                    引数: path(Path)、args/kwargs(可変引数)。返り値: bytes。
                    """
                    self.assertNotIn(path.name,('評価入力.json','全73場の正逆結果.json','全79例の当時特徴.json'))
                    return original_bytes(path,*args,**kwargs)
                with patch.object(Path,'read_text',guard_text),patch.object(Path,'read_bytes',guard_bytes):
                    runner.train_stage(plan,split,module)
                self.assertIn('学習入力.json',opened)
                self.assertNotIn('評価入力.json',opened)
                model_sha = sha(folder/'学習モデル.json')
                # ----------------------------------------
                # 評価はモデル固定後のみ。評価コマンド内の再学習呼出しを禁止する。
                with patch.object(runner,'learn',side_effect=AssertionError('評価中に再学習してはならない')):
                    runner.evaluate_stage(plan,split,module,model_sha)
                result = json.loads((folder/'CSV用の表.json').read_text(encoding='utf-8'))
                self.assertEqual([len(t['rows']) for t in result['tables']],[240,79,73])
                self.assertEqual(sha(folder/'学習モデル.json'),model_sha)
                stats = json.loads((folder/'集計.json').read_text(encoding='utf-8'))
                for policy in runner.POLICIES:
                    for h in ('1800','3600'):
                        for w in ('25','50','100','125','200'):
                            self.assertIsNone(stats['集計']['validation'][policy]['Last'][h][w]['ifd_net5_sum'])
                self.assertEqual(stats['B0対照bootstrap']['validation']['差の対照'],'B0')
                self.assertIs(module.selected,runner.selected)
            finally:
                runner.OWN = previous_own


if __name__=='__main__':
    unittest.main(verbosity=2)
