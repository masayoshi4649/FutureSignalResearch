"""126の探索範囲と時系列分割を、金融ラベルを開かず固定する。"""
from pathlib import Path
from collections import Counter
import hashlib
import json
from learner import catalogue,b0_side

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
FEATURE = ROOT/'work/124当時特徴の診断/全79例の当時特徴.json'
FEATURE_SHA = 'e4f0bf25156c1fe732b186c5c5d90b6e9f95718985a440d8eb7005588f734774'
BASE = ROOT/'work/125足の実体と反転切替/choices.json'
BASE_SHA = '16577b438f2de650c4398b313c2212fa124e812aea278e4dc00c529ffcb4c0a3'


def sha(path: Path) -> str:
    """
    機能: ファイルの全バイト指紋を求める。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def save(path: Path,value: dict) -> None:
    """
    機能: 未作成先へUTF-8 JSONを保存する。
    引数: path(Path)、value(dict)。返り値: None。
    """
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')


# ----------------------------------------
def main() -> None:
    """
    機能: 特徴と125B0票だけで候補・73場分割を固定する。
    引数: なし。返り値: None。124金融ペアや125損益を開かない。
    """
    assert sha(FEATURE)==FEATURE_SHA and sha(BASE)==BASE_SHA
    features = json.loads(FEATURE.read_text(encoding='utf-8'))['features']
    base = json.loads(BASE.read_text(encoding='utf-8'))
    bm = {(c['session'],c['id']):c for c in base['choices']}
    assert len(features)==len(bm)==79
    for f in features:
        assert bm[f['session'],f['id']]['choices']['T1']['side']==b0_side(f)
    sessions = list(dict.fromkeys(f['session'] for f in features))
    assert len(sessions)==73 and sessions==sorted(sessions)
    train,test = sessions[:48],sessions[48:]
    counts = Counter('train' if f['session'] in train else 'validation' for f in features)
    assert counts=={'train':53,'validation':26}
    specification = {'trial':126,'primary':'T8','policies':['O0','B0','T8','T6'],'primary_minleaf':8,
        'comparison_minleaf':6,'maximum_depth':2,'different_roles_required':True,
        'unknown':'B0を維持','body_candidate':False,'complexity_penalty_per_split_and_flip_leaf':1,
        'gain':'全H完了の±125/H60ラベル(順+1/逆-1/未到達0)のB0からの改善和',
        'leaf_guard':'両末端の全H完了数>=minimum、反転末端gain>0、両側既知C5差合計>0',
        'tie_order':['得点大','複雑さ小','gain大','C5差大','木ID辞書順小'],
        'atoms':catalogue(),'spec_sha256':sha(OWN/'条件.md'),'feature_sha256':FEATURE_SHA,'base_choices_sha256':BASE_SHA}
    split = {'trial':126,'sessions':sessions,'train_sessions':train,'validation_sessions':test,
             'training_entries':53,'validation_entries':26,'independent_unseen_period':False,
             'selection_labels':'trainのみ','all_sessions_previously_observed':True}
    save(OWN/'探索範囲.json',specification)
    save(OWN/'時系列分割.json',split)
    assert sha(FEATURE)==FEATURE_SHA and sha(BASE)==BASE_SHA
    save(OWN/'準備の確認.json',{'成功':True,'金融結果未読':True,'金融学習評価未実行':True,'全場':73,'全件':79,
         '学習場':48,'学習件数':53,'評価場':25,'評価件数':26,'条件SHA256':sha(OWN/'条件.md'),
         '探索範囲SHA256':sha(OWN/'探索範囲.json'),'分割SHA256':sha(OWN/'時系列分割.json'),
         '元特徴SHA256':FEATURE_SHA,'125B0票SHA256':BASE_SHA,'候補条件数':45})
    print(json.dumps({'成功':True,'探索範囲SHA256':sha(OWN/'探索範囲.json'),'分割SHA256':sha(OWN/'時系列分割.json'),
                      '条件SHA256':sha(OWN/'条件.md'),'学習件数':53,'評価件数':26},ensure_ascii=False))


if __name__=='__main__':
    main()
