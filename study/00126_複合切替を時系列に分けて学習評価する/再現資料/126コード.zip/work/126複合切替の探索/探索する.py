"""126の学習と評価を別コマンドにし、保存モデルSHAを境に後半を初読する。"""
from pathlib import Path
from fractions import Fraction
import argparse
import copy
import hashlib
import importlib.util
import json
from learner import catalogue,b0_side,transformed_values,apply,learn

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
MODULE = ROOT/'work/124入口の原因分析/集計する.py'
MODULE_SHA = '8479ca348231ffd77a637360797750833c9e6617c7fc4a6502e015c7a1d9f04a'
POLICIES = ('O0','B0','T8','T6')


def sha(path: Path) -> str:
    """
    機能: ファイルの全バイト指紋を求める。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def save(path: Path,value: dict) -> None:
    """
    機能: 未作成先へUTF-8 JSONを保存する。
    引数: path(Path)、value(dict)。返り値: None。
    """
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')


# ----------------------------------------
def selected(record: dict,policy: str,axis: str) -> dict:
    """
    機能: 1-pではなく、保存した実BBO/Lastの正逆候補をsideで選ぶ。
    引数: record(dict)、policy/axis(str)。返り値: dictは固定候補。
    """
    side = record['choices'][policy]['side']
    case = record['case']
    assert side in (-1,1)
    key = ('chart_' if axis=='Last' else '')+('original' if side==case['original_side'] else 'reverse')
    assert case[key]['birth']['side']==side
    return case[key]


# ----------------------------------------
def module124():
    """
    機能: 固定集計の統計・IFD関数を再用し、選択callbackだけを126票へつなぐ。
    引数: なし。返り値: Pythonモジュール。元ファイルを変更しない。
    """
    assert sha(MODULE)==MODULE_SHA
    spec = importlib.util.spec_from_file_location('fixed124_for126',MODULE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.POLICIES = POLICIES
    module.selected = selected
    return module


# ----------------------------------------
def verify_package(package: dict,plan: dict,split: dict,kind: str) -> None:
    """
    機能: 学習/評価の区分と固定指紋・全件対応を検査する。
    引数: package/plan/split(dict)、kind(str)。返り値: None。
    """
    assert package['trial']==126 and package['kind']==kind
    ids = split['train_sessions' if kind=='train' else 'validation_sessions']
    assert package['sessions']==ids
    assert len(package['records'])==(53 if kind=='train' else 26)
    assert len({(r['session'],r['case']['id']) for r in package['records']})==len(package['records'])
    assert set(r['session'] for r in package['records'])==set(ids)
    inputs = package['fixed_inputs']
    assert inputs['catalog_sha256']==sha(OWN/'探索範囲.json')
    assert inputs['split_sha256']==sha(OWN/'時系列分割.json')
    assert inputs['spec_sha256']==plan['spec_sha256']==sha(OWN/'条件.md')
    assert inputs['feature_sha256']==plan['feature_sha256']
    assert inputs['base_choices_sha256']==plan['base_choices_sha256']
    assert inputs['pair_sha256']=='25517066b291a0434211190299b9f0195e67f9a7d2e89c801d5b9e6b4b51c3a1'
    for record in package['records']:
        f,case = record['feature'],record['case']
        assert case['original_side']==f['original_side']
        assert (record['session'],case['id'])==(f['session'],f['id'])
        assert record['base_choice']['side']==b0_side(f)
        assert case['original']['entry']==case['reverse']['entry']==f['entry_quote']
        assert all(o['net0'] is None and o['net5'] is None for key in ('chart_original','chart_reverse') for o in case[key]['outcomes'])


# ----------------------------------------
def training_rows(package: dict,atoms: list[dict],module) -> list[dict]:
    """
    機能: 学習入力から主ラベルと両側既知費用後値だけを学習器へ渡す。
    引数: package(dict)はtrain必須、atoms(list[dict])、module(モジュール)。返り値: list[dict]。
    """
    assert package['kind']=='train'
    output = []
    for record in package['records']:
        f,case = record['feature'],record['case']
        side = b0_side(f)
        base = case['original' if side==case['original_side'] else 'reverse']
        flip = case['reverse' if side==case['original_side'] else 'original']
        a,b = module.observation(base,3600),module.observation(flip,3600)
        assert a['status']==b['status']
        complete = a['status']=='complete'
        ea,eb = module.ifd(base,a,125,'BBO'),module.ifd(flip,b,125,'BBO')
        output.append({'id':(record['session'],case['id']),'values':transformed_values(f,atoms),
                       'complete':complete,'base_utility':module.touch(a,125)['direction'] if complete else None,
                       'flip_utility':module.touch(b,125)['direction'] if complete else None,
                       'base_c5':Fraction(str(ea['net5'])) if ea['known'] else None,
                       'flip_c5':Fraction(str(eb['net5'])) if eb['known'] else None})
    return output


# ----------------------------------------
def annotate(records: list[dict],models: dict,atoms: list[dict]) -> list[dict]:
    """
    機能: 学習済み木だけで全票を作り、原入力を変更しない。
    引数: records(list[dict])、models(dict)、atoms(list[dict])。返り値: list[dict]。
    """
    output = copy.deepcopy(records)
    for record in output:
        f = record['feature']
        side = b0_side(f)
        record['choices'] = {'O0':{'side':f['original_side'],'flip_B0':f['original_side']!=side,'path':[]},
                             'B0':{'side':side,'flip_B0':False,'path':[]}}
        values = transformed_values(f,atoms)
        record['values_B0'] = values
        for policy in ('T8','T6'):
            flip,path = apply(models[policy]['tree'],values)
            record['choices'][policy] = {'side':-side if flip else side,'flip_B0':flip,'path':path}
    return output


# ----------------------------------------
def train_stage(plan: dict,split: dict,module) -> None:
    """
    機能: 学習入力だけを開き、主8/比較6のモデルを固定する。
    引数: plan/split(dict)、module(モジュール)。返り値: None。評価入力を開かない。
    """
    assert not (OWN/'学習モデル.json').exists()
    source = OWN/'学習入力.json'
    input_hash = sha(source)
    partition_proof = json.loads((OWN/'分割の確認.json').read_text(encoding='utf-8'))
    assert partition_proof['成功'] and partition_proof['学習入力SHA256']==input_hash
    package = json.loads(source.read_text(encoding='utf-8'))
    verify_package(package,plan,split,'train')
    rows = training_rows(package,plan['atoms'],module)
    models = {'T8':learn(rows,plan['atoms'],8),'T6':learn(rows,plan['atoms'],6)}
    assert sha(source)==input_hash
    result = {'trial':126,'success':True,'primary':'T8','training_input_sha256':input_hash,
              'catalog_sha256':sha(OWN/'探索範囲.json'),'split_sha256':sha(OWN/'時系列分割.json'),
              'partition_proof_sha256':sha(OWN/'分割の確認.json'),
              'learner_sha256':sha(OWN/'learner.py'),'runner_sha256':sha(Path(__file__)),
              'fixed_aggregate_sha256':MODULE_SHA,'evaluation_input_opened':False,
              'training_sessions':split['train_sessions'],'models':models}
    save(OWN/'学習モデル.json',result)
    save(OWN/'学習完了.json',{'成功':True,'試行':126,'学習入力SHA256':input_hash,
             'モデルSHA256':sha(OWN/'学習モデル.json'),'評価入力を開いたか':False,
             '学習場':48,'学習取得':53,'主T8':{k:v for k,v in models['T8'].items() if k!='root_audit'},
             '比較T6':{k:v for k,v in models['T6'].items() if k!='root_audit'}})
    print(json.dumps({'成功':True,'モデルSHA256':sha(OWN/'学習モデル.json'),
                      'T8':models['T8']['id'],'T6':models['T6']['id'],'評価入力を開いたか':False},ensure_ascii=False))


# ----------------------------------------
def bootstrap_b0(records: list[dict],sessions: list[str],module) -> dict:
    """
    機能: 固定bootstrapの対照callbackだけをB0へ向け、差の名称を正しくする。
    引数: records(list[dict])、sessions(list[str])、module(モジュール)。返り値: dict。
    """
    previous_selected,previous_policies = module.selected,module.POLICIES
    try:
        module.selected = lambda r,p,a:selected(r,'B0' if p=='O0' else p,a)
        module.POLICIES = ('B0','T8','T6')
        result = module.bootstrap(records,sessions)
    finally:
        module.selected,module.POLICIES = previous_selected,previous_policies
    for policy,values in result['政策'].items():
        values['B0との両側既知ペア平均差95区間'] = values.pop('O0との両側既知ペア平均差95区間')
    result['差の対照'] = 'B0'
    return result


# ----------------------------------------
def tables_for(records: list[dict],split: dict,aggregate: dict,module) -> list[dict]:
    """
    機能: 学習/評価/全体240行・入口79行・全場73行の閲覧表を作る。
    引数: records(list[dict])、split/aggregate(dict)、module(モジュール)。返り値: list[dict]。
    """
    headers = ['試行','区分','政策','価格軸','評価分','同幅pt','取得場数','取得数','原向きから反転数','全H完了','観測不足','順行先着','逆行先着','両方未到達','到達済み順行率','全完了順行率','到達済み70%達成','IFD代用既知','IFD代用未知','C0代用差引円','C5代用利益円','C5代用損失絶対円','C5代用差引円','C5代用平均円','C5代用PF']
    rows = []
    for part in ('train','validation','all'):
        for policy in POLICIES:
            for axis in module.AXES:
                for horizon in module.HORIZONS:
                    for width in module.WIDTHS:
                        s = aggregate[part][policy][axis][str(horizon)][str(width)]
                        rows.append([126,part,policy,axis,horizon/60,width,s['sessions'],s['entries'],s['flips'],s['complete'],s['censored'],s['forward'],s['adverse'],s['neither'],s['resolved_rate'],s['complete_rate'],s['target70'],s['ifd_known'],s['ifd_unknown'],s['ifd_net0_sum'],s['ifd_net5_profit'],s['ifd_net5_loss'],s['ifd_net5_sum'],s['ifd_net5_mean'],s['ifd_net5_pf']])
    # ----------------------------------------
    detail_headers = ['試行','区分','セッション','出生ID','元入口型','取得JST','元向き','B0向き','元取得価格','逆取得価格']
    for policy in POLICIES:
        detail_headers += [policy+'向き',policy+'B0反転',policy+'判断経路',policy+'125BBO全H',policy+'125BBO先着',policy+'125IFD既知',policy+'125C5代用円']
    detail = []
    for r in records:
        case,f = r['case'],r['feature']
        part = 'train' if r['session'] in split['train_sessions'] else 'validation'
        row = [126,part,r['session'],case['id'],f['strategy'],module.jst(case['original']['entry']['time']),case['original_side'],r['choices']['B0']['side'],case['original']['entry_price'],case['reverse']['entry_price']]
        for policy in POLICIES:
            c = selected(r,policy,'BBO')
            o = module.observation(c,3600)
            e = module.ifd(c,o,125,'BBO')
            path = json.dumps(r['choices'][policy]['path'],ensure_ascii=False,separators=(',',':'))
            row += [r['choices'][policy]['side'],r['choices'][policy]['flip_B0'],path,o['status'],module.touch(o,125)['direction'],e['known'],e['net5']]
        detail.append(row)
    # ----------------------------------------
    session_headers = ['試行','区分','セッション','取得数','最低1回達成']
    for policy in POLICIES:
        session_headers += [policy+'原向きから反転数',policy+'125順',policy+'125逆',policy+'125未到達',policy+'全H観測不足',policy+'IFD既知',policy+'IFD未知',policy+'C5利益円',policy+'C5損失絶対円',policy+'C5既知差引円',policy+'C5既知累計円（口座収支ではない）',policy+'累計IFD未知']
    totals,unknown = {p:0 for p in POLICIES},{p:0 for p in POLICIES}
    session_rows = []
    for sid in split['sessions']:
        subset = [r for r in records if r['session']==sid]
        row = [126,'train' if sid in split['train_sessions'] else 'validation',sid,len(subset),bool(subset)]
        for policy in POLICIES:
            s = module.stats(subset,policy,'BBO',3600,125)
            if s['ifd_net5_sum'] is not None:
                totals[policy] += s['ifd_net5_sum']
            unknown[policy] += s['ifd_unknown']
            row += [s['flips'],s['forward'],s['adverse'],s['neither'],s['censored'],s['ifd_known'],s['ifd_unknown'],s['ifd_net5_profit'],s['ifd_net5_loss'],s['ifd_net5_sum'],totals[policy],unknown[policy]]
        session_rows.append(row)
    tables = [{'name':'正逆比較','headers':headers,'rows':rows},{'name':'入口別診断','headers':detail_headers,'rows':detail},{'name':'全セッション','headers':session_headers,'rows':session_rows}]
    assert [len(t['rows']) for t in tables]==[240,79,73]
    assert all(all(len(r)==len(t['headers']) for r in t['rows']) for t in tables)
    return tables


# ----------------------------------------
def evaluate_stage(plan: dict,split: dict,module,model_sha: str) -> None:
    """
    機能: 保存モデルSHAを確認した後、初めて評価入力を開き全区分を報告する。
    引数: plan/split(dict)、module(モジュール)、model_sha(str)。返り値: None。
    """
    path = OWN/'学習モデル.json'
    assert model_sha and sha(path)==model_sha
    models = json.loads(path.read_text(encoding='utf-8'))
    assert models['trial']==126 and models['success'] and models['primary']=='T8'
    assert models['learner_sha256']==sha(OWN/'learner.py') and models['runner_sha256']==sha(Path(__file__))
    assert models['catalog_sha256']==sha(OWN/'探索範囲.json') and models['split_sha256']==sha(OWN/'時系列分割.json')
    assert models['training_input_sha256']==sha(OWN/'学習入力.json')
    assert models['partition_proof_sha256']==sha(OWN/'分割の確認.json')
    partition_proof = json.loads((OWN/'分割の確認.json').read_text(encoding='utf-8'))
    assert partition_proof['評価入力SHA256']==sha(OWN/'評価入力.json')
    assert not (OWN/'集計.json').exists() and not (OWN/'CSV用の表.json').exists()
    packages = {}
    input_hashes = {}
    for kind,name in (('train','学習入力.json'),('validation','評価入力.json')):
        input_hashes[name] = sha(OWN/name)
        packages[kind] = json.loads((OWN/name).read_text(encoding='utf-8'))
        verify_package(packages[kind],plan,split,kind)
    assert packages['train']['fixed_inputs']==packages['validation']['fixed_inputs']
    records = annotate(packages['train']['records']+packages['validation']['records'],models['models'],plan['atoms'])
    parts = {'train':[r for r in records if r['session'] in split['train_sessions']],
             'validation':[r for r in records if r['session'] in split['validation_sessions']],'all':records}
    aggregate = {part:{p:{axis:{str(h):{str(w):module.stats(rows,p,axis,h,w) for w in module.WIDTHS} for h in module.HORIZONS} for axis in module.AXES} for p in POLICIES} for part,rows in parts.items()}
    boots = {part:module.bootstrap(rows,split['sessions'] if part=='all' else split['train_sessions'] if part=='train' else split['validation_sessions']) for part,rows in parts.items()}
    base_boots = {part:bootstrap_b0(rows,split['sessions'] if part=='all' else split['train_sessions'] if part=='train' else split['validation_sessions'],module) for part,rows in parts.items()}
    for part,boot in boots.items():
        boot['区分'] = part
        boot['単位'] = f"当区分の全{len(split['sessions'] if part=='all' else split['train_sessions'] if part=='train' else split['validation_sessions'])}場を復元抽出、未知を0円観測にしない"
        boot['差の対照'] = 'O0（B0対照ではない。固定124関数のまま）'
        base_boots[part]['区分'] = part
        base_boots[part]['単位'] = boot['単位']
    tables = tables_for(records,split,aggregate,module)
    result = {'成功':True,'試行':126,'主政策':'T8','主評価区分':'validation','主幅pt':125,'主時間秒':3600,
              '全場数':73,'固定取得数':79,'学習場数':48,'評価場数':25,'モデルSHA256':model_sha,
              '入力SHA256':input_hashes,'集計':aggregate,'bootstrap':boots,'B0対照bootstrap':base_boots,
              '学習モデル':{p:{k:v for k,v in m.items() if k!='root_audit'} for p,m in models['models'].items()},
              '既知期間の時系列内分割':True,'B0は全73場選択済み':True,'独立未知期検証':False,
              '口座収支':False,'IFD実約定':False,'多重比較補正':False,
              '価格参考':'Last金額は全てnull。先着Rawの気配清算代用は実約定を示さない。'}
    for name,expected in input_hashes.items():
        assert sha(OWN/name)==expected
    assert sha(path)==model_sha and sha(MODULE)==MODULE_SHA
    save(OWN/'集計.json',result)
    save(OWN/'CSV用の表.json',{'試行':126,'成功':True,'model_sha256':model_sha,'意味':'既知期間の時系列内分割。独立1miniのIFD清算代用であり口座収支ではない。','tables':tables})
    save(OWN/'評価完了.json',{'成功':True,'試行':126,'モデルSHA256':model_sha,
             '集計SHA256':sha(OWN/'集計.json'),'表SHA256':sha(OWN/'CSV用の表.json'),
             '入力前後不変':True,'CSV行数':[len(t['rows']) for t in tables]})
    print(json.dumps({'成功':True,'主評価':aggregate['validation']['T8']['BBO']['3600']['125'],
                      '全体参考':aggregate['all']['T8']['BBO']['3600']['125'],'CSV行数':[len(t['rows']) for t in tables]},ensure_ascii=False))


# ----------------------------------------
def main() -> None:
    """
    機能: 固定探索範囲で学習又はモデル固定後の評価を実行する。
    引数: CLI --mode(str)、--fixed-catalog-sha256(str)、--model-sha256(str|None)。返り値: None。
    """
    parser = argparse.ArgumentParser(description='126の学習と評価を分ける')
    parser.add_argument('--mode',required=True,choices=('train','evaluate'))
    parser.add_argument('--fixed-catalog-sha256',required=True)
    parser.add_argument('--model-sha256')
    args = parser.parse_args()
    assert sha(OWN/'探索範囲.json')==args.fixed_catalog_sha256
    plan = json.loads((OWN/'探索範囲.json').read_text(encoding='utf-8'))
    split = json.loads((OWN/'時系列分割.json').read_text(encoding='utf-8'))
    assert plan['atoms']==catalogue() and plan['primary']=='T8'
    assert plan['spec_sha256']==sha(OWN/'条件.md')
    module = module124()
    if args.mode=='train':
        assert args.model_sha256 is None
        train_stage(plan,split,module)
    else:
        evaluate_stage(plan,split,module,args.model_sha256)


if __name__=='__main__':
    main()
