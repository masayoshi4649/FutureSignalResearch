"""固定後にだけ実行し、126学習/評価を場IDで物理分割する。閾値選択は行わない。"""
from pathlib import Path
import argparse
import copy
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
PAIR = ROOT/'work/124入口の正逆比較/全73場の正逆結果.json'
PAIR_SHA = '25517066b291a0434211190299b9f0195e67f9a7d2e89c801d5b9e6b4b51c3a1'
FEATURE = ROOT/'work/124当時特徴の診断/全79例の当時特徴.json'
FEATURE_SHA = 'e4f0bf25156c1fe732b186c5c5d90b6e9f95718985a440d8eb7005588f734774'
BASE = ROOT/'work/125足の実体と反転切替/choices.json'
BASE_SHA = '16577b438f2de650c4398b313c2212fa124e812aea278e4dc00c529ffcb4c0a3'


def sha(path: Path) -> str:
    """
    機能: ファイルの全バイト指紋を求める。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def save(path: Path,value: dict) -> None:
    """
    機能: 未作成先にUTF-8 JSONを保存する。
    引数: path(Path)、value(dict)。返り値: None。
    """
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')


# ----------------------------------------
def partition(pairs: dict,features: dict,base: dict,split: dict) -> dict:
    """
    機能: 閾値又は結果の良し悪しを使わず、固定した場IDだけで学習/評価へ分ける。
    引数: pairs/features/base/split(dict)。返り値: dictはtrain/validationの独立正本。
    """
    fmap = {(f['session'],f['id']):f for f in features['features']}
    bmap = {(b['session'],b['id']):b for b in base['choices']}
    assert len(fmap)==len(bmap)==79
    assert [s['session'] for s in pairs['scenes']]==split['sessions']
    output = {kind:{'trial':126,'kind':kind,'sessions':split[key],'records':[]} for kind,key in
              (('train','train_sessions'),('validation','validation_sessions'))}
    seen = set()
    for scene in pairs['scenes']:
        sid = scene['session']
        assert scene['success'] and scene['cases']
        kind = 'train' if sid in split['train_sessions'] else 'validation'
        assert sid in output[kind]['sessions']
        for case in scene['cases']:
            key = sid,case['id']
            assert key in fmap and key in bmap and key not in seen
            seen.add(key)
            feature = fmap[key]
            assert case['original_side']==feature['original_side']
            assert case['original']['entry']==feature['entry_quote']
            output[kind]['records'].append({'session':sid,'case':copy.deepcopy(case),
                                          'feature':copy.deepcopy(feature),'base_choice':copy.deepcopy(bmap[key]['choices']['T1'])})
    assert seen==set(fmap)==set(bmap)
    assert (len(output['train']['sessions']),len(output['train']['records']))==(48,53)
    assert (len(output['validation']['sessions']),len(output['validation']['records']))==(25,26)
    return output


# ----------------------------------------
def main() -> None:
    """
    機能: Root固定後、指紋一致を確認して入力を物理分割する。
    引数: CLI --fixed-catalog-sha256(str)。返り値: None。
    """
    parser = argparse.ArgumentParser(description='金融計算せず126入力を物理分割する')
    parser.add_argument('--fixed-catalog-sha256',required=True)
    args = parser.parse_args()
    assert sha(OWN/'探索範囲.json')==args.fixed_catalog_sha256
    fingerprints = {PAIR:PAIR_SHA,FEATURE:FEATURE_SHA,BASE:BASE_SHA}
    for path,expected in fingerprints.items():
        assert sha(path)==expected
    assert not (OWN/'学習入力.json').exists() and not (OWN/'評価入力.json').exists()
    split = json.loads((OWN/'時系列分割.json').read_text(encoding='utf-8'))
    packages = partition(json.loads(PAIR.read_text(encoding='utf-8')),
                         json.loads(FEATURE.read_text(encoding='utf-8')),
                         json.loads(BASE.read_text(encoding='utf-8')),split)
    common = {'pair_sha256':PAIR_SHA,'feature_sha256':FEATURE_SHA,'base_choices_sha256':BASE_SHA,
              'spec_sha256':sha(OWN/'条件.md'),'catalog_sha256':sha(OWN/'探索範囲.json'),
              'split_sha256':sha(OWN/'時系列分割.json'),'partition_code_sha256':sha(Path(__file__))}
    for kind,name in (('train','学習入力.json'),('validation','評価入力.json')):
        packages[kind]['fixed_inputs'] = common
        save(OWN/name,packages[kind])
    for path,expected in fingerprints.items():
        assert sha(path)==expected
    save(OWN/'分割の確認.json',{'成功':True,'試行':126,'閾値探索なし':True,'成績計算なし':True,
              '学習入力SHA256':sha(OWN/'学習入力.json'),'評価入力SHA256':sha(OWN/'評価入力.json'),
              '学習場':48,'学習取得':53,'評価場':25,'評価取得':26,'元入力前後不変':True,**common})
    print(json.dumps({'成功':True,'学習入力SHA256':sha(OWN/'学習入力.json'),'評価入力SHA256':sha(OWN/'評価入力.json')},ensure_ascii=False))


if __name__=='__main__':
    main()
