"""時系列内の学習行だけを受け取る、有限候補・深さ2の複合切替学習器。"""
from fractions import Fraction
import json
import math


def catalogue() -> list[dict]:
    """
    機能: 124の事前境界と符号0だけから、4役割45個の二分条件を作る。
    引数: なし。返り値: list[dict]はID・役割・元特徴・境界・符号変換。
    """
    definitions = []
    for width in (5,15,30):
        for name in ('gap','ema8_delta','ema21_delta','di_delta'):
            definitions.append(('MA方向・位置',f'{name}_signed_{width}',(0,),True))
    for ema in ('ema8','ema21'):
        definitions.append(('MA方向・位置',f'last_{ema}_atr_signed_5',(-1,-.25,.25,1,2),True))
    definitions += [('勢い','rsi_center_signed_5',(-20,-15,0,15,20),True),
                    ('勢い','rsi_delta_signed_5',(-10,-5,0,5,10),True),
                    ('勢い','hist_atr_signed_5',(-.1,0,.1),True),
                    ('勢い','hist_delta_atr_signed_5',(-.1,0,.1),True),
                    ('値幅','tr_previous_atr_ratio_5',(.5,1,2,3),False),
                    ('量','rvol5',(.5,1,2),False)]
    output = []
    for role,feature,cuts,signed in definitions:
        for cut in cuts:
            output.append({'id':f'A{len(output)+1:02d}','role':role,'feature':feature,
                           'threshold':cut,'signed_to_B0':signed,'operator':'既知値<境界'})
    assert len(output)==45 and len({a['id'] for a in output})==45
    return output


# ----------------------------------------
def number(features: dict, key: str) -> float | None:
    """
    機能: 未知と0を区別し、有限の既知値だけを返す。
    引数: features(dict)、key(str)。返り値: float|None。
    """
    value = features.get(key,{'known':False,'value':None})
    assert type(value['known']) is bool
    if not value['known']:
        assert value.get('value') is None
        return None
    out = value['value']
    assert type(out) in (int,float) and math.isfinite(out)
    return out


# ----------------------------------------
def b0_side(feature: dict) -> int:
    """
    機能: 125主T1の固定方向を当時特徴だけから再構成する。
    引数: feature(dict)は元向き・特徴票。返り値: intは±1。
    """
    side = feature['original_side']
    assert side in (-1,1)
    body = number(feature['features'],'candle5_body_signed_ratio')
    return -side if body is not None and .5<=body<.75 else side


# ----------------------------------------
def transformed_values(feature: dict, atoms: list[dict]) -> dict:
    """
    機能: 元向きの符号付き特徴をB0向きに合わせ、未知を保持する。
    引数: feature(dict)、atoms(list[dict])。返り値: dictは特徴キーと変換後値。
    """
    factor = b0_side(feature)*feature['original_side']
    output = {}
    for atom in atoms:
        key = atom['feature']
        if key in output:
            continue
        value = number(feature['features'],key)
        output[key] = value*factor if value is not None and atom['signed_to_B0'] else value
    return output


# ----------------------------------------
def branch(values: dict, atom: dict) -> bool | None:
    """
    機能: 固定条件を既知True/False又は未知として評価する。
    引数: values(dict)、atom(dict)。返り値: bool|None。
    """
    value = values.get(atom['feature'])
    return None if value is None else value<atom['threshold']


# ----------------------------------------
def model_id(tree: dict | None) -> str:
    """
    機能: 同点を再現可能に解消する短い木IDを作る。
    引数: tree(dict|None)。返り値: str。
    """
    if tree is None:
        return 'B0'
    child = lambda c: '-' if c is None else f"{c['atom']['id']}:{int(c['flip_branch'])}"
    return f"{tree['root']['id']}|1:{child(tree['left'])}|0:{child(tree['right'])}"


# ----------------------------------------
def apply(tree: dict | None, values: dict) -> tuple[bool, list[dict]]:
    """
    機能: 深さ2木を評価し、B0反転の有無と当時値の経路を返す。
    引数: tree(dict|None)、values(dict)。返り値: tuple[bool,list[dict]]。
    """
    if tree is None:
        return False,[]
    root = tree['root']
    side = branch(values,root)
    path = [{**root,'value':values.get(root['feature']),'branch':side}]
    if side is None:
        return False,path
    child = tree['left'] if side else tree['right']
    if child is None:
        return False,path
    leaf = branch(values,child['atom'])
    path.append({**child['atom'],'value':values.get(child['atom']['feature']),'branch':leaf})
    return leaf is not None and leaf==child['flip_branch'],path


# ----------------------------------------
def better(candidate: dict, previous: dict) -> bool:
    """
    機能: 事前固定の得点・複雑さ・gain・C5改善・ID順で候補を比べる。
    引数: candidate/previous(dict)。返り値: boolはcandidate優先時True。
    """
    key = lambda c:(c['score'],-c['complexity'],c['gain'],c['money_gain'])
    a,b = key(candidate),key(previous)
    return a>b or a==b and candidate['id']<previous['id']


# ----------------------------------------
def best_child(rows: list[dict], root: dict, atoms: list[dict], minimum: int) -> tuple[dict,list[dict]]:
    """
    機能: 1枝内で異役割のchildと片方の反転末端を有限探索する。
    引数: rows(list[dict])は学習行のみ、root(dict)、atoms(list[dict])、minimum(int)。
    返り値: tuple[dict,list[dict]]は最良寄与と全候補監査票。
    """
    best = {'id':'B0','node':None,'gain':0,'money_gain':Fraction(0),'complexity':0,'score':0}
    audit = []
    for atom in atoms:
        if atom['role']==root['role']:
            continue
        groups = {True:[],False:[]}
        for row in rows:
            value = branch(row['values'],atom)
            if value is not None:
                groups[value].append(row)
        counts = {b:sum(r['complete'] for r in group) for b,group in groups.items()}
        if min(counts.values())<minimum:
            continue
        for flip in (True,False):
            eligible = [r for r in groups[flip] if r['complete']]
            gain = sum(r['flip_utility']-r['base_utility'] for r in eligible)
            paired = [r for r in eligible if r['base_c5'] is not None and r['flip_c5'] is not None]
            money = sum((r['flip_c5']-r['base_c5'] for r in paired),Fraction(0))
            record = {'atom':atom['id'],'flip_branch':flip,'true_complete':counts[True],
                      'false_complete':counts[False],'gain':gain,'paired_known':len(paired),'money_gain':str(money)}
            audit.append(record)
            if gain<=0 or money<=0:
                continue
            candidate = {'id':f"{atom['id']}:{int(flip)}",'node':{'atom':atom,'flip_branch':flip},
                         'gain':gain,'money_gain':money,'complexity':2,'score':gain-2,
                         'true_complete':counts[True],'false_complete':counts[False],'paired_known':len(paired)}
            if better(candidate,best):
                best = candidate
    return best,audit


# ----------------------------------------
def learn(rows: list[dict], atoms: list[dict], minimum: int) -> dict:
    """
    機能: 学習行だけで深さ2の主8/比較6モデルを決める。
    引数: rows(list[dict])、atoms(list[dict])、minimum(int)は6又は8。
    返り値: dictは木・選択得点・全rootの監査票。評価行は受け取らない。
    """
    assert minimum in (6,8) and rows
    assert len({r['id'] for r in rows})==len(rows)
    best = {'id':'B0','tree':None,'gain':0,'money_gain':Fraction(0),'complexity':0,'score':0}
    audit = []
    for root in atoms:
        groups = {True:[],False:[]}
        for row in rows:
            value = branch(row['values'],root)
            if value is not None:
                groups[value].append(row)
        left,la = best_child(groups[True],root,atoms,minimum)
        right,ra = best_child(groups[False],root,atoms,minimum)
        if left['node'] is None and right['node'] is None:
            audit.append({'root':root['id'],'left_candidates':la,'right_candidates':ra,'feasible_tree':False})
            continue
        tree = {'root':root,'left':left['node'],'right':right['node']}
        gain = left['gain']+right['gain']
        complexity = 1+left['complexity']+right['complexity']
        candidate = {'id':model_id(tree),'tree':tree,'gain':gain,'money_gain':left['money_gain']+right['money_gain'],
                     'complexity':complexity,'score':gain-complexity}
        audit.append({'root':root['id'],'left_candidates':la,'right_candidates':ra,'feasible_tree':True,
                      'best_left':left['id'],'best_right':right['id'],'gain':gain,'complexity':complexity,
                      'score':candidate['score'],'money_gain':str(candidate['money_gain']),'tree_id':candidate['id']})
        if candidate['score']>0 and better(candidate,best):
            best = candidate
    # ----------------------------------------
    flips = [r for r in rows if apply(best['tree'],r['values'])[0]]
    verified_gain = sum(r['flip_utility']-r['base_utility'] for r in flips if r['complete'])
    assert verified_gain==best['gain']
    return {'minimum_complete_leaf':minimum,'id':best['id'],'tree':best['tree'],'gain':best['gain'],
            'money_gain':str(best['money_gain']),'complexity':best['complexity'],'score':best['score'],
            'training_rows':len(rows),'training_complete':sum(r['complete'] for r in rows),
            'training_flips':len(flips),'root_audit':audit,'evaluated_roots':len(atoms)}
