"""固定金融計算の数値を変えず、CSV入口明細の重複した列名だけを区別する。"""
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
OWN=Path(__file__).resolve().parent


def main() -> None:
    """
    機能: 基準方向列と政策B0方向列を区別し、元表と全データの同体を確認する。
    引数: なし。返り値: None。固定された金融コード・元表は変更しない。
    """
    source=ROOT/'work/126複合切替の探索/CSV用の表.json'
    original=source.read_bytes()
    assert hashlib.sha256(original).hexdigest()=='f48f2fa944960d27331f6a80f9f2ea274c1473b3991d7402074292b47620bd57'
    value=json.loads(original)
    table=value['tables'][1]
    assert table['name']=='入口別診断' and table['headers'][7]==table['headers'][17]=='B0向き'
    table['headers'][7]='基準方向（125T1）'
    assert all(len(set(t['headers']))==len(t['headers']) for t in value['tables'])
    restored=json.loads(json.dumps(value,ensure_ascii=False))
    restored['tables'][1]['headers'][7]='B0向き'
    assert restored==json.loads(original)
    output=OWN/'CSV用の閲覧表.json'
    with output.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    proof={'試行':126,'成功':True,'元SHA256':hashlib.sha256(original).hexdigest(),'閲覧表SHA256':hashlib.sha256(output.read_bytes()).hexdigest(),
           '変更':'入口別診断H列の見出しB0向き→基準方向（125T1）。R列の政策B0向きはそのまま。','全データ値型列順不変':True,'金融コードと元表不変':True}
    (OWN/'見出し補正の確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':
    main()
