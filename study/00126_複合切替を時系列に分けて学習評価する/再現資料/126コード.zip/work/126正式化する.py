"""126の実行前原文確認後に、コード・圧縮モデル・集計・段階指紋を最小保管する。"""
from pathlib import Path
import gzip
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent.parent
SOURCE = ROOT/'work/126複合切替の探索'
FORMAL = ROOT/'study/00126_複合切替を時系列に分けて学習評価する'


def sha(data: bytes) -> str:
    """
    機能: 全bytesの指紋を求める。
    引数: data(bytes)。返り値: strはSHA256。
    """
    return hashlib.sha256(data).hexdigest()


# ----------------------------------------
def save(path: Path,value: dict) -> None:
    """
    機能: 未作成先へ日本語UTF-8 JSONを保存する。
    引数: path(Path)、value(dict)。返り値: None。
    """
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')


# ----------------------------------------
def copy(source: Path,destination: Path) -> dict:
    """
    機能: 未作成先へ同bytesを保管し前後同体を確認する。
    引数: source/destination(Path)。返り値: dictは出典・保存先・サイズ・指紋。
    """
    data = source.read_bytes()
    with destination.open('xb') as stream:
        stream.write(data)
    assert destination.read_bytes()==data
    return {'source':source.relative_to(ROOT).as_posix(),'path':destination.relative_to(FORMAL).as_posix(),
            'bytes':len(data),'sha256':sha(data)}


# ----------------------------------------
def compress(source: Path,destination: Path) -> dict:
    """
    機能: 全文を一度だけgzip保存し、解凍後の全bytesを照合する。
    引数: source/destination(Path)。返り値: dictは圧縮・解凍指紋。
    """
    data = source.read_bytes()
    encoded = gzip.compress(data,mtime=0)
    with destination.open('xb') as stream:
        stream.write(encoded)
    assert gzip.decompress(destination.read_bytes())==data
    return {'path':destination.relative_to(FORMAL).as_posix(),'bytes':len(encoded),'sha256':sha(encoded),
            'decoded_bytes':len(data),'decoded_sha256':sha(data)}


# ----------------------------------------
def main() -> None:
    """
    機能: 126の再現に必要な最小成果物を恒久保存する。金融計算はしない。
    引数: なし。返り値: None。
    """
    for name in ('検査','根拠','成果物','再現資料'):
        (FORMAL/name).mkdir(exist_ok=True)
    f1 = json.loads((SOURCE/'F1.json').read_text(encoding='utf-8'))
    archive = json.loads(gzip.decompress((FORMAL/'検査/実行前文書.json.gz').read_bytes()))
    assert len(archive['原文'])==5 and archive['F1_sha256']==sha((SOURCE/'F1.json').read_bytes())
    expected = {Path(p).relative_to(ROOT).as_posix():s for p,s in f1['事前文書'].items()}
    for entry in archive['原文']:
        assert sha(entry['utf8_text'].encode('utf-8'))==expected[entry['restore_relative']]==entry['sha256']
    for path,expected_sha in {**f1['コード'],**f1['入力']}.items():
        assert sha(Path(path).read_bytes())==expected_sha
    copied = []
    for name in ('F1.json','分割固定.json','モデル固定.json','段階実行完了.json','学習完了.json',
                 '評価完了.json','分割の確認.json','準備の確認.json','人工検査.json'):
        copied.append(copy(SOURCE/name,FORMAL/'検査'/name))
    for name in ('条件.md','探索範囲.json','時系列分割.json'):
        copied.append(copy(SOURCE/name,FORMAL/'根拠'/name))
    copied.append(copy(ROOT/'work/126独立検算/確認.json',FORMAL/'検査/独立検算.json'))
    copied.append(copy(ROOT/'work/126独立検算/結果の確認.md',FORMAL/'検査/独立数値検算.md'))
    compressed = [compress(SOURCE/'集計.json',FORMAL/'成果物/集計.json.gz'),
                  compress(SOURCE/'学習モデル.json',FORMAL/'成果物/学習モデル.json.gz')]
    # ----------------------------------------
    # F1の新規6コードを保存し、既保存の124共通集計は旧ZIPを参照する。
    paths = [Path(p) for p in f1['コード'] if Path(p).resolve()!=(ROOT/'work/124入口の原因分析/集計する.py').resolve()]
    assert len(paths)==6 and ROOT/'work/126段階を固定して実行する.py' in paths
    paths += [ROOT/'work/126独立検算/検算する.py',Path(__file__).resolve()]
    zip_path = FORMAL/'再現資料/126コード.zip'
    entries = []
    with zipfile.ZipFile(zip_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive_file:
        for path in paths:
            name = path.relative_to(ROOT).as_posix()
            data = path.read_bytes()
            entry = zipfile.ZipInfo(name,(1980,1,1,0,0,0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            archive_file.writestr(entry,data)
            entries.append({'entry':name,'restore_relative':name,'bytes':len(data),'sha256':sha(data)})
    with zipfile.ZipFile(zip_path) as archive_file:
        assert archive_file.testzip() is None
        for entry in entries:
            assert sha(archive_file.read(entry['entry']))==entry['sha256']
            entry['crc32'] = f"{archive_file.getinfo(entry['entry']).CRC:08x}"
    index = {'trial':126,'F1_sha256':sha((SOURCE/'F1.json').read_bytes()),
        'zip':{'path':'126コード.zip','bytes':zip_path.stat().st_size,'sha256':sha(zip_path.read_bytes())},'entries':entries,
        'external_fixed_module':{'restore_relative':'work/124入口の原因分析/集計する.py',
          'archive':'../../00124_逆行の原因と売買反転を同じ入口で検証する/再現資料/124コード.zip',
          'entry':'work/124入口の原因分析/集計する.py','sha256':'8479ca348231ffd77a637360797750833c9e6617c7fc4a6502e015c7a1d9f04a'}}
    save(FORMAL/'再現資料/コード復元索引.json',index)
    # ----------------------------------------
    # 原板・既存特徴・B0・分割payloadの複製を避け、共用正本と再生成指紋だけを残す。
    references = []
    for relative,digest in (
        ('study/00124_逆行の原因と売買反転を同じ入口で検証する/成果物/全73場の正逆結果.json.gz','25517066b291a0434211190299b9f0195e67f9a7d2e89c801d5b9e6b4b51c3a1'),
        ('inputs/00124_同入口正逆の共用入力/全79例の当時特徴.json.gz','e4f0bf25156c1fe732b186c5c5d90b6e9f95718985a440d8eb7005588f734774'),
        ('inputs/00125_条件付き反転/choices.json.gz','16577b438f2de650c4398b313c2212fa124e812aea278e4dc00c529ffcb4c0a3')):
        encoded = (ROOT/relative).read_bytes()
        decoded = gzip.decompress(encoded)
        assert sha(decoded)==digest
        references.append({'repository_relative':relative,'gzip_bytes':len(encoded),'gzip_sha256':sha(encoded),
                           'decoded_bytes':len(decoded),'decoded_sha256':digest})
    split = json.loads((SOURCE/'分割の確認.json').read_text(encoding='utf-8'))
    save(FORMAL/'根拠/共用入力と分割指紋.json',{'trial':126,'references':references,
        'generated_inputs_not_duplicated':True,'training_bytes':(SOURCE/'学習入力.json').stat().st_size,
        'training_sha256':split['学習入力SHA256'],'validation_bytes':(SOURCE/'評価入力.json').stat().st_size,
        'validation_sha256':split['評価入力SHA256'],'recipe':'入力を分割する.py。固定48/25場でjoinのみ。',
        'tables_regenerated_not_duplicated':True,'tables_sha256':sha((SOURCE/'CSV用の表.json').read_bytes())})
    save(FORMAL/'検査/保存の確認.json',{'成功':True,'試行':126,'金融再実行なし':True,
        '実行前5原文確認済':True,'コピー':copied,'圧縮保存':compressed,'コードZIP':index['zip'],
        'コードZIP全entry復元一致':True,'原板と分割payload重複保存なし':True,
        '保存コードSHA256':sha(Path(__file__).read_bytes())})
    print(json.dumps({'成功':True,'zip':index['zip'],'圧縮':compressed,'保存proofSHA256':sha((FORMAL/'検査/保存の確認.json').read_bytes())},ensure_ascii=False))


if __name__=='__main__':
    main()
