"""126の実装をimportせず、固定JSONから正逆・費用・240/79/73表をFractionで独立検算する。"""
from pathlib import Path
from fractions import Fraction
from collections import Counter
from datetime import datetime,timezone,timedelta
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
SOURCE = ROOT/'work/126複合切替の探索'
PAIR = ROOT/'work/124入口の正逆比較/全73場の正逆結果.json'
FEATURE = ROOT/'work/124当時特徴の診断/全79例の当時特徴.json'
BASE = ROOT/'work/125足の実体と反転切替/choices.json'
POLICIES = ('O0','B0','T8','T6')
WIDTHS = (25,50,100,125,200)
HORIZONS = (1800,3600)


def sha(path: Path) -> str:
    """
    機能: 許可されたファイルの全バイト指紋を求める。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def read(path: Path) -> dict:
    """
    機能: 数値を10進有理数のまま読む。126コードをimportしない。
    引数: path(Path)。返り値: dict。
    """
    return json.loads(path.read_text(encoding='utf-8'),parse_float=Fraction)


# ----------------------------------------
def equal(actual,expected,label: str) -> None:
    """
    機能: 配列・辞書・数値・未知を再帰比較する。小数表示だけに丸め許容を与える。
    引数: actual/expected(任意型)、label(str)。返り値: None。
    """
    if actual is None or expected is None or isinstance(actual,bool) or isinstance(expected,bool):
        assert actual is expected,(label,actual,expected)
    elif isinstance(actual,(int,Fraction)) and isinstance(expected,(int,Fraction)):
        assert abs(actual-expected)<=max(Fraction(1,10**11),abs(expected)*Fraction(1,10**13)),(label,actual,expected)
    elif isinstance(expected,dict):
        assert isinstance(actual,dict) and set(actual)==set(expected),(label,set(actual),set(expected))
        for key in expected:
            equal(actual[key],expected[key],label+'/'+str(key))
    elif isinstance(expected,(list,tuple)):
        assert isinstance(actual,(list,tuple)) and len(actual)==len(expected),(label,len(actual),len(expected))
        for i,(a,b) in enumerate(zip(actual,expected)):
            equal(a,b,label+'/'+str(i))
    else:
        assert actual==expected,(label,actual,expected)


# ----------------------------------------
def value(feature: dict,key: str) -> Fraction | int | None:
    """
    機能: 指定した当時特徴の既知maskを尊重して値を取り出す。
    引数: feature(dict)、key(str)。返り値: Fraction|int|None。
    """
    field = feature['features'].get(key,{'known':False,'value':None})
    assert type(field['known']) is bool
    if not field['known']:
        assert field['value'] is None
        return None
    assert type(field['value']) in (int,Fraction)
    return field['value']


# ----------------------------------------
def base_direction(feature: dict) -> int:
    """
    機能: 125固定T1の方向を別式で再構成する。
    引数: feature(dict)。返り値: intは±1。
    """
    b = value(feature,'candle5_body_signed_ratio')
    inside = b is not None and Fraction(1,2)<=b<Fraction(3,4)
    return feature['original_side']*(-1 if inside else 1)


# ----------------------------------------
def walk(tree: dict | None,feature: dict) -> tuple[int,list[dict]]:
    """
    機能: 保存された木だけを評価し、未知ならB0、既知なら当時値の経路を記録する。
    引数: tree(dict|None)、feature(dict)。返り値: tuple[int,list[dict]]はsideと経路。
    """
    base = base_direction(feature)
    if tree is None:
        return base,[]
    factor = base*feature['original_side']
    def condition(atom: dict) -> tuple[bool | None,dict]:
        """
        機能: 1条件を既知True/False又は未知へ評価する。
        引数: atom(dict)。返り値: tuple[bool|None,dict]。
        """
        v = value(feature,atom['feature'])
        if v is not None and atom['signed_to_B0']:
            v *= factor
        branch = None if v is None else v<atom['threshold']
        return branch,{**atom,'value':v,'branch':branch}
    first,step = condition(tree['root'])
    path = [step]
    if first is None:
        return base,path
    child = tree['left' if first else 'right']
    if child is None:
        return base,path
    second,step = condition(child['atom'])
    path.append(step)
    return (-base if second is not None and second==child['flip_branch'] else base),path


# ----------------------------------------
def candidate(record: dict,policy: str,axis: str) -> dict:
    """
    機能: 選択sideに対応する実BBO又はLast候補を選ぶ。勝敗を反転しない。
    引数: record(dict)、policy/axis(str)。返り値: dict。
    """
    side = record['sides'][policy]
    case = record['case']
    key = ('chart_' if axis=='Last' else '')+('original' if side==case['original_side'] else 'reverse')
    out = case[key]
    assert out['birth']['side']==side
    return out


# ----------------------------------------
def observation(c: dict,horizon: int) -> dict:
    """
    機能: 指定時間の固定観測を取り出す。
    引数: c(dict)、horizon(int)。返り値: dict。
    """
    rows = [o for o in c['outcomes'] if o['seconds']==horizon]
    assert len(rows)==1
    return rows[0]


# ----------------------------------------
def touch(o: dict,width: int) -> dict:
    """
    機能: 指定同幅の保存済み先着を取り出す。
    引数: o(dict)、width(int)。返り値: dict。
    """
    rows = [t for t in o['touches'] if t['width']==width]
    assert len(rows)==1 and rows[0]['direction'] in (-1,0,1)
    return rows[0]


# ----------------------------------------
def exit_value(c: dict,horizon: int,width: int,axis: str) -> dict:
    """
    機能: 既知touch優先のIFD清算代用を気配側・Fractionで独立計算する。
    引数: c(dict)、horizon/width(int)、axis(str)。返り値: dict。
    """
    o = observation(c,horizon)
    t = touch(o,width)
    q = t['quote'] if t['direction']!=0 else o['endpoint'] if o['status']=='complete' else None
    if q is None:
        assert t['direction']==0
        return {'known':False,'reason':'観測不足','points':None,'net0':None,'net5':None}
    side = c['birth']['side']
    mark = q['last'] if axis=='Last' else q['bid'] if side>0 else q['ask']
    points = side*(mark-c['entry_price'])
    if t['direction']!=0:
        assert t['direction']*points>=width
        assert q['index']>c['entry']['index'] and q['source_line']>c['entry']['source_line']
        assert c['entry']['time']<=q['time']<=o['deadline']
    return {'known':True,'reason':'順行到達' if t['direction']==1 else '逆行到達' if t['direction']==-1 else '期限清算',
            'points':points,'net0':points*100-77 if axis=='BBO' else None,
            'net5':points*100-1077 if axis=='BBO' else None}


# ----------------------------------------
def statistic(records: list[dict],policy: str,axis: str,horizon: int,width: int) -> dict:
    """
    機能: 全H完了先着と既知IFD代用金額を別分母で独立集計する。
    引数: records(list[dict])、policy/axis(str)、horizon/width(int)。返り値: dict。
    """
    selected = [candidate(r,policy,axis) for r in records]
    outcomes = [observation(c,horizon) for c in selected]
    complete = [o for o in outcomes if o['status']=='complete']
    labels = Counter(touch(o,width)['direction'] for o in complete)
    forward,adverse,neither = labels[1],labels[-1],labels[0]
    exits = [exit_value(c,horizon,width,axis) for c in selected]
    known = [e for e in exits if e['known']]
    money = [e['net5'] for e in known] if axis=='BBO' else []
    profit = sum((x for x in money if x>0),Fraction(0))
    loss = -sum((x for x in money if x<0),Fraction(0))
    rate = Fraction(forward,forward+adverse) if forward+adverse else None
    allrate = Fraction(forward,len(complete)) if complete else None
    return {'entries':len(records),'sessions':len({r['session'] for r in records}),
            'complete':len(complete),'censored':len(outcomes)-len(complete),
            'forward':forward,'adverse':adverse,'neither':neither,'resolved':forward+adverse,
            'resolved_rate':rate,'complete_rate':allrate,'target70':rate>=Fraction(7,10) if rate is not None else None,
            'target70_all':allrate>=Fraction(7,10) if allrate is not None else None,
            'ifd_known':len(known),'ifd_unknown':len(exits)-len(known),
            'ifd_exits':dict(Counter(e['reason'] for e in exits)),
            'ifd_net0_sum':sum((e['net0'] for e in known),Fraction(0)) if axis=='BBO' and known else None,
            'ifd_net5_sum':sum(money,Fraction(0)) if money else None,
            'ifd_net5_mean':sum(money,Fraction(0))/len(money) if money else None,
            'ifd_net5_profit':profit if money else None,'ifd_net5_loss':loss if money else None,
            'ifd_net5_pf':profit/loss if loss else None,
            'ifd_net5_positive':sum(x>0 for x in money) if axis=='BBO' else None,
            'ifd_points_mean':sum((e['points'] for e in known),Fraction(0))/len(known) if known else None,
            'flips':sum(r['sides'][policy]!=r['case']['original_side'] for r in records)}


# ----------------------------------------
def tables(records: list[dict],split: dict,stats: dict,actual: list[dict]) -> int:
    """
    機能: 240比較・79入口・73場の全セルと累計を独立に照合する。
    引数: records(list[dict])、split/stats(dict)、actual(list[dict])。返り値: intは照合セル数。
    """
    assert [t['name'] for t in actual]==['正逆比較','入口別診断','全セッション']
    assert [len(t['rows']) for t in actual]==[240,79,73]
    expected = []
    for part in ('train','validation','all'):
        for p in POLICIES:
            for axis in ('BBO','Last'):
                for h in HORIZONS:
                    for w in WIDTHS:
                        s = stats[part][p][axis][str(h)][str(w)]
                        expected.append([126,part,p,axis,h/60,w,s['sessions'],s['entries'],s['flips'],s['complete'],s['censored'],s['forward'],s['adverse'],s['neither'],s['resolved_rate'],s['complete_rate'],s['target70'],s['ifd_known'],s['ifd_unknown'],s['ifd_net0_sum'],s['ifd_net5_profit'],s['ifd_net5_loss'],s['ifd_net5_sum'],s['ifd_net5_mean'],s['ifd_net5_pf']])
    equal(actual[0]['rows'],expected,'240比較表')
    # ----------------------------------------
    for i,(r,row) in enumerate(zip(records,actual[1]['rows'])):
        f,case = r['feature'],r['case']
        part = 'train' if r['session'] in split['train_sessions'] else 'validation'
        clock = datetime.fromtimestamp(float(case['original']['entry']['time']),timezone(timedelta(hours=9))).isoformat(sep=' ')
        start = [126,part,r['session'],case['id'],f['strategy'],clock,case['original_side'],r['sides']['B0'],case['original']['entry_price'],case['reverse']['entry_price']]
        equal(row[:10],start,f'入口{i}/基本')
        for j,p in enumerate(POLICIES):
            c = candidate(r,p,'BBO')
            o = observation(c,3600)
            e = exit_value(c,3600,125,'BBO')
            block = row[10+j*7:17+j*7]
            equal(block[:2],[r['sides'][p],r['sides'][p]!=r['sides']['B0']],f'入口{i}/{p}/選択')
            path = json.loads(block[2],parse_float=Fraction)
            equal(path,r['paths'][p],f'入口{i}/{p}/経路')
            equal(block[3:],[o['status'],touch(o,125)['direction'],e['known'],e['net5']],f'入口{i}/{p}/金額')
    # ----------------------------------------
    expected = []
    cumulative,unknown = {p:Fraction(0) for p in POLICIES},{p:0 for p in POLICIES}
    for sid in split['sessions']:
        subset = [r for r in records if r['session']==sid]
        row = [126,'train' if sid in split['train_sessions'] else 'validation',sid,len(subset),bool(subset)]
        for p in POLICIES:
            s = statistic(subset,p,'BBO',3600,125)
            if s['ifd_net5_sum'] is not None:
                cumulative[p] += s['ifd_net5_sum']
            unknown[p] += s['ifd_unknown']
            row += [s['flips'],s['forward'],s['adverse'],s['neither'],s['censored'],s['ifd_known'],s['ifd_unknown'],s['ifd_net5_profit'],s['ifd_net5_loss'],s['ifd_net5_sum'],cumulative[p],unknown[p]]
        expected.append(row)
    equal(actual[2]['rows'],expected,'73場表')
    return sum(len(t['headers'])*len(t['rows']) for t in actual)


# ----------------------------------------
def serializable(value):
    """
    機能: 証跡だけをJSONで表せる数値へ変換する。検算は変換前に終える。
    引数: value(任意型)。返り値: JSON可能な値。
    """
    if isinstance(value,Fraction):
        return value.numerator if value.denominator==1 else float(value)
    if isinstance(value,dict):
        return {str(k):serializable(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):
        return [serializable(v) for v in value]
    return value


# ----------------------------------------
def main() -> None:
    """
    機能: 許可された126の固定JSONだけで主要数値と記録鎖を独立検算する。
    引数: なし。返り値: None。Raw・127入力・学習器・評価器は実行しない。
    """
    paths = [PAIR,FEATURE,BASE]+[SOURCE/n for n in ('F1.json','探索範囲.json','時系列分割.json','学習入力.json','評価入力.json','分割の確認.json','分割固定.json','学習モデル.json','学習完了.json','モデル固定.json','集計.json','CSV用の表.json','評価完了.json','段階実行完了.json')]
    before = {str(p.relative_to(ROOT)):sha(p) for p in paths}
    assert sha(PAIR)=='25517066b291a0434211190299b9f0195e67f9a7d2e89c801d5b9e6b4b51c3a1'
    assert sha(FEATURE)=='e4f0bf25156c1fe732b186c5c5d90b6e9f95718985a440d8eb7005588f734774'
    assert sha(BASE)=='16577b438f2de650c4398b313c2212fa124e812aea278e4dc00c529ffcb4c0a3'
    assert sha(SOURCE/'F1.json')=='b7a4bfc217baf2d4bfea3d0963376a66626a6f9a0d6563747d3f8a78d5d7cd8e'
    assert sha(SOURCE/'学習モデル.json')=='a011cb759ff5d3ab05efe7c7a97bd1686fd9bdc482dfba048e8120e56bdd7059'
    f1,model,split,plan = (read(SOURCE/n) for n in ('F1.json','学習モデル.json','時系列分割.json','探索範囲.json'))
    mf,sf,done = (read(SOURCE/n) for n in ('モデル固定.json','分割固定.json','段階実行完了.json'))
    assert mf['評価前固定'] and mf['F1_SHA256']==sha(SOURCE/'F1.json')
    assert mf['分割固定SHA256']==sha(SOURCE/'分割固定.json') and mf['モデルSHA256']==sha(SOURCE/'学習モデル.json')
    assert done['モデル固定SHA256']==sha(SOURCE/'モデル固定.json') and done['コード入力文書モデル前後同体']
    assert done['集計SHA256']==sha(SOURCE/'集計.json') and done['表SHA256']==sha(SOURCE/'CSV用の表.json')
    for group in ('コード','入力'):
        for path,expected in f1[group].items():
            assert sha(Path(path))==expected
    for path,expected in sf['固定入力'].items():
        assert sha(Path(path))==expected
    assert len(plan['atoms'])==45 and len({a['role'] for a in plan['atoms']})==4
    assert all('body' not in a['feature'] and 'candle' not in a['feature'] for a in plan['atoms'])
    # ----------------------------------------
    pairs,features,base = read(PAIR),read(FEATURE),read(BASE)
    fmap = {(f['session'],f['id']):f for f in features['features']}
    bmap = {(f['session'],f['id']):f for f in base['choices']}
    cmap = {(s['session'],c['id']):c for s in pairs['scenes'] for c in s['cases']}
    assert len(fmap)==len(bmap)==len(cmap)==79
    assert [s['session'] for s in pairs['scenes']]==split['sessions']
    assert len(split['train_sessions'])==48 and len(split['validation_sessions'])==25
    assert split['sessions']==split['train_sessions']+split['validation_sessions']
    records = []
    for kind,name,count in (('train','学習入力.json',53),('validation','評価入力.json',26)):
        package = read(SOURCE/name)
        assert package['kind']==kind and len(package['records'])==count
        allowed = split['train_sessions' if kind=='train' else 'validation_sessions']
        assert package['sessions']==allowed
        for record in package['records']:
            key = record['session'],record['case']['id']
            assert record['session'] in allowed
            equal(record['case'],cmap[key],f'{key}/原ペア')
            equal(record['feature'],fmap[key],f'{key}/元特徴')
            equal(record['base_choice'],bmap[key]['choices']['T1'],f'{key}/B0票')
            f = record['feature']
            sides = {'O0':f['original_side'],'B0':base_direction(f)}
            assert sides['B0']==record['base_choice']['side']
            paths = {'O0':[],'B0':[]}
            for p in ('T8','T6'):
                sides[p],paths[p] = walk(model['models'][p]['tree'],f)
            records.append({**record,'sides':sides,'paths':paths})
    assert len({(r['session'],r['case']['id']) for r in records})==79
    parts = {'train':records[:53],'validation':records[53:],'all':records}
    # ----------------------------------------
    training_summary = {}
    for p,minimum in (('T8',8),('T6',6)):
        m = model['models'][p]
        tree = m['tree']
        assert m['minimum_complete_leaf']==minimum and m['training_rows']==53 and m['evaluated_roots']==45
        assert m['id']=='A11|1:-|0:A35:0'
        assert tree['root']['id']=='A11' and tree['root']['feature']=='ema21_delta_signed_30' and tree['root']['threshold']==0
        assert tree['left'] is None and tree['right']['atom']['id']=='A35'
        assert tree['right']['atom']['feature']=='hist_atr_signed_5' and tree['right']['atom']['threshold']==Fraction(1,10)
        assert tree['right']['flip_branch'] is False and tree['root']['role']!=tree['right']['atom']['role']
        gain,money,flips,complete = 0,Fraction(0),0,0
        leaf_counts = Counter()
        for r in parts['train']:
            b,c = candidate(r,'B0','BBO'),candidate(r,p,'BBO')
            bo,co = observation(b,3600),observation(c,3600)
            changed = r['sides'][p]!=r['sides']['B0']
            flips += changed
            if bo['status']=='complete':
                complete += 1
                gain += touch(co,125)['direction']-touch(bo,125)['direction']
                if len(r['paths'][p])==2 and r['paths'][p][-1]['branch'] is not None:
                    leaf_counts[r['paths'][p][-1]['branch']] += 1
                if changed:
                    be,ce = exit_value(b,3600,125,'BBO'),exit_value(c,3600,125,'BBO')
                    if be['known'] and ce['known']:
                        money += ce['net5']-be['net5']
        assert min(leaf_counts.values())>=minimum and len(leaf_counts)==2
        assert gain==m['gain']==10 and money==Fraction(m['money_gain'])==130000
        assert m['complexity']==3 and m['score']==gain-3==7
        assert flips==m['training_flips']==9 and complete==m['training_complete']==49
        training_summary[p] = {'gain':gain,'C5改善額':money,'複雑さ':3,'罰則後':gain-3,'全H完了末端数':dict(leaf_counts),'学習B0反転':flips}
    assert all(r['sides']['T8']==r['sides']['T6'] for r in records)
    # ----------------------------------------
    calculated = {part:{p:{axis:{str(h):{str(w):statistic(rows,p,axis,h,w) for w in WIDTHS} for h in HORIZONS} for axis in ('BBO','Last')} for p in POLICIES} for part,rows in parts.items()}
    actual = read(SOURCE/'集計.json')
    equal(actual['集計'],calculated,'集計240条件')
    assert actual['主政策']=='T8' and actual['主評価区分']=='validation'
    assert actual['全場数']==73 and actual['固定取得数']==79 and actual['モデルSHA256']==sha(SOURCE/'学習モデル.json')
    table = read(SOURCE/'CSV用の表.json')
    cells = tables(records,split,calculated,table['tables'])
    for part,rows in parts.items():
        for p in POLICIES:
            b = actual['bootstrap'][part]['政策'][p]
            known = [exit_value(candidate(r,p,'BBO'),3600,125,'BBO')['known'] for r in rows]
            paired = sum(known[i] and exit_value(candidate(r,'O0','BBO'),3600,125,'BBO')['known'] for i,r in enumerate(rows))
            assert b['既知IFD数']==sum(known) and b['両側既知ペア数']==paired
            if p!='O0':
                bb = actual['B0対照bootstrap'][part]['政策'][p]
                paired = sum(known[i] and exit_value(candidate(r,'B0','BBO'),3600,125,'BBO')['known'] for i,r in enumerate(rows))
                assert bb['既知IFD数']==sum(known) and bb['両側既知ペア数']==paired
    assert all(sha(ROOT/path)==expected for path,expected in before.items())
    primary = {part:{p:calculated[part][p]['BBO']['3600']['125'] for p in POLICIES} for part in parts}
    assert primary['validation']['T8']['resolved_rate']==Fraction(3,5) and not primary['validation']['T8']['target70']
    assert primary['all']['T8']['resolved_rate']==Fraction(13,19) and not primary['all']['T8']['target70']
    result = {'成功':True,'試行':126,'独立Fraction検算':True,'元学習評価コードimportなし':True,'再学習と再探索なし':True,
              '金融Rawと127入力未読':True,'bootstrap再実装なし':True,'bootstrap既知分母確認':True,
              '検算条件数':240,'表行数':[240,79,73],'表セル数':cells,'全件':79,'全場':73,
              '学習':{'場':48,'件':53},'評価':{'場':25,'件':26},'モデル係数検算':training_summary,
              '主±125H60':primary,'評価前モデル固定鎖一致':True,'指紋前後不変':before,
              '検算コードSHA256':sha(Path(__file__))}
    path = OWN/'確認.json'
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(serializable(result),ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    print(json.dumps(serializable({'成功':True,'確認SHA256':sha(path),'表セル数':cells,'主±125H60':primary}),ensure_ascii=False))


if __name__=='__main__':
    main()
