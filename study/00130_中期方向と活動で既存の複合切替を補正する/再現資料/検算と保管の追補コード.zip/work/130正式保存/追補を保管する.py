"""130の結果後独立検算とCSV証跡を研究F1源と分けて保管する。"""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT=Path(__file__).resolve().parents[2]
F=ROOT/'study/00130_中期方向と活動で既存の複合切替を補正する'


def sha(body: bytes) -> str:
    """
    機能: bytesのSHAを返す。
    引数: body(bytes)。返り値: str。
    """
    return hashlib.sha256(body).hexdigest()


def main() -> None:
    """
    機能: 独立停止proof/標準CSV再読と後発codeを恒久保存する。
    引数: なし。返り値: None。
    """
    source=ROOT/'work/130独立検算'
    assert sha((source/'独立検算.json').read_bytes())=='16839435df69e2c1727df495050cd778294c0c4344745adf9e8bc1d4f3cfbcbc'
    for p,name in [(source/'独立検算.json','独立検算.json'),(source/'完了.json','独立検算完了.json'),(ROOT/'work/130既存入口CSV出力/独立再読.json','CSV独立再読.json'),(ROOT/'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/130既存入口CSV/CSVの確認.json','CSVの確認.json')]:
        target=F/'検査'/name;assert not target.exists();shutil.copyfile(p,target);assert sha(p.read_bytes())==sha(target.read_bytes())
    text=(source/'README.md').read_text(encoding='utf-8').replace('[独立コード](検算する.py)','[独立コード（追補ZIP）](../再現資料/検算と保管の追補コード.zip)')
    (F/'検査/独立数値検算.md').write_text(text,encoding='utf-8')
    files=[source/'検算する.py',ROOT/'work/130正式保存/結果を記す.py',Path(__file__).resolve(),F/'再現資料/保存資料を復元する.py']
    path=F/'再現資料/検算と保管の追補コード.zip'
    with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
        for p in files:z.writestr(p.relative_to(ROOT).as_posix(),p.read_bytes())
    items=[{'path':p.relative_to(ROOT).as_posix(),'phase':'結果後の独立検算/保存補助。金融前F1源ではない。','bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}for p in files]
    with zipfile.ZipFile(path)as z:
        assert z.testzip() is None
        for x in items:assert sha(z.read(x['path']))==x['sha256']
    (F/'再現資料/追補コード索引.json').write_text(json.dumps({'ZIP':path.name,'ZIP_SHA256':sha(path.read_bytes()),'ZIP_bytes':path.stat().st_size,'格納源数':len(items),'格納源':items},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'追補ZIP_SHA':sha(path.read_bytes()),'源数':len(items),'独立検算値':31437,'CSV再読セル':16258},ensure_ascii=False))


if __name__=='__main__':
    main()
