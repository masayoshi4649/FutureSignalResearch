"""130のF1全MD原文を結果記述前に恒久圧縮保管する。"""
from pathlib import Path
import gzip
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
FORMAL=ROOT/'study/00130_中期方向と活動で既存の複合切替を補正する'


def sha(body: bytes) -> str:
    """
    機能: 保存bytesのSHAを返す。
    引数: body(bytes)。返り値: str。
    """
    return hashlib.sha256(body).hexdigest()


def main() -> None:
    """
    機能: F1全MDの原文/指紋を一つのgzipへ保存して復元を確認する。
    引数: なし。返り値: None。
    """
    f1=ROOT/'work/130既存入口の活動切替評価/F1.json'
    body=f1.read_bytes();assert sha(body)=='6d09694cb22abbbbe5de62f0aa66afa927ad01e99faf02f75dcbba0df5229f03'
    fixed=json.loads(body);docs=[]
    for name,expected in fixed['ファイル'].items():
        p=Path(name)
        if p.suffix.lower()!='.md':continue
        b=p.read_bytes();assert sha(b)==expected,name
        docs.append({'path':p.relative_to(ROOT).as_posix(),'bytes':len(b),'sha256':expected,'本文':b.decode('utf-8')})
    value={'試行':130,'F1SHA':sha(body),'文書':docs}
    decoded=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode();packed=gzip.compress(decoded,mtime=0)
    folder=FORMAL/'検査';folder.mkdir(exist_ok=True)
    with (folder/'実行前文書.json.gz').open('xb') as stream:stream.write(packed)
    for d in json.loads(gzip.decompress(packed))['文書']:assert sha(d['本文'].encode())==d['sha256']
    (folder/'金融前F1.json').write_bytes(body)
    result={'成功':True,'F1SHA':sha(body),'MD原文数':len(docs),'gzipSHA':sha(packed),'解凍SHA':sha(decoded),'全原文SHA一致':True,'全復元SHA一致':True,'金融再計算':False,'原板読取':False}
    (folder/'実行前文書の確認.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':
    main()
