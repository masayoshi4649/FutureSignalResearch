"""許可された当時特徴と固定方向だけから活動切替の小型票を準備する。"""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import hashlib
import importlib.util
import json
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[2]
OWN=Path(__file__).resolve().parent
SOURCES={
    'work/124当時特徴の診断/全79例の当時特徴.json':'e4f0bf25156c1fe732b186c5c5d90b6e9f95718985a440d8eb7005588f734774',
    'work/125足の実体と反転切替/choices.json':'16577b438f2de650c4398b313c2212fa124e812aea278e4dc00c529ffcb4c0a3',
    'work/126複合切替の探索/学習モデル.json':'a011cb759ff5d3ab05efe7c7a97bd1686fd9bdc482dfba048e8120e56bdd7059',
    'work/126複合切替の探索/CSV用の表.json':'f48f2fa944960d27331f6a80f9f2ea274c1473b3991d7402074292b47620bd57'}


def sha(path: Path) -> str:
    """
    機能: 許可されたファイルの指紋を求める。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def read_fixed(name: str) -> dict:
    """
    機能: 固定4正本だけを指紋照合後に解釈する。
    引数: name(str)はSOURCESの登録相対path。返り値: dict。
    """
    assert name in SOURCES
    path=ROOT/name
    assert sha(path)==SOURCES[name]
    return json.loads(path.read_text('utf-8'))


# ----------------------------------------
def save(path: Path, value: dict) -> None:
    """
    機能: UTF-8の新規JSONを保存する。
    引数: path(Path)、value(dict)。返り値: None。既存を上書きしない。
    """
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')


# ----------------------------------------
def stamp(quote: dict) -> dict:
    """
    機能: 当時の時計/採用Index/物理行だけを小型票へ写す。
    引数: quote(dict)。返り値: dict。取得価格や後続観測は複製しない。
    """
    return {key:quote[key] for key in ('time','index','source_line')}


# ----------------------------------------
def verify_tree(model: dict) -> None:
    """
    機能: モデルを再選択せず、固定T8の二条件の木であることを確認する。
    引数: model(dict)は126固定モデル。返り値: None。
    """
    t=model['models']['T8'];tree=t['tree']
    assert t['id']=='A11|1:-|0:A35:0' and t['minimum_complete_leaf']==8
    assert tree['left'] is None and tree['right']['flip_branch'] is False
    root=tree['root'];child=tree['right']['atom']
    assert (root['id'],root['feature'],root['threshold'],root['signed_to_B0'])==('A11','ema21_delta_signed_30',0,True)
    assert (child['id'],child['feature'],child['threshold'],child['signed_to_B0'])==('A35','hist_atr_signed_5',.1,True)
    assert root['operator']==child['operator']=='既知値<境界'


# ----------------------------------------
def main() -> None:
    """
    機能: 人工検査後、79票のB0/T8・時計を再現してV1/V2方向だけを準備する。
    引数: なし。返り値: None。Source124正逆outcomes/Raw/後続足/新損益は開かない。
    """
    assert not any((OWN/name).exists() for name in ('choices.json','準備の確認.json','人工検査.json'))
    code_paths=[OWN/name for name in ('方向を選ぶ.py','準備する.py','人工検査.py','条件.md')]
    code_before={p.name:sha(p) for p in code_paths}
    test=subprocess.run([sys.executable,'-X','utf8',str(OWN/'人工検査.py')],cwd=OWN,
                        text=True,encoding='utf-8',capture_output=True)
    assert test.returncode==0,(test.stdout,test.stderr)
    save(OWN/'人工検査.json',{'成功':True,'主人工検査数':8,'command':[sys.executable,'-X','utf8','人工検査.py'],
         'exit_code':test.returncode,'stdout':test.stdout,'stderr':test.stderr,'市場入力読取':False})
    spec=importlib.util.spec_from_file_location('活動切替の純方向',OWN/'方向を選ぶ.py')
    select=importlib.util.module_from_spec(spec);spec.loader.exec_module(select)
    feature_source=read_fixed('work/124当時特徴の診断/全79例の当時特徴.json')
    assert feature_source['success'] and feature_source['source_outcomes_used'] is False
    assert feature_source['new_direction_results_read'] is False
    original=feature_source['features']
    base=read_fixed('work/125足の実体と反転切替/choices.json')
    bmap={(r['session'],r['id']):r for r in base['choices']}
    verify_tree(read_fixed('work/126複合切替の探索/学習モデル.json'))
    old=read_fixed('work/126複合切替の探索/CSV用の表.json')
    table=next(t for t in old['tables'] if t['name']=='入口別診断');headers=table['headers']
    assert headers.count('T8向き')==1 and headers.count('B0向き')==2
    oldmap={(row[headers.index('セッション')],row[headers.index('出生ID')]):row for row in table['rows']}
    assert len(original)==len(bmap)==len(oldmap)==79
    assert {(r['session'],r['id']) for r in original}==set(bmap)==set(oldmap)
    sessions=list(dict.fromkeys(r['session'] for r in original))
    assert sessions==sorted(sessions) and len(sessions)==73
    first=set(sessions[:48]);rows=[]
    for row in original:
        identity=(row['session'],row['id']);o=row['original_side']
        d=select.choose(o,row['features']);oldrow=oldmap[identity]
        assert d['b0_side']==bmap[identity]['choices']['T1']['side']
        assert all(oldrow[i]==d['b0_side'] for i,h in enumerate(headers) if h=='B0向き')
        assert oldrow[headers.index('T8向き')]==d['t8_side']
        birth,entry=stamp(row['birth_quote']),stamp(row['entry_quote'])
        assert all(birth[k]<=entry[k] for k in birth)
        clock=datetime.fromtimestamp(entry['time'],timezone(timedelta(hours=9))).isoformat(sep=' ')
        assert oldrow[headers.index('取得JST')]==clock
        assert bmap[identity]['entry']==entry
        part='train' if row['session'] in first else 'validation'
        assert oldrow[headers.index('区分')]==part
        references=[]
        for ref in row['refs']:
            assert all(ref['delivered'][k]<=birth[k] for k in birth)
            assert ref['end']<=ref['delivered']['time']
            references.append({key:ref[key] for key in ('id','width_seconds','end','delivered','publication_sha256')})
        widths={r['width_seconds'] for r in references}
        assert 300 in widths
        if d['known']['ema21_delta_signed_30']:assert 1800 in widths
        if d['known']['gap_signed_15'] or d['known']['ema21_delta_signed_15']:assert 900 in widths
        rows.append({'session':row['session'],'id':row['id'],'partition_reference':part,
            'original_side':o,'strategy':row['strategy'],'path':row['path'],'birth':birth,'entry':entry,
            'refs':references,'rvol_source':row['rvol_source'],**d})
    source_after={name:sha(ROOT/name) for name in SOURCES}
    assert source_after==SOURCES and code_before=={p.name:sha(p) for p in code_paths}
    counts={p:sum(r['choices'][p]['restored_to_B0'] for r in rows) for p in ('V1','V2')}
    assert counts['V2']<=counts['V1']
    value={'proposal':'T8の活動による切替案','正式番号':None,'成功':True,'primary':'V2',
           'policies':list(select.POLICIES),'entry_count':79,'session_count':73,'sessions':sessions,
           'fixed_sources':SOURCES,'spec_sha256':code_before['条件.md'],'choices':rows,
           'natural_entry_reconstructed':False,'source_outcomes_read':False,
           'new_pnl_or_rates_computed':False,'all_periods_previously_observed':True}
    save(OWN/'choices.json',value)
    save(OWN/'準備の確認.json',{'成功':True,'正式番号':None,'主':'V2','副':'V1',
        '固定取得':79,'固定場':73,'前48場の票':sum(r['partition_reference']=='train' for r in rows),
        '後25場の票':sum(r['partition_reference']=='validation' for r in rows),
        '125B0の79方向同体':True,'126B0とT8の79方向同体':True,'固定79取得時計同体':True,
        '既知参照時計の因果確認':True,'復帰票数_成績ではない':counts,
        '人工8主成功':True,'choices_sha256':sha(OWN/'choices.json'),'choices_bytes':(OWN/'choices.json').stat().st_size,
        'コード仕様の前後SHA256':code_before,'入力正本の前後SHA256':source_after,
        'Source124outcomes読取':False,'原板読取':False,'新損益勝率計算':False,
        '金融評価':'Rootの金融前固定後に実施。それまでは未実行。'})
    print(json.dumps({'成功':True,'choices_SHA256':sha(OWN/'choices.json'),
        '準備proof_SHA256':sha(OWN/'準備の確認.json'),'復帰票数_成績ではない':counts,
        'choices_bytes':(OWN/'choices.json').stat().st_size},ensure_ascii=False))


if __name__=='__main__':
    main()
