"""新しい損益・原板を読まず、切替の境界/未知/符号鏡像を人工検査する。"""
from pathlib import Path
import importlib.util
import math
import unittest

SPEC=importlib.util.spec_from_file_location('活動の純方向',Path(__file__).with_name('方向を選ぶ.py'))
SELECT=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(SELECT)


def fields(body: float | None=0, long: float | None=1, hist: float | None=.1,
           gap: float | None=1, slope: float | None=1, volume: float | None=2) -> dict:
    """
    機能: 人工の元向き符号特徴を作る。
    引数: body/long/hist/gap/slope/volume(float|None)。返り値: dict。
    """
    return {key:{'known':value is not None,'value':value} for key,value in zip(SELECT.USED_KEYS,
            (body,long,hist,gap,slope,volume))}


# ----------------------------------------
class Artificial(unittest.TestCase):
    """市場の成績を使わず、手書き条件と固定対照の論理を検査する。"""

    def test_B0の実体境界(self) -> None:
        """
        機能: 実体比の下端/上端/未知の既存B0を確認する。
        引数: self(Artificial)。返り値: None。
        """
        for body,side in ((None,1),(.49999,1),(.5,-1),(.74999,-1),(.75,1)):
            self.assertEqual(SELECT.choose(1,fields(body=body))['b0_side'],side)

    def test_T8の等号と未知(self) -> None:
        """
        機能: MA30の0以上/MACD比.1以上と未知fallbackを確認する。
        引数: self(Artificial)。返り値: None。
        """
        for long,hist,side in ((0,.1,-1),(-.0001,.1,1),(1,.09999,1),(None,1,1),(1,None,1)):
            self.assertEqual(SELECT.choose(1,fields(long=long,hist=hist))['t8_side'],side)

    def test_活動の下端(self) -> None:
        """
        機能: V1>=1/V2>=2の等号と部分集合を確認する。
        引数: self(Artificial)。返り値: None。
        """
        for volume,v1,v2 in ((None,-1,-1),(.99999,-1,-1),(1,1,-1),(1.99999,1,-1),(2,1,1),(4,1,1)):
            c=SELECT.choose(1,fields(volume=volume))['choices']
            self.assertEqual((c['V1']['side'],c['V2']['side']),(v1,v2))

    def test_15分は厳密正(self) -> None:
        """
        機能: 15分の0/逆/未知を支持に変えないことを確認する。
        引数: self(Artificial)。返り値: None。
        """
        for gap,slope in ((0,1),(1,0),(-1,1),(1,-1),(None,1),(1,None)):
            c=SELECT.choose(1,fields(gap=gap,slope=slope))['choices']
            self.assertEqual(c['V1']['side'],-1)
            self.assertEqual(c['V2']['side'],-1)

    def test_T8非反転には介入しない(self) -> None:
        """
        機能: 活動が高くてもT8非反転局面から新方向を作らない。
        引数: self(Artificial)。返り値: None。
        """
        for long,hist in ((-1,1),(None,1),(1,None)):
            c=SELECT.choose(1,fields(long=long,hist=hist,volume=20))['choices']
            self.assertEqual(c['T8']['side'],1)
            self.assertEqual(c['V2']['side'],1)
            self.assertFalse(c['V2']['restored_to_B0'])

    def test_B0基準への符号変換(self) -> None:
        """
        機能: B0が元方向と逆の時に15/30分とHistを同じ基準へ変換する。
        引数: self(Artificial)。返り値: None。
        """
        d=SELECT.choose(1,fields(body=.6,long=-1,hist=-.2,gap=-1,slope=-1))
        self.assertEqual(d['b0_side'],-1)
        self.assertEqual(d['t8_side'],1)
        self.assertEqual(d['choices']['V2']['side'],-1)

    def test_売買鏡像と部分集合(self) -> None:
        """
        機能: 元向き符号特徴を保つ価格鏡像で全方向が反転することを確認する。
        引数: self(Artificial)。返り値: None。
        """
        for body in (None,0,.5,.75):
            for sign in (-1,1):
                for vol in (None,0,1,2):
                    f=fields(body=body,long=sign,hist=sign*.2,gap=sign,slope=sign,volume=vol)
                    buy,sell=SELECT.choose(1,f),SELECT.choose(-1,f)
                    for policy in SELECT.POLICIES:
                        self.assertEqual(sell['choices'][policy]['side'],-buy['choices'][policy]['side'])
                        self.assertEqual(sell['choices'][policy]['restored_to_B0'],buy['choices'][policy]['restored_to_B0'])
                    self.assertFalse(buy['choices']['V2']['restored_to_B0'] and not buy['choices']['V1']['restored_to_B0'])

    def test_不正既知値は拒否(self) -> None:
        """
        機能: 非有限/既知null/未知0を黙って支持へ変えないことを確認する。
        引数: self(Artificial)。返り値: None。
        """
        for item in ({'known':True,'value':math.nan},{'known':True,'value':None},{'known':False,'value':0}):
            f=fields();f['rvol5']=item
            with self.assertRaises(AssertionError):
                SELECT.choose(1,f)


if __name__=='__main__':
    unittest.main(verbosity=2)
