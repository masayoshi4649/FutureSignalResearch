"""固定T8へ、15分方向と活動の既知なAND条件だけを加える純粋関数。"""
import math

POLICIES=('O0','B0','T8','V1','V2')
USED_KEYS=('candle5_body_signed_ratio','ema21_delta_signed_30','hist_atr_signed_5',
           'gap_signed_15','ema21_delta_signed_15','rvol5')


def number(fields: dict, key: str) -> float | None:
    """
    機能: 未知を0にせず、有限の既知値だけを取り出す。
    引数: fields(dict)、key(str)。返り値: float|None。
    """
    item=fields.get(key,{'known':False,'value':None})
    assert type(item['known']) is bool
    if not item['known']:
        assert item.get('value') is None
        return None
    value=item['value']
    assert type(value) in (int,float) and math.isfinite(value)
    return value


# ----------------------------------------
def choose(original_side: int, fields: dict) -> dict:
    """
    機能: 元向き符号特徴からB0/T8を再現し、V1/V2のB0復帰を決める。
    引数: original_side(int)は±1、fields(dict)は当時のknown/value特徴。
    返り値: dictは5政策方向、既知mask、B0向き成分と理由。
    """
    assert type(original_side) is int and original_side in (-1,1)
    values={key:number(fields,key) for key in USED_KEYS}
    body=values['candle5_body_signed_ratio']
    base_flip=body is not None and .5<=body<.75
    b0=-original_side if base_flip else original_side
    factor=b0*original_side
    signed={key:(None if values[key] is None else factor*values[key])
            for key in ('ema21_delta_signed_30','hist_atr_signed_5','gap_signed_15','ema21_delta_signed_15')}
    long=signed['ema21_delta_signed_30'];hist=signed['hist_atr_signed_5']
    t8_flip=long is not None and hist is not None and long>=0 and hist>=.1
    t8=-b0 if t8_flip else b0
    gap=signed['gap_signed_15'];slope=signed['ema21_delta_signed_15'];volume=values['rvol5']
    ma15=gap is not None and slope is not None and gap>0 and slope>0
    restored={p:bool(t8_flip and ma15 and volume is not None and volume>=threshold)
              for p,threshold in (('V1',1),('V2',2))}
    sides={'O0':original_side,'B0':b0,'T8':t8,
           'V1':b0 if restored['V1'] else t8,'V2':b0 if restored['V2'] else t8}
    choices={}
    for policy in POLICIES:
        if policy=='O0':
            reason='元方向の固定対照'
        elif policy=='B0':
            reason='125実体比[0.5,0.75)の固定B0'
        elif policy=='T8':
            reason='126の固定MA30/MACD5のT8、未知はB0'
        elif restored[policy]:
            reason='T8反転局面で15分両条件と既知活動を満たしB0へ復帰'
        else:
            reason='復帰条件の不成立又は未知により固定T8を維持'
        choices[policy]={'side':sides[policy],'action':'flip' if sides[policy]!=original_side else 'keep',
                         'restored_to_B0':restored.get(policy,False),'reason':reason}
    assert not restored['V2'] or restored['V1']
    return {'choices':choices,'b0_side':b0,'t8_side':t8,'base_body_flip':base_flip,
            't8_flipped_B0':t8_flip,'ma15_supports_B0':ma15,
            'known':{key:value is not None for key,value in values.items()},
            'values_to_B0':{'candle5_body_signed_ratio':body,**signed,'rvol5':volume}}
