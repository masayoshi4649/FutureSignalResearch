"""130の事前仮説/方向票/正逆入力を固定してから既存Sourceを再評価する。"""
from pathlib import Path
from datetime import datetime,timezone
import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys

ROOT=Path(__file__).resolve().parent.parent
OWN=ROOT/'work/130既存入口の活動切替評価'
PLAN=ROOT/'work/T8の活動による切替案'
FORMAL=ROOT/'study/00130_中期方向と活動で既存の複合切替を補正する'


def sha(path: Path) -> str:
    """
    機能: ファイル全体のSHA256を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def save(path: Path,data: dict) -> None:
    """
    機能: 未作成先へUTF-8記録を保存する。
    引数: path(Path)、data(dict)。返り値: None。
    """
    with path.open('x',encoding='utf-8',newline='\n') as stream: stream.write(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n')


# ----------------------------------------
def verify(data: dict) -> None:
    """
    機能: 金融前に固定した全ファイルを照合する。
    引数: data(dict)。返り値: None。
    """
    for path,value in data['ファイル'].items(): assert sha(Path(path))==value,path


# ----------------------------------------
def main() -> None:
    """
    機能: 主V2/副V1を固定した後だけ正逆ペアの金融計算を呼ぶ。
    引数: CLI --mode(str、固定/評価)。返り値: None。
    """
    parser=argparse.ArgumentParser(description='130固定Sourceの方向比較')
    parser.add_argument('--mode',choices=('固定','評価'),required=True);args=parser.parse_args()
    f1=OWN/'F1.json'
    if args.mode=='固定':
        spec=importlib.util.spec_from_file_location('金融130の宣言',OWN/'評価する.py')
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        assert all(sha(path)==value for path,value in module.SOURCES.items())
        assert (OWN/'人工検査.py').is_file()
        files=set(module.SOURCES)|{module.METADATA,Path(__file__).resolve()}
        for folder in (PLAN,OWN,FORMAL):
            files.update(p for p in folder.rglob('*') if p.is_file() and p.suffix in ('.py','.md'))
        files.update(p for p in PLAN.glob('*.json'))
        value={'成功':True,'試行':130,'段階':'金融前F1','UTC':datetime.now(timezone.utc).isoformat(),
               '主':'V2・全73場79固定取得・実BBO/H60±125・到達済み70%以上',
               '副':'V1のみ。主を結果後に交換しない。全期間は既使用。',
               'ファイル':{str(p):sha(p) for p in sorted(files)}}
        save(f1,value);print(json.dumps({'F1':sha(f1),'ファイル数':len(files)},ensure_ascii=False));return
    fixed=json.loads(f1.read_bytes());verify(fixed)
    command=[sys.executable,'-X','utf8',str(OWN/'評価する.py'),'--f1',str(f1),'--f1-sha256',sha(f1),
             '--evaluate-fixed-choices','93c204569d7a9828708d3891d984551784961138534c3cbde80759b602b24a9e','--output-dir',str(OWN)]
    subprocess.run(command,cwd=ROOT,check=True);verify(fixed)
    data=json.loads((OWN/'集計.json').read_bytes())
    assert data['成功'] and data['試行']==130 and data['主政策']=='V2' and data['全場数']==73 and data['固定取得数']==79
    save(OWN/'Root評価完了.json',{'成功':True,'F1_SHA256':sha(f1),'集計SHA256':sha(OWN/'集計.json'),'全ファイル前後同体':True,'コマンド':command})


if __name__=='__main__':
    main()
