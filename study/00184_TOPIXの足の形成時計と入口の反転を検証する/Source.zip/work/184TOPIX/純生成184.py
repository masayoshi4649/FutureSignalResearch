"""184の直接形成・方向反転の条件を金融前に固定する。"""
from pathlib import Path
from collections import Counter
import json,gzip,sys
import 直接形成184 as D
M=D.BASE
HERE=Path(__file__).parent


def main():
    """
    機能: 81場の長い足を直接形成し、183と純q0の差を固定する。
    引数: なし。
    返り値: None。新金融は計算しない。
    """
    cfg183=M.read(M.HERE/'条件_実装修正1.json');assert M.sha(M.HERE/'入口とIFD.py')==cfg183['SourceSHA']
    manifest=M.read(M.HERE/'入力台帳.json');channels={s:M.Channel() for s in (5,15,30)};contract=None
    allrows=[];qualities=[]
    for e in manifest['entries']:
        if contract!=e['in_session_contract_codes']:
            channels={s:M.Channel() for s in (5,15,30)};contract=e['in_session_contract_codes']
        counter=Counter();before={str(s):ch.n for s,ch in channels.items()}
        rows,q=D.direct_features(e,channels,counter)
        for r in rows:
            plus=M.roles(r,1);minus=M.roles(r,-1)
            r['signals']=[1 if a and not b else -1 if b and not a else 0 for a,b in zip(plus,minus)]
        allrows+=rows
        qualities.append({'session':e['session'],**q,'形成':dict(counter),'場開始時既知足数':before,
          '場末既知足数':{str(s):ch.n for s,ch in channels.items()},'最初q0':rows[0]['time'] if rows else None})
        print(e['session'],len(rows),before,{s:ch.n for s,ch in channels.items()},flush=True)
    M.save(HERE/'純特徴_直接.json.gz',allrows);M.save(HERE/'入力品質_直接.json',qualities)
    cfg={'試行':184,'対象':'TOPIX','目的':'183の1分確認遅延から長い足の形成が遮断される問題と逆行過多方向を分解',
      '固定対照':'183の実装修正1、同一13入口×5/10/15pt H60、同費用/約定/単一保有。',
      '比較':{'C0':'183の足形成・元方向','C1':'183の足形成・実側反転','C2':'直接5/15/30形成・元方向','C3':'直接5/15/30形成・実側反転'},
      '新金融組数':117,'対照含む組数':156,
      '形成':'各5/15/30分を同じ原板の観測価格から直接形成。足初観測の開始遅延30秒以下・終端確認30秒以下・中間観測空白300秒以下。空の足を前値補完せず、未観測出来高0を作らない。判断は旧と同じ30秒以内に公表された完全1分。',
      '反転':'成立時の実注文sideを反転し、BBO取得価格とIFD・後続枠を再評価。1-pで代用しない。既使用の失敗を受けた事後仮説であり未知検証ではない。',
      '変更しない条件':cfg183,'Source':{str(p.relative_to(M.ROOT)):M.sha(p) for p in (HERE/'直接形成184.py',Path(__file__),M.HERE/'入口とIFD.py')},
      '直接純SHA':M.sha(HERE/'純特徴_直接.json.gz'),'旧純SHA':M.sha(M.HERE/'純特徴.json.gz')}
    assert not (HERE/'条件.json').exists();M.save(HERE/'条件.json',cfg)


if __name__=='__main__':main()
