"""184：1分の採否と長い足の形成を分離する。183の入口閾値は変えない。"""
from pathlib import Path
from collections import Counter,deque
import json,gzip,sys
import numpy as np
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work/183TOPIX'))
import 入口とIFD as BASE
from 入口とIFD import Channel,bounds,band

def direct_features(entry,channels,counts=None):
    """
    機能: 原順キャッシュから各時間幅を直接形成し、確定1分の公表点で特徴を構築する。
    引数: entry(dict)は入力参照、channels(dict[int,Channel])は同限月履歴、counts(Counter|None)は観測診断。
    返り値: tuple[list[dict],dict]は純q0と品質。未来OHLCは読まない。
    """
    session=entry['session'];start,end,force=bounds(session)
    cache=np.load(entry['cache_absolute'],allow_pickle=False)
    q=Counter();rows=[];current=None;previous_clock=-np.inf;parts={};direct={};minutes=deque(maxlen=20)
    previous_vol=None;previous_vt=None
    fields=('now','line','last','bid','ask','valid','volume','volume_time')
    for t,line,last,bid,ask,valid,vol,vt in zip(*(cache[k] for k in fields)):
        if not np.isfinite(t):q['時計欠測']+=1;continue
        if t<previous_clock:q['時計後退破棄']+=1;continue
        previous_clock=t
        if not start<=t<end:continue
        # ----------------------------------------
        # 長い足は1分足の採否に依存させず、当時までの原板価格から直接形成する。
        for size in (5,15,30):
            length=size*60;key=int((t-start)//length);old=direct.get(size)
            if old is not None and key>old['index']:
                accepted=(old['has_price'] and t-old['end']<=30 and old['first']-old['start']<=30 and old['gap']<=300)
                if counts is not None:
                    counts[f'{size}分観測足']+=1;counts[f'{size}分公開採用']+=int(accepted)
                if accepted:channels[size].update(old,float(t))
                direct.pop(size,None);old=None
            if old is None:
                old={'index':key,'start':start+key*length,'end':start+(key+1)*length,
                     'open':None,'high':-np.inf,'low':np.inf,'close':None,'has_price':False,
                     'first':float(t),'last_seen':float(t),'gap':0.}
                direct[size]=old
            old['gap']=max(old['gap'],float(t)-old['last_seen']);old['last_seen']=float(t)
            if np.isfinite(last) and last>0:
                if old['open'] is None:old['open']=float(last)
                old['high']=max(old['high'],float(last));old['low']=min(old['low'],float(last))
                old['close']=float(last);old['has_price']=True
        idx=int((t-start)//60)
        if current is not None and idx>current['index']:
            b=current;delay=t-b['end'];b['published']=float(t)
            complete=b['has_price'] and delay<=30
            q['1分公開数']+=1;q['30秒超確認遅延']+=delay>30
            if complete:
                contiguous=bool(minutes) and minutes[-1]['index']+1==b['index']
                if not contiguous:minutes.clear()
                c5=channels[5].last;c15=channels[15].last;c30=channels[30].last
                # ----------------------------------------
                # 公開された価格構造と過去だけの相対量。準備不足は0にしない。
                prior=list(minutes)[-3:];prior20=list(minutes)
                rv=None
                if len(prior20)==20 and b['volume_ok'] and all(x['volume_ok'] for x in prior20):
                    avg=sum(x['volume'] for x in prior20)/20
                    rv=b['volume']/avg if avg>0 else None
                fresh=lambda x,size:x is not None and t-x['published']<=size*60+30
                if c5 is not None and c5['count']>=21 and fresh(c5,5) and fresh(c15,15) and c15['count']>=8 and len(prior)==3 and valid and t<force:
                    atr=c5['atr'];r=b['high']-b['low']
                    if atr>0:
                        row={'session':session,'time':float(t),'line':int(line),'band':band(float(t),session),
                          'close':b['close'],'body':(b['close']-b['open'])/atr,'progress':(b['close']-prior[-1]['close'])/atr,
                          'position':(b['close']-b['low'])/r if r else .5,'high':b['high'],'low':b['low'],
                          'prior_high':max(x['high'] for x in prior),'prior_low':min(x['low'] for x in prior),
                          'prior_close':prior[-1]['close'],'atr':atr,'range':r/atr,'rvol':rv,
                          'live':(last-b['close'])/atr if np.isfinite(last) else None,'spread':float(ask-bid),
                          'm5':dict(c5),'m15':dict(c15),'m30':dict(c30) if fresh(c30,30) and c30['count']>=8 else None}
                        rows.append(row)
                minutes.append(b)
            else:
                minutes.clear();parts.clear()
            current=None
        if current is None:
            current={'index':idx,'start':start+idx*60,'end':start+(idx+1)*60,'open':None,'high':-np.inf,'low':np.inf,'close':None,
              'volume':0.,'volume_ok':previous_vol is not None,'has_price':False}
        if np.isfinite(last) and last>0:
            if current['open'] is None:current['open']=float(last)
            current['high']=max(current['high'],float(last));current['low']=min(current['low'],float(last));current['close']=float(last);current['has_price']=True
        if np.isfinite(vol) and np.isfinite(vt) and vol>=0 and vt<=t:
            if previous_vol is not None and vol>=previous_vol and vt>=previous_vt:current['volume']+=float(vol-previous_vol)
            else:current['volume_ok']=False
            previous_vol=float(vol);previous_vt=float(vt)
        elif not np.isfinite(vol) or not np.isfinite(vt):current['volume_ok']=False
    q['q0数']=len(rows);q['観測終端']=float(previous_clock) if np.isfinite(previous_clock) else None
    return rows,{key:(value.item() if isinstance(value,np.generic) else value) for key,value in q.items()}
