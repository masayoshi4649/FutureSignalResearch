"""足形成と実側反転を分離した四条件を、同じ単純IFDで比較する。"""
from pathlib import Path
from copy import deepcopy
import gzip,json,sys
import 直接形成184 as D
M=D.BASE;HERE=Path(__file__).parent
sys.path.insert(0,str(M.HERE))
import 金融を比較する as F
A=F.A


def main():
    """
    機能: 固定39対照と新117条件を同じ単一保有で再生する。
    引数: なし。
    返り値: None。全候補を保存し、事後に閾値を合わせない。
    """
    cfg=M.read(HERE/'条件.json')
    for p,digest in cfg['Source'].items():assert M.sha(M.ROOT/p)==digest,p
    assert cfg['直接純SHA']==M.sha(HERE/'純特徴_直接.json.gz')
    marker=HERE/'金融開始前固定.json';assert not marker.exists()
    M.save(marker,{'runner':M.sha(Path(__file__)),'共通集計Source':M.sha(M.ROOT/'work/183損失安定性/安定性183.py'),'条件':M.sha(HERE/'条件.json')})
    entries=M.read(M.HERE/'入力台帳.json')['entries'];meta=F.sessions(entries)
    assert meta==sorted(meta,key=lambda x:x['start'])
    pure={0:json.loads(gzip.decompress((M.HERE/'純特徴.json.gz').read_bytes())),1:json.loads(gzip.decompress((HERE/'純特徴_直接.json.gz').read_bytes()))}
    by={k:{s['scene']:[] for s in meta} for k in pure}
    for k,rows in pure.items():
        for r in rows:by[k][r['session']].append(r)
    packs={}
    for c in range(4):
        for i,name in enumerate(M.NAMES):
            for w in M.WIDTHS:
                ident=f'TOPIX184_C{c}_{name}_W{w:g}_H60'
                if c==0:
                    orig=M.HERE/'金融正本'/f'TOPIX183_{name}_W{w:g}_H60.json.gz'
                    p=json.loads(gzip.decompress(orig.read_bytes()));p['source_policy_id']=p['id'];p['id']=ident
                else:p=F.empty(ident,meta)
                packs[(c,i,w)]=p
    for e in entries:
        route=M.Route(e);cache={}
        for (c,ci,w),pack in packs.items():
            if c==0:continue
            busy=-float('inf');accepted=blocked=expired=signals=0
            for r in by[0 if c==1 else 1][e['session']]:
                side=r['signals'][ci]*(-1 if c in (1,3) else 1)
                if not side:continue
                signals+=1
                if r['time']<=busy:blocked+=1;continue
                key=(r['time'],r['line'],side,w)
                if key not in cache:cache[key]=route.cell(*key)
                cell=cache[key]
                if cell is None:expired+=1;continue
                accepted+=1;F.append(pack,cell);busy=route.end if cell['unknown'] else cell['exit_time']
            pack['diagnostics'].append({'scene':e['session'],'純成立':signals,'保有棄却':blocked,'取得':accepted,'失効':expired})
        print(e['session'],len(cache),flush=True)
    periods={'全80':[s['scene'] for s in meta[:-1]],'前48':[s['scene'] for s in meta[:48]],'後25':[s['scene'] for s in meta[48:73]],
      '追加7':[s['scene'] for s in meta[73:80]],'本日1':[meta[-1]['scene']]}
    stats={};short=[];orders={}
    for key,pack in packs.items():
        stats[key]=A.evaluate_pack(pack,periods);stat=stats[key]
        M.save(HERE/'金融正本'/(pack['id']+'.json.gz'),pack)
        short.append({'id':pack['id'],'case':key[0],'candidate':M.NAMES[key[1]],'width':key[2],
          '全81':{k:F.terse(v) for k,v in stat['groups'].items()},'期間':{p:{k:F.terse(v) for k,v in b.items()} for p,b in stat['periods'].items()}})
    for w in M.WIDTHS:
        for period in ('全80','前48'):
            for b in ('DAY','NIGHT'):
                base=stats[(0,0,w)]['periods'][period][b]
                keys=sorted((k for k in stats if k[2]==w),key=lambda k:(A.rank_key(stats[k]['periods'][period][b],base),packs[k]['id']))
                orders[f'W{w:g}_{period}_{b}']=[{'id':packs[k]['id'],'gate':A.gate(stats[k]['periods'][period][b],base)} for k in keys]
    M.save(HERE/'全156組短表.json',{'rows':short,'順位':orders})
    M.save(HERE/'全156組安定性.json.gz',{'metrics':list(stats.values()),'順位':orders})
    for name,order in orders.items():
        row=next(r for r in short if r['id']==order[0]['id'])
        print(name,json.dumps({'id':row['id'],'gate':order[0]['gate'],'全81':row['全81'][name.split('_')[-1]]},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
