"""直接足の先読みと数量の可視性を、金融成績とは別に確認する。"""
from pathlib import Path
from collections import Counter
import gzip,json,tempfile,sys
import numpy as np
import 直接形成184 as D
M=D.BASE
HERE=Path(__file__).parent


def artificial(path,seconds,prices):
    """
    機能: 正常板と同時刻の累積数量を持つ人工入力を作る。
    引数: path(Path),seconds(ndarray),prices(ndarray)。
    返り値: dictは一場の入力参照。
    """
    s,_,_=M.bounds('2026-09-21_Day');n=len(seconds)
    np.savez(path,now=s+seconds,line=np.arange(n)+1,last=prices,bid=prices-.25,ask=prices+.25,
             valid=np.ones(n,dtype=bool),volume=np.arange(n),volume_time=s+seconds)
    return {'session':'2026-09-21_Day','cache_absolute':str(path)}


def form(entry):
    """
    機能: 新規履歴から直接足を形成する。
    引数: entry(dict)。
    返り値: tupleは純特徴、形成数、チャネル。
    """
    ch={s:M.Channel() for s in (5,15,30)};c=Counter();rows,_=D.direct_features(entry,ch,c)
    return rows,c,ch


def main():
    """
    機能: 未来変更不変・直接足の欠測・全量窓の利用可能性を検査する。
    引数: なし。
    返り値: None。JSON診断を保存する。金融条件は変更しない。
    """
    results={};checks=0
    with tempfile.TemporaryDirectory() as tmp:
        p=Path(tmp);seconds=np.arange(0,400*60+1,5,dtype=float)
        prices=4000+np.sin(seconds/97)*2+seconds/10000
        a,c,ch=form(artificial(p/'a.npz',seconds,prices));assert a;checks+=1
        cutoff=240*60;future=prices.copy();future[seconds>=cutoff]+=500
        b,_,_=form(artificial(p/'b.npz',seconds,future));start=M.bounds('2026-09-21_Day')[0]
        left=[r for r in a if r['time']<start+cutoff];right=[r for r in b if r['time']<start+cutoff]
        assert left==right;checks+=len(left)
        for r in a:
            for key in ('m5','m15','m30'):
                if r[key] is not None:assert r[key]['published']<=r['time'];checks+=1
        mask=~((seconds>=60)&(seconds<100))
        late,lc,lch=form(artificial(p/'late.npz',seconds[mask],prices[mask]))
        assert lc['5分公開採用']==c['5分公開採用'];checks+=1
        oldch={s:M.Channel() for s in (5,15,30)};M.bars_and_features({'session':'2026-09-21_Day','cache_absolute':str(p/'late.npz')},oldch)
        assert oldch[5].n<lch[5].n;checks+=1
        gap=~((seconds>=5*60+5)&(seconds<11*60))
        _,gc,_=form(artificial(p/'gap.npz',seconds[gap],prices[gap]))
        assert gc['5分公開採用']<c['5分公開採用'];checks+=1
        results['人工']={'成功':True,'照合数':checks,'未来不変q0':len(left),'通常5分採用':c['5分公開採用'],
           '1分遅延時の直接5分採用':lc['5分公開採用'],'同旧合成5分採用':oldch[5].n,'大空白時5分採用':gc['5分公開採用']}
    # ----------------------------------------
    # 有限の相対量を使う全窓に、当該分に属し当時計で可視な数量があるか確認する。
    entries=M.read(M.HERE/'入力台帳.json')['entries']
    sources={'183':M.HERE/'純特徴.json.gz','184直接':HERE/'純特徴_直接.json.gz'}
    allrows={k:json.loads(gzip.decompress(p.read_bytes())) for k,p in sources.items()}
    quantity={}
    for label,rows in allrows.items():
        by={e['session']:[] for e in entries}
        for row in rows:
            if row['rvol'] is not None:by[row['session']].append(row)
        diagnostic=[]
        for e in entries:
            z=np.load(e['cache_absolute'],allow_pickle=False);start,end,_=M.bounds(e['session'])
            visible=set();last=-np.inf
            for t,v,vt in zip(z['now'],z['volume'],z['volume_time']):
                if not np.isfinite(t) or t<last:continue
                last=t
                if not start<=t<end:continue
                minute=int((t-start)//60)
                if np.isfinite(v) and np.isfinite(vt) and v>=0 and start+minute*60<=vt<=t:visible.add(minute)
            missing=0
            for r in by[e['session']]:
                closed=int((r['time']-start)//60)-1
                missing+=any(i not in visible for i in range(closed-20,closed+1))
            diagnostic.append({'scene':e['session'],'有限相対量q0':len(by[e['session']]),'21分窓の当分可視量不足':missing})
        quantity[label]={'対象q0':sum(d['有限相対量q0'] for d in diagnostic),'不足q0':sum(d['21分窓の当分可視量不足'] for d in diagnostic),'場別':diagnostic}
    results['数量']=quantity
    results['限界']='数量の完全性・真の受信時計を証明しない。価格時計の代理モデルで、数量時刻が未来だけの足を0量と誤認した対象窓がないことの検査。'
    M.save(HERE/'形成と数量の確認.json',results)
    print(json.dumps({'人工':results['人工'],'数量':{k:{a:v[a] for a in ('対象q0','不足q0')} for k,v in quantity.items()}},ensure_ascii=False))


if __name__=='__main__':main()
