"""TOPIX186の新入口・q0固定幅を、別の直接走査oracleで全件検査する。"""
from pathlib import Path
from collections import defaultdict
import json, math,sys
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'work/183損失安定性'))
import 入口186 as E
import numpy as np
import TOPIXを独立検算する as T


def main():
    """
    機能: 186全216候補の集計・金融・純入口対応・旧同体を読取専用で検査する。
    引数: なし。
    返り値: None。監査票を専有workへ保存する。
    """
    target=T.ROOT/'work/186TOPIX';state_path=target/'全216組安定性.json.gz'
    state_sha=T.sha(state_path);states=T.read(state_path)['metrics']
    packs={s['id']:T.read(target/'金融正本'/(s['id']+'.json.gz')) for s in states}
    hashes={k:T.sha(target/'金融正本'/(k+'.json.gz')) for k in packs}
    names=E.NAMES
    stored=T.read(target/'純入口.json.gz')
    pure={int(k):{(r['session'],r['time'],r['line']):r for r in rows} for k,rows in stored.items()}
    checks=[];cells=defaultdict(list);nfinancial=0;unique=0;same_old=0;signal_count=0
    for state in states:
        identifier=state['id'];pack=packs[identifier]
        checks.append({'id':identifier,'集計照合':T.inspect_groups(pack,state),'packSHA':hashes[identifier]})
        case=int(identifier.split('_')[1][1:]);name=next(n for n in names if '_'+n+'_' in identifier);ci=names.index(name)
        widthkey=identifier.split('_')[-2]
        ledger=pack['ledger'];previous={}
        assert len(pack['positions'])==len(ledger['net'])
        for i,scene in enumerate(ledger['scene']):
            request=ledger['request_time'][i];line=ledger['request_line'][i]
            row=pure[case][(scene,request,line)];expected_side=row['signals'][ci]
            expected_width=float(widthkey[1:]) if widthkey.startswith('W') else math.ceil(min(25,max(5,row['atr']*(1.5 if widthkey=='A15' else 2.5)))*4)/4
            assert ledger['width'][i]==expected_width,(identifier,i,'q0幅')
            assert ledger['side'][i]==expected_side and expected_side!=0,(identifier,i,'純q0対応')
            signal_count+=1
            assert request>previous.get(scene,-math.inf),(identifier,scene,'単一保有違反')
            position=pack['positions'][i]
            assert position['scene']==scene and position['fill']==ledger['entry_time'][i] and position['exit']==ledger['exit_time'][i]
            previous[scene]=ledger['exit_time'][i] if ledger['known'][i] else T.bounds(scene)[1]
            cells[scene].append(((request,ledger['side'][i],ledger['width'][i]),identifier,i))
    for entry in T.read(T.TARGET/'入力台帳.json')['entries']:
        scene=entry['session'];start,end,_=T.bounds(scene)
        with np.load(entry['cache_absolute'],allow_pickle=False) as archive:
            raw={k:archive[k] for k in ('now','line','bid','ask','valid')}
        t=raw['now'];finite=np.isfinite(t);prior=np.maximum.accumulate(np.where(finite,t,-np.inf))
        mask=finite&(t>=start)&(t<end)&(t>=prior)&raw['valid']
        arrays={k:v[mask] for k,v in raw.items() if k!='valid'};cache={}
        for key,identifier,i in cells[scene]:
            if key not in cache:cache[key]=T.financial_oracle(arrays,scene,*key)
            pack=packs[identifier]
            for k,v in cache[key].items():
                actual=pack['positions'][i][k] if k=='confirmed_until' else pack['ledger'][k][i]
                nfinancial+=T.V.check_equal(actual,v,(identifier,scene,i,k))
        unique+=len(cache)
    assert state_sha==T.sha(state_path)
    assert all(hashes[k]==T.sha(target/'金融正本'/(k+'.json.gz')) for k in packs)
    result={'成功':True,'候補数':len(states),'集計照合項目':sum(x['集計照合'] for x in checks),
            '金融照合項目':nfinancial,'金融全取得':sum(len(p['ledger']['net']) for p in packs.values()),
            '共通取得条件':unique,'q0固定幅検査':True,'純q0方向照合':signal_count,
            '単一保有検査':True,'金融新生成なし':True,
            '限界':'約定代用の別算術検査であり実約定保証ではない。直接形成の市場時計自体の証明は含まない。',
            '集計正本SHA':state_sha,'検査SourceSHA':T.sha(Path(__file__)),
            '独立oracleSourceSHA':T.sha(Path(T.__file__)),'候補':checks}
    (target/'独立確認.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='候補'},ensure_ascii=False))


if __name__=='__main__':main()
