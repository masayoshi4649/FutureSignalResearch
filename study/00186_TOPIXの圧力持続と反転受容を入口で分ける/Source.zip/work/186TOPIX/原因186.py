"""費用・値幅・未到達・時間帯・未参加を事後診断し、次の仮説へ分ける。"""
from pathlib import Path
from collections import defaultdict,deque,Counter
import gzip,json,statistics
import 入口186 as E
M=E.M;HERE=Path(__file__).parent


def read(p):
    """
    機能: 保存JSONを読む。
    引数: p(Path)。
    返り値: object。
    """
    return json.loads(gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes())


def summary(items):
    """
    機能: 既知寄与と未知・費用・到達を分離する。
    引数: items(list[dict])は診断用取引。
    返り値: dictは集計。未知を0へ埋めない。
    """
    known=[r for r in items if r['net'] is not None];vals=[r['net'] for r in known]
    return {'取得':len(items),'未知':len(items)-len(known),'参加場':len(set(r['scene'] for r in items)),
      '利益':sum(max(v,0) for v in vals),'損失':sum(-min(v,0) for v in vals),'純損益':sum(vals),
      '費用前':sum(r['gross']*1000 for r in known),'fee_slip':len(known)*583.6,
      '既知建玉中央値':statistics.median(vals) if vals else None,
      '順逆未到達不足':dict(Counter(r['label'] for r in items)),
      'spread_ATR中央値':statistics.median(r['spread_atr'] for r in items) if items else None,
      'fee_ATR中央値':statistics.median(r['fee_atr'] for r in items) if items else None}


def main():
    """
    機能: P0の時間帯と費用水準を診断し、全場不参加の真因を分ける。
    引数: なし。
    返り値: None。結果は事後群であり新手法成績としない。
    """
    source=read(E.ROOT/'inputs/TOPIX原順8列_20260921_20261116/純特徴184直接.json.gz')
    lookup={(r['session'],r['time'],r['line']):r for r in source}
    ident='TOPIX186_F1_P0_持続中の押戻し_緩_A25_H60';pack=read(HERE/'金融正本'/(ident+'.json.gz'));l=pack['ledger'];items=[]
    for i,scene in enumerate(l['scene']):
        r=lookup[(scene,l['request_time'][i],l['request_line'][i])];s=l['side'][i];a=r['atr'];m=r['m5']
        items.append({'scene':scene,'phase':l['phase'][i],'net':l['net'][i],'gross':l['gross_pt'][i],
          'label':l['label'][i],'reason':l['reason'][i],'spread_atr':r['spread']/a,'fee_atr':.5836/a,
          'spread_plus_fee_atr':(r['spread']+.5836)/a,'adx':m['adx'],'dist':s*(r['close']-m['ema8'])/a})
    grouped={}
    for phase,name in [(0,'DAY'),(1,'PRE'),(2,'POST')]:
        rr=[r for r in items if r['phase']==phase];grouped[name]={'全体':summary(rr),'返済理由':{key:summary([r for r in rr if r['reason']==key]) for key in sorted(set(r['reason'] for r in rr))}}
        for field,limits in [('spread_atr',[0,.05,.1,.2,100]),('fee_atr',[0,.05,.1,.2,100]),('spread_plus_fee_atr',[0,.1,.2,.4,100]),('adx',[0,15,25,40,100])]:
            grouped[name][field]={f'{lo}〜{hi}':summary([r for r in rr if lo<=r[field]<hi]) for lo,hi in zip(limits,limits[1:])}
    # ----------------------------------------
    # 0取得Dayは値を補完せず、入力不足と当時の複合条件を逐段に分ける。
    zero=[d['scene'] for d in pack['diagnostics'] if d['scene'].endswith('Day') and d['取得']==0];zero_detail={}
    for scene in zero:
        rows=[r for r in source if r['session']==scene];hist=deque(maxlen=3);last=None;previous=None;counts=Counter()
        for r in rows:
            m=r['m5'];ident=(m['count'],m['end'],m['published'])
            if ident!=last:hist.append(m);last=ident
            a=r['atr'];coherent=len(hist)==3 and all(hist[i]['end']-hist[i-1]['end']==300 for i in (1,2))
            counts['q0']+=1;counts['3足連続が既知']+=coherent;counts['相対量が既知']+=r['rvol'] is not None
            for s in (1,-1):
                steps=[coherent,
                  sum(s*(p['slope'] or 0)>0 and s*p['di']>0 and s*(p['ema8']-p['ema21'])>0 for p in hist)>=2,
                  s*m['di']>=.015 and s*(m['slope'] or 0)>0 and s*(m['ema8']-m['ema21'])>0,
                  s*r['m15']['di']>=0,
                  -.75<=s*(r['close']-m['ema8'])/a<=1.5 and 30<=(m['rsi'] if s==1 else 100-m['rsi'])<=80,
                  s*r['body']<0 and s*r['progress']<=0,
                  s*m['hist']/a>=-.15,
                  r['rvol'] is not None and r['rvol']>=.5,
                  0<r['spread']<=1.5 and r['range']<=2 and r['live'] is not None and s*r['live']>=-.25]
                for i in range(len(steps)):counts[f'段階{i+1}まで成立']+=all(steps[:i+1])
            previous=r
        zero_detail[scene]=dict(counts)
    result={'候補':pack['id'],'事後診断':True,'時間帯':grouped,'未取得Day':zero_detail,
      '段階順':['3確定足連続','3足中2足の同方向','現DI/EMA方向','15分DI方向','位置/RSI','1分の押戻し','MACD幅','相対量','spread/足幅/当時進行'],
      '解釈':'費用前も負なら費用だけの原因としない。赤字群の単なる除外を新戦略とせず、次試行で実側反転/技術補完・口座枠を再生する。'}
    M.save(HERE/'原因診断.json',result)
    print(json.dumps({'未取得Day':zero_detail,'帯':{b:d['全体'] for b,d in grouped.items()}},ensure_ascii=False))


if __name__=='__main__':main()
