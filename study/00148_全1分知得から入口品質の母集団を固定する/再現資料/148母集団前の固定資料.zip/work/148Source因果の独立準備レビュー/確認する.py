"""148 Source本体だけの独立因果境界を停止版へ結ぶ。作者部品の独立検算は含めない。"""
from pathlib import Path
import argparse
import ast
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
SOURCE = ROOT / 'work/148全1分知得の入口母集団'
FEATURES = ROOT / 'work/148全1分候補の当時特徴'
SPEC = ROOT / 'work/148_全1分知得の入口母集団を固定する採用仕様.md'
SPEC_SHA = '675b1afd79729ce6cd6f4d604337a92d006554d1c7963dcece23afaae4894f36'
DRIVER = ROOT / 'work/148母集団生成と観測を分離して実行する.py'
PERFORMANCE = ROOT / 'work/148観測の実行性能を測る.py'


def fingerprint(path: Path) -> dict:
    """
    機能: 自然入力ではなくコード/停止票のbytesだけを指紋化する。
    引数: path(Path)。返り値: dictはpath/bytes/SHA256。
    """
    raw = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def run(name: str, args: list[str], cwd: Path) -> dict:
    """
    機能: 人工又はhelpだけを実行してログを専有先へ保存する。
    引数: name(str)、args(list[str])、cwd(Path)。返り値: dictは実行概要。
    """
    result = subprocess.run(args, cwd=cwd, capture_output=True, text=True, encoding='utf-8')
    target = HERE / (name + 'のログ.txt')
    target.write_text(result.stdout + result.stderr, encoding='utf-8')
    assert result.returncode == 0, (name, result.stdout, result.stderr)
    return {'区分': name, '引数': args, '終了code': result.returncode, 'ログ': fingerprint(target)}


def main() -> None:
    """
    機能: 作者停止SHAを確認後、私有overlay5群/全test/vet/build/CLIを一回確認する。
    引数: CLI --source-proof-sha/--exe-sha(str)はRoot・作者が明示した停止版。
    返り値: None。自然Source/旧87本文/Raw/CSV/新金融/追加2場を開かない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-proof-sha', required=True)
    parser.add_argument('--exe-sha', required=True)
    args = parser.parse_args()
    proof_path = SOURCE / '準備の確認.json'
    exe = SOURCE / '全1分母集団生成.exe'
    assert fingerprint(SPEC)['sha256'] == SPEC_SHA
    assert fingerprint(proof_path)['sha256'] == args.source_proof_sha
    assert fingerprint(exe)['sha256'] == args.exe_sha
    declared = json.loads(proof_path.read_bytes())
    assert declared['成功']
    paths = sorted({p for folder in (SOURCE, FEATURES) for p in folder.rglob('*')
                    if p.is_file() and p.suffix in ('.go', '.mod', '.exe', '.json', '.md')})
    paths += [SPEC, DRIVER, PERFORMANCE, ROOT / 'work/148純case統合の準備/準備の確認.json']
    before = [fingerprint(p) for p in paths]
    virtual = SOURCE / 'zz_independent_review148_test.go'
    assert not virtual.exists()
    private = HERE / '独立境界_test.go.txt'
    overlay = HERE / 'overlay.json'
    overlay.write_text(json.dumps({'Replace': {str(virtual.resolve()): str(private.resolve())}},
                                  ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    checks = [run('独立5群', ['go', 'test', '-overlay', str(overlay), '-count=1', '-run', '^TestIndependent148', '-v', './...'], SOURCE),
              run('全作者人工', ['go', 'test', '-count=1', './...'], SOURCE),
              run('vet', ['go', 'vet', './...'], SOURCE),
              run('build', ['go', 'build', './...'], SOURCE)]
    for path in (DRIVER, PERFORMANCE):
        ast.parse(path.read_text(encoding='utf-8'))
        checks.append(run(path.stem + '_help', ['python', '-X', 'utf8', str(path), '--help'], ROOT))
    checks.append(run('Source_help', [str(exe), '--help'], ROOT))
    after = [fingerprint(p) for p in paths]
    assert before == after
    proof = {'成功': True, '試行': 148, '状態': 'Source本体の独立因果レビューを編集停止',
             '採用仕様SHA256': SPEC_SHA, '作者停止票SHA256': args.source_proof_sha, 'exeSHA256': args.exe_sha,
             '独立範囲': ['q0最新group/不適格台帳/eligibleだけX', '最新quality/L/TTLの理由優先',
                       '独立pendingの複数/同q1共有', 'q1未来値を変更してもq0/Xが同体',
                       '同Raw過去履歴/未知slot非圧縮', '親gzipの全CRC/JSON末尾/stat後の成功',
                       'Raw取得後も末尾を読み、後発破損なら成功禁止', '全73/参照SHAのstatic guard'],
             '独立対象外': ['自分が作者のcase_builder.go/test.go',
                        '自分が147で作者だったpublications cache/BB数学の再用',
                        'features100の算術（Root/特徴担当の別票）'],
             '静的接続所見': '親ReadParent全成功後だけRaw走査、全場Raw成功後だけ旧C1をbuilderへ渡す。WriteはGenerate正常終了後だけ。driverはF0/F1分離、q0入力へq1/labelを渡すCLIなし',
             'driver境界': '本票のdriver SHAは検査時点。Rootは最終準備票schema/独立票bindと観測bytes追補後にdriverを最終停止する',
             '実行': checks, '私有人工SHA256': fingerprint(private)['sha256'], 'overlay': fingerprint(overlay),
             '前後同体': before, '確認器': fingerprint(Path(__file__)),
             '新自然/原板/価格CSV/金融/旧87本文/追加2場読取': False,
             'Source/共用Bank/正式文書変更': False, '未解決の重大不整合': []}
    target = HERE / '準備の確認.json'
    target.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'proof_sha256': fingerprint(target)['sha256'], 'sources': len(paths),
                      'private_groups': 5}, ensure_ascii=False))


if __name__ == '__main__':
    main()
