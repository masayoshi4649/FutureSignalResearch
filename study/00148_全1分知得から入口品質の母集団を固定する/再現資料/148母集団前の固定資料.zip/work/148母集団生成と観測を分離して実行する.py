"""148の候補/特徴/取得生成と凍結133観測をF0/F1で分離する。"""
from pathlib import Path
from datetime import datetime,timezone
import argparse
import hashlib
import importlib.util
import json
import sys

ROOT=Path(__file__).resolve().parent.parent
GEN=ROOT/'work/148全1分知得の入口母集団'
FEATURES=ROOT/'work/148全1分候補の当時特徴'
FORMAL=ROOT/'study/00148_全1分知得から入口品質の母集団を固定する'
OWN=ROOT/'work/148全1分母集団の評価'
OUT=OWN/'母集団生成'
SPEC=ROOT/'work/148_全1分知得の入口母集団を固定する採用仕様.md'
INPUT=GEN/'入力参照.json'
FIXED=OUT/'固定取得入力.json'
META=OUT/'入口参照.json'
OBS=OWN/'固定取得の正逆観測.json'
KERNEL=ROOT/'work/133固定取得の正逆評価器/固定取得の正逆評価.exe'
PERF=ROOT/'work/148観測の実行性能を測る.py'
OLD_FIXED=ROOT/'work/145構造イベントの評価/固定入力/固定取得入力.json'
OLD_META=ROOT/'work/145構造イベントの評価/固定入力/入口参照.json'
OLD_PAIRS=ROOT/'work/145構造イベントの評価/固定取得の正逆観測.json'
OLD_SUMMARY=ROOT/'work/145構造イベントの評価/金融評価/集計.json'
SHAS={KERNEL:'033cf22a052e985bc61aa020a04fa6d499119051aaa39bb2adb715a4af1e7736',
    OLD_FIXED:'d2becb3b1d6de656a6cc3f04d576d95d99693dfc42efc03582ed04d2be8784e8',
    OLD_META:'3a3a144c478fa45f85e03ad4b8e4461e420592da24088458c7aa1cb748c8eb8d',
    OLD_PAIRS:'3b92da8b447d7be9ead6a2a112759ca7272a1e65d6cb5516989e3faf50c54d62',
    OLD_SUMMARY:'fb374d53982ce7727c5ae936d72a20a973029de35480ed442a6cb2305fc9c861'}
OUTPUT_NAMES=('出生台帳.json','当時特徴.json','取得対応.json','固定取得入力.json','入口参照.json')


def sha(path: Path) -> str:
    """
    機能: 大ファイルを全保持せず保存bytesのSHAを返す。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    digest=hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda:source.read(1024*1024),b''):digest.update(chunk)
    return digest.hexdigest()


# ----------------------------------------
def load_module(path: Path,name: str) -> object:
    """
    機能: mainを実行せず宣言済み補助部品を読む。
    引数: path(Path)、name(str)。
    返り値: objectはモジュール。
    """
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value


# ----------------------------------------
def file_refs(value: object) -> set[Path]:
    """
    機能: 小参照JSONに明示された物理FileRefを検査する。
    引数: value(object)は小参照の値。
    返り値: set[Path]はSHA/任意bytesが一致するファイル。大入力本文へ再帰しない。
    """
    result=set()
    if isinstance(value,dict):
        if isinstance(value.get('path'),str) and isinstance(value.get('sha256'),str):
            path=Path(value['path']);path=path if path.is_absolute() else ROOT/path
            assert path.is_file() and sha(path)==value['sha256']
            if value.get('bytes',0)>0:assert path.stat().st_size==value['bytes']
            result.add(path.resolve())
        for child in value.values():result.update(file_refs(child))
    elif isinstance(value,list):
        for child in value:result.update(file_refs(child))
    return result


# ----------------------------------------
def main() -> None:
    """
    機能: 出生前固定→全母集団生成→全case固定→正逆観測を別段階で実行する。
    引数: CLI --mode(str)は固定/生成/観測前/観測。
    返り値: None。既存出力を上書きせず、学習/選択/合格判定は行わない。
    """
    parser=argparse.ArgumentParser(description='148母集団の生成と観測を段階固定する')
    parser.add_argument('--mode',required=True,choices=('固定','生成','観測前','観測'))
    args=parser.parse_args();helper=load_module(ROOT/'work/133金融前を固定して実行する.py','148固定補助')
    OWN.mkdir(parents=True,exist_ok=True);f0=OWN/'F0母集団前.json';f1=OWN/'F1全case観測前.json'
    if args.mode=='固定':
        for path,h in SHAS.items():assert sha(path)==h
        source_ready=json.loads((GEN/'準備の確認.json').read_bytes())
        feature_ready=json.loads((FEATURES/'準備の確認.json').read_bytes())
        for ready in (source_ready,feature_ready):assert ready['成功'] and ready['採用仕様SHA256']==sha(SPEC)
        for ref in source_ready['源']+[source_ready['実行ファイル']]:
            path=ROOT/ref['path'];assert path.stat().st_size==ref['bytes'] and sha(path)==ref['sha256']
        feature_stop=json.loads((FEATURES/'停止の確認.json').read_bytes())
        assert feature_stop['成功']
        for ref in feature_stop['保存対象']:
            path=FEATURES/ref['path'];assert path.stat().st_size==ref['bytes'] and sha(path)==ref['sha256']
        assert source_ready['列定義物理SHA256']==sha(FEATURES/'列定義.json')
        assert sha(ROOT/'inputs/00148_全1分入口母集団/100特徴の列定義.json')==source_ready['列定義物理SHA256']
        independent_paths=[ROOT/'work/148特徴の独立検算/準備の確認.json',
            ROOT/'work/148case統合の独立検査/準備の確認.json',
            ROOT/'work/148Source因果の独立準備レビュー/準備の確認.json']
        for path in independent_paths:assert json.loads(path.read_bytes())['成功']
        for name in ('README.md','条件.md','設定と結果.md'):assert (FORMAL/name).is_file()
        files=set(SHAS)|{Path(__file__).resolve(),PERF,SPEC,INPUT,ROOT/'work/133金融前を固定して実行する.py',
            ROOT/'inputs/00148_全1分入口母集団/100特徴の列定義.json',ROOT/'work/148性能計測器の準備/人工の確認.json'}
        refs=file_refs(json.loads(INPUT.read_bytes()));assert len(refs)>=4;files.update(refs)
        for folder in (GEN,FEATURES,FORMAL,ROOT/'work/118複数技法の入口条件'):
            files.update(p for p in folder.rglob('*') if p.is_file() and p.suffix in ('.go','.mod','.exe','.py','.json','.md'))
        for path in independent_paths:
            files.update(p for p in path.parent.iterdir() if p.is_file() and p.suffix in ('.go','.mod','.py','.json','.md','.txt'))
        helper.save(f0,{'成功':True,'試行':148,'段階':'全1分母集団生成前F0','UTC':datetime.now(timezone.utc).isoformat(),
            'モデル又は売買選択':False,'最終選択取引数':None,'追加2場価格未読':True,
            'ファイル':{str(p.resolve()):sha(p) for p in sorted(files)}})
        print(json.dumps({'F0_SHA256':sha(f0),'源数':len(files)},ensure_ascii=False));return
    before=json.loads(f0.read_bytes());helper.verify(before)
    if args.mode=='生成':
        assert not OUT.exists()
        perf=load_module(PERF,'148性能計測')
        command=[str(GEN/'全1分母集団生成.exe'),'--input',str(INPUT),'--sha256',sha(INPUT),'--output-dir',str(OUT),'--workers','1','--execute-after-f0']
        result=perf.measure(command,ROOT);helper.save(OWN/'生成の実行性能.json',result)
        assert result['成功'] and result['終了後ピーク取得成功']
        for name in OUTPUT_NAMES:assert (OUT/name).is_file()
        for name in ('出生台帳.json','当時特徴.json','取得対応.json'):
            value=json.loads((OUT/name).read_bytes())
            assert value['success'] and value['trial']==148 and value['selected_trade_count'] is None
        helper.verify(before)
        helper.save(OWN/'生成の完了.json',{'成功':True,'試行':148,'F0_SHA256':sha(f0),
            '学習又は選択実行':False,'成果物':{name:sha(OUT/name) for name in OUTPUT_NAMES}})
        print(json.dumps({'成功':True,'生成物数':5,'固定取得入力SHA256':sha(FIXED)},ensure_ascii=False));return
    if args.mode=='観測前':
        assert json.loads((OWN/'生成の完了.json').read_bytes())['成功']
        fixed=json.loads(FIXED.read_bytes());assert len(fixed['scenes'])==73 and fixed['expected_entry_count']>=87
        files={Path(p) for p in before['ファイル']}|{f0,OWN/'生成の完了.json',OWN/'生成の実行性能.json'}|{OUT/name for name in OUTPUT_NAMES}
        helper.save(f1,{'成功':True,'試行':148,'段階':'全case固定後のF1','UTC':datetime.now(timezone.utc).isoformat(),
            'F0_SHA256':sha(f0),'engine試行':133,'全case数':fixed['expected_entry_count'],
            '最終売買選択':False,'特徴へq1又はラベルを混ぜない':True,
            'ファイル':{str(p.resolve()):sha(p) for p in sorted(files)}})
        print(json.dumps({'F1_SHA256':sha(f1),'全観測case数':fixed['expected_entry_count']},ensure_ascii=False));return
    financial=json.loads(f1.read_bytes());helper.verify(financial);assert not OBS.exists()
    perf=load_module(PERF,'148観測性能計測')
    command=[str(KERNEL),'--input',str(FIXED),'--sha256',sha(FIXED),'--output',str(OBS),'--workers','8']
    result=perf.measure(command,ROOT);helper.save(OWN/'全case観測の実行性能.json',result)
    assert result['成功'] and result['終了後ピーク取得成功']
    helper.verify_result(json.loads(OBS.read_bytes()),json.loads(FIXED.read_bytes()))
    helper.verify(before);helper.verify(financial)
    helper.save(OWN/'観測の完了.json',{'成功':True,'試行':148,'F1_SHA256':sha(f1),'結果SHA256':sha(OBS),
        '観測JSON_bytes':OBS.stat().st_size,'恒久gzip_bytes':'保管票で別記',
        '最大RAM測定':True,'RAMの定義':'観測exe単一プロセスのOS生涯PeakWorkingSetとPeakCommit。親PythonのRAMではない。',
        '学習又は売買選択':False})
    print(json.dumps({'成功':True,'結果SHA256':sha(OBS),'最大WorkingSet_bytes':result['最大WorkingSet_bytes']},ensure_ascii=False))


if __name__=='__main__':main()
