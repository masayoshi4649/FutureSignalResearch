"""Windows子プロセスの実時間とOSの生涯ピークメモリを計測する。"""
from pathlib import Path
import argparse
import ctypes
from ctypes import wintypes
import hashlib
import json
import os
import platform
import subprocess
import sys
import time


class MemoryCounters(ctypes.Structure):
    """WindowsのPROCESS_MEMORY_COUNTERSと同じ型・順序で値を受ける。"""
    _fields_=[('cb',wintypes.DWORD),('PageFaultCount',wintypes.DWORD),
        ('PeakWorkingSetSize',ctypes.c_size_t),('WorkingSetSize',ctypes.c_size_t),
        ('QuotaPeakPagedPoolUsage',ctypes.c_size_t),('QuotaPagedPoolUsage',ctypes.c_size_t),
        ('QuotaPeakNonPagedPoolUsage',ctypes.c_size_t),('QuotaNonPagedPoolUsage',ctypes.c_size_t),
        ('PagefileUsage',ctypes.c_size_t),('PeakPagefileUsage',ctypes.c_size_t)]


def counters(process: subprocess.Popen) -> tuple[dict|None,int]:
    """
    機能: 所有する子プロセスHANDLEからOSメモリ統計を読む。
    引数: process(subprocess.Popen)は終了後もHANDLEを閉じていない子。
    返り値: tuple[dict|None,int]は統計又は失敗とWindowsエラー番号。
    """
    api=ctypes.WinDLL('psapi',use_last_error=True).GetProcessMemoryInfo
    api.argtypes=[wintypes.HANDLE,ctypes.POINTER(MemoryCounters),wintypes.DWORD]
    api.restype=wintypes.BOOL
    value=MemoryCounters();value.cb=ctypes.sizeof(value)
    if not api(wintypes.HANDLE(int(process._handle)),ctypes.byref(value),value.cb):
        return None,ctypes.get_last_error()
    return {'peak_working_set_bytes':int(value.PeakWorkingSetSize),
        'working_set_bytes':int(value.WorkingSetSize),
        'peak_commit_bytes':int(value.PeakPagefileUsage),'commit_bytes':int(value.PagefileUsage)},0


# ----------------------------------------
def measure(command: list[str],cwd: Path) -> dict:
    """
    機能: コマンドを一度だけ実行し終了後のOSピーク値を所有HANDLEから取得する。
    引数: command(list[str])はshellを介さない引数、cwd(Path)は作業先。
    返り値: dictは終了コード・時間・観測中ピークと終了後ピークの記録。
    """
    assert os.name=='nt' and command
    started=time.monotonic()
    process=subprocess.Popen(command,cwd=cwd,creationflags=subprocess.CREATE_NO_WINDOW)
    samples=0;peak_ws=0;peak_commit=0;last_error=0
    while process.poll() is None:
        value,error=counters(process)
        if value is not None:
            samples+=1;peak_ws=max(peak_ws,value['peak_working_set_bytes']);peak_commit=max(peak_commit,value['peak_commit_bytes'])
        else:last_error=error
        time.sleep(.05)
    code=process.wait();elapsed=time.monotonic()-started
    final,error=counters(process)
    if final is not None:
        peak_ws=max(peak_ws,final['peak_working_set_bytes']);peak_commit=max(peak_commit,final['peak_commit_bytes'])
    else:last_error=error
    return {'成功':code==0,'終了コード':code,'実時間秒':elapsed,'PID':process.pid,'サンプル数':samples,
        '最大WorkingSet_bytes':peak_ws if samples or final else None,
        '最大Commit_bytes':peak_commit if samples or final else None,
        '終了後HANDLEから取得':final,'終了後ピーク取得成功':final is not None,
        '最後のAPI失敗番号':last_error,'測定間隔秒':.05,'コマンド':command,'作業先':str(cwd.resolve()),
        'Python':sys.version,'OS':platform.platform(),
        '意味':'WorkingSetは常駐RAM、Commitはコミット量。OS生涯ピークを読む。子孫プロセスの合算ではない。',
        '公式資料':['https://learn.microsoft.com/en-us/windows/win32/api/psapi/nf-psapi-getprocessmemoryinfo',
            'https://learn.microsoft.com/en-us/windows/win32/api/psapi/ns-psapi-process_memory_counters']}


# ----------------------------------------
def main() -> None:
    """
    機能: 自己確認又は明示コマンドの計測を未作成JSONへ保存する。
    引数: CLI --output(Path)、--cwd(Path)、--self-test(bool)、残りcommand(list[str])。
    返り値: None。計測対象を途中で停止・再実行せず、失敗も記録する。
    """
    parser=argparse.ArgumentParser(description='148の観測プロセス実時間/最大メモリを測る')
    parser.add_argument('--output',type=Path,required=True);parser.add_argument('--cwd',type=Path,default=Path.cwd())
    parser.add_argument('--self-test',action='store_true');parser.add_argument('command',nargs=argparse.REMAINDER)
    args=parser.parse_args();assert not args.output.exists()
    command=args.command
    if command and command[0]=='--':command=command[1:]
    if args.self_test:
        assert not command
        command=[sys.executable,'-X','utf8','-c','import time;b=bytearray(32*1024*1024);time.sleep(.2)']
    assert command
    result=measure(command,args.cwd)
    result['計測器SHA256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    if args.self_test:
        assert result['成功'] and result['終了後ピーク取得成功']
        assert result['最大WorkingSet_bytes']>=32*1024*1024 and result['最大Commit_bytes']>=32*1024*1024
        result['人工確認']='32MiB確保した短い子の終了後にも所有HANDLEから生涯ピークを取得。自然入力なし。'
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with args.output.open('x',encoding='utf-8',newline='\n') as f:json.dump(result,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps({'成功':result['成功'],'終了後ピーク取得成功':result['終了後ピーク取得成功'],
        '最大WorkingSet_bytes':result['最大WorkingSet_bytes'],'実時間秒':result['実時間秒']},ensure_ascii=False))
    if result['終了コード']!=0:raise SystemExit(result['終了コード'])


if __name__=='__main__':main()
