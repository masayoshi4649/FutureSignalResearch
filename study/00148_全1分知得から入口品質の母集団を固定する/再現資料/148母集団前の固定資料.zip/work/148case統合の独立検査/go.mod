module independentcases148

go 1.24.2

require (
 entrypopulation148 v0.0.0
 github.com/masayoshi4649/SessionTradeExecuter/features148 v0.0.0
 github.com/masayoshi4649/SessionTradeExecuter/entryrules118 v0.0.0
)

replace entrypopulation148 => ../148全1分知得の入口母集団
replace github.com/masayoshi4649/SessionTradeExecuter/features148 => ../148全1分候補の当時特徴
replace github.com/masayoshi4649/SessionTradeExecuter/entryrules118 => ../118複数技法の入口条件
