package independentcases148

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	p "entrypopulation148"
	"fmt"
	"reflect"
	"testing"
)

// fixture は作者fixtureを使わず73場87件と未知の大整数を作ります。
//
// 引数: t(*testing.T)。返り値: 固定JSON、参照JSON、旧売case Quoteです。
func fixture(t *testing.T) (json.RawMessage, json.RawMessage, p.Quote) {
	t.Helper()
	fixed := map[string]any{"expected_entry_count": 87, "scenes": []any{}, "不明な原値": json.Number("9223372036854775801")}
	meta := map[string]any{"trial": 145, "success": true, "sessions": []any{}, "entries": []any{}, "fixed_input_sha256": "旧SHA", "不明な原値": json.Number("9223372036854775801")}
	var reused p.Quote
	for i := 0; i < 73; i++ {
		sid := fmt.Sprintf("独立場%02d", i)
		start := float64(i * 20000)
		sc := map[string]any{"session": sid, "contract": "独立限月", "start": start, "end": start + 10000, "force_close": start + 9900, "expected_accepted": 1000, "entries": []any{}, "raw": map[string]any{"mtime_ns": json.Number("9223372036854775801")}}
		count := 1
		if i < 14 {
			count = 2
		}
		for j := 0; j < count; j++ {
			id := fmt.Sprintf("独立旧/%02d/%d", i, j)
			side := -1
			if j > 0 {
				side = 1
			}
			q := p.Quote{Clock: "独立価格時計", Time: start + 500 + float64(j*100), Index: int64(50 + j*10), SourceLine: int64(60 + j*10), Last: 1000, Bid: 990, Ask: 1010, QuoteOK: true}
			sc["entries"] = append(sc["entries"].([]any), map[string]any{"id": id, "side": side, "entry": q, "旧追加キー": []any{true, json.Number("9223372036854775801")}})
			meta["entries"] = append(meta["entries"].([]any), map[string]any{"id": id, "session": sid, "contract": "独立限月", "native_side": side, "entry_quote": q, "origins": []any{map[string]any{"未知の整数": json.Number("9223372036854775801")}}})
			if i == 0 && j == 0 {
				reused = q
			}
		}
		fixed["scenes"] = append(fixed["scenes"].([]any), sc)
		meta["sessions"] = append(meta["sessions"].([]any), sid)
	}
	a, e := json.Marshal(fixed)
	if e != nil {
		t.Fatal(e)
	}
	b, e := json.Marshal(meta)
	if e != nil {
		t.Fatal(e)
	}
	return a, b, reused
}

// decode は照合側でも大整数をfloat64へ落とさず保持します。
//
// 引数: t(*testing.T)、raw(json.RawMessage)。返り値: map[string]anyです。
func decode(t *testing.T, raw json.RawMessage) map[string]any {
	t.Helper()
	d := json.NewDecoder(bytes.NewReader(raw))
	d.UseNumber()
	var v map[string]any
	if e := d.Decode(&v); e != nil {
		t.Fatal(e)
	}
	return v
}

// Test独立C1売側と共有q1 は原値保持・売側stream対応・出生canonicalを照合します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test独立C1売側と共有q1(t *testing.T) {
	old, meta, q := fixture(t)
	beforeOld, beforeMeta := append([]byte{}, old...), append([]byte{}, meta...)
	born := q
	born.Time = 480
	born.Index = 48
	born.SourceLine = 58
	reuse := p.TakenEvent{EventID: "再用", Session: "独立場00", Contract: "独立限月", Born: born, Entry: q}
	target := q
	target.Time = 555
	target.Index = 56
	target.SourceLine = 66
	first := p.TakenEvent{EventID: "最初", Session: reuse.Session, Contract: reuse.Contract, Entry: target, Born: q}
	first.Born.Time = 530
	first.Born.Index = 52
	first.Born.SourceLine = 62
	later := first
	later.EventID = "後"
	later.Born.Time = 535
	later.Born.Index = 54
	later.Born.SourceLine = 64
	input := []p.TakenEvent{later, reuse, first}
	copyInput := append([]p.TakenEvent{}, input...)
	result, e := p.BuildCases(old, meta, input)
	if e != nil {
		t.Fatal(e)
	}
	if result.Counts["all_unique_cases"] != 88 || result.Counts["taken_events"] != 3 || result.Counts["population_unique_q1"] != 2 || result.Counts["extra_events_sharing_q1"] != 1 || result.Counts["c1_reused_events"] != 1 {
		t.Fatalf("物理単位の不一致: %+v", result.Counts)
	}
	for _, link := range result.Links {
		if link.EventID == "再用" {
			if !link.C1Reused || link.BuyStream != "reverse" || link.SellStream != "original" {
				t.Fatalf("旧売側caseの買/売対応: %+v", link)
			}
		} else if link.C1Reused || link.CanonicalEventID != "最初" || link.BuyStream != "original" {
			t.Fatalf("新case canonical不一致: %+v", link)
		}
	}
	a, b := decode(t, old), decode(t, result.Fixed)
	for i, v := range a["scenes"].([]any) {
		orig := v.(map[string]any)
		after := b["scenes"].([]any)[i].(map[string]any)
		for key, value := range orig {
			if key == "entries" {
				for j, entry := range value.([]any) {
					if !reflect.DeepEqual(entry, after[key].([]any)[j]) {
						t.Fatal("旧固定entryの欠落/値変化")
					}
				}
			} else if !reflect.DeepEqual(value, after[key]) {
				t.Fatal("旧sceneの値変化")
			}
		}
	}
	m, n := decode(t, meta), decode(t, result.Metadata)
	for key, value := range m {
		if key != "trial" && key != "fixed_input_sha256" && !reflect.DeepEqual(value, n[key]) {
			t.Fatalf("旧meta値変化: %s", key)
		}
	}
	digest := sha256.Sum256(result.Fixed)
	if n["fixed_input_sha256"] != hex.EncodeToString(digest[:]) {
		t.Fatal("再Marshal後等の異なるbytesをSHAへ使った")
	}
	if !bytes.Equal(old, beforeOld) || !bytes.Equal(meta, beforeMeta) || !reflect.DeepEqual(input, copyInput) {
		t.Fatal("入力を変更した")
	}
	if !bytes.Contains(result.Metadata, []byte("9223372036854775801")) {
		t.Fatal("整数精度を失った")
	}
}

// Test独立TTLと全値矛盾 は最初q1の期限等号と同物理行の気配差を拒否します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test独立TTLと全値矛盾(t *testing.T) {
	old, meta, q := fixture(t)
	event := p.TakenEvent{EventID: "期限", Session: "独立場00", Contract: "独立限月", Born: q, Entry: q}
	event.Born.Time = 470
	event.Born.Index = 47
	event.Born.SourceLine = 57
	if _, e := p.BuildCases(old, meta, []p.TakenEvent{event}); e == nil {
		t.Fatal("30秒の期限等号で取得した")
	}
	event.Born.Time = 480
	event.EventID = "気配差"
	event.Entry.Ask = 1020
	if _, e := p.BuildCases(old, meta, []p.TakenEvent{event}); e == nil {
		t.Fatal("旧caseと同原行の異なるAskを統合した")
	}
	result, e := p.BuildCases(old, meta, nil)
	if e != nil {
		t.Fatal(e)
	}
	if !reflect.DeepEqual(decode(t, old), decode(t, result.Fixed)) || result.Counts["all_unique_cases"] != 87 {
		t.Fatal("新0件でも旧87を保持しない")
	}
}
