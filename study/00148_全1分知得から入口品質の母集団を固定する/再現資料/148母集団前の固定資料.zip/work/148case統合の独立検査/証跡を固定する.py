"""独立fixtureの実行済み2群とpure builderの停止源を固定する。"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
GEN=ROOT/'work/148全1分知得の入口母集団'


def sha(path: Path) -> str:
    """
    機能: ファイルの現在bytesの指紋を返す。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 作者停止時と現在のbuilder同体を確認し、独立2群の証跡を保存する。
    引数: なし。人工の重複実行も自然資料の読取も行わない。
    返り値: None。
    """
    source=GEN/'case_builder.go';test=GEN/'case_builder_test.go'
    assert sha(source)=='c8df813b5c98998e945b36ef7767ac50e2ee9ab98cfcd3f4fddb2a41075820db'
    assert sha(test)=='2c0ff9160f0ecabdb4d4dd802616bf67bb94b0e5f7af9697c9e02c24129a8ae6'
    ready=ROOT/'work/148純case統合の準備/準備の確認.json'
    assert sha(ready)=='471c540f62d9caffed93f8792d448344a51d17405e08fb1cd5ab705259dc717c'
    log=HERE/'人工の実行.txt';assert log.read_text(encoding='utf-8').count('--- PASS: Test独立')==2
    result={'成功':True,'試行':148,'UTC':datetime.now(timezone.utc).isoformat(),'独立確認者':'Root',
        '独立人工群':2,'確認':['旧売側caseのbuy/reverse対応','独立3eventを2q1へ統合','最初出生canonical',
            '旧87と全73の未知キー/大整数/entries/origins保持','全入力非変更','返却fixed正確bytesのSHA',
            'TTL等号拒否','同q1気配差拒否','新0でも旧固定全値保持'],
        '作者fixture使用':False,'自然原板/価格/新金融使用':False,
        '範囲':'pure BuildCases公開APIの独立人工と静的読取。Raw first-normal取得や特徴100の検算ではない。',
        '作者停止源同体':True,'源':{str(p):sha(p) for p in (source,test,ready,HERE/'go.mod',HERE/'independent_test.go',log,Path(__file__).resolve())}}
    with (HERE/'準備の確認.json').open('x',encoding='utf-8',newline='\n') as out:json.dump(result,out,ensure_ascii=False,indent=2);out.write('\n')
    print(json.dumps({'成功':True,'独立人工群':2,'準備SHA256':sha(HERE/'準備の確認.json')},ensure_ascii=False))


if __name__=='__main__':main()
