package main

import (
	source "entrypopulation148"
	"flag"
	"fmt"
	"os"
)

// main はF0後だけ全知得母集団を新規の出力先へ生成します。
//
// 引数: CLI input/sha256/output-dir/workers/execute-after-f0。返り値: ありません。失敗は終了1です。
func main() {
	input := flag.String("input", "", "148小参照")
	sha := flag.String("sha256", "", "小参照SHA")
	output := flag.String("output-dir", "", "未作成出力先")
	workers := flag.Int("workers", 1, "互換指定、実効1")
	execute := flag.Bool("execute-after-f0", false, "Root F0後の明示実行")
	flag.Parse()
	fail := func(err error) { fmt.Fprintln(os.Stderr, err); os.Exit(1) }
	if !*execute || *input == "" || *output == "" || flag.NArg() != 0 {
		fail(fmt.Errorf("F0後明示と全引数が必要"))
	}
	if _, err := os.Stat(*output); !os.IsNotExist(err) {
		fail(fmt.Errorf("出力先は未作成だけ許可"))
	}
	ref, err := source.Load(*input, *sha)
	if err != nil {
		fail(err)
	}
	generated, err := source.Generate(ref, *workers, true)
	if err != nil {
		fail(err)
	}
	if _, err = source.Load(*input, *sha); err != nil {
		fail(err)
	}
	if err = source.Write(*output, *sha, generated); err != nil {
		fail(err)
	}
	fmt.Printf("148母集団生成成功 q0=%d eligible=%d filled_event=%d unique_case=%d。選択取引数は未定義\n", generated.Counts["q0_ledger"], generated.Counts["eligible_q0"], generated.Counts["taken_events"], generated.Counts["all_unique_cases"])
}
