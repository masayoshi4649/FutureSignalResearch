package entrypopulation148

import (
	"bytes"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"testing"
)

// parentFixture は自然Sourceを使わずgzipと両SHAを作ります。
//
// 引数: t(*testing.T)、body([]byte)。返り値: ParentRefです。
func parentFixture(t *testing.T, body []byte) ParentRef {
	t.Helper()
	var b bytes.Buffer
	gz := gzip.NewWriter(&b)
	if _, err := gz.Write(body); err != nil {
		t.Fatal(err)
	}
	if err := gz.Close(); err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(t.TempDir(), "人工親.json.gz")
	if err := os.WriteFile(path, b.Bytes(), 0600); err != nil {
		t.Fatal(err)
	}
	p, d := sha256.Sum256(b.Bytes()), sha256.Sum256(body)
	return ParentRef{Path: path, Bytes: int64(b.Len()), SHA256: hex.EncodeToString(p[:]), DecodedSHA256: hex.EncodeToString(d[:])}
}

// Test148ParentSceneAndBothHashes は場順/後置top/解凍ファイル未生成を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test148ParentSceneAndBothHashes(t *testing.T) {
	body := []byte(`{"trial":147,"scenes":[{"session":"甲"},{"session":"乙"}],"summary":{"件数":2}}`)
	r := parentFixture(t, body)
	ids := []string{}
	out, err := ReadParent(r, func(raw json.RawMessage) error {
		var s struct {
			Session string `json:"session"`
		}
		if err := json.Unmarshal(raw, &s); err != nil {
			return err
		}
		ids = append(ids, s.Session)
		return nil
	})
	if err != nil || out.Scenes != 2 || out.DecodedBytes != int64(len(body)) || len(ids) != 2 || ids[1] != "乙" {
		t.Fatal(out, ids, err)
	}
	files, err := os.ReadDir(filepath.Dir(r.Path))
	if err != nil || len(files) != 1 {
		t.Fatal("解凍副本を生成", files, err)
	}
}

// Test148ParentRejectsWrongSHAAndStructure は自然I/Oなしで不整合を拒否します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test148ParentRejectsWrongSHAAndStructure(t *testing.T) {
	for _, body := range []string{`{"scenes":[],"scenes":[]}`, `{"scenes":[1]}`, `{"scenes":[]}{}`, `{"other":1}`} {
		r := parentFixture(t, []byte(body))
		if _, err := ReadParent(r, func(json.RawMessage) error { return nil }); err == nil {
			t.Fatal("不正JSONを受理", body)
		}
	}
	r := parentFixture(t, []byte(`{"scenes":[]}`))
	r.DecodedSHA256 = string(bytes.Repeat([]byte{'0'}, 64))
	if _, err := ReadParent(r, func(json.RawMessage) error { return nil }); err == nil {
		t.Fatal("解凍SHA差を受理")
	}
	r.SHA256 = "不正"
	r.Path = "存在しない"
	if _, err := ReadParent(r, func(json.RawMessage) error { return nil }); err == nil {
		t.Fatal("不正参照受理")
	}
}

// Test148ParentVisitFailureIsNotSuccess は部分callbackを正式成功へ昇格させません。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test148ParentVisitFailureIsNotSuccess(t *testing.T) {
	r := parentFixture(t, []byte(`{"scenes":[{},{}]}`))
	want := errors.New("人工途中停止")
	if _, err := ReadParent(r, func(json.RawMessage) error { return want }); !errors.Is(err, want) {
		t.Fatal(err)
	}
}
