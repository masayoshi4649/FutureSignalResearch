package entrypopulation148

import (
	"bufio"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"io"
	"os"
	"reflect"
)

type SceneEvidence struct {
	Success         bool             `json:"success"`
	Session         string           `json:"session"`
	Contract        string           `json:"contract"`
	Start           float64          `json:"start"`
	End             float64          `json:"end"`
	EntryLimit      float64          `json:"entry_limit"`
	Raw             FileRef          `json:"raw"`
	ActualSHA256    string           `json:"actual_sha256"`
	ExpectedQuality *Counts          `json:"expected_quality"`
	Quality         Counts           `json:"quality"`
	StatBefore      map[string]int64 `json:"stat_before"`
	StatAfter       map[string]int64 `json:"stat_after"`
	RawPasses       int              `json:"raw_passes"`
	ParentBars      int              `json:"parent_bars"`
	WitnessGroups   int              `json:"witness_groups"`
	LedgerRows      int              `json:"ledger_rows"`
	Eligible        int              `json:"eligible"`
	TakenEvents     int              `json:"taken_events"`
	Statuses        map[string]int   `json:"statuses"`
	BBWindows       []BBWindow       `json:"bb_windows"`
}

type publicationOrigin struct {
	Session, Contract string
	SceneIndex        int
	Ref               rules.Ref
}

// validateLineage はBB20の元場/限月と配送の因果を当場indexへ混同せず確認します。
//
// 引数: window(BBWindow)、at(Quote)、scene(Scene)、sceneIndex(int)、origins(map[string]publicationOrigin)。返り値: errorです。
func validateLineage(window BBWindow, at Quote, scene Scene, sceneIndex int, origins map[string]publicationOrigin) error {
	if window.Bands.Count != len(window.Refs) || len(window.Refs) > 20 || len(window.Refs) == 0 || window.Refs[len(window.Refs)-1].ID != window.ID {
		return fmt.Errorf("BB窓ref又はcount差")
	}
	for i, r := range window.Refs {
		o, ok := origins[r.ID]
		if !ok || o.Ref != r || o.Contract != scene.Contract || o.SceneIndex > sceneIndex || r.End > r.Delivered.Time || r.Delivered.Time > at.Time {
			return fmt.Errorf("BB元場/限月/知得因果差")
		}
		if o.Session == scene.Session && (r.Delivered.Index > int(at.Index) || r.Delivered.Line > int(at.SourceLine)) {
			return fmt.Errorf("当場BB refが未来")
		}
		if i > 0 {
			prior := window.Refs[i-1]
			if r.End <= prior.End || r.Delivered.Time < prior.Delivered.Time {
				return fmt.Errorf("BB元配送順差")
			}
		}
	}
	return nil
}

// originIndex は固定公表を由来だけの参照表へ一度登録します。
//
// 引数: scenes([]Scene)。返り値: map[string]publicationOrigin/errorです。
func originIndex(scenes []Scene) (map[string]publicationOrigin, error) {
	out := map[string]publicationOrigin{}
	for i, s := range scenes {
		for _, p := range s.Publications {
			f := p.Frame.Frame
			r := rules.Ref{ID: f.ID, Width: f.Width, End: f.End, Delivered: p.Stamp}
			if _, exists := out[f.ID]; exists {
				return nil, fmt.Errorf("背景ID重複")
			}
			out[f.ID] = publicationOrigin{Session: s.Session, Contract: s.Contract, SceneIndex: i, Ref: r}
		}
	}
	return out, nil
}

// scan は全Rawを一回だけ採用し親q0 Quoteと最新1分を各原行で照合します。
//
// 引数: scene(Scene)、parent(ParentScene)、bank(*rules.Bank)、cache(*Publications)、sceneIndex(int)、origins(map)、compute(FeatureComputer)。返り値: *Population/SceneEvidence/errorです。
func scan(scene Scene, parent ParentScene, bank *rules.Bank, cache *Publications, sceneIndex int, origins map[string]publicationOrigin, compute FeatureComputer) (*Population, SceneEvidence, error) {
	out := SceneEvidence{Session: scene.Session, Contract: scene.Contract, Start: scene.Start, End: scene.End, Raw: scene.Raw, ExpectedQuality: scene.ExpectedQuality, RawPasses: 1, Statuses: map[string]int{}, BBWindows: []BBWindow{}}
	population := NewPopulation(scene, compute)
	out.EntryLimit = population.limit()
	if err := bank.StartSession(scene.Session, scene.Contract); err != nil {
		return nil, out, err
	}
	if err := cache.StartSession(scene.Session, scene.Contract); err != nil {
		return nil, out, err
	}
	f, err := os.Open(scene.Raw.Path)
	if err != nil {
		return nil, out, err
	}
	defer f.Close()
	before, err := f.Stat()
	if err != nil {
		return nil, out, err
	}
	out.StatBefore = stat(before)
	if scene.Raw.Bytes > 0 && before.Size() != scene.Raw.Bytes || !reflect.DeepEqual(out.StatBefore, parent.StatBefore) {
		return nil, out, fmt.Errorf("親Raw stat差")
	}
	hash := sha256.New()
	buffer := bufio.NewReader(io.TeeReader(f, hash))
	magic, err := buffer.Peek(2)
	if err != nil {
		return nil, out, err
	}
	var input io.Reader = buffer
	if magic[0] == 0x1f && magic[1] == 0x8b {
		gz, e := gzip.NewReader(buffer)
		if e != nil {
			return nil, out, e
		}
		defer gz.Close()
		input = gz
	}
	scanner := bufio.NewScanner(input)
	scanner.Buffer(make([]byte, 65536), 8<<20)
	counts := Counts{}
	contracts := map[string]bool{}
	previous, index, pi, bi := scene.Start, int64(0), 0, 0
	for scanner.Scan() {
		counts.Lines++
		q, _, next, e := decodeRow(scanner.Bytes(), counts.Lines, index, scene, previous, &counts, contracts)
		if e != nil {
			return nil, out, e
		}
		previous = next
		if q == nil {
			continue
		}
		for pi < len(scene.Publications) && scene.Publications[pi].Stamp.Index <= int(q.Index) {
			p := scene.Publications[pi]
			if p.Stamp.Index != int(q.Index) || p.Stamp.Time != q.Time || p.Stamp.Line != int(q.SourceLine) {
				return nil, out, fmt.Errorf("背景配送witness差")
			}
			if e = bank.Add(p); e != nil {
				return nil, out, e
			}
			if e = cache.Record(p); e != nil {
				return nil, out, e
			}
			pi++
		}
		snapshot, e := bank.Current(rq(*q))
		if e != nil {
			return nil, out, e
		}
		batch := []ParentKnownBar{}
		for bi < len(parent.Bars) && parent.Bars[bi].Bar.Stamp.Index <= int(q.Index) {
			b := parent.Bars[bi]
			if b.Bar.Stamp.Index != int(q.Index) || b.Context.At != *q {
				return nil, out, fmt.Errorf("親1分初知Quote witness差")
			}
			batch = append(batch, b)
			bi++
		}
		if len(batch) > 0 {
			latest := batch[len(batch)-1]
			if latest.Context.BBWindowID != "" {
				window, ok := cache.Window(latest.Context.BBWindowID)
				if !ok || window.Bands != snapshot.BB15 || latest.Context.BB15 != snapshot.BB15 {
					return nil, out, fmt.Errorf("q0 BB正本/Bank/親Context差")
				}
				if e = validateLineage(window, *q, scene, sceneIndex, origins); e != nil {
					return nil, out, e
				}
			}
			out.WitnessGroups++
		}
		if e = population.Step(snapshot, *q, batch); e != nil {
			return nil, out, e
		}
		index++
	}
	if err = scanner.Err(); err != nil {
		return nil, out, err
	}
	if _, err = io.Copy(io.Discard, buffer); err != nil {
		return nil, out, err
	}
	out.ActualSHA256 = hex.EncodeToString(hash.Sum(nil))
	after, err := f.Stat()
	if err != nil {
		return nil, out, err
	}
	pathAfter, err := os.Stat(scene.Raw.Path)
	if err != nil {
		return nil, out, err
	}
	out.StatAfter = stat(after)
	out.Quality = counts
	if out.ActualSHA256 != scene.Raw.SHA256 || !os.SameFile(before, pathAfter) || !reflect.DeepEqual(out.StatBefore, out.StatAfter) || before.Size() != pathAfter.Size() || !before.ModTime().Equal(pathAfter.ModTime()) || counts != *scene.ExpectedQuality || index != scene.ExpectedAccepted || len(contracts) != 1 || !contracts[scene.Contract] || pi != len(scene.Publications) || bi != len(parent.Bars) {
		return nil, out, fmt.Errorf("148全RawのSHA/stat/品質/限月/公表/親足数差")
	}
	population.Finish()
	out.ParentBars = len(parent.Bars)
	out.LedgerRows = len(population.Ledger)
	out.Eligible = len(population.Features)
	out.TakenEvents = len(population.Taken)
	for _, a := range population.Acquisitions {
		out.Statuses[a.Status]++
	}
	out.BBWindows = cache.Windows()
	out.Success = true
	return population, out, nil
}
