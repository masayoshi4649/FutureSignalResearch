# 148 全1分知得の研究母集団

仕様 `work/148_全1分知得の入口母集団を固定する採用仕様.md` の準備実装である。広い母集団を全件取引するStrategy、売買選択、ML、70%達成ではない。自然実行はRootのF0固定後だけ。旧147 Source/旧145の全87/118Bank/原板/CSVは不変更で、追加2場は対象外。

## 処理と部品分担

1. 共有147gzipをscene単位の最小型へ読み、全gzip/decoded SHA・CRC・前後statが成功してからRaw処理を始める。decoded 450MBの副本は作らない。Events/Checks/Groupsによる間引きをせず、当場の全barsを使う。
2. 固定122の背景と親Sourceの場/限月/品質を一致検査する。各Rawを147decoderのpackage差以外同体で一走査し、全背景配送→同Raw全親1分更新→既pendingのL/TTL/最新品質/正常q1→新q0/Xの順にする。
3. q0は最新足だけで出生適格を決め、未知slotは詰めない。適格q0にだけ買/売100列をそれぞれ計算し、未取得/取消になっても保持する。q1や旧C1表を特徴APIへ渡さない。
4. 全q0/X/取得判定が終了した後にだけ、旧87の全JSONを純case builderへ渡す。mtime_ns等をfloat64へ丸めず、unknownキー/origins/既存entriesを深いcopyで保持する。
5. 同q1はC1優先、C1外は出生index→line→ID順でcanonicalを決め、格納原側を+1にする。買/売streamの対応を明示し、event数をcase数へ足さない。

作者はSource/親gzip/状態/入出力がsettings119、純case_builder.go/testがreview131、純features148がarchive130である。各作者を自身の部品の独立検査担当とはしない。Rootが意味ある境界と独立確認を分担する。

背景BB20正本は147純cacheのpackage差コピーで、数値と元20refを一度だけ保存する。当場3最新だけをSnapshot.Refsへ渡し、cross-sessionの元場/限月/End/配送Timeを別の入力公表indexで検査する。cross-session refsのindex/lineを当場indexへ比較しない。短期数値の助走/3分/新strategyは持たない。

## 入出力API

`Load(path,sha string) (InputReference,error)` は小参照を検証する。小参照はtrial148、parent_source（物理gzip SHA/bytesとdecoded SHA）、background122、old_fixed/old_metadata（各gzip+decoded SHA）だけ。`Generate(ref,workers,all73)` は自然時all73=true・実効1で処理し、`Write(outputDir,inputSHA,generated)` は成功後だけ未作成先へ書く。

Sourceのq0/pendingは `NewPopulation(scene, compute)` と `Step(snapshot,q,batch)` の純時間順状態である。旧C1・labelを受け取る引数はない。`Finish` はEOFを未来気配へ置換せず、未取得理由を保持する。

純特徴は `features148.Compute(Input{Q0,Snapshot,Minutes})`、純builderは `BuildCases(oldFixed,oldMeta json.RawMessage,taken []TakenEvent)`。旧C1は後者だけへ渡る。builderのFixed返却bytesは再Marshalせずそのまま保存し、metadataのfixed_input_sha256と一致させる。

## 保存契約

全ファイルの共通topはsuccess/trial148/sessions/input_sha256/parent_source_sha256（解凍Source）/parent_gzip_sha256/background_sha256/catalog_sha256/counts/statuses。selected_trade_count・selected_trade_frequencyはnull、financial_labels_used/strategy_selectedはfalse。

- `出生台帳.json`: `rows`は不適格含む全q0。event_id/session/contract/q0/fullQuote、latest_bar_ref、直近slot_refs、当Raw全delivered_bar_refs、eligible/reasons/feature_ref/feature_generated。`scenes`に全73のRaw品質・SHA/stat・全親足/台帳/適格/取得数・BB正本。parent_evidenceはgzip/decoded指紋。
- `当時特徴.json`: `rows`はeligible全q0、未取得でも残す。event_id/session/contract/buy{side,x100}/sell/metadata/bb_window_id。列辞書catalogは全体で一度だけ。q1/取得有無/C1flagはない。
- `取得対応.json`: `rows`はeligible全q0。q0/expires/status/q1/terminated_at/reason/case_id/buy_stream/sell_stream。未取得はcase_id=nullで、Xから分離する。
- `固定取得入力.json`: 凍結133互換。旧全87 entriesを不変保持し、新unique q1だけ追加。original_side=+1は格納向きであり予測ではない。
- `入口参照.json`: 旧全JSON entries/unknownフィールド保持。trial148とfixed_input_sha256更新以外の旧値を残し、旧trial/hashはpopulation148へ退避。`population148.cases/event_case_links/counts`に新関係を分離。旧C1未参照caseも保持。
- `生成の確認.json`: 全5ファイルのbytes/SHAと最後の成功確認。途中失敗を成功にしない。

catalog_sha256は100列配列をGo json.MarshalしたbytesのSHAで、特徴ファイル内のcatalog値へbindする。別紙列定義JSON全fileのSHAはF0と準備proofに別に捕捉し、整形/ラッパーが異なる同名指紋を混同しない。

countsはparent_bars/q0_ledger/eligible_q0/ineligible_q0/taken_eventsと、純builderのold_cases/new_unique_cases/all_unique_cases/c1_reused_events/population_unique_q1/extra_events_sharing_q1等。台帳行・買売2配列・取得event・unique case・選択後tradeは別の単位で、データ取得可能な頻度を売買頻度としない。

## 準備と自然実行

```powershell
go test -count=1 -v ./...
go vet ./...
go build -o 全1分母集団生成.exe ./cmd/run
# Root F0/SHA固定後だけ
.\全1分母集団生成.exe --input 入力参照.json --sha256 小参照SHA --output-dir 未作成先 --workers 1 --execute-after-f0
```

自然価格のparse/Raw走査はこの明示実行前に行わない。1m CSVは再読しない。旧C1の金融結果を生成器へ渡さない。148はdataset準備で、全場最低1/概ね1回毎時/70%を選択後streamで評価する課題を残す。
