package entrypopulation148

import (
	"bytes"
	"compress/gzip"
	"encoding/json"
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	features "github.com/masayoshi4649/SessionTradeExecuter/features148"
	"io"
	"os"
	"path/filepath"
)

type Generated struct {
	Input         InputReference
	Parent        ParentEvidence
	Scenes        []SceneEvidence
	Ledger        []*LedgerRow
	Features      []FeatureRecord
	Acquisitions  []*Acquisition
	Taken         []TakenEvent
	Cases         CaseBuild
	Catalog       []features.Column
	CatalogSHA256 string
	Counts        map[string]int
	Statuses      map[string]int
}

const CatalogDefinitionSHA = "c85223fbe1543e5457c28d4391f817534099d1af1d19664035c668ff5fe8a7b4"
const CatalogCompactSHA = "28603f343be9d14f2f19dad4ac824f2b23435af57916595f8aa8a0e1e00ca96c"

// readSmallJSON はbuilder専用の旧87gzipだけを指紋検査して返します。
//
// 引数: ref(ParentRef)。返り値: json.RawMessage/errorです。
func readSmallJSON(ref ParentRef) (json.RawMessage, error) {
	before, err := os.Stat(ref.Path)
	if err != nil {
		return nil, err
	}
	body, err := os.ReadFile(ref.Path)
	if err != nil {
		return nil, err
	}
	if int64(len(body)) != ref.Bytes || digest(body) != ref.SHA256 {
		return nil, fmt.Errorf("旧C1 gzip指紋差")
	}
	gz, err := gzip.NewReader(bytes.NewReader(body))
	if err != nil {
		return nil, err
	}
	decoded, err := io.ReadAll(gz)
	if err != nil {
		return nil, err
	}
	if err = gz.Close(); err != nil {
		return nil, err
	}
	after, err := os.Stat(ref.Path)
	if err != nil {
		return nil, err
	}
	if !os.SameFile(before, after) || before.Size() != after.Size() || !before.ModTime().Equal(after.ModTime()) || digest(decoded) != ref.DecodedSHA256 || !json.Valid(decoded) {
		return nil, fmt.Errorf("旧C1解凍SHA/stat/JSON差")
	}
	return json.RawMessage(decoded), nil
}

// Generate はF0後の共有入力を検査し、旧C1を最後の純builderだけへ渡します。
//
// 引数: input(InputReference)、workers(int)、all73(bool)。返り値: Generated/errorです。
func Generate(input InputReference, workers int, all73 bool) (Generated, error) {
	out := Generated{Input: input, Scenes: []SceneEvidence{}, Ledger: []*LedgerRow{}, Features: []FeatureRecord{}, Acquisitions: []*Acquisition{}, Taken: []TakenEvent{}, Counts: map[string]int{}, Statuses: map[string]int{}}
	if workers < 1 || workers > 16 {
		return out, fmt.Errorf("workers範囲差。実効1")
	}
	scenes, err := readBackground(input.Background, all73)
	if err != nil {
		return out, err
	}
	parents, parentEvidence, err := loadParents(input.ParentSource, scenes)
	if err != nil {
		return out, err
	}
	out.Parent = parentEvidence
	origins, err := originIndex(scenes)
	if err != nil {
		return out, err
	}
	bank, cache := rules.NewBank(), NewPublications()
	out.Catalog = features.Catalog()
	body, err := json.Marshal(out.Catalog)
	if err != nil {
		return out, err
	}
	out.CatalogSHA256 = digest(body)
	if out.CatalogSHA256 != CatalogCompactSHA {
		return out, fmt.Errorf("固定100列compact指紋差")
	}
	for i, s := range scenes {
		p, evidence, e := scan(s, parents[i], bank, cache, i, origins, features.Compute)
		if e != nil {
			return out, e
		}
		parents[i].Bars = nil
		out.Scenes = append(out.Scenes, evidence)
		out.Ledger = append(out.Ledger, p.Ledger...)
		out.Features = append(out.Features, p.Features...)
		out.Acquisitions = append(out.Acquisitions, p.Acquisitions...)
		out.Taken = append(out.Taken, p.Taken...)
		out.Counts["parent_bars"] += evidence.ParentBars
		out.Counts["q0_ledger"] += evidence.LedgerRows
		out.Counts["eligible_q0"] += evidence.Eligible
		out.Counts["taken_events"] += evidence.TakenEvents
		for key, n := range evidence.Statuses {
			out.Statuses[key] += n
		}
		fmt.Fprintf(os.Stderr, "148進捗 session=%s q0累計=%d 適格累計=%d 取得event累計=%d\n", s.Session, out.Counts["q0_ledger"], out.Counts["eligible_q0"], out.Counts["taken_events"])
	}
	// ----------------------------------------
	// q0特徴と全取得判定が凍結した後にだけ、旧87の未来取得をdedupへ読みます。
	oldFixed, err := readSmallJSON(input.OldFixed)
	if err != nil {
		return out, err
	}
	oldMeta, err := readSmallJSON(input.OldMetadata)
	if err != nil {
		return out, err
	}
	out.Cases, err = BuildCases(oldFixed, oldMeta, out.Taken)
	if err != nil {
		return out, err
	}
	links := map[string]CaseLink{}
	for _, link := range out.Cases.Links {
		if _, ok := links[link.EventID]; ok {
			return out, fmt.Errorf("case link重複")
		}
		links[link.EventID] = link
	}
	for _, a := range out.Acquisitions {
		if a.Status != "filled" {
			continue
		}
		link, ok := links[a.EventID]
		if !ok {
			return out, fmt.Errorf("filled eventのcase不足")
		}
		id, buy, sell := link.CaseID, link.BuyStream, link.SellStream
		a.CaseID = &id
		a.BuyStream = &buy
		a.SellStream = &sell
	}
	if len(links) != len(out.Taken) || len(out.Features) != len(out.Acquisitions) {
		return out, fmt.Errorf("q0/X/取得/case分母差")
	}
	for key, n := range out.Cases.Counts {
		out.Counts[key] = n
	}
	out.Counts["ineligible_q0"] = len(out.Ledger) - len(out.Features)
	for _, ref := range []ParentRef{input.ParentSource, input.OldFixed, input.OldMetadata} {
		if err = verifyPhysical(ref.Path, ref.SHA256, ref.Bytes); err != nil {
			return out, err
		}
	}
	if err = verifyPhysical(input.Background.Path, input.Background.SHA256, input.Background.Bytes); err != nil {
		return out, err
	}
	return out, nil
}

// saveJSON は整形JSONを未作成ファイルへ保存します。
//
// 引数: path(string)、value(any)。返り値: bytes/errorです。
func saveJSON(path string, value any) ([]byte, error) {
	body, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		return nil, err
	}
	body = append(body, '\n')
	return body, saveRaw(path, body)
}

// saveRaw は純builderの指紋済みbytesを再Marshalせず書きます。
//
// 引数: path(string)、body([]byte)。返り値: errorです。
func saveRaw(path string, body []byte) error {
	f, err := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if err != nil {
		return err
	}
	if _, err = f.Write(body); err != nil {
		_ = f.Close()
		return err
	}
	return f.Close()
}

// Write は全入力成功後に5成果と最後の成功確認だけを未作成先へ保存します。
//
// 引数: outputDir/inputSHA(string)、out(Generated)。返り値: errorです。
func Write(outputDir, inputSHA string, out Generated) error {
	if _, err := os.Stat(outputDir); !os.IsNotExist(err) {
		return fmt.Errorf("未作成出力先だけ許可")
	}
	if err := os.MkdirAll(outputDir, 0700); err != nil {
		return err
	}
	sessions := []string{}
	for _, s := range out.Scenes {
		sessions = append(sessions, s.Session)
	}
	common := func() map[string]any {
		return map[string]any{"success": true, "trial": 148, "sessions": sessions, "input_sha256": inputSHA, "parent_source_sha256": out.Input.ParentSource.DecodedSHA256, "parent_gzip_sha256": out.Input.ParentSource.SHA256, "background_sha256": out.Input.Background.SHA256, "catalog_sha256": out.CatalogSHA256, "catalog_definition_sha256": CatalogDefinitionSHA, "counts": out.Counts, "statuses": out.Statuses, "selected_trade_count": nil, "selected_trade_frequency": nil, "financial_labels_used": false, "strategy_selected": false}
	}
	ledger := common()
	ledger["rows"] = out.Ledger
	ledger["scenes"] = out.Scenes
	ledger["parent_evidence"] = out.Parent
	x := common()
	x["rows"] = out.Features
	x["catalog"] = out.Catalog
	capture := common()
	capture["rows"] = out.Acquisitions
	proofs := map[string]any{}
	for _, item := range []struct {
		name  string
		value any
	}{{"出生台帳.json", ledger}, {"当時特徴.json", x}, {"取得対応.json", capture}} {
		body, err := saveJSON(filepath.Join(outputDir, item.name), item.value)
		if err != nil {
			return err
		}
		proofs[item.name] = map[string]any{"bytes": len(body), "sha256": digest(body)}
	}
	for _, item := range []struct {
		name string
		body []byte
	}{{"固定取得入力.json", out.Cases.Fixed}, {"入口参照.json", out.Cases.Metadata}} {
		if err := saveRaw(filepath.Join(outputDir, item.name), item.body); err != nil {
			return err
		}
		proofs[item.name] = map[string]any{"bytes": len(item.body), "sha256": digest(item.body)}
	}
	confirmation := common()
	confirmation["files"] = proofs
	confirmation["effective_workers"] = 1
	confirmation["new_raw_passes"] = len(out.Scenes)
	confirmation["decoded_parent_written"] = false
	_, err := saveJSON(filepath.Join(outputDir, "生成の確認.json"), confirmation)
	return err
}
