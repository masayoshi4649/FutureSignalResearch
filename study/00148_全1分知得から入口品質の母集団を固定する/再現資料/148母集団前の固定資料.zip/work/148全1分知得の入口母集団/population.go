package entrypopulation148

import (
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	features "github.com/masayoshi4649/SessionTradeExecuter/features148"
	"math"
)

type FeatureRecord struct {
	EventID    string            `json:"event_id"`
	Session    string            `json:"session"`
	Contract   string            `json:"contract"`
	Buy        features.SideRow  `json:"buy"`
	Sell       features.SideRow  `json:"sell"`
	Metadata   features.Metadata `json:"metadata"`
	BBWindowID string            `json:"bb_window_id"`
}

type FeatureComputer func(features.Input) (features.Pair, error)

type Population struct {
	Scene        Scene
	Ledger       []*LedgerRow
	Features     []FeatureRecord
	Acquisitions []*Acquisition
	Taken        []TakenEvent
	Counts       map[string]int
	slots        []Minute
	latest       *Minute
	nextStart    float64
	seen         map[string]bool
	pending      []*Acquisition
	compute      FeatureComputer
}

// NewPopulation は旧C1・q1・ラベルを受け取らない出生状態を作ります。
//
// 引数: scene(Scene)、compute(FeatureComputer)。返り値: *Populationです。
func NewPopulation(scene Scene, compute FeatureComputer) *Population {
	return &Population{Scene: scene, Ledger: []*LedgerRow{}, Features: []FeatureRecord{}, Acquisitions: []*Acquisition{}, Taken: []TakenEvent{}, Counts: map[string]int{}, slots: []Minute{}, nextStart: scene.Start, seen: map[string]bool{}, pending: []*Acquisition{}, compute: compute}
}

// limit は主H60を残す新規限界です。
//
// 引数: なし。返り値: float64です。
func (p *Population) limit() float64 { return math.Min(p.Scene.ForceClose, p.Scene.End-3900) }

// slotReference は価格数値を重ねず当場の格子と既知性を示します。
//
// 引数: m(Minute)。返り値: SlotRefです。
func slotReference(m Minute) SlotRef {
	return SlotRef{ID: m.ID, Start: m.Start, End: m.End, AvailableAt: m.AvailableAt, Stamp: m.Stamp, PriceKnown: m.PriceKnown, VolumeKnown: m.VolumeKnown, Closed: m.Closed}
}

// featureMinute は同じ配送済みslotを純特徴APIへ写します。
//
// 引数: m(Minute)。返り値: features.Minuteです。
func featureMinute(m Minute) features.Minute {
	return features.Minute{ID: m.ID, Session: m.Session, Contract: m.Contract, Start: m.Start, End: m.End, AvailableAt: m.AvailableAt, Stamp: m.Stamp, OHLC: m.OHLC, Volume: m.Volume, PriceKnown: m.PriceKnown, VolumeKnown: m.VolumeKnown, Closed: m.Closed}
}

// finishAcquisition は最初の終端理由と原行を一度だけ確定します。
//
// 引数: a(*Acquisition)、status/reason(string)、q(Quote)。返り値: ありません。
func finishAcquisition(a *Acquisition, status, reason string, q Quote) {
	z := q
	a.Status = status
	a.Reason = reason
	a.TerminatedAt = &z
}

// Step は全足反映→既pendingの優先順検査→新q0を一度だけ処理します。
//
// 引数: snapshot(rules.Snapshot)、q(Quote)、batch([]ParentKnownBar)。返り値: errorです。
func (p *Population) Step(snapshot rules.Snapshot, q Quote, batch []ParentKnownBar) error {
	if snapshot.SessionID != p.Scene.Session || snapshot.Contract != p.Scene.Contract || snapshot.AsOf != rq(q) {
		return fmt.Errorf("母集団Snapshotと原行scope差")
	}
	delivered := []SlotRef{}
	for _, known := range batch {
		m := known.Bar
		if m.ID == "" || p.seen[m.ID] || m.Session != p.Scene.Session || m.Contract != p.Scene.Contract || m.Width != 60 || m.Start != p.nextStart || m.End != m.Start+60 || m.End > p.Scene.End-300 || m.AvailableAt != m.End+60 || m.AvailableAt > q.Time || known.Context.At != q || m.Stamp.Time != q.Time || m.Stamp.Index != int(q.Index) || m.Stamp.Line != int(q.SourceLine) {
			return fmt.Errorf("親1分の格子/初知witness/原行差")
		}
		if m.PriceKnown && (!finite(m.OHLC.Open, m.OHLC.High, m.OHLC.Low, m.OHLC.Close) || m.OHLC.Low <= 0 || m.OHLC.High < m.OHLC.Low || m.OHLC.Open < m.OHLC.Low || m.OHLC.Open > m.OHLC.High || m.OHLC.Close < m.OHLC.Low || m.OHLC.Close > m.OHLC.High) {
			return fmt.Errorf("親既知1分OHLC不正")
		}
		if m.VolumeKnown && (!finite(m.Volume) || m.Volume < 0) {
			return fmt.Errorf("親既知量不正")
		}
		p.seen[m.ID] = true
		p.nextStart = m.End
		p.Counts["parent_bars"]++
		p.slots = append(p.slots, m)
		if len(p.slots) > 4 {
			p.slots = append([]Minute(nil), p.slots[len(p.slots)-4:]...)
		}
		z := m
		p.latest = &z
		delivered = append(delivered, slotReference(m))
	}
	// ----------------------------------------
	// C1や新q0の存在に関係なく、既pendingをL→TTL→最新品質→正常BBOの順に処理します。
	alive := []*Acquisition{}
	for _, a := range p.pending {
		switch {
		case q.Time >= p.limit():
			finishAcquisition(a, "entry_limit", "entry_limit", q)
		case q.Time >= a.Expires:
			finishAcquisition(a, "expired", "ttl", q)
		case p.latest == nil || !p.latest.PriceKnown || !p.latest.Closed || q.Time >= p.latest.End+120:
			finishAcquisition(a, "quality_lost", "latest_minute_quality", q)
		case q.Index > a.Q0.Index && q.SourceLine > a.Q0.SourceLine && q.Time >= a.Q0.Time+1 && q.QuoteOK && normal(q):
			finishAcquisition(a, "filled", "first_normal_bbo", q)
			z := q
			a.Q1 = &z
			p.Taken = append(p.Taken, TakenEvent{EventID: a.EventID, Session: a.Session, Contract: a.Contract, Born: a.Q0, Entry: q})
		default:
			alive = append(alive, a)
		}
	}
	p.pending = alive
	if len(batch) == 0 {
		return nil
	}
	// ----------------------------------------
	// 同Rawの最後の1分だけを出生台帳へ置き、適格Xを取得結果に関係なく一度作ります。
	m := *p.latest
	eventID := fmt.Sprintf("148/%s/%d/%d", p.Scene.Session, q.Index, q.SourceLine)
	row := &LedgerRow{EventID: eventID, Session: p.Scene.Session, Contract: p.Scene.Contract, Q0: q, LatestBarRef: slotReference(m), SlotRefs: []SlotRef{}, DeliveredBarRefs: delivered, Reasons: []string{}}
	for _, slot := range p.slots {
		row.SlotRefs = append(row.SlotRefs, slotReference(slot))
	}
	if !m.PriceKnown {
		row.Reasons = append(row.Reasons, "price_unknown")
	}
	if !m.Closed {
		row.Reasons = append(row.Reasons, "not_closed")
	}
	if q.Time >= m.End+120 {
		row.Reasons = append(row.Reasons, "stale")
	}
	if q.Time >= p.limit() {
		row.Reasons = append(row.Reasons, "entry_limit")
	}
	row.Eligible = len(row.Reasons) == 0
	p.Ledger = append(p.Ledger, row)
	p.Counts["q0_ledger"]++
	if !row.Eligible {
		return nil
	}
	if p.compute == nil {
		return fmt.Errorf("純特徴計算APIが未接続")
	}
	minutes := []features.Minute{}
	for _, slot := range p.slots {
		minutes = append(minutes, featureMinute(slot))
	}
	pair, err := p.compute(features.Input{Q0: features.Quote{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine), Last: q.Last, Bid: q.Bid, Ask: q.Ask, QuoteOK: q.QuoteOK}, Snapshot: snapshot, Minutes: minutes})
	if err != nil {
		return err
	}
	if pair.Buy.Side != 1 || pair.Sell.Side != -1 {
		return fmt.Errorf("特徴の両側型不一致")
	}
	bbID := ""
	if pub, ok := snapshot.Frames[900]; ok {
		bbID = pub.Frame.Frame.ID
	}
	p.Features = append(p.Features, FeatureRecord{EventID: eventID, Session: p.Scene.Session, Contract: p.Scene.Contract, Buy: pair.Buy, Sell: pair.Sell, Metadata: pair.Metadata, BBWindowID: bbID})
	key := eventID
	row.FeatureRef = &key
	row.FeatureGenerated = true
	p.Counts["eligible"]++
	a := &Acquisition{EventID: eventID, Session: p.Scene.Session, Contract: p.Scene.Contract, Q0: q, Status: "pending", Expires: math.Min(q.Time+30, p.limit())}
	p.Acquisitions = append(p.Acquisitions, a)
	p.pending = append(p.pending, a)
	return nil
}

// Finish はEOFを未来気配で補わず未取得理由として残します。
//
// 引数: なし。返り値: ありません。
func (p *Population) Finish() {
	for _, a := range p.pending {
		a.Status = "eof_unfilled"
		a.Reason = "raw_eof"
	}
	p.pending = nil
}
