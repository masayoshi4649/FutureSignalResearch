package entrypopulation148

import (
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"math"
)

// finite は有限な浮動小数だけを認めます。
//
// 引数: values(...float64)。返り値: boolです。
func finite(values ...float64) bool {
	for _, v := range values {
		if math.IsNaN(v) || math.IsInf(v, 0) {
			return false
		}
	}
	return true
}

// normal は正常BBOを有限・正のBid<Askで判断します。
//
// 引数: q(Quote)。返り値: boolです。
func normal(q Quote) bool { return finite(q.Bid, q.Ask) && q.Bid > 0 && q.Ask > q.Bid }

// rq は同一原行だけを118Bankの問い合わせへ写します。
//
// 引数: q(Quote)。返り値: rules.Quoteです。
func rq(q Quote) rules.Quote {
	return rules.Quote{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine), Last: q.Last}
}
