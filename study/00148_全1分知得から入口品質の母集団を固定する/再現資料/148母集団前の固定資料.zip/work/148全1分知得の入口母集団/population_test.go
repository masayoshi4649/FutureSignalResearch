package entrypopulation148

import (
	"encoding/json"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	features "github.com/masayoshi4649/SessionTradeExecuter/features148"
	"reflect"
	"testing"
)

// qTest は同時計別物理行も区別できる人工Quoteです。
//
// 引数: at(float64)、index(int64)、normalBBO(bool)。返り値: Quoteです。
func qTest(at float64, index int64, normalBBO bool) Quote {
	q := Quote{Clock: "人工", Time: at, Index: index, SourceLine: index + 1, Last: 1000, Bid: 999, Ask: 1001, QuoteOK: normalBBO}
	if !normalBBO {
		q.Bid = 1000
		q.Ask = 1000
	}
	return q
}

// snapTest は背景不足でも出生を落とさない人工Snapshotです。
//
// 引数: p(*Population)、q(Quote)。返り値: rules.Snapshotです。
func snapTest(p *Population, q Quote) rules.Snapshot {
	return rules.Snapshot{SessionID: p.Scene.Session, Contract: p.Scene.Contract, AsOf: rq(q), Frames: map[int]rules.Publication{}}
}

// minuteTest は親の初配送Quoteを持つ一つの人工slotです。
//
// 引数: p(*Population)、start(float64)、q(Quote)、known(bool)。返り値: ParentKnownBarです。
func minuteTest(p *Population, start float64, q Quote, known bool) ParentKnownBar {
	var out ParentKnownBar
	out.Bar = Minute{ID: p.Scene.Session + "/" + fmtNumber(start), Session: p.Scene.Session, Contract: p.Scene.Contract, Width: 60, Start: start, End: start + 60, AvailableAt: start + 120, Stamp: rules.Stamp{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine)}, OHLC: rules.OHLC{Open: 1000, High: 1001, Low: 999, Close: 1000}, PriceKnown: known, Closed: true, VolumeKnown: false}
	out.Context.At = q
	return out
}

// fmtNumber は人工識別だけに数値をJSON表記します。
//
// 引数: value(float64)。返り値: stringです。
func fmtNumber(value float64) string { b, _ := json.Marshal(value); return string(b) }

// populationTest は純特徴呼出回数と両sideを区別する人工状態です。
//
// 引数: calls(*int)。返り値: *Populationです。
func populationTest(calls *int) *Population {
	return NewPopulation(Scene{Session: "人工_Day", Contract: "X", Start: 0, End: 10000, ForceClose: 8000}, func(in features.Input) (features.Pair, error) {
		*calls++
		buy, sell := in.Q0.Ask, in.Q0.Bid
		pair := features.Pair{Buy: features.SideRow{Side: 1}, Sell: features.SideRow{Side: -1}}
		if in.Q0.QuoteOK {
			pair.Buy.X[0] = &buy
			pair.Sell.X[0] = &sell
		}
		return pair, nil
	})
}

// stepTest はSource入力だけで状態を進めます。
//
// 引数: t(*testing.T)、p(*Population)、q(Quote)、batch(...ParentKnownBar)。返り値: ありません。
func stepTest(t *testing.T, p *Population, q Quote, batch ...ParentKnownBar) {
	t.Helper()
	if err := p.Step(snapTest(p, q), q, batch); err != nil {
		t.Fatal(err)
	}
}

// Test148LatestOnlyAndNoFallback は同Raw最新未知を良い過去足へ置き換えません。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test148LatestOnlyAndNoFallback(t *testing.T) {
	calls := 0
	p := populationTest(&calls)
	q := qTest(180, 10, true)
	stepTest(t, p, q, minuteTest(p, 0, q, true), minuteTest(p, 60, q, false))
	if len(p.Ledger) != 1 || p.Ledger[0].LatestBarRef.Start != 60 || p.Ledger[0].Eligible || len(p.Ledger[0].SlotRefs) != 2 || calls != 0 || p.Ledger[0].FeatureRef != nil || len(p.Acquisitions) != 0 {
		t.Fatal(p.Ledger, calls)
	}
	if len(p.Ledger[0].DeliveredBarRefs) != 2 {
		t.Fatal("古い同Raw足の由来欠落")
	}
}

// Test148BadQ0BBOStillEligible はq0不正常を出生除外にせず1秒別行取得します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test148BadQ0BBOStillEligible(t *testing.T) {
	calls := 0
	p := populationTest(&calls)
	q := qTest(120, 10, false)
	stepTest(t, p, q, minuteTest(p, 0, q, true))
	if len(p.Features) != 1 || calls != 1 || !p.Ledger[0].Eligible || p.Features[0].Buy.X[0] != nil {
		t.Fatal(p.Ledger, p.Features)
	}
	stepTest(t, p, qTest(120, 11, true))
	if len(p.Taken) != 0 {
		t.Fatal("同時計を1秒後と誤認")
	}
	stepTest(t, p, qTest(121, 12, true))
	if len(p.Taken) != 1 || p.Acquisitions[0].Status != "filled" || calls != 1 {
		t.Fatal(p.Acquisitions, calls)
	}
}

// Test148IndependentPendingShareQ1 は異なるq0を抑止せず同じq1へ対応させます。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test148IndependentPendingShareQ1(t *testing.T) {
	calls := 0
	p := populationTest(&calls)
	q := qTest(175, 10, false)
	stepTest(t, p, q, minuteTest(p, 0, q, true))
	q = qTest(180, 11, false)
	stepTest(t, p, q, minuteTest(p, 60, q, true))
	stepTest(t, p, qTest(181, 12, true))
	if len(p.Taken) != 2 || calls != 2 || p.Taken[0].Entry != p.Taken[1].Entry || p.Taken[0].EventID == p.Taken[1].EventID {
		t.Fatal(p.Taken)
	}
}

// Test148QualityBeforeBBOAndPriority は最新品質喪失を取得より先に検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test148QualityBeforeBBOAndPriority(t *testing.T) {
	for _, which := range []string{"quality", "ttl", "limit"} {
		calls := 0
		p := populationTest(&calls)
		q := qTest(175, 10, false)
		if which == "limit" {
			p.Scene.ForceClose = 180
		}
		stepTest(t, p, q, minuteTest(p, 0, q, true))
		q = qTest(180, 11, true)
		if which == "ttl" {
			p.Acquisitions[0].Expires = 180
		}
		stepTest(t, p, q, minuteTest(p, 60, q, false))
		want := map[string]string{"quality": "quality_lost", "ttl": "expired", "limit": "entry_limit"}[which]
		if p.Acquisitions[0].Status != want || len(p.Taken) != 0 || calls != 1 {
			t.Fatal(which, p.Acquisitions, calls)
		}
	}
}

// Test148FutureQ1DoesNotChangeX はq1価格/存在を変えてもq0特徴を再計算しません。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test148FutureQ1DoesNotChangeX(t *testing.T) {
	var frozen []byte
	for _, mode := range []string{"cheap", "dear", "none"} {
		calls := 0
		p := populationTest(&calls)
		q := qTest(120, 10, true)
		stepTest(t, p, q, minuteTest(p, 0, q, true))
		before, _ := json.Marshal(p.Features)
		q = qTest(121, 11, true)
		if mode == "cheap" {
			q.Last = 900
			q.Bid = 899
			q.Ask = 901
		}
		if mode == "dear" {
			q.Last = 1100
			q.Bid = 1099
			q.Ask = 1101
		}
		if mode == "none" {
			q.Time = 150
		}
		stepTest(t, p, q)
		after, _ := json.Marshal(p.Features)
		if !reflect.DeepEqual(before, after) || calls != 1 {
			t.Fatal("q1でX変化")
		}
		if frozen == nil {
			frozen = before
		} else if !reflect.DeepEqual(frozen, before) {
			t.Fatal("未来値依存")
		}
	}
}

// Test148UnknownSlotIsNotCompressed は4slotへ未知を詰めず残します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test148UnknownSlotIsNotCompressed(t *testing.T) {
	calls := 0
	p := populationTest(&calls)
	for i := 0; i < 4; i++ {
		q := qTest(float64(i*60+120), int64(i+10), true)
		stepTest(t, p, q, minuteTest(p, float64(i*60), q, i != 1))
	}
	row := p.Ledger[len(p.Ledger)-1]
	if len(row.SlotRefs) != 4 || row.SlotRefs[1].PriceKnown || row.SlotRefs[2].Start != 120 {
		t.Fatal(row)
	}
}
