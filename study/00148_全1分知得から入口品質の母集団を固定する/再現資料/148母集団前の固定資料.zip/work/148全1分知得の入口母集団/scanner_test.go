package entrypopulation148

import (
	"bytes"
	"compress/gzip"
	"encoding/json"
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	features "github.com/masayoshi4649/SessionTradeExecuter/features148"
	"os"
	"path/filepath"
	"testing"
	"time"
)

// rawScene148 は自然価格を使わず親q0と同じ物理原行を人工作成します。
//
// 引数: t(*testing.T)、compressed(bool)。返り値: Scene/ParentSceneです。
func rawScene148(t *testing.T, compressed bool) (Scene, ParentScene) {
	t.Helper()
	var raw bytes.Buffer
	for i, at := range []int64{120, 121, 122} {
		row := map[string]any{"Symbol": "X", "CurrentPriceTime": time.Unix(at, 0).UTC().Format(time.RFC3339Nano), "CurrentPrice": 1000.}
		for j := 1; j <= 10; j++ {
			bid, ask := 999., 1001.
			if i == 0 {
				bid, ask = 1000, 1000
			}
			row[fmt.Sprintf("Buy%d", j)] = map[string]float64{"Price": bid, "Qty": 1}
			row[fmt.Sprintf("Sell%d", j)] = map[string]float64{"Price": ask, "Qty": 1}
		}
		b, err := json.Marshal(row)
		if err != nil {
			t.Fatal(err)
		}
		raw.Write(b)
		raw.WriteByte('\n')
	}
	body := raw.Bytes()
	if compressed {
		var b bytes.Buffer
		gz := gzip.NewWriter(&b)
		_, _ = gz.Write(body)
		_ = gz.Close()
		body = b.Bytes()
	}
	path := filepath.Join(t.TempDir(), "人工Raw")
	if err := os.WriteFile(path, body, 0600); err != nil {
		t.Fatal(err)
	}
	info, err := os.Stat(path)
	if err != nil {
		t.Fatal(err)
	}
	s := Scene{Session: "人工_Day", Contract: "X", Start: 0, End: 10000, ForceClose: 8000, Raw: FileRef{Path: path, SHA256: digest(body)}, ExpectedAccepted: 3, ExpectedQuality: &Counts{Lines: 3, Accepted: 3, Delivered: 3, BadBBO: 1}}
	q := Quote{Clock: "1970-01-01T00:02:00Z", Time: 120, Index: 0, SourceLine: 1, Last: 1000, Bid: 1000, Ask: 1000, QuoteOK: false}
	p := NewPopulation(s, nil)
	bar := minuteTest(p, 0, q, true)
	parent := ParentScene{Success: true, Session: s.Session, Contract: s.Contract, Start: s.Start, End: s.End, ForceClose: s.ForceClose, Raw: s.Raw, ActualSHA256: s.Raw.SHA256, ExpectedAccepted: 3, ExpectedQuality: s.ExpectedQuality, Counts: *s.ExpectedQuality, Quality: *s.ExpectedQuality, RawPasses: 1, StatBefore: stat(info), StatAfter: stat(info), Bars: []ParentKnownBar{bar}}
	return s, parent
}

// Test148RawPassBothEncodings はq0異常BBO/親witness/未知背景と一走査品質を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test148RawPassBothEncodings(t *testing.T) {
	for _, compressed := range []bool{false, true} {
		s, parent := rawScene148(t, compressed)
		p, evidence, err := scan(s, parent, rules.NewBank(), NewPublications(), 0, map[string]publicationOrigin{}, features.Compute)
		if err != nil {
			t.Fatal(err)
		}
		if !evidence.Success || evidence.RawPasses != 1 || evidence.Quality != *s.ExpectedQuality || len(p.Taken) != 1 || len(p.Features) != 1 || p.Taken[0].Entry.Time != 121 {
			t.Fatal(evidence, p, err)
		}
		for i, c := range features.Catalog() {
			if c.Name == "q0_spread_points" && p.Features[0].Buy.X[i] != nil {
				t.Fatal("異常q0のspread既知")
			}
		}
		parent.Bars[0].Context.At.Last = 999
		if _, _, err = scan(s, parent, rules.NewBank(), NewPublications(), 0, map[string]publicationOrigin{}, features.Compute); err == nil {
			t.Fatal("親q0 witness差を受理")
		}
	}
}

// Test148ParentCRCFailure はCRC破損を全入力成功にしません。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test148ParentCRCFailure(t *testing.T) {
	r := parentFixture(t, []byte(`{"scenes":[{}]}`))
	body, err := os.ReadFile(r.Path)
	if err != nil {
		t.Fatal(err)
	}
	body[len(body)-8] ^= 1
	if err = os.WriteFile(r.Path, body, 0600); err != nil {
		t.Fatal(err)
	}
	r.SHA256 = digest(body)
	if _, err = ReadParent(r, func(json.RawMessage) error { return nil }); err == nil {
		t.Fatal("CRC破損を受理")
	}
}

// Test148ArtifactRawFixedBytes はbuilderの固定bytesを再Marshalせず保存します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test148ArtifactRawFixedBytes(t *testing.T) {
	f, m, _ := cbFixture148(t)
	built, err := BuildCases(f, m, nil)
	if err != nil {
		t.Fatal(err)
	}
	out := Generated{Cases: built, Scenes: []SceneEvidence{}, Ledger: []*LedgerRow{}, Features: []FeatureRecord{}, Acquisitions: []*Acquisition{}, Counts: built.Counts, Statuses: map[string]int{}}
	path := filepath.Join(t.TempDir(), "新規")
	if err = Write(path, "人工入力SHA", out); err != nil {
		t.Fatal(err)
	}
	body, err := os.ReadFile(filepath.Join(path, "固定取得入力.json"))
	if err != nil || !bytes.Equal(body, built.Fixed) {
		t.Fatal("固定bytes改変", err)
	}
	if err = Write(path, "人工入力SHA", out); err == nil {
		t.Fatal("既存先を上書き")
	}
}
