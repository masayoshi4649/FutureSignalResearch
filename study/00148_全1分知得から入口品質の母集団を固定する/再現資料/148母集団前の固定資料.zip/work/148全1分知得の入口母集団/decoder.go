package entrypopulation148

import (
	"encoding/json"
	"fmt"
	"time"
)

// decodeRow はSource122の採用規則を本文変更なしで再用します。
//
// 引数: raw([]byte)、line/index(int64)、scene(Scene)、previous(float64)、counts(*Counts)、contracts(map[string]bool)。
// 返り値: *Quote/string/float64/errorは採用行・理由・時計・失敗。
func decodeRow(raw []byte, line, index int64, scene Scene, previous float64, counts *Counts, contracts map[string]bool) (*Quote, string, float64, error) {
	var fields map[string]json.RawMessage
	if err := json.Unmarshal(raw, &fields); err != nil {
		return nil, "", previous, fmt.Errorf("物理%d JSON:%w", line, err)
	}
	var symbol string
	if err := json.Unmarshal(fields["Symbol"], &symbol); err != nil {
		return nil, "", previous, fmt.Errorf("物理%d Symbol:%w", line, err)
	}
	contracts[symbol] = true
	if len(fields["CurrentPriceTime"]) == 0 {
		counts.ClockMissing++
		return nil, "clock_missing", previous, nil
	}
	var clock string
	if err := json.Unmarshal(fields["CurrentPriceTime"], &clock); err != nil {
		return nil, "", previous, fmt.Errorf("物理%d CurrentPriceTime型:%w", line, err)
	}
	at, err := time.Parse(time.RFC3339Nano, clock)
	if err != nil {
		counts.ClockInvalid++
		return nil, "clock_invalid", previous, nil
	}
	stamp := float64(at.UnixNano()) / 1e9
	if !finite(stamp) || stamp < scene.Start || stamp > scene.End {
		counts.Outside++
		return nil, "outside_session", previous, nil
	}
	if stamp < previous {
		counts.Backward++
		return nil, "backward_clock", previous, nil
	}
	var last float64
	if len(fields["CurrentPrice"]) > 0 {
		if err = json.Unmarshal(fields["CurrentPrice"], &last); err != nil {
			return nil, "", previous, fmt.Errorf("物理%d CurrentPrice型/非有限:%w", line, err)
		}
	}
	if !finite(last) {
		counts.LastNonFinite++
		return nil, "last_non_finite", previous, nil
	}
	if last <= 0 {
		counts.LastNonPositive++
		return nil, "last_non_positive", previous, nil
	}
	// ----------------------------------------
	// 最良以外を値として保存しませんが、旧parserと同じ10深度のJSON型を検査します。
	q := Quote{Clock: clock, Time: stamp, Index: index, SourceLine: line, Last: last}
	for i := 1; i <= 10; i++ {
		var buy, sell struct{ Price, Qty float64 }
		if err = json.Unmarshal(fields[fmt.Sprintf("Buy%d", i)], &buy); err != nil {
			return nil, "", previous, fmt.Errorf("物理%d Buy%d:%w", line, i, err)
		}
		if err = json.Unmarshal(fields[fmt.Sprintf("Sell%d", i)], &sell); err != nil {
			return nil, "", previous, fmt.Errorf("物理%d Sell%d:%w", line, i, err)
		}
		if i == 1 {
			q.Bid, q.Ask = buy.Price, sell.Price
		}
	}
	q.QuoteOK = normal(q)
	counts.Accepted++
	if !q.QuoteOK {
		counts.BadBBO++
	}
	if scene.Cutoff > 0 && stamp >= scene.Cutoff {
		counts.CutoffExcluded++
		return nil, "cutoff_excluded", stamp, nil
	}
	counts.Delivered++
	return &q, "", stamp, nil
}
