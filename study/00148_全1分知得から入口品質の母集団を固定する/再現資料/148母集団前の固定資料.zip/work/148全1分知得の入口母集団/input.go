package entrypopulation148

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"reflect"
	"strings"
)

// verifyPhysical は生成終了時にも共有入力bytesの指紋を読み切って照合します。
//
// 引数: path/expected(string)、size(int64)。返り値: errorです。
func verifyPhysical(path, expected string, size int64) error {
	f, err := os.Open(path)
	if err != nil {
		return err
	}
	defer f.Close()
	s, err := f.Stat()
	if err != nil {
		return err
	}
	if s.Size() != size {
		return fmt.Errorf("終端入力サイズ差")
	}
	h := sha256.New()
	if _, err = io.Copy(h, f); err != nil {
		return err
	}
	if hex.EncodeToString(h.Sum(nil)) != expected {
		return fmt.Errorf("生成後の共有入力SHA差")
	}
	return nil
}

const BackgroundSHA = "6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec"
const ParentSHA = "b99c49f06fe7e2306e59733b1cff26e3bb351f64edee220c98bc30b62c016d77"
const ParentDecodedSHA = "d42d25ec0fe41e8358c1227fd71b4377ffa90c96a8cf582f1ee4537ebf455d63"
const OldFixedSHA = "d2becb3b1d6de656a6cc3f04d576d95d99693dfc42efc03582ed04d2be8784e8"
const OldMetadataSHA = "3a3a144c478fa45f85e03ad4b8e4461e420592da24088458c7aa1cb748c8eb8d"

type InputReference struct {
	Trial        int       `json:"trial"`
	ParentSource ParentRef `json:"parent_source"`
	Background   FileRef   `json:"background"`
	OldFixed     ParentRef `json:"old_fixed"`
	OldMetadata  ParentRef `json:"old_metadata"`
}

// digest は指定bytesのSHAを文字列にします。
//
// 引数: body([]byte)。返り値: stringです。
func digest(body []byte) string { h := sha256.Sum256(body); return hex.EncodeToString(h[:]) }

// Load は自然F0後の小参照だけを読み、価格本文をまだ解析しません。
//
// 引数: path/expected(string)。返り値: InputReference/errorです。
func Load(path, expected string) (InputReference, error) {
	var out InputReference
	if !shaFormat(expected) {
		return out, fmt.Errorf("小参照SHA不正")
	}
	body, err := os.ReadFile(path)
	if err != nil {
		return out, err
	}
	if digest(body) != expected {
		return out, fmt.Errorf("小参照SHA差")
	}
	if err = json.Unmarshal(body, &out); err != nil {
		return out, err
	}
	if out.Trial != 148 || out.ParentSource.SHA256 != ParentSHA || out.ParentSource.DecodedSHA256 != ParentDecodedSHA || out.Background.SHA256 != BackgroundSHA || out.OldFixed.DecodedSHA256 != OldFixedSHA || out.OldMetadata.DecodedSHA256 != OldMetadataSHA {
		return out, fmt.Errorf("148固定参照由来差")
	}
	for _, ref := range []ParentRef{out.ParentSource, out.OldFixed, out.OldMetadata} {
		if !shaFormat(ref.SHA256) || !shaFormat(ref.DecodedSHA256) || ref.Bytes <= 0 {
			return out, fmt.Errorf("gzip参照不正")
		}
		s, e := os.Stat(ref.Path)
		if e != nil {
			return out, e
		}
		if s.Size() != ref.Bytes {
			return out, fmt.Errorf("gzip参照サイズ差")
		}
	}
	s, err := os.Stat(out.Background.Path)
	if err != nil {
		return out, err
	}
	if out.Background.Bytes <= 0 || s.Size() != out.Background.Bytes {
		return out, fmt.Errorf("背景参照サイズ差")
	}
	return out, nil
}

// readBackground は固定122の全73と品質・公表順を検査します。
//
// 引数: ref(FileRef)、all73(bool)。返り値: []Scene/errorです。
func readBackground(ref FileRef, all73 bool) ([]Scene, error) {
	body, err := os.ReadFile(ref.Path)
	if err != nil {
		return nil, err
	}
	if int64(len(body)) != ref.Bytes || digest(body) != ref.SHA256 {
		return nil, fmt.Errorf("背景bytes又はSHA差")
	}
	var input struct {
		Trial  int     `json:"trial"`
		Scenes []Scene `json:"scenes"`
	}
	if err = json.Unmarshal(body, &input); err != nil {
		return nil, err
	}
	if input.Trial != 122 {
		return nil, fmt.Errorf("背景trial差")
	}
	if err = Validate(input.Scenes, all73); err != nil {
		return nil, err
	}
	return input.Scenes, nil
}

// Validate は全場を落とさず固定入力の場/品質/公表scopeを確認します。
//
// 引数: scenes([]Scene)、all73(bool)。返り値: errorです。
func Validate(scenes []Scene, all73 bool) error {
	if len(scenes) == 0 || all73 && len(scenes) != 73 {
		return fmt.Errorf("場数差")
	}
	seen := map[string]bool{}
	days, nights, pubs := 0, 0, 0
	for index, s := range scenes {
		if s.Session == "" || s.Contract == "" || seen[s.Session] || !finite(s.Start, s.End, s.ForceClose) || s.End-3900 <= s.Start || s.ForceClose <= s.Start || s.ForceClose > s.End || s.Cutoff != 0 || s.Raw.Path == "" || !shaFormat(s.Raw.SHA256) || s.Raw.Bytes < 0 || s.ExpectedQuality == nil || s.ExpectedAccepted <= 0 {
			return fmt.Errorf("場metadata不正:%s", s.Session)
		}
		q := s.ExpectedQuality
		if q.Accepted != s.ExpectedAccepted || q.Delivered != q.Accepted || q.CutoffExcluded != 0 || q.Lines != q.Accepted+q.ClockMissing+q.ClockInvalid+q.Outside+q.Backward+q.LastNonPositive+q.LastNonFinite || q.BadBBO > q.Accepted {
			return fmt.Errorf("品質算術差")
		}
		if index > 0 && (s.Start < scenes[index-1].End || s.Session <= scenes[index-1].Session) {
			return fmt.Errorf("場順差")
		}
		seen[s.Session] = true
		if strings.HasSuffix(s.Session, "_Day") {
			days++
		}
		if strings.HasSuffix(s.Session, "_Night") {
			nights++
		}
		previous, line := -1, -1
		for _, p := range s.Publications {
			f := p.Frame.Frame
			if f.SessionID != s.Session || f.Contract != s.Contract || p.Stamp.Index < previous || p.Stamp.Line < line || p.Stamp.Index < 0 || int64(p.Stamp.Index) >= s.ExpectedAccepted || p.Stamp.Time < s.Start || p.Stamp.Time > s.End {
				return fmt.Errorf("公表scope又は順序差")
			}
			previous, line = p.Stamp.Index, p.Stamp.Line
			pubs++
		}
	}
	if all73 && (days != 37 || nights != 36 || pubs != 12794) {
		return fmt.Errorf("固定73場/12794公表差")
	}
	return nil
}

// loadParents はgzipを場単位で最小型へ射影し全指紋成功後だけ返します。
//
// 引数: ref(ParentRef)、scenes([]Scene)。返り値: []ParentScene/ParentEvidence/errorです。
func loadParents(ref ParentRef, scenes []Scene) ([]ParentScene, ParentEvidence, error) {
	parents := []ParentScene{}
	evidence, err := ReadParent(ref, func(body json.RawMessage) error {
		var p ParentScene
		if err := json.Unmarshal(body, &p); err != nil {
			return err
		}
		i := len(parents)
		if i >= len(scenes) {
			return fmt.Errorf("親場過多")
		}
		s := scenes[i]
		if !p.Success || p.Session != s.Session || p.Contract != s.Contract || p.Start != s.Start || p.End != s.End || p.ForceClose != s.ForceClose || p.Raw != s.Raw || p.ActualSHA256 != s.Raw.SHA256 || p.ExpectedAccepted != s.ExpectedAccepted || p.ExpectedQuality == nil || !reflect.DeepEqual(p.ExpectedQuality, s.ExpectedQuality) || p.Counts != *s.ExpectedQuality || p.Quality != p.Counts || p.RawPasses != 1 || !reflect.DeepEqual(p.StatBefore, p.StatAfter) {
			return fmt.Errorf("親Sourceと固定122のmetadata/品質差:%s", p.Session)
		}
		parents = append(parents, p)
		return nil
	})
	if err != nil {
		return nil, evidence, err
	}
	if len(parents) != len(scenes) {
		return nil, evidence, fmt.Errorf("親場不足")
	}
	var success, financial, positions bool
	var trial int
	if json.Unmarshal(evidence.Top["success"], &success) != nil || json.Unmarshal(evidence.Top["trial"], &trial) != nil || json.Unmarshal(evidence.Top["financial_labels_used"], &financial) != nil || json.Unmarshal(evidence.Top["source_positions_used"], &positions) != nil || !success || trial != 147 || financial || positions {
		return nil, evidence, fmt.Errorf("親Source top不正")
	}
	return parents, evidence, nil
}
