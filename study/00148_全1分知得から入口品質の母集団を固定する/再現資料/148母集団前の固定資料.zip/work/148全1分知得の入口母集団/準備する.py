"""148母集団の人工・由来・入力小参照を自然実行前に固定する。"""
from pathlib import Path
import hashlib
import json
import subprocess

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
SPEC=ROOT/'work/148_全1分知得の入口母集団を固定する採用仕様.md'
SPEC_SHA='675b1afd79729ce6cd6f4d604337a92d006554d1c7963dcece23afaae4894f36'
FEATURES=ROOT/'work/148全1分候補の当時特徴'
DEFINITION_SHA='c85223fbe1543e5457c28d4391f817534099d1af1d19664035c668ff5fe8a7b4'
COMPACT_SHA='28603f343be9d14f2f19dad4ac824f2b23435af57916595f8aa8a0e1e00ca96c'


def sha(path: Path) -> str:
    """
    機能: コード/小参照のbytes指紋を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def ref(path: Path) -> dict:
    """
    機能: 正式再現用の相対path・サイズ・SHAを束縛する。
    引数: path(Path)。返り値: dict。
    """
    return {'path':str(path.relative_to(ROOT)),'bytes':path.stat().st_size,'sha256':sha(path)}


def main() -> None:
    """
    機能: 自然入力本文を解析せず意味ある人工とbuildで停止証跡を作る。
    引数: なし。返り値: None。
    """
    assert sha(SPEC)==SPEC_SHA and sha(FEATURES/'列定義.json')==DEFINITION_SHA
    inherited=[]
    for name in ['rawtypes.go','decoder.go','publications.go']:
        source=ROOT/'work/147中位位置からの実体回復'/name;target=HERE/name
        assert source.read_bytes().replace(b'package midrecover147',b'package entrypopulation148',1)==target.read_bytes(),name
        inherited.append({'元':ref(source),'新':ref(target),'差分':'package行だけ。旧戦略条件は呼び出さず、decoder/型/公表証拠だけ再用。'})
    origin={'成功':True,'試行':148,'継承':inherited,'作者分担':{'settings119':'親gzip/入力/Raw1pass/出生・独立pending/純特徴接続/出力/CLI',
        'review131':['case_builder.go','case_builder_test.go'],'archive130':'../148全1分候補の当時特徴/の純100列'},
        '独立性':'作者を自己部品の独立検査担当とはしない。Rootが別票で確認。',
        '自然前':'小参照のため共有gzipの物理SHA/サイズだけ取得。解凍Source/旧87/背景本文/Raw/CSV/金融/追加2場を解析していない。'}
    (HERE/'由来.json').write_text(json.dumps(origin,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    own=[*HERE.glob('*.go'),*HERE.glob('cmd/**/*.go'),HERE/'go.mod',HERE/'README.md',HERE/'入力参照.json',HERE/'由来.json',Path(__file__).resolve()]
    features=[*FEATURES.glob('*.go'),FEATURES/'go.mod',FEATURES/'列定義.json',FEATURES/'列定義.md',FEATURES/'停止の確認.json']
    deps=[ROOT/'work/118複数技法の入口条件'/name for name in ['bank.go','types.go','rules.go','go.mod']]
    copied=[ROOT/'work/147中位位置からの実体回復'/name for name in ['rawtypes.go','decoder.go','publications.go']]
    paths=sorted(set(own+features+deps+copied+[SPEC]),key=str);before={str(path):sha(path)for path in paths}
    logs=[]
    for args in [['go','version'],['go','test','-count=1','-v','./...'],['go','vet','./...'],['go','build','-o','全1分母集団生成.exe','./cmd/run']]:
        r=subprocess.run(args,cwd=HERE,capture_output=True,text=True,encoding='utf-8',errors='replace')
        logs.append({'引数':args,'終了コード':r.returncode,'標準出力':r.stdout,'標準エラー':r.stderr});assert r.returncode==0,logs[-1]
    assert before=={str(path):sha(path)for path in paths}
    count=sum(line.startswith('--- PASS:')for line in logs[1]['標準出力'].splitlines());assert count>=17
    result={'成功':True,'試行':148,'編集停止':True,'人工主群数':count,'確認':logs,'全源前後SHA一致':True,'源':[ref(path)for path in paths],
        '実行ファイル':ref(HERE/'全1分母集団生成.exe'),'採用仕様SHA256':SPEC_SHA,'列定義物理SHA256':DEFINITION_SHA,'catalog_compact_sha256':COMPACT_SHA,
        '作者分担':origin['作者分担'],'自然147又は旧C1解凍本文読取':False,'自然Raw_CSV_金融_追加2場読取':False,'自然生成':False,
        '学習又は戦略採用':False,'母集団と最終取引の分離':True,'実効workers':1,
        '証明範囲':'人工/型/因果/品質/CRC/旧87deep-copy/buildまで。自然母集団の件数/性能や取引の70%/1h/min1はまだ未実行。'}
    path=HERE/'準備の確認.json';path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'success':True,'proof_sha256':sha(path),'exe_sha256':sha(HERE/'全1分母集団生成.exe'),'sources':len(paths),'tests':count}))


if __name__=='__main__':
    main()
