package entrypopulation148

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"sort"
)

type casePhysical148 struct {
	session, contract string
	time              float64
	index, line       int64
}

type caseScene148 struct {
	object       map[string]any
	session      string
	contract     string
	start, limit float64
	accepted     int64
	entries      []any
}

type caseStored148 struct {
	id               string
	side             int
	quote            Quote
	legacy           bool
	canonicalEventID string
}

// cbObject148 は数値文字列の精度を保持したままJSON全値を独立decodeします。
//
// 引数: raw(json.RawMessage)。返り値: map[string]any/error。旧未知キーも保持します。
func cbObject148(raw json.RawMessage) (map[string]any, error) {
	d := json.NewDecoder(bytes.NewReader(raw))
	d.UseNumber()
	var value map[string]any
	if err := d.Decode(&value); err != nil || value == nil {
		return nil, fmt.Errorf("case入力はJSON object:%v", err)
	}
	var tail any
	if err := d.Decode(&tail); err != io.EOF {
		return nil, fmt.Errorf("case入力の後続JSON")
	}
	return value, nil
}

// cbMap148 は全JSON値からobjectを取り出します。
//
// 引数: value(any)、name(string)。返り値: map[string]any/error。
func cbMap148(value any, name string) (map[string]any, error) {
	out, ok := value.(map[string]any)
	if !ok || out == nil {
		return nil, fmt.Errorf("%sはobject", name)
	}
	return out, nil
}

// cbSlice148 はnullを空配列へ補完せず配列を取り出します。
//
// 引数: value(any)、name(string)。返り値: []any/error。
func cbSlice148(value any, name string) ([]any, error) {
	out, ok := value.([]any)
	if !ok {
		return nil, fmt.Errorf("%sはarray", name)
	}
	return out, nil
}

// cbString148 は空でない識別文字列を取り出します。
//
// 引数: value(any)、name(string)。返り値: string/error。
func cbString148(value any, name string) (string, error) {
	out, ok := value.(string)
	if !ok || out == "" {
		return "", fmt.Errorf("%sは非空文字列", name)
	}
	return out, nil
}

// cbInt148 は整数識別をfloat64へ経由せず取り出します。
//
// 引数: value(any)、name(string)。返り値: int64/error。
func cbInt148(value any, name string) (int64, error) {
	n, ok := value.(json.Number)
	if !ok {
		return 0, fmt.Errorf("%sはJSON整数", name)
	}
	out, err := n.Int64()
	if err != nil {
		return 0, fmt.Errorf("%sはint64:%w", name, err)
	}
	return out, nil
}

// cbFloat148 は時計など計算対象だけを有限float64へ変換します。
//
// 引数: value(any)、name(string)。返り値: float64/error。未知キーの数値には触れません。
func cbFloat148(value any, name string) (float64, error) {
	n, ok := value.(json.Number)
	if !ok {
		return 0, fmt.Errorf("%sはJSON数値", name)
	}
	out, err := n.Float64()
	if err != nil || math.IsNaN(out) || math.IsInf(out, 0) {
		return 0, fmt.Errorf("%sは有限値", name)
	}
	return out, nil
}

// cbQuote148 は旧Quoteを既知の全8項目で検査し、未知JSON項目は元objectへ残します。
//
// 引数: value(any)。返り値: Quote/error。入力のmapは変更しません。
func cbQuote148(value any) (Quote, error) {
	m, err := cbMap148(value, "旧Quote")
	if err != nil {
		return Quote{}, err
	}
	var q Quote
	if q.Clock, err = cbString148(m["clock"], "Quote.clock"); err != nil {
		return q, err
	}
	for name, ptr := range map[string]*float64{"time": &q.Time, "last": &q.Last, "bid": &q.Bid, "ask": &q.Ask} {
		if *ptr, err = cbFloat148(m[name], "Quote."+name); err != nil {
			return q, err
		}
	}
	if q.Index, err = cbInt148(m["index"], "Quote.index"); err != nil {
		return q, err
	}
	if q.SourceLine, err = cbInt148(m["source_line"], "Quote.source_line"); err != nil {
		return q, err
	}
	var ok bool
	if q.QuoteOK, ok = m["quote_ok"].(bool); !ok {
		return q, fmt.Errorf("Quote.quote_okはbool")
	}
	if err = cbValidQuote148(q, true); err != nil {
		return q, err
	}
	return q, nil
}

// cbValidQuote148 は出生又は取得Quoteの有限値・物理順・正常flagを確認します。
//
// 引数: q(Quote)、entry(bool)は正常取得必須の指定。返り値: error。
func cbValidQuote148(q Quote, entry bool) error {
	for _, x := range []float64{q.Time, q.Last, q.Bid, q.Ask} {
		if math.IsNaN(x) || math.IsInf(x, 0) {
			return fmt.Errorf("Quote既知非有限")
		}
	}
	normal := q.Bid > 0 && q.Ask > 0 && q.Bid < q.Ask
	if q.Clock == "" || q.Last <= 0 || q.Index < 0 || q.SourceLine <= q.Index || q.QuoteOK != normal || (entry && !normal) {
		return fmt.Errorf("Quote識別/正常flag/物理行差")
	}
	return nil
}

// cbKey148 は取得物理キーを文字列の丸め無しで作ります。
//
// 引数: session/contract(string)、q(Quote)。返り値: casePhysical148。
func cbKey148(session, contract string, q Quote) casePhysical148 {
	return casePhysical148{session: session, contract: contract, time: q.Time, index: q.Index, line: q.SourceLine}
}

// cbDigest148 は入力又は返却する正確なbytesへSHA256を付けます。
//
// 引数: raw([]byte)。返り値: string。
func cbDigest148(raw []byte) string {
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

// cbEncode148 は末尾改行を含む返却正本bytesを作ります。
//
// 引数: value(any)。返り値: json.RawMessage/error。呼出側は再Marshalしません。
func cbEncode148(value any) (json.RawMessage, error) {
	raw, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		return nil, err
	}
	return append(raw, '\n'), nil
}

// cbDescriptor148 は旧metadataを転記せずcaseとstreamの対応だけを返します。
//
// 引数: scene(*caseScene148)、stored(*caseStored148)。返り値: map[string]any。
func cbDescriptor148(scene *caseScene148, stored *caseStored148) map[string]any {
	buy, sell := "original", "reverse"
	if stored.side < 0 {
		buy, sell = sell, buy
	}
	legacyID := ""
	if stored.legacy {
		legacyID = stored.id
	}
	return map[string]any{"case_id": stored.id, "session": scene.session, "contract": scene.contract,
		"original_side": stored.side, "c1_reused": stored.legacy, "legacy_entry_id": legacyID,
		"canonical_event_id": stored.canonicalEventID, "buy_stream": buy, "sell_stream": sell}
}

// BuildCases は取得済みeventだけを旧87へ結び、全JSON値を保持して一物理q1一caseにします。
//
// 引数: oldFixed/oldMeta(json.RawMessage)、taken([]TakenEvent)はfilled取得票だけです。
// 返り値: CaseBuild/error。q0生成・特徴・pendingへ旧C1の未来表を渡さず、ファイルも読みません。
func BuildCases(oldFixed, oldMeta json.RawMessage, taken []TakenEvent) (CaseBuild, error) {
	var result CaseBuild
	fixed, err := cbObject148(oldFixed)
	if err != nil {
		return result, err
	}
	meta, err := cbObject148(oldMeta)
	if err != nil {
		return result, err
	}
	if _, exists := meta["population148"]; exists {
		return result, fmt.Errorf("population148の上書き禁止")
	}
	count, err := cbInt148(fixed["expected_entry_count"], "旧取得数")
	if err != nil || count != 87 {
		return result, fmt.Errorf("旧87固定取得数差")
	}
	trial, err := cbInt148(meta["trial"], "旧metadata試行")
	if err != nil || trial != 145 {
		return result, fmt.Errorf("旧metadataは145")
	}
	sceneValues, err := cbSlice148(fixed["scenes"], "旧scenes")
	if err != nil || len(sceneValues) != 73 {
		return result, fmt.Errorf("旧全73場差")
	}
	metaSessions, err := cbSlice148(meta["sessions"], "旧metadata.sessions")
	if err != nil || len(metaSessions) != 73 {
		return result, fmt.Errorf("旧metadata全73場差")
	}
	scenes := map[string]*caseScene148{}
	physical := map[casePhysical148]*caseStored148{}
	byID := map[string]*caseStored148{}
	caseRows := []any{}
	oldCount := 0
	// ----------------------------------------
	// 旧固定JSONはdecodeで作った独立mapの全値を残し、識別と結合だけ確認します。
	for n, value := range sceneValues {
		obj, e := cbMap148(value, "旧scene")
		if e != nil {
			return result, e
		}
		sid, e := cbString148(obj["session"], "旧session")
		if e != nil || metaSessions[n] != sid || scenes[sid] != nil {
			return result, fmt.Errorf("旧場順/重複差")
		}
		contract, e := cbString148(obj["contract"], "旧contract")
		if e != nil {
			return result, e
		}
		start, e := cbFloat148(obj["start"], "旧start")
		if e != nil {
			return result, e
		}
		end, e := cbFloat148(obj["end"], "旧end")
		if e != nil {
			return result, e
		}
		force, e := cbFloat148(obj["force_close"], "旧force_close")
		if e != nil || end <= start || force <= start || force > end || end-3900 <= start {
			return result, fmt.Errorf("旧場時計差")
		}
		accepted, e := cbInt148(obj["expected_accepted"], "旧expected_accepted")
		if e != nil || accepted <= 0 {
			return result, fmt.Errorf("旧採用数差")
		}
		entries, e := cbSlice148(obj["entries"], "旧entries")
		if e != nil {
			return result, e
		}
		sc := &caseScene148{object: obj, session: sid, contract: contract, start: start,
			limit: math.Min(force, end-3900), accepted: accepted, entries: entries}
		scenes[sid] = sc
		for _, entry := range entries {
			em, e := cbMap148(entry, "旧entry")
			if e != nil {
				return result, e
			}
			id, e := cbString148(em["id"], "旧case ID")
			if e != nil || byID[id] != nil {
				return result, fmt.Errorf("旧ID空又は重複")
			}
			side, e := cbInt148(em["side"], "旧case side")
			if e != nil || (side != 1 && side != -1) {
				return result, fmt.Errorf("旧side差")
			}
			q, e := cbQuote148(em["entry"])
			if e != nil || q.Time < start || q.Time >= sc.limit || q.Index >= accepted {
				return result, fmt.Errorf("旧取得Quote/場時計差:%s", id)
			}
			key := cbKey148(sid, contract, q)
			if physical[key] != nil {
				return result, fmt.Errorf("旧C1同q1複数caseは禁止")
			}
			stored := &caseStored148{id: id, side: int(side), quote: q, legacy: true}
			physical[key], byID[id] = stored, stored
			caseRows = append(caseRows, cbDescriptor148(sc, stored))
			oldCount++
		}
	}
	metaEntries, err := cbSlice148(meta["entries"], "旧metadata.entries")
	if err != nil || len(metaEntries) != 87 || oldCount != 87 {
		return result, fmt.Errorf("旧87の全件結合数差")
	}
	joined := map[string]bool{}
	for _, value := range metaEntries {
		obj, e := cbMap148(value, "旧metadata entry")
		if e != nil {
			return result, e
		}
		id, e := cbString148(obj["id"], "旧metadata ID")
		if e != nil || byID[id] == nil || joined[id] {
			return result, fmt.Errorf("旧metadata ID結合差")
		}
		sid, e := cbString148(obj["session"], "旧metadata session")
		if e != nil || scenes[sid] == nil || obj["contract"] != scenes[sid].contract {
			return result, fmt.Errorf("旧metadata scope差")
		}
		q, e := cbQuote148(obj["entry_quote"])
		stored := byID[id]
		if e != nil || q != stored.quote || physical[cbKey148(sid, scenes[sid].contract, q)] != stored {
			return result, fmt.Errorf("旧metadata Quote全値差")
		}
		side, e := cbInt148(obj["native_side"], "旧metadata side")
		if e != nil || int(side) != stored.side {
			return result, fmt.Errorf("旧metadata side差")
		}
		joined[id] = true
	}
	// ----------------------------------------
	// 入力sliceは並べ替えず、出生順のcopyからcanonicalと同q1の対応を作ります。
	ordered := append([]TakenEvent(nil), taken...)
	sort.Slice(ordered, func(i, j int) bool {
		a, b := ordered[i], ordered[j]
		if a.Session != b.Session {
			return a.Session < b.Session
		}
		if a.Born.Index != b.Born.Index {
			return a.Born.Index < b.Born.Index
		}
		if a.Born.SourceLine != b.Born.SourceLine {
			return a.Born.SourceLine < b.Born.SourceLine
		}
		return a.EventID < b.EventID
	})
	counts := map[string]int{"old_cases": 87, "taken_events": len(taken), "new_unique_cases": 0,
		"all_unique_cases": 87, "c1_reused_events": 0, "population_unique_q1": 0,
		"extra_events_sharing_q1": 0, "c1_overlapping_unique_q1": 0}
	links := []CaseLink{}
	seenEvents := map[string]bool{}
	seenNewPhysical := map[casePhysical148]bool{}
	for _, event := range ordered {
		sc := scenes[event.Session]
		eventKey := event.Session + "\x00" + event.EventID
		if event.EventID == "" || seenEvents[eventKey] || sc == nil || event.Contract != sc.contract {
			return result, fmt.Errorf("取得event識別/重複/scope差")
		}
		seenEvents[eventKey] = true
		if err = cbValidQuote148(event.Born, false); err != nil {
			return result, err
		}
		if err = cbValidQuote148(event.Entry, true); err != nil {
			return result, err
		}
		b, q := event.Born, event.Entry
		if b.Time < sc.start || b.Time >= sc.limit || b.Index >= sc.accepted || q.Index >= sc.accepted ||
			q.Index <= b.Index || q.SourceLine <= b.SourceLine || q.Time < b.Time+1 ||
			q.Time >= math.Min(b.Time+30, sc.limit) {
			return result, fmt.Errorf("event出生/取得+1秒/TTL/限界差:%s", event.EventID)
		}
		key := cbKey148(event.Session, event.Contract, q)
		stored := physical[key]
		if stored != nil && stored.quote != q {
			return result, fmt.Errorf("同q1のQuote全値差")
		}
		if !seenNewPhysical[key] {
			seenNewPhysical[key] = true
			counts["population_unique_q1"]++
			if stored != nil && stored.legacy {
				counts["c1_overlapping_unique_q1"]++
			}
		}
		if stored == nil {
			id := fmt.Sprintf("148/%s/q1/%d/%d", event.Session, q.Index, q.SourceLine)
			if byID[id] != nil {
				return result, fmt.Errorf("新case ID衝突")
			}
			stored = &caseStored148{id: id, side: 1, quote: q, canonicalEventID: event.EventID}
			physical[key], byID[id] = stored, stored
			sc.entries = append(sc.entries, map[string]any{"id": id, "side": 1, "entry": q})
			sc.object["entries"] = sc.entries
			caseRows = append(caseRows, cbDescriptor148(sc, stored))
			counts["new_unique_cases"]++
			counts["all_unique_cases"]++
		}
		buy, sell := "original", "reverse"
		if stored.side < 0 {
			buy, sell = sell, buy
		}
		links = append(links, CaseLink{EventID: event.EventID, Session: event.Session, Contract: event.Contract,
			CaseID: stored.id, BuyStream: buy, SellStream: sell, C1Reused: stored.legacy,
			CanonicalEventID: stored.canonicalEventID})
		if stored.legacy {
			counts["c1_reused_events"]++
		}
	}
	counts["extra_events_sharing_q1"] = len(taken) - counts["population_unique_q1"]
	fixed["expected_entry_count"] = counts["all_unique_cases"]
	fixedRaw, err := cbEncode148(fixed)
	if err != nil {
		return result, err
	}
	// ----------------------------------------
	// 旧metadata.entriesやoriginsを作り直さず、新結合だけ別namespaceへ追加します。
	population := map[string]any{"cases": caseRows, "event_case_links": links, "counts": counts,
		"parent_metadata_trial": meta["trial"], "old_fixed_sha256": cbDigest148(oldFixed),
		"old_metadata_sha256": cbDigest148(oldMeta), "schema_version": 1,
		"case_unit": "session/contract/取得time/index/source_line", "c1_priority": true,
		"canonical_order": "C1優先、C1外は出生Index→Line→event ID", "selected_trade_count": nil}
	if value, exists := meta["fixed_input_sha256"]; exists {
		population["parent_fixed_input_sha256"] = value
	}
	meta["population148"], meta["trial"] = population, 148
	meta["fixed_input_sha256"] = cbDigest148(fixedRaw)
	metadataRaw, err := cbEncode148(meta)
	if err != nil {
		return result, err
	}
	result = CaseBuild{Fixed: fixedRaw, Metadata: metadataRaw, Links: links, Counts: counts}
	return result, nil
}
