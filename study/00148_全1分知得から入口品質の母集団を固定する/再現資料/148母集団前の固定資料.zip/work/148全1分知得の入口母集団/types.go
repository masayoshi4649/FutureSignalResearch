package entrypopulation148

import (
	"encoding/json"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

type FileRef struct {
	Path   string `json:"path"`
	SHA256 string `json:"sha256"`
	Bytes  int64  `json:"bytes"`
}

type Scene struct {
	Session          string              `json:"session"`
	Contract         string              `json:"contract"`
	Start            float64             `json:"start"`
	End              float64             `json:"end"`
	ForceClose       float64             `json:"force_close"`
	Cutoff           float64             `json:"cutoff"`
	Raw              FileRef             `json:"raw"`
	ExpectedAccepted int64               `json:"expected_accepted"`
	ExpectedQuality  *Counts             `json:"expected_quality"`
	Publications     []rules.Publication `json:"publications"`
}

type Minute struct {
	ID          string      `json:"id"`
	Session     string      `json:"session"`
	Contract    string      `json:"contract"`
	Width       int         `json:"width_seconds"`
	Start       float64     `json:"start"`
	End         float64     `json:"end"`
	AvailableAt float64     `json:"available_at"`
	Stamp       rules.Stamp `json:"stamp"`
	OHLC        rules.OHLC  `json:"ohlc"`
	Volume      float64     `json:"volume"`
	PriceKnown  bool        `json:"price_known"`
	VolumeKnown bool        `json:"volume_known"`
	Closed      bool        `json:"closed"`
	Missing     bool        `json:"missing"`
	CSV         *FileRef    `json:"csv,omitempty"`
	CSVLine     int         `json:"csv_line,omitempty"`
}

type ParentKnownBar struct {
	Bar     Minute `json:"bar"`
	Context struct {
		At         Quote       `json:"at"`
		Refs       []rules.Ref `json:"refs"`
		BBWindowID string      `json:"bb_window_id"`
		BB15       rules.Bands `json:"bb15"`
	} `json:"context"`
}

type ParentScene struct {
	Success          bool             `json:"success"`
	Session          string           `json:"session"`
	Contract         string           `json:"contract"`
	Start            float64          `json:"start"`
	End              float64          `json:"end"`
	ForceClose       float64          `json:"force_close"`
	Raw              FileRef          `json:"raw"`
	ActualSHA256     string           `json:"actual_sha256"`
	ExpectedAccepted int64            `json:"expected_accepted"`
	ExpectedQuality  *Counts          `json:"expected_quality"`
	Counts           Counts           `json:"counts"`
	Quality          Counts           `json:"quality"`
	RawPasses        int              `json:"raw_passes"`
	StatBefore       map[string]int64 `json:"stat_before"`
	StatAfter        map[string]int64 `json:"stat_after"`
	Bars             []ParentKnownBar `json:"bars"`
}

type SlotRef struct {
	ID          string      `json:"id"`
	Start       float64     `json:"start"`
	End         float64     `json:"end"`
	AvailableAt float64     `json:"available_at"`
	Stamp       rules.Stamp `json:"stamp"`
	PriceKnown  bool        `json:"price_known"`
	VolumeKnown bool        `json:"volume_known"`
	Closed      bool        `json:"closed"`
}

type LedgerRow struct {
	EventID          string    `json:"event_id"`
	Session          string    `json:"session"`
	Contract         string    `json:"contract"`
	Q0               Quote     `json:"q0"`
	LatestBarRef     SlotRef   `json:"latest_bar_ref"`
	SlotRefs         []SlotRef `json:"slot_refs"`
	DeliveredBarRefs []SlotRef `json:"delivered_bar_refs"`
	Eligible         bool      `json:"eligible"`
	Reasons          []string  `json:"reasons"`
	FeatureRef       *string   `json:"feature_ref"`
	FeatureGenerated bool      `json:"feature_generated"`
}

// TakenEvent はq1取得済みの非戦略的eventだけを純builderへ渡します。
type TakenEvent struct {
	EventID  string `json:"event_id"`
	Session  string `json:"session"`
	Contract string `json:"contract"`
	Born     Quote  `json:"born"`
	Entry    Quote  `json:"entry"`
}

type CaseLink struct {
	EventID          string `json:"event_id"`
	Session          string `json:"session"`
	Contract         string `json:"contract"`
	CaseID           string `json:"case_id"`
	BuyStream        string `json:"buy_stream"`
	SellStream       string `json:"sell_stream"`
	C1Reused         bool   `json:"c1_reused"`
	CanonicalEventID string `json:"canonical_event_id"`
}

// CaseBuild は旧87全値と新unique q1だけを固定する後段成果です。
type CaseBuild struct {
	Fixed    json.RawMessage `json:"fixed"`
	Metadata json.RawMessage `json:"metadata"`
	Links    []CaseLink      `json:"links"`
	Counts   map[string]int  `json:"counts"`
}

type Acquisition struct {
	EventID      string  `json:"event_id"`
	Session      string  `json:"session"`
	Contract     string  `json:"contract"`
	Q0           Quote   `json:"q0"`
	Status       string  `json:"status"`
	Expires      float64 `json:"expires"`
	Q1           *Quote  `json:"q1"`
	TerminatedAt *Quote  `json:"terminated_at"`
	Reason       string  `json:"reason"`
	CaseID       *string `json:"case_id"`
	BuyStream    *string `json:"buy_stream"`
	SellStream   *string `json:"sell_stream"`
}

type BBWindow struct {
	ID    string      `json:"id"`
	Bands rules.Bands `json:"bands"`
	Refs  []rules.Ref `json:"refs"`
}
