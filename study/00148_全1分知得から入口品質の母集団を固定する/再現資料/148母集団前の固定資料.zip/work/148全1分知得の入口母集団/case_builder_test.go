package entrypopulation148

import (
	"bytes"
	"encoding/json"
	"fmt"
	"math"
	"reflect"
	"testing"
)

// cbFixture148 は原板も自然資料も使わず全73場と旧87全JSON値を作ります。
//
// 引数: t(*testing.T)。返り値: oldFixed/oldMeta(json.RawMessage)、old([]TakenEvent)は旧取得へ結ぶ人工票です。
func cbFixture148(t *testing.T) (json.RawMessage, json.RawMessage, []TakenEvent) {
	t.Helper()
	fixed := map[string]any{"expected_entry_count": 87, "scenes": []any{},
		"future_unknown_top": map[string]any{"mtime_ns": json.Number("1810123456789012345"), "array": []any{nil, false, "原値"}}}
	meta := map[string]any{"success": true, "trial": 145, "sessions": []any{}, "entries": []any{},
		"fixed_input_sha256": "旧固定bytesの指紋", "unknown_meta": json.Number("9007199254740993")}
	old := []TakenEvent{}
	n := 0
	for i := 0; i < 73; i++ {
		sid := fmt.Sprintf("人工場%02d", i)
		start := float64(1000000 + i*30000)
		sc := map[string]any{"session": sid, "contract": "人工同限月", "start": start, "end": start + 20000,
			"force_close": start + 19000, "expected_accepted": 1000000, "entries": []any{},
			"raw":              map[string]any{"path": "人工原板を開かない", "sha256": "人工SHA", "mtime_ns": json.Number("1810123456789012345")},
			"expected_quality": map[string]any{"未定義の旧品質項目": true}}
		count := 1
		if i < 14 {
			count++
		}
		for j := 0; j < count; j++ {
			id := fmt.Sprintf("旧C1/%s/%d", sid, j)
			side := 1
			if n == 0 {
				side = -1
			}
			q := Quote{Clock: "人工価格時計", Time: start + float64(500+j*10), Index: int64(100 + j*10),
				SourceLine: int64(111 + j*10), Last: 100, Bid: 95, Ask: 105, QuoteOK: true}
			raw, e := json.Marshal(q)
			if e != nil {
				t.Fatal(e)
			}
			qo, e := cbObject148(raw)
			if e != nil {
				t.Fatal(e)
			}
			qo["未知Quote項目"] = json.Number("9007199254740993")
			sc["entries"] = append(sc["entries"].([]any), map[string]any{"id": id, "side": side, "entry": qo,
				"未知旧entry項目": []any{json.Number("1810123456789012345"), nil}})
			meta["entries"] = append(meta["entries"].([]any), map[string]any{"id": id, "session": sid, "contract": "人工同限月",
				"native_side": side, "entry_quote": qo, "baseline": n < 81,
				"origins": []any{map[string]any{"id": "保存通知", "未知の元項目": json.Number("1810123456789012345"), "nullable": nil}}})
			born := q
			born.Time -= 2
			born.Index -= 2
			born.SourceLine -= 2
			old = append(old, TakenEvent{EventID: fmt.Sprintf("old-hit-%d", n), Session: sid, Contract: "人工同限月", Born: born, Entry: q})
			n++
		}
		fixed["scenes"] = append(fixed["scenes"].([]any), sc)
		meta["sessions"] = append(meta["sessions"].([]any), sid)
	}
	f, e := cbEncode148(fixed)
	if e != nil {
		t.Fatal(e)
	}
	m, e := cbEncode148(meta)
	if e != nil {
		t.Fatal(e)
	}
	return f, m, old
}

// cbNewTaken148 は1秒条件を満たす新しい人工q1共有票を作ります。
//
// 引数: id(string)、index(int64)は出生順。返り値: TakenEvent。
func cbNewTaken148(id string, index int64) TakenEvent {
	entry := Quote{Clock: "人工価格時計", Time: 1000700, Index: 500, SourceLine: 520,
		Last: 100, Bid: 95, Ask: 105, QuoteOK: true}
	born := entry
	born.Time -= 2
	born.Index = index
	born.SourceLine = index + 11
	return TakenEvent{EventID: id, Session: "人工場00", Contract: "人工同限月", Born: born, Entry: entry}
}

// TestCases148OldAllValues は全87/73と未知キー・大整数・入力非改変を検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestCases148OldAllValues(t *testing.T) {
	f, m, _ := cbFixture148(t)
	fBefore, mBefore := append([]byte(nil), f...), append([]byte(nil), m...)
	result, err := BuildCases(f, m, nil)
	if err != nil {
		t.Fatal(err)
	}
	before, _ := cbObject148(f)
	after, _ := cbObject148(result.Fixed)
	if !reflect.DeepEqual(before, after) || result.Counts["all_unique_cases"] != 87 || len(result.Links) != 0 {
		t.Fatal("旧固定全値/全73/87保持差")
	}
	oldMeta, _ := cbObject148(m)
	newMeta, _ := cbObject148(result.Metadata)
	if !reflect.DeepEqual(oldMeta["entries"], newMeta["entries"]) || oldMeta["unknown_meta"] != newMeta["unknown_meta"] {
		t.Fatal("旧metadata全entries/未知大整数を改変")
	}
	pop := newMeta["population148"].(map[string]any)
	if pop["parent_metadata_trial"] != json.Number("145") || pop["selected_trade_count"] != nil ||
		newMeta["fixed_input_sha256"] != cbDigest148(result.Fixed) || pop["old_fixed_sha256"] != cbDigest148(f) {
		t.Fatal("正確bytesSHA/元trial/null選択取引差")
	}
	if !bytes.Equal(f, fBefore) || !bytes.Equal(m, mBefore) {
		t.Fatal("入力rawを変更")
	}
}

// TestCases148SharedAndC1Sides は同q1共有・C1売買対応・canonicalと再現を検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestCases148SharedAndC1Sides(t *testing.T) {
	f, m, old := cbFixture148(t)
	early, late := cbNewTaken148("早い出生", 490), cbNewTaken148("遅い出生", 491)
	early.Born.Bid, early.Born.Ask, early.Born.QuoteOK = 0, 0, false
	taken := []TakenEvent{late, old[1], early, old[0]}
	before := append([]TakenEvent(nil), taken...)
	result, err := BuildCases(f, m, taken)
	if err != nil {
		t.Fatal(err)
	}
	expect := map[string]int{"old_cases": 87, "taken_events": 4, "new_unique_cases": 1, "all_unique_cases": 88,
		"c1_reused_events": 2, "population_unique_q1": 3, "extra_events_sharing_q1": 1, "c1_overlapping_unique_q1": 2}
	if !reflect.DeepEqual(result.Counts, expect) || !reflect.DeepEqual(taken, before) {
		t.Fatal("件数又は入力順を変更", result.Counts)
	}
	links := map[string]CaseLink{}
	for _, link := range result.Links {
		links[link.EventID] = link
	}
	if links[old[0].EventID].BuyStream != "reverse" || links[old[0].EventID].SellStream != "original" ||
		links[old[1].EventID].BuyStream != "original" || !links[old[1].EventID].C1Reused ||
		links[old[0].EventID].CanonicalEventID != "" {
		t.Fatal("C1格納原向きと買売ラベルを混同")
	}
	if links[early.EventID].CaseID != links[late.EventID].CaseID || links[early.EventID].CanonicalEventID != early.EventID ||
		links[early.EventID].BuyStream != "original" || links[early.EventID].C1Reused {
		t.Fatal("新caseのcanonical/共有/格納買方向差")
	}
	reverse := []TakenEvent{old[0], early, old[1], late}
	repeated, err := BuildCases(f, m, reverse)
	if err != nil || !bytes.Equal(result.Fixed, repeated.Fixed) || !bytes.Equal(result.Metadata, repeated.Metadata) {
		t.Fatal("入力列順が同体出力へ影響", err)
	}
	bf, _ := cbObject148(f)
	af, _ := cbObject148(result.Fixed)
	bs, as := bf["scenes"].([]any), af["scenes"].([]any)
	for i := range bs {
		oldScene, newScene := bs[i].(map[string]any), as[i].(map[string]any)
		oldEntries, newEntries := oldScene["entries"].([]any), newScene["entries"].([]any)
		if !reflect.DeepEqual(oldEntries, newEntries[:len(oldEntries)]) {
			t.Fatal("旧87を順も含めて改変")
		}
	}
}

// TestCases148CanonicalIDTie は同出生Index/Lineの最後のID順を検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestCases148CanonicalIDTie(t *testing.T) {
	f, m, _ := cbFixture148(t)
	a, z := cbNewTaken148("A", 490), cbNewTaken148("Z", 490)
	r, err := BuildCases(f, m, []TakenEvent{z, a})
	if err != nil || len(r.Links) != 2 || r.Links[0].CanonicalEventID != "A" || r.Links[1].CanonicalEventID != "A" {
		t.Fatal("出生Index/Line/ID順差", err)
	}
}

// TestCases148ClockAndIdentityGuards は取得時計・scope・同原行全値を人工で拒否します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestCases148ClockAndIdentityGuards(t *testing.T) {
	tests := []struct {
		name   string
		mutate func(*TakenEvent)
	}{
		{"TTL等号", func(e *TakenEvent) { e.Born.Time = e.Entry.Time - 30 }},
		{"1秒未満", func(e *TakenEvent) { e.Born.Time = e.Entry.Time - 0.5 }},
		{"同Index", func(e *TakenEvent) { e.Born.Index = e.Entry.Index }},
		{"同物理Line", func(e *TakenEvent) { e.Born.SourceLine = e.Entry.SourceLine }},
		{"正常flag不整合", func(e *TakenEvent) { e.Entry.QuoteOK = false }},
		{"未知場", func(e *TakenEvent) { e.Session = "存在しない場" }},
		{"異限月", func(e *TakenEvent) { e.Contract = "異限月" }},
		{"出生非有限", func(e *TakenEvent) { e.Born.Last = math.Inf(1) }},
		{"限界等号", func(e *TakenEvent) { e.Entry.Time = 1016100; e.Born.Time = 1016098 }},
		{"採用Index外", func(e *TakenEvent) { e.Entry.Index = 1000000; e.Entry.SourceLine = 1000010 }},
		{"出生場外", func(e *TakenEvent) { e.Born.Time = 999999 }},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			f, m, _ := cbFixture148(t)
			e := cbNewTaken148("人工", 490)
			tc.mutate(&e)
			if _, err := BuildCases(f, m, []TakenEvent{e}); err == nil {
				t.Fatal("不適格を受理")
			}
		})
	}
	f, m, old := cbFixture148(t)
	if _, err := BuildCases(f, m, []TakenEvent{old[0], old[0]}); err == nil {
		t.Fatal("同event重複")
	}
	old[0].Entry.Bid--
	if _, err := BuildCases(f, m, []TakenEvent{old[0]}); err == nil {
		t.Fatal("同q1時点で異なるQuote")
	}
}

// TestCases148OldSchemaGuards は旧87/73とmetadata全件結合の破損を拒否します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestCases148OldSchemaGuards(t *testing.T) {
	f, m, _ := cbFixture148(t)
	if _, err := BuildCases(append(f, []byte("{}")...), m, nil); err == nil {
		t.Fatal("後続JSONを受理")
	}
	for _, name := range []string{"87不足", "73不足", "metadata副向き", "metadataQuote", "既population"} {
		t.Run(name, func(t *testing.T) {
			fo, _ := cbObject148(f)
			mo, _ := cbObject148(m)
			switch name {
			case "87不足":
				fo["expected_entry_count"] = 86
			case "73不足":
				fo["scenes"] = fo["scenes"].([]any)[:72]
			case "metadata副向き":
				mo["entries"].([]any)[0].(map[string]any)["native_side"] = 1
			case "metadataQuote":
				mo["entries"].([]any)[0].(map[string]any)["entry_quote"].(map[string]any)["last"] = 101
			case "既population":
				mo["population148"] = map[string]any{}
			}
			ff, _ := cbEncode148(fo)
			mm, _ := cbEncode148(mo)
			if _, err := BuildCases(ff, mm, nil); err == nil {
				t.Fatal("旧対照破損を受理")
			}
		})
	}
}
