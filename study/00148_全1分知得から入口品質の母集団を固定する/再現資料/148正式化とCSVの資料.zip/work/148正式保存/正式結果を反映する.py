"""148の保存済み数値を正式文書へ写し、条件prefixと513セルは保持する。"""
from pathlib import Path
import gzip
import json
import re
from 保存部品 import ROOT, FORMAL, file_sha, json_bytes


def money(value):
    """円の整数を表示する。

    引数: value(int|None)。返り値: strはnull又は桁区切り。
    """
    return 'null' if value is None else f'{value:,}'


def stats_table(summary, parts, policies):
    """正本のH60±125数値だけをMarkdown表へ写す。

    引数: summary(dict)、parts/policies(list[str])。返り値: str。
    """
    lines = ['|区分・政策|件数|順/逆/未/不足|到達済み先着率|利益円 C5|損失円 C5|差引円 C5|金額既知/未知|',
             '|---|---:|---|---:|---:|---:|---:|---|']
    labels = {'all': '全73場', 'train': '前48場・既使用', 'validation': '後25場・既使用'}
    for part in parts:
        for policy in policies:
            row = summary['集計'][part][policy]['BBO']['3600']['125']
            rate = 'null' if row['resolved_rate'] is None else f"{row['resolved_rate'] * 100:.2f}%"
            lines.append(f"|{labels[part]} {policy}|{row['entries']:,}|{row['forward']:,}/{row['adverse']:,}/{row['neither']:,}/{row['censored']:,}|{rate}|{money(row['ifd_net5_profit'])}|{money(row['ifd_net5_loss'])}|{money(row['ifd_net5_sum'])}|{row['ifd_known']:,}/{row['ifd_unknown']:,}|")
    return '\n'.join(lines)


def main():
    """READMEを完了版へ更新し、条件/設定へ結果だけを追記する。

    引数: なし。返り値: None。Source/指標式/閾値/金融計算は変更しない。
    """
    summary = json.loads((FORMAL / '成果物/集計.json').read_bytes())
    assert summary['主政策'] is None and summary['選択trade数'] is None and not summary['売買選択']
    with gzip.open(FORMAL / '検査/F1実行前文書.json.gz', 'rb') as stream:
        original = json.load(stream)
    before = {item['path']: item['本文'].encode('utf-8') for item in original['文書']}
    for name, body in before.items():
        assert (ROOT / name).read_bytes() == body
    settings = FORMAL / '設定と結果.md'
    rows_before = [line for line in settings.read_text(encoding='utf-8').splitlines() if re.match(r'^\|\s*[A-Z]\d{2}\s*\|', line)]
    assert len(rows_before) == 57 and all(len(line.split('|')) == 13 for line in rows_before)
    all_table = stats_table(summary, ['all'], ['C0', 'C1', 'RC1', 'BUY', 'SELL'])
    split_table = stats_table(summary, ['train', 'validation'], ['C1', 'BUY', 'SELL'])
    output = '../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/148_全1分知得の母集団診断'
    readme = f'''# 全1分知得の母集団固定と診断を完了

試行00148。全73場の母集団生成・当時100特徴・取得case統合・正逆観測・金融診断300比較を完了した。**売買政策・最終選択取引数・選択頻度は未選択/null**である。母集団全件のBUYは43.11%、SELLは46.44%で、全件に高い入口精度があるとは言えない。広く記録して複合テクニカルで局面を選ぶ土台ができたことと、Strategyの目標達成を区別する。

[全セッションCSV]({output}/全セッション.csv)で73場を確認し、[入口別診断CSV]({output}/入口別診断.csv)で全q0・未取得理由・両方向の結果を追える。[正逆比較CSV]({output}/正逆比較.csv)は政策/母集団・費用・観測時間・幅を比較する。CSVの件数は最終取引回数ではない。

## 何を増やし、何を選んでいないか

従来の狭いAND完成を待つ入口は、147で新取得5件にとどまった。148は最新1分の価格known・closed・freshを満たすq0を広く残し、背景MA/DI/ADX・Hist/RSI・BB位置/125pt余地・ATR/TR・量・短期形状の100列を記録した。量や技法の不一致で母集団を間引かず、q1の成否・後続quality・ラベルをq0のXへ入れていない。

|単位|全73場の数|意味|
|---|---:|---|
|全q0台帳|40,544|不適格も全理由・当場4slot付きで保持|
|出生適格・X生成|35,339|買売各100列。q1未取得でもXを保持|
|取得event/unique新研究q1|31,632|今回同q1共有0。全件を実売買した回数ではない|
|旧C1再用|77|旧87の一部と同原行。元side/Quote/originsを保持|
|旧C1外の新case|31,555|格納原側+1から実買/実売を別々に観測|
|保護旧C1|87|未参照10件も除外せず保持|
|全観測case|31,642|31,555＋旧87。BUY/SELL診断集合31,632とは異なる|
|最終選択取引|**null**|Strategy・ML・episode/cooldown・待機閾値は未採用|

q0は足を知った時点、q1は別原行かつ1秒以上後の最初正常BBOである。30秒strict TTL、最新1分quality取消、新規限界Lを維持し、q0へ取得価格を遡らせない。1分をまとめて知った場合は最後/最新足だけをdecision対象とし、古い良い足へfallbackしない。時刻はCurrentPriceTimeモデルで、実受信やWS完全性を復元したものではない。

## H60±125の診断

全て取得時点から60分・同幅125ptの実BBO側で評価する。「到達済み先着率」はH完了内の順/(順＋逆)。未到達と観測不足を落として全件勝率と呼ばず、IFD金額既知/未知とも分ける。利益/損失は独立mini1枚、手数料往復77円＋C5追加滑り往復1,000円。損失は絶対額で示す。

{all_table}

C0は旧81、C1は旧145全87、RC1はC1同時点の実逆。BUY/SELLは研究q1の同じ31,632物理取得を実買/実売へ写した**選別前の診断集合**である。C1の70.00%は既存対照の維持で、新しい高頻度政策の達成ではない。BUY/SELLの全件IFD合算は近接・重複保有を含み、片側上限10枚口座・実mini板・実IFD・必須利益追尾の運用成績とは呼ばない。

|集合|追加滑り0・往復77円のみの差引円|C5差引円|取得可能case/全時間h|選択trade/時|
|---|---:|---:|---:|---|
'''
    for policy in ('C1', 'BUY', 'SELL'):
        row = summary['集計']['all'][policy]['BBO']['3600']['125']
        rate = summary['取得可能頻度']['all'][policy]['取得可能case毎時']
        readme += f"|{policy}|{money(row['ifd_net0_sum'])}|{money(row['ifd_net5_sum'])}|{rate:.5f}|null|\n"
    readme += f'''
全時間分母は720時間55分。母集団case約43.88件/時はデータの取得可能密度であり、共同目標の平均概ね1回/時を満たす選択取引頻度ではない。反転結果は実BBOで別観測しており、1−pで推定しない。

## 前後の参考分割と限界

{split_table}

前48場も後25場も既使用で、後半を独立未知期と呼ばない。同場・近接H60窓・買売2行を独立標本へ水増ししない。全件買売の43.11/46.44%から、個々のテクニカル領域の条件を未検証のまま採用しない。未到達・不足・金額未知を0損益へ補完しない。

## 検査・再現・次の問い

Sourceの停止人工、Rootの追加26特徴3群/純case2群、独立Source5群と自然全件監査により、旧87の全JSON/大整数/origins保持、100列の有限/null、台帳・refs・canonical・時計を確認した。金融はRootの別算術で300比較/7,200統計キー・旧87全4streamを一致。CSVは2,123,963データセル・800,382数値を独立再読し、Rootが3プレビューを確認した。

検算初回のflipsは保存原側とBUY正規化側という意味の差だけを別版で修正し、作者数値・Source・F2元checkerは不変更。[修正経緯](根拠/診断検算の修正経緯.md)に旧版と版2、元準備票とUTF-8補正票を分けて記録した。

[条件](条件.md)はF0本文を保持し結果追記、[設定と結果](設定と結果.md)は版7全513セルを保持した。[100特徴別紙](100特徴の列定義.md)、[金融正本](成果物/集計.json)、[金融独立票](検査/金融独立検算.json)、[閲覧資料](閲覧資料.md)、[保管索引](保管索引.json)、[再現手順](再現手順.md)から根拠へ到達できる。生成5正本と観測は各一度gzip保存し、旧大入力・原板・実行体を複製していない。

次は[149：可読な8局面の選択](../00149_可読な局面選択で入口品質を診断する/README.md)で、価格位置と別役割を組み合わせて選ぶ。149の金融は本結果へ混ぜず、別試行で評価する。148は母集団固定の完了であり、70%・全場min1・概ね1回/時の共同目標を縮小又は達成した記録ではない。
'''
    # 後続の正式名はRootが作成した149だけを参照する。本文や条件は編集しない。
    next_folder = next((ROOT / 'study').glob('00149_*'))
    readme = readme.replace('../00149_可読な局面選択で入口品質を診断する/README.md', '../' + next_folder.name + '/README.md')
    appendix = f'''

## 実行結果：148の母集団固定と金融診断

全73場の自然生成・100特徴・全case観測・300比較を完了した。上の未実行/予定は固定前原文として保持し、ここへ結果を追記する。条件・閾値・100列・57行513セルは変更していない。主政策/最終選択取引/選択頻度/新政策共同目標はnullで、データcase数を取引頻度の達成へ代用しない。

全q0台帳40,544、X35,339、取得event/研究unique q1は31,632、C1再用77、新31,555、旧C1全87保護、全観測31,642case。旧C1未参照10件も保持する。H60±125実BBO・C5の結果は以下の通り。

{all_table}

到達済み率はH完了内の順/(順＋逆)で、未到達・観測不足・IFD金額未知を別に残す。全件買売IFD合算は重複窓を含む独立1mini診断で、10枚口座・実運用収支ではない。前48/後25も既使用で、[README](README.md)に前後の参考値を示す。母集団取得可能密度は約43.88case/時、選択取引の頻度はnullである。

F0 `d3f6888e97cb2373a83fb95576175ef1f76b5c59ff8ffaa60a9391ac2fb8d00d`、F1 `c1d2873f9bf7cce046c40e1353126dfb7b375b11f328674117946799b599e6ad`、F2 `00f1061e6a43450bd1a596056fec84ca912e06ab7e09a37ec23b955c46cdfb4b`。Root独立300/7,200キー・旧87全4stream一致、CSV全2,123,963データセル/800,382数値再読とRoot3プレビュー確認を完了した。[検算経緯](根拠/診断検算の修正経緯.md)のflipsメタ修正は金融条件変更ではない。

[全セッションCSV]({output}/全セッション.csv)、[入口別CSV]({output}/入口別診断.csv)、[比較CSV]({output}/正逆比較.csv)、[金融正本](成果物/集計.json)、[独立検算](検査/金融独立検算.json)、[再現手順](再現手順.md)、[保管索引](保管索引.json)を参照する。追加2場は対象外・未読のまま。後続149の選択を本試行へ後付けせず、148の売買政策は未選択を保持する。
'''
    (FORMAL / 'README.md').write_text(readme, encoding='utf-8')
    for name in ('条件.md', '設定と結果.md'):
        path = FORMAL / name
        path.write_bytes(before[path.relative_to(ROOT).as_posix()] + appendix.encode('utf-8'))
    rows_after = [line for line in settings.read_text(encoding='utf-8').splitlines() if re.match(r'^\|\s*[A-Z]\d{2}\s*\|', line)]
    assert rows_before == rows_after
    for name in ('条件.md', '設定と結果.md'):
        path = FORMAL / name
        assert path.read_bytes().startswith(before[path.relative_to(ROOT).as_posix()])
    proof = {'成功': True, '試行': 148, 'README': '母集団固定完了/売買政策未選択nullを先頭へ',
             '条件と設定はF1全bytesをprefix保持': True, '513セル完全同体': True,
             '元3MDはF0F1snapshot保持': True, '新金融計算': False,
             '転記正本SHA256': file_sha(FORMAL / '成果物/集計.json'),
             '正式3MD': {name: file_sha(FORMAL / name) for name in ('README.md', '条件.md', '設定と結果.md')}}
    (FORMAL / '検査/正式結果の反映確認.json').write_bytes(json_bytes(proof))
    print('proof_sha256=' + file_sha(FORMAL / '検査/正式結果の反映確認.json'))


if __name__ == '__main__':
    main()
