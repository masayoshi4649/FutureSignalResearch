"""148の正式結果・CSV・再現・小型資料を締め、停止票を作る。"""
from pathlib import Path
import gzip
import hashlib
import json
import re
from urllib.parse import unquote
import zipfile
from 保存部品 import ROOT, FORMAL, file_sha, json_bytes, save


def links(path):
    """Markdown内のローカルリンクを実在確認する。

    引数: path(Path)。返り値: intは検査リンク数。
    """
    count = 0
    for target in re.findall(r'\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
        if target.startswith(('http:', 'https:', 'mailto:', '#')):
            continue
        assert (path.parent / unquote(target.split('#')[0])).resolve().exists(), (str(path), target)
        count += 1
    return count


def check_numbers(path, summary):
    """表示したH60±125表のセルを金融正本へ別読取で比較する。

    引数: path(Path)、summary(dict)。返り値: intは確認した数値セル数。
    金融算術を再実装せず、転記の一致だけを確認する。
    """
    prefixes = {'全73場 ': 'all', '前48場・既使用 ': 'train', '後25場・既使用 ': 'validation'}
    checked = 0
    for line in path.read_text(encoding='utf-8').splitlines():
        if not line.startswith('|'):
            continue
        cells = line.split('|')[1:-1]
        if len(cells) != 8:
            continue
        for prefix, part in prefixes.items():
            if not cells[0].startswith(prefix):
                continue
            policy = cells[0][len(prefix):]
            d = summary['集計'][part][policy]['BBO']['3600']['125']
            assert int(cells[1].replace(',', '')) == d['entries']
            assert [int(x.replace(',', '')) for x in cells[2].split('/')] == [d[k] for k in ('forward', 'adverse', 'neither', 'censored')]
            assert cells[3] == f"{d['resolved_rate'] * 100:.2f}%"
            assert [int(x.replace(',', '')) for x in cells[4:7]] == [d[k] for k in ('ifd_net5_profit', 'ifd_net5_loss', 'ifd_net5_sum')]
            assert [int(x.replace(',', '')) for x in cells[7].split('/')] == [d['ifd_known'], d['ifd_unknown']]
            checked += 11
    assert checked > 0
    return checked


def main():
    """恒久資料と文書を最終確認し、最小後発ZIPと停止票を残す。

    引数: なし。返り値: None。旧147/149正式3MD・Raw・Sourceは変更しない。
    """
    here = Path(__file__).resolve().parent
    runtime = ROOT / 'work/148全1分母集団の評価'
    output = ROOT / 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/148_全1分知得の母集団診断'
    index_path = FORMAL / '保管索引.json'
    index = json.loads(index_path.read_bytes())
    summary = json.loads((FORMAL / '成果物/集計.json').read_bytes())
    assert summary['主政策'] is None and summary['選択trade数'] is None and summary['選択trade毎時'] is None
    with gzip.open(FORMAL / '検査/F1実行前文書.json.gz', 'rb') as stream:
        old = {item['path']: item['本文'].encode('utf-8') for item in json.load(stream)['文書']}
    for name in ('条件.md', '設定と結果.md'):
        path = FORMAL / name
        assert path.read_bytes().startswith(old[path.relative_to(ROOT).as_posix()])
    old_rows = [x for x in old[(FORMAL / '設定と結果.md').relative_to(ROOT).as_posix()].decode('utf-8').splitlines() if re.match(r'^\|\s*[A-Z]\d{2}\s*\|', x)]
    now_rows = [x for x in (FORMAL / '設定と結果.md').read_text(encoding='utf-8').splitlines() if re.match(r'^\|\s*[A-Z]\d{2}\s*\|', x)]
    assert old_rows == now_rows and len(now_rows) == 57 and all(len(row.split('|')) == 13 for row in now_rows)
    numeric = sum(check_numbers(FORMAL / name, summary) for name in ('README.md', '条件.md', '設定と結果.md'))
    replay_source = ROOT / 'work/148保存観測の再現/保存観測からの再現確認.json'
    assert file_sha(replay_source) == '7faec8061231710b0f879b6dbc874d7e088f43d8441fe10ac9f687933320c499'
    replay = json.loads(replay_source.read_bytes())
    assert replay['成功'] and replay['CSV用三表JSONbytes完全一致']
    replay_record = save(replay_source, FORMAL / '検査/保存観測からの再現確認.json', file_sha(replay_source))
    csv_source = runtime / '金融診断/CSV独立再読.json'
    csv = json.loads(csv_source.read_bytes())
    assert csv['成功'] and csv['全データセル比較数'] == 2123963 and csv['数値比較数'] == 800382
    for item in csv['表別']:
        assert file_sha(Path(item['CSV']['path'])) == item['CSV']['sha256']
    csv_record = save(csv_source, FORMAL / '検査/CSV独立再読.json', file_sha(csv_source))
    reviewer = ROOT / 'work/148正式結果の原文とリンクの独立確認'
    reviewer_proof = reviewer / '確認の記録.json'
    assert file_sha(reviewer_proof) == '5cd352c168c01b1e3123a8744ec5f704f3deecfea8e09521199b83f5eb521419'
    review_record = save(reviewer_proof, FORMAL / '検査/正式原文とリンクの独立確認.json', file_sha(reviewer_proof))
    # ----------------------------------------
    # 新しい小型コードだけを保存する。既存金融源・gZip・CSVをZIPへ複製しない。
    paths = [here / name for name in ('正式結果を反映する.py', '保存観測から再集計する.py', '正式保存を確認する.py')]
    paths += [reviewer / '確認する.py']
    paths += [ROOT / 'work/確定三表のCSV出力' / name for name in ('出力する.mjs', 'CSVを独立再読する.py', '由来.json')]
    target = FORMAL / '再現資料/148正式化とCSVの資料.zip'
    entries = []
    with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for path in paths:
            body, name = path.read_bytes(), path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 12, 0, 0, 0))
            bundle.writestr(info, body, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
            entries.append({'path': name, 'bytes': len(body), 'sha256': file_sha(path)})
    with zipfile.ZipFile(target) as bundle:
        assert all(hashlib.sha256(bundle.read(item['path'])).hexdigest() == item['sha256'] for item in entries)
    marker = {'確認者': 'Root', '確認方法': '親からの完了通知。Rootの3PNG目視済み・create/3/csv marker1回',
              '作者票': (output / 'CSVの確認.json').relative_to(ROOT).as_posix(), '作者票SHA256': file_sha(output / 'CSVの確認.json'),
              '支援画像': [str(path.relative_to(ROOT)) for path in sorted((output / '支援画像').glob('*.png'))],
              '子agent自身の目視確認とは区別': True, 'xlsx生成': False}
    assert len(marker['支援画像']) == 3
    (FORMAL / '検査/RootのCSV表示確認.json').write_bytes(json_bytes(marker))
    index.update({'段階': '正式保存完了・母集団診断完了。売買政策は未選択null',
                  '保存観測の再現': replay_record, 'CSV独立再読': csv_record,
                  '正式原文の独立確認': review_record,
                  'CSV閲覧': {item['表名']: {'path': Path(item['CSV']['path']).relative_to(ROOT).as_posix(),
                                           'sha256': item['CSV']['sha256'], 'rows': item['行数'], 'columns': item['列数']} for item in csv['表別']},
                  '正式化とCSVの資料': {'保存元ZIP': target.relative_to(ROOT).as_posix(), 'ZIP_SHA256': file_sha(target),
                                       'ZIP_bytes': target.stat().st_size, '格納源': entries},
                  '正式3MD最終SHA256': {name: file_sha(FORMAL / name) for name in ('README.md', '条件.md', '設定と結果.md')},
                  '最終選択取引数': None, '新選択共同目標': None, '目標を母集団件数で代用': False})
    index_path.write_bytes(json_bytes(index))
    # 文書リンクはCSV/再現の恒久化後に全件確認する。
    documents = [FORMAL / name for name in ('README.md', '条件.md', '設定と結果.md', '100特徴の列定義.md', '再現手順.md', '閲覧資料.md', '根拠/診断検算の修正経緯.md')]
    documents += [output / 'README.md', ROOT / 'inputs/00148_全1分入口母集団/README.md',
                  ROOT / 'README.md', ROOT / 'docs/README.md', ROOT / 'docs/議論/README.md', ROOT / 'study/README.md',
                  ROOT / 'docs/議論/入口の母集団を広げて技術局面の良否を評価する方針.md']
    link_count = sum(links(path) for path in documents)
    proof = {'成功': True, '試行': 148, '状態': '母集団生成/100特徴/正逆観測/金融診断/CSV/再現/正式保存を完了・編集停止',
             'F0_SHA256': index['F0_SHA256'], 'F1_SHA256': index['F1_SHA256'], 'F2_SHA256': index['F2_SHA256'],
             'F0全87/F1全95/F2全13参照保存': [index['F0直接源数'], index['F1直接源数'], index['F2直接源数']],
             'F1保存bytes復元': 92, '非複製': 3, '条件設定の元全bytesPrefix保持': True, '全513セル同体': True,
             '文書表の数値転記比較数': numeric, '金融Root別算術': '300比較7200統計キー・旧87全4stream同体',
             'CSV全データセル一致': csv['全データセル比較数'], 'CSV数値一致': csv['数値比較数'],
             '保存観測再集計': file_sha(ROOT / replay_record['保存元']), '三表JSONbytes一致': True,
             'ローカルリンク実在数': link_count, '保管索引SHA256': file_sha(index_path),
             '正式3MD最終SHA256': index['正式3MD最終SHA256'], '最終選択取引数': None, '新選択共同目標': None,
             '運用収支又は新政策達成': False, 'Raw再走査/追加2場読取/旧147又は149正式変更': False,
             '巨大入力や観測の重複保存': False, '重大不足': []}
    final_path = FORMAL / '検査/正式保存の最終確認.json'
    final_path.write_bytes(json_bytes(proof))
    print('final_sha256=' + file_sha(final_path))
    print('index_sha256=' + file_sha(index_path))
    print('links=' + str(link_count))


if __name__ == '__main__':
    main()
