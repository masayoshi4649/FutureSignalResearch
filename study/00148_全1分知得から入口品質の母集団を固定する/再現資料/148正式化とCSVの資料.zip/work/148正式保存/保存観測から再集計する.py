"""148の恒久gzip/小ZIPから必要源を復元し、Rawなしで診断を再集計する。"""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import subprocess
import sys
import zipfile
from 保存部品 import ROOT, FORMAL, registries, file_sha, json_bytes


def main():
    """未作成work宛先へ最小源を復元して300比較/三表を再現する。

    引数: --destination(str)はrepository内workの未作成相対path。
    返り値: None。原F1は不変更で、再現台帳のpath/SHAだけを分離する。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--destination', required=True)
    args = parser.parse_args()
    destination = (ROOT / args.destination).resolve()
    assert destination.is_relative_to((ROOT / 'work').resolve()) and not destination.exists()
    destination.mkdir(parents=True)
    index = json.loads((FORMAL / '保管索引.json').read_bytes())
    f1 = json.loads((ROOT / index['F1原文']['保存元']).read_bytes())
    f2 = json.loads((ROOT / index['F2原文']['保存元']).read_bytes())
    completed = json.loads((FORMAL / '成果物/集計完了.json').read_bytes())
    by_path, by_sha = registries()
    fingerprints = {}
    for document in (f1['ファイル'], f2['ファイル'], completed['前後SHA256']):
        for name, digest in document.items():
            path = Path(name)
            if not path.is_absolute():
                path = ROOT / path
            fingerprints[path.relative_to(ROOT).as_posix()] = digest
    restored, verified = [], {}

    def restore(rel):
        """保存物から一源をストリーム復元する。

        引数: rel(str)は元repository相対path。返り値: Path。
        """
        wanted = fingerprints[rel]
        ref = by_path.get(rel)
        if not ref or ref.get('解凍SHA256') != wanted:
            ref = by_sha[wanted]
        target = destination / rel
        assert target.is_relative_to(destination) and not target.exists()
        target.parent.mkdir(parents=True, exist_ok=True)
        if '保存元ZIP' in ref:
            path = ROOT / ref['保存元ZIP']
            if path not in verified:
                verified[path] = file_sha(path)
            assert verified[path] == ref['ZIP_SHA256']
            with zipfile.ZipFile(path) as bundle, bundle.open(ref['ZIP内path']) as original, target.open('xb') as output:
                for chunk in iter(lambda: original.read(1024 * 1024), b''):
                    output.write(chunk)
        else:
            path = ROOT / ref['保存元']
            assert file_sha(path) == ref['保存SHA256']
            assert ref['形式'] in ('gzip', '同体')
            opener = gzip.open if ref['形式'] == 'gzip' else open
            with opener(path, 'rb') as original, target.open('xb') as output:
                for chunk in iter(lambda: original.read(1024 * 1024), b''):
                    output.write(chunk)
        assert file_sha(target) == wanted
        restored.append({'path': rel, 'sha256': wanted, 'bytes': target.stat().st_size})
        return target

    for rel in (
        'work/148母集団の診断集計/集計する.py', 'work/148母集団の診断集計/人工検査.py',
        'work/148母集団の診断集計/条件.md', 'work/148母集団の診断集計/準備の確認.json',
        'work/124入口の原因分析/集計する.py', 'work/145構造イベントの評価/固定取得の正逆観測.json',
        'work/145構造イベントの評価/金融評価/集計.json',
        *['work/148全1分母集団の評価/母集団生成/' + name + '.json' for name in ('出生台帳', '取得対応', '固定取得入力', '入口参照', '生成の確認')],
        'work/148全1分母集団の評価/固定取得の正逆観測.json'):
        restore(rel)
    replay_f1 = {**f1, 'ファイル': {str(destination / Path(name).relative_to(ROOT)): digest for name, digest in f1['ファイル'].items()},
                 '再現専用': True, '元F1_SHA256': index['F1_SHA256']}
    replay_path = destination / '再現F1.json'
    replay_path.write_bytes(json_bytes(replay_f1))
    replay_sha = file_sha(replay_path)
    output = destination / '再集計'
    script = destination / 'work/148母集団の診断集計/集計する.py'
    command = [sys.executable, '-X', 'utf8', str(script), '--preparation-sha256',
               'fcd5c81366bb7640fd330e1a7b93043b3195f5026e016d7c7683e326345f545c',
               '--f1', str(replay_path), '--f1-sha256', replay_sha,
               '--generation-dir', str(destination / 'work/148全1分母集団の評価/母集団生成'),
               '--result', str(destination / 'work/148全1分母集団の評価/固定取得の正逆観測.json'),
               '--result-sha256', index['保存済み正逆観測']['解凍SHA256'], '--output-dir', str(output)]
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (destination / '再実行.txt').write_bytes(result.stdout + result.stderr)
    assert result.returncode == 0, (result.stdout + result.stderr).decode('utf-8', 'replace')
    expected = json.loads((ROOT / index['保存金融正本']['保存元']).read_bytes())
    actual = json.loads((output / '集計.json').read_bytes())
    assert actual['F1_SHA256'] == replay_sha
    actual['F1_SHA256'] = expected['F1_SHA256']
    assert actual == expected
    assert file_sha(output / 'CSV用の表.json') == index['保存CSV用の表']['解凍SHA256']
    proof = {'成功': True, '試行': 148, '復元源': restored, '元F1_SHA256': index['F1_SHA256'],
             '再現専用F1_SHA256': replay_sha, '許容差': '集計のF1_SHA256だけを再現台帳へ置換。他の全dictは完全一致',
             '300比較と全統計参加頻度phase旧対照が一致': True, 'CSV用三表JSONbytes完全一致': True,
             '三表JSON_SHA256': file_sha(output / 'CSV用の表.json'), 'RawSource再生又は新観測': False,
             '旧正本上書き': False, '原F1変更': False, '最終選択取引数': None}
    path = destination / '保存観測からの再現確認.json'
    path.write_bytes(json_bytes(proof))
    print('proof_path=' + str(path.relative_to(ROOT)))
    print('proof_sha256=' + file_sha(path))


if __name__ == '__main__':
    main()
