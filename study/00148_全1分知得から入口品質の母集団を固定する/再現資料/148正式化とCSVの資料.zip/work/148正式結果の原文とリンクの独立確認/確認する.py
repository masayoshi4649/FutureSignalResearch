"""148正式結果の原文prefix・513セル・完了/null表記・リンクだけを非金融確認する。"""
from pathlib import Path
import gzip
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
FORMAL = ROOT / 'study/00148_全1分知得から入口品質の母集団を固定する'


def fingerprint(path: Path) -> dict:
    """
    機能: 正式文書と既退避原文のbytesを指紋化する。
    引数: path(Path)。返り値: dictはpath/bytes/SHA256。
    """
    raw = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def catalog_rows(text: str) -> list[str]:
    """
    機能: ID付き57手法の9尺度表だけを抽出する。
    引数: text(str)。返り値: list[str]は表の原文行。
    """
    return [line for line in text.splitlines() if re.match(r'^\| [A-Z]\d{2} \|', line)
            and len(line.split('|')[1:-1]) == 11]


def main() -> None:
    """
    機能: F1原文と現在3MDを比較し、非金融の限定停止票を作る。
    引数: なし。返り値: None。金額/ラベルJSONは開かず、正式文書を変更しない。
    """
    author = FORMAL / '検査/正式結果の反映確認.json'
    assert fingerprint(author)['sha256'] == '039dae42b3a3b9f9a9bdcedf371595f1fa968ceb4156f5ac033f08954bf26bcd'
    original_path = FORMAL / '検査/F1実行前文書.json.gz'
    paths = [FORMAL / n for n in ('README.md', '条件.md', '設定と結果.md')] + [author, original_path]
    before = {p: fingerprint(p) for p in paths}
    snapshot = json.loads(gzip.decompress(original_path.read_bytes()))
    by_path = {row['path'].replace('\\', '/'): row for row in snapshot['文書']}
    old = {}
    for name in ('README.md', '条件.md', '設定と結果.md'):
        item = by_path[(FORMAL / name).relative_to(ROOT).as_posix()]
        raw = item['本文'].encode('utf-8')
        assert hashlib.sha256(raw).hexdigest() == item['sha256']
        old[name] = raw
    for name in ('条件.md', '設定と結果.md'):
        assert (FORMAL / name).read_bytes().startswith(old[name]), name
    rows = catalog_rows((FORMAL / '設定と結果.md').read_text(encoding='utf-8'))
    prior_rows = catalog_rows(old['設定と結果.md'].decode('utf-8'))
    assert rows == prior_rows and len(rows) == 57
    assert all(len(line.split('|')[3:-1]) == 9 for line in rows)
    readme = (FORMAL / 'README.md').read_text(encoding='utf-8')
    heading = readme.splitlines()[0]
    introduction = readme.split('\n\n')[1]
    assert '母集団固定' in heading and '完了' in heading
    assert '売買政策・最終選択取引数・選択頻度は未選択/null' in introduction
    assert 'Strategyの目標達成を区別' in introduction
    links = 0
    for path in paths[:3]:
        for target in re.findall(r'\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
            if '://' in target or target.startswith('#'):
                continue
            assert (path.parent / target.split('#', 1)[0]).exists(), (path.name, target)
            links += 1
    assert before == {p: fingerprint(p) for p in paths}
    proof = {'成功': True, '試行': 148, '状態': '正式結果の原文とリンクの限定確認・停止',
             'F1原文': before[original_path], '作者反映票': before[author],
             '条件/設定のF1元全bytesがprefix保持': True,
             'V7': {'手法': 57, '尺度': 9, 'セル': 513, '全57行文字同体': True},
             'README先頭': '母集団固定完了/売買政策・最終選択取引数・選択頻度は未選択null/目標達成と区別',
             'ローカルリンク実在': links, '対象前後同体': list(before.values()),
             '金額/先着率の数値妥当性検査': False, '金融/ラベルJSON/Raw/追加2場読取': False,
             '独立金融確認はRoot別票へ分離': True, '正式/149編集': False,
             '確認コード': fingerprint(Path(__file__))}
    target = HERE / '確認の記録.json'
    target.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'proof_sha256': fingerprint(target)['sha256'], 'cells': 513, 'links': links}, ensure_ascii=False))


if __name__ == '__main__':
    main()
