"""148保存器を人工だけで準備確認し、実F0保存は別CLIへ分ける。"""
from pathlib import Path
import json
import subprocess
import sys
from 保存部品 import ROOT, sha, json_bytes, registries


def main():
    """人工・構文・CLI拒否・旧保存器不変を確認する。

    引数: なし。返り値: None。自然5正本/Raw/金融や正式3MDは開かない。
    """
    here = Path(__file__).resolve().parent
    old = ROOT / 'work/147正式保存'
    before = {path.name: sha(path.read_bytes()) for path in old.glob('*.py')}
    by_path, _ = registries()
    expected = {
        'work/145構造イベントの評価/固定入力/固定取得入力.json': 'd2becb3b1d6de656a6cc3f04d576d95d99693dfc42efc03582ed04d2be8784e8',
        'work/145構造イベントの評価/固定入力/入口参照.json': '3a3a144c478fa45f85e03ad4b8e4461e420592da24088458c7aa1cb748c8eb8d',
        'work/145構造イベントの評価/固定取得の正逆観測.json': '3b92da8b447d7be9ead6a2a112759ca7272a1e65d6cb5516989e3faf50c54d62',
    }
    assert all(by_path[name]['解凍SHA256'] == value for name, value in expected.items())
    run = subprocess.run([sys.executable, '-X', 'utf8', str(here / '保存の人工検査.py')], capture_output=True, text=True, encoding='utf-8')
    assert run.returncode == 0, run.stdout + run.stderr
    artificial = json.loads(run.stdout)
    assert artificial['成功'] and artificial['人工主群'] == 5
    scripts = sorted(here.glob('*.py'))
    compile_result = subprocess.run([sys.executable, '-m', 'py_compile', *map(str, scripts)], capture_output=True)
    assert compile_result.returncode == 0
    refusals = []
    for name in ('F0原文を保管する.py', 'F1の追加資料を保管する.py'):
        result = subprocess.run([sys.executable, '-X', 'utf8', str(here / name)], capture_output=True)
        assert result.returncode == 2
        refusals.append({'CLI': name, '必須指定拒否': True})
    assert before == {path.name: sha(path.read_bytes()) for path in old.glob('*.py')}
    proof = {'成功': True, '試行': 148, '段階': '人工のみの保存器準備', '人工': artificial,
             '構文成功': True, 'CLI拒否': refusals, '可変F0F1源数': True, '生成5正本各一度gzip': True,
             '100列既存正本を再複製しない': True, '共有入力metadata解決': expected,
             '旧147保存器前後同体': before, '準備源': {path.name: sha(path.read_bytes()) for path in [*scripts, here / '保存の準備.md']},
             '自然生成5点/金融/Raw/価格CSV/追加2場読取': False, '正式3MD変更': False,
             '最終取引未選択null': True, 'case数を目標頻度へ代用': False, '重大不足': []}
    path = here / '準備の確認.json'
    path.write_bytes(json_bytes(proof))
    print('prepare_sha256=' + sha(path.read_bytes()))
    print('artificial_groups=' + str(artificial['人工主群']))


if __name__ == '__main__':
    main()
