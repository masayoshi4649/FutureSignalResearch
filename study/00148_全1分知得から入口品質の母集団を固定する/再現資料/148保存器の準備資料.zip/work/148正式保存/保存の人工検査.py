"""148保存器を一時架空rootだけで検査し、生成中の実5ファイルは開かない。"""
from pathlib import Path
import gzip
import json
import tempfile
import 保存部品 as M


def main():
    """コア3MD/100列共有/可変F1/一度gzipを人工で確認する。

    引数: なし。返り値: None。実正式148の変更や自然データ読取は行わない。
    """
    previous = M.ROOT, M.FORMAL, M.INPUTS, M.registries
    by_path, by_sha = M.registries()
    for name in ('固定取得入力.json', '入口参照.json'):
        assert 'work/145構造イベントの評価/固定入力/' + name in by_path
    tests = ['旧145共有入力と旧コードを既存恒久索引metadataだけで解決']
    here = Path(__file__).resolve().parent
    with tempfile.TemporaryDirectory(prefix='人工148_', dir=here) as temporary:
        root = Path(temporary)
        M.ROOT = root
        M.FORMAL = root / 'study/00148_人工'
        M.INPUTS = root / 'inputs/00148_人工'

        def put(path, body):
            """架空rootだけに入力を書く。

            引数: path(Path)、body(bytes)。返り値: None。
            """
            assert path.is_relative_to(root)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(body)

        documents = [M.FORMAL / name for name in M.CORE]
        for path in documents:
            put(path, ('# 人工原文 ' + path.name + '\r\n').encode('utf-8'))
        catalog = M.FORMAL / '100特徴の列定義.md'
        put(catalog, '# 人工100列を重ねない\n'.encode('utf-8'))
        canonical = M.INPUTS / '100特徴の列定義.json'
        put(canonical, b'["artificial"]\n')
        code = root / 'work/人工源.py'
        put(code, '"""人工コード。"""\n'.encode('utf-8'))
        huge = root / 'work/122全場入力/入力.json'
        binary = root / 'work/人工.exe'
        put(huge, b'artificial huge path only')
        put(binary, b'artificial executable')
        old = root / 'work/人工共有.json'
        packed = root / 'inputs/人工共有.json.gz'
        body = M.json_bytes({'人工': True, '値': 3})
        put(old, body)
        put(packed, gzip.compress(body, mtime=0))
        shared = {'保存元': packed.relative_to(root).as_posix(), '復元先': old.relative_to(root).as_posix(),
                  '形式': 'gzip', '保存SHA256': M.file_sha(packed), '解凍SHA256': M.sha(body)}
        M.registries = lambda: ({shared['復元先']: shared}, {})
        files = {str(path): M.file_sha(path) for path in [*documents, catalog, canonical, code, huge, binary, old]}
        f0 = root / 'work/人工実行/F0.json'
        put(f0, M.json_bytes({'試行': 148, '人工': True, 'ファイル': files}))
        M.f0(f0, M.file_sha(f0))
        index = json.loads((M.FORMAL / '保管索引.json').read_bytes())
        groups = index['F0復元参照']
        assert len(groups['文書snapshot']) == 3 and len(groups['既存恒久正本']) == 2
        assert len(groups['意図して非複製']) == 2 and len(groups['共有入力']) == 1
        assert sum(len(value) for value in groups.values() if isinstance(value, list)) == len(files)
        assert index['最終選択取引数'] is None and not index['データcase数を目標頻度へ代用']
        snap = json.loads(gzip.decompress((M.FORMAL / '検査/F0実行前文書.json.gz').read_bytes()))
        assert len(snap['文書']) == 3
        assert all(item['本文'].encode('utf-8') == (root / item['path']).read_bytes() for item in snap['文書'])
        tests.append('コア3MD CRLF原文、100列2正本の共有、新小ZIPと巨大入力exe非複製の区分')

        generated = root / 'work/人工実行/母集団生成'
        for i, name in enumerate(M.GENERATED):
            put(generated / name, M.json_bytes({'人工': True, 'kind': name, '値': i, '文字': 'a' * (1_100_000 if i == 1 else 20)}))
        files1 = {**files, str(f0): M.file_sha(f0), **{str(generated / name): M.file_sha(generated / name) for name in M.GENERATED}}
        f1 = root / 'work/人工実行/F1.json'
        put(f1, M.json_bytes({'試行': 148, '人工': True, 'ファイル': files1}))
        M.f1(f1, M.file_sha(f1), generated)
        index = json.loads((M.FORMAL / '保管索引.json').read_bytes())
        assert index['F1直接源数'] == len(files1) and index['F1増分源数'] == 6
        assert len(index['新共用入力']) == 5
        for item in index['新共用入力']:
            assert M.sha(gzip.decompress((root / item['保存元']).read_bytes())) == item['解凍SHA256']
        tests.append('可変F1増分と生成5正本のストリームgzip、物理と解凍SHAを分離')
        for path in documents:
            put(path, path.read_bytes() + '\n人工の結果追記\n'.encode('utf-8'))
        assert all(M.sha(item['本文'].encode('utf-8')) == item['sha256'] for item in snap['文書'])
        tests.append('結果追記後も固定原文は退避snapshotから復元できる')
        try:
            M.save(generated / M.GENERATED[0], M.INPUTS / (M.GENERATED[0] + '.gz'), files1[str(generated / M.GENERATED[0])], True)
        except AssertionError:
            pass
        else:
            raise AssertionError('生成正本を上書きした')
        tests.append('一度保存した生成gzipへの重複保存を拒否')
    M.ROOT, M.FORMAL, M.INPUTS, M.registries = previous
    print(json.dumps({'成功': True, '人工主群': len(tests), '人工': tests,
                      '自然生成5点/Raw/金融/実正式148操作': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
