"""148の可変源数保存器。147を基に、100列共有と生成5点へ適応する。"""
from pathlib import Path
import gzip
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
FORMAL = ROOT / 'study/00148_全1分知得から入口品質の母集団を固定する'
INPUTS = ROOT / 'inputs/00148_全1分入口母集団'
TRIAL = 148
CORE = ('README.md', '条件.md', '設定と結果.md')
GENERATED = ('出生台帳.json', '当時特徴.json', '取得対応.json', '固定取得入力.json', '入口参照.json')


def sha(body):
    """原文bytesの指紋を計算する。

    引数: body(bytes)。返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


def file_sha(path):
    """小さいチャンクで指紋化する。

    引数: path(Path)。返り値: str。本文を構造解析しない。
    """
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(chunk)
    return result.hexdigest()


def json_bytes(value):
    """日本語UTF-8 JSONを作る。

    引数: value(dict)。返り値: bytes。非有限値は禁止する。
    """
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode('utf-8')


def write(path, body):
    """未作成先だけへ保存する。

    引数: path(Path)、body(bytes)。返り値: None。上書きは禁止する。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(body)


def save(source, target, expected, packed=False):
    """通知済み源を各一度だけ同体又はストリームgzip保存する。

    引数: source/target(Path)、expected(str)、packed(bool)。
    返り値: dictは復元情報。大きい生成JSONを全件メモリへ展開しない。
    """
    assert not target.exists(), str(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    result, size = hashlib.sha256(), 0
    with source.open('rb') as original, target.open('xb') as stored:
        writer = gzip.GzipFile(filename='', mode='wb', fileobj=stored, compresslevel=9, mtime=0) if packed else stored
        try:
            for chunk in iter(lambda: original.read(1024 * 1024), b''):
                result.update(chunk)
                size += len(chunk)
                writer.write(chunk)
        finally:
            if packed:
                writer.close()
    assert result.hexdigest() == expected, str(source)
    return {'保存元': target.relative_to(ROOT).as_posix(), '復元先': source.relative_to(ROOT).as_posix(),
            '形式': 'gzip' if packed else '同体', '保存bytes': target.stat().st_size, '保存SHA256': file_sha(target),
            '解凍bytes': size, '解凍SHA256': expected}


# ----------------------------------------
def registries():
    """既存恒久索引metadataから共有入力・コード・文書の参照を作る。

    引数: なし。返り値: tuple(dict,dict)は復元先とSHAの索引。
    Sourceや観測本文は開かず、小型の保存台帳を読む。
    """
    by_path, by_sha = {}, {}
    for number in (147, 146, 145, 144, 143, 141, 138, 133):
        folder = next((ROOT / 'study').glob(f'{number:05d}_*'))
        pending = [json.loads((folder / '保管索引.json').read_bytes())]
        while pending:
            item = pending.pop()
            if isinstance(item, list):
                pending.extend(item)
                continue
            if not isinstance(item, dict):
                continue
            if all(k in item for k in ('保存元', '復元先', '保存SHA256', '解凍SHA256')):
                by_path.setdefault(item['復元先'], item)
                by_sha.setdefault(item['解凍SHA256'], item)
            if item.get('形式') == '文書snapshot' and all(k in item for k in ('保存元', '抽出キー', 'sha256')):
                by_sha.setdefault(item['sha256'], item)
            if all(k in item for k in ('保存元ZIP', 'ZIP_SHA256', 'ZIP内path', 'sha256')):
                by_sha.setdefault(item['sha256'], item)
            if ('ZIP' in item or '保存元ZIP' in item) and '格納源' in item:
                path = ROOT / item['保存元ZIP'] if '保存元ZIP' in item else folder / '再現資料' / item['ZIP']
                for entry in item['格納源']:
                    fingerprint, name = entry.get('sha256'), entry.get('ZIP内path', entry.get('path'))
                    if fingerprint and name:
                        by_sha.setdefault(fingerprint, {'保存元ZIP': path.relative_to(ROOT).as_posix(),
                            'ZIP_SHA256': item['ZIP_SHA256'], 'ZIP内path': name, 'sha256': fingerprint, 'bytes': entry.get('bytes')})
            pending.extend(item.values())
    return by_path, by_sha


def current_catalog_refs():
    """100列と既存小ZIPを再複製せず参照する。

    引数: なし。返り値: dictはSHAから復元参照への辞書。
    """
    refs = {}
    packed = FORMAL / '根拠/100特徴の固定前資料.zip'
    if packed.exists():
        digest = file_sha(packed)
        with zipfile.ZipFile(packed) as bundle:
            for name in bundle.namelist():
                body = bundle.read(name)
                refs[sha(body)] = {'保存元ZIP': packed.relative_to(ROOT).as_posix(), 'ZIP_SHA256': digest,
                                  'ZIP内path': name, 'sha256': sha(body), 'bytes': len(body)}
    source_json = INPUTS / '100特徴の列定義.json'
    if source_json.exists():
        digest = file_sha(source_json)
        refs[digest] = {'保存元': source_json.relative_to(ROOT).as_posix(), '保存SHA256': digest,
                       '形式': '同体', '解凍SHA256': digest, '解凍bytes': source_json.stat().st_size}
    source_md = ROOT / 'work/148全1分候補の当時特徴/列定義.md'
    formal_md = FORMAL / '100特徴の列定義.md'
    if source_md.exists() and formal_md.exists():
        original = source_md.read_bytes()
        assert formal_md.read_bytes().startswith(original)
        refs[sha(original)] = {'保存元': formal_md.relative_to(ROOT).as_posix(), '保存SHA256': file_sha(formal_md),
                              '形式': '先頭bytes', '抽出bytes': len(original), '解凍SHA256': sha(original)}
    return refs


def snapshot(freeze, stage, fingerprint):
    """正式コア3MDを結果編集前の原文で保存する。

    引数: freeze(dict)、stage/fingerprint(str)。返り値: tupleは保存情報と文書参照。
    100列別紙は既存恒久正本を共有し、snapshotへ重ねない。
    """
    docs = []
    for name in CORE:
        path = FORMAL / name
        expected, body = freeze['ファイル'][str(path)], path.read_bytes()
        assert sha(body) == expected
        docs.append({'path': path.relative_to(ROOT).as_posix(), 'sha256': expected,
                     'bytes': len(body), '本文': body.decode('utf-8')})
    value = {'試行': TRIAL, '段階': stage + '正式文書原文', '固定SHA256': fingerprint,
             '正式コア3MD数': 3, '文書': docs, '100列別紙': '既存恒久正本を共有参照', '事前固定の後造り': False}
    target = FORMAL / '検査' / f'{stage}実行前文書.json.gz'
    write(target, gzip.compress(json_bytes(value), mtime=0))
    info = {'保存元': target.relative_to(ROOT).as_posix(), '保存SHA256': file_sha(target), '正式コア3MD数': 3}
    refs = [{'復元先': d['path'], 'sha256': d['sha256'], 'bytes': d['bytes'], '保存元': info['保存元'],
             '保存SHA256': info['保存SHA256'], '形式': '文書snapshot', '抽出キー': d['path']} for d in docs]
    return info, refs


def resolve(items, stage, docs, existing=None):
    """固定源を共有・snapshot・新小ZIP・非複製へ可変件数で分ける。

    引数: items(dict)、stage(str)、docs(list)、existing(dict|None)。返り値: dict。
    新生成5点はF1通知後の明示保存以外では開かない。
    """
    by_path, by_sha = registries()
    by_sha.update(current_catalog_refs())
    document = {d['復元先']: d for d in docs}
    existing = existing or {}
    groups = {key: [] for key in ('文書snapshot', '既存恒久正本', '共有入力', '共有コード又は文書', '保存済み参照', '新固定源', '意図して非複製')}
    bodies, verified = {}, set()
    for name, expected in items.items():
        path = Path(name)
        assert path.is_relative_to(ROOT), 'repository外は明示する'
        rel = path.relative_to(ROOT).as_posix()
        if rel in document:
            groups['文書snapshot'].append(document[rel])
            continue
        if rel in existing:
            assert existing[rel]['解凍SHA256'] == expected
            groups['保存済み参照'].append(existing[rel])
            continue
        if rel == 'work/122全場入力/入力.json' or path.suffix in ('.exe', '.csv', '.jsonl'):
            groups['意図して非複製'].append({'path': rel, 'sha256': expected, 'bytes': path.stat().st_size,
                                          '理由': '共用巨大入力/実行体/原価格は非複製。既存生成手順とGo源を参照'})
            continue
        if rel.startswith(('inputs/', 'study/')):
            assert file_sha(path) == expected
            groups['既存恒久正本'].append({'保存元': rel, '復元先': rel, '形式': '同体', '保存SHA256': expected,
                                          '解凍SHA256': expected, '保存bytes': path.stat().st_size, '解凍bytes': path.stat().st_size})
            continue
        ref = by_path.get(rel)
        if ref and ref['解凍SHA256'] == expected:
            stored = ROOT / ref['保存元']
            if stored not in verified:
                assert file_sha(stored) == ref['保存SHA256']
                verified.add(stored)
            groups['共有入力'].append(ref)
            continue
        if expected in by_sha:
            ref = {**by_sha[expected], '復元先': rel}
            if '保存元ZIP' in ref:
                packed = ROOT / ref['保存元ZIP']
                if packed not in verified:
                    assert file_sha(packed) == ref['ZIP_SHA256']
                    verified.add(packed)
                with zipfile.ZipFile(packed) as bundle:
                    assert sha(bundle.read(ref['ZIP内path'])) == expected
            elif ref.get('形式') != '文書snapshot':
                assert file_sha(ROOT / ref['保存元']) == ref['保存SHA256']
            groups['共有コード又は文書'].append(ref)
            continue
        assert path.stat().st_size < 1_000_000, (rel, '新大入力は通知後に明示gzip保存する')
        body = path.read_bytes()
        assert sha(body) == expected
        groups['新固定源'].append({'path': rel, 'sha256': expected, 'bytes': len(body)})
        bodies[rel] = body
    assert sum(len(group) for group in groups.values()) == len(items)
    target = FORMAL / '再現資料' / f'148{stage}の固定資料.zip'
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for name, body in sorted(bodies.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 12, 0, 0, 0))
            bundle.writestr(info, body, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    with zipfile.ZipFile(target) as bundle:
        assert {name: bundle.read(name) for name in bundle.namelist()} == bodies
    groups['固定ZIP'] = {'ZIP': target.name, 'ZIP_SHA256': file_sha(target), 'ZIP_bytes': target.stat().st_size,
                         '格納源数': len(bodies), '格納源': groups['新固定源']}
    return groups


# ----------------------------------------
def f0(path, fingerprint):
    """Root通知後にF0原文・コア3MD・全源の復元参照を保存する。

    引数: path(Path)、fingerprint(str)。返り値: None。
    生成5点・新金融・147Source解凍本文は開かない。
    """
    body = path.read_bytes()
    assert sha(body) == fingerprint
    frozen = json.loads(body)
    assert frozen['試行'] == TRIAL
    original = save(path, FORMAL / '検査/F0母集団前.json', fingerprint)
    snap, docs = snapshot(frozen, 'F0', fingerprint)
    groups = resolve(frozen['ファイル'], '母集団前', docs)
    index = {'試行': TRIAL, '段階': 'F0原文と全固定源参照を保存。生成5点/観測は未保存',
             'F0_SHA256': fingerprint, 'F0直接源数': len(frozen['ファイル']), 'F0原文': original,
             'F0文書原文': snap, 'F0復元参照': groups,
             '122巨大入力の復元': {'手順': 'study/00122_E0固定条件を全セッションで検証する/再現資料/再現手順.md',
                                  'SHA256': '6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec', '本文新複写/解析': False},
             '147Source共有': 'inputs/00147_中位価格位置と実体回復/Sourceの出生と取得.json.gz。解凍本文は本保存器で未読',
             '旧145共有': 'inputs/00145_構造イベントの入口/と旧145保管索引を参照',
             '最終選択取引数': None, 'データcase数を目標頻度へ代用': False,
             '正式3MD変更': False, '自然生成5点/新金融/Raw/追加2場読取': False}
    write(FORMAL / '保管索引.json', json_bytes(index))
    proof = {'成功': True, '試行': TRIAL, 'F0_SHA256': fingerprint, '全源数': len(frozen['ファイル']),
             '全復元参照解決': True, '正式コア3MD先退避': True, '100列は既存正本共有': True,
             '区分件数': {k: len(v) for k, v in groups.items() if isinstance(v, list)},
             '共有gzipは物理指紋と既保存解凍指紋を区別': True, '共有大本文の新解凍': False,
             '生成5点を開かない': True, '最終選択取引数': None, '重大不足': []}
    write(FORMAL / '検査/F0原文と源の保管確認.json', json_bytes(proof))


def f1(path, fingerprint, generated_dir):
    """Root通知後に生成5正本を各一度gzip保存しF1増分を解決する。

    引数: path/generated_dir(Path)、fingerprint(str)。返り値: None。
    観測/先着/金融を生成又は構造解析しない。
    """
    body = path.read_bytes()
    assert sha(body) == fingerprint
    frozen = json.loads(body)
    assert frozen['試行'] == TRIAL
    index_path = FORMAL / '保管索引.json'
    index = json.loads(index_path.read_bytes())
    prior = json.loads((ROOT / index['F0原文']['保存元']).read_bytes())
    assert all(frozen['ファイル'][name] == value for name, value in prior['ファイル'].items())
    original = save(path, FORMAL / '検査/F1観測前.json', fingerprint)
    snap, docs = snapshot(frozen, 'F1', fingerprint)
    additions = {name: value for name, value in frozen['ファイル'].items() if name not in prior['ファイル']}
    references = {index['F0原文']['復元先']: index['F0原文']}
    saved = []
    for name in GENERATED:
        source = generated_dir / name
        record = save(source, INPUTS / (name + '.gz'), frozen['ファイル'][str(source)], packed=True)
        saved.append(record)
        references[record['復元先']] = record
    groups = resolve(additions, '観測前追加', docs, references)
    index.update({'段階': 'F0/F1と生成5正本を保存。正逆観測と選択取引は未保存/未採用',
                  'F1_SHA256': fingerprint, 'F1直接源数': len(frozen['ファイル']), 'F1増分源数': len(additions),
                  'F1原文': original, 'F1文書原文': snap, '新共用入力': saved, 'F1増分復元参照': groups,
                  '最終選択取引数': None, 'データcase数を目標頻度へ代用': False})
    index_path.write_bytes(json_bytes(index))
