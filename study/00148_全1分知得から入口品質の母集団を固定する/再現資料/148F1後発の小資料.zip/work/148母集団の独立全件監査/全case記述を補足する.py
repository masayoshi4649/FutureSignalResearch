"""主監査を変更せず、eventから参照されない旧C1を含む全case記述を補足照合する。"""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
BASE = ROOT / 'work/148全1分母集団の評価/母集団生成'


def sha(path: Path) -> str:
    """
    機能: 許可された小さい固定case/参照のbytesを指紋化する。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 全case descriptorの方向・参照・旧C1 IDを全件照合する。
    引数: なし。返り値: None。主監査や自然生成物を変更せず新しい補足票だけ保存する。
    """
    fixed_path, meta_path = BASE / '固定取得入力.json', BASE / '入口参照.json'
    main_proof = HERE / '監査の確認.json'
    pins = {fixed_path: '12c43fe60e0ffd5ffa44bec7b5f7dd3d60bb92b291e0008db23587dcf19536d3',
            meta_path: '66511104a6efd7bc936b0e624469a2de43e9fa5b5fa7645304499f793c25329c',
            main_proof: 'e4d628a7e8887e4a1820f9dcc84ea380074d922710d0fc31af9c091afd835846'}
    assert all(sha(p) == h for p, h in pins.items())
    fixed, meta = json.loads(fixed_path.read_bytes()), json.loads(meta_path.read_bytes())
    cases = {e['id']: (s['session'], s['contract'], e['side']) for s in fixed['scenes'] for e in s['entries']}
    old_ids = {e['id'] for e in meta['entries']}
    pop = meta['population148']
    rows = {r['case_id']: r for r in pop['cases']}
    assert len(rows) == len(pop['cases']) == len(cases) == 31642
    assert set(rows) == set(cases) and len(old_ids) == 87
    for cid, (sid, contract, side) in cases.items():
        r = rows[cid]
        assert (r['session'], r['contract'], r['original_side']) == (sid, contract, side)
        assert (r['buy_stream'], r['sell_stream']) == (('original', 'reverse') if side == 1 else ('reverse', 'original'))
        assert r['c1_reused'] is (cid in old_ids)
        if cid in old_ids:
            assert r['legacy_entry_id'] == cid and r['canonical_event_id'] == ''
        else:
            assert side == 1 and r['legacy_entry_id'] == '' and r['canonical_event_id']
    used = {r['case_id'] for r in pop['event_case_links']}
    unused = set(cases) - used
    assert len(unused) == 10 and unused <= old_ids
    assert all(sha(p) == h for p, h in pins.items())
    proof = {'成功': True, '試行': 148, '主監査SHA256': pins[main_proof],
             '全case記述': len(cases), '全ID集合/全方向/全stream/旧ID保持': True,
             'eventから未参照の旧C1case': len(unused), '主監査/生成物変更': False,
             'Raw/金融/追加2場読取': False, 'コードSHA256': sha(Path(__file__))}
    target = HERE / '全case記述の補足.json'
    target.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'補足票SHA256': sha(target), '全case': len(cases), '未参照旧C1': len(unused)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
