"""148のF1外の生成確認・性能・監査補足を小型ZIPへ一度保管する。"""
from pathlib import Path
import hashlib
import json
import zipfile
from 保存部品 import ROOT, FORMAL, file_sha, registries, json_bytes


def main():
    """小型証跡のbytesを保存し、共有算術とF1主監査の参照を残す。

    引数: なし。返り値: None。Rawや自然金融JSONは開かず、監査コードも実行しない。
    """
    here = Path(__file__).resolve().parent
    runtime = ROOT / 'work/148全1分母集団の評価'
    audit = ROOT / 'work/148母集団の独立全件監査'
    source_paths = [runtime / name for name in (
        '生成の完了.json', '生成の実行性能.json', '母集団生成/生成の確認.json',
        '観測の完了.json', '全case観測の実行性能.json')]
    source_paths += [audit / '全case記述を補足する.py', audit / '全case記述の補足.json',
                     ROOT / 'work/148母集団の金融診断を独立に照合する.py',
                     here / 'F1保管を確認する.py', here / '観測を一度保存する.py',
                     here / '生成5正本の保管計画.json', Path(__file__)]
    assert file_sha(audit / '全case記述の補足.json') == '7419950437e76fe916aa19b9946341d1ea3a90e622abb6d2e8b43e5dd9be636c'
    assert all(path.stat().st_size < 1_000_000 for path in source_paths)
    before = {path: file_sha(path) for path in source_paths}
    target = FORMAL / '再現資料/148F1後発の小資料.zip'
    entries = []
    with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for path in source_paths:
            name = path.relative_to(ROOT).as_posix()
            body = path.read_bytes()
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 12, 0, 0, 0))
            bundle.writestr(info, body, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
            entries.append({'path': name, 'bytes': len(body), 'sha256': before[path]})
    with zipfile.ZipFile(target) as bundle:
        for item in entries:
            assert hashlib.sha256(bundle.read(item['path'])).hexdigest() == item['sha256']
    assert before == {path: file_sha(path) for path in source_paths}
    _, shared = registries()
    helper_sha = '30bd4aef8c2809699cb013f930cfbce152f3986fe8d3d3cc6b49452104c2269e'
    assert helper_sha in shared
    index_path = FORMAL / '保管索引.json'
    index = json.loads(index_path.read_bytes())
    index['F1後発小資料'] = {'区分': 'F1一覧外の生成確認/性能/全case補足/保存器。事前固定への後付けではない',
        '保存元ZIP': target.relative_to(ROOT).as_posix(), 'ZIP_SHA256': file_sha(target),
        'ZIP_bytes': target.stat().st_size, '格納源': entries,
        '主独立監査': '主コードとe4d628a7票はF1追加固定ZIP内で共有し、ここへ再複製しない',
        '補足SHA256': '7419950437e76fe916aa19b9946341d1ea3a90e622abb6d2e8b43e5dd9be636c',
        'Root金融監査コード': '本保存時点版。まだ実行せず、将来の確定票と指紋で再照合する'}
    index['Root金融監査の共有算術'] = {**shared[helper_sha], '復元先': 'work/141金融集計を独立に確認する.py'}
    proof_path = FORMAL / '検査/F1全源の復元参照確認.json'
    proof = json.loads(proof_path.read_bytes())
    index['F1復元照合'] = {'保存元': proof_path.relative_to(ROOT).as_posix(), 'SHA256': file_sha(proof_path),
                         '全源数': proof['全源数'], '保存bytes一致': proof['保存bytes復元一致数'], '非複製': proof['意図して非複製数']}
    index_path.write_bytes(json_bytes(index))
    print('zip_sha256=' + file_sha(target))
    print('index_sha256=' + file_sha(index_path))
    print('files=' + str(len(entries)))


if __name__ == '__main__':
    main()
