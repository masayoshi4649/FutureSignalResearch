"""148の観測完了通知後、正本を一度だけストリームgzip保存する。"""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
from 保存部品 import FORMAL, ROOT, save, file_sha, json_bytes


def main():
    """通知指紋を照合して観測gzipと保存票を作る。

    引数: --result(Path)、--sha256(str)、--notice(Path)。返り値: None。
    842MB等のJSONを構造解析・再転記せず、解凍もチャンクで照合する。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--result', required=True, type=Path)
    parser.add_argument('--sha256', required=True)
    parser.add_argument('--notice', required=True, type=Path)
    args = parser.parse_args()
    source, notice_path = args.result.resolve(), args.notice.resolve()
    notice = json.loads(notice_path.read_bytes())
    assert notice['成功'] and notice['試行'] == 148 and notice['結果SHA256'] == args.sha256
    index_path = FORMAL / '保管索引.json'
    index = json.loads(index_path.read_bytes())
    assert notice['F1_SHA256'] == index['F1_SHA256']
    assert source.stat().st_size == notice['観測JSON_bytes']
    record = save(source, FORMAL / '成果物/固定取得の正逆観測.json.gz', args.sha256, True)
    digest, count = hashlib.sha256(), 0
    with gzip.open(ROOT / record['保存元'], 'rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
            count += len(chunk)
    assert digest.hexdigest() == args.sha256 and count == source.stat().st_size
    index['保存済み正逆観測'] = record
    index['段階'] = 'F0/F1/生成5正本/全case観測を保存。集計/売買選択は未保存又は未採用'
    index['観測保存の区分'] = '全caseの両側観測。最終選択取引数/目標頻度の達成とは別'
    index_path.write_bytes(json_bytes(index))
    proof = {'成功': True, '試行': 148, 'F1_SHA256': index['F1_SHA256'], '保存観測': record,
             'gzip解凍をストリーム照合': True, 'JSON本文の構造解析': False, '金融集計実行': False,
             '自然RawやSource再実行': False, '観測通知SHA256': file_sha(notice_path),
             '最終選択取引数': None, 'case数を目標頻度へ代用': False, '正式3MD変更': False}
    target = FORMAL / '検査/観測gzipの保存確認.json'
    assert not target.exists()
    target.write_bytes(json_bytes(proof))
    print('proof_sha256=' + file_sha(target))
    print('gzip_sha256=' + record['保存SHA256'])
    print('gzip_bytes=' + str(record['保存bytes']))


if __name__ == '__main__':
    main()
