"""148の保存bytesとF1全参照を照合し、JSON成績やRawは再計算しない。"""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import zipfile
from 保存部品 import ROOT, FORMAL, CORE, file_sha, json_bytes


def stream_digest(stream):
    """展開bytesを保存せず指紋化する。

    引数: stream(binary stream)。返り値: tuple(str,int)はSHAとサイズ。
    """
    digest, count = hashlib.sha256(), 0
    for chunk in iter(lambda: stream.read(1024 * 1024), b''):
        digest.update(chunk)
        count += len(chunk)
    return digest.hexdigest(), count


def main():
    """F1と保存台帳から全95等の可変源を回収照合する。

    引数: --f1-sha256(str)。返り値: None。生成/金融JSON本文は解析しない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--f1-sha256', required=True)
    args = parser.parse_args()
    index = json.loads((FORMAL / '保管索引.json').read_bytes())
    assert index['F1_SHA256'] == args.f1_sha256
    f1_path = ROOT / index['F1原文']['保存元']
    assert file_sha(f1_path) == args.f1_sha256
    frozen = json.loads(f1_path.read_bytes())
    expected = {Path(name).relative_to(ROOT).as_posix(): digest for name, digest in frozen['ファイル'].items()}
    all_refs, exempt = {}, {}
    for stage in ('F0復元参照', 'F1増分復元参照'):
        groups = index[stage]
        for kind, items in groups.items():
            if not isinstance(items, list):
                continue
            for item in items:
                if kind == '意図して非複製':
                    exempt[item['path']] = item
                elif kind == '新固定源':
                    all_refs[item['path']] = {
                        '保存元ZIP': (FORMAL / '再現資料' / groups['固定ZIP']['ZIP']).relative_to(ROOT).as_posix(),
                        'ZIP_SHA256': groups['固定ZIP']['ZIP_SHA256'], 'ZIP内path': item['path'], 'sha256': item['sha256']}
                else:
                    all_refs[item['復元先']] = item
    assert set(all_refs).isdisjoint(exempt) and set(all_refs) | set(exempt) == set(expected)
    checked_files, snapshots, outcomes = {}, {}, []

    def stored_ok(path, digest):
        """同じ保存物の物理指紋を一度だけ確認する。

        引数: path(Path)、digest(str)。返り値: None。
        """
        if path not in checked_files:
            checked_files[path] = file_sha(path)
        assert checked_files[path] == digest, str(path)

    for target, ref in all_refs.items():
        wanted = expected[target]
        if '保存元ZIP' in ref:
            path = ROOT / ref['保存元ZIP']
            stored_ok(path, ref['ZIP_SHA256'])
            with zipfile.ZipFile(path) as bundle, bundle.open(ref['ZIP内path']) as stream:
                actual, size = stream_digest(stream)
            method = 'ZIP源bytes'
        else:
            path = ROOT / ref['保存元']
            if '保存SHA256' in ref:
                stored_ok(path, ref['保存SHA256'])
            method = ref['形式']
            if method == '文書snapshot':
                if path not in snapshots:
                    with gzip.open(path, 'rb') as stream:
                        snapshot = json.load(stream)
                    snapshots[path] = {item['path']: item['本文'].encode('utf-8') for item in snapshot['文書']}
                body = snapshots[path][ref['抽出キー']]
                actual, size = hashlib.sha256(body).hexdigest(), len(body)
            elif method == '先頭bytes':
                with path.open('rb') as stream:
                    body = stream.read(ref['抽出bytes'])
                actual, size = hashlib.sha256(body).hexdigest(), len(body)
            elif method == 'gzip':
                with gzip.open(path, 'rb') as stream:
                    actual, size = stream_digest(stream)
            else:
                assert method == '同体'
                actual, size = file_sha(path), path.stat().st_size
        assert actual == wanted, (target, actual, wanted)
        outcomes.append({'復元先': target, '方式': method, 'bytes': size, 'sha256': actual})
    for target, ref in exempt.items():
        path = ROOT / target
        assert path.is_file() and path.stat().st_size == ref['bytes']
        assert ref['sha256'] == expected[target]
    for name in CORE:
        path = FORMAL / name
        assert file_sha(path) == expected[path.relative_to(ROOT).as_posix()]
    for stage in ('F0', 'F1'):
        with gzip.open(FORMAL / '検査' / (stage + '実行前文書.json.gz'), 'rb') as stream:
            snapshot = json.load(stream)
        assert len(snapshot['文書']) == 3
        for item in snapshot['文書']:
            assert hashlib.sha256(item['本文'].encode('utf-8')).hexdigest() == item['sha256']
    proof = {'成功': True, '試行': 148, 'F1_SHA256': args.f1_sha256, '全源数': len(expected),
             '保存bytes復元一致数': len(outcomes), '意図して非複製数': len(exempt),
             '全参照が保存又は明示非複製': True, '正式3MD前後同体': True,
             '生成5gzip解凍指紋一致': True, '生成JSONや金融の内容再計算': False,
             'Raw/147Source解凍本文/追加2場読取': False, '最終選択取引数': None,
             'case数を達成頻度へ代用': False, '復元照合': outcomes, '非複製': list(exempt.values()), '重大不足': []}
    path = FORMAL / '検査/F1全源の復元参照確認.json'
    assert not path.exists()
    path.write_bytes(json_bytes(proof))
    print('proof_sha256=' + file_sha(path))
    print('recovered=' + str(len(outcomes)))
    print('noncopied=' + str(len(exempt)))


if __name__ == '__main__':
    main()
