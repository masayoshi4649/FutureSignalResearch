"""148の選別前母集団の金融診断を、作者の集計コードを共有せず照合する。"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import math

ROOT = Path(__file__).resolve().parent.parent


def sha(path: Path) -> str:
    """
    機能: 保存bytesを全保持せずSHA256を計算する。
    引数: path(Path)は対象。
    返り値: strは指紋。
    """
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


# ----------------------------------------
def independent_calculator() -> object:
    """
    機能: 141の別実装の算術のみを固定SHAで読み込む。
    引数: なし。
    返り値: objectはcalculate関数を持つモジュール。
    """
    path = ROOT / 'work/141金融集計を独立に確認する.py'
    assert sha(path) == '30bd4aef8c2809699cb013f930cfbce152f3986fe8d3d3cc6b49452104c2269e'
    spec = importlib.util.spec_from_file_location('独立141算術', path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


# ----------------------------------------
def compare_stats(expected: dict, actual: dict, label: tuple) -> int:
    """
    機能: 既知/未知・全先着計数・費用後金額を全キー照合する。
    引数: expected/actual(dict)、label(tuple)は診断用の比較名。
    返り値: intは照合キー数。
    """
    assert set(expected) == set(actual), (label, set(expected) ^ set(actual))
    for key, value in expected.items():
        if isinstance(value, float):
            assert math.isclose(value, actual[key], rel_tol=1e-12, abs_tol=1e-9), (label, key, value, actual[key])
        else:
            assert value == actual[key], (label, key, value, actual[key])
    return len(expected)


# ----------------------------------------
def main() -> None:
    """
    機能: 148の300比較と旧87の全観測を保存JSONだけから検算する。
    引数: CLI folder/summary/output(Path)は評価先・作者集計・未作成確認票。
    返り値: None。Raw・100特徴・追加場を読まず、売買条件は選択しない。
    """
    parser = argparse.ArgumentParser(description='148母集団の金融診断の独立照合')
    parser.add_argument('--folder', type=Path, required=True)
    parser.add_argument('--summary', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    generated = args.folder / '母集団生成'
    paths = {'fixed': generated / '固定取得入力.json', 'metadata': generated / '入口参照.json',
             'captures': generated / '取得対応.json', 'result': args.folder / '固定取得の正逆観測.json',
             'summary': args.summary, 'f1': args.folder / 'F1全case観測前.json',
             'old_result': ROOT / 'work/145構造イベントの評価/固定取得の正逆観測.json'}
    before = {key: sha(path) for key, path in paths.items()}
    fixed, metadata, captures, result, summary, f1, old_result = [json.loads(paths[key].read_bytes())
        for key in ('fixed', 'metadata', 'captures', 'result', 'summary', 'f1', 'old_result')]
    assert metadata['trial'] == summary['試行'] == 148 and result['trial'] == 133
    assert before['fixed'] == metadata['fixed_input_sha256'] == result['input_sha256']
    assert all(f1['ファイル'][str(paths[key].resolve())] == before[key] for key in ('fixed', 'metadata', 'captures'))
    assert before['old_result'] == '3b92da8b447d7be9ead6a2a112759ca7272a1e65d6cb5516989e3faf50c54d62'
    sessions = [scene['session'] for scene in fixed['scenes']]
    assert sessions == metadata['sessions'] == captures['sessions'] and len(sessions) == 73
    cases = {case['id']: (scene['session'], case) for scene in result['scenes'] for case in scene['cases']}
    old_cases = {case['id']: (scene['session'], case) for scene in old_result['scenes'] for case in scene['cases']}
    assert len(cases) == fixed['expected_entry_count'] == 31642
    assert len(old_cases) == 87 and all(cases[key] == value for key, value in old_cases.items())
    old_entries = {entry['id']: entry for entry in metadata['entries']}
    c0 = {key for key, entry in old_entries.items() if entry['model'] == 'C0'}
    c1 = set(old_cases)
    mother = {row['case_id'] for row in captures['rows'] if row['status'] == 'filled'}
    assert len(c0) == 81 and len(c1) == 87 and len(mother) == 31632
    assert len(mother & c1) == 77 and len(mother - c1) == 31555
    buy_cases = {}
    for key in mother:
        session, original = cases[key]
        if original['original_side'] == 1:
            buy_cases[key] = (session, original)
        else:
            normalized = dict(original)
            normalized.update(original=original['reverse'], reverse=original['original'],
                chart_original=original['chart_reverse'], chart_reverse=original['chart_original'])
            buy_cases[key] = (session, normalized)
        assert buy_cases[key][1]['original']['birth']['side'] == 1
        assert buy_cases[key][1]['reverse']['birth']['side'] == -1
    calculator = independent_calculator()
    comparisons = cells = 0
    coverage = {}
    for part, target_sessions in (('all', sessions), ('train', sessions[:48]), ('validation', sessions[48:])):
        target_set = set(target_sessions)
        hours = sum((scene['end'] - 300 - scene['start']) / 3600 for scene in fixed['scenes'] if scene['session'] in target_set)
        for policy in ('C0', 'C1', 'RC1', 'BUY', 'SELL'):
            members = c0 if policy == 'C0' else c1 if policy in ('C1', 'RC1') else mother
            source = buy_cases if policy in ('BUY', 'SELL') else cases
            selected = [source[key] for key in sorted(members) if source[key][0] in target_set]
            present = {session for session, _ in selected}
            coverage[part + '/' + policy] = {'対象場': len(target_sessions), '取得可能case数': len(selected),
                '取得可能場': len(present), '未取得場': [session for session in target_sessions if session not in present],
                '取得可能件数毎時': len(selected) / hours, '選択取引数': None, '選択頻度': None}
            for axis in ('BBO', 'Last'):
                for horizon in (1800, 3600):
                    for width in (25, 50, 100, 125, 200):
                        expected = calculator.calculate(selected, policy in ('RC1', 'SELL'), axis, horizon, width)
                        actual = summary['集計'][part][policy][axis][str(horizon)][str(width)]
                        cells += compare_stats(expected, actual, (part, policy, axis, horizon, width))
                        comparisons += 1
    assert comparisons == 300
    assert all(sha(path) == before[key] for key, path in paths.items())
    output = {'成功': True, '試行': 148, '比較数': comparisons, '統計キー数': cells,
        '旧87全4streamの値一致': True, '母集団unique': len(mother), '売買の実側対応': True,
        '選択取引数': None, '選択頻度': None, '売買政策の合格判定': None,
        '近接窓を独立標本と主張しない': True, '作者の124集計をimport': False,
        '自然原板再走査': False, '参加と頻度の独立再算': coverage,
        '入力': {str(path.resolve()): before[key] for key, path in paths.items()}}
    with args.output.open('x', encoding='utf-8', newline='\n') as target:
        json.dump(output, target, ensure_ascii=False, indent=2, allow_nan=False)
        target.write('\n')
    print(json.dumps({'成功': True, '比較数': comparisons, '統計キー数': cells}, ensure_ascii=False))


if __name__ == '__main__':
    main()
