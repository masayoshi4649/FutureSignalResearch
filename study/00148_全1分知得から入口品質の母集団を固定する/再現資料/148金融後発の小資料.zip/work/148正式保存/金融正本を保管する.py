"""148の金融診断F2・正本・検算履歴を保存し、既存大観測は共有する。"""
from pathlib import Path
import json
import zipfile
from 保存部品 import ROOT, FORMAL, save, resolve, file_sha, json_bytes


def main():
    """通知された金融完成物を各一度保存する。

    引数: なし。返り値: None。金融算術は再計算せず、正式3MDは変更しない。
    """
    runtime = ROOT / 'work/148全1分母集団の評価'
    folder = runtime / '金融診断'
    index_path = FORMAL / '保管索引.json'
    index = json.loads(index_path.read_bytes())
    f2 = runtime / 'F2診断集計前.json'
    f2_sha = file_sha(f2)
    assert f2_sha == '00f1061e6a43450bd1a596056fec84ca912e06ab7e09a37ec23b955c46cdfb4b'
    frozen = json.loads(f2.read_bytes())
    assert frozen['試行'] == 148
    completion = json.loads((folder / '集計完了.json').read_bytes())
    assert completion['成功']
    summary = json.loads((folder / '集計.json').read_bytes())
    assert summary['成功'] and summary['主政策'] is None and summary['選択trade数'] is None
    assert summary['F1_SHA256'] == index['F1_SHA256']
    # F2に正式MDは含まれない。編集前原文の根拠はF0/F1 snapshotと同体確認に置く。
    f1 = json.loads((ROOT / index['F1原文']['保存元']).read_bytes())
    for name in ('README.md', '条件.md', '設定と結果.md'):
        path = FORMAL / name
        assert file_sha(path) == f1['ファイル'][str(path)]
    f2_record = save(f2, FORMAL / '検査/F2診断集計前.json', f2_sha)
    groups = resolve(frozen['ファイル'], '診断集計前', [])
    summary_record = save(folder / '集計.json', FORMAL / '成果物/集計.json', completion['集計SHA256'])
    table_record = save(folder / 'CSV用の表.json', FORMAL / '成果物/CSV用の表.json.gz', completion['表SHA256'], True)
    extras = []
    for name, target in (
        ('集計完了.json', '成果物/集計完了.json'),
        ('独立検算.json', '検査/金融独立検算.json'),
        ('独立検算の修正前固定.json', '検査/独立検算の修正前固定.json')):
        path = folder / name
        extras.append(save(path, FORMAL / target, file_sha(path)))
    checker = ROOT / 'work/148母集団の金融診断を独立に照合する_版2.py'
    assert file_sha(checker) == '4ad86a23d195c4da4fdedd26a265c7523df7c95230e06ed5f40048a076241be5'
    zip_path = FORMAL / '再現資料/148金融後発の小資料.zip'
    entries = []
    with zipfile.ZipFile(zip_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for path in (checker, Path(__file__), Path(__file__).with_name('保存部品.py')):
            body, name = path.read_bytes(), path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 12, 0, 0, 0))
            bundle.writestr(info, body, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
            entries.append({'path': name, 'bytes': len(body), 'sha256': file_sha(path)})
    independent = json.loads((folder / '独立検算.json').read_bytes())
    assert independent['成功'] and independent['比較数'] == 300 and independent['統計キー数'] == 7200
    index.update({'段階': '母集団生成/全case観測/金融診断まで保存。正式結果とCSV最終確認は別途',
                  'F2_SHA256': f2_sha, 'F2原文': f2_record, 'F2直接源数': len(frozen['ファイル']),
                  'F2復元参照': groups, '保存金融正本': summary_record, '保存CSV用の表': table_record,
                  '金融完成票と独立票': extras,
                  '金融後発小資料': {'保存元ZIP': zip_path.relative_to(ROOT).as_posix(), 'ZIP_SHA256': file_sha(zip_path),
                                    'ZIP_bytes': zip_path.stat().st_size, '格納源': entries,
                                    '区分': 'F2旧checkerを変更せず、flipsメタの意味修正だけを別版で記録'},
                  '診断主政策': None, '最終選択取引数': None, '新選択共同目標': None,
                  '金融診断は運用収支': False, '元準備票とUTF8補正票': 'F2源として両方保持・元票不変更'})
    index_path.write_bytes(json_bytes(index))
    proof = {'成功': True, '試行': 148, 'F2_SHA256': f2_sha, 'F2全源数': len(frozen['ファイル']),
             'F2全源参照解決': True, '集計SHA256': summary_record['解凍SHA256'], '表SHA256': table_record['解凍SHA256'],
             '独立比較数': 300, '独立統計キー数': 7200, '旧87全4stream同体': independent['旧87全4streamの値一致'],
             '正式3MD未変更': True, '新Raw走査又は追加2場読取': False,
             '保存大観測を再複製': False, '選択trade数': None, '運用収支': False,
             '保管索引SHA256': file_sha(index_path), '重大不足': []}
    path = FORMAL / '検査/金融正本の保管確認.json'
    assert not path.exists()
    path.write_bytes(json_bytes(proof))
    print('proof_sha256=' + file_sha(path))
    print('index_sha256=' + file_sha(index_path))


if __name__ == '__main__':
    main()
