"""148の保存観測を方向正規化し、無選択の母集団診断300比較へ集計する。"""
from collections import Counter
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import math
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
ARITHMETIC=ROOT/'work/124入口の原因分析/集計する.py'
OLD_PAIRS=ROOT/'work/145構造イベントの評価/固定取得の正逆観測.json'
OLD_SUMMARY=ROOT/'work/145構造イベントの評価/金融評価/集計.json'
SOURCES={ARITHMETIC:'8479ca348231ffd77a637360797750833c9e6617c7fc4a6502e015c7a1d9f04a',
         OLD_PAIRS:'3b92da8b447d7be9ead6a2a112759ca7272a1e65d6cb5516989e3faf50c54d62',
         OLD_SUMMARY:'fb374d53982ce7727c5ae936d72a20a973029de35480ed442a6cb2305fc9c861'}
POLICIES=('C0','C1','RC1','BUY','SELL')
AXES=('BBO','Last');HORIZONS=(1800,3600);WIDTHS=(25,50,100,125,200)
COMPARISON_HEADERS=['試行','区分','政策','観測集合','価格軸','評価分','同幅pt','対象場数','取得場数','unique観測case数','格納原側相対反転数','全場観測caseあり',
 '全H完了','観測不足','順行先着','逆行先着','両方未到達','到達済み順行率','完了分母順行率','全case分母順行率','到達済み70%数値','新選択の参加率共同判定',
 '取得可能case毎時','選択後trade毎時','取得可能case毎時1以上','新選択三目標判定','IFD代用既知','IFD代用未知','C0代用差引円','C5代用利益円','C5代用損失絶対円','C5代用差引円','C5代用平均円','C5代用PF']
DETAIL_HEADERS=['試行','参考区分','セッション','限月','q0eventID','q0JST','q0採用index','q0物理行','最新1分ID','最新1分EndJST','同Raw配送足数','履歴slot数','出生適格','不適格理由',
 '特徴生成','feature_ref','q0正常BBO','q0Last','q0Bid','q0Ask','取得状態','取得期限JST','q1JST','q1採用index','q1物理行','q1Last','q1Bid','q1Ask','q0からq1秒','観測caseID','C1case再用','同case参照event数','買stream','売stream']
for side in ('買','売'):DETAIL_HEADERS += [side+x for x in ('方向','125H状態','125記録到達方向','125完了分母方向','125最初到達JST','IFD既知','IFD清算','IFD清算JST','125C5代用円')]
SCENE_HEADERS=['試行','セッション','参考区分','ザラバ時間h','名目新規可時間h','全親1分数','全q0台帳数','出生適格_X数','不適格q0数','取得event数','unique取得可能q1数','同q1共有追加event数',
 'price未知q0','未closedq0','staleq0','末尾q0','TTL未取得','L未取得','品質喪失未取得','EOF未取得','取得可能q1毎時','選択trade数','選択trade毎時','選択待機数','新選択共同目標判定']
for policy in POLICIES:SCENE_HEADERS += [policy+x for x in ('観測case数','125順','125逆','125未到達','125不足','IFD既知','IFD未知','C5利益','C5損失絶対','C5代用差引')]


def sha(path: Path) -> str:
    """
    機能: 大型観測も固定bufferで指紋を求める。
    引数: path(Path)。返り値: str。
    """
    h=hashlib.sha256()
    with path.open('rb')as source:
        for body in iter(lambda:source.read(1<<20),b''):h.update(body)
    return h.hexdigest()


def save(path: Path,value) -> None:
    """
    機能: 未作成のJSONだけをUTF-8で保存する。
    引数: path(Path)、value(object)。返り値: None。
    """
    with path.open('x',encoding='utf-8')as target:json.dump(value,target,ensure_ascii=False,indent=2);target.write('\n')


def selected(record: dict,policy: str,axis: str) -> dict:
    """
    機能: 格納方向を売買又は旧対照の方向へ明示正規化する。
    引数: record(dict)、policy/axis(str)。返り値: dict。
    """
    case=record['case'];side=case['original_side']
    reverse=policy=='RC1' or policy=='BUY' and side==-1 or policy=='SELL' and side==1
    return case[('chart_'if axis=='Last'else '')+('reverse'if reverse else 'original')]


def load_arithmetic():
    """
    機能: 作者124算術だけを私有importし選択関数を差し替える。
    引数: なし。返り値: ModuleType。
    """
    assert sha(ARITHMETIC)==SOURCES[ARITHMETIC]
    spec=importlib.util.spec_from_file_location('private124for148',ARITHMETIC);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value)
    value.selected=selected;value.POLICIES=POLICIES;return value


def membership(metadata: dict) -> dict:
    """
    機能: 旧81/87と取得eventのunique caseを加算せず集合化する。
    引数: metadata(dict)。返り値: dict[str,set]。
    """
    old={e['id']for e in metadata['entries']};baseline={e['id']for e in metadata['entries']if e.get('baseline')is True}
    pop=metadata['population148'];unique={link['case_id']for link in pop['event_case_links']}
    assert len(old)==87 and len(baseline)==81 and baseline<=old
    assert len(unique)==pop['counts']['population_unique_q1']
    return {'C0':baseline,'C1':old,'RC1':old,'BUY':unique,'SELL':unique}


def prepare(result: dict,fixed: dict,metadata: dict,ledger: dict,capture: dict,strict: bool=True) -> tuple:
    """
    機能: 生成5点と正逆観測を全case/原行で結合しphaseを検査する。
    引数: result/fixed/metadata/ledger/capture(dict)、strict(bool)。返り値: tuple。
    """
    assert result['success'] and result['trial']==133 and metadata['trial']==ledger['trial']==capture['trial']==148
    assert result['input_sha256']==metadata['fixed_input_sha256']
    sessions=metadata['sessions'];assert sessions==ledger['sessions']==capture['sessions'] and len(sessions)==73
    descriptors={d['case_id']:d for d in metadata['population148']['cases']};members=membership(metadata)
    all_records={};phase=Counter()
    for observed,scene in zip(result['scenes'],fixed['scenes']):
        sid=scene['session'];assert sid==observed['session'] and observed['success']
        assert observed['actual_sha256']==scene['raw']['sha256'] and observed['quality']==observed['expected_quality']==scene['expected_quality'] and observed['stat_before']==observed['stat_after']
        end=scene['end']-300;limit=min(scene['force_close'],scene['end']-3900)
        assert observed['execution_end']==end and observed['effective_entry_limit']==limit
        entries={e['id']:e for e in scene['entries']};assert len(entries)==len(observed['cases'])
        for case in observed['cases']:
            key=case['id'];assert key not in all_records and key in entries and key in descriptors;e=entries[key];q=e['entry'];d=descriptors[key]
            assert d['session']==sid and d['contract']==scene['contract'] and d['original_side']==e['side']==case['original_side'] and q['time']<limit
            assert q['quote_ok'] and 0<q['bid']<q['ask']
            for name in ('original','reverse','chart_original','chart_reverse'):
                stream=case[name];side=e['side']if name.endswith('original')else -e['side'];chart=name.startswith('chart')
                assert stream['status']=='filled' and stream['entry']==q and stream['birth']['side']==side
                assert stream['entry_price']==(q['last']if chart else q['ask']if side==1 else q['bid']);phase['stream']+=1
                assert [o['seconds']for o in stream['outcomes']]==list(HORIZONS)
                for o in stream['outcomes']:
                    assert o['deadline']==q['time']+o['seconds'] and [t['width']for t in o['touches']]==list(WIDTHS)
                    assert (o['endpoint']is not None)==(o['status']=='complete')
                    if o['endpoint']:
                        x=o['endpoint'];assert o['deadline']<=x['time']<=o['deadline']+30 and x['time']<end;phase['endpoint']+=1
                    for touch in o['touches']:
                        assert touch['direction']in (-1,0,1) and (touch['quote']is None)==(touch['direction']==0)
                        if touch['quote']:
                            x=touch['quote'];assert q['time']<=x['time']<=o['deadline'] and x['time']<end and x['index']>q['index'] and x['source_line']>q['source_line'];phase['touch']+=1
                    if chart:assert o['net0']is None and o['net5']is None
            all_records[key]={'session':sid,'case':case,'scene':scene}
    assert set(all_records)==set(descriptors) and len(all_records)==fixed['expected_entry_count']==result['source_entry_count']
    assert all(ids<=set(all_records)for ids in members.values())
    q0={r['event_id']:r for r in ledger['rows']};captures={r['event_id']:r for r in capture['rows']};links={r['event_id']:r for r in metadata['population148']['event_case_links']}
    assert len(q0)==len(ledger['rows']) and len(captures)==len(capture['rows'])
    assert set(captures)=={key for key,row in q0.items()if row['eligible']}
    assert set(links)=={key for key,row in captures.items()if row['status']=='filled'}
    for key,row in captures.items():
        l=q0[key];assert row['q0']==l['q0'] and row['session']==l['session'] and row['contract']==l['contract'] and l['feature_ref']is not None and l['feature_generated']
        if key not in links:assert row['case_id']is None and row['q1']is None;continue
        link=links[key];record=all_records[link['case_id']];assert row['case_id']==link['case_id'] and row['q1']==record['case']['original']['entry']
        assert row['buy_stream']==link['buy_stream'] and row['sell_stream']==link['sell_stream']
        assert link['buy_stream']==('original'if record['case']['original_side']==1 else 'reverse')
        assert row['q1']['time']>=row['q0']['time']+1 and row['q1']['time']<row['expires']
    for row in q0.values():
        if not row['eligible']:assert row['feature_ref']is None and not row['feature_generated']
    if strict:assert len(q0)==40544 and len(all_records)==31642 and len(members['BUY'])==31632
    return all_records,members,sessions,dict(phase)


def calculate(records: dict,members: dict,sessions: list,scenes: list,module) -> tuple:
    """
    機能: 300診断を既使用48/25に分け、選択後の合格をnullに保つ。
    引数: records/members(dict)、sessions/scenes(list)、module(ModuleType)。返り値: tuple。
    """
    values={};participation={};frequency={}
    for part,scope in [('all',sessions),('train',sessions[:48]),('validation',sessions[48:])]:
        values[part]={};participation[part]={};frequency[part]={};hours=sum((s['end']-300-s['start'])/3600 for s in scenes if s['session']in scope)
        available_hours=sum((min(s['force_close'],s['end']-3900)-s['start'])/3600 for s in scenes if s['session']in scope)
        for policy in POLICIES:
            rows=[r for key,r in records.items()if key in members[policy] and r['session']in scope];present={r['session']for r in rows}
            values[part][policy]={axis:{str(h):{str(w):module.stats(rows,policy,axis,h,w)for w in WIDTHS}for h in HORIZONS}for axis in AXES}
            participation[part][policy]={'対象場数':len(scope),'取得数':len(rows),'取得場数':len(present),'未取得場':[s for s in scope if s not in present],'全場最低1取得':len(present)==len(scope)}
            frequency[part][policy]={'全時間h':hours,'名目新規可時間h':available_hours,'取得可能case毎時':len(rows)/hours if hours else None,'名目新規可時間case毎時':len(rows)/available_hours if available_hours else None,'選択trade数':None,'選択trade毎時':None}
    return values,participation,frequency


def baseline_check(records: dict,values: dict,old: dict,old_summary: dict,members: dict) -> dict:
    """
    機能: 旧C1全87の4streamと既存C0/C1/実逆の60条件を保持する。
    引数: records/values/old/old_summary/members(dict)。返り値: dict。
    """
    previous={c['id']:(s['session'],c)for s in old['scenes']for c in s['cases']};assert len(previous)==87 and set(previous)==members['C1']
    checks=0
    for key in previous:
        sid,c=previous[key];r=records[key];assert r['session']==sid and r['case']==c;checks+=4
    for part in ('all','train','validation'):
        for policy,old_policy in [('C0','C0'),('C1','U0'),('RC1','RU')]:
            for axis in AXES:
                for h in HORIZONS:
                    for w in WIDTHS:
                        a=values[part][policy][axis][str(h)][str(w)];b=old_summary['集計'][part][old_policy][axis][str(h)][str(w)]
                        for field,value in a.items():
                            if field=='flips':continue
                            expected=b[field]
                            if isinstance(value,float):assert math.isclose(value,expected,rel_tol=1e-12,abs_tol=1e-8),(part,policy,field)
                            else:assert value==expected,(part,policy,axis,h,w,field)
    return {'成功':True,'旧C1件数':87,'全4stream同体数':checks,'保存全case同体':True,'C0_C1_RC1全180条件_反転基準以外同体':True}


def tables(records: dict,members: dict,sessions: list,values: dict,participation: dict,freq: dict,ledger: dict,capture: dict,metadata: dict,module) -> list:
    """
    機能: 300比較/全q0/73場を型付きセルだけの既存三表契約へ写す。
    引数: 結合済みdict/listとmodule。返り値: list[dict]。
    """
    comparison=[]
    for part in ('all','train','validation'):
        for policy in POLICIES:
            p=participation[part][policy];f=freq[part][policy]
            for axis in AXES:
                for h in HORIZONS:
                    for w in WIDTHS:
                        s=values[part][policy][axis][str(h)][str(w)];data_frequency=f['取得可能case毎時']
                        comparison.append([148,part,policy,'旧固定対照'if policy in ('C0','C1','RC1')else '母集団unique_q1',axis,h/60,w,p['対象場数'],s['sessions'],s['entries'],s['flips'],p['全場最低1取得'],s['complete'],s['censored'],s['forward'],s['adverse'],s['neither'],s['resolved_rate'],s['complete_rate'],s['forward']/s['entries']if s['entries']else None,s['target70'],None,data_frequency,None,data_frequency>=1 if data_frequency is not None else None,None,s['ifd_known'],s['ifd_unknown'],s['ifd_net0_sum'],s['ifd_net5_profit'],s['ifd_net5_loss'],s['ifd_net5_sum'],s['ifd_net5_mean'],s['ifd_net5_pf']])
    captures={r['event_id']:r for r in capture['rows']};links={r['event_id']:r for r in metadata['population148']['event_case_links']};sharing=Counter(x['case_id']for x in links.values());detail=[]
    for l in ledger['rows']:
        key=l['event_id'];a=captures.get(key);q=l['q0'];q1=a['q1']if a else None;link=links.get(key)
        row=[148,'train'if l['session']in sessions[:48]else 'validation',l['session'],l['contract'],key,module.jst(q['time']),q['index'],q['source_line'],l['latest_bar_ref']['id'],module.jst(l['latest_bar_ref']['end']),len(l['delivered_bar_refs']),len(l['slot_refs']),l['eligible'],'|'.join(l['reasons']),l['feature_generated'],l['feature_ref'],q['quote_ok'],q['last'],q['bid'],q['ask'],a['status']if a else 'ineligible',module.jst(a['expires'])if a else None,module.jst(q1['time'])if q1 else None,q1['index']if q1 else None,q1['source_line']if q1 else None,q1['last']if q1 else None,q1['bid']if q1 else None,q1['ask']if q1 else None,q1['time']-q['time']if q1 else None,a['case_id']if a else None,link['c1_reused']if link else None,sharing[link['case_id']]if link else None,a['buy_stream']if a else None,a['sell_stream']if a else None]
        for policy in ('BUY','SELL'):
            if not link:row.extend([None]*9);continue
            c=selected(records[link['case_id']],policy,'BBO');o=module.observation(c,3600);t=module.touch(o,125);e=module.ifd(c,o,125,'BBO')
            row.extend([c['birth']['side'],o['status'],t['direction'],t['direction']if o['status']=='complete'else None,module.jst(t['quote']['time'])if t['quote']else None,e['known'],e['reason'],module.jst(e['exit']['time'])if e['exit']else None,e['net5']])
        detail.append(row)
    scenes=[]
    for i,scene in enumerate(ledger['scenes']):
        sid=scene['session'];hours=(scene['end']-300-scene['start'])/3600;newhours=(scene['entry_limit']-scene['start'])/3600
        ls=[x for x in ledger['rows']if x['session']==sid];acs=[x for x in capture['rows']if x['session']==sid];reasons=Counter(z for x in ls for z in x['reasons']);statuses=Counter(x['status']for x in acs);unique={x['case_id']for x in acs if x['status']=='filled'}
        row=[148,sid,'train'if i<48 else 'validation',hours,newhours,scene['parent_bars'],len(ls),len(acs),sum(not x['eligible']for x in ls),statuses['filled'],len(unique),statuses['filled']-len(unique),reasons['price_unknown'],reasons['not_closed'],reasons['stale'],reasons['entry_limit'],statuses['expired'],statuses['entry_limit'],statuses['quality_lost'],statuses['eof_unfilled'],len(unique)/hours,None,None,None,None]
        for policy in POLICIES:
            selected_rows=[r for key,r in records.items()if key in members[policy] and r['session']==sid];s=module.stats(selected_rows,policy,'BBO',3600,125)
            row.extend([s['entries'],s['forward'],s['adverse'],s['neither'],s['censored'],s['ifd_known'],s['ifd_unknown'],s['ifd_net5_profit'],s['ifd_net5_loss'],s['ifd_net5_sum']])
        scenes.append(row)
    output=[{'name':'正逆比較','headers':COMPARISON_HEADERS,'rows':comparison},{'name':'入口別診断','headers':DETAIL_HEADERS,'rows':detail},{'name':'全セッション','headers':SCENE_HEADERS,'rows':scenes}]
    assert len(comparison)==300 and len(scenes)==73
    for table in output:
        assert len(table['headers'])==len(set(table['headers']))
        assert all(len(row)==len(table['headers']) and all(v is None or type(v)in (str,int,float,bool) for v in row)for row in table['rows'])
        assert all(not isinstance(v,float)or math.isfinite(v) for row in table['rows']for v in row)
    return output


def main() -> None:
    """
    機能: 別固定の準備票/F1/入力指紋を先確認してから自然観測を集計する。
    引数: CLI preparation-sha256/f1/f1-sha256/generation-dir/result/result-sha256/output-dir。返り値: None。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--preparation-sha256',required=True)
    for name in ('f1','generation-dir','result','output-dir'):parser.add_argument('--'+name,required=True,type=Path)
    for name in ('f1-sha256','result-sha256'):parser.add_argument('--'+name,required=True)
    args=parser.parse_args();preparation=HERE/'準備の確認.json';assert sha(preparation)==args.preparation_sha256
    prep=json.loads(preparation.read_bytes());assert prep['成功'] and all(sha(ROOT/f['path'])==f['sha256']for f in prep['源'])
    assert sha(args.f1)==args.f1_sha256 and sha(args.result)==args.result_sha256
    f1=json.loads(args.f1.read_bytes());declared={str(Path(p).resolve()):h for p,h in f1['ファイル'].items()}
    folder=args.generation_dir;paths={n:folder/(n+'.json')for n in ('出生台帳','取得対応','固定取得入力','入口参照','生成の確認')}
    generation=json.loads(paths['生成の確認'].read_bytes())
    for name,path in paths.items():
        if name!='生成の確認':assert sha(path)==generation['files'][path.name]['sha256']
    for name in ('固定取得入力','入口参照'):assert declared[str(paths[name].resolve())]==sha(paths[name])
    inputs={**SOURCES,**{path:sha(path)for path in paths.values()},args.f1:args.f1_sha256,args.result:args.result_sha256,preparation:args.preparation_sha256}
    assert all(sha(path)==expected for path,expected in inputs.items())
    # ----------------------------------------
    # 観測本文はここからだけ開き、Root通知後に明示CLIで実行します。
    fixed,meta,ledger,capture=[json.loads(paths[n].read_bytes())for n in ('固定取得入力','入口参照','出生台帳','取得対応')]
    observed=json.loads(args.result.read_bytes());records,members,sessions,phase=prepare(observed,fixed,meta,ledger,capture);module=load_arithmetic()
    values,participation,freq=calculate(records,members,sessions,fixed['scenes'],module)
    baseline=baseline_check(records,values,json.loads(OLD_PAIRS.read_bytes()),json.loads(OLD_SUMMARY.read_bytes()),members)
    result_tables=tables(records,members,sessions,values,participation,freq,ledger,capture,meta,module)
    out={'成功':True,'試行':148,'主政策':None,'売買選択':False,'選択trade数':None,'選択trade毎時':None,'新選択共同目標':None,'全場数':73,
        '観測case数':len(records),'母集団unique_q1数':len(members['BUY']),'全q0台帳数':len(ledger['rows']),'出生適格_X数':len(capture['rows']),
        '集計':values,'参加':participation,'取得可能頻度':freq,'旧C1同体':baseline,'全4stream_phase':phase,'運用収支':False,'実IFD':False,'全期既使用':True,
        '費用':'mini1枚100円/pt、往復77円/C5追加1000円。Last金額null。','分母':'event・2side X・unique q1・最終取引を別記。母集団IFD合算は口座収支ではない。',
        'F1_SHA256':args.f1_sha256,'自然結果SHA256':args.result_sha256,'集計準備SHA256':args.preparation_sha256}
    assert all(sha(path)==expected for path,expected in inputs.items())
    target=args.output_dir;target.mkdir(parents=True,exist_ok=True)
    save(target/'集計.json',out);save(target/'CSV用の表.json',{'成功':True,'試行':148,'主政策':None,'tables':result_tables})
    save(target/'集計完了.json',{'成功':True,'試行':148,'前後SHA256':{str(p):h for p,h in inputs.items()},'前後不変':True,'三表形状':[[len(t['rows']),len(t['headers'])]for t in result_tables],
        '集計SHA256':sha(target/'集計.json'),'表SHA256':sha(target/'CSV用の表.json'),'CSV実出力':False,'新戦略又は学習':False})
    print(json.dumps({'success':True,'cases':len(records),'tables':[[len(t['rows']),len(t['headers'])]for t in result_tables]},ensure_ascii=True))


if __name__=='__main__':
    main()
