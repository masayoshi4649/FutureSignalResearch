"""母集団300比較の向き正規化・未取得NULL・三表の型を人工確認する。"""
from pathlib import Path
import copy
import importlib.util
import unittest

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('aggregate148',HERE/'集計する.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)


def fixture() -> tuple:
    """
    機能: 全73場/旧87と取得1・未取得1・不適格1の人工資料を作る。
    引数: なし。返り値: tuple。
    """
    sessions=[f'人工{i:02d}'for i in range(73)];fixed={'expected_entry_count':87,'scenes':[]};result={'success':True,'trial':133,'input_sha256':'固定','source_entry_count':87,'scenes':[]}
    meta={'trial':148,'fixed_input_sha256':'固定','sessions':sessions,'entries':[],'population148':{'cases':[],'event_case_links':[],'counts':{'population_unique_q1':1}}}
    ledger={'trial':148,'sessions':sessions,'scenes':[],'rows':[]};capture={'trial':148,'sessions':sessions,'rows':[]};count=0
    for i,sid in enumerate(sessions):
        start=i*10000;q={'time':start+100,'index':10,'source_line':11,'last':1000,'bid':999,'ask':1001,'quote_ok':True,'clock':'人工'}
        scene={'session':sid,'contract':'X','start':start,'end':start+9000,'force_close':start+8000,'raw':{'sha256':'a'*64},'expected_quality':{},'entries':[]}
        observed={'session':sid,'success':True,'actual_sha256':'a'*64,'quality':{},'expected_quality':{},'stat_before':{},'stat_after':{},'execution_end':start+8700,'effective_entry_limit':start+5100,'cases':[]}
        for j in range(2 if i<14 else 1):
            key=f'{sid}/{j}';side=-1 if count==0 else 1;quote={**q,'index':10+j,'source_line':11+j};case={'id':key,'original_side':side}
            for name in ('original','reverse','chart_original','chart_reverse'):
                stream_side=side if name.endswith('original')else -side;chart=name.startswith('chart');direction=1 if name.endswith('original')else -1
                price=1000 if chart else quote['ask']if stream_side==1 else quote['bid'];outcomes=[]
                for h in module.HORIZONS:
                    touches=[]
                    for w in module.WIDTHS:
                        mark=price+stream_side*direction*w;touch_quote={**quote,'time':quote['time']+w,'index':100+w,'source_line':101+w,'last':mark,'bid':mark if stream_side==1 else mark-2,'ask':mark+2 if stream_side==1 else mark}
                        touches.append({'width':w,'direction':direction,'quote':touch_quote})
                    endpoint={**quote,'time':quote['time']+h,'index':1000+h,'source_line':1001+h}
                    outcomes.append({'seconds':h,'deadline':quote['time']+h,'status':'complete','touches':touches,'endpoint':endpoint,'net0':None if chart else -77,'net5':None if chart else -1077})
                case[name]={'status':'filled','birth':{'side':stream_side},'entry':quote,'entry_price':price,'outcomes':outcomes}
            observed['cases'].append(case);scene['entries'].append({'id':key,'side':side,'entry':quote});meta['entries'].append({'id':key,'baseline':count<81})
            meta['population148']['cases'].append({'case_id':key,'session':sid,'contract':'X','original_side':side});count+=1
        fixed['scenes'].append(scene);result['scenes'].append(observed);ledger['scenes'].append({'session':sid,'start':start,'end':start+9000,'entry_limit':start+5100,'parent_bars':3 if i==0 else 0})
    first=fixed['scenes'][0]['entries'][0];quote=first['entry'];q0={**quote,'time':quote['time']-2,'index':8,'source_line':9}
    for key,eligible,reasons in [('取得',True,[]),('未取得',True,[]),('不適格',False,['entry_limit'])]:
        ledger['rows'].append({'event_id':key,'session':sessions[0],'contract':'X','q0':q0,'latest_bar_ref':{'id':'足','end':60},'delivered_bar_refs':[],'slot_refs':[],
            'eligible':eligible,'reasons':reasons,'feature_generated':eligible,'feature_ref':key if eligible else None})
    capture['rows']=[{'event_id':'取得','session':sessions[0],'contract':'X','q0':q0,'status':'filled','expires':q0['time']+30,'q1':quote,'case_id':first['id'],'buy_stream':'reverse','sell_stream':'original'},
        {'event_id':'未取得','session':sessions[0],'contract':'X','q0':q0,'status':'expired','expires':q0['time']+30,'q1':None,'case_id':None,'buy_stream':None,'sell_stream':None}]
    meta['population148']['event_case_links']=[{'event_id':'取得','case_id':first['id'],'buy_stream':'reverse','sell_stream':'original','c1_reused':True}]
    return result,fixed,meta,ledger,capture


class AggregateTests(unittest.TestCase):
    """自然観測を開かず基本契約を確認する。"""

    def test_方向正規化と全300三表(self) -> None:
        """
        機能: 売格納C1の買は実逆、未取得と不適格は金融列nullにする。
        引数: self(AggregateTests)。返り値: None。
        """
        observed,fixed,meta,ledger,capture=fixture();records,members,sessions,phase=module.prepare(observed,fixed,meta,ledger,capture,False);arithmetic=module.load_arithmetic()
        values,p,f=module.calculate(records,members,sessions,fixed['scenes'],arithmetic);tables=module.tables(records,members,sessions,values,p,f,ledger,capture,meta,arithmetic)
        self.assertEqual([len(t['rows'])for t in tables],[300,3,73]);self.assertEqual(values['all']['BUY']['BBO']['3600']['125']['adverse'],1)
        self.assertEqual(values['all']['SELL']['BBO']['3600']['125']['forward'],1)
        self.assertEqual(module.selected(records['人工00/0'],'BUY','BBO')['birth']['side'],1)
        h=tables[0]['headers'];self.assertTrue(all(r[h.index('新選択三目標判定')]is None for r in tables[0]['rows']))
        dh=tables[1]['headers'];self.assertIsNone(tables[1]['rows'][1][dh.index('買125C5代用円')]);self.assertIsNone(tables[1]['rows'][2][dh.index('買IFD既知')])
        self.assertGreater(phase['touch'],0)

    def test_同case複数eventを二重計数しない(self) -> None:
        """
        機能: metadataの複数eventが同caseを参照しても集合サイズは1にする。
        引数: self(AggregateTests)。返り値: None。
        """
        _,_,meta,_,_=fixture();meta['population148']['event_case_links']*=2
        self.assertEqual(len(module.membership(meta)['BUY']),1)

    def test_既知touch優先とLast金額null(self) -> None:
        """
        機能: H不足の既知touchをIFDへ残し、Lastを金額化しない。
        引数: self(AggregateTests)。返り値: None。
        """
        observed,_,_,_,_=fixture();case=observed['scenes'][0]['cases'][0];case['original']['outcomes'][1]['status']='censored';case['original']['outcomes'][1]['endpoint']=None
        r={'session':'人工00','case':case};a=module.load_arithmetic();s=a.stats([r],'C1','BBO',3600,125)
        self.assertEqual((s['complete'],s['ifd_known']),(0,1));self.assertIsNone(s['resolved_rate']);self.assertIsNotNone(s['ifd_net5_sum'])
        chart=a.stats([r],'C1','Last',3600,125);self.assertIsNone(chart['ifd_net5_sum'])

    def test_phase未来を拒否(self) -> None:
        """
        機能: ザラバ終端以後のquoteを正常清算として使わない。
        引数: self(AggregateTests)。返り値: None。
        """
        observed,fixed,meta,ledger,capture=fixture();observed['scenes'][0]['cases'][0]['original']['outcomes'][0]['touches'][0]['quote']['time']=999999
        with self.assertRaises(AssertionError):module.prepare(observed,fixed,meta,ledger,capture,False)


if __name__=='__main__':
    unittest.main(verbosity=2)
