"""ツールで実行済みの独立3群と、作者停止票/旧74の現在同体を固定する。"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
FEATURES=ROOT/'work/148全1分候補の当時特徴'


def sha(path: Path) -> str:
    """
    機能: 明示ファイルの保存bytesの指紋を返す。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 実行記録・旧式同体・停止源15件を照合し、独立確認票を新規保存する。
    引数: なし。自然データを読み直さず、人工を重複実行しない。
    返り値: None。
    """
    stop=FEATURES/'停止の確認.json'
    assert sha(stop)=='fbfbd6aa076fd311d930539b57ff8fd0138a140df48070662aae15ec1ac40cc1'
    value=json.loads(stop.read_bytes());assert value['成功']
    sources={}
    for ref in value['保存対象']:
        path=FEATURES/ref['path'];assert path.stat().st_size==ref['bytes'] and sha(path)==ref['sha256'];sources[str(path)]=sha(path)
    legacy=ROOT/'work/全成立poolの当時特徴/features.go'
    assert legacy.read_bytes().replace(b'package main',b'package features148',1)==(FEATURES/'legacy74.go').read_bytes()
    record=HERE/'人工の実行.txt'
    assert record.read_text(encoding='utf-8').count('--- PASS: Test独立')==3
    report={'成功':True,'試行':148,'UTC':datetime.now(timezone.utc).isoformat(),'確認者':'Root',
        '独立人工群':3,'追加26列の手計算':26,'買売の実側を別計算':True,'停止票と全源同体':True,
        '旧74のpackage以外bytes同体':True,'作者fixture利用':False,'自然価格又は金融利用':False,
        '範囲':'公開Compute APIの独立fixture。26列全買側と非対称売側、価格未知/量既知/既知0、同Raw履歴、未来拒否。全100列の独立再実装ではない。',
        '作者停止SHA256':sha(stop),'源':sources,
        '独立確認源':{str(p):sha(p) for p in (HERE/'go.mod',HERE/'independent_test.go',record,Path(__file__).resolve(),legacy)}}
    with (HERE/'準備の確認.json').open('x',encoding='utf-8',newline='\n') as out:json.dump(report,out,ensure_ascii=False,indent=2);out.write('\n')
    print(json.dumps({'成功':True,'独立人工群':3,'源確認':len(sources),'準備SHA256':sha(HERE/'準備の確認.json')},ensure_ascii=False))


if __name__=='__main__':main()
