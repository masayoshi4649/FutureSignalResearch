package independent148

import (
	r "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	f "github.com/masayoshi4649/SessionTradeExecuter/features148"
	"math"
	"testing"
)

// known は独立fixtureの既知有限値を作ります。
//
// 引数: x(float64)。返り値: r.Valueです。
func known(x float64) r.Value { return r.Value{Known: true, Value: x} }

// fixture は作者fixtureを使わない人工Snapshotと連続4slotです。
//
// 引数: なし。返り値: f.Inputです。実価格/ラベルは読みません。
func fixture() f.Input {
	q := f.Quote{Time: 2240, Index: 50, Line: 60, Last: 108, Bid: 107, Ask: 109, QuoteOK: true}
	s := r.Snapshot{SessionID: "独立", Contract: "人工", AsOf: r.Quote{Time: q.Time, Index: q.Index, Line: q.Line, Last: q.Last}, Frames: map[int]r.Publication{}, RVOL5: known(2), BB15: r.Bands{Known: true, Count: 20, Mean: 100, Sigma: 10, Upper: 120, Lower: 80}}
	for _, width := range []int{300, 900, 1800} {
		end, at, idx := 1800., 1900., 15
		atr := float64(width) / 45
		if width == 300 {
			end, at, idx, atr = 2100, 2180, 45, 10
		}
		if width == 900 {
			atr = 20
		}
		tech := r.Technical{EMA8: known(100), EMA21: known(95), EMA8Delta: known(.2), EMA21Delta: known(.1), Gap: known(5), ATR: known(atr), PreviousATR: known(atr), TR: known(20), RSI: known(60), PreviousRSI: known(55), Histogram: known(2), PreviousHistogram: known(1)}
		id := "独立背景"
		if width == 300 {
			id += "5"
		} else if width == 900 {
			id += "15"
		} else {
			id += "30"
		}
		stamp := r.Stamp{Time: at, Index: idx, Line: idx + 10}
		p := r.Publication{Stamp: stamp, Frame: r.Frame{Frame: r.ChartFrame{ID: id, SessionID: s.SessionID, Contract: s.Contract, Width: width, Start: end - float64(width), End: end, AvailableAt: end + 60, DeliveryAt: at, PriceKnown: true, VolumeKnown: true, Volume: 1000, OHLC: r.OHLC{Open: 95, High: 110, Low: 90, Close: 105}, Technical: tech}, DMI: r.DMI{PlusDI: known(20), MinusDI: known(10), ADX: known(25), PreviousADX: known(24)}}}
		s.Frames[width] = p
		s.Refs = append(s.Refs, r.Ref{ID: id, Width: width, End: end, Delivered: stamp})
	}
	prices := []r.OHLC{{Open: 94, High: 101, Low: 90, Close: 99}, {Open: 99, High: 105, Low: 95, Close: 102}, {Open: 102, High: 107, Low: 99, Close: 104}, {Open: 104, High: 112, Low: 101, Close: 108}}
	in := f.Input{Q0: q, Snapshot: s}
	for i, o := range prices {
		start := 1920. + float64(i)*60
		id := []string{"a", "b", "p", "r"}[i]
		at := []float64{2050, 2110, 2170, 2240}[i]
		idx := 20 + 10*i
		in.Minutes = append(in.Minutes, f.Minute{ID: id, Session: s.SessionID, Contract: s.Contract, Start: start, End: start + 60, AvailableAt: start + 120, Stamp: r.Stamp{Time: at, Index: idx, Line: idx + 10}, OHLC: o, Volume: []float64{100, 200, 300, 600}[i], PriceKnown: true, VolumeKnown: true, Closed: true})
	}
	return in
}

// at は辞書名から値を引き未知/既知の取り違えを確認します。
//
// 引数: t(*testing.T)、row(f.SideRow)、name(string)。返り値: *float64です。
func at(t *testing.T, row f.SideRow, name string) *float64 {
	t.Helper()
	for i, c := range f.Catalog() {
		if c.Name == name {
			return row.X[i]
		}
	}
	t.Fatal("列なし: " + name)
	return nil
}

// expect は手計算した値と列の有限値を比較します。
//
// 引数: t(*testing.T)、row(f.SideRow)、name(string)、want(float64)。返り値: ありません。
func expect(t *testing.T, row f.SideRow, name string, want float64) {
	t.Helper()
	x := at(t, row, name)
	if x == nil || math.IsNaN(*x) || math.Abs(*x-want) > 1e-10*math.Max(1, math.Abs(want)) {
		t.Fatalf("%s want=%g got=%v", name, want, x)
	}
}

// Test独立26列手計算 は非対称気配とヒゲ・前3本から追加26列を照合します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test独立26列手計算(t *testing.T) {
	p, err := f.Compute(fixture())
	if err != nil {
		t.Fatal(err)
	}
	expected := map[string]float64{"q0_spread_points": 2, "q0_spread_125_ratio": 2. / 125, "q0_entry_minus_last_atr5_to_side": .1, "q0_entry_minus_ema8_atr5_to_side": .9, "q0_entry_minus_ema21_atr5_to_side": 1.4, "q0_entry_minus_bbmean_sigma_to_side": .9, "bb15_forward_room_125_ratio_to_side": 11. / 125, "bb15_mean_room_125_ratio_to_side": -9. / 125, "target125_atr5_ratio": 12.5, "target125_atr15_ratio": 6.25, "m1_range_atr5_ratio": 1.1, "m1_body_ratio_to_side": 4. / 11, "m1_forward_wick_ratio": 4. / 11, "m1_opposite_wick_ratio": 3. / 11, "m1_close_position_to_side": 7. / 11, "m1_tr_atr5_ratio": 1.1, "m1_close_delta_atr5_to_side": .4, "q0_last_minus_m1_close_atr5_to_side": 0, "m1_volume_ratio_previous": 2, "m1_body_reclaim_atr5_to_side": .6, "m1_previous_body_ratio_to_side": .25, "q0_last_minus_prior3_forward_edge_atr5_to_side": .1, "q0_prior3_forward_room_125_to_side": -2. / 125, "q0_entry_prior3_percent_to_side": 19. / 17, "m1_volume_relative_prior3": 3, "m1_body_range_prior3_to_side": 4. / 17}
	if len(expected) != 26 || len(f.Catalog()) != 100 {
		t.Fatal("列数不一致")
	}
	for name, x := range expected {
		expect(t, p.Buy, name, x)
	}
	for name, x := range map[string]float64{"q0_entry_minus_last_atr5_to_side": .1, "q0_entry_minus_ema8_atr5_to_side": -.7, "q0_entry_minus_bbmean_sigma_to_side": -.7, "bb15_forward_room_125_ratio_to_side": 27. / 125, "bb15_mean_room_125_ratio_to_side": 7. / 125, "m1_forward_wick_ratio": 3. / 11, "m1_opposite_wick_ratio": 4. / 11, "m1_close_position_to_side": 4. / 11, "q0_entry_prior3_percent_to_side": 0} {
		expect(t, p.Sell, name, x)
	}
}

// Test独立価格未知と量既知 は必要な列だけを未知にし既知0を保持します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test独立価格未知と量既知(t *testing.T) {
	in := fixture()
	in.Minutes[0].PriceKnown = false
	in.Minutes[2].PriceKnown = false
	in.Minutes[3].Volume = 0
	p, err := f.Compute(in)
	if err != nil {
		t.Fatal(err)
	}
	expect(t, p.Buy, "m1_volume_ratio_previous", 0)
	expect(t, p.Buy, "m1_volume_relative_prior3", 0)
	for _, name := range []string{"m1_tr_atr5_ratio", "m1_previous_body_ratio_to_side", "q0_entry_prior3_percent_to_side"} {
		if at(t, p.Buy, name) != nil {
			t.Fatal("必要価格が未知でもknown: " + name)
		}
	}
	in = fixture()
	in.Q0.Bid = 111
	p, err = f.Compute(in)
	if err != nil {
		t.Fatal(err)
	}
	for _, name := range []string{"q0_spread_points", "q0_spread_125_ratio", "q0_entry_minus_last_atr5_to_side", "q0_prior3_forward_room_125_to_side"} {
		if at(t, p.Buy, name) != nil {
			t.Fatal("異常BBO依存列がknown: " + name)
		}
	}
	expect(t, p.Buy, "m1_body_reclaim_atr5_to_side", .6)
	expect(t, p.Buy, "q0_last_minus_prior3_forward_edge_atr5_to_side", .1)
}

// Test独立同時知得と未来拒否 は現在までの履歴利用と未来参照を分けます。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test独立同時知得と未来拒否(t *testing.T) {
	in := fixture()
	before, err := f.Compute(in)
	if err != nil {
		t.Fatal(err)
	}
	in.Minutes[2].Stamp = in.Minutes[3].Stamp
	after, err := f.Compute(in)
	if err != nil {
		t.Fatal(err)
	}
	for i, x := range before.Buy.X {
		y := after.Buy.X[i]
		if (x == nil) != (y == nil) || x != nil && *x != *y {
			t.Fatalf("同Raw知得で値が変化: %s", f.Catalog()[i].Name)
		}
	}
	in = fixture()
	future := in.Snapshot.Frames[300]
	future.Stamp.Time = in.Q0.Time + 1
	future.Frame.Frame.DeliveryAt = in.Q0.Time + 1
	in.Snapshot.Frames[300] = future
	if _, err = f.Compute(in); err == nil {
		t.Fatal("q0以後の背景を受容した")
	}
}
