package features148

import (
	"sort"
	"strings"
)

// columnRequirements は列の参照と未知条件を共通辞書へ明示します。
//
// 引数: name(string)は固定列名、old(bool)は旧74列かどうかです。
// 返り値: string/string は必要参照と未知条件です。
func columnRequirements(name string, old bool) (string, string) {
	if old {
		if name == "rvol5" {
			return "当時Snapshot.RVOL5", "RVOL5未知"
		}
		if strings.HasPrefix(name, "bb15_") {
			return "当時Snapshot.BB15。width_atrは15分ATRも参照", "BB未知。位置/percentはσ<=0、width_atrは15分価格/ATR不足又はATR<=0"
		}
		return "列名の5/15/30分の当場fresh公表と式内のknown値", "当該Frame不在/価格未知/必要技法値未知。比率分母<=0。ゼロ足幅の形状比は未知、range値0は既知"
	}
	needs := "q0と当時Snapshot"
	unknown := "式内の値未知又は分母<=0"
	switch name {
	case "q0_spread_points", "q0_spread_125_ratio":
		return "q0 Bid/Ask/QuoteOK", "q0が不正常BBO"
	case "m1_body_ratio_to_side", "m1_forward_wick_ratio", "m1_opposite_wick_ratio", "m1_close_position_to_side":
		return "当場r OHLC", "r価格未知/未closed又はr足幅<=0"
	case "m1_previous_body_ratio_to_side":
		return "rに実隣接する当場p OHLC", "p不足/非隣接/価格未知/未closed又はp足幅<=0"
	case "m1_volume_ratio_previous":
		return "当場実隣接p/rのclosedと両Volume。価格knownは不要", "p/r不足/非隣接/未closed/量未知又はp量<=0。r量0は既知0"
	case "m1_volume_relative_prior3":
		return "rと実隣接する当場prior3のclosed・Volume。価格knownは不要", "4足不足/非隣接/未closed/量未知又はprior3量平均<=0。r量0は既知0"
	case "q0_last_minus_prior3_forward_edge_atr5_to_side":
		return "q0 Last、rを除く当場実連続prior3のOHLC、当時5分ATR", "4slot不足/非隣接、prior3価格未知/未closed、5分価格/ATR未知又はATR<=0。rのOHLC/量は不要"
	case "q0_prior3_forward_room_125_to_side":
		return "正常q0の買Ask/売Bid、rを除く当場実連続prior3のOHLC", "4slot不足/非隣接、prior3価格未知/未closed又は不正常BBO。rのOHLC/量は不要"
	case "q0_entry_prior3_percent_to_side":
		return "正常q0の買Ask/売Bid、rを除く当場実連続prior3のOHLC", "4slot不足/非隣接、prior3価格未知/未closed、prior3幅<=0又は不正常BBO。rのOHLC/量は不要、clipなし"
	case "m1_body_range_prior3_to_side":
		return "当場rとrを除く実連続prior3のOHLC", "4足不足/非隣接/必要価格未知/未closed又はprior3幅<=0。量は不要"
	}
	if strings.HasPrefix(name, "m1_") || name == "q0_last_minus_m1_close_atr5_to_side" {
		needs = "当場r。TR/close_delta/body_reclaimは実隣接pも必要"
		unknown = "必要短期足不足/非隣接/価格未知/未closed"
	}
	if strings.Contains(name, "atr5") {
		needs += "、当時5分ATR"
		unknown += "、5分価格/ATR未知又はATR<=0"
	}
	if name == "target125_atr15_ratio" {
		needs = "当時15分ATR"
		unknown = "15分価格/ATR未知又はATR<=0"
	}
	if name == "q0_entry_minus_ema8_atr5_to_side" || name == "q0_entry_minus_ema21_atr5_to_side" {
		needs += "、対応5分EMA"
		unknown += "、EMA未知"
	}
	if strings.HasPrefix(name, "bb15_") || name == "q0_entry_minus_bbmean_sigma_to_side" {
		needs += "、当時BB15"
		unknown += "、BB未知"
		if name == "q0_entry_minus_bbmean_sigma_to_side" {
			unknown += "又はσ<=0"
		}
	}
	if strings.HasPrefix(name, "q0_entry_") || name == "bb15_forward_room_125_ratio_to_side" || name == "bb15_mean_room_125_ratio_to_side" || name == "q0_prior3_forward_room_125_to_side" {
		needs += "、正常q0の買Ask/売Bid"
		unknown += "、不正常BBO"
	}
	return needs, unknown
}

// addedCatalog は追加26列の役割/単位/式を固定します。
//
// 引数: ありません。
// 返り値: map[string]Definition は旧74と名前が重ならない定義です。
func addedCatalog() map[string]Definition {
	return map[string]Definition{
		"q0_spread_points":                               {"値幅", "pt", "Ask0-Bid0。正常q0だけ既知"},
		"q0_spread_125_ratio":                            {"値幅", "125pt比", "(Ask0-Bid0)/125。正常q0だけ既知"},
		"q0_entry_minus_last_atr5_to_side":               {"構造", "ATR5比", "s*(P0_s-Last0)/ATR5"},
		"q0_entry_minus_ema8_atr5_to_side":               {"構造", "ATR5比", "s*(P0_s-EMA8_5)/ATR5"},
		"q0_entry_minus_ema21_atr5_to_side":              {"構造", "ATR5比", "s*(P0_s-EMA21_5)/ATR5"},
		"q0_entry_minus_bbmean_sigma_to_side":            {"構造", "σ比", "s*(P0_s-BB15.Mean)/BB15.Sigma"},
		"bb15_forward_room_125_ratio_to_side":            {"構造", "125pt比", "s*(F_s-P0_s)/125。F_sは買Upper/売Lower"},
		"bb15_mean_room_125_ratio_to_side":               {"構造", "125pt比", "s*(BB15.Mean-P0_s)/125"},
		"target125_atr5_ratio":                           {"値幅", "比", "125/ATR5"},
		"target125_atr15_ratio":                          {"値幅", "比", "125/ATR15"},
		"m1_range_atr5_ratio":                            {"値幅", "ATR5比", "(r.High-r.Low)/ATR5"},
		"m1_body_ratio_to_side":                          {"構造", "比", "s*(r.Close-r.Open)/(r.High-r.Low)"},
		"m1_forward_wick_ratio":                          {"構造", "比", "買はr上ヒゲ/幅、売はr下ヒゲ/幅"},
		"m1_opposite_wick_ratio":                         {"構造", "比", "買はr下ヒゲ/幅、売はr上ヒゲ/幅"},
		"m1_close_position_to_side":                      {"構造", "比", "買は(r.Close-r.Low)/幅、売は1-同値"},
		"m1_tr_atr5_ratio":                               {"値幅", "ATR5比", "max(r.High-r.Low,abs(r.High-p.Close),abs(r.Low-p.Close))/ATR5"},
		"m1_close_delta_atr5_to_side":                    {"勢い", "ATR5比", "s*(r.Close-p.Close)/ATR5"},
		"q0_last_minus_m1_close_atr5_to_side":            {"構造", "ATR5比", "s*(Last0-r.Close)/ATR5"},
		"m1_volume_ratio_previous":                       {"量", "比", "r.Volume/p.Volume。両量既知、p量正、r量0は既知0"},
		"m1_body_reclaim_atr5_to_side":                   {"構造", "ATR5比", "s*(r.Close-p.Open)/ATR5"},
		"m1_previous_body_ratio_to_side":                 {"構造", "比", "s*(p.Close-p.Open)/(p.High-p.Low)"},
		"q0_last_minus_prior3_forward_edge_atr5_to_side": {"構造", "ATR5比", "s*(Last0-E_s)/ATR5。E_sは前3本の買High最大/売Low最小"},
		"q0_prior3_forward_room_125_to_side":             {"構造", "125pt比", "s*(E_s-P0_s)/125"},
		"q0_entry_prior3_percent_to_side":                {"構造", "比", "買(P0_s-L3)/(U3-L3)、売1-同値。clipなし"},
		"m1_volume_relative_prior3":                      {"量", "比", "r.Volume/前3本Volume平均。量既知・平均正、r量0は既知0"},
		"m1_body_range_prior3_to_side":                   {"構造", "比", "s*(r.Close-r.Open)/(U3-L3)"},
	}
}

// buildCatalog148 は旧74と追加26を100全体の辞書順で固定します。
//
// 引数: ありません。
// 返り値: []Column は毎回新しいcopyで、旧74名への射影順も同体です。
func buildCatalog148() []Column {
	original := catalog()
	definitions := catalog()
	for name, d := range addedCatalog() {
		if _, exists := definitions[name]; exists {
			panic("追加列名が旧74と重複")
		}
		definitions[name] = d
	}
	if len(definitions) != Count {
		panic("100列ではありません")
	}
	names := make([]string, 0, len(definitions))
	for name := range definitions {
		names = append(names, name)
	}
	sort.Strings(names)
	out := make([]Column, 0, len(names))
	for _, name := range names {
		d := definitions[name]
		_, old := original[name]
		needs, unknown := columnRequirements(name, old)
		out = append(out, Column{Name: name, Role: d.Role, Unit: d.Unit, Formula: d.Formula,
			Mirror: "価格全反射P'=C-P・Bid/Ask交換・s'=-sで同値。RSIは100-RSI、DI交換、MA/Hist/増分反射、ADX/ATR/量不変。", Needs: needs, Unknown: unknown})
	}
	return out
}

var fixedCatalog148 = buildCatalog148()

// Catalog は不変な100列辞書を外部変更できないcopyで返します。
//
// 引数: ありません。
// 返り値: []Column は列名辞書順の100列です。
func Catalog() []Column { return append([]Column(nil), fixedCatalog148...) }
