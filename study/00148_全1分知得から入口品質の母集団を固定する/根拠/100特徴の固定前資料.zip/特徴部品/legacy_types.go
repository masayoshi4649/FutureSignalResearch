package features148

import rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"

// Query/Value/Definition/Foot/Row は旧74式を変更しないための互換型です。
// 公開Computeはこの旧Queryを引数に取らず、IDや時刻をXへ射影しません。
type Query struct {
	ID         string      `json:"id"`
	Session    string      `json:"session"`
	Contract   string      `json:"contract"`
	Side       int         `json:"side"`
	BirthQuote rules.Quote `json:"birthQuote"`
}
type Value struct {
	Known bool     `json:"known"`
	Value *float64 `json:"value"`
}
type Definition struct {
	Role    string `json:"role"`
	Unit    string `json:"unit"`
	Formula string `json:"formula"`
}
type Foot struct {
	ID          string      `json:"id"`
	Width       int         `json:"width_seconds"`
	End         float64     `json:"end"`
	AvailableAt float64     `json:"available_at"`
	DeliveryAt  float64     `json:"delivery_at"`
	Delivered   rules.Stamp `json:"delivered"`
	PriceKnown  bool        `json:"price_known"`
	VolumeKnown bool        `json:"volume_known"`
	MarketAge   float64     `json:"market_age_seconds"`
	DeliveryAge float64     `json:"delivery_age_seconds"`
}
type Row struct {
	Query     Query            `json:"query"`
	Values    map[string]Value `json:"values"`
	KnownMask map[string]bool  `json:"known_mask"`
	Feet      map[string]*Foot `json:"feet"`
	Refs      []rules.Ref      `json:"refs"`
	Missing   []string         `json:"missing"`
	Flags     map[string]*bool `json:"flags"`
}
