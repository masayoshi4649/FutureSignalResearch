package features148

import (
	"fmt"
	"math"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// finite148 は入力時計や既知値の非有限を判定します。
//
// 引数: xs(...float64)。
// 返り値: bool はすべて有限なら真です。
func finite148(xs ...float64) bool {
	for _, x := range xs {
		if math.IsNaN(x) || math.IsInf(x, 0) {
			return false
		}
	}
	return true
}

// normalQuote はq0の執行価格とspreadを定義できる条件を返します。
//
// 引数: q(Quote)。
// 返り値: bool はQuoteOKかつ有限0<Bid<Askです。
func normalQuote(q Quote) bool {
	return q.QuoteOK && finite148(q.Bid, q.Ask) && q.Bid > 0 && q.Bid < q.Ask
}

// priceBar は短期の既知・閉鎖を判定します。
//
// 引数: b(Minute)。
// 返り値: bool は価格が使える足です。量既知性は別です。
func priceBar(b Minute) bool { return b.Closed && b.PriceKnown }

// validKnown148 は未知の仮値を使わず、既知非有限値を不正と判定します。
//
// 引数: value(rules.Value)。
// 返り値: bool は未知又は既知有限なら真です。
func validKnown148(value rules.Value) bool { return !value.Known || finite148(value.Value) }

// adjacent はslotを詰めず実隣接することを判定します。
//
// 引数: a/b(Minute)は前/後の順です。
// 返り値: bool は同場/同限月の60秒実隣接です。同Raw配送も許容します。
func adjacent(a, b Minute) bool {
	return a.Session == b.Session && a.Contract == b.Contract && a.End == b.Start
}

// validateInput は未来/scope/逆順の契約違反だけを拒否し、未知を通常処理へ残します。
//
// 引数: in(Input)。
// 返り値: error は不正契約です。価格未知/未closed/p不足はerrorにしません。
func validateInput(in Input) error {
	q := in.Q0
	s := in.Snapshot
	if !finite148(q.Time, q.Last) || q.Last <= 0 || q.Index < 0 || q.Line < 1 || s.SessionID == "" || s.Contract == "" || s.AsOf != (rules.Quote{Time: q.Time, Index: q.Index, Line: q.Line, Last: q.Last}) {
		return fmt.Errorf("q0/Snapshotのscope又は当時時計が不正")
	}
	if len(in.Minutes) < 1 || len(in.Minutes) > 4 {
		return fmt.Errorf("1〜4個の当場1分slotが必要")
	}
	if !validKnown148(s.RVOL5) {
		return fmt.Errorf("既知RVOLが非有限")
	}
	if s.BB15.Known && (!finite148(s.BB15.Mean, s.BB15.Sigma, s.BB15.Upper, s.BB15.Lower) || s.BB15.Sigma < 0 || s.BB15.Upper < s.BB15.Lower) {
		return fmt.Errorf("既知BBが不正")
	}
	for width, p := range s.Frames {
		f := p.Frame.Frame
		d := p.Stamp
		if width != 300 && width != 900 && width != 1800 {
			return fmt.Errorf("背景尺度が不正")
		}
		if f.SessionID != s.SessionID || f.Contract != s.Contract || f.Width != width || !finite148(f.Start, f.End, f.AvailableAt, f.DeliveryAt, d.Time) || f.End != f.Start+float64(width) || f.End > f.AvailableAt || f.AvailableAt > f.DeliveryAt || f.DeliveryAt > d.Time || d.Time > q.Time || d.Index > q.Index || d.Line > q.Line || d.Index < 0 || d.Line < 1 || q.Time >= f.End+float64(width)+60 {
			return fmt.Errorf("未来/別scope/非freshの背景Snapshot")
		}
		if f.PriceKnown {
			o := f.OHLC
			if !finite148(o.Open, o.High, o.Low, o.Close) || o.Low <= 0 || o.High < o.Low || o.Open < o.Low || o.Open > o.High || o.Close < o.Low || o.Close > o.High {
				return fmt.Errorf("既知背景OHLCが不正")
			}
		}
		technical, dmi := f.Technical, p.Frame.DMI
		for _, item := range []rules.Value{technical.EMA8, technical.EMA21, technical.EMA8Delta, technical.EMA21Delta, technical.Gap, technical.ATR, technical.PreviousATR, technical.TR, technical.RSI, technical.PreviousRSI, technical.Histogram, technical.PreviousHistogram, dmi.PlusDI, dmi.MinusDI, dmi.ADX, dmi.PreviousADX} {
			if !validKnown148(item) {
				return fmt.Errorf("既知背景数値が非有限")
			}
		}
	}
	for _, ref := range s.Refs {
		if !finite148(ref.End, ref.Delivered.Time) || ref.End > ref.Delivered.Time || ref.Delivered.Time > q.Time || ref.Delivered.Index > q.Index || ref.Delivered.Line > q.Line || ref.Delivered.Index < 0 || ref.Delivered.Line < 1 {
			return fmt.Errorf("未来の背景参照")
		}
	}
	seen := map[string]bool{}
	for i, b := range in.Minutes {
		if b.ID == "" || seen[b.ID] || b.Session != s.SessionID || b.Contract != s.Contract || !finite148(b.Start, b.End, b.AvailableAt, b.Stamp.Time) || b.End != b.Start+60 || b.End > b.AvailableAt || b.AvailableAt > b.Stamp.Time || b.Stamp.Time > q.Time || b.Stamp.Index > q.Index || b.Stamp.Line > q.Line || b.Stamp.Index < 0 || b.Stamp.Line < 1 {
			return fmt.Errorf("短期slotのscope/格子/未来/重複が不正")
		}
		if i > 0 {
			a := in.Minutes[i-1]
			if b.Start < a.End || math.Mod(b.Start-a.Start, 60) != 0 || b.Stamp.Time < a.Stamp.Time || b.Stamp.Index < a.Stamp.Index || b.Stamp.Line < a.Stamp.Line {
				return fmt.Errorf("短期slotの順序/格子が不正")
			}
		}
		seen[b.ID] = true
		if priceBar(b) {
			o := b.OHLC
			if !finite148(o.Open, o.High, o.Low, o.Close) || o.Low <= 0 || o.High < o.Low || o.Open < o.Low || o.Open > o.High || o.Close < o.Low || o.Close > o.High {
				return fmt.Errorf("既知OHLCが不正")
			}
		}
		if b.Closed && b.VolumeKnown && (!finite148(b.Volume) || b.Volume < 0) {
			return fmt.Errorf("既知量が不正")
		}
	}
	return nil
}

// atrAt は価格既知の当場背景ATRだけを分母候補へ渡します。
//
// 引数: snapshot(rules.Snapshot)、width(int)。
// 返り値: rules.Value は不足/価格未知なら未知です。
func atrAt(snapshot rules.Snapshot, width int) rules.Value {
	p, ok := snapshot.Frames[width]
	if !ok || !p.Frame.Frame.PriceKnown {
		return rules.Value{}
	}
	return p.Frame.Frame.Technical.ATR
}

// additions は当時のq0と1分slotから追加26値を側別に計算します。
//
// 引数: in(Input)、side(int)は+1/-1。
// 返り値: map[string]Value は未知をnullとして持つ26値です。
func additions(in Input, side int) map[string]Value {
	out := map[string]Value{}
	for name := range addedCatalog() {
		out[name] = Value{}
	}
	s := float64(side)
	q := in.Q0
	normal := normalQuote(q)
	entry := q.Ask
	if side < 0 {
		entry = q.Bid
	}
	atr5, atr15 := atrAt(in.Snapshot, 300), atrAt(in.Snapshot, 900)
	out["target125_atr5_ratio"] = normalize(true, 125, atr5)
	out["target125_atr15_ratio"] = normalize(true, 125, atr15)
	if normal {
		out["q0_spread_points"] = number(true, q.Ask-q.Bid)
		out["q0_spread_125_ratio"] = number(true, (q.Ask-q.Bid)/125)
		out["q0_entry_minus_last_atr5_to_side"] = normalize(true, s*(entry-q.Last), atr5)
		if p, ok := in.Snapshot.Frames[300]; ok && p.Frame.Frame.PriceKnown {
			t := p.Frame.Frame.Technical
			out["q0_entry_minus_ema8_atr5_to_side"] = normalize(t.EMA8.Known, s*(entry-t.EMA8.Value), atr5)
			out["q0_entry_minus_ema21_atr5_to_side"] = normalize(t.EMA21.Known, s*(entry-t.EMA21.Value), atr5)
		}
		bb := in.Snapshot.BB15
		if bb.Known {
			out["q0_entry_minus_bbmean_sigma_to_side"] = normalize(true, s*(entry-bb.Mean), rules.Value{Known: bb.Known, Value: bb.Sigma})
			f := bb.Upper
			if side < 0 {
				f = bb.Lower
			}
			out["bb15_forward_room_125_ratio_to_side"] = number(true, s*(f-entry)/125)
			out["bb15_mean_room_125_ratio_to_side"] = number(true, s*(bb.Mean-entry)/125)
		}
	}
	n := len(in.Minutes)
	r := in.Minutes[n-1]
	rknown := priceBar(r)
	if rknown {
		o := r.OHLC
		span := o.High - o.Low
		out["m1_range_atr5_ratio"] = normalize(true, span, atr5)
		out["q0_last_minus_m1_close_atr5_to_side"] = normalize(true, s*(q.Last-o.Close), atr5)
		if span > 0 {
			f, op := o.High-math.Max(o.Open, o.Close), math.Min(o.Open, o.Close)-o.Low
			pos := (o.Close - o.Low) / span
			if side < 0 {
				f, op = op, f
				pos = 1 - pos
			}
			out["m1_body_ratio_to_side"] = number(true, s*(o.Close-o.Open)/span)
			out["m1_forward_wick_ratio"] = number(true, f/span)
			out["m1_opposite_wick_ratio"] = number(true, op/span)
			out["m1_close_position_to_side"] = number(true, pos)
		}
	}
	if n >= 2 {
		p := in.Minutes[n-2]
		if priceBar(p) && adjacent(p, r) {
			if span := p.OHLC.High - p.OHLC.Low; span > 0 {
				out["m1_previous_body_ratio_to_side"] = number(true, s*(p.OHLC.Close-p.OHLC.Open)/span)
			}
		}
		if rknown && priceBar(p) && adjacent(p, r) {
			o := r.OHLC
			po := p.OHLC
			tr := math.Max(o.High-o.Low, math.Max(math.Abs(o.High-po.Close), math.Abs(o.Low-po.Close)))
			out["m1_tr_atr5_ratio"] = normalize(true, tr, atr5)
			out["m1_close_delta_atr5_to_side"] = normalize(true, s*(o.Close-po.Close), atr5)
			out["m1_body_reclaim_atr5_to_side"] = normalize(true, s*(o.Close-po.Open), atr5)
		}
		if adjacent(p, r) && p.Closed && r.Closed && p.VolumeKnown && r.VolumeKnown && p.Volume > 0 {
			out["m1_volume_ratio_previous"] = number(true, r.Volume/p.Volume)
		}
	}
	if n == 4 {
		prior := in.Minutes[:3]
		contiguous := adjacent(prior[2], r)
		for i := 1; i < len(prior); i++ {
			contiguous = contiguous && adjacent(prior[i-1], prior[i])
		}
		ok := contiguous
		for i, b := range prior {
			ok = ok && priceBar(b)
			if i > 0 {
				ok = ok && adjacent(prior[i-1], b)
			}
		}
		ok = ok && adjacent(prior[2], r)
		if ok {
			high, low := prior[0].OHLC.High, prior[0].OHLC.Low
			for _, b := range prior {
				high = math.Max(high, b.OHLC.High)
				low = math.Min(low, b.OHLC.Low)
			}
			edge := high
			if side < 0 {
				edge = low
			}
			out["q0_last_minus_prior3_forward_edge_atr5_to_side"] = normalize(true, s*(q.Last-edge), atr5)
			if normal {
				out["q0_prior3_forward_room_125_to_side"] = number(true, s*(edge-entry)/125)
			}
			if span := high - low; span > 0 {
				if rknown {
					out["m1_body_range_prior3_to_side"] = number(true, s*(r.OHLC.Close-r.OHLC.Open)/span)
				}
				if normal {
					pos := (entry - low) / span
					if side < 0 {
						pos = 1 - pos
					}
					out["q0_entry_prior3_percent_to_side"] = number(true, pos)
				}
			}
		}
		volumeKnown := contiguous && r.Closed && r.VolumeKnown
		sum := 0.
		for _, b := range prior {
			volumeKnown = volumeKnown && b.Closed && b.VolumeKnown
			sum += b.Volume
		}
		if volumeKnown && sum > 0 {
			out["m1_volume_relative_prior3"] = number(true, r.Volume/(sum/3))
		}
	}
	return out
}

// Compute は同じq0の買Askと売Bidを別々に計算し、共通辞書順100配列へ射影します。
//
// 引数: in(Input)はq0/当時Snapshot/当場1〜4slotだけです。
// 返り値: Pair/error。q1/Raw/ラベル/ファイルを受けず、副作用や保存を行いません。
func Compute(in Input) (Pair, error) {
	if err := validateInput(in); err != nil {
		return Pair{}, err
	}
	columns := fixedCatalog148
	var result Pair
	for _, side := range []int{1, -1} {
		legacy := features(Query{Session: in.Snapshot.SessionID, Contract: in.Snapshot.Contract, Side: side, BirthQuote: rules.Quote{Time: in.Q0.Time, Index: in.Q0.Index, Line: in.Q0.Line, Last: in.Q0.Last}}, in.Snapshot)
		extra := additions(in, side)
		row := SideRow{Side: side}
		for i, c := range columns {
			value, ok := legacy.Values[c.Name]
			if !ok {
				value = extra[c.Name]
			}
			if value.Known && value.Value != nil {
				x := *value.Value
				if !finite148(x) {
					return Pair{}, fmt.Errorf("既知Xに非有限値")
				}
				row.X[i] = &x
			}
		}
		if side > 0 {
			result.Buy = row
			result.Metadata = Metadata{Refs: append([]rules.Ref{}, legacy.Refs...), Feet: legacy.Feet, Missing: append([]string{}, legacy.Missing...), Flags: legacy.Flags, ShortRefs: []ShortRef{}}
		} else {
			result.Sell = row
		}
	}
	q := in.Q0
	meta := QuoteMetadata{Time: q.Time, Index: q.Index, Line: q.Line, Last: q.Last, QuoteOK: q.QuoteOK, NormalBBO: normalQuote(q), BidFinite: finite148(q.Bid), AskFinite: finite148(q.Ask)}
	if meta.BidFinite {
		x := q.Bid
		meta.Bid = &x
	}
	if meta.AskFinite {
		x := q.Ask
		meta.Ask = &x
	}
	result.Metadata.Q0 = meta
	for _, b := range in.Minutes {
		result.Metadata.ShortRefs = append(result.Metadata.ShortRefs, ShortRef{ID: b.ID, Session: b.Session, Contract: b.Contract, Start: b.Start, End: b.End, AvailableAt: b.AvailableAt, Stamp: b.Stamp, PriceKnown: b.PriceKnown, VolumeKnown: b.VolumeKnown, Closed: b.Closed})
	}
	return result, nil
}
