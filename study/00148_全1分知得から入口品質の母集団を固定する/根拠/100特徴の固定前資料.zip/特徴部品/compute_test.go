package features148

import (
	"encoding/json"
	"math"
	"reflect"
	"sort"
	"testing"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// k148 は人工の既知値を作ります。
//
// 引数: x(float64)。返り値: rules.Valueです。
func k148(x float64) rules.Value { return rules.Value{Known: true, Value: x} }

// input148 は100列すべてが既知になる非対称な人工q0/Snapshot/4slotを作ります。
//
// 引数: ありません。返り値: Inputです。自然ファイルは読みません。
func input148() Input {
	q := Quote{Time: 1865, Index: 100, Line: 101, Last: 110, Bid: 107, Ask: 114, QuoteOK: true}
	snap := rules.Snapshot{SessionID: "当場", Contract: "限月", AsOf: rules.Quote{Time: q.Time, Index: q.Index, Line: q.Line, Last: q.Last}, Frames: map[int]rules.Publication{},
		RVOL5: k148(1.5), BB15: rules.Bands{Known: true, Count: 20, Mean: 105, Sigma: 10, Upper: 125, Lower: 85}}
	for _, w := range []int{300, 900, 1800} {
		atr := 10. * float64(w/300)
		if w == 900 {
			atr = 20
		}
		if w == 1800 {
			atr = 30
		}
		tech := rules.Technical{EMA8: k148(102), EMA21: k148(100), EMA8Delta: k148(.5), EMA21Delta: k148(.25), Gap: k148(2), ATR: k148(atr), PreviousATR: k148(8), TR: k148(12), RSI: k148(60), PreviousRSI: k148(55), Histogram: k148(1), PreviousHistogram: k148(.5)}
		p := rules.Publication{Stamp: rules.Stamp{Time: 1860, Index: 90, Line: 91}, Frame: rules.Frame{Frame: rules.ChartFrame{ID: map[int]string{300: "5分", 900: "15分", 1800: "30分"}[w], SessionID: "当場", Contract: "限月", Width: w, Start: 1800 - float64(w), End: 1800, AvailableAt: 1860, DeliveryAt: 1860, PriceKnown: true, VolumeKnown: true, Volume: 100, OHLC: rules.OHLC{Open: 103, High: 114, Low: 98, Close: 108}, Technical: tech}, DMI: rules.DMI{PlusDI: k148(30), MinusDI: k148(10), ADX: k148(25), PreviousADX: k148(20)}}}
		snap.Frames[w] = p
		snap.Refs = append(snap.Refs, rules.Ref{ID: p.Frame.Frame.ID, Width: w, End: 1800, Delivered: p.Stamp})
	}
	prices := []rules.OHLC{{Open: 95, High: 102, Low: 92, Close: 99}, {Open: 100, High: 108, Low: 96, Close: 105}, {Open: 106, High: 112, Low: 101, Close: 103}, {Open: 103, High: 119, Low: 99, Close: 116}}
	minutes := []Minute{}
	for i, o := range prices {
		end := 1620 + float64(i*60)
		minutes = append(minutes, Minute{ID: []string{"a", "b", "p", "r"}[i], Session: "当場", Contract: "限月", Start: end - 60, End: end, AvailableAt: end + 60, Stamp: rules.Stamp{Time: end + 60, Index: 10 + i*20, Line: 11 + i*20}, OHLC: o, Volume: []float64{5, 10, 15, 30}[i], PriceKnown: true, VolumeKnown: true, Closed: true})
	}
	return Input{Q0: q, Snapshot: snap, Minutes: minutes}
}

// clone148 は人工入力を深いcopyへ分離します。
//
// 引数: in(Input)。返り値: Inputです。有限な人工票だけに使います。
func clone148(in Input) Input {
	raw, _ := json.Marshal(in)
	var out Input
	_ = json.Unmarshal(raw, &out)
	return out
}

// value148 は辞書順配列から指定列を検索します。
//
// 引数: row(SideRow)、name(string)。返り値: *float64はnilなら未知です。
func value148(row SideRow, name string) *float64 {
	for i, c := range Catalog() {
		if c.Name == name {
			return row.X[i]
		}
	}
	panic("未知の列名")
}

// want148 は既知値と許容誤差を検査します。
//
// 引数: t(*testing.T)、row(SideRow)、name(string)、want(float64)。返り値: ありません。
func want148(t *testing.T, row SideRow, name string, want float64) {
	t.Helper()
	p := value148(row, name)
	if p == nil || math.Abs(*p-want) > 1e-10 {
		t.Fatalf("%s=%v、期待%v", name, p, want)
	}
}

// same148 は100列すべてのknownと値を比較します。
//
// 引数: t(*testing.T)、a/b(SideRow)。返り値: ありません。side自体は比較しません。
func same148(t *testing.T, a, b SideRow) {
	t.Helper()
	for i, c := range Catalog() {
		if (a.X[i] == nil) != (b.X[i] == nil) {
			t.Fatal(c.Name, "known差")
		}
		if a.X[i] != nil && math.Abs(*a.X[i]-*b.X[i]) > 1e-9 {
			t.Fatal(c.Name, *a.X[i], *b.X[i])
		}
	}
}

// TestCatalogAndLegacy148 は100全辞書順と旧74名への射影値/式/単位同体を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestCatalogAndLegacy148(t *testing.T) {
	in := input148()
	before := clone148(in)
	pair, err := Compute(in)
	if err != nil {
		t.Fatal(err)
	}
	cols := Catalog()
	if len(cols) != 100 || len(catalog()) != 74 || len(addedCatalog()) != 26 {
		t.Fatal("列数")
	}
	names := []string{}
	seen := map[string]bool{}
	for _, c := range cols {
		if c.Role == "" || c.Unit == "" || c.Formula == "" || c.Mirror == "" || c.Needs == "" || c.Unknown == "" || seen[c.Name] {
			t.Fatal("定義不足/重複", c.Name)
		}
		seen[c.Name] = true
		names = append(names, c.Name)
	}
	if !sort.StringsAreSorted(names) {
		t.Fatal("非辞書順")
	}
	for _, side := range []int{1, -1} {
		old := features(Query{Session: in.Snapshot.SessionID, Contract: in.Snapshot.Contract, Side: side, BirthQuote: in.Snapshot.AsOf}, in.Snapshot)
		row := pair.Buy
		if side < 0 {
			row = pair.Sell
		}
		for name, def := range catalog() {
			c := cols[sort.SearchStrings(names, name)]
			if c.Role != def.Role || c.Unit != def.Unit || c.Formula != def.Formula {
				t.Fatal("旧定義変更", name)
			}
			got := value148(row, name)
			want := old.Values[name]
			if (got != nil) != want.Known || (got != nil && *got != *want.Value) {
				t.Fatal("旧74値/known差", name)
			}
		}
		for i, v := range row.X {
			if v == nil || math.IsNaN(*v) || math.IsInf(*v, 0) {
				t.Fatal("完全人工の未知/非有限", cols[i].Name)
			}
		}
	}
	cols[0].Name = "外部変更"
	if Catalog()[0].Name == "外部変更" || !reflect.DeepEqual(in, before) {
		t.Fatal("入力/辞書を共有変更")
	}
}

// TestAdded26ClosedForm148 は非対称Ask/Bidから追加26を手計算の期待値へ比較します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestAdded26ClosedForm148(t *testing.T) {
	pair, err := Compute(input148())
	if err != nil {
		t.Fatal(err)
	}
	expected := map[string][2]float64{
		"q0_spread_points": {7, 7}, "q0_spread_125_ratio": {7. / 125, 7. / 125}, "q0_entry_minus_last_atr5_to_side": {.4, .3},
		"q0_entry_minus_ema8_atr5_to_side": {1.2, -.5}, "q0_entry_minus_ema21_atr5_to_side": {1.4, -.7}, "q0_entry_minus_bbmean_sigma_to_side": {.9, -.2},
		"bb15_forward_room_125_ratio_to_side": {11. / 125, 22. / 125}, "bb15_mean_room_125_ratio_to_side": {-9. / 125, 2. / 125},
		"target125_atr5_ratio": {12.5, 12.5}, "target125_atr15_ratio": {6.25, 6.25}, "m1_range_atr5_ratio": {2, 2}, "m1_body_ratio_to_side": {.65, -.65},
		"m1_forward_wick_ratio": {.15, .2}, "m1_opposite_wick_ratio": {.2, .15}, "m1_close_position_to_side": {.85, .15}, "m1_tr_atr5_ratio": {2, 2},
		"m1_close_delta_atr5_to_side": {1.3, -1.3}, "q0_last_minus_m1_close_atr5_to_side": {-.6, .6}, "m1_volume_ratio_previous": {2, 2},
		"m1_body_reclaim_atr5_to_side": {1, -1}, "m1_previous_body_ratio_to_side": {-3. / 11, 3. / 11}, "q0_last_minus_prior3_forward_edge_atr5_to_side": {-.2, -1.8},
		"q0_prior3_forward_room_125_to_side": {-2. / 125, 15. / 125}, "q0_entry_prior3_percent_to_side": {1.1, .25}, "m1_volume_relative_prior3": {3, 3}, "m1_body_range_prior3_to_side": {.65, -.65},
	}
	if len(expected) != 26 {
		t.Fatal("26期待値不足")
	}
	for name, w := range expected {
		want148(t, pair.Buy, name, w[0])
		want148(t, pair.Sell, name, w[1])
	}
	if *value148(pair.Buy, "q0_entry_minus_ema8_atr5_to_side") == -*value148(pair.Sell, "q0_entry_minus_ema8_atr5_to_side") {
		t.Fatal("両側価格を単純符号反転")
	}
}

// transform148 は人工価格の全反射又は平行移動を行います。
//
// 引数: in(Input)、base(float64)、mirror(bool)。返り値: Inputは変換済みcopyです。
func transform148(in Input, base float64, mirror bool) Input {
	out := clone148(in)
	f := func(x float64) float64 {
		if mirror {
			return base - x
		}
		return base + x
	}
	ohlc := func(o rules.OHLC) rules.OHLC {
		if mirror {
			return rules.OHLC{Open: f(o.Open), High: f(o.Low), Low: f(o.High), Close: f(o.Close)}
		}
		return rules.OHLC{Open: f(o.Open), High: f(o.High), Low: f(o.Low), Close: f(o.Close)}
	}
	out.Q0.Last = f(in.Q0.Last)
	out.Q0.Bid = f(in.Q0.Bid)
	out.Q0.Ask = f(in.Q0.Ask)
	if mirror {
		out.Q0.Bid, out.Q0.Ask = out.Q0.Ask, out.Q0.Bid
	}
	out.Snapshot.AsOf.Last = out.Q0.Last
	for width, p := range out.Snapshot.Frames {
		p.Frame.Frame.OHLC = ohlc(p.Frame.Frame.OHLC)
		a := &p.Frame.Frame.Technical
		a.EMA8.Value = f(a.EMA8.Value)
		a.EMA21.Value = f(a.EMA21.Value)
		if mirror {
			for _, v := range []*rules.Value{&a.Gap, &a.EMA8Delta, &a.EMA21Delta, &a.Histogram, &a.PreviousHistogram} {
				v.Value = -v.Value
			}
			a.RSI.Value = 100 - a.RSI.Value
			a.PreviousRSI.Value = 100 - a.PreviousRSI.Value
			p.Frame.DMI.PlusDI, p.Frame.DMI.MinusDI = p.Frame.DMI.MinusDI, p.Frame.DMI.PlusDI
		}
		out.Snapshot.Frames[width] = p
	}
	bb := &out.Snapshot.BB15
	bb.Mean = f(bb.Mean)
	bb.Upper = f(bb.Upper)
	bb.Lower = f(bb.Lower)
	if mirror {
		bb.Upper, bb.Lower = bb.Lower, bb.Upper
	}
	for i := range out.Minutes {
		out.Minutes[i].OHLC = ohlc(out.Minutes[i].OHLC)
	}
	return out
}

// TestMirrorAndTranslation148 は価格全反射+s反転と価格平行移動の100列不変を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestMirrorAndTranslation148(t *testing.T) {
	in := input148()
	a, _ := Compute(in)
	b, err := Compute(transform148(in, 300, true))
	if err != nil {
		t.Fatal(err)
	}
	same148(t, a.Buy, b.Sell)
	same148(t, a.Sell, b.Buy)
	c, err := Compute(transform148(in, 10000, false))
	if err != nil {
		t.Fatal(err)
	}
	same148(t, a.Buy, c.Buy)
	same148(t, a.Sell, c.Sell)
}

// TestAbnormalBBO148 は異常気配でも価格形状を失わず、P0/spreadだけnullにします。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestAbnormalBBO148(t *testing.T) {
	dependent := []string{"q0_spread_points", "q0_spread_125_ratio", "q0_entry_minus_last_atr5_to_side", "q0_entry_minus_ema8_atr5_to_side", "q0_entry_minus_ema21_atr5_to_side", "q0_entry_minus_bbmean_sigma_to_side", "bb15_forward_room_125_ratio_to_side", "bb15_mean_room_125_ratio_to_side", "q0_prior3_forward_room_125_to_side", "q0_entry_prior3_percent_to_side"}
	for _, kind := range []string{"cross", "zero", "flag", "NaN", "Inf"} {
		in := input148()
		switch kind {
		case "cross":
			in.Q0.Bid = 120
		case "zero":
			in.Q0.Bid = 0
		case "flag":
			in.Q0.QuoteOK = false
		case "NaN":
			in.Q0.Bid = math.NaN()
		case "Inf":
			in.Q0.Ask = math.Inf(1)
		}
		out, err := Compute(in)
		if err != nil {
			t.Fatal(err)
		}
		for _, row := range []SideRow{out.Buy, out.Sell} {
			for _, name := range dependent {
				if value148(row, name) != nil {
					t.Fatal("異常BBOに既知実側", kind, name)
				}
			}
			want148(t, row, "m1_range_atr5_ratio", 2)
			want148(t, row, "target125_atr5_ratio", 12.5)
		}
		if _, err := json.Marshal(out); err != nil {
			t.Fatal("異常気配metadataがJSON不可能", err)
		}
	}
}

// TestUnknownZeroAndVolume148 は価格と量の独立known・0分母・既知0を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestUnknownZeroAndVolume148(t *testing.T) {
	in := input148()
	for i := range in.Minutes {
		in.Minutes[i].PriceKnown = false
	}
	out, err := Compute(in)
	if err != nil {
		t.Fatal(err)
	}
	want148(t, out.Buy, "m1_volume_ratio_previous", 2)
	want148(t, out.Buy, "m1_volume_relative_prior3", 3)
	if value148(out.Buy, "m1_body_ratio_to_side") != nil || value148(out.Buy, "q0_entry_prior3_percent_to_side") != nil {
		t.Fatal("未知価格を形状へ使用")
	}
	in = input148()
	in.Minutes[3].Volume = 0
	out, _ = Compute(in)
	want148(t, out.Buy, "m1_volume_ratio_previous", 0)
	want148(t, out.Buy, "m1_volume_relative_prior3", 0)
	in.Minutes[2].Volume = 0
	out, _ = Compute(in)
	if value148(out.Buy, "m1_volume_ratio_previous") != nil {
		t.Fatal("0量分母")
	}
	in = input148()
	in.Minutes[0].VolumeKnown = false
	out, _ = Compute(in)
	if value148(out.Buy, "m1_volume_relative_prior3") != nil {
		t.Fatal("未知量補完")
	}
	want148(t, out.Buy, "m1_body_range_prior3_to_side", .65)
	in = input148()
	in.Snapshot.BB15.Sigma = 0
	in.Snapshot.BB15.Upper = 105
	in.Snapshot.BB15.Lower = 105
	p := in.Snapshot.Frames[300]
	p.Frame.Frame.Technical.ATR = k148(0)
	in.Snapshot.Frames[300] = p
	out, err = Compute(in)
	if err != nil {
		t.Fatal(err)
	}
	if value148(out.Buy, "q0_entry_minus_bbmean_sigma_to_side") != nil || value148(out.Buy, "target125_atr5_ratio") != nil {
		t.Fatal("σ/ATR0補完")
	}
	want148(t, out.Buy, "m5_gap_to_side", 2)
	in = input148()
	in.Minutes[3].OHLC = rules.OHLC{Open: 116, High: 116, Low: 116, Close: 116}
	out, _ = Compute(in)
	want148(t, out.Buy, "m1_range_atr5_ratio", 0)
	if value148(out.Buy, "m1_body_ratio_to_side") != nil {
		t.Fatal("0足幅で形状比")
	}
	in = input148()
	in.Minutes[3].PriceKnown = false
	out, _ = Compute(in)
	want148(t, out.Buy, "m1_previous_body_ratio_to_side", -3./11)
	in = input148()
	in.Minutes[1].Closed = false
	out, _ = Compute(in)
	if value148(out.Buy, "m1_volume_relative_prior3") != nil || value148(out.Buy, "q0_entry_prior3_percent_to_side") != nil {
		t.Fatal("未closedをprior3へ使用")
	}
	want148(t, out.Buy, "m1_volume_ratio_previous", 2)
	in = input148()
	for i := 0; i < 3; i++ {
		in.Minutes[i].OHLC = rules.OHLC{Open: 100, High: 100, Low: 100, Close: 100}
	}
	out, _ = Compute(in)
	if value148(out.Buy, "q0_entry_prior3_percent_to_side") != nil || value148(out.Buy, "m1_body_range_prior3_to_side") != nil {
		t.Fatal("prior3の0幅を分母へ使用")
	}
	want148(t, out.Buy, "q0_prior3_forward_room_125_to_side", -14./125)
	want148(t, out.Buy, "m1_volume_relative_prior3", 3)
}

// TestMetadataNotX148 は時計・ID・場名を整合的に変更してもXへ混入しないことを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。相対的な当時知得は保ちます。
func TestMetadataNotX148(t *testing.T) {
	in := input148()
	base, _ := Compute(in)
	const delta = 86400.
	in.Q0.Time += delta
	in.Q0.Index += 1000
	in.Q0.Line += 1000
	in.Snapshot.SessionID = "別日同形"
	in.Snapshot.Contract = "別の識別名"
	in.Snapshot.AsOf = rules.Quote{Time: in.Q0.Time, Index: in.Q0.Index, Line: in.Q0.Line, Last: in.Q0.Last}
	for width, p := range in.Snapshot.Frames {
		f := &p.Frame.Frame
		f.ID += "別名"
		f.SessionID, f.Contract = in.Snapshot.SessionID, in.Snapshot.Contract
		f.Start += delta
		f.End += delta
		f.AvailableAt += delta
		f.DeliveryAt += delta
		p.Stamp.Time += delta
		p.Stamp.Index += 1000
		p.Stamp.Line += 1000
		in.Snapshot.Frames[width] = p
	}
	for i := range in.Snapshot.Refs {
		r := &in.Snapshot.Refs[i]
		r.ID += "別名"
		r.End += delta
		r.Delivered.Time += delta
		r.Delivered.Index += 1000
		r.Delivered.Line += 1000
	}
	for i := range in.Minutes {
		m := &in.Minutes[i]
		m.ID += "別名"
		m.Session, m.Contract = in.Snapshot.SessionID, in.Snapshot.Contract
		m.Start += delta
		m.End += delta
		m.AvailableAt += delta
		m.Stamp.Time += delta
		m.Stamp.Index += 1000
		m.Stamp.Line += 1000
	}
	out, err := Compute(in)
	if err != nil {
		t.Fatal(err)
	}
	same148(t, base.Buy, out.Buy)
	same148(t, base.Sell, out.Sell)
}

// TestHistoryAndPrior3Exclusion148 は不足/gapを詰めず、rをprior3から除外します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestHistoryAndPrior3Exclusion148(t *testing.T) {
	in := input148()
	base, _ := Compute(in)
	in.Minutes[3].OHLC.High = 100000
	out, err := Compute(in)
	if err != nil {
		t.Fatal(err)
	}
	for _, name := range []string{"q0_last_minus_prior3_forward_edge_atr5_to_side", "q0_prior3_forward_room_125_to_side", "q0_entry_prior3_percent_to_side", "m1_body_range_prior3_to_side"} {
		if *value148(base.Buy, name) != *value148(out.Buy, name) {
			t.Fatal("rをprior3へ混入", name)
		}
	}
	in = input148()
	in.Minutes = append(in.Minutes[:2], in.Minutes[3])
	out, err = Compute(in)
	if err != nil {
		t.Fatal(err)
	}
	for _, name := range []string{"m1_tr_atr5_ratio", "m1_body_reclaim_atr5_to_side", "q0_entry_prior3_percent_to_side"} {
		if value148(out.Buy, name) != nil {
			t.Fatal("欠分を圧縮", name)
		}
	}
	want148(t, out.Buy, "m1_range_atr5_ratio", 2)
	in = input148()
	in.Minutes = in.Minutes[3:]
	out, err = Compute(in)
	if err != nil {
		t.Fatal(err)
	}
	if value148(out.Buy, "m1_previous_body_ratio_to_side") != nil {
		t.Fatal("前足を補完")
	}
	want148(t, out.Buy, "m1_range_atr5_ratio", 2)
}

// TestSameRawAndContractGuards148 は同Raw履歴を許し、未来/scope/逆順/既知非有限を拒否します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestSameRawAndContractGuards148(t *testing.T) {
	in := input148()
	for i := range in.Minutes {
		in.Minutes[i].Stamp = rules.Stamp{Time: in.Q0.Time, Index: in.Q0.Index, Line: in.Q0.Line}
	}
	if _, err := Compute(in); err != nil {
		t.Fatal("同Raw履歴を拒否", err)
	}
	for _, kind := range []string{"futureTime", "futureIndex", "futureLine", "futureShort", "scope", "reverse", "NaNknown", "zeroSlots", "tooMany"} {
		in = input148()
		p := in.Snapshot.Frames[300]
		switch kind {
		case "futureTime":
			p.Stamp.Time = in.Q0.Time + 1
		case "futureIndex":
			p.Stamp.Index = in.Q0.Index + 1
		case "futureLine":
			p.Stamp.Line = in.Q0.Line + 1
		case "futureShort":
			in.Minutes[3].Stamp.Time = in.Q0.Time + 1
		case "scope":
			in.Minutes[0].Contract = "別限月"
		case "reverse":
			in.Minutes[0], in.Minutes[1] = in.Minutes[1], in.Minutes[0]
		case "NaNknown":
			p.Frame.Frame.Technical.EMA8 = k148(math.NaN())
		case "zeroSlots":
			in.Minutes = nil
		case "tooMany":
			in.Minutes = append(in.Minutes, in.Minutes[3])
		}
		in.Snapshot.Frames[300] = p
		if _, err := Compute(in); err == nil {
			t.Fatal("不正契約を受理", kind)
		}
	}
	typ := reflect.TypeOf(Input{})
	if typ.NumField() != 3 {
		t.Fatal("想定外API入力")
	}
	for _, name := range []string{"Q1", "Raw", "Label", "Labels", "Path", "FuturePublications"} {
		if _, ok := typ.FieldByName(name); ok {
			t.Fatal("未来/ファイル引数", name)
		}
	}
}
