package main

import (
	"encoding/json"
	"fmt"
	"os"

	features "github.com/masayoshi4649/SessionTradeExecuter/features148"
)

// main は自然入力を読まず、共通100列辞書だけを標準出力へ書き出します。
//
// 引数: ありません。返り値: ありません。失敗時は非0終了です。
func main() {
	encoder := json.NewEncoder(os.Stdout)
	encoder.SetIndent("", "  ")
	encoder.SetEscapeHTML(false)
	if err := encoder.Encode(features.Catalog()); err != nil {
		fmt.Fprintln(os.Stderr, "列定義を書き出せません:", err)
		os.Exit(1)
	}
}
