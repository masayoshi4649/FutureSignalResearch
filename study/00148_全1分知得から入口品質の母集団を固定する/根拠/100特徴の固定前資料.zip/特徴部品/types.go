package features148

import rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"

const Count = 100

// Quote はq0の現在情報だけです。q1、将来品質、ファイル、ラベルを持ちません。
type Quote struct {
	Time    float64 `json:"time"`
	Index   int     `json:"index"`
	Line    int     `json:"source_line"`
	Last    float64 `json:"last"`
	Bid     float64 `json:"bid"`
	Ask     float64 `json:"ask"`
	QuoteOK bool    `json:"quote_ok"`
}

// Minute は欠分を詰めない当場1分slotです。未知はPriceKnown/VolumeKnownで保持します。
type Minute struct {
	ID          string      `json:"id"`
	Session     string      `json:"session"`
	Contract    string      `json:"contract"`
	Start       float64     `json:"start"`
	End         float64     `json:"end"`
	AvailableAt float64     `json:"available_at"`
	Stamp       rules.Stamp `json:"stamp"`
	OHLC        rules.OHLC  `json:"ohlc"`
	Volume      float64     `json:"volume"`
	PriceKnown  bool        `json:"price_known"`
	VolumeKnown bool        `json:"volume_known"`
	Closed      bool        `json:"closed"`
}

// Input は当時Snapshotと直近1〜4slotだけを受けます。未来publication配列もありません。
type Input struct {
	Q0       Quote          `json:"q0"`
	Snapshot rules.Snapshot `json:"snapshot"`
	Minutes  []Minute       `json:"minutes"`
}

// Column は全行共通の辞書です。Name100個を各行へ重複保存しません。
type Column struct {
	Name    string `json:"name"`
	Role    string `json:"role"`
	Unit    string `json:"unit"`
	Formula string `json:"formula"`
	Mirror  string `json:"mirror"`
	Needs   string `json:"needs"`
	Unknown string `json:"unknown"`
}
type SideRow struct {
	Side int             `json:"side"`
	X    [Count]*float64 `json:"x"`
}
type ShortRef struct {
	ID          string      `json:"id"`
	Session     string      `json:"session"`
	Contract    string      `json:"contract"`
	Start       float64     `json:"start"`
	End         float64     `json:"end"`
	AvailableAt float64     `json:"available_at"`
	Stamp       rules.Stamp `json:"stamp"`
	PriceKnown  bool        `json:"price_known"`
	VolumeKnown bool        `json:"volume_known"`
	Closed      bool        `json:"closed"`
}

// QuoteMetadata は非有限気配をnullとfinite旗へ分離し、異常値をXへ入れません。
type QuoteMetadata struct {
	Time      float64  `json:"time"`
	Index     int      `json:"index"`
	Line      int      `json:"source_line"`
	Last      float64  `json:"last"`
	Bid       *float64 `json:"bid"`
	Ask       *float64 `json:"ask"`
	BidFinite bool     `json:"bid_finite"`
	AskFinite bool     `json:"ask_finite"`
	QuoteOK   bool     `json:"quote_ok"`
	NormalBBO bool     `json:"normal_bbo"`
}
type Metadata struct {
	Q0        QuoteMetadata    `json:"q0"`
	Refs      []rules.Ref      `json:"refs"`
	Feet      map[string]*Foot `json:"feet"`
	ShortRefs []ShortRef       `json:"short_refs"`
	Missing   []string         `json:"missing"`
	Flags     map[string]*bool `json:"flags"`
}
type Pair struct {
	Buy      SideRow  `json:"buy"`
	Sell     SideRow  `json:"sell"`
	Metadata Metadata `json:"metadata"`
}
