"""自然データを読まず、Go正本の列辞書をJSONとMarkdownへ保存する。"""

import json
from pathlib import Path
import subprocess


def main():
    """共通列定義を生成する。

    引数: なし。
    返り値: None。GoのCatalogだけを呼び、自然入力は開かない。
    """
    folder = Path(__file__).resolve().parent
    result = subprocess.run(
        ["go", "run", "./cmd/catalog"], cwd=folder, check=True,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
    )
    columns = json.loads(result.stdout)
    names = [column["name"] for column in columns]
    assert len(names) == len(set(names)) == 100 and names == sorted(names)
    (folder / "列定義.json").write_text(
        json.dumps(columns, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    lines = [
        "# 148の当時特徴100列",
        "",
        "旧74列を名前で射影した式・役割・単位・値・knownは同体とし、追加26列を合わせて100全体を列名の辞書順に固定する。各行はこの順番の配列で保存し、辞書は上位に一度だけ保存する。",
        "",
        "sは買+1/売−1、P0_sは正常q0の買Ask/売Bid。rは最新の当場1分slot、pはその実隣接前足、prior3はrを除く当場実連続3足。U3/L3はprior3のHigh最大/Low最小。固定125はpt尺度である。",
        "",
        "必要なknownは式が参照する項目ごとに判定する。価格未知でも量既知・closed・実連続なら量比は計算する。r量0は既知0、量未知・欠分・分母0を0で補完しない。pの実体比はrのOHLCを必要としない。prior3の価格端はrのOHLCを必要とせず、実体/prior3幅だけはr価格も必要とする。",
        "",
        "旧74式のlastはq0 Lastであり、Ask/Bidへ置換しない。追加P0列は同q0でも買と売で価格が違うため、売配列を買の単純符号反転で作らない。",
        "",
        "全反射は価格P'=C−P、Bid/Ask交換、s'＝−s、RSI'=100−RSI、DI交換、MA/Hist/増分反射、ADX/ATR/量不変とする。上下ヒゲは交換する。この全入力変換では各側100列が対応する反対側と同体になる。",
        "",
        "|列順|列名|役割|単位|式|必要参照|未知条件|鏡像|",
        "|---:|---|---|---|---|---|---|---|",
    ]
    for index, column in enumerate(columns, 1):
        fields = [column[key].replace("|", "\\|").replace("\n", " ") for key in (
            "name", "role", "unit", "formula", "needs", "unknown", "mirror"
        )]
        lines.append("|" + "|".join([str(index), *fields]) + "|")
    lines += ["", "生成元はCatalog()である。再生成: `python 列定義を書き出す.py`。自然価格・将来入力・ラベルを読まない。", ""]
    (folder / "列定義.md").write_text("\n".join(lines), encoding="utf-8")


if __name__ == "__main__":
    main()
