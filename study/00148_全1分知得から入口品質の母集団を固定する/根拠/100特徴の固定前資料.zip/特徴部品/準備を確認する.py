"""148の純特徴部品を人工だけで検査し、由来と出力指紋を保存する。"""

from datetime import datetime
import hashlib
import json
from pathlib import Path
import subprocess


def sha(path):
    """ファイル指紋を計算する。

    引数: path(Path)は小型コード又は本部品の列辞書。
    返り値: strはSHA256。自然価格ファイルには呼ばない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(folder, command):
    """人工検査又は構文・ビルドを実行する。

    引数: folder(Path)、command(list[str])。
    返り値: dictは終了値とUTF-8標準出力/標準エラー。失敗は例外。
    """
    result = subprocess.run(command, cwd=folder, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    output = {
        "コマンド": command,
        "終了値": result.returncode,
        "標準出力": result.stdout.decode("utf-8", errors="replace"),
        "標準エラー": result.stderr.decode("utf-8", errors="replace"),
    }
    if result.returncode:
        raise AssertionError(output)
    return output


def main():
    """準備の人工と停止前指紋を確定する。

    引数: なし。
    返り値: None。自然入力・ラベル・金融を読み込まない。
    """
    folder = Path(__file__).resolve().parent
    old = folder.parent / "全成立poolの当時特徴" / "features.go"
    rules = folder.parent / "118複数技法の入口条件"
    spec = folder.parent / "148_全1分知得の入口母集団を固定する採用仕様.md"
    own = sorted([
        *folder.glob("*.go"), *folder.glob("*.py"),
        *folder.glob("cmd/**/*.go"), folder / "go.mod", folder / "README.md",
        folder / "列定義.json", folder / "列定義.md",
    ])
    protected = [old, spec, *sorted(rules.glob("*.go")), rules / "go.mod"]
    paths = list(dict.fromkeys([*own, *protected]))
    before = {str(path.relative_to(folder.parent)): sha(path) for path in paths}
    expected = old.read_bytes().replace(b"package main", b"package features148", 1)
    assert old.read_bytes().count(b"package main") == 1
    assert (folder / "legacy74.go").read_bytes() == expected
    columns = json.loads((folder / "列定義.json").read_text(encoding="utf-8"))
    assert len(columns) == len({column["name"] for column in columns}) == 100
    assert [column["name"] for column in columns] == sorted(column["name"] for column in columns)
    assert all(all(column[key] for key in ("name", "role", "unit", "formula", "mirror", "needs", "unknown")) for column in columns)
    md = (folder / "列定義.md").read_text(encoding="utf-8")
    assert sum(line.startswith("|") and line.split("|")[1].isdigit() for line in md.splitlines()) == 100
    version = run(folder, ["go", "version"])
    tests = run(folder, ["go", "test", "-count=1", "-json", "./..."])
    events = [json.loads(line) for line in tests["標準出力"].splitlines() if line.strip()]
    successes = [event["Test"] for event in events if event.get("Action") == "pass" and event.get("Test")]
    assert len(successes) == 8 and not any(event.get("Action") == "fail" for event in events)
    checks = [run(folder, ["go", "vet", "./..."]), run(folder, ["go", "build", "./..."])]
    exported = run(folder, ["go", "run", "./cmd/catalog"])
    assert json.loads(exported["標準出力"]) == columns
    after = {str(path.relative_to(folder.parent)): sha(path) for path in paths}
    assert before == after
    (folder / "人工の実行.jsonl").write_text(tests["標準出力"], encoding="utf-8")
    proof = {
        "成功": True,
        "確認日時": datetime.now().astimezone().isoformat(),
        "対象": "148当時特徴の純部品・自然実行前の作者準備",
        "採用仕様SHA256": sha(spec),
        "Go環境": version["標準出力"].strip(),
        "人工主群": successes,
        "人工主群数": len(successes),
        "旧74正本": {"path": str(old.relative_to(folder.parent)), "sha256": sha(old)},
        "旧74コピーはpackage宣言だけ変更": True,
        "旧74式と値known射影": "Go人工で両側74列を完全一致。旧正本bytesは前後同体",
        "全列数": 100,
        "追加列数": 26,
        "全100辞書順": True,
        "追加26両側の手計算": True,
        "反射と平行移動": "価格全反射＋BidAsk交換＋s反転、価格平行移動で各100列一致",
        "量knownと価格knownを分離": True,
        "短期同Raw履歴を許容": True,
        "未来とscope契約違反を拒否": True,
        "q1Rawラベルファイルpublication配列をInputに持たない": True,
        "XへID時計日付場名限月価格水準を入れない": True,
        "列定義JSON": {"path": "列定義.json", "sha256": sha(folder / "列定義.json")},
        "列定義MD": {"path": "列定義.md", "sha256": sha(folder / "列定義.md")},
        "人工実行ログSHA256": sha(folder / "人工の実行.jsonl"),
        "構文vetbuild": checks,
        "限定静的レビュー": {
            "担当": "review131",
            "区分": "数式再実装による独立算術ではなく、追加26の式/known/接続のread-only確認",
            "報告": "重大な式・known依存の齟齬なし。BB20/carry正本や最新q0適格はSource側で監査する境界",
        },
        "前後コード列辞書同体": before == after,
        "源SHA256": after,
        "未実行": ["自然価格", "Raw", "CSV", "追加2場", "ラベル", "金融", "学習", "新入口の先着率"],
    }
    path = folder / "準備の確認.json"
    path.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"成功": True, "人工主群": len(successes), "準備SHA256": sha(path)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
