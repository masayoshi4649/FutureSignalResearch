# 148の当時特徴100列の純部品

q0で既に知っている背景と当場1分履歴から、買い・売り各100値を計算する。自然データ・学習・先着・損益は未実行である。この部品自体は入口の優位性を判定しない。

`github.com/masayoshi4649/SessionTradeExecuter/features148` の `package features148`。Go 1.24.2を用い、`../118複数技法の入口条件` をローカル依存とする。外部OSSの追加はない。

## API

```go
func Catalog() []Column
func Compute(in Input) (Pair, error)
```

`Input` は `Q0 Quote`、`Snapshot rules.Snapshot`、`Minutes []Minute` の3項目だけを持つ。q0には `Time/Index/Line/Last/Bid/Ask/QuoteOK`、Minuteには `ID/Session/Contract/Start/End/AvailableAt/Stamp/OHLC/Volume/PriceKnown/VolumeKnown/Closed` を渡す。`Minutes` は最新rを末尾とする当場1〜4slotであり、価格や量が未知でも詰めずに残す。

`Pair.Buy/Sell` は `SideRow{Side int, X [100]*float64}`。nilはJSONのnullで未知を表す。全known値は有限数とする。共通の `Catalog()` が全100列名の辞書順を返し、行ごとに100個の名前を重ねない。[列定義JSON](列定義.json)と[式・known条件の表](列定義.md)が正本である。

`Pair.Metadata` は `Q0/Refs/Feet/ShortRefs/Missing/Flags` をXの外へ保存する。q0異常気配の非有限値はMetadataでもnullとfinite旗へ分離する。生の非有限文字列を復元する目的のAPIではない。q0のID・価格水準・日付・時計・場名・限月名・品質・参照は、Xにそのまま入れない。

## 当時知得と未知の境界

- q0とSnapshot.AsOfのLast/Time/Index/Lineは一致させる。背景は同場・同限月の当時freshな5/15/30分Snapshotだけを使う。未来時刻・原行、別scope、逆順、幅違い等の契約違反はerrorにする。
- Snapshot.Frames/Refsは118Bank.Currentの当場最新3尺度である。BB20やcarryの跨場元refsはSource正本metadataが元場・同限月・元配送順を検査する。跨場元Index/Lineを当場q0と比較するためにSnapshot.Refsへ足さない。
- Minutesの市場End、AvailableAt、配送Stampはq0以前。欠分は圧縮せず、隣接式を未知にする。p/rが同Rawで遅れて一緒に知得された履歴は使用できる。147の初配送strict条件は引き継がない。
- p/prior3不足、価格未知、未closedは対応列だけnullにし、Compute全体を失敗させない。価格式と量式は必要knownを分け、価格未知でも実連続・closed・量既知なら量比を計算する。r量0は既知0、分母0・量未知・欠分は補完しない。
- 正常q0は `QuoteOK && finite(Bid,Ask) && 0<Bid<Ask`。正常時のみspreadとP0依存列を計算する。異常BBOでもLast・背景・短期形状の独立列を失わせない。
- 分母ATR/σ/必要足幅が0なら比率は未知。0という分子や値幅自体を未知へ変えない。prior3の端はrを含めず、価格位置のclipはしない。
- 関数にq1・Raw・ファイル・ラベル・将来publication配列を渡す欄がない。将来を渡さないことは呼出側のSnapshot生成・Source因果監査と合わせて確認するものであり、純関数だけで全履歴の由来を証明したとしない。

## 旧74列と追加26列

`legacy74.go` は旧 `../全成立poolの当時特徴/features.go` のpackage宣言だけを変更したコピーである。旧74列の定義と値・knownの計算は保持し、新100から旧名へ射影して同体を確認する。旧last系をAsk/Bidへ変更しない。

追加P0系は同じq0でも買Askと売Bidが違うため、買いと売りを明示的に2回計算する。全価格反射＋Bid/Ask交換＋側反転の人工では、旧74を含む100列が対応する反対側と同体になる。価格平行移動にも不変である。

## 再現と準備検査

```powershell
python 列定義を書き出す.py
go test -count=1 -v ./...
go vet ./...
go build ./...
python 準備を確認する.py
```

人工8主群は、列数と旧74射影、追加26の両側手計算、100列の価格反射/平行移動、異常BBO、価格と量の独立known・0分母、p不足/欠分/prior3除外、時計・ID非混入、同Rawと未来/scope/API拒否を扱う。自然価格・Raw・CSV・新損益を読み込まず実行する。準備票は独立レビューと区別した作者の人工証跡である。
