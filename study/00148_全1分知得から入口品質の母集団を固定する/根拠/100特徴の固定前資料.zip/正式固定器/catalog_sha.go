package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"

	features "github.com/masayoshi4649/SessionTradeExecuter/features148"
)

// main はSourceと同じjson.Marshalの共通辞書bytes指紋を返します。
//
// 引数: ありません。返り値: ありません。自然入力を読まず、列定義だけを直列化します。
func main() {
	body, err := json.Marshal(features.Catalog())
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	sum := sha256.Sum256(body)
	_ = json.NewEncoder(os.Stdout).Encode(map[string]any{
		"sha256": hex.EncodeToString(sum[:]), "bytes": len(body),
		"count": len(features.Catalog()), "serialization": "Go encoding/json.Marshal([]Column)、compact、HTML escape有り、改行なし",
	})
}
