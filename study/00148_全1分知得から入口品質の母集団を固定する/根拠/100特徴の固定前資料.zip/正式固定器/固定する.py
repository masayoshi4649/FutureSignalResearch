"""148の100列別紙を恒久保存し、実行前の正式文書へ指紋を追補する。"""

from datetime import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote
import zipfile


def digest(body):
    """小型資料bytesの指紋を計算する。

    引数: body(bytes)。返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


def same_or_create(path, body):
    """同体確認付きで一度だけ恒久ファイルを保存する。

    引数: path(Path)、body(bytes)。返り値: None。不一致の既存保存は拒否する。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == body, str(path)
    else:
        path.write_bytes(body)


def table_rows(body):
    """汎用表の57行を抜き出す。

    引数: body(bytes)。返り値: list[str]はID順を含む元行。
    """
    rows = [line for line in body.decode("utf-8").splitlines() if re.match(r"^\|\s*[A-Z]\d{2}\s*\|", line)]
    assert len(rows) == 57 and all(len(line.split("|")) == 13 for line in rows)
    return rows


def check_links(path):
    """Markdownのローカルリンクを実在確認する。

    引数: path(Path)。返り値: list[str]は確認したリンク。
    """
    checked = []
    for target in re.findall(r"\]\(([^)]+)\)", path.read_text(encoding="utf-8")):
        target = target.strip().split(" \"")[0]
        if target.startswith(("http:", "https:", "mailto:", "#")):
            continue
        resolved = (path.parent / unquote(target.split("#")[0])).resolve()
        assert resolved.exists(), (str(path), target)
        checked.append(target)
    return checked


def main():
    """原文退避・列定義保存・正式追補と限定検査を行う。

    引数: なし。返り値: None。自然Sourceや金融入力は開かない。
    """
    work = Path(__file__).resolve().parent
    root = work.parents[1]
    feature = root / "work/148全1分候補の当時特徴"
    source = root / "work/148全1分知得の入口母集団"
    formal = root / "study/00148_全1分知得から入口品質の母集団を固定する"
    input_dir = root / "inputs/00148_全1分入口母集団"
    spec = root / "work/148_全1分知得の入口母集団を固定する採用仕様.md"
    prepare_file = root / "work/148正式文書の準備確認.json"
    prepare_body = prepare_file.read_bytes()
    assert digest(prepare_body) == "4a89b6bba91e7ef29dcb628184fbb1a59fefb9e04b9d9943c67fb5979c2285ad"
    prepare = json.loads(prepare_body)
    assert digest(spec.read_bytes()) == prepare["採用仕様SHA256"] == "675b1afd79729ce6cd6f4d604337a92d006554d1c7963dcece23afaae4894f36"
    stopped = json.loads((feature / "停止の確認.json").read_bytes())
    assert digest((feature / "停止の確認.json").read_bytes()) == "fbfbd6aa076fd311d930539b57ff8fd0138a140df48070662aae15ec1ac40cc1"
    for item in stopped["保存対象"]:
        assert digest((feature / item["path"]).read_bytes()) == item["sha256"]
    protected = {path: digest(path.read_bytes()) for path in [
        *sorted(feature.glob("*.go")), *sorted(feature.glob("cmd/**/*.go")),
        *sorted(source.glob("*.go")), spec,
        *[root / name for name in prepare["旧147MD前後同体"]],
    ]}
    before = {}
    for name, expected in prepare["正式3MD"].items():
        path = root / name
        before[name] = path.read_bytes()
        assert digest(before[name]) == expected, name
    original_rows = table_rows(before[str((formal / "設定と結果.md").relative_to(root)).replace("\\", "/")])

    physical = (feature / "列定義.json").read_bytes()
    assert digest(physical) == "c85223fbe1543e5457c28d4391f817534099d1af1d19664035c668ff5fe8a7b4"
    columns = json.loads(physical)
    assert len(columns) == 100 and [item["name"] for item in columns] == sorted(item["name"] for item in columns)
    assert len({item["name"] for item in columns}) == 100
    compact = json.loads(subprocess.run(["go", "run", "."], cwd=work, check=True, stdout=subprocess.PIPE).stdout)
    assert compact["count"] == 100
    assert compact["sha256"] == "28603f343be9d14f2f19dad4ac824f2b23435af57916595f8aa8a0e1e00ca96c"

    # ----------------------------------------
    # 実行前3MDと部品・人工証跡は、追補より先に小型ZIPへ保存する。
    archive = {}
    for name, body in before.items():
        archive["事前文書/" + Path(name).name] = body
    archive["元正式準備/準備の確認.json"] = prepare_body
    archive["元正式準備/採用仕様.md"] = spec.read_bytes()
    for item in stopped["保存対象"]:
        if item["path"] in {"列定義.json", "列定義.md"}:
            continue
        archive["特徴部品/" + item["path"]] = (feature / item["path"]).read_bytes()
    archive["共用列辞書参照.json"] = (json.dumps({
        "JSON": {"path": "inputs/00148_全1分入口母集団/100特徴の列定義.json", "sha256": digest(physical)},
        "元MD": {"path": "study/" + formal.name + "/100特徴の列定義.md", "元MD_bytes": len((feature / "列定義.md").read_bytes()), "元MD_SHA256": digest((feature / "列定義.md").read_bytes()), "復元": "正式MDの先頭元MD_bytesを抽出。末尾は恒久参照だけ"},
        "複製回避": "列辞書JSONと元MDはこのZIPへ再複製しない",
    }, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    archive["特徴部品/停止の確認.json"] = (feature / "停止の確認.json").read_bytes()
    independent = root / "work/148特徴の独立検算"
    assert digest((independent / "準備の確認.json").read_bytes()) == "9cc5f52caa370bfa766e18b445e6849f7bce69c245d147cf0c70399945cb43f2"
    for name in ["go.mod", "independent_test.go", "準備の確認.json", "証跡を固定する.py", "人工の実行.txt"]:
        archive["Root独立人工/" + name] = (independent / name).read_bytes()
    old = root / "work/全成立poolの当時特徴/features.go"
    archive["旧74元コード/features.go"] = old.read_bytes()
    assert (feature / "legacy74.go").read_bytes() == old.read_bytes().replace(b"package main", b"package features148", 1)
    for path in [work / "go.mod", work / "catalog_sha.go", Path(__file__)]:
        archive["正式固定器/" + path.name] = path.read_bytes()
    zip_path = formal / "根拠/100特徴の固定前資料.zip"
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for name, body in sorted(archive.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 12, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            bundle.writestr(info, body, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    with zipfile.ZipFile(zip_path) as bundle:
        assert {name: bundle.read(name) for name in bundle.namelist()} == archive

    # ----------------------------------------
    # 整形JSONの物理bytesは一度だけコピーし、MDは元100行に参照だけ追加する。
    canonical = input_dir / "100特徴の列定義.json"
    same_or_create(canonical, physical)
    original_md = (feature / "列定義.md").read_bytes()
    md_link = "\n恒久列辞書：[100特徴の列定義.json](../../inputs/00148_全1分入口母集団/100特徴の列定義.json)。由来・コード・人工：[固定前資料](根拠/100特徴の固定前資料.zip)。指紋と知得境界：[正式条件のF0前追補](条件.md#f0前追補100特徴別紙の固定2026-11-12)。\n"
    formal_md = formal / "100特徴の列定義.md"
    same_or_create(formal_md, original_md + md_link.encode("utf-8"))
    binding = f"""

## F0前追補：100特徴別紙の固定（2026-11-12）

上記の「別紙SHA未取得・固定予定」は退避した準備原文の状態であり、本追補で別紙を固定した。自然生成・新Raw走査・金融・学習は引き続き未実行。採用仕様675b1afdの本文・母集団条件・57手法×9尺度の513セルは変更していない。

正本は[100特徴の列定義JSON](../../inputs/00148_全1分入口母集団/100特徴の列定義.json)と[説明表](100特徴の列定義.md)。100列全体の辞書順、旧74名への射影の式/役割/単位/値/known同体、追加26の明示式を固定する。買Ask0と売Bid0で2回計算し、売を買の単純符号反転で作らない。必要knownは参照項目ごとに判定し、価格未知でも実連続・closed・量既知なら量比を計算する。r量0は既知0、量未知・欠分・分母0を0補完しない。p実体はr価格を要せず、prior3の価格端はrを除く。

|対象|bytes又は方式|SHA256|
|---|---|---|
|恒久JSONの物理ファイル|UTF-8整形、{len(physical):,} bytes、元列定義JSONをbytesコピー|`{digest(physical)}`|
|Source用catalog共通辞書|Go json.Marshal(Catalog())、compact・HTML escape有り・改行なし、{compact['bytes']:,} bytes|`{compact['sha256']}`|
|正式説明表|元100行を維持し、恒久参照だけ追加、{len(formal_md.read_bytes()):,} bytes|`{digest(formal_md.read_bytes())}`|
|元説明表|内容原本、{len(original_md):,} bytes|`{digest(original_md)}`|
|列コードcatalog.go|役割/単位/式/必要参照/unknown/Mirror|`{digest((feature / 'catalog.go').read_bytes())}`|
|純計算compute.go|q0/当時Snapshot/当場1〜4slotだけ|`{digest((feature / 'compute.go').read_bytes())}`|
|旧74コピーlegacy74.go|package宣言だけ変更|`{digest((feature / 'legacy74.go').read_bytes())}`|
|作者の停止票|8主人工、test/vet/build、旧74bytes/射影、100列鏡像/平行移動|`fbfbd6aa076fd311d930539b57ff8fd0138a140df48070662aae15ec1ac40cc1`|
|Rootの独立人工|3群、追加26手計算/非対称両側/量known/同Raw/未来拒否。全100再実装ではない|`9cc5f52caa370bfa766e18b445e6849f7bce69c245d147cf0c70399945cb43f2`|

整形JSONの物理SHAとSource出力のcatalog_sha256は直列化bytesが違うため別の指紋である。名前・列順・全定義の内容は同体であり、片方のSHAを他方へ代入しない。コードSHAも辞書bytesのSHAと区別する。

APIはCompute(Input{{Q0,Snapshot,Minutes}})からBuy/Sell各SideとX [100]*float64、共通Metadataを返す。q1・Raw・ラベル・ファイル・未来publication配列は受け取らない。Refs/Feet/ShortRefs・日付/場名/ID/時計・元価格水準はXの外へ置く。当場Snapshot refsのguardと、Source側の跨場BB20/carry元refsの由来検査を分ける。SourceのR/J等の属性値は本追補で変更しない。

追補前3MD・元準備票4a89b6bb・675b1afd採用原文・コード/列辞書・作者/Root人工は[固定前資料](根拠/100特徴の固定前資料.zip)へ退避済み。[F0前固定の確認](検査/100特徴のF0前固定.json)で元条件prefix・全513セル・正式リンク・源前後同体を確認する。ここでの人工成功は新入口や取引目標達成の証拠ではない。
"""
    proof_path = formal / "検査/100特徴のF0前固定.json"
    proof_path.parent.mkdir(parents=True, exist_ok=True)
    # リンク先確認のため先に空のJSON文書を置き、直後に確定票で置き換える。
    same_or_create(proof_path, b"{}\n")
    for name, body in before.items():
        (root / name).write_bytes(body + binding.encode("utf-8"))
    input_readme = f"""# 148の100特徴共通辞書

正本は[100特徴の列定義.json](100特徴の列定義.json)。元整形JSONを一度だけbytesコピーし、物理SHAは`{digest(physical)}`、{len(physical):,} bytes。各行は100列名の辞書順の配列で、辞書は上位に一度だけ保存する。

Source用Go json.Marshal(Catalog())のcompact/HTML escape有り・改行なしのSHAは`{compact['sha256']}`（{compact['bytes']:,} bytes）。同じ内容でも直列化が違うため物理ファイルSHAと区別する。コードSHAは[正式条件](../../study/{formal.name}/条件.md)のF0前追補を参照する。

式・役割・単位・Mirror・必要参照・unknownは[正式別紙](../../study/{formal.name}/100特徴の列定義.md)。旧74射影同体と数量known独立、人工・由来は[固定前資料](../../study/{formal.name}/根拠/100特徴の固定前資料.zip)と[確認票](../../study/{formal.name}/検査/100特徴のF0前固定.json)に保存する。自然Source・新金融・追加2場は本保存では読んでいない。
"""
    same_or_create(input_dir / "README.md", input_readme.encode("utf-8"))

    # ----------------------------------------
    # 完全prefix保持と設定セル・静的リンク・固定源の不変を確認する。
    after = {name: (root / name).read_bytes() for name in before}
    assert all(after[name] == body + binding.encode("utf-8") for name, body in before.items())
    assert table_rows((formal / "設定と結果.md").read_bytes()) == original_rows
    assert formal_md.read_bytes() == original_md + md_link.encode("utf-8")
    assert digest(canonical.read_bytes()) == digest(physical)
    assert protected == {path: digest(path.read_bytes()) for path in protected}
    paths_to_check = [*(root / name for name in before), formal_md, input_dir / "README.md"]
    links = {str(path.relative_to(root)): check_links(path) for path in paths_to_check}
    proof = {
        "成功": True, "試行": 148, "確認日時": datetime.now().astimezone().isoformat(),
        "区分": "F0前の100列別紙固定。自然/金融の結果ではない",
        "元正式準備SHA256": digest(prepare_body), "採用本文SHA256": digest(spec.read_bytes()),
        "追補前3MD_SHA256": {name: digest(body) for name, body in before.items()},
        "追補後3MD_SHA256": {name: digest(body) for name, body in after.items()},
        "元3MD全bytesをprefix保持": True, "513セル完全同体": True,
        "全定義数": 100, "列名辞書順": True, "旧74式と値known射影同体": True,
        "量knownと価格knownを分離": True, "元MDは恒久参照追加だけ": True,
        "恒久JSON": {"path": str(canonical.relative_to(root)), "bytes": len(physical), "sha256": digest(physical)},
        "Source用catalog直列化": compact,
        "正式MD": {"path": str(formal_md.relative_to(root)), "bytes": len(formal_md.read_bytes()), "sha256": digest(formal_md.read_bytes())},
        "固定前ZIP": {"path": str(zip_path.relative_to(root)), "bytes": zip_path.stat().st_size, "sha256": digest(zip_path.read_bytes()), "files": len(archive)},
        "ZIP全bytes復元一致": True,
        "保護源SHA256": {str(path.relative_to(root)): value for path, value in protected.items()},
        "保護源前後同体": True, "Source_R_J等属性変更": False,
        "ローカルリンク実在数": sum(len(items) for items in links.values()), "リンク": links,
        "自然RawCSV金融追加2場読取": False,
    }
    proof_path.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("proof_sha256=" + digest(proof_path.read_bytes()))
    print("formal_catalog_md_sha256=" + digest(formal_md.read_bytes()))
    print("archive_sha256=" + digest(zip_path.read_bytes()))
    print("local_links=" + str(proof["ローカルリンク実在数"]))


if __name__ == "__main__":
    main()
