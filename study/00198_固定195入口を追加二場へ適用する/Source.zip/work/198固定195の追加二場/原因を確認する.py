"""追加二場の固定195を別算術で照合し、旧幹の確認迂回を診断する。"""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import importlib.util
import sys
import numpy as np
import 固定適用198 as F

ROOT=F.ROOT;HERE=Path(__file__).parent


def main() -> None:
    """
    機能: 全11案の集計照合と旧買い保留後の旧売り取得の当時特徴を保存する。
    引数: なし。
    返り値: None。追加二場由来の事後診断であり条件変更はしない。
    """
    spec=importlib.util.spec_from_file_location('独立183_for198',ROOT/'work/183損失安定性/新候補の集計を独立検査する.py')
    V=importlib.util.module_from_spec(spec);sys.modules[spec.name]=V;spec.loader.exec_module(V)
    metrics=F.read(HERE/'安定性198.json.gz')['metrics'];count=0
    for state in metrics:
        pack=F.read(HERE/'金融正本'/(state['id']+'.json.gz'));count+=V.verify(pack,state)
    F.U.save(HERE/'独立確認198.json',{'成功':True,'候補':len(metrics),'照合項目':count,'検査Source':F.U.ref(Path(V.__file__)),'注意':'別算術の台帳集計。別原板金融engineではない。'})
    p=F.N.load_pure_leg();features=p['features'];features.q0_prices=F.N.load_q0(p)
    R=F.R.R;P=R.P
    arrays,meta,times,phases,reset,prices=P._prepare(features)
    columns=[c['name'] if isinstance(c,dict) else c for c in features.columns]
    for side,name in enumerate(('buy_X','sell_X')):
        arrays[side]['m15_gap_to_side']=np.asarray(getattr(features,name))[:,columns.index('m15_gap_to_side')]
    previous=R._previous_five(arrays,reset);base,_,_=P.P.OLD.V1._base(p['baselines']['全期_J035'],len(times),phases)
    seed=810;cancel=825;state=R._state(seed,1,arrays,prices,base)
    rule=next(v for v in R.catalog()['rules'] if v['id']=='E193_04');profile=P.PROFILES['C120'];series=[]
    assert meta[seed]['session']==meta[cancel]['session']=='2026-11-17_Day'
    for i in range(seed,cancel+1):
        row={'event':i,'時刻JST':datetime.fromtimestamp(times[i],timezone(timedelta(hours=9))).isoformat(),
            'last':prices['last'][i],'bid':prices['bid'][i],'ask':prices['ask'][i],
            '旧core':int(base['birth']['core'][i]),'固定買い回復水準':state['reverse']['level'],
            '固定売り再テスト水準':state['follow']['level']}
        if i>seed:
            accept=P._accept(state['reverse'],arrays[0],i,1,times,prices,profile)
            row['買い価格受容成熟']=P._mature(state['reverse'],accept,i,1,times,prices,profile)
            row['買い全技術確認']=R._reverse_ok(state,arrays,0,i,prices,rule,previous)
            distance=-(prices['last'][i]-state['follow']['level'])/state['atr']
            if state['retest_event']<0 and prices['normal'][i] and -.2<=distance<=.2:state['retest_event']=i
            row['売り再テスト番号']=state['retest_event']
            other=None
            if state['retest_event']>=0 and i>state['retest_event'] and times[i]>times[state['retest_event']]:
                other=P._accept(state['follow'],arrays[1],i,-1,times,prices,profile)
            row['売り価格受容成熟']=P._mature(state['follow'],other,i,-1,times,prices,profile)
            row['売り全技術確認']=R._follow_ok(state,arrays,1,i,prices,rule)
        row['実側特徴']={}
        for side,name in enumerate(('買い','売り')):
            x=arrays[side]
            keys=('m5_atr','m5_gap_to_side','m15_gap_to_side','m5_di_difference_to_side','m15_di_difference_to_side',
                'm5_ema21_delta_to_side','m15_ema21_delta_to_side','m30_ema21_delta_to_side','m5_hist_delta_to_side','m5_rsi_delta_to_side',
                'q0_entry_minus_bbmean_sigma_to_side','q0_entry_minus_ema8_atr5_to_side','m1_volume_relative_prior3')
            row['実側特徴'][name]={k:x[k][i] for k in keys}
        series.append(row)
    F.U.save(HERE/'旧幹による確認取消の診断198.json',{'原因':'旧買い要求をriskで保留後、逆方向の旧売りがrisk非該当となるとpendingを取消し、そのまま旧幹として取得する。新反転/順行の確認は通っていない。',
        '差':'旧810買い+16923円から旧825売り−24077円へ一件入替。差−41000円。他5DayとNight2は同一。',
        '195T効果':'この場の枠差はTでないため195全遮断/独自受容でも同じ。',
        '注意':'追加二場の固定適用後の診断。ここからの新条件は以後全83既使用として記録する。825の仮想確認は適用結果ではなく、取消直前の技術状態を説明するもの。',
        'series':series})
    print({'独立照合':count,'回復固定水準':state['reverse']['level'],'売り再テスト番号':state['retest_event']})


if __name__=='__main__':main()
