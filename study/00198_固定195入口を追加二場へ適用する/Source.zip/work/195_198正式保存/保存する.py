"""195の旧81探索と198の固定追加二場を正式資料へ保存する。"""
from pathlib import Path
import hashlib
import importlib.util
import json
import shutil
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('保存193_for195',ROOT/'work/193正式保存/保存する.py')
S=importlib.util.module_from_spec(spec);sys.modules[spec.name]=S;spec.loader.exec_module(S)


def manifest(trial: Path,extra: dict | None=None) -> None:
    """
    機能: 保存後の正式ファイル指紋を更新する。
    引数: trial(Path)、extra(dict|None)。
    返り値: None。
    """
    path=trial/'保存索引.json';value=S.read(path) if path.exists() else {}
    value.update(extra or {});value['正式保存']=[S.ref(p) for p in sorted(trial.rglob('*')) if p.is_file() and p.name!='保存索引.json']
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def add_test_fixtures(trial: Path) -> None:
    """
    機能: 親人工fixtureを正式Sourceへ補い、単独展開後の検査依存を記録する。
    引数: trial(Path)。
    返り値: None。金融前Sourceを変更しない。
    """
    paths=[ROOT/'work'/name/'人工検査.py' for name in ('183入口候補','185原圧力と受容','191要求起点の受容','193構造拡大停止と取得位置')]
    with zipfile.ZipFile(trial/'Source.zip','a',zipfile.ZIP_DEFLATED) as z:
        names=set(z.namelist())
        for p in paths:
            name=p.relative_to(ROOT).as_posix()
            if name not in names:z.write(p,name)
    (trial/'監査'/'人工fixture依存.json').write_text(json.dumps({'金融変更なし':True,'追加保存Source':[S.ref(p) for p in paths]},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def main() -> None:
    """
    機能: 195/198の結果・限界・再現資料を保存する。
    引数: なし。
    返り値: None。
    """
    S.CASES={195:('195保留中Tの技術根拠','00195_保留中の補完入口を技術根拠で判別する',[0,2,3,5,7,8,10])}
    S.STORIES={195:'''技術確認を保留した旧要求の途中でも、初参加用Tが先に取得される問題を11案で比較した。R1の全遮断05とT固有受容07は、全80Day151取得・全40場・保有51.68%・未知0・両中央値正を維持し、旧基準の損失1,054,697円を980,235円へ減らした。最悪5場は旧同値−29,386円、赤字場は9/40のまま、赤字取引61→55、場末DD65,231円は不変。前48/全80の機械順位ともDAY05、NIGHT02となった。

ただし19304からの追加改善64,000円は10/09Day一場に限られる。保留中T−21,077円を止めると、後続を含む旧4取得+2,692円から新4取得+66,692円へ枠が替わった。R1のT固有受容は純成立4件でも実取得0で、05と07の優劣は示せていない。R2の遮断/受容は9/24Nightの黒字T等を落とし、赤字場7→8へ悪化した。全遮断を一般解としない。

旧基準に対し05のDay損失は前48−42,308円、後25−18,077円、追加7−14,077円、11/16Day−56,308円。追加7は3Dayのうち2Dayが赤字のままで安定採用とはしない。195条件/純全3legは追加二場収支を受信する前に封印した。固定順位の記録と198追加適用は194の旧対照損益を受信した後で、完全な未見選択とは区別する。'''}
    S.main()
    trial=ROOT/'study/00195_保留中の補完入口を技術根拠で判別する'
    with (trial/'README.md').open('a',encoding='utf-8') as f:
        f.write('\n[固定順位と追加二場適用候補](固定順位と追加二場適用候補.json)に全11案と機械順位・支持・閲覧時計を固定。追加二場は[198](../00198_固定195入口を追加二場へ適用する/README.md)へ分離した。\n')
    add_test_fixtures(trial);manifest(trial,{'追加正式化Source':S.ref(Path(__file__))})
    # ----------------------------------------
    work=ROOT/'work/198固定195の追加二場';trial=ROOT/'study/00198_固定195入口を追加二場へ適用する'
    for name in ('全純入口の封印.json','安定性198.json.gz','金融開始前固定.json'):
        shutil.copy2(work/name,trial/name)
    (trial/'監査').mkdir(exist_ok=True);(trial/'保存金融').mkdir(exist_ok=True)
    for name in ('対照同体198.json','独立確認198.json','旧幹による確認取消の診断198.json'):
        shutil.copy2(work/name,trial/'監査'/name)
    for path in (work/'金融正本').glob('*.json.gz'):shutil.copy2(path,trial/'保存金融'/path.name)
    condition=S.read(trial/'条件_NK225.json')
    for ref in condition['Source']:assert S.ref(ROOT/ref['path'])==ref,ref['path']
    with zipfile.ZipFile(trial/'Source.zip','w',zipfile.ZIP_DEFLATED) as z:
        for item in condition['Source']:z.write(ROOT/item['path'],item['path'])
        for p in (work/'原因を確認する.py',ROOT/'work/183損失安定性/新候補の集計を独立検査する.py',Path(__file__)):
            name=p.relative_to(ROOT).as_posix()
            if name not in z.namelist():z.write(p,name)
    with zipfile.ZipFile(trial/'純入口.zip','w',zipfile.ZIP_DEFLATED) as z:
        for name in ('追加二場純出生.npz','追加二場純診断.json.gz'):
            p=work/name;z.write(p,p.relative_to(ROOT).as_posix())
    text='''# 198 固定195入口を追加二場へ適用する

195の全11案を条件変更せず、2026-11-16Night・11-17Dayへ適用した。**Dayの新案は旧基準より悪化し、195の旧期間改善を安定採用へ引き上げない。** 追加2場は以後の条件作成では既使用として扱う。

金額は日経mini1枚、片道手数料38.5円＋5pt追加滑り、実ラージBBO代用。各候補別に全2場を保持し、未知0。保有・予約合計1、単純IFDの元幅/期限、終了15分前までの決済を維持した。

|対象|候補|取得|利益|損失|収支|保有率|建玉中央値|
|---|---|---:|---:|---:|---:|---:|---:|
|11/16Night|全11案|2|12,923|16,077|−3,154|23.54%|−1,577|
|11/17Day|00 旧基準|6|55,846|73,308|−17,462|53.17%|−10,577|
|11/17Day|01〜10|6|38,923|97,385|−58,462|53.15%|−14,077|

Night保有率は[安定性](安定性198.json.gz)を正本とする。1場ずつのため新規安定性を判定できる件数ではない。

## 何が変わったか

11/17の11:16:01、旧買い要求810は5/15/30分の売り背景が揃うriskとして保留された。旧基準はこの買いを取得し+16,923円。その15分後11:31:01に旧売り825が出た時、買い圧力のriskが非該当なため保留setupを取消し、旧売りをそのまま取得した。その収支が−24,077円で、差−41,000円となった。他5Day取引とNight2取引は同じ。

825の売りMA差・DIは正で拡大していたが、売りMACD増分−0.314・RSI増分−2.970は短期の反発を示していた。この取得は新しい反転/順行確認を通らず、193のMA非拡大も195のT判別も対象外だった。リスクが非該当になっただけで、新方向の取得根拠が揃ったとは限らない。[当時の特徴と固定水準](監査/旧幹による確認取消の診断198.json)は事後診断として保存。次199では保留中の旧幹による確認取消を別条件として比較する。

## 固定と検査

195全閾値・Source・旧81純判断は194追加二場収支の受信前に固定した。ただし198は194の旧対照結果を受信した後の全11案固定適用であり、追加二場を一切未見の選択とは呼ばない。[条件](条件_NK225.json)と[純封印](全純入口の封印.json)を保持し、成績で候補を入れ替えていない。

194の4固定対照×7区分の同体、全11案4,752属性の別算術集計を照合。独立原板金融engineの再実装ではない。全候補の金融packと安定性は正式保存済みで、workなしで閲覧できる。

## 再現

194の恒久入力と共用金融接続を元の相対構造へ復元し、195のSourceと本Source ZIPを展開する。

```powershell
python -X utf8 work/198固定195の追加二場/固定適用198.py --pure
python -X utf8 work/198固定195の追加二場/固定適用198.py --finance
python -X utf8 work/198固定195の追加二場/原因を確認する.py
```

金融開始マーカーは重複実行を止める。再現は空の別作業コピーで行い、元の固定成果を上書きしない。Python3.14.3/NumPy2.5.4。入力原板は再複製しない。
'''
    metrics=S.read(work/'安定性198.json.gz')['metrics'];night=metrics[0]['groups']['NIGHT']['holding']['held_lower_ratio']
    text=text.replace('23.54%',f'{night:.2%}')
    (trial/'README.md').write_text(text,encoding='utf-8')
    source=(ROOT/'study/00195_保留中の補完入口を技術根拠で判別する/設定と結果.md').read_text(encoding='utf-8')
    source=source.replace('# 195 設定と結果','# 198 設定と結果')
    source=source[:source.index('## 設定明細と複合結果')]+'''## 設定明細と複合結果

版8全567セルは195と同じ役割・閾値。195の候補を選び直さず全11案を追加二場へ適用した。[固定条件](条件_NK225.json)内の親195条件指紋・Sourceが設定の正本。追尾や技術途中決済は使わない。

結果は[README](README.md)、[全候補安定性](安定性198.json.gz)、[保存金融](保存金融/)へ。全場を残し、未知を0円にしない。追加二場は各帯一場だけで、両中央値の合否や率を安定性と同一視しない。以後の条件修正では全83場既使用。
'''
    (trial/'設定と結果.md').write_text(source,encoding='utf-8')
    manifest(trial,{'正式化Source':S.ref(Path(__file__)),'注意':'固定適用198。共用原板は194恒久入力を参照。'})
    print('195/198 正式保存完了')


if __name__=='__main__':main()
