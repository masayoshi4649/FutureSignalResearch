"""131評価器を人工79票/73場だけで検査する。自然outcomesは開かない。"""
from pathlib import Path
import copy
import importlib.util
import subprocess
import sys
import unittest

OWN=Path(__file__).resolve().parent
SPEC=importlib.util.spec_from_file_location('人工用131評価',OWN/'評価する.py')
EVAL=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(EVAL)
SELECT=EVAL.load_module(EVAL.PLAN/'方向を選ぶ.py','人工用純方向131')


def quote(at: float, index: int, last: float=1005, bid: float=1000, ask: float=1010) -> dict:
    """
    機能: 人工の正常価格/原行時計を作る。
    引数: at/last/bid/ask(float)、index(int)。返り値: dict。
    """
    return {'time':at,'index':index,'source_line':index+1,'clock':'人工',
            'last':last,'bid':bid,'ask':ask,'quote_ok':True}


# ----------------------------------------
def candidate(side: int, entry: dict, chart: bool) -> dict:
    """
    機能: 正逆のspreadが異なる人工H30/60・5幅観測を作る。
    引数: side(int)、entry(dict)、chart(bool)。返り値: dict。
    """
    price=entry['last'] if chart else entry['ask'] if side==1 else entry['bid']
    touch=quote(entry['time']+5,entry['index']+1,last=1145,bid=1140,ask=1150)
    mark=touch['last'] if chart else touch['bid'] if side==1 else touch['ask']
    points=side*(mark-price);outcomes=[]
    for h in (1800,3600):
        end=quote(entry['time']+h,entry['index']+2,last=1145,bid=1140,ask=1150)
        touches=[]
        for width in (25,50,100,125,200):
            direction=1 if points>=width else -1 if points<=-width else 0
            touches.append({'width':width,'direction':direction,'quote':copy.deepcopy(touch) if direction else None})
        outcomes.append({'seconds':h,'deadline':entry['time']+h,'status':'complete','touches':touches,'endpoint':end,
            'points':points,'net0':None if chart else points*100-77,'net5':None if chart else points*100-1077})
    return {'status':'filled','axis':'Last価格方向診断' if chart else 'BBO','birth':{'side':side},
            'entry':copy.deepcopy(entry),'entry_price':price,'outcomes':outcomes}


# ----------------------------------------
def fixture() -> tuple[dict,dict,dict,dict]:
    """
    機能: 全79票/73場と参考53/26を満たす人工data/features/choices/metadataを作る。
    引数: なし。返り値: tuple[dict,dict,dict,dict]。
    """
    scenes=[];features=[];choices=[];metadata=[];n=0
    sessions=[f'人工{i:03d}' for i in range(73)]
    for i,sid in enumerate(sessions):
        cases=[];start=100000+i*10000
        metadata.append({'session':sid,'start':start-100,'end':start+5300})
        for j in range(2 if i<5 or i==48 else 1):
            identity=f'{sid}/{j}';side=1 if n%2==0 else -1;q=quote(start+j*10,100+j*10)
            birth=quote(q['time']-2,q['index']-2)
            values={'candle5_body_signed_ratio':0,'ema21_delta_signed_30':1,'hist_atr_signed_5':.2,
                    'gap_signed_15':1,'ema21_delta_signed_15':1,'rvol5':2 if n%2==0 else 1,
                    'hist_signed_15':1,'hist_delta_signed_15':1}
            fs={k:{'known':True,'value':values[k]} for k in SELECT.USED_KEYS}
            refs=[{'id':f'{sid}/{w}','width_seconds':w,'end':start-w,
                   'delivered':{'time':start-3,'index':90,'source_line':91},'publication_sha256':'人工'} for w in (300,900,1800)]
            f={'session':sid,'id':identity,'original_side':side,'strategy':'trend','path':'strong',
               'features':fs,'birth_quote':birth,'entry_quote':q,'entry_price':q['ask'] if side==1 else q['bid'],'refs':refs}
            features.append(f)
            c={'session':sid,'id':identity,'original_side':side,'strategy':'trend','path':'strong',
               'birth':{k:birth[k] for k in ('time','index','source_line')},
               'entry':{k:q[k] for k in ('time','index','source_line')},'refs':refs,
               'partition_reference':'train' if i<48 else 'validation',**SELECT.choose(side,fs)}
            choices.append(c)
            cases.append({'id':identity,'original_side':side,'original':candidate(side,q,False),'reverse':candidate(-side,q,False),
                          'chart_original':candidate(side,q,True),'chart_reverse':candidate(-side,q,True)})
            n+=1
        scenes.append({'session':sid,'success':True,'cases':cases})
    data={'success':True,'trial':124,'candidate_quantity':1,'widths':[25,50,100,125,200],'horizons':[1800,3600],'scenes':scenes}
    feature_data={'success':True,'trial':124,'features':features}
    fixed={'成功':True,'primary':'H0','policies':list(EVAL.POLICIES),'entry_count':79,'session_count':73,
        'spec_sha256':EVAL.UPSTREAM_SPEC_SHA,'fixed_sources':{
            'work/124当時特徴の診断/全79例の当時特徴.json':EVAL.FEATURE_SHA,
            'work/126複合切替の探索/学習モデル.json':EVAL.MODEL_SHA},'sessions':sessions,'choices':choices}
    return data,feature_data,fixed,{'scenes':metadata}


# ----------------------------------------
class Artificial131(unittest.TestCase):
    """固定Sourceの対応、未知、phase境界、閲覧表の不変性を検査する。"""

    def setUp(self) -> None:
        """
        機能: 各検査へ独立な人工79票だけを用意する。
        引数: self(Artificial131)。返り値: None。
        """
        self.data,self.features,self.fixed,self.metadata=fixture()
        self.records,self.sessions=EVAL.prepare_records(self.data,self.features,self.fixed,SELECT)
        self.module=EVAL.module124()

    def test_全79全73と三表の不変(self) -> None:
        """
        機能: 300/79/73の三表と全対照を保持し、入力を変更しないことを確認する。
        引数: self(Artificial131)。返り値: None。
        """
        before=copy.deepcopy((self.data,self.features,self.fixed))
        aggregate=EVAL.aggregate_records(self.records,self.sessions,self.module)
        tables=EVAL.tables_for(self.records,self.sessions,aggregate,self.module)
        self.assertEqual([len(t['rows']) for t in tables],[300,79,73])
        self.assertEqual(aggregate['train']['H0']['BBO']['3600']['125']['entries'],53)
        self.assertEqual(aggregate['validation']['H0']['BBO']['3600']['125']['entries'],26)
        self.assertEqual(tables[0]['rows'][0][2],'H0')
        self.assertEqual((self.data,self.features,self.fixed),before)

    def test_実正逆spreadとT8既知ペア差(self) -> None:
        """
        機能: 元向きと逆を実BBOで選び、単純な勝敗反転にしないことを確認する。
        引数: self(Artificial131)。返り値: None。
        """
        r=self.records[0]
        a=EVAL.selected(r,'H0','BBO');b=EVAL.selected(r,'T8','BBO')
        x=self.module.ifd(a,self.module.observation(a,3600),125,'BBO')
        y=self.module.ifd(b,self.module.observation(b,3600),125,'BBO')
        self.assertEqual((x['net5'],y['net5']),(11923,-16077))
        self.assertEqual(EVAL.paired([r],'H0','T8',self.module)['C5既知ペア差引円'],28000)

    def test_不足touch既知と未知と空場(self) -> None:
        """
        機能: H不足でもtouch既知を残し、未知/空場の金額を0へ埋めない。
        引数: self(Artificial131)。返り値: None。
        """
        known,unknown=copy.deepcopy(self.records[0]),copy.deepcopy(self.records[2])
        for name in ('original','reverse','chart_original','chart_reverse'):
            for o in known['case'][name]['outcomes']:
                o['status']='phase_censored';o['endpoint']=None;o['net0']=o['net5']=None
            for o in unknown['case'][name]['outcomes']:
                o['status']='gap_censored';o['endpoint']=None;o['net0']=o['net5']=None
                for t in o['touches']:t['direction']=0;t['quote']=None
        rows=[known,unknown];s=self.module.stats(rows,'H0','BBO',3600,125)
        self.assertEqual((s['complete'],s['censored'],s['ifd_known'],s['ifd_unknown']),(0,2,1,1))
        a=EVAL.aggregate_records(rows,self.sessions,self.module);tables=EVAL.tables_for(rows,self.sessions,a,self.module)
        table=tables[2];header=table['headers'];empty=table['rows'][-1]
        self.assertEqual(empty[header.index('取得数')],0)
        self.assertIsNone(empty[header.index('H0C5既知差引円')])
        only_unknown=table['rows'][1]
        self.assertEqual(only_unknown[header.index('H0IFD未知')],1)
        self.assertIsNone(only_unknown[header.index('H0C5既知差引円')])
        self.assertEqual(len(table['rows']),73)

    def test_Last金額は全None(self) -> None:
        """
        機能: Last方向の既知観測があっても金額を出さないことを確認する。
        引数: self(Artificial131)。返り値: None。
        """
        for p in EVAL.POLICIES:
            s=self.module.stats(self.records,p,'Last',3600,125)
            self.assertGreater(s['ifd_known'],0)
            for key in ('ifd_net0_sum','ifd_net5_sum','ifd_net5_profit','ifd_net5_loss','ifd_net5_pf'):
                self.assertIsNone(s[key])

    def test_全streamの境界等号とLast側も拒否(self) -> None:
        """
        機能: 原/逆BBOとLastのentry/touch/endpoint境界を集計前に拒否する。
        引数: self(Artificial131)。返り値: None。
        """
        EVAL.assert_execution_phase(self.records,self.sessions,self.metadata)
        for name in ('original','reverse','chart_original','chart_reverse'):
            for target in ('entry','touch','endpoint'):
                rows=copy.deepcopy(self.records)
                c=rows[0]['case'][name];boundary=self.metadata['scenes'][0]['end']-300
                q=c['entry'] if target=='entry' else c['outcomes'][0]['endpoint'] if target=='endpoint' else c['outcomes'][0]['touches'][0]['quote']
                q['time']=boundary
                with self.assertRaises(AssertionError):EVAL.assert_execution_phase(rows,self.sessions,self.metadata)

    def test_全票と方向改変を拒否(self) -> None:
        """
        機能: 固定母集団欠落と、票数が同じでも方向が変わる入力を拒否する。
        引数: self(Artificial131)。返り値: None。
        """
        data=copy.deepcopy(self.data);data['scenes'][-1]['cases']=[]
        with self.assertRaises(AssertionError):EVAL.prepare_records(data,self.features,self.fixed,SELECT)
        fixed=copy.deepcopy(self.fixed);fixed['choices'][0]['choices']['H0']['side']*=-1
        with self.assertRaises(AssertionError):EVAL.prepare_records(self.data,self.features,fixed,SELECT)

    def test_売買価格鏡像(self) -> None:
        """
        機能: K−priceとBid/Ask交換で各選択側の損益が鏡像不変となることを確認する。
        引数: self(Artificial131)。返り値: None。
        """
        original=self.records[0];mirrored=copy.deepcopy(original);mirrored['case']['original_side']*=-1
        for c in mirrored['choice']['choices'].values():c['side']*=-1
        for name in ('original','reverse','chart_original','chart_reverse'):
            c=mirrored['case'][name];c['birth']['side']*=-1;c['entry_price']=3000-c['entry_price']
            quotes=[c['entry']]+[o['endpoint'] for o in c['outcomes']]
            quotes += [t['quote'] for o in c['outcomes'] for t in o['touches'] if t['quote'] is not None]
            for q in quotes:
                q['last'],q['bid'],q['ask']=3000-q['last'],3000-q['ask'],3000-q['bid']
        for p in EVAL.POLICIES:
            self.assertEqual(self.module.stats([original],p,'BBO',3600,125),self.module.stats([mirrored],p,'BBO',3600,125))

    def test_F1未指定は自然読取前に拒否(self) -> None:
        """
        機能: CLIのF1引数不足で自然入力を読む前に終了することを確認する。
        引数: self(Artificial131)。返り値: None。
        """
        r=subprocess.run([sys.executable,'-X','utf8',str(OWN/'評価する.py')],capture_output=True,text=True,encoding='utf-8')
        self.assertEqual(r.returncode,2)
        self.assertIn('--f1',r.stderr)


if __name__=='__main__':
    unittest.main(verbosity=2)
