"""131の固定方向票で既存正逆ペアを選ぶ。自然実行にはRootのF1を要求する。"""
from pathlib import Path
import argparse
import gzip
import hashlib
import importlib.util
import json
import math

ROOT=Path(__file__).resolve().parents[2]
OWN=Path(__file__).resolve().parent
PLAN=ROOT/'work/T8の15分位相による切替案'
POLICIES=('O0','B0','T8','H0','H1')
DISPLAY=('H0','T8','O0','B0','H1')
CHOICES_SHA='cdf1f0c6248d76222d49c7d872094cce20edecb7f52aa9e725d1040aa51f17c3'
FEATURE_SHA='e4f0bf25156c1fe732b186c5c5d90b6e9f95718985a440d8eb7005588f734774'
MODEL_SHA='a011cb759ff5d3ab05efe7c7a97bd1686fd9bdc482dfba048e8120e56bdd7059'
UPSTREAM_SPEC_SHA='be87721a911275f64c7431d50df66f4c24551040666b61514a02f9218f91d263'
MODULE=ROOT/'work/124入口の原因分析/集計する.py'
MODULE_SHA='8479ca348231ffd77a637360797750833c9e6617c7fc4a6502e015c7a1d9f04a'
METADATA=ROOT/'inputs/00124_同入口正逆の共用入力/入力.json.gz'
METADATA_DECODED_SHA='b2368b1f42c16e8c96a3acd098c58a902807a3b6a5023d6d4b1e75261f3ee51b'
SOURCES={ROOT/'work/124入口の正逆比較/全73場の正逆結果.json':'25517066b291a0434211190299b9f0195e67f9a7d2e89c801d5b9e6b4b51c3a1',
    ROOT/'work/124当時特徴の診断/全79例の当時特徴.json':FEATURE_SHA,
    ROOT/'work/126複合切替の探索/集計.json':'e30aca19e553ded53ccdd3b1785bd6168e19dd210aa9c32c1f9625c0063fdcd8',
    ROOT/'work/126複合切替の探索/学習モデル.json':MODEL_SHA,
    PLAN/'choices.json':CHOICES_SHA,PLAN/'条件.md':UPSTREAM_SPEC_SHA,
    PLAN/'方向を選ぶ.py':'6ca313c9cb03d8a1997db71d25d789004f3539538d4c9bcf84d97be9fad35f68',
    MODULE:MODULE_SHA}


def sha(path: Path) -> str:
    """
    機能: 固定入力/コードの全bytes指紋を求める。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def load_module(path: Path, name: str) -> object:
    """
    機能: 原文とmainを変更/実行せずPython計算関数を読み込む。
    引数: path(Path)、name(str)。返り値: objectは読込module。
    """
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


# ----------------------------------------
def selected(record: dict, policy: str, axis: str) -> dict:
    """
    機能: 固定choice.sideだけで同caseの実正逆/Last側を選ぶ。
    引数: record(dict)、policy/axis(str)。返り値: dictは既存候補。
    """
    side=record['choice']['choices'][policy]['side']
    assert side in (-1,1) and axis in ('BBO','Last')
    key=('chart_' if axis=='Last' else '')+('original' if side==record['case']['original_side'] else 'reverse')
    return record['case'][key]


# ----------------------------------------
def module124() -> object:
    """
    機能: 固定124算術を同体importし、政策と選択だけをメモリ内で差し替える。
    引数: なし。返り値: objectはstats/ifd/bootstrapを持つmodule。
    """
    assert sha(MODULE)==MODULE_SHA
    module=load_module(MODULE,'固定124算術131')
    module.POLICIES=POLICIES;module.selected=selected
    return module


# ----------------------------------------
def prepare_records(data: dict, features: dict, fixed: dict, chooser: object) -> tuple[list[dict],list[str]]:
    """
    機能: 固定79票/73場の全方向/時計/価格/参照と実正逆対応を再確認する。
    引数: data/features/fixed(dict)、chooser(object)。返り値: tuple[list[dict],list[str]]。
    """
    assert data['success'] and data['trial']==124 and len(data['scenes'])==73
    assert data['candidate_quantity']==1 and tuple(data['widths'])==(25,50,100,125,200)
    assert tuple(data['horizons'])==(1800,3600)
    assert features['success'] and features['trial']==124
    assert fixed['成功'] and fixed['primary']=='H0' and tuple(fixed['policies'])==POLICIES
    assert fixed['entry_count']==79 and fixed['session_count']==73 and fixed['spec_sha256']==UPSTREAM_SPEC_SHA
    assert fixed['fixed_sources']['work/124当時特徴の診断/全79例の当時特徴.json']==FEATURE_SHA
    assert fixed['fixed_sources']['work/126複合切替の探索/学習モデル.json']==MODEL_SHA
    fmap={(f['session'],f['id']):f for f in features['features']}
    choices={(c['session'],c['id']):c for c in fixed['choices']}
    assert len(fmap)==len(features['features'])==len(choices)==len(fixed['choices'])==79
    assert set(fmap)==set(choices)
    for key,f in fmap.items():
        c=choices[key]
        expected=chooser.choose(f['original_side'],f['features'])
        assert all(c[k]==v for k,v in expected.items())
        assert all(c[k]==f[k] for k in ('original_side','strategy','path'))
        assert c['birth']=={k:f['birth_quote'][k] for k in ('time','index','source_line')}
        assert c['entry']=={k:f['entry_quote'][k] for k in ('time','index','source_line')}
        assert all(c['birth'][k]<=c['entry'][k] for k in c['birth'])
        assert all(all(r['delivered'][k]<=c['birth'][k] for k in c['birth']) for r in c['refs'])
    records=[];sessions=[];seen=set()
    for scene in data['scenes']:
        sid=scene['session']
        assert scene['success'] and scene['cases'] and sid not in sessions
        sessions.append(sid)
        for case in scene['cases']:
            key=(sid,case['id']);assert key in choices and key not in seen;seen.add(key)
            f,c=fmap[key],choices[key];side=case['original_side'];q=case['original']['entry']
            assert side==f['original_side'] and q==case['reverse']['entry']==f['entry_quote']
            assert q['quote_ok'] and all(math.isfinite(q[k]) for k in ('time','last','bid','ask')) and 0<q['bid']<q['ask']
            assert case['original']['birth']['side']==side and case['reverse']['birth']['side']==-side
            assert case['original']['entry_price']==(q['ask'] if side==1 else q['bid'])==f['entry_price']
            assert case['reverse']['entry_price']==(q['bid'] if side==1 else q['ask'])
            for name in ('original','reverse','chart_original','chart_reverse'):
                candidate=case[name]
                assert candidate['entry']==q and candidate['status']=='filled'
                assert tuple(o['seconds'] for o in candidate['outcomes'])==(1800,3600)
                assert all(tuple(t['width'] for t in o['touches'])==(25,50,100,125,200) for o in candidate['outcomes'])
                if name.startswith('chart_'):
                    assert candidate['entry_price']==q['last']
                    assert candidate['birth']['side']==(side if name=='chart_original' else -side)
                    assert all(o['net0'] is None and o['net5'] is None for o in candidate['outcomes'])
            expected_part='train' if len(sessions)<=48 else 'validation'
            assert c['partition_reference']==expected_part
            records.append({'session':sid,'case':case,'choice':c})
    assert len(records)==79 and len(sessions)==73 and sessions==fixed['sessions']==sorted(sessions)
    assert seen==set(choices) and sum(r['choice']['partition_reference']=='train' for r in records)==53
    assert sum(r['choice']['partition_reference']=='validation' for r in records)==26
    return records,sessions


# ----------------------------------------
def assert_execution_phase(records: list[dict], sessions: list[str], metadata: dict) -> dict:
    """
    機能: 全選択streamのentry/全touch/endpointを元End−300未満へ照合する。
    引数: records(list[dict])、sessions(list[str])、metadata(dict)。返り値: dictは検査数。
    違反時はAssertionErrorで評価を止め、候補除外/0円化/修正ラベルを作りません。
    """
    scenes={s['session']:s for s in metadata['scenes']}
    assert list(scenes)==sessions and len(scenes)==len(metadata['scenes'])==73
    counts={'選択stream検査':0,'entry検査':0,'touch検査':0,'endpoint検査':0}
    for r in records:
        end=scenes[r['session']]['end'];boundary=end-300
        assert math.isfinite(boundary)
        for p in POLICIES:
            for axis in ('BBO','Last'):
                c=selected(r,p,axis);counts['選択stream検査']+=1
                assert math.isfinite(c['entry']['time']) and c['entry']['time']<boundary,(r['session'],r['case']['id'],p,axis,'entry',c['entry']['time'],boundary)
                counts['entry検査']+=1
                for o in c['outcomes']:
                    if o['endpoint'] is not None:
                        q=o['endpoint'];assert math.isfinite(q['time']) and q['time']<boundary,(r['session'],r['case']['id'],p,axis,'endpoint',q['time'],boundary)
                        counts['endpoint検査']+=1
                    for t in o['touches']:
                        if t['quote'] is not None:
                            q=t['quote'];assert math.isfinite(q['time']) and q['time']<boundary,(r['session'],r['case']['id'],p,axis,'touch',q['time'],boundary)
                            counts['touch検査']+=1
    return {'成功':True,'境界':'各SourceScene.End−300、等号違反で停止',
            '対象':'全5政策/両軸/両H/全幅、重複選択streamも検査数へ含む',**counts,
            '新規2分buffer再適用':False,'未知0円化':False}


# ----------------------------------------
def aggregate_records(records: list[dict], sessions: list[str], module: object) -> dict:
    """
    機能: 全体と固定前48/後25で、5政策×20条件の同じ算術を適用する。
    引数: records(list[dict])、sessions(list[str])、module(object)。返り値: dictは300条件。
    """
    output={}
    for part,ids in (('all',sessions),('train',sessions[:48]),('validation',sessions[48:])):
        rows=[r for r in records if r['session'] in ids]
        output[part]={p:{axis:{str(h):{str(w):module.stats(rows,p,axis,h,w) for w in module.WIDTHS}
                       for h in module.HORIZONS} for axis in module.AXES} for p in POLICIES}
    return output


# ----------------------------------------
def paired(records: list[dict], policy: str, reference: str, module: object) -> dict:
    """
    機能: 同じcaseの両側IFD既知だけで主125/60分の差を集計する。
    引数: records(list[dict])、policy/reference(str)、module(object)。返り値: dict。
    """
    values=[];left=right=neither=0
    for r in records:
        a=selected(r,policy,'BBO');b=selected(r,reference,'BBO')
        x=module.ifd(a,module.observation(a,3600),125,'BBO');y=module.ifd(b,module.observation(b,3600),125,'BBO')
        if x['known'] and y['known']:values.append(x['net5']-y['net5'])
        elif x['known']:left+=1
        elif y['known']:right+=1
        else:neither+=1
    return {'比較政策':policy,'対照政策':reference,'同case数':len(records),'両側既知':len(values),
            '比較側だけ既知':left,'対照側だけ既知':right,'両側未知':neither,
            'C5既知ペア差引円':sum(values) if values else None,
            'C5既知ペア平均差円':sum(values)/len(values) if values else None}


# ----------------------------------------
def tables_for(records: list[dict], sessions: list[str], aggregate: dict, module: object) -> list[dict]:
    """
    機能: 主H0/T8を先に、比較300・入口79・全73場の閲覧3表を作る。
    引数: records(list[dict])、sessions(list[str])、aggregate(dict)、module(object)。返り値: list[dict]。
    """
    headers=['試行','区分','政策','価格軸','評価分','同幅pt','対象場数','取得場数','取得数','原向きから反転数',
             '全H完了','観測不足','順行先着','逆行先着','両方未到達','到達済み順行率','全完了順行率',
             '到達済み70%達成','IFD代用既知','IFD代用未知','C0代用差引円','C5代用利益円','C5代用損失絶対円',
             'C5代用差引円','C5代用平均円','C5代用PF']
    compare=[]
    for part,n in (('all',73),('train',48),('validation',25)):
        for p in DISPLAY:
            for axis in module.AXES:
                for h in module.HORIZONS:
                    for w in module.WIDTHS:
                        s=aggregate[part][p][axis][str(h)][str(w)]
                        compare.append([131,part,p,axis,h/60,w,n,s['sessions'],s['entries'],s['flips'],s['complete'],s['censored'],
                            s['forward'],s['adverse'],s['neither'],s['resolved_rate'],s['complete_rate'],s['target70'],
                            s['ifd_known'],s['ifd_unknown'],s['ifd_net0_sum'],s['ifd_net5_profit'],s['ifd_net5_loss'],
                            s['ifd_net5_sum'],s['ifd_net5_mean'],s['ifd_net5_pf']])
    # ----------------------------------------
    detail_headers=['試行','参考区分','セッション','出生ID','入口型','元向き','取得JST','元取得価格','逆取得価格',
        'B0基準15分Hist','Hist既知','B0基準15分Hist増分','Hist増分既知','B0基準15分Gap','Gap既知','B0基準15分EMA21増分','増分既知','RVOL5','RVOL既知','H1復帰','H0復帰']
    for p in DISPLAY:detail_headers += [p+'向き',p+'125BBO全H',p+'125BBO先着',p+'125IFD既知',p+'125IFD清算',p+'125C5代用円']
    detail=[]
    for r in records:
        c=r['choice'];case=r['case'];v=c['values_to_B0'];k=c['known']
        row=[131,c['partition_reference'],r['session'],case['id'],c['strategy'],case['original_side'],module.jst(case['original']['entry']['time']),
             case['original']['entry_price'],case['reverse']['entry_price'],v['hist_signed_15'],k['hist_signed_15'],v['hist_delta_signed_15'],k['hist_delta_signed_15'],v['gap_signed_15'],k['gap_signed_15'],
             v['ema21_delta_signed_15'],k['ema21_delta_signed_15'],v['rvol5'],k['rvol5'],
             c['choices']['H1']['restored_to_B0'],c['choices']['H0']['restored_to_B0']]
        for p in DISPLAY:
            candidate=selected(r,p,'BBO');o=module.observation(candidate,3600);e=module.ifd(candidate,o,125,'BBO')
            row += [c['choices'][p]['side'],o['status'],module.touch(o,125)['direction'],e['known'],e['reason'],e['net5']]
        detail.append(row)
    # ----------------------------------------
    scene_headers=['試行','セッション','参考区分','取得数','最低1取得']
    for p in DISPLAY:scene_headers += [p+'反転数',p+'125順',p+'125逆',p+'125未到達',p+'全H不足',p+'IFD既知',p+'IFD未知',
        p+'C5利益円',p+'C5損失絶対円',p+'C5既知差引円',p+'C5既知累計円（口座収支ではない）',p+'累計IFD未知']
    scene_rows=[];cum={p:0 for p in POLICIES};unknown={p:0 for p in POLICIES}
    for i,sid in enumerate(sessions):
        group=[r for r in records if r['session']==sid]
        row=[131,sid,'train' if i<48 else 'validation',len(group),bool(group)]
        for p in DISPLAY:
            s=module.stats(group,p,'BBO',3600,125)
            if s['ifd_net5_sum'] is not None:cum[p]+=s['ifd_net5_sum']
            unknown[p]+=s['ifd_unknown']
            row += [s['flips'],s['forward'],s['adverse'],s['neither'],s['censored'],s['ifd_known'],s['ifd_unknown'],
                s['ifd_net5_profit'],s['ifd_net5_loss'],s['ifd_net5_sum'],cum[p],unknown[p]]
        scene_rows.append(row)
    tables=[{'name':'正逆比較','headers':headers,'rows':compare},{'name':'入口別診断','headers':detail_headers,'rows':detail},
            {'name':'全セッション','headers':scene_headers,'rows':scene_rows}]
    assert [len(t['rows']) for t in tables]==[300,len(records),len(sessions)]
    assert all(len(t['headers'])==len(set(t['headers'])) and all(len(row)==len(t['headers']) for row in t['rows']) for t in tables)
    return tables


# ----------------------------------------
def assert_baselines(aggregate: dict, reference: dict) -> None:
    """
    機能: 旧126のO0/B0/T8全180条件と主要既報値の一致を確認する。
    引数: aggregate/reference(dict)。返り値: None。不一致で保存を中止する。
    """
    for part in ('all','train','validation'):
        for policy in ('O0','B0','T8'):
            assert aggregate[part][policy]==reference['集計'][part][policy],(part,policy)
    s=aggregate['all']['T8']['BBO']['3600']['125']
    assert (s['entries'],s['sessions'],s['forward'],s['adverse'],s['neither'],s['censored'])==(79,73,39,18,16,6)
    assert (s['ifd_known'],s['ifd_unknown'],s['ifd_net5_profit'],s['ifd_net5_loss'],s['ifd_net5_sum'])==(76,3,506304,313156,193148)


# ----------------------------------------
def main() -> None:
    """
    機能: RootのF1/固定choices明示後だけ正逆outcomesを読み評価する。
    引数: CLI f1/output-dir(Path)、f1-sha256/evaluate-fixed-choices(str)。返り値: None。
    """
    parser=argparse.ArgumentParser(description='131の金融前固定後だけ実行する既存Source方向比較')
    parser.add_argument('--f1',type=Path,required=True);parser.add_argument('--f1-sha256',required=True)
    parser.add_argument('--evaluate-fixed-choices',required=True);parser.add_argument('--output-dir',type=Path,default=OWN)
    args=parser.parse_args()
    assert args.evaluate_fixed_choices==CHOICES_SHA and len(args.f1_sha256)==64
    assert sha(args.f1)==args.f1_sha256
    checks={**SOURCES,args.f1:args.f1_sha256,METADATA:sha(METADATA)}
    for path in (OWN/'条件.md',OWN/'評価する.py',OWN/'人工検査.py'):checks[path]=sha(path)
    assert all(sha(p)==expected for p,expected in checks.items())
    dest=args.output_dir;dest.mkdir(parents=True,exist_ok=True)
    assert not any((dest/name).exists() for name in ('集計.json','CSV用の表.json','評価完了.json'))
    module=module124();chooser=load_module(PLAN/'方向を選ぶ.py','固定方向131')
    # ここより前には正逆outcomesを開かない。人工検査はこのmainを呼ばない。
    data=json.loads((ROOT/'work/124入口の正逆比較/全73場の正逆結果.json').read_text('utf-8'))
    features=json.loads((ROOT/'work/124当時特徴の診断/全79例の当時特徴.json').read_text('utf-8'))
    choices=json.loads((PLAN/'choices.json').read_text('utf-8'))
    reference=json.loads((ROOT/'work/126複合切替の探索/集計.json').read_text('utf-8'))
    metadata_bytes=gzip.decompress(METADATA.read_bytes())
    assert hashlib.sha256(metadata_bytes).hexdigest()==METADATA_DECODED_SHA
    metadata=json.loads(metadata_bytes)
    records,sessions=prepare_records(data,features,choices,chooser)
    phase=assert_execution_phase(records,sessions,metadata)
    aggregate=aggregate_records(records,sessions,module);assert_baselines(aggregate,reference)
    tables=tables_for(records,sessions,aggregate,module)
    result={'成功':True,'試行':131,'主政策':'H0','主評価区分':'all','主幅pt':125,'主時間秒':3600,
        '全場数':73,'固定取得数':79,'前48場取得数':53,'後25場取得数':26,'集計':aggregate,
        'T8との主125同case既知差':{p:paired(records,p,'T8',module) for p in DISPLAY},
        '全選択streamのphase検査':phase,'共用metadata解凍SHA256':METADATA_DECODED_SHA,
        'bootstrap':module.bootstrap(records,sessions),'旧O0B0T8全180条件同体':True,
        'F1_SHA256':args.f1_sha256,'選択票SHA256':CHOICES_SHA,'固定モデルSHA256':MODEL_SHA,
        '固定算術SHA256':MODULE_SHA,'条件SHA256':checks[OWN/'条件.md'],'コードSHA256':checks[OWN/'評価する.py'],
        '全73場は既使用':True,'独立未知期検証':False,'多重比較補正':False,
        '原板再読':False,'自然新入口再構築':False,'逆注文適格性再構築':False,'口座収支':False,'IFD実約定':False,
        '価格参考':'Last金額は全てnull。mini1枚独立IFD代用で、追尾/10枚口座利益ではない。'}
    assert all(sha(p)==expected for p,expected in checks.items())
    module.save(dest/'集計.json',result)
    module.save(dest/'CSV用の表.json',{'成功':True,'試行':131,'主政策':'H0','choices_sha256':CHOICES_SHA,
        '意味':'固定79取得/73場の方向診断。全体と前後参考の300比較、口座収支ではない。','tables':tables})
    module.save(dest/'評価完了.json',{'成功':True,'試行':131,'F1_SHA256':args.f1_sha256,'前後指紋不変':True,
        '入力コードSHA256':{str(p.relative_to(ROOT)) if p.is_relative_to(ROOT) else str(p):h for p,h in checks.items()},
        '集計SHA256':sha(dest/'集計.json'),'表SHA256':sha(dest/'CSV用の表.json'),'CSV行数':[len(t['rows']) for t in tables]})
    print(json.dumps({'成功':True,'試行':131,'CSV行数':[len(t['rows']) for t in tables],
        '主125H60':{p:aggregate['all'][p]['BBO']['3600']['125'] for p in DISPLAY}},ensure_ascii=False))


if __name__=='__main__':
    main()
