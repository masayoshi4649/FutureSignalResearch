"""固定T8の反転枝を15分Histの位相で分ける純粋関数。金融ラベルは入力に持たない。"""
import math

POLICIES=('O0','B0','T8','H0','H1')
USED_KEYS=('candle5_body_signed_ratio','ema21_delta_signed_30','hist_atr_signed_5',
           'gap_signed_15','ema21_delta_signed_15','rvol5','hist_signed_15','hist_delta_signed_15')


def number(fields: dict, key: str) -> float | None:
    """
    機能: 有限の既知値だけを取り出し、未知を0へ変換しない。
    引数: fields(dict)、key(str)。返り値: float|None。
    """
    item=fields.get(key,{'known':False,'value':None})
    assert type(item['known']) is bool
    if not item['known']:
        assert item.get('value') is None
        return None
    value=item['value']
    assert type(value) in (int,float) and math.isfinite(value)
    return value


# ----------------------------------------
def choose(original_side: int, fields: dict) -> dict:
    """
    機能: 既存B0/T8を再現し、主H0は15Hist正、副H1は追加増分正でB0へ復帰する。
    引数: original_side(int)は±1、fields(dict)は元方向基準の当時known/value特徴。
    返り値: dictは5政策方向、既知mask、B0基準値と理由。RVOLは記録だけに用いる。
    """
    assert type(original_side) is int and original_side in (-1,1)
    values={key:number(fields,key) for key in USED_KEYS}
    body=values['candle5_body_signed_ratio']
    base_flip=body is not None and .5<=body<.75
    b0=-original_side if base_flip else original_side
    factor=b0*original_side
    signed={key:(None if values[key] is None else factor*values[key])
            for key in ('ema21_delta_signed_30','hist_atr_signed_5','gap_signed_15','ema21_delta_signed_15',
                        'hist_signed_15','hist_delta_signed_15')}
    long=signed['ema21_delta_signed_30'];hist5=signed['hist_atr_signed_5']
    t8_flip=long is not None and hist5 is not None and long>=0 and hist5>=.1
    t8=-b0 if t8_flip else b0
    gap=signed['gap_signed_15'];slope=signed['ema21_delta_signed_15']
    hist15=signed['hist_signed_15'];delta15=signed['hist_delta_signed_15']
    ma15=gap is not None and slope is not None and gap>0 and slope>0
    positive15=hist15 is not None and hist15>0
    delta_positive15=delta15 is not None and delta15>0
    restore0=bool(t8_flip and ma15 and positive15)
    restored={'H0':restore0,'H1':bool(restore0 and delta_positive15)}
    sides={'O0':original_side,'B0':b0,'T8':t8,
           'H0':b0 if restored['H0'] else t8,'H1':b0 if restored['H1'] else t8}
    choices={}
    for policy in POLICIES:
        if policy=='O0':reason='元方向の固定対照'
        elif policy=='B0':reason='125実体比[0.5,0.75)の固定B0'
        elif policy=='T8':reason='126の固定MA30/MACD5のT8、未知はB0'
        elif restored[policy]:
            reason='T8反転枝で15分MA支持とHist正によりB0へ復帰' if policy=='H0' else '主条件に15分Hist増分正も伴いB0へ復帰'
        else:reason='位相条件の不成立/0/未知により固定T8を維持'
        choices[policy]={'side':sides[policy],'action':'flip' if sides[policy]!=original_side else 'keep',
                         'restored_to_B0':restored.get(policy,False),'reason':reason}
    assert not restored['H1'] or restored['H0']
    return {'choices':choices,'b0_side':b0,'t8_side':t8,'base_body_flip':base_flip,
            't8_flipped_B0':t8_flip,'ma15_supports_B0':ma15,
            'hist15_positive_to_B0':positive15,'hist15_delta_positive_to_B0':delta_positive15,
            'known':{key:value is not None for key,value in values.items()},
            'values_to_B0':{'candle5_body_signed_ratio':body,**signed,'rvol5':values['rvol5']}}
