"""原板・新損益を読まず、位相切替の境界/未知/符号鏡像を人工検査する。"""
from pathlib import Path
import copy
import importlib.util
import math
import unittest

SPEC=importlib.util.spec_from_file_location('位相の純方向',Path(__file__).with_name('方向を選ぶ.py'))
SELECT=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(SELECT)


def fields(body: float | None=0,long: float | None=1,hist: float | None=.1,
           gap: float | None=1,slope: float | None=1,volume: float | None=2,
           hist15: float | None=1,delta15: float | None=1) -> dict:
    """
    機能: 元方向基準の人工特徴を作る。
    引数: body/long/hist/gap/slope/volume/hist15/delta15(float|None)。返り値: dict。
    """
    return {key:{'known':v is not None,'value':v} for key,v in zip(SELECT.USED_KEYS,(body,long,hist,gap,slope,volume,hist15,delta15))}


class Artificial(unittest.TestCase):
    """市場の成績を使わず、固定対照と位相条件の論理を検査する。"""

    def test_B0とT8の固定境界(self) -> None:
        """
        機能: B0実体比とT8の既定等号・未知を再現する。
        引数: self(Artificial)。返り値: None。
        """
        for body,side in ((None,1),(.49999,1),(.5,-1),(.74999,-1),(.75,1)):
            self.assertEqual(SELECT.choose(1,fields(body=body))['b0_side'],side)
        for long,hist,side in ((0,.1,-1),(-.0001,.1,1),(1,.09999,1),(None,1,1),(1,None,1)):
            self.assertEqual(SELECT.choose(1,fields(long=long,hist=hist))['t8_side'],side)

    def test_Hist15は厳密正(self) -> None:
        """
        機能: 負/0/未知はT8維持、正は主H0の復帰となることを確認する。
        引数: self(Artificial)。返り値: None。
        """
        for hist,side in ((None,-1),(-1,-1),(0,-1),(1e-15,1),(1,1)):
            c=SELECT.choose(1,fields(hist15=hist))['choices']
            self.assertEqual(c['H0']['side'],side)
            self.assertEqual(c['H1']['side'],side)

    def test_H1の追加増分(self) -> None:
        """
        機能: 主を保ちながら副は増分が厳密正の時だけ復帰する。
        引数: self(Artificial)。返り値: None。
        """
        for delta,side in ((None,-1),(-1,-1),(0,-1),(1e-15,1),(1,1)):
            c=SELECT.choose(1,fields(delta15=delta))['choices']
            self.assertEqual(c['H0']['side'],1)
            self.assertEqual(c['H1']['side'],side)

    def test_15分MAとT8枝が必要(self) -> None:
        """
        機能: MAの0/逆/未知又はT8非反転では新しい向きを作らない。
        引数: self(Artificial)。返り値: None。
        """
        for gap,slope in ((0,1),(1,0),(-1,1),(1,-1),(None,1),(1,None)):
            c=SELECT.choose(1,fields(gap=gap,slope=slope))['choices']
            self.assertEqual(c['H0']['side'],-1);self.assertEqual(c['H1']['side'],-1)
        c=SELECT.choose(1,fields(long=-1))['choices']
        self.assertEqual(c['H0']['side'],1);self.assertFalse(c['H0']['restored_to_B0'])

    def test_RVOLは判断へ使わない(self) -> None:
        """
        機能: 活動の未知/0/大小でH0/H1が変わらず、記録だけ残ることを確認する。
        引数: self(Artificial)。返り値: None。
        """
        for volume in (None,0,.5,1,2,20):
            d=SELECT.choose(1,fields(volume=volume))
            self.assertEqual((d['choices']['H0']['side'],d['choices']['H1']['side']),(1,1))
            self.assertEqual(d['values_to_B0']['rvol5'],volume)

    def test_B0基準への全符号変換(self) -> None:
        """
        機能: B0が元向きと逆でも15Hist/増分を他指標と同じ基準へ変換する。
        引数: self(Artificial)。返り値: None。
        """
        d=SELECT.choose(1,fields(body=.6,long=-1,hist=-.2,gap=-1,slope=-1,hist15=-1,delta15=-1))
        self.assertEqual((d['b0_side'],d['t8_side']),(-1,1))
        self.assertEqual((d['choices']['H0']['side'],d['choices']['H1']['side']),(-1,-1))
        self.assertEqual(d['values_to_B0']['hist_signed_15'],1)

    def test_売買鏡像と部分集合と非改変(self) -> None:
        """
        機能: 鏡像・副⊆主・元の特徴非改変を確認する。
        引数: self(Artificial)。返り値: None。
        """
        for body in (None,0,.5,.75):
            for hist in (None,-1,0,1):
                for delta in (None,-1,0,1):
                    f=fields(body=body,hist15=hist,delta15=delta);original=copy.deepcopy(f)
                    a,b=SELECT.choose(1,f),SELECT.choose(-1,f)
                    self.assertEqual(f,original)
                    for p in SELECT.POLICIES:
                        self.assertEqual(b['choices'][p]['side'],-a['choices'][p]['side'])
                        self.assertEqual(b['choices'][p]['restored_to_B0'],a['choices'][p]['restored_to_B0'])
                    self.assertFalse(a['choices']['H1']['restored_to_B0'] and not a['choices']['H0']['restored_to_B0'])

    def test_不正既知値は拒否(self) -> None:
        """
        機能: 非有限/真偽値/既知null/未知0を黙って計算しない。
        引数: self(Artificial)。返り値: None。
        """
        for item in ({'known':True,'value':math.nan},{'known':True,'value':True},{'known':True,'value':None},{'known':False,'value':0}):
            f=fields();f['hist_signed_15']=item
            with self.assertRaises(AssertionError):SELECT.choose(1,f)


if __name__=='__main__':unittest.main(verbosity=2)
