"""131の方向票/固定集計/小型コードを一度だけ保管し共有旧資源は参照する。"""
from pathlib import Path
import gzip
import hashlib
import json
import shutil
import zipfile

ROOT=Path(__file__).resolve().parents[2]
F=ROOT/'study/00131_中期MACDの位相で複合入口の方向を切り替える'
OWN=ROOT/'work/131既存入口の位相切替評価'


def sha(body: bytes) -> str:
    """
    機能: bytesのSHAを返す。
    引数: body(bytes)。返り値: str。
    """
    return hashlib.sha256(body).hexdigest()


def main() -> None:
    """
    機能: 131だけの正本を保管し、F1源/共有入力を複製しない。
    引数: なし。返り値: None。
    """
    choice=ROOT/'work/T8の15分位相による切替案/choices.json';body=choice.read_bytes();assert sha(body)=='cdf1f0c6248d76222d49c7d872094cce20edecb7f52aa9e725d1040aa51f17c3'
    folder=ROOT/'inputs/00131_T8の15分位相切替';folder.mkdir(exist_ok=True)
    packed=gzip.compress(body,mtime=0)
    with (folder/'choices.json.gz').open('xb') as stream:stream.write(packed)
    assert gzip.decompress(packed)==body
    choice_record={'path':'inputs/00131_T8の15分位相切替/choices.json.gz','bytes':len(packed),'sha256':sha(packed),'decoded_bytes':len(body),'decoded_sha256':sha(body)}
    (folder/'指紋.json').write_text(json.dumps(choice_record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (F/'成果物').mkdir(exist_ok=True)
    aggregate=(OWN/'集計.json').read_bytes();assert sha(aggregate)=='252a8d1744fe340b57a23db5c46d7dc7abd467fdfa59d273ce42f497b04843f3'
    with (F/'成果物/集計.json').open('xb') as stream:stream.write(aggregate)
    proofs=[(OWN/'Root評価完了.json','Root評価完了.json'),(OWN/'評価完了.json','評価完了.json'),(ROOT/'work/T8の15分位相による切替案/準備の確認.json','方向票の準備確認.json'),(ROOT/'work/T8の15分位相による切替案/人工検査.json','方向票の人工検査.json')]
    for p,name in proofs:shutil.copyfile(p,F/'検査'/name)
    fixed=json.loads((OWN/'F1.json').read_bytes());items={}
    for name,expected in fixed['ファイル'].items():
        p=Path(name)
        if p.suffix not in ['.py','.md']:continue
        b=p.read_bytes();assert sha(b)==expected,name;items[p.relative_to(ROOT).as_posix()]=(b,'金融前F1固定')
    for folder in [ROOT/'work/131既存入口CSV出力',ROOT/'work/131正式保存']:
        for p in folder.glob('*'):
            if p.suffix in ['.py','.mjs']:items[p.relative_to(ROOT).as_posix()]=(p.read_bytes(),'結果後の閲覧/保管補助')
    recipe=F/'再現資料';recipe.mkdir(exist_ok=True)
    path=recipe/'131コード.zip'
    with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
        for p,(b,_)in sorted(items.items()):z.writestr(p,b)
    with zipfile.ZipFile(path)as z:
        assert z.testzip() is None
        for p,(b,_)in items.items():assert z.read(p)==b
    index={'ZIP':path.name,'ZIP_SHA256':sha(path.read_bytes()),'ZIP_bytes':path.stat().st_size,'格納源数':len(items),'格納源':[{'path':p,'phase':phase,'bytes':len(b),'sha256':sha(b)} for p,(b,phase)in sorted(items.items())]}
    (recipe/'コード復元索引.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    refs=[
      {'保存元':'study/00124_逆行の原因と売買反転を同じ入口で検証する/成果物/全73場の正逆結果.json.gz','復元先':'work/124入口の正逆比較/全73場の正逆結果.json','解凍SHA':'25517066b291a0434211190299b9f0195e67f9a7d2e89c801d5b9e6b4b51c3a1'},
      {'保存元':'inputs/00124_同入口正逆の共用入力/全79例の当時特徴.json.gz','復元先':'work/124当時特徴の診断/全79例の当時特徴.json','解凍SHA':'e4f0bf25156c1fe732b186c5c5d90b6e9f95718985a440d8eb7005588f734774'},
      {'保存元':'study/00126_複合切替を時系列に分けて学習評価する/成果物/集計.json.gz','復元先':'work/126複合切替の探索/集計.json','解凍SHA':'e30aca19e553ded53ccdd3b1785bd6168e19dd210aa9c32c1f9625c0063fdcd8'},
      {'保存元':'study/00126_複合切替を時系列に分けて学習評価する/成果物/学習モデル.json.gz','復元先':'work/126複合切替の探索/学習モデル.json','解凍SHA':'a011cb759ff5d3ab05efe7c7a97bd1686fd9bdc482dfba048e8120e56bdd7059'}]
    for item in refs:assert sha(gzip.decompress((ROOT/item['保存元']).read_bytes()))==item['解凍SHA']
    (F/'保管索引.json').write_text(json.dumps({'試行':131,'新方向票':choice_record,'集計SHA':sha(aggregate),'共有参照':refs,'共用metadata':'inputs/00124_同入口正逆の共用入力/入力.json.gz','共用metadata保存SHA':'717f41674a4c99f94545a5e147495ae66498dbbc1afa48d7f34d04c40514843b','原板複製':False,'共有124_125_126の恒久複製':False,'金融再計算':False},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'方向票gzipSHA':choice_record['sha256'],'集計SHA':sha(aggregate),'ZIP_SHA':index['ZIP_SHA256'],'源数':len(items),'共有参照':len(refs)},ensure_ascii=False))


if __name__=='__main__':
    main()
