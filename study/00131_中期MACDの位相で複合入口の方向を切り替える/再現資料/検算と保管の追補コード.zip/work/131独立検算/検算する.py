"""131評価器/124算術をimportせず、保存Quoteを分数算術で独立検算する。"""
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone,timedelta
from fractions import Fraction as F
import gzip
import hashlib
import json
import math

ROOT=Path(__file__).resolve().parents[2]
OWN=Path(__file__).resolve().parent
RUN=ROOT/'work/131既存入口の位相切替評価'
POLICIES=('O0','B0','T8','H0','H1')
WIDTHS=(25,50,100,125,200)
HORIZONS=(1800,3600)
SOURCE={RUN/'集計.json':'252a8d1744fe340b57a23db5c46d7dc7abd467fdfa59d273ce42f497b04843f3',
    RUN/'CSV用の表.json':'96af73095d0485f97b03962816ca58b576987868582829fad2a033e55787a96d',
    RUN/'F1.json':'8694a553430b66032dd733c06fa166803d470d488a8810fbe6a29310e3f66882',
    ROOT/'work/T8の15分位相による切替案/choices.json':'cdf1f0c6248d76222d49c7d872094cce20edecb7f52aa9e725d1040aa51f17c3',
    ROOT/'work/124入口の正逆比較/全73場の正逆結果.json':'25517066b291a0434211190299b9f0195e67f9a7d2e89c801d5b9e6b4b51c3a1',
    ROOT/'work/124当時特徴の診断/全79例の当時特徴.json':'e4f0bf25156c1fe732b186c5c5d90b6e9f95718985a440d8eb7005588f734774',
    ROOT/'work/126複合切替の探索/集計.json':'e30aca19e553ded53ccdd3b1785bd6168e19dd210aa9c32c1f9625c0063fdcd8'}
CHECKS=0


def sha(path: Path) -> str:
    """
    機能: 許可された固定保存票/結果の指紋を求める。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def load(path: Path) -> dict:
    """
    機能: 固定JSONだけを解釈する。
    引数: path(Path)。返り値: dict。
    """
    return json.loads(path.read_text('utf-8'))


# ----------------------------------------
def compare(expected: object, actual: object, where: str) -> None:
    """
    機能: 整数/金額/型を厳密に、分数の率/PFを表示丸め範囲で照合する。
    引数: expected/actual(object)、where(str)。返り値: None。
    """
    global CHECKS
    if isinstance(expected,dict):
        assert isinstance(actual,dict) and set(expected)==set(actual),where
        for key in expected:compare(expected[key],actual[key],where+'/'+str(key))
    elif isinstance(expected,F):
        assert type(actual) in (int,float) and math.isfinite(actual),(where,expected,actual)
        error=abs(expected-F(str(actual)))
        tolerance=F(0) if expected.denominator==1 else max(F(1,10**9),abs(expected)*F(1,10**12))
        assert error<=tolerance,(where,expected,actual)
        CHECKS+=1
    elif isinstance(expected,bool) or expected is None:
        assert actual is expected,(where,expected,actual);CHECKS+=1
    elif isinstance(expected,int):
        assert type(actual) in (int,float) and F(str(actual))==expected,(where,expected,actual);CHECKS+=1
    else:
        assert expected==actual,(where,expected,actual);CHECKS+=1


# ----------------------------------------
def known(fields: dict, key: str) -> F | None:
    """
    機能: 元特徴の未知と既知0を区別して分数へ変換する。
    引数: fields(dict)、key(str)。返り値: F|None。
    """
    item=fields[key]
    if not item['known']:
        assert item['value'] is None
        return None
    return F(str(item['value']))


# ----------------------------------------
def directions(feature: dict) -> tuple[dict,dict]:
    """
    機能: 5政策を元特徴から独立に再構成する。固定モデルを再学習しない。
    引数: feature(dict)。返り値: tuple[dict,dict]は方向とB0基準値。
    """
    original=feature['original_side'];fs=feature['features'];body=known(fs,'candle5_body_signed_ratio')
    base=original*(-1 if body is not None and F(1,2)<=body<F(3,4) else 1)
    factor=base*original
    values={key:(None if known(fs,key) is None else factor*known(fs,key)) for key in
        ('ema21_delta_signed_30','hist_atr_signed_5','gap_signed_15','ema21_delta_signed_15','hist_signed_15','hist_delta_signed_15')}
    values['candle5_body_signed_ratio']=body;values['rvol5']=known(fs,'rvol5')
    a=values['ema21_delta_signed_30'];b=values['hist_atr_signed_5']
    tree_flips=a is not None and b is not None and a>=0 and b>=F(1,10)
    tree=-base if tree_flips else base
    g=values['gap_signed_15'];d=values['ema21_delta_signed_15']
    hist=values['hist_signed_15'];delta=values['hist_delta_signed_15']
    support=tree_flips and g is not None and d is not None and g>0 and d>0
    restore=support and hist is not None and hist>0
    out={'O0':original,'B0':base,'T8':tree,
         'H0':base if restore else tree,
         'H1':base if restore and delta is not None and delta>0 else tree}
    return out,values


# ----------------------------------------
def stream(record: dict, policy: str, axis: str) -> dict:
    """
    機能: 独立に求めた方向で保存正逆の同caseを選ぶ。
    引数: record(dict)、policy/axis(str)。返り値: dictは元の保存候補。
    """
    is_original=record['sides'][policy]==record['case']['original_side']
    name=('chart_' if axis=='Last' else '')+('original' if is_original else 'reverse')
    return record['case'][name]


# ----------------------------------------
def observation(candidate: dict, horizon: int) -> dict:
    """
    機能: 指定時間の保存観測を取り出す。
    引数: candidate(dict)、horizon(int)。返り値: dict。
    """
    found=[o for o in candidate['outcomes'] if o['seconds']==horizon]
    assert len(found)==1
    return found[0]


# ----------------------------------------
def arrival(outcome: dict, width: int) -> dict:
    """
    機能: 指定した同幅の最初到達の保存票を取り出す。
    引数: outcome(dict)、width(int)。返り値: dict。
    """
    found=[t for t in outcome['touches'] if t['width']==width]
    assert len(found)==1
    return found[0]


# ----------------------------------------
def liquidation(candidate: dict, horizon: int, width: int, axis: str) -> dict:
    """
    機能: H不足でもtouch既知を優先し、独立分数式で費用後額を計算する。
    引数: candidate(dict)、horizon/width(int)、axis(str)。返り値: dict。
    """
    o=observation(candidate,horizon);t=arrival(o,width)
    if t['direction']!=0:
        quote=t['quote'];reason='順行到達' if t['direction']>0 else '逆行到達'
    elif o['status']=='complete':quote=o['endpoint'];reason='期限清算'
    else:quote=None;reason='観測不足'
    if quote is None:return {'known':False,'reason':reason,'points':None,'net0':None,'net5':None}
    side=candidate['birth']['side']
    mark=quote['last'] if axis=='Last' else quote['bid'] if side>0 else quote['ask']
    point=side*(F(str(mark))-F(str(candidate['entry_price'])))
    return {'known':True,'reason':reason,'points':point,
            'net0':point*100-77 if axis=='BBO' else None,
            'net5':point*100-1077 if axis=='BBO' else None}


# ----------------------------------------
def statistics(records: list[dict], policy: str, axis: str, horizon: int, width: int) -> dict:
    """
    機能: 全H分母とIFD既知分母を独立に集計する。
    引数: records(list[dict])、policy/axis(str)、horizon/width(int)。返り値: dict。
    """
    candidates=[stream(r,policy,axis) for r in records]
    complete=[observation(c,horizon) for c in candidates if observation(c,horizon)['status']=='complete']
    labels=Counter(arrival(o,width)['direction'] for o in complete)
    forward,adverse,neither=(labels[x] for x in (1,-1,0));resolved=forward+adverse
    exits=[liquidation(c,horizon,width,axis) for c in candidates]
    valid=[e for e in exits if e['known']]
    amounts=[e['net5'] for e in valid] if axis=='BBO' else []
    profit=sum((v for v in amounts if v>0),F());loss=-sum((v for v in amounts if v<0),F())
    return {'entries':len(records),'sessions':len({r['session'] for r in records}),'complete':len(complete),
        'censored':len(records)-len(complete),'forward':forward,'adverse':adverse,'neither':neither,'resolved':resolved,
        'resolved_rate':F(forward,resolved) if resolved else None,'complete_rate':F(forward,len(complete)) if complete else None,
        'target70':10*forward>=7*resolved if resolved else None,'target70_all':10*forward>=7*len(complete) if complete else None,
        'ifd_known':len(valid),'ifd_unknown':len(records)-len(valid),'ifd_exits':dict(Counter(e['reason'] for e in exits)),
        'ifd_net0_sum':sum((e['net0'] for e in valid),F()) if valid and axis=='BBO' else None,
        'ifd_net5_sum':sum(amounts,F()) if amounts else None,'ifd_net5_mean':sum(amounts,F())/len(amounts) if amounts else None,
        'ifd_net5_profit':profit if amounts else None,'ifd_net5_loss':loss if amounts else None,
        'ifd_net5_pf':profit/loss if loss else None,'ifd_net5_positive':sum(v>0 for v in amounts) if axis=='BBO' else None,
        'ifd_points_mean':sum((e['points'] for e in valid),F())/len(valid) if valid else None,
        'flips':sum(r['sides'][policy]!=r['case']['original_side'] for r in records)}


# ----------------------------------------
def plain(value: object) -> object:
    """
    機能: 検算の分数をJSONへ保存できる整数又は分数/近似値へ写す。
    引数: value(object)。返り値: object。
    """
    if isinstance(value,F):return value.numerator if value.denominator==1 else {'分数':str(value),'近似':float(value)}
    if isinstance(value,dict):return {k:plain(v) for k,v in value.items()}
    if isinstance(value,list):return [plain(v) for v in value]
    return value


# ----------------------------------------
def main() -> None:
    """
    機能: Root通知の結果と固定票だけを300条件・全表・phaseで独立検算する。
    引数: なし。返り値: None。評価器/固定124算術のimport・Raw再読・探索は行わない。
    """
    before={str(p.relative_to(ROOT)):sha(p) for p in SOURCE}
    assert all(sha(p)==h for p,h in SOURCE.items())
    meta_path=ROOT/'inputs/00124_同入口正逆の共用入力/入力.json.gz';encoded=meta_path.read_bytes();body=gzip.decompress(encoded)
    assert hashlib.sha256(body).hexdigest()=='b2368b1f42c16e8c96a3acd098c58a902807a3b6a5023d6d4b1e75261f3ee51b'
    meta=json.loads(body);scene_map={s['session']:s for s in meta['scenes']}
    fixed=load(ROOT/'work/T8の15分位相による切替案/choices.json');features=load(ROOT/'work/124当時特徴の診断/全79例の当時特徴.json')
    pairs=load(ROOT/'work/124入口の正逆比較/全73場の正逆結果.json');result=load(RUN/'集計.json');tables=load(RUN/'CSV用の表.json')
    old=load(ROOT/'work/126複合切替の探索/集計.json')
    fmap={(f['session'],f['id']):f for f in features['features']};cmap={(c['session'],c['id']):c for c in fixed['choices']}
    assert len(fmap)==len(cmap)==79 and set(fmap)==set(cmap)
    sessions=[s['session'] for s in pairs['scenes']]
    assert sessions==fixed['sessions']==list(scene_map)==sorted(sessions) and len(sessions)==73
    records=[];phase={'entry検査':0,'touch検査':0,'endpoint検査':0,'選択stream検査':0}
    for s in pairs['scenes']:
        for case in s['cases']:
            identity=(s['session'],case['id']);f=fmap[identity];c=cmap[identity];sides,values=directions(f)
            assert f['original_side']==case['original_side']==c['original_side']
            assert case['original']['entry']==case['reverse']['entry']==f['entry_quote']
            compare(values,c['values_to_B0'],'B0値/'+case['id'])
            compare({k:v is not None for k,v in values.items()},c['known'],'既知/'+case['id'])
            for p in POLICIES:
                compare(sides[p],c['choices'][p]['side'],'方向/'+p+'/'+case['id'])
                compare(p in ('H1','H0') and sides[p]!=sides['T8'],c['choices'][p]['restored_to_B0'],'復帰/'+p+'/'+case['id'])
            r={'session':s['session'],'case':case,'feature':f,'choice':c,'sides':sides,'values':values}
            records.append(r);boundary=scene_map[s['session']]['end']-300
            for p in POLICIES:
                for axis in ('BBO','Last'):
                    candidate=stream(r,p,axis);q=candidate['entry'];side=candidate['birth']['side']
                    assert side==sides[p] and q['time']<boundary and q['quote_ok'] and 0<q['bid']<q['ask']
                    expected=q['last'] if axis=='Last' else q['ask'] if side>0 else q['bid']
                    compare(F(str(expected)),candidate['entry_price'],'取得価格')
                    phase['entry検査']+=1;phase['選択stream検査']+=1
                    for o in candidate['outcomes']:
                        if o['endpoint'] is not None:
                            end=o['endpoint'];assert end['time']<boundary and o['deadline']<=end['time']<=o['deadline']+30
                            phase['endpoint検査']+=1
                        for t in o['touches']:
                            tq=t['quote'];assert (tq is None)==(t['direction']==0)
                            if tq is not None:
                                assert q['time']<=tq['time']<=o['deadline'] and tq['time']<boundary
                                assert tq['index']>q['index'] and tq['source_line']>q['source_line'] and tq['quote_ok'] and 0<tq['bid']<tq['ask']
                                mark=tq['last'] if axis=='Last' else tq['bid'] if side>0 else tq['ask']
                                distance=side*(F(str(mark))-F(str(candidate['entry_price'])))
                                assert distance>=t['width'] if t['direction']==1 else distance<=-t['width']
                                phase['touch検査']+=1
                        if axis=='Last':assert o['net0'] is None and o['net5'] is None
    assert len(records)==79 and len({r['session'] for r in records})==73
    groups={'all':records,'train':[r for r in records if r['session'] in sessions[:48]],
            'validation':[r for r in records if r['session'] in sessions[48:]]}
    assert len(groups['train'])==53 and len(groups['validation'])==26
    aggregates={};conditions=baseline=0
    for part,rows in groups.items():
        aggregates[part]={}
        for p in POLICIES:
            aggregates[part][p]={}
            for axis in ('BBO','Last'):
                aggregates[part][p][axis]={}
                for h in HORIZONS:
                    aggregates[part][p][axis][str(h)]={}
                    for w in WIDTHS:
                        expected=statistics(rows,p,axis,h,w);aggregates[part][p][axis][str(h)][str(w)]=expected
                        compare(expected,result['集計'][part][p][axis][str(h)][str(w)],f'{part}/{p}/{axis}/{h}/{w}')
                        conditions+=1
                        if p in ('O0','B0','T8'):
                            compare(expected,old['集計'][part][p][axis][str(h)][str(w)],'旧126/'+f'{part}/{p}/{axis}/{h}/{w}');baseline+=1
    assert conditions==300 and baseline==180
    for p in POLICIES:
        differences=[];left=right=neither=0
        for r in records:
            a=liquidation(stream(r,p,'BBO'),3600,125,'BBO');b=liquidation(stream(r,'T8','BBO'),3600,125,'BBO')
            if a['known'] and b['known']:differences.append(a['net5']-b['net5'])
            elif a['known']:left+=1
            elif b['known']:right+=1
            else:neither+=1
        compare({'比較政策':p,'対照政策':'T8','同case数':79,'両側既知':len(differences),'比較側だけ既知':left,
            '対照側だけ既知':right,'両側未知':neither,'C5既知ペア差引円':sum(differences,F()) if differences else None,
            'C5既知ペア平均差円':sum(differences,F())/len(differences) if differences else None},result['T8との主125同case既知差'][p],'既知ペア/'+p)
    for k,v in phase.items():compare(v,result['全選択streamのphase検査'][k],'phase/'+k)
    # ----------------------------------------
    # 全比較表はヘッダーの意味から照合し、評価器の転記関数を使わない。
    counts_before_tables=CHECKS;table_by_name={t['name']:t for t in tables['tables']}
    assert [(t['name'],len(t['rows']),len(t['headers'])) for t in tables['tables']]==[
        ('正逆比較',300,26),('入口別診断',79,51),('全セッション',73,65)]
    t=table_by_name['正逆比較'];seen=set()
    mapping={'取得場数':'sessions','取得数':'entries','原向きから反転数':'flips','全H完了':'complete','観測不足':'censored',
        '順行先着':'forward','逆行先着':'adverse','両方未到達':'neither','到達済み順行率':'resolved_rate','全完了順行率':'complete_rate',
        '到達済み70%達成':'target70','IFD代用既知':'ifd_known','IFD代用未知':'ifd_unknown','C0代用差引円':'ifd_net0_sum',
        'C5代用利益円':'ifd_net5_profit','C5代用損失絶対円':'ifd_net5_loss','C5代用差引円':'ifd_net5_sum','C5代用平均円':'ifd_net5_mean','C5代用PF':'ifd_net5_pf'}
    for row in t['rows']:
        x=dict(zip(t['headers'],row));key=(x['区分'],x['政策'],x['価格軸'],int(x['評価分']*60),x['同幅pt']);assert key not in seen;seen.add(key)
        part,p,axis,h,w=key;s=aggregates[part][p][axis][str(h)][str(w)]
        expected={'試行':131,'区分':part,'政策':p,'価格軸':axis,'評価分':h//60,'同幅pt':w,'対象場数':len({r['session'] for r in groups[part]}),
                  **{label:s[field] for label,field in mapping.items()}}
        compare(expected,x,'比較表')
    assert len(seen)==300
    # ----------------------------------------
    by_id={(r['session'],r['case']['id']):r for r in records};t=table_by_name['入口別診断'];seen=set()
    for row in t['rows']:
        x=dict(zip(t['headers'],row));key=(x['セッション'],x['出生ID']);assert key not in seen;seen.add(key)
        r=by_id[key];case=r['case'];q=case['original']['entry'];v=r['values'];c=r['choice']
        expected={'試行':131,'参考区分':'train' if r in groups['train'] else 'validation','セッション':r['session'],'出生ID':case['id'],
            '入口型':r['feature']['strategy'],'元向き':case['original_side'],'取得JST':datetime.fromtimestamp(q['time'],timezone(timedelta(hours=9))).isoformat(sep=' '),
            '元取得価格':F(str(case['original']['entry_price'])),'逆取得価格':F(str(case['reverse']['entry_price'])),
            'B0基準15分Hist':v['hist_signed_15'],'Hist既知':v['hist_signed_15'] is not None,
            'B0基準15分Hist増分':v['hist_delta_signed_15'],'Hist増分既知':v['hist_delta_signed_15'] is not None,
            'B0基準15分Gap':v['gap_signed_15'],'Gap既知':v['gap_signed_15'] is not None,
            'B0基準15分EMA21増分':v['ema21_delta_signed_15'],'増分既知':v['ema21_delta_signed_15'] is not None,
            'RVOL5':v['rvol5'],'RVOL既知':v['rvol5'] is not None,
            'H1復帰':r['sides']['H1']!=r['sides']['T8'],'H0復帰':r['sides']['H0']!=r['sides']['T8']}
        for p in POLICIES:
            cand=stream(r,p,'BBO');o=observation(cand,3600);e=liquidation(cand,3600,125,'BBO')
            expected.update({p+'向き':r['sides'][p],p+'125BBO全H':o['status'],p+'125BBO先着':arrival(o,125)['direction'],
                p+'125IFD既知':e['known'],p+'125IFD清算':e['reason'],p+'125C5代用円':e['net5']})
        compare(expected,x,'入口表')
    assert seen==set(by_id)
    # ----------------------------------------
    t=table_by_name['全セッション'];cum={p:F() for p in POLICIES};unknown={p:0 for p in POLICIES}
    assert [row[t['headers'].index('セッション')] for row in t['rows']]==sessions
    for i,row in enumerate(t['rows']):
        sid=sessions[i];x=dict(zip(t['headers'],row));rows=[r for r in records if r['session']==sid]
        expected={'試行':131,'セッション':sid,'参考区分':'train' if i<48 else 'validation','取得数':len(rows),'最低1取得':bool(rows)}
        for p in POLICIES:
            s=statistics(rows,p,'BBO',3600,125)
            if s['ifd_net5_sum'] is not None:cum[p]+=s['ifd_net5_sum']
            unknown[p]+=s['ifd_unknown']
            expected.update({p+'反転数':s['flips'],p+'125順':s['forward'],p+'125逆':s['adverse'],p+'125未到達':s['neither'],
                p+'全H不足':s['censored'],p+'IFD既知':s['ifd_known'],p+'IFD未知':s['ifd_unknown'],p+'C5利益円':s['ifd_net5_profit'],
                p+'C5損失絶対円':s['ifd_net5_loss'],p+'C5既知差引円':s['ifd_net5_sum'],p+'C5既知累計円（口座収支ではない）':cum[p],p+'累計IFD未知':unknown[p]})
        compare(expected,x,'全場表')
    assert CHECKS-counts_before_tables==16574
    after={str(p.relative_to(ROOT)):sha(p) for p in SOURCE}
    assert before==after and meta_path.read_bytes()==encoded
    summary={part:{p:aggregates[part][p]['BBO']['3600']['125'] for p in POLICIES} for part in groups}
    changes=[]
    for r in records:
        if r['sides']['H0']!=r['sides']['T8']:
            a=liquidation(stream(r,'H0','BBO'),3600,125,'BBO');b=liquidation(stream(r,'T8','BBO'),3600,125,'BBO')
            changes.append({'session':r['session'],'id':r['case']['id'],'T8方向':r['sides']['T8'],'H0方向':r['sides']['H0'],
                            'H0_C5':a['net5'],'T8_C5':b['net5'],'両側既知差':a['net5']-b['net5'] if a['known'] and b['known'] else None})
    output={'成功':True,'試行':131,'独立計算':'標準ライブラリ/Fraction。評価器/124算術をimportしない。',
        '全固定取得':79,'全固定場':73,'前48場取得':53,'後25場取得':26,'全条件照合数':conditions,
        '旧126固定対照照合数':baseline,'比較値総数':CHECKS,'CSV用3表全データセル照合数':16574,
        '全選択streamのphase照合':phase,'方向再構成':'原特徴からO0/B0/T8/H1/H0を独立再構成し79票一致',
        '主と前後参考':summary,'主H0変更6票':changes,'前SHA256':before,'後SHA256':after,'前後不変':True,
        '共用metadata解凍SHA256':hashlib.sha256(body).hexdigest(),'検算コードSHA256':sha(Path(__file__)),
        'Raw再読':False,'新探索':False,'評価器実行流用':False,
        '限界':'保存touchの最初性/中間gapはRaw再走査しない。bootstrap区間の再実装とCSVファイル自体の再読は対象外。'}
    dest=OWN/'独立検算.json'
    with dest.open('x',encoding='utf-8',newline='\n') as handle:handle.write(json.dumps(plain(output),ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'成功':True,'検算SHA256':sha(dest),'300条件':conditions,'旧対照':baseline,'表セル':16574,
                      '主':plain(summary['all']['H0']),'変更票':plain(changes)},ensure_ascii=False))


if __name__=='__main__':
    main()
