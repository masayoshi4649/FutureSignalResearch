"""131の金融前固定候補を、自然outcomesを開かず独立式と人工データで確認する。"""
from pathlib import Path
from itertools import product
from datetime import datetime, timezone
import ast
import gzip
import hashlib
import importlib.util
import json
import math
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
PLAN = ROOT / 'work/T8の15分位相による切替案'
EVAL = ROOT / 'work/131既存入口の位相切替評価'
FORMAL = ROOT / 'study/00131_中期MACDの位相で複合入口の方向を切り替える'
EXPECTED = {
    PLAN / 'choices.json': 'cdf1f0c6248d76222d49c7d872094cce20edecb7f52aa9e725d1040aa51f17c3',
    PLAN / '条件.md': 'be87721a911275f64c7431d50df66f4c24551040666b61514a02f9218f91d263',
    PLAN / '方向を選ぶ.py': '6ca313c9cb03d8a1997db71d25d789004f3539538d4c9bcf84d97be9fad35f68',
    PLAN / '準備の確認.json': '0ee33d9a57355dd703ba146a9ed74106cf8277635a8cea25dcf11c5934e1b828',
    EVAL / '評価する.py': '5f67a94544d46a2742cc383119e08728864e8bd8e2f33547145794cf2ae66259',
    ROOT / 'work/124当時特徴の診断/全79例の当時特徴.json': 'e4f0bf25156c1fe732b186c5c5d90b6e9f95718985a440d8eb7005588f734774',
    ROOT / 'work/124入口の原因分析/集計する.py': '8479ca348231ffd77a637360797750833c9e6617c7fc4a6502e015c7a1d9f04a',
}


def sha(path: Path) -> str:
    """
    機能: 許可した非金融ファイルの指紋を計算する。
    引数: path(Path)は候補票・当時特徴・コード・文書。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def number(fields: dict, key: str) -> float | None:
    """
    機能: 未知・既知0・有限値を区別して取り出す。
    引数: fields(dict)、key(str)。
    返り値: float|None。
    """
    item = fields.get(key, {'known': False, 'value': None})
    assert type(item['known']) is bool
    if not item['known']:
        assert item['value'] is None
        return None
    value = item['value']
    assert type(value) in (int, float) and math.isfinite(value)
    return value


# ----------------------------------------
def independent_sides(original: int, fields: dict) -> dict:
    """
    機能: 本体chooserを呼ばず、事前式から5方向を求める。
    引数: original(int)は±1、fields(dict)は元向き符号特徴。
    返り値: dict[str,int]はO0/B0/T8/H0/H1。
    """
    body = number(fields, 'candle5_body_signed_ratio')
    b0 = -original if body is not None and .5 <= body < .75 else original
    factor = b0 * original
    aligned = {}
    for key in ('ema21_delta_signed_30', 'hist_atr_signed_5', 'gap_signed_15',
                'ema21_delta_signed_15', 'hist_signed_15', 'hist_delta_signed_15'):
        value = number(fields, key)
        aligned[key] = None if value is None else factor * value
    long = aligned['ema21_delta_signed_30']; fast = aligned['hist_atr_signed_5']
    reverse = long is not None and long >= 0 and fast is not None and fast >= .1
    t8 = -b0 if reverse else b0
    support = reverse and all(aligned[k] is not None and aligned[k] > 0
                             for k in ('gap_signed_15', 'ema21_delta_signed_15', 'hist_signed_15'))
    delta = aligned['hist_delta_signed_15']
    return {'O0': original, 'B0': b0, 'T8': t8,
            'H0': b0 if support else t8,
            'H1': b0 if support and delta is not None and delta > 0 else t8}


# ----------------------------------------
def main() -> None:
    """
    機能: 固定79票の因果参照と独立方向式、人工16検査を保存する。
    引数: なし。
    返り値: None。自然outcomes・Raw・旧集計・旧方向CSVの内容は読まない。
    """
    files = set(EXPECTED) | {ROOT / 'work/131金融前を固定して評価する.py', Path(__file__).resolve(),
                            ROOT / 'inputs/00124_同入口正逆の共用入力/入力.json.gz'}
    for folder in (PLAN, EVAL, FORMAL):
        files.update(p for p in folder.rglob('*') if p.is_file() and p.suffix in ('.py', '.md'))
    before = {str(p.relative_to(ROOT)): sha(p) for p in sorted(files)}
    assert all(sha(p) == expected for p, expected in EXPECTED.items())
    declaration = ast.parse((EVAL / '評価する.py').read_text('utf-8'))
    constants = {n.targets[0].id: ast.literal_eval(n.value) for n in declaration.body
                 if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name)
                 and n.targets[0].id in ('POLICIES', 'DISPLAY', 'CHOICES_SHA', 'UPSTREAM_SPEC_SHA')}
    assert constants['CHOICES_SHA'] == EXPECTED[PLAN / 'choices.json']
    assert constants['UPSTREAM_SPEC_SHA'] == EXPECTED[PLAN / '条件.md']
    assert constants['POLICIES'] == ('O0', 'B0', 'T8', 'H0', 'H1')
    assert constants['DISPLAY'] == ('H0', 'T8', 'O0', 'B0', 'H1')
    fixed = json.loads((PLAN / 'choices.json').read_text('utf-8'))
    features = json.loads((ROOT / 'work/124当時特徴の診断/全79例の当時特徴.json').read_text('utf-8'))
    metadata_body = gzip.decompress((ROOT / 'inputs/00124_同入口正逆の共用入力/入力.json.gz').read_bytes())
    assert hashlib.sha256(metadata_body).hexdigest() == 'b2368b1f42c16e8c96a3acd098c58a902807a3b6a5023d6d4b1e75261f3ee51b'
    metadata = json.loads(metadata_body)
    scenes = {s['session']: s for s in metadata['scenes']}
    fmap = {(f['session'], f['id']): f for f in features['features']}
    assert len(fmap) == len(fixed['choices']) == 79 and len(scenes) == 73
    assert fixed['primary'] == 'H0' and tuple(fixed['policies']) == constants['POLICIES']
    assert fixed['sessions'] == list(scenes) == sorted(scenes)
    spec = importlib.util.spec_from_file_location('独立人工用の固定chooser131', PLAN / '方向を選ぶ.py')
    chooser = importlib.util.module_from_spec(spec); spec.loader.exec_module(chooser)
    observed = set(); counts = {'H0': 0, 'H1': 0}; refs = 0; partitions = {'train': 0, 'validation': 0}
    for row in fixed['choices']:
        identity = (row['session'], row['id'])
        assert identity in fmap and identity not in observed
        observed.add(identity); f = fmap[identity]
        expected = independent_sides(f['original_side'], f['features'])
        assert {p: row['choices'][p]['side'] for p in constants['POLICIES']} == expected
        assert all(row[k] == v for k, v in chooser.choose(f['original_side'], f['features']).items())
        assert row['birth'] == {k: f['birth_quote'][k] for k in ('time', 'index', 'source_line')}
        assert row['entry'] == {k: f['entry_quote'][k] for k in ('time', 'index', 'source_line')}
        assert all(row['birth'][k] <= row['entry'][k] for k in row['birth'])
        assert row['entry']['time'] < scenes[row['session']]['end'] - 300
        projected = [{k: r[k] for k in ('id', 'width_seconds', 'end', 'delivered', 'publication_sha256')} for r in f['refs']]
        assert row['refs'] == projected
        for ref in row['refs']:
            assert ref['end'] <= ref['delivered']['time']
            assert all(ref['delivered'][k] <= row['birth'][k] for k in row['birth'])
            refs += 1
        for policy in counts:
            restored = expected[policy] != expected['T8']
            assert row['choices'][policy]['restored_to_B0'] == restored
            counts[policy] += restored
        partition = 'train' if fixed['sessions'].index(row['session']) < 48 else 'validation'
        assert row['partition_reference'] == partition
        partitions[partition] += 1
    assert observed == set(fmap) and counts == {'H0': 6, 'H1': 5}
    assert partitions == {'train': 53, 'validation': 26}
    artificial_count = 0
    for side, body, values in product((1, -1), (0, .6), product((None, -1, 0, 1), repeat=4)):
        gap, slope, hist, delta = values
        fields = {'candle5_body_signed_ratio': body, 'ema21_delta_signed_30': 1 if body == 0 else -1,
                  'hist_atr_signed_5': .2 if body == 0 else -.2, 'gap_signed_15': gap,
                  'ema21_delta_signed_15': slope, 'hist_signed_15': hist, 'hist_delta_signed_15': delta}
        reference = None
        for volume in (None, 0, 1, 100):
            items = {k: {'known': v is not None, 'value': v} for k, v in {**fields, 'rvol5': volume}.items()}
            actual = chooser.choose(side, items)
            assert {p: actual['choices'][p]['side'] for p in constants['POLICIES']} == independent_sides(side, items)
            if reference is None: reference = actual['choices']
            assert actual['choices'] == reference
            artificial_count += 1
    tests = []
    for path in (PLAN / '人工検査.py', EVAL / '人工検査.py'):
        result = subprocess.run([sys.executable, '-X', 'utf8', str(path)], cwd=ROOT,
                                text=True, encoding='utf-8', capture_output=True)
        assert result.returncode == 0 and 'Ran 8 tests' in result.stderr, (result.stdout, result.stderr)
        tests.append({'path': str(path.relative_to(ROOT)), 'returncode': result.returncode,
                      'stdout': result.stdout, 'stderr': result.stderr})
    after = {str(p.relative_to(ROOT)): sha(p) for p in sorted(files)}
    assert before == after
    proof = {'成功': True, '試行': 131, '段階': '金融前独立準備確認', 'UTC': datetime.now(timezone.utc).isoformat(),
             '主': 'H0', '副': 'H1', '固定取得': 79, '固定場': 73, '前後区分': partitions,
             '独立式の全方向一致': 79 * 5, '最新性の再生成ではなく保存因果参照の照合': refs,
             '全79取得がザラバ終端未満': True, '復帰票数_成績ではない': counts,
             '独立式とRVOL非依存の人工組合せ': artificial_count, '人工検査': tests,
             '指紋前後不変': True, 'SHA256': before, '自然outcomes読取': False,
             '自然損益又は率の算出': False, 'Raw読取': False, '旧金融集計又は方向CSV読取': False,
             '金融時に残る検査': '実正逆Quote対応・全H/幅のtouch/endpoint境界・旧O0/B0/T8全180条件一致は評価器のassertでRootが金融時確認する',
             '限界': '当時特徴の生成自体や実到着時計/逆注文適格性/実IFDは再構築していない。既使用期間の選択偏りは残る。'}
    with (OWN / '準備の独立確認.json').open('x', encoding='utf-8', newline='\n') as handle:
        json.dump(proof, handle, ensure_ascii=False, indent=2, allow_nan=False); handle.write('\n')
    print(json.dumps({'成功': True, '確認SHA256': sha(OWN / '準備の独立確認.json'),
                      '因果参照': refs, '復帰票': counts, '人工組合せ': artificial_count}, ensure_ascii=False))


if __name__ == '__main__':
    main()
