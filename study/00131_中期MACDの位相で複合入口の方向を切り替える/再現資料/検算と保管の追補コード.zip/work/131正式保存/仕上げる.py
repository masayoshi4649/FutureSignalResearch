"""131の検算・CSV・再現コードを金融前資源と分けて保管する。"""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
FORMAL = ROOT / 'study/00131_中期MACDの位相で複合入口の方向を切り替える'
OUTPUT = ROOT / 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/131既存入口CSV'


def sha(body: bytes) -> str:
    """
    機能: 保存内容の指紋を返す。
    引数: body(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


# ----------------------------------------
def copy(source: Path, name: str) -> None:
    """
    機能: 停止済み証跡を正式検査票へ同体保存する。
    引数: source(Path)、name(str)は検査内ファイル名。
    返り値: None。同名があれば同体のみ許容する。
    """
    target = FORMAL / '検査' / name
    body = source.read_bytes()
    if target.exists():
        assert target.read_bytes() == body
        return
    with target.open('xb') as handle:
        handle.write(body)


# ----------------------------------------
def main() -> None:
    """
    機能: 結果後の検算・閲覧資源を一つの追補ZIPと正式資料へ保存する。
    引数: なし。
    返り値: None。条件変更・金融再計算・CSV再作成を行わない。
    """
    review = ROOT / 'work/131独立準備レビュー'
    verify = ROOT / 'work/131独立検算'
    assert sha((verify / '独立検算.json').read_bytes()) == 'c7bbfcab94ffd1f6572474143096eb784ee7b7063608c5894954588678fa7255'
    pairs = [
        (review / '準備の独立確認.json', '準備の独立確認.json'),
        (review / 'F1との接続.json', 'F1との接続.json'),
        (review / '完了.json', '独立準備の完了.json'),
        (verify / '独立検算.json', '独立検算.json'),
        (verify / '完了.json', '独立検算完了.json'),
        (ROOT / 'work/131既存入口CSV出力/独立再読.json', 'CSV独立再読.json'),
        (OUTPUT / 'CSVの確認.json', 'CSVの確認.json'),
    ]
    for source, target in pairs:
        copy(source, target)
    text = (review / 'README.md').read_text('utf-8').replace('[確認する.py](確認する.py)', '[確認コード（追補ZIP）](../再現資料/検算と保管の追補コード.zip)')
    (FORMAL / '検査/独立準備確認.md').write_text(text, encoding='utf-8')
    text = (verify / 'README.md').read_text('utf-8').replace('[検算する.py](検算する.py)', '[検算コード（追補ZIP）](../再現資料/検算と保管の追補コード.zip)')
    (FORMAL / '検査/独立数値検算.md').write_text(text, encoding='utf-8')
    files = [review / '確認する.py', verify / '検算する.py',
             ROOT / 'work/131既存入口CSV出力/出力する.mjs',
             ROOT / 'work/131既存入口CSV出力/CSVを独立再読する.py',
             ROOT / 'work/131正式保存/結果を記す.py', Path(__file__).resolve(),
             FORMAL / '再現資料/保存資料を復元する.py', FORMAL / '再現資料/保管を確認する.py']
    archive = FORMAL / '再現資料/検算と保管の追補コード.zip'
    index = []
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in files:
            body = path.read_bytes(); name = path.relative_to(ROOT).as_posix()
            z.writestr(name, body)
            index.append({'path': name, 'phase': '結果後の検算/保管/閲覧補助。金融前F1源とは別',
                          'bytes': len(body), 'sha256': sha(body)})
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for item in index:
            assert sha(z.read(item['path'])) == item['sha256']
    record = {'ZIP': archive.name, 'ZIP_SHA256': sha(archive.read_bytes()), 'ZIP_bytes': archive.stat().st_size,
              '格納源数': len(index), '格納源': index}
    (FORMAL / '再現資料/追補コード索引.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    (OUTPUT / 'README.md').write_text('''# 131既存入口のCSV

まず[全セッション.csv](全セッション.csv)で全73場の主H0・副H1・固定T8/O0/B0について既知利益/損失/差引/累計/未知を確認する。主はH0・全体実BBO/H60±125pt、全73場79取得・61.40%で70未達。T8の68.42%より悪化し、主副どちらも改善として採用しない。

- [正逆比較.csv](正逆比較.csv)：300行・26列。全体/前48/後25×5政策×BBO/Last×H30/60×5幅。
- [入口別診断.csv](入口別診断.csv)：79行・51列。固定時計、各方向、当時15分Hist/増分・MA・RVOLと主125結果。
- [全セッション.csv](全セッション.csv)：73行・65列。全場を残し、未知を0円にしない。

IFD代用は独立mini1枚100円/pt、C0往復77円、C5は追加1,000円。BBOのspreadを二重控除しない。全H完了の先着率と、途中touch既知のIFD代用は別分母。Last金額は空欄。自然新入口・逆注文の適格性・利益追尾・10枚口座収支ではない。

Rootは全16,574データセル/12,011数値を独立再読し、3プレビューを確認した。[生成確認](CSVの確認.json)。Node24.22.1・Artifact2.8.129、xlsx生成なし。固定条件と限界は[正式131](../../../study/00131_中期MACDの位相で複合入口の方向を切り替える/README.md)。
''', encoding='utf-8')
    (FORMAL / 'README.md').write_text((FORMAL / 'README.md').read_text('utf-8') + '\n[独立準備確認](検査/独立準備確認.md)と[独立数値検算](検査/独立数値検算.md)を保存。全300条件・旧180条件・全16,574表セルを含む32,067値が一致した。CSV実ファイルの独立再読は別証跡として全16,574セル/12,011数値を確認した。\n', encoding='utf-8')
    print(json.dumps({'成功': True, '追補源': len(index), '追補ZIP_SHA256': record['ZIP_SHA256'],
                      '独立検算値': 32067, 'CSV再読セル': 16574}, ensure_ascii=False))


if __name__ == '__main__':
    main()
