"""176元Sourceと177薄いSourceを正式ZIPから順に復元して隔離再現する。"""
from pathlib import Path
import argparse
import json
import os
import shutil
import subprocess
import sys
import venv
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
ISOLATION=ROOT/'work/177隔離再現'
sys.path.insert(0,str(ROOT/'work/176正式保存'))
import 隔離を準備する as P


def main() -> None:
    """
    機能: 元workを参照せず177固定再現を監査付きで行う新規隔離環境を作る。
    引数: --bundle(Path)は177の索引と二ZIPを含む正式又は仮保存先。
    返り値: None。共有inputs/studyは読み取り専用監査で参照する。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--bundle',type=Path,default=HERE/'仮保存');args=parser.parse_args();bundle=args.bundle.resolve()
    index=json.loads((bundle/'保存索引.json').read_text(encoding='utf-8'));assert index['成功'] and not ISOLATION.exists()
    parent=index['Source継承元'];parent_source=ROOT/parent['archive']['path'];parent_index=ROOT/parent['index']['path']
    assert P.digest(parent_source)==parent['archive']['sha256'] and P.digest(parent_index)==parent['index']['sha256']
    for field,name in (('Source','Source.zip'),('正本','出生と比較正本.zip')):assert P.digest(bundle/name)==index[field]['archive']['sha256']
    repository=ISOLATION/'repo';repository.mkdir(parents=True)
    P.restore(parent_source,parent['members'],repository,True)
    P.restore(bundle/'Source.zip',index['Source']['members'],repository,True)
    P.restore(bundle/'出生と比較正本.zip',index['正本']['members'],repository,False)
    artifacts=repository/'artifacts';artifacts.mkdir();shutil.copy2(bundle/'出生と比較正本.zip',artifacts/'出生と比較正本.zip')
    P.junction(repository/'inputs',ROOT/'inputs');P.junction(repository/'study',ROOT/'study')
    environment=ISOLATION/'環境';venv.EnvBuilder(with_pip=False,symlinks=False).create(environment)
    site=Path(np.__file__).resolve().parent.parent;isolated_site=environment/'Lib/site-packages'
    packages=[p for p in site.iterdir() if p.name in ('numpy','numpy.libs','tzdata') or p.name.startswith(('numpy-','tzdata-')) and p.name.endswith('.dist-info')]
    assert any(p.name=='numpy' for p in packages) and any(p.name=='tzdata' for p in packages)
    for package in packages:shutil.copytree(package,isolated_site/package.name)
    audit=ISOLATION/'監査実行.py';shutil.copy2(HERE/'監査実行.py',audit)
    record={'成功':True,'176元SourceSHA256':P.digest(parent_source),'177新SourceSHA256':P.digest(bundle/'Source.zip'),
        '小正本SHA256':P.digest(bundle/'出生と比較正本.zip'),'復元':'176元byte→177薄い新Source→必要小入力。共有入力は読取監査。',
        '環境':'新規venv・NumPy'+np.__version__+'・tzdata','実行SourceSHA256':P.digest(audit)}
    (ISOLATION/'準備.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    env=os.environ.copy();env.pop('PYTHONPATH',None);env.update({'PYTHONIOENCODING':'utf-8','PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'})
    subprocess.run([str(environment/'Scripts/python.exe'),str(audit)],cwd=repository,env=env,check=True)


if __name__=='__main__':main()
