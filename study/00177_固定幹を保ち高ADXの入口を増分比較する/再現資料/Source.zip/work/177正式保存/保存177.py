"""176正式Sourceを参照継承し、177新Sourceと小正本だけを薄く保存する。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import json
import os
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'work/176正式保存'))
import 保存175_176 as P
TRIAL=ROOT/'study/00177_固定幹を保ち高ADXの入口を増分比較する'
PARENT=ROOT/'study/00176_役割票と局面別構造で入口を広げる/再現資料'
OLD=ROOT/'study/00174_共同条件を残して単一建玉の入口を広げる/再現資料'
DESTINATION=TRIAL/'再現資料'
CSV=ROOT/'outputs/00177_高ADX枝の増分比較'
IDS={'全期_J002_J000','全期_J003_J000','前48_J000_J005','前48_J000_J013'}


def inherited() -> tuple:
    """
    機能: 176正式Sourceの全元byteと174必要小memberを正式索引へ照合する。
    引数: なし。
    返り値: tuple[dict,dict,dict]はSource継承参照・旧小入力参照・小member元byte。
    """
    parent=P.read(PARENT/'保存索引.json');source=PARENT/'Source.zip'
    assert P.fingerprint(source)==parent['Source']['archive'] and parent['正式保存']
    with zipfile.ZipFile(source) as archive:
        assert archive.testzip() is None and set(archive.namelist())=={r['path'] for r in parent['Source']['members']}
        assert all(P.member_reference(r['path'],archive.read(r['path']))==r for r in parent['Source']['members'])
        own_dependency='work/176正式保存/保存175_176.py'
        assert P.member_reference(own_dependency,Path(P.__file__).read_bytes())==next(r for r in parent['Source']['members'] if r['path']==own_dependency)
    source_ref={'archive':P.fingerprint(source),'index':P.fingerprint(PARENT/'保存索引.json'),
        'members':parent['Source']['members'],'継承':'177薄いSource.zipに重複せず、176 Source.zip元byteを先に復元する。'}
    old=P.read(OLD/'保存索引.json');old_archive=OLD/'出生と比較正本.zip';assert P.fingerprint(old_archive)==old['正本']['archive']
    refs={r['path']:r for r in old['正本']['members']};names=[f'work/174追加七場適用/{period}の{kind}174.{suffix}'
        for period in ('旧73','追加7') for kind,suffix in (('純出生','npz'),('全取得','json.gz'))]
    names.append('work/174参加と両中央値の再探索/旧73jointの固定選択.json');contents={}
    with zipfile.ZipFile(old_archive) as archive:
        assert archive.testzip() is None
        for name in names:
            body=archive.read(name);assert P.member_reference(name,body)==refs[name];contents[name]=body
    return source_ref,{'archive':P.fingerprint(old_archive),'index':P.fingerprint(OLD/'保存索引.json'),'members':[refs[n] for n in names],'元byte継承':True},contents


def collect() -> tuple:
    """
    機能: 177自身のSource/小正本を集め、大きい予備統計と画像を省略する。
    引数: なし。
    返り値: tuple[list,list,list]はSource・小正本・省略指紋。
    """
    sources=[];results=[];omitted=[]
    for folder in sorted(p for p in (ROOT/'work').glob('177*') if p.is_dir() and '隔離再現' not in p.name):
        for current,dirs,files in os.walk(folder,followlinks=False):
            dirs[:]=[n for n in dirs if n not in P.EXCLUDED_DIRS and 'cache' not in n.lower()]
            for name in files:
                path=Path(current)/name
                if path.suffix in ('.py','.mjs'):sources.append(path);continue
                if path.is_relative_to(HERE) and path.name!='README.md':continue
                if path.suffix not in ('.md','.json','.gz','.npz','.png','.jpg','.webp','.csv'):continue
                reason=None
                if path.suffix=='.npz' and '予備統計' in path.name:reason='再生成可能な全幅期限予備統計。軸・純出生・辞書・選択Source・指紋を保存する。'
                elif path.suffix in ('.png','.jpg','.webp'):reason='表示画像は再生成中間であり重複保存しない。'
                elif path.suffix=='.csv':reason='候補別CSVはoutputs正本を指紋参照しZIPへ重複保存しない。'
                if reason:omitted.append({'file':P.fingerprint(path),'理由':reason})
                else:assert path.stat().st_size<16*1024*1024;results.append(path)
    results.extend(p for p in TRIAL.rglob('*') if p.is_file() and '再現資料' not in p.relative_to(TRIAL).parts and p.suffix in ('.json','.md'))
    sources.append(ROOT/'scripts/損益CSV/候補別に出力する.mjs')
    assert Path(__file__) in sources and HERE/'正式入力で再現する.py' in sources
    return sorted(set(sources)),sorted(set(results)),sorted(omitted,key=lambda r:r['file']['path'])


def gates(final: bool, extra: list) -> dict:
    """
    機能: 固定四案・旧73/全80独立検査・CSV正本・最終隔離を確認する。
    引数: final(bool)、extra(list[Path])はRoot追加必須。
    返り値: dictは指紋と完了条件。
    """
    fixed=P.read(ROOT/'work/177高ADX枝の増分比較/旧73の固定選択.json')
    assert {r['id'] for v in fixed['選択'].values() for r in v['candidates']}==IDS
    required=[TRIAL/'条件.json',ROOT/'work/177高ADX枝の増分比較/旧四対照の同体.json',
        *[ROOT/'work/177高ADX枝の増分比較'/n for n in ('増分単独.json.gz','増分二枝.json.gz','三帯接合.json.gz','純出生177.npz','旧73の固定選択.json')],
        *[ROOT/'work/177追加七場適用'/n for n in ('旧73の全取得177.json.gz','追加7の全取得177.json.gz','全80の両中央値177.json.gz','金融前の出生固定.json','完了.json')],
        *[ROOT/'work/177増分の独立検査'/n for n in ('増分177の独立結果.json','追加七場と全80の独立結果.json','候補別CSVの独立結果.json')],*extra]
    assert all(p.is_file() for p in required),[str(p) for p in required if not p.is_file()]
    assert P.read(ROOT/'work/177追加七場適用/完了.json')['金融後Source変更なし']
    assert all(P.read(ROOT/'work/177増分の独立検査'/name)['成功'] for name in ('増分177の独立結果.json','追加七場と全80の独立結果.json','候補別CSVの独立結果.json'))
    csv_files=sorted(CSV.rglob('*.csv'));assert len(csv_files)==16
    if final:
        assert all((TRIAL/n).is_file() for n in ('README.md','設定と結果.md','再現手順.md'))
        audit=ROOT/'work/177隔離再現/repo/work/監査結果.json';verification=ROOT/'work/177隔離再現/repo/work/正式runner確認/再現確認.json'
        assert P.read(audit)['成功'] and P.read(verification)['成功']
        assert P.fingerprint(ROOT/'work/177隔離再現/repo/work/177正式保存/正式入力で再現する.py')['sha256']==P.fingerprint(HERE/'正式入力で再現する.py')['sha256']
        assert P.read(audit)['監査SourceSHA256']==P.fingerprint(HERE/'監査実行.py')['sha256'];required.extend([audit,verification])
    return {'成功':True,'必須':[P.fingerprint(p) for p in sorted(set(required))],'固定参考四案':sorted(IDS),
        '候補別CSV':[P.fingerprint(p) for p in csv_files],'注意':'追加期Night悪化と前48後25悪化を保持。共同条件を満たしても安定採用とはしない。'}


def execute(destination: Path, final: bool, extra: list) -> dict:
    """
    機能: 177新Sourceだけの薄いZIPと必要旧小入力を含む正本を新規保存する。
    引数: destination(Path)、final(bool)、extra(list[Path])。
    返り値: dictは保存索引。旧Sourceや178を混在させない。
    """
    assert not any((destination/n).exists() for n in ('Source.zip','出生と比較正本.zip','保存索引.json'))
    gate=gates(final,extra);source_ref,old_ref,old_small=inherited();source_paths,result_paths,omitted=collect()
    before={p.relative_to(ROOT).as_posix():P.fingerprint(p) for p in source_paths+result_paths}
    source_bytes={p.relative_to(ROOT).as_posix():p.read_bytes() for p in source_paths}
    assert not set(source_bytes)&{r['path'] for r in source_ref['members']}
    source_bytes['継承/176Sourceの参照.json']=(json.dumps(source_ref,ensure_ascii=False,separators=(',',':'))+'\n').encode('utf-8')
    results={p.relative_to(ROOT).as_posix():p.read_bytes() for p in result_paths};assert not set(results)&set(old_small);results.update(old_small)
    if final:
        for p in (ROOT/'work/177隔離再現/repo/work/監査結果.json',ROOT/'work/177隔離再現/repo/work/正式runner確認/再現確認.json'):
            results['検査/177隔離/'+p.name]=p.read_bytes()
    destination.mkdir(parents=True,exist_ok=True)
    source=P.write_archive(destination/'Source.zip',source_bytes);canonical=P.write_archive(destination/'出生と比較正本.zip',results)
    assert all(P.fingerprint(ROOT/name)==value for name,value in before.items())
    assert P.fingerprint(PARENT/'Source.zip')==source_ref['archive'] and P.fingerprint(OLD/'出生と比較正本.zip')==old_ref['archive']
    index={'成功':True,'正式保存':final,'保存UTC':datetime.now(timezone.utc).isoformat(),'Source':source,'正本':canonical,
        'Source継承元':source_ref,'旧小入力の選択継承':old_ref,'新Source':[P.fingerprint(p) for p in source_paths],
        '完了gate':gate,'省略中間指紋':omitted,'保存器':P.fingerprint(Path(__file__)),
        '共用入力':'正式148の固定151/161射影と共有163/167。176正式Source→177新Sourceの順に復元。原板/cache/金融配列副本なし。',
        '注意':'177は旧幹保持の有望増分。全80既使用、追加期Nightと前48後25悪化を保持し安定採用とは呼ばない。178は別試行で収録しない。'}
    (destination/'保存索引.json').write_text(json.dumps(index,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    return index


def main() -> None:
    """
    機能: 隔離用仮保存とRoot最終GO後の正式保存を分けて実行する。
    引数: --prepare(bool)、--execute/--go(bool)、--require(Path,反復可)。
    返り値: None。引数なしでは正式ZIPを作らない。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--prepare',action='store_true');parser.add_argument('--execute',action='store_true');parser.add_argument('--go',action='store_true')
    parser.add_argument('--require',type=Path,action='append',default=[]);args=parser.parse_args();extra=[(p if p.is_absolute() else ROOT/p).resolve() for p in args.require]
    if args.prepare:assert not args.execute and not args.go;result=execute(HERE/'仮保存',False,extra)
    elif args.execute or args.go:assert args.execute and args.go;result=execute(DESTINATION,True,extra)
    else:print(json.dumps({'準備済み':True,'正式保存未実行':True},ensure_ascii=False));return
    print(json.dumps({'成功':True,'正式保存':result['正式保存'],'Source':result['Source']['archive'],'正本':result['正本']['archive']},ensure_ascii=False))


if __name__=='__main__':main()
