"""177固定四案と174無追加四対照を正式148・共有163/167から隔離再現する。"""
from pathlib import Path
from io import BytesIO
import argparse
import gzip
import json
import sys
import zipfile
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work/175局面別入口の再探索'))
import 基盤175 as BASE
B=BASE.B
TRIAL=ROOT/'study/00177_固定幹を保ち高ADXの入口を増分比較する'
BASE_IDS=('全期_J002','全期_J003','前48_J000','前48_J001')
KEYS=('core','branches','technical','tier','mw','fw','hi')


def main() -> None:
    """
    機能: 正式Source継承と小正本だけで全出生/全pack/全80を照合する。
    引数: --archive(Path)は177小正本ZIP、--output(Path)は新規work確認先。
    返り値: None。新探索・追加期選択・原板/cache再読を行わない。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--archive',type=Path,default=TRIAL/'再現資料/出生と比較正本.zip')
    parser.add_argument('--output',type=Path,required=True);args=parser.parse_args();output=args.output.resolve()
    assert output.is_relative_to(ROOT/'work') and not output.exists()
    adapter=B.P.module(ROOT/'work/177追加七場適用/固定政策を適用する.py','formal177_adapter')
    increment=B.P.module(ROOT/'work/177高ADX枝の増分比較/増分177.py','formal177_increment')
    builder=B.P.module(ROOT/'work/177高ADXの増分純入口/rules177.py','formal177_builder')
    formal176=B.P.module(ROOT/'work/176正式保存/正式入力で再現する.py','formal176_helper_for177')
    checks=[];controls={};regenerated={};metadata={}
    with zipfile.ZipFile(args.archive) as archive:
        assert archive.testzip() is None
        def read(name: str) -> dict:
            """
            機能: 正式小正本ZIPからJSONを元byteで読む。
            引数: name(str)はmember名。
            返り値: dictはJSON又はgzip JSON。
            """
            body=archive.read(name);return json.loads(gzip.decompress(body) if name.endswith('.gz') else body)
        fixed_body=read('work/177高ADX枝の増分比較/旧73の固定選択.json');assert fixed_body['成功']
        fixed=[p for route in ('全期','前48') for p in fixed_body['選択'][route]['candidates']]
        assert len(fixed)==4 and len({p['id'] for p in fixed})==4
        catalog=read('work/177高ADXの増分純入口/候補辞書177.json')['rules'];lookup={r['id']:i for i,r in enumerate(catalog)}
        rules={r['birth_key']:r for p in fixed for rows in p['options'].values() for r in rows}
        ids=sorted({r['rule_id'] for r in rules.values()})
        for period,context in (('旧73',formal176.old_context()),('追加7',B.load_context(True))):
            output_birth=builder.build(context.features,np.asarray([s['start'] for s in context.scenes]),context.event_phases,candidate_ids=ids)
            assert output_birth['candidate_ids']==ids and np.array_equal(output_birth['phases'],context.event_phases)
            raw={name:output_birth['directions'][i] for i,name in enumerate(ids)}
            if period=='旧73':
                with np.load(BytesIO(archive.read('work/177高ADX枝の増分比較/純出生177.npz')),allow_pickle=False) as original:
                    assert np.array_equal(original['phases'],context.event_phases)
                    matrix=original['directions'];assert all(np.array_equal(value,matrix[lookup[name]]) for name,value in raw.items())
            directions={}
            for key,rule in rules.items():
                assert key==rule['rule_id']+'/'+rule['orientation'] and rule['orientation'] in ('NORMAL','REVERSE')
                directions[key]=raw[rule['rule_id']].copy() if rule['orientation']=='NORMAL' else -raw[rule['rule_id']]
            report=read(f'work/177追加七場適用/{period}の全取得177.json.gz')
            assert len(report['rows'])==4 and [r['id'] for r in report['rows']]==[p['id'] for p in fixed]
            assert len({r['id'] for r in report['rows']})==4
            eligible,hours=adapter.A.eligibility(context)
            meta={'場数':len(context.scenes),'場順':context.sessions,'対象場':eligible,'対象時間':hours,
                '幅順':list(context.table.widths),'期限順':list(context.table.horizons)}
            assert all(report[key]==value for key,value in meta.items()),(period,'metadata');metadata[period]=meta
            old_rows={r['id']:r for r in read(f'work/174追加七場適用/{period}の全取得174.json.gz')['rows']}
            with np.load(BytesIO(archive.read(f'work/174追加七場適用/{period}の純出生174.npz')),allow_pickle=False) as sealed:
                assert np.array_equal(sealed['phases'],context.event_phases)
                bases={base:{key:sealed[base+'__'+key].copy() for key in KEYS} for base in BASE_IDS}
            controls[period]=adapter.no_add_check(context,bases,old_rows,increment)
            assert controls[period]==report['追加なし旧174全pack同体']
            expected={r['id']:r for r in report['rows']};rows=[]
            with np.load(BytesIO(archive.read(f'work/177追加七場適用/{period}の純出生177.npz')),allow_pickle=False) as sealed:
                assert np.array_equal(sealed['phases'],context.event_phases)
                expected_keys={'phases'}
                for policy in fixed:
                    birth,mw,fw,hi,active,blocked=increment.combine(bases[policy['base']],context.event_phases,policy['options'],directions,list(context.table.horizons))
                    arrays={**birth,'mw':mw,'fw':fw,'hi':hi,'active':active,'blocked':blocked}
                    for key,value in arrays.items():
                        name=policy['id']+'__'+key;expected_keys.add(name);assert np.array_equal(value,sealed[name]),(period,name)
                    value=B.replay(context,birth,mw,fw,hi,True);row=adapter.pack(context,value,policy,active,increment)
                    assert row==expected[policy['id']],(period,policy['id'],'全pack')
                    assert max((r['peak_global_reserved'] for r in row['engine']['audits']),default=0)<=1
                    checks.append({'期間':period,'id':policy['id'],'取得':len(row['cases']),'新枝':row['new_count'],
                        '純出生全属性・全pack・added・origins・金融・完全経路一致':True});rows.append(row)
                assert expected_keys==set(sealed.files)
            regenerated[period]=rows
        expected80=read('work/177追加七場適用/全80の両中央値177.json.gz')
        eligible={name:metadata['旧73']['対象場'][name]+metadata['追加7']['対象場'][name] for name in ('DAY','PRE','POST')}
        hours={name:metadata['旧73']['対象時間'][name]+metadata['追加7']['対象時間'][name] for name in ('DAY','PRE','POST')}
        assert expected80['場数']==metadata['旧73']['場数']+metadata['追加7']['場数']==80
        assert expected80['対象場']==eligible and expected80['対象時間']==hours
        assert [r['id'] for r in expected80['rows']]==[p['id'] for p in fixed] and len({r['id'] for r in expected80['rows']})==4
        actual_rows=[]
        for old,added in zip(regenerated['旧73'],regenerated['追加7'],strict=True):
            assert old['id']==added['id'];joined={name:old['ledger'][name]+added['ledger'][name] for name in ('net','known','label','scene')}
            phases=old['phases']+added['phases'];origins=old['origins']+added['origins'];flags=old['added']+added['added']
            financial=B.metrics173.evaluate_metrics(joined['net'],joined['known'],joined['label'],joined['scene'],phases,origins,eligible,hours)
            actual_rows.append({'id':old['id'],'policy':old['policy'],'financial':financial,'paths':adapter.A.paths(financial),
                'ledger':joined,'phases':phases,'origins':origins,'added':flags,'new_count':sum(flags),
                'old_main_count':old['old_main_count']+added['old_main_count'],'fallback_count':old['fallback_count']+added['fallback_count'],
                '旧73':old['financial'],'追加7':added['financial']})
        assert actual_rows==expected80['rows']
    output.mkdir(parents=True)
    B.P.save(output/'再現確認.json',{'成功':True,'確認':checks,'旧174追加なし四対照全pack同体':controls,
        '全80全行・対象場時間・金融・経路・added再構成一致':True,'正式148キャッシュ不使用':True,
        '小正本SHA256':B.P.sha(args.archive),'注意':'全80既使用。追加期Night悪化と前48の後25悪化は保持。安定採用や独立未見性能ではない。'})
    print(json.dumps({'成功':True,'候補期間':len(checks),'旧174noadd照合':sum(len(v) for v in controls.values()),'全80全行一致':True},ensure_ascii=False))


if __name__=='__main__':main()
