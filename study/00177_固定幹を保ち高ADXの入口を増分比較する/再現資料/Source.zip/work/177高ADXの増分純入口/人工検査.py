"""177のSource同体・最終ゲート・鏡像と因果性を人工入力だけで確認する。"""
import hashlib
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import rules177 as R

ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('synthetic176_for177',ROOT/'work/176局面別の役割票/人工検査.py')
A=importlib.util.module_from_spec(spec);spec.loader.exec_module(A)


def main() -> None:
    """
    機能: 768候補のSource同体・鏡像・prefix・未来改変・未知・境界とgapを検査する。
    引数: なし。
    返り値: None。辞書と人工確認JSONのみ保存し自然出生・金融を生成しない。
    """
    here=Path(__file__).resolve().parent;catalog=R.catalog();checks={};cells=0
    source_before={x['source_id']:x['sha256'] for x in catalog['sources']}
    for source_id,module in R.SOURCES.items():
        for group in R.GROUPS:
            features,starts=A.synthetic(group)
            rules=[r for r in catalog['rules'] if r['source_id']==source_id and r['group']==group]
            ids=[r['id'] for r in rules];source_ids=[r['source_rule_id'] for r in rules]
            result=R.build(features,starts,candidate_ids=ids)['directions']
            original=module.build(features,starts,candidate_ids=source_ids)['directions']
            adx=features.columns.index('m15_adx')
            expected=np.where(((original==1)&(features.buy_X[:,adx]>20))|((original==-1)&(features.sell_X[:,adx]>20)),original,0)
            assert np.array_equal(result,expected) and result.any(),(source_id,group)
            swapped=SimpleNamespace(buy_X=features.sell_X.copy(),sell_X=features.buy_X.copy(),columns=features.columns,q0_meta=features.q0_meta)
            assert np.array_equal(R.build(swapped,starts,candidate_ids=ids)['directions'],-result)
            for end in (20,36,50):
                prefix=R.build(A.A.take(features,end),starts,candidate_ids=ids)['directions']
                assert np.array_equal(prefix,result[:,:end])
                future=A.A.take(features,len(features.q0_meta));future.buy_X[end:]=np.nan;future.sell_X[end:]=np.nan
                assert np.array_equal(R.build(future,starts,candidate_ids=ids)['directions'][:,:end],result[:,:end])
                cells+=2*prefix.size
            for value in (20,np.nan):
                blocked=A.A.take(features,len(features.q0_meta));blocked.buy_X[:,adx]=value;blocked.sell_X[:,adx]=value
                assert not R.build(blocked,starts,candidate_ids=ids)['directions'].any()
            boundary=A.A.take(features,len(features.q0_meta));boundary.buy_X[:,adx]=20.01;boundary.sell_X[:,adx]=20.01
            raw=module.build(boundary,starts,candidate_ids=source_ids)['directions']
            assert np.array_equal(R.build(boundary,starts,candidate_ids=ids)['directions'],raw)
            gap=A.A.take(features,len(features.q0_meta))
            for q in gap.q0_meta[36:]:q['q0_time']+=300
            raw=module.build(gap,starts,candidate_ids=source_ids)['directions']
            assert np.array_equal(R.build(gap,starts,candidate_ids=ids)['directions'],raw)
            checks[source_id+'_'+group]={'候補数':len(ids),'人工成立セル':int(np.count_nonzero(result)),
                'Source同体と最終ゲート':True,'鏡像':True,'prefixと未来改変':True,'ADX20と未知は待機':True,
                'ADX20超とgapの元時計を保持':True}
    # ----------------------------------------
    # ゲートだけが再び真になっても、元EDGEが0の行を新たに発火させない。
    features,starts=A.synthetic('HT');adx=features.columns.index('m15_adx')
    features.buy_X[:,adx]=20;features.sell_X[:,adx]=20
    features.buy_X[40:,adx]=21;features.sell_X[40:,adx]=21
    for source_id,module in R.SOURCES.items():
        source_id_rule='HT0001_EDGE';identity=source_id+'_'+source_id_rule
        raw=module.build(features,starts,candidate_ids=[source_id_rule])['directions'][0]
        actual=R.build(features,starts,candidate_ids=[identity])['directions'][0]
        assert actual[40]==0 and raw[40]==0
        assert np.all((actual==0)|(actual==raw))
    after=R.catalog();assert source_before=={x['source_id']:x['sha256'] for x in after['sources']}
    target=here/'候補辞書177.json';target.write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    proof={'成功':True,'人工入力だけで新規自然出生と金融未入力':True,'候補数':768,'照合セル':cells,
        '検査':checks,'ゲート回復で元EDGEを再発火しない':True,'元Source変更なし':source_before,
        'SourceSHA256':hashlib.sha256((here/'rules177.py').read_bytes()).hexdigest(),
        '候補辞書SHA256':hashlib.sha256(target.read_bytes()).hexdigest()}
    (here/'人工確認177.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':
    main()
