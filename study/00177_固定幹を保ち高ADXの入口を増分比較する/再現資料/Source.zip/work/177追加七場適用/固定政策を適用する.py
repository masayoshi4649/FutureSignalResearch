"""177固定四案を、174正式封印幹と純新枝の金融前封印後に追加七場へ適用する。"""
from pathlib import Path
from io import BytesIO
from datetime import datetime, timezone
import argparse
import copy
import hashlib
import json
import sys
import zipfile
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'work/176追加七場適用'))
import 固定政策を適用する as A
B=A.B
FIXED=ROOT/'work/177高ADX枝の増分比較/旧73の固定選択.json'
OLD_REPORT=ROOT/'work/177高ADX枝の増分比較/三帯接合.json.gz'
OLD_BIRTH=ROOT/'work/177高ADX枝の増分比較/純出生177.npz'
BUILDER=ROOT/'work/177高ADXの増分純入口/rules177.py'
CATALOG=ROOT/'work/177高ADXの増分純入口/候補辞書177.json'
INCREMENT=ROOT/'work/177高ADX枝の増分比較/増分177.py'
PARENT=ROOT/'study/00174_共同条件を残して単一建玉の入口を広げる/再現資料'
BASE_IDS=('全期_J002','全期_J003','前48_J000','前48_J001')
KEYS=('core','branches','technical','tier','mw','fw','hi')


def policies(expected_sha: str) -> list:
    """
    機能: Root指定SHAの全期/前48各最大二案だけを取り出す。
    引数: expected_sha(str)はGO時の固定票SHA256。
    返り値: list[dict]は保存順の固定四政策。選び直さない。
    """
    assert len(expected_sha)==64 and A.physical(FIXED)['sha256']==expected_sha.lower()
    body=B.P.read(FIXED);assert body['成功'] and body['追加7当該候補金融未読'];result=[]
    for route in ('全期','前48'):
        values=body['選択'][route]['candidates'];assert len(values)<=2
        assert all(p['route']==route and p['base'] in BASE_IDS and set(p['options'])=={'PRE','POST'} for p in values)
        assert all(len(rows)<=2 for p in values for rows in p['options'].values());result.extend(values)
    assert len(result)==4 and len({p['id'] for p in result})==4
    assert {p['id'] for p in result}=={'全期_J002_J000','全期_J003_J000','前48_J000_J005','前48_J000_J013'}
    return result


def source_paths() -> list:
    """
    機能: 実行前後に確認するSourceと非金融固定入力を列挙する。
    引数: なし。
    返り値: list[Path]。金融reportは出生封印後に別途確認する。
    """
    values=[Path(__file__),HERE/'README.md',FIXED,OLD_BIRTH,OLD_BIRTH.with_suffix('.json'),BUILDER,CATALOG,INCREMENT,
        PARENT/'保存索引.json',ROOT/'study/00177_固定幹を保ち高ADXの入口を増分比較する/条件.json',
        ROOT/'work/163任意幅の数値化/arrays163.py',ROOT/'work/166可変場の数値化/arrays166.py']
    for module in list(sys.modules.values()):
        name=getattr(module,'__file__',None)
        if name:
            path=Path(name).resolve()
            if path.suffix=='.py' and path.is_relative_to(ROOT):values.append(path)
    return sorted(set(values))


def official_seals() -> tuple:
    """
    機能: 174正式ZIPの物理指紋と元member指紋へ両期間の純出生を照合する。
    引数: なし。
    返り値: tuple[dict,dict]は期間別四幹と継承指紋。金融memberを解釈しない。
    """
    index=B.P.read(PARENT/'保存索引.json');archive_path=PARENT/'出生と比較正本.zip'
    assert A.physical(archive_path)==index['正本']['archive'];refs={r['path']:r for r in index['正本']['members']}
    result={};members=[]
    with zipfile.ZipFile(archive_path) as archive:
        for period in ('旧73','追加7'):
            name=f'work/174追加七場適用/{period}の純出生174.npz';body=archive.read(name)
            assert {'path':name,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}==refs[name]
            with np.load(BytesIO(body),allow_pickle=False) as sealed:
                result[period]={'phases':sealed['phases'].copy(),
                    'bases':{base:{key:sealed[base+'__'+key].copy() for key in KEYS} for base in BASE_IDS}}
            members.append(refs[name])
    return result,{'archive':A.physical(archive_path),'index':A.physical(PARENT/'保存索引.json'),'members':members,'元byte継承':True}


def build_directions(features: object, fixed: list, builder: object) -> tuple:
    """
    機能: 177のmode/ADXゲート既適用方向に正逆を一回だけ適用する。
    引数: features(object)、fixed(list[dict])、builder(object)。
    返り値: tuple[dict,dict]はbirth_key方向と正逆前rule_id方向。金融を入力しない。
    """
    rules={r['birth_key']:r for p in fixed for rows in p['options'].values() for r in rows}
    ids=sorted({r['rule_id'] for r in rules.values()})
    born=builder.build(features,np.asarray([s['start'] for s in features.scenes]),features.q0_timeband,candidate_ids=ids)
    assert born['candidate_ids']==ids and np.array_equal(born['phases'],features.q0_timeband)
    assert born['directions'].shape==(len(ids),len(features.q0_meta)) and np.isin(born['directions'],(-1,0,1)).all()
    raw={name:born['directions'][i].copy() for i,name in enumerate(ids)};directions={}
    for key,rule in rules.items():
        assert key==rule['rule_id']+'/'+rule['orientation'] and rule['orientation'] in ('NORMAL','REVERSE')
        directions[key]=raw[rule['rule_id']].copy() if rule['orientation']=='NORMAL' else -raw[rule['rule_id']]
    return directions,raw


def freeze_births(fixed: list, before: dict, increment: object, builder: object, bases: dict, parent_ref: dict) -> dict:
    """
    機能: 旧73新枝一致と174幹同体を確認し、両期間の合成出生を金融前封印する。
    引数: fixed(list)、before(dict)、increment/builder(object)、bases/parent_ref(dict)。
    返り値: dictは純入力指紋・出生指紋・合成確認。
    """
    data=B.P.R168.BASE.data_module();old=data.load_feature_dataset()
    directory=ROOT/'inputs/00167_追加七場の入口と共用価格索引/入口母集団';added,_,_=B.P.R168.BASE.load_features(directory)
    inputs=[ROOT/'work/151過去場判別の評価/入口選択/cache/feature_only/features.npz',ROOT/'work/151過去場判別の評価/入口選択/cache/feature_only/features_meta.json',
        *[directory/name for name in ('完了.json','当時特徴.json.gz','固定取得入力.json.gz','取得対応.json.gz')]]
    proof={'成功':True,'追加7金融未読':True,'金融内容未入力':True,'Sourceと固定選択':before,'174正式幹':parent_ref,
        '非金融入力':{p.relative_to(ROOT).as_posix():A.physical(p) for p in inputs},'期間':{}}
    old_proof=B.P.read(OLD_BIRTH.with_suffix('.json'));assert old_proof['金融未入力'] and B.P.sha(OLD_BIRTH)==old_proof['出生SHA256']
    catalog=B.P.read(CATALOG)['rules'];lookup={r['id']:i for i,r in enumerate(catalog)}
    for period,features in (('旧73',old),('追加7',added)):
        directions,raw=build_directions(features,fixed,builder)
        assert np.array_equal(features.q0_timeband,bases[period]['phases'])
        if period=='旧73':
            with np.load(OLD_BIRTH,allow_pickle=False) as sealed:
                assert np.array_equal(sealed['phases'],features.q0_timeband)
                matrix=sealed['directions'];assert all(np.array_equal(value,matrix[lookup[name]]) for name,value in raw.items())
        arrays={'phases':features.q0_timeband};counts=[]
        for policy in fixed:
            birth,mw,fw,hi,active,blocked=increment.combine(bases[period]['bases'][policy['base']],features.q0_timeband,policy['options'],directions,A.HORIZONS)
            prefix=policy['id']+'__';arrays.update({prefix+key:value for key,value in birth.items()})
            arrays.update({prefix+key:value for key,value in [('mw',mw),('fw',fw),('hi',hi),('active',active),('blocked',blocked)]})
            counts.append({'id':policy['id'],'合成主成立q0':int(np.count_nonzero(birth['core'])),'新枝成立q0':int(active.sum()),'枝競合q0':int(blocked.sum()),'旧T成立q0':int(np.count_nonzero(birth['technical']))})
        target=HERE/(period+'の純出生177.npz');assert not target.exists();np.savez_compressed(target,**arrays)
        proof['期間'][period]={'場順':[s['session'] for s in features.scenes],'q0数':len(features.q0_meta),'出生':A.physical(target),
            '新birth_key数':len(directions),'必要rule_id数':len(raw),'診断':counts,'旧73純新枝一致':period=='旧73'}
    assert all(A.physical(ROOT/name)==value for name,value in before.items())
    assert all(A.physical(ROOT/name)==value for name,value in proof['非金融入力'].items())
    A.save(HERE/'金融前の出生固定.json',proof);return proof


def no_add_check(context: object, bases: dict, expected: dict, increment: object) -> list:
    """
    機能: 各期間の旧174四対照を追加なしで全pack同体確認する。
    引数: context(object)、bases/expected(dict)、increment(object)。
    返り値: list[dict]は全取得・engine・金融・台帳の一致票。
    """
    checks=[]
    for base in BASE_IDS:
        birth,mw,fw,hi,active,blocked=increment.combine(bases[base],context.event_phases,{}, {},list(context.table.horizons))
        assert not active.any() and not blocked.any()
        value=B.replay(context,birth,mw,fw,hi,True)
        actual=A.pack(context,value,expected[base]['policy'])
        assert all(actual[key]==value for key,value in expected[base].items()),base
        checks.append({'id':base,'追加なし旧174全pack一致':True,'取得':len(value[0].cases)})
    return checks


def pack(context: object, value: tuple, policy: dict, active: np.ndarray, increment: object) -> dict:
    """
    機能: 共通packへ新枝取得flag・旧主/T件数・期間群を追加する。
    引数: context(object)、value(tuple)、policy(dict)、active(np.ndarray)、increment(object)。
    返り値: dict。originsの旧0/2は保持し、addedは実取得eventで照合する。
    """
    row=A.pack(context,value,policy);added=active[value[0].events]
    assert not ((value[1]==2)&added).any()
    periods,compact=increment.evidence(context,value)
    row.update({'added':added.tolist(),'new_count':int(added.sum()),'old_main_count':int(((value[1]==0)&~added).sum()),
        'fallback_count':int((value[1]==2).sum()),'periods':periods,'period_paths':compact})
    return row


def run(expected_sha: str) -> None:
    """
    機能: 固定四案を封印後だけ金融へ接続し、全80台帳と新枝flagを連結する。
    引数: expected_sha(str)はRootのGOと固定票SHA256。
    返り値: None。追加7で条件や候補を選び直さず新規保存する。
    """
    assert not (HERE/'金融前の出生固定.json').exists();fixed=policies(expected_sha)
    increment=B.P.module(INCREMENT,'increment177_added');builder=B.P.module(BUILDER,'pure177_added')
    bases,parent_ref=official_seals();before={p.relative_to(ROOT).as_posix():A.physical(p) for p in source_paths()}
    A.save(HERE/'出生前の固定.json',{'成功':True,'UTC':datetime.now(timezone.utc).isoformat(),'固定票SHA256':expected_sha.lower(),
        'Sourceと固定選択':before,'対象':[p['id'] for p in fixed],'追加7金融未読':True})
    proof=freeze_births(fixed,before,increment,builder,bases,parent_ref);proof_ref=A.physical(HERE/'金融前の出生固定.json')
    # ----------------------------------------
    # 新枝と174幹の両期間合成出生を封印してから金融member/金融表を読む。
    expected_ref=A.physical(OLD_REPORT);expected={r['id']:r for r in B.P.read(OLD_REPORT)['rows'] if r['id'] in {p['id'] for p in fixed}}
    assert len(expected)==4;reports={};same=[];controls={}
    with zipfile.ZipFile(PARENT/'出生と比較正本.zip') as parent_archive:
        for new,period in ((False,'旧73'),(True,'追加7')):
            parent_body=parent_archive.read(f'work/174追加七場適用/{period}の全取得174.json.gz')
            import gzip
            parent_rows={r['id']:r for r in json.loads(gzip.decompress(parent_body))['rows']}
            context=B.load_context(new);assert context.sessions==proof['期間'][period]['場順']
            controls[period]=no_add_check(context,bases[period]['bases'],parent_rows,increment)
            target=HERE/(period+'の純出生177.npz');assert A.physical(target)==proof['期間'][period]['出生'];rows=[]
            with np.load(target,allow_pickle=False) as sealed:
                assert np.array_equal(sealed['phases'],context.event_phases)
                for policy in fixed:
                    prefix=policy['id']+'__';birth={k:sealed[prefix+k] for k in ('core','branches','technical','tier')}
                    mw,fw,hi=[sealed[prefix+k] for k in ('mw','fw','hi')];active=sealed[prefix+'active']
                    value=B.replay(context,birth,mw,fw,hi,True);row=pack(context,value,policy,active,increment)
                    maximum=max((a['peak_global_reserved'] for a in value[-1]['audits']),default=0);assert maximum<=1
                    if not new:
                        original=expected[policy['id']]
                        assert row['policy']==original['policy'] and row['periods']==original['periods'] and row['period_paths']==original['paths']
                        assert len(row['cases'])==original['count'] and row['new_count']==original['new_count']
                        assert maximum==original['max_reserved'] and int(sealed[prefix+'blocked'].sum())==original['conflict_q0']
                        same.append({'id':policy['id'],'旧73三期間四帯金融・経路・回数・新枝数・占有一致':True})
                    rows.append(row)
            eligible,hours=A.eligibility(context)
            reports[period]={'成功':True,'場数':len(context.scenes),'場順':context.sessions,'幅順':list(context.table.widths),'期限順':list(context.table.horizons),
                '対象場':eligible,'対象時間':hours,'出生固定':proof_ref,'rows':rows,'追加なし旧174全pack同体':controls[period],
                '位置づけ':'旧73既使用固定再現' if not new else '追加7既使用参考、独立未見ではない。'}
            A.save(HERE/(period+'の全取得177.json.gz'),reports[period])
    # ----------------------------------------
    all_eligible={n:reports['旧73']['対象場'][n]+reports['追加7']['対象場'][n] for n in ('DAY','PRE','POST')}
    all_hours={n:reports['旧73']['対象時間'][n]+reports['追加7']['対象時間'][n] for n in ('DAY','PRE','POST')}
    assert not set(reports['旧73']['場順'])&set(reports['追加7']['場順']);joined_rows=[]
    for old,added in zip(reports['旧73']['rows'],reports['追加7']['rows'],strict=True):
        assert old['id']==added['id'];joined={k:old['ledger'][k]+added['ledger'][k] for k in ('net','known','label','scene')}
        phases=old['phases']+added['phases'];origins=old['origins']+added['origins'];new_flags=old['added']+added['added']
        financial=B.metrics173.evaluate_metrics(joined['net'],joined['known'],joined['label'],joined['scene'],phases,origins,all_eligible,all_hours)
        joined_rows.append({'id':old['id'],'policy':old['policy'],'financial':financial,'paths':A.paths(financial),
            'ledger':joined,'phases':phases,'origins':origins,'added':new_flags,'new_count':sum(new_flags),
            'old_main_count':old['old_main_count']+added['old_main_count'],'fallback_count':old['fallback_count']+added['fallback_count'],
            '旧73':old['financial'],'追加7':added['financial']})
    assert len(reports['旧73']['場順'])+len(reports['追加7']['場順'])==80
    A.save(HERE/'全80の両中央値177.json.gz',{'成功':True,'場数':80,'対象場':all_eligible,'対象時間':all_hours,'rows':joined_rows,
        '注意':'全80既使用。前48の後25悪化・0取引場・未知Noneを保持。新枝はactive[実取得event]で数え、financial originsは旧0/2のまま。'})
    assert A.physical(OLD_REPORT)==expected_ref and A.physical(HERE/'金融前の出生固定.json')==proof_ref
    assert A.physical(PARENT/'出生と比較正本.zip')==parent_ref['archive']
    assert all(A.physical(ROOT/name)==value for name,value in before.items())
    assert all(A.physical(ROOT/name)==value for name,value in proof['非金融入力'].items())
    A.save(HERE/'完了.json',{'成功':True,'Sourceと固定選択':before,'出生固定':proof_ref,'旧金融report':expected_ref,'174正式幹':parent_ref,
        '旧73同体':same,'追加なし旧174四対照全pack同体':controls,'金融後Source変更なし':True,'固定候補再選択なし':True,
        'files':{p.name:A.physical(p) for p in HERE.iterdir() if p.is_file() and p.name!='完了.json'}})
    print(json.dumps({'成功':True,'旧73同体':len(same),'noadd四対照':{k:len(v) for k,v in controls.items()},
        '取得':{name:{r['id']:{'全取得':len(r['cases']),'新枝':r['new_count']} for r in report['rows']} for name,report in reports.items()}},ensure_ascii=False))


def main() -> None:
    """
    機能: RootのGOと固定SHAが明示されたときだけ参考適用する。
    引数: --expected-sha(str)、--execute(bool)。
    返り値: None。金融後にSourceを変更しない。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--expected-sha',required=True);parser.add_argument('--execute',action='store_true',required=True)
    args=parser.parse_args();run(args.expected_sha)


if __name__=='__main__':main()
