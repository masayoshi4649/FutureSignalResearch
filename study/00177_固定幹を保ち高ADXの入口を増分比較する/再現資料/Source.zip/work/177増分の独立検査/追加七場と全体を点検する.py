"""177固定四案の旧73・追加7・全80を、台帳から独立金融へ照合する。"""
from pathlib import Path
from io import BytesIO
import gzip
import importlib.util
import json
import sys
import zipfile
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
PACK=ROOT/'work/177追加七場適用'


def module(path: Path, name: str) -> object:
    """
    機能: 主処理を開始せず既存検査部品を読む。
    引数: path(Path)、name(str)。
    返り値: objectは読み込んだ部品。
    """
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec)
    sys.modules[name]=value;spec.loader.exec_module(value);return value


N=module(HERE/'増分と選択を点検する.py','increment177_fixed_verify')
Q=N.Q;V=N.V;F=N.F


def shared_value(context: object, row: dict, counters: dict) -> tuple:
    """
    機能: 取得の添字・幅期限から共用金融とq0帯を確認し、再生結果形式へ写す。
    引数: context(object)、row(dict)、counters(dict)。
    返り値: tupleはSelection/origin/wi/hi/tier/engine。金融や取得を改変しない。
    """
    names=('cases','sides','events','phases','origins','widths','horizons','tiers')
    count=len(row['cases']);assert all(len(row[name])==count for name in names)
    cases,sides,events,wi,hi=[np.asarray(row[name],dtype=np.int32) for name in ('cases','sides','events','widths','horizons')]
    key=(cases,sides,wi,hi);known=context.arrays['known'][key]
    expected={'net':[float(n) if k else None for n,k in zip(context.arrays['net'][key],known,strict=True)],
        'known':known.tolist(),'label':context.arrays['label'][key].tolist(),
        'scene':[context.sessions[int(i)] for i in context.case_scene[cases]]}
    V.compare(expected,row['ledger'],row['id']+'/共用金融',counters)
    V.compare(context.event_phases[events].tolist(),row['phases'],row['id']+'/q0帯',counters)
    assert len(row['engine']['records'])==count
    for i,record in enumerate(row['engine']['records']):
        V.compare({'event':int(events[i]),'case':int(cases[i]),'side':int(sides[i]),
            'width':int(context.table.widths[wi[i]]),'origin':row['origins'][i],'tier':row['tiers'][i]},
            record,row['id']+'/取得/'+str(i),counters)
    counters['shared_ledger']+=count
    selected=type('取得列',(),{})();selected.cases=cases;selected.sides=sides;selected.events=events
    selected.phases=np.asarray(row['phases'],dtype=np.int8)
    return selected,np.asarray(row['origins'],dtype=np.int8),wi,hi,np.asarray(row['tiers'],dtype=np.int8),row['engine']


def branch_counts(row: dict) -> dict:
    """
    機能: addedと旧originを混同せず、旧主・新枝・初参加Tの取得数を確認する。
    引数: row(dict)は台帳とadded/originsを持つpack。
    返り値: dictは三内訳。
    """
    assert len(row['added'])==len(row['origins'])==len(row['ledger']['net'])
    assert all(type(v) is bool for v in row['added'])
    assert not any(added and origin==2 for added,origin in zip(row['added'],row['origins'],strict=True))
    values={'new_count':sum(row['added']),
        'old_main_count':sum(not added and origin==0 for added,origin in zip(row['added'],row['origins'],strict=True)),
        'fallback_count':sum(origin==2 for origin in row['origins'])}
    assert all(row[key]==value for key,value in values.items())
    assert sum(values.values())==len(row['ledger']['net'])
    return values


def main() -> None:
    """
    機能: Root固定四案の旧73・追加7・全80を独立検算し、追加悪化と重複を保存する。
    引数: なし。自然金融の閲覧GO済み。
    返り値: None。担当workへ検査票だけを保存し、戦略・固定票は変更しない。
    """
    files=[PACK/(name+'.json.gz') for name in ('旧73の全取得177','追加7の全取得177','全80の両中央値177')]
    fixed_path=ROOT/'work/177高ADX枝の増分比較/旧73の固定選択.json'
    files += [fixed_path,PACK/'金融前の出生固定.json',PACK/'完了.json',PACK/'固定政策を適用する.py',
        PACK/'旧73の純出生177.npz',PACK/'追加7の純出生177.npz',Path(__file__),HERE/'増分と選択を点検する.py']
    before=[V.fingerprint(path) for path in files]
    fixed=V.read(fixed_path);expected_sha='8d9eb4bbe3830c3b504b72854330394699f3f970623855d44777ecb4155f89b5'
    assert V.fingerprint(fixed_path)['sha256']==expected_sha
    ids=[p['id'] for route in ('全期','前48') for p in fixed['選択'][route]['candidates']]
    bodies={name:V.read(path) for name,path in zip(('旧73','追加7','全80'),files[:3])}
    assert all(body['成功'] and [row['id'] for row in body['rows']]==ids for body in bodies.values())
    by_id={name:{row['id']:row for row in body['rows']} for name,body in bodies.items()}
    sys.path.insert(0,str(ROOT/'work/173両中央値と単一建玉'));import 基盤173 as B
    counters={'scalar':0,'financial_group':0,'full_risk':0,'replayed_financial_group':0,'request_capacity_checked':0,
        'shared_ledger':0,'period_compact':0,'added_flags':0,'additional_174_controls':0}
    independent={};periods={};branch_summary={}
    parent=ROOT/'study/00174_共同条件を残して単一建玉の入口を広げる/再現資料'
    parent_index=V.read(parent/'保存索引.json');parent_archive=parent/'出生と比較正本.zip'
    assert V.fingerprint(parent_archive)==parent_index['正本']['archive']
    index_members={r['path']:r for r in parent_index['正本']['members']}
    for new,name in ((False,'旧73'),(True,'追加7')):
        context=B.load_context(new);body=bodies[name]
        eligible,hours=Q.eligibility(context,np.ones(len(context.scenes),bool))
        assert context.sessions==body['場順'] and len(context.scenes)==body['場数']
        V.compare(eligible,body['対象場'],name+'/対象場',counters);V.compare(hours,body['対象時間'],name+'/時間',counters)
        independent[name]={};periods[name]={};branch_summary[name]={}
        with np.load(PACK/(name+'の純出生177.npz'),allow_pickle=False) as sealed:
            assert np.array_equal(sealed['phases'],context.event_phases)
            for row in body['rows']:
                where=name+'/'+row['id'];value=shared_value(context,row,counters)
                groups=F.financial_groups(row,eligible,hours);independent[name][row['id']]=groups
                Q.check_groups(groups,row['financial'],row['paths'],where,counters)
                amended={**row,'count':len(row['cases']),'max_reserved':max(a['peak_global_reserved'] for a in row['engine']['audits'])}
                periods[name][row['id']]=N.replay_groups(context,value,amended,counters)
                for period,values in periods[name][row['id']].items():
                    for band in ('DAY','PRE','POST','NIGHT'):
                        saved=row['period_paths'][period][band]
                        V.compare(V.independent_risk(values[band]),{k:v for k,v in saved.items() if k not in ('version','notes')},
                            where+'/'+period+'/'+band+'/小型経路',counters);counters['period_compact']+=1
                expected_added=sealed[row['id']+'__active'][np.asarray(row['events'])].tolist()
                V.compare(expected_added,row['added'],where+'/新枝実取得flag',counters);counters['added_flags']+=len(expected_added)
                branch_summary[name][row['id']]=branch_counts(row)
        if new:
            with zipfile.ZipFile(parent_archive) as archive:
                base_name='work/174追加七場適用/追加7の純出生174.npz';raw=archive.read(base_name)
                assert index_members[base_name]['sha256']==__import__('hashlib').sha256(raw).hexdigest()
                parent_body=json.loads(gzip.decompress(archive.read('work/174追加七場適用/追加7の全取得174.json.gz')))
                parent_rows={r['id']:r for r in parent_body['rows']}
                with np.load(BytesIO(raw),allow_pickle=False) as bases:
                    for candidate,expected in parent_rows.items():
                        base={key:bases[candidate+'__'+key] for key in ('core','branches','technical','tier','mw','fw','hi')}
                        actual=N.independent_combine(base,context.event_phases,{}, {},list(context.table.horizons))
                        value=B.replay(context,*actual[:4],True)
                        core={'cases':value[0].cases.tolist(),'sides':value[0].sides.tolist(),'events':value[0].events.tolist(),
                            'phases':value[0].phases.tolist(),'origins':value[1].tolist(),'widths':value[2].tolist(),
                            'horizons':value[3].tolist(),'tiers':value[4].tolist(),'engine':value[5]}
                        V.compare(core,{key:expected[key] for key in core},candidate+'/追加7旧174全取得',counters)
                        V.compare(B.financial(context,value),expected['financial'],candidate+'/追加7旧174全金融',counters)
                        counters['additional_174_controls']+=1
        del context
    # ----------------------------------------
    # 全80は再計算した対象場・時間と連結台帳から作り、未知と三内訳も保存値へ照合する。
    old,added,all_body=[bodies[name] for name in ('旧73','追加7','全80')]
    eligible={band:old['対象場'][band]+added['対象場'][band] for band in ('DAY','PRE','POST')}
    hours={band:old['対象時間'][band]+added['対象時間'][band] for band in ('DAY','PRE','POST')}
    assert not set(old['場順'])&set(added['場順'])
    V.compare(eligible,all_body['対象場'],'全80/対象場',counters);V.compare(hours,all_body['対象時間'],'全80/時間',counters)
    assert all_body['場数']==len(old['場順'])+len(added['場順'])==80
    independent['全80']={};branch_summary['全80']={}
    for candidate in ids:
        a,b,row=[by_id[name][candidate] for name in ('旧73','追加7','全80')]
        joined={'ledger':{key:a['ledger'][key]+b['ledger'][key] for key in ('net','known','label','scene')},
            **{key:a[key]+b[key] for key in ('phases','origins','added')}}
        for key in joined:V.compare(joined[key],row[key],'全80/'+candidate+'/'+key,counters)
        groups=F.financial_groups(joined,eligible,hours);independent['全80'][candidate]=groups
        Q.check_groups(groups,row['financial'],row['paths'],'全80/'+candidate,counters)
        assert row['policy']==a['policy']==b['policy']
        V.compare(a['financial'],row['旧73'],'全80/'+candidate+'/旧金融',counters)
        V.compare(b['financial'],row['追加7'],'全80/'+candidate+'/追加金融',counters)
        branch_summary['全80'][candidate]=branch_counts(row)
    assert before==[V.fingerprint(path) for path in files]
    summary={scope:{candidate:{band:Q.brief(groups[band]) for band in ('DAY','PRE','POST','NIGHT','ALL')}
        for candidate,groups in values.items()} for scope,values in independent.items()}
    for period in ('前48','後25'):
        summary[period]={candidate:{band:Q.brief(groups[period][band]) for band in ('DAY','PRE','POST','NIGHT','ALL')}
            for candidate,groups in periods['旧73'].items()}
    paired={scope:{candidate:{**row,'policy':{**row['policy'],'options':{'DAY':[],**row['policy']['options']}}}
        for candidate,row in by_id[scope].items()} for scope in ('旧73','追加7')}
    overlap={route:Q.overlap(paired['旧73'],paired['追加7'],*fixed['選択'][route]['参考候補']) for route in ('全期','前48')}
    result={'成功':True,'固定SHA256':expected_sha,'対象ID':ids,'検査':counters,'不一致':0,'Sourceと入力不変':True,
        '入力':before,'要約':summary,'取得内訳':branch_summary,'近傍重複':overlap,
        '注意':['全80は既使用で独立未見ではない。全期/前48の固定選択を追加7で変更しない。',
            '追加7packの前48/後25はローカル添字で全7/空。旧73の前後差と混同しない。',
            '既知寄与DDを金融未知のある全件DDと呼ばない。DDは場末実現収支であり保有中時価DDではない。']}
    (HERE/'追加七場と全80の独立結果.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps({key:result[key] for key in ('成功','対象ID','検査','不一致','Sourceと入力不変')},ensure_ascii=False))


if __name__=='__main__':main()
