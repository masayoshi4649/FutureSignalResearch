"""177増分の固定条件・全段経路・route選択・旧幹同体を独立検査する。"""
from pathlib import Path
import copy
import importlib.util
import json
import sys

import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
SOURCE=ROOT/'work/177高ADX枝の増分比較'
TRIAL=ROOT/'study/00177_固定幹を保ち高ADXの入口を増分比較する'


def module(path: Path, name: str) -> object:
    """
    機能: mainを起動せず担当検査部品を読む。
    引数: path(Path)、name(str)。
    返り値: objectは読み込んだ部品。
    """
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec)
    sys.modules[name]=value;spec.loader.exec_module(value);return value


V=module(ROOT/'work/175数量結果の独立検査/数量経路を点検する.py','independent175_for177')
Q=module(ROOT/'work/176固定結果の独立検査/固定金融を点検する.py','independent176_for177')
F=Q.F


def independent_combine(base: dict, phases: np.ndarray, options: dict, directions: dict, horizons: list) -> tuple:
    """
    機能: q0を一件ずつ列挙し、旧core→新枝→旧Tの優先順を別実装する。
    引数: base(dict)、phases(np.ndarray)、options/directions(dict)、horizons(list)。
    返り値: tupleはbirth、幅二列、期限、新枝mask、競合mask。
    """
    n=len(phases);birth={name:base[name].copy() for name in ('core','branches','technical','tier')}
    mw,fw,hi=[base[name].copy() for name in ('mw','fw','hi')]
    active=np.zeros(n,bool);blocked=np.zeros(n,bool)
    for index in range(n):
        if base['core'][index]:continue
        band=('DAY','PRE','POST')[int(phases[index])]
        signals=[(rule,int(directions[rule['birth_key']][index]))
            for rule in sorted(options.get(band,[]),key=lambda r:r['id']) if directions[rule['birth_key']][index]]
        if len({side for _,side in signals})>1:
            blocked[index]=True;birth['technical'][index]=0;birth['tier'][index]=0
        elif signals:
            rule,side=signals[0];active[index]=True;birth['core'][index]=side
            mw[index]=fw[index]=rule['width'];hi[index]=horizons.index(rule['horizon'])
    birth['branches']=np.asarray([0 if side else -1 for side in birth['core']],dtype=np.int8)
    return birth,mw,fw,hi,active,blocked


def compare_arrays(first: tuple, second: tuple) -> None:
    """
    機能: 合成結果の全配列を比較する。
    引数: first/second(tuple)は合成出力。
    返り値: None。不一致は例外。
    """
    assert len(first)==len(second)==6
    for key in first[0]:assert np.array_equal(first[0][key],second[0][key]),key
    assert all(np.array_equal(a,b) for a,b in zip(first[1:],second[1:],strict=True))


def joint_key(row: dict, route: str) -> tuple:
    """
    機能: F0で公表した共同条件・支持・経路の辞書順を別実装する。
    引数: row(dict)は政策、route(str)は全期又は前48だけ。
    返り値: tupleは昇順順位。
    """
    g=row['periods'][route];p=row['paths'][route]
    dual=all(g[band]['decision']['status']=='適合' for band in ('DAY','NIGHT'))
    full=sum(p[band]['support']['zero_scene_count'] for band in ('DAY','NIGHT'))==0
    support=True
    for band in ('DAY','NIGHT'):
        t=g[band]['trades'];fa=t['IFD_FIRSTFANC']
        support &= t['all_count']>=24 and fa['reached_count']>=12 and g[band]['resolved_scene_count']>=6
        support &= (fa['first_f_rate_reached'] or 0)>=.7
    unknown=max((g[b]['trades']['unknown_count']/g[b]['trades']['all_count'] if g[b]['trades']['all_count'] else 1) for b in ('DAY','NIGHT'))
    windows=[w['negative_net_share_complete'] for b in ('DAY','NIGHT') for w in p[b]['windows'].values() if w['complete_window_count']]
    burdens=[p[b]['known_drawdown_to_known_profit'] for b in ('DAY','NIGHT')]
    return (-int(dual and full and support),-int(dual and full),-p['POST']['support']['participating_scene_count'],
        unknown,max(windows,default=1),max(float('inf') if v is None else v for v in burdens),
        -sum(g[b]['trades']['known_net'] for b in ('DAY','NIGHT')),row['id'])


def replay_groups(context: object, value: tuple, row: dict, counters: dict) -> dict:
    """
    機能: 固定政策の再取得を独立金融へ渡し、三期間四帯の保存値と照合する。
    引数: context(object)、value(tuple)、row(dict)、counters(dict)。
    返り値: dictは三期間の独立五群。
    """
    selected,origins,wi,hi,_,engine=value;key=(selected.cases,selected.sides,wi,hi);known=context.arrays['known'][key]
    pack={'ledger':{'net':[float(n) if k else None for n,k in zip(context.arrays['net'][key],known,strict=True)],
        'known':known.tolist(),'label':context.arrays['label'][key].tolist(),
        'scene':[context.sessions[int(i)] for i in context.case_scene[selected.cases]]},
        'phases':selected.phases.tolist(),'origins':origins.tolist()}
    records=F.normalize(pack);scene_index={scene:i for i,scene in enumerate(context.sessions)};output={}
    assert engine['capacity']==1 and engine['contracts_per_request']==1
    assert all(a['peak_global_reserved']<=1 and a['peak_global_pending']<=1 and a['peak_global_held']<=1 for a in engine['audits'])
    assert all(not (r['accepted'] and r['held_total_before']+r['pending_total_before']) for r in engine['requests'])
    assert len(selected.cases)==row['count'];assert max(a['peak_global_reserved'] for a in engine['audits'])==row['max_reserved']
    counters['request_capacity_checked']+=len(engine['requests'])
    for name,predicate in [('全期',lambda i:True),('前48',lambda i:i<48),('後25',lambda i:i>=48)]:
        mask=np.asarray([predicate(i) for i in range(len(context.sessions))],dtype=bool)
        eligible,hours=Q.eligibility(context,mask)
        indices=[i for i,r in enumerate(records) if predicate(scene_index[r['scene']])]
        subset={'ledger':{name:[values[i] for i in indices] for name,values in pack['ledger'].items()},
            'phases':[pack['phases'][i] for i in indices],'origins':[pack['origins'][i] for i in indices]}
        groups=F.financial_groups(subset,eligible,hours);output[name]=groups
        selected_records=[records[i] for i in indices]
        for band in ('DAY','PRE','POST','NIGHT'):
            group=copy.deepcopy(groups[band]);group.pop('origins');group.pop('concentration')
            resolved=[r for r in selected_records if r['label'] in ('F','A') and (r['phase'] in ('PRE','POST') if band=='NIGHT' else r['phase']==band)]
            counts={scene:sum(r['scene']==scene for r in resolved) for scene in context.sessions}
            group.update({'resolved_scene_count':sum(v>0 for v in counts.values()),'max_resolved_scene_count':max(counts.values(),default=0)})
            V.compare(group,row['periods'][name][band],row['id']+'/'+name+'/'+band+'/再金融',counters)
            counters['replayed_financial_group']+=1
    return output


def main() -> None:
    """
    機能: 177の固定結果をRootのGO後に独立検査する。
    引数: なし。
    返り値: None。担当workへ検査JSONだけを保存し、戦略Sourceや固定票は変更しない。
    """
    sys.path.insert(0,str(SOURCE));M=module(SOURCE/'増分177.py','increment177_independent_review')
    paths=[TRIAL/'条件.json',SOURCE/'増分177.py',SOURCE/'純出生177.npz',SOURCE/'純出生177.json',
        SOURCE/'予備統計177.npz',SOURCE/'予備短表177.json',SOURCE/'旧四対照の同体.json',
        SOURCE/'単独短表.json',SOURCE/'帯短表.json',SOURCE/'旧73の固定選択.json',Path(__file__)]
    paths += [SOURCE/(name+'.json.gz') for name in ('増分単独','増分二枝','三帯接合')]
    f0=V.read(TRIAL/'条件.json')
    paths += [ROOT/r['path'] for r in f0['Source']]
    paths=list(dict.fromkeys(paths));before=[V.fingerprint(path) for path in paths]
    assert f0['試行']==177 and f0['GO'] and f0['人工検査']==M.artificial()
    for expected in f0['Source']:assert expected==V.fingerprint(ROOT/expected['path'])
    birth_proof=V.read(SOURCE/'純出生177.json');assert birth_proof['金融未入力']
    assert birth_proof['F0SHA256']==V.fingerprint(TRIAL/'条件.json')['sha256']
    assert birth_proof['出生SHA256']==V.fingerprint(SOURCE/'純出生177.npz')['sha256']
    counters={'scalar':0,'path_group':0,'compact_key':0,'shortlist':0,'period_guard':0,
        'source_policy_list':0,'old_controls':0,'fixed_replays':0,'replayed_financial_group':0,'request_capacity_checked':0,'natural_combine':0}
    sizes={};all_rows={};day_by_base={};selected={}
    for name in ('増分単独','増分二枝','三帯接合'):
        rows=V.read(SOURCE/(name+'.json.gz'))['rows'];all_rows[name]=rows;sizes[name]=len(rows)
        sealed=V.read(TRIAL/'検査'/('F2_'+name+'.json'))
        assert sealed['成功'] and sealed['追加7未読'] and sealed['SourceSHA256']==V.fingerprint(SOURCE/'増分177.py')['sha256']
        V.compare(sealed['policies'],[row['policy'] for row in rows],name+'/F2政策列',counters);counters['source_policy_list']+=1
        assert len({row['id'] for row in rows})==len(rows)
        for row in rows:
            policy=row['policy'];assert policy['route'] in ('全期','前48') and set(policy['options'])<= {'PRE','POST'}
            assert row['max_reserved']<=1
            if policy['base'] not in day_by_base:day_by_base[policy['base']]={period:groups['DAY'] for period,groups in row['periods'].items()}
            V.compare(day_by_base[policy['base']],{period:groups['DAY'] for period,groups in row['periods'].items()},row['id']+'/全段Day同体',counters)
            for period,groups in row['periods'].items():
                for band,group in groups.items():
                    saved=row['paths'][period][band]
                    V.compare(V.independent_risk(group),{k:v for k,v in saved.items() if k not in ('version','notes')},row['id']+'/'+period+'/'+band,counters)
                    full=M.STAGE.RISK.path_summary(group)
                    assert M.STAGE.compact_risk(full)==saved
                    assert M.STAGE.RISK.candidate_key(group,full,band)==M.STAGE.RISK.candidate_key(group,saved,band)
                    counters['path_group']+=1;counters['compact_key']+=1
        if name=='三帯接合':continue
        short=V.read(SOURCE/('単独短表.json' if name=='増分単独' else '帯短表.json'))['選択']
        for base,bands in short.items():
            route='全期' if base.startswith('全期') else '前48'
            for band,wanted in bands.items():
                subset=[r for r in rows if r['policy']['base']==base and band in r['policy']['options']]
                actual=M.rank(subset,route,band)
                assert [r['policy'] for r in actual]==wanted
                guarded=[{**r,'periods':V.OnlyPeriod({route:r['periods'][route]}),'paths':V.OnlyPeriod({route:r['paths'][route]})} for r in subset]
                assert [r['id'] for r in M.rank(guarded,route,band)]==[r['id'] for r in actual]
                counters['shortlist']+=1;counters['period_guard']+=1
    # ----------------------------------------
    # 最終順位はSourceの内側関数を使わず、固定した公開辞書順から再計算する。
    fixed=V.read(SOURCE/'旧73の固定選択.json');assert fixed['追加7当該候補金融未読']
    for route in ('全期','前48'):
        rows=[row for row in all_rows['三帯接合'] if row['policy']['route']==route]
        ordered=sorted(rows,key=lambda row:joint_key(row,route));eligible=[r for r in ordered if joint_key(r,route)[0]==-1]
        expected=fixed['選択'][route]
        assert len(eligible)==expected['共同適合数']=={'全期':72,'前48':28}[route]
        assert expected['主案']==eligible[0]['id']
        assert expected['参考候補']==[r['id'] for r in ordered[:2]]
        assert expected['candidates']==[r['policy'] for r in ordered[:2]]
        guarded=[{**r,'periods':V.OnlyPeriod({route:r['periods'][route]}),'paths':V.OnlyPeriod({route:r['paths'][route]})} for r in rows]
        assert [r['id'] for r in sorted(guarded,key=lambda r:joint_key(r,route))]==[r['id'] for r in ordered]
        counters['period_guard']+=1;selected[route]={'主案':expected['主案'],'共同適合':len(eligible),'参照':expected['参考候補']}
    # ----------------------------------------
    # 旧四対照と固定四案だけを共用時計で再生し、全金融と全取得・監査を照合する。
    M.initialize();context=M.CTX;expected={r['id']:r for r in V.read(M.PARENT/'旧73の全取得174.json.gz')['rows']}
    M.artificial();natural_checks=[];fixed_groups={}
    for name,base in M.BASES.items():
        independent=independent_combine(base,context.event_phases,{},M.DIRS,list(context.table.horizons))
        actual=M.combine(base,context.event_phases,{},M.DIRS,list(context.table.horizons));compare_arrays(independent,actual)
        value=M.B.replay(context,*actual[:4],True,M.CAPS);record=expected[name]
        packed={'cases':value[0].cases.tolist(),'sides':value[0].sides.tolist(),'events':value[0].events.tolist(),
            'phases':value[0].phases.tolist(),'origins':value[1].tolist(),'widths':value[2].tolist(),
            'horizons':value[3].tolist(),'tiers':value[4].tolist(),'engine':value[5]}
        V.compare(packed,{key:record[key] for key in packed},name+'/174対照取得',counters)
        V.compare(M.B.financial(context,value),record['financial'],name+'/174対照金融',counters)
        counters['old_controls']+=1;counters['natural_combine']+=1
    id_map={row['id']:row for row in all_rows['三帯接合']}
    for route,choice in fixed['選択'].items():
        for policy in choice['candidates']:
            base=M.BASES[policy['base']];actual=M.combine(base,context.event_phases,policy['options'],M.DIRS,list(context.table.horizons))
            compare_arrays(independent_combine(base,context.event_phases,policy['options'],M.DIRS,list(context.table.horizons)),actual)
            birth,mw,fw,hi,active,blocked=actual
            day=context.event_phases==0
            assert not active[day].any() and not blocked[day].any()
            for key in birth:assert np.array_equal(birth[key][day],base[key][day]),(policy['id'],key,'Day出生')
            for key,array in [('mw',mw),('fw',fw),('hi',hi)]:assert np.array_equal(array[day],base[key][day])
            value=M.B.replay(context,birth,mw,fw,hi,True,M.CAPS);row=id_map[policy['id']]
            assert int(active[value[0].events].sum())==row['new_count'] and int(blocked.sum())==row['conflict_q0']
            groups=replay_groups(context,value,row,counters);fixed_groups[policy['id']]=groups
            events=value[0].events;is_day=value[0].phases==0;record=expected[policy['base']];base_day=np.asarray(record['phases'])==0
            for key,values in [('cases',value[0].cases),('sides',value[0].sides),('events',events),('origins',value[1]),('widths',value[2]),('horizons',value[3]),('tiers',value[4])]:
                assert values[is_day].tolist()==np.asarray(record[key])[base_day].tolist(),(policy['id'],key,'Day取得')
            natural_checks.append({'id':policy['id'],'取得':row['count'],'新枝取得':row['new_count'],'Day出生と取得同体':True,
                '全合成配列独立一致':True,'金融全期間一致':True,'global1とpending1':True})
            counters['fixed_replays']+=1;counters['natural_combine']+=1
    assert before==[V.fingerprint(path) for path in paths]
    result={'成功':True,'F0':V.fingerprint(TRIAL/'条件.json'),'固定票':V.fingerprint(SOURCE/'旧73の固定選択.json'),
        '対象':sizes,'検査':counters,'不一致':0,'Sourceと入力不変':True,'入力':before,'固定選択':selected,'固定再生':natural_checks,
        '固定案要約':{candidate:{period:{band:Q.brief(groups[band]) for band in ('DAY','PRE','POST','NIGHT','ALL')}
            for period,groups in periods.items()} for candidate,periods in fixed_groups.items()},
        '範囲':['三数量段階の全保存場行から経路・支持を別集計。固定八再生は共用engine/共用時計を使用し、金融集計と合成は独立実装。',
            '予備統計の全16指標そのものの独立再算出や、engineの独立実装は本票の対象外。',
            '追加7はこの検査では入力・再生しない。全期発見と前48選択を区別し、既使用結果を未見評価と呼ばない。']}
    target=HERE/'増分177の独立結果.json';target.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps({key:result[key] for key in ('成功','対象','検査','不一致','Sourceと入力不変','固定選択')},ensure_ascii=False))


if __name__=='__main__':main()
