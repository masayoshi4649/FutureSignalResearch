"""177候補別16CSVを、独立台帳集計と型付き中間へ読取専用で照合する。"""
from pathlib import Path
import csv
import importlib.util
import json
import math
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
OUTPUT=ROOT/'outputs/00177_高ADX枝の増分比較'
TYPED=ROOT/'work/177候補別CSV/型付き入力.json'
PACK=ROOT/'work/177追加七場適用/全80の両中央値177.json.gz'
SESSION_COLUMNS=['候補','選択範囲','セッション日','セッションID','利益円_既知','損失円_既知','収支円_全件確定','収支円_既知分',
    '累計収支円_全件確定','累計収支円_既知分','取得回数','旧主取得','新枝取得','初参加T取得','F','A','N','C','金融未知件数','累計金融未知件数','取引なし理由']
SUMMARY_COLUMNS=['候補','選択範囲','区分','対象場数','取得場数','取得回数','旧主取得','新枝取得','初参加T取得',
    'F','A','N','C','金融未知件数','先着率','既知利益円','既知損失円','既知収支円','利益損失比',
    '建玉中央値下限円','建玉中央値上限円','場中央値下限円','場中央値上限円','完全場数','両中央値判定','取得毎時','全件確定収支円']


def module(path: Path, name: str) -> object:
    """
    機能: 主処理を起動せず独立金融部品を読む。
    引数: path(Path)、name(str)。
    返り値: objectは読み込んだ部品。
    """
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec)
    sys.modules[name]=value;spec.loader.exec_module(value);return value


Q=module(ROOT/'work/176固定結果の独立検査/固定金融を点検する.py','financial176_csv177')
V=Q.V;F=Q.F


def compare_csv(path: Path, columns: list, expected: list, counter: dict) -> None:
    """
    機能: CSVの全セルを文字・数値・未知空欄の型に応じて独立値へ照合する。
    引数: path(Path)、columns(list[str])、expected(list[list])、counter(dict)。
    返り値: None。CSVは変更しない。
    """
    with path.open(encoding='utf-8-sig',newline='') as stream:rows=list(csv.reader(stream))
    assert rows[0]==columns and len(rows)-1==len(expected),(path,'列又は行数')
    for index,(actual,wanted) in enumerate(zip(rows[1:],expected,strict=True)):
        assert len(actual)==len(wanted)==len(columns)
        for column,(text,value) in enumerate(zip(actual,wanted,strict=True)):
            where=(path.as_posix(),index+2,columns[column])
            if value is None:assert text=='',(where,'未知空欄',text)
            elif isinstance(value,str):assert text==value,(where,value,text)
            elif type(value) is int:assert text and float(text)==value,(where,value,text)
            else:assert text and math.isclose(float(text),value,rel_tol=1e-12,abs_tol=1e-8),(where,value,text)
            counter['cells']+=1
    counter['files']+=1;counter['rows']+=len(expected)


def independent_tables(row: dict, eligible: dict, hours: dict) -> dict:
    """
    機能: 全80台帳から候補単独の集計表と各40場のCSV行を独立生成する。
    引数: row(dict)、eligible/hours(dict)。
    返り値: dict[str,list[list]]は比較用の値のみ。ファイルは生成しない。
    """
    records=F.normalize(row);groups=F.financial_groups(row,eligible,hours)
    for index,record in enumerate(records):record['added']=row['added'][index]
    identity='177:'+row['id'];route=row['policy']['route'];result={'候補比較':[]}
    for band in ('DAY','NIGHT','PRE','POST'):
        group=groups[band];trade=group['trades'];session=group['sessions'];fa=trade['IFD_FIRSTFANC']
        selected=[r for r in records if (r['phase'] in ('PRE','POST') if band=='NIGHT' else r['phase']==band)]
        old=sum(r['origin']=='主' and not r['added'] for r in selected);new=sum(r['added'] for r in selected)
        fallback=sum(r['origin']=='補完' for r in selected)
        result['候補比較'].append([identity,route,band,session['eligible_count'],session['participating_count'],len(selected),
            old,new,fallback,*[fa[key] for key in ('F','A','N','C')],trade['unknown_count'],fa['first_f_rate_reached'],
            trade['known_profit'],trade['known_loss'],trade['known_net'],trade['known_profit']/trade['known_loss'] if trade['known_loss'] else None,
            trade['net_median']['lower'],trade['net_median']['upper'],session['net_median']['lower'],session['net_median']['upper'],
            session['complete_count'],group['decision']['status'],group['acquisitions_per_hour'],trade['known_net'] if not trade['unknown_count'] else None])
    for band,name in [('DAY','デイ'),('PRE','ナイト_米前'),('POST','ナイト_米後')]:
        rows=[];cumulative=0.0;unknown=0
        for scene in sorted(eligible[band]):
            selected=[r for r in records if r['scene']==scene and r['phase']==band]
            known=[r['net'] for r in selected if r['known']];missing=sum(not r['known'] for r in selected)
            profit=sum(max(0,value) for value in known);loss=sum(-min(0,value) for value in known);net=sum(known)
            cumulative+=net;unknown+=missing
            old=sum(r['origin']=='主' and not r['added'] for r in selected);new=sum(r['added'] for r in selected)
            fallback=sum(r['origin']=='補完' for r in selected)
            labels=[sum(r['label']==label for r in selected) for label in ('F','A','N','C')]
            reason='' if selected else '当該小帯で取得なし。Night全体の参加・技術成立/保有/失効は報告の原因診断を参照。'
            rows.append([identity,route,scene[:10],scene,profit,loss,None if missing else net,net,
                None if unknown else cumulative,cumulative,len(selected),old,new,fallback,*labels,missing,unknown,reason])
        assert len(rows)==40;result[name]=rows
    return result


def main() -> None:
    """
    機能: 4候補×4CSVと型付き入力を独立台帳集計へ照合する。
    引数: なし。
    返り値: None。CSVは読取のみ、検査票JSONだけ担当workへ保存する。
    """
    files=[PACK,TYPED,*sorted(OUTPUT.rglob('*.csv')),Path(__file__)]
    assert len(files)==19
    before=[V.fingerprint(path) for path in files];body=V.read(PACK);typed=V.read(TYPED)
    assert typed['trial']==177 and typed['inputs']==[V.fingerprint(PACK)]
    assert typed['tables']['候補比較']['headers']==SUMMARY_COLUMNS
    assert all(typed['tables'][name]['headers']==SESSION_COLUMNS for name in ('デイ','ナイト_米前','ナイト_米後'))
    counters={'scalar':0,'files':0,'rows':0,'cells':0,'typed_tables':0};actual_files=set()
    for row in body['rows']:
        identity='177:'+row['id'];tables=independent_tables(row,body['対象場'],body['対象時間'])
        for name,wanted in tables.items():
            selected=[values for values in typed['tables'][name]['rows'] if values[0]==identity]
            V.compare(wanted,selected,row['id']+'/'+name+'/型付き入力',counters);counters['typed_tables']+=1
            path=OUTPUT/('177_'+row['id'])/('集計.csv' if name=='候補比較' else name+'.csv')
            compare_csv(path,SUMMARY_COLUMNS if name=='候補比較' else SESSION_COLUMNS,wanted,counters);actual_files.add(path)
    assert actual_files==set(OUTPUT.rglob('*.csv')) and counters['files']==16
    assert before==[V.fingerprint(path) for path in files]
    result={'成功':True,'不一致':0,'検査':counters,'CSVと入力不変':True,'入力':before,
        '方法':'CSV/型付き入力を全80台帳の独立金融・場別直接一覧へ全セル照合。未知空欄、全40場、累計、旧主/新枝/T内訳を検査。CSVを作成/編集しない。'}
    (HERE/'候補別CSVの独立結果.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps({key:result[key] for key in ('成功','不一致','検査','CSVと入力不変')},ensure_ascii=False))


if __name__=='__main__':main()
