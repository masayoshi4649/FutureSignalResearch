# 177固定四案の追加七場参考適用

RootのGOと固定票SHA256を受け、全期J002J000/J003J000・前48J000J005/J000J013の四案だけを適用する。追加期で候補を選び直さない。前48選択後の後25悪化も保持する。

旧幹は174正式小正本ZIPの純出生元byteを正式索引・物理SHAへ照合して継承する。177新枝は必要rule_idだけを純builderで再生成し、旧73の元純出生と一致確認する。mode/ADXゲートは既適用、birth_keyの正逆を一回だけ適用する。

旧73・追加7の新枝と幹の合成を金融前に封印してから、`B.replay(..., fallback=True)` へ渡す。旧core優先・新枝・旧Tの順とデイT遅延を177 Sourceのcombineに従って維持する。追加なしの174四対照は両期間で全pack同体を確認する。

packは176共通schemaに `added` bool配列（`active[selected.events]`）、`new_count`、`old_main_count`、`fallback_count` を付ける。金融の `origins` は旧0/2のままであり、新枝取得は別flagで判別する。全80でも台帳・origins・addedを連結し、対象場/時間を足し合わせて両中央値とpath175全診断を再計算する。未知Noneと0取引場を保持する。

```powershell
& 'work/複合テクニカル学習環境/Scripts/python.exe' 'work/177追加七場適用/固定政策を適用する.py' --expected-sha '<固定票SHA256>' --execute
```

追加七場は既使用の参考適用であり、独立未見性能とは呼ばない。Sourceと固定入力の指紋を実行前後で照合し、金融後にSourceを変更しない。
