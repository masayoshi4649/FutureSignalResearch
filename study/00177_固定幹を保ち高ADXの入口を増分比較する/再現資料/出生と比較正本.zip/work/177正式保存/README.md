# 177の薄いSource継承と正式固定再現

176正式Source.zipを元byte・全member指紋へ照合し、その上へ177の新Sourceだけを復元する。177 Source.zipには176の重複Sourceを入れず、継承元のZIP・索引・全memberの指紋参照を収録する。

小正本には177辞書・純出生・予備短表・全数量段階・固定四案旧/追加pack・全80・経路・独立検査・CSV型付き入力/作成票/案内を入れる。CSV本文16ファイルはoutputs正本を指紋参照し、ZIPへ二重保存しない。共用CSV出力器 `scripts/損益CSV/候補別に出力する.mjs` は新Sourceへ明示収録する。予備統計NPZは再生成中間としてSHA/理由を残す。

177runnerは正式148を固定151/161 Sourceでキャッシュ無し射影し、共有163/167へ接続する。174旧/追加の純出生と全四対照packは、174正式小正本から必要memberだけ元byte継承する。全四対照の追加なし全pack、177固定四案の両期間純出生・全pack・added・origins・金融・経路、全80全行/対象場/時間を照合する。

原板・元work・feature cache読込と共有inputs/study書込を監査で拒否する。必要環境はPython 3.14.3、NumPy 2.5.4、tzdata 2026.6。177は有望な増分候補だが、追加期Nightと前48後25の悪化を保持し、安定採用とは扱わない。178は別試行で混在させない。

保存前の隔離確認は成功した。177固定4×旧追加の8候補期間、174no-add四対照×2の8照合、全80全行と対象metadataが一致し、禁止参照0。

```powershell
& 'work/複合テクニカル学習環境/Scripts/python.exe' 'work/177正式保存/保存177.py' --prepare
& 'work/複合テクニカル学習環境/Scripts/python.exe' 'work/177正式保存/隔離を準備する.py'
```

正式保存はRoot最終GO後に `保存177.py --execute --go`。既存ZIP・隔離先は上書きしない。
