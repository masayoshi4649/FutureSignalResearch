"""TOPIXの既存原順キャッシュを照合し、未作成場だけ同一パーサで生成する。"""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
import hashlib
import importlib.util
import json
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).parent
DATA=ROOT.parent/'JP_OSE_Data/future'


def module():
    """
    機能: 固定済み8列キャッシュ生成器を読み込む。
    引数: なし。
    返り値: moduleは元パーサ。
    """
    path=ROOT/'scripts/複合検証/データ準備.py'
    spec=importlib.util.spec_from_file_location('topix183準備',path)
    value=importlib.util.module_from_spec(spec);sys.modules[spec.name]=value;spec.loader.exec_module(value)
    return value


def one(job):
    """
    機能: 原板を指紋で照合し、同体の旧cacheを再用又は未収録場を生成する。
    引数: job(tuple[str,dict|None])は場と旧台帳。
    返り値: dictは由来とキャッシュ参照。旧資料を変更しない。
    """
    session,old=job;p=module();source=DATA/'TOPIX'/session/'book.jsonl'
    if old is not None:
        cache=ROOT/'work/複合検証'/old['cache_path']
        current=p.hash_file(source)
        assert current==old['sha256_uncompressed'],session
        assert p.hash_file(cache)==old['sha256_cache'],session
        result=dict(old);result['cache_absolute']=str(cache);result['再用']=True
    else:
        cache=HERE/'生成入力'/f'{session}.npz'
        saved=HERE/'生成入力'/f'{session}.json'
        if saved.exists():
            result=json.loads(saved.read_text(encoding='utf-8'))
            assert p.hash_file(source)==result['sha256_uncompressed']
            assert p.hash_file(cache)==result['sha256_cache']
        else:
            result=p.build_one(source,cache,'TOPIX',session,DATA)
            saved.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        result['cache_absolute']=str(cache);result['再用']=False
    result['current_raw']={'path':str(source),'bytes':source.stat().st_size,'sha256':result['sha256_uncompressed']}
    assert len(result['in_session_contract_codes'])==1
    return result


def main():
    """
    機能: 現在存在する81完了場の原板とcacheを固定する。
    引数: なし。
    返り値: None。入力台帳と進捗を出力する。
    """
    HERE.mkdir(parents=True,exist_ok=True)
    old=json.loads((ROOT/'work/TOPIX補助/00044/入力台帳.json').read_text(encoding='utf-8'))
    entries={x['session']:x for x in old['entries']}
    scenes=sorted(p.name for p in (DATA/'TOPIX').iterdir() if p.is_dir() and (p/'book.jsonl').exists())
    assert len(scenes)==81
    rows=[]
    with ProcessPoolExecutor(max_workers=4) as pool:
        futures={pool.submit(one,(s,entries.get(s))):s for s in scenes}
        for f in as_completed(futures):
            row=f.result();rows.append(row)
            print(json.dumps({'完了':len(rows),'場':row['session'],'再用':row['再用']},ensure_ascii=False),flush=True)
    rows.sort(key=lambda x:x['session'])
    data={'成功':True,'対象':'TOPIX','場数':len(rows),'期間':['2026-09-21_Day','2026-11-16_Day'],'entries':rows,
          '原板複製':False,'旧cache再用':sum(r['再用'] for r in rows),'旧Source':str(ROOT/'scripts/複合検証/データ準備.py')}
    (HERE/'入力台帳.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


if __name__=='__main__':
    main()
