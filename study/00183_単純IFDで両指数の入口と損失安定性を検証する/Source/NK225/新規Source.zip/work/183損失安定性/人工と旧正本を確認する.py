"""損失指標の人工境界と旧182の固定正本を照合する。"""
from pathlib import Path
from copy import deepcopy
import gzip
import hashlib
import json
import math

import 安定性183 as S

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).parent


def reference(path: Path) -> dict:
    """
    機能: 固定入力と新集計Sourceの指紋を取得する。
    引数: path(Path)。
    返り値: dictは相対path・bytes・SHA。
    """
    raw = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def artificial() -> dict:
    """
    機能: 未知・ゼロ場・連続性・回復・保有境界を人工例で確認する。
    引数: なし。
    返り値: dictは意味を持つ検査群の件数。
    """
    assert S.bounds([1,3],1)['lower'] == 1 and S.bounds([1,3],1)['upper'] == 3
    assert S.bounds([1],1)['lower_unbounded'] and S.bounds([1],1)['upper_unbounded']
    assert S.bounds([],0)['lower'] is None
    assert S.negative_rate(1,1,4)['lower'] == .25 and S.negative_rate(1,1,4)['upper'] == .5
    assert S.streak([-1,None,-1,1]) == {'lower':1,'upper':3,'exact':False}
    assert S.union_seconds([(10,20),(15,30),(40,50),(18,19),(60,60)]) == 30
    rows = [{'scene':str(i),'start':i*100,'end':(i+1)*100,'known_net':v,
             'all_count':1,'complete':True} for i,v in enumerate([-10,-20,40,-5])]
    path = S.path_values(rows)
    assert path['max_drawdown']['amount'] == 30
    assert path['max_drawdown']['recovery_scene'] == '2'
    assert path['max_drawdown']['peak_to_recovery_seconds'] == 300
    assert path['initial_minimum'] == -30 and path['longest_underwater_count'] == 2
    assert S.rolling(rows,2)['worst_complete']['known_net'] == -30
    rows[1]['complete'] = False
    roll = S.rolling(rows,2)
    assert roll['unknown_count'] == 2 and roll['negative_rate']['upper'] == 2/3
    # ----------------------------------------
    sessions = [{'scene':str(i),'kind':'DAY','start':i*100.,'end':(i+1)*100.,
        'phases':[{'name':'DAY','start':i*100.,'end':(i+1)*100.}]} for i in range(4)]
    ledger = {'net':[100.,None,-40.,30.], 'known':[True,False,True,True],
        'scene':['0','0','1','3'], 'phase':[0,0,0,0], 'entry_time':[10.,50.,110.,310.]}
    positions = [{'scene':'0','fill':10.,'exit':40.,'confirmed_until':40.,'possible_until':100.},
        {'scene':'0','fill':50.,'exit':None,'confirmed_until':60.,'possible_until':100.},
        {'scene':'1','fill':110.,'exit':160.,'confirmed_until':160.,'possible_until':200.},
        {'scene':'3','fill':310.,'exit':340.,'confirmed_until':340.,'possible_until':400.}]
    pack={'id':'人工','ledger':ledger,'sessions':sessions,'positions':positions}
    saved=deepcopy(pack)
    result=S.evaluate_pack(pack,{'前二場':['0','1']})
    assert pack == saved
    day=result['groups']['DAY'];tr=day['trades'];sc=day['sessions']
    assert tr['all_count']==4 and tr['known_profit']==130 and tr['known_loss']==40
    assert sc['zero_acquisition_count']==1 and sc['eligible_count']==4
    assert sc['negative_rate']['lower']==.25 and sc['negative_rate']['upper']==.5
    assert day['holding']['held_lower_seconds']==120 and day['holding']['held_upper_seconds']==160
    assert day['path']['full_exact'] is None and day['path']['exact_prefix_scenes']==0
    assert result['periods']['前二場']['DAY']['sessions']['eligible_count']==2
    assert result['groups']['NIGHT']['sessions']['eligible_count']==0
    # ----------------------------------------
    ns=[{'scene':'夜','kind':'NIGHT','start':0.,'end':100.,
        'phases':[{'name':'PRE','start':0.,'end':50.},{'name':'POST','start':50.,'end':100.}]}]
    np=[{'scene':'夜','fill':40.,'exit':80.,'confirmed_until':80.,'possible_until':100.}]
    assert S.hold_rows(ns,np,'PRE')[0]['held_lower_seconds']==10
    assert S.hold_rows(ns,np,'POST')[0]['held_lower_seconds']==30
    return {'成功':True,'検査群':8,'内容':['中央値無界','赤字率上下限','連続赤字上下限','保有区間和集合',
        'DD回復と初期損失','重複窓未知','全場/純関数/期間','米国境界の実時間分割']}


def natural() -> dict:
    """
    機能: 既存182の7案に対し、独立集計と固定正本の共通項を照合する。
    引数: なし。
    返り値: dictは照合件数と新しい基準損失指標。
    """
    path=ROOT/'work/182局面と値幅の改善/保存する候補.json.gz'
    before=reference(path)
    rows=json.loads(gzip.decompress(path.read_bytes()))['rows']
    counts=0;results=[]
    for row in rows:
        scenes=[s['scene'] for s in row['sessions']]
        assert len(scenes)==81
        periods={'旧73':scenes[:73],'前48':scenes[:48],'後25':scenes[48:73],
                 '追加7':scenes[73:80],'本日1':scenes[80:],'全80':scenes[:80]}
        result=S.evaluate_pack(row,periods)
        for period in (None,'旧73','前48','後25','追加7','本日1','全80'):
            evidence=row['evidence'] if period is None else row['全80比較'] if period=='全80' else row['periods'][period]
            groups=result['groups'] if period is None else result['periods'][period]
            for band in ('DAY','NIGHT','PRE','POST'):
                old=(evidence['financial']['session_groups_required'][band] if band in ('DAY','NIGHT')
                     else evidence['financial']['phases_diagnostic'][band])
                new=groups[band]
                for key in ('all_count','known_count','unknown_count','known_profit','known_loss','known_net'):
                    assert new['trades'][key]==old['trades'][key],(row['id'],period,band,key)
                    counts+=1
                for key in ('eligible_count','participating_count','zero_acquisition_count','complete_count','unknown_count'):
                    assert new['sessions'][key]==old['sessions'][key],(row['id'],period,band,key)
                    counts+=1
                assert new['sessions']['negative_rate']['negative_count']==old['sessions']['complete_negative_count']
                counts+=1
                for kind in ('trades','sessions'):
                    for key in ('lower','upper','lower_unbounded','upper_unbounded','strictly_positive_guaranteed'):
                        assert new[kind]['net_median'][key]==old[kind]['net_median'][key],(row['id'],period,band,kind,key)
                        counts+=1
                oldheld=evidence['holding']['groups'][band]
                for key in ('eligible_seconds','held_lower_seconds','held_upper_seconds','held_lower_ratio','held_upper_ratio'):
                    a,b=new['holding'][key],oldheld[key]
                    assert (a is None and b is None) or (a is not None and b is not None and math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-8)),(row['id'],period,band,key,a,b)
                    counts+=1
                prior=evidence['concentration'][band]['path']['known_contribution']
                if prior is not None:
                    assert new['path']['known_contribution']['max_drawdown']['amount']==prior['max_drawdown_amount']
                    assert new['path']['known_contribution']['worst_scene_net']==prior['worst_scene_net']
                    counts+=2
        results.append(result)
    assert before==reference(path)
    (HERE/'旧182七案の損失安定性.json.gz').write_bytes(gzip.compress(json.dumps({'rows':results},ensure_ascii=False,separators=(',',':'),allow_nan=False).encode(),mtime=0))
    return {'成功':True,'候補数':len(rows),'期間':7,'主小帯':4,'共通属性照合':counts,'入力':before}


def main() -> None:
    """
    機能: 人工・旧正本同体とSource指紋を保存する。
    引数: なし。
    返り値: None。旧正本と金融を変更しない。
    """
    proof={'人工':artificial(),'旧正本':natural(),
        'Source':reference(HERE/'安定性183.py'),'順位方針':reference(HERE/'順位方針.json')}
    (HERE/'人工と旧正本の確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':
    main()
