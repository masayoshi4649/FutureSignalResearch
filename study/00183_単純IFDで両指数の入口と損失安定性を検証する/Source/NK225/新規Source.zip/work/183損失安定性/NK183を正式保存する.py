"""NK183の新Source・選択正本・小型比較を、親archiveを参照して正式保存する。"""
from pathlib import Path
from datetime import datetime, timezone
import gzip,hashlib,json,platform,sys,zipfile
import numpy as np

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
TRIAL=ROOT/'study/00183_単純IFDで両指数の入口と損失安定性を検証する'
DEST=TRIAL/'NK225';BASE=ROOT/'work/183単純IFD検証'
PARENT=ROOT/'study/00182_反転の危険局面と値幅に応じた保護を組み合わせる/再現資料'
INPUT=ROOT/'inputs/00183_入口判断時点の価格'


def ref(path):
    """
    機能: 相対パス・サイズ・内容指紋を返す。
    引数: path(Path)は対象ファイル。
    返り値: dictはSHA256を持つ参照。
    """
    with path.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':digest}


def write(path,data):
    """
    機能: 新しい保存先だけへ書き、既存同体の再実行を許す。
    引数: path(Path),data(bytes)。
    返り値: dictは保存指紋。既存差分は失敗させる。
    """
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():assert path.read_bytes()==data,path
    else:path.write_bytes(data)
    return ref(path)


def copy(src,dst):
    """
    機能: 正本を元byteのまま別の正式保存先へ写す。
    引数: src/dst(Path)。
    返り値: dictは保存先と元pathの対応。
    """
    return {'source':ref(src),'saved':write(dst,src.read_bytes()),'変換':'なし'}


def read(path):
    """
    機能: JSON又はgzip JSONを読む。
    引数: path(Path)。
    返り値: objectは保存値。
    """
    data=path.read_bytes();return json.loads(gzip.decompress(data) if path.suffix=='.gz' else data)


def main():
    """
    機能: Source/結果/検査/入力目次を固定保存し、全memberと正本の一致を確認する。
    引数: なし。
    返り値: None。旧試行・親archive・他担当成果物は書き換えない。
    """
    saved=[];sources=[]
    for folder in (ROOT/'work/183入口候補',BASE):sources.extend(folder.glob('*.py'))
    sources.extend(HERE/name for name in ('安定性183.py','新候補の集計を独立検査する.py','人工と旧正本を確認する.py',
        'NK183の差を診断する.py','NK183を正式保存する.py','順位方針.json'))
    sources.append(BASE/'比較方針.json');sources=sorted(set(sources))
    source_path=TRIAL/'Source/NK225/新規Source.zip';source_path.parent.mkdir(parents=True,exist_ok=True)
    import io
    payload=io.BytesIO()
    with zipfile.ZipFile(payload,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for p in sources:
            info=zipfile.ZipInfo(p.relative_to(ROOT).as_posix(),(2026,11,17,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            archive.writestr(info,p.read_bytes())
    write(source_path,payload.getvalue())
    with zipfile.ZipFile(source_path) as archive:
        assert archive.namelist()==[p.relative_to(ROOT).as_posix() for p in sources]
        assert all(archive.read(p.relative_to(ROOT).as_posix())==p.read_bytes() for p in sources)
    # ----------------------------------------
    for name in ('全候補比較.json.gz','全候補の損失安定性.json.gz','全純入口の封印.json'):
        saved.append(copy(BASE/name,DEST/name))
    for n in ('00','01','04','06'):
        name='E183_'+n+'__C0_IFD.json.gz';saved.append(copy(BASE/'集約'/name,DEST/'選択4候補'/name))
    for name in ('候補辞書183.json','純候補の固定183.json'):
        saved.append(copy(ROOT/'work/183入口候補'/name,DEST/'条件'/name))
    saved.append(copy(ROOT/'work/183入口候補/README.md',DEST/'入口仕様.md'))
    for name in ('NK183独立確認.json','人工と旧正本の確認.json'):
        saved.append(copy(HERE/name,DEST/'監査'/name))
    raw=ROOT/'work/183入口候補/人工確認183.json';compressed=gzip.compress(raw.read_bytes(),mtime=0)
    result=write(DEST/'監査/入口人工確認183.json.gz',compressed)
    assert gzip.decompress((ROOT/result['path']).read_bytes())==raw.read_bytes()
    saved.append({'source':ref(raw),'saved':result,'変換':'gzip可逆圧縮。元byteへ戻すと元SHAに一致。'})
    for name in ('NK183取得差の診断.json.gz','外部一次資料.md'):
        saved.append(copy(HERE/name,DEST/name))
    # ----------------------------------------
    input_refs=[ref(p) for p in sorted(INPUT.iterdir()) if p.suffix in ('.json','.npz')]
    input_text='''# 判断時点q0の価格

NK225の純入口183で、当時のEMA価格・BB帯端・突破端を固定するための小型入力。後の取得q1や金融成績を含まない。

`旧73_q0.npz`、`追加7_q0.npz`、`本日1_q0.npz` に `last/bid/ask/time/line/normal` を保存する。各 `.json` は100特徴の意味内容SHA、共用価格索引manifest/場別SHA、生成Source、NPZのサイズ/SHA、元q0行との照合件数を持つ。原板・48byte価格索引は複製しない。

元100特徴の `q0_index` で共用163/167/180の索引行を取り出し、元行番号・時刻・場・限月を照合した。`time` は既存入力の価格時計であり受信時計ではない。正常BBOでもmini実約定を保証しない。

生成Sourceは [183新規Source](../../study/00183_単純IFDで両指数の入口と損失安定性を検証する/Source/NK225/新規Source.zip) 内の `work/183単純IFD検証/当時価格183.py`。親Sourceを復元した作業コピーで `python -X utf8 work/183単純IFD検証/当時価格183.py` を実行する。既存入力があれば元Source/入力/内容SHAの一致を検査する。

| ファイル | byte | SHA256 |
|---|---:|---|
'''
    for r in input_refs:input_text+=f"|{Path(r['path']).name}|{r['bytes']}|`{r['sha256']}`|\n"
    write(INPUT/'README.md',input_text.encode('utf-8'))
    # ----------------------------------------
    text='''# NK225の検証と再現

固定単純IFDに対し、旧4案＋6種の複合構造×4統合方式を比較した。幅・期限は基準入口の設定を継承し、新しい出口最適化をしていない。mini1枚、1pt=100円、片道税込手数料38.5円、追加滑り片道5pt（往復費用1,077円）。全81場は既使用であり、全80発見・前48選択・後25/追加7/本日1の診断を区別する。

全80Dayの事前順位先頭は04（押戻し回復を追加）、前48Dayの先頭は06（同回復＋既存危険局面の反転）。Nightは両方とも00（旧IFD）が先頭。順位は適合→赤字場率上限→最悪5場既知寄与損失→最大場損失→連続赤字→赤字取引→損失/取得→DD→参加の順。前半と全期を交換しない。未知場/窓の既知寄与順位は確定した安定優位の証明ではない。

04はDay全41場取得・両中央値黒字・保有55.44%を保持し、赤字場10→9、場末DD93,539→70,771円。一方で損失総額1,163,159→1,284,621円、追加7内Day収支8,768→−17,386円へ悪化した。全面的な損失安定化として採用しない。

[取得差の診断](取得差の診断.md)に新枝の実取得と旧口座との差を記した。詳細は `NK183取得差の診断.json.gz`。これは実取得した取引の差であり、未参加の仮想利益を機会損失として最適化したものではない。

## 保存物

- `全候補比較.json.gz`：全28候補の小表と全80/前48の固定順位。
- `全候補の損失安定性.json.gz`：全28候補×全体/期間×帯の率上下限・中央値範囲・保有下上限・DD・5/10場窓。
- `選択4候補/`：00旧IFD、01全BO回復待ち対照、04全80Day先頭、06前48Day先頭の金融全件・全81場。
- `監査/`：独立117,936属性照合、人工8群と旧182比較、入口人工検査。
- `条件/`、`全純入口の封印.json`、親の `条件_NK225.json`：新金融前の候補・Source・純配列固定。
- [Source](../Source/NK225/新規Source.zip)：新183Sourceのみ。元work相対パスを保持する。
- [保存索引](保存索引.json)：上記の指紋、生成した元84期間pack/28集約pack/純NPZの省略指紋、親archive参照。

## 再現

まず [182再現資料](../../00182_反転の危険局面と値幅に応じた保護を組み合わせる/再現資料/README.md) に従い、親Source・正本を古い順に新しい作業コピーのリポジトリルートへ復元する。182索引が参照する181以前の依存も必要。原板・148/163/167/179/180共用inputsを同じSHAで参照し、183へ重複させない。続いて183新規Source.zipを同ルートへ展開する。

```powershell
python -X utf8 work/183単純IFD検証/当時価格183.py
python -X utf8 work/183入口候補/人工検査.py
python -X utf8 work/183単純IFD検証/実行183.py --resume
python -X utf8 work/183単純IFD検証/比較を集計する.py
python -X utf8 work/183損失安定性/新候補の集計を独立検査する.py --input work/183単純IFD検証 --output work/183損失安定性/NK183独立確認.json
python -X utf8 work/183損失安定性/NK183の差を診断する.py
```

`--resume` は固定Source・純配列の一致を検査後、存在する期間packを再利用する。中間packがない新しい作業コピーでは全84packを生成する。独立検査には全28集約packが必要なので、4保存候補だけを渡さない。再生成した期間pack・純NPZは保存索引の指紋へ照合できる。ZIPの保存時刻や圧縮実装が変わる場合は内容配列と条件を先に照合する。

独立検査は金融台帳からの別算術集計・旧金融共通項照合であり、原JSONL全件の再取得や実約定保証ではない。TOPIXの全件BBO直接走査監査とは検査範囲を分ける。
'''
    write(DEST/'README.md',text.encode('utf-8'))
    diagnosis='''# 実取得から見た183の差

この診断は固定結果を読んだ後の説明であり、新しい条件を採用した検証ではない。単位はNK225mini1枚・費用後円。04/06の新構造は複数時間軸の方向支持、押戻しの固定EMA8価格からの回復、MACD/RSI増分、1分構造、相対数量を組み合わせている。

## Day

04新構造36取得だけでは利益303,691円・損失349,463円・収支−45,772円（未知0）。04口座全体の増益には枠の解放時刻と旧幹の後続取得の変化を含むため、押戻し回復単独の優位とは言えない。追加7内Dayの新構造3取得は全赤字、損失48,231円。単純な順行確認の追加が一貫した安定化を生んだわけではない。

前48選択06の後25Dayは、既存危険局面の反転3取得が全赤字−93,231円。新構造19取得は04と同じ+29,537円である。悪化の主たる観測箇所は、新構造追加の一括否定ではなく、元方向リスクを実方向の持続優位へ置き換える反転判断にある。ただしこの事後3件から閾値の正解を決めない。

## Night

全6構造の追加方式で新構造実取得の既知収支は赤字だった。次表は新構造から実際に取得できた部分だけであり、口座全体の差額とは異なる。

| 入口 | 新構造取得 | 未知 | 既知利益 | 既知損失 | 既知収支 |
|---|---:|---:|---:|---:|---:|
|04 押戻し回復|77|7|454,844|706,234|−251,390|
|08 固定突破端再テスト|45|4|264,922|423,079|−158,157|
|12 固定突破端失敗反転|94|4|497,459|958,389|−460,930|
|16 元圧力失速と反転|107|9|746,073|839,619|−93,546|
|20 低ADX固定BB端回復|43|7|263,537|296,309|−32,772|
|24 混在背景から動力整理|68|2|394,229|720,311|−326,082|

04は新構造PRE34取得で−256,464円、POST43取得で+5,074円（未知5）。PREの損失が大きく、POSTは未知を含む小幅な既知黒字である。前48/後25/追加7の新構造収支も順に−82,234/−138,694/−30,462円。旧幹維持部分の既知収支803,916円に対し新構造自体が赤字で、枠の置換だけによる悪化とは言えない。

04口座全体は基準122→173取得、未知5→11。新構造の未知7件は通常期限BBO不足6・価格gap1。口座全体では通常期限BBO不足8・価格gap3。新しい取得時点で、固定H60などの返済時計に正常BBOがないケースを増やした。数量やチャートが不利だった証明ではなく、金融観測と参加拡大の問題である。将来の欠測を入口時点で除外せず、当時に判別できる流動性・観測の持続性を次試行で別検証する必要がある。

次の仮説では、PREで回復が元の大きな方向へ継続せず短い戻りに終わる原因、逆行リスクの発見と反対側の入口優位を分ける。板需給が使えるなら、価格が戻った事実に加え元方向の圧力消失と実方向の量の持続を調べる。これは[一次資料](外部一次資料.md)からの研究仮説であり、183で確認した因果効果ではない。
'''
    write(DEST/'取得差の診断.md',diagnosis.encode('utf-8'))
    # ----------------------------------------
    omitted=[ref(p) for p in sorted((BASE/'期間別').glob('*/*.json.gz'))]
    omitted.extend(ref(p) for p in sorted((BASE/'集約').glob('*.json.gz')))
    omitted.extend(ref(BASE/(leg+suffix)) for leg in ('旧73','追加7','本日1') for suffix in ('_新入口.npz','_純成立診断.json.gz'))
    assert len(list((BASE/'期間別').glob('*/*.json.gz')))==84
    import tzdata
    manifest={'成功':True,'正式保存':True,'新金融生成なし':True,
        'Source':{'archive':ref(source_path),'members':[ref(p) for p in sources]},
        '親参照':[ref(PARENT/n) for n in ('Source.zip','比較正本.zip','保存索引.json','README.md')],
        '正本':saved,'省略中間指紋':omitted,'恒久q0入力':input_refs+[ref(INPUT/'README.md')],
        '条件':ref(TRIAL/'条件_NK225.json'),'文書':[ref(DEST/n) for n in ('README.md','取得差の診断.md')],
        '依存関係':{'Python':platform.python_version(),'NumPy':np.__version__,'tzdata':tzdata.__version__},
        '保存方針':'旧archiveと共用原板は参照。新Sourceだけ保存。全28候補の小表/安定性、選択4金融正本を保存。84期間packと残り集約pack・純NPZは再生成可能な指紋に留める。',
        '完了確認':{'Source全member同体':len(sources),'保存正本同体':len(saved),'NK独立集計照合':read(HERE/'NK183独立確認.json')['照合項目']}}
    write(DEST/'保存索引.json',(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    print(json.dumps({'成功':True,'Source件数':len(sources),'正本':len(saved),'省略指紋':len(omitted),'保存先':str(DEST)},ensure_ascii=False))


if __name__=='__main__':main()
