"""NK183の取得済み台帳の差を診断し、未参加の仮想利益と区別する。"""
from pathlib import Path
from collections import defaultdict
import gzip,hashlib,json

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent;BASE=ROOT/'work/183単純IFD検証'


def read(path):
    """
    機能: 保存値を読む。
    引数: path(Path)はJSON/gzip JSON。
    返り値: objectは保存値。
    """
    data=path.read_bytes();return json.loads(gzip.decompress(data) if path.suffix=='.gz' else data)


def summary(rows):
    """
    機能: 実際に取得した一群の利益・損失・未知・先着を数える。
    引数: rows(list[dict])は取得台帳。
    返り値: dict。未知額を0とした全件収支は作らない。
    """
    known=[r['net'] for r in rows if r['net'] is not None];labels=defaultdict(int)
    for row in rows:labels[str(row['label'])]+=1
    return {'取得':len(rows),'未知':len(rows)-len(known),'既知利益':sum(max(x,0) for x in known),
            '既知損失':-sum(min(x,0) for x in known),'既知収支':sum(known),
            '確定赤字':sum(x<0 for x in known),'先着ラベル':dict(labels)}


def main():
    """
    機能: 新入口の役割別実取得と基準から変化した実取得を診断する。
    引数: なし。
    返り値: None。金融・選択・条件を改変しない。
    """
    comp=read(BASE/'全候補比較.json.gz');raw=[read(BASE/'集約'/(r['id']+'.json.gz')) for r in comp['rows']]
    diag={leg:read(BASE/(leg+'_純成立診断.json.gz')) for leg in ('旧73','追加7','本日1')}
    scenes=[r['scene'] for r in raw[0]['sessions']];periods={'前48':set(scenes[:48]),'後25':set(scenes[48:73]),
        '追加7':set(scenes[73:80]),'本日1':set(scenes[80:]),'全80':set(scenes[:80]),'全81':set(scenes)}
    tables={}
    for pack in raw:
        led=pack['ledger'];rows=[];entry=pack['policy']['entry']
        for i in range(len(led['net'])):
            r={k:v[i] for k,v in led.items()};details=diag[r['leg']][entry];event=r['event']
            r['役割']=('LC' if r['added'] else '新構造' if 'new_structure' in details and details['new_structure'][event]
                else '既存幹の反転' if 'flipped' in details and details['flipped'][event] else '旧幹又はT')
            r['key']=(r['scene'],r['entry_time'],r['entry_line'],r['side'],r['width'],r['horizon'])
            rows.append(r)
        tables[pack['id']]=rows
    baseline=tables[comp['baseline']];result=[]
    for identity,rows in tables.items():
        groups={}
        for band in ('DAY','NIGHT','PRE','POST'):
            phases={'DAY':{0},'NIGHT':{1,2},'PRE':{1},'POST':{2}}[band]
            for period,names in periods.items():
                picked=[r for r in rows if r['scene'] in names and r['phase'] in phases]
                old=[r for r in baseline if r['scene'] in names and r['phase'] in phases]
                keys={r['key'] for r in picked};oldkeys={r['key'] for r in old}
                added=[r for r in picked if r['key'] not in oldkeys];removed=[r for r in old if r['key'] not in keys]
                classes=defaultdict(list)
                for row in picked:classes[row['役割']].append(row)
                groups[band+'_'+period]={'全取得':summary(picked),'役割':{k:summary(v) for k,v in classes.items()},
                    '基準だけの実取得':summary(removed),'候補だけの実取得':summary(added),
                    '未知の実取得':[{k:r[k] for k in ('scene','case_id','entry_time','side','width','horizon','status','役割')}
                        for r in picked if r['net'] is None]}
        result.append({'id':identity,'群':groups})
    body={'基準':comp['baseline'],'順位':comp['順位'],'注意':'候補だけ/基準だけは各口座再生で実際に取得した取引の差。未参加の機会損失を最適化しない。新構造の追加は枠・後続取得も変えるため単独寄与と口座差を区別する。',
          '作成SourceSHA':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':result}
    (HERE/'NK183取得差の診断.json.gz').write_bytes(gzip.compress(json.dumps(body,ensure_ascii=False,separators=(',',':')).encode(),mtime=0))
    selected={r['id']:r for r in result};keys=['E183_'+n+'__C0_IFD' for n in ('00','04','06','08','12','16','20','24')]
    for key in keys:
        row=selected[key]
        print(json.dumps({'id':key,'DAY全81':row['群']['DAY_全81']['全取得'],'NIGHT全80':row['群']['NIGHT_全80']},ensure_ascii=False))


if __name__=='__main__':main()
