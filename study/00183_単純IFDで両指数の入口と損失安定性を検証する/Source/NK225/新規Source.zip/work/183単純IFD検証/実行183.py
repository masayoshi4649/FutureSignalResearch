"""金融前に純入口を固定し、単純IFDで全81場の後続注文を再生する。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import gzip
import hashlib
import json
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).parent
TRIAL = ROOT/'study/00183_単純IFDで両指数の入口と損失安定性を検証する'
for directory in ('work/181共用接続','work/181反省を分解した改善','work/183入口候補'):
    sys.path.insert(0, str(ROOT/directory))
import 共用181 as C
import 集計181 as A
import rules183 as R
import 当時価格183 as Q


def ref(path: Path) -> dict:
    """
    機能: Sourceや入力の内容指紋を取得する。
    引数: path(Path)。
    返り値: dictは相対パス・容量・SHA256。
    """
    data = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


def safe(value: object) -> object:
    """
    機能: NumPyと非有限値をJSON互換の値へ変換する。
    引数: value(object)。
    返り値: object。非有限値はNone、未知の0円化は行わない。
    """
    if isinstance(value, dict): return {str(k): safe(v) for k,v in value.items()}
    if isinstance(value, (list,tuple,np.ndarray)): return [safe(v) for v in value]
    if isinstance(value, np.bool_): return bool(value)
    if isinstance(value, np.integer): return int(value)
    if isinstance(value, (float,np.floating)): return float(value) if np.isfinite(value) else None
    return value


def save(path: Path, value: object) -> None:
    """
    機能: UTF-8のJSON又は決定的gzipで保存する。
    引数: path(Path)、value(object)。
    返り値: None。
    """
    data = (json.dumps(safe(value),ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(gzip.compress(data,mtime=0) if path.suffix=='.gz' else data)


def freeze() -> dict:
    """
    機能: 候補・順位・Sourceを新183の金融計算前に封印する。
    引数: なし。
    返り値: dictは固定条件。再開時には同体を検査する。
    """
    sources = [Path(__file__), Path(Q.__file__), Path(C.__file__), Path(A.__file__),
        Path(R.__file__), HERE/'比較方針.json',
        ROOT/'work/181入口改善/rules181.py', ROOT/'work/181入口改善/rules181_v2.py',
        ROOT/'work/182局面別の反転確認/rules182.py',
        ROOT/'work/183損失安定性/安定性183.py', ROOT/'work/183損失安定性/順位方針.json']
    sources += sorted((ROOT/'work/183入口候補').glob('*.py'))
    sources = sorted(set(sources))
    body = {'試行':183,'商品':'NK225','UTC':datetime.now(timezone.utc).isoformat(),
        '入口':R.catalog(), '方針':json.loads((HERE/'比較方針.json').read_text(encoding='utf-8')),
        'Source':[ref(p) for p in sources]}
    target = TRIAL/'条件_NK225.json'
    if target.exists():
        prior=json.loads(target.read_text(encoding='utf-8'))
        assert all(prior[key]==body[key] for key in ('入口','方針','Source'))
        return prior
    save(target,body)
    return body


def main() -> None:
    """
    機能: 純判断を全期間で先に封印し、固定IFD口座を候補ごとに再生する。
    引数: CLI --resume(bool)は同体の完了pack再利用、--leg(str)は任意の期間。
    返り値: None。純入口・監査診断・期間別損益を保存する。
    """
    parser=argparse.ArgumentParser()
    parser.add_argument('--resume',action='store_true')
    parser.add_argument('--leg',choices=C.LEGS)
    args=parser.parse_args()
    freeze()
    all_pure={}
    for leg in C.LEGS:
        pure=C.load_pure_leg(leg)
        C.seal_pure_leg(pure)
        pure['features'].q0_prices=Q.load_q0(pure)
        built=R.build(pure['features'],pure['baselines']['全期_J035'])
        payload={}
        for name,bundle in built['bundles'].items():
            for key in ('mw','fw','hi','added'):payload[name+'__'+key]=bundle[key]
            for key,value in bundle['birth'].items():payload[name+'__birth__'+key]=value
        target=HERE/(leg+'_新入口.npz')
        if target.exists():
            with np.load(target,allow_pickle=False) as prior:
                assert set(prior.files)==set(payload)
                for key in payload:np.testing.assert_array_equal(prior[key],payload[key])
        else:np.savez_compressed(target,**payload)
        save(HERE/(leg+'_純成立診断.json.gz'),built.get('diagnostics',{}))
        all_pure[leg]=(pure,built)
        print(json.dumps({'段階':'純入口封印','期間':leg,'候補':len(built['bundles'])},ensure_ascii=False),flush=True)
    seal={'金融前':True,'条件':ref(TRIAL/'条件_NK225.json'),
          '純入口':[ref(HERE/(leg+'_新入口.npz')) for leg in C.LEGS],
          '当時価格':[ref(Q.DEST/(leg+'_q0.npz')) for leg in C.LEGS]}
    target=HERE/'全純入口の封印.json'
    if target.exists():assert json.loads(target.read_text(encoding='utf-8'))==seal
    else:save(target,seal)
    # ----------------------------------------
    for leg in ([args.leg] if args.leg else C.LEGS):
        pure,built=all_pure[leg]
        loaded=C.attach_financial(pure)
        for name,bundle in built['bundles'].items():
            policy={'id':name+'__C0_IFD','entry':name,'exit':'C0_IFD'}
            path=HERE/'期間別'/leg/(policy['id']+'.json.gz')
            if args.resume and path.exists():continue
            pack=A.pack(loaded['context'],bundle,policy,leg)
            save(path,pack)
            print(json.dumps({'期間':leg,'候補':policy['id'],**A.short(pack['evidence'])},ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
