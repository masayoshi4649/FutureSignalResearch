"""182の保存候補を、候補別CSV用の型付きJSONへ変換する。"""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import argparse
import gzip
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
JST = timezone(timedelta(hours=9))
NAMES = {'候補比較': '集計', 'デイ': 'デイ', 'ナイト_米前': 'ナイト_米前',
         'ナイト_米後': 'ナイト_米後', 'ナイト合計': 'ナイト合計', '取引明細': '取引明細'}
REASONS = {1: '利確幅先着', 2: '損切幅先着', 3: '通常期限決済', 4: '終了前の予定決済',
    5: '追尾接触後の遅延返済', 10: '価格欠測で不明', 11: 'BBO欠測で不明',
    12: '通常期限の板不足', 13: '終了前決済窓の板不足', 14: '観測終了で不明', 15: '新規停止後'}
SUMMARY = ['候補', '選択区分', '集計対象', '区分', '対象場数', '取得場数',
    '利益円_既知', '損失円_既知', '収支円_既知分', '収支円_全件確定', '取引回数',
    '黒字決済回数', '赤字決済回数', '同値決済回数', '金融未知件数', '保有率下限', '保有率上限',
    '保有分下限', '保有分上限', '対象分', '場別保有率中央値下限', '保有20%以上確定場数',
    '取引なし場数', 'F', 'A', 'N', 'C', '先着率', '建玉中央値下限円', '建玉中央値上限円',
    '場中央値下限円', '場中央値上限円', '両中央値', '強制決済件数', '終了前決済未確認場数',
    '終了前決済違反場数', '入口設定', '出口設定', '原候補ID']
SCENE = ['候補', '選択区分', 'セッション日', 'セッションID', '利益円_既知', '損失円_既知',
    '収支円_既知分', '収支円_全件確定', '累計収支円_既知分', '累計収支円_全件確定',
    '取引回数', '金融未知件数', '累計金融未知件数', '保有率下限', '保有率上限',
    '保有分下限', '保有分上限', '対象分', '保有20%以上確定', '旧主取得', '新LC取得',
    '初参加T取得', 'F', 'A', 'N', 'C', '強制決済件数', '終了前全決済確認',
    '対象開始JST', '対象終了JST', '入口設定', '出口設定', '原候補ID', '取引なし理由']
TRADE = ['候補', '取引番号', 'セッションID', '新規時間帯', '方向', '取得時刻JST', '決済時刻JST',
    '取得BBO価格', '決済BBO価格', '売買差pt', '往復手数料円', '往復追加滑り円',
    '利益円_既知', '損失円_既知', '費用後損益円', '累計収支円_既知分', '累計収支円_全件確定',
    '金融未知件数', '累計金融未知件数', '保有分下限', '保有分上限', '決済理由', '入口区分',
    'IFD対称幅pt', '期限', '強制決済', 'case_id', '取得原行', '決済原行', '入口設定', '出口設定', '原候補ID', '正本台帳行']


def read(path: Path) -> dict:
    """
    機能: JSON又はgzipの正本を読み込む。
    引数: path(Path)。
    返り値: dictは保存された標準JSON。
    """
    body = path.read_bytes()
    return json.loads(gzip.decompress(body) if path.suffix == '.gz' else body)


def ref(path: Path) -> dict:
    """
    機能: 入出力の内容指紋を返す。
    引数: path(Path)。
    返り値: dictはリポジトリ相対path、bytes、sha256。
    """
    return {'path': path.resolve().relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def local_time(value: float | None) -> str | None:
    """
    機能: 価格時計の秒を、artifactがISO日時と誤認しないJST文字列へ変換する。
    引数: value(float|None)はUnix秒。未知はNone。
    返り値: str|NoneはYYYY-MM-DD HH:mm:ss、又は未知。
    """
    if value is None:
        return None
    result = datetime.fromtimestamp(float(value), JST).strftime('%Y-%m-%d %H:%M:%S')
    assert re.fullmatch(r'\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}', result)
    return result


def display(identity: str, mapping: dict) -> tuple:
    """
    機能: 候補IDを一意な182短名と選択区分へ対応させる。
    引数: identity(str)、mapping(dict)はID→短名文字列又はshort/role辞書。
    返り値: tuple[str,str]は表示候補と選択区分。
    """
    value = mapping[identity]
    short = value if isinstance(value, str) else value['short']
    role = '保存候補・全81場診断' if isinstance(value, str) else value.get('role', '保存候補・全81場診断')
    candidate = short if short.startswith('182:') else '182:'+short
    assert re.fullmatch(r'182:[^<>:"/\\|?*]+', candidate), candidate
    assert all(len(candidate.replace(':', '_')+'_'+name) <= 31 for name in NAMES.values()), candidate
    return candidate, role


def indices(ledger: dict, band: str) -> list:
    """
    機能: 新規時点に固定した時間帯で台帳行を選ぶ。
    引数: ledger(dict)、band(str)はALL/DAY/NIGHT/PRE/POST。
    返り値: list[int]は原台帳位置。保有時間の帯分割と混同しない。
    """
    return [i for i, phase in enumerate(ledger['phase']) if band == 'ALL'
        or (band == 'NIGHT' and phase > 0)
        or (band in ('DAY', 'PRE', 'POST') and phase == ('DAY', 'PRE', 'POST').index(band))]


def group(row: dict, band: str) -> dict:
    """
    機能: 保存済み評価から帯又は全81場の同じ金融群を取得する。
    引数: row(dict)、band(str)。
    返り値: dictはtrades/sessions/decisionを含む金融群。
    """
    finance = row['evidence']['financial']
    return finance['all_reference'] if band == 'ALL' else finance['session_groups_required'][band] \
        if band in ('DAY', 'NIGHT') else finance['phases_diagnostic'][band]


def build(data: dict, mapping: dict, expected: dict | None = None) -> tuple:
    """
    機能: 候補ごとに6CSV向けの型付き表を作り、正本の金融・保有・未知へ照合する。
    引数: data(dict)は全81packを持つrows、mapping(dict)、expected(dict|None)は帯別期待場数。
    返り値: tuple[dict,dict]はCSV author用入力と整合確認。入力・政策は変更しない。
    """
    records = data['rows']; assert records and len({r['id'] for r in records}) == len(records)
    assert set(mapping) == {r['id'] for r in records}
    tables = {name: {'headers': SUMMARY if name == '候補比較' else TRADE if name == '取引明細' else SCENE,
                     'rows': []} for name in NAMES}
    candidates = [display(r['id'], mapping)[0] for r in records]
    assert len(set(candidates)) == len(candidates)
    checks = []; correspondences = []
    for row in records:
        candidate, role = display(row['id'], mapping); ledger = row['ledger']; n = len(ledger['net'])
        assert all(len(value) == n for value in ledger.values())
        assert all((net is not None) == bool(known) for net, known in zip(ledger['net'], ledger['known'], strict=True))
        holding = row['evidence']['holding']; closure = {r['scene']: r for r in holding['closure']['rows']}
        window = {r['scene']: r for r in row['sessions']}; assert len(window) == len(row['sessions'])
        entry, exit_id = row['policy']['entry'], row['policy']['exit']
        correspondences.append({'表示ID': candidate, '原候補ID': row['id'], '選択区分': role})
        for band in ('ALL', 'DAY', 'PRE', 'POST', 'NIGHT'):
            g = group(row, band); t = g['trades']; s = g['sessions']; h = holding['groups'][band]
            selected = indices(ledger, band); known = [ledger['net'][i] for i in selected if ledger['net'][i] is not None]
            profit = sum(max(0., v) for v in known); loss = sum(max(0., -v) for v in known)
            assert (profit, loss, profit-loss) == (t['known_profit'], t['known_loss'], t['known_net'])
            assert len(selected) == t['all_count'] and len(selected)-len(known) == t['unknown_count']
            assert len(s['rows']) == s['eligible_count'] and len(h['rows']) == s['eligible_count']
            if expected is not None: assert len(s['rows']) == expected[band], (candidate, band, len(s['rows']))
            first = t['IFD_FIRSTFANC']; labels = [ledger['label'][i] for i in selected]
            assert [labels.count(code) for code in (1, -1, 0, 2)] == [first[k] for k in ('F', 'A', 'N', 'C')]
            all_net = t['known_net'] if t['unknown_count'] == 0 else None
            tables['候補比較']['rows'].append([candidate, role, '全81場・既使用・本日を含む診断', band,
                s['eligible_count'], s['participating_count'], profit, loss, t['known_net'], all_net,
                len(selected), sum(v > 0 for v in known), sum(v < 0 for v in known), sum(v == 0 for v in known),
                t['unknown_count'], h['held_lower_ratio'], h['held_upper_ratio'], h['held_lower_seconds']/60,
                h['held_upper_seconds']/60, h['eligible_seconds']/60, h['scene_ratio_median_lower'],
                h['scene_target_met_guaranteed_count'], sum(r['all_count'] == 0 for r in s['rows']),
                *[first[k] for k in ('F', 'A', 'N', 'C')], first['first_f_rate_reached'],
                t['net_median']['lower'], t['net_median']['upper'], s['net_median']['lower'], s['net_median']['upper'],
                g['decision']['status'], sum(bool(ledger['forced'][i]) for i in selected),
                sum(closure[r['scene']]['flat_guaranteed'] is None for r in s['rows']),
                sum(closure[r['scene']]['flat_guaranteed'] is False for r in s['rows']), entry, exit_id, row['id']])
            if band == 'ALL': continue
            name = {'DAY': 'デイ', 'PRE': 'ナイト_米前', 'POST': 'ナイト_米後', 'NIGHT': 'ナイト合計'}[band]
            held = {r['scene']: r for r in h['rows']}; cumulative = 0.; uncertain = 0
            for scene in sorted(s['rows'], key=lambda r: (window[r['scene']]['start'], r['scene'])):
                identity = scene['scene']; matching = [i for i in selected if ledger['scene'][i] == identity]
                assert len(matching) == scene['all_count']
                cumulative += scene['known_net']; uncertain += scene['unknown_count']; time = held[identity]
                assert scene['all_net'] == (scene['known_net'] if scene['unknown_count'] == 0 else None)
                added = sum(bool(ledger['added'][i]) for i in matching)
                fallback = sum(ledger['origin'][i] == 2 for i in matching)
                labels = [ledger['label'][i] for i in matching]; flat = closure[identity]['flat_guaranteed']
                why = '' if matching else '新規取得なし。他帯で取得した保有は時間に実配分。' \
                    if time['held_lower_seconds'] > 0 else '新規取得なし。固定条件・数量枠を含む再生結果。'
                tables[name]['rows'].append([candidate, role, identity.split('_')[0], identity,
                    scene['known_profit'], scene['known_loss'], scene['known_net'], scene['all_net'],
                    cumulative, cumulative if uncertain == 0 else None, len(matching), scene['unknown_count'], uncertain,
                    time['held_lower_ratio'], time['held_upper_ratio'], time['held_lower_seconds']/60,
                    time['held_upper_seconds']/60, time['eligible_seconds']/60,
                    '達成' if time['target_met_guaranteed'] else '不確定' if time['target_met_possible'] else '未達',
                    len(matching)-added-fallback, added, fallback, *[labels.count(code) for code in (1, -1, 0, 2)],
                    sum(bool(ledger['forced'][i]) for i in matching), '確認済' if flat is True else '未知' if flat is None else '違反',
                    local_time(time['start']), local_time(time['end']), entry, exit_id, row['id'], why])
            assert cumulative == t['known_net'] and uncertain == t['unknown_count']
            assert sum(r['held_lower_seconds'] for r in h['rows']) == h['held_lower_seconds']
            assert sum(r['held_upper_seconds'] for r in h['rows']) == h['held_upper_seconds']
            checks.append({'候補': candidate, '帯': band, '場数': len(s['rows']), '0取引場': sum(r['all_count'] == 0 for r in s['rows']),
                '金融と累計一致': True, '保有秒一致': True})

        # ----------------------------------------
        positions = {(p['scene'], p['event'], p['case'], p['side']): p for p in row['positions']}
        assert len(positions) == n
        cumulative = 0.; uncertain = 0
        ordered = sorted(range(n), key=lambda i: (ledger['entry_time'][i], ledger['scene'][i], ledger['event'][i], ledger['side'][i]))
        for number, i in enumerate(ordered, 1):
            net = ledger['net'][i]; cumulative += 0 if net is None else net; uncertain += net is None
            sign = 1 if ledger['side'][i] == 0 else -1
            points = None if net is None else sign*(ledger['exit_price'][i]-ledger['entry_price'][i])
            if net is not None: assert abs(net-(points*100-77-1000)) < 1e-7
            pos = positions[(ledger['scene'][i], ledger['event'][i], ledger['case'][i], ledger['side'][i])]
            low_end = pos['exit'] if pos['exit'] is not None else pos['confirmed_until']
            high_end = pos['exit'] if pos['exit'] is not None else pos['possible_until']
            assert pos['fill'] == ledger['entry_time'][i] and pos['fill'] <= low_end <= high_end
            kind = '新LC' if ledger['added'][i] else '初参加T' if ledger['origin'][i] == 2 else '主入口'
            entry_line = ledger['entry_line'][i]; exit_line = ledger['exit_line'][i]
            tables['取引明細']['rows'].append([candidate, number, ledger['scene'][i],
                ('DAY', 'PRE', 'POST')[ledger['phase'][i]], '買い' if sign == 1 else '売り',
                local_time(ledger['entry_time'][i]), local_time(ledger['exit_time'][i]), ledger['entry_price'][i],
                ledger['exit_price'][i], points, 77 if net is not None else None, 1000 if net is not None else None,
                None if net is None else max(0., net), None if net is None else max(0., -net), net,
                cumulative, cumulative if uncertain == 0 else None, int(net is None), uncertain,
                (low_end-pos['fill'])/60, (high_end-pos['fill'])/60,
                REASONS[ledger['status'][i]], kind, ledger['width'][i], ledger['horizon'][i],
                bool(ledger['forced'][i]), ledger['case_id'][i], entry_line if entry_line >= 0 else None,
                exit_line if exit_line >= 0 else None, entry, exit_id, row['id'], i+1])
        assert cumulative == group(row, 'ALL')['trades']['known_net']
    for name, table in tables.items():
        assert all(len(row) == len(table['headers']) for row in table['rows']), name
        assert all(row[0] in candidates for row in table['rows'])
    for candidate in candidates:
        for name in tables:
            assert any(r[0] == candidate for r in tables[name]['rows']), (candidate, name)
    body = {'trial': 182, 'tableNames': NAMES, 'tables': tables, '候補対応': correspondences,
        '定義': '各候補は別フォルダ・別CSV。mini1枚、費用後、1pt100円、片道38.5円と追加滑り5pt、ラージBBO代理。全81は既使用で本日を含む診断。金融は新規帯、保有は実時間分割。PRE/POSTとNight合計を重複合算しない。未知はnullで空欄となり、既知寄与と全件確定を分ける。累計全件確定は最初の未知以降null。0取引場も残す。日時はJST文字列。'}
    proof = {'成功': True, '候補数': len(records), 'CSV予定数': len(records)*len(NAMES),
        '行数': {k: len(v['rows']) for k, v in tables.items()}, '候補帯の照合': checks,
        'データセル': sum(len(t['headers'])*len(t['rows']) for t in tables.values()),
        '同一CSVへの異候補混在': False, '未知を0円化': False, 'CSV本体の作成': False}
    return body, proof


def main() -> None:
    """
    機能: 保存候補と外部短名からJSON中間入力だけを生成する。
    引数: CLI --input/--mapping/--output、任意--proof(Path文字列)。
    返り値: None。CSV・xlsx・preview・markerは作成しない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', type=Path, required=True); parser.add_argument('--mapping', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True); parser.add_argument('--proof', type=Path)
    args = parser.parse_args(); before = [ref(args.input), ref(args.mapping)]
    body, proof = build(read(args.input), read(args.mapping), {'ALL': 81, 'DAY': 41, 'PRE': 40, 'POST': 40, 'NIGHT': 40})
    body['inputs'] = before; body['Source'] = ref(Path(__file__))
    assert not args.output.exists(); args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(body, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')
    assert before == [ref(args.input), ref(args.mapping)]
    proof.update({'入力': before, 'Source': ref(Path(__file__)), '型付き入力': ref(args.output)})
    if args.proof:
        assert not args.proof.exists(); args.proof.parent.mkdir(parents=True, exist_ok=True)
        args.proof.write_text(json.dumps(proof, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(proof, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
