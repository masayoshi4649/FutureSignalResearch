"""生成した54CSVを再読し、型付き正本の全セルと候補分離を照合する。"""
from pathlib import Path
from decimal import Decimal
import csv
import hashlib
import io
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).parent
OUT = ROOT / 'outputs/00183_単純IFDの入口比較'


def equal(text: str, expected: object) -> bool:
    """
    機能: CSV文字列を元セルの型に応じて比較する。
    引数: text(str)、expected(object)はJSONの型付き値。
    返り値: bool。未知の空欄と数値0を区別する。
    """
    if expected is None:
        return text == ''
    if isinstance(expected, bool):
        return text == str(expected).lower()
    if isinstance(expected, (int, float)):
        return Decimal(text) == Decimal(str(expected))
    return text == expected


def main() -> None:
    """
    機能: UTF-8 BOM、候補混在なし、全場残存、全セル一致を確認する。
    引数: なし。生成入力2件と対応する出力54件を使う。
    返り値: None。JSON検査票を保存する。
    """
    proof = {'成功': True, 'files': [], '全セル照合': 0, 'CSV数': 0, '異候補混在': False}
    visited = set()
    for file in ('NK型付き入力.json', 'TOPIX型付き入力.json'):
        data = json.loads((HERE/file).read_text(encoding='utf-8'))
        candidates = sorted({r[0] for r in data['tables']['候補比較']['rows']})
        for candidate in candidates:
            for name, table in data['tables'].items():
                path = OUT / candidate.replace(':', '_') / (data['tableNames'][name] + '.csv')
                assert path not in visited
                visited.add(path)
                original = [table['headers']] + [r for r in table['rows'] if r[0] == candidate]
                raw = path.read_bytes()
                assert raw.startswith(b'\xef\xbb\xbf')
                actual = list(csv.reader(io.StringIO(raw.decode('utf-8-sig'), newline='')))
                assert len(actual) == len(original)
                for observed, expected in zip(actual, original, strict=True):
                    assert len(observed) == len(expected)
                    assert all(equal(a, b) for a, b in zip(observed, expected, strict=True)), path
                assert all(row[0] == candidate for row in actual[1:])
                if name in ('デイ', 'ナイト_米前', 'ナイト_米後', 'ナイト合計'):
                    assert len(actual)-1 == (41 if name == 'デイ' else 40)
                cells = sum(len(r) for r in actual)
                proof['全セル照合'] += cells
                proof['files'].append({'path': path.relative_to(ROOT).as_posix(), 'bytes': len(raw),
                    'sha256': hashlib.sha256(raw).hexdigest(), 'データ行': len(actual)-1, '照合セル': cells})
    assert visited == set(OUT.glob('*/*.csv')) and len(visited) == 54
    proof['CSV数'] = len(visited)
    (HERE/'CSV再読確認.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({k: proof[k] for k in ('成功', 'CSV数', '全セル照合', '異候補混在')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
