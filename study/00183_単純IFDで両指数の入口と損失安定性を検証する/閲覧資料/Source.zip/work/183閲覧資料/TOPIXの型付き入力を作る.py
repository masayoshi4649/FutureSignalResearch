"""TOPIXの固定5候補を、未知と0取引場を保つ候補別閲覧表へ変換する。"""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import gzip
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).parent
sys.path.insert(0, str(ROOT / 'work/183損失安定性'))
import 安定性183 as S

NAMES = {'候補比較': '集計', 'デイ': 'デイ', 'ナイト_米前': 'ナイト_米前',
         'ナイト_米後': 'ナイト_米後', 'ナイト合計': 'ナイト合計', '取引明細': '取引明細'}
CHOICES = [
    (183, 'T0_二足順行', '183:TOPIX_T0旧足', '幅15の固定基準'),
    (183, 'R0_弱トレンド反転', '183:TOPIX_R0旧足', '実側反転の前の固定対照'),
    (183, 'M4_広い複合とスパイク除外', '183:TOPIX_M4旧足', '直接足形成の前の固定対照'),
    (184, 'C1_R0_弱トレンド反転', '184:TOPIX_C1R0反転', '旧足・実側反転・全80と前48のDay幅15順位1位・未参加あり'),
    (184, 'C2_M4_広い複合とスパイク除外', '184:TOPIX_C2M4直接足', '全Day参加の診断例・両中央値赤字・不採用'),
]
SUMMARY = ['候補', '選択区分', '対象帯', '対象場数', '取得場数', '利益円_既知', '損失円_既知',
    '収支円_既知分', '収支円_全件確定', '取得回数', '金融未知件数', '赤字場数_確定', '未知場数',
    '赤字場率下限', '赤字場率上限', '赤字取引率下限', '赤字取引率上限', '保有率下限', '保有率上限',
    '建玉中央値下限円', '建玉中央値上限円', '場中央値下限円', '場中央値上限円', '両中央値黒字',
    '最長連続赤字場下限', '最長連続赤字場上限', '場末DD円_既知寄与', '全件経路確定',
    'F', 'A', 'N', 'C', '到達済み先着率', 'IFD対称幅pt', '期限分', '往復手数料円', '往復追加滑り円', '原候補ID']
SCENE = ['候補', '選択区分', 'セッション日', 'セッションID', '利益円_既知', '損失円_既知',
    '収支円_既知分', '収支円_全件確定', '累計収支円_既知分', '累計収支円_全件確定', '取得回数',
    '金融未知件数', '累計金融未知件数', '保有率下限', '保有率上限', '保有分下限', '保有分上限',
    '対象分', '保有20%以上確定', 'F', 'A', 'N', 'C', '終了前全決済確認', '対象開始JST',
    '対象終了JST', '純成立数_全セッション', '保有棄却数_全セッション', '失効数_全セッション',
    'IFD対称幅pt', '期限分', '原候補ID', '取引なし理由']
TRADE = ['候補', '取引番号', 'セッションID', '新規時間帯', '方向', '取得時刻JST', '決済時刻JST',
    '取得BBO価格', '決済BBO価格', '売買差pt', '往復手数料円', '往復追加滑り円', '利益円_既知',
    '損失円_既知', '費用後損益円', '累計収支円_既知分', '累計収支円_全件確定', '金融未知件数',
    '累計金融未知件数', '保有分下限', '保有分上限', '決済理由', '未知理由', '先着区分', 'IFD対称幅pt',
    '期限分', '要求時刻JST', '要求原行', '取得原行', '決済原行', '原候補ID', '正本台帳行']


def money(value: float | None) -> float | None:
    """
    機能: 円金額だけを元の費用精度で丸め、浮動小数の表示誤差を除く。
    引数: value(float|None)。
    返り値: float|None。未知は未知のまま。
    """
    return None if value is None else round(value, 1)


def local(value: float | None) -> str | None:
    """
    機能: 観測時計をJST文字列へ変換する。
    引数: value(float|None)はUnix秒。
    返り値: str|None。未知の時刻を補完しない。
    """
    return None if value is None else datetime.fromtimestamp(value, timezone(timedelta(hours=9))).strftime('%Y-%m-%d %H:%M:%S')


def ref(path: Path) -> dict:
    """
    機能: 入力・Sourceの内容指紋を取得する。
    引数: path(Path)。
    返り値: dictは相対path、bytes、sha256。
    """
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def select(ledger: dict, band: str) -> list[int]:
    """
    機能: 新規要求時に固定された帯で台帳行を選ぶ。
    引数: ledger(dict)、band(str)はALL/DAY/NIGHT/PRE/POST。
    返り値: list[int]は元台帳の添字。
    """
    phase = {'DAY': 0, 'PRE': 1, 'POST': 2}
    return [i for i, p in enumerate(ledger['phase'])
            if band == 'ALL' or (band == 'NIGHT' and p > 0) or (band in phase and p == phase[band])]


def main() -> None:
    """
    機能: 固定5候補を読み、全81場・三帯・単一建玉の6表を候補別に準備する。
    引数: なし。CHOICESは閲覧する固定候補だけで採用判断を変更しない。
    返り値: None。型付きJSONと金融・保有の照合記録を保存する。
    """
    tables = {name: {'headers': SUMMARY if name == '候補比較' else TRADE if name == '取引明細' else SCENE,
                     'rows': []} for name in NAMES}
    inputs, checks, correspondences = [], [], []
    for trial, code, candidate, role in CHOICES:
        identity = f'TOPIX{trial}_{code}_W15_H60'
        path = ROOT / f'work/{trial}TOPIX/金融正本' / (identity + '.json.gz')
        inputs.append(ref(path))
        pack = json.loads(gzip.decompress(path.read_bytes()))
        ledger = pack['ledger']; n = len(ledger['net'])
        assert all(len(v) == n for v in ledger.values())
        assert pack['id'] == identity and len(pack['sessions']) == 81
        assert len(pack['positions']) == n
        groups = S.evaluate_pack(pack)['groups']
        windows = {s['scene']: s for s in pack['sessions']}
        diagnostics = {d['scene']: d for d in pack['diagnostics']}
        positions = {(p['scene'], p['fill']): p for p in pack['positions']}
        assert len(positions) == n
        correspondences.append({'表示ID': candidate, '原候補ID': identity, '選択区分': role})
        for band in ('ALL', 'DAY', 'PRE', 'POST', 'NIGHT'):
            g = groups[band]; t, s, h = g['trades'], g['sessions'], g['holding']
            ix = select(ledger, band)
            values = [ledger['net'][i] for i in ix if ledger['known'][i]]
            assert len(ix) == t['all_count'] and len(ix) - len(values) == t['unknown_count']
            labels = [ledger['label'][i] for i in ix]
            fanc = [labels.count(k) for k in ('F', 'A', 'N', 'C')]
            assert sum(fanc) == len(ix)
            tables['候補比較']['rows'].append([candidate, role, band, s['eligible_count'], s['participating_count'],
                money(t['known_profit']), money(t['known_loss']), money(t['known_net']),
                money(t['known_net']) if not t['unknown_count'] else None, len(ix), t['unknown_count'],
                s['negative_rate']['negative_count'], s['unknown_count'], s['negative_rate']['lower'], s['negative_rate']['upper'],
                t['negative_rate']['lower'], t['negative_rate']['upper'], h['held_lower_ratio'], h['held_upper_ratio'],
                money(t['net_median']['lower']), money(t['net_median']['upper']), money(s['net_median']['lower']), money(s['net_median']['upper']),
                g['both_medians_positive'], s['negative_streak']['lower'], s['negative_streak']['upper'],
                money(g['path']['known_contribution']['max_drawdown']['amount']), g['path']['full_exact'] is not None,
                *fanc, fanc[0]/sum(fanc[:2]) if sum(fanc[:2]) else None, 15, 60, 83.6, 500, identity])
            if band == 'ALL':
                continue
            name = {'DAY': 'デイ', 'PRE': 'ナイト_米前', 'POST': 'ナイト_米後', 'NIGHT': 'ナイト合計'}[band]
            held = {r['scene']: r for r in S.hold_rows(pack['sessions'], pack['positions'], band)}
            assert len(held) == s['eligible_count'] == (41 if band == 'DAY' else 40)
            cumulative, uncertain = 0., 0
            for row in s['rows']:
                scene = row['scene']; time = held[scene]
                matches = [i for i in ix if ledger['scene'][i] == scene]
                cumulative += row['known_net']; uncertain += row['unknown_count']
                assert len(matches) == row['all_count']
                labels = [ledger['label'][i] for i in matches]
                all_positions = [p for p in pack['positions'] if p['scene'] == scene]
                flat = '未知' if any(p['exit'] is None for p in all_positions) else '確認済'
                assert all(p['exit'] is None or p['exit'] <= windows[scene]['end'] for p in all_positions)
                seconds = time['eligible_seconds']; lower = time['held_lower_seconds']; upper = time['held_upper_seconds']
                d = diagnostics[scene]
                why = '' if matches else ('純成立なし。足の履歴・品質と条件成立を診断資料で区別。' if d['純成立'] == 0
                    else '当帯の取得なし。全セッションの純成立・保有棄却・失効を併記。')
                tables[name]['rows'].append([candidate, role, scene.split('_')[0], scene,
                    money(row['known_profit']), money(row['known_loss']), money(row['known_net']), money(row['all_net']),
                    money(cumulative), money(cumulative) if not uncertain else None, len(matches), row['unknown_count'], uncertain,
                    lower/seconds, upper/seconds, lower/60, upper/60, seconds/60, lower/seconds >= .2,
                    *[labels.count(k) for k in ('F', 'A', 'N', 'C')], flat, local(time['start']), local(time['end']),
                    d['純成立'], d['保有棄却'], d['失効'], 15, 60, identity, why])
            assert abs(cumulative - t['known_net']) < 1e-6 and uncertain == t['unknown_count']
            assert abs(sum(v['held_lower_seconds'] for v in held.values()) - h['held_lower_seconds']) < 1e-6
            checks.append({'候補': candidate, '帯': band, '金融累計一致': True, '未知一致': True, '保有秒一致': True})

        # ----------------------------------------
        cumulative, uncertain = 0., 0
        order = sorted(range(n), key=lambda i: (ledger['entry_time'][i], i))
        for number, i in enumerate(order, 1):
            net = ledger['net'][i]; known = ledger['known'][i]
            assert bool(known) == (net is not None)
            cumulative += net if known else 0.; uncertain += not known
            sign = ledger['side'][i]; assert sign in (-1, 1)
            points = None if not known else sign * (ledger['exit_price'][i] - ledger['entry_price'][i])
            if known:
                assert abs(points - ledger['gross_pt'][i]) < 1e-8
                assert abs(net - round(points*1000 - 83.6 - 500, 1)) < 1e-8
            p = positions[(ledger['scene'][i], ledger['entry_time'][i])]
            lo = p['exit'] if p['exit'] is not None else p['confirmed_until']
            hi = p['exit'] if p['exit'] is not None else p['possible_until']
            tables['取引明細']['rows'].append([candidate, number, ledger['scene'][i],
                ('DAY', 'PRE', 'POST')[ledger['phase'][i]], '買い' if sign == 1 else '売り',
                local(ledger['entry_time'][i]), local(ledger['exit_time'][i]), ledger['entry_price'][i], ledger['exit_price'][i], points,
                83.6 if known else None, 500 if known else None, max(net, 0.) if known else None, max(-net, 0.) if known else None,
                net, money(cumulative), money(cumulative) if not uncertain else None, int(not known), uncertain,
                (lo-p['fill'])/60, (hi-p['fill'])/60, ledger['reason'][i], ledger['unknown_reason'][i], ledger['label'][i],
                ledger['width'][i], 60, local(ledger['request_time'][i]), ledger['request_line'][i], ledger['entry_line'][i],
                ledger['exit_line'][i], identity, i+1])
        assert abs(cumulative-groups['ALL']['trades']['known_net']) < 1e-6
        assert inputs[-1] == ref(path)
    for table in tables.values():
        assert all(len(r) == len(table['headers']) for r in table['rows'])
    body = {'trial': 184, 'tableNames': NAMES, 'tables': tables, '候補対応': correspondences, 'inputs': inputs,
        'Source': [ref(Path(__file__)), ref(ROOT/'work/183損失安定性/安定性183.py')],
        '定義': 'miniTOPIX1枚。1pt1000円、片道41.8円、追加滑り片道0.25pt、ラージBBO代理。幅15/H60の単純IFD。全81場は既使用。金融は新規帯、保有は実時間で配分。未知は空欄、0取引場を残す。PRE/POSTとNight合計は重複合算しない。'}
    proof = {'成功': True, '候補数': len(CHOICES), 'CSV予定数': len(CHOICES)*len(NAMES), '照合': checks,
        '入力': inputs, 'Source': body['Source'], 'データセル': sum(len(t['headers'])*len(t['rows']) for t in tables.values())}
    for name, value in [('TOPIX型付き入力.json', body), ('TOPIX入力照合.json', proof)]:
        path = HERE / name; assert not path.exists()
        path.write_text(json.dumps(value, ensure_ascii=False, allow_nan=False)+'\n', encoding='utf-8')
    print(json.dumps({k: proof[k] for k in ('成功', '候補数', 'CSV予定数', 'データセル')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
