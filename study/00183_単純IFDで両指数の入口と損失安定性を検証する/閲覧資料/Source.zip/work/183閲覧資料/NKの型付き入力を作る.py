"""183のNK225固定4候補を、候補別CSV用の型付き表へ変換する。"""
from pathlib import Path
import gzip
import importlib.util
import json
import re

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).parent
BASE = ROOT / 'work/182閲覧資料/型付き入力を作る.py'
spec = importlib.util.spec_from_file_location('csv182', BASE)
B = importlib.util.module_from_spec(spec)
spec.loader.exec_module(B)
MAPPING = {
    'E183_00__C0_IFD': {'short': 'NK00_旧入口', 'role': '固定基準・旧179入口・単純IFD'},
    'E183_01__C0_IFD': {'short': 'NK01_BO確認待ち', 'role': '固定対照・一律確認で損失と赤字場を分ける'},
    'E183_04__C0_IFD': {'short': 'NK04_EM追加', 'role': '全80Day発見順位1位・Nightは不採用'},
    'E183_06__C0_IFD': {'short': 'NK06_EM方向確認', 'role': '前48Day選択順位1位・未見検証ではない'},
}


def display(identity: str, mapping: dict) -> tuple[str, str]:
    """
    機能: 183専用の候補短名と選択区分を返す。
    引数: identity(str)は正本ID、mapping(dict)は閲覧対応。
    返り値: tuple[str,str]は候補名と選択区分。
    """
    value = mapping[identity]
    candidate = '183:' + value['short']
    assert re.fullmatch(r'183:[^<>:"/\\|?*]+', candidate)
    assert all(len(candidate.replace(':', '_') + '_' + name) <= 31 for name in B.NAMES.values())
    return candidate, value['role']


def main() -> None:
    """
    機能: 保存済み台帳を全セルの型を保つJSONへ変換し、金融・保有を照合する。
    引数: なし。固定対応表と183の集約済み台帳を読む。
    返り値: None。CSVそのものは別の共通出力器で作成する。
    """
    B.display = display
    paths = [ROOT / 'work/183単純IFD検証/集約' / (identity + '.json.gz') for identity in MAPPING]
    records = [json.loads(gzip.decompress(path.read_bytes())) for path in paths]
    before = [B.ref(path) for path in paths]
    body, proof = B.build({'rows': records}, MAPPING,
                         {'ALL': 81, 'DAY': 41, 'PRE': 40, 'POST': 40, 'NIGHT': 40})
    body['trial'] = 183
    body['定義'] = body['定義'].replace('本日', '11月16日デイ')
    body['inputs'] = before
    body['Source'] = [B.ref(Path(__file__)), B.ref(BASE)]

    # ----------------------------------------
    for table in body['tables'].values():
        table['headers'] = [v.replace('旧主取得', '主入口取得').replace('新LC取得', '継承LC取得')
                            for v in table['headers']]
    table = body['tables']['取引明細']
    at = table['headers'].index('入口区分')
    for row in table['rows']:
        if row[at] == '新LC':
            row[at] = '継承LC'
    assert before == [B.ref(path) for path in paths]
    proof.update({'入力': before, 'Source': body['Source'], '候補対応': body['候補対応']})
    HERE.mkdir(parents=True, exist_ok=True)
    for name, value in [('NK型付き入力.json', body), ('NK入力照合.json', proof)]:
        path = HERE / name
        assert not path.exists(), path
        path.write_text(json.dumps(value, ensure_ascii=False, allow_nan=False) + '\n', encoding='utf-8')
    print(json.dumps({k: proof[k] for k in ('成功', '候補数', 'CSV予定数', 'データセル')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
