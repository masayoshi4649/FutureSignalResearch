# 市場時刻と公表時刻を分ける純状態部品

137向けの非金融準備。自然Source・原板・CSV・金融・追加2場は未実行。本folder名はRootの準備先であり、この作業では正式試行を採番しない。

`条件.md` が今回の固定差分。旧136のmodule名と公開型/APIを保ち、Rootの別接続器でreplace先を本folderへ変更できる。`go.mod`・`types.go`・`helpers.go` は旧136とbyte同体。

- `state.go`：回復cを新5分の市場End以後に変更し、Firstが実配送より後という要件だけを外す。新5分の実配送、現在の既知性、既存TTL/cap/risk等は維持する。
- `state_test.go`：人工6群。売買鏡像、1265確認→1266出生、未来/未知の拒否と保護条件を確認する。
- `136対照_test.go.txt`：旧136にoverlayだけで追加する拒否対照。旧folderへファイルを作らない。
- `準備を確認する.py`：人工・vet・build、旧136対照、旧136/参照コード/新部品の前後SHAを検査し `準備の確認.json` を保存する。

実行は本folderで `python 準備を確認する.py`。Raw reader、Source走査、注文、損益計算は呼ばない。現在の足年齢30秒、量履歴、cache提示の接続契約は `条件.md` を参照する。
