package e1episode

import (
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"math"
	"testing"
)

// ----------------------------------------
// tq は鏡像価格の人工Rawを作ります。
//
// 引数: at/price(float64)、side(int)。返り値: Quoteです。
func tq(at, price float64, side int) Quote {
	if side < 0 {
		price = 200 - price
	}
	return Quote{Clock: "人工", Time: at, Index: int64(at - 9000), SourceLine: int64(at-9000) + 1, Last: price, Bid: price - 1, Ask: price + 1, QuoteOK: true}
}

// ----------------------------------------
// ts は固定CSV同様のEnd+60以後配送による既知公表を作ります。
//
// 引数: q(Quote)、side(int)、contact(float64)、phaseRecovered(bool)、atr(float64)。返り値: rules.Snapshotです。
func ts(q Quote, side int, contact float64, phaseRecovered bool, atr float64) rules.Snapshot {
	s := rules.Snapshot{SessionID: "人工場", Contract: "人工限月", AsOf: rq(q), Frames: map[int]rules.Publication{}, RVOL5: rules.Value{Known: true, Value: 1}}
	initial15 := math.Floor((contact-65)/900) * 900
	initial5 := math.Floor((contact-65)/300) * 300
	for _, width := range []int{300, 900, 1800} {
		end := math.Floor((q.Time-65)/float64(width)) * float64(width)
		stamp := end + 65
		t := rules.Technical{EMA8: rules.Value{Known: true, Value: 100}, EMA21: rules.Value{Known: true, Value: 100}, Gap: rules.Value{Known: true, Value: float64(side) * 10}, EMA21Delta: rules.Value{Known: true, Value: float64(side)}, ATR: rules.Value{Known: true, Value: atr}, PreviousATR: rules.Value{Known: true, Value: atr}, TR: rules.Value{Known: true, Value: 30}, RSI: rules.Value{Known: true, Value: 50 + float64(side)*5}, PreviousRSI: rules.Value{Known: true, Value: 50 + float64(side)*4}, Histogram: rules.Value{Known: true, Value: -float64(side) * 2}, PreviousHistogram: rules.Value{Known: true, Value: -float64(side) * 3}}
		if width == 300 && end > initial5 {
			t.Histogram.Value = -float64(side)
			t.PreviousHistogram.Value = -float64(side) * 2
		}
		if width == 900 && phaseRecovered && end > initial15 {
			t.Histogram.Value = float64(side)
		}
		diPlus, diMinus := 30.0, 10.0
		if side < 0 {
			diPlus, diMinus = diMinus, diPlus
		}
		p := rules.Publication{Stamp: rules.Stamp{Time: stamp, Index: int(stamp - 9000), Line: int(stamp-9000) + 1}, Frame: rules.Frame{Frame: rules.ChartFrame{ID: fmt.Sprintf("人工%d/%v", width, end), SessionID: s.SessionID, Contract: s.Contract, Width: width, Start: end - float64(width), End: end, AvailableAt: end + 60, DeliveryAt: stamp, PriceKnown: true, OHLC: rules.OHLC{Open: 100, High: 110, Low: 90, Close: 100}, Technical: t}, DMI: rules.DMI{PlusDI: rules.Value{Known: true, Value: diPlus}, MinusDI: rules.Value{Known: true, Value: diMinus}, ADX: rules.Value{Known: true, Value: 25}}}}
		s.Frames[width] = p
		s.Refs = append(s.Refs, reference(p))
	}
	return s
}

// ----------------------------------------
// tb は、閉鎖の前後時計を持つ129同型の人工1分を作ります。
//
// 引数: start/open/high/low/close/volume(float64)、side(int)。返り値: Barです。
func tb(start, open, high, low, close, volume float64, side int) Bar {
	if side < 0 {
		open, high, low, close = 200-open, 200-low, 200-high, 200-close
	}
	return Bar{Start: start, End: start + 60, OHLC: rules.OHLC{Open: open, High: high, Low: low, Close: close}, Rows: 2, First: rq(tq(start+1, 100, side)), Last: rq(tq(start+59, close, 1)), PriceKnown: true, VolumeKnown: true, Volume: volume}
}

// ----------------------------------------
// observe は、人工だけを入力し予期しないerrorを検出します。
//
// 引数: t(*testing.T)、d(*Detector)、at/price/contact/atr(float64)、side(int)、recovered(bool)、b(*Bar)、history([]Bar)。返り値: []Eventです。
func observe(t *testing.T, d *Detector, at, price, contact, atr float64, side int, recovered bool, b *Bar, history []Bar) []Event {
	t.Helper()
	q := tq(at, price, side)
	events, err := d.Observe(ts(q, side, contact, recovered, atr), q, b, history)
	if err != nil {
		t.Fatal(err)
	}
	return events
}

// ----------------------------------------
// prepared は、接触・拒否K固定・新5分改善までを連続した人工Rawで進めます。
//
// 引数: t(*testing.T)、side(int)、contact(float64)、recovered(bool)、laterATR(float64)。返り値: *Detector/新5分配送timeです。
func prepared(t *testing.T, side int, contact float64, recovered bool, laterATR float64) (*Detector, float64) {
	t.Helper()
	d := New()
	if err := d.StartSession("人工場", "人工限月"); err != nil {
		t.Fatal(err)
	}
	observe(t, d, contact, 102, contact, 40, side, false, nil, nil)
	start := math.Floor(contact/60) * 60
	b := tb(start, 100, 104, 99, 103, 150, side)
	previous := tb(start-60, 100, 101, 99, 100, 100, side)
	observe(t, d, b.End+1, 103, contact, laterATR, side, recovered, &b, []Bar{previous})
	if d.active[side] == nil || d.active[side].reject == nil {
		t.Fatal("拒否1分が固定されない")
	}
	m := math.Ceil(contact/300)*300 + 65
	for at := b.End + 56; at < m; at += 55 {
		observe(t, d, at, 102, contact, laterATR, side, recovered, nil, nil)
	}
	observe(t, d, m, 102, contact, laterATR, side, recovered, nil, nil)
	if d.active[side] == nil || d.active[side].improvement == nil {
		t.Fatal("後の5分改善が保存されない")
	}
	return d, m
}

// ----------------------------------------
// finish は、新5分後に始まった別1分と2Raw/1秒の維持を人工生成します。
//
// 引数: t(*testing.T)、d(*Detector)、side(int)、contact/m/atr(float64)、recovered(bool)。返り値: Eventです。
func finish(t *testing.T, d *Detector, side int, contact, m, atr float64, recovered bool) Event {
	t.Helper()
	start := math.Floor(m/60)*60 + 60
	for at := m + 55; at < start+60; at += 55 {
		observe(t, d, at, 102, contact, atr, side, recovered, nil, nil)
	}
	b := tb(start, 102, 110, 101, 109, 200, side)
	p := tb(start-60, 102, 103, 101, 102, 100, side)
	if events := observe(t, d, b.End+1, 109, contact, atr, side, recovered, &b, []Bar{p}); len(events) != 0 {
		t.Fatal("1行だけで出生")
	}
	events := observe(t, d, b.End+2, 109, contact, atr, side, recovered, nil, nil)
	if len(events) != 1 {
		t.Fatalf("成立可能経路が出生しない: %+v", d.Lifecycle())
	}
	return events[0]
}

// ----------------------------------------
// marketPrepared は、拒否Kの後で市場End以後のcを新5分配送原行に提示します。
//
// 引数: t(*testing.T)、side(int)、contact/offset/atr(float64)、recovered(bool)、last(float64)。返り値: *Detector/配送timeです。
func marketPrepared(t *testing.T, side int, contact, offset, atr float64, recovered bool, last float64) (*Detector, float64) {
	t.Helper()
	d := New()
	if err := d.StartSession("人工場", "人工限月"); err != nil {
		t.Fatal(err)
	}
	observe(t, d, contact, 102, contact, 40, side, false, nil, nil)
	start := math.Floor(contact/60) * 60
	b := tb(start, 100, 104, 99, 103, 150, side)
	p := tb(start-60, 100, 101, 99, 100, 100, side)
	observe(t, d, b.End+1, 103, contact, atr, side, recovered, &b, []Bar{p})
	mEnd := math.Ceil(contact/300) * 300
	delivery := mEnd + offset
	for at := b.End + 56; at < delivery; at += 55 {
		observe(t, d, at, 102, contact, atr, side, recovered, nil, nil)
	}
	q := tq(delivery, last, side)
	s := marketSnapshot(q, side, contact, recovered, atr, mEnd, delivery)
	c := tb(mEnd, 102, 110, 101, 109, 200, side)
	c.First = rq(tq(mEnd, 102, side))
	previous := tb(mEnd-60, 102, 103, 101, 102, 100, side)
	events, err := d.Observe(s, q, &c, []Bar{previous})
	if err != nil || len(events) != 0 {
		t.Fatalf("現在知得のcを確認できない: %+v %v", events, err)
	}
	return d, delivery
}

// ----------------------------------------
// marketSnapshot は、人工の早い配送を次Rawでも同じ公表Stampのまま保持します。
//
// 引数: q(Quote)、side(int)、contact/atr/marketEnd/delivery(float64)、recovered(bool)。返り値: rules.Snapshotです。
func marketSnapshot(q Quote, side int, contact float64, recovered bool, atr, marketEnd, delivery float64) rules.Snapshot {
	s := ts(tq(math.Max(q.Time, marketEnd+65), 100, side), side, contact, recovered, atr)
	s.AsOf = rq(q)
	for width, pub := range s.Frames {
		if pub.Stamp.Time > delivery {
			pub.Stamp = rules.Stamp{Time: delivery, Index: int(delivery - 9000), Line: int(delivery-9000) + 1}
			pub.Frame.Frame.DeliveryAt = delivery
			s.Frames[width] = pub
		}
	}
	s.Refs = nil
	for _, width := range []int{300, 900, 1800} {
		s.Refs = append(s.Refs, reference(s.Frames[width]))
	}
	return s
}

// ----------------------------------------
// TestMarketTimeRecoveryAndMirror は、136で拒否した市場足を現在知得後に確認し鏡像出生させます。
//
// 引数: t(*testing.T)。返り値: なし。First.Time==m.Endを半開区間として許可します。
func TestMarketTimeRecoveryAndMirror(t *testing.T) {
	for _, side := range []int{1, -1} {
		d, m := marketPrepared(t, side, 10000, 65, 80, false, 109)
		if d.active[side] == nil || d.active[side].confirmed == nil {
			t.Fatal("配送前に形成した既知cを拒否")
		}
		events := observe(t, d, m+1, 109, 10000, 80, side, false, nil, nil)
		if len(events) != 1 {
			t.Fatal("1秒後に出生しない")
		}
		e := events[0]
		if e.At.Time != 10266 || e.ATR5 != 40 || e.Fields["recovery_bar_clock"] != "market_end" || e.Fields["hold_rows"] != 2 || e.Fields["t8_applied"] != false {
			t.Fatal("時計版/ATR/hold/方向規則が違う")
		}
		if e.EntryCap != 100+float64(side)*19 {
			t.Fatal("接触ATRのcapを緩和")
		}
	}
}

// ----------------------------------------
// TestZeroOneFiveSecondDelivery は、0/1/5秒の配送位相でも市場足確認は期限を緩めず成立することを示します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestZeroOneFiveSecondDelivery(t *testing.T) {
	for _, offset := range []float64{60, 61, 65} {
		d, m := marketPrepared(t, 1, 10000, offset, 40, false, 109)
		q := tq(m+1, 109, 1)
		events, err := d.Observe(marketSnapshot(q, 1, 10000, false, 40, 10200, m), q, nil, nil)
		if err != nil || len(events) != 1 || events[0].Fields["recovery_expires"] != m+120 {
			t.Fatal("市場時刻への分離で期限自体を変更")
		}
	}
}

// ----------------------------------------
// TestNoFutureNoUndeliveredNoPriorMarketFoot は、未知のm/未来c/市場End前のcを拒否します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestNoFutureNoUndeliveredNoPriorMarketFoot(t *testing.T) {
	for _, mode := range []string{"未来m", "未配送m", "未来c", "市場End前c", "量未知"} {
		d := New()
		_ = d.StartSession("人工場", "人工限月")
		observe(t, d, 10000, 102, 10000, 40, 1, false, nil, nil)
		b := tb(9960, 100, 104, 99, 103, 150, 1)
		p := tb(9900, 100, 101, 99, 100, 100, 1)
		observe(t, d, 10021, 103, 10000, 40, 1, false, &b, []Bar{p})
		for at := 10076.0; at < 10265; at += 55 {
			observe(t, d, at, 102, 10000, 40, 1, false, nil, nil)
		}
		q := tq(10265, 109, 1)
		s := ts(q, 1, 10000, false, 40)
		c := tb(10200, 102, 110, 101, 109, 200, 1)
		previous := tb(10140, 102, 103, 101, 102, 100, 1)
		if mode == "未来m" {
			pub := s.Frames[300]
			pub.Stamp.Time = q.Time + 1
			s.Frames[300] = pub
			s.Refs[0] = reference(pub)
		}
		if mode == "未配送m" {
			delete(s.Frames, 300)
			s.Refs = s.Refs[1:]
		}
		if mode == "未来c" {
			c = tb(10260, 102, 110, 101, 109, 200, 1)
		}
		if mode == "市場End前c" {
			c = tb(10140, 102, 110, 101, 109, 200, 1)
			previous = tb(10080, 102, 103, 101, 102, 100, 1)
		}
		if mode == "量未知" {
			c.VolumeKnown = false
		}
		events, _ := d.Observe(s, q, &c, []Bar{previous})
		if len(events) != 0 {
			t.Fatal("当時利用不能又は量不明の足で出生")
		}
		if e := d.active[1]; e != nil && e.confirmed != nil {
			t.Fatalf("不正な回復を保存: %s", mode)
		}
	}
}

// ----------------------------------------
// TestCurrentCapAndStrictExpiry は、当時Lastがcap外なら待機し120秒等号も拒否します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestCurrentCapAndStrictExpiry(t *testing.T) {
	d, m := marketPrepared(t, 1, 10000, 65, 40, false, 120)
	if events := observe(t, d, m+1, 120, 10000, 40, 1, false, nil, nil); len(events) != 0 {
		t.Fatal("現在Lastがcap超過なのに出生")
	}
	for at := m + 56; at < m+120; at += 55 {
		observe(t, d, at, 120, 10000, 40, 1, false, nil, nil)
	}
	if events := observe(t, d, m+120, 109, 10000, 40, 1, false, nil, nil); len(events) != 0 || d.Stats().Active != 0 {
		t.Fatal("120秒等号で出生")
	}
}

// ----------------------------------------
// TestSavedPhaseAndIDConsumption は、15分の正回復後も保存位相を使い、同ID再使用をしません。
//
// 引数: t(*testing.T)。返り値: なし。
func TestSavedPhaseAndIDConsumption(t *testing.T) {
	d, m := marketPrepared(t, 1, 10700, 65, 40, true, 109)
	if events := observe(t, d, m+1, 109, 10700, 40, 1, true, nil, nil); len(events) != 1 {
		t.Fatal("確認時の正Hist15で保存位相を取消し")
	}
	d = New()
	_ = d.StartSession("人工場", "人工限月")
	observe(t, d, 10000, 102, 10000, 40, 1, false, nil, nil)
	d.RejectClock("人工欠分")
	observe(t, d, 10001, 102, 10000, 40, 1, false, nil, nil)
	if d.Stats().Episodes != 1 || d.Stats().Active != 0 {
		t.Fatal("同15分IDの再arming")
	}
}

// ----------------------------------------
// TestCooldownAndCurrentUnknown は、600秒と現在未知取消しを136と同じまま確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestCooldownAndCurrentUnknown(t *testing.T) {
	d, m := prepared(t, 1, 10000, false, 40)
	e := finish(t, d, 1, 10000, m, 40, false)
	for at := e.At.Time + 55; at < e.At.Time+599; at += 55 {
		observe(t, d, at, 102, 10000, 40, 1, false, nil, nil)
	}
	observe(t, d, e.At.Time+599, 102, 10000, 40, 1, false, nil, nil)
	if d.Stats().Active != 0 {
		t.Fatal("600秒前に再準備")
	}
	observe(t, d, e.At.Time+600, 102, 10000, 40, 1, false, nil, nil)
	if d.Stats().Active != 1 {
		t.Fatal("600秒等号を拒否")
	}
	q := tq(e.At.Time+601, 102, 1)
	s := ts(q, 1, 10000, false, 40)
	p := s.Frames[300]
	p.Frame.Frame.Technical.Histogram = rules.Value{}
	s.Frames[300] = p
	if _, err := d.Observe(s, q, nil, nil); err != nil || d.Stats().Active != 0 {
		t.Fatal("現在背景未知で取消さない")
	}
}
