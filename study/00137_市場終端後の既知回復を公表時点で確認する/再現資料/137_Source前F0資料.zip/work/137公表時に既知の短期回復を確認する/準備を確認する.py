"""137純状態の人工だけを実行し、136不変更と市場時刻差分を確認する。"""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import subprocess
import sys

OWN = Path(__file__).resolve().parent
OLD = OWN.parent / '押戻し位相を保存して回復を待つ入口'
ROOT = OWN.parent.parent
FROZEN = {
    'go.mod': '25acd16cc2b54313c78f99fc648f5b97731196bb23b7f07e43ba7f43ec0a0ed1',
    'types.go': 'ee517fc44a2019c54969e8b0da49d695e67eb8734de475ce2e5bd2936d7b2939',
    'helpers.go': 'bbf8bca5dd0c2cf6426a80353ebad0118ab71d826f2261d6da494c60897c7042',
    'state.go': '56ea24d00eecfd853049f8fecd03b381c78fc2753e9a93b95be3213aa5259dd2',
    'state_test.go': '39a84cdbce16ae186d42d9341962a3aaf36f5fabdb17845708bb00c13333a683',
    '条件表と差分案.md': '5ef2efd5b66c64e72595fc817ddabcc7bb25f020ec6893e12d6166b143f31664',
    'README.md': '1dcaa8d2ec2a13a0b29b3c59dd07dda181e67164cabcb91fe3c4a86a33e3d489',
    '準備を確認する.py': 'f5a8616f78d368a8e1d2d7e31ede5a011d6d2700393782566183ab2211f0e140',
    '準備の確認.json': 'ce4d201c02004da32ef99c6b938082cb351e5a21cfec102701db8b3fef44bd15',
}


# ----------------------------------------
def sha(path: Path) -> str:
    """
    機能: 指定したコード・文書のbytes指紋を得る。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def execute(spec: tuple[str, Path, list[str]]) -> tuple[str, subprocess.CompletedProcess]:
    """
    機能: 自然入力を持たないGo検査を指定folderで実行する。
    引数: spec(tuple[str,Path,list[str]])。返り値: tuple[str,CompletedProcess]。
    """
    name, folder, command = spec
    return name, subprocess.run(command, cwd=folder, capture_output=True, text=True, encoding='utf-8')


# ----------------------------------------
def main() -> None:
    """
    機能: 新部品と旧版対照を人工検査し、不変指紋を証跡へ保存する。
    引数: なし。返り値: None。自然Source/Raw/CSV/金融を一切呼ばない。
    """
    sys.stdout.reconfigure(encoding='utf-8')
    names = ['go.mod', 'types.go', 'helpers.go', 'state.go', 'state_test.go',
             '136対照_test.go.txt', '条件.md', 'README.md', '準備を確認する.py']
    before = {name: sha(OWN / name) for name in names}
    old_before = {name: sha(OLD / name) for name in FROZEN}
    assert old_before == FROZEN, old_before
    identical = ['go.mod', 'types.go', 'helpers.go']
    assert all((OWN / name).read_bytes() == (OLD / name).read_bytes() for name in identical)

    # ----------------------------------------
    # 原定義との差分を文字列逆変換で固定し、別ロジックの変更を拒否する。
    old_text = (OLD / 'state.go').read_text(encoding='utf-8')
    new_text = (OWN / 'state.go').read_text(encoding='utf-8')
    operations = [
        ('// recover は、改善配送後に始まった別1分のClose/同足量/実Lastだけを確認します。',
         '// recover は、新5分の市場End以後の既知別1分を現在のClose/同足量/実Lastで確認します。'),
        ('m := e.improvement.Stamp', 'marketEnd := e.improvement.Frame.Frame.End'),
        ('b.Start < m.Time || b.End <= e.reject.End || b.Start < e.reject.End || b.First.Index <= m.Index || b.First.Line <= m.Line ||',
         'b.Start < marketEnd || b.End <= e.reject.End || b.Start < e.reject.End ||'),
        ('"新5分配送後の別確定足"', '"新5分市場End以後の既知確定足"'),
        ('fields := map[string]any{"direction_policy":',
         'fields := map[string]any{"recovery_bar_clock": "market_end", "direction_policy":'),
    ]
    expected = old_text
    for source, replacement in operations:
        assert expected.count(source) == 1, source
        expected = expected.replace(source, replacement)
    assert expected == new_text
    ref_folder = ROOT / 'work/118複数技法の入口条件'
    refs = sorted(ref_folder.glob('*.go')) + [ref_folder / 'go.mod']
    ref_before = {str(path): sha(path) for path in refs}

    # ----------------------------------------
    # 旧版の仮想testだけをoverlayし、旧136の現物は一切編集しない。
    virtual = OLD / '独立137市場時計対照_test.go'
    assert not virtual.exists()
    overlay = OWN / '旧136対照のoverlay.json'
    overlay.write_text(json.dumps({'Replace': {str(virtual): str(OWN / '136対照_test.go.txt')}},
                                  ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    commands = [
        ('人工', OWN, ['go', 'test', '-count=1', '-json', './...']),
        ('静的検査', OWN, ['go', 'vet', './...']),
        ('build', OWN, ['go', 'build', './...']),
        ('旧136拒否対照', OLD, ['go', 'test', '-count=1', '-json', '-overlay', str(overlay),
                           '-run', '^TestOld136RejectsMarketRecovery$', './...']),
    ]
    checks = {}
    with ThreadPoolExecutor(max_workers=4) as pool:
        for name, result in pool.map(execute, commands):
            assert result.returncode == 0, result.stdout + result.stderr
            log = OWN / (name + 'のログ.txt')
            log.write_text(result.stdout + result.stderr, encoding='utf-8')
            checks[name] = {'exit_code': result.returncode, 'log_sha256': sha(log)}
            if name in ('人工', '旧136拒否対照'):
                events = [json.loads(line) for line in result.stdout.splitlines() if line.startswith('{')]
                passed = [event['Test'] for event in events
                          if event.get('Action') == 'pass' and event.get('Test')]
                assert len(passed) == (6 if name == '人工' else 1)
                assert not any(event.get('Action') in ('fail', 'skip') for event in events)
                checks[name]['passed'] = passed
    assert not virtual.exists()
    assert before == {name: sha(OWN / name) for name in names}
    assert old_before == {name: sha(OLD / name) for name in FROZEN}
    assert ref_before == {str(path): sha(path) for path in refs}
    proof = {
        '成功': True, '段階': '137純状態の非金融準備のみ。自然Source未実行・正式採番なし',
        'module': 'github.com/masayoshi4649/SessionTradeExecuter/e1episode', 'package': 'e1episode',
        'API': ['New', 'StartSession', 'Observe', 'RejectClock', 'Stats', 'Lifecycle'],
        '回復時計': 'market_end', '本部品SHA256': before, '旧136固定SHA256': old_before,
        '参照コードSHA256': ref_before, '旧版とbyte同体のファイル': identical,
        '旧stateからの変更操作数': len(operations), '変更操作': operations, '検査': checks,
        '人工成功時計': {'contact': 10000, 'K_fixed': 10021, 'm_end': 10200, 'm_delivery': 10265,
                         'c_start': 10200, 'c_first': 10200, 'c_end': 10260, 'confirm_raw': 10265,
                         'birth_raw': 10266, 'hold_rows': 2, 'recovery_expires_exclusive': 10385,
                         'episode_expires_exclusive': 10900},
        '保持': ['実配送後のみ確認', '回復足の現在年齢30秒', '900/120秒等号失効',
                 '接触ATRとK/I/cap固定', '同足量とその直前足', '売買鏡像',
                 '保存15分位相とID消費', '600秒cooldown', '場回数capなし'],
        '前後同体': {'新部品': True, '旧136': True, '参照コード': True},
        '自然RawとCSV本文読取': False, '自然Source実行': False, '追加2場本文読取': False,
        '金融結果読取': False, '新勝敗と損益計算': False, '新試行採番': False,
        '統合側の分離範囲': ['閉鎖済み1分と直前履歴cacheの値copy',
                            '新5分実配送原行だけのcache再提示とreset破棄',
                            'E0/L0/E1競合と次1秒実BBO取得', '137時計markerを明示判別する集計器'],
    }
    dest = OWN / '準備の確認.json'
    dest.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'success': True, 'proof_sha256': sha(dest), 'files': before}, ensure_ascii=True))


if __name__ == '__main__':
    main()
