package holdingohlc113

import (
	episode "github.com/masayoshi4649/SessionTradeExecuter/e1episode"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// clearRecoveryCache は、短期未知時に過去の正常閉鎖足を再提示しないよう消去します。
//
// 引数: receiver(*e1Observer)。返り値: ありません。legacyと1分Trackerには書き込みません。
func (o *e1Observer) clearRecoveryCache() {
	o.lastClosed = nil
	o.closedPrevious = nil
	o.closedAt = nil
}

// ----------------------------------------
// recoveryBar は、今回閉鎖足又は新5分配送時に限り最新の既知閉鎖足を返します。
//
// 引数: q(Quote)、s(rules.Snapshot)、closed(*episode.Bar)、previous([]episode.Bar)。
// 返り値: *episode.Bar/[]episode.Barは当時までに既知の足と直前履歴、又はnilです。
// cache再提示は現在年齢30秒以下・閉鎖確認済み・同Rawの新5分配送3項一致に限定します。
func (o *e1Observer) recoveryBar(q Quote, s rules.Snapshot, closed *episode.Bar, previous []episode.Bar) (*episode.Bar, []episode.Bar) {
	if closed != nil {
		b, at := *closed, q
		o.lastClosed = &b
		o.closedAt = &at
		o.closedPrevious = append([]episode.Bar(nil), previous...)
		return closed, previous
	}
	p, ok := s.Frames[300]
	if !ok || p.Stamp.Time != q.Time || int64(p.Stamp.Index) != q.Index || int64(p.Stamp.Line) != q.SourceLine ||
		o.lastClosed == nil || o.closedAt == nil {
		return nil, nil
	}
	if o.closedAt.Time > q.Time || o.closedAt.Index >= q.Index || o.closedAt.SourceLine >= q.SourceLine {
		return nil, nil
	}
	b := *o.lastClosed
	if !b.PriceKnown || b.End > q.Time || q.Time-b.End > 30 || b.Last.Time >= b.End ||
		int64(b.Last.Index) >= q.Index || int64(b.Last.Line) >= q.SourceLine {
		return nil, nil
	}
	return &b, append([]episode.Bar(nil), o.closedPrevious...)
}
