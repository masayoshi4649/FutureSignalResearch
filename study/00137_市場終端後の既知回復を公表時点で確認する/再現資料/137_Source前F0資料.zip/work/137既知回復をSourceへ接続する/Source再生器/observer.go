package holdingohlc113

import (
	"fmt"
	"math"

	episode "github.com/masayoshi4649/SessionTradeExecuter/e1episode"
	minute "github.com/masayoshi4649/SessionTradeExecuter/e1minute"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// sourceObserver133 は、legacyへ書き込まない追加観測の接続点です。
type sourceObserver133 interface {
	Accepted(*rules.Bank, Quote, bool, []*Candidate133, []byte) error
	Rejected(string)
}

// E1Candidate は、元E0用adapterを流用せずE1の注文条件を保存します。
type E1Candidate struct {
	ID              string        `json:"id"`
	Path            string        `json:"path"`
	DirectionPolicy string        `json:"direction_policy"`
	T8Applied       bool          `json:"t8_applied"`
	Event           episode.Event `json:"event"`
	Birth           Quote         `json:"birth"`
	Expires         float64       `json:"expires"`
	Status          string        `json:"status"`
	Evaluation      *Quote        `json:"evaluation"`
	Entry           *Quote        `json:"entry"`
	EntryPrice      *float64      `json:"entry_price"`
	RiskAtDecision  *float64      `json:"risk_at_decision"`
}

// e1Observer は、追加状態と取得記録だけを私有します。
type e1Observer struct {
	Scene          Scene133
	Detector       *episode.Detector
	Minutes        *minute.Tracker
	Events         []episode.Event
	Candidates     []*E1Candidate
	RejectedBy     map[string]uint64
	lastClosed     *episode.Bar
	closedPrevious []episode.Bar
	closedAt       *Quote
}

// ----------------------------------------
// newE1Observer は、新規限界を共通化した空の追加状態を作ります。
//
// 引数: scene(Scene133)。返り値: *e1Observer/errorは当場状態又は不正場定義です。
func newE1Observer(scene Scene133) (*e1Observer, error) {
	s, err := sourceScene133(scene)
	if err != nil {
		return nil, err
	}
	d := episode.New()
	if err = d.StartSession(s.Session, s.Contract); err != nil {
		return nil, err
	}
	return &e1Observer{Scene: s, Detector: d, Minutes: minute.New(), Events: []episode.Event{}, Candidates: []*E1Candidate{}, RejectedBy: map[string]uint64{}}, nil
}

// ----------------------------------------
// e1Quote は、同じ採用Rawの値を1分/状態部品へ写します。
//
// 引数: q(Quote)。返り値: episode.Quoteは同一時計・原行・価格です。
func e1Quote(q Quote) episode.Quote {
	return episode.Quote{Clock: q.Clock, Time: q.Time, Index: q.Index, SourceLine: q.SourceLine, Last: q.Last, Bid: q.Bid, Ask: q.Ask, QuoteOK: q.QuoteOK}
}

// ----------------------------------------
// Rejected は、129と同じ時計拒否だけを追加短期状態の未知へ反映します。
//
// 引数: reason(string)。返り値: ありません。元Bankやlegacy状態は変更しません。
func (o *e1Observer) Rejected(reason string) {
	if reason == "clock_missing" || reason == "clock_invalid" || reason == "backward_clock" {
		o.RejectedBy[reason]++
		o.Minutes.RejectClock(reason)
		o.Detector.RejectClock(reason)
		o.cancelPending("cancelled_clock_rejection")
		o.clearRecoveryCache()
	}
}

// ----------------------------------------
// cancelPending は、品質否定時にE1未取得要求だけを取消します。
//
// 引数: reason(string)は固定の取消区分。返り値: ありません。既取得とlegacyは変更しません。
func (o *e1Observer) cancelPending(reason string) {
	for _, c := range o.Candidates {
		if c.Status == "pending" {
			c.Status = reason
		}
	}
}

// ----------------------------------------
// newE1Request は、同じ出生RawのE1イベントを専用の成行要求へ変換します。
//
// 引数: event(episode.Event)、q(Quote)、s(Scene133)。返り値: *E1Candidate/errorです。
func newE1Request(event episode.Event, q Quote, s Scene133) (*E1Candidate, error) {
	if event.Session != s.Session || event.ID == "" || event.Mode != "E1" || (event.Side != 1 && event.Side != -1) ||
		event.At.Time != q.Time || event.At.Index != q.Index || event.At.Line != q.SourceLine ||
		!finite(event.EntryCap, event.Invalidation, event.ATR5, event.HoldBoundary) || event.EntryCap <= 0 || event.Invalidation <= 0 ||
		event.ATR5 <= 0 || event.HoldBoundary <= 0 || event.HoldMinimum != 0 || event.MinimumRisk != 10 {
		return nil, fmt.Errorf("E1イベントの場/方向/原行/geometryが不正")
	}
	for _, ref := range event.Refs {
		if ref.Delivered.Time > q.Time || int64(ref.Delivered.Index) > q.Index || int64(ref.Delivered.Line) > q.SourceLine {
			return nil, fmt.Errorf("E1イベントに未来の公表参照")
		}
	}
	c := &E1Candidate{ID: event.ID, Path: "E1", DirectionPolicy: "pattern", T8Applied: false, Event: event, Birth: q,
		Expires: math.Min(q.Time+30, s.ForceClose), Status: "pending"}
	if q.Time >= s.ForceClose {
		c.Status = "force_close"
	}
	return c, nil
}

// ----------------------------------------
// pendingE1 は、最初の1秒後正常BBOでcap・リスク・現在構造を再検査します。
//
// 引数: c(*E1Candidate)、q(Quote)、force(float64)。返り値: ありません。
// 適格でない最初の評価を取消し、価格が有利になるまで注文を残しません。
func pendingE1(c *E1Candidate, q Quote, force float64) {
	if c.Status != "pending" {
		return
	}
	if q.Time >= force {
		c.Status = "force_close"
		return
	}
	if q.Time >= c.Expires {
		c.Status = "unfilled_expired"
		return
	}
	if q.Index <= c.Birth.Index || q.SourceLine <= c.Birth.SourceLine || q.Time < c.Birth.Time+1 || !q.QuoteOK || !normal(q) {
		return
	}
	x := q
	c.Evaluation = &x
	e := c.Event
	price := q.Ask
	if e.Side < 0 {
		price = q.Bid
	}
	risk := float64(e.Side) * (price - e.Invalidation)
	c.RiskAtDecision = &risk
	if float64(e.Side)*(price-e.EntryCap) > 0 {
		c.Status = "entry_cap_rejected"
		return
	}
	if float64(e.Side)*(q.Last-e.HoldBoundary) < e.HoldMinimum {
		c.Status = "structure_lost"
		return
	}
	if risk < e.MinimumRisk || risk > math.Min(125, 1.5*e.ATR5) {
		c.Status = "risk_rejected"
		return
	}
	c.Entry, c.EntryPrice, c.Status = &x, &price, "filled"
}

// ----------------------------------------
// Accepted は、全公表配送済みの同Rawを1分→純状態→専用注文の順に処理します。
//
// 引数: bank(*rules.Bank)、q(Quote)、e0Born(bool)、legacyFills([]*Candidate133)、row([]byte)。
// 返り値: errorは状態又は接続の矛盾。bankはCurrentの読取だけで、legacyは変更しません。
func (o *e1Observer) Accepted(bank *rules.Bank, q Quote, e0Born bool, legacyFills []*Candidate133, row []byte) error {
	v, vt := minute.Quantity(row)
	closed, previous, reset, err := o.Minutes.Observe(e1Quote(q), v, vt)
	if err != nil {
		return err
	}
	if reset != "" {
		o.Detector.RejectClock(reset)
		o.cancelPending("cancelled_short_reset")
		o.clearRecoveryCache()
	}
	e0Priority := e0Born
	for _, c := range legacyFills {
		if c.Policy == "L0" && c.Path == "E0" {
			e0Priority = true
		}
	}
	if q.Time >= o.Scene.ForceClose {
		o.Detector.RejectClock("新規限界")
	} else {
		snapshot, err := bank.Current(quote133(q))
		if err != nil {
			return err
		}
		offered, prior := o.recoveryBar(q, snapshot, closed, previous)
		events, err := o.Detector.Observe(snapshot, e1Quote(q), offered, prior)
		if err != nil {
			return err
		}
		for _, event := range events {
			c, err := newE1Request(event, q, o.Scene)
			if err != nil {
				return err
			}
			o.Events = append(o.Events, event)
			o.Candidates = append(o.Candidates, c)
		}
	}
	for _, c := range o.Candidates {
		if c.Status != "pending" {
			continue
		}
		if e0Priority {
			c.Status = "cancelled_e0_priority"
		} else {
			pendingE1(c, q, o.Scene.ForceClose)
		}
	}
	return nil
}

// ----------------------------------------
// finish は、自然末尾で未終了要求を未取得のまま閉じます。
//
// 引数: receiver(*e1Observer)。返り値: ありません。EOFで1分や金融観測は閉じません。
func (o *e1Observer) finish() {
	for _, c := range o.Candidates {
		if c.Status == "pending" {
			c.Status = "eof_unfilled"
		}
	}
}
