package holdingohlc113

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"sync"

	episode "github.com/masayoshi4649/SessionTradeExecuter/e1episode"
	selectentry "github.com/masayoshi4649/SessionTradeExecuter/e1select"
)

// SceneE1Result は、固定対照と追加入口の原記録を混ぜず保存します。
type SceneE1Result struct {
	Session      string                  `json:"session"`
	Success      bool                    `json:"success"`
	Error        string                  `json:"error,omitempty"`
	Legacy       Result133               `json:"legacy"`
	E1Events     []episode.Event         `json:"e1_events"`
	E1Candidates []*E1Candidate          `json:"e1_candidates"`
	E1Stats      episode.Stats           `json:"e1_stats"`
	MinuteStats  map[string]int          `json:"minute_stats"`
	RejectedBy   map[string]uint64       `json:"rejected_by"`
	Lifecycle    []episode.Trace         `json:"lifecycle"`
	Selection    selectentry.Result      `json:"selection"`
	FrequencyA0  []selectentry.Candidate `json:"frequency_A0"`
	RawPasses    int                     `json:"raw_passes"`
}

// ----------------------------------------
// selectionStamp は、同じ取得時計を金融を持たない識別型へ写します。
//
// 引数: q(Quote)。返り値: selectentry.Stampは同じtime/index/物理行です。
func selectionStamp(q Quote) selectentry.Stamp {
	return selectentry.Stamp{Time: q.Time, Index: q.Index, SourceLine: q.SourceLine}
}

// ----------------------------------------
// selectE1Scene は、元L0と新E1の取得時計だけでC0/S0を選びます。
//
// 引数: s(Scene133)、legacy(Result133)、extra([]*E1Candidate)。
// 返り値: selectentry.Result/error。価格・損益を選択器へ渡しません。
func selectE1Scene(s Scene133, legacy Result133, extra []*E1Candidate) (selectentry.Result, error) {
	rows := []selectentry.Candidate{}
	for _, c := range legacy.Candidates {
		if c.Policy != "L0" || c.Entry == nil {
			continue
		}
		kind := selectentry.L0
		if c.Path == "E0" {
			kind = selectentry.E0
		}
		rows = append(rows, selectentry.Candidate{Session: s.Session, Contract: s.Contract, Kind: kind, ID: c.Birth.ID,
			BirthStamp: selectionStamp(c.Birth.Quote), EntryStamp: selectionStamp(*c.Entry)})
	}
	for _, c := range extra {
		if c.Entry == nil {
			continue
		}
		if c.Status != "filled" || c.DirectionPolicy != "pattern" || c.T8Applied {
			return selectentry.Result{}, fmt.Errorf("E1取得状態又は方向政策の矛盾")
		}
		rows = append(rows, selectentry.Candidate{Session: s.Session, Contract: s.Contract, Kind: selectentry.E1, ID: c.ID,
			BirthStamp: selectionStamp(c.Birth), EntryStamp: selectionStamp(*c.Entry)})
	}
	return selectentry.Select(rows)
}

// ----------------------------------------
// scanE1Source は、legacyの一走査へ読み取りobserverを加え全出生を保存します。
//
// 引数: all([]Scene133)、at(int)。返り値: SceneE1Result/errorです。
// 最初1補完のSelectionと、全E1候補の保存を分け、頻度比較の候補を消しません。
func scanE1Source(all []Scene133, at int) (SceneE1Result, error) {
	s := all[at]
	out := SceneE1Result{Session: s.Session, RawPasses: 1}
	observer, err := newE1Observer(s)
	if err != nil {
		return out, err
	}
	legacy, err := scanCore133(all, at, observer)
	out.Legacy = legacy
	if err != nil {
		return out, err
	}
	observer.finish()
	out.E1Events = observer.Events
	out.E1Candidates = observer.Candidates
	out.E1Stats = observer.Detector.Stats()
	out.MinuteStats = observer.Minutes.Stats()
	out.RejectedBy = observer.RejectedBy
	out.Lifecycle = observer.Detector.Lifecycle()
	out.Selection, err = selectE1Scene(s, legacy, observer.Candidates)
	if err != nil {
		return out, err
	}
	out.FrequencyA0, err = frequencyE1Scene(s, legacy, observer.Candidates)
	if err != nil {
		return out, err
	}
	if len(out.Selection.C0) == 0 && legacy.Coverage["L0"] {
		return out, fmt.Errorf("旧L0取得と選択器C0の矛盾")
	}
	if len(out.Selection.C0) > 0 && len(out.Selection.S0) == 0 {
		return out, fmt.Errorf("全場参加を選択器で欠落")
	}
	out.Success = true
	return out, nil
}

// ----------------------------------------
// RunE1Source は、明示SHAの固定73場で非金融の出生と取得だけを保存します。
//
// 引数: input/expected/output(string)、workers(int)。返り値: errorは整合又は保存失敗です。
// 自然実行前にF0固定が必要です。この関数自身は承認や閾値を変更しません。
func RunE1Source(input, expected, output string, workers int) error {
	if !validSHA133(expected) {
		return fmt.Errorf("F0固定の入力SHAを指定してください")
	}
	data, err := os.ReadFile(input)
	if err != nil {
		return err
	}
	sum := sha256.Sum256(data)
	if hex.EncodeToString(sum[:]) != expected {
		return fmt.Errorf("入力SHA差")
	}
	var in Input133
	if err = json.Unmarshal(data, &in); err != nil {
		return err
	}
	pubs, err := validateInput133(in, workers)
	if err != nil {
		return err
	}
	if _, err = os.Stat(output); !os.IsNotExist(err) {
		return fmt.Errorf("未作成の出力先だけ使用できます")
	}
	results := make([]SceneE1Result, len(in.Scenes))
	jobs := make(chan int)
	var wg sync.WaitGroup
	for i := 0; i < workers; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for at := range jobs {
				r, e := scanE1Source(in.Scenes, at)
				if e != nil {
					r.Error = e.Error()
				}
				results[at] = r
				fmt.Printf("%s 成功=%t E1出生=%d C0=%d S0=%d %s\n", r.Session, r.Success, len(r.E1Events), len(r.Selection.C0), len(r.Selection.S0), r.Error)
			}
		}()
	}
	for at := range in.Scenes {
		jobs <- at
	}
	close(jobs)
	wg.Wait()
	for _, r := range results {
		if !r.Success {
			return fmt.Errorf("%s: %s", r.Session, r.Error)
		}
	}
	encoded, err := json.MarshalIndent(map[string]any{"success": true, "engine": "Source133に市場終端後の既知回復E1を追加した版2", "base_trial": 133,
		"input_sha256": expected, "scene_count": len(in.Scenes), "publication_count": pubs, "scenes": results,
		"financial_labels_used": false, "portfolio_pnl": false, "candidate_quantity": 1, "source_signals_used": false,
		"stage": "入口の出生と取得だけ", "selection": "主A0はC0に全適格E1を追加し同取得原行はC0優先。C0旧L0固定、S0全E0と最初1補完",
		"e1_direction_policy": "pattern", "e1_t8_applied": false, "price_clock_only": true}, "", "  ")
	if err != nil {
		return err
	}
	after, err := os.ReadFile(input)
	if err != nil || sha256.Sum256(after) != sum {
		return fmt.Errorf("入力前後差又は再読失敗")
	}
	f, err := os.OpenFile(output, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if err != nil {
		return err
	}
	defer f.Close()
	_, err = f.Write(append(encoded, '\n'))
	return err
}
