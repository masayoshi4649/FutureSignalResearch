package holdingohlc113

import (
	"testing"

	episode "github.com/masayoshi4649/SessionTradeExecuter/e1episode"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// cacheFrame は、人工Rawへ今配送された5分のStampだけを持つSnapshotです。
//
// 引数: q(Quote)。返り値: rules.Snapshotはcache接続検査用で、取引判断には使いません。
func cacheFrame(q Quote) rules.Snapshot {
	return rules.Snapshot{Frames: map[int]rules.Publication{300: {Stamp: rules.Stamp{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine)}}}}
}

// ----------------------------------------
// TestKnownClosedMinuteCache は、以前に確定した足を新5分配送時だけ当時情報として提示します。
//
// 引数: t(*testing.T)。返り値: ありません。自然データは開きません。
func TestKnownClosedMinuteCache(t *testing.T) {
	o := &e1Observer{}
	b := episode.Bar{Start: 1200, End: 1260, PriceKnown: true, VolumeKnown: true, Volume: 2,
		First: rules.Quote{Time: 1200, Index: 1, Line: 2}, Last: rules.Quote{Time: 1259, Index: 4, Line: 5}}
	prior := []episode.Bar{{Start: 1140, End: 1200, VolumeKnown: true, Volume: 1}}
	closedAt := testQuote133(1261, 5, 95, 105)
	x, prev := o.recoveryBar(closedAt, rules.Snapshot{}, &b, prior)
	if x != &b || len(prev) != 1 {
		t.Fatal("今回閉鎖を変更")
	}
	b.Volume = 999
	prior[0].Volume = 999
	delivered := testQuote133(1265, 6, 95, 105)
	x, prev = o.recoveryBar(delivered, cacheFrame(delivered), nil, nil)
	if x == nil || x.Start != 1200 || x.Volume != 2 || len(prev) != 1 || prev[0].Volume != 1 {
		t.Fatal("既知cache又はcopy不正", x, prev)
	}
	x.Volume = 888
	prev[0].Volume = 888
	again := testQuote133(1266, 7, 95, 105)
	x, prev = o.recoveryBar(again, cacheFrame(again), nil, nil)
	if x.Volume != 2 || prev[0].Volume != 1 {
		t.Fatal("返したcacheが内部と共有")
	}
	// ----------------------------------------
	// 現在Rawへ新5分が届いていなければ過去足を再送しない。
	for _, field := range []string{"Time", "Index", "Line", "無し"} {
		s := cacheFrame(again)
		p := s.Frames[300]
		switch field {
		case "Time":
			p.Stamp.Time--
		case "Index":
			p.Stamp.Index--
		case "Line":
			p.Stamp.Line--
		case "無し":
			delete(s.Frames, 300)
		}
		if field != "無し" {
			s.Frames[300] = p
		}
		if x, _ := o.recoveryBar(again, s, nil, nil); x != nil {
			t.Fatal("新配送3項の不一致を許可", field)
		}
	}
	for _, tc := range []struct {
		at   float64
		want bool
	}{{1290, true}, {1291, false}} {
		q := testQuote133(tc.at, 20, 95, 105)
		x, _ := o.recoveryBar(q, cacheFrame(q), nil, nil)
		if (x != nil) != tc.want {
			t.Fatal("現在年齢30秒境界", tc.at)
		}
	}
	o.clearRecoveryCache()
	if x, _ := o.recoveryBar(again, cacheFrame(again), nil, nil); x != nil {
		t.Fatal("reset後に過去cache復活")
	}
}
