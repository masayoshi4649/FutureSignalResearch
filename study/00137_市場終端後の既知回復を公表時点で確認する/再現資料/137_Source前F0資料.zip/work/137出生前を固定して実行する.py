"""137のSource生成前F0を固定し、保存済み結果の確認を走査から分離する。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parent.parent
OWN = ROOT/'work/137既知回復の評価'
PREP = ROOT/'work/137既知回復をSourceへ接続する'
ENGINE = PREP/'Source再生器/E1接続Source.exe'
FORMAL = ROOT/'study/00137_市場終端後の既知回復を公表時点で確認する'
SOURCE = ROOT/'work/122全場入力/入力.json'
SOURCE_SHA = '6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec'
CONTROL = ROOT/'work/133探索期限の評価/Sourceの出生と取得.json'
CONTROL_SHA = '4c9449b620c15a63c00f9810eeaa52fc8f0eb5f92f7ea2d124cc9db12cc728f6'
OUTPUT = OWN/'Sourceの出生と取得.json'


def sha(path: Path) -> str:
    """
    機能: 全バイトのSHA256を返す。
    引数: path(Path)。
    返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def save(path: Path, data: dict) -> None:
    """
    機能: 既存記録を上書きせずUTF-8 JSONを保存する。
    引数: path(Path)、data(dict)。
    返り値: None。
    """
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n')


# ----------------------------------------
def verify(f0: dict) -> None:
    """
    機能: 自然生成前に固定した全コード・入力・文書を再照合する。
    引数: f0(dict)。
    返り値: None。不一致で停止する。
    """
    assert f0['成功'] and f0['試行'] == 137 and f0['主'] == 'A0'
    for path,expected in f0['ファイル'].items():
        assert sha(Path(path)) == expected,path


# ----------------------------------------
def confirm(f0: dict) -> None:
    """
    機能: 保存済みSourceから旧対照同体・参加・方向・phaseを非金融で確認する。
    引数: f0(dict)。
    返り値: None。Raw再走査・勝敗計算・閾値変更をしない。
    """
    verify(f0)
    data = json.loads(OUTPUT.read_bytes())
    old = json.loads(CONTROL.read_bytes())
    metadata = json.loads(SOURCE.read_bytes())
    assert data['success'] and data['input_sha256'] == SOURCE_SHA and not data['financial_labels_used']
    assert data['scene_count'] == len(data['scenes']) == len(old['scenes']) == len(metadata['scenes']) == 73
    totals = {'C0':0,'S0':0,'A0':0,'E1出生':0,'E1候補':0,'E1取得':0}
    scene_counts = []
    stat_differences = []
    old_source_fields = ('session','success','raw','actual_sha256','quality','expected_quality','raw_encoding','publications','events','detector_stats','candidates','raw_passes','source_signals_used','participation','source_force_close','entry_cutoff','execution_end','fallback_at','coverage')
    for new,prior,scene in zip(data['scenes'],old['scenes'],metadata['scenes']):
        sid = scene['session']
        assert new['success'] and new['session'] == prior['session'] == sid and new['raw_passes'] == 1
        legacy = new['legacy']
        assert legacy['stat_before'] == legacy['stat_after']
        for key in old_source_fields:
            assert legacy.get(key) == prior.get(key),(sid,key)
        if legacy['stat_before'] != prior['stat_before']:
            stat_differences.append(sid)
        filled = {c['birth']['id']:c for c in legacy['candidates'] if c['policy'] == 'L0' and c['entry'] is not None}
        extra = {c['id']:c for c in new['e1_candidates'] if c['entry'] is not None}
        assert len(extra) == sum(c['entry'] is not None for c in new['e1_candidates'])
        assert len(new['e1_events']) == len(new['e1_candidates'])
        expected_c0 = set(filled)
        assert {c['id'] for c in new['selection']['C0']} == expected_c0
        c0_stamps = {tuple(c['entry'][k] for k in ('time','index','source_line')) for c in filled.values()}
        counts = {}
        for model,rows in (('C0',new['selection']['C0']),('S0',new['selection']['S0']),('A0',new['frequency_A0'])):
            assert rows and len({c['id'] for c in rows}) == len(rows)
            counts[model] = len(rows)
            for ref in rows:
                assert ref['session'] == sid and ref['contract'] == scene['contract']
                if ref['kind'] == 'E1':
                    c = extra[ref['id']]
                    entry,birth = c['entry'],c['birth']
                    assert c['direction_policy'] == 'pattern' and not c['t8_applied']
                    assert c['event']['side'] in (-1,1)
                    assert c['status'] == 'filled'
                    if model == 'A0':
                        assert tuple(entry[k] for k in ('time','index','source_line')) not in c0_stamps
                else:
                    c = filled[ref['id']]
                    entry,birth = c['entry'],c['birth']['quote']
                    assert c['direction']['selected_side'] in (-1,1)
                assert ref['entry_stamp'] == {k:entry[k] for k in ('time','index','source_line')}
                assert ref['birth_stamp'] == {k:birth[k] for k in ('time','index','source_line')}
                assert birth['time']+1 <= entry['time'] and entry['time'] < birth['time']+30
                assert birth['index'] < entry['index'] and birth['source_line'] < entry['source_line']
                assert entry['time'] < min(scene['force_close'],scene['end']-3900)
        assert expected_c0 <= {c['id'] for c in new['frequency_A0']}
        assert counts['A0'] == counts['C0'] + sum(tuple(c['entry'][k] for k in ('time','index','source_line')) not in c0_stamps for c in extra.values())
        for model in ('C0','S0','A0'):
            totals[model] += counts[model]
        totals['E1出生'] += len(new['e1_events'])
        totals['E1候補'] += len(new['e1_candidates'])
        totals['E1取得'] += len(extra)
        scene_counts.append({'session':sid,**counts,'E1出生':len(new['e1_events']),'E1取得':len(extra)})
    assert totals['C0'] == 79
    verify(f0)
    save(OWN/'Source非金融の確認.json',{'成功':True,'試行':137,'F0_SHA256':sha(OWN/'F0.json'),'Source_SHA256':sha(OUTPUT),
         '旧対照C0全79同体':True,'旧Source全場の実質全項目同体':True,'旧時点とのstat差の場':stat_differences,
         '現在stat前後同体':True,'全73場全model最低1取得':True,'合計':totals,'場別':scene_counts,
         'Source原板再走査':False,'金融読取':False,'方向政策':'E1pattern、旧L0固定T8、E0元保護'})
    print(json.dumps({'成功':True,'試行':137,'合計':totals,'確認SHA256':sha(OWN/'Source非金融の確認.json')},ensure_ascii=False))


# ----------------------------------------
def main() -> None:
    """
    機能: F0固定、Source一回走査、保存済み確認を別modeで実行する。
    引数: CLI --mode(str)、固定時のみ--independent-proof(Path)/--independent-sha(str)。
    返り値: None。確認失敗を理由に原板を再走査しない。
    """
    parser = argparse.ArgumentParser(description='137非金融Sourceの実行前固定')
    parser.add_argument('--mode',choices=('固定','実行','確認'),required=True)
    parser.add_argument('--independent-proof',type=Path)
    parser.add_argument('--independent-sha')
    args = parser.parse_args()
    OWN.mkdir(exist_ok=True)
    if args.mode == '固定':
        assert args.independent_proof and sha(args.independent_proof) == args.independent_sha
        independent = json.loads(args.independent_proof.read_bytes())
        assert independent.get('成功') is True or independent.get('success') is True
        assert sha(SOURCE) == SOURCE_SHA and sha(CONTROL) == CONTROL_SHA
        prepared = json.loads((PREP/'Rootの準備の確認.json').read_bytes())
        assert prepared['成功'] and sha(ENGINE) == prepared['exe_sha256']
        assert all(sha(Path(p)) == value for p,value in prepared['ファイル'].items())
        files = set(Path(p) for p in prepared['ファイル']) | {SOURCE,CONTROL,ENGINE,Path(__file__).resolve(),args.independent_proof.resolve()}
        files.update(p for p in PREP.iterdir() if p.is_file() and p.suffix in ('.py','.md','.json'))
        files.update(p for p in FORMAL.iterdir() if p.is_file() and p.suffix == '.md')
        for folder in ('137公表時に既知の短期回復を確認する','押戻し回復の1分入力','押戻し回復の取得を時系列で選ぶ','137市場時刻と公表時計の独立確認'):
            files.update(p for p in (ROOT/'work'/folder).iterdir() if p.is_file() and p.suffix in ('.py','.md','.json','.mod','.go'))
        f0 = {'成功':True,'試行':137,'段階':'自然Source前F0','主':'A0','UTC':datetime.now(timezone.utc).isoformat(),
              '条件':'全73場min1・実BBO/H60±125先着70・全ザラバ時間平均概ね1/h。場回数偏り許容',
              '頻度主への更新':'ユーザー指定を自然実行前に反映。S0は固定副対照',
              'ファイル':{str(p):sha(p) for p in sorted(files)}}
        save(OWN/'F0.json',f0)
        print(json.dumps({'F0_SHA256':sha(OWN/'F0.json'),'固定ファイル数':len(files)},ensure_ascii=False))
        return
    f0 = json.loads((OWN/'F0.json').read_bytes())
    verify(f0)
    if args.mode == '確認':
        confirm(f0)
        return
    assert not OUTPUT.exists(),'Sourceは再実行せず確認modeを使用する'
    command = [str(ENGINE),'--input',str(SOURCE),'--expected-sha',SOURCE_SHA,'--output',str(OUTPUT),'--workers','8','--execute-after-f0']
    subprocess.run(command,cwd=ROOT,check=True)
    verify(f0)
    save(OWN/'Source走査の完了.json',{'成功':True,'試行':137,'F0_SHA256':sha(OWN/'F0.json'),'Source_SHA256':sha(OUTPUT),
         '入力コード前後同体':True,'コマンド':command,'後段確認別mode':True})


if __name__ == '__main__':
    main()
