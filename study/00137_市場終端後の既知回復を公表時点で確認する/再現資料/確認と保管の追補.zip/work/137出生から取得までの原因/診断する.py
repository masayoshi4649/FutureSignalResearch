"""137 SourceのE1候補9件だけから、出生価格と取得判定価格の差を非金融診断する。"""
from collections import Counter
from pathlib import Path
import hashlib
import json
import math

OWN = Path(__file__).resolve().parent
ROOT = OWN.parent.parent
SOURCE = ROOT / 'work/137既知回復の評価/Sourceの出生と取得.json'
SOURCE_SHA = 'd5c2e8e772e1658015d82497760b56ef40d6cae07da40eb8f148f601795628e5'
OBSERVER = ROOT / 'work/137既知回復をSourceへ接続する/Source再生器/observer.go'


# ----------------------------------------
def sha(path: Path) -> str:
    """
    機能: 指定ファイルのbytes指紋を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def geometry(price: float, last: float, side: int, k: float, cap: float, invalid: float, maximum: float) -> dict:
    """
    機能: 137と同じ方向符号でK・追値上限・riskを独立に測る。
    引数: price/last/k/cap/invalid/maximum(float)、side(int)。返り値: dict。
    """
    assert side in (-1, 1) and all(math.isfinite(v) for v in (price, last, k, cap, invalid, maximum))
    hold = side * (last - k)
    excess = side * (price - cap)
    risk = side * (price - invalid)
    checks = {'K維持': hold >= 0, 'cap内': excess <= 0, 'risk内': 10 <= risk <= maximum}
    return {**checks, '全適格': all(checks.values()), 'LastのK余裕pt': hold,
            '価格のcap超過pt_正なら拒否': excess, '価格のIまでrisk_pt': risk}


# ----------------------------------------
def point(quote: dict, side: int, event: dict) -> dict:
    """
    機能: 同じQuoteのLastによる適格と取得側Ask/Bidによる適格を分ける。
    引数: quote/event(dict)、side(int)。返り値: dict。
    """
    assert quote['quote_ok'] is True and 0 < quote['bid'] < quote['ask']
    maximum = min(125, 1.5 * event['atr5'])
    price = quote['ask'] if side == 1 else quote['bid']
    args = side, event['hold_boundary'], event['entry_cap'], event['invalidation'], maximum
    return {'Quote': quote, '取得側': 'Ask' if side == 1 else 'Bid', '取得側価格': price,
            'スプレッドpt': quote['ask'] - quote['bid'], '取得側価格とLastの方向差pt': side * (price - quote['last']),
            'Lastで測ったgeometry': geometry(quote['last'], quote['last'], *args),
            '取得側価格で測ったgeometry': geometry(price, quote['last'], *args)}


# ----------------------------------------
def artificial() -> None:
    """
    機能: 売買鏡像とK/cap/riskの等号境界、Lastと取得側の違いを検査する。
    引数: なし。返り値: None。自然データの最適化は行わない。
    """
    buy = geometry(110, 109, 1, 109, 119, 94, 60)
    sell = geometry(90, 91, -1, 91, 81, 106, 60)
    assert buy == sell and buy['全適格']
    assert geometry(119, 109, 1, 109, 119, 94, 60)['全適格']
    assert not geometry(120, 109, 1, 109, 119, 94, 60)['cap内']
    assert geometry(104, 109, 1, 109, 119, 94, 60)['risk内']
    assert not geometry(103, 109, 1, 109, 119, 94, 60)['risk内']
    assert geometry(154, 109, 1, 109, 200, 94, 60)['risk内']
    assert not geometry(155, 109, 1, 109, 200, 94, 60)['risk内']
    assert not geometry(110, 108, 1, 109, 119, 94, 60)['K維持']


# ----------------------------------------
def diagnose(session: str, candidate: dict) -> dict:
    """
    機能: 候補の保存された出生・最初の評価・取得だけを因果順に分類する。
    引数: session(str)、candidate(dict)。返り値: dict。途中Rawや後続損益は推測しない。
    """
    event = candidate['event']; side = event['side']; birth = candidate['birth']; evaluation = candidate['evaluation']
    assert candidate['id'] == event['id'] and event['session'] == session
    assert candidate['path'] == 'E1' and candidate['direction_policy'] == 'pattern' and candidate['t8_applied'] is False
    assert event['fields']['recovery_bar_clock'] == 'market_end'
    born = point(birth, side, event)
    assert born['Lastで測ったgeometry']['全適格']
    row = {'session': session, 'id': candidate['id'], '売買向き': side, '最終status': candidate['status'],
           'K': event['hold_boundary'], 'I': event['invalidation'], 'cap': event['entry_cap'],
           '接触ATR5': event['atr5'], 'risk上限': min(125, 1.5 * event['atr5']),
           '出生': born, '要求期限': candidate['expires'], '評価': None,
           '保存された取得': candidate['entry'], '取得代用成立': candidate['entry'] is not None}
    assert evaluation is not None  # 今回の9件。未知評価を0円/0ptで埋めない。
    assert birth['time'] + 1 <= evaluation['time'] < candidate['expires']
    assert all(evaluation[key] > birth[key] for key in ('index', 'source_line'))
    evaluated = point(evaluation, side, event)
    row['評価'] = evaluated; row['出生から評価まで秒'] = evaluation['time'] - birth['time']
    bg = born['取得側価格で測ったgeometry']; eg = evaluated['取得側価格で測ったgeometry']
    last_move = side * (evaluation['last'] - birth['last'])
    wedge = evaluated['取得側価格とLastの方向差pt']
    signed_gap = side * (evaluated['取得側価格'] - birth['last'])
    assert signed_gap == last_move + wedge
    row['差の分解'] = {'評価Lastの出生Lastからの方向変化pt': last_move,
                   '評価取得側価格の評価Lastからの方向差pt': wedge,
                   '評価取得側価格の出生Lastからの方向差pt': signed_gap,
                   '評価取得側価格の出生取得側価格からの方向変化pt': side * (evaluated['取得側価格'] - born['取得側価格'])}
    status = 'entry_cap_rejected' if not eg['cap内'] else 'structure_lost' if not eg['K維持'] else 'risk_rejected' if not eg['risk内'] else 'filled'
    assert candidate['status'] == status and candidate['risk_at_decision'] == eg['価格のIまでrisk_pt']
    if status == 'filled':
        assert candidate['entry'] == evaluation and candidate['entry_price'] == evaluated['取得側価格']
        row['原因分類'] = '取得'
    elif status == 'entry_cap_rejected':
        assert candidate['entry'] is None and candidate['entry_price'] is None
        row['原因分類'] = '出生時から実BBOはcap外' if not bg['cap内'] else '出生時実BBO適格から評価時実BBOがcap外'
    elif status == 'structure_lost':
        assert candidate['entry'] is None and candidate['entry_price'] is None
        row['原因分類'] = '評価LastがK維持を喪失'
    else:
        row['原因分類'] = '評価取得側価格のrisk不適格'
    return row


# ----------------------------------------
def main() -> None:
    """
    機能: 許可SourceのE1候補9件のみを診断し、小型の根拠と不変証跡を残す。
    引数: なし。返り値: None。金融/原板/CSV/追加2場は開かない。
    """
    assert sha(SOURCE) == SOURCE_SHA
    own_before = sha(Path(__file__)); observer_before = sha(OBSERVER)
    artificial()
    source = json.loads(SOURCE.read_text('utf-8'))
    assert source['financial_labels_used'] is False and source['portfolio_pnl'] is False
    rows = [diagnose(scene['session'], candidate) for scene in source['scenes'] for candidate in scene['e1_candidates']]
    assert len(rows) == len({row['id'] for row in rows}) == 9
    counts = Counter(row['最終status'] for row in rows)
    assert counts == {'filled': 2, 'entry_cap_rejected': 3, 'structure_lost': 4}
    summary = {'出生数': len(rows), '取得数': sum(row['取得代用成立'] for row in rows), '最終status件数': dict(counts),
               '原因分類件数': dict(Counter(row['原因分類'] for row in rows)),
               '出生Lastの全geometry適格': sum(row['出生']['Lastで測ったgeometry']['全適格'] for row in rows),
               '出生実AskBidの全geometry適格': sum(row['出生']['取得側価格で測ったgeometry']['全適格'] for row in rows),
               '評価Lastの全geometry適格': sum(row['評価']['Lastで測ったgeometry']['全適格'] for row in rows),
               '評価実AskBidの全geometry適格': sum(row['評価']['取得側価格で測ったgeometry']['全適格'] for row in rows),
               '独立条件違反件数_最終statusと別': {
                   '評価cap超過': sum(not row['評価']['取得側価格で測ったgeometry']['cap内'] for row in rows),
                   '評価LastのK喪失': sum(not row['評価']['取得側価格で測ったgeometry']['K維持'] for row in rows),
                   '評価risk不適格': sum(not row['評価']['取得側価格で測ったgeometry']['risk内'] for row in rows)},
               'E0優先による最終取消': 0, 'TTLによる最終取消': 0, '時計と短期resetとEOFによる最終取消': 0,
               '出生から最初の評価まで秒': {'最小': min(row['出生から評価まで秒'] for row in rows),
                                  '最大': max(row['出生から評価まで秒'] for row in rows)}}
    payload = {'試行': 137, '対象': '非金融E1候補9件の保存された出生・評価・取得だけ',
               'Source_SHA256': SOURCE_SHA, '集約': summary, '候補': rows,
               '限界': ['出生Lastとその時点のBBO、保存された最初の適格評価だけを比較した',
                      '最短1秒後の価格時計であり、受信時刻や厳密な1秒後の気配ではない',
                      '途中の気配・注文待ち中の連続維持・その後の先着や損益は調べていない',
                      '不適格な最初の評価で要求が終了する固定条件を維持した'],
               '未実行の問い': '出生時にも同じ実Ask/Bidのcap/risk条件を確認すると、Lastと取得価格の不一致を減らせるか。取得数や先着率への効果は未検証'}
    dest = OWN / '候補9件の原因.json'
    dest.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    assert sha(SOURCE) == SOURCE_SHA and sha(Path(__file__)) == own_before and sha(OBSERVER) == observer_before
    proof = {'成功': True, '試行': 137, 'Source前後SHA256': SOURCE_SHA,
             '診断コードSHA256': own_before, '固定adapterコード前後SHA256': observer_before,
             '候補9件の原因SHA256': sha(dest), '人工': '売買鏡像・K/cap/risk等号と外側の境界成功',
             '全9件の保存statusと式による分類同体': True, '前後同体': True,
             '新金融結果又はRaw又はCSV読取': False, '追加2場読取': False,
             '先着と損益算出': False, '現在137の条件変更': False}
    check = OWN / '診断の確認.json'
    check.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'success': True, 'proof_sha256': sha(check), 'output_sha256': sha(dest), 'summary': summary}, ensure_ascii=True))


if __name__ == '__main__':
    main()
