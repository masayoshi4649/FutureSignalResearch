"""137金融後の独立検算・原因・CSV・保存コードを別ZIPへまとめる。"""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
FORMAL = next((ROOT / 'study').glob('00137_*'))


def sha(body: bytes) -> str:
    """
    機能: 後発資料の指紋を求める。
    引数: body(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: F0/F1固定資料を不変に保ち、後発源だけを保管する。
    引数: なし。
    返り値: None。Raw・新金融・CSVを生成しない。
    """
    files = list((ROOT / 'work/137正式保存').glob('*.py')) + list((FORMAL / '再現資料').glob('*.py'))
    files += [ROOT / 'work/137独立検算' / x for x in ('検算する.py', '人工検査.py', 'README.md')]
    files += [ROOT / 'work/137出生から取得までの原因/診断する.py']
    files += [ROOT / 'work/137既知回復CSV出力' / x for x in ('出力する.mjs', 'CSVを独立再読する.py')]
    archive = FORMAL / '再現資料/確認と保管の追補.zip'; index = []
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in sorted(set(files)):
            body = path.read_bytes(); name = path.relative_to(ROOT).as_posix(); z.writestr(name, body)
            index.append({'path': name, 'bytes': len(body), 'sha256': sha(body), '区分': '金融後の検査・閲覧・原因・保管。F0/F1の直接固定源と区別'})
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for item in index:
            assert sha(z.read(item['path'])) == item['sha256']
    path = FORMAL / '保管索引.json'; m = json.loads(path.read_bytes())
    m['後発資料'] = {'ZIP': archive.name, 'ZIP_SHA256': sha(archive.read_bytes()), 'ZIP_bytes': archive.stat().st_size, '格納源数': len(index), '格納源': index}
    m['独立金融検算'] = {'proof': '検査/独立金融_独立確認.json', 'SHA256': 'a29d965fb915cf424f1e971c61672bcc973600486c0a09f0a4b5af638ab7251c',
                     '停止票': '検査/独立金融_完了.json', '全条件': 300, '表セル': 31117, '人工': 5, '非金融橋渡し作者と同じ担当': True}
    m['原因資料'] = {'本文': '出生から取得までの原因.md', '9候補': '成果物/候補9件の原因.json', 'proof': '検査/出生から取得の診断確認.json',
                   '金融/先着を参照': False, '137の条件を変更': False}
    m['段階'] = '金融・保存再現・独立検算・CSV確認完了。主A0の70%/平均1h未達'
    m['結果文面を編集'] = True
    path.write_text(json.dumps(m, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '後発源数': len(index), '後発ZIP_SHA256': m['後発資料']['ZIP_SHA256']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
