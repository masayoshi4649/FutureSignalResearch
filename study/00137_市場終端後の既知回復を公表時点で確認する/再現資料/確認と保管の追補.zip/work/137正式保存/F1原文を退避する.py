"""137の金融前F1と全MD原文を、結果の追記前に同体退避する。"""
from pathlib import Path
import gzip
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
FORMAL=ROOT/'study/00137_市場終端後の既知回復を公表時点で確認する'
OWN=ROOT/'work/137既知回復の評価'


def main() -> None:
    """
    機能: F1原本と列挙MDの現在SHAを照合し、履歴原文を保存する。
    引数: なし。
    返り値: None。金融結果/Raw/追加2場を読まず、正式3MDも変更しない。
    """
    body=(OWN/'F1.json').read_bytes()
    sha=lambda b:hashlib.sha256(b).hexdigest()
    expected='2d816fe6e8de7c5e5112d89f29f59113e53ba810cbbf43d43beb025cc24b6618'
    assert sha(body)==expected
    f1=json.loads(body);assert len(f1['ファイル'])==93
    docs=[]
    for name,h in f1['ファイル'].items():
        p=Path(name)
        if p.suffix!='.md':continue
        b=p.read_bytes();assert sha(b)==h,name
        docs.append({'path':p.relative_to(ROOT).as_posix(),'bytes':len(b),'sha256':h,'本文':b.decode('utf-8')})
    with (FORMAL/'検査/F1.json').open('xb') as handle:handle.write(body)
    value={'試行':137,'段階':'金融前F1の結果追記前原文','F1_SHA256':expected,'文書数':len(docs),'正式文書数':sum(x['path'].startswith('study/') for x in docs),'文書':docs}
    raw=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8');packed=gzip.compress(raw,mtime=0)
    with (FORMAL/'検査/実行前文書_F1.json.gz').open('xb') as handle:handle.write(packed)
    print(json.dumps({'成功':True,'F1源':93,'MD数':len(docs),'正式MD':value['正式文書数'],'gzip_SHA256':sha(packed),'結果MD変更':False},ensure_ascii=False))


if __name__=='__main__':
    main()
