"""137の金融前93源を同体保管し、保存済み観測を一度だけ恒久化する。"""
from pathlib import Path
import gzip
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
FORMAL = next((ROOT / 'study').glob('00137_*'))
OWN = ROOT / 'work/137既知回復の評価'


def sha(body: bytes) -> str:
    """
    機能: 原文の指紋を求める。
    引数: body(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


# ----------------------------------------
def put(path: Path, body: bytes) -> None:
    """
    機能: 新規先へ原文を保管する。
    引数: path(Path)、body(bytes)。
    返り値: None。既存を上書きしない。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as handle:
        handle.write(body)


# ----------------------------------------
def save(source: Path, destination: Path, packed: bool) -> dict:
    """
    機能: 同体又はgzip原文と復元票を保存する。
    引数: source/destination(Path)、packed(bool)。
    返り値: dictは由来と両指紋。
    """
    raw = source.read_bytes(); body = gzip.compress(raw, mtime=0) if packed else raw
    put(destination, body)
    return {'保存元': destination.relative_to(ROOT).as_posix(), '復元先': source.relative_to(ROOT).as_posix(),
            '形式': 'gzip' if packed else '同体', '保存bytes': len(body), '保存SHA256': sha(body),
            '解凍bytes': len(raw), '解凍SHA256': sha(raw)}


# ----------------------------------------
def main() -> None:
    """
    機能: 編集前manifestを含むF1原文と再現入力を最小保管する。
    引数: なし。
    返り値: None。Raw/177MB入力/追加2場/新金融を読まない。
    """
    original = (FORMAL / '検査/F1.json').read_bytes()
    assert sha(original) == '2d816fe6e8de7c5e5112d89f29f59113e53ba810cbbf43d43beb025cc24b6618'
    f1 = json.loads(original); assert len(f1['ファイル']) == 93
    manifest = json.loads((FORMAL / '保管索引.json').read_bytes())
    assert sha((FORMAL / '保管索引.json').read_bytes()) == '4bb004cd1f98bce68ec0c2ef039a8aa77cbb38d4f0bcc2c6bd3b6307314a7479'
    groups = []; known = {}
    for number, key in [(133, '固定コード'), (136, 'F0追加資料'), (137, 'F0追加資料')]:
        folder = next((ROOT / 'study').glob(f'{number:05d}_*'))
        old = json.loads((folder / '保管索引.json').read_bytes())[key]
        path = folder / '再現資料' / old['ZIP']; assert sha(path.read_bytes()) == old['ZIP_SHA256']
        at = len(groups)
        groups.append({'保存元ZIP': path.relative_to(ROOT).as_posix(), 'ZIP_SHA256': old['ZIP_SHA256'], '格納源': []})
        for item in old['格納源']:
            known.setdefault(item['sha256'], (at, item['path']))
    prior135 = json.loads((next((ROOT / 'study').glob('00135_*')) / '保管索引.json').read_bytes())
    shared = [item for item in prior135['共有参照'] if item['復元先'] in
              ('work/124入口の正逆比較/全73場の正逆結果.json', 'work/126複合切替の探索/集計.json')]
    assert len(shared) == 2
    shared += manifest['F0共有入力'] + [manifest['新Source入力']]
    new_inputs = []
    for name in ('固定取得入力.json', '方向と出生.json'):
        new_inputs.append(save(OWN / '固定入力' / name, ROOT / 'inputs/00137_公表時確認のSource入力' / (name + '.gz'), True))
    input_map = {x['復元先']: x for x in shared + new_inputs}
    for item in input_map.values():
        body = (ROOT / item['保存元']).read_bytes(); assert sha(body) == item['保存SHA256']
        decoded = gzip.decompress(body) if item['形式'] == 'gzip' else body
        assert sha(decoded) == item['解凍SHA256']
    new = []; bodies = {}; excluded = []
    for name, expected in f1['ファイル'].items():
        p = Path(name); rel = p.relative_to(ROOT).as_posix()
        if rel == 'work/122全場入力/入力.json' or p.suffix == '.exe':
            excluded.append({'path': rel, 'bytes': p.stat().st_size, 'sha256': expected,
                             '理由': '共用巨大入力と実行体は複写せず、生成元と固定SHA及び別ビルドを参照'})
            continue
        if rel in input_map:
            assert input_map[rel]['解凍SHA256'] == expected
            continue
        assert p.stat().st_size < 2_000_000, rel
        body = p.read_bytes(); assert sha(body) == expected, rel
        if expected in known:
            at, entry = known[expected]
            groups[at]['格納源'].append({'ZIP内path': entry, '復元先': rel, 'bytes': len(body), 'sha256': expected})
        else:
            new.append({'path': rel, 'bytes': len(body), 'sha256': expected}); bodies[rel] = body
    assert len(excluded) == 3
    assert sum(len(x['格納源']) for x in groups) + len(new) + len(input_map) == 90
    archive = FORMAL / '再現資料/137_金融前F1追加資料.zip'
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for item in new:
            z.writestr(item['path'], bodies[item['path']])
    for group in groups:
        group['格納源数'] = len(group['格納源'])
        with zipfile.ZipFile(ROOT / group['保存元ZIP']) as z:
            for item in group['格納源']:
                assert sha(z.read(item['ZIP内path'])) == item['sha256']
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for item in new:
            assert sha(z.read(item['path'])) == item['sha256']
    observations = save(OWN / '固定取得の正逆観測.json', FORMAL / '成果物/固定取得の正逆観測.json.gz', True)
    assert observations['解凍SHA256'] == 'f0adca92cf1f1db25e75e4d92187952e2920ea7126b3790ece89df1c7f00369a'
    aggregate = save(ROOT / 'work/137既知回復と頻度の集計/集計.json', FORMAL / '成果物/集計.json', False)
    assert aggregate['解凍SHA256'] == 'f7c73cc87948fa17174e3909f89aa63d74abe76191bf435788e71cb0d400548b'
    for source, name in [(OWN / '正逆観測の完了.json', '正逆観測の完了.json'),
                         (OWN / '金融段階の完了.json', '金融段階の完了.json'),
                         (OWN / '固定入力/転送の確認.json', '転送の確認.json'),
                         (ROOT / 'work/137既知回復と頻度の集計/集計完了.json', '集計完了.json'),
                         (ROOT / 'work/137既知回復と頻度の集計/非金融接続の確認.json', '非金融接続の確認.json')]:
        save(source, FORMAL / '検査' / name, False)
    source133 = next((ROOT / 'study').glob('00133_*'))
    m133 = json.loads((source133 / '保管索引.json').read_bytes())['固定コード']
    kernel = [x for x in m133['格納源'] if x['path'].startswith('work/133固定取得の正逆評価器/')]
    assert kernel
    manifest.update({'段階': '金融完了、正式化中', 'F1_SHA256': sha(original), 'F1直接源数': 93,
        'F1追加資料': {'ZIP': archive.name, 'ZIP_SHA256': sha(archive.read_bytes()), 'ZIP_bytes': archive.stat().st_size,
                     '格納源数': len(new), '格納源': new},
        'F1共有コード群': groups, 'F1共有入力': shared, '新金融入力': new_inputs,
        '意図して複製しないF1源': excluded, '保存済み正逆観測': observations, '集計正本': aggregate,
        '後段の再現用継承源': {'保存元ZIP': (source133 / '再現資料' / m133['ZIP']).relative_to(ROOT).as_posix(),
                        'ZIP_SHA256': m133['ZIP_SHA256'], '格納源数': len(kernel), '格納源': kernel,
                        '扱い': '133で保存済みの同体再現源。137 F1直接固定はexe指紋であり、源の後付け固定としない'},
        '金融前F1を作成': False, '金融前F1原本を同体保存': True})
    (FORMAL / '保管索引.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    proof = {'成功': True, '試行': 137, 'F1源': 93, '復元予定': 90, '未複製': 3, '追加ZIP源': len(new),
             '共有ZIP源': sum(x['格納源数'] for x in groups), '共有/新入力': [len(shared), len(new_inputs)],
             '編集前保管索引もF1原文として保存': True, 'F1_MD原文数': 12, '正式MD原文数': 3,
             'F1追加ZIP_SHA256': manifest['F1追加資料']['ZIP_SHA256'], '新金融/Raw/177MB/追加2場読取': False}
    put(FORMAL / '検査/F1原文と正本の保管確認.json', (json.dumps(proof, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    print(json.dumps(proof, ensure_ascii=False))


if __name__ == '__main__':
    main()
