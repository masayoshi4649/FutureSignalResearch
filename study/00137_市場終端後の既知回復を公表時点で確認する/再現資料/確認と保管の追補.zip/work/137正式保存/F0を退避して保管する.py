"""137のSource実行前F0を保管し、133/136と同体のコードは重複保存しない。"""
from pathlib import Path
import gzip
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[2]
FORMAL=ROOT/'study/00137_市場終端後の既知回復を公表時点で確認する'
OWN=ROOT/'work/137既知回復の評価'
F0_SHA='0c3660076da8c4da9b945cbde6c47213da763ec82e8c4c8e5313f4569a379a3d'


def sha(body: bytes) -> str:
    """
    機能: 保管原文の指紋を返す。
    引数: body(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


# ----------------------------------------
def put(path: Path, body: bytes) -> None:
    """
    機能: 未作成の保管先へ同体資料を保存する。
    引数: path(Path)、body(bytes)。
    返り値: None。既存は上書きしない。
    """
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as handle:handle.write(body)


# ----------------------------------------
def main() -> None:
    """
    機能: 137の62直接源・10原文MDと再現用共有依存を最小保管する。
    引数: なし。
    返り値: None。Sourceプロセス・自然結果・Raw/177MB・金融へ触れない。
    """
    original=(OWN/'F0.json').read_bytes();assert sha(original)==F0_SHA
    f0=json.loads(original);assert len(f0['ファイル'])==62
    prior133=ROOT/'study/00133_全場参加を維持して強い入口の探索期限を延ばす'
    prior136=ROOT/'study/00136_押戻し後の回復入口を加えて頻度と先着を比較する'
    m133=json.loads((prior133/'保管索引.json').read_bytes());m136=json.loads((prior136/'保管索引.json').read_bytes())
    saved=[];by_sha={}
    for folder,item in [(prior133,m133['固定コード']),(prior136,m136['F0追加資料'])]:
        path=folder/'再現資料'/item['ZIP'];assert sha(path.read_bytes())==item['ZIP_SHA256']
        group={'保存元ZIP':path.relative_to(ROOT).as_posix(),'ZIP_SHA256':item['ZIP_SHA256'],'格納源':[]}
        group_at=len(saved);saved.append(group)
        for source in item['格納源']:
            by_sha.setdefault(source['sha256'],(group_at,source))
    docs=[];new=[];bodies={};excluded=[]
    source_path='work/133探索期限の評価/Sourceの出生と取得.json'
    for name,expected in f0['ファイル'].items():
        path=Path(name);relative=path.relative_to(ROOT).as_posix()
        if relative=='work/122全場入力/入力.json' or path.suffix=='.exe':
            excluded.append({'path':relative,'sha256':expected,'bytes':path.stat().st_size,
                             '理由':'共用177MB入力と実行体は本文を複写せず、生成元/元SHAと別ビルドを参照'})
            continue
        if relative==source_path:continue
        assert path.stat().st_size<2_000_000,relative
        body=path.read_bytes();assert sha(body)==expected,relative
        if path.suffix=='.md':docs.append({'path':relative,'bytes':len(body),'sha256':expected,'本文':body.decode('utf-8')})
        if expected in by_sha:
            group_at,old=by_sha[expected]
            saved[group_at]['格納源'].append({'ZIP内path':old['path'],'復元先':relative,'bytes':len(body),'sha256':expected,'固定方法':'137 F0直接固定、既保存同体原文を参照'})
        else:
            new.append({'path':relative,'bytes':len(body),'sha256':expected,'固定方法':'137 F0直接固定'})
            bodies[relative]=body
    assert len(docs)==10 and sum(x['path'].startswith('study/') for x in docs)==3 and len(excluded)==2
    assert sum(len(x['格納源']) for x in saved)+len(new)==59
    for group in saved:
        group['格納源数']=len(group['格納源'])
        with zipfile.ZipFile(ROOT/group['保存元ZIP']) as z:
            assert z.testzip() is None
            for item in group['格納源']:assert sha(z.read(item['ZIP内path']))==item['sha256']
    dependencies=m136['間接固定の共有依存']
    for item in dependencies['格納源']:assert sha((ROOT/item['復元先']).read_bytes())==item['sha256']
    assert dependencies['格納源数']==10
    put(FORMAL/'検査/F0.json',original)
    snap={'試行':137,'段階':'Source自然実行前F0の結果編集前原文','F0_SHA256':F0_SHA,'文書数':10,'正式文書数':3,'金融前F1はまだ保存していない':True,'文書':docs}
    snap_body=(json.dumps(snap,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    put(FORMAL/'検査/実行前文書_F0.json.gz',gzip.compress(snap_body,mtime=0))
    source=next(x for x in m133['新共用入力'] if x['復元先']==source_path)
    body=(ROOT/source['保存元']).read_bytes();assert sha(body)==source['保存SHA256']
    assert sha(gzip.decompress(body))==source['解凍SHA256']==f0['ファイル'][str(ROOT/source_path)]
    archive=FORMAL/'再現資料/137_Source前F0資料.zip';archive.parent.mkdir(exist_ok=True)
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for item in new:z.writestr(item['path'],bodies[item['path']])
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for item in new:assert sha(z.read(item['path']))==item['sha256']
    m={'試行':137,'段階':'F0原文とSource再現源の準備だけ。結果未編集','F0_SHA256':F0_SHA,'F0直接源数':62,
       'F0追加資料':{'ZIP':archive.name,'ZIP_SHA256':sha(archive.read_bytes()),'ZIP_bytes':archive.stat().st_size,'格納源数':len(new),'格納源':new},
       'F0共有コード群':saved,
       '継承する再現用共有依存':{'保存元ZIP':dependencies['保存元ZIP'],'ZIP_SHA256':dependencies['ZIP_SHA256'],'格納源数':10,'格納源':dependencies['格納源'],
                         '扱い':'136保存版と現在同体を確認した再現用依存。137直接F0に含まれると後付けで主張しない。実行版はF0のexe SHAで固定'},
       'F0共有入力':[source],'意図して複製しないF0源':excluded,
       'F0原文MD':{'gzip':'検査/実行前文書_F0.json.gz','保存SHA256':sha((FORMAL/'検査/実行前文書_F0.json.gz').read_bytes()),'解凍SHA256':sha(snap_body),'MD数':10,'正式MD数':3},
       '金融前F1を作成':False,'結果文面を編集':False,'Sourceプロセスを操作':False,'自然Raw/CSV/177MB本文/追加2場読取':False}
    put(FORMAL/'保管索引.json',(json.dumps(m,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    proof={'成功':True,'試行':137,'段階':'F0原文と最小コードの先行保管','F0_SHA256':F0_SHA,'全F0原文MD':10,'正式MD':3,
           '追加ZIP源':len(new),'既保存共有源':sum(x['格納源数'] for x in saved),'再現用継承依存':10,'復元可能な直接F0源':60,
           '137のF0固定範囲を後付け拡大':False,'未複製源':excluded,'新結果/金融/Sourceプロセス操作':False,
           '追加ZIP_SHA256':m['F0追加資料']['ZIP_SHA256'],'コードSHA256':sha(Path(__file__).read_bytes())}
    put(FORMAL/'検査/F0原文と源の保管確認.json',(json.dumps(proof,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    print(json.dumps({'成功':True,'F0_MD':10,'正式MD':3,'新ZIP源':len(new),'共有源':sum(x['格納源数'] for x in saved),
                      'ZIP_SHA256':m['F0追加資料']['ZIP_SHA256'],'保管確認SHA256':sha((FORMAL/'検査/F0原文と源の保管確認.json').read_bytes())},ensure_ascii=False))


if __name__=='__main__':
    main()
