"""137の原文・全504セル・保存正本・再現・閲覧リンクを確認する。"""
from pathlib import Path
import gzip
import hashlib
import json
import re
import zipfile

ROOT = Path(__file__).resolve().parents[2]
FORMAL = next((ROOT / 'study').glob('00137_*'))


def sha(body: bytes) -> str:
    """
    機能: 資料のSHA256を返す。
    引数: body(bytes)。
    返り値: str。
    """
    return hashlib.sha256(body).hexdigest()


# ----------------------------------------
def cells(body: str) -> list:
    """
    機能: 版6の手法56行の9尺度セルを取り出す。
    引数: body(str)。
    返り値: listは行IDと9セル。
    """
    rows = []
    for line in body.splitlines():
        if re.match(r'^\| [A-Z]+\d{2} \|', line):
            values = [x.strip() for x in line.strip('|').split('|')]
            if len(values) == 11:
                rows.append([values[0], values[2:]])
    assert len(rows) == 56 and sum(len(x[1]) for x in rows) == 504
    return rows


# ----------------------------------------
def main() -> None:
    """
    機能: 正式137だけの保存状態を点検し完了票を保存する。
    引数: なし。
    返り値: None。Raw/追加2場/177MB/新金融を読まない。
    """
    m = json.loads((FORMAL / '保管索引.json').read_bytes())
    counts = []
    for stage, expected_count in [('F0', 10), ('F1', 12)]:
        f = (FORMAL / f'検査/{stage}.json').read_bytes()
        assert sha(f) == m[stage + '_SHA256']
        snapshot = json.loads(gzip.decompress((FORMAL / f'検査/実行前文書_{stage}.json.gz').read_bytes()))
        docs = snapshot['文書']; assert len(docs) == expected_count
        for item in docs:
            assert sha(item['本文'].encode('utf-8')) == item['sha256']
        official = [x for x in docs if x['path'].startswith('study/')]
        assert len(official) == 3
        original_table = next(x['本文'] for x in official if x['path'].endswith('/設定と結果.md'))
        assert cells(original_table) == cells((FORMAL / '設定と結果.md').read_text('utf-8'))
        original_conditions = next(x['本文'] for x in official if x['path'].endswith('/条件.md'))
        assert original_conditions.encode('utf-8') == (FORMAL / '条件.md').read_bytes()
        counts.append(len(docs))
    for name in ('F0追加資料', 'F1追加資料', '後発資料'):
        item = m[name]; p = FORMAL / '再現資料' / item['ZIP']; assert sha(p.read_bytes()) == item['ZIP_SHA256']
        with zipfile.ZipFile(p) as z:
            assert z.testzip() is None
            for source in item['格納源']:
                assert sha(z.read(source['path'])) == source['sha256']
    for item in m['F1共有コード群'] + [m['継承する再現用共有依存'], m['後段の再現用継承源']]:
        p = ROOT / item['保存元ZIP']; assert sha(p.read_bytes()) == item['ZIP_SHA256']
        with zipfile.ZipFile(p) as z:
            for source in item['格納源']:
                assert sha(z.read(source.get('ZIP内path', source.get('path')))) == source['sha256']
    for item in m['F1共有入力'] + m['新金融入力'] + [m['保存済み正逆観測']]:
        body = (ROOT / item['保存元']).read_bytes(); assert sha(body) == item['保存SHA256']
        raw = gzip.decompress(body) if item['形式'] == 'gzip' else body
        assert sha(raw) == item['解凍SHA256']
    final = json.loads((FORMAL / '成果物/集計.json').read_bytes())
    assert sha((FORMAL / '成果物/集計.json').read_bytes()) == 'f7c73cc87948fa17174e3909f89aa63d74abe76191bf435788e71cb0d400548b'
    a = final['集計']['all']['A0']['BBO']['3600']['125']
    assert [a[k] for k in ('entries', 'forward', 'adverse', 'neither', 'censored', 'ifd_known', 'ifd_unknown', 'ifd_net5_profit', 'ifd_net5_loss', 'ifd_net5_sum')] == [81,40,18,17,6,78,3,518227,318233,199994]
    assert final['主評価']['全73場最低1取得'] and not final['主評価']['三項目すべて達成']
    independent = (FORMAL / '検査/独立金融_独立確認.json').read_bytes()
    assert sha(independent) == 'a29d965fb915cf424f1e971c61672bcc973600486c0a09f0a4b5af638ab7251c'
    stop = json.loads((FORMAL / '検査/独立金融_完了.json').read_bytes())
    assert stop['編集停止'] and stop['人工成功'] and stop['人工主検査数'] == 5
    csv = json.loads((FORMAL / '検査/CSV再読の確認.json').read_bytes())
    assert csv['全データセル比較数'] == 31117 and csv['数値比較数'] == 15556 and csv['前後不変']
    output = ROOT / 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/137既知回復CSV'
    for item in csv['表別']:
        p = output / Path(item['CSV']['path']).name
        assert sha(p.read_bytes()) == item['CSV']['sha256']
    assert not list(output.glob('*.xlsx'))
    replay = json.loads((FORMAL / '検査/保存観測の再現確認.json').read_bytes())
    assert replay['F1全93中90源同体'] and replay['全金融数値/旧対照/頻度/phase/bootstrap一致']
    assert replay['全三表bytes一致_SHA256'] == '9c88bea44a03c6c92198f15c5a06410cb2f48b5f63e494fb17814d48ceae6aeb'
    cause = (FORMAL / '検査/出生から取得の診断確認.json').read_bytes()
    assert sha(cause) == '36aaa2a68a3be39405d1a3a6d1dff63ea07f6c4bc299407bcad6d88edc5b1329'
    indices = [ROOT / p for p in ('README.md', 'study/README.md', 'docs/README.md', 'docs/議論/README.md')]
    docs = list(FORMAL.glob('*.md')) + indices + [output / 'README.md', ROOT / 'docs/議論/既知回復の公表時計と実取得の壁を分ける.md']
    links = 0
    for p in docs:
        body = p.read_text('utf-8')
        if p in indices:
            assert '[137：' in body
            body = body.split('\n\n', 2)[1]
        for match in re.finditer(r'\]\(([^)]+)\)', body):
            target = match.group(1).strip('<>')
            if target.startswith(('https:', 'http:', '#', 'mailto:')):
                continue
            target = target.split('#', 1)[0]
            assert (p.parent / target).resolve().exists(), (str(p), target)
            links += 1
    proof = {'成功': True, '試行': 137, '正式保存完了': True, 'F0/F1全原文MD': counts, '正式原文MD': [3,3],
             '全56手法504セル/条件原文不変': True, '金融前原本の後付け偽造': False,
             'F1復元源': 90, '未複製源': 3, '新Source/金融入力gzip': 3,
             'Source/Raw/巨大入力/追加2場再走査': False, '新金融観測/CSV生成': False,
             '保存239観測から全数値/三表bytes再現': True,
             '独立金融全条件': 300, '独立表セル': 31117, '独立人工': 5,
             '実CSV再読セル/数値': [31117,15556], '旧C0T8条件/四streamラベル': [60,3160],
             'phase': final['全4streamのphase検査'], '4索引': True, '新規/正式文書の有効ローカルリンク': links,
             '主A0': {k: a[k] for k in ('entries','forward','adverse','neither','censored','ifd_known','ifd_unknown','ifd_net5_profit','ifd_net5_loss','ifd_net5_sum')},
             '目標達成': False, '全期既使用': True, '増分取得2のみ': True, '重大不足': [],
             'F0_SHA256': m['F0_SHA256'], 'F1_SHA256': m['F1_SHA256'], '保管索引SHA256': sha((FORMAL / '保管索引.json').read_bytes()),
             '後発ZIP_SHA256': m['後発資料']['ZIP_SHA256'], '確認コードSHA256': sha(Path(__file__).read_bytes())}
    path = FORMAL / '検査/正式保存の最終確認.json'
    assert not path.exists(); path.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '最終確認SHA256': sha(path.read_bytes()), '重大不足': [], 'ローカルリンク': links}, ensure_ascii=False))


if __name__ == '__main__':
    main()
