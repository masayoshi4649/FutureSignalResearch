"""137の保存F0を復元先で照合し、Sourceを実行せずGoビルドだけ確認する。"""
from pathlib import Path
import gzip
import hashlib
import json
import re
import subprocess

ROOT=Path(__file__).resolve().parents[2]
FORMAL=ROOT/'study/00137_市場終端後の既知回復を公表時点で確認する'
RESTORED=ROOT/'work/137F0資料の復元確認'


def sha(path: Path) -> str:
    """
    機能: 復元先コードと資料の指紋を返す。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def cells(text: str) -> dict:
    """
    機能: 版6の全504設定セルを抽出する。
    引数: text(str)。
    返り値: dictは56手法×9尺度。
    """
    result={}
    for line in text.splitlines():
        if re.match(r'^\| [A-Z][0-9]{2} ',line):
            p=[x.strip() for x in line.split('|')[1:-1]]
            if len(p)==11:result[p[0]]=p[2:]
    assert len(result)==56
    return result


# ----------------------------------------
def main() -> None:
    """
    機能: 保存原文・復元コード・共有依存を照合し、人工や自然走査を起動せずビルドする。
    引数: なし。
    返り値: None。177MB/Raw/追加場/金融は読まず、作業用実行体だけ生成する。
    """
    target=FORMAL/'検査/F0保存資料の復元確認.json';assert not target.exists()
    m=json.loads((FORMAL/'保管索引.json').read_bytes())
    f0=json.loads((FORMAL/'検査/F0.json').read_bytes())
    assert sha(RESTORED/'work/137既知回復の評価/F0.json')==m['F0_SHA256']
    before={}
    old_root=next(Path(p).parents[2] for p in f0['ファイル'] if p.endswith('study\\00137_市場終端後の既知回復を公表時点で確認する\\README.md'))
    excluded={x['path'] for x in m['意図して複製しないF0源']}
    for path,expected in f0['ファイル'].items():
        relative=Path(path).relative_to(old_root).as_posix()
        if relative in excluded:
            assert not (RESTORED/relative).exists();continue
        assert sha(RESTORED/relative)==expected,relative
        before[relative]=expected
    assert len(before)==60
    for item in m['継承する再現用共有依存']['格納源']:
        assert sha(RESTORED/item['復元先'])==item['sha256']
        before[item['復元先']]=item['sha256']
    assert len(before)==70
    snap=json.loads(gzip.decompress((FORMAL/'検査/実行前文書_F0.json.gz').read_bytes()))
    assert len(snap['文書'])==10 and snap['正式文書数']==3
    for item in snap['文書']:
        body=item['本文'].encode('utf-8')
        assert hashlib.sha256(body).hexdigest()==item['sha256'] and len(body)==item['bytes']
        assert (RESTORED/item['path']).read_bytes()==body
        if item['path'].endswith('/設定と結果.md'):
            assert cells(item['本文'])==cells((FORMAL/'設定と結果.md').read_text('utf-8'))
    native=RESTORED/'work/137既知回復をSourceへ接続する/Source再生器'
    output=native/'復元用ビルド確認.exe';assert not output.exists()
    command=['go','build','-o',str(output),'./cmd/e1source']
    run=subprocess.run(command,cwd=native,capture_output=True,text=True,encoding='utf-8')
    assert run.returncode==0,(run.stdout,run.stderr)
    assert all(sha(RESTORED/p)==h for p,h in before.items())
    proof={'成功':True,'試行':137,'段階':'保存F0の復元とビルドだけ','F0直接復元源':60,
           '継承する再現用共有依存':10,'全F0原文MD':10,'正式MD':3,'504セル不変':True,
           'F0と復元コードはビルド前後同体':True,'共有依存だけでSourceビルド成功':True,
           '実行列':command,'復元ビルドexe_SHA256':sha(output),'元F0実行体と同体とは主張しない':True,
           'Sourceを起動':False,'Source結果は本確認の対象外':True,
           '自然Raw/CSV/177MB本文/追加2場読取':False,'金融F1/新金融/CSV生成':False,
           '重大不足':[],'確認コードSHA256':sha(Path(__file__))}
    with target.open('x',encoding='utf-8') as handle:
        handle.write(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'成功':True,'復元60+共有依存10源':True,'Sourceビルド成功':True,
                      '確認SHA256':sha(target),'Source起動':False,'金融実行':False},ensure_ascii=False))


if __name__=='__main__':
    main()
