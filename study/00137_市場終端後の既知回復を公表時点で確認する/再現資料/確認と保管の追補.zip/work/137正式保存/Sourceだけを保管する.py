"""137の確定Sourceと非金融確認だけを先に保存し、金融前後の資料は混ぜない。"""
from pathlib import Path
import gzip
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
FORMAL=ROOT/'study/00137_市場終端後の既知回復を公表時点で確認する'
OWN=ROOT/'work/137既知回復の評価'


def sha(body: bytes) -> str:
    """
    機能: 保存原文の指紋を返す。
    引数: body(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


# ----------------------------------------
def put(path: Path, body: bytes) -> None:
    """
    機能: 未作成先に原文を保存する。
    引数: path(Path)、body(bytes)。
    返り値: None。
    """
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as handle:handle.write(body)


# ----------------------------------------
def main() -> None:
    """
    機能: Source一度gzipと走査/非金融確認を保管し、結果MDや金融計算には触れない。
    引数: なし。
    返り値: None。自然Raw/177MB/追加2場は開かない。
    """
    body=(OWN/'Sourceの出生と取得.json').read_bytes()
    assert sha(body)=='d5c2e8e772e1658015d82497760b56ef40d6cae07da40eb8f148f601795628e5'
    checked=(OWN/'Source非金融の確認.json').read_bytes()
    assert sha(checked)=='10ce6d7eec7d7343dbe0b9fd62533bce10c832cce6559de41694e48efd306eff'
    check=json.loads(checked);assert check['成功'] and check['Source_SHA256']==sha(body)
    assert check['合計']=={'C0':79,'S0':79,'A0':81,'E1出生':9,'E1候補':9,'E1取得':2}
    put(FORMAL/'検査/Source非金融の確認.json',checked)
    put(FORMAL/'検査/Source走査の完了.json',(OWN/'Source走査の完了.json').read_bytes())
    folder=ROOT/'inputs/00137_公表時確認のSource入力';folder.mkdir(exist_ok=True)
    saved=folder/'Sourceの出生と取得.json.gz';packed=gzip.compress(body,compresslevel=9,mtime=0);put(saved,packed)
    item={'保存元':saved.relative_to(ROOT).as_posix(),'復元先':'work/137既知回復の評価/Sourceの出生と取得.json','形式':'gzip',
          '保存bytes':len(packed),'保存SHA256':sha(packed),'解凍bytes':len(body),'解凍SHA256':sha(body)}
    path=FORMAL/'保管索引.json';m=json.loads(path.read_bytes());assert '新Source入力' not in m
    m['新Source入力']=item
    m['Source保管範囲']='非金融Sourceのみ。新2取得があるため金融F1/正逆/集計は後続で別保存。結果MDはまだ編集しない'
    path.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'Source_bytes':len(body),'Source_gzip_bytes':len(packed),'保存gzip_SHA256':sha(packed),
                      '新取得':2,'結果MD変更':False,'新金融実行':False},ensure_ascii=False))


if __name__=='__main__':
    main()
