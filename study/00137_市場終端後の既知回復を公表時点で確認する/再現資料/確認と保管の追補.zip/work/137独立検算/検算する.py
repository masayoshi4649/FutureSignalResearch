"""137の固定取得正逆Quoteを独立式で検算する。Root/124/137金融算術はimportしない。"""
import argparse
import datetime
import hashlib
import json
import math
from collections import Counter
from fractions import Fraction
from pathlib import Path
from statistics import median

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
POLICIES=('A0','C0','S0','O0','R0')
DISPLAY=POLICIES
MODELS=('A0','C0','S0')
MODEL={'A0':'A0','C0':'C0','S0':'S0','O0':'A0','R0':'A0'}
WIDTHS=(25,50,100,125,200)
HORIZONS=(1800,3600)
AXES=('BBO','Last')

def sha(path: Path) -> str:
    """
    機能: ファイルのSHA256を求める。
    引数: path(Path)は対象。
    返り値: strは小文字16進SHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()

def equal(actual: object, expected: object, location: str='') -> int:
    """
    機能: 型・未知・有限数値を区別して再帰照合する。
    引数: actual/expected(object)、location(str)は実値・期待値・位置。
    返り値: intは一致した末端値の数。不一致はAssertionError。
    """
    if isinstance(expected,dict):
        assert isinstance(actual,dict) and actual.keys()==expected.keys(),(location,'keys')
        return sum(equal(actual[k],v,location+'/'+str(k)) for k,v in expected.items())
    if isinstance(expected,list):
        assert isinstance(actual,list) and len(actual)==len(expected),(location,'length')
        return sum(equal(a,b,location+'/'+str(i)) for i,(a,b) in enumerate(zip(actual,expected)))
    if expected is None or type(expected) is bool:
        assert type(actual) is type(expected) and actual==expected,(location,actual,expected)
    elif type(expected) in (int,float):
        assert type(actual) in (int,float) and math.isfinite(actual) and math.isclose(actual,expected,rel_tol=1e-12,abs_tol=1e-8),(location,actual,expected)
    else:assert actual==expected,(location,actual,expected)
    return 1

def number(fields: dict, key: str) -> float | None:
    """
    機能: 既知の有限値だけを取り出し、未知はNoneにする。
    引数: fields(dict)、key(str)は保存票と項目。
    返り値: float|Noneは既知値又は未知。
    """
    if key not in fields:return None
    f=fields[key];assert type(f['known']) is bool
    if not f['known']:return None
    value=f['value'];assert type(value) in (int,float) and math.isfinite(value)
    return value

def observation(candidate: dict, horizon: int) -> dict:
    """
    機能: 指定期限の観測を一意に取り出す。
    引数: candidate(dict)、horizon(int)は候補と秒数。
    返り値: dictは観測。
    """
    matches=[o for o in candidate['outcomes'] if o['seconds']==horizon];assert len(matches)==1
    return matches[0]

def touch(outcome: dict, width: int) -> dict:
    """
    機能: 同幅の保存先着を一意に取り出す。
    引数: outcome(dict)、width(int)は観測とpt。
    返り値: dictは先着票。
    """
    matches=[t for t in outcome['touches'] if t['width']==width];assert len(matches)==1
    return matches[0]

def side_for(record: dict, policy: str) -> int:
    """
    機能: 固定した5政策の向きを保存票から選ぶ。
    引数: record(dict)、policy(str)は結合票と政策。
    返り値: intは±1。勝敗を使わない。
    """
    m=record['meta']
    return m['source_side'] if policy=='O0' else -m['selected_side'] if policy=='R0' else m['selected_side']

def choose(record: dict, policy: str, axis: str) -> dict:
    """
    機能: 同じ取得Quoteの実正逆又はLast参考候補を選ぶ。
    引数: record(dict)、policy/axis(str)は結合票・政策・価格軸。
    返り値: dictは保存候補。
    """
    assert record['meta']['model']==MODEL[policy]
    name='original' if side_for(record,policy)==record['case']['original_side'] else 'reverse'
    return record['case'][('chart_' if axis=='Last' else '')+name]

def points(candidate: dict, quote: dict, axis: str) -> int | float:
    """
    機能: 保存清算Quoteから実側の符号付き値幅を計算する。
    引数: candidate/quote(dict)、axis(str)は取得・清算・軸。
    返り値: int|floatはpt。
    """
    side=candidate['birth']['side'];mark=quote['last'] if axis=='Last' else quote['bid'] if side>0 else quote['ask']
    return side*(mark-candidate['entry_price'])

def ifd(candidate: dict, horizon: int, width: int, axis: str) -> dict:
    """
    機能: 既知touch優先でIFD代用を算出し、H不足の未到達は未知にする。
    引数: candidate(dict)、horizon/width(int)、axis(str)は方向と観測条件。
    返り値: dictは既知/理由/pt/C0/C5。Lastの金額はNone。
    """
    o=observation(candidate,horizon);t=touch(o,width)
    if t['direction']:
        quote=t['quote'];reason='順行到達' if t['direction']>0 else '逆行到達'
    elif o['status']=='complete':quote=o['endpoint'];reason='期限清算'
    else:return {'known':False,'reason':'観測不足','points':None,'net0':None,'net5':None}
    assert quote is not None
    p=points(candidate,quote,axis)
    return {'known':True,'reason':reason,'points':p,
            'net0':p*100-77 if axis=='BBO' else None,'net5':p*100-1077 if axis=='BBO' else None}

def stats(records: list[dict], policy: str, axis: str, horizon: int, width: int) -> dict:
    """
    機能: 保存QuoteとFractionから全率/分母/利益/損失/PFを独立集計する。
    引数: records(list[dict])、policy/axis(str)、horizon/width(int)は取得集合と条件。
    返り値: dictは主算術集計。Root集計/124算術を呼ばない。
    """
    selected=[choose(r,policy,axis) for r in records]
    complete=[observation(c,horizon) for c in selected if observation(c,horizon)['status']=='complete']
    counts=Counter(touch(o,width)['direction'] for o in complete);forward=counts[1];adverse=counts[-1];resolved=forward+adverse
    exits=[ifd(c,horizon,width,axis) for c in selected];known=[e for e in exits if e['known']]
    money=[e['net5'] for e in known] if axis=='BBO' else []
    profit=sum(x for x in money if x>0);loss=-sum(x for x in money if x<0)
    return {'entries':len(records),'sessions':len({r['session'] for r in records}),
            'complete':len(complete),'censored':len(selected)-len(complete),
            'forward':forward,'adverse':adverse,'neither':counts[0],'resolved':resolved,
            'resolved_rate':float(Fraction(forward,resolved)) if resolved else None,
            'complete_rate':float(Fraction(forward,len(complete))) if complete else None,
            'target70':Fraction(forward,resolved)>=Fraction(7,10) if resolved else None,
            'target70_all':Fraction(forward,len(complete))>=Fraction(7,10) if complete else None,
            'ifd_known':len(known),'ifd_unknown':len(exits)-len(known),
            'ifd_exits':dict(Counter(e['reason'] for e in exits)),
            'ifd_net0_sum':sum(e['net0'] for e in known) if axis=='BBO' and known else None,
            'ifd_net5_sum':sum(money) if money else None,
            'ifd_net5_mean':float(Fraction(sum(money))/len(money)) if money else None,
            'ifd_net5_profit':profit if money else None,'ifd_net5_loss':loss if money else None,
            'ifd_net5_pf':float(Fraction(profit)/Fraction(loss)) if loss else None,
            'ifd_net5_positive':sum(x>0 for x in money) if axis=='BBO' else None,
            'ifd_points_mean':float(Fraction(sum(e['points'] for e in known))/len(known)) if known else None,
            'flips':sum(c['birth']['side']!=r['case']['original_side'] for c,r in zip(selected,records))}

def subset(records: list[dict], policy: str, sessions: list[str]) -> list[dict]:
    """
    機能: 政策が属する取得集合と場だけを選ぶ。
    引数: records(list[dict])、policy(str)、sessions(list[str])は全票・政策・場順。
    返り値: list[dict]は母集団を混ぜない部分集合。
    """
    return [r for r in records if r['meta']['model']==MODEL[policy] and r['session'] in sessions]

def join(result: dict, fixed: dict, metadata: dict) -> tuple[list[dict],list[str],dict]:
    """
    機能: 全4価格streamを固定取得に結合し、phase/清算価格を独立点検する。
    引数: result/fixed/metadata(dict)は観測・固定取得・出生票。
    返り値: tuple[list[dict],list[str],dict]は全票・73場順・検査件数。
    """
    mmap={(m['session'],m['id']):m for m in metadata['entries']};seen=set();records=[];counts=Counter()
    assert result['success'] and result['trial']==133 and result['source_entry_count']==239
    sessions=[]
    for s,f in zip(result['scenes'],fixed['scenes']):
        sid=s['session'];sessions.append(sid);assert sid==f['session'] and s['success']
        boundary=f['end']-300;limit=min(f['force_close'],boundary-3600)
        assert s['execution_end']==boundary and s['effective_entry_limit']==limit and s['source_force_close']==f['force_close']
        assert s['quality']==s['expected_quality']==f['expected_quality'] and s['actual_sha256']==f['raw']['sha256']
        inputs={e['id']:e for e in f['entries']};assert len(inputs)==len(s['cases'])
        for c in s['cases']:
            key=(sid,c['id']);assert key in mmap and key not in seen;seen.add(key);m=mmap[key];entry=inputs[c['id']]['entry']
            assert c['original_side']==inputs[c['id']]['side']==m['source_side'] and entry==m['entryQuote'] and entry['time']<limit
            for name in ('original','reverse','chart_original','chart_reverse'):
                stream=c[name];axis='Last' if name.startswith('chart') else 'BBO'
                side=c['original_side']*(1 if name.endswith('original') else -1)
                assert stream['status']=='filled' and stream['birth']['side']==side and stream['entry']==entry
                assert stream['entry_price']==(entry['last'] if axis=='Last' else entry['ask'] if side>0 else entry['bid'])
                counts['stream検査']+=1;counts['entry検査']+=1
                assert tuple(o['seconds'] for o in stream['outcomes'])==HORIZONS
                for o in stream['outcomes']:
                    assert o['deadline']==entry['time']+o['seconds'] and tuple(t['width'] for t in o['touches'])==WIDTHS
                    assert (o['endpoint'] is not None)==(o['status']=='complete')
                    q=o['endpoint']
                    if q is not None:
                        assert o['deadline']<=q['time']<=o['deadline']+30 and q['time']<boundary
                        assert q['index']>entry['index'] and q['source_line']>entry['source_line'] and q['quote_ok'] and 0<q['bid']<q['ask']
                        p=points(stream,q,axis);equal(o['points'],p,'endpoint points')
                        equal(o['net0'],p*100-77 if axis=='BBO' else None,'endpoint C0')
                        equal(o['net5'],p*100-1077 if axis=='BBO' else None,'endpoint C5')
                        counts['endpoint検査']+=1
                    else:assert o['points'] is None and o['net0'] is None and o['net5'] is None
                    for t in o['touches']:
                        assert type(t['direction']) is int and t['direction'] in (-1,0,1)
                        q=t['quote'];assert (q is None)==(t['direction']==0)
                        if q is None:continue
                        assert entry['time']<=q['time']<=o['deadline'] and q['time']<boundary
                        assert q['index']>entry['index'] and q['source_line']>entry['source_line'] and q['quote_ok'] and 0<q['bid']<q['ask']
                        p=points(stream,q,axis)
                        assert p>=t['width'] if t['direction']>0 else p<=-t['width']
                        counts['touch検査']+=1
            
            if m['kind']=='E1':
                assert m['direction_policy']=='pattern' and m['selected_side']==m['source_side'] and m['direction'] is None
                counts['E1回復trace照合' if m['e1_recovery_trace'] is not None else 'E1回復traceなし_部品証跡継承']+=1
            records.append({'session':sid,'case':c,'meta':m})
    assert len(sessions)==len(set(sessions))==73 and seen==set(mmap) and len(records)==239
    return records,sessions,dict(counts)

def jst(at: float) -> str:
    """
    機能: Unix秒を閲覧表の日本時間書式へ変換する。
    引数: at(float)は時刻。
    返り値: strは秒精度のJST。
    """
    return datetime.datetime.fromtimestamp(at,datetime.timezone(datetime.timedelta(hours=9))).isoformat(sep=' ')


def frequency(records: list[dict],sessions: list[str],scenes: list[dict]) -> dict:
    """
    機能: 全場時計の加重頻度と別の場別分布をFractionで独立計算する。
    引数: records/sessions/scenes(list)は固定取得と場時計。
    返り値: dictは勝敗を使わない頻度。
    """
    clocks={s['session']:s for s in scenes};counts=Counter((r['meta']['model'],r['session']) for r in records)
    full={sid:Fraction(clocks[sid]['end']-300-clocks[sid]['start'])/3600 for sid in sessions}
    eligible={sid:Fraction(min(clocks[sid]['force_close'],clocks[sid]['end']-3900)-clocks[sid]['start'])/3600 for sid in sessions}
    result={'定義':'全時間=sum(end-300-start)/3600。全場を残す。名目新規可時間=sum(min(force_close,end-3900)-start)/3600は副評価',
            '場別':{},'各場回数cap':False,'毎時強制':False}
    for sid in sessions:
        assert full[sid]>0 and eligible[sid]>0
        result['場別'][sid]={'全時間h':float(full[sid]),'名目新規可時間h':float(eligible[sid]),
            'models':{m:{'取得数':counts[m,sid],'全時間頻度':float(counts[m,sid]/full[sid]),'名目新規可時間頻度':float(counts[m,sid]/eligible[sid])} for m in MODELS}}
    for part,ids in (('all',sessions),('train',sessions[:48]),('validation',sessions[48:])):
        result[part]={};hours=sum(full[s] for s in ids);ehours=sum(eligible[s] for s in ids)
        for model in MODELS:
            n=sum(counts[model,s] for s in ids);rates=[counts[model,s]/full[s] for s in ids]
            result[part][model]={'対象場数':len(ids),'取得数':n,'全時間h':float(hours),'名目新規可時間h':float(ehours),
                '全時間平均件数毎時':float(n/hours),'名目新規可時間平均件数毎時':float(n/ehours),'全時間平均1件毎時以上':n/hours>=1,
                '場別頻度分布':{'最小':float(min(rates)),'中央値':float(median(rates)),'最大':float(max(rates)),
                    '単純平均_主平均ではない':float(sum(rates)/len(rates)),'0取得場数':sum(r==0 for r in rates),'1件毎時以上場数':sum(r>=1 for r in rates)}}
    return result


def tables_check(tables: list[dict],records: list[dict],sessions: list[str],values: dict,participation: dict,freq: dict) -> dict:
    """
    機能: 独立式と固定metadataから3表全セルを照合する。
    引数: tables/records/sessions(list)、values/participation/freq(dict)は表と独立期待値。
    返り値: dictは31117セルの照合結果。実CSVの再読・描画は別担当。
    """
    assert [(t['name'],len(t['rows']),len(t['headers'])) for t in tables]==[('正逆比較',300,34),('入口別診断',239,64),('全セッション',73,77)]
    cells=0;seen=set()
    for row in tables[0]['rows']:
        a=dict(zip(tables[0]['headers'],row));part,p,axis=a['区分'],a['政策'],a['価格軸'];h=int(a['評価分']*60);w=a['同幅pt'];key=(part,p,axis,h,w)
        assert key not in seen;seen.add(key);s=values[part][p][axis][str(h)][str(w)];v=participation[part][MODEL[p]];f=freq[part][MODEL[p]]
        quality=bool(v['全場最低1取得'] and s['target70'] is True)
        e={'試行':137,'区分':part,'政策':p,'取得集合':MODEL[p],'価格軸':axis,'評価分':h/60,'同幅pt':w,'対象場数':v['対象場数'],
           '取得場数':s['sessions'],'取得数':s['entries'],'Source向きからの反転数':s['flips'],'全場最低1取得':v['全場最低1取得'],
           '全H完了':s['complete'],'観測不足':s['censored'],'順行先着':s['forward'],'逆行先着':s['adverse'],'両方未到達':s['neither'],
           '到達済み順行率':s['resolved_rate'],'完了分母順行率':s['complete_rate'],'全取得分母順行率':float(Fraction(s['forward'],s['entries'])) if s['entries'] else None,
           '到達済み70%達成':s['target70'],'参加と70%両達成':quality,'全時間平均件数毎時':f['全時間平均件数毎時'],
           '名目新規可時間平均件数毎時':f['名目新規可時間平均件数毎時'],'全時間平均1件毎時以上':f['全時間平均1件毎時以上'],
           '参加と70%と頻度すべて達成':quality and f['全時間平均1件毎時以上'],'IFD代用既知':s['ifd_known'],'IFD代用未知':s['ifd_unknown'],
           'C0代用差引円':s['ifd_net0_sum'],'C5代用利益円':s['ifd_net5_profit'],'C5代用損失絶対円':s['ifd_net5_loss'],
           'C5代用差引円':s['ifd_net5_sum'],'C5代用平均円':s['ifd_net5_mean'],'C5代用PF':s['ifd_net5_pf']}
        cells+=equal(a,e,'比較表/'+str(key))
    assert len(seen)==300
    t=tables[1];assert [r[t['headers'].index('出生ID')] for r in t['rows']]==[r['case']['id'] for r in records]
    for row,r in zip(t['rows'],records):
        m=r['meta'];c=r['case'];d=m['direction'];f=d['fields'] if d else {}
        e={'試行':137,'参考区分':'train' if r['session'] in sessions[:48] else 'validation','セッション':r['session'],'取得集合':m['model'],
           '出生ID':c['id'],'Source出生ID':m['source_id'],'旧対照ID':m['legacy_id'],'入口種別':m['kind'],'方向規則':m['direction_policy'],
           '元方向':c['original_side'],'B0方向':d['b0_side'] if d else None,'T8方向':d['t8_side'] if d else None,
           '選択方向':m['selected_side'],'E0保護':d['e0_protected'] if d else None,'出生JST':jst(m['birth']['time']),
           '取得JST':jst(m['entryQuote']['time']),'元取得価格':c['original']['entry_price'],'逆取得価格':c['reverse']['entry_price']}
        for key,value,known in (('body5_signed_ratio_to_source','5分実体比_Source','実体既知'),('ema21_delta30_to_B0','30分EMA21増分_B0','長期既知'),
                                ('hist5_atr_to_B0','5分HistATR_B0','勢い既知'),('atr5','ATR5','ATR既知')):
            x=m['e1_event']['atr5'] if key=='atr5' and m['kind']=='E1' else number(f,key);e[value]=x;e[known]=x is not None
        names=('E1接触JST','E1K固定JST','E1新5分EndJST','E1新5分配送JST','E1回復1分StartJST','E1回復1分EndJST','E1維持行数','E1維持秒数')
        if m['kind']=='E1':
            f=m['e1_event']['fields'];e.update(zip(names,[jst(f['contact']['time']),jst(f['K_frozen_at']['time']),jst(f['improvement_ref']['end']),
                jst(f['improvement_ref']['delivered']['time']),jst(f['recovery_minute']['start']),jst(f['recovery_minute']['end']),f['hold_rows'],f['hold_elapsed_seconds']]))
        else:e.update(dict.fromkeys(names,None))
        for p in POLICIES:
            names=[p+n for n in ('方向','125全H','125先着','IFD既知','清算','125C5代用円')]
            if m['model']!=MODEL[p]:e.update(dict.fromkeys(names,None));continue
            q=choose(r,p,'BBO');o=observation(q,3600);x=ifd(q,3600,125,'BBO')
            e.update(zip(names,[q['birth']['side'],o['status'],touch(o,125)['direction'],x['known'],x['reason'],x['net5']]))
        cells+=equal(dict(zip(t['headers'],row)),e,'入口表/'+c['id'])
    t=tables[2];assert [r[t['headers'].index('セッション')] for r in t['rows']]==sessions
    cumulative=Counter();unknown=Counter()
    for i,(row,sid) in enumerate(zip(t['rows'],sessions)):
        f=freq['場別'][sid];e={'試行':137,'セッション':sid,'参考区分':'train' if i<48 else 'validation','ザラバ時間h':f['全時間h'],'名目新規可時間h':f['名目新規可時間h']}
        for m in MODELS:
            v=f['models'][m];e.update({m+'取得数':v['取得数'],m+'最低1取得':bool(v['取得数']),m+'全時間頻度':v['全時間頻度'],m+'名目新規可時間頻度':v['名目新規可時間頻度']})
        for p in POLICIES:
            s=stats(subset(records,p,[sid]),p,'BBO',3600,125);cumulative[p]+=s['ifd_net5_sum'] or 0;unknown[p]+=s['ifd_unknown']
            e.update({p+'反転数':s['flips'],p+'125順':s['forward'],p+'125逆':s['adverse'],p+'125未到達':s['neither'],p+'全H不足':s['censored'],
                p+'IFD既知':s['ifd_known'],p+'IFD未知':s['ifd_unknown'],p+'C5利益円':s['ifd_net5_profit'],p+'C5損失絶対円':s['ifd_net5_loss'],
                p+'C5既知差引円':s['ifd_net5_sum'],p+'C5既知累計円_口座収支ではない':cumulative[p],p+'累計IFD未知':unknown[p]})
        cells+=equal(dict(zip(t['headers'],row)),e,'場表/'+sid)
    assert cells==31117
    return {'success':True,'table_dimensions':[[300,34],[239,64],[73,77]],'all_data_cells_equal':cells,'actual_csv_reread_or_render':False}


def main() -> None:
    """
    機能: 許可済み金融JSONを独立式で300条件・全表・頻度・旧対照へ照合する。
    引数: なし。Root通知SHAと固定3資料を使用する。
    返り値: None。独立proofを未作成先へ保存する。
    """
    paths={
      'fixed':('work/137既知回復の評価/固定入力/固定取得入力.json','be370b6316af511804d9e7c2ef2d3b17b9bbc4eea7f24140f3ca9800913567fc'),
      'metadata':('work/137既知回復の評価/固定入力/方向と出生.json','86f33705ba40fd3ba1b845557a2368e44c2802635082fc3bad69346770103f93'),
      'result':('work/137既知回復の評価/固定取得の正逆観測.json','f0adca92cf1f1db25e75e4d92187952e2920ea7126b3790ece89df1c7f00369a'),
      'aggregate':('work/137既知回復と頻度の集計/集計.json','f7c73cc87948fa17174e3909f89aa63d74abe76191bf435788e71cb0d400548b'),
      'tables':('work/137既知回復と頻度の集計/CSV用の表.json','9c88bea44a03c6c92198f15c5a06410cb2f48b5f63e494fb17814d48ceae6aeb'),
      'F1':('work/137既知回復の評価/F1.json','2d816fe6e8de7c5e5112d89f29f59113e53ba810cbbf43d43beb025cc24b6618'),
      'oldpairs':('work/124入口の正逆比較/全73場の正逆結果.json','25517066b291a0434211190299b9f0195e67f9a7d2e89c801d5b9e6b4b51c3a1'),
      'old126':('work/126複合切替の探索/集計.json','e30aca19e553ded53ccdd3b1785bd6168e19dd210aa9c32c1f9625c0063fdcd8')}
    assert all(sha(ROOT/p)==h for p,h in paths.values())
    load=lambda k:json.loads((ROOT/paths[k][0]).read_text(encoding='utf-8-sig'))
    fixed,metadata,result,aggregate=load('fixed'),load('metadata'),load('result'),load('aggregate')
    assert metadata['trial']==137 and metadata['fixed_input_sha256']==result['input_sha256']==paths['fixed'][1]
    assert fixed['expected_entry_count']==239 and metadata['counts']=={'C0':79,'S0':79,'A0':81}
    assert aggregate['試行']==137 and aggregate['主政策']=='A0' and aggregate['F1_SHA256']==paths['F1'][1]
    assert aggregate['固定入力SHA256']==paths['fixed'][1] and aggregate['方向metadataSHA256']==paths['metadata'][1] and aggregate['自然結果SHA256']==paths['result'][1]
    records,sessions,phase=join(result,fixed,metadata)
    parts={'all':sessions,'train':sessions[:48],'validation':sessions[48:]};values={};participation={};condition_count=0;leaves=0
    for part,ids in parts.items():
        values[part]={};participation[part]={}
        for m in MODELS:
            rs=[r for r in records if r['meta']['model']==m and r['session'] in ids];missing=[sid for sid in ids if not any(r['session']==sid for r in rs)]
            participation[part][m]={'対象場数':len(ids),'取得数':len(rs),'取得場数':len(ids)-len(missing),'未取得場数':len(missing),'未取得場':missing,'全場最低1取得':not missing and bool(ids)}
        for p in POLICIES:
            values[part][p]={}
            for axis in AXES:
                values[part][p][axis]={}
                for h in HORIZONS:
                    values[part][p][axis][str(h)]={}
                    for w in WIDTHS:
                        s=stats(subset(records,p,ids),p,axis,h,w);values[part][p][axis][str(h)][str(w)]=s
                        leaves+=equal(aggregate['集計'][part][p][axis][str(h)][str(w)],s,f'{part}/{p}/{axis}/{h}/{w}');condition_count+=1
    assert condition_count==300;equal(aggregate['参加'],participation);equal(aggregate['全4streamのphase検査'],phase)
    freq=frequency(records,sessions,fixed['scenes']);equal(aggregate['頻度'],freq,'頻度')
    s=values['all']['A0']['BBO']['3600']['125'];p=participation['all']['A0'];hour=freq['all']['A0']['全時間平均1件毎時以上'];rate=s['target70'] is True
    goal={'主':'A0/全73場/実BBO/H60/±125pt','全73場最低1取得':p['全場最低1取得'],'到達済み先着70%以上':rate,
      '入口品質の両条件達成':bool(p['全場最低1取得'] and rate),'全時間平均1件毎時以上':hour,'三項目すべて達成':bool(p['全場最低1取得'] and rate and hour),
      '順':s['forward'],'逆':s['adverse'],'未到達':s['neither'],'全H不足':s['censored'],'到達済み率':s['resolved_rate'],
      '完了分母率':s['complete_rate'],'全件分母率':float(Fraction(s['forward'],s['entries'])),'全時間平均件数毎時':freq['all']['A0']['全時間平均件数毎時'],'参加':p}
    equal(aggregate['主評価'],goal)
    oldpairs,old=load('oldpairs'),load('old126');prior={(x['session'],c['id']):c for x in oldpairs['scenes'] for c in x['cases']}
    groups={m:{(r['session'],r['meta']['source_id']):r for r in records if r['meta']['model']==m} for m in MODELS}
    labels=0
    for key,r in groups['C0'].items():
        reference=prior[r['session'],r['meta']['legacy_id']]
        for name in ('original','reverse','chart_original','chart_reverse'):
            for field in ('entry','entry_price','outcomes'):equal(r['case'][name][field],reference[name][field],'旧79')
            labels+=10
        for m in ('S0','A0'):
            other=groups[m][key]
            for k in ('source_side','selected_side','kind','direction_policy','birth','entryQuote','direction'):equal(r['meta'][k],other['meta'][k],'C0包含')
            for name in ('original','reverse','chart_original','chart_reverse'):
                for field in ('entry','entry_price','outcomes'):equal(r['case'][name][field],other['case'][name][field],'C0包含4stream')
    assert len(groups['C0'])==len(groups['S0'])==79 and len(groups['A0'])==81 and labels==3160
    added=[r for key,r in groups['A0'].items() if key not in groups['C0']];assert len(added)==2 and all(r['meta']['kind']=='E1' for r in added)
    for model in MODELS:
        stamps=[(r['session'],tuple(r['meta']['entryQuote'][k] for k in ('time','index','source_line'))) for r in groups[model].values()]
        assert len(set(stamps))==len(stamps)
    old_count=0
    for part in parts:
        for axis in AXES:
            for h in HORIZONS:
                for w in WIDTHS:equal(values[part]['C0'][axis][str(h)][str(w)],old['集計'][part]['T8'][axis][str(h)][str(w)]);old_count+=1
    equal(aggregate['旧対照同体'],{'成功':True,'C0取得時計と4stream全outcomes同体':79,'全H幅のラベル比較':3160,'旧集計の全条件同体':old_count,'旧対照を書き換え':False})
    kinds=Counter();diffs=[]
    for r in subset(records,'A0',sessions):
        a=ifd(choose(r,'A0','BBO'),3600,125,'BBO');b=ifd(choose(r,'O0','BBO'),3600,125,'BBO')
        k='both' if a['known'] and b['known'] else 'left' if a['known'] else 'right' if b['known'] else 'none';kinds[k]+=1
        if k=='both':diffs.append(a['net5']-b['net5'])
    pair={'政策':'A0','同群の対照':'O0','取得集合':'A0','同case数':81,'両側既知':len(diffs),'政策だけ既知':kinds['left'],'対照だけ既知':kinds['right'],'両側未知':kinds['none'],
        'C5既知ペア差引円':sum(diffs) if diffs else None,'C5既知ペア平均差円':float(Fraction(sum(diffs))/len(diffs)) if diffs else None}
    equal(aggregate['主A0と同群O0の両側既知ペア差'],pair);assert aggregate['A0とS0とC0のcaseペア差'] is None
    table_proof=tables_check(load('tables')['tables'],records,sessions,values,participation,freq)
    assert all(sha(ROOT/p)==h for p,h in paths.values())
    proof={'success':True,'trial':137,'condition_count':condition_count,'aggregate_leaf_values_checked':leaves,'entries':239,'sessions':73,
      'phase_checks':phase,'participation':participation,'frequency':freq,'table_checks':table_proof,'old_conditions_identical':old_count,'old_cases':79,
      'old_H_width_stream_labels':labels,'main':s,'main_policies':{p:values['all'][p]['BBO']['3600']['125'] for p in POLICIES},
      'front48':values['train']['A0']['BBO']['3600']['125'],'back25':values['validation']['A0']['BBO']['3600']['125'],
      'added_E1':[{'session':r['session'],'id':r['case']['id'],'IFD':ifd(choose(r,'A0','BBO'),3600,125,'BBO'),'complete':observation(choose(r,'A0','BBO'),3600)['status'],'touch':touch(observation(choose(r,'A0','BBO'),3600),125)['direction']} for r in added],
      'source_hashes_before_after_equal':True,'sources':{p:h for p,h in paths.values()},'code_sha256':sha(Path(__file__)),
      'Root_124_137_arithmetic_imported':False,'raw_CSV_additional2_sessions_read':False,'bootstrap_reimplemented':False,'actual_csv_reread_or_render':False,
      'nonfinancial_bridge_author':True,'Root_financial_calculator_author':False,'source_conditions_or_parameters_edited':False,'independent_unknown_period':False}
    out=HERE/'独立確認.json';assert not out.exists();out.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'success':True,'proof_sha256':sha(out),'main':s,'table_cells':table_proof['all_data_cells_equal'],'phase':phase},ensure_ascii=False))


if __name__=='__main__':main()
