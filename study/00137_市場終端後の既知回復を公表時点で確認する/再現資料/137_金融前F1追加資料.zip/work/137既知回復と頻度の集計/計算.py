"""政策ごとに取得集合を分離し、固定124算術を使う137の純集計関数。"""
from pathlib import Path
from collections import Counter
import importlib.util
import math

ROOT = Path(__file__).resolve().parents[2]
MODULE = ROOT / 'work/124入口の原因分析/集計する.py'
MODULE_SHA = '8479ca348231ffd77a637360797750833c9e6617c7fc4a6502e015c7a1d9f04a'
POLICIES = ('A0', 'C0', 'S0', 'O0', 'R0')
DISPLAY = POLICIES
MODELS = ('A0', 'C0', 'S0')
MODEL = {'A0': 'A0', 'C0': 'C0', 'S0': 'S0', 'O0': 'A0', 'R0': 'A0'}


def load_arithmetic() -> object:
    """
    機能: 原文不変の124算術をmainを実行せず私有moduleへ読み込む。
    引数: なし。返り値: objectは固定stats/ifd/bootstrap等。
    """
    import hashlib
    assert hashlib.sha256(MODULE.read_bytes()).hexdigest() == MODULE_SHA
    spec = importlib.util.spec_from_file_location('137専用の固定124算術', MODULE)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    module.selected = selected
    return module


# ----------------------------------------
def frequency(records: list[dict], sessions: list[str], scenes: list[dict]) -> dict:
    """
    機能: 全場のザラバ時計時間で加重頻度を計算し、名目新規可時間と場別分布を分ける。
    引数: records/sessions/scenes(list)。返り値: dict。価格や勝敗を使わない。
    """
    from statistics import median
    metadata = {s['session']: s for s in scenes}
    assert list(metadata) == sessions and len(sessions) == len(metadata) == len(scenes) == 73
    counts = Counter((r['model'], r['session']) for r in records)
    per_scene = {}
    for sid in sessions:
        s = metadata[sid]
        hours = (s['end'] - 300 - s['start']) / 3600
        entry_hours = (min(s['force_close'], s['end'] - 3900) - s['start']) / 3600
        assert hours > 0 and entry_hours > 0
        per_scene[sid] = {'全時間h': hours, '名目新規可時間h': entry_hours,
            'models': {m: {'取得数': counts[m, sid], '全時間頻度': counts[m, sid] / hours,
                           '名目新規可時間頻度': counts[m, sid] / entry_hours} for m in MODELS}}
    result = {'定義': '全時間=sum(end-300-start)/3600。全場を残す。名目新規可時間=sum(min(force_close,end-3900)-start)/3600は副評価',
              '場別': per_scene, '各場回数cap': False, '毎時強制': False}
    for part, ids in (('all', sessions), ('train', sessions[:48]), ('validation', sessions[48:])):
        result[part] = {}
        full_hours = sum(per_scene[s]['全時間h'] for s in ids)
        entry_hours = sum(per_scene[s]['名目新規可時間h'] for s in ids)
        for model in MODELS:
            total = sum(counts[model, sid] for sid in ids)
            rates = [per_scene[sid]['models'][model]['全時間頻度'] for sid in ids]
            result[part][model] = {'対象場数': len(ids), '取得数': total, '全時間h': full_hours,
                '名目新規可時間h': entry_hours, '全時間平均件数毎時': total / full_hours,
                '名目新規可時間平均件数毎時': total / entry_hours,
                '全時間平均1件毎時以上': total / full_hours >= 1,
                '場別頻度分布': {'最小': min(rates), '中央値': median(rates), '最大': max(rates),
                              '単純平均_主平均ではない': sum(rates) / len(rates),
                              '0取得場数': sum(v == 0 for v in rates), '1件毎時以上場数': sum(v >= 1 for v in rates)}}
    return result


# ----------------------------------------
def tables(records: list[dict], sessions: list[str], values: dict, participation: dict, module: object, frequencies: dict) -> list[dict]:
    """
    機能: 300比較・可変全入口・全73場の三表を作り、E1のB0/T8をnullにする。
    引数: records/sessions(list)、values/participation/frequencies(dict)、module(object)。返り値: list[dict]。
    """
    headers = ['試行', '区分', '政策', '取得集合', '価格軸', '評価分', '同幅pt', '対象場数', '取得場数', '取得数',
               'Source向きからの反転数', '全場最低1取得', '全H完了', '観測不足', '順行先着', '逆行先着', '両方未到達',
               '到達済み順行率', '完了分母順行率', '全取得分母順行率', '到達済み70%達成', '参加と70%両達成',
               '全時間平均件数毎時', '名目新規可時間平均件数毎時', '全時間平均1件毎時以上', '参加と70%と頻度すべて達成',
               'IFD代用既知', 'IFD代用未知', 'C0代用差引円', 'C5代用利益円', 'C5代用損失絶対円', 'C5代用差引円', 'C5代用平均円', 'C5代用PF']
    comparison = []
    for part in ('all', 'train', 'validation'):
        for policy in DISPLAY:
            p = participation[part][MODEL[policy]]; f = frequencies[part][MODEL[policy]]
            for axis in module.AXES:
                for h in module.HORIZONS:
                    for w in module.WIDTHS:
                        s = values[part][policy][axis][str(h)][str(w)]
                        quality = bool(p['全場最低1取得'] and s['target70'] is True)
                        comparison.append([137, part, policy, MODEL[policy], axis, h / 60, w, p['対象場数'], s['sessions'], s['entries'],
                            s['flips'], p['全場最低1取得'], s['complete'], s['censored'], s['forward'], s['adverse'], s['neither'],
                            s['resolved_rate'], s['complete_rate'], s['forward'] / s['entries'] if s['entries'] else None, s['target70'], quality,
                            f['全時間平均件数毎時'], f['名目新規可時間平均件数毎時'], f['全時間平均1件毎時以上'], quality and f['全時間平均1件毎時以上'],
                            s['ifd_known'], s['ifd_unknown'], s['ifd_net0_sum'], s['ifd_net5_profit'], s['ifd_net5_loss'], s['ifd_net5_sum'], s['ifd_net5_mean'], s['ifd_net5_pf']])
    detail_headers = ['試行', '参考区分', 'セッション', '取得集合', '出生ID', 'Source出生ID', '旧対照ID', '入口種別', '方向規則',
        '元方向', 'B0方向', 'T8方向', '選択方向', 'E0保護', '出生JST', '取得JST', '元取得価格', '逆取得価格',
        '5分実体比_Source', '実体既知', '30分EMA21増分_B0', '長期既知', '5分HistATR_B0', '勢い既知', 'ATR5', 'ATR既知',
        'E1接触JST', 'E1K固定JST', 'E1新5分EndJST', 'E1新5分配送JST', 'E1回復1分StartJST', 'E1回復1分EndJST', 'E1維持行数', 'E1維持秒数']
    for policy in DISPLAY:
        detail_headers += [policy + '方向', policy + '125全H', policy + '125先着', policy + 'IFD既知', policy + '清算', policy + '125C5代用円']
    detail = []; front = set(sessions[:48])
    for r in records:
        c, m = r['case'], r['meta']; d = m['direction']; fields = d['fields'] if d else {}
        nums = [number(fields, key) for key in ('body5_signed_ratio_to_source', 'ema21_delta30_to_B0', 'hist5_atr_to_B0', 'atr5')]
        if m['kind'] == 'E1':
            nums[3] = m['e1_event']['atr5']
        row = [137, 'train' if r['session'] in front else 'validation', r['session'], r['model'], c['id'], m['source_id'], m['legacy_id'],
            m['kind'], m['direction_policy'], c['original_side'], d['b0_side'] if d else None, d['t8_side'] if d else None,
            m['selected_side'], d['e0_protected'] if d else None, module.jst(m['birth']['time']), module.jst(m['entryQuote']['time']),
            c['original']['entry_price'], c['reverse']['entry_price']]
        for value in nums:
            row += [value, value is not None]
        if m['kind'] == 'E1':
            f = m['e1_event']['fields']
            row += [module.jst(f['contact']['time']), module.jst(f['K_frozen_at']['time']), module.jst(f['improvement_ref']['end']),
                module.jst(f['improvement_ref']['delivered']['time']), module.jst(f['recovery_minute']['start']),
                module.jst(f['recovery_minute']['end']), f['hold_rows'], f['hold_elapsed_seconds']]
        else:
            row += [None] * 8
        for policy in DISPLAY:
            if MODEL[policy] != r['model']:
                row += [None] * 6; continue
            candidate = selected(r, policy, 'BBO'); o = module.observation(candidate, 3600); e = module.ifd(candidate, o, 125, 'BBO')
            row += [candidate['birth']['side'], o['status'], module.touch(o, 125)['direction'], e['known'], e['reason'], e['net5']]
        detail.append(row)
    scene_headers = ['試行', 'セッション', '参考区分', 'ザラバ時間h', '名目新規可時間h']
    for suffix in ('取得数', '最低1取得', '全時間頻度', '名目新規可時間頻度'):
        scene_headers += [m + suffix for m in MODELS]
    for policy in DISPLAY:
        scene_headers += [policy + suffix for suffix in ('反転数', '125順', '125逆', '125未到達', '全H不足', 'IFD既知', 'IFD未知',
            'C5利益円', 'C5損失絶対円', 'C5既知差引円', 'C5既知累計円_口座収支ではない', '累計IFD未知')]
    scene_rows = []; cumulative = {p: 0 for p in POLICIES}; unknown = {p: 0 for p in POLICIES}
    for i, sid in enumerate(sessions):
        f = frequencies['場別'][sid]
        row = [137, sid, 'train' if i < 48 else 'validation', f['全時間h'], f['名目新規可時間h']]
        row += [f['models'][m]['取得数'] for m in MODELS] + [bool(f['models'][m]['取得数']) for m in MODELS]
        row += [f['models'][m]['全時間頻度'] for m in MODELS] + [f['models'][m]['名目新規可時間頻度'] for m in MODELS]
        for policy in DISPLAY:
            s = module.stats(subset(records, policy, [sid]), policy, 'BBO', 3600, 125)
            if s['ifd_net5_sum'] is not None:
                cumulative[policy] += s['ifd_net5_sum']
            unknown[policy] += s['ifd_unknown']
            row += [s['flips'], s['forward'], s['adverse'], s['neither'], s['censored'], s['ifd_known'], s['ifd_unknown'],
                s['ifd_net5_profit'], s['ifd_net5_loss'], s['ifd_net5_sum'], cumulative[policy], unknown[policy]]
        scene_rows.append(row)
    result = [{'name': '正逆比較', 'headers': headers, 'rows': comparison}, {'name': '入口別診断', 'headers': detail_headers, 'rows': detail},
              {'name': '全セッション', 'headers': scene_headers, 'rows': scene_rows}]
    assert [len(t['rows']) for t in result] == [300, len(records), 73]
    assert all(len(t['headers']) == len(set(t['headers'])) and all(len(row) == len(t['headers']) for row in t['rows']) for t in result)
    return result


# ----------------------------------------
def selected(record: dict, policy: str, axis: str) -> dict:
    """
    機能: 政策の取得集合を検査して、保存された実正逆又はLast側を選ぶ。
    引数: record(dict)、policy/axis(str)。返り値: dictは保存candidate。
    """
    assert policy in POLICIES and axis in ('BBO', 'Last') and record['model'] == MODEL[policy]
    original = record['case']['original_side']
    side = original if policy == 'O0' else record['meta']['selected_side']
    if policy == 'R0': side = -side
    assert side in (-1, 1)
    key = ('chart_' if axis == 'Last' else '') + ('original' if side == original else 'reverse')
    return record['case'][key]


# ----------------------------------------
def subset(records: list[dict], policy: str, sessions: list[str]) -> list[dict]:
    """
    機能: 政策と対象場に該当する取得だけをstatsへ渡す。
    引数: records(list[dict])、policy(str)、sessions(list[str])。返り値: list[dict]。
    """
    allowed = set(sessions)
    return [r for r in records if r['model'] == MODEL[policy] and r['session'] in allowed]


# ----------------------------------------
def coverage(records: list[dict], model: str, sessions: list[str]) -> dict:
    """
    機能: 未取得場も対象に残して参加を判定する。
    引数: records(list[dict])、model(str)、sessions(list[str])。返り値: dict。
    """
    assert model in MODELS and len(sessions) == len(set(sessions))
    counts = Counter(r['session'] for r in records if r['model'] == model and r['session'] in sessions)
    missing = [s for s in sessions if not counts[s]]
    return {'対象場数': len(sessions), '取得数': sum(counts.values()), '取得場数': len(counts),
            '未取得場数': len(missing), '未取得場': missing, '全場最低1取得': not missing and bool(sessions)}


# ----------------------------------------
def aggregate(records: list[dict], sessions: list[str], module: object) -> tuple[dict, dict]:
    """
    機能: 全体・前48・後25で、政策別の集合だけを300条件へ集計する。
    引数: records(list[dict])、sessions(list[str])、module(object)。返り値: tuple[dict,dict]。
    """
    assert len(sessions) == 73
    output, participation = {}, {}
    for part, ids in (('all', sessions), ('train', sessions[:48]), ('validation', sessions[48:])):
        participation[part] = {m: coverage(records, m, ids) for m in MODELS}
        output[part] = {}
        for policy in POLICIES:
            rows = subset(records, policy, ids)
            output[part][policy] = {axis: {str(h): {str(w): module.stats(rows, policy, axis, h, w)
                                      for w in module.WIDTHS} for h in module.HORIZONS} for axis in module.AXES}
    return output, participation


# ----------------------------------------
def goal(aggregate: dict, participation: dict, frequency: dict) -> dict:
    """
    機能: 主A0の70%・全場参加・平均1件毎時を分けて判定する。
    引数: aggregate/participation/frequency(dict)。返り値: dict。
    """
    s = aggregate['all']['A0']['BBO']['3600']['125']; p = participation['all']['A0']
    rate = s['target70'] is True; hourly = frequency['all']['A0']['全時間平均1件毎時以上']
    return {'主': 'A0/全73場/実BBO/H60/±125pt', '全73場最低1取得': p['全場最低1取得'],
            '到達済み先着70%以上': rate, '入口品質の両条件達成': bool(p['全場最低1取得'] and rate),
            '全時間平均1件毎時以上': hourly, '三項目すべて達成': bool(p['全場最低1取得'] and rate and hourly),
            '順': s['forward'], '逆': s['adverse'], '未到達': s['neither'], '全H不足': s['censored'],
            '到達済み率': s['resolved_rate'], '完了分母率': s['complete_rate'],
            '全件分母率': s['forward'] / s['entries'] if s['entries'] else None,
            '全時間平均件数毎時': frequency['all']['A0']['全時間平均件数毎時'], '参加': p}


# ----------------------------------------
def paired(records: list[dict], policy: str, reference: str, module: object) -> dict:
    """
    機能: 同じA0取得だけで、選択方向とSource方向の両側既知差を求める。
    引数: records(list[dict])、policy/reference(str)、module(object)。返り値: dict。
    """
    assert policy == 'A0' and reference == 'O0', '異なる取得集合のcaseペアを作らない'
    rows = [r for r in records if r['model'] == 'A0']
    values = []; left = right = neither = 0
    for r in rows:
        a = selected(r, policy, 'BBO'); b = selected(r, reference, 'BBO')
        x = module.ifd(a, module.observation(a, 3600), 125, 'BBO')
        y = module.ifd(b, module.observation(b, 3600), 125, 'BBO')
        if x['known'] and y['known']: values.append(x['net5'] - y['net5'])
        elif x['known']: left += 1
        elif y['known']: right += 1
        else: neither += 1
    return {'政策': policy, '同群の対照': reference, '取得集合': 'A0', '同case数': len(rows),
            '両側既知': len(values), '政策だけ既知': left, '対照だけ既知': right, '両側未知': neither,
            'C5既知ペア差引円': sum(values) if values else None,
            'C5既知ペア平均差円': sum(values) / len(values) if values else None}


# ----------------------------------------
def bootstrap(records: list[dict], sessions: list[str]) -> dict:
    """
    機能: 固定124の5000回/seed124算術を主A0と同群O0へ限定して適用する。
    引数: records(list[dict])、sessions(list[str])。返り値: dictは探索内の参考区間。
    """
    assert len(sessions) == 73
    module = load_arithmetic(); module.POLICIES = ('A0',)
    result = module.bootstrap([r for r in records if r['model'] == 'A0'], sessions)
    item = result['政策']['A0']
    item['O0との同群両側既知ペア平均差95区間'] = item.pop('O0との両側既知ペア平均差95区間')
    result['対照'] = 'A0の同じ取得原行の元方向O0'
    result['異なる取得集合のA0とS0とC0をcaseペア化'] = False
    return result


# ----------------------------------------
def number(fields: dict, key: str) -> float | None:
    """
    機能: Go形式の未知格納0を既知0と区別する。
    引数: fields(dict)、key(str)。返り値: float|None。
    """
    item = fields.get(key, {'known': False, 'value': 0})
    assert type(item['known']) is bool
    if not item['known']: return None
    value = item['value']; assert type(value) in (int, float) and math.isfinite(value)
    return value


# ----------------------------------------
