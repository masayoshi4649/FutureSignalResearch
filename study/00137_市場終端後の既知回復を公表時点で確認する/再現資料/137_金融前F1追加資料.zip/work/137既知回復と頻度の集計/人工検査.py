"""137押戻し回復と頻度集計を、自然結果を開かず可変cohortと未知の人工境界で確認する。"""
from pathlib import Path
import copy
import importlib.util
import subprocess
import sys
import unittest

OWN = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('137人工用CLI', OWN / '集計する.py')
RUN = importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(RUN)
C = RUN.CALC


def quote(at: float, index: int, bid: float = 1000, ask: float = 1010, last: float = 1005) -> dict:
    """
    機能: 人工の正常Quoteを作る。
    引数: at/bid/ask/last(float)、index(int)。返り値: dict。
    """
    return {'clock': '人工', 'time': at, 'index': index, 'source_line': index + 1,
            'bid': bid, 'ask': ask, 'last': last, 'quote_ok': True}


# ----------------------------------------
def candidate(side: int, entry: dict, chart: bool, unknown: bool) -> dict:
    """
    機能: 両H・全5幅の独立した正逆価格観測を人工生成する。
    引数: side(int)、entry(dict)、chart/unknown(bool)。返り値: dict。
    """
    price = entry['last'] if chart else entry['ask'] if side == 1 else entry['bid']
    point = quote(entry['time'] + 5, entry['index'] + 1, 1140, 1150, 1145)
    mark = point['last'] if chart else point['bid'] if side == 1 else point['ask']
    gain = side * (mark - price); outcomes = []
    for h in (1800, 3600):
        lost = unknown and h == 3600
        endpoint = None if lost else quote(entry['time'] + h, entry['index'] + 2, 1140, 1150, 1145)
        touches = []
        for width in (25, 50, 100, 125, 200):
            direction = 0 if lost else 1 if gain >= width else -1 if gain <= -width else 0
            touches.append({'width': width, 'direction': direction, 'quote': copy.deepcopy(point) if direction else None})
        outcomes.append({'seconds': h, 'deadline': entry['time'] + h, 'status': 'gap_censored' if lost else 'complete',
                         'touches': touches, 'endpoint': endpoint, 'points': None if lost else gain,
                         'net0': None if chart or lost else gain * 100 - 77,
                         'net5': None if chart or lost else gain * 100 - 1077})
    return {'status': 'filled', 'birth': {'side': side}, 'entry': copy.deepcopy(entry), 'entry_price': price,
            'outcomes': outcomes}


# ----------------------------------------
def e1_metadata(sid: str, start: float, contact: float, source_id: str, side: int) -> dict:
    """
    機能: phase順序・凍結geometryが既知の人工E1を作る。
    引数: sid/source_id(str)、start/contact(float)、side(int)。返り値: dict。
    """
    def q(at: float, last: float) -> dict:
        """機能: 鏡像Quoteを作る。引数: at/last(float)。返り値: dict。"""
        price = last if side == 1 else 2000 - last
        return quote(at, int(at - start), price - 1, price + 1, price)
    def ref(identity: str, width: int, end: float, at: float) -> dict:
        """機能: 人工公表参照を作る。引数: identity(str)、width(int)、end/at(float)。返り値: dict。"""
        return {'id': identity, 'width_seconds': width, 'end': end,
                'delivered': {'time': at, 'index': int(at - start), 'source_line': int(at - start) + 1}}
    def bar(at: float, opening: float, high: float, low: float, close: float, volume: float) -> dict:
        """機能: 人工確定足を作る。引数: at/opening/high/low/close/volume(float)。返り値: dict。"""
        ohlc = {'open': opening, 'high': high, 'low': low, 'close': close}
        if side == -1:
            ohlc = {'open': 2000 - opening, 'high': 2000 - low, 'low': 2000 - high, 'close': 2000 - close}
        return {'start': at, 'end': at + 60, 'ohlc': ohlc, 'price_known': True, 'volume_known': True, 'volume': volume,
                'first': q(at + 1, opening), 'last': q(at + 59, close), 'rows': 2}
    b = bar(contact - 40, 1000, 1004, 999, 1003, 150)
    c = bar(contact + 200, 1002, 1010, 1001, 1009, 200)
    c['first'] = q(contact + 200, 1002)
    phase = ref('人工15/' + source_id, 900, contact - 100, contact - 35)
    old5 = ref('人工5/' + source_id, 300, contact - 100, contact - 35)
    improve = ref('人工m/' + source_id, 300, contact + 200, contact + 265)
    birth_quote = q(contact + 266, 1009); entry = q(contact + 268, 1010)
    birth = {'id': source_id, 'side': side, **{k: birth_quote[k] for k in ('time', 'index', 'source_line')}, 'quote': birth_quote}
    k = 1009 if side == 1 else 991; invalidation = 994 if side == 1 else 1006
    event = {'session': sid, 'id': source_id, 'mode': 'E1', 'side': side,
             'at': {k: birth[k] for k in ('time', 'index', 'source_line')}, 'entry_cap': k + side * 10,
             'invalidation': invalidation, 'atr5': 40, 'hold_boundary': k, 'hold_minimum': 0, 'minimum_risk': 10,
             'refs': [phase, old5, improve], 'fields': {'recovery_bar_clock': 'market_end', 'direction_policy': 'pattern', 't8_applied': False,
                'contact': q(contact, 1002), 'phase15': phase, 'phase15_hist': -side, 'contact5': old5,
                'reject_minute': b, 'K_frozen_at': q(contact + 21, 1003), 'improvement_ref': improve,
                'recovery_minute': c, 'hold_started_at': q(contact + 265, 1009), 'hold_rows': 2,
                'hold_elapsed_seconds': 1, 'episode_expires': contact + 900, 'recovery_expires': contact + 385,
                'entry_ttl_seconds': 30, 'risk_min': 10, 'risk_max': 60, 'contact_atr': 40, 'hold_strict': False}}
    return {'session': sid, 'source_id': source_id, 'legacy_id': None, 'source_side': side, 'selected_side': side,
            'kind': 'E1', 'direction_policy': 'pattern', 'birth': birth, 'entryQuote': entry, 'direction': None, 'e1_event': event}


# ----------------------------------------
def fixture() -> tuple[dict, dict, dict]:
    """
    機能: C0二件・S0五件・A0六件、E0/L0/E1を混ぜて全73場を作る。
    引数: なし。返り値: tuple[dict,dict,dict]は人工結果/metadata/固定入力。
    """
    sessions = ['人工%03d' % i for i in range(73)]
    scenes = []; results = []; entries = []
    for i, sid in enumerate(sessions):
        start = 10000 + i * 20000; raw = {'path': '未作成の人工原板', 'sha256': 'a' * 64}
        quality = {'lines': 10000, 'source_parser_accepted': 10000, 'source_delivered': 10000}
        scene = {'session': sid, 'contract': '人工限月', 'start': start, 'end': start + 10000, 'force_close': start + 9400,
                 'raw': raw, 'expected_accepted': 10000, 'expected_quality': quality, 'entries': []}
        result = {'session': sid, 'success': True, 'raw': raw, 'actual_sha256': raw['sha256'], 'stat_before': {'bytes': 100},
                  'stat_after': {'bytes': 100}, 'quality': quality, 'expected_quality': quality, 'execution_end': start + 9700,
                  'source_force_close': start + 9400, 'effective_entry_limit': start + 6100, 'source_entries': 0, 'cases': []}
        definitions = []
        if i in (0, 48):
            kind = 'E0' if i == 0 else 'L0'; source_id = sid + ('/E0/1' if i == 0 else '/補完/L0/1')
            birth_quote = quote(start + 98, 98); entry = quote(start + 100, 100)
            fields = {k: {'known': True, 'value': v} for k, v in
                      (('body5_signed_ratio_to_source', 0), ('ema21_delta30_to_B0', 1), ('hist5_atr_to_B0', .2), ('atr5', 40))}
            selected = 1 if kind == 'E0' else -1
            refs = [{'id': '人工足', 'width_seconds': w, 'end': start + 30,
                     'delivered': {'time': start + 90, 'index': 90, 'source_line': 91}} for w in (300, 900, 1800)]
            d = {'source_side': 1, 'b0_side': 1, 't8_side': -1, 'selected_side': selected, 'e0_protected': kind == 'E0', 'fields': fields, 'refs': refs}
            base = {'session': sid, 'source_id': source_id, 'legacy_id': source_id.replace('/補完/L0/', '/補完/P3/'),
                    'source_side': 1, 'selected_side': selected, 'kind': kind, 'direction_policy': 'source' if kind == 'E0' else 'fixedT8',
                    'birth': {'id': source_id, 'side': 1, **{k: birth_quote[k] for k in ('time', 'index', 'source_line')}, 'quote': birth_quote},
                    'entryQuote': entry, 'direction': d, 'e1_event': None}
            definitions += [(model, copy.deepcopy(base), False) for model in ('C0', 'A0', 'S0')]
        if i in (0, 1, 72):
            contact = start + 600
            base = e1_metadata(sid, start, contact, sid + '/E1/1', 1)
            definitions += [(model, copy.deepcopy(base), i == 72) for model in ('A0', 'S0')]
        if i == 1:
            base = e1_metadata(sid, start, start + 1800, sid + '/E1/2', -1)
            definitions += [('A0', base, False)]
        for model, meta, unknown in definitions:
            identity = model + '/' + meta['source_id']; meta.update({'model': model, 'id': identity})
            entry = meta['entryQuote']; side = meta['source_side']; case = {'id': identity, 'original_side': side}
            for name, actual, chart in (('original', side, False), ('reverse', -side, False), ('chart_original', side, True), ('chart_reverse', -side, True)):
                case[name] = candidate(actual, entry, chart, unknown)
            scene['entries'].append({'id': identity, 'side': side, 'entry': entry}); result['cases'].append(case); entries.append(meta)
        result['source_entries'] = len(result['cases']); scenes.append(scene); results.append(result)
    counts = {model: sum(e['model'] == model for e in entries) for model in C.MODELS}
    coverage = {sid: {model: any(e['session'] == sid and e['model'] == model for e in entries) for model in C.MODELS} for sid in sessions}
    fixed = {'scenes': scenes, 'expected_entry_count': len(entries)}
    meta = {'success': True, 'trial': 137, 'new_outcomes_read': False, 'fixed_input_sha256': '人工入力',
            'sessions': sessions, 'entries': entries, 'counts': counts, 'coverage': coverage}
    result = {'success': True, 'trial': 133, 'input_sha256': '人工入力', 'scene_count': 73, 'source_entry_count': len(entries),
              'widths': [25, 50, 100, 125, 200], 'horizons': [1800, 3600], 'scenes': results}
    return result, meta, fixed


# ----------------------------------------
class Artificial137(unittest.TestCase):
    """自然結果を開かず混合集合と頻度、未知、phaseの誤結合を拒否する。"""

    def setUp(self) -> None:
        """機能: 人工入力と私有算術を用意する。引数: self(Artificial137)。返り値: None。"""
        self.result, self.meta, self.fixed = fixture()
        self.rows, self.sessions, self.phase = RUN.prepare_records(self.result, self.meta, self.fixed)
        self.module = C.load_arithmetic(); self.values, self.coverage = C.aggregate(self.rows, self.sessions, self.module)
        self.frequency = C.frequency(self.rows, self.sessions, self.fixed['scenes'])

    def test_混合モデルと完了分母を混ぜない(self) -> None:
        """機能: C0/S0/A0とE1方向を分離する。引数: self(Artificial137)。返り値: None。"""
        self.assertEqual(self.meta['counts'], {'A0': 6, 'C0': 2, 'S0': 5})
        for p, count in (('A0', 6), ('C0', 2), ('S0', 5), ('O0', 6), ('R0', 6)):
            self.assertEqual(self.values['all'][p]['BBO']['3600']['125']['entries'], count)
        goal = C.goal(self.values, self.coverage, self.frequency)
        s = self.values['all']['A0']['BBO']['3600']['125']
        self.assertEqual(goal['全件分母率'], s['forward'] / 6)
        self.assertEqual(goal['完了分母率'], s['complete_rate'])
        self.assertFalse(goal['三項目すべて達成'])

    def test_頻度は全時間の加重平均(self) -> None:
        """機能: 空場を残した時間分母と場別率の単純平均を区別する。引数: self(Artificial137)。返り値: None。"""
        scenes = copy.deepcopy(self.fixed['scenes']); scenes[0]['end'] += 3600
        f = C.frequency(self.rows, self.sessions, scenes)
        hours = sum(s['end'] - 300 - s['start'] for s in scenes) / 3600
        self.assertAlmostEqual(f['all']['A0']['全時間平均件数毎時'], 6 / hours)
        self.assertNotEqual(f['all']['A0']['全時間平均件数毎時'], f['all']['A0']['場別頻度分布']['単純平均_主平均ではない'])
        self.assertEqual(f['all']['A0']['場別頻度分布']['0取得場数'], 69)
        self.assertFalse(f['各場回数cap']); self.assertFalse(f['毎時強制'])

    def test_0取得と未知とLast金額(self) -> None:
        """機能: 0取得/0knownを0円にせず、件数だけで達成しない。引数: self(Artificial137)。返り値: None。"""
        empty, p = C.aggregate([], self.sessions, self.module); f = C.frequency([], self.sessions, self.fixed['scenes'])
        self.assertIsNone(empty['all']['A0']['BBO']['3600']['125']['ifd_net5_sum'])
        self.assertEqual(f['all']['A0']['全時間平均件数毎時'], 0)
        f['all']['A0']['全時間平均1件毎時以上'] = True
        self.assertFalse(C.goal(empty, p, f)['三項目すべて達成'])
        unknown = [r for r in self.rows if r['model'] == 'A0' and r['session'] == '人工072']
        s = self.module.stats(unknown, 'A0', 'BBO', 3600, 125)
        self.assertEqual((s['ifd_known'], s['ifd_unknown']), (0, 1)); self.assertIsNone(s['ifd_net5_sum'])
        for part in self.values.values():
            for p in C.POLICIES:
                for hs in part[p]['Last'].values():
                    self.assertTrue(all(s['ifd_net5_sum'] is None for s in hs.values()))
        sample = candidate(1, quote(100, 2), False, False)
        money = self.module.ifd(sample, self.module.observation(sample, 3600), 125, 'BBO')
        self.assertEqual((money['net0'], money['net5']), (12923, 11923))

    def test_E1のB0T8はnullで3表を維持(self) -> None:
        """機能: E1へT8を捏造せず全入口/73場を保存する。引数: self(Artificial137)。返り値: None。"""
        tables = C.tables(self.rows, self.sessions, self.values, self.coverage, self.module, self.frequency)
        self.assertEqual([len(t['rows']) for t in tables], [300, 13, 73])
        self.assertTrue(all(row[0] == 137 for table in tables for row in table['rows']))
        detail = tables[1]
        row = next(row for row in detail['rows'] if row[detail['headers'].index('入口種別')] == 'E1')
        self.assertIsNone(row[detail['headers'].index('B0方向')]); self.assertIsNone(row[detail['headers'].index('T8方向')])
        self.assertIsNone(row[detail['headers'].index('5分実体比_Source')])

    def test_A0だけペアとbootstrap(self) -> None:
        """機能: A0/O0だけを同取得差としC0/S0をペア化しない。引数: self(Artificial137)。返り値: None。"""
        pair = C.paired(self.rows, 'A0', 'O0', self.module)
        self.assertEqual(pair['同case数'], 6)
        for reference in ('C0', 'S0'):
            with self.assertRaises(AssertionError): C.paired(self.rows, 'A0', reference, self.module)
        a = C.bootstrap(self.rows, self.sessions); b = C.bootstrap([r for r in self.rows if r['model'] == 'A0'], self.sessions)
        self.assertEqual(a, b); self.assertEqual((a['回数'], a['seed']), (5000, 124))

    def test_凍結旧79と全60条件の同体(self) -> None:
        """機能: 旧対照の四streamと全条件の改変を拒否する。引数: self(Artificial137)。返り値: None。"""
        source = next(r for r in self.rows if r['model'] == 'C0'); rows = []; old = {s: [] for s in self.sessions}
        for i in range(79):
            r = copy.deepcopy(source); sid = self.sessions[i % 73]; legacy = '旧人工%d' % i
            r['session'] = sid; r['meta']['legacy_id'] = legacy; r['case']['id'] = 'C0/' + legacy
            previous = copy.deepcopy(r['case']); previous['id'] = legacy; old[sid].append(previous); rows.append(r)
        values, _ = C.aggregate(rows, self.sessions, self.module)
        pairs = {'scenes': [{'session': s, 'cases': v} for s, v in old.items()]}
        old126 = {'集計': {p: {'T8': values[p]['C0']} for p in values}}
        proof = RUN.assert_baselines(rows, values, pairs, old126)
        self.assertEqual(proof['旧集計の全条件同体'], 60)
        bad = copy.deepcopy(old126); bad['集計']['validation']['T8']['BBO']['3600']['125']['entries'] += 1
        with self.assertRaises(AssertionError): RUN.assert_baselines(rows, values, pairs, bad)

    def test_原行重複とC0欠落とS0上限を拒否(self) -> None:
        """機能: 重複計上や旧入口の除外で件数を作らない。引数: self(Artificial137)。返り値: None。"""
        bad = [r for r in self.rows if not (r['model'] == 'A0' and r['meta']['kind'] == 'L0')]
        with self.assertRaises(AssertionError): RUN.cohort_invariants(bad)
        bad = copy.deepcopy(self.rows); old = next(r for r in bad if r['model'] == 'C0'); new = next(r for r in bad if r['model'] == 'A0' and r['meta']['kind'] == 'E1')
        new['session'] = old['session']; new['meta']['entryQuote'] = old['meta']['entryQuote']
        with self.assertRaises(AssertionError): RUN.cohort_invariants(bad)
        duplicate = copy.deepcopy(next(r for r in self.rows if r['model'] == 'S0' and r['meta']['kind'] == 'E1'))
        with self.assertRaises(AssertionError): RUN.cohort_invariants(self.rows + [duplicate])

    def test_E1方向geometryと未来phaseを拒否(self) -> None:
        """機能: patternへのT8移植・cap緩和・未来窓・TTL・phase違反を拒否する。引数: self(Artificial137)。返り値: None。"""
        e = next(m for m in self.meta['entries'] if m['kind'] == 'E1')
        for mutation in ('direction', 'cap', 'future', 'ttl', 'side'):
            bad = copy.deepcopy(e)
            if mutation == 'direction': bad['direction'] = {}
            if mutation == 'cap': bad['e1_event']['entry_cap'] += 1
            if mutation == 'future': bad['e1_event']['fields']['improvement_ref']['delivered']['time'] = bad['birth']['time'] + 1
            if mutation == 'ttl': bad['entryQuote']['time'] = bad['birth']['time'] + 30
            if mutation == 'side': bad['selected_side'] *= -1
            with self.assertRaises(AssertionError): RUN.direction(bad)
        bad = copy.deepcopy(self.result)
        bad['scenes'][0]['cases'][0]['original']['outcomes'][0]['touches'][0]['quote']['time'] = bad['scenes'][0]['execution_end']
        with self.assertRaises(AssertionError): RUN.prepare_records(bad, self.meta, self.fixed)

    def test_market_end時計と当時既知を別に確認(self) -> None:
        """
        機能: 配送前に形成した既知cを許し、配送時計版/未配送/未来足/原行逆転を拒否する。
        引数: self(Artificial137)。返り値: None。買売とも同じ境界を使う。
        """
        entries = [e for e in self.meta['entries'] if e['kind'] == 'E1']
        self.assertEqual({e['source_side'] for e in entries}, {-1, 1})
        for e in entries:
            f = e['e1_event']['fields']; c = f['recovery_minute']; m = f['improvement_ref']
            self.assertEqual(c['first']['time'], m['end'])
            self.assertLess(c['start'], m['delivered']['time'])
            self.assertLess(c['end'], m['delivered']['time'])
            self.assertEqual(f['hold_started_at']['time'], m['delivered']['time'])
            RUN.direction(e)
        e = entries[0]
        for mutation in ('時計delivery', '時計なし', '市場End前', '未来End', '未来First', '未来Last', '回復前未配送'):
            bad = copy.deepcopy(e); f = bad['e1_event']['fields']; c = f['recovery_minute']
            if mutation == '時計delivery': f['recovery_bar_clock'] = 'delivery'
            if mutation == '時計なし': del f['recovery_bar_clock']
            if mutation == '市場End前': c['start'] -= 60; c['end'] -= 60
            if mutation == '未来End': c['end'] = bad['birth']['time'] + 1; c['start'] = c['end'] - 60
            if mutation == '未来First': c['first']['index'] = bad['birth']['index'] + 1
            if mutation == '未来Last': c['last']['source_line'] = bad['birth']['source_line'] + 1
            if mutation == '回復前未配送': f['improvement_ref']['delivered']['time'] = f['hold_started_at']['time'] + .5
            with self.subTest(mutation=mutation), self.assertRaises(AssertionError): RUN.direction(bad)

    def test_回復traceの量と確認時刻を照合(self) -> None:
        """
        機能: 任意traceの直前量/確認時30秒を検査し、欠損時は値を補完しない。
        引数: self(Artificial137)。返り値: None。出生時の足年齢30秒は追加しない。
        """
        e = copy.deepcopy(next(m for m in self.meta['entries'] if m['kind'] == 'E1'))
        f = e['e1_event']['fields']; c = f['recovery_minute']
        previous = copy.deepcopy(c)
        previous['start'] -= 60; previous['end'] -= 60; previous['volume'] = 100
        for key in ('first', 'last'):
            for clock in ('time', 'index', 'source_line'): previous[key][clock] -= 60
        trace = {'session': e['session'], 'contract': '人工限月',
                 'episode_id': e['source_id'].rsplit('/', 1)[0], 'side': e['source_side'],
                 'stage': '1分回復', 'reason': '人工の既知回復', 'at': copy.deepcopy(f['hold_started_at']),
                 'fields': {'recovery_minute': copy.deepcopy(c), 'previous_minute': previous, 'K': e['e1_event']['hold_boundary']}}
        # 人工source_idもnativeと同様に末尾へ出生indexを付ける。
        new_id = trace['episode_id'] + '/' + str(e['birth']['index'])
        e['source_id'] = e['birth']['id'] = e['e1_event']['id'] = new_id
        e['id'] = e['model'] + '/' + new_id
        e['e1_recovery_trace'] = trace
        RUN.direction(e)
        for mutation in ('episode違い', '量不足', '量未知', '足違い', '確認未来', '確認Last割れ', '確認年齢超過'):
            bad = copy.deepcopy(e); t = bad['e1_recovery_trace']
            if mutation == 'episode違い': t['episode_id'] += '/別'
            if mutation == '量不足': t['fields']['previous_minute']['volume'] = c['volume'] + 1
            if mutation == '量未知': t['fields']['previous_minute']['volume_known'] = False
            if mutation == '足違い': t['fields']['recovery_minute']['volume'] += 1
            if mutation == '確認未来': t['at']['time'] = bad['birth']['time'] + 1
            if mutation == '確認Last割れ': t['at']['last'] = bad['e1_event']['hold_boundary'] - bad['source_side']
            if mutation == '確認年齢超過': t['at']['time'] = c['end'] + 31
            with self.subTest(mutation=mutation), self.assertRaises(AssertionError): RUN.direction(bad)
        # 確認から維持を待った後の出生へ、確認時の年齢制約を移植しない。
        delayed = copy.deepcopy(e); d = 40
        for q in (delayed['birth'], delayed['birth']['quote'], delayed['entryQuote'],
                  delayed['e1_event']['at'], delayed['e1_event']['fields']['hold_started_at']):
            for key in ('time', 'index', 'source_line'): q[key] += d
        delayed['source_id'] = delayed['birth']['id'] = delayed['e1_event']['id'] = trace['episode_id'] + '/' + str(delayed['birth']['index'])
        delayed['id'] = delayed['model'] + '/' + delayed['source_id']
        RUN.direction(delayed)
        e['e1_recovery_trace'] = None
        RUN.direction(e)

    def test_F1なしは読取前に拒否(self) -> None:
        """機能: 自然CLIを明示SHA/F1なしで起動しない。引数: self(Artificial137)。返り値: None。"""
        result = subprocess.run([sys.executable, '-X', 'utf8', str(OWN / '集計する.py')], capture_output=True, text=True, encoding='utf-8')
        self.assertEqual(result.returncode, 2); self.assertIn('--f1', result.stderr)


if __name__ == '__main__':
    unittest.main(verbosity=2)


