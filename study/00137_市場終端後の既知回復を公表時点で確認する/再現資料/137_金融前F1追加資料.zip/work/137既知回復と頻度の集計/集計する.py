"""137のRoot固定後だけ、押戻し回復と頻度の取得集合を金融集計するCLI。"""
from pathlib import Path
from collections import Counter
import argparse
import hashlib
import importlib.util
import json
import math

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('137押戻し回復と頻度の純集計', OWN / '計算.py')
CALC = importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(CALC)
OLD_PAIRS = ROOT / 'work/124入口の正逆比較/全73場の正逆結果.json'
OLD126 = ROOT / 'work/126複合切替の探索/集計.json'
SOURCES = {CALC.MODULE: CALC.MODULE_SHA,
           OLD_PAIRS: '25517066b291a0434211190299b9f0195e67f9a7d2e89c801d5b9e6b4b51c3a1',
           OLD126: 'e30aca19e553ded53ccdd3b1785bd6168e19dd210aa9c32c1f9625c0063fdcd8'}


def sha(path: Path) -> str:
    """
    機能: ファイルの全bytes指紋を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def valid_number(value: object) -> bool:
    """
    機能: boolを除いて有限数値を確認する。
    引数: value(object)。返り値: bool。
    """
    return type(value) in (int, float) and math.isfinite(value)


# ----------------------------------------


# ----------------------------------------
def causal_ref(ref: dict, birth: dict) -> None:
    """
    機能: 現在参照と履歴参照の公表が出生より後でないことを確認する。
    引数: ref/birth(dict)。返り値: None。履歴参照へ現在freshを再要求しない。
    """
    assert ref['id'] and ref['width_seconds'] in (300, 900, 1800)
    assert valid_number(ref['end']) and ref['end'] <= ref['delivered']['time']
    assert all(ref['delivered'][k] <= birth[k] for k in ('time', 'index', 'source_line'))


# ----------------------------------------
def recovery_trace(meta: dict, event: dict) -> None:
    """
    機能: 任意の同episode回復traceから量と確認時の現在知得を追加照合する。
    引数: meta/event(dict)。返り値: None。traceなしは固定部品証跡を継承し値を捏造しない。
    """
    trace = meta.get('e1_recovery_trace')
    if trace is None:
        return
    assert isinstance(trace, dict) and trace['stage'] == '1分回復'
    assert trace['session'] == meta['session'] and trace['side'] == event['side']
    assert event['id'] == trace['episode_id'] + '/' + str(meta['birth']['index'])
    f = event['fields']; c = f['recovery_minute']; t = trace['fields']; at = trace['at']
    assert t['recovery_minute'] == c and t['K'] == event['hold_boundary']
    previous = t['previous_minute']
    assert previous['price_known'] and previous['volume_known']
    assert previous['end'] == previous['start'] + 60 and previous['end'] == c['start']
    assert valid_number(previous['volume']) and 0 < previous['volume'] <= c['volume']
    assert previous['last']['time'] < previous['end']
    assert all(previous['last'][k] < c['first'][k] for k in ('index', 'source_line'))
    assert all(valid_number(at[k]) for k in ('time', 'index', 'source_line', 'last'))
    assert c['end'] <= at['time'] <= c['end'] + 30
    assert all(c['last'][k] < at[k] for k in ('index', 'source_line'))
    assert all(f['improvement_ref']['delivered'][k] <= at[k] <= f['hold_started_at'][k] <= meta['birth'][k]
               for k in ('time', 'index', 'source_line'))
    assert event['side'] * (at['last'] - event['hold_boundary']) >= 0


# ----------------------------------------
def direction(meta: dict) -> None:
    """
    機能: E0/L0の固定Directionと、E1のpattern方向・順次成立・実取得geometryを区別する。
    引数: meta(dict)。返り値: None。E1にB0/T8を作らない。
    """
    source = meta['source_side']; selected = meta['selected_side']; kind = meta['kind']
    assert type(source) is int and source in (-1, 1) and type(selected) is int and selected in (-1, 1)
    assert kind in ('E0', 'L0', 'E1')
    birth, entry = meta['birth'], meta['entryQuote']
    assert birth['id'] == meta['source_id'] and birth['side'] == source
    assert meta['id'] == meta['model'] + '/' + meta['source_id']
    assert all(valid_number(birth[k]) and valid_number(entry[k]) for k in ('time', 'index', 'source_line'))
    assert birth['time'] + 1 <= entry['time'] < birth['time'] + 30
    assert birth['index'] < entry['index'] and birth['source_line'] < entry['source_line']
    assert all(birth['quote'][k] == birth[k] for k in ('time', 'index', 'source_line'))
    assert valid_number(birth['quote']['last']) and birth['quote']['last'] > 0
    if kind != 'E1':
        assert meta['direction_policy'] == ('source' if kind == 'E0' else 'fixedT8')
        assert meta['e1_event'] is None
        assert meta.get('e1_recovery_trace') is None
        assert meta['legacy_id'] == meta['source_id'].replace('/補完/L0/', '/補完/P3/')
        d = meta['direction']; assert isinstance(d, dict)
        fields = d['fields']; body = CALC.number(fields, 'body5_signed_ratio_to_source')
        b0 = -source if body is not None and .5 <= body < .75 else source
        long = CALC.number(fields, 'ema21_delta30_to_B0'); hist = CALC.number(fields, 'hist5_atr_to_B0')
        t8 = -b0 if long is not None and long >= 0 and hist is not None and hist >= .1 else b0
        assert (d['source_side'], d['b0_side'], d['t8_side']) == (source, b0, t8)
        assert d['e0_protected'] is (kind == 'E0')
        assert selected == d['selected_side'] == (source if kind == 'E0' else t8)
        assert d['refs'] and any(r['width_seconds'] == 300 for r in d['refs'])
        for ref in d['refs']:
            causal_ref(ref, birth)
        return
    assert meta['direction_policy'] == 'pattern' and meta['direction'] is None
    assert meta['legacy_id'] is None and selected == source
    event = meta['e1_event']; assert isinstance(event, dict)
    assert event['session'] == meta['session'] and event['id'] == meta['source_id'] and event['mode'] == 'E1'
    assert event['side'] == source and all(event['at'][k] == birth[k] for k in ('time', 'index', 'source_line'))
    assert event['refs']
    for ref in event['refs']:
        causal_ref(ref, birth)
    f = event['fields']
    assert f['direction_policy'] == 'pattern' and f['t8_applied'] is False
    assert f.get('recovery_bar_clock') == 'market_end'
    contact, freeze, phase, contact5, improve = (f[k] for k in ('contact', 'K_frozen_at', 'phase15', 'contact5', 'improvement_ref'))
    for ref in (phase, contact5, improve):
        causal_ref(ref, birth)
    assert phase['width_seconds'] == 900 and contact5['width_seconds'] == improve['width_seconds'] == 300
    assert phase['end'] <= contact['time'] and phase['delivered']['time'] <= contact['time']
    assert valid_number(f['phase15_hist']) and source * f['phase15_hist'] <= 0
    b, c = f['reject_minute'], f['recovery_minute']
    assert b['price_known'] and c['price_known'] and b['volume_known'] and c['volume_known']
    assert valid_number(b['volume']) and valid_number(c['volume']) and b['volume'] > 0 and c['volume'] > 0
    assert b['end'] == b['start'] + 60 and c['end'] == c['start'] + 60
    assert contact['time'] < b['end'] <= freeze['time'] <= b['end'] + 30
    assert b['last']['time'] >= contact['time'] and b['last']['time'] < b['end']
    assert b['last']['index'] >= contact['index'] and b['last']['source_line'] >= contact['source_line']
    assert improve['id'] != contact5['id'] and improve['end'] > contact5['end'] and improve['end'] > contact['time']
    assert improve['end'] >= b['end']
    assert all(improve['delivered'][k] > freeze[k] for k in ('time', 'index', 'source_line'))
    assert c['start'] >= improve['end'] and c['start'] >= b['end'] and c['end'] > b['end']
    assert c['first']['time'] >= c['start'] and c['first']['time'] <= c['last']['time'] < c['end']
    assert all(c['first'][k] <= c['last'][k] <= birth[k] for k in ('time', 'index', 'source_line'))
    hold = f['hold_started_at']
    assert c['end'] <= hold['time'] <= birth['time']
    assert all(improve['delivered'][k] <= hold[k] for k in ('time', 'index', 'source_line'))
    assert c['last']['index'] < hold['index'] and c['last']['source_line'] < hold['source_line']
    assert birth['time'] - hold['time'] == f['hold_elapsed_seconds'] and 1 <= f['hold_elapsed_seconds'] <= 10
    assert type(f['hold_rows']) is int and f['hold_rows'] >= 2
    assert all(hold[k] < birth[k] for k in ('index', 'source_line'))
    assert f['episode_expires'] == contact['time'] + 900
    assert f['recovery_expires'] == min(f['episode_expires'], improve['delivered']['time'] + 120)
    assert birth['time'] < f['episode_expires'] and birth['time'] < f['recovery_expires']
    atr = event['atr5']; assert valid_number(atr) and atr > 0 and atr == f['contact_atr']
    o = b['ohlc']; k = o['high'] + 5 if source == 1 else o['low'] - 5
    invalidation = o['low'] - 5 if source == 1 else o['high'] + 5
    assert event['hold_boundary'] == k and event['invalidation'] == invalidation
    assert event['entry_cap'] == k + source * min(20, .25 * atr)
    assert event['hold_minimum'] == 0 and event['minimum_risk'] == 10
    assert f['entry_ttl_seconds'] == 30 and f['risk_min'] == 10 and f['risk_max'] == min(125, 1.5 * atr)
    assert f['hold_strict'] is False
    price = entry['ask'] if source == 1 else entry['bid']
    assert source * (price - event['entry_cap']) <= 0 and source * (entry['last'] - k) >= 0
    assert 10 <= source * (price - invalidation) <= min(125, 1.5 * atr)
    assert source * (c['ohlc']['close'] - k) >= 0 and source * (birth['quote']['last'] - k) >= 0
    assert source * (birth['quote']['last'] - event['entry_cap']) <= 0
    assert 10 <= source * (birth['quote']['last'] - invalidation) <= min(125, 1.5 * atr)
    assert valid_number(hold['last']) and source * (hold['last'] - k) >= 0
    assert source * (hold['last'] - event['entry_cap']) <= 0
    assert 10 <= source * (hold['last'] - invalidation) <= min(125, 1.5 * atr)
    recovery_trace(meta, event)


# ----------------------------------------
def cohort_invariants(records: list[dict]) -> None:
    """
    機能: A0が旧C0を保持し、取得原行重複E1を数えず、S0の補完上限を守ることを確認する。
    引数: records(list[dict])。返り値: None。
    """
    controls = {(r['session'], r['meta']['legacy_id']): r for r in records if r['model'] == 'C0'}
    control_rows = [r for r in records if r['model'] == 'C0']
    assert len(controls) == len(control_rows) and all(k[1] is not None for k in controls)
    a0_old = {(r['session'], r['meta']['legacy_id']): r for r in records if r['model'] == 'A0' and r['meta']['kind'] != 'E1'}
    assert len(a0_old) == sum(r['model'] == 'A0' and r['meta']['kind'] != 'E1' for r in records)
    assert set(a0_old) == set(controls)
    stamp = lambda r: (r['session'], r['meta']['entryQuote']['time'], r['meta']['entryQuote']['index'], r['meta']['entryQuote']['source_line'])
    control_stamps = {stamp(r) for r in control_rows}
    a0_e1 = [r for r in records if r['model'] == 'A0' and r['meta']['kind'] == 'E1']
    assert all(stamp(r) not in control_stamps for r in a0_e1)
    assert len({stamp(r) for r in a0_e1}) == len(a0_e1)
    for key, original in controls.items():
        current = a0_old[key]
        for name in ('source_id', 'source_side', 'selected_side', 'kind', 'direction_policy', 'birth', 'entryQuote', 'direction'):
            assert original['meta'][name] == current['meta'][name]
        for name in ('original', 'reverse', 'chart_original', 'chart_reverse'):
            a, b = original['case'][name], current['case'][name]
            assert a['entry'] == b['entry'] and a['entry_price'] == b['entry_price'] and a['birth']['side'] == b['birth']['side']
            assert a['outcomes'] == b['outcomes']
    supplements = Counter(r['session'] for r in records if r['model'] == 'S0' and r['meta']['kind'] != 'E0')
    assert all(count <= 1 for count in supplements.values())


# ----------------------------------------
def prepare_records(result: dict, metadata: dict, fixed: dict) -> tuple[list[dict], list[str], dict]:
    """
    機能: 固定入力/方向metadataと4streamの自然結果を一意結合する。
    引数: result/metadata/fixed(dict)。返り値: tuple[list[dict],list[str],dict]。
    """
    assert result['success'] and result['trial'] == 133 and metadata['success'] and metadata['trial'] == 137
    assert metadata['new_outcomes_read'] is False
    assert result['input_sha256'] == metadata['fixed_input_sha256']
    sessions = [s['session'] for s in fixed['scenes']]
    assert sessions == metadata['sessions'] == [s['session'] for s in result['scenes']] == sorted(sessions)
    assert len(sessions) == len(set(sessions)) == result['scene_count'] == 73
    assert tuple(result['widths']) == (25, 50, 100, 125, 200) and tuple(result['horizons']) == (1800, 3600)
    meta_map = {(m['session'], m['id']): m for m in metadata['entries']}
    assert len(meta_map) == len(metadata['entries']) == fixed['expected_entry_count'] == result['source_entry_count']
    rows = []; seen = set(); phase = Counter()
    for original, scene in zip(fixed['scenes'], result['scenes']):
        sid = scene['session']; boundary = original['end'] - 300
        assert scene['success']
        assert all(scene['raw'][k] == original['raw'][k] for k in ('path', 'sha256'))
        assert scene['actual_sha256'] == original['raw']['sha256']
        assert scene['stat_before'] == scene['stat_after'] and scene['quality'] == scene['expected_quality'] == original['expected_quality']
        if 'bytes' in original['raw']:
            assert scene['stat_before']['bytes'] == original['raw']['bytes']
        if 'mod_time_ns' in original['raw']:
            assert scene['stat_before']['mtime_ns'] == original['raw']['mod_time_ns']
        assert scene['execution_end'] == boundary and scene['source_force_close'] == original['force_close']
        limit = min(original['force_close'], original['end'] - 3900)
        assert scene['effective_entry_limit'] == limit
        fixed_entries = {e['id']: e for e in original['entries']}
        assert len(fixed_entries) == len(original['entries']) == len(scene['cases']) == scene['source_entries']
        for case in scene['cases']:
            key = (sid, case['id']); assert key in meta_map and key not in seen
            seen.add(key); m = meta_map[key]; e = fixed_entries[case['id']]
            assert m['model'] in CALC.MODELS
            assert m['id'] == m['model'] + '/' + m['birth']['id'] and m['source_id'] == m['birth']['id']
            assert e['side'] == case['original_side'] == m['source_side']
            assert case['original']['entry'] == e['entry'] == m['entryQuote']
            direction(m)
            if m['kind'] == 'E1':
                phase['E1回復traceなし_部品証跡継承' if m.get('e1_recovery_trace') is None else 'E1回復trace照合'] += 1
            entry = e['entry']; assert original['start'] <= entry['time'] < limit
            assert entry['quote_ok'] and 0 < entry['bid'] < entry['ask']
            for name in ('original', 'reverse', 'chart_original', 'chart_reverse'):
                candidate = case[name]; chart = name.startswith('chart_')
                side = case['original_side'] if name in ('original', 'chart_original') else -case['original_side']
                assert candidate['status'] == 'filled' and candidate['birth']['side'] == side and candidate['entry'] == entry
                expected = entry['last'] if chart else entry['ask'] if side == 1 else entry['bid']
                assert candidate['entry_price'] == expected
                assert tuple(o['seconds'] for o in candidate['outcomes']) == (1800, 3600)
                phase['stream検査'] += 1; phase['entry検査'] += 1
                for o in candidate['outcomes']:
                    assert o['deadline'] == entry['time'] + o['seconds']
                    assert tuple(t['width'] for t in o['touches']) == (25, 50, 100, 125, 200)
                    assert o['status'] in ('complete', 'gap_censored', 'bbo_gap_censored', 'session_censored', 'endpoint_missing', 'phase_censored', 'eof_censored')
                    endpoint = o['endpoint']
                    assert (endpoint is not None) is (o['status'] == 'complete')
                    if endpoint is not None:
                        assert valid_number(endpoint['time']) and o['deadline'] <= endpoint['time'] <= o['deadline'] + 30
                        assert endpoint['time'] < boundary and endpoint['index'] > entry['index'] and endpoint['source_line'] > entry['source_line']
                        assert endpoint['quote_ok'] and 0 < endpoint['bid'] < endpoint['ask'] and valid_number(endpoint['last'])
                        phase['endpoint検査'] += 1
                    for touch in o['touches']:
                        assert type(touch['direction']) is int and touch['direction'] in (-1, 0, 1)
                        q = touch['quote']; assert (q is None) is (touch['direction'] == 0)
                        if q is not None:
                            assert valid_number(q['time']) and entry['time'] <= q['time'] <= o['deadline'] and q['time'] < boundary
                            assert q['index'] > entry['index'] and q['source_line'] > entry['source_line'] and q['quote_ok'] and 0 < q['bid'] < q['ask']
                            mark = q['last'] if chart else q['bid'] if side == 1 else q['ask']
                            gain = side * (mark - expected)
                            assert gain >= touch['width'] if touch['direction'] == 1 else gain <= -touch['width']
                            phase['touch検査'] += 1
                    if chart: assert o['net0'] is None and o['net5'] is None
            rows.append({'session': sid, 'model': m['model'], 'case': case, 'meta': m})
    assert seen == set(meta_map)
    assert metadata['counts'] == {model: sum(r['model'] == model for r in rows) for model in CALC.MODELS}
    for sid in sessions:
        for model in CALC.MODELS:
            assert metadata['coverage'][sid][model] is any(r['session'] == sid and r['model'] == model for r in rows)
    cohort_invariants(rows)
    return rows, sessions, dict(phase)


# ----------------------------------------
def assert_baselines(records: list[dict], aggregate: dict, old_pairs: dict, old126: dict) -> dict:
    """
    機能: C0の旧79Case全4streamと旧126T8全60条件を同体照合する。
    引数: records(list[dict])、aggregate/old_pairs/old126(dict)。返り値: dict。
    """
    previous = {(s['session'], c['id']): c for s in old_pairs['scenes'] for c in s['cases']}
    rows = [r for r in records if r['model'] == 'C0']; used = set(); labels = 0
    assert len(previous) == len(rows) == 79
    for r in rows:
        key = (r['session'], r['meta']['legacy_id']); assert key in previous and key not in used
        used.add(key); old = previous[key]; case = r['case']
        assert case['original_side'] == old['original_side']
        for name in ('original', 'reverse', 'chart_original', 'chart_reverse'):
            a, b = case[name], old[name]
            assert a['entry'] == b['entry'] and a['entry_price'] == b['entry_price'] and a['birth']['side'] == b['birth']['side']
            assert a['outcomes'] == b['outcomes'], (key, name)
            labels += 2 * 5
    assert used == set(previous)
    for part in ('all', 'train', 'validation'):
        assert aggregate[part]['C0'] == old126['集計'][part]['T8'], (part, '126T8')
    return {'成功': True, 'C0取得時計と4stream全outcomes同体': 79,
            '全H幅のラベル比較': labels, '旧集計の全条件同体': 60, '旧対照を書き換え': False}


# ----------------------------------------
def main() -> None:
    """
    機能: Root F1と全入力SHAを確認してからだけ自然結果を集計する。
    引数: CLIの固定入力/metadata/result/F1と各SHA(str/Path)。返り値: None。
    """
    parser = argparse.ArgumentParser(description='137のRoot金融前固定後だけ集計する')
    for name in ('f1', 'fixed-input', 'metadata', 'result'):
        parser.add_argument('--' + name, required=True, type=Path)
        parser.add_argument('--' + name + '-sha256', required=True)
    parser.add_argument('--output-dir', required=True, type=Path); args = parser.parse_args()
    paths = {name: getattr(args, name.replace('-', '_')).resolve() for name in ('f1', 'fixed-input', 'metadata', 'result')}
    expected = {name: getattr(args, name.replace('-', '_') + '_sha256') for name in paths}
    assert all(len(h) == 64 and all(c in '0123456789abcdef' for c in h) for h in expected.values())
    assert sha(paths['f1']) == expected['f1']
    f1 = json.loads(paths['f1'].read_text('utf-8')); declared = {Path(p).resolve(): h for p, h in f1['ファイル'].items()}
    for name in ('fixed-input', 'metadata'):
        assert declared[paths[name]] == expected[name] and sha(paths[name]) == expected[name]
    local = [OWN / n for n in ('条件.md', '計算.py', '集計する.py', '人工検査.py')]
    assert all(declared[p.resolve()] == sha(p) for p in local)
    assert all(declared[p.resolve()] == h for p, h in SOURCES.items())
    checks = {**SOURCES, **{paths[n]: expected[n] for n in paths}, **{p: sha(p) for p in local}}
    assert all(sha(p) == h for p, h in checks.items())
    dest = args.output_dir; dest.mkdir(parents=True, exist_ok=True)
    assert not any((dest / n).exists() for n in ('集計.json', 'CSV用の表.json', '集計完了.json'))
    # ここまで自然金融結果のJSON内容は開かない。Rootの明示SHAとF1を先に確認する。
    fixed = json.loads(paths['fixed-input'].read_text('utf-8')); metadata = json.loads(paths['metadata'].read_text('utf-8'))
    result = json.loads(paths['result'].read_text('utf-8'))
    assert metadata['fixed_input_sha256'] == expected['fixed-input']
    records, sessions, phase = prepare_records(result, metadata, fixed)
    module = CALC.load_arithmetic(); aggregate, participation = CALC.aggregate(records, sessions, module)
    baseline = assert_baselines(records, aggregate, json.loads(OLD_PAIRS.read_text('utf-8')),
                                json.loads(OLD126.read_text('utf-8')))
    frequency = CALC.frequency(records, sessions, fixed['scenes'])
    tables = CALC.tables(records, sessions, aggregate, participation, module, frequency)
    output = {'成功': True, '試行': 137, '主政策': 'A0', '主評価': CALC.goal(aggregate, participation, frequency),
              'E1回復時計': 'market_end',
              '後段engine試行': result['trial'], '全場数': 73, '取得集合数': metadata['counts'], '集計': aggregate, '参加': participation, '頻度': frequency,
              '主A0と同群O0の両側既知ペア差': CALC.paired(records, 'A0', 'O0', module),
              'A0とS0とC0のcaseペア差': None, '異時計の比較': '各取得集合の実現代用損益を並べる。同case差ではない',
              'bootstrap': CALC.bootstrap(records, sessions), '全4streamのphase検査': phase, '旧対照同体': baseline,
              '全73場は既使用': True, '独立未知期検証': False, '多重比較補正': False,
              'F1_SHA256': expected['f1'], '固定入力SHA256': expected['fixed-input'], '方向metadataSHA256': expected['metadata'],
              '自然結果SHA256': expected['result'], '口座収支': False, '実IFD': False,
              '頻度の定義': '全時間=sum(end-300-start)。名目新規可時間はstart〜min(force_close,end-3900)で副評価。各場capや毎時強制なし',
              '数量費用': '独立mini1枚100円/pt、往復77円、C5追加1000円。Last金額null'}
    assert all(sha(p) == h for p, h in checks.items())
    module.save(dest / '集計.json', output)
    module.save(dest / 'CSV用の表.json', {'成功': True, '試行': 137, '主政策': 'A0', 'tables': tables,
                '意味': '異なるA0/C0/S0取得集合と同一取得内の方向対照。独立1mini代用、口座収支ではない'})
    module.save(dest / '集計完了.json', {'成功': True, '試行': 137, '前後SHA256': {str(p): h for p, h in checks.items()},
                '前後不変': True, '表行数': [len(t['rows']) for t in tables], '表列数': [len(t['headers']) for t in tables],
                '集計SHA256': sha(dest / '集計.json'), '表SHA256': sha(dest / 'CSV用の表.json')})
    print(json.dumps({'成功': True, '主評価': output['主評価'], '行数': [len(t['rows']) for t in tables]}, ensure_ascii=False))


if __name__ == '__main__':
    main()
