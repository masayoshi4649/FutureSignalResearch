"""137金融集計器を自然入力なしで人工検査し、派生範囲と固定指紋を保存する。"""
from pathlib import Path
import ast
import hashlib
import importlib.util
import io
import json
import py_compile
import sys
import unittest

OWN = Path(__file__).resolve().parent
OLD = OWN.parent / '136押戻し回復と頻度の集計'
FROZEN = {
    '条件.md': '088fed2040d84206a482bed2a0a7e45f5c2e6ce0a92bc1d24cd14f54aa78d658',
    '計算.py': 'c4209e8e9843f91207b5f03d3bdf433df2d1956de3d26f2bf45d544d0293af7f',
    '集計する.py': 'c83379ea27ce6ccc9c13c029a11c294ee6b6e50014a55173fae8ed8a6f67218e',
    '人工検査.py': '69e020906e05a5fb1ead69efd215052739efba726602ed9008b8464bf20662bb',
    '準備の確認.json': '957c2dc1f55b9cc3b7761a0f54788e505c6a795c535bd2d369833d51173b34c9',
}


# ----------------------------------------
def sha(path: Path) -> str:
    """
    機能: コードと文書のbytes指紋を得る。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def functions(text: str) -> dict:
    """
    機能: 行番号等を除いた関数ASTを取得して非変更部分を比較する。
    引数: text(str)。返り値: dict[str,str]。
    """
    return {node.name: ast.dump(node, include_attributes=False) for node in ast.parse(text).body
            if isinstance(node, ast.FunctionDef)}


# ----------------------------------------
def main() -> None:
    """
    機能: 人工11群・可変三表・旧版不変更を確認し準備proofを作る。
    引数: なし。返り値: None。自然Source/Raw/CSV/金融は読まない。
    """
    sys.stdout.reconfigure(encoding='utf-8')
    names = ['条件.md', '計算.py', '集計する.py', '人工検査.py', '準備を確認する.py']
    before = {name: sha(OWN / name) for name in names}
    old_before = {name: sha(OLD / name) for name in FROZEN}
    assert old_before == FROZEN
    assert (OLD / '計算.py').read_text('utf-8').replace('136', '137') == (OWN / '計算.py').read_text('utf-8')
    old_cli = functions((OLD / '集計する.py').read_text('utf-8').replace('136', '137'))
    new_cli = functions((OWN / '集計する.py').read_text('utf-8'))
    assert set(new_cli) - set(old_cli) == {'recovery_trace'}
    assert set(old_cli) - set(new_cli) == set()
    changed = sorted(name for name in old_cli if old_cli[name] != new_cli[name])
    assert changed == ['direction', 'main', 'prepare_records']

    # ----------------------------------------
    # 人工moduleを私有importし、固定算術だけを読み込む。
    spec = importlib.util.spec_from_file_location('137準備の人工', OWN / '人工検査.py')
    artificial = importlib.util.module_from_spec(spec); spec.loader.exec_module(artificial)
    arithmetic = artificial.C.MODULE
    arithmetic_before = sha(arithmetic)
    assert arithmetic_before == artificial.C.MODULE_SHA
    for name in names:
        if name.endswith('.py'):
            py_compile.compile(str(OWN / name), doraise=True)
    suite = unittest.defaultTestLoader.loadTestsFromModule(artificial)
    assert suite.countTestCases() == 11
    log = io.StringIO()
    outcome = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
    assert outcome.wasSuccessful() and outcome.testsRun == 11 and not outcome.skipped
    (OWN / '人工検査のログ.txt').write_text(log.getvalue(), encoding='utf-8')
    result, meta, fixed = artificial.fixture()
    rows, sessions, phase = artificial.RUN.prepare_records(result, meta, fixed)
    module = artificial.C.load_arithmetic()
    aggregate, participation = artificial.C.aggregate(rows, sessions, module)
    frequency = artificial.C.frequency(rows, sessions, fixed['scenes'])
    tables = artificial.C.tables(rows, sessions, aggregate, participation, module, frequency)
    assert before == {name: sha(OWN / name) for name in names}
    assert old_before == {name: sha(OLD / name) for name in FROZEN}
    assert sha(arithmetic) == arithmetic_before
    proof = {
        '成功': True, '試行予定': 137, '状態': '人工準備のみ・自然入力接続と金融未実行',
        'SHA256': before, '旧136固定SHA256': old_before,
        '人工群': outcome.testsRun, '人工取得集合件数': meta['counts'],
        '人工表行数': [len(table['rows']) for table in tables],
        '人工表列数': [len(table['headers']) for table in tables], '人工phase検査': phase,
        '固定124算術SHA256': arithmetic_before, '後段engine': 133, '主政策': 'A0',
        '回復時計': 'market_end', '計算moduleは試行表記以外136と同体': True,
        'CLIの変更関数': changed, 'CLIの追加関数': ['recovery_trace'],
        'CLIの同体関数': sorted(name for name in old_cli if name not in changed),
        '三条件を別判定': True, '全時間加重頻度と名目新規可頻度を分離': True,
        'E1のB0T8はnull': True, '公表前形成cを現在知得後に許可': True,
        '任意traceの確認時量と30秒を照合': True, '出生時年齢30秒の追加': False,
        '自然金融読取と再計算': False, '自然Source読取': False, 'RawとCSV読取': False,
        '追加2場読取': False, '正式採番操作': False, 'Root入力接続': '未実行',
        '前後コード同体': True, '旧136前後同体': True, '固定算術前後同体': True,
        '人工ログSHA256': sha(OWN / '人工検査のログ.txt'),
    }
    dest = OWN / '準備の確認.json'
    dest.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'success': True, 'proof_sha256': sha(dest), 'files': before}, ensure_ascii=True))


if __name__ == '__main__':
    main()
