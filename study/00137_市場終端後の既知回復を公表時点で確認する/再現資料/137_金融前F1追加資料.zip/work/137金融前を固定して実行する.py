"""137の可変取得をF1固定後だけ正逆観測し、モデル別に集計する。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
OWN = ROOT/'work/137既知回復の評価'
FIXED = OWN/'固定入力/固定取得入力.json'
META = OWN/'固定入力/方向と出生.json'
AGG = ROOT/'work/137既知回復と頻度の集計'
BRIDGE = ROOT/'work/137出生を固定入力へ渡す'
KERNEL = ROOT/'work/133固定取得の正逆評価器/固定取得の正逆評価.exe'
KERNEL_SHA = '033cf22a052e985bc61aa020a04fa6d499119051aaa39bb2adb715a4af1e7736'
FORMAL = ROOT/'study/00137_市場終端後の既知回復を公表時点で確認する'
HELPER = ROOT/'work/133金融前を固定して実行する.py'


def sha(path: Path) -> str:
    """
    機能: ファイルの全バイト指紋を返す。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def load(path: Path, name: str) -> object:
    """
    機能: mainを呼ばず宣言と既存検査を私有モジュールへ読み込む。
    引数: path(Path)、name(str)。
    返り値: object。
    """
    spec = importlib.util.spec_from_file_location(name,path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# ----------------------------------------
def main() -> None:
    """
    機能: 金融前固定・原板正逆観測・モデル別集計の三段階を分離する。
    引数: CLI --mode(str)、固定時--fixed-sha256/--metadata-sha256(str)。
    返り値: None。Source出生の再生成や結果後の主変更をしない。
    """
    parser = argparse.ArgumentParser(description='137の金融前固定と実正逆観測')
    parser.add_argument('--mode',choices=('固定','再生','集計'),required=True)
    parser.add_argument('--fixed-sha256')
    parser.add_argument('--metadata-sha256')
    args = parser.parse_args()
    helper = load(HELPER,'137で使用する凍結133検査')
    f1 = OWN/'F1.json'
    assert sha(KERNEL) == KERNEL_SHA
    if args.mode == '固定':
        assert args.fixed_sha256 and sha(FIXED) == args.fixed_sha256
        assert args.metadata_sha256 and sha(META) == args.metadata_sha256
        f0 = json.loads((OWN/'F0.json').read_bytes())
        helper.verify(f0)
        source_check = json.loads((OWN/'Source非金融の確認.json').read_bytes())
        assert source_check['成功'] and source_check['試行'] == 137
        assert source_check['Source_SHA256'] == sha(OWN/'Sourceの出生と取得.json')
        metadata = json.loads(META.read_bytes())
        assert metadata['success'] and metadata['trial'] == 137
        assert metadata['fixed_input_sha256'] == args.fixed_sha256
        assert {e['model'] for e in metadata['entries']} == {'C0','S0','A0'}
        declared = load(AGG/'集計する.py','137金融前の固定宣言')
        assert all(sha(p) == expected for p,expected in declared.SOURCES.items())
        files = {Path(p) for p in f0['ファイル']} | set(declared.SOURCES)
        files.update((OWN/'F0.json',OWN/'Sourceの出生と取得.json',OWN/'Source非金融の確認.json',
                      OWN/'Source走査の完了.json',FIXED,META,HELPER,KERNEL,Path(__file__).resolve()))
        for folder in (FORMAL,BRIDGE,AGG,OWN/'固定入力'):
            files.update(p for p in folder.rglob('*') if p.is_file() and p.suffix in ('.py','.md','.json'))
        helper.save(f1,{'成功':True,'試行':137,'段階':'金融前F1','UTC':datetime.now(timezone.utc).isoformat(),
             '主':'A0/C0に全適格E1を追加、全73場min1・実BBO/H60±125先着70・全時間平均概ね1/h',
             '政策':['A0','C0','S0','O0','R0'],'取得集合':['C0','S0','A0'],'正逆kernel版':133,
             '副結果で主を交換しない':True,'Source追加走査禁止':True,
             'ファイル':{str(p):sha(p) for p in sorted(files)}})
        print(json.dumps({'F1_SHA256':sha(f1),'固定ファイル数':len(files)},ensure_ascii=False))
        return
    fixed = json.loads(f1.read_bytes())
    helper.verify(fixed)
    output = OWN/'固定取得の正逆観測.json'
    if args.mode == '再生':
        assert not output.exists(),'保存済み観測を再生し直さない'
        command = [str(KERNEL),'--input',str(FIXED),'--sha256',sha(FIXED),'--output',str(output),'--workers','8']
        subprocess.run(command,cwd=ROOT,check=True)
        helper.verify(fixed)
        helper.verify_result(json.loads(output.read_bytes()),json.loads(FIXED.read_bytes()))
        helper.save(OWN/'正逆観測の完了.json',{'成功':True,'試行':137,'engine_trial':133,'F1_SHA256':sha(f1),
             '観測SHA256':sha(output),'全固定源前後同体':True,'実行列':command})
        return
    command = [sys.executable,'-X','utf8',str(AGG/'集計する.py'),'--f1',str(f1),'--f1-sha256',sha(f1),
               '--fixed-input',str(FIXED),'--fixed-input-sha256',sha(FIXED),
               '--metadata',str(META),'--metadata-sha256',sha(META),
               '--result',str(output),'--result-sha256',sha(output),'--output-dir',str(AGG)]
    subprocess.run(command,cwd=ROOT,check=True)
    helper.verify(fixed)
    helper.save(OWN/'金融段階の完了.json',{'成功':True,'試行':137,'F1_SHA256':sha(f1),'全固定源前後同体':True,
         '集計SHA256':sha(AGG/'集計.json'),'CSV用の表SHA256':sha(AGG/'CSV用の表.json'),'実行列':command})


if __name__ == '__main__':
    main()
