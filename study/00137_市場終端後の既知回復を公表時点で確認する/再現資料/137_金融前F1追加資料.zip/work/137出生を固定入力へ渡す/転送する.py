"""137の非金融Sourceを3モデルの固定取得入力へ渡す。原板・CSV・金融は読まない。"""
import argparse
import copy
import gzip
import hashlib
import importlib.util
import json
import math
from collections import Counter
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
MODELS=('C0','S0','A0')
BASE=ROOT/'inputs/00124_同入口正逆の共用入力/入力.json.gz'
BASE_SHA='b2368b1f42c16e8c96a3acd098c58a902807a3b6a5023d6d4b1e75261f3ee51b'
OLD=ROOT/'work/T8の15分位相による切替案/choices.json'
OLD_SHA='cdf1f0c6248d76222d49c7d872094cce20edecb7f52aa9e725d1040aa51f17c3'
DIRECTION=ROOT/'work/133Source取得を固定入力へ渡す_版2.py'
DIRECTION_SHA='6469ea3d473be6f25169f5629193ecb9ad681b4fc685ae78167525e311fcbd55'
SOURCE_INPUT_SHA='6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec'


def digest(data: bytes) -> str:
    """
    機能: bytesの指紋を求める。
    引数: data(bytes)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(data).hexdigest()


def close(a: float,b: float) -> bool:
    """
    機能: 有限な派生値を丸め誤差だけ許して比較する。
    引数: a/b(float)は比較値。
    返り値: boolは一致判定。
    """
    return type(a) in (int,float) and type(b) in (int,float) and math.isfinite(a) and math.isfinite(b) and math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-9)


def stamp(q: dict) -> tuple:
    """
    機能: 価格時計と採用順・物理行を検査して取り出す。
    引数: q(dict)はQuote又はStamp。
    返り値: tupleはtime/index/source_line。
    """
    assert type(q['time']) in (int,float) and math.isfinite(q['time'])
    assert type(q['index']) is int and q['index']>=0 and type(q['source_line']) is int and q['source_line']>=1
    return q['time'],q['index'],q['source_line']


def quote(q: dict,normal: bool=False) -> None:
    """
    機能: 当時Quoteと必要時の正常実BBOを検査する。
    引数: q(dict)、normal(bool)は価格行と取得側検査の有無。
    返り値: None。不正は停止。
    """
    stamp(q);assert type(q['last']) in (int,float) and math.isfinite(q['last']) and q['last']>0
    if normal:assert q['quote_ok'] is True and math.isfinite(q['bid']) and math.isfinite(q['ask']) and 0<q['bid']<q['ask']


def le(a: dict,b: dict,strict: bool=False) -> bool:
    """
    機能: 同秒の物理順を含め未来参照を検査する。
    引数: a/b(dict)、strict(bool)は前後Stampと別原行要求。
    返り値: boolは因果条件。
    """
    x,y=stamp(a),stamp(b)
    return x[0]<=y[0] and (x[1]<y[1] and x[2]<y[2] if strict else x[1]<=y[1] and x[2]<=y[2])


def refs(values: list[dict],at: dict) -> None:
    """
    機能: 全参照の市場Endと実配送が出生以前であることを確認する。
    引数: values(list[dict])、at(dict)は保存参照と出生。
    返り値: None。
    """
    assert values
    for r in values:assert r['id'] and r['end']<=r['delivered']['time'] and le(r['delivered'],at)


def bar(b: dict,at: dict|None=None) -> None:
    """
    機能: 確定観測1分の価格・原行・任意の確認時年齢を検査する。
    引数: b(dict)、at(dict|None)は足と実確認Stamp。
    返り値: None。出生時へ30秒年齢を移植しない。
    """
    assert b['price_known'] is True and type(b['rows']) is int and b['rows']>0 and b['end']==b['start']+60
    o=b['ohlc'];assert all(type(o[k]) in (int,float) and math.isfinite(o[k]) for k in ('open','high','low','close'))
    assert 0<o['low']<=min(o['open'],o['close'])<=max(o['open'],o['close'])<=o['high']
    first,last=b['first'],b['last'];assert le(first,last) and b['start']<=first['time']<=last['time']<b['end']
    if at is not None:assert b['end']<=at['time']<=b['end']+30 and le(last,at,True)


def legacy_id(identity: str) -> str:
    """
    機能: 旧補完L0だけを旧P3のIDへ正規化する。
    引数: identity(str)はSource出生ID。
    返り値: strは旧参照ID。E0は変更しない。
    """
    return identity.replace('/補完/L0/','/補完/P3/')


def load_direction() -> object:
    """
    機能: 既定133版2の非金融方向検査だけを指紋付きで読み込む。
    引数: なし。
    返り値: objectはverify_directionを持つmodule。mainは実行しない。
    """
    assert digest(DIRECTION.read_bytes())==DIRECTION_SHA
    spec=importlib.util.spec_from_file_location('固定133方向検査',DIRECTION)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


def scene_check(meta: dict,scene: dict) -> float:
    """
    機能: Source legacyのRaw参照・stat・品質・執行限界を共用metadataと照合する。
    引数: meta/scene(dict)は共用場とSource場。
    返り値: floatは共通H60新規限界。
    """
    s=scene['legacy'];assert scene['success'] and s['success'] and scene['session']==s['session']==meta['session']
    assert scene['raw_passes']==s['raw_passes']==1 and s['source_signals_used'] is False
    assert s['actual_sha256']==meta['raw']['sha256'] and all(s['raw'][k]==meta['raw'][k] for k in ('path','sha256'))
    assert s['quality']==s['expected_quality']==meta['expected_quality'] and s['stat_before']==s['stat_after']
    for container in (meta['raw'],s['raw']):
        for k,sk in (('bytes','bytes'),('mod_time_ns','mtime_ns')):
            if k in container:assert container[k]==s['stat_before'][sk]
    limit=min(meta['force_close'],meta['end']-3900)
    assert s['source_force_close']==meta['force_close'] and s['entry_cutoff']==limit and s['execution_end']==meta['end']-300
    assert s['fallback_at']=={'L0':meta['start']+10800,'L1':meta['end']-4020}
    return limit


def verify_legacy(c: dict,meta: dict,limit: float,pure: object) -> dict:
    """
    機能: 旧L0の元geometry取得と固定方向式を再確認する。
    引数: c/meta(dict)、limit(float)、pure(object)は候補・場・限界・133検査器。
    返り値: dictはmodel未付与のmetadata行。
    """
    assert c['policy']=='L0' and c['status']=='filled' and 'outcomes' not in c
    b,q,d=c['birth'],c['entry'],c['direction'];side=b['side'];assert type(side) is int and side in (-1,1)
    quote(b['quote']);quote(q,True);assert all(b[k]==b['quote'][k] for k in ('time','index','source_line'))
    assert le(b,q,True) and b['time']+1<=q['time']<c['expires'] and meta['start']<=b['time']<q['time']<limit
    assert c['entry_price']==(q['ask'] if side>0 else q['bid'])
    pure.verify_direction(d,side,c['path']);refs(d['refs'],b)
    strategy='E0' if c['path']=='E0' else c['decision']['strategy'];assert strategy in ('E0','trend','reversal','deadline')
    return {'session':meta['session'],'source_id':b['id'],'legacy_id':legacy_id(b['id']),
        'kind':'E0' if c['path']=='E0' else 'L0','source_side':side,'selected_side':d['selected_side'],
        'direction_policy':'source' if c['path']=='E0' else 'fixedT8','path':c['path'],'strategy':strategy,
        'birth':b,'entryQuote':q,'direction':d,'e1_event':None,'e1_recovery_trace':None,'e1_recovery_trace_source':None,
        'e1_trace_limitations':[]}


def verify_e1(c: dict,event: dict,meta: dict,limit: float,traces: list[dict],source_sha: str) -> dict:
    """
    機能: E1の保存geometry・市場時計・現在取得・実回復traceを検査する。
    引数: c/event/meta(dict)、limit(float)、traces(list[dict])、source_sha(str)は保存候補と出典。
    返り値: dictはmodel未付与行。不足traceはnullと限界を保持する。
    """
    assert c['status']=='filled' and c['path']=='E1' and c['direction_policy']=='pattern' and c['t8_applied'] is False
    assert c['event']==event and event['id']==c['id'] and event['session']==meta['session'] and event['mode']=='E1'
    side=event['side'];assert type(side) is int and side in (-1,1)
    b,q=c['birth'],c['entry'];quote(b);quote(q,True)
    assert stamp(event['at'])==stamp(b) and le(b,q,True) and meta['start']<=b['time']+1<=q['time']<limit
    assert c['expires']==min(b['time']+30,limit) and q['time']<c['expires'] and c['evaluation']==q
    price=q['ask'] if side>0 else q['bid'];assert c['entry_price']==price
    f=event['fields'];atr=event['atr5'];k=event['hold_boundary'];invalid=event['invalidation'];cap=event['entry_cap']
    assert math.isfinite(atr) and atr>0 and event['minimum_risk']==10 and event['hold_minimum']==0
    assert f['recovery_bar_clock']=='market_end' and f['direction_policy']=='pattern' and f['t8_applied'] is False and f['hold_strict'] is False
    assert close(f['contact_atr'],atr) and close(cap,k+side*min(20,.25*atr)) and close(f['risk_max'],min(125,1.5*atr))
    assert f['risk_min']==10 and f['entry_ttl_seconds']==30
    for mark in (b['last'],price):assert side*(mark-cap)<=0 and 10<=side*(mark-invalid)<=min(125,1.5*atr)
    assert side*(b['last']-k)>=0 and side*(q['last']-k)>=0 and close(c['risk_at_decision'],side*(price-invalid))
    reject=f['reject_minute'];recover=f['recovery_minute'];frozen=f['K_frozen_at'];bar(reject,frozen);bar(recover)
    assert reject['volume_known'] is True and math.isfinite(reject['volume']) and reject['volume']>0
    assert k==(reject['ohlc']['high']+5 if side>0 else reject['ohlc']['low']-5)
    assert invalid==(reject['ohlc']['low']-5 if side>0 else reject['ohlc']['high']+5)
    m=f['improvement_ref'];contact=f['contact'];hold=f['hold_started_at'];refs(event['refs'],b)
    assert m['width_seconds']==300 and f['phase15']['width_seconds']==900 and side*f['phase15_hist']<=0
    assert m['id']!=f['contact5']['id'] and m['end']>f['contact5']['end'] and m['end']>contact['time'] and m['end']>=reject['end']
    assert all(m['delivered'][v]>frozen[v] for v in ('time','index','source_line')) and le(m['delivered'],hold)
    assert recover['start']>=m['end'] and recover['start']>=reject['end'] and recover['end']>reject['end']
    assert side*(recover['ohlc']['close']-k)>=0 and le(recover['last'],hold,True)
    assert close(f['episode_expires'],contact['time']+900) and close(f['recovery_expires'],min(f['episode_expires'],m['delivered']['time']+120))
    assert b['time']<f['episode_expires'] and b['time']<f['recovery_expires'] and le(hold,b,True)
    assert type(f['hold_rows']) is int and f['hold_rows']>=2 and 1<=b['time']-hold['time']<=10 and close(f['hold_elapsed_seconds'],b['time']-hold['time'])
    suffix='/'+str(event['at']['index']);assert event['id'].endswith(suffix)
    episode=event['id'][:-len(suffix)];matches=[(i,t) for i,t in enumerate(traces) if t['episode_id']==episode and t['stage']=='1分回復']
    assert len(matches)<=1;trace=None;origin=None
    limitations=['拒否足の直前量はEvent/回復traceに無いため比較は固定部品証跡を継承']
    if matches:
        i,trace=matches[0];assert trace['session']==meta['session'] and trace['contract']==meta['contract'] and trace['side']==side
        tf=trace['fields'];assert tf['recovery_minute']==recover and tf['K']==k
        at=trace['at'];quote(at);bar(recover,at);assert le(m['delivered'],at) and le(at,hold) and side*(at['last']-k)>=0
        previous=tf['previous_minute'];bar(previous)
        assert previous['end']==recover['start'] and le(previous['last'],recover['first'],True)
        assert previous['volume_known'] is True and recover['volume_known'] is True and math.isfinite(previous['volume']) and math.isfinite(recover['volume']) and recover['volume']>=previous['volume']>0
        origin={'source_sha256':source_sha,'session':meta['session'],'episode_id':episode,'lifecycle_index':i}
    else:limitations.append('回復traceが無いため直前量比較と回復確認時30秒は未検証。固定部品証跡を継承')
    signal={'id':event['id'],'side':side,'time':b['time'],'index':b['index'],'source_line':b['source_line'],'quote':b}
    return {'session':meta['session'],'source_id':event['id'],'legacy_id':None,'kind':'E1','source_side':side,'selected_side':side,
        'direction_policy':'pattern','path':'E1','strategy':'E1','birth':signal,'entryQuote':q,'direction':None,'e1_event':event,
        'e1_recovery_trace':trace,'e1_recovery_trace_source':origin,'e1_trace_limitations':limitations}


def reference(row: dict,contract: str) -> dict:
    """
    機能: originから価格を使わない選択器の参照形を再構成する。
    引数: row(dict)、contract(str)は結合行と限月。
    返り値: dictはKind/IDと出生・取得Stamp。
    """
    return {'session':row['session'],'contract':contract,'kind':row['kind'],'id':row['source_id'],
        'birth_stamp':dict(zip(('time','index','source_line'),stamp(row['birth']))),
        'entry_stamp':dict(zip(('time','index','source_line'),stamp(row['entryQuote'])))}


def selections(origins: list[dict]) -> dict:
    """
    機能: 原取得順だけでC0/S0/A0を独立に再構成する。
    引数: origins(list[dict])は旧L0列の後にE1元順で並べた参照。
    返り値: dictは3モデルの期待参照。A0はC0優先で同原行を除く。
    """
    ordered=sorted(origins,key=lambda r:(stamp(r['entry_stamp']),{'E0':0,'L0':1,'E1':2}[r['kind']],r['id']))
    c0=[r for r in ordered if r['kind']!='E1'];s0=[];seen_e0=False;chosen=False
    for r in ordered:
        if r['kind']=='E0':s0.append(r);seen_e0=True
        elif not seen_e0 and not chosen:s0.append(r);chosen=True
    rows=list(c0);seen={stamp(r['entry_stamp']) for r in rows};assert len(seen)==len(rows)
    for r in origins:
        if r['kind']=='E1' and stamp(r['entry_stamp']) not in seen:rows.append(r);seen.add(stamp(r['entry_stamp']))
    return {'C0':c0,'S0':s0,'A0':sorted(rows,key=lambda r:stamp(r['entry_stamp']))}


def convert(source: dict,base: dict,old: dict,pure: object,source_sha: str) -> tuple[dict,dict]:
    """
    機能: 非金融の辞書入力だけから3モデルの固定取得とmetadataを生成する。
    引数: source/base/old(dict)、pure(object)、source_sha(str)はSource・共用metadata・旧票・方向器・指紋。
    返り値: tuple[dict,dict]は固定入力とmetadata。既存entriesは転記しない。
    """
    assert source['success'] and source['base_trial']==133 and source['input_sha256']==SOURCE_INPUT_SHA
    assert source['financial_labels_used'] is False and source['portfolio_pnl'] is False and source['source_signals_used'] is False
    assert source['candidate_quantity']==1 and source['scene_count']==len(source['scenes'])==len(base['scenes'])==73
    assert source['engine']=='Source133に市場終端後の既知回復E1を追加した版2'
    sessions=[s['session'] for s in base['scenes']];assert sessions==[s['session'] for s in source['scenes']] and len(set(sessions))==73
    oldmap={(r['session'],r['id']):r for r in old['choices']};basemap={(s['session'],r['id']):r for s in base['scenes'] for r in s['entries']}
    assert len(oldmap)==len(basemap)==79
    scenes=[];rows=[];coverage={};attempts={};c0seen=set()
    for meta,s in zip(base['scenes'],source['scenes']):
        sid=meta['session'];limit=scene_check(meta,s);origins=[]
        for c in s['legacy']['candidates']:
            if c['policy']=='L0' and c['entry'] is not None:origins.append(verify_legacy(c,meta,limit,pure))
        assert s['legacy']['coverage']['L0']==bool(origins)
        events={e['id']:e for e in s['e1_events']};assert len(events)==len(s['e1_events'])
        candidates=s['e1_candidates'];assert len({c['id'] for c in candidates})==len(candidates) and {c['id'] for c in candidates}==set(events)
        for c in candidates:
            assert c['event']==events[c['id']] and c['event']['fields']['recovery_bar_clock']=='market_end'
            if c['entry'] is not None:origins.append(verify_e1(c,events[c['id']],meta,limit,s['lifecycle'],source_sha))
            else:assert c['status']!='filled'
        originmap={(r['kind'],r['source_id']):r for r in origins};assert len(originmap)==len(origins)
        refs_by_model=selections([reference(r,meta['contract']) for r in origins])
        for model,actual in (('C0',s['selection']['C0']),('S0',s['selection']['S0']),('A0',s['frequency_A0'])):assert actual==refs_by_model[model],(sid,model,'選択不一致')
        fixed={k:copy.deepcopy(meta[k]) for k in ('session','contract','start','end','force_close','raw','expected_accepted','expected_quality')};fixed['entries']=[]
        coverage[sid]={};attempts[sid]={'legacyL0':dict(Counter(c['status'] for c in s['legacy']['candidates'] if c['policy']=='L0')),'E1':dict(Counter(c['status'] for c in candidates))}
        for model in MODELS:
            coverage[sid][model]=bool(refs_by_model[model]);assert coverage[sid][model],(sid,model,'未取得場を除外しない')
            for ref in refs_by_model[model]:
                r=copy.deepcopy(originmap[ref['kind'],ref['id']]);identity=model+'/'+r['source_id'];r.update({'id':identity,'model':model})
                if model=='C0':
                    key=(sid,r['legacy_id']);assert key in oldmap and key not in c0seen;c0seen.add(key);o=oldmap[key]
                    assert r['source_side']==o['original_side'] and r['selected_side']==o['t8_side'] and r['path']==o['path'] and r['strategy']==o['strategy']
                    assert r['entryQuote']==basemap[key]['entry'] and r['source_side']==basemap[key]['side']
                    assert all(r['birth'][k]==o['birth'][k] and r['entryQuote'][k]==o['entry'][k] for k in ('time','index','source_line'))
                fixed['entries'].append({'id':identity,'side':r['source_side'],'entry':copy.deepcopy(r['entryQuote'])});rows.append(r)
        assert len({r['id'] for r in fixed['entries']})==len(fixed['entries']);scenes.append(fixed)
    assert c0seen==set(oldmap) and sum(r['model']=='C0' for r in rows)==79
    assert len({(r['session'],r['id']) for r in rows})==len(rows)
    fixed={'scenes':scenes,'expected_entry_count':len(rows)}
    metadata={'success':True,'trial':137,'source_sha256':source_sha,'source_input_sha256':source['input_sha256'],'sessions':sessions,
        'entries':rows,'coverage':coverage,'attempts':attempts,'counts':dict(Counter(r['model'] for r in rows)),
        'old_C0_79_identical':True,'new_outcomes_read':False,'selected_direction_order_eligibility_rebuilt':False,
        'E1_trace_missing_entries':sum(r['kind']=='E1' and r['e1_recovery_trace'] is None for r in rows)}
    return fixed,metadata


def save(path: Path,value: dict) -> str:
    """
    機能: 未作成JSONへUTF-8で保存する。
    引数: path(Path)、value(dict)は先と値。
    返り値: strは保存SHA256。
    """
    with path.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
    return digest(path.read_bytes())


def main() -> None:
    """
    機能: RootのSource確認後に明示CLIで橋渡しだけを実行する。
    引数: CLI --source/--sha256/--output-dirはSource・期待指紋・未作成先。
    返り値: None。原板・自然CSV・金融・追加2場は開かない。
    """
    p=argparse.ArgumentParser(description='137非金融Sourceを固定取得入力へ渡す')
    p.add_argument('--source',type=Path,required=True);p.add_argument('--sha256',required=True);p.add_argument('--output-dir',type=Path,required=True);args=p.parse_args()
    assert len(args.sha256)==64 and all(c in '0123456789abcdef' for c in args.sha256) and not args.output_dir.exists()
    data=args.source.read_bytes();assert digest(data)==args.sha256
    decoded=gzip.decompress(BASE.read_bytes());assert digest(decoded)==BASE_SHA
    previous=OLD.read_bytes();assert digest(previous)==OLD_SHA
    source=json.loads(data)
    fixed,metadata=convert(source,json.loads(decoded),json.loads(previous),load_direction(),args.sha256)
    assert all(s['selection']['C0']==s['selection']['S0'] for s in source['scenes']),'今回固定SourceのS0/C0同体差'
    metadata['S0_C0_same_source_references']=True
    assert digest(args.source.read_bytes())==args.sha256 and digest(gzip.decompress(BASE.read_bytes()))==BASE_SHA and digest(OLD.read_bytes())==OLD_SHA
    args.output_dir.mkdir(parents=True,exist_ok=False)
    input_sha=save(args.output_dir/'固定取得入力.json',fixed);metadata['fixed_input_sha256']=input_sha
    meta_sha=save(args.output_dir/'方向と出生.json',metadata)
    proof={'成功':True,'試行':137,'Source前後SHA256':args.sha256,'固定取得入力SHA256':input_sha,'方向と出生SHA256':meta_sha,
        '全場':73,'取得数':metadata['counts'],'全モデル全73最低1取得':True,'C0旧79同体':True,
        'S0_C0参照同体':True,
        'E1回復trace不足のmetadata件数':metadata['E1_trace_missing_entries'],'原板又はCSV又は金融読取':False,
        '反転方向の注文適格性再構築':False,'方向検査器SHA256':DIRECTION_SHA,'共用metadata解凍SHA256':BASE_SHA,'旧方向票SHA256':OLD_SHA,
        'コードSHA256':digest(Path(__file__).read_bytes())}
    save(args.output_dir/'転送の確認.json',proof);print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':main()
