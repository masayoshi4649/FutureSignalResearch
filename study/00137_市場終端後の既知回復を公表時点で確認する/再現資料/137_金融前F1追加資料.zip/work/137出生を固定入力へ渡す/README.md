# 137の非金融Sourceから固定取得入力へ渡す

本部品は原板・CSV・先着/損益を読まない。SourceはRootが実行・確認した非金融の出生/取得だけを明示SHAで読む。共用124の小型metadata、旧131の固定方向票79件、指紋付き133版2のverify_directionを再用し、既存entriesをコピーせず空から3モデルC0/S0/A0を構築する。

実行例は `python work/137出生を固定入力へ渡す/転送する.py --source <Sourceの出生と取得.json> --sha256 <Root確認SHA256> --output-dir <未作成フォルダ>`。既存出力先・未知SHAは拒否する。出力は固定取得入力.json、方向と出生.json、転送の確認.json。Go固定入力のentries[].entryとmetadata.entries[].entryQuoteは同じ保存Quoteで、固定入力は元方向、metadataのselected_sideは固定T8又はE1のpattern方向を持つ。反転方向の注文適格性は再構築していない。

Raw参照・SHA・stat前後・期待品質・契約/時刻の共用由来、H60新規限界、取得実側価格を検査する。C0旧79件の元側/固定方向/出生取得時計・Quoteを旧固定票と照合し、今回の固定SourceではS0の参照がC0と同体であることも追加検査する。全73場を残して3モデルの最低1取得を確認し、不成立場を捨てて入力を作らない。取得総数はC0/S0/A0から数えてexpected_entry_countへ入れる。

E1はfilled・pattern・T8非適用、Eventと元候補の同体、市場End以後の確定c、現在Lastと実Bid/AskのK/cap/risk、出生後1秒以上・30秒TTL、固定ATR、900/120秒、出生Raw2行/1秒以上10秒以内、公表refsを検査する。Event.IDはepisode_id+'/'+出生indexという固定作者式なので、lifecycleの同episode「1分回復」を一意結合し、元Trace形のe1_recovery_traceとSource SHA/場/episode/lifecycle添字の出典を別フィールドに保存する。c自身の直前量・確認Rawの現在年齢30秒・当時LastKはこのTraceから検査し、出生まで年齢30秒を課していない。

回復traceが無い場合はnullと未検証理由を残す。拒否bの直前量はEvent/回復traceに無いため、その比較は固定部品証跡を継承すると明記する。最初の正常BBOかどうか、背景数値の全再生成、観測間の保持を原板再走査で再証明していない。Source実装とF0の証跡を継承する。

選択はkind+idで元候補へ結合し、原取得順・同Raw E0優先/L0優先、S0は全E0と最初E0前の最初1補完を再構成する。A0はC0全件を保持し、同取得原行をC0優先で除いて全適格E1を加える。将来価格・損益で選ばない。

`python work/137出生を固定入力へ渡す/人工検査.py` の4主群は人工73場/旧79・239件、売買鏡像、0出生、trace不足null、stat/方向/cap/量/確認年齢/選択改変拒否、S0優先/A0原行重複除去を確認する。人工入力はテスト内で作り、自然Sourceを開かない。準備固定後、Rootが許可したSource SHAだけを読む。
