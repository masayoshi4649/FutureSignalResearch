"""非金融の人工73場・旧79件・E1だけで橋渡しを検査する。自然Sourceは読まない。"""
import copy
import importlib.util
import unittest
from pathlib import Path

HERE=Path(__file__).resolve().parent
SPEC=importlib.util.spec_from_file_location('転送137',HERE/'転送する.py')
M=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(M)


def q(at: int,price: float=100) -> dict:
    """
    機能: 人工時計のQuoteを作る。
    引数: at(int)、price(float)は時計/価格。
    返り値: dictは正常BBOを持つ行。
    """
    return {'clock':'人工','time':at,'index':at,'source_line':at+1,'last':price,'bid':price-1,'ask':price+1,'quote_ok':True}


def ref(identity: str,width: int,end: int,at: int) -> dict:
    """
    機能: 人工の公表参照を作る。
    引数: identity(str)、width/end/at(int)は識別・幅・終端・配送時計。
    返り値: dictは参照。
    """
    return {'id':identity,'width_seconds':width,'end':end,'delivered':dict(zip(('time','index','source_line'),M.stamp(q(at))))}


def foot(start: int,o: float,h: float,l: float,c: float,v: float,side: int=1) -> dict:
    """
    機能: 正常閉鎖した人工1分を作る。
    引数: start(int)、o/h/l/c/v(float)、side(int)は足と鏡像側。
    返り値: dictは観測価格と量proxy。
    """
    if side<0:o,h,l,c=200-o,200-l,200-h,200-c
    return {'start':start,'end':start+60,'ohlc':{'open':o,'high':h,'low':l,'close':c},'rows':2,
        'first':q(start,o),'last':q(start+59,c),'price_known':True,'volume_known':True,'volume':v,'tr':{'known':False,'value':0}}


def fixture(e1: bool=True,side: int=1) -> tuple[dict,dict,dict]:
    """
    機能: 既知期にも価格にも依存しない73場79対照と2E1の人工入力を作る。
    引数: e1(bool)、side(int)は追加有無と売買鏡像。
    返り値: tupleはSource・共用metadata・旧方向票。
    """
    base={'scenes':[]};source={'success':True,'base_trial':133,'input_sha256':M.SOURCE_INPUT_SHA,'financial_labels_used':False,
        'portfolio_pnl':False,'source_signals_used':False,'candidate_quantity':1,'scene_count':73,'scenes':[],
        'engine':'Source133に市場終端後の既知回復E1を追加した版2'};old={'choices':[]}
    known=lambda n:{'known':True,'value':n}
    for i in range(73):
        sid=f'人工{i:03d}_Day';quality={'source_parser_accepted':10,'source_delivered':10}
        meta={'session':sid,'contract':'人工限月','start':0,'end':30000,'force_close':29400,'raw':{'path':sid+'.人工','sha256':'a'*64},
            'expected_accepted':10,'expected_quality':quality,'entries':[]}
        legacy={'session':sid,'success':True,'raw':copy.deepcopy(meta['raw']),'actual_sha256':'a'*64,'quality':quality,'expected_quality':quality,
            'stat_before':{'bytes':10,'mtime_ns':20},'stat_after':{'bytes':10,'mtime_ns':20},'raw_passes':1,'source_signals_used':False,
            'source_force_close':29400,'entry_cutoff':26100,'execution_end':29700,'fallback_at':{'L0':10800,'L1':25980},'candidates':[],'coverage':{'L0':True}}
        refs=[]
        for k in range(2 if i<6 else 1):
            at=100+200*k;identity=sid+('/E0/一' if k else '/補完/L0/100');path='E0' if k else 'strong'
            birth={'id':identity,'side':1,**{n:q(at)[n] for n in ('time','index','source_line')},'quote':q(at)};entry=q(at+2)
            direction={'source_side':1,'b0_side':1,'t8_side':1,'selected_side':1,'e0_protected':bool(k),
                'fields':{n:known(v) for n,v in {'body5_signed_ratio_to_source':.1,'ema21_delta30_to_B0':-1,'hist5_atr_to_B0':0,'high5':110,'low5':90,'range5':20,'open5':100,'close5':102}.items()},
                'refs':[ref('人工5',300,0,10)]}
            candidate={'policy':'L0','path':path,'status':'filled','birth':birth,'entry':entry,'entry_price':101,'expires':at+30,
                'decision':{'strategy':'trend'},'direction':direction};legacy['candidates'].append(candidate)
            rid=M.legacy_id(identity);meta['entries'].append({'id':rid,'side':1,'entry':entry})
            old['choices'].append({'session':sid,'id':rid,'original_side':1,'t8_side':1,'path':path,'strategy':'E0' if k else 'trend',
                'birth':{n:birth[n] for n in ('time','index','source_line')},'entry':{n:entry[n] for n in ('time','index','source_line')}})
            refs.append({'session':sid,'contract':'人工限月','kind':'E0' if k else 'L0','id':identity,
                'birth_stamp':{n:birth[n] for n in ('time','index','source_line')},'entry_stamp':{n:entry[n] for n in ('time','index','source_line')}})
        scene={'session':sid,'success':True,'raw_passes':1,'legacy':legacy,'e1_events':[],'e1_candidates':[],'lifecycle':[],
            'selection':{'C0':copy.deepcopy(refs),'S0':copy.deepcopy(refs)},'frequency_A0':copy.deepcopy(refs)}
        if e1 and i<2:
            reject=foot(960,100,104,99,103,150,side);recover=foot(1200,102,110,101,109,200,side);previous=foot(1140,102,103,101,102,100,side)
            price=lambda n:n if side>0 else 200-n
            birth,entry=q(1266,price(109)),q(1267,price(110));episode=f'{sid}/E1/{side}/000001';identity=episode+'/1266'
            m=ref('新5',300,1200,1265);k,invalid,cap=price(109),price(94),price(119)
            fields={'recovery_bar_clock':'market_end','direction_policy':'pattern','t8_applied':False,'hold_strict':False,
                'contact_atr':40,'risk_max':60,'risk_min':10,'entry_ttl_seconds':30,'contact':q(1000,price(102)),
                'K_frozen_at':q(1021,price(103)),'reject_minute':reject,'recovery_minute':recover,'improvement_ref':m,
                'contact5':ref('旧5',300,900,961),'phase15':ref('旧15',900,900,961),'phase15_hist':-side,
                'hold_started_at':q(1265,price(109)),'episode_expires':1900,'recovery_expires':1385,'hold_rows':2,'hold_elapsed_seconds':1}
            event={'id':identity,'session':sid,'mode':'E1','side':side,'at':{n:birth[n] for n in ('time','index','source_line')},
                'entry_cap':cap,'invalidation':invalid,'atr5':40,'hold_boundary':k,'hold_minimum':0,'minimum_risk':10,'fields':fields,'refs':[m]}
            candidate={'id':identity,'status':'filled','path':'E1','direction_policy':'pattern','t8_applied':False,'event':event,'birth':birth,
                'entry':entry,'evaluation':entry,'entry_price':entry['ask'] if side>0 else entry['bid'],'risk_at_decision':17,'expires':1296}
            scene['e1_events'].append(event);scene['e1_candidates'].append(candidate)
            scene['lifecycle'].append({'session':sid,'contract':'人工限月','episode_id':episode,'side':side,'stage':'1分回復','reason':'人工',
                'at':q(1265,price(109)),'fields':{'recovery_minute':recover,'previous_minute':previous,'K':k}})
            scene['frequency_A0'].append({'session':sid,'contract':'人工限月','kind':'E1','id':identity,
                'birth_stamp':{n:birth[n] for n in ('time','index','source_line')},'entry_stamp':{n:entry[n] for n in ('time','index','source_line')}})
        base['scenes'].append(meta);source['scenes'].append(scene)
    return source,base,old


class Tests(unittest.TestCase):
    """自然ファイルを読まず、選択とgeometryを人工で検査する。"""
    @classmethod
    def setUpClass(cls) -> None:
        """
        機能: 指紋一致の非金融方向関数だけを読む。
        引数: cls(type)は検査クラス。
        返り値: None。
        """
        cls.pure=M.load_direction()

    def test_full_73_79_239_and_mirror(self) -> None:
        """
        機能: 全場と79対照、実量trace、売買鏡像2件、239出力を検査する。
        引数: self(Tests)は検査状態。
        返り値: None。
        """
        for side in (1,-1):
            source,base,old=fixture(side=side);saved=copy.deepcopy((source,base,old));fixed,meta=M.convert(source,base,old,self.pure,'b'*64)
            self.assertEqual(fixed['expected_entry_count'],239);self.assertEqual(meta['counts'],{'C0':79,'S0':79,'A0':81})
            self.assertEqual(meta['E1_trace_missing_entries'],0);self.assertEqual(len(meta['sessions']),73)
            self.assertEqual((source,base,old),saved)
            for row in meta['entries']:
                if row['kind']=='E1':self.assertEqual(row['selected_side'],side);self.assertIsNotNone(row['e1_recovery_trace'])

    def test_zero_birth_and_missing_trace(self) -> None:
        """
        機能: 0E1を同体保持し、trace欠落はnullと限界へ分ける。
        引数: self(Tests)は検査状態。
        返り値: None。
        """
        s,b,o=fixture(e1=False);fixed,meta=M.convert(s,b,o,self.pure,'b'*64);self.assertEqual(fixed['expected_entry_count'],237)
        s,b,o=fixture();s['scenes'][0]['lifecycle']=[];_,meta=M.convert(s,b,o,self.pure,'b'*64)
        self.assertEqual(meta['E1_trace_missing_entries'],1)
        row=next(r for r in meta['entries'] if r['kind']=='E1' and r['session']=='人工000_Day')
        self.assertIsNone(row['e1_recovery_trace']);self.assertTrue(row['e1_trace_limitations'])

    def test_reject_corruption(self) -> None:
        """
        機能: 品質・旧方向・cap・量・確認年齢・選択改変を停止する。
        引数: self(Tests)は検査状態。
        返り値: None。
        """
        for kind in ('stat','direction','cap','quantity','age','selection'):
            s,b,o=fixture();scene=s['scenes'][0]
            if kind=='stat':scene['legacy']['stat_after']['bytes']+=1
            if kind=='direction':scene['legacy']['candidates'][0]['direction']['selected_side']=-1
            if kind=='cap':scene['e1_candidates'][0]['entry']['ask']=125;scene['e1_candidates'][0]['entry_price']=125
            if kind=='quantity':scene['lifecycle'][0]['fields']['previous_minute']['volume']=201
            if kind=='age':scene['lifecycle'][0]['at']['time']=1291
            if kind=='selection':scene['selection']['S0']=[]
            with self.assertRaises(AssertionError,msg=kind):M.convert(s,b,o,self.pure,'b'*64)

    def test_selection_priority_and_dedup(self) -> None:
        """
        機能: 最初1補完・E0全保持・同取得RawのC0優先を独立期待値と比較する。
        引数: self(Tests)は検査状態。
        返り値: None。
        """
        def row(kind: str,identity: str,at: int) -> dict:
            """
            機能: 選択器だけの価格なし参照を作る。
            引数: kind/identity(str)、at(int)は種別・ID・取得時計。
            返り値: dictは参照。
            """
            return {'kind':kind,'id':identity,'entry_stamp':{n:q(at)[n] for n in ('time','index','source_line')}}
        values=[row('L0','旧',10),row('E0','基準',30),row('E1','早',5),row('E1','同Raw',10),row('E1','後',40)]
        result=M.selections(values)
        self.assertEqual([r['id'] for r in result['S0']],['早','基準'])
        self.assertEqual([r['id'] for r in result['A0']],['早','旧','基準','後'])
        values.append(row('E1','E0同Raw',30));result=M.selections(values)
        self.assertNotIn('E0同Raw',[r['id'] for r in result['A0']])


if __name__=='__main__':unittest.main(verbosity=2)
