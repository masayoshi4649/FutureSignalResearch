"""202の幅別対照と元側回復の結果を、固定履歴として保存する。"""
from pathlib import Path
import json,zipfile,shutil,re,os,hashlib,sys
import 入口202 as E
sys.path.insert(0,str(E.ROOT/'work/196TOPIX'))
from 正式化196 import row_text
TRIAL=E.ROOT/'study/00202_TOPIXの確認位置と元側回復を幅別に比較する'
INPUT=E.ROOT/'inputs/00202_TOPIXの確認位置と元側回復の純入口'


def ref(path):
    """
    機能: 保存資源の相対位置と指紋を記録する。
    引数: path(Path)。
    返り値: dictはpath/bytes/sha256。
    """
    return {'path':path.relative_to(E.ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':E.M.sha(path)}


def main():
    """
    機能: 18口座の条件・正本・原因・567セル・Sourceを恒久保存する。
    引数: なし。
    返り値: None。旧試行と今回の出生・金融は変更しない。
    """
    TRIAL.mkdir(parents=True,exist_ok=True);INPUT.mkdir(parents=True,exist_ok=True)
    files=('条件.json','人工確認.json','金融開始前固定.json','純成立診断.json','旧対照同体.json','全18組安定性.json.gz','全18組短表.json.gz','独立確認.json','原因診断.json','固定選択.json','名称修正確認.json')
    for name in files:shutil.copy2(E.HERE/name,TRIAL/name)
    shutil.copy2(E.HERE/'純入口.json.gz',INPUT/'純入口.json.gz')
    manifest={'試行':202,'純出生':ref(INPUT/'純入口.json.gz'),'条件':ref(TRIAL/'条件.json'),'原板':'inputs/TOPIX原順8列_20260921_20261116/台帳.json','母体':'inputs/00200_TOPIXの観測被覆と時間順入口/入力台帳.json'}
    (INPUT/'入力台帳.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (INPUT/'README.md').write_text('# TOPIX 202の純入口\n\n[研究正本](../../study/00202_TOPIXの確認位置と元側回復を幅別に比較する/README.md)。当初81場34,424q0・6入口×3幅=18。200全83の診断後に設計し、追加2場は探索に混ぜない。価格原板の複製はなく、恒久の共用入力を参照する。\n',encoding='utf-8')
    prior=E.read(E.ROOT/'study/00200_TOPIXの観測被覆と構造確認の順序を分ける/Source索引.json');sources=sorted(set([E.ROOT/r['path'] for r in prior]+list(E.HERE.glob('*.py'))))
    with zipfile.ZipFile(TRIAL/'Source.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for path in sources:archive.write(path,path.relative_to(E.ROOT).as_posix())
        for name in ('入力台帳.json','条件_実装修正1.json'):
            path=E.M.HERE/name;archive.write(path,path.relative_to(E.ROOT).as_posix())
        for path in (E.HERE/'名称修正前').glob('*'):
            if path.is_file():archive.write(path,path.relative_to(E.ROOT).as_posix())
    (TRIAL/'Source索引.json').write_text(json.dumps([ref(p) for p in sources],ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    template=E.ROOT/'docs/議論/手法と時間スケールの汎用表_版8.md';body=template.read_text(encoding='utf-8').split('## 設定明細')[0]
    body=body.replace('# 手法と時間スケールの汎用表・版8','# 202 TOPIX・設定と結果（版8）').replace('全セルは未設定・未検証。','使用セルに設定IDを記す。').replace('未設定・未検証','未使用')
    used={'I01':{3:'S1旧P0/源EMA8',4:'S1中期背景',5:'S1旧D4背景'},'I02':{3:'S2源からの進行0.5/1ATR'},'I03':{3:'S1/S3水準と回復増分'},'I04':{3:'S1/S3範囲と回復増分'},
        'I08':{3:'S1 DI/ADX',4:'S1 DI',5:'S1旧D4'},'I09':{3:'S2進行尺度/R1 A25幅'},'C01':{3:'S1持続',4:'S1'},'C07':{1:'S3破断→元側回復→保持',3:'S1/S3',4:'S1',5:'S1旧D4'},
        'P01':{1:'S3実体・端'},'P05':{1:'S2/S3進行'},'P06':{1:'S3源の前3本端固定'},'P07':{1:'S3次連続q0保持'},
        'V01':{0:'S4累積量時計',1:'S4旧量',3:'S4不明時5分量'},'B01':{0:'正常BBO/旧対照費用方向'},'E01':{0:'R1同一入口の3幅IFD'},'E02':{0:'R1固定SLとH60'}}
    count=0;lines=[]
    for line in body.splitlines():
        cells=[c.strip() for c in line.strip().strip('|').split('|')] if line.startswith('|') else []
        if len(cells)==11 and re.fullmatch(r'[A-Z][0-9]{2}',cells[0]):
            count+=1
            for i in range(9):cells[i+2]=used.get(cells[0],{}).get(i,'未使用')
            line='| '+' | '.join(cells)+' |'
        lines.append(line)
    assert count==63
    body='\n'.join(lines)+'\n';body=re.sub(r'\]\(([^)]+)\)',lambda m:']('+os.path.relpath((template.parent/m.group(1)).resolve(),TRIAL).replace('\\','/')+')',body)
    body+='''
## 設定明細と複合評価

S1は旧共通即時、和集合即時、200の実反転側確認。Dayは旧190D4固定。S2は確認時のq0終値が源終値から実側へ0<進行<=0.5又は1源ATRのときだけ反転確認を採用し、元順行即時は保持する。約定後の価格や損益から入口を選ばない。

S3は和集合P0源の旧実側への端破断、その後の元側への再回復、さらに次の連続q0（30〜90秒）保持を記録する。源の元/実側、形成、前3本端、10分期限を固定。保持は終値が元側・反対端侵入0.1ATR以内、元側MACD又はRSI増分正、S4量>=0.5。源当時の破断既知は可だが、源当時の回復発火は不可。後発源で期限を延長せず同源一度。

S4は旧1分量、和集合は1分不明時だけ192同体5分量。既知0を不明へ置換しない。200の過去被覆を入口棄却へ追加しない。

R1は各同一入口×Night W15/W10/A25の3幅。A25は確認q0の選択形成ATR5×2.5を5〜25ptへ制限し0.25刻み切上げ。取得後固定、H60、保有予約合計1、終了15分前、miniTOPIX片道41.8円+0.25pt。幅ごとに枠解放と後続取得も再計算する。新採用なし。[条件](条件.json)・[結果](全18組安定性.json.gz)・[原因](原因診断.json)。指標単独の効果ではない。未使用は無効判定ではない。

## 再現と版

[Source](Source.zip)・[索引](Source索引.json)・[純入口](../../inputs/00202_TOPIXの確認位置と元側回復の純入口/入力台帳.json)。版8は63手法×9尺度=567セル。旧81は既使用、200の追加2診断後に設計した。
'''
    body+='\n汎用表SHA256: '+hashlib.sha256(template.read_bytes()).hexdigest()+'\n';(TRIAL/'設定と結果.md').write_text(body,encoding='utf-8')
    states=E.read(E.HERE/'全18組安定性.json.gz')['metrics'];header='| index | 取得 / 参加場 | 保有下限 | 未知 | 利益円 | 損失円 | 既知収支円 | 建玉 / 場中央値下限円 | 場末DD円 |\n| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |\n'
    report='''# 202 TOPIXの確認位置と元側回復を幅別に比較する

2026-11-18作成。**新案は採用しない。** 固定15ptを狭めれば反転確認の問題が解消する、とは確認できなかった。位置を浅く限定すると口座のDDは減るが、取引する場と保有時間が減り、両中央値も満たさない。破断失敗後の元側回復自体も費用後赤字。202候補は板201の比較へ追加せず、203で方向を決める背景と価格回復の役割を分ける。

## 仮説・入力・固定条件

[200](../00200_TOPIXの観測被覆と構造確認の順序を分ける/README.md)では、実反転確認69件のうち到達が8F/6Aの14件だけで、期限48件が費用後−53,012.8円。15ptがATR中央値4.15倍だった。今回、6入口×同一3幅を比較し、値幅と入口と後続の取得枠を分離する。186も複数幅を調べたが、今回は200の固定時間順入口と新しい元側回復が対象である。

当初81場（2026-09-21Day〜11-16Day）だけで探索。全80発見/前48選択/後25/追加7/最終Dayを区別するが全て既使用。200全83を診断した後の仮説で、194追加2場を未見とは呼ばない。追加2場金融を本探索には混ぜない。[条件](条件.json)・[設定と結果](設定と結果.md)。

Dayは旧190D4/A25固定、Nightは同一入口を±15pt/±10pt/±A25で比較。A25は確認q0の公表ATR5×2.5を5〜25ptで0.25切上げ。H60は全案同じ、単純IFD、保有予約合計1、開始待機なし、15:30/05:45までに全決済。miniTOPIX1枚・1pt=1,000円、片道41.8円+0.25pt。ラージBBO代用・遅延1秒/取得TTL30秒。未知は0円とせず枠を場末保持する。

元側回復は源の旧実側への価格端破断、元側への再回復、次q0保持を当時の時計順に確認する。最終的な反転の成否や損益を読んで回復候補を作らない。源の固定端・元/実側・10分期限を後から書き換えない。

## 18案のNight結果

index0〜2=旧共通即時、3〜5=和集合即時、6〜8=200反転側確認、9〜11=確認進行0〜0.5ATR、12〜14=同0〜1ATR、15〜17=破断失敗から元側回復。各3案は15pt/10pt/A25順。母数40Night。

'''+header+'\n'.join(row_text(i,'NIGHT',states) for i in range(18))+'''

Dayは全18案が旧190同体の207取得/41場、保有54.90%・未知0、利益841,471.2/損失798,776.4/収支+42,694.8円。全場取得はNightの和集合即時で維持するが、未知21〜23と両中央値の不確定/赤字が残る。

## 幅を狭めても、入口の方向問題は解消しなかった

[原因診断](原因診断.json)は同じ入口の共通取得・幅変更で片方だけ実際に取得した建玉を区別する。枠変更を無視した独立一枚合算ではない。

200反転側確認（index6→7）を15→10ptにすると121→143取得、到達25F/12A→48F/38A、損失396,681.6→525,519.2円。実反転確認枝自体は69→73取得、先着8F/6A→16F/14A、既知収支−14,099.6→−57,434円。元順行即時も52→70取得、17F/6A→32F/24Aとなり、損切りが増えた。

A25の実反転確認は72取得・14F/22A・既知−79,933.2円。期限28件の費用前は+5,000円と改善する一方、IFD損切り22件の既知費用後−189,172円が増えた。期限損失だけを減らしても全体の安定性は改善しない。支持の薄い到達割合と、未到達・未知を併記する。

## 確認位置と元側回復

0.5ATR上限×15pt（index9）はDD40,754→19,668.8円、前48+44,156/後25+39,575.6/追加7+32,580.4円。ただ86取得/32場・保有14.35%、建玉/場中央値−83.6/0。反転確認枝は33件・1F/1A/26N/5C・既知−9,840.8円で、口座益の中心は元順行即時53件+126,152.8円だった。200の事後群27件+20,160.8円が、そのまま再生口座の新枝損益にはならない。

元側回復×15pt（index15）は79取得/31場・保有12.07%・未知2、建玉中央値+916.4円だが場中央値0。回復枝自身は21件/18場、4F/5A/12N・金融未知1、費用前−21,500/費用後−33,172円。既存元順行即時58件+100,234.8円と分ける。価格端の再回復だけで長期・中期の支持まで確認したことにはならない。

次203は旧費用比で元順行/実反転を決める母体を外し、長期支持→中期押戻し→短期構造回復と、長期失速→新方向の中期回復を独立に出生させる案を設計する。同時に厳しいANDを増やすのではなく、深さ・開始・回復の順序を残す。

## 検査・名称修正・再現

[人工確認](人工確認.json)3,320項目、[独立確認](独立確認.json)6,247取得・金融81,211属性・別集計57,996属性・全q0枠57,828件を照合。不一致0。旧190台帳の同体も確認。[固定選択](固定選択.json)は全80/前48の既定順位を保存、全体採用null。

複製した金融実行器のID末尾に固定文字列NightW15が残ったため削除した。入口名のW15/W10/A25と約定widthは当初から正しく、変更はIDだけ。旧コード・封印・正本をSource内の名称修正前へ保持し、再計算でID以外の全18台帳・全群・全期間が完全同体と確認した。[名称修正確認](名称修正確認.json)。

[Source](Source.zip)・[索引](Source索引.json)・[恒久純入口](../../inputs/00202_TOPIXの確認位置と元側回復の純入口/README.md)。Python3.14.3/NumPy2.5.4/tzdata2026.6。[共通再現ツール](../../scripts/TOPIX入口研究/README.md)の`固定純入口を再生.py 202`で、新しいworkへ原板を複製せず全金融を再生し正本SHAを比較する。`--監査`で別算術も再実行。純出生は197/200の固定母体と183/184当時特徴から`人工確認202.py`→`入口202.py`で生成する。
'''
    (TRIAL/'README.md').write_text(report,encoding='utf-8');print(json.dumps({'正式化':str(TRIAL),'表セル':567,'Source数':len(sources)},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
