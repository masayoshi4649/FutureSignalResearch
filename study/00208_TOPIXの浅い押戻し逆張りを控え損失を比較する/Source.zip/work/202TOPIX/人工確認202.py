"""破断・回復・保持の順序、源の不変性と同幅比較を金融前に検査する。"""
from copy import deepcopy
import json
import 入口202 as E
from 人工確認197 import around_row


def main():
    """
    機能: 売買鏡像、回復の前提順序、価格位置境界、prefix同体を確認する。
    引数: なし。
    返り値: None。旧金融・追加場の成績で検査条件を変更しない。
    """
    checks=0;features={f:E.read(E.ROOT/'inputs/TOPIX原順8列_20260921_20261116'/n) for f,n in enumerate(('純特徴183.json.gz','純特徴184直接.json.gz'))}
    scene='2026-09-21_Night';start=E.M.bounds(scene)[0];source=deepcopy(features[1][1000])
    source.update(session=scene,time=start+3600,line=1,band='PRE',close=3998.,prior_high=4001.,prior_low=3999.,prior_close=4000.,high=4001.,low=3997.,atr=2.,rvol=1.,body=-1.,progress=-1.)
    source['m5'].update(hist_delta=.1,rsi_delta=0.,ema8=4001.)
    rec=deepcopy(source);rec.update(time=source['time']+60,line=2,close=4000.,prior_close=3998.,body=1.,progress=1.,high=4001.,low=3998.)
    hold=deepcopy(rec);hold.update(time=source['time']+120,line=3,close=4001.,prior_close=4000.,high=4002.,low=3999.5)
    extra={'rvol5':1.}
    for mirror in (False,True):
        row=around_row(source,4000.) if mirror else source;side=1 if mirror else -1;native=-side
        seed=E.P.make_seed(row,side,native,1);seed.update(broken_at=row['time'] if E.broken(seed,row) else None,recovered_at=None)
        frozen={k:v for k,v in seed.items() if k not in ('armed','broken_at','recovered_at')}
        assert seed['broken_at']==row['time'];checks+=1
        assert not E.recover(seed,row,extra);checks+=1
        recovery=around_row(rec,4000.) if mirror else rec;confirmation=around_row(hold,4000.) if mirror else hold
        assert not E.recover(seed,recovery,extra) and seed['recovered_at']==recovery['time'];checks+=2
        assert E.recover(seed,confirmation,extra);checks+=1
        assert {k:v for k,v in seed.items() if k not in ('armed','broken_at','recovered_at')}==frozen;checks+=1
        for failure in ('未破断','量不明','保持なし','確認間隔超過','動力なし'):
            state=E.P.make_seed(row,side,native,1);state.update(broken_at=None if failure=='未破断' else row['time'],recovered_at=None)
            E.recover(state,recovery,extra);bad=deepcopy(confirmation)
            if failure=='量不明':bad['rvol']=None;ex={'rvol5':None}
            else:ex=extra
            if failure=='保持なし':bad['low' if native==1 else 'high']=state['level']-native*2.
            if failure=='確認間隔超過':bad['time']+=120
            if failure=='動力なし':bad['m5'].update(hist_delta=0.,rsi_delta=0.)
            assert not E.recover(state,bad,ex),failure;checks+=1
    s={'close':4000.,'atr':2.};b={'side':1,'reverse':True}
    for close,limit,expected in ((4000.,.5,False),(3999.,.5,False),(4001.,.5,True),(4001.001,.5,False),(4001.001,1.,True),(4002.,1.,True),(4002.001,1.,False)):
        assert E.bounded_progress(b,{'close':close},s,limit)==expected;checks+=1
        assert E.bounded_progress({'side':-1,'reverse':True},{'close':8000-close},s,limit)==expected;checks+=1
    for atr,expected in ((1.,5.),(3.,7.5),(30.,25.)):
        assert E.P.B.P.U.width({'atr':atr},'A25')==expected;checks+=1
    # ----------------------------------------
    # 実履歴の接頭部同体と、破断→回復→発火の時計・同源一度性。
    base=E.read(E.ROOT/'inputs/00197_TOPIXの一因子比較の純入口/純入口.json.gz')
    maps={f:{(r['session'],r['time'],r['line']):r for r in rows} for f,rows in features.items()};contexts={f:E.P.B.context_rows(rows) for f,rows in features.items()}
    full,counts=E.recoveries(base,maps,contexts);prefix,_=E.recoveries(base[:2000],maps,contexts)
    for key,value in prefix.items():assert full[key]==value;checks+=1
    seen=set()
    for key,birth in full.items():
        if birth is None:continue
        marker=(key[0],birth['time'],birth['line']);assert marker not in seen;seen.add(marker);checks+=1
        assert birth['expiry']==birth['time']+600 and birth['time']<=key[1]<=birth['expiry'];checks+=2
        if birth['reverse']:
            assert birth['time']<=birth['broken_at']<key[1] and birth['entry_side']==birth['native'] and birth['source_actual']==birth['side'];checks+=3
    proof={'成功':True,'項目数':checks,'売買鏡像':True,'破断前に元側回復しない':True,'prefix同体':True,'源方向期限固定':True,'同源一度発火':True,'診断':counts,'SourceSHA':E.M.sha(E.HERE/'入口202.py')}
    E.M.save(E.HERE/'人工確認.json',proof);print(json.dumps(proof,ensure_ascii=False),flush=True)


if __name__=='__main__':main()
