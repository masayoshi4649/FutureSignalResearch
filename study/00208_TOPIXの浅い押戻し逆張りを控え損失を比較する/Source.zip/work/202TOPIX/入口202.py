"""200の固定入口と確認位置・破断回復を、同一幅対照で比較する。"""
from pathlib import Path
from collections import defaultdict
import sys,json
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
sys.path.insert(0,str(ROOT/'work/200TOPIX'))
import 入口200 as P
M=P.M;read=P.read
ENTRIES=('E0_旧共通即時','E1_和集合即時','E2_200反転側確認','E3_確認進行005ATR','E4_確認進行010ATR','E5_破断失敗から元側回復')
WIDTHS=('W15','W10','A25')
NAMES=tuple(e+'_'+w for e in ENTRIES for w in WIDTHS)


def bounded_progress(birth,row,source,limit):
    """
    機能: 実反転確認の取得位置を、源からの当時進行で限定する。
    引数: birth/row/source(dict),limit(float)は0.5又は1.0ATR。
    返り値: bool。元順行即時は変更せず、実約定価格や未来損益は使わない。
    """
    if not birth['reverse']:return True
    progress=birth['side']*(row['close']-source['close'])/source['atr']
    return 0<progress<=limit


def broken(seed,row):
    """
    機能: 源の固定3本端を旧実側へ破断した事実を確認する。
    引数: seed/row(dict)。
    返り値: bool。源q0の時点で既に成立した破断も可、未来の成否は読まない。
    """
    side=seed['side'];level=seed['level']
    return side*(row['prior_close']-level)<=0<side*(row['close']-level) and side*row['body']>0 and side*row['progress']>0


def recover(seed,row,extra):
    """
    機能: 旧実側への破断後、固定端を元側へ回復し次q0でも保持する順序を評価する。
    引数: seed(dict)は監視状態,row/extra(dict)は当時特徴。
    返り値: boolは元側への一度の発火。源の方向・端・期限は変更しない。
    """
    if row['time']<=seed['time']:return False
    if seed['broken_at'] is None:
        if broken(seed,row):seed['broken_at']=row['time']
        return False
    side=seed['native'];level=seed['level'];armed=seed['recovered_at'];start=M.bounds(row['session'])[0]
    if armed is not None:
        consecutive=int((row['time']-start)//60)-int((armed-start)//60)==1
        extreme=row['low'] if side==1 else row['high']
        held=side*(row['close']-level)>0 and side*(extreme-level)>=-.1*row['atr']
        momentum=side*(row['m5']['hist_delta'] or 0)>0 or side*(row['m5']['rsi_delta'] or 0)>0
        if consecutive and 30<=row['time']-armed<=90 and held and momentum and P.usable(row,extra,1):return True
        seed['recovered_at']=None
    if row['time']>seed['broken_at'] and side*(row['prior_close']-level)<=0<side*(row['close']-level) and side*row['body']>0 and side*row['progress']>0:
        seed['recovered_at']=row['time']
    return False


def recoveries(base,maps,contexts):
    """
    機能: 和集合P0源の失敗回復を、不変の10分期限で監視する。
    引数: base(list[dict])は197固定源,maps/contexts(dict)。
    返り値: tuple[dict,dict]はq0別出生と監視診断。未確認の源を強制発火しない。
    """
    result={};scene=None;state=None;counts=defaultdict(int)
    for item in base:
        key=(item['session'],item['time'],item['line']);t=item['time'];birth=None
        if item['session']!=scene:state=None;scene=item['session']
        if item['band']=='DAY':result[key]=None;continue
        side=item['signals'][12]
        if state is not None and (t>state['expiry'] or item['band']!=state['band']):state=None;counts['失効']+=1
        if state is not None:
            row=maps[state['form']].get(key)
            if side:counts['後発源無視']+=1
            if row is not None and recover(state,row,item['extra']):
                birth={k:v for k,v in state.items() if k not in ('armed','recovered_at')};birth.update(confirmed=t,entry_side=state['native'],source_actual=state['side'])
                state=None;counts['元側回復発火']+=1
        elif side:
            ro=maps[0].get(key);row=ro if ro is not None else maps[1].get(key);form=0 if ro is not None else 1
            native=P.B.native(row,contexts[form][key],item['extra'],1);assert native!=0
            seed=P.make_seed(row,side,native,1);seed['form']=form
            if not seed['reverse']:
                birth={k:v for k,v in seed.items() if k!='armed'};birth.update(confirmed=t,entry_side=side,source_actual=side);counts['元順行即時']+=1
            else:
                seed['broken_at']=t if broken(seed,row) else None;seed['recovered_at']=None;state=seed;counts['監視開始']+=1
        result[key]=birth
    return result,dict(counts)


def prepare():
    """
    機能: 6入口×3幅を当初81場だけで生成し、金融前に固定する。
    引数: なし。
    返り値: None。200の旧81/追加2を変更せず、追加2は探索へ混ぜない。
    """
    pure200=read(ROOT/'inputs/00200_TOPIXの観測被覆と時間順入口/純入口.json.gz');base=read(ROOT/'inputs/00197_TOPIXの一因子比較の純入口/純入口.json.gz')
    features={f:read(ROOT/'inputs/TOPIX原順8列_20260921_20261116'/n) for f,n in enumerate(('純特徴183.json.gz','純特徴184直接.json.gz'))}
    maps={f:{(r['session'],r['time'],r['line']):r for r in rows} for f,rows in features.items()};contexts={f:P.B.context_rows(rows) for f,rows in features.items()}
    recovered,diagnostics=recoveries(base,maps,contexts);result=[]
    for item in pure200:
        key=(item['session'],item['time'],item['line']);signals=[];widths=[];origins=[];births=[]
        candidates=[item['births'][0],item['births'][9],item['births'][10],item['births'][10],item['births'][10],recovered[key]]
        for i,birth in enumerate(candidates):
            row=maps[birth['form']][key] if birth is not None else None
            if birth is not None and i in (3,4):
                source=maps[birth['form']][(item['session'],birth['time'],birth['line'])]
                if not bounded_progress(birth,row,source,.5 if i==3 else 1.):birth=None
            for width_key in WIDTHS:
                if item['band']=='DAY':side=item['signals'][0];width=item['widths'][0];stored=None;origin='旧190D4固定'
                else:
                    side=(birth.get('entry_side',birth['side']) if birth else 0)
                    width=float(width_key[1:]) if width_key.startswith('W') else P.B.P.U.width(row,width_key) if row is not None else None
                    stored=dict(birth,entry_side=side,source_actual=birth.get('source_actual',birth['side'])) if birth else None;origin=ENTRIES[i]+'_'+width_key
                signals.append(side);widths.append(width);origins.append(origin);births.append(stored)
        assert signals[0]==item['signals'][0] and widths[0]==item['widths'][0]
        result.append({'session':key[0],'time':key[1],'line':key[2],'band':item['band'],'signals':signals,'widths':widths,'origins':origins,'births':births,'extra':item['extra']})
    M.save(HERE/'純入口.json.gz',result)
    sources=[Path(__file__),ROOT/'work/200TOPIX/入口200.py',ROOT/'work/197TOPIX/入口197.py',ROOT/'work/192TOPIX/入口192.py',ROOT/'work/186TOPIX/入口186.py',M.HERE/'入口とIFD.py']
    cfg={'試行':202,'候補':list(NAMES),'規模':18,'入口':list(ENTRIES),'Night幅':list(WIDTHS),'情報区分':'200の全83診断後の仮説。純探索・金融は旧81だけ。追加2は既使用。',
        '同幅対照':'各入口をW15/W10/A25それぞれで再生。幅変更で枠解放と後続取得も再計算し、独立建玉合算にしない。Day旧190D4は固定。',
        '位置':'200N10の純出生を固定し、実反転確認だけ源終値から実側に0<進行<=0.5又は1.0源ATRで限定。元順行即時は保持。確認時q0終値を用い、未来の実取得価格では選ばない。',
        '回復':'197和集合QFを源に、旧実側の前3本端破断→元側へ端を回復→次の連続1分q0でも保持、元側MACD又はRSI増分正、量>=0.5で元側へ入る。源時点の破断が既知なら破断済みで開始してよいが同q0に回復/発火しない。',
        '不変源':'元側/旧実側・形成・端・源から600秒期限は固定。後発源で期限延長なし、帯境界で失効、同源一度。保有枠は確認監視とは別。逆側損益を1-pで推計せず実BBOを再生。',
        '比較履歴':'186にもW10/W15/A15/A25比較がある。202は200で固定した時間順確認入口と新しい失敗回復を同幅対照で調べる別仮説。',
        '幅':'Night W15/W10はTOPIXpt、A25は確認q0の選択形成ATR5×2.5を5〜25ptで0.25切上げ。取得後変更なし。H60全案固定。',
        '品質':'200の過去被覆を新規棄却には用いない。旧P0/形成/量の品質条件は保持。未来の返済時計不足で入口を選別しない。',
        '金融':'単純IFD・保有予約合計1・開始待機なし・終了15分前。miniTOPIX片道41.8円+0.25pt、未知枠は場末保持。',
        'Source':{p.relative_to(ROOT).as_posix():M.sha(p) for p in sources},'純入口SHA':M.sha(HERE/'純入口.json.gz'),
        '母体SHA':{str(p.relative_to(ROOT)):M.sha(p) for p in (ROOT/'inputs/00200_TOPIXの観測被覆と時間順入口/純入口.json.gz',ROOT/'inputs/00197_TOPIXの一因子比較の純入口/純入口.json.gz')}}
    assert not (HERE/'条件.json').exists();M.save(HERE/'条件.json',cfg)
    M.save(HERE/'純成立診断.json',{'q0':len(result),'回復監視':diagnostics,'Night純成立':{name:sum(r['signals'][i]!=0 for r in result if r['band']!='DAY') for i,name in enumerate(NAMES)}})
    print(json.dumps({'純q0':len(result),'候補':18,'純入口SHA':cfg['純入口SHA'],'回復監視':diagnostics},ensure_ascii=False),flush=True)


if __name__=='__main__':prepare()
