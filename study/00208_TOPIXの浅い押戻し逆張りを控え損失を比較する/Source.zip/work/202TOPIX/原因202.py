"""同じ入口の幅変更と、新しい元側回復自身の寄与を分ける。"""
from collections import defaultdict,Counter
import sys,json
import 入口202 as E
sys.path.insert(0,str(E.ROOT/'work/196TOPIX'))
from 原因196 import summarize


def describe(ledger,indices):
    """
    機能: 実取得群の既知損益・費用前寄与・F/A/N/Cをまとめる。
    引数: ledger(dict),indices(list[int])。
    返り値: dict。未取得の仮想利益は評価しない。
    """
    result=summarize(ledger,indices);count=Counter(ledger['label'][i] for i in indices);result['FANC']=dict(count)
    result['到達済み順行率']=count['F']/(count['F']+count['A']) if count['F']+count['A'] else None
    result['費用前円']=sum(ledger['gross_pt'][i]*1000 for i in indices if ledger['known'][i]);return result


def main():
    """
    機能: 18口座の枝・期限・幅変更に伴う取得枠を事後分解する。
    引数: なし。
    返り値: None。採用候補への置換は行わない。
    """
    data=E.read(E.HERE/'全18組安定性.json.gz');pure={(r['session'],r['time'],r['line']):r for r in E.read(E.HERE/'純入口.json.gz')};packs=[];results=[]
    for ci,state in enumerate(data['metrics']):
        pack=E.read(E.HERE/'金融正本'/(state['id']+'.json.gz'));packs.append(pack);ledger=pack['ledger'];groups=defaultdict(list)
        for i,scene in enumerate(ledger['scene']):
            if 'Night' not in scene:continue
            key=(scene,ledger['request_time'][i],ledger['request_line'][i]);birth=pure[key]['births'][ci]
            family='失敗後元側回復' if ci>=15 and birth['reverse'] else '実反転確認' if birth['reverse'] and birth['confirmed']>birth['time'] else '実反転即時' if birth['reverse'] else '元順行即時'
            for name in ('全体',family,family+'/'+ledger['reason'][i],'帯/'+str(ledger['phase'][i])):groups[name].append(i)
        results.append({'index':ci,'id':pack['id'],'群':{name:describe(ledger,indices) for name,indices in groups.items()}})
    pairs=[]
    for entry in range(6):
        base=entry*3;old=packs[base]['ledger'];oldmap={(s,old['request_time'][i],old['request_line'][i],old['side'][i]):i for i,s in enumerate(old['scene']) if 'Night' in s}
        for other in (base+1,base+2):
            new=packs[other]['ledger'];newmap={(s,new['request_time'][i],new['request_line'][i],new['side'][i]):i for i,s in enumerate(new['scene']) if 'Night' in s}
            common=set(oldmap)&set(newmap);lost=set(oldmap)-set(newmap);added=set(newmap)-set(oldmap)
            pairs.append({'15ptindex':base,'比較index':other,'共通取得15pt':describe(old,[oldmap[k] for k in sorted(common)]),'共通取得比較':describe(new,[newmap[k] for k in sorted(common)]),
                '15pt口座だけ実取得':describe(old,[oldmap[k] for k in sorted(lost)]),'比較口座だけ実取得':describe(new,[newmap[k] for k in sorted(added)])})
    E.M.save(E.HERE/'原因診断.json',{'区分':'旧81の固定金融の事後分解。元側回復の希少件数と既存即時の枠効果を区別。','候補':results,'同一入口の幅と枠':pairs,'SourceSHA':E.M.sha(E.HERE/'原因202.py')})
    E.M.save(E.HERE/'固定選択.json',{'全体採用':None,'理由':'新案に両中央値/参加/未知の共同適合なし。損失減の部分参考と採用を区別。','旧81固定順位':{k:v[:1] for k,v in data['順位'].items()},
        '板201へ新規追加する候補':[],'条件SHA':E.M.sha(E.HERE/'条件.json'),'純入口SHA':E.M.sha(E.HERE/'純入口.json.gz')})
    for row in results:
        if row['index'] in (6,7,8,9,15):print(json.dumps(row,ensure_ascii=False),flush=True)


if __name__=='__main__':main()
