"""203の独立した順行・転換の時系列比較を固定履歴として保存する。"""
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work/203TOPIX'))
import 入口203 as E
sys.path.insert(0,str(ROOT/'work/196TOPIX'))
from 正式化196 import row_text
TRIAL=ROOT/'study/00203_TOPIXの長期支持と中期転換を独立に確認する'
INPUT=ROOT/'inputs/00203_TOPIXの長期支持と転換の純入口'


def ref(path: Path) -> dict:
    """
    機能: 正式保存物の位置・容量・内容指紋を記録する。
    引数: path(Path)。
    返り値: dictは相対path・bytes・sha256。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


# ----------------------------------------
def main() -> None:
    """
    機能: 28口座と段階診断・567セル・Sourceを恒久保存する。
    引数: なし。
    返り値: None。203の金融・閾値・純条件を変更しない。
    """
    TRIAL.mkdir(parents=True,exist_ok=True);INPUT.mkdir(parents=True,exist_ok=True)
    proof=E.read(E.HERE/'独立確認.json');assert proof['成功'] and proof['候補']==28
    for name in ('条件.json','人工確認.json','金融開始前固定.json','純成立診断.json','旧対照同体.json',
                 '全28組安定性.json.gz','全28組短表.json.gz','独立確認.json','原因診断.json','固定選択.json','起動修正.json'):
        shutil.copy2(E.HERE/name,TRIAL/name)
    shutil.copy2(E.HERE/'純入口.json.gz',INPUT/'純入口.json.gz')
    manifest={'試行':203,'純出生':ref(INPUT/'純入口.json.gz'),'条件':ref(TRIAL/'条件.json'),
              '原板':'inputs/TOPIX原順8列_20260921_20261116/台帳.json','母体':'inputs/00200_TOPIXの観測被覆と時間順入口/入力台帳.json'}
    (INPUT/'入力台帳.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (INPUT/'README.md').write_text('# 203 TOPIXの独立役割入口\n\n[研究正本](../../study/00203_TOPIXの長期支持と中期転換を独立に確認する/README.md)。旧81場・34,424q0、28口座の金融前純出生。旧/直接形成の順行・転換・統合を独立に出生し、源から全段階20分を固定する。原板本体は共用入力を参照し複製しない。追加2場は本探索に入力していない。\n',encoding='utf-8')
    previous=E.read(ROOT/'study/00202_TOPIXの確認位置と元側回復を幅別に比較する/Source索引.json')
    sources=[ROOT/r['path'] for r in previous]+list(E.HERE.rglob('*.py'))+[Path(__file__)]
    sources += [E.M.HERE/'入力台帳.json',E.M.HERE/'条件_実装修正1.json']
    sources += [p for p in (E.HERE/'起動修正前').iterdir() if p.is_file()]
    sources=sorted(set(sources))
    with zipfile.ZipFile(TRIAL/'Source.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for path in sources:archive.write(path,path.relative_to(ROOT).as_posix())
    (TRIAL/'Source索引.json').write_text(json.dumps([ref(p) for p in sources],ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    template=ROOT/'docs/議論/手法と時間スケールの汎用表_版8.md'
    body=template.read_text(encoding='utf-8').split('## 設定明細')[0]
    body=body.replace('# 手法と時間スケールの汎用表・版8','# 203 設定と結果・版8').replace('全セルは未設定・未検証。','使用セルをS1〜S4/R203へ接続する。')
    used={'I01':{3:'S1源EMA8固定',4:'S1中期回復',5:'S1長期並び/傾き'},'I02':{4:'S2押戻し−1.5〜−0.1ATR15'},
        'I03':{5:'S1旧方向の失速'},'I04':{3:'旧対照のみ'},'I08':{3:'旧対照',4:'旧対照',5:'旧対照'},
        'I09':{3:'S2保持尺度/固定A25',4:'S2押戻し尺度'},'C01':{3:'旧対照',4:'旧対照'},
        'C07':{1:'S1段階の保持',3:'S1短期回復',4:'S1中期押戻し/回復',5:'S1長期支持/失速'},
        'P01':{1:'S3実体/反対端'},'P05':{1:'S3回復→保持'},'P06':{1:'S1出生固定水準'},'P07':{1:'S1次q0保持'},
        'V01':{0:'S4累積量時計',1:'S4相対量0.5/3中2',3:'S4不明時量補完'},
        'B01':{0:'正常BBO・spread1.5上限'},'E01':{0:'R203 W15/A25単純IFD'},'E02':{0:'R203 SL/H60/終了'}}
    lines=[];count=0
    for line in body.splitlines():
        cells=[c.strip() for c in line.split('|')[1:-1]] if line.startswith('|') else []
        if len(cells)==11 and re.fullmatch('[A-Z][0-9]{2}',cells[0]):
            count+=1;cells[2:]=[used.get(cells[0],{}).get(i,'未使用') for i in range(9)];line='| '+' | '.join(cells)+' |'
        lines.append(line)
    assert count==63
    body='\n'.join(lines)+'\n';body=re.sub(r'\]\(([^)]+)\)',lambda m:']('+os.path.relpath((template.parent/m.group(1)).resolve(),TRIAL).replace('\\','/')+')',body)
    body+='''
## 設定明細と複合評価

S1は[金融前条件](条件.json)の独立T/R/M。Tは長期のEMA並び・傾きの支持から、中期EMA8への押戻しと源5分EMA8の短期回復→次q0保持を確認する。Rは旧長期MACDの失速後、次の異なる公表15分足が固定した源EMA8を新側へ回復し、その後の5分固定水準回復→次q0保持を要求。15分足はcount+1/end+900、公表が源後かつ当時以前。源から全段階合計20分、後から期限を延ばさない。

S2は源時に固定した価格/ATR15と当時ATR5の尺度。S3は連続q0が30〜90秒、終値が同側、足の反対端が0.1ATR以内、発火時spread<=1.5・1分幅<=2.5ATR・live実側>=−0.25ATR。S4は1分相対量を優先し不明時だけ5分量。単独>=0.5対、連続3q0中2つ>=0.5かつ最新既知>0。未知を0へ補完しない。新案は短期RSI/MACDを一律ANDにしていない。旧対照は当時条件を維持。

R203は旧/直接形成×順行/転換/統合×量2×Night幅2と旧2母体×幅2の28口座。Day旧190D4固定、NightW15又は当時ATR5×2.5（5〜25pt・0.25切上げ）。H60単純IFD・保有予約1・終了15分前。miniTOPIX1枚・往復583.6円。幅ごとに後続枠も再計算する。

新案は参加と両中央値を満たさず採用しない。長期失速とEMA8回復だけでは転換を十分識別できなかった。[結果](README.md)・[全28正本](全28組安定性.json.gz)。複合結果を個別指標の効果とはしない。全63×9=567セル。元表SHA256: '''+ref(template)['sha256']+'。\n'
    (TRIAL/'設定と結果.md').write_text(body,encoding='utf-8')
    states=E.read(E.HERE/'全28組安定性.json.gz')['metrics']
    table='| index | 取得 / 参加場 | 保有下限 | 未知 | 利益円 | 損失円 | 既知収支円 | 建玉 / 場中央値下限円 | 場末DD円 |\n|---|---:|---:|---:|---:|---:|---:|---:|---:|\n'
    table+='\n'.join(row_text(i,'NIGHT',states) for i in range(28))+'\n'
    report='''# 203 TOPIXの長期支持と中期転換を独立に確認する

2026-11-18。**新案は採用しない。長期の失速と中期EMA8回復を、大きな方向転換と読む根拠が不足した。** 短期指標の同時ANDを増やす代わりに、長期→中期→短期の時系列を独立に比較したが、参加・両中央値・損失安定性の共同改善には至らなかった。原因を調べ、反対BBOと役割の区別を次へ進める。

## 固定比較と入力

新案は旧P0の源や旧費用境界を使わず、長期支持→押戻し→短期回復と、長期失速→次の中期足での回復を別々に出生。旧/直接形成×3役割×量2×幅2と4対照の28口座。[条件](条件.json)・[純段階件数](純成立診断.json)・[設定と結果](設定と結果.md)。当初81場は全て既使用で、全80/前48/後25/追加7/最終1を区別する。追加2は本探索に入力していない。

単純IFD。Day旧190D4固定、NightW15又はA25（当時ATR5×2.5、5〜25pt・0.25切上げ）、H60。保有/予約1・開始待機なし・15:30/05:45まで。miniTOPIX1枚、1pt1,000円、片道41.8円＋0.25pt。ラージBBO代用。金融未知を0円にせず枠は場末保持、0取得場を中央値から落とさない。

## Night全28結果

index0〜3は旧190/共通P0元側の各W15/A25。4〜15は旧形成、16〜27は直接形成。各形成内は順行・転換・統合の順、各役割は量単独W15/A25・量2/3継続W15/A25。Dayは全28で旧190同体。

'''+table+'''
直接統合×量単独W15（24）は83取得/37 of40場・保有14.27%・未知4、利益199,742.8/損失357,347.2/既知収支−157,604.4円。直接順行（16）は62取得/32場・保有10.90%・収支−6,432.4円、後25黒字でも追加7は−40,918円。直接転換（20）は47取得/32場・保有7.89%・収支−160,845.6円、2F/8A/36N/1C。到達10件だけを精密な確率推定に使わない。

## 失速と転換の違い

[原因診断](原因診断.json)では、転換47取得の45件で旧30分EMA方向が残り、40件で価格が旧側30EMA21を保持、44件で15分EMA並びが旧側だった。MACD増分の反転は長期の勢いの弱まりを示しても、新方向の持続を証明しない。新15DI/傾きが新側の11件も全て既知赤字なので、そこへANDを追加すれば解決するという根拠もない。

直接順行は448源→210保持確認→79純発火、直接転換は356源→84中期確認→54純発火。量2/3継続も改善しなかった。要求成立と保有枠内の取得は別に集計する。次は逆行の多い転換を同時点の反対BBOで診断し、旧長期支持が残る押戻しと新方向成立の区別を新仮説へする。反対確率を1−pから推定しない。

## 検査と再現

[人工確認](人工確認.json)25,750項目、[独立確認](独立確認.json)7,647取得・金融99,411属性・別算術90,216属性・全q0枠74,008件が一致。旧対照の取得価格と台帳も同体。Sourceと純出生は金融前に封印。

初回の実行器で試行番号の文字列置換が入力年2026へ作用したため、金融0件の起動段階で停止した。入力パスだけ訂正し、入口/条件/純出生は不変。[起動修正](起動修正.json)と旧Source/封印をSource.zip内の起動修正前へ保存。最終の正しい入力で金融と独立監査を完了した。

[Source](Source.zip)・[索引](Source索引.json)・[恒久純入口](../../inputs/00203_TOPIXの長期支持と転換の純入口/README.md)。Python3.14.3/NumPy2.5.4/tzdata2026.6。[共通再現ツール](../../scripts/TOPIX入口研究/README.md)の `固定純入口を再生.py 203` で新しい作業コピーから全28金融の集計SHAを照合する。原板は共用入力を参照し複製しない。今回の未採用結果を固定し、条件変更は新試行へ分離する。
'''
    (TRIAL/'README.md').write_text(report,encoding='utf-8')
    print(json.dumps({'正式保存':203,'口座':28,'汎用表':567,'Source':len(sources)},ensure_ascii=False))


# ----------------------------------------
if __name__=='__main__':main()
