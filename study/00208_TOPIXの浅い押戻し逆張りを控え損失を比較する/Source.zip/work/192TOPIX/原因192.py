"""192の希少化・旧費用境界・未参加・期限損益を分解する。"""
from collections import Counter,defaultdict,deque
import json
import 入口192 as E


def amount(values):
    """
    機能: 確定損益と未知を分けて件数・利益損失を集計する。
    引数: values(list[float|None])。
    返り値: dictは実現済みの既知寄与。
    """
    known=[v for v in values if v is not None]
    return {'件数':len(values),'未知':len(values)-len(known),'利益':sum(max(v,0) for v in known),
        '損失':sum(max(-v,0) for v in known),'既知収支':sum(known)}


def stages(row,context,extra):
    """
    機能: T緩条件の逐次遮断位置を、金融と独立に数える。
    引数: row/context/extra(dict)。
    返り値: dict[str,bool]は段階条件の累積通過。方向は両側を含む。
    """
    result=Counter();m=row['m5'];mid=row['m15'];long=row['m30'];a=row['atr'];h=context['history']
    quantity=extra['rvol5'] is not None and extra['rvol5']>=.5
    for side in (1,-1):
        labels=[]
        labels.append(('量既知と0.5以上',quantity))
        labels.append(('費用比と足幅と進行', (row['spread']+.5836)/a<=.5 and row['range']<=2 and row['live'] is not None and side*row['live']>=-.25))
        coherent=len(h)==3 and all(h[i]['end']-h[i-1]['end']==300 for i in (1,2))
        labels.append(('3つの5分足連続',coherent))
        labels.append(('5分方向2本持続',coherent and sum(side*p['di']>0 and side*(p['ema8']-p['ema21'])>0 for p in h)>=2))
        aligned=long is not None and all(side*(p['slope'] or 0)>0 and side*p['di']>0 and side*(p['ema8']-p['ema21'])>0 for p in (m,mid,long))
        labels.append(('三足の傾きDI並び',aligned))
        labels.append(('ADX18以上とEMA差0.15ATR',m['adx']>=18 and abs(m['ema8']-m['ema21'])/a>=.15))
        labels.append(('価格20分観測可',extra['range_known']))
        labels.append(('価格効率0.12以上',extra['range_known'] and extra['er20']>=.12))
        dist=side*(row['close']-m['ema8'])/a;rsi=m['rsi'] if side>0 else 100-m['rsi']
        labels.append(('取得位置とRSI',-.5<=dist<=1.25 and 35<=rsi<=75))
        labels.append(('1分順行と動力回復',side*row['body']>0 and side*row['progress']>0 and side*(m['hist_delta'] or 0)>=0 and side*(m['rsi_delta'] or 0)>=0))
        labels.append(('終値位置0.55以上',(row['position'] if side>0 else 1-row['position'])>=.55))
        passed=True
        for label,ok in labels:
            passed=passed and ok
            if passed:result[label]+=1
        assert passed==E.side_roles(row,side,context,False,extra,extra['rvol5'])[0]
    return result


def main():
    """
    機能: 同体固定後の原因診断を生成する。新しい入口条件へ遡及適用しない。
    引数: なし。
    返り値: None。
    """
    pure=E.read(E.HERE/'純入口.json.gz');index={(r['session'],r['time'],r['line']):r for r in pure}
    features={form:E.read(E.ROOT/'inputs/TOPIX原順8列_20260921_20261116'/name) for form,name in enumerate(('純特徴183.json.gz','純特徴184直接.json.gz'))}
    counters={};miss_detail={};short=E.read(E.HERE/'全73組短表.json.gz')['rows']
    for form,rows in features.items():
        history=deque(maxlen=3);previous=None;ident=None;scene=None;out=defaultdict(Counter)
        for row in rows:
            if row['session']!=scene:history.clear();previous=None;ident=None;scene=row['session']
            current=tuple(row['m5'][k] for k in ('count','end','published'))
            if current!=ident:history.append(row['m5']);ident=current
            context={'history':list(history),'previous':previous};key=(scene,row['time'],row['line']);ex=index[key]['extra']
            out[row['band']]['q0']+=1;out[row['band']].update(stages(row,context,ex))
            if scene in ('2026-09-21_Day','2026-09-22_Day','2026-09-23_Day','2026-10-12_Day'):
                c=miss_detail.setdefault(str(form)+':'+scene,Counter());c['q0']+=1;c['量1既知']+=row['rvol'] is not None;c['量5既知']+=ex['quantity_known']
                c['P0厳1分成立']+=E.signals(row,context,ex,True,0)[0]!=0;c['P0厳5分成立']+=E.signals(row,context,ex,True,1)[0]!=0
            previous=row
        counters[str(form)]={band:dict(v) for band,v in out.items()}
    # ----------------------------------------
    # 旧方向切替だけの仮想費用感応。価格・ATR・元P0を固定し、損益は再生成しない。
    q189=E.read(E.ROOT/'work/189TOPIX/純入口.json.gz');fmap={form:{(r['session'],r['time'],r['line']):r for r in rows} for form,rows in features.items()}
    sensitive=[]
    for form,rows in q189.items():
        posts=[r for r in rows if r['band']=='POST' and r['signals'][0]]
        for fee in (0.,20.9,41.8,83.6,167.2):
            changed=0;total=len(posts)
            for row in posts:
                key=(row['session'],row['time'],row['line']);fr=fmap[int(form)][key];native=row['signals'][0]
                current=-native if (fr['spread']+.5836)/fr['atr']>.25 else native
                adjusted=-native if (fr['spread']+.5+2*fee/1000)/fr['atr']>.25 else native
                changed+=current!=adjusted
            sensitive.append({'形成':int(form),'片道仮想手数料円':fee,'POST元P0成立数':total,'方向が変わる要求数':changed,'金融再生':False})
    # ----------------------------------------
    # 順行/反転の実取得は、先着と期限、費用前と費用後を別集計する。
    paths={};groups=[]
    for ci in (0,1,4,7,10,37,40,43,46):
        name=E.NAMES[ci];path=E.HERE/'金融正本'/('TOPIX192_'+name+'_DayA25_NightW15_H60.json.gz')
        pack=E.read(path);z=pack['ledger'];by=defaultdict(list);gross=defaultdict(list)
        for n,phase in enumerate(z['phase']):
            key=(('DAY','PRE','POST')[phase],z['reason'][n]);by[key].append(z['net'][n])
            gross[key].append(None if z['gross_pt'][n] is None else z['gross_pt'][n]*1000)
        for key,values in by.items():groups.append({'candidate':name,'帯':key[0],'決済':key[1],'費用後':amount(values),'費用前':amount(gross[key])})
    payload={'希少化の段階_T緩Q5':counters,'旧P0厳の未参加4場':{k:dict(v) for k,v in miss_detail.items()},
        '同じ価格での旧費用方向感応':sensitive,'順反の帯別と期限損益':groups,
        '結論':'三足整合と受容等の全ANDは希少化。費用変更だけで方向が動く事実と、ATRが市場局面代理である可能性を分ける。新条件の結果とはしない。'}
    E.M.save(E.HERE/'原因診断.json',payload);print(json.dumps({'診断完了':True,'帯別決済群':len(groups),'費用感応':sensitive},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
