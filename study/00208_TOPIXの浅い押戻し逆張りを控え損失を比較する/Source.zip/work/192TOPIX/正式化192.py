"""192の固定結果・純出生・Sourceを恒久保存する。"""
from pathlib import Path
import json,hashlib,zipfile,shutil,re,os
import 入口192 as E

TRIAL=E.ROOT/'study/00192_TOPIXの価格構造と数量尺度で方向を判別する'
INPUT=E.ROOT/'inputs/00192_TOPIXの構造と数量の純入口'


def ref(path):
    """
    機能: 保存資源の相対パスと内容指紋を得る。
    引数: path(Path)。
    返り値: dictはpath/bytes/SHA256。
    """
    return {'path':path.relative_to(E.ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':E.M.sha(path)}


def main():
    """
    機能: 未採用の新73比較を固定し、567セル表と再現用入力を保存する。
    引数: なし。
    返り値: None。旧試行と新金融の閾値を変更しない。
    """
    TRIAL.mkdir(parents=True,exist_ok=True);INPUT.mkdir(parents=True,exist_ok=True)
    files=('条件.json','人工確認.json','金融開始前固定.json','純成立診断.json','旧対照同体.json',
        '全73組安定性.json.gz','全73組短表.json.gz','独立確認.json','原因診断.json','追加二場前の固定選択.json')
    for name in files:shutil.copy2(E.HERE/name,TRIAL/name)
    shutil.copy2(E.HERE/'純入口.json.gz',INPUT/'純入口.json.gz')
    baseline=E.ROOT/'work/190TOPIX/金融正本/TOPIX190_D4_量不明でも動力改善_N01_共通q0の旧_DayA25_NightW15_H60.json.gz'
    shutil.copy2(baseline,INPUT/'旧190固定対照.json.gz')
    # 生成入力からの金融再生を固定。純出生自体の由来は条件と親試行Sourceを参照する。
    manifest={'試行':192,'用途':'封印済み73候補の純出生と旧金融同体検査用台帳。原板の複製ではない。',
        '純出生':ref(INPUT/'純入口.json.gz'),'旧対照':ref(INPUT/'旧190固定対照.json.gz'),'条件':ref(TRIAL/'条件.json')}
    (INPUT/'入力台帳.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (INPUT/'README.md').write_text('# TOPIX 192の固定純入口\n\n[研究正本](../../study/00192_TOPIXの価格構造と数量尺度で方向を判別する/README.md)。全81場、q0和集合34,424件、73条件。条件のSourceSHAと純出生SHAを固定。旧190対照台帳は追加禁止の同体検査にだけ用いる。量不明を0にせず、方向・幅は当時特徴で生成済み。\n',encoding='utf-8')
    sources=list(E.HERE.glob('*.py'))+[E.ROOT/p for p in (
        'work/186TOPIX/入口186.py','work/183TOPIX/入口とIFD.py','work/183TOPIX/金融を比較する.py',
        'work/183TOPIX/人工検査.py','work/186TOPIX/人工確認186.py',
        'work/183損失安定性/安定性183.py','work/183損失安定性/TOPIXを独立検算する.py','work/183損失安定性/新候補の集計を独立検査する.py',
        'scripts/入口分析/分析.py','scripts/複合検証/再生.py','study/00001_MACDと方向条件の比較/再現.py')]
    sources=sorted(set(sources))
    with zipfile.ZipFile(TRIAL/'Source.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in sources:z.write(p,p.relative_to(E.ROOT).as_posix())
        for name in ('入力台帳.json','条件_実装修正1.json'):
            p=E.M.HERE/name;z.write(p,p.relative_to(E.ROOT).as_posix())
    (TRIAL/'Source索引.json').write_text(json.dumps([ref(p) for p in sources],ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    template=E.ROOT/'docs/議論/手法と時間スケールの汎用表_版8.md'
    body=template.read_text(encoding='utf-8').split('## 設定明細')[0]
    body=body.replace('# 手法と時間スケールの汎用表・版8','# 192 TOPIX・設定と結果（版8）').replace('全セルは未設定・未検証。','使用したセルへ設定IDを付ける。').replace('未設定・未検証','未使用')
    used={'I01':{3:'S1 EMA8/21持続',4:'S1 中期背景',5:'S1 長期背景'},'I02':{3:'S2 取得位置/ATR'},
        'I03':{3:'S3 MACD12/26/9・増分',5:'S3 長期失速'},'I04':{3:'S3 RSI14・増分',5:'S3 長期失速'},
        'I08':{3:'S4 DI/ADX14',4:'S4 中期DI/ADX',5:'S4 長期DI/ADX'},'I09':{3:'S5 q0ATR14幅'},
        'I17':{1:'S6 固定1分端点20分ER'},'C01':{3:'S1〜S4動力',4:'S1/S4',5:'S1/S3/S4'},
        'C04':{3:'S4局面',4:'S4局面',5:'S4局面'},'C07':{1:'S7発動',3:'S1〜S5',4:'S1/S4',5:'S1/S3/S4'},
        'P01':{1:'S7 実体/位置/足幅'},'P05':{1:'S7 進行'},'P06':{0:'S6 原観測20分高低'},
        'P07':{1:'S7 固定端回復と翌足受容'},'P09':{1:'S7 端接触から回復'},
        'V01':{0:'S8 累積量端点と時計',1:'S8 旧相対量20分',3:'S8 5分量/前4窓'},
        'B01':{0:'S9 正常BBO・費用比可否'},'B02':{0:'正常数量の品質のみ、偏り未使用'},
        'E01':{0:'R1 単純同幅IFD'},'E02':{0:'R1 固定SLと終了、追尾なし'}}
    count=0;lines=[]
    for line in body.splitlines():
        cells=[x.strip() for x in line.strip().strip('|').split('|')] if line.startswith('|') else []
        if len(cells)==11 and re.fullmatch(r'[A-Z][0-9]{2}',cells[0]):
            count+=1
            for i in range(9):cells[i+2]=used.get(cells[0],{}).get(i,'未使用')
            line='| '+' | '.join(cells)+' |'
        lines.append(line)
    assert count==63
    body='\n'.join(lines)+'\n';body=re.sub(r'\]\(([^)]+)\)',lambda m:']('+os.path.relpath((template.parent/m.group(1)).resolve(),TRIAL).replace('\\','/')+')',body)
    body+='''
## 設定明細・複合評価

S1〜S5は183旧/184直接形成の公表済み5/15/30分。3つの異なる5分足の持続を求め、同じ足を重複しない。C0/C1は186 P0順行/実側反転の診断対照。Tは三足EMA傾き・並び・DI、ADX18/22以上、EMA差0.15/0.25ATR以上、ER0.12/0.2、位置−0.5〜1.25/0.75ATR、RSI35〜75と動力回復。Rは低ADXだけでなく20分端の接触後回復と低ER。Xは中長期への戻り又は長期失速を伴う新突破。全定数は[条件](条件.json)とSourceへ固定。個別指標だけの成績ではない。

S6はq0直前1分を除く20分の原順観測価格高低と、同窓21固定1分端点ER。端点30秒以内、原価格空白90秒以内。真の連続全約定経路ではない。S7は当時の1分実体/進行/終値位置と、前q0の固定3本端を翌連続1分でも保持する受容。連続30〜90秒、許容戻り緩0.1ATR/厳0。

S8は旧1分量、原累積5分量（現在5分÷前4窓）、1分不明時だけ5分量の3比較。5分量の全端点は価格/量時計が境界30秒内、q0原行以前。窓中の累積減少・量時計後退・90秒空白は不明。既知0と不明を区別する。S9の費用比上限は緩0.5/厳0.4で取引可否にのみ使い、方向を変えない。

R1は73口座。Day各形成q0ATR5×2.5（5〜25pt/0.25切上げ）、Night15pt、H60の単純IFD。旧190対照は当時の幅・方向を保持。miniTOPIX1枚・片道41.8円+0.25pt、保有予約合計1、開始待機なし、終了15分前まで。未知を0円にせず枠は場末保持。新案の共同適合は0、旧対照同体。結果と期間差は[README](README.md)・[全73正本](全73組安定性.json.gz)。

## 再現と版

[Source](Source.zip)・[索引](Source索引.json)・[純入口入力](../../inputs/00192_TOPIXの構造と数量の純入口/入力台帳.json)。全81場既使用。追加2場前の選択は[固定記録](追加二場前の固定選択.json)。版8の63手法×9尺度=567セル。未使用は無効との判断ではない。
'''
    body+='\n汎用表SHA256: '+hashlib.sha256(template.read_bytes()).hexdigest()+'\n'
    (TRIAL/'設定と結果.md').write_text(body,encoding='utf-8')
    print(json.dumps({'正式化':str(TRIAL),'表セル':count*9,'Source数':len(sources)},ensure_ascii=False))


if __name__=='__main__':main()
