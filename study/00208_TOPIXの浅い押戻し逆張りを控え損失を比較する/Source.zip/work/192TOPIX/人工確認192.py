"""192の量時計・端点構造・売買対称と固定対照を金融前に検査する。"""
from collections import deque
from copy import deepcopy
import json,sys
import numpy as np
import 入口192 as E
import 人工検査 as T
sys.path.insert(0,str(E.ROOT/'work/186TOPIX'))
from 人工確認186 import mirror_m


def mirror_extra(extra):
    """
    機能: 追加価格構造を鏡像へ移す。
    引数: extra(dict)。
    返り値: dictは同じ量・ERと反転した高低。
    """
    result=dict(extra)
    if extra['range_known']:
        result['range_low']=8000-extra['range_high'];result['range_high']=8000-extra['range_low']
    return result


def main():
    """
    機能: 人工因果時計と実特徴の鏡像を確認し、金融前証跡を保存する。
    引数: なし。
    返り値: None。
    """
    checks=0;scene='2026-09-21_Day';start=E.M.bounds(scene)[0]
    seconds=np.arange(0,3600,5,dtype=float);time=start+seconds
    data={'now':time,'line':np.arange(len(time))+1,'last':4000+seconds/600,'volume':seconds*2,'volume_time':time.copy()}
    keys=[(scene,start+t,int(t/5+1)) for t in (1800,2100,2400)]
    base=E.extra_for_scene(data,keys)
    for key,value in base.items():
        assert value['quantity_known'] and value['rvol5']==1 and value['volume5']==600
        assert value['range_known'] and abs(value['er20']-1)<1e-12;checks+=5
        cut=data['line']<=key[2];prefix={k:v[cut] for k,v in data.items()}
        assert E.extra_for_scene(prefix,[key])[key]==value;checks+=1
        changed={k:v.copy() for k,v in data.items()}
        for field in ('last','volume'):changed[field][~cut]+=100000
        assert E.extra_for_scene(changed,[key])[key]==value;checks+=1
    for mode in ('future','reset','clockback','missing','gap'):
        changed={k:v.copy() for k,v in data.items()}
        if mode=='future':changed['volume_time']+=60
        elif mode=='reset':changed['volume'][seconds>=1200]-=1000
        elif mode=='clockback':changed['volume_time'][seconds==1200]-=60
        elif mode=='missing':changed['volume'][seconds>=1700]=np.nan
        else:
            keep=~((seconds>900)&(seconds<1100));changed={k:v[keep] for k,v in changed.items()}
        value=E.extra_for_scene(changed,[keys[0]])[keys[0]]
        assert not value['quantity_known'],(mode,value);checks+=1
    zero={k:v.copy() for k,v in data.items()};zero['volume'][seconds>=1500]=3000
    value=E.extra_for_scene(zero,[keys[0]])[keys[0]]
    assert value['quantity_known'] and value['rvol5']==0 and value['volume5']==0;checks+=3
    # ----------------------------------------
    # 実特徴全体を間引いた検査。高低・RSI・DI・動力と長期不足も符号反転する。
    source={form:E.read(E.ROOT/'inputs/TOPIX原順8列_20260921_20261116'/name) for form,name in enumerate(('純特徴183.json.gz','純特徴184直接.json.gz'))}
    selected={(r['session'],r['time'],r['line']) for rows in source.values() for i,r in enumerate(rows) if i%31==0}
    extra=E.extras(selected)
    for rows in source.values():
        history=deque(maxlen=3);previous=None;ident=None;session=None
        for i,r in enumerate(rows):
            if r['session']!=session:history.clear();previous=None;ident=None;session=r['session']
            current=tuple(r['m5'][k] for k in ('count','end','published'))
            if current!=ident:history.append(r['m5']);ident=current
            if i%31==0:
                ctx={'history':list(history),'previous':previous};mirrored={'history':[mirror_m(p) for p in history],'previous':T.mirror(previous) if previous else None}
                ex=extra[(r['session'],r['time'],r['line'])]
                for strict in (False,True):
                    for q in range(3):
                        x=E.signals(r,ctx,ex,strict,q);y=E.signals(T.mirror(r),mirrored,mirror_extra(ex),strict,q)
                        assert x==[-v for v in y],(r['session'],i,x,y);checks+=6
            previous=r
    # ----------------------------------------
    # レンジ回復が単に低ADXだけで成立しないことと、既知0量は通らないことを確認。
    m={'count':26,'close':3998.4,'ema8':4000.,'ema21':4000.2,'slope':-.1,'hist':-.1,'hist_delta':.1,'rsi':40.,'rsi_delta':1.,
       'atr':3.,'adx':15.,'di':-.01,'bbz':-1.,'published':start+1800,'end':start+1800,'tr':3.}
    r={'session':scene,'time':start+1800,'line':361,'band':'DAY','atr':3.,'m5':m,'m15':m,'m30':None,'close':3998.4,
       'body':.1,'progress':.1,'position':.8,'range':.5,'live':0.,'spread':.5,'rvol':1.,'high':3998.5,'low':3998.,'prior_high':3999.,'prior_low':3997.8,'prior_close':3998.1}
    ex=dict(base[keys[0]],range_low=3998.,range_high=4002.,er20=.1)
    ctx={'history':[dict(m,end=start+1200),dict(m,end=start+1500),m],'previous':None}
    assert E.side_roles(r,1,ctx,False,ex,1.)[1];checks+=1
    moved=dict(r,low=3999.,close=3999.2)
    assert not E.side_roles(moved,1,ctx,False,ex,1.)[1];checks+=1
    assert not any(E.side_roles(r,1,ctx,False,ex,0.));checks+=1
    # ----------------------------------------
    # 時間軸の受容は同一公表足の複製で持続条件を満たさない。
    duplicate={'history':[m,m,m],'previous':None}
    assert not E.side_roles(r,1,duplicate,False,ex,1.)[0];checks+=1
    proof={'成功':True,'項目数':checks,'鏡像':True,'prefixと未来改変':True,'量未来時計':True,'窓中リセットと時計後退':True,
        '既知0量':True,'構造回復と低ADXを区別':True,'SourceSHA':E.M.sha(E.HERE/'入口192.py')}
    E.M.save(E.HERE/'人工確認.json',proof);print(json.dumps(proof,ensure_ascii=False),flush=True)


if __name__=='__main__':main()
