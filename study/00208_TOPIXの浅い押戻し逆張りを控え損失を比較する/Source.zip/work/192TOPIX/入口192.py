"""費用比の方向反転を外し、価格構造・複数足・量で入口を分ける。"""
from pathlib import Path
from collections import deque,Counter
from copy import deepcopy
import gzip,json,sys,math
import numpy as np

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
sys.path.insert(0,str(ROOT/'work/186TOPIX'))
import 入口186 as U
M=U.M
FAMILIES=('C0_P0順行','C1_P0実側反転','T0_持続と三足','R0_観測レンジ端回復','X0_混在から構造転換','M0_局面統合')
QUANTITIES=('Q1_1分相対量','Q5_5分端点相対量','QF_1分不明時5分')
SPECS=[{'form':form,'family':family,'strict':strict,'quantity':q,
        'name':f'F{form}_{FAMILIES[family]}_{"厳" if strict else "緩"}_{QUANTITIES[q]}'}
        for form in (0,1) for family in range(6) for strict in (False,True) for q in range(3)]
NAMES=('固定190_D4_N01',)+tuple(s['name'] for s in SPECS)


def read(path):
    """
    機能: 日本語JSON又はgzip JSONを読む。
    引数: path(Path)。
    返り値: objectは保存値。
    """
    return json.loads(gzip.decompress(path.read_bytes()) if path.suffix=='.gz' else path.read_bytes())


def extra_for_scene(data,keys):
    """
    機能: q0原行までの観測価格レンジ/固定1分端点ERと5分量比を計算する。
    引数: data(dict[str,np.ndarray])は原順8列、keys(list[tuple])は場/価格時計/原行。
    返り値: dict[tuple,dict]は当時特徴。未来行や未来の量時計を利用しない。
    """
    now=data['now'];line=data['line'];finite=np.isfinite(now)
    running=np.maximum.accumulate(np.where(finite,now,-np.inf));order=finite&(now>=running)
    price=order&np.isfinite(data['last'])&(data['last']>0)
    pt=now[price];pl=line[price];px=data['last'][price]
    amount=order&np.isfinite(data['volume'])&(data['volume']>=0)&np.isfinite(data['volume_time'])
    qt=now[amount];ql=line[amount];qv=data['volume'][amount];qvt=data['volume_time'][amount]
    visible=(qvt<=qt)&(qt-qvt<=30);qi=np.flatnonzero(visible);ut=qt[visible];ul=ql[visible]
    reset=np.r_[0,np.cumsum(np.diff(qv)<0)];back=np.r_[0,np.cumsum(np.diff(qvt)<0)]
    out={}
    for key in keys:
        scene,t,source_line=key;result={'range_known':False,'range_reason':None,'range_low':None,'range_high':None,'er20':None,
            'quantity_known':False,'quantity_reason':None,'rvol5':None,'volume5':None,'reference5':None,
            'quantity_last_line':None,'price_last_line':None}
        # ----------------------------------------
        # 直近1分を除いた20分の原行高低。ERは同じ窓の21個の固定1分端点で求める。
        limit=int(np.searchsorted(pl,source_line,side='right'));anchors=t-60-np.arange(20,-1,-1)*60
        points=np.searchsorted(pt[:limit],anchors,side='right')-1
        if len(pt)==0 or np.any(points<0):result['range_reason']='価格端点不足'
        elif np.any(anchors-pt[points]>30):result['range_reason']='価格端点30秒超'
        else:
            a,b=int(points[0]),int(points[-1]);window=px[a:b+1]
            gaps=np.diff(np.r_[anchors[0],pt[a:b+1],anchors[-1]])
            if max(gaps,default=0)>90:result['range_reason']='価格90秒超空白'
            else:
                endpoints=px[points];travel=float(np.abs(np.diff(endpoints)).sum())
                result.update(range_known=True,range_low=float(window.min()),range_high=float(window.max()),
                    er20=float(abs(endpoints[-1]-endpoints[0])/travel) if travel else 0.,price_last_line=int(pl[b]))
        # ----------------------------------------
        # q0を終端とする5分量と、その前4窓。量時刻も利用可能な原行だけを端点とする。
        limit=int(np.searchsorted(ul,source_line,side='right'));anchors=t-np.arange(5,-1,-1)*300
        points=np.searchsorted(ut[:limit],anchors,side='right')-1
        if len(ut)==0 or np.any(points<0):result['quantity_reason']='量端点不足'
        else:
            rows=qi[points];a,b=int(rows[0]),int(rows[-1])
            if np.any(anchors-qt[rows]>30) or np.any(anchors-qvt[rows]>30):result['quantity_reason']='量端点30秒超'
            elif reset[b]!=reset[a]:result['quantity_reason']='窓途中の累積量減少'
            elif back[b]!=back[a]:result['quantity_reason']='窓途中の量時計後退'
            elif max(np.diff(qt[a:b+1]),default=0)>90:result['quantity_reason']='量観測90秒超空白'
            else:
                increments=np.diff(qv[rows]);reference=float(increments[:-1].mean());current=float(increments[-1])
                assert current>=0 and reference>=0
                result.update(volume5=current,reference5=reference,quantity_last_line=int(ql[b]))
                if reference<=0:result['quantity_reason']='直前4窓の量平均0'
                else:result.update(quantity_known=True,rvol5=current/reference)
        out[key]=result
    return out


def extras(keys):
    """
    機能: 固定81場の共用8列から追加の当時特徴を作る。
    引数: keys(set[tuple])は全形成q0の和集合。
    返り値: dict[tuple,dict]は価格構造と数量。
    """
    by={}
    for key in keys:by.setdefault(key[0],[]).append(key)
    result={}
    for entry in read(ROOT/'inputs/TOPIX原順8列_20260921_20261116/台帳.json')['entries']:
        path=ROOT/entry['path'];assert M.sha(path)==entry['sha256']
        with np.load(path,allow_pickle=False) as z:data={k:z[k] for k in z.files}
        result.update(extra_for_scene(data,by.get(entry['session'],[])))
    return result


def side_roles(row,side,context,strict,extra,relative):
    """
    機能: 方向持続、レンジ回復、時間軸混在を当時の価格と動力で判別する。
    引数: row(dict),side(int),context(dict),strict(bool),extra(dict),relative(float|None)。
    返り値: list[bool]はT/R/X/Mの成立。費用比は方向でなく共通可否だけ。
    """
    m=row['m5'];mid=row['m15'];long=row['m30'];a=row['atr'];c=row['close']
    if relative is None or relative<(.75 if strict else .5):return [False]*4
    if (row['spread']+.5836)/a>(.4 if strict else .5):return [False]*4
    if row['range']>(1.5 if strict else 2.) or row['live'] is None or side*row['live']<-.25:return [False]*4
    hd=side*(m['hist_delta'] or 0)/a;rd=side*(m['rsi_delta'] or 0);rsi=m['rsi'] if side>0 else 100-m['rsi']
    motion=side*row['body']>0 and side*row['progress']>0
    recovery=hd>=0 and rd>=0 and motion
    position=row['position'] if side>0 else 1-row['position'];dist=side*(c-m['ema8'])/a
    history=context['history'];coherent=len(history)==3 and all(history[i]['end']-history[i-1]['end']==300 for i in (1,2))
    persistent=coherent and sum(side*p['di']>0 and side*(p['ema8']-p['ema21'])>0 for p in history)>=(3 if strict else 2)
    def aligned(channel,direction):
        """
        機能: 足のEMA傾き・並び・DIの同方向性を確認する。
        引数: channel(dict|None),direction(int)。
        返り値: bool。長期足不足は整合とみなさない。
        """
        return channel is not None and direction*(channel['slope'] or 0)>0 and direction*channel['di']>0 and direction*(channel['ema8']-channel['ema21'])>0
    known=extra['range_known'];er=extra['er20'];gap=abs((m['ema8']-m['ema21'])/a)
    t=persistent and all(aligned(p,side) for p in (m,mid,long)) and m['adx']>=(22 if strict else 18) and gap>=(.25 if strict else .15)
    t=t and known and er>=(.2 if strict else .12) and -.5<=dist<=(.75 if strict else 1.25) and 35<=rsi<=75 and recovery and position>=.55
    # ----------------------------------------
    # レンジの端まで戻ってから回復する。低ADXだけで反転を選ばない。
    r=False;x=False
    if known:
        low,high=extra['range_low'],extra['range_high'];width=high-low
        pos=(c-low)/width if side>0 and width else (high-c)/width if width else .5
        edge=low if side>0 else high;extreme=row['low'] if side>0 else row['high']
        touched=side*(extreme-edge)<=.1*a and side*(c-edge)>=(.1 if strict else .05)*a
        strong_opposite=aligned(long,-side) and long['adx']>=30 and abs((long['ema8']-long['ema21'])/long['atr'])>=1
        r=width>=a and er<=(.25 if strict else .35) and m['adx']<=(18 if strict else 22) and mid['adx']<=25
        r=r and gap<=(.4 if strict else .6) and pos<=(.25 if strict else .35) and touched and recovery and position>=.65 and 25<=rsi<=65 and not strong_opposite
        # ----------------------------------------
        # 短期の反対圧力が失速して中長期へ戻る場合と、中長期の失速を伴う新突破を分ける。
        previous=context['previous'];cross=False
        if previous is not None:
            dt=row['time']-previous['time'];start=M.bounds(row['session'])[0]
            consecutive=int((row['time']-start)//60)-int((previous['time']-start)//60)==1
            level=previous['prior_high'] if side>0 else previous['prior_low']
            cross=consecutive and 30<=dt<=90 and side*(previous['close']-level)>0 and side*(c-level)>0
            cross=cross and side*(extreme-level)>=-(0 if strict else .1)*a
        long_return=aligned(mid,side) and aligned(long,side) and not aligned(m,side) and recovery and cross and hd>0 and rd>0
        opposite_edge=high if side>0 else low
        new_break=aligned(m,side) and aligned(mid,side) and aligned(long,-side)
        fading=long is not None and side*(long['hist_delta'] or 0)>=0 and side*(long['rsi_delta'] or 0)>=0
        new_break=new_break and fading and er>=(.25 if strict else .15) and side*(c-opposite_edge)>0 and recovery and cross
        x=(long_return or new_break) and -.5<=dist<=(1. if strict else 1.5) and 30<=rsi<=75
    # 複数局面が同時に成立しても同じ側の一注文。両側が競合すれば呼出側で待機する。
    return [t,r,x,t or r or x]


def signals(row,context,extra,strict,quantity):
    """
    機能: 指定形成・量尺度の六家族を売買対称で評価する。
    引数: row/context/extra(dict),strict(bool),quantity(int)。
    返り値: list[int]は買1/売-1/待機0。C1だけ固定対照の実側反転。
    """
    relative=row['rvol'] if quantity==0 else extra['rvol5'] if quantity==1 else row['rvol'] if row['rvol'] is not None else extra['rvol5']
    candidate=dict(row,rvol=relative);p0=[];roles=[]
    for side in (1,-1):
        p0.append(U.roles(candidate,side,context,strict)[0] and (row['spread']+.5836)/row['atr']<=(.4 if strict else .5))
        roles.append(side_roles(row,side,context,strict,extra,relative))
    native=1 if p0[0] and not p0[1] else -1 if p0[1] and not p0[0] else 0
    return [native,-native]+[1 if a and not b else -1 if b and not a else 0 for a,b in zip(*roles)]


def prepare():
    """
    機能: 固定対照と72新候補を、81場の同じq0和集合上へ生成・封印する。
    引数: なし。
    返り値: None。新金融に触れる前に全条件を固定する。
    """
    paths=[ROOT/'inputs/TOPIX原順8列_20260921_20261116'/name for name in ('純特徴183.json.gz','純特徴184直接.json.gz')]
    feature={form:read(path) for form,path in enumerate(paths)}
    maps={form:{(r['session'],r['time'],r['line']):r for r in rows} for form,rows in feature.items()}
    keys=set(maps[0])|set(maps[1]);extra=extras(keys);generated={}
    for form,rows in feature.items():
        history=deque(maxlen=3);previous=None;scene=None;ident=None;generated[form]={}
        for row in rows:
            if row['session']!=scene:history.clear();previous=None;ident=None;scene=row['session']
            current=tuple(row['m5'][k] for k in ('count','end','published'))
            if current!=ident:history.append(row['m5']);ident=current
            key=(row['session'],row['time'],row['line']);context={'history':list(history),'previous':previous}
            generated[form][key]={(strict,q):signals(row,context,extra[key],strict,q) for strict in (False,True) for q in range(3)}
            previous=row
    old=read(ROOT/'work/190TOPIX/純入口.json.gz');fixed={(r['session'],r['time'],r['line']):r for r in old};base_index=4*12+1
    result=[];qa=Counter()
    for key in sorted(keys):
        original=fixed[key];row={'session':key[0],'time':key[1],'line':key[2],'band':original['band'],
            'signals':[original['signals'][base_index]],'widths':[original['width']],
            'origins':['190:'+original['origins'][base_index]],'extra':extra[key]}
        for spec in SPECS:
            formed=maps[spec['form']].get(key)
            signal=generated[spec['form']][key][(spec['strict'],spec['quantity'])][spec['family']] if formed else 0
            row['signals'].append(signal);row['widths'].append(U.width(formed,'A25') if formed and row['band']=='DAY' else 15. if formed else None)
            row['origins'].append(spec['name'] if signal else '待機又は形成不足')
        assert extra[key]['quantity_last_line'] is None or extra[key]['quantity_last_line']<=key[2]
        assert extra[key]['price_last_line'] is None or extra[key]['price_last_line']<=key[2]
        qa['range_known']+=int(extra[key]['range_known']);qa['quantity_known']+=int(extra[key]['quantity_known'])
        qa['量:'+str(extra[key]['quantity_reason'])]+=1;qa['価格:'+str(extra[key]['range_reason'])]+=1
        result.append(row)
    M.save(HERE/'純入口.json.gz',result)
    sources=[Path(__file__),ROOT/'work/186TOPIX/入口186.py',M.HERE/'入口とIFD.py']
    cfg={'試行':192,'規模':len(NAMES),'候補':list(NAMES),'specs':SPECS,'形成':{'0':'183旧1分合成','1':'184直接形成'},
        '対照':'190 D4/N01を純出生・幅の同体として保持。新候補も単純IFD/H60。',
        '方向':'費用比は共通可否だけ。P0順/全反転は診断対照、主新仮説は持続三足/観測レンジ回復/混在構造転換/統合。売買鏡像。',
        '価格構造':'q0直前1分を除く20分の原順観測価格高低。効率ERは同じ窓の21固定1分端点。端点30秒以内、原価格空白90秒以内。受信時計や真の連続全約定経路ではない。',
        '量5分':'q0を終端とする5分累積差分÷直前4窓平均。6端点の価格/量時計が境界30秒内、量時刻<=価格時計、原行<=q0。窓中の累積減少/量時計後退/量観測90秒空白は不明。',
        '量比較':list(QUANTITIES),'閾値':'緩/厳の全定数はSourceへ固定。費用比上限0.5/0.4、方向変更なし。',
        '幅期限':'Dayは各形成q0公表済みATR5×2.5を5〜25pt/0.25切上げ、Night±15pt、H60。対照190は当時の直接Day幅をそのまま。',
        '金融':read(M.HERE/'条件_実装修正1.json'),'保有':'保有/未決予約合計1。失効の30秒TTL中も新規禁止。未知は場末まで枠保持。',
        '期間':'固定81場。全80/前48の順位と後25/追加7/本日1を分離。追加11/16Night/11/17Dayは未使用。',
        'Source':{p.relative_to(ROOT).as_posix():M.sha(p) for p in sources},
        '入力SHA':{p.relative_to(ROOT).as_posix():M.sha(p) for p in paths},'純入口SHA':M.sha(HERE/'純入口.json.gz')}
    assert not (HERE/'条件.json').exists();M.save(HERE/'条件.json',cfg)
    M.save(HERE/'純成立診断.json',{'q0':len(result),'追加特徴':dict(qa),'候補':{n:sum(r['signals'][i]!=0 for r in result) for i,n in enumerate(NAMES)}})
    print(json.dumps({'純q0':len(result),'候補':len(NAMES),'特徴可用':dict(qa)},ensure_ascii=False),flush=True)


if __name__=='__main__':prepare()
