"""183の候補台帳と損失集計を、累積差分・連続文字列の別算術で検査する。"""
from pathlib import Path
from math import isclose
import argparse
import gzip
import hashlib
import json


def read(path: Path) -> dict:
    """
    機能: UTF-8のJSON又はgzip JSONを読む。
    引数: path(Path)。
    返り値: dictは保存済み正本。
    """
    data=path.read_bytes()
    return json.loads(gzip.decompress(data) if path.suffix=='.gz' else data)


def check_equal(a: object, b: object, where: tuple) -> int:
    """
    機能: 数値の丸めだけを許して一属性を照合する。
    引数: a/b(object)、where(tuple)は不一致の位置。
    返り値: intは照合数1。不一致は例外。
    """
    if isinstance(a,(int,float)) and isinstance(b,(int,float)):
        assert isclose(a,b,rel_tol=1e-12,abs_tol=1e-8),(where,a,b)
    else:
        assert a==b,(where,a,b)
    return 1


def longest(flags: list[bool]) -> int:
    """
    機能: 連続する真を文字列の分割で独立計数する。
    引数: flags(list[bool])。
    返り値: intは最長連続件数。
    """
    return max(map(len,''.join('1' if x else '0' for x in flags).split('0')),default=0)


def verify(pack: dict, state: dict) -> int:
    """
    機能: 各帯・各期間で台帳の算術と旧金融共通項と新安定性を独立照合する。
    引数: pack(dict)、state(dict)は同候補の集約と新集計。
    返り値: intは照合属性数。売買条件と金融計算は変更しない。
    """
    assert pack['id']==state['id']
    ledger=pack['ledger'];count=0
    all_groups={'全体':state['groups'],**state['periods']}
    for period,groups in all_groups.items():
        evidence=(pack['evidence'] if period=='全体' else pack.get('全80比較') if period=='全80'
                  else pack['periods'].get(period))
        for band,group in groups.items():
            scene_rows=group['sessions']['rows']
            names={r['scene'] for r in scene_rows}
            phase={'DAY':0,'PRE':1,'POST':2}.get(band)
            ids=[i for i,s in enumerate(ledger['scene']) if s in names and (phase is None or ledger['phase'][i]==phase)]
            ids.sort(key=lambda i:(ledger['entry_time'][i],i))
            values=[ledger['net'][i] for i in ids]
            known=[v for v in values if v is not None]
            unknown=len(values)-len(known)
            losses=[v for v in known if v<0]
            trades=group['trades'];where=(pack['id'],period,band)
            for k,v in {'all_count':len(values),'known_count':len(known),'unknown_count':unknown,
                        'known_net':sum(known),'known_profit':sum(v for v in known if v>0),'known_loss':-sum(losses)}.items():
                count+=check_equal(trades[k],v,where+(k,))
            for k,v in {'lower':len(losses)/len(values) if values else None,
                        'upper':(len(losses)+unknown)/len(values) if values else None}.items():
                count+=check_equal(trades['negative_rate'][k],v,where+('赤字取引率',k))
            count+=check_equal(trades['negative_streak']['lower'],longest([v is not None and v<0 for v in values]),where+('連敗下限',))
            count+=check_equal(trades['negative_streak']['upper'],longest([v is None or v<0 for v in values]),where+('連敗上限',))
            # ----------------------------------------
            scene_nets=[];missing=[]
            for scene in scene_rows:
                group_ids=[i for i in ids if ledger['scene'][i]==scene['scene']]
                financial=[ledger['net'][i] for i in group_ids]
                complete=all(v is not None for v in financial)
                net=sum(v for v in financial if v is not None)
                count+=check_equal(scene['all_count'],len(financial),where+(scene['scene'],'取得'))
                count+=check_equal(scene['known_net'],net,where+(scene['scene'],'既知収支'))
                count+=check_equal(scene['all_net'],net if complete else None,where+(scene['scene'],'全件収支'))
                scene_nets.append(net);missing.append(not complete)
            n=len(scene_nets)
            exact_negative=sum(v<0 and not u for v,u in zip(scene_nets,missing))
            for k,v in {'lower':exact_negative/n if n else None,
                        'upper':(exact_negative+sum(missing))/n if n else None}.items():
                count+=check_equal(group['sessions']['negative_rate'][k],v,where+('赤字場率',k))
            count+=check_equal(group['sessions']['negative_streak']['lower'],longest([v<0 and not u for v,u in zip(scene_nets,missing)]),where+('赤字場連続下限',))
            count+=check_equal(group['sessions']['negative_streak']['upper'],longest([v<0 or u for v,u in zip(scene_nets,missing)]),where+('赤字場連続上限',))
            # ----------------------------------------
            curve=[0.]
            for value in scene_nets:curve.append(curve[-1]+value)
            maxdd=max((curve[i]-curve[j] for i in range(len(curve)) for j in range(i,len(curve))),default=0.)
            count+=check_equal(group['path']['known_contribution']['max_drawdown']['amount'],maxdd,where+('DD全組合せ',))
            count+=check_equal(group['path']['full_exact'] is not None,not any(missing),where+('全件経路確定',))
            for width in (5,10):
                sums=[curve[i+width]-curve[i] for i in range(max(0,n-width+1))]
                complete=[not any(missing[i:i+width]) for i in range(len(sums))]
                original=group['rolling'][str(width)]
                count+=check_equal(original['all_count'],len(sums),where+('窓数',width))
                count+=check_equal(original['unknown_count'],len(sums)-sum(complete),where+('未知窓',width))
                actual=original['worst_known_contribution']
                count+=check_equal(actual['known_net'] if actual else None,min(sums) if sums else None,where+('最悪窓',width))
            # ----------------------------------------
            if evidence is not None and band!='ALL':
                prior=(evidence['financial']['session_groups_required'][band] if band in ('DAY','NIGHT')
                       else evidence['financial']['phases_diagnostic'][band])
                for kind,keys in (('trades',('all_count','unknown_count','known_profit','known_loss','known_net')),
                                  ('sessions',('eligible_count','participating_count','complete_count','unknown_count'))):
                    for key in keys:count+=check_equal(group[kind][key],prior[kind][key],where+(kind,key))
                    for key in ('lower','upper','lower_unbounded','upper_unbounded'):
                        count+=check_equal(group[kind]['net_median'][key],prior[kind]['net_median'][key],where+(kind,'中央値',key))
                for key in ('eligible_seconds','held_lower_seconds','held_upper_seconds','held_lower_ratio','held_upper_ratio'):
                    count+=check_equal(group['holding'][key],evidence['holding']['groups'][band][key],where+('保有',key))
    return count


def main() -> None:
    """
    機能: 指定フォルダの全候補と安定性正本を照合して検査票を保存する。
    引数: CLI --input(Path)は183比較フォルダ、--output(Path)は検査票。
    返り値: None。金融や順位を変更しない。
    """
    parser=argparse.ArgumentParser()
    parser.add_argument('--input',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    state_path=args.input/'全候補の損失安定性.json.gz'
    raw=state_path.read_bytes();before=hashlib.sha256(raw).hexdigest()
    states=read(state_path)['rows'];checks=[]
    for state in states:
        path=args.input/'集約'/(state['id']+'.json.gz')
        pack=read(path)
        checks.append({'id':state['id'],'照合':verify(pack,state),'packSHA':hashlib.sha256(path.read_bytes()).hexdigest()})
    assert before==hashlib.sha256(state_path.read_bytes()).hexdigest()
    result={'成功':True,'旧金融との独立集計照合':True,'新金融生成なし':True,
        '候補数':len(checks),'照合項目':sum(r['照合'] for r in checks),
        '集計正本SHA':before,'検査SourceSHA':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'候補':checks}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='候補'},ensure_ascii=False))


if __name__=='__main__':
    main()
