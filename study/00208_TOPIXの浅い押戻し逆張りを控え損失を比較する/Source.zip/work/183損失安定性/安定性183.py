"""単純IFDの全台帳から、損失の頻度・深さ・連続性を独立に集計する。"""
from __future__ import annotations

from collections import defaultdict
from math import ceil, isfinite
from statistics import median


def bounds(values: list[float], unknown: int) -> dict:
    """
    機能: 未知を任意実数として中央値の範囲を求める。
    引数: values(list[float])は確定値、unknown(int)は未知件数。
    返り値: dict。無界端はNoneと旗で表す。
    """
    assert unknown >= 0 and all(isfinite(x) for x in values)
    n = len(values) + unknown
    low = median(sorted(values + [-float('inf')] * unknown)) if n else None
    high = median(sorted(values + [float('inf')] * unknown)) if n else None
    return {'known_median': median(values) if values else None,
        'lower': low if low is not None and isfinite(low) else None,
        'upper': high if high is not None and isfinite(high) else None,
        'lower_unbounded': low == -float('inf'), 'upper_unbounded': high == float('inf'),
        'all_median_exact': unknown == 0 and n > 0,
        'strictly_positive_guaranteed': low is not None and low > 0}


def negative_rate(negative: int, unknown: int, total: int) -> dict:
    """
    機能: 未知を分母へ残して赤字率の下限と上限を算出する。
    引数: negative/unknown/total(int)は確定赤字・未知・全件の数。
    返り値: dict。取得0では率をNoneにする。
    """
    assert 0 <= negative + unknown <= total
    return {'lower': negative / total if total else None,
        'upper': (negative + unknown) / total if total else None,
        'negative_count': negative, 'unknown_count': unknown, 'denominator': total}


def streak(values: list[float | None]) -> dict:
    """
    機能: 未知を非赤字/赤字へ置いた場合の連続赤字件数の範囲を求める。
    引数: values(list[float|None])は取得順又は場順の損益。
    返り値: dict。未知は金額0円へ補完せず連続数の可能性だけを評価する。
    """
    low = high = best_low = best_high = 0
    for value in values:
        low = low + 1 if value is not None and value < 0 else 0
        high = high + 1 if value is None or value < 0 else 0
        best_low = max(best_low, low)
        best_high = max(best_high, high)
    return {'lower': best_low, 'upper': best_high, 'exact': all(v is not None for v in values)}


def path_values(rows: list[dict]) -> dict:
    """
    機能: 与えられた既知寄与経路のDD・回復・初期損失を計算する。
    引数: rows(list[dict])はscene/start/end/known_netを持つ時刻順行。
    返り値: dict。呼出側が既知寄与/全件確定を明示する。
    """
    cumulative = peak = 0.0
    peak_index = -1
    minimum = 0.0
    minimum_index = -1
    worst = {'amount': 0.0, 'peak_index': -1, 'trough_index': -1, 'peak_value': 0.0}
    curves = []
    episodes = []
    open_episode = None
    for i, row in enumerate(rows):
        cumulative += row['known_net']
        curves.append(cumulative)
        if cumulative < minimum:
            minimum, minimum_index = cumulative, i
        if cumulative < peak:
            if open_episode is None:
                open_episode = peak_index
            if peak - cumulative > worst['amount']:
                worst = {'amount': peak - cumulative, 'peak_index': peak_index,
                    'trough_index': i, 'peak_value': peak}
        else:
            if open_episode is not None:
                episodes.append({'peak_index': open_episode, 'recovery_index': i,
                    'underwater_count': i - open_episode - 1})
                open_episode = None
            peak, peak_index = cumulative, i
    if open_episode is not None:
        episodes.append({'peak_index': open_episode, 'recovery_index': None,
            'underwater_count': len(rows) - 1 - open_episode})
    recovery = next((i for i in range(worst['trough_index'] + 1, len(rows))
                     if curves[i] >= worst['peak_value']), None) if worst['amount'] else None
    peak_time = (rows[worst['peak_index']]['end'] if worst['peak_index'] >= 0
                 else rows[0]['start'] if rows else None)
    worst.update({'peak_scene': rows[worst['peak_index']]['scene'] if worst['peak_index'] >= 0 else None,
        'trough_scene': rows[worst['trough_index']]['scene'] if worst['trough_index'] >= 0 else None,
        'recovery_scene': rows[recovery]['scene'] if recovery is not None else None,
        'peak_to_recovery_scenes': recovery - worst['peak_index'] if recovery is not None else None,
        'peak_to_recovery_seconds': rows[recovery]['end'] - peak_time if recovery is not None else None})
    return {'net': cumulative, 'max_drawdown': worst,
        'initial_minimum': minimum,
        'initial_minimum_scene': rows[minimum_index]['scene'] if minimum_index >= 0 else None,
        'longest_underwater_count': max((e['underwater_count'] for e in episodes), default=0),
        'unrecovered_at_end': open_episode is not None,
        'worst_scene_net': min((r['known_net'] for r in rows), default=None)}


def rolling(rows: list[dict], width: int) -> dict:
    """
    機能: 連続する場窓の損失を、完全観測窓と既知寄与へ分ける。
    引数: rows(list[dict])は場順行、width(int)は5又は10等。
    返り値: dict。重複窓は独立試行数とは扱わない。
    """
    windows = []
    for i in range(max(0, len(rows) - width + 1)):
        part = rows[i:i + width]
        windows.append({'start_scene': part[0]['scene'], 'end_scene': part[-1]['scene'],
            'known_net': sum(r['known_net'] for r in part),
            'complete': all(r['complete'] for r in part),
            'acquisitions': sum(r['all_count'] for r in part)})
    complete = [r for r in windows if r['complete']]
    return {'width': width, 'all_count': len(windows), 'complete_count': len(complete),
        'unknown_count': len(windows) - len(complete),
        'negative_rate': negative_rate(sum(r['known_net'] < 0 for r in complete), len(windows)-len(complete), len(windows)),
        'worst_complete': min(complete, key=lambda r: r['known_net']) if complete else None,
        'worst_known_contribution': min(windows, key=lambda r: r['known_net']) if windows else None}


def union_seconds(intervals: list[tuple[float, float]]) -> float:
    """
    機能: 保有区間の和集合秒数を数え、重複保有による率水増しを防ぐ。
    引数: intervals(list[tuple[float,float]])は対象窓へ切った区間。
    返り値: floatは区間和の長さ。
    """
    total = 0.0
    right = None
    for left, end in sorted(intervals):
        if end <= left:
            continue
        total += end - max(left, right) if right is not None and end > right else end - left if right is None else 0
        right = max(right, end) if right is not None else end
    return total


def hold_rows(sessions: list[dict], positions: list[dict], band: str) -> list[dict]:
    """
    機能: 実時刻の保有を対象帯で切り、下限・上限を独立に集計する。
    引数: sessions/positions(list[dict])、band(str)はALL/DAY/NIGHT/PRE/POST。
    返り値: list[dict]は0保有場を含む分母と保有秒。
    """
    by_scene = defaultdict(list)
    for position in positions:
        by_scene[position['scene']].append(position)
    out = []
    for scene in sessions:
        if band in ('DAY', 'NIGHT') and scene['kind'] != band:
            continue
        windows = ([{'start': scene['start'], 'end': scene['end']}]
                   if band in ('ALL', 'DAY', 'NIGHT') else [p for p in scene['phases'] if p['name'] == band])
        for window in windows:
            start, end = window['start'], window['end']
            low, high = [], []
            for p in by_scene[scene['scene']]:
                fill = p['fill']
                finish_low = p['exit'] if p['exit'] is not None else p.get('confirmed_until', fill)
                finish_high = p['exit'] if p['exit'] is not None else p.get('possible_until', end)
                assert finish_low >= fill and finish_high >= finish_low
                low.append((max(start, fill), min(end, finish_low)))
                high.append((max(start, fill), min(end, finish_high)))
            lower, upper = union_seconds(low), union_seconds(high)
            assert 0 <= lower <= upper <= end - start + 1e-8
            out.append({'scene': scene['scene'], 'start': start, 'end': end,
                'eligible_seconds': end-start, 'held_lower_seconds': lower, 'held_upper_seconds': upper})
    return out


def group_metrics(pack: dict, band: str, scene_names: set[str]) -> dict:
    """
    機能: 期間・帯の台帳から金融と損失安定性を独立に集計する。
    引数: pack(dict)はledger/sessions/positions、band(str)、scene_names(set[str])。
    返り値: dict。金融帯は新規q0、保有帯は実際の経過時間で分ける。
    """
    phase = {'DAY': 0, 'PRE': 1, 'POST': 2}
    sessions = sorted((s for s in pack['sessions'] if s['scene'] in scene_names), key=lambda s: s['start'])
    eligible = [s for s in sessions if band == 'ALL' or (s['kind'] == band if band in ('DAY','NIGHT')
                    else any(p['name'] == band for p in s['phases']))]
    names = {s['scene'] for s in eligible}
    ledger = pack['ledger']
    length = len(ledger['net'])
    assert all(len(v) == length for v in ledger.values())
    indices = [i for i in range(length) if ledger['scene'][i] in names
        and (band not in phase or int(ledger['phase'][i]) == phase[band])]
    indices.sort(key=lambda i: (ledger['entry_time'][i], i))
    assert all(bool(ledger['known'][i]) == (ledger['net'][i] is not None) for i in indices)
    values = [ledger['net'][i] for i in indices]
    known = [float(v) for v in values if v is not None]
    unknown = len(values)-len(known)
    loss_values = [-v for v in known if v < 0]
    trade = {'all_count': len(values), 'known_count': len(known), 'unknown_count': unknown,
        'known_profit': sum(v for v in known if v > 0), 'known_loss': sum(loss_values), 'known_net': sum(known),
        'negative_rate': negative_rate(len(loss_values), unknown, len(values)),
        'loss_mean_per_known_loser': sum(loss_values)/len(loss_values) if loss_values else None,
        'known_loss_per_acquisition': sum(loss_values)/len(values) if values else None,
        'net_median': bounds(known, unknown), 'negative_streak': streak(values),
        'streak_clock': '単一保有の取得順。未知の終了時刻を捏造せず、未知を跨ぐ連敗は範囲表示。'}
    # ----------------------------------------
    rows = []
    for scene in eligible:
        selected = [i for i in indices if ledger['scene'][i] == scene['scene']]
        partial = [float(ledger['net'][i]) for i in selected if ledger['known'][i]]
        count_unknown = len(selected)-len(partial)
        net = sum(partial)
        rows.append({'scene': scene['scene'], 'start': scene['start'], 'end': scene['end'],
            'all_count': len(selected), 'unknown_count': count_unknown, 'known_net': net,
            'known_profit': sum(v for v in partial if v > 0), 'known_loss': sum(-v for v in partial if v < 0),
            'complete': count_unknown == 0, 'all_net': net if count_unknown == 0 else None})
    complete = [r['all_net'] for r in rows if r['complete']]
    missing = len(rows)-len(complete)
    negative_scenes = [-v for v in complete if v < 0]
    session = {'eligible_count': len(rows), 'participating_count': sum(r['all_count'] > 0 for r in rows),
        'zero_acquisition_count': sum(r['all_count'] == 0 for r in rows),
        'unknown_count': missing, 'complete_count': len(complete),
        'negative_rate': negative_rate(len(negative_scenes), missing, len(rows)),
        'complete_negative_scene_loss': sum(negative_scenes),
        'complete_negative_scene_mean': sum(negative_scenes)/len(negative_scenes) if negative_scenes else None,
        'net_median': bounds(complete, missing), 'negative_streak': streak([r['all_net'] for r in rows]),
        'rows': rows}
    # ----------------------------------------
    held_rows = hold_rows(sessions, pack['positions'], band)
    seconds = sum(r['eligible_seconds'] for r in held_rows)
    lower = sum(r['held_lower_seconds'] for r in held_rows)
    upper = sum(r['held_upper_seconds'] for r in held_rows)
    holding = {'eligible_seconds': seconds, 'held_lower_seconds': lower, 'held_upper_seconds': upper,
        'held_lower_ratio': lower/seconds if seconds else None, 'held_upper_ratio': upper/seconds if seconds else None}
    prefix = []
    for row in rows:
        if not row['complete']:
            break
        prefix.append(row)
    tail_n = ceil(.2*len(rows))
    tail = sorted((max(0., -r['known_net']) for r in rows), reverse=True)[:tail_n]
    path = {'meaning': '全件確定' if missing == 0 else '既知寄与。未知を0損益と仮定した全件経路ではない。',
        'known_contribution': path_values(rows), 'full_exact': path_values(rows) if missing == 0 else None,
        'exact_prefix': path_values(prefix), 'exact_prefix_scenes': len(prefix),
        'worst20pct_scene_loss_known_contribution_mean': sum(tail)/len(tail) if tail else None,
        'worst20pct_scene_loss_full_exact_mean': sum(tail)/len(tail) if tail and missing == 0 else None,
        'tail_denominator_scenes': tail_n}
    return {'trades': trade, 'sessions': session, 'holding': holding, 'path': path,
        'rolling': {str(w): rolling(rows,w) for w in (5,10)},
        'both_medians_positive': trade['net_median']['strictly_positive_guaranteed'] and session['net_median']['strictly_positive_guaranteed']}


def evaluate_pack(pack: dict, period_scenes: dict[str, list[str]] | None = None) -> dict:
    """
    機能: 候補の全体と明示された期間を、同じ純集計式で評価する。
    引数: pack(dict)、period_scenes(dict[str,list[str]]|None)は期間別の全対象場名。
    返り値: dictは全体groupsと期間periods。0取引場も入力のsessionsへ必要。
    """
    all_scenes = {s['scene'] for s in pack['sessions']}
    assert len(all_scenes) == len(pack['sessions'])
    bands = ('ALL','DAY','NIGHT','PRE','POST')
    periods = {}
    for name, scenes in (period_scenes or {}).items():
        assert set(scenes) <= all_scenes and len(scenes) == len(set(scenes)), name
        periods[name] = {band: group_metrics(pack, band, set(scenes)) for band in bands}
    return {'id': pack['id'], 'groups': {band: group_metrics(pack, band, all_scenes) for band in bands},
        'periods': periods, 'clock': 'セッション順・単一保有の取得順。場末DDは保有中時価DDではない。'}


def gate(group: dict, baseline: dict) -> dict:
    """
    機能: 既存の参加・中央値・未知条件を同じ分母で判定する。
    引数: group/baseline(dict)は同じ帯・期間のgroup_metrics返り値。
    返り値: dictは適合と個別条件。探索順位の採用とは別。
    """
    assert group['sessions']['eligible_count'] == baseline['sessions']['eligible_count']
    checks = {'全場取得': group['sessions']['eligible_count'] > 0 and group['sessions']['participating_count'] == group['sessions']['eligible_count'],
        '保有下限20%': group['holding']['held_lower_ratio'] is not None and group['holding']['held_lower_ratio'] >= .2,
        '両中央値黒字': group['both_medians_positive'],
        '未知非増加': group['trades']['unknown_count'] <= baseline['trades']['unknown_count']}
    return {'suitable': all(checks.values()), 'checks': checks}


def rank_key(group: dict, baseline: dict) -> tuple:
    """
    機能: 事前案の損失優先順に並べるための小さいほどよいキーを返す。
    引数: group/baseline(dict)は同じ帯・期間。ID同点は呼出側の昇順。
    返り値: tuple。未知を含む損失深さは既知寄与の診断順位である。
    """
    s,t,h = group['sessions'],group['trades'],group['holding']
    window = group['rolling']['5']['worst_known_contribution']
    worst_window_loss = max(0., -window['known_net']) if window else float('inf')
    worst_scene = group['path']['known_contribution']['worst_scene_net']
    return (not gate(group,baseline)['suitable'], s['negative_rate']['upper'] if s['negative_rate']['upper'] is not None else 1.,
        worst_window_loss, max(0.,-worst_scene) if worst_scene is not None else float('inf'),
        s['negative_streak']['upper'], t['negative_rate']['upper'] if t['negative_rate']['upper'] is not None else 1.,
        t['known_loss_per_acquisition'] if t['known_loss_per_acquisition'] is not None else float('inf'),
        group['path']['known_contribution']['max_drawdown']['amount'], -(h['held_lower_ratio'] or 0.), -t['all_count'])
