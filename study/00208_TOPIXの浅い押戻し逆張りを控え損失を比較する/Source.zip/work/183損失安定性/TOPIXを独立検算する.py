"""TOPIX183の金融台帳と安定性を、直接走査・独立算術で検査する。"""
from pathlib import Path
from collections import defaultdict
from bisect import bisect_left, bisect_right
from datetime import datetime, timedelta, timezone
from statistics import median
import gzip, hashlib, json, math, sys
import numpy as np
import 新候補の集計を独立検査する as V

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).parent
TARGET=ROOT/'work/183TOPIX'


def read(path):
    """
    機能: 保存正本を読む。
    引数: path(Path)はJSON又はgzip JSON。
    返り値: objectは保存値。
    """
    raw=path.read_bytes()
    return json.loads(gzip.decompress(raw) if path.suffix=='.gz' else raw)


def sha(path):
    """
    機能: 全体の指紋を読む。
    引数: path(Path)は入力。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def midpoint_union(intervals):
    """
    機能: 端点で区切った区間の中点被覆から保有和集合を独立に計数する。
    引数: intervals(list[tuple[float,float]])は帯内へ切った保有区間。
    返り値: floatは合計秒数。
    """
    cuts=sorted({t for a,b in intervals if a<b for t in (a,b)})
    return sum(b-a for a,b in zip(cuts,cuts[1:]) if any(x<=(a+b)/2<y for x,y in intervals))


def inspect_median(values,actual,where):
    """
    機能: 未知を正負無限大へ置いた中央値の範囲を独立に確認する。
    引数: values(list[float|None]),actual(dict),where(tuple)は正本値と位置。
    返り値: intは照合数。
    """
    count=0
    for name,sign in (('lower',-1),('upper',1)):
        bound=median([x if x is not None else sign*math.inf for x in values]) if values else None
        bounded=bound is not None and math.isfinite(bound)
        count+=V.check_equal(actual[name],bound if bounded else None,where+(name,))
        count+=V.check_equal(actual[name+'_unbounded'],bool(values) and not bounded,where+(name+'_unbounded',))
    return count


def inspect_groups(pack,state):
    """
    機能: 独立検査器の算術と、独立中央値・保有区間の検査を行う。
    引数: pack/state(dict)は一候補の保存値。
    返り値: intは照合数。
    """
    shadow={**pack,'evidence':None,'periods':dict.fromkeys(state['periods'])}
    count=V.verify(shadow,state)
    ledger=pack['ledger'];scene_map={s['scene']:s for s in pack['sessions']}
    pos=defaultdict(list)
    for p in pack['positions']:pos[p['scene']].append(p)
    for period,groups in {'全体':state['groups'],**state['periods']}.items():
        for band,g in groups.items():
            names={r['scene'] for r in g['sessions']['rows']};phase={'DAY':0,'PRE':1,'POST':2}.get(band)
            ids=[i for i,s in enumerate(ledger['scene']) if s in names and (phase is None or ledger['phase'][i]==phase)]
            where=(pack['id'],period,band)
            count+=inspect_median([ledger['net'][i] for i in ids],g['trades']['net_median'],where+('建玉中央値',))
            count+=inspect_median([r['all_net'] for r in g['sessions']['rows']],g['sessions']['net_median'],where+('場中央値',))
            eligible=low=high=0.
            for name in names:
                s=scene_map[name]
                windows=[(s['start'],s['end'])] if band in ('ALL','DAY','NIGHT') else [(p['start'],p['end']) for p in s['phases'] if p['name']==band]
                for a,b in windows:
                    eligible+=b-a
                    lows=[];highs=[]
                    for p in pos[name]:
                        finish=p['exit'];l=finish if finish is not None else p['confirmed_until'];h=finish if finish is not None else p['possible_until']
                        assert p['fill']<=l<=h
                        lows.append((max(a,p['fill']),min(b,l)));highs.append((max(a,p['fill']),min(b,h)))
                    low+=midpoint_union(lows);high+=midpoint_union(highs)
            for k,v in {'eligible_seconds':eligible,'held_lower_seconds':low,'held_upper_seconds':high,
                        'held_lower_ratio':low/eligible if eligible else None,'held_upper_ratio':high/eligible if eligible else None}.items():
                count+=V.check_equal(g['holding'][k],v,where+('保有独立区間',k))
    return count


def bounds(scene):
    """
    機能: 対象商品の研究上の時間限界を独立に作る。
    引数: scene(str)は開始日基準の場名。
    返り値: tuple[float,float,float]は開始/終了/強制要求。
    """
    d=datetime.fromisoformat(scene[:10]).replace(tzinfo=timezone(timedelta(hours=9)))
    a=d+timedelta(hours=8,minutes=45) if scene.endswith('Day') else d+timedelta(hours=17)
    b=d+timedelta(hours=15,minutes=30) if scene.endswith('Day') else d+timedelta(days=1,hours=5,minutes=45)
    return a.timestamp(),b.timestamp(),b.timestamp()-60


def financial_oracle(arrays,scene,q0,side,width):
    """
    機能: 到達木を呼ばずBBO部分配列の最初の接触を直接走査する。
    引数: arrays(dict[str,np.ndarray]),scene(str),q0(float),side(int),width(float)。
    返り値: dictは単純IFD台帳と確定保有の独立期待値。
    """
    start,end,force=bounds(scene);t=arrays['now'];line=arrays['line']
    i=bisect_left(t,q0+1)
    assert i<len(t) and t[i]<=min(q0+30,force) and t[i]<force
    opened=float(t[i]);entry=float(arrays['ask'][i] if side==1 else arrays['bid'][i])
    mark=arrays['bid'] if side==1 else arrays['ask']
    deadline=min(opened+3600,force);last=bisect_right(t,deadline)
    signed=side*(mark[i:last]-entry)
    touched=np.nonzero((signed>=width)|(signed<=-width))[0]
    touch=i+int(touched[0]) if len(touched) else None
    target=float(t[touch]) if touch is not None else deadline
    label=('F' if side*(mark[touch]-entry)>=width else 'A') if touch is not None else 'N'
    reason={'F':'IFD利確','A':'IFD損切','N':'期限'}[label]
    j=touch if label=='F' else bisect_left(t,target+1)
    maxfill=min(target+30,end)
    valid=j<len(t) and t[j]<=maxfill
    final_index=j if valid else min(bisect_left(t,maxfill),len(t)-1)
    gap=np.flatnonzero(np.diff(t[i:final_index+1])>300)
    unknown=not valid or bool(len(gap))
    if len(gap):
        known_until=float(t[i+int(gap[0])]);why='正常板300秒超空白'
    elif not valid:
        known_until=float(t[max(i,min(bisect_right(t,maxfill)-1,len(t)-1))]);why='返済時計不足'
    else:known_until=float(t[j]);why=None
    if unknown and (touch is None or len(gap) and i+int(gap[0])+1<=touch):label='C'
    exit_price=(entry+side*width if reason=='IFD利確' else float(mark[j])) if valid else None
    gross=None if unknown else side*(exit_price-entry)
    return {'entry_time':opened,'entry_line':int(line[i]),'entry_price':entry,
            'exit_time':None if unknown else float(t[j]),'exit_line':None if unknown else int(line[j]),
            'exit_price':None if unknown else exit_price,'gross_pt':gross,'known':not unknown,
            'net':None if unknown else round(gross*1000-83.6-500,1),'label':label,'reason':reason,
            'unknown_reason':why,'confirmed_until':min(max(known_until,opened),end)}


def main():
    """
    機能: TOPIX全39候補を読取専用で集計・金融・単一保有の独立検査する。
    引数: CLI任意--output文字列は検査票の末尾名。省略は実装修正1。
    返り値: None。検査票を専有workへ保存する。
    """
    suffix=sys.argv[1] if len(sys.argv)>1 else '実装修正1'
    target=TARGET/'全39組安定性.json.gz';state_sha=sha(target)
    states=read(target)['metrics'];packs={s['id']:read(TARGET/'金融正本'/(s['id']+'.json.gz')) for s in states}
    pack_sha={s:sha(TARGET/'金融正本'/(s+'.json.gz')) for s in packs}
    checks=[];cells=defaultdict(list);nfinancial=0;unique=0
    for s in states:
        p=packs[s['id']];checks.append({'id':s['id'],'集計照合':inspect_groups(p,s),'packSHA':pack_sha[s['id']]})
        ledger=p['ledger'];positions=p['positions'];previous={}
        assert len(positions)==len(ledger['net'])
        for i,scene in enumerate(ledger['scene']):
            end=bounds(scene)[1];request=ledger['request_time'][i]
            assert request>previous.get(scene,-math.inf),(s['id'],scene,'単一保有違反')
            assert positions[i]['scene']==scene and positions[i]['fill']==ledger['entry_time'][i]
            assert positions[i]['exit']==ledger['exit_time'][i]
            previous[scene]=ledger['exit_time'][i] if ledger['known'][i] else end
            key=(request,ledger['side'][i],ledger['width'][i])
            cells[scene].append((key,s['id'],i))
    entries=read(TARGET/'入力台帳.json')['entries']
    for entry in entries:
        scene=entry['session'];start,end,_=bounds(scene)
        with np.load(entry['cache_absolute'],allow_pickle=False) as archive:
            raw={k:archive[k] for k in ('now','line','bid','ask','valid')}
        t=raw['now'];finite=np.isfinite(t)
        prior=np.maximum.accumulate(np.where(finite,t,-np.inf))
        mask=finite&(t>=start)&(t<end)&(t>=prior)&raw['valid']
        arrays={k:v[mask] for k,v in raw.items() if k!='valid'}
        cache={}
        for key,identifier,i in cells[scene]:
            if key not in cache:cache[key]=financial_oracle(arrays,scene,*key)
            expected=cache[key];p=packs[identifier];ledger=p['ledger']
            for k,v in expected.items():
                actual=p['positions'][i][k] if k=='confirmed_until' else ledger[k][i]
                nfinancial+=V.check_equal(actual,v,(identifier,scene,i,k))
        unique+=len(cache)
    assert state_sha==sha(target)
    assert all(pack_sha[s]==sha(TARGET/'金融正本'/(s+'.json.gz')) for s in packs)
    result={'成功':True,'候補数':len(states),'集計照合項目':sum(x['集計照合'] for x in checks),
            '金融照合項目':nfinancial,'金融全取得':sum(len(p['ledger']['net']) for p in packs.values()),'共通取得条件':unique,
            '単一保有検査':True,'金融新生成なし':True,'限界':'正本の約定代用を別算術で検査。受信時計や真の市場約定を保証しない。',
            '集計正本SHA':state_sha,'検査SourceSHA':sha(Path(__file__)),'候補':checks}
    (HERE/('TOPIX独立確認_'+suffix+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='候補'},ensure_ascii=False))


if __name__=='__main__':main()
