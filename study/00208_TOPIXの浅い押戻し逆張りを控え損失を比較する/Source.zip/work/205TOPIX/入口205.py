"""長期支持を残す転換の反対側と、短期破断失敗からの独立順行を比較する。"""
from pathlib import Path
from collections import defaultdict
import sys,json
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
sys.path.insert(0,str(ROOT/'work/203TOPIX'))
import 入口203 as E
M=E.M;read=E.read
SPECS=tuple((form,family,width,mode) for form in (0,1) for family in (0,1) for width in ('W15','A25') for mode in (0,1))
NAMES=('C0_旧190固定',)+tuple(f"F{form}_{('R_長期支持で元側','F_破断失敗から回復')[family]}_{width}_{('全置換','旧優先増分')[mode]}" for form,family,width,mode in SPECS)


def minute_end(row):
    """
    機能: 公表q0が示す直前の完成1分足の終端を求める。
    引数: row(dict)。
    返り値: float。元入力は終端から30秒以内の公表だけを持つ。
    """
    start=M.bounds(row['session'])[0];return start+int((row['time']-start)//60)*60


def continuous(previous,row):
    """
    機能: 同一場の隣り合う完成1分足が欠けずに公表されたか調べる。
    引数: previous/row(dict)。
    返り値: bool。時計差だけでなく完成足終端も確認する。
    """
    return previous['session']==row['session'] and minute_end(row)-minute_end(previous)==60 and 30<=row['time']-previous['time']<=90


def background(row,side):
    """
    機能: 当時の30分支持と価格位置を監査用に固定する。
    引数: row(dict),side(int)。
    返り値: dict。将来公表値へ参照を差し替えない。
    """
    long=row['m30'];return {'time':row['time'],'line':row['line'],'direction':E.direction30(row),'price':row['close'],
        'old_side_price_distance':side*(row['close']-long['ema21']) if long else None,
        'm30':{k:long[k] for k in ('ema8','ema21','slope','hist_delta','end','published')} if long else None}


def seed(row):
    """
    機能: 長期支持と中期水準近傍の中で、直前3足端を終値で破断した源を作る。
    引数: row(dict)。
    返り値: dict|None。源水準・方向・全段階20分期限は不変。
    """
    side=E.direction30(row);mid=row['m15']
    if not side or mid['published']>row['time'] or mid['atr']<=0:return None
    if side*(row['close']-row['m30']['ema21'])<=0:return None
    depth=side*(row['close']-mid['ema8'])/mid['atr']
    if not -1.5<=depth<=.5:return None
    level=row['prior_low'] if side==1 else row['prior_high']
    if not side*(row['prior_close']-level)>=0>side*(row['close']-level):return None
    end=minute_end(row)
    return {'time':row['time'],'line':row['line'],'side':side,'level':level,'expiry':row['time']+1200,'stage':'破断',
        'break_end':end,'prior_ends':[end-180,end-120,end-60],'depth15':depth,'middle':{k:mid[k] for k in ('ema8','atr','end','published')},
        'source_background':background(row,side),'recovery':None}


def advance(state,row,extra):
    """
    機能: 源固定端の回復後、次の異なる完成1分足で価格保持と量を確認する。
    引数: state/row/extra(dict)。
    返り値: dict|Noneは一度の出生。破断→回復→保持は同足へ縮めない。
    """
    side=state['side'];level=state['level'];end=minute_end(row)
    if row['time']<=state['time'] or row['time']>state['expiry']:return None
    if state['stage']=='保持':
        recovery=state['recovery'];extreme=row['low'] if side==1 else row['high'];held=side*(row['close']-level)>0 and side*(extreme-level)>=-.1*row['atr']
        rv=E.relative_volume(row,extra)
        if end==recovery['end']+60 and 30<=row['time']-recovery['time']<=90 and held and rv is not None and rv>=.5 and E.execution_quality(row,side):
            return {k:v for k,v in state.items() if k!='stage'}|{'confirmed':row['time'],'confirmation_end':end,'confirmation_background':background(row,side),'relative_volume':rv,'family':'独立破断失敗から回復'}
        state['stage']='破断';state['recovery']=None
    if E.crossing(row,side,level):
        assert end>state['break_end']
        state['stage']='保持';state['recovery']={'time':row['time'],'line':row['line'],'end':end,'price':row['close']}
    return None


def generate(rows,extras):
    """
    機能: 203転換や費用方向と独立に破断源を追い、欠測で状態を破棄する。
    引数: rows(list[dict]),extras(dict)。
    返り値: tuple[dict,dict]はq0別出生と量/段階診断。
    """
    outputs={};state=None;previous=None;counts=defaultdict(int)
    for row in rows:
        key=(row['session'],row['time'],row['line']);birth=None
        if row['band']=='DAY':outputs[key]=None;state=None;previous=row;continue
        if previous is not None and not continuous(previous,row):
            if state is not None:counts['欠測又は場境界で源破棄']+=1
            state=None
        previous=row;rv=E.relative_volume(row,extras[key]);counts['量不明' if rv is None else '既知低量' if rv<.5 else '既知量支持']+=1
        if state is not None:
            if row['time']>state['expiry'] or E.direction30(row)!=state['side']:
                counts['期限又は長期支持失効']+=1;state=None
        if state is not None:
            before=state['stage'];birth=advance(state,row,extras[key]);counts['源監視q0']+=1
            if birth is not None:counts['発火']+=1;state=None
            elif before!=state['stage']:counts['回復確認' if state['stage']=='保持' else '保持せず']+=1
        else:
            state=seed(row)
            if state is not None:counts['源成立']+=1
        outputs[key]=birth
    return outputs,dict(counts)


def reverse_reference(rows,pure,form):
    """
    機能: 固定203転換出生の源旧側支持が残る時だけ、実側を反対にする対照を作る。
    引数: rows(list[dict]),pure(dict),form(int)。
    返り値: tuple[dict,dict]は出生と棄却診断。源以降欠測がある場合は継続扱いしない。
    """
    maps={(r['session'],r['time'],r['line']):r for r in rows};prefix={};gaps=0;previous=None;outputs={};counts=defaultdict(int)
    for row in rows:
        key=(row['session'],row['time'],row['line'])
        if previous is not None and not continuous(previous,row):gaps+=1
        prefix[key]=gaps;previous=row;birth=pure[key]['births'][8+form*12]
        if row['band']=='DAY' or birth is None:outputs[key]=None;continue
        counts['固定203転換出生']+=1;source_key=(row['session'],birth['time'],birth['line']);source=maps[source_key];side=birth['old_direction']
        if prefix[source_key]!=gaps:counts['源から確認まで欠測']+=1;outputs[key]=None;continue
        if E.direction30(row)!=side or side*(row['close']-row['m30']['ema21'])<=0:counts['旧長期方向又は価格支持なし']+=1;outputs[key]=None;continue
        outputs[key]={'family':'固定転換の源旧側','time':birth['time'],'line':birth['line'],'side':side,'level':birth['level'],'expiry':birth['expiry'],
            'confirmed':row['time'],'source_background':background(source,side),'confirmation_background':background(row,side),'reference203':birth}
        counts['発火']+=1
    return outputs,dict(counts)


def prepare():
    """
    機能: 17条件と源情報を金融前に固定し、旧優先を同q0の当時情報だけで決める。
    引数: なし。
    返り値: None。追加2場・実損益は生成や条件選択へ混ぜない。
    """
    base=read(ROOT/'inputs/00203_TOPIXの長期支持と転換の純入口/純入口.json.gz');pure={(r['session'],r['time'],r['line']):r for r in base};extras={k:r['extra'] for k,r in pure.items()}
    features={f:read(ROOT/'inputs/TOPIX原順8列_20260921_20261116'/n) for f,n in enumerate(('純特徴183.json.gz','純特徴184直接.json.gz'))};maps={f:{(r['session'],r['time'],r['line']):r for r in rows} for f,rows in features.items()};generated={};diagnostics={}
    for form in (0,1):
        generated[(form,0)],diagnostics[f'{form}_R']=reverse_reference(features[form],pure,form)
        generated[(form,1)],diagnostics[f'{form}_F']=generate(features[form],extras)
    result=[]
    for row in base:
        key=(row['session'],row['time'],row['line']);signals=[row['signals'][0]];widths=[row['widths'][0]];origins=['旧190固定'];births=[None]
        for form,family,width,mode in SPECS:
            birth=generated[(form,family)].get(key);side=birth['side'] if birth else 0
            if row['band']=='DAY' or mode==1 and row['signals'][0]:
                side=row['signals'][0];w=row['widths'][0];origin='旧190固定';record=None
            else:
                formed=maps[form].get(key);w=15. if width=='W15' else E.P.B.P.U.width(formed,width) if formed else None;origin=NAMES[len(signals)];record=dict(birth,form=form) if birth else None
            signals.append(side);widths.append(w);origins.append(origin);births.append(record)
        assert len(signals)==17 and signals[0]==row['signals'][0]
        result.append({'session':key[0],'time':key[1],'line':key[2],'band':row['band'],'signals':signals,'widths':widths,'origins':origins,'births':births,'extra':row['extra']})
    M.save(HERE/'純入口.json.gz',result)
    sources=[Path(__file__),ROOT/'work/203TOPIX/入口203.py',ROOT/'work/200TOPIX/入口200.py',ROOT/'work/197TOPIX/入口197.py',ROOT/'work/192TOPIX/入口192.py',ROOT/'work/186TOPIX/入口186.py',M.HERE/'入口とIFD.py',ROOT/'work/184TOPIX/直接形成184.py',ROOT/'scripts/TOPIX入口研究/共通金融.py']
    cfg={'試行':205,'規模':17,'候補':list(NAMES),'情報区分':'203反対BBO診断後に既使用81場で設計・探索。追加2も既使用だが今回探索へ混ぜない。未見再現ではない。',
      '構成':'旧190固定1＋旧/直接形成2×R/F入口2×W15/A25幅2×全置換/旧優先増分2。Day旧190D4固定。',
      'R':'203 Q0転換出生の源旧30方向が当時EMA並び/21傾きで残り、価格も当時30EMA21の源旧側なら実側を反転。源→確認までq0欠測があれば棄却。源/確認の30分値と価格位置を固定記録。',
      'F':'30EMA8/21並び＋21傾きで方向。価格が30EMA21源側かつ15EMA8距離が源側-1.5〜+0.5ATR15。現足除外の直前3完成1分端を終値で逆側へ破断→後の1分終値が源端を回復し実体/進行同側→次連続1分で固定端保持、逆端侵入<=0.1ATR5、量と品質で発火。',
      '時計':'源の3足端は現足除外のend-180/-120/-60。源足/回復足/保持足のendと公表q0は厳密に昇順。隣接q0は完成足end差60秒かつ公表差30〜90秒。欠測で全stage破棄。源から1200秒の総期限を延長しない。',
      '量品質':'旧1分相対量が既知なら優先、不明時だけ192因果5分量へ補完し>=0.5。既知低量と不明を区別。0<spread<=1.5、1分幅<=2.5ATR5、live既知かつ実側>=-0.25ATR5。',
      '優先':'旧N01優先は同q0で旧純成立があれば旧側/旧幅を選ぶだけ。将来の旧要求は参照せず、保有中・予約中は口座再生で追加禁止。増分を旧幹の優位と混同しない。',
      '固定比較':'旧190D4/N01の方向・旧費用境界・DayA25/NightW15は変更しない。新枝だけW15/A25。H60・単純IFD・合計1枠・終了15分前。miniTOPIX片道41.8円+0.25pt。',
      '評価':'前48/後25/追加7/全80/本日1、全場分母、両中央値/損失頻度/損失深さ/連続/累計DD/参加時間を保持。源旧側反転の直接47取得70%は到達10件かつ追加期赤字で一般解としない。',
      'Source':{p.relative_to(ROOT).as_posix():M.sha(p) for p in sources},'純入口SHA':M.sha(HERE/'純入口.json.gz'),'母体203SHA':M.sha(ROOT/'inputs/00203_TOPIXの長期支持と転換の純入口/純入口.json.gz')}
    assert not (HERE/'条件.json').exists();M.save(HERE/'条件.json',cfg)
    M.save(HERE/'純成立診断.json',{'段階':diagnostics,'Night純成立':{name:sum(bool(r['signals'][i]) for r in result if r['band']!='DAY') for i,name in enumerate(NAMES)},'q0':len(result)})
    print(json.dumps({'候補':17,'q0':len(result),'純入口SHA':cfg['純入口SHA'],'段階':diagnostics},ensure_ascii=False),flush=True)


if __name__=='__main__':prepare()
