"""逆行過多の独立順行を、同取得q0・同幅の反対BBOで個別に原因診断する。"""
from collections import defaultdict
from pathlib import Path
import sys,json
import numpy as np
import 入口205 as E
import 金融を比較する as F
sys.path.insert(0,str(E.ROOT/'work/183損失安定性'))
import TOPIXを独立検算する as T
sys.path.insert(0,str(E.ROOT/'work/202TOPIX'))
from 原因202 import describe


def main():
    """
    機能: 205の全置換F四案が実取得したq0だけを反対側で独立再評価する。
    引数: なし。
    返り値: None。個別反転の合算は口座収支や新採用候補ではない。
    """
    states=E.read(E.HERE/'金融/安定性.json.gz')['metrics'];indices=(5,7,13,15);old={ci:E.read(E.HERE/'金融/金融正本'/(states[ci]['id']+'.json.gz')) for ci in indices}
    targets=defaultdict(list);packs={}
    for ci in indices:
        pack=old[ci];ledger=pack['ledger'];new=F.empty('205原因_'+str(ci)+'_同取得q0反対側独立',pack['sessions']);new['ledger']['origin']=[];packs[ci]=new
        for i,scene in enumerate(ledger['scene']):
            if 'Night' in scene:targets[scene].append((ci,i))
    E.M.save(E.HERE/'反対側診断開始前.json',{'対象':list(indices),'区分':'205金融後の同取得q0反対側BBO診断。独立取引の合算を単一枠口座としない。条件へ採用しない。','SourceSHA':E.M.sha(Path(__file__)),'元金融SHA':E.M.sha(E.HERE/'金融/安定性.json.gz')})
    checks=0;count=0
    for entry in E.read(E.ROOT/'inputs/TOPIX原順8列_20260921_20261116/台帳.json')['entries']:
        scene=entry['session']
        if not targets[scene]:continue
        entry=dict(entry,cache_absolute=str(E.ROOT/entry['path']));route=E.M.Route(entry);start,end,force=T.bounds(scene)
        with np.load(entry['cache_absolute'],allow_pickle=False) as archive:raw={k:archive[k] for k in ('now','line','bid','ask','valid')}
        t=raw['now'];finite=np.isfinite(t);prior=np.maximum.accumulate(np.where(finite,t,-np.inf));mask=finite&(t>=start)&(t<end)&(t>=prior)&raw['valid'];arrays={k:v[mask] for k,v in raw.items() if k!='valid'};cache={}
        for ci,i in targets[scene]:
            ledger=old[ci]['ledger'];q0=ledger['request_time'][i];line=ledger['request_line'][i];side=-ledger['side'][i];width=ledger['width'][i];query=(q0,line,side,width)
            if query not in cache:cache[query]=(route.cell(*query),T.financial_oracle(arrays,scene,q0,side,width))
            cell,oracle=cache[query];assert cell is not None;pack=packs[ci];F.append(pack,dict(cell,origin='固定実取得q0の反対側原因診断'));j=len(pack['ledger']['net'])-1
            for field,value in oracle.items():
                actual=pack['positions'][j][field] if field=='confirmed_until' else pack['ledger'][field][j];checks+=T.V.check_equal(actual,value,(ci,scene,i,field))
            count+=1
    result=[]
    for ci in indices:
        ledger=old[ci]['ledger'];original_indices=[i for i,s in enumerate(ledger['scene']) if 'Night' in s];new=packs[ci]['ledger'];assert len(new['net'])==len(original_indices)
        result.append({'index':ci,'元実取得':describe(ledger,original_indices),'同取得q0反対':describe(new,list(range(len(new['net']))))})
    E.M.save(E.HERE/'反対側診断.json',{'区分':'同取得時点の独立反対BBO。1-pではなく実Bid/Askと費用を再計算。口座枠は再計算していないので新口座の収支ではない。','結果':result,'独立確認':{'成功':True,'取得':count,'金融属性':checks}})
    for row in result:print(json.dumps(row,ensure_ascii=False),flush=True)


if __name__=='__main__':main()
