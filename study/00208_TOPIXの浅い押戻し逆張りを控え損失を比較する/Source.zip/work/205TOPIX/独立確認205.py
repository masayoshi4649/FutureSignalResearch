"""205の共通金融を別BBO線形走査・全q0の予約保有再生・別集計で照合する。"""
from pathlib import Path
from collections import defaultdict
import sys,json,math
import numpy as np
import 入口205 as E
sys.path.insert(0,str(E.ROOT/'work/183損失安定性'))
import TOPIXを独立検算する as T


def main():
    """
    機能: 固定17口座の取得と両中央値・全場分母を、金融器と別算術で検査する。
    引数: なし。
    返り値: None。入口・純出生・共通金融は変更しない。
    """
    folder=E.HERE/'金融';metrics_path=folder/'安定性.json.gz';state_sha=E.M.sha(metrics_path)
    states=E.read(metrics_path)['metrics'];packs=[E.read(folder/'金融正本'/(s['id']+'.json.gz')) for s in states]
    original={p['id']:E.M.sha(folder/'金融正本'/(p['id']+'.json.gz')) for p in packs}
    by=defaultdict(list)
    for row in E.read(E.HERE/'純入口.json.gz'):by[row['session']].append(row)
    checks={'金融属性':0,'独立集計属性':0,'取得':0,'全q0枠':0,'出生時計':0}
    for pack,state in zip(packs,states):checks['独立集計属性']+=T.inspect_groups(pack,state)
    for entry in E.read(E.ROOT/'inputs/TOPIX原順8列_20260921_20261116/台帳.json')['entries']:
        scene=entry['session'];start,end,force=T.bounds(scene)
        with np.load(E.ROOT/entry['path'],allow_pickle=False) as archive:raw={k:archive[k] for k in ('now','line','bid','ask','valid')}
        t=raw['now'];finite=np.isfinite(t);prior=np.maximum.accumulate(np.where(finite,t,-np.inf));mask=finite&(t>=start)&(t<end)&(t>=prior)&raw['valid'];arrays={k:v[mask] for k,v in raw.items() if k!='valid'};cache={}
        for ci,pack in enumerate(packs):
            ledger=pack['ledger'];indices=[i for i,s in enumerate(ledger['scene']) if s==scene];cursor=0;busy=-math.inf
            for row in by[scene]:
                side=row['signals'][ci]
                if not side:continue
                checks['全q0枠']+=1
                if row['time']<=busy:continue
                key=(row['time'],side,row['widths'][ci])
                if key not in cache:
                    first=int(np.searchsorted(arrays['now'],row['time']+1));fillable=first<len(arrays['now']) and arrays['now'][first]<=min(row['time']+30,force) and arrays['now'][first]<force
                    cache[key]=T.financial_oracle(arrays,scene,*key) if fillable else None
                cell=cache[key]
                if cell is None:busy=min(row['time']+30,force);continue
                assert cursor<len(indices),(pack['id'],scene,'未記録取得')
                i=indices[cursor];cursor+=1;checks['取得']+=1
                for field,value in cell.items():
                    actual=pack['positions'][i][field] if field=='confirmed_until' else ledger[field][i]
                    checks['金融属性']+=T.V.check_equal(actual,value,(pack['id'],scene,i,field))
                assert ledger['request_time'][i]==row['time'] and ledger['request_line'][i]==row['line']
                assert ledger['side'][i]==side and ledger['width'][i]==row['widths'][ci] and ledger['origin'][i]==row['origins'][ci]
                birth=row['births'][ci]
                if birth is not None:
                    assert birth['source_background']['m30']['published']<=birth['time']<row['time']<=birth['expiry']
                    assert birth['confirmation_background']['m30']['published']<=row['time'];checks['出生時計']+=2
                    if birth['family']=='独立破断失敗から回復':
                        assert birth['break_end']<birth['recovery']['end']<birth['confirmation_end']<=row['time'];checks['出生時計']+=1
                busy=ledger['exit_time'][i] if ledger['known'][i] else end
            assert cursor==len(indices),(pack['id'],scene,'余分取得')
    old=E.read(E.ROOT/'inputs/00192_TOPIXの構造と数量の純入口/旧190固定対照.json.gz');ledger={k:v for k,v in packs[0]['ledger'].items() if k!='origin'};oldledger={k:v for k,v in old['ledger'].items() if k!='origin'}
    assert ledger==oldledger and packs[0]['positions']==old['positions'] and packs[0]['sessions']==old['sessions']
    assert state_sha==E.M.sha(metrics_path) and all(E.M.sha(folder/'金融正本'/(p['id']+'.json.gz'))==original[p['id']] for p in packs)
    proof={'成功':True,'候補':17,**checks,'旧対照同体':True,'固定金融SHA':state_sha,'方式':'共通金融/Route/到達木を使わない別BBO線形走査。予約失効30秒と未知保有を全q0で再生。','SourceSHA':E.M.sha(Path(__file__)),'独立oracleSHA':E.M.sha(Path(T.__file__))}
    E.M.save(E.HERE/'独立確認.json',proof);print(json.dumps(proof,ensure_ascii=False),flush=True)


if __name__=='__main__':main()
