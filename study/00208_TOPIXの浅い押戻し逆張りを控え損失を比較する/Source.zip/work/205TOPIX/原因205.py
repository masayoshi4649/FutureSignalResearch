"""旧入口の源方向と実方向、新枝自身と口座枠の変化を同じ当時属性で診断する。"""
from collections import defaultdict
from statistics import median
import sys,json
import 入口205 as E
sys.path.insert(0,str(E.ROOT/'work/202TOPIX'))
from 原因202 import describe
import 金融を比較する as F


def trend15(row):
    """
    機能: 当時15分EMAの並びと21EMA傾きの一致方向を求める。
    引数: row(dict)。
    返り値: intは+1/-1/0。0は方向不一致・未公表・不明を含む。
    """
    m=row['m15']
    if m is None or m['published']>row['time'] or m['slope'] is None:return 0
    return 1 if m['ema8']>m['ema21'] and m['slope']>0 else -1 if m['ema8']<m['ema21'] and m['slope']<0 else 0


def sign_label(direction,side):
    """
    機能: 実方向に対する背景方向を三値へ整理する。
    引数: direction/side(int)。
    返り値: strは支持/逆側/混在不明。
    """
    return '支持' if direction==side else '逆側' if direction==-side else '混在不明'


def diagnose(pack,pure,maps,contexts,ci):
    """
    機能: 旧幹と新枝に共通の当時背景・位置・源実方向属性を付けて集計する。
    引数: pack/pure/maps/contexts(dict),ci(int)。
    返り値: dictは群別支持と価格位置の事後説明。新条件を選択しない。
    """
    ledger=pack['ledger'];groups=defaultdict(list);values=defaultdict(list)
    for i,scene in enumerate(ledger['scene']):
        if 'Night' not in scene:continue
        key=(scene,ledger['request_time'][i],ledger['request_line'][i]);pr=pure[key];birth=pr['births'][ci];side=ledger['side'][i]
        if birth is None:
            form=0;row=maps[0][key];native=E.E.P.B.native(row,contexts[0][key],pr['extra'],0);assert native in (-1,1)
            family='旧N01';direction='元順行' if side==native else '実反転'
        else:
            form=birth['form'];row=maps[form][key];native=birth['side'];family=birth['family'];direction='源長期側'
        prefix=family+'/'+direction;long=E.E.direction30(row);middle=trend15(row)
        long_state='履歴不足又は鮮度不足' if row['m30'] is None else sign_label(long,side);mid_state=sign_label(middle,side)
        old_long='履歴不足又は鮮度不足' if row['m30'] is None else sign_label(long,native);old_middle=sign_label(middle,native)
        long_position='不明' if row['m30'] is None else '実側' if side*(row['close']-row['m30']['ema21'])>0 else '逆側同値'
        mid_position='実側' if side*(row['close']-row['m15']['ema8'])>0 else '逆側同値'
        names=['全体',family,prefix,prefix+'/帯/'+row['band'],prefix+'/30/'+long_state,prefix+'/15/'+mid_state,
            prefix+'/30と15/'+long_state+'_'+mid_state,prefix+'/源に対する30と15/'+old_long+'_'+old_middle,
            prefix+'/価格30EMA21/'+long_position,prefix+'/価格15EMA8/'+mid_position,prefix+'/背景と価格/'+long_state+'_'+long_position+'_'+mid_position,
            prefix+'/決済/'+ledger['reason'][i]]
        if birth is not None and 'depth15' in birth:
            age=(row['time']-birth['time'])/60;progress=side*(row['close']-birth['source_background']['price'])/row['atr'];depth=birth['depth15'];level_distance=side*(row['close']-birth['level'])/row['atr']
            names+= [prefix+'/源15位置/'+('EMA逆側' if depth<0 else 'EMA実側'),prefix+'/源から確認時間/'+('5分以下' if age<=5 else '5分超')]
            for name,value in (('源から確認分',age),('源から確認ATR5',progress),('源15EMA距離ATR15',depth),('確認の固定端距離ATR5',level_distance)):values[prefix+'/'+name].append(value)
        for name in names:groups[name].append(i)
        values[prefix+'/幅対ATR5'].append(ledger['width'][i]/row['atr'])
    return {'群':{name:describe(ledger,idx) for name,idx in groups.items()},'位置中央値':{name:{'件数':len(v),'中央値':median(v),'最小':min(v),'最大':max(v)} for name,v in values.items()}}


def main():
    """
    機能: 全17口座の枝と背景、旧優先増分が変更した実取得を分けて固定する。
    引数: なし。
    返り値: None。金融・入口・順位を事後の最良群へ置換しない。
    """
    data=E.read(E.HERE/'金融/安定性.json.gz');states=data['metrics'];packs=[E.read(E.HERE/'金融/金融正本'/(s['id']+'.json.gz')) for s in states]
    pure={(r['session'],r['time'],r['line']):r for r in E.read(E.HERE/'純入口.json.gz')};features={f:E.read(E.ROOT/'inputs/TOPIX原順8列_20260921_20261116'/name) for f,name in enumerate(('純特徴183.json.gz','純特徴184直接.json.gz'))};maps={f:{(r['session'],r['time'],r['line']):r for r in rows} for f,rows in features.items()};contexts={f:E.E.P.B.context_rows(rows) for f,rows in features.items()}
    results=[{'index':ci,'id':pack['id'],**diagnose(pack,pure,maps,contexts,ci)} for ci,pack in enumerate(packs)]
    baseline=packs[0]['ledger'];basekeys={(s,baseline['request_time'][i],baseline['request_line'][i],baseline['side'][i],baseline['width'][i]):i for i,s in enumerate(baseline['scene']) if 'Night' in s};pairs=[]
    for ci in range(2,17,2):
        ledger=packs[ci]['ledger'];keys={(s,ledger['request_time'][i],ledger['request_line'][i],ledger['side'][i],ledger['width'][i]):i for i,s in enumerate(ledger['scene']) if 'Night' in s};common=set(basekeys)&set(keys);baseonly=set(basekeys)-set(keys);changed=set(keys)-set(basekeys)
        for key in common:assert baseline['net'][basekeys[key]]==ledger['net'][keys[key]] and baseline['known'][basekeys[key]]==ledger['known'][keys[key]]
        extraold=[keys[k] for k in changed if ledger['origin'][keys[k]]=='旧190固定'];new=[keys[k] for k in changed if ledger['origin'][keys[k]]!='旧190固定']
        pairs.append({'index':ci,'共通実取得':describe(ledger,[keys[k] for k in sorted(common)]),'基準だけの実取得':describe(baseline,[basekeys[k] for k in sorted(baseonly)]),'補完口座だけの旧入口実取得':describe(ledger,extraold),'新枝実取得':describe(ledger,new)})
    rankings={}
    for period in ('全80','前48'):
        for band in ('DAY','NIGHT','ALL'):
            baseline_stat=states[0]['periods'][period][band];order=sorted(range(17),key=lambda i:(F.A.rank_key(states[i]['periods'][period][band],baseline_stat),states[i]['id']))
            rankings[f'{period}_{band}']=[{'id':states[i]['id'],'index':i,'gate':F.A.gate(states[i]['periods'][period][band],baseline_stat)} for i in order]
    E.M.save(E.HERE/'原因診断.json',{'情報区分':'205金融後の事後説明。源側と実側、共通実取得と枠の差を分離。将来の損益を使った新条件はまだない。','候補':results,'旧優先増分':pairs,'SourceSHA':E.M.sha(E.HERE/'原因205.py')})
    E.M.save(E.HERE/'固定選択.json',{'全体採用':None,'理由':'新枝は全置換で参加又は中央値不足。旧優先増分で参加を増すが、旧より損失を増し、直接形成は両中央値も悪化。利益増だけで改善としない。','順位':rankings,'条件SHA':E.M.sha(E.HERE/'条件.json'),'純入口SHA':E.M.sha(E.HERE/'純入口.json.gz'),'金融SHA':E.M.sha(E.HERE/'金融/安定性.json.gz')})
    for ci in (0,5,6,9,13,14):
        row=results[ci];print(json.dumps({'index':ci,'群':{k:v for k,v in row['群'].items() if len(k.split('/'))<=2},'位置':row['位置中央値']},ensure_ascii=False),flush=True)
    print(json.dumps({'増分':pairs},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
