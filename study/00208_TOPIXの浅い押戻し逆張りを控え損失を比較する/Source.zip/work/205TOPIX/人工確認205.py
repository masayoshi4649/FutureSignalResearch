"""源の固定、三足の順序、欠測破棄、量可用性、鏡像と接頭部を金融前に検査する。"""
from copy import deepcopy
import json
import 入口205 as E
import 人工検査 as T


def main():
    """
    機能: 新しい状態遷移と当時情報だけの出生を人工入力・実特徴で確認する。
    引数: なし。
    返り値: None。金融・損益・将来到達は参照しない。
    """
    checks=0;features={f:E.read(E.ROOT/'inputs/TOPIX原順8列_20260921_20261116'/n) for f,n in enumerate(('純特徴183.json.gz','純特徴184直接.json.gz'))}
    scene='2026-09-21_Night';t=E.M.bounds(scene)[0]+3600;source=deepcopy(features[1][1000])
    source.update(session=scene,time=t,line=1,band='PRE',close=4000.,prior_close=4002.,prior_low=4001.,prior_high=4004.,low=3999.5,high=4002.,atr=2.,rvol=1.,body=-1.,progress=-1.,live=0.,spread=.5,range=1.25)
    for key in ('m5','m15','m30'):source[key].update(count=10,end=t,published=t,atr=2.)
    source['m30'].update(ema8=4005.,ema21=3990.,slope=.1,hist_delta=-.1)
    source['m15'].update(ema8=4002.,atr=4.,close=4004.)
    recovery=deepcopy(source);recovery.update(time=t+60,line=2,close=4002.,prior_close=4000.,low=4000.,high=4003.,body=1.,progress=1.)
    hold=deepcopy(recovery);hold.update(time=t+120,line=3,prior_close=4002.,close=4002.5,low=4001.)
    for mirrored in (False,True):
        rows=[T.mirror(r) for r in (source,recovery,hold)] if mirrored else [source,recovery,hold]
        s,c,h=rows;state=E.seed(s);assert state is not None and state['side']==(-1 if mirrored else 1);checks+=2
        assert state['prior_ends']==[t-180,t-120,t-60] and state['break_end']==t;checks+=2
        fixed={k:deepcopy(v) for k,v in state.items() if k not in ('stage','recovery')}
        assert E.advance(state,s,{'rvol5':1.}) is None;assert E.advance(state,c,{'rvol5':1.}) is None;checks+=2
        assert E.advance(state,c,{'rvol5':1.}) is None;checks+=1
        # 同じ回復足の再参照で発火せず、異なる保持足を待つ。
        state=E.seed(s);E.advance(state,c,{'rvol5':1.});birth=E.advance(state,h,{'rvol5':1.});assert birth is not None;checks+=1
        assert {k:v for k,v in state.items() if k not in ('stage','recovery')}==fixed;checks+=1
        assert birth['break_end']<birth['recovery']['end']<birth['confirmation_end'];checks+=1
        extras={(r['session'],r['time'],r['line']):{'rvol5':1.} for r in rows}
        full,_=E.generate(rows,extras);assert sum(x is not None for x in full.values())==1;checks+=1
        no_middle,_=E.generate([s,h],extras);assert not any(no_middle.values());checks+=1
        for failure in ('低量','量不明','未来30足','期限切れ','非連続保持'):
            bad=deepcopy(h);extra={'rvol5':1.}
            if failure=='低量':bad['rvol']=0.
            elif failure=='量不明':bad['rvol']=None;extra['rvol5']=None
            elif failure=='未来30足':bad['m30']['published']=bad['time']+1
            elif failure=='期限切れ':bad['time']=t+1201
            else:bad['time']=t+180
            items=[s,c,bad];ex={(r['session'],r['time'],r['line']):extra if r is bad else {'rvol5':1.} for r in items};out,_=E.generate(items,ex)
            assert not any(out.values()),failure;checks+=1
    assert E.E.relative_volume(dict(source,rvol=0.),{'rvol5':100.})==0.;assert E.E.relative_volume(dict(source,rvol=None),{'rvol5':None}) is None;checks+=2
    # ----------------------------------------
    # 実特徴では将来を追加しても接頭部は不変。方向・源・期限は価格鏡像でも同体。
    base=E.read(E.ROOT/'inputs/00203_TOPIXの長期支持と転換の純入口/純入口.json.gz');pure={(r['session'],r['time'],r['line']):r for r in base};extras={k:r['extra'] for k,r in pure.items()};counts={}
    for form in (0,1):
        full,counts[f'{form}_F']=E.generate(features[form],extras);prefix,_=E.generate(features[form][:3000],extras)
        for key,birth in prefix.items():assert full[key]==birth;checks+=1
        mirrored,_=E.generate([T.mirror(r) for r in features[form][:3000]],extras)
        for key,birth in prefix.items():
            other=mirrored[key];assert (birth is None)==(other is None);checks+=1
            if birth is not None:assert birth['side']==-other['side'] and birth['time']==other['time'] and birth['expiry']==other['expiry'];checks+=3
        seen=set()
        for key,birth in full.items():
            if birth is None:continue
            marker=(key[0],birth['time'],birth['line']);assert marker not in seen;seen.add(marker);checks+=1
            assert birth['time']<birth['recovery']['time']<key[1]<=birth['expiry']==birth['time']+1200;checks+=2
            assert birth['break_end']<birth['recovery']['end']<birth['confirmation_end'] and birth['prior_ends'][-1]==birth['break_end']-60;checks+=2
            assert birth['source_background']['direction']==birth['side']==birth['confirmation_background']['direction'];checks+=1
        reverse,counts[f'{form}_R']=E.reverse_reference(features[form],pure,form);rprefix,_=E.reverse_reference(features[form][:3000],pure,form)
        for key,birth in rprefix.items():assert reverse[key]==birth;checks+=1
        for key,birth in reverse.items():
            if birth is None:continue
            assert birth['side']==birth['source_background']['direction']==birth['confirmation_background']['direction'];checks+=2
            assert birth['confirmation_background']['old_side_price_distance']>0 and birth['time']<key[1]<=birth['expiry'];checks+=2
    proof={'成功':True,'項目数':checks,'源と端点固定':True,'三足の厳密順序':True,'同足再参照で発火しない':True,'欠測stage破棄':True,'量不明と既知低量':True,'売買鏡像':True,'prefix同体':True,'同源一度':True,'源期限20分':True,'段階':counts,'SourceSHA':E.M.sha(E.HERE/'入口205.py')}
    E.M.save(E.HERE/'人工確認.json',proof);print(json.dumps({k:v for k,v in proof.items() if k!='段階'},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
