"""因子分解の純出生、方向対称、量不明の扱い、費用依存を金融前に確認する。"""
from copy import deepcopy
import json
import 入口197 as E
import 人工検査 as T
from 人工確認186 import mirror_m


def around_row(row,center):
    """
    機能: 指定価格を中心とする鏡像へ価格・指標を変換する。
    引数: row(dict),center(float)は評価q0の現在価格。
    返り値: dict。価格比の分母を固定した売買対称検査に用いる。
    """
    mirrored=T.mirror(row);shift=2*center-8000
    for key in ('close','prior_close','low','high','prior_low','prior_high'):mirrored[key]+=shift
    for k in ('m5','m15','m30'):
        if mirrored[k] is not None:
            for key in ('close','ema8','ema21'):mirrored[k][key]+=shift
    return mirrored


def around_context(context,center):
    """
    機能: q0と同じ中心で過去足も鏡像にし、指標の差と距離を保存する。
    引数: context(dict),center(float)。
    返り値: dictは履歴と前q0。
    """
    history=[mirror_m(m) for m in context['history']]
    for m in history:
        for key in ('close','ema8','ema21'):m[key]+=2*center-8000
    return {'history':history,'previous':around_row(context['previous'],center) if context['previous'] else None}


def main():
    """
    機能: 条件と純入口を固定する前に、人工的な因果境界・売買鏡像を検査する。
    引数: なし。
    返り値: None。費用変更は方向依存だけを診断し金融を生成しない。
    """
    checks=0;fee_stats=[]
    baseline=E.read(E.ROOT/'inputs/00192_TOPIXの構造と数量の純入口/純入口.json.gz')
    extras={(r['session'],r['time'],r['line']):r['extra'] for r in baseline}
    for form,name in enumerate(('純特徴183.json.gz','純特徴184直接.json.gz')):
        rows=E.read(E.ROOT/'inputs/TOPIX原順8列_20260921_20261116'/name);contexts=E.context_rows(rows)
        changes=[0]*4;total=0
        for i,row in enumerate(rows):
            key=(row['session'],row['time'],row['line']);ctx=contexts[key];extra=extras[key]
            side=E.native(row,ctx,extra,0)
            if side and row['band']=='POST':
                total+=1
                for p in range(4):changes[p]+=E.direction(row,side,p,41.8)!=E.direction(row,side,p,0.)
            if i%13:continue
            mirrored=around_row(row,row['close']);mc=around_context(ctx,row['close'])
            assert mirrored['close']==row['close'];checks+=1
            for quantity in (0,1):
                s=E.native(row,ctx,extra,quantity)
                assert s==-E.native(mirrored,mc,extra,quantity);checks+=1
                for policy in range(4):
                    actual=E.direction(row,s,policy)
                    assert actual==-E.direction(mirrored,-s,policy);checks+=1
                    for guard in range(3):assert E.night_guard(row,actual,s,guard)==-E.night_guard(mirrored,-actual,-s,guard);checks+=1
                assert E.day_guards(row,s)==tuple(-x for x in E.day_guards(mirrored,-s));checks+=1
            if row['rvol'] is not None:
                assert E.native(row,ctx,dict(extra,rvol5=9999),0)==E.native(row,ctx,dict(extra,rvol5=0),1);checks+=1
        assert changes[1:]==[0,0,0]
        fee_stats.append({'形成':form,'POST旧P0成立':total,'片道41.8円から0円で方向変化':dict(zip(E.POLICIES,changes))})
        prefix=E.context_rows(rows[:1001]);key=(rows[1000]['session'],rows[1000]['time'],rows[1000]['line'])
        assert prefix[key]==contexts[key];checks+=1
    row={'band':'POST','spread':.5,'atr':4.2,'close':4000.}
    assert E.direction(row,1,0,41.8)==-1 and E.direction(row,1,0,0.)==1;checks+=1
    for policy in (1,2,3):assert E.direction(row,1,policy,41.8)==E.direction(row,1,policy,0.);checks+=1
    proof={'成功':True,'項目数':checks,'同価格を中心に鏡像':True,'prefix同体':True,'既知量を5分量に置換しない':True,
        '費用だけ変更した方向診断':fee_stats,'SourceSHA':E.M.sha(E.HERE/'入口197.py')}
    E.M.save(E.HERE/'人工確認.json',proof);print(json.dumps(proof,ensure_ascii=False),flush=True)


if __name__=='__main__':main()
