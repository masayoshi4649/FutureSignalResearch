"""197の一要因比較を、固定正本と再現可能な出生として保存する。"""
from pathlib import Path
import json,zipfile,shutil,re,os,hashlib,sys
import 入口197 as E
sys.path.insert(0,str(E.ROOT/'work/196TOPIX'))
from 正式化196 import row_text
TRIAL=E.ROOT/'study/00197_TOPIXの量と観測機会と方向尺度を分離する'
INPUT=E.ROOT/'inputs/00197_TOPIXの一因子比較の純入口'


def ref(path):
    """
    機能: 正式資源の相対位置と指紋を記録する。
    引数: path(Path)。
    返り値: dictはpath/bytes/sha256。
    """
    return {'path':path.relative_to(E.ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':E.M.sha(path)}


def main():
    """
    機能: 57比較の条件・結果・原因と567セル表を恒久保存する。
    引数: なし。
    返り値: None。既定順位と入口を変更しない。
    """
    TRIAL.mkdir(parents=True,exist_ok=True);INPUT.mkdir(parents=True,exist_ok=True)
    files=('条件.json','人工確認.json','金融開始前固定.json','純成立診断.json','旧対照同体.json','全57組安定性.json.gz','全57組短表.json.gz','独立確認.json','原因診断.json','固定選択.json')
    for name in files:shutil.copy2(E.HERE/name,TRIAL/name)
    shutil.copy2(E.HERE/'純入口.json.gz',INPUT/'純入口.json.gz')
    manifest={'試行':197,'純出生':ref(INPUT/'純入口.json.gz'),'条件':ref(TRIAL/'条件.json'),'原板':'inputs/TOPIX原順8列_20260921_20261116/台帳.json','固定母体':'inputs/00192_TOPIXの構造と数量の純入口/入力台帳.json'}
    (INPUT/'入力台帳.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (INPUT/'README.md').write_text('# TOPIX 197の純入口\n\n[研究正本](../../study/00197_TOPIXの量と観測機会と方向尺度を分離する/README.md)。当初81場・34,424q0・57候補。追加2場の194結果受領後の新仮説。原板の複製を含めず、192純入口・旧190台帳は恒久入力を共用する。\n',encoding='utf-8')
    old_index=E.read(E.ROOT/'study/00196_TOPIXの市場尺度と量補完で方向を比較する/Source索引.json')
    sources=[E.ROOT/r['path'] for r in old_index if not r['path'].startswith('work/196TOPIX/')]+list(E.HERE.glob('*.py'))+[E.ROOT/'work/196TOPIX/正式化196.py',E.ROOT/'work/196TOPIX/入口196.py']
    sources=sorted(set(sources))
    with zipfile.ZipFile(TRIAL/'Source.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for path in sources:archive.write(path,path.relative_to(E.ROOT).as_posix())
        for name in ('入力台帳.json','条件_実装修正1.json'):
            path=E.M.HERE/name;archive.write(path,path.relative_to(E.ROOT).as_posix())
    (TRIAL/'Source索引.json').write_text(json.dumps([ref(p) for p in sources],ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    template=E.ROOT/'docs/議論/手法と時間スケールの汎用表_版8.md';body=template.read_text(encoding='utf-8').split('## 設定明細')[0]
    body=body.replace('# 手法と時間スケールの汎用表・版8','# 197 TOPIX・設定と結果（版8）').replace('全セルは未設定・未検証。','使用セルに設定IDを記す。').replace('未設定・未検証','未使用')
    used={'I01':{3:'S1 EMA8/21持続・差',4:'S1 中期背景',5:'S1旧D4背景'},'I02':{3:'S1/S4取得位置'},'I03':{3:'S1 MACD水準/旧D4増分'},'I04':{3:'S1 RSI範囲/旧D4増分'},
        'I08':{3:'S1 DI/ADX14',4:'S1 中期DI',5:'S1旧D4長期DI'},'I09':{3:'S2 ATR5/価格・幅'},'C01':{3:'S1 P0持続',4:'S1',5:'S1旧D4'},
        'C04':{3:'S2市場尺度/S4弱ADX'},'C07':{1:'S1/S4押戻し位置',3:'S1/S2/S4',4:'S1',5:'S1旧D4'},
        'P01':{1:'S4実体・終値位置・反対端'},'P05':{1:'S1逆進'},'V01':{0:'S3累積量/時計',1:'S3旧相対量',3:'S3不明時5分量'},
        'B01':{0:'S2旧費用比方向対照'},'E01':{0:'R1単純IFD'},'E02':{0:'R1固定SLと終了'}}
    count=0;lines=[]
    for line in body.splitlines():
        cells=[c.strip() for c in line.strip().strip('|').split('|')] if line.startswith('|') else []
        if len(cells)==11 and re.fullmatch(r'[A-Z][0-9]{2}',cells[0]):
            count+=1
            for i in range(9):cells[i+2]=used.get(cells[0],{}).get(i,'未使用')
            line='| '+' | '.join(cells)+' |'
        lines.append(line)
    assert count==63
    body='\n'.join(lines)+'\n';body=re.sub(r'\]\(([^)]+)\)',lambda m:']('+os.path.relpath((template.parent/m.group(1)).resolve(),TRIAL).replace('\\','/')+')',body)
    body+='''
## 設定明細と複合評価

S1は186 P0緩と旧190D4。異なる公表5分足3本のEMA傾き・順序・DI持続、15分DI、RSI・MACD水準、EMA距離と1分押戻しを保持する。S2は米前実反転を固定し、米後を旧費用比0.25又はATR5/当時価格0.0010・0.0011・0.0012で反転/元方向へ分ける。価格尺度は方向仮説、旧費用境界は料金だけで方向が変わる診断対照。196の新規費用比可否は加えない。

S3は旧1分量と、不明時だけ192同体の5分量補完。端点30秒・窓中減少/時計後退/90秒空白を確認。共通q0の旧形成/旧優先和集合と直交して比較する。旧条件が不成立だから直接形成へ乗り換えるわけではない。

S4はDay旧190D4のADX<18かつEMA差<0.4ATR棄却、又は同条件に実側1分実体<=−0.3ATRがある場合だけ棄却。Night旧190N01の実反転側は終値位置>=0.65、順行側は足中反対端がEMA21を0.1ATR超割らないことを確認。売買方向は変えない。

R1はDayA25/Night15pt/H60、保有予約合計1、終了15分前、miniTOPIX片道41.8円+0.25pt。57口座に新しい共同適合案なし。価格比の一点最適化を採用しない。[条件](条件.json)・[結果](全57組安定性.json.gz)・[原因](原因診断.json)・[README](README.md)。指標単独の効果ではない。未使用は無効判定ではない。

## 再現と版

[Source](Source.zip)・[索引](Source索引.json)・[純入口](../../inputs/00197_TOPIXの一因子比較の純入口/入力台帳.json)。版8は63手法×9尺度=567セル。194結果受領後に当初81場だけで探索した。追加2場への今後の適用も未見とは呼ばない。
'''
    body+='\n汎用表SHA256: '+hashlib.sha256(template.read_bytes()).hexdigest()+'\n';(TRIAL/'設定と結果.md').write_text(body,encoding='utf-8')
    states=E.read(E.HERE/'全57組安定性.json.gz')['metrics']
    header='| index | 取得 / 参加場 | 保有下限 | 未知 | 利益円 | 損失円 | 既知収支円 | 建玉 / 場中央値下限円 | 場末DD円 |\n| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |\n'
    report='''# 197 TOPIXの量と観測機会と方向尺度を分離する

2026-11-18作成。**新候補は採用せず、原因を分離して200へ継続する。** 共通の旧q0では5分量補完が取引を変えず、q0を広げたときに取引と未知が増えることが分かった。価格ATR比0.0010の部分改善は近傍で安定せず、最良一点だけを採用しない。

## 仮説と固定条件

[196](../00196_TOPIXの市場尺度と量補完で方向を比較する/README.md)では形成・量・方向を同時に変えたため交絡した。今回はNightの2母体（共通q0旧/旧優先和集合）×量2×方向4=16、旧N01の位置確認3、Day旧D4と往復除外2を組み合わせて3×19=57口座。[条件](条件.json)・[設定と結果](設定と結果.md)。旧母体のindex0は全34,424q0の方向と幅、金融台帳まで旧190D4N01と同体。

入力は当初81場（2026-09-21Day〜11-16Day）。全80発見・前48選択・後25・追加7・最終Dayを区別するが全て既使用。194の追加11/16Night・11/17Dayの結果受領後に設計しており、今後この2場へ適用しても未見性能とは言わない。追加場を本探索へ混ぜない。

単純IFD・DayA25/Night15pt・H60、保有予約合計1、開始待機なし、Day15:30/Night05:45まで全決済。miniTOPIX1枚・1pt=1,000円・片道41.8円+0.25pt。ラージBBOで取得を代用し実約定ではない。遅延1秒・取得TTL30秒、未知は0にせず枠を場末まで保持、0取得場も中央値に含める。旧P0に196の費用比可否<=0.5を加えず、一要因差を保つ。

## Day：損失の深さを抑えても期間安定は未達

index0=旧190D4、19=ADX5<18かつEMA差<0.4ATRだけ除外、38=加えて実側1分実体<=−0.3ATRのときだけ除外。母数41場。

'''+header+'\n'.join(row_text(i,'DAY',states) for i in (0,19,38))+'''

index19は全41場・未知0・両中央値正を維持して最大場損失57,585.2→39,501.6円を減らす。一方、前48収支−28,030.4→−36,111.6円、DD103,204.8→103,534.4円。最大損失だけの部分改善である。index38は逆実体を重ねると除外が3取得程度に留まり、最大場損失は改善しなかった。

## Night：量・観測機会・方向を分ける

index0〜3=共通旧/1分量、4〜7=共通旧/量不明時5分、8〜11=旧優先和集合/1分量、12〜15=旧優先和集合/量不明時5分。各4案の順は旧費用方向、価格ATR0.0010/0.0011/0.0012。16=旧反転側終値位置、17=旧順行側EMA21保持、18=両側確認。母数40場。

'''+header+'\n'.join(row_text(i,'NIGHT',states) for i in range(19))+'''

[一因子診断](原因診断.json)で、共通旧の量補完は純出生・台帳とも変更なし。q0だけ和集合へ広げると172→185取得、37→38場、未知7→9、両中央値は負になる。さらに量を補完すると217取得・全40場・保有37.24%だが未知21、建玉中央値下限−1,083.6円、場中央値下限は有限に確定できなくなる。未知は正常板空白5・返済時計不足16。量の既知/不明を閑散/活況の心理へ直接変換しない。

価格ATR0.0010は共通旧で損失540,353.6→516,353.6円、後25−22,266.8→−6,266.8円となるが、DD40,681.6→48,263.6円。0.0011は後25−49,266.8円、0.0012は−76,350.4円となる。0.0010だけの好成績を局面の安定判別とみなさない。

位置確認16はDD40,681.6→30,757.2円、後25−22,266.8→−516円を減らすが、未知8・場中央値下限0。単一の終値位置より、源q0から実側の構造回復と量が時間順に成立するかを200で比較する。

## 費用と市場尺度、検査、再現

価格/ATRを固定して片道手数料だけ41.8→0円にした純方向診断では、旧POST方向は旧形成1,023成立中108、直接1,147中127が逆になる。新価格比3近傍は0。これは料金定義への依存を切り分けた結果で、費用を0円にした金融成績を採用するものではない。[人工確認](人工確認.json)。価格比の0.10〜0.12%は相対値幅を区別する研究仮説で、その閾値の外部実証根拠はない。

人工177,374項目。[独立確認](独立確認.json)は21,905取得・金融284,765属性・別集計183,654属性・全q0枠216,604件を照合して不一致0。売買鏡像はq0現在価格を固定した中心で反転し、相対ATRの分母を不当に変えない。[固定選択](固定選択.json)は前48/全80の既定順位を保存、全体採用null。

[全57安定性](全57組安定性.json.gz)・[短表](全57組短表.json.gz)・[Source](Source.zip)・[索引](Source索引.json)・[恒久純入口](../../inputs/00197_TOPIXの一因子比較の純入口/README.md)。Python3.14.3/NumPy2.5.4/tzdata2026.6。

再現はSourceを相対構造どおり復元し、恒久純入口・条件・人工確認をwork/197TOPIXへ置き、新しい作業領域で`金融197.py`→`独立確認197.py`。183の原板参照は恒久TOPIX8列へ接続し、旧190台帳は192恒久入力から復元する。純出生は183/184特徴と192の追加特徴を用いて`人工確認197.py`→`入口197.py`。正本の閲覧はworkに依存しない。

200ではq0までの価格時計上のBBO観測被覆と、源q0から構造・量の順序確認を分ける。将来欠測や実返済可否を使って入口を除かない。
'''
    (TRIAL/'README.md').write_text(report,encoding='utf-8');print(json.dumps({'正式化':str(TRIAL),'表セル':567,'Source数':len(sources)},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
