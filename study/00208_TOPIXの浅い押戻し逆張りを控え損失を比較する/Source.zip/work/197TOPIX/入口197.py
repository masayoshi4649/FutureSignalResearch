"""TOPIXの観測機会・数量補完・方向尺度を一要因ずつ分けて比較する。"""
from pathlib import Path
from collections import deque
import sys,json
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
sys.path.insert(0,str(ROOT/'work/192TOPIX'))
import 入口192 as P
M=P.M;read=P.read
DAY=('D0_旧190D4','D1_弱ADXかつ狭MA差を除外','D2_弱ADX狭MA差かつ強い逆実体を除外')
POLICIES=('旧費用境界','価格ATR0010','価格ATR0011','価格ATR0012')
SPECS=tuple((connection,quantity,policy) for connection in (0,1) for quantity in (0,1) for policy in range(4))
NIGHT=tuple(f'N{i:02d}_{"共通旧" if c==0 else "旧優先和集合"}_{"1分量" if q==0 else "量不明時5分"}_{POLICIES[p]}' for i,(c,q,p) in enumerate(SPECS))+('N16_旧反転側の終値位置確認','N17_旧順行側のEMA21保持','N18_旧両側位置確認')
NAMES=tuple(d+'_'+n for d in DAY for n in NIGHT)


def context_rows(rows):
    """
    機能: 当時の異なる公表5分足3本と前q0を構築する。
    引数: rows(list[dict])は一形成の当初81場。
    返り値: dict[tuple,dict]。同一足を複数回数えず場をまたがない。
    """
    result={};history=deque(maxlen=3);scene=None;ident=None;previous=None
    for row in rows:
        if row['session']!=scene:history.clear();scene=row['session'];ident=None;previous=None
        current=tuple(row['m5'][k] for k in ('count','end','published'))
        if current!=ident:history.append(row['m5']);ident=current
        result[(scene,row['time'],row['line'])]={'history':list(history),'previous':previous}
        previous=row
    return result


def native(row,context,extra,quantity):
    """
    機能: P0の価格条件を保持し、量補完だけを切り替える。
    引数: row/context/extra(dict),quantity(int)は0が旧1分、1が不明時だけ5分。
    返り値: intは旧技術方向。追加の費用比可否条件を入れない。
    """
    rv=row['rvol']
    if quantity and rv is None:rv=extra['rvol5']
    working=dict(row,rvol=rv)
    signs=[side for side in (1,-1) if P.U.roles(working,side,context,False)[0]]
    return signs[0] if len(signs)==1 else 0


def direction(row,side,policy,fee_oneway=41.8):
    """
    機能: 旧費用境界と市場の相対ATR境界を、同一価格特徴上で比較する。
    引数: row(dict),side(int),policy(int)は0〜3,fee_oneway(float)は方向依存診断用円。
    返り値: intは実売買方向。米前一律反転は固定比較仮説。
    """
    if not side:return 0
    if row['band']=='PRE':return -side
    if policy==0:flip=(row['spread']+.5+2*fee_oneway/1000)/row['atr']>.25
    else:flip=row['atr']/row['close']<(0.,.0010,.0011,.0012)[policy]
    return -side if flip else side


def night_guard(row,side,base_native,guard):
    """
    機能: 旧入口の方向を変更せず、実方向ごとの取得位置だけ確認する。
    引数: row(dict),side/base_native(int),guard(int)は0反転側、1順行側、2両側。
    返り値: int。反転側は終値位置0.65、順行側は足中もEMA21を0.1ATR超割らない。
    """
    if not side:return 0
    reverse=side==-base_native
    if reverse and guard in (0,2):
        position=row['position'] if side==1 else 1-row['position']
        if position<.65:return 0
    if not reverse and guard in (1,2):
        extreme=row['low'] if side==1 else row['high']
        if side*(extreme-row['m5']['ema21'])<-.1*row['atr']:return 0
    return side


def day_guards(row,side):
    """
    機能: 旧190D4の方向・幅を保ち、弱方向の往復と強い逆実体を別に除外する。
    引数: row(dict|None)は直接形成、side(int)は旧入口。
    返り値: tuple[int,int,int]はD0〜D2。
    """
    if not side or row is None:return (side,side,side)
    weak=row['m5']['adx']<18 and abs(row['m5']['ema8']-row['m5']['ema21'])/row['atr']<.4
    adverse=side*row['body']<=-.3
    return (side,0 if weak else side,0 if weak and adverse else side)


def decide(key,maps,contexts,extra,baseline):
    """
    機能: 3Day×19Nightの57入口を当時特徴だけから作る。
    引数: key(tuple),maps/contexts/extra/baseline(dict)。
    返り値: dictは純入口。旧優先は旧の条件不成立時に直接へ乗り換えない。
    """
    ro=maps[0].get(key);rd=maps[1].get(key);common=ro is not None and rd is not None
    band=baseline['band'];signals=[];widths=[];origins=[]
    if band=='DAY':
        for i,side in enumerate(day_guards(rd,baseline['signals'][0])):
            for _ in NIGHT:signals.append(side);widths.append(baseline['widths'][0]);origins.append(DAY[i])
    else:
        nights=[]
        for c,q,p in SPECS:
            row=ro if c==0 and common else (ro if ro is not None else rd) if c==1 else None
            if row is None:nights.append((0,'共通q0外'));continue
            form=0 if row is ro else 1;side=native(row,contexts[form][key],extra,q)
            actual=direction(row,side,p)
            quantity_origin='1分量' if row['rvol'] is not None else '量不明時5分' if q else '1分量不明'
            nights.append((actual,('旧' if form==0 else '直接')+'_'+quantity_origin+'_'+POLICIES[p]))
        side=baseline['signals'][0]
        base_native=native(ro,contexts[0][key],extra,0) if ro is not None else 0
        for guard in range(3):nights.append((night_guard(ro,side,base_native,guard) if ro else 0,NIGHT[16+guard]))
        for _ in DAY:
            for side,origin in nights:signals.append(side);widths.append(15.);origins.append(origin)
    assert signals[0]==baseline['signals'][0] and widths[0]==baseline['widths'][0]
    return {'session':key[0],'time':key[1],'line':key[2],'band':band,'signals':signals,'widths':widths,'origins':origins,'extra':extra}


def prepare():
    """
    機能: 追加2場の結果受領後の新仮説として、旧81場の条件を金融前に固定する。
    引数: なし。
    返り値: None。旧192/196条件や金融を変更しない。
    """
    features={form:read(ROOT/'inputs/TOPIX原順8列_20260921_20261116'/name) for form,name in enumerate(('純特徴183.json.gz','純特徴184直接.json.gz'))}
    maps={form:{(r['session'],r['time'],r['line']):r for r in rows} for form,rows in features.items()}
    contexts={form:context_rows(rows) for form,rows in features.items()}
    baseline=read(ROOT/'inputs/00192_TOPIXの構造と数量の純入口/純入口.json.gz');result=[]
    for row in baseline:
        key=(row['session'],row['time'],row['line']);result.append(decide(key,maps,contexts,row['extra'],row))
    M.save(HERE/'純入口.json.gz',result)
    sources=[Path(__file__),ROOT/'work/192TOPIX/入口192.py',ROOT/'work/186TOPIX/入口186.py',M.HERE/'入口とIFD.py']
    cfg={'試行':197,'候補':list(NAMES),'Day候補':list(DAY),'Night候補':list(NIGHT),'規模':57,
        '情報区分':'194追加2場の固定候補結果を受領後の新仮説。探索は当初81場のみ。後日の追加2場適用も未見とは呼ばない。',
        'Day条件':'D0=旧190D4。D1はADX5<18かつ|EMA8-EMA21|<0.4ATR5を除外。D2は同条件に実側1分実体<=-0.3ATR5も伴う時だけ除外。幅は旧と同体。',
        'Night因子':'共通q0の旧形成/旧優先の和集合×旧1分量/1分不明時だけ5分量×方向4。価格条件はP0緩同体、196に追加した費用比可否<=0.5は入れない。',
        '方向':'PRE=-P0。POSTは旧(spread+0.5836)/ATR5>0.25又はATR5/close<0.0010/0.0011/0.0012で実反転、他はP0。3近傍を期間別に比較、最良1点だけで採用しない。',
        '価格尺度の理由':'指数価格に対する5分の値幅0.10〜0.12%を低値幅/高値幅の仮説境界にする。旧費用比との因果分離が目的で、この閾値自体の外部実証根拠はない。',
        '位置確認':'旧190N01限定の3対照。実反転側は実側1分終値位置>=0.65、元順行側は実側1分反対端がEMA21を0.1ATR超割らない。両側確認も比較。元方向を変更しない。',
        '量':'旧1分が既知0なら5分へ置換しない。5分は192の当時原累積量・時計・減少・空白確認と同体。量可用性を市場の閑散と呼ばない。',
        '幅期限':'旧190と同体DayA25/Night15pt/H60、単純IFD、保有予約合計1、開始待機なし、終了15分前決済、miniTOPIX1枚片道41.8円+0.25pt。',
        'Source':{p.relative_to(ROOT).as_posix():M.sha(p) for p in sources},'純入口SHA':M.sha(HERE/'純入口.json.gz'),
        '固定入力192SHA':M.sha(ROOT/'inputs/00192_TOPIXの構造と数量の純入口/純入口.json.gz')}
    assert not (HERE/'条件.json').exists();M.save(HERE/'条件.json',cfg)
    M.save(HERE/'純成立診断.json',{'q0':len(result),'候補':{name:sum(r['signals'][i]!=0 for r in result) for i,name in enumerate(NAMES)}})
    print(json.dumps({'純q0':len(result),'候補':len(NAMES),'純入口SHA':cfg['純入口SHA']},ensure_ascii=False),flush=True)


if __name__=='__main__':prepare()
