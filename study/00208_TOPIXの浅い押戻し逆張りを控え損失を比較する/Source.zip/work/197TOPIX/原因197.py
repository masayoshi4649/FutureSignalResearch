"""197の単一要因差と期間別の閾値近傍を、採用判断と分けて固定する。"""
from collections import Counter
import json
import 入口197 as E


def summary(state,band):
    """
    機能: 一要因の比較に必要な損失・参加・未知・期間差を抜き出す。
    引数: state(dict),band(str)。
    返り値: dictは金融正本に基づく要約。
    """
    g=state['groups'][band];t=g['trades'];s=g['sessions'];p=g['path']['known_contribution']
    return {'取得':t['all_count'],'参加場':s['participating_count'],'未知':t['unknown_count'],'保有下限':g['holding']['held_lower_ratio'],
        '利益':t['known_profit'],'損失':t['known_loss'],'既知純益':t['known_net'],'建玉中央値下限':t['net_median']['lower'],'場中央値下限':s['net_median']['lower'],
        '最大場損失':-min(0,p['worst_scene_net']),'場末DD':p['max_drawdown']['amount'],
        '期間純益':{k:state['periods'][k][band]['trades']['known_net'] for k in ('前48','後25','追加7','本日1')}}


def main():
    """
    機能: 全57口座を読取り、ペアごとの差と候補の固定順位を保存する。
    引数: なし。
    返り値: None。過去の最高値へ置換せず、未適合の順位1位も不適格と残す。
    """
    data=E.read(E.HERE/'全57組安定性.json.gz');states=data['metrics'];pure=E.read(E.HERE/'純入口.json.gz')
    comparisons=[]
    for old,new,reason in ((0,4,'共通旧の量だけ'),(0,8,'q0範囲だけ'),(8,12,'和集合の量だけ'),(0,1,'価格ATR0010方向だけ'),(0,16,'反転実側の取得位置だけ'),(0,19,'Day弱ADX狭MA差だけ')):
        band='DAY' if new==19 else 'NIGHT'
        changes=sum(r['signals'][old]!=r['signals'][new] for r in pure if (r['band']=='DAY')==(band=='DAY'))
        comparisons.append({'旧index':old,'新index':new,'因子':reason,'純出生方向差件数':changes,'旧':summary(states[old],band),'新':summary(states[new],band)})
    unknowns=[]
    for i in (0,1,4,8,12,16):
        ledger=E.read(E.HERE/'金融正本'/(states[i]['id']+'.json.gz'))['ledger']
        unknowns.append({'index':i,'未知理由':dict(Counter(ledger['unknown_reason'][n] for n in range(len(ledger['net'])) if 'Night' in ledger['scene'][n] and not ledger['known'][n]))})
    result={'比較':comparisons,'近傍':{str(i):summary(states[i],'NIGHT') for i in (0,1,2,3,8,9,10,11,12,13,14,15)},'未知':unknowns,
        '解釈':'量補完は共通旧で純出生・台帳に変化なし。和集合で初めて補完が成立し、参加と未知が増える。価格比0.0010だけを最良値として採用しない。',
        'SourceSHA':E.M.sha(E.HERE/'原因197.py')}
    E.M.save(E.HERE/'原因診断.json',result)
    selection={'情報区分':'194の追加2場結果を受領後に設計。全80発見/前48選択は既使用81内の比較であり未見ではない。',
        '全体採用':None,'理由':'全Nightの参加/両中央値/未知条件を共同で満たす新案なし。価格ATRの近傍で損失経路が不安定。',
        '固定順位':{k:v[:1] for k,v in data['順位'].items()},'事後部分参考':{'Day':19,'Night':1},
        '条件SHA':E.M.sha(E.HERE/'条件.json'),'純入口SHA':E.M.sha(E.HERE/'純入口.json.gz')}
    E.M.save(E.HERE/'固定選択.json',selection)
    print(json.dumps({'一因子比較':len(comparisons),'未知':unknowns},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
