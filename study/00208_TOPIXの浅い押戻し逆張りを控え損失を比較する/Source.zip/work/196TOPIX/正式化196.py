"""196の条件・正本・失敗原因・実装修正履歴を恒久保存する。"""
from pathlib import Path
import json,zipfile,shutil,re,os,hashlib
import 入口196 as E
TRIAL=E.ROOT/'study/00196_TOPIXの市場尺度と量補完で方向を比較する'
INPUT=E.ROOT/'inputs/00196_TOPIXの市場尺度による純入口'


def ref(path):
    """
    機能: 正式資源の相対位置と指紋を記録する。
    引数: path(Path)。
    返り値: dictはpath/bytes/sha256。
    """
    return {'path':path.relative_to(E.ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':E.M.sha(path)}


def row_text(index,band,states):
    """
    機能: 正本の利益・損失・参加・中央値を表1行へ変換する。
    引数: index(int),band(str),states(list[dict])。
    返り値: strはMarkdownの行。
    """
    g=states[index]['groups'][band];t=g['trades'];s=g['sessions'];p=g['path']['known_contribution']
    med=lambda x:'下限なし' if x is None else f'{x:+,.1f}'
    return f"| {index} | {t['all_count']} / {s['participating_count']} | {g['holding']['held_lower_ratio']:.2%} | {t['unknown_count']} | {t['known_profit']:,.1f} | {t['known_loss']:,.1f} | {t['known_net']:+,.1f} | {med(t['net_median']['lower'])} / {med(s['net_median']['lower'])} | {p['max_drawdown']['amount']:,.1f} |"


def main():
    """
    機能: 52候補の正本と567セル、Source、純出生を正式な保存先へ置く。
    引数: なし。
    返り値: None。金融条件・出生・台帳を変更しない。
    """
    TRIAL.mkdir(parents=True,exist_ok=True);INPUT.mkdir(parents=True,exist_ok=True)
    files=('条件.json','人工確認.json','金融開始前固定.json','純成立診断.json','旧対照同体.json','全52組安定性.json.gz','全52組短表.json.gz','独立確認.json','実装修正確認.json','原因診断.json')
    for name in files:shutil.copy2(E.HERE/name,TRIAL/name)
    shutil.copy2(E.HERE/'純入口.json.gz',INPUT/'純入口.json.gz')
    manifest={'試行':196,'純出生':ref(INPUT/'純入口.json.gz'),'条件':ref(TRIAL/'条件.json'),
        '固定192入力':'inputs/00192_TOPIXの構造と数量の純入口/入力台帳.json','原板':'inputs/TOPIX原順8列_20260921_20261116/台帳.json'}
    (INPUT/'入力台帳.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (INPUT/'README.md').write_text('# TOPIX 196の純入口\n\n[研究正本](../../study/00196_TOPIXの市場尺度と量補完で方向を比較する/README.md)。当初81場・34,424q0・52候補。追加2場金融前に封印。全場は既使用であり未知検証ではない。原板の複製を含まず、旧190対照は192の恒久入力を共用する。\n',encoding='utf-8')
    sources=list(E.HERE.glob('*.py'))+list((E.ROOT/'work/192TOPIX').glob('*.py'))+[E.ROOT/p for p in (
        'work/186TOPIX/入口186.py','work/186TOPIX/人工確認186.py','work/183TOPIX/入口とIFD.py','work/183TOPIX/金融を比較する.py','work/183TOPIX/人工検査.py',
        'work/183損失安定性/安定性183.py','work/183損失安定性/TOPIXを独立検算する.py','work/183損失安定性/新候補の集計を独立検査する.py',
        'scripts/入口分析/分析.py','scripts/複合検証/再生.py','study/00001_MACDと方向条件の比較/再現.py')]
    sources=sorted(set(sources))
    with zipfile.ZipFile(TRIAL/'Source.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for path in sources:archive.write(path,path.relative_to(E.ROOT).as_posix())
        for name in ('入力台帳.json','条件_実装修正1.json'):
            path=E.M.HERE/name;archive.write(path,path.relative_to(E.ROOT).as_posix())
        for path in (E.HERE/'実装修正前').glob('*'):
            if path.is_file():archive.write(path,path.relative_to(E.ROOT).as_posix())
    (TRIAL/'Source索引.json').write_text(json.dumps([ref(p) for p in sources],ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    template=E.ROOT/'docs/議論/手法と時間スケールの汎用表_版8.md';body=template.read_text(encoding='utf-8').split('## 設定明細')[0]
    body=body.replace('# 手法と時間スケールの汎用表・版8','# 196 TOPIX・設定と結果（版8）').replace('全セルは未設定・未検証。','使用セルに設定IDを記す。').replace('未設定・未検証','未使用')
    used={'I01':{3:'S1 EMA8/21持続・差',4:'S1 中期DI背景',5:'S1 旧D4補完背景'},'I02':{3:'S1 EMA距離/ATR'},
        'I03':{3:'S2 MACD水準・旧D4増分'},'I04':{3:'S2 RSI水準・旧D4増分'},'I08':{3:'S1 DI/ADX14',4:'S1 中期DI',5:'S1 旧D4長期DI'},
        'I09':{3:'S3 ATR比/過去12足中央値/IFD幅',4:'S3 ATR5/ATR15'},'I17':{1:'S4 20分端点ER'},
        'C01':{3:'S1/S2 P0持続',4:'S1',5:'S1旧D4'},'C04':{3:'S3/S4値幅と効率'},'C07':{1:'S5戻り',3:'S1〜S4',4:'S1/S3',5:'S1旧D4'},
        'P01':{1:'S5実体・足幅'},'P05':{1:'S5前足からの逆進'},'V01':{0:'S6累積量/時計',1:'S6旧1分相対量',3:'S6不明時5分量'},
        'B01':{0:'S7正常BBOと費用可否'},'E01':{0:'R1単純IFD'},'E02':{0:'R1固定SLと終了'}}
    lines=[];count=0
    for line in body.splitlines():
        cells=[c.strip() for c in line.strip().strip('|').split('|')] if line.startswith('|') else []
        if len(cells)==11 and re.fullmatch(r'[A-Z][0-9]{2}',cells[0]):
            count+=1
            for i in range(9):cells[i+2]=used.get(cells[0],{}).get(i,'未使用')
            line='| '+' | '.join(cells)+' |'
        lines.append(line)
    assert count==63
    body='\n'.join(lines)+'\n';body=re.sub(r'\]\(([^)]+)\)',lambda m:']('+os.path.relpath((template.parent/m.group(1)).resolve(),TRIAL).replace('\\','/')+')',body)
    body+='''
## 設定明細と複合評価

S1/S2は186 P0緩/厳の複合条件。3個の異なる公表5分足の傾き・EMA順序・DI持続、15分DI、RSI範囲、EMAからの距離、MACD水準と1分押戻しを用いる。DayのD0は190D4同体、D1は旧q0優先の厳P0、D2は直接厳価格と小戻り、D3は直接P0緩からADX<18かつMA差<0.4ATRを除く。全ての閾値は[条件](条件.json)とSourceで固定。

S3は米後の方向対照。ATR5/ATR15が0.35又は0.5未満、当該足を除く直前12公表5分ATR中央値未満、S4 ER20<0.25、S5逆進がMA差超、又は3尺度2票合意を用いる。12足は同一足IDを重複せずend間隔300秒を要求、場越しなし。不明時の既定行動も条件に記録。米前一律反転は比較上の固定仮説で、心理根拠の確定ではない。

S4は192と同体のq0直前1分を除いた20分端点ER。S6は1分相対量が不明のときだけ原累積5分量/前4窓で補完。全端点30秒内・量時計<=価格時計・窓途中の累積減少/時計後退/90秒空白なしを要求。既知0を不明に変えない。S7費用比<=0.5は新案の可否だけに用い、旧N01の費用方向を改変しない。

R1はDayA25/Night15pt・H60・保有予約合計1・終了15分前。片道41.8円+0.25pt、miniTOPIX1枚。52組に新しい適合案なし。指標単独の効果とはしない。[全正本](全52組安定性.json.gz)・[原因](原因診断.json)・[README](README.md)。未使用セルは無効の判定ではない。

## 再現と版

[Source](Source.zip)・[索引](Source索引.json)・[恒久純入口](../../inputs/00196_TOPIXの市場尺度による純入口/入力台帳.json)。版8は63手法×9尺度=567セル。旧81は全て既使用、192以後の追加2場金融前に純条件を固定した。
'''
    body+='\n汎用表SHA256: '+hashlib.sha256(template.read_bytes()).hexdigest()+'\n'
    (TRIAL/'設定と結果.md').write_text(body,encoding='utf-8')
    states=E.read(E.HERE/'全52組安定性.json.gz')['metrics']
    header='| index | 取得 / 参加場 | 保有下限 | 未知 | 利益円 | 損失円 | 既知収支円 | 建玉 / 場中央値下限円 | 場末DD円 |\n| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |\n'
    report='''# 196 TOPIXの市場尺度と量補完で方向を比較する

2026-11-18作成。**新案は採用しない。** Nightは全40場へ広がったが、未知と損失が増え、全新案で両中央値が負になった。Dayの最大損失減だけを全面改善と扱わず、取得母体・量・方向を分ける197へ進む。研究はここで停止しない。

## 仮説・固定条件・情報区分

[192](../00192_TOPIXの価格構造と数量尺度で方向を判別する/README.md)では費用比の方向反転が料金の仮定に依存し、複数時間軸で全条件同時回復を要求すると希少になった。196ではP0の押戻しを基礎に、市場尺度で米後の方向を変え、1分量不明時の5分量補完と形成の追加で参加を広げる。4Day×13Night=52口座。[条件](条件.json)・[設定と結果](設定と結果.md)。

入力は2026-09-21Day〜2026-11-16Dayの当初81場。全80発見・前48選択・後25・追加7・最終Dayを区別するが、全て既使用。11/16Nightと11/17Dayの金融を読む前に入口・閾値・Source・純出生を封印した。この試行に追加2場の結果を混ぜない。

単純IFD、Dayは選択形成の公表ATR5×2.5を5〜25ptで0.25刻み切上げ、Night±15pt、H60。保有/予約合計1、開始待機なし、Day15:30/Night05:45までに全決済。miniTOPIX1枚、1pt=1,000円、片道税込41.8円と0.25pt滑り。ラージBBOによる取得代用であり、mini実約定ではない。注文遅延1秒、取得TTL30秒、正常板300秒超空白・返済時計不足は未知。未知は0円にせず枠を場末まで保持し、0取得場を中央値から落とさない。

## Dayの結果

index0=旧190D4、13=旧厳を直接で履歴補完、26=直接厳価格と小押戻し量、39=直接P0と弱方向往復除外。母数41場。

'''+header+'\n'.join(row_text(i,'DAY',states) for i in (0,13,26,39))+'''

D3（index39）は最大場損失57,585.2→39,501.6円を減らすが、未知0→1、DD103,204.8→121,118円へ悪化する。前48のDay収支は−28,030.4→−53,695.2円。既知量の取得183件は+49,951.2円、5分量補完11件は−41,836円・未知1。これは取得枠も変わる事後群分けであり、量補完の単独因果効果とは言わない。

## Nightの結果

index0=旧190N01。1〜6は旧q0優先・直接補完、7〜12は直接形成。各組内はATR比0.35/0.5、過去ATR中央値、ER、逆進対MA差、3尺度合意の順。母数40場。

'''+header+'\n'.join(row_text(i,'NIGHT',states) for i in range(13))+'''

旧190N01は前48+220,561.2円、後25−22,266.8円で、全期間の黒字だけで安定とはしない。新案は全場取得に広がったが、未知7→13〜18件、両中央値は全案負。ATR比0.35の旧優先案は前48−26,276.4円、後25−76,353.6円だった。

## 原因を分ける

[原因診断](原因診断.json)では、旧優先ATR比0.35の213取得のうち、5分量補完63件は既知−37,930.8円・未知10。旧対照と同じ要求で実方向が逆になった38取得は既知−104,593.2円。新候補だけの取得77件は既知−123,434円・未知12。同じ要求同側98件は+148,641.6円だった。形成・方向・量・枠の変更が交絡しており、ATRの心理仮説だけが失敗したとは結論しない。

同案の未知17件は返済時計不足13・正常板300秒超空白4。直接ATR比0.35も未知16件のうち返済時計不足15。量可用性や原価格時計の不足を「市場が閑散だった」と呼ばない。未来の欠測を知って入口を除くこともしない。

次の197は旧価格条件をそのまま残し、q0の範囲・量補完・方向尺度の一因子対照を行う。旧費用境界と価格ATR比0.0010/11/12の近傍を比較し、最良1点の選択で結論しない。

## 検査・修正履歴・再現

[人工確認](人工確認.json)32,272項目、[独立確認](独立確認.json)20,649取得・金融268,437属性・別集計167,544属性・全q0枠179,770件を照合。不一致0。旧190の台帳・保有区間も同体。

金融コード複製時に候補数置換が期間スライスへ入り、初回の後25/追加7が誤っていた。売買台帳や入口は変更していない。`48:73`/`73:80`へ修正し、期間件数80/48/25/7/1のassertを追加して再計算。全52台帳のSHA、全81/全80/前48/最終Dayは同体。[修正確認](実装修正確認.json)。旧コード・誤集計・旧封印はSource内の実装修正前へ保存した。修正を新しい売買条件と混同しない。

[全52安定性](全52組安定性.json.gz)・[短表](全52組短表.json.gz)・[Source](Source.zip)・[索引](Source索引.json)・[恒久純入口](../../inputs/00196_TOPIXの市場尺度による純入口/README.md)。Python3.14.3/NumPy2.5.4/tzdata2026.6。

再現はSourceを同じ相対構造へ復元し、恒久純入口・条件・人工確認をwork/196TOPIXへ配置、金融開始前固定がない新しい作業領域で`金融196.py`→`独立確認196.py`を実行する。183の価格台帳は恒久TOPIX8列へ接続する。旧190台帳は192の恒久入力から復元する。純出生の再生成は恒久183/184特徴・192純入口を使って`人工確認196.py`→`入口196.py`。正式な閲覧正本はworkの存在に依存しない。
'''
    (TRIAL/'README.md').write_text(report,encoding='utf-8')
    print(json.dumps({'正式化':str(TRIAL),'表セル':567,'Source数':len(sources)},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
