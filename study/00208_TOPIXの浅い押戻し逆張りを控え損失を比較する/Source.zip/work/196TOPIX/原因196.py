"""196の取得増加を、方向の良否だけに帰さず量と形成と枠の由来で診断する。"""
from collections import defaultdict,Counter
import json
import 入口196 as E


def summarize(ledger,indices):
    """
    機能: 実際に取得した建玉群だけの既知利益損失と未知理由を数える。
    引数: ledger(dict),indices(list[int])。
    返り値: dict。未取得の仮想利益を算出しない。
    """
    values=[ledger['net'][i] for i in indices if ledger['known'][i]]
    return {'取得':len(indices),'既知利益':sum(max(0,v) for v in values),'既知損失':sum(max(0,-v) for v in values),
        '既知純益':sum(values),'未知':len(indices)-len(values),'場数':len({ledger['scene'][i] for i in indices}),
        '未知理由':dict(Counter(ledger['unknown_reason'][i] for i in indices if not ledger['known'][i]))}


def main():
    """
    機能: 固定196金融を当時特徴と照合し、仮説197とは別に事後分解を残す。
    引数: なし。
    返り値: None。入口・順位・金融は変更しない。
    """
    features={form:E.read(E.ROOT/'inputs/TOPIX原順8列_20260921_20261116'/name) for form,name in enumerate(('純特徴183.json.gz','純特徴184直接.json.gz'))}
    maps={form:{(r['session'],r['time'],r['line']):r for r in rows} for form,rows in features.items()}
    states=E.read(E.HERE/'全52組安定性.json.gz')['metrics'];result=[]
    baseline=E.read(E.HERE/'金融正本'/(states[0]['id']+'.json.gz'))['ledger']
    base_keys={(baseline['scene'][i],baseline['request_time'][i],baseline['request_line'][i]):baseline['side'][i] for i in range(len(baseline['net']))}
    for ci in list(range(13))+[13,26,39]:
        band='NIGHT' if ci<13 else 'DAY';ledger=E.read(E.HERE/'金融正本'/(states[ci]['id']+'.json.gz'))['ledger'];groups=defaultdict(list)
        for i,scene in enumerate(ledger['scene']):
            if ('Night' in scene)!=(band=='NIGHT'):continue
            key=(scene,ledger['request_time'][i],ledger['request_line'][i]);ro=maps[0].get(key);rd=maps[1].get(key)
            if band=='NIGHT':form=0 if (ci==0 or 1<=ci<=6) and ro is not None else 1
            else:form=0 if ci==13 and ro is not None else 1
            row=maps[form][key]
            quantity='旧1分量既知' if row['rvol'] is not None else '旧1分不明の5分補完'
            existence='共通q0' if ro is not None and rd is not None else '旧だけq0' if ro is not None else '直接だけq0'
            relation='共通取得同側' if base_keys.get(key)==ledger['side'][i] else '共通取得逆側' if key in base_keys else 'この候補だけ取得'
            for group in ('全体','量/'+quantity,'形成/'+str(form)+'/'+existence,'旧枠との関係/'+relation,'帯/'+str(ledger['phase'][i])):groups[group].append(i)
        result.append({'index':ci,'id':states[ci]['id'],'band':band,'集計':{name:summarize(ledger,indices) for name,indices in groups.items()}})
    payload={'区分':'固定196の事後診断。母数の変わる群間差を量補完の単独因果効果とは呼ばない。197で一因子対照を行う。',
        '原因':'196は量・観測機会・方向・費用可否を同時変更した。全場取得への増加だけで入口改善とは判断できない。',
        '集計':result,'SourceSHA':E.M.sha(E.HERE/'原因196.py')}
    E.M.save(E.HERE/'原因診断.json',payload)
    for r in result:
        if r['index'] in (1,7,39):print(json.dumps(r,ensure_ascii=False),flush=True)


if __name__=='__main__':main()
