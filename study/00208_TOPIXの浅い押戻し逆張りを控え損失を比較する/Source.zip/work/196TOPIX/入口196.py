"""価格の尺度と履歴で方向を分け、費用による方向反転を比較から外す。"""
from pathlib import Path
from collections import deque,Counter
from statistics import median
import math,sys,json
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
sys.path.insert(0,str(ROOT/'work/192TOPIX'))
import 入口192 as P
M=P.M
read=P.read
DAY=('D0_旧190D4','D1_旧厳を直接で履歴補完','D2_直接厳価格と小押戻し量','D3_直接押戻しで弱方向往復を除外')
POLICIES=('ATR比035','ATR比050','過去12足ATR中央値','20分価格効率','逆進とMA差','三尺度の合意')
NIGHT=('N00_旧190N01',)+tuple(f'N{1+form*6+i:02d}_{"旧優先直接補完" if form==0 else "直接"}_{name}' for form in (0,1) for i,name in enumerate(POLICIES))
NAMES=tuple(d+'_'+n for d in DAY for n in NIGHT)


def context_rows(rows):
    """
    機能: 異なる公開足だけを更新し、直前12足ATR中央値を当該足抜きで計算する。
    引数: rows(list[dict])は固定形成のq0。
    返り値: dict[tuple,dict]は3足持続/前q0/過去12ATR/可用性。場をまたがない。
    """
    out={};history=deque(maxlen=13);scene=None;ident=None;previous=None
    for r in rows:
        if r['session']!=scene:history.clear();ident=None;previous=None;scene=r['session']
        current=tuple(r['m5'][k] for k in ('count','end','published'))
        if current!=ident:history.append(r['m5']);ident=current
        before=list(history)[:-1]
        usable=len(before)==12 and all(before[i]['end']-before[i-1]['end']==300 for i in range(1,12))
        usable=usable and history[-1]['end']-before[-1]['end']==300
        value=median(p['atr'] for p in before) if usable else None
        out[(scene,r['time'],r['line'])]={'history':list(history)[-3:],'previous':previous,'past_atr_median':value,
            'past_atr_count':len(before),'past_atr_span':before[-1]['end']-before[0]['end']+300 if before else None}
        previous=r
    return out


def quantity(row,extra):
    """
    機能: 旧1分量が不明な場合だけ可視5分量へ補完する。
    引数: row/extra(dict)。
    返り値: float|Noneは相対量。不明を0にしない。
    """
    return row['rvol'] if row['rvol'] is not None else extra['rvol5']


def native(row,ctx,extra,strict=False,small=False):
    """
    機能: P0の価格条件を保ち、量と費用可否を分離して判断する。
    引数: row/ctx/extra(dict),strict(bool),small(bool)は小戻り量補完。
    返り値: intは技術方向。
    """
    rv=quantity(row,extra)
    if rv is None or rv<(.5 if small or not strict else 1.):return 0
    if (row['spread']+.5836)/row['atr']>.5:return 0
    if small and (row['range']>.75 or abs(row['body'])>.3):return 0
    working=dict(row,rvol=1. if small else rv)
    signs=[side for side in (1,-1) if P.U.roles(working,side,ctx,strict)[0]]
    return signs[0] if len(signs)==1 else 0


def night_direction(row,ctx,extra,policy):
    """
    機能: P0技術方向を市場尺度で選び、費用水準から方向を決めない。
    引数: row/ctx/extra(dict),policy(int)は0〜5。
    返り値: tuple[int,str]は実側と判断由来。米前反転は既使用探索に基づく対照的選択。
    """
    s=native(row,ctx,extra)
    if not s:return 0,'P0不成立'
    if row['band']=='PRE':return -s,'米前P0実反転'
    ratio=row['atr']/row['m15']['atr'];ref=ctx['past_atr_median'];er=extra['er20'] if extra['range_known'] else None
    reverse_move=-s*row['progress']*row['atr'];gap=abs(row['m5']['ema8']-row['m5']['ema21'])
    if policy==0:flip=ratio<.35
    elif policy==1:flip=ratio<.5
    elif policy==2:
        if ref is None:return s,'過去ATR不足は元方向'
        flip=row['atr']<ref
    elif policy==3:
        if er is None:return s,'価格効率不明は元方向'
        flip=er<.25
    elif policy==4:flip=reverse_move>gap
    else:
        votes=[-1 if ratio<.5 else 1,-1 if reverse_move>gap else 1]
        if er is not None:votes.append(-1 if er<.25 else 1)
        if votes.count(-1)>=2:flip=True
        elif votes.count(1)>=2:flip=False
        else:return 0,'方向根拠が競合'
    return -s if flip else s,POLICIES[policy]+('実反転' if flip else '元方向')


def decide(key,maps,contexts,extra,baseline):
    """
    機能: 同じq0からDay4/Night13の52口座の方向と幅を作る。
    引数: key(tuple),maps/contexts/extra/baseline(dict)。
    返り値: dictは純入口行。取引損益を参照しない。
    """
    ro=maps[0].get(key);rd=maps[1].get(key);eo=contexts[0].get(key);ed=contexts[1].get(key)
    band=baseline['band'];signals=[];widths=[];origins=[]
    if band=='DAY':
        preferred=ro if ro is not None else rd;context=eo if ro is not None else ed
        s1=native(preferred,context,extra,True) if preferred else 0
        s2=native(rd,ed,extra,True,True) if rd else 0
        s3=native(rd,ed,extra) if rd else 0
        if rd and rd['m5']['adx']<18 and abs(rd['m5']['ema8']-rd['m5']['ema21'])/rd['atr']<.4:s3=0
        days=[(baseline['signals'][0],baseline['widths'][0],'190D4固定'),
            (s1,P.U.width(preferred,'A25') if preferred else None,'旧優先厳・量不明時5分'),
            (s2,P.U.width(rd,'A25') if rd else None,'直接厳価格と小押戻し量'),
            (s3,P.U.width(rd,'A25') if rd else None,'直接P0と往復除外')]
        for s,w,origin in days:
            for _ in NIGHT:signals.append(s);widths.append(w);origins.append(origin)
    else:
        nights=[(baseline['signals'][0],'190N01固定')]
        for form in (0,1):
            row=ro if form==0 and ro is not None else rd;ctx=eo if form==0 and ro is not None else ed
            for policy in range(6):nights.append(night_direction(row,ctx,extra,policy) if row else (0,'形成不足'))
        for _ in DAY:
            for s,origin in nights:signals.append(s);widths.append(15.);origins.append(origin)
    return {'session':key[0],'time':key[1],'line':key[2],'band':band,'signals':signals,'widths':widths,'origins':origins,'extra':extra}


def prepare():
    """
    機能: 当初81場だけの52候補を、追加2場の金融参照前に固定する。
    引数: なし。
    返り値: None。
    """
    features={form:P.read(ROOT/'inputs/TOPIX原順8列_20260921_20261116'/name) for form,name in enumerate(('純特徴183.json.gz','純特徴184直接.json.gz'))}
    maps={form:{(r['session'],r['time'],r['line']):r for r in rows} for form,rows in features.items()}
    contexts={form:context_rows(rows) for form,rows in features.items()}
    baseline=P.read(ROOT/'inputs/00192_TOPIXの構造と数量の純入口/純入口.json.gz');result=[]
    for row in baseline:
        key=(row['session'],row['time'],row['line']);result.append(decide(key,maps,contexts,row['extra'],row))
    M.save(HERE/'純入口.json.gz',result)
    sources=[Path(__file__),ROOT/'work/192TOPIX/入口192.py',ROOT/'work/186TOPIX/入口186.py',M.HERE/'入口とIFD.py']
    cfg={'試行':196,'候補':list(NAMES),'Day':list(DAY),'Night':list(NIGHT),'規模':52,
        '追加情報':'追加11/16Night/11/17Dayの価格・金融結果を参照せず、旧81の192原因から仕様を固定。',
        'Day':'D0旧190D4固定、D1旧q0があれば厳P0・なければ直接厳P0、D2直接厳価格条件/量>=0.5/1分幅<=0.75ATR/実体<=0.3ATR、D3直接P0緩からADX<18かつEMA差<0.4ATRを除く。',
        'Night':'旧190N01固定対照。新案は米前のP0実側反転を固定起点とし、米後をATR5/ATR15の0.35又は0.5、過去ATR、ER、逆進対MA差、合意で判断。心理根拠の確定ではなく既使用データ由来仮説。',
        '過去ATR':'当該5分足を除く直前12個の異なる公開足。endが300秒刻みで連続、当該足への間隔も300秒、場越しなし。12足平均ではなく中央値。準備不足は元P0方向を保持して由来を区別。',
        'ER':'192同体の20分固定1分端点。ER不明の単独分岐は元方向、合意分岐は未知票を除く。',
        'quantity':'1分相対量既知ならそれを使い、不明時だけ192の可視5分量で補完。不明0化なし。',
        '費用':'方向には使わず共通可否比(spread+0.5836)/ATR5<=0.5だけ。旧対照は元費用方向を変更しない。',
        '幅期限':'Dayは選んだ形成のq0ATR5×2.5（5〜25pt/0.25切上げ）、Night15pt、単純IFD H60。保有/予約1、終了15分前まで、片道41.8円+0.25pt。',
        'Source':{p.relative_to(ROOT).as_posix():M.sha(p) for p in sources},'純入口SHA':M.sha(HERE/'純入口.json.gz'),
        '固定入力192SHA':M.sha(ROOT/'inputs/00192_TOPIXの構造と数量の純入口/純入口.json.gz')}
    assert not (HERE/'条件.json').exists();M.save(HERE/'条件.json',cfg)
    M.save(HERE/'純成立診断.json',{'q0':len(result),'候補':{name:sum(r['signals'][i]!=0 for r in result) for i,name in enumerate(NAMES)}})
    print(json.dumps({'純q0':len(result),'候補':len(NAMES),'純入口SHA':cfg['純入口SHA']},ensure_ascii=False),flush=True)


if __name__=='__main__':prepare()
