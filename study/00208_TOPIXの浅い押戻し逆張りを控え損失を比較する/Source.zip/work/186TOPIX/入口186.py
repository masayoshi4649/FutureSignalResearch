"""TOPIXの持続圧力、価格受容、反転確認を複合条件として固定する。"""
from pathlib import Path
from collections import deque,Counter
from copy import deepcopy
import gzip,json,sys,math,hashlib
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
sys.path.insert(0,str(ROOT/'work/183TOPIX'))
import 入口とIFD as M

FAMILIES=('P0_持続中の押戻し','P1_持続圧力の再開','P2_突破後の価格受容','P3_弱ADXの戻り売買',
 'R0_元圧力失速後の受容','R1_収束レンジ端回復','R2_収束後の拡散突破',
 'M0_持続再開と反転受容','M1_押戻しと弱ADX戻り','M2_収束拡散で切替','M3_持続と端回復','M4_役割別の広い複合')
NAMES=tuple(f'{name}_{level}' for name in FAMILIES for level in ('緩','厳'))+('対照T0_二足順行','対照R0反転','対照M4_旧複合')
WIDTHS=('W10','W15','A15','A25')


def width(row,key):
    """
    機能: 新規要求q0までに公表済みの5分ATRだけから固定IFD幅を決める。
    引数: row(dict),key(str)。
    返り値: floatはTOPIXpt。取得後は変更しない。
    """
    if key.startswith('W'):return float(key[1:])
    multiple=1.5 if key=='A15' else 2.5
    return math.ceil(min(25.,max(5.,row['atr']*multiple))*4)/4


def roles(r,side,context,strict):
    """
    機能: 圧力と受容を12複合入口へ変換する。
    引数: r(dict)は当時特徴、side(int)は実方向、context(dict)は公開済み履歴、strict(bool)は固定近傍。
    返り値: list[bool]。売買鏡像の同じ条件を使う。
    """
    m=r['m5'];mid=r['m15'];a=r['atr'];c=r['close'];past=context['history'];previous=context['previous']
    di=side*m['di'];slope=side*(m['slope'] or 0)/a;gap=side*(m['ema8']-m['ema21'])/a
    dist=side*(c-m['ema8'])/a;hist=side*m['hist']/a;hd=side*(m['hist_delta'] or 0)/a
    rd=side*(m['rsi_delta'] or 0);rsi=m['rsi'] if side==1 else 100-m['rsi'];rv=r['rvol']
    pos=r['position'] if side==1 else 1-r['position'];motion=side*r['body']>0 and side*r['progress']>0
    min_di=.04 if strict else .015;max_dist=1. if strict else 1.5;min_rv=1. if strict else .5
    q=0<r['spread']<=1.5 and r['range']<=(1.5 if strict else 2.) and r['live'] is not None and side*r['live']>=-.25
    if not q:return [False]*12
    amount=rv is not None and rv>=min_rv
    state_count=sum(side*(p['slope'] or 0)>0 and side*p['di']>0 and side*(p['ema8']-p['ema21'])>0 for p in past)
    coherent=len(past)==3 and all(past[i]['end']-past[i-1]['end']==300 for i in (1,2))
    persistent=coherent and state_count>=(3 if strict else 2)
    pressure=persistent and di>=min_di and slope>0 and gap>0 and side*mid['di']>=0
    bounded=(-.75<=dist<=max_dist and (35 if strict else 30)<=rsi<=(75 if strict else 80))
    # ----------------------------------------
    # 受容は前q0で越えた固定水準を、次の連続1分足でも同じ側へ保つこと。
    acceptance=ema_accept=False
    if previous is not None:
        dt=r['time']-previous['time'];start=M.bounds(r['session'])[0]
        consecutive=int((r['time']-start)//60)-int((previous['time']-start)//60)==1
        if consecutive and 30<=dt<=90:
            edge=previous['prior_high'] if side==1 else previous['prior_low']
            extreme=r['low'] if side==1 else r['high'];tol=0. if strict else .1*a
            acceptance=side*(previous['close']-edge)>0 and side*(c-edge)>0 and side*(extreme-edge)>=-tol
            anchor=previous['m5']['ema8']
            ema_accept=side*(previous['prior_close']-anchor)<=0<side*(previous['close']-anchor) and side*(c-anchor)>0 and side*(extreme-anchor)>=-tol
    # ----------------------------------------
    # 方向持続・短い戻り・順方向の再開を分ける。ADXの低さだけでは反転しない。
    p0=pressure and bounded and side*r['body']<0 and side*r['progress']<=0 and hist>=-.15 and amount
    p1=pressure and bounded and motion and pos>=(.65 if strict else .55) and hd>=0 and amount
    p2=pressure and bounded and acceptance and hd>=0 and amount
    opposite=M.roles(r,-side)[5]
    p3=opposite and persistent and di>=min_di and gap>0 and bounded and amount
    # ----------------------------------------
    # 反転は旧圧力の存在・動力の失速・固定水準の受容を別条件にする。
    oldpressure=coherent and any(side*p['di']<0 and side*(p['ema8']-p['ema21'])<0 for p in past[:-1])
    r0=oldpressure and hd>0 and rd>0 and motion and bounded and (ema_accept or acceptance) and amount
    convergence=abs((m['ema8']-m['ema21'])/a)<=(.25 if strict else .5)
    weak_di=abs(m['di'])<=(.05 if strict else .1)
    back=r['prior_low'] if side==1 else r['prior_high'];extreme=r['low'] if side==1 else r['high']
    edge_recovery=side*(extreme-back)<=0<side*(c-back)
    r1=convergence and weak_di and m['bbz'] is not None and side*m['bbz']<=-.5 and edge_recovery and motion and pos>=.65 and hd>=0 and rd>0 and amount
    expanding=coherent and abs(gap)>abs((past[-2]['ema8']-past[-2]['ema21'])/past[-2]['atr'])
    was_compressed=coherent and abs((past[0]['ema8']-past[0]['ema21'])/past[0]['atr'])<=.5
    r2=was_compressed and expanding and di>=min_di and slope>0 and acceptance and bounded and amount
    return [p0,p1,p2,p3,r0,r1,r2,p1 or p2 or r0,p0 or p3,
            (r1 or r2) if convergence else (p1 or p2 or r0),p0 or p1 or r1,
            p0 or p1 or p2 or p3 or r0 or r1 or r2]


def prepare():
    """
    機能: 金融を読む前に純入口と候補条件・対照を固定する。
    引数: なし。
    返り値: None。未来は使わず、同じ足IDを重複計数しない。
    """
    paths=[ROOT/'inputs/TOPIX原順8列_20260921_20261116/純特徴183.json.gz',ROOT/'inputs/TOPIX原順8列_20260921_20261116/純特徴184直接.json.gz']
    result={};diagnostics=[]
    for form,path in enumerate(paths):
        source=json.loads(gzip.decompress(path.read_bytes()));history=deque(maxlen=3);previous=None;scene=None;published_id=None;rows=[]
        for r in source:
            if scene!=r['session']:history.clear();previous=None;published_id=None;scene=r['session']
            ident=(r['m5']['count'],r['m5']['end'],r['m5']['published'])
            if ident!=published_id:history.append(r['m5']);published_id=ident
            ctx={'history':list(history),'previous':previous};signals=[]
            candidates={}
            for strict in (False,True):
                plus=roles(r,1,ctx,strict);minus=roles(r,-1,ctx,strict)
                candidates[strict]=[1 if p and not n else -1 if n and not p else 0 for p,n in zip(plus,minus)]
            for i in range(12):signals.extend([candidates[False][i],candidates[True][i]])
            signals.extend([r['signals'][0],-r['signals'][5],r['signals'][12]])
            rows.append({'session':r['session'],'time':r['time'],'line':r['line'],'band':r['band'],'atr':r['atr'],'signals':signals})
            previous=r
        result[str(form)]=rows
        diagnostics.append({'形成':form,'q0':len(rows),'純成立':{name:sum(r['signals'][i]!=0 for r in rows) for i,name in enumerate(NAMES)}})
    M.save(HERE/'純入口.json.gz',result);M.save(HERE/'純成立診断.json',diagnostics)
    cfg={'試行':186,'仮説':'方向持続と短い押戻し、元圧力失速後の価格受容を分け、ADX低水準だけの反転を避ける。',
      '候補':list(NAMES),'形成':{'0':'183旧1分合成','1':'184直接形成'},'幅':list(WIDTHS),
      'ATR幅':'q0以前に公開された5分ATR×1.5/2.5を5〜25TOPIXptへ制限し0.25pt切上げ。未来の取得価格/取得後足は使わず取得後固定。',
      '新組数':192,'対照組数':24,'合計':216,'SourceSHA':M.sha(Path(__file__)),'純入口SHA':M.sha(HERE/'純入口.json.gz'),
      '形成Source':'183実装修正1・184条件の同体純特徴を入力に使う。形成を変えた差は市場特性と断定しない。',
      '受容':'前q0で越えた固定端または前EMA8を、連続する次1分の終値も同側へ保つ。実時計差30〜90秒、同分重複なし。厳は足中の反対端も水準を割らない、緩は0.1ATR以内の一時戻りを許容。q0間欠測は不成立。',
      '持続':'同場の公開足ID(count/end/published)を重複させない直近3つの5分足。end間隔300秒を要求。履歴不足を別途不成立とし局面ラベルとしない。',
      '未知非増加対照':'形成ごと・幅規則ごとに同じ対照T0二足順行。W10対W10/W15対W15/A15対A15/A25対A25。',
      '順位':M.config()['順位'],'期間':M.config()['期間'],'固定金融':M.read(M.HERE/'条件_実装修正1.json'),
      '入力SHA':{str(p.relative_to(ROOT)):M.sha(p) for p in paths}}
    assert not (HERE/'条件.json').exists();M.save(HERE/'条件.json',cfg)
    print(json.dumps(diagnostics,ensure_ascii=False),flush=True)


if __name__=='__main__':prepare()
