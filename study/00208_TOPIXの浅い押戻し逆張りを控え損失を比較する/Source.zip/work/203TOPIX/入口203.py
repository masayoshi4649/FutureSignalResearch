"""長期背景、中期の押戻し又は転換、短期回復、量の継続を時間順で分ける。"""
from pathlib import Path
from collections import deque,defaultdict
import sys,json
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
sys.path.insert(0,str(ROOT/'work/200TOPIX'))
import 入口200 as P
M=P.M;read=P.read
WIDTHS=('W15','A25');FAMILIES=('T_長期支持から押戻し回復','R_長期失速から中期転換','M_独立出生の統合')
QUANTITIES=('Q0_確認時量','Q1_直近3つ中2つの量')
SPECS=tuple((form,family,quantity) for form in (0,1) for family in range(3) for quantity in (0,1))
NAMES=tuple('C0_旧190_'+w for w in WIDTHS)+tuple('C1_共通P0元側_'+w for w in WIDTHS)+tuple(f'F{f}_{FAMILIES[a]}_{QUANTITIES[q]}_{w}' for f,a,q in SPECS for w in WIDTHS)


def direction30(row):
    """
    機能: 公表済み30分EMAの並びと21EMA傾きから長期方向を決める。
    引数: row(dict)。
    返り値: intは+1/-1、未公表・不明・方向不一致は0。費用を参照しない。
    """
    m=row['m30']
    if m is None or m['published']>row['time'] or m['slope'] is None:return 0
    gap=m['ema8']-m['ema21'];slope=m['slope']
    return 1 if gap>0 and slope>0 else -1 if gap<0 and slope<0 else 0


def relative_volume(row,extra):
    """
    機能: 既知1分量を優先し、不明の場合だけ当時5分量へ補完する。
    引数: row/extra(dict)。
    返り値: float|None。不明と既知0/低量を区別する。
    """
    return row['rvol'] if row['rvol'] is not None else extra['rvol5']


def volume_gate(history,quantity):
    """
    機能: 単独確認量と、連続q0での相対量継続を比較する。
    引数: history(list[tuple[float,float|None]])は当時3q0,quantity(int)は0/1。
    返り値: bool。重複q0・欠測を低量へ置換しない。
    """
    if not history:return False
    current=history[-1][1]
    if quantity==0:return current is not None and current>=.5
    if len(history)!=3 or current is None or current<=0:return False
    if not all(30<=history[i][0]-history[i-1][0]<=90 for i in (1,2)):return False
    # 公表は30秒以内なので、時刻差に加え元の1分区間が連続であることを呼出側で確認する。
    return sum(rv is not None and rv>=.5 for _,rv in history)>=2


def crossing(row,side,level):
    """
    機能: 固定5分EMA8水準を1分終値が実側へ回復した時点を検出する。
    引数: row(dict),side(int),level(float)。
    返り値: bool。短期RSI/MACDの同時一致は要求しない。
    """
    return side*(row['prior_close']-level)<=0<side*(row['close']-level) and side*row['body']>0 and side*row['progress']>0


def execution_quality(row,side):
    """
    機能: 発火q0の価格品質を共通条件として確認する。
    引数: row(dict),side(int)。
    返り値: bool。スプレッド・当時逆進・1分足幅を使い、費用で方向を変えない。
    """
    return 0<row['spread']<=1.5 and row['range']<=2.5 and row['live'] is not None and side*row['live']>=-.25


def seed_for(row,family):
    """
    機能: 費用方向や旧P0成立から独立に、長期支持又は失速の源を生成する。
    引数: row(dict),family(int)は0順行/1転換。
    返り値: dict|Noneは源から全段階合計20分の不変期限を持つ監視状態。
    """
    old=direction30(row);mid=row['m15'];short=row['m5']
    if not old or mid['published']>row['time'] or short['published']>row['time']:return None
    depth=old*(row['close']-mid['ema8'])/mid['atr']
    if family==0:
        if not -1.5<=depth<=-.1:return None
        side=old;level=short['ema8'];stage='短期';armed=row['time'] if crossing(row,side,level) else None
    else:
        if row['m30']['hist_delta'] is None or old*row['m30']['hist_delta']>=0:return None
        side=-old
        if side*(mid['close']-mid['ema8'])>0:return None
        level=None;stage='中期';armed=None
    return {'time':row['time'],'line':row['line'],'side':side,'old_direction':old,'family':family,'expiry':row['time']+1200,
        'long_support':{k:row['m30'][k] for k in ('ema8','ema21','slope','hist_delta','end','published')},'depth15':depth,
        'middle_id':tuple(mid[k] for k in ('count','end','published')),'middle_level':mid['ema8'],
        'level':level,'stage':stage,'armed':armed,'middle_confirmed':None}


def advance(state,row,history,quantity):
    """
    機能: 中期の次足確認、固定短期水準の回復と次q0保持を順に評価する。
    引数: state(dict)は監視状態,row(dict),history(list[tuple]),quantity(int)。
    返り値: boolは一度の純出生。expiryは源時から更新しない。
    """
    if row['time']<=state['time'] or row['time']>state['expiry']:return False
    side=state['side'];mid=row['m15'];short=row['m5']
    if mid['published']>row['time'] or short['published']>row['time']:return False
    if state['stage']=='中期':
        count,end,published=state['middle_id']
        next_bar=mid['count']==count+1 and mid['end']==end+900 and state['time']<mid['published']<=row['time'] and mid['published']>published
        if not next_bar or side*(mid['close']-state['middle_level'])<=0:return False
        state.update(stage='短期',level=short['ema8'],middle_confirmed={'time':row['time'],'count':mid['count'],'end':mid['end'],'published':mid['published']})
        state['armed']=row['time'] if side*(row['close']-state['level'])>0 else None
        return False
    level=state['level'];armed=state['armed'];start=M.bounds(row['session'])[0]
    if armed is not None:
        consecutive=int((row['time']-start)//60)-int((armed-start)//60)==1
        extreme=row['low'] if side==1 else row['high'];held=side*(row['close']-level)>0 and side*(extreme-level)>=-.1*row['atr']
        if consecutive and 30<=row['time']-armed<=90 and held and volume_gate(history,quantity) and execution_quality(row,side):return True
        state['armed']=None
    if crossing(row,side,level):state['armed']=row['time']
    return False


def generate(rows,extras,quantity):
    """
    機能: 一形成の順行/転換を独立状態として生成し、同時ANDにしない。
    引数: rows(list[dict]),extras(dict),quantity(int)。
    返り値: tuple[dict,dict]はq0別の2出生と段階診断。
    """
    outputs={};states=[None,None];history=deque(maxlen=3);scene=None;previous=None;counts=defaultdict(int)
    for row in rows:
        key=(row['session'],row['time'],row['line']);start=M.bounds(row['session'])[0]
        if scene!=row['session']:states=[None,None];history.clear();scene=row['session'];previous=None
        if row['band']=='DAY':outputs[key]=[None,None];continue
        if previous is not None:
            consecutive=int((row['time']-start)//60)-int((previous-start)//60)==1
            if not consecutive:history.clear()
        rv=relative_volume(row,extras[key]);history.append((row['time'],rv));previous=row['time']
        counts['量不明' if rv is None else '既知低量' if rv<.5 else '既知量支持']+=1
        births=[]
        for family in (0,1):
            state=states[family];birth=None
            if state is not None:
                invalid=row['time']>state['expiry']
                if family==0:invalid=invalid or direction30(row)!=state['side']
                else:
                    long=row['m30'];invalid=invalid or long is None or long['published']>row['time'] or (long['hist_delta'] is not None and state['old_direction']*long['hist_delta']>0)
                if invalid:states[family]=None;state=None;counts[f'{family}期限又は背景失効']+=1
            if state is not None:
                before=state['stage']
                if advance(state,row,list(history),quantity):
                    birth={k:v for k,v in state.items() if k not in ('stage','armed')};birth.update(confirmed=row['time'],quantity=quantity)
                    states[family]=None;counts[f'{family}発火']+=1
                elif before!=state['stage']:counts[f'{family}中期確認']+=1
                counts[f'{family}監視q0']+=1
            else:
                state=seed_for(row,family)
                if state is not None:states[family]=state;counts[f'{family}源成立']+=1
            births.append(birth)
        outputs[key]=births
    return outputs,dict(counts)


def prepare():
    """
    機能: 旧対照4と独立出生24の全28口座を、金融参照前に固定する。
    引数: なし。
    返り値: None。Day固定、Night全81既使用を保持する。
    """
    baseline=read(ROOT/'inputs/00200_TOPIXの観測被覆と時間順入口/純入口.json.gz');extras={(r['session'],r['time'],r['line']):r['extra'] for r in baseline}
    features={f:read(ROOT/'inputs/TOPIX原順8列_20260921_20261116'/n) for f,n in enumerate(('純特徴183.json.gz','純特徴184直接.json.gz'))}
    maps={f:{(r['session'],r['time'],r['line']):r for r in rows} for f,rows in features.items()};contexts={f:P.B.context_rows(rows) for f,rows in features.items()}
    generated={};diagnostics={}
    for form in (0,1):
        for q in (0,1):generated[(form,q)],diagnostics[f'{form}_{q}']=generate(features[form],extras,q)
    result=[];conflicts=0
    for row in baseline:
        key=(row['session'],row['time'],row['line']);ro=maps[0].get(key);rd=maps[1].get(key)
        native=P.B.native(ro,contexts[0][key],row['extra'],0) if ro is not None and rd is not None else 0
        choices=[(row['signals'][0],ro,{'family':'旧190固定'}),(native,ro,{'family':'共通P0元側'})]
        for form,family,q in SPECS:
            births=generated[(form,q)].get(key,[None,None]);chosen=None
            if family<2:chosen=births[family]
            else:
                active=[b for b in births if b is not None]
                if len(active)==1:chosen=active[0]
                elif len(active)==2:
                    if active[0]['side']==active[1]['side']:chosen=dict(active[0],coincident_family=True)
                    else:conflicts+=1
            choices.append((chosen['side'] if chosen else 0,maps[form].get(key),dict(chosen,form=form) if chosen else None))
        signals=[];widths=[];origins=[];birth_records=[]
        for i,(side,formed,birth) in enumerate(choices):
            for w in WIDTHS:
                if row['band']=='DAY':s=row['signals'][0];width=row['widths'][0];origin='旧190D4固定';birth_record=None
                else:
                    s=side;width=15. if w=='W15' else P.B.P.U.width(formed,w) if formed else None;origin=NAMES[len(signals)];birth_record=birth
                signals.append(s);widths.append(width);origins.append(origin);birth_records.append(birth_record)
        assert len(signals)==28 and signals[0]==row['signals'][0] and widths[0]==row['widths'][0]
        result.append({'session':key[0],'time':key[1],'line':key[2],'band':row['band'],'signals':signals,'widths':widths,'origins':origins,'births':birth_records,'extra':row['extra']})
    M.save(HERE/'純入口.json.gz',result)
    sources=[Path(__file__),ROOT/'work/200TOPIX/入口200.py',ROOT/'work/197TOPIX/入口197.py',ROOT/'work/192TOPIX/入口192.py',ROOT/'work/186TOPIX/入口186.py',M.HERE/'入口とIFD.py']
    cfg={'試行':203,'候補':list(NAMES),'規模':28,'情報区分':'202原因診断後、当初81場で設計・探索。全既使用、追加2は探索へ混ぜない。板201結果の特徴選択とは独立。',
        '母体':'新案は旧P0源や旧費用方向を参照しない。旧/直接形成×順行/転換/統合×量2=12入口×幅2、旧190/共通P0元側×幅2の4対照。Dayは旧190D4固定。',
        '順行':'30分EMA8/21の並びと21EMA傾きが同側→q0価格の15分EMA8からの距離が同側-1.5〜-0.1ATR15なら源。源5分EMA8を固定し、1分の前終値から実側へ回復し実体/進行同側→次連続q0保持。源で回復が既知なら記録可、同q0発火不可。',
        '転換':'旧30分EMA方向にMACDヒストグラム増分が逆行して失速→源15分終値は新側EMA8を未回復→次の異なる公表15分足（count+1/end+900/pubは源時刻より後）が源15EMA8を新側へ回復→その時固定の5EMA8実側保持又は後続回復→次連続q0保持。',
        '短期確認':'連続1分q0は30〜90秒で足区間も連続。終値が固定水準実側、反対端侵入<=0.1当時ATR5。短期RSI/MACD同時一致は不要。順行は長期支持継続、転換は旧長期MACD再加速時に失効。',
        '源期限':'全段階合計が源時から1200秒。各stageで更新せず、後発源でも延長しない。場を跨がず、PRE/POSTの境界だけでは源を消さず同じ役割で判断する。',
        '量':'1分量既知なら優先、不明時だけ当時5分量補完。単独>=0.5対、連続3q0中2つ>=0.5かつ最新既知>0。欠測q0で履歴切断、同足を重複しない。5分補完窓は重複を含む観測代理で、独立した約定フローとは呼ばない。',
        '価格と費用':'新案は費用から売買方向を選ばない。発火q0は0<spread<=1.5pt、1分幅<=2.5ATR5、当時live既知かつ実側live>=-0.25ATR5。正常BBOと公表品質を保持。旧対照は旧費用方向を変更せず固定比較。',
        '幅期限':'NightW15/A25、A25は選択形成のq0ATR5×2.5を5〜25ptへ制限し0.25切上げ。H60、単純IFD、保有予約合計1、終了15分前、miniTOPIX片道41.8円+0.25pt。',
        'Source':{p.relative_to(ROOT).as_posix():M.sha(p) for p in sources},'純入口SHA':M.sha(HERE/'純入口.json.gz'),
        '母体200SHA':M.sha(ROOT/'inputs/00200_TOPIXの観測被覆と時間順入口/純入口.json.gz')}
    assert not (HERE/'条件.json').exists();M.save(HERE/'条件.json',cfg)
    M.save(HERE/'純成立診断.json',{'q0':len(result),'段階':diagnostics,'統合衝突':conflicts,'Night純成立':{name:sum(r['signals'][i]!=0 for r in result if r['band']!='DAY') for i,name in enumerate(NAMES)}})
    print(json.dumps({'純q0':len(result),'候補':28,'純入口SHA':cfg['純入口SHA'],'統合衝突':conflicts},ensure_ascii=False),flush=True)


if __name__=='__main__':prepare()
