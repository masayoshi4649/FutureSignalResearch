"""独立出生の段階脱落と、転換時に旧長期が残る状態を事後診断する。"""
from collections import defaultdict,Counter
import sys,json
import 入口203 as E
sys.path.insert(0,str(E.ROOT/'work/202TOPIX'))
from 原因202 import describe


def stages(rows,extras,quantity):
    """
    機能: 固定生成器へ読取ログだけを付け、回復前/保持/量/品質の脱落を数える。
    引数: rows(list[dict]),extras(dict),quantity(int)。
    返り値: tuple[dict,dict]は純出生と診断。元の判断関数は変更せず最後に復元する。
    """
    original_seed=E.seed_for;original_advance=E.advance;counts=Counter()
    def observe_seed(row,family):
        """
        機能: 元の源生成を呼び出し、その時点の位置だけを記録する。
        引数: row(dict),family(int)。
        返り値: dict|Noneは元と同じ監視状態。
        """
        seed=original_seed(row,family)
        if seed is not None and family==0:
            location=seed['side']*(row['close']-seed['level'])
            counts['順行源_5EMA実側' if location>0 else '順行源_5EMA反対又は同値']+=1
            if seed['armed'] is not None:counts['順行源_回復を既に記録']+=1
        return seed
    def observe_advance(state,row,history,q):
        """
        機能: 当時の段階通過/脱落を記録してから元の判断を呼ぶ。
        引数: state/row(dict),history(list),q(int)。
        返り値: boolは元と同じ発火判定。
        """
        family=state['family'];prefix=str(family)+'_'
        if state['stage']=='短期' and state['armed'] is not None:
            counts[prefix+'保持確認機会']+=1;side=state['side'];level=state['level'];start=E.M.bounds(row['session'])[0]
            continuous=30<=row['time']-state['armed']<=90 and int((row['time']-start)//60)-int((state['armed']-start)//60)==1
            extreme=row['low'] if side==1 else row['high'];held=side*(row['close']-level)>0 and side*(extreme-level)>=-.1*row['atr']
            if not continuous:counts[prefix+'非連続']+=1
            elif not held:counts[prefix+'価格保持せず']+=1
            elif not E.volume_gate(history,q):counts[prefix+'量支持なし']+=1
            elif not E.execution_quality(row,side):counts[prefix+'執行前品質不可']+=1
            else:counts[prefix+'保持量品質通過']+=1
        return original_advance(state,row,history,q)
    E.seed_for=observe_seed;E.advance=observe_advance
    try:result,_=E.generate(rows,extras,quantity)
    finally:E.seed_for=original_seed;E.advance=original_advance
    return result,dict(counts)


def main():
    """
    機能: 固定28口座と段階の純出生を読取診断し、次仮説へ原因を残す。
    引数: なし。
    返り値: None。203の閾値・金融・順位は変更しない。
    """
    pure={(r['session'],r['time'],r['line']):r for r in E.read(E.HERE/'純入口.json.gz')};extras={k:r['extra'] for k,r in pure.items()}
    features={f:E.read(E.ROOT/'inputs/TOPIX原順8列_20260921_20261116'/n) for f,n in enumerate(('純特徴183.json.gz','純特徴184直接.json.gz'))};maps={f:{(r['session'],r['time'],r['line']):r for r in rows} for f,rows in features.items()}
    stage_results={}
    for f in (0,1):
        for q in (0,1):
            shadow,counts=stages(features[f],extras,q)
            for key,births in shadow.items():
                if pure[key]['band']=='DAY':continue
                for family,birth in enumerate(births):assert (birth['side'] if birth else 0)==pure[key]['signals'][4+f*12+family*4+q*2]
            stage_results[f'{f}_{q}']=counts
    data=E.read(E.HERE/'全28組安定性.json.gz');results=[]
    for ci in (4,6,8,10,16,18,20,22,24,26):
        state=data['metrics'][ci];ledger=E.read(E.HERE/'金融正本'/(state['id']+'.json.gz'))['ledger'];groups=defaultdict(list)
        for i,scene in enumerate(ledger['scene']):
            if 'Night' not in scene:continue
            key=(scene,ledger['request_time'][i],ledger['request_line'][i]);birth=pure[key]['births'][ci];row=maps[birth['form']][key];side=birth['side'];old=birth['old_direction'];long=row['m30']
            family='順行回復' if birth['family']==0 else '中期転換';labels=['全体',family,family+'/'+ledger['reason'][i],row['band']+'/'+family]
            if birth['family']==1:
                labels+=['旧30EMA支持/'+('維持' if E.direction30(row)==old else '解消'),
                    '旧側30EMA21価格支持/'+('保持' if old*(row['close']-long['ema21'])>=0 else '割れ'),
                    '新15分DI傾き/'+('同側' if side*row['m15']['di']>0 and side*(row['m15']['slope'] or 0)>0 else '混在又は反対'),
                    '新15分EMA並び/'+('同側' if side*(row['m15']['ema8']-row['m15']['ema21'])>0 else '反対')]
            for label in labels:groups[label].append(i)
        results.append({'index':ci,'id':state['id'],'群':{label:describe(ledger,indices) for label,indices in groups.items()}})
    report={'区分':'旧81の事後診断。段階ログ再生は固定純出生の同体を照合。支持数・期間・取得枠を保持し、新条件の成績とはしない。',
        '段階':stage_results,'候補':results,'SourceSHA':E.M.sha(E.HERE/'原因203.py')}
    E.M.save(E.HERE/'原因診断.json',report)
    E.M.save(E.HERE/'固定選択.json',{'全体採用':None,'理由':'新案の参加と両中央値が不足。方向を費用から切り離しただけで優位が生じたとはしない。','旧81固定順位':{k:v[:1] for k,v in data['順位'].items()},'条件SHA':E.M.sha(E.HERE/'条件.json'),'純入口SHA':E.M.sha(E.HERE/'純入口.json.gz')})
    print(json.dumps({'段階':stage_results,'直接転換':next(r for r in results if r['index']==20)},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
