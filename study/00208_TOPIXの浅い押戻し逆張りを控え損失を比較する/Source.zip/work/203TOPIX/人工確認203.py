"""段階ごとの役割、異なる15分公表足、源からの合計期限と量継続を検査する。"""
from copy import deepcopy
import json
import 入口203 as E
import 人工検査 as T


def history_at(t,values=(1.,1.,1.)):
    """
    機能: 連続する3q0の量履歴を人工的に作る。
    引数: t(float),values(tuple[float|None])。
    返り値: list[tuple[float,float|None]]。
    """
    return [(t-120+i*60,v) for i,v in enumerate(values)]


def main():
    """
    機能: 順行と転換の時計・売買鏡像・欠測量・因果prefixを金融前に確認する。
    引数: なし。
    返り値: None。新候補の損益は参照しない。
    """
    checks=0;features={f:E.read(E.ROOT/'inputs/TOPIX原順8列_20260921_20261116'/n) for f,n in enumerate(('純特徴183.json.gz','純特徴184直接.json.gz'))}
    scene='2026-09-21_Night';t=E.M.bounds(scene)[0]+3600;source=deepcopy(features[1][1000])
    source.update(session=scene,time=t,line=1,band='PRE',close=4000.,prior_close=4000.,low=3999.,high=4001.,atr=2.,rvol=1.,body=-.2,progress=-.2,live=0.,spread=.5,range=1.)
    for k in ('m5','m15','m30'):source[k].update(count=10,end=t,published=t,atr=2.)
    source['m30'].update(ema8=4005.,ema21=4000.,slope=.1,hist_delta=.1)
    source['m15'].update(ema8=4002.,atr=4.,close=4005.);source['m5']['ema8']=4001.
    cross=deepcopy(source);cross.update(time=t+60,line=2,prior_close=4000.,close=4002.,low=4000.,high=4003.,body=1.,progress=1.)
    hold=deepcopy(cross);hold.update(time=t+120,line=3,prior_close=4002.,close=4002.5,low=4001.)
    for mirrored in (False,True):
        r=T.mirror(source) if mirrored else source;c=T.mirror(cross) if mirrored else cross;h=T.mirror(hold) if mirrored else hold
        seed=E.seed_for(r,0);assert seed is not None and seed['side']==(-1 if mirrored else 1);checks+=2
        fixed={k:deepcopy(v) for k,v in seed.items() if k not in ('stage','armed','middle_confirmed','level')}
        assert not E.advance(seed,c,history_at(c['time']),1);checks+=1
        assert E.advance(seed,h,history_at(h['time']),1);checks+=1
        assert {k:v for k,v in seed.items() if k not in ('stage','armed','middle_confirmed','level')}==fixed;checks+=1
    # ----------------------------------------
    # 中期転換は同じ15分足を繰り返して成立させない。全段階の期限は源+20分。
    reversal=deepcopy(source);reversal['m30']['hist_delta']=-.1
    middle=deepcopy(reversal);middle.update(time=t+900,line=10,close=3998.,high=3999.,low=3997.,body=-1.,progress=-1.)
    middle['m15'].update(count=11,end=t+900,published=t+900,close=3998.);middle['m5'].update(ema8=4000.,published=t+900,end=t+900)
    confirmed=deepcopy(middle);confirmed.update(time=t+960,line=11,close=3997.,prior_close=3998.,high=3999.5)
    for mirrored in (False,True):
        r=T.mirror(reversal) if mirrored else reversal;m=T.mirror(middle) if mirrored else middle;c=T.mirror(confirmed) if mirrored else confirmed
        state=E.seed_for(r,1);assert state is not None and state['side']==(1 if mirrored else -1);checks+=2
        assert not E.advance(state,m,history_at(m['time']),0) and state['stage']=='短期';checks+=2
        assert state['expiry']==t+1200 and state['middle_confirmed']['end']==t+900;checks+=2
        assert E.advance(state,c,history_at(c['time']),0);checks+=1
        for failure in ('同じ足','end飛越し','count飛越し','未来公表'):
            seed=E.seed_for(r,1);bad=deepcopy(m)
            if failure=='同じ足':bad['m15'].update(count=10,end=t,published=t)
            elif failure=='end飛越し':bad['m15']['end']=t+1800
            elif failure=='count飛越し':bad['m15']['count']=12
            else:bad['m15']['published']=bad['time']+1
            assert not E.advance(seed,bad,history_at(bad['time']),0) and seed['stage']=='中期';checks+=2
        late=deepcopy(c);late['time']=t+1201;assert not E.advance(state,late,history_at(late['time']),0);checks+=1
    for values,expected in (((1.,1.,None),False),((1.,1.,0.),False),((1.,None,1.),True),((None,None,1.),False),((1.,1.,.1),True)):
        assert E.volume_gate(history_at(t,values),1)==expected;checks+=1
    assert not E.volume_gate([(t-200,1.),(t-60,1.),(t,1.)],1);checks+=1
    assert E.relative_volume(dict(source,rvol=0.),{'rvol5':100.})==0.;checks+=1
    assert E.relative_volume(dict(source,rvol=None),{'rvol5':None}) is None;checks+=1
    # ----------------------------------------
    # 実特徴は接頭部と全体で同体。源から20分、転換は次の公開15分足、一度発火。
    base=E.read(E.ROOT/'inputs/00200_TOPIXの観測被覆と時間順入口/純入口.json.gz');extras={(r['session'],r['time'],r['line']):r['extra'] for r in base};allcounts={}
    for form in (0,1):
        for quantity in (0,1):
            full,counts=E.generate(features[form],extras,quantity);prefix,_=E.generate(features[form][:2000],extras,quantity);allcounts[f'{form}_{quantity}']=counts
            for key,value in prefix.items():assert value==full[key];checks+=1
            seen=set()
            for key,births in full.items():
                for family,birth in enumerate(births):
                    if birth is None:continue
                    marker=(key[0],family,birth['time'],birth['line']);assert marker not in seen;seen.add(marker);checks+=1
                    assert birth['time']<key[1]<=birth['expiry']==birth['time']+1200;checks+=2
                    if family==1:
                        mid=birth['middle_confirmed'];assert mid is not None and mid['count']==birth['middle_id'][0]+1 and mid['end']==birth['middle_id'][1]+900 and birth['time']<mid['published']<=mid['time']<key[1];checks+=4
            subset=features[form][:2000];mirrored=[T.mirror(r) for r in subset];opposite,_=E.generate(mirrored,extras,quantity)
            for key,births in prefix.items():
                for a,b in zip(births,opposite[key]):
                    assert (a is None)==(b is None)
                    if a is not None:assert a['side']==-b['side'] and a['time']==b['time'] and a['expiry']==b['expiry']
                    checks+=1
    proof={'成功':True,'項目数':checks,'独立役割出生':True,'売買鏡像':True,'同じ15分足で段階進行しない':True,'源から全段階20分':True,
        '欠測量と既知0を区別':True,'prefix同体':True,'同源一度':True,'段階':allcounts,'SourceSHA':E.M.sha(E.HERE/'入口203.py')}
    E.M.save(E.HERE/'人工確認.json',proof);print(json.dumps({k:v for k,v in proof.items() if k!='段階'},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
