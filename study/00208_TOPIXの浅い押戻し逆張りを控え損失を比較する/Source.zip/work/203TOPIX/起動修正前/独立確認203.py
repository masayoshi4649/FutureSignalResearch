"""203の金融・全q0保有枠・固定対照を別算術で照合する。"""
from pathlib import Path
from collections import defaultdict
import sys,json,math
import numpy as np
import 入口203 as E
sys.path.insert(0,str(E.ROOT/'work/183損失安定性'))
import TOPIXを独立検算する as T


def main():
    """
    機能: 全28口座を別BBO線形走査・別集計で読取検査する。
    引数: なし。
    返り値: None。新金融を採否選択へ追加せず、正本は変更しない。
    """
    states=E.read(E.HERE/'全28組安定性.json.gz')['metrics'];state_sha=E.M.sha(E.HERE/'全28組安定性.json.gz')
    packs=[E.read(E.HERE/'金融正本'/(s['id']+'.json.gz')) for s in states]
    sha={p['id']:E.M.sha(E.HERE/'金融正本'/(p['id']+'.json.gz')) for p in packs}
    pure=E.read(E.HERE/'純入口.json.gz');by=defaultdict(list)
    for row in pure:by[row['session']].append(row)
    count=0;group_count=0;acquired=0;slot_checks=0;quality=0
    for pack,state in zip(packs,states):group_count+=T.inspect_groups(pack,state)
    for entry in E.read(E.ROOT/'inputs/TOPIX原順8列_20360921_20361116/台帳.json')['entries']:
        scene=entry['session'];start,end,force=T.bounds(scene)
        with np.load(E.ROOT/entry['path'],allow_pickle=False) as archive:raw={k:archive[k] for k in ('now','line','bid','ask','valid')}
        t=raw['now'];finite=np.isfinite(t);prior=np.maximum.accumulate(np.where(finite,t,-np.inf))
        mask=finite&(t>=start)&(t<end)&(t>=prior)&raw['valid'];arrays={k:v[mask] for k,v in raw.items() if k!='valid'}
        cache={}
        for ci,pack in enumerate(packs):
            ledger=pack['ledger'];indices=[i for i,s in enumerate(ledger['scene']) if s==scene];cursor=0;busy=-math.inf
            for row in by[scene]:
                side=row['signals'][ci]
                if not side:continue
                slot_checks+=1
                if row['time']<=busy:continue
                key=(row['time'],side,row['widths'][ci])
                if key not in cache:
                    first=int(np.searchsorted(arrays['now'],row['time']+1))
                    fillable=first<len(arrays['now']) and arrays['now'][first]<=min(row['time']+30,force) and arrays['now'][first]<force
                    cache[key]=T.financial_oracle(arrays,scene,*key) if fillable else None
                cell=cache[key]
                if cell is None:busy=min(row['time']+30,force);continue
                assert cursor<len(indices),(pack['id'],scene,'未記録取得')
                i=indices[cursor];cursor+=1;acquired+=1
                for field,value in cell.items():
                    actual=pack['positions'][i][field] if field=='confirmed_until' else ledger[field][i]
                    count+=T.V.check_equal(actual,value,(pack['id'],scene,i,field))
                assert ledger['request_time'][i]==row['time'] and ledger['request_line'][i]==row['line']
                assert ledger['side'][i]==side and ledger['width'][i]==row['widths'][ci]
                assert ledger['origin'][i]==row['origins'][ci]
                assert row['extra']['quantity_last_line'] is None or row['extra']['quantity_last_line']<=row['line']
                assert row['extra']['price_last_line'] is None or row['extra']['price_last_line']<=row['line'];quality+=6
                busy=ledger['exit_time'][i] if ledger['known'][i] else end
            assert cursor==len(indices),(pack['id'],scene,'余分取得')
    assert state_sha==E.M.sha(E.HERE/'全28組安定性.json.gz')
    assert all(E.M.sha(E.HERE/'金融正本'/(p['id']+'.json.gz'))==sha[p['id']] for p in packs)
    report={'成功':True,'候補':len(packs),'取得':acquired,'金融属性':count,'独立集計属性':group_count,
        '全q0枠再生':slot_checks,'q0方向幅出生と追加特徴時計':quality,'旧対照同体':E.read(E.HERE/'旧対照同体.json'),
        '金融方式':'Routeと到達木を使わない183独立BBO線形走査。新旧とも失効TTL30秒の予約枠を再生。',
        'SourceSHA':E.M.sha(Path(__file__)),'独立oracleSHA':E.M.sha(Path(T.__file__)),'固定正本SHA':state_sha}
    E.M.save(E.HERE/'独立確認.json',report);print(json.dumps(report,ensure_ascii=False),flush=True)


if __name__=='__main__':main()
