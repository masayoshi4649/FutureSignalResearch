"""売買鏡像と注文時計・欠測・単純IFDを金融前に点検する。"""
from pathlib import Path
import copy,json,tempfile
import numpy as np
import 入口とIFD as M


def mirror(row):
    """
    機能: 原点4000を中心に価格と方向指標を反転する。
    引数: row(dict)。
    返り値: dictは売買鏡像。
    """
    r=copy.deepcopy(row)
    for key in ('close','prior_close'):r[key]=8000-row[key]
    for lo,hi in [('low','high'),('prior_low','prior_high')]:r[lo]=8000-row[hi];r[hi]=8000-row[lo]
    for key in ('body','progress','live'):r[key]=-row[key] if row[key] is not None else None
    r['position']=1-row['position']
    for key in ('m5','m15','m30'):
        if r[key] is None:continue
        for p in ('close','ema8','ema21'):r[key][p]=8000-row[key][p]
        for p in ('slope','hist','hist_delta','rsi_delta','di','bbz'):
            r[key][p]=-row[key][p] if row[key][p] is not None else None
        r[key]['rsi']=100-row[key]['rsi']
    return r


def route(tmp,seconds,bid,ask):
    """
    機能: 人工的な正常板列を作る。
    引数: tmp(Path),seconds/bid/ask(list[float])。
    返り値: Routeは一場価格索引。
    """
    session='2026-09-21_Day';start,_,_=M.bounds(session);n=len(seconds)
    p=tmp/'fake.npz'
    np.savez(p,now=start+np.array(seconds),line=np.arange(n)+1,last=(np.array(bid)+ask)/2,bid=np.array(bid),ask=np.array(ask),valid=np.ones(n,dtype=bool),volume=np.arange(n),volume_time=start+np.array(seconds))
    return M.Route({'session':session,'cache_absolute':str(p)})


def main():
    """
    機能: 重要な鏡像・足公表・注文時計・欠測を人工入力で確認する。
    引数: なし。
    返り値: None。検査票を保存する。
    """
    rng=np.random.default_rng(183);checks=0
    for i in range(1500):
        c=4000+rng.normal()*5;a=1+rng.random()*4
        mm={'close':c,'ema8':c+rng.normal()*a,'ema21':c+rng.normal()*a,'slope':rng.normal(),'hist':rng.normal(),
           'hist_delta':rng.normal(),'rsi_delta':rng.normal(),'di':rng.normal(),'bbz':rng.normal(),'rsi':rng.uniform(10,90),'adx':rng.uniform(5,50)}
        r={'m5':mm,'m15':copy.deepcopy(mm),'m30':copy.deepcopy(mm) if i%3 else None,'atr':a,'close':c,'body':rng.normal(),
           'progress':rng.normal(),'position':rng.random(),'high':c+1,'low':c-1,'prior_high':c+rng.normal(),
           'prior_low':c+rng.normal(),'prior_close':c+rng.normal(),'range':rng.uniform(0,3),'rvol':rng.random()*3 if i%4 else None,
           'live':rng.normal(),'spread':.5}
        assert M.roles(r,1)==M.roles(mirror(r),-1)
        assert M.roles(r,-1)==M.roles(mirror(r),1);checks+=26
    with tempfile.TemporaryDirectory() as temp:
        p=Path(temp);s,e,f=M.bounds('2026-09-21_Day')
        r=route(p,[0,1,2,3,4],[3999.5,3999.5,4006,4005,4004],[4000,4000,4006.5,4005.5,4004.5])
        x=r.cell(s,1,1,5);assert x['entry_time']==s+1 and x['exit_time']==s+2 and x['exit_price']==4005 and x['label']=='F';checks+=4
        r=route(p,[0,1,2,3,4],[3999.5,3999.5,3995,3993,3992],[4000,4000,3995.5,3993.5,3992.5])
        x=r.cell(s,1,1,5);assert x['exit_time']==s+3 and x['exit_price']==3993 and x['label']=='A';checks+=3
        r=route(p,[0,1,400,401],[3999.5,3999.5,4006,4005],[4000,4000,4006.5,4005.5])
        x=r.cell(s,1,1,5);assert x['unknown'] and x['exit_price'] is None and x['label']=='C';checks+=3
        r=route(p,[0,31,32],[3999.5]*3,[4000]*3);assert r.cell(s,1,1,5) is None;checks+=1
        r=route(p,[f-s-1,f-s,f-s+1],[3999.5]*3,[4000]*3);assert r.cell(f-1,1,1,5) is None;checks+=1
        seconds=[0,1]+list(range(60,3601,60))+[3601,3650,3700,24000]
        r=route(p,seconds,[3999.5]*len(seconds),[4000]*len(seconds))
        x=r.cell(s,1,1,5);assert x['unknown'] and x['known_until']==s+3601;checks+=2
        r=route(p,[0,1,2,3],[3999.5,3990,3991,3992],[4000,4000,3991.5,3992.5])
        x=r.cell(s,1,1,5);assert x['label']=='A' and x['exit_time']==s+2 and x['exit_price']==3991;checks+=3
        # ----------------------------------------
        # 1分未確定の将来行を変えても、その前の公開済み純特徴は変わらない。
        seconds=list(range(0,3*3600,5));prices=4000+np.sin(np.arange(len(seconds))/30)*3+np.arange(len(seconds))*.005
        r=route(p,seconds,prices-.25,prices+.25);entry={'session':r.session,'cache_absolute':str(p/'fake.npz')}
        rows,_=M.bars_and_features(entry,{k:M.Channel() for k in (5,15,30)})
        cutoff=s+150*60
        z=dict(np.load(p/'fake.npz'));mask=z['now']>=cutoff
        for key in ('last','bid','ask'):z[key][mask]+=100
        np.savez(p/'fake.npz',**z)
        rows2,_=M.bars_and_features(entry,{k:M.Channel() for k in (5,15,30)})
        a=[v for v in rows if v['time']<cutoff];b=[v for v in rows2 if v['time']<cutoff]
        assert a and a==b;checks+=len(a)
    M.save(M.HERE/'人工検査.json',{'成功':True,'照合数':checks,'売買鏡像':39000,'注文と足時計':checks-39000,'SourceSHA':M.sha(M.HERE/'入口とIFD.py')})
    print(json.dumps({'成功':True,'照合数':checks},ensure_ascii=False))


if __name__=='__main__':main()
