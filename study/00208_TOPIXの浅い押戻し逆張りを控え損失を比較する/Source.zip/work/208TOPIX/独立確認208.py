"""208の9口座を別BBO線形走査と全q0保有枠・別集計で検算する。"""
from pathlib import Path
from collections import defaultdict
import sys,json,math
import numpy as np
import 入口208 as E
sys.path.insert(0,str(E.ROOT/'work/183損失安定性'))
import TOPIXを独立検算する as T


def main():
    """
    機能: 固定9口座の取得・金融未知・期間分母・出生時計を独立算術で確認する。
    引数: なし。
    返り値: None。新仮説や金融を上書きしない。
    """
    folder=E.HERE/'金融';state_sha=E.M.sha(folder/'安定性.json.gz');states=E.read(folder/'安定性.json.gz')['metrics'];packs=[E.read(folder/'金融正本'/(s['id']+'.json.gz')) for s in states];by=defaultdict(list)
    for row in E.read(E.HERE/'純入口.json.gz'):by[row['session']].append(row)
    checks={'金融属性':0,'独立集計属性':0,'取得':0,'全q0枠':0,'出生時計':0}
    for pack,state in zip(packs,states):checks['独立集計属性']+=T.inspect_groups(pack,state)
    for entry in E.read(E.ROOT/'inputs/TOPIX原順8列_20260921_20261116/台帳.json')['entries']:
        scene=entry['session'];start,end,force=T.bounds(scene)
        with np.load(E.ROOT/entry['path'],allow_pickle=False) as archive:raw={k:archive[k] for k in ('now','line','bid','ask','valid')}
        t=raw['now'];finite=np.isfinite(t);prior=np.maximum.accumulate(np.where(finite,t,-np.inf));mask=finite&(t>=start)&(t<end)&(t>=prior)&raw['valid'];arrays={k:v[mask] for k,v in raw.items() if k!='valid'};cache={}
        for ci,pack in enumerate(packs):
            ledger=pack['ledger'];indices=[i for i,s in enumerate(ledger['scene']) if s==scene];cursor=0;busy=-math.inf
            for row in by[scene]:
                side=row['signals'][ci]
                if not side:continue
                checks['全q0枠']+=1
                if row['time']<=busy:continue
                query=(row['time'],side,row['widths'][ci])
                if query not in cache:
                    first=int(np.searchsorted(arrays['now'],row['time']+1));fillable=first<len(arrays['now']) and arrays['now'][first]<=min(row['time']+30,force) and arrays['now'][first]<force
                    cache[query]=T.financial_oracle(arrays,scene,*query) if fillable else None
                cell=cache[query]
                if cell is None:busy=min(row['time']+30,force);continue
                assert cursor<len(indices);i=indices[cursor];cursor+=1;checks['取得']+=1
                for field,value in cell.items():
                    actual=pack['positions'][i][field] if field=='confirmed_until' else ledger[field][i];checks['金融属性']+=T.V.check_equal(actual,value,(pack['id'],scene,i,field))
                assert ledger['request_time'][i]==row['time'] and ledger['request_line'][i]==row['line'] and ledger['side'][i]==side and ledger['width'][i]==row['widths'][ci] and ledger['origin'][i]==row['origins'][ci]
                origin=row['origins'][ci];birth=row['births'][ci]
                if origin=='A源方向切替':assert row['role']['A'] and side==row['role']['native'] and birth['time']==row['time'];checks['出生時計']+=3
                elif origin=='B構造確認反転':
                    assert birth['time']<=birth['broken']['time']<row['time']<=birth['expiry']==birth['time']+1200 and side==-birth['native'] and birth['width']==row['widths'][ci]==15.
                    assert birth['source_role']['B'] and birth['broken']['end']<birth['confirmation_end']<=row['time'];checks['出生時計']+=5
                busy=ledger['exit_time'][i] if ledger['known'][i] else end
            assert cursor==len(indices)
    old=E.read(E.ROOT/'inputs/00192_TOPIXの構造と数量の純入口/旧190固定対照.json.gz')
    assert {k:v for k,v in packs[0]['ledger'].items() if k!='origin'}=={k:v for k,v in old['ledger'].items() if k!='origin'} and packs[0]['positions']==old['positions'] and packs[0]['sessions']==old['sessions']
    assert state_sha==E.M.sha(folder/'安定性.json.gz')
    proof={'成功':True,'候補':9,**checks,'旧対照同体':True,'固定金融SHA':state_sha,'方式':'共通金融/Route/到達木を使わない独立BBO線形走査と全q0の予約保有枠','SourceSHA':E.M.sha(Path(__file__)),'独立oracleSHA':E.M.sha(Path(T.__file__))}
    E.M.save(E.HERE/'独立確認.json',proof);print(json.dumps(proof,ensure_ascii=False),flush=True)


if __name__=='__main__':main()
