"""旧入口を主軸に、浅い押戻しの逆張りと過熱失速後の順張りを役割で分ける。"""
from pathlib import Path
from collections import defaultdict
import sys,json
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
sys.path.insert(0,str(ROOT/'work/205TOPIX'))
import 入口205 as U
E=U.E;M=E.M;read=E.read
SPECS=tuple((a,b) for a in range(3) for b in range(3))
NAMES=tuple(f"A{a}_{('旧維持','浅押戻し逆張り見送り','浅押戻し源側')[a]}_B{b}_{('旧維持','過熱失速見送り','過熱失速の構造反転')[b]}" for a,b in SPECS)


def direction15(row):
    """
    機能: 公表済み15分EMAの並びと21EMA傾きの一致方向を求める。
    引数: row(dict)。
    返り値: intは+1/-1/0。
    """
    mid=row['m15']
    if mid is None or mid['published']>row['time'] or mid['slope'] is None:return 0
    return 1 if mid['ema8']>mid['ema21'] and mid['slope']>0 else -1 if mid['ema8']<mid['ema21'] and mid['slope']<0 else 0


def roles(row,native,actual):
    """
    機能: 旧要求の元方向と実方向を区別し、浅押戻しと過熱失速を当時情報で判定する。
    引数: row(dict),native/actual(int)。
    返り値: dictはA/B排他フラグと指標値。費用を新しい方向根拠にしない。
    """
    short=row['m5'];assert short['published']<=row['time'];rsi=short['rsi'] if native==1 else 100-short['rsi'];bbz=native*short['bbz'];distance=native*(row['close']-short['ema8'])/row['atr']
    long_side=E.direction30(row);middle_side=direction15(row)
    a=actual==-native and long_side==native and middle_side==native and native*(row['close']-row['m30']['ema21'])>0 and -.75<=distance<=.5 and rsi<65 and bbz<1
    b=actual==native and rsi>=65 and bbz>=1 and short['hist_delta'] is not None and native*short['hist_delta']<=0 and row['rvol'] is not None and row['rvol']>=1
    assert not (a and b)
    return {'A':a,'B':b,'native':native,'actual':actual,'native_rsi':rsi,'native_bbz':bbz,'native_distance5':distance,
        'native_hist_delta':None if short['hist_delta'] is None else native*short['hist_delta'],'rvol1':row['rvol'],'direction30':long_side,'direction15':middle_side,
        'source_background':U.background(row,native)}


def new_seed(row,role):
    """
    機能: 過熱失速Bの反対側候補を固定価格端・期限・幅で監視開始する。
    引数: row/role(dict)。
    返り値: dictは源当時の破断既知を記録するが同q0で発火しない。
    """
    side=-role['native'];level=row['prior_high'] if side==1 else row['prior_low'];end=U.minute_end(row)
    broken=E.crossing(row,side,level)
    return {'time':row['time'],'line':row['line'],'side':side,'native':role['native'],'level':level,'expiry':row['time']+1200,'width':15.,
        'prior_ends':[end-180,end-120,end-60],'source_end':end,'source_role':role,
        'broken':{'time':row['time'],'line':row['line'],'end':end} if broken else None}


def advance(state,row):
    """
    機能: 源固定端の反対側破断後、後の連続1分足で価格保持と量を確認する。
    引数: state/row(dict)。
    返り値: dict|Noneは一度の純発火。将来損益・返済可否は参照しない。
    """
    if row['time']<=state['time'] or row['time']>state['expiry']:return None
    side=state['side'];level=state['level'];broken=state['broken'];end=U.minute_end(row)
    if broken is not None:
        extreme=row['low'] if side==1 else row['high'];held=side*(row['close']-level)>0 and side*(extreme-level)>=-.1*row['atr']
        if end==broken['end']+60 and 30<=row['time']-broken['time']<=90 and held and row['rvol'] is not None and row['rvol']>=.5 and E.execution_quality(row,side):
            return {**state,'confirmed':row['time'],'confirmation_end':end,'confirmation_background':U.background(row,state['native']),'confirmation_rvol1':row['rvol']}
        state['broken']=None
    if E.crossing(row,side,level):state['broken']={'time':row['time'],'line':row['line'],'end':end}
    return None


def generate(rows,role_map):
    """
    機能: B源からの構造反転を金融枠と独立に生成し、欠測又は20分で失効させる。
    引数: rows(list[dict]),role_map(dict)は旧要求時の役割。
    返り値: tuple[dict,dict]は全q0の構造出生と棄却理由。
    """
    outputs={};state=None;previous=None;counts=defaultdict(int)
    for row in rows:
        key=(row['session'],row['time'],row['line']);role=role_map.get(key);birth=None
        assert row['m5']['published']<=row['time'] and row['m15']['published']<=row['time']
        if row['band']=='DAY':outputs[key]=None;state=None;previous=row;continue
        if previous is not None and not U.continuous(previous,row):
            if state is not None:counts['欠測又は場境界で失効']+=1
            state=None
        previous=row
        if state is not None and row['time']>state['expiry']:counts['源20分で失効']+=1;state=None
        if state is not None:
            before=state['broken'];birth=advance(state,row);counts['監視q0']+=1
            if role is not None and role['B']:counts['監視中の後発B_源不更新']+=1
            if birth is not None:counts['構造発火']+=1;state=None
            elif before is None and state['broken'] is not None:counts['固定端の破断']+=1
        elif role is not None and role['B']:
            state=new_seed(row,role);counts['B源開始']+=1
            if state['broken'] is not None:counts['源当時破断既知']+=1
        outputs[key]=birth
    return outputs,dict(counts)


def prepare():
    """
    機能: A三行動×B三行動の9口座を、同時要求優先と源記録を含め金融前に固定する。
    引数: なし。
    返り値: None。既存の欠測や未参加を分母から除外しない。
    """
    base=read(ROOT/'inputs/00205_TOPIXの長期支持と破断失敗の純入口/純入口.json.gz')
    features=read(ROOT/'inputs/TOPIX原順8列_20260921_20261116/純特徴183.json.gz');maps={(r['session'],r['time'],r['line']):r for r in features};contexts=E.P.B.context_rows(features);role_map={};support=defaultdict(int);scenes=defaultdict(set)
    for row in base:
        if row['band']=='DAY' or not row['signals'][0]:continue
        key=(row['session'],row['time'],row['line']);formed=maps[key];native=E.P.B.native(formed,contexts[key],row['extra'],0);assert native in (-1,1)
        role=roles(formed,native,row['signals'][0]);role_map[key]=role
        for kind,active in (('旧要求',True),('A',role['A']),('B',role['B'])):
            if active:support[kind]+=1;support[kind+'_'+row['band']]+=1;scenes[kind].add(row['session'])
    births,stages=generate(features,role_map);result=[];collision=defaultdict(int)
    for row in base:
        key=(row['session'],row['time'],row['line']);role=role_map.get(key);birth=births.get(key);signals=[];widths=[];origins=[];records=[]
        for ci,(a,b) in enumerate(SPECS):
            side=row['signals'][0];width=row['widths'][0];origin='旧190固定';record=None
            if row['band']!='DAY':
                if role is not None and role['A'] and a:
                    side=0 if a==1 else role['native'];origin='A見送り' if a==1 else 'A源方向切替';record={'family':origin,'source_role':role,'time':row['time'],'line':row['line']}
                if role is not None and role['B'] and b:side=0;origin='B見送り' if b==1 else 'B構造待機';record=None
                if b==2 and birth is not None:
                    if side:collision[str(ci)]+=1
                    else:side=birth['side'];width=birth['width'];origin='B構造確認反転';record=birth
            signals.append(side);widths.append(width);origins.append(origin);records.append(record)
        assert signals[0]==row['signals'][0] and widths[0]==row['widths'][0]
        result.append({'session':key[0],'time':key[1],'line':key[2],'band':row['band'],'signals':signals,'widths':widths,'origins':origins,'births':records,'role':role,'extra':row['extra']})
    M.save(HERE/'純入口.json.gz',result)
    sources=[Path(__file__),ROOT/'work/205TOPIX/入口205.py',ROOT/'work/203TOPIX/入口203.py',ROOT/'work/200TOPIX/入口200.py',ROOT/'work/197TOPIX/入口197.py',ROOT/'work/192TOPIX/入口192.py',ROOT/'work/186TOPIX/入口186.py',M.HERE/'入口とIFD.py',ROOT/'scripts/TOPIX入口研究/共通金融.py']
    cfg={'試行':208,'規模':9,'候補':list(NAMES),'情報区分':'205の原因診断後、当初81既使用場で新条件を探索。追加2場は混ぜず、未見性能とは呼ばない。',
      '母体':'旧190D4/N01の共通q0・旧量・元方向と実方向・DayA25/NightW15・H60を基本維持。旧N01以外からの源は作らない。',
      'A':'旧実側=-元側、30/15EMA並び＋21傾きが元側一致、価格は30EMA21元側、5EMA8距離が元側[-0.75,+0.5]ATR5、元側RSI<65・BBz<1。旧P0の短期逆行実体/進行と量>=0.5を保持。旧維持/見送り/元側へ即時切替の3。',
      'B':'旧実側=元側、元側RSI>=65かつBBz>=1、MACDヒスト増分が元側<=0、既知旧1分量>=1。旧維持/その要求を見送り/新側構造確認後の反対、の3。過熱だけで反転しない。',
      'B構造':'源で新側端（買いprior_high/売りprior_low、現足除外の直前3完成1分）と元/新側・幅15pt・源+1200秒を固定。1分終値が固定端を新側へ破断（実体・進行同側）→次の連続1分足が端の新側で保持し逆端侵入<=0.1ATR5、当時旧1分量>=0.5/価格品質。源当時破断既知は記録可、同q0発火不可。',
      'B時計と枠':'完成end差60秒・公表差30〜90秒。欠測でstage破棄。後発源で価格端/期限を更新せず同源一度。監視は未発注で口座枠を占有しない。他の要求は通常通り許容。構造発火とA処理後の即時要求が同q0なら即時を優先し、発火を再利用しない。金融では保有予約合計1。',
      '欠測':'30分履歴/鮮度不足ならA不成立として旧判断を残す。量不明を0/低量と混同せずB確認を成立させない。新5分量補完・VWAP・板新特徴は追加しない。',
      '品質と費用':'発火q0の0<spread<=1.5、1分幅<=2.5ATR5、live既知かつ新側>=-0.25ATR5。単純IFD、終了15分前、miniTOPIX片道41.8円+0.25pt。旧判断を残す要求は旧品質/費用方向を不変。',
      '評価':'前48/後25/追加7/全80/本日1、全場分母、損失頻度/深さ/連続/DD、両中央値/取得/保有率/未知。A/B作用と後続の旧要求の枠変化を分ける。',
      'Source':{p.relative_to(ROOT).as_posix():M.sha(p) for p in sources},'純入口SHA':M.sha(HERE/'純入口.json.gz'),'母体205SHA':M.sha(ROOT/'inputs/00205_TOPIXの長期支持と破断失敗の純入口/純入口.json.gz')}
    assert not (HERE/'条件.json').exists();M.save(HERE/'条件.json',cfg)
    M.save(HERE/'純成立診断.json',{'旧源の役割':dict(support),'役割の場数':{k:len(v) for k,v in scenes.items()},'B構造段階':stages,'即時要求優先で確認を不使用':dict(collision),'Night純成立':{name:sum(bool(r['signals'][i]) for r in result if r['band']!='DAY') for i,name in enumerate(NAMES)},'q0':len(result)})
    print(json.dumps({'候補':9,'q0':len(result),'純入口SHA':cfg['純入口SHA'],'役割':dict(support),'構造':stages,'衝突':dict(collision)},ensure_ascii=False),flush=True)


if __name__=='__main__':prepare()
