"""208の有望Night対照を、少数支持・既使用追加2・前半選択の違いとともに保存する。"""
from pathlib import Path
import json,zipfile,shutil,re,os,hashlib,sys
import 入口208 as E
sys.path.insert(0,str(E.ROOT/'work/196TOPIX'))
from 正式化196 import row_text
TRIAL=E.ROOT/'study/00208_TOPIXの浅い押戻し逆張りを控え損失を比較する'
INPUT=E.ROOT/'inputs/00208_TOPIXの役割別見送りと構造反転の純入口'


def ref(path):
    """
    機能: 資源の位置・サイズ・内容指紋を記録する。
    引数: path(Path)。
    返り値: dictはpath/bytes/sha256。
    """
    return {'path':path.relative_to(E.ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':E.M.sha(path)}


def main():
    """
    機能: 条件・金融・原因・再現Sourceと567セルを、元条件を変えず正式保存する。
    引数: なし。
    返り値: None。全体採用と将来再現を主張しない。
    """
    TRIAL.mkdir(parents=True,exist_ok=True);INPUT.mkdir(parents=True,exist_ok=True);extra=TRIAL/'追加二場と全83';extra.mkdir(exist_ok=True)
    for name in ('条件.json','人工確認.json','純成立診断.json','独立確認.json','原因診断.json','固定選択.json'):shutil.copy2(E.HERE/name,TRIAL/name)
    shutil.copy2(E.HERE/'金融/金融開始前固定.json',TRIAL/'金融開始前固定.json');shutil.copy2(E.HERE/'金融/安定性.json.gz',TRIAL/'全9組安定性.json.gz')
    for name in ('条件固定.json','独立確認.json'):shutil.copy2(E.HERE/'全83'/name,extra/name)
    shutil.copy2(E.HERE/'全83/金融/金融開始前固定.json',extra/'金融開始前固定.json');shutil.copy2(E.HERE/'全83/金融/安定性.json.gz',extra/'全9組全83安定性.json.gz')
    shutil.copy2(E.HERE/'純入口.json.gz',INPUT/'純入口.json.gz');shutil.copy2(E.HERE/'全83/追加二場純入口.json.gz',INPUT/'追加二場純入口.json.gz')
    manifest={'試行':208,'純出生':ref(INPUT/'純入口.json.gz'),'追加二場純出生':ref(INPUT/'追加二場純入口.json.gz'),'条件':ref(TRIAL/'条件.json'),'原板':'inputs/TOPIX原順8列_20260921_20261116/台帳.json','追加原板':'inputs/00194_20261116夜と1117昼の固定適用入力/原順8列/入力台帳.json','母体205':'inputs/00205_TOPIXの長期支持と破断失敗の純入口/入力台帳.json'}
    (INPUT/'入力台帳.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n','utf-8');(INPUT/'README.md').write_text('# TOPIX 208の純入口\n\n[研究正本](../../study/00208_TOPIXの浅い押戻し逆張りを控え損失を比較する/README.md)。旧81場34,424q0と、固定適用した追加2場937q0を分けて保存する。全9条件は旧81で固定し、追加2の結果で選択し直さない。全て既使用の研究であり、原板の複製はない。\n','utf-8')
    prior=E.read(E.ROOT/'study/00205_TOPIXの長期支持と破断失敗を旧入口へ比較する/Source索引.json');sources=sorted(set([E.ROOT/r['path'] for r in prior]+list(E.HERE.glob('*.py'))))
    with zipfile.ZipFile(TRIAL/'Source.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for p in sources:archive.write(p,p.relative_to(E.ROOT).as_posix())
        for name in ('入力台帳.json','条件_実装修正1.json'):
            p=E.M.HERE/name
            if p not in sources:archive.write(p,p.relative_to(E.ROOT).as_posix())
    (TRIAL/'Source索引.json').write_text(json.dumps([ref(p) for p in sources],ensure_ascii=False,indent=2)+'\n','utf-8')
    template=E.ROOT/'docs/議論/手法と時間スケールの汎用表_版8.md';body=template.read_text('utf-8').split('## 設定明細')[0];body=body.replace('# 手法と時間スケールの汎用表・版8','# 208 TOPIX・設定と結果（版8）').replace('全セルは未設定・未検証。','使用セルに設定IDを記す。').replace('未設定・未検証','未使用')
    used={'I01':{3:'A 5EMA8近傍',4:'A 15並び/傾き',5:'A 30並び/傾き/価格'},'I02':{3:'A距離-0.75〜0.5ATR5'},'I03':{3:'B元側hist増分<=0'},'I04':{3:'A元側RSI<65/B>=65'},'I06':{3:'A元側BBz<1/B>=1'},'I08':{3:'S0旧DI/ADX',4:'S0旧DI'},'I09':{1:'B逆端侵入<=0.1ATR5',3:'S0 DayA25'},
      'C01':{3:'S0旧持続',4:'A',5:'A'},'C07':{1:'B破断→保持',4:'A支持',5:'A支持'},'P01':{1:'B実体/端'},'P05':{1:'B進行'},'P06':{1:'B現足除く前3足固定端'},'P07':{1:'B次連続q0保持'},
      'V01':{0:'S0旧累積量時計',1:'S0>=0.5/B源>=1確認>=0.5'},'B01':{0:'正常BBO/旧費用方向保持'},'E01':{0:'R1旧同幅IFD'},'E02':{0:'R1 SL/H60'}}
    count=0;lines=[]
    for line in body.splitlines():
        cells=[c.strip() for c in line.strip().strip('|').split('|')] if line.startswith('|') else []
        if len(cells)==11 and re.fullmatch(r'[A-Z][0-9]{2}',cells[0]):
            count+=1
            for i in range(9):cells[i+2]=used.get(cells[0],{}).get(i,'未使用')
            line='| '+' | '.join(cells)+' |'
        lines.append(line)
    assert count==63
    body='\n'.join(lines)+'\n';body=re.sub(r'\]\(([^)]+)\)',lambda m:']('+os.path.relpath((template.parent/m.group(1)).resolve(),TRIAL).replace('\\','/')+')',body)
    body+='''
## 設定明細と複合評価

S0は旧190D4/N01。Aは旧実側=-元側で、30/15EMA並び＋21傾きが元側一致、価格が30EMA21元側、5EMA8距離が元側[-0.75,+0.5]ATR5、元側RSI<65・BBz<1。旧維持/見送り/元側切替の3行動。旧P0の短期逆行と既知量条件は保持する。

Bは旧実側=元側、元側RSI>=65・BBz>=1・MACDヒスト増分<=0・既知旧1分量>=1。旧維持/その場の見送り/構造確認後の反対の3行動。高RSIだけを反転根拠にしない。

Bの構造は源時の現足を除く直前3完成1分端を固定し、新側へ終値破断して実体・進行同側→次の連続足で端の新側を保持、逆端侵入<=0.1ATR5、旧1分量>=0.5と価格品質を確認。源当時の破断既知は記録するが、同q0発火不可。源+20分と幅15ptを固定し、後発源で延長しない。欠測はstage破棄。監視は未発注で口座枠を占有しない。同q0はA処理後の通常即時を優先し、使わなかった発火を再利用しない。

価格品質は0<spread<=1.5、1分幅<=2.5ATR5、live既知かつ実側>=−0.25ATR5。新しい5分量補完・板・VWAPは加えない。30分不足ならA不成立で旧判断を維持し、不足を混在相場と呼ばない。

R1は旧DayA25/NightW15/H60、単純IFD、保有予約合計1、終了15分前。A3がNightの有望主で、全体採用は保留。Bは実取得支持が1件。[条件](条件.json)・[結果](全9組安定性.json.gz)・[原因](原因診断.json)。指標単独効果や将来再現とはしない。

## 版と再現

版8は63手法×9尺度=567セル。[Source](Source.zip)・[索引](Source索引.json)・[恒久純入口](../../inputs/00208_TOPIXの役割別見送りと構造反転の純入口/入力台帳.json)。旧81と追加2は全て既使用、追加で条件・主案を選び直さない。
''';body+='\n汎用表SHA256: '+hashlib.sha256(template.read_bytes()).hexdigest()+'\n';(TRIAL/'設定と結果.md').write_text(body,'utf-8')
    states=E.read(E.HERE/'金融/安定性.json.gz')['metrics'];full=E.read(E.HERE/'全83/金融/安定性.json.gz')['metrics'];header='| index | 取得 / 参加場 | 保有下限 | 未知 | 利益円 | 損失円 | 既知収支円 | 建玉 / 場中央値下限円 | 場末DD円 |\n| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |\n'
    report='''# 208 TOPIXの浅い押戻し逆張りを控え損失を比較する

2026-11-18作成。**Nightの有望主をindex3（A見送り・B旧維持）として固定する。全体採用ではない。** 旧入口に対し参加する場・両中央値黒字・約29%の保有時間を維持し、損失額と累計DD、後25期間の赤字を縮小した。ただし新条件が基準の実取得に作用したAは5件だけで、取得枠の変化も改善に寄与する。赤字場数・連敗・初期損失は改善していない。

## 仮説と入力

[205](../00205_TOPIXの長期支持と破断失敗を旧入口へ比較する/README.md)は独立新枝を加えて参加を増やせたが損失を増した。今回は既存の要求を基本的に残し、当時の技術的な役割と旧実方向が矛盾する部分だけを控える/切り替える。[外部研究と独自仮説](../../docs/technical-analysis/市場心理/日中の順行と反転を時間順序と需要で分ける.md)が述べる需要の継続、失速と転換の違いを参照するが、今回のRSI/BB等の閾値を外部研究が実証したわけではない。

当初81場（2026-09-21Day〜11-16Day）で9条件を固定。全80発見と前48選択/後25/追加7を分けるが全て既使用。その後、同じ9条件を11-16Night/11-17Dayへ再選択せず適用した。追加2も既使用対照である。[条件](条件.json)・[設定と結果](設定と結果.md)。

Aは長中期支持下で過熱していない浅い押戻しを、旧判断が反対側へ売買しようとする場面。旧維持/見送り/源方向へ切替。Bは過熱＋MACD失速＋量がある場面の旧順行要求。旧維持/見送り/固定3足端の反対側破断と後足保持を待つ、の3行動。A/Bは旧実方向との関係で排他、3×3=9。価格構造前のB即時反転は候補にしない。

miniTOPIX1枚、1pt=1,000円、片道41.8円+0.25pt。旧DayA25/NightW15/H60、単純IFD、ラージBBO代用、遅延1秒/取得TTL30秒、保有予約合計1。開始待機なし、15:30/05:45までに決済。金融未知は0円や既知利益に置換せず、場末まで枠を保持する。

## 旧81・9案のNight結果

index0〜2はA旧維持、3〜5はA見送り、6〜8はA源側切替。各3案のBは旧維持/見送り/構造確認反転の順。分母40Night。

'''+header+'\n'.join(row_text(i,'NIGHT',states) for i in range(9))+'''

主3は前48+217,644.8円/後25−11,516円/追加7+24,411.6円。旧0の前48+220,561.2円/後25−22,266.8円/追加7+24,411.6円に対して、後半の赤字を縮小するが黒字化したとはしない。前48順位首位は6（源側切替）で、全期発見の3とは別である。前48選択を後から3へ置き換えない。[固定選択](固定選択.json)。

## 全83でも主3を維持

'''+header+'\n'.join(row_text(i,'NIGHT',full) for i in (0,3,6))+'''

分母41Night。主3は損失555,020.8→537,937.2円、DD40,681.6→29,016円、利益791,892.4→782,643.2円、既知収支236,871.6→244,706円。取得176→172、参加38/41場・未知7は同じ。保有29.30→28.54%、建玉/場中央値下限+416.4/+582円。Dayは全案旧対照のままで、214取得/42場・保有55.35%・利益878,220.4/損失830,610.8/収支+47,609.6円、未知0。

追加Night4取得+14,165.6円、追加Day7取得+4,914.8円は全9案同体。追加2にA/Bの該当要求がなかったため、Aの効果が別の2場で再現したとは言えない。[追加二場と全83](追加二場と全83/README.md)。

## 改善した項目と変わらない項目

旧81の主3は損失額・DD・最悪場（−19,752.4→−19,001.6円）・最悪5場の既知寄与（−27,172→−14,926円）を改善した。一方、既知赤字取引数は76→75でも分母が172→168へ減るため赤字率下限は44.19→44.64%へわずかに上がる。赤字場10/40、取引連敗6、場連敗2〜3、初期損失−11,088.4円は変わらない。未知7があるため、経路は既知寄与と完全確定部分を分ける。

[原因診断](原因診断.json)では、A純要求157件/27場に対し、基準の実取得でAに該当したのは5件/5場のみ。全て±15pt未到達Nで、利益9,249.2/損失14,167.2/収支−4,918円だった。これを源方向へ反転した6の同5件も−5,918円なので、見送ることと反対売買の優位は同義ではない。

主3の実取得差は、基準だけ6件−20,501.6円と比較口座だけ2件−12,667.2円。Aで取り除いた5件のほか、後続の通常旧入口が1件変わった。口座の+7,834.4円改善をA五件の単独効果とは呼ばない。個票は当時の指標・q0・源方向・実方向とともに原因正本へ保存した。

Bは純要求37件/14場→固定源21→構造発火14だが、基準の実取得では1件だけ。2026-11-06 03:11の通常旧順行は+5,416.4円、構造確認で03:12へ遅らせ反対売買した2では−15,083.6円。Bの一般的な有効/無効を1件から断定しない。未知と未成立、保有/予約棄却、即時要求優先で使わなかった確認を分けている。

## 検査・再現

[人工確認](人工確認.json)12,936項目でA/B排他、売買鏡像、価格構造前の不発火、別足保持、欠測破棄、源期限非更新、旧量不明/低量、接頭部同体、一度発火を確認。[独立確認](独立確認.json)は3,396取得・金融44,148属性・別集計28,998属性・全q0枠33,591件が一致し、旧190も同体。

追加は99取得・金融1,287属性・全q0枠819件、全83別集計39,006属性を独立照合。旧81の全9台帳・全群・条件/純出生/選択票は不変。[金融開始前固定](金融開始前固定.json)と追加票に原順NPZ/実行SourceのSHAを保持する。

[Source](Source.zip)・[索引](Source索引.json)・[恒久純入口](../../inputs/00208_TOPIXの役割別見送りと構造反転の純入口/README.md)。Python3.14.3/NumPy2.5.4/tzdata2026.6。旧81は共通金融へ `--condition work/208TOPIX/条件.json --births work/208TOPIX/純入口.json.gz --output work/208TOPIX/金融 --id-template TOPIX208_{name}_DayA25_H60` を渡す。金融/安定性.json.gzは全9組安定性.json.gzと同一SHA。旧固定選択票を配置した後、追加適用208.pyの「純固定」→「金融」で全83を同体再生できる。既存出力を上書きしない。
''';(TRIAL/'README.md').write_text(report,'utf-8')
    (extra/'README.md').write_text('''# 208の追加2場と全83固定適用

旧81で固定した全9案を、既使用の2026-11-16Nightと11-17Dayへ条件・選択を変えず適用した。主3は金融前の旧選択票のまま。[条件固定](条件固定.json)・[金融開始前固定](金融開始前固定.json)・[全83正本](全9組全83安定性.json.gz)・[独立確認](独立確認.json)。

追加はNight4取得+14,165.6円、Day7取得+4,914.8円で全9同体、金融未知0。A/Bの当時純要求が0だったため、条件の効果を追加2が再確認したとは言わない。全83の経路比較は[研究正本](../README.md)に掲載した。旧81を追加結果で書き換えず、閾値・方向・主案の再選択をしていない。
''','utf-8')
    print(json.dumps({'正式化':str(TRIAL),'表セル':567,'Source数':len(sources),'旧81主':3,'追加再選択':False},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
