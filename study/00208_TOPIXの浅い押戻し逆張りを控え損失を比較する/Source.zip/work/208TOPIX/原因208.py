"""役割変更が実際に取得した少数建玉と、後続枠の変化を分離して固定する。"""
from collections import defaultdict
from datetime import datetime
from zoneinfo import ZoneInfo
import sys,json
import 入口208 as E
sys.path.insert(0,str(E.ROOT/'work/202TOPIX'))
from 原因202 import describe
import 金融を比較する as F


def keys(ledger):
    """
    機能: Night実取得のq0・方向・幅を不変キーへ写す。
    引数: ledger(dict)。
    返り値: dict[tuple,int]。
    """
    return {(s,ledger['request_time'][i],ledger['request_line'][i],ledger['side'][i],ledger['width'][i]):i for i,s in enumerate(ledger['scene']) if 'Night' in s}


def record(ledger,i,role):
    """
    機能: 変更対象の実取得を日時と元/実側・損益で追跡可能にする。
    引数: ledger(dict),i(int),role(dict|None)。
    返り値: dict。未来損益から役割を決めた記録ではない。
    """
    return {'session':ledger['scene'][i],'q0':datetime.fromtimestamp(ledger['request_time'][i],ZoneInfo('Asia/Tokyo')).isoformat(),
      'side':ledger['side'][i],'width':ledger['width'][i],'known':ledger['known'][i],'net':ledger['net'][i],'label':ledger['label'][i],'reason':ledger['reason'][i],
      'origin':ledger['origin'][i],'role':role}


def main():
    """
    機能: 9固定口座の群、実取得差、損失安定性、前半選択を別々に保存する。
    引数: なし。
    返り値: None。追加2の金融を読む前にNight主候補3を固定する。
    """
    states=E.read(E.HERE/'金融/安定性.json.gz')['metrics'];packs=[E.read(E.HERE/'金融/金融正本'/(s['id']+'.json.gz')) for s in states];pure={(r['session'],r['time'],r['line']):r for r in E.read(E.HERE/'純入口.json.gz')};base=packs[0]['ledger'];basekeys=keys(base);results=[]
    for ci,pack in enumerate(packs):
        ledger=pack['ledger'];current=keys(ledger);groups=defaultdict(list)
        for k,i in current.items():
            p=pure[k[:3]];role=p['role'];kind='A該当' if role and role['A'] else 'B該当' if role and role['B'] else '通常旧又は確認';origin=ledger['origin'][i]
            for name in ('全体',kind,origin,'帯/'+p['band'],origin+'/'+ledger['reason'][i]):groups[name].append(i)
        common=set(basekeys)&set(current);removed=set(basekeys)-set(current);added=set(current)-set(basekeys)
        for k in common:assert base['net'][basekeys[k]]==ledger['net'][current[k]] and base['known'][basekeys[k]]==ledger['known'][current[k]]
        results.append({'index':ci,'id':pack['id'],'群':{k:describe(ledger,idx) for k,idx in groups.items()},'実取得差':{'共通':describe(ledger,[current[k] for k in sorted(common)]),
            '基準だけ':describe(base,[basekeys[k] for k in sorted(removed)]),'比較口座だけ':describe(ledger,[current[k] for k in sorted(added)]),
            '基準だけの個票':[record(base,basekeys[k],pure[k[:3]]['role']) for k in sorted(removed)],'比較だけの個票':[record(ledger,current[k],pure[k[:3]]['role']) for k in sorted(added)]}})
    rankings={}
    for period in ('全80','前48'):
        for band in ('DAY','NIGHT','ALL'):
            baseline=states[0]['periods'][period][band];order=sorted(range(9),key=lambda i:(F.A.rank_key(states[i]['periods'][period][band],baseline),states[i]['id']))
            rankings[f'{period}_{band}']=[{'index':i,'id':states[i]['id'],'gate':F.A.gate(states[i]['periods'][period][band],baseline)} for i in order]
    E.M.save(E.HERE/'原因診断.json',{'区分':'旧81の固定金融を事後分解。役割の純成立数と実際に作用した取得数を分け、後続枠効果を技術単独の優位としない。','候補':results,'SourceSHA':E.M.sha(E.HERE/'原因208.py')})
    E.M.save(E.HERE/'固定選択.json',{'全体採用':None,'Night有望主index':3,'理由':'全80/旧81で参加場/両中央値正/約29%保有/未知数を維持し、損失額とDD・後25赤字を縮小。既使用探索と少数変更の支持を保持し、追加2では再選択しない。','全期発見と前48順位':rankings,'条件SHA':E.M.sha(E.HERE/'条件.json'),'純入口SHA':E.M.sha(E.HERE/'純入口.json.gz'),'旧81金融SHA':E.M.sha(E.HERE/'金融/安定性.json.gz')})
    for ci in (0,2,3,6):
        r=results[ci];print(json.dumps({'index':ci,'群':r['群'],'取得差':r['実取得差']},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
