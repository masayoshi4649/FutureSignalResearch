"""A/B役割の鏡像と、B構造の順序・固定期限・欠測破棄・因果性を検査する。"""
from copy import deepcopy
import json
import 入口208 as E
import 人工検査 as T


def key(row):
    """
    機能: 完成足公表q0の不変キーを返す。
    引数: row(dict)。
    返り値: tuple[str,float,int]。
    """
    return row['session'],row['time'],row['line']


def main():
    """
    機能: 金融を見る前に役割切替と構造確認の重要な境界を検査する。
    引数: なし。
    返り値: None。未見性能や採用の証明ではない。
    """
    features=E.read(E.ROOT/'inputs/TOPIX原順8列_20260921_20261116/純特徴183.json.gz');source=deepcopy(next(r for r in features if r['m30'] is not None));scene='2026-09-21_Night';t=E.M.bounds(scene)[0]+3600;checks=0
    source.update(session=scene,time=t,line=1,band='PRE',close=4001.2,prior_close=4001.5,prior_low=4000.,prior_high=4003.,low=4001.,high=4002.,body=-.3,progress=-.15,atr=2.,range=.5,rvol=2.,live=0.,spread=.5)
    for name in ('m5','m15','m30'):source[name].update(end=t,published=t,ema8=4001.,ema21=3999.,slope=.1)
    source['m5'].update(rsi=55.,bbz=.4,hist_delta=.1)
    for mirrored in (False,True):
        r=T.mirror(source) if mirrored else source;native=-1 if mirrored else 1;role=E.roles(r,native,-native)
        assert role['A'] and not role['B'];checks+=2
        bad=deepcopy(r);bad['m30']=None;assert not E.roles(bad,native,-native)['A'];checks+=1
        bad=deepcopy(r);bad['m30']['published']=bad['time']+1;assert not E.roles(bad,native,-native)['A'];checks+=1
    # ----------------------------------------
    # 過熱失速だけで発火せず、異なる足の固定端破断→保持を待つ。
    source['m5'].update(rsi=68.,bbz=1.5,hist_delta=-.1)
    broken=deepcopy(source);broken.update(time=t+60,line=2,prior_close=4001.2,close=3999.,low=3998.5,high=4001.,body=-1.,progress=-1.)
    hold=deepcopy(broken);hold.update(time=t+120,line=3,prior_close=3999.,close=3998.5,high=3999.9,low=3998.)
    for mirrored in (False,True):
        s,b,h=[T.mirror(r) for r in (source,broken,hold)] if mirrored else [source,broken,hold];native=-1 if mirrored else 1;role=E.roles(s,native,native)
        assert role['B'] and not role['A'];checks+=2
        state=E.new_seed(s,role);fixed={k:deepcopy(v) for k,v in state.items() if k!='broken'}
        assert E.advance(state,s) is None;assert E.advance(state,b) is None;checks+=2
        assert E.advance(state,b) is None;checks+=1
        state=E.new_seed(s,role);E.advance(state,b);birth=E.advance(state,h);assert birth is not None;checks+=1
        assert state['prior_ends']==[t-180,t-120,t-60] and birth['source_end']<=birth['broken']['end']<birth['confirmation_end'];checks+=2
        assert {k:v for k,v in state.items() if k!='broken'}==fixed;checks+=1
        out,_=E.generate([s,b,h],{key(s):role});assert sum(v is not None for v in out.values())==1;checks+=1
        for failure in ('非連続','量不明','量不足','時計間隔','期限'):
            bad=deepcopy(h)
            if failure=='非連続':bad['time']=t+180
            elif failure=='量不明':bad['rvol']=None
            elif failure=='量不足':bad['rvol']=.1
            elif failure=='時計間隔':bad['time']=t+151
            else:bad['time']=t+1201
            out,_=E.generate([s,b,bad],{key(s):role});assert not any(out.values()),failure;checks+=1
        # 後発Bがあっても源時刻と20分期限を更新しない。
        out,_=E.generate([s,b,h],{key(s):role,key(b):role});live=[v for v in out.values() if v is not None];assert len(live)==1 and live[0]['time']==t and live[0]['expiry']==t+1200;checks+=3
        already=deepcopy(s);already.update(close=b['close'],prior_close=s['prior_close'],body=b['body'],progress=b['progress']);firsthold=deepcopy(h);firsthold.update(time=t+60,line=2)
        out,_=E.generate([already,firsthold],{key(already):role});assert sum(v is not None for v in out.values())==1 and out[key(already)] is None;checks+=2
    # ----------------------------------------
    # 実特徴の役割は売買鏡像で同体、未来追加で接頭部と源時刻が変わらない。
    base=E.read(E.ROOT/'inputs/00205_TOPIXの長期支持と破断失敗の純入口/純入口.json.gz');maps={key(r):r for r in features};contexts=E.E.P.B.context_rows(features);roles={};mirrors={}
    for p in base:
        if p['band']=='DAY' or not p['signals'][0]:continue
        k=key(p);r=maps[k];native=E.E.P.B.native(r,contexts[k],p['extra'],0);actual=p['signals'][0];role=E.roles(r,native,actual);other=E.roles(T.mirror(r),-native,-actual)
        assert role['A']==other['A'] and role['B']==other['B'];checks+=2
        roles[k]=role;mirrors[k]=other
    full,counts=E.generate(features,roles);prefix,_=E.generate(features[:5000],roles);opposite,_=E.generate([T.mirror(r) for r in features[:5000]],mirrors)
    for k,birth in prefix.items():
        assert full[k]==birth;other=opposite[k];assert (birth is None)==(other is None);checks+=2
        if birth is not None:assert birth['side']==-other['side'] and birth['time']==other['time'];checks+=2
    seen=set()
    for k,birth in full.items():
        if birth is None:continue
        marker=(k[0],birth['time'],birth['line']);assert marker not in seen;seen.add(marker);checks+=1
        assert birth['time']<=birth['broken']['time']<birth['confirmed']<=birth['expiry']==birth['time']+1200 and birth['width']==15.;checks+=2
    proof={'成功':True,'項目数':checks,'A_B排他':True,'売買鏡像':True,'価格構造前に反転発火なし':True,'源当時破断は後足保持を待つ':True,'同足再参照不可':True,'欠測stage破棄':True,'期限非更新':True,'旧量不明と低量を区別':True,'prefix同体':True,'同源一度':True,'構造段階':counts,'SourceSHA':E.M.sha(E.HERE/'入口208.py')}
    E.M.save(E.HERE/'人工確認.json',proof);print(json.dumps(proof,ensure_ascii=False),flush=True)


if __name__=='__main__':main()
