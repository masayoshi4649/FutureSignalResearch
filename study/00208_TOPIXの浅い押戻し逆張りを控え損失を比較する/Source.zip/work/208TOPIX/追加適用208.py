"""208の9固定条件を既使用追加2へ再選択せず適用し、全83経路を検算する。"""
from pathlib import Path
from collections import defaultdict
from copy import deepcopy
import argparse,json,sys,math,subprocess
import numpy as np
import 入口208 as E
sys.path.insert(0,str(E.ROOT/'scripts/TOPIX入口研究'))
import 共通金融 as C
sys.path.insert(0,str(E.ROOT/'work/183損失安定性'))
import TOPIXを独立検算する as T
DEST=E.HERE/'全83';INPUT=E.ROOT/'inputs/00194_20261116夜と1117昼の固定適用入力'


def apply_fixed(base,features):
    """
    機能: 固定208の役割・構造生成をそのまま使って入力別の9純出生を作る。
    引数: base/features(list[dict])。
    返り値: tuple[list[dict],dict]。旧81で完全同体を照合してから追加へ使う。
    """
    maps={(r['session'],r['time'],r['line']):r for r in features};contexts=E.E.P.B.context_rows(features);role_map={};support=defaultdict(int)
    for row in base:
        if row['band']=='DAY' or not row['signals'][0]:continue
        key=(row['session'],row['time'],row['line']);formed=maps[key];native=E.E.P.B.native(formed,contexts[key],row['extra'],0);assert native in (-1,1)
        role_map[key]=E.roles(formed,native,row['signals'][0])
        for name in ('A','B'):support[name]+=bool(role_map[key][name])
    births,stages=E.generate(features,role_map);result=[];collision=defaultdict(int)
    for row in base:
        key=(row['session'],row['time'],row['line']);role=role_map.get(key);birth=births.get(key);signals=[];widths=[];origins=[];records=[]
        for ci,(a,b) in enumerate(E.SPECS):
            side=row['signals'][0];width=row['widths'][0];origin='旧190固定';record=None
            if row['band']!='DAY':
                if role is not None and role['A'] and a:
                    side=0 if a==1 else role['native'];origin='A見送り' if a==1 else 'A源方向切替';record={'family':origin,'source_role':role,'time':row['time'],'line':row['line']}
                if role is not None and role['B'] and b:side=0;origin='B見送り' if b==1 else 'B構造待機';record=None
                if b==2 and birth is not None:
                    if side:collision[str(ci)]+=1
                    else:side=birth['side'];width=birth['width'];origin='B構造確認反転';record=birth
            signals.append(side);widths.append(width);origins.append(origin);records.append(record)
        result.append({'session':key[0],'time':key[1],'line':key[2],'band':row['band'],'signals':signals,'widths':widths,'origins':origins,'births':records,'role':role,'extra':row['extra']})
    return result,{'役割':dict(support),'構造':stages,'同時即時優先':dict(collision)}


def prepare():
    """
    機能: 旧81との出生同体と追加純入力を確認し、全9案を追加金融前に封印する。
    引数: なし。
    返り値: None。旧条件・純出生・金融・主3選択票は変更しない。
    """
    assert not (DEST/'条件固定.json').exists();old_cfg=E.read(E.HERE/'条件.json');assert all(E.M.sha(E.ROOT/p)==v for p,v in old_cfg['Source'].items())
    old=E.read(E.HERE/'純入口.json.gz');recreated,_=apply_fixed(E.read(E.ROOT/'inputs/00205_TOPIXの長期支持と破断失敗の純入口/純入口.json.gz'),E.read(E.ROOT/'inputs/TOPIX原順8列_20260921_20261116/純特徴183.json.gz'));assert old==recreated
    added,diag=apply_fixed(E.read(INPUT/'TOPIX/純入口192追加二場.json.gz'),E.read(INPUT/'TOPIX/純特徴183.json.gz'));assert {r['session'] for r in added}=={'2026-11-16_Night','2026-11-17_Day'}
    E.M.save(DEST/'追加二場純入口.json.gz',added);E.M.save(DEST/'純入口83.json.gz',old+added)
    cfg=deepcopy(old_cfg);cfg['純入口SHA']=E.M.sha(DEST/'純入口83.json.gz');cfg['Source'][Path(__file__).relative_to(E.ROOT).as_posix()]=E.M.sha(Path(__file__))
    cfg['情報区分']='旧81で固定した9条件を全83へ同体適用。追加2も既使用対照。主3を変更せず、方向・閾値・Sourceの再探索なし。'
    cfg['旧固定指紋']={name:E.M.sha(E.HERE/name) for name in ('条件.json','純入口.json.gz','固定選択.json','金融/安定性.json.gz')}
    cfg['旧81純出生同体']=True;cfg['追加純入口SHA']=E.M.sha(DEST/'追加二場純入口.json.gz');cfg['追加純入力']={p.relative_to(E.ROOT).as_posix():E.M.sha(p) for p in (INPUT/'TOPIX/純入口192追加二場.json.gz',INPUT/'TOPIX/純特徴183.json.gz',INPUT/'原順8列/入力台帳.json')};cfg['追加診断']=diag
    E.M.save(DEST/'条件固定.json',cfg);print(json.dumps({'旧81同体':True,'追加q0':len(added),'診断':diag,'候補':9,'旧81の主':3},ensure_ascii=False),flush=True)


def finance():
    """
    機能: 共通金融で全83を再生し、旧81同体・追加2の全q0と金融を独立確認する。
    引数: なし。
    返り値: None。追加の結果で候補や閾値を選び直さない。
    """
    cfg=E.read(DEST/'条件固定.json');assert all(E.M.sha(E.ROOT/p)==v for p,v in cfg['追加純入力'].items())
    subprocess.run([sys.executable,str(E.ROOT/'scripts/TOPIX入口研究/共通金融.py'),'--condition',str(DEST/'条件固定.json'),'--births',str(DEST/'純入口83.json.gz'),'--output',str(DEST/'金融'),'--id-template','TOPIX208_{name}_DayA25_H60','--extra'],cwd=E.ROOT,check=True)
    states=E.read(DEST/'金融/安定性.json.gz')['metrics'];oldstates=E.read(E.HERE/'金融/安定性.json.gz')['metrics'];packs=[E.read(DEST/'金融/金融正本'/(s['id']+'.json.gz')) for s in states];pure=E.read(DEST/'追加二場純入口.json.gz');by=defaultdict(list)
    for row in pure:by[row['session']].append(row)
    checks={'追加金融属性':0,'追加取得':0,'追加全q0枠':0,'全83独立集計':0,'旧81台帳同体':0}
    for ci,(pack,state) in enumerate(zip(packs,states)):
        old=E.read(E.HERE/'金融/金融正本'/(state['id']+'.json.gz'));n=len(old['ledger']['net'])
        for k,v in old['ledger'].items():assert pack['ledger'][k][:n]==v
        assert pack['positions'][:n]==old['positions'] and pack['sessions'][:81]==old['sessions'] and pack['diagnostics'][:81]==old['diagnostics']
        assert state['periods']['旧81']==oldstates[ci]['groups'];checks['旧81台帳同体']+=1;checks['全83独立集計']+=T.inspect_groups(pack,state)
    for entry in C.entries(True)[81:]:
        scene=entry['session'];start,end,force=T.bounds(scene)
        with np.load(entry['cache_absolute'],allow_pickle=False) as archive:raw={k:archive[k] for k in ('now','line','bid','ask','valid')}
        t=raw['now'];finite=np.isfinite(t);prior=np.maximum.accumulate(np.where(finite,t,-np.inf));mask=finite&(t>=start)&(t<end)&(t>=prior)&raw['valid'];arrays={k:v[mask] for k,v in raw.items() if k!='valid'};cache={}
        for ci,pack in enumerate(packs):
            ledger=pack['ledger'];indices=[i for i,s in enumerate(ledger['scene']) if s==scene];cursor=0;busy=-math.inf
            for row in by[scene]:
                side=row['signals'][ci]
                if not side:continue
                checks['追加全q0枠']+=1
                if row['time']<=busy:continue
                query=(row['time'],side,row['widths'][ci])
                if query not in cache:
                    first=int(np.searchsorted(arrays['now'],row['time']+1));fillable=first<len(arrays['now']) and arrays['now'][first]<=min(row['time']+30,force) and arrays['now'][first]<force
                    cache[query]=T.financial_oracle(arrays,scene,*query) if fillable else None
                cell=cache[query]
                if cell is None:busy=min(row['time']+30,force);continue
                assert cursor<len(indices);i=indices[cursor];cursor+=1;checks['追加取得']+=1
                for field,value in cell.items():
                    actual=pack['positions'][i][field] if field=='confirmed_until' else ledger[field][i];checks['追加金融属性']+=T.V.check_equal(actual,value,(ci,scene,i,field))
                assert ledger['request_time'][i]==row['time'] and ledger['request_line'][i]==row['line'] and ledger['origin'][i]==row['origins'][ci]
                busy=ledger['exit_time'][i] if ledger['known'][i] else end
            assert cursor==len(indices)
    assert all(E.M.sha(E.HERE/p)==v for p,v in cfg['旧固定指紋'].items())
    proof={'成功':True,'候補':9,**checks,'旧81の条件純出生金融選択票不変':True,'再選択':False,'追加2は既使用対照':True,'全83金融SHA':E.M.sha(DEST/'金融/安定性.json.gz'),'SourceSHA':E.M.sha(Path(__file__))}
    E.M.save(DEST/'独立確認.json',proof);print(json.dumps(proof,ensure_ascii=False),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('段階',choices=('純固定','金融'));args=parser.parse_args()
    if args.段階=='純固定':prepare()
    else:finance()
