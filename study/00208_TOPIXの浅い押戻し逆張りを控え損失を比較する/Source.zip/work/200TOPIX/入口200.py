"""価格時計の過去被覆と、入口源からの構造回復順序を分離する。"""
from pathlib import Path
from collections import defaultdict
import sys,json,math
import numpy as np
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
sys.path.insert(0,str(ROOT/'work/197TOPIX'))
import 入口197 as B
M=B.M;read=B.read
MOTHERS=('旧共通1分量','旧優先和集合量補完')
QUALITIES=('品質制限なし','過去10分被覆','過去30分被覆')
MODES=('源で即時','実反転側を時間順確認','両側を時間順確認')
SPECS=tuple((mother,quality,mode) for mother in (0,1) for quality in range(3) for mode in range(3))
NAMES=tuple(f'N{i:02d}_{MOTHERS[m]}_{QUALITIES[q]}_{MODES[o]}' for i,(m,q,o) in enumerate(SPECS))


def quality_for_scene(data,keys):
    """
    機能: q0原行以前の正常BBO価格時計を用い、直前窓の観測被覆を計測する。
    引数: data(dict[str,np.ndarray]),keys(list[tuple[str,float,int]])。
    返り値: dict[tuple,dict]。受信時計や真のBBO鮮度ではなく価格時計上の代理。
    """
    now=data['now'];line=data['line'];finite=np.isfinite(now)
    order=finite&(now>=np.maximum.accumulate(np.where(finite,now,-np.inf)))
    observed=order;good=order&data['valid'];gt=now[good];gl=line[good];ot=now[observed];ol=line[observed]
    result={}
    for key in keys:
        scene,t,source_line=key;start,_,_=M.bounds(scene);windows={}
        end=int(np.searchsorted(gl,source_line,side='right'));iend=int(np.searchsorted(ol,source_line,side='right'))
        for duration in (600,1800):
            begin=t-duration;known=begin>=start;left=int(np.searchsorted(gt[:end],begin-30,side='left'))
            seen=np.unique(gt[left:end]);seen=seen[(seen<=t)&(seen>=start)]
            starts=np.maximum(seen,begin);stops=np.minimum(seen+30,t)
            if len(seen)>1:stops[:-1]=np.minimum(stops[:-1],seen[1:])
            coverage=float(np.maximum(0,stops-starts).sum())
            before=seen[seen<=begin];boundary=len(before)>0 and begin-before[-1]<=30
            within=seen[seen>=begin];gap=float(np.max(np.diff(np.r_[begin,within,t])))
            ix=int(np.searchsorted(ot[:iend],begin,side='left'));observations=ot[ix:iend]
            repeats=int(np.sum(np.diff(observations)==0)) if len(observations)>1 else 0
            windows[str(duration)]={'場内窓':bool(known),'開始端確認':bool(boundary),'被覆秒':coverage,'被覆率':coverage/duration,
                '最大空白秒':gap,'正常異時刻数':int(len(within)),'観測行数':int(len(observations)),'同時計反復行数':repeats,
                '通過':bool(known and boundary and gap<=90 and coverage/duration>=.9)}
        result[key]={'windows':windows,'最大参照原行':int(gl[end-1]) if end else None}
    return result


def usable(row,extra,mother):
    """
    機能: 確認q0の量を源と同じ方式で評価する。
    引数: row/extra(dict),mother(int)は0旧1分、1不明時5分補完。
    返り値: bool。未来量・既知0の上書きを使わない。
    """
    rv=row['rvol'] if row['rvol'] is not None or mother==0 else extra['rvol5']
    return rv is not None and rv>=.5


def make_seed(row,side,native,mother):
    """
    機能: 源q0の方向と価格水準、失効時刻を不変の監視状態にする。
    引数: row(dict),side/native(int),mother(int)。
    返り値: dict。監視は注文予約ではなく、金融の保有枠を消費しない。
    """
    reverse=side==-native;edge=row['prior_high'] if side==1 else row['prior_low']
    return {'time':row['time'],'line':row['line'],'side':side,'native':native,'reverse':reverse,'mother':mother,
        'level':edge if reverse else row['m5']['ema8'],'expiry':row['time']+600,'band':row['band'],'armed':None,
        'level_kind':'源前3本端' if reverse else '源EMA8'}


def advance(seed,row,extra):
    """
    機能: 源の固定端突破を記録し、次の連続q0で保持と動力・量を確認する。
    引数: seed(dict)は変更される監視状態,row/extra(dict)は当時確認行。
    返り値: boolは一度だけ発火。期限・固定端・方向は変更しない。
    """
    if row['time']<=seed['time']:return False
    side=seed['side'];level=seed['level'];armed=seed['armed'];start=M.bounds(row['session'])[0]
    if armed is not None:
        consecutive=int((row['time']-start)//60)-int((armed-start)//60)==1
        gap=row['time']-armed;extreme=row['low'] if side==1 else row['high']
        held=side*(row['close']-level)>0 and side*(extreme-level)>=-.1*row['atr']
        momentum=side*(row['m5']['hist_delta'] or 0)>0 or side*(row['m5']['rsi_delta'] or 0)>0
        if consecutive and 30<=gap<=90 and held and momentum and usable(row,extra,seed['mother']):return True
        seed['armed']=None
    crossing=side*(row['prior_close']-level)<=0<side*(row['close']-level)
    if crossing and side*row['body']>0 and side*row['progress']>0:seed['armed']=row['time']
    return False


def transitions(base,maps,contexts):
    """
    機能: 母体2×時計3の出生を品質選別から独立に生成する。
    引数: base(list[dict])は197固定純入口,maps/contexts(dict)。
    返り値: tuple[dict,dict]はq0別出生と監視診断。後発源で期限を延長しない。
    """
    result={};counts=defaultdict(int);pending={};last_scene=None
    for item in base:
        key=(item['session'],item['time'],item['line']);scene,t,line=key
        if scene!=last_scene:pending.clear();last_scene=scene
        births=[]
        for mother in (0,1):
            ro=maps[0].get(key);rd=maps[1].get(key);row=ro if ro is not None else rd
            # 共通母体の監視も旧形成だけを使い、後から直接形成へ切り替えない。
            if mother==0:row=ro
            source=item['signals'][0 if mother==0 else 12] if item['band']!='DAY' else 0
            form=0 if row is ro else 1
            native=B.native(row,contexts[form][key],item['extra'],mother) if source and row is not None else 0
            for mode in range(3):
                pk=(mother,mode);birth=None;state=pending.get(pk)
                if state is not None and (t>state['expiry'] or item['band']!=state['band']):
                    counts['期限又は帯境界失効']+=1;pending.pop(pk);state=None
                if state is not None:
                    confirm_row=maps[state['form']].get(key)
                    if source:counts['監視中の後発源を無視']+=1
                    if confirm_row is not None and advance(state,confirm_row,item['extra']):
                        birth={k:v for k,v in state.items() if k!='armed'};birth['confirmed']=t
                        pending.pop(pk);counts['時間順確認発火']+=1
                elif source and row is not None:
                    assert native!=0
                    seed=make_seed(row,source,native,mother);seed['form']=form
                    if mode==0 or (mode==1 and not seed['reverse']):
                        birth={k:v for k,v in seed.items() if k!='armed'};birth['confirmed']=t;counts['即時発火']+=1
                    else:pending[pk]=seed;counts['監視開始']+=1
                births.append(birth)
        result[key]=births
    return result,dict(counts)


def prepare():
    """
    機能: 過去81場から18条件の純出生と観測被覆を金融前に固定する。
    引数: なし。
    返り値: None。200以降の結果で197以前を変更しない。
    """
    base=read(ROOT/'inputs/00197_TOPIXの一因子比較の純入口/純入口.json.gz')
    features={f:read(ROOT/'inputs/TOPIX原順8列_20260921_20261116'/n) for f,n in enumerate(('純特徴183.json.gz','純特徴184直接.json.gz'))}
    maps={f:{(r['session'],r['time'],r['line']):r for r in rows} for f,rows in features.items()};contexts={f:B.context_rows(rows) for f,rows in features.items()}
    births,diagnostics=transitions(base,maps,contexts);by=defaultdict(list)
    for key in births:by[key[0]].append(key)
    quality={}
    for entry in read(ROOT/'inputs/TOPIX原順8列_20260921_20261116/台帳.json')['entries']:
        path=ROOT/entry['path'];assert M.sha(path)==entry['sha256']
        with np.load(path,allow_pickle=False) as z:data={k:z[k] for k in ('now','line','valid')}
        quality.update(quality_for_scene(data,by[entry['session']]))
    result=[]
    for row in base:
        key=(row['session'],row['time'],row['line']);signals=[];widths=[];origins=[];lineage=[]
        for mother,q,mode in SPECS:
            if row['band']=='DAY':side=row['signals'][0];width=row['widths'][0];birth=None;origin='旧190D4固定'
            else:
                birth=births[key][mother*3+mode];pass_quality=q==0 or quality[key]['windows'][str(600 if q==1 else 1800)]['通過']
                side=birth['side'] if birth and pass_quality else 0;width=15.
                origin=MOTHERS[mother]+'_'+MODES[mode]+'_'+QUALITIES[q]
            signals.append(side);widths.append(width);origins.append(origin);lineage.append(birth)
        assert signals[0]==row['signals'][0]
        result.append({'session':key[0],'time':key[1],'line':key[2],'band':row['band'],'signals':signals,'widths':widths,'origins':origins,
            'births':lineage,'extra':row['extra'],'quality':quality[key]})
    M.save(HERE/'純入口.json.gz',result)
    sources=[Path(__file__),ROOT/'work/197TOPIX/入口197.py',ROOT/'work/192TOPIX/入口192.py',ROOT/'work/186TOPIX/入口186.py',M.HERE/'入口とIFD.py']
    cfg={'試行':200,'候補':list(NAMES),'規模':18,'対象':'当初81場、全既使用。194追加2場の結果受領後。追加場金融を本探索へ混ぜない。',
        '範囲':'Day旧190D4固定。Night母体2×観測品質3×入口時間順3=18。源即時と確認後を同じ固定IFD/H60で比較。',
        '品質':'q0原行までの正常BBO価格時計を使用。直前600/1800秒窓に、正常BBOを観測した時刻から30秒までの区間を重複なく被覆し、その秒数÷窓秒数>=90%。開始端直前30秒に正常観測、正常時計最大空白<=90秒、窓開始は場内を要求。場前は可用性不足として不成立、全場分母は維持。',
        '時計限界':'CurrentPriceTime上の正常BBO観測代理。真の受信時計や板更新時刻の鮮度ではない。同時計反復行数は診断だけ。将来返済/欠測で入口を選別しない。',
        '源':'旧190N01共通旧1分量、又は197N12旧優先和集合QF。旧費用方向を固定対照として保持。P0元側と実側を源時点で固定。',
        '時間順':'源から10分以内。実反転は源の前3本高低端、元順行は源EMA8を固定。源後のq0で前終値が水準反対側/当終値が実側へ交差し1分実体と進行が実側なら突破記録。次の同形成連続1分q0（30〜90秒）も終値実側・反対端の侵入<=0.1当時ATR、MACD又はRSI増分が実側正、量>=0.5なら1度発火。',
        '監視':'元/実方向・形成・固定端・600秒期限は不変。後発源を無視して期限延長しない。帯変更/期限超で失効、源当時は即確認しない。品質は発火q0だけへ適用、監視生成から独立。監視は金融pending予約ではない。',
        '金融':'Day旧A25/Night15/H60、単純IFD、保有予約合計1、開始待機なし、終了15分前。miniTOPIX1枚片道41.8円+0.25pt。',
        'Source':{p.relative_to(ROOT).as_posix():M.sha(p) for p in sources},'純入口SHA':M.sha(HERE/'純入口.json.gz'),
        '197純入力SHA':M.sha(ROOT/'inputs/00197_TOPIXの一因子比較の純入口/純入口.json.gz')}
    assert not (HERE/'条件.json').exists();M.save(HERE/'条件.json',cfg)
    M.save(HERE/'純成立診断.json',{'q0':len(result),'監視':diagnostics,'候補':{name:sum(r['signals'][i]!=0 for r in result if r['band']!='DAY') for i,name in enumerate(NAMES)}})
    print(json.dumps({'純q0':len(result),'候補':len(NAMES),'純入口SHA':cfg['純入口SHA'],'監視':diagnostics},ensure_ascii=False),flush=True)


if __name__=='__main__':prepare()
