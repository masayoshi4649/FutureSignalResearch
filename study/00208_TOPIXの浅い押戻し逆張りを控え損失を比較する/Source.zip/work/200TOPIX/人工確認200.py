"""価格時計被覆の因果性と不変seedの時間順確認を金融前に検査する。"""
from copy import deepcopy
import sys,json
import numpy as np
import 入口200 as E
from 人工確認197 import around_row


def main():
    """
    機能: 観測被覆・重複時計・未来不使用・構造確認の順序と一度性を確認する。
    引数: なし。
    返り値: None。実データの金融損益を参照しない。
    """
    checks=0;scene='2026-09-21_Night';start=E.M.bounds(scene)[0]
    now=start+np.arange(0,1831,30,dtype=float);data={'now':now,'line':np.arange(len(now))+1,'valid':np.ones(len(now),dtype=bool)}
    key=(scene,start+600,21);q=E.quality_for_scene(data,[key])[key]
    assert q['windows']['600']['通過'] and q['windows']['600']['被覆秒']==600;checks+=2
    assert not q['windows']['1800']['通過'] and not q['windows']['1800']['場内窓'];checks+=2
    prefix={k:v[:21] for k,v in data.items()};assert E.quality_for_scene(prefix,[key])[key]==q;checks+=1
    altered={k:v.copy() for k,v in data.items()};altered['valid'][21:]=False;altered['now'][21:]+=100000
    assert E.quality_for_scene(altered,[key])[key]==q;checks+=1
    doubled={'now':np.repeat(now,2),'line':np.arange(len(now)*2)+1,'valid':np.ones(len(now)*2,dtype=bool)}
    q2=E.quality_for_scene(doubled,[(scene,start+600,42)])[(scene,start+600,42)]
    for k in ('通過','被覆秒','被覆率','最大空白秒','正常異時刻数'):assert q['windows']['600'][k]==q2['windows']['600'][k];checks+=1
    gap={k:v.copy() for k,v in data.items()};gap['valid'][7:14]=False
    assert not E.quality_for_scene(gap,[key])[key]['windows']['600']['通過'];checks+=1
    # ----------------------------------------
    # 固定端の突破が先、保持と量・動力は次の連続q0で評価する。
    features={f:E.read(E.ROOT/'inputs/TOPIX原順8列_20260921_20261116'/n) for f,n in enumerate(('純特徴183.json.gz','純特徴184直接.json.gz'))}
    source=deepcopy(features[1][1000]);source.update(session=scene,time=start+3600,line=1,band='PRE',close=4000.,prior_high=4001.,prior_low=3999.,prior_close=4000.,high=4001.,low=3999.,atr=2.,rvol=1.)
    source['m5'].update(ema8=4001.,hist_delta=.1,rsi_delta=0.)
    cross=deepcopy(source);cross.update(time=source['time']+60,line=2,prior_close=4000.,close=4002.,high=4003.,low=4000.,body=1.,progress=1.)
    held=deepcopy(cross);held.update(time=source['time']+120,line=3,prior_close=4002.,close=4002.5,low=4001.)
    extra={'rvol5':1.}
    for reverse in (False,True):
        seed=E.make_seed(source,1,-1 if reverse else 1,0);immutable={k:v for k,v in seed.items() if k!='armed'}
        assert not E.advance(seed,source,extra);checks+=1
        assert not E.advance(seed,cross,extra) and seed['armed']==cross['time'];checks+=2
        assert E.advance(seed,held,extra);checks+=1
        assert {k:v for k,v in seed.items() if k!='armed'}==immutable;checks+=1
        mirrored_source=around_row(source,4000.);ms=E.make_seed(mirrored_source,-1,1 if reverse else -1,0)
        assert not E.advance(ms,around_row(cross,4000.),extra) and E.advance(ms,around_row(held,4000.),extra);checks+=2
        for alteration in ('量不明','価格再侵入','動力なし','確認間隔超過'):
            seed=E.make_seed(source,1,-1 if reverse else 1,0);E.advance(seed,cross,extra);bad=deepcopy(held)
            if alteration=='量不明':bad['rvol']=None
            elif alteration=='価格再侵入':bad['low']=4000.
            elif alteration=='動力なし':bad['m5'].update(hist_delta=0.,rsi_delta=0.)
            else:bad['time']+=120
            assert not E.advance(seed,bad,extra),alteration;checks+=1
    # ----------------------------------------
    # 実特徴は全体/接頭部で同体。後発seedで期限が延びず、同源は一度だけ発火。
    base=E.read(E.ROOT/'inputs/00197_TOPIXの一因子比較の純入口/純入口.json.gz')
    maps={f:{(r['session'],r['time'],r['line']):r for r in rows} for f,rows in features.items()};contexts={f:E.B.context_rows(rows) for f,rows in features.items()}
    full,counts=E.transitions(base,maps,contexts);prefix,_=E.transitions(base[:2000],maps,contexts)
    for key,births in prefix.items():assert births==full[key];checks+=1
    seen=set()
    for key,births in full.items():
        for i,birth in enumerate(births):
            if birth is None:continue
            marker=(key[0],i,birth['time'],birth['line']);assert marker not in seen;seen.add(marker);checks+=1
            assert birth['expiry']==birth['time']+600 and birth['time']<=key[1]<=birth['expiry'];checks+=2
            assert birth['reverse']==(birth['side']==-birth['native']);checks+=1
            if key[1]>birth['time']:assert key[1]-birth['time']>=60;checks+=1
    proof={'成功':True,'項目数':checks,'prefix同体':True,'重複時計が被覆率を変えない':True,'未来行改変同体':True,
        'seed水準方向期限不変':True,'同源一度発火':True,'場前窓を不可用にする':True,'監視':counts,'SourceSHA':E.M.sha(E.HERE/'入口200.py')}
    E.M.save(E.HERE/'人工確認.json',proof);print(json.dumps(proof,ensure_ascii=False),flush=True)


if __name__=='__main__':main()
