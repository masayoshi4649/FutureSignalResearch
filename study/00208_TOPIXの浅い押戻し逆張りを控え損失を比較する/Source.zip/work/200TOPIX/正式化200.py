"""200の観測品質・時間順確認・追加固定適用を分けて恒久保存する。"""
from pathlib import Path
import json,zipfile,shutil,re,os,hashlib,sys
import 入口200 as E
sys.path.insert(0,str(E.ROOT/'work/196TOPIX'))
from 正式化196 import row_text
TRIAL=E.ROOT/'study/00200_TOPIXの観測被覆と構造確認の順序を分ける'
INPUT=E.ROOT/'inputs/00200_TOPIXの観測被覆と時間順入口'


def ref(path):
    """
    機能: 保存資源の相対位置・サイズ・指紋を記録する。
    引数: path(Path)。
    返り値: dictはpath/bytes/sha256。
    """
    return {'path':path.relative_to(E.ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':E.M.sha(path)}


def main():
    """
    機能: 旧81と追加2/全83を区別し、全18条件と検査・原因を保存する。
    引数: なし。
    返り値: None。固定条件と元81の順位・台帳は変更しない。
    """
    TRIAL.mkdir(parents=True,exist_ok=True);INPUT.mkdir(parents=True,exist_ok=True);(TRIAL/'追加固定適用').mkdir(exist_ok=True)
    files=('条件.json','人工確認.json','金融開始前固定.json','純成立診断.json','旧対照同体.json','全18組安定性.json.gz','全18組短表.json.gz','独立確認.json','原因診断.json','取得位置と先着.json','全18組全83安定性.json.gz')
    for name in files:shutil.copy2(E.HERE/name,TRIAL/name)
    for name in ('条件固定.json','金融開始前固定.json','全18追加安定性.json.gz','独立確認.json'):shutil.copy2(E.HERE/'追加2'/name,TRIAL/'追加固定適用'/name)
    shutil.copy2(E.HERE/'純入口.json.gz',INPUT/'純入口.json.gz');shutil.copy2(E.HERE/'追加2/純入口.json.gz',INPUT/'追加二場純入口.json.gz')
    manifest={'試行':200,'旧81純出生':ref(INPUT/'純入口.json.gz'),'追加2純出生':ref(INPUT/'追加二場純入口.json.gz'),'条件':ref(TRIAL/'条件.json'),
        '原順8列':'inputs/TOPIX原順8列_20260921_20261116/台帳.json','追加入力':'inputs/00194_20261116夜と1117昼の固定適用入力/README.md','母体':'inputs/00197_TOPIXの一因子比較の純入口/入力台帳.json'}
    (INPUT/'入力台帳.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (INPUT/'README.md').write_text('# TOPIX 200の純入口\n\n[研究正本](../../study/00200_TOPIXの観測被覆と構造確認の順序を分ける/README.md)。当初81場34,424q0と追加2場937q0を別ファイルで保持。全18候補の条件は同じ。追加2場は194結果を参照済みで未見ではない。原板は共用入力を参照し複製しない。\n',encoding='utf-8')
    source_index=E.read(E.ROOT/'study/00197_TOPIXの量と観測機会と方向尺度を分離する/Source索引.json')
    sources=sorted(set([E.ROOT/r['path'] for r in source_index]+list(E.HERE.glob('*.py'))+[E.ROOT/'work/196TOPIX/原因196.py']))
    with zipfile.ZipFile(TRIAL/'Source.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for path in sources:archive.write(path,path.relative_to(E.ROOT).as_posix())
        for name in ('入力台帳.json','条件_実装修正1.json'):
            path=E.M.HERE/name;archive.write(path,path.relative_to(E.ROOT).as_posix())
    (TRIAL/'Source索引.json').write_text(json.dumps([ref(p) for p in sources],ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    fixed=E.read(E.HERE/'全18組安定性.json.gz')
    selection={'区分':'旧81金融正本に保存済みの全80/前48順位を追加適用後に索引化。新たな選択ではなく、追加前に全18固定適用を封印済み。',
        '全体採用':None,'理由':'時間順確認自身の損益・参加・両中央値・未知が共同適合しない。追加2の最高値への再選択なし。',
        '旧81固定順位':{k:v[:1] for k,v in fixed['順位'].items()},'追加適用':list(E.NAMES),'旧81金融SHA':E.M.sha(E.HERE/'全18組安定性.json.gz')}
    (TRIAL/'固定選択.json').write_text(json.dumps(selection,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    template=E.ROOT/'docs/議論/手法と時間スケールの汎用表_版8.md';body=template.read_text(encoding='utf-8').split('## 設定明細')[0]
    body=body.replace('# 手法と時間スケールの汎用表・版8','# 200 TOPIX・設定と結果（版8）').replace('全セルは未設定・未検証。','使用セルに設定IDを記す。').replace('未設定・未検証','未使用')
    used={'I01':{3:'S1 P0持続/源EMA8固定',4:'S1中期背景',5:'S1旧D4背景'},'I02':{3:'S2確認水準とATR侵入幅'},'I03':{3:'S1水準/S2増分'},'I04':{3:'S1範囲/S2増分'},
        'I08':{3:'S1 DI/ADX',4:'S1 DI',5:'S1旧D4'},'I09':{3:'S2許容侵入0.1ATR/Day幅'},'C01':{3:'S1持続',4:'S1'},'C07':{1:'S2源→突破→保持',3:'S1/S2',4:'S1',5:'S1旧D4'},
        'P01':{1:'S2実体・足端'},'P05':{1:'S2実側進行'},'P06':{1:'S2源時の前3本端固定'},'P07':{1:'S2次連続q0保持'},
        'V01':{0:'S3累積量時計',1:'S3旧量',3:'S3不明時5分量'},'B01':{0:'S4観測時間被覆10/30分'},'E01':{0:'R1固定単純IFD'},'E02':{0:'R1固定SLと終了'}}
    count=0;lines=[]
    for line in body.splitlines():
        cells=[c.strip() for c in line.strip().strip('|').split('|')] if line.startswith('|') else []
        if len(cells)==11 and re.fullmatch(r'[A-Z][0-9]{2}',cells[0]):
            count+=1
            for i in range(9):cells[i+2]=used.get(cells[0],{}).get(i,'未使用')
            line='| '+' | '.join(cells)+' |'
        lines.append(line)
    assert count==63
    body='\n'.join(lines)+'\n';body=re.sub(r'\]\(([^)]+)\)',lambda m:']('+os.path.relpath((template.parent/m.group(1)).resolve(),TRIAL).replace('\\','/')+')',body)
    body+='''
## 設定明細と複合評価

S1は197の旧共通1分量/旧優先和集合QFの2母体、Dayは190D4固定。P0の5分持続EMA・DI、15分DI、RSI/MACDと1分押戻しを保持。旧費用方向は固定対照で変更しない。

S2は源を即時取得/実反転側だけ確認/両側確認。源時に元側・実側・前3本端又はEMA8・形成・10分期限を固定。源後に固定水準を実側へ交差して1分実体/進行が正なら突破、次の連続1分q0（30〜90秒）が終値実側・反対端の侵入0.1ATR以内・MACD又はRSI増分実側正・量>=0.5なら一度発火。後発源で期限を延ばさない。監視は金融予約ではない。

S3は源と同じ1分量又は不明時5分量方式。S4はq0原行まで、正常BBOの価格時計から30秒までの区間和集合÷直前10/30分実秒数>=90%、開始端30秒内、最大空白90秒以下、窓が場内。重複原行を分母にしない。受信時計や真の板鮮度ではない。品質は発火q0に適用し、監視出生とは独立。

R1はDayA25/Night15pt/H60、保有予約合計1、終了15分前。miniTOPIX片道41.8円+0.25pt。全18口座に新規採用なし。[条件](条件.json)・[旧81結果](全18組安定性.json.gz)・[全83結果](全18組全83安定性.json.gz)・[原因](原因診断.json)。口座改善を反転確認枝の優位と呼ばない。未使用は無効判定ではない。

## 再現と版

[Source](Source.zip)・[索引](Source索引.json)・[純入口](../../inputs/00200_TOPIXの観測被覆と時間順入口/入力台帳.json)。版8は63手法×9尺度=567セル。旧81と追加2を分け、両方既使用と記録する。
'''
    body+='\n汎用表SHA256: '+hashlib.sha256(template.read_bytes()).hexdigest()+'\n';(TRIAL/'設定と結果.md').write_text(body,encoding='utf-8')
    states=fixed['metrics'];all83=E.read(E.HERE/'全18組全83安定性.json.gz')
    header='| index | 取得 / 参加場 | 保有下限 | 未知 | 利益円 | 損失円 | 既知収支円 | 建玉 / 場中央値下限円 | 場末DD円 |\n| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |\n'
    report='''# 200 TOPIXの観測被覆と構造確認の順序を分ける

2026-11-18作成。**新案は採用しない。口座の損失減と、確認した反転入口そのものの優位は別だった。** 構造確認により枠が空き、元順行の取得が増えた効果が大きい。反転確認自体は費用後赤字で、両中央値・参加・未知を満たす入口の発見には至っていない。追加2場も条件を変えず全18案へ適用し、全83経路を診断した。次の202へ継続する。

## 仮説・条件・入力

[197](../00197_TOPIXの量と観測機会と方向尺度を分離する/README.md)では、量補完とq0追加による未知と損失を分離できた。200は過去の観測品質と、実側の構造変化が時間順に成立するかを分ける。Night母体2×品質3×時間順3=18、Dayは旧190D4固定。[条件](条件.json)・[設定と結果](設定と結果.md)。

同じLast価格時計を繰り返す行数は被覆の分母にしない。正常BBOを価格時計上で確認した後30秒までの区間を重複なく合算し、直前10/30分の90%以上を観測していたかを使う。最大空白90秒、開始端30秒内、場内窓を要求する。受信時計や真のBid/Ask更新時計がないため、取引可能性の代理に留まる。将来の欠測・決済可否を入口へ混ぜない。

時間順確認では源q0時点の前3本端（実反転）/EMA8（元順行）と10分期限を固定する。後続の突破、その次の連続1分q0の保持、MACD又はRSI増分、量を確認する。後から源や期限を更新しない。監視は注文pendingではなく、取得後の保有枠は従来どおり1。

原板・特徴は当初81場（2026-09-21Day〜11-16Day）と194の追加11/16Night・11/17Day。旧81も追加2も既使用。200は194結果受領後に設計され、追加2への適用は未見再現ではない。純条件・Source・出生を旧81金融前に固定し、その後追加全18を別封印して適用、最高候補への再選択なし。

単純IFD・DayA25/Night±15pt・H60、保有予約合計1、開始待機なし、15:30/05:45までに全決済。miniTOPIX1枚・1pt=1,000円、片道41.8円+0.25pt滑り。ラージBBO代用、遅延1秒/取得TTL30秒。未知は0円とせず場末まで枠保持、0取得場も分母に含む。

## 当初81場のNight結果

index0〜8=共通旧1分量、9〜17=旧優先和集合QF。各9内は品質なし/10分/30分の順、各3内は即時/実反転だけ確認/両側確認の順。母数40Night。Dayは全案207取得/41場・保有54.90%・未知0・利益841,471.2/損失798,776.4/収支+42,694.8円で旧190D4同体。

'''+header+'\n'.join(row_text(i,'NIGHT',states) for i in range(18))+'''

和集合の実反転だけ確認（index10）は即時index9から217→121取得、未知21→9、DD85,432.4→40,754円となり、前48+69,900.4/後25+29,239.6/追加7+18,996.8円。ただ36/40場、建玉/場中央値下限−583.6/−833.6円である。30分品質も重ねたindex16は未知8だが保有19.27%・両中央値−83.6/0。良い期間合計だけでは採用しない。

## 反転確認自身と口座改善を分ける

[原因](原因診断.json)と[取得位置・先着](取得位置と先着.json)では、index10の実反転確認69件は利益190,242.8/損失204,342.4/既知収支−14,099.6円・未知8。元順行の即時52件は+132,236.4円・未知1。口座益+118,136.8円の主因を反転入口の優位へ置き換えない。

実反転確認は±15ptで8F/6A/48N/7C、到達済み57.14%は14件だけ。元順行は17F/6A/28N/1C、73.91%は23件。未知返済でも先着が先に確定したF/Aは保持するため、C件数と金融未知件数は一致しない。

反転確認の既知61件は費用前+21,500円→費用後−14,099.6円。うち期限48件は費用前−25,000円→費用後−53,012.8円。確認時の15pt幅はATR中央値4.15倍、元順行は2.78倍。確認時の15分DIと傾きが実側を同時支持した反転取得は0件だった。短い価格端の突破だけで中期反転まで確認できたとは言えない。

源から確認までの進行中央値0.56ATR。源から0〜0.5ATRの事後群27件は+20,160.8円だがF2/A0/N20/C5と小支持で、100%を採用理由にしない。固定端から0.5ATR超の18件は−12,337.6円。次は確認位置の0.5/1ATR近傍と、突破に失敗して元側へ戻る順序を検証する。固定15ptが低ATR側に大きい可能性は幅別の旧入口対照を揃えて調べる。

## 追加2場の固定適用と全83

[追加封印](追加固定適用/条件固定.json)は全18を指定し、[追加結果](追加固定適用/全18追加安定性.json.gz)と[全83](全18組全83安定性.json.gz)を旧81正本から分離した。追加Dayは全案7取得、利益36,749.2/損失31,834.4/収支+4,914.8円。Night即時は共通旧4取得+14,165.6円、和集合5取得+10,082円。

時間順確認の12案は追加Nightで全て最初の1取得が未知となり、以降は枠を場末保持。21:43:11要求→21:43:28買3908.5、H60期限の返済時計不足（最終確認22:43:25）。既知収支0という表記を無損失・同値撤退と読まない。過去被覆が良くても将来の返済時計は保証できず、期限延長や未来欠測の入口除外で既知化しない。

全83（Night41場）の主な固定対照は次の通り。Dayは同体の42場214取得・未知0・利益878,220.4/損失830,610.8/収支+47,609.6円。

'''+header+'\n'.join(row_text(i,'NIGHT',all83) for i in (0,3,6,9,10,13,16))+'''

旧81の全群・台帳・条件・純出生SHAは不変。追加2の良い即時案へ主条件を置換していない。[固定選択索引](固定選択.json)は旧金融に保存済みの順位をそのまま参照し、全体採用null。

## 検査と再現

人工19,726項目。旧81の[独立確認](独立確認.json)は5,941取得・金融77,233属性・別集計57,996属性・全q0枠55,596件・被覆275,392属性を照合、不一致0。被覆の別算術は原順を一度線形走査して索引化し、各q0以前の区間を独立に合併する。金融や閾値は変更していない。

[追加独立確認](追加固定適用/独立確認.json)は165取得・金融2,145属性・追加/全83集計68,850属性・追加被覆7,496属性を照合。不一致0。旧対照の取得枠・価格は同体。

[Source](Source.zip)・[索引](Source索引.json)・[恒久純入口](../../inputs/00200_TOPIXの観測被覆と時間順入口/README.md)。Python3.14.3/NumPy2.5.4/tzdata2026.6。[共通再現ツール](../../scripts/TOPIX入口研究/README.md)で`固定純入口を再生.py 200`を実行すると、原板を複製せず新しい作業領域で旧81金融を再生し正本SHAを比較する。`--監査`で別算術も実行する。

追加2はSourceと恒久194入力を復元し、200の旧81条件・純出生・金融正本を再生した後、`追加適用200.py 純固定`→`追加適用200.py 金融`。追加封印を上書きしない新しい作業領域で行う。純出生自体は197の固定母体と当時特徴から`人工確認200.py`→`入口200.py`。正式閲覧はworkに依存しない。
'''
    (TRIAL/'README.md').write_text(report,encoding='utf-8')
    print(json.dumps({'正式化':str(TRIAL),'表セル':567,'Source数':len(sources),'追加区分':True},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
