"""品質と時間順確認の効果を、元側/実反転側・三帯・未知理由へ分ける。"""
from collections import defaultdict,Counter
import json,sys
import 入口200 as E
sys.path.insert(0,str(E.ROOT/'work/196TOPIX'))
from 原因196 import summarize


def main():
    """
    機能: 固定200の金融を不変seedと照合し、実際の取得群だけを診断する。
    引数: なし。
    返り値: None。原因診断を新条件の成績に混ぜない。
    """
    states=E.read(E.HERE/'全18組安定性.json.gz')['metrics'];pure=E.read(E.HERE/'純入口.json.gz');index={(r['session'],r['time'],r['line']):r for r in pure};result=[]
    for ci,state in enumerate(states):
        ledger=E.read(E.HERE/'金融正本'/(state['id']+'.json.gz'))['ledger'];groups=defaultdict(list);delays=[]
        for i,scene in enumerate(ledger['scene']):
            if 'Night' not in scene:continue
            key=(scene,ledger['request_time'][i],ledger['request_line'][i]);row=index[key];birth=row['births'][ci];assert birth is not None
            side='実反転' if birth['reverse'] else '元順行';clock='確認後' if birth['confirmed']>birth['time'] else '即時';band=row['band']
            for k in ('全体',side,clock,band,band+'/'+side+'/'+clock):groups[k].append(i)
            if clock=='確認後':delays.append(birth['confirmed']-birth['time'])
        result.append({'index':ci,'id':state['id'],'取得群':{k:summarize(ledger,v) for k,v in groups.items()},'確認秒':{'件数':len(delays),'平均':sum(delays)/len(delays) if delays else None,'最大':max(delays) if delays else None}})
    # ----------------------------------------
    # 棄却される純発火の時点での被覆原因。未来の欠測は使わない。
    blocked={}
    for mother in (0,1):
        for mode in range(3):
            base=mother*9+mode
            for quality in (1,2):
                candidate=mother*9+quality*3+mode;reasons=Counter()
                for row in pure:
                    if row['band']=='DAY' or not row['signals'][base] or row['signals'][candidate]:continue
                    q=row['quality']['windows'][str(600 if quality==1 else 1800)]
                    if not q['場内窓']:reasons['場前窓']+=1
                    if not q['開始端確認']:reasons['開始端30秒不明']+=1
                    if q['最大空白秒']>90:reasons['最大空白90秒超']+=1
                    if q['被覆率']<.9:reasons['被覆90%未満']+=1
                blocked[str(candidate)]=dict(reasons)
    E.M.save(E.HERE/'原因診断.json',{'区分':'固定200の事後原因分解。取得群・枠の異なる損益を単一因子の効果と同一視しない。','候補':result,'純発火品質棄却':blocked,'SourceSHA':E.M.sha(E.HERE/'原因200.py')})
    for row in result:
        if row['index'] in (0,1,9,10,16):print(json.dumps(row,ensure_ascii=False),flush=True)


if __name__=='__main__':main()
