"""固定200全18案を追加2場へ再選択せず適用し、全83経路も別区分で集計する。"""
from pathlib import Path
from collections import defaultdict
from copy import deepcopy
import argparse,json,math,sys
import numpy as np
import 入口200 as E
M=E.M
import 金融を比較する as F
sys.path.insert(0,str(E.ROOT/'work/183損失安定性'))
import TOPIXを独立検算する as T
from 独立確認200 import normal_observations,quality_oracle
DEST=E.HERE/'追加2';INPUT=E.ROOT/'inputs/00194_20261116夜と1117昼の固定適用入力'


def entries():
    """
    機能: 194で同体接続済みの追加TOPIX2場だけを参照する。
    引数: なし。
    返り値: list[dict]。既使用の追加2場であり未見と呼ばない。
    """
    result=[r for r in E.read(INPUT/'原順8列/入力台帳.json')['entries'] if r['symbol']=='TOPIX']
    assert [r['session'] for r in result]==['2026-11-16_Night','2026-11-17_Day']
    for row in result:
        row['cache_absolute']=str(INPUT/'原順8列/TOPIX'/(row['session']+'.npz'))
        assert M.sha(Path(row['cache_absolute']))==row['sha256_cache']
    return result


def prepare():
    """
    機能: 200条件を変更せず194純特徴へ適用し、金融前に追加出生を封印する。
    引数: なし。
    返り値: None。元81場の条件・出生・選択を上書きしない。
    """
    cfg=E.read(E.HERE/'条件.json');assert all(M.sha(E.ROOT/p)==sha for p,sha in cfg['Source'].items())
    features={f:E.read(INPUT/'TOPIX'/n) for f,n in enumerate(('純特徴183.json.gz','純特徴184直接.json.gz'))}
    maps={f:{(r['session'],r['time'],r['line']):r for r in rows} for f,rows in features.items()};contexts={f:E.B.context_rows(rows) for f,rows in features.items()}
    base=[]
    for row in E.read(INPUT/'TOPIX/純入口192追加二場.json.gz'):
        key=(row['session'],row['time'],row['line']);base.append(E.B.decide(key,maps,contexts,row['extra'],row))
    births,diagnostics=E.transitions(base,maps,contexts);quality={}
    for entry in entries():
        with np.load(entry['cache_absolute'],allow_pickle=False) as z:raw={k:z[k] for k in ('now','line','valid')}
        quality.update(E.quality_for_scene(raw,[key for key in births if key[0]==entry['session']]))
    result=[]
    for row in base:
        key=(row['session'],row['time'],row['line']);signals=[];widths=[];origins=[];lineage=[]
        for mother,q,mode in E.SPECS:
            if row['band']=='DAY':side=row['signals'][0];width=row['widths'][0];birth=None;origin='旧190D4固定'
            else:
                birth=births[key][mother*3+mode];passed=q==0 or quality[key]['windows'][str(600 if q==1 else 1800)]['通過']
                side=birth['side'] if birth and passed else 0;width=15.;origin=E.MOTHERS[mother]+'_'+E.MODES[mode]+'_'+E.QUALITIES[q]
            signals.append(side);widths.append(width);origins.append(origin);lineage.append(birth)
        assert signals[0]==row['signals'][0]
        result.append({'session':key[0],'time':key[1],'line':key[2],'band':row['band'],'signals':signals,'widths':widths,'origins':origins,'births':lineage,'extra':row['extra'],'quality':quality[key]})
    M.save(DEST/'純入口.json.gz',result)
    sources=[Path(__file__),E.HERE/'入口200.py',E.HERE/'独立確認200.py',E.ROOT/'work/197TOPIX/入口197.py',E.ROOT/'work/192TOPIX/入口192.py',E.ROOT/'work/186TOPIX/入口186.py',Path(F.__file__),Path(T.__file__),Path(F.A.__file__),M.HERE/'入口とIFD.py']
    seal={'区分':'194結果受領後に設計済みの200を全18案固定適用。既使用追加2場。条件と順位の再探索なし。',
        '200条件SHA':M.sha(E.HERE/'条件.json'),'200旧81純入口SHA':M.sha(E.HERE/'純入口.json.gz'),'旧81金融SHA':M.sha(E.HERE/'全18組安定性.json.gz'),
        '追加純入口SHA':M.sha(DEST/'純入口.json.gz'),'Source':{p.relative_to(E.ROOT).as_posix():M.sha(p) for p in sources},
        '入力':{str(p.relative_to(E.ROOT)):M.sha(p) for p in [INPUT/'TOPIX/純特徴183.json.gz',INPUT/'TOPIX/純特徴184直接.json.gz',INPUT/'TOPIX/純入口192追加二場.json.gz',INPUT/'原順8列/入力台帳.json']},
        '場':[r['session'] for r in entries()],'候補':list(E.NAMES),'監視':diagnostics}
    assert not (DEST/'条件固定.json').exists();M.save(DEST/'条件固定.json',seal)
    print(json.dumps({'追加純q0':len(result),'候補':18,'純入口SHA':seal['追加純入口SHA']},ensure_ascii=False),flush=True)


def finance():
    """
    機能: 追加2場を固定IFDで再生し、追加だけ/旧81/全83を区別して独立照合する。
    引数: なし。
    返り値: None。金融後の最良候補への置換や元81集計の変更は行わない。
    """
    seal=E.read(DEST/'条件固定.json');assert all(M.sha(E.ROOT/p)==sha for p,sha in seal['Source'].items())
    assert all(M.sha(E.ROOT/p)==sha for p,sha in seal['入力'].items())
    assert M.sha(DEST/'純入口.json.gz')==seal['追加純入口SHA'];assert not (DEST/'金融開始前固定.json').exists()
    M.save(DEST/'金融開始前固定.json',{'追加条件SHA':M.sha(DEST/'条件固定.json'),'SourceSHA':M.sha(Path(__file__))})
    rows=entries();meta=F.sessions(rows);pure=E.read(DEST/'純入口.json.gz');by=defaultdict(list)
    for r in pure:by[r['session']].append(r)
    packs=[]
    for name in E.NAMES:
        pack=F.empty('TOPIX200_'+name+'_DayA25_NightW15_H60',meta);pack['ledger']['origin']=[];packs.append(pack)
    for entry in rows:
        route=M.Route(entry);cache={}
        for ci,pack in enumerate(packs):
            busy=-math.inf;pending=False;counts={'純成立':0,'保有棄却':0,'予約棄却':0,'取得':0,'失効':0}
            for r in by[entry['session']]:
                side=r['signals'][ci]
                if not side:continue
                counts['純成立']+=1
                if r['time']<=busy:counts['予約棄却' if pending else '保有棄却']+=1;continue
                key=(r['time'],r['line'],side,r['widths'][ci])
                if key not in cache:cache[key]=route.cell(*key)
                cell=cache[key]
                if cell is None:counts['失効']+=1;busy=min(r['time']+30,route.force);pending=True;continue
                F.append(pack,dict(cell,origin=r['origins'][ci]));counts['取得']+=1;busy=route.end if cell['unknown'] else cell['exit_time'];pending=False
            pack['diagnostics'].append({'scene':entry['session'],**counts})
    old_states=E.read(E.HERE/'全18組安定性.json.gz')['metrics'];newstats=[];allstats=[];fullpacks=[]
    for ci,pack in enumerate(packs):
        stat=F.A.evaluate_pack(pack,{'追加2':[r['scene'] for r in meta]});newstats.append(stat)
        old=E.read(E.HERE/'金融正本'/(old_states[ci]['id']+'.json.gz'));full=deepcopy(old)
        assert list(full['ledger'])==list(pack['ledger'])
        for k in full['ledger']:full['ledger'][k].extend(pack['ledger'][k])
        for k in ('sessions','positions','diagnostics'):full[k].extend(pack[k])
        scenes=[r['scene'] for r in full['sessions']];assert len(scenes)==83
        periods={'旧全81':scenes[:81],'前48':scenes[:48],'後25':scenes[48:73],'追加7':scenes[73:80],'旧最終1':scenes[80:81],'新2':scenes[81:]}
        allstat=F.A.evaluate_pack(full,periods);allstats.append(allstat);fullpacks.append(full)
        assert allstat['periods']['旧全81']==old_states[ci]['groups']
        M.save(DEST/'金融正本'/(pack['id']+'.json.gz'),pack);M.save(E.HERE/'全83金融正本'/(full['id']+'.json.gz'),full)
    # ----------------------------------------
    # 全追加q0の保有枠を独立BBO線形走査で検査し、全83集計も別算術で照合する。
    attrs=slots=groups=coverage=0
    for entry in rows:
        scene=entry['session'];start,end,force=T.bounds(scene)
        with np.load(entry['cache_absolute'],allow_pickle=False) as z:raw={k:z[k] for k in ('now','line','bid','ask','valid')}
        raw['別算術正常観測']=normal_observations(raw)
        for r in by[scene]:
            for duration in (600,1800):
                expected=quality_oracle(raw,(scene,r['time'],r['line']),duration)
                for key,val in expected.items():coverage+=T.V.check_equal(r['quality']['windows'][str(duration)][key],val,(scene,r['line'],duration,key))
        raw.pop('別算術正常観測');t=raw['now'];finite=np.isfinite(t);mask=finite&(t>=start)&(t<end)&(t>=np.maximum.accumulate(np.where(finite,t,-np.inf)))&raw['valid'];arrays={k:v[mask] for k,v in raw.items() if k!='valid'};cache={}
        for ci,pack in enumerate(packs):
            ledger=pack['ledger'];indices=[i for i,s in enumerate(ledger['scene']) if s==scene];cursor=0;busy=-math.inf
            for r in by[scene]:
                side=r['signals'][ci]
                if not side:continue
                slots+=1
                if r['time']<=busy:continue
                key=(r['time'],side,r['widths'][ci])
                if key not in cache:
                    first=int(np.searchsorted(arrays['now'],r['time']+1));ok=first<len(arrays['now']) and arrays['now'][first]<=min(r['time']+30,force) and arrays['now'][first]<force
                    cache[key]=T.financial_oracle(arrays,scene,*key) if ok else None
                cell=cache[key]
                if cell is None:busy=min(r['time']+30,force);continue
                assert cursor<len(indices);i=indices[cursor];cursor+=1
                for field,val in cell.items():attrs+=T.V.check_equal(pack['positions'][i][field] if field=='confirmed_until' else ledger[field][i],val,(ci,scene,i,field))
                assert ledger['request_time'][i]==r['time'] and ledger['request_line'][i]==r['line'];busy=ledger['exit_time'][i] if ledger['known'][i] else end
            assert cursor==len(indices)
    for p,s in zip(packs,newstats):groups+=T.inspect_groups(p,s)
    for p,s in zip(fullpacks,allstats):groups+=T.inspect_groups(p,s)
    M.save(DEST/'全18追加安定性.json.gz',newstats);M.save(E.HERE/'全18組全83安定性.json.gz',allstats)
    assert M.sha(E.HERE/'全18組安定性.json.gz')==seal['旧81金融SHA'] and M.sha(E.HERE/'純入口.json.gz')==seal['200旧81純入口SHA']
    report={'成功':True,'候補':18,'追加取得':sum(len(p['ledger']['net']) for p in packs),'追加金融属性':attrs,'追加全q0枠':slots,'追加と全83集計':groups,'追加全q0被覆':coverage,'旧81全群同体':True,'旧81金融SHA不変':True,'再選択':False,'既使用追加2':True}
    M.save(DEST/'独立確認.json',report);print(json.dumps(report,ensure_ascii=False),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('段階',choices=('純固定','金融'));args=parser.parse_args()
    if args.段階=='純固定':prepare()
    else:finance()
