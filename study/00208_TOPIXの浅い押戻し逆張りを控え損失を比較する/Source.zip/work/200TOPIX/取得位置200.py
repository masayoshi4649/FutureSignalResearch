"""200の取得位置と±15pt先着を、実反転確認枝と元順行枝で分ける。"""
from collections import defaultdict,Counter
from statistics import median
import json,sys
import 入口200 as E
sys.path.insert(0,str(E.ROOT/'work/196TOPIX'))
from 原因196 import summarize


def describe(ledger,indices,positions):
    """
    機能: 実取得群の±15pt先着と、源/固定端に対する確認位置を集計する。
    引数: ledger(dict),indices(list[int]),positions(dict[int,dict])。
    返り値: dict。未取得機会利益や、決済後の仮想延伸は評価しない。
    """
    value=summarize(ledger,indices);counts=Counter(ledger['label'][i] for i in indices)
    value['同幅先着']=dict(counts);den=counts['F']+counts['A'];value['到達済み順行率']=counts['F']/den if den else None
    value['源から確認進行ATR中央値']=median(positions[i]['source_progress'] for i in indices) if indices else None
    value['固定端から確認位置ATR中央値']=median(positions[i]['level_distance'] for i in indices) if indices else None
    value['幅ATR中央値']=median(positions[i]['width_atr'] for i in indices) if indices else None
    value['費用前円']=sum(ledger['gross_pt'][i]*1000 for i in indices if ledger['known'][i])
    return value


def main():
    """
    機能: 当初81場の固定取得に、当時の確認価格・中長期背景を対応付ける。
    引数: なし。
    返り値: None。事後の分解群を金融前の条件選択と呼ばない。
    """
    features={f:E.read(E.ROOT/'inputs/TOPIX原順8列_20260921_20261116'/n) for f,n in enumerate(('純特徴183.json.gz','純特徴184直接.json.gz'))}
    maps={f:{(r['session'],r['time'],r['line']):r for r in rows} for f,rows in features.items()}
    pure={(r['session'],r['time'],r['line']):r for r in E.read(E.HERE/'純入口.json.gz')};states=E.read(E.HERE/'全18組安定性.json.gz')['metrics'];results=[]
    for ci in (0,1,9,10,16):
        ledger=E.read(E.HERE/'金融正本'/(states[ci]['id']+'.json.gz'))['ledger'];groups=defaultdict(list);positions={}
        for i,scene in enumerate(ledger['scene']):
            if 'Night' not in scene:continue
            key=(scene,ledger['request_time'][i],ledger['request_line'][i]);birth=pure[key]['births'][ci]
            row=maps[birth['form']][key];source=maps[birth['form']][(scene,birth['time'],birth['line'])];side=birth['side']
            progress=side*(row['close']-source['close'])/source['atr'];distance=side*(row['close']-birth['level'])/row['atr'];positions[i]={'source_progress':progress,'level_distance':distance,'width_atr':15/row['atr']}
            family='実反転確認' if birth['reverse'] and birth['confirmed']>birth['time'] else '実反転即時' if birth['reverse'] else '元順行即時'
            for name in ('全体',family,family+'/'+ledger['reason'][i]):groups[name].append(i)
            if family=='実反転確認':
                bucket='0以下' if progress<=0 else '0から0.5' if progress<=.5 else '0.5から1' if progress<=1 else '1から2' if progress<=2 else '2超'
                groups['源進行ATR/'+bucket].append(i)
                groups['固定端距離/'+('0.5以下' if distance<=.5 else '0.5超')].append(i)
                for name in ('m5','m15','m30'):
                    m=row[name];label='不明' if m is None else '実側支持' if side*m['di']>0 and side*(m['slope'] or 0)>0 else '混在又は反対'
                    groups[name+'/'+label].append(i)
        results.append({'index':ci,'id':states[ci]['id'],'群':{name:describe(ledger,rows,positions) for name,rows in groups.items()}})
    E.M.save(E.HERE/'取得位置と先着.json',{'区分':'当初81の事後診断。±15pt/H60の最初F/Aを保持。未到達Nと観測不足Cを落とさず、決済勝率と先着率を区別。',
        '仮説診断':'源から進行0/0.5/1/2ATR、固定端0.5ATR、中長期DIと傾きで事後分解。未来の良い取得を選び直さない。','結果':results,'SourceSHA':E.M.sha(E.HERE/'取得位置200.py')})
    print(json.dumps(results[3],ensure_ascii=False),flush=True)


if __name__=='__main__':main()
