"""208の候補別15CSVを再読照合し、見方と恒久の再現資料を保存する。"""
from pathlib import Path
import csv,io,json,math,hashlib,shutil,zipfile
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
TRIAL=ROOT/'study/00208_TOPIXの浅い押戻し逆張りを控え損失を比較する';OUT=ROOT/'outputs/00208_TOPIXの浅押戻し見送り比較'


def main():
    """
    機能: 全セルと損益累計・未知空欄を検算し、候補を混在させず閲覧案内を作る。
    引数: なし。
    返り値: None。金融や固定主案・前半選択は変更しない。
    """
    data=json.loads((HERE/'閲覧入力.json').read_text('utf-8'));proof=json.loads((ROOT/'work/208CSV検査/作成確認.json').read_text('utf-8'));cells=nulls=0
    for item in proof['files']:
        raw=(OUT/item['相対path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==item['sha256'];rows=list(csv.reader(io.StringIO(raw.decode('utf-8-sig'))));table=data['tables'][item['元表']];expected=[table['headers']]+[r for r in table['rows'] if r[0]==item['候補']];assert len(rows)==len(expected)
        for actual,source in zip(rows,expected,strict=True):
            assert len(actual)==len(source)
            for a,b in zip(actual,source,strict=True):
                cells+=1
                if b is None:assert a=='';nulls+=1
                elif isinstance(b,(int,float)):assert math.isclose(float(a),b,abs_tol=1e-7)
                else:assert a==b
        for row in rows[1:]:assert math.isclose(float(row[3])-float(row[4]),float(row[10]),abs_tol=1e-7)
        if item['元表']!='候補比較':
            total=0.;complete=True
            for row in rows[1:]:
                total+=float(row[10]);complete=complete and int(row[8])==0;assert math.isclose(float(row[11]),total,abs_tol=1e-7)
                if complete:assert math.isclose(float(row[6]),total,abs_tol=1e-7)
                else:assert row[6]==''
    assert len(proof['files'])==15 and cells==6300 and nulls>0
    proof.update(CSV全セル再読=cells,未知空欄セル数=nulls,累計算術検査=True,全Day42とNight41を保持=True,全15表の描画を目視確認=True)
    support=TRIAL/'閲覧資料';support.mkdir(exist_ok=True);(support/'CSV確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n','utf-8');shutil.copy2(HERE/'閲覧入力.json',support/'閲覧入力.json')
    sources=[HERE/'入力を作る.py',Path(__file__),ROOT/'scripts/損益CSV/候補別に出力する.mjs']
    with zipfile.ZipFile(support/'閲覧Source.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for p in sources:archive.write(p,p.relative_to(ROOT).as_posix())
    (support/'Source索引.json').write_text(json.dumps([{'path':p.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sources],ensure_ascii=False,indent=2)+'\n','utf-8')
    descriptions={'00_旧基準':'旧190D4/N01。今回の見送りや新方向への切替を加える前の固定対照。','03_浅押戻し見送り':'全80/旧81から固定したNight有望主3。長中期の元方向支持があり過熱していない浅い押戻しで、旧入口が逆張りしようとする要求を見送る。','06_前48源側切替':'前48の既定順位首位6。同じ浅押戻しで見送らず、元方向へ切り替える固定比較。全期主3へ事後に交換しない。'}
    for title,description in descriptions.items():
        folder=OUT/('208_'+title)
        body=f'''# 208:{title}

{description}

2026-09-21〜11-17のデイ42・ナイト41、全83セッション。miniTOPIX1枚、ラージBBO代用。1pt=1,000円、片道41.8円+0.25pt、往復583.6円。DayA25/NightW15/H60の単純IFD、保有予約合計1、開始待機なし、終了15分前。

[集計](集計.csv) / [デイ](デイ.csv) / [ナイト全体](ナイト全体.csv) / [ナイト米国前](ナイト_米前.csv) / [ナイト米国後](ナイト_米後.csv)。

利益・損失は費用後の既知取引を分けた金額。未知を含む場の確定収支と、それ以後の確定累計は空欄。既知寄与を未知が解決した利益とはしない。未知7件はNight。無取引の場・帯も行を残す。累計は各候補・各帯ごとに0から始める。

保有時間率は対象実時間に占める確認済み保有の下限（0〜1）。末尾15分を分母から除き、予約と未確認保有で水増ししない。損益は新規取得帯、保有は実際の区間重複へ帰属するので、新規0回でも保有率が正の帯がある。ナイト全体と米国前後は同じ取引の別集計であり、足し合わせて重複計上しない。

[比較と限界](../README.md) / [研究正本](../../../study/00208_TOPIXの浅い押戻し逆張りを控え損失を比較する/README.md)。
''';(folder/'README.md').write_text(body,'utf-8')
    body='''# TOPIXの浅押戻し見送り比較・全83場

まず [03_浅押戻し見送り](208_03_浅押戻し見送り/README.md) と [00_旧基準](208_00_旧基準/README.md) のナイト全体を比較する。[06_前48源側切替](208_06_前48源側切替/README.md) は前半だけで選ぶと何が起きたかを残す対照。

## ナイト41セッション

miniTOPIX1枚・費用後・円。全3案とも38/41場で取得し、金融未知7、建玉と場の両中央値下限は正。全83は探索に既使用。

|候補|利益既知寄与|損失既知寄与|収支既知寄与|赤字取引 / 取得|赤字場|保有率下限|場末DD既知寄与|
|---|---:|---:|---:|---:|---:|---:|---:|
'''
    for row in data['Night比較']:
        title=row['候補'].split(':')[1];body+=f"|[{title}](208_{title}/README.md)|{row['known_profit']:,.1f}|{row['known_loss']:,.1f}|{row['known_net']:,.1f}|{row['赤字取引']} / {row['all_count']}|{row['赤字場']}|{row['保有率']:.2%}|{row['DD']:,.1f}|\n"
    body+='''
03は旧より損失額とDD、後25の赤字を縮めたNightの部分的な有望案。赤字場・連敗・初期損失は変わらず、赤字取引率も改善していない。条件が基準の実取得に作用したのは5件だけで、後続の枠変更も収支へ寄与する。追加2場では条件が発生せず全案同体なので、新しい効果の再現例とはしない。

Dayは3案同じで、214取得/42場・利益878,220.4/損失830,610.8/収支+47,609.6円・未知0。今回の新条件はNightだけ。Dayの改善や両指数の全面採用をこのCSVから主張しない。

## CSVの定義と確認

各候補のデイ42行・Night41行を保持。確定収支/確定累計の空欄は未知で、0円ではない。利益−損失は「既知寄与」へ一致し、未知を含む口座全体の確定収支とは区別する。保有率は全時間の率であり、各場20%達成や毎時一定回数を意味しない。DDは場末の既知実現寄与で、建玉保有中の最大時価DDではない。

[研究の原因と支持件数](../../study/00208_TOPIXの浅い押戻し逆張りを控え損失を比較する/README.md) / [15CSV・6,300セルの再読照合](../../study/00208_TOPIXの浅い押戻し逆張りを控え損失を比較する/閲覧資料/CSV確認.json) / [恒久再現資料](../../study/00208_TOPIXの浅い押戻し逆張りを控え損失を比較する/閲覧資料/README.md)。xlsxは生成していない。
''';(OUT/'README.md').write_text(body,'utf-8')
    (support/'README.md').write_text('''# 208候補別CSVの再現

[閲覧入口](../../../outputs/00208_TOPIXの浅押戻し見送り比較/README.md)。旧0・全期有望主3・前48順位首位6を別々に保存した。[型付き入力](閲覧入力.json)・[対象保有区間](対象保有区間.json.gz)・[CSV照合](CSV確認.json)・[Source](閲覧Source.zip)・[索引](Source索引.json)。

入力を作る.pyは通常実行で正式の全83集計と対象保有区間だけを読み、workの金融に依存しない。`--保有を固定`は独立照合済み金融から最小の区間情報を保存する初回用で、通常は不要。型付きJSONを `scripts/損益CSV/候補別に出力する.mjs --input 型付き入力 --output 新規出力先 --proof 新規確認先 --dependencies Codex提供node_modules` へ渡す。既存CSVは上書きしない。

NodeとCodex提供artifact-toolで全セルを渡し、recalculate後にCSV出力、全15表の描画を確認した。Python csvで全6,300セルを再読照合し、未知空欄・累計・利益−損失を検査。CSVはUTF-8 BOM/CRLF。xlsxは作らず、条件・金融・固定選択も変更していない。
''','utf-8')
    study_readme=TRIAL/'README.md';text=study_readme.read_text('utf-8');link='[候補別CSV](../../outputs/00208_TOPIXの浅押戻し見送り比較/README.md)'
    if link not in text:study_readme.write_text(text+'\n## 閲覧CSV\n\n'+link+'に旧0・有望主3・前48首位6の全83場を分離して保存した。各候補5CSV、計15CSV・6,300セルを元集計/保有区間へ再読照合。未知は確定収支・累計の空欄として保持する。\n','utf-8')
    print(json.dumps({'CSV':15,'全セル照合':cells,'未知空欄':nulls,'正式保存':True},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
