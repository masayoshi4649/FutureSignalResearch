# 173のDAY追加予備screenと三帯pool

準備日：2026-11-15。Source・人工検査を先に作成し、Root F1で物理指紋を固定してから明示GOで実行する。新しい自然screenはこの準備段階では実行していない。既存Source・旧統計・固定試行は編集しない。

## 計算範囲

- OLD1460の163保存出生を12幅ごとの元geometry・ALL/EDGEのまま再利用する。
- NEW768の172保存出生をtarget_points200・ALL/EDGEのまま全出口幅へ共用する。
- OLD/NEWのPRE/POSTは、172の完成統計NPZ・軸を元の完了票と固定SHA256へ照合して引用する。既存NIGHT合計の再計算や複製はしない。
- 足りないDAYだけ、ALL/EDGE×NORMAL/REVERSE×12幅×4期限×3期間の既存16指標を追加計算する。
- 同じphysical caseの最初の成立q0を全場で固定してからDAY/PRE/POSTへ分ける。正逆は同じq0/caseを共有し、実側を交換して実BBO数値表を読む。
- IFD_FIRSTを使い、STRICT_Hの未完了でも欠測前に確定した到達を残す。未到達N・観測不足Cを分け、net5はknownの取得だけを加算する。
- 各Sourceの代表8規則は別の取得一覧・別集計で全DAYの16指標を確認する。OLD代表8は旧164全帯N−旧172NIGHTの11加法項でも照合する。非加法項を差し引かない。
- 任意指定のLOCAL173出生は、152行に実mode適用済みの`directions[152,N]`をDECLARED一軸で3帯集計する。ALL/EDGEを二重評価しない。代表8を別一覧で三帯全指標へ照合する。

OLD/NEWは計427,776政策、LOCAL173は14,592政策となる。独立一枚の予備統計であり、global1再生の口座収支・建玉中央値・セッション中央値の達成結果ではない。既存16指標にない中央値上下限・到達場数・取得場集合は、予備filter後の実caseから後段adapterが計算する。

## 保存・接続API

`screen173.py`がOLD1460_DAY.npz/NEW768_DAY.npzと各DAY軸、`pool.json`、`独立検算.json`、`完了.json`を新規保存する。DAY配列名は`metrics`、shapeは`[規則,2発火,2方向,12幅,4期限,3期間,16指標]`。

`pool173.iter_blocks(day_output, additions=None)`がSource別の次のdictを逐次返す。

- `source`：OLD1460、NEW768又はLOCAL173等。
- `ids` / `families`：固定規則順と群。OLD/NEWの群はID先頭2文字、LOCALはCatalogのfamily。
- `metrics`：`[規則,発火,2方向,12幅,4期限,3帯,3期間,16指標]`。
- `axis`：日本語keyの規則順・発火方式・方向・幅・時計・帯・期間・指標・shape。
- `birth`：`layout`、`files`、`proof`、`q0_count`等の方向解決参照。
- `declared_modes`：LOCAL等の行別実mode。OLD/NEWではnull。
- `eligible_hours`：DAY/PRE/POST×全期/前48/後25の時間。
- `references` / `manifest`：入力とpoolの物理指紋。

統一帯順はDAY/PRE/POST、期間順は全期/前48場/後25場。OLD/NEWの発火順はALL/EDGE、LOCAL173はDECLARED一個。方向順はNORMAL/REVERSE。

16指標順は`count,F,A,N,C,rate,profit,loss,net,pf,known,unknown,scenes,eligible_scenes,per_hour,max_scene_share`。`scenes`は取得あり場数であり、F/A到達場数ではない。`max_scene_share`は最多場の取得数/全取得数。未知を含む全件収支はこの16項目から確定させない。

出生参照は`{path:repo相対,bytes,sha256}`。OLDの`birth.layout=width_dependent`は`files[str(width)]`、NEWの`layout=shared`は`files.shared`を読む。LOCALの`layout=declared`は`array_name=directions`、`files.shared`を読む。

LOCAL出生manifestは`source,ids,families,declared_modes,birth,proof`を持つ。proofの`source_fingerprints`と`input_fingerprints`は`{repo相対:{bytes,sha256}}`でRoot F1に照合する。`SourceCatalog.json`のrules[id/family/mode]とmanifest順序も一致確認する。LOCAL用full blockはサブフォルダへ保存し、同じ親poolから参照する。

追加の完成済み三帯統計は`pool173.register_full(...,modes=...,declared_modes=...)`で別poolへ登録し、`iter_blocks`のadditionsへ渡せる。集計やmode変換は登録関数で行わない。

## F1と実行

Rootは`screen173.required_paths()`が返すSource・人工結果・全既存入力を、`{"固定対象":[{"path":repo相対,"bytes":整数,"sha256":文字列},...]}`としてF1へ固定する。LOCALの生成Source・Catalog・人工結果と非金融生成入力もRoot F1へ追加する。生成後manifestをF1へ遡って追加せず、そのproofから固定Sourceと入力を照合する。

GO後の実行例：

```powershell
python work/173予備入口screen/screen173.py --f1 <RootF1のパス> --f1-sha256 <固定SHA256> --output work/173予備入口screen/自然結果 --execute --local-manifest <出生manifest173LOCAL.jsonのパス>
```

LOCALを別途集計する場合は`--local-manifest`を省略できる。出力先は未作成のwork内に限定する。F1未指定・指紋不一致・固定対象不足では自然読込へ進まない。Rootの実行GOを受ける前に上の自然実行を行わない。

人工検査：

```powershell
python work/173予備入口screen/人工検査.py
```

64人工母集団で三帯・正逆・全幅期限期間の884,736指標セルを独立集計に照合した。正準化の順番、IFD_FIRST、未知金額除外、LOCALのDECLARED一軸、誤F1の自然読込前拒否も確認した。自然の原板・特徴・金融を人工検査から読まない。
