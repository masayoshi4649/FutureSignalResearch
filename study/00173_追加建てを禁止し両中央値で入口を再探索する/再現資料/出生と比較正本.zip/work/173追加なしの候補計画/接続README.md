# Stage1配列と純短表の接続

2026-11-15。自然実行はRootのF1 GO待ち。支持閾値は`Source/支持と多様性で短表を選ぶ.py`の既定値を維持した。

`pool173.iter_blocks(day_output, additions=[])`の16指標配列を使う。最緩の疎補完層に必要な取得数・F+A・取得場数・C/金融未知比だけで事前filterし、通過設定の元出生と実caseから取得場集合、F/A到達場数、最多一場到達数、独立一枚の両中央値上下界を補完する。最多取得場比をF/A最多場比として代用しない。

元16指標の取得・F/A/N/C・金融未知・取得場・対象場・利益/損失/差引の12項目は、実case再集計と設定ごとに照合する。0取引場はセッション中央値へ含める。ここでの中央値は候補圧縮の代理値であり、最終の全場global1中央値とは分ける。

出生形式はOLD1460の幅別ALL/EDGE、新768の共通ALL/EDGE、LOCAL173のmode適用済み`directions`に対応する。LOCALの発火軸はDECLARED1で、辞書の`declared_modes[rule_index]`を実modeとし、再EDGE化しない。

RootがF1を固定した後、次の形式で実行する。

```powershell
python work/173追加なしの候補計画/Source/Stage1から短表を作る.py `
  --day-output ＜DAY追加poolフォルダ又はpool.json＞ `
  --addition ＜LOCAL173のpoolフォルダ又はpool.json＞ `
  --f1-go ＜RootのF1.json＞ `
  --f1-sha256 ＜Rootが固定した64桁SHA256＞ `
  --out work/173追加なしの候補計画/短表
```

F1 JSONは`試行:173`（又は`trial:173`）と`GO:true`を必要とする。固定SHA又はGOが不一致なら、自然poolのimport・金融読込・出力作成より前に停止する。出力先はwork配下の未作成ディレクトリとする。

出力`短表173.json`は`{成功:true, 選択:{全期:純selector返り値, 前48:純selector返り値}}`。各候補に`rule_index/position/key/birth_ref/birth_layout/birth_array/mode_index/axis_mode`を保持する。全期は旧73、前48は旧前48場だけの選択であり、後25/追加7を順位へ混ぜない。金融未知による無限界は、標準JSON上で文字列`Infinity/-Infinity`へ変換する。

`接続実行の確認.json`には全候補数・事前filter通過数を源/期間/帯ごとに残す。純selectorの支持不足数は事前filter後の件数なので、事前filterの棄却数と合わせて不足を読む。

人工確認は`python work/173追加なしの候補計画/Source/接続の人工を確認する.py`。生成した人工NPZだけを使い、①4000統計で支持適格を事前filterで落とさない、②3出生形式・元添字・LOCAL維持、③F1拒否を確認した。別の純selector人工7件と合わせて全件通過。自然の短表は未生成。
