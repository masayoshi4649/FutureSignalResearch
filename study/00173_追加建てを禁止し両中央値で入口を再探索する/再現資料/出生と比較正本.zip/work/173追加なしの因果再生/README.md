# 173の追加建てをしない純因果再生

確認日：2026-11-15。173用の純部品段階であり、新試行の正式採番・自然探索・金融比較はこの部品作成では行っていない。既存172のSource・固定結果と、完了したデイ集中診断は変更していない。

`engine173.py`は172のevent別幅・event付き決済callbackの形を引き継ぎ、保有・未決を買売合計一件までに変更した別Sourceである。原コピー元は`work/172ナイト数量再生/engine172.py`、SHA256は`d1b1fab0daad8f74d8928ea985a311288e5417a4455bf7209783c263b17a91a7`。

## 数量・時計の契約

- `capacity`は整数1固定。`None`、10、真偽値等を拒否する。各要求mini一枚で、同側追加・逆側保有・両建てを許さない。
- 買売合計の保有0・未決予約0の時だけ一要求を受理する。未決も取得前から全方向の枠を占める。
- 当時q0までに到来した取得・取消・決済だけを反映する。将来のexitを知っていても、その時計まで枠は空けない。
- 既知決済の原行は不明なので、exit秒の末尾に解放する。同じ秒のq0では再要求を受けず、解放後の次q0で受理可能となる。
- 決済時計が未知なら場末まで保持する。未知を0円決済として途中解放しない。場末で数量状態を閉じ、次のDay/Nightで再初期化する。NY境界は場を分けず、強制返済を加えない。
- 取得aliasは同じcaseの二つ目を建玉にせず、callbackも呼ばない。最終取得caseの重複も拒否する。
- 主入口があるq0は主を優先し、棄却しても同q0の技術補完や逆側へ代用しない。
- 技術補完は従来どおり初参加用。既定は場開始2700秒後、未取得の場だけで評価する。主未決の取消後は補完可能。最初の取得後は技術補完を再開しない。`after_seconds`を変える政策は呼出側が別候補として固定する。
- 172と同じく、主の当該枝幅0はそのeventの主を無効化し、他の条件が成立すれば技術補完へ進む。幅配列は非負整数、補完幅は正整数。

## 接続方法

`replay`の引数は172と同じ並びである。`momentum_width`と`fade_width`はevent別配列、技術補完幅は固定整数。`exit_lookup(event, case, side, width)`には取得が成立した後だけ到達する。呼出側の閉包が当該出生の期限を選び、既知決済秒又は`None`を返す。部品は価格・金融値・先着ラベルを入力に取らない。

取得`records`は172と同じ`event/case/side/width/origin/tier`。`requests`には同側の`held_before/pending_before`を残し、買売合計の`held_total_before/pending_total_before`を追加した。`skip_reason`は受理なら`null`、棄却なら`held`又は`pending`。全側不変式により、保有と未決が同時に正になることはない。

## 0参加を説明する監査

|監査|意味|
|---|---|
|`core_signal_events` / `effective_core_signal_events`|元主信号数／幅0無効化後の主信号数|
|`technical_signal_events`|全技術信号数|
|`technical_before_start_events` / `technical_after_start_events`|補完開始前／開始後の技術信号数|
|`technical_eligible_before_first_fill`|主のないq0で、開始後・初取得前に技術補完を要求した数。未決棄却も含む|
|`accepted_core` / `accepted_technical`|主／補完の受理要求数|
|`filled_core` / `filled_technical`|主／補完の取得数|
|`cancelled_core` / `cancelled_technical`|主／補完の失効・取消数|
|`skipped_held_core/technical`|主／補完を保有中のため棄却した数|
|`skipped_pending_core/technical`|主／補完を全側未決中のため棄却した数|
|`technical_wait_core_pending`|技術補完の未決棄却のうち、主要求が未決だった数|
|`technical_after_first_fill`|開始後かつ主のないq0で、すでに初取得済みのため補完対象外だった数|
|`capture_status_core/technical`|受理した取得対応の`status`別件数|
|`capture_reason_core/technical`|任意の`reason`又は`termination_reason`文字列別件数。未提供なら「未提供」|
|`pending_at_scene_end`|場末までに失効・取得の時計が到来しなかった予約の側別件数|
|`peak_global_reserved`|全買売の保有と未決の合計最大。常に0又は1|

従来の`quantity_rejected_core/technical`は互換の合計欄として残し、保有中棄却＋未決中棄却に一致させる。側別最大値も残すが、買側最大1と売側最大1を足して最大同時保有2と解釈しない。

価格不足かどうかを部品で推測しない。取得対応が`no_price`等のstatusや理由を渡せばそれを集計する。理由が未提供の取消から価格不足を断定することはできない。受理後の取得対応情報は、要求を受ける判断や方向選択には使わない。

空状態の最初の要求は受理するが、旧172と全状況で初取得を一致させる契約ではない。初要求が場末まで未決のケースでは、172が並行要求した後続取得を173は止めるため、173だけ0参加になり得る。未決もglobal1という制約に伴う結果であり、`pending_at_scene_end`と主/T別の未決棄却・取得対応status/reasonへ理由を残す。これを避ける未決取消期限等はこの部品に追加していない。

## 人工検査と再現

リポジトリルートから次を実行する。

```powershell
python work/173追加なしの因果再生/人工検査.py
```

17の明示シナリオに加え、固定乱数種20261115173の320母集団、計25,600q0を通常・鏡像・未来prefix変更の960回で再生した。単一保有/未決オブジェクトと時計一覧の最小探索を使う独立oracleに、全要求・全取得・全監査が一致した。

global1上限、逆側禁止、主/Tの未決棄却、主pending取消後のT初取得、正常価格不足の理由、同秒別原行、同秒exit、返済後再取得、未知場末、alias、場リセット、0参加の由来、既存172との最初の取得一致、整数1以外のcapacity拒否を確認した。自然の原板・特徴・金融は読んでいない。

`人工確認.json`が結果、`SourceSHA256.json`が入力部品・検査・READMEの指紋。建玉ごと及び全Day/Nightセッション別の費用後収支中央値が黒字という選択条件は、自然再生後の集計・選択器側で評価する。この純engineは中央値、損益、採否を計算しない。
