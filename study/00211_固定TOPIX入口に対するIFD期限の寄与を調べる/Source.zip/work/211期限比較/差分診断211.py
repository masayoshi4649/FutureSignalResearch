"""固定入口の期限差を、同じ実取得の返済差と枠の取得集合差へ分ける。"""
from collections import Counter
import math
import 実行211 as R


# ----------------------------------------
def records(pack: dict) -> dict:
    """
    機能: 重複のない実取得キーを作る。
    引数: pack(dict)は固定金融。
    返り値: dictは(scene,entry_line,side,width)から台帳行への写像。
    """
    ledger=pack['ledger'];result={}
    for i in range(len(ledger['known'])):
        row={k:v[i] for k,v in ledger.items()};key=tuple(row[k] for k in ('scene','entry_line','side','width'))
        assert key not in result;result[key]=row
    return result


# ----------------------------------------
def summarize(rows: list) -> dict:
    """
    機能: 実取得群の既知利益・損失・未知を独立に要約する。
    引数: rows(list[dict])。
    返り値: dict。未知金額をゼロ補完しない。
    """
    known=[r['net'] for r in rows if r['known']]
    return {'取得':len(rows),'既知':len(known),'未知':len(rows)-len(known),'利益':sum(max(v,0) for v in known),
            '損失':sum(max(-v,0) for v in known),'既知収支':sum(known),'既知赤字':sum(v<0 for v in known),
            '場数':len({r['scene'] for r in rows}),'理由':dict(Counter(r['reason'] for r in rows))}


# ----------------------------------------
def main() -> None:
    """
    機能: 主H60と二期限の実取得差を三母体・全体/帯別に分解する。
    引数: なし。
    返り値: None。結果を見た入口・期限の選び直しはしない。
    """
    R.verify_seal();results=[]
    for mother in R.MOTHERS:
        old_id=f'TOPIX211_{mother}_H60';old=records(R.read(R.HERE/'金融正本'/(old_id+'.json.gz')))
        for horizon in ('H120','SESSION'):
            new_id=f'TOPIX211_{mother}_{horizon}';new=records(R.read(R.HERE/'金融正本'/(new_id+'.json.gz')))
            common=sorted(old.keys()&new.keys());old_only=sorted(old.keys()-new.keys());new_only=sorted(new.keys()-old.keys())
            pairs=[]
            for key in common:
                a,b=old[key],new[key]
                assert a['entry_time']==b['entry_time'] and a['entry_price']==b['entry_price']
                pairs.append({'キー':list(key),'H60':a,'延長':b,'要求同一':(a['request_line'],a['request_time'])==(b['request_line'],b['request_time'])})
            bands={}
            for band in ('ALL','DAY','NIGHT','PRE','POST'):
                wanted={'DAY':{0},'NIGHT':{1,2},'PRE':{1},'POST':{2},'ALL':{0,1,2}}[band]
                chosen=[p for p in pairs if p['H60']['phase'] in wanted]
                oa=[old[k] for k in old_only if old[k]['phase'] in wanted];nb=[new[k] for k in new_only if new[k]['phase'] in wanted]
                sa=summarize([p['H60'] for p in chosen]);sb=summarize([p['延長'] for p in chosen]);so=summarize(oa);sn=summarize(nb)
                all_old=summarize([r for r in old.values() if r['phase'] in wanted]);all_new=summarize([r for r in new.values() if r['phase'] in wanted])
                assert math.isclose(all_new['既知収支']-all_old['既知収支'],sb['既知収支']-sa['既知収支']+sn['既知収支']-so['既知収支'],abs_tol=1e-7)
                transitions=Counter((p['H60']['reason'],p['延長']['reason'],p['H60']['known'],p['延長']['known']) for p in chosen)
                timeout=[p for p in chosen if p['H60']['reason']=='期限']
                bands[band]={'共通H60':sa,'共通延長':sb,'H60のみ':so,'延長のみ':sn,'全H60':all_old,'全延長':all_new,
                    '共通既知寄与差':sb['既知収支']-sa['既知収支'],'集合差の既知寄与差':sn['既知収支']-so['既知収支'],
                    '既知から未知':sum(p['H60']['known'] and not p['延長']['known'] for p in chosen),
                    '未知から既知':sum(not p['H60']['known'] and p['延長']['known'] for p in chosen),
                    'H60期限決済の共通取得':len(timeout),
                    'H60赤字から延長黒字_両既知':sum(p['H60']['known'] and p['延長']['known'] and p['H60']['net']<0<p['延長']['net'] for p in timeout),
                    'H60黒字から延長赤字_両既知':sum(p['H60']['known'] and p['延長']['known'] and p['延長']['net']<0<p['H60']['net'] for p in timeout),
                    '返済遷移':[{'H60理由':k[0],'延長理由':k[1],'H60既知':k[2],'延長既知':k[3],'件数':v} for k,v in sorted(transitions.items())]}
            results.append({'母体':mother,'比較':horizon,'主':'H60','帯別':bands,'共通取得':pairs,
                            'H60だけの実取得':[old[k] for k in old_only],'延長だけの実取得':[new[k] for k in new_only],
                            '集合差理由':'純出生・幅不変なので期限変更が予約・保有枠と後続取得を変える。棄却候補の仮想利益ではなく各口座で実取得したものだけ。'})
    R.save(R.STUDY/'監査/期限差の実取得分解.json.gz',{'試行':211,'全83既使用':True,'比較':results,'Source':R.ref(__import__('pathlib').Path(__file__))})
    for r in results:
        print(r['母体'],r['比較'])
        for b in ('DAY','NIGHT'):
            x=r['帯別'][b];print(b,{k:x[k] for k in ('共通既知寄与差','集合差の既知寄与差','既知から未知','H60赤字から延長黒字_両既知','H60黒字から延長赤字_両既知')},
                    '件数',x['共通H60']['取得'],x['H60のみ']['取得'],x['延長のみ']['取得'])


# ----------------------------------------
if __name__=='__main__':main()
