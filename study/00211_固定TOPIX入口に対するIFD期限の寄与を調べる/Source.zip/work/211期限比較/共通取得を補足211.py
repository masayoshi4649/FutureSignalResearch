"""既知寄与の差を両側既知の差と既知・未知の入れ替わりへ分ける。"""
from pathlib import Path
import math
import 実行211 as R


# ----------------------------------------
def main() -> None:
    """
    機能: 共通取得の既知寄与差を未知金額ゼロ扱いと誤読しない内訳へ分ける。
    引数: なし。
    返り値: None。元台帳・条件・既存診断は変更しない。
    """
    path=R.STUDY/'監査/期限差の実取得分解.json.gz';result=[]
    for comparison in R.read(path)['比較']:
        bands={}
        for band,wanted in {'ALL':{0,1,2},'DAY':{0},'NIGHT':{1,2},'PRE':{1},'POST':{2}}.items():
            pairs=[p for p in comparison['共通取得'] if p['H60']['phase'] in wanted]
            groups={(a,b):[p for p in pairs if (p['H60']['known'],p['延長']['known'])==(a,b)] for a in (False,True) for b in (False,True)}
            both=sum(p['延長']['net']-p['H60']['net'] for p in groups[True,True])
            old_lost=sum(p['H60']['net'] for p in groups[True,False]);new_added=sum(p['延長']['net'] for p in groups[False,True])
            assert math.isclose(both-old_lost+new_added,comparison['帯別'][band]['共通既知寄与差'],abs_tol=1e-7)
            bands[band]={'両既知件数':len(groups[True,True]),'両既知収支差':both,
                         '既知から未知件数':len(groups[True,False]),'既知から未知の旧収支':old_lost,
                         '未知から既知件数':len(groups[False,True]),'未知から既知の新収支':new_added,
                         '両未知件数':len(groups[False,False]),'未知金額は未確定':True}
        result.append({'母体':comparison['母体'],'比較':comparison['比較'],'帯別':bands})
    R.save(R.STUDY/'監査/共通取得の既知両側と未知化.json',{'入力':R.ref(path),'Source':R.ref(Path(__file__)),'比較':result})


# ----------------------------------------
if __name__=='__main__':main()
