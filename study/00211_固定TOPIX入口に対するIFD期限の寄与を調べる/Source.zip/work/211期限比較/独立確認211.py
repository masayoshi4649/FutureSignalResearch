"""期限比較を原順配列の直接走査・単一状態・独立算術で確認する。"""
from pathlib import Path
from collections import defaultdict
from bisect import bisect_left,bisect_right
from datetime import datetime,timedelta,timezone
from zoneinfo import ZoneInfo
import math
import sys
import numpy as np
import 実行211 as R

sys.path.insert(0,str(R.ROOT/'work/183損失安定性'))
import TOPIXを独立検算する as V


# ----------------------------------------
def load_arrays(entry: dict) -> dict:
    """
    機能: 原順8列を順走査し、価格時計高水位と正常板を独立に選ぶ。
    引数: entry(dict)は固定入力。
    返り値: dictは研究時間内の配列。生産Routeや区間木を呼ばない。
    """
    start,end,force=V.bounds(entry['session']);keep=[];high=-math.inf
    with np.load(entry['cache_absolute'],allow_pickle=False) as z:
        for i,clock in enumerate(z['now']):
            if not math.isfinite(clock):continue
            if clock<high:continue
            high=clock
            if start<=clock<end and bool(z['valid'][i]):keep.append(i)
        result={k:z[k][keep] for k in ('now','line','bid','ask')}
    result.update(scene=entry['session'],start=start,end=end,force=force)
    return result


# ----------------------------------------
def oracle(a: dict,q0: float,request_line: int,side: int,width: float,horizon: str) -> dict|None:
    """
    機能: 対象窓の配列を直接調べ、IFD接触・返済・未知を独立に計算する。
    引数: a(dict)は原順配列、q0(float)、request_line(int)、side(int)、width(float)、horizon(str)。
    返り値: dict|Noneはセル期待値。期限内の区間木や生産cellは呼ばない。
    """
    t=a['now'];i=bisect_left(t,q0+1)
    if i==len(t) or t[i]>q0+30 or t[i]>=a['force']:return None
    opened=float(t[i]);price=float(a['ask'][i] if side==1 else a['bid'][i]);mark=a['bid'] if side==1 else a['ask']
    horizon_seconds={'H60':3600,'H120':7200,'SESSION':math.inf}[horizon]
    deadline=min(opened+horizon_seconds,a['force']);edge=bisect_right(t,deadline)
    signed=side*(mark[i:edge]-price);hits=np.flatnonzero(np.abs(signed)>=width)
    touch=i+int(hits[0]) if len(hits) else None
    label='N' if touch is None else ('F' if side*(mark[touch]-price)>=width else 'A')
    reason={'N':'期限','F':'IFD利確','A':'IFD損切'}[label]
    target=deadline if touch is None else float(t[touch])
    j=touch if label=='F' else bisect_left(t,target+1)
    ttl=min(target+30,a['end']);valid=j<len(t) and t[j]<=ttl
    last=j if valid else min(bisect_left(t,ttl),len(t)-1)
    blanks=np.flatnonzero(np.diff(t[i:last+1])>300)
    first_gap=i+int(blanks[0])+1 if len(blanks) else None
    unknown=first_gap is not None or not valid
    if first_gap is not None:known_until=float(t[first_gap-1]);why='正常板300秒超空白'
    elif not valid:known_until=float(t[max(i,min(bisect_right(t,ttl)-1,len(t)-1))]);why='返済時計不足'
    else:known_until=float(t[j]);why=None
    if unknown and (touch is None or (first_gap is not None and first_gap<=touch)):label='C'
    exit_price=None if unknown else (price+side*width if reason=='IFD利確' else float(mark[j]))
    ny=datetime.fromtimestamp(q0,ZoneInfo('America/New_York'))
    ny_open=datetime.combine(ny.date(),datetime.min.time(),ZoneInfo('America/New_York'))+timedelta(hours=9,minutes=30)
    band='DAY' if a['scene'].endswith('_Day') else ('PRE' if q0<ny_open.timestamp() else 'POST')
    return {'session':a['scene'],'side':side,'request_time':q0,'request_line':request_line,'entry_time':opened,'entry_line':int(a['line'][i]),
        'entry_price':price,'exit_time':None if unknown else float(t[j]),'exit_line':None if unknown else int(a['line'][j]),'exit_price':exit_price,
        'width':width,'label':label,'reason':reason,'unknown':unknown,'unknown_reason':why,'known_until':min(max(known_until,opened),a['end']),
        'gross_pt':None if unknown else side*(exit_price-price),'band':band}


# ----------------------------------------
def audit() -> None:
    """
    機能: 全9口座の全成立セル・保有予約枠・台帳・費用・統計を別実装で照合する。
    引数: なし。
    返り値: None。事後監査票を保存し、固定Sourceは変更しない。
    """
    R.verify_seal();rows,_=R.pure();resources=R.D.G.entries(True);by=defaultdict(list)
    for row in rows:by[row['session']].append(row)
    states=R.read(R.HERE/'全9口座安定性.json.gz')['metrics'];assert len(states)==9
    packs={s['id']:R.read(R.HERE/'金融正本'/(s['id']+'.json.gz')) for s in states}
    cell_count=attribute_count=slot_count=fee_count=0
    diagnostics=[]
    for resource in resources:
        arrays=load_arrays(resource);scene=resource['session']
        for horizon in R.D.HORIZONS:
            production=R.D.Route(resource,horizon);cache={}
            for row in by[scene]:
                for ci,side in enumerate(row['signals']):
                    if not side:continue
                    key=(row['time'],row['line'],side,row['widths'][ci])
                    if key in cache:continue
                    cell=oracle(arrays,*key,horizon);assert cell==production.cell(*key),(scene,horizon,key)
                    cache[key]=cell;cell_count+=1;attribute_count+=len(cell) if cell else 1
            # ----------------------------------------
            # 時刻を進める単一状態で全後続要求を再生し、台帳やpack生成関数は呼ばない。
            for ci,mother in enumerate(R.MOTHERS):
                identity=f'TOPIX211_{mother}_{horizon}';pack=packs[identity];ledger=pack['ledger']
                ids=[i for i,name in enumerate(ledger['scene']) if name==scene];positions=[p for p in pack['positions'] if p['scene']==scene]
                counts={'純成立':0,'保有棄却':0,'予約棄却':0,'取得':0,'失効':0};release=-math.inf;state='空';at=0
                for row in by[scene]:
                    side=row['signals'][ci]
                    if not side:continue
                    counts['純成立']+=1
                    if row['time']<=release:counts['予約棄却' if state=='予約' else '保有棄却']+=1;continue
                    cell=cache[(row['time'],row['line'],side,row['widths'][ci])]
                    if cell is None:
                        counts['失効']+=1;state='予約';release=min(row['time']+30,arrays['force']);continue
                    counts['取得']+=1;state='保有';release=arrays['end'] if cell['unknown'] else cell['exit_time']
                    assert at<len(ids);i=ids[at];at+=1
                    net=None if cell['unknown'] else round(side*(cell['exit_price']-cell['entry_price'])*1000-2*41.8-2*.25*1000,1)
                    fields={'scene':scene,'phase':{'DAY':0,'PRE':1,'POST':2}[cell['band']],'known':not cell['unknown'],'net':net,'origin':row['origins'][ci]}
                    for field,values in ledger.items():
                        assert values[i]==(fields[field] if field in fields else cell[field]),(identity,scene,i,field)
                        slot_count+=1
                    expected={'scene':scene,'fill':cell['entry_time'],'exit':cell['exit_time'],'confirmed_until':cell['known_until'],
                              'possible_until':arrays['end'] if cell['unknown'] else cell['exit_time']}
                    assert positions[at-1]==expected;slot_count+=len(expected);fee_count+=net is not None
                    assert arrays['start']<=cell['entry_time']<arrays['force']
                    assert cell['exit_time'] is None or cell['exit_time']<arrays['end']
                assert at==len(ids)==len(positions)
                expected={'scene':scene,**counts};actual=next(d for d in pack['diagnostics'] if d['scene']==scene)
                assert expected==actual;diagnostics.append({'id':identity,**expected})
    stats_count=sum(V.inspect_groups(packs[s['id']],s) for s in states)
    R.verify_seal()
    result={'成功':True,'事後独立監査':True,'条件':R.ref(R.STUDY/'条件.json'),'全83':83,'口座':9,'全成立セル':cell_count,'セル属性':attribute_count,
       '枠台帳属性':slot_count,'既知費用式':fee_count,'統計属性':stats_count,'枠診断':diagnostics,
       '方法':'原順8列を逐次高水位選別し、BBO部分配列の最初の接触を直接走査。生産Route/到達木を期待値の作成に用いない。枠は一件状態で別再生。',
       '限界':'原JSON板から8列を再抽出する検査ではない。既存ラージBBOをmini価格へ代用する約定仮定は共通。実受信時計はない。',
       'Source':[R.ref(Path(__file__)),R.ref(Path(V.__file__)),R.ref(Path(V.V.__file__))],
       '金融':[R.ref(R.HERE/'金融正本'/(s['id']+'.json.gz')) for s in states],'統計':R.ref(R.HERE/'全9口座安定性.json.gz')}
    R.save(R.STUDY/'監査/独立金融確認.json.gz',result)
    print({k:result[k] for k in ('成功','全成立セル','セル属性','枠台帳属性','既知費用式','統計属性')},flush=True)


# ----------------------------------------
if __name__=='__main__':audit()
