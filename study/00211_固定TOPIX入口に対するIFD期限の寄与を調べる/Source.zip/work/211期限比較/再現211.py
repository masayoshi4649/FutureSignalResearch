"""恒久Sourceと入力だけから別保存先へ復元し、固定九口座のbyte同体を確認する。"""
from pathlib import Path
import argparse
import gzip
import hashlib
import importlib
import json
import os
import shutil
import subprocess
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[2]
STUDY=ROOT/'study/00211_固定TOPIX入口に対するIFD期限の寄与を調べる'
HERE=Path(__file__).parent


# ----------------------------------------
def read(path: Path) -> object:
    """
    機能: JSONを読む。
    引数: path(Path)。
    返り値: object。
    """
    raw=path.read_bytes();return json.loads(gzip.decompress(raw) if path.suffix=='.gz' else raw)


# ----------------------------------------
def sha(path: Path) -> str:
    """
    機能: 内容指紋を計算する。
    引数: path(Path)。
    返り値: str。
    """
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


# ----------------------------------------
def save(path: Path,value: object) -> None:
    """
    機能: 復元確認JSONを保存する。
    引数: path(Path)、value(object)。
    返り値: None。
    """
    raw=(json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode()
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():assert path.read_bytes()==raw,path
    else:path.write_bytes(raw)


# ----------------------------------------
def restore(target: Path) -> None:
    """
    機能: Source.zipを別rootへ復元し、恒久入力は読取専用のhardlinkで参照する。
    引数: target(Path)は未使用のwork内絶対復元先。
    返り値: None。既存保存先の削除・移動・上書きはしない。
    """
    target=target.resolve();assert not target.exists() and target.is_relative_to((ROOT/'work').resolve());target.mkdir(parents=True)
    index=read(STUDY/'Source索引.json');archive=STUDY/'Source.zip';assert sha(archive)==index['ZIP']['sha256']
    with zipfile.ZipFile(archive) as z:
        for row in index['資源']:
            output=target/row['path'];assert output.resolve().is_relative_to(target);output.parent.mkdir(parents=True,exist_ok=True)
            content=z.read(row['path']);assert hashlib.sha256(content).hexdigest()==row['sha256'];output.write_bytes(content)
    condition=read(STUDY/'条件.json');refs=sum((condition[k] for k in ('Source','純入力','旧条件','H60期待','原順入力')),[])
    refs += [{'path':p.relative_to(ROOT).as_posix(),'sha256':sha(p)} for p in (
        ROOT/'inputs/TOPIX原順8列_20260921_20261116/台帳.json',
        ROOT/'inputs/00194_20261116夜と1117昼の固定適用入力/原順8列/入力台帳.json')]
    links=[];copied=[]
    for row in refs:
        src=ROOT/row['path'];dst=target/row['path'];assert sha(src)==row['sha256']
        if dst.exists():assert sha(dst)==row['sha256'];continue
        dst.parent.mkdir(parents=True,exist_ok=True)
        if row['path'].startswith('inputs/'):
            os.link(src,dst);links.append({'path':row['path'],'sha256':row['sha256']})
        else:
            assert not row['path'].startswith('work/'),('恒久ZIPへ不足',row['path'])
            shutil.copyfile(src,dst);copied.append(row['path'])
    for name in ('条件.json','人工確認.json','H60同体確認.json','金融開始前固定.json'):
        path=STUDY/name;dst=target/path.relative_to(ROOT);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,dst)
    save(target/'復元入力票.json',{'元root':str(ROOT),'復元root':str(target),'hardlink入力':links,'複写正式物':copied,
        'SourceZIP_SHA':sha(archive),'原workの期待対照はZIPから復元':True})
    command=[sys.executable,'-X','utf8',str(target/'work/211期限比較/再現211.py'),'--child',str(ROOT)]
    subprocess.run(command,cwd=target,check=True)
    proof=read(target/'復元確認.json')
    save(STUDY/'監査/別保存先の主金融再現.json',proof)
    print(json.dumps({'成功':proof['成功'],'全金融byte同体':len(proof['金融']),'統計byte同体':proof['統計byte同体'],
                     '原work研究読取':proof['原work研究読取'],'入力改変なし':len(proof['入力SHA前後同体'])},ensure_ascii=False))


# ----------------------------------------
def child(original: Path) -> None:
    """
    機能: 元workの研究資源読取と入力書込みを禁止して復元Sourceを実行する。
    引数: original(Path)は元root。
    返り値: None。金融正本と統計のbyte同体・依存・入力不変を保存。
    """
    original=original.resolve();ticket=read(ROOT/'復元入力票.json');writes=[];blocked=[];opened=set()
    links=ticket['hardlink入力'];before={r['path']:sha(ROOT/r['path']) for r in links}
    allowed_runtime=[(original/'work/複合テクニカル学習環境').resolve(),(original/'work/pythonlibs').resolve()]
    def audit(event: str,args: tuple) -> None:
        """
        機能: openの書込先と元研究workへの読取を監視する。
        引数: event(str)、args(tuple)はPython監査イベント。
        返り値: None。不正参照は例外で停止。
        """
        if event!='open' or not isinstance(args[0],(str,bytes,os.PathLike)):return
        path=Path(os.fsdecode(args[0])).resolve();mode=args[1];flags=args[2] or 0
        write=(isinstance(mode,str) and any(c in mode for c in 'wax+')) or bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
        in_runtime=any(path.is_relative_to(p) for p in allowed_runtime)
        if write and (path.is_relative_to(ROOT/'inputs') or (path.is_relative_to(original) and not path.is_relative_to(ROOT))):
            writes.append(str(path));raise RuntimeError('入力又は元保存先への書込みは禁止')
        if not write and path.is_relative_to(original/'work') and not path.is_relative_to(ROOT) and not in_runtime:
            blocked.append(str(path));raise RuntimeError('元workの研究資源を読取禁止')
        if not write and path.suffix=='.py' and path.is_relative_to(ROOT):opened.add(path.relative_to(ROOT).as_posix())
    sys.addaudithook(audit)
    sys.path.insert(0,str(ROOT/'work/211期限比較'));R=importlib.import_module('実行211')
    R.h60();R.finance()
    # ----------------------------------------
    # 期待値は恒久金融だけを参照する。元workへは接続しない。
    financial=[];official=original/'study/00211_固定TOPIX入口に対するIFD期限の寄与を調べる'
    for path in sorted((ROOT/'work/211期限比較/金融正本').glob('*.json.gz')):
        expected=official/'金融正本'/path.name;assert path.read_bytes()==expected.read_bytes()
        financial.append({'file':path.name,'sha256':sha(path)})
    assert len(financial)==9
    for name in ('全9口座安定性.json.gz','全9口座短表.json'):
        assert (ROOT/'work/211期限比較'/name).read_bytes()==(official/name).read_bytes()
    after={r['path']:sha(ROOT/r['path']) for r in links};assert before==after
    assert not writes and not blocked
    save(ROOT/'復元確認.json',{'成功':True,'方式':'恒久Sourceから別保存先、inputsはhardlink書込拒否、原work研究読取禁止',
       'SourceZIP_SHA':ticket['SourceZIP_SHA'],'金融':financial,'統計byte同体':True,'原work研究読取':blocked,'入力書込':writes,
       '入力SHA前後同体':links,'復元研究Source読取':sorted(opened),'条件SHA':sha(R.STUDY/'条件.json'),
       '限界':'194入力台帳に元rootへの絶対pathがあり、同一PCで恒久inputsの原位置を残した再現。原JSONからの全旧履歴再抽出ではない。'})


# ----------------------------------------
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--target',type=Path);parser.add_argument('--child',type=Path);args=parser.parse_args()
    if args.child:child(args.child)
    else:assert args.target is not None;restore(args.target)
