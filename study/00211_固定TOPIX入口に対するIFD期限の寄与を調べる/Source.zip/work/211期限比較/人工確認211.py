"""新期限の時計と、期限以外が旧セル同体であることを人工入力で確認する。"""
from pathlib import Path
import ast
import inspect
import json
import tempfile
import textwrap
import numpy as np
import 期限接続211 as D


# ----------------------------------------
def structural_check() -> bool:
    """
    機能: 期限指定・module修飾・docstring以外の処理ASTが旧cellと同じことを確認する。
    引数: なし。
    返り値: bool。実行後の書換えではなく静的検査のみ。
    """
    old=ast.parse(textwrap.dedent(inspect.getsource(D.M.Route.cell))).body[0].body[1:]
    new=ast.parse(textwrap.dedent(inspect.getsource(D.Route.cell))).body[0].body[1:]
    new=[v for v in new if not(isinstance(v,ast.Assign) and isinstance(v.targets[0],ast.Name) and v.targets[0].id=='seconds')]
    old_deadline=next(v for v in old if isinstance(v,ast.Assign) and isinstance(v.targets[0],ast.Name) and v.targets[0].id=='deadline')
    for i,v in enumerate(new):
        if isinstance(v,ast.Assign) and isinstance(v.targets[0],ast.Name) and v.targets[0].id=='deadline':new[i]=old_deadline
    old_text='\n'.join(ast.unparse(v) for v in old)
    new_text='\n'.join(ast.unparse(v) for v in new).replace('M.band(', 'band(')
    assert old_text==new_text
    return True


# ----------------------------------------
def route(tmp: Path,seconds: list,bid: list,ask: list,horizon: str) -> D.Route:
    """
    機能: 人工的な正常板列を既存索引へ渡す。
    引数: tmp(Path)、seconds/bid/ask(list)、horizon(str)。
    返り値: Route。
    """
    scene='2026-09-21_Day';start,_,_=D.M.bounds(scene);n=len(seconds)
    path=tmp/'人工.npz'
    np.savez(path,now=start+np.asarray(seconds),line=np.arange(n)+1,bid=np.asarray(bid),ask=np.asarray(ask),valid=np.ones(n,dtype=bool))
    return D.Route({'session':scene,'cache_absolute':str(path)},horizon)


# ----------------------------------------
def run() -> dict:
    """
    機能: 期限・TP/SL時計・取得TTL・欠測・売買鏡像を確認する。
    引数: なし。
    返り値: dictは純粋な人工確認結果。実相場の損益は読まない。
    """
    checks=[];structural_check();checks.append('期限以外の旧cell AST同体')
    with tempfile.TemporaryDirectory() as folder:
        tmp=Path(folder);s,e,f=D.M.bounds('2026-09-21_Day');seconds=list(range(int(e-s)))
        for h in D.HORIZONS:
            r=route(tmp,seconds,[3999.5]*len(seconds),[4000.0]*len(seconds),h)
            x=r.cell(s,1,1,5);deadline=f if h=='SESSION' else s+1+D.HORIZONS[h]
            assert not x['unknown'] and x['exit_time']==deadline+1 and x['label']=='N'
            checks.append(h+'期限と翌秒返済')
            x=r.cell(f-2,1,1,5);assert x['entry_time']==f-1 and x['exit_time']==f+1
            assert r.cell(f-1,1,1,5) is None;checks.append(h+'終了前上限')
            for side in (1,-1):
                for favorable in (True,False):
                    b=[3999.5,3999.5,4006,4005,4004] if favorable else [3999.5,3999.5,3995,3993,3992]
                    a=[v+.5 for v in b]
                    if side==-1:b,a=[8000-v for v in a],[8000-v for v in b]
                    r=route(tmp,[0,1,2,3,4],b,a,h);x=r.cell(s,1,side,5)
                    assert not x['unknown'] and x['label']==('F' if favorable else 'A')
                    assert x['exit_time']==s+(2 if favorable else 3)
                    assert x['gross_pt']==(5 if favorable else -7)
                    checks.append(h+str(side)+('利確' if favorable else '損切'))
            r=route(tmp,[0,1,400,401],[3999.5,3999.5,4006,4005],[4000,4000,4006.5,4005.5],h)
            x=r.cell(s,1,1,5);assert x['unknown'] and x['label']=='C' and x['known_until']==s+1
            checks.append(h+'欠測前未知')
            r=route(tmp,[0,1,2,400],[3999.5,3999.5,4006,4005],[4000,4000,4006.5,4005.5],h)
            x=r.cell(s,1,1,5);assert not x['unknown'] and x['label']=='F';checks.append(h+'後の欠測で既決済を落とさない')
            r=route(tmp,[0,30,31],[3999.5]*3,[4000]*3,h);assert r.cell(s,1,1,5)['entry_time']==s+30
            r=route(tmp,[0,31,32],[3999.5]*3,[4000]*3,h);assert r.cell(s,1,1,5) is None
            checks.append(h+'取得TTL両端')
            # ----------------------------------------
            # 期限の時点での触れは期限決済より先に扱う。
            deadline=int(f-s if h=='SESSION' else 1+D.HORIZONS[h]);b=[3999.5]*len(seconds);a=[4000.0]*len(seconds)
            b[deadline]=4005;a[deadline]=4005.5
            r=route(tmp,seconds,b,a,h);x=r.cell(s,1,1,5)
            assert x['exit_time']==s+deadline and x['reason']=='IFD利確';checks.append(h+'期限同時TP')
            b[deadline]=3999.5;a[deadline]=4000;b[deadline+1]=4005;a[deadline+1]=4005.5
            r=route(tmp,seconds,b,a,h);x=r.cell(s,1,1,5)
            assert x['label']=='N' and x['reason']=='期限';checks.append(h+'期限後の値動きはTP判定へ入れない')
    return {'成功':True,'確認':checks,'件数':len(checks),'SourceSHA':D.M.sha(Path(__file__)),'接続SHA':D.M.sha(Path(D.__file__))}


# ----------------------------------------
if __name__=='__main__':
    result=run();D.M.save(Path(__file__).parent/'人工確認.json',result);print(json.dumps(result,ensure_ascii=False))
