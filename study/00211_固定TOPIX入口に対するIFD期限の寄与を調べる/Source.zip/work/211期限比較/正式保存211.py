"""固定金融・必要Source・期待対照を恒久保存する。"""
from pathlib import Path
import hashlib
import zipfile
import 実行211 as R


# ----------------------------------------
def main() -> None:
    """
    機能: 金融九正本と小規模な実行・監査・再現Sourceを重複原板なしで保存する。
    引数: なし。
    返り値: None。条件や金融Sourceは変えない。
    """
    R.verify_seal();assert R.read(R.STUDY/'監査/独立金融確認.json.gz')['成功']
    for path in sorted((R.HERE/'金融正本').glob('*.json.gz')):
        target=R.STUDY/'金融正本'/path.name;target.parent.mkdir(parents=True,exist_ok=True)
        if target.exists():assert target.read_bytes()==path.read_bytes()
        else:target.write_bytes(path.read_bytes())
    for name in ('全9口座安定性.json.gz','全9口座短表.json','金融完了.json'):
        path=R.HERE/name;target=R.STUDY/name
        if target.exists():assert target.read_bytes()==path.read_bytes()
        else:target.write_bytes(path.read_bytes())
    paths=R.source_paths()+[R.HERE/'人工確認.json',R.HERE/'独立確認211.py',R.HERE/'差分診断211.py',R.HERE/'共通取得を補足211.py',
        R.HERE/'再現211.py',Path(__file__),R.ROOT/'work/183損失安定性/TOPIXを独立検算する.py',
        R.ROOT/'work/183損失安定性/新候補の集計を独立検査する.py',*R.PARENTS[:2]]
    paths=sorted(set(paths),key=lambda p:p.relative_to(R.ROOT).as_posix());archive=R.STUDY/'Source.zip'
    assert not archive.exists()
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for path in paths:
            info=zipfile.ZipInfo(path.relative_to(R.ROOT).as_posix(),date_time=(2026,11,18,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(info,path.read_bytes())
    index={'ZIP':R.ref(archive),'資源':[R.ref(p) for p in paths],'説明':'金融前Sourceと事後監査/再現Sourceを区別。前者は条件.jsonのSourceに直接列挙。旧H60期待2packは再現に必要な小参照として格納。原板・純入力は既存inputsを参照。'}
    R.save(R.STUDY/'Source索引.json',index)
    with zipfile.ZipFile(archive) as z:
        for row in index['資源']:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
    R.save(R.STUDY/'監査/Source展開確認.json',{'成功':True,'資源数':len(paths),'ZIP':R.ref(archive),'全内容SHA同体':True})
    print({'Source資源':len(paths),'ZIP容量':archive.stat().st_size})


# ----------------------------------------
if __name__=='__main__':main()
