"""固定TOPIX金融部の取得・返済条件を保ち、保有期限だけを明示する。"""
from pathlib import Path
from functools import partial
from types import FunctionType, SimpleNamespace
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'scripts/TOPIX入口研究'))
import 共通金融 as G
M=G.M
F=G.F
HORIZONS={'H60':3600,'H120':7200,'SESSION':None}


# ----------------------------------------
class Route(M.Route):
    """既存原順索引を再用する期限指定付きの単純IFD。"""

    def __init__(self,entry: dict,horizon: str='H60') -> None:
        """
        機能: 固定原順索引を初期化し、事前指定された期限を保持する。
        引数: entry(dict)は原順入力、horizon(str)はH60/H120/SESSION。
        返り値: None。旧Routeや共通moduleは変更しない。
        """
        assert horizon in HORIZONS
        super().__init__(entry)
        self.horizon=horizon

    # ----------------------------------------
    def cell(self,q0: float,line: int,side: int,width: float) -> dict|None:
        """
        機能: 固定183の取得・TP・SL・欠測処理を保ち期限だけを指定する。
        引数: q0(float)は要求秒、line(int)は要求原行、side(int)は実側、width(float)は固定幅。
        返り値: dict|Noneは一取得の結果又はTTL失効。費用は固定金融部で別計算。
        """
        i=int(np.searchsorted(self.t,q0+1));limit=min(q0+30,self.force)
        if i>=len(self.t) or self.t[i]>limit or self.t[i]>=self.force:return None
        opened=float(self.t[i]);price=float(self.ask[i] if side==1 else self.bid[i]);mark=self.bid if side==1 else self.ask
        seconds=HORIZONS[self.horizon]
        deadline=self.force if seconds is None else min(opened+seconds,self.force)
        last=int(np.searchsorted(self.t,deadline,side='right'))
        tree=self.trees[0 if side==1 else 1]
        touch=tree.first(i,last,price-width,price+width)
        reason='期限';j=None;target=deadline;label='N';exit_price=None
        if touch is not None:
            favorable=side*(mark[touch]-price)>=width;label='F' if favorable else 'A'
            if favorable:
                reason='IFD利確';j=touch;target=float(self.t[touch]);exit_price=price+side*width
            else:
                reason='IFD損切';target=float(self.t[touch]);j=int(np.searchsorted(self.t,target+1))
        else:j=int(np.searchsorted(self.t,target+1))
        maxfill=min(target+30,self.end)
        valid=j<len(self.t) and self.t[j]<=maxfill
        if valid and exit_price is None:exit_price=float(mark[j])
        stop_index=j if valid else min(int(np.searchsorted(self.t,maxfill)),len(self.t)-1)
        gaps=self.gaps[(self.gaps>i)&(self.gaps<=stop_index)]
        unknown=not valid or bool(len(gaps))
        if len(gaps):known_until=float(self.t[gaps[0]-1]);why='正常板300秒超空白'
        elif not valid:
            last_known=max(i,min(int(np.searchsorted(self.t,maxfill,side='right'))-1,len(self.t)-1))
            known_until=float(self.t[last_known]);why='返済時計不足'
        else:known_until=float(self.t[j]);why=None
        if unknown and touch is not None and len(gaps) and gaps[0]<=touch:label='C'
        elif unknown and touch is None:label='C'
        return {'session':self.session,'side':side,'request_time':q0,'request_line':line,'entry_time':opened,'entry_line':int(self.line[i]),'entry_price':price,
          'exit_time':None if unknown else float(self.t[j]),'exit_line':None if unknown else int(self.line[j]),'exit_price':None if unknown else exit_price,
          'width':width,'label':label,'reason':reason,'unknown':unknown,'unknown_reason':why,'known_until':min(max(known_until,opened),self.end),
          'gross_pt':None if unknown else side*(exit_price-price),'band':M.band(q0,self.session)}


# ----------------------------------------
def replay(rows: list,identifiers: list[str],resources: list,horizon: str) -> list:
    """
    機能: 共通replayのコードを変更せず、独立globalsでRouteの期限だけを渡す。
    引数: rows(list)は固定純出生、identifiers(list[str])は三母体、resources(list)は83場、horizon(str)は期限。
    返り値: list[dict]は三口座。元module・関数globalsへの書込みはしない。
    """
    original_route=M.Route
    original_module=G.replay.__globals__['M']
    environment=dict(G.replay.__globals__)
    environment['M']=SimpleNamespace(Route=partial(Route,horizon=horizon))
    run=FunctionType(G.replay.__code__,environment,G.replay.__name__,G.replay.__defaults__,G.replay.__closure__)
    result=run(rows,identifiers,resources)
    assert M.Route is original_route and G.replay.__globals__['M'] is original_module
    return result
