"""三つの固定TOPIX入口を三期限で比較し、金融前封印と旧H60同体を必須にする。"""
from pathlib import Path
from collections import defaultdict
import argparse
import copy
import gzip
import hashlib
import importlib.metadata
import json
import platform
import sys
import 期限接続211 as D

ROOT=D.ROOT;HERE=Path(__file__).parent
STUDY=ROOT/'study/00211_固定TOPIX入口に対するIFD期限の寄与を調べる'
I208=ROOT/'inputs/00208_TOPIXの役割別見送りと構造反転の純入口'
I207=ROOT/'inputs/00207_TOPIXのVWAPと固定価格の純入口'
S208=ROOT/'study/00208_TOPIXの浅い押戻し逆張りを控え損失を比較する'
S207=ROOT/'study/00207_VWAPと固定価格の時間順入口を量支持で比較する'
MOTHERS=('C0_旧190','M208_主3','F207_QV_A25')
PARENTS=(
 ROOT/'work/208TOPIX/全83/金融/金融正本/TOPIX208_A0_旧維持_B0_旧維持_DayA25_H60.json.gz',
 ROOT/'work/208TOPIX/全83/金融/金融正本/TOPIX208_A1_浅押戻し逆張り見送り_B0_旧維持_DayA25_H60.json.gz',
 S207/'金融正本/TOPIX207_F_native回復失敗継続_QV_区間取引支持_A25.json.gz')


# ----------------------------------------
def read(path: Path) -> object:
    """
    機能: 固定JSONを読む。
    引数: path(Path)。
    返り値: object。
    """
    raw=path.read_bytes();return json.loads(gzip.decompress(raw) if path.suffix=='.gz' else raw)


# ----------------------------------------
def ref(path: Path) -> dict:
    """
    機能: リポジトリ相対位置と内容指紋を求める。
    引数: path(Path)。
    返り値: dict。
    """
    return {'path':path.resolve().relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':D.M.sha(path)}


# ----------------------------------------
def save(path: Path,value: object) -> None:
    """
    機能: 新規JSON又は再実行時同体のJSONを保存する。
    引数: path(Path)、value(object)。
    返り値: None。
    """
    raw=(json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode()
    if path.suffix=='.gz':raw=gzip.compress(raw,mtime=0)
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():assert path.read_bytes()==raw,path
    else:path.write_bytes(raw)


# ----------------------------------------
def digest(value: object) -> str:
    """
    機能: 並びを含むJSON値のSHA256を計算する。
    引数: value(object)。
    返り値: str。
    """
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()).hexdigest()


# ----------------------------------------
def pure() -> tuple[list,dict]:
    """
    機能: 正式純出生から三母体だけを選び、同じq0順へ外部結合する。
    引数: なし。
    返り値: tuple[list,dict]は方向・幅・originを不変にした純行と指紋票。未成立行も保持。
    """
    paths=[I208/'純入口.json.gz',I208/'追加二場純入口.json.gz',I207/'純入口.json.gz']
    old=read(paths[0])+read(paths[1]);other=read(paths[2]);groups=[(old,0),(old,3),(other,19)]
    union={};signals=[]
    for ci,(rows,index) in enumerate(groups):
        seen=set();n=0
        for row in rows:
            key=(row['session'],row['line']);assert key not in seen;seen.add(key)
            shell={'session':row['session'],'time':row['time'],'line':row['line'],'signals':[0,0,0],'widths':[None,None,None],'origins':[None,None,None]}
            target=union.setdefault(key,shell);assert target['time']==row['time']
            for field in ('signals','widths','origins'):target[field][ci]=row[field][index]
            n+=row['signals'][index]!=0
        signals.append(n)
    rows=sorted(union.values(),key=lambda r:(r['time'],r['line']))
    # ----------------------------------------
    # 旧190という名称の経済条件が207のC0とも同じことを、origin表示以外で照合する。
    mapping={(r['session'],r['line']):r for r in other};old_checks=0
    for row in old:
        match=mapping[(row['session'],row['line'])]
        assert row['signals'][0]==match['signals'][0]
        if row['signals'][0]:assert row['widths'][0]==match['widths'][0];old_checks+=1
    return rows,{'入力':[ref(p) for p in paths],'q0':len(rows),'成立':dict(zip(MOTHERS,signals)),
                 '射影SHA':digest(rows),'旧190と207C0の方向幅同体':old_checks,'origin':'旧190母体は208 index0の原表記を保持'}


# ----------------------------------------
def source_paths() -> list[Path]:
    """
    機能: 金融に実際に必要な研究Sourceを直接列挙する。
    引数: なし。
    返り値: list[Path]。動的到達木も含める。
    """
    return [Path(__file__),HERE/'期限接続211.py',HERE/'人工確認211.py',Path(D.G.__file__),Path(D.M.__file__),Path(D.F.__file__),
            Path(D.F.A.__file__),ROOT/'scripts/入口分析/分析.py']


# ----------------------------------------
def verify_seal() -> dict:
    """
    機能: 固定条件に列挙した全Source・純入力・期待対照・原順入力を再確認する。
    引数: なし。
    返り値: dictは条件正本。
    """
    condition=read(STUDY/'条件.json')
    for group in ('Source','純入力','旧条件','H60期待','原順入力'):
        for item in condition[group]:assert ref(ROOT/item['path'])==item,(group,item['path'])
    rows,proof=pure();assert proof==condition['純出生']
    assert read(HERE/'人工確認.json')['成功']
    return condition


# ----------------------------------------
def seal() -> None:
    """
    機能: 新期限の損益を読む前に全条件と資源を固定する。
    引数: なし。
    返り値: None。
    """
    resources=D.G.entries(True);rows,proof=pure();artificial=read(HERE/'人工確認.json');assert artificial['成功']
    assert artificial['接続SHA']==D.M.sha(HERE/'期限接続211.py')
    condition={'試行':211,'主':'H60','診断期限':['H120','SESSION'],'母体':list(MOTHERS),'規模':9,'全場':83,
      '情報区分':'全83既使用、固定母体の金融時計診断。未見検証でも新入口探索でもない。',
      '変更':'取得からのIFD期限のみ。H60=3600秒、H120=7200秒、SESSION=強制要求時刻。全てforceで打切り。',
      '不変':'純出生・実側・幅・費用・原順BBO代用・TP/SL遅延・予約保有一枠・未知時枠維持・終了時計。追尾なし。',
      '終了':'要求Day15:29/Night05:44、取得はforce未満、返済TTL30秒、正常BBOは15:30/05:45未満。',
      '費用':{'商品':'miniTOPIX1枚換算、ラージBBO代用','乗数':1000,'片道税込円':41.8,'片道滑りpt':0.25},
      '判断':'H60主を維持し最高額の期限へ交換しない。未知増加・損失頻度/深さ/連続/DD・両中央値・参加・期間を別評価。Fの少数支持を保持。',
      '取得集合':'期限変更後に全後続要求を再生。共通実取得の返済差と片側だけの実取得を分け、取り逃し利益は最適化しない。',
      'Source':[ref(p) for p in source_paths()],'純入力':proof['入力'],'純出生':proof,
      '旧条件':[ref(S208/'条件.json'),ref(S208/'追加二場と全83/条件固定.json'),ref(S207/'条件.json')],
      'H60期待':[ref(p) for p in PARENTS],'原順入力':[ref(Path(r['cache_absolute'])) for r in resources],
      '場順':[r['session'] for r in resources],'人工':ref(HERE/'人工確認.json'),
      '環境':{'Python':platform.python_version(),'numpy':importlib.metadata.version('numpy'),'tzdata':importlib.metadata.version('tzdata')},
      '金融前':True}
    save(STUDY/'条件.json',condition);save(STUDY/'人工確認.json',artificial)
    print(json.dumps({'封印':ref(STUDY/'条件.json'),'純出生':proof},ensure_ascii=False),flush=True)


# ----------------------------------------
def h60() -> None:
    """
    機能: 全純成立セルと三口座を旧H60実装・既存期待台帳へ照合する。
    引数: なし。
    返り値: None。新期限金融へ進む前の必須票を保存。
    """
    verify_seal();resources=D.G.entries(True);rows,_=pure();by=defaultdict(list)
    for row in rows:by[row['session']].append(row)
    cells=attributes=0;counts={}
    for entry in resources:
        a=D.M.Route(entry);b=D.Route(entry,'H60');seen=set()
        for row in by[entry['session']]:
            for ci,side in enumerate(row['signals']):
                if not side:continue
                key=(row['time'],row['line'],side,row['widths'][ci])
                if key in seen:continue
                seen.add(key);old=a.cell(*key);new=b.cell(*key);assert old==new,(entry['session'],key)
                cells+=1;attributes+=len(old) if old else 1
        counts[entry['session']]=len(seen)
    ids=[f'TOPIX211_{m}_H60' for m in MOTHERS];packs=D.replay(rows,ids,resources,'H60');proof=[]
    for pack,path in zip(packs,PARENTS,strict=True):
        expected=read(path);target=copy.deepcopy(pack);target['id']=expected['id'];assert target==expected,pack['id']
        save(HERE/'金融正本'/(pack['id']+'.json.gz'),pack)
        proof.append({'候補':pack['id'],'期待':ref(path),'全pack同体_IDのみ別':True,'取得':len(pack['ledger']['known'])})
    verify_seal()
    save(STUDY/'H60同体確認.json',{'成功':True,'条件':ref(STUDY/'条件.json'),'純成立セル':cells,'セル属性':attributes,'場別セル':counts,
        '三母体':proof,'元module変更なし':True,'全場順同体':83,'新H120_SESSION金融未実行':True})
    print(json.dumps({'H60同体':True,'セル':cells,'三母体':proof},ensure_ascii=False),flush=True)


# ----------------------------------------
def finance() -> None:
    """
    機能: 事前条件と旧H60同体を確認後に新六口座を計算し、全九口座を集計する。
    引数: なし。
    返り値: None。
    """
    verify_seal();proof=read(STUDY/'H60同体確認.json');assert proof['成功'] and proof['条件']==ref(STUDY/'条件.json')
    save(STUDY/'金融開始前固定.json',{'条件':ref(STUDY/'条件.json'),'H60確認':ref(STUDY/'H60同体確認.json'),'人工':ref(STUDY/'人工確認.json')})
    rows,_=pure();resources=D.G.entries(True);stats=[];brief=[]
    for horizon in D.HORIZONS:
        ids=[f'TOPIX211_{m}_{horizon}' for m in MOTHERS]
        packs=[read(HERE/'金融正本'/(i+'.json.gz')) for i in ids] if horizon=='H60' else D.replay(rows,ids,resources,horizon)
        for pack in packs:
            save(HERE/'金融正本'/(pack['id']+'.json.gz'),pack)
            state=D.F.A.evaluate_pack(pack,D.G.periods(pack));stats.append(state)
            brief.append({'id':pack['id'],'全83':{k:D.F.terse(v) for k,v in state['groups'].items()},
                          '期間':{p:{k:D.F.terse(v) for k,v in b.items()} for p,b in state['periods'].items()}})
        print(horizon+' 完了',flush=True)
    save(HERE/'全9口座安定性.json.gz',{'metrics':stats});save(HERE/'全9口座短表.json',{'rows':brief})
    verify_seal();save(HERE/'金融完了.json',{'成功':True,'条件':ref(STUDY/'条件.json'),'金融':[ref(p) for p in sorted((HERE/'金融正本').glob('*.json.gz'))],
                                          '統計':ref(HERE/'全9口座安定性.json.gz'),'元module変更なし':True})


# ----------------------------------------
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['seal','h60','finance']);args=parser.parse_args()
    {'seal':seal,'h60':h60,'finance':finance}[args.mode]()
