"""事後判明した推移依存だけを別保存し、初回固定票を変えず再現経路を閉じる。"""
from pathlib import Path
import argparse
import hashlib
import os
import shutil
import subprocess
import sys
import zipfile
import 再現211 as O

ROOT=O.ROOT;STUDY=O.STUDY;HERE=Path(__file__).parent
MISSING=('scripts/複合検証/再生.py','study/00001_MACDと方向条件の比較/再現.py')


# ----------------------------------------
def prepare() -> None:
    """
    機能: 推移依存二資源を旧208恒久Sourceと照合し、別ZIPへ保存する。
    引数: なし。
    返り値: None。金融前票を変更せず、事後保存であることを明示する。
    """
    prior=ROOT/'study/00208_TOPIXの浅い押戻し逆張りを控え損失を比較する/Source.zip';proof=[]
    with zipfile.ZipFile(prior) as z:
        for name in MISSING:
            raw=z.read(name);assert raw==(ROOT/name).read_bytes()
            proof.append({'path':name,'sha256':hashlib.sha256(raw).hexdigest(),'旧208ZIPと同体':True})
    paths=[ROOT/name for name in MISSING]+[Path(__file__)]
    archive=STUDY/'追加依存Source.zip';assert not archive.exists()
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for path in paths:
            info=zipfile.ZipInfo(path.relative_to(ROOT).as_posix(),date_time=(2026,11,18,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,path.read_bytes())
    O.save(STUDY/'追加依存Source索引.json',{'事後追加':True,'金融条件_Source変更なし':True,'ZIP':{'path':archive.relative_to(ROOT).as_posix(),'sha256':O.sha(archive),'bytes':archive.stat().st_size},
        '資源':[{'path':p.relative_to(ROOT).as_posix(),'sha256':O.sha(p),'bytes':p.stat().st_size} for p in paths],
        '既存保存証跡':{'path':prior.relative_to(ROOT).as_posix(),'sha256':O.sha(prior),'照合':proof},
        '不足':'211金融前の直接Source一覧に二つの推移依存がなかった。現値は以前の恒久208ZIPと同体だが、追加票を211の事前封印と呼ばない。'})


# ----------------------------------------
def restore(target: Path) -> None:
    """
    機能: 初回Sourceと追加依存を別rootへ展開して、固定金融の再現を実行する。
    引数: target(Path)は未使用のwork内復元先。
    返り値: None。初回失敗フォルダや固定Sourceは変更しない。
    """
    target=target.resolve();assert not target.exists() and target.is_relative_to((ROOT/'work').resolve());target.mkdir(parents=True)
    for archive_name,index_name in (('Source.zip','Source索引.json'),('追加依存Source.zip','追加依存Source索引.json')):
        archive=STUDY/archive_name;index=O.read(STUDY/index_name);assert O.sha(archive)==index['ZIP']['sha256']
        with zipfile.ZipFile(archive) as z:
            for row in index['資源']:
                output=target/row['path'];assert output.resolve().is_relative_to(target);output.parent.mkdir(parents=True,exist_ok=True)
                raw=z.read(row['path']);assert hashlib.sha256(raw).hexdigest()==row['sha256'];output.write_bytes(raw)
    condition=O.read(STUDY/'条件.json');refs=sum((condition[k] for k in ('Source','純入力','旧条件','H60期待','原順入力')),[])
    refs += [{'path':p.relative_to(ROOT).as_posix(),'sha256':O.sha(p)} for p in (
        ROOT/'inputs/TOPIX原順8列_20260921_20261116/台帳.json',ROOT/'inputs/00194_20261116夜と1117昼の固定適用入力/原順8列/入力台帳.json')]
    links=[];copied=[]
    for row in refs:
        src=ROOT/row['path'];dst=target/row['path'];assert O.sha(src)==row['sha256']
        if dst.exists():assert O.sha(dst)==row['sha256'];continue
        dst.parent.mkdir(parents=True,exist_ok=True)
        if row['path'].startswith('inputs/'):os.link(src,dst);links.append({'path':row['path'],'sha256':row['sha256']})
        else:
            assert not row['path'].startswith('work/'),('恒久ZIPへ不足',row['path']);shutil.copyfile(src,dst);copied.append(row['path'])
    for name in ('条件.json','人工確認.json','H60同体確認.json','金融開始前固定.json'):
        src=STUDY/name;dst=target/src.relative_to(ROOT);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
    # ----------------------------------------
    # orjsonは旧初回Sourceのimportに必要なバイナリ依存。正式Sourceへ複製せず既存環境を参照する。
    O.save(target/'復元入力票.json',{'元root':str(ROOT),'復元root':str(target),'hardlink入力':links,'複写正式物':copied,
        'SourceZIP_SHA':O.sha(STUDY/'Source.zip'),'追加依存ZIP_SHA':O.sha(STUDY/'追加依存Source.zip'),'原workの期待対照はZIPから復元':True})
    env=dict(os.environ);env['PYTHONPATH']=str(ROOT/'work/pythonlibs')
    subprocess.run([sys.executable,'-X','utf8',str(target/'work/211期限比較/追加依存と再現211.py'),'--child',str(ROOT)],cwd=target,env=env,check=True)
    proof=O.read(target/'復元確認.json');proof['追加依存ZIP_SHA']=O.sha(STUDY/'追加依存Source.zip');proof['事後依存補完']=True
    O.save(STUDY/'監査/別保存先の主金融再現.json',proof)
    print({'成功':True,'金融byte同体':len(proof['金融']),'統計byte同体':proof['統計byte同体'],'原work研究読取':proof['原work研究読取'],
           '入力SHA前後同体':len(proof['入力SHA前後同体'])})


# ----------------------------------------
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--prepare',action='store_true');parser.add_argument('--target',type=Path);parser.add_argument('--child',type=Path);args=parser.parse_args()
    if args.prepare:prepare()
    elif args.child:O.child(args.child)
    else:assert args.target is not None;restore(args.target)
