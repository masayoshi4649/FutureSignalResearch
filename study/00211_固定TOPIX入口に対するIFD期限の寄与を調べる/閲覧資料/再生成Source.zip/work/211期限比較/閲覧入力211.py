"""固定入口とIFD期限の9口座を同じ全83場の候補別CSVへ転記する。"""
from pathlib import Path
import importlib.util
import json
import math
import gzip
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
spec=importlib.util.spec_from_file_location('held199_for211',ROOT/'work/199候補別CSV/入力を作る.py')
H=importlib.util.module_from_spec(spec);spec.loader.exec_module(H)


def read(path: Path) -> object:
    """
    機能: 固定JSONを標準ライブラリだけで読む。
    引数: path(Path)。
    返り値: objectは解析値。
    """
    raw=path.read_bytes();return json.loads(gzip.decompress(raw) if path.suffix=='.gz' else raw)


# ----------------------------------------
def save(path: Path,value: object) -> None:
    """
    機能: 型付きCSV入力を新規保存し、再生成時は物理同体を要求する。
    引数: path(Path)、value(object)。
    返り値: None。
    """
    raw=(json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode()
    if path.exists():assert path.read_bytes()==raw,path
    else:path.write_bytes(raw)


# ----------------------------------------
def main() -> None:
    """
    機能: 正本の全9口座から未知を保った候補別の5表を生成する。
    引数: なし。
    返り値: None。候補の削除・成績による並べ替えを行わない。
    """
    headers=['候補','開始日又は期間','帯','利益既知寄与_円','損失絶対額既知寄与_円','収支確定_円',
             '累計収支確定_円','建玉回数','未知件数','保有時間率下限','収支既知寄与_円','累計既知寄与_円']
    names={'候補比較':'集計','デイ':'デイ','ナイト全体':'ナイト全体','ナイト_米前':'ナイト_米前','ナイト_米後':'ナイト_米後'}
    tables={name:{'headers':headers,'rows':[]} for name in names};mapping=[]
    for stat in read(HERE/'全9口座安定性.json.gz')['metrics']:
        identity=stat['id'];suffix=identity.split('211_')[1];mother,horizon=suffix.rsplit('_',1)
        code={'C0_旧190':'C0','M208_主3':'M3','F207_QV_A25':'F'}[mother]+'_'+horizon
        candidate='211:'+code;pack=read(HERE/'金融正本'/(identity+'.json.gz'))
        mapping.append({'候補':candidate,'id':identity,'商品':'TOPIX','母体':mother,'期限':horizon})
        scenes={s['scene']:s for s in pack['sessions']};assert len(scenes)==83
        for band in ('ALL','DAY','NIGHT','PRE','POST'):
            group=stat['groups'][band];t=group['trades'];h=group['holding'];s=group['sessions']
            full=t['known_net'] if t['unknown_count']==0 else None
            tables['候補比較']['rows'].append([candidate,'全83場',band,t['known_profit'],t['known_loss'],full,full,
                t['all_count'],t['unknown_count'],h['held_lower_ratio'],t['known_net'],t['known_net']])
            dest={'DAY':'デイ','NIGHT':'ナイト全体','PRE':'ナイト_米前','POST':'ナイト_米後'}.get(band)
            if dest is None:continue
            cumulative=0.;complete=True;held=profit=loss=0.
            for row in s['rows']:
                meta=scenes[row['scene']];ratio=H.held(meta,pack['positions'],band)
                duration=meta['end']-meta['start'] if band=='NIGHT' else sum(p['end']-p['start'] for p in meta['phases'] if p['name']==band)
                held+=ratio*duration;profit+=row['known_profit'];loss+=row['known_loss']
                cumulative+=row['known_net'];complete=complete and row['complete']
                tables[dest]['rows'].append([candidate,row['scene'][:10],band,row['known_profit'],row['known_loss'],
                    row['all_net'],cumulative if complete else None,row['all_count'],row['unknown_count'],ratio,row['known_net'],cumulative])
            assert len(s['rows'])==(42 if band=='DAY' else 41)
            assert math.isclose(held,h['held_lower_seconds'],abs_tol=1e-7)
            assert math.isclose(profit,t['known_profit'],abs_tol=1e-7) and math.isclose(loss,t['known_loss'],abs_tol=1e-7)
    assert len(mapping)==9==len({r['候補'] for r in mapping})
    save(HERE/'閲覧入力.json',{'tableNames':names,'tables':tables,'候補対応':mapping,'全83既使用':True})
    print(json.dumps({'候補':9,'CSV予定':45,'全場と未知を保持':True},ensure_ascii=False))


# ----------------------------------------
if __name__=='__main__':main()
