"""211の候補別CSVと版8の全尺度表を恒久保存する。"""
from pathlib import Path
import csv
import hashlib
import io
import json
import math
import re
import shutil
import zipfile
from 閲覧入力211 import read,save,ROOT,HERE

TRIAL=ROOT/'study/00211_固定TOPIX入口に対するIFD期限の寄与を調べる'
OUT=ROOT/'outputs/00211_固定入口とIFD期限の比較'


def write(path: Path,text: str) -> None:
    """
    機能: 日本語の説明をUTF-8で保存する。
    引数: path(Path)、text(str)。
    返り値: None。
    """
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(text,encoding='utf-8')


# ----------------------------------------
def verify() -> dict:
    """
    機能: 候補別45CSVの全セルと未知・累計を再読確認する。
    引数: なし。
    返り値: dictは再読票。
    """
    data=read(HERE/'閲覧入力.json');proof=read(ROOT/'work/211CSV検査/作成確認.json');cells=unknown=0
    for item in proof['files']:
        raw=(OUT/item['相対path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==item['sha256']
        actual=list(csv.reader(io.StringIO(raw.decode('utf-8-sig'))));table=data['tables'][item['元表']]
        expected=[table['headers']]+[r for r in table['rows'] if r[0]==item['候補']]
        assert len(actual)==len(expected)
        for a,b in zip(actual,expected,strict=True):
            assert len(a)==len(b)
            for x,y in zip(a,b,strict=True):
                cells+=1
                if y is None:assert x=='';unknown+=1
                elif isinstance(y,(int,float)):assert math.isclose(float(x),y,abs_tol=1e-7)
                else:assert x==y
        if item['元表']=='候補比較':continue
        assert len(actual)==(43 if item['元表']=='デイ' else 42)
        cumulative=0.;complete=True
        for row in actual[1:]:
            assert math.isclose(float(row[3])-float(row[4]),float(row[10]),abs_tol=1e-7)
            cumulative+=float(row[10]);complete=complete and int(row[8])==0
            assert math.isclose(cumulative,float(row[11]),abs_tol=1e-7)
            if complete:assert math.isclose(cumulative,float(row[6]),abs_tol=1e-7)
            else:assert row[6]==''
    assert len(proof['files'])==45 and cells==18900 and unknown>0
    return {**proof,'全セル再読':cells,'未知空欄':unknown,'全場累計一致':True}


# ----------------------------------------
def settings() -> None:
    """
    機能: 母体の有効条件とIFD時計を版8の567セルへ整理する。
    引数: なし。
    返り値: None。208のB反転や207のT/Rを今回の有効枝に含めない。
    """
    uses={
        'I01':{5:'S0旧5EMA/A近傍',6:'S0旧15/F中期8・21並び＋傾き',7:'A30並び・傾き・価格'},
        'I02':{5:'A[-.75,.5]ATR5/F源[.5,2]ATR5'},'I03':{5:'S0旧MACD/量不明補完'},
        'I04':{5:'S0旧RSI/A元側RSI<65'},'I05':{5:'A元側BBz<1'},
        'I08':{5:'S0旧DI・ADX',6:'S0旧DI'},'I09':{5:'S0 DayA25/F源ATR固定・発火幅A25'},
        'I12':{2:'F源native固定/保持区間Δ代金÷Δ量'},
        'C01':{5:'S0旧複合'},'C04':{5:'S0旧方向・強さ',6:'S0旧背景'},
        'C05':{2:'F固定nativeへの試行拒否',3:'F回復→次足保持'},
        'C07':{3:'S0取得/F保持',5:'S0価格・動力',6:'S0/F背景',7:'A長期支持'},
        'P01':{3:'S0逆実体・進行/F回復保持・逆端侵入≤.1源ATR'},
        'P03':{2:'F源nativeとG固定',3:'F試行→回復→保持'},
        'P05':{2:'F当時Last距離・live',3:'S0/F進行'},
        'V01':{2:'F同epoch差分代金量・量速度≥.5',3:'S0旧相対量・不明補完'},
        'B01':{2:'S0/FラージBBO代用・F spread≤1.5pt'},
        'E01':{2:'S211親IFD幅固定・取得後最初の接触'},
        'E02':{2:'S211 H60主/H120/SESSION・単純IFD・終了15分前'}}
    template=ROOT/'docs/議論/手法と時間スケールの汎用表_版8.md'
    body=template.read_text(encoding='utf-8').split('## 設定明細（コピー後に記入）')[0]
    body=body.replace('# 手法と時間スケールの汎用表・版8','# 211 設定と結果・版8')
    body=body.replace('全セルは未設定・未検証。','S0/A/Fは固定母体の入口、S211はIFD期限だけの対照。')
    body=body.replace('](../technical-analysis/','](../../docs/technical-analysis/')
    body=body.replace('](逆行200ptより先に順行400ptへ届く入口.md)','](../../docs/議論/逆行200ptより先に順行400ptへ届く入口.md)')
    body=body.replace('[版7](手法と時間スケールの汎用表_版7.md)','[版7](../../docs/議論/手法と時間スケールの汎用表_版7.md)')
    lines=[];count=0
    for line in body.splitlines():
        p=[x.strip() for x in line.split('|')[1:-1]] if line.startswith('|') else []
        if len(p)==11 and re.fullmatch('[ICPVBEMX][0-9]{2}',p[0]):
            count+=1
            for j in range(2,11):p[j]=uses.get(p[0],{}).get(j,'未使用')
            line='| '+' | '.join(p)+' |'
        lines.append(line)
    assert count==63
    tail='''
## 固定条件と複合評価

S0は[208](../00208_TOPIXの浅い押戻し逆張りを控え損失を比較する/設定と結果.md)の旧190D4/N01。Aは同試行主3の浅い押戻し逆張り見送りだけで、Bの過熱失速反転は使わない。Fは[207](../00207_VWAPと固定価格の時間順入口を量支持で比較する/設定と結果.md)のnative回復失敗継続/QV/A25だけで、T/Rは使わない。C0/主3のDayは同じ。候補ごとの有効枝と閾値は親正本を参照し、表の全セルを全候補で同時使用する意味ではない。

S211は3母体×H60/H120/SESSIONの9口座。方向・純出生・幅・費用は固定。H60を主に保持し、延長2案は期限交絡の原因診断。末尾の強制要求時計を超えず、TP指値/SL遅延/期限返済・未知/一枠と全後続要求を再生。1pt1,000円・往復583.6円、ラージBBO代用、全83既使用。追尾・利益保護の新設は行わない。

期限延長のDay収支増には取得集合の入替えが大きく、赤字場や連続性との交換がある。Nightでは未知が増え、延長を一律の改善としない。[正本説明](README.md)・[候補別45CSV](../../outputs/00211_固定入口とIFD期限の比較/README.md)。保有期限60/120分をチャート60分足の利用と混同しない。

全63手法×9尺度=567セル。元表SHA256: '''+hashlib.sha256(template.read_bytes()).hexdigest()+'。\n'
    write(TRIAL/'設定と結果.md','\n'.join(lines)+'\n'+tail)


# ----------------------------------------
def main() -> None:
    """
    機能: 全9候補の閲覧資料と再生成Sourceを正式保存する。
    引数: なし。
    返り値: None。金融監査と採否説明は別担当の正本へ接続する。
    """
    proof=verify();save(TRIAL/'CSV確認.json',proof);settings()
    assets=TRIAL/'閲覧資料';assets.mkdir(exist_ok=True);shutil.copy2(HERE/'閲覧入力.json',assets/'型付き入力.json')
    stats={s['id']:s for s in read(HERE/'全9口座安定性.json.gz')['metrics']}
    lines=['# 固定TOPIX入口とIFD期限の候補別比較','',
        'C0=旧190、M3=208主3、F=207 F/QV/A25。各H60/H120/SESSIONを別候補にし、主H60を成績上位へ交換しない。全83既使用、mini TOPIX1枚・費用後の円。', '',
        '|候補|Day利益/損失|Day収支|Night利益/損失|Night既知収支|Night未知|',
        '|---|---:|---:|---:|---:|---:|']
    for m in read(HERE/'閲覧入力.json')['候補対応']:
        code=m['候補'].split(':')[1];folder='211_'+code;g=stats[m['id']]['groups'];d,n=g['DAY']['trades'],g['NIGHT']['trades']
        lines.append(f"|[{code}]({folder}/README.md)|{d['known_profit']:,.1f}/{d['known_loss']:,.1f}|{d['known_net']:,.1f}|{n['known_profit']:,.1f}/{n['known_loss']:,.1f}|{n['known_net']:,.1f}|{n['unknown_count']}|")
        write(OUT/folder/'README.md',f'''# {m['候補']}

正本ID `{m['id']}`、母体{m['母体']}、期限{m['期限']}。[固定条件](../../../study/00211_固定TOPIX入口に対するIFD期限の寄与を調べる/条件.json)。

[集計](集計.csv) / [デイ](デイ.csv) / [ナイト全体](ナイト全体.csv) / [ナイト米国前](ナイト_米前.csv) / [ナイト米国後](ナイト_米後.csv)。全Day42/Night41、miniTOPIX1枚、費用後の円。1pt1,000円/往復費用583.6円、ラージBBO代用。期限変更後の全後続枠を再生し、独立取引の合算にしていない。

未知を含む場の確定収支と以後の確定累計は空欄、既知寄与は別列。未知を0円へ補完しない。実保有時間率下限は0〜1、終了15分前を除き、予約は保有に数えない。損益は新規の帯、保有は実区間の重なりへ帰属。Night全体と米前/後は重複合算しない。

[比較](../README.md)・[限界と再現](../../../study/00211_固定TOPIX入口に対するIFD期限の寄与を調べる/README.md)。H60を主とし、延長は原因診断。全83場既使用。
''')
    lines+=['','[仮説・全9結果・限界](../../study/00211_固定TOPIX入口に対するIFD期限の寄与を調べる/README.md)。Nightの既知増益を未知増加と相殺しない。Dayの増益も同じ建玉を長く持った効果と、取得集合が変わった効果を分ける。45CSV・18,900セル再読一致。']
    write(OUT/'README.md','\n'.join(lines)+'\n')
    sources=[HERE/'閲覧入力211.py',Path(__file__),ROOT/'work/199候補別CSV/入力を作る.py',ROOT/'scripts/損益CSV/候補別に出力する.mjs']
    with zipfile.ZipFile(assets/'再生成Source.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in sources:z.write(p,p.relative_to(ROOT).as_posix())
    save(assets/'Source索引.json',[{'path':p.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sources])
    print(json.dumps({'候補':9,'CSV':45,'全セル':proof['全セル再読'],'未知空欄':proof['未知空欄'],'汎用表':567},ensure_ascii=False))


# ----------------------------------------
if __name__=='__main__':main()
