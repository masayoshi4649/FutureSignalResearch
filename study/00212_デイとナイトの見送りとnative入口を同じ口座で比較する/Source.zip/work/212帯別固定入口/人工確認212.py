"""帯別の結合条件を売買鏡像・優先・同q0遮断の境界で確認する。"""
from pathlib import Path
import importlib.util,itertools
HERE=Path(__file__).parent
spec=importlib.util.spec_from_file_location('entry212',HERE/'入口212.py');M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)


def main() -> None:
    """
    機能: 純結合だけを人工境界で検査する。
    引数: なし。
    返り値: None。金融・実損益は読まない。
    """
    checked=0
    for old,f in itertools.product((-1,0,1),repeat=2):
        for a in set((0,old)):
            got=[M.night(old,a,f,m) for m in range(4)];expected=(old,a,old if old else f,a if old else f)
            assert tuple(x[0] for x in got)==expected;checked+=4
            mirror=[M.night(-old,-a,-f,m) for m in range(4)]
            assert all(x[0]==-y[0] and x[1]==y[1] for x,y in zip(got,mirror));checked+=8
            if old and not a:assert got[3][0]==0;checked+=1
    assert M.night(0,0,1,3)[0]==1 and M.night(0,0,0,3)[0]==0;checked+=2
    assert M.night(1,1,-1,3)[0]==1 and M.night(-1,-1,1,3)[0]==-1;checked+=2
    M.save(HERE/'人工確認.json',{'成功':True,'金融未使用':True,'SourceSHA':M.ref(HERE/'入口212.py')['sha256'],'属性':checked,'内容':['買売鏡像','旧優先','A棄却の同q0F迂回禁止','旧不成立時の固定F','次q0への繰越なし']});print('人工成功',checked)


if __name__=='__main__':main()
