"""212の親帯同体と損失優先選択・共通実取得・新枝支持を記録する。"""
from pathlib import Path
import importlib.util,json
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
spec=importlib.util.spec_from_file_location('post209',ROOT/'work/209固定参照/金融後確認209.py');Q=importlib.util.module_from_spec(spec);spec.loader.exec_module(Q)
spec=importlib.util.spec_from_file_location('parents212',HERE/'親期待212.py');R=importlib.util.module_from_spec(spec);spec.loader.exec_module(R)
P=Q.P;C=P.C


def main() -> None:
    """
    機能: 新8金融から親の限界帯同体、選択と期間差を固定する。
    引数: なし。
    返り値: None。独立原BBO監査は別担当の正本へ分離する。
    """
    cfg=P.read(HERE/'条件.json');expected=P.read(HERE/'金融前親期待.json.gz')['親'];stats=P.read(HERE/'金融/安定性.json.gz')['metrics'];packs=[P.read(HERE/'金融/金融正本'/(s['id']+'.json.gz')) for s in stats];checks=[]
    for ci,pack in enumerate(packs):
        di,ni=divmod(ci,4)
        for band,name in [('DAY','D1' if di else '旧')]+([] if ni==3 else [('NIGHT',('旧','A','F')[ni])]):
            assert R.project(pack,band)==expected[name]['帯'][band],(ci,band,name);checks.append({'候補':pack['id'],'帯':band,'親':expected[name]['id'],'同体':True})
    # ----------------------------------------
    ranks={}
    for period in ('前48','全80'):
        for band in ('DAY','NIGHT','ALL'):
            base=stats[0]['periods'][period][band];order=sorted(range(1,8),key=lambda i:(C.F.A.rank_key(stats[i]['periods'][period][band],base),packs[i]['id']))
            rows=[{'候補':cfg['候補'][i],'id':packs[i]['id'],'gate':C.F.A.gate(stats[i]['periods'][period][band],base)} for i in order];suitable=[r for r in rows if r['gate']['suitable']]
            ranks[period+'_'+band]={'選択':suitable[0] if suitable else None,'参考先頭':rows[0],'順位':rows}
    P.save(HERE/'固定選択.json',{'全83既使用':True,'同じ周辺帯は重複効果を数えない':True,'保守的対照':cfg['候補'][5],'順位':ranks})
    pairs={(0,i) for i in range(1,8)}|{(1,3),(2,3),(4,5),(4,6),(5,7),(6,7)}
    P.save(HERE/'実取得差分.json.gz',[Q.compare_pair(packs[a],packs[b]) for a,b in sorted(pairs)])
    short=[{'候補':cfg['候補'][i],'id':s['id'],'全83':{b:C.F.terse(g) for b,g in s['groups'].items()},'期間':{p:{b:C.F.terse(g) for b,g in gs.items()} for p,gs in s['periods'].items()}} for i,s in enumerate(stats)]
    P.save(HERE/'全8口座短表.json.gz',short)
    # ----------------------------------------
    support=[]
    for ci,pack in enumerate(packs):
        ledger=pack['ledger'];rows=[{k:v[i] for k,v in ledger.items()} for i,o in enumerate(ledger['origin']) if o=='ADD_V_native_QV_W15'];scenes=[s['scene'] for s in pack['sessions']]
        periods={'全83':scenes,'前48':scenes[:48],'後25':scenes[48:73],'追加7':scenes[73:80],'本日1':scenes[80:81],'追加2':scenes[81:]}
        support.append({'候補':pack['id'],'新F支持':{p:{**P.subtotal([r for r in rows if r['scene'] in names]),'取得場':len({r['scene'] for r in rows if r['scene'] in names})} for p,names in periods.items()},'新F実取得':rows})
    P.save(HERE/'F枝支持.json.gz',support);P.save(HERE/'親帯同体確認.json',{'成功':True,'同体':checks,'表記のみ除外':'originの旧幹呼称は209へ揃えた。その他の全ledger/sessions/positionsは同体。','新金融前親期待':R.M.ref(HERE/'金融前親期待.json.gz')})
    print(json.dumps({'親帯同体':len(checks),'前48全80選択':{k:v['選択'] for k,v in ranks.items()},'Night':[{k:r['全83']['NIGHT'][k] for k in ('取得','未知','利益','損失','既知収支','参加場','保有下限','場末DD既知寄与')} for r in short[:4]]},ensure_ascii=False))


if __name__=='__main__':main()
