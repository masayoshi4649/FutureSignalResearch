"""212の8口座・親帯同体・選択・原因を、既使用の組合せ発見として保存する。"""
from pathlib import Path
import gzip,hashlib,json,os,re,shutil,zipfile
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
TRIAL=ROOT/'study/00212_デイとナイトの見送りとnative入口を同じ口座で比較する'
PURE=ROOT/'inputs/00212_TOPIXの帯別固定入口の組合せ'


def read(path: Path) -> object:
    """
    機能: 固定JSONを読む。
    引数: path(Path)。
    返り値: object。
    """
    raw=path.read_bytes();return json.loads(gzip.decompress(raw) if path.suffix=='.gz' else raw)


def ref(path: Path) -> dict:
    """
    機能: 資源の相対位置と内容指紋を返す。
    引数: path(Path)。
    返り値: dict。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


def main() -> None:
    """
    機能: 全8正本と567セル、再現Source、支持と期間差を正式保存する。
    引数: なし。
    返り値: None。事前条件と既存親結果は不変更。
    """
    assert read(HERE/'親帯同体確認.json')['成功'];cfg=read(HERE/'条件.json');TRIAL.mkdir(parents=True,exist_ok=True)
    for name in ('条件.json','人工確認.json','純封印.json','純独立確認.json','金融前親期待.json.gz','親帯同体確認.json','固定選択.json','全8口座短表.json.gz','実取得差分.json.gz','F枝支持.json.gz'):
        shutil.copy2(HERE/name,TRIAL/name)
    shutil.copy2(HERE/'金融前設計.md',TRIAL/'金融前条件.md')
    for name in ('金融開始前固定.json','安定性.json.gz'):shutil.copy2(HERE/'金融'/name,TRIAL/name)
    (TRIAL/'金融正本').mkdir(exist_ok=True)
    for p in (HERE/'金融/金融正本').glob('*.json.gz'):shutil.copy2(p,TRIAL/'金融正本'/p.name)
    rows=read(HERE/'全8口座短表.json.gz');stats=read(HERE/'金融/安定性.json.gz')['metrics']
    table=['# 212 全8口座の結果','','全83場既使用。miniTOPIX1枚・費用後・円。未知がある金額は既知寄与。帯別順位では同じ周辺帯の重複を独立した支持にしない。','','|ID|帯|取得/未知|参加場|保有下限%|利益|損失|既知収支|建玉/場中央値下限|場末DD既知寄与|','|---|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    for i,row in enumerate(rows):
        for band in ('ALL','DAY','NIGHT','PRE','POST'):
            g=row['全83'][band];table.append(f"|{i} {row['候補']}|{band}|{g['取得']}/{g['未知']}|{g['参加場']}/{g['全場']}|{100*g['保有下限']:.2f}|{g['利益']:,.1f}|{g['損失']:,.1f}|{g['既知収支']:,.1f}|{g['建玉中央値下限']}/{g['場中央値下限']}|{g['場末DD既知寄与']:,.1f}|")
    (TRIAL/'全8結果.md').write_text('\n'.join(table)+'\n','utf-8')
    # ----------------------------------------
    body='''# 212 デイとナイトの見送りとnative入口を同じ口座で比較する

2026-11-18。**既存の部分的有望案を組み合わせると全口座の損失額と赤字回数を減らせたが、損失最少案とDD最少案は一致しなかった。** 新しい技術閾値は設けず、Day2×Night4の8口座を再生した。全83場は既使用の組合せ発見で、未見の安定採用ではない。

[全8結果](全8結果.md) / [設定と結果・版8](設定と結果.md) / [金融前条件](金融前条件.md) / [選択票](固定選択.json) / [原因・支持](原因診断.md) / [再現](再現.md)

## 何を組み合わせたか

Dayは旧190D4（D0）と210主3の長期矛盾見送り（D1）。Nightは旧190N01（N0）、208主3の浅押戻し逆張り見送り（NA）、209 ADD_V/W15のnative戻り失敗継続追加（NF）、両者併用（NAF）。旧が成立してAに棄却された同q0ではFも禁止。旧優先、元から旧が不成立のq0だけFを許容し、後へ繰り越さない。

保守的対照は5=D1+NA。6=D1+NF、7=D1+NAFはFの少支持を含む比較。全83・35,361 q0を同時計・同原行で接続。全場と未知を保持する。nativeは当場VWAPと限らず、起算・純特徴は[204](../00204_VWAPと価格構造の両指数入口/README.md)を継承した[209](../00209_固定参照への戻り失敗と旧入口の増分を比較する/README.md)の固定出生を再用した。

miniTOPIX1枚、1pt=1,000円、片道税込41.8円＋0.25pt、往復費用583.6円。ラージBBO代用。単純IFD H60、Day A25（当時ATR5×2.5を5〜25ptへ制限し0.25切上げ）、Night W15、保有予約合計1、開始待機なし、終了15分前全決済。未知決済では場末まで枠を保持する。

## 全口座83場

金額は未知を含む口座の確定収支ではなく既知寄与。4案とも80/83場で取得し、未知7、両中央値下限は正。

|候補|取得|利益|損失|既知収支|赤字取引|赤字場|保有下限|場末DD既知寄与|
|---|---:|---:|---:|---:|---:|---:|---:|---:|
'''
    for i,label in ((0,'0 旧'),(5,'5 D1+NA 保守的対照'),(6,'6 D1+NF'),(7,'7 D1+NAF')):
        g=stats[i]['groups']['ALL'];t=g['trades'];s=g['sessions'];body+=f"|{label}|{t['all_count']}|{t['known_profit']:,.1f}|{t['known_loss']:,.1f}|{t['known_net']:,.1f}|{t['negative_rate']['negative_count']}|{s['negative_rate']['negative_count']}|{g['holding']['held_lower_ratio']:.2%}|{g['path']['known_contribution']['max_drawdown']['amount']:,.1f}|\n"
    body+='''
7は旧から損失67,585.2円減・赤字取引181→174・赤字場27→25。6は損失50,501.6円減でDDも縮む。7のDDは旧より999.2円増えた。利益減だけで案を落とさず、損失総額・頻度と累計経路の違いを残す。

Day D1は42/42場209取得・未知0・保有53.94%、利益871,554円・損失800,276.4円・収支71,277.6円。Night NAFは38/41場173取得・未知7・保有28.78%、利益803,892.4円・損失517,770円・既知収支286,122.4円。未参加3Nightと未知7は解決していない。

前48/全80の既定順位ではDay D1だけが制約を満たす。Night/全体は未参加のためnull。Dayの同一4案のうちID順でD1+N0が記録されたのであり、Night N0が最良だったという意味ではない。保守的対照5と、事前順位の選択票と、全83の有望比較を交換しない。

## 支持と限界

Fは6/7とも純追加6 q0から同じ5取得/5Night。利益27,165.6円・損失5,083.6円・収支22,082円。新枝の支持は組合せで増えていない。Fを加えた口座差＋41,416.4円は旧入口の後続枠も含む。

NightのF追加効果は前48が−5,000円、後25が＋46,416.4円。全口座7対旧は前48＋9,834.4円・後25＋63,084.4円だが、Dayの改善と相殺した値でありFの前半悪化を隠さない。追加7/本日1/追加2は同体で効果再現例ではない。

人工190属性、全純別式1,838,772属性、第三者純1,885,993属性と人工180属性を検査。親14周辺帯はoriginの表示名以外の全ledger/sessions/positionsが一致。金融の別実装BBO・枠・費用・期間監査は正式の監査資料へ分離する。新しい閾値をこの結果から後付けしていない。
'''
    (TRIAL/'README.md').write_text(body,'utf-8')
    (TRIAL/'原因診断.md').write_text('''# 212 組合せの効果と限界

[共通・旧のみ・新のみ実取得](実取得差分.json.gz) / [F枝の実取得支持](F枝支持.json.gz) / [親14帯同体](親帯同体確認.json)。実現した取引間の差であり、未参加の仮想利益を機会損失にしていない。

Day/Nightは持ち越さず、限界帯の金融は親と同じになる。一方で累計口座経路は両帯の順序で変わる。7は損失最少でも全口座DD107,342.4円、6は100,426円で、この2案を単一の「最良」へまとめない。

全4主比較の最大DD区間は10/23Nightの頂点→10/29Dayの谷。6と7のこの区間の違いはAにより10/26Nightの旧売り＋6,916.4円がなくなる1件で、新たなF損失が発生した差ではない。7は全期間の損失をより削る一方、この窓では利益取引の見送りが谷を深める。

初期最小−28,501.6円（9/23Night）、最長水面下14場、最大DDからの回復11/4Dayは共通。両帯で別々にDDが減ることから、合算口座の連続損失まで改善したと推定しない。DDは場末既知実現寄与で、未知全件の確定経路や保有中時価DDではない。

A+Fの新F5取得はFのみと同体。NightでF→AFは共通171取得・既知298,789.6円、Fだけ6取得−20,501.6円、AFだけ2取得−12,667.2円となり口座差＋7,834.4円。旧要求の棄却だけでなく枠解放後の取得を含む。AF固有の新F優位を主張しない。

前48/後25のNight F効果−5,000/＋46,416.4円は保守的A対照へ追加しても同じ。全口座の前半改善はDay見送りとの組合せで、F単体の安定性が増した根拠ではない。追加7・本日1・追加2の金融同体は効果を新データで再現した事例に数えない。
''','utf-8')
    # ----------------------------------------
    template=ROOT/'docs/議論/手法と時間スケールの汎用表_版8.md';body=template.read_text('utf-8').split('## 設定明細')[0].replace('# 手法と時間スケールの汎用表・版8','# 212 設定と結果（版8）').replace('全セルは未設定・未検証。','親で使用した役割を固定再用する。').replace('未設定・未検証','未使用')
    used={'I01':{3:'旧/NA EMA8/21',4:'NA/NF 並び傾き',5:'D1/NA 並び傾き'},'I02':{3:'D1差0.4ATR/NA距離'},'I03':{3:'旧MACD'},'I04':{3:'旧/NA実側RSI<65'},'I05':{3:'NA源側BBz<1'},'I08':{3:'D1 ADX<18/旧DI'},'I09':{3:'旧A25/NF源固定ATR'},'I12':{0:'NF native固定/区間取引VWAP'},'C01':{3:'旧複合',4:'NA/NF中期'},'P01':{1:'NF実体と保持'},'P05':{1:'NF進行'},'P10':{1:'NF固定源回復保持'},'V01':{0:'NF区間数量速度>=0.5倍',1:'旧1分量条件'},'B01':{0:'実BBO/Last/旧方向'},'E01':{0:'同幅IFD'},'E02':{0:'H60/終了15分前/単一枠'}}
    lines=[];count=0
    for line in body.splitlines():
        cells=[c.strip() for c in line.strip().strip('|').split('|')] if line.startswith('|') else []
        if len(cells)==11 and re.fullmatch(r'[A-Z][0-9]{2}',cells[0]):
            count+=1
            for i in range(9):cells[i+2]=used.get(cells[0],{}).get(i,'未使用')
            line='| '+' | '.join(cells)+' |'
        lines.append(line)
    assert count==63
    body=re.sub(r'\]\(([^)]+)\)',lambda m:']('+os.path.relpath((template.parent/m.group(1)).resolve(),TRIAL).replace('\\','/')+')','\n'.join(lines)+'\n')
    body+='''
## 設定明細と複合評価

D1は旧D4成立時ADX5<18かつEMA8/21差<0.4ATR5で、公表済み30分の並びとEMA21傾きが源側と逆の群だけ見送り。30分未知・混在を逆向きへまとめない。[210固定条件](../00210_TOPIXデイの長期矛盾と押戻し成熟を比較する/条件.json)の主3。

NAは旧実側が元方向と反対で、30/15分並びと21傾きが元方向支持、価格が30EMA21元側、元側5EMA8距離[-0.75,+0.5]ATR5、元側RSI<65・BBz<1だけ見送り。[208固定条件](../00208_TOPIXの浅い押戻し逆張りを控え損失を比較する/条件.json)の主3。

NFは[209条件](../00209_固定参照への戻り失敗と旧入口の増分を比較する/金融前条件.md)のV/QV/W15源→接近→再開→保持。中期方向・源固定native/ATR/600秒・別足の実体/進行と保持・区間取引VWAP/量速度を再用。NAFは旧元成立の見送りをFで迂回せず、旧元不成立時だけNF出生を採る。

単純IFDの幅・H60・費用・単一枠・末尾15分は親と同じ。入口時計を5分へ制限していない。原板・1分公表・上位足の尺度は親で封印済み。新しい技術閾値なしで8口座の組合せと枠を評価した。指標単独効果や未見性能ではない。[結果](全8結果.md)・[選択](固定選択.json)。
'''
    (TRIAL/'設定と結果.md').write_text(body,'utf-8')
    # ----------------------------------------
    (TRIAL/'再現.md').write_text('''# 212の再現

Python3.14.3・NumPy2.5.4。Source ZIPを元の相対位置へ復元し、恒久純入力を参照する。原板を複製せず、全83の親純入力と原順8列を再用する。親は210index0/3、208index0/3、209index0/6/28。新金融前に全推移的動的依存を直接指紋記録した。

```powershell
& 'work/複合テクニカル学習環境/Scripts/python.exe' -X utf8 'work/212帯別固定入口/人工確認212.py'
& 'work/複合テクニカル学習環境/Scripts/python.exe' -X utf8 'work/212帯別固定入口/入口212.py'
& 'work/複合テクニカル学習環境/Scripts/python.exe' -X utf8 'work/212帯別固定入口/独立純212.py'
& 'work/複合テクニカル学習環境/Scripts/python.exe' -X utf8 'scripts/TOPIX入口研究/共通金融.py' --condition 'work/212帯別固定入口/条件.json' --births 'inputs/00212_TOPIXの帯別固定入口の組合せ/純入口.json.gz' --output 'work/212帯別固定入口/金融再現' --id-template 'TOPIX212_{name}' --extra --expected-dir 'study/00212_デイとナイトの見送りとnative入口を同じ口座で比較する/金融正本' --expected-metrics 'study/00212_デイとナイトの見送りとnative入口を同じ口座で比較する/安定性.json.gz'
```

出力先は新規とし、固定条件と旧成果物を異なる内容で上書きしない。[条件](条件.json)・[純封印](純封印.json)・[Source索引](Source索引.json)。金融後212.pyはwork/212帯別固定入口/金融を読むので再現金融を同位置へ復元する。親期待212.pyの再実行は不要。金融前に固定した[親期待](金融前親期待.json.gz)を同名でwork/212帯別固定入口へ復元すれば、親work金融を複製せず14帯同体を検査できる。

別担当の原BBO線形走査・枠・費用・期間は監査資料へ分離する。生産Routeを用いた同体再計算と混同しない。
''','utf-8')
    (PURE/'README.md').write_text('# 212 帯別固定入口の純結合\n\n全83場・35,361 q0・8候補を新金融前に封印。親210/208/209の同q0・同原行を使い、未来側近傍や補間をしない。見送りをFが迂回しない。[研究正本](../../study/00212_デイとナイトの見送りとnative入口を同じ口座で比較する/README.md)。\n','utf-8')
    (PURE/'入力台帳.json').write_text(json.dumps({'試行':212,'純':ref(PURE/'純入口.json.gz'),'条件':ref(TRIAL/'条件.json')},ensure_ascii=False,indent=2)+'\n','utf-8')
    sources=set(ROOT/p for p in cfg['Source'])|set(HERE.glob('*.py'))|{HERE/'金融前親期待.json.gz'}
    sources.update(ROOT/r['path'] for r in read(ROOT/'study/00209_固定参照への戻り失敗と旧入口の増分を比較する/Source索引.json'))
    with zipfile.ZipFile(TRIAL/'Source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(sources):z.write(p,p.relative_to(ROOT).as_posix())
    (TRIAL/'Source索引.json').write_text(json.dumps([ref(p) for p in sorted(sources)],ensure_ascii=False,indent=2)+'\n','utf-8')
    files=[p for p in sorted(TRIAL.rglob('*')) if p.is_file() and p.name!='保存索引.json']+list(sorted(PURE.glob('*')))
    (TRIAL/'保存索引.json').write_text(json.dumps({'Source固定不変':all(ref(ROOT/p)['sha256']==sha for p,sha in cfg['Source'].items()),'汎用セル':567,'正本':[ref(p) for p in files]},ensure_ascii=False,indent=2)+'\n','utf-8')
    print('正式212',len(files),'Source',len(sources),'567セル')


if __name__=='__main__':main()
