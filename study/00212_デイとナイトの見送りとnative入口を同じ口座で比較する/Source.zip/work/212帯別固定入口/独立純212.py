"""生産関数を呼ばず、全q08口座の親選択と幅・同体を直接照合する。"""
from pathlib import Path
import gzip,hashlib,json
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent


def read(path: Path) -> object:
    """
    機能: 固定JSONを読む。
    引数: path(Path)。
    返り値: object。
    """
    raw=path.read_bytes();return json.loads(gzip.decompress(raw) if path.suffix=='.gz' else raw)


def main() -> None:
    """
    機能: 親全信号との同体と結合8信号を独立な直式で検算する。
    引数: なし。
    返り値: None。金融や生成実装はimportしない。
    """
    cfg=read(HERE/'条件.json');assert all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==sha for p,sha in cfg['Source'].items())
    for r in cfg['入力']:assert hashlib.sha256((ROOT/r['path']).read_bytes()).hexdigest()==r['sha256']
    d=read(ROOT/'inputs/00210_TOPIXデイの背景矛盾と成熟待ちの純入口/純入口.json.gz');a=read(ROOT/'inputs/00208_TOPIXの役割別見送りと構造反転の純入口/純入口.json.gz')+read(ROOT/'inputs/00208_TOPIXの役割別見送りと構造反転の純入口/追加二場純入口.json.gz');f=read(ROOT/'inputs/00209_TOPIXの固定参照と戻り失敗の純入口/純入口.json.gz')
    out=read(ROOT/'inputs/00212_TOPIXの帯別固定入口の組合せ/純入口.json.gz');assert len(out)==len(d)==len(a)==len(f)==35361;checks=0
    for row,dr,ar,fr in zip(out,d,a,f,strict=True):
        assert all(row[k]==dr[k]==ar[k]==fr[k] for k in ('session','time','line','band'));checks+=12
        for ci in range(8):
            di,ni=divmod(ci,4);old=fr['signals'][0]
            if row['band']=='DAY':parent=dr;index=3 if di else 0;side=parent['signals'][index];width=parent['widths'][index];origin=fr['origins'][0];branch='D1' if di else '旧'
            elif ni==0:side=old;width=fr['widths'][0];origin=fr['origins'][0];branch='旧'
            elif ni==1 or ni==3 and old:side=ar['signals'][3];width=ar['widths'][3];origin=fr['origins'][0];branch='A'
            elif ni==2 and old:side=old;width=fr['widths'][0];origin=fr['origins'][0];branch='旧'
            else:side=fr['signals'][6];width=fr['widths'][6];origin=fr['origins'][28];branch='F'
            assert (row['signals'][ci],row['widths'][ci],row['origins'][ci],row['parent_branch'][ci])==(side,width,origin,branch);checks+=4
            if row['band']!='DAY' and ni==2:assert side==fr['signals'][28] and (not side or width==fr['widths'][28]);checks+=2
            if row['band']=='DAY' and not di or row['band']!='DAY' and ni==0:assert side==old and (not side or width==fr['widths'][0]);checks+=2
    result={'成功':True,'金融未使用':True,'生産importなし':True,'全q0':len(out),'照合属性':checks,'SourceSHA':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'純SHA':cfg['純入口SHA'],'範囲':'全8信号/幅/origin/親枝、NFと20928・Day0/Night0旧幹同体。親の源状態と特徴は再計算しない。'}
    path=HERE/'純独立確認.json';raw=(json.dumps(result,ensure_ascii=False,separators=(',',':'))+'\n').encode();assert not path.exists();path.write_bytes(raw);print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':main()
