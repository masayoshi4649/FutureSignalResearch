"""固定済みDay2案とNight4案を当時q0で結合し、金融前に封印する。"""
from pathlib import Path
from collections import Counter,defaultdict
import gzip,hashlib,json
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
PURE=ROOT/'inputs/00212_TOPIXの帯別固定入口の組合せ'
NAMES=tuple(f'{d}_{n}' for d in ('D0旧Day','D1長期矛盾見送り') for n in ('N0旧Night','NA浅押戻し見送り','NF_native追加','NAF見送りとnative追加'))
PARENTS={'D':ROOT/'inputs/00210_TOPIXデイの背景矛盾と成熟待ちの純入口/純入口.json.gz','A':ROOT/'inputs/00208_TOPIXの役割別見送りと構造反転の純入口/純入口.json.gz','A2':ROOT/'inputs/00208_TOPIXの役割別見送りと構造反転の純入口/追加二場純入口.json.gz','F':ROOT/'inputs/00209_TOPIXの固定参照と戻り失敗の純入口/純入口.json.gz'}
CFG={'D':ROOT/'study/00210_TOPIXデイの長期矛盾と押戻し成熟を比較する/条件.json','A':ROOT/'study/00208_TOPIXの浅い押戻し逆張りを控え損失を比較する/条件.json','F':ROOT/'study/00209_固定参照への戻り失敗と旧入口の増分を比較する/条件.json'}


def read(path: Path) -> object:
    """
    機能: 純JSONと固定票を読む。
    引数: path(Path)。
    返り値: object。
    """
    raw=path.read_bytes();return json.loads(gzip.decompress(raw) if path.suffix=='.gz' else raw)


def ref(path: Path) -> dict:
    """
    機能: 入力とSourceの内容指紋を返す。
    引数: path(Path)。
    返り値: dict。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


def save(path: Path,value: object) -> None:
    """
    機能: JSONを新規保存し、異なる上書きを拒否する。
    引数: path(Path),value(object)。
    返り値: None。
    """
    raw=(json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode('utf-8');data=gzip.compress(raw,mtime=0) if path.suffix=='.gz' else raw
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():assert path.read_bytes()==data,path
    else:path.write_bytes(data)


def night(old: int,after_a: int,f: int,mode: int) -> tuple:
    """
    機能: 旧優先とA見送り迂回禁止を保って同q0のNightを選ぶ。
    引数: old/after_a/f(int)は鏡像符号、mode(int)は0旧/1A/2F/3AF。
    返り値: tuple[int,str]は実側と純出生の親。状態を持たず繰越しない。
    """
    assert old in (-1,0,1) and after_a in (0,old) and f in (-1,0,1)
    if mode==0:return old,'旧'
    if mode==1:return after_a,'A'
    if mode==2:return (old,'旧') if old else (f,'F')
    assert mode==3
    if old:return (after_a,'A')
    return f,'F'


def inputs() -> tuple:
    """
    機能: 三つの固定純入口を同原行・同時計で読み、旧幹一致を検査する。
    引数: なし。
    返り値: tupleはDay/夜A/Fの全83純配列と参照票。
    """
    d,a,f=read(PARENTS['D']),read(PARENTS['A'])+read(PARENTS['A2']),read(PARENTS['F'])
    assert len(d)==len(a)==len(f)==35361
    cfgs={k:read(p) for k,p in CFG.items()}
    assert ref(PARENTS['D'])['sha256']==cfgs['D']['純入口SHA'] and ref(PARENTS['F'])['sha256']==cfgs['F']['純入口SHA']
    assert ref(PARENTS['A'])['sha256']==cfgs['D']['入力'][PARENTS['A'].relative_to(ROOT).as_posix()]
    assert ref(PARENTS['A2'])['sha256']==cfgs['D']['入力'][PARENTS['A2'].relative_to(ROOT).as_posix()]
    previous={};scenes=[]
    for dr,ar,fr in zip(d,a,f,strict=True):
        assert all((dr[k]==ar[k]==fr[k]) for k in ('session','time','line','band'))
        assert dr['signals'][0]==ar['signals'][0]==fr['signals'][0]
        if fr['signals'][0]:assert dr['widths'][0]==ar['widths'][0]==fr['widths'][0]
        assert dr['signals'][3] in (0,dr['signals'][0]) and ar['signals'][3] in (0,ar['signals'][0])
        scene=fr['session']
        if scene not in previous:scenes.append(scene)
        else:assert fr['time']>=previous[scene][0] and fr['line']>previous[scene][1]
        previous[scene]=(fr['time'],fr['line'])
    assert len(scenes)==83 and scenes[80:]==['2026-11-16_Day','2026-11-16_Night','2026-11-17_Day']
    return d,a,f,[ref(p) for p in [*PARENTS.values(),*CFG.values()]]


def prepare() -> None:
    """
    機能: 全8口座の純入口・Source・親指紋・条件を新金融前に保存する。
    引数: なし。
    返り値: None。金融ラベルを読まない。
    """
    proof=read(HERE/'人工確認.json');assert proof['成功'] and proof['SourceSHA']==ref(Path(__file__))['sha256']
    day,after_a,parents,refs=inputs();output=[];counts=defaultdict(Counter)
    for dr,ar,fr in zip(day,after_a,parents,strict=True):
        out={k:fr[k] for k in ('session','time','line','band')};out.update(signals=[],widths=[],origins=[],parent_branch=[])
        old=fr['signals'][0];raw_f=fr['signals'][6]
        for di in range(2):
            for ni in range(4):
                if fr['band']=='DAY':side=dr['signals'][3 if di else 0];parent='D1' if di else '旧';width=dr['widths'][3 if di else 0];origin=fr['origins'][0]
                else:
                    side,parent=night(old,ar['signals'][3],raw_f,ni);width=fr['widths'][6] if parent=='F' else ar['widths'][3] if parent=='A' else fr['widths'][0]
                    origin=fr['origins'][28] if parent=='F' else fr['origins'][0]
                out['signals'].append(side);out['widths'].append(width);out['origins'].append(origin);out['parent_branch'].append(parent)
                if side:
                    for scope in (str(di*4+ni)+'/全体',str(di*4+ni)+'/'+fr['band'],str(di*4+ni)+'/'+fr['session']):counts[scope][parent]+=1
        if fr['band']!='DAY' and old and not ar['signals'][3]:
            counts['A棄却/全体']['q0']+=1
            if raw_f:counts['A棄却/全体']['同q0独立Fも禁止']+=1
        output.append(out)
    save(PURE/'純入口.json.gz',output)
    paths=[Path(__file__),HERE/'人工確認212.py',HERE/'独立純212.py',HERE/'人工確認.json',HERE/'金融前設計.md',ROOT/'scripts/TOPIX入口研究/共通金融.py',ROOT/'work/183TOPIX/金融を比較する.py',ROOT/'work/183TOPIX/入口とIFD.py',ROOT/'work/183損失安定性/安定性183.py',ROOT/'scripts/入口分析/分析.py',ROOT/'scripts/複合検証/再生.py',ROOT/'study/00001_MACDと方向条件の比較/再現.py',ROOT/'work/183TOPIX/入力台帳.json',ROOT/'work/183TOPIX/条件_実装修正1.json']
    cfg={'試行':212,'規模':8,'候補':list(NAMES),'Source':{ref(p)['path']:ref(p)['sha256'] for p in paths},'入力':refs,'純入口SHA':ref(PURE/'純入口.json.gz')['sha256'],'金融未実行':True,'金融条件':'Day親A25/NightW15/H60/miniTOPIX1枚/片道41.8円+0.25pt/保有予約1/末尾15分','情報区分':'全83既使用の組合せ発見。前48選択/全80発見を区別。','保守的対照':NAMES[5],'固定条件本文':(HERE/'金融前設計.md').read_text('utf-8')}
    save(HERE/'条件.json',cfg);save(HERE/'純封印.json',{'金融未使用':True,'条件':ref(HERE/'条件.json'),'純入口':ref(PURE/'純入口.json.gz'),'全q0':len(output),'全場':83,'純支持':{k:dict(v) for k,v in counts.items()}})
    print(json.dumps({'成功':True,'候補':8,'q0':len(output),'全体支持':{k:dict(v) for k,v in counts.items() if k.endswith('/全体')}},ensure_ascii=False))


if __name__=='__main__':prepare()
