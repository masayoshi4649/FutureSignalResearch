"""212正式Sourceから隔離位置で純と全口座を再現する。"""
from pathlib import Path
import datetime,gzip,hashlib,json,subprocess,sys,zipfile
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
TRIAL=ROOT/'study/00212_デイとナイトの見送りとnative入口を同じ口座で比較する'


def read(path: Path) -> object:
    """
    機能: 固定JSONを読む。
    引数: path(Path)。
    返り値: object。
    """
    raw=path.read_bytes();return json.loads(gzip.decompress(raw) if path.suffix=='.gz' else raw)


def junction(link: Path,target: Path) -> None:
    """
    機能: 共用入力と親studyへの参照を隔離環境に作る。
    引数: link/target(Path)。
    返り値: None。新212純出力先を共用リンクしない。
    """
    assert target.is_dir() and not link.exists();link.parent.mkdir(parents=True,exist_ok=True)
    quote=lambda p:"'"+str(p).replace("'","''")+"'"
    subprocess.run(['powershell','-NoProfile','-Command','New-Item -ItemType Junction -Path '+quote(link)+' -Target '+quote(target)+' | Out-Null'],check=True,capture_output=True)


def main() -> None:
    """
    機能: 正式ZIPのみのSourceから新212純と全8金融を作り同体確認する。
    引数: なし。
    返り値: None。元入力・条件・金融へ書き込まない。
    """
    target=ROOT/'work'/('212Source再現_'+datetime.datetime.now().strftime('%Y%m%dT%H%M%S'));target.mkdir()
    with zipfile.ZipFile(TRIAL/'Source.zip') as z:
        for x in z.infolist():assert (target/x.filename).resolve().is_relative_to(target.resolve())
        z.extractall(target)
    for r in read(TRIAL/'Source索引.json'):assert hashlib.sha256((target/r['path']).read_bytes()).hexdigest()==r['sha256']
    for name in ('00208_TOPIXの役割別見送りと構造反転の純入口','00209_TOPIXの固定参照と戻り失敗の純入口','00210_TOPIXデイの背景矛盾と成熟待ちの純入口','TOPIX原順8列_20260921_20261116','00194_20261116夜と1117昼の固定適用入力'):
        junction(target/'inputs'/name,ROOT/'inputs'/name)
    for name in ('00208_TOPIXの浅い押戻し逆張りを控え損失を比較する','00209_固定参照への戻り失敗と旧入口の増分を比較する','00210_TOPIXデイの長期矛盾と押戻し成熟を比較する'):
        junction(target/'study'/name,ROOT/'study'/name)
    logs=[]
    for script in ('人工確認212.py','入口212.py','独立純212.py'):
        r=subprocess.run([sys.executable,'-X','utf8',str(target/'work/212帯別固定入口'/script)],cwd=target,capture_output=True,text=True,encoding='utf-8');logs.append({'工程':script,'終了':r.returncode,'出力':r.stdout,'エラー':r.stderr});assert r.returncode==0,logs[-1]
    relative='inputs/00212_TOPIXの帯別固定入口の組合せ/純入口.json.gz';sha=hashlib.sha256((target/relative).read_bytes()).hexdigest();assert sha==hashlib.sha256((ROOT/relative).read_bytes()).hexdigest()
    assert read(target/'work/212帯別固定入口/条件.json')==read(TRIAL/'条件.json')
    args=[sys.executable,'-X','utf8',str(target/'scripts/TOPIX入口研究/共通金融.py'),'--condition',str(target/'work/212帯別固定入口/条件.json'),'--births',str(target/relative),'--output',str(target/'work/212帯別固定入口/金融再現'),'--id-template','TOPIX212_{name}','--extra','--expected-dir',str(TRIAL/'金融正本'),'--expected-metrics',str(TRIAL/'安定性.json.gz')]
    r=subprocess.run(args,cwd=target,capture_output=True,text=True,encoding='utf-8');logs.append({'工程':'全8金融','終了':r.returncode,'出力':r.stdout,'エラー':r.stderr});assert r.returncode==0,logs[-1]
    proof={'成功':True,'SourceZIP_SHA':hashlib.sha256((TRIAL/'Source.zip').read_bytes()).hexdigest(),'隔離場所':str(target),'純入口SHA':sha,'条件全体同体':True,'金融':read(target/'work/212帯別固定入口/金融再現/検算.json'),'工程':logs,'範囲':'保存Sourceと共用恒久入力から再生成。追加2の原順8列は固定台帳絶対pathを継承。原BBO独立監査とは区別。'}
    (HERE/'Source隔離再現確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n','utf-8');print('隔離Sourceから純SHA/条件/8金融/全集計同体')


if __name__=='__main__':main()
