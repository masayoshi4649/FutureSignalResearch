"""既存親金融の周辺帯を新金融前に固定し、将来の再現依存を小さく残す。"""
from pathlib import Path
import importlib.util
HERE=Path(__file__).parent;ROOT=HERE.parents[1]
spec=importlib.util.spec_from_file_location('entry212',HERE/'入口212.py');M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)
PARENT={'旧':ROOT/'study/00209_固定参照への戻り失敗と旧入口の増分を比較する/金融正本/TOPIX209_C0_旧190固定.json.gz','D1':ROOT/'work/210TOPIX/金融/金融正本/TOPIX210_A1_長期矛盾見送り_B0_旧_DayA25_H60.json.gz','A':ROOT/'work/208TOPIX/全83/金融/金融正本/TOPIX208_A1_浅押戻し逆張り見送り_B0_旧維持_DayA25_H60.json.gz','F':ROOT/'study/00209_固定参照への戻り失敗と旧入口の増分を比較する/金融正本/TOPIX209_ADD_V_native_QV_W15.json.gz'}


def project(pack: dict,band: str) -> dict:
    """
    機能: 親金融を帯別へ射影し、表示origin以外の全台帳と保有を残す。
    引数: pack(dict),band(str)はDAY/NIGHT。
    返り値: dict。単一枠再生の期待で、取引損益の寄せ集めではない。
    """
    scenes=[s for s in pack['sessions'] if s['kind']==band];names={s['scene'] for s in scenes};ix=[i for i,s in enumerate(pack['ledger']['scene']) if s in names]
    return {'sessions':scenes,'positions':[p for p in pack['positions'] if p['scene'] in names],'ledger':{k:[v[i] for i in ix] for k,v in pack['ledger'].items() if k!='origin'}}


def main() -> None:
    """
    機能: 旧親の読取から同体確認用の小さい帯別期待と指紋を保存する。
    引数: なし。
    返り値: None。新212金融を読まず、純入口を変更しない。
    """
    assert not (HERE/'金融').exists();result={'新金融未使用':True,'親':{}}
    for name,path in PARENT.items():
        pack=M.read(path);result['親'][name]={'指紋':M.ref(path),'id':pack['id'],'帯':{b:project(pack,b) for b in ('DAY','NIGHT') if name=='旧' or b==('DAY' if name=='D1' else 'NIGHT')}}
    M.save(HERE/'金融前親期待.json.gz',result);print('親4本の指紋と帯期待を固定')


if __name__=='__main__':main()
