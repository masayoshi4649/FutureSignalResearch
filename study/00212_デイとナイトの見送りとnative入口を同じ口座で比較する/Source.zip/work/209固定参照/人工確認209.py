"""209の参照線・公表・可用性・固定状態と既存Fの人工検査を行う。"""
from pathlib import Path
from copy import deepcopy
import importlib.util

HERE=Path(__file__).parent
spec=importlib.util.spec_from_file_location('entry209',HERE/'入口209.py');M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)
spec2=importlib.util.spec_from_file_location('test207',M.ROOT/'work/207VWAP/人工確認207.py');T=importlib.util.module_from_spec(spec2);spec2.loader.exec_module(T)


def run() -> None:
    """
    機能: 参照のみ変更したFの売買鏡像と時間順、可用性を確認する。
    引数: なし。
    返り値: None。自然金融を読まない。
    """
    checks=0;items=[]
    for kind in range(4):
        for sell in (False,True):
            source,history,steps=T.scenario(2)
            if sell:source=T.mirror(*source);steps=[T.mirror(*p) for p in steps]
            r,n=source;r['m30']={'count':25,'published':r['time']-10,'end':r['time']-20,'ema21':100.}
            r['prior_high']=100.;r['prior_low']=100.
            state=M.seed(r,n,kind);assert state is not None;checks+=1
            if kind in (0,3):assert state==M.E.seed(r,n,[],2);checks+=1
            fixed=(state['level'],state['native_level'],state['expiry'],state['atr']);birth=None
            for index,(p,v) in enumerate(steps):
                p['m30']={'count':26,'published':p['time'],'end':p['time'],'ema21':130.};p['prior_high']=150.;p['prior_low']=50.
                birth,why=M.E.advance(state,p,v);assert why is None;checks+=1
                if index<len(steps)-1:assert birth is None;checks+=1
                assert fixed==(state['level'],state['native_level'],state['expiry'],state['atr']);checks+=1
            assert birth is not None and birth['quantity']['support'];checks+=2
            assert birth['source']['end']<birth['approach']['end']<birth['recovery']['end']<birth['confirmation']['end'];checks+=1
            items.append(f'{kind}/'+('売り' if sell else '買い')+'固定線と時間順')
    source,_,_=T.scenario(2);r,n=source;r['m30']=None
    assert M.seed(r,n,0) is not None and M.seed(r,n,1) is None and M.seed(r,n,3) is None;checks+=3
    r['m30']={'count':25,'published':r['time']+1,'end':r['time'],'ema21':100.}
    assert M.seed(r,n,1) is None and M.seed(r,n,3) is None;checks+=2
    r['m30']['published']=r['time'];r['m30']['count']=7
    assert M.seed(r,n,1) is None;checks+=1;items.append('Eは公表/履歴、V対照は同じ源時可用性')
    r['prior_high']=100.;a=M.seed(r,n,2);r['high']=999.;b=M.seed(r,n,2)
    assert a is not None and a==b;checks+=2;items.append('Hは源当足の高値を含まない')
    plus={'side':1,'quantity':{'known':False,'support':False}};minus={'side':-1,'quantity':{'known':True,'support':True}}
    for mode in range(3):assert M.E.choose([plus,minus,None],3,mode)==(0,[0,1],True);checks+=1
    items.append('反対側衝突は量より先')
    assert M.E.ref(M.ROOT/'work/207VWAP/入口207.py')['sha256']==M.E.read(M.ROOT/'work/207VWAP/条件.json')['Source']['work/207VWAP/入口207.py'];checks+=1
    M.E.save(HERE/'人工確認.json',{'成功':True,'金融未使用':True,'SourceSHA':M.E.ref(HERE/'入口209.py')['sha256'],'項目':len(items),'属性':checks,'内容':items})
    print('人工',len(items),'項目',checks,'属性成功')


if __name__=='__main__':run()
