"""209の固定条件・全金融・段階診断と再現資料を正式保存する。"""
from pathlib import Path
import gzip,hashlib,json,os,re,shutil,zipfile
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
TRIAL=ROOT/'study/00209_固定参照への戻り失敗と旧入口の増分を比較する'
INPUT=ROOT/'inputs/00209_TOPIXの固定参照と戻り失敗の純入口'


def read(path: Path) -> object:
    """
    機能: 固定JSON又はgzip JSONを読む。
    引数: path(Path)。
    返り値: object。
    """
    raw=path.read_bytes();return json.loads(gzip.decompress(raw) if path.suffix=='.gz' else raw)


def ref(path: Path) -> dict:
    """
    機能: 資源のリポジトリ相対位置と内容指紋を返す。
    引数: path(Path)。
    返り値: dict。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


def main() -> None:
    """
    機能: 固定209条件を変更せず、全38結果と選択区分を正式保存する。
    引数: なし。
    返り値: None。
    """
    TRIAL.mkdir(parents=True,exist_ok=True);cfg=read(HERE/'条件.json');assert read(HERE/'金融独立確認.json')['成功']
    for name in ('条件.json','純封印.json','人工確認.json','純独立確認.json','金融独立確認.json','固定選択.json','全38口座短表.json.gz','実取得差分.json.gz','段階棄却診断.json.gz'):
        shutil.copy2(HERE/name,TRIAL/name)
    shutil.copy2(HERE/'金融前設計案.md',TRIAL/'金融前条件.md')
    for name in ('金融開始前固定.json','安定性.json.gz'):shutil.copy2(HERE/'金融'/name,TRIAL/name)
    if (HERE/'金融再現/検算.json').exists():shutil.copy2(HERE/'金融再現/検算.json',TRIAL/'再現同体確認.json')
    (TRIAL/'金融正本').mkdir(exist_ok=True)
    for path in (HERE/'金融/金融正本').glob('*.json.gz'):shutil.copy2(path,TRIAL/'金融正本'/path.name)
    # ----------------------------------------
    table=['# 209 全38口座の結果','','miniTOPIX1枚・費用後・円。全83場は既使用。未知がある金額は既知寄与であり確定収支ではない。P/QK・C2・反対BBOは寄与診断で、新候補の順位へ混ぜない。','','|候補|帯|取得/未知|参加場|保有下限%|利益|損失|既知収支|建玉/場中央値下限|場末DD既知寄与|','|---|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    for row in read(HERE/'全38口座短表.json.gz'):
        for band in ('DAY','NIGHT'):
            g=row['全83'][band];table.append(f"|{row['候補']}|{band}|{g['取得']}/{g['未知']}|{g['参加場']}/{g['全場']}|{100*g['保有下限']:.2f}|{g['利益']:,.1f}|{g['損失']:,.1f}|{g['既知収支']:,.1f}|{g['建玉中央値下限']}/{g['場中央値下限']}|{g['場末DD既知寄与']:,.1f}|")
    (TRIAL/'全38結果.md').write_text('\n'.join(table)+'\n','utf-8')
    # ----------------------------------------
    template=ROOT/'docs/議論/手法と時間スケールの汎用表_版8.md';body=template.read_text('utf-8').split('## 設定明細')[0]
    body=body.replace('# 手法と時間スケールの汎用表・版8','# 209 設定と結果（版8）').replace('全セルは未設定・未検証。','使用セルへ設定IDを記す。').replace('未設定・未検証','未使用')
    used={'I01':{3:'C0旧EMA',4:'S1中期8/21並びと21傾き',5:'S2源30分EMA21'},'I02':{3:'S2源ATR距離'},'I03':{3:'C0旧条件'},'I04':{3:'C0旧条件'},'I08':{3:'C0旧条件'},'I09':{3:'S2固定源ATR/R1発火ATR'},'I12':{0:'S2固定native/S4区間代金数量比'},'C01':{4:'S1中期方向'},'C07':{1:'S3接近/再開/保持'},'P01':{1:'S3実体/端保持'},'P05':{1:'S3進行'},'P06':{1:'S2前3完成足端'},'P07':{1:'S3次足保持'},'V01':{0:'S4区間数量速度0.5倍'},'B01':{0:'正常BBO/Last位置/C0旧費用方向'},'E01':{0:'R1同幅IFD'},'E02':{0:'R1 H60/末尾15分'}}
    lines=[];count=0
    for line in body.splitlines():
        cells=[c.strip() for c in line.strip().strip('|').split('|')] if line.startswith('|') else []
        if len(cells)==11 and re.fullmatch(r'[A-Z][0-9]{2}',cells[0]):
            count+=1
            for i in range(9):cells[i+2]=used.get(cells[0],{}).get(i,'未使用')
            line='| '+' | '.join(cells)+' |'
        lines.append(line)
    assert count==63
    body=re.sub(r'\]\(([^)]+)\)',lambda m:']('+os.path.relpath((template.parent/m.group(1)).resolve(),TRIAL).replace('\\','/')+')','\n'.join(lines)+'\n')
    body+='''
## 設定明細と複合評価

C0は旧190固定、C1は同じ入口の全帯W15。S1は公表済み15分EMA8/21の並びとEMA21傾き。S2のVは源時native、Eは公表済み30分EMA21（8本以上）、Hは当足を除く前3完成1分端。Eは30分の方向支持条件を追加していない。三線は起算・観測尺度が異なる。C2はEが源時に利用可能な時だけnativeを使う可用性対照。

S2は源ATR5と参照線L、再開線G=L+実側符号×0.25ATR、源から600秒の期限を固定する。源は実側0.5〜2.0ATR、後の別完成足で距離−0.25〜+0.1ATRへ接近、さらに別足でGを実体・進行付き回復、次の連続完成足で保持。各段階の詳細は[金融前条件](金融前条件.md)。実装のnative_levelという継承名はE/Hでは固定参照線Lを格納し、その値を配信nativeとは呼ばない。

S3は中期方向継続、逆端侵入0.1源ATR以下、LastはG実側かつ0.75源ATR以内、スプレッド0超1.5以下、足値幅2.5現ATR以下、live実側−0.25以上。未知で源を解除せず、全段階の期限を延ばさない。量判定前に反対衝突を待機へ確定。同じ側の複数出生は1要求。売買は鏡像。

S4はP価格対照、QK量可用性対照、QV量支持。QKは源/回復/保持の累積epoch・連続性・識別、時刻と原行・数量時計の進行、正の代金/数量差を確認。QVは保持区間のΔ代金÷Δ数量÷10000がG実側、数量速度が源→回復の0.5倍以上。価格出生を共用して量不成立を後へ繰り越さない。HLC3の量加重を取引VWAPと呼ばない。

R1は単純IFD W15又は現ATR5×2.5を5〜25へ制限し0.25切上げたA25、H60、保有予約合計1、終了15分前。miniTOPIX片道41.8円＋0.25pt。ADDは同q0旧190優先、新QVは旧不成立時のみ。将来旧要求の枠を先取りして残さず、後続枠を再生する。DIAGは固定207R/QVの全純出生を反対側実BBOで再生し、1−pを使わない。

[全38結果](全38結果.md)は複合成績で指標単独効果ではない。前48Day選択はADD_V/A25、全80Day発見はADD_M/W15。Night選択はnullだがADD_V/W15を部分的有望診断として保持する。
'''
    (TRIAL/'設定と結果.md').write_text(body,'utf-8')
    # ----------------------------------------
    (TRIAL/'README.md').write_text('''# 209 固定参照への戻り失敗と旧入口の増分を比較する

2026-11-18。**旧入口を優先してnativeへの戻り失敗継続を追加するADD_V/W15は、Nightの損失・赤字取引・DDを減らした部分的な有望案。** 新枝の実取得は5件で、前48は悪化し後25で改善した。全場参加や未見での安定性を達成したとはしない。

[全38結果](全38結果.md) / [設定と結果・版8](設定と結果.md) / [金融前条件](金融前条件.md) / [固定選択](固定選択.json) / [段階と枠の診断](原因診断.md) / [再現](再現.md)

## 仮説と入力

207Fの源→接近→元方向再開→保持を、V配信native、E公表済み30分EMA21、H前3完成1分端へ広げ、P価格のみ/QK量可用性/QV区間実取引支持で比較した。線は源時に固定。方向・構造・量を組み合わせ、短期過熱単独の逆張りにしない。独立出生24、旧2、可用性2、旧優先追加8、207R反対BBO診断2の38口座。

全83場・35,361 q0。直接特徴35,087以外も旧母体と場分母へ残す。旧81、追加2とも既使用で、前48選択・全80発見・後25/追加7/本日1/追加2の診断を分ける。nativeは当場VWAPとは限らず、[204の同原行監査](../00204_VWAPと価格構造の両指数入口/README.md)を継承。原板を複製しない。

金融はminiTOPIX1枚、片道税込41.8円＋0.25pt、1pt=1,000円。単純IFD H60、保有予約合計1、開始一律待機なし、デイ15:30/ナイト05:45全決済。W15/A25を区別し、旧C0はDayA25/NightW15。ラージBBOによる約定代用。未知は0円にせず、枠を場末まで保持する。

## Nightの部分的な改善

|候補|取得/未知|参加場|保有下限|利益既知寄与|損失既知寄与|収支既知寄与|赤字取引/場|場末DD既知寄与|
|---|---:|---:|---:|---:|---:|---:|---:|---:|
|旧C0|176/7|38/41|29.30%|791,892.4|555,020.8|236,871.6|78/10|40,681.6|
|ADD_V/W15|177/7|38/41|29.54%|813,141.6|534,853.6|278,288.0|76/9|19,001.6|

金額は円。両中央値下限は正だが未参加3場と未知7件が残る。新枝そのものは5取得/5Nightで利益27,165.6円・損失5,083.6円・収支22,082円。口座差＋41,416.4円は後続旧入口の枠変更も含むため、全額を新枝単体の優位にしない。

前48のNightは収支が5,000円悪化・損失3,500円増。後25は収支46,416.4円改善・損失23,667.2円減。追加7/追加2は同体で効果再現例ではない。最悪5場の既知寄与は−27,172→−13,504.8円だが、両窓とも未知を含むため確定の損失幅ではない。

## Day・参照線・選択の区別

前48だけのDay選択はADD_V/A25、全80Day発見はADD_M/W15。Night/全体の選択は前48・全80ともnull。この選択を事後にADD_V/W15へ交換しない。

全80Day選択ADD_M/W15の全42Dayは217取得・利益905,219.6円・損失830,610.8円・収支74,608.8円。旧214取得・利益878,220.4円・損失830,610.8円・収支47,609.6円から利益は増えたが損失は同体で、損失安定性の改善証明としない。

E/Hの独立QV入口は少数で赤字。E/A25はDay4取得−14,084.4円、Night2取得で既知−13,583.6円・未知1。H/A25はDay7取得−50,585.2円、Night7取得−16,335.2円。合理的な参照線へ置換するだけでは解決しなかった。207Rの反対BBOは元の大幅赤字を縮めるがW15/A25ともDay/Night既知赤字であり、そのまま採用しない。

## 検査と範囲

人工11項目112属性、V6と207Fの純459,693属性、独立純2,971,042属性、金融別算術164,692属性、全1,343,718 q0の別状態枠再生89,452属性を検査。旧C0の全ledger/sessions/positions、V6と207F、P/QK全8組が同体。

純検査は保存出生と全信号の別式照合で、未成立源を含む全状態機械の別実装ではない。別状態の枠は全q0で確認したが、IFD決済は固定Routeを共用し、新たな原BBO独立走査とは区別する。条件と新金融前のSource/純封印を保持し、段階や期限の変更は次試行とする。
''','utf-8')
    (TRIAL/'原因診断.md').write_text('''# 209 段階の減少と実取得枠の診断

[純段階と場別支持](純封印.json) / [段階棄却の正本](段階棄却診断.json.gz) / [共通・旧のみ・新のみ実取得](実取得差分.json.gz)。事後診断であり条件は変えない。

|線|源|接近|回復|価格出生|量支持出生|量支持場|
|---|---:|---:|---:|---:|---:|---:|
|V native|1,007|145|55|19|13|11|
|E 30分EMA21|779|75|21|9|6|6|
|H 前3完成1分端|357|123|57|19|15|13|
|C2 E可用時native|940|134|49|16|12|10|

QVのDay/米前/米後はV6/6/1、E4/1/1、H8/2/5。Vの既存207F6条件は純と金融とも同体。P/QKの全8組も金融同体で、今回の数量条件差は単なる可用性選別ではない。

## なぜ回復から出生が減るか

V55回復は価格出生19、保持不成立で回復待ちへ戻る24、明示的失効12に分かれる。重なりを許した理由は逆端侵入19、保持終値未達13、rawLast未回復13、rawLast遠すぎ10、源600秒期限11、live逆側3、線反対側受容2、次足連続性1。単独の棄却理由はLast遠すぎ8、逆端4、期限3、live2、Last未回復1。理由は重なるので足し合わせない。

E21回復は価格出生9・保持不成立7・失効5。H57回復は19・28・10。源から接近する前に600秒期限で失効するものはV773/1007、E603/779、H183/357と多い。短い監視期限と厳しい保持が支持を減らす仕組みは確認できたが、棄却条件を緩めた金融は未実行なので「良い確認」か「希少化のみ」かの効果は未確定。

この600秒は入口の源監視期限で、取得後のIFD H60と別物。211の出口時計寄与診断と混同しない。棄却された仮想利益を機会損失として最適化していない。

段階診断は固定生産関数を呼んで理由を記録し、35,087×4系列の保存出生140,348件の対応を照合した観測器である。独立状態機械の監査ではない。既知の中期不整合は源解除、未知は源保持、価格の反対側受容と期限は明示失効として別記される。

## ADD_V/W15 Nightの実現寄与

共通171取得は未知7、利益771,559.6・損失529,770・既知収支241,789.6円。旧のみ5取得は利益20,332.8・損失25,250.8・収支−4,918円。新のみ6取得は利益41,582・損失5,083.6・収支36,498.4円。

新のみのうち新枝は10/8−5,083.6円、10/9＋4,416.4円、10/30＋14,416.4円、11/5＋3,916.4円、11/6＋4,416.4円の5件。残る11/6の＋14,416.4円は後続旧入口であり、新枝5件と区別する。旧のみ5件の置換と後続枠を含めて口座差＋41,416.4円となる。

期間差は前48−5,000円、後25＋46,416.4円、追加7/追加2は0円。新枝の小支持と期間差を残し、Nightの部分的有望性を全場・将来の安定採用へ拡張しない。
''','utf-8')
    # ----------------------------------------
    (TRIAL/'再現.md').write_text('''# 209の再現

Python3.14.3・NumPy2.5.4。Source ZIPを元のリポジトリ相対位置へ復元し、恒久inputsを読む。原板の複製は不要。生産条件/Source/純入力を新金融より前に封印している。

```powershell
& 'work/複合テクニカル学習環境/Scripts/python.exe' -X utf8 'work/209固定参照/人工確認209.py'
& 'work/複合テクニカル学習環境/Scripts/python.exe' -X utf8 'work/209固定参照/入口209.py'
& 'work/複合テクニカル学習環境/Scripts/python.exe' -X utf8 'work/209固定参照/独立純照合209.py'
& 'work/複合テクニカル学習環境/Scripts/python.exe' -X utf8 'scripts/TOPIX入口研究/共通金融.py' --condition 'work/209固定参照/条件.json' --births 'inputs/00209_TOPIXの固定参照と戻り失敗の純入口/純入口.json.gz' --output 'work/209固定参照/金融再現' --id-template 'TOPIX209_{name}' --extra --expected-dir 'study/00209_固定参照への戻り失敗と旧入口の増分を比較する/金融正本' --expected-metrics 'study/00209_固定参照への戻り失敗と旧入口の増分を比較する/安定性.json.gz'
```

再現の出力先は新規を使い、固定条件と正本を異なる内容で上書きしない。人工/純生成は金融を読まず、金融後確認209.pyと段階診断209.pyは後工程。金融後確認はwork/209固定参照/金融を読むので別環境では同体な再現packを元位置へ復元する。

旧C0検算用work/200TOPIX全83 N00金融は[201金融Source](../00201_板数量の更新尺度を複合入口へ加える/金融Source.zip)から元位置へ復元。207F金融の比較元は[207金融正本](../00207_VWAPと固定価格の時間順入口を量支持で比較する/README.md)で永久保存。入力は[209純入口](../../inputs/00209_TOPIXの固定参照と戻り失敗の純入口/README.md)、[204同原行native](../../inputs/00204_両指数の配信VWAP純入力/README.md)、[200旧母体](../../inputs/00200_TOPIXの観測被覆と時間順入口/入力台帳.json)を再用する。

[Source索引](Source索引.json)は後工程を含む再現依存を示し、新金融前のSource範囲は[条件](条件.json)が正本。[保存索引](保存索引.json)と[金融独立確認](金融独立確認.json)に検査範囲を残す。
''','utf-8')
    (INPUT/'README.md').write_text('# 209 TOPIX固定参照の純入口\n\n全83場35,361 q0・38候補。新金融前に固定した純入力を一度だけ保存する。[研究正本](../../study/00209_固定参照への戻り失敗と旧入口の増分を比較する/README.md)。原板は共用。nativeは当場VWAPとは限らず、E/Hの固定参照線と混同しない。\n','utf-8')
    (INPUT/'入力台帳.json').write_text(json.dumps({'試行':209,'純入口':ref(INPUT/'純入口.json.gz'),'条件':ref(TRIAL/'条件.json'),'全83既使用':True},ensure_ascii=False,indent=2)+'\n','utf-8')
    # ----------------------------------------
    sources=set(ROOT/p for p in cfg['Source'])|set(HERE.glob('*.py'))
    sources.update(ROOT/r['path'] for r in read(ROOT/'study/00207_VWAPと固定価格の時間順入口を量支持で比較する/Source索引.json'))
    sources.add(HERE/'金融前設計案.md');sources.add(HERE/'人工確認.json')
    sources.add(ROOT/'work/207VWAP/条件.json')
    sources.add(ROOT/'scripts/複合検証/再生.py')
    sources.add(ROOT/'study/00001_MACDと方向条件の比較/再現.py')
    with zipfile.ZipFile(TRIAL/'Source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(sources):z.write(p,p.relative_to(ROOT).as_posix())
    (TRIAL/'Source索引.json').write_text(json.dumps([ref(p) for p in sorted(sources)],ensure_ascii=False,indent=2)+'\n','utf-8')
    files=sorted(p for p in TRIAL.rglob('*') if p.is_file() and p.name!='保存索引.json')+sorted(INPUT.glob('*'))
    assert all(ref(ROOT/p)['sha256']==sha for p,sha in cfg['Source'].items())
    (TRIAL/'保存索引.json').write_text(json.dumps({'Source固定不変':True,'汎用セル':567,'正本':[ref(p) for p in files]},ensure_ascii=False,indent=2)+'\n','utf-8')
    links=0
    for p in [*TRIAL.glob('*.md'),INPUT/'README.md']:
        for link in re.findall(r'\]\(([^)]+)\)',p.read_text('utf-8')):
            if '://' in link or link.startswith('#'):continue
            assert (p.parent/link.split('#')[0]).resolve().exists(),(p,link);links+=1
    print('正式正本',len(files),'Source',len(sources),'汎用セル567','リンク',links,'成功')


if __name__=='__main__':main()
