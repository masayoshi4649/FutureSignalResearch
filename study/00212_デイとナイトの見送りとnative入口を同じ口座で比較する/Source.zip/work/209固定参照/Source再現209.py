"""正式Source ZIPを隔離位置へ復元し、純入口と全38金融を再現する。"""
from pathlib import Path
import datetime,gzip,hashlib,json,subprocess,sys,zipfile
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
TRIAL=ROOT/'study/00209_固定参照への戻り失敗と旧入口の増分を比較する'


def read(path: Path) -> object:
    """
    機能: 検査対象JSONを読む。
    引数: path(Path)。
    返り値: object。
    """
    raw=path.read_bytes();return json.loads(gzip.decompress(raw) if path.suffix=='.gz' else raw)


def junction(link: Path,target: Path) -> None:
    """
    機能: 共用入力又は固定親studyへ読取用ディレクトリ参照を作る。
    引数: link/target(Path)は検証済み絶対位置。
    返り値: None。原入力をコピーせず、新209純出力先はリンクしない。
    """
    assert target.is_dir() and not link.exists();link.parent.mkdir(parents=True,exist_ok=True)
    quote=lambda p:"'"+str(p).replace("'","''")+"'"
    cmd='New-Item -ItemType Junction -Path '+quote(link)+' -Target '+quote(target)+' | Out-Null'
    subprocess.run(['powershell','-NoProfile','-Command',cmd],check=True,capture_output=True)


def main() -> None:
    """
    機能: 保存ZIPだけのSourceと共用恒久入力で純/金融を隔離再現する。
    引数: なし。
    返り値: None。元の条件・金融・inputsに書き込まない。
    """
    target=ROOT/'work'/('209Source再現_'+datetime.datetime.now().strftime('%Y%m%dT%H%M%S'));target.mkdir()
    with zipfile.ZipFile(TRIAL/'Source.zip') as archive:
        for item in archive.infolist():assert (target/item.filename).resolve().is_relative_to(target.resolve())
        archive.extractall(target)
    for item in read(TRIAL/'Source索引.json'):
        assert hashlib.sha256((target/item['path']).read_bytes()).hexdigest()==item['sha256']
    names=('00200_TOPIXの観測被覆と時間順入口','TOPIX原順8列_20260921_20261116','00194_20261116夜と1117昼の固定適用入力','00204_両指数の配信VWAP純入力','00207_TOPIXのVWAPと固定価格の純入口')
    for name in names:junction(target/'inputs'/name,ROOT/'inputs'/name)
    for name in ('00204_VWAPと価格構造の両指数入口','00207_VWAPと固定価格の時間順入口を量支持で比較する'):
        junction(target/'study'/name,ROOT/'study'/name)
    parent=read(TRIAL/'条件.json')['母体期待']['path']
    with zipfile.ZipFile(ROOT/'study/00201_板数量の更新尺度を複合入口へ加える/金融Source.zip') as archive:archive.extract(parent,target)
    logs=[]
    for script in ('人工確認209.py','入口209.py','独立純照合209.py'):
        result=subprocess.run([sys.executable,'-X','utf8',str(target/'work/209固定参照'/script)],cwd=target,capture_output=True,text=True,encoding='utf-8')
        logs.append({'工程':script,'終了コード':result.returncode,'標準出力':result.stdout,'標準エラー':result.stderr});assert result.returncode==0,logs[-1]
    relative='inputs/00209_TOPIXの固定参照と戻り失敗の純入口/純入口.json.gz';sha=hashlib.sha256((target/relative).read_bytes()).hexdigest()
    assert sha==hashlib.sha256((ROOT/relative).read_bytes()).hexdigest()
    assert read(target/'work/209固定参照/条件.json')==read(TRIAL/'条件.json')
    command=[sys.executable,'-X','utf8',str(target/'scripts/TOPIX入口研究/共通金融.py'),'--condition',str(target/'work/209固定参照/条件.json'),'--births',str(target/relative),'--output',str(target/'work/209固定参照/金融再現'),'--id-template','TOPIX209_{name}','--extra','--expected-dir',str(TRIAL/'金融正本'),'--expected-metrics',str(TRIAL/'安定性.json.gz')]
    result=subprocess.run(command,cwd=target,capture_output=True,text=True,encoding='utf-8');logs.append({'工程':'全38金融','終了コード':result.returncode,'標準出力':result.stdout,'標準エラー':result.stderr});assert result.returncode==0,logs[-1]
    proof={'成功':True,'隔離場所':str(target),'復元SourceZIP_SHA':hashlib.sha256((TRIAL/'Source.zip').read_bytes()).hexdigest(),'純入口SHA':sha,'条件全体同体':True,'金融':read(target/'work/209固定参照/金融再現/検算.json'),'工程':logs,'共用入力':'永久inputsの読取参照。追加2原順8列は固定台帳の絶対pathも継承。原板複製なし、新209純入力は隔離実体へ保存。'}
    (HERE/'Source隔離再現確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n','utf-8');print('隔離Sourceから純SHA/条件/全38金融/全集計同体')


if __name__=='__main__':main()
