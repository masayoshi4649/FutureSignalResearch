"""209の母体/全枠/別集計/量と増分/反対BBOを固定条件のまま検査する。"""
from pathlib import Path
import importlib.util,json,hashlib,math

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent;TARGET=HERE/'金融'
spec=importlib.util.spec_from_file_location('audit207',ROOT/'work/207VWAP/金融後確認207.py');P=importlib.util.module_from_spec(spec);spec.loader.exec_module(P)
read=P.read;save=P.save;C=P.C


def compare_pair(old: dict,new: dict) -> dict:
    """
    機能: 同じ取得の共通寄与と旧のみ/新のみを、帯・期間別に分ける。
    引数: old/new(dict)は固定口座。
    返り値: dict。将来の機会損失を作らない。
    """
    a,b=P.trades(old),P.trades(new);common=set(a)&set(b);left=set(a)-common;right=set(b)-common
    for key in common:assert all(a[key][f]==b[key][f] for f in ('known','net','entry_price','exit_price','exit_time','label'))
    scenes=[r['scene'] for r in old['sessions']];periods={'全83':scenes,'全80':scenes[:80],'前48':scenes[:48],'後25':scenes[48:73],'追加7':scenes[73:80],'本日1':scenes[80:81],'追加2':scenes[81:]};summaries=[]
    for period,names in periods.items():
        for band in ('ALL','DAY','NIGHT','PRE','POST'):
            def inside(r: dict) -> bool:
                """
                機能: 元の要求帯と場で実現取引を選択する。
                引数: r(dict)。
                返り値: bool。
                """
                return r['scene'] in names and (band=='ALL' or band=='NIGHT' and r['phase']!=0 or r['phase']=={'DAY':0,'PRE':1,'POST':2}.get(band))
            summaries.append({'期間':period,'帯':band,'共通':P.subtotal([a[k] for k in common if inside(a[k])]),
                '旧のみ':P.subtotal([a[k] for k in left if inside(a[k])]),'新のみ':P.subtotal([b[k] for k in right if inside(b[k])])})
    return {'旧':old['id'],'新':new['id'],'集計':summaries,'旧のみ実取得':[a[k] for k in sorted(left)],'新のみ実取得':[b[k] for k in sorted(right)]}


def main() -> None:
    """
    機能: 38口座を独立集計し、事前選択・共通枠差・V6同体を保存する。
    引数: なし。
    返り値: None。209の源やIFD期限を変更しない。
    """
    cfg=read(HERE/'条件.json');assert read(HERE/'純独立確認.json')['成功']
    assert all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==sha for p,sha in cfg['Source'].items())
    stats=read(TARGET/'安定性.json.gz')['metrics'];assert len(stats)==38
    packs=[read(TARGET/'金融正本'/(r['id']+'.json.gz')) for r in stats];old=read(ROOT/cfg['母体期待']['path'])
    for field in ('ledger','sessions','positions'):assert packs[0][field]==old[field]
    vproof=[]
    for i,reference in enumerate(cfg['V6期待']):
        path=ROOT/reference['path'];assert hashlib.sha256(path.read_bytes()).hexdigest()==reference['sha256'];parent=read(path);actual=packs[i+2]
        for field in ('sessions','positions'):assert actual[field]==parent[field]
        assert {k:v for k,v in actual['ledger'].items() if k!='origin'}=={k:v for k,v in parent['ledger'].items() if k!='origin'}
        vproof.append({'候補':actual['id'],'元':reference,'同体':True})
    quantity_same=[]
    for role in range(4):
        for wi in range(2):
            a,b=packs[2+role*6+wi],packs[4+role*6+wi]
            assert a['positions']==b['positions'] and {k:v for k,v in a['ledger'].items() if k!='origin'}=={k:v for k,v in b['ledger'].items() if k!='origin'}
            quantity_same.append([a['id'],b['id']])
    groups=sum(P.V.inspect_groups(p,s) for p,s in zip(packs,stats,strict=True));rows=read(ROOT/'inputs/00209_TOPIXの固定参照と戻り失敗の純入口/純入口.json.gz')
    slots=P.capacity(packs,rows);eligible=[i for i in range(38) if i in range(28,36) or i in [6,7,12,13,18,19,24,25]];rankings={}
    for period in ('前48','全80'):
        for band in ('DAY','NIGHT','ALL'):
            base=stats[0]['periods'][period][band];order=sorted(eligible,key=lambda i:(C.F.A.rank_key(stats[i]['periods'][period][band],base),packs[i]['id']))
            table=[{'候補':cfg['候補'][i],'id':packs[i]['id'],'gate':C.F.A.gate(stats[i]['periods'][period][band],base)} for i in order]
            passed=[r for r in table if r['gate']['suitable']]
            rankings[period+'_'+band]={'選択':passed[0] if passed else None,'参考先頭':table[0],'順位':table}
    save(HERE/'固定選択.json',{'全83既使用':True,'新候補はQV又はADD':True,'順位':rankings})
    pairs={(0,i) for i in range(1,38)}|{(1,i) for i in [6,12,18,24]}|{(6,26),(7,27),(26,12),(27,13)}
    for role in range(4):
        for wi in range(2):pairs.add((2+role*6+wi,4+role*6+wi));pairs.add((4+role*6+wi,6+role*6+wi));pairs.add((6+role*6+wi,28+role*2+wi))
    diffs=[compare_pair(packs[a],packs[b]) for a,b in sorted(pairs)]
    for wi,w in enumerate(('W15','A25')):
        parent=read(ROOT/'study/00207_VWAPと固定価格の時間順入口を量支持で比較する/金融正本'/('TOPIX207_R_端突破失敗反転_QV_区間取引支持_'+w+'.json.gz'))
        diffs.append(compare_pair(parent,packs[36+wi]))
    save(HERE/'実取得差分.json.gz',diffs)
    short=[{'候補':cfg['候補'][i],'id':s['id'],'全83':{b:C.F.terse(g) for b,g in s['groups'].items()},
        '期間':{p:{b:C.F.terse(g) for b,g in group.items()} for p,group in s['periods'].items()}} for i,s in enumerate(stats)]
    save(HERE/'全38口座短表.json.gz',short)
    save(HERE/'金融独立確認.json',{'成功':True,'旧C0同体':True,'V6同体':vproof,'P_QK同体':quantity_same,'別算術属性':groups,'全件枠':slots,
        'SourceSHA':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'範囲':'全固定台帳と別算術・別状態枠。Route決済は共用で、原BBOの新規独立監査ではない。'})
    print(json.dumps({'成功':True,'別算術属性':groups,'枠':slots,'選択':{k:v['選択'] for k,v in rankings.items()}},ensure_ascii=False))


if __name__=='__main__':main()
