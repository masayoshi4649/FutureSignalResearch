"""209全信号と参照線の成立境界を生産売買関数なしで照合する。"""
from pathlib import Path
from collections import Counter
import gzip,hashlib,json,math

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent


def read(path: Path) -> object:
    """
    機能: 固定純JSONを読む。
    引数: path(Path)。
    返り値: object。
    """
    with gzip.open(path,'rt',encoding='utf-8') if path.suffix=='.gz' else path.open(encoding='utf-8') as f:return json.load(f)


def main() -> None:
    """
    機能: 全q0の38信号・幅・旧優先と、成立源の当時参照を検査する。
    引数: なし。
    返り値: None。未成立源の全状態を別生成した監査とは区別する。
    """
    cfg=read(HERE/'条件.json');path=ROOT/'inputs/00209_TOPIXの固定参照と戻り失敗の純入口/純入口.json.gz'
    assert hashlib.sha256(path.read_bytes()).hexdigest()==cfg['純入口SHA'];rows=read(path)
    old=read(ROOT/'inputs/00207_TOPIXのVWAPと固定価格の純入口/純入口.json.gz')
    features=read(ROOT/'inputs/TOPIX原順8列_20260921_20261116/純特徴184直接.json.gz')
    features+=read(ROOT/'inputs/00194_20261116夜と1117昼の固定適用入力/TOPIX/純特徴184直接.json.gz')
    fm={(r['session'],r['time'],r['line']):r for r in features};checks=0;counts=Counter()
    for r,p in zip(rows,old,strict=True):
        key=(r['session'],r['time'],r['line']);assert key==(p['session'],p['time'],p['line']);checks+=1
        current=fm.get(key);adaptive=math.ceil(min(25.,max(5.,current['atr']*2.5))*4)/4 if current else None
        expected_signals=p['signals'][:2];expected_widths=p['widths'][:2]
        assert r['births'][0]==p['births'][2];checks+=1
        for line,b in enumerate(r['births']):
            if b is None:continue
            counts[str(line)]+=1;d=b['side'];s=b['source'];source=fm[(r['session'],s['time'],s['line'])];m=source['m30'];a=source['atr']
            known=m is not None and m['count']>=8 and m['published']<=s['time'] and math.isfinite(m['ema21'])
            if line in (1,3):assert known;checks+=1
            fixed=m['ema21'] if line==1 else source['prior_high'] if line==2 and d==1 else source['prior_low'] if line==2 else s['native']
            assert b['native_level']==fixed and b['level']==fixed+d*.25*a;checks+=2
            assert .5<=d*(s['close']-fixed)/a<=2 and b['expiry']==s['time']+600;checks+=2
            approach,recovery,held=b['approach'],b['recovery'],b['confirmation']
            assert s['end']<approach['end']<recovery['end']<held['end'] and held['end']==recovery['end']+60;checks+=2
            ap=fm[(r['session'],approach['time'],approach['line'])];rc=fm[(r['session'],recovery['time'],recovery['line'])]
            assert -.25<=d*(ap['close']-fixed)/a<=.1 and d*ap['progress']<0;checks+=2
            assert d*(rc['prior_close']-b['level'])<=0<d*(rc['close']-b['level']);checks+=1
            points=(s,recovery,held);qknown=all(x['native_known'] and x['epoch']==s['epoch'] and x['continuity']==s['continuity'] and x['identity']==s['identity'] for x in points)
            rates=[];means=[]
            for left,right in zip(points,points[1:]):
                dq=right['volume']-left['volume'];dv=right['value']-left['value'];dt=right['time']-left['time']
                qknown=qknown and dq>0 and dv>0 and dt>0 and right['line']>left['line'] and right['volume_time']>left['volume_time']
                rates.append(dq/dt if dt>0 else None);means.append(dv/dq/10000 if dq>0 else None)
            assert qknown==b['quantity']['known'];checks+=1
            if qknown:assert b['quantity']['support']==(d*(means[-1]-b['level'])>=0 and rates[-1]>=.5*rates[0]);checks+=1
        for family in range(4):
            eligible=[b for i,b in enumerate(r['births'][:3]) if b is not None and (family==3 or family==i)];directions={b['side'] for b in eligible}
            for mode in range(3):
                passed=[b for b in eligible if mode==0 or mode==1 and b['quantity']['known'] or mode==2 and b['quantity']['support']]
                side=next(iter(directions)) if len(directions)==1 and passed else 0
                expected_signals.extend([side,side]);expected_widths.extend([15.,adaptive])
        common=r['births'][3];side=common['side'] if common and common['quantity']['support'] else 0
        expected_signals.extend([side,side]);expected_widths.extend([15.,adaptive])
        for family in range(4):
            side=expected_signals[2+family*6+4]
            for w in (15.,adaptive):expected_signals.append(p['signals'][0] or side);expected_widths.append(p['widths'][0] if p['signals'][0] else w)
        expected_signals.extend([-p['signals'][12],-p['signals'][13]]);expected_widths.extend(p['widths'][12:14])
        assert r['signals']==expected_signals and r['widths']==expected_widths;checks+=76
        for mode in range(3):
            for wi in range(2):assert r['signals'][2+mode*2+wi]==p['signals'][14+mode*2+wi];checks+=1
    proof={'成功':True,'金融未使用':True,'q0':len(rows),'価格出生':dict(counts),'比較属性':checks,
        '範囲':'全38信号/幅/旧優先/反対BBO側、V6同体と全保存源の参照・量を別式で確認。未成立状態全体の別生成ではない。',
        '純入口SHA':cfg['純入口SHA'],'SourceSHA':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    output=HERE/'純独立確認.json';assert not output.exists();output.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':main()
