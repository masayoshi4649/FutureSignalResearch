"""209の固定状態を再演し、保持が不成立となる当時理由を観測する。"""
from collections import Counter,defaultdict
from copy import deepcopy
from pathlib import Path
import importlib.util,json

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
spec=importlib.util.spec_from_file_location('e209',HERE/'入口209.py');M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)
E=M.E


def hold_reasons(state: dict,row: dict,native: dict) -> list:
    """
    機能: 固定回復の次段階で当時成立していない価格/時計条件を全て挙げる。
    引数: state/row/native(dict)。
    返り値: list[str]。理由は重複し、除外した仮想損益は算出しない。
    """
    d=state['side'];a=state['atr'];g=state['level'];r=state['recovery'];why=[]
    if row['time']>state['expiry']:why.append('源期限')
    background=E.direction(row)
    if background is None:why.append('中期未知')
    elif background!=d:why.append('中期非整合')
    if native['epoch']!=state['source']['epoch']:why.append('起算変更')
    if d*(row['close']-state['native_level'])<-.25*a:why.append('参照反対側への終値受容')
    if E.minute_end(row)!=r['end']+60 or not 30<=row['time']-r['time']<=90 or row['line']<=r['line']:why.append('保持足非連続')
    if d*(row['close']-g)<=0:why.append('保持終値が線の反対側')
    if d*((row['low'] if d==1 else row['high'])-g)<-.1*a:why.append('保持反対端侵入')
    distance=d*(native['last']-g) if native['last'] is not None else None
    if distance is None:why.append('Last未知')
    elif distance<=0:why.append('Last線未回復')
    elif distance>.75*a:why.append('Lastが線から遠い')
    if not 0<row['spread']<=1.5:why.append('スプレッド')
    if row['range']>2.5:why.append('1分幅過大')
    if row['live'] is None:why.append('live未知')
    elif d*row['live']<-.25:why.append('live逆進')
    return why


def main() -> None:
    """
    機能: 全状態を元Sourceのまま再演し保存出生同体を保って段階棄却を記録する。
    引数: なし。
    返り値: None。独立状態監査ではなく固定実装への観測を追加する事後診断。
    """
    _,features,natives,_=E.load_inputs();pure=E.read(M.PURE/'純入口.json.gz');expected={E.key(r):r['births'] for r in pure}
    states=[None]*4;scene=None;counts=defaultdict(Counter);events=[];checks=0
    for row in features:
        key=E.key(row);native=natives[key]
        if scene!=row['session']:
            for i,state in enumerate(states):
                if state is not None:
                    stage='保持待ち' if state['recovery'] else '再開待ち' if state['approach'] else '接近待ち'
                    counts[str(i)+'/全体']['場末:'+stage]+=1
            states=[None]*4;scene=row['session']
        births=[]
        for kind in range(4):
            state=states[kind];birth=None;scopes=[str(kind)+'/全体',str(kind)+'/'+row['band'],str(kind)+'/'+row['session']]
            if state is not None:
                before=deepcopy(state);why=hold_reasons(before,row,native) if before['recovery'] else []
                birth,reason=E.advance(state,row,native)
                if before['recovery']:
                    finished=birth is not None or reason is not None or state['recovery']!=before['recovery']
                    if finished:
                        status='価格保持出生' if birth else '保持失効' if reason else '保持不成立で回復待ちへ'
                        for scope in scopes:
                            counts[scope][status]+=1
                            for label in why:counts[scope]['理由:'+label]+=1
                        events.append({'line_kind':kind,'session':scene,'source':before['source'],'approach':before['approach'],
                            'recovery':before['recovery'],'observed':E.small_snapshot(row,native),'status':status,'reasons':why,
                            'source_atr':before['atr'],'price_line':before['level'],
                            'closed_high':row['high'],'closed_low':row['low'],'range_atr':row['range'],'live':row['live']})
                    else:
                        for scope in scopes:counts[scope]['保持監視継続']+=1
                if birth is not None or reason is not None:states[kind]=None
                if reason:
                    stage='保持待ち' if before['recovery'] else '再開待ち' if before['approach'] else '接近待ち'
                    for scope in scopes:counts[scope]['失効:'+stage+':'+reason]+=1
            else:
                state=M.seed(row,native,kind)
                if state is not None:states[kind]=state
            births.append(birth)
        assert births==expected[key],key;checks+=4
    for kind,state in enumerate(states):
        if state is not None:
            stage='保持待ち' if state['recovery'] else '再開待ち' if state['approach'] else '接近待ち';counts[str(kind)+'/全体']['場末:'+stage]+=1
    report={'事後診断':True,'金融未使用':True,'出生同体':checks,'集計':{k:dict(v) for k,v in counts.items()},'保持段階全件':events,
        '限界':'固定実装を呼ぶ観測追加であり独立状態実装ではない。棄却理由は重複。保持なし/期限延長の金融は未計算。失敗候補の仮想利益を機会損失にしない。'}
    E.save(HERE/'段階棄却診断.json.gz',report)
    print(json.dumps({k:v for k,v in report['集計'].items() if k.endswith('/全体')},ensure_ascii=False,indent=2))


if __name__=='__main__':main()
