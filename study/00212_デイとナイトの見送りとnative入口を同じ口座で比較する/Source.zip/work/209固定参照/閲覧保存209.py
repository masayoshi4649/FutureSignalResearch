"""209の候補別CSVを再読照合し、解説・再現Sourceと指紋を残す。"""
from pathlib import Path
import csv,io,json,math,hashlib,shutil,zipfile,re
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
TRIAL=ROOT/'study/00209_固定参照への戻り失敗と旧入口の増分を比較する'
OUT=ROOT/'outputs/00209_TOPIXの固定参照と旧入口の増分'


def ref(path: Path) -> dict:
    """
    機能: 資源のリポジトリ相対位置・サイズ・内容指紋を返す。
    引数: path(Path)。
    返り値: dict。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


def main() -> None:
    """
    機能: 20CSVの全セル・累計・未知空欄を検査して閲覧を正式化する。
    引数: なし。
    返り値: None。売買条件・金融・事前選択は変更しない。
    """
    data=json.loads((HERE/'閲覧入力.json').read_text('utf-8'));proof=json.loads((ROOT/'work/209CSV検査/作成確認.json').read_text('utf-8'));cells=nulls=0
    for item in proof['files']:
        raw=(OUT/item['相対path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==item['sha256'];rows=list(csv.reader(io.StringIO(raw.decode('utf-8-sig'))))
        table=data['tables'][item['元表']];expected=[table['headers']]+[r for r in table['rows'] if r[0]==item['候補']];assert len(rows)==len(expected)
        for actual,source in zip(rows,expected,strict=True):
            assert len(actual)==len(source)
            for a,b in zip(actual,source,strict=True):
                cells+=1
                if b is None:assert a=='';nulls+=1
                elif isinstance(b,(int,float)):assert math.isclose(float(a),b,abs_tol=1e-7)
                else:assert a==b
        for row in rows[1:]:assert math.isclose(float(row[3])-float(row[4]),float(row[10]),abs_tol=1e-7)
        if item['元表']!='候補比較':
            total=0.;complete=True
            for row in rows[1:]:
                total+=float(row[10]);complete=complete and int(row[8])==0;assert math.isclose(float(row[11]),total,abs_tol=1e-7)
                if complete:assert math.isclose(float(row[6]),total,abs_tol=1e-7)
                else:assert row[6]==''
    assert len(proof['files'])==20 and cells==8400 and nulls>0
    proof.update(CSV全セル再読=cells,未知空欄セル数=nulls,累計算術検査=True,全Day42とNight41を保持=True,全20表の描画を目視確認=True)
    support=TRIAL/'閲覧資料';support.mkdir(exist_ok=True);(support/'CSV確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n','utf-8');shutil.copy2(HERE/'閲覧入力.json',support/'閲覧入力.json')
    sources=[HERE/'閲覧入力209.py',Path(__file__),ROOT/'scripts/損益CSV/候補別に出力する.mjs']
    with zipfile.ZipFile(support/'閲覧Source.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in sources:z.write(p,p.relative_to(ROOT).as_posix())
    (support/'Source索引.json').write_text(json.dumps([ref(p) for p in sources],ensure_ascii=False,indent=2)+'\n','utf-8')
    descriptions={'00_旧基準':'旧190D4/N01。Day A25・Night W15の固定対照。','28_native追加W15':'旧190を優先し、旧不成立時にnativeへの戻り失敗継続QVをW15で追加。Nightの部分的有望案。','29_前48Day選択':'前48だけのDay順位首位ADD_V/A25。旧を優先し新native枝をA25で追加。全期の有望判断へ事後交換しない。','34_全80Day選択':'全80のDay順位首位ADD_M/W15。native・30分EMA21・前3完成1分端の同側統合QVを追加。Night選択案ではなく、Night未知は8へ増える。'}
    for title,description in descriptions.items():
        folder=OUT/('209_'+title)
        (folder/'README.md').write_text(f'''# 209:{title}

{description}

2026-09-21〜11-17、デイ42・ナイト41の全83セッションは既使用。miniTOPIX1枚、1pt=1,000円、片道41.8円＋0.25pt、往復費用583.6円。ラージBBOによる約定代用。単純IFD H60、保有予約合計1、開始一律待機なし、終了15分前全決済。新枝A25は現ATR5×2.5を5〜25ptへ制限し0.25切上げ。

[集計](集計.csv) / [デイ](デイ.csv) / [ナイト全体](ナイト全体.csv) / [ナイト米国前](ナイト_米前.csv) / [ナイト米国後](ナイト_米後.csv)。

利益・損失は費用後の既知取引の寄与を分ける。未知を含む場の確定収支とそれ以降の確定累計は空欄。未知を0円にせず既知寄与列を残す。0取引場も行を残し、累計は候補・帯ごとに0から始める。

保有時間率下限は対象実時間に占める確認済み保有（0〜1）。末尾15分を分母から除き、予約や未確認保有は含めない。損益は新規帯、保有は実区間の重なりへ帰属する。ナイト全体と米国前後は同じ取引の別集計なので重複加算しない。

[比較・支持・限界](../README.md) / [研究正本](../../../study/00209_固定参照への戻り失敗と旧入口の増分を比較する/README.md)。
''','utf-8')
    body='''# TOPIXの固定参照と旧入口の増分・全83場

まず[28_native追加W15](209_28_native追加W15/README.md)と[00_旧基準](209_00_旧基準/README.md)のナイト全体を比較する。新枝が増えた部分と後続旧入口の枠変更を含む口座結果であり、新枝単体の損益と区別する。

[29_前48Day選択](209_29_前48Day選択/README.md)は前半だけの選択、[34_全80Day選択](209_34_全80Day選択/README.md)は全80のDay発見案。この2案をNight選択へ読み替えない。

## ナイト41場

miniTOPIX1枚・費用後・円。全83場は探索に既使用。金額は未知を除く既知寄与で、全体の確定収支ではない。

|候補|利益既知寄与|損失既知寄与|収支既知寄与|赤字取引 / 取得|赤字場|未知|取得場|保有下限|場末DD既知寄与|
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
'''
    for row in data['Night比較']:
        title=row['候補'].split(':')[1];body+=f"|[{title}](209_{title}/README.md)|{row['known_profit']:,.1f}|{row['known_loss']:,.1f}|{row['known_net']:,.1f}|{row['赤字取引']} / {row['all_count']}|{row['赤字場']}|{row['unknown_count']}|{row['取得場']}/41|{row['保有率']:.2%}|{row['DD']:,.1f}|\n"
    body+='''
28は損失20,167.2円減、赤字取引78→76、赤字場10→9、DD40,681.6→19,001.6円へ減少。両中央値下限は正で、参加38/41場と未知7は同じ。前48Nightは収支5,000円悪化、後25は46,416.4円改善。追加7/追加2は同体なので効果の新たな再現ではない。

新枝の実取得は5件/5Night、利益27,165.6・損失5,083.6・収支22,082円。口座差＋41,416.4円は旧のみ/新のみの置換と後続旧入口も含む。少支持と期間差を残し、安定採用とはしない。

Dayの34は旧から利益26,999.2円増、損失830,610.8円は同体。利益拡大のみを損失安定性の改善としない。独立E/H枝は赤字・参加不足で全置換へ採らない。

## 定義と検査

全Day42行・全Night41行を残す。未知は確定収支/累計の空欄、0円は既知0。DDは場末既知実現寄与であり保有中の最大時価DDとは異なる。保有率は全対象実時間の率で、各場20%達成ではない。

[全38口座・段階・原因・選択](../../study/00209_固定参照への戻り失敗と旧入口の増分を比較する/README.md) / [20CSV・8,400セルの再読確認](../../study/00209_固定参照への戻り失敗と旧入口の増分を比較する/閲覧資料/CSV確認.json) / [閲覧再現](../../study/00209_固定参照への戻り失敗と旧入口の増分を比較する/閲覧資料/README.md)。xlsxは作成していない。
'''
    (OUT/'README.md').write_text(body,'utf-8')
    (support/'README.md').write_text('''# 209 閲覧CSVの再現

[閲覧入口](../../../outputs/00209_TOPIXの固定参照と旧入口の増分/README.md)。候補0/28/29/34をそれぞれ5CSVへ分離し、20CSV・8,400セルを再読照合した。全20表の描画を確認した。UTF-8 BOM/CRLF、未知は空欄。xlsxは作っていない。

[型付き入力](閲覧入力.json) / [CSV確認](CSV確認.json) / [Source](閲覧Source.zip) / [Source索引](Source索引.json)。入力生成は正式安定性と正式金融の保有区間だけを読み、workの金融や原板を必要としない。量・枠・金融の再探索はしない。

Sourceを元相対pathへ復元し、閲覧入力209.pyを実行。型付きJSONをscripts/損益CSV/候補別に出力する.mjsへ --input、--output 新規出力先、--proof 新規確認先、--dependencies Codex提供node_modulesで渡す。Node24.22.1・Codex提供artifact-tool。全セル設定とrecalculate後の値照合、別Python csv再読で確認する。
''','utf-8')
    study_readme=TRIAL/'README.md';text=study_readme.read_text('utf-8');link='[候補別CSV](../../outputs/00209_TOPIXの固定参照と旧入口の増分/README.md)'
    if link not in text:study_readme.write_text(text+'\n## 閲覧CSV\n\n'+link+'に旧0・部分的有望28・前48Day選択29・全80Day選択34の全83場を分離保存。20CSV・8,400セルを正式集計と保有区間へ照合した。未知は確定収支・累計の空欄として保持する。\n','utf-8')
    manifest=json.loads((TRIAL/'保存索引.json').read_text('utf-8'));manifest['正本']=[ref(p) for p in sorted(TRIAL.rglob('*')) if p.is_file() and p.name!='保存索引.json']+[ref(p) for p in sorted((ROOT/'inputs/00209_TOPIXの固定参照と戻り失敗の純入口').glob('*'))]+[ref(p) for p in sorted(OUT.rglob('*')) if p.is_file()]
    (TRIAL/'保存索引.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n','utf-8')
    links=0
    for p in [*OUT.rglob('*.md'),*TRIAL.rglob('*.md')]:
        for link in re.findall(r'\]\(([^)]+)\)',p.read_text('utf-8')):
            if '://' in link or link.startswith('#'):continue
            assert (p.parent/link.split('#')[0]).resolve().exists(),(p,link);links+=1
    print(json.dumps({'CSV':20,'全セル照合':cells,'未知空欄':nulls,'正式リンク':links,'正式保存':True},ensure_ascii=False))


if __name__=='__main__':main()
