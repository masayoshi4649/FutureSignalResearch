"""207Fの状態を固定し、native・30EMA・前3本端だけを比較する。"""
from collections import Counter,defaultdict
from pathlib import Path
import importlib.util,json,math

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
spec=importlib.util.spec_from_file_location('entry207',ROOT/'work/207VWAP/入口207.py');E=importlib.util.module_from_spec(spec);spec.loader.exec_module(E)
PURE=ROOT/'inputs/00209_TOPIXの固定参照と戻り失敗の純入口'
LINES=('V_native','E_30分EMA21','H_前3本端','M_同側統合')
NAMES=('C0_旧190固定','C1_旧190全帯W15')+tuple(f'{a}_{q}_{w}' for a in LINES for q in E.QUANTITY for w in E.WIDTHS)+tuple(f'C2_E可用時native_QV_{w}' for w in E.WIDTHS)+tuple(f'ADD_{a}_QV_{w}' for a in LINES for w in E.WIDTHS)+tuple(f'DIAG_R反対BBO_{w}' for w in E.WIDTHS)


def long_known(row: dict) -> bool:
    """
    機能: 公表済み30分の既定履歴と有限参照値を確認する。
    引数: row(dict)。
    返り値: bool。方向一致を追加条件にはしない。
    """
    m=row.get('m30')
    return m is not None and m['published']<=row['time'] and m['count']>=8 and m['ema21'] is not None and math.isfinite(m['ema21'])


def seed(row: dict,native: dict,kind: int) -> dict | None:
    """
    機能: 4監視（V/E/H/可用性対照）の価格源を生成する。
    引数: row/native(dict)、kind(int)は0/1/2/3。
    返り値: dict|None。源のnative_levelは共用F状態の固定参照L欄。
    """
    if kind in (1,3) and not long_known(row):return None
    if kind in (0,3):return E.seed(row,native,[],2)
    d=E.direction(row)
    if d not in (-1,1) or not native['native_known']:return None
    level=row['m30']['ema21'] if kind==1 else row['prior_high'] if d==1 else row['prior_low']
    a=row['atr']
    if not .5<=d*(row['close']-level)/a<=2:return None
    end=E.minute_end(row)
    return {'source':E.small_snapshot(row,native),'side':d,'old_direction':d,'role':2,'level':level+d*.25*a,
        'native_level':level,'atr':a,'expiry':row['time']+600,'stage':'接近待ち','recovery':None,'approach':None,
        'prior_ends':[end-180,end-120,end-60],'past_native':None,
        'middle':{k:row['m15'][k] for k in ('ema8','ema21','slope','end','published')},
        'reference_kind':LINES[kind],'reference_price':level,
        'reference_publication':{k:row['m30'][k] for k in ('end','published','count','ema21')} if kind==1 else {'prior_ends':[end-180,end-120,end-60]}}


def generate(features: list,natives: dict) -> tuple:
    """
    機能: 全監視で同じF遷移を使い、線・帯・場別の各段階を数える。
    引数: features(list[dict])、natives(dict)。
    返り値: tuple[dict,dict]はq0別4出生と純支持件数。
    """
    states=[None]*4;scene=None;result={};counts=defaultdict(Counter)
    for row in features:
        key=E.key(row);native=natives[key]
        if scene!=row['session']:scene=row['session'];states=[None]*4
        births=[]
        for kind in range(4):
            name=LINES[kind] if kind<3 else 'C2_E可用時native';state=states[kind];birth=None
            events=[]
            if state is not None:
                before=(state['approach'] is not None,state['recovery'] is not None)
                birth,reason=E.advance(state,row,native)
                if reason:events.append('失効:'+reason);states[kind]=None
                elif birth is not None:
                    events+=['価格保持出生'];events+=['量可用'] if birth['quantity']['known'] else ['量不明'];events+=['量支持'] if birth['quantity']['support'] else ['量支持なし'];states[kind]=None
                else:
                    if not before[0] and state['approach'] is not None:events.append('接近試行')
                    if not before[1] and state['recovery'] is not None:events.append('回復記録')
            else:
                state=seed(row,native,kind)
                if state is not None:states[kind]=state;events.append('源')
            for scope in ('全体',row['band'],row['session']):counts[name+'/'+scope].update(events)
            births.append(birth)
        result[key]=births
    return result,{k:dict(v) for k,v in counts.items()}


def prepare() -> None:
    """
    機能: 全38口座とV6の純同体を確認し、金融前にSource/条件/出生を封印する。
    引数: なし。
    返り値: None。新金融と将来の利益は参照しない。
    """
    proof=E.read(HERE/'人工確認.json');assert proof['成功'] and proof['SourceSHA']==E.ref(Path(__file__))['sha256']
    base,features,natives,inputs=E.load_inputs();maps={E.key(r):r for r in features};generated,counts=generate(features,natives)
    old_path=ROOT/'inputs/00207_TOPIXのVWAPと固定価格の純入口/純入口.json.gz';old=E.read(old_path);oldmap={E.key(r):r for r in old}
    parent_cfg=E.read(ROOT/'work/207VWAP/条件.json');assert E.ref(old_path)['sha256']==parent_cfg['純入口SHA'];inputs.append(E.ref(old_path))
    output=[];checks=0;conflicts=Counter()
    for row in base:
        key=E.key(row);formed=maps.get(key);births=generated.get(key,[None]*4);parent=oldmap[key]
        assert births[0]==parent['births'][2];checks+=1
        signals=[row['signals'][0]]*2;widths=[row['widths'][0],15.];origins=[row['origins'][0]]*2
        adaptive=math.ceil(min(25.,max(5.,formed['atr']*2.5))*4)/4 if formed else None
        choices=[]
        for family in range(4):
            for mode in range(3):
                side,selected,conflict=E.choose(births[:3],family,mode);choices.append({'line_indices':selected,'conflict':conflict})
                if conflict:conflicts[f'{family}/{mode}']+=1
                for wi,w in enumerate((15.,adaptive)):
                    signals.append(side);widths.append(w);origins.append(NAMES[len(origins)])
                    if family==0:
                        previous=14+mode*2+wi;assert side==parent['signals'][previous] and w==parent['widths'][previous];checks+=2
        common=births[3];common_side=common['side'] if common and common['quantity']['support'] else 0
        for w in (15.,adaptive):signals.append(common_side);widths.append(w);origins.append(NAMES[len(origins)])
        for family in range(4):
            side,_,_=E.choose(births[:3],family,2)
            for w in (15.,adaptive):
                original=row['signals'][0];signals.append(original or side);widths.append(row['widths'][0] if original else w)
                origins.append(row['origins'][0] if original else NAMES[len(origins)])
        for wi in range(2):
            signals.append(-parent['signals'][12+wi]);widths.append(parent['widths'][12+wi]);origins.append(NAMES[len(origins)])
        assert len(signals)==38
        output.append({'session':row['session'],'time':row['time'],'line':row['line'],'band':row['band'],
            'signals':signals,'widths':widths,'origins':origins,'births':births,'choices':choices})
    E.save(PURE/'純入口.json.gz',output)
    sources=[Path(__file__),HERE/'人工確認209.py',HERE/'人工確認.json',HERE/'金融前設計案.md']+[ROOT/p for p in parent_cfg['Source']]
    source_map={E.ref(p)['path']:E.ref(p)['sha256'] for p in sources}
    cfg={'試行':209,'候補':list(NAMES),'規模':38,'Source':source_map,'純入口SHA':E.ref(PURE/'純入口.json.gz')['sha256'],
        '入力':inputs,'金融未実行':True,'V6純同体属性':checks,'候補選択':'QVのV/E/H/統合とADDだけ。P/QK/C2/DIAGは対照。',
        '金融条件':'207と同じH60/単純IFD/W15又はA25/単一保有予約/末尾15分/miniTOPIX41.8円+0.25pt片道',
        '情報区分':'全83既使用。前48選択/全80発見/後25/追加7/本日1/追加2を区別。',
        '条件正本':'work/209固定参照/金融前設計案.md','母体期待':parent_cfg['母体期待'],
        'V6期待':[E.ref(ROOT/'study/00207_VWAPと固定価格の時間順入口を量支持で比較する/金融正本'/('TOPIX207_F_native回復失敗継続_'+q+'_'+w+'.json.gz')) for q in E.QUANTITY for w in E.WIDTHS]}
    E.save(HERE/'条件.json',cfg);E.save(HERE/'純封印.json',{'金融未使用':True,'条件':E.ref(HERE/'条件.json'),'純入口':E.ref(PURE/'純入口.json.gz'),
        'V6純同体属性':checks,'全q0':len(output),'段階':counts,'衝突':dict(conflicts)})
    print(json.dumps({'候補':38,'q0':len(output),'V6純同体属性':checks,'全体段階':{k:v for k,v in counts.items() if k.endswith('/全体')},'衝突':dict(conflicts)},ensure_ascii=False))


if __name__=='__main__':prepare()
