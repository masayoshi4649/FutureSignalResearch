"""212の固定全83集計と正式保有区間から候補別CSVの型付き入力を作る。"""
from pathlib import Path
import gzip,hashlib,json,math
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
TRIAL=ROOT/'study/00212_デイとナイトの見送りとnative入口を同じ口座で比較する'
SPECS=((0,'00_旧基準'),(5,'05_昼夜見送り'),(6,'06_昼見送り夜F'),(7,'07_昼夜見送りF'))


def load(path: Path) -> object:
    """
    機能: 正式JSON又はgzip JSONを読む。
    引数: path(Path)。
    返り値: object。
    """
    raw=path.read_bytes();return json.loads(gzip.decompress(raw) if path.suffix=='.gz' else raw)


def held(scene: dict, positions: list, band: str) -> float:
    """
    機能: 帯内の確認済み保有の実時間割合を返す。
    引数: scene(dict),positions(list),band(str)。
    返り値: floatは0〜1、予約と未確認保有を加算しない。
    """
    windows=[(scene['start'],scene['end'])] if band=='NIGHT' else [(p['start'],p['end']) for p in scene['phases'] if p['name']==band]
    assert len(windows)==1;start,end=windows[0];intervals=[]
    for p in positions:
        if p['scene']!=scene['scene']:continue
        stop=p['exit'] if p['exit'] is not None else p['confirmed_until'];assert stop is not None
        a,b=max(start,p['fill']),min(end,stop)
        if a<b:intervals.append((a,b))
    intervals.sort();assert all(intervals[i][0]>=intervals[i-1][1] for i in range(1,len(intervals)))
    return sum(b-a for a,b in intervals)/(end-start)


def main() -> None:
    """
    機能: 4候補の正式集計と保有から20CSV用入力を準備する。
    引数: なし。
    返り値: None。金融の再探索や条件変更はしない。
    """
    state_path=TRIAL/'安定性.json.gz';states=load(state_path)['metrics']
    headers=['候補','開始日又は期間','帯','利益既知寄与_円','損失絶対額既知寄与_円','収支確定_円','累計収支確定_円','建玉回数','未知件数','保有時間率下限','収支既知寄与_円','累計既知寄与_円']
    names={'候補比較':'集計','デイ':'デイ','ナイト全体':'ナイト全体','ナイト_米前':'ナイト_米前','ナイト_米後':'ナイト_米後'}
    tables={n:{'headers':headers,'rows':[]} for n in names};sources=[state_path];comparison=[]
    for ci,title in SPECS:
        state=states[ci];candidate='212:'+title;path=TRIAL/'金融正本'/(state['id']+'.json.gz');pack=load(path);sources.append(path)
        assert pack['id']==state['id'];scenes={s['scene']:s for s in pack['sessions']};assert len(scenes)==83
        for band,group in state['groups'].items():
            if band not in ('ALL','DAY','NIGHT','PRE','POST'):continue
            trades=group['trades'];sessions=group['sessions'];holding=group['holding'];net=trades['known_net'];full=net if not trades['unknown_count'] else None
            tables['候補比較']['rows'].append([candidate,'全83場',band,trades['known_profit'],trades['known_loss'],full,full,trades['all_count'],trades['unknown_count'],holding['held_lower_ratio'],net,net])
            dest={'DAY':'デイ','NIGHT':'ナイト全体','PRE':'ナイト_米前','POST':'ナイト_米後'}.get(band)
            if not dest:continue
            cumulative=0.;complete=True;profit=loss=seconds=0.
            for row in sessions['rows']:
                meta=scenes[row['scene']];cumulative+=row['known_net'];complete=complete and row['complete'];ratio=held(meta,pack['positions'],band)
                duration=meta['end']-meta['start'] if band=='NIGHT' else sum(p['end']-p['start'] for p in meta['phases'] if p['name']==band)
                profit+=row['known_profit'];loss+=row['known_loss'];seconds+=ratio*duration
                tables[dest]['rows'].append([candidate,row['scene'][:10],band,row['known_profit'],row['known_loss'],row['all_net'],cumulative if complete else None,row['all_count'],row['unknown_count'],ratio,row['known_net'],cumulative])
            assert math.isclose(profit,trades['known_profit'],abs_tol=1e-7) and math.isclose(loss,trades['known_loss'],abs_tol=1e-7) and math.isclose(seconds,holding['held_lower_seconds'],abs_tol=1e-7)
            assert len(sessions['rows'])==(42 if band=='DAY' else 41)
            if band=='NIGHT':comparison.append({'候補':candidate,**{k:trades[k] for k in ('known_profit','known_loss','known_net','all_count','unknown_count')},'取得場':sessions['participating_count'],'保有率':holding['held_lower_ratio'],'DD':group['path']['known_contribution']['max_drawdown']['amount'],'赤字取引':trades['negative_rate']['negative_count'],'赤字場':sessions['negative_rate']['negative_count'],'建玉中央値下限':trades['net_median']['lower'],'場中央値下限':sessions['net_median']['lower']})
    data={'tableNames':names,'tables':tables,'入力':[{'path':p.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sources],'Night比較':comparison,'全83既使用':True,'未知':'未知の場収支と以後の確定累計は空欄。既知寄与は別列。'}
    (HERE/'閲覧入力.json').write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n','utf-8');print('4候補20CSV用入力、全83場、利益損失保有同体')


if __name__=='__main__':main()
