"""212の候補別CSVを再読照合し、解説・再現Sourceと指紋を残す。"""
from pathlib import Path
import csv,io,json,math,hashlib,shutil,zipfile,re
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
TRIAL=ROOT/'study/00212_デイとナイトの見送りとnative入口を同じ口座で比較する'
OUT=ROOT/'outputs/00212_TOPIXの帯別入口と損失安定性'


def ref(path: Path) -> dict:
    """
    機能: 資源のリポジトリ相対位置・サイズ・内容指紋を返す。
    引数: path(Path)。
    返り値: dict。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


def main() -> None:
    """
    機能: 20CSVの全セル・累計・未知空欄を検査して閲覧を正式化する。
    引数: なし。
    返り値: None。売買条件・金融・事前選択は変更しない。
    """
    data=json.loads((HERE/'閲覧入力.json').read_text('utf-8'));proof=json.loads((ROOT/'work/212CSV検査/作成確認.json').read_text('utf-8'));cells=nulls=0
    for item in proof['files']:
        raw=(OUT/item['相対path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==item['sha256'];rows=list(csv.reader(io.StringIO(raw.decode('utf-8-sig'))))
        table=data['tables'][item['元表']];expected=[table['headers']]+[r for r in table['rows'] if r[0]==item['候補']];assert len(rows)==len(expected)
        for actual,source in zip(rows,expected,strict=True):
            assert len(actual)==len(source)
            for a,b in zip(actual,source,strict=True):
                cells+=1
                if b is None:assert a=='';nulls+=1
                elif isinstance(b,(int,float)):assert math.isclose(float(a),b,abs_tol=1e-7)
                else:assert a==b
        for row in rows[1:]:assert math.isclose(float(row[3])-float(row[4]),float(row[10]),abs_tol=1e-7)
        if item['元表']!='候補比較':
            total=0.;complete=True
            for row in rows[1:]:
                total+=float(row[10]);complete=complete and int(row[8])==0;assert math.isclose(float(row[11]),total,abs_tol=1e-7)
                if complete:assert math.isclose(float(row[6]),total,abs_tol=1e-7)
                else:assert row[6]==''
    assert len(proof['files'])==20 and cells==8400 and nulls>0
    proof.update(CSV全セル再読=cells,未知空欄セル数=nulls,累計算術検査=True,全Day42とNight41を保持=True,全20表の描画を目視確認=True)
    support=TRIAL/'閲覧資料';support.mkdir(exist_ok=True);(support/'CSV確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n','utf-8');shutil.copy2(HERE/'閲覧入力.json',support/'閲覧入力.json')
    sources=[HERE/'閲覧入力212.py',Path(__file__),ROOT/'scripts/損益CSV/候補別に出力する.mjs']
    with zipfile.ZipFile(support/'閲覧Source.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in sources:z.write(p,p.relative_to(ROOT).as_posix())
    (support/'Source索引.json').write_text(json.dumps([ref(p) for p in sources],ensure_ascii=False,indent=2)+'\n','utf-8')
    descriptions={'00_旧基準':'旧190D4/N01。今回のDay/Night見送りとFを加える前の対照。','05_昼夜見送り':'Day210主3の長期矛盾見送り＋Night208主3の浅押戻し逆張り見送り。事前に置いた保守的対照。','06_昼見送り夜F':'当面の閲覧主候補。Dayは210主3、Nightは209ADD_V/W15。全口座の損失・赤字回数とDDを旧より減らした既使用の発見。','07_昼夜見送りF':'損失額優先の比較。Day210主3＋Night208主3＋固定F。Fが見送りを迂回しない。6より損失総額は小さいがDDは大きい。'}
    for title,description in descriptions.items():
        folder=OUT/('212_'+title)
        (folder/'README.md').write_text(f'''# 212:{title}

{description}

2026-09-21〜11-17、デイ42・ナイト41の全83場は既使用。miniTOPIX1枚、1pt=1,000円、片道税込41.8円＋0.25pt、往復583.6円。ラージBBO約定代用。単純IFD Day A25/Night W15/H60、保有予約合計1、開始待機なし、終了15分前決済。A25は当時ATR5×2.5を5〜25ptへ制限し0.25切上げ。

[集計](集計.csv) / [デイ](デイ.csv) / [ナイト全体](ナイト全体.csv) / [ナイト米国前](ナイト_米前.csv) / [ナイト米国後](ナイト_米後.csv)。

利益・損失は費用後既知取引の寄与。未知がある場の確定収支とそれ以降の確定累計は空欄で、0円ではない。既知寄与を別列へ残す。0取引場も行を保持し、累計は候補・帯ごとに0から始める。

保有時間率下限は対象実時間に占める確認済み保有（0〜1）。末尾15分を除き、予約と未確認保有は算入しない。損益は新規帯、保有は実際の時間重複に帰属する。ナイト全体と米前/米後を重複加算しない。

[候補比較と限界](../README.md) / [研究正本](../../../study/00212_デイとナイトの見送りとnative入口を同じ口座で比較する/README.md)。
''','utf-8')
    states=json.loads(__import__('gzip').decompress((TRIAL/'安定性.json.gz').read_bytes()))['metrics']
    body='''# TOPIXの帯別入口と損失安定性・全83場

まず[06_昼見送り夜F](212_06_昼見送り夜F/README.md)と[00_旧基準](212_00_旧基準/README.md)を比較する。6を当面の閲覧主候補として置く。未見の安定採用ではなく、固定済みの前48/全80選択を差し替えたものでもない。

[05_昼夜見送り](212_05_昼夜見送り/README.md)は保守的対照、[07_昼夜見送りF](212_07_昼夜見送りF/README.md)は損失額優先の比較。7は損失をより減らす一方、累計口座DDが6より大きい。

## 全口座83場

miniTOPIX1枚・費用後・円。全案80/83場取得・未知7、両中央値下限は正。未知を除く既知寄与であり確定口座収支ではない。

|候補|取得|利益既知寄与|損失既知寄与|収支既知寄与|赤字取引|赤字場|保有下限|場末DD既知寄与|
|---|---:|---:|---:|---:|---:|---:|---:|---:|
'''
    for i,title in ((0,'00_旧基準'),(5,'05_昼夜見送り'),(6,'06_昼見送り夜F'),(7,'07_昼夜見送りF')):
        g=states[i]['groups']['ALL'];t=g['trades'];s=g['sessions'];body+=f"|[{title}](212_{title}/README.md)|{t['all_count']}|{t['known_profit']:,.1f}|{t['known_loss']:,.1f}|{t['known_net']:,.1f}|{t['negative_rate']['negative_count']}|{s['negative_rate']['negative_count']}|{g['holding']['held_lower_ratio']:.2%}|{g['path']['known_contribution']['max_drawdown']['amount']:,.1f}|\n"
    body+='''
6は旧より損失50,501.6円減・赤字取引181→175・赤字場27→25・DD106,343.2→100,426円。7は損失67,585.2円減・赤字取引174だがDD107,342.4円。期間中のDD窓ではAにより10/26Nightの旧売り＋6,916.4円を取得しない差がある。

Dayの主条件は42/42場209取得・未知0・保有53.94%。Nightは6が38/41場177取得・保有29.54%、7が同38場173取得・28.78%。未参加3Nightと金融未知7は残る。Dayの前48は−10,279.6円、Day取引連敗8、初期損失−28,501.6円と水面下14場も残る。

Fの新枝は6/7で同じ5取得・利益27,165.6/損失5,083.6/収支22,082円。F追加のNight口座差は前48−5,000円・後25＋46,416.4円。追加7/本日1/追加2は同体で新効果の再現例ではない。全83は探索に既使用で、支持の少なさを総取得数で覆い隠さない。

## 読み方と検査

デイ42行・ナイト41行、0取引場を残す。未知の確定収支/確定累計は空欄。利益−損失は既知寄与へ一致する。保有率は全対象時間の率で、全場20%達成ではない。DDは場末の既知実現寄与であり保有中最大時価DDではない。

[全8条件・支持・原因・選択](../../study/00212_デイとナイトの見送りとnative入口を同じ口座で比較する/README.md) / [20CSV・8,400セル確認](../../study/00212_デイとナイトの見送りとnative入口を同じ口座で比較する/閲覧資料/CSV確認.json) / [再現資料](../../study/00212_デイとナイトの見送りとnative入口を同じ口座で比較する/閲覧資料/README.md)。この比較可能な状態で新探索を一旦止める。
'''
    (OUT/'README.md').write_text(body,'utf-8')
    (support/'README.md').write_text('''# 212候補別CSVの再現

[閲覧入口](../../../outputs/00212_TOPIXの帯別入口と損失安定性/README.md)。0/5/6/7の4候補を各5CSVへ分離。[型付き入力](閲覧入力.json)・[照合](CSV確認.json)・[Source](閲覧Source.zip)・[索引](Source索引.json)。

閲覧入力212.pyは正式安定性と正式金融の保有区間だけを読み、売買条件や金融を再探索しない。型付きJSONをscripts/損益CSV/候補別に出力する.mjsへ --input、--output 新規出力先、--proof 新規確認先、--dependencies Codex提供node_modulesで渡す。Node24.22.1とCodex提供artifact-tool、全セル設定・recalculate・描画確認後に出力。別Python csvで20CSV8,400セル・未知空欄・累計・利益損失を照合した。UTF-8 BOM/CRLF。xlsxは作成しない。
''','utf-8')
    p=TRIAL/'README.md';text=p.read_text('utf-8');link='[候補別CSV](../../outputs/00212_TOPIXの帯別入口と損失安定性/README.md)'
    if link not in text:p.write_text(text+'\n## 閲覧主候補と一旦停止\n\n'+link+'に旧0・保守的5・閲覧主6・損失額比較7を分離した。6を当面の閲覧主候補とするが、既定選択nullは保持。Day前48−10,279.6円・取引連敗8、F5件支持・前48Night悪化、未知7と未参加3Nightを残す。全口座と第三者検査の結果を比較可能にして、新探索を一旦止める。\n','utf-8')
    manifest=json.loads((TRIAL/'保存索引.json').read_text('utf-8'));manifest['正本']=[ref(p) for p in sorted(TRIAL.rglob('*')) if p.is_file() and p.name!='保存索引.json']+[ref(p) for p in sorted((ROOT/'inputs/00212_TOPIXの帯別固定入口の組合せ').glob('*'))]+[ref(p) for p in sorted(OUT.rglob('*')) if p.is_file()]
    (TRIAL/'保存索引.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n','utf-8');links=0
    for p in [*TRIAL.rglob('*.md'),*OUT.rglob('*.md')]:
        for link in re.findall(r'\]\(([^)]+)\)',p.read_text('utf-8')):
            if '://' in link or link.startswith('#'):continue
            assert (p.parent/link.split('#')[0]).resolve().exists(),(p,link);links+=1
    print(json.dumps({'CSV':20,'セル':cells,'未知空欄':nulls,'正式リンク':links},ensure_ascii=False))


if __name__=='__main__':main()
