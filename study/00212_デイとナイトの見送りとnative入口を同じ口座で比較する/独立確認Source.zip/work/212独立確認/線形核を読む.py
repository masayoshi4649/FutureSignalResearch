"""恒久211監査Sourceから線形セル核だけを読み、金融実装の再利用を避ける。"""
from pathlib import Path
from types import ModuleType,SimpleNamespace
from datetime import datetime,timedelta,timezone
from zoneinfo import ZoneInfo
from bisect import bisect_left,bisect_right
import ast
import hashlib
import json
import math
import sys
import zipfile
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
STUDY=ROOT/'study/00211_固定TOPIX入口に対するIFD期限の寄与を調べる'


# ----------------------------------------
def load() -> SimpleNamespace:
    """
    機能: 固定ZIP内の独立集計器と、直接BBO走査2関数だけを読み込む。
    引数: なし。
    返り値: SimpleNamespaceはload_arrays/oracle/VとSource指紋。211の金融runnerはimportしない。
    """
    archive=STUDY/'Source.zip';index=json.loads((STUDY/'Source索引.json').read_text(encoding='utf-8'))
    assert hashlib.sha256(archive.read_bytes()).hexdigest()==index['ZIP']['sha256']
    indexed={r['path']:r for r in index['資源']};members=(
        'work/183損失安定性/新候補の集計を独立検査する.py',
        'work/183損失安定性/TOPIXを独立検算する.py',
        'work/211期限比較/独立確認211.py')
    with zipfile.ZipFile(archive) as z:
        bodies={name:z.read(name) for name in members}
    for name,body in bodies.items():assert hashlib.sha256(body).hexdigest()==indexed[name]['sha256']
    for name,module_name in zip(members[:2],('新候補の集計を独立検査する','TOPIX211固定独立集計'),strict=True):
        module=ModuleType(module_name);module.__file__=str(ROOT/name);sys.modules[module_name]=module
        exec(compile(bodies[name],str(archive)+'!/'+name,'exec'),module.__dict__)
    verifier=module
    tree=ast.parse(bodies[members[2]].decode('utf-8'))
    selected=[node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name in ('load_arrays','oracle')]
    assert [node.name for node in selected]==['load_arrays','oracle']
    scope={'V':verifier,'np':np,'math':math,'datetime':datetime,'timedelta':timedelta,'ZoneInfo':ZoneInfo,
           'bisect_left':bisect_left,'bisect_right':bisect_right}
    exec(compile(ast.Module(body=selected,type_ignores=[]),str(archive)+'!/線形核2関数','exec'),scope)
    return SimpleNamespace(load_arrays=scope['load_arrays'],oracle=scope['oracle'],V=verifier,
        proof={'恒久ZIP':{'path':archive.relative_to(ROOT).as_posix(),'sha256':index['ZIP']['sha256']},
               '使用資源':[indexed[n] for n in members],'線形関数':['load_arrays','oracle'],'211金融runner不使用':True})


# ----------------------------------------
if __name__=='__main__':
    kernel=load();assert kernel.oracle({'now':np.array([]),'force':0},0,1,1,15,'H60') is None
    print(json.dumps({'成功':True,**kernel.proof},ensure_ascii=False))
