"""212の八口座を線形BBO接触、別の一枠状態、親帯同体で確認する。"""
from pathlib import Path
from collections import defaultdict,Counter
import math
import sys
import 純結合を照合212 as P
import 線形核を読む as K

ROOT=P.ROOT;HERE=P.HERE;TARGET=P.TARGET
sys.path.insert(0,str(ROOT/'scripts/TOPIX入口研究'))
import 共通金融 as C


# ----------------------------------------
def resources() -> list:
    """
    機能: 全83の正式原順8列を親manifestから別に組み立てる。
    引数: なし。
    返り値: list[dict]は場順・絶対位置・SHA。共通金融のentriesは呼ばない。
    """
    rows=P.read(ROOT/'inputs/TOPIX原順8列_20260921_20261116/台帳.json')['entries'];result=[]
    for row in rows:
        path=ROOT/row['path'];assert P.ref(path)['sha256']==row['sha256']
        result.append({'session':row['session'],'cache_absolute':str(path),'sha256_cache':row['sha256']})
    extra=P.read(ROOT/'inputs/00194_20261116夜と1117昼の固定適用入力/原順8列/入力台帳.json')['entries']
    for row in extra:
        if row['symbol']=='TOPIX':
            assert P.ref(Path(row['cache_absolute']))['sha256']==row['sha256_cache'];result.append(row)
    assert len(result)==83 and [r['session'] for r in result[80:]]==['2026-11-16_Day','2026-11-16_Night','2026-11-17_Day']
    return result


# ----------------------------------------
def project(pack: dict,kind: str) -> dict:
    """
    機能: 順序を保ってDay/Nightの台帳・保有・場を射影する。
    引数: pack(dict)、kind(str)。
    返り値: dict。親により表示だけ異なるorigin以外を残す。
    """
    scenes=[s for s in pack['sessions'] if s['kind']==kind];names={s['scene'] for s in scenes}
    indices=[i for i,scene in enumerate(pack['ledger']['scene']) if scene in names]
    return {'sessions':scenes,'positions':[p for p in pack['positions'] if p['scene'] in names],
            'ledger':{k:[v[i] for i in indices] for k,v in pack['ledger'].items() if k!='origin'}}


# ----------------------------------------
def parent_checks(packs: list) -> list:
    """
    機能: 事前の親期待を元親へ照合後、新八口座の周辺帯を全件比較する。
    引数: packs(list[dict])は候補順。
    返り値: list[dict]は帯別確認票。AFを親の合算で評価しない。
    """
    parents=P.read(TARGET/'金融前親期待.json.gz')['親'];proof=[]
    for key,item in parents.items():
        path=ROOT/item['指紋']['path'];assert P.ref(path)==item['指紋'];pack=P.read(path)
        for kind,expected in item['帯'].items():assert project(pack,kind)==expected
    for ci,pack in enumerate(packs):
        day,night=divmod(ci,4);dkey='D1' if day else '旧'
        assert project(pack,'DAY')==parents[dkey]['帯']['DAY']
        proof.append({'候補':pack['id'],'帯':'DAY','親':dkey,'同体':True})
        if night!=3:
            nkey=('旧','A','F')[night];assert project(pack,'NIGHT')==parents[nkey]['帯']['NIGHT']
            proof.append({'候補':pack['id'],'帯':'NIGHT','親':nkey,'同体':True})
    assert project(packs[3],'NIGHT')==project(packs[7],'NIGHT')
    old=P.read(ROOT/parents['旧']['指紋']['path']);shadow={**packs[0],'id':old['id']};assert shadow==old
    return proof+[{'旧0全pack同体_IDのみ別':True},{'AFのDay違いによるNight全体同体':True}]


# ----------------------------------------
def run() -> None:
    """
    機能: 固定金融八口座の原順セル・全後続枠・費用・終了前・未知・集計を照合する。
    引数: なし。
    返り値: None。新候補の選択や固定Sourceの変更は行わない。
    """
    cfg=P.seals();pure_proof=P.read(HERE/'純結合の第三者照合.json');assert pure_proof['条件']==P.ref(TARGET/'条件.json')
    folder=TARGET/'金融';start=P.read(folder/'金融開始前固定.json');assert start['条件']['sha256']==P.ref(TARGET/'条件.json')['sha256']
    kernel=K.load();states=P.read(folder/'安定性.json.gz')['metrics'];assert len(states)==8
    packs=[P.read(folder/'金融正本'/(s['id']+'.json.gz')) for s in states];refs=[P.ref(folder/'安定性.json.gz')]
    refs += [P.ref(folder/'金融正本'/(p['id']+'.json.gz')) for p in packs]
    assert [p['id'] for p in packs]==['TOPIX212_'+name for name in cfg['候補']]
    parent=parent_checks(packs);rows=P.read(P.PURE);by=defaultdict(list)
    for row in rows:by[row['session']].append(row)
    inputs=resources();scene_names=[r['session'] for r in inputs];cells=cell_attrs=slot_attrs=fees=0;diagnostics=[];new_f=Counter()
    for pack,state in zip(packs,states,strict=True):
        assert [s['scene'] for s in pack['sessions']]==scene_names
        expected={'全80':scene_names[:80],'前48':scene_names[:48],'後25':scene_names[48:73],'追加7':scene_names[73:80],
                  '本日1':scene_names[80:81],'旧81':scene_names[:81],'追加2':scene_names[81:]}
        assert set(state['periods'])==set(expected)
        for period,names in expected.items():
            assert [r['scene'] for r in state['periods'][period]['ALL']['sessions']['rows']]==names
    for entry in inputs:
        a=kernel.load_arrays(entry);scene=entry['session'];cache={};production=C.M.Route(entry)
        for row in by[scene]:
            for ci,side in enumerate(row['signals']):
                if side:
                    key=(row['time'],row['line'],side,row['widths'][ci])
                    if key not in cache:
                        cache[key]=kernel.oracle(a,*key,'H60');assert cache[key]==production.cell(*key),(scene,key);cells+=1
                    if row['parent_branch'][ci]=='F':
                        assert not scene.endswith('Day') and row['widths'][ci]==15;new_f[f'{ci}/純F']+=1
        # ----------------------------------------
        # セルの期待値は線形核のみ。生産Routeを再実行せず全台帳への到達と保有枠を比較する。
        for ci,pack in enumerate(packs):
            ledger=pack['ledger'];indices=[i for i,s in enumerate(ledger['scene']) if s==scene]
            positions=[p for p in pack['positions'] if p['scene']==scene];cursor=0;release=-math.inf;pending=False
            count={'純成立':0,'保有棄却':0,'予約棄却':0,'取得':0,'失効':0}
            for row in by[scene]:
                side=row['signals'][ci]
                if not side:continue
                count['純成立']+=1
                if row['time']<=release:count['予約棄却' if pending else '保有棄却']+=1;continue
                cell=cache[(row['time'],row['line'],side,row['widths'][ci])]
                if cell is None:count['失効']+=1;release=min(row['time']+30,a['force']);pending=True;continue
                count['取得']+=1;pending=False;release=a['end'] if cell['unknown'] else cell['exit_time']
                assert cursor<len(indices);i=indices[cursor];cursor+=1
                net=None if cell['unknown'] else round(side*(cell['exit_price']-cell['entry_price'])*1000-83.6-500,1)
                expectation={'scene':scene,'phase':{'DAY':0,'PRE':1,'POST':2}[cell['band']],'known':not cell['unknown'],
                             'net':net,'origin':row['origins'][ci]}
                for name,values in ledger.items():
                    assert values[i]==(expectation[name] if name in expectation else cell[name]),(pack['id'],scene,i,name);slot_attrs+=1
                expected={'scene':scene,'fill':cell['entry_time'],'exit':cell['exit_time'],'confirmed_until':cell['known_until'],
                          'possible_until':a['end'] if cell['unknown'] else cell['exit_time']}
                assert positions[cursor-1]==expected;slot_attrs+=5;fees+=net is not None;cell_attrs+=len(cell)
                assert a['start']<=cell['entry_time']<a['force'] and (cell['exit_time'] is None or cell['exit_time']<a['end'])
                if row['parent_branch'][ci]=='F':new_f[f'{ci}/取得F']+=1
            assert cursor==len(indices)==len(positions)
            expected={'scene':scene,**count};assert next(d for d in pack['diagnostics'] if d['scene']==scene)==expected
            diagnostics.append({'id':pack['id'],**expected})
    statistic=sum(kernel.V.inspect_groups(pack,state) for pack,state in zip(packs,states,strict=True))
    assert all(P.ref(ROOT/r['path'])==r for r in refs);P.seals()
    P.save(HERE/'金融の第三者照合.json.gz',{'成功':True,'条件':P.ref(TARGET/'条件.json'),'純確認':P.ref(HERE/'純結合の第三者照合.json'),
        '全口座':8,'全場':83,'親周辺帯同体':parent,'全ユニーク成立セルを線形評価':cells,'実取得セル属性':cell_attrs,'枠台帳属性':slot_attrs,
        '既知費用式':fees,'別算術集計属性':statistic,'新F純と取得':dict(new_f),'枠診断':diagnostics,'金融正本':refs,
        '線形核':kernel.proof,'Source':[P.ref(Path(__file__)),P.ref(Path(P.__file__)),P.ref(Path(K.__file__))],
        '範囲':'生産Route/到達木を期待値に使わず原順8列で全成立セルを作成し、生産セル全件と比較。全後続要求の取得台帳を別一枠状態で比較。原JSON再抽出ではない。'})
    print({'成功':True,'ユニーク成立セル':cells,'枠台帳属性':slot_attrs,'費用式':fees,'集計属性':statistic,'F':dict(new_f)})


# ----------------------------------------
if __name__=='__main__':run()
