"""第三者側で固定親の行列から結合8条件を別の式で照合する。"""
from pathlib import Path
from collections import Counter
from datetime import datetime,timedelta,timezone
from zoneinfo import ZoneInfo
import ast
import gzip
import hashlib
import json
import sys

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent;TARGET=ROOT/'work/212帯別固定入口'
PURE=ROOT/'inputs/00212_TOPIXの帯別固定入口の組合せ/純入口.json.gz'


# ----------------------------------------
def read(path: Path) -> object:
    """
    機能: JSON正本を読む。
    引数: path(Path)。
    返り値: object。
    """
    raw=path.read_bytes();return json.loads(gzip.decompress(raw) if path.suffix=='.gz' else raw)


# ----------------------------------------
def ref(path: Path) -> dict:
    """
    機能: 正本資源の相対位置とSHAを求める。
    引数: path(Path)。
    返り値: dict。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


# ----------------------------------------
def save(path: Path,value: object) -> None:
    """
    機能: 新規又は同体の検査票だけを保存する。
    引数: path(Path)、value(object)。
    返り値: None。
    """
    raw=(json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode()
    if path.suffix=='.gz':raw=gzip.compress(raw,mtime=0)
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():assert path.read_bytes()==raw,path
    else:path.write_bytes(raw)


# ----------------------------------------
def seals() -> dict:
    """
    機能: 条件・純出生・親・全金融Sourceの指紋を検査する。
    引数: なし。
    返り値: dictは条件。
    """
    cfg=read(TARGET/'条件.json');ticket=read(TARGET/'純封印.json')
    assert ticket['条件']==ref(TARGET/'条件.json') and ticket['純入口']==ref(PURE)
    assert ref(PURE)['sha256']==cfg['純入口SHA']
    for name,sha in cfg['Source'].items():assert ref(ROOT/name)['sha256']==sha,name
    for row in cfg['入力']:assert ref(ROOT/row['path'])==row,row['path']
    for name in ('scripts/入口分析/分析.py','scripts/複合検証/再生.py','study/00001_MACDと方向条件の比較/再現.py'):
        assert name in cfg['Source']
    return cfg


# ----------------------------------------
def run() -> None:
    """
    機能: 金融前に親集合・別式結合・AF迂回禁止・幅とorigin・帯を全件照合する。
    引数: なし。
    返り値: None。金融の値・ラベルは読まない。
    """
    cfg=seals();assert not (TARGET/'金融/金融開始前固定.json').exists(),'新金融開始前の検査が必要'
    day=read(ROOT/'inputs/00210_TOPIXデイの背景矛盾と成熟待ちの純入口/純入口.json.gz')
    night=read(ROOT/'inputs/00208_TOPIXの役割別見送りと構造反転の純入口/純入口.json.gz')+read(ROOT/'inputs/00208_TOPIXの役割別見送りと構造反転の純入口/追加二場純入口.json.gz')
    extra=read(ROOT/'inputs/00209_TOPIXの固定参照と戻り失敗の純入口/純入口.json.gz');actual=read(PURE)
    assert len(actual)==len(day)==len(night)==len(extra)==35361
    counts=Counter();previous={};seen=set();checks=0
    for dr,ar,fr,row in zip(day,night,extra,actual,strict=True):
        key=(row['session'],row['line']);assert key not in seen;seen.add(key)
        assert all(tuple(r[k] for k in ('session','time','line'))==tuple(row[k] for k in ('session','time','line')) for r in (dr,ar,fr));checks+=9
        scene=row['session'];clock=row['time'];is_day=scene.endswith('_Day')
        if scene in previous:assert previous[scene][0]<=clock and previous[scene][1]<row['line'];checks+=2
        previous[scene]=(clock,row['line'])
        session_start=datetime.fromisoformat(scene[:10]).replace(tzinfo=timezone(timedelta(hours=9)))+timedelta(hours=17)
        ny_date=session_start.astimezone(ZoneInfo('America/New_York')).date()
        opening=datetime.combine(ny_date,datetime.min.time(),ZoneInfo('America/New_York'))+timedelta(hours=9,minutes=30)
        band='DAY' if is_day else ('PRE' if clock<opening.timestamp() else 'POST')
        assert all(r['band']==band for r in (dr,ar,fr,row));checks+=4
        old=fr['signals'][0];a=ar['signals'][3];f=fr['signals'][6];not_old=int(old==0)
        assert dr['signals'][0]==ar['signals'][0]==old and a in (0,old) and dr['signals'][3] in (0,old);checks+=4
        night_sides=[old,a,old+not_old*f,a+not_old*f]
        branches=['旧','A','F' if not_old else '旧','F' if not_old else 'A']
        night_widths=[fr['widths'][0],ar['widths'][3],fr['widths'][6] if not_old else fr['widths'][0],fr['widths'][6] if not_old else ar['widths'][3]]
        for ci in range(8):
            d,n=divmod(ci,4)
            if is_day:
                s=dr['signals'][3*d];w=dr['widths'][3*d];origin=fr['origins'][0];branch=['旧','D1'][d]
            else:
                s=night_sides[n];w=night_widths[n];branch=branches[n];origin=fr['origins'][28 if branch=='F' else 0]
            assert (row['signals'][ci],row['widths'][ci],row['origins'][ci],row['parent_branch'][ci])==(s,w,origin,branch);checks+=4
            if s:counts[f'{ci}/{band}/{branch}']+=1
            if not is_day and n==2:assert s==fr['signals'][28] and (not s or w==fr['widths'][28]);checks+=2
        if not is_day and old and not a:
            assert row['signals'][3]==row['signals'][7]==0;counts['A棄却q0']+=1
            if f:counts['A棄却とF同時q0']+=1
        if not is_day and not old and f:
            assert row['signals'][2]==row['signals'][3]==row['signals'][6]==row['signals'][7]==f
            assert fr['widths'][6]==15.;counts['元旧なしF出生q0']+=1
    assert len(previous)==83
    # ----------------------------------------
    # 生産night関数だけをASTで読み、実データにない同時衝突も全列挙する。純生成は実行しない。
    tree=ast.parse((TARGET/'入口212.py').read_text(encoding='utf-8'));nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='night'];scope={}
    assert len(nodes)==1;exec(compile(ast.Module(body=nodes,type_ignores=[]),'固定night関数のみ','exec'),scope)
    artificial=0
    for old in (-1,0,1):
        for a in set((0,old)):
            for f in (-1,0,1):
                expected=[old,a,old+int(old==0)*f,a+int(old==0)*f]
                for mode,s in enumerate(expected):
                    out=scope['night'](old,a,f,mode);mirror=scope['night'](-old,-a,-f,mode)
                    assert out[0]==s and mirror[0]==-s and out[1]==mirror[1];artificial+=3
    seals()
    save(HERE/'純結合の第三者照合.json',{'成功':True,'金融未使用':True,'全q0':len(actual),'全場':83,'別式属性':checks,'全組合せ人工属性':artificial,
       '条件':ref(TARGET/'条件.json'),'純封印':ref(TARGET/'純封印.json'),'純入口':ref(PURE),'Source':ref(Path(__file__)),
       '純支持':dict(counts),'動的推移依存3資源の直接封印':True,'制約':'親の源状態・特徴は再計算しない。固定純出生の同原行結合とAF優先を検査する。'})
    print(json.dumps({'成功':True,'別式属性':checks,'人工属性':artificial,'純支持':dict(counts)},ensure_ascii=False))


# ----------------------------------------
if __name__=='__main__':run()
