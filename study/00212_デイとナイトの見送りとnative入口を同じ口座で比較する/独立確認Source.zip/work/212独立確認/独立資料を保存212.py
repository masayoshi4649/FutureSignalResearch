"""第三者監査票と必要な小Sourceを、212の主保存とは別に恒久化する。"""
from pathlib import Path
import hashlib
import zipfile
import 純結合を照合212 as P
import 金融を照合212 as F

STUDY=P.ROOT/'study/00212_デイとナイトの見送りとnative入口を同じ口座で比較する'


# ----------------------------------------
def main() -> None:
    """
    機能: 事前純照合・事後金融照合を固定参照へ束縛して別ZIPへ保存する。
    引数: なし。
    返り値: None。主条件・金融Source・主READMEには触れない。
    """
    P.seals();pure=P.read(P.HERE/'純結合の第三者照合.json');finance=P.read(P.HERE/'金融の第三者照合.json.gz')
    assert pure['成功'] and finance['成功'] and finance['純確認']==P.ref(P.HERE/'純結合の第三者照合.json')
    start=P.read(P.TARGET/'金融/金融開始前固定.json');resources=F.resources();assert len(start['原順入力'])==len(resources)==83
    raw_refs=[]
    for expected,actual in zip(start['原順入力'],resources,strict=True):
        assert expected['session']==actual['session'];path=Path(actual['cache_absolute']);current=P.ref(path)
        assert current['sha256']==expected['ref']['sha256'] and current['bytes']==expected['ref']['bytes'];raw_refs.append({'scene':actual['session'],'ref':current})
    parent=P.read(P.TARGET/'金融前親期待.json.gz')['親'];parent_refs=[]
    for row in parent.values():
        assert P.ref(P.ROOT/row['指紋']['path'])==row['指紋'];parent_refs.append(row['指紋'])
    for item in finance['金融正本']:assert P.ref(P.ROOT/item['path'])==item
    for name in ('純結合の第三者照合.json','金融の第三者照合.json.gz'):
        P.save(STUDY/'監査'/name,P.read(P.HERE/name))
    refs={'条件':P.ref(P.TARGET/'条件.json'),'金融開始前票':P.ref(P.TARGET/'金融/金融開始前固定.json'),
          '親期待':P.ref(P.TARGET/'金融前親期待.json.gz'),'親正本':parent_refs,'全原順入力':raw_refs,
          '監査票':[P.ref(STUDY/'監査'/name) for name in ('純結合の第三者照合.json','金融の第三者照合.json.gz')],
          '線形核':finance['線形核'],'Source':P.ref(Path(__file__)),'事後資源束縛':True}
    P.save(STUDY/'監査/独立確認の参照資源.json',refs)
    # ----------------------------------------
    # 210親全packは正式JSONがないため小期待として保存。208親は既存211Source.zipを再用する。
    paths=[P.HERE/'線形核を読む.py',P.HERE/'純結合を照合212.py',P.HERE/'金融を照合212.py',Path(__file__),
           P.ROOT/parent['D1']['指紋']['path']]
    archive=STUDY/'独立確認Source.zip';assert not archive.exists()
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for path in paths:
            info=zipfile.ZipInfo(path.relative_to(P.ROOT).as_posix(),date_time=(2026,11,18,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,path.read_bytes())
    index={'ZIP':P.ref(archive),'資源':[P.ref(p) for p in paths],'外部恒久核':finance['線形核'],
           '説明':'主金融Sourceとは別の監査Source。211ZIP内の独立核/集計器と208親期待を再用し、原板・純入力を複製しない。'}
    P.save(STUDY/'独立確認Source索引.json',index)
    with zipfile.ZipFile(archive) as z:
        for row in index['資源']:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
    P.save(STUDY/'監査/独立Source展開確認.json',{'成功':True,'ZIP':P.ref(archive),'資源':len(paths),'内容SHA同体':True})
    print({'成功':True,'資源':len(paths),'ZIP容量':archive.stat().st_size})


# ----------------------------------------
if __name__=='__main__':main()
