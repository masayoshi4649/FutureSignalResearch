# 保有参加時間と利益集中の純部品

`activity179.py` は自然入力・金融結果を読まない純集計。F0固定時SHAは `1dde8382c828681e071ba62ec438189b6353b90db9278f372183e4fd36101b55`。

## 保有時間

`holding_summary(sessions, positions, target_ratio=.2)`。

- sessions：`scene`, `kind`（DAY/NIGHT）, `start`, `end`, `phases=[{name,start,end}]`。任意`original_end`, `close_deadline`。帯窓は対象時計全域を隙間・重複なく覆う。
- positions：実取得の`scene`, `fill`, `exit`, `confirmed_until`, `possible_until`, `quantity`。status省略はfilled。pending/unfilled/cancelled/expiredは保有へ算入しない。
- 既知exitは保有時計を確定。未知exitの下限はconfirmed_until（省略はfill）、上限はpossible_until（省略は対象end）。観測不足の管理上場末占有は下限に使わない。
- 分母はstart～end。original_end、欠測、未決、無保有で分母を変更しない。複数枚は区間の和集合、跨帯は実秒を配分。

出力`groups[DAY/NIGHT/PRE/POST/ALL]`に対象秒・下限/上限秒・全時間加重率・場中央値境界・場ごとのrowsを保持する。target_statusは達成/不確定/未達/評価不能。下限だけで20%以上の時に保証達成とする。場中央値と全時間加重率、各場の達成数は別指標。

`closure`は既知期限違反・未知退出・flat保証を別表示する。評価域上限をcutへ切ったことは、決済約定の証明ではない。未知exitはflat保証をしない。

## 金融

`financial_diagnostics(group)`。metrics173の`trades/sessions.rows/decision`を渡す。

`concentration`は場内既知利益総額`gross_profit`、正の既知寄与場純益`positive_scene_net`、全件確定場だけの正純益`positive_complete_scene_net`を区別する。各`top`で上位1/3/5場のシェア・除外後利益/損失/既知純益・完全純益・残存未知を示す。正の順位値を持たない場を便宜的に除かない。

黒字/赤字/ゼロの完全場・未知場・0取得場、取得数の度数/中央値/集中、両中央値判定を保持する。`path`は固定path175の完全経路・既知寄与・完全窓を返す。集中は事後診断であり、入口時点の特徴ではない。

## 人工確認

`人工検査.py`で11検査と整数秒の別占有展開16,000セルを確認。`人工サンプル.json`は両APIの入力と全出力、未知退出例を含む。`人工結果.json`にSource指紋と検査結果を保存した。
