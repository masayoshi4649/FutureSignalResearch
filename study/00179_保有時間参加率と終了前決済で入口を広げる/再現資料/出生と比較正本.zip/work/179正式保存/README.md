# 179固定10政策の保存と再現

178までのSource連鎖を元byte継承し、179 Sourceだけを薄いZIPへ追加する。CSV出力器は179の5表tableNames対応版を差分上書きとして旧/新SHAと理由を宣言する。売買・金融SourceやF0は変更しない。

固定4候補と旧6対照は旧73/追加7の全取得・保有区間・engine・金融・集中と全80を保持する。純方向576も両期間保持する。金融表接続preflightと純入力指紋を保存し、overlayは `inputs/00179_終了前決済の共用数値表/` の一組をSHA参照する。23MBの旧overlayや原板をZIPへ複製しない。

全段元gz約79MBは重複保存しない。別軽量正本へ元SHA、全政策・件数、選択必要数値、元行canonical SHAを保存する。元ranking/shortlistの順位が一致することを検算する。必要なら元Source/F0/正式入力で全段を再計算し行SHAへ照合できる。固定再現に全探索の再実行を必須にしない。元workは削除しない。

隔離runnerは正式148をキャッシュ無し射影し、early.load_overlayでcase/純取得/評価軸/binding/NPZ/Sourceを計算前確認する。旧6seal/proofは174/177/178正式ZIPから必要九memberだけ継承する。179のcompose/replay/pack/merge Sourceをそのまま呼び、576純方向と固定10×旧追加の全pack・全80を比較する。

隔離確認は成功。576方向両期、20候補期間と固定10全80全行が一致し、禁止参照0（298読込）。任意政策再検算ツールも先頭政策一件で元行全数値SHAの一致を確認済み。

```powershell
& 'work/複合テクニカル学習環境/Scripts/python.exe' 'work/179正式保存/保存179.py' --prepare
& 'work/複合テクニカル学習環境/Scripts/python.exe' 'work/179正式保存/隔離を準備する.py'
```

正式保存はRoot最終GO後の `保存179.py --execute --go`。必要な独立検査は `--require` で追加できる。元work/cache/原板参照と共有入力への書込を隔離監査で禁止する。
