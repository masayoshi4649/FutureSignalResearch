"""179の新規閲覧文書と目次の179参照を確認する。"""
from pathlib import Path
import json
import re
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[2]


def main() -> None:
    """
    機能: 179新規文書の相対リンク・UTF-8・行末空白を検査する。
    引数: なし。
    返り値: None。結果は作業領域へ保存し、成果物を書き換えない。
    """
    folders = ['study/00179_保有時間参加率と終了前決済で入口を広げる',
               'outputs/00179_保有時間参加と終了前決済',
               'inputs/00179_終了前決済の共用数値表']
    paths = [p for folder in folders for p in (ROOT / folder).rglob('*.md')]
    paths.append(ROOT / 'docs/議論/保有時間の参加率と終了十五分前決済で入口を評価する.md')
    indexes = ['README.md', 'docs/README.md', 'study/README.md', 'AGENTS.md']
    errors = []; checks = 0
    for path in paths + [ROOT / name for name in indexes]:
        body = path.read_text(encoding='utf-8')
        if path not in paths:
            body = '\n'.join(line for line in body.splitlines() if '179' in line)
        for line in body.splitlines():
            if line.rstrip() != line:
                errors.append([path.relative_to(ROOT).as_posix(), '行末空白', line])
        for match in re.finditer(r'\[[^\]]*\]\((<[^>]+>|[^)]+)\)', body):
            target = match.group(1).strip('<>')
            if target.startswith(('https://', 'http://', '#', 'mailto:')):
                continue
            target = unquote(target.split('#', 1)[0])
            checks += 1
            if not (path.parent / target).exists():
                errors.append([path.relative_to(ROOT).as_posix(), '参照先不在', target])
    result = {'成功': not errors, '文書数': len(paths) + len(indexes), 'リンク数': checks, '問題': errors}
    (Path(__file__).parent / '文書リンク検査.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False))
    assert not errors


if __name__ == '__main__':
    main()
