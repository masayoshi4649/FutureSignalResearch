"""179固定結果から候補別の金融・実保有参加CSV用の型付き値を作る。"""
from pathlib import Path
import gzip
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).parent


def chosen(data: dict) -> list:
    """
    機能: 各routeの主と、全期旧174/177/178新時計対照を公開対象にする。
    引数: data(dict)は全80固定結果。
    返り値: list[tuple[str,dict]]。近傍の同じ取引を独立成功として並べない。
    """
    out=[];routes=set()
    for row in data['rows']:
        identity=row['id'];route=row['policy']['route']
        if not identity.startswith('C'):
            if route not in routes:out.append((identity,row));routes.add(route)
        elif identity.startswith(('C174_全期','C177_全期','C178_全期')):
            out.append(('旧'+identity[1:4]+'_新時計',row))
    assert len(out)==5
    return out


def main() -> None:
    """
    機能: 0取引場・未知・跨帯保有を保った五表を候補ごとに準備する。
    引数: なし。
    返り値: None。CSV authorは共通artifact-tool処理で別に行う。
    """
    path=ROOT/'work/179保有参加の探索/全80の固定結果179.json.gz'
    raw=path.read_bytes();data=json.loads(gzip.decompress(raw));records=chosen(data)
    summary=['候補','選択区分','区分','対象場数','取得場数','取引回数','保有率下限','保有率上限','場別保有率中央値下限',
        '20%以上の場数','利益円_既知','損失円_既知','収支円_既知','利益損失比','黒字確定場数','赤字確定場数','未知場数',
        '上位3正純益場割合','上位3正純益場除外後収支円_既知','建玉中央値下限円','場中央値下限円','両中央値',
        'F','A','N','C','金融未知件数','先着率','強制決済件数','終了前決済未確認場数','原候補ID']
    columns=['候補','選択区分','セッション日','セッションID','利益円_既知','損失円_既知','収支円_既知分','収支円_全件確定',
        '累計収支円_既知分','累計収支円_全件確定','取引回数','保有率下限','保有率上限','保有分下限','保有分上限','対象分',
        '保有20%以上確定','旧主取得','新枝取得','初参加T取得','F','A','N','C','金融未知件数','累計金融未知件数',
        '強制決済件数','終了前全決済確認','原候補ID','取引なし理由']
    names={'候補比較':'集計','デイ':'デイ','ナイト合計':'ナイト合計','ナイト_米前':'ナイト_米前','ナイト_米後':'ナイト_米後'}
    tables={name:{'headers':summary if name=='候補比較' else columns,'rows':[]} for name in names}
    for alias,row in records:
        candidate='179:'+alias;route=row['policy']['route'];ev=row['evidence'];financial=ev['financial']
        groups={**financial['phases_diagnostic'],'NIGHT':financial['session_groups_required']['NIGHT']}
        ledger=row['ledger'];holding=ev['holding']['groups'];closure={r['scene']:r for r in ev['holding']['closure']['rows']}
        for band,name in [('DAY','デイ'),('NIGHT','ナイト合計'),('PRE','ナイト_米前'),('POST','ナイト_米後')]:
            g=groups[band];t=g['trades'];s=g['sessions'];h=holding[band]
            phases=ledger['phase'];selected=[i for i,p in enumerate(phases) if p>0] if band=='NIGHT' else [i for i,p in enumerate(phases) if p==('DAY','PRE','POST').index(band)]
            diagnostic=ev['concentration'][band]
            top=next(v for v in diagnostic['concentration']['positive_scene_net']['top'] if v['requested_top_count']==3)
            positive=sum(r['unknown_count']==0 and r['known_net']>0 for r in s['rows'])
            negative=sum(r['unknown_count']==0 and r['known_net']<0 for r in s['rows'])
            unknown_scenes=sum(r['unknown_count']>0 for r in s['rows'])
            fa=t['IFD_FIRSTFANC'];loss=t['known_loss']
            tables['候補比較']['rows'].append([candidate,route,band,s['eligible_count'],s['participating_count'],t['all_count'],
                h['held_lower_ratio'],h['held_upper_ratio'],h['scene_ratio_median_lower'],h['scene_target_met_guaranteed_count'],
                t['known_profit'],loss,t['known_net'],t['known_profit']/loss if loss else None,positive,negative,unknown_scenes,
                top['share'],top['remaining']['known_net'],t['net_median']['lower'],s['net_median']['lower'],g['decision']['status'],
                *[fa[k] for k in ('F','A','N','C')],t['unknown_count'],fa['first_f_rate_reached'],sum(ledger['forced'][i] for i in selected),
                sum(closure[r['scene']]['flat_guaranteed'] is None for r in s['rows']),row['id']])
            held={r['scene']:r for r in h['rows']};cumulative=0.;uncertain=0
            for scene in sorted(s['rows'],key=lambda r:r['scene']):
                identity=scene['scene'];cumulative+=scene['known_net'];uncertain+=scene['unknown_count']
                indices=[i for i in selected if ledger['scene'][i]==identity];time=held[identity]
                added=sum(ledger['added'][i] for i in indices);fallback=sum(ledger['origin'][i]==2 for i in indices)
                labels=[ledger['label'][i] for i in indices];flat=closure[identity]['flat_guaranteed']
                reason='' if indices else '帯内の新規取得なし。保有時間には他帯で取得した建玉も実時間配分する。'
                tables[name]['rows'].append([candidate,route,identity.split('_')[0],identity,
                    scene['known_profit'],scene['known_loss'],scene['known_net'],scene['all_net'],cumulative,cumulative if not uncertain else None,
                    len(indices),time['held_lower_ratio'],time['held_upper_ratio'],time['held_lower_seconds']/60,time['held_upper_seconds']/60,
                    time['eligible_seconds']/60,'達成' if time['target_met_guaranteed'] else '不確定' if time['target_met_possible'] else '未達',
                    len(indices)-added-fallback,added,fallback,*[labels.count(code) for code in (1,-1,0,2)],scene['unknown_count'],uncertain,
                    sum(ledger['forced'][i] for i in indices),'確認済' if flat is True else '未知' if flat is None else '違反',row['id'],reason])
            assert cumulative==t['known_net']
        assert all(len(tables[name]['rows'])%40==0 for name in names if name!='候補比較')
    body={'trial':179,'確認日':'2026-11-16','tableNames':names,'tables':tables,
        'inputs':[{'path':path.relative_to(ROOT).as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}],
        '候補対応':[{'表示ID':'179:'+alias,'原候補ID':r['id']} for alias,r in records],
        '定義':'mini1枚、追加禁止。参加率は実保有時間。金融は新規帯、時間は実時間配分。開始一律待機なし、15:30/05:45締切、15:29/05:44決済要求。未知は下限/上限と空欄で示す。全80既使用。'}
    destination=HERE/'型付き入力.json';assert not destination.exists()
    destination.write_text(json.dumps(body,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'候補数':len(records),'CSV予定数':len(records)*len(names),'行数':{k:len(v['rows']) for k,v in tables.items()}},ensure_ascii=False))


if __name__=='__main__':main()
