"""179の原行逐次独立基準・鏡像・prefixを自然金融なしで確認する。"""
from pathlib import Path
import hashlib
import json
import math
import sys
import numpy as np
import early179 as E

HERE=Path(__file__).resolve().parent
RECORD=np.dtype([('time','<f8'),('source_line','<i8'),('last','<f8'),('bid','<f8'),('ask','<f8'),('normal','<u8')])


def no_natural(event: str, arguments: tuple) -> None:
    """
    機能: 人工検査中の自然入力・金融配列読込を監査で禁止する。
    引数: event(str)、arguments(tuple)。
    返り値: None。禁止対象ならRuntimeError。
    """
    if event!='open' or not isinstance(arguments[0],(str,bytes)):return
    path=Path(arguments[0]).resolve()
    if path.is_relative_to(E.ROOT/'inputs') or path.is_relative_to(E.ROOT.parent/'JP_OSE_Data'):
        raise RuntimeError('自然入力禁止: '+str(path))
    if path.suffix in ('.gz','.npz') and not path.is_relative_to(HERE):raise RuntimeError('自然配列禁止: '+str(path))


def rows(times: list, bids: list, flags: list|None=None, spreads: list|None=None) -> np.ndarray:
    """
    機能: 正常/異常BBOと物理原行を持つ人工索引を作る。
    引数: times/bids(list)、flags/spreads(list|None)。
    返り値: np.ndarrayは48byte互換の構造化配列。
    """
    n=len(times);result=np.zeros(n,RECORD);result['time']=times;result['source_line']=np.arange(n)*2+1
    result['normal']=np.ones(n,np.uint64) if flags is None else flags
    result['bid']=bids;result['ask']=np.asarray(bids)+(np.full(n,10) if spreads is None else spreads)
    result['ask'][result['normal']==0]=result['bid'][result['normal']==0]
    result['last']=(result['ask']+result['bid'])/2;return result


def scalar(records: np.ndarray, entry: int, side: int, width: float, horizon: dict, end: float) -> dict:
    """
    機能: 木・二分探索・terminal関数を使わず各原行を時間順に独立再生する。
    引数: records(np.ndarray)、entry/side(int)、width/end(float)、horizon(dict)。
    返り値: dictは一セルの先着/既知/費用後収支/確認保有下限。
    """
    result={'label':2,'known':False,'net':math.nan,'net0':math.nan,'exit_time':math.nan,'known_at':math.nan,
        'holding_confirmed_until':math.nan,'forced':False,'direction':0,'points':math.nan,'exit_quote_time':math.nan,
        'exit_price':math.nan,'exit_index':-1,'exit_line':-1}
    cut=end-900;submit=cut-60;time=float(records[entry]['time'])
    if time>=submit:return result
    deadline=math.inf if horizon['kind']=='session' else time+horizon['seconds']
    previous=time;normal_time=time;result['holding_confirmed_until']=time
    sign=1 if side==0 else -1;price=float(records[entry]['ask' if side==0 else 'bid'])
    for index in range(entry+1,len(records)):
        quote=records[index];at=float(quote['time'])
        if at>cut:break
        normal=quote['normal']==1 and math.isfinite(quote['bid']) and math.isfinite(quote['ask']) and 0<quote['bid']<quote['ask']
        if at-previous>300 and previous<deadline:break
        if at-normal_time>300 and normal_time<deadline:break
        if at>deadline+30:break
        if normal:
            mark=float(quote['bid' if side==0 else 'ask']);points=sign*(mark-price)
            touch=at<=deadline and abs(points)>=width
            force=at>=submit+1
            horizon_close=at>=deadline
            if touch or force or horizon_close:
                label=(1 if points>=width else -1) if touch else 0
                result.update(label=label,known=True,net=points*100-1077,net0=points*100-77,
                    exit_time=at,known_at=at,holding_confirmed_until=at,forced=bool(force and not touch),direction=label,
                    points=points,exit_quote_time=at,exit_price=mark,exit_index=index,exit_line=int(quote['source_line']))
                return result
            normal_time=at;result['holding_confirmed_until']=at
        previous=at
    return result


def check(records: np.ndarray, entries: np.ndarray, end: float, widths: list, horizons: list) -> tuple:
    """
    機能: 全セルを独立逐次基準へ照合する。
    引数: records/entries(np.ndarray)、end(float)、widths/horizons(list)。
    返り値: tuple[dict,int]は実配列と照合属性セル数。
    """
    actual=E.evaluate_records(records,entries,end,widths,horizons);cells=0
    for ci,entry in enumerate(entries):
        for side in (0,1):
            for wi,width in enumerate(widths):
                for hi,horizon in enumerate(horizons):
                    wanted=scalar(records,int(entry),side,width,horizon,end)
                    for key,value in wanted.items():
                        observed=actual[key][ci,side,wi,hi]
                        assert observed==value or isinstance(value,float) and math.isnan(value) and math.isnan(observed),(
                            key,ci,entry,side,width,horizon,observed,value,records.tolist())
                        cells+=1
    return actual,cells


def main() -> None:
    """
    機能: 境界・乱数・鏡像・prefixと原行木を人工入力だけで検査する。
    引数: なし。
    返り値: None。JSON確認票を保存し自然金融を生成しない。
    """
    before=E.sha(HERE/'early179.py');sys.addaudithook(no_natural)
    horizons=[{'id':'H1','kind':'strict','seconds':60},{'id':'H3','kind':'strict','seconds':180},
        {'id':'H20','kind':'strict','seconds':1200},{'id':'SESSION','kind':'session','seconds':0}]
    widths=[25,50,125,250,1000];count=mirror=prefix=trees=0
    fixtures=[
        rows([100,160,160,540,540.9,541,599,601],[1000,1010,1500,1020,1030,1040,2000,3000]),
        rows([100,150,539,540.5,601],[1000,1010,1020,1030,2000]),
        rows([100,150,450,541,601],[1000,1140,1000,800,1000]),
        rows([100,150,450.001,541,601],[1000,1010,1400,800,1000]),
        rows([100,200,300,401,541,601],[1000,1000,1000,1000,1200,1000],[1,0,0,0,1,1]),
        rows([100,159,161,500,541,600],[1000,1010,1500,1000,1010,1000]),
        rows([100,159,191,500,541,600],[1000,1010,1500,1000,1010,1000]),
        rows([100,100,100,541,600],[1000,1300,700,1000,1010]),
        rows([100,120,140],[1000,1010,1020]),
    ]
    for fixture in fixtures:
        _,cells=check(fixture,np.array([0]),1500.,widths,horizons);count+=cells
    # ----------------------------------------
    rng=np.random.default_rng(1790301)
    for repetition in range(180):
        size=80;times=100+np.cumsum(rng.choice([0.,.5,1.,10.,30.,100.,300.,301.],size,p=[.08,.10,.15,.2,.2,.1,.1,.07]))
        bids=10000+np.cumsum(rng.integers(-150,151,size));flags=rng.random(size)>.15;flags[0]=True
        data=rows(times.tolist(),bids.tolist(),flags.tolist());end=float(times[int(rng.integers(15,75))]+900)
        valid=np.flatnonzero(flags);entries=valid[::max(1,len(valid)//8)][:9]
        actual,cells=check(data,entries,end,widths,horizons);count+=cells
        # ----------------------------------------
        reflected=data.copy();reflected['bid']=30000-data['ask'];reflected['ask']=30000-data['bid'];reflected['last']=30000-data['last']
        mirrored=E.evaluate_records(reflected,entries,end,widths,horizons)
        for key in ('label','known','net','exit_time','known_at','holding_confirmed_until','forced','direction','points','exit_index','exit_line'):
            np.testing.assert_array_equal(mirrored[key][:,::-1],actual[key]);mirror+=1
        stop=int(rng.integers(20,size));short_entries=entries[entries<stop]
        short=E.evaluate_records(data[:stop],short_entries,end,widths,horizons)
        for key in ('label','known','net','exit_time','forced','holding_confirmed_until'):
            known=short['known'];np.testing.assert_array_equal(short[key][known],actual[key][:len(short_entries)][known]);prefix+=1
        # ----------------------------------------
        tree=E.PriceIndex(data)
        for sample in range(10):
            start=int(rng.integers(0,size));finish=int(rng.integers(start,size+1));side=int(rng.integers(0,2))
            center=float(rng.integers(9600,10400));width=float(rng.choice(widths))
            wanted=next((i for i in range(start,finish) if flags[i] and
                (data['bid' if side==0 else 'ask'][i]<=center-width or data['bid' if side==0 else 'ask'][i]>=center+width)),-1)
            assert tree.first_outside(start,finish,center-width,center+width,side)==wanted;trees+=1
    assert E.sha(HERE/'early179.py')==before
    result={'成功':True,'自然入力未読':True,'自然金融生成なし':True,'確認日':'2026-11-16','SourceSHA256':before,
        '独立逐次属性セル':count,'鏡像属性':mirror,'既知prefix属性':prefix,'独立原行木':trees,'境界fixture':len(fixtures),
        '検査':'要求1秒後からcut以下の最初の正常BBO、後の最良/最終価格を選ばない。期限後grace quoteをtouchへ使わない。同秒順・gap300・既確定FA保持・未知下限を確認。'}
    (HERE/'人工確認179.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':main()
