"""179表のcase束縛・評価軸・全体SHAを成績閲覧と各再生段階の前に確認する。"""
import argparse
import json
import 探索179 as P


def main() -> None:
    """
    機能: 正式overlay読込APIで旧表への接続保証を確認し、以後の不変を照合する。
    引数: --new(bool)は追加7。既定は旧73。
    返り値: None。数値条件・入口・順位・決済値を変更しない。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--new',action='store_true');args=parser.parse_args()
    P.verify();module=P.B.P.module(P.ROOT/'work/179終了前決済/early179.py','early179_preflight')
    context=P.B.load_context(args.new)
    loaded=module.load_overlay(context,args.new,P.OVERLAY_DIR)
    period='追加7' if args.new else '旧73'
    proof={'成功':True,'期間':period,'binding・軸・NPZ_SHA照合':True,
        'NPZ':P.ref(P.OVERLAY_DIR/(period+'_overlay179.npz')),
        'metadata':P.ref(P.OVERLAY_DIR/(period+'_overlay179.json')),
        'Source':P.ref(P.ROOT/'work/179終了前決済/early179.py')}
    target=P.TRIAL/'検査'/(period+'の金融表接続.json')
    if target.exists():assert P.B.P.read(target)==proof
    else:P.B.P.save(target,proof)
    print(json.dumps(proof,ensure_ascii=False),flush=True)


if __name__=='__main__':main()
