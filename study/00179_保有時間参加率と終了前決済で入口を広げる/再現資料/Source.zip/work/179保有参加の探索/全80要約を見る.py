"""固定全80結果の主要数値を短く表示する。"""
import json
import 探索179 as P
from 要約を見る import compact


def main() -> None:
    """
    機能: route主案と旧全期対照の全80・追加期を表示する。
    引数: なし。
    返り値: None。
    """
    data=P.B.P.read(P.HERE/'全80の固定結果179.json.gz');seen=set();output=[]
    for row in data['rows']:
        control=row['id'].startswith('C');route=row['policy']['route']
        if control and route!='全期':continue
        if not control:
            if route in seen:continue
            seen.add(route)
        temporary={**row,'periods':{'全80':row['evidence'],**row['periods']}}
        output.append(compact(temporary,'全80'))
        if not control:output.append(compact(temporary,'追加7'));output.append(compact(temporary,'後25'))
    print(json.dumps(output,ensure_ascii=False))


if __name__=='__main__':main()
