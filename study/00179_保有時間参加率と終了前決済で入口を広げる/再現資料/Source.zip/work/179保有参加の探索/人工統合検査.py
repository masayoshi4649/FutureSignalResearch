"""自然金融を使わず、179の新規停止・予約取消・未知占有を確認する。"""
from types import SimpleNamespace
import copy
import json
import numpy as np
import 基盤179 as M


def fixture() -> tuple:
    """
    機能: 同秒決済、新規停止境界、停止を跨ぐ予約を持つ人工入力を作る。
    引数: なし。
    返り値: tuple[object,dict,np.ndarray,np.ndarray,list]。
    """
    times=[0,100,101,3539,3540,3605];n=len(times)
    context=SimpleNamespace(event_keys=[(float(t),i,1) for i,t in enumerate(times)],
        event_scenes=np.zeros(n,np.int16),event_phases=np.zeros(n,np.int8),
        scenes=[{'start':0,'end':4500,'session':'2000-01-01_Day'}],sessions=['2000-01-01_Day'],
        deadlines=np.array([3600.]),close_submits=np.array([3540.]),case_scene=np.zeros(n,np.int16),
        table=SimpleNamespace(widths=[200],horizons=['H60']))
    shape=(n,2,1,1);exits=np.array([100,200,200,3600,3600,3600],float)
    context.arrays={'known':np.ones(shape,bool),'exit_time':np.broadcast_to(exits[:,None,None,None],shape).copy(),
        'entry_time':np.array([1,101,102,3541,3541,3606],float),'holding_confirmed_until':np.full(shape,50.)}
    birth={'core':np.ones(n,np.int8),'branches':np.zeros(n,np.int8),'technical':np.zeros(n,np.int8),'tier':np.zeros(n,np.int8)}
    descriptors=[{'status':'filled','case':i,'fill_key':(float(context.arrays['entry_time'][i]),i+10,1)} for i in range(n)]
    return context,birth,np.full(n,200,np.int16),np.zeros(n,np.int8),descriptors


def main() -> None:
    """
    機能: 境界と未知保有を人工確認し、自然値と独立の検査票を保存する。
    引数: なし。
    返り値: None。
    """
    context,birth,width,hi,caps=fixture()
    value=M.replay(context,birth,width,width,hi,True,caps)
    assert value[0].events.tolist()==[0,2] and value[0].cases.tolist()==[0,2]
    assert [r['event'] for r in value[-1]['requests']]==[0,1,2,3]
    assert value[-1]['requests'][1]['skip_reason']=='held'
    assert value[-1]['audits'][0]['cancelled']==1
    assert value[-1]['audits'][0]['peak_global_reserved']==1
    assert value[-1]['audits'][0]['pending_at_scene_end']==[0,0]
    mirror={**birth,'core':-birth['core']}
    reversed_value=M.replay(context,mirror,width,width,hi,True,caps)
    assert np.array_equal(value[0].events,reversed_value[0].events)
    assert np.array_equal(value[0].sides,1-reversed_value[0].sides)
    unknown=copy.deepcopy(context);unknown.arrays['known'][0]=False
    uncertain=M.replay(unknown,birth,width,width,hi,True,caps)
    assert uncertain[0].events.tolist()==[0]
    positions=M.positions(unknown,uncertain)
    assert positions[0]['exit'] is None and positions[0]['confirmed_until']==50
    assert positions[0]['possible_until']==3600
    proof={'成功':True,'自然金融未読':True,'停止時点q0を除外':True,'停止越えpending取消':True,
        '同秒exitは秒末解放':True,'取得event元番号復元':True,'鏡像同体':True,
        '未知管理占有と保有下限を分離':True,'Source':{p.name:M.B.P.sha(p) for p in [M.HERE/'基盤179.py',M.HERE/'人工統合検査.py']}}
    M.B.P.save(M.HERE/'人工統合検査.json',proof)
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':main()
