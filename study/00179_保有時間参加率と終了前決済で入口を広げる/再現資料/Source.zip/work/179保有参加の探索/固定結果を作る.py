"""179の固定少数候補を追加7へ適用し、全80を取引・保有台帳から再集計する。"""
from pathlib import Path
import argparse
import json
import numpy as np
import 探索179 as P
import 基盤179 as M


def pack(policy: dict, new: bool) -> dict:
    """
    機能: 一つの固定政策から金融・保有区間・全要求を作る。
    引数: policy(dict)、new(bool)は追加期間。
    返り値: dictは再現・独立確認に必要な固定全件台帳。
    """
    context=P.CTX;birth,mw,fw,hi,added=P.compose(policy)
    value=P.replay(context,birth,mw,fw,hi,True,P.CAPS)
    selected,origin,wi,his,tier,engine=value
    key=(selected.cases,selected.sides,wi,his);known=context.arrays['known'][key]
    ledger={'net':[float(v) if k else None for v,k in zip(context.arrays['net'][key],known,strict=True)],
        'known':known.tolist(),'label':context.arrays['label'][key].tolist(),
        'scene':[context.sessions[int(s)] for s in context.case_scene[selected.cases]],
        'phase':selected.phases.tolist(),'origin':origin.tolist(),'event':selected.events.tolist(),
        'case':selected.cases.tolist(),'case_id':[context.table.case_ids[int(case)] for case in selected.cases],'side':selected.sides.tolist(),
        'width':[int(context.table.widths[i]) for i in wi],'horizon':[context.table.horizons[i] for i in his],
        'entry_time':context.arrays['entry_time'][selected.cases].tolist(),
        'entry_price':context.arrays['entry_price'][selected.cases,selected.sides].tolist(),
        'exit_time':[float(v) if k else None for v,k in zip(context.arrays['exit_time'][key],known,strict=True)],
        'exit_price':[float(v) if k else None for v,k in zip(context.arrays['exit_price'][key],known,strict=True)],
        'exit_index':context.arrays['exit_index'][key].tolist(),'exit_line':context.arrays['exit_line'][key].tolist(),
        'forced':context.arrays['forced'][key].tolist(),'status':context.arrays['status'][key].tolist(),
        'added':added[selected.events].tolist()}
    full=P.evidence(context,value);periods={}
    if not new:
        for name,eligible in [('前48',np.arange(len(context.scenes))<48),('後25',np.arange(len(context.scenes))>=48)]:
            periods[name]=P.evidence(context,value,eligible)
    return {'id':policy['id'],'policy':policy,'evidence':full,'periods':periods,
        'ledger':ledger,'positions':M.positions(context,value),'sessions':M.session_windows(context),
        'selection':{'cases':selected.cases.tolist(),'sides':selected.sides.tolist(),'events':selected.events.tolist(),
            'origins':origin.tolist(),'width_indices':wi.tolist(),'horizon_indices':his.tolist(),'tiers':tier.tolist()},'engine':engine}


def merge(old: dict, added: dict) -> dict:
    """
    機能: 旧73と追加7の台帳を結び、全80の同じ定義の金融と時間を求める。
    引数: old/added(dict)は同じ固定政策。
    返り値: dict。期間ごとの率を単純平均しない。
    """
    assert old['id']==added['id'] and old['policy']==added['policy']
    ledger={name:old['ledger'][name]+added['ledger'][name] for name in old['ledger']}
    sessions=old['sessions']+added['sessions'];positions=old['positions']+added['positions']
    eligible={b:[] for b in P.BANDS};hours={b:0. for b in P.BANDS}
    for session in sessions:
        for phase in session['phases']:
            eligible[phase['name']].append(session['scene']);hours[phase['name']]+=(phase['end']-phase['start'])/3600
    financial=P.B.metrics173.evaluate_metrics(ledger['net'],ledger['known'],ledger['label'],ledger['scene'],
        ledger['phase'],ledger['origin'],eligible,hours)
    holding=M.ACTIVITY.holding_summary(sessions,positions,target_ratio=.2)
    groups={**financial['phases_diagnostic'],'NIGHT':financial['session_groups_required']['NIGHT']}
    concentration={name:M.ACTIVITY.financial_diagnostics(g) for name,g in groups.items()}
    return {'id':old['id'],'policy':old['policy'],'evidence':{'financial':financial,'holding':holding,'concentration':concentration},
        'ledger':ledger,'positions':positions,'sessions':sessions,
        'periods':{'旧73':old['evidence'],'追加7':added['evidence'],**old['periods']}}


def main() -> None:
    """
    機能: 固定選択SHAを確認し、各route二案と旧6対照を追加適用する。
    引数: --selection-sha(str)。
    返り値: None。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--selection-sha',required=True);args=parser.parse_args()
    P.verify();source=P.HERE/'旧73の固定選択.json';assert P.B.P.sha(source)==args.selection_sha
    fixed=P.B.P.read(source);policies=[p for route in P.BASE_IDS for p in fixed['選択'][route]['candidates']]
    controls=P.B.P.read(P.HERE/'旧入口の新時計対照.json.gz')['rows'];policies.extend(r['policy'] for r in controls)
    assert len({p['id'] for p in policies})==len(policies)
    proof={'成功':True,'選択':P.ref(source),'Source':P.ref(Path(__file__)),'policies':policies,'追加7当該政策金融未読':True}
    target=P.HERE/'追加適用前の固定.json';assert not target.exists();P.B.P.save(target,proof)
    by_period={};expected={r['id']:r for r in P.B.P.read(P.HERE/'三帯の保有参加比較.json.gz')['rows']};expected.update({r['id']:r for r in controls})
    for new,name in [(False,'旧73'),(True,'追加7')]:
        P.initialize(new);rows=[]
        for policy in policies:
            row=pack(policy,new)
            if not new:
                earlier=expected[row['id']]
                assert row['evidence']==earlier['periods']['全期']
                assert all(row['periods'][period]==earlier['periods'][period] for period in ('前48','後25'))
                assert len(row['ledger']['net'])==earlier['count']
            rows.append(row)
        destination=P.HERE/(name+'の固定全取得179.json.gz');assert not destination.exists()
        P.B.P.save(destination,{'成功':True,'rows':rows,'固定':P.ref(target),'場順':P.CTX.sessions})
        by_period[name]=rows
        print(json.dumps({'固定適用':name,'候補数':len(rows)},ensure_ascii=False),flush=True)
    joined=[merge(a,b) for a,b in zip(by_period['旧73'],by_period['追加7'],strict=True)]
    P.B.P.save(P.HERE/'全80の固定結果179.json.gz',{'成功':True,'rows':joined,'固定':P.ref(target),'全場数':80,'全期間既使用':True})
    print(json.dumps({'成功':True,'全80候補':len(joined)},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
