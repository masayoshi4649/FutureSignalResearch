"""量と構造の複合入口を、終了前決済の独立予備表から数量比較へ絞る。"""
from pathlib import Path
import json
import time
import numpy as np
import 探索179 as P


def select(metrics: np.ndarray, rules: list, widths: list, horizons: list) -> dict:
    """
    機能: 各群から利益損失・参加・決済正率・先着支持の四視点を残す。
    引数: metrics(np.ndarray)、rules/widths/horizons(list)。
    返り値: dict。独立ケースの予備であり、口座参加率や金融中央値を主張しない。
    """
    families=sorted({r['group'] for r in rules});result={}
    for pi,route in enumerate(('全期','前48')):
        result[route]={}
        for bi,band in enumerate(P.BANDS):
            chosen=[]
            for family in families:
                rows=[]
                for ri,rule in enumerate(rules):
                    if rule['group']!=family:continue
                    for oi in range(2):
                        for wi,width in enumerate(widths):
                            for hi,horizon in enumerate(horizons):
                                s=dict(zip(P.SCREEN.FIELDS,metrics[ri,oi,bi,pi,wi,hi].tolist(),strict=True))
                                if not(s['count']>=12 and s['scenes']>=6 and s['F']+s['A']>=6 and s['resolved_scenes']>=4
                                    and s['C']<=.2*s['count'] and s['max_fa_share']<=.5):continue
                                n=s['F']+s['A'];p=s['F']/n;z=1.959963984540054
                                lower=(p+z*z/(2*n)-z*np.sqrt(p*(1-p)/n+z*z/(4*n*n)))/(1+z*z/n)
                                orientation=('NORMAL','REVERSE')[oi];identity=f'{rule["id"]}_{orientation}_W{width}_{horizon}_{band}'
                                rows.append({'id':identity,'family':family,'rule_id':rule['id'],'rule_index':ri,
                                    'orientation':orientation,'birth_key':rule['id']+'/'+orientation,'width':int(width),
                                    'horizon':horizon,'mode':rule['mode'],'wilson':float(lower),
                                    'proxy':{k:v if np.isfinite(v) else None for k,v in s.items()}})
                seen=set();birth_counts={}
                for view in ('利益損失','参加','決済正率','先着支持'):
                    def key(row: dict) -> tuple:
                        """
                        機能: 一視点の予備順位を同じ期間だけから作る。
                        引数: row(dict)。
                        返り値: tupleは昇順。率70%を要求しない。
                        """
                        s=row['proxy'];positive=s['positive_rate'] or 0
                        common=(-int(s['net']>0),-int(positive>.5),-s['scenes'])
                        if view=='参加':return (*common,-s['count'],-row['wilson'],row['id'])
                        if view=='決済正率':return (*common,-positive,-s['count'],row['id'])
                        if view=='先着支持':return (*common,-row['wilson'],-s['resolved_scenes'],row['id'])
                        pf=s['profit']/max(1,s['loss'])
                        return (*common,-pf,-positive,-s['count'],row['id'])
                    taken=0
                    for row in sorted(rows,key=key):
                        if row['id'] in seen or birth_counts.get(row['birth_key'],0)>=2:continue
                        chosen.append({**row,'selected_by':view});seen.add(row['id'])
                        birth_counts[row['birth_key']]=birth_counts.get(row['birth_key'],0)+1;taken+=1
                        if taken==2:break
            result[route][band]=chosen
    return result


def main() -> None:
    """
    機能: 固定純方向を新時計へ結び、全幅期限の予備統計と短表を保存する。
    引数: なし。
    返り値: None。
    """
    P.verify();P.initialize(False);ctx=P.CTX;rules=P.B.P.read(P.CATALOG)['rules']
    proof=P.B.P.read(P.HERE/'旧73の純出生179.json');assert proof['候補順']==[r['id'] for r in rules]
    with np.load(P.HERE/'旧73の純出生179.npz',allow_pickle=False) as source:directions=source['directions'].copy()
    times=np.asarray([k[0] for k in ctx.event_keys]);available=times<ctx.close_submits[ctx.event_scenes]
    event_cases=ctx.event_cases.copy();event_cases[~available]=-1
    good=event_cases>=0
    late=np.zeros(len(event_cases),bool)
    late[good]=ctx.arrays['entry_time'][event_cases[good]]>=ctx.close_submits[ctx.case_scene[event_cases[good]]]
    event_cases[late]=-1
    metrics=np.empty((len(rules),2,3,2,len(ctx.table.widths),len(ctx.table.horizons),len(P.SCREEN.FIELDS)))
    start=time.monotonic()
    for ri,direction in enumerate(directions):
        cases,sides,phases=P.SCREEN.physical(direction,event_cases,ctx.event_phases)
        for oi in range(2):metrics[ri,oi]=P.SCREEN.summarize(ctx,cases,sides if oi==0 else 1-sides,phases)
        if (ri+1)%48==0:print(json.dumps({'予備':ri+1,'全数':len(rules),'秒':round(time.monotonic()-start,1)},ensure_ascii=False),flush=True)
    target=P.HERE/'予備統計179.npz';assert not target.exists();np.savez_compressed(target,metrics=metrics)
    chosen=select(metrics,rules,list(ctx.table.widths),list(ctx.table.horizons))
    P.B.P.save(P.HERE/'予備短表179.json',{'成功':True,'選択':chosen,'統計':P.ref(target),'注意':'独立予備。保有時間参加率と損益中央値は数量再生で評価する。'})
    print(json.dumps({'成功':True,'短表':{r:{b:len(v) for b,v in bs.items()} for r,bs in chosen.items()}},ensure_ascii=False))


if __name__=='__main__':main()
