"""179純出生の共用入力を、金融評価前の物理指紋で固定する。"""
from pathlib import Path
import json
import 探索179 as P


def main() -> None:
    """
    機能: 自然金融値を読まず、純特徴・取得対応・出生のSHAを保存する。
    引数: なし。
    返り値: None。再実行は同じ指紋であることだけを確認する。
    """
    paths=[]
    for folder in ('inputs/00148_全1分入口母集団','inputs/00167_追加七場の入口と共用価格索引/入口母集団'):
        paths.extend(p for p in (P.ROOT/folder).iterdir() if p.is_file() and p.suffix!='.md')
    cache=P.ROOT/'work/151過去場判別の評価/入口選択/cache/feature_only'
    paths.extend(cache/name for name in ('features.npz','features_meta.json'))
    paths.extend(P.HERE/name for name in ('旧73の純出生179.npz','旧73の純出生179.json','追加7の純出生179.npz','追加7の純出生179.json'))
    proof={'成功':True,'入力':[P.ref(p) for p in paths],'F0SHA256':P.B.P.sha(P.TRIAL/'条件.json')}
    destination=P.TRIAL/'検査/純入力の指紋.json'
    if destination.exists():assert P.B.P.read(destination)==proof
    else:P.B.P.save(destination,proof)
    print(json.dumps({'成功':True,'入力数':len(paths),'指紋票':P.ref(destination)},ensure_ascii=False))


if __name__=='__main__':main()
