"""179の完成済み段階だけを短く表示し、大量正本を会話へ転記しない。"""
import argparse
import json
import 探索179 as P


def compact(row: dict, route: str) -> dict:
    """
    機能: 一候補の主要金融・参加・黒字場数を要約する。
    引数: row(dict)、route(str)。
    返り値: dict。
    """
    out={'id':row['id'],'評価期間':route,'band':{}}
    for band in ('DAY','NIGHT','PRE','POST'):
        g,h=P.group(row,route,band);t=g['trades'];s=g['sessions'];fa=t['IFD_FIRSTFANC']
        positives=sum(r['unknown_count']==0 and r['known_net']>0 for r in s['rows'])
        winners=sorted([max(0,r['known_net']) for r in s['rows']],reverse=True)
        out['band'][band]={'回数':t['all_count'],'取得場':s['participating_count'],'全場':s['eligible_count'],
            'FANC':[fa[k] for k in ('F','A','N','C')],'先着率':fa['first_f_rate_reached'],
            '利益':t['known_profit'],'損失':t['known_loss'],'収支':t['known_net'],'未知':t['unknown_count'],
            '建玉中央値':[t['net_median'][k] for k in ('lower','upper')],
            '場中央値':[s['net_median'][k] for k in ('lower','upper')],'両中央値':g['decision']['status'],
            '保有率下限':h['held_lower_ratio'],'保有率上限':h['held_upper_ratio'],
            '黒字確定場':positives,'上位3正純益場を除く既知収支':t['known_net']-sum(winners[:3])}
    return out


def main() -> None:
    """
    機能: 指定済み正本から対照全件又はroute上位のみを表示する。
    引数: file(str)、--best(bool)。
    返り値: None。
    """
    parser=argparse.ArgumentParser();parser.add_argument('file');parser.add_argument('--best',action='store_true')
    args=parser.parse_args();data=P.B.P.read(P.HERE/args.file);rows=data['rows']
    if args.best:
        rows=[min([r for r in rows if r['policy']['route']==route],key=lambda r:P.ranking(r,route,('DAY','NIGHT'))) for route in P.BASE_IDS]
    print(json.dumps({'件数':len(data['rows']),'要約':[compact(r,r['policy']['route']) for r in rows]},ensure_ascii=False))


if __name__=='__main__':main()
