"""179純入口の対称性・因果性・代替未知・量対照を人工入力で検査する。"""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from types import SimpleNamespace

import numpy as np
import rules179 as R

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work/176局面別の役割票'))
spec=importlib.util.spec_from_file_location('synthetic176_for179',ROOT/'work/176局面別の役割票/人工検査.py')
A=importlib.util.module_from_spec(spec);spec.loader.exec_module(A)


def synthetic(group: str,n: int=70) -> tuple:
    """
    機能: 既存人工100特徴を六群の価格回復局面へ写す。
    引数: group(str)、n(int)は人工q0数。
    返り値: tupleはfeatures(SimpleNamespace)と場開始秒配列。
    """
    return A.synthetic({'TF':'HT','BR':'HB','RV':'HR','MX':'HM','RG':'RL','LC':'LC'}[group],n)


def take(features: object,end: int) -> object:
    """
    機能: 人工特徴を複製しprefixへ切り出す。
    引数: features(object)、end(int)。
    返り値: objectは元入力を変更しない独立配列。
    """
    return A.A.take(features,end)


def choose(catalog: dict,group: str,volume: str,trigger: str='現在価格回復',profile: int=0) -> dict:
    """
    機能: 人工境界検査用に辞書の一つの固定条件を選ぶ。
    引数: catalog(dict)、group/volume/trigger(str)、profile(int)。
    返り値: dictはALL・必要票1の一候補。
    """
    return next(r for r in catalog['rules'] if r['group']==group and r['mode']=='ALL'
        and r['settings']['profile']==profile and r['settings']['volume_mode']==volume
        and r['settings']['direction_or_momentum_min']==1 and r['settings']['structure_mode']==trigger)


def main() -> None:
    """
    機能: 自然入力なしで鏡像・prefix・未来・未知・履歴reset・量方式を検査する。
    引数: なし。
    返り値: None。全辞書と人工確認のみ保存し、自然金融へ接続しない。
    """
    here=Path(__file__).resolve().parent;catalog=R.catalog();checks={};cells=0
    official=json.loads((ROOT/'inputs/00148_全1分入口母集団/100特徴の列定義.json').read_text(encoding='utf-8'))
    assert set(catalog['raw_columns'])<={r['name'] for r in official}
    assert len(catalog['rules'])==576 and len({r['id'] for r in catalog['rules']})==576
    for group in R.GROUPS:
        features,starts=synthetic(group);ids=[r['id'] for r in catalog['rules'] if r['group']==group]
        original=features.buy_X.copy();result=R.build(features,starts,candidate_ids=ids)
        assert np.array_equal(features.buy_X,original,equal_nan=True) and result['directions'].any(),group
        mirror=SimpleNamespace(columns=features.columns,buy_X=features.sell_X.copy(),sell_X=features.buy_X.copy(),q0_meta=features.q0_meta)
        assert np.array_equal(R.build(mirror,starts,candidate_ids=ids)['directions'],-result['directions'])
        for end in (20,36,50):
            prefix=R.build(take(features,end),starts,candidate_ids=ids)['directions']
            assert np.array_equal(prefix,result['directions'][:,:end])
            future=take(features,70);future.buy_X[end:]=np.nan;future.sell_X[end:]=np.nan
            assert np.array_equal(R.build(future,starts,candidate_ids=ids)['directions'][:,:end],result['directions'][:,:end])
            cells+=2*prefix.size
        unknown=take(features,70);unknown.buy_X[:]=np.nan;unknown.sell_X[:]=np.nan
        assert not R.build(unknown,starts,candidate_ids=ids)['directions'].any()
        # ----------------------------------------
        # 現在状態の代替枝はgap直後も当時値で判断できるが、旧履歴armは持ち越さない。
        gap=take(features,70)
        for q in gap.q0_meta[36:]:q['q0_time']+=300
        after=R.build(gap,starts,candidate_ids=ids)
        assert after['diagnostics']['history_reset'][36]
        for ri,r in enumerate([r for r in catalog['rules'] if r['group']==group]):
            if r['settings']['structure_mode']=='履歴イベント':assert not after['directions'][ri,36:40].any()
        for logical in {r['logical_id'] for r in catalog['rules'] if r['group']==group}:
            raw=result['directions'][ids.index(logical+'_ALL')];edge=result['directions'][ids.index(logical+'_EDGE')]
            assert np.all((edge==0)|(edge==raw))
        checks[group]={'候補数':96,'人工成立セル':int(np.count_nonzero(result['directions'])),
            '鏡像':True,'prefixと未来変更':True,'全未知待機':True,'gapで旧履歴破棄':True,'EDGEはALLの部分集合':True}
    # ----------------------------------------
    # 量なし対照は量NaNで遮断しない。量を使用する三方式はNaNで遮断する。
    features,starts=synthetic('TF');volume=features.columns.index('m1_volume_relative_prior3')
    features.buy_X[:,volume]=np.nan;features.sell_X[:,volume]=np.nan
    for mode in ('V0','V1','V2','V3'):
        rule=choose(catalog,'TF',mode)
        matrix=R.build(features,starts,candidate_ids=[rule['id']])['directions']
        assert bool(matrix.any())==(mode=='V0'),mode
    # ----------------------------------------
    # 履歴イベント必要列が未知でも、必要列が既知の現在回復は別パターンとして成立する。
    features,starts=synthetic('TF');position=features.columns.index('m5_price_ema8_atr_to_side')
    features.buy_X[:,position]=np.nan;features.sell_X[:,position]=np.nan
    rule=choose(catalog,'TF','V0','いずれか');evaluator=R.Evaluator179(features,starts)
    record=evaluator.evaluate_one(rule)
    assert record['directions'].any() and not record['unknown_buy'].any()
    event=choose(catalog,'TF','V0','履歴イベント')
    assert not R.build(features,starts,candidate_ids=[event['id']])['directions'].any()
    # 動力は二列とも既知が必要。片列が未知でも0票へ埋めない。
    for name in ('m5_hist_delta_to_side','m5_rsi_delta_to_side'):
        bad,starts=synthetic('TF');column=bad.columns.index(name);bad.buy_X[:,column]=np.nan;bad.sell_X[:,column]=np.nan
        assert not R.build(bad,starts,candidate_ids=[choose(catalog,'TF','V0')['id']])['directions'].any()
    # ----------------------------------------
    # V1の包含下限、V2の相対量回復、V3の厳密な同時スパイク境界。
    for value,expected in ((.249999,False),(.25,True)):
        features,starts=synthetic('TF');features.buy_X[:,volume]=value;features.sell_X[:,volume]=value
        actual=R.build(features,starts,candidate_ids=[choose(catalog,'TF','V1')['id']])['directions'][0,10]
        assert bool(actual)==expected
    for current,expected in ((.49,False),(.5,True)):
        features,starts=synthetic('TF');features.buy_X[:,volume]=.5;features.sell_X[:,volume]=.5
        features.buy_X[10,volume]=current;features.sell_X[10,volume]=current
        actual=R.build(features,starts,candidate_ids=[choose(catalog,'TF','V2')['id']])['directions'][0,10]
        assert bool(actual)==expected
    for relative,expected in ((2.5,True),(2.500001,False)):
        features,starts=synthetic('TF');features.buy_X[:,volume]=relative;features.sell_X[:,volume]=relative
        tr=features.columns.index('m1_tr_atr5_ratio');features.buy_X[:,tr]=1.3;features.sell_X[:,tr]=1.3
        actual=R.build(features,starts,candidate_ids=[choose(catalog,'TF','V3')['id']])['directions'][0,10]
        assert bool(actual)==expected
    # ----------------------------------------
    # LCは開始固定待機なし。一度公表した場/限月ではgap後にも再許可しない。
    features,starts=synthetic('LC',80);rule=choose(catalog,'LC','V0')
    initial=R.build(features,starts,candidate_ids=[rule['id']]);assert initial['directions'][0,0]!=0
    column=features.columns.index('m15_hist_delta_to_side');features.buy_X[20,column]=.1
    for q in features.q0_meta[40:]:q['q0_time']+=300
    current=R.build(features,starts,candidate_ids=[rule['id']])
    assert not current['directions'][:,20:].any() and not current['diagnostics']['local_allowed'][20:].any()
    for q in features.q0_meta[50:]:q['contract']='次の人工限月'
    changed=R.build(features,starts,candidate_ids=[rule['id']])
    assert changed['diagnostics']['local_allowed'][50:].all() and changed['diagnostics']['history_reset'][50]
    assert R.build(features,starts,candidate_ids=[])['directions'].shape==(0,80)
    dictionary=here/'候補辞書179.json';dictionary.write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    proof={'成功':True,'自然特徴と金融未読':True,'公式列名だけを照合':True,'raw_columns数':len(R.RAW_COLUMNS),
        '候補数':576,'群':checks,'照合セル':cells,'量なし対照と量未知':True,
        '代替構造の未知を別の既知真へ補完しない':True,'動力二列全既知':True,'量下限/回復/同時スパイク境界':True,
        '開始固定待機なしとLC公表ever':True,'空候補':True,
        'SourceSHA256':hashlib.sha256((here/'rules179.py').read_bytes()).hexdigest(),
        '候補辞書SHA256':hashlib.sha256(dictionary.read_bytes()).hexdigest()}
    (here/'人工確認179.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':
    main()
