"""179主と旧178新時計の実取得だけをcaseで対応させる。"""
import gzip
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def selected(row: dict) -> dict:
    """
    機能: DAY実取得を場ID・物理case ID・実側で一意に写す。
    引数: row(dict)は179固定結果の一候補。
    返り値: dict[tuple,dict]は台帳行。旧73/追加7のローカルcase添字を混同しない。
    """
    ledger=row['ledger'];out={};count=0
    for i in range(len(ledger['scene'])):
        if ledger['phase'][i]!=0:continue
        key=(ledger['scene'][i],ledger['case_id'][i],ledger['side'][i])
        assert key not in out
        out[key]={name:values[i] for name,values in ledger.items()};count+=1
    assert len(out)==count
    return out


def main() -> None:
    """
    機能: 共通/新だけ/旧だけと新LCの既知寄与を固定台帳から集計する。
    引数: なし。
    返り値: None。金融Source・実取得・固定政策を変更せず小JSONを保存する。
    """
    path=ROOT/'work/179保有参加の探索/全80の固定結果179.json.gz'
    digest=hashlib.sha256(path.read_bytes()).hexdigest()
    with gzip.open(path,'rt',encoding='utf-8') as stream:rows=json.load(stream)['rows']
    lookup={row['id']:row for row in rows}
    new=selected(lookup['全期_J035']);old=selected(lookup['C178_全期_J002_J000_K012'])
    shared=new.keys()&old.keys();new_only=new.keys()-old.keys();old_only=old.keys()-new.keys()
    changed=[key for key in shared if any(new[key][field]!=old[key][field]
        for field in ('side','width','horizon','origin','added','known','net'))]
    added=[row for row in new.values() if row['added']]
    proof={'成功':True,'対象':'全80DAY・全期J035と旧178新時計の実取得だけ','Source結果SHA256':digest,
        '対応キー':['scene','case_id','side'],'新総数':len(new),'旧総数':len(old),'共通':len(shared),
        '共通条件金融変更':len(changed),'新だけ':len(new_only),'旧だけ':len(old_only),
        '新だけ既知収支':sum(new[k]['net'] for k in new_only if new[k]['known']),
        '旧だけ既知収支':sum(old[k]['net'] for k in old_only if old[k]['known']),
        '旧だけ金融未知':sum(not old[k]['known'] for k in old_only),
        '新枝取得':len(added),'新枝取得場':len({r['scene'] for r in added}),
        '新枝利益':sum(max(r['net'],0) for r in added if r['known']),
        '新枝損失':sum(max(-r['net'],0) for r in added if r['known']),
        '新枝既知収支':sum(r['net'] for r in added if r['known']),
        '注意':'実際に各政策が取得した二台帳の比較。新枝の独立合算や、未取得仮想利益の機会損失評価ではない。旧に金融未知1があり差額は既知寄与。'}
    assert hashlib.sha256(path.read_bytes()).hexdigest()==digest
    (HERE/'新枝と旧取得の対応179.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':
    main()
