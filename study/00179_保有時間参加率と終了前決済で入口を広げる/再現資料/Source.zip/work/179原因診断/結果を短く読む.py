"""179保存結果を逐次読取り、保有・中央値・利益の場分布を小さく整理する。"""
from collections import Counter,defaultdict
import gzip
import hashlib
import json
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[2]
SOURCE=ROOT/'work/179保有参加の探索'
HERE=Path(__file__).resolve().parent


def iter_rows(path: Path) -> object:
    """
    機能: 大きい固定JSONの最上位rows配列を一行ずつ読んでメモリ複製を抑える。
    引数: path(Path)は179のgzip結果。
    返り値: generator[dict]。固定生成形式の最初のrowsキーを対象とし金融を再生成しない。
    """
    decoder=json.JSONDecoder()
    with gzip.open(path,'rt',encoding='utf-8') as stream:
        buffer=''
        while True:
            match=re.search(r'"rows"\s*:\s*\[',buffer)
            if match:buffer=buffer[match.end():];break
            chunk=stream.read(65536)
            if not chunk:raise ValueError('最上位rowsが見つからない: '+str(path))
            buffer+=chunk
        while True:
            buffer=buffer.lstrip()
            if buffer.startswith(','):buffer=buffer[1:].lstrip()
            if buffer.startswith(']'):return
            try:
                value,end=decoder.raw_decode(buffer)
            except json.JSONDecodeError:
                chunk=stream.read(65536)
                if not chunk:raise ValueError('rowsの途中で終了: '+str(path))
                buffer+=chunk;continue
            if not isinstance(value,dict):raise ValueError('結果rowが辞書ではない。')
            yield value
            buffer=buffer[end:]


def group(row: dict,period: str,band: str) -> dict:
    """
    機能: 一結果・期間・帯の中央値、保有時間、利益分布を短く抜き出す。
    引数: row(dict)、period/band(str)。
    返り値: dict。未知の全件収支を既知収支で置換しない。
    """
    record=row['periods'][period]
    financial=record['financial']
    g=(financial['session_groups_required']['NIGHT'] if band=='NIGHT' else financial['phases_diagnostic'][band])
    t=g['trades'];s=g['sessions'];h=record['holding']['groups'][band];c=record['concentration'][band]
    top=next(x for x in c['concentration']['positive_scene_net']['top'] if x['requested_top_count']==3)
    path=c['path']['known_contribution']
    return {'取得':t['all_count'],'取得場':s['participating_count'],'全場':s['eligible_count'],
        'FANC':{k:t['IFD_FIRSTFANC'][k] for k in ('F','A','N','C')},
        '到達済先着率':t['IFD_FIRSTFANC']['first_f_rate_reached'],
        '既知利益':t['known_profit'],'既知損失':t['known_loss'],'既知収支':t['known_net'],
        '金融未知':t['unknown_count'],'建玉中央値範囲':[t['net_median'][k] for k in ('lower','upper')],
        '場中央値範囲':[s['net_median'][k] for k in ('lower','upper')],'両中央値':g['decision']['status'],
        '保有下限比率':h['held_lower_ratio'],'保有上限比率':h['held_upper_ratio'],
        '保有20下限達成':h['target_met_guaranteed'],'場保有比率中央値下限':h['scene_ratio_median_lower'],
        '保有20下限達成場':h['scene_target_met_guaranteed_count'],
        '黒字確定場':c['positive_complete_scene_count'],'赤字確定場':c['negative_complete_scene_count'],
        '未知場':c['unknown_scene_count'],'上位3正純益場の集中率':top['share'],
        '上位3正純益場除外後の既知収支':top['remaining']['known_net'],
        '上位3の場ID':top['removed_scenes'],'既知寄与DD':path['max_drawdown_amount'],
        '既知寄与初期最小':path['initial_minimum'],'既知寄与最長水面下場':path['max_underwater_scenes']}


def summarize(path: Path) -> dict:
    """
    機能: 完成済み各段の落ちる位置を数え、旧対照又は固定少数案の短票を作る。
    引数: path(Path)は完成した固定結果。
    返り値: dictは各帯の件数。候補再選択・Source変更・新金融計算は行わない。
    """
    stages={};controls={};selected={}
    fixed=SOURCE/'旧73の固定選択.json'
    if fixed.exists():
        choices=json.loads(fixed.read_text(encoding='utf-8'))['選択']
        selected_ids={identity for value in choices.values() for identity in value['参考候補']}
    else:selected_ids=set()
    count=0
    for row in iter_rows(path):
        count+=1;policy=row['policy'];route=policy['route'];changes=policy.get('changes',{})
        if not changes:
            controls[row['id']]={p:{b:group(row,p,b) for b in ('DAY','PRE','POST','NIGHT')}
                for p in ('全期','前48','後25')}
        if row['id'] in selected_ids:
            selected[row['id']]={'policy':policy,'三期間':{p:{b:group(row,p,b) for b in ('DAY','PRE','POST','NIGHT')}
                for p in ('全期','前48','後25')}}
        bands=tuple(changes) if len(changes)==1 else ('DAY','NIGHT')
        for band in bands:
            short=group(row,route,band);key=route+'_'+band
            if key not in stages:
                stages[key]={'候補数':0,'両中央値':Counter(),'保有20下限達成':0,'全場取得':0,
                    '中央値と保有20':0,'黒字場半数超':0,'上位3除外後既知黒字':0,
                    '取得数範囲':[None,None],'保有下限範囲':[None,None],'モードと群':Counter()}
            target=stages[key];target['候補数']+=1;target['両中央値'][short['両中央値']]+=1
            target['保有20下限達成']+=int(short['保有20下限達成'])
            target['全場取得']+=int(short['取得場']==short['全場'])
            target['中央値と保有20']+=int(short['両中央値']=='適合' and short['保有20下限達成'])
            target['黒字場半数超']+=int(short['黒字確定場']>short['全場']/2)
            target['上位3除外後既知黒字']+=int(short['上位3正純益場除外後の既知収支']>0)
            for field,value in (('取得数範囲',short['取得']),('保有下限範囲',short['保有下限比率'])):
                if value is None:continue
                if target[field][0] is None:target[field]=[value,value]
                else:target[field]=[min(target[field][0],value),max(target[field][1],value)]
            change=changes.get(band)
            if change is not None:
                family='+'.join(sorted(r['family'] for r in change['rules'])) or '旧対照'
                target['モードと群'][change['mode']+'/'+family]+=1
    return {'政策数':count,'段階別':stages,'旧対照':controls,'固定参考候補':selected,
        '注意':'保有20は群の実時間下限。利益集中の上位は場内利益総額ではなくmax(場の既知純益,0)で順位付け、当該場の全取引を除く。未知は既知寄与と全件の区別を保持。'}


def main() -> None:
    """
    機能: 存在する完成正本だけを読み、短い診断JSONを保存する。
    引数: なし。
    返り値: None。途中の0byteや書込中ファイルを金融結果として扱わない。
    """
    files=['旧入口の新時計対照.json.gz','単帯の追加置換.json.gz','二局面の追加置換.json.gz','三帯の保有参加比較.json.gz']
    result={'成功':True,'段階':{},'入力':{}}
    for name in files:
        path=SOURCE/name
        if not path.exists() or not path.stat().st_size:continue
        before=hashlib.sha256(path.read_bytes()).hexdigest()
        value=summarize(path)
        assert hashlib.sha256(path.read_bytes()).hexdigest()==before
        result['段階'][name]=value;result['入力'][name]={'sha256':before,'bytes':path.stat().st_size}
        print(json.dumps({'段階':name,'政策数':value['政策数'],'票':value['段階別']},ensure_ascii=False),flush=True)
    target=HERE/'段階の原因短票179.json'
    target.write_text(json.dumps(result,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n',encoding='utf-8')


if __name__=='__main__':
    main()
