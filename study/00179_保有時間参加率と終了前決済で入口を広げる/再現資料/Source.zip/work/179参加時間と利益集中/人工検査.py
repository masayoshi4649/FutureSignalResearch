"""179の保有時間境界と利益集中を人工値だけで確認する。自然金融を読まない。"""
from pathlib import Path
from copy import deepcopy
import hashlib
import importlib.util
import json
import math
import random
import sys

import activity179 as A

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def day(scene: str='2026-01-01_Day', start: float=0, end: float=100, original_end: float|None=None) -> dict:
    """
    機能: 人工Dayの対象時計を作る。
    引数: scene(str)、start/end(float)、original_end(float|None)。
    返り値: dictは全域を覆う一帯の場。
    """
    return {'scene':scene,'kind':'DAY','start':start,'end':end,'original_end':end if original_end is None else original_end,
        'phases':[{'name':'DAY','start':start,'end':end}]}


def night() -> dict:
    """
    機能: 境界300秒を持つ200～400秒の人工Nightを作る。
    引数: なし。
    返り値: dictはPRE/POSTの全域分割。
    """
    return {'scene':'2026-01-01_Night','kind':'NIGHT','start':200,'end':400,'original_end':420,
        'phases':[{'name':'PRE','start':200,'end':300},{'name':'POST','start':300,'end':400}]}


def position(scene: str='2026-01-01_Day', fill: float=10, exit_time: float|None=30, **kwargs: object) -> dict:
    """
    機能: 人工の実取得又は未知退出を作る。
    引数: scene(str)、fill(float)、exit_time(float|None)、kwargs(object)は追加入力。
    返り値: dictは保有入力。
    """
    return {'scene':scene,'fill':fill,'exit':exit_time,'quantity':1,**kwargs}


def close(first: float, second: float) -> None:
    """
    機能: 人工値の集計順丸めだけを許して数値を比較する。
    引数: first/second(float)。
    返り値: None。不一致はAssertionError。
    """
    assert math.isclose(first,second,rel_tol=1e-12,abs_tol=1e-10),(first,second)


def rejects(function: object, *args: object) -> None:
    """
    機能: 不正入力をValueErrorで拒否することを確認する。
    引数: function(callable)、args(object)は人工入力。
    返り値: None。拒否しなければAssertionError。
    """
    try:function(*args)
    except ValueError:return
    raise AssertionError('不正入力を拒否しなかった。')


def money_group(values: list, known: list, scenes: list, eligible: list) -> dict:
    """
    機能: 173の純評価部品へ人工台帳だけを渡し、金融群を作る。
    引数: values(list[float|None])、known(list[bool])、scenes/eligible(list[str])。
    返り値: dictはDAYの全対象群。
    """
    path=ROOT/'work/173追加なしの評価/metrics173.py'
    spec=importlib.util.spec_from_file_location('metrics173_artificial179',path);M=importlib.util.module_from_spec(spec)
    sys.modules[spec.name]=M;spec.loader.exec_module(M)
    labels=['N' if k else 'C' for k in known]
    return M.evaluate_metrics(values,known,labels,scenes,[0]*len(values),[0]*len(values),
        {'DAY':eligible,'PRE':[],'POST':[]},{'DAY':100*len(eligible),'PRE':0,'POST':0})['phases_diagnostic']['DAY']


def main() -> None:
    """
    機能: 時間下限/上限・分母・跨帯・未知・利益集中を人工検算し、I/F例を保存する。
    引数: なし。
    返り値: None。担当workに人工JSONだけを書き、自然データや金融順位を読まない。
    """
    source_sha=hashlib.sha256((HERE/'activity179.py').read_bytes()).hexdigest();checks={}
    sessions=[day(original_end=120),night()]
    positions=[position(fill=10,exit_time=40),position(fill=20,exit_time=70,quantity=10),
        {'scene':'2026-01-01_Day','status':'pending','fill':0,'exit':100,'quantity':99},
        position('2026-01-01_Night',250,350)]
    before=deepcopy((sessions,positions));result=A.holding_summary(sessions,positions)
    assert before==(sessions,positions)
    for group,seconds,denominator in [('DAY',60,100),('NIGHT',100,200),('PRE',50,100),('POST',50,100),('ALL',160,300)]:
        value=result['groups'][group];close(value['held_lower_seconds'],seconds);close(value['held_upper_seconds'],seconds)
        close(value['eligible_seconds'],denominator);close(value['held_lower_ratio'],seconds/denominator)
    assert result['input_status_counts']['pending']==1 and result['closure']['all_scenes_flat_guaranteed'] is True
    checks['複数枚と重複は和集合・pending除外・跨帯配分・原終了を分母へ足さない']=True
    # ----------------------------------------
    # 全時間加重と、0保有場を残した等場重み中央値は同じ指標ではない。
    weighted=A.holding_summary([day(),day('2026-01-02_Day',200,1200)],[position(fill=10,exit_time=70)])['groups']['DAY']
    close(weighted['held_lower_ratio'],60/1100);close(weighted['scene_ratio_median_lower'],.3)
    assert weighted['target_status']=='未達' and weighted['median_target']['target_status']=='達成'
    assert weighted['eligible_scene_count']==2 and weighted['zero_guaranteed_holding_scene_count']==1
    checks['全時間加重・中央値・0保有場保持']=True
    unknown=A.holding_summary([day()],[position(fill=20,exit_time=None,confirmed_until=40,possible_until=80)])
    value=unknown['groups']['DAY'];close(value['held_lower_ratio'],.2);close(value['held_upper_ratio'],.6)
    assert value['target_status']=='達成' and unknown['closure']['all_scenes_flat_guaranteed'] is False
    assert unknown['closure']['rows'][0]['flat_guaranteed'] is None
    uncertain=A.holding_summary([day()],[position(fill=20,exit_time=None)])
    assert uncertain['groups']['DAY']['target_status']=='不確定'
    close(uncertain['groups']['DAY']['held_lower_seconds'],0);close(uncertain['groups']['DAY']['held_upper_seconds'],80)
    no_target=A.holding_summary([day()],[position(fill=20,exit_time=None,possible_until=30)])
    assert no_target['groups']['DAY']['target_status']=='未達'
    bounded=A.holding_summary([day()],[position(fill=20,exit_time=None,possible_until=80)])
    assert bounded['closure']['rows'][0]['flat_guaranteed'] is None
    checks['未知は保証保有端のみ下限・上限だけでは20達成にしない・上限はflat証明でない']=True
    crossing=A.holding_summary([night()],[position('2026-01-01_Night',250,None,confirmed_until=280,possible_until=350)])
    for group,low,high in [('PRE',30,50),('POST',0,50),('NIGHT',30,100)]:
        close(crossing['groups'][group]['held_lower_seconds'],low);close(crossing['groups'][group]['held_upper_seconds'],high)
    checks['未知跨帯の下限上限を別に分配']=True
    late=A.holding_summary([day()],[position(fill=0,exit_time=120)])
    close(late['groups']['DAY']['held_lower_seconds'],100)
    assert late['closure']['known_violation_scene_count']==1 and late['closure']['all_scenes_flat_guaranteed'] is False
    proved_late=A.holding_summary([day()],[position(fill=0,exit_time=None,confirmed_until=110)])
    assert proved_late['closure']['rows'][0]['confirmed_held_past_deadline_count']==1
    checks['期限後保有は分母へ延長せず違反を別表示']=True
    empty=A.holding_summary([],[])
    assert all(g['target_status']=='評価不能' and g['held_lower_ratio'] is None for g in empty['groups'].values())
    no_fills=A.holding_summary([day()],[{'scene':'2026-01-01_Day','status':'unfilled'}])
    assert no_fills['groups']['DAY']['held_lower_ratio']==0 and no_fills['groups']['DAY']['held_upper_ratio']==0
    checks['空対象は評価不能・非取得は保有ゼロ']=True
    invalid=day();invalid['phases']=[{'name':'DAY','start':0,'end':20}]
    rejects(A.holding_summary,[invalid],[])
    invalid=night();invalid['phases'][1]['start']=299
    rejects(A.holding_summary,[invalid],[])
    rejects(A.holding_summary,[day()],[position(fill=10,exit_time=9)])
    rejects(A.holding_summary,[day()],[position(fill=10,exit_time=None,confirmed_until=50,possible_until=40)])
    rejects(A.holding_summary,[day()],[position(quantity=0)])
    rejects(A.holding_summary,[day()],[position(fill=-1)])
    rejects(A.holding_summary,[day()],[position(fill=float('nan'))])
    rejects(A.holding_summary,[day()],[position('別場')])
    checks['欠測を除く帯穴・重複帯・逆時計・数量0・場外・非有限を拒否']=True
    # ----------------------------------------
    # 整数秒の人工建玉を1秒ごとの占有配列へ展開し、区間和集合と別照合する。
    rng=random.Random(179);random_cells=0
    for _ in range(80):
        records=[];lower=[False]*100;upper=[False]*100
        for _ in range(rng.randrange(12)):
            fill=rng.randrange(100);lo=rng.randrange(fill,101);hi=rng.randrange(lo,101)
            known=rng.choice((True,False));exit_time=lo if known else None
            records.append(position(fill=fill,exit_time=exit_time,confirmed_until=lo,possible_until=hi,quantity=rng.randrange(1,11)))
            for second in range(fill,lo):lower[second]=True
            for second in range(fill,lo if known else hi):upper[second]=True
        actual=A.holding_summary([day()],records)['groups']['DAY']
        close(actual['held_lower_seconds'],sum(lower));close(actual['held_upper_seconds'],sum(upper));random_cells+=200
    checks['人工80ケースの整数秒展開と和集合別照合']=True
    # ----------------------------------------
    # 場内総利益が大きい赤字場と、正の場純益が大きい場を異なる順位にする。
    ids=[f'2026-01-0{i}_Day' for i in range(1,6)]
    group=money_group([1000,-1200,500,100,None,50,-150],[True,True,True,True,False,True,True],
        [ids[0],ids[0],ids[1],ids[2],ids[2],ids[4],ids[4]],ids)
    original=deepcopy(group);financial=A.financial_diagnostics(group);assert original==group
    assert financial['known_profit']==1650 and financial['known_loss']==1350 and financial['known_net']==300
    assert financial['all_net'] is None and financial['unknown_scene_count']==1
    assert financial['positive_complete_scene_count']==1 and financial['negative_complete_scene_count']==2
    assert financial['zero_complete_scene_count']==1 and financial['zero_acquisition_scene_count']==1
    gross=financial['concentration']['gross_profit']['top'];net=financial['concentration']['positive_scene_net']['top']
    complete=financial['concentration']['positive_complete_scene_net']
    assert gross[0]['removed_scenes']==[ids[0]] and gross[0]['remaining']['known_net']==500
    close(gross[0]['share'],1000/1650)
    assert net[0]['removed_scenes']==[ids[1]] and net[0]['remaining']['known_net']==-200
    close(net[0]['share'],500/600)
    assert net[1]['actual_removed_scene_count']==2 and net[1]['remaining']['all_net']==-300
    assert net[1]['removed_unknown_scene_count']==1 and net[1]['remaining']['unknown_trade_count']==0
    assert complete['unknown_scenes_omitted_from_ranking']==1
    assert complete['top'][1]['actual_removed_scene_count']==1 and complete['top'][1]['remaining']['all_net'] is None
    assert financial['path']['exact_path'] is None
    assert financial['path']['known_contribution']['max_drawdown_amount']==200
    assert financial['path']['complete_prefix']['scene_count']==2
    assert financial['trade_count_distribution']['histogram']==[{'trade_count':0,'scene_count':1},{'trade_count':1,'scene_count':1},{'trade_count':2,'scene_count':3}]
    close(financial['trade_count_distribution']['mean'],1.4)
    checks['総利益と正純益の別順位・未知場除外の可視化・赤字場をゼロ点で便宜削除しない']=True
    checks['黒字赤字未知0取得場・取得分布・完全DDと既知寄与DD区別']=True
    only_unknown=A.financial_diagnostics(money_group([None],[False],[ids[0]],[ids[0]]))
    assert only_unknown['all_net'] is None and only_unknown['path']['exact_path'] is None
    assert only_unknown['concentration']['gross_profit']['top'][0]['share'] is None
    assert only_unknown['concentration']['gross_profit']['top'][0]['remaining']['all_net'] is None
    red=A.financial_diagnostics(money_group([-100],[True],[ids[0]],[ids[0]]))
    assert all(v['top'][2]['actual_removed_scene_count']==0 and v['top'][2]['remaining']['all_net']==-100 for v in red['concentration'].values())
    single=A.financial_diagnostics(money_group([100],[True],[ids[0]],[ids[0]]))
    assert single['concentration']['gross_profit']['top'][0]['remaining']['all_net'] is None
    invalid=deepcopy(group);invalid['sessions']['rows'][2]['all_net']=0
    rejects(A.financial_diagnostics,invalid)
    checks['全未知・全赤字・残存0場は架空の安定黒字にしない']=True
    assert source_sha==hashlib.sha256((HERE/'activity179.py').read_bytes()).hexdigest()
    sample={'人工例':True,'sessions':sessions,'positions':positions,'holding_summary':result,
        '未知例':{'sessions':[day()],'positions':[position(fill=20,exit_time=None)],'holding_summary':uncertain},
        'financial_group':group,'financial_diagnostics':financial}
    (HERE/'人工サンプル.json').write_text(json.dumps(sample,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    proof={'成功':True,'自然入力・金融順位未読':True,'SourceSHA256':source_sha,'人工検査数':len(checks),
        '整数秒別展開セル':random_cells,'検査':checks,'I/Fサンプル':'work/179参加時間と利益集中/人工サンプル.json'}
    (HERE/'人工結果.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':main()
