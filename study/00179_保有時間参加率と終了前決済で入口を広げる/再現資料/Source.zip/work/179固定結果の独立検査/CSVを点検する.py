"""179の五候補25CSVを、独立金融と端点分割の保有時間へ全セル照合する。"""
from pathlib import Path
import json
import sys
import statistics

import independent179 as I
from 原BBOを点検する import fingerprint

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
OUTPUT=ROOT/'outputs/00179_保有時間参加と終了前決済'
PACK=ROOT/'work/179保有参加の探索/全80の固定結果179.json.gz'
TYPED=ROOT/'work/179候補別CSV/型付き入力.json'
FIXED=ROOT/'work/179保有参加の探索/旧73の固定選択.json'
SUMMARY=['候補','選択区分','区分','対象場数','取得場数','取引回数','保有率下限','保有率上限','場別保有率中央値下限',
    '20%以上の場数','利益円_既知','損失円_既知','収支円_既知','利益損失比','黒字確定場数','赤字確定場数','未知場数',
    '上位3正純益場割合','上位3正純益場除外後収支円_既知','建玉中央値下限円','場中央値下限円','両中央値',
    'F','A','N','C','金融未知件数','先着率','強制決済件数','終了前決済未確認場数','原候補ID']
COLUMNS=['候補','選択区分','セッション日','セッションID','利益円_既知','損失円_既知','収支円_既知分','収支円_全件確定',
    '累計収支円_既知分','累計収支円_全件確定','取引回数','保有率下限','保有率上限','保有分下限','保有分上限','対象分',
    '保有20%以上確定','旧主取得','新枝取得','初参加T取得','F','A','N','C','金融未知件数','累計金融未知件数',
    '強制決済件数','終了前全決済確認','原候補ID','取引なし理由']


def tables(alias: str, row: dict) -> dict:
    """
    機能: 台帳金融・端点分割の保有から候補単独五表を組み立てる。
    引数: alias(str)は表示ID、row(dict)は全80固定pack。
    返り値: dictは照合値。CSVファイルへ書き込まない。
    """
    groups=I.financial_groups(row);held=I.holding(row['sessions'],row['positions']);ledger=row['ledger']
    closure={r['scene']:r for r in held['closure']['rows']};candidate='179:'+alias;route=row['policy']['route']
    output={'候補比較':[]}
    for band,name in [('DAY','デイ'),('NIGHT','ナイト合計'),('PRE','ナイト_米前'),('POST','ナイト_米後')]:
        group=groups[band];trade=group['trades'];session=group['sessions'];hold=held['groups'][band]
        selected=[i for i,phase in enumerate(ledger['phase']) if (phase>0 if band=='NIGHT' else phase==('DAY','PRE','POST').index(band))]
        scores=sorted([max(0,s['known_net']) for s in session['rows']],reverse=True);denominator=sum(scores);top=sum(scores[:3])
        fa=trade['IFD_FIRSTFANC'];loss=trade['known_loss']
        output['候補比較'].append([candidate,route,band,session['eligible_count'],session['participating_count'],trade['all_count'],
            hold['held_lower_ratio'],hold['held_upper_ratio'],hold['scene_ratio_median_lower'],hold['scene_target_met_guaranteed_count'],
            trade['known_profit'],loss,trade['known_net'],trade['known_profit']/loss if loss else None,
            session['complete_positive_count'],session['complete_negative_count'],session['unknown_count'],
            top/denominator if denominator else None,trade['known_net']-top,trade['net_median']['lower'],session['net_median']['lower'],group['decision']['status'],
            *[fa[k] for k in ('F','A','N','C')],trade['unknown_count'],fa['first_f_rate_reached'],sum(ledger['forced'][i] for i in selected),
            sum(closure[s['scene']]['flat_guaranteed'] is None for s in session['rows']),row['id']])
        time={r['scene']:r for r in hold['rows']};cumulative=0.;unknown=0;lines=[]
        for scene in sorted(session['rows'],key=lambda s:s['scene']):
            identity=scene['scene'];cumulative+=scene['known_net'];unknown+=scene['unknown_count']
            indices=[i for i in selected if ledger['scene'][i]==identity];t=time[identity]
            new=sum(ledger['added'][i] for i in indices);fallback=sum(ledger['origin'][i]==2 for i in indices)
            labels=[sum(ledger['label'][i]==code for i in indices) for code in (1,-1,0,2)]
            flat=closure[identity]['flat_guaranteed'];state='確認済' if flat is True else '未知' if flat is None else '違反'
            reason='' if indices else '帯内の新規取得なし。保有時間には他帯で取得した建玉も実時間配分する。'
            lines.append([candidate,route,identity[:10],identity,scene['known_profit'],scene['known_loss'],scene['known_net'],scene['all_net'],
                cumulative,cumulative if not unknown else None,len(indices),t['held_lower_ratio'],t['held_upper_ratio'],
                t['held_lower_seconds']/60,t['held_upper_seconds']/60,t['eligible_seconds']/60,t['target_status'],
                len(indices)-new-fallback,new,fallback,*labels,scene['unknown_count'],unknown,sum(ledger['forced'][i] for i in indices),state,row['id'],reason])
        assert len(lines)==40;output[name]=lines
    return output


def main() -> None:
    """
    機能: 固定主二案＋旧全期三対照の25CSVを全セル読取専用で点検する。
    引数: なし。
    返り値: None。担当workへJSONだけを保存し、CSVを作成/編集しない。
    """
    C=I.module(ROOT/'work/177増分の独立検査/CSVを点検する.py','csv177_for179')
    files=[PACK,TYPED,FIXED,*sorted(OUTPUT.rglob('*.csv')),Path(__file__)]
    assert len(files)==29;before=[fingerprint(path) for path in files]
    data=I.V.read(PACK);typed=I.V.read(TYPED);fixed=I.V.read(FIXED);by_id={r['id']:r for r in data['rows']}
    choices=[(fixed['選択'][route]['主案'],fixed['選択'][route]['主案']) for route in ('全期','前48')]
    choices += [('旧174_新時計','C174_全期_J002'),('旧177_新時計','C177_全期_J002_J000'),('旧178_新時計','C178_全期_J002_J000_K012')]
    assert typed['trial']==179 and typed['inputs']==[fingerprint(PACK)]
    assert typed['候補対応']==[{'表示ID':'179:'+alias,'原候補ID':identity} for alias,identity in choices]
    assert typed['tables']['候補比較']['headers']==SUMMARY
    assert all(t['headers']==COLUMNS for name,t in typed['tables'].items() if name!='候補比較')
    counter={'scalar':0,'files':0,'rows':0,'cells':0,'typed_tables':0};actual_files=set();header_cells=0
    for alias,identity in choices:
        expected=tables(alias,by_id[identity])
        for name,wanted in expected.items():
            selected=[r for r in typed['tables'][name]['rows'] if r[0]=='179:'+alias]
            I.V.compare(wanted,selected,alias+'/'+name+'/型付き値',counter);counter['typed_tables']+=1
            path=OUTPUT/('179_'+alias)/('集計.csv' if name=='候補比較' else name+'.csv')
            columns=SUMMARY if name=='候補比較' else COLUMNS
            C.compare_csv(path,columns,wanted,counter);header_cells+=len(columns);actual_files.add(path)
    assert actual_files==set(OUTPUT.rglob('*.csv')) and counter['files']==25
    assert before==[fingerprint(path) for path in files]
    result={'成功':True,'対象候補':choices,'検査':counter,'ヘッダーセル':header_cells,'ヘッダー込セル':counter['cells']+header_cells,
        '不一致':0,'CSVと入力不変':True,'入力':before,
        '方法':'25表全ての金融は台帳の独立集計、保有率は原positionsの端点分割で算出。候補名/対照対応、各帯40場、未知空欄/締切未知を確認。'}
    (HERE/'候補別CSVの独立結果.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps({k:result[k] for k in ('成功','検査','ヘッダーセル','ヘッダー込セル','不一致','CSVと入力不変')},ensure_ascii=False))


if __name__=='__main__':main()
