"""原行逐次シミュレーターを人工48byte列でearly179へ照合する。自然金融は読まない。"""
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import sys
import numpy as np

import scan179 as S

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
EARLY=ROOT/'work/179終了前決済/early179.py'


def records(times: list|None=None) -> np.ndarray:
    """
    機能: 正常な一定BBOを持つ人工原行を作る。
    引数: times(list|None)は省略時0～1100秒。
    返り値: np.ndarrayは48byte構造化配列。
    """
    times=list(range(1101)) if times is None else times
    rows=np.zeros(len(times),dtype=S.RECORD);rows['time']=times;rows['source_line']=np.arange(1,len(times)+1)
    rows['last']=1002;rows['bid']=1000;rows['ask']=1005;rows['normal']=1;return rows


def compare(expected: object, actual: object, where: tuple) -> None:
    """
    機能: 未知NaNと数値丸めを区別して一つの期待値を照合する。
    引数: expected/actual(object)、where(tuple)は箇所。
    返り値: None。不一致はAssertionError。
    """
    if expected is None:assert math.isnan(float(actual)),(where,expected,actual)
    elif isinstance(expected,float):assert math.isclose(expected,float(actual),abs_tol=1e-8,rel_tol=1e-12),(where,expected,actual)
    else:assert expected==actual,(where,expected,actual)


def main() -> None:
    """
    機能: gap・期限・同原行優先・同秒原行順・両側・費用を人工値で照合する。
    引数: なし。
    返り値: None。担当workに人工票だけを保存する。
    """
    spec=importlib.util.spec_from_file_location('early179_seq_artificial',EARLY);E=importlib.util.module_from_spec(spec)
    sys.modules[spec.name]=E;spec.loader.exec_module(E)
    assert E.CONFIG==S.CONFIG
    source_sha=hashlib.sha256(EARLY.read_bytes()).hexdigest();fixtures={}
    fixtures['通常と強制']=records()
    fixtures['価格gap']=records(list(range(50))+list(range(600,1101)))
    gap=records();mask=(gap['time']>=50)&(gap['time']<=600);gap['normal'][mask]=0;gap['bid'][mask]=gap['ask'][mask]=0
    fixtures['BBOgap']=gap
    timeout=records();mask=(timeout['time']>=9)&(timeout['time']<=49);timeout['normal'][mask]=0;timeout['bid'][mask]=timeout['ask'][mask]=0
    fixtures['通常期限猶予不足']=timeout
    missing=records();mask=missing['time']>=1040;missing['normal'][mask]=0;missing['bid'][mask]=missing['ask'][mask]=0
    fixtures['強制返済窓不足']=missing
    fixtures['EOF']=records(list(range(1001)))
    ordinary_hit=records();mask=ordinary_hit['time']>=10;ordinary_hit['bid'][mask]=1015;ordinary_hit['ask'][mask]=1020
    fixtures['通常同原行IFD優先']=ordinary_hit
    forced_hit=records();mask=forced_hit['time']>=1041;forced_hit['bid'][mask]=1015;forced_hit['ask'][mask]=1020
    fixtures['強制同原行IFD優先']=forced_hit
    same_second=records(list(range(1042))+[1041]+list(range(1042,1101)))
    same_second['bid'][1042]=1015;same_second['ask'][1042]=1020
    fixtures['強制同秒は最初原行']=same_second
    horizons=[{'id':'短期','kind':'strict','seconds':10},{'id':'同時計','kind':'strict','seconds':1041},{'id':'SESSION','kind':'session'}]
    widths=[10,125];checks=0;cell_count=0;statuses=set()
    fields=('known','label','status','forced','exit_time','known_at','exit_index','exit_line','exit_price','exit_quote_time',
        'points','net0','net','holding_confirmed_until','nominal_deadline','exit_deadline')
    for name,rows in fixtures.items():
        entries=np.asarray([0]+([1040] if len(rows)>1040 and S.normal(rows[1040]) else []),dtype=np.int64)
        actual=E.evaluate_records(rows,entries,2000,widths,horizons)
        for ci,entry in enumerate(entries):
            for side in (0,1):
                for wi,width in enumerate(widths):
                    for hi,horizon in enumerate(horizons):
                        expected=S.scan_one(rows,int(entry),2000,width,horizon,side);key=(ci,side,wi,hi)
                        for field in fields:compare(expected[field],actual[field][key],(name,int(entry),side,width,horizon['id'],field));checks+=1
                        statuses.add(expected['status']);cell_count+=1
    constant=S.scan_one(fixtures['通常と強制'],0,2000,125,horizons[0],0)
    assert constant['exit_time']==10 and constant['points']==-5 and constant['net0']==-577 and constant['net']==-1577
    force=S.scan_one(fixtures['通常と強制'],0,2000,125,horizons[2],1)
    assert force['exit_time']==1041 and force['status']==4 and force['forced']
    assert {1,2,3,4,10,11,12,13,14,15}<=statuses
    assert source_sha==hashlib.sha256(EARLY.read_bytes()).hexdigest()
    result={'成功':True,'自然入力未読':True,'人工列':len(fixtures),'人工case側幅期限':cell_count,'照合値':checks,
        '確認status':sorted(statuses),'費用を原BBO価格差と別計算':True,'earlySourceSHA256':source_sha,
        '独立SourceSHA256':hashlib.sha256((HERE/'scan179.py').read_bytes()).hexdigest()}
    (HERE/'逐次走査の人工結果.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':main()
