"""179固定十政策を台帳・秒区間・予約・金融・集中へ独立照合する。"""
from pathlib import Path
from collections import Counter
from datetime import datetime, time, timezone, timedelta
from zoneinfo import ZoneInfo
import copy
import json
import math
import statistics
import sys
import numpy as np

import independent179 as I
from 原BBOを点検する import fingerprint, read, F0, EXPECTED_F0

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
SOURCE=ROOT/'work/179保有参加の探索'
V=I.V


def counts(rows: list) -> dict:
    """
    機能: 完全場の符号・未知・無取引場を別計数する。
    引数: rows(list[dict])は全対象場。
    返り値: dictはactivity179契約の場数。
    """
    complete=[r for r in rows if not r['unknown_count']]
    return {'scene_count':len(rows),'complete_scene_count':len(complete),
        'positive_complete_scene_count':sum(r['all_net']>0 for r in complete),
        'negative_complete_scene_count':sum(r['all_net']<0 for r in complete),
        'zero_complete_scene_count':sum(r['all_net']==0 for r in complete),
        'unknown_scene_count':len(rows)-len(complete),'unknown_trade_count':sum(r['unknown_count'] for r in rows),
        'zero_acquisition_scene_count':sum(r['all_count']==0 for r in rows)}


def check_financial(row: dict, groups: dict, where: str, counter: dict) -> None:
    """
    機能: 独立金融と上位場除外後の全金額・分布・DDを保存evidenceへ照合する。
    引数: row(dict)、groups(dict)、where(str)、counter(dict)。
    返り値: None。不一致は例外。
    """
    saved=row['evidence'];actual=I.Q.financial_actual(saved['financial'])
    for band,g in groups.items():V.compare(g,actual[band],where+'/'+band+'/金融',counter);counter['financial_group']+=1
    V.compare(groups['DAY'],saved['financial']['session_groups_required']['DAY'],where+'/DAY重複群',counter)
    for band in ('DAY','NIGHT','PRE','POST'):
        g=groups[band];rows=g['sessions']['rows'];trade=g['trades'];diag=saved['concentration'][band]
        core={**counts(rows),'trade_count':trade['all_count'],'known_profit':trade['known_profit'],'known_loss':trade['known_loss'],
            'known_net':trade['known_net'],'all_net':trade['known_net'] if rows and not trade['unknown_count'] else None,
            'all_net_exact':bool(rows and not trade['unknown_count']),'decision':g['decision'],
            'trade_net_median':trade['net_median'],'session_net_median':g['sessions']['net_median']}
        for key,value in core.items():V.compare(value,diag[key],where+'/'+band+'/集中総計/'+key,counter)
        for basis in ('gross_profit','positive_scene_net','positive_complete_scene_net'):
            score={r['scene']:(r['known_profit'] if basis=='gross_profit' else max(0,r['known_net'])) for r in rows}
            if basis=='positive_complete_scene_net':score={r['scene']:max(0,r['all_net']) for r in rows if not r['unknown_count']}
            positive=sorted([r for r in rows if score.get(r['scene'],0)>0],key=lambda r:(-score[r['scene']],r['scene']))
            total=sum(score.values());concentration=diag['concentration'][basis]
            V.compare(total,concentration['ranking_value_total'],where+'/'+band+'/'+basis+'/総順位値',counter)
            assert concentration['positive_ranking_scene_count']==len(positive)
            for index,k in enumerate((1,3,5)):
                removed=positive[:k];ids={r['scene'] for r in removed};remaining=[r for r in rows if r['scene'] not in ids]
                value=sum(score[r['scene']] for r in removed);c=counts(remaining);net=sum(r['known_net'] for r in remaining)
                expected={'requested_top_count':k,'actual_removed_scene_count':len(removed),'removed_scenes':[r['scene'] for r in removed],
                    'amount':value,'share':value/total if total else None,'removed_unknown_scene_count':sum(r['unknown_count']>0 for r in removed),
                    'removed_unknown_trade_count':sum(r['unknown_count'] for r in removed),
                    'remaining':{**c,'trade_count':sum(r['all_count'] for r in remaining),'known_profit':sum(r['known_profit'] for r in remaining),
                        'known_loss':sum(r['known_loss'] for r in remaining),'known_net':net,
                        'all_net':net if remaining and not c['unknown_trade_count'] else None,'all_net_exact':bool(remaining and not c['unknown_trade_count'])}}
                V.compare(expected,concentration['top'][index],where+'/'+band+'/'+basis+'/'+str(k),counter);counter['concentration_top']+=1
        histogram=Counter(r['all_count'] for r in rows);values=[r['all_count'] for r in rows]
        distribution=diag['trade_count_distribution']
        for key,value in {'eligible_scene_count':len(rows),'trade_count':sum(values),'minimum':min(values,default=None),
            'median':statistics.median(values) if values else None,'mean':sum(values)/len(values) if values else None,
            'maximum':max(values,default=None),'histogram':[{'trade_count':k,'scene_count':v} for k,v in sorted(histogram.items())]}.items():
            V.compare(value,distribution[key],where+'/'+band+'/取得分布/'+key,counter)
        V.compare(I.Q.full_risk(g),{k:v for k,v in diag['path'].items() if k not in ('version','notes')},where+'/'+band+'/経路',counter)
        counter['path_group']+=1


def check_evidence(row: dict, where: str, counter: dict) -> dict:
    """
    機能: 台帳金融と端点分割保有を同じ対象場で照合する。
    引数: row(dict)、where(str)、counter(dict)。
    返り値: dictは独立集計。
    """
    groups=I.financial_groups(row);held=I.holding(row['sessions'],row['positions'])
    V.compare(held,{key:row['evidence']['holding'][key] for key in held},where+'/保有',counter)
    counter['holding_scope']+=1;check_financial(row,groups,where,counter)
    return {'financial':groups,'holding':held}


def subset(row: dict, scene_ids: set, evidence: dict) -> dict:
    """
    機能: 台帳と保有を同じ場集合で直接切り出す。
    引数: row(dict)、scene_ids(set[str])、evidence(dict)は保存期間evidence。
    返り値: dictは独立期間集計の入力。
    """
    indices=[i for i,s in enumerate(row['ledger']['scene']) if s in scene_ids]
    return {'ledger':{key:[values[i] for i in indices] for key,values in row['ledger'].items()},
        'sessions':[s for s in row['sessions'] if s['scene'] in scene_ids],
        'positions':[p for p in row['positions'] if p['scene'] in scene_ids],'evidence':evidence}


def check_clock(row: dict) -> None:
    """
    機能: 日本時間の固定開始/cutとNY09:30境界を独立に検査する。
    引数: row(dict)はsessionsを持つ固定pack。
    返り値: None。欠測で分母を削る時計を認めない。
    """
    jst=timezone(timedelta(hours=9))
    for s in row['sessions']:
        start=datetime.fromtimestamp(s['start'],jst);end=datetime.fromtimestamp(s['end'],jst)
        assert s['end']==s['original_end']-900 and s['close_deadline']==s['end']
        assert (start.strftime('%H:%M'),end.strftime('%H:%M'))==(('08:45','15:30') if s['kind']=='DAY' else ('17:00','05:45'))
        if s['kind']=='NIGHT':
            d=datetime.fromisoformat(s['scene'][:10]).date();boundary=datetime.combine(d,time(9,30),ZoneInfo('America/New_York')).timestamp()
            assert s['phases'][0]['end']==s['phases'][1]['start']==boundary


def check_market(context: object, arrays: dict, row: dict, counter: dict) -> None:
    """
    機能: 固定台帳をoverlay全セルと元取得へ照合し、予約区間の一枠不変を確認する。
    引数: context(object)、arrays(dict)、row(dict)、counter(dict)。
    返り値: None。engineの保有フラグを確定保有時間には使用しない。
    """
    ledger=row['ledger'];selection=row['selection'];n=len(ledger['net']);assert len(row['positions'])==n
    cases=np.asarray(selection['cases']);sides=np.asarray(selection['sides']);events=np.asarray(selection['events'])
    wi=np.asarray(selection['width_indices']);hi=np.asarray(selection['horizon_indices']);key=(cases,sides,wi,hi);known=arrays['known'][key]
    expected={'net':[float(v) if k else None for v,k in zip(arrays['net'][key],known)],'known':known.tolist(),'label':arrays['label'][key].tolist(),
        'scene':[context.sessions[int(i)] for i in context.case_scene[cases]],'phase':context.event_phases[events].tolist(),
        'origin':selection['origins'],'event':events.tolist(),'case':cases.tolist(),'case_id':[context.table.case_ids[int(c)] for c in cases],
        'side':sides.tolist(),'width':[int(context.table.widths[i]) for i in wi],'horizon':[context.table.horizons[i] for i in hi],
        'entry_time':context.arrays['entry_time'][cases].tolist(),'entry_price':context.arrays['entry_price'][cases,sides].tolist(),
        'exit_time':[float(v) if k else None for v,k in zip(arrays['exit_time'][key],known)],
        'exit_price':[float(v) if k else None for v,k in zip(arrays['exit_price'][key],known)],
        'exit_index':arrays['exit_index'][key].tolist(),'exit_line':arrays['exit_line'][key].tolist(),
        'forced':arrays['forced'][key].tolist(),'status':arrays['status'][key].tolist()}
    for field,value in expected.items():V.compare(value,ledger[field],row['id']+'/市場台帳/'+field,counter)
    for i,p in enumerate(row['positions']):
        scene=int(context.case_scene[cases[i]]);end=float(context.scenes[scene]['end'])-900;fill=expected['entry_time'][i]
        lower=float(arrays['holding_confirmed_until'][key][i]);lower=fill if not math.isfinite(lower) else max(fill,min(lower,end))
        fields={'scene':expected['scene'][i],'fill':fill,'exit':expected['exit_time'][i],'confirmed_until':lower,'possible_until':end,
            'quantity':1,'event':int(events[i]),'case':int(cases[i]),'side':int(sides[i]),'origin':selection['origins'][i]}
        V.compare(fields,p,row['id']+'/保有台帳/'+str(i),counter)
        assert fill<end-60 and (p['exit'] is None or p['exit']<=end)
    counter['market_trades']+=n
    engine=row['engine'];assert engine['capacity']==1 and engine['contracts_per_request']==1
    assert all(a['peak_global_reserved']<=1 and a['pending_at_scene_end']==[0,0] for a in engine['audits'])
    record_by_event={r['event']:r for r in engine['records']};assert len(record_by_event)==n
    record_index={int(event):i for i,event in enumerate(events)};caps=context._independent_caps
    previous={};seen={};accepted=cancelled=aliases=0
    for request in engine['requests']:
        event=request['event'];scene=request['scene_index'];start=tuple(request['at']);cut=float(context.scenes[scene]['end'])-900;stop=cut-60
        assert start==tuple(context.event_keys[event]) and context.event_scenes[event]==scene and start[0]<stop
        reserved=request['held_total_before']+request['pending_total_before'];assert reserved<=1 and request['accepted']==(reserved==0)
        if not request['accepted']:continue
        accepted+=1;capture=caps[event];clock=tuple(capture['fill_key'] if capture['status']=='filled' else capture['finish_key'])
        if clock[0]>=stop:end=(stop,math.inf,math.inf);cancelled+=1
        elif capture['status']!='filled':end=clock;cancelled+=1
        elif event in record_by_event:
            i=record_index[event];assert int(capture['case'])==ledger['case'][i]
            end=(ledger['exit_time'][i] if ledger['known'][i] else cut,math.inf,math.inf)
            seen.setdefault(scene,set()).add(int(capture['case']))
        else:
            assert int(capture['case']) in seen.get(scene,set());end=clock;aliases+=1
        assert scene not in previous or start>=previous[scene],(row['id'],'予約/保有の重複',event)
        assert end>=start;previous[scene]=end
    assert accepted==n+cancelled+aliases
    assert cancelled==sum(a['cancelled'] for a in engine['audits']) and aliases==sum(a['alias_fills_skipped'] for a in engine['audits'])
    counter['reservation_requests']+=len(engine['requests']);counter['accepted_reservations']+=accepted


def brief(result: dict) -> dict:
    """
    機能: 場別20%達成数・中央値・最小値と、独立金融の主要値をまとめる。
    引数: result(dict)は独立金融/保有。
    返り値: dictは帯別要約。
    """
    output={}
    for band,g in result['financial'].items():
        h=result['holding']['groups'][band];t=g['trades'];s=g['sessions']
        output[band]={'取得':t['all_count'],'参加場':s['participating_count'],'対象場':s['eligible_count'],
            '利益':t['known_profit'],'損失':t['known_loss'],'既知収支':t['known_net'],'金融未知':t['unknown_count'],
            '建玉中央値':t['net_median'],'場中央値':s['net_median'],'両中央値':g['decision']['status'],
            '保有下限比率':h['held_lower_ratio'],'保有上限比率':h['held_upper_ratio'],
            '場中央値下限比率':h['scene_ratio_median_lower'],'場中央値上限比率':h['scene_ratio_median_upper'],
            '場最小下限比率':min((r['held_lower_ratio'] for r in h['rows']),default=None),
            '保証20%以上場':h['scene_target_met_guaranteed_count'],'20%可能場':h['scene_target_met_possible_count'],
            '完全黒字場':s['complete_positive_count'],'完全赤字場':s['complete_negative_count'],'未知場':s['unknown_count']}
    return output


def main() -> None:
    """
    機能: 固定十政策の旧/追加/全80・前後と、routeだけの適用を独立照合する。
    引数: なし。自然固定結果のRoot GO後だけ実行する。
    返り値: None。担当workへ検査票を保存し、F0 Sourceは変更しない。
    """
    paths=[SOURCE/name for name in ('旧73の固定全取得179.json.gz','追加7の固定全取得179.json.gz','全80の固定結果179.json.gz','旧73の固定選択.json')]
    paths += [F0,Path(__file__),HERE/'independent179.py'];before=[fingerprint(path) for path in paths]
    assert fingerprint(F0)['sha256']==EXPECTED_F0
    docs={name:V.read(path) for name,path in zip(('旧73','追加7','全80'),paths[:3])};fixed=read(paths[3])
    ids=[r['id'] for r in docs['全80']['rows']];assert len(ids)==len(set(ids))==10
    assert all([r['id'] for r in d['rows']]==ids for d in docs.values())
    counter={'scalar':0,'financial_group':0,'holding_scope':0,'path_group':0,'concentration_top':0,
        'market_trades':0,'reservation_requests':0,'accepted_reservations':0,'route_guard':0}
    sys.path.insert(0,str(ROOT/'work/173両中央値と単一建玉'));import 基盤173 as B
    summaries={};by_id={name:{r['id']:r for r in d['rows']} for name,d in docs.items()}
    for new,period in ((False,'旧73'),(True,'追加7')):
        context=B.load_context(new);context._independent_caps=B.captures(context)
        with np.load(ROOT/'inputs/00179_終了前決済の共用数値表'/(period+'_overlay179.npz'),allow_pickle=False) as raw:
            arrays={key:raw[key] for key in ('known','label','net','exit_time','exit_price','exit_index','exit_line','forced','status','holding_confirmed_until')}
        summaries[period]={}
        for row in docs[period]['rows']:
            check_clock(row);check_market(context,arrays,row,counter)
            summaries[period][row['id']]=brief(check_evidence(row,period+'/'+row['id'],counter))
            if not new:
                for name,scenes in [('前48',row['sessions'][:48]),('後25',row['sessions'][48:])]:
                    result=check_evidence(subset(row,{s['scene'] for s in scenes},row['periods'][name]),name+'/'+row['id'],counter)
                    summaries.setdefault(name,{})[row['id']]=brief(result)
        del context,arrays
    summaries['全80']={}
    for row in docs['全80']['rows']:
        old,added=[by_id[name][row['id']] for name in ('旧73','追加7')]
        for key in ('sessions','positions'):V.compare(old[key]+added[key],row[key],row['id']+'/全80連結/'+key,counter)
        V.compare({key:old['ledger'][key]+added['ledger'][key] for key in old['ledger']},row['ledger'],row['id']+'/全80台帳連結',counter)
        result=check_evidence(row,'全80/'+row['id'],counter);summaries['全80'][row['id']]=brief(result)
    # ----------------------------------------
    # 最終票の各routeをguardへ通す。未選択全政策の順位を再探索する検査ではない。
    sys.path.insert(0,str(SOURCE));P=I.module(SOURCE/'探索179.py','rank179_fixed_independent')
    route_details=[]
    for route,selection in fixed['選択'].items():
        rows=[]
        for policy in selection['candidates']:
            old=by_id['旧73'][policy['id']];assert old['policy']==policy and policy['route']==route
            row={'id':old['id'],'policy':policy,'periods':{'全期':old['evidence'],**old['periods']}}
            normal=P.ranking(row,route,('DAY','NIGHT'))
            guarded={**row,'periods':V.OnlyPeriod({route:row['periods'][route]})}
            assert normal==P.ranking(guarded,route,('DAY','NIGHT'));counter['route_guard']+=1
            rows.append((normal,policy['id']))
        assert [identity for _,identity in sorted(rows)]==selection['参考候補']
        route_details.append({'route':route,'主案':selection['主案'],'参照':selection['参考候補'],'選択期間のみ参照':True})
    assert before==[fingerprint(path) for path in paths]
    result={'成功':True,'対象政策':ids,'検査':counter,'不一致':0,'Sourceと入力不変':True,'入力':before,'要約':summaries,'route検査':route_details,
        '範囲':['全80の期間平均ではなく台帳と秒区間を連結して独立再計算。未知はNone/保証下限/上限を保持。',
            '予約は原取得descriptorと実取得から全accepted予約の占有終端を再構成し、次予約との重複を検査。',
            '金融/集中/秒区間は独立集計。売買Sourceやengine自体を独立実装した検査ではない。',
            'route guardは固定票の期間適用を検査。未選択全政策の再順位付けや新探索はしない。']}
    (HERE/'固定十政策の独立結果.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps({key:result[key] for key in ('成功','対象政策','検査','不一致','Sourceと入力不変','route検査')},ensure_ascii=False))


if __name__=='__main__':main()
