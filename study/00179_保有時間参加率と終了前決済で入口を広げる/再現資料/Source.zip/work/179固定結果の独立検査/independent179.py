"""179固定結果の独立集計。保有時間は端点分割の被覆判定で求める。"""
from collections import Counter
import importlib.util
from pathlib import Path
import statistics
import sys

ROOT=Path(__file__).resolve().parents[2]


def module(path: Path, name: str) -> object:
    """
    機能: mainを開始せず固定された独立部品を読み込む。
    引数: path(Path)、name(str)。
    返り値: objectは読み込んだ部品。
    """
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec)
    sys.modules[name]=value;spec.loader.exec_module(value);return value


Q=module(ROOT/'work/176固定結果の独立検査/固定金融を点検する.py','financial176_for179')
V=Q.V;F=Q.F


def duration(intervals: list, start: float, end: float) -> float:
    """
    機能: 全端点で区間を分割し、どれかの保有で覆われる小区間を一度だけ加える。
    引数: intervals(list[tuple])は建玉区間、start/end(float)は対象窓。
    返り値: floatは被覆実秒。activity179の区間合併は使用しない。
    """
    clipped=[(max(a,start),min(b,end)) for a,b in intervals if max(a,start)<min(b,end)]
    points=sorted({start,end,*[v for interval in clipped for v in interval]})
    return sum(b-a for a,b in zip(points,points[1:]) if any(x<=a and b<=y for x,y in clipped))


def target(low: float|None, high: float|None, goal: float) -> dict:
    """
    機能: 比率境界を仕様の目標状態へ独立に分類する。
    引数: low/high(float|None)、goal(float)。
    返り値: dictは目標状態と保証/可能旗。
    """
    guaranteed=low is not None and low>=goal;possible=high is not None and high>=goal
    return {'target_status':'評価不能' if low is None else '達成' if guaranteed else '不確定' if possible else '未達',
        'target_met_guaranteed':guaranteed,'target_met_possible':possible}


def holding(sessions: list, positions: list, goal: float=.2) -> dict:
    """
    機能: 全対象時計・実取得区間から加重保有率と場中央値を独立に再計算する。
    引数: sessions(list[dict])、positions(list[dict])、goal(float)は目標。
    返り値: dictはactivity179のgroups/input_status_counts/closureに一致する内容。
    """
    by_scene={s['scene']:[] for s in sessions};statuses=Counter();groups={name:[] for name in ('DAY','NIGHT','PRE','POST','ALL')}
    for record in positions:
        status=record.get('status','filled');statuses[status]+=1
        if status=='filled':by_scene[record['scene']].append(record)
    closure=[]
    for session in sessions:
        records=by_scene[session['scene']];lower=[];upper=[]
        for record in records:
            fill=record['fill'];exit_time=record.get('exit')
            lo=exit_time if exit_time is not None else record.get('confirmed_until')
            lo=fill if lo is None else lo
            hi=exit_time if exit_time is not None else record.get('possible_until')
            hi=max(session['end'],lo) if hi is None else hi
            lower.append((fill,lo));upper.append((fill,hi))
        windows=[{'name':session['kind'],'start':session['start'],'end':session['end']}]
        if session['kind']=='NIGHT':windows.extend(session['phases'])
        for window in windows:
            start,end=window['start'],window['end'];denominator=end-start
            low=duration(lower,start,end);high=duration(upper,start,end)
            row={'scene':session['scene'],'kind':session['kind'],'phase':window['name'],'start':float(start),'end':float(end),
                'eligible_seconds':float(denominator),'held_lower_seconds':float(low),'held_upper_seconds':float(high),
                'held_lower_ratio':low/denominator,'held_upper_ratio':high/denominator,**target(low/denominator,high/denominator,goal)}
            groups[window['name']].append(row)
            if window['name']==session['kind']:groups['ALL'].append(dict(row))
        deadline=session.get('close_deadline',session['end'])
        late=sum(p.get('exit') is not None and p['exit']>deadline for p in records)
        past=sum(p.get('exit') is None and p.get('confirmed_until',p['fill'])>deadline for p in records)
        unknown=sum(p.get('exit') is None for p in records)
        closure.append({'scene':session['scene'],'close_deadline':float(deadline),'known_late_exit_count':late,
            'confirmed_held_past_deadline_count':past,'unknown_exit_count':unknown,
            'entry_at_or_after_deadline_count':sum(p['fill']>=deadline for p in records),
            'flat_guaranteed':False if late or past else None if unknown else True})
    output={}
    for name,rows in groups.items():
        rows.sort(key=lambda r:(r['start'],r['scene'],r['phase']))
        denominator=sum(r['eligible_seconds'] for r in rows);lo=sum(r['held_lower_seconds'] for r in rows);hi=sum(r['held_upper_seconds'] for r in rows)
        low_ratio=lo/denominator if denominator else None;high_ratio=hi/denominator if denominator else None
        low_median=statistics.median(r['held_lower_ratio'] for r in rows) if rows else None
        high_median=statistics.median(r['held_upper_ratio'] for r in rows) if rows else None
        output[name]={'eligible_scene_count':len(rows),'eligible_seconds':denominator,'held_lower_seconds':lo,'held_upper_seconds':hi,
            'held_lower_ratio':low_ratio,'held_upper_ratio':high_ratio,'scene_ratio_median_lower':low_median,'scene_ratio_median_upper':high_median,
            **target(low_ratio,high_ratio,goal),'median_target':target(low_median,high_median,goal),
            'scene_target_met_guaranteed_count':sum(r['target_met_guaranteed'] for r in rows),
            'scene_target_met_possible_count':sum(r['target_met_possible'] for r in rows),
            'uncertain_scene_count':sum(r['held_upper_seconds']>r['held_lower_seconds'] for r in rows),
            'zero_guaranteed_holding_scene_count':sum(r['held_lower_seconds']==0 for r in rows),'rows':rows}
    return {'groups':output,'input_status_counts':{name:statuses[name] for name in ('filled','pending','unfilled','cancelled','expired')},
        'closure':{'known_violation_scene_count':sum(r['flat_guaranteed'] is False for r in closure),
            'unresolved_scene_count':sum(r['flat_guaranteed'] is None for r in closure),
            'guaranteed_flat_scene_count':sum(r['flat_guaranteed'] is True for r in closure),
            'all_scenes_flat_guaranteed':all(r['flat_guaranteed'] is True for r in closure) if closure else None,'rows':closure}}


def financial_groups(row: dict) -> dict:
    """
    機能: 179台帳と対象帯時計から、173と同じ金融群を独立に組み直す。
    引数: row(dict)はledger/sessionsを持つ固定pack。
    返り値: dictはALL/DAY/PRE/POST/NIGHTの金融群。
    """
    ledger=row['ledger'];pack={'ledger':{key:ledger[key] for key in ('net','known','label','scene')},
        'phases':ledger['phase'],'origins':ledger['origin']}
    eligible={name:[] for name in ('DAY','PRE','POST')};hours={name:0.0 for name in eligible}
    for session in row['sessions']:
        for phase in session['phases']:
            eligible[phase['name']].append(session['scene']);hours[phase['name']]+=(phase['end']-phase['start'])/3600
    return F.financial_groups(pack,eligible,hours)
