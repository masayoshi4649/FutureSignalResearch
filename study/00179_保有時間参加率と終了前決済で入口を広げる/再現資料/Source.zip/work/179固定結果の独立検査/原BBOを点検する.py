"""179 overlayの少数自然セルを、原48byte列の逐次走査へ独立照合する。"""
from pathlib import Path
from datetime import datetime, timedelta, timezone
import argparse
import gzip
import hashlib
import json
import sys
import numpy as np

import scan179 as S
from 逐次走査の人工検査 import compare

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
F0=ROOT/'study/00179_保有時間参加率と終了前決済で入口を広げる/条件.json'
EXPECTED_F0='6d8284f96e615fb582d4786b9cfdbb95801f995fcdf11e2a5f3c157109c61073'
FIELDS=('known','label','status','forced','exit_time','known_at','exit_index','exit_line','exit_price','exit_quote_time',
    'points','net0','net','holding_confirmed_until','nominal_deadline','exit_deadline')


def fingerprint(path: Path) -> dict:
    """
    機能: 自然入力とSourceの全物理指紋を算出する。
    引数: path(Path)。
    返り値: dictは相対path/bytes/sha256。
    """
    with path.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':digest}


def read(path: Path) -> dict:
    """
    機能: UTF-8 JSONの小型metadataを読む。
    引数: path(Path)。
    返り値: dictは解析値。
    """
    return json.loads(path.read_text(encoding='utf-8-sig'))


def main() -> None:
    """
    機能: 旧73又は追加7のstatus別先頭セルを、原BBO・時計・費用へ照合する。
    引数: --period(str)は旧73/追加7。Rootのoverlay完成・自然金融GO後に実行する。
    返り値: None。検査JSONだけを担当workへ保存し、元入力を変更しない。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--period',choices=('旧73','追加7'),required=True);args=parser.parse_args()
    period=args.period;directory=ROOT/'inputs/00179_終了前決済の共用数値表'
    path=directory/(period+'_overlay179.npz');metadata_path=path.with_suffix('.json')
    assert fingerprint(F0)['sha256']==EXPECTED_F0;f0=read(F0)
    for reference in f0['Source']:assert fingerprint(ROOT/reference['path'])==reference
    metadata=read(metadata_path);assert metadata['成功'] and metadata['条件']==S.CONFIG
    assert fingerprint(path)==metadata['NPZ']
    assert fingerprint(ROOT/metadata['manifest']['path'])['sha256']==metadata['manifest']['sha256']
    early=ROOT/'work/179終了前決済/early179.py';assert fingerprint(early)['sha256']==metadata['SourceSHA256']
    references=[fingerprint(p) for p in (F0,path,metadata_path,early,HERE/'scan179.py',Path(__file__))]
    sys.path.insert(0,str(ROOT/'work/173両中央値と単一建玉'));import 基盤173 as B
    context=B.load_context(period=='追加7');binding=metadata['binding']
    assert binding['case数']==len(context.table.case_ids)
    encoded=json.dumps(list(context.table.case_ids),ensure_ascii=False,separators=(',',':')).encode()
    assert hashlib.sha256(encoded).hexdigest()==binding['case順SHA256']
    digest=hashlib.sha256()
    for key in ('entry_time','entry_index','entry_line','entry_price','session_index'):
        raw=np.ascontiguousarray(context.arrays[key]);digest.update(key.encode());digest.update(raw.dtype.str.encode());digest.update(raw.tobytes())
    assert digest.hexdigest()==binding['純取得SHA256']
    widths=list(context.table.widths);horizons=context.table.evidence['条件']['horizons']
    assert binding['幅']==widths and binding['期限']==list(context.table.horizons)
    with np.load(path,allow_pickle=False) as archive:arrays={key:archive[key] for key in FIELDS}
    selected=[];coverage={}
    for status in (1,2,3,4,10,11,12,13,14,15):
        coverage[status]=[]
        for side in (0,1):
            mask=arrays['status'][:,side,:,:]==status
            if not mask.any():continue
            case,wi,hi=np.unravel_index(int(np.argmax(mask)),mask.shape)
            selected.append({'case':int(case),'side':side,'wi':int(wi),'hi':int(hi),'status':status,
                'scene':int(context.case_scene[case])});coverage[status].append(side)
    assert coverage[3]==[0,1] and coverage[4]==[0,1]
    selected.sort(key=lambda r:(r['scene'],r['case'],r['side'],r['wi'],r['hi']))
    index_refs={row['session']:row for row in metadata['価格索引']};checks=[];value_count=0;source_count=0
    previous_scene=None;records=None
    for chosen in selected:
        scene=chosen['scene'];case=chosen['case'];side=chosen['side'];wi=chosen['wi'];hi=chosen['hi']
        session=context.sessions[scene]
        if scene!=previous_scene:
            reference=index_refs[session];index_path=ROOT/reference['path'];actual=fingerprint(index_path)
            assert actual['sha256']==reference['sha256'];references.append(actual)
            body=gzip.decompress(index_path.read_bytes());assert body[:8]==b'NQIDX163' and len(body)==8+48*reference['rows']
            records=np.frombuffer(body,dtype=S.RECORD,offset=8)
            assert len(records)==reference['rows'] and np.all(np.diff(records['time'])>=0) and np.all(np.diff(records['source_line'])>0)
            previous_scene=scene;source_count+=1
        entry=int(context.arrays['entry_index'][case]);row=records[entry]
        assert row['time']==context.arrays['entry_time'][case] and row['source_line']==context.arrays['entry_line'][case]
        assert row['ask']==context.arrays['entry_price'][case,0] and row['bid']==context.arrays['entry_price'][case,1]
        result=S.scan_one(records,entry,float(context.scenes[scene]['end']),float(widths[wi]),horizons[hi],side,metadata['条件'])
        key=(case,side,wi,hi)
        for field in FIELDS:compare(result[field],arrays[field][key],(period,session,case,side,widths[wi],horizons[hi]['id'],field));value_count+=1
        cut=datetime.fromtimestamp(result['audit']['cut'],timezone(timedelta(hours=9))).strftime('%H:%M:%S')
        assert cut==('15:30:00' if session.endswith('_Day') else '05:45:00')
        checks.append({'case':case,'case_id':context.table.case_ids[case],'session':session,'side':side,
            'width':widths[wi],'horizon':horizons[hi]['id'],'結果':result,'overlay一致':True,'cut_JST':cut})
    assert all(fingerprint(ROOT/r['path'])==r for r in references)
    result={'成功':True,'期間':period,'F0SHA256':EXPECTED_F0,'少数セル':len(checks),'照合値':value_count,'直接索引数':source_count,
        '抽出':'各status・買売ごとにcase/幅/期限の辞書式先頭。検査網羅用であり政策の順位/損益最適化には使わない。',
        'status実在側':coverage,'入力不変':True,'入力':references,'検査':checks,
        '独立性':'early179の極値木・terminal・censor・evaluate_recordsを呼ばず、48byte原行を逐次処理。両側BBO価格差から手数料77円/追加滑り1000円を別計算。'}
    target=HERE/('原BBO逐次結果_'+period+'.json');target.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps({key:result[key] for key in ('成功','期間','少数セル','照合値','直接索引数','status実在側','入力不変')},ensure_ascii=False))


if __name__=='__main__':main()
