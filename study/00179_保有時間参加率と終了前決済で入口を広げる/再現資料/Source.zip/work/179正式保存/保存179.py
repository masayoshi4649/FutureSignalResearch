"""179固定10政策と選択検算用軽量正本を、178 Source連鎖へ薄く追加保存する。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import gzip
import json
import os
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'work/178正式保存'))
import 保存178 as PREVIOUS
P=PREVIOUS.P
TRIAL=ROOT/'study/00179_保有時間参加率と終了前決済で入口を広げる'
PARENT=ROOT/'study/00178_新枝の実方向と複数足の背景を確認する/再現資料'
DESTINATION=TRIAL/'再現資料'
INPUT=ROOT/'inputs/00179_終了前決済の共用数値表'
CSV=ROOT/'outputs/00179_保有時間参加と終了前決済'
LARGE=('単帯の追加置換','二局面の追加置換','三帯の保有参加比較')


def inherited() -> tuple:
    """
    機能: 178までのSource連鎖と174/177/178旧6seal/proofだけを元byte継承する。
    引数: なし。
    返り値: tuple[dict,list,dict,list]はSource参照・旧入力参照・元byte・CSV差分上書き。
    """
    index=P.read(PARENT/'保存索引.json');assert index['正式保存']
    source_ref={'archive':index['Source']['archive'],'index':P.fingerprint(PARENT/'保存索引.json'),
        'members':index['Source']['members'],'親Source継承元':index['Source継承元']}
    PREVIOUS.verify_source(source_ref)
    assert P.fingerprint(Path(PREVIOUS.__file__))==next(r for r in source_ref['members'] if r['path']=='work/178正式保存/保存178.py')
    small={};records=[]
    folders={174:'00174_共同条件を残して単一建玉の入口を広げる',177:'00177_固定幹を保ち高ADXの入口を増分比較する',178:'00178_新枝の実方向と複数足の背景を確認する'}
    for trial,name in folders.items():
        folder=ROOT/'study'/name/'再現資料';old=P.read(folder/'保存索引.json');archive_path=folder/'出生と比較正本.zip'
        assert P.fingerprint(archive_path)==old['正本']['archive'];expected={r['path']:r for r in old['正本']['members']}
        names=[f'work/{trial}追加七場適用/{period}の純出生{trial}.npz' for period in ('旧73','追加7')]
        names.append(f'work/{trial}追加七場適用/金融前の出生固定.json')
        with zipfile.ZipFile(archive_path) as archive:
            for member in names:
                body=archive.read(member);assert P.member_reference(member,body)==expected[member];assert member not in small;small[member]=body
        records.append({'archive':P.fingerprint(archive_path),'index':P.fingerprint(folder/'保存索引.json'),'members':[expected[n] for n in names]})
    ancestor=source_ref;old_writer=None
    while ancestor:
        old_writer=next((r for r in ancestor['members'] if r['path']=='scripts/損益CSV/候補別に出力する.mjs'),None)
        if old_writer is not None:break
        ancestor=ancestor.get('親Source継承元')
    assert old_writer is not None
    new_writer=P.fingerprint(ROOT/old_writer['path'])
    overrides=[] if new_writer==old_writer else [{'path':old_writer['path'],'ancestor':old_writer,'new':new_writer,
        '理由':'179の5表tableNamesに対応する汎用CSV出力器。売買/金融Sourceの変更ではない。'}]
    return source_ref,records,small,overrides


def collect() -> tuple:
    """
    機能: 179 Source・固定全pack・小資料を集め、全段大重複と予備統計を省く。
    引数: なし。
    返り値: tuple[list,list,list]はSource・小正本・省略指紋。
    """
    sources=[];results=[];omitted=[]
    for folder in sorted(p for p in (ROOT/'work').glob('179*') if p.is_dir() and '隔離再現' not in p.name):
        for current,dirs,files in os.walk(folder,followlinks=False):
            dirs[:]=[n for n in dirs if n not in P.EXCLUDED_DIRS and 'cache' not in n.lower()]
            for name in files:
                path=Path(current)/name
                if path.suffix in ('.py','.mjs'):sources.append(path);continue
                if path.is_relative_to(HERE) and '軽量正本' not in path.parts and path.name!='README.md':continue
                if path.suffix not in ('.md','.json','.gz','.npz','.png','.jpg','.webp','.csv'):continue
                reason=None
                if path.parent==ROOT/'work/179保有参加の探索' and path.name in [n+'.json.gz' for n in LARGE]:
                    reason='全候補で重複する詳細診断約79MBは保存しない。元SHA・政策・選択必要数値・全行canonicalハッシュを別軽量正本へ保存。固定10は全packを保持。'
                elif path.suffix=='.npz' and '予備統計' in path.name:reason='再生成可能な予備統計。純出生/軸/Source/短表/元指紋を保持。'
                elif path.suffix in ('.png','.jpg','.webp'):reason='表示画像は再生成中間。閲覧確認JSONとCSVを参照。'
                elif path.suffix=='.csv':reason='CSV本文25本はoutputs正本へ指紋参照し二重保存しない。'
                if reason:omitted.append({'file':P.fingerprint(path),'理由':reason})
                else:assert path.stat().st_size<16*1024*1024;results.append(path)
    sources.append(ROOT/'scripts/損益CSV/候補別に出力する.mjs')
    results.extend(p for p in TRIAL.rglob('*') if p.is_file() and '再現資料' not in p.relative_to(TRIAL).parts and p.suffix in ('.json','.md'))
    assert HERE/'正式入力で再現する.py' in sources and Path(__file__) in sources
    return sorted(set(sources)),sorted(set(results)),sorted(omitted,key=lambda r:r['file']['path'])


def gates(final: bool, extra: list) -> dict:
    """
    機能: 固定10政策・preflight・純入力指紋・CSV25と最終隔離を確認する。
    引数: final(bool)、extra(list[Path])はRootが指定する独立検査等。
    返り値: dictは必須指紋と恒久overlay入力参照。
    """
    folder=ROOT/'work/179保有参加の探索'
    required=[TRIAL/'条件.json',TRIAL/'検査/純入力の指紋.json',TRIAL/'検査/旧73の金融表接続.json',TRIAL/'検査/追加7の金融表接続.json',
        *[folder/n for n in ('旧73の固定選択.json','追加適用前の固定.json','旧73の固定全取得179.json.gz','追加7の固定全取得179.json.gz','全80の固定結果179.json.gz')],
        *[ROOT/'work/179固定結果の独立検査'/n for n in ('固定十政策の独立結果.json','候補別CSVの独立結果.json')],*extra]
    assert all(p.is_file() for p in required),[str(p) for p in required if not p.is_file()]
    declaration=P.read(folder/'追加適用前の固定.json');assert declaration['成功'] and len(declaration['policies'])==10
    assert len({p['id'] for p in declaration['policies']})==10
    assert all(P.read(ROOT/'work/179固定結果の独立検査'/n)['成功'] for n in ('固定十政策の独立結果.json','候補別CSVの独立結果.json'))
    for period in ('旧73','追加7'):
        assert P.read(TRIAL/'検査'/(period+'の金融表接続.json'))['成功']
        rows=json.loads(gzip.decompress((folder/(period+'の固定全取得179.json.gz')).read_bytes()))['rows']
        assert [r['id'] for r in rows]==[p['id'] for p in declaration['policies']]
    inputs=[P.fingerprint(p) for p in sorted(INPUT.iterdir()) if p.is_file()]
    for period in ('旧73','追加7'):
        meta=P.read(INPUT/(period+'_overlay179.json'));assert meta['成功'] and meta['旧数値表の無変更領域照合']['成功']
        assert P.fingerprint(INPUT/(period+'_overlay179.npz'))==meta['NPZ']
    csv_files=sorted(CSV.rglob('*.csv'));assert len(csv_files)==25,CSV
    if final:
        assert all((TRIAL/n).is_file() for n in ('README.md','設定と結果.md','再現手順.md'))
        audit=ROOT/'work/179隔離再現/repo/work/監査結果.json';verification=ROOT/'work/179隔離再現/repo/work/正式runner確認/再現確認.json'
        assert P.read(audit)['成功'] and P.read(verification)['成功']
        assert P.fingerprint(ROOT/'work/179隔離再現/repo/work/179正式保存/正式入力で再現する.py')['sha256']==P.fingerprint(HERE/'正式入力で再現する.py')['sha256']
        assert P.read(audit)['監査SourceSHA256']==P.fingerprint(HERE/'監査実行.py')['sha256'];required.extend([audit,verification])
    return {'成功':True,'必須':[P.fingerprint(p) for p in sorted(set(required))],'恒久overlay入力':inputs,
        'CSV25':[P.fingerprint(p) for p in csv_files],'固定10全台帳保持':True}


def execute(destination: Path, final: bool, extra: list) -> dict:
    """
    機能: Source連鎖・固定10全pack・軽量選択根拠を別の新規ZIPへ保存する。
    引数: destination(Path)、final(bool)、extra(list[Path])。
    返り値: dictは保存索引。旧Source/旧ZIP/79MB元正本を編集しない。
    """
    assert not any((destination/n).exists() for n in ('Source.zip','出生と比較正本.zip','保存索引.json'))
    light=B_module(HERE/'軽量正本を作る.py','light179_storage');light_proof=light.build()
    gate=gates(final,extra);source_ref,old_refs,old_small,overrides=inherited();source_paths,result_paths,omitted=collect()
    before={p.relative_to(ROOT).as_posix():P.fingerprint(p) for p in source_paths+result_paths}
    source_bytes={p.relative_to(ROOT).as_posix():p.read_bytes() for p in source_paths}
    ancestor=source_ref;ancestor_names=set()
    while ancestor:
        ancestor_names.update(r['path'] for r in ancestor['members']);ancestor=ancestor.get('親Source継承元')
    assert set(source_bytes)&ancestor_names=={r['path'] for r in overrides}
    source_bytes['継承/178Sourceの参照.json']=(json.dumps({'元Source':source_ref,'179上書き':overrides},ensure_ascii=False,separators=(',',':'))+'\n').encode('utf-8')
    results={p.relative_to(ROOT).as_posix():p.read_bytes() for p in result_paths};assert not set(results)&set(old_small);results.update(old_small)
    if final:
        for p in (ROOT/'work/179隔離再現/repo/work/監査結果.json',ROOT/'work/179隔離再現/repo/work/正式runner確認/再現確認.json'):
            results['検査/179隔離/'+p.name]=p.read_bytes()
    destination.mkdir(parents=True,exist_ok=True)
    source=P.write_archive(destination/'Source.zip',source_bytes);canonical=P.write_archive(destination/'出生と比較正本.zip',results)
    assert all(P.fingerprint(ROOT/name)==value for name,value in before.items());PREVIOUS.verify_source(source_ref)
    index={'成功':True,'正式保存':final,'保存UTC':datetime.now(timezone.utc).isoformat(),'Source':source,'正本':canonical,
        'Source継承元':source_ref,'Source差分上書き':overrides,'旧小入力の選択継承':old_refs,'軽量段階正本':light_proof,
        '新Source':[P.fingerprint(p) for p in source_paths],'完了gate':gate,'省略中間指紋':omitted,'保存器':P.fingerprint(Path(__file__)),
        '注意':'179有望なDAY改善。固定10政策を再現の主対象とし、全段を保存義務へ追加しない。overlayはinputs179一組を共用、旧/追加/全80既使用。'}
    (destination/'保存索引.json').write_text(json.dumps(index,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    return index


def B_module(path: Path, name: str) -> object:
    """
    機能: 保存時だけ使う軽量化Sourceを明示読込する。
    引数: path(Path)、name(str)。
    返り値: objectはmodule。
    """
    import importlib.util
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);sys.modules[name]=value;spec.loader.exec_module(value);return value


def main() -> None:
    """
    機能: work内仮保存とRoot GO後の正式保存を区別して実行する。
    引数: --prepare(bool)、--execute/--go(bool)、--require(Path,反復可)。
    返り値: None。指定なしで正式ZIPを作らない。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--prepare',action='store_true');parser.add_argument('--execute',action='store_true');parser.add_argument('--go',action='store_true')
    parser.add_argument('--require',type=Path,action='append',default=[]);args=parser.parse_args();extra=[(p if p.is_absolute() else ROOT/p).resolve() for p in args.require]
    if args.prepare:assert not args.execute and not args.go;result=execute(HERE/'仮保存',False,extra)
    elif args.execute or args.go:assert args.execute and args.go;result=execute(DESTINATION,True,extra)
    else:print(json.dumps({'準備済み':True,'正式保存未実行':True},ensure_ascii=False));return
    print(json.dumps({'成功':True,'正式保存':result['正式保存'],'Source':result['Source']['archive'],'正本':result['正本']['archive']},ensure_ascii=False))


if __name__=='__main__':main()
