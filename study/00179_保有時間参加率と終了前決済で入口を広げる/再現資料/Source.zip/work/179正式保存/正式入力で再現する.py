"""179の純出生576方向と固定10政策を、正式148射影・overlay束縛確認から再現する。"""
from pathlib import Path
from io import BytesIO
import argparse
import gzip
import json
import sys
import zipfile
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work/179保有参加の探索'))
import 探索179 as P
import 基盤179 as M
B=P.B
TRIAL=P.TRIAL


def formal_context(new: bool, early: object) -> tuple:
    """
    機能: 旧73だけ正式148射影へ差し替え、overlay bindingを計算前に確認する。
    引数: new(bool)、early(object)は固定179表読込API。
    返り値: tuple[object,dict]は179 Contextとpreflight指紋。旧cacheを読まない。
    """
    if new:base=B.load_context(True)
    else:
        helper=B.P.module(ROOT/'work/176正式保存/正式入力で再現する.py','formal176_for179')
        base=helper.old_context();assert base.features.sources['formal161']['cache_used'] is False
    loaded=early.load_overlay(base,new,P.OVERLAY_DIR);proof=loaded['files'];del loaded
    original=M.B.load_context
    def factory(requested: bool) -> object:
        """
        機能: 同じ179接続Sourceへ正式射影済みContextだけを渡す。
        引数: requested(bool)は対象期間。
        返り値: objectは束縛確認済みの未置換Context。
        """
        assert requested==new;return base
    try:
        M.B.load_context=factory
        period='追加7' if new else '旧73';context=M.load_context(new,P.OVERLAY_DIR/(period+'_overlay179.npz'))
    finally:M.B.load_context=original
    return context,proof


def main() -> None:
    """
    機能: 純方向全同体と固定旧/追加10pack・全80を元Sourceのまま照合する。
    引数: --archive(Path)は179小正本ZIP、--output(Path)は新規work内。
    返り値: None。全探索を再生することを必須にせず固定結果を優先する。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--archive',type=Path,default=TRIAL/'再現資料/出生と比較正本.zip')
    parser.add_argument('--output',type=Path,required=True);args=parser.parse_args();output=args.output.resolve()
    assert output.is_relative_to(ROOT/'work') and not output.exists();P.verify()
    early=B.P.module(ROOT/'work/179終了前決済/early179.py','early179_formal')
    builder=B.P.module(P.BUILDER,'pure179_formal');fixed_source=B.P.module(ROOT/'work/179保有参加の探索/固定結果を作る.py','fixed179_formal')
    checks=[];preflight={};regenerated={}
    with zipfile.ZipFile(args.archive) as archive:
        assert archive.testzip() is None
        def read(name: str) -> dict:
            """
            機能: 小正本ZIPから元byteのJSONを読む。
            引数: name(str)はmember名。
            返り値: dictはJSON又はgzip JSON。
            """
            body=archive.read(name);return json.loads(gzip.decompress(body) if name.endswith('.gz') else body)
        folder='work/179保有参加の探索/'
        fixed=read(folder+'旧73の固定選択.json');declaration=read(folder+'追加適用前の固定.json')
        chosen=[p for route in P.BASE_IDS for p in fixed['選択'][route]['candidates']]
        policies=declaration['policies'];assert len(chosen)==4 and len(policies)==len({p['id'] for p in policies})==10
        assert policies[:4]==chosen and len([p for p in policies if p['id'].startswith('C')])==6
        for new,period in ((False,'旧73'),(True,'追加7')):
            context,proof=formal_context(new,early);preflight[period]=proof
            pure=builder.build(context.features,np.asarray([s['start'] for s in context.scenes]),context.event_phases)
            born_proof=read(folder+period+'の純出生179.json')
            assert pure['candidate_ids']==born_proof['候補順'] and len(pure['candidate_ids'])==576
            with np.load(BytesIO(archive.read(folder+period+'の純出生179.npz')),allow_pickle=False) as sealed:
                assert set(sealed.files)=={'directions','phases'}
                assert np.array_equal(sealed['directions'],pure['directions']) and np.array_equal(sealed['phases'],pure['phases'])
            P.CTX=context;P.CAPS=B.captures(context)
            P.DIRS={identity+'/'+orientation:pure['directions'][i] if orientation=='NORMAL' else -pure['directions'][i]
                for i,identity in enumerate(pure['candidate_ids']) for orientation in ('NORMAL','REVERSE')}
            P.SEALS={}
            for trial,ids in ((174,['全期_J002','前48_J000']),(177,['全期_J002_J000','前48_J000_J005']),
                (178,['全期_J002_J000_K012','前48_J000_J005_K000'])):
                with np.load(BytesIO(archive.read(f'work/{trial}追加七場適用/{period}の純出生{trial}.npz')),allow_pickle=False) as sealed:
                    assert np.array_equal(sealed['phases'],context.event_phases)
                    for identity in ids:P.SEALS[f'{trial}/{identity}']={k:sealed[identity+'__'+k].copy() for k in ('core','branches','technical','tier','mw','fw','hi')}
            report=read(folder+period+'の固定全取得179.json.gz')
            assert report['成功'] and report['場順']==context.sessions
            assert [r['id'] for r in report['rows']]==[p['id'] for p in policies]
            rows=[]
            for policy,expected in zip(policies,report['rows'],strict=True):
                actual=fixed_source.pack(policy,new);assert actual==expected,(period,policy['id'],'全pack')
                rows.append(actual);checks.append({'期間':period,'id':policy['id'],'取得':len(actual['ledger']['net']),
                    '576純方向同体・全取得・保有区間・engine・金融・期間・集中全pack一致':True})
            regenerated[period]=rows
        expected80=read(folder+'全80の固定結果179.json.gz')
        assert expected80['成功'] and expected80['全場数']==80 and len(expected80['rows'])==10
        actual80=[fixed_source.merge(old,added) for old,added in zip(regenerated['旧73'],regenerated['追加7'],strict=True)]
        assert actual80==expected80['rows']
    P.verify();output.mkdir(parents=True)
    B.P.save(output/'再現確認.json',{'成功':True,'確認':checks,'純方向576の両期間同体':True,'overlay_binding計算前確認':preflight,
        '固定4と旧6対照の全80全行一致':True,'正式148キャッシュ不使用':True,'小正本SHA256':B.P.sha(args.archive),
        '注意':'固定10政策の同体再現。全探索を新たな保存義務にしない。全期既使用、追加期赤字や未達目標を保持。'})
    print(json.dumps({'成功':True,'候補期間':len(checks),'576方向両期間一致':True,'固定10全80全行一致':True},ensure_ascii=False))


if __name__=='__main__':main()
