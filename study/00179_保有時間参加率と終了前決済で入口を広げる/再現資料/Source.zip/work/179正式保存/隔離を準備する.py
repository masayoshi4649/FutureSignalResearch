"""178までのSource連鎖と179差分を復元し、恒久overlayのpreflightから隔離再現する。"""
from pathlib import Path,PurePosixPath
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import venv
import zipfile
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
ISOLATION=ROOT/'work/179隔離再現'
sys.path.insert(0,str(ROOT/'work/176正式保存'))
import 隔離を準備する as P


def restore_source(ref: dict, repository: Path, seen: set) -> None:
    """
    機能: 祖先からSource元byteを指紋確認して一度ずつ復元する。
    引数: ref(dict)、repository(Path)、seen(set)。
    返り値: None。各ZIPと索引の現物SHAを検査する。
    """
    if '親Source継承元' in ref:restore_source(ref['親Source継承元'],repository,seen)
    key=ref['archive']['sha256'];assert key not in seen;seen.add(key)
    source=ROOT/ref['archive']['path'];assert P.digest(source)==key and P.digest(ROOT/ref['index']['path'])==ref['index']['sha256']
    P.restore(source,ref['members'],repository,True)


def restore_new(source: Path, members: list, repository: Path, overrides: list) -> None:
    """
    機能: 179差分を復元し、明示したCSV出力器だけ旧版指紋確認後に更新する。
    引数: source/repository(Path)、members/overrides(list[dict])。
    返り値: None。無宣言の旧Source上書きを拒否する。
    """
    refs={r['path']:r for r in members};allowed={r['path']:r for r in overrides}
    with zipfile.ZipFile(source) as archive:
        assert archive.testzip() is None and set(archive.namelist())==set(refs) and len(archive.namelist())==len(refs)
        for name in archive.namelist():
            path=PurePosixPath(name);assert '\\' not in name and ':' not in name and not path.is_absolute() and '..' not in path.parts
            body=archive.read(name);assert len(body)==refs[name]['bytes'] and hashlib.sha256(body).hexdigest()==refs[name]['sha256']
            target=repository/name
            if target.exists():assert name in allowed and P.digest(target)==allowed[name]['ancestor']['sha256']
            else:assert name not in allowed
            target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(body)


def main() -> None:
    """
    機能: 正式/仮ZIPと共有inputsだけの隔離repoを作り、固定10政策を監査実行する。
    引数: --bundle(Path)は179の索引と二ZIPがあるフォルダ。
    返り値: None。巨大overlayや原板/cacheを複製しない。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--bundle',type=Path,default=HERE/'仮保存');args=parser.parse_args();bundle=args.bundle.resolve()
    index=json.loads((bundle/'保存索引.json').read_text(encoding='utf-8'));assert index['成功'] and not ISOLATION.exists()
    for field,name in (('Source','Source.zip'),('正本','出生と比較正本.zip')):assert P.digest(bundle/name)==index[field]['archive']['sha256']
    repository=ISOLATION/'repo';repository.mkdir(parents=True);seen=set();restore_source(index['Source継承元'],repository,seen)
    restore_new(bundle/'Source.zip',index['Source']['members'],repository,index['Source差分上書き'])
    P.restore(bundle/'出生と比較正本.zip',index['正本']['members'],repository,False)
    artifacts=repository/'artifacts';artifacts.mkdir();shutil.copy2(bundle/'出生と比較正本.zip',artifacts/'出生と比較正本.zip')
    P.junction(repository/'inputs',ROOT/'inputs');P.junction(repository/'study',ROOT/'study')
    environment=ISOLATION/'環境';venv.EnvBuilder(with_pip=False,symlinks=False).create(environment)
    site=Path(np.__file__).resolve().parent.parent;isolated_site=environment/'Lib/site-packages'
    packages=[p for p in site.iterdir() if p.name in ('numpy','numpy.libs','tzdata') or p.name.startswith(('numpy-','tzdata-')) and p.name.endswith('.dist-info')]
    assert any(p.name=='numpy' for p in packages) and any(p.name=='tzdata' for p in packages)
    for package in packages:shutil.copytree(package,isolated_site/package.name)
    audit=ISOLATION/'監査実行.py';shutil.copy2(HERE/'監査実行.py',audit)
    (ISOLATION/'準備.json').write_text(json.dumps({'成功':True,'祖先Source数':len(seen),'179SourceSHA256':P.digest(bundle/'Source.zip'),
        '小正本SHA256':P.digest(bundle/'出生と比較正本.zip'),'CSV差分':index['Source差分上書き'],
        '環境':'Python'+sys.version+'・NumPy'+np.__version__+'・tzdata','overlay':'共有inputs179、Source/binding/SHAを計算前確認'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    env=os.environ.copy();env.pop('PYTHONPATH',None);env.update({'PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8','PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'})
    subprocess.run([str(environment/'Scripts/python.exe'),str(audit)],cwd=repository,env=env,check=True)


if __name__=='__main__':main()
