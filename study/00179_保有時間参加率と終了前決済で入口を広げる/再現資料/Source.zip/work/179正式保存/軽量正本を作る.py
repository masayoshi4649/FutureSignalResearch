"""179全段の大きい重複診断を省き、元行ハッシュと選択必要数値を別正本へ保存する。"""
from pathlib import Path
import copy
import gzip
import hashlib
import json
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'work/179保有参加の探索'))
import 探索179 as P
NAMES=('単帯の追加置換','二局面の追加置換','三帯の保有参加比較')


def canonical_sha(value: object) -> str:
    """
    機能: gzip時刻やJSONのキー順に依存しない元行全数値の指紋を求める。
    引数: value(object)は標準JSON値。
    返り値: strはcanonical JSONのSHA256。
    """
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf-8')).hexdigest()


def group(source: dict) -> dict:
    """
    機能: 順位・参加・両中央値・正決済/先着の検算に必要な金融数値だけを残す。
    引数: source(dict)はmetrics173の一群。
    返り値: dict。原行/建玉全件や重複する集中診断は固定packから読む。
    """
    sessions={k:copy.deepcopy(v) for k,v in source['sessions'].items() if k!='rows'}
    sessions['rows']=[{k:r[k] for k in ('scene','all_count','unknown_count','known_net')} for r in source['sessions']['rows']]
    return {'trades':copy.deepcopy(source['trades']),'sessions':sessions,'decision':copy.deepcopy(source['decision']),
        'eligible_hours':source['eligible_hours'],'acquisitions_per_hour':source['acquisitions_per_hour']}


def thin(row: dict) -> dict:
    """
    機能: immutableな元行のハッシュと、元ranking/shortlistが使う数値を保存する。
    引数: row(dict)は元全段正本の一行。
    返り値: dictは政策/件数/期間金融/保有比率/順位キー。
    """
    result={k:copy.deepcopy(v) for k,v in row.items() if k!='periods'};result['periods']={}
    for period,record in row['periods'].items():
        financial=record['financial']
        trimmed={'required_decision':copy.deepcopy(financial['required_decision']),
            'phases_diagnostic':{k:group(v) for k,v in financial['phases_diagnostic'].items()},
            'session_groups_required':{k:group(v) for k,v in financial['session_groups_required'].items()}}
        holding={'groups':{name:{k:copy.deepcopy(v) for k,v in data.items() if not isinstance(v,(dict,list))}
            for name,data in record['holding']['groups'].items()}}
        result['periods'][period]={'financial':trimmed,'holding':holding}
    route=row['policy']['route'];keys={}
    for bands in (('DAY',),('PRE',),('POST',),('DAY','NIGHT')):
        wanted=P.ranking(row,route,bands);assert P.ranking(result,route,bands)==wanted
        keys['+'.join(bands)]=list(wanted)
    result['original_row_sha256']=canonical_sha(row);result['selection_rank_keys']=keys
    return result


def build() -> list:
    """
    機能: 三段の元SHA・全政策・選択数値・行ハッシュを軽量別正本へ生成する。
    引数: なし。
    返り値: list[dict]は元と軽量保存先の指紋、順位/短表検算結果。
    """
    destination=HERE/'軽量正本';destination.mkdir(exist_ok=True);proof=[]
    for name in NAMES:
        source=P.HERE/(name+'.json.gz');target=destination/(name+'.json.gz');source_ref=P.ref(source)
        if target.exists():
            previous=P.B.P.read(target);assert previous['元正本']==source_ref and previous['成功']
            proof.append({'元':source_ref,'軽量':P.ref(target),'rows':len(previous['rows']),'順位短表同体':True});continue
        body=P.B.P.read(source);assert body['成功'];original=body['rows'];rows=[thin(row) for row in original]
        checks=0
        for route in P.BASE_IDS:
            for band in P.BANDS:
                a=[r for r in original if r['policy']['route']==route and band in r['policy'].get('changes',{})]
                b=[r for r in rows if r['policy']['route']==route and band in r['policy'].get('changes',{})]
                for maximum in (6,8):
                    assert [r['id'] for r in P.shortlist(a,route,band,maximum)]==[r['id'] for r in P.shortlist(b,route,band,maximum)];checks+=1
            a=sorted([r for r in original if r['policy']['route']==route],key=lambda r:P.ranking(r,route,('DAY','NIGHT')))
            b=sorted([r for r in rows if r['policy']['route']==route],key=lambda r:P.ranking(r,route,('DAY','NIGHT')))
            assert [r['id'] for r in a]==[r['id'] for r in b];checks+=1
        result={'成功':True,'形式':'179選択必要数値と全行指紋1','元正本':source_ref,'rows':rows,
            '選択検算':{'全行全視点順位キー一致':True,'shortlistと全順位比較':checks},
            '再実行':'元Source/F0/正式入力から同じ政策群を全再生し、canonical_sha(row)をoriginal_row_sha256へ照合できる。',
            '省略':'候補ごとに重複する全保有区間・全経路/集中診断を除く。固定10政策は別に全packを恒久保存。元workファイルは削除/改変しない。'}
        raw=(json.dumps(result,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode('utf-8')
        target.write_bytes(gzip.compress(raw,mtime=0));assert P.B.P.read(target)==result
        proof.append({'元':source_ref,'軽量':P.ref(target),'rows':len(rows),'順位短表同体':True})
    return proof


def main() -> None:
    """
    機能: Root承認済みの別軽量正本だけを生成する。
    引数: なし。
    返り値: None。元数量正本・入口条件・金融・既存ZIPを変更しない。
    """
    P.verify();print(json.dumps({'成功':True,'軽量正本':build()},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
