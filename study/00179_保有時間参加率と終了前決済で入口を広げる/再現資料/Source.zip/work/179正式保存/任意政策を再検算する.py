"""必要時だけ一つの段階政策を正式入力から再生し、軽量正本の元行SHAへ照合する。"""
from pathlib import Path
from io import BytesIO
import argparse
import gzip
import json
import numpy as np
import 正式入力で再現する as R
import 軽量正本を作る as L


def main() -> None:
    """
    機能: 全探索を必須にせず、指定政策の全数値を元Source/F0/正式入力から再生成する。
    引数: --archive(Path)、--stage(str)、--id(str|None)は省略時その段階の先頭政策。
    返り値: None。元段階gzやfeature cacheを参照せず、元行canonical SHAの一致だけを報告する。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--archive',type=Path,default=R.TRIAL/'再現資料/出生と比較正本.zip')
    parser.add_argument('--stage',choices=L.NAMES,required=True);parser.add_argument('--id');args=parser.parse_args();P=R.P;B=R.B;P.verify()
    early=B.P.module(R.ROOT/'work/179終了前決済/early179.py','early179_one_policy')
    context,_=R.formal_context(False,early);builder=B.P.module(P.BUILDER,'pure179_one_policy')
    pure=builder.build(context.features,np.asarray([s['start'] for s in context.scenes]),context.event_phases)
    with __import__('zipfile').ZipFile(args.archive) as archive:
        light=json.loads(gzip.decompress(archive.read('work/179正式保存/軽量正本/'+args.stage+'.json.gz')))
        row=light['rows'][0] if args.id is None else next(r for r in light['rows'] if r['id']==args.id)
        with np.load(BytesIO(archive.read('work/179保有参加の探索/旧73の純出生179.npz')),allow_pickle=False) as sealed:
            assert np.array_equal(pure['directions'],sealed['directions']) and np.array_equal(pure['phases'],sealed['phases'])
        P.CTX=context;P.CAPS=B.captures(context)
        P.DIRS={identity+'/'+o:pure['directions'][i] if o=='NORMAL' else -pure['directions'][i]
            for i,identity in enumerate(pure['candidate_ids']) for o in ('NORMAL','REVERSE')};P.SEALS={}
        for trial,ids in ((174,['全期_J002','前48_J000']),(177,['全期_J002_J000','前48_J000_J005']),
            (178,['全期_J002_J000_K012','前48_J000_J005_K000'])):
            with np.load(BytesIO(archive.read(f'work/{trial}追加七場適用/旧73の純出生{trial}.npz')),allow_pickle=False) as sealed:
                for identity in ids:P.SEALS[f'{trial}/{identity}']={k:sealed[identity+'__'+k].copy() for k in ('core','branches','technical','tier','mw','fw','hi')}
        actual=P.evaluate(row['policy']);digest=L.canonical_sha(actual);assert digest==row['original_row_sha256'],row['id']
    print(json.dumps({'成功':True,'id':row['id'],'元行全数値canonicalSHA256':digest,'正式148キャッシュ不使用':True},ensure_ascii=False))


if __name__=='__main__':main()
