package gatesnapshots159

import (
	"bytes"
	"compress/gzip"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"sort"
	"testing"

	features "features158"
)

// artificialCase は共通87の所属重複に対応する一物理caseを人工で作ります。
//
// 引数: なし。返り値: SourceScene。
func artificialCase() SourceScene {
	c := SourceCase{ID: "同じ物理case", OriginalSide: 1, Side: 1, Stream: "original", Entry: Quote{Time: 10, Index: 1, SourceLine: 2, Last: 1002, Bid: 1000, Ask: 1005, QuoteOK: true}, EntryPrice: 1005, Memberships: json.RawMessage(`[{"policy":"153U15","未知の旧field":123},{"policy":"152U0","未知の旧field":456}]`)}
	for _, h := range []string{"H60", "SESSION"} {
		for _, d := range []string{"D0", "D1"} {
			for _, cost := range []string{"C0", "C5"} {
				q := Quote{Time: 50, Index: 5, SourceLine: 6, Last: 1132, Bid: 1130, Ask: 1135, QuoteOK: true}
				c.Results = append(c.Results, BaselineResult{Policy: "F125S125", Horizon: h, Delay: d, Cost: cost, Trigger: &Trigger{Reason: "take_profit", Time: 50, Quote: &q}})
			}
		}
	}
	return SourceScene{Session: "人工場", Contract: "人工限月", Start: 0, End: 800, ForceClose: 200, ContinuousEnd: 500, Cases: []SourceCase{c}}
}

// Test最初TPの全DCと所属 はC0の全D/c一致と所属二重計上禁止を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func Test最初TPの全DCと所属(t *testing.T) {
	scene := artificialCase()
	rows, e := Queries(scene, 0)
	if e != nil {
		t.Fatal(e)
	}
	if len(rows) != 2 || rows[0].CaseID != rows[1].CaseID || !reflect.DeepEqual(rows[0].Gate, rows[1].Gate) || !bytes.Equal(rows[0].Memberships, scene.Cases[0].Memberships) {
		t.Fatal("物理1×2horizon/所属保存差")
	}
	scene.Cases[0].Results[1].Trigger.Quote.Index++
	if _, e = Queries(scene, 0); e == nil {
		t.Fatal("D/c差を許容")
	}
	scene = artificialCase()
	scene.Cases[0].Results = append(scene.Cases[0].Results, scene.Cases[0].Results[0])
	if _, e = Queries(scene, 0); e == nil {
		t.Fatal("C0構成重複")
	}
	scene = artificialCase()
	scene.Cases = append(scene.Cases, scene.Cases[0])
	if _, e = Queries(scene, 0); e == nil {
		t.Fatal("物理case二重")
	}
}

// Test非TPと売側 は非TP台帳の維持と売の実Ask清算を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func Test非TPと売側(t *testing.T) {
	scene := artificialCase()
	for i := range scene.Cases[0].Results {
		scene.Cases[0].Results[i].Trigger.Reason = "stop"
	}
	rows, e := Queries(scene, 0)
	if e != nil {
		t.Fatal(e)
	}
	if len(rows) != 2 || rows[0].Gate != nil || rows[0].Values != nil || len(QueryOrder(rows)) != 0 {
		t.Fatal("非TPを条件出生へ")
	}
	scene = artificialCase()
	c := &scene.Cases[0]
	c.Side = -1
	c.OriginalSide = -1
	c.Entry = reflectQuote(c.Entry)
	c.EntryPrice = 2000 - c.EntryPrice
	for i := range c.Results {
		q := reflectQuote(*c.Results[i].Trigger.Quote)
		c.Results[i].Trigger.Quote = &q
	}
	rows, e = Queries(scene, 0)
	if e != nil {
		t.Fatal(e)
	}
	if rows[0].Side != -1 || rows[0].EntryPrice != 995 {
		t.Fatal("売側転記差")
	}
}

// reflectQuote は人工の価格反射を行います。
//
// 引数: q(Quote)。返り値: Quote。
func reflectQuote(q Quote) Quote {
	q.Last, q.Bid, q.Ask = 2000-q.Last, 2000-q.Ask, 2000-q.Bid
	return q
}

// fixtureContext は全149名を持つ最小公表済み特徴を作ります。
//
// 引数: at(Stamp)、value/until(float64)。返り値: features.Context/[]string。
func fixtureContext(at Stamp, value, until float64) (features.Context, []string) {
	keys := []string{"m1.close"}
	for i := 0; i < 148; i++ {
		keys = append(keys, fmt.Sprintf("追加%03d", i))
	}
	sort.Strings(keys)
	r := FeatureRef{ID: fmt.Sprintf("足/%d", at.Index), Session: "人工場", Contract: "人工限月", WidthSeconds: 60, Start: 0, End: 0, AvailableAt: 0, Stamp: at, Source: "人工"}
	c := features.Context{Session: "人工場", Contract: "人工限月", At: at, UpdatedAt: at, EventID: r.ID, Values: map[string]features.FeatureValue{}, Refs: []FeatureRef{r}, Updates: []features.FeatureUpdate{}}
	for _, key := range keys {
		c.Values[key] = features.FeatureValue{RefIDs: []string{r.ID}}
	}
	x, y := value, until
	c.Values["m1.close"] = features.FeatureValue{Known: true, Value: &x, ValidUntil: &y, RefIDs: []string{r.ID}}
	return c, keys
}

// TestTTLと凍結と未来 は照会時の失効・map凍結・同秒未来index拒否を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestTTLと凍結と未来(t *testing.T) {
	rows, _ := Queries(artificialCase(), 0)
	c, keys := fixtureContext(Stamp{Time: 20, Index: 2, SourceLine: 3}, 123, 50)
	if e := Attach(&rows[0], c, keys); e != nil {
		t.Fatal(e)
	}
	if rows[0].Known["m1.close"] || rows[0].Values["m1.close"] != nil {
		t.Fatal("TTL等号延命")
	}
	c, keys = fixtureContext(Stamp{Time: 20, Index: 2, SourceLine: 3}, 123, 100)
	if e := Attach(&rows[0], c, keys); e != nil {
		t.Fatal(e)
	}
	v := c.Values["m1.close"]
	*v.Value = 999
	if *rows[0].Values["m1.close"] != 123 {
		t.Fatal("未来変化でsnapshot改変")
	}
	c.At = Stamp{Time: 50, Index: 6, SourceLine: 7}
	if e := Attach(&rows[1], c, keys); e == nil {
		t.Fatal("同秒未来index")
	}
}

// fixtureFeatureFile は人工Contextだけをgzipへ保存してmanifest一場参照を作ります。
//
// 引数: t(*testing.T)、contexts([]features.Context)。返り値: directory(string)/features.SceneFeatures。
func fixtureFeatureFile(t *testing.T, contexts []features.Context) (string, features.SceneFeatures) {
	t.Helper()
	directory := t.TempDir()
	var raw bytes.Buffer
	encoder := json.NewEncoder(&raw)
	for _, c := range contexts {
		if e := encoder.Encode(c); e != nil {
			t.Fatal(e)
		}
	}
	var compressed bytes.Buffer
	z := gzip.NewWriter(&compressed)
	_, _ = z.Write(raw.Bytes())
	if e := z.Close(); e != nil {
		t.Fatal(e)
	}
	name := "000.jsonl.gz"
	if e := os.WriteFile(filepath.Join(directory, name), compressed.Bytes(), 0644); e != nil {
		t.Fatal(e)
	}
	return directory, features.SceneFeatures{Session: "人工場", Contract: "人工限月", Start: 0, End: 800, ForceClose: 200, ContinuousEnd: 500, Path: name, Bytes: int64(compressed.Len()), SHA256: hashBytes(compressed.Bytes()), DecodedBytes: int64(raw.Len()), DecodedSHA256: hashBytes(raw.Bytes()), Rows: len(contexts)}
}

// TestStreamの未来票非依存 はfuture先読とgate無し場の完読を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestStreamの未来票非依存(t *testing.T) {
	first, keys := fixtureContext(Stamp{Time: 20, Index: 2, SourceLine: 3}, 123, 100)
	future, _ := fixtureContext(Stamp{Time: 60, Index: 6, SourceLine: 7}, 999, 180)
	dir, ref := fixtureFeatureFile(t, []features.Context{first, future})
	rows, _ := Queries(artificialCase(), 0)
	scene := SnapshotScene{Session: ref.Session, Contract: ref.Contract, Start: ref.Start, End: ref.End, ForceClose: ref.ForceClose, ContinuousEnd: ref.ContinuousEnd, Rows: rows}
	e, e1 := BindScene(&scene, ref, dir, keys)
	if e1 != nil {
		t.Fatal(e1)
	}
	if !e.Success || e.Rows != 2 || *scene.Rows[0].Values["m1.close"] != 123 || *scene.Rows[1].Values["m1.close"] != 123 {
		t.Fatal("未来票を混入")
	}
	future.Values["m1.close"] = features.FeatureValue{}
	dir2, ref2 := fixtureFeatureFile(t, []features.Context{first, future})
	rows, _ = Queries(artificialCase(), 0)
	scene2 := scene
	scene2.Rows = rows
	if _, err := BindScene(&scene2, ref2, dir2, keys); err != nil {
		t.Fatal(err)
	}
	a, _ := json.Marshal(scene.Rows)
	b, _ := json.Marshal(scene2.Rows)
	if !bytes.Equal(a, b) {
		t.Fatal("future特徴差替えで当時票が変化")
	}
	scene.Rows = []Snapshot{}
	e, e1 = BindScene(&scene, ref, dir, keys)
	if e1 != nil || !e.Success || e.Rows != 2 {
		t.Fatal("gateゼロ場の未完読")
	}
}

// TestStream終端失敗 は既query結合後もCRC/SHAの末尾失敗を成功へ変えません。
//
// 引数: t(*testing.T)。返り値: なし。
func TestStream終端失敗(t *testing.T) {
	c, keys := fixtureContext(Stamp{Time: 20, Index: 2, SourceLine: 3}, 123, 100)
	dir, ref := fixtureFeatureFile(t, []features.Context{c})
	rows, _ := Queries(artificialCase(), 0)
	scene := SnapshotScene{Session: ref.Session, Contract: ref.Contract, Start: ref.Start, End: ref.End, ForceClose: ref.ForceClose, ContinuousEnd: ref.ContinuousEnd, Rows: rows}
	body, e := os.ReadFile(filepath.Join(dir, ref.Path))
	if e != nil {
		t.Fatal(e)
	}
	body[len(body)-5] ^= 1
	if e = os.WriteFile(filepath.Join(dir, ref.Path), body, 0644); e != nil {
		t.Fatal(e)
	}
	ref.SHA256 = hashBytes(body)
	if evidence, err := BindScene(&scene, ref, dir, keys); err == nil || evidence.Success {
		t.Fatal("末尾CRC不正で成功")
	}
}

// Test全体接続と親SHA は人工の結果/特徴/条件だけから2horizon票を完成させます。
//
// 引数: t(*testing.T)。返り値: なし。
func Test全体接続と親SHA(t *testing.T) {
	c, keys := fixtureContext(Stamp{Time: 20, Index: 2, SourceLine: 3}, 123, 100)
	dir, ref := fixtureFeatureFile(t, []features.Context{c})
	manifest := features.FeatureManifest{Success: true, Trial: 158, Schema: "technical_features158_v1", Catalog: keys, Scenes: []features.SceneFeatures{ref}, SceneCount: 1}
	mb, _ := json.Marshal(manifest)
	mp := filepath.Join(dir, "特徴の確認.json")
	if e := os.WriteFile(mp, mb, 0644); e != nil {
		t.Fatal(e)
	}
	parent := struct {
		Success         bool          `json:"success"`
		Trial           int           `json:"trial"`
		CaseCount       int           `json:"case_count"`
		MembershipCount int           `json:"membership_count"`
		Scenes          []SourceScene `json:"scenes"`
	}{true, 158, 1, 2, []SourceScene{artificialCase()}}
	pb, _ := json.Marshal(parent)
	var compressed bytes.Buffer
	z := gzip.NewWriter(&compressed)
	_, _ = z.Write(pb)
	_ = z.Close()
	pp := filepath.Join(dir, "結果.json.gz")
	if e := os.WriteFile(pp, compressed.Bytes(), 0644); e != nil {
		t.Fatal(e)
	}
	sp := filepath.Join(dir, "条件.md")
	sb := []byte("人工条件")
	if e := os.WriteFile(sp, sb, 0644); e != nil {
		t.Fatal(e)
	}
	opts := ExtractOptions{Results: features.ParentRef{Path: pp, Bytes: int64(compressed.Len()), SHA256: hashBytes(compressed.Bytes()), DecodedSHA256: hashBytes(pb)}, ManifestPath: mp, ManifestSHA: hashBytes(mb), SpecificationPath: sp, SpecificationSHA: hashBytes(sb)}
	out, e := Extract(opts)
	if e != nil {
		t.Fatal(e)
	}
	if !out.Success || out.CaseCount != 1 || out.MembershipCount != 2 || out.Rows != 2 || out.GateRows != 2 || out.LabelsUsed || out.NewSelectionUsed || out.RawRead {
		t.Fatal("全体接続/物理分母差")
	}
	if *out.Scenes[0].Rows[0].Values["m1.close"] != 123 {
		t.Fatal("当時値差")
	}
	opts.Results.DecodedSHA256 = hashBytes([]byte("不一致"))
	failed, e := Extract(opts)
	if e == nil || failed.Success {
		t.Fatal("親SHA末尾不一致で成功")
	}
}
