package main

import (
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"

	features "features158"
	gate "gatesnapshots159"
)

type counter struct {
	writer io.Writer
	count  int64
}

// Write は保存JSON解凍bytes数を数えます。
//
// 引数: body([]byte)。返り値: int/error。
func (c *counter) Write(body []byte) (int, error) {
	n, e := c.writer.Write(body)
	c.count += int64(n)
	return n, e
}

// main は固定通知後だけgate時点の特徴を一度抽出して排他gzip保存します。
//
// 引数: CLIフラグ。返り値: なし。全入力検査成功前に出力を作りません。
func main() {
	result := flag.String("results", "", "正式158出口結果gzip")
	physical := flag.String("results-sha", "", "158出口結果物理SHA")
	decoded := flag.String("results-decoded-sha", "", "158出口結果解凍SHA")
	bytes := flag.Int64("results-bytes", 0, "158出口結果物理bytes")
	manifest := flag.String("features", "", "158特徴manifest")
	manifestSHA := flag.String("features-sha", "a6dce32eb35102d95f44647d0a10811bf13ed6e36f46b08ef0956c52bb783d11", "158特徴manifestSHA")
	spec := flag.String("spec", "", "正式159実行条件")
	specSHA := flag.String("spec-sha", "", "159実行条件SHA")
	output := flag.String("output", "", "未作成のsnapshot.json.gz")
	allow := flag.Bool("allow-natural", false, "Root自然抽出通知後の実行を明示")
	flag.Parse()
	if !*allow || *result == "" || len(*physical) != 64 || len(*decoded) != 64 || *bytes <= 0 || *manifest == "" || *spec == "" || len(*specSHA) != 64 || *output == "" {
		fmt.Fprintln(os.Stderr, "自然実行未許可又は固定参照不足")
		os.Exit(1)
	}
	if _, e := os.Stat(*output); !os.IsNotExist(e) {
		fmt.Fprintln(os.Stderr, "出力は未作成を指定")
		os.Exit(1)
	}
	o, e := gate.Extract(gate.ExtractOptions{Results: features.ParentRef{Path: *result, Bytes: *bytes, SHA256: *physical, DecodedSHA256: *decoded}, ManifestPath: *manifest, ManifestSHA: *manifestSHA, SpecificationPath: *spec, SpecificationSHA: *specSHA, All73: true})
	if e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
	if e = os.MkdirAll(filepath.Dir(*output), 0755); e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
	f, e := os.OpenFile(*output, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0644)
	if e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
	ph, dh := sha256.New(), sha256.New()
	z := gzip.NewWriter(io.MultiWriter(f, ph))
	counter := &counter{writer: io.MultiWriter(z, dh)}
	e = json.NewEncoder(counter).Encode(o)
	if e == nil {
		e = z.Close()
	}
	if e == nil {
		e = f.Close()
	}
	if e != nil {
		f.Close()
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
	info, e := os.Stat(*output)
	if e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
	completion := map[string]any{"success": true, "trial": 159, "schema": o.Schema, "output": *output, "sha256": hex.EncodeToString(ph.Sum(nil)), "decoded_sha256": hex.EncodeToString(dh.Sum(nil)), "bytes": info.Size(), "decoded_bytes": counter.count, "scene_count": o.SceneCount, "case_count": o.CaseCount, "membership_count": o.MembershipCount, "rows": o.Rows, "gate_rows": o.GateRows, "labels_used": false, "new_selection_used": false, "raw_read": false}
	body, e := json.MarshalIndent(completion, "", "  ")
	if e == nil {
		e = os.WriteFile(*output+".完了.json", append(body, '\n'), 0644)
	}
	if e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
	fmt.Printf("gate特徴完了 %d場 %d物理case %d票 TP125=%d\n", o.SceneCount, o.CaseCount, o.Rows, o.GateRows)
}
