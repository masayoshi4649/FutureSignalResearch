package gatesnapshots159

import (
	"bufio"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"reflect"
	"strings"

	features "features158"
)

type ReadEvidence struct {
	Success       bool             `json:"success"`
	Path          string           `json:"path"`
	SHA256        string           `json:"sha256"`
	DecodedSHA256 string           `json:"decoded_sha256"`
	Bytes         int64            `json:"bytes"`
	DecodedBytes  int64            `json:"decoded_bytes"`
	Rows          int              `json:"rows"`
	StatBefore    map[string]int64 `json:"stat_before"`
	StatAfter     map[string]int64 `json:"stat_after"`
}

type counter struct {
	reader io.Reader
	count  int64
}

// Read は解凍bytesを計数します。
//
// 引数: p([]byte)。返り値: int/error。
func (c *counter) Read(p []byte) (int, error) {
	n, e := c.reader.Read(p)
	c.count += int64(n)
	return n, e
}

// stat は価格を含まないサイズと変更時刻を返します。
//
// 引数: f(os.FileInfo)。返り値: map[string]int64。
func stat(f os.FileInfo) map[string]int64 {
	return map[string]int64{"bytes": f.Size(), "mtime_ns": f.ModTime().UnixNano()}
}

// hashBytes は固定小入力の指紋を作ります。
//
// 引数: body([]byte)。返り値: string。
func hashBytes(body []byte) string { h := sha256.Sum256(body); return hex.EncodeToString(h[:]) }

// checkedBytes は小参照を全SHA/stat確認後にだけ返します。
//
// 引数: path/expected(string)。返り値: []byte/error。
func checkedBytes(path, expected string) ([]byte, error) {
	old, e := os.Stat(path)
	if e != nil {
		return nil, e
	}
	body, e := os.ReadFile(path)
	if e != nil {
		return nil, e
	}
	now, e := os.Stat(path)
	if e != nil {
		return nil, e
	}
	if len(expected) != 64 || hashBytes(body) != expected || !os.SameFile(old, now) || !reflect.DeepEqual(stat(old), stat(now)) {
		return nil, fmt.Errorf("小入力SHA/stat差")
	}
	return body, nil
}

// validateContext は保存eventの全149列と全参照の因果を検査します。
//
// 引数: c(features.Context)、scene(features.SceneFeatures)、catalog([]string)。返り値: error。
func validateContext(c features.Context, scene features.SceneFeatures, catalog []string) error {
	if c.Session != scene.Session || c.Contract != scene.Contract || !finite(c.At.Time) || c.At.Time < scene.Start || c.At.Time >= scene.ContinuousEnd || c.At.Index < 0 || c.At.SourceLine < 1 || len(c.Values) != len(catalog) || !before(c.UpdatedAt, c.At) {
		return fmt.Errorf("特徴票scope/件数/時計差")
	}
	refs := map[string]bool{}
	for _, r := range c.Refs {
		if r.ID == "" || refs[r.ID] || r.Session != scene.Session || r.Contract != scene.Contract || r.End > r.AvailableAt || r.AvailableAt > r.Stamp.Time || !before(r.Stamp, c.At) {
			return fmt.Errorf("特徴refscope/因果差")
		}
		refs[r.ID] = true
	}
	for _, key := range catalog {
		v, ok := c.Values[key]
		if !ok || v.Known != (v.Value != nil) || v.Value != nil && !finite(*v.Value) || v.ValidUntil != nil && !finite(*v.ValidUntil) || v.Known && v.ValidUntil != nil && c.At.Time >= *v.ValidUntil {
			return fmt.Errorf("特徴key/known/有限/期限差")
		}
		for _, id := range v.RefIDs {
			if !refs[id] {
				return fmt.Errorf("特徴ref ID未結合")
			}
		}
	}
	return nil
}

// BindScene はqueryを物理順に処理し未消費future値をsnapshotへ渡しません。
//
// 引数: scene(*SnapshotScene)、reference(features.SceneFeatures)、directory(string)、catalog([]string)。
// 返り値: ReadEvidence/error。gateゼロ場も全gzipを完読してCRC/SHA/statを確定します。
func BindScene(scene *SnapshotScene, reference features.SceneFeatures, directory string, catalog []string) (ReadEvidence, error) {
	evidence := ReadEvidence{Path: reference.Path}
	if scene.Session != reference.Session || scene.Contract != reference.Contract || scene.Start != reference.Start || scene.End != reference.End || scene.ForceClose != reference.ForceClose || scene.ContinuousEnd != reference.ContinuousEnd {
		return evidence, fmt.Errorf("特徴/照会場scope差")
	}
	clean := filepath.Clean(reference.Path)
	if filepath.IsAbs(clean) || filepath.VolumeName(clean) != "" || clean == ".." || strings.HasPrefix(clean, ".."+string(filepath.Separator)) {
		return evidence, fmt.Errorf("特徴path外参照")
	}
	path := filepath.Join(directory, clean)
	file, e := os.Open(path)
	if e != nil {
		return evidence, e
	}
	defer file.Close()
	old, e := file.Stat()
	if e != nil {
		return evidence, e
	}
	evidence.StatBefore = stat(old)
	if old.Size() != reference.Bytes {
		return evidence, fmt.Errorf("特徴gzipサイズ差")
	}
	ph, dh := sha256.New(), sha256.New()
	buffer := bufio.NewReader(io.TeeReader(file, ph))
	gz, e := gzip.NewReader(buffer)
	if e != nil {
		return evidence, e
	}
	defer gz.Close()
	count := &counter{reader: io.TeeReader(gz, dh)}
	decoder := json.NewDecoder(count)
	order := QueryOrder(scene.Rows)
	position := 0
	current := features.Context{}
	var last *Stamp
	for {
		var next features.Context
		e = decoder.Decode(&next)
		if e == io.EOF {
			break
		}
		if e != nil {
			return evidence, e
		}
		if e = validateContext(next, reference, catalog); e != nil {
			return evidence, e
		}
		if last != nil && (!before(*last, next.At) || last.Index >= next.At.Index || last.SourceLine >= next.At.SourceLine) {
			return evidence, fmt.Errorf("特徴event順序差")
		}
		x := next.At
		last = &x
		evidence.Rows++
		// ----------------------------------------
		// 次eventがqueryより未来なら、直前Contextで先に全同原行queryを凍結します。
		for position < len(order) && !before(next.At, stamp(*scene.Rows[order[position]].Gate)) {
			row := &scene.Rows[order[position]]
			q := stamp(*row.Gate)
			if next.At.Time < q.Time || next.At.Index < q.Index || next.At.SourceLine < q.SourceLine {
				return evidence, fmt.Errorf("特徴/照会3時計交差")
			}
			if e = Attach(row, current, catalog); e != nil {
				return evidence, e
			}
			position++
		}
		current = next
	}
	for position < len(order) {
		if e = Attach(&scene.Rows[order[position]], current, catalog); e != nil {
			return evidence, e
		}
		position++
	}
	if _, e = io.Copy(io.Discard, gz); e != nil {
		return evidence, e
	}
	if _, e = io.Copy(io.Discard, buffer); e != nil {
		return evidence, e
	}
	now, e := file.Stat()
	if e != nil {
		return evidence, e
	}
	pathNow, e := os.Stat(path)
	if e != nil {
		return evidence, e
	}
	evidence.StatAfter = stat(now)
	evidence.SHA256 = hex.EncodeToString(ph.Sum(nil))
	evidence.DecodedSHA256 = hex.EncodeToString(dh.Sum(nil))
	evidence.Bytes = now.Size()
	evidence.DecodedBytes = count.count
	if !os.SameFile(old, pathNow) || !reflect.DeepEqual(stat(old), stat(now)) || !reflect.DeepEqual(stat(old), stat(pathNow)) || evidence.SHA256 != reference.SHA256 || evidence.DecodedSHA256 != reference.DecodedSHA256 || evidence.DecodedBytes != reference.DecodedBytes || evidence.Rows != reference.Rows {
		return evidence, fmt.Errorf("特徴gzipCRC/SHA/rows/stat差")
	}
	evidence.Success = true
	return evidence, nil
}

type ExtractOptions struct {
	Results           features.ParentRef
	ManifestPath      string
	ManifestSHA       string
	SpecificationPath string
	SpecificationSHA  string
	All73             bool
}

type Output struct {
	Success          bool            `json:"success"`
	Trial            int             `json:"trial"`
	Schema           string          `json:"schema"`
	Catalog          []string        `json:"catalog"`
	InputRefs        map[string]any  `json:"input_refs"`
	Scenes           []SnapshotScene `json:"scenes"`
	SceneCount       int             `json:"scene_count"`
	CaseCount        int             `json:"case_count"`
	MembershipCount  int             `json:"membership_count"`
	Rows             int             `json:"rows"`
	GateRows         int             `json:"gate_rows"`
	LabelsUsed       bool            `json:"labels_used"`
	NewSelectionUsed bool            `json:"new_selection_used"`
	RawRead          bool            `json:"raw_read"`
}

// Extract は全C0原行を照会し特徴全73gzip完読後だけ成功を返します。
//
// 引数: options(ExtractOptions)。返り値: Output/error。自然実行はRoot通知後だけ行います。
func Extract(options ExtractOptions) (Output, error) {
	out := Output{Trial: 159, Schema: "gate_snapshots159_v1", Scenes: []SnapshotScene{}, InputRefs: map[string]any{}}
	manifestBody, e := checkedBytes(options.ManifestPath, options.ManifestSHA)
	if e != nil {
		return out, e
	}
	var manifest features.FeatureManifest
	if e = json.Unmarshal(manifestBody, &manifest); e != nil {
		return out, e
	}
	if !manifest.Success || manifest.Trial != 158 || manifest.Schema != "technical_features158_v1" || len(manifest.Catalog) != 149 || options.All73 && len(manifest.Scenes) != 73 {
		return out, fmt.Errorf("158特徴manifest成功/件数差")
	}
	seenKeys := map[string]bool{}
	for _, k := range manifest.Catalog {
		if k == "" || seenKeys[k] {
			return out, fmt.Errorf("catalog重複/空")
		}
		seenKeys[k] = true
	}
	out.Catalog = append([]string{}, manifest.Catalog...)
	if _, e = checkedBytes(options.SpecificationPath, options.SpecificationSHA); e != nil {
		return out, e
	}
	index := 0
	seenCases := map[string]bool{}
	parent, e := features.ReadParent(options.Results, func(body json.RawMessage) error {
		if index >= len(manifest.Scenes) {
			return fmt.Errorf("結果場過剰")
		}
		var source SourceScene
		if e := json.Unmarshal(body, &source); e != nil {
			return e
		}
		rows, e := Queries(source, index)
		if e != nil {
			return e
		}
		for _, c := range source.Cases {
			if seenCases[c.ID] {
				return fmt.Errorf("物理case再計上")
			}
			seenCases[c.ID] = true
			var members []json.RawMessage
			if e = json.Unmarshal(c.Memberships, &members); e != nil {
				return e
			}
			out.MembershipCount += len(members)
		}
		scene := SnapshotScene{Session: source.Session, Contract: source.Contract, SessionIndex: index, Start: source.Start, End: source.End, ForceClose: source.ForceClose, ContinuousEnd: source.ContinuousEnd, Rows: rows}
		scene.FeatureRead, e = BindScene(&scene, manifest.Scenes[index], filepath.Dir(options.ManifestPath), manifest.Catalog)
		if e != nil {
			return e
		}
		for _, r := range rows {
			if r.Gate != nil {
				out.GateRows++
			}
		}
		out.Rows += len(rows)
		out.CaseCount += len(source.Cases)
		out.Scenes = append(out.Scenes, scene)
		index++
		fmt.Fprintf(os.Stderr, "gate特徴 %d/%d %s rows=%d\n", index, len(manifest.Scenes), source.Session, len(rows))
		return nil
	})
	if e != nil {
		return out, e
	}
	var success bool
	var trial, count, members int
	if e = json.Unmarshal(parent.Top["success"], &success); e != nil {
		return out, e
	}
	if e = json.Unmarshal(parent.Top["trial"], &trial); e != nil {
		return out, e
	}
	if e = json.Unmarshal(parent.Top["case_count"], &count); e != nil {
		return out, e
	}
	if e = json.Unmarshal(parent.Top["membership_count"], &members); e != nil {
		return out, e
	}
	if !success || trial != 158 || count != out.CaseCount || members != out.MembershipCount || index != len(manifest.Scenes) || options.All73 && (index != 73 || count != 837 || members != 924 || out.Rows != 1674) {
		return out, fmt.Errorf("全固定結果/所属/場/照会分母差")
	}
	if _, e = checkedBytes(options.ManifestPath, options.ManifestSHA); e != nil {
		return out, e
	}
	if _, e = checkedBytes(options.SpecificationPath, options.SpecificationSHA); e != nil {
		return out, e
	}
	out.InputRefs["results158"] = map[string]any{"reference": options.Results, "actual_sha256": parent.ActualSHA256, "decoded_sha256": parent.DecodedSHA256, "decoded_bytes": parent.DecodedBytes, "stat_before": parent.StatBefore, "stat_after": parent.StatAfter}
	out.InputRefs["feature_manifest158"] = map[string]string{"path": options.ManifestPath, "sha256": options.ManifestSHA}
	out.InputRefs["specification159"] = map[string]string{"path": options.SpecificationPath, "sha256": options.SpecificationSHA}
	out.SceneCount = index
	out.Success = true
	return out, nil
}
