# 159：最初TP125原行の特徴抽出

準備のみ。自然抽出はRootの159正式条件固定・通知後にRootが一回実行する。158Source・自然特徴・別算術票は変更しない。

正式158結果の全837物理caseから、C0=`F125S125`のH60/SESSION×D0/D1×C0/C5を照合する。各Hの全D/cが`trigger.reason=take_profit`になるかどうかと、その最初Quote全8値/trigger.Timeを一致検査する。TPの場合だけ当該原行をgateにする。C0の非TP/unknownはgate=nullのまま残す。利確後fillや損益、他政策の結果をsnapshotへ入れない。共通87は所属を複数持つ物理1caseで、元memberships全JSONを保持する。

全case×2H=1674票。`scenes[].rows[]`は`case_id/session/contract/session_index/horizon/side/original_side/stream/entry/entry_price/memberships/gate/trigger`と、`values/known/valid_until/feature_ref_ids/refs/feature_updated_at/feature_event_id`を持つ。値は149個の物理方向非依存特徴で、side投影・ルール採否・ラベル・学習は行わない。gate無しでは特徴部はnull。場start/end/force_close/continuous_endを保持するがXにするためではない。

特徴はAt.time/index/source_lineの全てがgate以下の最新Contextだけを使い、gate.Time>=ValidUntilでunknown/nullへする。将来票の先読は現在値へ適用しない。値と参照はコピーし、後の特徴更新から独立に凍結する。最初の特徴より早いgateなら149個ともunknownで、古いknownへのfallbackや0補完はしない。

自然CLIの形（repo root、159条件のpath/SHAはRoot固定値を指定）：

```powershell
& '.\work\159延伸判断の特徴抽出\snapshot159.exe' --allow-natural `
  --results '.\study\00158_複合技術で出口の役割と局面を切り替える\成果物\出口結果.json.gz' `
  --results-sha '70a4c3178206bbb3c8641901c7515f2121da11c28403b88c3f8e6f93cc0baa6c' `
  --results-decoded-sha '3c3df90244de838056ca7c98857ffe7b8f85514807e90194c07f73129ec277c7' `
  --results-bytes 7057093 `
  --features '.\inputs\00158_複合技術特徴\特徴\特徴の確認.json' `
  --spec '<159実行条件のpath>' --spec-sha '<159正式条件SHA>' `
  --output '<未作成の固定snapshot.json.gz>'
```

全73場の特徴gzipをgateゼロ場も含め完読し、CRC/物理SHA/解凍SHA/rows/前後statを検査する。158結果gzipも場単位で完読・両SHA/CRCを検査し、全入力成功後だけ排他出力する。Raw/価格CSVを開かない。出力gzip隣に`.完了.json`を保存する。再生入口は固定したままであり、抽出自体を出口の成績改善とはしない。

検査：`go test -count=1 -v ./...`、`go vet ./...`、`go build -o snapshot159.exe ./cmd/run`。人工6群はC0全D/c・所属重複、非TP/売Ask、TTL/凍結/未来index、将来票差し替え非依存、gateゼロ場完読、CRC/親解凍SHA失敗とend-to-end結合。自作抽出器の作者検査であり、独立レビューはRoot/他担当に分ける。

依存は不変更のfeatures158型とReadParent汎用gzip iterator（数値計算を呼ばない）、pricetape157 Quote型。158特徴の再生成、価格経路再走査、既存正式試行の変更を行わない。
