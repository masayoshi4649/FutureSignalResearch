// Package gatesnapshots159 は固定入口の最初TP125原行だけへ公表済み特徴を結合します。
package gatesnapshots159

import (
	"encoding/json"
	"fmt"
	"math"
	"reflect"
	"sort"

	features "features158"
	tape "pricetape157"
)

type Quote = tape.Quote
type Stamp = features.Stamp
type FeatureRef = features.FeatureRef

type Trigger struct {
	Reason string  `json:"reason"`
	Time   float64 `json:"time"`
	Quote  *Quote  `json:"quote"`
}

type BaselineResult struct {
	Policy  string   `json:"policy"`
	Horizon string   `json:"horizon"`
	Delay   string   `json:"delay"`
	Cost    string   `json:"cost"`
	Trigger *Trigger `json:"trigger"`
}

type SourceCase struct {
	ID           string           `json:"id"`
	OriginalSide int              `json:"original_side"`
	Side         int              `json:"side"`
	Stream       string           `json:"stream"`
	Entry        Quote            `json:"entry"`
	EntryPrice   float64          `json:"entry_price"`
	Memberships  json.RawMessage  `json:"memberships"`
	Results      []BaselineResult `json:"results"`
}

type SourceScene struct {
	Session       string       `json:"session"`
	Contract      string       `json:"contract"`
	Start         float64      `json:"start"`
	End           float64      `json:"end"`
	ForceClose    float64      `json:"force_close"`
	ContinuousEnd float64      `json:"continuous_end"`
	Cases         []SourceCase `json:"cases"`
}

type Snapshot struct {
	CaseID           string              `json:"case_id"`
	Session          string              `json:"session"`
	Contract         string              `json:"contract"`
	SessionIndex     int                 `json:"session_index"`
	Horizon          string              `json:"horizon"`
	Side             int                 `json:"side"`
	OriginalSide     int                 `json:"original_side"`
	Stream           string              `json:"stream"`
	Entry            Quote               `json:"entry"`
	EntryPrice       float64             `json:"entry_price"`
	Memberships      json.RawMessage     `json:"memberships"`
	Gate             *Quote              `json:"gate"`
	Trigger          *Trigger            `json:"trigger"`
	Values           map[string]*float64 `json:"values"`
	Known            map[string]bool     `json:"known"`
	ValidUntil       map[string]*float64 `json:"valid_until"`
	FeatureRefIDs    map[string][]string `json:"feature_ref_ids"`
	Refs             []FeatureRef        `json:"refs"`
	FeatureUpdatedAt *Stamp              `json:"feature_updated_at"`
	FeatureEventID   *string             `json:"feature_event_id"`
}

type SnapshotScene struct {
	Session       string       `json:"session"`
	Contract      string       `json:"contract"`
	SessionIndex  int          `json:"session_index"`
	Start         float64      `json:"start"`
	End           float64      `json:"end"`
	ForceClose    float64      `json:"force_close"`
	ContinuousEnd float64      `json:"continuous_end"`
	Rows          []Snapshot   `json:"rows"`
	FeatureRead   ReadEvidence `json:"feature_read"`
}

// finite は有限数値だけを認めます。
//
// 引数: xs(...float64)。返り値: bool。
func finite(xs ...float64) bool {
	for _, x := range xs {
		if math.IsNaN(x) || math.IsInf(x, 0) {
			return false
		}
	}
	return true
}

// stamp はQuoteの全配送時計だけを取り出します。
//
// 引数: q(Quote)。返り値: Stamp。
func stamp(q Quote) Stamp { return Stamp{Time: q.Time, Index: q.Index, SourceLine: q.SourceLine} }

// before は3時計が全て現在以前かを判定します。
//
// 引数: a/b(Stamp)。返り値: bool。
func before(a, b Stamp) bool {
	return a.Time <= b.Time && a.Index <= b.Index && a.SourceLine <= b.SourceLine
}

// normal は清算側も含む有効な実BBOを要求します。
//
// 引数: q(Quote)。返り値: bool。
func normal(q Quote) bool {
	return q.QuoteOK && finite(q.Time, q.Last, q.Bid, q.Ask) && q.Last > 0 && q.Bid > 0 && q.Ask > q.Bid && q.Index >= 0 && q.SourceLine > 0
}

// Queries は全物理caseを一度だけ保持しC0全D/cからH別のgate照会を作ります。
//
// 引数: scene(SourceScene)、sessionIndex(int)。返り値: []Snapshot/error。損益/採否は受け取りません。
func Queries(scene SourceScene, sessionIndex int) ([]Snapshot, error) {
	if scene.Session == "" || scene.Contract == "" || !finite(scene.Start, scene.End, scene.ForceClose, scene.ContinuousEnd) || scene.Start >= scene.ForceClose || scene.ForceClose >= scene.ContinuousEnd || scene.ContinuousEnd != scene.End-300 {
		return nil, fmt.Errorf("場scope差")
	}
	rows := []Snapshot{}
	ids := map[string]bool{}
	for _, c := range scene.Cases {
		if c.ID == "" || ids[c.ID] || c.Side != 1 && c.Side != -1 || c.OriginalSide != 1 && c.OriginalSide != -1 || !normal(c.Entry) || !finite(c.EntryPrice) || c.Entry.Time < scene.Start || c.Entry.Time >= scene.ContinuousEnd {
			return nil, fmt.Errorf("物理case/入口差")
		}
		ids[c.ID] = true
		price := c.Entry.Ask
		if c.Side < 0 {
			price = c.Entry.Bid
		}
		if c.EntryPrice != price {
			return nil, fmt.Errorf("実側入口価格差")
		}
		var members []json.RawMessage
		if e := json.Unmarshal(c.Memberships, &members); e != nil || len(members) == 0 {
			return nil, fmt.Errorf("所属不足")
		}
		base := map[string]BaselineResult{}
		for _, r := range c.Results {
			if r.Policy != "F125S125" {
				continue
			}
			if r.Horizon != "H60" && r.Horizon != "SESSION" || r.Delay != "D0" && r.Delay != "D1" || r.Cost != "C0" && r.Cost != "C5" {
				return nil, fmt.Errorf("C0構成不正")
			}
			key := r.Horizon + "/" + r.Delay + "/" + r.Cost
			if _, ok := base[key]; ok {
				return nil, fmt.Errorf("C0構成重複")
			}
			base[key] = r
		}
		if len(base) != 8 {
			return nil, fmt.Errorf("各物理caseにC0の8構成が必要")
		}
		for _, horizon := range []string{"H60", "SESSION"} {
			var gate *Quote
			var trigger *Trigger
			selected := false
			for _, delay := range []string{"D0", "D1"} {
				for _, cost := range []string{"C0", "C5"} {
					r := base[horizon+"/"+delay+"/"+cost]
					tp := r.Trigger != nil && r.Trigger.Reason == "take_profit"
					if !selected {
						selected = true
						if tp {
							if r.Trigger.Quote == nil {
								return nil, fmt.Errorf("TPにQuote無し")
							}
							q := *r.Trigger.Quote
							t := *r.Trigger
							t.Quote = &q
							gate = &q
							trigger = &t
						}
					} else if tp != (gate != nil) || tp && (!reflect.DeepEqual(r.Trigger.Quote, gate) || r.Trigger.Time != trigger.Time) {
						return nil, fmt.Errorf("全D/cの最初TP125原行が不一致")
					}
				}
			}
			if gate != nil {
				deadline := scene.ForceClose
				if horizon == "H60" {
					deadline = math.Min(deadline, c.Entry.Time+3600)
				}
				mark := gate.Bid
				if c.Side < 0 {
					mark = gate.Ask
				}
				if !normal(*gate) || !before(stamp(c.Entry), stamp(*gate)) || gate.Index <= c.Entry.Index || gate.SourceLine <= c.Entry.SourceLine || gate.Time >= deadline || trigger.Time != gate.Time || float64(c.Side)*(mark-c.EntryPrice) < 125 {
					return nil, fmt.Errorf("TP125要求時計/実BBO清算幅差")
				}
			}
			rows = append(rows, Snapshot{CaseID: c.ID, Session: scene.Session, Contract: scene.Contract, SessionIndex: sessionIndex, Horizon: horizon, Side: c.Side, OriginalSide: c.OriginalSide, Stream: c.Stream, Entry: c.Entry, EntryPrice: c.EntryPrice, Memberships: append(json.RawMessage(nil), c.Memberships...), Gate: gate, Trigger: trigger})
		}
		pair := rows[len(rows)-2:]
		if pair[0].Gate != nil && !reflect.DeepEqual(pair[0].Gate, pair[1].Gate) {
			return nil, fmt.Errorf("H60での最初TP125とSESSION原行不一致")
		}
	}
	return rows, nil
}

// QueryOrder は物理原行順にgateの行添字を返します。
//
// 引数: rows([]Snapshot)。返り値: []int。gate無しの台帳行は保持するが照会しません。
func QueryOrder(rows []Snapshot) []int {
	indices := []int{}
	for i, r := range rows {
		if r.Gate != nil {
			indices = append(indices, i)
		}
	}
	sort.SliceStable(indices, func(i, j int) bool {
		a, b := rows[indices[i]], rows[indices[j]]
		if a.Gate.Index != b.Gate.Index {
			return a.Gate.Index < b.Gate.Index
		}
		if a.Gate.SourceLine != b.Gate.SourceLine {
			return a.Gate.SourceLine < b.Gate.SourceLine
		}
		if a.CaseID != b.CaseID {
			return a.CaseID < b.CaseID
		}
		return a.Horizon < b.Horizon
	})
	return indices
}

// Attach はgateまでの最新Contextだけをコピーしquery現在時刻でTTL失効します。
//
// 引数: row(*Snapshot)、context(features.Context)、catalog([]string)。返り値: error。
func Attach(row *Snapshot, context features.Context, catalog []string) error {
	if row.Gate == nil {
		return fmt.Errorf("gate無しへ特徴を結合しない")
	}
	q := stamp(*row.Gate)
	if context.Session != "" && (context.Session != row.Session || context.Contract != row.Contract || !before(context.At, q)) {
		return fmt.Errorf("未来/別場Context")
	}
	row.Values = map[string]*float64{}
	row.Known = map[string]bool{}
	row.ValidUntil = map[string]*float64{}
	row.FeatureRefIDs = map[string][]string{}
	row.Refs = append([]FeatureRef{}, context.Refs...)
	for _, r := range row.Refs {
		if r.Session != row.Session || r.Contract != row.Contract || r.End > r.AvailableAt || r.AvailableAt > r.Stamp.Time || !before(r.Stamp, q) {
			return fmt.Errorf("未来/別場feature ref")
		}
	}
	for _, key := range catalog {
		v := context.Values[key]
		if v.Known != (v.Value != nil) || v.Value != nil && !finite(*v.Value) || v.ValidUntil != nil && !finite(*v.ValidUntil) {
			return fmt.Errorf("特徴known/finite差")
		}
		row.Values[key] = nil
		row.Known[key] = false
		row.FeatureRefIDs[key] = append([]string{}, v.RefIDs...)
		if v.ValidUntil != nil {
			x := *v.ValidUntil
			row.ValidUntil[key] = &x
		} else {
			row.ValidUntil[key] = nil
		}
		if v.Known && (v.ValidUntil == nil || q.Time < *v.ValidUntil) {
			x := *v.Value
			row.Values[key] = &x
			row.Known[key] = true
		}
	}
	if context.EventID != "" {
		x := context.UpdatedAt
		id := context.EventID
		row.FeatureUpdatedAt = &x
		row.FeatureEventID = &id
	}
	return nil
}
