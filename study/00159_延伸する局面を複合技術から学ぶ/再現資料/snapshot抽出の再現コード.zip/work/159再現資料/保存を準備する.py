"""159のsnapshot抽出小源と参照だけをステージする。抽出・学習・金融は再実行しない。"""
from __future__ import annotations

import gzip
import hashlib
import json
import math
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
EXTRACTOR=ROOT/'work/159延伸判断の特徴抽出'
FORMAL159=ROOT/'study/00159_延伸する局面を複合技術から学ぶ'
F0=FORMAL159/'検査/特徴抽出前固定.json'
SNAPSHOT=ROOT/'inputs/00159_延伸判断の特徴/判断時点の特徴.json.gz'
COMPLETION=Path(str(SNAPSHOT)+'.完了.json')
PARENT158=ROOT/'study/00158_複合技術で出口の役割と局面を切り替える/再現資料/再現コード.zip'
PARENT157=ROOT/'study/00157_固定入口の到達距離と追尾退出を比較する/再現資料/再現コード.zip'


def fp(path: Path) -> dict:
    """
    機能: 物理SHAと前後statを確認しrepo相対参照を作る。
    引数: path(Path)。返り値: dict。
    """
    old=path.stat();h=hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(4<<20),b''):h.update(chunk)
    now=path.stat();assert (old.st_size,old.st_mtime_ns)==(now.st_size,now.st_mtime_ns)
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':old.st_size,
            'sha256':h.hexdigest(),'mtime_ns':old.st_mtime_ns}


def load(path: Path) -> dict:
    """
    機能: 小さい固定JSONだけを読む。
    引数: path(Path)。返り値: dict。
    """
    return json.loads(path.read_text(encoding='utf-8'))


def write(path: Path, value: dict) -> None:
    """
    機能: ステージ専有の小JSONをUTF8で保存する。
    引数: path(Path)、value(dict)。返り値: None。
    """
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')


def before(a: dict, b: dict) -> bool:
    """
    機能: 同場の配送time/index/source_lineが全て照会以前かを検査する。
    引数: a/b(dict)。返り値: bool。
    """
    return all(a[k]<=b[k] for k in ('time','index','source_line'))


def check_snapshot(completion: dict) -> dict:
    """
    機能: 既生成snapshotのCRC/両SHAと全149列の形/TTL/future guardを確認する。
    引数: completion(dict)。返り値: dict。特徴再算・C0再生・ラベル読取は行わない。
    """
    old=fp(SNAPSHOT);assert old['sha256']==completion['sha256'] and old['bytes']==completion['bytes']
    h=hashlib.sha256();size=0
    with gzip.open(SNAPSHOT,'rb') as source:
        body=source.read();h.update(body);size=len(body)
    assert h.hexdigest()==completion['decoded_sha256'] and size==completion['decoded_bytes']
    data=json.loads(body);del body
    assert data['success'] and data['trial']==159 and data['schema']=='gate_snapshots159_v1'
    assert not data['labels_used'] and not data['new_selection_used'] and not data['raw_read']
    catalog=data['catalog'];assert len(catalog)==149 and catalog==sorted(set(catalog))
    cases={};rows=gate_rows=cells=known=unknown=refs=0
    for si,scene in enumerate(data['scenes']):
        assert scene['session_index']==si and scene['feature_read']['success']
        for row in scene['rows']:
            rows+=1
            assert row['session']==scene['session'] and row['contract']==scene['contract'] and row['session_index']==si
            assert row['horizon'] in ('H60','SESSION') and row['side'] in (-1,1)
            previous=cases.setdefault(row['case_id'],{'rows':[],'memberships':row['memberships'],'entry':row['entry']})
            assert row['horizon'] not in previous['rows'] and previous['memberships']==row['memberships'] and previous['entry']==row['entry']
            previous['rows'].append(row['horizon'])
            q=row['gate']
            if q is None:
                assert all(row[k] is None for k in ('trigger','values','known','valid_until','feature_ref_ids','refs','feature_updated_at','feature_event_id'))
                continue
            gate_rows+=1
            assert row['trigger']['reason']=='take_profit' and row['trigger']['time']==q['time'] and row['trigger']['quote']==q
            assert before(row['entry'],q) and row['entry']['index']<q['index'] and row['entry']['source_line']<q['source_line']
            assert q['quote_ok'] and 0<q['bid']<q['ask']
            mark=q['bid'] if row['side']==1 else q['ask']
            assert row['side']*(mark-row['entry_price'])>=125
            limit=scene['force_close'] if row['horizon']=='SESSION' else min(scene['force_close'],row['entry']['time']+3600)
            assert q['time']<limit
            for name in ('values','known','valid_until','feature_ref_ids'):assert set(row[name])==set(catalog)
            ref_ids=set()
            for ref in row['refs']:
                refs+=1;assert ref['id'] not in ref_ids;ref_ids.add(ref['id'])
                assert ref['session']==scene['session'] and ref['contract']==scene['contract']
                assert ref['end']<=ref['available_at']<=ref['stamp']['time'] and before(ref['stamp'],q)
            if row['feature_updated_at'] is not None:assert before(row['feature_updated_at'],q)
            for key in catalog:
                cells+=1;value=row['values'][key];flag=row['known'][key];until=row['valid_until'][key]
                assert type(flag) is bool and flag==(value is not None)
                if flag:
                    known+=1;assert type(value) in (int,float) and math.isfinite(value)
                    if until is not None:assert q['time']<until
                else:unknown+=1
                if until is not None:assert math.isfinite(until)
                assert set(row['feature_ref_ids'][key])<=ref_ids
    assert len(data['scenes'])==73 and len(cases)==837 and rows==1674 and gate_rows==977
    assert all(set(c['rows'])=={'H60','SESSION'} for c in cases.values())
    assert sum(len(c['memberships']) for c in cases.values())==924
    assert rows==completion['rows'] and gate_rows==completion['gate_rows']
    assert old==fp(SNAPSHOT)
    return {'success':True,'snapshot':old,'decoded_sha256':h.hexdigest(),'decoded_bytes':size,
            'crc_checked':True,'scenes':73,'physical_cases':837,'memberships':924,'rows':rows,
            'gate_rows':gate_rows,'no_gate_rows':rows-gate_rows,'point_feature_cells':cells,
            'known_cells':known,'unknown_cells':unknown,'refs':refs,
            'all_149_shape_finite_null_ttl_future_guards_checked':True,
            'numeric_recalculation':False,'first_tp_raw_replay':False,'author_only_preservation_check':True}


def main() -> None:
    """
    機能: F0現物同体・snapshot保存性・親ZIP依存を確認して小源ZIPを作る。
    引数: なし。返り値: None。学習/抽出/金融の自然実行をしない。
    """
    frozen=load(F0);assert frozen['成功'] and frozen['試行']==159
    current={}
    for path,sha in frozen['Source'].items():
        current[path]=fp(ROOT/path);assert current[path]['sha256']==sha
    for ref in frozen['参照'].values():assert fp(ROOT/ref['path'])['sha256']==ref['sha256']
    prep=load(EXTRACTOR/'準備の確認.json');stop=load(EXTRACTOR/'停止の確認.json')
    assert fp(EXTRACTOR/'準備の確認.json')['sha256']==stop['preparation']['sha256']
    for ref in prep['files']:assert fp(Path(ref['path']))['sha256']==ref['sha256']
    snapshot=check_snapshot(load(COMPLETION))
    parent_refs=[fp(PARENT158),fp(PARENT157)]
    # ----------------------------------------
    # 依存は158/157の既保存ZIPを参照し、同じ小源や大入力を新ZIPへ複写しない。
    dependencies=[]
    with zipfile.ZipFile(PARENT158) as z:
        names=set(z.namelist())
        for module in ('158技術特徴','157固定入口と価格経路','118複数技法の入口条件'):
            for path in sorted((ROOT/'work'/module).rglob('*')):
                if path.is_file() and (path.suffix=='.go' or path.name=='go.mod'):
                    relative=path.relative_to(ROOT).as_posix();assert relative in names,relative
                    saved=z.read(relative);assert saved==path.read_bytes(),relative
                    dependencies.append({'path':relative,'sha256':hashlib.sha256(saved).hexdigest(),'parent_archive':parent_refs[0]['path']})
    index={'success':True,'trial':159,'scope':'snapshot抽出器だけの再現ステージ。学習/集計/CSV/最終独立票は後でRootが追加',
           'f0':fp(F0),'f0_extractor_sources_current_equal':current,'snapshot':snapshot,
           'snapshot_completion':fp(COMPLETION),'parent_archives':parent_refs,'dependencies':dependencies,
           'shared_inputs_not_copied':True,'snapshot_not_copied':True,'natural_reexecuted':False,
           'limits':['C0最初正常TP125の全Raw別再生ではない','149値の数式再実装ではない',
                     '当該snapshotの有限NULL/期限/参照時計を保存性検査した',
                     '158特徴の数式/鮮度/計測時計・既使用全73場の制限を継承する']}
    write(HERE/'入力と依存の参照.json',index)
    allow=[EXTRACTOR/'extract.go',EXTRACTOR/'extract_test.go',EXTRACTOR/'go.mod',EXTRACTOR/'stream.go',
           EXTRACTOR/'cmd/run/main.go',EXTRACTOR/'README.md',EXTRACTOR/'準備の確認.json',EXTRACTOR/'停止の確認.json',
           F0,COMPLETION,HERE/'README.md',HERE/'入力と依存の参照.json',Path(__file__)]
    archive=HERE/'snapshot抽出の再現コード.zip';assert not archive.exists()
    contents={p.relative_to(ROOT).as_posix():p.read_bytes() for p in allow}
    manifest={'trial':159,'scope':index['scope'],'parent_archives':parent_refs,
              'members':[{'path':p,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for p,b in sorted(contents.items())]}
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for path,body in sorted(contents.items()):z.writestr(path,body)
        z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and set(z.namelist())==set(contents)|{'manifest.json'}
        for path,body in contents.items():assert z.read(path)==body
        assert json.loads(z.read('manifest.json'))==manifest
    assert current=={p:fp(ROOT/p) for p in current}
    write(HERE/'ステージの確認.json',{'success':True,'trial':159,'archive':fp(archive),
          'index':fp(HERE/'入力と依存の参照.json'),'members':len(contents),'all_member_bytes_reread':True,
          'all_zip_crc_checked':True,'f0_sources_before_after_equal':True,'natural_reexecuted':False,
          'formal159_edited':False,'snapshot_or_shared_inputs_copied':False})
    print(json.dumps({'archive':fp(archive),'proof':fp(HERE/'ステージの確認.json')},ensure_ascii=False,indent=2))


if __name__=='__main__':main()
