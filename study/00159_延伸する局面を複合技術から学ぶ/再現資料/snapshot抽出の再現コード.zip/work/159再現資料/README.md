# 159 snapshot抽出器の再現ステージ

ここは`work/159再現資料/`の準備物であり、159の学習・集計・CSV・最終独立票を含む最終保存とは分ける。正式159/旧158/旧157の文書や固定Sourceを変更しない。

`snapshot抽出の再現コード.zip`へ抽出器のGo小源・人工・準備/停止票と必要な小参照だけを元のrepo相対pathで保存する。exe、判断snapshot本体、価格テープ、158出口結果、158特徴、元147/122、学習モデルを同梱しない。ZIP内manifestと`入力と依存の参照.json`に全格納SHA/bytesと親ZIPの参照を残す。全ZIP格納bytesを再読照合する。

Go依存の`features158`・`pricetape157`・`entryrules118`は正式158の`再現資料/再現コード.zip`に保存済みなので、そのZIPをrepoルートへ復元する。正式157の同名ZIPは旧Quote/テープ由来と再現契約の参照先。両親ZIPの完全path/SHA/bytesは索引に記録し、158親ZIPの依存Go全bytesが現在の固定依存と同体であることも確認する。新159 ZIPを同じルートへ展開すれば`go.mod replace`を変えずbuildできる。

## 恒久入力と時計

snapshotは`inputs/00159_延伸判断の特徴/判断時点の特徴.json.gz`を一度保存済みで、再複写しない。物理SHA `b7be610367196246af4125cabc10ea46157d4068896d29c35d0939084b41a148`、3,600,073 bytes、解凍SHA `3ac97f2372c3c58b5c0e2584e0d72b27f08f3a50dec6c2cfcfe40e85db63fe7e`、33,662,878 bytes。元837物理case/924所属、73場×case別H60/SESSIONの1674票、TP125 gate977票。共通87を別物理caseへ水増ししない。gate無しは特徴部nullのまま保持する。

由来は正式158`成果物/出口結果.json.gz`（物理`70a4c3178206bbb3c8641901c7515f2121da11c28403b88c3f8e6f93cc0baa6c`、解凍`3c3df90244de838056ca7c98857ffe7b8f85514807e90194c07f73129ec277c7`）と`inputs/00158_複合技術特徴/特徴/特徴の確認.json`（`a6dce32eb35102d95f44647d0a10811bf13ed6e36f46b08ef0956c52bb783d11`）。特徴は147 canonical OHLCV/固定122旧公表由来で、実受信時刻や即時Raw足へ読み替えない。

C0=`F125S125`の最初`trigger.reason=take_profit`原行をqueryとし、全D0/D1・費用C0/C5で当該Quote全8値が同じことを抽出器が検査する。ctxのtime/index/source_line全て<=queryの当時値だけを採る。1分はEnd+180、背景は旧Source早期限End+width+60を継承し、query時刻で期限等号をunknown/nullへ変える。期限切れ/未知で古いknownへ戻らない。保存snapshotには149raw値/known/期限/参照を残し、side投影・採否・ラベル・学習を含めない。

保存時にsnapshotの全CRC/両SHA/stat、全149列の形・有限NULL・query TTL・参照の非未来を検査する。これは149数式を別実装した検算や、原板から最初正常TP原行を全件別再生した証明ではない。158のSource/特徴別算術票の限界（ST/SAR/CK自然数式6列・MTF値再計算は対象外）と、既使用全73場・重複caseの依存も継承する。今回の保存検査は抽出作者の確認であり、最終159の独立学習/集計票を後から追加する。

## 再現

入力をそのまま使えば抽出再実行は不要。コードを確かめる最小手順は、新しいcheckoutへ親158 ZIPと新159 ZIPを元相対pathで復元し、`work/159延伸判断の特徴抽出/`で以下を行う。

```powershell
go test -count=1 -v ./...
go vet ./...
go build -o '<新しいsnapshot159.exe>' ./cmd/run
```

保存確認だけではこれらを再実行せず、F0 `検査/特徴抽出前固定.json`と5源/exe、作者準備票全小源の現物SHA一致を確認する。元exe SHAは`b2905518759eaae8be0c670de08ef2164fb41e9e78b4ab311add8c66f7e4cef0`。新環境buildの物理SHAは別に記録する。

本当に再抽出する場合だけ、根拠入力と159条件を固定し、抽出器READMEのCLIへ次を明示する。既存正本へ上書きしない。

```powershell
& '<新しいsnapshot159.exe>' --allow-natural `
  --results 'study/00158_複合技術で出口の役割と局面を切り替える/成果物/出口結果.json.gz' `
  --results-sha '70a4c3178206bbb3c8641901c7515f2121da11c28403b88c3f8e6f93cc0baa6c' `
  --results-decoded-sha '3c3df90244de838056ca7c98857ffe7b8f85514807e90194c07f73129ec277c7' `
  --results-bytes 7057093 `
  --features 'inputs/00158_複合技術特徴/特徴/特徴の確認.json' `
  --spec 'study/00159_延伸する局面を複合技術から学ぶ/実行条件.md' `
  --spec-sha '8899a5a1b378abd669ec9003ded19930c4e315879b76dc67517dd0b5e4e6bdb3' `
  --output '<未作成の別snapshot.json.gz>'
```

自然抽出・学習・金融は今回のステージ処理では一切再実行しない。後発の学習/集計/CSV/独立票をこの抽出前F0へ遡及して含めない。
