# 159 独立確認の準備

2026-11-13。新159の自然モデル・新採否・合成結果は未読。固定仕様と作者コードの静的読取、および私有人工だけを先に行った。自然実行はRootの結果SHA通知後とする。158の正式再現資料・Source・結果は変更していない。

## 実装と静的確認

`oracle159.py`は作者のdata/rules/runnerをimportせず、25派生量、124predicate、異役割6,232条件対×2行動の12,464規則を別式で計算する。整数bitsetで一致教師を保持し、金額差と場内分母はFractionで計算する。9適用枠を6訓練範囲へ分け、重複fitを探索件数へ水増ししない。

作者`work/159複合条件の延伸選択/{data159.py,rules159.py,実行する.py}`の主要境界を静的に確認した。

- 教師はH60/D1/C5の三行動全closedに限る。未知はNaNで保持し、eligible=falseとして分離する。837物理caseを対象とし、共通87所属を二重教師にしない。
- 場番号の過去区間と`known_at < cutoff`をfit前に選ぶ。cutoff等号・当場/将来を除く。n_jは選択された全eligible gate教師数で、規則一致件数で置き換えない。
- `apply_model(model, derived)`へラベル・親cash・選択後のknownを渡さない。未学習はIFD。学習済みでも不成立・未知・非TPはIFD。同じH60学習modelをSESSION/D0/C0へ適用する。
- 合成は共通prefixの三親経路だけ。非TPの初期決済同体、gate前退出がないことを先に確認し、選んだ親の実cashを全値コピーする。親technical_counts/traceを新gateの実発動数へ混ぜない。

これはソースの静的確認であり、自然全件の成功票ではない。入力DTOの極端な型防御を、固定入力SHAで束縛された自然の時間漏洩と混同しない。

## 本番の確認範囲

`確認する.py`が保存159 snapshotと親158結果を一場ずつ読み、gate・149値の既知/期限・ref時計・共通prefixを確認する。その後に過去教師だけを作り、全規則winner/上位10/score/場寄与/支持件数/分母/成熟/自己model SHAを別計算する。全5,022 choiceと全837物理case×24G状態の選択・warmupIFD・同モデル感度適用・親cash・parent_diagnostics分離を照合する。

最終結果から新規則を学び直す処理はない。数学的な同点と浮動小数の丸めが異なれば、そのまま差として報告する。原板の再読、価格経路の再生、各特徴の数値生成を再実装する検査ではない。snapshot値の全元イベント再抽出は別の抽出器人工・Source境界へ分離する。

## 人工

人工6群は、売買実側・prior高安交換・ゼロ分母、未知>=/<両偽、strict cutoffと当場除外、全eligible分母/最大一場除去/負寄与罰、label無し適用、長い場JSONとescape/後置metadata/gzipCRC、未知教師だけの9枠/6fitを確認する。自然入力本文・モデル・金融結果は読んでいない。

```powershell
python -X utf8 work/159独立確認/人工検査.py
```

## Root結果通知後のCLI

Python標準ライブラリのみ。各pathと物理SHAを明示し、票は未作成先へ保存する。親337MB結果は場単位に一回解釈し、巨大全件の副本・全leafの再転記を残さない。

```powershell
python -X utf8 work/159独立確認/確認する.py `
 --snapshot '<判断時点の特徴.json.gz>' --snapshot-sha256 '<固定SHA>' `
 --parent '<158出口結果.json.gz>' --parent-sha256 '70a4c3178206bbb3c8641901c7515f2121da11c28403b88c3f8e6f93cc0baa6c' `
 --models '<モデルと学習報告.json>' --models-sha256 '<Root通知SHA>' `
 --choices '<全gateの出口選択.json>' --choices-sha256 '<Root通知SHA>' `
 --result '<固定入口の出口合成.json.gz>' --result-sha256 '<Root通知SHA>' `
 --book 'study/00159_延伸する局面を複合技術から学ぶ/文法と学習の固定.json' `
 --book-sha256 '86fa33f1e1111ddc2665e1cb6c68c7b4dae5dfc61feff0132ef144064966891a' `
 --output 'work/159独立確認/自然確認/独立確認.json'
```

既存149特徴manifestは当時catalog/SHAを確認するためだけに読む。93MBの特徴本文、Raw、未見2場、旧156を使わない。成功後は小票と必要な検査Sourceだけを保存する。
