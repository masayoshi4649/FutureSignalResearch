"""機能: 159の派生特徴・規則・過去教師scoreを作者関数なしで計算する。"""
from collections import Counter, defaultdict
from fractions import Fraction
import itertools
import math


def numeric(value) -> bool:
    """機能: boolを除く有限数値だけを既知とする。

    引数: value(JSON値)。返り値: bool。
    """
    return type(value) in (int, float) and math.isfinite(value)


def derive(row: dict) -> dict:
    """機能: 当時の149値を別式で25の方向付き量へ写す。

    引数: row(dict型のgate入力)。返り値: dict[str,float|None]。
    """
    side = row['side']
    assert type(side) is int and side in (-1, 1)
    values = row['values'] or {}

    def get(key):
        """機能: 有限既知値を取得する。

        引数: key(str)。返り値: float又はNone。
        """
        value = values.get(key)
        assert value is None or numeric(value), (key, value)
        return value

    def signed(key):
        """機能: 物理値を実側へ射影する。

        引数: key(str)。返り値: float又はNone。
        """
        x = get(key)
        return None if x is None else side*x

    def divided(numerator, denominator):
        """機能: 正の既知分母に限り除算する。

        引数: numerator/denominator(数値又はNone)。返り値: float又はNone。
        """
        return numerator/denominator if numeric(numerator) and numeric(denominator) and denominator > 0 else None

    def minus(a, b):
        """機能: 両値既知の差だけを作る。

        引数: a/b(数値又はNone)。返り値: float又はNone。
        """
        return a-b if numeric(a) and numeric(b) else None

    out = {}
    for width in (5, 15, 30):
        denominator = get(f'm{width}.atr14')
        out[f'gap{width}_atr{width}'] = divided(signed(f'm{width}.gap'), denominator)
        out[f'slope{width}_atr{width}'] = divided(signed(f'm{width}.ema21_delta'), denominator)
    atr = get('m1.atr14')
    out.update({'di1': signed('m1.di_difference'), 'adx15': get('m15.adx'),
                'hist1_atr1': divided(signed('m1.hist'), atr),
                'hist5_atr5': divided(signed('m5.hist'), get('m5.atr14')),
                'hist_delta1_atr1': divided(signed('m1.hist_delta'), atr),
                'rsi_signed': None if get('m1.rsi14') is None else side*(get('m1.rsi14')-50),
                'cmf_signed': signed('m1.cmf20'), 'obv_delta5_signed': signed('m1.obv_delta5'),
                'rvol1': get('m1.rvol'), 'er10': get('m1.er10'), 'chop14': get('m1.chop14'),
                'bb_width_ratio': divided(get('m1.bb_width'), get('m1.previous_bb_width')),
                'atr1_atr5': divided(atr, get('m5.atr14')),
                'close_ema8_atr1': divided(minus(signed('m1.close'), signed('m1.ema8')), atr),
                'zscore_signed': signed('m1.zscore'), 'body_atr1': divided(signed('m1.body'), atr),
                'forward5_atr1': divided(minus(signed('m1.close'), signed('m1.prior_high5' if side > 0 else 'm1.prior_low5')), atr),
                'opposite5_atr1': divided(minus(signed('m1.close'), signed('m1.prior_low5' if side > 0 else 'm1.prior_high5')), atr),
                'elapsed_minutes': None if row['gate'] is None else (row['gate']['time']-row['entry']['time'])/60})
    assert len(out) == 25 and all(v is None or numeric(v) for v in out.values())
    return out


def predicates(book: dict) -> list:
    """機能: 固定bookから124の原子的条件を作る。

    引数: book(dict)。返り値: list[dict]型のID辞書順条件。
    """
    result = []
    for item in book['特徴']:
        for threshold in item['thresholds']:
            assert numeric(threshold)
            for op in ('>=', '<'):
                result.append({'id': f'{item["role"]}/{item["name"]}/{op}{threshold:.15g}',
                               'feature': item['name'], 'role': item['role'],
                               'op': op, 'threshold': float(threshold)})
    result.sort(key=lambda p: p['id'])
    assert len(result) == 124 and len({p['id'] for p in result}) == 124
    return result


def holds(features: dict, predicate: dict) -> bool:
    """機能: 未知は両演算とも偽として条件を計算する。

    引数: features/predicate(dict)。返り値: bool。
    """
    value = features[predicate['feature']]
    if value is None:
        return False
    assert numeric(value) and predicate['op'] in ('>=', '<')
    return value >= predicate['threshold'] if predicate['op'] == '>=' else value < predicate['threshold']


def past_teachers(rows: list[dict], start: int, end: int, cutoff: float) -> list:
    """機能: 過去場かつ三行動全既知・strict成熟した物理教師だけを選ぶ。

    引数: rows(list[dict])、start/end(int)、cutoff(float)。返り値: list[dict]。
    """
    assert type(start) is int and type(end) is int and 0 <= start <= end and numeric(cutoff)
    result = []
    for row in rows:
        if not start <= row['session_index'] < end:
            continue
        if row['eligible'] is not True or not numeric(row['known_at']) or row['known_at'] >= cutoff:
            continue
        assert len(row['net']) == 3 and all(numeric(v) for v in row['net'])
        result.append(row)
    assert len({r['case_id'] for r in result}) == len(result)
    return result


def fit_oracle(teachers: list[dict], book: dict) -> dict:
    """機能: 整数bitsetと有理数で全12,464規則のwinnerを求める。

    引数: teachers(list[dict]型の成熟・過去選択済み教師)、book(dict)。返り値: dict。
    """
    atoms = predicates(book)
    assert len({t['case_id'] for t in teachers}) == len(teachers)
    denominators = Counter(t['session_index'] for t in teachers)
    masks = []
    for atom in atoms:
        mask = 0
        for i, teacher in enumerate(teachers):
            if holds(teacher['features'], atom):
                mask |= 1 << i
        masks.append(mask)
    evaluated = {}
    winners = []
    eligible_count = positive_count = pairs = 0
    for i, j in itertools.combinations(range(len(atoms)), 2):
        if atoms[i]['role'] == atoms[j]['role']:
            continue
        pairs += 1
        matches = masks[i] & masks[j]
        if matches.bit_count() < book['min_matched_teachers']:
            continue
        if matches not in evaluated:
            ids, bits = [], matches
            while bits:
                bit = bits & -bits
                ids.append(bit.bit_length()-1)
                bits ^= bit
            scenes = {teachers[k]['session_index'] for k in ids}
            if len(scenes) < book['min_matched_sessions']:
                evaluated[matches] = None
            else:
                candidates = []
                for action_index, action in enumerate(('C1', 'C2'), 1):
                    sums = defaultdict(Fraction)
                    for k in ids:
                        t = teachers[k]
                        assert len(t['net']) == 3 and all(numeric(v) for v in t['net'])
                        sums[t['session_index']] += Fraction(str(t['net'][action_index])) - Fraction(str(t['net'][0]))
                    contributions = {s: value/denominators[s] for s, value in sums.items()}
                    score = sum(contributions.values(), Fraction(0)) - max([Fraction(0), *contributions.values()])
                    score -= sum((-x for x in contributions.values() if x < 0), Fraction(0))/2
                    candidates.append({'action': action, 'score': score, 'matched_teachers': len(ids),
                                       'matched_scenes': len(scenes), 'scene_contributions': contributions})
                evaluated[matches] = candidates
        if evaluated[matches] is None:
            continue
        eligible_count += 2
        for candidate in evaluated[matches]:
            if candidate['score'] <= Fraction(str(book['minimum_score'])):
                continue
            positive_count += 1
            winners.append({**candidate, 'predicates': [atoms[i], atoms[j]]})
    assert pairs == 6232
    winners.sort(key=lambda r: (-r['score'], -r['matched_teachers'], r['action'] != 'C1',
                                tuple(p['id'] for p in r['predicates'])))
    return {'selected_rule': winners[0] if winners else None, 'top10': winners[:10],
            'support_qualified_rules': eligible_count, 'positive_score_rules': positive_count,
            'candidate_rules': pairs*2, 'teacher_count': len(teachers),
            'scene_denominators': dict(denominators), 'unique_masks_evaluated': len(evaluated)}


def apply_oracle(model: dict | None, features: dict, gate_present: bool) -> str:
    """機能: 学習済み二条件だけで行動を選ぶ。

    引数: model(dict又はNone)、features(dict)、gate_present(bool)。返り値: str。
    """
    if not gate_present or model is None or model['selected_rule'] is None:
        return 'C0'
    rule = model['selected_rule']
    return rule['action'] if all(holds(features, p) for p in rule['predicates']) else 'C0'
