"""機能: 159の教師・全規則winner・全G24経路選択を独立に再構成する。"""
from pathlib import Path
from collections import Counter
from fractions import Fraction
import argparse
import copy
import hashlib
import itertools
import json
import math

from oracle159 import numeric, derive, predicates, past_teachers, fit_oracle, apply_oracle
from 入力を読む import sha, scenes

POLICIES = ('G01_F48', 'G02_EXP12', 'G03_WIN36')
ACTIONS = {'C0': 'F125S125', 'C1': 'T125W100TP250', 'C2': 'A11_PROFIT_BUDGET'}
SPEC_SHA = '8899a5a1b378abd669ec9003ded19930c4e315879b76dc67517dd0b5e4e6bdb3'
BOOK_SHA = '86fa33f1e1111ddc2665e1cb6c68c7b4dae5dfc61feff0132ef144064966891a'


def same_quote(a, b) -> bool:
    """機能: 省略clockを空文字として全Quoteを比較する。

    引数: a/b(dict又はNone)。返り値: bool。
    """
    if a is None or b is None:
        return a is b
    keys = ('time', 'index', 'source_line', 'last', 'bid', 'ask', 'quote_ok', 'clock')
    return all(a.get(k, '' if k == 'clock' else None) == b.get(k, '' if k == 'clock' else None) for k in keys)


def canonical(value) -> str:
    """機能: 保存modelの自己SHAを作者関数なしで再計算する。

    引数: value(JSON値)。返り値: str。
    """
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                         separators=(',', ':'), allow_nan=False).encode('utf-8')).hexdigest()


def close(actual, expected) -> None:
    """機能: scoreの実数丸め範囲だけを許して別算術を比較する。

    引数: actual/expected(数値)。返り値: None。
    """
    assert numeric(actual) and math.isclose(actual, float(expected), rel_tol=1e-11, abs_tol=1e-7), (actual, expected)


def check_gate(row, parent, catalog):
    """機能: gate/共通prefix/未知/参照時計を独立照合する。

    引数: row/parent(dict)、catalog(list[str])。返り値: dict型の比較分母。
    """
    assert row['side'] == parent['side'] and row['session'] == parent['_session']
    assert row['contract'] == parent['_contract'] and same_quote(row['entry'], parent['entry'])
    assert row['entry_price'] == parent['entry_price'] and row['memberships'] == parent['memberships']
    gate = row['gate']
    compared = {'gate組': 0, '非gate組': 0, 'prefix比較': 0, '特徴値': 0, '参照': 0}
    for delay, cost in itertools.product(('D0', 'D1'), ('C0', 'C5')):
        base = parent['_results'][row['horizon'], delay, cost, 'C0']
        is_gate = base['trigger'] is not None and base['trigger']['reason'] == 'take_profit'
        assert is_gate == (gate is not None)
        if is_gate:
            assert same_quote(gate, base['trigger']['quote']) and same_quote(gate, base['first125_quote'])
            assert gate['time'] == base['trigger']['time'] < base['deadline']
            assert gate['index'] > row['entry']['index'] and gate['source_line'] > row['entry']['source_line']
            assert gate['quote_ok'] and 0 < gate['bid'] < gate['ask']
            assert row['side']*(gate['bid' if row['side'] > 0 else 'ask']-row['entry_price']) >= 125
            compared['gate組'] += 1
        else:
            compared['非gate組'] += 1
        for action in ('C1', 'C2'):
            alternative = parent['_results'][row['horizon'], delay, cost, action]
            if gate is None:
                ignored = {'config_id', 'policy', 'technical_counts', 'technical_trace'}
                assert {k: v for k, v in base.items() if k not in ignored} == {
                    k: v for k, v in alternative.items() if k not in ignored}
            else:
                assert same_quote(alternative['first125_quote'], gate) and alternative['reached125']
                assert base['fee_yen'] == alternative['fee_yen'] and base['deadline'] == alternative['deadline']
                for q in (alternative.get('arm_quote'), alternative.get('fill')):
                    if q is not None:
                        assert q['time'] >= gate['time'] and q['index'] >= gate['index'] and q['source_line'] >= gate['source_line']
                trigger = alternative['trigger']
                if trigger is not None:
                    assert trigger['time'] >= gate['time']
                    if trigger['quote'] is not None:
                        assert trigger['quote']['index'] >= gate['index'] and trigger['quote']['source_line'] >= gate['source_line']
            compared['prefix比較'] += 1
    if gate is None:
        assert row['values'] is None
        return compared
    assert set(row['values']) == set(catalog) == set(row['known']) == set(row['valid_until'])
    ids = {ref['id'] for ref in row['refs']}
    assert len(ids) == len(row['refs'])
    for ref in row['refs']:
        assert ref['contract'] == row['contract'] and ref['end'] <= ref['available_at'] <= ref['stamp']['time'] <= gate['time']
        if ref['session'] == row['session']:
            assert ref['stamp']['index'] <= gate['index'] and ref['stamp']['source_line'] <= gate['source_line']
        compared['参照'] += 1
    for name, value in row['values'].items():
        assert value is None or numeric(value)
        assert row['known'][name] is (value is not None)
        if value is not None and row['valid_until'][name] is not None:
            assert gate['time'] < row['valid_until'][name]
        assert set(row['feature_ref_ids'][name]) <= ids
        compared['特徴値'] += 1
    at = row.get('feature_updated_at')
    if at is not None:
        assert at['time'] <= gate['time'] and at['index'] <= gate['index'] and at['source_line'] <= gate['source_line']
    return compared


def check_rule(actual, expected):
    """機能: 選定規則・score・支持と全場寄与を照合する。

    引数: actual/expected(dict又はNone)。返り値: None。
    """
    if actual is None or expected is None:
        assert actual is expected
        return
    for k in ('action', 'predicates', 'matched_teachers', 'matched_scenes'):
        assert actual[k] == expected[k], (k, actual[k], expected[k])
    close(actual['score'], expected['score'])
    assert set(actual['scene_contributions']) == {str(k) for k in expected['scene_contributions']}
    for k, v in expected['scene_contributions'].items():
        close(actual['scene_contributions'][str(k)], v)


def model_checks(report, teacher_rows, scene_rows, book):
    """機能: 九つの適用枠を六つの過去訓練範囲へ分け全規則を照合する。

    引数: report(dict)、teacher_rows/scene_rows(list)、book(dict)。返り値: tuple。
    """
    assert report['success'] and report['trial'] == 159 and report['schema'] == 'walkforward_models159_v1'
    assert report['model_slots'] == 9 and report['unique_training_windows'] == 6
    assert report['minimum_score'] == book['minimum_score']
    assert report['dictionary'] == book['特徴'] and report['predicate_dictionary_sha256'] == canonical(predicates(book))
    assert report['teacher_total'] == 837 and report['eligible_teachers'] == sum(r['eligible'] for r in teacher_rows)
    assert report['unknown_or_non_gate_teachers'] == 837-report['eligible_teachers']
    assert set(report['models']) == set(POLICIES)
    cache, slots, summary = {}, {}, []
    for setting in book['policies']:
        policy = setting['id']
        assert len(report['models'][policy]) == len(setting['blocks'])
        for model, (first, last) in zip(report['models'][policy], setting['blocks'], strict=True):
            start = max(0, first-36) if policy == 'G03_WIN36' else 0
            cutoff = scene_rows[first]['start']
            assert (model['policy'], model['training_start_index'], model['training_end_exclusive'], model['cutoff'],
                    model['application_start_index'], model['application_end_exclusive']) == (policy, start, first, cutoff, first, last)
            chosen = past_teachers(teacher_rows, start, first, cutoff)
            assert model['teacher_case_ids'] == [r['case_id'] for r in chosen]
            assert model['teacher_count'] == len(chosen)
            assert model['teacher_scenes'] == len({r['session_index'] for r in chosen})
            assert model['maturity_max'] == max((r['known_at'] for r in chosen), default=None)
            key = start, first, cutoff
            if key not in cache:
                cache[key] = fit_oracle(chosen, book)
                print(json.dumps({'訓練範囲': [start, first], '教師': len(chosen), '規則': 12464}, ensure_ascii=False), flush=True)
            oracle = cache[key]
            assert model['scene_denominators'] == {str(k): v for k, v in oracle['scene_denominators'].items()}
            for out, expected in (('predicate_count', 124), ('candidate_pairs', 6232), ('candidate_rules', 12464),
                                  ('support_qualified_rules', oracle['support_qualified_rules']),
                                  ('positive_score_rules', oracle['positive_score_rules'])):
                assert model[out] == expected, (out, model[out], expected)
            check_rule(model['selected_rule'], oracle['selected_rule'])
            assert len(model['top10']) == len(oracle['top10'])
            for a, b in zip(model['top10'], oracle['top10'], strict=True):
                check_rule(a, b)
            hashed = {k: v for k, v in model.items() if k not in ('model_id', 'policy', 'application_start_index', 'application_end_exclusive')}
            assert canonical(hashed) == model['model_id']
            slots[policy, first, last] = (model, oracle)
            summary.append({'policy': policy, 'train': [start, first], 'apply': [first, last],
                            'teacher_count': len(chosen), 'model_id': model['model_id'],
                            'action': None if oracle['selected_rule'] is None else oracle['selected_rule']['action'],
                            'score': None if oracle['selected_rule'] is None else float(oracle['selected_rule']['score'])})
    assert len(slots) == 9 and len(cache) == 6
    return slots, summary


def main() -> None:
    """機能: Root通知後だけ自然モデル/選択/全G24結果を検査する。

    引数: CLI各path/明示SHA。返り値: None。学習・新選択・金融再生はしない。
    """
    parser = argparse.ArgumentParser()
    for name in ('snapshot', 'parent', 'models', 'choices', 'result', 'book'):
        parser.add_argument('--'+name, type=Path, required=True)
        parser.add_argument('--'+name+'-sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    before = {}
    for name in ('snapshot', 'parent', 'models', 'choices', 'result', 'book'):
        path = getattr(args, name)
        expected = getattr(args, name+'_sha256')
        assert sha(path) == expected
        before[str(path.resolve())] = [expected, path.stat().st_size, path.stat().st_mtime_ns]
    assert args.book_sha256 == BOOK_SHA
    book = json.loads(args.book.read_bytes())
    manifest_path = Path(__file__).resolve().parents[2] / 'inputs/00158_複合技術特徴/特徴/特徴の確認.json'
    assert sha(manifest_path) == book['snapshot_parent']['features_sha256']
    manifest_catalog = json.loads(manifest_path.read_bytes())['catalog']
    before[str(manifest_path.resolve())] = [book['snapshot_parent']['features_sha256'],
        manifest_path.stat().st_size, manifest_path.stat().st_mtime_ns]
    snapshot_evidence, parent_evidence = {}, {}
    parents, frames, scene_rows = {}, [], []
    counts, ids = Counter(), set()
    for snapshot, parent in itertools.zip_longest(scenes(args.snapshot, snapshot_evidence), scenes(args.parent, parent_evidence)):
        assert snapshot is not None and parent is not None
        index = len(scene_rows)
        for k in ('session', 'contract', 'start', 'end', 'force_close', 'continuous_end'):
            assert snapshot[k] == parent[k]
        scene_rows.append({k: snapshot[k] for k in ('session', 'contract', 'start', 'end', 'force_close', 'continuous_end')})
        for case in parent['cases']:
            assert case['id'] not in parents
            physical = (parent['session'], case['side'], case['entry']['time'], case['entry']['index'], case['entry']['source_line'])
            assert physical not in ids
            ids.add(physical)
            rows = {}
            for r in case['results']:
                if r['policy'] in ACTIONS.values():
                    action = next(a for a, p in ACTIONS.items() if p == r['policy'])
                    rows[r['horizon'], r['delay'], r['cost'], action] = {k: v for k, v in r.items() if k != 'technical_trace'}
            assert len(rows) == 24
            parents[case['id']] = {k: v for k, v in case.items() if k != 'results'} | {
                '_session': parent['session'], '_contract': parent['contract'], '_index': index, '_results': rows}
        catalog = snapshot_evidence['header']['catalog']
        assert len(catalog) == len(set(catalog)) == 149
        assert catalog == manifest_catalog
        for row in snapshot['rows']:
            assert row['session_index'] == index
            counts.update(check_gate(row, parents[row['case_id']], catalog))
            derived = derive(row)
            frames.append({k: v for k, v in row.items() if k in ('case_id', 'horizon', 'session', 'session_index', 'gate', 'entry', 'side')} |
                          {'features': derived, 'feature_index': len(frames)})
        print(json.dumps({'入力場': len(scene_rows), '物理case': len(parents)}, ensure_ascii=False), flush=True)
    assert len(scene_rows) == 73 and len(parents) == 837 and len(frames) == 1674
    assert len({(r['case_id'], r['horizon']) for r in frames}) == 1674
    assert snapshot_evidence['header']['schema'] == 'gate_snapshots159_v1'
    assert parent_evidence['header']['trial'] == 158
    sh = snapshot_evidence['header']
    assert (sh['scene_count'], sh['case_count'], sh['membership_count'], sh['rows']) == (73, 837, 924, 1674)
    assert sh['labels_used'] is False and sh['new_selection_used'] is False and sh['raw_read'] is False
    assert sh['input_refs']['results158']['actual_sha256'] == args.parent_sha256 == book['snapshot_parent']['result_sha256']
    assert sh['input_refs']['feature_manifest158']['sha256'] == book['snapshot_parent']['features_sha256']
    assert sh['input_refs']['specification159']['sha256'] == SPEC_SHA
    teachers = []
    for row in frames:
        if row['horizon'] != 'H60':
            continue
        outcomes = [parents[row['case_id']]['_results']['H60', 'D1', 'C5', a] for a in ACTIONS]
        complete = row['gate'] is not None and all(r['status'] == 'closed' and numeric(r['profit_yen']) and r['fill'] is not None for r in outcomes)
        teachers.append({**row, 'eligible': complete,
                         'known_at': max(r['fill']['time'] for r in outcomes) if complete else None,
                         'net': [r['profit_yen'] for r in outcomes] if complete else [None]*3})
    report = json.loads(args.models.read_bytes())
    assert report['prefix'] == {'gate_groups': counts['gate組'], 'non_gate_groups': counts['非gate組'],
                                'action_comparisons': counts['prefix比較']}
    slots, model_summary = model_checks(report, teachers, scene_rows, book)
    choices = json.loads(args.choices.read_bytes())
    assert choices['schema'] == 'gate_choices159_v1' and choices['success']
    assert choices['models_ref']['sha256'] == args.models_sha256
    assert choices['snapshot_ref']['sha256'] == args.snapshot_sha256
    expected_choices = {}
    for policy, row in itertools.product(POLICIES, frames):
        applicable = [(m, oracle) for (p, first, last), (m, oracle) in slots.items()
                      if p == policy and first <= row['session_index'] < last]
        assert len(applicable) <= 1
        model, oracle = applicable[0] if applicable else (None, None)
        action = apply_oracle(oracle, row['features'], row['gate'] is not None)
        has_rule = model is not None and oracle['selected_rule'] is not None
        reason = ('nonTP_C0保持' if row['gate'] is None else 'warmup_IFD' if model is None else
                  '合格規則なし_IFD' if not has_rule else 'AND成立_延伸' if action != 'C0' else
                  'AND不成立又は未知_IFD')
        expected_choices[policy, row['case_id'], row['horizon']] = {
            'policy': policy, 'case_id': row['case_id'], 'session': row['session'],
            'session_index': row['session_index'], 'horizon': row['horizon'], 'feature_index': row['feature_index'],
            'action': action,
            'model_id': None if model is None else model['model_id'], 'gate': row['gate'],
            'reason': reason, 'model_has_rule': has_rule}
    assert len(choices['rows']) == len(expected_choices) == 5022
    seen = set()
    for choice in choices['rows']:
        key = choice['policy'], choice['case_id'], choice['horizon']
        assert key not in seen and choice == expected_choices[key], key
        seen.add(key)
    result_evidence, result_count, result_cases = {}, 0, set()
    for scene in scenes(args.result, result_evidence):
        for case in scene['cases']:
            parent = parents[case['id']]
            assert case['id'] not in result_cases and scene['session'] == parent['_session']
            result_cases.add(case['id'])
            for k in ('id', 'original_side', 'side', 'stream', 'entry', 'entry_price', 'memberships'):
                assert case[k] == parent[k]
            assert len(case['results']) == 24
            configs = set()
            for result in case['results']:
                policy, horizon, delay, cost = (result[k] for k in ('policy', 'horizon', 'delay', 'cost'))
                choice = expected_choices[policy, case['id'], horizon]
                source = parent['_results'][horizon, delay, cost, choice['action']]
                assert result['config_id'] == '/'.join((policy, horizon, delay, cost))
                assert result['config_id'] not in configs
                configs.add(result['config_id'])
                for k, v in source.items():
                    if k not in ('policy', 'config_id', 'technical_counts'):
                        assert result[k] == v, (case['id'], result['config_id'], k)
                assert 'technical_counts' not in result and 'technical_trace' not in result
                assert result['parent_diagnostics'] == {'counts': source.get('technical_counts'),
                    'parent_result_sha': args.parent_sha256, 'session': scene['session'],
                    'case_id': case['id'], 'config_id': source['config_id']}
                assert result['selected_source_policy'] == ACTIONS[choice['action']]
                assert result['model_id'] == choice['model_id'] and result['gate_feature_index'] == choice['feature_index']
                assert same_quote(result['gate'], choice['gate'])
                info = result['recomposition159']
                assert info == {'method': '共通prefixによる保存経路の合成', 'source_config_id': source['config_id'],
                                'source_policy': source['policy'], 'action': choice['action']}
                result_count += 1
    assert result_count == 20088 and len(result_cases) == 837
    head = result_evidence['header']
    assert head['schema'] == 'recomposed_exit_results159_v1' and head['configuration_count'] == 24
    assert head['model_refs']['models']['sha256'] == args.models_sha256 and head['model_refs']['choices']['sha256'] == args.choices_sha256
    assert head['source_refs']['parent_result']['sha256'] == args.parent_sha256
    assert head['source_refs']['snapshot']['sha256'] == args.snapshot_sha256
    assert head['source_refs']['book']['sha256'] == BOOK_SHA and head['source_refs']['specification']['sha256'] == SPEC_SHA
    source_dir = Path(__file__).resolve().parents[2] / 'work/159複合条件の延伸選択'
    for name, expected in head['source_refs']['source_sha256'].items():
        assert sha(source_dir / name) == expected
    for name, (expected, size, mtime) in before.items():
        p = Path(name)
        assert sha(p) == expected and (p.stat().st_size, p.stat().st_mtime_ns) == (size, mtime)
    proof = {'成功': True, '試行': 159, '作者関数import': False, '新自然学習': False,
             '物理case': 837, '全gate票': 1674, '全choice': 5022, 'G結果状態': result_count,
             'モデル適用枠': 9, '重複を除くfit': 6, '全列挙規則比較': 6*12464,
             '入力とprefix比較': dict(counts), '教師既知': sum(t['eligible'] for t in teachers),
             'モデルの別計算': model_summary, '入力前後指紋': before,
             '解凍確認': {'snapshot': snapshot_evidence['decoded_sha256'], 'parent': parent_evidence['decoded_sha256'],
                          'result': result_evidence['decoded_sha256']},
             '本コードSHA256': sha(Path(__file__)), 'oracleSHA256': sha(Path(__file__).with_name('oracle159.py')),
             '検査器schema追補': {'初回handle': 23555, '初回終了値': 1,
                '初回停止段階': '全入力/6fit一致後、最初choiceのmodel_has_rule/reason metadata未対応',
                '修正': '最終固定の説明metadataとrecomposition内重複情報省略へ対応。判定/score/教師の別算術は不変',
                '学習前固定SHA256': '30c852055d59b0337cc2b21ff8f617eba83d906022e9440e2af0aa66854ded45',
                '自然再生成': False, '同一保存結果の再照合': True},
             '限界': '反実仮想は共通prefixを持つ3親経路だけ。原行金融の再生/新規則探索はしない。'}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(proof, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')
    print(json.dumps({'成功': True, 'SHA256': sha(args.output)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
