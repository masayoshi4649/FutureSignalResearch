"""機能: 159独自oracleの時間・未知・重み・適用の主要人工を確認する。"""
from pathlib import Path
from fractions import Fraction
from copy import deepcopy
import json
import hashlib
import gzip
import tempfile

from oracle159 import derive, predicates, holds, past_teachers, fit_oracle, apply_oracle
from 入力を読む import scenes
from 確認する import canonical, model_checks


def fixture_book() -> dict:
    """機能: 結果前に固定済みの159文法だけを読む。

    引数: なし。返り値: dict。
    """
    path = Path(__file__).resolve().parents[2] / 'study/00159_延伸する局面を複合技術から学ぶ/文法と学習の固定.json'
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == '86fa33f1e1111ddc2665e1cb6c68c7b4dae5dfc61feff0132ef144064966891a'
    return json.loads(raw)


def test_derive(book):
    """機能: 売買射影・必要分母・未知比較の境界を確認する。

    引数: book(dict)。返り値: None。
    """
    raw = {'m1.atr14': 10, 'm5.atr14': 20, 'm15.atr14': 40, 'm30.atr14': 80,
           'm1.close': 105, 'm1.ema8': 100, 'm1.prior_high5': 110, 'm1.prior_low5': 90,
           'm1.rsi14': 60, 'm1.body': 5, 'm1.cmf20': .1, 'm1.di_difference': 10,
           'm1.bb_width': 20, 'm1.previous_bb_width': 10}
    row = {'side': 1, 'values': raw, 'entry': {'time': 0}, 'gate': {'time': 120}}
    x = derive(row)
    assert x['close_ema8_atr1'] == .5 and x['forward5_atr1'] == -.5 and x['opposite5_atr1'] == 1.5
    assert x['bb_width_ratio'] == 2 and x['elapsed_minutes'] == 2 and x['rsi_signed'] == 10
    # ----------------------------------------
    # 同じ物理価格での売りはprior low/highを交換し、単純全列negateにしない。
    row['side'] = -1
    sell = derive(row)
    assert sell['forward5_atr1'] == -1.5 and sell['opposite5_atr1'] == .5
    row['values']['m1.atr14'] = 0
    assert derive(row)['forward5_atr1'] is None
    row['gate'] = None
    row['values'] = None
    assert all(v is None for v in derive(row).values())
    atom = next(p for p in predicates(book) if p['op'] == '>=' and p['threshold'] == 0)
    assert not holds({atom['feature']: None}, atom)
    assert not holds({atom['feature']: None}, dict(atom, op='<'))
    assert holds({atom['feature']: 0}, atom)


def test_time():
    """機能: cutoff等号・当場・未知教師をfit前に除く。

    引数: なし。返り値: None。
    """
    rows = [{'case_id': str(i), 'session_index': s, 'known_at': t, 'eligible': e, 'net': n}
            for i, (s, t, e, n) in enumerate([(0, 99, True, [0, 1, 2]),
                (0, 100, True, [0, 1, 2]), (1, 1, True, [0, 1, 2]),
                (0, None, False, [None]*3), (0, 99, False, [0, 1, 2])])]
    before = deepcopy(rows)
    assert [r['case_id'] for r in past_teachers(rows, 0, 1, 100)] == ['0']
    assert rows == before


def test_score(book):
    """機能: 全eligible分母・最良場除去・負寄与追加罰を手計算する。

    引数: book(dict)。返り値: dict型のモデル。
    """
    features = {r['name']: 0 for r in book['特徴']}
    unknown = {r['name']: None for r in book['特徴']}
    teachers = []
    for scene in range(6):
        for k in range(3):
            teachers.append({'case_id': f'{scene}/{k}', 'session_index': scene,
                             'features': features if k < 2 else unknown,
                             'net': [0, 9 if k < 2 else 1000, -3],
                             'eligible': True, 'known_at': 10})
    model = fit_oracle(teachers, book)
    rule = model['selected_rule']
    assert rule['action'] == 'C1' and rule['score'] == 30
    assert rule['matched_teachers'] == 12 and rule['matched_scenes'] == 6
    assert model['scene_denominators'] == {i: 3 for i in range(6)}
    assert model['candidate_rules'] == 12464
    for t in teachers:
        if t['session_index'] == 5 and t['features'] is features:
            t['net'][1] = -3
    assert fit_oracle(teachers, book)['selected_rule']['score'] == 21
    return model, features


def test_apply(model, features):
    """機能: 未学習・gate無し・未知時のIFDとlabel無し適用を確認する。

    引数: model/features(dict)。返り値: None。
    """
    assert apply_oracle(None, features, True) == 'C0'
    assert apply_oracle(model, features, False) == 'C0'
    assert apply_oracle(model, features, True) == 'C1'
    x = deepcopy(features)
    x[model['selected_rule']['predicates'][0]['feature']] = None
    assert apply_oracle(model, x, True) == 'C0'


def test_stream():
    """機能: 大きい一場・escape・後置metadata・全CRCを確認する。

    引数: なし。返り値: None。
    """
    value = {'success': True, 'trial': 159, 'catalog': ['人工'],
             'scenes': [{'session': '人工場', '文字列': ('日本語{["\\"]}'*40000),
                         'rows': [{'a': None, 'b': [1, 2, {'c': '}'}]}]}],
             'case_count': 837, 'rows': 1674, 'labels_used': False}
    raw = (json.dumps(value, ensure_ascii=False)+'\n').encode('utf-8')
    with tempfile.TemporaryDirectory(prefix='159読取人工_') as folder:
        path = Path(folder)/'人工.json.gz'
        with gzip.GzipFile(filename=str(path), mode='wb', mtime=0) as f:
            f.write(raw)
        evidence = {}
        assert list(scenes(path, evidence)) == value['scenes']
        assert evidence['header']['case_count'] == 837 and evidence['header']['rows'] == 1674
        assert evidence['header']['labels_used'] is False
        assert evidence['decoded_sha256'] == hashlib.sha256(raw).hexdigest()
        broken = bytearray(path.read_bytes())
        broken[-8] ^= 1
        path.write_bytes(broken)
        try:
            list(scenes(path, {}))
        except OSError:
            return
        raise AssertionError('CRC改変を受理した')


def test_model_slots(book):
    """機能: 未知教師だけでも9枠/6訓練を保持し自己SHAと暖機を分ける。

    引数: book(dict)。返り値: None。
    """
    scene_rows = [{'start': i*1000} for i in range(73)]
    teachers = [{'case_id': str(i), 'session_index': i % 73, 'known_at': None,
                 'eligible': False, 'net': [None]*3} for i in range(837)]
    report = {'success': True, 'trial': 159, 'schema': 'walkforward_models159_v1',
              'model_slots': 9, 'unique_training_windows': 6, 'minimum_score': 1e-9,
              'dictionary': book['特徴'], 'predicate_dictionary_sha256': canonical(predicates(book)),
              'teacher_total': 837, 'eligible_teachers': 0, 'unknown_or_non_gate_teachers': 837, 'models': {}}
    for setting in book['policies']:
        items = []
        for first, last in setting['blocks']:
            start = max(0, first-36) if setting['id'] == 'G03_WIN36' else 0
            base = {'schema': 'rule_model159_v1', 'dictionary_sha256': canonical(predicates(book)),
                    'training_start_index': start, 'training_end_exclusive': first,
                    'cutoff': scene_rows[first]['start'], 'teacher_count': 0, 'teacher_scenes': 0,
                    'teacher_case_ids': [], 'maturity_max': None, 'scene_denominators': {},
                    'predicate_count': 124, 'candidate_pairs': 6232, 'candidate_rules': 12464,
                    'support_qualified_rules': 0, 'positive_score_rules': 0, 'selected_rule': None, 'top10': []}
            items.append({**base, 'model_id': canonical(base), 'policy': setting['id'],
                          'application_start_index': first, 'application_end_exclusive': last})
        report['models'][setting['id']] = items
    slots, _ = model_checks(report, teachers, scene_rows, book)
    assert len(slots) == 9 and len({v[0]['model_id'] for v in slots.values()}) == 6


def main() -> None:
    """機能: 固定bookと人工だけで4群を実行する。

    引数: なし。返り値: None。自然snapshot・教師・modelは読まない。
    """
    book = fixture_book()
    test_derive(book)
    test_time()
    model, features = test_score(book)
    test_apply(model, features)
    test_stream()
    test_model_slots(book)
    print(json.dumps({'成功': True, '人工': 6, '全規則': model['candidate_rules'],
                      '自然読取': False, '作者関数import': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
