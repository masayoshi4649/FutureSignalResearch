"""機能: 同じ自然出力を検査する前のschema停止だけを小さく履歴保存する。"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import zipfile


def main() -> None:
    """機能: 補修前checkerと準備票を一度退避する。

    引数: なし。返り値: None。Source・自然出力・oracle算術は変更しない。
    """
    here = Path(__file__).parent
    target = here/'検査器のschema追補前.zip'
    assert not target.exists()
    names = ['確認する.py', '準備の確認.json', '準備の停止.json']
    hashes = {name: hashlib.sha256((here/name).read_bytes()).hexdigest() for name in names}
    with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name in names:
            z.writestr(name, (here/name).read_bytes())
    record = {'成功': False, '試行': 159, '終了handle': 23555, '終了値': 1,
              '確認UTC': datetime.now(timezone.utc).isoformat(),
              '停止段階': '入力73場/837物理・全6訓練範囲の全規則winner/top10/score/成熟一致後、最初のchoice schema比較',
              '理由': 'model_has_ruleとreason細分化が私有期待に未対応',
              'Root確認': '最終作者*.pyは学習前固定SHA30c852055d59b0337cc2b21ff8f617eba83d906022e9440e2af0aa66854ded45へ固定済み',
              '修正範囲': 'checkerの説明metadataだけ。作者Source/保存結果/独自oracle計算不変更',
              '自然再生成': False, '履歴ZIP_SHA256': hashlib.sha256(target.read_bytes()).hexdigest(),
              '履歴源': hashes}
    (here/'初回schema停止.json').write_text(json.dumps(record, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(record, ensure_ascii=False))


if __name__ == '__main__':
    main()
