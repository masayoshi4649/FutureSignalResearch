"""機能: 159独立確認の小源と履歴だけを恒久ZIPへ保存する。"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import platform
import shutil
import subprocess
import sys
import zipfile
import zlib

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
FORMAL = ROOT/'study/00159_延伸する局面を複合技術から学ぶ'


def sha(path: Path) -> str:
    """機能: 小源・ZIP・小票の物理SHAを求める。

    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """機能: 両正式copy・全entry・復元人工を確認して編集停止する。

    引数: なし。返り値: None。自然学習・金融・大入力の再読はしない。
    """
    target = FORMAL/'再現資料/独立確認コード.zip'
    ticket = FORMAL/'検査/独立確認コードの保存確認.json'
    stop_path = HERE/'停止の確認.json'
    assert not target.exists() and not ticket.exists() and not stop_path.exists()
    success = HERE/'自然確認/独立確認.json'
    table = HERE/'総合表確認/確認.json'
    assert sha(success) == '66b78281fb135966f0b4f482af2ec255296ee5517df59b879638510becca2bfa'
    assert sha(table) == '1d15ee8213d982a33dbab33f98936c5b5d75e1697e73f9f7889b7eae2b3fc8af'
    copies = {}
    for path, origin in ((FORMAL/'検査/モデルと選択と合成の独立確認.json', success),
                         (FORMAL/'検査/総合三表の独立確認.json', table)):
        assert path.is_file() and path.read_bytes() == origin.read_bytes()
        copies[path.relative_to(ROOT).as_posix()] = sha(path)
    f0 = FORMAL/'検査/学習前固定.json'
    assert sha(f0) == '30c852055d59b0337cc2b21ff8f617eba83d906022e9440e2af0aa66854ded45'
    frozen = json.loads(f0.read_bytes())
    for name, expected in frozen['ソース'].items():
        assert sha(ROOT/name) == expected
    main_proof = json.loads(success.read_bytes())
    assert sha(HERE/'確認する.py') == main_proof['本コードSHA256']
    assert sha(HERE/'oracle159.py') == main_proof['oracleSHA256']
    # ----------------------------------------
    # 複写元の由来は正式158 ZIP、実行時の私有統計は今回ZIPに全同梱する。
    old_archive = ROOT/'study/00158_複合技術で出口の役割と局面を切り替える/再現資料/再現コード.zip'
    assert sha(old_archive) == '348f68f9e46dc8c4b206aa5bba194612e2ce88c26fb110ef38b455d59c555743'
    provenance = {'work/158結果の独立確認/確認する.py': 'e8fb9598609db74d0f12aebb6cc23f223e6f9a5360e7be894d3f38d3384e36ef',
                  'work/158結果の独立確認/別計算.py': '64973c6644b3db0e45dd2a5fced79b71795d82ba7e01aac07edc378d9cd991f3'}
    with zipfile.ZipFile(old_archive) as z:
        for name, expected in provenance.items():
            assert hashlib.sha256(z.read(name)).hexdigest() == expected
    author_archive = FORMAL/'再現資料/実行コード.zip'
    assert sha(author_archive) == '391bb50805a7c2ca7961c390399c77b15b62e2c9ff311583e4d5401aa5c54cec'
    authors = {}
    with zipfile.ZipFile(author_archive) as z:
        for name, expected in frozen['ソース'].items():
            name = Path(name).as_posix()
            data = z.read(name)
            assert hashlib.sha256(data).hexdigest() == expected
            authors[name] = expected
        assert 'work/159集計と閲覧/総合集計する.py' in z.namelist()
    selected = {}
    for p in HERE.rglob('*'):
        if not p.is_file() or '__pycache__' in p.parts:
            continue
        assert '復元確認' not in p.parts
        if p.suffix not in ('.py', '.md', '.json', '.zip'):
            continue
        assert p.stat().st_size < 512_000, p
        name = p.relative_to(ROOT).as_posix()
        assert '..' not in Path(name).parts
        selected[name] = p
    entries = {}
    for name, p in sorted(selected.items()):
        data = p.read_bytes()
        entries[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                         'crc32': f'{zlib.crc32(data):08x}'}
    manifest = {'試行': 159, '用途': '自然後の独立確認小源。事前F0へ遡及追加しない',
                '格納ファイル': entries, '依存': {'Python': platform.python_version(), 'NumPy': '不使用',
                    'Root集計関数': 'importしない', '作者計算関数': 'importしない'},
                '外部コード': {'作者Source_SHA検査用': {'path': author_archive.relative_to(ROOT).as_posix(),
                            'sha256': sha(author_archive), '復元entry': authors},
                    '複写器のみの由来': {'path': old_archive.relative_to(ROOT).as_posix(),
                            'sha256': sha(old_archive), 'entry': provenance},
                    '通常実行': '159内のreader/Oracle/Audit/Fractionを同梱。158私有work不要'},
                '正本': copies, '学習前固定SHA256': sha(f0),
                '境界': ['初回metadata schema停止を履歴ZIP/小票で保持し同入力へ再照合',
                         '全22三表508640データセル。CSVヘッダー込み508748はRoot別再読票',
                         '反実仮想は共通prefix3行動限定、任意戦略の接合ではない',
                         '大表/Raw/入力/特徴/親結果/モデル/choice/G結果の副本を格納しない']}
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, p in sorted(selected.items()):
            info = zipfile.ZipInfo(name, (2026, 11, 13, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, p.read_bytes())
        z.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2).encode('utf-8'))
    restored = HERE/'復元確認'
    assert not restored.exists()
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None and set(z.namelist()) == set(entries) | {'manifest.json'}
        for name, expected in entries.items():
            data = z.read(name)
            assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
            assert f'{zlib.crc32(data):08x}' == expected['crc32']
        z.extractall(restored)
    for name in entries:
        if name.endswith('.py'):
            compile((restored/name).read_bytes(), name, 'exec')
    # 作者Sourceは既存正式ZIPから選択復元し、重複ZIP保存しない。
    with zipfile.ZipFile(author_archive) as z:
        for name in authors:
            p = restored/name
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(z.read(name))
    for name in ('文法と学習の固定.json', '実行条件.md'):
        src = FORMAL/name
        dst = restored/src.relative_to(ROOT)
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)
    checkers = [restored/'work/159独立確認/人工検査.py',
                restored/'work/159独立確認/確認する.py',
                restored/'work/159独立確認/総合表確認/確認する.py']
    logs = []
    for i, script in enumerate(checkers):
        command = [sys.executable, '-X', 'utf8', str(script)] + ([] if i == 0 else ['--help'])
        result = subprocess.run(command, cwd=restored, capture_output=True)
        assert result.returncode == 0, result.stderr.decode('utf-8')
        logs.append({'command': command, 'exit_code': 0, 'stdout': result.stdout.decode('utf-8')})
    for name, p in selected.items():
        assert sha(p) == entries[name]['sha256'], name
    proof = {'成功': True, '試行': 159, 'ZIP': {'path': target.relative_to(ROOT).as_posix(),
                'sha256': sha(target), 'bytes': target.stat().st_size},
             '源数': len(entries), 'manifest込み': len(entries)+1, '全entry_SHA_bytes_CRC': True,
             '元源前後同体': True, '正式2票copy同体': copies, '学習前固定Source同体': True,
             '外部作者ZIP復元SHA': authors, 'Python全源構文': True, '復元人工とCLI': logs,
             '自然再実行': False, '金融再計算': False, '巨大副本': False,
             '総合表データセル': 508640, 'CSVヘッダー込み508748': 'Root別再読、今回の独立コードはCSV未読',
             '保存器SHA256': sha(Path(__file__)), '確認UTC': datetime.now(timezone.utc).isoformat()}
    ticket.write_text(json.dumps(proof, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    stop = {'成功': True, '試行': 159, '編集停止': True, '自然主票SHA256': sha(success),
            '総合三表票SHA256': sha(table), '保存票SHA256': sha(ticket), 'ZIP_SHA256': sha(target),
            '同一入力への検査再実行': True, 'Source/自然選択/学習再生成': False,
            '最小保存': '正式独立確認コード.zip＋正式2票＋保存確認票。workの大副本なし',
            '確認UTC': datetime.now(timezone.utc).isoformat()}
    stop_path.write_text(json.dumps(stop, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'成功': True, 'ZIP_SHA256': sha(target), '保存票SHA256': sha(ticket),
                      '停止SHA256': sha(stop_path), '源数': len(entries)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
