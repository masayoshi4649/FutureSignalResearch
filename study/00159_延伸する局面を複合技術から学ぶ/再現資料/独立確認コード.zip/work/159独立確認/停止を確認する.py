"""機能: 作者最終源を再照合し自然前独立準備の停止票へ束縛する。"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json


def sha(path: Path) -> str:
    """機能: 小源・小票の物理SHAを求める。

    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """機能: 停止Sourceと準備票の同体を確認し小票を新規保存する。

    引数: なし。返り値: None。自然入力・学習結果は読まない。
    """
    here = Path(__file__).parent
    root = here.parents[1]
    target = here/'準備の停止.json'
    assert not target.exists()
    author = root/'work/159複合条件の延伸選択'
    assert sha(author/'準備の確認.json') == 'd8604f56d69a360ee42f4d16feb43021f3efc5fd0979e2df40bf6d3c5bd5acf5'
    assert sha(author/'停止.json') == '35a9de11e11d01e7a75dcb32e5d33648b6c92112dfed5dc0b22f99f434f7efb9'
    proof = json.loads((here/'準備の確認.json').read_bytes())
    for name, expected in proof['源'].items():
        assert sha(here/name) == expected
    for name, expected in proof['静的読取作者源'].items():
        assert sha(author/name) == expected
    files = [*proof['源'], '準備の確認.json', '停止を確認する.py']
    result = {'成功': True, '試行': 159, '段階': '自然前の静的レビューと独立checker準備',
              '編集停止': True, '確認UTC': datetime.now(timezone.utc).isoformat(),
              '自然本文読取': False, '作者関数import': False, '重大未解決': False,
              '準備SHA256': sha(here/'準備の確認.json'),
              '作者準備SHA256': sha(author/'準備の確認.json'), '作者停止SHA256': sha(author/'停止.json'),
              '最小保存対象': {name: sha(here/name) for name in files},
              '自然後': '同じcheckerで全規則/教師/モデル/choice/G24を別計算、Rootの結果SHA通知まで実行しない'}
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'成功': True, '停止SHA256': sha(target)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
