"""機能: 自然未読の独立159検査器を人工・構文・CLIへ束縛する。"""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import platform


def sha(path: Path) -> str:
    """機能: 小さいコード・固定bookの物理SHAを求める。

    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """機能: 私有人工だけを実行し準備票を新規保存する。

    引数: なし。返り値: None。
    """
    here = Path(__file__).parent
    target = here / '準備の確認.json'
    assert not target.exists()
    root = here.parents[1]
    names = ['oracle159.py', '入力を読む.py', '確認する.py', '人工検査.py', 'README.md', '準備を確認する.py']
    for name in names:
        if name.endswith('.py'):
            compile((here/name).read_bytes(), name, 'exec')
    test = subprocess.run([sys.executable, '-X', 'utf8', str(here/'人工検査.py')], capture_output=True)
    assert test.returncode == 0, test.stderr.decode('utf-8')
    lines = test.stdout.decode('utf-8').splitlines()
    assert json.loads(lines[-1])['人工'] == 6
    help_result = subprocess.run([sys.executable, str(here/'確認する.py'), '--help'], capture_output=True)
    rejected = subprocess.run([sys.executable, str(here/'確認する.py')], capture_output=True)
    assert help_result.returncode == 0 and rejected.returncode == 2
    authors = root/'work/159複合条件の延伸選択'
    proof = {'成功': True, '試行': 159, '状態': '自然前準備', '人工': 6,
             '自然snapshot本文読取': False, '自然モデル読取': False, '作者関数import': False,
             'Source編集': False, '構文': True, 'CLI_help': 0, '無指定拒否': 2,
             '人工stdout': test.stdout.decode('utf-8'),
             '依存': {'Python': platform.python_version(), '実行Python': sys.executable, 'NumPy': '不使用'},
             '源': {name: sha(here/name) for name in names},
             '静的読取作者源': {name: sha(authors/name) for name in ('data159.py', 'rules159.py', '実行する.py')},
             '固定specSHA256': '8899a5a1b378abd669ec9003ded19930c4e315879b76dc67517dd0b5e4e6bdb3',
             '固定bookSHA256': '86fa33f1e1111ddc2665e1cb6c68c7b4dae5dfc61feff0132ef144064966891a',
             '期待': {'全gate票': 1674, '物理case': 837, '全choice': 5022, 'G24結果': 20088,
                      '適用枠': 9, 'unique_fit': 6, '全規則検算': 74784},
             '自然実行': 'Root結果SHA通知後のみ、現段階は人工と静的レビュー'}
    target.write_text(json.dumps(proof, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'成功': True, '準備SHA256': sha(target)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
