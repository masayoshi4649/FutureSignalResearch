"""機能: 158親19政策と159G3政策の全三表を独立集約で確認する。"""
from pathlib import Path
from collections import defaultdict
from fractions import Fraction
import argparse
import itertools
import json
import sys

from 集計別算術 import Audit, POLICIES, Stats

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from 入力を読む import sha, scenes


def artificial() -> None:
    """機能: Gの親技術回数を0と誤記せず対象外nullにする境界を確認する。

    引数: なし。返り値: None。自然データは読まない。
    """
    assert len(POLICIES) == 22
    audit = Audit()
    audit.scenes = ['人工場']
    prefix = ('152U0', 'H60', 'D1', 'C5', 'G01_F48')
    row = {'status': 'closed', 'fill': {'time': 100}, 'profit_yen': 11423,
           'profit_points': 125, 'fee_yen': 1077, 'held_seconds': 10,
           'giveback_points': 0, 'armed': False, 'profit_after_positive_loss': False,
           'profit_after125_loss': False}
    for policy in ('G01_F48', 'F125S125', 'T125W100TP250'):
        audit.stats[(*prefix[:4], policy, '人工場')].add(row)
    audit.tech[(*prefix, '人工場')]['技術床変更した取得数'] = 99
    summary = audit.summary(prefix, '全73場')
    assert summary['取得数'] == 1 and summary['既知差引円'] == 11423
    for key in ('技術評価した取得数', '技術床変更した取得数', '技術退出要求回数',
                '利確要求回数', '不足特徴の種類数'):
        assert summary[key] is None


def main() -> None:
    """機能: 同じ保存結果だけから全22政策の三表を別算法で照合する。

    引数: CLI親/G/表のpathとSHA、output。返り値: None。Root集計はimportしない。
    """
    artificial()
    parser = argparse.ArgumentParser()
    for name in ('parent', 'gates', 'tables'):
        parser.add_argument('--'+name, type=Path, required=True)
        parser.add_argument('--'+name+'-sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    before = {}
    for name in ('parent', 'gates', 'tables'):
        path = getattr(args, name)
        expected = getattr(args, name+'_sha256')
        assert sha(path) == expected
        before[str(path.resolve())] = [expected, path.stat().st_size, path.stat().st_mtime_ns]
    assert args.parent_sha256 == '70a4c3178206bbb3c8641901c7515f2121da11c28403b88c3f8e6f93cc0baa6c'
    assert args.gates_sha256 == '40ffc8145918654b1d4ada0905bdd257a8ca732f23efeea808e74ac5c3fa60c3'
    old_evidence, new_evidence, audit = {}, {}, Audit()
    for parent, gates in itertools.zip_longest(scenes(args.parent, old_evidence), scenes(args.gates, new_evidence)):
        assert parent is not None and gates is not None
        for key in ('session', 'contract', 'start', 'end', 'force_close', 'continuous_end'):
            assert parent[key] == gates[key]
        new_cases = {c['id']: c for c in gates['cases']}
        assert len(new_cases) == len(gates['cases'])
        assert {c['id'] for c in parent['cases']} == set(new_cases)
        for case in parent['cases']:
            new = new_cases[case['id']]
            for key in ('id', 'original_side', 'side', 'stream', 'entry', 'entry_price', 'memberships'):
                assert case[key] == new[key]
            assert len(case['results']) == 152 and len(new['results']) == 24
            assert not any('technical_counts' in r or 'technical_trace' in r for r in new['results'])
            case['results'].extend(new['results'])
        audit.ingest(parent)
        print(json.dumps({'照合場': len(audit.scenes), '物理case': len(audit.physical)}, ensure_ascii=False), flush=True)
    assert old_evidence['header']['trial'] == 158 and new_evidence['header']['trial'] == 159
    assert len(audit.scenes) == 73 and len(audit.physical) == 837 and audit.states == 147312
    assert {base: len(items) for base, items in audit.members.items()} == {'153U15': 93, '152U0': 831}
    data = json.loads(args.tables.read_bytes())
    assert data['試行'] == 159
    compared = audit.compare_tables(data['tables'])
    for path, (expected, size, mtime) in before.items():
        p = Path(path)
        assert sha(p) == expected and (p.stat().st_size, p.stat().st_mtime_ns) == (size, mtime)
    for path, expected in data['sources'].items():
        assert sha(Path(path)) == expected
    here = Path(__file__).parent
    proof = {'成功': True, '試行': 159, '追加確認': '親19政策＋新G3政策の総合三表',
             'Root集計import': False, '作者算術import': False, '新学習': False,
             '全場': 73, '物理case': 837, '所属': 924, '政策数': 22, '全結果状態': audit.states,
             **compared, 'G技術回数': '親回数を加算せず全列null',
             '順位': '全22政策共通既知集合の前48IFD差順、同点はIFD/157追尾/他ID。後25は不交換',
             '検査': ['金額/件数/未知/null/同時刻DD', 'IFDと157追尾の2対応差/同体決済数',
                      '全73/前48/後25', '73場累計と未知後null', '全22共通既知順位', 'G対象外null'],
             '入力前後指紋': before, '小源': {p.name: sha(p) for p in here.glob('*.py')},
             '共用読取源SHA256': sha(here.parent/'入力を読む.py'),
             '親解凍SHA256': old_evidence['decoded_sha256'], 'G解凍SHA256': new_evidence['decoded_sha256'],
             '元159自然主票': '66b78281fb135966f0b4f482af2ec255296ee5517df59b879638510becca2bfa',
             '元158源/結果改変': False, '全件副本保存': False}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(proof, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'成功': True, 'SHA256': sha(args.output)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
