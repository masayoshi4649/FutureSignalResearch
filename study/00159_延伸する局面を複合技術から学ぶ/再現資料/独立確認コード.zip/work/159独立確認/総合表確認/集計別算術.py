"""158生結果・157対照・Root型付き集計を別計算で場単位に照合する。"""
from pathlib import Path
from collections import defaultdict
from fractions import Fraction
import argparse
import hashlib
import itertools
import json
import math
import sys

from 別計算 import Stats, number, equal, sha, stream_scenes, POLICIES as OLD_POLICIES

CONTROLS = {'F125S125', 'T125W100TP250', 'E0W125'}
TECHNICAL = (
    'CHAND_MOM', 'KASE_VAR', 'SUPER_CONFIRM', 'SAR_ACCEL', 'SWING_CONFIRM',
    'BB_CONTRACT', 'VOL_DIVERGE', 'VWAP_REVERT', 'SPIKE_CONFIRM',
    'PROGRESS_CLOCK', 'PROFIT_BUDGET', 'VOL_SHOCK', 'CUSUM_FAILURE',
    'PERSISTENT_CONSENSUS', 'EXTEND_PERMISSION', 'REGIME_SWITCH',
)
POLICIES = CONTROLS | {f'A{i:02d}_{name}' for i, name in enumerate(TECHNICAL, 1)} | {'G01_F48', 'G02_EXP12', 'G03_WIN36'}
SCOPES = ('全73場', '前48場', '後25場')
BASES = ('153U15', '152U0')
PAIR_NAMES = (
    'IFD利益総額円', 'IFD損失総額円', 'IFD既知差引円', 'IFD損益未知',
    'IFD対応既知件数', 'IFD対応損益未知', '対応既知IFD差分円',
    '対応利益総額差分円', '対応損失総額差分円', 'IFDより改善件数',
    'IFDより悪化件数', '対応既知改善場数', '対応既知悪化場数',
    '対応既知で実決済が同じ取得数', '対応既知で実決済が異なる取得数',
)
TECH_MAP = {
    'evaluations': ('技術評価した取得数', '技術評価回数'),
    'fallback_evaluations': ('特徴不足があった取得数', '特徴不足評価回数'),
    'floor_changes': ('技術床変更した取得数', '技術床変更回数'),
    'technical_requests': ('技術退出要求した取得数', '技術退出要求回数'),
}


def policy_tie(policy: str) -> tuple:
    """機能: 同点時だけ固定対照を先にする事前順序を返す。

    引数: policy(str)。返り値: tuple[int,str]。
    """
    return (0 if policy == 'F125S125' else 1 if policy == 'T125W100TP250' else 2, policy)


def stamp(q: dict) -> tuple:
    """機能: 同場の配送3時計を取り出す。

    引数: q(dict)。返り値: tuple[Fraction,int,int]。
    """
    assert type(q['index']) is int and q['index'] >= 0
    assert type(q['source_line']) is int and q['source_line'] > 0
    return number(q['time']), q['index'], q['source_line']


def quote(q: dict, normal: bool = True) -> None:
    """機能: 有限Quoteと正常BBOを検査する。

    引数: q(dict)、normal(bool)。返り値: None。
    """
    stamp(q)
    for key in ('last', 'bid', 'ask'):
        number(q[key])
    assert q['last'] > 0 and type(q['quote_ok']) is bool
    if normal:
        assert q['quote_ok'] and 0 < q['bid'] < q['ask']


def close_enough(a, b) -> None:
    """機能: 浮動小数の丸め差だけを許して算術を照合する。

    引数: a/b(数値)。返り値: None。
    """
    expected = b if isinstance(b, Fraction) else number(b)
    assert abs(number(a) - expected) <= Fraction(1, 1000000), (a, b)


def check_result(scene: dict, case: dict, row: dict) -> int:
    """機能: 実BBO算術・要求順序・期限・床の保存整合を検査する。

    引数: scene/case/row(dict)。返り値: int型の確認項目数。
    原テープの全gapや技術式そのものは本関数から再生しない。
    """
    e, side = case['entry'], case['side']
    quote(e)
    assert side in (-1, 1) and type(side) is int
    entry_price = number(case['entry_price'])
    assert entry_price == number(e['ask' if side == 1 else 'bid'])
    g0 = side * (number(e['bid' if side == 1 else 'ask']) - entry_price)
    close_enough(row['entry_mark_points'], g0)
    assert row['policy'] in POLICIES
    assert row['horizon'] in ('H60', 'SESSION')
    assert row['delay'] in ('D0', 'D1') and row['cost'] in ('C0', 'C5')
    assert row['config_id'] == '/'.join(row[k] for k in ('policy', 'horizon', 'delay', 'cost'))
    fee = 77 if row['cost'] == 'C0' else 1077
    assert row['fee_yen'] == fee
    deadline = number(scene['force_close'])
    if row['horizon'] == 'H60':
        deadline = min(deadline, number(e['time']) + 3600)
    assert number(row['deadline']) == deadline < number(scene['continuous_end'])
    assert number(row['peak_points']) >= 0
    assert number(row['trough_points']) <= min(0, g0)
    assert type(row['armed']) is bool
    if row['armed']:
        arm = row['arm_quote']
        quote(arm)
        ag = side * (number(arm['bid' if side == 1 else 'ask']) - entry_price)
        assert 100 * ag - fee > 0 and number(row['stop_points']) >= 0
    else:
        assert row['arm_quote'] is None
        if row['policy'].startswith('A'):
            assert row['stop_points'] == -125
    trigger = row['trigger']
    if trigger is not None:
        tt = number(trigger['time'])
        assert tt >= number(e['time'])
        if trigger['reason'] == 'deadline':
            assert tt == deadline and trigger['quote'] is None
        else:
            tq = trigger['quote']
            quote(tq)
            assert number(tq['time']) == tt < deadline
            assert tq['index'] > e['index'] and tq['source_line'] > e['source_line']
    assert row['status'] in ('closed', 'unknown')
    if row['status'] == 'unknown':
        assert row.get('unknown_reason') in {'phase_cut', 'accepted_gap', 'normal_bbo_gap', 'exit_ttl', 'eof'}
        for key in ('profit_points', 'profit_yen', 'fill', 'held_seconds', 'giveback_points',
                    'profit_after_positive_loss', 'profit_after125_loss'):
            assert row[key] is None, key
    else:
        fill = row['fill']
        quote(fill)
        assert trigger is not None
        ft, fi, fl = stamp(fill)
        assert ft < number(scene['continuous_end'])
        assert fi > e['index'] and fl > e['source_line']
        assert 0 <= ft - number(trigger['time']) <= 30
        if row['delay'] == 'D1':
            assert ft - number(trigger['time']) >= 1
            if trigger['quote'] is not None:
                assert fi > trigger['quote']['index'] and fl > trigger['quote']['source_line']
        gross = side * (number(fill['bid' if side == 1 else 'ask']) - entry_price)
        close_enough(row['profit_points'], gross)
        close_enough(row['profit_yen'], 100 * gross - fee)
        close_enough(row['held_seconds'], ft - number(e['time']))
        close_enough(row['giveback_points'], number(row['peak_points']) - gross)
        assert number(row['trough_points']) <= gross <= number(row['peak_points'])
        assert row['profit_after_positive_loss'] == (row['positive_seen'] and row['profit_yen'] < 0)
        assert row['profit_after125_loss'] == (row['reached125'] and row['profit_yen'] < 0)
    previous_floor = Fraction(-125)
    for item in row.get('technical_trace') or []:
        at = stamp(item['at'])
        assert at[0] >= number(e['time'])
        assert at[1] > e['index'] and at[2] > e['source_line']
        assert number(item['previous_floor']) >= previous_floor
        assert number(item['applied_floor']) >= number(item['previous_floor'])
        previous_floor = number(item['applied_floor'])
        fa = item['feature_at']
        assert number(fa['time']) <= at[0] and fa['index'] <= at[1] and fa['source_line'] <= at[2]
    counts = row.get('technical_counts') or {}
    for name in ('evaluations', 'fallback_evaluations', 'floor_changes', 'arm_starts',
                 'technical_requests', 'take_profit_requests'):
        assert type(counts.get(name, 0)) is int and counts.get(name, 0) >= 0
    for name in ('fallback_evaluations', 'floor_changes', 'technical_requests', 'take_profit_requests'):
        assert counts.get(name, 0) <= counts.get('evaluations', 0)
    return 30


def old_projection(actual, expected, where=()) -> int:
    """機能: 157の全既存keyを再帰的に完全比較する。

    引数: actual/expected(JSON値)、where(tuple)。返り値: int型の比較末端数。
    """
    if isinstance(expected, dict):
        assert isinstance(actual, dict) and set(expected) <= set(actual), where
        return sum(old_projection(actual[k], v, (*where, k)) for k, v in expected.items())
    if isinstance(expected, list):
        assert isinstance(actual, list) and len(actual) == len(expected), where
        return sum(old_projection(a, b, (*where, i)) for i, (a, b) in enumerate(zip(actual, expected, strict=True)))
    assert type(actual) is type(expected) and actual == expected, (where, actual, expected)
    return 1


class Audit:
    """機能: 一場ずつ独立統計と公平な共通既知順位を蓄積する。"""

    def __init__(self):
        """機能: 小さい集計器を初期化する。

        引数: なし。返り値: None。
        """
        self.scenes, self.physical, self.members = [], set(), defaultdict(set)
        self.stats, self.pairs = defaultdict(Stats), defaultdict(lambda: defaultdict(Fraction))
        self.tech, self.missing = defaultdict(lambda: defaultdict(int)), defaultdict(set)
        self.common_n, self.common_delta = defaultdict(int), defaultdict(Fraction)
        self.states = self.control_states = self.old_leaves = self.checks = 0

    def ingest(self, scene: dict, baseline: dict | None = None) -> None:
        """機能: 生結果の一場を読み対照と集約を照合する。

        引数: scene(dict)、baseline(dict又はNone)。返り値: None。
        """
        session = scene['session']
        assert session not in self.scenes
        fold = '前48場' if len(self.scenes) < 48 else '後25場'
        self.scenes.append(session)
        old_cases = {} if baseline is None else {c['id']: c for c in baseline['cases']}
        if baseline is not None:
            for key in ('session', 'contract', 'start', 'end', 'force_close', 'continuous_end'):
                assert scene[key] == baseline[key]
            assert {c['id'] for c in scene['cases']} == set(old_cases)
        for case in scene['cases']:
            identity = (session, case['id'])
            assert identity not in self.physical
            self.physical.add(identity)
            rows = {r['config_id']: r for r in case['results']}
            assert len(rows) == len(case['results']) == 176
            assert {r['policy'] for r in rows.values()} == POLICIES
            bases = [m['policy'] for m in case['memberships']]
            assert bases and len(bases) == len(set(bases)) and set(bases) <= set(BASES)
            if baseline is not None:
                old = old_cases[case['id']]
                for key in ('id', 'original_side', 'side', 'stream', 'entry', 'entry_price', 'memberships'):
                    self.old_leaves += old_projection(case[key], old[key], (session, case['id'], key))
                for r in old['results']:
                    if r['policy'] in CONTROLS:
                        self.old_leaves += old_projection(rows[r['config_id']], r, (session, case['id'], r['config_id']))
                        self.control_states += 1
            for row in rows.values():
                self.checks += check_result(scene, case, row)
                self.states += 1
            primary = [rows[f'{p}/H60/D1/C5'] for p in POLICIES]
            if all(r['status'] == 'closed' for r in primary):
                bmoney = number(rows['F125S125/H60/D1/C5']['profit_yen'])
                for base in bases:
                    for scope in ('全73場', fold):
                        self.common_n[base, scope] += 1
                        for r in primary:
                            self.common_delta[base, scope, r['policy']] += number(r['profit_yen']) - bmoney
            for base in bases:
                self.members[base].add(identity)
                for row in rows.values():
                    group = (base, row['horizon'], row['delay'], row['cost'], row['policy'], session)
                    self.stats[group].add(row)
                    counts = row.get('technical_counts') or {}
                    for name, (count_name, sum_name) in TECH_MAP.items():
                        self.tech[group][count_name] += counts.get(name, 0) > 0
                        self.tech[group][sum_name] += counts.get(name, 0)
                    self.tech[group]['利確要求回数'] += counts.get('take_profit_requests', 0)
                    self.missing[group].update((counts.get('missing_features') or {}).keys())
                    for control in ('F125S125', 'T125W100TP250'):
                        b = rows[f'{control}/{row["horizon"]}/{row["delay"]}/{row["cost"]}']
                        if row['status'] == b['status'] == 'closed':
                            a_money, b_money = number(row['profit_yen']), number(b['profit_yen'])
                            pair = self.pairs[(*group, control)]
                            pair['IFD対応既知件数'] += 1
                            pair['対応既知IFD差分円'] += a_money - b_money
                            pair['対応利益総額差分円'] += max(a_money, 0) - max(b_money, 0)
                            pair['対応損失総額差分円'] += max(-a_money, 0) - max(-b_money, 0)
                            pair['IFDより改善件数'] += a_money > b_money
                            pair['IFDより悪化件数'] += a_money < b_money
                            same = row['fill'] == b['fill'] and row['profit_yen'] == b['profit_yen']
                            pair['対応既知で実決済が同じ取得数'] += same
                            pair['対応既知で実決済が異なる取得数'] += not same

    def sessions(self, scope: str) -> list:
        """機能: 元場順の固定区間を返す。

        引数: scope(str)。返り値: list[str]。
        """
        assert scope in SCOPES
        return self.scenes if scope == '全73場' else self.scenes[:48] if scope == '前48場' else self.scenes[48:]

    def summary(self, prefix: tuple, scope: str) -> dict:
        """機能: 一区間の基本・二対照・技術集計を求める。

        引数: prefix(tuple)、scope(str)。返り値: dict。
        """
        total, counters, missing = Stats(), defaultdict(int), set()
        for session in self.sessions(scope):
            group = (*prefix, session)
            total.merge(self.stats[group])
            for k, v in self.tech[group].items():
                counters[k] += v
            missing.update(self.missing[group])
        result = total.values()
        for control, label in (('F125S125', ''), ('T125W100TP250', '157対照_')):
            baseline, pairs = Stats(), defaultdict(Fraction)
            good = bad = 0
            for session in self.sessions(scope):
                baseline.merge(self.stats[(*prefix[:4], control, session)])
                item = self.pairs[(*prefix, session, control)]
                for k, v in item.items():
                    pairs[k] += v
                good += item['対応既知IFD差分円'] > 0
                bad += item['対応既知IFD差分円'] < 0
            values = {k: pairs[k] for k in PAIR_NAMES}
            values.update({'IFD利益総額円': baseline.profit, 'IFD損失総額円': baseline.loss,
                           'IFD既知差引円': baseline.profit - baseline.loss, 'IFD損益未知': baseline.unknown,
                           'IFD対応損益未知': total.n - pairs['IFD対応既知件数'],
                           '対応既知改善場数': good, '対応既知悪化場数': bad})
            result.update({label + k: v for k, v in values.items()})
        for count_name, sum_name in TECH_MAP.values():
            result[count_name], result[sum_name] = counters[count_name], counters[sum_name]
        result['不足特徴の種類数'] = len(missing)
        result['利確要求回数'] = counters['利確要求回数']
        if prefix[4].startswith('G0') and total.n:
            for a, b in TECH_MAP.values():
                result[a] = result[b] = None
            result['不足特徴の種類数'] = result['利確要求回数'] = None
        return result

    def compare_tables(self, tables: dict, strict: bool = True) -> dict:
        """機能: Root三表の全セルを独立再構成し照合する。

        引数: tables(dict)、strict(bool)。返り値: dict型の比較件数。
        """
        assert set(tables) == {'総合比較', '全セッション', '研究順位と発動'}
        cells = numeric = 0
        expected_rows = {'総合比較': 1056, '全セッション': 25696, '研究順位と発動': 44}
        for name, table in tables.items():
            headers = table['headers']
            assert len(headers) == len(set(headers))
            if strict:
                assert len(table['rows']) == expected_rows[name]
            seen, cumulative, unknown = set(), defaultdict(Fraction), defaultdict(int)
            session_position = defaultdict(int)
            ranking = {}
            if name == '研究順位と発動':
                for base in BASES:
                    ranking[base] = sorted(POLICIES, key=lambda p: (-self.common_delta[base, '前48場', p], *policy_tie(p)))
            for row in table['rows']:
                assert len(row) == len(headers)
                actual = dict(zip(headers, row, strict=True))
                if name == '研究順位と発動':
                    base, rank, policy = (actual[k] for k in headers[:3])
                    assert base in BASES and ranking[base][rank - 1] == policy
                    expected = {}
                    for scope in ('前48場', '後25場', '全73場'):
                        expected[scope + '_全22政策共通既知数'] = self.common_n[base, scope]
                        expected[scope + '_共通既知IFD差分円'] = self.common_delta[base, scope, policy]
                        summary = self.summary((base, 'H60', 'D1', 'C5', policy), scope)
                        for k in ('既知差引円', '対応既知IFD差分円', 'IFD対応既知件数', 'IFD対応損益未知'):
                            expected[scope + '_' + k] = summary[k]
                    whole = self.summary((base, 'H60', 'D1', 'C5', policy), '全73場')
                    for out, source in (('全期技術床変更の取得数', '技術床変更した取得数'),
                                        ('全期技術退出要求の取得数', '技術退出要求した取得数'),
                                        ('全期特徴不足の取得数', '特徴不足があった取得数')):
                        expected[out] = whole[source]
                    identity = (base, policy)
                    offset = 3
                else:
                    prefix = tuple(actual[k] for k in ('入口', '保有期限', '約定代用', '費用', '出口'))
                    offset = 6
                    if name == '総合比較':
                        scope = actual['区間']
                        expected = self.summary(prefix, scope)
                        identity = (*prefix, scope)
                    else:
                        session = actual['セッション']
                        identity = (*prefix, session)
                        assert session == self.scenes[session_position[prefix]]
                        session_position[prefix] += 1
                        item = self.stats[identity]
                        cumulative[prefix] += item.profit - item.loss
                        unknown[prefix] += item.unknown
                        expected = {k: v for k, v in item.values().items() if k in headers}
                        expected.update({'累計既知差引円': cumulative[prefix], '累計損益未知': unknown[prefix],
                                         '全件確定累計円': None if unknown[prefix] else cumulative[prefix]})
                assert identity not in seen
                seen.add(identity)
                assert set(expected) == set(headers[offset:]), (name, set(expected) ^ set(headers[offset:]))
                for k, value in expected.items():
                    equal(value, actual[k], (name, identity, k))
                    numeric += value is not None
                cells += len(headers)
        return {'全セル': cells, '数値null以外': numeric, '表行数': {k: len(v['rows']) for k, v in tables.items()}}


