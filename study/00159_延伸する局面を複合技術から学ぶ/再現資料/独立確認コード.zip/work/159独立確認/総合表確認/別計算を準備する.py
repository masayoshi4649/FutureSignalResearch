"""機能: 成功済み158独立集計を22政策へ私有適応する。"""
from pathlib import Path
import hashlib


def main() -> None:
    """機能: 元源を変えず統計・比較コードだけを新folderへ複写する。

    引数: なし。返り値: None。データ・Root集計関数は読まない。
    """
    here = Path(__file__).parent
    root = here.parents[2]
    old = root/'work/158結果の独立確認'
    source = (old/'確認する.py').read_text(encoding='utf-8').split('\ndef check_small_refs', 1)[0]
    source = source.replace("POLICIES = CONTROLS | {f'A{i:02d}_{name}' for i, name in enumerate(TECHNICAL, 1)}",
        "POLICIES = CONTROLS | {f'A{i:02d}_{name}' for i, name in enumerate(TECHNICAL, 1)} | {'G01_F48', 'G02_EXP12', 'G03_WIN36'}")
    source = source.replace('== 152', '== 176').replace('全19政策共通既知数', '全22政策共通既知数')
    source = source.replace("'出口比較'", "'総合比較'")
    source = source.replace("'総合比較': 912, '全セッション': 22192, '研究順位と発動': 38",
                            "'総合比較': 1056, '全セッション': 25696, '研究順位と発動': 44")
    needle = "        result['利確要求回数'] = counters['利確要求回数']\n        return result"
    replacement = """        result['利確要求回数'] = counters['利確要求回数']
        if prefix[4].startswith('G0') and total.n:
            for a, b in TECH_MAP.values():
                result[a] = result[b] = None
            result['不足特徴の種類数'] = result['利確要求回数'] = None
        return result"""
    assert needle in source
    source = source.replace(needle, replacement)
    target = here/'集計別算術.py'
    assert not target.exists() and not (here/'別計算.py').exists()
    target.write_text(source+'\n', encoding='utf-8')
    (here/'別計算.py').write_bytes((old/'別計算.py').read_bytes())
    print(hashlib.sha256((old/'確認する.py').read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
