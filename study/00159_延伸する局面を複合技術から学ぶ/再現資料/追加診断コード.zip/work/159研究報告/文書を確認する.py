"""今回の正式Markdownのリンク、表の尺度数、条件指紋を確認する。"""
from pathlib import Path
from urllib.parse import unquote
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[2]


def main() -> None:
    """
    機能: 今回作成・更新した文書と固定条件の保存整合を検査する。
    引数: なし。返り値: None。金融再生や学習は行わない。
    """
    files = [ROOT/'AGENTS.md',ROOT/'docs/README.md',ROOT/'docs/議論/README.md',ROOT/'study/README.md',
             ROOT/'docs/議論/出口の複合条件と利益保護を分ける.md',ROOT/'inputs/00159_延伸判断の特徴/README.md']
    for trial in (158,159):
        folder = next((ROOT/'study').glob(f'{trial:05d}_*'))
        files.extend(folder.glob('*.md'))
        files.extend((folder/'再現資料').glob('*.md'))
        body=(folder/'設定と結果.md').read_text(encoding='utf-8')
        ids=[]
        for line in body.splitlines():
            cells=[c.strip() for c in line.strip().strip('|').split('|')]
            if len(cells)==11 and re.fullmatch(r'[A-Z]\d\d',cells[0]):
                ids.append(cells[0])
        assert len(ids)==len(set(ids))==63,(trial,len(ids))
        assert '自然教師の学習は未実行' not in body
        assert '| R01 | 未設定 |' not in body
    missing=[]; count=0
    for p in files:
        body=p.read_text(encoding='utf-8')
        for link in re.findall(r'\]\(([^)]+)\)',body):
            link=link.strip('<>').split('#')[0]
            if not link or re.match(r'^[a-zA-Z]+:',link):
                continue
            target=(p.parent/unquote(link)).resolve()
            count+=1
            if not target.exists():missing.append([str(p.relative_to(ROOT)),link])
    assert not missing,missing
    output=next((ROOT/'study').glob('00159_*'))/'検査/文書と目次の確認.json'
    assert not output.exists()
    proof={'成功':True,'試行':159,'確認したMarkdown数':len(files),'実在ローカルリンク数':count,
           '設定表':{'158':{'手法数':63,'尺度数':9,'セル数':567},'159':{'手法数':63,'尺度数':9,'セル数':567}},
           '対象文書':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
           '検査器SHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           '金融再生':False,'学習再実行':False}
    output.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'文書':len(files),'リンク':count},ensure_ascii=False))


if __name__ == '__main__':
    main()
