"""159の固定モデル・採否・保存損益を読み、再学習せず解釈する。"""
from __future__ import annotations

from collections import Counter, defaultdict
import copy
import hashlib
import itertools
import json
import math
from pathlib import Path
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
SOURCE = ROOT / "work/159複合条件の延伸選択"
sys.path.insert(0, str(SOURCE))
import data159 as data
import rules159 as rules
import numpy as np

FORMAL = ROOT / "study/00159_延伸する局面を複合技術から学ぶ/成果物"
POLICIES = ("G01_F48", "G02_EXP12", "G03_WIN36")
COHORTS = ("153U15", "152U0", "物理全体")
PARTS = {"all": (0, 73), "train": (0, 48), "validation": (48, 73)}


def sha(path: Path) -> str:
    """小さい源のSHAを取得する。

    引数: path (Path)。返り値: str 型。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def known(result: dict) -> bool:
    """保存損益が確定しているか確認する。

    引数: result (dict) 既存出口結果。
    返り値: bool 型。未知を0円へ補わない。
    """
    return result["status"] == "closed" and data.finite_number(result.get("profit_yen"))


def metrics(rows: list[dict]) -> dict:
    """既知利益・損失・未知と分母を集計する。

    引数: rows (list[dict]) 固定取得の結果。
    返り値: dict 型。実退出の利益率を入口先着率とは呼ばない。
    """
    values = [row["profit_yen"] for row in rows if known(row)]
    profit = sum(max(value, 0) for value in values)
    loss = sum(max(-value, 0) for value in values)
    return {"n": len(rows), "known": len(values), "unknown": len(rows)-len(values), "profit_trades": sum(value > 0 for value in values), "loss_trades": sum(value < 0 for value in values), "profit_yen": profit, "loss_yen": loss, "known_net_yen": profit-loss, "confirmed_total_yen": profit-loss if len(values)==len(rows) else None}


def paired(left: dict, right: dict, ids: list[str], cases: dict) -> dict:
    """双方既知の同一取得だけで左−右を計算する。

    引数: left/right (dict) case→結果、ids (list[str])、cases (dict) metadata。
    返り値: dict 型。異なる未知集合の総額差を対応差にしない。
    """
    diffs = [(case_id,left[case_id]["profit_yen"]-right[case_id]["profit_yen"]) for case_id in ids if known(left[case_id]) and known(right[case_id])]
    scenes = defaultdict(float)
    counts = Counter()
    for case_id,value in diffs:
        scenes[cases[case_id]["session"]]+=value
        counts[cases[case_id]["session"]]+=1
    details=[{"session":name,"pairs":counts[name],"difference_yen":value} for name,value in scenes.items()]
    return {"n": len(ids), "both_known": len(diffs), "unknown_pair": len(ids)-len(diffs), "difference_yen": sum(value for _,value in diffs), "improved": sum(value>0 for _,value in diffs), "worse": sum(value<0 for _,value in diffs), "equal": sum(value==0 for _,value in diffs), "positive_difference_yen": sum(max(value,0) for _,value in diffs), "negative_difference_yen": sum(max(-value,0) for _,value in diffs), "improved_scenes": sum(value>0 for value in scenes.values()), "worse_scenes": sum(value<0 for value in scenes.values()), "top_improved_scenes":sorted([row for row in details if row["difference_yen"]>0],key=lambda row:row["difference_yen"],reverse=True)[:3],"top_worse_scenes":sorted([row for row in details if row["difference_yen"]<0],key=lambda row:row["difference_yen"])[:3]}


def compact_report(value:dict)->dict:
    """正式保存用に主条件の群別・区画別数値だけを射影する。

    引数: value (dict) work限定の詳細集計。
    返り値: dict 型。全取引・全モデル・反復場明細を転記しない。
    """
    pair_keys=("n","both_known","unknown_pair","difference_yen","improved","worse","equal")
    tables=[]
    for cohort in ("153U15","152U0"):
        for part in PARTS:
            for policy in POLICIES:
                row=value["summary"][policy][cohort][part]["H60"]
                tables.append({"cohort":cohort,"part":part,"policy":policy,"counts":row["counts"],"metrics":row["metrics"],"vs_IFD":{key:row["vs_ifd"][key] for key in pair_keys},"vs_C1":{key:row["vs_always_C1"][key] for key in pair_keys},"C1_minus_IFD_by_group":{group:{key:stats["C1_vs_ifd"][key] for key in pair_keys} for group,stats in row["groups"].items()}})
    periods=[]
    for policy,slots in value["model_slots"].items():
        for slot in slots:
            row=slot["cohorts"]["152U0"]
            periods.append({"policy":policy,"model_ref":slot["model_id"],"training_window":slot["train"],"application_window":slot["apply"],"teacher_count":slot["teacher_count"],"matched_teachers":slot["rule"]["matched_teachers"],"matched_scenes":slot["rule"]["matched_scenes"],"winner_margin_score":slot["winner_margin_score"],"physical_gate":slot["apply_physical_gates"],"physical_gate_predicate_unknown":slot["apply_gate_predicate_unknown"],"cohort_152_trades":row["trades"],"cohort_152_gate":row["gate"],"extensions":row["extensions"],"extension_scenes":row["extension_scenes"],"extension_top_scenes":row["extension_top_scenes"],"selected_vs_IFD":{key:row["selected_C1_vs_IFD"][key] for key in pair_keys},"default_C1_vs_IFD":{key:row["default_C1_vs_IFD"][key] for key in pair_keys}})
    return {"成功":True,"試行":159,"範囲":"H60/D1/C5、群別数値のみ、全件/全モデル転記なし","再学習":False,"新閾値探索":False,"教師総数":value["教師総数"],"教師既知":value["教師既知"],"モデル枠":9,"訓練窓":6,"異なるAND条件":5,"選択行動":value["選択行動"],"input_refs":{name:{key:ref[key] for key in ("path","sha256","decoded_sha256")} for name,ref in value["inputs"].items()},"main_tables":tables,"application_blocks":periods,"extension_overlap_H60":value["overlaps"]["H60"],"全モデル正本":"study/00159_延伸する局面を複合技術から学ぶ/成果物/モデルと学習報告.json","全選択正本":"study/00159_延伸する局面を複合技術から学ぶ/成果物/全gateの出口選択.json"}


def main() -> None:
    """保存5入力を固定し主条件の解釈集計だけを出す。

    引数: なし。
    返り値: None。再学習・新規閾値探索・Raw走査は行わない。
    """
    frozen_before={p.name:sha(p) for p in SOURCE.glob("*.py")}
    models,model_ref=data.read_ref(data.FileRef(FORMAL/"モデルと学習報告.json","ee00ddb5dee650c389bf98028e5836205b9ab848a09e982892ff1d8b63e2bfcf","ee00ddb5dee650c389bf98028e5836205b9ab848a09e982892ff1d8b63e2bfcf"))
    choices_object,choice_ref=data.read_ref(data.FileRef(FORMAL/"全gateの出口選択.json","496668980e3eed6094bc2ad310efac4f161c95e1a9d282b31ab3ec66c840d998","496668980e3eed6094bc2ad310efac4f161c95e1a9d282b31ab3ec66c840d998"))
    result,result_ref=data.read_ref(data.FileRef(FORMAL/"固定入口の出口合成.json.gz","40ffc8145918654b1d4ada0905bdd257a8ca732f23efeea808e74ac5c3fa60c3","c330177150038f5cfb412fd40e5ba45b3734293888f594cd6763f9303dfcbb5a"))
    parent,parent_ref=data.read_ref(data.FileRef(ROOT/"study/00158_複合技術で出口の役割と局面を切り替える/成果物/出口結果.json.gz","70a4c3178206bbb3c8641901c7515f2121da11c28403b88c3f8e6f93cc0baa6c","3c3df90244de838056ca7c98857ffe7b8f85514807e90194c07f73129ec277c7"))
    cases,_=data.action_index(parent);del parent
    snapshot,snapshot_ref=data.read_ref(data.FileRef(ROOT/"inputs/00159_延伸判断の特徴/判断時点の特徴.json.gz","b7be610367196246af4125cabc10ea46157d4068896d29c35d0939084b41a148","3ac97f2372c3c58b5c0e2584e0d72b27f08f3a50dec6c2cfcfe40e85db63fe7e"))
    gates=data.gate_dataset(snapshot);del snapshot
    derived=rules.derive(gates)
    choice={(row["policy"],row["case_id"],row["horizon"]):row for row in choices_object["rows"]}
    assert len(choice)==837*2*3
    new={}
    for scene in result["scenes"]:
        for case in scene["cases"]:
            for row in case["results"]:
                if row["delay"]=="D1" and row["cost"]=="C5":new[row["policy"],case["id"],row["horizon"]]=row
    scope=lambda cohort,first,last:[case_id for case_id,case in cases.items() if first<=case["session_index"]<last and (cohort=="物理全体" or any(member["policy"]==cohort for member in case["memberships"]))]
    base={horizon:{action:{case_id:case["results"][horizon,"D1","C5",action] for case_id,case in cases.items()} for action in data.ACTIONS} for horizon in data.HORIZONS}
    summary,slots,baselines={},{},{}
    for cohort in COHORTS:
        baselines[cohort]={}
        for part,(first,last) in PARTS.items():
            ids=scope(cohort,first,last);baselines[cohort][part]={}
            for horizon in data.HORIZONS:baselines[cohort][part][horizon]={action:metrics([values[case_id] for case_id in ids]) for action,values in base[horizon].items()}
    for policy in POLICIES:
        summary[policy]={}
        for cohort in COHORTS:
            summary[policy][cohort]={}
            for part,(first,last) in PARTS.items():
                ids=scope(cohort,first,last);summary[policy][cohort][part]={}
                for horizon in data.HORIZONS:
                    current={case_id:new[policy,case_id,horizon] for case_id in ids}
                    categories={"warmup_gate":[],"modeled_extension":[],"modeled_default_gate":[],"non_gate":[]}
                    unknown_predicate=0
                    for case_id in ids:
                        row=choice[policy,case_id,horizon]
                        category="non_gate" if row["gate"] is None else "warmup_gate" if row["model_id"] is None else "modeled_extension" if row["action"]!="C0" else "modeled_default_gate"
                        categories[category].append(case_id)
                        assert current[case_id]["selected_source_policy"]==data.ACTIONS[row["action"]]
                    counts={name:len(group) for name,group in categories.items()}
                    assert sum(counts.values())==len(ids)
                    summary[policy][cohort][part][horizon]={"counts":counts,"metrics":metrics(list(current.values())),"vs_ifd":paired(current,base[horizon]["C0"],ids,cases),"vs_always_C1":paired(current,base[horizon]["C1"],ids,cases),"groups":{name:{"vs_ifd":paired(current,base[horizon]["C0"],group,cases),"C1_vs_ifd":paired(base[horizon]["C1"],base[horizon]["C0"],group,cases)} for name,group in categories.items()}}
        slots[policy]=[]
        for model in models["models"][policy]:
            first,last=model["application_start_index"],model["application_end_exclusive"]
            rule=model["selected_rule"]
            ixs=[i for i,row in enumerate(gates.rows) if row["horizon"]=="H60" and first<=row["session_index"]<last]
            masks=rules.predicate_masks(derived[ixs],rule["predicates"])
            position={name:i for i,name in enumerate(rules.DERIVED_NAMES)}
            all_known=np.logical_and.reduce([np.isfinite(derived[ixs,position[predicate["feature"]]]) for predicate in rule["predicates"]])
            gated=np.asarray([gates.rows[i]["gate"] is not None for i in ixs])
            actual=rules.apply_model(model,derived[ixs])
            assert all(choice[policy,gates.rows[i]["case_id"],"H60"]["action"]==action for i,action in zip(ixs,actual))
            groups={}
            for cohort in COHORTS:
                ids=scope(cohort,first,last);selected=[case_id for case_id in ids if choice[policy,case_id,"H60"]["action"]!="C0"]
                defaults=[case_id for case_id in ids if choice[policy,case_id,"H60"]["gate"] is not None and choice[policy,case_id,"H60"]["action"]=="C0"]
                counts=Counter(cases[case_id]["session"] for case_id in selected)
                groups[cohort]={"trades":len(ids),"gate":sum(choice[policy,case_id,"H60"]["gate"] is not None for case_id in ids),"extensions":len(selected),"extension_scenes":len(counts),"extension_top_scenes":counts.most_common(5),"selected_C1_vs_IFD":paired(base["H60"]["C1"],base["H60"]["C0"],selected,cases),"default_C1_vs_IFD":paired(base["H60"]["C1"],base["H60"]["C0"],defaults,cases)}
            contributions=rule["scene_contributions"]
            top_contributions=sorted([{"scene_index":int(index),"session":gates.scenes[int(index)]["session"],"eligible_n_j":model["scene_denominators"][index],"d_j":value,"matched_raw_difference_yen":value*model["scene_denominators"][index]} for index,value in contributions.items()],key=lambda row:row["d_j"],reverse=True)
            slots[policy].append({"model_id":model["model_id"],"train":[model["training_start_index"],model["training_end_exclusive"]],"apply":[first,last],"teacher_count":model["teacher_count"],"teacher_scenes":model["teacher_scenes"],"rule":rule,"positive_rules":model["positive_score_rules"],"top10_action_counts":dict(Counter(row["action"] for row in model["top10"])),"winner_margin_score":None if len(model["top10"])<2 else rule["score"]-model["top10"][1]["score"],"matched_scene_n_j_one":sum(model["scene_denominators"][index]==1 for index in contributions),"top_training_contributions":top_contributions[:5],"apply_physical_gates":int(gated.sum()),"apply_gate_both_predicate_known":int((gated&all_known).sum()),"apply_gate_predicate_unknown":int((gated&~all_known).sum()),"apply_matched":int((masks[0]&masks[1]).sum()),"cohorts":groups})
    overlaps={}
    for horizon in data.HORIZONS:
        sets={policy:{case_id for case_id in cases if choice[policy,case_id,horizon]["action"]!="C0"} for policy in POLICIES}
        overlaps[horizon]={"extensions":{policy:len(ids) for policy,ids in sets.items()},"pairs":[{"left":a,"right":b,"intersection":len(sets[a]&sets[b]),"union":len(sets[a]|sets[b]),"only_left":len(sets[a]-sets[b]),"only_right":len(sets[b]-sets[a])} for a,b in itertools.combinations(POLICIES,2)],"all3":len(set.intersection(*sets.values()))}
    known_model_ids={model["model_id"] for values in models["models"].values() for model in values}
    unique_rules={tuple(p["id"] for p in model["selected_rule"]["predicates"]) for values in models["models"].values() for model in values}
    result={"成功":True,"試行":159,"範囲":"主H60/D1/C5とSESSION/D1/C5、保存済み固定採否のみ","再学習":False,"新閾値探索":False,"教師総数":models["teacher_total"],"教師既知":models["eligible_teachers"],"モデル枠":9,"訓練窓":len(known_model_ids),"異なる選定条件":len(unique_rules),"選択行動":dict(Counter(row["action"] for row in choices_object["rows"])),"inputs":{"models":model_ref,"choices":choice_ref,"result":result_ref,"parent":parent_ref,"snapshot":snapshot_ref},"baselines":baselines,"summary":summary,"model_slots":slots,"overlaps":overlaps,"frozen_source_sha256":frozen_before}
    assert frozen_before=={p.name:sha(p) for p in SOURCE.glob("*.py")}
    target=HERE/"モデル解釈の集計.json"
    target.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+"\n",encoding="utf-8")
    (HERE/"要点の集計.json").write_text(json.dumps(compact_report(result),ensure_ascii=False,indent=2,allow_nan=False)+"\n",encoding="utf-8")
    print(json.dumps({"成功":True,"path":str(target),"sha256":sha(target)},ensure_ascii=False))


if __name__=="__main__":main()
