"""158の19政策と159の因果的選択3政策を、同じ入口で総合比較する。"""
from pathlib import Path
from collections import defaultdict
import argparse
import gzip
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parents[2]
POLICIES = tuple(row['id'] for row in json.loads((ROOT/'study/00158_複合技術で出口の役割と局面を切り替える/候補の固定.json').read_bytes())['政策']) + ('G01_F48','G02_EXP12','G03_WIN36')


def read_json(path: Path) -> dict:
    """
    機能: gzip又は平文のJSONを読み、全CRCと前後statを確認する。
    引数: path(Path)。返り値: dict。
    """
    before = path.stat()
    with (gzip.open(path, 'rt', encoding='utf-8') if path.suffix == '.gz'
          else path.open('r', encoding='utf-8')) as source:
        value = json.load(source)
        assert not source.read()
    after = path.stat()
    assert (before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns)
    return value


def sha(path: Path) -> str:
    """
    機能: ファイルを逐次読取してSHA256を求める。
    引数: path(Path)。返り値: str。
    """
    result = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1 << 20), b''):
            result.update(block)
    return result.hexdigest()


def ratio(a: float, b: float) -> float | None:
    """
    機能: 分母0を未知のままにした比率を求める。
    引数: a/b(float)。返り値: float又はNone。
    """
    return a / b if b else None


def wilson(success: int, n: int) -> tuple[float | None, float | None]:
    """
    機能: Bernoulli比率のWilson95%区間を参考値として求める。
    引数: success/n(int)。返り値: tuple[float又はNone,float又はNone]。
    """
    if not n:
        return None, None
    z = 1.959963984540054
    p = success/n
    center = (p+z*z/(2*n))/(1+z*z/n)
    radius = z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/(1+z*z/n)
    return max(0, center-radius), min(1, center+radius)


def realized_dd(rows: list[dict]) -> float:
    """
    機能: 同時刻決済を合算し、既知1枚独立収支の最大DDを求める。
    引数: rows(list[dict])は金額既知の結果。返り値: float、損失幅は正値。
    """
    events = defaultdict(float)
    for row in rows:
        events[row['fill']['time']] += row['profit_yen']
    equity = high = dd = 0.0
    for stamp, change in sorted(events.items()):
        equity += change
        high = max(high, equity)
        dd = max(dd, high-equity)
    return dd


def metrics(rows: list[dict]) -> dict:
    """
    機能: 未知を除去せず件数を保持し、既知分の利益・損失を集計する。
    引数: rows(list[dict])。返り値: dict。
    """
    known = [r for r in rows if r['status'] == 'closed']
    unknown = [r for r in rows if r['status'] == 'unknown']
    assert len(known)+len(unknown) == len(rows)
    assert all(r['profit_yen'] is None and r['profit_points'] is None for r in unknown)
    assert all(r['fill'] is not None and r['profit_yen'] is not None for r in known)
    assert all(abs(r['profit_yen']-(100*r['profit_points']-r['fee_yen'])) < 1e-7 for r in known)
    profit = sum(max(0, r['profit_yen']) for r in known)
    loss = -sum(min(0, r['profit_yen']) for r in known)
    wins = sum(r['profit_yen'] > 0 for r in known)
    losses = sum(r['profit_yen'] < 0 for r in known)
    flat = len(known)-wins-losses
    ci = wilson(wins, len(known))
    return {'取得数':len(rows), '決済既知':len(known), '損益未知':len(unknown),
        '利益取引':wins, '損失取引':losses, '同額取引':flat,
        '利益総額円':profit, '損失総額円':loss, '既知差引円':profit-loss,
        '全件確定差引円':None if unknown else profit-loss,
        'PF':ratio(profit,loss), '利益側金額比率':ratio(profit,profit+loss),
        '既知決済勝率':ratio(wins,len(known)), '勝率参考95下限':ci[0], '勝率参考95上限':ci[1],
        '追尾起動既知':sum(bool(r['armed']) for r in known),
        '費用後正益後赤字':sum(bool(r['profit_after_positive_loss']) for r in known),
        '125順行後赤字':sum(bool(r['profit_after125_loss']) for r in known),
        '平均保有秒':ratio(sum(r['held_seconds'] for r in known),len(known)),
        '平均吐出しpt':ratio(sum(r['giveback_points'] for r in known),len(known)),
        '独立既知決済累計DD円':realized_dd(known)}


def membership_base(member: dict) -> str:
    """
    機能: 固定入力の所属識別子を研究名に正規化する。
    引数: member(dict)。返り値: str。未知識別子は拒否する。
    """
    value = member.get('base', member.get('policy', member.get('cohort', member.get('base_id'))))
    assert value in ('153U15','152U0'), member
    return value


def paired_metrics(rows: list[dict], baseline: list[dict]) -> dict:
    """
    機能: 同じ取得の単純IFD±125ptと対応比較し、未知と場内相関を残す。
    引数: rows/baseline(list[dict])。返り値: dict。
    """
    controls = {(r['_session'],r['_case_id']):r for r in baseline}
    assert len(controls) == len(baseline) == len(rows)
    pairs = [(r,controls[(r['_session'],r['_case_id'])]) for r in rows]
    known = [(r,b) for r,b in pairs if r['status'] == b['status'] == 'closed']
    scene_changes = defaultdict(float)
    for r,b in known:
        scene_changes[r['_session']] += r['profit_yen']-b['profit_yen']
    b = metrics(baseline)
    return {'IFD利益総額円':b['利益総額円'],'IFD損失総額円':b['損失総額円'],
        'IFD既知差引円':b['既知差引円'],'IFD損益未知':b['損益未知'],
        'IFD対応既知件数':len(known),'IFD対応損益未知':len(pairs)-len(known),
        '対応既知IFD差分円':sum(r['profit_yen']-b['profit_yen'] for r,b in known),
        '対応利益総額差分円':sum(max(0,r['profit_yen'])-max(0,b['profit_yen']) for r,b in known),
        '対応損失総額差分円':sum(max(0,-r['profit_yen'])-max(0,-b['profit_yen']) for r,b in known),
        'IFDより改善件数':sum(r['profit_yen']>b['profit_yen'] for r,b in known),
        'IFDより悪化件数':sum(r['profit_yen']<b['profit_yen'] for r,b in known),
        '対応既知で実決済が同じ取得数':sum(r['fill']==b['fill'] and r['profit_yen']==b['profit_yen'] for r,b in known),
        '対応既知で実決済が異なる取得数':sum(r['fill']!=b['fill'] or r['profit_yen']!=b['profit_yen'] for r,b in known),
        '対応既知改善場数':sum(v>0 for v in scene_changes.values()),
        '対応既知悪化場数':sum(v<0 for v in scene_changes.values())}


def technical_metrics(rows: list[dict]) -> dict:
    """
    機能: 技術の未発動と必要特徴不足を、取引数/評価回数を分けて集計する。
    引数: rows(list[dict])。返り値: dict。
    """
    counters=[r.get('technical_counts') or {} for r in rows]
    missing=set().union(*(set(c.get('missing_features') or {}) for c in counters))
    result={'技術評価した取得数':sum(c.get('evaluations',0)>0 for c in counters),
        '特徴不足があった取得数':sum(c.get('fallback_evaluations',0)>0 for c in counters),
        '技術床変更した取得数':sum(c.get('floor_changes',0)>0 for c in counters),
        '技術退出要求した取得数':sum(c.get('technical_requests',0)>0 for c in counters),
        '技術評価回数':sum(c.get('evaluations',0) for c in counters),
        '特徴不足評価回数':sum(c.get('fallback_evaluations',0) for c in counters),
        '技術床変更回数':sum(c.get('floor_changes',0) for c in counters),
        '技術退出要求回数':sum(c.get('technical_requests',0) for c in counters),
        '利確要求回数':sum(c.get('take_profit_requests',0) for c in counters),
        '不足特徴の種類数':len(missing)}
    if rows and all(r['policy'].startswith('G0') for r in rows):
        return {key:None for key in result}
    return result


def build(data: dict) -> dict:
    """
    機能: 152出口条件を全/前48/後25と全73場へ集計する。
    引数: data(dict)は158出口正本。返り値: dictは型付きCSV入力と要約。
    """
    assert data['success'] and data['trial'] == 159
    scenes = data['scenes']
    assert len(scenes) == 73 and len({s['session'] for s in scenes}) == 73
    configurations = data['configurations']
    assert len(configurations) == 176 and len({c['id'] for c in configurations}) == 176
    assert {c['policy'] for c in configurations} == set(POLICIES)
    scene_rank = {scene['session']:i for i,scene in enumerate(scenes)}
    summary_buckets, session_buckets = defaultdict(list), defaultdict(list)
    memberships = defaultdict(set)
    for scene in scenes:
        for case in scene['cases']:
            assert len(case['results']) == 176
            bases = [membership_base(m) for m in case['memberships']]
            assert len(set(bases)) == len(bases)
            for base in bases:
                memberships[base].add((scene['session'],case['id']))
            fold = '前48場' if scene_rank[scene['session']] < 48 else '後25場'
            for raw_result in case['results']:
                result = dict(raw_result,_session=scene['session'],_case_id=case['id'])
                for base in bases:
                    key = (base,result['horizon'],result['delay'],result['cost'],result['policy'])
                    for scope in ('全73場',fold):
                        summary_buckets[(*key,scope)].append(result)
                    session_buckets[(*key,scene['session'])].append(result)
    assert {base:len(items) for base,items in memberships.items()} == {'153U15':93,'152U0':831}
    assert sum(len(scene['cases']) for scene in scenes) == 837
    identity = ['入口','保有期限','約定代用','費用','出口','区間']
    summary_rows = []
    for base in ('153U15','152U0'):
        for horizon in ('H60','SESSION'):
            for delay in ('D1','D0'):
                for cost in ('C5','C0'):
                    for policy in POLICIES:
                        for scope in ('全73場','前48場','後25場'):
                            key = (base,horizon,delay,cost,policy,scope)
                            metric = metrics(summary_buckets[key])
                            pairs = paired_metrics(summary_buckets[key],
                                summary_buckets[(base,horizon,delay,cost,'F125S125',scope)])
                            prior = paired_metrics(summary_buckets[key],
                                summary_buckets[(base,horizon,delay,cost,'T125W100TP250',scope)])
                            technical = technical_metrics(summary_buckets[key])
                            summary_rows.append([*key,*metric.values(),*pairs.values(),*prior.values(),*technical.values()])
    metric_columns = list(metrics([]))+list(paired_metrics([],[]))
    metric_columns += ['157対照_'+name for name in paired_metrics([],[])]+list(technical_metrics([]))
    session_rows = []
    for base in ('153U15','152U0'):
        for horizon in ('H60','SESSION'):
            for delay in ('D1','D0'):
                for cost in ('C5','C0'):
                    for policy in POLICIES:
                        cumulative = unknown_count = 0
                        for scene in scenes:
                            key = (base,horizon,delay,cost,policy,scene['session'])
                            m = metrics(session_buckets[key])
                            cumulative += m['既知差引円']
                            unknown_count += m['損益未知']
                            session_rows.append([*key,m['取得数'],m['決済既知'],m['損益未知'],
                                m['利益総額円'],m['損失総額円'],m['既知差引円'],cumulative,unknown_count,
                                cumulative if not unknown_count else None,m['費用後正益後赤字'],m['125順行後赤字']])
    assert len(summary_rows) == 1056 and len(session_rows) == 25696
    by_key={tuple(row[:6]):row for row in summary_rows}
    header=identity+metric_columns
    ranking=[]
    for base in ('153U15','152U0'):
        common={}
        common_delta={}
        for scope in ('前48場','後25場','全73場'):
            group={(p):summary_buckets[(base,'H60','D1','C5',p,scope)] for p in POLICIES}
            common[scope]=set.intersection(*[
                {(r['_session'],r['_case_id']) for r in rows if r['status']=='closed'}
                for rows in group.values()])
            baseline={(r['_session'],r['_case_id']):r for r in group['F125S125']}
            for policy,rows in group.items():
                common_delta[scope,policy]=sum(r['profit_yen']-baseline[(r['_session'],r['_case_id'])]['profit_yen']
                    for r in rows if (r['_session'],r['_case_id']) in common[scope])
        candidates=[by_key[(base,'H60','D1','C5',p,'前48場')] for p in POLICIES]
        candidates.sort(key=lambda r:(-common_delta['前48場',r[4]],
            0 if r[4]=='F125S125' else 1 if r[4]=='T125W100TP250' else 2,r[4]))
        for rank,train in enumerate(candidates,1):
            policy=train[4]
            test=by_key[(base,'H60','D1','C5',policy,'後25場')]
            whole=by_key[(base,'H60','D1','C5',policy,'全73場')]
            names=['既知差引円','対応既知IFD差分円','IFD対応既知件数','IFD対応損益未知']
            ranking.append([base,rank,policy,
                *[v for scope in ('前48場','後25場','全73場') for v in (len(common[scope]),common_delta[scope,policy])],
                *[r[header.index(k)] for r in (train,test,whole) for k in names],
                whole[header.index('技術床変更した取得数')],whole[header.index('技術退出要求した取得数')],
                whole[header.index('特徴不足があった取得数')]])
    return {'試行':159,'単位':'日経mini独立1枚、同時重複あり、片側10枚制限付き口座ではない',
        '区間':'全73場、前48場/後25場とも既使用データ',
        'DD定義':'金額既知のみを実決済価格時計で合算、同時刻決済を同時に計上した累計の最大下落幅。含み損益・未知額を含まない。',
        'tables':{'出口比較':{'headers':header,'rows':summary_rows},
            '全セッション':{'headers':['入口','保有期限','約定代用','費用','出口','セッション',
                '取得数','決済既知','損益未知','利益総額円','損失総額円','既知差引円','累計既知差引円',
                '累計損益未知','全件確定累計円','費用後正益後赤字','125順行後赤字'],'rows':session_rows},
            '研究順位と発動':{'headers':['入口','前48場の研究順位','出口']+
                [part+'_'+name for part in ('前48場','後25場','全73場') for name in ('全22政策共通既知数','共通既知IFD差分円')]+
                [part+'_'+name for part in ('前48場','後25場','全73場') for name in names]+
                ['全期技術床変更の取得数','全期技術退出要求の取得数','全期特徴不足の取得数'],'rows':ranking}}}


def main() -> None:
    """
    機能: 親19政策と新G3政策を非改変で結合し、最新の総合三表を作る。
    引数: CLI parent/gates/output(Path)。返り値: None。学習・選択は再実行しない。
    """
    parser=argparse.ArgumentParser()
    for name in ('parent','gates','output'):
        parser.add_argument(name,type=Path)
    args=parser.parse_args()
    assert not args.output.exists()
    hashes={str(p.resolve()):sha(p) for p in (args.parent,args.gates)}
    assert hashes[str(args.parent.resolve())]=='70a4c3178206bbb3c8641901c7515f2121da11c28403b88c3f8e6f93cc0baa6c'
    parent,gates=read_json(args.parent),read_json(args.gates)
    assert parent['success'] and parent['trial']==158 and gates['success'] and gates['trial']==159
    assert len(parent['scenes'])==len(gates['scenes'])==73
    for old_scene,new_scene in zip(parent['scenes'],gates['scenes'],strict=True):
        assert old_scene['session']==new_scene['session']
        old_cases={c['id']:c for c in old_scene['cases']}
        new_cases={c['id']:c for c in new_scene['cases']}
        assert set(old_cases)==set(new_cases)
        for ident,case in old_cases.items():
            new=new_cases[ident]
            assert new['entry']==case['entry'] and new['side']==case['side']
            assert new['memberships']==case['memberships']
            assert len(case['results'])==152 and len(new['results'])==24
            assert {r['policy'] for r in new['results']}=={'G01_F48','G02_EXP12','G03_WIN36'}
            assert not any(r.get('technical_counts') for r in new['results'])
            case['results'].extend(new['results'])
    parent['trial']=159
    parent['configurations'].extend(gates['configurations'])
    result=build(parent)
    tables=result['tables']
    result['tables']={'総合比較':tables['出口比較'],'全セッション':tables['全セッション'],
        '研究順位と発動':tables['研究順位と発動']}
    result['技術発動列']='新G政策の原行技術回数は対象外（空欄）。親の評価回数を新gateの評価回数と混ぜない。'
    result['モデルの因果時計']='最初48/24場の実政策はIFDで、未来modelを前半へ遡及適用していない。'
    result['sources']={**hashes,str(Path(__file__).resolve()):sha(Path(__file__))}
    assert hashes=={str(p.resolve()):sha(p) for p in (args.parent,args.gates)}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,ensure_ascii=False,allow_nan=False,separators=(',',':'))+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'表':{k:len(v['rows']) for k,v in result['tables'].items()},'SHA256':sha(args.output)},ensure_ascii=False))


if __name__=='__main__':
    main()


