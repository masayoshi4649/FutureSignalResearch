import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {Workbook} from '@oai/artifact-tool';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '../..');
const input = path.resolve(process.argv[2]);
const output = path.resolve(process.argv[3]);

/**
 * SHA256を計算する。
 * @param {Buffer|string} value - 指紋化する内容。
 * @returns {string} 十六進SHA256。
 */
function sha(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

/**
 * 型付き一セルをRFC4180のCSV表現へ変換する。
 * @param {number|string|boolean|null} value - 書き出す一セル。
 * @returns {string} 引用符を調整した文字列。
 */
function field(value) {
  const text = value === null ? '' : String(value);
  return /[",\r\n]/.test(text) ? '"' + text.replaceAll('"', '""') + '"' : text;
}

// ----------------------------------------
assert.ok(output.startsWith(path.join(root, 'outputs')+path.sep));
const bytes = await fs.readFile(input);
const data = JSON.parse(bytes);
assert.equal(data.試行,159);
assert.deepEqual(Object.keys(data.tables),['総合比較','全セッション','研究順位と発動']);
for (const [name,hash] of Object.entries(data.sources)) {
  assert.equal(sha(await fs.readFile(path.resolve(root,name))),hash,name);
}
const workbook = Workbook.create();
const owners = [];
for (const [name,t] of Object.entries(data.tables)) {
  const original = [t.headers,...t.rows];
  assert.ok(original.every(row=>row.length===t.headers.length));
  assert.ok(original.flat().every(v=>v===null || ['string','number','boolean'].includes(typeof v)));
  const sheet = workbook.worksheets.add(name);
  const range = sheet.getRangeByIndexes(0,0,original.length,t.headers.length);
  range.values = original;
  sheet.showGridLines = false;
  const shown = Math.min(10,t.headers.length);
  sheet.getRangeByIndexes(0,0,Math.min(14,original.length),shown).format.font = {name:'Arial',size:10};
  sheet.getRangeByIndexes(0,0,1,shown).format = {fill:'#334155',font:{name:'Arial',size:10,color:'#FFFFFF',bold:true},
    wrapText:true,verticalAlignment:'center',rowHeight:48};
  for (let j=0;j<shown;j++) {
    sheet.getRangeByIndexes(0,j,Math.min(14,original.length),1).format.columnWidthPx = j<6 ? 125 : 105;
  }
  sheet.getRangeByIndexes(0,name === '研究順位と発動'?2:4,Math.min(14,original.length),1).format.columnWidthPx = 245;
  owners.push({name,t,original,sheet,range});
}
workbook.recalculate();
await fs.mkdir(output,{recursive:true});
const proof = {成功:true,試行:159,入力SHA256:sha(bytes),元正本:data.sources,node:process.version,
  出力器SHA256:sha(await fs.readFile(fileURLToPath(import.meta.url))),表:{}};
for (const owner of owners) {
  const {name,t,original,sheet,range} = owner;
  const actual = range.values;
  assert.deepEqual(actual,original,name+'の全セル/型');
  assert.ok(range.formulas.flat().every(v=>v==='' || v===null || v===undefined));
  const body = '\uFEFF'+actual.map(row=>row.map(field).join(',')).join('\r\n')+'\r\n';
  const csvPath = path.join(output,name+'.csv');
  await fs.writeFile(csvPath,body,{encoding:'utf8',flag:'wx'});
  const inspected = await workbook.inspect({kind:'table',range:`${name}!A1:I8`,include:'values,formulas',
    tableMaxRows:8,tableMaxCols:9,maxChars:1300});
  const preview = await workbook.render({sheetName:name,range:'A1:I12',scale:1,format:'png'});
  await fs.writeFile(path.join(output,name+'_表示確認.png'),new Uint8Array(await preview.arrayBuffer()),{flag:'wx'});
  proof.表[name]={データ行:t.rows.length,列:t.headers.length,全セル照合:actual.length*t.headers.length,
    SHA256:sha(body),inspect:inspected.ndjson};
}
const errors = await workbook.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',
  options:{useRegex:true,maxResults:10},maxChars:1000});
proof.エラー走査 = errors.ndjson;
assert.equal(sha(await fs.readFile(input)),sha(bytes));
for (const [name,hash] of Object.entries(data.sources)) {
  assert.equal(sha(await fs.readFile(path.resolve(root,name))),hash,name);
}
await fs.writeFile(path.join(output,'作成確認.json'),JSON.stringify(proof,null,2)+'\n',{encoding:'utf8',flag:'wx'});
console.log(JSON.stringify({成功:true,表:proof.表}));
