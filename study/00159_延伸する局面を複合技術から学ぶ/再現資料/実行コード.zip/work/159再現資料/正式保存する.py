"""159の固定抽出ZIPと停止済み実行小源を正式再現資料へ保存する。"""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
FORMAL=ROOT/'study/00159_延伸する局面を複合技術から学ぶ'
DEST=FORMAL/'再現資料'
CHECKS=FORMAL/'検査'
CSV=ROOT/'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/00159_出口の総合比較'


def fp(path: Path) -> dict:
    """
    機能: 全物理SHAを取り前後stat同体を確認する。
    引数: path(Path)。返り値: dict。
    """
    a=path.stat();h=hashlib.sha256()
    with path.open('rb') as source:
        for b in iter(lambda:source.read(4<<20),b''):h.update(b)
    z=path.stat();assert (a.st_size,a.st_mtime_ns)==(z.st_size,z.st_mtime_ns)
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':a.st_size,'sha256':h.hexdigest()}


def copy_once(source: Path, target: Path) -> dict:
    """
    機能: 小票/ZIPを初回だけ保存し既存なら同体だけを受理する。
    引数: source/target(Path)。返り値: dict。
    """
    body=source.read_bytes();target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():assert target.read_bytes()==body,target
    else:target.write_bytes(body)
    return {'source':fp(source),'saved':fp(target)}


def load(path: Path) -> dict:
    """
    機能: 小JSONの固定票を読む。
    引数: path(Path)。返り値: dict。
    """
    return json.loads(path.read_text(encoding='utf-8'))


def write_new(path: Path, data: dict) -> None:
    """
    機能: 保存生成物をUTF8で排他新規保存する。
    引数: path(Path)、data(dict)。返り値: None。
    """
    body=(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode('utf-8')
    if path.exists():assert path.read_bytes()==body,path
    else:path.write_bytes(body)


def main() -> None:
    """
    機能: F0現物一致/停止源/最新CSVを確認して独立小ZIPと索引を保存する。
    引数: なし。返り値: None。学習/抽出/金融/CSV生成を再実行しない。
    """
    DEST.mkdir(parents=True,exist_ok=True);CHECKS.mkdir(parents=True,exist_ok=True)
    frozen=load(CHECKS/'学習前固定.json')
    for path,sha in frozen['ソース'].items():assert fp(ROOT/path)['sha256']==sha,path
    for ref in frozen['入力'].values():assert fp(ROOT/ref['path'])['sha256']==ref['sha256'],ref
    originals=[(ROOT/'work/159延伸判断の特徴抽出/準備の確認.json','snapshot抽出の準備確認.json'),
        (ROOT/'work/159延伸判断の特徴抽出/停止の確認.json','snapshot抽出の停止確認.json'),
        (HERE/'ステージの確認.json','snapshot再現ステージの確認.json'),
        (HERE/'ステージの停止.json','snapshot再現ステージの停止.json'),
        (HERE/'入力と依存の参照.json','snapshot保存と時点の確認.json'),
        (HERE/'準備表の退避確認.json','初期設定表の退避確認.json'),
        (ROOT/'inputs/00159_延伸判断の特徴/判断時点の特徴.json.gz.完了.json','snapshot自然抽出の完了.json'),
        (ROOT/'work/159複合条件の延伸選択/準備の確認.json','学習部品の準備確認.json'),
        (ROOT/'work/159複合条件の延伸選択/停止.json','学習部品の停止確認.json'),
        (CSV/'作成確認.json','CSV作成の確認.json'),(CSV/'独立再読.json','CSV全セルの標準再読.json')]
    copies=[copy_once(p,CHECKS/name) for p,name in originals]
    copies.append(copy_once(HERE/'snapshot抽出の再現コード.zip',DEST/'snapshot抽出の再現コード.zip'))
    # ----------------------------------------
    # 原文は内部リンクを直さず元bytesをZIPへ保存し、初期記録のSHAを維持する。
    assert fp(HERE/'初期設定と結果.md')['sha256']=='4d3570f7594ad2099f47e5db8835709bed2c8f573a084fb7956d249db5b1f049'
    files=list(sorted((ROOT/'work/159複合条件の延伸選択').glob('*.py')))
    files += [ROOT/'work/159複合条件の延伸選択'/n for n in ('README.md','準備の確認.json','停止.json')]
    files += [ROOT/'work/159集計と閲覧'/n for n in ('総合集計する.py','人工検査.py','CSVへ出力する.mjs','CSVを独立再読する.py')]
    files += [ROOT/'work/159研究条件/条件を固定する.py',ROOT/'work/159研究報告/報告を作成する.py',
        CHECKS/'学習前固定.json',FORMAL/'成果物/完了の確認.json',HERE/'初期設定と結果.md',Path(__file__)]
    assert len(files)==len(set(files))
    before={p:fp(p) for p in files}
    content={p.relative_to(ROOT).as_posix():p.read_bytes() for p in files}
    parent=load(HERE/'入力と依存の参照.json')['parent_archives']
    creation=load(CSV/'作成確認.json');reread=load(CSV/'独立再読.json')
    assert creation['成功'] and reread['成功'] and creation['入力SHA256']==reread['型付き入力SHA256']
    assert fp(ROOT/'work/159集計と閲覧/型付き表.json')['sha256']==creation['入力SHA256']
    latest_csv=[]
    for name,ref in creation['表'].items():
        path=CSV/(name+'.csv');actual=fp(path);assert actual['sha256']==ref['SHA256']==reread['表'][name]['SHA256'];latest_csv.append(actual)
    done=load(FORMAL/'成果物/完了の確認.json')
    for ref in (done['result'],done['models'],done['choices']):assert fp(Path(ref['path']))['sha256']==ref['sha256']
    manifest={'trial':159,'scope':'自然実行前固定の学習5源と後発Root集計/CSV/文書源の保存。後発をF0へ遡及しない',
        'members':[{'path':name,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()} for name,body in sorted(content.items())],
        'parent_archives':parent,'dependencies':{'Python':'3.14.3','NumPy':'2.5.4','Go':'1.24.2','Node':'24.22.1','artifact_tool':'2.8.129'},
        'initial_settings_record':{'sha256':'4d3570f7594ad2099f47e5db8835709bed2c8f573a084fb7956d249db5b1f049','f0_prebound_claim':False},
        'not_included':['node_modules','exe','自然大入力','型付き表','CSV/PNG副本','後発のモデル解釈/独立最終票']}
    archive=DEST/'実行コード.zip';assert not archive.exists()
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,body in sorted(content.items()):z.writestr(name,body)
        z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and set(z.namelist())==set(content)|{'manifest.json'}
        for name,body in content.items():assert z.read(name)==body
        assert json.loads(z.read('manifest.json'))==manifest
    assert before=={p:fp(p) for p in files}
    index={'success':True,'trial':159,'snapshot_archive':fp(DEST/'snapshot抽出の再現コード.zip'),'execution_archive':fp(archive),
        'source_members':manifest['members'],'parent_archives':parent,'copied_small_evidence':copies,
        'snapshot':fp(ROOT/'inputs/00159_延伸判断の特徴/判断時点の特徴.json.gz'),
        'snapshot_input_readme':fp(ROOT/'inputs/00159_延伸判断の特徴/README.md'),
        'parent_result158':fp(ROOT/'study/00158_複合技術で出口の役割と局面を切り替える/成果物/出口結果.json.gz'),
        'composed_result159':fp(Path(done['result']['path'])),'learning_completion':fp(FORMAL/'成果物/完了の確認.json'),
        'learning_f0':fp(CHECKS/'学習前固定.json'),'latest_csv':latest_csv,
        'typed_table_not_copied':{'sha256':creation['入力SHA256'],'rebuild_inputs':'158出口結果gzip＋159固定入口の出口合成gzip＋保存総合集計コード'},
        'source_before_after_unchanged':True,'natural_reexecuted':False,'large_inputs_copied':False,
        'pending_root_additions':['モデル解釈','独立最終確認票','Rootの最終保存確認']}
    write_new(DEST/'保管索引.json',index)
    write_new(CHECKS/'再現資料の保存確認.json',{'success':True,'trial':159,'archive_members':len(content),'all_zip_bytes_reread':True,
        'source_before_after_unchanged':True,'f0_learner_sources_current_equal':True,'latest_csv_cells_recorded':sum(r['全セル一致'] for r in reread['表'].values()),
        'index':fp(DEST/'保管索引.json'),'snapshot_archive':index['snapshot_archive'],'execution_archive':index['execution_archive'],
        'natural_reexecuted':False,'large_inputs_copied':False,'root_final_check_pending':True})
    print(json.dumps({'index':fp(DEST/'保管索引.json'),'proof':fp(CHECKS/'再現資料の保存確認.json'),'execution_zip':fp(archive)},ensure_ascii=False,indent=2))


if __name__=='__main__':main()
