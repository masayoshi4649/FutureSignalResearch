"""159の境界・prefix・未来非依存を小さい非自然fixtureで調べる。"""
from __future__ import annotations

import copy
import inspect
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np

import data159 as data
import rules159 as rules


def quote(time: float, index: int, gain: float = 125) -> dict:
    """人工の清算側Quoteを作る。

    引数: time (float)、index (int)、gain (float) 粗益。
    返り値: dict 型。
    """
    return {"time": time, "index": index, "source_line": index + 1, "clock": "人工時計", "last": 1005 + gain, "bid": 1000 + gain, "ask": 1010 + gain, "quote_ok": True}


def snapshot_and_results() -> tuple[dict, dict]:
    """TPと非TPを含む2物理caseの保存票を作る。

    引数: なし。
    返り値: tuple[dict, dict] 型。自然Sourceは開かない。
    """
    scenes = [{"session": "人工場", "contract": "人工限月", "start": 0, "end": 1000, "force_close": 900, "continuous_end": 950, "rows": []}]
    result_scene = {key: value for key, value in scenes[0].items() if key != "rows"}
    result_scene["cases"] = []
    for case_index, gated in enumerate((True, False)):
        entry = quote(100 + 100 * case_index, 1 + case_index * 10, -10)
        gate = quote(entry["time"] + 10, entry["index"] + 1) if gated else None
        case_id = f"人工{case_index}"
        case = {"id": case_id, "side": 1, "original_side": 1, "stream": "original", "entry": entry, "entry_price": 1000, "memberships": [{"policy": "153U15"}, {"policy": "152U0"}], "results": []}
        for horizon in data.HORIZONS:
            scenes[0]["rows"].append({"case_id": case_id, "session": "人工場", "contract": "人工限月", "session_index": 0, "horizon": horizon, "side": 1, "entry": copy.deepcopy(entry), "gate": copy.deepcopy(gate), "values": {"人工列": 1.0} if gated else None})
            for delay in data.DELAYS:
                for cost in data.COSTS:
                    for action_index, (action, policy) in enumerate(data.ACTIONS.items()):
                        fill = quote(entry["time"] + (11 + action_index * 10 if gated else 6), entry["index"] + (2 + action_index if gated else 2), 125 + action_index * 25 if gated else -130)
                        trigger_quote = gate if gated else quote(entry["time"] + 5, entry["index"] + 1, -125)
                        result = {key: None for key in data.PREFIX_KEYS}
                        result.update({"config_id": "/".join((policy, horizon, delay, cost)), "policy": policy, "horizon": horizon, "delay": delay, "cost": cost, "status": "closed", "deadline": 900, "fee_yen": 1077 if cost == "C5" else 77, "entry_mark_points": -10, "fill": fill, "profit_points": fill["bid"] - 1000, "profit_yen": 100 * (fill["bid"] - 1000) - (1077 if cost == "C5" else 77), "trigger": {"reason": "take_profit" if gated else "stop", "time": trigger_quote["time"], "quote": copy.deepcopy(trigger_quote), "stop_points": None}, "reached125": gated, "first125_quote": copy.deepcopy(gate), "armed": gated and action != "C0", "arm_quote": copy.deepcopy(gate) if gated and action != "C0" else None})
                        if action == "C2":
                            result["technical_counts"] = {"evaluations": 3}
                            result["technical_trace"] = [{"親だけの診断": True}]
                        case["results"].append(result)
        result_scene["cases"].append(case)
    return {"success": True, "trial": 159, "schema": "gate_snapshots159_v1", "catalog": ["人工列"], "scenes": scenes}, {"success": True, "trial": 158, "scenes": [result_scene]}


def batch_fixture() -> rules.TrainingBatch:
    """全eligible分母とmatched分母が異なる教師を作る。

    引数: なし。
    返り値: TrainingBatch 型。各場3教師中2教師だけ既知特徴を持つ。
    """
    x = np.full((18, 25), np.nan)
    rows, net = [], np.zeros((18, 3))
    for index in range(18):
        scene = index // 3
        if index % 3 < 2:
            x[index] = 0
            net[index, 1:] = 12
        else:
            net[index, 1:] = 999
        rows.append({"case_id": f"人工{index}", "eligible": True, "known_at": 1.0, "session_index": scene, "feature_index": index})
    return rules.TrainingBatch(x, net, np.asarray([row["session_index"] for row in rows]), rows, 0, 6, 1000)


def walk_fixture() -> tuple[data.GateDataset, data.TeacherDataset]:
    """73場の時計と完全に人工の特徴・教師を作る。

    引数: なし。
    返り値: tuple[GateDataset, TeacherDataset] 型。
    """
    raw = {"m1.atr14": 20, "m5.atr14": 100, "m15.atr14": 150, "m30.atr14": 200, "m1.di_difference": 10, "m15.adx": 25, "m1.hist": 1, "m5.hist": 2, "m1.hist_delta": 1, "m1.rsi14": 55, "m1.cmf20": .2, "m1.obv_delta5": 100, "m1.rvol": 1.2, "m1.er10": .5, "m1.chop14": 40, "m1.bb_width": 100, "m1.previous_bb_width": 100, "m1.close": 1020, "m1.ema8": 1010, "m1.zscore": 1, "m1.body": 10, "m1.prior_high5": 1030, "m1.prior_low5": 990}
    for width in (5, 15, 30):
        raw[f"m{width}.gap"] = 10
        raw[f"m{width}.ema21_delta"] = 2
    columns = tuple(sorted(raw))
    scenes, rows, teachers = [], [], []
    for scene in range(73):
        start = scene * 10000
        scenes.append({"session": f"人工場{scene}", "contract": "人工限月", "start": start, "end": start + 9000})
        for horizon in data.HORIZONS:
            rows.append({"case_id": f"人工case{scene}", "session": f"人工場{scene}", "contract": "人工限月", "session_index": scene, "horizon": horizon, "side": 1, "entry": quote(start + 100, 1, -10), "gate": quote(start + 200, 2)})
        teachers.append({"case_id": f"人工case{scene}", "session": f"人工場{scene}", "session_index": scene, "feature_index": scene * 2, "eligible": True, "known_at": start + 500})
    gates = data.GateDataset(columns, np.asarray([[raw[name] for name in columns]] * len(rows), dtype=np.float64), rows, scenes)
    teacher = data.TeacherDataset(teachers, np.asarray([[0, 1000, 500]] * 73, dtype=np.float64), np.ones(73, dtype=bool), np.asarray([row["known_at"] for row in teachers], dtype=np.float64))
    return gates, teacher


class Tests(unittest.TestCase):
    """自然入力へ進まず重要な契約だけを確認する。"""

    def test_dictionary_boundary_and_unknown(self) -> None:
        """固定辞書・等号・unknown両falseを確認する。

        引数: self (Tests)。返り値: None。
        """
        predicates = rules.dictionary()
        self.assertEqual(len(predicates), 124)
        x = np.zeros((2, 25)); x[1] = np.nan
        masks = rules.predicate_masks(x)
        self.assertFalse(masks[:, 1].any())
        for i, predicate in enumerate(predicates):
            if predicate["threshold"] == 0:
                self.assertEqual(bool(masks[i, 0]), predicate["op"] == ">=")
        book = Path(__file__).resolve().parents[2] / "study/00159_延伸する局面を複合技術から学ぶ/文法と学習の固定.json"
        rules.validate_book(json.loads(book.read_text(encoding="utf-8-sig")))

    def test_score_denominator_support_and_tie(self) -> None:
        """全eligible分母・最良場除去・負場罰則・同点順を確認する。

        引数: self (Tests)。返り値: None。
        """
        batch = batch_fixture(); before = batch.net.copy()
        model = rules.fit_rule(batch)
        rule = model["selected_rule"]
        self.assertEqual((rule["score"], rule["matched_teachers"], rule["matched_scenes"], rule["action"]), (40, 12, 6, "C1"))
        self.assertEqual(model["candidate_rules"], 12464)
        np.testing.assert_array_equal(before, batch.net)
        batch.net[15:17, 1:] = -12
        self.assertEqual(rules.fit_rule(batch)["selected_rule"]["score"], 20)
        batch.derived[0] = np.nan
        self.assertIsNone(rules.fit_rule(batch)["selected_rule"])

    def test_prefix_teacher_unknown_and_recomposition(self) -> None:
        """共通prefixと未知教師・親診断の扱いを確認する。

        引数: self (Tests)。返り値: None。
        """
        snapshots, saved = snapshot_and_results()
        gates = data.gate_dataset(snapshots); indexed, _ = data.action_index(saved)
        proof = data.verify_common_prefix(gates, indexed)
        self.assertEqual(proof, {"gate_groups": 8, "non_gate_groups": 8, "action_comparisons": 32})
        teacher = data.project_teachers(gates, indexed)
        self.assertEqual(teacher.eligible.tolist(), [True, False])
        self.assertEqual(teacher.known_at[0], 131)
        self.assertTrue(np.isnan(teacher.net[1]).all())
        case = indexed["人工0"]; before = copy.deepcopy(case)
        result = data.recompose_result(case, "H60", "D1", "C5", "C2", "G01_F48", {"model_id": "人工", "feature_index": 0}, "親SHA")
        source = case["results"]["H60", "D1", "C5", "C2"]
        for key in data.PREFIX_KEYS:
            self.assertEqual(result.get(key), source.get(key))
        self.assertNotIn("technical_trace", result)
        self.assertNotIn("technical_counts", result)
        self.assertEqual(result["parent_diagnostics"]["counts"], {"evaluations": 3})
        self.assertEqual(before, case)
        case["results"]["H60", "D1", "C5", "C2"].update(status="unknown", fill=None, profit_yen=None)
        data.verify_common_prefix(gates, indexed)
        self.assertFalse(data.project_teachers(gates, indexed).eligible[0])

    def test_prefix_rejects_early_and_nonTP_difference(self) -> None:
        """query前の別行動退出と非TPの損益差を拒否する。

        引数: self (Tests)。返り値: None。
        """
        snapshots, saved = snapshot_and_results(); gates = data.gate_dataset(snapshots); indexed, _ = data.action_index(saved)
        indexed["人工0"]["results"]["H60", "D1", "C5", "C1"]["fill"] = quote(109, 1)
        with self.assertRaises(AssertionError): data.verify_common_prefix(gates, indexed)
        indexed, _ = data.action_index(saved)
        indexed["人工1"]["results"]["H60", "D1", "C5", "C2"]["profit_yen"] += 1
        with self.assertRaises(AssertionError): data.verify_common_prefix(gates, indexed)

    def test_future_labels_and_warmup(self) -> None:
        """未来label改変で既定9モデル・全採否が変わらないことを確認する。

        引数: self (Tests)。返り値: None。
        """
        gates, teacher = walk_fixture()
        models, choices = rules.walk_forward(gates, teacher)
        modified = copy.deepcopy(teacher); modified.net[60:, 1:] = -1e9
        next_models, next_choices = rules.walk_forward(gates, modified)
        self.assertEqual(models, next_models); self.assertEqual(choices, next_choices)
        self.assertEqual(sum(map(len, models.values())), 9)
        self.assertEqual(len({model["model_id"] for values in models.values() for model in values}), 6)
        for choice in choices:
            warmup = 48 if choice["policy"] == "G01_F48" else 24
            if choice["session_index"] < warmup:
                self.assertEqual((choice["action"], choice["model_id"]), ("C0", None))
        self.assertEqual(tuple(inspect.signature(rules.apply_model).parameters), ("model", "derived"))

    def test_strict_maturity_and_mirror(self) -> None:
        """成熟等号除外と25派生の買売鏡像を確認する。

        引数: self (Tests)。返り値: None。
        """
        gates, teacher = walk_fixture(); derived = rules.derive(gates)
        cutoff = gates.scenes[24]["start"]
        teacher.known_at[23] = cutoff; teacher.rows[23]["known_at"] = cutoff
        batch = rules.select_training(gates, teacher, derived, 0, 24, cutoff)
        self.assertEqual(len(batch.rows), 23)
        mirror = copy.deepcopy(gates)
        for row in mirror.rows: row["side"] = -1
        for index, name in enumerate(mirror.columns):
            if name in ("m1.close", "m1.ema8"):
                mirror.X[:, index] = 3000 - mirror.X[:, index]
            elif name == "m1.prior_high5": mirror.X[:, index] = 3000 - gates.X[:, gates.columns.index("m1.prior_low5")]
            elif name == "m1.prior_low5": mirror.X[:, index] = 3000 - gates.X[:, gates.columns.index("m1.prior_high5")]
            elif name == "m1.rsi14": mirror.X[:, index] = 100 - mirror.X[:, index]
            elif any(part in name for part in (".gap", ".ema21_delta", ".hist", ".di_difference")) or name in ("m1.cmf20", "m1.obv_delta5", "m1.zscore", "m1.body"):
                mirror.X[:, index] *= -1
        np.testing.assert_allclose(derived, rules.derive(mirror), equal_nan=True)

    def test_composition_and_gzip_integrity(self) -> None:
        """G24合成・gzip指紋・CRC拒否を人工だけで確認する。

        引数: self (Tests)。返り値: None。
        """
        path=Path(__file__).with_name("実行する.py")
        spec=importlib.util.spec_from_file_location("runner159_fixture",path)
        runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
        snapshots,saved=snapshot_and_results();gates=data.gate_dataset(snapshots);indexed,_=data.action_index(saved)
        choices=[]
        for policy in runner.POLICIES:
            for i,row in enumerate(gates.rows):choices.append({"policy":policy,"case_id":row["case_id"],"horizon":row["horizon"],"action":"C1" if row["gate"] is not None else "C0","model_id":"人工固定","feature_index":i,"gate":copy.deepcopy(row["gate"])})
        result=runner.compose(gates,indexed,choices,"親SHA",{})
        self.assertEqual((result["configuration_count"],result["case_count"],result["membership_count"]),(24,2,4))
        self.assertTrue(all(len(case["results"])==24 for scene in result["scenes"] for case in scene["cases"]))
        self.assertTrue(all("technical_trace" not in row and "technical_counts" not in row for scene in result["scenes"] for case in scene["cases"] for row in case["results"]))
        with tempfile.TemporaryDirectory() as directory:
            target=Path(directory)/"人工結果.json.gz";ref=runner.save_gzip(target,result)
            decoded,_=data.read_ref(data.FileRef(target,ref["sha256"],ref["decoded_sha256"]))
            self.assertEqual(result,decoded)
            corrupted=bytearray(target.read_bytes());corrupted[-8]^=1;target.write_bytes(corrupted)
            with self.assertRaises(Exception):data.read_ref(data.FileRef(target,data.sha(target),ref["decoded_sha256"]))


if __name__ == "__main__":
    unittest.main(verbosity=2)
