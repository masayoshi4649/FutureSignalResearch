"""159の人工だけを実行し、自然学習前のSourceを停止する。"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
FORMAL = ROOT / "study/00159_延伸する局面を複合技術から学ぶ"
EXPECTED = {FORMAL / "実行条件.md": "8899a5a1b378abd669ec9003ded19930c4e315879b76dc67517dd0b5e4e6bdb3", FORMAL / "文法と学習の固定.json": "86fa33f1e1111ddc2665e1cb6c68c7b4dae5dfc61feff0132ef144064966891a"}


def sha(path: Path) -> str:
    """小さい源の物理SHAを返す。

    引数: path (Path)。返り値: str 型のSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """UTF-8 strictの人工・構文と源同体を確認する。

    引数: なし。
    返り値: None。自然入力・モデルは作らない。
    """
    sources = sorted([*HERE.glob("*.py"), HERE / "README.md", *EXPECTED])
    before = {path.relative_to(ROOT).as_posix(): sha(path) for path in sources}
    for path, expected in EXPECTED.items():
        assert sha(path) == expected
    logs = []
    for arguments in ([sys.executable, "-X", "utf8", "人工検査.py"], [sys.executable, "-X", "utf8", "-m", "py_compile", "data159.py", "rules159.py", "実行する.py", "人工検査.py", "準備する.py"], [sys.executable, "-X", "utf8", "実行する.py", "--help"]):
        result = subprocess.run(arguments, cwd=HERE, env={**os.environ, "PYTHONUTF8": "1"}, capture_output=True, text=True, encoding="utf-8", errors="strict")
        assert result.returncode == 0 and "\ufffd" not in result.stdout + result.stderr, result.stderr
        logs.append({"arguments": arguments, "code": result.returncode, "stdout": result.stdout, "stderr": result.stderr})
    assert before == {path.relative_to(ROOT).as_posix(): sha(path) for path in sources}
    proof = {"成功": True, "試行": 159, "自然snapshot本文読取": False, "親金融本文読取": False, "自然学習": False, "自然採否": False, "人工主群": 7, "predicate数": 124, "AND組数": 6232, "規則数_fit": 12464, "モデル適用枠": 9, "重複除去訓練窓": 6, "結果条件数": 24, "Python": sys.version, "NumPy": np.__version__, "CLI": "work/159複合条件の延伸選択/実行する.py", "ログ": logs, "源SHA256": before, "前後同体": True}
    target = HERE / "準備の確認.json"
    target.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    stopped = {"成功": True, "試行": 159, "準備票SHA256": sha(target), "源SHA256": before, "自然実行": "Root通知後にRootが一度", "編集停止": True}
    stop = HERE / "停止.json"
    stop.write_text(json.dumps(stopped, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"成功": True, "準備SHA256": sha(target), "停止SHA256": sha(stop)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
