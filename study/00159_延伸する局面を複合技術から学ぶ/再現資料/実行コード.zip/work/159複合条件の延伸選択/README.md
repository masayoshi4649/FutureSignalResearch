# 159：＋125で複合条件から延伸を選ぶ

Root固定159条件に従うCPU/NumPy部品。158の入口837物理case・924所属・73場を維持する。新Raw・新約定再生・方向変更・入口選別を行わない。自然学習はRoot通知後だけ。全73場は既使用であり、因果的な過去場適用を未使用データ検証とは呼ばない。

正本：`study/00159_延伸する局面を複合技術から学ぶ/実行条件.md`（8899a5a1b378abd669ec9003ded19930c4e315879b76dc67517dd0b5e4e6bdb3）、同 `文法と学習の固定.json`（86fa33f1e1111ddc2665e1cb6c68c7b4dae5dfc61feff0132ef144064966891a）。コードの25式・役割・境界・区画を構造同体照合する。

## 分離と数学的prefix

`data159.py` はgate特徴、教師、保存3行動を分離する。`rules159.py` は124predicate・異役割AND6,232組×2延伸行動を全列挙する。`fit_rule(TrainingBatch)` は過去だけに射影済みの教師を受け、`apply_model(model,derived)` はlabelを受けない。

C0=F125S125、C1=T125W100TP250、C2=A11_PROFIT_BUDGET。C0が初めてTP125を要求する直前まで、全3行動は同じ初期SL125で、C1/C2の起動は125、起動前追尾・早期技術退出はない。C1のTP250は125より先に発生できず、C2はTPなし。このためSL・品質・期限・返済予約も共通であり、query原行で行動を切り替えた保存結果を合成できる。同原行の250飛越は、その原行でC1が要求する合法な分岐として扱う。

保存票では全case×H/D/cで、3行動のentry/期限/費用、最初125Quote、queryより前のarm/退出がないことを確認する。nonTPは全損益・fill・保有metricsが同体であることを確認しC0を保持する。数学的契約とこの保存結果検査の範囲であり、未来経路を見て分岐させたものではない。

教師はmain H60/D1/C5の3行動全closedかつ全損益既知だけ。known_at=max3fill.timeをstrictにcutoff前へ制限し、現在場・将来場はfitへ渡さない。共有87をmembership別に水増ししない。未知は全3labelをNaNとし、ゼロ利益へ補完しない。

一致12教師/6場、場分母はmatched数でなく全eligible教師n_j。score=sum(d_j)−max(0,max d_j)−.5sum(max(0,−d_j))、score>1e−9だけ採用。最大score→一致教師多→C1優先→predicate lexical。未知predicateは>=/<の両方false。

G01_F48は先頭48場IFD→1モデルを後25へ固定、G02_EXP12/G03_WIN36は先頭24場IFD→24/36/48/60起点の4区画。後者は直前最大36場、前者は過去全部。9適用枠・6unique訓練窓で同じ訓練窓は再利用する。主教師の同じモデルを全H/D/cへ適用するが、各Hの最初C0TP125当時特徴だけで判定する。

## 実動

repo rootから次をRoot固定後に実行する。既存出力先は上書きしない。

```powershell
& 'work/複合テクニカル学習環境/Scripts/python.exe' -X utf8 'work/159複合条件の延伸選択/実行する.py' `
 --snapshot 'inputs/00159_延伸判断の特徴/判断時点の特徴.json.gz' `
 --snapshot-sha256 b7be610367196246af4125cabc10ea46157d4068896d29c35d0939084b41a148 `
 --snapshot-decoded-sha256 3ac97f2372c3c58b5c0e2584e0d72b27f08f3a50dec6c2cfcfe40e85db63fe7e `
 --parent-result 'study/00158_複合技術で出口の役割と局面を切り替える/成果物/出口結果.json.gz' `
 --parent-result-sha256 70a4c3178206bbb3c8641901c7515f2121da11c28403b88c3f8e6f93cc0baa6c `
 --parent-result-decoded-sha256 3c3df90244de838056ca7c98857ffe7b8f85514807e90194c07f73129ec277c7 `
 --spec 'study/00159_延伸する局面を複合技術から学ぶ/実行条件.md' --spec-sha256 8899a5a1b378abd669ec9003ded19930c4e315879b76dc67517dd0b5e4e6bdb3 `
 --book 'study/00159_延伸する局面を複合技術から学ぶ/文法と学習の固定.json' --book-sha256 86fa33f1e1111ddc2665e1cb6c68c7b4dae5dfc61feff0132ef144064966891a `
 --execute-after-f0 <Root固定票path> --f0-sha256 <固定票SHA> --output-dir <未作成先>
```

出力は `モデルと学習報告.json`（全9枠/上位10/score/支持・成熟/探索数）、`全gateの出口選択.json`（label無し採否）、`固定入口の出口合成.json.gz`（G3×H2×D2×C2=24結果/case）、`完了の確認.json`。親19政策は再転記せずRoot集計が共有する。親のcash/MFE/holding等は選択pathと同体、親technical_traceは複製せずcountsと親SHA/case/config参照をparent_diagnosticsへ退避する。新gate発動の回数と親診断を混同しない。

人工は全eligible重み、最良場除去/負場罰、支持下限/同点、unknown、成熟等号、未来label改変、warmup、売買鏡像、共通prefix/早期退出拒否、nonTP同体、G24合成、gzipCRCを扱う。準備器は自然snapshot/結果本文を開かない。F0の全源照合はRoot運転部、このCLIは明示F0・spec/book・両gzipの前後SHA/statと全CRCへ束縛する。
