"""159の過去教師学習・label無し適用・保存3経路合成を順に行う。"""
from __future__ import annotations

import argparse
import copy
import gzip
import hashlib
import json
import os
from pathlib import Path
import sys

import numpy as np

import data159 as data
import rules159 as rules

HERE = Path(__file__).resolve().parent
SPEC_SHA = "8899a5a1b378abd669ec9003ded19930c4e315879b76dc67517dd0b5e4e6bdb3"
BOOK_SHA = "86fa33f1e1111ddc2665e1cb6c68c7b4dae5dfc61feff0132ef144064966891a"
POLICIES = ("G01_F48", "G02_EXP12", "G03_WIN36")


def save_json(path: Path, value: object) -> dict:
    """小さい新規JSONをUTF-8で保存する。

    引数: path (Path)、value (object) JSON可能値。
    返り値: dict 型のpath/SHA/bytes。既存ファイルは上書きしない。
    """
    body = (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")
    with path.open("xb") as target:
        target.write(body)
    return {"path": str(path.resolve()), "sha256": hashlib.sha256(body).hexdigest(), "bytes": len(body)}


def save_gzip(path: Path, value: object) -> dict:
    """解凍副本なしで結果を新規gzipへ保存する。

    引数: path (Path)、value (object) 結果JSON。
    返り値: dict 型の物理/解凍SHA・サイズ。
    """
    digest, size = hashlib.sha256(), 0
    encoder = json.JSONEncoder(ensure_ascii=False, separators=(",", ":"), allow_nan=False)
    with path.open("xb") as target:
        with gzip.GzipFile(filename="", mode="wb", fileobj=target, mtime=0) as zipped:
            for text in encoder.iterencode(value):
                body = text.encode("utf-8")
                digest.update(body); size += len(body); zipped.write(body)
            zipped.write(b"\n"); digest.update(b"\n"); size += 1
        target.flush(); os.fsync(target.fileno())
    return {"path": str(path.resolve()), "sha256": data.sha(path), "decoded_sha256": digest.hexdigest(), "bytes": path.stat().st_size, "decoded_bytes": size}


def compose(gates: data.GateDataset, indexed: dict, choices: list[dict], parent_sha: str, model_refs: dict) -> dict:
    """固定採否へ選択された親Resultを対応させる。

    引数: gates (GateDataset)、indexed (dict)、choices (list[dict])、parent_sha (str)、model_refs (dict)。
    返り値: dict 型のG24結果/case。選択と同じ関数へlabelを渡さない。
    """
    lookup = {(row["policy"], row["case_id"], row["horizon"]): row for row in choices}
    assert len(lookup) == len(choices) == len(gates.rows) * 3
    scenes = [{**copy.deepcopy(scene), "cases": []} for scene in gates.scenes]
    for case_id, parent in indexed.items():
        case = {key: copy.deepcopy(parent[key]) for key in ("id", "original_side", "side", "stream", "entry", "entry_price", "memberships")}
        case["results"] = []
        for policy in POLICIES:
            for horizon in data.HORIZONS:
                choice = lookup[policy, case_id, horizon]
                for delay in data.DELAYS:
                    for cost in data.COSTS:
                        case["results"].append(data.recompose_result(parent, horizon, delay, cost, choice["action"], policy, choice, parent_sha))
        assert len(case["results"]) == 24
        scenes[parent["session_index"]]["cases"].append(case)
    configurations = [{"id": "/".join((policy, horizon, delay, cost)), "policy": policy, "horizon": horizon, "delay": delay, "cost": cost, "fee_yen": 77 if cost == "C0" else 1077} for policy in POLICIES for horizon in data.HORIZONS for delay in data.DELAYS for cost in data.COSTS]
    return {"success": True, "trial": 159, "schema": "recomposed_exit_results159_v1", "method": "共通prefixによる保存経路の合成", "financial_labels_used_for_past_training": True, "current_or_future_labels_used_for_gate": False, "raw_read": False, "new_execution_simulation": False, "entry_changed": False, "configurations": configurations, "configuration_count": 24, "scene_count": len(scenes), "case_count": len(indexed), "membership_count": sum(len(case["memberships"]) for case in indexed.values()), "model_refs": model_refs, "scenes": scenes}


def execute(options: argparse.Namespace) -> dict:
    """F0を確認して射影→fit→保存model→apply→合成を実行する。

    引数: options (Namespace) 明示path/SHA。
    返り値: dict 型の全完了票。自然実行はRoot通知後だけ。
    """
    output = Path(options.output_dir).resolve()
    assert not output.exists(), "未作成の出力先だけを使用する"
    inputs = [(Path(options.execute_after_f0), options.f0_sha256), (Path(options.spec), options.spec_sha256), (Path(options.book), options.book_sha256)]
    assert options.spec_sha256 == SPEC_SHA and options.book_sha256 == BOOK_SHA
    for path, expected in inputs:
        assert len(expected) == 64 and data.sha(path) == expected
    book = json.loads(Path(options.book).read_text(encoding="utf-8-sig"))
    rules.validate_book(book)
    assert options.parent_result_sha256 == book["snapshot_parent"]["result_sha256"]
    sources = {p.name: data.sha(p) for p in sorted(HERE.glob("*.py"))}
    snapshot, snapshot_read = data.read_ref(data.FileRef(options.snapshot, options.snapshot_sha256, options.snapshot_decoded_sha256))
    parent_reference = snapshot["input_refs"]["results158"]
    assert parent_reference["actual_sha256"] == options.parent_result_sha256 and parent_reference["decoded_sha256"] == options.parent_result_decoded_sha256
    assert snapshot["input_refs"]["feature_manifest158"]["sha256"] == book["snapshot_parent"]["features_sha256"]
    assert snapshot["input_refs"]["specification159"]["sha256"] == SPEC_SHA
    gates = data.gate_dataset(snapshot)
    assert len(gates.scenes) == 73 and len(gates.rows) == 1674 and len(gates.columns) == 149
    del snapshot
    parent, parent_read = data.read_ref(data.FileRef(options.parent_result, options.parent_result_sha256, options.parent_result_decoded_sha256))
    indexed, parent_scenes = data.action_index(parent)
    assert gates.scenes == parent_scenes and len(indexed) == 837
    parent_header = {key: copy.deepcopy(value) for key, value in parent.items() if key not in ("scenes", "configurations")}
    del parent
    prefix = data.verify_common_prefix(gates, indexed)
    teacher = data.project_teachers(gates, indexed)
    print("共通prefix検査成功、過去6区画の学習へ", file=sys.stderr)
    models, choices = rules.walk_forward(gates, teacher)
    assert sum(map(len, models.values())) == 9
    assert len({model["model_id"] for rows in models.values() for model in rows}) == 6
    output.mkdir(parents=True, exist_ok=False)
    model_report = {"success": True, "trial": 159, "schema": "walkforward_models159_v1", "model_slots": 9, "unique_training_windows": 6, "minimum_score": 1e-9, "dictionary": rules.fixed_features(), "predicate_dictionary_sha256": rules.canonical_sha(rules.dictionary()), "teacher_total": len(teacher.rows), "eligible_teachers": int(teacher.eligible.sum()), "unknown_or_non_gate_teachers": int((~teacher.eligible).sum()), "prefix": prefix, "models": models}
    model_ref = save_json(output / "モデルと学習報告.json", model_report)
    choice_ref = save_json(output / "全gateの出口選択.json", {"success": True, "trial": 159, "schema": "gate_choices159_v1", "models_ref": model_ref, "snapshot_ref": snapshot_read, "rows": choices})
    print("9適用モデルと選択票を保存、親3経路を合成", file=sys.stderr)
    result = compose(gates, indexed, choices, options.parent_result_sha256, {"models": model_ref, "choices": choice_ref})
    result["source_refs"] = {"snapshot": snapshot_read, "parent_result": parent_read, "parent_header": parent_header, "specification": {"path": str(Path(options.spec).resolve()), "sha256": SPEC_SHA}, "book": {"path": str(Path(options.book).resolve()), "sha256": BOOK_SHA}, "f0": {"path": str(Path(options.execute_after_f0).resolve()), "sha256": options.f0_sha256}, "source_sha256": sources}
    result_ref = save_gzip(output / "固定入口の出口合成.json.gz", result)
    for evidence in (snapshot_read, parent_read):
        path = Path(evidence["path"])
        assert data.sha(path) == evidence["sha256"]
        now = path.stat(); fields = ("st_dev", "st_ino", "st_size", "st_mtime_ns")
        assert [getattr(now, key) for key in fields] == evidence["stat_after"]
    for path, expected in inputs:
        assert data.sha(path) == expected
    assert sources == {p.name: data.sha(p) for p in sorted(HERE.glob("*.py"))}
    done = {"success": True, "trial": 159, "result": result_ref, "models": model_ref, "choices": choice_ref, "prefix": prefix, "model_slots": 9, "unique_training_windows": 6, "configuration_count": 24, "case_count": 837, "membership_count": result["membership_count"], "teacher_total": len(teacher.rows), "eligible_teachers": int(teacher.eligible.sum()), "snapshot": snapshot_read, "parent": parent_read, "source_unchanged": True, "raw_read": False, "current_or_future_labels_used_for_gate": False}
    save_json(output / "完了の確認.json", done)
    return done


def main() -> None:
    """明示されたF0と指紋だけを受け取るCLI。

    引数: CLI flags。
    返り値: None。失敗時は非0で終了しsuccess票を書かない。
    """
    parser = argparse.ArgumentParser()
    for flag in ("snapshot", "snapshot-sha256", "snapshot-decoded-sha256", "parent-result", "parent-result-sha256", "parent-result-decoded-sha256", "spec", "spec-sha256", "book", "book-sha256", "execute-after-f0", "f0-sha256", "output-dir"):
        parser.add_argument("--" + flag, required=True)
    options = parser.parse_args()
    print(json.dumps(execute(options), ensure_ascii=False, allow_nan=False))


if __name__ == "__main__":
    main()
