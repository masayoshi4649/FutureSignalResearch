"""事前固定した異役割2条件ANDだけを過去場教師で選ぶ。"""
from __future__ import annotations

from dataclasses import dataclass
import copy
import hashlib
import itertools
import json
import math

import numpy as np

from data159 import GateDataset, TeacherDataset

DEFINITIONS = (
    ("gap5_atr5", "trend", (0, .25, .5)),
    ("gap15_atr15", "trend", (0, .25)),
    ("gap30_atr30", "trend", (0,)),
    ("slope5_atr5", "trend", (0, .02)),
    ("slope15_atr15", "trend", (0,)),
    ("slope30_atr30", "trend", (0,)),
    ("di1", "trend", (0, 10)),
    ("adx15", "trend", (15, 20, 25)),
    ("hist1_atr1", "momentum", (0, .02)),
    ("hist5_atr5", "momentum", (0, .02)),
    ("hist_delta1_atr1", "momentum", (0,)),
    ("rsi_signed", "momentum", (-10, 0, 10)),
    ("cmf_signed", "volume", (-.1, 0, .1)),
    ("obv_delta5_signed", "volume", (0,)),
    ("rvol1", "volume", (.8, 1.2, 1.5)),
    ("er10", "volatility", (.25, .35, .5, .65)),
    ("chop14", "volatility", (38.2, 50, 61.8)),
    ("bb_width_ratio", "volatility", (.8, 1, 1.2)),
    ("atr1_atr5", "volatility", (.1, .2, .4)),
    ("close_ema8_atr1", "structure", (-.5, 0, .5)),
    ("zscore_signed", "structure", (0, 1, 2)),
    ("body_atr1", "structure", (0, 1)),
    ("forward5_atr1", "structure", (-.5, 0, .5)),
    ("opposite5_atr1", "structure", (0, 1, 2)),
    ("elapsed_minutes", "clock", (.5, 2, 5, 10, 20)),
)
DERIVED_NAMES = tuple(row[0] for row in DEFINITIONS)
FORMULAS = (
    "s*m5.gap/m5.atr14", "s*m15.gap/m15.atr14", "s*m30.gap/m30.atr14",
    "s*m5.ema21_delta/m5.atr14", "s*m15.ema21_delta/m15.atr14", "s*m30.ema21_delta/m30.atr14",
    "s*m1.di_difference", "m15.adx", "s*m1.hist/m1.atr14", "s*m5.hist/m5.atr14", "s*m1.hist_delta/m1.atr14",
    "s*(m1.rsi14-50)", "s*m1.cmf20", "s*m1.obv_delta5", "m1.rvol", "m1.er10", "m1.chop14",
    "m1.bb_width/m1.previous_bb_width", "m1.atr14/m5.atr14", "s*(m1.close-m1.ema8)/m1.atr14", "s*m1.zscore", "s*m1.body/m1.atr14",
    "s*(m1.close-(buy?m1.prior_high5:m1.prior_low5))/m1.atr14",
    "s*(m1.close-(buy?m1.prior_low5:m1.prior_high5))/m1.atr14", "(gate.time-entry.time)/60",
)


@dataclass
class TrainingBatch:
    derived: np.ndarray
    net: np.ndarray
    session_indices: np.ndarray
    rows: list[dict]
    start: int
    end: int
    cutoff: float


def canonical_sha(value: object) -> str:
    """モデル条件を再現可能なJSON表現で指紋化する。

    引数: value (object) JSON可能な値。
    返り値: str 型。自己SHA欄は呼出し側で含めない。
    """
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")).hexdigest()


def dictionary() -> list[dict]:
    """採用通知の各閾値へ>=と<を割り当てる。

    引数: なし。
    返り値: list[dict] 型の辞書順124predicate。未知は両方false。
    """
    result = []
    for name, role, thresholds in DEFINITIONS:
        for threshold in thresholds:
            for op in (">=", "<"):
                result.append({"id": f"{role}/{name}/{op}{threshold:.15g}", "feature": name, "role": role, "op": op, "threshold": float(threshold)})
    result.sort(key=lambda row: row["id"])
    assert len(result) == 124 and len({row["id"] for row in result}) == 124
    return result


def fixed_features() -> list[dict]:
    """式をevalせずRoot固定bookと構造比較できる形で公開する。

    引数: なし。
    返り値: list[dict] 型の25派生量。
    """
    return [{"name": name, "role": role, "thresholds": list(thresholds), "formula": formula} for (name, role, thresholds), formula in zip(DEFINITIONS, FORMULAS)]


def validate_book(book: dict) -> None:
    """Root固定辞書・境界・適用区画と実装を照合する。

    引数: book (dict) 学習前固定JSON。
    返り値: None。不一致は学習前に停止する。
    """
    assert book["試行"] == 159 and book["学習前固定"] is True
    assert book["特徴"] == fixed_features()
    for key, expected in {"predicate_ops": [">=", "<"], "feature_count": 25, "predicate_count": 124, "pair_count": 6232, "action_count": 2, "rule_count_per_fit": 12464, "min_matched_teachers": 12, "min_matched_sessions": 6, "minimum_score": 1e-9, "model_slots": 9, "unique_training_windows": 6}.items():
        assert book[key] == expected, key
    expected_blocks = {"G01_F48": [[48, 73]], "G02_EXP12": [[24, 36], [36, 48], [48, 60], [60, 73]], "G03_WIN36": [[24, 36], [36, 48], [48, 60], [60, 73]]}
    assert {row["id"]: row["blocks"] for row in book["policies"]} == expected_blocks


def derive(gates: GateDataset, indices: list[int] | np.ndarray | None = None) -> np.ndarray:
    """149物理特徴を固定25量へ方向正規化する。

    引数: gates (GateDataset)、indices (list[int]|ndarray|None) 対象行。
    返り値: ndarray[float64] 型。分母非正・未知はNaNのまま。
    """
    ids = np.arange(len(gates.rows)) if indices is None else np.asarray(indices, dtype=np.int64)
    positions = {name: i for i, name in enumerate(gates.columns)}
    required = {"m1.atr14", "m5.atr14", "m15.atr14", "m30.atr14", "m1.di_difference", "m15.adx", "m1.hist", "m5.hist", "m1.hist_delta", "m1.rsi14", "m1.cmf20", "m1.obv_delta5", "m1.rvol", "m1.er10", "m1.chop14", "m1.bb_width", "m1.previous_bb_width", "m1.close", "m1.ema8", "m1.zscore", "m1.body", "m1.prior_high5", "m1.prior_low5"}
    required |= {f"m{width}.{name}" for width in (5, 15, 30) for name in ("gap", "ema21_delta")}
    assert required <= set(positions), sorted(required - set(positions))
    x = gates.X[ids]
    side = np.asarray([gates.rows[i]["side"] for i in ids], dtype=np.float64)

    def column(name: str) -> np.ndarray:
        """固定列を取得する。

        引数: name (str) 既存149列名。
        返り値: ndarray[float64] 型の参照。
        """
        return x[:, positions[name]]

    def ratio(numerator: np.ndarray, denominator: np.ndarray) -> np.ndarray:
        """分母正・両既知だけを除算する。

        引数: numerator/denominator (ndarray) 数列。
        返り値: ndarray[float64] 型。
        """
        result = np.full(len(ids), np.nan)
        mask = np.isfinite(numerator) & np.isfinite(denominator) & (denominator > 0)
        np.divide(numerator, denominator, out=result, where=mask)
        return result

    values = {}
    for width in (5, 15, 30):
        atr = column(f"m{width}.atr14")
        values[f"gap{width}_atr{width}"] = ratio(side * column(f"m{width}.gap"), atr)
        values[f"slope{width}_atr{width}"] = ratio(side * column(f"m{width}.ema21_delta"), atr)
    atr1, atr5, close = column("m1.atr14"), column("m5.atr14"), column("m1.close")
    values.update({
        "di1": side * column("m1.di_difference"),
        "adx15": column("m15.adx"),
        "hist1_atr1": ratio(side * column("m1.hist"), atr1),
        "hist5_atr5": ratio(side * column("m5.hist"), atr5),
        "hist_delta1_atr1": ratio(side * column("m1.hist_delta"), atr1),
        "rsi_signed": side * (column("m1.rsi14") - 50),
        "cmf_signed": side * column("m1.cmf20"),
        "obv_delta5_signed": side * column("m1.obv_delta5"),
        "rvol1": column("m1.rvol"),
        "er10": column("m1.er10"),
        "chop14": column("m1.chop14"),
        "bb_width_ratio": ratio(column("m1.bb_width"), column("m1.previous_bb_width")),
        "atr1_atr5": ratio(atr1, atr5),
        "close_ema8_atr1": ratio(side * (close - column("m1.ema8")), atr1),
        "zscore_signed": side * column("m1.zscore"),
        "body_atr1": ratio(side * column("m1.body"), atr1),
        "forward5_atr1": ratio(side * (close - np.where(side > 0, column("m1.prior_high5"), column("m1.prior_low5"))), atr1),
        "opposite5_atr1": ratio(side * (close - np.where(side > 0, column("m1.prior_low5"), column("m1.prior_high5"))), atr1),
        "elapsed_minutes": np.asarray([np.nan if gates.rows[i]["gate"] is None else (gates.rows[i]["gate"]["time"] - gates.rows[i]["entry"]["time"]) / 60 for i in ids], dtype=np.float64),
    })
    return np.column_stack([values[name] for name in DERIVED_NAMES])


def predicate_masks(derived: np.ndarray, predicates: list[dict] | None = None) -> np.ndarray:
    """既知比較だけを真にするpredicate行列を作る。

    引数: derived (ndarray)、predicates (list[dict]|None) 固定条件。
    返り値: ndarray[bool] 型のpredicate×行。
    """
    predicates = dictionary() if predicates is None else predicates
    positions = {name: i for i, name in enumerate(DERIVED_NAMES)}
    masks = []
    for predicate in predicates:
        value = derived[:, positions[predicate["feature"]]]
        threshold = predicate["threshold"]
        assert predicate["op"] in (">=", "<") and math.isfinite(threshold)
        compare = value >= threshold if predicate["op"] == ">=" else value < threshold
        masks.append(np.isfinite(value) & compare)
    return np.asarray(masks, dtype=bool).reshape(len(predicates), len(derived))


def select_training(gates: GateDataset, teacher: TeacherDataset, derived: np.ndarray, start: int, end: int, cutoff: float) -> TrainingBatch:
    """過去場かつstrict成熟済み教師だけをfit入力へ写す。

    引数: gates/teacher (Dataset)、derived (ndarray)、start/end (int)、cutoff (float)。
    返り値: TrainingBatch 型。現場以後のlabelは含めない。
    """
    assert 0 <= start <= end <= len(gates.scenes) and math.isfinite(cutoff)
    selected = [i for i, row in enumerate(teacher.rows) if start <= row["session_index"] < end and teacher.eligible[i] and math.isfinite(teacher.known_at[i]) and teacher.known_at[i] < cutoff]
    rows = [copy.deepcopy(teacher.rows[i]) for i in selected]
    for i,row in zip(selected,rows):
        assert row["eligible"] is True and row["known_at"] == teacher.known_at[i]
    feature_indices = [row["feature_index"] for row in rows]
    return TrainingBatch(derived[feature_indices].copy(), teacher.net[selected].copy(), np.asarray([row["session_index"] for row in rows], dtype=np.int64), rows, start, end, cutoff)


def fit_rule(batch: TrainingBatch) -> dict:
    """異役割2predicateを全列挙し固定scoreで1規則を選ぶ。

    引数: batch (TrainingBatch) 過去だけへ分離済みの教師。
    返り値: dict 型のモデル・上位10・探索数。合格無しはselected_rule=None。
    """
    assert batch.derived.shape == (len(batch.rows), len(DERIVED_NAMES)) and batch.net.shape == (len(batch.rows), 3)
    assert np.isfinite(batch.net).all()
    for row in batch.rows:
        assert row["eligible"] is True and batch.start <= row["session_index"] < batch.end and row["known_at"] < batch.cutoff
    predicates = dictionary()
    masks = predicate_masks(batch.derived, predicates)
    pairs = [(i, j) for i, j in itertools.combinations(range(len(predicates)), 2) if predicates[i]["role"] != predicates[j]["role"]]
    assert len(pairs) == 6232
    counts = np.bincount(batch.session_indices, minlength=batch.end) if len(batch.rows) else np.zeros(batch.end, dtype=np.int64)
    winners, qualified, positive = [], 0, 0
    delta = batch.net[:, 1:] - batch.net[:, 0, None]
    for i, j in pairs:
        matched = masks[i] & masks[j]
        n = int(matched.sum())
        if n < 12:
            continue
        scenes = np.unique(batch.session_indices[matched])
        if len(scenes) < 6:
            continue
        for action_index, action in enumerate(("C1", "C2")):
            qualified += 1
            totals = np.bincount(batch.session_indices[matched], weights=delta[matched, action_index], minlength=batch.end)
            contributions = np.divide(totals, counts, out=np.zeros_like(totals), where=counts > 0)
            score = float(contributions.sum() - max(0.0, float(contributions.max(initial=0))) - .5 * np.maximum(0, -contributions).sum())
            if score <= 1e-9:
                continue
            positive += 1
            candidate = {"action": action, "predicates": [copy.deepcopy(predicates[i]), copy.deepcopy(predicates[j])], "score": score, "matched_teachers": n, "matched_scenes": int(len(scenes)), "scene_contributions": {str(int(scene)): float(contributions[scene]) for scene in scenes}}
            winners.append(candidate)
    winners.sort(key=lambda rule: (-rule["score"], -rule["matched_teachers"], 0 if rule["action"] == "C1" else 1, tuple(predicate["id"] for predicate in rule["predicates"])))
    result = {"schema": "rule_model159_v1", "dictionary_sha256": canonical_sha(predicates), "training_start_index": batch.start, "training_end_exclusive": batch.end, "cutoff": batch.cutoff, "teacher_count": len(batch.rows), "teacher_scenes": int(len(np.unique(batch.session_indices))), "teacher_case_ids": [row["case_id"] for row in batch.rows], "maturity_max": max((row["known_at"] for row in batch.rows), default=None), "scene_denominators": {str(i): int(n) for i, n in enumerate(counts) if n > 0}, "predicate_count": 124, "candidate_pairs": len(pairs), "candidate_rules": len(pairs) * 2, "support_qualified_rules": qualified, "positive_score_rules": positive, "selected_rule": copy.deepcopy(winners[0]) if winners else None, "top10": copy.deepcopy(winners[:10])}
    result["training_net_sha256"]=hashlib.sha256(np.ascontiguousarray(batch.net).tobytes()).hexdigest()
    result["training_features_sha256"]=hashlib.sha256(np.ascontiguousarray(batch.derived).tobytes()).hexdigest()
    result["minimum_score"]=1e-9
    result["model_id"] = canonical_sha(result)
    return result


def apply_model(model: dict | None, derived: np.ndarray) -> list[str]:
    """固定モデル条件だけで行動を選びlabelを受け取らない。

    引数: model (dict|None)、derived (ndarray) 当時特徴。
    返り値: list[str] 型のC0/C1/C2。未知又は不成立はC0。
    """
    result = np.full(len(derived), "C0", dtype="<U2")
    if model is not None and model["selected_rule"] is not None:
        rule = model["selected_rule"]
        masks = predicate_masks(derived, rule["predicates"])
        result[masks[0] & masks[1]] = rule["action"]
    return result.tolist()


def walk_forward(gates: GateDataset, teacher: TeacherDataset) -> tuple[dict, list[dict]]:
    """3つの事前区画でfitとlabel無しapplyを分ける。

    引数: gates (GateDataset)、teacher (TeacherDataset)。
    返り値: tuple[dict, list[dict]] 型の9モデルと全case×Hの判断票。
    """
    assert len(gates.scenes) == 73
    assert all(math.isfinite(scene["start"]) for scene in gates.scenes)
    assert all(gates.scenes[i]["start"] < gates.scenes[i+1]["start"] for i in range(72))
    derived = derive(gates)
    schedules = {"G01_F48": [(48, 73, 0)], "G02_EXP12": [(i, 73 if i == 60 else i + 12, 0) for i in (24, 36, 48, 60)], "G03_WIN36": [(i, 73 if i == 60 else i + 12, max(0, i - 36)) for i in (24, 36, 48, 60)]}
    models, choices, cache = {}, [], {}
    for policy, blocks in schedules.items():
        assigned, policy_models = {}, []
        for first, last, training_start in blocks:
            cutoff = gates.scenes[first]["start"]
            batch = select_training(gates, teacher, derived, training_start, first, cutoff)
            cache_key=(training_start,first,cutoff)
            if cache_key not in cache:
                cache[cache_key]=fit_rule(batch)
            model=copy.deepcopy(cache[cache_key])
            model = {**model, "policy": policy, "application_start_index": first, "application_end_exclusive": last}
            policy_models.append(model)
            ids = [i for i, row in enumerate(gates.rows) if first <= row["session_index"] < last]
            actions = apply_model(model, derived[ids])
            for index, action in zip(ids, actions):
                assigned[index] = action, model["model_id"], model["selected_rule"] is not None
        models[policy] = policy_models
        for i, row in enumerate(gates.rows):
            action, model_id, has_rule = assigned.get(i, ("C0", None, False))
            if row["gate"] is None:
                action = "C0"
            choices.append({"policy": policy, "case_id": row["case_id"], "session": row["session"], "session_index": row["session_index"], "horizon": row["horizon"], "feature_index": i, "action": action, "model_id": model_id, "gate": copy.deepcopy(row["gate"]), "reason": "nonTP_C0保持" if row["gate"] is None else "warmup_IFD" if model_id is None else "合格規則なし_IFD" if not has_rule else "AND成立_延伸" if action != "C0" else "AND不成立又は未知_IFD", "model_has_rule": has_rule})
    return models, choices
