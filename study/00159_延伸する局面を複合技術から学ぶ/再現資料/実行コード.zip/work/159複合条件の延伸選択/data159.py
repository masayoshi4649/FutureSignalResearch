"""159のgate特徴・3出口教師・保存経路合成を分離する。"""
from __future__ import annotations

from dataclasses import dataclass
import copy
import gzip
import hashlib
import json
import math
from pathlib import Path

import numpy as np

ACTIONS = {"C0": "F125S125", "C1": "T125W100TP250", "C2": "A11_PROFIT_BUDGET"}
HORIZONS = ("H60", "SESSION")
DELAYS = ("D0", "D1")
COSTS = ("C0", "C5")
QUOTE_KEYS = ("time", "index", "source_line", "clock", "last", "bid", "ask", "quote_ok")
PREFIX_KEYS = ("status", "unknown_reason", "deadline", "fee_yen", "entry_mark_points", "profit_points", "profit_yen", "trigger", "fill", "held_seconds", "armed", "arm_quote", "stop_points", "peak_points", "peak_quote", "trough_points", "trough_quote", "positive_seen", "first_positive_quote", "reached125", "first125_quote", "profit_after_positive_loss", "profit_after125_loss", "giveback_points", "observed_rows", "bad_bbo_rows", "last_ohlc")


@dataclass(frozen=True)
class FileRef:
    path: str | Path
    sha256: str
    decoded_sha256: str


@dataclass
class GateDataset:
    columns: tuple[str, ...]
    X: np.ndarray
    rows: list[dict]
    scenes: list[dict]


@dataclass
class TeacherDataset:
    rows: list[dict]
    net: np.ndarray
    eligible: np.ndarray
    known_at: np.ndarray


def finite_number(value: object) -> bool:
    """boolを数値へ流さず有限実数を判定する。

    引数: value (object) 対象値。
    返り値: bool 型。
    """
    return type(value) in (int, float) and math.isfinite(value)


def sha(path: Path) -> str:
    """入力物理bytesを固定bufferで指紋化する。

    引数: path (Path) 対象ファイル。
    返り値: str 型のSHA256。
    """
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def read_ref(ref: FileRef) -> tuple[dict, dict]:
    """圧縮/解凍SHA・全CRC・前後statを確認して正本を読む。

    引数: ref (FileRef) 明示された入力指紋。
    返り値: tuple[dict, dict] 型のJSONと証跡。解凍副本は書かない。
    """
    path = Path(ref.path)
    before = path.stat()
    for expected in (ref.sha256, ref.decoded_sha256):
        assert len(expected) == 64 and set(expected) <= set("0123456789abcdef")
    assert sha(path) == ref.sha256
    with path.open("rb") as source:
        compressed = source.read(2) == b"\x1f\x8b"
    with (gzip.open(path, "rb") if compressed else path.open("rb")) as source:
        body = source.read()
    decoded = hashlib.sha256(body).hexdigest()
    assert decoded == ref.decoded_sha256
    value = json.loads(body, parse_constant=lambda token: (_ for _ in ()).throw(ValueError(token)))
    assert isinstance(value, dict)
    after = path.stat()
    fields = ("st_dev", "st_ino", "st_size", "st_mtime_ns")
    assert all(getattr(before, key) == getattr(after, key) for key in fields) and sha(path) == ref.sha256
    return value, {"path": str(path.resolve()), "sha256": ref.sha256, "decoded_sha256": decoded, "physical_bytes": before.st_size, "decoded_bytes": len(body), "gzip_crc_checked": compressed, "stat_before": [getattr(before, key) for key in fields], "stat_after": [getattr(after, key) for key in fields]}


def quote_identity(quote: dict) -> tuple:
    """全8Quoteを比較できる形に正規化する。

    引数: quote (dict) 保存済み原行。
    返り値: tuple 型。省略clockは空文字だけを許容する。
    """
    assert isinstance(quote, dict)
    result = tuple(quote.get(key, "" if key == "clock" else None) for key in QUOTE_KEYS)
    assert all(finite_number(quote.get(key)) for key in ("time", "last", "bid", "ask"))
    assert type(quote["index"]) is int and quote["index"] >= 0
    assert type(quote["source_line"]) is int and quote["source_line"] > 0
    assert type(quote["quote_ok"]) is bool
    return result


def quote_order(quote: dict) -> tuple:
    """時刻・accepted index・物理行の順序を取り出す。

    引数: quote (dict) 原行。
    返り値: tuple[float, int, int] 型。
    """
    quote_identity(quote)
    return quote["time"], quote["index"], quote["source_line"]


def gate_dataset(value: dict) -> GateDataset:
    """label無しgate票を数値行列と識別metadataへ分離する。

    引数: value (dict) gate_snapshots159_v1。
    返り値: GateDataset 型。gate無しもNaN行として保持する。
    """
    assert value["success"] is True and value["trial"] == 159 and value["schema"] == "gate_snapshots159_v1"
    columns = tuple(value["catalog"])
    assert len(columns) == len(set(columns)) and all(isinstance(name, str) and name for name in columns)
    rows, matrix, scenes, seen = [], [], [], set()
    for scene_index, scene in enumerate(value["scenes"]):
        scenes.append({key: copy.deepcopy(scene[key]) for key in ("session", "contract", "start", "end", "force_close", "continuous_end") if key in scene})
        for source in scene["rows"]:
            row = copy.deepcopy(source)
            assert row["session_index"] == scene_index and row["session"] == scene["session"] and row["contract"] == scene["contract"]
            assert row["horizon"] in HORIZONS and row["side"] in (-1, 1)
            key = row["case_id"], row["horizon"]
            assert key not in seen
            seen.add(key)
            quote_identity(row["entry"])
            if row["gate"] is None:
                assert row["values"] is None
                x = [np.nan] * len(columns)
            else:
                quote_identity(row["gate"])
                assert row["gate"]["time"] >= row["entry"]["time"] and row["gate"]["index"] > row["entry"]["index"] and row["gate"]["source_line"] > row["entry"]["source_line"]
                assert set(row["values"]) == set(columns)
                x = []
                for name in columns:
                    item = row["values"][name]
                    assert item is None or finite_number(item)
                    if row.get("known") is not None:
                        assert row["known"][name] is (item is not None)
                    if item is not None and row.get("valid_until") is not None and row["valid_until"][name] is not None:
                        assert row["gate"]["time"] < row["valid_until"][name]
                    x.append(np.nan if item is None else float(item))
            row.pop("values", None)
            rows.append(row)
            matrix.append(x)
    return GateDataset(columns, np.asarray(matrix, dtype=np.float64).reshape(len(rows), len(columns)), rows, scenes)


def action_index(value: dict) -> tuple[dict, list[dict]]:
    """保存158結果から3行動だけを物理case別に射影する。

    引数: value (dict) 保存済み158出口結果。
    返り値: tuple[dict, list[dict]] 型の対応表と場metadata。
    """
    assert value["success"] is True and value["trial"] == 158
    indexed, scenes, physical = {}, [], set()
    selected = set(ACTIONS.values())
    for scene_index, scene in enumerate(value["scenes"]):
        scenes.append({key: copy.deepcopy(scene[key]) for key in ("session", "contract", "start", "end", "force_close", "continuous_end") if key in scene})
        for case in scene["cases"]:
            assert case["id"] not in indexed
            quote_identity(case["entry"])
            assert case["side"] in (-1,1) and case["entry_price"] == case["entry"]["ask" if case["side"] > 0 else "bid"]
            key = (scene["session"], scene["contract"], case["side"], *quote_order(case["entry"]))
            assert key not in physical
            physical.add(key)
            row = {key: copy.deepcopy(case[key]) for key in ("id", "original_side", "side", "stream", "entry", "entry_price", "memberships")}
            row.update({"session": scene["session"], "contract": scene["contract"], "session_index": scene_index, "results": {}})
            for result in case["results"]:
                if result["policy"] not in selected:
                    continue
                action = next(name for name, policy in ACTIONS.items() if policy == result["policy"])
                config = result["horizon"], result["delay"], result["cost"], action
                assert config not in row["results"]
                row["results"][config] = {key:copy.deepcopy(item) for key,item in result.items() if key!="technical_trace"}
            assert len(row["results"]) == 24
            indexed[case["id"]] = row
    return indexed, scenes


def verify_common_prefix(gates: GateDataset, indexed: dict) -> dict:
    """数学的共通prefixの保存結果上の必要条件を全組で確認する。

    引数: gates (GateDataset)、indexed (dict) 3保存行動。
    返り値: dict 型の検査分母。新経路や将来特徴は再構成しない。
    """
    counts = {"gate_groups": 0, "non_gate_groups": 0, "action_comparisons": 0}
    for row in gates.rows:
        case = indexed[row["case_id"]]
        assert row["session"] == case["session"] and row["contract"] == case["contract"] and row["side"] == case["side"]
        assert quote_identity(row["entry"]) == quote_identity(case["entry"])
        for delay in DELAYS:
            for cost in COSTS:
                base = case["results"][row["horizon"], delay, cost, "C0"]
                is_gate = base.get("trigger") is not None and base["trigger"]["reason"] == "take_profit"
                assert is_gate == (row["gate"] is not None)
                if is_gate:
                    assert quote_identity(base["trigger"]["quote"]) == quote_identity(row["gate"])
                    assert base["trigger"]["time"] == row["gate"]["time"] < base["deadline"]
                    assert base["reached125"] is True and quote_identity(base["first125_quote"]) == quote_identity(row["gate"])
                    assert row["gate"]["quote_ok"] is True and 0 < row["gate"]["bid"] < row["gate"]["ask"]
                    assert case["side"]*(row["gate"]["bid" if case["side"]>0 else "ask"]-case["entry_price"]) >= 125
                    counts["gate_groups"] += 1
                else:
                    counts["non_gate_groups"] += 1
                for action in ("C1", "C2"):
                    other = case["results"][row["horizon"], delay, cost, action]
                    assert base["deadline"] == other["deadline"] and base["fee_yen"] == other["fee_yen"]
                    if is_gate:
                        assert other["reached125"] is True
                        assert quote_identity(other["first125_quote"]) == quote_identity(row["gate"])
                        for quote in (other.get("arm_quote"), other.get("fill")):
                            if quote is not None:
                                assert quote["time"] >= row["gate"]["time"] and quote["index"] >= row["gate"]["index"] and quote["source_line"] >= row["gate"]["source_line"]
                        trigger = other.get("trigger")
                        if trigger is not None:
                            assert trigger["time"] >= row["gate"]["time"]
                            if trigger.get("quote") is not None:
                                assert trigger["quote"]["index"] >= row["gate"]["index"] and trigger["quote"]["source_line"] >= row["gate"]["source_line"]
                    else:
                        assert {name: base.get(name) for name in PREFIX_KEYS} == {name: other.get(name) for name in PREFIX_KEYS}
                    counts["action_comparisons"] += 1
    assert {row["case_id"] for row in gates.rows} == set(indexed)
    assert {(row["case_id"],row["horizon"]) for row in gates.rows} == {(case_id,horizon) for case_id in indexed for horizon in HORIZONS}
    return counts


def project_teachers(gates: GateDataset, indexed: dict) -> TeacherDataset:
    """主H60/D1/C5の3損益全既知だけを教師へ射影する。

    引数: gates (GateDataset)、indexed (dict) 保存3行動。
    返り値: TeacherDataset 型。未知を0labelへ変換しない。
    """
    rows, net, eligible, known_at = [], [], [], []
    for feature_index, gate in enumerate(gates.rows):
        if gate["horizon"] != "H60":
            continue
        results = [indexed[gate["case_id"]]["results"]["H60", "D1", "C5", action] for action in ACTIONS]
        complete = gate["gate"] is not None and all(result["status"] == "closed" and finite_number(result.get("profit_yen")) and result.get("fill") is not None and finite_number(result["fill"].get("time")) for result in results)
        maturity = max(result["fill"]["time"] for result in results) if complete else None
        if complete:
            assert maturity >= gate["gate"]["time"]
        rows.append({"case_id": gate["case_id"], "session": gate["session"], "session_index": gate["session_index"], "feature_index": feature_index, "gate_time": None if gate["gate"] is None else gate["gate"]["time"], "eligible": complete, "known_at": maturity})
        net.append([float(result["profit_yen"]) for result in results] if complete else [np.nan] * 3)
        eligible.append(complete)
        known_at.append(np.nan if maturity is None else maturity)
    return TeacherDataset(rows, np.asarray(net, dtype=np.float64).reshape(len(rows), 3), np.asarray(eligible, dtype=bool), np.asarray(known_at, dtype=np.float64))


def recompose_result(case: dict, horizon: str, delay: str, cost: str, action: str, policy_id: str, choice: dict, parent_result_sha: str = "") -> dict:
    """gateで選んだ保存行動結果を全値copyし新政策へ束縛する。

    引数: case (dict)、horizon/delay/cost/action/policy_id (str)、choice (dict)、parent_result_sha (str)。
    返り値: dict 型。再約定や1−p推定は行わない。
    """
    assert action in ACTIONS
    base = case["results"][horizon, delay, cost, "C0"]
    is_gate = base.get("trigger") is not None and base["trigger"]["reason"] == "take_profit"
    assert is_gate or action == "C0"
    result = copy.deepcopy(case["results"][horizon, delay, cost, action])
    original_config = result["config_id"]
    original_policy = result["policy"]
    result["config_id"] = "/".join((policy_id, horizon, delay, cost))
    result["policy"] = policy_id
    counts=result.pop("technical_counts",None)
    result.pop("technical_trace",None)
    result["parent_diagnostics"]={"counts":counts,"parent_result_sha":parent_result_sha,"session":case["session"],"case_id":case["id"],"config_id":original_config}
    result["selected_source_policy"]=original_policy
    result["model_id"]=choice.get("model_id")
    result["gate"]=copy.deepcopy(base["trigger"]["quote"]) if is_gate else None
    result["gate_feature_index"]=choice.get("feature_index")
    result["recomposition159"] = {"method": "共通prefixによる保存経路の合成", "source_config_id": original_config, "source_policy": original_policy, "action": action}
    return result
