"""159の技術文法と因果的モデル更新条件を、自然教師の学習前に固定する。"""
from pathlib import Path
import json
import hashlib
import re

ROOT=Path(__file__).resolve().parents[2]
TRIAL=ROOT/'study/00159_延伸する局面を複合技術から学ぶ'
FEATURES=[
 ('gap5_atr5','trend',[0,.25,.5],'s*m5.gap/m5.atr14'),
 ('gap15_atr15','trend',[0,.25],'s*m15.gap/m15.atr14'),
 ('gap30_atr30','trend',[0],'s*m30.gap/m30.atr14'),
 ('slope5_atr5','trend',[0,.02],'s*m5.ema21_delta/m5.atr14'),
 ('slope15_atr15','trend',[0],'s*m15.ema21_delta/m15.atr14'),
 ('slope30_atr30','trend',[0],'s*m30.ema21_delta/m30.atr14'),
 ('di1','trend',[0,10],'s*m1.di_difference'),
 ('adx15','trend',[15,20,25],'m15.adx'),
 ('hist1_atr1','momentum',[0,.02],'s*m1.hist/m1.atr14'),
 ('hist5_atr5','momentum',[0,.02],'s*m5.hist/m5.atr14'),
 ('hist_delta1_atr1','momentum',[0],'s*m1.hist_delta/m1.atr14'),
 ('rsi_signed','momentum',[-10,0,10],'s*(m1.rsi14-50)'),
 ('cmf_signed','volume',[-.1,0,.1],'s*m1.cmf20'),
 ('obv_delta5_signed','volume',[0],'s*m1.obv_delta5'),
 ('rvol1','volume',[.8,1.2,1.5],'m1.rvol'),
 ('er10','volatility',[.25,.35,.5,.65],'m1.er10'),
 ('chop14','volatility',[38.2,50,61.8],'m1.chop14'),
 ('bb_width_ratio','volatility',[.8,1,1.2],'m1.bb_width/m1.previous_bb_width'),
 ('atr1_atr5','volatility',[.1,.2,.4],'m1.atr14/m5.atr14'),
 ('close_ema8_atr1','structure',[-.5,0,.5],'s*(m1.close-m1.ema8)/m1.atr14'),
 ('zscore_signed','structure',[0,1,2],'s*m1.zscore'),
 ('body_atr1','structure',[0,1],'s*m1.body/m1.atr14'),
 ('forward5_atr1','structure',[-.5,0,.5],'s*(m1.close-(buy?m1.prior_high5:m1.prior_low5))/m1.atr14'),
 ('opposite5_atr1','structure',[0,1,2],'s*(m1.close-(buy?m1.prior_low5:m1.prior_high5))/m1.atr14'),
 ('elapsed_minutes','clock',[.5,2,5,10,20],'(gate.time-entry.time)/60'),
]


def main() -> None:
    """
    機能: 文法JSONとV8設定表を新規保存し、探索数を人工的に検算する。
    引数: なし。返り値: None。価格・教師・損益の本文は読まない。
    """
    predicates=[(name,role,op,t) for name,role,thresholds,formula in FEATURES
        for t in thresholds for op in ('>=','<')]
    pairs=sum(a[1]!=b[1] for i,a in enumerate(predicates) for b in predicates[i+1:])
    assert len(FEATURES)==25 and len(predicates)==124 and pairs==6232
    TRIAL.mkdir(parents=True,exist_ok=True)
    book={'試行':159,'日付':'2026-11-13','学習前固定':True,
        '手法':'異なる役割の技術2条件ANDを過去だけで選び、+125で利確/延伸の出口を切り替える',
        '特徴':[{'name':name,'role':role,'thresholds':thresholds,'formula':formula}
            for name,role,thresholds,formula in FEATURES],
        'predicate_ops':['>=','<'],'feature_count':25,'predicate_count':124,'pair_count':6232,
        'action_count':2,'rule_count_per_fit':12464,
        'continuation_actions':['T125W100TP250','A11_PROFIT_BUDGET'],
        'default_action':'F125S125','missing_predicate':'unknownは>=/<の両方false、延伸せずIFD',
        'min_matched_teachers':12,'min_matched_sessions':6,
        'teacher':'H60/D1/C5、3行動全closed、物理case重複除去、strict known_at<cutoff/past scenesのみ',
        'weight':'1/各場内の全eligible gate教師数n_j。matched数で正規化しない',
        'score':'sum(d_j)-max(0,max(d_j))-.5*sum(max(0,-d_j))、d_j=sum(matched(action_net-IFD_net))/n_j',
        'minimum_score':1e-9,
        'tie_break':['最大score','一致教師数が多い','C1をA11より優先','predicate ID lexical'],
        'policies':[
            {'id':'G01_F48','warmup':48,'blocks':[[48,73]],'training':'0..47を一回、last25へ固定'},
            {'id':'G02_EXP12','warmup':24,'blocks':[[24,36],[36,48],[48,60],[60,73]],'training':'各block startより前の全場'},
            {'id':'G03_WIN36','warmup':24,'blocks':[[24,36],[36,48],[48,60],[60,73]],'training':'各block start前の最大36場'},
        ],
        'model_slots':9,'unique_training_windows':6,'axes':['H60','SESSION','D1','D0','C5','C0'],
        'prediction':'fitした同じmodelを全H/D/cへ。各HのC0最初TP125 Quoteだけでapply、nonTPはIFD',
        'snapshot_parent':{'result_sha256':'70a4c3178206bbb3c8641901c7515f2121da11c28403b88c3f8e6f93cc0baa6c',
            'features_sha256':'a6dce32eb35102d95f44647d0a10811bf13ed6e36f46b08ef0956c52bb783d11'},
    }
    out=TRIAL/'文法と学習の固定.json'
    assert not out.exists()
    out.write_text(json.dumps(book,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    template=(ROOT/'docs/議論/手法と時間スケールの汎用表_版8.md').read_text(encoding='utf-8')
    body=template[template.index('## 手法×時間スケール'):]
    body=body.replace('(../technical-analysis/','(../../docs/technical-analysis/')
    body=body.replace('(逆行200ptより先に順行400ptへ届く入口.md)','(../../docs/議論/逆行200ptより先に順行400ptへ届く入口.md)')
    used={'I01':'MTF gap/slope/Close-EMA8','I03':'Hist/差分、ATR比','I04':'方向RSI50中心',
        'I05':'BBz/幅比','I08':'DI方向/ADX15','I09':'ATRによる単位正規化',
        'I17':'ER10 .25/.35/.5/.65','I18':'CHOP14 38.2/50/61.8',
        'V01':'相対量 .8/1.2/1.5','V02':'方向OBV差5','V06':'方向CMF -.1/0/.1',
        'P01':'実体/価格位置','P02':'直前5足高安への距離','P05':'方向価格差と利確125時点',
        'C07':'MTFを他役割と2条件で判別','M01':'二分岐条件の全列挙、既定文法内のAND2',
        'E01':'158の共通prefix対照3行動','E02':'+125分岐/保存経路合成/連続の利益保護',
        'B01':'実清算BBO/固定C0C1A11の実約定代用'}
    lines=[]
    for line in body.splitlines():
        match=re.match(r'^\| ([ICPVBXME]\d{2}) \| \[',line)
        if match:
            fields=line.split('|')
            for j in range(3,12):
                fields[j]=' 今回の新選択では未使用・未検証 '
            if match.group(1) in used:
                fields[3]=' 159設定：'+used[match.group(1)]+'；学習前準備 '
            line='|'.join(fields)
        lines.append(line)
    (TRIAL/'設定と結果.md').write_text('# 159 設定と結果\n\n2026-11-13。V8全63手法×9尺度＝567セル。'
        '既存出口3行動の継続/利確を25派生量の異role2条件で選ぶ。教科書の単独指標効果とはしない。'
        '\n\n[実行条件](実行条件.md) / [固定文法](文法と学習の固定.json)。自然教師の学習は未実行。\n\n'+'\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'features':25,'predicates':124,'rules_per_fit':12464,
        'book_sha256':hashlib.sha256(out.read_bytes()).hexdigest()},ensure_ascii=False))


if __name__=='__main__':
    main()
