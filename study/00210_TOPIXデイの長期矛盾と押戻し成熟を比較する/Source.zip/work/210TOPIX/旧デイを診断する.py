"""固定旧D4の取得を当時の役割と背景へ分解し、新金融の前に原因を保存する。"""
from pathlib import Path
from collections import defaultdict,Counter
from datetime import datetime
from zoneinfo import ZoneInfo
from statistics import median
import sys,json
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
sys.path.insert(0,str(ROOT/'work/190TOPIX'))
import 入口190 as D
sys.path.insert(0,str(ROOT/'work/197TOPIX'))
import 入口197 as B
sys.path.insert(0,str(ROOT/'work/202TOPIX'))
from 原因202 import describe
M=D.M;read=D.read


def key(row):
    """
    機能: 当時特徴と出生の厳密な索引を作る。
    引数: row(dict)。
    返り値: tuple[str,float,int]は場・価格時計・原行。
    """
    return row['session'],row['time'],row['line']


def old_day(row,context):
    """
    機能: D4のP0主・量不明動力改善補完を定義から再生する。
    引数: row/context(dict)。
    返り値: tuple[int,str]。Dayは費用比による実方向反転を行わない。
    """
    p=D.U.E.roles(row,1,context,False)[0];n=D.U.E.roles(row,-1,context,False)[0]
    side=1 if p and not n else -1 if n and not p else 0
    if side:return side,'P0主'
    p=D.U.supplement(row,1,context,'未知');n=D.U.supplement(row,-1,context,'未知')
    side=1 if p and not n else -1 if n and not p else 0
    if not side:return 0,'不成立'
    short=row['m5']
    if side*(short['hist_delta'] or 0)<0 or side*(short['rsi_delta'] or 0)<0:return 0,'量不明の動力改善なし'
    return side,'量不明動力改善補完'


def direction(channel,time):
    """
    機能: 同じEMA並びと傾きから方向を求め、履歴不明と混在を分ける。
    引数: channel(dict|None),time(float)。
    返り値: int|None。
    """
    if channel is None or channel['published']>time or channel['slope'] is None:return None
    return 1 if channel['ema8']>channel['ema21'] and channel['slope']>0 else -1 if channel['ema8']<channel['ema21'] and channel['slope']<0 else 0


def relation(value,side):
    """
    機能: 背景の方向を実側に対して表す。
    引数: value(int|None),side(int)。
    返り値: str。
    """
    return '履歴又は鮮度不足' if value is None else '同側' if value==side else '逆側' if value==-side else '並びと傾き混在'


def bucket(value,edges):
    """
    機能: 説明用の粗い固定区分を作り、精密な閾値最適化をしない。
    引数: value(float|None),edges(list[float])。
    返り値: str。
    """
    if value is None:return '不明'
    for i,end in enumerate(edges):
        if value<end:return f'{edges[i-1]}以上{end}未満' if i else f'{end}未満'
    return f'{edges[-1]}以上'


def attributes(row,extra,side,family):
    """
    機能: 旧D4の源時だけの方向・動力・値幅・量・構造を記録する。
    引数: row/extra(dict),side(int),family(str)。
    返り値: dict。値は取得後又は将来の成績に依存しない。
    """
    m=row['m5'];a=row['atr'];mid=row['m15'];long=row['m30'];close=row['close']
    v={'源側':side,'実側':side,'出生':family,'ATR5':a,'ADX5':m['adx'],'源側EMA差ATR5':side*(m['ema8']-m['ema21'])/a,
      '源側EMA傾きATR5':side*(m['slope'] or 0)/a,'源側DI5':side*m['di'],'源側DI15':side*mid['di'],
      '源側RSI5':m['rsi'] if side==1 else 100-m['rsi'],'源側RSI変化5':None if m['rsi_delta'] is None else side*m['rsi_delta'],
      '源側BBz5':None if m['bbz'] is None else side*m['bbz'],'源側MACD差ATR5':side*m['hist']/a,
      '源側MACD変化ATR5':None if m['hist_delta'] is None else side*m['hist_delta']/a,
      '源側価格EMA8距離ATR5':side*(close-m['ema8'])/a,'源側価格EMA21距離ATR5':side*(close-m['ema21'])/a,
      '源側価格EMA8距離ATR15':side*(close-mid['ema8'])/mid['atr'],'源側価格EMA21距離ATR30':None if long is None else side*(close-long['ema21'])/long['atr'],
      '15方向':relation(direction(mid,row['time']),side),'30方向':relation(direction(long,row['time']),side),
      'ADX15':mid['adx'],'ADX30':None if long is None else long['adx'],
      '量1分':row['rvol'],'量5分':extra.get('rvol5'),'量5分理由':extra.get('quantity_reason'),
      '1分値幅ATR5':row['range'],'源側実体ATR5':side*row['body'],'源側進行ATR5':side*row['progress'],
      '源側当足位置':row['position'] if side==1 else 1-row['position'],
      '源側直前3端距離ATR5':side*(close-(row['prior_high'] if side==1 else row['prior_low']))/a,
      '逆側直前3端距離ATR5':side*(close-(row['prior_low'] if side==1 else row['prior_high']))/a,
      '20分ER':extra.get('er20'),'20分構造既知':extra.get('range_known'),
      '費用比':(row['spread']+.5836)/a,'スプレッド':row['spread'],
      '源側価格時計進行ATR5':None if row['live'] is None else side*row['live']}
    lo=extra.get('range_low');hi=extra.get('range_high')
    v['源側20分位置']=None if not extra.get('range_known') or hi==lo else (close-lo)/(hi-lo) if side==1 else (hi-close)/(hi-lo)
    start=M.bounds(row['session'])[0];v['場開始分']=(row['time']-start)/60;v['1分公表遅延秒']=(row['time']-start)%60
    return v


def groups(v):
    """
    機能: 指標の単独区分と役割を分けた少数複合区分を作る。
    引数: v(dict)は源時属性。
    返り値: list[str]。後付け診断であり、新規採用条件ではない。
    """
    names=['全体','出生/'+v['出生'],'方向30/'+v['30方向'],'方向15/'+v['15方向'],
      '方向30と15/'+v['30方向']+'_'+v['15方向']]
    bins={'ADX5':[15,20,25,40],'源側EMA差ATR5':[.25,.5,1.],
      '源側価格EMA8距離ATR5':[-.25,0,.5,1.],'源側価格EMA8距離ATR15':[-.5,0,.5],
      '源側価格EMA21距離ATR30':[-.5,0,.5],'源側RSI5':[50,60,70],
      '源側RSI変化5':[0],'源側BBz5':[0,1,2],'源側MACD変化ATR5':[0],
      '量1分':[.5,1,2],'量5分':[.5,1,2],'1分値幅ATR5':[.5,1],
      '逆側直前3端距離ATR5':[0,.5,1.],'源側直前3端距離ATR5':[-.5,0],
      '20分ER':[.25,.5],'源側20分位置':[.25,.5,.75],'費用比':[.25,.4],
      '場開始分':[60,180,300],'1分公表遅延秒':[5,15],
      '源側価格時計進行ATR5':[-.1,0,.1]}
    for name,edges in bins.items():names.append(name+'/'+bucket(v[name],edges))
    adx='低20' if v['ADX5']<20 else '非低20';gap='狭0.5' if v['源側EMA差ATR5']<.5 else '非狭0.5';er='不明' if v['20分ER'] is None else '低0.25' if v['20分ER']<.25 else '非低0.25'
    names+=['ADXとEMA差/'+adx+'_'+gap,'ADX差とER/'+adx+'_'+gap+'_'+er,
      '出生と30方向/'+v['出生']+'_'+v['30方向'],
      '30方向と短期価格/'+v['30方向']+'_'+('EMA8逆側' if v['源側価格EMA8距離ATR5']<0 else 'EMA8同側'),
      '30方向とEMA差/'+v['30方向']+'_'+gap,
      'ADX差と30方向/'+adx+'_'+gap+'_'+v['30方向']]
    weak197=v['ADX5']<18 and v['源側EMA差ATR5']<.4
    if weak197:names+=['197既存弱基準/全体','197既存弱基準/30方向/'+v['30方向']]
    if v['源側BBz5'] is not None and v['源側BBz5']>=2 and v['源側MACD変化ATR5'] is not None and v['源側MACD変化ATR5']>=0:names.append('拡張と加速/全体')
    return names


def main():
    """
    機能: 既存全83口座だけを読み、214デイ取得と全純出生を照合する。
    引数: なし。
    返り値: None。新しい入口の金融計算や既存金融の改変は行わない。
    """
    state_path=ROOT/'work/208TOPIX/全83/金融/安定性.json.gz';state=read(state_path)['metrics'][0]
    pack_path=state_path.parent/'金融正本'/(state['id']+'.json.gz');pack=read(pack_path);ledger=pack['ledger']
    pure_path=ROOT/'work/208TOPIX/全83/純入口83.json.gz';pure={key(r):r for r in read(pure_path)}
    files=[ROOT/'inputs/TOPIX原順8列_20260921_20261116/純特徴184直接.json.gz',ROOT/'inputs/00194_20261116夜と1117昼の固定適用入力/TOPIX/純特徴184直接.json.gz']
    rows=sum((read(p) for p in files),[]);maps={key(r):r for r in rows};contexts=B.context_rows(rows);pure_counts=Counter();role_map={};same=0
    for k,p in pure.items():
        if p['band']!='DAY':continue
        if k not in maps:assert not p['signals'][0];continue
        native,family=old_day(maps[k],contexts[k]);assert native==p['signals'][0],(k,native,p['signals'][0]);same+=1
        if native:role_map[k]=family;pure_counts[family]+=1
    periods={'前48':{s['scene'] for s in pack['sessions'][:48]},'後25':{s['scene'] for s in pack['sessions'][48:73]},'追加7':{s['scene'] for s in pack['sessions'][73:80]},'最終1':{pack['sessions'][80]['scene']},'追加2':{s['scene'] for s in pack['sessions'][81:]},'全83':{s['scene'] for s in pack['sessions']}}
    grouped=defaultdict(list);records=[]
    for i,scene in enumerate(ledger['scene']):
        if 'Day' not in scene:continue
        k=(scene,ledger['request_time'][i],ledger['request_line'][i]);r=maps[k];side=ledger['side'][i];assert side==pure[k]['signals'][0]
        v=attributes(r,pure[k]['extra'],side,role_map[k]);names=groups(v)
        for period,scenes in periods.items():
            if scene in scenes:
                for name in names:grouped[(period,name)].append(i)
        records.append({'台帳添字':i,'session':scene,'q0':datetime.fromtimestamp(k[1],ZoneInfo('Asia/Tokyo')).isoformat(),
          'time':k[1],'line':k[2],'known':ledger['known'][i],'net':ledger['net'][i],
          'label':ledger['label'][i],'reason':ledger['reason'][i],'width':ledger['width'][i],
          '取得遅延秒':ledger['entry_time'][i]-k[1],
          '源側取得価格差ATR5':side*(ledger['entry_price'][i]-r['close'])/r['atr'],
          '属性':v})
    result={period:{name:describe(ledger,indices) for (p,name),indices in grouped.items() if p==period} for period in periods}
    scene_groups=defaultdict(list)
    for r in records:scene_groups[r['session']].append(r['台帳添字'])
    scene_results={scene:describe(ledger,ids) for scene,ids in scene_groups.items()}
    assert len(records)==214 and all(r['known'] for r in records)
    M.save(HERE/'旧D4原因診断.json.gz',{'区分':'既存208旧基準の全83の事後説明。新金融なし。源方向と実側はDayでは同じ。費用比反転はNightのみ。',
      '同体照合':{'直接q0':same,'純出生':dict(pure_counts),'デイ実取得':len(records)},'期間別群':result,'場別':scene_results,'個票':records,
      'Source':{str(p.relative_to(ROOT)):M.sha(p) for p in [Path(__file__),pack_path,state_path,pure_path,*files,ROOT/'work/190TOPIX/入口190.py',ROOT/'work/189TOPIX/入口189.py',ROOT/'work/186TOPIX/入口186.py']}})
    for period in periods:print(period,json.dumps({k:v for k,v in result[period].items() if k=='全体' or k.startswith(('出生/','197既存弱基準/','拡張と加速/'))},ensure_ascii=False))
    print('最悪場',json.dumps(sorted(scene_results.items(),key=lambda p:p[1]['既知純益'])[:8],ensure_ascii=False))


if __name__=='__main__':main()
