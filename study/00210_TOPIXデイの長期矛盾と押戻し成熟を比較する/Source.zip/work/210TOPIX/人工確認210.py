"""役割の鏡像・源固定・異なる足の順序・失効を金融前に確認する。"""
from copy import deepcopy
import json,sys
import 入口210 as E
sys.path.insert(0,str(E.ROOT/'work/183TOPIX'))
import 人工検査 as T


def fixture():
    """
    機能: 価格線と時計が明確な人工のデイ源足を作る。
    引数: なし。
    返り値: dict。
    """
    _,features,_=E.load_inputs();r=deepcopy(next(r for r in features if r['m30'] is not None));scene='2026-09-21_Day';t=E.M.bounds(scene)[0]+3600
    r.update(session=scene,time=t,line=1,band='DAY',close=4002.,prior_close=4002.5,prior_low=4000.,prior_high=4003.,low=4001.5,high=4003.,body=-.25,progress=-.25,atr=2.,range=.75,rvol=1.,live=0.,spread=.5)
    for name in ('m5','m15','m30'):r[name].update(count=200,end=t,published=t,ema8=4000.,ema21=3999.,slope=.1,di=.1)
    r['m5'].update(adx=25.,bbz=2.2,hist_delta=.1)
    return r


def main():
    """
    機能: 人工境界、全実特徴の鏡像、接頭部の因果同体を検査する。
    引数: なし。
    返り値: None。金融計算なし。
    """
    source=fixture();t=source['time'];checks=0
    # ----------------------------------------
    # Aは短長期の矛盾だけ。単なる弱ADX、長期不明、混在では反転させない。
    a=deepcopy(source);a['m5'].update(adx=17.,ema8=4000.2,ema21=4000.);a['m30'].update(ema8=4001.,ema21=4002.,slope=-.1)
    for mirror in (False,True):
        r=T.mirror(a) if mirror else a;s=-1 if mirror else 1;role=E.roles(r,s);assert role['A'] and not role['B'];checks+=2
        for mode in ('不明','混在','同側'):
            bad=deepcopy(r)
            if mode=='不明':bad['m30']=None
            elif mode=='混在':bad['m30']['slope']*=-1
            else:bad['m30'].update(ema8=r['m30']['ema21'],ema21=r['m30']['ema8'],slope=-r['m30']['slope'])
            assert not E.roles(bad,s)['A'];checks+=1
    broken=deepcopy(a);broken.update(time=t+60,line=2,prior_close=4002.,close=3999.8,high=4001.,low=3999.5,body=-.5,progress=-.5);broken['m5']['hist_delta']=-.1
    held=deepcopy(broken);held.update(time=t+120,line=3,prior_close=3999.8,close=3999.6,high=4000.1,low=3999.3)
    for mirror in (False,True):
        seq=[T.mirror(r) for r in (a,broken,held)] if mirror else [a,broken,held];s=-1 if mirror else 1;r0,r1,r2=seq;role=E.roles(r0,s)
        births,counts=E.generate(seq,{E.key(r0):role},{E.key(r0):5.},'A');live=[b for b in births.values() if b]
        assert len(live)==1 and live[0]['side']==-s and live[0]['level']==r0['prior_low' if s==1 else 'prior_high'];checks+=3
        assert live[0]['prior_ends']==[t-180,t-120,t-60] and live[0]['width']==5.;checks+=2
        for mode in ('量不明','低量','長期不明','保持失敗','非連続'):
            bad=deepcopy(r2)
            if mode=='量不明':bad['rvol']=None
            elif mode=='低量':bad['rvol']=.1
            elif mode=='長期不明':bad['m30']=None
            elif mode=='保持失敗':bad['close']=r0['prior_low' if s==1 else 'prior_high']
            else:bad['time']+=60
            out,_=E.generate([r0,r1,bad],{E.key(r0):role},{E.key(r0):5.},'A');assert not any(out.values()),mode;checks+=1
    # ----------------------------------------
    # B/Mは別5分の冷却→さらに後の跨ぎ→次1分保持。冷却同時の跨ぎは不使用。
    seq=[deepcopy(source)]
    for n in range(1,9):
        r=deepcopy(source);r.update(time=t+n*60,line=n+1,close=4001.5,prior_close=4001.5,high=4002.,low=4001.,body=-.1,progress=-.1)
        if n>=5:r['m5'].update(count=201,end=t+300,published=t+300,hist_delta=-.1,bbz=.5)
        if n==5:r.update(close=3999.8,prior_close=4000.5,low=3999.5,high=4000.5)
        if n==6:r.update(close=4000.3,prior_close=3999.8,low=3999.9,high=4000.5,body=.25,progress=.25)
        if n==7:r.update(close=4000.5,prior_close=4000.3,low=3999.9,high=4000.8,body=.1,progress=.1)
        seq.append(r)
    for mirror in (False,True):
        rows=[T.mirror(r) for r in seq] if mirror else seq;s=-1 if mirror else 1;role=E.roles(rows[0],s);assert role['B'] and role['M'];checks+=2
        for family in ('B','M'):
            out,counts=E.generate(rows,{E.key(rows[0]):role},{E.key(rows[0]):5.},family);live=[b for b in out.values() if b];assert len(live)==1;birth=live[0]
            assert birth['time']<birth['cooling']['time']<birth['broken']['time']<birth['confirmed']<=birth['expiry']==t+1200;checks+=5
            assert birth['level']==rows[0]['m5']['ema8'] and birth['width']==5. and birth['confirmed']==t+420;checks+=3
            same=deepcopy(rows)
            for r in same[5:]:r['m5'].update(count=200,end=t,published=t)
            fake,_=E.generate(same,{E.key(rows[0]):role},{E.key(rows[0]):5.},family);assert not any(fake.values());checks+=1
            # 冷却時に既に線の同側なら、単なる保持だけでは発火しない。
            same=deepcopy(rows);same[5].update(close=rows[6]['close'],prior_close=rows[6]['close']);same[6]['prior_close']=same[5]['close']
            fake,ct=E.generate(same,{E.key(rows[0]):role},{E.key(rows[0]):5.},family);assert not any(fake.values()) and ct['冷却時の源EMA8/同側で後の跨ぎ待ち']==1;checks+=2
            # 保持失敗後に同じ源の別の跨ぎがあっても復活しない。
            same=deepcopy(rows);same[7]['rvol']=None;same[8]=deepcopy(same[7]);same[8].update(time=t+480,line=9,rvol=1.)
            fake,ct=E.generate(same,{E.key(rows[0]):role},{E.key(rows[0]):5.},family);assert not any(fake.values()) and ct['確認1分量不明']==1;checks+=2
            # 後発源を使って固定線又は期限を延ばさない。
            roles={E.key(rows[0]):role,E.key(rows[4]):role};widths={E.key(rows[0]):5.,E.key(rows[4]):10.};out,ct=E.generate(rows,roles,widths,family);live=[b for b in out.values() if b]
            assert len(live)==1 and live[0]['time']==t and live[0]['level']==rows[0]['m5']['ema8'] and live[0]['width']==5.;checks+=4
    # ----------------------------------------
    # 実特徴からの役割は鏡像同体、未来を追加しても接頭部を変えない。
    base,features,_=E.load_inputs();maps={E.key(r):r for r in features};roles={};widths={};mirrors={}
    for p in base:
        if p['band']!='DAY' or not p['signals'][0]:continue
        k=E.key(p);r=maps[k];s=p['signals'][0];role=E.roles(r,s);other=E.roles(T.mirror(r),-s)
        assert all(role[f]==other[f] for f in ('A','B','M','weak197'));checks+=4;roles[k]=role;mirrors[k]=other;widths[k]=p['widths'][0]
    for family in ('A','B','M'):
        full,_=E.generate(features,roles,widths,family);prefix,_=E.generate(features[:5000],roles,widths,family);opposite,_=E.generate([T.mirror(r) for r in features[:5000]],mirrors,widths,family);seen=set()
        for k,b in prefix.items():
            assert full[k]==b and (b is None)==(opposite[k] is None);checks+=2
            if b:assert b['side']==-opposite[k]['side'] and b['time']==opposite[k]['time'];checks+=2
        for k,b in full.items():
            if b is None:continue
            marker=(k[0],b['time'],b['line']);assert marker not in seen;seen.add(marker);checks+=1
            assert b['source_end']<=b['broken']['end']<b['confirmation_end'] and b['time']<=b['broken']['time']<b['confirmed']<=b['expiry'];checks+=2
    result,diag=E.build(base,features);assert len(result)==35361 and len(result[0]['signals'])==13;checks+=2
    proof={'成功':True,'項目数':checks,'鏡像':True,'別5分足の冷却':True,'段階の厳密順序':True,'冷却同側を跨ぎとしない':True,'源線幅期限不変':True,'欠測失効':True,'保持失敗後不復活':True,'接頭部同体':True,'全83q0':len(result),'SourceSHA':E.M.sha(E.HERE/'入口210.py')}
    E.M.save(E.HERE/'人工確認.json',proof);print(json.dumps(proof,ensure_ascii=False),flush=True)


if __name__=='__main__':main()
