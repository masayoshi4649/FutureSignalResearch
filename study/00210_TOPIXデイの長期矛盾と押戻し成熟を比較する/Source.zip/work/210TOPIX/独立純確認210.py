"""純生成器の状態遷移関数を呼ばず、別の段階表で全13出生を照合する。"""
from pathlib import Path
from collections import defaultdict
import json,math
import 入口210 as E
from 旧デイを診断する import old_day,B


def end(row):
    """
    機能: 場開始から完成1分足の終端を別算術で求める。
    引数: row(dict)。
    返り値: float。
    """
    start=E.M.bounds(row['session'])[0]
    return start+math.floor((row['time']-start)/60)*60


def trend(row):
    """
    機能: 30分方向を公表済みEMA並びと傾きから独立に判定する。
    引数: row(dict)。
    返り値: intは方向、0は不明又は混在。
    """
    m=row['m30']
    if m is None or m['published']>row['time'] or m['slope'] is None:return 0
    if m['ema8']>m['ema21'] and m['slope']>0:return 1
    if m['ema8']<m['ema21'] and m['slope']<0:return -1
    return 0


def classify(row,side):
    """
    機能: 書面のA/B/M条件を独立に計算する。
    引数: row(dict),side(int)。
    返り値: dict。
    """
    m=row['m5'];weak=m['adx']<18 and abs(m['ema8']-m['ema21'])<.4*row['atr']
    hd=None if m['hist_delta'] is None else side*m['hist_delta'];bb=None if m['bbz'] is None else side*m['bbz']
    a=weak and row['m30'] is not None and trend(row)==-side
    return {'A':a,'B':not a and bb is not None and bb>=2 and hd is not None and hd>=0,'M':hd is not None and hd>=0,'weak197':weak,'hd':hd,'side':side,'body':side*row['body']}


def crossed(row,side,level):
    """
    機能: 固定線の確定終値跨ぎと同方向実体・進行を独立に確認する。
    引数: row(dict),side(int),level(float)。
    返り値: bool。
    """
    return side*(row['prior_close']-level)<=0<side*(row['close']-level) and side*row['body']>0 and side*row['progress']>0


def oracle(rows,roles,widths,family):
    """
    機能: 冷却待ち/破断待ち/保持待ちの別段階表で出生を再生する。
    引数: rows(list[dict]),roles/widths(dict),family(str)。
    返り値: dictは確認q0から固定源と段階時刻への写像。
    """
    expected={};state=None;prev=None
    for r in rows:
        k=E.key(r);q=r['time'];role=roles.get(k)
        if r['band']!='DAY':state=None;prev=r;continue
        contiguous=prev is None or (prev['session']==r['session'] and end(r)==end(prev)+60 and 30<=q-prev['time']<=90)
        if not contiguous:state=None
        prev=r
        if state is not None and q>state['t']+1200:state=None
        if state is None:
            if role is None or not role[family]:continue
            s=-role['side'] if family=='A' else role['side'];level=(r['prior_high'] if s==1 else r['prior_low']) if family=='A' else r['m5']['ema8']
            stage='破断待ち' if family=='A' else '冷却待ち'
            state={'t':q,'line':r['line'],'s':s,'native':role['side'],'lineprice':level,'atr':r['atr'],'width':widths[k],'m5':(r['m5']['count'],r['m5']['end']),'stage':stage,'cool':None,'break':None}
            if family=='A' and crossed(r,s,level):state['stage']='保持待ち';state['break']=(q,end(r))
            continue
        if q<=state['t']:continue
        s=state['s'];level=state['lineprice'];m=r['m5'];stage=state['stage']
        if stage=='冷却待ち':
            later=m['count']>state['m5'][0] and m['end']>state['m5'][1] and state['t']<m['published']<=q
            cooling=m['hist_delta'] is not None and s*m['hist_delta']<0 and m['bbz'] is not None and s*m['bbz']<=1
            if later and cooling and s*(m['ema8']-m['ema21'])>0 and s*r['m15']['di']>=0:state['stage']='破断待ち';state['cool']=q
            continue
        if stage=='破断待ち':
            if state['cool'] is not None and q<=state['cool']:continue
            if crossed(r,s,level):state['stage']='保持待ち';state['break']=(q,end(r))
            continue
        break_time,break_end=state['break']
        if q<=break_time:continue
        extreme=r['low'] if s==1 else r['high']
        held=end(r)==break_end+60 and 30<=q-break_time<=90 and s*(r['close']-level)>0 and s*(extreme-level)>=-.1*state['atr']
        background=(r['m30'] is not None and trend(r)==s and m['hist_delta'] is not None and s*m['hist_delta']>=0) if family=='A' else s*r['m15']['di']>=0
        quality=0<r['spread']<=1.5 and r['range']<=2.5 and r['live'] is not None and s*r['live']>=-.25
        amount=r['rvol'] is not None and r['rvol']>=.5
        if held and background and quality and amount:expected[k]={**state,'confirmation':q}
        state=None
    return expected


def main():
    """
    機能: 13口座全q0と固定197対照・源D4を金融前に独立照合する。
    引数: なし。
    返り値: None。
    """
    base,features,_=E.load_inputs();pure=E.read(E.HERE/'純入口.json.gz');maps={E.key(r):r for r in features};contexts=B.context_rows(features);roles={};widths={};checks=defaultdict(int)
    for p in base:
        if p['band']!='DAY':continue
        k=E.key(p)
        if k not in maps:assert not p['signals'][0];continue
        r=maps[k];native,_=old_day(r,contexts[k]);assert native==p['signals'][0];checks['旧D4源実側同体']+=1
        if native:roles[k]=classify(r,native);widths[k]=p['widths'][0]
    expected={family:oracle(features,roles,widths,family) for family in ('A','B','M')}
    old197={E.key(r):r for r in E.read(E.ROOT/'inputs/00197_TOPIXの一因子比較の純入口/純入口.json.gz')}
    for p,actual in zip(base,pure):
        assert E.key(p)==E.key(actual);k=E.key(p);role=roles.get(k)
        if role:
            for name in ('A','B','M','weak197'):assert actual['role'][name]==role[name];checks['独立役割']+=1
        for ci in range(13):
            side=p['signals'][0];width=p['widths'][0];birth=None
            if p['band']=='DAY':
                watch=[]
                if ci<9:
                    a,b=divmod(ci,3)
                    if role and (role['A'] and a or role['B'] and b):side=0
                    if a==2:watch.append('A')
                    if b==2:watch.append('B')
                elif ci==9:
                    if role and role['weak197']:side=0
                elif ci==10:
                    if role and role['weak197'] and role['body']<=-.3:side=0
                elif ci==11:
                    if role and not (role['hd'] is not None and role['hd']<0):side=0
                else:
                    if role and role['M']:side=0
                    watch=['M']
                for family in watch:
                    if side or k not in expected[family]:continue
                    birth=expected[family][k];side=birth['s'];width=birth['width']
            assert actual['signals'][ci]==side and actual['widths'][ci]==width,(k,ci);checks['全q0方向幅']+=2
            born=actual['births'][ci];assert (born is None)==(birth is None);checks['全q0出生有無']+=1
            if birth:
                assert born['time']==birth['t'] and born['line']==birth['line'] and born['side']==birth['s'] and born['level']==birth['lineprice'] and born['width']==birth['width'] and born['confirmed']==birth['confirmation'];checks['確認出生属性']+=6
                assert born['broken']['time']==birth['break'][0] and (None if born['cooling'] is None else born['cooling']['time'])==birth['cool'];checks['段階時刻']+=2
        if p['band']=='DAY' and k in old197:
            for ci,oldindex in ((0,0),(9,19),(10,38)):
                assert actual['signals'][ci]==old197[k]['signals'][oldindex] and actual['widths'][ci]==old197[k]['widths'][oldindex];checks['197旧81同体']+=2
    proof={'成功':True,'金融未実行':not (E.HERE/'金融').exists(),'方式':'入口210のroles/advance/generate/fuseを呼ばない別段階表。D4は190/189/186定義再生、D1/D2は固定197と厳密q0照合。',
      '候補':13,'確認出生':{f:len(v) for f,v in expected.items()},'検査':dict(checks),'条件SHA':E.M.sha(E.HERE/'条件.json'),'純入口SHA':E.M.sha(E.HERE/'純入口.json.gz'),'SourceSHA':E.M.sha(Path(__file__))}
    E.M.save(E.HERE/'独立純確認.json',proof);print(json.dumps(proof,ensure_ascii=False),flush=True)


if __name__=='__main__':main()
