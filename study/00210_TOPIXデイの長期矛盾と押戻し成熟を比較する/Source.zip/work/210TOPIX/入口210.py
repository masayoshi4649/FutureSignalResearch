"""デイの短長期矛盾と加速中の押戻しを区別し、固定線で成熟を待つ。"""
from pathlib import Path
from collections import defaultdict
from copy import deepcopy
import sys,json
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
sys.path.insert(0,str(ROOT/'work/208TOPIX'))
import 入口208 as P
U=P.U;E=P.E;M=P.M;read=P.read
SPECS=tuple((a,b) for a in range(3) for b in range(3))
NAMES=tuple(f'A{a}_{("旧","長期矛盾見送り","長期側構造確認")[a]}_B{b}_{("旧","拡張加速見送り","拡張加速の成熟待ち")[b]}' for a,b in SPECS)+('既197_D1_弱さ全除外','既197_D2_弱さと大実体除外','M1_全源のMACD減速AND','M2_全加速源の成熟待ち')


def key(row):
    """
    機能: 公表q0の不変キーを作る。
    引数: row(dict)。
    返り値: tuple[str,float,int]。
    """
    return row['session'],row['time'],row['line']


def roles(row,side):
    """
    機能: 旧D4の成立した源を長短期矛盾と拡張加速へ排他的に分類する。
    引数: row(dict),side(int)は旧源と同じ実側。
    返り値: dict。履歴不明を方向混在に置換せず、金融は参照しない。
    """
    m=row['m5'];a=row['atr'];long=E.direction30(row)
    weak=m['adx']<18 and abs(m['ema8']-m['ema21'])/a<.4
    hd=None if m['hist_delta'] is None else side*m['hist_delta'];bb=None if m['bbz'] is None else side*m['bbz']
    role_a=weak and row['m30'] is not None and long==-side
    role_b=not role_a and bb is not None and bb>=2 and hd is not None and hd>=0
    return {'A':role_a,'B':role_b,'M':hd is not None and hd>=0,'weak197':weak,
      'native':side,'actual':side,'direction30':long,'hist_delta_native':hd,'bbz_native':bb,
      'source_family':'量不明動力改善補完' if row['rvol'] is None else 'P0主',
      'source_background':U.background(row,side)}


def seed(row,role,family,width):
    """
    機能: 方向・価格線・幅・期限を源時に固定する。
    引数: row/role(dict),family(str)はA/B/M,width(float)。
    返り値: dictは源後の価格で線を動かさない監視状態。
    """
    native=role['native'];side=-native if family=='A' else native;end=U.minute_end(row)
    level=(row['prior_high'] if side==1 else row['prior_low']) if family=='A' else row['m5']['ema8']
    state={'family':family,'time':row['time'],'line':row['line'],'source_end':end,'side':side,'native':native,
      'level':level,'width':width,'source_atr':row['atr'],'expiry':row['time']+1200,
      'source_m5_id':[row['m5'][name] for name in ('count','end','published')],
      'source_role':deepcopy(role),'prior_ends':[end-180,end-120,end-60] if family=='A' else None,
      'cooling':None,'broken':None,'done':False,'reason':None}
    if family=='A' and E.crossing(row,side,level):state['broken']={'time':row['time'],'line':row['line'],'end':end}
    return state


def hold_reason(state,row):
    """
    機能: 初回破断の次足が固定水準を保ち、動力と量を伴うか確認する。
    引数: state/row(dict)。
    返り値: str|Noneは不成立理由。Noneは保持成立。
    """
    side=state['side'];edge=state['level'];extreme=row['low'] if side==1 else row['high'];broken=state['broken'];m=row['m5']
    if U.minute_end(row)!=broken['end']+60 or not 30<=row['time']-broken['time']<=90:return '保持時計非連続'
    if not (side*(row['close']-edge)>0 and side*(extreme-edge)>=-.1*state['source_atr']):return '固定線の保持失敗'
    if state['family']=='A':
        if row['m30'] is None:return '確認30分不明'
        if E.direction30(row)!=side:return '確認30分支持なし'
        if m['hist_delta'] is None:return '確認MACD不明'
        if side*m['hist_delta']<0:return '確認実側MACD増分不足'
    elif side*row['m15']['di']<0:return '確認15分DI支持なし'
    if row['rvol'] is None:return '確認1分量不明'
    if row['rvol']<.5:return '確認1分量不足'
    if not E.execution_quality(row,side):return '確認執行品質不足'
    return None


def advance(state,row):
    """
    機能: 異なる公表5分足の冷却・1分破断・次足保持を時系列で進める。
    引数: state/row(dict)。
    返り値: dict|Noneは一度だけの確認出生。失敗保持は状態を失効させる。
    """
    if state['done'] or row['time']<=state['time'] or row['time']>state['expiry']:return None
    end=U.minute_end(row);side=state['side'];m=row['m5']
    if state['broken'] is not None:
        if row['time']<=state['broken']['time']:return None
        reason=hold_reason(state,row);state['done']=True;state['reason']=reason or '確認成立'
        if reason is not None:return None
        return {**deepcopy(state),'confirmed':row['time'],'confirmation_end':end,'confirmation_background':U.background(row,state['native']),'confirmation_rvol1':row['rvol']}
    if state['family']!='A' and state['cooling'] is None:
        count,source_end,published=state['source_m5_id']
        later=m['count']>count and m['end']>source_end and state['time']<m['published']<=row['time']
        cool=later and m['hist_delta'] is not None and side*m['hist_delta']<0 and m['bbz'] is not None and side*m['bbz']<=1
        supported=side*(m['ema8']-m['ema21'])>0 and side*row['m15']['di']>=0
        if cool and supported:state['cooling']={'time':row['time'],'line':row['line'],'end':end,'m5_id':[m[name] for name in ('count','end','published')],'源固定線の同側':side*(row['close']-state['level'])>0}
        return None
    if state['family']!='A' and row['time']<=state['cooling']['time']:return None
    if E.crossing(row,side,state['level']):state['broken']={'time':row['time'],'line':row['line'],'end':end}
    return None


def generate(rows,role_map,width_map,family):
    """
    機能: 同役割の源を一つずつ監視し、後発で線と期限を更新しない。
    引数: rows(list[dict]),role_map/width_map(dict),family(str)。
    返り値: tuple[dict,dict]は純確認出生と段階・不成立件数。
    """
    outputs={};state=None;previous=None;counts=defaultdict(int)
    for row in rows:
        k=key(row);birth=None;role=role_map.get(k)
        assert row['m5']['published']<=row['time'] and row['m15']['published']<=row['time']
        if row['band']!='DAY':outputs[k]=None;state=None;previous=row;continue
        if previous is not None and not U.continuous(previous,row):
            if state is not None:
                counts['欠測又は場境界で失効']+=1;counts['欠測段階/'+('破断後' if state['broken'] is not None else '冷却後' if state['cooling'] is not None else '源後')]+=1
            state=None
        previous=row
        if state is not None and row['time']>state['expiry']:
            counts['源20分で失効']+=1;counts['期限段階/'+('破断後' if state['broken'] is not None else '冷却後' if state['cooling'] is not None else '源後')]+=1;state=None
        if state is not None:
            cooling=state['cooling'];broken=state['broken'];birth=advance(state,row);counts['監視q0']+=1
            if role is not None and role[family]:counts['後発源を無視し固定保持']+=1
            if cooling is None and state['cooling'] is not None:
                counts['別5分足の冷却']+=1;counts['冷却時の源EMA8/'+('同側で後の跨ぎ待ち' if state['cooling']['源固定線の同側'] else '逆側又は同値')]+=1
            if broken is None and state['broken'] is not None:counts['固定線の初回破断']+=1
            if state['done']:counts[state['reason']]+=1;state=None
        elif role is not None and role[family]:
            state=seed(row,role,family,width_map[k]);counts['源開始']+=1
            if state['broken'] is not None:counts['源当時破断既知']+=1
        outputs[k]=birth
    return outputs,dict(counts)


def fuse(base,role_map,confirmation):
    """
    機能: 旧即時要求を現在q0だけで優先し、13口座の純出生へ写す。
    引数: base(list[dict]),role_map/confirmation(dict)。
    返り値: tuple[list[dict],dict]は純入口と同時確認不使用数。
    """
    result=[];collision=defaultdict(int)
    for row in base:
        k=key(row);role=role_map.get(k);signals=[];widths=[];origins=[];births=[]
        for ci in range(len(NAMES)):
            side=row['signals'][0];width=row['widths'][0];origin='旧190固定';birth=None;wanted=[]
            if row['band']=='DAY':
                if ci<9:
                    a,b=SPECS[ci]
                    if role is not None and ((role['A'] and a) or (role['B'] and b)):side=0;origin='役割見送り又は確認待機'
                    if a==2:wanted.append('A')
                    if b==2:wanted.append('B')
                elif role is not None:
                    if ci==9 and role['weak197']:side=0;origin='既197D1見送り'
                    elif ci==10 and role['weak197']:
                        # 大実体条件は源特徴から別途保存した同じ値を使用する。
                        if role['body_native']<=-.3:side=0;origin='既197D2見送り'
                    elif ci==11 and not (role['hist_delta_native'] is not None and role['hist_delta_native']<0):side=0;origin='M1未減速見送り'
                    elif ci==12 and role['M']:side=0;origin='M2成熟待機'
                if ci==12:wanted=['M']
                for family in wanted:
                    confirmed=confirmation[family].get(k)
                    if confirmed is None:continue
                    if side:collision[str(ci)+'/'+family]+=1;continue
                    birth=confirmed;side=birth['side'];width=birth['width'];origin=family+'時間順確認'
            signals.append(side);widths.append(width);origins.append(origin);births.append(birth)
        assert signals[0]==row['signals'][0] and widths[0]==row['widths'][0]
        result.append({'session':k[0],'time':k[1],'line':k[2],'band':row['band'],'signals':signals,'widths':widths,'origins':origins,'births':births,'role':role,'extra':row['extra']})
    return result,dict(collision)


def load_inputs():
    """
    機能: 正式保存された旧81と追加2の同体入力だけを連結する。
    引数: なし。
    返り値: tuple[list,list,list[Path]]は旧基準出生・直接特徴・参照資源。
    """
    paths=[ROOT/'inputs/00208_TOPIXの役割別見送りと構造反転の純入口/純入口.json.gz',ROOT/'inputs/00208_TOPIXの役割別見送りと構造反転の純入口/追加二場純入口.json.gz',
      ROOT/'inputs/TOPIX原順8列_20260921_20261116/純特徴184直接.json.gz',ROOT/'inputs/00194_20261116夜と1117昼の固定適用入力/TOPIX/純特徴184直接.json.gz']
    return read(paths[0])+read(paths[1]),read(paths[2])+read(paths[3]),paths


def build(base,features):
    """
    機能: 金融を参照せず、全旧源の役割・時間順出生・13条件を構築する。
    引数: base/features(list[dict])。
    返り値: tuple[list,dict]。
    """
    maps={key(r):r for r in features};role_map={};widths={};counts=defaultdict(int);scenes=defaultdict(set)
    for p in base:
        if p['band']!='DAY' or not p['signals'][0]:continue
        k=key(p);r=maps[k];role=roles(r,p['signals'][0]);role['body_native']=role['native']*r['body'];role_map[k]=role;widths[k]=p['widths'][0]
        for family in ('A','B','M'):
            if role[family]:counts[family]+=1;scenes[family].add(p['session'])
    confirmation={};stages={}
    for family in ('A','B','M'):confirmation[family],stages[family]=generate(features,role_map,widths,family)
    result,collision=fuse(base,role_map,confirmation)
    return result,{'旧源':len(role_map),'役割数':dict(counts),'役割場数':{k:len(v) for k,v in scenes.items()},'段階':stages,'同q0旧即時又は先行確認優先':collision,
      'Day純成立':{name:sum(bool(r['signals'][i]) for r in result if r['band']=='DAY') for i,name in enumerate(NAMES)}}


def prepare():
    """
    機能: 人工検査後に条件・純出生・Sourceを金融前封印する。
    引数: なし。
    返り値: None。既存83場の再探索であり未見性能ではない。
    """
    assert not (HERE/'条件.json').exists()
    proof=read(HERE/'人工確認.json');assert proof['成功'] and proof['SourceSHA']==M.sha(Path(__file__))
    base,features,paths=load_inputs();result,diag=build(base,features);M.save(HERE/'純入口.json.gz',result)
    sources=[Path(__file__),HERE/'人工確認210.py',HERE/'独立純確認210.py',HERE/'旧デイを診断する.py',HERE/'金融前案.md',ROOT/'work/208TOPIX/入口208.py',ROOT/'work/205TOPIX/入口205.py',ROOT/'work/203TOPIX/入口203.py',ROOT/'work/200TOPIX/入口200.py',ROOT/'work/197TOPIX/入口197.py',ROOT/'work/192TOPIX/入口192.py',ROOT/'work/190TOPIX/入口190.py',ROOT/'work/189TOPIX/入口189.py',ROOT/'work/186TOPIX/入口186.py',M.HERE/'入口とIFD.py',ROOT/'scripts/TOPIX入口研究/共通金融.py']
    cfg={'試行':210,'規模':len(NAMES),'候補':list(NAMES),'情報区分':'旧D4全83を事後診断した後の条件探索。追加2も既使用。全80発見と前48選択を分け、後25/追加7/本日1/追加2を保持。',
      '固定条件本文':(HERE/'金融前案.md').read_text(encoding='utf-8'),'母体':'Day旧190D4の源側=実側、Night旧190N01は不変。新株/指標/新費用方向は追加しない。',
      'M不明':'M1はMACD増分既知かつ源側負のみ。M2は増分不明時には旧要求を残す。低量と量不明を区別。',
      'Source':{p.relative_to(ROOT).as_posix():M.sha(p) for p in sources},'入力':{p.relative_to(ROOT).as_posix():M.sha(p) for p in paths},'純入口SHA':M.sha(HERE/'純入口.json.gz')}
    M.save(HERE/'条件.json',cfg);M.save(HERE/'純成立診断.json',diag);print(json.dumps(diag,ensure_ascii=False),flush=True)


if __name__=='__main__':prepare()
