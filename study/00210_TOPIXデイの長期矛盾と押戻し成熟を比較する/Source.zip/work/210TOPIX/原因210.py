"""背景矛盾の見送りと成熟確認の効果を、変更取得・後続枠・期間へ分ける。"""
from collections import defaultdict
from datetime import datetime
from zoneinfo import ZoneInfo
import sys,json
import 入口210 as E
sys.path.insert(0,str(E.ROOT/'work/202TOPIX'))
from 原因202 import describe
import 金融を比較する as F


def indices(ledger):
    """
    機能: Day実取得をq0・実側・幅で厳密に識別する。
    引数: ledger(dict)。
    返り値: dict[tuple,int]。
    """
    return {(s,ledger['request_time'][i],ledger['request_line'][i],ledger['side'][i],ledger['width'][i]):i for i,s in enumerate(ledger['scene']) if 'Day' in s}


def record(ledger,i,pure,ci):
    """
    機能: 実取得の源役割・確認又は旧要求を追跡可能にする。
    引数: ledger/pure(dict),i/ci(int)。
    返り値: dict。
    """
    k=(ledger['scene'][i],ledger['request_time'][i],ledger['request_line'][i]);p=pure[k]
    return {'session':k[0],'q0':datetime.fromtimestamp(k[1],ZoneInfo('Asia/Tokyo')).isoformat(),'time':k[1],'line':k[2],
      'side':ledger['side'][i],'width':ledger['width'][i],'net':ledger['net'][i],'known':ledger['known'][i],'label':ledger['label'][i],
      'origin':ledger['origin'][i],'role':p['role'],'birth':p['births'][ci]}


def main():
    """
    機能: 固定13口座の寄与と前48/全80の順位を分け、有望対照を固定する。
    引数: なし。
    返り値: None。後付け群から入口条件は変更しない。
    """
    stats=E.read(E.HERE/'金融/安定性.json.gz')['metrics'];packs=[E.read(E.HERE/'金融/金融正本'/(s['id']+'.json.gz')) for s in stats];pure={E.key(r):r for r in E.read(E.HERE/'純入口.json.gz')};base=packs[0]['ledger'];base_keys=indices(base);results=[]
    for ci,pack in enumerate(packs):
        ledger=pack['ledger'];current=indices(ledger);grouped=defaultdict(list)
        for k,i in current.items():
            p=pure[k[:3]];role=p['role'];origin=ledger['origin'][i];kind='A源' if role and role['A'] else 'B源' if role and role['B'] else '他旧又は確認'
            for name in ('全体',kind,origin,'決済/'+ledger['reason'][i]):grouped[name].append(i)
        common=set(base_keys)&set(current);removed=set(base_keys)-set(current);added=set(current)-set(base_keys)
        for k in common:assert base['net'][base_keys[k]]==ledger['net'][current[k]] and base['known'][base_keys[k]]==ledger['known'][current[k]]
        r={'index':ci,'id':pack['id'],'群':{k:describe(ledger,v) for k,v in grouped.items()},'差':{'共通':describe(ledger,[current[k] for k in sorted(common)]),
          '基準だけ':describe(base,[base_keys[k] for k in sorted(removed)]),'比較だけ':describe(ledger,[current[k] for k in sorted(added)]),
          '基準だけ個票':[record(base,base_keys[k],pure,0) for k in sorted(removed)],'比較だけ個票':[record(ledger,current[k],pure,ci) for k in sorted(added)]}}
        periods={name:{s['scene'] for s in pack['sessions'][sl]} for name,sl in [('前48',slice(0,48)),('後25',slice(48,73)),('追加7',slice(73,80)),('最終1',slice(80,81)),('追加2',slice(81,83))]}
        r['変更取得の期間別']={name:{'基準だけ':describe(base,[base_keys[k] for k in sorted(removed) if k[0] in scenes]),'比較だけ':describe(ledger,[current[k] for k in sorted(added) if k[0] in scenes])} for name,scenes in periods.items()}
        results.append(r)
    rankings={}
    for period in ('全80','前48'):
        for band in ('DAY','NIGHT','ALL'):
            baseline=stats[0]['periods'][period][band];order=sorted(range(13),key=lambda i:(F.A.rank_key(stats[i]['periods'][period][band],baseline),stats[i]['id']))
            rankings[period+'_'+band]=[{'index':i,'id':stats[i]['id'],'gate':F.A.gate(stats[i]['periods'][period][band],baseline)} for i in order]
    E.M.save(E.HERE/'原因診断.json',{'区分':'全83既使用の固定金融事後説明。旧で実取得した群の損益と、見送り後の口座改善額を分ける。','候補':results,'SourceSHA':E.M.sha(E.HERE/'原因210.py')})
    E.M.save(E.HERE/'固定選択.json',{'全体採用':None,'Day有望主index':3,'Day比較候補index':[0,3,5,9,12],
      '理由':'全80/前48とも損失安定性の既定順位で3が先頭。全42Day取得・両中央値正・保有53.94%・未知0を保持し損失/赤字場/DD/最悪5場/初期損失を縮小。ただし赤字取引の最長連続数7→8、前48赤字・少数変更が残り全面安定採用とはしない。',
      '順位':rankings,'条件SHA':E.M.sha(E.HERE/'条件.json'),'純入口SHA':E.M.sha(E.HERE/'純入口.json.gz'),'金融SHA':E.M.sha(E.HERE/'金融/安定性.json.gz')})
    for ci in (0,3,5,6,12):
        r=results[ci];print(json.dumps({'index':ci,'群':r['群'],'差':{k:v for k,v in r['差'].items() if '個票' not in k},'期間差':r['変更取得の期間別']},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
