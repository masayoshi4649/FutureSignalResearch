"""全83場の13口座を独立BBO走査・枠・集計で監査する。"""
from pathlib import Path
from collections import defaultdict
import sys,json,math,hashlib
import numpy as np
import 入口210 as E
sys.path.insert(0,str(E.ROOT/'work/183損失安定性'))
import TOPIXを独立検算する as T
sys.path.insert(0,str(E.ROOT/'scripts/TOPIX入口研究'))
import 共通金融 as C


def filtered(ledger,scenes):
    """
    機能: 固定旧81場の同体比較用に台帳を元の順序のまま抽出する。
    引数: ledger(dict),scenes(set[str])。
    返り値: dict。出生表示名以外の全属性を残す。
    """
    indices=[i for i,s in enumerate(ledger['scene']) if s in scenes]
    return {k:[v[i] for i in indices] for k,v in ledger.items() if k!='origin'}


def digest(value):
    """
    機能: 台帳属性の順序に依存しない正準JSON指紋を作る。
    引数: value(object)。
    返り値: str。
    """
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')).hexdigest()


def main():
    """
    機能: Route/共通金融の計算を呼ばずに全取得の金融と予約枠を確認する。
    引数: なし。
    返り値: None。
    """
    folder=E.HERE/'金融';states=E.read(folder/'安定性.json.gz')['metrics'];packs=[E.read(folder/'金融正本'/(s['id']+'.json.gz')) for s in states];by=defaultdict(list)
    for r in E.read(E.HERE/'純入口.json.gz'):by[r['session']].append(r)
    checks=defaultdict(int);sha=E.M.sha(folder/'安定性.json.gz')
    for pack,stat in zip(packs,states):checks['独立集計属性']+=T.inspect_groups(pack,stat)
    for entry in C.entries(True):
        scene=entry['session'];start,end,force=T.bounds(scene)
        with np.load(entry['cache_absolute'],allow_pickle=False) as z:raw={k:z[k] for k in ('now','line','bid','ask','valid')}
        t=raw['now'];finite=np.isfinite(t);prior=np.maximum.accumulate(np.where(finite,t,-np.inf));mask=finite&(t>=start)&(t<end)&(t>=prior)&raw['valid'];arrays={k:v[mask] for k,v in raw.items() if k!='valid'};cache={}
        for ci,pack in enumerate(packs):
            ledger=pack['ledger'];indices=[i for i,s in enumerate(ledger['scene']) if s==scene];cursor=0;busy=-math.inf
            for row in by[scene]:
                side=row['signals'][ci]
                if not side:continue
                checks['全q0枠']+=1
                if row['time']<=busy:continue
                query=(row['time'],side,row['widths'][ci])
                if query not in cache:
                    first=int(np.searchsorted(arrays['now'],row['time']+1));fillable=first<len(arrays['now']) and arrays['now'][first]<=min(row['time']+30,force) and arrays['now'][first]<force
                    cache[query]=T.financial_oracle(arrays,scene,*query) if fillable else None
                cell=cache[query]
                if cell is None:busy=min(row['time']+30,force);continue
                assert cursor<len(indices);i=indices[cursor];cursor+=1;checks['取得']+=1
                for field,value in cell.items():
                    actual=pack['positions'][i][field] if field=='confirmed_until' else ledger[field][i];checks['金融属性']+=T.V.check_equal(actual,value,(pack['id'],scene,i,field))
                assert ledger['request_time'][i]==row['time'] and ledger['request_line'][i]==row['line'] and ledger['side'][i]==side and ledger['width'][i]==row['widths'][ci] and ledger['origin'][i]==row['origins'][ci]
                birth=row['births'][ci]
                if birth:
                    assert birth['time']<=birth['broken']['time']<row['time']<=birth['expiry']==birth['time']+1200 and birth['width']==row['widths'][ci];checks['確認出生時計']+=4
                    if birth['family']!='A':assert birth['time']<birth['cooling']['time']<birth['broken']['time'];checks['確認出生時計']+=2
                busy=ledger['exit_time'][i] if ledger['known'][i] else end
            assert cursor==len(indices)
    # ----------------------------------------
    # 全83の旧基準と、既検証197のD1/D2の旧81を両方固定照合する。
    expected=E.read(E.HERE/'旧同体期待.json');scenes={r['scene'] for r in packs[0]['sessions']};old81={r['scene'] for r in packs[0]['sessions'][:81]}
    assert digest(filtered(packs[0]['ledger'],scenes))==expected['0']['台帳SHA'] and digest(packs[0]['positions'])==expected['0']['保有SHA'] and digest(packs[0]['sessions'])==expected['0']['場SHA']
    for ci in (9,10):
        assert digest(filtered(packs[ci]['ledger'],old81))==expected[str(ci)]['台帳SHA']
        assert digest([p for p in packs[ci]['positions'] if p['scene'] in old81])==expected[str(ci)]['保有SHA']
    assert sha==E.M.sha(folder/'安定性.json.gz')
    proof={'成功':True,'口座':13,'全83':True,'旧190全83同体':True,'旧197_D1_D2の旧81同体':True,'金融SHA':sha,'検査':dict(checks),'SourceSHA':E.M.sha(Path(__file__)),'独立oracleSHA':E.M.sha(Path(T.__file__))}
    E.M.save(E.HERE/'独立金融確認.json',proof);print(json.dumps(proof,ensure_ascii=False),flush=True)


if __name__=='__main__':main()
