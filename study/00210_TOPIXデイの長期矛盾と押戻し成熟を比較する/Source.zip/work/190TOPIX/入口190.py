"""同じ公表原行での足形成差・追加q0・技術確認を分離する。"""
from pathlib import Path
import gzip,json,sys,math
import numpy as np
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
sys.path.insert(0,str(ROOT/'work/189TOPIX'))
import 入口189 as U
M=U.M
DAY=('D0_直接P0','D1_量不明補完','D2_急な動力悪化を除外','D3_量不明候補の次足回復','D4_量不明でも動力改善')
NIGHT=('N00_旧全q0','N01_共通q0の旧','N02_共通q0の直接','N03_直接全q0','N04_旧優先直接追加',
 'N05_実側合意と高密度追加','N06_直接への旧DI支持','N07_旧への直接DI支持',
 'N08_直接P0と旧ATR','N09_旧P0と直接ATR','N10_直接に観測密度','N11_直接に密度費用比')
NAMES=tuple(d+'_'+n for d in DAY for n in NIGHT)


def read(p):
    """
    機能: 保存JSONを読む。
    引数: p(Path)。
    返り値: object。
    """
    return json.loads(gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes())


def density(keys):
    """
    機能: q0の公表原行までの正常板観測密度を求める。
    引数: keys(set[tuple[str,float,int]])は場・価格時計・原行。
    返り値: dict[tuple,dict]は直近300秒の異時刻数/最大空白。真の受信密度ではない。
    """
    by={}
    for key in keys:by.setdefault(key[0],[]).append(key)
    result={};manifest=read(ROOT/'inputs/TOPIX原順8列_20260921_20261116/台帳.json')
    for e in manifest['entries']:
        z=np.load(ROOT/e['path'],allow_pickle=False);t=z['now'];finite=np.isfinite(t)
        high=np.maximum.accumulate(np.where(finite,t,-np.inf));good=finite&(t>=high)&z['valid']&np.isfinite(z['last'])&(z['last']>0)
        times=t[good];lines=z['line'][good]
        for key in by.get(e['session'],[]):
            _,q0,line=key;i=int(np.searchsorted(lines,line,side='right'));left=int(np.searchsorted(times,q0-300))
            seen=np.unique(times[left:i]);gap=max(np.max(np.diff(seen)) if len(seen)>1 else 300,q0-seen[-1] if len(seen) else 300,seen[0]-(q0-300) if len(seen) else 300)
            result[key]={'観測異時刻数':len(seen),'最大空白':float(gap),'密度合格':bool(len(seen)>=10 and gap<=30)}
    return result


def di_support(row,signal,origin):
    """
    機能: 他形成のDIが元の技術方向を支持するか確認する。
    引数: row(dict|None),signal(int),origin(str)。
    返り値: bool。反転N07はその反転前のP0方向を参照する。
    """
    if row is None or not signal:return False
    native=-signal if '反転' in origin else signal
    return native*row['m5']['di']>0 and native*row['m15']['di']>=0


def main():
    """
    機能: 60条件を全q0の和集合で作り金融前に封印する。
    引数: なし。
    返り値: None。共通は同じ場・CurrentPriceTime・公表原行の厳密一致。
    """
    q189=read(ROOT/'work/189TOPIX/純入口.json.gz');index={int(k):{(r['session'],r['time'],r['line']):r for r in rows} for k,rows in q189.items()}
    features={}
    for form,file in enumerate(('純特徴183.json.gz','純特徴184直接.json.gz')):
        rows=read(ROOT/'inputs/TOPIX原順8列_20260921_20261116'/file);features[form]={(r['session'],r['time'],r['line']):r for r in rows}
    keys=set(index[0])|set(index[1]);obs=density(keys);previous={};result=[]
    for key in sorted(keys):
        scene,t,line=key;old=index[0].get(key);direct=index[1].get(key);ro=features[0].get(key);rd=features[1].get(key)
        band=(direct or old)['band'];common=old is not None and direct is not None;signals=[];origins=[]
        if band=='DAY':
            if direct is None:days=[(0,'直接準備不足')]*5
            else:
                q0=(direct['signals'][0],direct['origins'][0]);q1=(direct['signals'][14],direct['origins'][14]);m=rd['m5'];s=q1[0];a=rd['atr']
                smooth=not s or (s*(m['hist_delta'] or 0)/a>=-.03 and s*(m['rsi_delta'] or 0)>=-3 and m['tr']/a<=1.8 and (m['rsi'] if s==1 else 100-m['rsi'])<=75)
                recover=q0;prior=previous.get(scene)
                if not recover[0] and prior is not None:
                    p,pr=prior;ps=p['signals'][14];dt=t-p['time'];start=M.bounds(scene)[0]
                    consecutive=int((t-start)//60)-int((p['time']-start)//60)==1
                    if ps and p['origins'][14]=='量不明補完' and consecutive and 30<=dt<=90:
                        if ps*rd['body']>0 and ps*rd['progress']>0 and ps*(rd['close']-pr['m5']['ema8'])>0 and 0<ps*(rd['close']-pr['close'])/a<=.5:
                            recover=(ps,'量不明候補の回復確認')
                improved=q1
                if q1[1]=='量不明補完' and (s*(m['hist_delta'] or 0)<0 or s*(m['rsi_delta'] or 0)<0):improved=(0,'動力改善なし')
                days=[q0,q1,q1 if smooth else (0,'動力悪化待機'),recover,improved]
                previous[scene]=(direct,rd)
            for d in days:
                for _ in NIGHT:signals.append(d[0]);origins.append(d[1])
            w=U.E.width(direct,'A25') if direct else None
        else:
            op=(old['signals'][7],'旧'+old['origins'][7]) if old else (0,'旧準備不足')
            dp=(direct['signals'][7],'直接'+direct['origins'][7]) if direct else (0,'直接準備不足')
            dense=obs[key]['密度合格']
            agree=op[0]!=0 and op[0]==dp[0]
            chosen=op if old is not None else dp
            agreement=op if agree else dp if old is None and dense else (0,'不一致待機')
            direct_di=dp if di_support(ro,dp[0],dp[1]) or (old is None and dense) else (0,'旧DI支持なし')
            old_di=op if di_support(rd,op[0],op[1]) else (0,'直接DI支持なし')
            exchange=[]
            for signal_source,price_source,title in ((direct,ro,'直接P0旧ATR'),(old,rd,'旧P0直接ATR')):
                if signal_source is None or price_source is None:exchange.append((0,'交換元不足'));continue
                native=signal_source['signals'][0];ratio=(price_source['spread']+.5836)/price_source['atr']
                exchange.append((-native if band=='PRE' or ratio>.25 else native,title))
            ratio=(rd['spread']+.5836)/rd['atr'] if rd else None
            nights=[op,op if common else (0,'共通外'),dp if common else (0,'共通外'),dp,chosen,agreement,direct_di,old_di,
               exchange[0],exchange[1],dp if dense else (0,'観測密度不足'),dp if dense and ratio is not None and ratio<=.4 else (0,'密度又は費用比待機')]
            for _ in DAY:
                for n in nights:signals.append(n[0]);origins.append(n[1])
            w=15.
        result.append({'session':scene,'time':t,'line':line,'band':band,'width':w,'common':common,'signals':signals,'origins':origins,'観測密度':obs[key]})
    M.save(HERE/'純入口.json.gz',result)
    cfg={'試行':190,'規模':60,'Day':list(DAY),'Night':list(NIGHT),'候補':list(NAMES),
      'q0共通':'場・CurrentPriceTime・公表原行lineが完全一致。5/15/30足の公表時刻は各形成の当時特徴として異なり得る。時計だけの近似照合なし。',
      '観測密度':'q0原行までの正常BBOかつ有限最終値で直近300秒の異なる価格時刻数10以上・最大空白30秒以下。真の受信密度/経済的相場分類ではない。',
      '幅期限':'全候補Day=q0直接5分ATR×2.5（5〜25pt、0.25切上げ）、Night=15pt、H60。取得後固定。',
      '固定金融':M.read(M.HERE/'条件_実装修正1.json'),'未知基準':'Day同体D0、Night同体N00旧全q0。全候補D0N00を基本対照。',
      '選択':'全80と前48の損失優先順位を分離、後25/追加7/本日1を診断。全81既使用。',
      '原因分解':'旧全→共通旧：旧だけq0。共通旧→共通直接：指標と方向。共通直接→直接全：直接追加q0。共通要求取得・元のみ・新のみと出生損益で枠効果を別計数。',
      'SourceSHA':M.sha(Path(__file__)),'純入口SHA':M.sha(HERE/'純入口.json.gz'),
      '量の区別':'D1/D4は189Q1の量不明だけ。既知低量は補完しない。D3は不明量候補が出た後の当時回復であり、量を捏造しない。'}
    assert not (HERE/'条件.json').exists();M.save(HERE/'条件.json',cfg)
    M.save(HERE/'純成立診断.json',{'q0和集合':len(result),'候補':{n:sum(r['signals'][i]!=0 for r in result) for i,n in enumerate(NAMES)}})
    print('60条件の純入口を固定',len(result),flush=True)


if __name__=='__main__':main()
