"""P0を保持し、数量不足の補完と夜間の実方向切替を別要因で比較する。"""
from pathlib import Path
from collections import deque
import gzip,json,sys,math
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
sys.path.insert(0,str(ROOT/'work/186TOPIX'))
import 入口186 as E
M=E.M
NIGHT=('N00_元P0','N01_P0全反転','N02_低ADX反転','N03_費用比反転','N04_長期逆向き反転',
 'N05_量付き逆進反転','N06_低ADX高費用反転','N07_米前反転米後費用比','N08_P1全反転',
 'N09_反転受容の全反転','N10_P0P1反転','N11_低費用整合と反転','N12_P0と反転受容失敗','N13_高費用待機P0P1反転')
NAMES=tuple(f'Q{q}_{name}' for q in range(3) for name in NIGHT)
WIDTHS=('W15','A25')


def supplement(r,side,ctx,kind):
    """
    機能: 量不明と既知低量を別にして価格・三足方向で補完する。
    引数: r(dict),side(int),ctx(dict),kind(str)は未知/低量。
    返り値: bool。数量0への補完や仮想出来高は生成しない。
    """
    rv=r['rvol'];m=r['m5'];long=r['m30'];a=r['atr'];past=ctx['history']
    if kind=='未知' and rv is not None:return False
    if kind=='低量' and not (rv is not None and 0<=rv<.5):return False
    coherent=len(past)==3 and all(past[i]['end']-past[i-1]['end']==300 for i in (1,2))
    if not coherent or long is None:return False
    steady=all(side*(p['slope'] or 0)>0 and side*p['di']>0 and side*(p['ema8']-p['ema21'])>0 for p in past)
    trend=steady and side*m['di']>=.015 and side*r['m15']['di']>=0 and side*long['di']>0 and side*(long['slope'] or 0)>0
    dist=side*(r['close']-m['ema8'])/a;rsi=m['rsi'] if side==1 else 100-m['rsi']
    price=-.5<=dist<=(.75 if kind=='未知' else 1.) and 35<=rsi<=75 and side*r['body']<0 and side*r['progress']<=0 and side*m['hist']/a>=-.15
    quality=0<r['spread']<=1.5 and r['range']<=(1.5 if kind=='未知' else .75) and r['live'] is not None and side*r['live']>=-.25
    return bool(trend and price and quality)


def resolve(first,second):
    """
    機能: 役割別の主・補完を事前優先順で選ぶ。
    引数: first,second(tuple[int,str])。
    返り値: tuple[int,str]は成立済み主を優先した判断。
    """
    return first if first[0] else second


def reverse(pair):
    """
    機能: 実注文方向を反転する。
    引数: pair(tuple[int,str])。
    返り値: tuple[int,str]。損益は後で反対BBOから再生する。
    """
    return (-pair[0],pair[1]+'反転') if pair[0] else pair


def decide(r,ctx,base,quantity_mode,night):
    """
    機能: 当時の技術・量の可用性・帯から入口の実側を決める。
    引数: r,ctx(dict),base(list[int])は186純方向、quantity_mode,night(int)。
    返り値: tuple[int,str]は注文方向と出生枝。未来収支を参照しない。
    """
    p0=(base[0],'P0主') if base[0] else (0,'なし')
    if not p0[0] and quantity_mode>=1:
        plus=supplement(r,1,ctx,'未知');minus=supplement(r,-1,ctx,'未知')
        if plus!=minus:p0=(1 if plus else -1,'量不明補完')
    if not p0[0] and quantity_mode==2:
        plus=supplement(r,1,ctx,'低量');minus=supplement(r,-1,ctx,'低量')
        if plus!=minus:p0=(1 if plus else -1,'量既知低量補完')
    if r['band']=='DAY':return p0
    p1=(base[2],'P1再開') if base[2] else (0,'なし');rev=(base[8],'R0反転受容') if base[8] else (0,'なし')
    m=r['m5'];long=r['m30'];ratio=(r['spread']+.5836)/r['atr'];s=p0[0]
    low=m['adx']<25;cost=ratio>.25
    oppose=long is not None and s*(long['slope'] or 0)<0
    surge=abs(r['body'])>=.3 and r['rvol'] is not None and r['rvol']>=1.2
    if night==0:return p0
    if night==1:return reverse(p0)
    if night==2:return reverse(p0) if low else p0
    if night==3:return reverse(p0) if cost else p0
    if night==4:return reverse(p0) if oppose else p0
    if night==5:return reverse(p0) if surge else p0
    if night==6:return reverse(p0) if low and cost else p0
    if night==7:return reverse(p0) if r['band']=='PRE' or cost else p0
    if night==8:return reverse(p1)
    if night==9:return reverse(rev)
    if night==10:return reverse(resolve(p0,p1))
    if night==11:
        aligned=long is not None and s*(long['slope'] or 0)>0 and s*long['di']>0
        return p0 if s and ratio<.2 and aligned else reverse(resolve(p1,rev))
    if night==12:return resolve(p0,reverse(rev))
    if night==13:return (0,'高費用待機') if ratio>.4 else reverse(resolve(p0,p1))
    raise ValueError(night)


def main():
    """
    機能: 189の全q0判断を作り、金融前にSource/条件を封印する。
    引数: なし。
    返り値: None。量不足を市場局面の測定値に置換しない。
    """
    old=json.loads(gzip.decompress((E.HERE/'純入口.json.gz').read_bytes()));result={};diag=[]
    for form,file in enumerate(('純特徴183.json.gz','純特徴184直接.json.gz')):
        source=json.loads(gzip.decompress((ROOT/'inputs/TOPIX原順8列_20260921_20261116'/file).read_bytes()))
        lookup={(r['session'],r['time'],r['line']):r for r in old[str(form)]};hist=deque(maxlen=3);prev=None;scene=None;ident=None;rows=[]
        for r in source:
            if scene!=r['session']:hist.clear();prev=None;ident=None;scene=r['session']
            now=(r['m5']['count'],r['m5']['end'],r['m5']['published'])
            if now!=ident:hist.append(r['m5']);ident=now
            ctx={'history':list(hist),'previous':prev};base=lookup[(scene,r['time'],r['line'])]['signals']
            choices=[decide(r,ctx,base,q,n) for q in range(3) for n in range(14)]
            rows.append({'session':scene,'time':r['time'],'line':r['line'],'band':r['band'],'atr':r['atr'],
              'signals':[p[0] for p in choices],'origins':[p[1] for p in choices]});prev=r
        result[str(form)]=rows
        diag.append({'形成':form,'候補':{name:sum(r['signals'][i]!=0 for r in rows) for i,name in enumerate(NAMES)}})
    M.save(HERE/'純入口.json.gz',result);M.save(HERE/'純成立診断.json',diag)
    cfg={'試行':189,'新仮説':'P0を保持し数量可用性不足を価格構造で補完、Nightの方向誤認を当時情報で切替',
       '比較規模':168,'候補':list(NAMES),'形成':['183旧合成','184直接'],'幅':list(WIDTHS),'期限':'60分固定',
       '量補完':{'Q0':'なし','Q1':'rvol不明のみ、三足同方向と3本の5分持続と狭い押戻しで補完','Q2':'Q1に加えrvol既知0.5未満も、小幅0.75ATR以下の押戻しと三足方向で別補完'},
       'Night':list(NIGHT),'未知非増加基準':'同形成・同幅Q0_N00。P0主を固定対照とし、全q0で単一保有再生。',
       '順位':M.config()['順位'],'期間':M.config()['期間'],'費用と金融':M.read(M.HERE/'条件_実装修正1.json'),
       '前試行':'186全216を既使用。9/23固有の時刻/価格条件なし。量不明と既知低量をoriginで別計上。',
       'SourceSHA':M.sha(Path(__file__)),'186SourceSHA':M.sha(E.HERE/'入口186.py'),'純入口SHA':M.sha(HERE/'純入口.json.gz'),
       '圧力の意味':'EMA/DI/価格進行/相対量の代理量。板数量/完全OFI/吸収の直接観測ではない。'}
    assert not (HERE/'条件.json').exists();M.save(HERE/'条件.json',cfg)
    print('168組の純入口・条件を固定した',flush=True)


if __name__=='__main__':main()
