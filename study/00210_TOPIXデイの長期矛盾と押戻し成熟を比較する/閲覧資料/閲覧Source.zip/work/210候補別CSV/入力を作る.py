"""210の固定全83集計と保有区間から候補を混在させないCSV用入力を作る。"""
from pathlib import Path
import gzip,hashlib,json,math,argparse
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
TRIAL=ROOT/'study/00210_TOPIXデイの長期矛盾と押戻し成熟を比較する';SUPPORT=TRIAL/'閲覧資料'
SPECS=((0,'00_旧基準'),(3,'03_長期矛盾見送り'),(5,'05_成熟待ち併用'))


def load(path):
    """
    機能: 正式JSON又はgzip JSONを読む。
    引数: path(Path)。
    返り値: dict|list。
    """
    raw=path.read_bytes();return json.loads(gzip.decompress(raw) if path.suffix=='.gz' else raw)


def held(scene,positions,band):
    """
    機能: 当該帯と確認済み保有区間の重なりを、当該帯実時間で割る。
    引数: scene(dict),positions(list),band(str)。
    返り値: floatは0〜1。予約・未確認区間を保有へ加えない。
    """
    windows=[(scene['start'],scene['end'])] if band=='NIGHT' else [(p['start'],p['end']) for p in scene['phases'] if p['name']==band]
    assert len(windows)==1;start,end=windows[0];intervals=[]
    for p in positions:
        if p['scene']!=scene['scene']:continue
        stop=p['exit'] if p['exit'] is not None else p['confirmed_until'];assert stop is not None
        a,b=max(start,p['fill']),min(end,stop)
        if a<b:intervals.append((a,b))
    intervals.sort();assert all(intervals[i][0]>=intervals[i-1][1] for i in range(1,len(intervals)))
    return sum(b-a for a,b in intervals)/(end-start)


def main():
    """
    機能: 確定収支と既知寄与を分け、全83場・3候補・5表を準備する。
    引数: CLI --保有を固定(bool)は独立検査済み金融から最小の保有入力を保存する初回専用。
    返り値: None。通常再現は恒久入力だけから行い、金融を再探索しない。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--保有を固定',action='store_true');args=parser.parse_args();SUPPORT.mkdir(exist_ok=True)
    state_path=TRIAL/'全13組全83安定性.json.gz';states=load(state_path)['metrics'];position_path=SUPPORT/'対象保有区間.json.gz'
    if args.保有を固定:
        selected={}
        for ci,title in SPECS:
            p=ROOT/'work/210TOPIX/金融/金融正本'/(states[ci]['id']+'.json.gz');pack=load(p)
            selected[str(ci)]={'id':pack['id'],'sessions':pack['sessions'],'positions':pack['positions'],'金融packSHA':hashlib.sha256(p.read_bytes()).hexdigest()}
        body=json.dumps(selected,ensure_ascii=False,separators=(',',':')).encode('utf-8');assert not position_path.exists()
        with position_path.open('wb') as f:
            with gzip.GzipFile(fileobj=f,mode='wb',mtime=0) as stream:stream.write(body)
    selected=load(position_path);headers=['候補','開始日又は期間','帯','利益既知寄与_円','損失絶対額既知寄与_円','収支確定_円','累計収支確定_円','建玉回数','未知件数','保有時間率下限','収支既知寄与_円','累計既知寄与_円']
    names={'候補比較':'集計','デイ':'デイ','ナイト全体':'ナイト全体','ナイト_米前':'ナイト_米前','ナイト_米後':'ナイト_米後'};tables={name:{'headers':headers,'rows':[]} for name in names};comparison=[]
    for ci,title in SPECS:
        state=states[ci];candidate='210:'+title;stored=selected[str(ci)];assert stored['id']==state['id'];scenes={s['scene']:s for s in stored['sessions']};assert len(scenes)==83
        for band,group in state['groups'].items():
            if band not in ('ALL','DAY','NIGHT','PRE','POST'):continue
            trades=group['trades'];sessions=group['sessions'];holding=group['holding'];net=trades['known_net'];full=net if not trades['unknown_count'] else None
            tables['候補比較']['rows'].append([candidate,'全83場',band,trades['known_profit'],trades['known_loss'],full,full,trades['all_count'],trades['unknown_count'],holding['held_lower_ratio'],net,net])
            dest={'DAY':'デイ','NIGHT':'ナイト全体','PRE':'ナイト_米前','POST':'ナイト_米後'}.get(band)
            if not dest:continue
            cumulative=0.;complete=True;profit=loss=seconds=0.
            for row in sessions['rows']:
                meta=scenes[row['scene']];cumulative+=row['known_net'];complete=complete and row['complete'];ratio=held(meta,stored['positions'],band)
                duration=meta['end']-meta['start'] if band=='NIGHT' else sum(p['end']-p['start'] for p in meta['phases'] if p['name']==band)
                profit+=row['known_profit'];loss+=row['known_loss'];seconds+=ratio*duration
                tables[dest]['rows'].append([candidate,row['scene'][:10],band,row['known_profit'],row['known_loss'],row['all_net'],cumulative if complete else None,row['all_count'],row['unknown_count'],ratio,row['known_net'],cumulative])
            assert math.isclose(profit,trades['known_profit'],abs_tol=1e-7) and math.isclose(loss,trades['known_loss'],abs_tol=1e-7) and math.isclose(seconds,holding['held_lower_seconds'],abs_tol=1e-7)
            assert len(sessions['rows'])==(42 if band=='DAY' else 41)
            if band=='DAY':comparison.append({'候補':candidate,**{k:trades[k] for k in ('known_profit','known_loss','known_net','all_count','unknown_count')},'取得場':sessions['participating_count'],'保有率':holding['held_lower_ratio'],'DD':group['path']['known_contribution']['max_drawdown']['amount'],'赤字取引':trades['negative_rate']['negative_count'],'赤字場':sessions['negative_rate']['negative_count'],'建玉中央値下限':trades['net_median']['lower'],'場中央値下限':sessions['net_median']['lower']})
    sources=[{'path':p.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in (state_path,position_path)]
    data={'tableNames':names,'tables':tables,'入力':sources,'Day比較':comparison,'全83既使用':True,'未知':'未知の場収支と以後の確定累計は空欄。既知寄与列を別に残す。'}
    HERE.mkdir(parents=True,exist_ok=True);(HERE/'閲覧入力.json').write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n','utf-8');print(json.dumps({'候補':3,'CSV予定':15,'場数':83,'Day比較':comparison},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
