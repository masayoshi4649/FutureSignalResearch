"""210の3候補15CSVを再読し、損失安定性と支持の限界を添えて正式保存する。"""
from pathlib import Path
import csv,io,json,math,hashlib,shutil,zipfile
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
TRIAL=ROOT/'study/00210_TOPIXデイの長期矛盾と押戻し成熟を比較する';OUT=ROOT/'outputs/00210_TOPIXデイの長期矛盾と成熟待ち比較'


def main():
    """
    機能: 型付き原表と全セル、未知空欄、累計を確認し閲覧案内を保存する。
    引数: なし。
    返り値: None。候補混在やxlsx出力は行わない。
    """
    data=json.loads((HERE/'閲覧入力.json').read_text('utf-8'));proof=json.loads((ROOT/'work/210CSV検査/作成確認.json').read_text('utf-8'));cells=nulls=0
    for item in proof['files']:
        raw=(OUT/item['相対path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==item['sha256'];rows=list(csv.reader(io.StringIO(raw.decode('utf-8-sig'))));table=data['tables'][item['元表']]
        expected=[table['headers']]+[r for r in table['rows'] if r[0]==item['候補']];assert len(rows)==len(expected)
        for actual,source in zip(rows,expected,strict=True):
            assert len(actual)==len(source)
            for a,b in zip(actual,source,strict=True):
                cells+=1
                if b is None:assert a=='';nulls+=1
                elif isinstance(b,(int,float)):assert math.isclose(float(a),b,abs_tol=1e-7)
                else:assert a==b
        for row in rows[1:]:assert math.isclose(float(row[3])-float(row[4]),float(row[10]),abs_tol=1e-7)
        if item['元表']!='候補比較':
            total=0.;complete=True
            for row in rows[1:]:
                total+=float(row[10]);complete=complete and int(row[8])==0;assert math.isclose(float(row[11]),total,abs_tol=1e-7)
                if complete:assert math.isclose(float(row[6]),total,abs_tol=1e-7)
                else:assert row[6]==''
    assert len(proof['files'])==15 and cells==6300 and nulls>0
    proof.update(CSV全セル再読=cells,未知空欄セル数=nulls,累計算術検査=True,全Day42とNight41を保持=True,全15表の描画を目視確認=True)
    support=TRIAL/'閲覧資料';support.mkdir(exist_ok=True);(support/'CSV確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n','utf-8');shutil.copy2(HERE/'閲覧入力.json',support/'閲覧入力.json')
    sources=[HERE/'入力を作る.py',Path(__file__),ROOT/'scripts/損益CSV/候補別に出力する.mjs']
    with zipfile.ZipFile(support/'閲覧Source.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for p in sources:archive.write(p,p.relative_to(ROOT).as_posix())
    (support/'Source索引.json').write_text(json.dumps([{'path':p.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sources],ensure_ascii=False,indent=2)+'\n','utf-8')
    descriptions={'00_旧基準':'旧190D4/N01。新しい見送り・成熟待ちを加える前の固定対照。',
      '03_長期矛盾見送り':'Day有望主3。弱い短期方向が当時の30分方向と逆のときだけ旧要求を見送る。全80/前48の既定順位とも先頭だが、既使用探索であり前期赤字も残る。',
      '05_成熟待ち併用':'主3の長期矛盾見送りに、BB外側の加速中は5分冷却→源EMA8の回復→保持を待つ処理を加えた比較。利益と損失額は改善するが、赤字場・連敗・DDが主3より悪く主を交換しない。'}
    for title,description in descriptions.items():
        text=f'''# 210:{title}

{description}

2026-09-21〜11-17の全83セッション。ミニTOPIX1枚、1pt=1,000円、片道41.8円+0.25pt、往復583.6円。ラージBBO代用、Day源A25/NightW15/H60単純IFD、保有予約合計1、開始待機なし、終了15分前決済。

[集計](集計.csv) / [デイ](デイ.csv) / [ナイト全体](ナイト全体.csv) / [ナイト米国前](ナイト_米前.csv) / [ナイト米国後](ナイト_米後.csv)。今回の変更はDayだけで、Nightは3案とも旧190N01。Night208主3を混合していない。

利益と損失は費用後の既知取引の金額。Day未知0、Night未知7。未知を含む場の確定収支と以後の確定累計は空欄で、別列の既知寄与を確定利益と扱わない。無取引場も残す。保有時間率は実際に確認できた区間の下限（0〜1）、終了前15分を分母から除く。予約・未確認保有で水増ししない。

損益は新規取得帯へ、保有は帯との実時間重複へ帰属。新規0でも保有率が正の帯がある。Night全体と米前・米後は別の集計なので重複加算しない。DDは場末実現寄与の経路で、保有中時価DDではない。

[比較と限界](../README.md) / [研究正本](../../../study/00210_TOPIXデイの長期矛盾と押戻し成熟を比較する/README.md)。
'''
        (OUT/('210_'+title)/'README.md').write_text(text,'utf-8')
    text='''# TOPIXデイの長期矛盾と成熟待ち比較

まず [03_長期矛盾見送り](210_03_長期矛盾見送り/デイ.csv) と [00_旧基準](210_00_旧基準/デイ.csv) のデイを比較する。[05_成熟待ち併用](210_05_成熟待ち併用/デイ.csv)は利益額だけでは主に選ばなかった比較候補。

全3案とも42/42デイで取得し、金融未知0、建玉・セッション両中央値は黒字。ミニTOPIX1枚・費用後・円。全83場は研究に既使用。

|候補|利益|損失|収支|赤字取引 / 取得|赤字場|保有率|場末DD|
|---|---:|---:|---:|---:|---:|---:|---:|
'''
    for r in data['Day比較']:
        title=r['候補'].split(':')[1];text+=f"|[{title}](210_{title}/README.md)|{r['known_profit']:,.1f}|{r['known_loss']:,.1f}|{r['known_net']:,.1f}|{r['赤字取引']} / {r['all_count']}|{r['赤字場']}|{r['保有率']:.2%}|{r['DD']:,.1f}|\n"
    text+='''
主3は赤字場17→16、場連敗4→3、最悪場−57,585.2→−44,001.6円、初期最低−103,204.8→−79,536.8円を改善。一方、取引連敗は7→8へ悪化し、前48は−10,279.6円でまだ赤字。Aが作用した基準の実取得は10件/6場に限られ、後続旧要求の枠変更も収支改善へ寄与する。追加7以後はA該当がなく旧と同体で、新しい効果が再確認されたとはしない。

05は純益が高く損失額も少ないが、主3より赤字場18、取引連敗10、DD102,444.4円が悪い。成熟確認の実取得は1件+15,666.4円だけで、単独手法の優位を確定しない。全期最大利益ではなく損失安定性を優先し主3を保持した。

各候補のDay42行・Night41行を残した。Nightは全候補旧基準の176取得/38場、金融未知7で同体。Night208主3や209の新枝はこのCSVへ混ぜていない。保有率は全対象時間の率で、各場20%以上や毎時一定回数を意味しない。

[研究の原因と支持](../../study/00210_TOPIXデイの長期矛盾と押戻し成熟を比較する/README.md) / [15CSV・6,300セル再読照合](../../study/00210_TOPIXデイの長期矛盾と押戻し成熟を比較する/閲覧資料/CSV確認.json) / [恒久再現資料](../../study/00210_TOPIXデイの長期矛盾と押戻し成熟を比較する/閲覧資料/README.md)。xlsxは生成していない。
'''
    (OUT/'README.md').write_text(text,'utf-8')
    (support/'README.md').write_text('''# 210候補別CSVの再現

[閲覧入口](../../../outputs/00210_TOPIXデイの長期矛盾と成熟待ち比較/README.md)。旧0・Day有望主3・成熟待ち比較5を分離。[型付き入力](閲覧入力.json)・[最小保有区間](対象保有区間.json.gz)・[照合](CSV確認.json)・[Source](閲覧Source.zip)・[索引](Source索引.json)。

入力を作る.pyは通常、正式の全13組全83安定性.json.gzと対象保有区間.json.gzだけを参照する。初回の`--保有を固定`以外はwork金融に依存しない。型付きJSONを共通の`候補別に出力する.mjs --input 入力 --output 新規先 --proof 新規確認先 --dependencies Codex提供node_modules`へ渡す。既存CSVは上書きしない。

Codex提供artifact-toolへ全セルを渡し、再計算後CSVを出力。全15表のプレビューを目視し、Python csvで6,300セルを再読、累計・未知空欄・利益−損失を独立確認。UTF-8 BOM/CRLF。PNGは作業確認用だけとし正式には複製しない。
''','utf-8')
    p=TRIAL/'README.md';text=p.read_text('utf-8');text+='\n## 閲覧CSV\n\n[候補別CSV](../../outputs/00210_TOPIXデイの長期矛盾と成熟待ち比較/README.md)へ旧0・有望主3・成熟待ち併用5を分離した。3候補15CSV・6,300セルを正式集計と保有区間へ再読照合。Day全42場とNight全41場、未知と0を区別して保持する。\n';p.write_text(text,'utf-8')
    print(json.dumps({'CSV':15,'全セル照合':cells,'未知空欄':nulls,'正式保存':True},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
