"""129の自然出生を変更せず、全73場の取得入力へ転記する。"""
from pathlib import Path
from collections import Counter
import argparse
import hashlib
import json
import math

ROOT=Path(__file__).resolve().parent.parent
OWN=ROOT/'work/129短期回復の評価'


def main() -> None:
    """
    機能: 出生の原行/参照/全品質と0出生場を保持して入力を新規保存する。
    引数: CLI --sha256(str)は出生JSON期待指紋。返り値: None。
    """
    parser=argparse.ArgumentParser(description='129出生の同体転記')
    parser.add_argument('--sha256',required=True);args=parser.parse_args()
    raw=(OWN/'出生.json').read_bytes();assert hashlib.sha256(raw).hexdigest()==args.sha256
    source=json.loads(raw)
    assert source['success'] and source['trial']==129 and not source['financial_labels_used'] and source['raw_passes']==73
    assert source['background_sha256']=='e382858a62865b321449279d9653f5b1c644c97f6c4254cbae8dd9d3ea065e62'
    assert len(source['scenes'])==73
    grouped={s['session']:[] for s in source['scenes']};ids=set()
    for event in source['events']:
        assert event['id'] not in ids and event['mode'] in ('C1','C2','C3') and event['side'] in (-1,1)
        ids.add(event['id']);side=event['side'];at=event['at'];a=event['atr5']
        assert a>0 and all(math.isfinite(event[k]) for k in ('atr5','entry_cap','invalidation','hold_boundary','minimum_risk'))
        assert event['hold_minimum']==0 and event['minimum_risk']==10
        assert side*(event['entry_cap']-event['hold_boundary'])>=0 and side*(event['entry_cap']-event['invalidation'])>=10
        for ref in event['refs']:
            assert all(ref['delivered'][k]<=at[k] for k in ('time','index','source_line'))
        copied=dict(event);session=copied.pop('session');grouped[session].append(copied)
    scenes=[]
    for s in source['scenes']:
        assert s['counts']==s['expected_quality'] and s['actual_sha256']==s['raw']['sha256'] and s['raw_passes']==1
        assert s['expected_accepted']==s['counts']['source_parser_accepted']
        events=sorted(grouped[s['session']],key=lambda e:(e['at']['source_line'],e['id']))
        assert len(events)==s['births'] and all(e['at']['index']<s['expected_accepted'] for e in events)
        modes=Counter(e['mode'] for e in events)
        assert all(modes[k]==s['by_mode'].get(k,0) for k in ('C1','C2','C3'))
        row={k:s[k] for k in ('session','contract','start','end','force_close','raw','expected_accepted','expected_quality')}
        row['execution_end']=s['end']-300;row['events']=events;scenes.append(row)
    assert len({s['session'] for s in scenes})==73
    value={'trial':129,'source_births_sha256':args.sha256,'source_background_sha256':source['background_sha256'],
           'source_entry_births_used':False,'scenes':scenes}
    output=(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode('utf-8')
    with (OWN/'入力.json').open('xb') as stream: stream.write(output)
    print(json.dumps({'成功':True,'SHA256':hashlib.sha256(output).hexdigest(),'出生':len(ids),'出生場':sum(bool(s['events']) for s in scenes),'0出生場':[s['session'] for s in scenes if not s['events']]},ensure_ascii=False))


if __name__=='__main__':
    main()
