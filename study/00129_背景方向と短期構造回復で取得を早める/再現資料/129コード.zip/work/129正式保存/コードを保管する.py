"""129F0/F1の小型ソースとCSV器をRaw/巨大入力/exeなしで保管する。"""
from pathlib import Path
import gzip
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[2]
FORMAL=ROOT/'study/00129_背景方向と短期構造回復で取得を早める'


def sha(body: bytes) -> str:
    """
    機能: bytesのSHAを返す。
    引数: body(bytes)。返り値: str。
    """
    return hashlib.sha256(body).hexdigest()


def main() -> None:
    """
    機能: 固定源と結果後CSV器を由来別manifest付きZIPへ保存する。
    引数: なし。返り値: None。
    """
    folders=ROOT/'work/129短期回復の評価'
    items={}
    for phase in ['F0','F1']:
        fixed=json.loads((folders/f'{phase}.json').read_bytes())
        for name,expected in fixed['ファイル'].items():
            p=Path(name)
            if not (p.suffix in ['.go','.py','.md'] or p.name=='go.mod'):continue
            body=p.read_bytes();assert sha(body)==expected,str(p)
            items[p.relative_to(ROOT).as_posix()]=(body,phase)
    for folder in [ROOT/'work/129短期回復CSV出力',ROOT/'work/129出生の不足診断',ROOT/'work/129正式保存']:
        for p in folder.glob('*'):
            if p.suffix not in ['.go','.py','.mjs','.md'] and p.name!='go.mod':continue
            items[p.relative_to(ROOT).as_posix()]=(p.read_bytes(),'結果後の閲覧・診断・保管（金融条件外）')
    for p in [ROOT/'work/129閲覧表をまとめる.py',ROOT/'work/129短期回復の出生/小部分再用の確認.json']:
        items[p.relative_to(ROOT).as_posix()]=(p.read_bytes(),'実行補助・出自')
    recipe=FORMAL/'再現資料';recipe.mkdir(exist_ok=True)
    target=recipe/'129コード.zip'
    manifest=[{'path':p,'phase':phase,'bytes':len(b),'sha256':sha(b)} for p,(b,phase) in sorted(items.items())]
    with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,(body,_) in sorted(items.items()):z.writestr(name,body)
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
        for p,(body,_) in items.items():assert z.read(p)==body
    value={'試行':129,'ZIP':target.name,'ZIP_SHA256':sha(target.read_bytes()),'ZIP_bytes':target.stat().st_size,'格納源数':len(items),'格納源':manifest,'未格納':'Raw・巨大公表・入力全文・結果全文・exe。共用128Inputは永続inputs128を参照。','参照補足':'準備を確認する.pyの120/128元コード照合は旧120/128の正式ZIPを復元して使う。金融再生と人工go testはこのZIPで自己完結。'}
    (recipe/'コード復元索引.json').write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'ZIP_SHA':value['ZIP_SHA256'],'源数':len(items),'bytes':target.stat().st_size},ensure_ascii=False))


if __name__=='__main__':
    main()
