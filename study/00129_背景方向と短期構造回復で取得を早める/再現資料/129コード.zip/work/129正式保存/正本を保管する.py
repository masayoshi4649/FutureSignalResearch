"""129固定結果を再計算せずcompact正本へ保管する。"""
from pathlib import Path
import gzip
import hashlib
import json
import shutil

ROOT=Path(__file__).resolve().parents[2]
FORMAL=ROOT/'study/00129_背景方向と短期構造回復で取得を早める'
OWN=ROOT/'work/129短期回復の評価'


def sha(body: bytes) -> str:
    """
    機能: 保存bytesのSHAを返す。
    引数: body(bytes)。返り値: str。
    """
    return hashlib.sha256(body).hexdigest()


def save_gzip(path: Path, body: bytes, source: str) -> dict:
    """
    機能: 元bytesをgzip一正本へ保存し復元同体を確認する。
    引数: path(Path)/body(bytes)/source(str)。返り値: dict。
    """
    path.parent.mkdir(parents=True,exist_ok=True)
    data=gzip.compress(body,mtime=0)
    with path.open('xb') as stream:stream.write(data)
    assert gzip.decompress(path.read_bytes())==body
    return {'source':source,'path':path.relative_to(ROOT).as_posix(),'bytes':len(data),'sha256':sha(data),'decoded_bytes':len(body),'decoded_sha256':sha(body)}


def copy(path: Path, target: Path) -> None:
    """
    機能: 小型証跡だけを一度copyする。
    引数: path/target(Path)。返り値: None。
    """
    target.parent.mkdir(exist_ok=True,parents=True)
    assert not target.exists(),str(target)
    shutil.copyfile(path,target)
    assert sha(path.read_bytes())==sha(target.read_bytes())


# ----------------------------------------
def main() -> None:
    """
    機能: 固定結果/入力/Stats/証跡を保存し元Rawを複製しない。
    引数: なし。返り値: None。
    """
    items=[]
    for source,target,expected in [
        (OWN/'入力.json',ROOT/'inputs/00129_短期構造回復/入力.json.gz','96382d12330a49fc5237e78bf3d888c4be52ade98ed6ff6017057aee5f4f7d56'),
        (OWN/'新入口結果.json',FORMAL/'成果物/新入口結果.json.gz','d25d00c3b1f548120fd9b43067b97ac4ff397f1abc385acd87777f2a009491f2'),
        (OWN/'元出生結果.json',FORMAL/'成果物/元出生区間対照結果.json.gz','845f94dcc4256d77c54ded158fb803a5a25a3db5ab3ca2717c14931e4d5034aa')]:
        body=source.read_bytes();assert sha(body)==expected
        items.append(save_gzip(target,body,source.relative_to(ROOT).as_posix()))
    (ROOT/'inputs/00129_短期構造回復/指紋.json').write_text(json.dumps(items[0],ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    for source,target in [(OWN/'新入口集計/集計.json',FORMAL/'成果物/新入口集計.json'),(OWN/'元出生集計/集計.json',FORMAL/'成果物/元出生区間対照集計.json')]:
        copy(source,target)
    born=json.loads((OWN/'出生.json').read_bytes())
    assert sha((OWN/'出生.json').read_bytes())=='d67b0787f2e34c2a63bec4b7f5c6d02a74c4362c2b6b1d3da1b5efb723a62d6a'
    stages={'成功':True,'試行':129,'出生SHA':'d67b0787f2e34c2a63bec4b7f5c6d02a74c4362c2b6b1d3da1b5efb723a62d6a','出生数':91,'出生場':38,'金融ラベルなし':True,'scenes':born['scenes']}
    items.append(save_gzip(FORMAL/'成果物/出生段階Stats.json.gz',(json.dumps(stages,ensure_ascii=False,indent=2)+'\n').encode(), '出生.jsonの場metadata/Stats（eventsは恒久入力に同体保存）'))
    diagnostic=ROOT/'work/129出生の不足診断'
    copy(diagnostic/'保存資料の診断_詳細.json',FORMAL/'成果物/出生不足の詳細.json')
    copy(diagnostic/'診断の確認.json',FORMAL/'検査/出生不足診断.json')
    copy(diagnostic/'補助レビュー.md',FORMAL/'根拠/出生不足の補助レビュー.md')
    text=(diagnostic/'結果と次の問い.md').read_text(encoding='utf-8')
    text=text.replace('(保存資料の診断_詳細.json)','(../成果物/出生不足の詳細.json)').replace('(補助レビュー.md)','(出生不足の補助レビュー.md)').replace('次130','次131')
    text=text.replace('数学的欠陥','格子上の不成立条件').replace('押戻し中のHist負を','押戻し中のHistが同方向でないことを').replace('Hist負の押戻しが','Histが同方向でない押戻しが')
    (FORMAL/'根拠/出生不足の診断.md').write_text(text,encoding='utf-8')
    proofs=[('F1.json','金融前F1.json'),('出生完了.json','出生完了.json'),('新入口再生完了.json','新入口再生完了.json'),('元出生再生完了.json','元出生再生完了.json'),('新入口集計完了.json','新入口集計完了.json'),('元出生集計完了.json','元出生集計完了.json')]
    for source,target in proofs:copy(OWN/source,FORMAL/'検査'/target)
    for source,target in [
      (ROOT/'work/129短期回復の出生/準備の確認.json','出生器の人工確認.json'),
      (ROOT/'work/129独立準備レビュー/出生の独立確認.json','出生器の独立準備.json')]:copy(source,FORMAL/'検査'/target)
    manifest={'試行':129,'圧縮正本':items,'共用対照入力':'inputs/00128_Raw価格時計の独立出生/gap300入力.json.gz','対照入力解凍SHA':'474455be28a60248c7418fd69e123297738f6f782648b9c52aab076384e3c384','原板複製':False,'巨大公表入力複製':False,'実行体複製':False,'金融再計算':False}
    (FORMAL/'保管索引.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'圧縮正本':len(items),'旧対照入力':'既存128恒久入力参照','原板複製':False},ensure_ascii=False))


if __name__=='__main__':
    main()
