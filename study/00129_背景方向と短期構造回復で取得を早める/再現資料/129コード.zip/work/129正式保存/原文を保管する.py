"""129実行前F0に含まれる全MDを更新前に同体保存する。"""
from pathlib import Path
import gzip
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
FORMAL=ROOT/'study/00129_背景方向と短期構造回復で取得を早める'


def sha(body: bytes) -> str:
    """
    機能: 保存bytesのSHAを返す。
    引数: body(bytes)。返り値: str。
    """
    return hashlib.sha256(body).hexdigest()


def main() -> None:
    """
    機能: F0全MD原文と各SHAを一つのgzipへ保管し復元一致を検査する。
    引数: なし。返り値: None。
    """
    f0=ROOT/'work/129短期回復の評価/F0.json'
    body=f0.read_bytes()
    assert sha(body)=='41883e6f698dddce6224a27f3d835f8deb236ffd1a0035bdee432b2fcf3c71f5'
    fixed=json.loads(body)
    documents=[]
    for name,expected in fixed['ファイル'].items():
        path=Path(name)
        if path.suffix.lower()!='.md':continue
        original=path.read_bytes()
        assert sha(original)==expected,str(path)
        text=original.decode('utf-8')
        assert text.encode('utf-8')==original
        documents.append({'path':path.relative_to(ROOT).as_posix(),'bytes':len(original),'sha256':expected,'本文':text})
    out={'試行':129,'F0SHA':sha(body),'保存対象':'F0の全MD原文（正式結果記述前）','文書':documents}
    encoded=(json.dumps(out,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    compressed=gzip.compress(encoded,mtime=0)
    folder=FORMAL/'検査';folder.mkdir(exist_ok=True)
    path=folder/'実行前文書.json.gz'
    with path.open('xb') as stream:stream.write(compressed)
    restored=json.loads(gzip.decompress(path.read_bytes()))
    for d in restored['文書']:assert sha(d['本文'].encode('utf-8'))==d['sha256']
    proof={'成功':True,'F0SHA':sha(body),'MD原文数':len(documents),'gzipSHA':sha(compressed),'解凍SHA':sha(encoded),'保存bytes':len(compressed),'全原文SHA一致':True,'全復元SHA一致':True,'金融計算再実行':False,'原板再読':False}
    (folder/'実行前文書の確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (folder/'出生前F0.json').write_bytes(body)
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':
    main()
