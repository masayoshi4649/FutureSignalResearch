package main

import (
	"testing"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	source "shortbirth129"
)

// Test格子とriskの交差 は同じ連続capでも10pt格子に値がない場合を検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test格子とriskの交差(t *testing.T) {
	for _, tc := range []struct {
		atr, cap, I float64
		n           int
	}{{19, 1009.75, 990, 0}, {20, 1010, 990, 1}, {59, 1019.75, 990, 1}, {60, 1020, 990, 2}, {100, 1025, 800, 0}} {
		for _, side := range []int{1, -1} {
			price := func(x float64) float64 {
				if side < 0 {
					return 3000 - x
				}
				return x
			}
			e := source.Event{ID: "人工", Mode: "C1", Side: side, HoldBoundary: price(1005), EntryCap: price(tc.cap), Invalidation: price(tc.I), ATR5: tc.atr, Fields: map[string]any{}}
			g := geometry(e)
			if g.GridPoints != tc.n {
				t.Fatalf("格子/鏡像:%+v want%d", g, tc.n)
			}
		}
	}
}

// Test段階の単位保存 はRaw回数と閉鎖足と候補数を混ぜず元件数を保存します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test段階の単位保存(t *testing.T) {
	s := source.SceneResult{Session: "人工", Births: 1, ByMode: map[string]int{"C1": 1}, Stats: map[string]int{"採用Raw": 100, "閉鎖1分": 4, "既知閉鎖1分": 3, "C1/1/背景不足": 50, "C1/-1/背景不足": 40, "C1/1/接触": 2, "C1/1/拒否量不足": 3, "C1/1/出生": 1, "数量未知": 2}}
	r := stages(s)
	if r.Raw != 100 || r.MinuteAttempts != 4 || r.MinuteKnown != 3 || r.Stage["C1"]["背景不足"] != 90 || r.Stage["C1"]["接触"] != 2 || r.Stage["C1"]["拒否量不足"] != 3 || r.Other["数量未知"] != 2 {
		t.Fatalf("単位/件数差:%+v", r)
	}
}

// Test同Raw全TFと量窓 は公表だけの診断で未来配送と未知量を埋めません。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test同Raw全TFと量窓(t *testing.T) {
	s := source.Scene{Session: "人工_Day", Contract: "NK"}
	for i := 0; i < 21; i++ {
		end := 36000 + float64(i*300)
		stamp := rules.Stamp{Time: end + 1, Index: i, Line: i + 1}
		for _, width := range []int{300, 900, 1800} {
			if i > 0 && width != 300 {
				continue
			}
			f := rules.ChartFrame{ID: string(rune('A'+i)) + string(rune(width)), SessionID: s.Session, Contract: s.Contract, Width: width, Start: end - float64(width), End: end, AvailableAt: end + 1, DeliveryAt: end + 1, PriceKnown: true, VolumeKnown: true, Volume: 10, OHLC: rules.OHLC{Open: 1000, High: 1010, Low: 990, Close: 1000}}
			s.Pubs = append(s.Pubs, rules.Publication{Stamp: stamp, Frame: rules.Frame{Frame: f}})
		}
	}
	r, e := backgrounds([]source.Scene{s})
	if e != nil {
		t.Fatal(e)
	}
	if len(r) != 1 || r[0].Snapshots != 21 || r[0].Roles["RVOL5_known_or_pass"] != 1 || r[0].First["RVOL5"] != 42001 || r[0].Roles["range12_known_or_pass"] != 10 {
		t.Fatalf("公表配送/数量窓差:%+v", r)
	}
	if r[0].Roles["15_price_known"] != 4 || r[0].Roles["30_price_known"] != 7 {
		t.Fatalf("TFfresh境界差:%+v", r[0].Roles)
	}
}
