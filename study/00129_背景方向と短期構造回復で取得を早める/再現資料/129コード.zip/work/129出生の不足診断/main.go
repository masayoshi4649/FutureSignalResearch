package main

import (
	"bytes"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"math"
	"os"
	"sort"
	"strings"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	source "shortbirth129"
)

type Bar = source.Bar

type Geometry struct {
	ID          string  `json:"id"`
	Mode        string  `json:"mode"`
	Side        int     `json:"side"`
	K           float64 `json:"K"`
	Cap         float64 `json:"cap"`
	I           float64 `json:"I"`
	ATR         float64 `json:"atr5"`
	RawLast     float64 `json:"birth_last"`
	FirstRaw    float64 `json:"first_10pt_price"`
	LastRaw     float64 `json:"last_10pt_price"`
	GridPoints  int     `json:"feasible_10pt_prices"`
	CapDistance float64 `json:"cap_distance"`
	OneGrid     bool    `json:"only_one_10pt_price"`
}

type Counters map[string]int

type BackgroundScene struct {
	Session   string             `json:"session"`
	Snapshots int                `json:"five_delivery_snapshots"`
	First     map[string]float64 `json:"first_known"`
	Roles     Counters           `json:"roles"`
}

type StageScene struct {
	Session        string              `json:"session"`
	Births         int                 `json:"births"`
	ByMode         map[string]int      `json:"by_mode"`
	Raw            int                 `json:"accepted_raw"`
	MinuteAttempts int                 `json:"minute_close_attempts"`
	MinuteKnown    int                 `json:"known_minute_closes"`
	Stage          map[string]Counters `json:"stage_counters"`
	Other          Counters            `json:"quality_counters"`
}

// digest は読んだ保存ファイルのSHAを返します。
//
// 引数: b([]byte)。返り値: stringです。
func digest(b []byte) string { x := sha256.Sum256(b); return hex.EncodeToString(x[:]) }

// readFixed は指定SHAが完全一致した後だけ小型成果/背景を解凍します。
//
// 引数: path/expected(string)、target(any)。返り値: errorです。原板は開きません。
func readFixed(path, expected string, target any) error {
	if len(expected) != 64 {
		return fmt.Errorf("SHA指定が必要")
	}
	data, e := os.ReadFile(path)
	if e != nil {
		return e
	}
	if digest(data) != expected {
		return fmt.Errorf("保存SHA差:%s", path)
	}
	var r io.Reader = bytes.NewReader(data)
	if len(data) > 1 && data[0] == 0x1f && data[1] == 0x8b {
		z, e := gzip.NewReader(r)
		if e != nil {
			return e
		}
		defer z.Close()
		r = z
	}
	return json.NewDecoder(r).Decode(target)
}

// geometry は方向を揃えたK/cap/risk区間と10pt格子の交差を求めます。
//
// 引数: e(source.Event)。返り値: Geometryです。実BBO取得可能性とは別です。
func geometry(e source.Event) Geometry {
	x := float64(e.Side)
	rmax := math.Min(125, 1.5*e.ATR5)
	lo, hi := math.Max(x*e.HoldBoundary, x*e.Invalidation+10), math.Min(x*e.EntryCap, x*e.Invalidation+rmax)
	first, last := math.Ceil((lo-1e-8)/10)*10, math.Floor((hi+1e-8)/10)*10
	n := 0
	if last >= first {
		n = int(math.Round((last-first)/10)) + 1
	}
	lastPrice, _ := e.Fields["actual_raw_last"].(float64)
	return Geometry{ID: e.ID, Mode: e.Mode, Side: e.Side, K: e.HoldBoundary, Cap: e.EntryCap, I: e.Invalidation, ATR: e.ATR5, RawLast: lastPrice, FirstRaw: x * first, LastRaw: x * last, GridPoints: n, CapDistance: x * (e.EntryCap - e.HoldBoundary), OneGrid: n == 1}
}

// stages は合算Statsをそのまま保ち、単位の違う拒否を率へ混ぜません。
//
// 引数: scene(source.SceneResult)。返り値: StageSceneです。
func stages(scene source.SceneResult) StageScene {
	r := StageScene{Session: scene.Session, Births: scene.Births, ByMode: scene.ByMode, Raw: scene.Stats["採用Raw"], MinuteAttempts: scene.Stats["閉鎖1分"], MinuteKnown: scene.Stats["既知閉鎖1分"], Stage: map[string]Counters{}, Other: Counters{}}
	for _, m := range []string{"C1", "C2", "C3"} {
		r.Stage[m] = Counters{}
	}
	for k, v := range scene.Stats {
		parts := strings.SplitN(k, "/", 3)
		if len(parts) == 3 && (parts[0] == "C1" || parts[0] == "C2" || parts[0] == "C3") {
			r.Stage[parts[0]][parts[2]] += v
		} else {
			r.Other[k] = v
		}
	}
	return r
}

// add は独立した真のgateだけをsnapshot単位で数えます。
//
// 引数: c(Counters)、name(string)、pass(bool)。返り値: ありません。
func add(c Counters, name string, pass bool) {
	if pass {
		c[name]++
	}
}

// first は最初の既知時計だけを保存します。
//
// 引数: r(*BackgroundScene)、name(string)、at(float64)、pass(bool)。返り値: ありません。
func first(r *BackgroundScene, name string, at float64, pass bool) {
	if _, ok := r.First[name]; !ok && pass {
		r.First[name] = at
	}
}

// roles は当時5分snapshotの指標共存を検査します。Raw接触へは置換しません。
//
// 引数: r(*BackgroundScene)、s(rules.Snapshot)、at(float64)、five([]rules.Publication)。返り値: ありません。
func roles(r *BackgroundScene, s rules.Snapshot, at float64, five []rules.Publication) {
	r.Snapshots++
	p, price := priceFrame(s, 300)
	t := p.Frame.Frame.Technical
	_, comm := common(s)
	for name, pass := range map[string]bool{"price5": price, "ATR5": t.ATR.Known, "previous_ATR5": t.PreviousATR.Known, "RSI5": t.RSI.Known, "previous_RSI5": t.PreviousRSI.Known, "Hist5": t.Histogram.Known, "previous_Hist5": t.PreviousHistogram.Known, "RVOL5": s.RVOL5.Known, "common": comm, "range12": len(five) == 12} {
		add(r.Roles, name+"_known_or_pass", pass)
		first(r, name, at, pass)
	}
	for _, w := range []int{900, 1800} {
		q, k := priceFrame(s, w)
		u := q.Frame.Frame.Technical
		d := q.Frame.DMI
		for name, pass := range map[string]bool{"price": k, "Gap": u.Gap.Known, "EMA21Delta": u.EMA21Delta.Known, "ADX": d.ADX.Known, "DI": known(d.PlusDI, d.MinusDI)} {
			key := fmt.Sprintf("%d_%s", w/60, name)
			add(r.Roles, key+"_known", pass)
			first(r, key, at, pass)
		}
	}
	add(r.Roles, "ATR5_lt20", t.ATR.Known && t.ATR.Value < 20)
	add(r.Roles, "ATR5_lt60", t.ATR.Known && t.ATR.Value < 60)
	add(r.Roles, "ATR5_lt80", t.ATR.Known && t.ATR.Value < 80)
	add(r.Roles, "common_and_ATR5_lt20", comm && t.ATR.Value < 20)
	if len(five) == 12 {
		lo, hi := math.Inf(1), math.Inf(-1)
		for _, q := range five {
			lo = math.Min(lo, q.Frame.Frame.OHLC.Low)
			hi = math.Max(hi, q.Frame.Frame.OHLC.High)
		}
		add(r.Roles, "range12_width_lt145", hi-lo < 145)
	}
	for _, side := range []int{1, -1} {
		x := float64(side)
		prefix := fmt.Sprintf("side%d/", side)
		cohort, dir := directional(s, side)
		hist := t.Histogram.Known && x*t.Histogram.Value > 0
		rsi := t.RSI.Known && x*(t.RSI.Value-50) >= -10
		add(r.Roles, prefix+"directional", dir)
		add(r.Roles, prefix+"directional_"+cohort, dir)
		add(r.Roles, prefix+"directional_hist_positive", dir && hist)
		add(r.Roles, prefix+"directional_hist_nonpositive", dir && t.Histogram.Known && !hist)
		add(r.Roles, prefix+"directional_hist_unknown", dir && !t.Histogram.Known)
		add(r.Roles, prefix+"directional_common", dir && comm)
		add(r.Roles, prefix+"directional_common_hist_positive", dir && comm && hist)
		add(r.Roles, prefix+"directional_rsi_tolerance", dir && rsi)
		bandKnown := price && known(t.EMA8, t.EMA21, t.ATR) && t.ATR.Value > 0
		low, high := math.Min(t.EMA8.Value, t.EMA21.Value)-.25*t.ATR.Value, math.Max(t.EMA8.Value, t.EMA21.Value)+.25*t.ATR.Value
		closeIn := bandKnown && p.Frame.Frame.OHLC.Close >= low && p.Frame.Frame.OHLC.Close <= high
		rangeIn := bandKnown && p.Frame.Frame.OHLC.High >= low && p.Frame.Frame.OHLC.Low <= high
		add(r.Roles, prefix+"directional_close_in_current_EMA_band", dir && closeIn)
		add(r.Roles, prefix+"directional_close_in_band_hist_positive", dir && closeIn && hist)
		add(r.Roles, prefix+"directional_common_close_in_band", dir && comm && closeIn)
		add(r.Roles, prefix+"directional_common_close_in_band_hist_positive", dir && comm && closeIn && hist)
		add(r.Roles, prefix+"directional_closed5_intersects_current_band", dir && rangeIn)
		add(r.Roles, prefix+"directional_closed5_intersects_band_hist_positive", dir && rangeIn && hist)
		for _, mode := range []string{"C1", "C2", "C3"} {
			c, ok := context(s, mode, side, mode == "C3")
			key := prefix + mode + "_context"
			add(r.Roles, key, ok)
			add(r.Roles, key+"_"+c, ok)
			first(r, key, at, ok)
			add(r.Roles, key+"_ATR_lt20", ok && t.ATR.Value < 20)
		}
	}
}

// backgrounds は全公表を同Raw単位で配送し、5分配送のある時点だけを数えます。
//
// 引数: scenes([]source.Scene)。返り値: []BackgroundScene/errorです。
func backgrounds(scenes []source.Scene) ([]BackgroundScene, error) {
	bank := rules.NewBank()
	out := []BackgroundScene{}
	for _, scene := range scenes {
		if e := bank.StartSession(scene.Session, scene.Contract); e != nil {
			return nil, e
		}
		r := BackgroundScene{Session: scene.Session, First: map[string]float64{}, Roles: Counters{}}
		five := []rules.Publication{}
		for i := 0; i < len(scene.Pubs); {
			stamp := scene.Pubs[i].Stamp
			j := i
			has5 := false
			for j < len(scene.Pubs) && scene.Pubs[j].Stamp == stamp {
				p := scene.Pubs[j]
				if e := bank.Add(p); e != nil {
					return nil, e
				}
				if p.Frame.Frame.Width == 300 {
					has5 = true
					if !p.Frame.Frame.PriceKnown {
						five = nil
					} else {
						if len(five) > 0 && p.Frame.Frame.End-five[len(five)-1].Frame.Frame.End != 300 {
							five = nil
						}
						five = append(five, p)
						if len(five) > 12 {
							five = five[len(five)-12:]
						}
					}
				}
				j++
			}
			if has5 {
				s, e := bank.Current(rules.Quote{Time: stamp.Time, Index: stamp.Index, Line: stamp.Line, Last: 1})
				if e != nil {
					return nil, e
				}
				roles(&r, s, stamp.Time, five)
			}
			i = j
		}
		out = append(out, r)
	}
	return out, nil
}

// main は完了SHA確認後に保存Stats/固定公表だけを診断します。
//
// 引数: births/birth-sha/background/background-sha/output(string)、execute-diagnostic(bool)。返り値: ありません。
func main() {
	birth := flag.String("births", "", "Root完了後の出生JSON")
	bsha := flag.String("birth-sha", "", "Root通知SHA")
	bg := flag.String("background", "", "固定gap300公表")
	bgsha := flag.String("background-sha", "", "固定背景SHA")
	output := flag.String("output", "", "未作成診断JSON")
	execute := flag.Bool("execute-diagnostic", false, "Root許可後の保存資料診断だけを明示実行")
	flag.Parse()
	if !*execute || *birth == "" || *output == "" || *bgsha != source.BackgroundSHA {
		fmt.Fprintln(os.Stderr, "完成SHA通知後だけ診断。明示入力/SHA/output/executeが必要。")
		os.Exit(2)
	}
	var births source.Result
	if e := readFixed(*birth, *bsha, &births); e != nil {
		panic(e)
	}
	if !births.Success || births.Trial != 129 || births.FinancialLabels || len(births.Scenes) != 73 || births.BackgroundSHA != source.BackgroundSHA {
		panic("129全場出生完了資料だけ使用")
	}
	var background struct {
		Success bool           `json:"success"`
		Scenes  []source.Scene `json:"scenes"`
	}
	if e := readFixed(*bg, *bgsha, &background); e != nil {
		panic(e)
	}
	if !background.Success || len(background.Scenes) != 73 {
		panic("背景73場差")
	}
	stage := []StageScene{}
	geo := []Geometry{}
	total := map[string]Counters{"C1": {}, "C2": {}, "C3": {}}
	totalBirths := 0
	seen := map[string]bool{}
	for i, s := range births.Scenes {
		if s.Session != background.Scenes[i].Session {
			panic("場順序差")
		}
		r := stages(s)
		stage = append(stage, r)
		totalBirths += r.Births
		for m, c := range r.Stage {
			for k, v := range c {
				total[m][k] += v
			}
		}
	}
	for _, e := range births.Events {
		if seen[e.ID] {
			panic("重複出生ID")
		}
		seen[e.ID] = true
		g := geometry(e)
		if g.GridPoints < 1 {
			panic("実出生と10pt格子幾何学が矛盾")
		}
		geo = append(geo, g)
	}
	if totalBirths != len(births.Events) {
		panic("出生総数差")
	}
	back, e := backgrounds(background.Scenes)
	if e != nil {
		panic(e)
	}
	sort.SliceStable(geo, func(i, j int) bool { return geo[i].ID < geo[j].ID })
	r := map[string]any{"成功": true, "自然Raw再読": false, "金融ラベル読取生成": false, "出生SHA": *bsha, "背景SHA": *bgsha, "単位の注意": "Statsの背景不足/Raw位置はRaw×候補、拒否量不足は候補×閉鎖1分の合算。公表診断は5分配送snapshotで時間重み/Raw接触とは別。", "未判別": "1分拒否量>=前足の単独効果、非出生setupのK/cap実位置、全EMA接触時のHist、旧contact失効I/期限の内訳は既存保存Statsだけでは分解不可。", "全場": stage, "系列段階合計": total, "出生幾何学": geo, "公表背景": back}
	body, e := json.MarshalIndent(r, "", "  ")
	if e != nil {
		panic(e)
	}
	f, e := os.OpenFile(*output, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if e != nil {
		panic(e)
	}
	if _, e = f.Write(append(body, '\n')); e != nil {
		panic(e)
	}
	if e = f.Close(); e != nil {
		panic(e)
	}
	fmt.Printf("保存Stats診断 全場=%d 出生=%d 金融=false 原板再読=false\n", len(stage), len(geo))
}
