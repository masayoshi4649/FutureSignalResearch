"""129F0を変更せず、背景条件の同体関数を不足診断側へ用意する。"""
from pathlib import Path
import hashlib
import json

OWN=Path(__file__).resolve().parent


def main() -> None:
    """
    機能: 小型context.goをpackageだけ変えてコピーし、出自を記録する。
    引数: なし。返り値: None。
    """
    source=OWN.parent/'129短期回復の出生/context.go'
    body=source.read_text(encoding='utf-8')
    target=OWN/'context129.go'
    with target.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(body.replace('package shortbirth129','package main',1))
    proof={'成功':True,'自然入力読取':False,'元':source.relative_to(OWN.parent.parent).as_posix(),'元SHA256':hashlib.sha256(source.read_bytes()).hexdigest(),'差':'package宣言のみ','旧129変更':False}
    (OWN/'固定条件の出自.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


if __name__=='__main__':
    main()
