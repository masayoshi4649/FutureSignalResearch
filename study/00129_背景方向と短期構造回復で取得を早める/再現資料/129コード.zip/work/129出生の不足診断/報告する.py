"""固定出生と公表の不足診断だけを日本語Markdownへまとめる。"""
from pathlib import Path
from collections import Counter
from datetime import datetime, timedelta, timezone
import hashlib
import json

OWN=Path(__file__).resolve().parent


def pct(n: int, d: int) -> str:
    """
    機能: 同じ単位の件数だけを百分率で表示する。
    引数: n/d(int)。返り値: str。
    """
    return f'{n}/{d} ({n/d:.1%})' if d else f'{n}/{d} (分母0)'


def clock(at: float | None) -> str:
    """
    機能: 価格時計をJSTへ表示する。
    引数: at(float|None)。返り値: str。
    """
    return datetime.fromtimestamp(at,timezone(timedelta(hours=9))).strftime('%m/%d %H:%M:%S') if at is not None else 'この場で既知/成立なし'


def main() -> None:
    """
    機能: 原板/金融未読のまま既存Statsを報告する。
    引数: なし。返り値: None。
    """
    path=OWN/'保存資料の診断_詳細.json'
    d=json.loads(path.read_text(encoding='utf-8'))
    assert d['成功'] and not d['自然Raw再読'] and not d['金融ラベル読取生成']
    scenes=d['全場'];back=d['公表背景'];stages=d['系列段階合計'];g=d['出生幾何学']
    assert len(scenes)==len(back)==73 and sum(x['births'] for x in scenes)==len(g)==91
    role=Counter()
    for x in back: role.update(x['roles'])
    def r(name: str) -> int:
        """
        機能: 正逆方向の公表snapshot件数を合計する。
        引数: name(str)。返り値: int。
        """
        return sum(role[f'side{s}/{name}'] for s in [1,-1])
    zero=[x for x in scenes if not x['births']]
    def category(x: dict) -> str:
        """
        機能: 0出生を保存された到達段階で区分する。
        引数: x(dict)。返り値: str。根本原因の一意分類ではない。
        """
        m=x['stage_counters']
        if sum(m[k].get('拒否setup',0)+m[k].get('弱い反対足',0) for k in ['C1','C2','C3']):return 'setup後/維持以前'
        if m['C1'].get('接触',0)+m['C2'].get('接触',0):return '接触後/拒否setup以前'
        return '接触・C3setup以前'
    cats=Counter(category(x) for x in zero)
    lines=['# 129出生不足の診断（金融を使わない）','',
           'Root通知の出生SHAを照合し、91出生・73場を検査した。出生有38場、0出生35場。原板再読・金融ラベルの読取/生成は行っていない。129/F0の条件・コードは変更していない。', '',
           f'- 出生SHA：`{d["出生SHA"]}`',f'- 背景SHA：`{d["背景SHA"]}`',f'- 数値正本：[保存資料の診断_詳細.json](保存資料の診断_詳細.json)（SHA `{hashlib.sha256(path.read_bytes()).hexdigest()}`）','',
           '## どの段階が細くなったか','',
           '|系列|接触|拒否/弱戻りsetup|次の別足回復|出生|setup失効|背景失効|',
           '|---|---:|---:|---:|---:|---:|---:|']
    for mode,c in stages.items():
        lines.append(f'|{mode}|{c.get("接触",0) if mode!="C3" else "対象外"}|{c.get("拒否setup",0)+c.get("弱い反対足",0)}|{c.get("次足回復",0) if mode=="C3" else "対象外"}|{c.get("出生",0)}|{c.get("setup失効",0)}|{c.get("背景失効",0)}|')
    lines += ['',
      'C1は接触444に対して拒否setup216、出生80。C2は接触179に対して拒否setup30、出生9で、別に位置/余地が残らない29回を記録した。C3は弱い反対足55から次足回復2、次足未回復19、setup失効32となり、Raw出生2まで減った。状態はgap/時計拒否/場末でも消えるため、表を完全な収支式へしない。', '',
      'C1の拒否量不足649、C2の同201は「前足連続性・拒否形・当/前の量既知・量正・量が前足以上」の合算で、単独の量gateに帰属できない。C1のRaw位置未成立59073、C2の6699、C3の240もRaw×活動setupの反復数であり、取引数や負け率ではない。1秒維持の期限resetはC1=6、C2=3で、少なくともこの特定reset回数を大量減少の主要因とは言えない。', '',
      f'全場の採用Rawは{sum(x["accepted_raw"] for x in scenes):,}行、1分閉鎖試行は{sum(x["minute_close_attempts"] for x in scenes):,}、価格既知閉鎖は{sum(x["known_minute_closes"] for x in scenes):,}。価格既知と数量既知は別である。', '',
      '## 初日の本当の不足','',
      f'初日Dayは採用Raw{scenes[0]["accepted_raw"]:,}、価格既知1分{scenes[0]["known_minute_closes"]}、5分配送snapshot{back[0]["five_delivery_snapshots"]}があり、1分価格履歴自体が全場ないわけではない。共通gateは37 snapshotで成立した。一方、15分ADXが場内で一度も既知にならず、30分の方向に使うGap/EMA21Δも場内で未知だった。C1/C3はADX15≥20を必須にし、C2もADX30未知のfallbackではADX15既知を必須にしたため、全系列の背景が成立しなかった。', '',
      '|初日Dayの値|最初の既知/成立時計(JST)|','|---|---|']
    for key in ['ATR5','Hist5','RVOL5','15_DI','15_Gap','15_EMA21Delta','15_ADX','30_Gap','30_EMA21Delta','common']:
        lines.append(f'|{key}|{clock(back[0]["first_known"].get(key))}|')
    lines += ['',
      '長期未知を支持に変えない原則は維持する。ただし「30分を未知maskにして15分だけで初日も使う」という意図に対し、15分ADXまで必須にした実装は初日を救っていない。次試行では「既知15分DI/MA/5分構造による別cohort」と「ADXが既知で支持するcohort」を分ける必要がある。未知ADXを低ADXや強ADXへ補完する案ではない。', '',
      '## EMA帯への押戻しとHist同向の共存','',
      '以下は同Rawの5/15/30を全Addした後の5分配送snapshotで、正負sideを合計した記述集計。公表Closeと現在公表EMA帯は当足Closeを含むので、当足内の当時Raw接触を復元した計数ではない。', '',
      '|母集団|Hist同向|','|---|---:|',
      f'|上位方向支持|{pct(r("directional_hist_positive"),r("directional"))}|',
      f'|上位方向支持＋公表CloseがEMA帯内|{pct(r("directional_close_in_band_hist_positive"),r("directional_close_in_current_EMA_band"))}|',
      f'|上位方向支持＋共通gate|{pct(r("directional_common_hist_positive"),r("directional_common"))}|',
      f'|上位方向支持＋共通gate＋公表CloseがEMA帯内|{pct(r("directional_common_close_in_band_hist_positive"),r("directional_common_close_in_band"))}|',
      f'|上位方向支持＋公表5分値幅がEMA帯と交差|{pct(r("directional_closed5_intersects_band_hist_positive"),r("directional_closed5_intersects_current_band"))}|', '',
      f'全{sum(x["five_delivery_snapshots"] for x in back)}個の5分配送時点に対し、C1背景成立はside合計{r("C1_context")}、C2は{r("C2_context")}、C3確認背景は{r("C3_context")}。', '',
      'EMA帯へ近づいた公表ではHist同向の比率が下がる。押戻し中のHist負を背景トレンド終了と同一視し、接触時にも確認時にも同向を要求することで候補が消える可能性を支える。ただしHist負の押戻しが勝つこと、Hist条件を外せば精度が上がることは未検証。次仮説は「接触時は減速を許し、短い確認時にΔHist/価格回復を見る」と段階を分けることであり、無条件の符号緩和ではない。', '',
      '## 10pt格子と20pt cap','',
      f'固定公表ではATR5既知{role["ATR5_known_or_pass"]} snapshot中、ATR<20は{role["ATR5_lt20"]}、ATR<60は{role["ATR5_lt60"]}、ATR<80は{role["ATR5_lt80"]}だった。したがって「ATR<20なのでK〜capに10pt格子点がない」という数学的欠陥は存在するが、今回の5分配送snapshotに実例はなく、大半0出生の実測主要因とは認定できない。', '',
      f'実出生91ではK/cap/risk区間内の10pt格子が1点だけのもの{sum(x["only_one_10pt_price"] for x in g)}、2点のもの{sum(x["feasible_10pt_prices"]==2 for x in g)}。最大でも2点という狭さは残る。RawLastがこの区間へ1秒維持で入ることと、その1秒後の実買Ask/売Bidが入ることは別で、後段取消をここでは読んでいない。非出生setupの値は保存されていないため、cap/risk/K割れの失敗内訳は算出できない。', '',
      'C2の145pt余地は10pt格子では実質150pt以上を要す。拒否Closeを旧域内へ戻す条件と組み合わせると、最小でもおおむね160ptのレンジ幅が必要になる（[補助レビュー](補助レビュー.md)）。125ptの余地がない小さい回転を除く意味はあるが、局所レンジを必ず1場1回で取れる保証にはならない。', '',
      '## 0出生35場の到達段階','',
      '以下は到達段階による機械分類で、失敗gateの一意な根本原因ではない。', '',
      '|分類|場数|','|---|---:|']
    for k,v in cats.items():lines.append(f'|{k}|{v}|')
    lines += ['', '|0出生の場|段階|C1接触/setup|C2接触/setup|C3弱戻りsetup|価格既知1分|','|---|---|---:|---:|---:|---:|']
    for x in zero:
        m=x['stage_counters']
        lines.append(f'|{x["session"]}|{category(x)}|{m["C1"].get("接触",0)}/{m["C1"].get("拒否setup",0)}|{m["C2"].get("接触",0)}/{m["C2"].get("拒否setup",0)}|{m["C3"].get("弱い反対足",0)}|{x["known_minute_closes"]}|')
    lines += ['', '## 次130へ持ち込む問い','',
      '1. 接触時の背景と確認時の再加速を分ける。Hist同向を一貫して強制せず、背景の持続、押戻しの失速、短い価格構造回復を別状態で確認する。',
      '2. 長期未知cohortと15分ADX未知cohortを明示する。初日に利用可能な15分DI/MAと5分値幅/量/短期構造だけで判断できる別条件を定義し、未知を支持へ補完しない。',
      '3. 量gateを単独に診断できるcounterと、K未回復/cap超過/risk過大/低riskを別counterで保存する。現Statsから単独効果を推定しない。capの変更を試すなら、格子に丸めた許容点数と実BBO spread/TTLを併記する。',
      '4. C3は大きい先行移動・薄い反対足・次足の全拒否高安回復を重ねると55setupから2確認へ減った。短期の構造を段階化したまま、回復境界と無効化の設計を新試行で比較する。', '',
      'これらは出生を増やす仕組みの仮説であり、70%精度や利益改善の証拠ではない。129は固定保存し、金融結果でこの診断の条件を後から切り替えない。']
    (OWN/'結果と次の問い.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print('73場/91出生の不足診断報告を保存。金融未読・原板再読なし。')


if __name__=='__main__':
    main()
