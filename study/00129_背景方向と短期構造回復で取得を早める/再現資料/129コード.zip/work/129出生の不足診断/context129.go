package main

import (
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"math"
)

// finite は有限な数値だけを許可します。
//
// 引数: values(...float64)。返り値: boolです。
func finite(values ...float64) bool {
	for _, v := range values {
		if math.IsNaN(v) || math.IsInf(v, 0) {
			return false
		}
	}
	return true
}

// known は全必要値の既知性を返します。
//
// 引数: values(...rules.Value)。返り値: boolです。
func known(values ...rules.Value) bool {
	for _, v := range values {
		if !v.Known {
			return false
		}
	}
	return true
}

// priceFrame は現在公表の価格既知性を判定します。
//
// 引数: s(rules.Snapshot)、width(int)。返り値: rules.Publication/boolです。
func priceFrame(s rules.Snapshot, width int) (rules.Publication, bool) {
	p, ok := s.Frames[width]
	return p, ok && p.Frame.Frame.PriceKnown
}

// delta は両端が既知の方向増分を確認します。
//
// 引数: now/previous(rules.Value)、side(int)。返り値: boolです。
func delta(now, previous rules.Value, side int) bool {
	return known(now, previous) && float64(side)*(now.Value-previous.Value) > 0
}

// common は5分値幅・量とRSIスパイクを背景として制限します。
//
// 引数: s(rules.Snapshot)。返り値: rules.Technical/boolです。
func common(s rules.Snapshot) (rules.Technical, bool) {
	p, ok := priceFrame(s, 300)
	t := p.Frame.Frame.Technical
	pass := ok && known(t.ATR, t.PreviousATR, t.TR, t.RSI, t.PreviousRSI, t.Histogram, s.RVOL5) && t.ATR.Value > 0 && t.PreviousATR.Value > 0 && t.TR.Value >= 0 && t.TR.Value <= 2*t.PreviousATR.Value && math.Abs(t.RSI.Value-t.PreviousRSI.Value) <= 10 && s.RVOL5.Value >= .5
	return t, pass
}

// directional は既知30方向の支持と、未知時だけの15分cohortを分けます。
//
// 引数: s(rules.Snapshot)、side(int)。返り値: string/boolはB30又はB15と成立です。
func directional(s rules.Snapshot, side int) (string, bool) {
	p15, ok := priceFrame(s, 900)
	if !ok {
		return "", false
	}
	d := p15.Frame.DMI
	t15 := p15.Frame.Frame.Technical
	x := float64(side)
	if !known(d.PlusDI, d.MinusDI, d.ADX) || x*(d.PlusDI.Value-d.MinusDI.Value) <= 0 || d.ADX.Value < 20 {
		return "", false
	}
	p30, present := priceFrame(s, 1800)
	t30 := p30.Frame.Frame.Technical
	if present && known(t30.Gap, t30.EMA21Delta) {
		return "B30", x*t30.Gap.Value > 0 && x*t30.EMA21Delta.Value > 0
	}
	if present && ((t30.Gap.Known && x*t30.Gap.Value <= 0) || (t30.EMA21Delta.Known && x*t30.EMA21Delta.Value <= 0)) {
		return "", false
	}
	return "B15", known(t15.Gap, t15.EMA21Delta) && x*t15.Gap.Value > 0 && x*t15.EMA21Delta.Value > 0
}

// direction3 はMA並びと両傾きの厳密な同方向を判定します。
//
// 引数: t(rules.Technical)。返り値: intは±1/中立0、boolは既知です。
func direction3(t rules.Technical) (int, bool) {
	if !known(t.Gap, t.EMA8Delta, t.EMA21Delta) {
		return 0, false
	}
	if t.Gap.Value > 0 && t.EMA8Delta.Value > 0 && t.EMA21Delta.Value > 0 {
		return 1, true
	}
	if t.Gap.Value < 0 && t.EMA8Delta.Value < 0 && t.EMA21Delta.Value < 0 {
		return -1, true
	}
	return 0, true
}

// strongCounter は既知の非減速・強い逆向きを拒否します。
//
// 引数: s(rules.Snapshot)、side(int)。返り値: boolです。
func strongCounter(s rules.Snapshot, side int) bool {
	for _, width := range []int{300, 1800} {
		p, ok := priceFrame(s, width)
		if !ok {
			continue
		}
		d, k := direction3(p.Frame.Frame.Technical)
		a := p.Frame.DMI
		if k && d == -side && known(a.ADX, a.PreviousADX) && a.ADX.Value >= 25 && a.ADX.Value >= a.PreviousADX.Value {
			return true
		}
	}
	return false
}

// weakDMI は低ADX又は既知低下を判定します。
//
// 引数: d(rules.DMI)。返り値: boolです。
func weakDMI(d rules.DMI) bool {
	return d.ADX.Known && (d.ADX.Value <= 20 || (d.PreviousADX.Known && d.ADX.Value < d.PreviousADX.Value))
}

// context は系列ごとの背景・勢い条件を、当時公表だけで判定します。
//
// 引数: s(rules.Snapshot)、mode(string)、side(int)、confirm(bool)。返り値: cohort(string)/boolです。
func context(s rules.Snapshot, mode string, side int, confirm bool) (string, bool) {
	t, ok := common(s)
	if !ok {
		return "", false
	}
	x := float64(side)
	if mode == "C1" || mode == "C3" {
		cohort, ok := directional(s, side)
		if !ok || x*t.Histogram.Value <= 0 {
			return "", false
		}
		if mode == "C1" {
			return cohort, x*(t.RSI.Value-50) >= -10
		}
		pass := t.Gap.Known && x*t.Gap.Value > 0 && x*(t.RSI.Value-50) >= 0
		if confirm {
			pass = pass && (delta(t.RSI, t.PreviousRSI, side) || delta(t.Histogram, t.PreviousHistogram, side))
		}
		return cohort, pass
	}
	p15, present := priceFrame(s, 900)
	a15 := p15.Frame.Frame.Technical
	p5, _ := priceFrame(s, 300)
	if !present || !known(a15.Gap, a15.ATR) || a15.ATR.Value <= 0 || math.Abs(a15.Gap.Value) > .5*a15.ATR.Value || !weakDMI(p5.Frame.DMI) || strongCounter(s, side) || !delta(t.RSI, t.PreviousRSI, side) || !delta(t.Histogram, t.PreviousHistogram, side) {
		return "", false
	}
	p30, has30 := priceFrame(s, 1800)
	if has30 && p30.Frame.DMI.ADX.Known {
		return "B30", weakDMI(p30.Frame.DMI)
	}
	return "B15", weakDMI(p15.Frame.DMI)
}

// rejection は方向実体又は逆側ヒゲの拒否を判定します。
//
// 引数: b(Bar)、side(int)。返り値: boolです。
func rejection(b Bar, side int) bool {
	o := b.OHLC
	if float64(side)*(o.Close-o.Open) > 0 {
		return true
	}
	span := o.High - o.Low
	if span <= 0 {
		return false
	}
	wick := math.Min(o.Open, o.Close) - o.Low
	if side < 0 {
		wick = o.High - math.Max(o.Open, o.Close)
	}
	return wick/span >= .25
}

// refs は同じIDの当時参照を一度だけ保持します。
//
// 引数: lists(...[]rules.Ref)。返り値: []rules.Refです。
func refs(lists ...[]rules.Ref) []rules.Ref {
	out := []rules.Ref{}
	seen := map[string]bool{}
	for _, list := range lists {
		for _, r := range list {
			if !seen[r.ID] {
				out = append(out, r)
				seen[r.ID] = true
			}
		}
	}
	return out
}
