"""不足診断の人工検査と129Source不変を確認する。自然Raw/金融を開かない。"""
from pathlib import Path
import hashlib
import json
import re
import subprocess

OWN=Path(__file__).resolve().parent
SOURCE=OWN.parent/'129短期回復の出生'


def sha(path: Path) -> str:
    """
    機能: 小型コード/資料の保存SHAを求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 既存129の16指紋不変と診断3人工test/vet/buildを確認する。
    引数: なし。返り値: None。
    """
    proof_path=SOURCE/'準備の確認.json'
    assert sha(proof_path)=='4176098a18c62b3b53fea2b8890ba7996bbd3bc086617396c606d7c0d8ae7296'
    old=json.loads(proof_path.read_text(encoding='utf-8'))
    for item in old['コードと文書']:assert sha(SOURCE/item['path'])==item['sha256'],item['path']
    assert sha(SOURCE/'短期回復の出生.exe')==old['実行体SHA']
    assert (SOURCE/'context.go').read_text(encoding='utf-8').replace('package shortbirth129','package main',1)==(OWN/'context129.go').read_text(encoding='utf-8')
    checks=[]
    for args,expected in [(['go','test','-count=1','-v','./...'],0),(['go','vet','./...'],0),(['go','build','-o','不足を診断する.exe','.'],0),([str(OWN/'不足を診断する.exe')],2)]:
        run=subprocess.run(args,cwd=OWN,encoding='utf-8',capture_output=True)
        assert run.returncode==expected,(args,run.stdout,run.stderr)
        checks.append({'引数':args,'終了値':run.returncode,'標準出力':run.stdout,'標準エラー':run.stderr})
    tests=re.findall(r'^=== RUN   ([^/\r\n]+)$',checks[0]['標準出力'],re.M)
    assert len(tests)==3,tests
    paths=[*OWN.glob('*.go'),*OWN.glob('*.py'),OWN/'go.mod',OWN/'README.md',OWN/'結果と次の問い.md',OWN/'補助レビュー.md',OWN/'固定条件の出自.json']
    d=json.loads((OWN/'保存資料の診断_詳細.json').read_text(encoding='utf-8'))
    assert not d['金融ラベル読取生成'] and not d['自然Raw再読']
    result={'成功':True,'金融結果未読':True,'原板再読なし':True,'旧129指紋不変数':len(old['コードと文書']),'旧129実行体不変':True,'context関数同体':True,'主人工検査':tests,'検査':checks,'保存診断SHA':sha(OWN/'保存資料の診断_詳細.json'),'コードと文書':[{'path':p.relative_to(OWN).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(paths)],'実行体SHA':sha(OWN/'不足を診断する.exe')}
    (OWN/'診断の確認.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('旧129不変・3人工検査・同体context・診断入力を確認。')


if __name__=='__main__':
    main()
