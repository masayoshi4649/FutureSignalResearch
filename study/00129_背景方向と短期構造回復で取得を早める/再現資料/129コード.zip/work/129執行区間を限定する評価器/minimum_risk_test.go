package holdingohlc113

import "testing"

// TestMinimumRiskMirror129 は入力で指定した最小距離を実取得側でも守ることを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestMinimumRiskMirror129(t *testing.T) {
	for _, reverse := range []bool{false, true} {
		for _, risk := range []float64{5, 10} {
			q := artificialQuote129(100, 0, 995, 1000, 1000)
			e := artificialBirth129(q)
			e.HoldBoundary = 1000
			e.EntryCap = 1050
			e.MinimumRisk = 10
			e.Invalidation = 1010 - risk
			fill := artificialQuote129(101, 1, 1000, 1010, 1000)
			if reverse {
				e = mirrorBirth129(e, 3000)
				q = mirrorQuote129(q, 3000)
				fill = mirrorQuote129(fill, 3000)
			}
			s := Scene129{Start: 90, End: 5000, ForceClose: 4900, ExpectedAccepted: 10, Events: []Birth129{e}}
			if _, err := validateBirths129(s); err != nil {
				t.Fatal(err)
			}
			r := request129(e, q, 4900)
			got := pendingBirth129(r, fill, 4900)
			if got != (risk == 10) {
				t.Fatalf("最小riskの鏡像/包含境界差:%t %g %s", reverse, risk, r.Status)
			}
		}
	}
}
