package holdingohlc113

import (
	"fmt"
	"math"
)

// phaseScene129 は、価格時計上のザラバ観測終端と新規要求の余裕を明示します。
//
// 引数: s(Scene129)は元の場定義です。execution_end省略はEnd-300で導出し、指定値は一致必須です。
// 返り値: Scene129/errorは値copyした実行用の場又は不正理由です。元の場・Input bytesを変更しません。
// 2分の新規bufferは受信時刻の復元ではなく、価格時計の遅れが残る代理モデル上の余裕です。
func phaseScene129(s Scene129) (Scene129, error) {
	if !finite(s.Start, s.End, s.ForceClose, s.ExecutionEnd) || s.ForceClose <= s.Start || s.ForceClose > s.End {
		return s, fmt.Errorf("執行区間の時計/新規限界差:%s", s.Session)
	}
	executionEnd := s.End - 300
	if executionEnd <= s.Start || (s.ExecutionEnd != 0 && s.ExecutionEnd != executionEnd) {
		return s, fmt.Errorf("execution_endはsession.end-300が必要:%s", s.Session)
	}
	s.ExecutionEnd = executionEnd
	s.ForceClose = math.Min(s.ForceClose, executionEnd-120)
	if s.ForceClose <= s.Start {
		return s, fmt.Errorf("新規2分buffer後に執行区間がない:%s", s.Session)
	}
	return s, nil
}

// phaseCut129 は、執行終端以降の未完了観測だけを打ち切ります。
//
// 引数: c(*Candidate129)は正逆BBO/Lastの候補、q(Quote)は現在行、executionEnd(float64)は除外境界です。
// 返り値: boolは境界以降なら真です。既知touchと完了済み観測を変更しません。
func phaseCut129(c *Candidate129, q Quote, executionEnd float64) bool {
	if q.Time < executionEnd {
		return false
	}
	for i := range c.Outcomes {
		if c.Outcomes[i].Status == "pending" {
			c.Outcomes[i].Status = "phase_censored"
		}
	}
	return true
}
