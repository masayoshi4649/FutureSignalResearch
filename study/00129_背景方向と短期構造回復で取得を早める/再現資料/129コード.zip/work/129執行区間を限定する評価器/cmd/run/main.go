package main

import (
	"flag"
	"fmt"
	entry "independentbirth129"
	"os"
)

// main は固定済み独立出生を原板へ因果配送します。
//
// 引数: CLI input/sha256/output(string)、workers(int)。返り値: ありません。
func main() {
	i := flag.String("input", "", "固定入力")
	s := flag.String("sha256", "", "入力SHA")
	o := flag.String("output", "", "新規結果")
	w := flag.Int("workers", 8, "並列数")
	flag.Parse()
	if e := entry.RunBirth129(*i, *s, *o, *w); e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
}
