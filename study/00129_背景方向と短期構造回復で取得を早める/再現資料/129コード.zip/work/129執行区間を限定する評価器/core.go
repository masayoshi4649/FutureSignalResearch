package holdingohlc113

var Widths129 = []float64{25, 50, 100, 125, 200}
var Horizons129 = []float64{1800, 3600}

type FixedEntry129 struct {
	ID    string `json:"id"`
	Side  int    `json:"side"`
	Entry Quote  `json:"entry"`
}
type Scene129 struct {
	Session          string     `json:"session"`
	Contract         string     `json:"contract"`
	Start            float64    `json:"start"`
	End              float64    `json:"end"`
	ForceClose       float64    `json:"force_close"`
	ExecutionEnd     float64    `json:"execution_end,omitempty"`
	Raw              FileRef    `json:"raw"`
	ExpectedAccepted int64      `json:"expected_accepted"`
	ExpectedQuality  *Counts    `json:"expected_quality"`
	Events           []Birth129 `json:"events"`
}
type Input129 struct {
	Scenes []Scene129 `json:"scenes"`
}
type Signal129 struct {
	ID    string  `json:"id"`
	Side  int     `json:"side"`
	Time  float64 `json:"time"`
	Index int64   `json:"index"`
	Line  int64   `json:"source_line"`
	Quote Quote   `json:"quote"`
}
type First129 struct {
	Width     float64 `json:"width"`
	Direction int     `json:"direction"`
	Quote     *Quote  `json:"quote"`
}
type Outcome129 struct {
	Seconds  float64    `json:"seconds"`
	Deadline float64    `json:"deadline"`
	Status   string     `json:"status"`
	Touches  []First129 `json:"touches"`
	Endpoint *Quote     `json:"endpoint"`
	Points   *float64   `json:"points"`
	Net0     *float64   `json:"net0"`
	Net5     *float64   `json:"net5"`
}
type Candidate129 struct {
	Status         string       `json:"status"`
	Axis           string       `json:"axis"`
	Birth          Signal129    `json:"birth"`
	Entry          *Quote       `json:"entry"`
	EntryPrice     *float64     `json:"entry_price"`
	LastNormalTime float64      `json:"last_normal_time"`
	Outcomes       []Outcome129 `json:"outcomes"`
}
type Case129 struct {
	SourceEvent   Birth129      `json:"source_event"`
	RequestQuote  *Quote        `json:"request_quote"`
	ID            string        `json:"id"`
	OriginalSide  int           `json:"original_side"`
	Original      *Candidate129 `json:"original"`
	Reverse       *Candidate129 `json:"reverse"`
	ChartOriginal *Candidate129 `json:"chart_original"`
	ChartReverse  *Candidate129 `json:"chart_reverse"`
}
type Result129 struct {
	ExecutionEnd        float64           `json:"execution_end"`
	SourceForceClose    float64           `json:"source_force_close"`
	EffectiveForceClose float64           `json:"effective_force_close"`
	Births              []*BirthResult129 `json:"births"`
	Session             string            `json:"session"`
	Success             bool              `json:"success"`
	Error               string            `json:"error,omitempty"`
	Raw                 FileRef           `json:"raw"`
	ActualSHA           string            `json:"actual_sha256"`
	Before              FileStat          `json:"stat_before"`
	After               FileStat          `json:"stat_after"`
	RawEncoding         string            `json:"raw_encoding"`
	Quality             Counts            `json:"quality"`
	ExpectedQuality     *Counts           `json:"expected_quality"`
	Cases               []*Case129        `json:"cases"`
	RawPasses           int               `json:"raw_passes"`
	SourceEntries       int               `json:"source_entries"`
}

// fixedCandidate129 は元の取得原行に正又は逆の取得価格を固定します。
//
// 引数: id(string)、side(int)、q(Quote)、chart(bool)。返り値: *Candidate129です。
func fixedCandidate129(id string, side int, q Quote, chart bool) *Candidate129 {
	price := q.Ask
	axis := "BBO"
	if side < 0 {
		price = q.Bid
	}
	if chart {
		price = q.Last
		axis = "Last価格方向診断"
	}
	x := q
	c := &Candidate129{Status: "filled", Axis: axis, Birth: Signal129{ID: id, Side: side, Time: q.Time, Index: q.Index, Line: q.SourceLine, Quote: q}, Entry: &x, EntryPrice: &price, LastNormalTime: q.Time, Outcomes: []Outcome129{}}
	for _, h := range Horizons129 {
		o := Outcome129{Seconds: h, Deadline: q.Time + h, Status: "pending", Touches: []First129{}}
		for _, w := range Widths129 {
			o.Touches = append(o.Touches, First129{Width: w})
		}
		c.Outcomes = append(c.Outcomes, o)
	}
	return c
}

// fixedCase129 は同じ取得原行のBBO正逆とLast参考正逆を一組にします。
//
// 引数: source(FixedEntry129)、q(Quote)。返り値: *Case129です。
func fixedCase129(source FixedEntry129, q Quote) *Case129 {
	return &Case129{ID: source.ID, OriginalSide: source.Side, Original: fixedCandidate129(source.ID, source.Side, q, false), Reverse: fixedCandidate129(source.ID, -source.Side, q, false), ChartOriginal: fixedCandidate129(source.ID, source.Side, q, true), ChartReverse: fixedCandidate129(source.ID, -source.Side, q, true)}
}

// candidates129 は同時刻から始まる四つの独立観測を返します。
//
// 引数: c(*Case129)。返り値: []*Candidate129です。
func candidates129(c *Case129) []*Candidate129 {
	return []*Candidate129{c.Original, c.Reverse, c.ChartOriginal, c.ChartReverse}
}

// stepCase129 はBBOに固定kernel、価格参考にmarkだけLastのkernelを適用します。
//
// 引数: c(*Case129)、q(Quote)、previous/executionEnd(float64)。返り値: boolは未完了が残る場合です。
func stepCase129(c *Case129, q Quote, previous, executionEnd float64) bool {
	outcome129(c.Original, q, previous, executionEnd)
	outcome129(c.Reverse, q, previous, executionEnd)
	chartOutcome129(c.ChartOriginal, q, previous, executionEnd)
	chartOutcome129(c.ChartReverse, q, previous, executionEnd)
	for _, candidate := range candidates129(c) {
		for _, o := range candidate.Outcomes {
			if o.Status == "pending" {
				return true
			}
		}
	}
	return false
}

// finalize129 は未完了を打切りにし、約定不可の参考観測の金額を保存しません。
//
// 引数: c(*Case129)。返り値: ありません。価格方向・先着の値は変更しません。
func finalize129(c *Case129) {
	for _, candidate := range candidates129(c) {
		for i := range candidate.Outcomes {
			o := &candidate.Outcomes[i]
			if o.Status == "pending" {
				o.Status = "eof_censored"
			}
			if candidate.Axis != "BBO" {
				o.Net0 = nil
				o.Net5 = nil
			}
		}
	}
}
