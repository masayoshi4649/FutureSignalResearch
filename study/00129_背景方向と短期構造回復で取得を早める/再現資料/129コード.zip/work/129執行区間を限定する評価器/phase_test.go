package holdingohlc113

import (
	"encoding/json"
	"math"
	"testing"
)

// TestPhaseSceneLimits129 は、省略互換・指定不一致拒否・新規の境界と2分余裕を確認します。
//
// 引数: t(*testing.T)は人工検査です。返り値: ありません。
func TestPhaseSceneLimits129(t *testing.T) {
	input := Scene129{Session: "人工", Start: 0, End: 3000, ForceClose: 2900}
	current, err := phaseScene129(input)
	if err != nil || current.ExecutionEnd != 2700 || current.ForceClose != 2580 || input.ExecutionEnd != 0 || input.ForceClose != 2900 {
		t.Fatal("境界導出/値copy差", current, err)
	}
	old := input
	old.ForceClose = 2500
	old, err = phaseScene129(old)
	if err != nil || old.ForceClose != 2500 {
		t.Fatal("元の早い新規限界を緩めた")
	}
	explicit := input
	explicit.ExecutionEnd = 2700
	if _, err = phaseScene129(explicit); err != nil {
		t.Fatal("正しい明示境界を拒否", err)
	}
	for _, bad := range []float64{2700.1, math.NaN(), math.Inf(1)} {
		explicit.ExecutionEnd = bad
		if _, err = phaseScene129(explicit); err == nil {
			t.Fatal("誤った/非有限の境界を許可")
		}
	}
	q := artificialQuote129(2580, 0, 995, 1005, 1000)
	e := artificialBirth129(q)
	if got := request129(e, q, current.ForceClose); got.Status != "force_close" {
		t.Fatal("新規境界等号を許可")
	}
	// ----------------------------------------
	// 128のtrialや追加metadataを使わない既存Go入力型で、旧入力の省略を保つ。
	raw := []byte(`{"trial":128,"scenes":[{"session":"旧入力","start":0,"end":3000,"force_close":2900}]}`)
	var decoded Input129
	if err = json.Unmarshal(raw, &decoded); err != nil || len(decoded.Scenes) != 1 {
		t.Fatal("旧128入力型の互換差", err)
	}
	if result, err := phaseScene129(decoded.Scenes[0]); err != nil || result.ExecutionEnd != 2700 {
		t.Fatal("旧Input bytesを変えずに境界導出できない", err)
	}
}

// TestPhaseObservationBoundaryMirror129 は、BBO/Last正逆の直前/等号/直後を同じ窓で確認します。
//
// 引数: t(*testing.T)は人工検査です。返り値: ありません。
func TestPhaseObservationBoundaryMirror129(t *testing.T) {
	for _, reflected := range []bool{false, true} {
		for _, offset := range []float64{-1, 0, 1} {
			entry := artificialQuote129(100, 0, 995, 1000, 1000)
			next := artificialQuote129(1900+offset, 1, 1130, 1135, 1132)
			side := 1
			if reflected {
				entry, next, side = mirrorQuote129(entry, 3000), mirrorQuote129(next, 3000), -1
			}
			c := fixedCase129(FixedEntry129{ID: "人工", Side: side, Entry: entry}, entry)
			for _, candidate := range candidates129(c) {
				candidate.LastNormalTime = next.Time - 1
			}
			stepCase129(c, next, next.Time-1, 1900)
			for _, candidate := range candidates129(c) {
				o := candidate.Outcomes[0]
				if offset < 0 {
					if o.Status != "pending" || o.Touches[3].Direction == 0 || o.Endpoint != nil {
						t.Fatal("境界直前の既知観測を失った")
					}
				} else if o.Status != "phase_censored" || o.Touches[3].Direction != 0 || o.Endpoint != nil || o.Points != nil || o.Net0 != nil || o.Net5 != nil {
					t.Fatal("境界等号/後をtouch又は期限清算に利用")
				}
			}
		}
	}
	// ----------------------------------------
	// 期限が境界前でも、最初の期限Quoteが境界以降なら清算不能にする。
	entry := artificialQuote129(90, 0, 995, 1000, 1000)
	c := fixedCase129(FixedEntry129{ID: "期限人工", Side: 1, Entry: entry}, entry)
	for _, candidate := range candidates129(c) {
		candidate.LastNormalTime = 1899
	}
	stepCase129(c, artificialQuote129(1900, 1, 1100, 1110, 1105), 1899, 1900)
	for _, candidate := range candidates129(c) {
		if candidate.Outcomes[0].Status != "phase_censored" || candidate.Outcomes[0].Endpoint != nil {
			t.Fatal("期限+30秒猶予でザラバ外を清算に使用")
		}
	}
	completed := fixedCase129(FixedEntry129{ID: "完了済み人工", Side: 1, Entry: entry}, entry)
	for _, candidate := range candidates129(completed) {
		candidate.LastNormalTime = 1889
	}
	endpoint := artificialQuote129(1890, 1, 1100, 1110, 1105)
	stepCase129(completed, endpoint, 1889, 1900)
	stepCase129(completed, artificialQuote129(1900, 2, 5000, 5010, 1000), 1890, 1900)
	for _, candidate := range candidates129(completed) {
		if candidate.Outcomes[0].Status != "complete" || candidate.Outcomes[0].Endpoint == nil || *candidate.Outcomes[0].Endpoint != endpoint || candidate.Outcomes[1].Status != "phase_censored" {
			t.Fatal("境界前の完了済み観測を変更")
		}
	}
}

// TestPhaseKnownTouchRetained129 は、既知touchを残し未到達を未知に保ち、Last金額を付けないことを確認します。
//
// 引数: t(*testing.T)は人工検査です。返り値: ありません。
func TestPhaseKnownTouchRetained129(t *testing.T) {
	entry := artificialQuote129(100, 0, 995, 1000, 1000)
	c := fixedCase129(FixedEntry129{ID: "既知人工", Side: 1, Entry: entry}, entry)
	index := int64(1)
	previous := 100.0
	for at := 300.0; at <= 1700; at += 200 {
		stepCase129(c, artificialQuote129(at, index, 1000, 1005, 1002), previous, 1900)
		index++
		previous = at
	}
	touch := artificialQuote129(1801, index, 1130, 1135, 1132)
	stepCase129(c, touch, previous, 1900)
	boundary := artificialQuote129(1900, index+1, 5000, 5010, 1000)
	stepCase129(c, boundary, touch.Time, 1900)
	finalize129(c)
	for _, candidate := range candidates129(c) {
		for _, o := range candidate.Outcomes {
			if o.Status != "phase_censored" || o.Touches[3].Direction == 0 || o.Touches[3].Quote == nil || *o.Touches[3].Quote != touch || o.Endpoint != nil || o.Points != nil || o.Net0 != nil || o.Net5 != nil {
				t.Fatal("既知touchの保持又は未清算金額の扱い差")
			}
		}
		if candidate.LastNormalTime != touch.Time {
			t.Fatal("ザラバ外を最終正常観測へ更新")
		}
	}
	unknown := fixedCase129(FixedEntry129{ID: "未到達人工", Side: 1, Entry: entry}, entry)
	stepCase129(unknown, boundary, boundary.Time-1, 1900)
	finalize129(unknown)
	for _, candidate := range candidates129(unknown) {
		if candidate.Outcomes[0].Touches[3].Direction != 0 || candidate.Outcomes[0].Status != "phase_censored" {
			t.Fatal("未到達をザラバ外で既知化")
		}
	}
}

// TestPhaseScanKeepsAllRawQuality129 は、打切り後も全Rawを認証し、buffer境界の新規と清算を拒否することを確認します。
//
// 引数: t(*testing.T)は人工検査です。返り値: ありません。自然Rawは読みません。
func TestPhaseScanKeepsAllRawQuality129(t *testing.T) {
	rows := []Quote{}
	// appendQuoteは人工原行順を付けて追加する。
	// 引数: at/bid/ask/last(float64)。返り値: Quoteは追加した行。
	appendQuote := func(at, bid, ask, last float64) Quote {
		q := artificialQuote129(at, int64(len(rows)), bid, ask, last)
		rows = append(rows, q)
		return q
	}
	for at := 100.0; at <= 2800; at += 300 {
		appendQuote(at, 995, 1005, 1000)
	}
	born := appendQuote(3000, 995, 1005, 1000)
	appendQuote(3001, 995, 1005, 1000)
	for at := 3200.0; at <= 4600; at += 200 {
		appendQuote(at, 995, 1005, 1000)
	}
	pre := appendQuote(4679, 995, 1005, 1000)
	equal := appendQuote(4680, 995, 1005, 1000)
	appendQuote(4799, 995, 1005, 1000)
	late := appendQuote(4800, 5000, 5010, 1000)
	appendQuote(5000, 0, 0, 1000)
	appendQuote(5100, 6000, 6010, 1000)
	events := []Birth129{}
	for i, q := range []Quote{born, pre, equal, late} {
		e := artificialBirth129(q)
		e.ID = []string{"早期", "buffer直前", "buffer等号", "執行終端"}[i]
		e.Mode, e.MinimumRisk = "C1", 10
		events = append(events, e)
	}
	for _, compressed := range []bool{false, true} {
		s := fixtureScene129(t, rows, compressed, events)
		result, err := scanBirth129(s)
		if err != nil || !result.Success || result.Quality != *s.ExpectedQuality || result.Quality.Accepted != int64(len(rows)) || result.Quality.BadBBO != 1 || result.ActualSHA != s.Raw.SHA256 {
			t.Fatal("打切り後の全Raw/品質認証差", err)
		}
		if result.ExecutionEnd != 4800 || result.SourceForceClose != 5000 || result.EffectiveForceClose != 4680 || len(result.Cases) != 1 || len(result.Births) != 4 {
			t.Fatal("実行窓/元新規限界/出生保持差")
		}
		for _, b := range result.Births[1:] {
			if b.Status != "force_close" || b.Entry != nil {
				t.Fatal("buffer等号以降の新規/約定を許可")
			}
		}
		for _, candidate := range candidates129(result.Cases[0]) {
			for _, o := range candidate.Outcomes {
				if o.Status != "phase_censored" || o.Touches[3].Direction != 0 || o.Endpoint != nil {
					t.Fatal("同窓のザラバ外の偽到達を利用")
				}
			}
		}
	}
}
