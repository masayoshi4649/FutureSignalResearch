package holdingohlc113

import (
	"bytes"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"testing"
	"time"
)

// artificialQuote129 は出生・取得の人工原行を作ります。
//
// 引数: at(float64)、index(int64)、bid/ask/last(float64)。返り値: Quoteです。
func artificialQuote129(at float64, index int64, bid, ask, last float64) Quote {
	return Quote{Clock: time.Unix(0, int64(at*1e9)).UTC().Format(time.RFC3339Nano), Time: at, Index: index, SourceLine: index + 1, Bid: bid, Ask: ask, Last: last, QuoteOK: ask > bid && bid > 0}
}

// artificialBirth129 はK境界・半ATR上限に対応する人工出生を作ります。
//
// 引数: q(Quote)。返り値: Birth129です。
func artificialBirth129(q Quote) Birth129 {
	return Birth129{ID: "人工出生", Mode: "人工順行", Side: 1, At: Stamp129{Time: q.Time, Index: q.Index, Line: q.SourceLine}, EntryCap: 1050, Invalidation: 900, ATR5: 100, HoldBoundary: 1000, HoldMinimum: 0, Refs: json.RawMessage(`[{"id":"人工公表"}]`), Fields: json.RawMessage(`{"K":1000,"当時値":true}`)}
}

// mirrorQuote129 はK-priceの価格鏡像を作り、Bid/Askを入れ替えます。
//
// 引数: q(Quote)、k(float64)。返り値: Quoteです。
func mirrorQuote129(q Quote, k float64) Quote {
	q.Bid, q.Ask, q.Last = k-q.Ask, k-q.Bid, k-q.Last
	return q
}

// mirrorBirth129 は売買と全価格境界を同時に反転します。
//
// 引数: e(Birth129)、k(float64)。返り値: Birth129です。
func mirrorBirth129(e Birth129, k float64) Birth129 {
	e.Side = -e.Side
	e.EntryCap, e.Invalidation, e.HoldBoundary = k-e.EntryCap, k-e.Invalidation, k-e.HoldBoundary
	return e
}

// fixtureScene129 はplain/gzipの人工原板を保存し、全行品質を固定します。
//
// 引数: t(*testing.T)、rows([]Quote)、compressed(bool)、events([]Birth129)。返り値: Scene129です。
func fixtureScene129(t *testing.T, rows []Quote, compressed bool, events []Birth129) Scene129 {
	t.Helper()
	var raw bytes.Buffer
	var quality Counts
	for _, q := range rows {
		m := map[string]any{"Symbol": "X", "CurrentPriceTime": q.Clock, "CurrentPrice": q.Last}
		for depth := 1; depth <= 10; depth++ {
			m[fmt.Sprintf("Buy%d", depth)] = map[string]float64{"Price": q.Bid, "Qty": 1}
			m[fmt.Sprintf("Sell%d", depth)] = map[string]float64{"Price": q.Ask, "Qty": 1}
		}
		encoded, err := json.Marshal(m)
		if err != nil {
			t.Fatal(err)
		}
		raw.Write(encoded)
		raw.WriteByte('\n')
		quality.Lines++
		quality.Accepted++
		quality.Delivered++
		if !normal(q) {
			quality.BadBBO++
		}
	}
	data := raw.Bytes()
	if compressed {
		var result bytes.Buffer
		z := gzip.NewWriter(&result)
		if _, err := z.Write(data); err != nil {
			t.Fatal(err)
		}
		if err := z.Close(); err != nil {
			t.Fatal(err)
		}
		data = result.Bytes()
	}
	// ----------------------------------------
	// gzipも拡張子を同じにし、magic判定を検査する。
	path := filepath.Join(t.TempDir(), "人工原板.jsonl")
	if err := os.WriteFile(path, data, 0600); err != nil {
		t.Fatal(err)
	}
	hash := sha256.Sum256(data)
	return Scene129{Session: "人工場", Contract: "X", Start: rows[0].Time, End: rows[0].Time + 5000, ForceClose: rows[0].Time + 4900, Raw: FileRef{Path: path, SHA256: hex.EncodeToString(hash[:])}, ExpectedAccepted: int64(len(rows)), ExpectedQuality: &quality, Events: events}
}

// TestRequestDelayMirrorAndRiskBoundary129 は1秒・原行・正常BBO・鏡像・最大risk等号を検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestRequestDelayMirrorAndRiskBoundary129(t *testing.T) {
	for _, mirror := range []bool{false, true} {
		q := artificialQuote129(100, 0, 995, 1005, 1000)
		e := artificialBirth129(q)
		e.EntryCap, e.ATR5, e.Invalidation = 1010, 40, 950
		fill := artificialQuote129(101, 1, 1000, 1010, 1005)
		if mirror {
			q, fill, e = mirrorQuote129(q, 3000), mirrorQuote129(fill, 3000), mirrorBirth129(e, 3000)
		}
		r := request129(e, q, 5000)
		if r.Status != "pending" || r.Request == nil || *r.Request != q || r.Entry != nil || r.MaximumRisk != 60 {
			t.Fatal("出生時に将来約定を保存又は最大risk差")
		}
		if pendingBirth129(r, q, 5000) {
			t.Fatal("出生原行で取得")
		}
		early := fill
		early.Time = 100.999
		if pendingBirth129(r, early, 5000) || r.Evaluation != nil {
			t.Fatal("1秒未満で評価")
		}
		wrong := fill
		wrong.SourceLine = q.SourceLine
		if pendingBirth129(r, wrong, 5000) {
			t.Fatal("後物理行制約を無視")
		}
		wrong = fill
		wrong.Index = q.Index
		if pendingBirth129(r, wrong, 5000) {
			t.Fatal("後採用Index制約を無視")
		}
		bad := fill
		bad.Bid = bad.Ask
		if pendingBirth129(r, bad, 5000) || r.Evaluation != nil {
			t.Fatal("locked BBOで取得")
		}
		if !pendingBirth129(r, fill, 5000) || r.Status != "filled" || *r.Entry != fill || *r.Evaluation != fill || *r.Risk != 60 {
			t.Fatal("最初正常BBO/境界等号の取得差", r)
		}
	}
}

// TestFirstNormalRejectionsAndTTL129 はcap/hold/riskの優先と即取消・期限を検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestFirstNormalRejectionsAndTTL129(t *testing.T) {
	q := artificialQuote129(100, 0, 995, 1005, 1000)
	base := artificialBirth129(q)
	base.EntryCap, base.ATR5, base.Invalidation = 1010, 40, 950
	for _, mirror := range []bool{false, true} {
		for _, test := range []struct {
			name, want                           string
			price, last, invalidation, at, force float64
		}{
			{"上限優先", "entry_cap_rejected", 1011, 999, 950, 101, 5000},
			{"構造優先", "structure_lost", 1005, 999, 1005, 101, 5000},
			{"risk超過", "risk_rejected", 1010, 1005, 949, 101, 5000},
			{"riskゼロ", "risk_rejected", 1005, 1000, 1005, 101, 5000},
			{"TTL等号", "unfilled_expired", 1010, 1005, 950, 130, 5000},
			{"Force等号", "force_close", 1010, 1005, 950, 115, 115},
		} {
			t.Run(fmt.Sprintf("%t/%s", mirror, test.name), func(t *testing.T) {
				e, born := base, q
				e.Invalidation = test.invalidation
				next := artificialQuote129(test.at, 1, test.price-10, test.price, test.last)
				if mirror {
					e, born, next = mirrorBirth129(e, 3000), mirrorQuote129(born, 3000), mirrorQuote129(next, 3000)
				}
				r := request129(e, born, test.force)
				if pendingBirth129(r, next, test.force) || r.Status != test.want || r.Entry != nil {
					t.Fatalf("拒否種別差: got=%s want=%s", r.Status, test.want)
				}
				improved := artificialQuote129(116, 2, 995, 1005, 1005)
				if mirror {
					improved = mirrorQuote129(improved, 3000)
				}
				if pendingBirth129(r, improved, 5000) || r.Status != test.want {
					t.Fatal("初回拒否後に改善を待って取得")
				}
			})
		}
	}
	// ----------------------------------------
	// 最小のhold 5ptと、最大riskの125pt床/ATR連動を独立に検査する。
	for _, mirror := range []bool{false, true} {
		for _, hold := range []float64{1005, 1004.999} {
			e, born := base, q
			e.HoldMinimum = 5
			e.HoldBoundary = 995
			fill := artificialQuote129(101, 1, 1000, 1010, hold-5)
			if mirror {
				e, born, fill = mirrorBirth129(e, 3000), mirrorQuote129(born, 3000), mirrorQuote129(fill, 3000)
			}
			r := request129(e, born, 5000)
			if pendingBirth129(r, fill, 5000) != (hold == 1005) {
				t.Fatal("hold5pt等号差")
			}
		}
		for _, invalidation := range []float64{885, 884.999} {
			e, born := artificialBirth129(q), q
			e.EntryCap, e.Invalidation = 1010, invalidation
			fill := artificialQuote129(101, 1, 1000, 1010, 1005)
			if mirror {
				e, born, fill = mirrorBirth129(e, 3000), mirrorQuote129(born, 3000), mirrorQuote129(fill, 3000)
			}
			r := request129(e, born, 5000)
			if r.MaximumRisk != 125 || pendingBirth129(r, fill, 5000) != (invalidation == 885) {
				t.Fatal("risk125pt等号差")
			}
		}
	}
}

// TestBirthScanStampPlainGzipAndSource129 は配送stampと遅延原行・Source129・chart金額nilを検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestBirthScanStampPlainGzipAndSource129(t *testing.T) {
	for _, compressed := range []bool{false, true} {
		for _, mirror := range []bool{false, true} {
			rows := []Quote{artificialQuote129(100, 0, 995, 1005, 1000), artificialQuote129(100, 1, 1000, 1010, 1005), artificialQuote129(100.999, 2, 1000, 1010, 1005), artificialQuote129(101, 3, 1005, 1005, 1005), artificialQuote129(102, 4, 1000, 1010, 1005), artificialQuote129(103, 5, 1025, 1035, 1030)}
			e := artificialBirth129(rows[0])
			e.EntryCap = 1010
			if mirror {
				e = mirrorBirth129(e, 3000)
				for i := range rows {
					rows[i] = mirrorQuote129(rows[i], 3000)
				}
			}
			s := fixtureScene129(t, rows, compressed, []Birth129{e})
			r, err := scanBirth129(s)
			if err != nil || !r.Success || len(r.Births) != 1 || len(r.Cases) != 1 || r.Quality != *s.ExpectedQuality || r.Before != r.After || r.SourceEntries != 1 || r.RawPasses != 1 {
				t.Fatal("全行/出生/取得認証差", err)
			}
			if r.Births[0].Status != "filled" || *r.Births[0].Entry != rows[4] || *r.Births[0].Request != rows[0] {
				t.Fatal("後1秒の最初正常BBOを使わない")
			}
			c := r.Cases[0]
			if c.SourceEvent.ID != e.ID || c.SourceEvent.At != e.At || !bytes.Equal(c.SourceEvent.Refs, e.Refs) || !bytes.Equal(c.SourceEvent.Fields, e.Fields) || *c.RequestQuote != rows[0] || c.Original.Birth.Index != 4 || c.Original.Birth.Line != 5 || c.Reverse.Birth.Side != -e.Side {
				t.Fatal("技術出生と取得clock又はSourceメタデータを混同")
			}
			for _, candidate := range []*Candidate129{c.ChartOriginal, c.ChartReverse} {
				for _, outcome := range candidate.Outcomes {
					if outcome.Net0 != nil || outcome.Net5 != nil || outcome.Status != "eof_censored" {
						t.Fatal("参考価格に金額又はEOF未処理")
					}
				}
			}
			wantEncoding := "plain"
			if compressed {
				wantEncoding = "gzip"
			}
			if r.RawEncoding != wantEncoding {
				t.Fatal("magicの圧縮判定差")
			}
		}
	}
}

// TestBirthZeroQualityValidationAndBoundaries129 は出生0場・全行認証・metadata境界・EOFを検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestBirthZeroQualityValidationAndBoundaries129(t *testing.T) {
	rows := []Quote{artificialQuote129(100, 0, 995, 1005, 1000), artificialQuote129(130, 1, 995, 1005, 1000)}
	s := fixtureScene129(t, rows, false, nil)
	r, err := scanBirth129(s)
	if err != nil || !r.Success || len(r.Cases) != 0 || len(r.Births) != 0 || r.SourceEntries != 0 || r.ActualSHA != s.Raw.SHA256 {
		t.Fatal("出生0を原板未検査にした", err)
	}
	for _, mutation := range []func(*Scene129){
		func(x *Scene129) { x.Raw.SHA256 = fmt.Sprintf("%064d", 0) },
		func(x *Scene129) { x.Contract = "Y" },
		func(x *Scene129) { x.ExpectedAccepted++ },
		func(x *Scene129) { quality := *x.ExpectedQuality; quality.BadBBO++; x.ExpectedQuality = &quality },
	} {
		bad := s
		mutation(&bad)
		if _, err := scanBirth129(bad); err == nil {
			t.Fatal("0出生場でSHA/限月/採用数/品質差を許可")
		}
	}
	e := artificialBirth129(rows[0])
	for _, mutation := range []func(*Birth129){
		func(x *Birth129) { x.At.Time += .5 },
		func(x *Birth129) { x.At.Index++ },
		func(x *Birth129) { x.At.Line++ },
		func(x *Birth129) { x.ATR5 = math.NaN() },
		func(x *Birth129) { x.HoldMinimum = 1 },
		func(x *Birth129) { x.HoldBoundary = x.EntryCap + 1 },
		func(x *Birth129) { x.Invalidation = x.EntryCap },
	} {
		bad := s
		changed := e
		mutation(&changed)
		bad.Events = []Birth129{changed}
		if _, err := scanBirth129(bad); err == nil {
			t.Fatal("出生stamp/finite/hold/cap境界差を許可")
		}
	}
	s.Events = []Birth129{e, e}
	if _, err := scanBirth129(s); err == nil {
		t.Fatal("重複出生IDを許可")
	}
	s.Events = []Birth129{e}
	r, err = scanBirth129(s)
	if err != nil || r.Births[0].Status != "unfilled_expired" || len(r.Cases) != 0 {
		t.Fatal("TTL30秒等号で取得", err)
	}
	s = fixtureScene129(t, rows[:1], false, []Birth129{e})
	r, err = scanBirth129(s)
	if err != nil || r.Births[0].Status != "eof_unfilled" || len(r.Cases) != 0 {
		t.Fatal("EOF未取得の分類差", err)
	}
	// ----------------------------------------
	// 出生時Lastが構造外/上限超過なら、後の正常BBOを待たず拒否する。
	for _, test := range []struct {
		boundary, cap, force float64
		status               string
	}{
		{1005, 1050, 5000, "birth_structure_lost"}, {990, 995, 5000, "birth_cap_rejected"}, {1000, 1050, 100, "force_close"},
	} {
		e.HoldBoundary, e.EntryCap = test.boundary, test.cap
		born := request129(e, rows[0], test.force)
		if born.Status != test.status || born.Request != nil {
			t.Fatal("出生時拒否の分類差")
		}
	}
}

// TestRunBirth73Artificial129 は73場CLI・品質必須・新規出力・同時実行を人工で検査します。
//
// 引数: t(*testing.T)。返り値: ありません。自然Raw/出生JSONは読みません。
func TestRunBirth73Artificial129(t *testing.T) {
	input := Input129{Scenes: []Scene129{}}
	for i := 0; i < 73; i++ {
		at := float64(10000 + i*10000)
		rows := []Quote{artificialQuote129(at, 0, 995, 1005, 1000), artificialQuote129(at+1, 1, 1000, 1010, 1005)}
		var events []Birth129
		if i == 0 {
			events = []Birth129{artificialBirth129(rows[0])}
		}
		s := fixtureScene129(t, rows, i%2 == 0, events)
		s.Session = fmt.Sprintf("人工%02d", i)
		input.Scenes = append(input.Scenes, s)
	}
	file := filepath.Join(t.TempDir(), "人工入力.json")
	write := func(in Input129) string {
		encoded, err := json.Marshal(in)
		if err != nil {
			t.Fatal(err)
		}
		if err = os.WriteFile(file, encoded, 0600); err != nil {
			t.Fatal(err)
		}
		hash := sha256.Sum256(encoded)
		return hex.EncodeToString(hash[:])
	}
	output := filepath.Join(t.TempDir(), "人工結果.json")
	hash := write(input)
	if err := RunBirth129(file, hash, output, 8); err != nil {
		t.Fatal("人工73場", err)
	}
	encoded, err := os.ReadFile(output)
	if err != nil {
		t.Fatal(err)
	}
	var result struct {
		Trial   int         `json:"trial"`
		Success bool        `json:"success"`
		Scenes  []Result129 `json:"scenes"`
	}
	if err = json.Unmarshal(encoded, &result); err != nil || result.Trial != 129 || !result.Success || len(result.Scenes) != 73 || len(result.Scenes[0].Cases) != 1 || len(result.Scenes[72].Births) != 0 {
		t.Fatal("人工73場結果shape差", err)
	}
	if err = RunBirth129(file, hash, output, 8); err == nil {
		t.Fatal("既存結果上書きを許可")
	}
	bad := input
	bad.Scenes = append([]Scene129{}, input.Scenes...)
	bad.Scenes[0].ExpectedQuality = nil
	if err = RunBirth129(file, write(bad), filepath.Join(t.TempDir(), "拒否.json"), 1); err == nil {
		t.Fatal("品質固定なしを許可")
	}
}
