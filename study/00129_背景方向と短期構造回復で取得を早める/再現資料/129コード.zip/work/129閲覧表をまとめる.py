"""129の新入口と元出生対照を、元セル同体の3閲覧表へまとめる。"""
from pathlib import Path
import argparse
import hashlib
import json

ROOT=Path(__file__).resolve().parent.parent
OWN=ROOT/'work/129短期回復の評価'


def main() -> None:
    """
    機能: 列名の和集合へ元セルを転記し、政策対象外だけをnullで補う。
    引数: CLI --primary-sha256/--base-sha256(str)。返り値: None。
    """
    parser=argparse.ArgumentParser(description='129主と対照のCSV用三表')
    parser.add_argument('--primary-sha256',required=True);parser.add_argument('--base-sha256',required=True)
    args=parser.parse_args();sources=[];proof=[]
    for name,label,expected in (('新入口','新入口（主）',args.primary_sha256),('元出生','元出生（同区間）',args.base_sha256)):
        path=OWN/f'{name}集計/CSV用の表.json';raw=path.read_bytes()
        assert hashlib.sha256(raw).hexdigest()==expected
        data=json.loads(raw);assert data['成功'] and data['試行']==129
        sources.append((label,data['tables']));proof.append({'構成':name,'正本SHA256':expected})
    tables=[]
    for i in range(3):
        name=sources[0][1][i]['name'];headers=[]
        for _,source in sources:
            assert source[i]['name']==name
            headers.extend(h for h in source[i]['headers'] if h not in headers)
        assert len(set(headers))==len(headers)
        rows=[]
        for label,source in sources:
            t=source[i];indices=[headers.index(h) for h in t['headers']]
            for row in t['rows']:
                mapped=[None]*len(headers)
                for index,value in zip(indices,row): mapped[index]=value
                assert [mapped[k] for k in indices]==row
                rows.append([label]+mapped)
        tables.append({'name':name,'headers':['入口構成']+headers,'rows':rows})
    assert len(tables[0]['rows'])==260 and len(tables[2]['rows'])==146
    value={'試行':129,'成功':True,'元表':proof,'元セル変更':False,'政策対象外の追加列':'null','tables':tables}
    raw=(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode('utf-8')
    with (OWN/'CSV用の閲覧表.json').open('xb') as stream: stream.write(raw)
    print(json.dumps({'成功':True,'SHA256':hashlib.sha256(raw).hexdigest(),'行列':[(t['name'],len(t['rows']),len(t['headers'])) for t in tables]},ensure_ascii=False))


if __name__=='__main__':
    main()
