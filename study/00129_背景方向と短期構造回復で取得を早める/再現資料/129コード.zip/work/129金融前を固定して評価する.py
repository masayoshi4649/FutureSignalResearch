"""129の入力/転記を金融前に追加固定し、同じ限定器で主と対照を評価する。"""
from pathlib import Path
import argparse
import importlib.util
import json
import subprocess
import sys

ROOT=Path(__file__).resolve().parent.parent
spec=importlib.util.spec_from_file_location('出生前固定129',ROOT/'work/129出生前を固定する.py')
stage=importlib.util.module_from_spec(spec);spec.loader.exec_module(stage)
OWN=stage.OWN
AGG={'新入口':ROOT/'work/129区間限定の短期回復集計','元出生':ROOT/'work/129元出生の区間対照集計'}


def main() -> None:
    """
    機能: 入力同体を固定し、主120比較/対照140比較を別々に保存する。
    引数: CLI --mode(str、固定/再生/集計)、--model(str、新入口/元出生)。返り値: None。
    """
    parser=argparse.ArgumentParser(description='129の金融前固定と同区間比較')
    parser.add_argument('--mode',choices=('固定','再生','集計'),required=True)
    parser.add_argument('--model',choices=tuple(AGG));args=parser.parse_args()
    f0=json.loads((OWN/'F0.json').read_bytes());stage.verify(f0)
    if args.mode=='固定':
        born=json.loads((OWN/'出生完了.json').read_bytes())
        assert born['出生SHA256']==stage.sha(OWN/'出生.json')
        files=[Path(__file__).resolve(),ROOT/'work/129出生を入力へ渡す.py',OWN/'出生.json',OWN/'入力.json',OWN/'出生完了.json']
        value={'成功':True,'試行':129,'段階':'金融前F1','F0_SHA256':stage.sha(OWN/'F0.json'),
               '主入力':str(OWN/'入力.json'),'対照入力':str(stage.BASE),'ファイル':{str(p):stage.sha(p) for p in files}}
        stage.save(OWN/'F1.json',value);print(json.dumps({'F1':stage.sha(OWN/'F1.json')},ensure_ascii=False));return
    f1=json.loads((OWN/'F1.json').read_bytes());stage.verify(f1)
    assert f1['F0_SHA256']==stage.sha(OWN/'F0.json') and args.model
    model=args.model;input_path=OWN/'入力.json' if model=='新入口' else stage.BASE
    output=OWN/f'{model}結果.json'
    if args.mode=='再生':
        assert not output.exists()
        command=[str(stage.ENGINE/'独立出生の再生.exe'),'--input',str(input_path),'--sha256',stage.sha(input_path),'--output',str(output),'--workers','4']
        subprocess.run(command,cwd=stage.ENGINE,check=True);stage.verify(f0);stage.verify(f1)
        data=json.loads(output.read_bytes());inputs=json.loads(input_path.read_bytes())['scenes']
        assert data['trial']==129 and data['success'] and len(data['scenes'])==73
        for scene,source in zip(data['scenes'],inputs):
            assert scene['success'] and scene['session']==source['session']
            end=source['end']-300
            assert scene['execution_end']==end and scene['source_force_close']==source['force_close']
            assert scene['effective_force_close']==min(source['force_close'],end-120)
            for case in scene['cases']:
                for name in ('original','reverse','chart_original','chart_reverse'):
                    candidate=case[name];assert candidate['entry']['time']<scene['effective_force_close']
                    for observation in candidate['outcomes']:
                        if observation.get('endpoint'): assert observation['endpoint']['time']<end
                        for touch in observation['touches']:
                            if touch.get('quote'): assert touch['quote']['time']<end
        stage.save(OWN/f'{model}再生完了.json',{'成功':True,'F1_SHA256':stage.sha(OWN/'F1.json'),'結果SHA256':stage.sha(output),'phase境界全票確認':True,'コード入力前後同体':True,'コマンド':command})
        print(json.dumps({'再生完了':model,'SHA256':stage.sha(output)},ensure_ascii=False));return
    done=json.loads((OWN/f'{model}再生完了.json').read_bytes());assert done['結果SHA256']==stage.sha(output)
    command=[sys.executable,'-X','utf8',str(AGG[model]/'集計する.py'),'--result',str(output),'--sha256',stage.sha(output),
             '--input-sha256',stage.sha(input_path),'--input',str(input_path),'--output-dir',str(OWN/f'{model}集計')]
    subprocess.run(command,cwd=ROOT,check=True);stage.verify(f0);stage.verify(f1)
    stage.save(OWN/f'{model}集計完了.json',{'成功':True,'F1_SHA256':stage.sha(OWN/'F1.json'),'集計SHA256':stage.sha(OWN/f'{model}集計/集計.json'),'コード入力前後同体':True})


if __name__=='__main__':
    main()
