"""自然データを読まず人工検査と小部分再用の同体・コード指紋を記録する。"""
from pathlib import Path
import hashlib
import importlib.util
import json
import re
import subprocess

OWN = Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 小型コード/成果だけの保存SHAを求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def command(args: list[str], expected: int = 0) -> dict:
    """
    機能: 人工検査/ビルドの結果を検査する。
    引数: args(list[str])/expected(int)。返り値: dict。
    """
    run = subprocess.run(args, cwd=OWN, encoding="utf-8", capture_output=True)
    assert run.returncode == expected, (args, run.returncode, run.stdout, run.stderr)
    return {"引数": args, "終了値": run.returncode, "標準出力": run.stdout, "標準エラー": run.stderr}


# ----------------------------------------
def main() -> None:
    """
    機能: 自然Raw/入力/金融を開かず同体と人工テストの正本を作る。
    引数: なし。返り値: None。
    """
    spec = importlib.util.spec_from_file_location("reuse", OWN / "小部分を再用する.py")
    reuse = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(reuse)
    old = OWN.parent / "120入口の1分構造/detector.go"
    previous = json.loads((OWN / "小部分再用の確認.json").read_text(encoding="utf-8"))
    assert sha(old) == previous["120元SHA256"]
    original = old.read_text(encoding="utf-8")
    target = (OWN / "minute_reuse.go").read_text(encoding="utf-8")
    for name, expected in previous["関数本文SHA256"].items():
        body = reuse.function(original, name)
        assert body == reuse.function(target, name)
        assert hashlib.sha256(body.encode()).hexdigest() == expected
    old_decoder = OWN.parent / "128Raw価格時計の全場足生成/decoder.go"
    assert sha(old_decoder) == previous["128decoder元SHA256"]
    assert old_decoder.read_text(encoding="utf-8").replace("package rawpricebars", "package shortbirth129", 1) == (OWN / "decoder.go").read_text(encoding="utf-8")
    checks = [command(["go", "version"]), command(["go", "test", "-count=1", "-v", "./..."]), command(["go", "vet", "./..."]), command(["go", "build", "-o", "短期回復の出生.exe", "./cmd/run"]), command([str(OWN / "短期回復の出生.exe")], 2)]
    test_names = re.findall(r"^=== RUN   ([^/\r\n]+)$", checks[1]["標準出力"], re.M)
    assert len(test_names) == 15, test_names
    paths = sorted([*OWN.glob("*.go"), *OWN.glob("*.py"), OWN / "go.mod", OWN / "README.md", OWN / "仕様.md", OWN / "cmd/run/main.go"])
    result = {"成功": True, "試行": 129, "自然129走査": False, "自然129出生": False, "金融ラベル読取生成": False, "主人工検査数": len(test_names), "主人工検査": test_names, "120三関数同体": True, "128decoder差": "package宣言のみ", "背景SHA": "e382858a62865b321449279d9653f5b1c644c97f6c4254cbae8dd9d3ea065e62", "コードと文書": [{"path": p.relative_to(OWN).as_posix(), "bytes": p.stat().st_size, "sha256": sha(p)} for p in paths], "実行体SHA": sha(OWN / "短期回復の出生.exe"), "検査": checks}
    (OWN / "準備の確認.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("129の人工15検査・vet/build・CLI拒否・120/128小部分同体を確認。自然129未実行。")


if __name__ == "__main__":
    main()
