package shortbirth129

import rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"

const BackgroundSHA = "e382858a62865b321449279d9653f5b1c644c97f6c4254cbae8dd9d3ea065e62"

type FileRef struct {
	Path   string `json:"path"`
	SHA256 string `json:"sha256"`
	Bytes  int64  `json:"bytes"`
}
type Counts struct {
	Lines           int64 `json:"lines"`
	ClockMissing    int64 `json:"clock_missing"`
	ClockInvalid    int64 `json:"clock_invalid"`
	Outside         int64 `json:"outside_session"`
	Backward        int64 `json:"backward_clock"`
	LastNonPositive int64 `json:"last_non_positive"`
	LastNonFinite   int64 `json:"last_non_finite"`
	BadBBO          int64 `json:"bad_bbo"`
	Accepted        int64 `json:"source_parser_accepted"`
	CutoffExcluded  int64 `json:"cutoff_excluded"`
	Delivered       int64 `json:"source_delivered"`
}
type Scene struct {
	Session          string              `json:"session"`
	Contract         string              `json:"contract"`
	Start            float64             `json:"start"`
	End              float64             `json:"end"`
	ForceClose       float64             `json:"force_close"`
	Cutoff           float64             `json:"cutoff"`
	Raw              FileRef             `json:"raw"`
	ExpectedAccepted int64               `json:"expected_accepted"`
	ExpectedQuality  *Counts             `json:"expected_quality"`
	Pubs             []rules.Publication `json:"publications"`
}
type Quote struct {
	Clock      string  `json:"clock"`
	Time       float64 `json:"time"`
	Index      int64   `json:"index"`
	SourceLine int64   `json:"source_line"`
	Last       float64 `json:"last"`
	Bid        float64 `json:"bid"`
	Ask        float64 `json:"ask"`
	QuoteOK    bool    `json:"quote_ok"`
}
type Observation struct {
	Quote      Quote
	Volume     *float64
	VolumeTime *float64
}
type Bar struct {
	Start       float64     `json:"start"`
	End         float64     `json:"end"`
	OHLC        rules.OHLC  `json:"ohlc"`
	TR          rules.Value `json:"tr"`
	Rows        int         `json:"rows"`
	First       rules.Quote `json:"first"`
	Last        rules.Quote `json:"last"`
	PriceKnown  bool        `json:"price_known"`
	VolumeKnown bool        `json:"volume_known"`
	Volume      float64     `json:"volume"`
}
type Range struct {
	Known bool    `json:"known"`
	Start float64 `json:"start"`
	End   float64 `json:"end"`
	Low   float64 `json:"low"`
	High  float64 `json:"high"`
	Count int     `json:"count"`
}
type Stamp struct {
	Time  float64 `json:"time"`
	Index int64   `json:"index"`
	Line  int64   `json:"source_line"`
}
type Event struct {
	Session      string         `json:"session"`
	ID           string         `json:"id"`
	Mode         string         `json:"mode"`
	Side         int            `json:"side"`
	At           Stamp          `json:"at"`
	EntryCap     float64        `json:"entry_cap"`
	Invalidation float64        `json:"invalidation"`
	ATR5         float64        `json:"atr5"`
	HoldBoundary float64        `json:"hold_boundary"`
	HoldMinimum  float64        `json:"hold_minimum"`
	MinimumRisk  float64        `json:"minimum_risk"`
	Refs         []rules.Ref    `json:"refs"`
	Fields       map[string]any `json:"fields"`
}
type Contact struct {
	At        rules.Quote
	Low       float64
	High      float64
	RangeLow  float64
	RangeHigh float64
	Cohort    string
	Expires   float64
	Refs      []rules.Ref
}
type Setup struct {
	Mode     string
	Side     int
	Cohort   string
	At       rules.Quote
	Bar      Bar
	ATR      float64
	K        float64
	I        float64
	Cap      float64
	Expires  float64
	Ready    bool
	Cross    *rules.Quote
	HoldRows int
	Refs     []rules.Ref
	Fields   map[string]any
}
type Detector struct {
	Scene       Scene
	Current     *Bar
	History     []Bar
	Five        []rules.Publication
	Contacts    map[string]*Contact
	Setups      map[string]*Setup
	LastSignals map[string]float64
	Last        *Observation
	Volume      *float64
	VolumeTime  *float64
	Stats       map[string]int
	Events      []Event
}
