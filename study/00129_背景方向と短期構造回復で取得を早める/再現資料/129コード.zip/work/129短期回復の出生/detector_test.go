package shortbirth129

import (
	"fmt"
	"math"
	"testing"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// val は人工検査用の既知値を作ります。
//
// 引数: x(float64)。返り値: rules.Valueです。
func val(x float64) rules.Value { return rules.Value{Known: true, Value: x} }

// testScene は自然入力を読まず人工の場を作ります。
//
// 引数: ありません。返り値: Sceneです。
func testScene() Scene {
	return Scene{Session: "人工_Day", Contract: "NK", Start: 36000, End: 72000, ForceClose: 71880}
}

// snapshot は背景の各役割が既知の人工公表を作ります。
//
// 引数: weak(bool)。返り値: rules.Snapshotです。
func snapshot(weak bool) rules.Snapshot {
	s := rules.Snapshot{SessionID: "人工_Day", Contract: "NK", Frames: map[int]rules.Publication{}, RVOL5: val(1)}
	for _, width := range []int{300, 900, 1800} {
		t := rules.Technical{EMA8: val(1020), EMA21: val(1000), Gap: val(20), EMA8Delta: val(2), EMA21Delta: val(1), ATR: val(100), PreviousATR: val(100), TR: val(80), RSI: val(55), PreviousRSI: val(54), Histogram: val(3), PreviousHistogram: val(2)}
		d := rules.DMI{PlusDI: val(30), MinusDI: val(10), ADX: val(25), PreviousADX: val(24)}
		if weak {
			d.ADX, d.PreviousADX = val(18), val(19)
		}
		id := fmt.Sprintf("人工/%d", width)
		stamp := rules.Stamp{Time: 35999, Index: 0, Line: 1}
		s.Frames[width] = rules.Publication{Stamp: stamp, Frame: rules.Frame{Frame: rules.ChartFrame{ID: id, SessionID: s.SessionID, Contract: s.Contract, Width: width, Start: 35999 - float64(width), End: 35999, PriceKnown: true, Technical: t}, DMI: d}}
		s.Refs = append(s.Refs, rules.Ref{ID: id, Width: width, End: 35999, Delivered: stamp})
	}
	return s
}

// minuteBar は完全に確定した人工1分を作ります。
//
// 引数: start/o/h/l/c/volume(float64)、index(int)。返り値: Barです。
func minuteBar(start, o, h, l, c, volume float64, index int) Bar {
	return Bar{Start: start, End: start + 60, OHLC: rules.OHLC{Open: o, High: h, Low: l, Close: c}, Rows: 2, First: rules.Quote{Time: start, Index: index, Line: index + 1, Last: o}, Last: rules.Quote{Time: start + 59, Index: index + 1, Line: index + 2, Last: c}, PriceKnown: true, VolumeKnown: true, Volume: volume}
}

// quote は物理順と価格時計を持つ人工Rawを作ります。
//
// 引数: at/price(float64)、index(int64)。返り値: Quoteです。
func quote(at, price float64, index int64) Quote {
	return Quote{Time: at, Last: price, Index: index, SourceLine: index + 1, Bid: price - 5, Ask: price + 5, QuoteOK: true}
}

// mirrorSnapshot は価格/方向値を符号反転して売買鏡像を作ります。
//
// 引数: s(rules.Snapshot)。返り値: rules.Snapshotです。
func mirrorSnapshot(s rules.Snapshot) rules.Snapshot {
	out := s
	out.Frames = map[int]rules.Publication{}
	for width, p := range s.Frames {
		t := &p.Frame.Frame.Technical
		for _, v := range []*rules.Value{&t.Gap, &t.EMA8Delta, &t.EMA21Delta, &t.Histogram, &t.PreviousHistogram} {
			v.Value = -v.Value
		}
		t.EMA8.Value, t.EMA21.Value = 3000-t.EMA8.Value, 3000-t.EMA21.Value
		t.RSI.Value, t.PreviousRSI.Value = 100-t.RSI.Value, 100-t.PreviousRSI.Value
		p.Frame.DMI.PlusDI, p.Frame.DMI.MinusDI = p.Frame.DMI.MinusDI, p.Frame.DMI.PlusDI
		out.Frames[width] = p
	}
	return out
}

// Test背景の未知と既知中立 は30分の未知を支持に変えないことを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test背景の未知と既知中立(t *testing.T) {
	for _, tc := range []struct {
		name       string
		gap, slope rules.Value
		cohort     string
		pass       bool
	}{{"全既知支持", val(20), val(1), "B30", true}, {"全未知", rules.Value{}, rules.Value{}, "B15", true}, {"一部正", val(20), rules.Value{}, "B15", true}, {"一部中立", val(0), rules.Value{}, "", false}, {"一部逆", rules.Value{}, val(-1), "", false}, {"全既知中立", val(0), val(1), "B30", false}} {
		t.Run(tc.name, func(t *testing.T) {
			s := snapshot(false)
			p := s.Frames[1800]
			p.Frame.Frame.Technical.Gap, p.Frame.Frame.Technical.EMA21Delta = tc.gap, tc.slope
			s.Frames[1800] = p
			c, ok := directional(s, 1)
			if c != tc.cohort || ok != tc.pass {
				t.Fatalf("%s %v", c, ok)
			}
			c2, ok2 := directional(mirrorSnapshot(s), -1)
			if c2 != c || ok2 != ok {
				t.Fatal("売買鏡像差")
			}
		})
	}
}

// Test量値幅と弱方向 はスパイク/量未知/強い逆背景を拒否します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test量値幅と弱方向(t *testing.T) {
	s := snapshot(true)
	if c, ok := context(s, "C2", 1, false); !ok || c != "B30" {
		t.Fatal("弱方向が不成立")
	}
	p := s.Frames[1800]
	p.Frame.DMI.ADX = rules.Value{}
	s.Frames[1800] = p
	if c, ok := context(s, "C2", 1, false); !ok || c != "B15" {
		t.Fatal("未知30分の分離失敗")
	}
	p.Frame.DMI.ADX, p.Frame.DMI.PreviousADX = val(30), val(29)
	s.Frames[1800] = p
	if _, ok := context(s, "C2", 1, false); ok {
		t.Fatal("既知強30分を通過")
	}
	s = snapshot(false)
	s.RVOL5 = rules.Value{}
	if _, ok := common(s); ok {
		t.Fatal("量未知を通過")
	}
	s = snapshot(false)
	p = s.Frames[300]
	p.Frame.Frame.Technical.RSI = val(75)
	s.Frames[300] = p
	if _, ok := common(s); ok {
		t.Fatal("RSIスパイクを通過")
	}
}

// Test実Raw維持と鏡像 は足終値と現在価格を混同せず1秒維持を要求します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test実Raw維持と鏡像(t *testing.T) {
	for _, side := range []int{1, -1} {
		s := snapshot(false)
		price := func(x float64) float64 {
			if side < 0 {
				return 3000 - x
			}
			return x
		}
		if side < 0 {
			s = mirrorSnapshot(s)
		}
		d := NewDetector(testScene())
		d.Setups[key("C1", side)] = &Setup{Mode: "C1", Side: side, Cohort: "B30", K: price(1050), I: price(1000), Cap: price(1070), ATR: 100, Ready: true, Fields: map[string]any{}}
		d.trigger(s, quote(36000, price(1049), 10))
		d.trigger(s, quote(36001, price(1052), 11))
		d.trigger(s, quote(36001.5, price(1053), 12))
		if len(d.Events) != 0 {
			t.Fatal("1秒未満で出生")
		}
		d.trigger(s, quote(36002, price(1054), 13))
		if len(d.Events) != 1 {
			t.Fatal("実価格維持で未出生")
		}
		e := d.Events[0]
		if e.Side != side || e.Fields["actual_raw_last"] != price(1054) || e.HoldMinimum != 0 || e.MinimumRisk != 10 || e.Fields["continuous_end"] != float64(71700) || e.Fields["entry_cutoff"] != float64(71580) {
			t.Fatalf("schema/phase差:%+v", e)
		}
		if !d.cooling(key("C1", side), 36003) {
			t.Fatal("cooldownなし")
		}
	}
}

// Test維持の割れと時間超過 は飛び乗り位置や断続観測で維持時計をresetします。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test維持の割れと時間超過(t *testing.T) {
	d := NewDetector(testScene())
	s := snapshot(false)
	v := &Setup{Mode: "C1", Side: 1, K: 1050, I: 1000, Cap: 1070, ATR: 100, Ready: true, Fields: map[string]any{}}
	d.Setups[key("C1", 1)] = v
	for i, p := range []float64{1052, 1049, 1052, 1071} {
		d.trigger(s, quote(36000+float64(i), p, int64(i+10)))
	}
	if v.Cross != nil {
		t.Fatal("K割れ/cap超えの維持が残存")
	}
	d.trigger(s, quote(36010, 1052, 20))
	d.trigger(s, quote(36021, 1052, 21))
	if len(d.Events) != 0 || v.Cross.Time != 36021 {
		t.Fatal("10秒超過で出生")
	}
	d.trigger(s, quote(36022, 1052, 22))
	if len(d.Events) != 1 {
		t.Fatal("再維持失敗")
	}
}

// Test接触拒否足の位置固定 は過去の領域へ遠い高値の拒否を結び付けません。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test接触拒否足の位置固定(t *testing.T) {
	s := snapshot(false)
	d := NewDetector(testScene())
	d.History = []Bar{minuteBar(36000, 1000, 1010, 990, 1005, 10, 10)}
	d.touch(s, quote(36065, 1010, 20))
	if d.Contacts[key("C1", 1)] == nil {
		t.Fatal("接触なし")
	}
	b := minuteBar(36060, 1100, 1120, 1090, 1115, 20, 19)
	d.onMinute(b, s, quote(36120, 1115, 30))
	if d.Setups[key("C1", 1)] != nil {
		t.Fatal("離れた拒否足を採用")
	}
	b = minuteBar(36060, 1000, 1030, 990, 1020, 20, 19)
	d.onMinute(b, s, quote(36120, 1020, 30))
	v := d.Setups[key("C1", 1)]
	if v == nil || v.K != 1035 || v.I != 985 || v.Cap != 1055 || v.Fields["setup_atr_ref"] != "人工/300" {
		t.Fatalf("固定setup差:%+v", v)
	}
	// 後公表のATR拡大は保存済みcapを変えません。
	p := s.Frames[300]
	p.Frame.Frame.Technical.ATR = val(500)
	s.Frames[300] = p
	d.trigger(s, quote(36121, 1060, 31))
	if v.Cap != 1055 || v.Cross != nil {
		t.Fatal("後ATRでcap緩和")
	}
}

// Testレンジの実取得余地 は狭いレンジの125pt目標や後半取得を除外します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Testレンジの実取得余地(t *testing.T) {
	for _, width := range []float64{80, 400} {
		d := NewDetector(testScene())
		s := snapshot(true)
		d.History = []Bar{minuteBar(36000, 1000, 1010, 990, 1005, 10, 10)}
		d.Contacts[key("C2", 1)] = &Contact{At: rules.Quote{Time: 36065, Index: 20}, Cohort: "B30", RangeLow: 1000, RangeHigh: 1000 + width, Expires: 36965}
		d.onMinute(minuteBar(36060, 1010, 1030, 1000, 1020, 20, 19), s, quote(36120, 1020, 30))
		v := d.Setups[key("C2", 1)]
		if width == 80 && v != nil {
			t.Fatal("80pt域から125pt余地を仮定")
		}
		if width == 400 && (v == nil || v.Cap != 1055 || v.Cap > 1100 || 1400-v.Cap < 145) {
			t.Fatalf("広い域の幾何学差:%+v", v)
		}
	}
}

// Test弱い反対足の次足確認 は失速だけで逆方向へ入らず次足回復を要求します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test弱い反対足の次足確認(t *testing.T) {
	d := NewDetector(testScene())
	s := snapshot(false)
	d.History = []Bar{minuteBar(36000, 990, 1005, 985, 1000, 100, 10), minuteBar(36060, 1000, 1035, 995, 1030, 100, 20), minuteBar(36120, 1030, 1065, 1025, 1060, 100, 30)}
	j := minuteBar(36180, 1060, 1065, 1035, 1040, 40, 40)
	d.onMinute(j, s, quote(36240, 1040, 50))
	v := d.Setups[key("C3", 1)]
	if v == nil || v.Ready || v.K != 1070 || v.I != 1030 {
		t.Fatalf("j固定差:%+v", v)
	}
	d.History[0].OHLC.Close = 9999
	if v.Fields["impulse_minutes"].([]Bar)[0].OHLC.Close != 1000 {
		t.Fatal("過去構造が後のslice更新で改変")
	}
	k := minuteBar(36240, 1045, 1075, 1040, 1072, 50, 50)
	d.onMinute(k, s, quote(36300, 1072, 60))
	if !v.Ready {
		t.Fatal("次足回復未認識")
	}
	d.trigger(s, quote(36300, 1069, 60))
	if v.Cross != nil {
		t.Fatal("1分Closeを現在Lastに流用")
	}
	d.trigger(s, quote(36301, 1072, 61))
	d.trigger(s, quote(36302, 1072, 62))
	if len(d.Events) != 1 || d.Events[0].Mode != "C3" {
		t.Fatal("C3回復維持未出生")
	}
}

// observation は累積数量を持つ人工Rawを作ります。
//
// 引数: at/price/volume(float64)、index(int64)。返り値: Observationです。
func observation(at, price, volume float64, index int64) Observation {
	return Observation{Quote: quote(at, price, index), Volume: &volume, VolumeTime: &at}
}

// Test一分品質と数量proxy は初回未知と次足差分、欠分・閉鎖遅れを区別します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test一分品質と数量proxy(t *testing.T) {
	d := NewDetector(testScene())
	s := snapshot(false)
	for i, at := range []float64{36000, 36030, 36060, 36090, 36120} {
		if _, e := d.Observe(observation(at, 1000+float64(i), float64(i*10), int64(i)), s); e != nil {
			t.Fatal(e)
		}
	}
	if len(d.History) != 2 || d.History[0].VolumeKnown || !d.History[1].VolumeKnown || d.History[1].Volume != 20 || !d.History[1].TR.Known {
		t.Fatalf("1分品質:%+v", d.History)
	}
	if _, e := d.Observe(observation(36181, 1000, 60, 5), s); e != nil {
		t.Fatal(e)
	}
	if len(d.History) != 0 || d.Stats["価格時計gap60超"] != 1 {
		t.Fatal("gapで短期構造が残存")
	}
	d = NewDetector(testScene())
	for i, at := range []float64{36059, 36091} {
		if _, e := d.Observe(observation(at, 1000, float64(i), int64(i)), s); e != nil {
			t.Fatal(e)
		}
	}
	if len(d.History) != 0 || d.Stats["閉鎖1分未知"] != 1 {
		t.Fatal("31秒超遅れで1分が既知")
	}
}

// Test重複と数量不正 は同一Raw改変や先行時計を許可しません。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test重複と数量不正(t *testing.T) {
	d := NewDetector(testScene())
	s := snapshot(false)
	o := observation(36000, 1000, 10, 0)
	if _, e := d.Observe(o, s); e != nil {
		t.Fatal(e)
	}
	if _, e := d.Observe(o, s); e != nil {
		t.Fatal(e)
	}
	*d.Last.Volume = 11
	if _, e := d.Observe(o, s); e == nil {
		t.Fatal("同原行数量改変を通過")
	}
	d = NewDetector(testScene())
	o = observation(36000, 1000, 10, 0)
	future := 36001.0
	o.VolumeTime = &future
	if _, e := d.Observe(o, s); e != nil || d.Current.VolumeKnown {
		t.Fatal("先行数量時計が既知")
	}
	d.RejectClock("人工")
	if d.Current.PriceKnown || len(d.History) != 0 {
		t.Fatal("破棄時計で短期既知")
	}
	if finite(math.NaN()) {
		t.Fatal("非有限値")
	}
}

// mirrorBar は人工確定足を同じ時計と量のまま売買鏡像へ写します。
//
// 引数: b(Bar)。返り値: Barです。
func mirrorBar(b Bar) Bar {
	o := b.OHLC
	b.OHLC = rules.OHLC{Open: 3000 - o.Open, High: 3000 - o.Low, Low: 3000 - o.High, Close: 3000 - o.Close}
	b.First.Last = 3000 - b.First.Last
	b.Last.Last = 3000 - b.Last.Last
	return b
}

// Test反転領域と弱戻りの売買鏡像 はC2/C3の構造とcapも反転させます。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test反転領域と弱戻りの売買鏡像(t *testing.T) {
	for _, side := range []int{1, -1} {
		price := func(x float64) float64 {
			if side < 0 {
				return 3000 - x
			}
			return x
		}
		bar := func(b Bar) Bar {
			if side < 0 {
				return mirrorBar(b)
			}
			return b
		}
		s := snapshot(true)
		if side < 0 {
			s = mirrorSnapshot(s)
		}
		d := NewDetector(testScene())
		d.History = []Bar{bar(minuteBar(36000, 1000, 1010, 990, 1005, 10, 10))}
		lo, hi := 1000.0, 1400.0
		if side < 0 {
			lo, hi = 1600, 2000
		}
		d.Contacts[key("C2", side)] = &Contact{At: rules.Quote{Time: 36065, Index: 20}, Cohort: "B30", RangeLow: lo, RangeHigh: hi, Expires: 36965}
		d.onMinute(bar(minuteBar(36060, 1010, 1030, 1000, 1020, 20, 19)), s, quote(36120, price(1020), 30))
		v := d.Setups[key("C2", side)]
		if v == nil || v.K != price(1035) || v.I != price(995) || v.Cap != price(1055) {
			t.Fatalf("C2鏡像差:%+v", v)
		}
		d.trigger(s, quote(36121, price(1040), 31))
		d.trigger(s, quote(36122, price(1040), 32))
		if len(d.Events) != 1 {
			t.Fatal("C2鏡像で未出生")
		}
		// ----------------------------------------
		s = snapshot(false)
		if side < 0 {
			s = mirrorSnapshot(s)
		}
		d = NewDetector(testScene())
		d.History = []Bar{bar(minuteBar(36000, 990, 1005, 985, 1000, 100, 10)), bar(minuteBar(36060, 1000, 1035, 995, 1030, 100, 20)), bar(minuteBar(36120, 1030, 1065, 1025, 1060, 100, 30))}
		d.onMinute(bar(minuteBar(36180, 1060, 1065, 1035, 1040, 40, 40)), s, quote(36240, price(1040), 50))
		v = d.Setups[key("C3", side)]
		if v == nil || v.Ready {
			t.Fatal("C3鏡像jなし")
		}
		d.onMinute(bar(minuteBar(36240, 1045, 1075, 1040, 1072, 50, 50)), s, quote(36300, price(1072), 60))
		d.trigger(s, quote(36301, price(1072), 61))
		d.trigger(s, quote(36302, price(1072), 62))
		if len(d.Events) != 1 || d.Events[0].Side != side || d.Events[0].Invalidation != price(1030) {
			t.Fatal("C3鏡像出生差")
		}
	}
}

// Test無効化と期限 は失効した古いsetupを新しい成功に数えません。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test無効化と期限(t *testing.T) {
	for _, tc := range []struct{ at, price float64 }{{36000, 1000}, {36120, 1050}} {
		d := NewDetector(testScene())
		k := key("C1", 1)
		d.Setups[k] = &Setup{Side: 1, I: 1000, Expires: 36120}
		d.Contacts[k] = &Contact{Expires: 37000}
		d.expire(quote(tc.at, tc.price, 10))
		if d.Setups[k] != nil || d.Contacts[k] != nil {
			t.Fatal("無効化/期限後に残存")
		}
	}
}
