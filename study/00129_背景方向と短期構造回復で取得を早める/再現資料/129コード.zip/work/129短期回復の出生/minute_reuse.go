package shortbirth129

import (
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"math"
)

// makeBar は120同体の価格足初期化です。
//
// 引数: q(rules.Quote)。返り値: *Barです。
func makeBar(q rules.Quote) *Bar {
	start := math.Floor(q.Time/60) * 60
	return &Bar{Start: start, End: start + 60, OHLC: rules.OHLC{Open: q.Last, High: q.Last, Low: q.Last, Close: q.Last}, Rows: 1, First: q, Last: q}
}

// updateBar は120同体の価格OHLC更新です。
//
// 引数: b(*Bar)、q(rules.Quote)。返り値: ありません。
func updateBar(b *Bar, q rules.Quote) {
	b.OHLC.High = math.Max(b.OHLC.High, q.Last)
	b.OHLC.Low = math.Min(b.OHLC.Low, q.Last)
	b.OHLC.Close = q.Last
	b.Rows++
	b.Last = q
}

// priorRange は120同体の連続足の範囲検査です。
//
// 引数: history([]Bar)、n(int)、end(float64)。返り値: Rangeです。
func priorRange(history []Bar, n int, end float64) Range {
	r := Range{Count: n}
	if len(history) < n || n < 1 {
		return r
	}
	list := history[len(history)-n:]
	r.Start = list[0].Start
	r.End = end
	r.Low = math.Inf(1)
	r.High = math.Inf(-1)
	for i, b := range list {
		if b.End != b.Start+60 || (i > 0 && b.Start != list[i-1].End) {
			return Range{Count: n}
		}
		r.Low = math.Min(r.Low, b.OHLC.Low)
		r.High = math.Max(r.High, b.OHLC.High)
	}
	if list[n-1].End != end {
		return Range{Count: n}
	}
	r.Known = true
	return r
}
