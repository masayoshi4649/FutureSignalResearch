package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"os"
	birth "shortbirth129"
)

// main は明示実行と固定背景が揃った場合だけ自然Raw出生を生成します。
//
// 引数: background/sha256/output(string)、execute-all(bool)。返り値: ありません。
func main() {
	input := flag.String("background", "", "固定gap300公表gzip")
	sha := flag.String("sha256", "", "固定背景SHA")
	output := flag.String("output", "", "未作成出生JSON")
	execute := flag.Bool("execute-all", false, "全73場の出生だけを明示生成")
	flag.Parse()
	if !*execute || *input == "" || *output == "" {
		fmt.Fprintln(os.Stderr, "自然生成は版固定後のみ。--execute-all/--background/--sha256/--outputを明示してください。")
		os.Exit(2)
	}
	if _, e := os.Stat(*output); e == nil || !os.IsNotExist(e) {
		panic("出力先は未作成が必要")
	}
	scenes, e := birth.Load(*input, *sha)
	if e != nil {
		panic(e)
	}
	result, e := birth.Generate(scenes, true)
	if e != nil {
		panic(e)
	}
	body, e := json.MarshalIndent(result, "", "  ")
	if e != nil {
		panic(e)
	}
	file, e := os.OpenFile(*output, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if e != nil {
		panic(e)
	}
	if _, e = file.Write(append(body, '\n')); e != nil {
		_ = file.Close()
		panic(e)
	}
	if e = file.Close(); e != nil {
		panic(e)
	}
	fmt.Printf("全場=%d 出生有場=%d 出生=%d 金融ラベル=false\n", len(result.Scenes), result.BirthSessions, len(result.Events))
}
