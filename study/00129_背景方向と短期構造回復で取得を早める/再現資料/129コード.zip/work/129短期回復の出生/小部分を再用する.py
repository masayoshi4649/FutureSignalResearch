"""120の小さい価格形成関数と128decoderを、旧ソース不変更で再用する。"""
from pathlib import Path
import hashlib
import json

OWN=Path(__file__).resolve().parent


def function(text: str, name: str) -> str:
    """
    機能: Go関数を括弧深さで抜き出す。
    引数: text/name(str)。返り値: strは元の関数本文。
    """
    start=text.index('func '+name+'(');opening=text.index('{',start);depth=1;end=opening+1
    while depth:
        if text[end]=='{':depth+=1
        elif text[end]=='}':depth-=1
        end+=1
    return text[start:end]


# ----------------------------------------
def main() -> None:
    """
    機能: 小部分の同体ソースだけを保存する。自然データ未読。
    引数: なし。返り値: None。
    """
    source=OWN.parent/'120入口の1分構造/detector.go';text=source.read_text(encoding='utf-8');names=('makeBar','updateBar','priorRange')
    parts=[function(text,n) for n in names]
    header='package shortbirth129\n\nimport ("math"; rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118")\n\n'
    comments=['// makeBar は120同体の価格足初期化です。\n//\n// 引数: q(rules.Quote)。返り値: *Barです。\n','// updateBar は120同体の価格OHLC更新です。\n//\n// 引数: b(*Bar)、q(rules.Quote)。返り値: ありません。\n','// priorRange は120同体の連続足の範囲検査です。\n//\n// 引数: history([]Bar)、n(int)、end(float64)。返り値: Rangeです。\n']
    target=OWN/'minute_reuse.go'
    with target.open('x',encoding='utf-8',newline='\n') as stream:stream.write(header+'\n\n'.join(c+p for c,p in zip(comments,parts))+'\n')
    decoder=OWN.parent/'128Raw価格時計の全場足生成/decoder.go';body=decoder.read_bytes();copied=body.replace(b'package rawpricebars',b'package shortbirth129',1)
    with (OWN/'decoder.go').open('xb') as stream:stream.write(copied)
    proof={'成功':True,'自然データ読取':False,'旧ソース変更':False,'120元SHA256':hashlib.sha256(source.read_bytes()).hexdigest(),'関数本文SHA256':{n:hashlib.sha256(p.encode()).hexdigest() for n,p in zip(names,parts)},'128decoder元SHA256':hashlib.sha256(body).hexdigest(),'decoder差':'package宣言だけ'}
    with (OWN/'小部分再用の確認.json').open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
    print('3価格関数とdecoderの小部分を再用。自然データ未読。')


if __name__=='__main__':
    main()
