package shortbirth129

import (
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"math"
)

// key は系列と売買の独立状態識別子を作ります。
//
// 引数: mode(string)、side(int)。返り値: stringです。
func key(mode string, side int) string { return fmt.Sprintf("%s/%d", mode, side) }

// cooling は未出生と時刻0を混同せずcooldownを判定します。
//
// 引数: k(string)、now(float64)。返り値: boolです。
func (d *Detector) cooling(k string, now float64) bool {
	last, exists := d.LastSignals[k]
	return exists && now-last < 600
}

// refreshContexts は接触中の背景失効を量や拒否足の検査より先に取消します。
//
// 引数: s(rules.Snapshot)。返り値: ありません。
func (d *Detector) refreshContexts(s rules.Snapshot) {
	for _, mode := range []string{"C1", "C2"} {
		for _, side := range []int{1, -1} {
			k := key(mode, side)
			if d.Contacts[k] == nil {
				continue
			}
			if _, ok := context(s, mode, side, false); !ok {
				delete(d.Contacts, k)
				d.Stats[k+"/接触背景失効"]++
			}
		}
	}
}

// expire は期限と実Lastの無効化を候補生成前に検査します。
//
// 引数: q(Quote)。返り値: ありません。
func (d *Detector) expire(q Quote) {
	for k, c := range d.Contacts {
		if q.Time >= c.Expires {
			delete(d.Contacts, k)
			d.Stats[k+"/接触期限"]++
		}
	}
	for k, s := range d.Setups {
		if q.Time >= s.Expires || float64(s.Side)*(q.Last-s.I) <= 0 {
			delete(d.Setups, k)
			delete(d.Contacts, k)
			d.Stats[k+"/setup失効"]++
		}
	}
}

// touch は当時の帯又は前12本領域へのRaw接触を固定します。
//
// 引数: s(rules.Snapshot)、q(Quote)。返り値: ありません。
func (d *Detector) touch(s rules.Snapshot, q Quote) {
	for _, mode := range []string{"C1", "C2"} {
		for _, side := range []int{1, -1} {
			k := key(mode, side)
			if d.Contacts[k] != nil || d.Setups[k] != nil || d.cooling(k, q.Time) {
				continue
			}
			cohort, ok := context(s, mode, side, false)
			if !ok {
				d.Stats[k+"/背景不足"]++
				continue
			}
			t := s.Frames[300].Frame.Frame.Technical
			c := &Contact{At: rq(q), Cohort: cohort, Expires: q.Time + 900, Refs: refs(s.Refs)}
			if mode == "C1" {
				if !known(t.EMA8, t.EMA21) {
					continue
				}
				c.Low = math.Min(t.EMA8.Value, t.EMA21.Value) - .25*t.ATR.Value
				c.High = math.Max(t.EMA8.Value, t.EMA21.Value) + .25*t.ATR.Value
				if q.Last < c.Low || q.Last > c.High {
					continue
				}
			} else {
				if len(d.Five) != 12 {
					d.Stats[k+"/12本不足"]++
					continue
				}
				lo, hi := math.Inf(1), math.Inf(-1)
				r := []rules.Ref{}
				for _, p := range d.Five {
					f := p.Frame.Frame
					lo = math.Min(lo, f.OHLC.Low)
					hi = math.Max(hi, f.OHLC.High)
					r = append(r, rules.Ref{ID: f.ID, Width: 300, End: f.End, Delivered: p.Stamp})
				}
				if hi <= lo {
					continue
				}
				if side > 0 && (q.Last < lo || q.Last > lo+.2*(hi-lo)) || side < 0 && (q.Last > hi || q.Last < hi-.2*(hi-lo)) {
					continue
				}
				c.RangeLow = lo
				c.RangeHigh = hi
				c.Refs = refs(c.Refs, r)
			}
			d.Contacts[k] = c
			d.Stats[k+"/接触"]++
		}
	}
}

// setup は拒否1分のK/I/ATRを固定し、後のATRでcapを緩めません。
//
// 引数: mode/cohort(string)、side(int)、b(Bar)、s(rules.Snapshot)、q(Quote)。返り値: *Setupです。
func setup(mode, cohort string, side int, b Bar, s rules.Snapshot, q Quote) *Setup {
	a := s.Frames[300].Frame.Frame.Technical.ATR.Value
	v := &Setup{Mode: mode, Side: side, Cohort: cohort, At: rq(q), Bar: b, ATR: a, Expires: b.End + 120, Ready: true, Refs: refs(s.Refs), Fields: map[string]any{"reject_minute": b}}
	v.Fields["setup_atr_ref"] = s.Frames[300].Frame.Frame.ID
	if side > 0 {
		v.K = b.OHLC.High + 5
		v.I = b.OHLC.Low - 5
	} else {
		v.K = b.OHLC.Low - 5
		v.I = b.OHLC.High + 5
	}
	v.Cap = v.K + float64(side)*math.Min(20, .25*a)
	return v
}

// onMinute は確定した短い構造だけから3系列のsetupを作ります。
//
// 引数: b(Bar)、s(rules.Snapshot)、q(Quote)。返り値: ありません。
func (d *Detector) onMinute(b Bar, s rules.Snapshot, q Quote) {
	for _, side := range []int{1, -1} {
		x := float64(side)
		// ----------------------------------------
		// C3の反対足jに対する次の別足kを先に確認します。
		k3 := key("C3", side)
		if old := d.Setups[k3]; old != nil && !old.Ready {
			cohort, ok := context(s, "C3", side, true)
			if b.Start == old.Bar.End && ok && x*(b.OHLC.Close-old.K) >= 0 && x*(b.OHLC.Close-b.OHLC.Open) > 0 && b.VolumeKnown && b.Volume > 0 && b.Volume >= old.Bar.Volume {
				old.Ready = true
				old.Refs = refs(old.Refs, s.Refs)
				old.Fields["confirm_minute"] = b
				old.Fields["confirm_cohort"] = cohort
				d.Stats[k3+"/次足回復"]++
			} else {
				delete(d.Setups, k3)
				d.Stats[k3+"/次足未回復"]++
			}
		}
		// ----------------------------------------
		// C1/C2は接触を包含する又は後続の拒否足で固定します。
		for _, mode := range []string{"C1", "C2"} {
			k := key(mode, side)
			c := d.Contacts[k]
			if c == nil || d.Setups[k] != nil || b.End <= c.At.Time || b.Last.Index < c.At.Index || len(d.History) == 0 {
				continue
			}
			previous := d.History[len(d.History)-1]
			if !priorRange(d.History, 1, b.Start).Known || !b.VolumeKnown || !previous.VolumeKnown || b.Volume <= 0 || b.Volume < previous.Volume || !rejection(b, side) {
				d.Stats[k+"/拒否量不足"]++
				continue
			}
			cohort, ok := context(s, mode, side, false)
			if !ok {
				delete(d.Contacts, k)
				continue
			}
			a := s.Frames[300].Frame.Frame.Technical.ATR.Value
			if b.OHLC.High-b.OHLC.Low > a {
				continue
			}
			if mode == "C1" && (b.OHLC.Low > c.High || b.OHLC.High < c.Low) {
				continue
			}
			if mode == "C2" && (b.OHLC.Close < c.RangeLow || b.OHLC.Close > c.RangeHigh || side > 0 && b.OHLC.Low > c.RangeLow+.2*(c.RangeHigh-c.RangeLow) || side < 0 && b.OHLC.High < c.RangeHigh-.2*(c.RangeHigh-c.RangeLow)) {
				continue
			}
			v := setup(mode, cohort, side, b, s, q)
			v.Refs = refs(c.Refs, v.Refs)
			v.Fields["contact"] = c.At
			v.Fields["contact_cohort"] = c.Cohort
			if mode == "C2" {
				lo, hi := c.RangeLow, c.RangeHigh
				if side > 0 {
					v.Cap = math.Min(v.Cap, math.Min(lo+.25*(hi-lo), hi-145))
				} else {
					v.Cap = math.Max(v.Cap, math.Max(hi-.25*(hi-lo), lo+145))
				}
				v.Fields["range_low"] = lo
				v.Fields["range_high"] = hi
				v.Fields["required_room"] = 145
				if x*(v.Cap-v.K) < 0 {
					delete(d.Contacts, k)
					d.Stats[k+"/位置余地不成立"]++
					continue
				}
			}
			d.Setups[k] = v
			d.Stats[k+"/拒否setup"]++
		}
		// ----------------------------------------
		// C3の既知先行移動→小さく薄い反対足jを新しく固定します。
		if d.Setups[k3] != nil || d.cooling(k3, q.Time) || len(d.History) < 3 || !priorRange(d.History, 3, b.Start).Known {
			continue
		}
		cohort, ok := context(s, "C3", side, false)
		if !ok {
			continue
		}
		h := d.History[len(d.History)-3:]
		u0, u1, u2 := h[0], h[1], h[2]
		a := s.Frames[300].Frame.Frame.Technical.ATR.Value
		move := x * (u2.OHLC.Close - u0.OHLC.Close)
		if x*(u1.OHLC.Close-u0.OHLC.Close) <= 0 || x*(u2.OHLC.Close-u1.OHLC.Close) <= 0 || move < .5*a || x*(b.OHLC.Close-b.OHLC.Open) >= 0 || b.OHLC.High-b.OHLC.Low > .5*a {
			continue
		}
		retrace := x * (u2.OHLC.Close - b.OHLC.Close) / move
		if retrace <= 0 || retrace > .5 || !u1.VolumeKnown || !u2.VolumeKnown || u1.Volume <= 0 || u2.Volume <= 0 || !b.VolumeKnown || b.Volume <= 0 || b.Volume > (u1.Volume+u2.Volume)/2 {
			continue
		}
		v := setup("C3", cohort, side, b, s, q)
		v.Ready = false
		v.Fields["impulse_minutes"] = append([]Bar(nil), h...)
		v.Fields["retrace_ratio"] = retrace
		d.Setups[k3] = v
		d.Stats[k3+"/弱い反対足"]++
	}
}

// trigger は実Lastによる2原行/1秒維持後だけ出生させます。
//
// 引数: s(rules.Snapshot)、q(Quote)。返り値: ありません。
func (d *Detector) trigger(s rules.Snapshot, q Quote) {
	for _, mode := range []string{"C1", "C3", "C2"} {
		for _, side := range []int{1, -1} {
			k := key(mode, side)
			v := d.Setups[k]
			if v == nil || !v.Ready {
				continue
			}
			cohort, ok := context(s, mode, side, mode == "C3")
			if !ok {
				delete(d.Setups, k)
				delete(d.Contacts, k)
				d.Stats[k+"/背景失効"]++
				continue
			}
			x := float64(side)
			risk := x * (q.Last - v.I)
			if x*(q.Last-v.K) < 0 || x*(q.Last-v.Cap) > 0 || risk < 10 || risk > math.Min(125, 1.5*v.ATR) {
				v.Cross = nil
				v.HoldRows = 0
				d.Stats[k+"/Raw位置未成立"]++
				continue
			}
			if v.Cross == nil {
				r := rq(q)
				v.Cross = &r
				v.HoldRows = 1
				continue
			}
			if q.Time-v.Cross.Time > 10 {
				r := rq(q)
				v.Cross = &r
				v.HoldRows = 1
				d.Stats[k+"/維持期限reset"]++
				continue
			}
			v.HoldRows++
			if q.Time-v.Cross.Time < 1 || int(q.Index) <= v.Cross.Index || int(q.SourceLine) <= v.Cross.Line {
				continue
			}
			allrefs := refs(v.Refs, s.Refs)
			for _, r := range allrefs {
				if r.Delivered.Time > q.Time || r.Delivered.Index > int(q.Index) || r.Delivered.Line > int(q.SourceLine) {
					panic("出生の未来公表")
				}
			}
			fields := map[string]any{}
			for name, value := range v.Fields {
				fields[name] = value
			}
			fields["cohort"] = v.Cohort
			fields["birth_cohort"] = cohort
			fields["actual_raw_last"] = q.Last
			fields["hold_started_at"] = v.Cross
			fields["hold_rows"] = v.HoldRows
			fields["hold_elapsed_seconds"] = q.Time - v.Cross.Time
			fields["risk_min"] = 10
			fields["risk_max"] = math.Min(125, 1.5*v.ATR)
			fields["entry_ttl_seconds"] = 30
			continuousEnd := d.Scene.End - 300
			entryCutoff := math.Min(d.Scene.ForceClose, continuousEnd-120)
			fields["continuous_end"] = continuousEnd
			fields["entry_cutoff"] = entryCutoff
			fields["source_force_close"] = d.Scene.ForceClose
			fields["before_entry_cutoff"] = q.Time < entryCutoff
			fields["phase_policy"] = "元forcecloseまで技術候補を保持し、執行phaseは後段で拒否"
			d.Events = append(d.Events, Event{Session: d.Scene.Session, ID: fmt.Sprintf("%s/%s/%d/%d", d.Scene.Session, mode, side, q.Index), Mode: mode, Side: side, At: Stamp{Time: q.Time, Index: q.Index, Line: q.SourceLine}, EntryCap: v.Cap, Invalidation: v.I, ATR5: v.ATR, HoldBoundary: v.K, HoldMinimum: 0, MinimumRisk: 10, Refs: allrefs, Fields: fields})
			d.LastSignals[k] = q.Time
			delete(d.Setups, k)
			delete(d.Contacts, k)
			d.Stats[k+"/出生"]++
		}
	}
}
