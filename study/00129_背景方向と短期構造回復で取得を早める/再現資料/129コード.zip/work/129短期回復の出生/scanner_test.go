package shortbirth129

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"testing"
	"time"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// rawRow は自然原板と同型の人工JSON一行を作ります。
//
// 引数: at/last(float64)、badBBO(bool)。返り値: map[string]anyです。
func rawRow(at, last float64, badBBO bool) map[string]any {
	clock := time.Unix(int64(at), 0).UTC().Format(time.RFC3339Nano)
	r := map[string]any{"Symbol": "NK", "CurrentPriceTime": clock, "CurrentPrice": last, "TradingVolume": at - 36000, "TradingVolumeTime": clock}
	for i := 1; i <= 10; i++ {
		r[fmt.Sprintf("Buy%d", i)] = map[string]float64{"Price": 990 - float64(i-1)*10, "Qty": 1}
		r[fmt.Sprintf("Sell%d", i)] = map[string]float64{"Price": 1010 + float64(i-1)*10, "Qty": 1}
	}
	if badBBO {
		r["Buy1"] = map[string]float64{"Price": 1010, "Qty": 1}
	}
	return r
}

// artificialFile は一時フォルダだけへ人工原板を書きます。
//
// 引数: t(*testing.T)。返り値: Sceneです。
func artificialFile(t *testing.T) Scene {
	t.Helper()
	rows := []map[string]any{rawRow(36000, 1000, false), rawRow(36010, 1000, false), rawRow(36005, 1000, false), {"Symbol": "NK"}, rawRow(36011, 0, false), rawRow(36012, 1000, true)}
	data := []byte{}
	for _, row := range rows {
		b, e := json.Marshal(row)
		if e != nil {
			t.Fatal(e)
		}
		data = append(data, b...)
		data = append(data, '\n')
	}
	path := filepath.Join(t.TempDir(), "人工原板.jsonl")
	if e := os.WriteFile(path, data, 0600); e != nil {
		t.Fatal(e)
	}
	s := testScene()
	s.Raw = FileRef{Path: path, SHA256: hash(data), Bytes: int64(len(data))}
	s.ExpectedAccepted = 3
	s.ExpectedQuality = &Counts{Lines: 6, Accepted: 3, Delivered: 3, ClockMissing: 1, Backward: 1, LastNonPositive: 1, BadBBO: 1}
	for _, width := range []int{300, 900, 1800} {
		f := rules.ChartFrame{ID: fmt.Sprintf("人工配送/%d", width), SessionID: s.Session, Contract: s.Contract, Width: width, Start: 36000 - float64(width), End: 36000, AvailableAt: 36010, DeliveryAt: 36010, PriceKnown: true, OHLC: rules.OHLC{Open: 1000, High: 1010, Low: 990, Close: 1000}}
		s.Pubs = append(s.Pubs, rules.Publication{Stamp: rules.Stamp{Time: 36010, Index: 1, Line: 2}, Frame: rules.Frame{Frame: f}})
	}
	return s
}

// Test人工Raw一走査 は全品質・同Raw三時間軸配送・0出生を残します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test人工Raw一走査(t *testing.T) {
	s := artificialFile(t)
	r, e := Generate([]Scene{s}, false)
	if e != nil {
		t.Fatal(e)
	}
	if !r.Success || r.FinancialLabels || r.RawPasses != 1 || len(r.Scenes) != 1 || r.Scenes[0].Births != 0 || len(r.Events) != 0 || r.Scenes[0].ActualSHA != s.Raw.SHA256 || r.Scenes[0].Counts != *s.ExpectedQuality {
		t.Fatalf("全場/品質/0出生の差:%+v", r)
	}
	if e = Validate([]Scene{s}, true); e == nil {
		t.Fatal("自然73場要件を人工1場で通過")
	}
}

// Test原板品質と配送時計の差 は不一致を成功や0出生へ変えません。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test原板品質と配送時計の差(t *testing.T) {
	for _, kind := range []string{"品質", "SHA", "配送"} {
		t.Run(kind, func(t *testing.T) {
			s := artificialFile(t)
			switch kind {
			case "品質":
				s.ExpectedQuality.BadBBO = 0
			case "SHA":
				s.Raw.SHA256 = fmt.Sprintf("%064d", 0)
			case "配送":
				s.Pubs[0].Stamp.Line = 3
			}
			if _, e := Generate([]Scene{s}, false); e == nil {
				t.Fatal("不一致を成功")
			}
		})
	}
}

// Test固定背景の読取ガード は別SHA指定ならファイル読取前に拒否します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test固定背景の読取ガード(t *testing.T) {
	if _, e := Load("存在しない人工入力", "別SHA"); e == nil || e.Error() != "固定背景SHA指定差" {
		t.Fatal("背景ガードなし")
	}
}

// Test背景崩れで接触を取消 は量不足の足でも古い接触を残しません。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test背景崩れで接触を取消(t *testing.T) {
	d := NewDetector(testScene())
	s := snapshot(false)
	if _, e := d.Observe(observation(36000, 1010, 10, 1), s); e != nil {
		t.Fatal(e)
	}
	if d.Contacts[key("C1", 1)] == nil {
		t.Fatal("初回接触なし")
	}
	broken := snapshot(false)
	p := broken.Frames[1800]
	p.Frame.Frame.Technical.Gap = val(-20)
	broken.Frames[1800] = p
	if _, e := d.Observe(observation(36001, 1100, 11, 2), broken); e != nil {
		t.Fatal(e)
	}
	if d.Contacts[key("C1", 1)] != nil {
		t.Fatal("背景崩れ後の古い接触残存")
	}
	if _, e := d.Observe(observation(36002, 1010, 12, 3), s); e != nil {
		t.Fatal(e)
	}
	if c := d.Contacts[key("C1", 1)]; c == nil || c.At.Index != 3 {
		t.Fatal("背景回復後に古い接触を再利用")
	}
}
