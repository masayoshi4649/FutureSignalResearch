package shortbirth129

import (
	"bufio"
	"bytes"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"io"
	"os"
	"reflect"
	"sort"
	"strings"
	"time"
)

// hash は保存bytesのSHA256を求めます。
//
// 引数: body([]byte)。返り値: stringです。
func hash(body []byte) string { v := sha256.Sum256(body); return hex.EncodeToString(v[:]) }

// normal は元parserと同じ最良BBO正常性を返します。
//
// 引数: q(Quote)。返り値: boolです。
func normal(q Quote) bool { return finite(q.Bid, q.Ask) && q.Bid > 0 && q.Ask > q.Bid }

// quantity は128と同じ当Rawの数量/数量時計を解釈します。
//
// 引数: raw([]byte)。返り値: *float64/*float64は既知量/時計又はnilです。
func quantity(raw []byte) (*float64, *float64) {
	var fields map[string]json.RawMessage
	if json.Unmarshal(raw, &fields) != nil {
		return nil, nil
	}
	var volume *float64
	var text string
	if json.Unmarshal(fields["TradingVolume"], &volume) != nil || volume == nil || !finite(*volume) || *volume < 0 || json.Unmarshal(fields["TradingVolumeTime"], &text) != nil {
		return nil, nil
	}
	t, e := time.Parse(time.RFC3339Nano, text)
	if e != nil {
		return volume, nil
	}
	stamp := float64(t.UnixNano()) / 1e9
	return volume, &stamp
}

// Validate は自然73場の順序・metadataを走査前に確認します。
//
// 引数: scenes([]Scene)、all73(bool)。返り値: errorです。falseは人工用です。
func Validate(scenes []Scene, all73 bool) error {
	if len(scenes) == 0 || all73 && len(scenes) != 73 {
		return fmt.Errorf("全73場の入力が必要")
	}
	ids := map[string]bool{}
	days, nights := 0, 0
	for i, s := range scenes {
		if s.Session == "" || s.Contract == "" || ids[s.Session] || !finite(s.Start, s.End, s.ForceClose) || s.End <= s.Start || s.ForceClose <= s.Start || s.ForceClose > s.End || s.Cutoff != 0 || s.Raw.Path == "" || len(s.Raw.SHA256) != 64 || s.ExpectedQuality == nil || s.ExpectedAccepted <= 0 {
			return fmt.Errorf("metadata差:%s", s.Session)
		}
		if _, e := hex.DecodeString(s.Raw.SHA256); e != nil {
			return e
		}
		q := s.ExpectedQuality
		if q.Accepted != s.ExpectedAccepted || q.Delivered != q.Accepted || q.CutoffExcluded != 0 || q.Lines != q.Accepted+q.ClockMissing+q.ClockInvalid+q.Outside+q.Backward+q.LastNonPositive+q.LastNonFinite || q.BadBBO > q.Accepted {
			return fmt.Errorf("品質算術差:%s", s.Session)
		}
		if i > 0 && s.Start < scenes[i-1].End {
			return fmt.Errorf("場順序差")
		}
		ids[s.Session] = true
		if strings.HasSuffix(s.Session, "_Day") {
			days++
		}
		if strings.HasSuffix(s.Session, "_Night") {
			nights++
		}
		previous := -1
		line := -1
		for _, p := range s.Pubs {
			f := p.Frame.Frame
			if f.SessionID != s.Session || f.Contract != s.Contract || p.Stamp.Index < previous || p.Stamp.Line < line || p.Stamp.Index < 0 || int64(p.Stamp.Index) >= s.ExpectedAccepted {
				return fmt.Errorf("背景公表scope/順序差")
			}
			previous = p.Stamp.Index
			line = p.Stamp.Line
		}
	}
	if all73 && (days != 37 || nights != 36) {
		return fmt.Errorf("Day37/Night36差")
	}
	return nil
}

// Load は固定即時gap300公表だけを背景として読みます。Raw走査は行いません。
//
// 引数: path/expected(string)。返り値: []Scene/errorです。
func Load(path, expected string) ([]Scene, error) {
	if expected != BackgroundSHA {
		return nil, fmt.Errorf("固定背景SHA指定差")
	}
	data, e := os.ReadFile(path)
	if e != nil {
		return nil, e
	}
	if hash(data) != expected {
		return nil, fmt.Errorf("背景SHA差")
	}
	var body io.Reader = bytes.NewReader(data)
	if len(data) > 1 && data[0] == 0x1f && data[1] == 0x8b {
		z, e := gzip.NewReader(body)
		if e != nil {
			return nil, e
		}
		defer z.Close()
		body = z
	}
	var input struct {
		Success bool `json:"success"`
		Model   struct {
			Name string `json:"name"`
		} `json:"model"`
		Scenes []Scene `json:"scenes"`
	}
	if e = json.NewDecoder(body).Decode(&input); e != nil {
		return nil, e
	}
	if !input.Success || input.Model.Name != "gap300" {
		return nil, fmt.Errorf("即時gap300成功入力だけを使用")
	}
	if e = Validate(input.Scenes, true); e != nil {
		return nil, e
	}
	return input.Scenes, nil
}

type SceneResult struct {
	Session          string         `json:"session"`
	Contract         string         `json:"contract"`
	Start            float64        `json:"start"`
	End              float64        `json:"end"`
	ForceClose       float64        `json:"force_close"`
	Raw              FileRef        `json:"raw"`
	ExpectedAccepted int64          `json:"expected_accepted"`
	ExpectedQuality  *Counts        `json:"expected_quality"`
	Counts           Counts         `json:"counts"`
	ActualSHA        string         `json:"actual_sha256"`
	RawPasses        int            `json:"raw_passes"`
	Births           int            `json:"births"`
	ByMode           map[string]int `json:"by_mode"`
	Stats            map[string]int `json:"stats"`
}
type Result struct {
	Success         bool          `json:"success"`
	Trial           int           `json:"trial"`
	BackgroundSHA   string        `json:"background_sha256"`
	FinancialLabels bool          `json:"financial_labels_used"`
	Events          []Event       `json:"events"`
	Scenes          []SceneResult `json:"scenes"`
	RawPasses       int           `json:"raw_passes"`
	BirthSessions   int           `json:"birth_sessions"`
}

// scan は当場Rawを一走査し、背景公表を同Raw全Add後に観測します。
//
// 引数: scene(Scene)、bank(*rules.Bank)。返り値: []Event/SceneResult/errorです。
func scan(scene Scene, bank *rules.Bank) ([]Event, SceneResult, error) {
	result := SceneResult{Session: scene.Session, Contract: scene.Contract, Start: scene.Start, End: scene.End, ForceClose: scene.ForceClose, Raw: scene.Raw, ExpectedAccepted: scene.ExpectedAccepted, ExpectedQuality: scene.ExpectedQuality, RawPasses: 1, ByMode: map[string]int{"C1": 0, "C2": 0, "C3": 0}}
	if e := bank.StartSession(scene.Session, scene.Contract); e != nil {
		return nil, result, e
	}
	d := NewDetector(scene)
	f, e := os.Open(scene.Raw.Path)
	if e != nil {
		return nil, result, e
	}
	defer f.Close()
	before, e := f.Stat()
	if e != nil {
		return nil, result, e
	}
	if scene.Raw.Bytes > 0 && scene.Raw.Bytes != before.Size() {
		return nil, result, fmt.Errorf("原板bytes差")
	}
	h := sha256.New()
	buffer := bufio.NewReader(io.TeeReader(f, h))
	header, e := buffer.Peek(2)
	if e != nil {
		return nil, result, e
	}
	var reader io.Reader = buffer
	if header[0] == 0x1f && header[1] == 0x8b {
		z, e := gzip.NewReader(buffer)
		if e != nil {
			return nil, result, e
		}
		defer z.Close()
		reader = z
	}
	scanner := bufio.NewScanner(reader)
	scanner.Buffer(make([]byte, 65536), 4<<20)
	previous := scene.Start
	index := int64(0)
	contracts := map[string]bool{}
	pubIndex := 0
	for scanner.Scan() {
		result.Counts.Lines++
		row := scanner.Bytes()
		q, reason, next, e := decodeRow(row, result.Counts.Lines, index, scene, previous, &result.Counts, contracts)
		if e != nil {
			return nil, result, e
		}
		previous = next
		if q == nil {
			if reason == "clock_missing" || reason == "clock_invalid" || reason == "backward_clock" {
				d.RejectClock(reason)
			}
			continue
		}
		if pubIndex < len(scene.Pubs) && scene.Pubs[pubIndex].Stamp.Index < int(q.Index) {
			return nil, result, fmt.Errorf("背景配送原行を通過")
		}
		for pubIndex < len(scene.Pubs) && scene.Pubs[pubIndex].Stamp.Index == int(q.Index) {
			p := scene.Pubs[pubIndex]
			if p.Stamp.Time != q.Time || p.Stamp.Line != int(q.SourceLine) {
				return nil, result, fmt.Errorf("背景配送stamp全項目差")
			}
			if e = bank.Add(p); e != nil {
				return nil, result, e
			}
			if e = d.AddPublication(p); e != nil {
				return nil, result, e
			}
			pubIndex++
		}
		s, e := bank.Current(rq(*q))
		if e != nil {
			return nil, result, e
		}
		v, at := quantity(row)
		if _, e = d.Observe(Observation{Quote: *q, Volume: v, VolumeTime: at}, s); e != nil {
			return nil, result, e
		}
		index++
	}
	if e = scanner.Err(); e != nil {
		return nil, result, e
	}
	if _, e = io.Copy(io.Discard, buffer); e != nil {
		return nil, result, e
	}
	result.ActualSHA = hex.EncodeToString(h.Sum(nil))
	after, e := f.Stat()
	if e != nil {
		return nil, result, e
	}
	pathAfter, e := os.Stat(scene.Raw.Path)
	if e != nil {
		return nil, result, e
	}
	if result.ActualSHA != scene.Raw.SHA256 || before.Size() != after.Size() || !before.ModTime().Equal(after.ModTime()) || !os.SameFile(before, pathAfter) || before.Size() != pathAfter.Size() || !before.ModTime().Equal(pathAfter.ModTime()) || !reflect.DeepEqual(result.Counts, *scene.ExpectedQuality) || result.Counts.Accepted != scene.ExpectedAccepted || pubIndex != len(scene.Pubs) || len(contracts) != 1 || !contracts[scene.Contract] {
		return nil, result, fmt.Errorf("Raw SHA/stat/11品質/限月/全公表配送差:%s", scene.Session)
	}
	result.Stats = d.Stats
	result.Births = len(d.Events)
	for _, event := range d.Events {
		result.ByMode[event.Mode]++
	}
	return d.Events, result, nil
}

// Generate は固定73場を逐次生成し、0出生と品質も保存します。
//
// 引数: scenes([]Scene)、all73(bool)。返り値: Result/error。falseは人工用です。
func Generate(scenes []Scene, all73 bool) (Result, error) {
	result := Result{Trial: 129, BackgroundSHA: BackgroundSHA, Events: []Event{}, Scenes: []SceneResult{}}
	if e := Validate(scenes, all73); e != nil {
		return result, e
	}
	bank := rules.NewBank()
	for _, scene := range scenes {
		events, summary, e := scan(scene, bank)
		if e != nil {
			return result, e
		}
		result.Events = append(result.Events, events...)
		result.Scenes = append(result.Scenes, summary)
		result.RawPasses++
		if len(events) > 0 {
			result.BirthSessions++
		}
		fmt.Printf("129出生 %s 採用=%d 出生=%d C1=%d C2=%d C3=%d\n", scene.Session, summary.Counts.Accepted, len(events), summary.ByMode["C1"], summary.ByMode["C2"], summary.ByMode["C3"])
	}
	sort.SliceStable(result.Events, func(i, j int) bool {
		a, b := result.Events[i], result.Events[j]
		if a.At.Time != b.At.Time {
			return a.At.Time < b.At.Time
		}
		if a.At.Line != b.At.Line {
			return a.At.Line < b.At.Line
		}
		return a.ID < b.ID
	})
	result.Success = true
	return result, nil
}
