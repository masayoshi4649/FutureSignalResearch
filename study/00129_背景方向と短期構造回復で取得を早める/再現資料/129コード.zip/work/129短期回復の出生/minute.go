package shortbirth129

import (
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"math"
)

// rq は実Rawの価格時計と物理順を公開用Quoteへ写します。
//
// 引数: q(Quote)。返り値: rules.Quoteです。
func rq(q Quote) rules.Quote {
	return rules.Quote{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine), Last: q.Last}
}

// cloneObservation は外部ポインタを残さず最後の原行を保存します。
//
// 引数: o(Observation)。返り値: Observationです。
func cloneObservation(o Observation) Observation {
	if o.Volume != nil {
		v := *o.Volume
		o.Volume = &v
	}
	if o.VolumeTime != nil {
		v := *o.VolumeTime
		o.VolumeTime = &v
	}
	return o
}

// sameValue はnilと既知0を区別します。
//
// 引数: a/b(*float64)。返り値: boolです。
func sameValue(a, b *float64) bool { return a == nil && b == nil || a != nil && b != nil && *a == *b }

// NewDetector は当場の価格構造と候補を初期化します。
//
// 引数: scene(Scene)。返り値: *Detectorです。
func NewDetector(scene Scene) *Detector {
	return &Detector{Scene: scene, Contacts: map[string]*Contact{}, Setups: map[string]*Setup{}, LastSignals: map[string]float64{}, Stats: map[string]int{}, Events: []Event{}}
}

// clearShort は短期未知時にsetupと構造を消し、背景Bankを変更しません。
//
// 引数: reason(string)。返り値: ありません。
func (d *Detector) clearShort(reason string) {
	d.History = nil
	d.Contacts = map[string]*Contact{}
	d.Setups = map[string]*Setup{}
	d.Volume = nil
	d.VolumeTime = nil
	d.Stats[reason]++
}

// RejectClock は破棄行を現在1分の未知へ反映します。
//
// 引数: reason(string)。返り値: ありません。
func (d *Detector) RejectClock(reason string) {
	if d.Current != nil {
		d.Current.PriceKnown = false
		d.Current.VolumeKnown = false
	}
	d.clearShort("時計拒否/" + reason)
}

// AddPublication は当場に配送済みの5分構造だけを蓄積します。
//
// 引数: p(rules.Publication)。返り値: errorです。
func (d *Detector) AddPublication(p rules.Publication) error {
	f := p.Frame.Frame
	if f.SessionID != d.Scene.Session || f.Contract != d.Scene.Contract {
		return fmt.Errorf("当場公表scope差")
	}
	if f.Width != 300 {
		return nil
	}
	if !f.PriceKnown {
		d.Five = nil
		return nil
	}
	if len(d.Five) > 0 && f.End-d.Five[len(d.Five)-1].Frame.Frame.End != 300 {
		d.Five = nil
	}
	d.Five = append(d.Five, p)
	if len(d.Five) > 12 {
		d.Five = d.Five[len(d.Five)-12:]
	}
	return nil
}

// addQuantity は128と同じ当Raw累積差分を現在区間へ割り当てます。
//
// 引数: o(Observation)。返り値: ありません。
func (d *Detector) addQuantity(o Observation) {
	b := d.Current
	q := o.Quote
	if o.Volume == nil || o.VolumeTime == nil || !finite(*o.Volume, *o.VolumeTime) || *o.Volume < 0 || *o.VolumeTime > q.Time {
		b.VolumeKnown = false
		d.Volume = nil
		d.VolumeTime = nil
		d.Stats["数量未知"]++
		return
	}
	if d.Volume == nil || *o.Volume < *d.Volume || *o.VolumeTime < *d.VolumeTime {
		b.VolumeKnown = false
		d.Stats["数量基準reset"]++
	} else {
		sum := b.Volume + *o.Volume - *d.Volume
		if !finite(sum) {
			b.VolumeKnown = false
			d.Volume = nil
			d.VolumeTime = nil
			d.Stats["数量非有限"]++
			return
		}
		b.Volume = sum
	}
	v, t := *o.Volume, *o.VolumeTime
	d.Volume = &v
	d.VolumeTime = &t
}

// startMinute は120同体の価格形成を数量/品質フラグで包みます。
//
// 引数: o(Observation)。返り値: ありません。
func (d *Detector) startMinute(o Observation) {
	d.Current = makeBar(rq(o.Quote))
	d.Current.PriceKnown = true
	d.Current.VolumeKnown = true
	d.addQuantity(o)
}

// Observe は確定1分と現在Rawを分け、未来の終値を現在価格へ使いません。
//
// 引数: o(Observation)、s(rules.Snapshot)。返り値: []Event/errorはこの原行での出生です。
func (d *Detector) Observe(o Observation, s rules.Snapshot) ([]Event, error) {
	q := o.Quote
	if !finite(q.Time, q.Last) || q.Last <= 0 || q.Index < 0 || q.SourceLine < 1 || s.SessionID != d.Scene.Session || s.Contract != d.Scene.Contract {
		return nil, fmt.Errorf("Raw/公表scope差")
	}
	if d.Last != nil {
		last := d.Last.Quote
		if q.Index == last.Index {
			if q != last || !sameValue(o.Volume, d.Last.Volume) || !sameValue(o.VolumeTime, d.Last.VolumeTime) {
				return nil, fmt.Errorf("同原行改変")
			}
			return nil, nil
		}
		if q.Index <= last.Index || q.SourceLine <= last.SourceLine || q.Time < last.Time {
			return nil, fmt.Errorf("原行順逆転")
		}
	}
	before := len(d.Events)
	d.Stats["採用Raw"]++
	if d.Last != nil && q.Time-d.Last.Quote.Time > 60 {
		d.Current = nil
		d.clearShort("価格時計gap60超")
	}
	d.expire(q)
	d.refreshContexts(s)
	currentStart := math.Floor(q.Time/60) * 60
	if d.Current == nil {
		d.startMinute(o)
	} else if currentStart == d.Current.Start {
		updateBar(d.Current, rq(q))
		d.addQuantity(o)
	} else {
		b := *d.Current
		d.Stats["閉鎖1分"]++
		if currentStart != b.End || q.Time-b.End > 30 || !b.PriceKnown {
			d.clearShort("閉鎖1分未知")
		} else {
			if len(d.History) > 0 {
				previous := d.History[len(d.History)-1]
				b.TR = rules.Value{Known: true, Value: math.Max(b.OHLC.High-b.OHLC.Low, math.Max(math.Abs(b.OHLC.High-previous.OHLC.Close), math.Abs(b.OHLC.Low-previous.OHLC.Close)))}
			}
			d.Stats["既知閉鎖1分"]++
			if q.Time < d.Scene.ForceClose {
				d.onMinute(b, s, q)
			}
			d.History = append(d.History, b)
			if len(d.History) > 6 {
				d.History = d.History[len(d.History)-6:]
			}
		}
		d.startMinute(o)
	}
	if q.Time < d.Scene.ForceClose {
		d.touch(s, q)
		d.trigger(s, q)
	} else {
		d.Contacts = map[string]*Contact{}
		d.Setups = map[string]*Setup{}
	}
	saved := cloneObservation(o)
	d.Last = &saved
	return append([]Event(nil), d.Events[before:]...), nil
}
