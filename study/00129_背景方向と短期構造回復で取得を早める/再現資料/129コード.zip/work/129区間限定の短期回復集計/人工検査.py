"""自然Raw/出生JSON/結果を開かず、129 first-fillと全73分母・未知・鏡像を検査する。"""
from pathlib import Path
from collections import Counter
import copy
import importlib.util
import json
import unittest

OWN = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('aggregate_birth129_artificial',OWN/'集計する.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def row(identifier: str,mode: str,side: int,risk: float,index: int=1,at: float=101) -> dict:
    """
    機能: 選択器へ渡す当時取得メタデータだけの人工行を作る。
    引数: identifier/mode(str)、side(int)、risk/at(float)、index(int)。返り値: dict。
    """
    return {'session':'人工','mode':mode,'risk':risk,
            'case':{'id':identifier,'original_side':side,'original':{'entry':{'time':at,'index':index,'source_line':index+1}}}}


# ----------------------------------------
def fixture(zero_last: bool=False) -> dict:
    """
    機能: 全650出生・73場の結果形を人工的に構成する。生原板の再生ではない。
    引数: zero_last(bool)は出生0・取得0場を含める指定。返り値: dict。
    """
    modes = ['C2']*300+['C1']*200+['C3']*150
    cursor = 0
    scenes = []
    for i in range(73):
        count = (11 if i==0 else 9 if i<72 else 0) if zero_last else (9 if i<66 else 8)
        sid = f'人工{i:02d}'
        start = 1000000.+i*10000
        side = 1 if i%2==0 else -1
        request = {'clock':'人工時計','time':start,'index':0,'source_line':1,'last':1000.,'bid':995.,'ask':1005.,'quote_ok':True}
        entry = {**request,'time':start+1,'index':1,'source_line':2,
                 'last':1005. if side==1 else 995.,'bid':1000. if side==1 else 990.,'ask':1010. if side==1 else 1000.}
        births,cases = [],[]
        for j in range(count):
            identifier = f'{sid}/人工{j}'
            mode = modes[cursor]; cursor += 1
            at = {'time':start if j==0 else start+2+j,'index':0 if j==0 else j+2,'source_line':1 if j==0 else j+3}
            event = {'id':identifier,'mode':mode,'side':side,'at':at,'entry_cap':1050. if side==1 else 950.,
                     'invalidation':900. if side==1 else 1100.,'atr5':100.,
                     'hold_boundary':1000. if j==0 else 1001. if side==1 else 999.,'hold_minimum':0.,
                     'minimum_risk':10.,'refs':[{'id':'人工公表'}],'fields':{'人工':True}}
            born = {'event':event,'request':request if j==0 else None,'expires':at['time']+30,
                    'status':'filled' if j==0 else 'birth_structure_lost','evaluation':entry if j==0 else None,
                    'entry':entry if j==0 else None,'risk':110. if j==0 else None,'maximum_risk':125.}
            births.append(born)
            if j!=0:
                continue
            case = {'id':identifier,'original_side':side,'source_event':event,'request_quote':request}
            for axis in ('BBO','Last'):
                for reverse in (False,True):
                    direction = -side if reverse else side
                    price = entry['last'] if axis=='Last' else entry['ask'] if direction==1 else entry['bid']
                    outcomes = []
                    for seconds in (1800,3600):
                        quote = {**entry,'time':entry['time']+seconds,'index':1000,'source_line':1001,
                                 'last':1145. if side==1 else 855.,'bid':1120. if side==1 else 850.,'ask':1150. if side==1 else 860.}
                        mark = quote['last'] if axis=='Last' else quote['bid'] if direction==1 else quote['ask']
                        points = direction*(mark-price)
                        status = 'gap_censored' if i in (1,2) else 'complete'
                        touches = []
                        for width in module.WIDTHS:
                            label = (1 if points>=width else -1 if points<=-width else 0) if i!=2 else 0
                            touches.append({'width':width,'direction':label,'quote':quote if label else None})
                        outcomes.append({'seconds':seconds,'deadline':entry['time']+seconds,'status':status,
                            'touches':touches,'endpoint':quote if status=='complete' else None,'points':points if status=='complete' else None,
                            'net0':points*100-77 if axis=='BBO' and status=='complete' else None,
                            'net5':points*100-1077 if axis=='BBO' and status=='complete' else None})
                    name = ('chart_' if axis=='Last' else '')+('reverse' if reverse else 'original')
                    case[name] = {'status':'filled','birth':{'id':identifier,'side':direction,'quote':entry},'entry':entry,'entry_price':price,'outcomes':outcomes}
            cases.append(case)
        quality = {'lines':2000,'source_parser_accepted':2000,'source_delivered':2000}
        scenes.append({'session':sid,'success':True,'raw':{'path':'人工のみ','sha256':'a'*64},'actual_sha256':'a'*64,
                       'stat_before':{'bytes':1,'mod_time_ns':1},'stat_after':{'bytes':1,'mod_time_ns':1},
                       'quality':quality,'expected_quality':quality,'raw_passes':1,'source_entries':count,'births':births,'cases':cases})
    assert cursor==650
    return {'trial':129,'success':True,'input_sha256':'b'*64,'widths':list(module.WIDTHS),'horizons':list(module.HORIZONS),'scenes':scenes}


# ----------------------------------------
def mirror(data: dict,k: float=3000.) -> dict:
    """
    機能: 全Quoteと全価格境界・売買方向をK-priceへ鏡像変換する。
    引数: data(dict)、k(float)。返り値: dict。元人工正本を変更しない。
    """
    output = json.loads(json.dumps(data))
    def walk(value) -> None:
        """
        機能: 共有参照のない人工JSONを再帰的に変換する。
        引数: value(任意型)。返り値: None。
        """
        if isinstance(value,list):
            for item in value:walk(item)
        elif isinstance(value,dict):
            if {'bid','ask','last'}<=set(value):
                value['bid'],value['ask'],value['last'] = k-value['ask'],k-value['bid'],k-value['last']
            for name in ('entry_cap','invalidation','hold_boundary','entry_price'):
                if name in value:value[name] = k-value[name]
            for name in ('side','original_side'):
                if name in value:value[name] = -value[name]
            for item in value.values():walk(item)
    walk(output)
    return output


# ----------------------------------------
class Artificial129(unittest.TestCase):
    """自然結果前のfirst-fill集計検査。"""

    def test_earliest_clock_then_mode_risk_and_id(self) -> None:
        """
        機能: 未来C1非優先、同RawのC1→C3→C2優先、最小risk、同sideIDを検査する。
        引数: self(Artificial129)。返り値: None。
        """
        early = row('早いQ','C2',1,100)
        later = row('後のR','C1',-1,10,2,102)
        picked,trace = module.choose_first([later,early])
        self.assertIs(picked,early)
        r,t = row('C1','C1',1,100),row('C3','C3',-1,10)
        self.assertIs(module.choose_first([t,r])[0],r)
        q=row('C2','C2',1,5)
        self.assertIs(module.choose_first([q,t])[0],t)
        policies,_=module.policies_for([q,t,r],['人工'])
        self.assertEqual({p:policies[p][0]['case']['id'] for p in ('P1','P2','P3')},{'P1':'C1','P2':'C2','P3':'C3'})
        r1,r2 = row('R1','C1',1,20),row('R2','C1',-1,10)
        self.assertIs(module.choose_first([r1,r2])[0],r2)
        b,a = row('B','C3',1,10),row('A','C3',1,10)
        self.assertIs(module.choose_first([b,a])[0],a)
        self.assertEqual(trace[0]['status'],'selected')

    def test_direction_tie_skips_whole_raw(self) -> None:
        """
        機能: 両side同riskは同Rawの他modeへ降格せず次Rawへ進む。
        引数: self(Artificial129)。返り値: None。
        """
        rows = [row('R買','C1',1,10),row('R売','C1',-1,10),row('同RawQ','C2',1,5),row('次RawS','C3',1,10,2,102)]
        picked,trace = module.choose_first(rows)
        self.assertEqual(picked['case']['id'],'次RawS')
        self.assertEqual([t['status'] for t in trace],['direction_unresolved','selected'])
        self.assertIsNone(module.choose_first(rows[:3])[0])
        self.assertEqual(module.choose_first(rows,'C2')[0]['case']['id'],'同RawQ')
        reflected = copy.deepcopy(rows)
        for r in reflected:r['case']['original_side'] *= -1
        self.assertEqual(module.choose_first(reflected)[0]['case']['id'],picked['case']['id'])
        # ----------------------------------------
        # 選択器はoutcomesや後続価格を読む必要がない。
        for r in rows:r['case']['outcomes'] = object()
        self.assertEqual(module.choose_first(rows)[0]['case']['id'],'次RawS')

    def test_full_73_650_mirror_unknown_and_touch(self) -> None:
        """
        機能: 全73/650・鏡像・既知touch優先・Last金額nil・120表を検査する。
        引数: self(Artificial129)。返り値: None。
        """
        data = fixture()
        original = copy.deepcopy(data)
        fixed = module.module124()
        result,ledger,tables = module.process(data,fixed)
        reflected,_,_ = module.process(mirror(data),fixed)
        self.assertEqual(result['集計'],reflected['集計'])
        self.assertEqual(data,original)
        self.assertEqual(result['出生mode'],{'C2':300,'C1':200,'C3':150})
        self.assertEqual([len(t['rows']) for t in tables['tables']],[120,73,73])
        self.assertEqual(len(ledger['全出生']),650)
        self.assertTrue(result['主全73場取得'])
        self.assertEqual(result['政策取得ID']['F0'],result['政策取得ID']['FR'])
        s = result['集計']['F0']['BBO']['3600']['125']
        self.assertEqual((s['complete'],s['censored'],s['ifd_known'],s['ifd_unknown']),(71,2,72,1))
        for p in module.POLICIES:
            for h in module.HORIZONS:
                for w in module.WIDTHS:
                    self.assertIsNone(result['集計'][p]['Last'][str(h)][str(w)]['ifd_net5_sum'])
        self.assertEqual(result['bootstrap']['場数'],73)
        self.assertEqual(result['bootstrap']['政策']['F0']['既知IFD数'],72)
        self.assertEqual(result['bootstrap']['政策']['F0']['F0両側既知ペア平均差95区間'],[0.,0.])

    def test_zero_scene_kept_and_malformed_refused(self) -> None:
        """
        機能: 0出生/0取得も73分母、未知金額はnull、riskとSource不整合は拒否する。
        引数: self(Artificial129)。返り値: None。
        """
        data = fixture(True)
        result,_,tables = module.process(data,module.module124())
        self.assertEqual((result['coverage']['F0']['target_sessions'],result['coverage']['F0']['filled_sessions']),(73,72))
        self.assertFalse(result['主全73場取得'])
        self.assertFalse(result['主両条件達成'])
        last = tables['tables'][2]
        row = last['rows'][-1]
        self.assertEqual(row[last['headers'].index('F0H60状態')],'未取得')
        self.assertIsNone(row[last['headers'].index('F0C5既知差引円')])
        self.assertEqual(row[last['headers'].index('未取得場累計')],1)
        bad = copy.deepcopy(data)
        bad['scenes'][0]['cases'][0]['source_event']['minimum_risk'] = 11
        with self.assertRaises(AssertionError):module.audit_records(bad)
        bad = copy.deepcopy(data)
        bad['scenes'][0]['cases'][0]['source_event']['mode'] = '別'
        with self.assertRaises(AssertionError):module.audit_records(bad)
        bad = copy.deepcopy(data)
        bad['scenes'][0]['cases'][0]['request_quote'] = None
        with self.assertRaises(AssertionError):module.audit_records(bad)

    def test_full_input_scope_and_event_identity(self) -> None:
        """
        機能: 件数だけ同じでも場順・出生票が異なる入力を拒否し、全0出生も許可する。
        引数: self(Artificial129)。返り値: None。
        """
        data=fixture()
        source={'trial':129,'source_entry_births_used':False,
                'scenes':[{'session':s['session'],'events':[copy.deepcopy(b['event']) for b in s['births']]} for s in data['scenes']]}
        self.assertEqual(module.audit_source(data,source),650)
        changed=copy.deepcopy(source)
        changed['scenes'][0]['events'][0]['entry_cap']+=5
        with self.assertRaises(AssertionError):module.audit_source(data,changed)
        changed=copy.deepcopy(source)
        changed['scenes'][0],changed['scenes'][1]=changed['scenes'][1],changed['scenes'][0]
        with self.assertRaises(AssertionError):module.audit_source(data,changed)
        empty_data=copy.deepcopy(data);empty_source=copy.deepcopy(source)
        for scene in empty_data['scenes']:
            scene['births']=[]
            scene['cases']=[]
            scene['source_entries']=0
        for scene in empty_source['scenes']:scene['events']=[]
        self.assertEqual(module.audit_source(empty_data,empty_source),0)
        empty_result,_,empty_tables=module.process(empty_data,module.module124(),0)
        self.assertEqual(empty_result['coverage']['F0']['filled_sessions'],0)
        self.assertEqual([len(t['rows']) for t in empty_tables['tables']],[120,0,73])


if __name__=='__main__':
    unittest.main(verbosity=2)
