"""固定取得の正逆・技術切替・純価格方向を別々に集計し、原因診断へ結ぶ。"""
from pathlib import Path
from collections import Counter, defaultdict
from datetime import datetime, timezone, timedelta
from statistics import mean
import hashlib
import json
import random

ROOT=Path(__file__).resolve().parents[2]
OWN=Path(__file__).resolve().parent
RUN=ROOT/'work/124入口の正逆比較'
FEATURE=ROOT/'work/124当時特徴の診断/全79例の当時特徴.json'
ADDITIONAL=ROOT/'work/124当時特徴の診断/T3追加の切替.json'
POLICIES=('O0','R0','R1','R2','R3','T1','T2','T3')
WIDTHS=(25,50,100,125,200)
HORIZONS=(1800,3600)
AXES=('BBO','Last')


def sha(path: Path) -> str:
    """
    機能: ファイルの全バイト指紋を求める。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def save(path: Path, value: dict) -> None:
    """
    機能: 未作成先へ日本語UTF-8の正本を保存する。
    引数: path(Path)、value(dict)。返り値: None。
    """
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')


# ----------------------------------------
def jst(value: float) -> str:
    """
    機能: 原価格時計をJSTへ変換する。
    引数: value(float)。返り値: str。
    """
    return datetime.fromtimestamp(value,timezone(timedelta(hours=9))).isoformat(sep=' ')


# ----------------------------------------
def selected(record: dict, policy: str, axis: str) -> dict:
    """
    機能: 結果を参照せず固定済みモード又は当時特徴のsideだけで正逆を選ぶ。
    引数: record(dict)、policy(str)、axis(str)。返り値: dictは観測候補。
    """
    case,f=record['case'],record['feature']
    strategy=f['strategy']
    flip=(policy=='R0' or policy=='R1' and strategy!='E0' or policy=='R2' and strategy=='trend' or policy=='R3' and strategy=='deadline')
    if policy in ('T1','T2','T3'):
        side=f['choices'][policy]['side']
        assert side in (-1,1)
        flip=side!=case['original_side']
    key=('chart_' if axis=='Last' else '')+('reverse' if flip else 'original')
    return case[key]


# ----------------------------------------
def observation(candidate: dict, seconds: int) -> dict:
    """
    機能: 固定時間の観測を取り出す。
    引数: candidate(dict)、seconds(int)。返り値: dict。
    """
    return next(o for o in candidate['outcomes'] if o['seconds']==seconds)


# ----------------------------------------
def touch(outcome: dict, width: int) -> dict:
    """
    機能: 指定同幅の最初の到達を取り出す。
    引数: outcome(dict)、width(int)。返り値: dict。
    """
    return next(t for t in outcome['touches'] if t['width']==width)


# ----------------------------------------
def ifd(candidate: dict, outcome: dict, width: int, axis: str) -> dict:
    """
    機能: 到達済みは最初の到達気配、未到達完了は期限気配で清算を代用する。
    引数: candidate/outcome(dict)、width(int)、axis(str)。返り値: dict。未知は金額None。
    """
    t=touch(outcome,width)
    q=t['quote'] if t['direction'] else outcome['endpoint'] if outcome['status']=='complete' else None
    if q is None:
        return {'known':False,'reason':'観測不足','points':None,'net0':None,'net5':None,'exit':None}
    side=candidate['birth']['side']
    mark=q['last'] if axis=='Last' else q['bid'] if side==1 else q['ask']
    points=side*(mark-candidate['entry_price'])
    return {'known':True,'reason':'順行到達' if t['direction']==1 else '逆行到達' if t['direction']==-1 else '期限清算',
            'points':points,'net0':points*100-77 if axis=='BBO' else None,'net5':points*100-1077 if axis=='BBO' else None,'exit':q}


# ----------------------------------------
def stats(records: list[dict], policy: str, axis: str, seconds: int, width: int) -> dict:
    """
    機能: 固定時計の先着と、決済が既知なIFD代用の金額を別の分母で集計する。
    引数: records(list[dict])、policy/axis(str)、seconds/width(int)。返り値: dict。
    """
    candidates=[selected(r,policy,axis) for r in records]
    outcomes=[observation(c,seconds) for c in candidates]
    complete=[o for o in outcomes if o['status']=='complete']
    count=Counter(touch(o,width)['direction'] for o in complete)
    a,b,n=count[1],count[-1],count[0]
    exits=[ifd(c,o,width,axis) for c,o in zip(candidates,outcomes)]
    known=[x for x in exits if x['known']]
    values=[x['net5'] for x in known] if axis=='BBO' else []
    gains=sum(x for x in values if x>0); losses=-sum(x for x in values if x<0)
    return {'entries':len(records),'sessions':len({r['session'] for r in records}),'complete':len(complete),'censored':len(outcomes)-len(complete),
            'forward':a,'adverse':b,'neither':n,'resolved':a+b,'resolved_rate':a/(a+b) if a+b else None,'complete_rate':a/len(complete) if complete else None,
            'target70':a/(a+b)>=.7 if a+b else None,'target70_all':a/len(complete)>=.7 if complete else None,'ifd_known':len(known),'ifd_unknown':len(exits)-len(known),'ifd_exits':dict(Counter(x['reason'] for x in exits)),
            'ifd_net0_sum':sum(x['net0'] for x in known) if axis=='BBO' and known else None,'ifd_net5_sum':sum(values) if values else None,
            'ifd_net5_mean':mean(values) if values else None,'ifd_net5_profit':gains if values else None,'ifd_net5_loss':losses if values else None,
            'ifd_net5_pf':gains/losses if losses else None,'ifd_net5_positive':sum(x>0 for x in values) if axis=='BBO' else None,
            'ifd_points_mean':mean(x['points'] for x in known) if known else None,
            'flips':sum(selected(r,policy,axis)['birth']['side']!=r['case']['original_side'] for r in records)}


# ----------------------------------------
def percentile(values: list[float], probability: float) -> float | None:
    """
    機能: 線形補間で標本の分位値を求める。
    引数: values(list[float])、probability(float)。返り値: float|None。
    """
    if not values:
        return None
    x=sorted(values); p=(len(x)-1)*probability; i=int(p); f=p-i
    return x[i]+f*(x[min(i+1,len(x)-1)]-x[i])


# ----------------------------------------
def bootstrap(records: list[dict], sessions: list[str]) -> dict:
    """
    機能: 主125pt/60分の費用後代用損益とO0差をセッション単位で再標本化する。
    引数: records(list[dict])、sessions(list[str])。返り値: dictは探索内参考95%区間。
    """
    rng=random.Random(124)
    samples=[[rng.randrange(len(sessions)) for _ in sessions] for _ in range(5000)]
    output={}
    for policy in POLICIES:
        sums=defaultdict(float); ns=Counter(); ds=defaultdict(float); dn=Counter()
        for r in records:
            c=selected(r,policy,'BBO'); o=observation(c,3600); e=ifd(c,o,125,'BBO')
            c0=selected(r,'O0','BBO'); e0=ifd(c0,observation(c0,3600),125,'BBO')
            sid=r['session']
            if e['known']:
                sums[sid]+=e['net5']; ns[sid]+=1
            if e['known'] and e0['known']:
                ds[sid]+=e['net5']-e0['net5']; dn[sid]+=1
        vectors=[(sums[s],ns[s],ds[s],dn[s]) for s in sessions]
        means=[]; deltas=[]
        for sample in samples:
            a=b=c=d=0
            for i in sample:
                x=vectors[i]; a+=x[0]; b+=x[1]; c+=x[2]; d+=x[3]
            if b: means.append(a/b)
            if d: deltas.append(c/d)
        output[policy]={'C5平均代用損益95区間':[percentile(means,.025),percentile(means,.975)],
                        'O0との両側既知ペア平均差95区間':[percentile(deltas,.025),percentile(deltas,.975)],
                        '既知IFD数':sum(ns.values()),'両側既知ペア数':sum(dn.values())}
    return {'主条件':[125,3600],'回数':5000,'seed':124,'単位':'全73セッションを復元抽出、1セッション内の例を同時に保持',
            '範囲':'既知73場の探索内・他政策と区分は多重比較未補正。未知期間への有意性ではない。','政策':output}


# ----------------------------------------
def main() -> None:
    """
    機能: 全79組の正逆を検査し、原因区分と事前切替の比較および3CSV値を生成する。
    引数: なし。返り値: None。入力/仮説を変更しない。
    """
    source=RUN/'全73場の正逆結果.json'
    data=json.loads(source.read_text(encoding='utf-8'))
    features=json.loads(FEATURE.read_text(encoding='utf-8'))
    assert features['success'] and features['trial']==124 and features['source_sha256']=='9823c9b3f257d97462f295e696b649d41a10ea538dd816490d70e60b34c4146f'
    previous=json.loads((ROOT/'work/123全場参加の入口比較/全73場の入口結果.json').read_text(encoding='utf-8'))
    fmap={(f['session'],f['id']):f for f in features['features']}
    extra=json.loads(ADDITIONAL.read_text(encoding='utf-8'))
    assert extra['success'] and extra['trial']==124 and extra['source_features_sha256']==sha(FEATURE)
    for item in extra['choices']:
        key=item['session'],item['id']
        assert key in fmap
        fmap[key]['choices']['T3']=item['T3']
    assert all('T3' in f['choices'] for f in fmap.values())
    original={(s['session'],c['birth']['id']):c for s in previous['scenes'] for c in s['candidates'] if c['policy']=='P3' and c['entry']}
    assert data['success'] and data['trial']==124 and len(data['scenes'])==73 and len(fmap)==79
    records=[]; invariant=0
    for scene,oldscene in zip(data['scenes'],previous['scenes']):
        assert scene['session']==oldscene['session'] and scene['success']
        for case in scene['cases']:
            key=scene['session'],case['id']; old=original[key]
            assert case['original_side']==old['birth']['side']
            assert case['original']['entry']==case['reverse']['entry']==old['entry']
            assert case['original']['entry_price']==old['entry_price']
            assert case['original']['outcomes']==old['outcomes']
            assert case['reverse']['birth']['side']==-case['original_side']
            q=old['entry']; assert case['reverse']['entry_price']==(q['bid'] if case['original_side']==1 else q['ask'])
            for name in ('chart_original','chart_reverse'):
                assert case[name]['entry_price']==q['last']
                assert all(o['net0'] is None and o['net5'] is None for o in case[name]['outcomes'])
            for h in HORIZONS:
                a,b=observation(case['original'],h),observation(case['reverse'],h)
                assert a['status']==b['status']
                if a['status']=='complete':
                    assert a['endpoint']==b['endpoint']
                    endpoint=a['endpoint']; cost=(q['ask']-q['bid']+endpoint['ask']-endpoint['bid'])*100
                    assert a['net0']+b['net0']==-cost-154
                    assert a['net5']+b['net5']==-cost-2154
                    invariant+=1
            records.append({'session':scene['session'],'case':case,'feature':fmap[key]})
    assert len(records)==79 and len({r['session'] for r in records})==73
    sessions=[s['session'] for s in data['scenes']]
    aggregate={p:{axis:{str(h):{str(w):stats(records,p,axis,h,w) for w in WIDTHS} for h in HORIZONS} for axis in AXES} for p in POLICIES}
    # ----------------------------------------
    # 原向きと全逆の先着の同時分布を、全H完了分母で保存する。
    matrices={}
    for axis in AXES:
        matrices[axis]={}
        for w in WIDTHS:
            pairs=Counter()
            for r in records:
                a=observation(selected(r,'O0',axis),3600); b=observation(selected(r,'R0',axis),3600)
                if a['status']=='complete' and b['status']=='complete': pairs[(touch(a,w)['direction'],touch(b,w)['direction'])]+=1
            matrices[axis][str(w)]={f'{a}/{b}':pairs[a,b] for a in (-1,0,1) for b in (-1,0,1)}
    groups={}
    bin_keys=sorted({k for r in records for k in r['feature']['bins']})
    for key in ['strategy',*bin_keys]:
        groups[key]={}
        values=sorted({str(r['feature']['strategy'] if key=='strategy' else r['feature']['bins'].get(key,'未知')) for r in records})
        for value in values:
            subset=[r for r in records if str(r['feature']['strategy'] if key=='strategy' else r['feature']['bins'].get(key,'未知'))==value]
            groups[key][value]={'n':len(subset),'BBO':{p:{str(w):stats(subset,p,'BBO',3600,w) for w in (25,100,125)} for p in ('O0','R0')},
                                'Last':{p:{str(w):stats(subset,p,'Last',3600,w) for w in (25,100,125)} for p in ('O0','R0')}}
    result={'成功':True,'試行':124,'主政策':'T1','主幅pt':125,'主時間秒':3600,'全場数':73,'固定取得数':79,
            '元結果SHA256':sha(source),'特徴SHA256':sha(FEATURE),'追加切替SHA256':sha(ADDITIONAL),'原向き123同体':79,'同時点正逆spread恒等式確認数':invariant,
            '集計':aggregate,'原逆同時分布':matrices,'原因区分':groups,'bootstrap':bootstrap(records,sessions),
            '口座収支':False,'IFD実約定':False,'価格参考':'Last軸の金額は全てNone。原板Lastの方向参考であり約定できたとは扱わない。'}
    save(OWN/'集計.json',result)
    # ----------------------------------------
    headers=['試行','政策','価格軸','評価分','同幅pt','取得場数','取得数','反転数','全H完了','観測不足','順行先着','逆行先着','両方未到達','到達済み順行率','全完了順行率','到達済み70%達成','IFD代用既知清算','IFD代用未知','C0代用合計円','C5代用利益円','C5代用損失絶対円','C5代用差引円','C5代用平均円','C5代用PF']
    rows=[]
    for p in POLICIES:
        for axis in AXES:
            for h in HORIZONS:
                for w in WIDTHS:
                    s=aggregate[p][axis][str(h)][str(w)]
                    rows.append([124,p,axis,h/60,w,s['sessions'],s['entries'],s['flips'],s['complete'],s['censored'],s['forward'],s['adverse'],s['neither'],s['resolved_rate'],s['complete_rate'],s['target70'],s['ifd_known'],s['ifd_unknown'],s['ifd_net0_sum'],s['ifd_net5_profit'],s['ifd_net5_loss'],s['ifd_net5_sum'],s['ifd_net5_mean'],s['ifd_net5_pf']])
    # ----------------------------------------
    detail_headers=['試行','セッション','出生ID','入口型','元向き','取得JST','元取得価格','逆取得価格','spread','EMA21距離ATR比','RSI側中心','RSI側増分','Hist側増分ATR比','RVOL','T1選択','T1理由','T2選択','T2理由','125原BBO','125逆BBO','125原Last','125逆Last','25原BBO','25逆BBO','25原Last','25逆Last','原125C5代用円','逆125C5代用円','当時特徴の正本参照']
    detail_rows=[]
    for r in records:
        f=r['feature']; case=r['case']; q=case['original']['entry']
        vals=f['features']
        get=lambda key: vals.get(key,{}).get('value') if vals.get(key,{}).get('known') else None
        labels=[]
        for w in (125,25):
            for axis,p in (('BBO','O0'),('BBO','R0'),('Last','O0'),('Last','R0')):
                o=observation(selected(r,p,axis),3600); t=touch(o,w)
                labels.append(('全H観測不足:' if o['status']!='complete' else '')+('順' if t['direction']==1 else '逆' if t['direction']==-1 else '未到達'))
        a=case['original']; b=case['reverse']
        detail_rows.append([124,r['session'],case['id'],f['strategy'],'買' if case['original_side']==1 else '売',jst(q['time']),a['entry_price'],b['entry_price'],q['ask']-q['bid'],get('last_ema21_atr_signed_5'),get('rsi_center_signed_5'),get('rsi_delta_signed_5'),get('hist_delta_atr_signed_5'),get('rvol5'),f['choices']['T1']['action'],f['choices']['T1']['reason'],f['choices']['T2']['action'],f['choices']['T2']['reason'],*labels,ifd(a,observation(a,3600),125,'BBO')['net5'],ifd(b,observation(b,3600),125,'BBO')['net5'],f"全79例の当時特徴.json:{r['session']}:{case['id']}"])
    # ----------------------------------------
    session_headers=['試行','セッション','取得数','最低1回達成','T1反転数','原125順','原125逆','原125未到達','T1125順','T1125逆','T1125未到達','T1全H観測不足','T1IFD代用既知','T1IFD代用未知','T1C5代用利益円','T1C5代用損失絶対円','T1C5代用既知差引円','T1C5代用既知累計円（口座収支ではない）','累計IFD代用未知数']
    session_rows=[]; cumulative=0; unknown=0
    for sid in sessions:
        subset=[r for r in records if r['session']==sid]; a=stats(subset,'O0','BBO',3600,125); b=stats(subset,'T1','BBO',3600,125)
        if b['ifd_net5_sum'] is not None: cumulative+=b['ifd_net5_sum']
        unknown+=b['ifd_unknown']
        session_rows.append([124,sid,len(subset),bool(subset),b['flips'],a['forward'],a['adverse'],a['neither'],b['forward'],b['adverse'],b['neither'],b['censored'],b['ifd_known'],b['ifd_unknown'],b['ifd_net5_profit'],b['ifd_net5_loss'],b['ifd_net5_sum'],cumulative,unknown])
    tables=[{'name':'正逆比較','headers':headers,'rows':rows},{'name':'入口別診断','headers':detail_headers,'rows':detail_rows},{'name':'全セッション','headers':session_headers,'rows':session_rows}]
    assert all(all(len(row)==len(t['headers']) for row in t['rows']) for t in tables)
    save(OWN/'CSV用の表.json',{'試行':124,'成功':True,'result_sha256':sha(source),'意味':'同じ取得の正逆対照。独立1miniのIFD即時気配清算代用、口座収支と実IFDではない。','tables':tables})
    print(json.dumps({'成功':True,'CSV行数':[len(t['rows']) for t in tables],'主125H60':{p:aggregate[p]['BBO']['3600']['125'] for p in POLICIES},'正逆同時分布':matrices},ensure_ascii=False))


if __name__=='__main__':
    main()
