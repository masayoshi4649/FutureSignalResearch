"""129の技術出生・金融核・事前原文を新Raw走査前に固定する。"""
from pathlib import Path
from datetime import datetime,timezone
import argparse
import hashlib
import json
import subprocess

ROOT=Path(__file__).resolve().parent.parent
OWN=ROOT/'work/129短期回復の評価'
BIRTH=ROOT/'work/129短期回復の出生'
ENGINE=ROOT/'work/129執行区間を限定する評価器'
FORMAL=ROOT/'study/00129_背景方向と短期構造回復で取得を早める'
BACKGROUND=ROOT/'work/128全場のRaw公表/gap300.json.gz'
BASE=ROOT/'work/128Raw時計の評価/gap300入力.json'


def sha(path: Path) -> str:
    """
    機能: ファイル全bytesのSHA256を返す。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def save(path: Path,data: dict) -> None:
    """
    機能: 新規先だけにUTF-8記録を保存する。
    引数: path(Path)、data(dict)。返り値: None。
    """
    with path.open('x',encoding='utf-8',newline='\n') as stream: stream.write(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n')


# ----------------------------------------
def verify(fixed: dict) -> None:
    """
    機能: 先に固定したコード・入力・文書・実行物を照合する。
    引数: fixed(dict)。返り値: None。
    """
    for path,value in fixed['ファイル'].items(): assert sha(Path(path))==value,path


# ----------------------------------------
def main() -> None:
    """
    機能: 出生前F0固定又は金融ラベルを持たない自然出生を行う。
    引数: CLI --mode(str、固定/出生)。返り値: None。
    """
    parser=argparse.ArgumentParser(description='129の出生前固定')
    parser.add_argument('--mode',choices=('固定','出生'),required=True);args=parser.parse_args()
    OWN.mkdir(exist_ok=True)
    if args.mode=='固定':
        assert sha(BACKGROUND)=='e382858a62865b321449279d9653f5b1c644c97f6c4254cbae8dd9d3ea065e62'
        assert sha(BASE)=='474455be28a60248c7418fd69e123297738f6f782648b9c52aab076384e3c384'
        assert sha(BIRTH/'短期回復の出生.exe')=='52d0edb894e802a0ed797222be2316c6059db4601c796298e23a19bef2bd6299'
        assert sha(ENGINE/'独立出生の再生.exe')=='3669ef574eb0feb94780dcd7c6e6ea9182143e768870bc7aa343e168c5560b5e'
        files={Path(__file__).resolve(),BACKGROUND,BASE,ROOT/'work/124入口の原因分析/集計する.py',BIRTH/'短期回復の出生.exe',ENGINE/'独立出生の再生.exe'}
        for folder in (BIRTH,ENGINE,ROOT/'work/129区間限定の短期回復集計',ROOT/'work/129元出生の区間対照集計',ROOT/'work/118複数技法の入口条件',FORMAL):
            files.update(p for p in folder.rglob('*') if p.is_file() and (p.suffix in ('.go','.py','.md') or p.name=='go.mod'))
        fixed={'成功':True,'試行':129,'段階':'出生前F0','UTC':datetime.now(timezone.utc).isoformat(),
               '主':'新C1/C2/C3の最初実取得F0・区間限定・実BBO/H60±125・全73取得＋先着70%',
               '対照':'同限定器へ元643出生の入力を同bytesで渡す。技術変更とphase修正を分離。',
               '金融ラベル新規生成':False,'金融前に追加固定するもの':'生成入力・転記コード・金融実行runner',
               'ファイル':{str(p):sha(p) for p in sorted(files)}}
        save(OWN/'F0.json',fixed);print(json.dumps({'F0':sha(OWN/'F0.json'),'ファイル数':len(files)},ensure_ascii=False));return
    fixed=json.loads((OWN/'F0.json').read_bytes());verify(fixed)
    output=OWN/'出生.json';assert not output.exists()
    command=[str(BIRTH/'短期回復の出生.exe'),'--background',str(BACKGROUND),'--sha256',sha(BACKGROUND),'--output',str(output),'--execute-all']
    subprocess.run(command,cwd=BIRTH,check=True);verify(fixed)
    data=json.loads(output.read_bytes())
    assert data['success'] and data['trial']==129 and not data['financial_labels_used'] and data['raw_passes']==73 and len(data['scenes'])==73
    save(OWN/'出生完了.json',{'成功':True,'出生SHA256':sha(output),'F0_SHA256':sha(OWN/'F0.json'),'出生場':data['birth_sessions'],'出生数':len(data['events']),'前後同体':True,'コマンド':command})
    print(json.dumps({'出生完了':True,'SHA256':sha(output),'出生場':data['birth_sessions'],'出生数':len(data['events'])},ensure_ascii=False))


if __name__=='__main__':
    main()
