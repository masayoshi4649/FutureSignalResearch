/**
 * Rootが確定した三表を、型を照合してCSV三点へ保存する。
 * @param {string[]} process.argv - --input JSON --sha256 期待SHA --output 未作成先。
 * @returns {Promise<void>} CSV、確認JSON、三表の小プレビューを新規保存する。
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {Workbook} from '@oai/artifact-tool';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const NAMES = ['正逆比較', '入口別診断', '全セッション'];
const PREVIEW_WIDTHS = {
  '正逆比較': [160, 60, 130, 90, 110, 110, 110],
  '全セッション': [160, 60, 170, 80, 130, 170, 100],
  '入口別診断': [160, 60, 160, 150, 80, 100, 150],
};
const ERROR = /^(#REF!|#DIV\/0!|#VALUE!|#NAME\?|#N\/A|#NUM!|#NULL!|#SPILL!|#CALC!)/;

/**
 * bytes又はUTF-8文字列の指紋を返す。
 * @param {Uint8Array|string} value - 検査対象。
 * @returns {string} SHA256の16進表記。
 */
function sha(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

/**
 * 三つの明示CLI引数だけを受け取る。
 * @param {string[]} argv - 引数列。
 * @returns {{input:string, expected:string, output:string}} 解決済みの入出力。
 */
function argumentsFor(argv) {
  const fields = {};
  for (let i = 0; i < argv.length; i += 2) {
    assert.ok(['--input', '--sha256', '--output'].includes(argv[i]), '不明な引数');
    assert.ok(argv[i + 1] && fields[argv[i]] === undefined, '値不足又は重複引数');
    fields[argv[i]] = argv[i + 1];
  }
  assert.equal(Object.keys(fields).length, 3, 'JSON/SHA/新規先を指定');
  assert.match(fields['--sha256'], /^[a-f0-9]{64}$/);
  return {input: path.resolve(fields['--input']), expected: fields['--sha256'], output: path.resolve(fields['--output'])};
}

/**
 * JSON三表の形と、セルの有限型を検査する。
 * @param {object} data - tablesを持つ入力JSON。
 * @returns {Array<object>} 元の順序と値を保持した三表。
 */
function validate(data) {
  assert.ok(data && Array.isArray(data.tables) && data.tables.length === 3, 'tablesは三表');
  assert.deepEqual(data.tables.map(t => t.name).sort(), [...NAMES].sort(), '三表の本名');
  for (const table of data.tables) {
    assert.ok(Array.isArray(table.headers) && table.headers.length > 0, 'ヘッダ不足');
    assert.ok(table.headers.every(v => typeof v === 'string'), 'ヘッダは文字列');
    assert.equal(new Set(table.headers).size, table.headers.length, 'ヘッダ重複');
    assert.ok(Array.isArray(table.rows), 'rowsは配列');
    for (const row of table.rows) {
      assert.ok(Array.isArray(row) && row.length === table.headers.length, '行列数不整合');
      for (const value of row) {
        assert.ok(value === null || ['string', 'number', 'boolean'].includes(typeof value), 'セル型不正');
        if (typeof value === 'number') {
          assert.ok(Number.isFinite(value), '非有限数値');
          if (Number.isInteger(value)) assert.ok(Number.isSafeInteger(value), '安全整数範囲外');
        }
      }
    }
  }
  return data.tables;
}

/**
 * 式に見える文字と引用符先頭の文字を、Workbookの文字値として投入する。
 * @param {string|number|boolean|null} value - JSONの型付きセル。
 * @returns {string|number|boolean|null} 文書化された単一引用符エスケープを付けた値。
 */
function literal(value) {
  return typeof value === 'string' && /^[=']/.test(value) ? "'" + value : value;
}

/**
 * Workbook全セルを元JSONの型と値へ照合する。
 * @param {Array<Array<unknown>>} actual - エンジン再計算後の値。
 * @param {Array<Array<string|number|boolean|null>>} expected - 元のヘッダと全行。
 * @returns {{rows:Array<Array<unknown>>, cells:number, nulls:number, literalErrors:number}} 検算済み表。
 */
function compare(actual, expected) {
  assert.equal(actual.length, expected.length);
  const rows = []; let cells = 0, nulls = 0, literalErrors = 0;
  for (let i = 0; i < expected.length; i++) {
    assert.equal(actual[i].length, expected[i].length);
    const row = [];
    for (let j = 0; j < expected[i].length; j++) {
      const want = expected[i][j]; let got = actual[i][j];
      if (want === null) {
        assert.ok(got === null || got === '' || got === undefined, `空欄 ${i}/${j}`);
        got = null; nulls++;
      } else {
        if (want === '' && (got === null || got === undefined)) got = '';
        if (typeof want === 'string' && /^[=']/.test(want) && got === "'" + want) got = got.slice(1);
        assert.equal(typeof got, typeof want, `型 ${i}/${j}`);
        assert.ok(got === want, `値 ${i}/${j}: ${String(got)} / ${String(want)}`);
        if (typeof got === 'string' && ERROR.test(got)) literalErrors++;
      }
      row.push(got); cells++;
    }
    rows.push(row);
  }
  return {rows, cells, nulls, literalErrors};
}

/**
 * CSVの一セルを引用し、nullを空欄として返す。
 * @param {string|number|boolean|null} value - 検算済みの値。
 * @returns {string} RFC4180のセル。booleanは小文字true/false。
 */
function field(value) {
  const text = value === null ? '' : String(value);
  return /[",\r\n]/.test(text) ? '"' + text.replaceAll('"', '""') + '"' : text;
}

/**
 * 見本の幅だけに使う文字の概算pxを返す。
 * @param {unknown} value - セル表示値。
 * @returns {number} 列幅の候補px。
 */
function width(value) {
  return [...String(value ?? '')].reduce((total, c) => total + (c.codePointAt(0) > 129 ? 14 : 7), 20);
}

// ----------------------------------------
// 数値の意味や金融集計はRootの三表を保持し、このbuilderでは再定義しない。
const args = argumentsFor(process.argv.slice(2));
assert.equal(process.version, 'v24.22.1', '固定Node版');
const packagePath = path.join(HERE, 'node_modules', '@oai', 'artifact-tool', 'package.json');
const packageBytes = await fs.readFile(packagePath);
assert.equal(JSON.parse(packageBytes).version, '2.8.129', '固定artifact-tool版');
try { await fs.lstat(args.output); throw new Error('既存出力先は使用禁止'); }
catch (error) { if (error.code !== 'ENOENT') throw error; }
const inputBytes = await fs.readFile(args.input);
assert.equal(sha(inputBytes), args.expected, '入力SHA256');
const tables = validate(JSON.parse(inputBytes.toString('utf8').replace(/^\uFEFF/, '')));
const workbook = Workbook.create();
const entries = [];
for (const table of tables) {
  const sheet = workbook.worksheets.add(table.name);
  const original = [table.headers, ...table.rows];
  sheet.getRangeByIndexes(0, 0, original.length, table.headers.length).values = original.map(row => row.map(literal));
  sheet.showGridLines = false;
  const previewRows = Math.min(5, original.length), previewColumns = Math.min(7, table.headers.length);
  const preview = sheet.getRangeByIndexes(0, 0, previewRows, previewColumns);
  preview.format.font = {name: 'Arial', size: 10};
  preview.format.verticalAlignment = 'center';
  preview.format.wrapText = true;
  sheet.getRangeByIndexes(0, 0, 1, previewColumns).format = {
    fill: '#334155', font: {name: 'Arial', size: 10, bold: true, color: '#FFFFFF'},
    horizontalAlignment: 'center', verticalAlignment: 'center', wrapText: true,
  };
  for (let j = 0; j < previewColumns; j++) {
    sheet.getRangeByIndexes(0, j, previewRows, 1).format.columnWidthPx = PREVIEW_WIDTHS[table.name][j];
  }
  preview.format.autofitRows();
  sheet.getRangeByIndexes(0, 0, 1, previewColumns).format.rowHeight = 48;
  entries.push({table, sheet, original, previewRows, previewColumns});
}
workbook.recalculate();
const outputs = {}, proofs = [], images = [];
for (const entry of entries) {
  const {table, sheet, original, previewRows, previewColumns} = entry;
  const range = sheet.getRangeByIndexes(0, 0, original.length, table.headers.length);
  const checked = compare(range.values, original);
  const formulas = range.formulas;
  assert.ok(formulas.flat().every(v => v === null || v === '' || v === undefined), 'JSONの文字を数式へ変換しない');
  const inspected = await workbook.inspect({kind: 'table',
    range: `${table.name}!A1:${String.fromCharCode(64 + previewColumns)}${previewRows}`,
    include: 'values,formulas', tableMaxRows: 5, tableMaxCols: 8, maxChars: 2400});
  const body = '\uFEFF' + checked.rows.map(row => row.map(field).join(',')).join('\r\n') + '\r\n';
  outputs[table.name + '.csv'] = {body, sha256: sha(body), データ行数: table.rows.length, 列数: table.headers.length};
  const image = await workbook.render({sheetName: table.name,
    range: `A1:${String.fromCharCode(64 + previewColumns)}${previewRows}`, scale: 1, format: 'png'});
  images.push({name: table.name + '.png', body: new Uint8Array(await image.arrayBuffer())});
  proofs.push({表: table.name, 全セル比較: checked.cells, null数: checked.nulls,
    入力どおりのエラー表示文字列数: checked.literalErrors, 数式数: 0, inspect: inspected.ndjson});
}
const errors = await workbook.inspect({kind: 'match',
  searchTerm: '#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',
  options: {useRegex: true, maxResults: 10}, maxChars: 1800});
assert.equal(sha(await fs.readFile(args.input)), args.expected, '保存前の入力不変');
assert.equal(sha(await fs.readFile(packagePath)), sha(packageBytes), '依存package不変');
await fs.mkdir(args.output, {recursive: false});
for (const [name, value] of Object.entries(outputs)) {
  await fs.writeFile(path.join(args.output, name), value.body, {encoding: 'utf8', flag: 'wx'});
  assert.equal(sha(await fs.readFile(path.join(args.output, name))), value.sha256, '保存bytes');
  delete value.body;
}
const support = path.join(args.output, '支援画像'); await fs.mkdir(support, {recursive: false});
for (const image of images) await fs.writeFile(path.join(support, image.name), image.body, {flag: 'wx'});
assert.equal(sha(await fs.readFile(args.input)), args.expected, '保存後の入力不変');
const proof = {成功: true, 試行: 129, 入力: args.input, 入力SHA256: args.expected, 入力前後不変: true,
  評価単位: '同入口の正逆BBO対照・独立1miniのIFD代用/期限評価。実IFD又は運用口座収支へ合算しない',
  出力: outputs, 表の確認: proofs, エラー走査: errors.ndjson,
  エラー検査: '全セルを元JSON型/値へ照合、数式0。入力自身の同一エラー文字列は文字として保持',
  null: '空欄、0は0。空文字とnullはCSV表現上は区別不能',
  実行環境: {node: process.version, node_path: process.execPath, artifact_tool: '2.8.129', package_sha256: sha(packageBytes)},
  コードSHA256: sha(await fs.readFile(fileURLToPath(import.meta.url))),
  操作marker: '自動実行なし。Rootが自然first authoring直前にcreate/3/csvを1回実行',
  金融再計算: false, xlsx生成: false, プレビュー: images.map(v => '支援画像/' + v.name)};
await fs.writeFile(path.join(args.output, 'CSVの確認.json'), JSON.stringify(proof, null, 2) + '\n', {flag: 'wx'});
console.log(JSON.stringify({成功: true, 出力先: args.output, 出力: outputs}));
