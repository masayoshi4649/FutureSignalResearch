"""機能: 正逆再生の算術と主要集計をRoot集計関数なしで独立照合する。

引数: --result/--result-sha は許可済み結果、--aggregate/--aggregate-sha は集計、--output は新規保存先。
返り値: なし。成功時は指紋付き検算JSONを保存する。
"""

import argparse
import hashlib
import json
import math
from collections import Counter
from fractions import Fraction
from pathlib import Path

POLICIES = ("O0", "R0", "R1", "R2", "R3", "T1", "T2", "T3")
WIDTHS = (25, 50, 100, 125, 200)
HORIZONS = (1800, 3600)
AXES = ("BBO", "Last")


def sha(path: Path) -> str:
    """機能: ファイルのSHA256を求める。

    引数: path (Path) は対象ファイル。
    返り値: str は小文字16進表記。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def equal(actual, expected, location: str) -> None:
    """機能: 未知・型・有限数値を区別して照合する。

    引数: actual/expected (object) は比較値、location (str) は位置。
    返り値: None。不一致はAssertionError。
    """
    if expected is None or isinstance(expected, bool):
        assert type(actual) is type(expected) and actual == expected, (location, actual, expected)
    elif isinstance(expected, (int, float)):
        assert isinstance(actual, (int, float)) and not isinstance(actual, bool) and math.isfinite(actual), (location, actual)
        assert math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-8), (location, actual, expected)
    else:
        assert actual == expected, (location, actual, expected)


def observation(candidate: dict, seconds: int) -> dict:
    """機能: 固定期限の観測を一意に取り出す。

    引数: candidate (dict) は観測候補、seconds (int) は期限秒数。
    返り値: dict は一致した観測。
    """
    matches = [o for o in candidate["outcomes"] if o["seconds"] == seconds]
    assert len(matches) == 1
    return matches[0]


def touch(outcome: dict, width: int) -> dict:
    """機能: 同幅の先着票を一意に取り出す。

    引数: outcome (dict) は期限観測、width (int) は同幅pt。
    返り値: dict は一致した先着票。
    """
    matches = [t for t in outcome["touches"] if t["width"] == width]
    assert len(matches) == 1
    return matches[0]


def points(candidate: dict, quote: dict, axis: str) -> int | float:
    """機能: その向きの清算価格から値幅を算出する。

    引数: candidate/quote (dict) は候補と気配、axis (str) はBBO又はLast。
    返り値: int | float は元取得価格からの符号付きpt。
    """
    side = candidate["birth"]["side"]
    mark = quote["last"] if axis == "Last" else quote["bid"] if side > 0 else quote["ask"]
    return side * (mark - candidate["entry_price"])


def quote_valid(quote: dict, entry: dict) -> None:
    """機能: 保存された観測気配の価格・順序を照合する。

    引数: quote/entry (dict) は観測と取得の原行。
    返り値: None。不適格はAssertionError。
    """
    assert quote["quote_ok"] and 0 < quote["bid"] <= quote["ask"] and quote["last"] > 0
    assert all(math.isfinite(quote[k]) for k in ("time", "last", "bid", "ask"))
    assert quote["index"] > entry["index"] and quote["source_line"] > entry["source_line"]
    assert quote["time"] >= entry["time"]


def ifd_value(candidate: dict, horizon: int, width: int, axis: str) -> dict:
    """機能: 先着済みは打切り後も保持し、未到達完了だけ期限清算を使う。

    引数: candidate (dict)、horizon/width (int)、axis (str) は候補・期限・同幅・価格軸。
    返り値: dict は代用清算の既知、理由、pt、費用後金額。
    """
    o = observation(candidate, horizon)
    t = touch(o, width)
    if t["direction"] != 0:
        q, reason = t["quote"], "順行到達" if t["direction"] > 0 else "逆行到達"
    elif o["status"] == "complete":
        q, reason = o["endpoint"], "期限清算"
    else:
        return {"known": False, "reason": "観測不足", "points": None, "net0": None, "net5": None}
    assert q is not None
    p = points(candidate, q, axis)
    return {"known": True, "reason": reason, "points": p,
            "net0": p * 100 - 77 if axis == "BBO" else None,
            "net5": p * 100 - 1077 if axis == "BBO" else None}


def pick(record: dict, policy: str, axis: str) -> dict:
    """機能: 固定政策又は凍結したchoicesだけで向きを選ぶ。

    引数: record (dict) はcase/feature、policy/axis (str) は政策と価格軸。
    返り値: dict は選択した候補。勝敗を判定に使わない。
    """
    case, feature = record["case"], record["feature"]
    mode = feature["strategy"]
    side = case["original_side"]
    if policy in ("T1", "T2", "T3"):
        side = feature["choices"][policy]["side"]
    elif policy == "R0" or policy == "R1" and mode != "E0" or policy == "R2" and mode == "trend" or policy == "R3" and mode == "deadline":
        side = -side
    assert side in (-1, 1)
    key = ("chart_" if axis == "Last" else "") + ("original" if side == case["original_side"] else "reverse")
    return case[key]


def independent_stats(records: list[dict], policy: str, axis: str, horizon: int, width: int) -> dict:
    """機能: 整数件数とFractionから率・代用利益/損失・PFを集計する。

    引数: records (list[dict])、policy/axis (str)、horizon/width (int) は全例・政策・価格軸・時計・同幅。
    返り値: dict はRoot集計から独立した主要数値。
    """
    selected = [pick(r, policy, axis) for r in records]
    complete = [observation(c, horizon) for c in selected if observation(c, horizon)["status"] == "complete"]
    directions = Counter(touch(o, width)["direction"] for o in complete)
    forward, adverse, neither = directions[1], directions[-1], directions[0]
    resolved = forward + adverse
    exits = [ifd_value(c, horizon, width, axis) for c in selected]
    known = [x for x in exits if x["known"]]
    values = [x["net5"] for x in known] if axis == "BBO" else []
    profit = sum(v for v in values if v > 0)
    loss = -sum(v for v in values if v < 0)
    mean_points = float(Fraction(sum(x["points"] for x in known)) / len(known)) if known else None
    return {
        "entries": len(records), "sessions": len({r["session"] for r in records}),
        "complete": len(complete), "censored": len(selected) - len(complete),
        "forward": forward, "adverse": adverse, "neither": neither, "resolved": resolved,
        "resolved_rate": float(Fraction(forward, resolved)) if resolved else None,
        "complete_rate": float(Fraction(forward, len(complete))) if complete else None,
        "target70": Fraction(forward, resolved) >= Fraction(7, 10) if resolved else None,
        "target70_all": Fraction(forward, len(complete)) >= Fraction(7, 10) if complete else None,
        "ifd_known": len(known), "ifd_unknown": len(exits) - len(known),
        "ifd_exits": dict(Counter(x["reason"] for x in exits)),
        "ifd_net0_sum": sum(x["net0"] for x in known) if axis == "BBO" and known else None,
        "ifd_net5_sum": sum(values) if values else None,
        "ifd_net5_mean": float(Fraction(sum(values)) / len(values)) if values else None,
        "ifd_net5_profit": profit if values else None, "ifd_net5_loss": loss if values else None,
        "ifd_net5_pf": float(Fraction(profit) / Fraction(loss)) if loss else None,
        "ifd_net5_positive": sum(v > 0 for v in values) if axis == "BBO" else None,
        "ifd_points_mean": mean_points,
        "flips": sum(c["birth"]["side"] != r["case"]["original_side"] for c, r in zip(selected, records)),
    }


def main() -> None:
    """機能: 許可された固定結果と集計を指紋化して独立照合を実行する。

    引数: コマンドラインのPath/SHA文字列。
    返り値: None。未作成の--outputへ検算証跡を保存する。
    """
    parser = argparse.ArgumentParser()
    for name in ("result", "aggregate"):
        parser.add_argument(f"--{name}", type=Path, required=True)
        parser.add_argument(f"--{name}-sha", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    paths = {
        args.result: args.result_sha, args.aggregate: args.aggregate_sha,
        root / "work/123全場参加の入口比較/全73場の入口結果.json": "9823c9b3f257d97462f295e696b649d41a10ea538dd816490d70e60b34c4146f",
        root / "work/124当時特徴の診断/全79例の当時特徴.json": "e4f0bf25156c1fe732b186c5c5d90b6e9f95718985a440d8eb7005588f734774",
        root / "work/124当時特徴の診断/T3追加の切替.json": "656072b82b66564473d81aa96d4fe7dbc04ed97cfac982edc0d3b206baff7382",
        root / "work/124入口の原因分析/再生前固定.json": "7fdfbf3b8ef9166d7bcaf0b5503a711f6a808dcba718e67c951fe627f71210d3",
    }
    before = {str(p.resolve()): sha(p) for p in (*paths, Path(__file__).resolve())}
    assert all(before[str(p.resolve())] == expected for p, expected in paths.items())
    data = json.loads(args.result.read_text(encoding="utf-8-sig"))
    aggregate = json.loads(args.aggregate.read_text(encoding="utf-8-sig"))
    baseline = json.loads(list(paths)[2].read_text(encoding="utf-8-sig"))
    features = json.loads(list(paths)[3].read_text(encoding="utf-8-sig"))
    additional = json.loads(list(paths)[4].read_text(encoding="utf-8-sig"))
    f1 = json.loads(list(paths)[5].read_text(encoding="utf-8-sig"))
    assert data["success"] and data["trial"] == 124 and aggregate["成功"]
    assert aggregate["主政策"] == f1["主政策"] == "T1" and aggregate["主幅pt"] == 125 and aggregate["主時間秒"] == 3600
    assert aggregate["元結果SHA256"] == args.result_sha and aggregate["特徴SHA256"] == paths[list(paths)[3]]
    assert aggregate["追加切替SHA256"] == paths[list(paths)[4]]
    assert data["input_sha256"] == next(v for k, v in f1["入力"].items() if k.endswith("124入口の原因分析\\入力.json"))
    assert len(data["scenes"]) == len(baseline["scenes"]) == 73
    fmap = {(r["session"], r["id"]): r for r in features["features"]}
    assert len(fmap) == 79
    for row in additional["choices"]:
        assert (row["session"], row["id"]) in fmap
        fmap[row["session"], row["id"]]["choices"]["T3"] = row["T3"]
    counts, records = Counter(), []
    for scene, oldscene in zip(data["scenes"], baseline["scenes"]):
        assert scene["success"] and scene["session"] == oldscene["session"]
        for key in ("raw", "actual_sha256", "raw_encoding", "quality", "expected_quality"):
            equal(scene[key], oldscene[key], f"場:{scene['session']}:{key}")
        assert scene["quality"] == scene["expected_quality"] and scene["stat_before"] == scene["stat_after"]
        old = {c["birth"]["id"]: c for c in oldscene["candidates"] if c["policy"] == "P3" and c["status"] == "filled"}
        assert [c["id"] for c in scene["cases"]] == list(old)
        assert scene["source_entries"] == len(scene["cases"]) > 0
        for case in scene["cases"]:
            c0 = old[case["id"]]
            side, q0 = c0["birth"]["side"], c0["entry"]
            assert case["original_side"] == side
            assert case["original"]["outcomes"] == c0["outcomes"]
            assert case["original"]["entry_price"] == c0["entry_price"]
            counts["原方向123同体"] += 1
            record = {"session": scene["session"], "case": case, "feature": fmap[scene["session"], case["id"]]}
            assert record["feature"]["original_side"] == side
            records.append(record)
            for name in ("original", "reverse", "chart_original", "chart_reverse"):
                c = case[name]
                axis = "Last" if name.startswith("chart_") else "BBO"
                expected_side = -side if name.endswith("reverse") else side
                assert c["status"] == "filled" and c["birth"]["side"] == expected_side and c["entry"] == q0
                assert c["birth"]["time"] == q0["time"] and c["birth"]["index"] == q0["index"] and c["birth"]["source_line"] == q0["source_line"]
                expected_price = q0["last"] if axis == "Last" else q0["ask"] if expected_side > 0 else q0["bid"]
                assert c["entry_price"] == expected_price
                assert len(c["outcomes"]) == 2
                for h in HORIZONS:
                    o = observation(c, h)
                    assert o["deadline"] == q0["time"] + h and len(o["touches"]) == 5
                    for w in WIDTHS:
                        t = touch(o, w)
                        assert t["direction"] in (-1, 0, 1)
                        if t["direction"] == 0:
                            assert t["quote"] is None
                        else:
                            qt = t["quote"]
                            quote_valid(qt, q0)
                            assert qt["time"] <= o["deadline"]
                            gain = points(c, qt, axis)
                            assert gain >= w if t["direction"] == 1 else gain <= -w
                            counts["先着幾何"] += 1
                            if o["status"] != "complete":
                                assert ifd_value(c, h, w, axis)["known"]
                                counts["打切り後も既知touch清算を保持"] += 1
                    if o["status"] == "complete":
                        qe = o["endpoint"]
                        quote_valid(qe, q0)
                        assert o["deadline"] <= qe["time"] <= o["deadline"] + 30
                        gain = points(c, qe, axis)
                        equal(o["points"], gain, "期限pt")
                        equal(o["net0"], gain * 100 - 77 if axis == "BBO" else None, "期限C0")
                        equal(o["net5"], gain * 100 - 1077 if axis == "BBO" else None, "期限C5")
                        counts["期限算術"] += 1
                    else:
                        assert o["endpoint"] is None and o["points"] is None and o["net0"] is None and o["net5"] is None
                        counts["打切りnil"] += 1
                    if axis == "Last":
                        assert o["net0"] is None and o["net5"] is None
                        counts["Last金額nil"] += 1
            for h in HORIZONS:
                oo = [observation(case[n], h) for n in ("original", "reverse", "chart_original", "chart_reverse")]
                assert len({o["status"] for o in oo}) == 1 and all(o["endpoint"] == oo[0]["endpoint"] for o in oo)
                if oo[0]["status"] == "complete":
                    qe = oo[0]["endpoint"]
                    spread_sum = q0["ask"] - q0["bid"] + qe["ask"] - qe["bid"]
                    equal(oo[0]["points"] + oo[1]["points"], -spread_sum, "正逆spread恒等式pt")
                    equal(oo[0]["net5"] + oo[1]["net5"], -spread_sum * 100 - 2154, "正逆spread恒等式C5")
                    equal(oo[2]["points"], -oo[3]["points"], "Last正逆鏡像")
                    counts["spread恒等式"] += 1
                for w in WIDTHS:
                    ca, cb = touch(oo[2], w), touch(oo[3], w)
                    assert ca["direction"] == -cb["direction"] and ca["quote"] == cb["quote"]
    assert len(records) == len({(r['session'], r['case']['id']) for r in records}) == 79
    assert len({r["session"] for r in records}) == 73
    all_stats = {}
    for policy in POLICIES:
        all_stats[policy] = {}
        for axis in AXES:
            all_stats[policy][axis] = {}
            for h in HORIZONS:
                all_stats[policy][axis][str(h)] = {}
                for w in WIDTHS:
                    stats = independent_stats(records, policy, axis, h, w)
                    expected = aggregate["集計"][policy][axis][str(h)][str(w)]
                    assert set(expected) == set(stats)
                    for key, value in stats.items():
                        equal(expected[key], value, f"{policy}/{axis}/{h}/{w}/{key}")
                        counts["集計値照合"] += 1
                    all_stats[policy][axis][str(h)][str(w)] = stats
    for name in ("T1", "T2"):
        assert all_stats[name] == all_stats["O0"]
    assert all_stats["T3"]["BBO"]["3600"]["125"]["flips"] == 1
    matrices = {}
    for axis in AXES:
        matrices[axis] = {}
        for w in WIDTHS:
            pairs = Counter()
            for record in records:
                a, b = (observation(pick(record, p, axis), 3600) for p in ("O0", "R0"))
                if a["status"] == b["status"] == "complete":
                    pairs[touch(a, w)["direction"], touch(b, w)["direction"]] += 1
            matrix = {f"{a}/{b}": pairs[a, b] for a in (-1, 0, 1) for b in (-1, 0, 1)}
            assert matrix == aggregate["原逆同時分布"][axis][str(w)]
            matrices[axis][str(w)] = matrix
    assert aggregate["原向き123同体"] == counts["原方向123同体"] == 79
    assert aggregate["同時点正逆spread恒等式確認数"] == counts["spread恒等式"]
    after = {str(p.resolve()): sha(p) for p in (*paths, Path(__file__).resolve())}
    assert before == after
    summary = {p: {a: {str(w): all_stats[p][a]["3600"][str(w)] for w in (25, 100, 125)} for a in AXES} for p in POLICIES}
    output = {"成功": True, "試行": 124, "主条件": ["T1", 3600, 125], "全場数": 73, "全例数": 79,
              "前SHA256": before, "後SHA256": after, "前後不変": True, "検査件数": dict(counts),
              "全政策軸期限幅の集計組数": 160, "60分の主要幅": summary, "正逆同時分布": matrices,
              "Root集計import": False, "率PF計算": "整数件数とFraction", "Raw再読": False,
              "限界": ["Raw先着最初性と欠測時計を新たに再走査しない", "bootstrap区間・全原因bin・実CSVセルは本独立検算の範囲外", "気配清算代用はIFDの注文実約定又は口座収支ではない"]}
    with args.output.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(output, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"成功": True, "出力SHA256": sha(args.output), "検査件数": dict(counts),
                      "主T1": summary["T1"]["BBO"]["125"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
