"""機能: 新3系列とphase全票照合の境界を人工で検査する。

引数: なし。自作128人工fixtureだけを再用する。
返り値: なし。人工検査.jsonを新規保存する。自然結果を開かない。
"""
import copy
import hashlib
import importlib.util
import json
import unittest
from pathlib import Path

BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[1]


def module(path: Path, name: str) -> object:
    """機能: 読取副作用のない自作コードを読み込む。

    引数: path (Path)、name (str) はソースとモジュール名。
    返り値: object は読み込んだモジュール。
    """
    spec=importlib.util.spec_from_file_location(name,path);out=importlib.util.module_from_spec(spec);spec.loader.exec_module(out)
    return out


target=module(BASE/'独立集計する.py','独立129人工対象')
fixture=module(ROOT/'work/128Raw時計の独立検算/人工検査.py','自作128人工生成')
helper=target.load_helper()


def sample() -> dict:
    """機能: 各幅の既知touchだけを持つ人工の正逆BBO/Lastを作る。

    引数: なし。
    返り値: dict はH不足でもtouchを保持した人工ケース。
    """
    q=fixture.quote(100,1,2)
    case={k:fixture.candidate(q,s,chart) for k,s,chart in (('original',1,False),('reverse',-1,False),('chart_original',1,True),('chart_reverse',-1,True))}
    for c in case.values():
        for o in c['outcomes']:
            o.update({'status':'phase_censored','endpoint':None,'points':None,'net0':None,'net5':None})
    return case


class Artificial129(unittest.TestCase):
    """機能: 新規選択順・執行終端・全0ケースを検査する。

    引数: unittestが生成する。
    返り値: 各検査はNone又は失敗。
    """
    def test_priority_and_whole_raw_tie(self) -> None:
        """機能: C1→C3→C2と同Raw全見送りを検査する。

        引数: self (Artificial129)。返り値: None。
        """
        def row(name: str, mode: str, at: int, side: int=1) -> dict:
            """機能: 人工選択票を作る。

            引数: name/mode (str)、at/side (int)。返り値: dict。
            """
            return {'mode':mode,'risk':10,'case':{'id':name,'original_side':side,'original':{'entry':fixture.quote(at,at,at+1)}}}
        order=('C1','C3','C2');a=row('一','C1',100);b=row('三','C3',100);c=row('二','C2',100)
        self.assertIs(target.first([c,b,a],priority=order),a)
        self.assertIs(target.first([c,b],priority=order),b)
        early=row('早い二','C2',99)
        self.assertIs(target.first([a,early],priority=order),early)
        tie=row('反対一','C1',100,-1);next_row=row('次の二','C2',101)
        self.assertIs(target.first([a,tie,b,next_row],priority=order),next_row)

    def test_touch_boundary_and_known_retained(self) -> None:
        """機能: 終端前の既知touchを保持し、等号以降の保存票を拒否する。

        引数: self (Artificial129)。返り値: None。
        """
        case=sample();counts=target.phase_observations(case,500,helper)
        self.assertEqual((counts['H票'],counts['既知touch票'],counts['phase_censored']),(8,40,8))
        for at in (500,501):
            bad=copy.deepcopy(case);bad['original']['outcomes'][0]['touches'][3]['quote']['time']=at
            with self.assertRaises(AssertionError):target.phase_observations(bad,500,helper)

    def test_endpoint_equal_boundary_refused(self) -> None:
        """機能: H完了の期限が終端と等しい場合も清算票を拒否する。

        引数: self (Artificial129)。返り値: None。
        """
        entry=fixture.quote(100,1,2)
        case={k:fixture.candidate(entry,s,chart) for k,s,chart in (('original',1,False),('reverse',-1,False),('chart_original',1,True),('chart_reverse',-1,True))}
        with self.assertRaises(AssertionError):target.phase_observations(case,3700,helper)
        for c in case.values():c['outcomes'][1].update({'status':'phase_censored','endpoint':None,'points':None,'net0':None,'net5':None})
        self.assertEqual(target.phase_observations(case,3700,helper)['完了endpoint票'],4)

    def test_empty_73_new_series(self) -> None:
        """機能: 全0出生を120比較と73場へ残す。

        引数: self (Artificial129)。返り値: None。
        """
        data,source,aggregate=fixture.fixture(False);data['trial']=129
        for actual,original in zip(data['scenes'],source['scenes']):
            actual.update({'execution_end':original['end']-300,'source_force_close':original['force_close'],
                           'effective_force_close':min(original['force_close'],original['end']-420)})
        policies=('F0','FR','A0','P1','P2','P3')
        aggregate['政策取得ID']={p:[] for p in policies}
        aggregate['coverage']={p:copy.deepcopy(aggregate['coverage']['F0']) for p in policies}
        aggregate['集計']={p:copy.deepcopy(aggregate['集計']['F0']) for p in policies}
        out=target.audit(data,source,aggregate,helper,'new')
        self.assertEqual((out['全出生'],out['全取得'],out['比較組数'],out['集計値照合数']),(0,0,120,2980))
        self.assertEqual(len(out['coverage']['F0']['empty_sessions']),73)


if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Artificial129))
    assert result.wasSuccessful()
    out={'成功':True,'試行':129,'人工主検査':result.testsRun,'自然結果読取':False,
         'ファイルSHA256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (BASE/'独立集計する.py',Path(__file__).resolve())}}
    with (BASE/'人工検査.json').open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(out,ensure_ascii=False))
