"""129の結果後独立検算と保管補助を、研究F0/F1源と区別して保存する。"""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT=Path(__file__).resolve().parents[2]
F=ROOT/'study/00129_背景方向と短期構造回復で取得を早める'


def sha(body: bytes) -> str:
    """
    機能: bytesのSHAを返す。
    引数: body(bytes)。返り値: str。
    """
    return hashlib.sha256(body).hexdigest()


def copy(source: Path,target: Path) -> None:
    """
    機能: 小型証跡の同体copyを行う。
    引数: source/target(Path)。返り値: None。
    """
    assert not target.exists(),str(target)
    shutil.copyfile(source,target)
    assert sha(source.read_bytes())==sha(target.read_bytes())


def main() -> None:
    """
    機能: 停止済み検算器/証跡と現行保管補助を恒久保存する。
    引数: なし。返り値: None。
    """
    own=ROOT/'work/129独立検算'
    for name,target in [('新入口の独立検算.json','新入口の独立検算.json'),('元出生の独立検算.json','元出生の独立検算.json'),('完了.json','独立検算完了.json'),('人工検査.json','独立検算の人工検査.json')]:copy(own/name,F/'検査'/target)
    for source,target in [(ROOT/'work/129短期回復CSV出力/独立再読の確認.json','CSVの独立再読.json'),(ROOT/'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/129短期回復CSV/CSVの確認.json','CSVの生成確認.json'),(ROOT/'work/129独立準備レビュー/区間限定の独立確認.json','執行区間の独立準備.json')]:copy(source,F/'検査'/target)
    text=(own/'README.md').read_text(encoding='utf-8').replace('[独立集計する.py](独立集計する.py)','[独立集計する.py（追補コード）](../再現資料/検算と保管の追補コード.zip)').replace('[人工検査.py](人工検査.py)','[人工検査.py（追補コード）](../再現資料/検算と保管の追補コード.zip)')
    (F/'検査/独立検算の短報.md').write_text(text,encoding='utf-8')
    files=[own/'独立集計する.py',own/'人工検査.py',ROOT/'work/124正逆の独立検算/検算する.py',ROOT/'work/129正式保存/結果を記す.py',Path(__file__).resolve(),F/'再現資料/保存資料を復元する.py']
    items=[{'path':p.relative_to(ROOT).as_posix(),'phase':'結果後の独立検算/保管補助。金融F0/F1源ではない。','bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in files]
    path=F/'再現資料/検算と保管の追補コード.zip'
    with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in files:z.writestr(p.relative_to(ROOT).as_posix(),p.read_bytes())
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        for item in items:assert sha(z.read(item['path']))==item['sha256']
    (F/'再現資料/追補コード索引.json').write_text(json.dumps({'ZIP':path.name,'ZIP_SHA256':sha(path.read_bytes()),'ZIP_bytes':path.stat().st_size,'格納源数':len(items),'格納源':items},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'追補ZIP_SHA':sha(path.read_bytes()),'格納源数':len(items)},ensure_ascii=False))


if __name__=='__main__':
    main()
