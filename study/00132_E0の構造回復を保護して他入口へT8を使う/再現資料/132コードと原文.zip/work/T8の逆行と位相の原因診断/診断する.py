"""固定区分の作成後に、保存済み実BBO正逆だけでT8の誤りを照合する。Raw再読なし。"""
import hashlib
import importlib.util
import json
from collections import Counter
from fractions import Fraction
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def sha(path: Path) -> str:
    """
    機能: ファイルのSHA256を計算する。
    引数: path(Path)は対象。
    返り値: strは小文字16進SHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(relative: str, expected: str, sources: dict) -> dict:
    """
    機能: 許可されたJSONの指紋を確認して読み込む。
    引数: relative(str)、expected(str)、sources(dict)は相対名・期待SHA・記録先。
    返り値: dictはJSON。読取前後のSHAはmainでも確認する。
    """
    path=ROOT/relative
    actual=sha(path);assert actual==expected,(relative,actual,expected)
    sources[relative]=actual
    return json.loads(path.read_text(encoding='utf-8-sig'))


def outcome(candidate: dict, width: int=125) -> tuple[dict,dict]:
    """
    機能: 保存済み60分の観測と指定幅の先着を取り出す。
    引数: candidate(dict)、width(int)は方向候補と幅pt。
    返り値: tuple[dict,dict]は期限観測と先着票。
    """
    outcomes=[x for x in candidate['outcomes'] if x['seconds']==3600];assert len(outcomes)==1
    touches=[x for x in outcomes[0]['touches'] if x['width']==width];assert len(touches)==1
    return outcomes[0],touches[0]


def selected(record: dict, inverse: bool=False) -> dict:
    """
    機能: T8又はその実逆の保存候補を選ぶ。
    引数: record(dict)、inverse(bool)は結合票と方向指定。
    返り値: dictは元/逆BBO候補。1-pで推定しない。
    """
    side=record['t8_side']*(-1 if inverse else 1)
    return record['case']['original' if side==record['original_side'] else 'reverse']


def label(candidate: dict, width: int=125) -> str:
    """
    機能: H完了と到達方向を分けたラベルを返す。
    引数: candidate(dict)、width(int)は候補と幅。
    返り値: strは順・逆・未到達・不足。
    """
    o,t=outcome(candidate,width)
    if o['status']!='complete':return '不足'
    return {1:'順',-1:'逆',0:'未到達'}[t['direction']]


def exit_value(candidate: dict, width: int) -> dict:
    """
    機能: 保存touchを優先し、既知のIFD代用清算を独立計算する。
    引数: candidate(dict)、width(int)は方向候補と幅。
    返り値: dictは既知・清算理由・pt・C0/C5。未知はNone。
    """
    o,t=outcome(candidate,width)
    if t['direction']!=0:q=t['quote'];reason='順touch' if t['direction']>0 else '逆touch'
    elif o['status']=='complete':q=o['endpoint'];reason='期限'
    else:return {'known':False,'reason':'不足','pt':None,'C0':None,'C5':None}
    assert q is not None
    side=candidate['birth']['side'];price=q['bid'] if side>0 else q['ask']
    points=side*(price-candidate['entry_price'])
    return {'known':True,'reason':reason,'pt':points,'C0':points*100-77,'C5':points*100-1077}


def stats(records: list[dict], inverse: bool=False, width: int=125) -> dict:
    """
    機能: 全件/完了/先着の分母と利益損失をFractionから算出する。
    引数: records(list[dict])、inverse(bool)、width(int)は群・方向・幅。
    返り値: dictは算術集計。0件・未到達・不足を捨てない。
    """
    candidates=[selected(x,inverse) for x in records]
    counts=Counter(label(c,width) for c in candidates)
    complete=len(records)-counts['不足'];resolved=counts['順']+counts['逆']
    exits=[exit_value(c,width) for c in candidates];known=[x for x in exits if x['known']]
    profits={cost:sum(x[cost] for x in known if x[cost]>0) for cost in ('C0','C5')}
    losses={cost:-sum(x[cost] for x in known if x[cost]<0) for cost in ('C0','C5')}
    money={cost:{'profit':profits[cost],'loss':losses[cost],
                 'net':profits[cost]-losses[cost],
                 'PF':float(Fraction(profits[cost],losses[cost])) if losses[cost] else None}
           for cost in ('C0','C5')}
    return {'entries':len(records),'sessions':len({x['session'] for x in records}),
            'complete':complete,'forward':counts['順'],'adverse':counts['逆'],
            'neither':counts['未到達'],'censored':counts['不足'],'resolved':resolved,
            'resolved_rate':float(Fraction(counts['順'],resolved)) if resolved else None,
            'complete_rate':float(Fraction(counts['順'],complete)) if complete else None,
            'ifd_known':len(known),'ifd_unknown':len(exits)-len(known),
            'ifd_reasons':dict(Counter(x['reason'] for x in exits)),'money':money}


# ----------------------------------------
def main() -> None:
    """
    機能: 凍結した区分へ既存正逆結果を結合して小型診断を保存する。
    引数: なし。固定許可ファイルだけを開く。
    返り値: None。診断JSONと完了指紋を新規保存する。
    """
    sources={}
    fixed=read('work/T8の逆行と位相の原因診断/事前の技術区分.json',
               '3112a6580f985e16ef82a072143d6d3eb55daf77553269f0913744b4c5818324',sources)
    assert sha(HERE/'事前の技術区分.md')==fixed['spec_sha256']
    features=read('work/124当時特徴の診断/全79例の当時特徴.json',
                  'e4f0bf25156c1fe732b186c5c5d90b6e9f95718985a440d8eb7005588f734774',sources)
    choices=read('work/T8の15分位相による切替案/choices.json',
                 'cdf1f0c6248d76222d49c7d872094cce20edecb7f52aa9e725d1040aa51f17c3',sources)
    model=read('work/126複合切替の探索/学習モデル.json',
               'a011cb759ff5d3ab05efe7c7a97bd1686fd9bdc482dfba048e8120e56bdd7059',sources)
    spec=importlib.util.spec_from_file_location('fixed_classification',HERE/'分類する.py')
    pure=importlib.util.module_from_spec(spec);spec.loader.exec_module(pure)
    choice_map={(x['session'],x['id']):x for x in choices['choices']}
    assert len(choice_map)==79
    records=[]
    for f in features['features']:
        key=(f['session'],f['id']);d=choice_map[key]
        assert d['original_side']==f['original_side']
        for ref in f['refs']:
            assert ref['delivered']['time']<=f['birth_quote']['time']
            assert ref['delivered']['index']<=f['birth_quote']['index']
            assert ref['delivered']['source_line']<=f['birth_quote']['source_line']
        records.append({'session':key[0],'id':key[1],'original_side':f['original_side'],
                        't8_side':d['t8_side'],'b0_side':d['b0_side'],'strategy':f['strategy'],
                        'partition_reference':d['partition_reference'],
                        'birth_quote':f['birth_quote'],'entry_quote':f['entry_quote'],
                        'diagnostic_only_entry_price_original':f['entry_price'],
                        'classification':pure.classify(f,d)})
    assert len(records)==79 and len({r['session'] for r in records})==73
    # 分類を全件確定した後でのみラベルを開く。
    data=read('work/124入口の正逆比較/全73場の正逆結果.json',
              '25517066b291a0434211190299b9f0195e67f9a7d2e89c801d5b9e6b4b51c3a1',sources)
    cases={(s['session'],c['id']):c for s in data['scenes'] for c in s['cases']}
    assert len(data['scenes'])==73 and len(cases)==79
    for r in records:
        c=cases[(r['session'],r['id'])];assert c['original_side']==r['original_side']
        assert c['original']['entry']==r['entry_quote']
        # 124正逆のbirthはSource123の取得時計を指す。技術特徴の出生時計とは区別する。
        assert c['original']['birth']['quote']==r['entry_quote']
        assert r['birth_quote']['time']<=r['entry_quote']['time']
        r['case']=c
    total=stats(records)
    assert (total['forward'],total['adverse'],total['neither'],total['censored'])==(39,18,16,6)
    aggregate=read('work/131既存入口の位相切替評価/集計.json',
                   '252a8d1744fe340b57a23db5c46d7dc7abd467fdfa59d273ce42f497b04843f3',sources)
    a=aggregate['集計']['all']['T8']['BBO']['3600']['125']
    for key in ('entries','sessions','complete','censored','forward','adverse','neither','resolved','resolved_rate',
                'complete_rate','ifd_known','ifd_unknown'):assert total[key]==a[key],key
    assert total['money']['C5']=={'profit':a['ifd_net5_profit'],'loss':a['ifd_net5_loss'],
                                'net':a['ifd_net5_sum'],'PF':a['ifd_net5_pf']}
    old=read('work/124入口の原因分析/集計.json',
             '1ca939bd2c619f6d2a3926999cb1b8e57726d48f2584b798cc6688e42ece49f8',sources)
    groups=[]
    for field in records[0]['classification']['bins']:
        categories=sorted({r['classification']['bins'][field] for r in records})
        for category in categories:
            subset=[r for r in records if r['classification']['bins'][field]==category]
            groups.append({'axis':field,'bin':category,'T8':stats(subset),'actual_reverse':stats(subset,True),
                           'matrix':dict(Counter(label(selected(r))+'→'+label(selected(r,True)) for r in subset)),
                           'supplement_widths':{str(w):{'T8':stats(subset,False,w),'actual_reverse':stats(subset,True,w)}
                                                for w in (25,100)} if field in ('D1','D2') else None})
    branches=[]
    for branch in ('T8=B0','T8=-B0'):
        subset=[r for r in records if r['classification']['bins']['枝']==branch]
        branches.append({'branch':branch,'main':stats(subset),'actual_reverse':stats(subset,True),
                         'adverse_group_counts':{field:dict(Counter(r['classification']['bins'][field] for r in subset
                                                                   if label(selected(r))=='逆'))
                                                 for field in records[0]['classification']['bins']}})
    exported=[]
    for r in records:
        row={k:v for k,v in r.items() if k!='case'}
        row['H60_125']={'T8':label(selected(r)),'actual_reverse':label(selected(r,True)),
                        'T8_exit':exit_value(selected(r),125),'actual_reverse_exit':exit_value(selected(r,True),125)}
        row['T8_entry_price']=selected(r)['entry_price']
        row['actual_reverse_entry_price']=selected(r,True)['entry_price']
        exported.append(row)
    output={'success':True,'diagnosis_only':True,'not_a_new_policy_evaluation':True,
            'source_hashes':sources,'entries':79,'sessions':73,'all_sessions_previously_observed':True,
            'independent_unknown_period':False,'fixed_bins_before_group_results':True,
            'birth_last_position':True,'entry_features_used_in_bins':False,'new_raw_reads':False,
            'new_financial_replay':False,'threshold_search':False,'main_width':125,'main_horizon':3600,
            'all':{'T8':total,'actual_reverse':stats(records,True),
                   'supplement_widths':{str(w):{'T8':stats(records,False,w),'actual_reverse':stats(records,True,w)} for w in (25,100)}},
            'branches':branches,'groups':groups,
            'prior124_T3_reference':old['集計']['T3']['BBO']['3600']['125'],
            'adverse_ids':[r['id'] for r in records if label(selected(r))=='逆'],'rows':exported}
    path=HERE/'当時区分の診断.json';assert not path.exists()
    path.write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    assert all(sha(ROOT/p)==h for p,h in sources.items())
    assert sha(HERE/'事前の技術区分.md')==fixed['spec_sha256']
    owned={p.name:sha(p) for p in HERE.iterdir() if p.is_file()}
    proof={'success':True,'source_hashes_before_after_equal':True,'source_hashes':sources,
           'files':owned,'result_sha256':sha(path),'rows':79,'sessions':73,
           'T8_131_all_main_identical':True,'artificial_tests':4,'natural_raw_read':False,
           'source_or_old_study_edited':False,'new_policy_finance_computed':False}
    (HERE/'完了.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'success':True,'result_sha256':sha(path),'all_T8':total,'branches':branches,
                      'D1D2':[g for g in groups if g['axis'] in ('D1','D2')],'priorT3':output['prior124_T3_reference']},ensure_ascii=False))


if __name__=='__main__':main()
