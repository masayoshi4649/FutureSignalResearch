"""追加区分固定後、技術的出生4型の固定O0/B0/T8だけを保存正逆から照合する。"""
import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path


def sha(path: Path) -> str:
    """
    機能: ファイルのSHA256を求める。
    引数: path(Path)は対象ファイル。
    返り値: strは小文字16進SHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 固定79件を技術的出生4型で比較し、政策は再選択せず保存する。
    引数: なし。限定した旧固定入力と追加区分JSONを参照する。
    返り値: None。入口型の診断JSON・完了JSONを新規保存する。
    """
    here=Path(__file__).resolve().parent;root=here.parents[2]
    fixed={
        'work/124当時特徴の診断/全79例の当時特徴.json':'e4f0bf25156c1fe732b186c5c5d90b6e9f95718985a440d8eb7005588f734774',
        'work/124入口の正逆比較/全73場の正逆結果.json':'25517066b291a0434211190299b9f0195e67f9a7d2e89c801d5b9e6b4b51c3a1',
        'work/T8の15分位相による切替案/choices.json':'cdf1f0c6248d76222d49c7d872094cce20edecb7f52aa9e725d1040aa51f17c3',
        'work/131既存入口の位相切替評価/集計.json':'252a8d1744fe340b57a23db5c46d7dc7abd467fdfa59d273ce42f497b04843f3',
        'work/T8の逆行と位相の原因診断/診断する.py':'e60b50c2fd01242f2946a6db8dfbf67cb3399834ec9eda310b23f9c1fe872d7a',
    }
    # 算術ヘルパーは直前に作成した独立診断コード。Root集計はimportしない。
    arithmetic=here.parent/'診断する.py'
    actual_arithmetic_sha=sha(arithmetic)
    assert actual_arithmetic_sha==fixed['work/T8の逆行と位相の原因診断/診断する.py']
    assert sha(here/'追加区分の固定.json')=='0bf3f6733f64c195efbf362b0684aed2638ad97ea38483fc01dda2629414bc9f'
    spec=json.loads((here/'追加区分の固定.json').read_text(encoding='utf-8'))
    assert sha(here/'追加区分を固定する.md')==spec['spec_sha256']
    assert all(sha(root/p)==h for p,h in fixed.items())
    m=importlib.util.spec_from_file_location('own_diagnostic_arithmetic',arithmetic)
    helper=importlib.util.module_from_spec(m);m.loader.exec_module(helper)
    load=lambda name:json.loads((root/name).read_text(encoding='utf-8-sig'))
    features=load(list(fixed)[0]);choices=load(list(fixed)[2])
    choice_map={(x['session'],x['id']):x for x in choices['choices']}
    source_type={};source_features={}
    for f in features['features']:
        key=(f['session'],f['id']);source_type[key]=f['strategy'];source_features[key]=f
        assert f['strategy'] in spec['categories']
    data=load(list(fixed)[1]);aggregate=load(list(fixed)[3])
    sessions=[s['session'] for s in data['scenes']];assert len(sessions)==73
    records=[]
    for scene in data['scenes']:
        for case in scene['cases']:
            key=(scene['session'],case['id']);c=choice_map[key];f=source_features[key]
            assert case['original_side']==f['original_side']==c['original_side']
            records.append({'session':key[0],'id':key[1],'case':case,'original_side':case['original_side'],
                            'strategy':source_type[key],'direction_choices':c,'feature':f})
    assert len(records)==len(source_type)==79
    rows=[];stats={}
    for policy in spec['policies']:
        selected_records=[{**r,'t8_side':r['direction_choices']['choices'][policy]['side']} for r in records]
        stats[policy]={}
        for group in ('all',*spec['categories']):
            subset=selected_records if group=='all' else [r for r in selected_records if r['strategy']==group]
            result=helper.stats(subset)
            result['flips_from_O0']=sum(r['t8_side']!=r['original_side'] for r in subset)
            result['flips_from_B0']=sum(r['t8_side']!=r['direction_choices']['b0_side'] for r in subset)
            stats[policy][group]=result
        a=aggregate['集計']['all'][policy]['BBO']['3600']['125'];s=stats[policy]['all']
        for key in ('entries','sessions','complete','forward','adverse','neither','censored','resolved','resolved_rate',
                    'complete_rate','ifd_known','ifd_unknown'):assert a[key]==s[key],(policy,key)
        assert a['ifd_net5_sum']==s['money']['C5']['net']
        assert a['ifd_net5_profit']==s['money']['C5']['profit']
        assert a['ifd_net5_loss']==s['money']['C5']['loss']
        assert a['ifd_net5_pf']==s['money']['C5']['PF']
    for record in records:
        choices=record['direction_choices'];f=record['feature'];fields=f['features']
        row={'session':record['session'],'id':record['id'],'strategy':record['strategy'],
             'source_candle_width':fields['source_candle_width'],
             'source_candle_body_signed_ratio':fields['source_candle_body_signed_ratio'],
             'candle5_body_signed_ratio':fields['candle5_body_signed_ratio'],
             'rvol5':fields['rvol5'],'original_side':record['original_side'],
             'policies':{}}
        for policy in spec['policies']:
            r={**record,'t8_side':choices['choices'][policy]['side']}
            row['policies'][policy]={'side':r['t8_side'],'label':helper.label(helper.selected(r)),
                                     'IFD':helper.exit_value(helper.selected(r),125)}
        rows.append(row)
    group_sessions=[]
    for session in sessions:
        counts=Counter(r['strategy'] for r in records if r['session']==session)
        group_sessions.append({'session':session,'types':{k:counts[k] for k in spec['categories']}})
    result={'success':True,'source_hashes':fixed,'fixed_type_spec_sha256':spec['spec_sha256'],
            'groups_fixed_before_grouped_outcomes':True,'new_policy_evaluation':False,
            'all_rows':79,'all_sessions':73,'all_period_previously_observed':True,
            'all_O0_B0_T8_131_main_equal':True,'stats':stats,'all_session_type_counts':group_sessions,
            'rows':rows,'raw_reads':False,'old_sources_edited':False}
    out=here/'入口型の診断.json';assert not out.exists()
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    assert all(sha(root/p)==h for p,h in fixed.items())
    proof={'success':True,'source_hashes_before_after_equal':True,'source_hashes':fixed,
           'all_79_and_73_kept':True,'fixed_policy_all_main_131_equal':True,
           'result_sha256':sha(out),'owned_files':{p.name:sha(p) for p in here.iterdir() if p.is_file()},
           'new_policy_finance_computed':False,'raw_reads':False}
    (here/'完了.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'success':True,'result_sha256':sha(out),'stats':stats},ensure_ascii=False))


if __name__=='__main__':main()
