"""132の非金融同体検査と、旧T8入口型の関連診断を区別して正式保存する。"""
from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import json
import re
import zipfile

ROOT = Path(__file__).resolve().parents[2]
FORMAL = ROOT / 'study/00132_E0の構造回復を保護して他入口へT8を使う'
PLAN = ROOT / 'work/E0の構造回復を保護する切替案'
TYPES = ROOT / 'work/T8の逆行と位相の原因診断/入口型の追補'


def sha(body: bytes) -> str:
    """
    機能: 保存内容の指紋を返す。
    引数: body(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


# ----------------------------------------
def put(path: Path, body: bytes) -> None:
    """
    機能: 未作成の正式先へ原文bytesを保存する。
    引数: path(Path)、body(bytes)。
    返り値: None。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as handle:
        handle.write(body)


# ----------------------------------------
def cells(text: str) -> dict[str, list[str]]:
    """
    機能: 汎用表56行の全504設定セルを取り出す。
    引数: text(str)はMarkdown。
    返り値: dict[str,list[str]]。
    """
    result = {}
    for line in text.splitlines():
        if re.match(r'^\| [A-Z][0-9]{2} ', line):
            fields = [x.strip() for x in line.split('|')[1:-1]]
            if len(fields) == 11:
                assert fields[0] not in result
                result[fields[0]] = fields[2:]
    assert len(result) == 56
    return result


# ----------------------------------------
def main() -> None:
    """
    機能: 整備後の正本だけを保管し、既存共有資源の参照と由来を記録する。
    引数: なし。
    返り値: None。132金融、CSV、原板走査、F1作成は行わない。
    """
    identity = (PLAN / '方向の同体検査.json').read_bytes()
    identity_code = PLAN / '方向同体を確認する.py'
    assert sha(identity) == 'cf24a024311a072216a7efdffff8df3ff36c59994cd8916327ddb965e5d38782'
    assert sha(identity_code.read_bytes()) == 'ef2329a93e46b901dabe9a75f4f61ec5ece4d8a1ebcc1b78a0059732682e6a0b'
    proof = json.loads(identity)
    assert proof['人工検査成功'] == 8 and proof['固定取得'] == 79 and proof['固定場'] == 73
    assert proof['E0保護の適用'] == 9 and proof['T8から方向変更'] == 0 and proof['全79方向同体']
    assert not proof['金融結果読取'] and not proof['Raw読取'] and not proof['新CSV生成']
    for name, expected in proof['入力前後SHA256'].items():
        assert sha((ROOT / name).read_bytes()) == expected
    typed = (TYPES / '入口型の診断.json').read_bytes()
    assert sha(typed) == 'e654d4934e12c03207b9ba68dd25ac5602408d9b0808c9b1267889c3b154b2b6'
    before_md = {name: sha((FORMAL / name).read_bytes()) for name in ('README.md', '設定と結果.md')}
    setting_cells = cells((FORMAL / '設定と結果.md').read_text('utf-8'))
    put(FORMAL / '検査/方向の同体検査.json.gz', gzip.compress(identity, mtime=0))
    folder = FORMAL / '根拠/入口型の追補'
    put(folder / '入口型の診断.json.gz', gzip.compress(typed, mtime=0))
    for name in ('追加区分の固定.json', '追加区分を固定する.md', '完了.json', '最終確認.json'):
        put(folder / name, (TYPES / name).read_bytes())
    text = (TYPES / '結果と型の由来.md').read_text('utf-8')
    text = text.replace('(入口型の診断.json)', '(入口型の診断.json.gz)')
    text += '\nこの追補は既存O0/B0/T8の型別診断であり、132の新しい金融実行ではない。原文は再現資料のコードと原文ZIPへ保管した。JSONはgzipで一度だけ保存し、解凍SHAは`e654d4934e12c03207b9ba68dd25ac5602408d9b0808c9b1267889c3b154b2b6`。型由来のコードは既存123/124/121の正式コードZIPから参照できる。\n'
    put(folder / '結果と型の由来.md', text.encode('utf-8'))
    shared = []
    for name, decoded, target in [
        ('inputs/00124_同入口正逆の共用入力/全79例の当時特徴.json.gz', 'e4f0bf25156c1fe732b186c5c5d90b6e9f95718985a440d8eb7005588f734774', 'work/124当時特徴の診断/全79例の当時特徴.json'),
        ('inputs/00131_T8の15分位相切替/choices.json.gz', 'cdf1f0c6248d76222d49c7d872094cce20edecb7f52aa9e725d1040aa51f17c3', 'work/T8の15分位相による切替案/choices.json'),
    ]:
        body = (ROOT / name).read_bytes(); expanded = gzip.decompress(body)
        assert sha(expanded) == decoded
        shared.append({'保存元': name, '保存SHA256': sha(body), '解凍SHA256': decoded, '復元先': target})
    pure_archive = ROOT / 'study/00131_中期MACDの位相で複合入口の方向を切り替える/再現資料/131コード.zip'
    pure_entry = 'work/T8の15分位相による切替案/方向を選ぶ.py'
    with zipfile.ZipFile(pure_archive) as z:
        pure = z.read(pure_entry)
    assert sha(pure) == '6ca313c9cb03d8a1997db71d25d789004f3539538d4c9bcf84d97be9fad35f68'
    files = [identity_code, ROOT / 'work/132正式文書/金融前を記す.py',
             ROOT / 'work/132正式文書/同体の状態を記す.py', Path(__file__).resolve(),
             FORMAL / '再現資料/保存資料を復元する.py', TYPES / '型別に照合する.py',
             TYPES.parent / '診断する.py', TYPES / '追加区分を固定する.md', TYPES / '結果と型の由来.md']
    archive = FORMAL / '再現資料/132コードと原文.zip'
    archive.parent.mkdir(exist_ok=True)
    index = []
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in files:
            name = path.relative_to(ROOT).as_posix(); body = path.read_bytes()
            z.writestr(name, body)
            index.append({'path': name, 'bytes': len(body), 'sha256': sha(body),
                          '区分': '132非金融同体又は文書保管' if '入口型の追補' not in name and '原因診断/診断する.py' not in name else '既存T8型別診断の関連資源。132金融ではない'})
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for item in index:
            assert sha(z.read(item['path'])) == item['sha256']
    manifest = {'試行': 132, '金融実行': False, '金融前F1': None, '新CSV生成': False,
                '正式化前の同体通知後2MD指紋': before_md,
                '504セル基準': setting_cells, '方向証跡解凍SHA256': sha(identity),
                '方向証跡gzipSHA256': sha((FORMAL / '検査/方向の同体検査.json.gz').read_bytes()),
                '関連する旧T8型別診断の解凍SHA256': sha(typed),
                '共有非金融入力': shared,
                '共有純関数': {'保存元ZIP': pure_archive.relative_to(ROOT).as_posix(), 'ZIP_SHA256': sha(pure_archive.read_bytes()),
                               'entry': pure_entry, 'コードSHA256': sha(pure), '復元先': pure_entry},
                'コード': {'ZIP': archive.name, 'ZIP_SHA256': sha(archive.read_bytes()), 'ZIP_bytes': archive.stat().st_size,
                           '格納源数': len(index), '格納源': index},
                '保管UTC': datetime.now(timezone.utc).isoformat(),
                '注意': '金融後に事前F1を再構成していない。132は非金融同体検査、型別金額は旧T8等の関連診断。'}
    put(FORMAL / '保管索引.json', (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    print(json.dumps({'成功': True, '金融実行': False, '方向変更': 0,
                      'ZIP_SHA256': manifest['コード']['ZIP_SHA256'], 'コード源数': len(index),
                      '方向証跡解凍SHA256': sha(identity), 'F1作成': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
