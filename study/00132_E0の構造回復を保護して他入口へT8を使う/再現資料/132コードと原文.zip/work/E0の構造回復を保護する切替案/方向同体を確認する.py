"""132のE0保護を非金融で検査する。同体なら新しい損益表を重複生成しない。"""
from pathlib import Path
import hashlib
import importlib.util
import json
import unittest

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
SOURCES = {
    'work/124当時特徴の診断/全79例の当時特徴.json': 'e4f0bf25156c1fe732b186c5c5d90b6e9f95718985a440d8eb7005588f734774',
    'work/T8の15分位相による切替案/choices.json': 'cdf1f0c6248d76222d49c7d872094cce20edecb7f52aa9e725d1040aa51f17c3',
    'work/T8の15分位相による切替案/方向を選ぶ.py': '6ca313c9cb03d8a1997db71d25d789004f3539538d4c9bcf84d97be9fad35f68',
}


def sha(path: Path) -> str:
    """
    機能: ファイル全体の指紋を求める。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def choose(original: int, t8: int, strategy: str) -> dict:
    """
    機能: E0だけ元方向を保護し、その他はT8を継承する。
    引数: original/t8(int)は±1、strategy(str)は出生時の入口型。
    返り値: dictは主P0と反対方向R0の方向票。金融結果を参照しない。
    """
    assert type(original) is int and original in (-1, 1)
    assert type(t8) is int and t8 in (-1, 1)
    assert strategy in ('E0', 'trend', 'reversal', 'deadline')
    p0 = original if strategy == 'E0' else t8
    return {'P0': p0, 'R0': -p0, 'E0原方向の保護': strategy == 'E0'}


# ----------------------------------------
class Artificial(unittest.TestCase):
    """型の取り違え、符号、対照の定義を市場結果なしで検査する。"""

    def test_E0は元方向(self) -> None:
        """
        機能: E0をT8が変えた場合も元方向を選ぶ。
        引数: self(Artificial)。
        返り値: None。
        """
        self.assertEqual(choose(1, -1, 'E0')['P0'], 1)

    def test_E0同体も保護として記録(self) -> None:
        """
        機能: 保護の適用と実際の方向変更を混同しない。
        引数: self(Artificial)。
        返り値: None。
        """
        self.assertTrue(choose(1, 1, 'E0')['E0原方向の保護'])

    def test_通常順行はT8(self) -> None:
        """
        機能: trendに新しい条件を加えない。
        引数: self(Artificial)。
        返り値: None。
        """
        self.assertEqual(choose(1, -1, 'trend')['P0'], -1)

    def test_通常反転はT8(self) -> None:
        """
        機能: reversalに新しい条件を加えない。
        引数: self(Artificial)。
        返り値: None。
        """
        self.assertEqual(choose(1, -1, 'reversal')['P0'], -1)

    def test_期限補完もT8(self) -> None:
        """
        機能: deadlineを今回の主条件から除外しない。
        引数: self(Artificial)。
        返り値: None。
        """
        self.assertEqual(choose(1, -1, 'deadline')['P0'], -1)

    def test_R0は実逆評価用方向だけ(self) -> None:
        """
        機能: 全型・全方向でR0をP0の符号反転にする。
        引数: self(Artificial)。
        返り値: None。
        """
        for strategy in ('E0', 'trend', 'reversal', 'deadline'):
            for original in (1, -1):
                for t8 in (1, -1):
                    result = choose(original, t8, strategy)
                    self.assertEqual(result['R0'], -result['P0'])

    def test_売買鏡像(self) -> None:
        """
        機能: 価格方向の鏡像で主方向も反転する。
        引数: self(Artificial)。
        返り値: None。
        """
        for strategy in ('E0', 'trend', 'reversal', 'deadline'):
            self.assertEqual(choose(-1, 1, strategy)['P0'], -choose(1, -1, strategy)['P0'])

    def test_不正な型を拒否(self) -> None:
        """
        機能: 未知の型をE0又は通常入口へ黙って変換しない。
        引数: self(Artificial)。
        返り値: None。
        """
        with self.assertRaises(AssertionError):
            choose(1, -1, '未知')


# ----------------------------------------
def main() -> None:
    """
    機能: 人工検査後に固定79票の方向同体を検査し、新規の小型証跡へ保存する。
    引数: なし。
    返り値: None。正逆の将来観測・金融集計・Rawは開かない。
    """
    assert all(sha(ROOT / name) == expected for name, expected in SOURCES.items())
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(Artificial)
    tested = unittest.TextTestRunner(verbosity=1).run(suite)
    assert tested.wasSuccessful() and tested.testsRun == 8
    spec = importlib.util.spec_from_file_location('固定131純方向', ROOT / 'work/T8の15分位相による切替案/方向を選ぶ.py')
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    features = json.loads((ROOT / 'work/124当時特徴の診断/全79例の当時特徴.json').read_text('utf-8'))['features']
    previous = json.loads((ROOT / 'work/T8の15分位相による切替案/choices.json').read_text('utf-8'))
    prior = {(r['session'], r['id']): r for r in previous['choices']}
    rows = []
    for feature in features:
        identity = feature['session'], feature['id']
        old = prior[identity]
        pure = module.choose(feature['original_side'], feature['features'])
        assert pure['t8_side'] == old['choices']['T8']['side']
        assert old['strategy'] == feature['strategy'] and old['path'] == feature['path']
        assert (feature['strategy'] == 'E0') == (feature['path'] == 'E0')
        assert old['birth'] == {k: feature['birth_quote'][k] for k in ('time', 'index', 'source_line')}
        assert old['entry'] == {k: feature['entry_quote'][k] for k in ('time', 'index', 'source_line')}
        result = choose(feature['original_side'], pure['t8_side'], feature['strategy'])
        rows.append({'セッション': identity[0], '出生ID': identity[1], '型': feature['strategy'],
                     'O0': feature['original_side'], 'T8': pure['t8_side'], **result,
                     '出生': old['birth'], '取得': old['entry'], 'T8から変更': result['P0'] != pure['t8_side']})
    assert len(rows) == len(prior) == 79 and len({r['セッション'] for r in rows}) == 73
    assert all(sha(ROOT / name) == expected for name, expected in SOURCES.items())
    value = {'成功': True, '試行': 132, '主': 'P0', '副候補': None, '人工検査成功': 8,
             '入力前後SHA256': SOURCES, 'コードSHA256': sha(Path(__file__)),
             '固定取得': 79, '固定場': 73, 'E0保護の適用': sum(r['E0原方向の保護'] for r in rows),
             'T8から方向変更': sum(r['T8から変更'] for r in rows),
             '全79方向同体': all(not r['T8から変更'] for r in rows),
             '結果': '固定入口と全方向が同体なら、同じ評価式で入口成績は改善しない。金融を重複実行しない。',
             '金融結果読取': False, 'Raw読取': False, '新CSV生成': False, '方向票': rows}
    with (OWN / '方向の同体検査.json').open('x', encoding='utf-8', newline='\n') as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2); handle.write('\n')
    print(json.dumps({k: value[k] for k in ('成功', '固定取得', '固定場', 'E0保護の適用', 'T8から方向変更', '全79方向同体')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
