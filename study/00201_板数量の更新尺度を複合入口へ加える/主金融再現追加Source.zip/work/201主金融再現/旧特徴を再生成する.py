"""恒久148から151純特徴を再構成し、旧履歴情報を保った同一キャッシュを確認する。"""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).parent


# ----------------------------------------
def sha(path: Path) -> str:
    """
    機能: ファイルの物理指紋を得る。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 元148入力から特徴を作り、由来の履歴断片だけを復元して151固定SHAを検査する。
    引数: なし。第1引数で出力先を指定可能。
    返り値: None。履歴statを今回の読取証拠と称さない。
    """
    spec=importlib.util.spec_from_file_location('data151_repro',ROOT/'work/151過去場判別/data151.py')
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
    assert sha(Path(module.__file__))=='3b92ff77a28bf82e6cf8e5dc504cc5586f4101c1e28d0bc12b29bc7cd0efdd8c'
    historical=json.loads((HERE/'151特徴の旧由来.json').read_text(encoding='utf-8'))
    refs={key:module.FileRef(ROOT/'inputs/00148_全1分入口母集団'/Path(value['path']).name,value['sha256'],value['decoded_sha256']) for key,value in historical.items()}
    dataset=module.load_feature_dataset(refs['features'],refs['fixed'])
    current=dataset.sources
    for key in current:
        for field in ('sha256','decoded_sha256','physical_bytes','decoded_bytes','gzip','full_crc_checked'):
            assert current[key][field]==historical[key][field],(key,field)
    dataset.sources=historical
    target=Path(sys.argv[1]) if len(sys.argv)>1 else HERE/'151再生成'
    result=module.save_feature_cache(dataset,target)
    assert result['npz_sha256']=='5b309e0821403fcf1b122956fc6c9fe20ec5dfbe4327d7d674193b8e58f99b44'
    assert result['metadata_sha256']=='71df54db57a3093eb4de2f5ce26c654c758f9181e07f61660cb1a192f6fa4602'
    proof={'成功':True,'固定151の両物理SHA同体':True,'履歴statは現在の証拠ではない':True,'今回の読取証拠':current,'旧由来断片':historical,'出力':result}
    (HERE/'151特徴再生成確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'固定151の両物理SHA同体':True},ensure_ascii=False),flush=True)


# ----------------------------------------
if __name__=='__main__':main()
