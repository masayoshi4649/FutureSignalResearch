"""復元先の固定201主金融を動かし、元の正本とbyte同体を検査する。"""
from pathlib import Path
import hashlib
import json
import os
import sys
import traceback

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).parent
ORIGINAL=Path(sys.argv[1]).resolve()
TRIAL=Path('study/00201_板数量の更新尺度を複合入口へ加える')
OPENED=set();WRITTEN=set();EXTERNAL={};IN_WATCH=False


# ----------------------------------------
def watch(event: str,args: tuple) -> None:
    """
    機能: 実参照・書込を記録し、元配置と展開先の恒久入力への書込を拒否する。
    引数: event(str)、args(tuple)はPython監査イベント。
    返り値: None。参照先の書換えや旧条件の置換は行わない。
    """
    global IN_WATCH
    if IN_WATCH or event!='open' or not args or not isinstance(args[0],(str,bytes)):return
    IN_WATCH=True
    try:
        p=Path(args[0]).resolve()
        mode=args[1] if len(args)>1 and isinstance(args[1],str) else ''
        flags=args[2] if len(args)>2 and isinstance(args[2],int) else 0
        writing=any(c in mode for c in 'wax+') or flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)
        protected=(ROOT/'inputs',ORIGINAL/'inputs',ORIGINAL.parent/'JP_OSE_Data')
        if writing and any(p.is_relative_to(q) for q in protected):raise RuntimeError('入力への書込を拒否:'+str(p))
        if p.suffix=='.pyc' or 'site-packages' in p.parts:return
        if p.is_relative_to(ROOT) or p.is_relative_to(ORIGINAL):
            OPENED.add(p)
            if writing:
                assert p.is_relative_to(ROOT),'元配置への書込は禁止:'+str(p)
                WRITTEN.add(p)
        if p.is_relative_to(ORIGINAL/'work') and not p.is_relative_to(ROOT):
            trace=[];frame=sys._getframe(1)
            while frame is not None and len(trace)<12:
                trace.append(frame.f_code.co_name+'@'+frame.f_code.co_filename+':'+str(frame.f_lineno));frame=frame.f_back
            EXTERNAL.setdefault(str(p),trace)
    finally:IN_WATCH=False


# ----------------------------------------
def ref(path: Path) -> dict:
    """
    機能: 物理ファイルの指紋を得る。
    引数: path(Path)は対象。
    返り値: dictは絶対path/bytes/sha256。
    """
    with path.open('rb') as stream:sha=hashlib.file_digest(stream,'sha256').hexdigest()
    return {'path':str(path),'bytes':path.stat().st_size,'sha256':sha}


# ----------------------------------------
def main() -> None:
    """
    機能: 恒久Source展開先で主金融を再生し、全25台帳・全統計・入力不変を検査する。
    引数: 第1引数は元リポジトリの絶対path(str)。
    返り値: None。独立金融算式の検査ではなく固定主実装の再現。
    """
    original_inputs={r['path']:r for r in json.loads((HERE/'復元参照表.json').read_text(encoding='utf-8'))['input_refs']}
    for rel,r in original_inputs.items():assert ref(ORIGINAL/rel)['sha256']==r['sha256'],rel
    sys.addaudithook(watch)
    sys.path.insert(0,str(ROOT/'work/201板数量比較'))
    success=False;error=None;matches=[];statistics=[]
    try:
        import 実行201 as M
        M.finance()
        output=ROOT/'work/201板数量比較'
        for p in sorted((output/'金融正本').glob('*.json.gz')):
            assert p.read_bytes()==(ORIGINAL/TRIAL/'金融正本'/p.name).read_bytes(),p.name
            matches.append(ref(p))
        assert len(matches)==25
        for name in ('全25口座安定性.json.gz','全25口座短表.json.gz','旧五母体同体.json'):
            assert (output/name).read_bytes()==(ORIGINAL/TRIAL/name).read_bytes(),name
            statistics.append(ref(output/name))
        success=True
    except Exception:error=traceback.format_exc()
    imports=[]
    for name,module in list(sys.modules.items()):
        filename=getattr(module,'__file__',None)
        if filename:
            p=Path(filename).resolve()
            if p.suffix in ('.py','.pyd') and (p.is_relative_to(ROOT) or p.is_relative_to(ORIGINAL)) and 'site-packages' not in p.parts:
                imports.append({'module':name,'path':str(p),'展開先':p.is_relative_to(ROOT)})
    assert all(r['展開先'] for r in imports),[r for r in imports if not r['展開先']]
    for rel,r in original_inputs.items():assert ref(ORIGINAL/rel)['sha256']==r['sha256'],rel
    originals=[{'path':p,'stack':trace} for p,trace in sorted(EXTERNAL.items())]
    proof={'成功':success,'固定Source変更なし':True,'独立金融算式ではなく固定主実装の再現':True,
        '全25金融byte同体':matches,'全統計byte同体':statistics,'展開先':str(ROOT),
        '元workへの絶対path参照':originals,'読込module':imports,
        '恒久入力の前後SHA不変件数':len(original_inputs),'恒久入力への書込みなし':True,
        '書込先':[str(p) for p in sorted(WRITTEN)],'実参照':[str(p) for p in sorted(OPENED)],'error':error}
    (HERE/'復元主金融確認201.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':success,'金融byte同体':len(matches),'統計byte同体':len(statistics),'module':len(imports),'元work絶対参照':len(originals),'error':error},ensure_ascii=False),flush=True)
    assert success,error


# ----------------------------------------
if __name__=='__main__':main()
