"""201の主金融再現に必要な小さな補助Sourceだけを恒久保存する。"""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).parent
TRIAL=ROOT/'study/00201_板数量の更新尺度を複合入口へ加える'


# ----------------------------------------
def ref(path: Path) -> dict:
    """
    機能: 正式資源の指紋を得る。
    引数: path(Path)は対象。
    返り値: dictはpath/bytes/sha256。
    """
    with path.open('rb') as stream:sha=hashlib.file_digest(stream,'sha256').hexdigest()
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':sha}


# ----------------------------------------
def main() -> None:
    """
    機能: 主金融の追加再現Sourceと検査票を保存し、ZIPを別場所へ展開して一致確認する。
    引数: なし。
    返り値: None。既存金融Source・条件・正本は変更しない。
    """
    names=('復元する.py','復元先を実行する.py','旧特徴を再生成する.py','151特徴の旧由来.json','復元参照表.json','追加Sourceを保存する.py')
    paths=[HERE/name for name in names]+[ROOT/'scripts/入口分析/分析.py']
    archive=TRIAL/'主金融再現追加Source.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for path in sorted(paths):
            info=zipfile.ZipInfo(path.relative_to(ROOT).as_posix(),date_time=(2026,11,18,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(info,path.read_bytes())
    refs=[ref(p) for p in sorted(paths)]
    manifest=json.loads((HERE/'復元参照表.json').read_text(encoding='utf-8'))
    index={'試行':201,'用途':'固定主金融の再現。金融前封印への遡及追加ではない。','archive':ref(archive),'members':refs,
        '既存ZIP参照':manifest['archives'],'復元資源数':len(manifest['files']),'前後SHA確認入力数':len(manifest['input_refs']),
        'バイナリ依存':manifest['バイナリ依存'],'原板や金融台帳の新規複製なし':True,
        '動的依存の事後捕捉':'scripts/入口分析/分析.pyは201の事前直接列挙に欠けた。現バイトは200正式ZIPと同体。既存条件は修正しない。'}
    (TRIAL/'主金融再現追加Source索引.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    restored=HERE/'repo_hardlink2/work/201主金融再現'
    audit=TRIAL/'監査';audit.mkdir(exist_ok=True)
    shutil.copy2(restored/'復元主金融確認201.json',audit/'主金融再現確認201.json')
    prepare=json.loads((restored/'復元準備確認.json').read_text(encoding='utf-8'))
    cache=json.loads((restored/'151特徴再生成確認.json').read_text(encoding='utf-8'))
    summary={'成功':prepare['成功'],'準備票の要約である':True,'復元Sourceと生成入力数':len(prepare['正式保存からの復元']),
        '共有入力方式':'全inputsをfile hardlinkで参照、金融実行の監査フックで入力への書込を禁止',
        '今回作成hardlink件数':len(prepare['恒久入力のfile_hardlink']),'原板複製なし':True,'依存版':prepare['依存版'],'151再生成':cache}
    (audit/'主金融再現の準備と151再生成.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    dest=HERE/'追加Source展開確認';assert not dest.exists();dest.mkdir()
    with zipfile.ZipFile(archive) as z:
        for r in refs:
            body=z.read(r['path']);target=dest/r['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(body)
            assert target.stat().st_size==r['bytes'] and hashlib.sha256(target.read_bytes()).hexdigest()==r['sha256']
            if target.suffix=='.py':compile(body,str(target),'exec')
    proof={'成功':True,'ZIP':ref(archive),'全member内容一致':len(refs),'全Python構文確認':sum(p.suffix=='.py' for p in paths),
        '主金融の別root実行済み':True,'その確認票':ref(audit/'主金融再現確認201.json')}
    (audit/'主金融再現Source展開確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False),flush=True)


# ----------------------------------------
if __name__=='__main__':main()
