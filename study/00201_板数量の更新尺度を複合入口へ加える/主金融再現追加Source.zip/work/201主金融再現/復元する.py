"""恒久保存の参照表から201主金融の再実行先を復元する。原板は複製しない。"""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).parent


# ----------------------------------------
def sha(path: Path) -> str:
    """
    機能: ファイルの物理指紋を得る。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 固定Source・生成入力を正式保存から復元し、恒久入力だけをfile hardlinkで共用する。
    引数: 第1引数は未作成の展開先(str)。省略時はrepo_hardlink0。
    返り値: None。既存ファイルを削除せず、原板と固定条件を変更しない。
    """
    target=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else HERE/'repo_hardlink0'
    assert not target.exists();target.mkdir(parents=True)
    manifest=json.loads((HERE/'復元参照表.json').read_text(encoding='utf-8'))
    for archive in manifest['archives']:
        assert sha(ROOT/archive['path'])==archive['sha256'],archive['path']
    for item in manifest['files']:
        dest=target/item['path'];dest.parent.mkdir(parents=True,exist_ok=True)
        if 'archive' in item:
            with zipfile.ZipFile(ROOT/item['archive']) as z:body=z.read(item['member'])
        else:body=(ROOT/item['source']).read_bytes()
        assert len(body)==item['bytes'] and hashlib.sha256(body).hexdigest()==item['sha256'],item['path']
        dest.write_bytes(body)
    input_links=[]
    for original in sorted((ROOT/'inputs').rglob('*')):
        if not original.is_file():continue
        dest=target/original.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True)
        if not dest.exists():os.link(original,dest)
        assert os.path.samefile(original,dest)
        input_links.append({'path':original.relative_to(ROOT).as_posix(),'bytes':original.stat().st_size})
    helper=target/'work/201主金融再現';helper.mkdir(parents=True,exist_ok=True)
    for name in ('旧特徴を再生成する.py','151特徴の旧由来.json','復元先を実行する.py','復元参照表.json'):
        shutil.copy2(HERE/name,helper/name)
    subprocess.run([sys.executable,'-X','utf8',str(helper/'旧特徴を再生成する.py'),str(target/'work/151過去場判別の評価/入口選択/cache/feature_only')],check=True)
    subprocess.run([sys.executable,'-m','pip','install','--disable-pip-version-check','--target',str(target/'work/pythonlibs'),'orjson==3.13.0'],check=True)
    subprocess.run([sys.executable,'-m','pip','install','--disable-pip-version-check','--target',str(target/'work/複合テクニカル学習環境/Lib/site-packages'),'numpy==2.5.4'],check=True)
    proof={'成功':True,'展開先':str(target),'正式保存からの復元':manifest['files'],'恒久入力のfile_hardlink':input_links,
        '入力は書込禁止で実行する':True,'原板複製なし':True,'151キャッシュは恒久148から再生成':True,
        '依存版':{'Python':sys.version,'orjson':'3.13.0','numpy':'2.5.4'}}
    (helper/'復元準備確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'展開先':str(target),'復元資源':len(manifest['files']),'入力hardlink':len(input_links)},ensure_ascii=False),flush=True)


# ----------------------------------------
if __name__=='__main__':main()
