"""独立照合済みの全83場から、日経の旧基準と損失軽減二案の閲覧入力を作る。"""
from pathlib import Path
import gzip
import hashlib
import json
import math

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).parent
TRIAL=ROOT/'study/00199_保留中の旧幹を確認済みの根拠で切り替える'
SPECS=(('00','旧基準'),('02','補完制限'),('05','旧幹確認'))


def load(path: Path) -> dict:
    """
    機能: 正式JSON資源の内容を読む。
    引数: path(Path)はJSON又はgzip JSON。
    返り値: dictは解析値。
    """
    raw=path.read_bytes();return json.loads(gzip.decompress(raw) if path.suffix=='.gz' else raw)


# ----------------------------------------
def held(scene: dict, positions: list, band: str) -> float:
    """
    機能: 場又は小時間帯と保有確認区間の重なりから保有時間率下限を求める。
    引数: scene(dict)、positions(list[dict])、band(str)。
    返り値: floatは0〜1の率。未知の保有を場末まで確定保有としない。
    """
    windows=[(scene['start'],scene['end'])] if band=='NIGHT' else [(p['start'],p['end']) for p in scene['phases'] if p['name']==band]
    assert len(windows)==1;start,end=windows[0]
    intervals=[]
    for p in positions:
        if p['scene']!=scene['scene']:continue
        stop=p['exit'] if p['exit'] is not None else p['confirmed_until']
        assert stop is not None
        a,b=max(start,p['fill']),min(end,stop)
        if a<b:intervals.append((a,b))
    intervals.sort()
    assert all(intervals[i][0]>=intervals[i-1][1] for i in range(1,len(intervals)))
    return sum(b-a for a,b in intervals)/(end-start)


# ----------------------------------------
def main() -> None:
    """
    機能: 旧81＋追加2を同条件で結合し、正本集計と場別のCSV入力を照合する。
    引数: なし。
    返り値: None。旧条件・選択・金融を変更しない。
    """
    state_path=TRIAL/'監査/全83の事後診断199.json.gz'
    states={s['id']:s for s in load(state_path)['metrics']}
    headers=['候補','開始日又は期間','帯','利益既知寄与_円','損失絶対額既知寄与_円','収支確定_円',
             '累計収支確定_円','建玉回数','未知件数','保有時間率下限','収支既知寄与_円','累計既知寄与_円']
    names={'候補比較':'集計','デイ':'デイ','ナイト全体':'ナイト全体','ナイト_米前':'ナイト_米前','ナイト_米後':'ナイト_米後'}
    tables={name:{'headers':headers,'rows':[]} for name in names}
    sources=[];comparison=[]
    for code,title in SPECS:
        identity=f'E199_{code}__C0_IFD';candidate=f'199:{code}_{title}'
        paths=[TRIAL/'保存金融'/(identity+'.json.gz'),TRIAL/'追加二場/保存金融'/('NK225199_'+identity+'.json.gz')]
        packs=[load(p) for p in paths]
        for p in paths:sources.append({'path':p.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
        scenes={s['scene']:s for p in packs for s in p['sessions']};positions=[x for p in packs for x in p['positions']]
        assert len(scenes)==83
        for band,group in states[identity]['groups'].items():
            if band not in ('ALL','DAY','NIGHT','PRE','POST'):continue
            trades=group['trades'];sessions=group['sessions'];h=group['holding']
            known=trades['known_net'];full=known if trades['unknown_count']==0 else None
            tables['候補比較']['rows'].append([candidate,'全83場',band,trades['known_profit'],trades['known_loss'],full,full,
                trades['all_count'],trades['unknown_count'],h['held_lower_ratio'],known,known])
            dest={'DAY':'デイ','NIGHT':'ナイト全体','PRE':'ナイト_米前','POST':'ナイト_米後'}.get(band)
            if not dest:continue
            cumulative=0.;complete=True;sum_profit=sum_loss=sum_seconds=0.
            for row in sessions['rows']:
                name=row['scene'];meta=scenes[name];cumulative+=row['known_net'];complete=complete and row['complete']
                ratio=held(meta,positions,band)
                window=meta['end']-meta['start'] if band=='NIGHT' else sum(p['end']-p['start'] for p in meta['phases'] if p['name']==band)
                sum_seconds+=ratio*window;sum_profit+=row['known_profit'];sum_loss+=row['known_loss']
                tables[dest]['rows'].append([candidate,name[:10],band,row['known_profit'],row['known_loss'],row['all_net'],
                    cumulative if complete else None,row['all_count'],row['unknown_count'],ratio,row['known_net'],cumulative])
            assert math.isclose(sum_profit,trades['known_profit'],abs_tol=1e-7)
            assert math.isclose(sum_loss,trades['known_loss'],abs_tol=1e-7)
            assert math.isclose(sum_seconds,h['held_lower_seconds'],abs_tol=1e-7)
            assert len(sessions['rows'])==(42 if band=='DAY' else 41)
            if band=='DAY':comparison.append({'候補':candidate,**{k:trades[k] for k in ('known_profit','known_loss','known_net','all_count')},
                '赤字取引':trades['negative_rate']['negative_count'],'赤字場':sessions['negative_rate']['negative_count'],
                '場DD':group['path']['known_contribution']['max_drawdown']['amount'],'保有率':h['held_lower_ratio'],
                '建玉中央値下限':trades['net_median']['lower'],'場中央値下限':sessions['net_median']['lower']})
    data={'tableNames':names,'tables':tables,'入力':sources,'集計正本':str(state_path.relative_to(ROOT)),
          '全83既使用の事後比較':True,'デイ比較':comparison,
          '未知':'不明がある場の確定収支、以後の確定累計は空欄。既知寄与を別列へ残す。'}
    HERE.mkdir(parents=True,exist_ok=True)
    (HERE/'閲覧入力.json').write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps({'候補':3,'CSV予定':15,'場数':83,'未知を確定累計へ入れない':True,'デイ比較':comparison},ensure_ascii=False))


# ----------------------------------------
if __name__=='__main__':main()
