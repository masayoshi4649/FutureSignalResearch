"""旧リスク要求自身を起点に失速反転又は再テスト順行を確認する純入口。"""
from pathlib import Path
import hashlib
import json
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work/185原圧力と受容'))
import rules185 as P

VERSION='191旧要求を起点に二方向の価格受容を確認1'
CONTROLS=('E185_00','E185_01','E185_03','E185_14')


def catalog() -> dict:
    """
    機能: 固定四対照と二リスク×二統合×二持続の12候補を定義する。
    引数: なし。
    返り値: dictは金融前の仕様・全閾値・心理仮説。
    """
    rules=[{'id':f'E191_{i:02d}','control':key,'description':'固定対照 '+key} for i,key in enumerate(CONTROLS)]
    for risk in ('R1','R2'):
        for mode in ('WAIT','SWITCH'):
            for profile in ('C60','C120'):
                rules.append({'id':f'E191_{len(rules):02d}','risk':risk,'mode':mode,'profile':profile,
                    'description':risk+'／'+mode+'／'+profile})
    return {'version':VERSION,'candidate_count':12,'rules':rules,'profiles':{k:P.PROFILES[k] for k in ('C60','C120')},
        'input':'旧179全期J035純入口、当時100特徴、q0絶対価格。金融・取得可否・未来価格を入力しない。',
        'risk_R1':'取得実方向と反対の5分EMA21傾き/DIが正、Hist/RSI増分両非負で一方正、15又は30分のEMA/DI両正、1分実体/価格進行/liveが正。全役割の必要既知。',
        'risk_R2':'取得実方向と反対の5分EMA21傾き/DIが正、Hist/RSI増分両非負で一方正、かつADX15>=25と増分>0、又は反対側entryのBB位置>=1σ。ORは既知True優先の三値。',
        'unknown':'既知リスクTrueだけ保留。未知は別旗で旧要求保持、安全認定しない。LCとcore=0の旧Tはそのまま。',
        'setup':'独立familyの新しい種は待たず、リスク旧要求自体をsetupにする。同方向30実分の期限を延長せず、反対旧要求で置換。新しい非リスク/未知旧coreで取消。',
        'reverse_level':'元方向BB位置>=1かつsigma>0が既知なら当時の固定1σ端。そうでなければ要求時Last。BB未知を内側と認定せず、局所Last水準という明示的代替を使う。',
        'reverse_confirm':'元5分DIがsetupより低下し、元Hist増分又はEMA傾きも低下。実方向5分Hist/RSI増分両非負・一方正、1分実体/進行/live正、共通品質と固定価格側受容。5分DIの完全符号転換は必須にしない。',
        'follow_level':'要求時Lastを固定。後続q0で元方向の距離が−.2〜+.2ATRに再テストし、そのq0より後で受容を開始する。再テスト同q0で発火しない。',
        'follow_confirm':'元方向5分EMA/DI/MA差が正、長期一足EMA/DI両正、Hist/RSI増分両非負で一方正、1分構造。元DI又はMA差がsetup以上を維持又は拡大し、共通品質と受容。WAITは使わずSWITCHだけ候補にする。',
        'acceptance':P.catalog()['acceptance'],
        'quality':P.catalog()['common'],
        'clock':'185のq0価格同体とresetを継承。受容90秒gap/量/侵入reset、同秒原行はcount/量平均を増やさず侵入と無効化を反映。setup30実分。NY帯だけの境界では継続。',
        'priority':'通常旧coreを最優先、LC保持。T/LC行で保留setupは保持するが、LC行では受容区間を切り直す。LCを飛ばした連続保持を仮定しない。リスク元q0はTへ暗黙切替しない。実方向反転再開と元方向順行が同時成熟すれば待ち。片方が発火したsetupは消費する。',
        'width':'元要求時のmw/fw/hiを固定し、遅延/切替時にも同じ幅・IFD期限種を渡す。新しい当時実方向BBOで取得し価格を据え置かない。setup待機期限と取得後IFD期限は別。IFD期限は取得後から、場末締切は別に適用。',
        'diagnostic':'元要求event、発火種別、固定水準、受容開始/秒/個数/侵入、遅延秒、元方向の源、unknownを保存。added=Trueは旧LCだけ。',
        'psychology':'勢いのある元方向に対して反転だけを決めず、帯内回復と元動力失速が続けば反転、元水準の再テスト後に方向/動力が残れば順行、どちらもなければ待つ仮説。',
        'limits':['圧力はEMA/DI/価格進行/相対量の代理であり板数量・完全OFI・吸収直接測定ではない。',
            '保持・侵入はq0観測範囲。全原板の間に逆行がなかったとは保証しない。',
            '全81既使用。前48選択と全80発見を分け、本日1/全81は診断専用。',
            '金融後の閾値改善は別試行。単純IFDのみで出口の追尾・技術途中返済を加えない。']}


def _and(items: list) -> int:
    """
    機能: 必要役割の既知Falseを優先する三値ANDを計算する。
    引数: items(list[int])は1/0/−1。
    返り値: intは真/偽/未知。
    """
    return 0 if 0 in items else -1 if -1 in items else 1


def _or(items: list) -> int:
    """
    機能: 代替役割の既知Trueを優先する三値ORを計算する。
    引数: items(list[int])は1/0/−1。
    返り値: intは真/偽/未知。
    """
    return 1 if 1 in items else -1 if -1 in items else 0


def _risk(x: dict, i: int, kind: str, normal: bool) -> int:
    """
    機能: 実方向と反対側の現在の整合・動力を三値判定する。
    引数: x(dict)は反対側特徴、i(int)、kind(str)、normal(bool)。
    返り値: intは既知リスク1/非該当0/UNKNOWN−1。
    """
    if not normal:return -1
    names=('m5_ema21_delta_to_side','m5_di_difference_to_side','m5_hist_delta_to_side','m5_rsi_delta_to_side')
    common=(-1 if not P._has(x,i,*names) else int(x[names[0]][i]>0 and x[names[1]][i]>0 and P._momentum(x,i)))
    if kind=='R1':
        long=[]
        for m in (15,30):
            pair=(f'm{m}_ema21_delta_to_side',f'm{m}_di_difference_to_side')
            long.append(-1 if not P._has(x,i,*pair) else int(x[pair[0]][i]>0 and x[pair[1]][i]>0))
        structure_names=('m1_body_ratio_to_side','m1_close_delta_atr5_to_side','m1_body_reclaim_atr5_to_side','q0_last_minus_m1_close_atr5_to_side')
        structure=-1 if not P._has(x,i,*structure_names) else int(P._structure(x,i))
        return _and([common,_or(long),structure])
    adx=(-1 if not P._has(x,i,'m15_adx','m15_adx_delta') else int(x['m15_adx'][i]>=25 and x['m15_adx_delta'][i]>0))
    bb=(-1 if not P._has(x,i,'q0_entry_minus_bbmean_sigma_to_side') else int(x['q0_entry_minus_bbmean_sigma_to_side'][i]>=1))
    return _and([common,_or([adx,bb])])


def _state(i: int, direction: int, arrays: list, prices: dict, base: dict) -> dict | None:
    """
    機能: 旧要求自体から反転・順行の固定価格と元幅期限を記憶する。
    引数: i/direction(int)、arrays(list)、prices/base(dict)。
    返り値: dict|NoneはATR/価格既知の時だけ作るsetup。
    """
    side=0 if direction==1 else 1;source=arrays[1-side];source_sign=-direction
    if not P._has(source,i,'m5_atr') or source['m5_atr'][i]<=0:return None
    atr=float(source['m5_atr'][i]);last=float(prices['last'][i]);level=last;kind='要求時Last'
    if P._has(source,i,'q0_entry_minus_bbmean_sigma_to_side','bb15_sigma') and source['q0_entry_minus_bbmean_sigma_to_side'][i]>=1 and source['bb15_sigma'][i]>0:
        entry=float(prices['ask'][i] if source_sign==1 else prices['bid'][i])
        level=entry-source_sign*(source['q0_entry_minus_bbmean_sigma_to_side'][i]-1)*source['bb15_sigma'][i]
        kind='固定BB1σ端'
    return {'event':i,'direction':direction,'atr':atr,'reverse_level_kind':kind,
        'reverse':{'level':level,'atr':atr,'accept':None},'follow':{'level':last,'atr':atr,'accept':None},
        'retest_event':-1,**{k:base[k][i] for k in ('mw','fw','hi')}}


def _reverse_ok(state: dict, arrays: list, side: int, i: int, prices: dict) -> bool:
    """
    機能: 元DIと動力失速・実方向の構造/動力回復を確認する。
    引数: state(dict)、arrays(list)、side/i(int)、prices(dict)。
    返り値: bool。完全な5分DI符号転換を遅れて待つ条件とは分ける。
    """
    source=arrays[1-side];x=arrays[side];seed=state['event']
    names=('m5_di_difference_to_side','m5_hist_delta_to_side','m5_ema21_delta_to_side')
    return bool(P._has(source,i,*names) and P._has(source,seed,*names)
        and source[names[0]][i]<source[names[0]][seed]
        and (source[names[1]][i]<source[names[1]][seed] or source[names[2]][i]<source[names[2]][seed])
        and P._momentum(x,i) and P._structure(x,i) and P._quality(x,i,prices))


def _follow_ok(state: dict, arrays: list, side: int, i: int, prices: dict) -> bool:
    """
    機能: 元方向の支持・動力・DI/MA差拡大と現在位置を確認する。
    引数: state(dict)、arrays(list)、side/i(int)、prices(dict)。
    返り値: bool。
    """
    x=arrays[side];seed=state['event'];names=('m5_ema21_delta_to_side','m5_di_difference_to_side','m5_gap_to_side')
    return bool(P._has(x,i,*names) and P._has(x,seed,'m5_di_difference_to_side','m5_gap_to_side')
        and all(x[k][i]>0 for k in names) and P._long(x,i) and P._momentum(x,i) and P._structure(x,i)
        and (x['m5_di_difference_to_side'][i]>=x['m5_di_difference_to_side'][seed] or x['m5_gap_to_side'][i]>=x['m5_gap_to_side'][seed])
        and P._quality(x,i,prices))


def build(features: object, base_bundle: dict, candidate_ids: list | None=None) -> dict:
    """
    機能: リスク旧要求から持続反転/再テスト順行へ移る12候補を作る。
    引数: features(FeatureDataset互換、q0_prices必須)、base_bundle(dict)、candidate_ids(list[str]|None)。
    返り値: dictはcandidate_ids/bundles/diagnostics。金融/保有を入力しない。
    """
    mapping={r['id']:r for r in catalog()['rules']};ids=list(mapping) if candidate_ids is None else candidate_ids
    assert len(ids)==len(set(ids)) and set(ids)<=set(mapping)
    arrays,meta,times,phases,reset,prices=P._prepare(features);n=len(times)
    base,_,_=P.P.OLD.V1._base(base_bundle,n,phases)
    controls=P.build(features,base_bundle,[mapping[k]['control'] for k in ids if 'control' in mapping[k]])
    bundles={};diagnostics={}
    for identity in ids:
        rule=mapping[identity]
        if 'control' in rule:
            bundles[identity]=controls['bundles'][rule['control']];diagnostics[identity]=controls['diagnostics'][rule['control']];continue
        out={'birth':{k:v.copy() for k,v in base['birth'].items()},**{k:base[k].copy() for k in ('mw','fw','hi','added')}}
        diag={'guarded':np.zeros(n,bool),'risk_unknown':np.zeros(n,bool),'reverse_confirmed':np.zeros(n,bool),
            'follow_confirmed':np.zeros(n,bool),'pending_from':np.full(n,-1,np.int64),'retest_event':np.full(n,-1,np.int64),
            'accept_event':np.full(n,-1,np.int64),'accept_seconds':np.zeros(n),'accept_count':np.zeros(n,np.int16),
            'max_penetration_atr':np.full(n,np.nan),'level':np.full(n,np.nan),'reverse_bb_level':np.zeros(n,bool),
            'delay_seconds':np.zeros(n),'competing':np.zeros(n,bool)}
        pending=None;profile=P.PROFILES[rule['profile']]
        for i in range(n):
            if reset[i]:pending=None
            if pending is not None and times[i]-times[pending['event']]>1800:pending=None
            if base['added'][i]:
                if pending is not None:
                    pending['reverse']['accept']=None;pending['follow']['accept']=None
                continue
            original=int(base['birth']['core'][i])
            if original:
                side=0 if original==1 else 1;risk=_risk(arrays[1-side],i,rule['risk'],bool(prices['normal'][i]))
                diag['risk_unknown'][i]=risk==-1
                if risk!=1:pending=None;continue
                proposed=_state(i,original,arrays,prices,base)
                if proposed is None:diag['risk_unknown'][i]=True;pending=None;continue
                diag['guarded'][i]=True
                for key,value in (('core',0),('branches',-1),('technical',0),('tier',0)):out['birth'][key][i]=value
                if pending is None or pending['direction']!=original:pending=proposed
            if pending is None or i<=pending['event'] or times[i]<=times[pending['event']] or out['birth']['core'][i]!=0:continue
            side=0 if pending['direction']==1 else 1;sign=pending['direction'];source_side=1-side;source_sign=-sign
            accept=P._accept(pending['reverse'],arrays[side],i,sign,times,prices,profile)
            reverse=(P._mature(pending['reverse'],accept,i,sign,times,prices,profile) and _reverse_ok(pending,arrays,side,i,prices))
            follow=False;other=None
            if rule['mode']=='SWITCH':
                distance=source_sign*(float(prices['last'][i])-pending['follow']['level'])/pending['atr']
                if pending['retest_event']<0 and prices['normal'][i] and -.2<=distance<=.2:pending['retest_event']=i
                if pending['retest_event']>=0 and i>pending['retest_event'] and times[i]>times[pending['retest_event']]:
                    other=P._accept(pending['follow'],arrays[source_side],i,source_sign,times,prices,profile)
                    follow=(P._mature(pending['follow'],other,i,source_sign,times,prices,profile) and _follow_ok(pending,arrays,source_side,i,prices))
            if reverse and follow:diag['competing'][i]=True;continue
            if not reverse and not follow:continue
            selected=pending['reverse'] if reverse else pending['follow'];observed=accept if reverse else other
            out['birth']['core'][i]=sign if reverse else source_sign
            for key in ('branches','technical','tier'):out['birth'][key][i]=0
            for key in ('mw','fw','hi'):out[key][i]=pending[key]
            out['added'][i]=False
            diag['reverse_confirmed'][i]=reverse;diag['follow_confirmed'][i]=follow
            diag['pending_from'][i]=pending['event'];diag['retest_event'][i]=pending['retest_event'];diag['accept_event'][i]=observed['event']
            diag['accept_seconds'][i]=times[i]-observed['time'];diag['accept_count'][i]=observed['count']
            diag['max_penetration_atr'][i]=max(0,-observed['min_distance']);diag['level'][i]=selected['level']
            diag['reverse_bb_level'][i]=pending['reverse_level_kind']=='固定BB1σ端'
            diag['delay_seconds'][i]=times[i]-times[pending['event']];pending=None
        lc=base['added'].astype(bool)
        assert all(np.array_equal(out['birth'][k][lc],base['birth'][k][lc]) for k in base['birth'])
        bundles[identity]=out;diagnostics[identity]=diag
    return {'version':VERSION,'candidate_ids':ids,'bundles':bundles,'diagnostics':diagnostics}


def write_catalog(path: Path) -> None:
    """
    機能: 新191の全条件と直接Sourceを金融前に新規保存する。
    引数: path(Path)は未作成JSON。
    返り値: None。旧Source・固定条件を変更しない。
    """
    assert not path.exists()
    sources=[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
        for p in (Path(__file__),Path(P.__file__))]
    path.write_text(json.dumps({**catalog(),'Source':sources,'新191金融未入力':True},ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
