"""リスク非該当の旧幹が技術確認保留を取り消す場合の入口を判別する。"""
from pathlib import Path
import hashlib
import json
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work/195保留中Tの技術根拠'))
import rules195 as G
R=G.R
B=G.B
P=G.P
EXTRA=G.EXTRA
_previous_five=G._previous_five
_risk=G._risk
_state=G._state
_reverse_ok=G._reverse_ok
_follow_ok=G._follow_ok
_filter_t=G._filter_t
VERSION='199保留中の旧幹確認2未知保持'
CONTROLS=('E195_00','E195_02','E195_05','E195_07','E195_10')


def catalog() -> dict:
    """
    機能: 五対照と二リスク×三つの旧幹切替確認を金融前に定義する。
    引数: なし。
    返り値: dictは全11案の条件・仮説・既使用区分。
    """
    rules=[{'id':f'E199_{i:02d}','control':key,'description':'固定対照 '+key} for i,key in enumerate(CONTROLS)]
    source={v['id']:v for v in G.catalog()['rules']}
    for key in ('E195_07','E195_10'):
        for mode in ('ALL','OPPOSITE','OWN'):
            rule={**source[key],'id':f'E199_{len(rules):02d}','base195':key,'handoff_mode':mode}
            rule['description']=key+'／旧幹の確認取消 '+mode;rules.append(rule)
    return {'version':VERSION,'candidate_count':11,'rules':rules,'base_specification':G.catalog(),
        'input':'全83既使用。195の旧81だけで先に純封印・金融を実行し、追加二場は既使用の原因診断期間として後段固定適用。',
        'hypothesis':'risk非該当は異常の不成立であり、新方向の取得根拠成立とは限らない。保留中に現れる旧幹も取得方向の確認を要する。',
        'ALL':'技術setup保留中に出たrisk非該当又は未知の旧幹を全て抑え、元setupのC120二方向確認へ通す。',
        'OPPOSITE':'保留方向と逆向きの旧幹だけALLと同じ。同方向のrisk非該当/未知は旧同体で即時に旧幹へ戻る。',
        'OWN':'保留中のrisk非該当/未知旧幹へ切替時、元setupを捨てて当該新要求のLast/ATR/幅期限を固定。新方向のC60受容＋実側5分MA差/DI>0・MACD/RSI増分・1分構造・量・品質で再開。',
        'OWN_state':'独自確認中は同方向の旧要求で期限を延ばさず、逆方向の非risk旧要求では新しい固定種へ替える。新risk旧要求なら従来の二方向setupへ戻す。固有確認中のTは遮断。LC優先で受容のみをresetし種は保持。',
        'OWN_clock':'30分期限、場/限月/180秒gap/resetで失効。同秒はC60を成熟させない。初回要求の幅/期限種を保持し、取得後からIFD期限を測る。',
        'unknown':'独自種が価格/ATR未知で作れない場合は元pending又は既存handoffを保持し、未知で待機理由を消さない。risk未知を安全とは言わずフラグ保持。独自確認に必要な価格/ATR/技術/量が未知なら発火しない。場/q0分母を保持。',
        'unchanged':'保留がない通常旧幹、LC、C120反転/順行、195T固有受容、単純IFD・1枠・末尾15分返済は同体。利益後追尾は追加しない。',
        'selection':'195と同じ損失優先順位と参加/両中央値適合。前48選択・全80発見・旧末尾1診断を区別。追加二場由来の仮説なので未見性能とは呼ばない。',
        'limits':['特定810の旧利益や825の損失を条件に使わず、全該当要求へ共通条件を適用する。',
            '元確認枝/新独自確認/旧幹/LC/Tと、口座の共通/旧のみ/新のみ実取得を分ける。',
            '全遮断を正解としない。弱い支持・参加減・別期間悪化を残して次仮説へ進む。']}


def _own_state(i: int, sign: int, arrays: list, prices: dict, base: dict) -> dict | None:
    """
    機能: 旧幹切替要求自身の固定価格・ATR・幅期限を記憶する。
    引数: i/sign(int)、arrays(list)、prices/base(dict)。
    返り値: dict|Noneは正常価格と正ATRがある場合だけの独自setup。
    """
    x=arrays[0 if sign==1 else 1]
    if not prices['normal'][i] or not P._has(x,i,'m5_atr') or x['m5_atr'][i]<=0:return None
    return {'event':i,'direction':sign,'level':float(prices['last'][i]),'atr':float(x['m5_atr'][i]),'accept':None,
        **{k:base[k][i] for k in ('mw','fw','hi')}}


def _own_ok(x: dict,i: int,prices: dict) -> bool:
    """
    機能: 独自切替の実側方向・勢い・構造・品質を同時確認する。
    引数: x/prices(dict)、i(int)。
    返り値: bool。必要値未知は不成立。
    """
    return bool(P._has(x,i,'m5_gap_to_side','m5_di_difference_to_side')
        and x['m5_gap_to_side'][i]>0 and x['m5_di_difference_to_side'][i]>0
        and P._quality(x,i,prices) and P._momentum(x,i) and P._structure(x,i))


def _suppress(out: dict,i: int) -> None:
    """
    機能: 現在の旧幹と同q0のTを新しい確認へ回して即時発火を止める。
    引数: out(dict)、i(int)。
    返り値: None。幅/期限を変更しない。
    """
    for key,value in (('core',0),('branches',-1),('technical',0),('tier',0)):out['birth'][key][i]=value


def build(features: object, base_bundle: dict, candidate_ids: list | None=None) -> dict:
    """
    機能: 保留中の旧幹取消を元確認又は独自確認へ通す11候補を作る。
    引数: features(FeatureDataset互換、q0_prices必須)、base_bundle(dict)、candidate_ids(list[str]|None)。
    返り値: dictはcandidate_ids/bundles/diagnostics。金融/保有を入力しない。
    """
    mapping={r['id']:r for r in catalog()['rules']};ids=list(mapping) if candidate_ids is None else candidate_ids
    assert len(ids)==len(set(ids)) and set(ids)<=set(mapping)
    arrays,meta,times,phases,reset,prices=P._prepare(features);n=len(times)
    columns=[c['name'] if isinstance(c,dict) else c for c in P.P._get(features,'columns')]
    for side,name in enumerate(('buy_X','sell_X')):
        for column in EXTRA:arrays[side][column]=np.asarray(P.P._get(features,name))[:,columns.index(column)]
    previous=_previous_five(arrays,reset)
    base,_,_=P.P.OLD.V1._base(base_bundle,n,phases)
    controls=G.build(features,base_bundle,[mapping[k]['control'] for k in ids if 'control' in mapping[k]])
    bundles={};diagnostics={}
    for identity in ids:
        rule=mapping[identity]
        if 'control' in rule:
            bundles[identity]=controls['bundles'][rule['control']];diagnostics[identity]=controls['diagnostics'][rule['control']];continue
        out={'birth':{k:v.copy() for k,v in base['birth'].items()},**{k:base[k].copy() for k in ('mw','fw','hi','added')}}
        diag={'guarded':np.zeros(n,bool),'risk_unknown':np.zeros(n,bool),'reverse_confirmed':np.zeros(n,bool),
            'follow_confirmed':np.zeros(n,bool),'pending_from':np.full(n,-1,np.int64),'retest_event':np.full(n,-1,np.int64),
            'accept_event':np.full(n,-1,np.int64),'accept_seconds':np.zeros(n),'accept_count':np.zeros(n,np.int16),
            'max_penetration_atr':np.full(n,np.nan),'level':np.full(n,np.nan),'reverse_bb_level':np.zeros(n,bool),
            'delay_seconds':np.zeros(n),'competing':np.zeros(n,bool),
            'pending_t_signal':np.zeros(n,bool),'pending_t_blocked':np.zeros(n,bool),'pending_t_allowed':np.zeros(n,bool),
            'pending_t_unknown':np.zeros(n,bool),'pending_t_from':np.full(n,-1,np.int64),
            'pending_t_accept_from':np.full(n,-1,np.int64),
            'redirected_core':np.zeros(n,bool),'redirected_from':np.full(n,-1,np.int64),
            'own_seed':np.zeros(n,bool),'own_confirmed':np.zeros(n,bool),'own_from':np.full(n,-1,np.int64),
            'own_active':np.zeros(n,bool),'own_unknown':np.zeros(n,bool),'own_t_blocked':np.zeros(n,bool)}
        pending=None;handoff=None;profile=P.PROFILES[rule['profile']]
        for i in range(n):
            if reset[i]:pending=None;handoff=None
            if pending is not None and times[i]-times[pending['event']]>1800:pending=None
            if handoff is not None and times[i]-times[handoff['event']]>1800:handoff=None
            if base['added'][i]:
                if pending is not None:
                    pending['reverse']['accept']=None;pending['follow']['accept']=None
                    pending.pop('t_states',None)
                if handoff is not None:handoff['accept']=None
                continue
            original=int(base['birth']['core'][i])
            if original:
                side=0 if original==1 else 1;risk=_risk(arrays[1-side],i,rule['risk'],bool(prices['normal'][i]))
                diag['risk_unknown'][i]=risk==-1
                if risk!=1:
                    if handoff is not None:
                        _suppress(out,i);diag['redirected_core'][i]=True;diag['redirected_from'][i]=handoff['event']
                        if original!=handoff['direction']:
                            proposed_own=_own_state(i,original,arrays,prices,base)
                            diag['own_seed'][i]=proposed_own is not None;diag['own_unknown'][i]=proposed_own is None
                            if proposed_own is not None:handoff=proposed_own
                    elif pending is not None and (rule['handoff_mode']=='ALL' or
                            (rule['handoff_mode']=='OPPOSITE' and original!=pending['direction'])):
                        _suppress(out,i);diag['redirected_core'][i]=True;diag['redirected_from'][i]=pending['event']
                    elif pending is not None and rule['handoff_mode']=='OWN':
                        _suppress(out,i);diag['redirected_core'][i]=True;diag['redirected_from'][i]=pending['event']
                        proposed_own=_own_state(i,original,arrays,prices,base)
                        diag['own_seed'][i]=proposed_own is not None;diag['own_unknown'][i]=proposed_own is None
                        if proposed_own is not None:handoff=proposed_own;pending=None
                    else:pending=None;continue
                else:
                    handoff=None
                    proposed=_state(i,original,arrays,prices,base)
                    if proposed is None:diag['risk_unknown'][i]=True;pending=None;continue
                    diag['guarded'][i]=True;_suppress(out,i)
                    if pending is None or pending['direction']!=original:pending=proposed
            if handoff is not None:
                diag['own_active'][i]=True;diag['own_from'][i]=handoff['event']
                diag['own_t_blocked'][i]=out['birth']['technical'][i]!=0
                out['birth']['technical'][i]=0;out['birth']['tier'][i]=0
                if i<=handoff['event'] or times[i]<=times[handoff['event']]:continue
                sign=handoff['direction'];side=0 if sign==1 else 1
                accept=P._accept(handoff,arrays[side],i,sign,times,prices,P.PROFILES['C60'])
                if not P._mature(handoff,accept,i,sign,times,prices,P.PROFILES['C60']) or not _own_ok(arrays[side],i,prices):continue
                out['birth']['core'][i]=sign;out['birth']['branches'][i]=0
                for key in ('mw','fw','hi'):out[key][i]=handoff[key]
                out['added'][i]=False;diag['own_confirmed'][i]=True
                diag['pending_from'][i]=handoff['event'];diag['accept_event'][i]=accept['event']
                diag['accept_seconds'][i]=times[i]-accept['time'];diag['accept_count'][i]=accept['count']
                diag['max_penetration_atr'][i]=max(0,-accept['min_distance']);diag['level'][i]=handoff['level']
                diag['delay_seconds'][i]=times[i]-times[handoff['event']];handoff=None
                continue
            if pending is None or i<=pending['event'] or times[i]<=times[pending['event']] or out['birth']['core'][i]!=0:continue
            _filter_t(out,diag,pending,arrays,i,times,prices,rule)
            side=0 if pending['direction']==1 else 1;sign=pending['direction'];source_side=1-side;source_sign=-sign
            accept=P._accept(pending['reverse'],arrays[side],i,sign,times,prices,profile)
            reverse=(P._mature(pending['reverse'],accept,i,sign,times,prices,profile) and _reverse_ok(pending,arrays,side,i,prices,rule,previous))
            follow=False;other=None
            if rule['mode']=='SWITCH':
                distance=source_sign*(float(prices['last'][i])-pending['follow']['level'])/pending['atr']
                if pending['retest_event']<0 and prices['normal'][i] and -.2<=distance<=.2:pending['retest_event']=i
                if pending['retest_event']>=0 and i>pending['retest_event'] and times[i]>times[pending['retest_event']]:
                    other=P._accept(pending['follow'],arrays[source_side],i,source_sign,times,prices,profile)
                    follow=(P._mature(pending['follow'],other,i,source_sign,times,prices,profile) and _follow_ok(pending,arrays,source_side,i,prices,rule))
            if reverse and follow:diag['competing'][i]=True;continue
            if not reverse and not follow:continue
            selected=pending['reverse'] if reverse else pending['follow'];observed=accept if reverse else other
            out['birth']['core'][i]=sign if reverse else source_sign
            for key in ('branches','technical','tier'):out['birth'][key][i]=0
            for key in ('mw','fw','hi'):out[key][i]=pending[key]
            out['added'][i]=False
            diag['reverse_confirmed'][i]=reverse;diag['follow_confirmed'][i]=follow
            diag['pending_from'][i]=pending['event'];diag['retest_event'][i]=pending['retest_event'];diag['accept_event'][i]=observed['event']
            diag['accept_seconds'][i]=times[i]-observed['time'];diag['accept_count'][i]=observed['count']
            diag['max_penetration_atr'][i]=max(0,-observed['min_distance']);diag['level'][i]=selected['level']
            diag['reverse_bb_level'][i]=pending['reverse_level_kind']=='固定BB1σ端'
            diag['delay_seconds'][i]=times[i]-times[pending['event']];pending=None
        lc=base['added'].astype(bool)
        assert all(np.array_equal(out['birth'][k][lc],base['birth'][k][lc]) for k in base['birth'])
        bundles[identity]=out;diagnostics[identity]=diag
    return {'version':VERSION,'candidate_ids':ids,'bundles':bundles,'diagnostics':diagnostics}


def write_catalog(path: Path) -> None:
    """
    機能: 新199の全条件と直接Sourceを金融前に新規保存する。
    引数: path(Path)は未作成JSON。
    返り値: None。旧Source・固定条件を変更しない。
    """
    assert not path.exists()
    sources=[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
        for p in (Path(__file__),Path(G.__file__),Path(R.__file__),Path(B.__file__),Path(P.__file__))]
    path.write_text(json.dumps({**catalog(),'Source':sources,'新199金融未入力':True},ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
