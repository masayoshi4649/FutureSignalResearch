"""194 NK225の未評価接続と金融接続を分離する。CLIは非金融検査だけを実行する。"""
from pathlib import Path
import argparse
import gzip
import json
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import NK純接続194 as N

AXES = ROOT / 'work/163任意幅Raw索引/観測条件の雛形.json'
FIXED_INPUTS = {
    '旧73': ROOT / 'inputs/00148_全1分入口母集団/固定取得入力.json.gz',
    '追加7': ROOT / 'inputs/00167_追加七場の入口と共用価格索引/入口母集団/固定取得入力.json.gz',
    '本日1': ROOT / 'inputs/00180_20261116デイの固定適用入力/入口母集団/固定取得入力.json.gz',
    '追加2': N.DEST / '入口母集団/固定取得入力.json.gz',
}
CHECK = HERE / 'NK金融接続前の検査194.json'


def read(path: Path) -> dict:
    """
    機能: 入力のJSON又はgzip JSONを日本語UTF-8で読む。
    引数: path(Path)は非金融入力。
    返り値: dictはデコードした内容。
    """
    raw = path.read_bytes()
    return json.loads(gzip.decompress(raw) if path.suffix == '.gz' else raw)


def modules() -> tuple:
    """
    機能: 既存の数値確保・終了前IFD・終了時計部品を明示名で読み込む。
    引数: なし。
    返り値: tupleは共用181・arrays166・early179。金融計算は呼ばない。
    """
    C = N.common()
    arrays = N.module(ROOT / 'work/166可変場の数値化/arrays166.py', 'arrays166_for194')
    early = N.module(ROOT / 'work/179終了前決済/early179.py', 'early179_for194')
    return C, arrays, early


def source_refs() -> list:
    """
    機能: 起動時のimport履歴に依存しない金融接続Source一覧を返す。
    引数: なし。
    返り値: list[dict]は相対path・bytes・SHA256。旧Sourceを変更しない。
    """
    paths = [Path(__file__), Path(N.__file__), AXES,
        ROOT / 'work/180本日デイ適用/入力180.py',
        ROOT / 'work/180本日デイ適用/本日を計算する.py',
        ROOT / 'work/181共用接続/共用181.py',
        ROOT / 'work/166可変場の数値化/arrays166.py',
        ROOT / 'work/163任意幅の数値化/arrays163.py',
        ROOT / 'work/167固定入口の別期間/適用基盤167.py',
        ROOT / 'work/179保有参加の探索/基盤179.py',
        ROOT / 'work/179終了前決済/early179.py']
    return [N.ref(path) for path in sorted(set(paths))]


def fixed_entries(fixed: dict) -> list:
    """
    機能: 各場の物理取得を全体ID辞書順に並べ、場添字を保持する。
    引数: fixed(dict)は固定取得入力。
    返り値: list[tuple[int,dict]]は場添字と取得。場内行位置を全体位置へ混同しない。
    """
    pairs = [(si, entry) for si, scene in enumerate(fixed['scenes']) for entry in scene['entries']]
    pairs.sort(key=lambda pair: pair[1]['id'])
    ids = [entry['id'] for _, entry in pairs]
    assert len(ids) == len(set(ids)) == fixed['expected_entry_count']
    assert all(isinstance(identity, str) and identity for identity in ids)
    return pairs


def assert_unvalued(context: object) -> None:
    """
    機能: 未評価表が全Cであり、将来決済値を持たないことを検査する。
    引数: context(GenericContext)は取得メタデータを接続した表。
    返り値: None。0円格納値を既知損益と扱わない。
    """
    shape = (len(context.table.case_ids), 2, len(context.table.widths), len(context.table.horizons))
    assert not context.financial_attached
    assert context.arrays['known'].shape == shape and not context.arrays['known'].any()
    assert np.all(context.arrays['label'] == 2) and np.all(context.arrays['net'] == 0)
    assert np.isnan(context.arrays['exit_time']).all() and np.isnan(context.arrays['known_at']).all()
    assert np.all(context.arrays['exit_index'] == -1) and np.all(context.arrays['exit_line'] == -1)


def assert_entry_rows(context: object, si: int, records: np.ndarray) -> np.ndarray:
    """
    機能: 全体case位置に属する取得を、当該場の同じ原行時刻・価格へ照合する。
    引数: context(GenericContext)、si(int)は場添字、records(np.ndarray)は48byte索引。
    返り値: np.ndarray[int64]は当該場の全体case位置。
    """
    cases = np.flatnonzero(context.case_scene == si)
    entries = np.asarray(context.arrays['entry_index'][cases], dtype=np.int64)
    assert np.all((entries >= 0) & (entries < len(records)))
    assert np.all(records['normal'][entries] == 1)
    for column, name in (('time', 'entry_time'), ('source_line', 'entry_line')):
        np.testing.assert_array_equal(records[column][entries], context.arrays[name][cases])
    np.testing.assert_array_equal(records['ask'][entries], context.arrays['entry_price'][cases, 0])
    np.testing.assert_array_equal(records['bid'][entries], context.arrays['entry_price'][cases, 1])
    return cases


def load_unvalued_context(pure: dict) -> dict:
    """
    機能: 180の一場接続を任意場数へ一般化し、全C未評価GenericContextを作る。
    引数: pure(dict)は181互換の純特徴・取得対応・索引・入力指紋。
    返り値: dictはcontext・proof・pure・captures・records。金融を計算しない。
    """
    C, adapter, early = modules()
    leg = pure['leg']
    assert leg in FIXED_INPUTS
    assert pure['proof']['金融未入力'] and not pure['context'].financial_attached
    assert C.feature_sha(pure['features']) == pure['proof']['features_sha256']
    features = pure['features']
    fixed_path = FIXED_INPUTS[leg]
    fixed = read(fixed_path)
    assert fixed['financial_labels_used'] is False and fixed['strategy_selected'] is False
    sessions = [scene['session'] for scene in features.scenes]
    assert sessions == [scene['session'] for scene in fixed['scenes']]
    assert sessions == [scene['session'] for scene in pure['price_index']['scenes']]
    assert len(sessions) == len(set(sessions))
    manifest_ref = pure['price_index']['manifest']
    assert N.ref(ROOT / manifest_ref['path']) == manifest_ref
    rows = fixed_entries(fixed)
    config = read(AXES)
    widths = tuple(config['widths'])
    horizons = tuple(row['id'] for row in config['horizons'])
    arrays = adapter.allocate(len(rows), widths, horizons)
    records_by_scene = []
    for si, (scene, indexed) in enumerate(zip(fixed['scenes'], pure['price_index']['scenes'], strict=True)):
        assert scene['session'] == indexed['session'] and scene['contract'] == indexed['contract']
        assert all(scene[key] == features.scenes[si][key] for key in ('session', 'start', 'end'))
        records = adapter.load_records(ROOT / indexed['path'], indexed['sha256'], indexed['rows'])
        records.setflags(write=False)
        records_by_scene.append(records)
    case_sessions = []
    for row, (si, entry) in enumerate(rows):
        quote = entry['entry']
        index = int(quote['index'])
        records = records_by_scene[si]
        assert 0 <= index < len(records) and records[index]['normal'] == 1
        assert all(records[index][key] == quote[key] for key in ('time', 'source_line', 'last', 'bid', 'ask'))
        for key, column in (('time', 'entry_time'), ('index', 'entry_index'), ('source_line', 'entry_line')):
            arrays[column][row] = quote[key]
        arrays['entry_price'][row] = [quote['ask'], quote['bid']]
        arrays['session_index'][row] = si
        assert entry['side'] in (-1, 1)
        arrays['original_side'][row] = entry['side']
        case_sessions.append(sessions[si])
    table = adapter.RawOutcomeTable(tuple(entry['id'] for _, entry in rows), tuple(case_sessions), tuple(sessions),
        widths, horizons, horizons, arrays, ('未評価',),
        {'成功': True, '条件': config, '索引manifestSHA256': manifest_ref['sha256'], '金融未評価全C': True})
    context = C.P.B.P.R168.BASE.GenericContext(features, table, pure['context'].capture_rows)
    context.financial_attached = False
    assert_unvalued(context)
    assert context.event_keys == pure['context'].event_keys
    assert context.sessions == pure['context'].sessions
    np.testing.assert_array_equal(context.event_scenes, pure['event_scene'])
    binding = early.binding(context, False)
    del binding['追加7']
    binding['対象期間'] = leg
    scene_checks = []
    for si, records in enumerate(records_by_scene):
        cases = assert_entry_rows(context, si, records)
        scene_checks.append({'場': sessions[si], '物理取得数': len(cases), '同原行一致': True})
    proof = {'成功': True, '金融未実行': True, '期間': leg, '純入力': pure['proof'],
             '固定取得入力': N.ref(fixed_path), '価格索引': pure['price_index'], '条件': N.ref(AXES),
             'Source': source_refs(), 'binding': binding, '場別確認': scene_checks,
             'shape': list(context.arrays['known'].shape), '当時q0数': len(features.q0_meta)}
    context._nk194 = {'pure': pure, 'records': records_by_scene, 'proof': proof, 'binding': binding}
    return {'context': context, 'proof': proof, 'pure': pure, 'captures': C.M.B.captures(context),
            'records': records_by_scene}


def connect_clock(context: object) -> object:
    """
    機能: 179固定Sourceで15分前cutと16分前submit・三帯時間を接続する。
    引数: context(GenericContext)は未評価又は評価済み表。
    返り値: GenericContextは同じinstance。金融計算や旧Context読込は行わない。
    """
    M = N.common().M
    original = M.B.load_context
    try:
        M.B.load_context = lambda new=False: context
        result = M.load_context()
    finally:
        M.B.load_context = original
    assert result is context
    np.testing.assert_array_equal(context.deadlines, [scene['end'] - 900 for scene in context.scenes])
    np.testing.assert_array_equal(context.close_submits, [scene['end'] - 960 for scene in context.scenes])
    np.testing.assert_allclose(context.hours.sum(axis=1),
        [(scene['end'] - 900 - scene['start']) / 3600 for scene in context.scenes], rtol=0, atol=1e-12)
    return context


def join_overlay(parts: list, count: int, widths: list, horizons: list) -> dict:
    """
    機能: 各場の金融配列を全体case位置へ戻し、未知と両実側を保って結合する。
    引数: parts(list[tuple[np.ndarray,dict]])、count(int)、widths/horizons(list)は共通軸。
    返り値: dict[str,np.ndarray]は全case順overlay。人工配列でも検査できる。
    """
    _, _, early = modules()
    result = early.allocate(count, widths, horizons)
    seen = np.zeros(count, bool)
    for cases, local in parts:
        cases = np.asarray(cases, dtype=np.int64)
        assert len(cases) == len(set(cases.tolist())) and np.all((cases >= 0) & (cases < count))
        assert not seen[cases].any() and set(local) == set(result)
        for key, value in result.items():
            assert local[key].shape == (len(cases), *value.shape[1:]), key
            assert local[key].dtype == value.dtype, key
            value[cases] = local[key]
        seen[cases] = True
    assert seen.all()
    assert np.array_equal(result['label'] == 2, ~result['known'])
    result['unknown_hold_lower_end'] = result['holding_confirmed_until'].copy()
    result['pair_complete'] = np.all(result['known'], axis=1)
    result['pair_known_at'] = np.where(result['pair_complete'], np.max(result['known_at'], axis=1), np.nan)
    return result


def attach_financial(context: object) -> dict:
    """
    機能: rootの候補・両商品・全Source封印後だけ、場別early179を実行し179時計を接続する。
    引数: context(GenericContext)はload_unvalued_contextで作った未評価表。
    返り値: dictはcontext・captures・proof・overlay・case_index。contextをA.packへ直接渡せる。
            自然入力での本関数呼出しはrootの金融実行指示後に限る。CLIからは呼ばない。
    """
    C, _, early = modules()
    assert_unvalued(context)
    prepared = context._nk194
    assert prepared['proof']['金融未実行']
    assert all(N.ref(ROOT / row['path']) == row for row in prepared['proof']['Source'])
    assert N.ref(ROOT / prepared['proof']['固定取得入力']['path']) == prepared['proof']['固定取得入力']
    assert C.feature_sha(context.features) == prepared['pure']['proof']['features_sha256']
    horizon_spec = context.table.evidence['条件']['horizons']
    assert [row['id'] for row in horizon_spec] == list(context.table.horizons)
    parts = []
    for si, (scene, records) in enumerate(zip(context.scenes, prepared['records'], strict=True)):
        cases = assert_entry_rows(context, si, records)
        entries = np.asarray(context.arrays['entry_index'][cases], dtype=np.int64)
        local = early.evaluate_records(records, entries, float(scene['end']), list(context.table.widths), horizon_spec)
        parts.append((cases, local))
    overlay = join_overlay(parts, len(context.table.case_ids), list(context.table.widths), horizon_spec)
    context.arrays.update(overlay)
    context = connect_clock(context)
    context.financial_attached = True
    assert np.array_equal(context.arrays['label'] == 2, ~context.arrays['known'])
    limits = np.broadcast_to(context.deadlines[context.case_scene, None, None, None], context.arrays['known'].shape)
    assert np.all(context.arrays['exit_time'][context.arrays['known']] <= limits[context.arrays['known']])
    proof = {'成功': True, '金融接続済み': True, '未評価入力': prepared['proof'],
             '金融Source': N.ref(Path(early.__file__)), '条件': early.CONFIG, 'status名': early.STATUS,
             '場別計算後にcase位置結合': True, '入口再探索なし': True,
             '配列': {key: {'shape': list(value.shape), 'dtype': str(value.dtype)} for key, value in overlay.items()}}
    assert all(N.ref(ROOT / row['path']) == row for row in prepared['proof']['Source'])
    return {'context': context, 'captures': C.M.B.captures(context), 'proof': proof, 'overlay': overlay,
            'pure': prepared['pure'], 'financial_attached': True,
            'case_index': C.case_mapping(context, prepared['pure']['price_index'])}


def artificial() -> dict:
    """
    機能: 全体case順・非連続位置の場別結合・未知保持を人工値だけで確認する。
    引数: なし。
    返り値: dictは非金融の人工検査票。evaluate_recordsは呼ばない。
    """
    _, _, early = modules()
    fixed = {'expected_entry_count': 3, 'scenes': [
        {'entries': [{'id': 'c'}, {'id': 'a'}]}, {'entries': [{'id': 'b'}]}, {'entries': []}]}
    assert [(si, row['id']) for si, row in fixed_entries(fixed)] == [(0, 'a'), (1, 'b'), (0, 'c')]
    widths = [125, 250]
    horizons = [{'id': 'H60', 'kind': 'strict', 'seconds': 3600}]
    parts = []
    for cases in (np.array([2, 0]), np.array([1]), np.array([], dtype=np.int64)):
        values = early.allocate(len(cases), widths, horizons)
        for i, case in enumerate(cases):
            values['status'][i] = 100 + case
            values['holding_confirmed_until'][i] = 1000 + case
        parts.append((cases, values))
    merged = join_overlay(parts, 3, widths, horizons)
    np.testing.assert_array_equal(merged['status'][:, 0, 0, 0], [100, 101, 102])
    np.testing.assert_array_equal(merged['unknown_hold_lower_end'][:, 1, 1, 0], [1000, 1001, 1002])
    assert not merged['known'].any() and np.isnan(merged['net']).all()
    assert not merged['pair_complete'].any() and np.isnan(merged['pair_known_at']).all()
    return {'成功': True, 'ID辞書順と場対応': True, '非連続case位置へ結合': True,
            'caseゼロの場': True, '未知NaNと既知旗を保持': True, '自然金融未実行': True}


def verify_prepare() -> dict:
    """
    機能: 旧本日1の未評価全配列同体と追加2場の取得対応・時計を金融前に検査する。
    引数: なし。
    返り値: dictはSource固定前の検査票。自然金融・先着ラベルの読込/計算は行わない。
    """
    C, _, _ = modules()
    synthetic = artificial()
    old_pure = C.load_pure_leg('本日1')
    actual = load_unvalued_context(old_pure)['context']
    legacy = N.module(ROOT / 'work/180本日デイ適用/入力180.py', 'input180_reference194').load_context()['context']
    assert C.feature_sha(actual.features) == C.feature_sha(legacy.features)
    for key in ('case_ids', 'sessions', 'session_order', 'widths', 'horizons', 'horizon_ids', 'status_names'):
        assert getattr(actual.table, key) == getattr(legacy.table, key), key
    for name in ('arrays',):
        left, right = getattr(actual, name), getattr(legacy, name)
        assert set(left) == set(right)
        for key in left:
            assert left[key].dtype == right[key].dtype
            np.testing.assert_array_equal(left[key], right[key], err_msg='旧本日1 context/' + key)
    assert set(actual.table.arrays) == set(legacy.table.arrays)
    for key, value in actual.table.arrays.items():
        assert value.dtype == legacy.table.arrays[key].dtype
        np.testing.assert_array_equal(value, legacy.table.arrays[key], err_msg='旧本日1 table/' + key)
    for key in ('sessions', 'capture_rows', 'event_keys', 'end_keys', 'case_map'):
        assert getattr(actual, key) == getattr(legacy, key), key
    for key in ('case_scene', 'starts', 'event_scenes', 'event_phases', 'event_cases', 'hours', 'case_phases'):
        np.testing.assert_array_equal(getattr(actual, key), getattr(legacy, key), err_msg=key)
    pure = N.load_pure_leg()
    loaded = load_unvalued_context(pure)
    context = connect_clock(loaded['context'])
    assert_unvalued(context)
    result = {'成功': True, '金融未実行': True, '追加二場損益ラベル未読': True, '人工': synthetic,
              '旧本日1': {'未評価context全配列同体': True, '未評価table全配列同体': True,
                         'q0数': len(actual.event_keys), 'case数': len(actual.table.case_ids)},
              '追加二場': loaded['proof'], '終了時計': {'cut': context.deadlines.tolist(),
                  'submit': context.close_submits.tolist(), '帯別時間': context.hours.tolist()},
              'Source': source_refs()}
    N.save_once(CHECK, result)
    print(json.dumps({'成功': True, '金融未実行': True, '旧本日1未評価同体': True,
        '場別取得': loaded['proof']['場別確認'], 'shape': loaded['proof']['shape'], '検査票': N.ref(CHECK)}, ensure_ascii=False), flush=True)
    return result


# ----------------------------------------
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='194 NK金融接続の非金融検査だけを実行する。')
    parser.add_argument('--prepare', action='store_true')
    args = parser.parse_args()
    if args.prepare:
        verify_prepare()
    else:
        print(json.dumps({'準備API': 'load_unvalued_context(pure)',
            '金融API': 'root封印・指示後だけattach_financial(context)', 'Source': N.ref(Path(__file__))}, ensure_ascii=False))
