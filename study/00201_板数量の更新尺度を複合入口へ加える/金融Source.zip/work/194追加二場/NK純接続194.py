"""固定174→177/178→179を任意の当時特徴へ接続する。金融計算は行わない。"""
from pathlib import Path
from types import SimpleNamespace
import argparse
import hashlib
import importlib.util
import json
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
DEST = ROOT / 'inputs/00194_20261116夜と1117昼の固定適用入力/NK225'
PURE = DEST / '固定基準の純接続'
CHECK = HERE / 'NK旧三期間の純出生同体.json'
LEG = '追加2'
SCENES = ('2026-11-16_Night', '2026-11-17_Day')
HORIZONS = ['H30', 'H60', 'H120', 'SESSION']
FIXED = {
    '174': ROOT / 'work/174参加と両中央値の再探索/旧73jointの固定選択.json',
    '177': ROOT / 'work/177高ADX枝の増分比較/旧73の固定選択.json',
    '178': ROOT / 'work/178新枝の確認比較/旧73の固定選択.json',
    '179': ROOT / 'work/179保有参加の探索/旧73の固定選択.json',
}
IDENTITIES = {'174': '全期_J002', '177': '全期_J002_J000',
              '178': '全期_J002_J000_K012', '179': '全期_J035'}
RULE_KEYS = ('id', 'source', 'family', 'rule', 'rule_id', 'mode', 'orientation',
             'width', 'horizon', 'birth_key', 'gate')


def module(path: Path, name: str) -> object:
    """
    機能: 同名helperの衝突を避け、専用名で固定Sourceを読み込む。
    引数: path(Path)はSource、name(str)は専用module名。
    返り値: objectは読込済みmodule。金融初期化は呼ばない。
    """
    if name in sys.modules:
        result = sys.modules[name]
        assert Path(result.__file__).resolve() == path.resolve()
        return result
    sys.path.insert(0, str(path.parent))
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    sys.modules[name] = result
    spec.loader.exec_module(result)
    return result


def ref(path: Path) -> dict:
    """
    機能: 入力やSourceを複製せず、物理指紋を記録する。
    引数: path(Path)はリポジトリ内ファイル。
    返り値: dictはpath/bytes/sha256。
    """
    path = path.resolve()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size, 'sha256': digest}


def save_once(path: Path, body: dict) -> None:
    """
    機能: 日本語UTF-8で保存し、再実行時は既存内容との同体を確認する。
    引数: path(Path)は保存先、body(dict)は非金融記録。
    返り値: None。内容の異なる既存記録を上書きしない。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert json.loads(path.read_text(encoding='utf-8')) == body, str(path)
    else:
        path.write_text(json.dumps(body, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def common() -> object:
    """
    機能: 181の純APIを正規名で取得する。
    引数: なし。
    返り値: objectは共用181。金融APIは使用しない。
    """
    return module(ROOT / 'work/181共用接続/共用181.py', '共用181')


def policies() -> dict:
    """
    機能: 固定IDの技術条件だけを取り出し、金融順位欄を計算へ渡さない。
    引数: なし。
    返り値: dictは174/177/178/179の固定政策。
    """
    result = {}
    for trial, path in FIXED.items():
        body = json.loads(path.read_text(encoding='utf-8'))
        selected = next(row for row in body['選択']['全期']['candidates'] if row['id'] == IDENTITIES[trial])
        policy = {key: selected[key] for key in ('id', 'base', 'parent', 'route', 'fallback',
            'fallback_by_band', 'day_fallback_after_minutes', 'gate_by_band') if key in selected}
        if 'options' in selected:
            policy['options'] = {band: [{key: rule[key] for key in RULE_KEYS if key in rule} for rule in rules]
                                 for band, rules in selected['options'].items()}
        if 'changes' in selected:
            policy['changes'] = {band: {'mode': change['mode'],
                'rules': [{key: rule[key] for key in RULE_KEYS if key in rule} for rule in change['rules']]}
                for band, change in selected['changes'].items()}
        result[trial] = policy
    assert result['177']['base'] == result['174']['id']
    assert result['178']['base'] == result['174']['id']
    assert result['178']['parent'] == result['177']['id']
    assert result['179']['base'] == '178/' + result['178']['id']
    return result


def build(features: object) -> dict:
    """
    機能: 旧174幹・177夜間枝の178実側確認・179デイLCを同じSourceで再生成する。
    引数: features(FeatureDataset互換)は当時100特徴・q0メタデータ・場順。
    返り値: dictの全期_J035/旧178_新時計がbirth4・mw/fw/hi/addedを保持する。
            取得・将来ラベル・損益は計算しない。夜間をゼロ化しない。
    """
    C = common()
    fixed = policies()
    phases = np.asarray(features.q0_timeband)
    assert phases.shape == (len(features.q0_meta),) and np.isin(phases, (0, 1, 2)).all()
    old = module(ROOT / 'work/174追加七場適用/固定政策を適用する.py', 'adapter174_for194')
    stage = module(old.STAGE_SOURCE, 'delay174_for194')
    helper178 = module(ROOT / 'work/178追加七場適用/固定政策を適用する.py', 'adapter178_for194')
    verification = module(helper178.SOURCE, 'verification178_for194')
    builder177 = module(ROOT / 'work/177高ADXの増分純入口/rules177.py', 'rules177_for194')
    gates = module(helper178.GATES, 'gates178_for194')
    builder179 = module(ROOT / 'work/179量と構造の純入口/rules179.py', 'rules179_for194')

    # ----------------------------------------
    inherited = fixed['174']
    directions = old.build_directions(features, [inherited])
    base, _, _ = old.B.P.baseline(SimpleNamespace(features=features))
    birth, mw, fw, hi, _, _ = old.compose(phases, inherited['options'], directions,
        base['technical'], base['tier'], HORIZONS,
        inherited.get('fallback_by_band', inherited.get('fallback', False)))
    birth = stage.delay_day_fallback(birth, phases,
        np.asarray([row['session_index'] for row in features.q0_meta]),
        [(row['q0_time'], row['q0_index'], row['q0_line']) for row in features.q0_meta],
        np.asarray([row['start'] for row in features.scenes]), inherited.get('day_fallback_after_minutes', 45))
    base174 = {**birth, 'mw': mw, 'fw': fw, 'hi': hi}

    # ----------------------------------------
    # 178は177の実方向へゲートを掛け、174幹へ合成する。177枝を二重追加しない。
    gated, _ = helper178.directions(features, [fixed['178']], [fixed['177']], builder177, gates, verification)
    birth, mw, fw, hi, _, _ = verification.P.combine(base174, phases, fixed['178']['options'], gated, HORIZONS)
    base178 = {**birth, 'mw': mw, 'fw': fw, 'hi': hi}
    contrast = {'birth': {key: value.copy() for key, value in birth.items()},
                'mw': mw.copy(), 'fw': fw.copy(), 'hi': hi.copy(), 'added': np.zeros(len(phases), bool)}

    # ----------------------------------------
    selected = fixed['179']
    rules = {rule['birth_key']: rule for change in selected['changes'].values() for rule in change['rules']}
    ids = sorted({rule['rule_id'] for rule in rules.values()})
    born = builder179.build(features, np.asarray([row['start'] for row in features.scenes]), phases, candidate_ids=ids)
    assert born['candidate_ids'] == ids and np.array_equal(born['phases'], phases)
    raw = {identity: born['directions'][i] for i, identity in enumerate(ids)}
    directions179 = {}
    for key, rule in rules.items():
        assert rule['orientation'] in ('NORMAL', 'REVERSE')
        directions179[key] = raw[rule['rule_id']] if rule['orientation'] == 'NORMAL' else -raw[rule['rule_id']]
    context = SimpleNamespace(event_phases=phases, table=SimpleNamespace(horizons=HORIZONS))
    with C.temporary(CTX=context, DIRS=directions179, SEALS={selected['base']: base178}):
        main_birth, main_mw, main_fw, main_hi, added = C.P.compose(selected)
    result = {'全期_J035': {'birth': main_birth, 'mw': main_mw, 'fw': main_fw, 'hi': main_hi, 'added': added},
              '旧178_新時計': contrast}
    for bundle in result.values():
        for array in [*bundle['birth'].values(), *[bundle[key] for key in C.PARAM_KEYS]]:
            assert len(array) == len(phases)
            array.setflags(write=False)
    return result


def source_refs() -> list:
    """
    機能: 実際に読み込んだリポジトリ内Sourceと固定技術票を列挙する。
    引数: なし。
    返り値: list[dict]は内容指紋。金融出力ファイルを含めない。
    """
    paths = {Path(__file__).resolve(), *FIXED.values(), ROOT / 'work/163任意幅Raw索引/観測条件の雛形.json'}
    for loaded in list(sys.modules.values()):
        name = getattr(loaded, '__file__', None)
        if name:
            path = Path(name).resolve()
            if path.suffix == '.py' and path.is_relative_to(ROOT) and 'site-packages' not in path.parts:
                paths.add(path)
    return [ref(path) for path in sorted(paths)]


def verify_old() -> dict:
    """
    機能: 旧73・追加7・本日1の2基準×8配列を181純基準と全件比較する。
    引数: なし。
    返り値: dictは一致数・当時特徴指紋・Source。金融は付与しない。
    """
    C = common()
    results = []
    for leg in C.LEGS:
        pure = C.load_pure_leg(leg)
        assert not pure['context'].financial_attached and pure['context'].arrays == {}
        regenerated = build(pure['features'])
        assert set(regenerated) == set(pure['baselines'])
        checks = []
        for identity, actual in regenerated.items():
            expected = pure['baselines'][identity]
            for key in C.BIRTH_KEYS + C.PARAM_KEYS:
                a = actual['birth'][key] if key in C.BIRTH_KEYS else actual[key]
                b = expected['birth'][key] if key in C.BIRTH_KEYS else expected[key]
                assert a.dtype == b.dtype, (leg, identity, key, a.dtype, b.dtype)
                np.testing.assert_array_equal(a, b, err_msg=f'{leg}/{identity}/{key}')
                checks.append(identity + '/' + key)
        result = {'期間': leg, '場数': len(pure['features'].scenes), 'q0': len(pure['features'].q0_meta),
                  '特徴SHA256': C.feature_sha(pure['features']), '全件一致配列': checks}
        results.append(result)
        print(json.dumps({'成功': True, '段階': '旧純出生同体', **result}, ensure_ascii=False), flush=True)
    proof = {'成功': True, '金融未入力': True, '期間': results, 'Source': source_refs(), '固定政策': policies()}
    save_once(CHECK, proof)
    return proof


def load_pure_leg() -> dict:
    """
    機能: 旧同体検査に合格したSourceだけを追加2場の当時特徴へ接続する。
    引数: なし。
    返り値: dictは181互換の純context・features・baselines・索引・入力指紋。
    """
    C = common()
    checked = json.loads(CHECK.read_text(encoding='utf-8'))
    assert checked['成功'] and checked['金融未入力']
    assert [row['期間'] for row in checked['期間']] == list(C.LEGS)
    assert all(ref(ROOT / row['path']) == row for row in checked['Source'])
    directory = DEST / '入口母集団'
    features, captures, _ = C.P.B.P.R168.BASE.load_features(directory)
    assert tuple(row['session'] for row in features.scenes) == SCENES
    axes = json.loads((ROOT / 'work/163任意幅Raw索引/観測条件の雛形.json').read_text(encoding='utf-8'))
    event_scene = np.asarray([row['session_index'] for row in features.q0_meta], dtype=np.int16)
    context = SimpleNamespace(features=features, scenes=features.scenes, sessions=list(SCENES), capture_rows=captures,
        event_phases=np.asarray(features.q0_timeband), event_scenes=event_scene,
        event_keys=[(row['q0_time'], row['q0_index'], row['q0_line']) for row in features.q0_meta],
        table=SimpleNamespace(widths=tuple(axes['widths']), horizons=tuple(row['id'] for row in axes['horizons'])),
        arrays={}, financial_attached=False)
    manifest_path = DEST / '原板数値索引/manifest.json'
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    assert manifest['success'] and tuple(row['session'] for row in manifest['scenes']) == SCENES
    rows = []
    for row in manifest['scenes']:
        path = manifest_path.parent / row['index']['path']
        assert path.resolve().parent == manifest_path.parent.resolve()
        rows.append({'session': row['session'], 'contract': row['contract'], 'path': path.relative_to(ROOT).as_posix(),
                     'sha256': row['index']['sha256'], 'rows': row['rows']})
    inputs = [ref(directory / name) for name in ('完了.json', '出生台帳.json.gz', '当時特徴.json.gz',
                                               '取得対応.json.gz', '物理取得.json.gz', '固定取得入力.json.gz')]
    masks = {name: np.zeros(2, bool) for name in ('前48', '後25', '追加7', '本日1')}
    masks.update({'全対象': np.ones(2, bool), LEG: np.ones(2, bool)})
    result = {'leg': LEG, 'context': context, 'features': features, 'baselines': build(features),
              'price_index': {'manifest': ref(manifest_path), 'scenes': rows},
              'scene_masks': masks, 'event_scene': event_scene,
              'proof': {'成功': True, '金融未入力': True, 'features_sha256': C.feature_sha(features),
                        'q0': len(features.q0_meta), '場数': 2, '開始待機': 0, '終了時計': '179固定のcut/submit',
                        '旧同体検査': ref(CHECK), '当時入力': inputs, 'adapter': ref(Path(__file__))}}
    assert all(ref(ROOT / row['path']) == row for row in checked['Source'])
    return result


def load_q0(pure: dict) -> dict:
    """
    機能: 追加2場の同一q0原行価格を194配下に限って保存・照合する。
    引数: pure(dict)はload_pure_legの返り値。
    返り値: dict[str,np.ndarray]はlast/bid/ask/time/line/normal。
    """
    assert pure['leg'] == LEG and not pure['context'].financial_attached
    helper = module(ROOT / 'work/183単純IFD検証/当時価格183.py', 'q0_for194')
    previous = helper.DEST
    try:
        helper.DEST = DEST / '判断時点価格'
        result = helper.load_q0(pure)
    finally:
        helper.DEST = previous
    return result


def seal() -> dict:
    """
    機能: 追加2場の純基準と同原行q0価格・Source指紋を金融前に封印する。
    引数: なし。
    返り値: dictは封印参照。追加2場の金融・先着ラベルは読まない。
    """
    pure = load_pure_leg()
    C = common()
    sealed = C.seal_pure_leg(pure, PURE)
    prices = load_q0(pure)
    # 起動時のimport履歴を使わず、旧同体検査の依存集合と純価格抽出Sourceへ固定する。
    checked = json.loads(CHECK.read_text(encoding='utf-8'))
    dependencies = {row['path']: row for row in checked['Source']}
    for path in (ROOT / 'work/183単純IFD検証/当時価格183.py', ROOT / 'work/163任意幅の数値化/arrays163.py'):
        value = ref(path)
        dependencies[value['path']] = value
    result = {'成功': True, '金融未入力': True, '追加二場損益ラベル未読': True,
              '固定基準': sealed, '当時価格': ref(DEST / '判断時点価格/追加2_q0.json'),
              '当時価格NPZ': ref(DEST / '判断時点価格/追加2_q0.npz'), '旧同体検査': ref(CHECK),
              '入力': pure['proof'], 'Source': [dependencies[key] for key in sorted(dependencies)],
              'q0': len(prices['time']), '正常板q0': int(prices['normal'].sum())}
    save_once(PURE / '純接続完了194.json', result)
    print(json.dumps({'成功': True, '段階': '追加二場純接続', 'q0': result['q0'],
                      '正常板q0': result['正常板q0'], '完了票': ref(PURE / '純接続完了194.json')}, ensure_ascii=False), flush=True)
    return result


# ----------------------------------------
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='194の純接続専用。金融計算は実行しない。')
    parser.add_argument('--stage', choices=('verify', 'seal', 'all'), default='all')
    args = parser.parse_args()
    if args.stage in ('verify', 'all'):
        verify_old()
    if args.stage in ('seal', 'all'):
        seal()
