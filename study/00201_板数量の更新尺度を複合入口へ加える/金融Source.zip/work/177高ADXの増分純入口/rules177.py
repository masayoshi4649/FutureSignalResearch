"""175/176の高ADX四群を元の時計のまま識別して包む純入口。"""
from copy import deepcopy
import hashlib
from pathlib import Path
import sys

import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work/175局面別の純入口'))
sys.path.insert(0,str(ROOT/'work/176局面別の役割票'))
import rules175 as S175
import rules176 as S176

VERSION='177高ADXの増分純入口1'
GROUPS=('HT','HB','HR','HM')
SOURCES={'S175':S175,'S176':S176}


def candidate_catalog() -> list[dict]:
    """
    機能: 元の高ADX四群768候補へSource識別と最終ADXゲートだけを加える。
    引数: なし。
    返り値: list[dict]は出典付き固定候補。元の閾値・確認秒・ALL/EDGEは保持する。
    """
    rules=[]
    for source_id,module in SOURCES.items():
        for original in module.candidate_catalog():
            if original['group'] not in GROUPS:continue
            rule=deepcopy(original)
            rule.update({'id':source_id+'_'+original['id'],
                'logical_id':source_id+'_'+original['logical_id'],
                'source_id':source_id,'source_rule_id':original['id'],
                'source_version':module.VERSION,
                'final_direction_gate':{'factor':'m15_adx','operator':'>','threshold':20,
                    'timing':'元Sourceの確認とALL/EDGE適用後に当該実側へ適用。再EDGE化しない。'}})
            rules.append(rule)
    assert len(rules)==768 and len({r['id'] for r in rules})==768
    return rules


def catalog() -> dict:
    """
    機能: 出典指紋と768候補の同体性・増分比較上の役割を公開する。
    引数: なし。
    返り値: dictは純辞書。自然特徴・取得・金融を読まない。
    """
    records=[]
    for source_id,module in SOURCES.items():
        path=Path(module.__file__)
        records.append({'source_id':source_id,'version':module.VERSION,
            'path':path.relative_to(ROOT).as_posix(),
            'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    return {'version':VERSION,'candidate_count':768,'logical_count':384,
        'rules':candidate_catalog(),'sources':records,
        'input':'当時の実側100特徴・q0_meta・場開始秒だけ。金融と教師は未入力。',
        'gate':'元175/176の最終方向に、その実側m15_adxが既知かつ20超の場合だけ通す。',
        'clock':'元Sourceの履歴reset・確認秒・ALL/EDGE時計を変更せず、ゲート後にEDGEを計算し直さない。',
        'comparison':'174固定幹を維持した上で幹無成立時だけ加える新枝候補。純builderは174の金融・予約・数量・Tを実装しない。',
        'orientation':'純辞書768。正方向/逆方向は後段予備評価の別軸で、純候補数に二重計上しない。',
        'limitations':['ADXは方向を表さず、各Sourceの複数技術が方向・構造・動力を分担する。',
            '175/176の既使用結果を踏まえた追加比較であり、独立な未見性能ではない。',
            '元EDGE成立時にゲート不成立なら後でADXが20を超えても再発火させない。',
            '追加ゲートを除く新しい閾値は導入しない。']}


def build(features: object,scene_starts: object=None,phases: object=None,candidate_ids: list|None=None) -> dict:
    """
    機能: 元Sourceの方向へ当時ADXの最終ゲートだけを適用する。
    引数: features(object)は当時100特徴、scene_starts(object|None)は場開始秒、
          phases(object|None)は診断用帯、candidate_ids(list[str]|None)は部分集合。
    返り値: dictはcandidate_ids/directions[候補,N]int8と純診断。金融は含まない。
    """
    if scene_starts is None:scene_starts=S175._get(features,'scene_starts')
    rules=candidate_catalog()
    if candidate_ids is not None:
        requested=set(candidate_ids);assert len(requested)==len(candidate_ids)
        mapping={r['id']:r for r in rules};assert requested<=set(mapping)
        rules=[mapping[name] for name in candidate_ids]
    columns=list(S175._get(features,'columns'));column=columns.index('m15_adx')
    buy=np.asarray(S175._get(features,'buy_X'))[:,column]
    sell=np.asarray(S175._get(features,'sell_X'))[:,column]
    buy_gate=np.isfinite(buy)&(buy>20);sell_gate=np.isfinite(sell)&(sell>20)
    n=len(buy);matrix=np.zeros((len(rules),n),dtype=np.int8);diagnostics={}
    for source_id,module in SOURCES.items():
        positions=[i for i,rule in enumerate(rules) if rule['source_id']==source_id]
        if not positions:continue
        result=module.build(features,scene_starts,phases,
            candidate_ids=[rules[i]['source_rule_id'] for i in positions])
        raw=result['directions']
        # ----------------------------------------
        # 元の確認とALL/EDGEを完了した方向だけを遮断し、再発火は生成しない。
        matrix[positions]=np.where(((raw==1)&buy_gate)|((raw==-1)&sell_gate),raw,0)
        diagnostics[source_id]=result['diagnostics']
    output={'version':VERSION,'candidate_ids':[r['id'] for r in rules],
        'directions':matrix,'diagnostics':{'sources':diagnostics,
            'buy_adx_gate':buy_gate,'sell_adx_gate':sell_gate}}
    if phases is not None:
        values=np.asarray(phases);assert values.shape==(n,) and np.isin(values,(0,1,2)).all()
        output['phases']=values.copy()
    return output
