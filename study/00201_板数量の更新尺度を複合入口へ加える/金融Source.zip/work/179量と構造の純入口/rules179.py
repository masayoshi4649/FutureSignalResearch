"""179の量と価格回復を組み合わせた純入口。金融・保有・損益は入力しない。"""
from itertools import product
from pathlib import Path
import sys

import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work/175局面別の純入口'))
import rules175 as P
from rules162 import term

VERSION='179量と構造の純入口1'
GROUPS={
    'TF':'背景順行の押戻し回復',
    'BR':'価格端への接近と回復・突破',
    'RV':'反対圧力の失速後に構造を回復',
    'MX':'背景混在から短期方向を整理',
    'RG':'BB帯端から内側への回復',
    'LC':'長期増分未公表時の局所複合',
}
RAW_COLUMNS=tuple(sorted(set(
    [f'm{m}_{name}' for m in (5,15,30) for name in ('ema21_delta_to_side','di_difference_to_side')]
    +['m5_gap_to_side','m5_hist_delta_to_side','m5_hist_delta_atr_to_side','m5_rsi_delta_to_side',
      'm5_rsi_center_to_side','m5_price_ema8_atr_to_side','m15_hist_delta_to_side','m15_adx',
      'm15_adx_delta','m1_body_ratio_to_side','m1_previous_body_ratio_to_side',
      'm1_close_delta_atr5_to_side','m1_body_reclaim_atr5_to_side','q0_last_minus_m1_close_atr5_to_side',
      'm5_body_ratio_to_side','m1_volume_relative_prior3',
      'm1_tr_atr5_ratio','m5_tr_previous_atr_ratio','q0_entry_minus_ema8_atr5_to_side',
      'q0_last_minus_prior3_forward_edge_atr5_to_side','bb15_position_sigma_to_side',
      'bb15_mean_room_125_ratio_to_side','q0_spread_points'])))


def candidate_catalog() -> list[dict]:
    """
    機能: 六群の背景・構造・動力へ三量方式と量なし対照を組み込む。
    引数: なし。
    返り値: list[dict]は6群×48論理×ALL/EDGE=576候補の全閾値。
    """
    rules=[]
    for group in GROUPS:
        for number,(profile,volume_mode,alignment,trigger) in enumerate(product((0,1),range(4),(0,1),range(3)),1):
            required=1+alignment
            conditions=[term('q0_spread_points','>',0),term('q0_spread_points','<=',20),
                term('abs_q0_close_gap','<=',1),
                term('q0_entry_minus_ema8_atr5_to_side','>=',-2+.5*profile),
                term('q0_entry_minus_ema8_atr5_to_side','<=',1.5-.5*profile),
                term('m1_tr_atr5_ratio','<=',2-.25*profile),
                term('m5_tr_previous_atr_ratio','<=',3.5-.5*profile),
                term('n_abs_rsi_delta5','<=',12-4*profile),
                term('p179_momentum','>=',required),
                term(f'p179_structure|{group}|{profile}|{trigger}','>',.5),
                term(f'p179_volume|{volume_mode}|{profile}','>',.5)]
            if group=='TF':
                conditions += [term('m15_adx','>=',15+5*profile),term('long_up_votes','>=',required),
                    term('short_up_votes','>=',required),term('m5_rsi_center_to_side','<=',30-5*profile)]
            elif group=='BR':
                conditions += [term('m15_adx','>=',12+6*profile),term('m15_adx_delta','>=',-1+.5*profile),
                    term('long_up_votes','>=',required),term('short_up_votes','>=',required),
                    term('q0_last_minus_prior3_forward_edge_atr5_to_side','>',-.1+.1*profile),
                    term('m5_rsi_center_to_side','<=',30-5*profile)]
            elif group=='RV':
                conditions += [term('m15_adx','>=',12+6*profile),term('m15_adx_delta','<=',.5-.5*profile),
                    term('long_up_votes','<=',3-alignment),term('short_up_votes','>=',required),
                    term('bb15_position_sigma_to_side','<=',1-.5*profile)]
            elif group=='MX':
                conditions += [term('m15_adx','>=',10+5*profile),term('m15_adx','<=',40),
                    term('long_up_votes','>=',1),term('long_up_votes','<=',3),
                    term('short_up_votes','>=',required),term('m5_rsi_center_to_side','<=',30-5*profile)]
            elif group=='RG':
                conditions += [term('m15_adx','<=',25-5*profile),term('long_up_votes','<=',3-alignment),
                    term('bb15_position_sigma_to_side','<=',-.5*profile),
                    term('bb15_mean_room_125_ratio_to_side','>',0),
                    term('m5_rsi_center_to_side','<=',15-5*profile)]
            else:
                conditions += [term('p175_local_allowed','>',.5),term('short_up_votes','>=',required),
                    term('m5_rsi_center_to_side','>=',-10),term('m5_rsi_center_to_side','<=',30-5*profile)]
            logical=f'V{group}{number:04d}'
            for mode in ('ALL','EDGE'):
                rules.append({'id':logical+'_'+mode,'logical_id':logical,'group':group,'family':group,
                    'description':GROUPS[group],
                    'technical_families':['EMA/DIの局所方向' if group=='LC' else 'EMA/DI/ADXの背景',
                        'MACD/RSIの動力','価格構造','ATR/鮮度/取得位置']
                        +(['BB'] if group in ('RV','RG') else [])+([] if volume_mode==0 else ['観測相対量']),
                    'timeframes':[1,5] if group=='LC' else [1,5,15,30],
                    'settings':{'profile':profile,'volume_mode':f'V{volume_mode}',
                        'relative_volume_min':None if volume_mode==0 else .25+.25*profile,
                        'relative_volume_recovery_ratio':1+.1*profile if volume_mode==2 else None,
                        'spike_volume_threshold':2.5-.5*profile if volume_mode==3 else None,
                        'direction_or_momentum_min':required,
                        'structure_mode':('現在価格回復','履歴イベント','いずれか')[trigger],
                        'window_minutes':5+5*profile,'confirmation_seconds':0,'initial_wait_minutes':0,
                        'geometry_points':200},
                    'mode':mode,'confirmation_seconds':0,'conditions':conditions})
    assert len(rules)==576 and len({r['id'] for r in rules})==576
    return rules


def catalog() -> dict:
    """
    機能: 純候補と、量・構造の役割、未知、公表時計の意味を公開する。
    引数: なし。
    返り値: dictは固定用辞書。自然価格・金融・保有状態を読まない。
    """
    return {'version':VERSION,'candidate_count':576,'logical_count':288,'groups':GROUPS,
        'rules':candidate_catalog(),'raw_columns':list(RAW_COLUMNS),
        'volume_modes':{'V0':'量なし対照。量列を要求せず、背景/構造/動力/品質だけ。',
            'V1':'相対量下限.25/.5だけ。1超の出来高増を意味しない。',
            'V2':'V1＋相対量が直前q0の1/1.1倍以上＋当時価格の回復。生の絶対量増加とは異なる。',
            'V3':'V1＋相対量>2.5/2と大値幅又は追いかけが同時に生じる局面を除く。'},
        'roles':'背景・構造・動力は各候補で必須。EMA/DI票は独立確率ではなく役割上の確認数。ADXだけで向きを決めない。',
        'unknown':'方向票・動力票は全必要列が既知。代替構造は必要列既知の一パターンが真なら成立し、全パターン既知で全偽なら非成立。他は未知。NaNを0票に補完しない。',
        'clock':'175純Evaluatorの場/scene/限月/gap>180秒resetを再用。元q0のみで最終ALL/EDGE。5/10実分窓と足幅を区別。開始固定待機/最終60秒確認なし。',
        'local':'LCは同場同限月でM15Hist増分が一度も公表されていない時だけ。gapで再許可せず、指標自体の助走は必要。',
        'scope':'保有/予約・held20%・15:30/05:45全決済・数量・費用は後段口座側の条件。純Sourceは未来損益や保有率を知らない。',
        'changes_from_175_176':['全ANDと60秒待機を増やすのでなく、現在価格回復を履歴イベントの代替にする。',
            '背景の必要票、ADX/RSI/取得位置の研究域を広げ、RGでは回復前のEMA/DI整列を一律要求しない。',
            '未使用の別代替パターンNaNが既知の回復パターンを拒否しない。',
            'LCの固定120/180分待機を置かず、公表済みの局所技術が揃ったq0から扱う。',
            '量なし/V1対照とV2/V3を同じ背景・構造・動力の中で比較できる。'],
        'limitations':['量はラージの観測累積差分由来で、mini実板・攻撃側約定フロー・吸収の直接観測ではない。',
            'BRのprofile0は価格端から.1ATR内側も許し、全件が完了済み突破ではない。',
            'RVの緩いprofileはADX小幅上昇も許すが、反対実体からの価格回復又は動力失速履歴を別に必須とする。',
            '本辞書の成立・取得・保有率・両中央値・利益集中への有効性は金融前に未確認。']}


class Evaluator179(P.Evaluator175):
    def derived(self,side: int,name: str) -> tuple:
        """
        機能: 既存因果factorだけから代替構造と量の純確認を作る。
        引数: side(int)は買0/売1、name(str)はp179派生名。
        返り値: tuple[np.ndarray,np.ndarray]は値と既知mask。
        """
        def value(column: str) -> tuple:
            """
            機能: 175から既存の純列又は因果派生を読む。
            引数: column(str)。
            返り値: tuple[np.ndarray,np.ndarray]。
            """
            return super(Evaluator179,self).factor(side,column)

        def compare(column: str,operator: str='>',threshold: float=0) -> tuple:
            """
            機能: 一つの比較と、その必要値の既知性を返す。
            引数: column/operator(str)、threshold(float)。
            返り値: tuple[np.ndarray,np.ndarray]。
            """
            data,known=value(column)
            operations={'>':np.greater,'>=':np.greater_equal,'<':np.less,'<=':np.less_equal}
            return operations[operator](data,threshold)&known,known

        def both(*items: tuple) -> tuple:
            """
            機能: 一パターンの全必要列が既知の場合だけ同時条件を評価する。
            引数: items(tuple)は成立/既知の組。
            返り値: tuple[np.ndarray,np.ndarray]。
            """
            known=np.logical_and.reduce([x[1] for x in items])
            return np.logical_and.reduce([x[0] for x in items])&known,known

        def either(*items: tuple) -> tuple:
            """
            機能: 代替の既知真があれば成立、全既知偽なら非成立、それ以外は未知とする。
            引数: items(tuple)は成立/既知の組。
            返り値: tuple[np.ndarray,np.ndarray]。未知を0票へ補完しない。
            """
            passed=np.logical_or.reduce([x[0]&x[1] for x in items])
            known=passed|np.logical_and.reduce([x[1] for x in items])
            return passed,known

        if name=='p179_momentum':
            a,ak=value('m5_hist_delta_to_side');b,bk=value('m5_rsi_delta_to_side');known=ak&bk
            result=(a>0).astype(float)+(b>0).astype(float)
            return np.where(known,result,np.nan),known
        parts=name.split('|')
        if parts[0]=='p179_structure':
            group=parts[1];profile=int(parts[2]);mode=int(parts[3]);window=5+5*profile
            body=compare('m1_body_ratio_to_side');live=compare('live_reclaim');advance=compare('m1_close_delta_atr5_to_side')
            if group=='TF':
                state=either(live,both(body,compare('m5_price_ema8_atr_to_side','>=',-.5+.25*profile)))
                event=compare(f'n_event|NP|{window}|{.25*profile}|0','>',.5)
            elif group=='BR':
                state=either(both(body,advance),both(live,compare('q0_last_minus_prior3_forward_edge_atr5_to_side','>',-.1+.1*profile)))
                event=compare(f'p175_break|{window}|{.1*profile}|0','>',.5)
            elif group=='RV':
                state=both(compare('m1_previous_body_ratio_to_side','<',0),body,either(live,advance))
                event=both(compare(f'n_event|NS|{window}|{4+4*profile}|0','>',.5),either(live,body))
            elif group=='MX':
                state=either(both(live,body),both(advance,compare('q0_last_minus_prior3_forward_edge_atr5_to_side','>=',-.25)))
                event=compare(f'n_event|NX|{window}|{2*profile}|0','>',.5)
            elif group=='RG':
                state=either(both(live,body),both(advance,compare('m5_body_ratio_to_side')))
                event=compare(f'n_event|NR|{window}|{.5+.5*profile}|0','>',.5)
            else:
                state=either(both(body,compare('m1_close_delta_atr5_to_side','>=',0)),both(live,compare('m5_body_ratio_to_side')))
                event=compare(f'n_event|NP|{window}|{.25*profile}|0','>',.5)
            passed,known=(state if mode==0 else event if mode==1 else either(state,event))
        elif parts[0]=='p179_volume':
            mode=int(parts[1]);profile=int(parts[2]);n=len(self.q0_meta)
            if mode==0:return np.ones(n),np.ones(n,bool)
            relative,rk=value('m1_volume_relative_prior3');passed=rk&(relative>=.25+.25*profile);known=rk
            if mode==2:
                previous=self.previous(relative);pk=np.isfinite(previous)
                recovery=either(both(compare('m1_body_ratio_to_side'),compare('m1_close_delta_atr5_to_side','>=',0)),
                    both(compare('live_reclaim'),compare('m1_close_delta_atr5_to_side')))
                known=rk&pk&recovery[1]
                passed &= pk&(relative>=previous*(1+.1*profile))&recovery[0]
            elif mode==3:
                tr1,k1=value('m1_tr_atr5_ratio');tr5,k5=value('m5_tr_previous_atr_ratio')
                chase,kc=value('q0_entry_minus_ema8_atr5_to_side');known=rk&k1&k5&kc
                spike=(relative>2.5-.5*profile)&((tr1>1.25-.25*profile)|(tr5>2-.5*profile)|(chase>1-.25*profile))
                passed &= ~spike
            elif mode!=1:raise KeyError('未定義の179量方式: '+name)
        else:raise KeyError('未定義の179派生: '+name)
        return np.where(known,passed.astype(float),np.nan),known

    def factor(self,side_index: int,name: str) -> tuple:
        """
        機能: 179の派生だけを追加し、他の公表・履歴規則は175を再用する。
        引数: side_index(int)、name(str)。
        返り値: tuple[np.ndarray,np.ndarray]は値と既知性。
        """
        if not name.startswith('p179_'):return super().factor(side_index,name)
        key=(side_index,name)
        if key not in self._factor_cache:self._factor_cache[key]=self.derived(side_index,name)
        return self._factor_cache[key]


def build(features: object,scene_starts: object=None,phases: object=None,candidate_ids: list|None=None) -> dict:
    """
    機能: 当時純特徴から179のmode適用済み候補方向を生成する。
    引数: features(object)は100特徴とq0_meta、scene_starts(object|None)は場開始秒、
          phases(object|None)は診断用、candidate_ids(list[str]|None)は部分集合。
    返り値: dictはcandidate_ids/directions[候補,N]int8と純履歴診断。金融を含まない。
    """
    if scene_starts is None:scene_starts=P._get(features,'scene_starts')
    evaluator=Evaluator179(features,scene_starts);rules=candidate_catalog()
    if candidate_ids is not None:
        requested=set(candidate_ids);assert len(requested)==len(candidate_ids)
        mapping={r['id']:r for r in rules};assert requested<=set(mapping)
        rules=[mapping[identity] for identity in candidate_ids]
    matrix=np.asarray([evaluator.evaluate_one(rule)['directions'] for rule in rules],dtype=np.int8)
    if not rules:matrix=np.zeros((0,len(evaluator.q0_meta)),dtype=np.int8)
    out={'version':VERSION,'candidate_ids':[r['id'] for r in rules],'directions':matrix,
        'diagnostics':{'history_reset':evaluator._reset175.copy(),
            'local_allowed':evaluator._local_allowed175.copy(),'elapsed_minutes':evaluator._elapsed.copy()}}
    if phases is not None:
        values=np.asarray(phases);assert values.shape==(matrix.shape[1],) and np.isin(values,(0,1,2)).all()
        out['phases']=values.copy()
    return out
