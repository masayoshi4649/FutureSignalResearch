"""177の追加枝だけに実際の取得方向の技術確認を加える。"""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime,timezone
from itertools import product
import argparse
import copy
import json
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).parent
TRIAL=ROOT/'study/00178_新枝の実方向と複数足の背景を確認する'
sys.path.insert(0,str(ROOT/'work/177高ADX枝の増分比較'))
import 増分177 as P
B=P.B
FIXED=ROOT/'work/177高ADX枝の増分比較/旧73の固定選択.json'
BUILDER=ROOT/'work/178新枝の実方向確認/gates178.py'
CATALOG=ROOT/'work/178新枝の実方向確認/候補辞書178.json'


def parents() -> list:
    """
    機能: 177の金融前固定された各route最大二案を保存順で返す。
    引数: なし。
    返り値: list[dict]。追加期間を見た並べ替えは行わない。
    """
    fixed=B.P.read(FIXED)['選択'];return [p for route in ('全期','前48') for p in fixed[route]['candidates']]


def freeze() -> None:
    """
    機能: 新枝の実方向確認と選択手順を金融前に固定する。
    引数: なし。
    返り値: None。
    """
    source=[Path(__file__),Path(P.__file__),FIXED,BUILDER,CATALOG,
        ROOT/'work/177高ADXの増分純入口/rules177.py',ROOT/'work/177高ADX枝の増分比較/純出生177.npz',
        ROOT/'work/175経路と支持の評価/path175.py',ROOT/'work/175局面別入口の再探索/基盤175.py',
        ROOT/'work/175局面別入口の再探索/数量段階を進める.py',ROOT/'work/173両中央値と単一建玉/基盤173.py',
        ROOT/'work/173追加なしの因果再生/engine173.py',ROOT/'work/173追加なしの評価/metrics173.py',
        ROOT/'work/174追加七場適用/旧73の純出生174.npz']
    body={'試行':178,'GO':True,'UTC':datetime.now(timezone.utc).isoformat(),
        '仮説':'177は支持を広げたが追加期間の方向悪化と全80Night中央値保留が残る。複数足の背景と実際の取得方向の動力・量が不足した可能性を新枝だけで検証する。',
        '親':'177固定全期2/前48二案。旧174幹とT・デイは変更せず、新枝にだけ実側ゲートを追加する。',
        'ゲート':'G00無追加/G01-L2/G02-L3/G03-L4/G04-L2+15分MACDヒストグラム変化が実側非負/G05-L3+同/G06-L2+量.75/G07-L3+同/G08-L2+5分DI正/G09-L3+同/G10-L2+5分MACDヒストグラムとRSIの改善/G11-L3+同。Lは15/30分EMA/DI四票。相対量.75は平常量超過ではなく低量の除外。G99は新枝なしの旧174対照。',
        '実側':'177の正逆反転後の取得向きで特徴を読む。未知不成立。元ALL/EDGEを保ち再EDGEしない。元の新枝の幅・期限を保つ。',
        '数量と費用':'177と同体。買売合計保有+pending1、q0→q1、mini1枚、片道38.5円+5ptと実BBO。IFD_FIRSTとN期限返済/C未知を保持。',
        '探索':'各親×PRE/POST×12ゲート+新枝無効の単独104政策。各帯で共同/支持/経路/率各2短表、G00対照を必ず残し最大8。PRE×POSTを親ごと64以下で再生。',
        '順位':'全Day/Night両中央値正・全場取得・先着70%(FA12/取得24/FA場6)を主支持として分ける。共同条件→PRE/POST支持目標の数→未知率→完全5/10場赤字窓割合→DD/既知利益→既知収支。小帯支持は順位であり硬い新必須条件ではない。',
        '期間':'旧73全期発見と前48選択を分離。追加7は選択固定後各route2案の参考適用だけ。全期/前半/後半/追加/全80を分け、既使用を未見と呼ばない。',
        '不変確認':'G00全帯は177固定全取得/金融同体、G99全帯は174固定と同体。旧試行を変更しない。',
        '出力':'CSVは候補別。未知None、既知寄与DDと全件DDを区別。',
        'Source':[P.ref(p) for p in source]}
    TRIAL.mkdir(parents=True,exist_ok=True);(TRIAL/'検査').mkdir(exist_ok=True)
    assert not (TRIAL/'条件.json').exists();B.P.save(TRIAL/'条件.json',body)
    print(json.dumps(P.ref(TRIAL/'条件.json'),ensure_ascii=False))


def birth() -> None:
    """
    機能: 177固定新枝の正逆方向へ実側ゲートを加え金融前に封印する。
    引数: なし。
    返り値: None。旧73の純出生だけを生成する。
    """
    fixed=B.P.read(TRIAL/'条件.json')
    for r in fixed['Source']:assert B.P.sha(ROOT/r['path'])==r['sha256']
    data=B.P.R168.BASE.data_module();features=data.load_feature_dataset()
    gates=B.P.module(BUILDER,'gates178_birth');rules={r['birth_key']:r for p in parents() for items in p['options'].values() for r in items}
    catalog=B.P.read(P.CATALOG)['rules'];indices={r['id']:i for i,r in enumerate(catalog)}
    output={}
    with np.load(ROOT/'work/177高ADX枝の増分比較/純出生177.npz',allow_pickle=False) as sealed:
        for key,r in rules.items():
            direction=sealed['directions'][indices[r['rule_id']]]*(1 if r['orientation']=='NORMAL' else -1)
            for i in range(12):output[f'G{i:02}|'+key]=gates.apply(features,direction,f'G{i:02}')
        output['phases']=sealed['phases']
    target=HERE/'純出生178.npz';assert not target.exists();np.savez_compressed(target,**output)
    B.P.save(target.with_suffix('.json'),{'成功':True,'金融未入力':True,'F0SHA256':B.P.sha(TRIAL/'条件.json'),'出生SHA256':B.P.sha(target),'方向数':len(output)-1})
    print(json.dumps({'成功':True,'純方向数':len(output)-1},ensure_ascii=False))


def initialize() -> None:
    """
    機能: 177の因果口座再生へ178純方向だけを接続する。
    引数: なし。
    返り値: None。
    """
    P.initialize()
    with np.load(HERE/'純出生178.npz',allow_pickle=False) as raw:
        assert np.array_equal(raw['phases'],P.CTX.event_phases)
        P.DIRS={k:raw[k].copy() for k in raw.files if k!='phases'}


def policy(parent: dict, band: str, gate: str) -> dict:
    """
    機能: 親の新枝へ共通ゲートを一度だけ付加する。
    引数: parent(dict)、band/gate(str)。
    返り値: dictは固定幹とゲート済みoptions。
    """
    rules=[] if gate=='G99' else copy.deepcopy(parent['options'][band])
    for rule in rules:rule['birth_key']=gate+'|'+rule['birth_key'];rule['gate']=gate
    return {'id':parent['id']+'_'+band+'_'+gate,'parent':parent['id'],'base':parent['base'],'route':parent['route'],'options':{band:rules},'gate_by_band':{band:gate}}


def run(name: str, policies: list) -> list:
    """
    機能: 政策群を先に固定し、旧73を因果再生する。
    引数: name(str)、policies(list)。
    返り値: list[dict]。
    """
    for r in B.P.read(TRIAL/'条件.json')['Source']:assert B.P.sha(ROOT/r['path'])==r['sha256']
    target=HERE/(name+'.json.gz');assert not target.exists()
    B.P.save(TRIAL/'検査'/('F2_'+name+'.json'),{'成功':True,'SourceSHA256':B.P.sha(Path(__file__)),'policies':policies,'追加7未読':True})
    with ProcessPoolExecutor(max_workers=4,initializer=initialize) as pool:rows=list(pool.map(P.evaluate,policies,chunksize=4))
    B.P.save(target,{'成功':True,'rows':rows});print(json.dumps({'成功':True,'段階':name,'政策数':len(rows)},ensure_ascii=False));return rows


def stages(stage: str) -> None:
    """
    機能: 帯別ゲート単独から三帯共同条件の固定候補へ進める。
    引数: stage(str)はsingle/joint。
    返り値: None。
    """
    policies=[]
    if stage=='single':
        initialize();checks=[]
        expected={r['id']:r for r in B.P.read(ROOT/'work/177追加七場適用/旧73の全取得177.json.gz')['rows']}
        baseline={r['id']:r for r in B.P.read(ROOT/'work/174追加七場適用/旧73の全取得174.json.gz')['rows']}
        for parent in parents():
            for gate,record in [('G00',expected[parent['id']]),('G99',baseline[parent['base']])]:
                options={b:policy(parent,b,gate)['options'][b] for b in ('PRE','POST')}
                birth,mw,fw,hi,_,_=P.combine(P.BASES[parent['base']],P.CTX.event_phases,options,P.DIRS,list(P.CTX.table.horizons))
                value=B.replay(P.CTX,birth,mw,fw,hi,True,P.CAPS)
                assert B.financial(P.CTX,value)==record['financial'],(parent['id'],gate)
                actual={'cases':value[0].cases.tolist(),'sides':value[0].sides.tolist(),'events':value[0].events.tolist(),
                    'phases':value[0].phases.tolist(),'origins':value[1].tolist(),'widths':value[2].tolist(),
                    'horizons':value[3].tolist(),'tiers':value[4].tolist(),'engine':value[5]}
                assert actual=={k:record[k] for k in actual},(parent['id'],gate)
                checks.append({'id':parent['id'],'gate':gate,'全金融全取得全engine一致':True})
        B.P.save(HERE/'両端対照の同体.json',{'成功':True,'checks':checks})
        for parent in parents():
            for band in ('PRE','POST'):
                for gate in [*[f'G{i:02}' for i in range(12)],'G99']:policies.append(policy(parent,band,gate))
        rows=run('帯別確認',policies);chosen={}
        for parent in parents():
            chosen[parent['id']]={}
            for band in ('PRE','POST'):
                subset=[r for r in rows if r['policy']['parent']==parent['id'] and band in r['policy']['options']]
                selected=P.rank(subset,parent['route'],band)
                control=next(r for r in subset if r['policy']['gate_by_band'][band]=='G00')
                if control['id'] not in {r['id'] for r in selected}:selected=selected[:7]+[control]
                chosen[parent['id']][band]=[r['policy'] for r in selected]
        B.P.save(HERE/'帯短表.json',{'成功':True,'選択':chosen})
    else:
        short=B.P.read(HERE/'帯短表.json')['選択']
        for parent in parents():
            bands=short[parent['id']]
            for i,(a,b) in enumerate(product(bands['PRE'],bands['POST'])):
                policies.append({'id':parent['id']+f'_K{i:03}','parent':parent['id'],'base':parent['base'],'route':parent['route'],
                    'options':{**a['options'],**b['options']},'gate_by_band':{**a['gate_by_band'],**b['gate_by_band']}})
        rows=run('三帯接合',policies);chosen={}
        for route in ('全期','前48'):
            def key(row: dict) -> tuple:
                """
                機能: 固定した主支持・未知・経路の順位を選択期間から作る。
                引数: row(dict)。
                返り値: tuple。
                """
                gs=[row['periods'][route][b] for b in ('DAY','NIGHT')];ps=row['paths'][route]
                dual=all(g['decision']['status']=='適合' for g in gs)
                full=all(ps[b]['support']['zero_scene_count']==0 for b in ('DAY','NIGHT'))
                rate=all(g['trades']['all_count']>=24 and g['trades']['IFD_FIRSTFANC']['reached_count']>=12 and g['resolved_scene_count']>=6 and (g['trades']['IFD_FIRSTFANC']['first_f_rate_reached'] or 0)>=.7 for g in gs)
                support=sum(ps[b]['support']['phase_diagnostic_goal_met'] for b in ('PRE','POST'))
                unknown=max(g['trades']['unknown_count']/g['trades']['all_count'] if g['trades']['all_count'] else 1 for g in gs)
                windows=[w['negative_net_share_complete'] for b in ('DAY','NIGHT') for w in ps[b]['windows'].values() if w['complete_window_count']]
                burdens=[ps[b]['known_drawdown_to_known_profit'] for b in ('DAY','NIGHT')]
                return (-int(dual and full and rate),-int(dual and full),-support,unknown,max(windows,default=1),max(float('inf') if b is None else b for b in burdens),-sum(g['trades']['known_net'] for g in gs),row['id'])
            options=sorted([r for r in rows if r['policy']['route']==route],key=key);eligible=[r for r in options if key(r)[0]==-1]
            chosen[route]={'主案':eligible[0]['id'] if eligible else None,'共同適合数':len(eligible),'参考候補':[r['id'] for r in options[:2]],'candidates':[r['policy'] for r in options[:2]]}
        B.P.save(HERE/'旧73の固定選択.json',{'成功':True,'選択':chosen,'追加7当該候補金融未読':True})
        print(json.dumps({k:{a:b for a,b in v.items() if a!='candidates'} for k,v in chosen.items()},ensure_ascii=False))


def main() -> None:
    """
    機能: 178の金融前固定・出生・帯確認・接合を段階実行する。
    引数: --stage(str)。
    返り値: None。
    """
    p=argparse.ArgumentParser();p.add_argument('--stage',choices=('freeze','birth','single','joint'),required=True);args=p.parse_args()
    if args.stage=='freeze':freeze()
    elif args.stage=='birth':birth()
    else:stages(args.stage)


if __name__=='__main__':main()
