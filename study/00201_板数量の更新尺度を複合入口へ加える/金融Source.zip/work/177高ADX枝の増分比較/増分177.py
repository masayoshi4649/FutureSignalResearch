"""174の固定幹を保持し、高ADXの複合入口を増分で数量再生する。"""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from itertools import combinations,product
from datetime import datetime,timezone
import argparse
import copy
import json
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).parent
TRIAL=ROOT/'study/00177_固定幹を保ち高ADXの入口を増分比較する'
sys.path.insert(0,str(ROOT/'work/175局面別入口の再探索'))
import 基盤175 as BASE
import 予備評価175 as SCREEN
import 数量段階を進める as STAGE
B=BASE.B
CATALOG=ROOT/'work/177高ADXの増分純入口/候補辞書177.json'
BUILDER=ROOT/'work/177高ADXの増分純入口/rules177.py'
PARENT=ROOT/'work/174追加七場適用'
CTX=CAPS=DIRS=BASES=None


def ref(path: Path) -> dict:
    """
    機能: Sourceと入力の指紋を取得する。
    引数: path(Path)。
    返り値: dictはpath/bytes/sha256。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':B.P.sha(path)}


def combine(base: dict, phases: np.ndarray, options: dict, directions: dict, horizons: list) -> tuple:
    """
    機能: 旧coreを優先し、旧coreなしのq0だけ新枝へ置き換える。
    引数: base(dict)は174封印出生、phases(np.ndarray)、options/directions(dict)、horizons(list)。
    返り値: tupleはbirth/mw/fw/hi/新枝mask/枝競合。旧Tと遅延は保持する。
    """
    new,mw,fw,hi,_,conflict=BASE.compose(phases,options,directions,horizons)
    active=(base['core']==0)&(new['core']!=0)
    blocked=(base['core']==0)&conflict
    core=np.where(active,new['core'],base['core']).astype(np.int8)
    birth={'core':core,'branches':np.where(core!=0,0,-1).astype(np.int8),
        'technical':np.where(blocked,0,base['technical']).astype(np.int8),
        'tier':np.where(blocked,0,base['tier']).astype(np.int8)}
    return birth,*[np.where(active,added,base[name]).copy() for name,added in [('mw',mw),('fw',fw),('hi',hi)]],active,blocked


def artificial() -> dict:
    """
    機能: 優先順・T保持・競合・鏡像とprefixを人工確認する。
    引数: なし。
    返り値: dictは自然金融を読まない確認票。
    """
    phases=np.array([0,1,1,2,2,2]);n=len(phases)
    base={'core':np.array([1,0,0,-1,0,0],np.int8),'technical':np.ones(n,np.int8),
        'tier':np.ones(n,np.int8),'mw':np.full(n,125,np.int16),'fw':np.full(n,125,np.int16),'hi':np.ones(n,np.int8)}
    dirs={'a':np.array([-1,1,1,1,1,0],np.int8),'b':np.array([0,1,-1,0,0,0],np.int8)}
    rules=[{'id':k,'birth_key':k,'width':200,'horizon':'H30'} for k in dirs]
    options={b:rules for b in ('DAY','PRE','POST')};hs=['H30','H60','H120','SESSION']
    out=combine(base,phases,options,dirs,hs)
    assert out[0]['core'].tolist()==[1,1,0,-1,1,0]
    assert out[0]['technical'].tolist()==[1,1,0,1,1,1]
    assert out[1].tolist()==[125,200,125,125,200,125]
    mirrored={**base,'core':-base['core'],'technical':-base['technical']}
    mirror=combine(mirrored,phases,options,{k:-v for k,v in dirs.items()},hs)
    assert all(np.array_equal(mirror[0][k],-out[0][k]) for k in ('core','technical'))
    for end in range(1,n+1):
        short=combine({k:v[:end] for k,v in base.items()},phases[:end],options,{k:v[:end] for k,v in dirs.items()},hs)
        assert all(np.array_equal(short[0][k],out[0][k][:end]) for k in short[0])
    return {'成功':True,'旧core優先':True,'旧T保持':True,'枝競合で待機':True,'鏡像とprefix':True}


def freeze() -> None:
    """
    機能: 177の増分設計と全選択手順を金融前に固定する。
    引数: なし。
    返り値: None。旧試行は変更しない。
    """
    assert not (TRIAL/'条件.json').exists()
    paths=[Path(__file__),CATALOG,BUILDER,ROOT/'work/175局面別入口の再探索/基盤175.py',
        ROOT/'work/175局面別入口の再探索/予備評価175.py',ROOT/'work/175局面別入口の再探索/数量段階を進める.py',
        ROOT/'work/175経路と支持の評価/path175.py',PARENT/'旧73の純出生174.npz',
        ROOT/'work/174参加と両中央値の再探索/旧73jointの固定選択.json']
    body={'試行':177,'GO':True,'UTC':datetime.now(timezone.utc).isoformat(),
        '仮説':'175の全ANDは希少、176の全置換は広幅Nと後半悪化。174固定幹を維持し、高ADXだけ複合技術の新枝を増分比較する。',
        '旧幹':'174全期J002/J003・前48J000/J001。各routeで固定2対照を保持。デイ・旧主・初参加T・デイT遅延を変更しない。',
        '純入口':'175/176のHT/HB/HR/HMをSource区別してADX>20ゲート。元modeを保持、閾値の外しだけでなく既存の複合技術条件全体を使う。',
        '優先':'旧core>新枝>T。旧coreが無い時だけ新枝を使う。新枝の逆方向競合は待機しTも抑制。同方向はID順。',
        '費用と時計':'mini1枚、1pt100円、片道38.5円＋5pt滑りと実BBO。買売合計保有+pending1。q0連続、q1取得、未知場末保持。',
        '出口':'IFD_FIRST、幅125/150/175/200/225/250/300/350/400/500/750/1000、H30/H60/H120/SESSION。N期限返済、C未知。',
        '予備':'768候補×正逆2×12幅×4期限、旧73全期/前48別。175の支持条件・4視点選択を再用し、4群から最大16案/帯/route。',
        '数量選択':'各174固定幹へPRE又はPOST一枝を足しglobal1。各帯8短表。異なる群の新枝最大2の組合せ＋一枝＋追加なしを再生し帯8へ。PRE×POSTを接合、Dayは同体。',
        '主支持':'Day/Night両中央値正・全場取得・先着70%に加えFA12/取得24/FA場6を別表示。PRE/POST参加50%は順位の支持軸で必須採否にしない。',
        '順位':'主支持→両中央値と全場→POST取得場数→未知率→完全5/10場赤字窓割合→DD/既知利益→既知純益。初期損失・回復も併記。',
        '選択期間':'全期発見と前48選択を分離し、後25を成績で再選択しない。追加7は各route固定最大2案のみ、既使用の参考適用。',
        '対照検査':'追加なしは174固定の全金融・全取得へ一致確認。新枝で枠占有が変わる後続取引も再生し独立利益を足さない。',
        '出力':'候補ごとCSVとMD。未知を0にせず既知寄与DDと全件DDを区別。',
        '人工検査':artificial(),'Source':[ref(p) for p in paths]}
    TRIAL.mkdir(parents=True,exist_ok=True);(TRIAL/'検査').mkdir(exist_ok=True)
    B.P.save(TRIAL/'条件.json',body);print(json.dumps(ref(TRIAL/'条件.json'),ensure_ascii=False))


def birth_screen(stage: str) -> None:
    """
    機能: 純出生を先に固定し、その後だけ独立予備評価する。
    引数: stage(str)はbirth又はscreen。
    返り値: None。
    """
    fixed=B.P.read(TRIAL/'条件.json')
    for r in fixed['Source']:assert B.P.sha(ROOT/r['path'])==r['sha256']
    target=HERE/'純出生177.npz';rules=B.P.read(CATALOG)['rules']
    if stage=='birth':
        data=B.P.R168.BASE.data_module();features=data.load_feature_dataset()
        builder=B.P.module(BUILDER,'pure177');out=builder.build(features,np.array([s['start'] for s in features.scenes]),features.q0_timeband)
        assert out['candidate_ids']==[r['id'] for r in rules] and not target.exists()
        np.savez_compressed(target,directions=out['directions'],phases=features.q0_timeband)
        B.P.save(target.with_suffix('.json'),{'成功':True,'金融未入力':True,'F0SHA256':B.P.sha(TRIAL/'条件.json'),'出生SHA256':B.P.sha(target)})
    else:
        proof=B.P.read(target.with_suffix('.json'));assert proof['金融未入力'] and B.P.sha(target)==proof['出生SHA256']
        context=B.load_context(False)
        with np.load(target,allow_pickle=False) as raw:matrix=raw['directions'];assert np.array_equal(raw['phases'],context.event_phases)
        metrics=np.empty((len(rules),2,3,2,len(context.table.widths),len(context.table.horizons),len(SCREEN.FIELDS)))
        for ri,direction in enumerate(matrix):
            cases,sides,phases=SCREEN.physical(direction,context.event_cases,context.event_phases)
            for oi in range(2):metrics[ri,oi]=SCREEN.summarize(context,cases,sides if oi==0 else 1-sides,phases)
        selected=SCREEN.select(metrics,rules,list(context.table.widths),list(context.table.horizons))
        path=HERE/'予備統計177.npz';assert not path.exists();np.savez_compressed(path,metrics=metrics)
        B.P.save(HERE/'予備短表177.json',{'成功':True,'選択':selected,'予備統計SHA256':B.P.sha(path)})
    print(json.dumps({'成功':True,'段階':stage,'候補数':len(rules)},ensure_ascii=False))


def initialize() -> None:
    """
    機能: 各workerへ旧73だけを接続する。
    引数: なし。
    返り値: None。
    """
    global CTX,CAPS,DIRS,BASES
    CTX=B.load_context(False);CAPS=B.captures(CTX)
    rules=B.P.read(CATALOG)['rules']
    with np.load(HERE/'純出生177.npz',allow_pickle=False) as raw:
        matrix=raw['directions'];DIRS={r['id']+'/'+o:matrix[i] if o=='NORMAL' else -matrix[i] for i,r in enumerate(rules) for o in ('NORMAL','REVERSE')}
    with np.load(PARENT/'旧73の純出生174.npz',allow_pickle=False) as raw:
        BASES={name:{k:raw[name+'__'+k].copy() for k in ('core','branches','technical','tier','mw','fw','hi')} for name in ('全期_J002','全期_J003','前48_J000','前48_J001')}


def evidence(context: object, value: tuple) -> tuple:
    """
    機能: 三期間四帯の金融と経路を同じ定義で評価する。
    引数: context(object)、value(tuple)。
    返り値: tuple[dict,dict]は金融と小型経路。
    """
    scene=context.case_scene[value[0].cases];periods={};paths={}
    labels=context.arrays['label'][value[0].cases,value[0].sides,value[2],value[3]]
    for name,eligible in [('全期',np.ones(len(context.scenes),bool)),('前48',np.arange(len(context.scenes))<48),('後25',np.arange(len(context.scenes))>=48)]:
        metric=B.financial(context,value,eligible[scene],eligible)
        periods[name]={**metric['phases_diagnostic'],'NIGHT':metric['session_groups_required']['NIGHT']};paths[name]={}
        for field,group in periods[name].items():
            phase=value[0].phases>0 if field=='NIGHT' else value[0].phases==('DAY','PRE','POST').index(field)
            resolved=eligible[scene]&phase&((labels==1)|(labels==-1))
            counts=np.bincount(scene[resolved],minlength=len(context.scenes))
            group['resolved_scene_count']=int((counts>0).sum());group['max_resolved_scene_count']=int(counts.max())
            group.pop('origins',None);group.pop('concentration',None)
            paths[name][field]=STAGE.compact_risk(STAGE.RISK.path_summary(group))
    return periods,paths


def evaluate(policy: dict) -> dict:
    """
    機能: 固定幹と新枝の口座全体を一枠で再生する。
    引数: policy(dict)はbase/route/options/id。
    返り値: dictは期間別成績と追加枝取得数。候補ごとの独立利益を合算しない。
    """
    birth,mw,fw,hi,active,blocked=combine(BASES[policy['base']],CTX.event_phases,policy['options'],DIRS,list(CTX.table.horizons))
    value=B.replay(CTX,birth,mw,fw,hi,True,CAPS);periods,paths=evidence(CTX,value)
    return {'id':policy['id'],'policy':policy,'periods':periods,'paths':paths,'count':len(value[0].cases),
        'new_count':int(active[value[0].events].sum()),'conflict_q0':int(blocked.sum()),
        'max_reserved':max((a['peak_global_reserved'] for a in value[-1]['audits']),default=0)}


def run(name: str, policies: list) -> list:
    """
    機能: 政策群を先に封印してから旧73だけを再生する。
    引数: name(str)、policies(list[dict])。
    返り値: list[dict]。
    """
    path=HERE/(name+'.json.gz');assert not path.exists()
    for r in B.P.read(TRIAL/'条件.json')['Source']:assert B.P.sha(ROOT/r['path'])==r['sha256']
    B.P.save(TRIAL/'検査'/('F2_'+name+'.json'),{'成功':True,'SourceSHA256':B.P.sha(Path(__file__)),'policies':policies,'追加7未読':True})
    rows=[]
    with ProcessPoolExecutor(max_workers=4,initializer=initialize) as pool:
        for row in pool.map(evaluate,policies,chunksize=4):
            rows.append(row)
            if len(rows)%100==0:print(json.dumps({'段階':name,'再生':len(rows),'全数':len(policies)},ensure_ascii=False),flush=True)
    B.P.save(path,{'成功':True,'rows':rows});return rows


def rank(rows: list, route: str, field: str, maximum: int=8) -> list:
    """
    機能: 共同条件・経路と参加支持を別視点で短表へ残す。
    引数: rows(list)、route/field(str)、maximum(int)。
    返り値: list[dict]は最大8候補。
    """
    out=[];seen=set()
    for view in ('共同','支持','経路','率'):
        def key(row: dict) -> tuple:
            """
            機能: 選択期間だけから一視点の順位を作る。
            引数: row(dict)。
            返り値: tuple。
            """
            g=row['periods'][route][field];p=row['paths'][route][field];s=p['support'];t=g['trades']
            general=STAGE.RISK.candidate_key(g,p,field);fa=t['IFD_FIRSTFANC']
            if view=='共同':return general
            if view=='支持':return (-s['participating_scene_count'],-t['all_count'],general)
            if view=='率':return (-int(fa['reached_count']>=12 and g['resolved_scene_count']>=6),-(fa['first_f_rate_reached'] or 0),general)
            burden=p['known_drawdown_to_known_profit']
            return (-int(g['decision']['status']=='適合'),float('inf') if burden is None else burden,general)
        taken=0
        for row in sorted(sorted(rows,key=lambda r:r['id']),key=key):
            if row['id'] in seen:continue
            out.append(row);seen.add(row['id']);taken+=1
            if taken==2 or len(out)==maximum:break
        if len(out)==maximum:break
    return out


def stages(stage: str) -> None:
    """
    機能: 増分単独・最大二枝・三帯接合を順に実行する。
    引数: stage(str)はsingle/mix/joint。
    返り値: None。固定前48の選択に後25を使用しない。
    """
    policies=[];fixed=B.P.read(ROOT/'work/174参加と両中央値の再探索/旧73jointの固定選択.json')['選択']
    if stage=='single':
        initialize();controls=[]
        expected={r['id']:r for r in B.P.read(PARENT/'旧73の全取得174.json.gz')['rows']}
        for name,base in BASES.items():
            birth,mw,fw,hi,active,blocked=combine(base,CTX.event_phases,{},DIRS,list(CTX.table.horizons))
            value=B.replay(CTX,birth,mw,fw,hi,True,CAPS);record=expected[name]
            assert not active.any() and not blocked.any()
            assert B.financial(CTX,value)==record['financial'],name
            actual={'cases':value[0].cases.tolist(),'sides':value[0].sides.tolist(),'events':value[0].events.tolist(),
                'phases':value[0].phases.tolist(),'origins':value[1].tolist(),'widths':value[2].tolist(),
                'horizons':value[3].tolist(),'tiers':value[4].tolist(),'engine':value[5]}
            assert actual=={k:record[k] for k in actual},name
            controls.append({'id':name,'全金融全取得全engine一致':True})
        B.P.save(HERE/'旧四対照の同体.json',{'成功':True,'checks':controls})
        short=B.P.read(HERE/'予備短表177.json')['選択']
        for route,value in fixed.items():
            for base in value['candidates']:
                for band in ('PRE','POST'):
                    choices=[[],*[[r] for r in short[route][band]]]
                    for i,options in enumerate(choices):policies.append({'id':base['id']+'_'+band+f'_S{i:03}','base':base['id'],'route':route,'options':{band:options}})
        rows=run('増分単独',policies);chosen={}
        for route,value in fixed.items():
            for base in value['candidates']:
                chosen[base['id']]={band:[r['policy'] for r in rank([r for r in rows if r['policy']['base']==base['id'] and band in r['policy']['options']],route,band)] for band in ('PRE','POST')}
        B.P.save(HERE/'単独短表.json',{'成功':True,'選択':chosen})
    elif stage=='mix':
        source=B.P.read(HERE/'単独短表.json')['選択']
        for base,bands in source.items():
            route='全期' if base.startswith('全期') else '前48'
            for band,items in bands.items():
                rules={r['id']:r for p in items for r in p['options'][band]};choices=[[],*[[r] for r in rules.values()]]
                choices+=[list(pair) for pair in combinations(rules.values(),2) if pair[0]['family']!=pair[1]['family']]
                for i,options in enumerate(choices):policies.append({'id':base+'_'+band+f'_M{i:03}','base':base,'route':route,'options':{band:options}})
        rows=run('増分二枝',policies);chosen={}
        for route,value in fixed.items():
            for base in value['candidates']:
                chosen[base['id']]={band:[r['policy'] for r in rank([r for r in rows if r['policy']['base']==base['id'] and band in r['policy']['options']],route,band)] for band in ('PRE','POST')}
        B.P.save(HERE/'帯短表.json',{'成功':True,'選択':chosen})
    else:
        source=B.P.read(HERE/'帯短表.json')['選択']
        for base,bands in source.items():
            route='全期' if base.startswith('全期') else '前48'
            for i,(a,b) in enumerate(product(bands['PRE'],bands['POST'])):policies.append({'id':base+f'_J{i:03}','base':base,'route':route,'options':{**a['options'],**b['options']}})
        rows=run('三帯接合',policies);chosen={}
        for route in ('全期','前48'):
            options=[r for r in rows if r['policy']['route']==route]
            def key(row: dict) -> tuple:
                """
                機能: 金融前に決めた共同条件と経路で固定候補を選ぶ。
                引数: row(dict)。
                返り値: tuple。
                """
                groups=row['periods'][route];paths=row['paths'][route];gs=[groups[b] for b in ('DAY','NIGHT')]
                dual=all(g['decision']['status']=='適合' for g in gs)
                full=all(paths[b]['support']['zero_scene_count']==0 for b in ('DAY','NIGHT'))
                support=all(g['trades']['all_count']>=24 and g['trades']['IFD_FIRSTFANC']['reached_count']>=12 and g['resolved_scene_count']>=6 and (g['trades']['IFD_FIRSTFANC']['first_f_rate_reached'] or 0)>=.7 for g in gs)
                rates=[g['trades']['unknown_count']/g['trades']['all_count'] if g['trades']['all_count'] else 1 for g in gs]
                windows=[w['negative_net_share_complete'] for b in ('DAY','NIGHT') for w in paths[b]['windows'].values() if w['complete_window_count']]
                burdens=[paths[b]['known_drawdown_to_known_profit'] for b in ('DAY','NIGHT')]
                burden=max(float('inf') if b is None else b for b in burdens)
                return (-int(dual and full and support),-int(dual and full),-paths['POST']['support']['participating_scene_count'],max(rates),max(windows,default=1),burden,-sum(g['trades']['known_net'] for g in gs),row['id'])
            options.sort(key=key);eligible=[r for r in options if key(r)[0]==-1]
            chosen[route]={'主案':eligible[0]['id'] if eligible else None,'共同適合数':len(eligible),'参考候補':[r['id'] for r in options[:2]],'candidates':[r['policy'] for r in options[:2]]}
        B.P.save(HERE/'旧73の固定選択.json',{'成功':True,'選択':chosen,'追加7当該候補金融未読':True})
        print(json.dumps({k:{a:b for a,b in v.items() if a!='candidates'} for k,v in chosen.items()},ensure_ascii=False))


def main() -> None:
    """
    機能: 金融前固定から旧73の固定選択まで指定段階だけ実行する。
    引数: --stage(str)。
    返り値: None。
    """
    p=argparse.ArgumentParser();p.add_argument('--stage',choices=('freeze','birth','screen','single','mix','joint'),required=True);args=p.parse_args()
    if args.stage=='freeze':freeze()
    elif args.stage in ('birth','screen'):birth_screen(args.stage)
    else:stages(args.stage)


if __name__=='__main__':main()
