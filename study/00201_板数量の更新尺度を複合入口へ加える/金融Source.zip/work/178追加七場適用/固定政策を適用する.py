"""178固定四案を、実側ゲート済み純方向の封印後だけ追加七場へ参考適用する。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import gzip
import hashlib
import json
import sys
import zipfile
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'work/175局面別入口の再探索'))
import 基盤175 as BASE
B=BASE.B
FIXED=ROOT/'work/178新枝の確認比較/旧73の固定選択.json'
OLD_REPORT=ROOT/'work/178新枝の確認比較/三帯接合.json.gz'
OLD_BIRTH=ROOT/'work/178新枝の確認比較/純出生178.npz'
SOURCE=ROOT/'work/178新枝の確認比較/検証178.py'
GATES=ROOT/'work/178新枝の実方向確認/gates178.py'
CATALOG=ROOT/'work/178新枝の実方向確認/候補辞書178.json'
PARENT=ROOT/'study/00177_固定幹を保ち高ADXの入口を増分比較する/再現資料'
IDS={'全期_J002_J000_K012','全期_J002_J000_K013','前48_J000_J005_K000','前48_J000_J005_K008'}


def selected(expected_sha: str) -> list:
    """
    機能: Rootの固定SHAを確認し各route最大二案の四政策だけを返す。
    引数: expected_sha(str)はGO時の固定票SHA256。
    返り値: list[dict]。追加七場で条件や候補を選び直さない。
    """
    assert len(expected_sha)==64 and B.P.sha(FIXED)==expected_sha.lower();body=B.P.read(FIXED)
    assert body['成功'] and body['追加7当該候補金融未読'];result=[]
    for route in ('全期','前48'):
        rows=body['選択'][route]['candidates'];assert len(rows)<=2 and all(r['route']==route for r in rows);result.extend(rows)
    assert len(result)==4 and {r['id'] for r in result}==IDS
    assert all(set(p['options'])=={'PRE','POST'} for p in result)
    return result


def sources(helper: object) -> list:
    """
    機能: 実行前後で照合する新Sourceと非金融固定入力を列挙する。
    引数: helper(object)は177の既存共通adapter。
    返り値: list[Path]。金融正本の内容は出生封印後に読む。
    """
    result=[Path(__file__),HERE/'README.md',FIXED,OLD_BIRTH,OLD_BIRTH.with_suffix('.json'),SOURCE,GATES,CATALOG,
        ROOT/'study/00178_新枝の実方向と複数足の背景を確認する/条件.json',PARENT/'保存索引.json',
        ROOT/'work/177高ADX枝の増分比較/旧73の固定選択.json',ROOT/'work/177高ADX枝の増分比較/純出生177.npz',
        ROOT/'work/163任意幅の数値化/arrays163.py',ROOT/'work/166可変場の数値化/arrays166.py']
    for module in list(sys.modules.values()):
        name=getattr(module,'__file__',None)
        if name:
            path=Path(name).resolve()
            if path.suffix=='.py' and path.is_relative_to(ROOT):result.append(path)
    return sorted(set(result))


def directions(features: object, fixed: list, parents: list, builder: object, gates: object, verification: object) -> tuple:
    """
    機能: 177の正逆後の実注文側へ178ゲートを一回適用する。
    引数: features(object)、fixed/parents(list)、builder/gates/verification(object)。
    返り値: tuple[dict,dict]はゲート済みbirth_key方向と正逆前の177方向。
    """
    originals={r['birth_key']:r for p in parents for rows in p['options'].values() for r in rows}
    ids=sorted({r['rule_id'] for r in originals.values()})
    born=builder.build(features,np.asarray([s['start'] for s in features.scenes]),features.q0_timeband,candidate_ids=ids)
    assert born['candidate_ids']==ids and np.array_equal(born['phases'],features.q0_timeband)
    raw={name:born['directions'][i].copy() for i,name in enumerate(ids)};oriented={}
    for key,rule in originals.items():
        assert key==rule['rule_id']+'/'+rule['orientation'] and rule['orientation'] in ('NORMAL','REVERSE')
        oriented[key]=raw[rule['rule_id']].copy() if rule['orientation']=='NORMAL' else -raw[rule['rule_id']]
    result={'G00|'+key:gates.apply(features,value,'G00') for key,value in oriented.items()}
    for policy in fixed:
        for band,rules in policy['options'].items():
            for rule in rules:
                gate,key=rule['birth_key'].split('|',1)
                assert gate==rule['gate']==policy['gate_by_band'][band]
                assert key==rule['rule_id']+'/'+rule['orientation'] and key in oriented
                result[rule['birth_key']]=gates.apply(features,oriented[key],gate)
    assert all(np.isin(value,(-1,0,1)).all() for value in result.values())
    return result,raw


def controls(parents: list, verification: object) -> list:
    """
    機能: 各親のG00=177/G99=174という両端政策を純構成する。
    引数: parents(list[dict])、verification(object)は178政策関数。
    返り値: list[dict]は八つの固定対照構成。
    """
    return [{'id':'対照_'+parent['id']+'_'+gate,'parent':parent['id'],'base':parent['base'],'route':parent['route'],
        'gate':gate,'options':{band:verification.policy(parent,band,gate)['options'][band] for band in ('PRE','POST')}}
        for parent in parents for gate in ('G00','G99')]


def freeze(fixed: list, parents: list, control: list, before: dict, helper: object, verification: object, builder: object, gates: object, bases: dict, parent_ref: dict) -> dict:
    """
    機能: 旧純出生一致を確認し、旧/追加の固定政策と両端対照を金融前封印する。
    引数: fixed/parents/control(list)、before/bases/parent_ref(dict)、各objectは固定Source。
    返り値: dictは純入力と全出生の指紋。
    """
    data=B.P.R168.BASE.data_module();old=data.load_feature_dataset()
    directory=ROOT/'inputs/00167_追加七場の入口と共用価格索引/入口母集団';added,_,_=B.P.R168.BASE.load_features(directory)
    paths=[ROOT/'work/151過去場判別の評価/入口選択/cache/feature_only/features.npz',ROOT/'work/151過去場判別の評価/入口選択/cache/feature_only/features_meta.json',
        *[directory/n for n in ('完了.json','当時特徴.json.gz','固定取得入力.json.gz','取得対応.json.gz')]]
    proof={'成功':True,'金融内容未入力':True,'追加7金融未読':True,'Sourceと固定選択':before,'174正式幹':parent_ref,
        '非金融入力':{p.relative_to(ROOT).as_posix():helper.A.physical(p) for p in paths},'期間':{},'両端対照':control}
    old_proof=B.P.read(OLD_BIRTH.with_suffix('.json'));assert old_proof['金融未入力'] and B.P.sha(OLD_BIRTH)==old_proof['出生SHA256']
    catalog=B.P.read(verification.P.CATALOG)['rules'];lookup={r['id']:i for i,r in enumerate(catalog)}
    for period,features in (('旧73',old),('追加7',added)):
        pure,raw=directions(features,fixed,parents,builder,gates,verification)
        assert np.array_equal(features.q0_timeband,bases[period]['phases'])
        if period=='旧73':
            with np.load(ROOT/'work/177高ADX枝の増分比較/純出生177.npz',allow_pickle=False) as sealed:
                matrix=sealed['directions'];assert all(np.array_equal(value,matrix[lookup[name]]) for name,value in raw.items())
            with np.load(OLD_BIRTH,allow_pickle=False) as sealed:
                assert np.array_equal(sealed['phases'],features.q0_timeband)
                assert all(np.array_equal(value,sealed[key]) for key,value in pure.items())
        arrays={'phases':features.q0_timeband};counts=[]
        for policy in [*fixed,*control]:
            birth,mw,fw,hi,active,blocked=verification.P.combine(bases[period]['bases'][policy['base']],features.q0_timeband,policy['options'],pure,helper.A.HORIZONS)
            prefix=policy['id']+'__';arrays.update({prefix+k:v for k,v in birth.items()})
            arrays.update({prefix+k:v for k,v in [('mw',mw),('fw',fw),('hi',hi),('active',active),('blocked',blocked)]})
            counts.append({'id':policy['id'],'主成立q0':int(np.count_nonzero(birth['core'])),'新枝成立q0':int(active.sum()),'枝競合q0':int(blocked.sum())})
        target=HERE/(period+'の純出生178.npz');assert not target.exists();np.savez_compressed(target,**arrays)
        proof['期間'][period]={'場順':[s['session'] for s in features.scenes],'q0数':len(features.q0_meta),'出生':helper.A.physical(target),
            '実側ゲート方向数':len(pure),'診断':counts,'旧178純方向一致':period=='旧73','反転後ゲート一回・再EDGEなし':True}
    assert all(helper.A.physical(ROOT/name)==value for name,value in before.items())
    assert all(helper.A.physical(ROOT/name)==value for name,value in proof['非金融入力'].items())
    helper.A.save(HERE/'金融前の出生固定.json',proof);return proof


def official_report(folder: Path, member: str, helper: object) -> dict:
    """
    機能: 出生封印後に、正式ZIPの金融memberを索引へ照合して読む。
    引数: folder(Path)、member(str)、helper(object)。
    返り値: dictはJSON。正式正本をworkの現在値へ差し替えない。
    """
    index=B.P.read(folder/'保存索引.json');source=folder/'出生と比較正本.zip';assert helper.A.physical(source)==index['正本']['archive']
    ref=next(r for r in index['正本']['members'] if r['path']==member)
    with zipfile.ZipFile(source) as archive:body=archive.read(member)
    assert {'path':member,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}==ref
    return json.loads(gzip.decompress(body) if member.endswith('.gz') else body)


def run(expected_sha: str) -> None:
    """
    機能: 178固定四案と両端対照を封印後に金融へ接続し、全80を台帳から再計算する。
    引数: expected_sha(str)はRoot GOと固定票SHA256。
    返り値: None。全体/前半/後半/追加/全80を分け、追加期選択は行わない。
    """
    assert not (HERE/'金融前の出生固定.json').exists();fixed=selected(expected_sha)
    helper=B.P.module(ROOT/'work/177追加七場適用/固定政策を適用する.py','adapter177_for178')
    verification=B.P.module(SOURCE,'verification178_added');gates=B.P.module(GATES,'gates178_added')
    builder=B.P.module(verification.P.BUILDER,'pure177_for178_added');parents=verification.parents();control=controls(parents,verification)
    bases,parent_ref=helper.official_seals();before={p.relative_to(ROOT).as_posix():helper.A.physical(p) for p in sources(helper)}
    helper.A.save(HERE/'出生前の固定.json',{'成功':True,'UTC':datetime.now(timezone.utc).isoformat(),'固定票SHA256':expected_sha.lower(),
        'Sourceと固定選択':before,'対象':[p['id'] for p in fixed],'追加7金融未読':True})
    proof=freeze(fixed,parents,control,before,helper,verification,builder,gates,bases,parent_ref);proof_ref=helper.A.physical(HERE/'金融前の出生固定.json')
    # ----------------------------------------
    # 純方向・合成・G00/G99両端の両期間封印後にのみ金融を読み込む。
    expected_ref=helper.A.physical(OLD_REPORT);expected={r['id']:r for r in B.P.read(OLD_REPORT)['rows'] if r['id'] in IDS}
    assert len(expected)==4;reports={};same=[];endpoints={};noadd={};parent_lookup={p['id']:p for p in parents}
    for new,period in ((False,'旧73'),(True,'追加7')):
        context=B.load_context(new);assert context.sessions==proof['期間'][period]['場順']
        ref177={r['id']:r for r in official_report(PARENT,f'work/177追加七場適用/{period}の全取得177.json.gz',helper)['rows']}
        ref174={r['id']:r for r in official_report(helper.PARENT,f'work/174追加七場適用/{period}の全取得174.json.gz',helper)['rows']}
        noadd[period]=helper.no_add_check(context,bases[period]['bases'],ref174,verification.P)
        target=HERE/(period+'の純出生178.npz');assert helper.A.physical(target)==proof['期間'][period]['出生'];rows=[];endpoints[period]=[]
        with np.load(target,allow_pickle=False) as sealed:
            assert np.array_equal(sealed['phases'],context.event_phases)
            for policy in [*fixed,*control]:
                prefix=policy['id']+'__';birth={k:sealed[prefix+k] for k in ('core','branches','technical','tier')}
                mw,fw,hi=[sealed[prefix+k] for k in ('mw','fw','hi')];active=sealed[prefix+'active']
                value=B.replay(context,birth,mw,fw,hi,True)
                if policy in control:
                    if policy['gate']=='G00':
                        actual=helper.pack(context,value,parent_lookup[policy['parent']],active,verification.P)
                        assert actual==ref177[policy['parent']],(period,policy['id'],'G00=177全pack')
                    else:
                        actual=helper.A.pack(context,value,ref174[policy['base']]['policy'])
                        assert all(actual[k]==v for k,v in ref174[policy['base']].items()),(period,policy['id'],'G99=174全pack')
                    endpoints[period].append({'parent':policy['parent'],'gate':policy['gate'],'全取得engine金融台帳一致':True,'取得':len(value[0].cases)})
                    continue
                row=helper.pack(context,value,policy,active,verification.P);maximum=max((a['peak_global_reserved'] for a in value[-1]['audits']),default=0)
                assert maximum<=1
                if not new:
                    original=expected[policy['id']]
                    assert row['policy']==original['policy'] and row['periods']==original['periods'] and row['period_paths']==original['paths']
                    assert len(row['cases'])==original['count'] and row['new_count']==original['new_count'] and maximum==original['max_reserved']
                    assert int(sealed[prefix+'blocked'].sum())==original['conflict_q0']
                    same.append({'id':policy['id'],'旧73全金融期間経路・新枝数・回数・占有一致':True})
                rows.append(row)
        eligible,hours=helper.A.eligibility(context)
        reports[period]={'成功':True,'場数':len(context.scenes),'場順':context.sessions,'対象場':eligible,'対象時間':hours,
            '幅順':list(context.table.widths),'期限順':list(context.table.horizons),'出生固定':proof_ref,'rows':rows,
            'G00=177_G99=174全pack同体':endpoints[period],'追加なし旧174四対照全pack同体':noadd[period],
            '位置づけ':'旧73既使用固定再現' if not new else '追加7既使用参考。候補再選択なし。'}
        helper.A.save(HERE/(period+'の全取得178.json.gz'),reports[period])
    # ----------------------------------------
    eligible={n:reports['旧73']['対象場'][n]+reports['追加7']['対象場'][n] for n in ('DAY','PRE','POST')}
    hours={n:reports['旧73']['対象時間'][n]+reports['追加7']['対象時間'][n] for n in ('DAY','PRE','POST')}
    assert not set(reports['旧73']['場順'])&set(reports['追加7']['場順']);joined_rows=[]
    for old,added in zip(reports['旧73']['rows'],reports['追加7']['rows'],strict=True):
        assert old['id']==added['id'];joined={n:old['ledger'][n]+added['ledger'][n] for n in ('net','known','label','scene')}
        phases=old['phases']+added['phases'];origins=old['origins']+added['origins'];flags=old['added']+added['added']
        financial=B.metrics173.evaluate_metrics(joined['net'],joined['known'],joined['label'],joined['scene'],phases,origins,eligible,hours)
        joined_rows.append({'id':old['id'],'policy':old['policy'],'financial':financial,'paths':helper.A.paths(financial),
            'ledger':joined,'phases':phases,'origins':origins,'added':flags,'new_count':sum(flags),
            'old_main_count':old['old_main_count']+added['old_main_count'],'fallback_count':old['fallback_count']+added['fallback_count'],
            '旧73':old['financial'],'追加7':added['financial']})
    assert len(reports['旧73']['場順'])+len(reports['追加7']['場順'])==80
    helper.A.save(HERE/'全80の両中央値178.json.gz',{'成功':True,'場数':80,'対象場':eligible,'対象時間':hours,'rows':joined_rows,
        '注意':'全80既使用。未知None/0取得場/前48後25悪化と追加期の成績を保持。実側ゲート後の枝flagとorigins0/2を分離。'})
    assert helper.A.physical(OLD_REPORT)==expected_ref and helper.A.physical(HERE/'金融前の出生固定.json')==proof_ref
    assert helper.A.physical(helper.PARENT/'出生と比較正本.zip')==parent_ref['archive']
    assert all(helper.A.physical(ROOT/name)==value for name,value in before.items())
    assert all(helper.A.physical(ROOT/name)==value for name,value in proof['非金融入力'].items())
    helper.A.save(HERE/'完了.json',{'成功':True,'出生固定':proof_ref,'Sourceと固定選択':before,'174正式幹':parent_ref,'旧金融正本':expected_ref,
        '旧73固定同体':same,'両端対照全pack同体':endpoints,'旧174追加なし四対照全pack同体':noadd,
        '固定候補再選択なし':True,'金融後Source変更なし':True,'files':{p.name:helper.A.physical(p) for p in HERE.iterdir() if p.is_file() and p.name!='完了.json'}})
    print(json.dumps({'成功':True,'旧73同体':len(same),'両端対照':{k:len(v) for k,v in endpoints.items()},
        '取得':{name:{r['id']:{'全取得':len(r['cases']),'新枝':r['new_count']} for r in report['rows']} for name,report in reports.items()}},ensure_ascii=False))


def main() -> None:
    """
    機能: Root GOと固定票SHAの明示指定でのみ178参考適用を開始する。
    引数: --expected-sha(str)、--execute(bool)。
    返り値: None。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--expected-sha',required=True);parser.add_argument('--execute',action='store_true',required=True)
    args=parser.parse_args();run(args.expected_sha)


if __name__=='__main__':main()
