"""技術確認保留中の旧T補完を、元圧力とT固有の受容で判別する純入口。"""
from pathlib import Path
import hashlib
import json
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work/193構造拡大停止と取得位置'))
import rules193 as R
B=R.B
P=R.P
EXTRA=R.EXTRA
_previous_five=R._previous_five
_risk=R._risk
_state=R._state
_reverse_ok=R._reverse_ok
_follow_ok=R._follow_ok
VERSION='195保留中Tの技術根拠1'
CONTROLS=('E193_00','E193_01','E193_02','E193_04','E193_10')


def catalog() -> dict:
    """
    機能: 五対照と二つの元条件×三つのT判別を金融前に固定する。
    引数: なし。
    返り値: dictは全11案の条件と心理仮説。
    """
    rules=[{'id':f'E195_{i:02d}','control':key,'description':'固定対照 '+key} for i,key in enumerate(CONTROLS)]
    source={v['id']:v for v in R.catalog()['rules']}
    for key in ('E193_04','E193_10'):
        for gate in ('ALL','EXPAND','ACCEPT'):
            rule={**source[key],'id':f'E195_{len(rules):02d}','base':key,'t_gate':gate}
            rule['description']=key+'／保留T '+gate
            rules.append(rule)
    return {'version':VERSION,'candidate_count':11,'rules':rules,'base_specification':R.catalog(),
        'input':'旧81場のみ。11/16Night・11/17Dayの追加二場は条件作成に入力しない。',
        'target':'旧リスク要求の技術確認setupが有効な間だけ旧Tを判別する。保有・金融・未来を純判断へ入力しない。',
        'ALL':'有効なsetupの保留中は全Tを遮断する対照。全遮断を正解と仮定しない。',
        'EXPAND':'Tが保留した反転方向と同じで、元側の現在riskが既知成立し、元5分/15分MA差がsetup時以上かつ一つは拡大なら遮断。MA差は同一setupATRで比較。未知は既存Tを保持してフラグ。',
        'ACCEPT':'T方向ごとの初回純T時点Last/ATRを固定し、2観測・60秒・侵入<=.1ATR・各量>=.5/平均量>=.75・価格進行>=.1ATRのC60受容を確認する。現在の実側5分MA差/DI>0、MACD/RSI増分、1分実体/進行と品質も必要。',
        'T_state':'T固有状態は旧setupとともに失効。初回Tには正常価格と正ATRが必要、同秒では成熟しない。以後は純Tがないq0も受容履歴に含めるが、入口は現在Tが成立した時だけ。LC時は受容をリセットする。',
        'unknown':'EXPANDの未知はT保持、ACCEPTの確認未知はT不成立。両方とも場/q0分母を残し未知を安全へ置換しない。',
        'preserve':'旧幹/LC、反転と順行確認、元幅/期限、C120、reset、全決済15分前、追加禁止は193同体。Tは元の±200/H60、開始45分後かつ場の初取得前だけ。',
        'psychology':'同じ反転を警戒して待っているのに、別名の補完注文だけが同方向へ入るなら確認を迂回する。一方、T固有の価格受容と技術根拠ができた時は待機理由が変わった可能性があり、無条件全遮断と比較する。',
        'limits':['旧81は既使用。前48選択/全80発見/本日1診断を分ける。',
            '純T件数、45分後初取得前の金融engine要求、実取得を区別する。',
            'Tを保有未知の穴埋めと呼ばない。枠変化と確認枝単体の優位を分ける。',
            '単純IFD固定。出口改善と利益最大化の探索は行わない。']}


def _filter_t(out: dict, diag: dict, pending: dict, arrays: list, i: int,
              times: np.ndarray, prices: dict, rule: dict) -> None:
    """
    機能: 保留中のT固有受容を更新し、現在のTだけを因果的に許可又は遮断する。
    引数: out/diag/pending/prices/rule(dict)、arrays(list)、i(int)、times(np.ndarray)。
    返り値: None。outのtechnical/tierだけを変更し、診断を追記する。
    """
    sign=int(out['birth']['technical'][i]);mode=rule['t_gate']
    states=pending.setdefault('t_states',{})
    accepted={}
    if mode=='ACCEPT':
        if sign and sign not in states:
            side=0 if sign==1 else 1;x=arrays[side]
            if prices['normal'][i] and P._has(x,i,'m5_atr') and x['m5_atr'][i]>0:
                states[sign]={'event':i,'level':float(prices['last'][i]),'atr':float(x['m5_atr'][i]),'accept':None}
        for direction,state in states.items():
            side=0 if direction==1 else 1;x=arrays[side]
            observed=P._accept(state,x,i,direction,times,prices,P.PROFILES['C60'])
            technical=(P._has(x,i,'m5_gap_to_side','m5_di_difference_to_side')
                and x['m5_gap_to_side'][i]>0 and x['m5_di_difference_to_side'][i]>0
                and P._quality(x,i,prices) and P._momentum(x,i) and P._structure(x,i))
            accepted[direction]=bool(P._mature(state,observed,i,direction,times,prices,P.PROFILES['C60']) and technical)
    if not sign:return
    diag['pending_t_signal'][i]=True;diag['pending_t_from'][i]=pending['event']
    allow=False
    if mode=='EXPAND':
        allow=True
        if sign==pending['direction']:
            source=arrays[1 if sign==1 else 0];seed=pending['event']
            risk=_risk(source,i,rule['risk'],bool(prices['normal'][i]))
            names=('m5_gap_to_side','m15_gap_to_side')
            known=P._has(source,i,*names) and P._has(source,seed,*names)
            diag['pending_t_unknown'][i]=(risk==-1 or not known)
            if known and risk==1:
                change=[(source[k][i]-source[k][seed])/pending['atr'] for k in names]
                allow=not(all(v>=0 for v in change) and any(v>0 for v in change))
    elif mode=='ACCEPT':
        allow=accepted.get(sign,False)
        if sign in states:diag['pending_t_accept_from'][i]=states[sign]['event']
    if not allow:
        out['birth']['technical'][i]=0;out['birth']['tier'][i]=0
        diag['pending_t_blocked'][i]=True
    else:diag['pending_t_allowed'][i]=True


def build(features: object, base_bundle: dict, candidate_ids: list | None=None) -> dict:
    """
    機能: 旧二方向受容を維持し、保留中Tの扱いが異なる11候補を作る。
    引数: features(FeatureDataset互換、q0_prices必須)、base_bundle(dict)、candidate_ids(list[str]|None)。
    返り値: dictはcandidate_ids/bundles/diagnostics。金融/保有を入力しない。
    """
    mapping={r['id']:r for r in catalog()['rules']};ids=list(mapping) if candidate_ids is None else candidate_ids
    assert len(ids)==len(set(ids)) and set(ids)<=set(mapping)
    arrays,meta,times,phases,reset,prices=P._prepare(features);n=len(times)
    columns=[c['name'] if isinstance(c,dict) else c for c in P.P._get(features,'columns')]
    for side,name in enumerate(('buy_X','sell_X')):
        for column in EXTRA:arrays[side][column]=np.asarray(P.P._get(features,name))[:,columns.index(column)]
    previous=_previous_five(arrays,reset)
    base,_,_=P.P.OLD.V1._base(base_bundle,n,phases)
    controls=R.build(features,base_bundle,[mapping[k]['control'] for k in ids if 'control' in mapping[k]])
    bundles={};diagnostics={}
    for identity in ids:
        rule=mapping[identity]
        if 'control' in rule:
            bundles[identity]=controls['bundles'][rule['control']];diagnostics[identity]=controls['diagnostics'][rule['control']];continue
        out={'birth':{k:v.copy() for k,v in base['birth'].items()},**{k:base[k].copy() for k in ('mw','fw','hi','added')}}
        diag={'guarded':np.zeros(n,bool),'risk_unknown':np.zeros(n,bool),'reverse_confirmed':np.zeros(n,bool),
            'follow_confirmed':np.zeros(n,bool),'pending_from':np.full(n,-1,np.int64),'retest_event':np.full(n,-1,np.int64),
            'accept_event':np.full(n,-1,np.int64),'accept_seconds':np.zeros(n),'accept_count':np.zeros(n,np.int16),
            'max_penetration_atr':np.full(n,np.nan),'level':np.full(n,np.nan),'reverse_bb_level':np.zeros(n,bool),
            'delay_seconds':np.zeros(n),'competing':np.zeros(n,bool),
            'pending_t_signal':np.zeros(n,bool),'pending_t_blocked':np.zeros(n,bool),'pending_t_allowed':np.zeros(n,bool),
            'pending_t_unknown':np.zeros(n,bool),'pending_t_from':np.full(n,-1,np.int64),
            'pending_t_accept_from':np.full(n,-1,np.int64)}
        pending=None;profile=P.PROFILES[rule['profile']]
        for i in range(n):
            if reset[i]:pending=None
            if pending is not None and times[i]-times[pending['event']]>1800:pending=None
            if base['added'][i]:
                if pending is not None:
                    pending['reverse']['accept']=None;pending['follow']['accept']=None
                    pending.pop('t_states',None)
                continue
            original=int(base['birth']['core'][i])
            if original:
                side=0 if original==1 else 1;risk=_risk(arrays[1-side],i,rule['risk'],bool(prices['normal'][i]))
                diag['risk_unknown'][i]=risk==-1
                if risk!=1:pending=None;continue
                proposed=_state(i,original,arrays,prices,base)
                if proposed is None:diag['risk_unknown'][i]=True;pending=None;continue
                diag['guarded'][i]=True
                for key,value in (('core',0),('branches',-1),('technical',0),('tier',0)):out['birth'][key][i]=value
                if pending is None or pending['direction']!=original:pending=proposed
            if pending is None or i<=pending['event'] or times[i]<=times[pending['event']] or out['birth']['core'][i]!=0:continue
            _filter_t(out,diag,pending,arrays,i,times,prices,rule)
            side=0 if pending['direction']==1 else 1;sign=pending['direction'];source_side=1-side;source_sign=-sign
            accept=P._accept(pending['reverse'],arrays[side],i,sign,times,prices,profile)
            reverse=(P._mature(pending['reverse'],accept,i,sign,times,prices,profile) and _reverse_ok(pending,arrays,side,i,prices,rule,previous))
            follow=False;other=None
            if rule['mode']=='SWITCH':
                distance=source_sign*(float(prices['last'][i])-pending['follow']['level'])/pending['atr']
                if pending['retest_event']<0 and prices['normal'][i] and -.2<=distance<=.2:pending['retest_event']=i
                if pending['retest_event']>=0 and i>pending['retest_event'] and times[i]>times[pending['retest_event']]:
                    other=P._accept(pending['follow'],arrays[source_side],i,source_sign,times,prices,profile)
                    follow=(P._mature(pending['follow'],other,i,source_sign,times,prices,profile) and _follow_ok(pending,arrays,source_side,i,prices,rule))
            if reverse and follow:diag['competing'][i]=True;continue
            if not reverse and not follow:continue
            selected=pending['reverse'] if reverse else pending['follow'];observed=accept if reverse else other
            out['birth']['core'][i]=sign if reverse else source_sign
            for key in ('branches','technical','tier'):out['birth'][key][i]=0
            for key in ('mw','fw','hi'):out[key][i]=pending[key]
            out['added'][i]=False
            diag['reverse_confirmed'][i]=reverse;diag['follow_confirmed'][i]=follow
            diag['pending_from'][i]=pending['event'];diag['retest_event'][i]=pending['retest_event'];diag['accept_event'][i]=observed['event']
            diag['accept_seconds'][i]=times[i]-observed['time'];diag['accept_count'][i]=observed['count']
            diag['max_penetration_atr'][i]=max(0,-observed['min_distance']);diag['level'][i]=selected['level']
            diag['reverse_bb_level'][i]=pending['reverse_level_kind']=='固定BB1σ端'
            diag['delay_seconds'][i]=times[i]-times[pending['event']];pending=None
        lc=base['added'].astype(bool)
        assert all(np.array_equal(out['birth'][k][lc],base['birth'][k][lc]) for k in base['birth'])
        bundles[identity]=out;diagnostics[identity]=diag
    return {'version':VERSION,'candidate_ids':ids,'bundles':bundles,'diagnostics':diagnostics}


def write_catalog(path: Path) -> None:
    """
    機能: 新195の全条件と直接Sourceを金融前に新規保存する。
    引数: path(Path)は未作成JSON。
    返り値: None。旧Source・固定条件を変更しない。
    """
    assert not path.exists()
    sources=[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
        for p in (Path(__file__),Path(R.__file__),Path(B.__file__),Path(P.__file__))]
    path.write_text(json.dumps({**catalog(),'Source':sources,'新195金融未入力':True},ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
