"""共用48byte価格索引から、事前締切発注を持つ179専用IFD表を生成する。"""
from pathlib import Path
from dataclasses import dataclass
import gzip
import hashlib
import importlib.util
import json
import math
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
VERSION='179終了前の事前決済1'
CONFIG={'終了前秒':900,'決済要求余裕秒':60,'強制注文最小遅延秒':1,
    '価格BBO最大gap秒':300,'通常期限猶予秒':30,'1pt円':100,'往復手数料円':77,'往復追加滑り円':1000}
STATUS={1:'順行先着',2:'逆行先着',3:'通常期限返済',4:'事前要求の強制返済',
    10:'価格gap未知',11:'BBOgap未知',12:'通常期限BBO不足',13:'強制返済窓BBO不足',14:'EOF未知',15:'新規停止後の取得'}
FLOAT_KEYS=('net','net0','exit_time','known_at','holding_confirmed_until','exit_deadline',
    'nominal_deadline','exit_quote_time','exit_price','points')


def sha(path: Path) -> str:
    """
    機能: 入力/SourceのSHA256を返す。
    引数: path(Path)。
    返り値: strは十六進指紋。
    """
    with path.open('rb') as source:return hashlib.file_digest(source,'sha256').hexdigest()


def module(path: Path, name: str) -> object:
    """
    機能: 既存の固定Sourceを明示名で読み込む。
    引数: path(Path)、name(str)。
    返り値: objectはmodule。自然入力を自動生成しない。
    """
    spec=importlib.util.spec_from_file_location(name,path);result=importlib.util.module_from_spec(spec)
    sys.modules[name]=result;spec.loader.exec_module(result);return result


def allocate(count: int, widths: list, horizons: list) -> dict:
    """
    機能: 金融未知をNaN/known=Falseとして明示したoverlay配列を確保する。
    引数: count(int)、widths/horizons(list)。
    返り値: dict[str,np.ndarray]はcase×実側×幅×期限。
    """
    shape=(count,2,len(widths),len(horizons));arrays={k:np.full(shape,np.nan) for k in FLOAT_KEYS}
    arrays.update({k:np.full(shape,-1,np.int64) for k in ('exit_index','exit_line')})
    arrays.update(label=np.full(shape,2,np.int8),known=np.zeros(shape,bool),forced=np.zeros(shape,bool),
        status=np.full(shape,14,np.int16),direction=np.zeros(shape,np.int8))
    return arrays


@dataclass
class PriceIndex:
    """正常実側極値木と価格/BBO gap位置を、場内の全case/幅/期限へ共有する。"""
    rows: np.ndarray

    def __post_init__(self) -> None:
        """
        機能: 正常BBO・gap300と原行順minmax木を構築する。
        引数: self(PriceIndex)は48byte互換の構造化配列を持つ。
        返り値: None。自然金融集計・順位付けは行わない。
        """
        rows=self.rows;self.times=rows['time'];n=len(rows)
        assert n and np.isfinite(self.times).all() and np.all(np.diff(self.times)>=0)
        assert np.all(np.diff(rows['source_line'])>0)
        self.normal=np.flatnonzero((rows['normal']==1)&np.isfinite(rows['bid'])&np.isfinite(rows['ask'])&(rows['bid']>0)&(rows['bid']<rows['ask']))
        self.price_gaps=np.flatnonzero(np.diff(self.times)>CONFIG['価格BBO最大gap秒'])+1
        previous=np.maximum.accumulate(np.where(np.isin(np.arange(n),self.normal),np.arange(n),-1))
        previous=np.r_[-1,previous[:-1]];self.previous_normal=np.where(previous>=0,self.times[np.maximum(previous,0)],np.nan)
        self.bbo_gaps=np.flatnonzero((previous>=0)&(self.times-self.previous_normal>CONFIG['価格BBO最大gap秒']))
        self.size=1<<(n-1).bit_length()
        self.minimum=np.full((2,2*self.size),np.inf);self.maximum=np.full((2,2*self.size),-np.inf)
        for side,column in enumerate(('bid','ask')):
            self.minimum[side,self.size+self.normal]=rows[column][self.normal]
            self.maximum[side,self.size+self.normal]=rows[column][self.normal]
        level=self.size//2
        while level:
            self.minimum[:,level:2*level]=np.minimum(self.minimum[:,2*level:4*level:2],self.minimum[:,2*level+1:4*level:2])
            self.maximum[:,level:2*level]=np.maximum(self.maximum[:,2*level:4*level:2],self.maximum[:,2*level+1:4*level:2]);level//=2

    def first_outside(self, start: int, stop: int, lower: float, upper: float, side: int) -> int:
        """
        機能: 半開原行区間で実側価格が上下閾値へ初めて触れた位置を返す。
        引数: start/stop(int)、lower/upper(float)、side(int、0はBid/1はAsk)。
        返り値: intは最初の採用原行index、未到達は-1。
        """
        if start>=stop:return -1
        stack=[(1,0,self.size)]
        while stack:
            node,left,right=stack.pop()
            if right<=start or stop<=left:continue
            if self.minimum[side,node]>lower and self.maximum[side,node]<upper:continue
            if right-left==1:return left if left<len(self.rows) else -1
            middle=(left+right)//2;stack.append((node*2+1,middle,right));stack.append((node*2,left,middle))
        return -1

    def censor(self, entry: int, deadline: float) -> tuple:
        """
        機能: 旧163と同じ価格/BBO gap300の最初の打切りを求める。
        引数: entry(int)は取得原行、deadline(float)は有効評価期限。
        返り値: tuple[int,int]は排他的原行終端と未知status。価格gapを同原行で優先する。
        """
        stop=len(self.rows);status=0
        at=np.searchsorted(self.price_gaps,entry,side='right')
        if at<len(self.price_gaps):
            index=int(self.price_gaps[at])
            if self.times[index-1]<deadline:stop=index;status=10
        at=np.searchsorted(self.bbo_gaps,entry,side='right')
        if at<len(self.bbo_gaps):
            index=int(self.bbo_gaps[at])
            if self.previous_normal[index]<deadline and index<stop:stop=index;status=11
        return stop,status

    def first_normal(self, time: float, after: int=-1) -> int:
        """
        機能: 指定秒以上かつ取得後の最初の正常BBO原行を求める。
        引数: time(float)、after(int)は除外する取得原行。
        返り値: intは原行位置、該当なしは-1。同秒後続も原行順で扱う。
        """
        position=max(int(np.searchsorted(self.times[self.normal],time,side='left')),int(np.searchsorted(self.normal,after,side='right')))
        return int(self.normal[position]) if position<len(self.normal) else -1

    def last_normal(self, entry: int, stop: int) -> int:
        """
        機能: 有効観測区間内で最後に正常BBOを確認した原行を返す。
        引数: entry(int)、stop(int)は排他的観測終端。
        返り値: intは少なくとも保有を確認できた行。取得より前へ戻さない。
        """
        at=int(np.searchsorted(self.normal,stop,side='left'))-1
        return max(entry,int(self.normal[at])) if at>=0 else entry


def terminal(index: PriceIndex, entry: int, nominal: float, cut: float, forced_index: int) -> dict:
    """
    機能: 通常期限/強制返済の早い原行と、未知打切りを幅非依存で求める。
    引数: index(PriceIndex)、entry(int)、nominal/cut(float)、forced_index(int)。
    返り値: dictは返済候補・touch終端・未知status・未到達確認時刻。
    """
    horizon=index.first_normal(nominal,entry) if math.isfinite(nominal) else -1
    if horizon>=0 and (index.times[horizon]>nominal+CONFIG['通常期限猶予秒'] or index.times[horizon]>cut):horizon=-1
    candidates=[(i,kind) for i,kind in ((horizon,3),(forced_index,4)) if i>=0]
    selected,kind=min(candidates,key=lambda x:(x[0],-x[1])) if candidates else (-1,0)
    end_time=float(index.times[selected]) if selected>=0 else cut
    # ----------------------------------------
    # 先に通常期限の猶予が切れた不観測は、後の強制価格で既知へ復活させない。
    expired=math.isfinite(nominal) and end_time>nominal+CONFIG['通常期限猶予秒']
    if expired:selected=-1;kind=0
    observation=min(nominal,end_time if selected>=0 else cut)
    gap,gap_status=index.censor(entry,observation)
    touch_end=int(np.searchsorted(index.times,min(nominal,cut),side='right'))
    if selected>=0:touch_end=min(touch_end,selected+1)
    touch_end=min(touch_end,gap)
    valid=selected>=0 and selected<gap
    hard_end=int(np.searchsorted(index.times,cut,side='right'))
    missing=int(np.searchsorted(index.times,nominal+CONFIG['通常期限猶予秒'],side='right')) if math.isfinite(nominal) else len(index.rows)
    if valid:status=kind
    elif gap<hard_end and gap<=missing and gap<len(index.rows):status=gap_status
    elif index.times[-1]<min(nominal,cut):status=14
    elif expired or math.isfinite(nominal) and nominal+CONFIG['通常期限猶予秒']<cut:status=12
    else:status=13
    return {'exit':selected if valid else -1,'status':status,'touch_end':max(entry+1,touch_end),
        'lower':float(index.times[index.last_normal(entry,max(entry+1,touch_end))]),
        'exit_deadline':min(nominal+CONFIG['通常期限猶予秒'],cut)}


def evaluate_records(records: np.ndarray, entries: np.ndarray, scene_end: float, widths: list, horizons: list) -> dict:
    """
    機能: 一場の共用索引を全case/実側/幅/期限へ共有して早期終了IFDを計算する。
    引数: records(np.ndarray)、entries(np.ndarray[int])、scene_end(float)、widths(list[float])、horizons(list[dict])。
    返り値: dictは同shape配列。元表・原板を変更せず、幅ごとの原板再読を行わない。
    """
    index=PriceIndex(records);cut=float(scene_end-CONFIG['終了前秒']);submit=cut-CONFIG['決済要求余裕秒']
    forced=index.first_normal(submit+CONFIG['強制注文最小遅延秒'])
    if forced>=0 and index.times[forced]>cut:forced=-1
    arrays=allocate(len(entries),widths,horizons)
    for ci,value in enumerate(entries):
        entry=int(value);assert 0<=entry<len(records) and entry in index.normal
        entry_time=float(index.times[entry])
        if entry_time>=submit:
            arrays['status'][ci]=15;continue
        nominal=[cut if h['kind']=='session' else entry_time+float(h['seconds']) for h in horizons]
        terms=[terminal(index,entry,float('inf') if h['kind']=='session' else deadline,cut,forced) for h,deadline in zip(horizons,nominal,strict=True)]
        global_gap,_=index.censor(entry,cut)
        global_end=min(global_gap,int(np.searchsorted(index.times,cut,side='right')),forced+1 if forced>=0 else len(records))
        for side,sign in enumerate((1,-1)):
            price=float(records['ask' if sign==1 else 'bid'][entry]);mark_column='bid' if sign==1 else 'ask'
            hits=[index.first_outside(entry+1,global_end,price-width,price+width,side) for width in widths]
            for wi,hit in enumerate(hits):
                for hi,term in enumerate(terms):
                    key=(ci,side,wi,hi);arrays['status'][key]=term['status'];arrays['holding_confirmed_until'][key]=term['lower']
                    arrays['exit_deadline'][key]=term['exit_deadline'];arrays['nominal_deadline'][key]=nominal[hi]
                    touched=hit>=0 and hit<term['touch_end']
                    exit_index=hit if touched else term['exit']
                    if exit_index<0:continue
                    mark=float(records[mark_column][exit_index]);points=sign*(mark-price);at=float(records['time'][exit_index])
                    label=(1 if points>=widths[wi] else -1) if touched else 0
                    if touched:assert abs(points)>=widths[wi]-1e-9
                    arrays['label'][key]=label;arrays['known'][key]=True;arrays['direction'][key]=label
                    arrays['status'][key]=(1 if label==1 else 2) if touched else term['status']
                    arrays['forced'][key]=not touched and term['status']==4
                    for name,amount in [('net0',points*CONFIG['1pt円']-CONFIG['往復手数料円']),
                        ('net',points*CONFIG['1pt円']-CONFIG['往復手数料円']-CONFIG['往復追加滑り円']),
                        ('exit_time',at),('known_at',at),('holding_confirmed_until',at),('exit_quote_time',at),('exit_price',mark),('points',points)]:arrays[name][key]=amount
                    arrays['exit_index'][key]=exit_index;arrays['exit_line'][key]=records['source_line'][exit_index]
    assert np.array_equal(arrays['label']==2,~arrays['known'])
    assert np.all(arrays['exit_time'][arrays['known']]<=cut)
    return arrays


def binding(context: object, new: bool) -> dict:
    """
    機能: contextのcase順・純取得・評価軸・場時計を小さい指紋へ束縛する。
    引数: context(object)、new(bool)。
    返り値: dict。金融成績・順位は集計しない。
    """
    arrays=context.arrays;entry_digest=hashlib.sha256()
    for key in ('entry_time','entry_index','entry_line','entry_price','session_index'):
        data=np.ascontiguousarray(arrays[key]);entry_digest.update(key.encode());entry_digest.update(data.dtype.str.encode());entry_digest.update(data.tobytes())
    case_digest=hashlib.sha256(json.dumps(list(context.table.case_ids),ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
    return {'追加7':bool(new),'case数':len(context.table.case_ids),'case順SHA256':case_digest,'純取得SHA256':entry_digest.hexdigest(),
        '幅':list(context.table.widths),'期限':list(context.table.horizons),
        '場':[{'session':s['session'],'start':s['start'],'original_end':s['end'],'cut':s['end']-900,'submit':s['end']-960} for s in context.scenes]}


def verify_unchanged(context: object, arrays: dict) -> dict:
    """
    機能: 強制要求より前に旧IFD/通常期限決済が確定した無変更領域を全セル照合する。
    引数: context(object)は旧配列を持つ未置換context、arrays(dict)は179 overlay。
    返り値: dictは照合数と成功。金融成績の集計や順位は作らない。
    """
    submit=np.asarray([s['end']-CONFIG['終了前秒']-CONFIG['決済要求余裕秒'] for s in context.scenes])
    cut=submit[np.asarray(context.case_scene)][:,None,None,None]
    old=context.arrays;safe=old['known']&np.isfinite(old['exit_time'])&(old['exit_time']<cut)
    for key in ('label','known','net','exit_time','exit_index','exit_line'):
        np.testing.assert_array_equal(arrays[key][safe],old[key][safe],err_msg='旧163/167無変更領域: '+key)
    return {'成功':True,'旧既知exitが強制submitより前のセル数':int(safe.sum()),'照合属性':['label','known','net','exit_time','exit_index','exit_line'],
        '通常期限猶予':'期限後30秒以内の正常endpointを返済に使い、touch対象は元期限まで。旧163契約を保持。'}


def build_overlay(context: object, new: bool, output_dir: Path) -> dict:
    """
    機能: F0後に共用163/167索引から179配列を一度生成して保存する。
    引数: context(object)は既存GenericContext、new(bool)、output_dir(Path)は出力先。
    返り値: dictはarrays/metadata/files。自然生成の呼出しはRoot F0後に限る。
    """
    output_dir=Path(output_dir);stem='追加7_overlay179' if new else '旧73_overlay179'
    target=output_dir/(stem+'.npz');metadata_path=output_dir/(stem+'.json');assert not target.exists() and not metadata_path.exists()
    helper=module(ROOT/'work/163任意幅の数値化/arrays163.py','index163_for179')
    directory=ROOT/('inputs/00167_追加七場の入口と共用価格索引/原板数値索引' if new else 'inputs/00163_任意幅の共用価格索引/価格索引')
    manifest_path=directory/'manifest.json';expected=context.table.evidence['索引manifestSHA256'];assert sha(manifest_path)==expected
    manifest=json.loads(manifest_path.read_text(encoding='utf-8'));assert manifest['success']
    assert [r['session'] for r in manifest['scenes']]==context.sessions
    widths=list(context.table.widths);horizons=context.table.evidence['条件']['horizons']
    assert [h['id'] for h in horizons]==list(context.table.horizons)
    arrays=allocate(len(context.table.case_ids),widths,horizons);input_refs=[]
    for si,(scene,ref) in enumerate(zip(context.scenes,manifest['scenes'],strict=True)):
        assert scene['session']==ref['session'] and ref['success'] and ref['all_entries_matched']
        path=directory/ref['index']['path'];assert path.parent==directory
        records=helper.load_records(path,ref['index']['sha256'],ref['rows']);cases=np.flatnonzero(context.case_scene==si)
        entries=np.asarray(context.arrays['entry_index'][cases],np.int64)
        assert np.array_equal(records['time'][entries],context.arrays['entry_time'][cases])
        assert np.array_equal(records['source_line'][entries],context.arrays['entry_line'][cases])
        assert np.array_equal(records['ask'][entries],context.arrays['entry_price'][cases,0]) and np.array_equal(records['bid'][entries],context.arrays['entry_price'][cases,1])
        local=evaluate_records(records,entries,float(scene['end']),widths,horizons)
        for key in arrays:arrays[key][cases]=local[key]
        input_refs.append({'session':scene['session'],'path':path.relative_to(ROOT).as_posix(),'rows':ref['rows'],'sha256':ref['index']['sha256']})
    arrays['unknown_hold_lower_end']=arrays['holding_confirmed_until'].copy()
    arrays['pair_complete']=np.all(arrays['known'],axis=1)
    arrays['pair_known_at']=np.where(arrays['pair_complete'],np.max(arrays['known_at'],axis=1),np.nan)
    unchanged=verify_unchanged(context,arrays)
    metadata={'成功':True,'版':VERSION,'条件':CONFIG,'status名':STATUS,'金融成績の集計なし':True,'binding':binding(context,new),
        'SourceSHA256':sha(Path(__file__)),'163読込SourceSHA256':sha(ROOT/'work/163任意幅の数値化/arrays163.py'),
        'manifest':{'path':manifest_path.relative_to(ROOT).as_posix(),'sha256':expected},'価格索引':input_refs,
        '契約':'cut-60に事前要求、1秒後以降cut以下の最初の正常BBO。IFD同原行優先、通常N/強制N同原行は強制優先。通常grace30/価格BBOgap300維持。',
        '保有下限':'未知は有効観測区間の最後の正常BBO時刻。未知空白を保有下限へ加算しない。新規停止以後のcaseはC/下限NaN。',
        'exit_deadline':'通常期限+grace30とcutの早い方。nominal_deadlineは元期限とSESSIONのcut。',
        '旧数値表の無変更領域照合':unchanged,'arrays':{k:{'shape':list(v.shape),'dtype':str(v.dtype)} for k,v in arrays.items()}}
    assert sha(manifest_path)==expected;output_dir.mkdir(parents=True,exist_ok=True);np.savez_compressed(target,**arrays)
    metadata['NPZ']={'path':target.relative_to(ROOT).as_posix(),'bytes':target.stat().st_size,'sha256':sha(target)}
    metadata_path.write_text(json.dumps(metadata,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    return {'arrays':arrays,'metadata':metadata,'files':{'npz':str(target),'metadata':str(metadata_path),'npz_sha256':metadata['NPZ']['sha256'],'metadata_sha256':sha(metadata_path)}}


def load_overlay(context: object, new: bool, output_dir: Path|None=None) -> dict:
    """
    機能: 生成済みoverlayをSource・純取得・軸・全NPZ指紋確認付きで復元する。
    引数: context(object)、new(bool)、output_dir(Path|None)は省略時このfolderの生成/。
    返り値: dictはarrays/metadata/files。未生成の自然金融を自動計算しない。
    """
    output_dir=HERE/'生成' if output_dir is None else Path(output_dir);stem='追加7_overlay179' if new else '旧73_overlay179'
    target=output_dir/(stem+'.npz');metadata_path=output_dir/(stem+'.json');metadata=json.loads(metadata_path.read_text(encoding='utf-8'))
    assert metadata['成功'] and metadata['版']==VERSION and metadata['条件']==CONFIG and metadata['binding']==binding(context,new)
    assert metadata['SourceSHA256']==sha(Path(__file__)) and sha(target)==metadata['NPZ']['sha256']
    assert sha(ROOT/metadata['manifest']['path'])==metadata['manifest']['sha256']
    with np.load(target,allow_pickle=False) as sealed:
        assert set(sealed.files)==set(metadata['arrays']);arrays={k:sealed[k].copy() for k in sealed.files}
    assert all(list(v.shape)==metadata['arrays'][k]['shape'] and str(v.dtype)==metadata['arrays'][k]['dtype'] for k,v in arrays.items())
    return {'arrays':arrays,'metadata':metadata,'files':{'npz':str(target),'metadata':str(metadata_path),'npz_sha256':sha(target),'metadata_sha256':sha(metadata_path)}}
