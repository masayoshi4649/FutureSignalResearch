"""固定179全期J035のデイ純出生を、旧固定部品だけで再生成する。"""
from pathlib import Path
from types import SimpleNamespace
import hashlib
import importlib.util
import json
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
HORIZONS = ['H30', 'H60', 'H120', 'SESSION']
FIXED174 = ROOT / 'work/174参加と両中央値の再探索/旧73jointの固定選択.json'
FIXED179 = ROOT / 'work/179保有参加の探索/旧73の固定選択.json'
RULE_KEYS = ('id', 'source', 'rule', 'mode', 'orientation', 'width', 'horizon', 'birth_key')
NEW_KEYS = ('id', 'family', 'rule_id', 'orientation', 'birth_key', 'width', 'horizon', 'mode')


def module(path: Path, name: str) -> object:
    """
    機能: 固定Sourceを専用の名前で読み込み、金融初期化は呼ばない。
    引数: path(Path)はSource、name(str)は専用module名。
    返り値: objectは読込済みmodule。
    """
    if name in sys.modules:
        return sys.modules[name]
    sys.path.insert(0, str(path.parent))
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    sys.modules[name] = result
    spec.loader.exec_module(result)
    return result


def ref(path: Path) -> dict:
    """
    機能: 継承したSourceと固定票の内容指紋を返す。
    引数: path(Path)はリポジトリ内ファイル。
    返り値: dictは相対path、bytes、sha256。
    """
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size, 'sha256': digest}


def policies() -> tuple:
    """
    機能: 旧174と179の固定IDから技術設定だけを取り出し、別候補へ交換しない。
    引数: なし。
    返り値: tuple[dict,dict]は174デイ政策と179全期J035。金融・順位欄は渡さない。
    """
    old = json.loads(FIXED174.read_text(encoding='utf-8'))
    row = next(r for r in old['選択']['全期']['candidates'] if r['id'] == '全期_J002')
    rules = [{k: r[k] for k in RULE_KEYS} for r in row['options']['DAY']]
    assert {(r['rule'], r['orientation'], r['width'], r['horizon']) for r in rules} == {
        ('MP0057', 'NORMAL', 150, 'H60'), ('BO0065', 'REVERSE', 350, 'H60')}
    fallback = row.get('fallback_by_band', row.get('fallback', False))
    day_fallback = bool(fallback.get('DAY', False)) if isinstance(fallback, dict) else bool(fallback)
    inherited = {'id': row['id'], 'options': {'DAY': rules},
        'fallback_by_band': {'DAY': day_fallback},
        'day_fallback_after_minutes': row.get('day_fallback_after_minutes', 45)}
    assert inherited['day_fallback_after_minutes'] == 45 and day_fallback
    new = json.loads(FIXED179.read_text(encoding='utf-8'))
    row = next(r for r in new['選択']['全期']['candidates'] if r['id'] == '全期_J035')
    change = row['changes']['DAY']
    rules = [{k: r[k] for k in NEW_KEYS} for r in change['rules']]
    assert len(rules) == 1 and rules[0]['rule_id'] == 'VLC0003_EDGE'
    assert rules[0]['orientation'] == 'NORMAL' and rules[0]['width'] == 400
    assert rules[0]['horizon'] == 'SESSION' and change['mode'] == 'ADD'
    assert row['base'] == '178/全期_J002_J000_K012'
    assert all(row['changes'][b] == {'mode': 'KEEP', 'rules': []} for b in ('PRE', 'POST'))
    selected = {'id': row['id'], 'base': row['base'],
        'changes': {'DAY': {'mode': 'ADD', 'rules': rules},
                    'PRE': {'mode': 'KEEP', 'rules': []}, 'POST': {'mode': 'KEEP', 'rules': []}}}
    return inherited, selected


def build(features: object) -> dict:
    """
    機能: 同じ当時特徴から旧178デイ対照と固定179全期J035の純出生を作る。
    引数: features(FeatureDataset互換)はbuy_X/sell_X[N,100]、columns、q0_meta、
          scenes、q0_timeband。q0_metaはsession/session_index/contract/q0_time/q0_index/q0_line。
    返り値: dictの全期_J035/旧178_新時計それぞれがbirth/mw/fw/hi/addedを持つ。
          旧場検査では夜間行をゼロ化する。金融・価格将来・口座・取得判定は入力しない。
    """
    inherited, selected = policies()
    phases = np.asarray(features.q0_timeband, dtype=np.int8)
    n = len(features.q0_meta)
    assert phases.shape == (n,) and np.isin(phases, (0, 1, 2)).all()
    old = module(ROOT / 'work/174追加七場適用/固定政策を適用する.py', 'old174_pure180')
    stage = module(ROOT / 'work/174参加と両中央値の再探索/段階再生174.py', 'delay174_pure180')
    p179 = module(ROOT / 'work/179保有参加の探索/探索179.py', 'compose179_pure180')
    pure = module(ROOT / 'work/179量と構造の純入口/rules179.py', 'rules179_pure180')

    # ----------------------------------------
    directions = old.build_directions(features, [inherited])
    base, _, _ = old.B.P.baseline(SimpleNamespace(features=features))
    birth, mw, fw, hi, _, _ = old.compose(phases, inherited['options'], directions,
        base['technical'], base['tier'], HORIZONS, inherited['fallback_by_band'])
    birth = stage.delay_day_fallback(birth, phases,
        np.asarray([q['session_index'] for q in features.q0_meta]),
        [(q['q0_time'], q['q0_index'], q['q0_line']) for q in features.q0_meta],
        np.asarray([s['start'] for s in features.scenes]), inherited['day_fallback_after_minutes'])
    # 177/178は夜間だけの変更なので、旧174デイが旧178デイと同一である。
    seal = {**birth, 'mw': mw, 'fw': fw, 'hi': hi}
    contrast = {'birth': {k: v.copy() for k, v in birth.items()},
        'mw': mw.copy(), 'fw': fw.copy(), 'hi': hi.copy(), 'added': np.zeros(n, bool)}

    # ----------------------------------------
    born = pure.build(features, np.asarray([s['start'] for s in features.scenes]), phases,
                      candidate_ids=['VLC0003_EDGE'])
    assert born['candidate_ids'] == ['VLC0003_EDGE']
    previous = (p179.CTX, p179.SEALS, p179.DIRS)
    try:
        p179.CTX = SimpleNamespace(event_phases=phases, table=SimpleNamespace(horizons=HORIZONS))
        p179.SEALS = {selected['base']: seal}
        p179.DIRS = {'VLC0003_EDGE/NORMAL': born['directions'][0]}
        main_birth, main_mw, main_fw, main_hi, added = p179.compose(selected)
    finally:
        p179.CTX, p179.SEALS, p179.DIRS = previous
    main = {'birth': main_birth, 'mw': main_mw, 'fw': main_fw, 'hi': main_hi, 'added': added}
    result = {'全期_J035': main, '旧178_新時計': contrast}
    for bundle in result.values():
        for key in ('core', 'technical', 'tier'):
            bundle['birth'][key][phases != 0] = 0
        bundle['birth']['branches'][phases != 0] = -1
        bundle['added'][phases != 0] = False
    return result


def references() -> list[dict]:
    """
    機能: adapterが直接継承した固定票とSourceの指紋を列挙する。
    引数: なし。
    返り値: list[dict]は旧条件を変えていないことを照合する参照票。
    """
    return [ref(p) for p in (Path(__file__), FIXED174, FIXED179,
        ROOT / 'work/174追加七場適用/固定政策を適用する.py',
        ROOT / 'work/174参加と両中央値の再探索/段階再生174.py',
        ROOT / 'work/172ナイト入口探索/選定政策の出生.py',
        ROOT / 'work/172ナイト入口探索/再生172.py',
        ROOT / 'work/179量と構造の純入口/rules179.py',
        ROOT / 'work/179保有参加の探索/探索179.py')]
