"""本日デイへ179固定入口と旧178対照を同じ終了時計で適用する。"""
from pathlib import Path
import hashlib
import json
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).parent
TRIAL = ROOT / 'study/00180_固定179入口を十一月十六日デイへ適用する'
sys.path.insert(0, str(ROOT / 'work/179保有参加の探索'))
import 探索179 as P
import 基盤179 as M
import 固定結果を作る as FIXED


def ref(path: Path) -> dict:
    """
    機能: 作業・恒久ファイルのサイズとSHAを記録する。
    引数: path(Path)は入力又は生成ファイル。
    返り値: dictはリポジトリ相対パス、サイズ、指紋。
    """
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size, 'sha256': digest}


def main() -> None:
    """
    機能: 非金融入力・固定方向を封印してから179の金融と数量再生を実行する。
    引数: なし。
    返り値: None。固定2政策の全取得・保有・損益と証拠を保存する。
    """
    P.verify()
    freeze = P.B.P.module(HERE / '条件を固定する.py', 'freeze180')
    freeze.main()
    fixed = P.B.P.read(TRIAL / '条件.json')
    source = P.B.P.module(HERE / '入力180.py', 'input180')
    rules = P.B.P.module(HERE / '純方向180.py', 'pure180')
    loaded = source.load_context()
    context = loaded['context']
    assert context.sessions == ['2026-11-16_Day']
    assert not context.arrays['known'].any()
    bundles = rules.build(context.features)
    assert set(bundles) == {'全期_J035', '旧178_新時計'}
    sources = [Path(__file__), HERE / '入力180.py', HERE / '純方向180.py',
               HERE / '条件を固定する.py']
    before = [ref(path) for path in sources]

    # ----------------------------------------
    directions = {}
    for name, bundle in bundles.items():
        for key, value in bundle['birth'].items():
            directions[name + '__' + key] = value
        for key in ('mw', 'fw', 'hi', 'added'):
            directions[name + '__' + key] = bundle[key]
    sealed = HERE / '本日の純出生.npz'
    assert not sealed.exists()
    np.savez_compressed(sealed, **directions)
    P.B.P.save(HERE / '金融前の接続.json', {'成功': True, 'Source': before,
        '条件': ref(TRIAL / '条件.json'), '純出生': ref(sealed), '入力': loaded['proof'],
        '再探索': False, '当日金融未評価': True})

    # ----------------------------------------
    early = P.B.P.module(ROOT / 'work/179終了前決済/early179.py', 'early179_for180')
    records = loaded['records']
    entries = np.asarray(context.arrays['entry_index'], dtype=np.int64)
    assert np.array_equal(records['time'][entries], context.arrays['entry_time'])
    assert np.array_equal(records['source_line'][entries], context.arrays['entry_line'])
    assert np.array_equal(records['ask'][entries], context.arrays['entry_price'][:, 0])
    assert np.array_equal(records['bid'][entries], context.arrays['entry_price'][:, 1])
    horizon_spec = context.table.evidence['条件']['horizons']
    assert [h['id'] for h in horizon_spec] == list(context.table.horizons)
    overlay = early.evaluate_records(records, entries, context.scenes[0]['end'],
                                     list(context.table.widths), horizon_spec)
    overlay_path = HERE / '本日の終了前金融.npz'
    assert not overlay_path.exists()
    np.savez_compressed(overlay_path, **overlay)
    binding = early.binding(context, False)
    del binding['追加7']
    binding['対象期間'] = '2026-11-16_Dayの1場'
    P.B.P.save(HERE / '終了前金融の接続.json', {'成功': True, '金融Source': ref(Path(early.__file__)),
        'binding': binding, '価格索引': loaded['index_ref'],
        'overlay': ref(overlay_path), '条件': early.CONFIG, '新規探索': False})
    context.arrays.update(overlay)
    original_factory = M.B.load_context
    try:
        M.B.load_context = lambda new=False: context
        context = M.load_context()
    finally:
        M.B.load_context = original_factory

    # ----------------------------------------
    P.CTX = context
    P.CAPS = M.B.captures(context)
    original_compose = P.compose

    def compose(policy: dict) -> tuple:
        """
        機能: 封印した固定方向・幅・期限だけを旧179のpackへ渡す。
        引数: policy(dict)は固定政策IDを含む。
        返り値: tupleはbirth/mw/fw/hi/added。
        """
        bundle = bundles[policy['id']]
        return tuple(bundle[key] for key in ('birth', 'mw', 'fw', 'hi', 'added'))

    policies = [fixed['主政策'], {'id': '旧178_新時計', 'route': '固定対照',
        '説明': fixed['対照']}]
    try:
        P.compose = compose
        rows = [FIXED.pack(policy, True) for policy in policies]
    finally:
        P.compose = original_compose
    for row in rows:
        cases = np.asarray(row['selection']['cases'], dtype=np.int64)
        row['ledger']['entry_line'] = context.arrays['entry_line'][cases].tolist()
        row['ledger']['entry_index'] = context.arrays['entry_index'][cases].tolist()
    destination = HERE / '本日の固定結果.json.gz'
    assert not destination.exists()
    P.B.P.save(destination, {'成功': True, '試行': 180, '対象': context.sessions,
        '政策固定': ref(TRIAL / '条件.json'), '再探索': False, 'rows': rows})
    assert [ref(path) for path in sources] == before
    freeze.main()
    P.verify()
    for row in rows:
        evidence = row['evidence']
        finance = evidence['financial']['session_groups_required']['DAY']
        trade = finance['trades']
        print(json.dumps({'id': row['id'], '取得': trade['all_count'],
            '利益': trade['known_profit'], '損失': trade['known_loss'], '収支': trade['known_net'],
            '金融未知': trade['unknown_count'], '先着': trade['IFD_FIRSTFANC'],
            '保有率下限': evidence['holding']['groups']['DAY']['held_lower_ratio']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
