"""167の固定接続器を再用し、11/16Day一場を同じ100特徴・物理取得へ接続する。"""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import argparse
import copy
import gzip
import hashlib
import json
import subprocess
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
OUTPUT=ROOT/'inputs/00180_20261116デイの固定適用入力'
SESSION='2026-11-16_Day'
CONTRACT='161120018'
OLD=ROOT/'inputs/00167_追加七場の入口と共用価格索引'
INDEX_EXE=ROOT/'work/166可変場の観測/可変場観測.exe'
BRIDGE_EXE=ROOT/'work/未見入口の同体接続/入口同体接続.exe'
sys.path.insert(0,str(ROOT/'work/173両中央値と単一建玉'))
import 基盤173 as B


def ref(path: Path) -> dict:
    """
    機能: 市場値を解釈せず物理bytes・SHA・前後statを確認する。
    引数: path(Path)。
    返り値: dictは絶対path/bytes/sha256。
    """
    before=path.stat()
    with path.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
    after=path.stat();assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns)
    return {'path':str(path),'bytes':after.st_size,'sha256':digest}


def read(path: Path) -> dict:
    """
    機能: JSON又はgzip JSONを読む。
    引数: path(Path)。
    返り値: dictは標準JSON。
    """
    body=path.read_bytes();return json.loads(gzip.decompress(body) if path.suffix=='.gz' else body)


def save(path: Path, value: dict) -> None:
    """
    機能: 新規の入力計画・非金融投影・証拠をUTF-8保存する。
    引数: path(Path)、value(dict)。
    返り値: None。既存入力を上書きしない。
    """
    assert not path.exists();path.parent.mkdir(parents=True,exist_ok=True)
    body=(json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode('utf-8')
    path.write_bytes(gzip.compress(body,mtime=0) if path.suffix=='.gz' else body)


def run(name: str, command: list) -> None:
    """
    機能: 固定済みCLIをshellを挟まず実行し、標準出力/エラーを残す。
    引数: name(str)、command(list[str])。
    返り値: None。失敗時は終了し、旧Sourceを変更しない。
    """
    with (OUTPUT/(name+'_stdout.txt')).open('x',encoding='utf-8') as out,(OUTPUT/(name+'_stderr.txt')).open('x',encoding='utf-8') as err:
        result=subprocess.run(command,cwd=ROOT,stdout=out,stderr=err,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    assert result.returncode==0,(name,read_text(OUTPUT/(name+'_stderr.txt')))
    print(json.dumps({'完了段階':name},ensure_ascii=False),flush=True)


def read_text(path: Path) -> str:
    """
    機能: CLI失敗時の短いエラー末尾を取得する。
    引数: path(Path)。
    返り値: strは末尾4000文字。
    """
    return path.read_text(encoding='utf-8',errors='replace')[-4000:]


def generate() -> None:
    """
    機能: 今日を一回索引化し、旧七場の前史を再用して非金融母集団を生成する。
    引数: なし。
    返り値: None。候補/損益を評価せず、旧七場の100特徴/取得対応の全同体を確認する。
    """
    assert not (OUTPUT/'完了.json').exists();OUTPUT.mkdir(parents=True,exist_ok=True)
    raw_dir=ROOT.parent/'JP_OSE_Data/future/NK225'/SESSION
    raw=raw_dir/('book.jsonl.gz' if (raw_dir/'book.jsonl.gz').exists() else 'book.jsonl')
    files={name:ref(path) for name,path in [('raw',raw),('csv_1m',raw_dir/'candle_1min.csv'),('csv_5m',raw_dir/'candle_5min.csv')]}
    source_paths=[Path(__file__),INDEX_EXE,BRIDGE_EXE]
    for name in ('work/未見入口の同体接続/接続器の停止.json','work/166可変場の観測/可変場観測の停止.json','work/166可変場の数値化/数値化の停止.json'):
        path=ROOT/name;stop=read(path);assert stop['成功'];source_paths.append(path)
        for item in stop['Source']:
            candidate=ROOT/item['path'];assert ref(candidate)['sha256']==item['sha256'];source_paths.append(candidate)
    source_refs={str(p):ref(p) for p in sorted(set(source_paths))}
    zone=timezone(timedelta(hours=9));start=datetime(2026,11,16,8,45,tzinfo=zone).timestamp();end=datetime(2026,11,16,15,45,tzinfo=zone).timestamp()
    scene={'session':SESSION,'contract':CONTRACT,'start':start,'end':end,'force_close':end-600,'raw':files['raw'],
        'expected_raw_stat':{'bytes':raw.stat().st_size,'mtime_ns':raw.stat().st_mtime_ns},'expected_accepted':0,'expected_quality':None,'entries':[]}
    fixed=OUTPUT/'索引前の空取得入力.json';save(fixed,{'trial':180,'scenes':[scene],'expected_entry_count':0})
    save(OUTPUT/'入力生成前の固定.json',{'成功':True,'対象':SESSION,'用途':'179全期J035固定条件だけ。本日損益を見て閾値を変えない。','原本':files,'Source':source_refs})
    index_dir=OUTPUT/'原板数値索引'
    run('原板索引',[str(INDEX_EXE),'--mode','index','--input',str(fixed),'--sha256',ref(fixed)['sha256'],'--output-dir',str(index_dir),'--workers','1'])
    measured=read(index_dir/'manifest.json');assert measured['success'] and len(measured['scenes'])==1
    item=measured['scenes'][0];assert item['session']==SESSION and item['contract']==CONTRACT and item['success']
    today={k:scene[k] for k in ('session','contract','start','end','force_close','raw')}
    today.update(expected_accepted=item['rows'],expected_quality=item['quality'],csv_1m=files['csv_1m'],csv_5m=files['csv_5m'],
        quote_index=ref(index_dir/item['index']['path']))
    old_plan=read(OLD/'母集団接続計画.json');old_index=read(OLD/'原板数値索引/manifest.json')
    previous=copy.deepcopy(old_plan['scenes']);combined=[]
    for target in previous:
        record=copy.deepcopy(next(r for r in old_index['scenes'] if r['session']==target['session']))
        assert ref(Path(target['quote_index']['path']))['sha256']==target['quote_index']['sha256']
        record['index']['path']=target['quote_index']['path'];combined.append(record)
    now=copy.deepcopy(item);now['index']['path']=today['quote_index']['path'];combined.append(now)
    manifest=OUTPUT/'前史七場と本日の索引参照.json';save(manifest,{'success':True,'trial':180,'scenes':combined,'価格索引複製なし':True})
    plan=OUTPUT/'母集団接続計画.json'
    save(plan,{'version':1,'trial':180,'transport':'index48','history_through':old_plan['history_through'],
        'history_plan':old_plan['history_plan'],'prior_publications':old_plan['prior_publications'],'index_manifest':ref(manifest),'scenes':previous+[today]})
    population=HERE/'前史七場と本日の母集団'
    run('非金融母集団',[str(BRIDGE_EXE),'--execute-after-f0','--plan',str(plan),'--plan-sha',ref(plan)['sha256'],'--plan-bytes',str(ref(plan)['bytes']),'--output',str(population)])
    complete=read(population/'完了.json');assert complete['success'] and complete['financial_labels_used'] is False
    names=('出生台帳.json.gz','当時特徴.json.gz','取得対応.json.gz','物理取得.json.gz','固定取得入力.json.gz')
    prefix=[];projected={};old_sessions={s['session'] for s in previous}
    for name in names:
        all_data=read(population/name);old_data=read(OLD/'入口母集団'/name);body=copy.deepcopy(all_data)
        key='scenes' if name=='固定取得入力.json.gz' else 'cases' if name=='物理取得.json.gz' else 'rows'
        prior=[r for r in all_data[key] if r['session'] in old_sessions]
        assert prior==old_data[key],('既存七場同体差',name)
        body[key]=[r for r in all_data[key] if r['session']==SESSION]
        if name=='出生台帳.json.gz':body['scenes']=[r for r in all_data['scenes'] if r['session']==SESSION]
        if name=='固定取得入力.json.gz':body['expected_entry_count']=len(body['scenes'][0]['entries'])
        body['counts']={'今日へ射影':True,'対象':SESSION,'金融ラベル未入力':True};projected[name]=body
        prefix.append({'file':name,'既存七場の全件同体':True,'旧数':len(prior),'今日数':len(body[key])})
    directory=OUTPUT/'入口母集団';directory.mkdir()
    for name,value in projected.items():save(directory/name,value)
    save(directory/'完了.json',{'success':True,'trial':180,'financial_labels_used':False,'strategy_selected':False,
        'counts':{'features':len(projected['当時特徴.json.gz']['rows'])},'files':{name:ref(directory/name) for name in names},'旧七場同体':prefix})
    assert all(ref(Path(name))==value for name,value in source_refs.items())
    assert all(ref(Path(value['path']))==value for value in files.values())
    save(OUTPUT/'完了.json',{'成功':True,'対象':SESSION,'原本':files,'Source':source_refs,'旧七場同体':prefix,
        'index':ref(index_dir/'manifest.json'),'母集団':ref(directory/'完了.json'),'前史計画':ref(plan),'金融未生成':True})
    print(json.dumps({'成功':True,'対象':SESSION,'rows':item['rows'],'features':len(projected['当時特徴.json.gz']['rows']),'旧七場同体':True},ensure_ascii=False),flush=True)


def load_context() -> dict:
    """
    機能: 今日一場の純特徴と全C未評価tableをGenericContextへ接続する。
    引数: なし。
    返り値: dictはcontext/features/captures/records/index_ref/proof。Rootが179早期金融を重ねる。
    """
    proof=read(OUTPUT/'完了.json');assert proof['成功'] and proof['金融未生成']
    features,captures,_=B.P.R168.BASE.load_features(OUTPUT/'入口母集団')
    assert len(features.scenes)==1 and features.scenes[0]['session']==SESSION and np.all(features.q0_timeband==0)
    adapter=B.P.module(ROOT/'work/166可変場の数値化/arrays166.py','arrays166_for180')
    manifest=read(OUTPUT/'原板数値索引/manifest.json');item=manifest['scenes'][0]
    index_path=OUTPUT/'原板数値索引'/item['index']['path'];records=adapter.load_records(index_path,item['index']['sha256'],item['rows'])
    fixed=read(OUTPUT/'入口母集団/固定取得入力.json.gz');entries=sorted(fixed['scenes'][0]['entries'],key=lambda r:r['id'])
    config=read(ROOT/'work/163任意幅Raw索引/観測条件の雛形.json');widths=tuple(config['widths']);horizons=tuple(h['id'] for h in config['horizons'])
    arrays=adapter.allocate(len(entries),widths,horizons)
    for row,entry in enumerate(entries):
        quote=entry['entry'];index=int(quote['index']);assert records[index]['normal']==1
        assert all(records[index][key]==quote[key] for key in ('time','source_line','last','bid','ask'))
        for key,column in (('time','entry_time'),('index','entry_index'),('source_line','entry_line')):arrays[column][row]=quote[key]
        arrays['entry_price'][row]=[quote['ask'],quote['bid']];arrays['session_index'][row]=0;arrays['original_side'][row]=entry['side']
    table=adapter.RawOutcomeTable(tuple(e['id'] for e in entries),tuple(SESSION for _ in entries),(SESSION,),widths,horizons,horizons,
        arrays,('未評価',),{'成功':True,'条件':config,'索引manifestSHA256':ref(OUTPUT/'原板数値索引/manifest.json')['sha256'],'金融未評価全C':True})
    context=B.P.R168.BASE.GenericContext(features,table,captures)
    return {'context':context,'features':features,'captures':captures,'records':records,'index_ref':ref(index_path),'proof':proof}


def main() -> None:
    """
    機能: 本日固定適用に必要な可逆な非金融入力生成だけを明示実行する。
    引数: --generate(bool)。
    返り値: None。入口探索や損益最適化を行わない。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--generate',action='store_true');args=parser.parse_args()
    if args.generate:generate()
    else:print(json.dumps({'準備済み':True,'出力':str(OUTPUT),'API':'load_context()'},ensure_ascii=False))


if __name__=='__main__':main()
