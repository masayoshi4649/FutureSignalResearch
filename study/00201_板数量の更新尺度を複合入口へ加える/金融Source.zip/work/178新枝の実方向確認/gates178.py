"""177の正逆変換後の実注文側だけを確認する、状態を持たない純ゲート。"""
from collections.abc import Mapping

import numpy as np

VERSION='178新枝の実方向確認1'
LONG_COLUMNS=tuple(f'm{m}_{name}' for m in (15,30)
    for name in ('ema21_delta_to_side','di_difference_to_side'))


def catalog() -> dict:
    """
    機能: 実方向の背景・動力・量を確認する固定12ゲートを公開する。
    引数: なし。
    返り値: dictはgatesに全条件を持つ。G00は新しい制限のない固定対照。
    """
    gates=[]
    for number in range(12):
        conditions=[]
        if number:
            minimum={1:2,2:3,3:4,4:2,5:3,6:2,7:3,8:2,9:3,10:2,11:3}[number]
            conditions.append({'factor':'long_up_votes','operator':'>=','threshold':minimum})
            if number in (4,5):conditions.append({'factor':'m15_hist_delta_to_side','operator':'>=','threshold':0})
            if number in (6,7):conditions.append({'factor':'m1_volume_relative_prior3','operator':'>=','threshold':.75})
            if number in (8,9):conditions.append({'factor':'m5_di_difference_to_side','operator':'>','threshold':0})
            if number in (10,11):
                conditions.extend({'factor':factor,'operator':'>','threshold':0}
                    for factor in ('m5_hist_delta_to_side','m5_rsi_delta_to_side'))
        gates.append({'id':f'G{number:02d}','conditions':conditions})
    return {'version':VERSION,'gate_count':12,'gates':gates,
        'input':'当時のbuy_X/sell_X/columnsと、177の正逆変換・元ALL/EDGE適用後の方向のみ。金融は入力しない。',
        'direction':'方向+1は買実側、−1は売実側。判定側を反転前Source側へ戻さない。',
        'long_up_votes':{'columns':list(LONG_COLUMNS),'positive':'>0','required_known':'4列すべて有限',
            'meaning':'15分/30分それぞれEMA21傾きとDI差が実注文方向に正である票数。独立確率の投票ではない。'},
        'unknown':'追加条件に必要な列が未知なら不成立。G00は追加条件が無いため入力方向の同体対照。',
        'clock':'状態を持たず当該q0を遮断するだけ。入っていない方向を作らず、EDGEを再発火しない。',
        'scope':'177の新枝だけに適用し旧幹・T・数量時計を変更しない。適用範囲と合成は後段Sourceが担当。'}


def _get(features: object,name: str) -> object:
    """
    機能: 純特徴を辞書又は属性から取り出す。
    引数: features(object)、name(str)。
    返り値: objectは渡された入力。欠けた列を未来や金融で補完しない。
    """
    return features[name] if isinstance(features,Mapping) else getattr(features,name)


def apply(features: object,direction: np.ndarray,gateid: str) -> np.ndarray:
    """
    機能: 正逆変換後の実方向に対応する当時特徴だけで追加ゲートを適用する。
    引数: features(object)はbuy_X/sell_X/columns、direction(np.ndarray[N])は−1/0/+1、
          gateid(str)はG00..G11。
    返り値: np.ndarray[N]のint8。元方向を通すか0にするだけで、新規方向やEDGEを作らない。
    """
    gates={g['id']:g for g in catalog()['gates']}
    if gateid not in gates:raise KeyError('未知の実方向ゲート: '+str(gateid))
    raw=np.asarray(direction);assert raw.ndim==1 and np.isin(raw,(-1,0,1)).all()
    columns=[v['name'] if isinstance(v,dict) else v for v in _get(features,'columns')]
    index={name:i for i,name in enumerate(columns)};assert len(index)==len(columns)
    arrays=[np.asarray(_get(features,name),dtype=np.float64) for name in ('buy_X','sell_X')]
    assert arrays[0].shape==arrays[1].shape==(len(raw),len(columns))
    if gateid=='G00':return raw.astype(np.int8,copy=True)
    allowed=np.zeros(len(raw),bool)
    for side,x in enumerate(arrays):
        active=raw==(1 if side==0 else -1)
        if not active.any():continue
        mask=np.ones(len(raw),bool)
        for condition in gates[gateid]['conditions']:
            factor=condition['factor']
            if factor=='long_up_votes':
                if not set(LONG_COLUMNS)<=set(index):mask[:]=False;break
                values=x[:,[index[name] for name in LONG_COLUMNS]]
                known=np.isfinite(values).all(axis=1)
                value=(values>0).sum(axis=1)
            else:
                if factor not in index:mask[:]=False;break
                value=x[:,index[factor]];known=np.isfinite(value)
            threshold=condition['threshold']
            truth=value>=threshold if condition['operator']=='>=' else value>threshold
            mask &= known&truth
        allowed |= active&mask
    # ----------------------------------------
    # 方向は元の非0点の部分集合。遅延発火・補完方向・EDGE再生成は行わない。
    return np.where(allowed,raw,0).astype(np.int8)
