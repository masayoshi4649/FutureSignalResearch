"""元方向の構造拡大停止と順行取得位置を分離して確認する純入口。"""
from pathlib import Path
import hashlib
import json
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work/191要求起点の受容'))
import rules191 as B
P=B.P

VERSION='193構造拡大停止と再テストの取得位置1'
CONTROLS=('E191_00','E191_07','E191_11','E191_09')
EXTRA=('m15_gap_to_side',)


def catalog() -> dict:
    """
    機能: 旧四対照と二リスク×三役割×二近傍の16案を金融前に定義する。
    引数: なし。
    返り値: dictは全条件・閾値・心理仮説。
    """
    rules=[{'id':f'E193_{i:02d}','control':key,'description':'固定対照 '+key} for i,key in enumerate(CONTROLS)]
    for risk in ('R1','R2'):
        for filter_mode in ('REV','FOLLOW','BOTH'):
            for strict in (False,True):
                rules.append({'id':f'E193_{len(rules):02d}','risk':risk,'mode':'SWITCH','profile':'C120',
                    'filter':filter_mode,'strict':strict,'description':risk+'／'+filter_mode+'／'+('厳' if strict else '緩')})
    return {'version':VERSION,'candidate_count':16,'rules':rules,'profiles':{'C120':P.PROFILES['C120']},
        'input':'191と同じ旧179純入口・当時100特徴・当時q0絶対価格。追加2場は参照しない。',
        'base_specification':B.catalog(),
        'reverse_loose':'191反転確認に加え、元側5分MA差・15分MA差・15分EMA21傾きがsetup時より非拡大。全値既知。差はsetup時ATR5の同一尺度で比較。',
        'reverse_strict':'緩に加え、元15分DIがsetup時以下、新しい5分背景特徴へ更新後で、直前の異なる5分背景よりMA差が非拡大。',
        'five_minute_publication':'m5 ATR/MA差/EMA21傾き/DIの組が変わった当時q0を新しい公表の代理とする。同じ組を繰り返し数えず、実足IDや全ての確定足の存在を保証しない。欠測/resetで履歴を切る。',
        'follow_loose':'191順行確認に加え、実entryのEMA8距離<=1ATR5、BB位置<=1.5σ、固定再テスト水準からの実Last距離<=1setupATR。下限等は191品質条件を継承。',
        'follow_strict':'緩の上限をEMA8 .75ATR5、BB1σ、固定水準.75setupATRにする。',
        'factor':'REVは反転だけ追加確認、FOLLOWは順行だけ位置確認、BOTHは両方。同じC120で比較。',
        'unknown':'旧リスク判別の未知は191通り旧要求保持。新追加確認の必要値未知は不成立とし、未知を収束や安全に置換しない。',
        'clock_width':'元要求の固定水準・setup30分・幅/期限種・正常BBO・C120持続・LC/T優先は191同体。新取得後からIFD期限を測る。',
        'psychology':'DIが一時低下しても短中期MAの拡大が続く間は元の需給が残る可能性。反転は構造拡大停止と価格受容を合わせ、順行は再テスト後に追い過ぎない位置で確認する仮説。',
        'limits':['全81場は既使用で、全80発見と前48選択を分ける。11/16Dayは診断のみ。',
            '現在の背景特徴の変化は真の注文フローや全原板の受容を直接測るものではない。',
            '参加の減少と後続枠の入替を別記し、新確認枝の損益と口座全体を混同しない。',
            '単純IFDに固定、追尾/技術途中決済なし。金融後の変更は新試行。']}


def _previous_five(arrays: list, reset: np.ndarray) -> np.ndarray:
    """
    機能: 変化した5分背景の直前公表代理を因果的に追跡する。
    引数: arrays(list)は側別特徴、reset(np.ndarray[bool])は場/時計品質境界。
    返り値: np.ndarray[int]は直前異特徴のq0番号。不明は−1。
    """
    x=arrays[0];names=('m5_atr','m5_gap_to_side','m5_ema21_delta_to_side','m5_di_difference_to_side')
    out=np.full(len(reset),-1,np.int64);last=-1;previous=-1;signature=None
    for i in range(len(reset)):
        if reset[i] or not P._has(x,i,*names):last=previous=-1;signature=None
        if not P._has(x,i,*names):continue
        current=tuple(float(x[k][i]) for k in names)
        if current!=signature:previous=last;last=i;signature=current
        out[i]=previous
    return out


def _and(items: list) -> int:
    """
    機能: 必要役割の既知Falseを優先する三値ANDを計算する。
    引数: items(list[int])は1/0/−1。
    返り値: intは真/偽/未知。
    """
    return 0 if 0 in items else -1 if -1 in items else 1


def _or(items: list) -> int:
    """
    機能: 代替役割の既知Trueを優先する三値ORを計算する。
    引数: items(list[int])は1/0/−1。
    返り値: intは真/偽/未知。
    """
    return 1 if 1 in items else -1 if -1 in items else 0


def _risk(x: dict, i: int, kind: str, normal: bool) -> int:
    """
    機能: 実方向と反対側の現在の整合・動力を三値判定する。
    引数: x(dict)は反対側特徴、i(int)、kind(str)、normal(bool)。
    返り値: intは既知リスク1/非該当0/UNKNOWN−1。
    """
    if not normal:return -1
    names=('m5_ema21_delta_to_side','m5_di_difference_to_side','m5_hist_delta_to_side','m5_rsi_delta_to_side')
    common=(-1 if not P._has(x,i,*names) else int(x[names[0]][i]>0 and x[names[1]][i]>0 and P._momentum(x,i)))
    if kind=='R1':
        long=[]
        for m in (15,30):
            pair=(f'm{m}_ema21_delta_to_side',f'm{m}_di_difference_to_side')
            long.append(-1 if not P._has(x,i,*pair) else int(x[pair[0]][i]>0 and x[pair[1]][i]>0))
        structure_names=('m1_body_ratio_to_side','m1_close_delta_atr5_to_side','m1_body_reclaim_atr5_to_side','q0_last_minus_m1_close_atr5_to_side')
        structure=-1 if not P._has(x,i,*structure_names) else int(P._structure(x,i))
        return _and([common,_or(long),structure])
    adx=(-1 if not P._has(x,i,'m15_adx','m15_adx_delta') else int(x['m15_adx'][i]>=25 and x['m15_adx_delta'][i]>0))
    bb=(-1 if not P._has(x,i,'q0_entry_minus_bbmean_sigma_to_side') else int(x['q0_entry_minus_bbmean_sigma_to_side'][i]>=1))
    return _and([common,_or([adx,bb])])


def _state(i: int, direction: int, arrays: list, prices: dict, base: dict) -> dict | None:
    """
    機能: 旧要求自体から反転・順行の固定価格と元幅期限を記憶する。
    引数: i/direction(int)、arrays(list)、prices/base(dict)。
    返り値: dict|NoneはATR/価格既知の時だけ作るsetup。
    """
    side=0 if direction==1 else 1;source=arrays[1-side];source_sign=-direction
    if not P._has(source,i,'m5_atr') or source['m5_atr'][i]<=0:return None
    atr=float(source['m5_atr'][i]);last=float(prices['last'][i]);level=last;kind='要求時Last'
    if P._has(source,i,'q0_entry_minus_bbmean_sigma_to_side','bb15_sigma') and source['q0_entry_minus_bbmean_sigma_to_side'][i]>=1 and source['bb15_sigma'][i]>0:
        entry=float(prices['ask'][i] if source_sign==1 else prices['bid'][i])
        level=entry-source_sign*(source['q0_entry_minus_bbmean_sigma_to_side'][i]-1)*source['bb15_sigma'][i]
        kind='固定BB1σ端'
    return {'event':i,'direction':direction,'atr':atr,'reverse_level_kind':kind,
        'reverse':{'level':level,'atr':atr,'accept':None},'follow':{'level':last,'atr':atr,'accept':None},
        'retest_event':-1,**{k:base[k][i] for k in ('mw','fw','hi')}}


def _reverse_ok(state: dict, arrays: list, side: int, i: int, prices: dict, rule: dict, previous: np.ndarray) -> bool:
    """
    機能: 191の失速反転へ短中期の構造非拡大を追加する。
    引数: state/arrays/side/i/pricesは191同体、rule(dict)、previous(np.ndarray[int])。
    返り値: boolは追加確認を満たす場合。未知はFalse。
    """
    if not B._reverse_ok(state,arrays,side,i,prices):return False
    if rule['filter']=='FOLLOW':return True
    source=arrays[1-side];seed=state['event']
    names=('m5_gap_to_side','m15_gap_to_side','m15_ema21_delta_to_side')
    if not P._has(source,i,*names) or not P._has(source,seed,*names):return False
    if any((source[k][i]-source[k][seed])/state['atr']>0 for k in names):return False
    if not rule['strict']:return True
    old=int(previous[i]);signature=('m5_atr','m5_gap_to_side','m5_ema21_delta_to_side','m5_di_difference_to_side')
    return bool(old>=0 and P._has(source,i,'m15_di_difference_to_side',*signature)
        and P._has(source,seed,'m15_di_difference_to_side',*signature)
        and source['m15_di_difference_to_side'][i]<=source['m15_di_difference_to_side'][seed]
        and any(source[k][i]!=source[k][seed] for k in signature)
        and source['m5_gap_to_side'][i]<=source['m5_gap_to_side'][old])


def _follow_ok(state: dict, arrays: list, side: int, i: int, prices: dict, rule: dict) -> bool:
    """
    機能: 191の順行再テストへ過大乖離を避ける位置確認を加える。
    引数: state/arrays/side/i/pricesは191同体、rule(dict)は役割と厳格度。
    返り値: boolは現在の位置も許容する場合。
    """
    if not B._follow_ok(state,arrays,side,i,prices):return False
    if rule['filter']=='REV':return True
    x=arrays[side];names=('q0_entry_minus_ema8_atr5_to_side','q0_entry_minus_bbmean_sigma_to_side')
    if not P._has(x,i,*names):return False
    ema,bb,distance=(.75,1.,.75) if rule['strict'] else (1.,1.5,1.)
    sign=1 if side==0 else -1
    return bool(x[names[0]][i]<=ema and x[names[1]][i]<=bb
        and sign*(prices['last'][i]-state['follow']['level'])/state['atr']<=distance)


def build(features: object, base_bundle: dict, candidate_ids: list | None=None) -> dict:
    """
    機能: 旧要求の二方向受容へ構造非拡大と位置制限を加えた16候補を作る。
    引数: features(FeatureDataset互換、q0_prices必須)、base_bundle(dict)、candidate_ids(list[str]|None)。
    返り値: dictはcandidate_ids/bundles/diagnostics。金融/保有を入力しない。
    """
    mapping={r['id']:r for r in catalog()['rules']};ids=list(mapping) if candidate_ids is None else candidate_ids
    assert len(ids)==len(set(ids)) and set(ids)<=set(mapping)
    arrays,meta,times,phases,reset,prices=P._prepare(features);n=len(times)
    columns=[c['name'] if isinstance(c,dict) else c for c in P.P._get(features,'columns')]
    for side,name in enumerate(('buy_X','sell_X')):
        for column in EXTRA:arrays[side][column]=np.asarray(P.P._get(features,name))[:,columns.index(column)]
    previous=_previous_five(arrays,reset)
    base,_,_=P.P.OLD.V1._base(base_bundle,n,phases)
    controls=B.build(features,base_bundle,[mapping[k]['control'] for k in ids if 'control' in mapping[k]])
    bundles={};diagnostics={}
    for identity in ids:
        rule=mapping[identity]
        if 'control' in rule:
            bundles[identity]=controls['bundles'][rule['control']];diagnostics[identity]=controls['diagnostics'][rule['control']];continue
        out={'birth':{k:v.copy() for k,v in base['birth'].items()},**{k:base[k].copy() for k in ('mw','fw','hi','added')}}
        diag={'guarded':np.zeros(n,bool),'risk_unknown':np.zeros(n,bool),'reverse_confirmed':np.zeros(n,bool),
            'follow_confirmed':np.zeros(n,bool),'pending_from':np.full(n,-1,np.int64),'retest_event':np.full(n,-1,np.int64),
            'accept_event':np.full(n,-1,np.int64),'accept_seconds':np.zeros(n),'accept_count':np.zeros(n,np.int16),
            'max_penetration_atr':np.full(n,np.nan),'level':np.full(n,np.nan),'reverse_bb_level':np.zeros(n,bool),
            'delay_seconds':np.zeros(n),'competing':np.zeros(n,bool)}
        pending=None;profile=P.PROFILES[rule['profile']]
        for i in range(n):
            if reset[i]:pending=None
            if pending is not None and times[i]-times[pending['event']]>1800:pending=None
            if base['added'][i]:
                if pending is not None:
                    pending['reverse']['accept']=None;pending['follow']['accept']=None
                continue
            original=int(base['birth']['core'][i])
            if original:
                side=0 if original==1 else 1;risk=_risk(arrays[1-side],i,rule['risk'],bool(prices['normal'][i]))
                diag['risk_unknown'][i]=risk==-1
                if risk!=1:pending=None;continue
                proposed=_state(i,original,arrays,prices,base)
                if proposed is None:diag['risk_unknown'][i]=True;pending=None;continue
                diag['guarded'][i]=True
                for key,value in (('core',0),('branches',-1),('technical',0),('tier',0)):out['birth'][key][i]=value
                if pending is None or pending['direction']!=original:pending=proposed
            if pending is None or i<=pending['event'] or times[i]<=times[pending['event']] or out['birth']['core'][i]!=0:continue
            side=0 if pending['direction']==1 else 1;sign=pending['direction'];source_side=1-side;source_sign=-sign
            accept=P._accept(pending['reverse'],arrays[side],i,sign,times,prices,profile)
            reverse=(P._mature(pending['reverse'],accept,i,sign,times,prices,profile) and _reverse_ok(pending,arrays,side,i,prices,rule,previous))
            follow=False;other=None
            if rule['mode']=='SWITCH':
                distance=source_sign*(float(prices['last'][i])-pending['follow']['level'])/pending['atr']
                if pending['retest_event']<0 and prices['normal'][i] and -.2<=distance<=.2:pending['retest_event']=i
                if pending['retest_event']>=0 and i>pending['retest_event'] and times[i]>times[pending['retest_event']]:
                    other=P._accept(pending['follow'],arrays[source_side],i,source_sign,times,prices,profile)
                    follow=(P._mature(pending['follow'],other,i,source_sign,times,prices,profile) and _follow_ok(pending,arrays,source_side,i,prices,rule))
            if reverse and follow:diag['competing'][i]=True;continue
            if not reverse and not follow:continue
            selected=pending['reverse'] if reverse else pending['follow'];observed=accept if reverse else other
            out['birth']['core'][i]=sign if reverse else source_sign
            for key in ('branches','technical','tier'):out['birth'][key][i]=0
            for key in ('mw','fw','hi'):out[key][i]=pending[key]
            out['added'][i]=False
            diag['reverse_confirmed'][i]=reverse;diag['follow_confirmed'][i]=follow
            diag['pending_from'][i]=pending['event'];diag['retest_event'][i]=pending['retest_event'];diag['accept_event'][i]=observed['event']
            diag['accept_seconds'][i]=times[i]-observed['time'];diag['accept_count'][i]=observed['count']
            diag['max_penetration_atr'][i]=max(0,-observed['min_distance']);diag['level'][i]=selected['level']
            diag['reverse_bb_level'][i]=pending['reverse_level_kind']=='固定BB1σ端'
            diag['delay_seconds'][i]=times[i]-times[pending['event']];pending=None
        lc=base['added'].astype(bool)
        assert all(np.array_equal(out['birth'][k][lc],base['birth'][k][lc]) for k in base['birth'])
        bundles[identity]=out;diagnostics[identity]=diag
    return {'version':VERSION,'candidate_ids':ids,'bundles':bundles,'diagnostics':diagnostics}


def write_catalog(path: Path) -> None:
    """
    機能: 新193の全条件と直接Sourceを金融前に新規保存する。
    引数: path(Path)は未作成JSON。
    返り値: None。旧Source・固定条件を変更しない。
    """
    assert not path.exists()
    sources=[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
        for p in (Path(__file__),Path(B.__file__),Path(P.__file__))]
    path.write_text(json.dumps({**catalog(),'Source':sources,'新193金融未入力':True},ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
