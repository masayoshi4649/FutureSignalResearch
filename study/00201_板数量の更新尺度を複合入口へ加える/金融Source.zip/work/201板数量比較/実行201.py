"""固定複合入口の板追加を、純出生封印後に同じIFD口座で比較する。"""
from pathlib import Path
from collections import defaultdict
import argparse
import copy
import gzip
import hashlib
import json
import math
import sys
import numpy as np
import 板条件201 as B

ROOT=B.ROOT;HERE=Path(__file__).parent;TRIAL=ROOT/'study/00201_板数量の更新尺度を複合入口へ加える'
INPUT=ROOT/'inputs/00201_両指数の板数量純特徴'
NK_IDS=('E199_00','E199_02','E199_05');TP_IDS=(0,10)
for directory in ('work/181共用接続','work/181反省を分解した改善','work/183損失安定性','work/183単純IFD検証','work/194追加二場','work/199保留中の旧幹確認_未知保持','work/200TOPIX'):
    sys.path.insert(0,str(ROOT/directory))
import 共用181 as C
import 集計181 as A
import 安定性183 as S
import NK純接続194 as N
import NK金融接続194 as NF
import rules199 as R
import 当時価格183 as Q
import 入口200 as T
import 金融を比較する as F


def read(path: Path) -> object:
    """
    機能: UTF-8のJSON又はgzip JSONを読む。
    引数: path(Path)。
    返り値: objectは解析値。
    """
    raw=path.read_bytes();return json.loads(gzip.decompress(raw) if path.suffix=='.gz' else raw)


# ----------------------------------------
def safe(value: object) -> object:
    """
    機能: NumPy型と非有限値をJSONへ変換する。
    引数: value(object)。
    返り値: objectはJSON互換値。非有限の未知をNoneで保持する。
    """
    if isinstance(value,dict):return {str(k):safe(v) for k,v in value.items()}
    if isinstance(value,(list,tuple,np.ndarray)):return [safe(v) for v in value]
    if isinstance(value,np.bool_):return bool(value)
    if isinstance(value,np.integer):return int(value)
    if isinstance(value,(float,np.floating)):return float(value) if math.isfinite(value) else None
    return value


# ----------------------------------------
def save(path: Path, value: object) -> None:
    """
    機能: 決定的JSONを新規保存し、既存なら同体を確認する。
    引数: path(Path)、value(object)。
    返り値: None。
    """
    raw=(json.dumps(safe(value),ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode()
    body=gzip.compress(raw,mtime=0) if path.suffix=='.gz' else raw
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():assert path.read_bytes()==body,path
    else:path.write_bytes(body)


# ----------------------------------------
def ref(path: Path) -> dict:
    """
    機能: 資源の容量と内容指紋を取得する。
    引数: path(Path)。
    返り値: dictはリポジトリ相対path・bytes・sha256。
    """
    with path.open('rb') as stream:sha=hashlib.file_digest(stream,'sha256').hexdigest()
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':sha}


# ----------------------------------------
def board_values(row: dict) -> dict:
    """
    機能: 既知旗付き純板特徴を金融条件へ渡す値だけに変換する。
    引数: row(dict)は原行結合済みの純板特徴。
    返り値: dict[str,float|None]。未知を0へ補完しない。
    """
    result={}
    for dest,source in zip(B.FIELDS,('QI3','OFI16','OFI64','BLOCK4_OFI'),strict=True):
        field=row['features'][source]
        if field['known']:
            assert field['value'] is not None and math.isfinite(field['value'])
            assert field['start_line']<=field['end_line']<=field['available_line']<=row['line']
            result[dest]=field['value']
        else:result[dest]=None
    return result


# ----------------------------------------
def board_map(paths: list[Path], symbol: str) -> dict:
    """
    機能: 一商品全83場の純板値を物理原行で索引化する。
    引数: paths(list[Path])はq0板特徴、symbol(str)。
    返り値: dict[tuple[str,int],dict]。時計ソートで未来同秒行へ差し替えない。
    """
    rows={}
    for path in paths:
        payload=read(path)
        assert payload['schema']=='純板201_v1' and payload['symbol']==symbol and payload['financial_labels_used'] is False
        for row in payload['rows']:
            assert row['symbol']==symbol
            key=(row['session'],int(row['line']));assert key not in rows
            rows[key]=row
    return rows


# ----------------------------------------
def parent_topix() -> list:
    """
    機能: 200の全83場の固定純出生を旧81・追加2の順で返す。
    引数: なし。
    返り値: list[dict]は全q0。母体0が旧190、10が反転側時間順確認。
    """
    source=ROOT/'inputs/00200_TOPIXの観測被覆と時間順入口'
    manifest=read(source/'入力台帳.json')
    assert all(ref(ROOT/manifest[k]['path'])==manifest[k] for k in ('旧81純出生','追加2純出生','条件'))
    return read(source/'純入口.json.gz')+read(source/'追加二場純入口.json.gz')


# ----------------------------------------
def check_scenes(scenes: list) -> None:
    """
    機能: 全83場の順序と旧期間区切りを検査する。
    引数: scenes(list[dict])はscene又はsessionを持つ場順。
    返り値: None。未知・無取引場を落として期間を詰めない。
    """
    names=[s.get('scene',s.get('session')) for s in scenes]
    assert len(names)==len(set(names))==83
    assert all(scenes[i]['start']<scenes[i+1]['start'] for i in range(82))
    assert names[80:]==['2026-11-16_Day','2026-11-16_Night','2026-11-17_Day']
    reference=read(ROOT/'inputs/TOPIX原順8列_20260921_20261116/台帳.json')['entries']
    assert names[:81]==[r['session'] for r in reference]


# ----------------------------------------
def baseline_paths() -> dict:
    """
    機能: BASEの同体確認に使う既存固定金融の参照先を列挙する。
    引数: なし。
    返り値: dict[str,list[Path]]は候補ごとの旧81・追加2又は全83正本。
    """
    result={};trial=ROOT/'study/00199_保留中の旧幹を確認済みの根拠で切り替える'
    for name in NK_IDS:
        result['NK225201_'+name+'_BASE']=[trial/'保存金融'/(name+'__C0_IFD.json.gz'),
            trial/'追加二場/保存金融'/('NK225199_'+name+'__C0_IFD.json.gz')]
    for index in TP_IDS:
        paths=list((ROOT/'work/200TOPIX/全83金融正本').glob(f'TOPIX200_N{index:02d}_*.json.gz'))
        assert len(paths)==1;result[f'TOPIX201_I{index:02d}_BASE']=paths
    return result


# ----------------------------------------
def verify_baseline(pack: dict) -> dict | None:
    """
    機能: 板追加なし五母体の全台帳と保有区間が親の固定結果と同体か確認する。
    引数: pack(dict)は新201の金融結果。
    返り値: dict|NoneはBASEの照合票。金融評価を再定義しない。
    """
    if not pack['id'].endswith('_BASE'):return None
    parts=[read(p) for p in baseline_paths()[pack['id']]]
    for field in ('ledger','sessions','positions'):
        if field=='ledger':expected={k:sum((p[field][k] for p in parts),[]) for k in parts[0][field]}
        else:expected=sum((p[field] for p in parts),[])
        assert pack[field]==expected,(pack['id'],field)
    if pack['id'].startswith('TOPIX'):assert pack['diagnostics']==parts[0]['diagnostics']
    return {'id':pack['id'],'全台帳と保有と場順同体':True,'取得':len(pack['ledger']['known'])}


# ----------------------------------------
def pure(nk_paths: list[Path], tp_paths: list[Path]) -> None:
    """
    機能: 全25口座の当時純判断を生成し、全商品を金融前に封印する。
    引数: nk_paths/tp_paths(list[Path])は全83場の板q0資源。
    返り値: None。金融・先着ラベルを読まない。
    """
    boards={'NK225':board_map(nk_paths,'NK225'),'TOPIX':board_map(tp_paths,'TOPIX')}
    diagnostics={};pure_refs=[];scene_order=[]
    for leg in (*C.LEGS,'追加2'):
        p=N.load_pure_leg() if leg=='追加2' else C.load_pure_leg(leg)
        if leg!='追加2':C.seal_pure_leg(p)
        scene_order.extend(p['features'].scenes)
        p['features'].q0_prices=N.load_q0(p) if leg=='追加2' else Q.load_q0(p)
        built=R.build(p['features'],p['baselines']['全期_J035'],candidate_ids=list(NK_IDS))
        rows=[]
        for meta in p['features'].q0_meta:
            row=boards['NK225'][(meta['session'],meta['q0_line'])]
            assert row['time']==meta['q0_time'];rows.append(board_values(row))
        for previous,current in zip(p['features'].q0_meta,p['features'].q0_meta[1:]):
            if previous['session']==current['session']:
                assert previous['q0_line']<current['q0_line'] and previous['q0_time']<=current['q0_time']
        payload={};diag={}
        for identity,bundle in built['bundles'].items():
            for mode in B.MODES:
                key=identity+'_'+mode;value,info=B.filter_bundle(bundle,rows,mode)
                for k in C.PARAM_KEYS:payload[key+'__'+k]=value[k]
                for k in C.BIRTH_KEYS:payload[key+'__birth__'+k]=value['birth'][k]
                diag[key]={k:int(v.sum()) for k,v in info.items()}
                if mode=='BASE':
                    for k in C.PARAM_KEYS:np.testing.assert_array_equal(value[k],bundle[k])
                    for k in C.BIRTH_KEYS:np.testing.assert_array_equal(value['birth'][k],bundle['birth'][k])
        target=HERE/'純入口'/(leg+'.npz');target.parent.mkdir(parents=True,exist_ok=True)
        if target.exists():
            with np.load(target,allow_pickle=False) as old:
                assert set(old.files)==set(payload)
                for k in payload:np.testing.assert_array_equal(old[k],payload[k])
        else:np.savez_compressed(target,**payload)
        pure_refs.append(ref(target));diagnostics[leg]=diag
        print(json.dumps({'純出生':leg,'候補':15,'q0':len(rows)},ensure_ascii=False),flush=True)
    check_scenes(scene_order)
    rows=[];diag=defaultdict(lambda:defaultdict(int))
    for parent in parent_topix():
        board=boards['TOPIX'][(parent['session'],parent['line'])]
        assert board['time']==parent['time'];values=board_values(board)
        new={k:parent[k] for k in ('session','line','time','band')};signals=[];widths=[];origins=[]
        for identity in TP_IDS:
            for mode in B.MODES:
                sign=parent['signals'][identity];key=f'I{identity:02d}_{mode}'
                if sign:
                    allow,unknown=B.decide(values,sign,mode)
                    diag[key]['proposed']+=1;diag[key]['unknown']+=int(unknown);diag[key]['rejected']+=int(not allow)
                else:allow=True
                signals.append(sign if allow else 0);widths.append(parent['widths'][identity]);origins.append(parent['origins'][identity])
        new.update(signals=signals,widths=widths,origins=origins);rows.append(new)
    for previous,current in zip(rows,rows[1:]):
        if previous['session']==current['session']:
            assert previous['line']<current['line'] and previous['time']<=current['time']
    target=HERE/'純入口/TOPIX.json.gz';save(target,rows);pure_refs.append(ref(target));diagnostics['TOPIX']=dict(diag)
    save(HERE/'純成立診断.json',diagnostics)
    NF.modules()
    paths={Path(__file__),Path(B.__file__),Path(C.__file__),Path(A.__file__),Path(S.__file__),Path(N.__file__),Path(NF.__file__),
        Path(R.__file__),Path(Q.__file__),Path(T.__file__),Path(F.__file__),TRIAL/'金融前カタログ.json',
        ROOT/'study/00199_保留中の旧幹を確認済みの根拠で切り替える/条件_NK225_v2.json',
        ROOT/'study/00200_TOPIXの観測被覆と構造確認の順序を分ける/条件.json'}
    paths.update(ROOT/r['path'] for r in NF.source_refs())
    paths.update(nk_paths+tp_paths)
    paths.update(ROOT/'inputs/00200_TOPIXの観測被覆と時間順入口'/name for name in ('純入口.json.gz','追加二場純入口.json.gz','入力台帳.json'))
    paths.update(path for items in baseline_paths().values() for path in items)
    paths.update(INPUT/name for name in ('抽出前固定.json.gz','完了.json'))
    cache_manifest=ROOT/'inputs/TOPIX原順8列_20260921_20261116/台帳.json'
    paths.add(cache_manifest)
    for item in read(cache_manifest)['entries']:
        path=ROOT/item['path'];assert ref(path)['sha256']==item['sha256'];paths.add(path)
    added_manifest=ROOT/'inputs/00194_20261116夜と1117昼の固定適用入力/原順8列/入力台帳.json'
    paths.add(added_manifest)
    for item in read(added_manifest)['entries']:
        path=Path(item['cache_absolute']);assert ref(path)['sha256']==item['sha256_cache'];paths.add(path)
    for module in list(sys.modules.values()):
        filename=getattr(module,'__file__',None)
        if filename:
            path=Path(filename).resolve()
            if path.suffix=='.py' and path.is_relative_to(ROOT) and 'site-packages' not in path.parts:paths.add(path)
    condition={'試行':201,'カタログ':B.catalog(),'Sourceと参照':[ref(p) for p in sorted(paths)],
        '純出生':pure_refs,'人工':B.artificial(),'全83既使用':True,'全25金融前':True,
        '板入力':{'NK225':[ref(p) for p in nk_paths],'TOPIX':[ref(p) for p in tp_paths]}}
    save(TRIAL/'条件.json',condition)
    save(HERE/'純封印.json',{'成功':True,'全25金融前':True,'条件':ref(TRIAL/'条件.json')})


# ----------------------------------------
def topix_finance() -> list:
    """
    機能: TOPIX十口座を固定Routeの予約・保有一枠で全83場再生する。
    引数: なし。
    返り値: list[dict]は元幅期限・元費用の金融pack。
    """
    entries=copy.deepcopy(read(T.M.HERE/'入力台帳.json')['entries'])
    manifest={r['session']:r for r in read(ROOT/'inputs/TOPIX原順8列_20260921_20261116/台帳.json')['entries']}
    for entry in entries:entry['cache_absolute']=str(ROOT/manifest[entry['session']]['path'])
    added=read(ROOT/'inputs/00194_20261116夜と1117昼の固定適用入力/原順8列/入力台帳.json')['entries']
    entries += [e for e in added if e['symbol']=='TOPIX'];assert len(entries)==83
    meta=F.sessions(entries);by=defaultdict(list)
    for row in read(HERE/'純入口/TOPIX.json.gz'):by[row['session']].append(row)
    packs=[]
    for identity in TP_IDS:
        for mode in B.MODES:
            pack=F.empty(f'TOPIX201_I{identity:02d}_{mode}',meta);pack['ledger']['origin']=[];packs.append(pack)
    for entry in entries:
        route=T.M.Route(entry);cache={}
        for ci,pack in enumerate(packs):
            busy=-math.inf;pending=False;counts={'純成立':0,'保有棄却':0,'予約棄却':0,'取得':0,'失効':0}
            for row in by[entry['session']]:
                sign=row['signals'][ci]
                if not sign:continue
                counts['純成立']+=1
                if row['time']<=busy:counts['予約棄却' if pending else '保有棄却']+=1;continue
                width=row['widths'][ci];assert width is not None
                key=(row['time'],row['line'],sign,width)
                if key not in cache:cache[key]=route.cell(*key)
                cell=cache[key]
                if cell is None:counts['失効']+=1;busy=min(row['time']+30,route.force);pending=True;continue
                counts['取得']+=1;F.append(pack,dict(cell,origin=row['origins'][ci]));pending=False
                busy=route.end if cell['unknown'] else cell['exit_time']
            pack['diagnostics'].append({'scene':entry['session'],**counts})
    return packs


# ----------------------------------------
def finance() -> None:
    """
    機能: 全25純判断とSourceの固定を確認して、口座の後続枠を含め再生する。
    引数: なし。
    返り値: None。金融後に候補を作り直さない。
    """
    condition=read(TRIAL/'条件.json');seal=read(HERE/'純封印.json')
    assert seal['条件']==ref(TRIAL/'条件.json')
    assert all(ref(ROOT/r['path'])==r for r in condition['Sourceと参照']+condition['純出生'])
    marker=HERE/'金融開始前固定.json';assert not marker.exists();save(marker,{'条件':ref(TRIAL/'条件.json'),'純封印':ref(HERE/'純封印.json')})
    by=defaultdict(list)
    for leg in (*C.LEGS,'追加2'):
        p=N.load_pure_leg() if leg=='追加2' else C.load_pure_leg(leg)
        if leg!='追加2':C.seal_pure_leg(p)
        context=NF.attach_financial(NF.load_unvalued_context(p)['context'])['context'] if leg=='追加2' else C.attach_financial(p)['context']
        with np.load(HERE/'純入口'/(leg+'.npz'),allow_pickle=False) as data:
            for identity in NK_IDS:
                for mode in B.MODES:
                    key=identity+'_'+mode;policy={'id':'NK225201_'+key,'entry':identity,'exit':'C0_IFD','board':mode}
                    bundle={k:data[key+'__'+k].copy() for k in C.PARAM_KEYS}
                    bundle['birth']={k:data[key+'__birth__'+k].copy() for k in C.BIRTH_KEYS}
                    pack=A.pack(context,bundle,policy,leg);by[policy['id']].append(pack)
        print(json.dumps({'金融':leg,'候補':15},ensure_ascii=False),flush=True)
    packs=[A.combine(parts) for parts in by.values()]+topix_finance();stats=[];short=[];baseline_checks=[]
    for pack in packs:
        check_scenes(pack['sessions'])
        check=verify_baseline(pack)
        if check:baseline_checks.append(check)
        scenes=[r['scene'] for r in pack['sessions']]
        periods={'旧81':scenes[:81],'追加2':scenes[81:],'全80':scenes[:80],'前48':scenes[:48],
            '後25':scenes[48:73],'追加7':scenes[73:80],'本日1':scenes[80:81]}
        stat=S.evaluate_pack(pack,periods);stats.append(stat)
        save(HERE/'金融正本'/(pack['id']+'.json.gz'),pack)
        short.append({'id':pack['id'],'全83':{b:F.terse(g) for b,g in stat['groups'].items()},
            '期間':{period:{b:F.terse(g) for b,g in bands.items()} for period,bands in stat['periods'].items()}})
    save(HERE/'全25口座安定性.json.gz',{'metrics':stats});save(HERE/'全25口座短表.json.gz',short)
    assert len(baseline_checks)==5;save(HERE/'旧五母体同体.json',{'成功':True,'候補':baseline_checks})
    assert all(ref(ROOT/r['path'])==r for r in condition['Sourceと参照']+condition['純出生'])
    print(json.dumps({'完了':25,'全83既使用':True},ensure_ascii=False),flush=True)


# ----------------------------------------
if __name__=='__main__':
    parser=argparse.ArgumentParser();group=parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--pure',action='store_true');group.add_argument('--finance',action='store_true')
    parser.add_argument('--nk',nargs='+',type=Path);parser.add_argument('--topix',nargs='+',type=Path);args=parser.parse_args()
    if args.pure:
        assert args.nk and args.topix;pure(args.nk,args.topix)
    else:finance()
