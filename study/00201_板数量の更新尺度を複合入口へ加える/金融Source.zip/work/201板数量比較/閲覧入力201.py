"""全25口座を同じ全83場の候補別CSVへ転記する。"""
from pathlib import Path
import importlib.util
import json
import math
import 実行201 as E

ROOT=E.ROOT;HERE=Path(__file__).parent
spec=importlib.util.spec_from_file_location('held199_for201',ROOT/'work/199候補別CSV/入力を作る.py')
H=importlib.util.module_from_spec(spec);spec.loader.exec_module(H)


def main() -> None:
    """
    機能: 正本の全25口座から未知を保った候補別の5表を生成する。
    引数: なし。
    返り値: None。候補の削除・成績による並べ替えを行わない。
    """
    headers=['候補','開始日又は期間','帯','利益既知寄与_円','損失絶対額既知寄与_円','収支確定_円',
             '累計収支確定_円','建玉回数','未知件数','保有時間率下限','収支既知寄与_円','累計既知寄与_円']
    names={'候補比較':'集計','デイ':'デイ','ナイト全体':'ナイト全体','ナイト_米前':'ナイト_米前','ナイト_米後':'ナイト_米後'}
    tables={name:{'headers':headers,'rows':[]} for name in names};mapping=[]
    for stat in E.read(HERE/'全25口座安定性.json.gz')['metrics']:
        identity=stat['id'];kind=identity.split('201_')[0];suffix=identity.split('201_')[1]
        mother,mode=suffix.rsplit('_',1) if not suffix.endswith('BLOCK_VETO') else (suffix[:-11],'BLOCK_VETO')
        code=('N'+mother[-2:] if kind=='NK225' else 'T'+mother[-2:])+'_'+{'BASE':'B','KNOWN':'K','VETO':'V','SUPPORT':'S','BLOCK_VETO':'BV'}[mode]
        candidate='201:'+code;pack=E.read(HERE/'金融正本'/(identity+'.json.gz'))
        mapping.append({'候補':candidate,'id':identity,'商品':kind,'母体':mother,'板条件':mode})
        scenes={s['scene']:s for s in pack['sessions']};E.check_scenes(pack['sessions'])
        for band in ('ALL','DAY','NIGHT','PRE','POST'):
            group=stat['groups'][band];t=group['trades'];h=group['holding'];s=group['sessions']
            full=t['known_net'] if t['unknown_count']==0 else None
            tables['候補比較']['rows'].append([candidate,'全83場',band,t['known_profit'],t['known_loss'],full,full,
                t['all_count'],t['unknown_count'],h['held_lower_ratio'],t['known_net'],t['known_net']])
            dest={'DAY':'デイ','NIGHT':'ナイト全体','PRE':'ナイト_米前','POST':'ナイト_米後'}.get(band)
            if dest is None:continue
            cumulative=0.;complete=True;held=profit=loss=0.
            for row in s['rows']:
                meta=scenes[row['scene']];ratio=H.held(meta,pack['positions'],band)
                duration=meta['end']-meta['start'] if band=='NIGHT' else sum(p['end']-p['start'] for p in meta['phases'] if p['name']==band)
                held+=ratio*duration;profit+=row['known_profit'];loss+=row['known_loss']
                cumulative+=row['known_net'];complete=complete and row['complete']
                tables[dest]['rows'].append([candidate,row['scene'][:10],band,row['known_profit'],row['known_loss'],
                    row['all_net'],cumulative if complete else None,row['all_count'],row['unknown_count'],ratio,row['known_net'],cumulative])
            assert len(s['rows'])==(42 if band=='DAY' else 41)
            assert math.isclose(held,h['held_lower_seconds'],abs_tol=1e-7)
            assert math.isclose(profit,t['known_profit'],abs_tol=1e-7) and math.isclose(loss,t['known_loss'],abs_tol=1e-7)
    assert len(mapping)==25==len({r['候補'] for r in mapping})
    E.save(HERE/'閲覧入力.json',{'tableNames':names,'tables':tables,'候補対応':mapping,'全83既使用':True})
    print(json.dumps({'候補':25,'CSV予定':125,'全場と未知を保持':True},ensure_ascii=False))


# ----------------------------------------
if __name__=='__main__':main()
