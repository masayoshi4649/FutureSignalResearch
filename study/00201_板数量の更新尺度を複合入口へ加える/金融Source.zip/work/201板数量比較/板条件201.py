"""既存の複合入口へ板数量の支持を追加する金融未参照の小対照。"""
from pathlib import Path
import hashlib
import json
import math
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
VERSION='201板数量の更新尺度1'
MODES=('BASE','KNOWN','VETO','SUPPORT','BLOCK_VETO')
FIELDS=('qi3','ofi16','ofi64','block4_ofi')


def catalog() -> dict:
    """
    機能: 商品別母体と五つの板追加条件を金融前に定義する。
    引数: なし。
    返り値: dictは全25口座のカタログ。方向は元入口から取得する。
    """
    return {'版':VERSION,'全83既使用':True,'候補数':25,
        '母体':{'NK225':['E199_00','E199_02','E199_05'],'TOPIX':['旧190_D4_N01','200_N10']},
        'モード':{
            'BASE':'親の固定複合入口と同体。板条件を追加しない。',
            'KNOWN':'QI3・16回OFI・64回OFIが全て既知の場合のみ。量の方向と可用性を分ける対照。',
            'VETO':'三列が既知で、実側QI3<=−0.2、実側OFI16<0、実側OFI64<0なら現在要求を棄却。必要値未知は親要求を保持し未知フラグ。',
            'SUPPORT':'三列が既知かつ、実側QI3>=0、実側OFI16>=0、実側OFI64>=0の場合だけ要求を許可。',
            'BLOCK_VETO':'VETOの三条件と、完了4現値時計ブロックOFIの実側<0が全て既知成立した場合だけ棄却。必要値未知は親要求を保持し未知フラグ。'},
        '売買':'市場買い正の純板特徴へ元の実側±1を掛ける同一式。新たな売買反転を行わない。',
        '心理仮説':'価格由来の方向・構造・勢いから生まれた入口が、直近の表示数量変化に継続して逆らう場合を識別する。板の厚さや更新差分だけを需要や吸収の確定証拠とはしない。',
        '尺度':'16/64はL1が変化した原行の回数。完了ブロックは現値時計が進んだ時だけ公表。実時間の板更新時計と呼ばない。',
        '要求':'原q0で評価、待機からの再開は作らない。新しい純入口は生成せず、次の既存要求を当時条件で判断。',
        'NK優先':'coreがあるq0でそのcoreが棄却された場合は同q0のtechnicalも消し、別名の補完へ迂回させない。coreが無いq0はtechnicalを自身の実側で評価。LCを含む全新規要求が対象。',
        '単純IFD':'親の幅・期限・費用・約定時計を固定。保有/予約合計1、終了15分前。未知決済では枠を空けない。',
        '比較':'BASEの金融・純要求同体、三列のKNOWN対照、純成立/要求/実取得と保有、共通/旧のみ/新のみの実現損益、前48/後25/追加7/最終1/追加2を保持。',
        '未使用列':'QI1/QI10・ブロック価格変化は純特徴の診断用に保持し、本25口座の売買条件には使わない。',
        '選択':'損失の頻度・深さ・連続性・期間差を優先し、全期最高額で採用しない。参加・両中央値を併記し、不適合内の順位を適合としない。'}


# ----------------------------------------
def decide(board: dict, side: int, mode: str) -> tuple[bool,bool]:
    """
    機能: 当時既知の板特徴だけで、元の実側要求を許可するか判定する。
    引数: board(dict[str,float|None])、side(int)は買い1/売り−1、mode(str)。
    返り値: tuple[bool,bool]は許可・必要特徴未知。未知を0へ補完しない。
    """
    assert mode in MODES and side in (-1,1)
    if mode=='BASE':return True,False
    fields=FIELDS if mode=='BLOCK_VETO' else FIELDS[:3]
    known=all(board.get(k) is not None and math.isfinite(board[k]) for k in fields)
    if not known:return mode in ('VETO','BLOCK_VETO'),True
    if mode=='KNOWN':return True,False
    q,a,b=(side*board[k] for k in FIELDS[:3])
    if mode=='SUPPORT':return q>=0 and a>=0 and b>=0,False
    opposite=q<=-.2 and a<0 and b<0
    if mode=='BLOCK_VETO':opposite=opposite and side*board['block4_ofi']<0
    return not opposite,False


# ----------------------------------------
def filter_bundle(bundle: dict, rows: list[dict], mode: str) -> tuple[dict,dict]:
    """
    機能: NKの当時純出生をコピーし、元の優先順位を保って板条件を加える。
    引数: bundle(dict)は出生・幅期限・LC旗、rows(list[dict])は同じq0順の純板値、mode(str)。
    返り値: tuple[dict,dict]は新純出生とq0単位の診断。元配列を変更しない。
    """
    out={k:v.copy() for k,v in bundle.items() if k!='birth'}
    out['birth']={k:v.copy() for k,v in bundle['birth'].items()}
    n=len(out['birth']['core']);assert len(rows)==n
    unknown=np.zeros(n,bool);rejected=np.zeros(n,bool);proposed=np.zeros(n,bool)
    for i,row in enumerate(rows):
        core=int(out['birth']['core'][i]);technical=int(out['birth']['technical'][i]);sign=core or technical
        if not sign:continue
        assert sign in (-1,1);proposed[i]=True
        allow,unknown[i]=decide(row,sign,mode)
        if not allow:
            rejected[i]=True
            out['birth']['core'][i]=0;out['birth']['branches'][i]=-1
            out['birth']['technical'][i]=0;out['birth']['tier'][i]=0
    return out,{'proposed':proposed,'unknown':unknown,'rejected':rejected}


# ----------------------------------------
def artificial() -> dict:
    """
    機能: 売買鏡像・閾値・未知・原入力不変・同q0迂回禁止を人工値で確認する。
    引数: なし。
    返り値: dictは金融を含まない検査票。
    """
    import itertools
    checks=0
    for values in itertools.product((None,-.2,0.,.2),repeat=4):
        row=dict(zip(FIELDS,values));mirror={k:-v if v is not None else None for k,v in row.items()}
        for mode in MODES:
            assert decide(row,1,mode)==decide(mirror,-1,mode);checks+=1
            known=all(v is not None for v in values[:3])
            if mode=='KNOWN':assert decide(row,1,mode)==(known,not known);checks+=1
    contrary=dict(qi3=-.2,ofi16=-.01,ofi64=-.01,block4_ofi=-.01)
    assert decide(contrary,1,'VETO')==(False,False)
    assert decide(dict(contrary,qi3=-.199),1,'VETO')==(True,False)
    assert decide(dict(contrary,ofi16=0),1,'VETO')==(True,False)
    assert decide(dict(contrary,block4_ofi=0),1,'BLOCK_VETO')==(True,False)
    base={'birth':{'core':np.array([1,0]),'branches':np.array([2,-1]),'technical':np.array([-1,1]),'tier':np.array([1,1])},
          'mw':np.array([125,125]),'fw':np.array([200,200]),'hi':np.array([0,0]),'added':np.array([True,False])}
    copy={k:v.copy() for k,v in base['birth'].items()}
    new,diag=filter_bundle(base,[contrary,contrary],'VETO')
    assert np.all(new['birth']['core']==0) and np.all(new['birth']['technical']==0)
    for k,v in copy.items():np.testing.assert_array_equal(v,base['birth'][k]);checks+=1
    for k in ('mw','fw','hi','added'):np.testing.assert_array_equal(new[k],base[k]);checks+=1
    assert diag['rejected'].all() and not diag['unknown'].any()
    return {'成功':True,'確認項目':checks+7,'金融未参照':True,'売買鏡像':True,'未知保持':True,'同q0迂回禁止':True}


# ----------------------------------------
if __name__=='__main__':
    here=Path(__file__).parent;here.mkdir(parents=True,exist_ok=True)
    trial=ROOT/'study/00201_板数量の更新尺度を複合入口へ加える';trial.mkdir(parents=True,exist_ok=True)
    checks=artificial();source=Path(__file__)
    value={'カタログ':catalog(),'人工':checks,'Source':{'path':source.relative_to(ROOT).as_posix(),
        'sha256':hashlib.sha256(source.read_bytes()).hexdigest()},'金融計算前':True}
    target=trial/'金融前カタログ.json'
    text=json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n'
    if target.exists():assert target.read_text(encoding='utf-8')==text
    else:target.write_text(text,encoding='utf-8')
    print(json.dumps(checks,ensure_ascii=False))
