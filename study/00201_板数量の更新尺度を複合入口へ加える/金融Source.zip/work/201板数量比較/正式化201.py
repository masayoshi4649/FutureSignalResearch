"""201の固定条件・結果・全尺度表・候補別CSVを恒久保存する。"""
from pathlib import Path
import csv
import hashlib
import io
import json
import math
import re
import shutil
import zipfile
import 実行201 as E

ROOT=E.ROOT;HERE=Path(__file__).parent;TRIAL=E.TRIAL
OUT=ROOT/'outputs/00201_板数量追加の比較'


def write(path: Path, text: str) -> None:
    """
    機能: 日本語UTF-8資料を保存する。
    引数: path(Path)、text(str)。
    返り値: None。売買Sourceと固定条件を書き換えない。
    """
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(text,encoding='utf-8')


# ----------------------------------------
def verify_csv(data: dict) -> dict:
    """
    機能: 全125CSVを再読し、元セル・未知空欄・収支累計・全場を検算する。
    引数: data(dict)は型付き閲覧入力。
    返り値: dictは照合票。金融を再実行しない。
    """
    proof=E.read(ROOT/'work/201CSV検査/作成確認.json');cells=unknown=0
    for item in proof['files']:
        path=OUT/item['相対path'];raw=path.read_bytes();assert hashlib.sha256(raw).hexdigest()==item['sha256']
        actual=list(csv.reader(io.StringIO(raw.decode('utf-8-sig'))));table=data['tables'][item['元表']]
        expected=[table['headers']]+[r for r in table['rows'] if r[0]==item['候補']]
        assert len(actual)==len(expected)
        for a,b in zip(actual,expected,strict=True):
            assert len(a)==len(b)
            for left,right in zip(a,b,strict=True):
                cells+=1
                if right is None:assert left=='';unknown+=1
                elif isinstance(right,(float,int)):assert math.isclose(float(left),right,abs_tol=1e-7)
                else:assert left==right
        if item['元表']=='候補比較':continue
        assert len(actual)==(43 if item['元表']=='デイ' else 42)
        cumulative=0.;complete=True
        for row in actual[1:]:
            assert math.isclose(float(row[3])-float(row[4]),float(row[10]),abs_tol=1e-7)
            cumulative+=float(row[10]);complete=complete and int(row[8])==0
            assert math.isclose(cumulative,float(row[11]),abs_tol=1e-7)
            if complete:assert math.isclose(cumulative,float(row[6]),abs_tol=1e-7)
            else:assert row[6]==''
    assert len(proof['files'])==125 and cells==52500 and unknown>0
    return {**proof,'全セル再読':cells,'未知空欄':unknown,'利益引く損失と累計一致':True,'全場保持':True}


# ----------------------------------------
def settings() -> None:
    """
    機能: 版8全567セルを親の複合設定と新しい板設定へ接続する。
    引数: なし。
    返り値: None。
    """
    nk=ROOT/'study/00199_保留中の旧幹を確認済みの根拠で切り替える/設定と結果.md'
    tp=ROOT/'study/00200_TOPIXの観測被覆と構造確認の順序を分ける/設定と結果.md'
    grids=[]
    for path in (nk,tp):
        grid={}
        for line in path.read_text(encoding='utf-8').splitlines():
            p=[x.strip() for x in line.split('|')[1:-1]] if line.startswith('|') else []
            if len(p)==11 and re.fullmatch('[ICPVBEMX][0-9]{2}',p[0]):grid[p[0]]=p
        assert len(grid)==63;grids.append(grid)
    template=ROOT/'docs/議論/手法と時間スケールの汎用表_版8.md'
    body=template.read_text(encoding='utf-8').split('## 設定明細（コピー後に記入）')[0]
    body=body.replace('# 手法と時間スケールの汎用表・版8','# 201 設定と結果・版8')
    body=body.replace('全セルは未設定・未検証。','Nは199、Tは200の親設定。S201は板追加、R201は全25口座の複合評価。')
    body=body.replace('](../technical-analysis/','](../../docs/technical-analysis/')
    lines=[];rows=0
    for line in body.splitlines():
        p=[x.strip() for x in line.split('|')[1:-1]] if line.startswith('|') else []
        if len(p)==11 and p[0] in grids[0]:
            code=p[0];p[1]=grids[0][code][1];rows+=1
            for j in range(2,11):
                parts=[prefix+g[code][j] for prefix,g in zip(('N:','T:'),grids) if g[code][j]!='未使用']
                if j==2 and code=='B02':parts.append('S201a QI3≥0/≤−0.2・実側')
                if j==2 and code=='B03':parts.append('S201b OFI16/64・完了4ブロック・符号')
                p[j]=' / '.join(parts)+'/R201' if parts else '未使用'
            line='| '+' | '.join(p)+' |'
        elif line.startswith('[版7]'):line='[版7](../../docs/議論/手法と時間スケールの汎用表_版7.md)。旧表・旧試行は保持。'
        lines.append(line)
    assert rows==63
    tail='''
## 設定明細と複合評価

Nは[199](../00199_保留中の旧幹を確認済みの根拠で切り替える/設定と結果.md)の00/02/05、Tは[200](../00200_TOPIXの観測被覆と構造確認の順序を分ける/設定と結果.md)のI00/I10を固定再用。全候補が全ての表セルを同時利用するという意味ではなく、候補ごとの有効枝は親条件に従う。

S201aは買い上位3段と売り上位3段の数量不均衡。S201bはL1価格又は数量が変わった直近16/64回の正規化差分平均と、直前4完了現値時計ブロック内の同差分平均。市場の買い方向が正、候補実側±1を後から掛ける。表示量を約定量・心理・真の実時間圧力と同一視しない。QI1/10とブロックmid変化は純特徴として保存するが売買には未使用。

BASE、三列KNOWN、強い反対板を除くVETO、同方向支持必須SUPPORT、完了4ブロックも逆の時だけ除くBLOCK_VETOの全5条件。全閾値・未知時の保持/不成立・同q0補完への迂回禁止は[金融前カタログ](金融前カタログ.json)。原板更新回数と分足を混同せず、板の2セルは原板・逐次へ記す。新たな待機・再開や売買反転は作らない。

R201はNK3母体×5＋TOPIX2母体×5=25口座。全83場既使用。単純IFDの幅・期限・費用は親同体、保有/予約合計1、終了15分前。NK1pt100円・往復費用1,077円、miniTOPIX1pt1,000円・往復費用583.6円。新しい板条件だけを比較する。0取得場・金融未知は保持し、同じ入口時点での損益と後続枠の変化を区別する。

## 結果と版

追加の板確認は全面改善にならなかった。NK旧基準のVETOは損失とDDを減らすが赤字場が増え、新199へ重ねても利益減との交換。TOPIXのVETOは損失/DDを増やし、SUPPORTは参加と両中央値を失う。新しい安定採用条件にはしない。全25の期間差と未知は[正本](全25口座安定性.json.gz)、[説明](README.md)、[候補別CSV](../../outputs/00201_板数量追加の比較/README.md)。複合結果を板単独の予測力へ置き換えない。

全63手法×9尺度=567セル。元表SHA256: '''+E.ref(template)['sha256']+'。\n'
    write(TRIAL/'設定と結果.md','\n'.join(lines)+'\n'+tail)


# ----------------------------------------
def main() -> None:
    """
    機能: 独立監査後の全25結果・CSV・Source・説明を正式保存する。
    引数: なし。
    返り値: None。金融と固定条件を変更しない。
    """
    assert E.read(ROOT/'work/201独立検査/金融独立確認.json.gz')['成功']
    data=E.read(HERE/'閲覧入力.json');proof=verify_csv(data)
    for name in ('純封印.json','金融開始前固定.json','純成立診断.json','旧五母体同体.json','全25口座安定性.json.gz','全25口座短表.json.gz','閲覧入力.json'):
        shutil.copy2(HERE/name,TRIAL/name)
    write(TRIAL/'CSV確認.json',json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
    (TRIAL/'金融正本').mkdir(exist_ok=True)
    for path in (HERE/'金融正本').glob('*.json.gz'):shutil.copy2(path,TRIAL/'金融正本'/path.name)
    sources=[ROOT/r['path'] for r in E.read(TRIAL/'条件.json')['Sourceと参照'] if r['path'].startswith('work/')]
    sources += list(HERE.glob('*.py'))+list((HERE/'純入口').glob('*'))
    sources += [ROOT/'scripts/損益CSV/候補別に出力する.mjs',ROOT/'work/199候補別CSV/入力を作る.py']
    sources=sorted(set(p for p in sources if p.is_file() and 'pythonlibs' not in p.parts))
    with zipfile.ZipFile(TRIAL/'金融Source.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for path in sources:archive.write(path,path.relative_to(ROOT).as_posix())
    write(TRIAL/'金融Source索引.json',json.dumps([E.ref(p) for p in sources],ensure_ascii=False,indent=2)+'\n')
    settings()
    stats={r['id']:r for r in E.read(HERE/'全25口座安定性.json.gz')['metrics']}
    lines=['|候補|母体 / 板条件|デイ利益 / 損失|デイ収支|ナイト利益 / 損失|夜間既知収支|','|---|---|---:|---:|---:|---:|']
    for m in data['候補対応']:
        code=m['候補'].split(':')[1];folder='201_'+code;g=stats[m['id']]['groups'];d,n=g['DAY']['trades'],g['NIGHT']['trades']
        lines.append(f"|[{code}]({folder}/README.md)|{m['母体']} / {m['板条件']}|{d['known_profit']:,.1f} / {d['known_loss']:,.1f}|{d['known_net']:,.1f}|{n['known_profit']:,.1f} / {n['known_loss']:,.1f}|{n['known_net']:,.1f}|")
        text=f'''# {m['候補']}

正本ID `{m['id']}`。商品は{m['商品']}、母体{m['母体']}、板条件{m['板条件']}。[条件の定義](../../../study/00201_板数量の更新尺度を複合入口へ加える/金融前カタログ.json)。

[集計](集計.csv) / [デイ](デイ.csv) / [ナイト全体](ナイト全体.csv) / [ナイト米国前](ナイト_米前.csv) / [ナイト米国後](ナイト_米後.csv)。全83場、デイ42・夜間41。各商品mini1枚、費用後の円。NK往復1,077円、TOPIX往復583.6円。ラージBBOによる約定代用。

未知を含む場の確定収支と以後の確定累計は空欄。既知寄与は別列で、未知を解決した口座収支ではない。保有時間率下限は対象実時間に対する0〜1の比率。終了15分前を除き、予約は保有としない。損益は新規の帯、保有は実区間の重なりへ帰属する。夜間全体と米前/後は同じ取引の別集計なので重複合算しない。

[比較一覧](../README.md) / [仮説・結果・限界](../../../study/00201_板数量の更新尺度を複合入口へ加える/README.md)。全83場は探索に既使用。
'''
        write(OUT/folder/'README.md',text)
    write(OUT/'README.md','''# 板数量追加の全25口座比較

5母体へBASE/Known/Veto/Support/BlockVetoを同じ金融条件で適用した。25候補を固定順で掲載し、候補ごとのCSVへ分離。各商品mini1枚・費用後の円、全83場は既使用。

N00=旧179、N02=195_05、N05=199_05。T00=旧190D4/N01、T10=200の実反転側時間順確認。B=追加なし、K=三列既知、V=強い反対板を除外、S=同側支持必須、BV=完了4ブロックも反対の時だけ除外。

'''+ '\n'.join(lines)+'''

利益・損失は既知寄与。未知のある夜間は確定収支ではない。[全場中央値・参加・DD・未知・前後差の正本](../../study/00201_板数量の更新尺度を複合入口へ加える/全25口座安定性.json.gz)と[説明](../../study/00201_板数量の更新尺度を複合入口へ加える/README.md)を併読する。板を追加すると一律に良くなる結果ではなく、全額順位で採用していない。[125CSV・52,500セルの再読](../../study/00201_板数量の更新尺度を複合入口へ加える/CSV確認.json)。
''')
    report='''# 201 板数量の更新尺度を複合入口へ加える

2026-11-18。**板数量の同方向支持を一律に必須とする案は採用しない。** 強い反対板を避ける案には日経で損失軽減の部分効果があるが、赤字場や利益との交換があり、TOPIXへ共通の改善にはならなかった。日経195/199の有望範囲を対照に残し、TOPIXの価格構造と板応答の役割を検証する。

## 仮説と固定した25口座

複数時間軸の価格方向・構造・勢いから生まれる既存入口へ、表示量の支持を重ねる。NK199の00/02/05とTOPIX200のI00/I10へ、追加なし・必要板既知のみ・強い反対板を除外・同方向支持必須・完了4ブロックも逆の場合に除外、の5条件を適用。[金融前カタログ](金融前カタログ.json)と[条件](条件.json)を新しい板条件の金融開封前に固定した。

QI3は上位3段数量不均衡、OFI16/64はL1変化回数尺度、BLOCK4は直前4完了現値時計ブロック内の差分平均。買い正の純値へ実側を掛ける。未知のVETOは元要求を保持し、SUPPORTは不成立。coreを棄却した同q0で別名Tを発火させない。単独の板注文や新たな方向反転は追加していない。

全83場は既使用。単純IFD・幅・期限・費用は親のまま、買売合計保有/予約1、開始待機なし、15:30/05:45まで。mini1枚・NK往復1,077円/TOPIX583.6円（手数料と仮定滑り）。未知は0円とせず枠を場末まで保持する。ラージBBO代用で、miniの実約定を観測した結果ではない。

## 結果

日経旧基準へVETOを加えると、デイ損失1,236,467→1,190,313円、赤字取引71→69、場末DD111,001→65,231円。全42場取得・保有51.33%・両中央値正を保つが、赤字場11→12。主要な改善は9/29と11/16の取得入替えで、新たな入口単体の利益とはいえない。

199_05へVETOを重ねると損失1,074,543→1,053,466円、収支1,030,988→1,002,219円。利益も減り赤字場が増える。支持必須では日経デイは78〜84取得、夜間78取得・保有15.90%へ減り、夜間の両中央値を満たさない。

TOPIX旧母体のVETOはデイ損失830,610.8→836,110.8円・DD103,204.8→114,621.2円、夜間損失555,020.8→560,520.8円・未知7→8と悪化。SUPPORTはデイ損失を505,266.8円へ減らすが38/42場・両中央値不適合。I10 SUPPORTも夜間損失203,006.4円/DD18,167.2円まで減る一方、29/41場・保有8.52%・両中央値不適合。取引を減らした低損失を目標達成としない。

全25口座の同期間の利益・損失・前48/後25/追加7/最終1/追加2は[安定性正本](全25口座安定性.json.gz)。[全候補CSV](../../outputs/00201_板数量追加の比較/README.md)は125ファイル、各候補の全場を残す。純数量が既知の時点だけ選ぶ効果と数量の符号の効果をKNOWNで区別する。次は押戻しと転換、板尺度と価格背景尺度の違いを調べる。固定条件は結果から変更していない。

## 入力と検査

[恒久純入力](../../inputs/00201_両指数の板数量純特徴/README.md)は原板166商品場・26,743,493行から生成した75,675q0の7特徴、gzip計10,067,814byte。元原板は複製・変更しない。独立した受信/板更新時刻はなく、原行更新回数と現値時計を区別する。

純値の原板prefix再計算は全529,725特徴一致。さらに板判定を呼ばない別式で25純出生6,039,954項目、金融集計108,350属性と別状態の全q0枠再生86,544属性が一致した。5BASEは親の全ledger/保有/場順と同体。新金融監査はIFD共用表/Routeを再用し、原BBOを新しい独立金融engineで全件走査した監査とは区別する。[独立監査](監査/)・[純特徴監査](../../inputs/00201_両指数の板数量純特徴/独立純特徴監査.json)。[CSV再読](CSV確認.json)は125ファイル・52,500セル一致、未知と確定累計を別に保持した。

## 再現と保存

[設定と結果](設定と結果.md)は版8全567セル。[純特徴の再現](純特徴の再現.md)、[金融Source](金融Source.zip)・[索引](金融Source索引.json)、[独立検査の再現](監査/README.md)。金融条件票の全Sourceと入力をそのまま保持。全25金融はgzip JSON、原板と純特徴は共用inputs参照。旧固定試行・選択票は上書きしない。

金融再計算は親199/194/200の再現資料を同じ相対配置へ復元し、本Sourceを展開して実行する。純生成は `実行201.py --pure --nk inputs/00201.../NK225/各場.json.gz --topix inputs/00201.../TOPIX/各場.json.gz`。新規作業コピーで純封印後に `--finance` を実行する。既存の金融開始票がある場所へ上書きしない。Python3.14.3/NumPy2.5.4/orjson3.13.0/tzdata2026.6。原板からの純特徴と独立監査は再現可能、主金融の全work消去からの完全隔離復元はまだ確認していない。
'''
    write(TRIAL/'README.md',report)
    print(json.dumps({'正式保存':25,'CSV':125,'全セル':proof['全セル再読'],'汎用表':567,'金融Source資源':len(sources)},ensure_ascii=False))


# ----------------------------------------
if __name__=='__main__':main()
