"""201の独立一件状態を人工時計で検査し、自然金融を読まない。"""
from pathlib import Path
from types import SimpleNamespace
import json
import numpy as np
import 独立確認201 as A


def fixture(times: list,core: list,technical: list,captures: list,known: list,exits: list) -> tuple:
    """
    機能: 自然入力と無関係な一場の枠確認用contextを作る。
    引数: times/core/technical/captures/known/exits(list)は合成した時計と値。
    返り値: tupleはcontext・bundle・capture。
    """
    n=len(times);k=np.zeros((len(known),2,2,1),bool);e=np.full(k.shape,np.nan)
    for i,value in enumerate(known):k[i,:,:,:]=value;e[i,:,:,:]=exits[i]
    context=SimpleNamespace(scenes=[{'start':0.}],event_keys=[(t,i,i+1) for i,t in enumerate(times)],
        event_scenes=np.zeros(n,int),deadlines=np.array([5000.]),close_submits=np.array([4940.]),
        table=SimpleNamespace(widths=(125,200),horizons=('H60',)),arrays={'known':k,'exit_time':e})
    bundle={'birth':{'core':np.array(core),'branches':np.array([0 if s else -1 for s in core]),
                     'technical':np.array(technical),'tier':np.ones(n,int)},
            'mw':np.full(n,125),'fw':np.full(n,125),'hi':np.zeros(n,int),'added':np.zeros(n,bool)}
    return context,bundle,captures


def fill(case: int,time: float) -> dict:
    """
    機能: 合成の取得予定を作る。
    引数: case(int)、time(float)。
    返り値: dictは非金融の取得キー。
    """
    return {'status':'filled','case':case,'fill_key':(time,0,1)}


def main() -> None:
    """
    機能: 同秒保有、未知保持、45分初参加、予約失効、別名取得、終了取消を検査する。
    引数: なし。
    返り値: None。独立枠の人工票だけを保存する。
    """
    rows,diag=A.nk_slots(*fixture([0,1,3,4,6,2700],[1,-1,1,-1,1,0],[0,0,0,0,0,1],
        [fill(0,1),fill(1,2),fill(1,4),fill(1,5),fill(0,7),fill(0,2701)],[True,False],[3,np.nan]))
    assert [(r['event'],r['case']) for r in rows]==[(0,0),(3,1)]
    assert diag['保有棄却']==3
    rows,diag=A.nk_slots(*fixture([2699,2700,2702,2704],[0,0,0,0],[1,1,1,1],
        [fill(0,2700),fill(0,2701),fill(1,2703),fill(1,2705)],[True,True],[2702,2706]))
    assert [(r['event'],r['origin'],r['width']) for r in rows]==[(1,2,200)]
    rows,diag=A.nk_slots(*fixture([0,2,4],[1,1,1],[0,0,0],
        [{'status':'cancelled','finish_key':(3,0,1)},fill(0,3),fill(0,5)],[True],[6]))
    assert [r['event'] for r in rows]==[2] and diag['予約棄却']==1 and diag['予約取消']==1
    rows,diag=A.nk_slots(*fixture([0,4,8],[1,1,1],[0,0,0],
        [fill(0,1),fill(0,5),fill(1,9)],[True,True],[2,10]))
    assert [r['event'] for r in rows]==[0,2] and diag['別名取得棄却']==1
    rows,diag=A.nk_slots(*fixture([4939,4940],[1,1],[0,0],[fill(0,4940),fill(0,4941)],[True],[4950]))
    assert rows==[] and diag['全q0']==1 and diag['予約取消']==1
    result={'成功':True,'自然金融未参照':True,'人工場面':5,'検査':'同秒秒末/未知場末/初参加45分/初取得後T禁止/予約取消/予約中禁止/別名同case/終了前予約取消',
            '独立枠Source':A.ref(Path(A.__file__)),'人工Source':A.ref(Path(__file__))}
    A.save(Path(__file__).parent/'独立枠の人工確認.json',result);print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':main()
