"""201の板判定・単一枠・集計を、売買実装を変更せず独立に確認する。"""
from pathlib import Path
from collections import defaultdict
import argparse
import copy
import gzip
import hashlib
import importlib.util
import json
import math
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
TARGET=ROOT/'work/201板数量比較';TRIAL=ROOT/'study/00201_板数量の更新尺度を複合入口へ加える'
MODES=('BASE','KNOWN','VETO','SUPPORT','BLOCK_VETO')
NK_IDS=('E199_00','E199_02','E199_05');TP_IDS=(0,10)
sys.path.insert(0,str(TARGET))
import 実行201 as J
sys.path.insert(0,str(ROOT/'work/183損失安定性'))
import TOPIXを独立検算する as V


def read(path: Path) -> object:
    """
    機能: 保存済みのUTF-8 JSONを読む。
    引数: path(Path)。
    返り値: object。gzipも許容する。
    """
    raw=path.read_bytes();return json.loads(gzip.decompress(raw) if path.suffix=='.gz' else raw)


def ref(path: Path) -> dict:
    """
    機能: 独立照合の対象資源を指紋で固定する。
    引数: path(Path)。
    返り値: dictは相対パス・容量・SHA256。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,
            'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


def save(path: Path,value: object) -> None:
    """
    機能: 検査結果を専用workへ保存する。
    引数: path(Path)、value(object)はJSON互換値。
    返り値: None。生産側のSource・条件・金融は書き換えない。
    """
    body=(json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode()
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(gzip.compress(body,mtime=0) if path.suffix=='.gz' else body)


# ----------------------------------------
def board_oracle(row: dict,side: int,mode: str) -> tuple:
    """
    機能: 生産側の板判定関数を呼ばず、素直な条件式で許可と未知を求める。
    引数: row(dict)は当時板特徴、side(int)は買1/売−1、mode(str)。
    返り値: tuple[bool,bool]は許可/未知。金融・将来値を参照しない。
    """
    assert side in (-1,1) and mode in MODES
    if mode=='BASE':return True,False
    fields=['QI3','OFI16','OFI64']+(['BLOCK4_OFI'] if mode=='BLOCK_VETO' else [])
    values=[]
    for key in fields:
        f=row['features'][key]
        if not f['known']:return mode in ('VETO','BLOCK_VETO'),True
        assert f['value'] is not None and math.isfinite(f['value'])
        assert f['start_line']<=f['end_line']<=f['available_line']<=row['line']
        values.append(float(f['value'])*side)
    if mode=='KNOWN':return True,False
    if mode=='SUPPORT':return all(v>=0 for v in values),False
    blocked=(values[0]<=-.2 and values[1]<0 and values[2]<0)
    if mode=='BLOCK_VETO':blocked=blocked and values[3]<0
    return not blocked,False


def board_index(condition: dict,symbol: str) -> dict:
    """
    機能: 生産側の結合器を使わず、当時原行の板を索引にする。
    引数: condition(dict)は201固定条件、symbol(str)。
    返り値: dict[tuple[str,int],dict]。
    """
    result={}
    for source in condition['板入力'][symbol]:
        path=ROOT/source['path'];assert ref(path)==source
        body=read(path);assert body['financial_labels_used'] is False and body['symbol']==symbol
        for row in body['rows']:
            key=(row['session'],int(row['line']));assert key not in result
            result[key]=row
    return result


def nk_parent_path(leg: str) -> Path:
    """
    機能: 再生成せず199の固定純出生を参照する。
    引数: leg(str)。
    返り値: Path。元の金融は参照しない。
    """
    if leg=='追加2':return ROOT/'work/199追加二場の固定診断/追加二場純出生.npz'
    return ROOT/'work/199保留中の旧幹確認_未知保持'/(leg+'_新入口.npz')


def pure_audit() -> None:
    """
    機能: 全25口座の全q0で板条件と固定母体を別式照合する。
    引数: なし。
    返り値: None。新金融を読まず、純判定の確認票を保存する。
    """
    condition=read(TRIAL/'条件.json');seal=read(TARGET/'純封印.json')
    assert seal['条件']==ref(TRIAL/'条件.json')
    assert all(ref(ROOT/r['path'])==r for r in condition['Sourceと参照']+condition['純出生'])
    boards={s:board_index(condition,s) for s in ('NK225','TOPIX')}
    checks=0;proposals=0;diagnostics={};parents=[]
    for leg in (*J.C.LEGS,'追加2'):
        p=J.N.load_pure_leg() if leg=='追加2' else J.C.load_pure_leg(leg)
        parent_path=nk_parent_path(leg);parents.append(ref(parent_path))
        with np.load(parent_path,allow_pickle=False) as parent_raw, np.load(TARGET/'純入口'/(leg+'.npz'),allow_pickle=False) as child_raw:
            parent={k:parent_raw[k].copy() for k in parent_raw.files}
            child={k:child_raw[k].copy() for k in child_raw.files}
            diag={}
            for identity in NK_IDS:
                for mode in MODES:
                    key=identity+'_'+mode;counts={'proposed':0,'unknown':0,'rejected':0}
                    for attr in ('mw','fw','hi','added'):
                        np.testing.assert_array_equal(parent[identity+'__'+attr],child[key+'__'+attr]);checks+=len(child[key+'__'+attr])
                    for i,meta in enumerate(p['features'].q0_meta):
                        row=boards['NK225'][(meta['session'],int(meta['q0_line']))];assert row['time']==meta['q0_time']
                        original={k:int(parent[identity+'__birth__'+k][i]) for k in ('core','branches','technical','tier')}
                        sign=original['core'] if original['core'] else original['technical']
                        expected=dict(original)
                        if sign:
                            allow,unknown=board_oracle(row,sign,mode);proposals+=1;counts['proposed']+=1
                            counts['unknown']+=int(unknown);counts['rejected']+=int(not allow)
                            if not allow:expected={'core':0,'branches':-1,'technical':0,'tier':0}
                        for attr,value in expected.items():
                            assert child[key+'__birth__'+attr][i]==value,(leg,key,i,attr);checks+=1
                    diag[key]=counts
            diagnostics[leg]=diag
        print('純照合',leg,flush=True)
    source=ROOT/'inputs/00200_TOPIXの観測被覆と時間順入口'
    paths=[source/'純入口.json.gz',source/'追加二場純入口.json.gz'];parents.extend(ref(p) for p in paths)
    parent=read(paths[0])+read(paths[1]);child=read(TARGET/'純入口/TOPIX.json.gz')
    assert len(parent)==len(child);diag=defaultdict(lambda:defaultdict(int))
    for old,new in zip(parent,child,strict=True):
        for field in ('session','line','time','band'):assert new[field]==old[field];checks+=1
        row=boards['TOPIX'][(old['session'],old['line'])];assert row['time']==old['time']
        for mother_pos,identity in enumerate(TP_IDS):
            for mode_pos,mode in enumerate(MODES):
                index=mother_pos*len(MODES)+mode_pos;sign=old['signals'][identity];key=f'I{identity:02d}_{mode}'
                allow=True
                if sign:
                    allow,unknown=board_oracle(row,sign,mode);proposals+=1;diag[key]['proposed']+=1
                    diag[key]['unknown']+=int(unknown);diag[key]['rejected']+=int(not allow)
                assert new['signals'][index]==(sign if allow else 0)
                assert new['widths'][index]==old['widths'][identity] and new['origins'][index]==old['origins'][identity];checks+=3
    diagnostics['TOPIX']={k:dict(v) for k,v in diag.items()}
    assert diagnostics==read(TARGET/'純成立診断.json')
    save(HERE/'純判定独立確認.json',{'成功':True,'金融未参照':True,'全25純出生照合項目':checks,'板判断要求':proposals,
         '条件':ref(TRIAL/'条件.json'),'Source':ref(Path(__file__)),'親純出生':parents,'診断':diagnostics,
         '範囲':'板の数量式自体は別担当の純抽出監査を参照。ここは当時結合済みの板値から追加条件を別式で全件確認。'})
    print('全25純出生一致',checks,flush=True)


# ----------------------------------------
def nk_slots(context: object,bundle: dict,captures: list) -> tuple:
    """
    機能: heapエンジンを使わず、一件の予約又は保有状態でNKの全q0枠を再生する。
    引数: context(object)は不変のIFD表、bundle(dict)は照合済み純出生、captures(list)は不変の取得対応。
    返り値: tuple[list[dict],dict]は取得と枠診断。既知IFD表を参照しBBOは再走査しない。
    """
    births=bundle['birth'];records=[];diagnostic=defaultdict(int)
    width_index={int(w):i for i,w in enumerate(context.table.widths)};h60=context.table.horizons.index('H60')
    for si,scene in enumerate(context.scenes):
        pending=None;held_until=None;seen=set();ever=False
        end=float(context.deadlines[si]);stop=float(context.close_submits[si])
        events=[i for i in range(len(context.event_keys)) if context.event_scenes[i]==si and context.event_keys[i][0]<stop]
        def advance(key: tuple) -> None:
            """
            機能: 現在キーまでに発生した予約完了と秒末決済だけを処理する。
            引数: key(tuple[float,float,float])。
            返り値: None。未知は場末まで保有し、同秒の次要求で枠を空けない。
            """
            nonlocal pending,held_until,ever
            if held_until is not None and held_until<=key:held_until=None
            if pending is None or pending['finish']>key:return
            order=pending;pending=None
            if not order['fill']:diagnostic['予約取消']+=1;return
            case=order['case']
            if case in seen:diagnostic['別名取得棄却']+=1;return
            seen.add(case);ever=True
            record={k:order[k] for k in ('event','case','side','width','origin','tier','hi')};records.append(record)
            index=(case,order['side'],width_index[order['width']],order['hi'])
            exit_time=float(context.arrays['exit_time'][index]) if context.arrays['known'][index] else end
            held_until=(exit_time,math.inf,math.inf)
            if held_until<=key:held_until=None
        for event in events:
            key=tuple(context.event_keys[event]);advance(key);diagnostic['全q0']+=1
            core=int(births['core'][event]);branch=int(births['branches'][event]);technical=int(births['technical'][event])
            width=int(bundle['mw'][event] if branch==0 else bundle['fw'][event])
            if width<=0:core=0
            if core:sign=core;origin=0;tier=0;hi=int(bundle['hi'][event])
            elif technical and key[0]>=scene['start']+2700 and not ever:
                sign=technical;origin=2;tier=int(births['tier'][event]);width=200;hi=h60
            else:continue
            diagnostic['純要求']+=1
            if held_until is not None:diagnostic['保有棄却']+=1;continue
            if pending is not None:diagnostic['予約棄却']+=1;continue
            descriptor=captures[event];fill=descriptor['status']=='filled'
            finish=tuple(descriptor['fill_key'] if fill else descriptor['finish_key'])
            if finish[0]>=stop:fill=False;finish=(stop,math.inf,math.inf)
            assert key<=finish
            pending={'event':event,'case':int(descriptor['case']) if fill else -1,'side':0 if sign==1 else 1,
                     'width':width,'origin':origin,'tier':tier,'hi':hi,'fill':fill,'finish':finish}
            diagnostic['枠受理']+=1
        advance((end,math.inf,math.inf));assert pending is None and held_until is None
    return sorted(records,key=lambda r:(r['event'],r['origin'])),dict(diagnostic)


def slot_audit(packs: dict) -> dict:
    """
    機能: 全25口座の後続枠を独立再生し、実取得列の過不足を全件検査する。
    引数: packs(dict[str,dict])は201金融正本。
    返り値: dictは件数と比較範囲。共用IFD表・TOPIX Routeは変更せず再利用する。
    """
    checks=0;diagnostics={}
    for leg in (*J.C.LEGS,'追加2'):
        p=J.N.load_pure_leg() if leg=='追加2' else J.C.load_pure_leg(leg)
        if leg!='追加2':
            cache=J.C.HERE/'cache'/(leg+'_純基準181.npz')
            assert cache.exists() and cache.with_suffix('.json').exists()
            J.C.seal_pure_leg(p)
        context=J.NF.attach_financial(J.NF.load_unvalued_context(p)['context'])['context'] if leg=='追加2' else J.C.attach_financial(p)['context']
        captures=J.A.M.B.captures(context)
        with np.load(TARGET/'純入口'/(leg+'.npz'),allow_pickle=False) as data:
            for identity in NK_IDS:
                for mode in MODES:
                    key=identity+'_'+mode;name='NK225201_'+key
                    bundle={k:data[key+'__'+k] for k in ('mw','fw','hi','added')}
                    bundle['birth']={k:data[key+'__birth__'+k] for k in ('core','branches','technical','tier')}
                    records,diag=nk_slots(context,bundle,captures);diagnostics[name+'_'+leg]=diag
                    ledger=packs[name]['ledger'];ids=[i for i,v in enumerate(ledger['leg']) if v==leg]
                    assert len(records)==len(ids),(name,leg,'取得数',len(records),len(ids))
                    for record,i in zip(records,ids,strict=True):
                        for attr in ('event','case','side','width','origin'):assert ledger[attr][i]==record[attr];checks+=1
                        assert ledger['horizon'][i]==context.table.horizons[record['hi']];checks+=1
        print('枠照合',leg,flush=True)

    # ----------------------------------------
    # TOPIXも元のRouteのセルは共用し、全q0から予約と保有の選択だけ別再生する。
    entries=copy.deepcopy(read(J.T.M.HERE/'入力台帳.json')['entries'])
    mapping={r['session']:r['path'] for r in read(ROOT/'inputs/TOPIX原順8列_20260921_20261116/台帳.json')['entries']}
    for entry in entries:entry['cache_absolute']=str(ROOT/mapping[entry['session']])
    entries.extend(r for r in read(ROOT/'inputs/00194_20261116夜と1117昼の固定適用入力/原順8列/入力台帳.json')['entries'] if r['symbol']=='TOPIX')
    rows=defaultdict(list)
    for row in read(TARGET/'純入口/TOPIX.json.gz'):rows[row['session']].append(row)
    for entry in entries:
        scene=entry['session'];route=J.T.M.Route(entry);cells={}
        for mother_pos,identity in enumerate(TP_IDS):
            for mode_pos,mode in enumerate(MODES):
                ci=mother_pos*len(MODES)+mode_pos;name=f'TOPIX201_I{identity:02d}_{mode}';ledger=packs[name]['ledger']
                ids=[i for i,s in enumerate(ledger['scene']) if s==scene];cursor=0;unavailable_until=-math.inf;count=defaultdict(int)
                for row in rows[scene]:
                    count['全q0']+=1;side=row['signals'][ci]
                    if not side:continue
                    count['純要求']+=1
                    if row['time']<=unavailable_until:count['枠棄却']+=1;continue
                    key=(row['time'],row['line'],side,row['widths'][ci])
                    if key not in cells:cells[key]=route.cell(*key)
                    cell=cells[key]
                    if cell is None:unavailable_until=min(row['time']+30,route.force);count['予約失効']+=1;continue
                    assert cursor<len(ids),(name,scene,'不足取得');i=ids[cursor];cursor+=1;count['取得']+=1
                    expected={'known':not cell['unknown'],'net':None if cell['unknown'] else round(cell['gross_pt']*1000-83.6-500,1),
                              'scene':scene,'phase':{'DAY':0,'PRE':1,'POST':2}[cell['band']],'origin':row['origins'][ci]}
                    for attr,values in ledger.items():
                        value=expected[attr] if attr in expected else cell[attr]
                        checks+=V.V.check_equal(values[i],value,(name,scene,i,attr))
                    unavailable_until=route.end if cell['unknown'] else cell['exit_time']
                assert cursor==len(ids),(name,scene,'余分取得');diagnostics[name+'_'+scene]=dict(count)
    return {'照合項目':checks,'全件枠診断':diagnostics,
            '範囲':'板判定後の全q0を別の一件状態で再生。NKは既存IFD表と非金融取得対応、TOPIXは不変Routeセルを共用。原BBOの独立再走査は過去監査の範囲であり、本検査で新たに行ったとはしない。'}


# ----------------------------------------
def baseline_sources() -> dict:
    """
    機能: 5母体の固定金融を明示し、生産側の同体検査関数から独立させる。
    引数: なし。
    返り値: dict[str,list[Path]]。
    """
    result={};study=ROOT/'study/00199_保留中の旧幹を確認済みの根拠で切り替える'
    for identity in NK_IDS:
        result['NK225201_'+identity+'_BASE']=[study/'保存金融'/(identity+'__C0_IFD.json.gz'),
            study/'追加二場/保存金融'/('NK225199_'+identity+'__C0_IFD.json.gz')]
    for identity in TP_IDS:
        paths=list((ROOT/'work/200TOPIX/全83金融正本').glob(f'TOPIX200_N{identity:02d}_*.json.gz'));assert len(paths)==1
        result[f'TOPIX201_I{identity:02d}_BASE']=paths
    return result


def financial_summary(rows: list) -> dict:
    """
    機能: 実際に取得した列だけの利益・損失・未知を集計する。
    引数: rows(list[dict])は取引。
    返り値: dict。未知を0円と確定せず既知寄与を分ける。
    """
    values=[r['net'] for r in rows if r['known']];unknown=sum(not r['known'] for r in rows)
    return {'取得':len(rows),'未知':unknown,'利益':sum(max(0,v) for v in values),'損失':sum(max(0,-v) for v in values),
            '既知収支':sum(values),'確定収支':sum(values) if not unknown else None,'赤字取得':sum(v<0 for v in values)}


def trade_rows(pack: dict) -> dict:
    """
    機能: 共通の実取得を、入口の別名でなく価格行・実側・幅・期限で識別する。
    引数: pack(dict)は一口座。
    返り値: dict[tuple,dict]。将来の仮想利益を作らない。
    """
    ledger=pack['ledger'];out={};nk=pack['id'].startswith('NK')
    for i in range(len(ledger['known'])):
        row={k:v[i] for k,v in ledger.items()};side=(1 if row['side']==0 else -1) if nk else row['side']
        key=(row['scene'],row['entry_line'],row['entry_time'],side,row['width'],row.get('horizon','H60'))
        assert key not in out;out[key]=row
    return out


def decomposition(packs: dict) -> list:
    """
    機能: 各案と自身の母体を共通・旧のみ・新のみの実現取引へ分解する。
    引数: packs(dict[str,dict])。
    返り値: list[dict]は全25案の帯・期間別比較と入替取引。
    """
    results=[]
    for name,pack in packs.items():
        mode=next(m for m in sorted(MODES,key=len,reverse=True) if name.endswith('_'+m))
        base=name[:-(len(mode)+1)]+'_BASE';old=trade_rows(packs[base]);new=trade_rows(pack)
        common=set(old)&set(new);only_old=set(old)-common;only_new=set(new)-common
        for key in common:
            for attr in ('net','known','entry_price','exit_price','exit_time','label'):
                assert old[key][attr]==new[key][attr],(name,key,attr)
        scenes=[s['scene'] for s in pack['sessions']]
        periods={'全83':scenes,'前48':scenes[:48],'後25':scenes[48:73],'追加7':scenes[73:80],'本日1':scenes[80:81],'追加2':scenes[81:]}
        summaries=[]
        for period,names in periods.items():
            eligible=set(names)
            for band in ('ALL','DAY','NIGHT','PRE','POST'):
                def includes(row: dict) -> bool:
                    """
                    機能: 元の取得帯と場を保ったまま分解対象を選ぶ。
                    引数: row(dict)。
                    返り値: bool。
                    """
                    return row['scene'] in eligible and (band=='ALL' or band=='NIGHT' and row['phase']!=0 or row['phase']=={'DAY':0,'PRE':1,'POST':2}.get(band))
                a=financial_summary([old[k] for k in sorted(common) if includes(old[k])])
                b=financial_summary([old[k] for k in sorted(only_old) if includes(old[k])])
                c=financial_summary([new[k] for k in sorted(only_new) if includes(new[k])])
                before=financial_summary([r for r in old.values() if includes(r)]);after=financial_summary([r for r in new.values() if includes(r)])
                assert before['取得']==a['取得']+b['取得'] and after['取得']==a['取得']+c['取得']
                assert math.isclose(after['既知収支']-before['既知収支'],c['既知収支']-b['既知収支'],abs_tol=1e-7)
                summaries.append({'期間':period,'帯':band,'共通':a,'旧のみ':b,'新のみ':c,'旧合計':before,'新合計':after})
        results.append({'候補':name,'母体':base,'集計':summaries,
                        '旧のみ実取得':[old[k] for k in sorted(only_old)],'新のみ実取得':[new[k] for k in sorted(only_new)]})
    return results


def finance_audit() -> None:
    """
    機能: GO後の全25金融正本について母体同体・別集計・全q0枠・実現取引差分を検査する。
    引数: なし。--financeはrootの金融完了連絡後だけ実行する。
    返り値: None。金融候補や順位を変更せず独立確認票を保存する。
    """
    assert (HERE/'純判定独立確認.json').exists()
    pure=read(HERE/'純判定独立確認.json');assert pure['条件']==ref(TRIAL/'条件.json')
    states_path=TARGET/'全25口座安定性.json.gz';states=read(states_path)['metrics'];assert len(states)==25
    paths=[TARGET/'金融正本'/(s['id']+'.json.gz') for s in states]
    references=[ref(p) for p in paths]+[ref(states_path)];packs={s['id']:read(p) for s,p in zip(states,paths,strict=True)}
    baseline=[]
    for name,files in baseline_sources().items():
        parents=[read(p) for p in files];actual=packs[name]
        for field in ('ledger','sessions','positions'):
            if field=='ledger':expected={k:sum((p[field][k] for p in parents),[]) for k in parents[0][field]}
            else:expected=sum((p[field] for p in parents),[])
            assert actual[field]==expected,(name,field)
        baseline.append({'候補':name,'成功':True,'元金融':[ref(p) for p in files]})
    group_checks=sum(V.inspect_groups(packs[s['id']],s) for s in states)
    slots=slot_audit(packs)
    save(HERE/'元新の実取得差分.json.gz',{'全83既使用':True,'実現取引のみ':True,'比較':decomposition(packs)})
    assert all(ref(ROOT/r['path'])==r for r in references)
    report={'成功':True,'候補数':25,'母体同体':baseline,'独立集計項目':group_checks,'枠再生':slots,
            'Source':ref(Path(__file__)),'既存別算術Source':ref(Path(V.__file__)),'金融正本':references,
            '差分':ref(HERE/'元新の実取得差分.json.gz'),'純確認':ref(HERE/'純判定独立確認.json')}
    save(HERE/'金融独立確認.json.gz',report)
    print(json.dumps({'成功':True,'候補数':25,'独立集計項目':group_checks,'枠属性':slots['照合項目']},ensure_ascii=False),flush=True)


if __name__=='__main__':
    cli=argparse.ArgumentParser();choice=cli.add_mutually_exclusive_group(required=True)
    choice.add_argument('--pure',action='store_true');choice.add_argument('--finance',action='store_true');args=cli.parse_args()
    if args.pure:pure_audit()
    else:finance_audit()
