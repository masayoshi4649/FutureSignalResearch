"""201の独立確認票と別算術Sourceだけを正式試行へ保存する。"""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
TRIAL=ROOT/'study/00201_板数量の更新尺度を複合入口へ加える'


def ref(path: Path) -> dict:
    """
    機能: 監査保存物の指紋を取得する。
    引数: path(Path)。
    返り値: dictは相対パス・容量・SHA256。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,
            'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


def main() -> None:
    """
    機能: root担当の主資料に触れず、独立名の正本・Source・索引を作る。
    引数: なし。
    返り値: None。原入力・新金融の複製を避け、監査票だけコピーする。
    """
    audit=TRIAL/'監査';audit.mkdir(parents=True,exist_ok=True);saved=[]
    names=('純判定独立確認.json','金融独立確認.json.gz','元新の実取得差分.json.gz','独立枠の人工確認.json','検査履歴.json','動的依存の同体確認.json')
    for name in names:
        target=audit/('独立検査履歴.json' if name=='検査履歴.json' else name)
        shutil.copyfile(HERE/name,target);assert target.read_bytes()==(HERE/name).read_bytes();saved.append(ref(target))
    paths=[HERE/name for name in ('独立確認201.py','金融検査接続修正前.py','独立枠を人工確認する.py','固定母体を確認復元する.py','正式保存201独立.py')]
    paths += [ROOT/'work/183損失安定性'/name for name in ('TOPIXを独立検算する.py','新候補の集計を独立検査する.py')]
    target=TRIAL/'独立Source.zip'
    with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for path in paths:
            member=zipfile.ZipInfo(path.relative_to(ROOT).as_posix(),date_time=(2026,11,18,0,0,0));member.compress_type=zipfile.ZIP_DEFLATED
            archive.writestr(member,path.read_bytes())
    with zipfile.ZipFile(target) as archive:
        for path in paths:assert archive.read(path.relative_to(ROOT).as_posix())==path.read_bytes()
    parents=ROOT/'study/00199_保留中の旧幹を確認済みの根拠で切り替える'
    index={'試行':201,'独立Source':[ref(p) for p in paths],'SourceZIP':ref(target),'監査正本':saved,
           '既存親純出生ZIP':[ref(parents/'純入口.zip'),ref(parents/'追加二場/純入口.zip')],
           '元入力を複製しない':True,'範囲':'新板条件の全件別式照合、既存IFD表不変での別一件状態、183の別集計。原BBOを新規に独立走査したものではない。'}
    (TRIAL/'独立Source索引.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'Source':len(paths),'監査票':len(saved),'ZIPbytes':target.stat().st_size},ensure_ascii=False))


if __name__=='__main__':main()
