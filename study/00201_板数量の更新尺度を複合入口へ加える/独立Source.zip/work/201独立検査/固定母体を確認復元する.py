"""独立監査の親純出生を、既存の正式199 ZIPから必要分だけ復元する。"""
from pathlib import Path
import hashlib
import zipfile

ROOT=Path(__file__).resolve().parents[2]


def main() -> None:
    """
    機能: 正式199の4純NPZだけを監査が参照するworkへ復元又は同体確認する。
    引数: なし。
    返り値: None。既存ファイルを上書きせず、原板や金融を生成しない。
    """
    study=ROOT/'study/00199_保留中の旧幹を確認済みの根拠で切り替える'
    pairs=[(study/'純入口.zip',f'work/199保留中の旧幹確認_未知保持/{leg}_新入口.npz') for leg in ('旧73','追加7','本日1')]
    pairs.append((study/'追加二場/純入口.zip','work/199追加二場の固定診断/追加二場純出生.npz'))
    for source,name in pairs:
        with zipfile.ZipFile(source) as archive:raw=archive.read(name)
        target=(ROOT/name).resolve();assert target.is_relative_to((ROOT/'work').resolve())
        if target.exists():assert hashlib.sha256(target.read_bytes()).digest()==hashlib.sha256(raw).digest()
        else:target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    print('正式199の親純出生4本を確認')


if __name__=='__main__':main()
