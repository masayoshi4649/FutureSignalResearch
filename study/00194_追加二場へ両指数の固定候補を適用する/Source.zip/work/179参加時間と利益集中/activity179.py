"""179向けの保有参加時間と利益集中の純集計。自然入力や金融ファイルは読まない。"""
from __future__ import annotations

from collections import Counter
from collections.abc import Mapping, Sequence
from copy import deepcopy
import importlib.util
import math
from numbers import Integral, Real
from pathlib import Path
import statistics
import sys

ROOT=Path(__file__).resolve().parents[2]
PATH_SOURCE=ROOT/'work/175経路と支持の評価/path175.py'
_spec=importlib.util.spec_from_file_location('activity179_path175',PATH_SOURCE)
_path=importlib.util.module_from_spec(_spec)
sys.modules[_spec.name]=_path
_spec.loader.exec_module(_path)
VERSION='179保有参加と利益集中1'
GROUPS=('DAY','NIGHT','PRE','POST','ALL')


def _number(value: object, name: str) -> float:
    """
    機能: 真偽値や非有限値を拒否して有限実数へ正規化する。
    引数: value(object)は値、name(str)は検査箇所。
    返り値: floatは有限実数。不正値はValueError。
    """
    if isinstance(value,bool) or not isinstance(value,Real) or not math.isfinite(value):
        raise ValueError(name+'は有限実数。')
    return float(value)


def _integer(value: object, name: str, positive: bool=False) -> int:
    """
    機能: 件数を整数として検査する。
    引数: value(object)、name(str)、positive(bool)は厳密な正数要求。
    返り値: intは0以上又は正の整数。不正値はValueError。
    """
    if isinstance(value,bool) or not isinstance(value,Integral) or value<(1 if positive else 0):
        raise ValueError(name+'は正の整数。' if positive else name+'は0以上の整数。')
    return int(value)


def _scene_id(value: object) -> str:
    """
    機能: 場IDを空でない文字列として検査する。
    引数: value(object)は場ID。
    返り値: strは実場ID。不正値はValueError。
    """
    if not isinstance(value,str) or not value:raise ValueError('sceneは空でない文字列。')
    return value


def _union(intervals: Sequence[tuple[float,float]]) -> list[tuple[float,float]]:
    """
    機能: 重複建玉や接する区間を和集合へまとめ、時間の二重計数を防ぐ。
    引数: intervals(Sequence[tuple[float,float]])は半開区間。
    返り値: list[tuple[float,float]]は重ならない時刻順の区間。
    """
    result=[]
    for start,end in sorted((a,b) for a,b in intervals if b>a):
        if result and start<=result[-1][1]:result[-1]=(result[-1][0],max(end,result[-1][1]))
        else:result.append((start,end))
    return result


def _duration(intervals: Sequence[tuple[float,float]], start: float, end: float) -> float:
    """
    機能: 和集合を一つの対象窓へ切り、実秒の保有長を計算する。
    引数: intervals(Sequence[tuple[float,float]])は和集合、start/end(float)は対象窓。
    返り値: floatは0以上の実秒。
    """
    return sum(max(0.0,min(end,b)-max(start,a)) for a,b in intervals)


def _target(lower: float|None, upper: float|None, target: float) -> dict:
    """
    機能: 下限・上限から目標の保証達成と不確定を分ける。
    引数: lower/upper(float|None)は比率境界、target(float)は目標。
    返り値: dictは達成/不確定/未達/評価不能と保証・上限側の旗。
    """
    guaranteed=lower is not None and lower>=target;possible=upper is not None and upper>=target
    status='評価不能' if lower is None else '達成' if guaranteed else '不確定' if possible else '未達'
    return {'target_status':status,'target_met_guaranteed':guaranteed,'target_met_possible':possible}


def _session(source: Mapping) -> dict:
    """
    機能: 対象時計と全域を覆う帯窓を検査する。観測の穴を分母から落とさない。
    引数: source(Mapping)はscene/kind/start/end/phasesと任意original_end/close_deadline。
    返り値: dictは正規化した場。phasesはname/start/end。
    """
    scene=_scene_id(source['scene']);kind=source['kind']
    if kind not in ('DAY','NIGHT'):raise ValueError('kindはDAY又はNIGHT。')
    start=_number(source['start'],'場開始');end=_number(source['end'],'対象終了')
    if end<=start:raise ValueError('対象終了は場開始より後。')
    original_end=_number(source.get('original_end',end),'元の終了')
    if original_end<end:raise ValueError('original_endは対象end以上。')
    deadline=_number(source.get('close_deadline',end),'全決済期限')
    if not start<=deadline<=end:raise ValueError('close_deadlineは対象時計内。')
    phases=[]
    for raw in source['phases']:
        name=raw['name'];a=_number(raw['start'],'帯開始');b=_number(raw['end'],'帯終了')
        if name not in (('DAY',) if kind=='DAY' else ('PRE','POST')):raise ValueError('kindと帯名が不一致。')
        if not start<=a<b<=end:raise ValueError('帯窓は対象場内の正の長さ。')
        phases.append({'name':name,'start':a,'end':b})
    phases.sort(key=lambda r:(r['start'],r['name']))
    if not phases or len({p['name'] for p in phases})!=len(phases):raise ValueError('帯は空不可・同名重複不可。')
    cursor=start
    for phase in phases:
        if phase['start']!=cursor:raise ValueError('帯窓は対象時計全域を隙間・重複なく分割する。')
        cursor=phase['end']
    if cursor!=end:raise ValueError('帯窓で対象末尾を除外しない。')
    if kind=='NIGHT' and [p['name'] for p in phases] not in (['PRE'],['POST'],['PRE','POST']):
        raise ValueError('Nightの帯順はPREからPOST。')
    return {'scene':scene,'kind':kind,'start':start,'end':end,'original_end':original_end,
        'close_deadline':deadline,'phases':phases}


def _holding_group(rows: list[dict], target: float) -> dict:
    """
    機能: 対象秒数による加重保有率と、場を等重みにする中央値境界を計算する。
    引数: rows(list[dict])は全対象場/帯の時間行、target(float)は目標。
    返り値: dictは両境界・場分布・目標診断。0保有場も分母へ残す。
    """
    ordered=sorted(rows,key=lambda r:(r['start'],r['scene'],r['phase']))
    denominator=sum(r['eligible_seconds'] for r in ordered)
    lower=sum(r['held_lower_seconds'] for r in ordered);upper=sum(r['held_upper_seconds'] for r in ordered)
    low_ratio=lower/denominator if denominator else None;high_ratio=upper/denominator if denominator else None
    low_median=statistics.median(r['held_lower_ratio'] for r in ordered) if ordered else None
    high_median=statistics.median(r['held_upper_ratio'] for r in ordered) if ordered else None
    return {'eligible_scene_count':len(ordered),'eligible_seconds':denominator,
        'held_lower_seconds':lower,'held_upper_seconds':upper,'held_lower_ratio':low_ratio,'held_upper_ratio':high_ratio,
        'scene_ratio_median_lower':low_median,'scene_ratio_median_upper':high_median,
        **_target(low_ratio,high_ratio,target),'median_target':_target(low_median,high_median,target),
        'scene_target_met_guaranteed_count':sum(r['target_met_guaranteed'] for r in ordered),
        'scene_target_met_possible_count':sum(r['target_met_possible'] for r in ordered),
        'uncertain_scene_count':sum(r['held_upper_seconds']>r['held_lower_seconds'] for r in ordered),
        'zero_guaranteed_holding_scene_count':sum(r['held_lower_seconds']==0 for r in ordered),'rows':ordered}


def holding_summary(sessions: Sequence[Mapping], positions: Sequence[Mapping], target_ratio: Real=.2) -> dict:
    """
    機能: 一枚以上の実保有時間を和集合で計り、未知退出の保証下限と上限を分離する。
    引数: sessions(Sequence[Mapping])はscene/kind/start/end/phases(name/start/end)、
          positions(Sequence[Mapping])はscene/fill/exit/confirmed_until/possible_until/quantity。
          status省略はfilled、pending/unfilled/cancelled/expiredは保有へ算入しない。
          exit=Noneではconfirmed_until既定fill、possible_until既定対象end。target_ratio(Real)は0..1。
    返り値: dictはDAY/NIGHT/PRE/POST/ALLの全時間加重率・場中央値境界と期限決済診断。
          全決済の要求時刻やengine上の架空場末保持をconfirmed_untilに入れてはならない。
    """
    target=_number(target_ratio,'目標比率')
    if not 0<=target<=1:raise ValueError('目標比率は0以上1以下。')
    scene_rows=[_session(source) for source in sessions]
    if len({r['scene'] for r in scene_rows})!=len(scene_rows):raise ValueError('対象sceneが重複。')
    scenes={r['scene']:r for r in scene_rows};by_scene={scene:[] for scene in scenes};statuses=Counter()
    for source in positions:
        scene=_scene_id(source['scene'])
        if scene not in scenes:raise ValueError('positionのsceneが対象時計にない。')
        status=source.get('status','filled')
        if status not in ('filled','pending','unfilled','cancelled','expired'):raise ValueError('未知の取得status。')
        statuses[status]+=1
        if status!='filled':continue
        _integer(source.get('quantity',1),'取得枚数',True)
        fill=_number(source['fill'],'実取得時刻');window=scenes[scene]
        if not window['start']<=fill<=window['end']:raise ValueError('実取得fillは対象場のstart～end内。')
        exit_time=source.get('exit')
        if exit_time is not None:
            exit_time=_number(exit_time,'既知決済時刻')
            if exit_time<fill:raise ValueError('決済が取得より前。')
            lower=upper=exit_time
        else:
            raw=source.get('confirmed_until');lower=fill if raw is None else _number(raw,'保証保有端')
            raw=source.get('possible_until');upper=max(window['end'],lower) if raw is None else _number(raw,'可能保有端')
            if not fill<=lower<=upper:raise ValueError('未知退出はfill<=confirmed_until<=possible_until。')
        by_scene[scene].append({'fill':fill,'exit':exit_time,'lower':lower,'upper':upper})
    # ----------------------------------------
    # 先に場ごとの和集合を作り、それを帯境界へ切る。跨帯や複数枚を重複加算しない。
    rows={name:[] for name in GROUPS};closure=[]
    for window in scene_rows:
        scene=window['scene'];items=by_scene[scene]
        lower=_union([(p['fill'],p['lower']) for p in items]);upper=_union([(p['fill'],p['upper']) for p in items])
        windows=[{'name':window['kind'],'start':window['start'],'end':window['end']}]
        if window['kind']=='NIGHT':windows+=window['phases']
        for phase in windows:
            a,b=phase['start'],phase['end'];lo=_duration(lower,a,b);hi=_duration(upper,a,b);seconds=b-a
            row={'scene':scene,'kind':window['kind'],'phase':phase['name'],'start':a,'end':b,
                'eligible_seconds':seconds,'held_lower_seconds':lo,'held_upper_seconds':hi,
                'held_lower_ratio':lo/seconds,'held_upper_ratio':hi/seconds,
                **_target(lo/seconds,hi/seconds,target)}
            rows[phase['name']].append(row)
            if phase['name']==window['kind']:rows['ALL'].append(dict(row))
        deadline=window['close_deadline']
        late=sum(p['exit'] is not None and p['exit']>deadline for p in items)
        past=sum(p['exit'] is None and p['lower']>deadline for p in items)
        unknown=sum(p['exit'] is None for p in items)
        flat=False if late or past else None if unknown else True
        closure.append({'scene':scene,'close_deadline':deadline,'known_late_exit_count':late,
            'confirmed_held_past_deadline_count':past,'unknown_exit_count':unknown,
            'entry_at_or_after_deadline_count':sum(p['fill']>=deadline for p in items),'flat_guaranteed':flat})
    return {'version':VERSION,'target_ratio':target,'groups':{name:_holding_group(rows[name],target) for name in GROUPS},
        'input_status_counts':{name:statuses[name] for name in ('filled','pending','unfilled','cancelled','expired')},
        'closure':{'known_violation_scene_count':sum(r['flat_guaranteed'] is False for r in closure),
            'unresolved_scene_count':sum(r['flat_guaranteed'] is None for r in closure),
            'guaranteed_flat_scene_count':sum(r['flat_guaranteed'] is True for r in closure),
            'all_scenes_flat_guaranteed':all(r['flat_guaranteed'] is True for r in closure) if closure else None,'rows':closure},
        'notes':['分母はsessionsのstart～end全域。欠測・待機・未決・無保有を除外しない。original_endは分母に使わない。',
            '下限20%以上だけを保証達成とする。上限側の到達は、達成を否定できないという緩い境界。',
            '枚数を時間へ乗じない。PRE→POST跨ぎは実秒で分割し、複数建玉は和集合。',
            'possible_until既定場末は評価域の上限であり、場末決済の証明ではない。未知exitはflat保証をしない。',
            '既知決済は時計だけの情報。金融の既知/未知とは別の入力として扱う。']}


# ----------------------------------------
# 財務の事後診断。新規発注や入口の閾値を決める関数ではない。


def _financial_rows(group: Mapping) -> list[dict]:
    """
    機能: metrics173の全場行を検査し、未知を0円の最終収支へ変換しない。
    引数: group(Mapping)はtrades/sessions.rowsを持つ金融群。
    返り値: list[dict]は検査済みの場行。元入力は変更しない。
    """
    rows=[]
    for source in group['sessions']['rows']:
        row=dict(source);row['scene']=_scene_id(source['scene'])
        for key in ('all_count','unknown_count'):row[key]=_integer(source[key],key)
        if row['unknown_count']>row['all_count']:raise ValueError('未知数が取得数を超える。')
        for key in ('known_profit','known_loss','known_net'):row[key]=_number(source[key],key)
        if row['known_profit']<0 or row['known_loss']<0:raise ValueError('利益・損失の絶対額は0以上。')
        if not math.isclose(row['known_profit']-row['known_loss'],row['known_net'],abs_tol=1e-8,rel_tol=1e-12):
            raise ValueError('利益−損失と既知寄与が不一致。')
        if row['unknown_count']:
            if source.get('all_net') is not None:raise ValueError('未知のある全件場収支はNone。')
            row['all_net']=None
        else:
            final=_number(source.get('all_net',row['known_net']),'全件確定場収支')
            if final!=row['known_net']:raise ValueError('全件確定場の既知寄与と収支が不一致。')
            row['all_net']=final
        if not row['all_count'] and (row['unknown_count'] or row['known_profit'] or row['known_loss']):
            raise ValueError('0取得場は未知0・利益損失0として残す。')
        rows.append(row)
    if len({r['scene'] for r in rows})!=len(rows):raise ValueError('金融群のsceneが重複。')
    if len(rows)!=group['sessions']['eligible_count']:raise ValueError('全対象場数と行数が不一致。')
    for key in ('all_count','unknown_count','known_profit','known_loss','known_net'):
        expected=sum(r[key] for r in rows);actual=group['trades'][key]
        if not math.isclose(expected,actual,abs_tol=1e-8,rel_tol=1e-12):raise ValueError('場行と建玉総計が不一致: '+key)
    return rows


def _counts(rows: Sequence[Mapping]) -> dict:
    """
    機能: 黒字・赤字・ゼロの完全場と、未知場・0取得場を別集計する。
    引数: rows(Sequence[Mapping])は未参加場を含む場行。
    返り値: dictは場の金融完全性と符号件数。
    """
    complete=[r for r in rows if not r['unknown_count']]
    return {'scene_count':len(rows),'complete_scene_count':len(complete),
        'positive_complete_scene_count':sum(r['all_net']>0 for r in complete),
        'negative_complete_scene_count':sum(r['all_net']<0 for r in complete),
        'zero_complete_scene_count':sum(r['all_net']==0 for r in complete),
        'unknown_scene_count':len(rows)-len(complete),'unknown_trade_count':sum(r['unknown_count'] for r in rows),
        'zero_acquisition_scene_count':sum(not r['all_count'] for r in rows)}


def _concentration(rows: list[dict], basis: str) -> dict:
    """
    機能: 正の集計値がある上位1/3/5場を順位ごとに除き、残存収支を計算する。
    引数: rows(list[dict])は全場、basis(str)はgross_profit/positive_scene_net/positive_complete_scene_net。
    返り値: dictは上位シェアと除外後の既知/全件収支・未知・支持。ゼロ点の場を便宜的に除かない。
    """
    if basis=='gross_profit':scores={r['scene']:r['known_profit'] for r in rows}
    elif basis=='positive_scene_net':scores={r['scene']:max(0.0,r['known_net']) for r in rows}
    else:scores={r['scene']:max(0.0,r['all_net']) for r in rows if not r['unknown_count']}
    ordered=sorted((r for r in rows if scores.get(r['scene'],0)>0),key=lambda r:(-scores[r['scene']],r['scene']))
    total=sum(scores.values());top=[]
    for k in (1,3,5):
        removed=ordered[:k];ids={r['scene'] for r in removed};remaining=[r for r in rows if r['scene'] not in ids]
        amount=sum(scores[r['scene']] for r in removed);counts=_counts(remaining)
        known_profit=sum(r['known_profit'] for r in remaining);known_loss=sum(r['known_loss'] for r in remaining)
        known_net=sum(r['known_net'] for r in remaining);unknown=counts['unknown_trade_count']
        top.append({'requested_top_count':k,'actual_removed_scene_count':len(removed),'removed_scenes':[r['scene'] for r in removed],
            'amount':amount,'share':amount/total if total else None,
            'removed_unknown_scene_count':sum(r['unknown_count']>0 for r in removed),
            'removed_unknown_trade_count':sum(r['unknown_count'] for r in removed),
            'remaining':{**counts,'trade_count':sum(r['all_count'] for r in remaining),'known_profit':known_profit,
                'known_loss':known_loss,'known_net':known_net,'all_net':known_net if remaining and not unknown else None,
                'all_net_exact':bool(remaining and not unknown)}})
    meanings={'gross_profit':'場内の既知利益総額。場純益が赤字の場も上位になり得る。',
        'positive_scene_net':'max(既知寄与の場純益,0)。未知場の最終純益と同一ではない。',
        'positive_complete_scene_net':'全件確定場のmax(全件純益,0)。未知場を正益0とせず順位対象外にする。'}
    return {'meaning':meanings[basis],'ranking_value_total':total,'positive_ranking_scene_count':len(ordered),
        'unknown_scenes_omitted_from_ranking':sum(r['unknown_count']>0 for r in rows) if basis=='positive_complete_scene_net' else 0,'top':top}


def _trade_distribution(rows: list[dict]) -> dict:
    """
    機能: 全対象場で取得数の分布と上位場集中を計算する。
    引数: rows(list[dict])は0取得場を含む場行。
    返り値: dictは最小・中央値・平均・最大・度数と上位1/3/5場シェア。
    """
    values=[r['all_count'] for r in rows];total=sum(values);histogram=Counter(values)
    ordered=sorted(rows,key=lambda r:(-r['all_count'],r['scene']))
    return {'eligible_scene_count':len(rows),'trade_count':total,'minimum':min(values,default=None),
        'median':statistics.median(values) if values else None,'mean':total/len(rows) if rows else None,
        'maximum':max(values,default=None),'histogram':[{'trade_count':k,'scene_count':v} for k,v in sorted(histogram.items())],
        'top':[{'requested_top_count':k,'actual_scene_count':min(k,len(rows)),
            'scenes':[r['scene'] for r in ordered[:k]],'trade_count':sum(r['all_count'] for r in ordered[:k]),
            'share':sum(r['all_count'] for r in ordered[:k])/total if total else None} for k in (1,3,5)]}


def financial_diagnostics(group: Mapping) -> dict:
    """
    機能: metrics173の一群へ利益集中・除外後収支・取得分布・完全/未知寄与DDを加える。
    引数: group(Mapping)はtrades/sessions.rows/decisionを持つ金融群。
    返り値: dictは事後診断。Day/Nightの両中央値判定は入力を保持し、新しい順位や金額閾値を導入しない。
    """
    rows=_financial_rows(group);unknown=sum(r['unknown_count'] for r in rows)
    profit=sum(r['known_profit'] for r in rows);loss=sum(r['known_loss'] for r in rows);net=sum(r['known_net'] for r in rows)
    return {'version':VERSION,**_counts(rows),'trade_count':sum(r['all_count'] for r in rows),
        'known_profit':profit,'known_loss':loss,'known_net':net,'all_net':net if rows and not unknown else None,
        'all_net_exact':bool(rows and not unknown),'decision':deepcopy(group.get('decision')),
        'trade_net_median':deepcopy(group['trades'].get('net_median')),
        'session_net_median':deepcopy(group['sessions'].get('net_median')),
        'concentration':{basis:_concentration(rows,basis) for basis in ('gross_profit','positive_scene_net','positive_complete_scene_net')},
        'trade_count_distribution':_trade_distribution(rows),'path':_path.path_summary(group),
        'notes':['集中と上位場除外後は事後診断であり、入口の当時情報ではない。',
            '利益総額と正の場純益を混同しない。未知場の既知寄与は最終場純益ではない。',
            '上位kに正の順位値を持つ場がk未満なら、その正の場だけを除く。ゼロ点の赤字/未知場を便宜的に除外しない。',
            '除外後も未知が残れば全件収支None。残存場0も確定黒字とせずall_net=None。',
            'path175のexact_pathは全件既知のみ。known_contributionは完全DDではなく、保有中時価DDも表さない。']}
