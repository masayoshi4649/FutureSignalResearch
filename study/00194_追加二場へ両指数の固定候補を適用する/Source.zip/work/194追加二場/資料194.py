"""194の結果・候補別閲覧入口・汎用表を恒久保存する。"""
from pathlib import Path
import csv
import gzip
import hashlib
import io
import json
import math
import re
import shutil

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
TRIAL=ROOT/'study/00194_追加二場へ両指数の固定候補を適用する'
OUT=ROOT/'outputs/00194_追加二場の固定適用'
NK=ROOT/'study/00193_構造拡大停止と順行取得位置を確認する'
TP=ROOT/'study/00192_TOPIXの価格構造と数量尺度で方向を判別する'


def load(path: Path) -> object:
    """
    機能: JSON又はgzip JSONを読み込む。
    引数: path(Path)は保存済み入力。
    返り値: objectは解析値。
    """
    raw=path.read_bytes();return json.loads(gzip.decompress(raw) if path.suffix=='.gz' else raw)


# ----------------------------------------
def save(path: Path, text: str) -> None:
    """
    機能: 日本語UTF-8資料を新規保存し、再実行時は同体を確認する。
    引数: path(Path)、text(str)。
    返り値: None。
    """
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():assert path.read_text(encoding='utf-8')==text,path
    else:path.write_text(text,encoding='utf-8')


# ----------------------------------------
def main() -> None:
    """
    機能: 検算済み9候補を正式保存し、CSV全セル・金額・0取引行を照合する。
    引数: なし。
    返り値: None。売買条件・選択・旧試行を変更しない。
    """
    assert load(HERE/'独立監査194.json')['成功']
    for name in ('全候補純封印.json','金融開始前固定.json','追加二場安定性.json.gz','追加二場短表.json',
                 '独立監査194.json','再計算確認194.json','NK金融接続前の検査194.json','閲覧入力.json'):
        shutil.copy2(HERE/name,TRIAL/name)
    (TRIAL/'金融正本').mkdir(exist_ok=True)
    for path in (HERE/'金融正本').glob('*.json.gz'):shutil.copy2(path,TRIAL/'金融正本'/path.name)
    data=load(HERE/'閲覧入力.json');proof=load(ROOT/'work/194CSV検査/作成確認.json');cells=0
    for item in proof['files']:
        path=OUT/item['相対path'];raw=path.read_bytes()
        assert hashlib.sha256(raw).hexdigest()==item['sha256']
        actual=list(csv.reader(io.StringIO(raw.decode('utf-8-sig'))))
        source=data['tables'][item['元表']]
        expected=[source['headers']]+[r for r in source['rows'] if r[0]==item['候補']]
        assert len(actual)==len(expected)
        for left,right in zip(actual,expected,strict=True):
            assert len(left)==len(right)
            for a,b in zip(left,right,strict=True):
                cells+=1
                if b is None:assert a==''
                elif isinstance(b,(float,int)):assert math.isclose(float(a),b,abs_tol=1e-7)
                else:assert a==b
        for row in actual[1:]:assert math.isclose(float(row[3])-float(row[4]),float(row[5]),abs_tol=1e-7)
    proof['CSV再読の全セル照合']=cells;proof['全CSVの費用後利益引く損失と収支一致']=True
    save(TRIAL/'CSV確認.json',json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
    # ----------------------------------------
    # 全63手法・9尺度をコピーし、選択候補に使う親設定への参照を保持する。
    def grid(parent: Path) -> dict:
        """
        機能: 固定済み親試行の全尺度セルを取得する。
        引数: parent(Path)は試行フォルダ。
        返り値: dict[str,list[str]]は63行。
        """
        rows={}
        for line in (parent/'設定と結果.md').read_text(encoding='utf-8').splitlines():
            parts=[c.strip() for c in line.split('|')[1:-1]] if line.startswith('|') else []
            if len(parts)==11 and re.fullmatch(r'[ICPVBEMX][0-9]{2}',parts[0]):rows[parts[0]]=parts
        assert len(rows)==63;return rows
    ng,tg=grid(NK),grid(TP)
    template=ROOT/'docs/議論/手法と時間スケールの汎用表_版8.md'
    body=template.read_text(encoding='utf-8').split('## 設定明細（コピー後に記入）')[0]
    body=body.replace('# 手法と時間スケールの汎用表・版8','# 194 設定と結果・版8')
    body=body.replace('全セルは未設定・未検証。','Nは193、Tは192の設定IDを参照。R194は今回の追加2場の複合評価。未使用は今回使わないもの。')
    body=body.replace('](../technical-analysis/','](../../docs/technical-analysis/')
    lines=[];count=0
    for line in body.splitlines():
        parts=[c.strip() for c in line.split('|')[1:-1]] if line.startswith('|') else []
        if len(parts)==11 and parts[0] in ng:
            count+=1;code=parts[0];parts[1]=ng[code][1]
            for i in range(2,11):
                a,b=ng[code][i],tg[code][i]
                uses=[]
                if a!='未使用':uses.append('N:'+a)
                if b!='未使用':uses.append('T:'+b)
                parts[i]=' / '.join(uses)+'/R194' if uses else '未使用'
            line='| '+' | '.join(parts)+' |'
        elif line.startswith('[版7]'):line='[版7](../../docs/議論/手法と時間スケールの汎用表_版7.md)。旧表と旧試行は変更しない。'
        lines.append(line)
    assert count==63
    tail='''
## 設定と選択

Nの閾値正本は[193の設定](../00193_構造拡大停止と順行取得位置を確認する/設定と結果.md)、Tは[192の設定](../00192_TOPIXの価格構造と数量尺度で方向を判別する/設定と結果.md)。表は両商品の参照範囲をまとめたもので、個々の候補が全セルを同時使用するという意味ではない。候補別の有効分岐は[条件](条件.json)内の固定選択とSourceに従う。

- N00は旧179、N01/N02はR1/R2の反転・順行C120確認、N04はN01の反転側へ短中期MA構造の非拡大を追加。順行の新しい位置上限制限は今回の4案に含めない。元幅・期限を変更しない。
- T00は190 D4/N01固定、T04は旧足P0厳・1分相対量、T20/T56は旧足/直接足のレンジ端回復・緩・5分相対量、T29は旧足の混在構造転換・厳・5分相対量。旧/直接の履歴、幅、量、価格条件を継承。
- TOPIX新案のデイ幅は当時ATR5×2.5を5〜25pt、0.25pt単位へ切上げ。ナイト幅15pt、H60。Nは旧入口枝の固定幅・H60/H120等を引き継ぐ。全案対称IFD、追尾なし。
- mini各1枚、保有/予約合計1、開始待機なし、デイ15:30/ナイト05:45まで。NK往復1,077円、TOPIX往復583.6円の手数料と仮定滑りを含む。ラージBBO代用。

## R194の結果

追加2場は今回の候補固定時には未参照。結果を読んだ後は既使用扱い。全9案・52取得、金融未知0。N00は−20,616円、N01/N02/N04は各−61,616円。T00は+19,080.4円、T04は−32,585.2円、T20/T56は0取得、T29は2取得+19,832.8円だが保有7.12%。支持の小さい黒字を安定採用にしない。詳細は[結果](README.md)・[全集計](追加二場安定性.json.gz)・[独立監査](独立監査194.json)。複合結果を個別指標の効果としない。

## 版と再現

全63手法×9尺度=567セル。元表のSHA256: '''+hashlib.sha256(template.read_bytes()).hexdigest()+'''。
[入力](../../inputs/00194_20261116夜と1117昼の固定適用入力/README.md)・[再現](再現.md)。
'''
    save(TRIAL/'設定と結果.md','\n'.join(lines)+'\n'+tail)
    # ----------------------------------------
    # 成績の良否で候補を並べ替えず、金融前に固定した順をそのまま案内する。
    rows=['|候補|内容|デイ収支|ナイト収支|建玉数（デイ/夜間）|','|---|---|---:|---:|---:|']
    titles={'NK_00':'旧179','NK_01':'R1・C120確認','NK_02':'R2・C120確認','NK_04':'R1・MA構造非拡大',
            'TP_00':'旧190 D4/N01','TP_04':'旧足P0厳・1分量','TP_20':'旧足レンジ端・5分量',
            'TP_29':'旧足混在構造転換・5分量','TP_56':'直接足レンジ端・5分量'}
    stats={s['id']:s for s in load(HERE/'追加二場安定性.json.gz')['metrics']}
    for mapping in data['候補対応']:
        key=mapping['候補'].split(':')[1];folder='194_'+key;s=stats[mapping['正本ID']]['groups']
        d,n=s['DAY']['trades'],s['NIGHT']['trades']
        rows.append(f"|[{key}]({folder}/README.md)|{titles[key]}|{d['known_net']:,.1f}|{n['known_net']:,.1f}|{d['all_count']} / {n['all_count']}|")
        text=f'''# {mapping['候補']} {titles[key]}

商品は{mapping['商品']}。{mapping['費用']}。ラージ板による約定代用。

対象は2026-11-16ナイトと11-17デイだけ。正本IDは `{mapping['正本ID']}`。

[集計](集計.csv) / [デイ](デイ.csv) / [ナイト米国前](ナイト_米前.csv) / [ナイト米国後](ナイト_米後.csv)。費用後の利益と損失、収支を分ける。累計はこの追加期間・当該帯の0円から。未知は空欄で保持する仕様であり、今回の9案は全件既知。

損益は新規取得時の帯へ帰属する。保有時間率は各帯と保有区間の重なりなので、米国前の建玉を持ち越した米国後には、新規0回・保有時間正の場合がある。0取引行も残す。比率は0〜1。

[比較一覧](../README.md) / [条件・限界](../../../study/00194_追加二場へ両指数の固定候補を適用する/README.md)。
'''
        save(OUT/folder/'README.md',text)
    intro='''# 194 追加2セッションへの固定適用

2026-11-16ナイト・11-17デイ。旧81場で固定した9候補を、再選択せず適用した。商品ごとにmini1枚・費用後の円。各候補のCSVは分離している。

'''
    table='\n'.join(rows)+'\n'
    save(OUT/'README.md',intro+table+'''
旧81場を含む全期間表ではない。過去の固定結果は[193（日経）](../../study/00193_構造拡大停止と順行取得位置を確認する/README.md)、[192（TOPIX）](../../study/00192_TOPIXの価格構造と数量尺度で方向を判別する/README.md)。2場だけで将来の安定性を証明しない。[194の条件と検算](../../study/00194_追加二場へ両指数の固定候補を適用する/README.md)。
''')
    maintext='''# 194 追加2場へ両指数の固定候補を適用する

2026-11-18。旧81場から固定した日経4案・TOPIX5案を、未参照だった11/16ナイト・11/17デイへ適用した。**日経の改善候補は追加デイで旧条件より悪化した。TOPIX旧対照は両場黒字だが、2場だけを安定採用の根拠にしない。** 結果を受け、入口の原因診断と新仮説を継続する。

## 固定適用の結果

金額は費用後・各mini1枚。条件別の詳細は[候補別CSV](../../outputs/00194_追加二場の固定適用/README.md)。

|候補|デイ利益|デイ損失|デイ収支|夜間利益|夜間損失|夜間収支|
|---|---:|---:|---:|---:|---:|---:|
'''
    for m in data['候補対応']:
        key=m['候補'].split(':')[1];g=stats[m['正本ID']]['groups'];d,n=g['DAY']['trades'],g['NIGHT']['trades']
        values=[d['known_profit'],d['known_loss'],d['known_net'],n['known_profit'],n['known_loss'],n['known_net']]
        maintext+='|'+key+'|'+'|'.join(f'{x:,.1f}' for x in values)+'|\n'
    maintext+='''
日経は全4案でデイ6・夜間2取得、両場参加。保有率はデイ約53.15〜53.17%、夜間23.53%。N01/02/04のデイ収支はN00より41,000円悪化した。193の過去80デイの損失軽減と、追加日の悪化を相殺して隠さない。TOPIX T00はデイ7・夜間4取得、保有73.87%/18.76%。T04は4/3、T29は1/1、T20/T56は0/0。T29の2勝を頻度の充足としない。全9案・計52取得は未知0。

N00のデイ旧順位・N02の夜間旧順位、TOPIXの不適格を含む固定順位と参考対照を維持。帯ごとに今回の最高収支候補を合成していない。実取引口座の改善と、新しい確認枝単体の損益は別評価する。

## 仮説・入力・条件

193で損失を軽減した構造確認、192の価格・量による方向判別が追加期間にも通用するかを確かめる固定適用。[金融前の条件](条件.json)には選択・Source・純出生のSHAを保存。親試行の全81場は既使用、この2場は選択時点で未参照だった。開封後は今後の探索で既使用扱い。

[入力の由来と指紋](../../inputs/00194_20261116夜と1117昼の固定適用入力/README.md)。原順8列4資源と日経48byte価格索引を恒久保存し、旧履歴を引き継ぐ。日経の旧73・追加7・11/16デイで固定2基準の全配列同体、TOPIX旧81の全34,424 q0・73候補の純出生同体を確認して追加2場へ接続した。追加母集団は日経1,014 q0、TOPIX旧/直接の和集合937 q0。

単純対称IFD。日経は旧入口枝の幅・期限、TOPIXはデイATR5×2.5（5〜25pt/0.25切上げ）・夜間15pt/H60を継承。買売合計保有・予約1、開始待機なし、デイ15:30/ナイト05:45まで。新規の価格時計・最大待ち・末尾の注文限界も親実装を継承。NK片道38.5円＋5pt、TOPIX片道41.8円＋0.25pt。ラージ板のBBO代用でminiの実約定を観測したものではない。

## 検査・再現・限界

[独立監査](独立監査194.json)は金融後の検査。全52取得を評価器を呼ばない原BBO走査へ照合し、NK86要求・TOPIX126成立q0の単一枠・予約処理、1,084金融属性・3,474集計属性が一致。4原JSONLの全SHAと54異なる採用原行も確認。既知決済は全件期限内、0取引2候補も全2場を残した。[再計算](再計算確認194.json)は同じ実装による全9台帳・全集計の同体確認で、独立監査と区別する。[CSV確認](CSV確認.json)は36ファイル・1,296セルを再読して一致。

金融前の主条件票に直接列挙されていなかった依存6件は、既存の金融接続前検査票とSHA一致を確認した。主条件票へ事後に追加して事前封印とすることはしていない。監査票へ対象と限界を記録した。独立した受信・Bid/Ask更新時計の欠落、約定遅延の仮定、わずか2場の支持にも留意する。

[設定と結果](設定と結果.md)は汎用表版8の567セル。[再現手順](再現.md)・[Source索引](Source索引.json)。損益閲覧はCSV、正本は小さなJSON gzip。旧81の結果・選択を変更していない。
'''
    save(TRIAL/'README.md',maintext)
    dest=ROOT/'inputs/00194_20261116夜と1117昼の固定適用入力'
    save(dest/'README.md','''# 194 追加2場の恒久入力

2026-11-16_Nightと2026-11-17_Day、NK225/TOPIXの4原板。[入力生成前の方針](../../study/00194_追加二場へ両指数の固定候補を適用する/入力生成前の方針.json)に原板の位置・byte数・SHA256と生成Sourceがある。原板本体は共用JP_OSE_Dataを参照し重複保存しない。

[原順8列台帳](原順8列/入力台帳.json)の4NPZは価格時計・原行・Last/Bid/Ask・正常旗・累積量・量時計。数量不明と0を区別する。独立した受信時計や全板更新時計を持つ形式ではない。

日経の[価格索引](NK225/原板数値索引/manifest.json)、[母集団の接続計画](NK225/母集団接続計画.json)、[純接続確認](NK225/固定基準の純接続/純接続完了194.json)を保存。旧前史8場との同体を確認したうえで、追加2場の1,014 q0を作成した。

TOPIXの[形成同体](TOPIX/特徴の同体確認.json)、[純出生同体](TOPIX/純出生の同体確認.json)、旧/直接特徴と全73候補の追加2場純入力を保存。旧81場を全件照合し、追加和集合937 q0。旧入力本体は既存恒久inputsを参照する。

[研究正本](../../study/00194_追加二場へ両指数の固定候補を適用する/README.md)・[再現](../../study/00194_追加二場へ両指数の固定候補を適用する/再現.md)。追加2場の金融結果を読む前に候補・入力を固定した。今後は既使用であり、未見として再利用しない。
''')
    print(json.dumps({'正式保存':True,'全セル':cells,'汎用表':567,'候補':9},ensure_ascii=False))


# ----------------------------------------
if __name__=='__main__':main()
