"""TOPIXの旧81場と同体の履歴を継承し、追加2場の固定候補を金融前に生成する。"""
from pathlib import Path
from collections import Counter,deque
import argparse
import copy
import gzip
import importlib.util
import json
import sys
import numpy as np
import 入力194 as I

ROOT=I.ROOT;HERE=Path(__file__).parent;DEST=I.DEST/'TOPIX'
sys.path.insert(0,str(ROOT/'work/184TOPIX'))
import 直接形成184 as D
M=D.BASE


def entries():
    """
    機能: 旧81と追加2の恒久8列入力を同じ形で返す。
    引数: なし。
    返り値: list[dict]は原板を複製しない83場参照。
    """
    compact=I.read(ROOT/'inputs/TOPIX原順8列_20260921_20261116/台帳.json')
    old=I.read(ROOT/'work/183TOPIX/入力台帳.json')['entries']
    contracts={tuple(e['in_session_contract_codes']) for e in old};assert len(contracts)==1
    result=[]
    for e in compact['entries']:
        path=ROOT/e['path'];assert M.sha(path)==e['sha256']
        result.append({'session':e['session'],'cache_absolute':str(path),'sha256_cache':e['sha256'],
            'in_session_contract_codes':list(next(iter(contracts)))})
    added=[e for e in I.read(I.DEST/'原順8列/入力台帳.json')['entries'] if e['symbol']=='TOPIX']
    assert [e['session'] for e in added]==list(I.SCENES)
    assert all(tuple(e['in_session_contract_codes']) in contracts for e in added)
    for e in added:
        assert M.sha(Path(e['cache_absolute']))==e['sha256_cache'];result.append(e)
    assert len(result)==83 and len({e['session'] for e in result})==83
    return result


def features():
    """
    機能: 旧/直接の2形成を同じSourceで再生し、旧81全q0の同体を検査する。
    引数: なし。
    返り値: None。追加特徴だけを恒久保存し、金融は読まない。
    """
    sources=[I.ref(p) for p in (Path(__file__),Path(D.__file__),Path(M.__file__))]
    rows=entries();I.save(DEST/'形成前の固定.json',{'金融未入力':True,'Source':sources,'entries':rows})
    proof=[]
    for form,name in enumerate(('純特徴183.json.gz','純特徴184直接.json.gz')):
        channels={n:M.Channel() for n in (5,15,30)};allrows=[];quality=[];contract=None
        for i,e in enumerate(rows):
            if contract!=e['in_session_contract_codes']:
                channels={n:M.Channel() for n in (5,15,30)};contract=e['in_session_contract_codes']
            values,qa=M.bars_and_features(e,channels) if form==0 else D.direct_features(e,channels,Counter())
            for row in values:
                plus=M.roles(row,1);minus=M.roles(row,-1)
                row['signals']=[1 if a and not b else -1 if b and not a else 0 for a,b in zip(plus,minus)]
            allrows.extend(values);quality.append({'session':e['session'],**qa})
            if (i+1)%20==0:print(json.dumps({'TOPIX非金融形成':form,'場数':i+1},ensure_ascii=False),flush=True)
        old=I.read(ROOT/'inputs/TOPIX原順8列_20260921_20261116'/name)
        prior=[r for r in allrows if r['session'] not in I.SCENES];new=[r for r in allrows if r['session'] in I.SCENES]
        assert prior==old,('旧81特徴差',form)
        I.save(DEST/name,new);I.save(DEST/(str(form)+'_入力品質.json'),quality)
        proof.append({'形成':form,'旧81全件同体':True,'旧q0':len(old),'追加q0':len(new),'純特徴':I.ref(DEST/name)})
    assert all(I.ref(Path(s['path']))==s for s in sources)
    I.save(DEST/'特徴の同体確認.json',{'成功':True,'金融未入力':True,'確認':proof})
    print(json.dumps(proof,ensure_ascii=False),flush=True)


def per_form(source,rule192):
    """
    機能: 各形成の当時履歴から186/189固定役割と192新規役割用文脈を作る。
    引数: source(list[dict])は純特徴、rule192(module)は固定済み192。
    返り値: dict[tuple,dict]はq0の役割・履歴。金融なし。
    """
    legacy=I.module(ROOT/'work/189TOPIX/入口189.py','旧189_194')
    history=deque(maxlen=3);previous=None;scene=None;ident=None;result={}
    for row in source:
        if row['session']!=scene:history.clear();previous=None;ident=None;scene=row['session']
        current=tuple(row['m5'][k] for k in ('count','end','published'))
        if current!=ident:history.append(row['m5']);ident=current
        context={'history':list(history),'previous':previous};choices={}
        for strict in (False,True):
            plus=rule192.U.roles(row,1,context,strict);minus=rule192.U.roles(row,-1,context,strict)
            choices[strict]=[1 if a and not b else -1 if b and not a else 0 for a,b in zip(plus,minus)]
        base=[]
        for i in range(12):base.extend([choices[False][i],choices[True][i]])
        key=(scene,row['time'],row['line'])
        result[key]={'row':row,'context':context,'q0':legacy.decide(row,context,base,0,7),
            'q1':legacy.decide(row,context,base,1,0)}
        previous=row
    return result


def control(old,direct):
    """
    機能: 固定190 D4/N01の方向と幅だけを純情報から再生する。
    引数: old/direct(dict|None)は各形成の当時役割。
    返り値: tuple[int,float|None,str]は方向・幅・出生。費用境界の旧条件を変更しない。
    """
    row=(direct or old)['row']
    if row['band']=='DAY':
        if direct is None:return 0,None,'直接準備不足'
        r=direct['row'];side,origin=direct['q1'];m=r['m5']
        if origin=='量不明補完' and (side*(m['hist_delta'] or 0)<0 or side*(m['rsi_delta'] or 0)<0):side,origin=0,'動力改善なし'
        width=np.ceil(min(25.,max(5.,r['atr']*2.5))*4)/4
        return side,float(width),origin
    if old is None or direct is None:return 0,15.,'共通外'
    side,origin=old['q0'];return side,15.,'旧'+origin


def pure():
    """
    機能: 固定192の全73候補を旧81で同体検査し、追加2場へ適用する。
    引数: なし。
    返り値: None。追加金融は候補選択封印まで実行しない。
    """
    rule=I.module(ROOT/'work/192TOPIX/入口192.py','固定192_194')
    cfg=I.read(ROOT/'work/192TOPIX/条件.json')
    assert all(M.sha(ROOT/p)==sha for p,sha in cfg['Source'].items())
    old_pure=I.read(ROOT/'work/192TOPIX/純入口.json.gz');old_lookup={(r['session'],r['time'],r['line']):r for r in old_pure}
    combined={}
    for form,name in enumerate(('純特徴183.json.gz','純特徴184直接.json.gz')):
        combined[form]=I.read(ROOT/'inputs/TOPIX原順8列_20260921_20261116'/name)+I.read(DEST/name)
    maps={f:per_form(rows,rule) for f,rows in combined.items()};keys=set(maps[0])|set(maps[1]);extra={k:r['extra'] for k,r in old_lookup.items()}
    for entry in entries()[-2:]:
        with np.load(entry['cache_absolute'],allow_pickle=False) as z:data={k:z[k] for k in z.files}
        extra.update(rule.extra_for_scene(data,[k for k in keys if k[0]==entry['session']]))
    outputs=[];checked=0
    for key in sorted(keys):
        old=maps[0].get(key);direct=maps[1].get(key);row=(direct or old)['row'];side,w,origin=control(old,direct)
        signals=[side];widths=[w];origins=['190:'+origin]
        for spec in rule.SPECS:
            formed=maps[spec['form']].get(key)
            side=rule.signals(formed['row'],formed['context'],extra[key],spec['strict'],spec['quantity'])[spec['family']] if formed else 0
            signals.append(side);widths.append(rule.U.width(formed['row'],'A25') if formed and row['band']=='DAY' else 15. if formed else None)
            origins.append(spec['name'] if side else '待機又は形成不足')
        result={'session':key[0],'time':key[1],'line':key[2],'band':row['band'],'signals':signals,'widths':widths,'origins':origins,'extra':extra[key]}
        if key in old_lookup:assert result==old_lookup[key],('旧192純出生差',key);checked+=1
        else:outputs.append(result)
    I.save(DEST/'純入口192追加二場.json.gz',outputs)
    I.save(DEST/'純出生の同体確認.json',{'成功':True,'金融未入力':True,'旧81全q0同体':checked,'追加q0':len(outputs),'候補数':len(rule.NAMES),
        'Source':[I.ref(Path(__file__)),I.ref(Path(rule.__file__)),I.ref(ROOT/'work/189TOPIX/入口189.py')],
        '固定192条件':I.ref(ROOT/'work/192TOPIX/条件.json'),'純入口':I.ref(DEST/'純入口192追加二場.json.gz')})
    print(json.dumps({'TOPIX純出生同体':checked,'追加q0':len(outputs),'候補':len(rule.NAMES)},ensure_ascii=False),flush=True)


def main():
    """
    機能: 非金融特徴生成と、固定後の純候補生成を明示分離する。
    引数: CLI --features又は--pure。
    返り値: None。
    """
    parser=argparse.ArgumentParser();group=parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--features',action='store_true');group.add_argument('--pure',action='store_true');args=parser.parse_args()
    if args.features:features()
    else:pure()


if __name__=='__main__':main()
