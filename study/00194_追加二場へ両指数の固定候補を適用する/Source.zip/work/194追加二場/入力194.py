"""追加2場の価格と数量を固定し、既存条件の適用前に非金融母集団を準備する。"""
from pathlib import Path
from datetime import datetime,timedelta,timezone
import argparse
import copy
import gzip
import hashlib
import importlib.util
import json
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
DEST=ROOT/'inputs/00194_20261116夜と1117昼の固定適用入力'
TRIAL=ROOT/'study/00194_追加二場へ両指数の固定候補を適用する'
SCENES=('2026-11-16_Night','2026-11-17_Day');PRODUCTS=('NK225','TOPIX')
DATA=ROOT.parent/'JP_OSE_Data/future';JST=timezone(timedelta(hours=9))
INDEX=ROOT/'work/166可変場の観測/可変場観測.exe'
BRIDGE=ROOT/'work/未見入口の同体接続/入口同体接続.exe'


def read(path):
    """
    機能: UTF-8 JSON又はgzip JSONを読む。
    引数: path(Path)。
    返り値: objectは解析値。
    """
    raw=path.read_bytes();return json.loads(gzip.decompress(raw) if path.suffix=='.gz' else raw)


def ref(path):
    """
    機能: 原板・Sourceの物理指紋を前後stat付きで検証する。
    引数: path(Path)。
    返り値: dictは絶対path、bytes、SHA256。
    """
    before=path.stat()
    with path.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
    after=path.stat();assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns)
    return {'path':str(path),'bytes':after.st_size,'sha256':digest}


def save(path,value):
    """
    機能: 新規資源を保存し、再実行は既存との同体だけ許可する。
    引数: path(Path),value(object)。
    返り値: None。
    """
    raw=(json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode()
    body=gzip.compress(raw,mtime=0) if path.suffix=='.gz' else raw
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():assert path.read_bytes()==body,path
    else:path.write_bytes(body)


def module(path,name):
    """
    機能: 固定した過去の入力生成Sourceを別名で読み込む。
    引数: path(Path),name(str)。
    返り値: moduleは読み込んだ実装。
    """
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec)
    sys.modules[name]=value;spec.loader.exec_module(value);return value


def run(name,command):
    """
    機能: 既存の非金融CLIを順次実行し、終了状態とログを保存する。
    引数: name(str),command(list[str])。
    返り値: None。シェル連結は使わない。
    """
    stdout=DEST/(name+'_stdout.txt');stderr=DEST/(name+'_stderr.txt')
    with stdout.open('x',encoding='utf-8') as out,stderr.open('x',encoding='utf-8') as err:
        result=subprocess.run(command,cwd=ROOT,stdout=out,stderr=err,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    assert result.returncode==0,(name,stderr.read_text(encoding='utf-8')[-3000:])
    print(json.dumps({'段階完了':name},ensure_ascii=False),flush=True)


def freeze():
    """
    機能: 追加2場の使用方針、原板、生成Sourceを金融なしで固定する。
    引数: なし。
    返り値: dictは固定入力計画。
    """
    paths=[Path(__file__),ROOT/'scripts/複合検証/データ準備.py',INDEX,BRIDGE]
    for name in ('work/未見入口の同体接続/接続器の停止.json','work/166可変場の観測/可変場観測の停止.json','work/166可変場の数値化/数値化の停止.json'):
        p=ROOT/name;stop=read(p);assert stop['成功'];paths.append(p)
        for item in stop['Source']:
            source=ROOT/item['path'];assert ref(source)['sha256']==item['sha256'];paths.append(source)
    sources=[ref(p) for p in sorted(set(paths))];inputs=[]
    for product in PRODUCTS:
        for scene in SCENES:
            folder=DATA/product/scene
            raw=folder/('book.jsonl.gz' if (folder/'book.jsonl.gz').exists() else 'book.jsonl')
            inputs.append({'product':product,'session':scene,'raw':ref(raw),
                'csv_1m':ref(folder/'candle_1min.csv'),'csv_5m':ref(folder/'candle_5min.csv')})
    value={'trial':194,'対象':list(SCENES),'商品':list(PRODUCTS),'確認日':'2026-11-18','Source':sources,'inputs':inputs,
        '金融未実行':True,'選択方針':'192/193までの旧81場による候補・前48/全80選択を封印した後だけ追加2場を適用。追加2場の結果から候補を差し替えない。',
        '旧固定対照':'NK旧183基準/191 R1 SWITCH C120、TOPIX190 D4/N01。正式IDとSourceは金融前の候補封印へ固定する。',
        '結果区分':'追加2場は今回探索で未参照の固定適用。わずか2場を長期安定性の証明としない。結果を読んだ後は既使用扱い。',
        '不変':'単純IFD、保有/予約合計1、終了15分前決済、同費用。原板と既存81場は上書きしない。'}
    save(TRIAL/'入力生成前の方針.json',value);return value


def quantity(spec):
    """
    機能: 同じ8列パーサで追加4原板を恒久変換する。
    引数: spec(dict)は固定計画。
    返り値: None。損益と候補の適否は計算しない。
    """
    parser=module(ROOT/'scripts/複合検証/データ準備.py','旧8列194');records=[]
    for entry in spec['inputs']:
        source=Path(entry['raw']['path']);assert ref(source)==entry['raw']
        target=DEST/'原順8列'/entry['product']/(entry['session']+'.npz');memo=target.with_suffix('.json')
        if memo.exists():
            record=read(memo);assert ref(target)['sha256']==record['sha256_cache']
        else:
            assert not target.exists();target.parent.mkdir(parents=True,exist_ok=True)
            record=parser.build_one(source,target,entry['product'],entry['session'],source.parents[2])
            record.update(cache_absolute=str(target),current_raw=entry['raw']);save(memo,record)
        assert ref(source)==entry['raw'];records.append(record)
        print(json.dumps({'非金融8列':entry['product'],'場':entry['session'],'原行':record['raw_lines'],'状態':record['events']},ensure_ascii=False),flush=True)
    save(DEST/'原順8列/入力台帳.json',{'成功':True,'金融未生成':True,'entries':records,'Source':spec['Source']})


def nk_population(spec):
    """
    機能: 180までの前史8場を継承し、追加2場だけの100特徴母集団を作る。
    引数: spec(dict)は原板とSourceの金融前固定。
    返り値: None。前史8場が旧正本と同体であることも確認する。
    """
    output=DEST/'NK225';output.mkdir(parents=True,exist_ok=True)
    if (output/'完了.json').exists():return
    scenes=[]
    for e in spec['inputs']:
        if e['product']!='NK225':continue
        d=datetime.fromisoformat(e['session'][:10]).replace(tzinfo=JST)
        day=e['session'].endswith('Day');start=d+timedelta(hours=8,minutes=45) if day else d+timedelta(hours=17)
        end=d+timedelta(hours=15,minutes=45) if day else d+timedelta(days=1,hours=6)
        raw=Path(e['raw']['path'])
        scene={'session':e['session'],'contract':'161120018','start':start.timestamp(),'end':end.timestamp(),
            'force_close':end.timestamp()-600,'raw':e['raw'],'expected_raw_stat':{'bytes':raw.stat().st_size,'mtime_ns':raw.stat().st_mtime_ns},
            'expected_accepted':0,'expected_quality':None,'entries':[]}
        scenes.append(scene)
    fixed=output/'索引前の空取得入力.json';save(fixed,{'trial':194,'scenes':scenes,'expected_entry_count':0})
    index_dir=output/'原板数値索引'
    if not (index_dir/'manifest.json').exists():
        run('NK原板索引',[str(INDEX),'--mode','index','--input',str(fixed),'--sha256',ref(fixed)['sha256'],'--output-dir',str(index_dir),'--workers','2'])
    measured=read(index_dir/'manifest.json');assert measured['success'] and len(measured['scenes'])==2
    for scene,item in zip(scenes,measured['scenes']):
        assert item['success'] and item['session']==scene['session'] and item['contract']==scene['contract']
    old_folder=ROOT/'inputs/00180_20261116デイの固定適用入力'
    old=read(old_folder/'母集団接続計画.json');previous=copy.deepcopy(old['scenes'])
    old_index=read(old_folder/'前史七場と本日の索引参照.json');combined=copy.deepcopy(old_index['scenes'])
    additions=[]
    for scene,item in zip(scenes,measured['scenes']):
        e=next(e for e in spec['inputs'] if e['product']=='NK225' and e['session']==scene['session'])
        target={k:scene[k] for k in ('session','contract','start','end','force_close','raw')}
        target.update(expected_accepted=item['rows'],expected_quality=item['quality'],csv_1m=e['csv_1m'],csv_5m=e['csv_5m'],quote_index=ref(index_dir/item['index']['path']))
        record=copy.deepcopy(item);record['index']['path']=target['quote_index']['path'];combined.append(record);additions.append(target)
    manifest=output/'前史八場と追加二場の索引参照.json';save(manifest,{'success':True,'trial':194,'scenes':combined,'価格索引複製なし':True})
    plan=output/'母集団接続計画.json';save(plan,{'version':1,'trial':194,'transport':'index48','history_through':old['history_through'],
        'history_plan':old['history_plan'],'prior_publications':old['prior_publications'],'index_manifest':ref(manifest),'scenes':previous+additions})
    population=HERE/'前史八場と追加二場の母集団'
    if not (population/'完了.json').exists():
        run('NK非金融母集団',[str(BRIDGE),'--execute-after-f0','--plan',str(plan),'--plan-sha',ref(plan)['sha256'],'--plan-bytes',str(ref(plan)['bytes']),'--output',str(population)])
    complete=read(population/'完了.json');assert complete['success'] and not complete['financial_labels_used']
    names=('出生台帳.json.gz','当時特徴.json.gz','取得対応.json.gz','物理取得.json.gz','固定取得入力.json.gz');prefix=[]
    old7=ROOT/'inputs/00167_追加七場の入口と共用価格索引/入口母集団';old1=old_folder/'入口母集団'
    directory=output/'入口母集団'
    for name in names:
        full=read(population/name);body=copy.deepcopy(full)
        key='scenes' if name=='固定取得入力.json.gz' else 'cases' if name=='物理取得.json.gz' else 'rows'
        expected=read(old7/name)[key]+read(old1/name)[key]
        prior=[r for r in full[key] if r['session'] not in SCENES]
        assert prior==expected,('旧八場差',name)
        body[key]=[r for r in full[key] if r['session'] in SCENES]
        if name=='出生台帳.json.gz':body['scenes']=[r for r in full['scenes'] if r['session'] in SCENES]
        if name=='固定取得入力.json.gz':body['expected_entry_count']=sum(len(s['entries']) for s in body['scenes'])
        body['counts']={'追加二場へ射影':True,'対象':list(SCENES),'金融ラベル未入力':True};save(directory/name,body)
        prefix.append({'file':name,'旧八場同体':True,'旧数':len(prior),'追加数':len(body[key])})
    save(directory/'完了.json',{'success':True,'trial':194,'financial_labels_used':False,'strategy_selected':False,
        'counts':{'features':len(read(directory/'当時特徴.json.gz')['rows'])},'files':{name:ref(directory/name) for name in names},'旧八場同体':prefix})
    assert all(ref(Path(r['path']))==r for r in spec['Source'])
    save(output/'完了.json',{'成功':True,'対象':list(SCENES),'金融未生成':True,'旧八場同体':prefix,
        'index':ref(index_dir/'manifest.json'),'母集団':ref(directory/'完了.json'),'Source':spec['Source']})
    print(json.dumps({'NK純生成':True,'旧8場同体':True,'追加特徴':read(directory/'完了.json')['counts']['features']},ensure_ascii=False),flush=True)


def main():
    """
    機能: 方針固定後、量8列とNK母集団の非金融準備を実行する。
    引数: CLI --quantity又は--nk。未指定時は方針だけ固定。
    返り値: None。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--quantity',action='store_true');parser.add_argument('--nk',action='store_true')
    args=parser.parse_args();spec=freeze();DEST.mkdir(parents=True,exist_ok=True)
    if args.quantity:quantity(spec)
    if args.nk:nk_population(spec)


if __name__=='__main__':main()
