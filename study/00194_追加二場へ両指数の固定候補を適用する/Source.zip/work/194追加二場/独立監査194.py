"""194の9packを、評価器を呼ばず原BBO走査・別枠再生・別集計で検査する。"""
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
import argparse
import gzip
import hashlib
import json
import math
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
DEST = ROOT / 'inputs/00194_20261116夜と1117昼の固定適用入力'
TRIAL = ROOT / 'study/00194_追加二場へ両指数の固定候補を適用する'
SCENES = ('2026-11-16_Night', '2026-11-17_Day')
sys.path.insert(0, str(ROOT / 'work/179固定結果の独立検査'))
import scan179 as S
sys.path.insert(0, str(ROOT / 'work/183損失安定性'))
import TOPIXを独立検算する as T


def read(path: Path) -> object:
    """
    機能: 既存のJSON又はgzip正本を読む。
    引数: path(Path)は読取対象。
    返り値: objectは保存値。正本は変更しない。
    """
    body = path.read_bytes()
    return json.loads(gzip.decompress(body) if path.suffix == '.gz' else body)


def ref(path: Path) -> dict:
    """
    機能: 読取対象の物理指紋を計算する。
    引数: path(Path)は入力又はSource。
    返り値: dictは相対path・bytes・SHA256。
    """
    path = path.resolve()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size, 'sha256': digest}


def verify_ref(saved: dict) -> bool:
    """
    機能: 絶対/相対pathの既存指紋を、格納表記に依存せず照合する。
    引数: saved(dict)はpath/bytes/sha256。
    返り値: boolは一致。後から作った票を事前封印とは扱わない。
    """
    path = Path(saved['path'])
    if not path.is_absolute():
        path = ROOT / path
    actual = ref(path)
    assert actual['bytes'] == saved['bytes'] and actual['sha256'] == saved['sha256'], str(path)
    return True


def key(quote: dict) -> tuple:
    """
    機能: 原行時計を辞書順比較できる形へ変換する。
    引数: quote(dict)はtime/index/source_line。
    返り値: tupleは時刻・索引・原行。
    """
    return quote['time'], quote['index'], quote['source_line']


def phase(scene: str, at: float) -> int:
    """
    機能: q0時点をデイ・NY09:30前・以後へ独立分類する。
    引数: scene(str)、at(float)は価格時計。
    返り値: intはDAY0/PRE1/POST2。夏冬をNY地域時計で変換する。
    """
    if scene.endswith('_Day'):
        return 0
    start = T.bounds(scene)[0]
    local = datetime.fromtimestamp(start, ZoneInfo('America/New_York'))
    boundary = local.replace(hour=9, minute=30, second=0, microsecond=0).timestamp()
    return 1 if at < boundary else 2


def target_quote(targets: dict, symbol: str, scene: str, line: int, at: float, bid: float, ask: float) -> None:
    """
    機能: 実JSONLへ照合する採用原行の時刻と両側価格を蓄積する。
    引数: targets(dict)、symbol/scene(str)、line(int)、at/bid/ask(float)。
    返り値: None。同じ行に矛盾する期待値を許さない。
    """
    expected = (float(at), float(bid), float(ask))
    prior = targets[(symbol, scene)].setdefault(int(line), expected)
    assert prior == expected


def nk_audit(packs: list, targets: dict) -> dict:
    """
    機能: NK全q0を独自の予約/保有1枠で走査し、全取得を独立scan179へ照合する。
    引数: packs(list[dict])は固定4案、targets(dict)は原板照合対象。
    返り値: dictは全要求・取得・金融属性の一致数。early179やengine173は呼ばない。
    """
    folder = DEST / 'NK225/入口母集団'
    fixed = read(folder / '固定取得入力.json.gz')
    features = read(folder / '当時特徴.json.gz')['rows']
    captures = {row['event_id']: row for row in read(folder / '取得対応.json.gz')['rows']}
    entries = sorted([row for scene in fixed['scenes'] for row in scene['entries']], key=lambda row: row['id'])
    case_map = {row['id']: i for i, row in enumerate(entries)}
    axes = read(ROOT / 'work/163任意幅Raw索引/観測条件の雛形.json')
    horizons = axes['horizons']
    manifest_path = DEST / 'NK225/原板数値索引/manifest.json'
    manifest = read(manifest_path)
    records = {}
    for row in manifest['scenes']:
        path = manifest_path.parent / row['index']['path']
        assert ref(path)['sha256'] == row['index']['sha256']
        raw = gzip.decompress(path.read_bytes())
        assert raw[:8] == b'NQIDX163' and len(raw) == 8 + 48 * row['rows']
        records[row['session']] = np.frombuffer(raw, S.RECORD, offset=8)
    cache = {}
    checks = requests_count = acquired = 0
    with np.load(HERE / 'NK追加2純出生.npz', allow_pickle=False) as archive:
        born = {k: archive[k].copy() for k in archive.files}
    for pack in packs:
        identity = pack['policy']['entry']
        arrays = {k: born[identity + '__birth__' + k] for k in ('core', 'branches', 'technical', 'tier')}
        mw, fw, his = [born[identity + '__' + k] for k in ('mw', 'fw', 'hi')]
        expected_requests = []
        expected_trades = []
        for si, scene in enumerate(fixed['scenes']):
            name = scene['session']; start, cut, submit = T.bounds(name)
            busy = None; first_fill = None; seen = set()
            for event, f in enumerate(features):
                if f['session'] != name:
                    continue
                quote = f['metadata']['q0']; now = key(quote)
                if now[0] >= submit:
                    continue
                if busy is not None and busy['release'] <= now:
                    busy = None
                ever = first_fill is not None and first_fill <= now
                core = int(arrays['core'][event])
                width = int(mw[event] if arrays['branches'][event] == 0 else fw[event])
                core = core if width > 0 else 0
                if core:
                    side = 0 if core == 1 else 1; origin = tier = 0
                    horizon = horizons[int(his[event])]
                elif arrays['technical'][event] and now[0] >= start + 2700 and not ever:
                    side = 0 if arrays['technical'][event] == 1 else 1
                    width = 200; origin = 2; tier = int(arrays['tier'][event])
                    horizon = next(row for row in horizons if row['id'] == 'H60')
                else:
                    continue
                held = busy is not None and busy['filled'] and busy['fill'] <= now
                pending = busy is not None and not held
                expected_requests.append({'event': event, 'scene_index': si, 'side': side, 'width': width,
                    'origin': origin, 'tier': tier, 'at': list(now),
                    'held_before': int(held and busy['side'] == side),
                    'pending_before': int(pending and busy['side'] == side),
                    'held_total_before': int(held), 'pending_total_before': int(pending),
                    'accepted': busy is None, 'skip_reason': 'held' if held else 'pending' if pending else None})
                if busy is not None:
                    continue
                capture = captures[f['event_id']]
                finish = key(capture['q1']) if capture['status'] == 'filled' else min(
                    (capture['expires'], math.inf, math.inf),
                    key(capture['terminated_at']) if capture['terminated_at'] else (math.inf, math.inf, math.inf))
                if finish[0] >= submit:
                    finish = (submit, math.inf, math.inf); filled = False
                else:
                    filled = capture['status'] == 'filled'
                if not filled or capture['case_id'] in seen:
                    busy = {'release': finish, 'filled': False, 'fill': finish, 'side': side}
                    continue
                seen.add(capture['case_id'])
                if first_fill is None:
                    first_fill = finish
                case = case_map[capture['case_id']]
                q1 = capture['q1']; entry_index = int(q1['index']); raw = records[name]
                assert all(raw[entry_index][k] == q1[k] for k in ('time', 'source_line', 'bid', 'ask', 'last'))
                request = (name, entry_index, side, width, horizon['id'])
                if request not in cache:
                    cache[request] = S.scan_one(raw, entry_index, scene['end'], width, horizon, side)
                result = cache[request]
                expected_trades.append((event, case, side, width, origin, tier, horizon['id'], result))
                busy = {'release': (result['exit_time'] if result['known'] else cut, math.inf, math.inf),
                        'filled': True, 'fill': finish, 'side': side}
        assert pack['engine']['requests'] == expected_requests, (pack['id'], '全q0要求相違')
        requests_count += len(expected_requests)
        ledger = pack['ledger']
        assert len(expected_trades) == len(ledger['net']) == len(pack['positions'])
        for i, (event, case, side, width, origin, tier, horizon, result) in enumerate(expected_trades):
            scene = features[event]['session']; raw = records[scene]
            for name, value in {'event': event, 'case': case, 'case_id': entries[case]['id'], 'side': side,
                'width': width, 'origin': origin, 'horizon': horizon, 'phase': phase(scene, features[event]['metadata']['q0']['time'])}.items():
                checks += T.V.check_equal(ledger[name][i], value, (pack['id'], i, name))
            for name in ('known', 'label', 'status', 'forced', 'exit_time', 'exit_index', 'exit_line', 'exit_price', 'net'):
                checks += T.V.check_equal(ledger[name][i], result[name], (pack['id'], i, name))
            audit = result['audit']
            for name in ('entry_index', 'entry_time', 'entry_line', 'entry_price'):
                checks += T.V.check_equal(ledger[name][i], audit[name], (pack['id'], i, name))
            checks += T.V.check_equal(pack['positions'][i]['confirmed_until'], result['holding_confirmed_until'], (pack['id'], i, '保有下限'))
            assert pack['positions'][i]['quantity'] == 1
            for at in (ledger['entry_index'][i], ledger['exit_index'][i]):
                if at >= 0:
                    row = raw[at]
                    target_quote(targets, 'NK225', scene, row['source_line'], row['time'], row['bid'], row['ask'])
            acquired += 1
    return {'候補': len(packs), '取得': acquired, '全q0要求': requests_count,
            '金融等照合属性': checks, '独立逐次金融条件': len(cache), '枠': '保有と予約合計1・同秒決済は秒末解放'}


def topix_audit(packs: list, entries: list, targets: dict, condition: dict) -> dict:
    """
    機能: 192独立監査のBBO走査とTTL予約再生を追加2場の固定5案へ適用する。
    引数: packs/entries(list[dict])、targets(dict)、condition(dict)は固定条件。
    返り値: dictは取得・全q0枠・金融照合数。Route.cellや金融評価器は呼ばない。
    """
    pure = read(HERE / 'TOPIX追加2純出生.json.gz')
    full = {(r['session'], r['time'], r['line']): r for r in read(DEST / 'TOPIX/純入口192追加二場.json.gz')}
    by = defaultdict(list)
    for row in pure:
        by[row['session']].append(row)
        original = full[(row['session'], row['time'], row['line'])]
        for field in ('signals', 'widths', 'origins'):
            assert row[field] == [original[field][i] for i in condition['TOPIX候補index']]
    order = {int(pack['id'].split('_I')[1][:2]): pack for pack in packs}
    count = slots = acquired = 0
    for entry in entries:
        if entry['symbol'] != 'TOPIX':
            continue
        scene = entry['session']; start, end, force = T.bounds(scene)
        path = Path(entry['cache_absolute']); assert ref(path)['sha256'] == entry['sha256_cache']
        with np.load(path, allow_pickle=False) as archive:
            raw = {k: archive[k] for k in ('now', 'line', 'bid', 'ask', 'valid')}
        times = raw['now']; finite = np.isfinite(times)
        prior = np.maximum.accumulate(np.where(finite, times, -np.inf))
        mask = finite & (times >= start) & (times < end) & (times >= prior) & raw['valid']
        arrays = {k: v[mask] for k, v in raw.items() if k != 'valid'}
        cache = {}
        for ci, identity in enumerate(condition['TOPIX候補index']):
            pack = order[identity]; ledger = pack['ledger']
            ids = [i for i, name in enumerate(ledger['scene']) if name == scene]
            cursor = 0; busy = -math.inf; pending = False
            diagnostic = {'純成立': 0, '保有棄却': 0, '予約棄却': 0, '取得': 0, '失効': 0}
            for row in by[scene]:
                side = row['signals'][ci]
                if not side:
                    continue
                diagnostic['純成立'] += 1; slots += 1
                if row['time'] <= busy:
                    diagnostic['予約棄却' if pending else '保有棄却'] += 1
                    continue
                cell_key = (row['time'], side, row['widths'][ci])
                if cell_key not in cache:
                    first = int(np.searchsorted(arrays['now'], row['time'] + 1))
                    fillable = first < len(arrays['now']) and arrays['now'][first] <= min(row['time'] + 30, force) and arrays['now'][first] < force
                    cache[cell_key] = T.financial_oracle(arrays, scene, *cell_key) if fillable else None
                cell = cache[cell_key]
                if cell is None:
                    diagnostic['失効'] += 1; busy = min(row['time'] + 30, force); pending = True
                    continue
                assert cursor < len(ids), (pack['id'], scene, '未記録取得')
                i = ids[cursor]; cursor += 1; acquired += 1; diagnostic['取得'] += 1
                for field, value in cell.items():
                    actual = pack['positions'][i][field] if field == 'confirmed_until' else ledger[field][i]
                    count += T.V.check_equal(actual, value, (pack['id'], scene, i, field))
                for field, value in {'request_time': row['time'], 'request_line': row['line'], 'side': side,
                    'width': row['widths'][ci], 'origin': row['origins'][ci], 'phase': phase(scene, row['time'])}.items():
                    count += T.V.check_equal(ledger[field][i], value, (pack['id'], scene, i, field))
                original = full[(scene, row['time'], row['line'])]
                for field in ('quantity_last_line', 'price_last_line'):
                    assert original['extra'][field] is None or original['extra'][field] <= row['line']
                for field in ('entry_line', 'exit_line'):
                    line = ledger[field][i]
                    if line is not None:
                        at = int(np.searchsorted(arrays['line'], line))
                        assert at < len(arrays['line']) and arrays['line'][at] == line
                        target_quote(targets, 'TOPIX', scene, line, arrays['now'][at], arrays['bid'][at], arrays['ask'][at])
                busy = ledger['exit_time'][i] if ledger['known'][i] else end; pending = False
            assert cursor == len(ids), (pack['id'], scene, '余分取得')
            expected = next(r for r in pack['diagnostics'] if r['scene'] == scene)
            assert expected == {'scene': scene, **diagnostic}
    return {'候補': len(packs), '取得': acquired, '全q0枠判定': slots, '金融等照合属性': count,
            '枠': '保有とTTL30秒予約合計1・未知は場末占有'}


def raw_audit(entries: list, targets: dict) -> dict:
    """
    機能: 4原JSONLを一度ずつ読んで全SHAと取引原行の時計/BBOを独立照合する。
    引数: entries(list[dict])は原板台帳、targets(dict)は全候補の取得/決済行。
    返り値: dictは原本数と全採用行一致数。Buy1をBid、Sell1をAskとして読む。
    """
    checks = []
    for entry in entries:
        path = Path(entry['current_raw']['path']); selected = targets[(entry['symbol'], entry['session'])]
        digest = hashlib.sha256(); found = set(); bytes_read = 0
        with path.open('rb') as stream:
            for line_no, raw in enumerate(stream, 1):
                digest.update(raw); bytes_read += len(raw)
                if line_no not in selected:
                    continue
                row = json.loads(raw)
                actual = (datetime.fromisoformat(row['CurrentPriceTime']).timestamp(), row['Buy1']['Price'], row['Sell1']['Price'])
                expected = selected[line_no]
                assert actual == expected, (entry['symbol'], entry['session'], line_no, actual, expected)
                found.add(line_no)
        assert found == set(selected)
        assert digest.hexdigest() == entry['current_raw']['sha256'] == entry['sha256_uncompressed']
        assert bytes_read == entry['current_raw']['bytes']
        checks.append({'商品': entry['symbol'], '場': entry['session'], '照合原行': len(found), '原本SHA一致': True})
    return {'4原本全SHA': len(checks), '全採用原行': sum(r['照合原行'] for r in checks), '場別': checks}


def main() -> None:
    """
    機能: root金融完了GO後に9pack全体を独立検査し、金融後監査票として保存する。
    引数: CLI --audit(bool)は明示実行。未指定はSource表示のみ。
    返り値: None。新候補選択・金融正本変更・事前封印の書換えを行わない。
    """
    parser = argparse.ArgumentParser(); parser.add_argument('--audit', action='store_true'); args = parser.parse_args()
    if not args.audit:
        print(json.dumps({'監査Source': ref(Path(__file__)), '金融後の監査専用': True}, ensure_ascii=False)); return
    condition = read(TRIAL / '条件.json'); marker = read(HERE / '金融開始前固定.json')
    assert verify_ref(marker['条件']) and verify_ref(marker['全候補純封印'])
    assert tuple(condition['期間']) == SCENES
    bound = condition['Sourceと参照'] + condition['純出生']
    assert all(verify_ref(row) for row in bound)
    prior = read(HERE / 'NK金融接続前の検査194.json')
    assert prior['成功'] and prior['金融未実行'] and all(verify_ref(row) for row in prior['Source'])
    raw_ledger = read(DEST / '原順8列/入力台帳.json'); entries = raw_ledger['entries']
    assert {(r['symbol'], r['session']) for r in entries} == {(s, p) for s in ('NK225', 'TOPIX') for p in SCENES}
    assert all(ref(Path(row['cache_absolute']))['sha256'] == row['sha256_cache'] for row in entries)
    stats_path = HERE / '追加二場安定性.json.gz'; states = read(stats_path)['metrics']
    paths = [HERE / '金融正本' / (state['id'] + '.json.gz') for state in states]
    before = [ref(path) for path in [stats_path, TRIAL / '条件.json', HERE / '金融開始前固定.json', *paths]]
    packs = [read(path) for path in paths]
    assert len(packs) == len({p['id'] for p in packs}) == 9
    nk = [p for p in packs if p['id'].startswith('NK225')]; tp = [p for p in packs if p['id'].startswith('TOPIX')]
    assert {p['policy']['entry'] for p in nk} == set(condition['NK候補']) and len(nk) == 4 and len(tp) == 5
    group_checks = 0; unknown = 0; no_trade = []
    for pack, state in zip(packs, states, strict=True):
        assert tuple(s['scene'] for s in pack['sessions']) == SCENES
        assert len(pack['positions']) == len(pack['ledger']['net'])
        for session in pack['sessions']:
            start, cut, _ = T.bounds(session['scene'])
            assert session['start'] == start and session['end'] == cut
        for i, known in enumerate(pack['ledger']['known']):
            if not known:
                unknown += 1
                assert all(pack['ledger'][k][i] is None for k in ('net', 'exit_time', 'exit_price'))
            else:
                scene = pack['ledger']['scene'][i]
                assert pack['ledger']['entry_time'][i] <= pack['ledger']['exit_time'][i] <= T.bounds(scene)[1]
        if not pack['ledger']['net']:
            no_trade.append(pack['id'])
        group_checks += T.inspect_groups(pack, state)
    targets = defaultdict(dict)
    nk_result = nk_audit(nk, targets)
    tp_result = topix_audit(tp, entries, targets, condition)
    originals = raw_audit(entries, targets)
    assert all(verify_ref(row) for row in before)
    directly_bound = {str(Path(row['path']).resolve()) for row in bound}
    missing = [r for r in prior['Source'] if str((ROOT / r['path']).resolve()) not in directly_bound]
    result = {'成功': True, '監査時点': '金融完了後・root GO後。事前封印とは称さない。',
        '候補': 9, '全候補で2場を保持': True, '未知取得': unknown, '0取引候補': no_trade,
        'NK': nk_result, 'TOPIX': tp_result, '原JSONL': originals, '独立集計照合属性': group_checks,
        '金融正本と条件不変': True, '固定正本': before, '検査Source': [ref(Path(__file__)), ref(Path(S.__file__)), ref(Path(T.__file__)), ref(Path(T.V.__file__))],
        '金融前に存在したNK検査票のSource照合': {'票': ref(HERE / 'NK金融接続前の検査194.json'), '一致': True,
            '194条件へ直接列挙されていなかったSource': missing},
        '限界': ['約定代用の実装・原行・費用を検査したもので、受信時刻や実注文の成立を保証しない。',
                  '194条件に直接列挙されていない依存を、金融後に新たな事前封印として追加していない。',
                  '全9案で未知取得が0のため、今回自然結果だけで未知経路全分岐の正しさを証明しない。']}
    output = HERE / '独立監査194.json'
    if output.exists():
        assert read(output) == result
    else:
        output.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    print(json.dumps({k: result[k] for k in ('成功', '候補', '未知取得', 'NK', 'TOPIX', '原JSONL', '独立集計照合属性')}, ensure_ascii=False), flush=True)


# ----------------------------------------
if __name__ == '__main__':
    main()
