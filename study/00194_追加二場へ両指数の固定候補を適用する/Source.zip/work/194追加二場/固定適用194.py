"""旧81場だけで選んだ両指数9候補を、追加2場へ条件固定で適用する。"""
from pathlib import Path
from collections import defaultdict
import argparse
import gzip
import json
import math
import sys
import numpy as np
import 入力194 as I
import NK純接続194 as N

ROOT=I.ROOT;HERE=Path(__file__).parent;TRIAL=I.TRIAL
NK_SELECTION=ROOT/'study/00193_構造拡大停止と順行取得位置を確認する/追加二場参照前の固定選択.json'
TP_SELECTION=ROOT/'work/192TOPIX/追加二場前の固定選択.json'
sys.path.insert(0,str(ROOT/'work/193構造拡大停止と取得位置'))
import rules193 as R
sys.path.insert(0,str(ROOT/'work/192TOPIX'))
import 入口192 as T
import 金融を比較する as F


def safe(value):
    """
    機能: NumPy値をJSON型にし、非有限の未知をNoneへ保存する。
    引数: value(object)。
    返り値: objectはJSON互換値。
    """
    if isinstance(value,dict):return {str(k):safe(v) for k,v in value.items()}
    if isinstance(value,(list,tuple,np.ndarray)):return [safe(v) for v in value]
    if isinstance(value,np.bool_):return bool(value)
    if isinstance(value,np.integer):return int(value)
    if isinstance(value,(float,np.floating)):return float(value) if math.isfinite(value) else None
    return value


def references():
    """
    機能: この適用が使う固定条件・入力・生成Sourceを列挙する。
    引数: なし。
    返り値: list[dict]は内容指紋。取引の成績で選別しない。
    """
    paths=[Path(__file__),Path(N.__file__),Path(R.__file__),Path(T.__file__),Path(F.__file__),
        HERE/'NK金融接続194.py',HERE/'TOPIX純接続194.py',NK_SELECTION,TP_SELECTION,
        I.DEST/'TOPIX/純出生の同体確認.json',I.DEST/'NK225/固定基準の純接続/純接続完了194.json',
        ROOT/'work/193構造拡大停止と取得位置/全純入口の封印.json',ROOT/'work/192TOPIX/条件.json']
    for module in list(sys.modules.values()):
        filename=getattr(module,'__file__',None)
        if filename:
            path=Path(filename).resolve()
            if path.suffix=='.py' and path.is_relative_to(ROOT) and 'site-packages' not in path.parts:paths.append(path)
    return [I.ref(p) for p in sorted(set(paths))]


def pure():
    """
    機能: 既選択候補だけの追加2場の純出生を封印し、金融へ渡す条件を固定する。
    引数: なし。
    返り値: None。結果を見て選択を入れ替えない。
    """
    nk=I.read(NK_SELECTION);tp=I.read(TP_SELECTION)
    nk_ids=nk['194固定適用候補'];tp_ids=tp['194参考index']
    assert nk_ids==['E193_00','E193_01','E193_02','E193_04'] and tp_ids==[0,4,20,29,56]
    cfg=I.read(ROOT/'work/192TOPIX/条件.json');assert all(T.M.sha(ROOT/p)==sha for p,sha in cfg['Source'].items())
    pure_n=N.load_pure_leg();pure_n['features'].q0_prices=N.load_q0(pure_n)
    built=R.build(pure_n['features'],pure_n['baselines']['全期_J035'],candidate_ids=nk_ids)
    payload={}
    for name,bundle in built['bundles'].items():
        for key in ('mw','fw','hi','added'):payload[name+'__'+key]=bundle[key]
        for key,value in bundle['birth'].items():payload[name+'__birth__'+key]=value
    target=HERE/'NK追加2純出生.npz'
    if target.exists():
        with np.load(target,allow_pickle=False) as old:
            assert set(old.files)==set(payload)
            for key in payload:np.testing.assert_array_equal(old[key],payload[key])
    else:np.savez_compressed(target,**payload)
    I.save(HERE/'NK追加2純診断.json.gz',safe(built['diagnostics']))
    allrows=I.read(I.DEST/'TOPIX/純入口192追加二場.json.gz');rows=[]
    for row in allrows:
        subset={k:v for k,v in row.items() if k not in ('signals','widths','origins','extra')}
        for field in ('signals','widths','origins'):subset[field]=[row[field][i] for i in tp_ids]
        rows.append(subset)
    I.save(HERE/'TOPIX追加2純出生.json.gz',rows)
    condition={'試行':194,'期間':list(I.SCENES),'旧期間':'旧81場は既使用。追加2場は今回の選択・探索へ未使用。',
        'NK候補':nk_ids,'TOPIX候補index':tp_ids,'TOPIX候補名':[T.NAMES[i] for i in tp_ids],
        '選択':{'NK':nk,'TOPIX':tp},'候補を合成しない':True,
        '未知と参加':'0取得の場を残し、未知を0円としない。追加2場だけで安定性を証明しない。',
        '金融':'各商品の固定単純IFD・幅/期限・費用・実BBO代用を継承。保有/予約1、終了15分前。',
        'Sourceと参照':references(),
        '純出生':[I.ref(target),I.ref(HERE/'TOPIX追加2純出生.json.gz')],'金融開封前':True}
    I.save(TRIAL/'条件.json',condition)
    I.save(HERE/'全候補純封印.json',{'成功':True,'金融前':True,'条件':I.ref(TRIAL/'条件.json'),'候補9':True})
    print(json.dumps({'金融前封印':True,'NK候補':4,'TOPIX候補':5,'追加場':list(I.SCENES)},ensure_ascii=False),flush=True)


def topix_finance(condition):
    """
    機能: TOPIX固定5候補を同じRouteと保有/予約1枠で再生する。
    引数: condition(dict)は金融前の固定候補。
    返り値: list[dict]は全2場を残した候補別pack。
    """
    entries=[e for e in I.read(I.DEST/'原順8列/入力台帳.json')['entries'] if e['symbol']=='TOPIX']
    meta=F.sessions(entries);by=defaultdict(list)
    for row in I.read(HERE/'TOPIX追加2純出生.json.gz'):by[row['session']].append(row)
    packs=[]
    for i,name in zip(condition['TOPIX候補index'],condition['TOPIX候補名']):
        pack=F.empty(f'TOPIX194_I{i:02d}_{name}_DayA25_NightW15_H60',meta)
        pack['ledger']['origin']=[];packs.append(pack)
    for entry in entries:
        route=T.M.Route(entry);cache={}
        for ci,pack in enumerate(packs):
            busy=-math.inf;pending=False;counts={'純成立':0,'保有棄却':0,'予約棄却':0,'取得':0,'失効':0}
            for row in by[entry['session']]:
                side=row['signals'][ci]
                if not side:continue
                counts['純成立']+=1
                if row['time']<=busy:counts['予約棄却' if pending else '保有棄却']+=1;continue
                w=row['widths'][ci];assert w is not None;key=(row['time'],row['line'],side,w)
                if key not in cache:cache[key]=route.cell(*key)
                cell=cache[key]
                if cell is None:counts['失効']+=1;busy=min(row['time']+30,route.force);pending=True;continue
                counts['取得']+=1;F.append(pack,dict(cell,origin=row['origins'][ci]));busy=route.end if cell['unknown'] else cell['exit_time'];pending=False
            pack['diagnostics'].append({'scene':entry['session'],**counts})
    return packs


def finance():
    """
    機能: 両商品の全候補封印を検査してから、追加2場の金融を一度開封する。
    引数: なし。
    返り値: None。成績による再選択は行わない。
    """
    import NK金融接続194 as NF
    sys.path.insert(0,str(ROOT/'work/181反省を分解した改善'))
    import 集計181 as A
    condition=I.read(TRIAL/'条件.json');seal=I.read(HERE/'全候補純封印.json')
    assert seal['金融前'] and seal['条件']==I.ref(TRIAL/'条件.json')
    assert all(I.ref(Path(r['path']))==r for r in condition['Sourceと参照']+condition['純出生'])
    marker=HERE/'金融開始前固定.json';assert not marker.exists()
    I.save(marker,{'条件':I.ref(TRIAL/'条件.json'),'全候補純封印':I.ref(HERE/'全候補純封印.json')})
    pure_n=N.load_pure_leg();unvalued=NF.load_unvalued_context(pure_n)
    context=unvalued['context'] if isinstance(unvalued,dict) else unvalued
    loaded=NF.attach_financial(context)
    context=loaded['context'] if isinstance(loaded,dict) else loaded
    packs=[]
    with np.load(HERE/'NK追加2純出生.npz',allow_pickle=False) as data:
        for name in condition['NK候補']:
            bundle={k:data[name+'__'+k].copy() for k in ('mw','fw','hi','added')}
            bundle['birth']={k:data[name+'__birth__'+k].copy() for k in ('core','branches','technical','tier')}
            policy={'id':f'NK225194_{name}__C0_IFD','entry':name,'exit':'C0_IFD'}
            packs.append(A.pack(context,bundle,policy,'追加2'))
    packs.extend(topix_finance(condition));stats=[];short=[]
    for pack in packs:
        I.save(HERE/'金融正本'/(pack['id']+'.json.gz'),safe(pack))
        stat=F.A.evaluate_pack(pack,{'追加2':list(I.SCENES)});stats.append(stat)
        short.append({'id':pack['id'],'groups':{b:F.terse(g) for b,g in stat['groups'].items()}})
    I.save(HERE/'追加二場安定性.json.gz',safe({'metrics':stats}));I.save(HERE/'追加二場短表.json',safe(short))
    assert all(I.ref(Path(r['path']))==r for r in condition['Sourceと参照']+condition['純出生'])
    print(json.dumps(safe(short),ensure_ascii=False),flush=True)


def main():
    """
    機能: 純候補の封印と金融適用を別引数で実行する。
    引数: CLI --pure又は--finance。
    返り値: None。
    """
    parser=argparse.ArgumentParser();group=parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--pure',action='store_true');group.add_argument('--finance',action='store_true');args=parser.parse_args()
    if args.pure:pure()
    else:finance()


if __name__=='__main__':main()
