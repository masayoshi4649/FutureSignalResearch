"""固定済み194を再計算し、全9台帳・集計の同体と実際の入力依存を確認する。"""
from pathlib import Path
import hashlib
import json
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).parent
OPENED=set()


def opened(event: str, args: tuple) -> None:
    """
    機能: 実行で参照したリポジトリ内資源のパスだけを記録する。
    引数: event(str)、args(tuple)はPythonの監査イベント。
    返り値: None。ファイルの内容や研究条件を変えない。
    """
    if event=='open' and args and isinstance(args[0],(str,bytes)):
        path=Path(args[0]).resolve()
        if path.is_relative_to(ROOT) and 'site-packages' not in path.parts and path.suffix!='.pyc':OPENED.add(path)


def digest(value: object) -> str:
    """
    機能: 固定保存と同じJSON表現の指紋を求める。
    引数: value(object)は金融又は集計の内容。
    返り値: strはSHA256。
    """
    return hashlib.sha256((json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode()).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 追加2場を条件変更なしで再生し、保存済み全結果と照合する。
    引数: なし。
    返り値: None。金融開始票と正本を上書きしない。
    """
    sys.addaudithook(opened)
    import 固定適用194 as D
    import NK金融接続194 as NF
    sys.path.insert(0,str(ROOT/'work/181反省を分解した改善'))
    import 集計181 as A
    condition=D.I.read(D.TRIAL/'条件.json')
    assert all(D.I.ref(Path(r['path']))==r for r in condition['Sourceと参照']+condition['純出生'])
    pure=D.N.load_pure_leg();context=NF.attach_financial(NF.load_unvalued_context(pure)['context'])['context']
    packs=[]
    with np.load(HERE/'NK追加2純出生.npz',allow_pickle=False) as data:
        for name in condition['NK候補']:
            bundle={k:data[name+'__'+k].copy() for k in ('mw','fw','hi','added')}
            bundle['birth']={k:data[name+'__birth__'+k].copy() for k in ('core','branches','technical','tier')}
            policy={'id':f'NK225194_{name}__C0_IFD','entry':name,'exit':'C0_IFD'}
            packs.append(A.pack(context,bundle,policy,'追加2'))
    packs.extend(D.topix_finance(condition));stats=[];short=[];checks=[]
    for pack in packs:
        actual=D.safe(pack);expected=D.I.read(HERE/'金融正本'/(pack['id']+'.json.gz'))
        assert digest(actual)==digest(expected),pack['id']
        stat=D.F.A.evaluate_pack(pack,{'追加2':list(D.I.SCENES)});stats.append(stat)
        short.append({'id':pack['id'],'groups':{b:D.F.terse(g) for b,g in stat['groups'].items()}})
        checks.append({'id':pack['id'],'全台帳同体':True,'内容SHA256':digest(actual)})
    for filename,value in (('追加二場安定性.json.gz',{'metrics':stats}),('追加二場短表.json',short)):
        assert digest(D.safe(value))==digest(D.I.read(HERE/filename)),filename
    sources=[]
    for module in list(sys.modules.values()):
        filename=getattr(module,'__file__',None)
        if filename:
            path=Path(filename).resolve()
            if path.is_relative_to(ROOT) and path.suffix=='.py' and 'site-packages' not in path.parts:sources.append(path)
    paths=sorted(set(sources)|{p for p in OPENED if p.is_file()})
    refs=[D.I.ref(p) for p in paths]
    proof={'成功':True,'独立検算とは別の同じ実装の再現':True,'全9台帳同体':checks,
           '全集計と短表同体':True,'実参照資源':refs}
    target=HERE/'再計算確認194.json'
    target.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    work=[r for r in refs if Path(r['path']).is_relative_to(ROOT/'work')]
    print(json.dumps({'再計算同体':9,'参照資源':len(refs),'work件数':len(work),'work総byte':sum(r['bytes'] for r in work),
        'work大きい順':sorted(work,key=lambda r:r['bytes'],reverse=True)[:8]},ensure_ascii=False))


# ----------------------------------------
if __name__=='__main__':main()
