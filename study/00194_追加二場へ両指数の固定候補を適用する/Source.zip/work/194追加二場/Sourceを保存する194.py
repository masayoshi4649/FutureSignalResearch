"""実参照した194の再計算・監査依存を、入力を複製せず正式ZIPへ保存する。"""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
TRIAL = ROOT / 'study/00194_追加二場へ両指数の固定候補を適用する'


def ref(path: Path) -> dict:
    """
    機能: 実ファイルの物理指紋を相対パス付きで返す。
    引数: path(Path)はリポジトリ内のファイル。
    返り値: dictはpath/bytes/sha256。
    """
    path = path.resolve()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size, 'sha256': digest}


def read(path: Path) -> dict:
    """
    機能: 日本語UTF-8の保存票を読む。
    引数: path(Path)はJSON。
    返り値: dictは保存内容。
    """
    return json.loads(path.read_text(encoding='utf-8'))


def main() -> None:
    """
    機能: 固定Sourceを変更せず、実参照依存と最低限の入力生成CLIを恒久保存する。
    引数: なし。
    返り値: None。原板・inputs・PythonライブラリのバイナリはZIPへ複製しない。
    """
    finance = read(HERE / '再計算確認194.json')
    audit = read(HERE / '監査参照確認194.json')
    plan = read(TRIAL / '入力生成前の方針.json')
    refs = finance['実参照資源'] + audit['参照'] + plan['Source']
    paths = set()
    for item in refs:
        path = Path(item['path']).resolve()
        assert path.is_relative_to(ROOT)
        actual = ref(path)
        assert actual['bytes'] == item['bytes'] and actual['sha256'] == item['sha256'], str(path)
        paths.add(path)
    paths.update([Path(__file__).resolve(), HERE / '再計算確認194.json', HERE / '監査参照確認194.json',
                  HERE / '独立監査194.json', HERE / '資料194.py', TRIAL / '入力生成前の方針.json',
                  ROOT / 'work/194隔離再現/復元実行を確認する.py'])
    inputs = sorted(p for p in paths if p.is_relative_to(ROOT / 'inputs'))
    dependencies = sorted(p for p in paths if p.is_relative_to(ROOT / 'work/pythonlibs'))
    archived = sorted(paths - set(inputs) - set(dependencies))
    members = [ref(path) for path in archived]
    target = TRIAL / 'Source.zip'
    with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path, item in zip(archived, members, strict=True):
            info = zipfile.ZipInfo(item['path'], date_time=(2026, 11, 18, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, path.read_bytes(), compresslevel=9)
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None
        assert archive.namelist() == [item['path'] for item in members]
        for item in members:
            data = archive.read(item['path'])
            assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256']
    prior_archive = ROOT / 'study/00167_固定した複合入口を追加七場へ適用する/再現資料/Source.zip'
    prior_members = []
    with zipfile.ZipFile(prior_archive) as archive:
        for item in plan['Source']:
            path = Path(item['path'])
            name = path.relative_to(ROOT).as_posix()
            if name in archive.namelist():
                raw = archive.read(name)
                if hashlib.sha256(raw).hexdigest() == item['sha256']:
                    prior_members.append(name)
    raw_inputs = [{'商品': row['product'], '場': row['session'], **row['raw']} for row in plan['inputs']]
    body = {'成功': True, '保存時点': '194金融後の再現用カプセル。金融前の固定票は内容を変えず同梱。',
        'archive': ref(target), 'members': members, 'member_count': len(members),
        '展開総byte': sum(row['bytes'] for row in members),
        '恒久入力参照': [ref(path) for path in inputs], '原板参照': raw_inputs,
        '外部ライブラリ': {'Python': '3.14.3 Windows x64', 'numpy': '2.5.4', 'orjson': '3.13.0',
            'tzdata': '2026.6', 'orjson旧参照の照合用ファイル': [ref(path) for path in dependencies],
            'ライブラリをZIPへコピーしない': True},
        '再現範囲': '恒久194母集団・固定純出生から9金融packと全集計を再計算。独立監査も同梱。',
        '入力生成': {'現物保存した実使用CLI': [row for row in members if row['path'].endswith('.exe')],
            'Sourceの既存恒久参照': ref(prior_archive), '同体確認member': prior_members,
            '未検証': '4原板と旧全履歴から194母集団を白紙再生成する経路は今回のカプセル検査対象外。'},
        '移転制約': '固定条件と一部台帳に元リポジトリの絶対pathが残る。別root完全独立再現とは主張しない。',
        '再計算票': ref(HERE / '再計算確認194.json'), '監査票': ref(HERE / '独立監査194.json'),
        '生成Source': ref(Path(__file__))}
    (TRIAL / 'Source索引.json').write_text(json.dumps(body, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, 'archive': body['archive'], 'member_count': len(members),
        '展開総byte': body['展開総byte'], '入力参照': len(inputs), '外部ライブラリ参照': len(dependencies)}, ensure_ascii=False), flush=True)


# ----------------------------------------
if __name__ == '__main__':
    main()
