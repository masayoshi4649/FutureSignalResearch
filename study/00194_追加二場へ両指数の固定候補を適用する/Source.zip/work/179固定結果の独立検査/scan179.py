"""179の一取得を原BBO行から逐次判定する独立検査。極値木やearly179を呼ばない。"""
from collections.abc import Mapping
import math
import numpy as np

RECORD=np.dtype({'names':['time','source_line','last','bid','ask','normal'],
    'formats':['<f8','<i8','<f8','<f8','<f8','<u8'],'offsets':[0,8,16,24,32,40],'itemsize':48})
CONFIG={'終了前秒':900,'決済要求余裕秒':60,'強制注文最小遅延秒':1,
    '価格BBO最大gap秒':300,'通常期限猶予秒':30,'1pt円':100,'往復手数料円':77,'往復追加滑り円':1000}


def normal(row: object) -> bool:
    """
    機能: 原行の正常BBOを独立に判定する。
    引数: row(object)はtime/bid/ask/normalを持つ構造化行。
    返り値: boolは正常旗と有限・正価格・Bid<Askの同時成立。
    """
    return bool(row['normal']==1 and math.isfinite(row['bid']) and math.isfinite(row['ask'])
        and 0<row['bid']<row['ask'])


def scan_one(records: np.ndarray, entry: int, scene_end: float, width: float,
             horizon: Mapping, side: int, config: Mapping|None=None) -> dict:
    """
    機能: 取得後の原行を順に見て、同原行IFD優先・期限/強制返済・不観測を判定する。
    引数: records(np.ndarray)は48byte索引、entry(int)は取得原行、scene_end/width(float)、
          horizon(Mapping)はkind/seconds、side(int)は買0/売1、config(Mapping|None)は固定条件。
    返り値: dictは既知/未知・先着・時計・金額と、少数の原BBO監査値。自然ファイルは読まない。
    """
    cfg=CONFIG if config is None else dict(config)
    assert side in (0,1) and width>0 and 0<=entry<len(records) and normal(records[entry])
    cut=float(scene_end-cfg['終了前秒']);submit=cut-cfg['決済要求余裕秒'];at=float(records['time'][entry])
    strict=horizon['kind']!='session'
    nominal=at+float(horizon['seconds']) if strict else math.inf
    touch_deadline=min(nominal,cut);grace_end=nominal+cfg['通常期限猶予秒'] if strict else math.inf
    price=float(records['ask' if side==0 else 'bid'][entry]);sign=1 if side==0 else -1
    result={'known':False,'label':2,'status':15 if at>=submit else 14,'forced':False,
        'exit_time':None,'known_at':None,'exit_index':-1,'exit_line':-1,'exit_price':None,'exit_quote_time':None,
        'points':None,'net0':None,'net':None,'holding_confirmed_until':None,
        'nominal_deadline':None if at>=submit else cut if not strict else nominal,
        'exit_deadline':None if at>=submit else min(grace_end,cut),
        'audit':{'entry_index':int(entry),'entry_time':at,'entry_line':int(records['source_line'][entry]),
            'entry_bid':float(records['bid'][entry]),'entry_ask':float(records['ask'][entry]),
            'entry_price':price,'side':side,'width':float(width),'cut':cut,'submit':submit,
            'first_uncertain_index':None,'last_confirmed_index':int(entry),'scanned_rows':0}}
    if at>=submit:return result
    last_normal=entry;previous_time=at;previous_normal=at
    fallback=12 if grace_end<cut else 13
    # ----------------------------------------
    # 各原行では不観測の発生、IFD、返済注文の順に処理する。後のBBOで不観測を復活させない。
    for index in range(entry+1,len(records)):
        row=records[index];now=float(row['time']);result['audit']['scanned_rows']+=1
        assert now>=previous_time
        price_gap=now-previous_time>cfg['価格BBO最大gap秒'] and previous_time<touch_deadline
        bbo_gap=now-previous_normal>cfg['価格BBO最大gap秒'] and previous_normal<touch_deadline
        if price_gap or bbo_gap:
            result['audit']['first_uncertain_index']=index
            result['status']=(10 if price_gap else 11) if now<=cut else fallback
            break
        if now>cut:
            result['status']=fallback
            break
        if normal(row):
            mark=float(row['bid' if side==0 else 'ask']);points=sign*(mark-price)
            touched=now<=touch_deadline and abs(points)>=width
            forced=now>=submit+cfg['強制注文最小遅延秒']
            ordinary=strict and now>=nominal and now<=grace_end
            if touched:
                kind=1 if points>=width else 2;label=1 if kind==1 else -1
            elif forced or ordinary:
                if now>grace_end:
                    result['status']=12
                    break
                kind=4 if forced else 3;label=0
            else:kind=0;label=2
            if kind:
                result.update({'known':True,'label':label,'status':kind,'forced':kind==4,
                    'exit_time':now,'known_at':now,'exit_index':index,'exit_line':int(row['source_line']),
                    'exit_price':mark,'exit_quote_time':now,'points':points,
                    'net0':points*cfg['1pt円']-cfg['往復手数料円'],
                    'net':points*cfg['1pt円']-cfg['往復手数料円']-cfg['往復追加滑り円'],
                    'holding_confirmed_until':now})
                result['audit']['last_confirmed_index']=index
                return result
            if now<=touch_deadline:last_normal=index
            previous_normal=now
        if now>grace_end and grace_end<cut:
            result['status']=12
            break
        previous_time=now
    else:
        result['status']=14 if float(records['time'][-1])<touch_deadline else fallback
    result['holding_confirmed_until']=float(records['time'][last_normal])
    result['audit']['last_confirmed_index']=int(last_normal)
    return result
