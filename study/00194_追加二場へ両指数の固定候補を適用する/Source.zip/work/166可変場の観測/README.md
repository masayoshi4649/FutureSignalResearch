# 可変場数のRaw索引と任意幅観測

2026-11-14。旧163のSourceを別folderへコピーし、73場・31,642case・2026年固定の入口検査を一般化した。旧163は変更しない。48byte形式、parser、segment min/max木、firstOutside、期限・市場境界、両実側、費用の計算は同じ。旧strict label、direction、金融既知を別々に保存し、164の観測済み先着への再分類は数値adapter側で行う。

`Sourceの同体を確認する.py` と `旧163純関数の同体.json` は、変更したwrapper5関数を列挙し、それ以外の10関数本文と6ファイル全bytesが旧163と一致することを確認する。異常終了時の出力file closeもwrapperで補った。

## 初回の索引入力

入力JSONは `scenes` と `expected_entry_count`。各sceneはsession/contract/start/end/force_close/rawを持つ。rawは元原板path/SHAで固定する。`expected_raw_stat:{bytes,mtime_ns}` を指定するとopen前の事前固定statへも照合し、全件走査後に開いたfile・元pathのstat/同一file・SHAを再検査する。

q1がまだない初回は `entries:[]`、`expected_entry_count:0` としてよい。`expected_accepted:0` 又は省略は期待値未指定、`expected_quality:null` 又は省略も未指定である。実測件数・全品質は必ず保存し、manifestの `expected_accepted_compared` / `expected_quality_compared` / `expected_raw_stat_compared` で事前期待照合の有無を区別する。未指定値を「事前照合済み」としない。Raw全SHA・前後stat・全Symbolの限月一貫性・価格時計の品質検査は省略しない。

```powershell
go build -o 可変場観測.exe .
.\可変場観測.exe --mode index --input <固定入力> --sha256 <SHA> --output-dir <未作成先> --workers 4
```

新manifest.versionは部品版166、数値索引のmagicは互換の `NQIDX163`。研究試行は入力の任意の正 `trial` を渡し、未指定の旧形だけ部品版166を既定値にする。将来167以降にも同じSourceを使える。1場1ファイル、Rawは1回だけ読む。

## q1を生成した後の評価

入口接続器で生成した全q1を固定入力へ置き、同じ索引を使う。索引作成時とq1入力のSHAは異なってよい。両者を出力manifestへ併記し `index_input_differs_from_entries` で明示する。対象場は索引manifestからsessionで結び、元Raw参照・限月・実測品質を確認する。全q1のtime/index/line/Last/Bid/Askを索引の実原行へ照合してから金融計算する。

```powershell
.\可変場観測.exe --mode evaluate --input <q1固定入力> --sha256 <SHA> --index-dir <索引先> --index-sha256 <manifestSHA> --config <観測条件> --config-sha256 <SHA> --output-dir <未作成先> --workers 4
```

旧163 manifestも読める。場の部分集合・可変case数を受け、case0の場も結果へ残す。新出力の `component_version` は166、`trial` は入力の研究試行を渡す。source_entry_count/scene_count/index_manifest_scene_countを実数で残す。元の12幅・4時計設定は条件JSONのSHAで束縛する。固定幅125/200へ戻さず、任意幅のkernelを維持する。

人工では、1場のentries空/品質未指定で索引を作り、Rawを開けなくしてから別q1入力で評価する経路、期待値の宣言違い、旧kernelの48,832比較等を確認した。既知73場は保存索引だけで再評価し、Rawを再走査しない。未見7場のRaw/CSVは未読であり、166等の候補・book・F0固定まで自然実行しない。
