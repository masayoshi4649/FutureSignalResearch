package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
	"time"
)

// fixedArtificial は入力のSHAを返す人工JSON保存器です。
//
// 機能: 市場本文を読まず可変場数CLIの契約を確認します。
// 引数: t(*testing.T)、path(string)、value(any)。返り値: stringはSHA256です。
func fixedArtificial(t *testing.T, path string, value any) string {
	t.Helper()
	body, err := json.Marshal(value)
	if err != nil {
		t.Fatal(err)
	}
	if err = os.WriteFile(path, body, 0600); err != nil {
		t.Fatal(err)
	}
	digest := sha256.Sum256(body)
	return hex.EncodeToString(digest[:])
}

// TestEmptyEntriesThenVariableEvaluation は空取得索引から別入力のq1を後付けします。
//
// 機能: 元Rawは一度だけ読み、未知期待品質を事前照合成功としないことを確認します。
// 引数: t(*testing.T)。返り値: ありません。
func TestEmptyEntriesThenVariableEvaluation(t *testing.T) {
	dir := t.TempDir()
	at := time.Date(2026, 1, 1, 8, 45, 0, 0, time.FixedZone("JST", 9*3600))
	body := []byte{}
	for i := 0; i < 3; i++ {
		body = append(body, rawRow(at.Add(time.Duration(i)*time.Second), 1000+200*float64(i), 1010+200*float64(i))...)
	}
	raw := filepath.Join(dir, "人工原板.jsonl")
	if err := os.WriteFile(raw, body, 0600); err != nil {
		t.Fatal(err)
	}
	digest := sha256.Sum256(body)
	stat, _ := os.Stat(raw)
	scene := FixedScene{Session: "2026-01-01_Day", Contract: "人工限月", Start: float64(at.Unix()), End: float64(at.Unix()) + 25200, ForceClose: float64(at.Unix()) + 24600, Raw: FileRef{Path: raw, SHA256: hex.EncodeToString(digest[:])}, ExpectedRawStat: &FileStat{Bytes: stat.Size(), ModTimeNS: stat.ModTime().UnixNano()}, Entries: []FixedEntry{}}
	input := filepath.Join(dir, "空取得入力.json")
	inputSHA := fixedArtificial(t, input, FixedInput{Scenes: []FixedScene{scene}, ExpectedEntryCount: 0})
	indexed := filepath.Join(dir, "索引")
	if err := buildIndex(input, inputSHA, indexed, 1); err != nil {
		t.Fatal(err)
	}
	manifestPath := filepath.Join(indexed, "manifest.json")
	manifestBody, _ := os.ReadFile(manifestPath)
	var manifest Manifest
	if err := json.Unmarshal(manifestBody, &manifest); err != nil {
		t.Fatal(err)
	}
	r := manifest.Scenes[0]
	if manifest.Version != 166 || manifest.SourceEntryCount != 0 || r.Rows != 3 || !r.AllEntriesMatched || r.ExpectedAcceptedCompared || r.ExpectedQualityCompared || !r.ExpectedRawStatCompared {
		t.Fatal("未知期待値と実測を混同")
	}
	// ----------------------------------------
	// 索引成功後は原板を開けなくし、別のq1入力だけで観測できることを確認します。
	if err := os.Rename(raw, raw+".未使用"); err != nil {
		t.Fatal(err)
	}
	q := Quote{Clock: at.UTC().Format(time.RFC3339Nano), Time: scene.Start, Index: 0, SourceLine: 1, Last: 1005, Bid: 1000, Ask: 1010, QuoteOK: true}
	scene.Entries = []FixedEntry{{ID: "人工q1", Side: 1, Entry: q}}
	scene.ExpectedAccepted = 3
	quality := r.Quality
	scene.ExpectedQuality = &quality
	entries := filepath.Join(dir, "取得入力.json")
	entriesSHA := fixedArtificial(t, entries, FixedInput{Scenes: []FixedScene{scene}, ExpectedEntryCount: 1})
	config := filepath.Join(dir, "観測条件.json")
	configSHA := fixedArtificial(t, config, testConfig())
	manifestSHA, _ := hashFile(manifestPath)
	out := filepath.Join(dir, "観測")
	if err := evaluateIndex(entries, entriesSHA, indexed, manifestSHA, config, configSHA, out, 1); err != nil {
		t.Fatal(err)
	}
	encoded, _ := os.ReadFile(filepath.Join(out, "manifest.json"))
	var result map[string]any
	if err := json.Unmarshal(encoded, &result); err != nil {
		t.Fatal(err)
	}
	if result["source_entry_count"] != float64(1) || result["scene_count"] != float64(1) || result["index_input_differs_from_entries"] != true {
		t.Fatal("可変数又は前後入力の区別差")
	}
}

// TestFlexibleInputValidation は固定件数の撤去後も件数と場の整合を維持します。
//
// 機能: 空母集団を認め、宣言数違い・重複場・負期待件数を拒否します。
// 引数: t(*testing.T)。返り値: ありません。
func TestFlexibleInputValidation(t *testing.T) {
	dir := t.TempDir()
	input := filepath.Join(dir, "入力.json")
	scene := FixedScene{Session: "2026-01-01_Day", Contract: "人工", Start: 1000, End: 20000, ForceClose: 19000, Raw: FileRef{Path: "未読.jsonl", SHA256: "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"}, Entries: []FixedEntry{}}
	valid := FixedInput{Scenes: []FixedScene{scene}, ExpectedEntryCount: 0}
	sha := fixedArtificial(t, input, valid)
	if _, _, err := readFixed(input, sha); err != nil {
		t.Fatal(err)
	}
	for name, value := range map[string]FixedInput{"宣言数違い": {Scenes: []FixedScene{scene}, ExpectedEntryCount: 1}, "場重複": {Scenes: []FixedScene{scene, scene}, ExpectedEntryCount: 0}, "負期待件数": {Scenes: []FixedScene{scene}, ExpectedEntryCount: -1}} {
		t.Run(name, func(t *testing.T) {
			sha := fixedArtificial(t, input, value)
			if _, _, err := readFixed(input, sha); err == nil {
				t.Fatal("不正入力を許可")
			}
		})
	}
}
