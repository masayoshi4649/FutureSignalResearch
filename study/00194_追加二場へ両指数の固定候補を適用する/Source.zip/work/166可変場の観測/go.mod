module quoteindex166

go 1.24.2
