package main

import (
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math/rand"
	"os"
	"path/filepath"
	"testing"
	"time"
)

// artificialQuote は人工の原行位置と評価価格を作ります。
//
// 機能: 逐次旧kernelと数値索引へ同じQuoteを提供します。
// 引数: record(Record)、index(int)は数値原行と採用位置。
// 返り値: Quoteは時刻/物理原行/価格です。
func artificialQuote(record Record, index int) Quote {
	return Quote{Time: record.Time, Index: int64(index), SourceLine: record.SourceLine, Last: record.Last, Bid: record.Bid, Ask: record.Ask, QuoteOK: record.Flags == 1}
}

// oldReference は保存済み旧逐次kernelで人工の全幅・全期限を観測します。
//
// 機能: 高速木検索の時計と値幅を独立した逐次更新へ比較します。
// 引数: rows([]Record)、entry(int)、side(int)、end(float64)、config(EvaluationConfig)。
// 返り値: *Candidate133は旧kernelが得た先着と完了状態です。
func oldReference(rows []Record, entry, side int, end float64, config EvaluationConfig) *Candidate133 {
	q := artificialQuote(rows[entry], entry)
	price := q.Ask
	if side < 0 {
		price = q.Bid
	}
	c := &Candidate133{Status: "filled", Axis: "BBO", Birth: Signal133{Side: side}, Entry: &q, EntryPrice: &price, LastNormalTime: q.Time}
	for _, h := range config.Horizons {
		o := Outcome133{Seconds: h.Seconds, Deadline: q.Time + h.Seconds, Status: "pending"}
		for _, w := range config.Widths {
			o.Touches = append(o.Touches, First133{Width: w})
		}
		c.Outcomes = append(c.Outcomes, o)
	}
	previous := rows[entry].Time
	for i := entry; i < len(rows); i++ {
		outcome133(c, artificialQuote(rows[i], i), previous, end)
		previous = rows[i].Time
	}
	for i := range c.Outcomes {
		if c.Outcomes[i].Status == "pending" {
			c.Outcomes[i].Status = "eof_censored"
		}
	}
	return c
}

// testConfig は有限幅と旧契約の費用を設定した人工条件を返します。
//
// 機能: テストごとの値幅と期限を明示します。
// 引数: なし。
// 返り値: EvaluationConfigは比較条件です。
func testConfig() EvaluationConfig {
	return EvaluationConfig{Widths: []float64{25, 125, 175, 200, 250, 400, 750}, Horizons: []Horizon{{ID: "H1", Kind: "strict", Seconds: 60}, {ID: "H30", Kind: "strict", Seconds: 1800}, {ID: "H60", Kind: "strict", Seconds: 3600}, {ID: "H120", Kind: "strict", Seconds: 7200}}, MaximumGap: 300, EndpointGrace: 30, PointYen: 100, RoundTripFee: 77, ExtraSlippage: 1000}
}

// TestTreeMatchesSequentialKernel は幅・買売・gap・境界・同秒を混ぜて旧逐次kernelへ照合します。
//
// 機能: 全quote×caseの更新を木検索へ置き換えても結果が同体か検査します。
// 引数: t(*testing.T)はGoテスト文脈。
// 返り値: ありません。不一致時は失敗します。
func TestTreeMatchesSequentialKernel(t *testing.T) {
	rng := rand.New(rand.NewSource(163))
	config := testConfig()
	comparisons := 0
	for sample := 0; sample < 120; sample++ {
		rows := make([]Record, 220)
		now := 1000000000.0
		price := 10000.0
		for i := range rows {
			if i > 0 {
				now += float64(rng.Intn(61))
				if rng.Intn(40) == 0 {
					now += 301
				}
			}
			price += float64(rng.Intn(141) - 70)
			ask := price + 10
			flags := uint64(1)
			if rng.Intn(9) == 0 {
				ask = price
				flags = 0
			}
			rows[i] = Record{Time: now, SourceLine: int64(i*2 + 1), Last: price + 5, Bid: price, Ask: ask, Flags: flags}
		}
		x := newSegmentIndex(rows)
		end := rows[100+rng.Intn(120)].Time
		for entry := 0; entry < 50; entry += 7 {
			if rows[entry].Flags != 1 {
				continue
			}
			q := artificialQuote(rows[entry], entry)
			actual, e := evaluateCase(x, FixedEntry{ID: "人工", Side: 1, Entry: q}, end, config)
			if e != nil {
				t.Fatal(e)
			}
			for si, side := range []int{1, -1} {
				ref := oldReference(rows, entry, side, end, config)
				for hi, wanted := range ref.Outcomes {
					got := actual.Sides[si].Outcomes[hi]
					if got.Status != wanted.Status || got.Complete != (wanted.Status == "complete") {
						t.Fatalf("時計差 sample%d entry%d side%d H%d got%s want%s", sample, entry, side, hi, got.Status, wanted.Status)
					}
					if (got.EndpointIndex == nil) != (wanted.Endpoint == nil) || got.EndpointIndex != nil && *got.EndpointIndex != wanted.Endpoint.Index {
						t.Fatal("endpoint原行差")
					}
					for wi, touch := range wanted.Touches {
						out := got.Touches[wi]
						label := int8(2)
						if wanted.Status == "complete" {
							label = int8(touch.Direction)
						}
						if out.Direction != int8(touch.Direction) || out.Label != label || (out.TouchIndex == nil) != (touch.Quote == nil) || out.TouchIndex != nil && *out.TouchIndex != touch.Quote.Index {
							t.Fatalf("先着差 sample%d entry%d side%d H%d W%d", sample, entry, side, hi, wi)
						}
						exit := touch.Quote
						if exit == nil && wanted.Status == "complete" {
							exit = wanted.Endpoint
						}
						if (out.ExitIndex == nil) != (exit == nil) {
							t.Fatal("金融既知差")
						}
						if exit != nil {
							mark := exit.Bid
							if side < 0 {
								mark = exit.Ask
							}
							points := float64(side) * (mark - *ref.EntryPrice)
							if *out.ExitIndex != exit.Index || *out.Points != points || *out.Net5 != points*100-1077 {
								t.Fatal("実側IFD価格又は費用差")
							}
						}
						comparisons++
					}
				}
			}
		}
	}
	t.Logf("逐次旧kernelとの全実側幅期限比較=%d", comparisons)
}

// TestSessionExpiryContract は場末の鮮度・境界証拠・gapと早期touchを検査します。
//
// 機能: 新しいSESSION契約を厳密H60へ混ぜず明示検証します。
// 引数: t(*testing.T)はGoテスト文脈。
// 返り値: ありません。
func TestSessionExpiryContract(t *testing.T) {
	config := testConfig()
	config.Horizons = []Horizon{{ID: "SESSION", Kind: "session", Seconds: 0}}
	config.SessionExit = "last_normal_pre_end_fresh30_require_boundary"
	rows := []Record{{Time: 100, SourceLine: 1, Last: 1000, Bid: 990, Ask: 1000, Flags: 1}, {Time: 200, SourceLine: 2, Last: 1250, Bid: 1250, Ask: 1260, Flags: 1}, {Time: 399, SourceLine: 3, Last: 1200, Bid: 1200, Ask: 1210, Flags: 1}, {Time: 400, SourceLine: 4, Last: 1500, Bid: 1500, Ask: 1510, Flags: 1}}
	x := newSegmentIndex(rows)
	q := artificialQuote(rows[0], 0)
	actual, e := evaluateCase(x, FixedEntry{ID: "人工", Side: 1, Entry: q}, 400, config)
	if e != nil {
		t.Fatal(e)
	}
	o := actual.Sides[0].Outcomes[0]
	if !o.Complete || *o.EndpointIndex != 2 || *o.KnownAt != 400 || *o.Touches[1].TouchIndex != 1 {
		t.Fatal("SESSION境界前清算/先着/成熟差")
	}
	if o.Touches[5].Direction != 0 {
		t.Fatal("境界等号で400幅に到達した")
	}
	missing := newSegmentIndex(rows[:3])
	if missing.terminal(0, config.Horizons[0], 400, config).Complete {
		t.Fatal("市場境界観測なしを完了にした")
	}
	stale := append([]Record(nil), rows...)
	stale[2].Time = 350
	if newSegmentIndex(stale).terminal(0, config.Horizons[0], 400, config).Complete {
		t.Fatal("鮮度30秒超を場末決済した")
	}
	gap := append([]Record(nil), rows...)
	gap[1].Time = 401
	gap[2].Time = 499
	gap[3].Time = 500
	if term := newSegmentIndex(gap).terminal(0, config.Horizons[0], 500, config); term.Complete || term.Status != "gap_censored" {
		t.Fatal("SESSION gap未考慮")
	}
}

// TestSameClockEndpointAndPhasePriority は同秒後続と境界等号の順序を固定します。
//
// 機能: 期限最初の正常原行で完了した後の同秒価格を混入しないことを確認します。
// 引数: t(*testing.T)はGoテスト文脈。
// 返り値: ありません。
func TestSameClockEndpointAndPhasePriority(t *testing.T) {
	config := testConfig()
	config.Horizons = config.Horizons[:1]
	rows := []Record{{Time: 100, SourceLine: 1, Last: 1005, Bid: 1000, Ask: 1010, Flags: 1}, {Time: 160, SourceLine: 2, Last: 1015, Bid: 1010, Ask: 1020, Flags: 1}, {Time: 160, SourceLine: 3, Last: 1510, Bid: 1500, Ask: 1510, Flags: 1}}
	x := newSegmentIndex(rows)
	q := artificialQuote(rows[0], 0)
	r, e := evaluateCase(x, FixedEntry{ID: "人工", Side: 1, Entry: q}, 1000, config)
	if e != nil {
		t.Fatal(e)
	}
	o := r.Sides[0].Outcomes[0]
	if !o.Complete || *o.EndpointIndex != 1 || o.Touches[1].Direction != 0 {
		t.Fatal("完了後同秒原行を触達へ混入")
	}
	r, e = evaluateCase(x, FixedEntry{ID: "人工", Side: 1, Entry: q}, 160, config)
	if e != nil {
		t.Fatal(e)
	}
	o = r.Sides[0].Outcomes[0]
	if o.Complete || o.Status != "phase_censored" || o.Touches[1].Direction != 0 {
		t.Fatal("市場境界等号の価格を混入")
	}
	rows[1].Time = 100
	rows[2].Time = 100
	r, e = evaluateCase(newSegmentIndex(rows), FixedEntry{ID: "人工", Side: 1, Entry: q}, 1000, config)
	if e != nil {
		t.Fatal(e)
	}
	if r.Sides[0].Outcomes[0].Touches[1].Direction != 1 {
		t.Fatal("同秒後続原行を不当に除外")
	}
}

// BenchmarkVariableWidthTree は一度の索引を多数取得と幅へ共有する速度を測ります。
//
// 機能: 自然Rawを読まず木検索の反復性能と割当を測ります。
// 引数: b(*testing.B)はGoベンチマーク文脈。
// 返り値: ありません。
func BenchmarkVariableWidthTree(b *testing.B) {
	rows := make([]Record, 100000)
	price := 10000.0
	rng := rand.New(rand.NewSource(163))
	for i := range rows {
		price += float64(rng.Intn(21) - 10)
		rows[i] = Record{Time: 1000000000 + float64(i), SourceLine: int64(i + 1), Last: price + 5, Bid: price, Ask: price + 10, Flags: 1}
	}
	x := newSegmentIndex(rows)
	config := testConfig()
	b.ResetTimer()
	for repeat := 0; repeat < b.N; repeat++ {
		for at := 0; at < 10000; at += 10 {
			q := artificialQuote(rows[at], at)
			if _, e := evaluateCase(x, FixedEntry{ID: "人工", Side: 1, Entry: q}, rows[len(rows)-1].Time, config); e != nil {
				b.Fatal(e)
			}
		}
	}
}

// rawRow は旧parserの型を満たす人工JSONLを作ります。
//
// 機能: 全Raw索引化と取得全値照合を人工ファイルで検査します。
// 引数: at(time.Time)、bid/ask(float64)は時計とBBO。
// 返り値: []byteはJSON原行です。
func rawRow(at time.Time, bid, ask float64) []byte {
	m := map[string]any{"Symbol": "人工限月", "CurrentPriceTime": at.Format(time.RFC3339Nano), "CurrentPrice": (bid + ask) / 2}
	for i := 1; i <= 10; i++ {
		m[fmt.Sprintf("Buy%d", i)] = map[string]float64{"Price": bid - float64(i-1)*10, "Qty": 10}
		m[fmt.Sprintf("Sell%d", i)] = map[string]float64{"Price": ask + float64(i-1)*10, "Qty": 10}
	}
	body, _ := json.Marshal(m)
	return append(body, '\n')
}

// TestIndexRoundTripAndCorruption は数値索引のRaw指紋・原行・全CRCを検査します。
//
// 機能: 保存価格が実側と同体で、原板/索引の破損が成功扱いにならないことを確認します。
// 引数: t(*testing.T)はGoテスト文脈。
// 返り値: ありません。
func TestIndexRoundTripAndCorruption(t *testing.T) {
	dir := t.TempDir()
	raw := filepath.Join(dir, "人工.jsonl")
	at := time.Unix(1000000000, 0).UTC()
	body := []byte{}
	for i := 0; i < 3; i++ {
		body = append(body, rawRow(at.Add(time.Duration(i)*time.Second), 1000+float64(i)*10, 1010+float64(i)*10)...)
	}
	if e := os.WriteFile(raw, body, 0600); e != nil {
		t.Fatal(e)
	}
	digest := sha256.Sum256(body)
	q := Quote{Clock: at.Format(time.RFC3339Nano), Time: float64(at.Unix()), Index: 0, SourceLine: 1, Last: 1005, Bid: 1000, Ask: 1010, QuoteOK: true}
	s := FixedScene{Session: "人工", Contract: "人工限月", Start: q.Time, End: q.Time + 10000, ForceClose: q.Time + 9000, Raw: FileRef{Path: raw, SHA256: hex.EncodeToString(digest[:])}, ExpectedAccepted: 3, ExpectedQuality: &Counts{Lines: 3, Accepted: 3, Delivered: 3}, Entries: []FixedEntry{{ID: "人工", Side: 1, Entry: q}}}
	r, e := indexScene(s, dir)
	if e != nil {
		t.Fatal(e)
	}
	if !r.Success || !r.AllEntriesMatched || r.Rows != 3 {
		t.Fatal("索引検査差")
	}
	rows, e := loadRecords(filepath.Join(dir, r.Index.Path), r.Index.SHA256, 3)
	if e != nil {
		t.Fatal(e)
	}
	if rows[0].Time != q.Time || rows[0].Bid != q.Bid || rows[0].Ask != q.Ask || rows[2].SourceLine != 3 {
		t.Fatal("保存型/実側価格差")
	}
	path := filepath.Join(dir, r.Index.Path)
	bad, _ := os.ReadFile(path)
	bad[len(bad)-1] ^= 1
	if e = os.WriteFile(path, bad, 0600); e != nil {
		t.Fatal(e)
	}
	newSHA, _ := hashFile(path)
	if _, e = loadRecords(path, newSHA, 3); e == nil {
		t.Fatal("索引gzip CRC破損を許した")
	}
	other := t.TempDir()
	s.Entries[0].Entry.Ask++
	if _, e = indexScene(s, other); e == nil {
		t.Fatal("元取得原行の価格差を許した")
	}
	corrupt := filepath.Join(t.TempDir(), "人工.gz")
	f, _ := os.Create(corrupt)
	z := gzip.NewWriter(f)
	z.Write(body)
	z.Close()
	f.Close()
	encoded, _ := os.ReadFile(corrupt)
	encoded[len(encoded)-1] ^= 1
	os.WriteFile(corrupt, encoded, 0600)
	s.Raw.Path = corrupt
	d := sha256.Sum256(encoded)
	s.Raw.SHA256 = hex.EncodeToString(d[:])
	s.Entries[0].Entry.Ask--
	if _, e = indexScene(s, t.TempDir()); e == nil {
		t.Fatal("原板gzip CRC破損を許した")
	}
}
