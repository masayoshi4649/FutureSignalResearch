package main

// outcome133 は同幅先着と期限清算評価を別に保存し、欠測を0円へ埋めません。
//
// 引数: c(*Candidate133)、q(Quote)、previous/force(float64)。返り値: ありません。
func outcome133(c *Candidate133, q Quote, previous, force float64) {
	if c.Entry == nil || q.Index <= c.Entry.Index {
		return
	}
	if phaseCut133(c, q, force) {
		return
	}
	lastNormal := c.LastNormalTime
	if q.QuoteOK && normal(q) {
		defer func() { c.LastNormalTime = q.Time }()
	}
	for i := range c.Outcomes {
		o := &c.Outcomes[i]
		if o.Status != "pending" {
			continue
		}
		if previous >= c.Entry.Time && q.Time-previous > 300 && previous < o.Deadline {
			o.Status = "gap_censored"
			continue
		}
		if lastNormal >= c.Entry.Time && lastNormal < o.Deadline && q.Time-lastNormal > 300 {
			o.Status = "bbo_gap_censored"
			continue
		}
		if q.Time > force {
			o.Status = "session_censored"
			continue
		}
		if q.Time > o.Deadline+30 {
			o.Status = "endpoint_missing"
			continue
		}
		if !q.QuoteOK || !normal(q) {
			continue
		}
		mark := q.Bid
		if c.Birth.Side < 0 {
			mark = q.Ask
		}
		gain := float64(c.Birth.Side) * (mark - *c.EntryPrice)
		if q.Time <= o.Deadline {
			for j := range o.Touches {
				t := &o.Touches[j]
				if t.Direction != 0 {
					continue
				}
				if gain >= t.Width {
					t.Direction = 1
					x := q
					t.Quote = &x
				} else if gain <= -t.Width {
					t.Direction = -1
					x := q
					t.Quote = &x
				}
			}
		}
		if q.Time >= o.Deadline {
			x := q
			o.Endpoint = &x
			o.Points = &gain
			n0 := gain*100 - 77
			n5 := n0 - 1000
			o.Net0 = &n0
			o.Net5 = &n5
			o.Status = "complete"
		}
	}
}

// phaseCut133 はザラバ終端以降の未完了だけを打ち切り、既知touchと完了観測を保持します。
//
// 引数: c(*Candidate133)、q(Quote)、executionEnd(float64)は等号を除外する境界です。
// 返り値: boolは現在行が境界以降の場合に真です。Last/BBOへ同じ順序で適用します。
func phaseCut133(c *Candidate133, q Quote, executionEnd float64) bool {
	if q.Time < executionEnd {
		return false
	}
	for i := range c.Outcomes {
		if c.Outcomes[i].Status == "pending" {
			c.Outcomes[i].Status = "phase_censored"
		}
	}
	return true
}

type Signal133 struct {
	ID    string  `json:"id"`
	Side  int     `json:"side"`
	Time  float64 `json:"time"`
	Index int64   `json:"index"`
	Line  int64   `json:"source_line"`
	Quote Quote   `json:"quote"`
}
type First133 struct {
	Width     float64 `json:"width"`
	Direction int     `json:"direction"`
	Quote     *Quote  `json:"quote"`
}
type Outcome133 struct {
	Seconds  float64    `json:"seconds"`
	Deadline float64    `json:"deadline"`
	Status   string     `json:"status"`
	Touches  []First133 `json:"touches"`
	Endpoint *Quote     `json:"endpoint"`
	Points   *float64   `json:"points"`
	Net0     *float64   `json:"net0"`
	Net5     *float64   `json:"net5"`
}
type Candidate133 struct {
	Status         string       `json:"status"`
	Axis           string       `json:"axis"`
	Birth          Signal133    `json:"birth"`
	Entry          *Quote       `json:"entry"`
	EntryPrice     *float64     `json:"entry_price"`
	LastNormalTime float64      `json:"last_normal_time"`
	Outcomes       []Outcome133 `json:"outcomes"`
}
