package main

import (
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"sort"
	"sync"
)

type Horizon struct {
	ID      string  `json:"id"`
	Kind    string  `json:"kind"`
	Seconds float64 `json:"seconds"`
}

type EvaluationConfig struct {
	Widths        []float64 `json:"widths"`
	Horizons      []Horizon `json:"horizons"`
	SessionExit   string    `json:"session_exit"`
	MaximumGap    float64   `json:"maximum_gap_seconds"`
	EndpointGrace float64   `json:"endpoint_grace_seconds"`
	PointYen      float64   `json:"point_yen"`
	RoundTripFee  float64   `json:"round_trip_fee"`
	ExtraSlippage float64   `json:"extra_round_trip_slippage"`
}

type SegmentIndex struct {
	Rows        []Record
	Size        int
	BidMin      []float64
	BidMax      []float64
	AskMin      []float64
	AskMax      []float64
	Normal      []int
	PriceGaps   []int
	BBOGaps     []int
	BBOPrevious []float64
}

type Terminal struct {
	Deadline float64
	Status   string
	Complete bool
	Endpoint int
	TouchEnd int
	KnownAt  *float64
}

type TouchResult struct {
	Width      float64  `json:"width"`
	Direction  int8     `json:"direction"`
	Label      int8     `json:"label"`
	TouchIndex *int64   `json:"touch_index"`
	ExitIndex  *int64   `json:"exit_index"`
	Points     *float64 `json:"points"`
	Net0       *float64 `json:"net0"`
	Net5       *float64 `json:"net5"`
}

type HorizonResult struct {
	HorizonID     string        `json:"horizon_id"`
	Kind          string        `json:"kind"`
	Seconds       float64       `json:"seconds"`
	Deadline      float64       `json:"deadline"`
	Status        string        `json:"status"`
	Complete      bool          `json:"complete"`
	KnownAt       *float64      `json:"known_at"`
	EndpointIndex *int64        `json:"endpoint_index"`
	Touches       []TouchResult `json:"touches"`
}

type SideResult struct {
	Side       int             `json:"side"`
	EntryPrice float64         `json:"entry_price"`
	Outcomes   []HorizonResult `json:"outcomes"`
}

type CaseResult struct {
	ID           string       `json:"id"`
	OriginalSide int          `json:"original_side"`
	EntryIndex   int64        `json:"entry_index"`
	Sides        []SideResult `json:"sides"`
}

type SceneEvaluation struct {
	Session string       `json:"session"`
	Success bool         `json:"success"`
	Cases   []CaseResult `json:"cases"`
}

type EvaluationFile struct {
	Session string  `json:"session"`
	File    FileRef `json:"file"`
	Bytes   int64   `json:"bytes"`
	Cases   int     `json:"cases"`
	Success bool    `json:"success"`
	Error   string  `json:"error,omitempty"`
}

// newSegmentIndex は正常BBOの価格極値と打切りイベントを索引化します。
//
// 機能: 幅ごとに全原行を再走査せず最初の上下到達を検索します。
// 引数: rows([]Record)は全採用原行。
// 返り値: *SegmentIndexはBid/Ask minmax木とgap位置です。
func newSegmentIndex(rows []Record) *SegmentIndex {
	size := 1
	for size < len(rows) {
		size *= 2
	}
	x := &SegmentIndex{Rows: rows, Size: size, BidMin: make([]float64, 2*size), BidMax: make([]float64, 2*size), AskMin: make([]float64, 2*size), AskMax: make([]float64, 2*size)}
	for i := 0; i < 2*size; i++ {
		x.BidMin[i] = math.Inf(1)
		x.AskMin[i] = math.Inf(1)
		x.BidMax[i] = math.Inf(-1)
		x.AskMax[i] = math.Inf(-1)
	}
	lastNormal := math.NaN()
	for i, r := range rows {
		if i > 0 && r.Time-rows[i-1].Time > 300 {
			x.PriceGaps = append(x.PriceGaps, i)
		}
		if !math.IsNaN(lastNormal) && r.Time-lastNormal > 300 {
			x.BBOGaps = append(x.BBOGaps, i)
			x.BBOPrevious = append(x.BBOPrevious, lastNormal)
		}
		if r.Flags == 1 {
			x.Normal = append(x.Normal, i)
			lastNormal = r.Time
			x.BidMin[size+i] = r.Bid
			x.BidMax[size+i] = r.Bid
			x.AskMin[size+i] = r.Ask
			x.AskMax[size+i] = r.Ask
		}
	}
	for i := size - 1; i > 0; i-- {
		x.BidMin[i] = math.Min(x.BidMin[2*i], x.BidMin[2*i+1])
		x.AskMin[i] = math.Min(x.AskMin[2*i], x.AskMin[2*i+1])
		x.BidMax[i] = math.Max(x.BidMax[2*i], x.BidMax[2*i+1])
		x.AskMax[i] = math.Max(x.AskMax[2*i], x.AskMax[2*i+1])
	}
	return x
}

// firstOutside は指定原行範囲で上下閾値のどちらかに最初に触れた行を返します。
//
// 機能: 正常価格のminmaxを使い未到達区間をまとめて枝刈りします。
// 引数: node/left/right/from/to(int)、lower/upper(float64)、ask(bool)は木位置・半開区間・閾値・評価価格側。
// 返り値: intは最初の物理採用index、未到達は−1です。
func (x *SegmentIndex) firstOutside(node, left, right, from, to int, lower, upper float64, ask bool) int {
	if right <= from || to <= left {
		return -1
	}
	minimum, maximum := x.BidMin[node], x.BidMax[node]
	if ask {
		minimum, maximum = x.AskMin[node], x.AskMax[node]
	}
	if minimum > lower && maximum < upper {
		return -1
	}
	if right-left == 1 {
		if left >= len(x.Rows) {
			return -1
		}
		return left
	}
	middle := (left + right) / 2
	if found := x.firstOutside(node*2, left, middle, from, to, lower, upper, ask); found >= 0 {
		return found
	}
	return x.firstOutside(node*2+1, middle, right, from, to, lower, upper, ask)
}

// firstCensor は取得以後かつ期限前に始まる最初の価格/BBO gapを返します。
//
// 機能: 旧kernelのgap300秒と同じ優先順を一回の二分探索で復元します。
// 引数: entry(int)、deadline(float64)は取得indexと評価期限。
// 返り値: int/stringは最初gapのindexと状態、なしは行数と空文字です。
func (x *SegmentIndex) firstCensor(entry int, deadline float64) (int, string) {
	stop := len(x.Rows)
	status := ""
	p := sort.Search(len(x.PriceGaps), func(i int) bool { return x.PriceGaps[i] > entry })
	if p < len(x.PriceGaps) {
		i := x.PriceGaps[p]
		if x.Rows[i-1].Time < deadline {
			stop = i
			status = "gap_censored"
		}
	}
	b := sort.Search(len(x.BBOGaps), func(i int) bool { return x.BBOGaps[i] > entry })
	if b < len(x.BBOGaps) && x.BBOPrevious[b] < deadline && x.BBOGaps[b] < stop {
		stop = x.BBOGaps[b]
		status = "bbo_gap_censored"
	}
	return stop, status
}

// terminal は厳密期限又は明示した場末契約の完了/打切りを決めます。
//
// 機能: q1原行除外、gap、phase等号、endpoint猶予を幅と独立に固定します。
// 引数: entry(int)、h(Horizon)、executionEnd(float64)、config(EvaluationConfig)は取得位置と時計条件。
// 返り値: Terminalはlabel成熟、清算候補、先着検索の排他的終端です。
func (x *SegmentIndex) terminal(entry int, h Horizon, executionEnd float64, config EvaluationConfig) Terminal {
	n := len(x.Rows)
	phase := sort.Search(n, func(i int) bool { return x.Rows[i].Time >= executionEnd })
	deadline := x.Rows[entry].Time + h.Seconds
	if h.Kind == "session" {
		deadline = executionEnd
	}
	gap, gapStatus := x.firstCensor(entry, deadline)
	result := Terminal{Deadline: deadline, Status: "eof_censored", Endpoint: -1, TouchEnd: n}
	if h.Kind == "session" {
		result.TouchEnd = phase
		if gap < phase {
			result.Status = gapStatus
			result.TouchEnd = gap
			return result
		}
		if phase == n {
			return result
		}
		result.Status = "phase_censored"
		at := sort.SearchInts(x.Normal, phase) - 1
		if at >= 0 {
			endpoint := x.Normal[at]
			if endpoint > entry && executionEnd-x.Rows[endpoint].Time <= config.EndpointGrace {
				result.Complete = true
				result.Status = "complete"
				result.Endpoint = endpoint
				known := x.Rows[phase].Time
				result.KnownAt = &known
			}
		}
		return result
	}
	missing := sort.Search(n, func(i int) bool { return x.Rows[i].Time > deadline+config.EndpointGrace })
	endAt := sort.Search(len(x.Normal), func(i int) bool { return x.Rows[x.Normal[i]].Time >= deadline })
	endpoint := n
	if endAt < len(x.Normal) {
		endpoint = x.Normal[endAt]
	}
	stop := n
	if phase < stop {
		stop = phase
		result.Status = "phase_censored"
	}
	if gap < stop {
		stop = gap
		result.Status = gapStatus
	}
	if missing < stop {
		stop = missing
		result.Status = "endpoint_missing"
	}
	if endpoint < stop {
		stop = endpoint
		result.Status = "complete"
		result.Complete = true
		result.Endpoint = endpoint
		known := x.Rows[endpoint].Time
		result.KnownAt = &known
	}
	result.TouchEnd = sort.Search(n, func(i int) bool { return x.Rows[i].Time > deadline })
	limit := stop
	if result.Complete {
		limit = stop + 1
	}
	if limit < result.TouchEnd {
		result.TouchEnd = limit
	}
	return result
}

// evaluateCase は両実側の任意幅先着と瞬時BBOのIFD金額を作ります。
//
// 機能: labelと金融既知を分け、逆側を1−pで作らず同じ取得原行から再評価します。
// 引数: x(*SegmentIndex)、entry(FixedEntry)、executionEnd(float64)、config(EvaluationConfig)。
// 返り値: CaseResult/errorは全幅・時計の両側結果又は索引不一致です。
func evaluateCase(x *SegmentIndex, entry FixedEntry, executionEnd float64, config EvaluationConfig) (CaseResult, error) {
	result := CaseResult{ID: entry.ID, OriginalSide: entry.Side, EntryIndex: entry.Entry.Index, Sides: []SideResult{}}
	at := int(entry.Entry.Index)
	if at < 0 || at >= len(x.Rows) {
		return result, fmt.Errorf("取得index範囲外")
	}
	q := x.Rows[at]
	saved := entry.Entry
	if q.Flags != 1 || q.Time != saved.Time || q.SourceLine != saved.SourceLine || q.Last != saved.Last || q.Bid != saved.Bid || q.Ask != saved.Ask {
		return result, fmt.Errorf("索引の元取得全数値差:%s", entry.ID)
	}
	terms := make([]Terminal, len(config.Horizons))
	for i, h := range config.Horizons {
		terms[i] = x.terminal(at, h, executionEnd, config)
	}
	for _, side := range []int{1, -1} {
		price := q.Ask
		if side < 0 {
			price = q.Bid
		}
		sideResult := SideResult{Side: side, EntryPrice: price, Outcomes: []HorizonResult{}}
		for i, h := range config.Horizons {
			term := terms[i]
			o := HorizonResult{HorizonID: h.ID, Kind: h.Kind, Seconds: h.Seconds, Deadline: term.Deadline, Status: term.Status, Complete: term.Complete, KnownAt: term.KnownAt, Touches: []TouchResult{}}
			if term.Endpoint >= 0 {
				index := int64(term.Endpoint)
				o.EndpointIndex = &index
			}
			for _, width := range config.Widths {
				t := TouchResult{Width: width, Label: 2}
				found := -1
				if term.TouchEnd > at+1 {
					found = x.firstOutside(1, 0, x.Size, at+1, term.TouchEnd, price-width, price+width, side < 0)
				}
				if found >= 0 {
					index := int64(found)
					t.TouchIndex = &index
					mark := x.Rows[found].Bid
					if side < 0 {
						mark = x.Rows[found].Ask
					}
					points := float64(side) * (mark - price)
					t.Direction = 1
					if points < 0 {
						t.Direction = -1
					}
				}
				if term.Complete {
					t.Label = t.Direction
				}
				exit := found
				if exit < 0 && term.Complete {
					exit = term.Endpoint
				}
				if exit >= 0 {
					index := int64(exit)
					t.ExitIndex = &index
					mark := x.Rows[exit].Bid
					if side < 0 {
						mark = x.Rows[exit].Ask
					}
					points := float64(side) * (mark - price)
					net0 := points*config.PointYen - config.RoundTripFee
					net5 := net0 - config.ExtraSlippage
					t.Points = &points
					t.Net0 = &net0
					t.Net5 = &net5
				}
				o.Touches = append(o.Touches, t)
			}
			sideResult.Outcomes = append(sideResult.Outcomes, o)
		}
		result.Sides = append(result.Sides, sideResult)
	}
	return result, nil
}

// readConfig は任意幅と期限の事前固定設定を検査します。
//
// 機能: 費用・gap・endpointの密かな変更と重複幅を拒否します。
// 引数: path/expected(string)は条件JSONと物理SHA。
// 返り値: EvaluationConfig/errorは比較設定又は不一致です。
func readConfig(path, expected string) (EvaluationConfig, error) {
	var config EvaluationConfig
	body, e := os.ReadFile(path)
	if e != nil {
		return config, e
	}
	digest := sha256.Sum256(body)
	if hex.EncodeToString(digest[:]) != expected {
		return config, fmt.Errorf("評価条件SHA差")
	}
	if e = json.Unmarshal(body, &config); e != nil {
		return config, e
	}
	if len(config.Widths) == 0 || len(config.Horizons) == 0 || config.MaximumGap != 300 || config.EndpointGrace != 30 || config.PointYen != 100 || config.RoundTripFee != 77 || config.ExtraSlippage != 1000 {
		return config, fmt.Errorf("比較条件/gap/費用差")
	}
	seenWidth := map[float64]bool{}
	for _, width := range config.Widths {
		if !finite(width) || width <= 0 || seenWidth[width] {
			return config, fmt.Errorf("幅の不正/重複")
		}
		seenWidth[width] = true
	}
	seenHorizon := map[string]bool{}
	for _, h := range config.Horizons {
		if h.ID == "" || seenHorizon[h.ID] || h.Kind != "strict" && h.Kind != "session" || h.Kind == "strict" && (!finite(h.Seconds) || h.Seconds <= 0) || h.Kind == "session" && (h.Seconds != 0 || config.SessionExit != "last_normal_pre_end_fresh30_require_boundary") {
			return config, fmt.Errorf("期限又は場末契約差")
		}
		seenHorizon[h.ID] = true
	}
	return config, nil
}

// evaluateScene は一場の数値索引から全caseを任意幅で評価します。
//
// 機能: Raw再走査をせず一つの木を全取得・幅・期限で共有します。
// 引数: scene(FixedScene)、index(IndexScene)、indexDirectory/output(string)、config(EvaluationConfig)。
// 返り値: EvaluationFile/errorは小型観測gzipの指紋又は失敗です。
func evaluateScene(scene FixedScene, index IndexScene, indexDirectory, output string, config EvaluationConfig) (EvaluationFile, error) {
	r := EvaluationFile{Session: scene.Session, Cases: len(scene.Entries)}
	if index.Session != scene.Session || index.Contract != scene.Contract || index.Index.Path != scene.Session+".quotes.bin.gz" || !index.Success || !index.AllEntriesMatched || index.Raw != scene.Raw || scene.ExpectedAccepted > 0 && index.Rows != scene.ExpectedAccepted || scene.ExpectedQuality != nil && index.Quality != *scene.ExpectedQuality {
		return r, fmt.Errorf("索引manifestと固定場の差")
	}
	rows, e := loadRecords(filepath.Join(indexDirectory, index.Index.Path), index.Index.SHA256, index.Rows)
	if e != nil {
		return r, e
	}
	x := newSegmentIndex(rows)
	result := SceneEvaluation{Session: scene.Session, Success: true, Cases: []CaseResult{}}
	for _, entry := range scene.Entries {
		c, e := evaluateCase(x, entry, scene.End-300, config)
		if e != nil {
			return r, e
		}
		result.Cases = append(result.Cases, c)
	}
	name := scene.Session + ".outcomes.json.gz"
	path := filepath.Join(output, name)
	f, e := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if e != nil {
		return r, e
	}
	defer f.Close()
	z := gzip.NewWriter(f)
	defer z.Close()
	encoder := json.NewEncoder(z)
	encoder.SetEscapeHTML(false)
	if e = encoder.Encode(result); e != nil {
		return r, e
	}
	if e = z.Close(); e != nil {
		return r, e
	}
	if e = f.Close(); e != nil {
		return r, e
	}
	digest, e := hashFile(path)
	if e != nil {
		return r, e
	}
	stat, e := os.Stat(path)
	if e != nil {
		return r, e
	}
	r.File = FileRef{Path: name, SHA256: digest}
	r.Bytes = stat.Size()
	r.Success = true
	return r, nil
}

// evaluateIndex は固定索引と任意幅設定を用い指定場を再評価します。
//
// 機能: 最初到達検索を値幅・期限へ再利用し新規政策の採否を読まず純観測を保存します。
// 引数: input/inputSHA/indexDirectory/indexSHA/configPath/configSHA/output(string)、workers(int)。
// 返り値: errorは全指紋/場/観測の失敗です。
func evaluateIndex(input, inputSHA, indexDirectory, indexSHA, configPath, configSHA, output string, workers int) error {
	if workers < 1 || workers > 8 {
		return fmt.Errorf("並列数は1～8")
	}
	in, decoded, e := readFixed(input, inputSHA)
	if e != nil {
		return e
	}
	manifestPath := filepath.Join(indexDirectory, "manifest.json")
	body, e := os.ReadFile(manifestPath)
	if e != nil {
		return e
	}
	digest := sha256.Sum256(body)
	if hex.EncodeToString(digest[:]) != indexSHA {
		return fmt.Errorf("索引manifest SHA差")
	}
	var manifest Manifest
	if e = json.Unmarshal(body, &manifest); e != nil {
		return e
	}
	if !manifest.Success || manifest.Version != 163 && manifest.Version != 166 || len(manifest.InputSHA256) != 64 || len(manifest.InputDecodedSHA256) != 64 || len(manifest.Scenes) == 0 {
		return fmt.Errorf("索引manifestの由来差")
	}
	// ----------------------------------------
	// 索引はq1生成前のentries空でもよく、後段のq1は元索引の全数値へ必ず再照合します。
	bySession := map[string]IndexScene{}
	for _, indexed := range manifest.Scenes {
		if _, exists := bySession[indexed.Session]; exists {
			return fmt.Errorf("索引manifest場重複")
		}
		bySession[indexed.Session] = indexed
	}
	indices := make([]IndexScene, len(in.Scenes))
	for i, scene := range in.Scenes {
		indexed, ok := bySession[scene.Session]
		if !ok {
			return fmt.Errorf("索引manifestに対象場がない")
		}
		indices[i] = indexed
	}
	config, e := readConfig(configPath, configSHA)
	if e != nil {
		return e
	}
	if _, e = os.Stat(output); !os.IsNotExist(e) {
		return fmt.Errorf("未作成の観測保存先だけ")
	}
	if e = os.MkdirAll(output, 0700); e != nil {
		return e
	}
	results := make([]EvaluationFile, len(in.Scenes))
	jobs := make(chan int)
	var wg sync.WaitGroup
	for worker := 0; worker < workers; worker++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for i := range jobs {
				r, err := evaluateScene(in.Scenes[i], indices[i], indexDirectory, output, config)
				if err != nil {
					r.Error = err.Error()
				}
				results[i] = r
				fmt.Printf("任意幅 %s 成功=%t %s\n", r.Session, r.Success, r.Error)
			}
		}()
	}
	for i := range in.Scenes {
		jobs <- i
	}
	close(jobs)
	wg.Wait()
	for _, r := range results {
		if !r.Success {
			return fmt.Errorf("観測失敗 %s:%s", r.Session, r.Error)
		}
	}
	for path, expected := range map[string]string{input: inputSHA, manifestPath: indexSHA, configPath: configSHA} {
		actual, e := hashFile(path)
		if e != nil || actual != expected {
			return fmt.Errorf("入力/索引/条件の前後変更")
		}
	}
	return writeJSON(filepath.Join(output, "manifest.json"), map[string]any{"success": true, "trial": in.Trial, "component_version": 166, "new_entry_selection": false, "input_sha256": inputSHA, "input_decoded_sha256": decoded, "index_input_sha256": manifest.InputSHA256, "index_input_decoded_sha256": manifest.InputDecodedSHA256, "index_input_differs_from_entries": manifest.InputSHA256 != inputSHA, "index_manifest_sha256": indexSHA, "config_sha256": configSHA, "config": config, "source_entry_count": in.ExpectedEntryCount, "scene_count": len(in.Scenes), "index_manifest_scene_count": len(manifest.Scenes), "scenes": results, "search": "Bid/Ask minmax木の原行順firstOutside。Raw再走査なし。"})
}
