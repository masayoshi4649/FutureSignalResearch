package main

import (
	"flag"
	"fmt"
	"os"
)

// main は索引構築又は任意幅観測をSHA固定した設定で実行します。
//
// 機能: 原板の一回索引化と幅ごとの高速評価を別工程へ分けます。
// 引数: CLI mode/input/sha256/output-dir/index-dir/index-sha256/config/config-sha256(string)、workers(int)。
// 返り値: ありません。失敗時は終了コード1です。
func main() {
	mode := flag.String("mode", "", "index又はevaluate")
	input := flag.String("input", "", "正式固定取得gzip又はJSON")
	inputSHA := flag.String("sha256", "", "固定入力物理SHA")
	output := flag.String("output-dir", "", "未作成出力先")
	index := flag.String("index-dir", "", "既存数値索引先")
	indexSHA := flag.String("index-sha256", "", "索引manifest SHA")
	config := flag.String("config", "", "任意幅条件JSON")
	configSHA := flag.String("config-sha256", "", "任意幅条件SHA")
	workers := flag.Int("workers", 4, "場並列数1～8")
	flag.Parse()
	var err error
	switch *mode {
	case "index":
		err = buildIndex(*input, *inputSHA, *output, *workers)
	case "evaluate":
		err = evaluateIndex(*input, *inputSHA, *index, *indexSHA, *config, *configSHA, *output, *workers)
	default:
		err = fmt.Errorf("modeはindex又はevaluate")
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
