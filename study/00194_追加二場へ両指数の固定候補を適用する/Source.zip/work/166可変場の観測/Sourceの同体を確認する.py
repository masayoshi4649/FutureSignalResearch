"""163の金融kernel不変と166で変更した入口wrapperを区別する。"""
from pathlib import Path
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OLD = ROOT / 'work/163任意幅Raw索引'


def sha(path: Path) -> str:
    """
    機能: Sourceの全bytesを指紋化する。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def functions(path: Path) -> dict:
    """
    機能: 既存Goの列0終端で純関数本文を比較用に抽出する。
    引数: path(Path)は対象の固定Source。
    返り値: dict[str,str]は関数名と宣言以降の本文。
    """
    text = path.read_text(encoding='utf-8')
    result = {}
    for match in re.finditer(r'^func (?:\([^\n]*?\) )?(\w+)\(', text, re.M):
        end = text.index('\n}', match.start()) + 2
        result[match[1]] = text[match.start():end]
    return result


def main() -> None:
    """
    機能: 旧Source不変・純金融関数不変・新wrapper差分を記録する。
    引数: なし。
    返り値: None。
    """
    copied = json.loads((HERE / '旧163からのコピー.json').read_text(encoding='utf-8'))
    assert all(sha(ROOT / row['旧源']) == row['旧SHA256'] for row in copied['新源'])
    allowed = {'index.go': {'readFixed', 'indexScene', 'buildIndex'},
               'query.go': {'evaluateScene', 'evaluateIndex'}}
    checked = []
    for filename, changed in allowed.items():
        old, new = functions(OLD / filename), functions(HERE / filename)
        assert old.keys() == new.keys()
        for name in old:
            if name not in changed:
                assert old[name] == new[name], (filename, name)
                checked.append(f'{filename}:{name}')
    unchanged = []
    for row in copied['新源']:
        if Path(row['新copy']).name not in ('index.go', 'query.go', 'go.mod'):
            assert sha(ROOT / row['新copy']) == row['旧SHA256']
            unchanged.append(row['新copy'])
    result = {'成功': True, '旧163変更': False, '本文同体の関数': checked,
              '全bytes同体の源': unchanged, '変更wrapper': allowed,
              '変更の範囲': '可変場数/取得数、期待品質未指定、Raw事前stat、q1後付け、後段全数値照合、異常時file close、由来表示',
              '先着探索・期限・金融計算変更': False, '未見価格読取': False,
              'Source': [{'path': str(p.relative_to(ROOT)), 'sha256': sha(p), 'bytes': p.stat().st_size}
                         for p in sorted(HERE.glob('*')) if p.is_file() and p.suffix in ('.go', '.py', '.exe')],
              }
    result['変更wrapper'] = {key: sorted(value) for key, value in allowed.items()}
    (HERE / '旧163純関数の同体.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '本文同体関数数': len(checked), '全bytes同体源数': len(unchanged)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
