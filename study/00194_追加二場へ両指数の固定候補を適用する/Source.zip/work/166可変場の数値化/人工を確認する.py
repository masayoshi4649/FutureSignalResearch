"""可変場のGo producer→q1後付け→数値adapterを人工価格だけで確認する。"""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import tempfile

import numpy as np
import arrays166 as adapter

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
GO = ROOT / 'work/166可変場の観測/可変場観測.exe'


def write(path: Path, value: object) -> str:
    """
    機能: 人工JSONを保存して固定SHAを返す。
    引数: path(Path)、value(object)。
    返り値: strはSHA256。
    """
    path.write_text(json.dumps(value, ensure_ascii=False), encoding='utf-8')
    return adapter.sha(path)


def run(arguments: list[str]) -> None:
    """
    機能: 人工だけを渡した可変場Go CLIの成功を確認する。
    引数: arguments(list[str])。
    返り値: None。
    """
    result = subprocess.run([str(GO), *arguments], capture_output=True, text=True, encoding='utf-8')
    assert result.returncode == 0, (result.stdout, result.stderr)


def main() -> None:
    """
    機能: 3場2case・case0場・C早期touch・未知金額・非166試行番号を確認する。
    引数: なし。
    返り値: None。
    """
    with tempfile.TemporaryDirectory(prefix='人工166_', dir=HERE) as temporary:
        directory = Path(temporary)
        base = int(datetime.datetime(2026, 1, 1, 0, 0, tzinfo=datetime.timezone.utc).timestamp())
        scenes = []
        for i, session in enumerate(('2026-01-01_Day', '2026-01-01_Night', '2026-01-02_Day')):
            start = base + 11100 * i
            raw = directory / f'{session}.jsonl'
            records = []
            for k in range(361 if i == 0 else 3):
                bid = 10000 + (20 * (k % 20) if i == 0 else 300 * k)
                records.append({'Symbol': '人工契約', 'CurrentPriceTime': datetime.datetime.fromtimestamp(start + 30*k, datetime.timezone.utc).isoformat(),
                                'CurrentPrice': bid + 5, 'Buy1': {'Price': bid, 'Qty': 1}, 'Sell1': {'Price': bid + 10, 'Qty': 1}})
                for depth in range(2, 11):
                    records[-1][f'Buy{depth}'] = {'Price': bid - depth, 'Qty': 1}
                    records[-1][f'Sell{depth}'] = {'Price': bid + 10 + depth, 'Qty': 1}
            raw.write_text(''.join(json.dumps(row) + '\n' for row in records), encoding='utf-8')
            stat = raw.stat()
            scenes.append({'session': session, 'contract': '人工契約', 'start': start, 'end': start + 10800, 'force_close': start + 10200,
                           'raw': {'path': str(raw), 'sha256': adapter.sha(raw)},
                           'expected_raw_stat': {'bytes': stat.st_size, 'mtime_ns': stat.st_mtime_ns}, 'entries': []})
        initial = directory / '索引前.json'
        initial_sha = write(initial, {'trial': 777, 'scenes': scenes, 'expected_entry_count': 0})
        index = directory / '索引'
        run(['--mode', 'index', '--input', str(initial), '--sha256', initial_sha, '--output-dir', str(index), '--workers', '2'])
        im = json.loads((index / 'manifest.json').read_text(encoding='utf-8'))
        assert im['trial'] == 777 and im['version'] == 166 and im['source_entry_count'] == 0
        for i, (scene, indexed) in enumerate(zip(scenes, im['scenes'], strict=True)):
            assert indexed['expected_raw_stat_compared'] and not indexed['expected_accepted_compared'] and not indexed['expected_quality_compared']
            scene['expected_accepted'] = indexed['rows']
            scene['expected_quality'] = indexed['quality']
            if i < 2:
                scene['entries'] = [{'id': f'人工{i}', 'side': 1, 'entry': {'time': scene['start'], 'index': 0, 'source_line': 1,
                    'last': 10005, 'bid': 10000, 'ask': 10010, 'quote_ok': True}}]
            Path(scene['raw']['path']).rename(Path(scene['raw']['path']).with_suffix('.以後未使用'))
        fixed = directory / '取得後.json'
        fixed_sha = write(fixed, {'trial': 777, 'scenes': scenes, 'expected_entry_count': 2})
        config = ROOT / 'work/163任意幅Raw索引/観測条件の雛形.json'
        observed = directory / '観測'
        run(['--mode', 'evaluate', '--input', str(fixed), '--sha256', fixed_sha,
             '--index-dir', str(index), '--index-sha256', adapter.sha(index / 'manifest.json'),
             '--config', str(config), '--config-sha256', adapter.sha(config), '--output-dir', str(observed), '--workers', '2'])
        table = adapter.read_table(index, adapter.sha(index / 'manifest.json'), observed, adapter.sha(observed / 'manifest.json'),
                                   config, adapter.sha(config), fixed, fixed_sha)
        assert table.arrays['label'].shape == (2, 2, 12, 4)
        assert table.session_order == tuple(scene['session'] for scene in scenes)
        assert table.evidence['実行試行'] == 777 and len(table.sessions) == 2
        c_hit = (table.arrays['label'] == 2) & (table.arrays['direction'] != 0)
        assert c_hit.any() and table.arrays['known'][c_hit].all()
        unknown = ~table.arrays['known']
        assert unknown.any() and np.all(table.arrays['net5'][unknown] == 0) and np.isnan(table.arrays['points'][unknown]).all()
        assert (table.arrays['label'] == 0).any()
        cache = adapter.save_table(table, directory / '数値')
        loaded = adapter.load_table(directory / '数値', cache)
        for key in table.arrays:
            assert np.array_equal(table.arrays[key], loaded.arrays[key], equal_nan=True)
    report = {'成功': True, '人工場数': 3, '人工case数': 2, 'case0場保持': True, '試行777受理': True,
              'q1前後の入力SHAを分離': True, '実Rawは索引後に再読不可': True, 'C早期touchの既知と未知net0のmask': True,
              'Nを保持': True, 'NPZ保存復元': True, '自然価格読取': False,
              'adapter_SHA256': adapter.sha(HERE / 'arrays166.py'), 'Go_SHA256': adapter.sha(GO),
              '固定163依存_SHA256': adapter.DEPENDENCY_SHA}
    (HERE / '人工確認.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False))


if __name__ == '__main__':
    main()
