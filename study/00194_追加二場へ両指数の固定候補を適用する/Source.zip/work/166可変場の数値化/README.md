# 可変場数・case数の金融配列

2026-11-15。`arrays166.py` は固定163 adapter（SHA `0231ea14ce03979a733d1a307c175266ff6aed2492dbc283162de63e153b23e6`）を指紋確認後にimportし、allocate/fill_case/保存/復元/RawOutcomeTableをそのまま呼ぶ。金融の別算術を複製せず、読取wrapperだけを一般化する。

APIは `read_table(index_dir,index_sha,observation_dir,observation_sha,config_path,config_sha,fixed_path,fixed_sha,fixed_decoded_sha=None)`。全引数はPath又は固定SHA。旧73/31,642case/特定日付を固定しない。case0場を `session_order` へ残し、case IDsは辞書順、side軸はBUY/SELL、後ろはwidth/horizonの固定順。session_indexはint16なので対象場は1〜32,767場を受ける。

索引を先にentries空で作り、入口生成後の別固定q1入力で観測した場合も、両入力SHAと元Raw由来を区別して検査する。163 manifest及び166部品manifestを受ける。`component_version=166` と研究 `trial` は別で、人工では正のtrial777も確認した。

`save_table` と `load_table` の形式は163と同じ。`.root_arrays()` のAPIも同じで、未知金額0は必ずknownと同時に使う。`direction` は `table.arrays['direction']` に保持する。ここでは旧163のstrict label・成熟時計を保存し、観測済みtouchで確定する164方式の再分類は研究側の別時計として明示的に適用する。未来のH完了を要求する旧strictと混同しない。

人工の再現は `python -X utf8 人工を確認する.py`。3場2case、case0場、索引後の原板再読不可、q1後付け、未指定期待品質、C早期touch、N、未知金額mask、NPZ保存復元を確認した。自然価格を読まない。

既知回帰は `旧73全配列の同体.json`。旧73保存索引だけから作ったGo166観測を数値化し、全31,642case・全31,863,494配列セル・dtype・case/場順が旧163と一致。原板再走査0、未見7場価格読取0。再現は `既知数値を確認する.py`（出力が未作成のときだけ）。

新価格への適用は候補・167以降のbook・F0固定後に行う。この部品版の166という名前を、未見検証を実行済みという意味で使わない。
