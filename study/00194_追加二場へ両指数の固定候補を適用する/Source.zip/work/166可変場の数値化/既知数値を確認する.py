"""既使用73場の最終Go166と数値adapterを旧163全配列へ比較する。"""
from pathlib import Path
import json
import numpy as np
import arrays166 as adapter

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def main() -> None:
    """
    機能: 既知索引のみで全caseの数値配列・case順・場順を同体確認する。
    引数: なし。
    返り値: None。
    """
    index = ROOT / 'work/163任意幅Raw索引/自然索引'
    observed = ROOT / 'work/166可変場の観測/旧73最終版の同体'
    config = ROOT / 'work/163任意幅Raw索引/観測条件の雛形.json'
    fixed = ROOT / 'inputs/00148_全1分入口母集団/固定取得入力.json.gz'
    assert adapter.sha(index / 'manifest.json') == '391217482497b2d872d73ffcd91cfe31c80a6d90e9c0e3ca12442ae6a7ccfa80'
    table = adapter.read_table(index, adapter.sha(index / 'manifest.json'), observed, adapter.sha(observed / 'manifest.json'),
        config, '2c965bc6892cdb351e79dadc53915ba06bf292b95e88fa2e67015a73174a9a5e',
        fixed, '99f10a996ca6e8b6c428061f1b48624bbc479ec84c500a9633818d47e4298e2a',
        '12c43fe60e0ffd5ffa44bec7b5f7dd3d60bb92b291e0008db23587dcf19536d3')
    old_dir = ROOT / 'work/163任意幅の数値化/自然数値表'
    complete = json.loads((old_dir / '完了.json').read_text(encoding='utf-8'))
    old = adapter.load_table(old_dir, complete['cache'])
    assert table.case_ids == old.case_ids and table.sessions == old.sessions and table.session_order == old.session_order
    assert table.widths == old.widths and table.horizons == old.horizons and table.horizon_ids == old.horizon_ids
    assert table.status_names == old.status_names and table.arrays.keys() == old.arrays.keys()
    compared = {}
    for key in table.arrays:
        a, b = table.arrays[key], old.arrays[key]
        assert a.dtype == b.dtype and np.array_equal(a, b, equal_nan=True), key
        compared[key] = {'shape': list(a.shape), 'dtype': str(a.dtype), 'cells': a.size}
    cache = adapter.save_table(table, HERE / '旧73の数値表')
    report = {'成功': True, '全場数': len(table.session_order), '全case数': len(table.case_ids),
              '全array': compared, '総比較セル': sum(row['cells'] for row in compared.values()),
              'case辞書順・場順・全dtype同体': True, 'Raw再走査': 0, '未見価格読取': False,
              '金融計算は固定163関数を直接再用': True, '自然配列は旧163と全一致': True,
              'adapter_SHA256': adapter.sha(HERE / 'arrays166.py'), 'cache': cache}
    (HERE / '旧73全配列の同体.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({key: value for key, value in report.items() if key not in ('全array', 'cache')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
