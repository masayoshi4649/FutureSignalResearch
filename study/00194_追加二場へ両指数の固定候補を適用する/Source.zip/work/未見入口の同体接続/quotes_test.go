package entrybridge

import (
	"bytes"
	"compress/gzip"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"errors"
	"math"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
	"time"

	population "github.com/masayoshi4649/SessionTradeExecuter/entrypopulation148"
)

const artificialIndexStart = 1794000000.0

type artificialIndexRow struct {
	At             float64
	Line           int64
	Last, Bid, Ask float64
	Flag           uint64
}

// artificialParserTime は旧Raw parserと同じ経路で人工秒時計を作ります。
//
// 引数: nanoseconds(int64)は人工基準秒からのナノ秒です。
// 返り値: float64はUnixNanoをfloat化して1e9で割った正本時計です。
func artificialParserTime(nanoseconds int64) float64 {
	return float64(time.Unix(int64(artificialIndexStart), nanoseconds).UnixNano()) / 1e9
}

// artificialIndexBytes は各列を独立に符号化した人工48byte列を作ります。
//
// 引数: rows([]artificialIndexRow)は人工原行です。
// 返り値: []byteは固定magicとリトルエンディアンrecord列です。
func artificialIndexBytes(rows []artificialIndexRow) []byte {
	body := []byte("NQIDX163")
	for _, row := range rows {
		record := make([]byte, 48)
		binary.LittleEndian.PutUint64(record[0:8], math.Float64bits(row.At))
		binary.LittleEndian.PutUint64(record[8:16], uint64(row.Line))
		binary.LittleEndian.PutUint64(record[16:24], math.Float64bits(row.Last))
		binary.LittleEndian.PutUint64(record[24:32], math.Float64bits(row.Bid))
		binary.LittleEndian.PutUint64(record[32:40], math.Float64bits(row.Ask))
		binary.LittleEndian.PutUint64(record[40:48], row.Flag)
		body = append(body, record...)
	}
	return body
}

// artificialIndexScene は自然入力へ触れず人工gzipと固定参照を作ります。
//
// 引数: t(*testing.T)、decoded([]byte)、mutate(func([]byte)[]byte|nil)は圧縮後の破損操作です。
// 返り値: Sceneは人工索引だけを参照する場です。
func artificialIndexScene(t *testing.T, decoded []byte, mutate func([]byte) []byte) Scene {
	t.Helper()
	var encoded bytes.Buffer
	writer := gzip.NewWriter(&encoded)
	if _, err := writer.Write(decoded); err != nil {
		t.Fatal(err)
	}
	if err := writer.Close(); err != nil {
		t.Fatal(err)
	}
	body := append([]byte(nil), encoded.Bytes()...)
	if mutate != nil {
		body = mutate(body)
	}
	path := filepath.Join(t.TempDir(), "人工索引.bin.gz")
	if err := os.WriteFile(path, body, 0600); err != nil {
		t.Fatal(err)
	}
	sum := sha256.Sum256(body)
	ref := FileRef{Path: path, Bytes: int64(len(body)), SHA256: hex.EncodeToString(sum[:])}
	return Scene{Scene: population.Scene{Session: "人工_Day", Contract: "人工限月", Start: artificialIndexStart, End: artificialIndexStart + 60,
		Raw: FileRef{Path: "人工Raw本文は未読", SHA256: strings.Repeat("a", 64), Bytes: 1}}, QuoteIndex: &ref}
}

// TestIndex48RetainsPhysicalQuotes は同秒・悪BBOを落とさず全数値bitを確認します。
//
// 引数: t(*testing.T)はGo検査器です。
// 返り値: ありません。原行又は数値bitの差を失敗として報告します。
func TestIndex48RetainsPhysicalQuotes(t *testing.T) {
	rows := []artificialIndexRow{
		{At: artificialParserTime(250000000), Line: 1, Last: 39000.25, Bid: 39000, Ask: 39005, Flag: 1},
		{At: artificialParserTime(250000000), Line: 5, Last: 39001, Bid: math.Copysign(0, -1), Ask: 39005, Flag: 0},
		{At: artificialParserTime(500000000), Line: 8, Last: 39002, Bid: 39010, Ask: 39005, Flag: 0},
		{At: artificialParserTime(1000000000), Line: 9, Last: 39003, Bid: 39000, Ask: 39005, Flag: 1},
	}
	scene := artificialIndexScene(t, artificialIndexBytes(rows), nil)
	scene.ExpectedAccepted = int64(len(rows))
	scene.ExpectedQuality = &population.Counts{Delivered: int64(len(rows))}
	got := []population.Quote{}
	proof, err := (Index48Provider{}).Scan(scene, func(q population.Quote) error {
		got = append(got, q)
		return nil
	})
	if err != nil {
		t.Fatal(err)
	}
	if len(got) != len(rows) || proof.Rows != int64(len(rows)) || proof.OriginalClockPreserved || proof.RawReference != scene.Raw || proof.ActualSHA256 != scene.QuoteIndex.SHA256 || !reflect.DeepEqual(proof.StatBefore, proof.StatAfter) {
		t.Fatalf("全体証跡差: %+v", proof)
	}
	for i, q := range got {
		row := rows[i]
		if q.Index != int64(i) || q.SourceLine != row.Line || q.QuoteOK != (row.Flag == 1) {
			t.Fatalf("原行識別/悪BBO保持差: %+v", q)
		}
		for name, pair := range map[string][2]float64{"time": {q.Time, row.At}, "last": {q.Last, row.Last}, "bid": {q.Bid, row.Bid}, "ask": {q.Ask, row.Ask}} {
			if math.Float64bits(pair[0]) != math.Float64bits(pair[1]) {
				t.Fatalf("%sのbit差: 原=%016x 生成=%016x", name, math.Float64bits(pair[1]), math.Float64bits(pair[0]))
			}
		}
		parsed, err := time.Parse(time.RFC3339Nano, q.Clock)
		if err != nil || !strings.HasSuffix(q.Clock, "+09:00") || math.Float64bits(float64(parsed.UnixNano())/1e9) != math.Float64bits(row.At) {
			t.Fatalf("JST表記又は再解釈bit差: %q/%v", q.Clock, err)
		}
	}
}

// TestCanonicalClockKeepsParserFloat は旧parserと同じUnixNano変換の小数時計を確認します。
//
// 引数: t(*testing.T)はGo検査器です。
// 返り値: ありません。JST再整形後のfloatbit差を失敗として報告します。
func TestCanonicalClockKeepsParserFloat(t *testing.T) {
	for i := int64(0); i < 4096; i++ {
		at := float64(time.Unix(int64(artificialIndexStart), (i*982451653)%1e9).UnixNano()) / 1e9
		clock, err := canonicalClock(at)
		if err != nil {
			t.Fatalf("旧parser由来floatの再整形を拒否: %.17g/%v", at, err)
		}
		parsed, err := time.Parse(time.RFC3339Nano, clock)
		if err != nil || math.Float64bits(float64(parsed.UnixNano())/1e9) != math.Float64bits(at) {
			t.Fatalf("小数秒bit差: %.17g/%q/%v", at, clock, err)
		}
	}
	for _, at := range []float64{math.NaN(), math.Inf(1), -1, 9e9 + 1, 1e-10} {
		if clock, err := canonicalClock(at); err == nil {
			t.Fatalf("範囲外又はns再現不能を受理: %.17g/%q", at, clock)
		}
	}
}

// TestIndex48RejectsBrokenRecords は行順・時計・正常旗・record長の破損を拒否します。
//
// 引数: t(*testing.T)はGo検査器です。
// 返り値: ありません。破損を正式成功にした場合に失敗します。
func TestIndex48RejectsBrokenRecords(t *testing.T) {
	valid := artificialIndexRow{At: artificialIndexStart + 1, Line: 2, Last: 39000, Bid: 38995, Ask: 39005, Flag: 1}
	tests := []struct {
		name string
		rows []artificialIndexRow
	}{
		{"flag範囲", []artificialIndexRow{{At: valid.At, Line: 2, Last: 39000, Bid: 38995, Ask: 39005, Flag: 2}}},
		{"正常BBOをflag0", []artificialIndexRow{{At: valid.At, Line: 2, Last: 39000, Bid: 38995, Ask: 39005, Flag: 0}}},
		{"悪BBOをflag1", []artificialIndexRow{{At: valid.At, Line: 2, Last: 39000, Bid: 39005, Ask: 38995, Flag: 1}}},
		{"同じ物理行", []artificialIndexRow{valid, valid}},
		{"物理行後退", []artificialIndexRow{valid, {At: valid.At, Line: 1, Last: 39000, Bid: 38995, Ask: 39005, Flag: 1}}},
		{"時計後退", []artificialIndexRow{valid, {At: artificialIndexStart + 0.5, Line: 3, Last: 39000, Bid: 38995, Ask: 39005, Flag: 1}}},
		{"場前", []artificialIndexRow{{At: artificialIndexStart - 1, Line: 1, Last: 39000, Bid: 38995, Ask: 39005, Flag: 1}}},
		{"場後", []artificialIndexRow{{At: artificialIndexStart + 61, Line: 1, Last: 39000, Bid: 38995, Ask: 39005, Flag: 1}}},
		{"最終価格0", []artificialIndexRow{{At: valid.At, Line: 2, Last: 0, Bid: 38995, Ask: 39005, Flag: 1}}},
		{"時計NaN", []artificialIndexRow{{At: math.NaN(), Line: 2, Last: 39000, Bid: 38995, Ask: 39005, Flag: 1}}},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			scene := artificialIndexScene(t, artificialIndexBytes(test.rows), nil)
			if _, err := (Index48Provider{}).Scan(scene, func(population.Quote) error { return nil }); err == nil {
				t.Fatal("破損recordを正式受理")
			}
		})
	}
	for _, test := range []struct {
		name    string
		decoded []byte
	}{
		{"magic", append([]byte("NQIDX164"), artificialIndexBytes([]artificialIndexRow{valid})[8:]...)},
		{"空record", []byte("NQIDX163")},
		{"47byte", artificialIndexBytes([]artificialIndexRow{valid})[:8+47]},
		{"49byte", append(artificialIndexBytes([]artificialIndexRow{valid}), 0)},
	} {
		t.Run(test.name, func(t *testing.T) {
			scene := artificialIndexScene(t, test.decoded, nil)
			if _, err := (Index48Provider{}).Scan(scene, func(population.Quote) error { return nil }); err == nil {
				t.Fatal("magic又はrecord終端破損を正式受理")
			}
		})
	}
}

// TestIndex48RejectsBrokenGzipAndReferences は全圧縮列・物理SHA・件数の最終検査を確認します。
//
// 引数: t(*testing.T)はGo検査器です。
// 返り値: ありません。callback済みでも終端検査が失敗になることを確認します。
func TestIndex48RejectsBrokenGzipAndReferences(t *testing.T) {
	body := artificialIndexBytes([]artificialIndexRow{{At: artificialIndexStart, Line: 1, Last: 39000, Bid: 38995, Ask: 39005, Flag: 1}})
	for _, test := range []struct {
		name   string
		mutate func([]byte) []byte
	}{
		{"CRC", func(data []byte) []byte { data[len(data)-8] ^= 0x80; return data }},
		{"gzip切断", func(data []byte) []byte { return data[:len(data)-3] }},
		{"gzip後の不正列", func(data []byte) []byte { return append(data, []byte("末尾破損0123456789")...) }},
	} {
		t.Run(test.name, func(t *testing.T) {
			scene := artificialIndexScene(t, body, test.mutate)
			if _, err := (Index48Provider{}).Scan(scene, func(population.Quote) error { return nil }); err == nil {
				t.Fatal("圧縮終端破損を正式受理")
			}
		})
	}
	for _, which := range []string{"物理SHA", "bytes", "ExpectedAccepted", "品質Delivered"} {
		t.Run(which, func(t *testing.T) {
			scene := artificialIndexScene(t, body, nil)
			switch which {
			case "物理SHA":
				scene.QuoteIndex.SHA256 = strings.Repeat("0", 64)
			case "bytes":
				scene.QuoteIndex.Bytes++
			case "ExpectedAccepted":
				scene.ExpectedAccepted = 2
			case "品質Delivered":
				scene.ExpectedQuality = &population.Counts{Delivered: 2}
			}
			calls := 0
			_, err := (Index48Provider{}).Scan(scene, func(population.Quote) error { calls++; return nil })
			if err == nil {
				t.Fatal("入力参照又は件数差を正式受理")
			}
			if which != "bytes" && calls != 1 {
				t.Fatalf("終端前の原行供給数差: %d", calls)
			}
		})
	}
}

// TestIndex48StopsOnVisitorError は供給先失敗を成功や部分継続へ置換しません。
//
// 引数: t(*testing.T)はGo検査器です。
// 返り値: ありません。callback拒否がそのまま返ることを確認します。
func TestIndex48StopsOnVisitorError(t *testing.T) {
	body := artificialIndexBytes([]artificialIndexRow{{At: artificialIndexStart, Line: 1, Last: 39000, Bid: 38995, Ask: 39005, Flag: 1}})
	scene := artificialIndexScene(t, body, nil)
	want := errors.New("人工callback拒否")
	_, err := (Index48Provider{}).Scan(scene, func(population.Quote) error { return want })
	if !errors.Is(err, want) {
		t.Fatalf("callback失敗の置換: %v", err)
	}
	if _, err := (Index48Provider{}).Scan(scene, nil); err == nil {
		t.Fatal("callbackなしを受理")
	}
	scene.QuoteIndex = nil
	if _, err := (Index48Provider{}).Scan(scene, func(population.Quote) error { return nil }); err == nil {
		t.Fatal("索引参照なしを受理")
	}
}
