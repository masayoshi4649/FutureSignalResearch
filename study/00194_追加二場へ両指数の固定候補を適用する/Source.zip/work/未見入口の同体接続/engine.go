package entrybridge

import (
	"encoding/json"
	"fmt"
	"math"
	"os"

	population "github.com/masayoshi4649/SessionTradeExecuter/entrypopulation148"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	features "github.com/masayoshi4649/SessionTradeExecuter/features148"
	bank115 "github.com/masayoshi4649/SessionTradeExecuter/threeframe115"
)

// validatePlan は場順と入力scopeを市場本文を開く前に確認します。
//
// 機能: 旧73等の件数固定を避け、呼出側が固定した場だけを対象にします。
// 引数: plan(Plan)。返り値: errorです。
func validatePlan(plan Plan) error {
	if plan.Version != 1 || plan.Trial < 1 || len(plan.Scenes) == 0 || plan.Transport != "index48" {
		return fmt.Errorf("計画版/試行/対象/transport不正")
	}
	seen := map[string]bool{}
	end := 0.0
	for _, s := range plan.Scenes {
		if s.Session == "" || s.Contract == "" || seen[s.Session] || !finite(s.Start, s.End, s.ForceClose) || s.Start < end || s.End <= s.Start || s.ForceClose <= s.Start || s.ForceClose > s.End || s.Cutoff != 0 || len(s.Publications) != 0 {
			return fmt.Errorf("対象場scope/順序/二重公表/非対応cutoff差:%s", s.Session)
		}
		seen[s.Session] = true
		end = s.End
	}
	return nil
}

// seedInfo はcoldとsealed種を区別します。
//
// 機能: 私有種の数値を外から作らず証跡だけを取り出します。
// 引数: seed(*bank115.Seed)。返り値: *bank115.SeedInfoです。
func seedInfo(seed *bank115.Seed) *bank115.SeedInfo {
	if seed == nil {
		return nil
	}
	info := seed.Info()
	return &info
}

// scanScene は一つの索引原行で技術公表と1分配送を接続します。
//
// 機能: 100X.Computeと148出生状態を未変更で再用します。
// 引数: scene(Scene)、previous(*bank115.Seed)、bank(*rules.Bank)、cache(*population.Publications)、provider(QuoteProvider)。
// 返り値: *population.Population/SceneEvidence/bank115.Seed/errorです。
func scanScene(scene Scene, previous *bank115.Seed, bank *rules.Bank, cache *population.Publications, provider QuoteProvider) (*population.Population, SceneEvidence, bank115.Seed, error) {
	out := SceneEvidence{Session: scene.Session, Contract: scene.Contract, Start: scene.Start, End: scene.End, EntryLimit: math.Min(scene.ForceClose, scene.End-3900), InputSeed: seedInfo(previous), Counts: map[string]int{}, Statuses: map[string]int{}}
	minutes, proof1, err := LoadMinutes(scene)
	out.CSV1m = proof1
	if err != nil {
		return nil, out, bank115.Seed{}, err
	}
	chart := chartScene(scene.Session, scene.Contract, scene.Start, scene.End)
	children, proof5, err := loadChildren(chart, scene.CSV5m)
	out.CSV5m = proof5
	if err != nil {
		return nil, out, bank115.Seed{}, err
	}
	publisher, err := bank115.BeginSession(chart, children, previous)
	if err != nil {
		return nil, out, bank115.Seed{}, err
	}
	if err = bank.StartSession(scene.Session, scene.Contract); err != nil {
		return nil, out, bank115.Seed{}, err
	}
	if err = cache.StartSession(scene.Session, scene.Contract); err != nil {
		return nil, out, bank115.Seed{}, err
	}
	p := population.NewPopulation(scene.Scene, features.Compute)
	publications := []Publication{}
	projected := []rules.Publication{}
	cursor := 0
	quotes, err := provider.Scan(scene, func(q population.Quote) error {
		frames, e := publisher.AdvanceObserved(q.Time, uint64(q.Index)+1)
		if e != nil {
			return e
		}
		for _, f := range frames {
			pub := Publication{Stamp: rules.Stamp{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine)}, Frame: f}
			value, e := projectPublication(pub)
			if e != nil {
				return e
			}
			if e = bank.Add(value); e != nil {
				return e
			}
			if e = cache.Record(value); e != nil {
				return e
			}
			publications = append(publications, pub)
			projected = append(projected, value)
		}
		snapshot, e := bank.Current(rules.Quote{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine), Last: q.Last})
		if e != nil {
			return e
		}
		batch := DeliverMinutes(minutes, &cursor, q)
		for i := range batch {
			batch[i].Context.Refs = append([]rules.Ref(nil), snapshot.Refs...)
			if pub, ok := snapshot.Frames[900]; ok {
				window, exists := cache.Window(pub.Frame.Frame.ID)
				if !exists || window.Bands != snapshot.BB15 {
					return fmt.Errorf("BB正本と当時Bank差")
				}
				batch[i].Context.BBWindowID = window.ID
				batch[i].Context.BB15 = window.Bands
			}
		}
		return p.Step(snapshot, q, batch)
	})
	out.Quotes = quotes
	if err != nil {
		return nil, out, bank115.Seed{}, err
	}
	p.Finish()
	rawSeed, _, err := publisher.Seal()
	if err != nil {
		return nil, out, bank115.Seed{}, err
	}
	out.RawEndSeed = rawSeed.Info()
	next, err := scheduledSeed(chart, children, previous)
	if err != nil {
		return nil, out, bank115.Seed{}, err
	}
	out.ScheduledEndSeed = next.Info()
	out.CSV1m.Delivered = cursor
	out.CSV1m.EOFUndelivered = len(minutes) - cursor
	out.PublicationCount = len(publications)
	body, err := json.Marshal(publications)
	if err != nil {
		return nil, out, bank115.Seed{}, err
	}
	out.PublicationSHA256 = digest(body)
	body, err = json.Marshal(projected)
	if err != nil {
		return nil, out, bank115.Seed{}, err
	}
	out.ProjectedPublicationSHA256 = digest(body)
	for key, value := range p.Counts {
		out.Counts[key] = value
	}
	for _, a := range p.Acquisitions {
		out.Statuses[a.Status]++
	}
	out.BBWindows = cache.Windows()
	return p, out, next, nil
}

// bindCases は旧C1を参照せず実取得の同一物理q1を一件にします。
//
// 機能: 出生順のcanonicalと全取得eventの対応を保ちます。
// 引数: out(*Generated)。返り値: errorです。
func bindCases(out *Generated) error {
	type key struct {
		session, contract string
		time              float64
		index, line       int64
	}
	byPhysical := map[key]int{}
	for _, a := range out.Acquisitions {
		if a.Status != "filled" {
			continue
		}
		if a.Q1 == nil {
			return fmt.Errorf("filledのq1がない")
		}
		q := *a.Q1
		k := key{a.Session, a.Contract, q.Time, q.Index, q.SourceLine}
		ci, exists := byPhysical[k]
		if !exists {
			ci = len(out.Cases)
			byPhysical[k] = ci
			out.Cases = append(out.Cases, Case{ID: fmt.Sprintf("148/%s/q1/%d/%d", a.Session, q.Index, q.SourceLine), Session: a.Session, Contract: a.Contract, CanonicalEventID: a.EventID, Entry: q})
		} else if out.Cases[ci].Entry != q {
			return fmt.Errorf("同物理q1の価格全値差")
		}
		id, buy, sell := out.Cases[ci].ID, "original", "reverse"
		a.CaseID, a.BuyStream, a.SellStream = &id, &buy, &sell
	}
	return nil
}

// Generate はF0へ固定した入力だけから非金融の出生・特徴・取得を生成します。
//
// 機能: N/T向けの母集団を作り、旧C1・ラベル・選択候補へ依存しません。
// 引数: plan(Plan)、provider(QuoteProvider|nil)はnilならIndex48Provider。
// 返り値: Generated/errorです。全入力成功後にだけWriteできます。
func Generate(plan Plan, provider QuoteProvider) (Generated, error) {
	out := Generated{Plan: plan, Scenes: []SceneEvidence{}, Ledger: []*population.LedgerRow{}, Features: []population.FeatureRecord{}, Acquisitions: []*population.Acquisition{}, Cases: []Case{}, Catalog: features.Catalog(), Counts: map[string]int{}}
	if err := validatePlan(plan); err != nil {
		return out, err
	}
	if provider == nil {
		if err := validateIndexManifest(plan); err != nil {
			return out, err
		}
		provider = Index48Provider{}
	}
	previous, bank, cache, err := bootstrap(plan)
	if err != nil {
		return out, err
	}
	catalogBody, err := json.Marshal(out.Catalog)
	if err != nil || digest(catalogBody) != population.CatalogCompactSHA {
		return out, fmt.Errorf("固定100列辞書差:%v", err)
	}
	for _, s := range plan.Scenes {
		p, evidence, next, e := scanScene(s, previous, bank, cache, provider)
		if e != nil {
			return out, fmt.Errorf("入口接続:%s:%w", s.Session, e)
		}
		previous = &next
		out.Scenes = append(out.Scenes, evidence)
		out.Ledger = append(out.Ledger, p.Ledger...)
		out.Features = append(out.Features, p.Features...)
		out.Acquisitions = append(out.Acquisitions, p.Acquisitions...)
		for key, value := range evidence.Counts {
			out.Counts[key] += value
		}
		out.Counts["taken_events"] += len(p.Taken)
		fmt.Fprintf(os.Stderr, "入口接続 session=%s q0累計=%d 特徴累計=%d 取得累計=%d\n", s.Session, len(out.Ledger), len(out.Features), out.Counts["taken_events"])
	}
	if err = bindCases(&out); err != nil {
		return out, err
	}
	out.Counts["physical_cases"] = len(out.Cases)
	return out, nil
}
