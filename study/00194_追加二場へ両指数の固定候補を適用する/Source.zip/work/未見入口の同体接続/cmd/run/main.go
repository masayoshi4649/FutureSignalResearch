package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"path/filepath"

	bridge "entrybridge"
)

// main は明示実行指定と固定計画だけを受けるCLIです。
//
// 機能: 非金融母集団を未作成出力先へ生成し、任意で既知回帰を確認します。
// 引数: CLI引数。返り値: ありません。失敗時は非0終了です。
func main() {
	planPath := flag.String("plan", "", "事前固定計画JSON")
	planSHA := flag.String("plan-sha", "", "計画物理SHA256")
	planBytes := flag.Int64("plan-bytes", 0, "計画bytes")
	output := flag.String("output", "", "未作成出力先")
	reference := flag.String("known-reference", "", "既知場だけの参照JSON")
	execute := flag.Bool("execute-after-f0", false, "固定済みF0後だけ明示指定")
	flag.Parse()
	if !*execute || *output == "" {
		fmt.Fprintln(os.Stderr, "固定済みF0後の明示実行と未作成出力先が必要")
		os.Exit(2)
	}
	ref := bridge.FileRef{Path: *planPath, SHA256: *planSHA, Bytes: *planBytes}
	plan, err := bridge.LoadPlan(ref)
	if err != nil {
		fail(err)
	}
	out, err := bridge.Generate(plan, nil)
	if err != nil {
		fail(err)
	}
	var report map[string]any
	if *reference != "" {
		var refs bridge.References
		body, e := os.ReadFile(*reference)
		if e != nil {
			fail(e)
		}
		if e = json.Unmarshal(body, &refs); e != nil {
			fail(e)
		}
		report, err = bridge.CompareReferences(out, refs)
		if err != nil {
			fail(err)
		}
	}
	if err = bridge.Write(*output, ref, out); err != nil {
		fail(err)
	}
	if report != nil {
		body, e := json.MarshalIndent(report, "", "  ")
		if e != nil {
			fail(e)
		}
		if e = os.WriteFile(filepath.Join(*output, "旧148との同体.json"), append(body, '\n'), 0600); e != nil {
			fail(e)
		}
	}
	fmt.Printf("接続成功 場=%d q0=%d 特徴=%d 物理取得=%d\n", len(out.Scenes), len(out.Ledger), len(out.Features), len(out.Cases))
}

// fail はエラーを可視化して自然結果成功を残しません。
//
// 機能: CLIの失敗を非0終了にします。
// 引数: err(error)。返り値: ありません。
func fail(err error) { fmt.Fprintln(os.Stderr, err); os.Exit(1) }
