# 当時100特徴とq0→q1の可変場接続

2026-11-14。旧148の `features.Compute`、`NewPopulation/Step/Finish`、旧115の技術公開器、旧118のBB/RVOL Bankを未変更でimportする。1分CSV規則は147から型・名前だけを調整して移した。旧C1・将来ラベル・候補選択は入力に持たない。N/Tの別期間適用のための非金融母集団を作る。

## 確認した同体

`旧73全件回帰/旧148との同体.json`：旧73場のq0 40,544件、適格特徴35,339件×両側100列、全35,339取得/取消状態、物理q1 31,632件、115公表全文12,794件が一致。q0/q1秒時計はfloat bitも一致した。

文字列 `Clock` は48byte索引に保存されていないため、索引の正本timeからJST ISO8601へ再整形した。元CurrentPriceTime原文との文字列同体は主張しない。旧C1が優先する物理case名とstream対応も新規N/Tでは使わず、同体比較ではその3fieldだけを除いた。取得時刻・方向の実側価格・取消理由等は比較した。

## Go APIとCLI

module `entrybridge`。`LoadPlan(FileRef) (Plan,error)` → `Generate(Plan,QuoteProvider|nil) (Generated,error)` → `Write(directory,planRef,out) error`。nil providerは `Index48Provider`。Clock原文sidecarが必要になった場合はproviderを追加できる。

計画はversion=1、trialは実行試行、transport=`index48`。対象場数・case数を固定しない。`history_plan` は旧122の計画、`prior_publications` は旧122の保存公表、`index_manifest` は対象索引の完成manifestを、それぞれpath/bytes/SHAで指定する。

`history_through` が空ならcold開始。旧73場後に延長するときは `2026-11-10_Day` を指定する。旧73の5分CSVを既存入力口で予定Endまで順に進め、115の本物の私有Seedを作る。BB/RVOLと由来窓は旧122の実配送公表を別途再生する。保存SeedInfoだけから数値種を組み立てない。

各 `scenes` はsession/contract/start/end/force_close/raw/expected_accepted/expected_quality、`csv_1m`、`csv_5m`、`quote_index` を持つ。各ファイル参照はpath/bytes/SHA。索引は `NQIDX163` + 48byteの既存形式で、manifestの元Raw path/SHA/品質と照合する。CSVの既使用path表現は公表IDの由来にもなるため変えない。

```powershell
go build -o 入口同体接続.exe ./cmd/run
.\入口同体接続.exe --execute-after-f0 --plan 計画.json --plan-sha <固定SHA> --plan-bytes <bytes> --output <未作成先>
```

`--known-reference 参照.json` を付けると、固定された旧出生台帳・特徴・取得対応gzip、旧122公表へ数値同体を確認してから保存する。旧場計画の再作成は `旧場計画を作る.py`。このスクリプトは旧73場終端をassertし、未知期へアクセスしない。

## 出力と境界

出生台帳・当時特徴・取得対応・物理取得・金融観測用固定取得入力を各一度gzip保存し、全成功後の `完了.json` に指紋を残す。全q0、未知X、未取得、0件場を残す。固定取得入力は採用取引ではなく、両実側を評価するための母集団。

q0は1分足のEnd+60秒以後の最初の受理Raw。q1は別index/別物理行、1秒以上後の最初の正常BBO。TTL30秒の等号失効、品質・限界の優先順、`min(ForceClose,End-3900)` を旧148のまま使う。5/15/30分は指標の時間軸であり、新規判断をその区切りへ変更しない。

この接続器はRawを再解析しない。新しい索引のproducerは `work/166可変場の観測`。新場のRaw/CSV自然実行は、候補・166等のbook・F0固定後にだけ行う。現時点の確認に未見7場の価格は一切使用していない。
