module entrybridge

go 1.24.2

require (
	github.com/masayoshi4649/SessionTradeExecuter/entrypopulation148 v0.0.0
	github.com/masayoshi4649/SessionTradeExecuter/entryrules118 v0.0.0
	github.com/masayoshi4649/SessionTradeExecuter/features148 v0.0.0
	github.com/masayoshi4649/SessionTradeExecuter/threeframe v0.0.0
	github.com/masayoshi4649/SessionTradeExecuter/threeframe115 v0.0.0
	github.com/masayoshi4649/SessionTradeExecuter/threeframeinput v0.0.0
)

replace github.com/masayoshi4649/SessionTradeExecuter/entrypopulation148 => ../148全1分知得の入口母集団
replace github.com/masayoshi4649/SessionTradeExecuter/entryrules118 => ../118複数技法の入口条件
replace github.com/masayoshi4649/SessionTradeExecuter/features148 => ../148全1分候補の当時特徴
replace github.com/masayoshi4649/SessionTradeExecuter/threeframe => ../三時間軸の公開器
replace github.com/masayoshi4649/SessionTradeExecuter/threeframe115 => ../115三時間軸と方向性の公開
replace github.com/masayoshi4649/SessionTradeExecuter/threeframeinput => ../三時間軸の市場入力口
