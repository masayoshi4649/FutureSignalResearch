package entrybridge

import (
	"strings"
	"testing"

	frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
	bank115 "github.com/masayoshi4649/SessionTradeExecuter/threeframe115"
)

// seedChildren は実価格を含まない三時間軸の人工子足を作ります。
//
// 機能: 数値種と限月切替の契約だけを検証します。
// 引数: scene(frame.Session)。返り値: []frame.ChildBarです。
func seedChildren(scene frame.Session) []frame.ChildBar {
	out := []frame.ChildBar{}
	for at := scene.Start; at < scene.End; at += 300 {
		p := 1000 + (at-scene.Start)/300
		out = append(out, frame.ChildBar{Start: at, End: at + 300, OHLC: frame.OHLC{Open: p, High: p + 2, Low: p - 1, Close: p + 1}, Volume: 10, Closed: true, VolumeKnown: true, Input: frame.FileRef{Path: "人工5分.csv", SHA256: strings.Repeat("a", 64), Bytes: 1}, Row: uint64(len(out) + 2)})
	}
	return out
}

// TestScheduledSeed はRaw末尾種と予定End種、同限月と別限月を区別します。
//
// 機能: 保存Infoから種を捏造せず既存115だけでcarryを確認します。
// 引数: t(*testing.T)。返り値: ありません。
func TestScheduledSeed(t *testing.T) {
	scene := chartScene("人工前場", "A", 300, 7500)
	children := seedChildren(scene)
	scheduled, err := scheduledSeed(scene, children, nil)
	if err != nil {
		t.Fatal(err)
	}
	b, err := bank115.BeginSession(scene, children, nil)
	if err != nil {
		t.Fatal(err)
	}
	if _, err = b.AdvanceObserved(scene.End-301, 17); err != nil {
		t.Fatal(err)
	}
	rawEnd, _, err := b.Seal()
	if err != nil {
		t.Fatal(err)
	}
	if rawEnd.Info().SHA256 == scheduled.Info().SHA256 || rawEnd.Info().Old.ObservedAt == scheduled.Info().Old.ObservedAt {
		t.Fatal("Raw末尾と予定Endを混同")
	}
	for _, contract := range []string{"A", "B"} {
		nextScene := chartScene("人工後場"+contract, contract, 7800, 15000)
		next, err := bank115.BeginSession(nextScene, seedChildren(nextScene), &scheduled)
		if err != nil {
			t.Fatal(err)
		}
		frames, err := next.AdvanceObserved(nextScene.Start+360, 5)
		if err != nil {
			t.Fatal(err)
		}
		if len(frames) == 0 || frames[0].Frame.WidthSeconds != 300 {
			t.Fatal("最初の5分公表なし")
		}
		if contract == "A" && frames[0].Frame.Technical.HistoryBars <= 1 {
			t.Fatal("同限月の技術種がcoldになった")
		}
		if contract == "B" && frames[0].Frame.Technical.HistoryBars != 1 {
			t.Fatal("別限月へ技術種を持越した")
		}
	}
}
