package entrybridge

import (
	"bytes"
	"crypto/sha256"
	"encoding/csv"
	"encoding/hex"
	"fmt"
	"io"
	"math"
	"os"
	"strconv"
	"strings"
	"time"

	population "github.com/masayoshi4649/SessionTradeExecuter/entrypopulation148"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// MinuteEvidence は147のCSV検査値を同じ意味で保存します。
type MinuteEvidence struct {
	Reference      FileRef          `json:"reference"`
	Rows           int              `json:"rows"`
	GridMinutes    int              `json:"grid_minutes"`
	Missing        int              `json:"missing"`
	PriceKnown     int              `json:"price_known"`
	VolumeKnown    int              `json:"volume_known"`
	Delivered      int              `json:"delivered"`
	EOFUndelivered int              `json:"eof_undelivered"`
	StatBefore     map[string]int64 `json:"stat_before"`
	StatAfter      map[string]int64 `json:"stat_after"`
}

// minuteDigest は固定原本bytesのSHA256を求めます。
//
// 引数: body([]byte)は読み切ったCSV原本です。
// 返り値: stringは小文字のSHA256です。
func minuteDigest(body []byte) string {
	v := sha256.Sum256(body)
	return hex.EncodeToString(v[:])
}

// minuteStat は価格値を含まないサイズと更新時計を保存します。
//
// 引数: value(os.FileInfo)はCSVのstatです。
// 返り値: map[string]int64はbytesとmtime_nsです。
func minuteStat(value os.FileInfo) map[string]int64 {
	return map[string]int64{"bytes": value.Size(), "mtime_ns": value.ModTime().UnixNano()}
}

// minuteFinite は147と同じ有限性を検査します。
//
// 引数: values(...float64)は検査値です。
// 返り値: boolは全値が有限であることです。
func minuteFinite(values ...float64) bool {
	for _, v := range values {
		if math.IsNaN(v) || math.IsInf(v, 0) {
			return false
		}
	}
	return true
}

// minuteNumber は欠測と非有限を既知0へ補わず返します。
//
// 引数: text(string)はCSVセルの原文です。
// 返り値: float64/boolは内部値と既知性です。
func minuteNumber(text string) (float64, bool) {
	if text == "" || strings.TrimSpace(text) != text {
		return 0, false
	}
	v, e := strconv.ParseFloat(text, 64)
	return v, e == nil && minuteFinite(v)
}

// LoadMinutes は147の元CSV規則を148の1分型へ同体で写します。
//
// 引数: scene(Scene)は場の時刻と固定CSV1m参照です。
// 返り値: []population.Minute/MinuteEvidence/errorは欠分を詰めない格子、入力検査値、又は構造不正です。
// 元147のCSV読取規則を維持し、ShortTrackerが付与していたWidth=60とCSV参照型だけを写します。
func LoadMinutes(scene Scene) ([]population.Minute, MinuteEvidence, error) {
	ref := scene.CSV1m
	stats := MinuteEvidence{Reference: ref}
	before, e := os.Stat(ref.Path)
	if e != nil {
		return nil, stats, e
	}
	stats.StatBefore = minuteStat(before)
	body, e := os.ReadFile(ref.Path)
	if e != nil {
		return nil, stats, e
	}
	if ref.Bytes <= 0 || int64(len(body)) != ref.Bytes || minuteDigest(body) != ref.SHA256 {
		return nil, stats, fmt.Errorf("CSV SHA/size差")
	}
	reader := csv.NewReader(bytes.NewReader(bytes.TrimPrefix(body, []byte{0xef, 0xbb, 0xbf})))
	header, e := reader.Read()
	if e != nil {
		return nil, stats, e
	}
	want := []string{"time", "open", "high", "low", "close", "volume", "volume_complete", "closed"}
	if len(header) != len(want) {
		return nil, stats, fmt.Errorf("CSVヘッダ不一致")
	}
	for i, k := range want {
		if header[i] != k {
			return nil, stats, fmt.Errorf("CSV列順/名前不一致")
		}
	}
	reader.FieldsPerRecord = 8
	byStart := map[float64]population.Minute{}
	previous := math.Inf(-1)
	for {
		row, err := reader.Read()
		if err == io.EOF {
			break
		}
		if err != nil {
			return nil, stats, fmt.Errorf("CSV構文不正")
		}
		stats.Rows++
		at, err := time.Parse(time.RFC3339Nano, row[0])
		if err != nil {
			return nil, stats, fmt.Errorf("CSV時計不正")
		}
		start := float64(at.UnixNano()) / 1e9
		if !minuteFinite(start) || start <= previous || math.Mod(start-scene.Start, 60) != 0 {
			return nil, stats, fmt.Errorf("CSV重複/後退/格子不正")
		}
		previous = start
		if start < scene.Start || start >= scene.End-300 {
			continue
		}
		line, _ := reader.FieldPos(0)
		m := population.Minute{ID: fmt.Sprintf("csv1m:%s:%.0f", ref.SHA256, start), Session: scene.Session, Contract: scene.Contract, Width: 60, Start: start, End: start + 60, AvailableAt: start + 120, CSV: &ref, CSVLine: line, Closed: row[7] == "true"}
		values := []*float64{&m.OHLC.Open, &m.OHLC.High, &m.OHLC.Low, &m.OHLC.Close}
		known := true
		for i, p := range values {
			v, k := minuteNumber(row[i+1])
			if !k {
				known = false
				v = 0
			}
			*p = v
		}
		o := m.OHLC
		m.PriceKnown = known && o.Low > 0 && o.High >= o.Low && o.Open >= o.Low && o.Open <= o.High && o.Close >= o.Low && o.Close <= o.High
		v, k := minuteNumber(row[5])
		if k && v >= 0 {
			m.Volume = v
			m.VolumeKnown = row[6] == "true"
		}
		if row[6] != "true" && row[6] != "false" {
			m.VolumeKnown = false
		}
		if row[7] != "true" && row[7] != "false" {
			m.PriceKnown = false
			m.VolumeKnown = false
			m.Closed = false
		}
		byStart[start] = m
	}

	// ----------------------------------------
	// 欠分も元の60秒格子に置き、当場のslot数と未知性を保ちます。
	minutes := []population.Minute{}
	for start := scene.Start; start < scene.End-300; start += 60 {
		m, ok := byStart[start]
		if !ok {
			m = population.Minute{ID: fmt.Sprintf("csv1m-missing:%s:%.0f", ref.SHA256, start), Session: scene.Session, Contract: scene.Contract, Width: 60, Start: start, End: start + 60, AvailableAt: start + 120, CSV: &ref, Missing: true}
			stats.Missing++
		}
		minutes = append(minutes, m)
		if m.PriceKnown && m.Closed {
			stats.PriceKnown++
		}
		if m.VolumeKnown && m.Closed {
			stats.VolumeKnown++
		}
	}
	stats.GridMinutes = len(minutes)
	after, e := os.Stat(ref.Path)
	if e != nil {
		return nil, stats, e
	}
	stats.StatAfter = minuteStat(after)
	if !os.SameFile(before, after) || before.Size() != after.Size() || !before.ModTime().Equal(after.ModTime()) {
		return nil, stats, fmt.Errorf("CSV前後stat差")
	}
	return minutes, stats, nil
}

// DeliverMinutes はAvailableAt以後の最初の受理原行へ全slotを配送します。
//
// 引数: all([]population.Minute)は元格子、cursor(*int)は配送位置、q(population.Quote)は現在の受理原行です。
// 返り値: []population.ParentKnownBarは同じ原行で配送する全slotです。RefsとBBは接続器が現在Snapshotから付与します。
func DeliverMinutes(all []population.Minute, cursor *int, q population.Quote) []population.ParentKnownBar {
	batch := []population.ParentKnownBar{}
	for *cursor < len(all) && all[*cursor].AvailableAt <= q.Time {
		m := all[*cursor]
		m.Stamp = rules.Stamp{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine)}
		known := population.ParentKnownBar{Bar: m}
		known.Context.At = q
		batch = append(batch, known)
		*cursor++
	}
	return batch
}
