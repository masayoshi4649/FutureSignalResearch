package entrybridge

import (
	"encoding/json"
	"fmt"

	population "github.com/masayoshi4649/SessionTradeExecuter/entrypopulation148"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
	bank115 "github.com/masayoshi4649/SessionTradeExecuter/threeframe115"
	input "github.com/masayoshi4649/SessionTradeExecuter/threeframeinput"
)

// chartScene は旧122と同じ予定EOFを固定します。
//
// 機能: Raw末尾へ足計画を縮めず115の場を作ります。
// 引数: session/contract(string)、start/end(float64)。返り値: frame.Sessionです。
func chartScene(session, contract string, start, end float64) frame.Session {
	return frame.Session{ID: session, Contract: contract, Start: start, End: end, EOF: end}
}

// loadChildren は既存CSV入力口をそのまま呼び前後statを検査します。
//
// 機能: 5分子足を既存の数値意味と物理CSV由来で読みます。
// 引数: scene(frame.Session)、ref(FileRef)。返り値: []frame.ChildBar/FileEvidence/errorです。
func loadChildren(scene frame.Session, ref FileRef) ([]frame.ChildBar, FileEvidence, error) {
	f, proof, err := openVerified(ref)
	if err != nil {
		return nil, proof, err
	}
	defer f.Close()
	loaded, err := input.LoadChildren(scene, frame.FileRef{Path: ref.Path, Bytes: ref.Bytes, SHA256: ref.SHA256})
	if err != nil {
		return nil, proof, err
	}
	if err = finishVerified(f, &proof, ref.SHA256); err != nil {
		return nil, proof, err
	}
	return loaded.Bars, proof, nil
}

// scheduledSeed は122と同じ別Bankで予定Endまで種を進めます。
//
// 機能: 実Rawの末尾状態を次場の数値種へ流用しません。
// 引数: scene(frame.Session)、children([]frame.ChildBar)、previous(*bank115.Seed)。
// 返り値: bank115.Seed/errorです。
func scheduledSeed(scene frame.Session, children []frame.ChildBar, previous *bank115.Seed) (bank115.Seed, error) {
	b, err := bank115.BeginSession(scene, children, previous)
	if err != nil {
		return bank115.Seed{}, err
	}
	if _, err = b.AdvanceObserved(scene.End, 1); err != nil {
		return bank115.Seed{}, err
	}
	next, _, err := b.Seal()
	return next, err
}

// projectPublication は保存122を118へ読むときと同じJSON項目射影を行います。
//
// 機能: 115の指標を再計算せず118の既存型へ渡します。
// 引数: value(Publication)。返り値: rules.Publication/errorです。
func projectPublication(value Publication) (rules.Publication, error) {
	var out rules.Publication
	body, err := json.Marshal(value)
	if err != nil {
		return out, err
	}
	err = json.Unmarshal(body, &out)
	return out, err
}

// bootstrap は価格本文既使用の計画と公表から二種類の前史を別々に復元します。
//
// 機能: 真の115種はCSV予定End再生、BB/RVOL/由来は実配送122公表再生で作ります。
// 引数: plan(Plan)。返り値: *bank115.Seed/*rules.Bank/*population.Publications/errorです。
func bootstrap(plan Plan) (*bank115.Seed, *rules.Bank, *population.Publications, error) {
	bank, cache := rules.NewBank(), population.NewPublications()
	if plan.HistoryThrough == "" {
		return nil, bank, cache, nil
	}
	var history struct {
		History []PriorScene `json:"history"`
	}
	if _, err := readJSON(plan.HistoryPlan, &history); err != nil {
		return nil, nil, nil, err
	}
	var background struct {
		Scenes []population.Scene `json:"scenes"`
	}
	if _, err := readJSON(plan.PriorPublications, &background); err != nil {
		return nil, nil, nil, err
	}
	bySession := map[string]population.Scene{}
	for _, s := range background.Scenes {
		if _, exists := bySession[s.Session]; exists {
			return nil, nil, nil, fmt.Errorf("前史公表場重複")
		}
		bySession[s.Session] = s
	}
	var previous *bank115.Seed
	lastEnd := 0.0
	for _, s := range history.History {
		if s.Start < lastEnd {
			return nil, nil, nil, fmt.Errorf("前史場順差")
		}
		lastEnd = s.End
		children, _, err := loadChildren(chartScene(s.Session, s.Contract, s.Start, s.End), s.CSV)
		if err != nil {
			return nil, nil, nil, fmt.Errorf("前史5分:%s:%w", s.Session, err)
		}
		next, err := scheduledSeed(chartScene(s.Session, s.Contract, s.Start, s.End), children, previous)
		if err != nil {
			return nil, nil, nil, err
		}
		previous = &next
		p, ok := bySession[s.Session]
		if !ok || p.Contract != s.Contract || p.Start != s.Start || p.End != s.End {
			return nil, nil, nil, fmt.Errorf("前史CSV/実公表scope差:%s", s.Session)
		}
		if err = bank.StartSession(s.Session, s.Contract); err != nil {
			return nil, nil, nil, err
		}
		if err = cache.StartSession(s.Session, s.Contract); err != nil {
			return nil, nil, nil, err
		}
		for _, pub := range p.Publications {
			if err = bank.Add(pub); err != nil {
				return nil, nil, nil, err
			}
			if err = cache.Record(pub); err != nil {
				return nil, nil, nil, err
			}
		}
		if s.Session == plan.HistoryThrough {
			if len(plan.Scenes) == 0 || s.End > plan.Scenes[0].Start {
				return nil, nil, nil, fmt.Errorf("前史が対象開始より未来")
			}
			return previous, bank, cache, nil
		}
	}
	return nil, nil, nil, fmt.Errorf("前史終端場が見つからない")
}
