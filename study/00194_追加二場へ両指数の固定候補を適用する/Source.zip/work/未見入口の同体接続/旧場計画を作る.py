"""既使用73場だけの同体回帰計画を固定資料から作る。"""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 明示した既使用入力又はSourceを指紋化する。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    value = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(4 << 20):
            value.update(block)
    return value.hexdigest()


def ref(path: Path) -> dict:
    """
    機能: 既使用ファイルの絶対pathと固定参照を返す。
    引数: path(Path)。
    返り値: dictはpath・bytes・SHA256。
    """
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def main() -> None:
    """
    機能: 旧73を超えるデータへアクセスしない回帰計画を保存する。
    引数: なし。
    返り値: None。
    """
    history_path = ROOT / 'work/122全場入力/公表生成計画.json'
    background_path = ROOT / 'work/122全場入力/入力.json'
    minute_path = ROOT / 'work/141VWMA独立入口の評価/CSV73参照.json'
    index_path = ROOT / 'work/163任意幅Raw索引/自然索引/manifest.json'
    expected = {
        history_path: '584e0e95da786dfa4bcf527ed20c1222f237d068bbf5e302fddd6024a13fb7e5',
        background_path: '6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec',
        minute_path: '07e136e2b77a0029ddacd955abad16a9240373fa849ec96b553c2875e1e85147',
        index_path: '391217482497b2d872d73ffcd91cfe31c80a6d90e9c0e3ca12442ae6a7ccfa80',
    }
    assert all(sha(path) == value for path, value in expected.items())
    history = json.loads(history_path.read_text(encoding='utf-8'))['history']
    minutes = json.loads(minute_path.read_text(encoding='utf-8'))['scenes']
    indices = json.loads(index_path.read_text(encoding='utf-8'))['scenes']
    assert len(history) == len(minutes) == len(indices) == 73
    assert [s['session'] for s in history] == [s['session'] for s in minutes] == [s['session'] for s in indices]
    assert history[-1]['session'] == '2026-11-10_Day'
    scenes = []
    for scene, minute, index in zip(history, minutes, indices, strict=True):
        assert scene['session'] <= '2026-11-10_Day'
        assert scene['contract'] == minute['contract'] == index['contract']
        scenes.append({
            'session': scene['session'], 'contract': scene['contract'],
            'start': scene['start'], 'end': scene['end'], 'force_close': scene['force_close'],
            'raw': scene['raw'], 'expected_accepted': index['rows'], 'expected_quality': index['quality'],
            'csv_1m': minute['csv'], 'csv_5m': scene['csv'],
            'quote_index': {'path': str(index_path.parent / index['index']['path']),
                            'bytes': index['index_bytes'], 'sha256': index['index']['sha256']},
        })
    plan = {'version': 1, 'trial': 148, 'history_plan': ref(history_path),
            'prior_publications': ref(background_path), 'index_manifest': ref(index_path),
            'history_through': '', 'transport': 'index48', 'scenes': scenes}
    references = {name: ref(ROOT / 'inputs/00148_全1分入口母集団' / filename) for name, filename in (
        ('ledger', '出生台帳.json.gz'), ('features', '当時特徴.json.gz'), ('acquisitions', '取得対応.json.gz'))}
    references['publications'] = ref(background_path)
    target = HERE / '既知73場だけの回帰計画.json'
    reference_target = HERE / '既知148の参照.json'
    assert not target.exists() and not reference_target.exists()
    target.write_text(json.dumps(plan, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    reference_target.write_text(json.dumps(references, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'計画': ref(target), '旧参照': ref(reference_target), '未見価格読取': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
