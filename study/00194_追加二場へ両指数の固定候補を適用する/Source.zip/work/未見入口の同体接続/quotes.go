package entrybridge

import (
	"bufio"
	"compress/gzip"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"fmt"
	"io"
	"math"
	"time"

	population "github.com/masayoshi4649/SessionTradeExecuter/entrypopulation148"
)

const indexMagic = "NQIDX163"

type Index48Provider struct{}

// canonicalClock は索引のfloat時計をJSTへ表記し直します。
//
// 機能: 元CurrentPriceTime原文と区別し、再解釈後のfloat bit同体を確認します。
// 引数: at(float64)は金融正本の秒時計。返り値: string/errorです。
func canonicalClock(at float64) (string, error) {
	if !finite(at) || at < 0 || at > 9e9 {
		return "", fmt.Errorf("索引時計範囲差")
	}
	seconds, fraction := math.Modf(at)
	t := time.Unix(int64(seconds), int64(math.Round(fraction*1e9))).In(time.FixedZone("JST", 9*3600))
	clock := t.Format(time.RFC3339Nano)
	parsed, err := time.Parse(time.RFC3339Nano, clock)
	if err != nil || math.Float64bits(float64(parsed.UnixNano())/1e9) != math.Float64bits(at) {
		return "", fmt.Errorf("canonical時計のfloat同体差")
	}
	return clock, nil
}

// Scan は163の受理済み48byte索引を一回streamします。
//
// 機能: 数値時計・物理識別・全価格を変更せず供給し、全gzip/物理SHAを検査します。
// 引数: scene(Scene)、visit(func(population.Quote)error)。
// 返り値: QuoteEvidence/errorです。ClockはJST再整形で原文同体とはしません。
func (Index48Provider) Scan(scene Scene, visit func(population.Quote) error) (QuoteEvidence, error) {
	out := QuoteEvidence{ClockFormat: "索引float秒をJST canonical ISO8601へ再整形。元原文ではない", OriginalClockPreserved: false, RawReference: scene.Raw}
	if scene.QuoteIndex == nil || visit == nil {
		return out, fmt.Errorf("索引参照又はcallbackがない")
	}
	f, evidence, err := openVerified(*scene.QuoteIndex)
	out.FileEvidence = evidence
	if err != nil {
		return out, err
	}
	defer f.Close()
	hash := sha256.New()
	physical := bufio.NewReader(io.TeeReader(f, hash))
	stream, err := gzip.NewReader(physical)
	if err != nil {
		return out, err
	}
	defer stream.Close()
	magic := make([]byte, len(indexMagic))
	if _, err = io.ReadFull(stream, magic); err != nil || string(magic) != indexMagic {
		return out, fmt.Errorf("索引magic差:%v", err)
	}
	buf := make([]byte, 48)
	previous, previousLine := scene.Start, int64(0)
	for {
		_, err = io.ReadFull(stream, buf)
		if err == io.EOF {
			break
		}
		if err != nil {
			return out, fmt.Errorf("索引record/CRC:%w", err)
		}
		at := math.Float64frombits(binary.LittleEndian.Uint64(buf[0:8]))
		line := int64(binary.LittleEndian.Uint64(buf[8:16]))
		last := math.Float64frombits(binary.LittleEndian.Uint64(buf[16:24]))
		bid := math.Float64frombits(binary.LittleEndian.Uint64(buf[24:32]))
		ask := math.Float64frombits(binary.LittleEndian.Uint64(buf[32:40]))
		flag := binary.LittleEndian.Uint64(buf[40:48])
		normal := finite(bid, ask) && bid > 0 && ask > bid
		if !finite(at, last) || at < previous || at < scene.Start || at > scene.End || last <= 0 || line <= previousLine || line <= out.Rows || flag > 1 || (flag == 1) != normal {
			return out, fmt.Errorf("索引scope/物理順/価格/正常flag差:%s/%d", scene.Session, out.Rows)
		}
		clock, e := canonicalClock(at)
		if e != nil {
			return out, e
		}
		q := population.Quote{Clock: clock, Time: at, Index: out.Rows, SourceLine: line, Last: last, Bid: bid, Ask: ask, QuoteOK: normal}
		if e = visit(q); e != nil {
			return out, e
		}
		out.Rows++
		previous, previousLine = at, line
	}
	if err = stream.Close(); err != nil {
		return out, err
	}
	if _, err = io.Copy(io.Discard, physical); err != nil {
		return out, err
	}
	if err = finishVerified(f, &out.FileEvidence, hex.EncodeToString(hash.Sum(nil))); err != nil {
		return out, err
	}
	if out.Rows == 0 || (scene.ExpectedAccepted > 0 && out.Rows != scene.ExpectedAccepted) || (scene.ExpectedQuality != nil && out.Rows != scene.ExpectedQuality.Delivered) {
		return out, fmt.Errorf("索引受理件数差:%s", scene.Session)
	}
	return out, nil
}
