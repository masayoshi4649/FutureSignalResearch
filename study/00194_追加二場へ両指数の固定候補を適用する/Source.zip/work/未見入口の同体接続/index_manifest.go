package entrybridge

import (
	"fmt"
	"path/filepath"
	"reflect"
	"strings"

	population "github.com/masayoshi4649/SessionTradeExecuter/entrypopulation148"
)

// absolutePath は比較用だけにpathを正規化します。
//
// 機能: 入力CSVの由来表現そのものは変更しません。
// 引数: value(string)。返り値: string/errorです。
func absolutePath(value string) (string, error) {
	path, err := filepath.Abs(value)
	return filepath.Clean(path), err
}

// validateIndexManifest は索引が指す元Rawと場・品質・SHAを計画へ結びます。
//
// 機能: 数値索引だけを別場や別原本へ取り違えることを拒否します。
// 引数: plan(Plan)。返り値: errorです。
func validateIndexManifest(plan Plan) error {
	var manifest struct {
		Success bool `json:"success"`
		Scenes  []struct {
			Success         bool              `json:"success"`
			Session         string            `json:"session"`
			Contract        string            `json:"contract"`
			Rows            int64             `json:"rows"`
			Raw             FileRef           `json:"raw"`
			ActualRawSHA256 string            `json:"actual_raw_sha256"`
			Before          map[string]int64  `json:"stat_before"`
			After           map[string]int64  `json:"stat_after"`
			Quality         population.Counts `json:"quality"`
			Index           FileRef           `json:"index"`
			IndexBytes      int64             `json:"index_bytes"`
		} `json:"scenes"`
	}
	if _, err := readJSON(plan.IndexManifest, &manifest); err != nil {
		return err
	}
	if !manifest.Success {
		return fmt.Errorf("索引manifest未成功")
	}
	seen := map[string]bool{}
	for _, s := range manifest.Scenes {
		if seen[s.Session] {
			return fmt.Errorf("索引manifest場重複")
		}
		seen[s.Session] = true
	}
	for _, target := range plan.Scenes {
		found := false
		for _, s := range manifest.Scenes {
			if s.Session != target.Session {
				continue
			}
			found = true
			if !s.Success || s.Contract != target.Contract || s.Rows <= 0 || target.ExpectedAccepted != s.Rows || target.ExpectedQuality == nil || *target.ExpectedQuality != s.Quality || s.Rows != s.Quality.Delivered || s.Raw.SHA256 != target.Raw.SHA256 || s.ActualRawSHA256 != target.Raw.SHA256 || !reflect.DeepEqual(s.Before, s.After) || target.Raw.Bytes > 0 && target.Raw.Bytes != s.Before["bytes"] || target.QuoteIndex == nil {
				return fmt.Errorf("索引manifestと計画scope/品質/原本差:%s", target.Session)
			}
			a, err := absolutePath(s.Raw.Path)
			if err != nil {
				return err
			}
			b, err := absolutePath(target.Raw.Path)
			if err != nil {
				return err
			}
			if !strings.EqualFold(a, b) {
				return fmt.Errorf("元Raw path差")
			}
			indexPath := s.Index.Path
			if !filepath.IsAbs(indexPath) {
				indexPath = filepath.Join(filepath.Dir(plan.IndexManifest.Path), indexPath)
			}
			a, err = absolutePath(indexPath)
			if err != nil {
				return err
			}
			b, err = absolutePath(target.QuoteIndex.Path)
			if err != nil {
				return err
			}
			if !strings.EqualFold(a, b) || s.Index.SHA256 != target.QuoteIndex.SHA256 || s.IndexBytes != target.QuoteIndex.Bytes {
				return fmt.Errorf("索引path/SHA/bytes差:%s", target.Session)
			}
		}
		if !found {
			return fmt.Errorf("索引manifestに対象がない:%s", target.Session)
		}
	}
	return nil
}
