// Package entrybridge は旧148の特徴と出生状態を変更せず別場の指紋付き入力へ接続します。
package entrybridge

import (
	population "github.com/masayoshi4649/SessionTradeExecuter/entrypopulation148"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	features "github.com/masayoshi4649/SessionTradeExecuter/features148"
	bank115 "github.com/masayoshi4649/SessionTradeExecuter/threeframe115"
)

type FileRef = population.FileRef

type Scene struct {
	population.Scene
	CSV1m      FileRef  `json:"csv_1m"`
	CSV5m      FileRef  `json:"csv_5m"`
	QuoteIndex *FileRef `json:"quote_index"`
}

// Plan は試行番号・新場数を固定せず、呼出側がF0へ束縛する入力契約です。
type Plan struct {
	Version           int     `json:"version"`
	Trial             int     `json:"trial"`
	HistoryPlan       FileRef `json:"history_plan"`
	PriorPublications FileRef `json:"prior_publications"`
	IndexManifest     FileRef `json:"index_manifest"`
	HistoryThrough    string  `json:"history_through"`
	Transport         string  `json:"transport"`
	Scenes            []Scene `json:"scenes"`
}

type PriorScene struct {
	Session  string  `json:"session"`
	Contract string  `json:"contract"`
	Start    float64 `json:"start"`
	End      float64 `json:"end"`
	CSV      FileRef `json:"csv"`
}

type Publication struct {
	Stamp rules.Stamp   `json:"stamp"`
	Frame bank115.Frame `json:"frame"`
}

type FileEvidence struct {
	Reference    FileRef          `json:"reference"`
	ActualSHA256 string           `json:"actual_sha256"`
	StatBefore   map[string]int64 `json:"stat_before"`
	StatAfter    map[string]int64 `json:"stat_after"`
}

type QuoteEvidence struct {
	FileEvidence
	Rows                   int64   `json:"rows"`
	ClockFormat            string  `json:"clock_format"`
	OriginalClockPreserved bool    `json:"original_clock_preserved"`
	RawReference           FileRef `json:"raw_reference"`
}

type SceneEvidence struct {
	Session                    string                `json:"session"`
	Contract                   string                `json:"contract"`
	Start                      float64               `json:"start"`
	End                        float64               `json:"end"`
	EntryLimit                 float64               `json:"entry_limit"`
	Quotes                     QuoteEvidence         `json:"quotes"`
	CSV1m                      MinuteEvidence        `json:"csv_1m"`
	CSV5m                      FileEvidence          `json:"csv_5m"`
	InputSeed                  *bank115.SeedInfo     `json:"input_seed"`
	RawEndSeed                 bank115.SeedInfo      `json:"raw_end_seed"`
	ScheduledEndSeed           bank115.SeedInfo      `json:"scheduled_end_seed"`
	PublicationCount           int                   `json:"publication_count"`
	PublicationSHA256          string                `json:"publication_sha256"`
	ProjectedPublicationSHA256 string                `json:"projected_publication_sha256"`
	Counts                     map[string]int        `json:"counts"`
	Statuses                   map[string]int        `json:"statuses"`
	BBWindows                  []population.BBWindow `json:"bb_windows"`
}

type Case struct {
	ID               string           `json:"id"`
	Session          string           `json:"session"`
	Contract         string           `json:"contract"`
	CanonicalEventID string           `json:"canonical_event_id"`
	Entry            population.Quote `json:"entry"`
}

type Generated struct {
	Plan         Plan                       `json:"plan"`
	Scenes       []SceneEvidence            `json:"scenes"`
	Ledger       []*population.LedgerRow    `json:"ledger"`
	Features     []population.FeatureRecord `json:"features"`
	Acquisitions []*population.Acquisition  `json:"acquisitions"`
	Cases        []Case                     `json:"cases"`
	Catalog      []features.Column          `json:"catalog"`
	Counts       map[string]int             `json:"counts"`
}

// QuoteProvider はClock原文のsidecarを後から追加できる原行供給境界です。
//
// 機能: 受理済み原行を物理順に渡し、入力全体成功を最後に返します。
// 引数: scene(Scene)、visit(func(population.Quote)error)。
// 返り値: QuoteEvidence/error。callback成功だけで正式成功とはしません。
type QuoteProvider interface {
	Scan(scene Scene, visit func(population.Quote) error) (QuoteEvidence, error)
}
