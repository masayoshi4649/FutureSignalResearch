package entrybridge

import (
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
	"time"

	population "github.com/masayoshi4649/SessionTradeExecuter/entrypopulation148"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

const minuteHeader = "time,open,high,low,close,volume,volume_complete,closed\n"

// artificialMinuteRow はCSV人工場のRFC3339行を作ります。
//
// 引数: at(int64)は開始秒、values(string)は残り7列です。
// 返り値: stringは改行付きCSV行です。
func artificialMinuteRow(at int64, values string) string {
	return time.Unix(at, 0).UTC().Format(time.RFC3339Nano) + "," + values + "\n"
}

// artificialMinuteScene は自然入力に触れず一時CSVと固定参照を作ります。
//
// 引数: t(*testing.T)、body(string)は人工CSVです。
// 返り値: Sceneは0〜600秒の人工場です。
func artificialMinuteScene(t *testing.T, body string) Scene {
	t.Helper()
	path := filepath.Join(t.TempDir(), "minute.csv")
	if err := os.WriteFile(path, []byte(body), 0600); err != nil {
		t.Fatal(err)
	}
	ref := FileRef{Path: path, SHA256: minuteDigest([]byte(body)), Bytes: int64(len(body))}
	return Scene{Scene: population.Scene{Session: "人工_Day", Contract: "人工限月", Start: 0, End: 600, ForceClose: 550}, CSV1m: ref}
}

// TestLoadMinutesRetainsGrid は価格・数量・欠分と物理行を独立期待値で確認します。
//
// 引数: t(*testing.T)はGo検査器です。
// 返り値: ありません。期待値差を失敗として報告します。
func TestLoadMinutesRetainsGrid(t *testing.T) {
	body := "\ufeff" + minuteHeader +
		artificialMinuteRow(-60, "100,102,99,101,7,true,true") +
		artificialMinuteRow(0, "100,102,99,101,0,true,true") +
		artificialMinuteRow(120, "100,102,99,101,2,false,true") +
		artificialMinuteRow(180, "NaN,102,99,101,3,true,true") +
		artificialMinuteRow(240, "100,102,99,101,4,true,不正") +
		artificialMinuteRow(300, "100,102,99,101,5,true,true")
	scene := artificialMinuteScene(t, body)
	all, proof, err := LoadMinutes(scene)
	if err != nil {
		t.Fatal(err)
	}
	if proof.Rows != 6 || proof.GridMinutes != 5 || proof.Missing != 1 || proof.PriceKnown != 2 || proof.VolumeKnown != 2 {
		t.Fatalf("元行・格子・既知性差: %+v", proof)
	}
	if !reflect.DeepEqual(proof.StatBefore, proof.StatAfter) || proof.Reference != scene.CSV1m {
		t.Fatalf("固定参照又は前後stat差: %+v", proof)
	}
	for i, m := range all {
		start := float64(i * 60)
		if m.Start != start || m.End != start+60 || m.AvailableAt != start+120 || m.Width != 60 || m.Session != scene.Session || m.Contract != scene.Contract || m.CSV == nil || *m.CSV != scene.CSV1m {
			t.Fatalf("slot %dのscope/格子差: %+v", i, m)
		}
	}
	if !all[0].VolumeKnown || all[0].Volume != 0 || !all[0].PriceKnown || !all[0].Closed || all[0].CSVLine != 3 {
		t.Fatalf("既知0数量又は物理行差: %+v", all[0])
	}
	if !all[1].Missing || all[1].PriceKnown || all[1].VolumeKnown || all[1].Closed || all[1].CSVLine != 0 || !strings.HasPrefix(all[1].ID, "csv1m-missing:") {
		t.Fatalf("欠分の未知性差: %+v", all[1])
	}
	if all[2].VolumeKnown || all[2].Volume != 2 || !all[2].PriceKnown || !all[2].Closed {
		t.Fatalf("不完全数量の格納値と既知性差: %+v", all[2])
	}
	if all[3].PriceKnown || !all[3].VolumeKnown || all[3].OHLC.Open != 0 || !all[3].Closed {
		t.Fatalf("非有限価格の未知性差: %+v", all[3])
	}
	if all[4].PriceKnown || all[4].VolumeKnown || all[4].Closed {
		t.Fatalf("不正closed旗の未知性差: %+v", all[4])
	}
}

// TestDeliverMinutesUsesFirstObservedLine は公表等号とcatch-up全部の配送を確認します。
//
// 引数: t(*testing.T)はGo検査器です。
// 返り値: ありません。配送時刻・物理行・重複の差を失敗として報告します。
func TestDeliverMinutesUsesFirstObservedLine(t *testing.T) {
	scene := artificialMinuteScene(t, minuteHeader+artificialMinuteRow(0, "100,102,99,101,0,true,true"))
	all, _, err := LoadMinutes(scene)
	if err != nil {
		t.Fatal(err)
	}
	cursor := 0
	q := population.Quote{Clock: "人工", Time: 119, Index: 4, SourceLine: 8, Last: 100, Bid: 99, Ask: 101, QuoteOK: true}
	if got := DeliverMinutes(all, &cursor, q); len(got) != 0 || cursor != 0 {
		t.Fatalf("足終+60以前に配送: %+v", got)
	}
	q.Time = 120
	got := DeliverMinutes(all, &cursor, q)
	if len(got) != 1 || cursor != 1 || got[0].Context.At != q || got[0].Bar.Stamp != (rules.Stamp{Time: 120, Index: 4, Line: 8}) {
		t.Fatalf("等号の初知原行差: %+v", got)
	}
	if again := DeliverMinutes(all, &cursor, q); len(again) != 0 {
		t.Fatalf("同一原行で再配送: %+v", again)
	}
	q.Time, q.Index, q.SourceLine = 300, 9, 20
	got = DeliverMinutes(all, &cursor, q)
	if len(got) != 3 || cursor != 4 {
		t.Fatalf("catch-up欠分配送差: %+v", got)
	}
	for i, known := range got {
		if known.Bar.Start != float64((i+1)*60) || known.Context.At != q || known.Bar.Stamp != (rules.Stamp{Time: 300, Index: 9, Line: 20}) {
			t.Fatalf("catch-up順又は原行差: %+v", got)
		}
	}
	if all[0].Stamp != (rules.Stamp{}) || all[1].Stamp != (rules.Stamp{}) {
		t.Fatal("配送が元CSVslotのstampを変更")
	}
	q.Time = 359
	if got = DeliverMinutes(all, &cursor, q); len(got) != 0 || cursor != 4 {
		t.Fatal("次slotをAvailableAt以前に配送")
	}
	q.Time = 360
	if got = DeliverMinutes(all, &cursor, q); len(got) != 1 || cursor != 5 {
		t.Fatal("次slotのAvailableAt等号配送差")
	}
}

// TestLoadMinutesRejectsBrokenInput は構文・順序・格子と固定指紋の破損を失敗にします。
//
// 引数: t(*testing.T)はGo検査器です。
// 返り値: ありません。破損を無取引へ置換した場合に失敗します。
func TestLoadMinutesRejectsBrokenInput(t *testing.T) {
	row0 := artificialMinuteRow(0, "100,102,99,101,1,true,true")
	tests := []struct{ name, body string }{
		{"ヘッダ順", strings.Replace(minuteHeader, "open,high", "high,open", 1) + row0},
		{"列数", minuteHeader + "1970-01-01T00:00:00Z,100,101\n"},
		{"時計", minuteHeader + "不正,100,102,99,101,1,true,true\n"},
		{"重複", minuteHeader + row0 + row0},
		{"後退", minuteHeader + artificialMinuteRow(60, "100,102,99,101,1,true,true") + row0},
		{"場外でも格子検査", minuteHeader + artificialMinuteRow(-61, "100,102,99,101,1,true,true") + row0},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			scene := artificialMinuteScene(t, test.body)
			if _, _, err := LoadMinutes(scene); err == nil {
				t.Fatalf("破損を受理: %s", test.name)
			}
		})
	}
	for _, which := range []string{"SHA", "bytes"} {
		t.Run(fmt.Sprintf("固定%s", which), func(t *testing.T) {
			scene := artificialMinuteScene(t, minuteHeader+row0)
			if which == "SHA" {
				scene.CSV1m.SHA256 = strings.Repeat("0", 64)
			} else {
				scene.CSV1m.Bytes++
			}
			if _, _, err := LoadMinutes(scene); err == nil {
				t.Fatal("固定参照差を受理")
			}
		})
	}
}
