package entrybridge

import (
	"bufio"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"reflect"

	population "github.com/masayoshi4649/SessionTradeExecuter/entrypopulation148"
	bank115 "github.com/masayoshi4649/SessionTradeExecuter/threeframe115"
)

type References struct {
	Ledger       FileRef `json:"ledger"`
	Features     FileRef `json:"features"`
	Acquisitions FileRef `json:"acquisitions"`
	Publications FileRef `json:"publications"`
}

// readGzipJSON は固定済み既知参照だけを全SHA/CRC確認後に受け取ります。
//
// 機能: 回帰検査で金融ラベルを読まず旧148の原値を比較します。
// 引数: ref(FileRef)、out(any)。返り値: errorです。
func readGzipJSON(ref FileRef, out any) error {
	f, evidence, err := openVerified(ref)
	if err != nil {
		return err
	}
	defer f.Close()
	hash := sha256.New()
	physical := bufio.NewReader(io.TeeReader(f, hash))
	gz, err := gzip.NewReader(physical)
	if err != nil {
		return err
	}
	defer gz.Close()
	decoder := json.NewDecoder(gz)
	if err = decoder.Decode(out); err != nil {
		return err
	}
	var tail any
	if err = decoder.Decode(&tail); err != io.EOF {
		return fmt.Errorf("参照JSON末尾差:%v", err)
	}
	if err = gz.Close(); err != nil {
		return err
	}
	if _, err = io.Copy(io.Discard, physical); err != nil {
		return err
	}
	return finishVerified(f, &evidence, hex.EncodeToString(hash.Sum(nil)))
}

// normalizedQuote はClockだけの表記差を除き、数値正本を保持します。
//
// 機能: 原文文字列同体と数値同体を混同しません。
// 引数: q(population.Quote)。返り値: population.Quoteです。
func normalizedQuote(q population.Quote) population.Quote { q.Clock = ""; return q }

// normalizedAcquisition は取得caseの旧C1結合とClock表記だけを比較から外します。
//
// 機能: 出生・失効・実取得の全状態を独立に比較します。
// 引数: original(population.Acquisition)。返り値: population.Acquisitionです。
func normalizedAcquisition(original population.Acquisition) population.Acquisition {
	a := original
	a.Q0 = normalizedQuote(a.Q0)
	a.CaseID, a.BuyStream, a.SellStream = nil, nil, nil
	if a.Q1 != nil {
		q := normalizedQuote(*a.Q1)
		a.Q1 = &q
	}
	if a.TerminatedAt != nil {
		q := normalizedQuote(*a.TerminatedAt)
		a.TerminatedAt = &q
	}
	return a
}

// CompareReferences は旧148の全q0・全100X・全取得状態と旧122公表を比較します。
//
// 機能: 新しい接続経路の数値同体だけを検証し、戦略評価を行いません。
// 引数: out(Generated)、refs(References)。返り値: map[string]any/errorです。
func CompareReferences(out Generated, refs References) (map[string]any, error) {
	selected := map[string]bool{}
	for _, s := range out.Scenes {
		selected[s.Session] = true
	}
	var oldLedger struct {
		Rows []*population.LedgerRow `json:"rows"`
	}
	if err := readGzipJSON(refs.Ledger, &oldLedger); err != nil {
		return nil, err
	}
	i := 0
	for _, row := range oldLedger.Rows {
		if selected[row.Session] {
			if i >= len(out.Ledger) {
				return nil, fmt.Errorf("q0不足")
			}
			actual, expected := *out.Ledger[i], *row
			if math.Float64bits(actual.Q0.Time) != math.Float64bits(expected.Q0.Time) {
				return nil, fmt.Errorf("q0時計bit差:%s", row.EventID)
			}
			actual.Q0, expected.Q0 = normalizedQuote(actual.Q0), normalizedQuote(expected.Q0)
			if !reflect.DeepEqual(actual, expected) {
				return nil, fmt.Errorf("q0台帳差:%s", row.EventID)
			}
			i++
		}
	}
	if i != len(out.Ledger) {
		return nil, fmt.Errorf("q0余剰")
	}
	oldLedger.Rows = nil
	var oldFeatures struct {
		Rows []population.FeatureRecord `json:"rows"`
	}
	if err := readGzipJSON(refs.Features, &oldFeatures); err != nil {
		return nil, err
	}
	i = 0
	for _, row := range oldFeatures.Rows {
		if selected[row.Session] {
			if i >= len(out.Features) || !reflect.DeepEqual(out.Features[i], row) {
				return nil, fmt.Errorf("100X又はMetadata差:%s", row.EventID)
			}
			for _, pair := range [][2][100]*float64{{out.Features[i].Buy.X, row.Buy.X}, {out.Features[i].Sell.X, row.Sell.X}} {
				for k, value := range pair[0] {
					if value != nil && math.Float64bits(*value) != math.Float64bits(*pair[1][k]) {
						return nil, fmt.Errorf("100Xのfloat bit差:%s/%d", row.EventID, k)
					}
				}
			}
			i++
		}
	}
	if i != len(out.Features) {
		return nil, fmt.Errorf("100X余剰")
	}
	oldFeatures.Rows = nil
	var oldAcquisitions struct {
		Rows []*population.Acquisition `json:"rows"`
	}
	if err := readGzipJSON(refs.Acquisitions, &oldAcquisitions); err != nil {
		return nil, err
	}
	i = 0
	for _, row := range oldAcquisitions.Rows {
		if selected[row.Session] {
			if i >= len(out.Acquisitions) || !reflect.DeepEqual(normalizedAcquisition(*out.Acquisitions[i]), normalizedAcquisition(*row)) {
				return nil, fmt.Errorf("取得/取消状態差:%s", row.EventID)
			}
			if row.Q1 != nil && math.Float64bits(out.Acquisitions[i].Q1.Time) != math.Float64bits(row.Q1.Time) {
				return nil, fmt.Errorf("q1時計bit差:%s", row.EventID)
			}
			i++
		}
	}
	if i != len(out.Acquisitions) {
		return nil, fmt.Errorf("取得状態余剰")
	}
	oldAcquisitions.Rows = nil
	var background struct {
		Scenes []struct {
			Session      string        `json:"session"`
			Publications []Publication `json:"publications"`
		} `json:"scenes"`
	}
	if _, err := readJSON(refs.Publications, &background); err != nil {
		return nil, err
	}
	bySession := map[string][]Publication{}
	for _, s := range background.Scenes {
		bySession[s.Session] = s.Publications
	}
	pubCount := 0
	for _, s := range out.Scenes {
		pubs, ok := bySession[s.Session]
		if !ok {
			return nil, fmt.Errorf("既知公表場なし")
		}
		body, err := json.Marshal(pubs)
		if err != nil {
			return nil, err
		}
		if digest(body) != s.PublicationSHA256 || len(pubs) != s.PublicationCount {
			return nil, fmt.Errorf("115公表全文/時計/由来差:%s", s.Session)
		}
		pubCount += len(pubs)
	}
	return map[string]any{"成功": true, "比較場数": len(out.Scenes), "全q0": len(out.Ledger), "両側100X行": 2 * len(out.Features), "特徴値セル": 200 * len(out.Features), "全取得状態": len(out.Acquisitions), "全物理q1": len(out.Cases), "115公表全文": pubCount, "q0_q1時計float_bit同体": true, "Clock原文字列同体": false, "Clock差": "索引正本からJST canonical表記。比較から文字列だけ除外", "旧C1結合差": "case_id/buy_stream/sell_streamだけ除外。出生・取得状態は全文比較", "未見価格読取": false, "金融ラベル読取": false, "参照": refs, "種の既存API": bank115.DeclaredDefinition()}, nil
}
