package entrybridge

import (
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"

	population "github.com/masayoshi4649/SessionTradeExecuter/entrypopulation148"
)

// writeJSON は未作成先へJSONを一度だけ保存します。
//
// 機能: 大きな配列のMarshal複製を避け、必要時はgzipします。
// 引数: path(string)、value(any)、compress(bool)。返り値: FileRef/errorです。
func writeJSON(path string, value any, compress bool) (FileRef, error) {
	ref := FileRef{Path: path}
	f, err := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if err != nil {
		return ref, err
	}
	hash := sha256.New()
	writer := &hashWriter{file: f, hash: hash}
	if compress {
		gz := gzip.NewWriter(writer)
		err = json.NewEncoder(gz).Encode(value)
		closeError := gz.Close()
		if err == nil {
			err = closeError
		}
	} else {
		err = json.NewEncoder(writer).Encode(value)
	}
	closeError := f.Close()
	if err == nil {
		err = closeError
	}
	if err != nil {
		return ref, err
	}
	stat, err := os.Stat(path)
	if err != nil {
		return ref, err
	}
	ref.Bytes = stat.Size()
	ref.SHA256 = hex.EncodeToString(hash.Sum(nil))
	return ref, nil
}

type hashWriter struct {
	file *os.File
	hash interface{ Write([]byte) (int, error) }
}

// Write は保存に成功した物理bytesだけを指紋へ流します。
//
// 機能: 書込先とSHAの同体を保ちます。
// 引数: body([]byte)。返り値: int/errorです。
func (w *hashWriter) Write(body []byte) (int, error) {
	n, err := w.file.Write(body)
	if n > 0 {
		_, _ = w.hash.Write(body[:n])
	}
	return n, err
}

// Write は全入力成功後に非金融成果と最後の完了票を未作成先へ保存します。
//
// 機能: 候補採否や旧C1を含めず将来の入口適用へ共用できます。
// 引数: directory(string)、planRef(FileRef)、out(Generated)。返り値: errorです。
func Write(directory string, planRef FileRef, out Generated) error {
	if _, err := os.Stat(directory); !os.IsNotExist(err) {
		return fmt.Errorf("未作成出力先だけ許可")
	}
	if err := os.MkdirAll(directory, 0700); err != nil {
		return err
	}
	files := map[string]FileRef{}
	common := func() map[string]any {
		return map[string]any{"success": true, "trial": out.Plan.Trial, "plan_reference": planRef, "counts": out.Counts, "clock_original_preserved": false, "clock_format": "索引float秒からJST canonical ISO8601へ再整形", "financial_labels_used": false, "legacy_c1_used": false, "strategy_selected": false}
	}
	ledger := common()
	ledger["rows"] = out.Ledger
	ledger["scenes"] = out.Scenes
	x := common()
	x["rows"] = out.Features
	x["catalog"] = out.Catalog
	capture := common()
	capture["rows"] = out.Acquisitions
	cases := common()
	cases["cases"] = out.Cases
	for _, item := range []struct {
		name  string
		value any
	}{{"出生台帳.json.gz", ledger}, {"当時特徴.json.gz", x}, {"取得対応.json.gz", capture}, {"物理取得.json.gz", cases}} {
		ref, err := writeJSON(filepath.Join(directory, item.name), item.value, true)
		if err != nil {
			return err
		}
		files[item.name] = ref
	}
	// ----------------------------------------
	// 両実側の金融観測へ渡す固定形はN/Tの全取得母集団であり、採用取引ではありません。
	fixedScenes := []map[string]any{}
	for i, s := range out.Plan.Scenes {
		entries := []map[string]any{}
		for _, c := range out.Cases {
			if c.Session == s.Session {
				entries = append(entries, map[string]any{"id": c.ID, "side": 1, "entry": c.Entry})
			}
		}
		fixedScenes = append(fixedScenes, map[string]any{"session": s.Session, "contract": s.Contract, "start": s.Start, "end": s.End, "force_close": s.ForceClose, "raw": s.Raw, "expected_accepted": out.Scenes[i].Quotes.Rows, "expected_quality": s.ExpectedQuality, "entries": entries})
	}
	fixed := common()
	fixed["scenes"] = fixedScenes
	fixed["expected_entry_count"] = len(out.Cases)
	ref, err := writeJSON(filepath.Join(directory, "固定取得入力.json.gz"), fixed, true)
	if err != nil {
		return err
	}
	files["固定取得入力.json.gz"] = ref
	complete := common()
	complete["files"] = files
	complete["catalog_compact_sha256"] = population.CatalogCompactSHA
	complete["raw_passes"] = 0
	complete["index_passes"] = len(out.Scenes)
	_, err = writeJSON(filepath.Join(directory, "完了.json"), complete, false)
	return err
}
