package entrybridge

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"os"
)

// digest はSource及び入力の物理bytesを指紋化します。
//
// 機能: SHA256を小文字で返します。
// 引数: data([]byte)。返り値: stringです。
func digest(data []byte) string { value := sha256.Sum256(data); return hex.EncodeToString(value[:]) }

// finite は時計と既知値の非有限を拒否します。
//
// 機能: 全要素の有限性を確認します。
// 引数: values(...float64)。返り値: boolです。
func finite(values ...float64) bool {
	for _, value := range values {
		if math.IsNaN(value) || math.IsInf(value, 0) {
			return false
		}
	}
	return true
}

// fileStat は指紋照合用のサイズと更新時計を保存します。
//
// 機能: 価格を含まない入力statを返します。
// 引数: value(os.FileInfo)。返り値: map[string]int64です。
func fileStat(value os.FileInfo) map[string]int64 {
	return map[string]int64{"bytes": value.Size(), "mtime_ns": value.ModTime().UnixNano()}
}

// openVerified は呼出側固定参照と読取前statを検査します。
//
// 機能: 指定入力を開きサイズ差を拒否します。
// 引数: ref(FileRef)。返り値: *os.File/FileEvidence/errorです。
func openVerified(ref FileRef) (*os.File, FileEvidence, error) {
	out := FileEvidence{Reference: ref}
	if ref.Path == "" || ref.Bytes <= 0 || len(ref.SHA256) != 64 {
		return nil, out, fmt.Errorf("入力参照不正")
	}
	f, err := os.Open(ref.Path)
	if err != nil {
		return nil, out, err
	}
	s, err := f.Stat()
	if err != nil {
		f.Close()
		return nil, out, err
	}
	out.StatBefore = fileStat(s)
	if s.Size() != ref.Bytes {
		f.Close()
		return nil, out, fmt.Errorf("入力サイズ差:%s", ref.Path)
	}
	return f, out, nil
}

// finishVerified は全読取SHAと開いた入力及びpathの後statを照合します。
//
// 機能: 正式成功前の入力同体を確認します。
// 引数: f(*os.File)、evidence(*FileEvidence)、actual(string)。返り値: errorです。
func finishVerified(f *os.File, evidence *FileEvidence, actual string) error {
	after, err := f.Stat()
	if err != nil {
		return err
	}
	pathAfter, err := os.Stat(evidence.Reference.Path)
	if err != nil {
		return err
	}
	evidence.StatAfter = fileStat(after)
	evidence.ActualSHA256 = actual
	if actual != evidence.Reference.SHA256 || evidence.StatBefore["bytes"] != after.Size() || evidence.StatBefore["mtime_ns"] != after.ModTime().UnixNano() || !os.SameFile(after, pathAfter) || after.Size() != pathAfter.Size() || !after.ModTime().Equal(pathAfter.ModTime()) {
		return fmt.Errorf("入力SHA/前後stat差:%s", evidence.Reference.Path)
	}
	return nil
}

// readJSON は全物理SHAと前後statが一致したJSONだけを解釈します。
//
// 機能: 小計画及び既使用公表を固定参照で読みます。
// 引数: ref(FileRef)、out(any)は受取先pointer。返り値: FileEvidence/errorです。
func readJSON(ref FileRef, out any) (FileEvidence, error) {
	f, evidence, err := openVerified(ref)
	if err != nil {
		return evidence, err
	}
	defer f.Close()
	body, err := io.ReadAll(f)
	if err != nil {
		return evidence, err
	}
	if err = finishVerified(f, &evidence, digest(body)); err != nil {
		return evidence, err
	}
	return evidence, json.Unmarshal(body, out)
}

// LoadPlan は呼出側が固定した計画を読みます。
//
// 機能: 市場入力をまだ開かず計画SHAを照合します。
// 引数: ref(FileRef)。返り値: Plan/errorです。
func LoadPlan(ref FileRef) (Plan, error) {
	var plan Plan
	_, err := readJSON(ref, &plan)
	return plan, err
}
