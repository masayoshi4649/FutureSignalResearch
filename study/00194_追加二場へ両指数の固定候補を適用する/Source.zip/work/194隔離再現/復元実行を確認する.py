"""194の展開先で固定再計算を実行し、元workへの絶対参照を別記する。"""
from pathlib import Path
import hashlib
import json
import os
import runpy
import sys
import traceback

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
RESTORED = HERE / 'repo_hardlink'
OPENED = set()
WRITTEN = set()


def watch(event: str, args: tuple) -> None:
    """
    機能: 展開先と元リポジトリの読取パスを両方記録する。
    引数: event(str)、args(tuple)はPython監査イベント。
    返り値: None。参照先を書き換えない。
    """
    if event == 'open' and args and isinstance(args[0], (str, bytes)):
        try:
            path = Path(args[0]).resolve()
        except (ValueError, TypeError):
            return
        if path.is_relative_to(ROOT) and path.suffix != '.pyc' and 'site-packages' not in path.parts:
            OPENED.add(path)
            mode = args[1] if len(args) > 1 and isinstance(args[1], str) else ''
            flags = args[2] if len(args) > 2 and isinstance(args[2], int) else 0
            if any(char in mode for char in 'wax+') or flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND):
                WRITTEN.add(path)


def main() -> None:
    """
    機能: 正式ZIP展開先の再計算を実行し、戦略moduleと絶対参照を区別して記録する。
    引数: なし。
    返り値: None。固定Source・条件を変えず、元正本を上書きしない。
    """
    sys.path.insert(0, str(RESTORED / 'work/194追加二場'))
    sys.addaudithook(watch)
    success = False; error = None
    try:
        runpy.run_path(str(RESTORED / 'work/194追加二場/再計算194.py'), run_name='__main__')
        success = True
    except Exception:
        error = traceback.format_exc()
    imports = []
    for name, module in list(sys.modules.items()):
        filename = getattr(module, '__file__', None)
        if filename:
            path = Path(filename).resolve()
            if path.is_relative_to(ROOT) and path.suffix in ('.py', '.pyd') and 'site-packages' not in path.parts:
                imports.append({'module': name, 'path': str(path), '展開先': path.is_relative_to(RESTORED)})
    original_work = sorted(str(p) for p in OPENED if p.is_relative_to(ROOT / 'work') and not p.is_relative_to(HERE))
    input_writes = [str(p) for p in WRITTEN if p.is_relative_to(ROOT / 'inputs') or p.is_relative_to(RESTORED / 'inputs')]
    assert not input_writes, input_writes
    proof = {'成功': success, '対象': str(RESTORED), '実行方式': 'Source.zip展開・inputsは元恒久入力へのfile hardlink・orjsonはpip指定版を展開先へ導入',
        '固定Source変更なし': True, '元workへの絶対path参照': original_work,
        '読込module': imports, 'error': error,
        '恒久入力への書込み': input_writes, '恒久入力への書込みなし': True,
        '通常コピー側の書込み': sorted(str(p) for p in WRITTEN),
        '限界': '別root完全隔離ではない。旧固定条件の絶対pathによる原配置の指紋検査と恒久入力参照が残る。'}
    (HERE / '復元実行確認194.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': success, '元work絶対参照': len(original_work), 'module': len(imports), 'error': error}, ensure_ascii=False), flush=True)
    assert success, error


# ----------------------------------------
if __name__ == '__main__':
    main()
