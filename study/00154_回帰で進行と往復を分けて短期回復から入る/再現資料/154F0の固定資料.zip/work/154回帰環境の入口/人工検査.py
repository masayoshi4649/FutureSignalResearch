"""154固定境界/153R0同体/買売鏡像を小型人工で検査する。"""
from pathlib import Path
import copy
import importlib.util
import sys
import unittest
import logic154 as m

ROOT=Path(__file__).resolve().parents[2]
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'work/153独立出生の入口'))
spec=importlib.util.spec_from_file_location('fixture153_for154',ROOT/'work/153独立出生の入口/人工検査.py')
fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
NAMES=fixture.NAMES;INDEX=fixture.INDEX


def case(kind: str='T') -> tuple:
    """
    機能: 153の原fixtureに独立測定rowを加える。
    引数: kind(str)。返り値: tupleは買/売/測定/回帰。
    """
    buy,sell,d,_,_=fixture.fixture('RV' if kind=='V' else 'PB');d['event_id']='人工'
    d['prior_ranges']=fixture.ranges(True,100,110)
    if kind=='V':
        d['q0'].update(last=103.5,bid=103,ask=104)
        d['r']['ohlc'].update(open=100,low=100.5,high=106,close=103)
        d['r']['ohlc']['open']=101
        buy,sell=fixture.features(d,103.5,1.25,'RV')
    out={'event_id':'人工','eligible':True,'r_ref':'r','windows':{}}
    for width in m.WINDOWS:
        w=d['prior_ranges'][str(width)]
        out['windows'][str(width)]={'from':w['from'],'to':w['to'],'known':True,'unknown_reasons':[],
            'first_ref':f'始{width}','last_ref':f'終{width}','fit':{'points':width,'constant':False,
              'slope_pt_per_minute':1.,'r_squared':.4 if kind=='V' else .5,'mean_close':105.,'population_std_close':1.,
              'residual_rmse':.5,'fitted_first':101.,'fitted_last':109.,'first_close':101.,'last_close':109.}}
    return buy,sell,d,out


def mirrored_regression(regression: dict) -> dict:
    """
    機能: 物理価格反射で方向付き回帰値だけを反転する。
    引数: regression(dict)。返り値: dict。
    """
    out=copy.deepcopy(regression)
    for item in out['windows'].values():
        if item['fit']:
            f=item['fit'];f['slope_pt_per_minute']*=-1
            for key in ('mean_close','fitted_first','fitted_last','first_close','last_close'):f[key]=220-f[key]
    return out


class Tests(unittest.TestCase):
    def test_T境界と全幅ANDなし(self):
        """
        機能: R²=.5/距離±1を含み0傾きを拒否しMA/DIを追加しない。
        引数: self(Tests)。返り値: None。
        """
        b,s,d,r=case();b[INDEX['m5_ema21_delta_to_side']]=-99;b[INDEX['m30_di_difference_to_side']]=None
        for distance,expected in [(-1,True),(1,True),(-1.0001,False),(1.0001,False)]:
            v=list(b);v[INDEX[m.prior.DISTANCE]]=distance
            self.assertIs(m.choose(v,s,NAMES,d,r)['by_side']['1']['T']['30']['pass'],expected)
        r['windows']['30']['fit']['r_squared']=.499999
        self.assertFalse(m.choose(b,s,NAMES,d,r)['by_side']['1']['T']['30']['pass'])
        r['windows']['30']['fit'].update(r_squared=.5,slope_pt_per_minute=0)
        self.assertFalse(m.choose(b,s,NAMES,d,r)['by_side']['1']['T']['30']['pass'])

    def test_V帯と内半分の等号(self):
        """
        機能: V極値は帯等号可/CloseとLastはstrict/実P半幅等号可を検査する。
        引数: self(Tests)。返り値: None。
        """
        b,s,d,r=case('V');self.assertTrue(m.choose(b,s,NAMES,d,r)['by_side']['1']['V']['30']['pass'])
        d['r']['ohlc']['low']=101
        self.assertTrue(m.choose(b,s,NAMES,d,r)['by_side']['1']['V']['30']['pass'])
        d['r']['ohlc'].update(low=101.01,open=102)
        self.assertFalse(m.choose(b,s,NAMES,d,r)['by_side']['1']['V']['30']['pass'])
        b,s,d,r=case('V');d['r']['ohlc']['close']=101
        self.assertFalse(m.choose(b,s,NAMES,d,r)['by_side']['1']['V']['30']['pass'])
        b,s,d,r=case('V');d['q0']['last']=101
        self.assertFalse(m.choose(b,s,NAMES,d,r)['by_side']['1']['V']['30']['pass'])
        for price,expected in [(100,False),(105,True),(105.0001,False)]:
            b,s,d,r=case('V');d['q0'].update(ask=price,bid=price-1)
            self.assertIs(m.choose(b,s,NAMES,d,r)['by_side']['1']['V']['30']['pass'],expected)

    def test_V幅2bと旧方向不要(self):
        """
        機能: 幅2b等号を拒否し旧30/DI/ADXの未知をVへ追加しない。
        引数: self(Tests)。返り値: None。
        """
        b,s,d,r=case('V')
        for key in m.prior.TREND_KEYS:b[INDEX[key]]=None
        b[INDEX['m1_volume_relative_prior3']]=1
        self.assertTrue(m.choose(b,s,NAMES,d,r)['by_side']['1']['V']['30']['pass'])
        d['prior_ranges']=fixture.ranges(True,100,102)
        self.assertFalse(m.choose(b,s,NAMES,d,r)['by_side']['1']['V']['30']['checks']['width_more_two_bands'])
        r['windows']['30']['fit']['r_squared']=.5
        self.assertFalse(m.choose(b,s,NAMES,d,r)['by_side']['1']['V']['30']['pass'])

    def test_未知窓と定数は未知(self):
        """
        機能: known窓でも定数R²nullは不成立、未知値を0補完しない。
        引数: self(Tests)。返り値: None。
        """
        b,s,d,r=case();r['windows']['30']['fit'].update(constant=True,r_squared=None,slope_pt_per_minute=0)
        out=m.choose(b,s,NAMES,d,r);self.assertIsNone(out['by_side']['1']['N30']['pass'])
        d['prior_ranges']=fixture.ranges(False)
        for width in m.WINDOWS:
            w=d['prior_ranges'][str(width)];r['windows'][str(width)]={'from':w['from'],'to':w['to'],'known':False,'unknown_reasons':w['unknown_reasons'],'fit':None}
        self.assertEqual(m.choose(b,s,NAMES,d,r)['decision']['directions']['N30'],0)
        r['r_ref']='未来'
        with self.assertRaises(AssertionError):m.choose(b,s,NAMES,d,r)
        b,s,d,r=case('V');d['q0'].update(last=None,last_known=False)
        b[INDEX[m.prior.GAP]]=s[INDEX[m.prior.GAP]]=None
        result=m.choose(b,s,NAMES,d,r)
        self.assertEqual(result['decision']['directions']['R0'],0)
        self.assertIsNone(result['by_side']['1']['V']['30']['checks']['last_returns_inside'])

    def test_売買鏡像と非改変(self):
        """
        機能: T/Vの物理反射で方向を反転し入力を変更しない。
        引数: self(Tests)。返り値: None。
        """
        for kind in ('T','V'):
            b,s,d,r=case(kind);before=copy.deepcopy((b,s,d,r));out=m.choose(b,s,NAMES,d,r)
            mirror=fixture.mirror(d);rev=m.choose(s,b,NAMES,mirror,mirrored_regression(r))
            self.assertEqual((b,s,d,r),before)
            for p in m.POLICIES:self.assertEqual(out['decision']['directions'][p],-rev['decision']['directions'][p])

    def test_153共通R0全値同体(self):
        """
        機能: 153R0のtrue/false/unknownと値を変更していないことを検査する。
        引数: self(Tests)。返り値: None。
        """
        for kind in ('T','V'):
            for key,value in [(None,None),('m1_volume_relative_prior3',None),(m.prior.DISTANCE,-2),(m.prior.DISTANCE,1.001),(m.prior.GAP,None),(m.prior.ATR,0)]:
                b,s,d,r=case(kind)
                if key:b[INDEX[key]]=value
                old=m.prior.choose(b,s,NAMES,d);new=m.choose(b,s,NAMES,d,r)
                for side in ('1','-1'):
                    self.assertEqual(old['by_side'][side]['R0'],new['by_side'][side]['R0'])

    def test_回帰数値のbool拒否(self):
        """
        機能: constant以外のfit数値をboolで偽装できないことを検査する。
        引数: self(Tests)。返り値: None。
        """
        for key in ('points','slope_pt_per_minute','r_squared','residual_rmse'):
            b,s,d,r=case();r['windows']['30']['fit'][key]=True
            with self.assertRaises(AssertionError):m.choose(b,s,NAMES,d,r)


if __name__=='__main__':
    unittest.main(verbosity=2)
