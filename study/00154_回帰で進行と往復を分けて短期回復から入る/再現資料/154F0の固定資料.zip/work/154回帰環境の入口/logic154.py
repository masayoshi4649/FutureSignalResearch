"""154は153共通R0を保ち、r除外の回帰環境と端/価格位置を複合する。"""
from pathlib import Path
import importlib.util
import math

ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('fixed153_for154',ROOT/'work/153独立出生の入口/logic153.py')
prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)
WINDOWS=(15,30,60)
POLICIES=('R0','T30','V30','N15','N30','N60')


def validate_regression(measurement: dict,regression: dict) -> None:
    """
    機能: 同じq0/rと完全窓の測定を一意に結び、未知の数値補完を拒否する。
    引数: measurement/regression(dict)。返り値: None。
    """
    assert regression['event_id']==measurement['event_id'] and regression['r_ref']==measurement['r']['id']
    assert regression['eligible'] is measurement['eligible'] and set(regression['windows'])==set(map(str,WINDOWS))
    for width in WINDOWS:
        fit=regression['windows'][str(width)];window=measurement['prior_ranges'][str(width)]
        assert (fit['from'],fit['to'],fit['known'],fit['unknown_reasons'])==(window['from'],window['to'],window['known'],window['unknown_reasons'])
        if window['known']:
            value=fit['fit'];assert type(value['points']) is int and value['points']==width and type(value['constant']) is bool
            assert set(value)=={'points','constant','slope_pt_per_minute','r_squared','mean_close','population_std_close','residual_rmse','fitted_first','fitted_last','first_close','last_close'}
            for name,number in value.items():
                if name in ('points','constant'):continue
                if name=='r_squared' and number is None:continue
                assert type(number) in (int,float) and math.isfinite(number)
            assert value['population_std_close']>=0 and value['residual_rmse']>=0 and value['first_close']>0 and value['last_close']>0
            if value['constant']:assert value['r_squared'] is None and value['slope_pt_per_minute']==0
            else:assert value['r_squared'] is not None and 0<=value['r_squared']<=1
        else:assert fit['fit'] is None and 'first_ref' not in fit and 'last_ref' not in fit


def common(v: dict,q: dict) -> tuple:
    """
    機能: 153 chooseの共通R0と同じ演算順・knownで判定する。
    引数: v/q(dict)。返り値: tuple[dict,dict]はR0とR6。
    """
    rr=prior.recovery({k:v[k] for k in prior.R_KEYS});spread=q['ask']-q['bid'] if q['normal_bbo'] else None
    gate=prior.gate({'eligible':True,'R':rr['value'],'normal_bbo':q['normal_bbo'],
        'spread_positive':prior.compare(spread,'>',0),'spread_max20':prior.compare(spread,'<=',20),
        'gap_abs_max1':prior.compare(abs(v[prior.GAP]) if v[prior.GAP] is not None else None,'<=',1),
        'ema8_chase_max1':prior.compare(v[prior.DISTANCE],'<=',1),'atr5_positive':prior.compare(v[prior.ATR],'>',0)},
        {'atr5':v[prior.ATR],'entry_price_q0':None,'ema8_distance_atr5':v[prior.DISTANCE],
         'last_close_gap_atr5':v[prior.GAP],'spread':spread})
    return gate,rr


def choose(buy: list,sell: list,columns: list,measurement: dict,regression: dict) -> dict:
    """
    機能: 100Xとq0構造/回帰だけで各側T/V/ORを独立出生する。
    引数: buy/sell(list)、columns(list[str|dict])、measurement/regression(dict)。
    返り値: dictはby_side/decision。q1/対照/ラベル/教師を受け取らない。
    """
    prior.validate_measurement(measurement);validate_regression(measurement,regression)
    assert measurement['eligible'] is True
    names=[c['name'] if isinstance(c,dict) else c for c in columns]
    required=tuple(sorted(set((*prior.R_KEYS,prior.ATR,prior.DISTANCE,prior.GAP))))
    assert len(names)==len(set(names))==len(buy)==len(sell)==100 and set(required)<=set(names)
    index={name:i for i,name in enumerate(names)};q=measurement['q0'];o=measurement['r']['ohlc'];last=prior.number(q['last']);sides={}
    for t,vector in ((1,buy),(-1,sell)):
        values=prior.values(vector,index,required);atr=values[prior.ATR];distance=values[prior.DISTANCE]
        price=q['ask' if t==1 else 'bid'] if q['normal_bbo'] else None
        r0,recovery=common(values,q);r0['values']['entry_price_q0']=price
        band=.25*atr if atr is not None and atr>0 else None
        branch={'R0':r0,'R':recovery,'T':{},'V':{},'geometry':{'atr5':atr,'band':band,'entry_price_q0':price,'ema8_distance_atr5':distance}}
        for width in WINDOWS:
            key=str(width);window=measurement['prior_ranges'][key];fit=regression['windows'][key]['fit']
            r2=fit['r_squared'] if fit else None;slope=fit['slope_pt_per_minute'] if fit else None
            trend=prior.gate({'common':r0['pass'],'window_known':window['known'],'r2_at_least_half':prior.compare(r2,'>=',.5),
                'slope_to_side_positive':prior.compare(t*slope if slope is not None else None,'>',0),
                'ema8_distance_at_least_minus1':prior.compare(distance,'>=',-1)},
                {'window_minutes':width,'r_squared':r2,'slope_to_side':t*slope if slope is not None else None,'entry_distance_atr5':distance})
            lower,upper=window['low'],window['high'];edge=lower if t==1 else upper
            width_points=window['range_points'];extreme=o['low' if t==1 else 'high']
            extreme_distance=t*(extreme-edge) if edge is not None else None
            close_distance=t*(o['close']-edge) if edge is not None else None
            last_distance=t*(last-edge) if edge is not None and last is not None else None
            entry_distance=t*(price-edge) if edge is not None and price is not None else None
            value=prior.gate({'common':r0['pass'],'window_known':window['known'],'r2_below_half':prior.compare(r2,'<',.5),
                'width_more_two_bands':prior.compare(width_points,'>',2*band if band is not None else None),
                'opposite_extreme_touches_band':prior.compare(extreme_distance,'<=',band),
                'close_returns_inside':prior.compare(close_distance,'>',band),'last_returns_inside':prior.compare(last_distance,'>',band),
                'entry_inside_positive':prior.compare(entry_distance,'>',0),
                'entry_within_half_range':prior.compare(entry_distance,'<=',width_points/2 if width_points is not None else None)},
                {'window_minutes':width,'lower':lower,'upper':upper,'edge':edge,'band':band,'r_squared':r2,
                 'opposite_extreme_distance':extreme_distance,'close_edge_distance':close_distance,
                 'last_edge_distance':last_distance,'entry_edge_distance':entry_distance,'width':width_points})
            branch['T'][key]=trend;branch['V'][key]=value
            flag=prior.logical_or([trend['pass'],value['pass']])
            branch['N'+key]={'known':flag is not None,'pass':flag,'origins':[name for name,item in [('T'+key,trend),('V'+key,value)] if item['pass'] is True]}
        sides[str(t)]=branch
    directions={};conflicts={};evidence=[]
    for policy in POLICIES:
        hits=[]
        for t in (1,-1):
            side=sides[str(t)];item=side['T']['30'] if policy=='T30' else side['V']['30'] if policy=='V30' else side[policy]
            if item['pass'] is True:
                hits.append(t);evidence.append({'rule':policy,'signal_side':t,'order_side':t,
                    'roles':['構造','勢い','量'] if policy=='R0' else ['方向','構造','勢い','値幅','量'],
                    'origins':item.get('origins',[policy])})
        directions[policy]=hits[0] if len(hits)==1 else 0;conflicts[policy]=len(hits)>1
    return {'by_side':sides,'decision':{'directions':directions,'conflicts':conflicts,'evidence':evidence}}
