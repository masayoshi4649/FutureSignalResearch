# 154：回帰環境から独立出生する準備

準備完了・F0未固定。採用の原文は `work/154採用条件のRoot通知.md`、数値と入力指紋の正本は [条件.json](条件.json)。自然154の売買採否・容量・金融はRoot F0後だけ実行する。153以前の源を変更しない。

主U30=C1∪N30、Nw=Tw OR Vw。rを除く1分の実時間30分窓を主、15/60を比較として事前採用し、結果後に交換しない。共通R0の1分実体/現在p.Open回復/5分Hist・RSI増分/同r量>=1、正常q0 BBO/spread(0,20]、ATR5正、Last/r.Close距離絶対1以下、実側EMA8距離上限1は153と同じ。

TwはR0に、完全known窓・R²定義・R²>=.5・t側OLS傾き正・実側EMA8距離>=−1を加える。VwはR0に、完全known窓・R²定義・R²<.5、幅>2b（b=.25ATR5）を加える。edgeは買L/売U、逆端は買r.Low/売r.High。逆端の方向距離<=b、CloseとLastの距離>b、実Ask/Bidの距離は0超かつ幅/2以下。Vに反対側内境界・strict帯外侵入・量1.25・旧30向き/DI条件を追加しない。Tに全幅MA/DI/ADX ANDを追加しない。

純APIは `logic154.choose(buy,sell,columns,measurement,regression)`。100列とq0/r/先行域/同じr除外OLSだけを受け、旧選択/P65/モデル/教師/q1/金融を引数に持たない。measurementは153DTOにevent_idを足し、regressionはprior_close_ols_v1の同event/r_ref/windows行。R²定数null、未知域は待機。片側true・反対unknownは一方向採用、同q0両trueは待機。ORはknown true優先。

返り値 `by_side['1'/'-1']` はR0/R、T/Vの窓別gate、N15/N30/N60、geometry。gateにはknown/pass/false/unknown/checks/valuesを保持し、取得前の証拠とする。decisionはdirections/conflicts/evidence。Hist/RSIは同じ勢い役割で二重票とせず、OLSとMAも独立した証拠数として加算しない。

運転は全35,339q0の100X/r/Quoteと、全40,544測定行の同event/r/窓/時間窓のfirst-last refsを先照合する。全新q0判断を排他保存してからcapture/metaと固定旧153/152選択を読み、C1優先で接続する。別q0同q1の後発aliasは追加計上せず、最初q0index→line→IDのcanonicalを取り消したり反対側へ取り直したりしない。

旧153R0の1,375取得は、新判断終了後にcase/side/stream/q0時計を含む全取得参照値で照合する。旧R0を新出生資格へ使わない。U153は旧153U15全93を全値copy、B152/UB152は旧152B0/U1の614/697を全値copyし旧153内の同対照とも一致を確認する。C1=87も同体。RR0/RU30/C0/RC1は金融側で同q1別streamから派生し、Sourceでは新しい逆予測を作らない。

CLI:

```powershell
& work/複合テクニカル学習環境/Scripts/python.exe -X utf8 work/154回帰環境の入口/選択する.py --book work/154回帰環境の入口/条件.json --book-sha256 <固定SHA> --output-dir work/154回帰環境の評価/入口選択 --execute-after-f0
```

未作成出力先のみ。全物理SHAを先確認し、gzipの全CRC/解凍SHA/statを確認して直接読む。大入力の解凍副本は作らない。前後の全源/入力SHAとstatを検査する。

- `q0の判断.json`: 成功/試行/全q0判断数/rows。各rowはevent_id/session/contract/session_index/q0_time/index/line/r_ref/technical/decision。未取得でも全q0保持。
- `選択対応.json`: 主U30、政策dict C1/B152/UB152/U153/R0/T30/V30/N15/N30/N60/U15/U30/U60、候補と取得、旧C1重複はU15/U30/U60別dict。NN30はN30同体aliasで金融政策外。
- `選択の確認.json`: 全源/入力SHA、CRC/物理・解凍/stat証跡、旧対照照合、出力SHAと件数。

17政策×2軸×2H×5幅×3parts=1,020比較はRoot金融側。全73min1・平均概ね1/h・同幅70%を別及び共同判定し、未到達/不足/IFD未知と利益/損失を残す。実逆を1−pとしない。全73既使用・153後の事後着想であり、R²=.5等は最適値でも将来確率でもない。41で回帰を既検証して未達だったことを保持する。RMSEはsqrt(SSE/w)の測定記録で採否に使わない。

準備は純7群＋運転4群。153R0のtrue/false/unknown全gate値、T/V境界、量1、fit数値bool拒否、買売鏡像/非改変、全metadata先照合、同q1/C1優先、旧R0後段一致、旧対照deepcopy、実行旗なし本文I/O拒否を確認する。自然件数の成功を人工から推定しない。
