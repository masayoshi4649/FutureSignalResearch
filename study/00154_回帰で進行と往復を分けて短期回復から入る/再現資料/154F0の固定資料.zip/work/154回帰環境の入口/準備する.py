"""154は自然売買を実行せず人工・構文・物理入力指紋だけを停止する。"""
from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import os
import subprocess
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def sha(path: Path) -> str:
    """
    機能: 物理SHAだけをbufferで計算する。
    引数: path(Path)。返り値: str。
    """
    h=hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda:source.read(1<<20),b''):h.update(block)
    return h.hexdigest()


def save(path: Path,value: dict) -> None:
    """
    機能: UTF8で停止票を排他保存する。
    引数: path(Path)、value(dict)。返り値: None。
    """
    with path.open('x',encoding='utf-8') as output:json.dump(value,output,ensure_ascii=False,indent=2,allow_nan=False);output.write('\n')


def main() -> None:
    """
    機能: 11人工・関数コメント・全入力物理指紋を確認し自然未実行で停止する。
    引数: なし。返り値: None。
    """
    book=json.loads((HERE/'条件.json').read_bytes());paths=sorted(HERE.glob('*.py'))+[HERE/'条件.json',HERE/'README.md']
    paths+=list(ROOT/p for p in book['sources'] if ROOT/p not in paths)
    before={p.relative_to(ROOT).as_posix():sha(p) for p in paths};syntax=[]
    for path in HERE.glob('*.py'):
        tree=ast.parse(path.read_text(encoding='utf-8'));compile(tree,str(path),'exec')
        for node in ast.walk(tree):
            if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
                doc=ast.get_docstring(node);assert doc and '\n' in doc and all(k in doc for k in ('機能:','引数:','返り値:')),(path.name,node.name)
        syntax.append(path.name)
    spec=importlib.util.spec_from_file_location('validate154book',HERE/'選択する.py');runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner);runner.validate_book(book)
    logs={};env=dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8:strict')
    for name in ('人工検査.py','人工検査_運転.py'):
        command=[sys.executable,'-X','utf8',str(HERE/name)]
        run=subprocess.run(command,cwd=HERE,env=env,capture_output=True,encoding='utf-8',errors='strict')
        assert run.returncode==0 and '\ufffd' not in run.stdout+run.stderr,run.stderr
        logs[name]={'command':command,'exit_code':run.returncode,'stdout':run.stdout,'stderr':run.stderr}
    refs=list(book['features_source'].values())+[book['range_input'],book['regression_input']]
    for key in ('fixed152_control','fixed153_control'):refs.extend([book[key]['selection'],book[key]['f1']])
    refs.append({'path':'inputs/00148_全1分入口母集団/100特徴の列定義.json','sha256':book['catalog_definition_sha256']})
    physical={}
    for ref in refs:
        path=ROOT/ref['path'];stat=path.stat();assert sha(path)==ref['sha256']
        physical[ref['path']]={'sha256':ref['sha256'],'bytes':stat.st_size,'mtime_ns':stat.st_mtime_ns,'自然JSON本文未読':True}
    assert all(sha(ROOT/p)==h for p,h in before.items()) and all(sha(ROOT/p)==h for p,h in book['sources'].items())
    proof={'成功':True,'試行':154,'状態':'準備完了/F0未固定','自然154売買_容量_金融未実行':True,'自然入力本文未読':True,
        'Raw_CSV_追加2場未読':True,'新教師又は学習なし':True,'純人工数':7,'運転人工数':4,'UTF8_strict':True,
        '人工':logs,'構文と型付き複数行コメント':syntax,'採用通知SHA256':book['sources']['work/154採用条件のRoot通知.md'],
        '入力は物理SHAのみ':physical,'源':before,'源前後同体':True}
    save(HERE/'準備の確認.json',proof);save(HERE/'停止.json',{'成功':True,'試行':154,'編集停止':True,'自然未実行':True,
        '源':before,'準備の確認_SHA256':sha(HERE/'準備の確認.json')})
    print(json.dumps({'成功':True,'条件':sha(HERE/'条件.json'),'準備':sha(HERE/'準備の確認.json'),'停止':sha(HERE/'停止.json')},ensure_ascii=False))


if __name__=='__main__':
    main()
