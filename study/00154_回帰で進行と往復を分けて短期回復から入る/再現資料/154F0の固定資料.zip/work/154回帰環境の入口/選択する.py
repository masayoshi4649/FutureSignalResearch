"""154の全新q0判断を排他保存した後にだけ、取得と旧対照を結ぶ。"""
from pathlib import Path
import argparse
import copy
import gc
import importlib.util
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('fixed153_driver154',ROOT/'work/153独立出生の入口/選択する.py')
shared=importlib.util.module_from_spec(spec);spec.loader.exec_module(shared)
sha=shared.sha
save=shared.save
module=shared.module


def validate_book(book: dict) -> None:
    """
    機能: Root採用の主/境界/段階分離を本文読取前に照合する。
    引数: book(dict)。返り値: None。
    """
    assert book['trial']==154 and book['parent_trial']==148 and book['primary']=='U30'
    assert book['primary_window_minutes']==30 and book['comparison_unions']==['U15','U60']
    assert (book['feature_rows'],book['session_count'],book['legacy_count'],book['catalog_count'])==(35339,73,87,100)
    assert book['common']=={'R_all6known_same_as_152':True,'normal_q0_bbo':True,'spread_range':'(0,20]',
        'abs_last_close_atr5_max':1,'final_order_ema8_distance_upper_inclusive':1,'atr5_strict_positive':True}
    assert book['T']=={'common_R0_same_as_153':True,'known_window_and_defined_r_squared':True,'r_squared_at_least':.5,
        'slope_to_side_strict_positive':True,'ema8_distance_at_least':-1,'upper_1_inherited_R0':True,'MTF_MA_DI_ADX_AND':False}
    assert book['V']=={'common_R0_same_as_153':True,'known_window_and_defined_r_squared':True,'r_squared_strict_below':.5,
        'band_atr5_ratio':.25,'width_strict_more_two_bands':True,'edge':'買low/売high',
        'opposite_extreme_distance_max_band_inclusive':True,'close_and_last_distance_strict_above_band':True,
        'entry_edge_distance_strict_positive':True,'entry_edge_distance_max_half_width_inclusive':True,'old30_or_DI_reversal_required':False}
    assert book['no_P65_P60_qualification'] and book['no_model_or_teacher']
    assert book['R']['per_side_all_required_known'] and book['R']['one_true_other_unknown_choose_true']
    assert book['R']['both_true_wait'] and book['R']['no_true_wait']
    assert book['fixed153_control']['expected_counts']=={'U153':93,'R0':1375,'C1':87}
    assert book['fixed153_control']['read_only_after_all_new_q0_saved'] and book['fixed152_control']['read_only_after_all_new_q0_saved']
    assert book['financial_policies']==['C0','C1','RC1','B152','UB152','U153','R0','RR0','T30','V30','N30','U30','RU30','N15','U15','N60','U60']


def measurements(features: object,witness: dict,high: dict,regression: dict,core: object,expected_rows: int=40544) -> tuple:
    """
    機能: 153先検査を再用し、全q0のOLS/r/窓/refsを選択前に結合する。
    引数: features(object)、witness/high/regression(dict)、core(object)、expected_rows(int)。返り値: tuple[list,list]。
    """
    joined=shared.measurements(features,witness,high,core.prior,expected_rows)
    assert regression['success'] and regression['schema']=='prior_close_ols_v1'
    assert not regression['strategy_selected'] and not regression['financial_labels_used']
    assert regression['sessions']==high['sessions'] and len(regression['scenes'])==len(high['scenes'])
    assert regression['windows_minutes']==[15,30,60]
    eligible={};all_ids=set();count=0
    for original,measured in zip(high['scenes'],regression['scenes']):
        assert (original['session'],original['contract'])==(measured['session'],measured['contract'])
        assert len(original['rows'])==len(measured['rows']);starts={b['start']:b for b in original['bars']}
        for row,out in zip(original['rows'],measured['rows']):
            assert row['event_id'] not in all_ids;all_ids.add(row['event_id']);count+=1
            assert all(row[k]==out[k] for k in ('event_id','r_ref','eligible'))
            assert set(out['windows'])=={'15','30','60'}
            for width in core.WINDOWS:
                w=row['prior_ranges'][str(width)];fit=out['windows'][str(width)]
                assert all(w[k]==fit[k] for k in ('from','to','known','unknown_reasons'))
                if w['known']:
                    assert fit['first_ref']==starts[w['from']]['id'] and fit['last_ref']==starts[w['to']-60]['id']
                    assert fit['fit']['points']==width
                else:assert fit['fit'] is None and 'first_ref' not in fit and 'last_ref' not in fit
            if row['eligible']:eligible[row['event_id']]=out
    assert count==expected_rows and len(eligible)==len(features.q0_meta)
    regrows=[]
    for meta,dto in zip(features.q0_meta,joined):
        dto['event_id']=meta['event_id'];value=eligible[meta['event_id']]
        core.validate_regression(dto,value);regrows.append(value)
    return joined,regrows


def project(features: object,joined: list,regrows: list,core: object) -> list:
    """
    機能: 全q0を新測定だけで判定し、旧選択/取得を引数に持たない。
    引数: features(object)、joined/regrows(list)、core(object)。返り値: list[dict]。
    """
    assert len(joined)==len(regrows)==len(features.q0_meta);rows=[]
    for i,(meta,dto,regression) in enumerate(zip(features.q0_meta,joined,regrows)):
        chosen=core.choose(features.buy_X[i].tolist(),features.sell_X[i].tolist(),list(features.columns),dto,regression)
        decision=chosen['decision'];decision['directions']['NN30']=decision['directions']['N30'];decision['conflicts']['NN30']=decision['conflicts']['N30']
        rows.append({**meta,'r_ref':dto['r']['id'],'technical':chosen['by_side'],'decision':decision})
        if (i+1)%5000==0:print(json.dumps({'判定済q0':i+1,'全q0':len(joined)},ensure_ascii=False),flush=True)
    return rows


def connect(decisions: list,captures: dict,metadata: dict,sessions: list,helper: object) -> dict:
    """
    機能: 新q0保存後の参照でC1優先の3unionを接続する。
    引数: decisions(list)、captures/metadata(dict)、sessions(list)、helper(object)。返り値: dict。
    """
    names=['R0','T30','V30','N15','N30','N60']
    setting={'rules':[{'id':p} for p in names],'union_rules':['N30'],'union_id':'NN30','legacy_id':'C1','main_id':'U30','session_count':len(sessions),'legacy_count':87}
    out=helper.connect(decisions,captures['rows'],metadata['population148']['cases'],sessions,setting)
    baseline={r['case_id']:r for r in out['政策']['C1']};overlap={'U30':out.pop('旧C1重複')}
    for union,new in [('U15','N15'),('U60','N60')]:
        merged=dict(baseline);collisions=[]
        for row in out['政策'][new]:
            key=row['case_id']
            if key in merged:collisions.append({'case_id':key,'legacy_side':merged[key]['side'],'new_side':row['side'],'opposite':merged[key]['side']!=row['side']})
            else:merged[key]=row
        out['政策'][union]=list(merged.values());overlap[union]=collisions
    out['旧C1重複']=overlap;return out


def bind_controls(result: dict,old153: dict,old152: dict,expected: dict=None) -> None:
    """
    機能: 新全q0後にだけ旧153R0/旧対照を照合しU153を全値copyする。
    引数: result/old153/old152(dict)、expected(dict|None)。返り値: None。
    """
    expected=expected or {'U153':93,'R0':1375,'C1':87}
    assert old153['成功'] and old153['試行']==153 and old153['選択時の金融ラベル利用'] is False
    shared.bind_controls(result,old152,{'B152':614,'UB152':697,'C1':expected['C1']})
    for policy in ('C1','R0','B152','UB152'):
        current={r['case_id']:r for r in result['政策'][policy]};previous={r['case_id']:r for r in old153['政策'][policy]}
        assert current==previous and len(current)==len(result['政策'][policy])==len(old153['政策'][policy]),policy
    assert len(result['政策']['R0'])==expected['R0'] and len(old153['政策']['U15'])==expected['U153']
    result['政策']['U153']=copy.deepcopy(old153['政策']['U15'])
    result['旧153同体']={'成功':True,'U153件数':expected['U153'],'旧R0取得件数':expected['R0'],
        'R0全参照値同体':True,'C1_B152_UB152全値同体':True,'旧選択を新判断へ未使用':True}


def main() -> None:
    """
    機能: Root F0後だけ全新q0保存→取得と旧対照接続を行う。
    引数: CLI book(Path)/book-sha256(str)/output-dir(Path)/execute-after-f0(bool)。返り値: None。
    """
    parser=argparse.ArgumentParser()
    parser.add_argument('--book',type=Path,required=True);parser.add_argument('--book-sha256',required=True)
    parser.add_argument('--output-dir',type=Path,required=True);parser.add_argument('--execute-after-f0',action='store_true')
    args=parser.parse_args();args.book=args.book.resolve();args.output_dir=args.output_dir.resolve()
    assert args.execute_after_f0 and not args.output_dir.exists() and sha(args.book)==args.book_sha256
    book=json.loads(args.book.read_bytes());validate_book(book);declared={ROOT/p:h for p,h in book['sources'].items()};declared[args.book]=args.book_sha256
    for value in book['features_source'].values():declared[ROOT/value['path']]=value['sha256']
    for value in [book['range_input'],book['regression_input'],book['fixed152_control']['selection'],book['fixed152_control']['f1'],book['fixed153_control']['selection'],book['fixed153_control']['f1']]:declared[ROOT/value['path']]=value['sha256']
    catalog=ROOT/'inputs/00148_全1分入口母集団/100特徴の列定義.json';declared[catalog]=book['catalog_definition_sha256']
    assert all(sha(p)==h for p,h in declared.items());before={str(p):[p.stat().st_size,p.stat().st_mtime_ns] for p in declared}
    data=module(ROOT/'work/151過去場判別/data151.py','feature_only154');core=module(HERE/'logic154.py','logic154run')
    helper=module(ROOT/'scripts/入口研究/固定特徴から可読条件を選択する.py','helper154')
    refs={k:data.FileRef(ROOT/v['path'],v['sha256'],v['decoded_sha256']) for k,v in book['features_source'].items()}
    raw,features_evidence=data.read_ref(refs['features']);fixed,fixed_evidence=data.read_ref(refs['fixed'])
    features=data.feature_dataset_from_objects(raw,fixed,73,35339);witness=shared.witnesses(raw)
    assert list(features.columns)==[c['name'] for c in json.loads(catalog.read_bytes())];del raw,fixed;gc.collect()
    range_ref=book['range_input'];high,range_evidence=data.read_ref(data.FileRef(ROOT/range_ref['path'],range_ref['sha256'],range_ref['decoded_sha256']))
    reg_ref=book['regression_input'];regression,reg_evidence=data.read_ref(data.FileRef(ROOT/reg_ref['path'],reg_ref['sha256'],reg_ref['decoded_sha256']))
    assert regression['source']=={k:range_ref[k] for k in ('path','sha256','decoded_sha256')}
    joined,regrows=measurements(features,witness,high,regression,core);del high,regression,witness;gc.collect()
    decisions=project(features,joined,regrows,core);del joined,regrows;gc.collect()
    assert all(sha(p)==h for p,h in declared.items());args.output_dir.mkdir(parents=True)
    save(args.output_dir/'q0の判断.json',{'成功':True,'試行':154,'全q0判断数':len(decisions),'新学習又はモデル':False,
        'P65_P60又は旧選択を資格へ使用':False,'全新q0判断後に取得結合':True,'rows':decisions})
    # ----------------------------------------
    # ここからだけcapture/metaと旧153/152を読む。旧q0/金融/教師は読まない。
    captures,_=data.read_ref(refs['captures']);metadata,_=data.read_ref(refs['metadata']);sessions=[s['session'] for s in features.scenes]
    assert captures['sessions']==metadata['sessions']==sessions
    result=connect(decisions,captures,metadata,sessions,helper);controls={}
    for number,key in [(153,'fixed153_control'),(152,'fixed152_control')]:
        control=book[key];freeze=json.loads((ROOT/control['f1']['path']).read_bytes())
        old_key='work/153独立出生の評価/入口選択/選択対応.json' if number==153 else 'work/152複合回復の評価/入口選択/選択対応.json'
        assert freeze['ファイル'][old_key]==control['selection']['decoded_sha256']
        ref=control['selection'];controls[number],_=data.read_ref(data.FileRef(ROOT/ref['path'],ref['sha256'],ref['decoded_sha256']))
    bind_controls(result,controls[153],controls[152],book['fixed153_control']['expected_counts'])
    save(args.output_dir/'選択対応.json',{'成功':True,'試行':154,'主政策':'U30','book_sha256':args.book_sha256,
        '高安入力解凍SHA256':range_ref['decoded_sha256'],'回帰入力解凍SHA256':reg_ref['decoded_sha256'],**result})
    assert all(sha(p)==h for p,h in declared.items()) and before=={str(p):[p.stat().st_size,p.stat().st_mtime_ns] for p in declared}
    save(args.output_dir/'選択の確認.json',{'成功':True,'試行':154,'新学習又は金融又はRaw':False,'全metadata検査後に判断':True,
        '全新q0保存後に取得と固定対照読取':True,'入力':{str(p.relative_to(ROOT)).replace('\\','/'):h for p,h in declared.items()},
        '全入力前後SHA_stat同体':True,'特徴読取証跡':features_evidence,'固定入力読取証跡':fixed_evidence,'高安読取証跡':range_evidence,'回帰読取証跡':reg_evidence,
        '政策別取得数':{k:len(v) for k,v in result['政策'].items()},'出力':{p.name:sha(p) for p in args.output_dir.iterdir() if p.is_file()}})
    print(json.dumps({'成功':True,'政策別取得数':{k:len(v) for k,v in result['政策'].items()}},ensure_ascii=False))


if __name__=='__main__':
    main()
