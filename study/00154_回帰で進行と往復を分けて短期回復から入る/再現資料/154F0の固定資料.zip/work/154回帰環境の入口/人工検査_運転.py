"""154全q0先検査と旧選択を後段copyする契約だけを人工で検査する。"""
from pathlib import Path
from unittest.mock import patch
import copy
import importlib.util
import sys
import unittest
import logic154 as core

ROOT=Path(__file__).resolve().parents[2]
sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'work/153独立出生の入口'))
spec=importlib.util.spec_from_file_location('source153fixtures154',ROOT/'work/153独立出生の入口/人工検査_運転.py')
fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
spec=importlib.util.spec_from_file_location('runner154test',Path(__file__).with_name('選択する.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


def make_joined() -> tuple:
    """
    機能: r以前60本の既知prefixと対応OLS行を人工で作る。
    引数: なし。返り値: tupleは特徴/照合票/高安/OLS。
    """
    f,w,h=fixture.joined_fixture();scene=h['scenes'][0];row=scene['rows'][0];r=scene['bars'][0];bars=[]
    for i in range(60):
        price=90+i*.1;bars.append({'id':f'先{i}','start':i*60,'end':(i+1)*60,'available_at':(i+2)*60,
            'stamp':{'time':3660,'index':9,'line':10},'price_known':True,'volume_known':False,'closed':True,'missing':False,
            'ohlc':{'open':price,'high':price,'low':price,'close':price}})
    scene['bars']=bars+[r];scene['start']=f.scenes[0]['start']=0;out={'event_id':'e0','r_ref':'r','eligible':True,'windows':{}}
    for width in core.WINDOWS:
        feet=bars[60-width:];window=row['prior_ranges'][str(width)]
        window.update(known=True,unknown_reasons=[],price_known_count=width,high=feet[-1]['ohlc']['high'],low=feet[0]['ohlc']['low'])
        window['range_points']=window['high']-window['low'];window['range_zero']=False
        for key,foot in [('high_first_ref',feet[-1]),('low_first_ref',feet[0])]:window[key]={k:foot[k] for k in ('id','start','end')}
        out['windows'][str(width)]={'from':window['from'],'to':window['to'],'known':True,'unknown_reasons':[],
            'first_ref':feet[0]['id'],'last_ref':feet[-1]['id'],'fit':{'points':width,'constant':False,'slope_pt_per_minute':.1,
            'r_squared':1.,'mean_close':93.,'population_std_close':1.,'residual_rmse':0.,'fitted_first':feet[0]['ohlc']['close'],
            'fitted_last':feet[-1]['ohlc']['close'],'first_close':feet[0]['ohlc']['close'],'last_close':feet[-1]['ohlc']['close']}}
    ols={'success':True,'schema':'prior_close_ols_v1','strategy_selected':False,'financial_labels_used':False,
        'sessions':['人工'],'windows_minutes':[15,30,60],'scenes':[{'session':'人工','contract':'X','rows':[out]}]}
    return f,w,h,ols


def make_links() -> tuple:
    """
    機能: 旧87と同q1反対aliasの判断を154政策へ写す。
    引数: なし。返り値: tuple。
    """
    d,c,meta,s=fixture.link_fixture()
    for row in d:
        side=next(iter(row['decision']['directions'].values()));names=(*core.POLICIES,'NN30')
        row['decision']={'directions':{p:side for p in names},'conflicts':{p:False for p in names},
            'evidence':[{'rule':p,'order_side':side} for p in core.POLICIES]}
    return d,c,meta,s


class Tests(unittest.TestCase):
    def test_全OLS照合後にだけ判定(self):
        """
        機能: 全q0/r/first-last refs不一致をchoose前に拒否する。
        引数: self(Tests)。返り値: None。
        """
        f,w,h,r=make_joined();before=copy.deepcopy((w,h,r))
        with patch.object(core,'choose',wraps=core.choose) as choose:
            joined,reg=m.measurements(f,w,h,r,core,1);self.assertEqual(choose.call_count,0)
            projected=m.project(f,joined,reg,core);self.assertEqual(choose.call_count,1)
        self.assertEqual(projected[0]['decision']['directions']['NN30'],1);self.assertEqual((w,h,r),before)
        for field in ('event_id','r_ref','first_ref'):
            bad=copy.deepcopy(r);out=bad['scenes'][0]['rows'][0]
            if field=='first_ref':out['windows']['30'][field]='後足'
            else:out[field]='後足'
            with self.assertRaises(AssertionError):m.measurements(f,w,h,bad,core,1)

    def test_同q1最初とC1優先三union(self):
        """
        機能: 同q1後発反対を再採用せずC1を全unionで優先する。
        引数: self(Tests)。返り値: None。
        """
        d,c,meta,s=make_links();before=copy.deepcopy((d,c,meta));out=m.connect(d,c,meta,s,fixture.helper)
        for name in ('U15','U30','U60'):
            rows={r['case_id']:r for r in out['政策'][name]}
            self.assertEqual(len(rows),88);self.assertEqual(rows['新']['event_id'],'先')
            self.assertEqual((rows['旧00']['side'],rows['旧00']['stream']),(-1,'original'))
        self.assertEqual((d,c,meta),before)

    def test_旧R0の後段同体と対照copy(self):
        """
        機能: 新判断後の旧R0全参照照合と対照の非破壊copyを検査する。
        引数: self(Tests)。返り値: None。
        """
        d,c,meta,s=make_links();out=m.connect(d,c,meta,s,fixture.helper)
        old152={'成功':True,'試行':152,'選択時の金融ラベル利用':False,'政策':{'C1':copy.deepcopy(out['政策']['C1']),
            'B0':[{'case_id':f'b{i}','未知欄':{'値':[None]}} for i in range(614)],'U1':[{'case_id':f'u{i}'} for i in range(697)]}}
        old153={'成功':True,'試行':153,'選択時の金融ラベル利用':False,'政策':{'C1':copy.deepcopy(out['政策']['C1']),
            'R0':copy.deepcopy(out['政策']['R0']),'B152':copy.deepcopy(old152['政策']['B0']),
            'UB152':copy.deepcopy(old152['政策']['U1']),'U15':[{'case_id':'旧主','全値':{'未知':[None]}}]}}
        before=copy.deepcopy((old152,old153));m.bind_controls(out,old153,old152,{'U153':1,'R0':2,'C1':87})
        self.assertEqual(out['政策']['U153'],old153['政策']['U15']);out['政策']['U153'][0]['全値']['未知'].append(5)
        self.assertEqual((old152,old153),before)
        old153['政策']['R0'][0]['side']*=-1
        with self.assertRaises(AssertionError):m.bind_controls(out,old153,old152,{'U153':1,'R0':2,'C1':87})

    def test_明示実行なしは本文IOなし(self):
        """
        機能: F0実行旗なしでbook本文へ到達しないことを検査する。
        引数: self(Tests)。返り値: None。
        """
        with patch.object(sys,'argv',['選択する.py','--book','存在しない.json','--book-sha256','0'*64,'--output-dir','存在しない出力']),patch.object(m,'sha',side_effect=RuntimeError('本文IO禁止')) as io:
            with self.assertRaises(AssertionError):m.main()
            self.assertEqual(io.call_count,0)


if __name__=='__main__':
    unittest.main(verbosity=2)
