"""154の最終bookを一度保存し、実行前3MD・設定513構造を固定する。"""
from pathlib import Path
import hashlib
import json
import re
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
FORMAL = ROOT / 'study/00154_回帰で進行と往復を分けて短期回復から入る'
SOURCE = ROOT / 'work/154回帰環境の入口'
PERMANENT = ROOT / 'inputs/00154_先行終値の回帰測定/条件.json'
BOOK_SHA = '4704d9cb453a305673fbe9a4b1b984983cc10a0a85b0c96f8efc0a63a371a951'
PREP_SHA = '25fdebc45eb434b7764f7e8eb976a8d2a6e58043a577d0435a733a302c198c96'
STOP_SHA = 'c9a2dd628f12c4f6fa3e719c68319eb54b310cd8cd461055a2dd60fae4b9f6e3'
NOTICE_SHA = '576012fea2848cdf929abea7f55e62c718b2b30204e156168a1bb1aa719b3d2e'
POLICIES = ['C0','C1','RC1','B152','UB152','U153','R0','RR0','T30','V30','N30','U30','RU30','N15','U15','N60','U60']


def sha(path: Path) -> str:
    """
    機能: 小型文書・源の物理指紋を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def catalog(text: str) -> list[list[str]]:
    """
    機能: 他の設定表を除いて57手法9尺度の本表だけを取り出す。
    引数: text(str)。返り値: list[list[str]]。
    """
    return [line.split('|')[1:-1] for line in text.splitlines()
            if re.match(r'^\|\s+[A-Z]\d{2}\s+\|', line) and len(line.split('|')) == 13]


def main() -> None:
    """
    機能: 最終採用bookの閾値・源を確認し、3MDを束縛して停止票を保存する。
    引数: なし。返り値: None。自然入力本文・売買採否・容量・金融は読まない。
    """
    assert not (HERE / '準備の確認.json').exists()
    paths = [SOURCE / n for n in ('条件.json','準備の確認.json','停止.json')]
    expected = [BOOK_SHA, PREP_SHA, STOP_SHA]
    assert [sha(p) for p in paths] == expected
    book, prep, stop = [json.loads(p.read_bytes()) for p in paths]
    assert prep['成功'] is True and stop['成功'] is True and stop['編集停止'] is True
    assert book['trial'] == 154 and book['primary'] == 'U30' and book['primary_window_minutes'] == 30
    assert book['financial_policies'] == POLICIES and book['feature_rows'] == 35339
    assert book['session_count'] == 73 and book['legacy_count'] == 87
    assert book['no_P65_P60_qualification'] and book['no_model_or_teacher']
    assert book['T']['r_squared_at_least'] == .5 and book['T']['ema8_distance_at_least'] == -1
    assert book['T']['slope_to_side_strict_positive'] and not book['T']['MTF_MA_DI_ADX_AND']
    assert book['V']['r_squared_strict_below'] == .5 and book['V']['band_atr5_ratio'] == .25
    assert book['V']['entry_edge_distance_max_half_width_inclusive'] and not book['V']['old30_or_DI_reversal_required']
    assert book['R']['volume_at_least'] == 1 and book['R']['one_true_other_unknown_choose_true']
    assert book['R']['both_true_wait'] and book['R']['no_true_wait']
    assert book['common']['spread_range'] == '(0,20]' and book['common']['abs_last_close_atr5_max'] == 1
    assert book['common']['final_order_ema8_distance_upper_inclusive'] == 1
    assert book['regression_input']['path'] == 'inputs/00154_先行終値の回帰測定/先行回帰の入力.json.gz'
    assert book['regression_input']['sha256'] == 'f0eef157e0559827e5d7d2f2d614b8ab4d3a98c27b8d463b02c2eec5e9325e98'
    before = {name: sha(ROOT / name) for name in stop['源']}
    assert before == stop['源']
    assert sha(ROOT / 'work/154採用条件のRoot通知.md') == NOTICE_SHA
    assert (FORMAL / '再現資料/採用条件のRoot通知.md').read_bytes() == (ROOT / 'work/154採用条件のRoot通知.md').read_bytes()
    if PERMANENT.exists():
        assert PERMANENT.read_bytes() == paths[0].read_bytes()
    else:
        PERMANENT.write_bytes(paths[0].read_bytes())
    # ----------------------------------------
    # 本文の売買数値を変えず、作成者のRMSE単位誤記を訂正し最終源を追補する。
    condition = FORMAL / '条件.md'
    text = condition.read_text(encoding='utf-8')
    assert '## F0前の最終停止版' not in text
    text = text.replace('Source/bookは準備中、最終停止版のSHAはF0前末尾へ束縛する。',
                        'Source/bookの最終停止版は末尾へ束縛済み。')
    text = text.replace('RMSEはsqrt(SSE/W)であり標準誤差の自由度補正とは別。',
                        '窓内1分点数w=W/60としてRMSEはsqrt(SSE/w)であり、秒数Wや標準誤差の自由度補正で割らない。')
    text += f'''\n\n## F0前の最終停止版\n\n[154恒久book](../../inputs/00154_先行終値の回帰測定/条件.json) SHA256 `{BOOK_SHA}`。作成元[Source準備票](../../work/154回帰環境の入口/準備の確認.json) SHA256 `{PREP_SHA}`、[停止票](../../work/154回帰環境の入口/停止.json) SHA256 `{STOP_SHA}`へ束縛した。Root採用源 `{NOTICE_SHA}`、主U30/窓30と全閾値は不変。新売買採否・容量・金融は引き続き未実行。\n\nこの追補はSource独立レビューではなく文書作者の自己確認。RMSEの割り数を1分点数wと明確化したが、RMSEは採否に使わず入力/売買数値を変更していない。\n'''
    condition.write_bytes(text.encode('utf-8'))
    readme = FORMAL / 'README.md'
    text = readme.read_text(encoding='utf-8').replace('最終Source/book SHAはF0前に追補する。', '最終Source/book SHAは[条件末尾](条件.md)へ束縛済み。')
    readme.write_bytes(text.encode('utf-8'))
    v7 = ROOT / 'docs/議論/手法と時間スケールの汎用表_版7.md'
    original = catalog(v7.read_text(encoding='utf-8'))
    configured = catalog((FORMAL / '設定と結果.md').read_text(encoding='utf-8'))
    assert len(original) == len(configured) == 57 and all(len(row[2:]) == 9 for row in configured)
    assert [row[0] for row in original] == [row[0] for row in configured]
    heading = '| ID | 手法 | 原板・逐次 | 1分 | 3分 | 5分 | 15分 | 30分 | 60分 | セッション足 | 日足 |'
    assert heading in (FORMAL / '設定と結果.md').read_text(encoding='utf-8') and heading in v7.read_text(encoding='utf-8')
    by_id = {row[0].strip(): row[2:] for row in configured}
    assert '154-OLS' in by_id['I14'][1] and 'r除外1分' in by_id['I14'][1]
    assert all('未使用' in by_id['I14'][i] for i in (4,5,6))
    assert '154-V' in by_id['P06'][1] and '154-V' in by_id['P09'][1]
    assert '各t側Hist' in by_id['I03'][3] and '各t側RSI' in by_id['I04'][3]
    docs = [FORMAL / n for n in ('README.md','条件.md','設定と結果.md')]
    count = 0
    for path in docs:
        text = path.read_text(encoding='utf-8')
        assert '全セルは未設定・未検証。' not in text and '未実行' in text
        for target in re.findall(r'\]\(([^)]+)\)', text):
            if '://' in target or target.startswith('#'):
                continue
            local = unquote(target.strip('<>').split('#', 1)[0])
            assert (path.parent / local).exists(), (path.name, target)
            count += 1
    assert {name: sha(ROOT / name) for name in before} == before
    assert [sha(p) for p in paths] == expected
    proof = {'成功': True, '試行': 154, '編集停止': True,
        '自然154売買_容量_金融_新価格入力本文読取': False,
        'Source最終SHA束縛': True, 'book恒久1回保存同体': {'path': PERMANENT.relative_to(ROOT).as_posix(), 'sha256': sha(PERMANENT)},
        'Source準備票': {'path': paths[1].relative_to(ROOT).as_posix(), 'sha256': PREP_SHA},
        'Source停止票': {'path': paths[2].relative_to(ROOT).as_posix(), 'sha256': STOP_SHA},
        '採用Root通知SHA256': NOTICE_SHA, 'Source12源前後同体': before,
        'V7': {'手法':57,'尺度':9,'セル':513,'ID時間列保持':True,'使用セル閾値記入':True,
               'OLS先行域は1分セル_15_30_60分足と別':True},
        '主':'U30','比較':['U15','U60'],'政策':POLICIES,'比較数':1020,
        'RMSE点数wの説明補正_採否非使用':True,'ローカルリンク実在':count,
        '旧153以前と目次編集':False,'Source独立レビューとは別の文書作者自己確認':True,
        '正式3MD':{p.name:sha(p) for p in docs},
        '確認器SHA256':sha(Path(__file__)),'生成器SHA256':sha(HERE / '正式文書を作る.py')}
    out = HERE / '準備の確認.json'
    out.write_bytes((json.dumps(proof, ensure_ascii=False, indent=2)+'\n').encode('utf-8'))
    print(json.dumps({'成功':True,'513':True,'リンク':count,'準備SHA256':sha(out),'正式3MD':proof['正式3MD']},ensure_ascii=False))


if __name__ == '__main__':
    main()
