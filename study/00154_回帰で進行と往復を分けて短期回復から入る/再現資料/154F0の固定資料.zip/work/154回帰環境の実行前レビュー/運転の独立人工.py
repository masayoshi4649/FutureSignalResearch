"""154のmetadata結合と旧対照保持を、私有fixtureと静的運転順で確認する。"""
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import ast
import copy
import hashlib
import importlib.util
import inspect
import json
import sys
import 独立人工 as pure

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent


def load(path: Path, name: str):
    """
    機能: Sourceのmainを起動せずprivate moduleとして読む。
    引数: path(Path)、name(str)。返り値: module。
    """
    spec = importlib.util.spec_from_file_location(name, path); result = importlib.util.module_from_spec(spec)
    sys.modules[name] = result; spec.loader.exec_module(result); return result


# ----------------------------------------
def regression(high: dict) -> dict:
    """
    機能: 私有2q0の既知窓へ有限な人工OLSと実際の両端IDを束縛する。
    引数: high(dict)。返り値: dict。自然OLS値は参照しない。
    """
    scenes = []
    for scene in high['scenes']:
        starts = {bar['start']: bar for bar in scene['bars']}; rows = []
        for row in scene['rows']:
            result = {'event_id': row['event_id'], 'eligible': row['eligible'], 'r_ref': row['r_ref'], 'windows': {}}
            for width in (15, 30, 60):
                w = row['prior_ranges'][str(width)]
                fit = {'points': width, 'slope_pt_per_minute': .1, 'r_squared': .8, 'constant': False,
                    'mean_close': 1000., 'population_std_close': 2., 'residual_rmse': 1., 'fitted_first': 1000.,
                    'fitted_last': 1000. + .1 * (width - 1), 'first_close': 1000., 'last_close': 1001.}
                result['windows'][str(width)] = {'from': w['from'], 'to': w['to'], 'known': True,
                    'unknown_reasons': [], 'fit': fit, 'first_ref': starts[w['from']]['id'], 'last_ref': starts[w['to'] - 60]['id']}
            rows.append(result)
        scenes.append({'session': scene['session'], 'contract': scene['contract'], 'rows': rows})
    return {'success': True, 'schema': 'prior_close_ols_v1', 'strategy_selected': False,
            'financial_labels_used': False, 'sessions': high['sessions'], 'windows_minutes': [15, 30, 60], 'scenes': scenes}


# ----------------------------------------
def main() -> None:
    """
    機能: 実metadata/project/link/bindを人工確認しmainの読取順をASTで確認する。
    引数: なし。返り値: None。自然154/金融/Rawを開かない。
    """
    paths = [ROOT / 'work/154回帰環境の入口/logic154.py', ROOT / 'work/154回帰環境の入口/選択する.py',
             ROOT / 'work/154回帰環境の入口/条件.json', ROOT / 'work/153独立出生の入口/選択する.py',
             ROOT / 'scripts/入口研究/固定特徴から可読条件を選択する.py']
    before = {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    core = load(paths[0], '対象154core'); driver = load(paths[1], '対象154runner'); helper = load(paths[4], '凍結link154')
    book = json.loads(paths[2].read_bytes()); driver.validate_book(book)
    # ----------------------------------------
    # 既存の独立人工fixtureだけを再用する。作者fixture/mainを期待値に使わない。
    old_pure = load(ROOT / 'work/153独立出生の実行前レビュー/独立人工.py', '既存153独立pure')
    with patch.dict(sys.modules, {'独立人工': old_pure}):
        old_fixture = load(ROOT / 'work/153独立出生の実行前レビュー/運転の独立人工.py', '既存153独立fixture')
    features, raw, high, captures, metadata, old152 = old_fixture.fixtures(); reg = regression(high)
    witness = driver.shared.witnesses(raw); original = copy.deepcopy((raw, high, reg, captures, metadata, old152))
    joined, regrows = driver.measurements(features, witness, high, reg, core, expected_rows=2)
    decisions = driver.project(features, joined, regrows, core)
    assert len(decisions) == 2 and all(row['decision']['directions']['N30'] == 1 for row in decisions)
    assert (raw, high, reg, captures, metadata, old152) == original
    rejected = []
    for kind in ('last_event', 'last_r', 'last_first_ref', 'last_last_ref', 'window_scope'):
        bad = copy.deepcopy(reg); row = bad['scenes'][0]['rows'][-1]
        if kind == 'last_event': row['event_id'] = '別q0'
        elif kind == 'last_r': row['r_ref'] = '別r'
        elif kind == 'last_first_ref': row['windows']['30']['first_ref'] = '別足'
        elif kind == 'last_last_ref': row['windows']['30']['last_ref'] = '別足'
        else: row['windows']['30']['to'] += 60
        try: driver.measurements(features, witness, high, bad, core, expected_rows=2)
        except (AssertionError, ValueError): rejected.append(kind)
        else: raise AssertionError(kind)
    # ----------------------------------------
    # 不適格台帳は残し、featuresから外してchooseへ渡さない。
    h, r = copy.deepcopy(high), copy.deepcopy(reg)
    h['scenes'][0]['rows'][0]['eligible'] = False; r['scenes'][0]['rows'][0]['eligible'] = False
    only = SimpleNamespace(columns=features.columns, buy_X=features.buy_X[1:], sell_X=features.sell_X[1:],
                           q0_meta=features.q0_meta[1:], scenes=features.scenes)
    one_witness = {key: value for key, value in witness.items() if key == features.q0_meta[1]['event_id']}
    one_joined, one_reg = driver.measurements(only, one_witness, h, r, core, expected_rows=2)
    one_choice = driver.project(only, one_joined, one_reg, core)
    assert len(one_choice) == 1 and one_choice[0]['event_id'] == features.q0_meta[1]['event_id']
    bad_dto = copy.deepcopy(joined[0]); bad_reg = copy.deepcopy(regrows[0]); bad_dto['eligible'] = bad_reg['eligible'] = False
    try: core.choose(features.buy_X[0].tolist(), features.sell_X[0].tolist(), list(features.columns), bad_dto, bad_reg)
    except AssertionError: rejected.append('不適格pure_choose拒否')
    else: raise AssertionError('不適格を出生')
    # ----------------------------------------
    # 同q1/C1優先と旧対照全値copyは実connect/bindの小人工で確認する。
    result = driver.connect(decisions, captures, metadata, high['sessions'], helper)
    for policy in ('U30', 'U15', 'U60'):
        assert len(result['政策'][policy]) == 88
        assert next(row for row in result['政策'][policy] if row['case_id'] == '旧0')['side'] == -1
        assert result['旧C1重複'][policy][0]['opposite'] is True
    old153 = {'成功': True, '試行': 153, '選択時の金融ラベル利用': False,
        '政策': {'C1': copy.deepcopy(result['政策']['C1']), 'R0': copy.deepcopy(result['政策']['R0']),
                 'B152': copy.deepcopy(old152['政策']['B0']), 'UB152': copy.deepcopy(old152['政策']['U1']),
                 'U15': [*copy.deepcopy(result['政策']['C1']), *[{'case_id': f'保護{i}', 'side': 1, '任意由来': ['維持']} for i in range(6)]]}}
    saved = copy.deepcopy(old153)
    driver.bind_controls(result, old153, old152, {'U153': 93, 'R0': 2, 'C1': 87})
    assert result['政策']['U153'] == old153['政策']['U15'] and len(result['政策']['U153']) == 93
    result['政策']['U153'][-1]['任意由来'].append('返却だけ変更'); assert old153 == saved
    # ----------------------------------------
    # 全mainのI/Oは静的に順序確認する。人工mainの大きな再演は追加しない。
    source = inspect.getsource(driver.main); tree = ast.parse(source)
    calls = [node for node in ast.walk(tree) if isinstance(node, ast.Call)]
    saved_q0 = next((node.lineno, node.col_offset) for node in calls if isinstance(node.func, ast.Name) and node.func.id == 'save'
                    and isinstance(node.args[0], ast.BinOp) and isinstance(node.args[0].right, ast.Constant) and node.args[0].right.value == 'q0の判断.json')
    metadata_line = next((node.lineno, node.col_offset) for node in calls if isinstance(node.func, ast.Name) and node.func.id == 'measurements')
    project_line = next((node.lineno, node.col_offset) for node in calls if isinstance(node.func, ast.Name) and node.func.id == 'project')
    reads = {ast.unparse(node.args[0]): (node.lineno, node.col_offset) for node in calls if isinstance(node.func, ast.Attribute)
             and ast.unparse(node.func) == 'data.read_ref'}
    assert metadata_line < project_line < saved_q0 < reads["refs['captures']"] < reads["refs['metadata']"]
    old_loop = next(node for node in ast.walk(tree) if isinstance(node, ast.For) and isinstance(node.target, ast.Tuple)
                    and ast.unparse(node.target) == '(number, key)')
    assert saved_q0[0] < old_loop.lineno
    assert "[(153, 'fixed153_control'), (152, 'fixed152_control')]" == ast.unparse(old_loop.iter)
    assert 'freeze[\'ファイル\'][old_key] == control[\'selection\'][\'decoded_sha256\']' in ast.unparse(old_loop)
    assert tuple(inspect.signature(core.choose).parameters) == ('buy', 'sell', 'columns', 'measurement', 'regression')
    assert before == {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    proof = {'成功': True, '区分': '154運転境界の私有人工と静的順序', '後行metadata不正拒否': rejected,
             '全台帳の不適格をchooseへ渡さず保持': True, 'U30_U15_U60のC1反対優先': True,
             '旧152対照/旧153R0_C1全値一致とU153全93deepcopy': True,
             '全metadata検査→全project→q0排他保存→capture_meta→旧153_152': True,
             '旧F1_選択解凍SHAの静的bind': True, 'Source前後同体': before,
             '確認コードSHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             '自然154採否/容量/金融/Raw/追加2場': False,
             '限界': '私有2q0/1場でmetadata/project/link/bindを実行。oldR0件数は人工2へ明示縮約。mainはAST順序の確認であり全自然I/O再演ではない。gzip/物理SHAは固定共有153境界を再用し、自然実行後に別全件監査で確認する。'}
    with (HERE / '運転の最終確認.json').open('x', encoding='utf-8', newline='\n') as output:
        json.dump(proof, output, ensure_ascii=False, indent=2); output.write('\n')
    print(json.dumps({'成功': True, '後行不正拒否数': len(rejected)}, ensure_ascii=False))


if __name__ == '__main__': main()
