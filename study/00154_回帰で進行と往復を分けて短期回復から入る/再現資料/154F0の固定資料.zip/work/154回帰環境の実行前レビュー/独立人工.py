"""154のT/VをRoot採用式の独立oracleと人工だけで照合する。"""
from pathlib import Path
import copy
import hashlib
import importlib.util
import inspect
import json
import math
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
OLD_PATH = ROOT / 'work/153独立出生の実行前レビュー/独立人工.py'
spec = importlib.util.spec_from_file_location('既存独立R0oracle154', OLD_PATH)
old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
NAMES, INDEX = old.NAMES, old.INDEX
SOURCE = ROOT / 'work/154回帰環境の入口/logic154.py'


def all_known(values: list) -> bool | None:
    """
    機能: すべての必要条件が既知の場合だけ真偽を返す。
    引数: values(list[bool|None])。返り値: bool|None。
    """
    return None if any(value is None for value in values) else all(values)


# ----------------------------------------
def compare(a, op: str, b) -> bool | None:
    """
    機能: 未知を偽へ補完せず条件を独立比較する。
    引数: a/b(float|None)、op(str)。返り値: bool|None。
    """
    if a is None or b is None: return None
    return {'>': a > b, '>=': a >= b, '<': a < b, '<=': a <= b}[op]


# ----------------------------------------
def oracle(buy: list, sell: list, measured: dict, regression: dict) -> dict:
    """
    機能: 153独立R0を基礎にT/Vと窓別ORだけを別実装で求める。
    引数: buy/sell(list)、measured/regression(dict)。返り値: dict。
    """
    base = old.oracle(buy, sell, measured); out = {}
    q, r = measured['q0'], measured['r']['ohlc']
    for side, vector in ((1, buy), (-1, sell)):
        common = base['sides'][str(side)]['flags']['R0']
        atr = old.known(vector[INDEX[old.ATR]]); distance = old.known(vector[INDEX[old.DIST]])
        band = atr / 4 if atr is not None and atr > 0 else None
        price = q['ask' if side == 1 else 'bid'] if q['normal_bbo'] else None
        flags = {'R0': common}
        for width in (15, 30, 60):
            w = measured['prior_ranges'][str(width)]; fit = regression['windows'][str(width)]['fit']
            r2, slope = (fit['r_squared'], fit['slope_pt_per_minute']) if fit is not None else (None, None)
            trend = all_known([common, w['known'], compare(r2, '>=', .5),
                compare(side * slope if slope is not None else None, '>', 0), compare(distance, '>=', -1)])
            edge = w['low' if side == 1 else 'high']; span = w['range_points']
            extreme = side * (r['low' if side == 1 else 'high'] - edge) if edge is not None else None
            close = side * (r['close'] - edge) if edge is not None else None
            last = side * (q['last'] - edge) if q['last'] is not None and edge is not None else None
            entry = side * (price - edge) if price is not None and edge is not None else None
            value = all_known([common, w['known'], compare(r2, '<', .5), compare(span, '>', band * 2 if band is not None else None),
                compare(extreme, '<=', band), compare(close, '>', band), compare(last, '>', band),
                compare(entry, '>', 0), compare(entry, '<=', span / 2 if span is not None else None)])
            flags.update({f'T{width}': trend, f'V{width}': value, f'N{width}': old.tri_or([trend, value])})
        out[str(side)] = flags
    directions, conflicts = {}, {}
    for policy in ('R0', 'T30', 'V30', 'N15', 'N30', 'N60'):
        sides = [side for side in (1, -1) if out[str(side)][policy] is True]
        directions[policy] = sides[0] if len(sides) == 1 else 0; conflicts[policy] = len(sides) > 1
    return {'sides': out, 'directions': directions, 'conflicts': conflicts}


# ----------------------------------------
def fixture(kind: str = 'T', r2: float | None = .5, slope: float = .1) -> tuple:
    """
    機能: 既存独立の物理価格から154専用の回帰測定DTOだけを人工作成する。
    引数: kind(str)、r2(float|None)、slope(float)。返り値: tuple。
    """
    buy, sell, measured = old.fixture('PB' if kind == 'T' else 'RV')
    measured['event_id'] = '独立154q0'
    regression = {'event_id': measured['event_id'], 'r_ref': measured['r']['id'], 'eligible': True, 'windows': {}}
    for width in (15, 30, 60):
        w = measured['prior_ranges'][str(width)]
        fit = {'points': width, 'slope_pt_per_minute': slope, 'r_squared': r2, 'constant': r2 is None,
               'mean_close': 1000., 'population_std_close': 0. if r2 is None else 2., 'residual_rmse': 0. if r2 is None else 1.,
               'fitted_first': 1000., 'fitted_last': 1000. if r2 is None else 1000. + slope * (width - 1),
               'first_close': 1000., 'last_close': 1000. if r2 is None else 1001.}
        if r2 is None: fit['slope_pt_per_minute'] = 0.
        regression['windows'][str(width)] = {'from': w['from'], 'to': w['to'], 'known': True,
            'unknown_reasons': [], 'fit': fit, 'first_ref': f'先行始{width}', 'last_ref': f'先行終{width}'}
    return buy, sell, measured, regression


# ----------------------------------------
def refresh(buy: list, sell: list, measured: dict, ema: float = 1010) -> None:
    """
    機能: 人工価格変更後も買Ask/売Bidと短期実体/gapの関係を保つ。
    引数: buy/sell(list)、measured(dict)、ema(float)。返り値: None。
    """
    q, r = measured['q0'], measured['r']['ohlc']
    for side, vector in ((1, buy), (-1, sell)):
        vector[INDEX[old.DIST]] = side * (q['ask' if side == 1 else 'bid'] - ema) / 20
        vector[INDEX[old.R[0]]] = side * (r['close'] - r['open']) / (r['high'] - r['low'])
        vector[INDEX[old.R[1]]] = side * (r['close'] - 1000) / 20
        vector[INDEX[old.R[2]]] = side * (q['last'] - r['close']) / 20


# ----------------------------------------
def check(module, buy: list, sell: list, measured: dict, regression: dict) -> int:
    """
    機能: 全3窓のT/V/OR・R0・方向・競合と入力非改変を確認する。
    引数: module(対象)、buy/sell(list)、measured/regression(dict)。返り値: intは比較数。
    """
    before = copy.deepcopy((buy, sell, measured, regression, NAMES))
    expected = oracle(buy, sell, measured, regression); actual = module.choose(buy, sell, NAMES, measured, regression)
    comparisons = 0
    for side in (1, -1):
        for key, value in expected['sides'][str(side)].items():
            branch = actual['by_side'][str(side)]
            target = branch['T'][key[1:]] if key.startswith('T') else branch['V'][key[1:]] if key.startswith('V') else branch[key]
            assert target['pass'] is value and target['known'] is (value is not None), (side, key, target, value)
            comparisons += 2
    assert actual['decision']['directions'] == expected['directions'] and actual['decision']['conflicts'] == expected['conflicts']
    assert (buy, sell, measured, regression, NAMES) == before
    actual['by_side']['1']['geometry']['entry_price_q0'] = -999
    assert (buy, sell, measured, regression, NAMES) == before
    return comparisons + 12


# ----------------------------------------
def main() -> None:
    """
    機能: T/V境界・未知・定数・鏡像を自然本文なしで最小人工確認する。
    引数: なし。返り値: None。既存停止folderと作者源を編集しない。
    """
    source_sha = hashlib.sha256(SOURCE.read_bytes()).hexdigest()
    spec = importlib.util.spec_from_file_location('対象154純判定', SOURCE)
    module = importlib.util.module_from_spec(spec); sys.modules['対象154純判定'] = module; spec.loader.exec_module(module)
    assert tuple(inspect.signature(module.choose).parameters) == ('buy', 'sell', 'columns', 'measurement', 'regression')
    cases = comparisons = 0; groups = []
    for r2 in (math.nextafter(.5, -math.inf), .5, math.nextafter(.5, math.inf)):
        for slope in (-.1, 0., .1):
            for distance in (-1.000001, -1., 0., 1., 1.000001):
                b, s, m, reg = fixture('T', r2, slope); b[INDEX[old.DIST]] = distance
                comparisons += check(module, b, s, m, reg); cases += 1
    groups.append('TのR2半分/傾き0/距離[-1,1]の全境界')
    for kind, r2 in (('T', .5), ('V', .49)):
        b, s, m, reg = fixture(kind, r2)
        for key in (*old.TREND, 'm15_adx', 'm15_adx_delta'): b[INDEX[key]] = None; s[INDEX[key]] = None
        first = module.choose(b, s, NAMES, m, reg)
        assert first['by_side']['1']['T' if kind == 'T' else 'V']['30']['pass'] is True
        mirrored = copy.deepcopy(reg)
        for w in mirrored['windows'].values():
            fit = w['fit']; fit['slope_pt_per_minute'] *= -1
            for key in ('mean_close', 'fitted_first', 'fitted_last', 'first_close', 'last_close'): fit[key] = 3000 - fit[key]
        reflected = module.choose(s, b, NAMES, old.reflect(m), mirrored)
        assert all(reflected['decision']['directions'][key] == -side for key, side in first['decision']['directions'].items())
        comparisons += check(module, b, s, m, reg); cases += 1
    groups.append('三軸Trend/ADXを追加せずT/V成立、実物理価格反射と反対実側')
    for extreme in (1005., 1005.000001):
        b, s, m, reg = fixture('V', .49); m['r']['ohlc']['low'] = extreme; refresh(b, s, m)
        assert module.choose(b, s, NAMES, m, reg)['by_side']['1']['V']['30']['checks']['opposite_extreme_touches_band'] is (extreme == 1005.)
        comparisons += check(module, b, s, m, reg); cases += 1
    for entry in (1000., 1020., 1020.000001):
        b, s, m, reg = fixture('V', .49); m['q0'].update(ask=entry, bid=entry - 4); refresh(b, s, m)
        comparisons += check(module, b, s, m, reg); cases += 1
        assert module.choose(b, s, NAMES, m, reg)['by_side']['1']['V']['30']['pass'] is (entry == 1020.)
    for width in (10., 10.000001):
        b, s, m, reg = fixture('V', .49); m['q0'].update(ask=1004, bid=1000); refresh(b, s, m)
        for w in m['prior_ranges'].values():
            w['high'] = 1000 + width; w['range_points'] = w['high'] - w['low']
        comparisons += check(module, b, s, m, reg); cases += 1
        assert module.choose(b, s, NAMES, m, reg)['by_side']['1']['V']['30']['pass'] is (width > 10)
    groups.append('V端帯等号・実P0超/半幅以下・幅2b超、旧153RVの対向端制約なし')
    for key, value in (('close', 1005.), ('last', 1005.)):
        b, s, m, reg = fixture('V', .49); m['r']['ohlc']['open'] = 1001.
        (m['r']['ohlc'] if key == 'close' else m['q0'])[key] = value
        refresh(b, s, m); comparisons += check(module, b, s, m, reg); cases += 1
        assert module.choose(b, s, NAMES, m, reg)['by_side']['1']['V']['30']['pass'] is False
    groups.append('現在Close/Lastのedge+b厳密超')
    for key in (*old.R, old.ATR, old.DIST):
        b, s, m, reg = fixture(); b[INDEX[key]] = None
        comparisons += check(module, b, s, m, reg); cases += 1
    b, s, m, reg = fixture('T', None, 0.)
    assert module.choose(b, s, NAMES, m, reg)['by_side']['1']['N30']['pass'] is None
    comparisons += check(module, b, s, m, reg); cases += 1
    b, s, m, reg = fixture()
    for width in (15, 30, 60):
        old.unknown_window(m, width)
        value = reg['windows'][str(width)]
        value.update(known=False, unknown_reasons=['price_unknown'], fit=None)
        value.pop('first_ref'); value.pop('last_ref')
    assert module.choose(b, s, NAMES, m, reg)['by_side']['1']['R0']['pass'] is True
    comparisons += check(module, b, s, m, reg); cases += 1
    b, s, m, reg = fixture(); m['q0']['last_known'] = False; m['q0']['last'] = None
    b[INDEX[old.R[2]]] = s[INDEX[old.R[2]]] = None
    assert module.choose(b, s, NAMES, m, reg)['by_side']['1']['N30']['pass'] is None
    comparisons += check(module, b, s, m, reg); cases += 1
    groups.append('R0不変・各required未知・定数R2未定義・未知窓を0へ補完しない')
    rejected = 0
    for key, value in (('points', True), ('constant', 1), ('slope_pt_per_minute', True), ('r_squared', True),
                       ('r_squared', float('nan')), ('residual_rmse', float('inf'))):
        b, s, m, reg = fixture(); reg['windows']['30']['fit'][key] = value
        try: module.choose(b, s, NAMES, m, reg)
        except (AssertionError, ValueError): rejected += 1
        else: raise AssertionError((key, value))
    for change in ('event', 'r_ref', 'window_from', 'future_line'):
        b, s, m, reg = fixture()
        if change == 'event': reg['event_id'] = '別q0'
        elif change == 'r_ref': reg['r_ref'] = '別r'
        elif change == 'window_from': reg['windows']['30']['from'] += 60
        else: m['r']['stamp']['line'] += 1
        try: module.choose(b, s, NAMES, m, reg)
        except (AssertionError, ValueError): rejected += 1
        else: raise AssertionError(change)
    groups.append('bool/NaN/無限/別q0別r/窓差/未来行を拒否')
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == source_sha
    proof = {'成功': True, '範囲': '154純判定だけ。運転は作者停止後に別確認。', '人工ケース': cases,
             '全枝known_pass/方向比較': comparisons, '不正拒否': rejected, '主群': groups,
             '対象SourceSHA256': source_sha, '独立人工SHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             '独立R0依存': {'path': OLD_PATH.relative_to(ROOT).as_posix(), 'SHA256': hashlib.sha256(OLD_PATH.read_bytes()).hexdigest()},
             '自然154採否/容量/金融/Raw/追加2場': False, '既存源又は停止folderの変更': False}
    with (HERE / '純判定の最終確認.json').open('x', encoding='utf-8', newline='\n') as output:
        json.dump(proof, output, ensure_ascii=False, indent=2); output.write('\n')
    print(json.dumps(proof, ensure_ascii=False, indent=2))


if __name__ == '__main__': main()
