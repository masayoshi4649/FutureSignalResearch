"""154の独立再構成と後結合を、自然判断を読む前に小人工で確認する。"""
from pathlib import Path
import copy
import hashlib
import json
import sys
import 当時条件 as c
import 監査する as a

HERE = Path(__file__).resolve().parent


def main() -> None:
    """
    機能: T/V/定数/未知/鏡像と、同q1最早/C1/取消の人工を確認する。
    引数: なし。返り値: None。自然154出力・金融・Rawは開かない。
    """
    count = 0
    for kind, r2 in (('T', .8), ('V', .3)):
        buy, sell, measured, reg = c.old.fixture(kind, r2)
        value = c.reconstruct(buy, sell, c.old.NAMES, measured, reg)
        assert value['decision']['directions']['N30'] == value['decision']['directions']['NN30'] == 1
        count += 1
        mirror = copy.deepcopy(reg)
        for item in mirror['windows'].values():
            fit = item['fit']; fit['slope_pt_per_minute'] *= -1
            for key in ('mean_close', 'fitted_first', 'fitted_last', 'first_close', 'last_close'): fit[key] = 3000 - fit[key]
        inverse = c.reconstruct(sell, buy, c.old.NAMES, c.old.old.reflect(measured), mirror)
        assert all(inverse['decision']['directions'][key] == -side for key, side in value['decision']['directions'].items()); count += 1
    buy, sell, measured, reg = c.old.fixture('T', None, 0.)
    value = c.reconstruct(buy, sell, c.old.NAMES, measured, reg)
    assert value['technical']['1']['N30']['pass'] is None and value['decision']['directions']['N30'] == 0; count += 1
    buy, sell, measured, reg = c.old.fixture()
    for width in (15, 30, 60):
        c.old.old.unknown_window(measured, width)
        item = reg['windows'][str(width)]; item.update(known=False, fit=None, unknown_reasons=['price_unknown'])
        item.pop('first_ref'); item.pop('last_ref')
    value = c.reconstruct(buy, sell, c.old.NAMES, measured, reg)
    assert value['technical']['1']['R0']['pass'] is True and value['decision']['directions']['N30'] == 0; count += 1
    buy, sell, measured, reg = c.old.fixture('T', .8)
    value = c.reconstruct(buy, sell, c.old.NAMES, measured, reg)
    sessions = ['人工場']
    descriptors = [{'case_id': f'旧{i}', 'session': '人工場', 'contract': 'X', 'original_side': -1,
        'buy_stream': 'reverse', 'sell_stream': 'original', 'c1_reused': True} for i in range(87)]
    descriptors.append({'case_id': '新', 'session': '人工場', 'contract': 'X', 'original_side': 1,
        'buy_stream': 'original', 'sell_stream': 'reverse', 'c1_reused': False})
    rows, captures = [], []
    for i, (key, status) in enumerate([('旧0', 'filled'), ('新', 'filled'), ('新', 'filled'), (None, 'expired')]):
        meta = {'event_id': f'E{i}', 'session': '人工場', 'contract': 'X', 'session_index': 0,
                'q0_time': 100 + i, 'q0_index': i, 'q0_line': i + 1}
        rows.append({**meta, 'decision': copy.deepcopy(value['decision'])})
        captures.append({'event_id': meta['event_id'], 'session': '人工場', 'contract': 'X',
            'q0': {'time': 100 + i, 'index': i, 'source_line': i + 1}, 'status': status, 'case_id': key,
            'buy_stream': 'reverse' if key == '旧0' else 'original', 'sell_stream': 'original' if key == '旧0' else 'reverse'})
    result = a.join(rows, {'rows': captures, 'sessions': sessions}, {'population148': {'cases': descriptors}, 'sessions': sessions}, sessions)
    for policy in ('U30', 'U15', 'U60'):
        assert len(result['政策'][policy]) == 88
        assert next(row for row in result['政策'][policy] if row['case_id'] == '旧0')['side'] == -1
    assert next(row for row in result['政策']['N30'] if row['case_id'] == '新')['event_id'] == 'E1'
    assert result['候補と取得']['N30']['duplicate_q1'] == 1 and result['候補と取得']['N30']['expired'] == 1; count += 1
    assert a.stamp({'time': 1, 'index': 0, 'line': 1}) == a.stamp({'time': 1, 'index': 0, 'source_line': 1}); count += 1
    assert not any('/154回帰環境の入口/' in str(getattr(value, '__file__', '')).replace('\\', '/') for value in sys.modules.values())
    proof = {'成功': True, '人工確認': count, '作者logic154/runner_import': False,
             '自然154出力/金融/Raw本文読取': False, '区分': '自然全件監査の準備。F0への固定有無はRoot台帳に従う。',
             '固定源': {name: hashlib.sha256((HERE / name).read_bytes()).hexdigest() for name in ('当時条件.py', '監査する.py', '準備人工.py')},
             '依存独立oracleSHA256': hashlib.sha256(c.ORACLE_PATH.read_bytes()).hexdigest()}
    with (HERE / '準備の確認.json').open('x', encoding='utf-8', newline='\n') as out:
        json.dump(proof, out, ensure_ascii=False, indent=2); out.write('\n')
    print(json.dumps({'成功': True, '人工確認': count, 'SHA256': hashlib.sha256((HERE / '準備の確認.json').read_bytes()).hexdigest()}, ensure_ascii=False))


if __name__ == '__main__': main()
