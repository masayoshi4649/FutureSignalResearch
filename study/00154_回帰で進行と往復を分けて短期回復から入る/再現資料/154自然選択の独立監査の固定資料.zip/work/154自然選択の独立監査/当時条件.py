"""154当時条件の全表を、独立oracleから再構成する。"""
from pathlib import Path
import importlib.util
import math

ROOT = Path(__file__).resolve().parents[2]
ORACLE_PATH = ROOT / 'work/154回帰環境の実行前レビュー/独立人工.py'
spec = importlib.util.spec_from_file_location('停止独立154oracle', ORACLE_PATH)
old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
POLICIES = ('R0', 'T30', 'V30', 'N15', 'N30', 'N60')


def gate(checks: dict, values: dict) -> dict:
    """
    機能: 全required既知・真偽と未知理由を表へまとめる。
    引数: checks/values(dict)。返り値: dict。
    """
    known = all(value is not None for value in checks.values())
    return {'known': known, 'pass': all(checks.values()) if known else None,
        'false': [key for key, value in checks.items() if value is False],
        'unknown': [key for key, value in checks.items() if value is None], 'checks': checks, 'values': values}


# ----------------------------------------
def reconstruct(buy: list, sell: list, columns: list, measured: dict, regression: dict) -> dict:
    """
    機能: 独立oracleと別表現の条件表から全R0/T/V/Nと役割・由来を復元する。
    引数: buy/sell/columns(list)、measured/regression(dict)。返り値: dict。
    """
    index = {name: i for i, name in enumerate(columns)}; arrays = []
    for vector in (buy, sell):
        reordered = [None] * 100
        for key in old.old.REQUIRED: reordered[old.INDEX[key]] = vector[index[key]]
        arrays.append(reordered)
    expected = old.oracle(*arrays, measured, regression); out = {}; q, o = measured['q0'], measured['r']['ohlc']
    R, ATR, DIST = old.old.R, old.old.ATR, old.old.DIST
    for side, vector in ((1, buy), (-1, sell)):
        x = {key: old.old.known(vector[index[key]]) for key in sorted(set((*R, ATR, DIST)))}
        live = None if x[R[1]] is None or x[R[2]] is None else math.fsum((x[R[1]], x[R[2]]))
        ready = all(x[key] is not None for key in R)
        recovery = {'known': ready, 'value': (min(x[R[0]], live, x[R[3]], x[R[4]]) > 0 and x[R[5]] >= 1) if ready else None,
                    'values': {**{key: x[key] for key in R}, 'live_reclaim': live}}
        price = q['ask' if side == 1 else 'bid'] if q['normal_bbo'] else None
        spread = q['ask'] - q['bid'] if q['normal_bbo'] else None
        atr, distance = x[ATR], x[DIST]; band = atr / 4 if atr is not None and atr > 0 else None
        c = old.compare
        r0 = gate({'eligible': True, 'R': recovery['value'], 'normal_bbo': q['normal_bbo'],
            'spread_positive': c(spread, '>', 0), 'spread_max20': c(spread, '<=', 20),
            'gap_abs_max1': c(abs(x[R[2]]) if x[R[2]] is not None else None, '<=', 1),
            'ema8_chase_max1': c(distance, '<=', 1), 'atr5_positive': c(atr, '>', 0)},
            {'atr5': atr, 'entry_price_q0': price, 'ema8_distance_atr5': distance, 'last_close_gap_atr5': x[R[2]], 'spread': spread})
        branch = {'R0': r0, 'R': recovery, 'T': {}, 'V': {}, 'geometry': {'atr5': atr, 'band': band,
                  'entry_price_q0': price, 'ema8_distance_atr5': distance}}
        for width in (15, 30, 60):
            w = measured['prior_ranges'][str(width)]; fit = regression['windows'][str(width)]['fit']
            r2 = fit['r_squared'] if fit is not None else None; slope = fit['slope_pt_per_minute'] if fit is not None else None
            signed_slope = side * slope if slope is not None else None
            trend = gate({'common': r0['pass'], 'window_known': w['known'], 'r2_at_least_half': c(r2, '>=', .5),
                'slope_to_side_positive': c(signed_slope, '>', 0), 'ema8_distance_at_least_minus1': c(distance, '>=', -1)},
                {'window_minutes': width, 'r_squared': r2, 'slope_to_side': signed_slope, 'entry_distance_atr5': distance})
            low, high, span = w['low'], w['high'], w['range_points']; edge = low if side == 1 else high
            extreme = side * (o['low' if side == 1 else 'high'] - edge) if edge is not None else None
            close = side * (o['close'] - edge) if edge is not None else None
            last = side * (q['last'] - edge) if edge is not None and q['last'] is not None else None
            entry = side * (price - edge) if edge is not None and price is not None else None
            value = gate({'common': r0['pass'], 'window_known': w['known'], 'r2_below_half': c(r2, '<', .5),
                'width_more_two_bands': c(span, '>', 2 * band if band is not None else None),
                'opposite_extreme_touches_band': c(extreme, '<=', band), 'close_returns_inside': c(close, '>', band),
                'last_returns_inside': c(last, '>', band), 'entry_inside_positive': c(entry, '>', 0),
                'entry_within_half_range': c(entry, '<=', span / 2 if span is not None else None)},
                {'window_minutes': width, 'lower': low, 'upper': high, 'edge': edge, 'band': band, 'r_squared': r2,
                 'opposite_extreme_distance': extreme, 'close_edge_distance': close, 'last_edge_distance': last,
                 'entry_edge_distance': entry, 'width': span})
            branch['T'][str(width)], branch['V'][str(width)] = trend, value
            flag = old.old.tri_or([trend['pass'], value['pass']])
            branch['N' + str(width)] = {'known': flag is not None, 'pass': flag,
                'origins': [name for name, item in [('T' + str(width), trend), ('V' + str(width), value)] if item['pass'] is True]}
            assert trend['pass'] is expected['sides'][str(side)]['T' + str(width)]
            assert value['pass'] is expected['sides'][str(side)]['V' + str(width)]
        assert r0['pass'] is expected['sides'][str(side)]['R0']; out[str(side)] = branch
    evidence = []
    for policy in POLICIES:
        for side in (1, -1):
            branch = out[str(side)]
            item = branch['T']['30'] if policy == 'T30' else branch['V']['30'] if policy == 'V30' else branch[policy]
            if item['pass'] is True:
                evidence.append({'rule': policy, 'signal_side': side, 'order_side': side,
                    'roles': ['構造', '勢い', '量'] if policy == 'R0' else ['方向', '構造', '勢い', '値幅', '量'],
                    'origins': item.get('origins', [policy])})
    directions, conflicts = dict(expected['directions']), dict(expected['conflicts'])
    directions['NN30'] = directions['N30']; conflicts['NN30'] = conflicts['N30']
    return {'technical': out, 'decision': {'directions': directions, 'conflicts': conflicts, 'evidence': evidence}}
