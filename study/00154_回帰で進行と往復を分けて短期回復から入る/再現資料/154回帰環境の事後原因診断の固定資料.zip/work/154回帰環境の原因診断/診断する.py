"""154の固定gateと保存正逆を二段階で診断し、小正本だけを残す。"""
from pathlib import Path
from collections import Counter
import argparse
import copy
import hashlib
import importlib.util
import json
import os
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
BASE=ROOT/'work/154回帰環境の評価'
SOURCE153=ROOT/'work/153独立出生の原因診断'
FIN153_SHA='ce23e8192a4f9c6245e79fae759fc3224c9e59eac4f3e191f0f85a0e7ac59965'
READER=ROOT/'work/149局面の位置と急変と実反転の診断/診断する.py'
READER_SHA='963044ab01273131755f4f6df963af986e49a44d0100fa6258c4b340f1e9140a'
OBS=ROOT/'work/148全1分母集団の評価/固定取得の正逆観測.json'
OBS_SHA='d1b4cab8a258203f04b5c1d081f57d10ed2a0c58ce4cc160ef571d5fac0ceffc'
NEW=('R0','T30','V30','N15','N30','N60')
FIN=('R0','RR0','T30','V30','N30','U30','U153','UB152','C1')
R0_GROUPS=('進行同側','進行反対','低R²','窓未知','R²未定義','進行傾きゼロ')
CAPTURE=ROOT/'inputs/00148_全1分入口母集団/取得対応.json.gz'
CAPTURE_SHA='7c27420abe6af0867f6cf3d8fd838205da3ed099df8db8e5b5d62892cbadf6bc'
CAPTURE_DECODED='e433b79f87411c34232acac57a8aed191da71bcd1888376b19196099cbf9909a'
DATA=ROOT/'work/151過去場判別/data151.py'
DATA_SHA='3b92ff77a28bf82e6cf8e5dc504cc5586f4101c1e28d0bc12b29bc7cd0efdd8c'


def sha(path: Path) -> str:
    """
    機能: 大入力をbufferで指紋化する。
    引数: path(Path)。返り値: str。
    """
    h=hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda:source.read(1<<20),b''):h.update(block)
    return h.hexdigest()


def module(path: Path,name: str) -> object:
    """
    機能: 固定reader/診断集計をmainなしで私有再用する。
    引数: path(Path)、name(str)。返り値: object。
    """
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m


def truth(value) -> str:
    """
    機能: unknownとfalseを別名へ写す。
    引数: value(bool|None)。返り値: str。
    """
    assert value is None or type(value) is bool
    return 'unknown' if value is None else 'true' if value else 'false'


def new_counter() -> dict:
    """
    機能: q0/側と各環境の小型計数を初期化する。
    引数: なし。返り値: dict。
    """
    return {'q0':0,'側数':0,'R0':Counter(),'出生':{p:Counter() for p in NEW},'窓別R0側':{str(w):{'環境':Counter(),'T':{},'V':{}} for w in (15,30,60)},'同q0_T30_V30':Counter()}


def add_gate(target: dict,gate: dict) -> None:
    """
    機能: R0側のgate否定重複と全必要knownの固定順累積を数える。
    引数: target/gate(dict)。返り値: None。
    """
    target['分母']=target.get('分母',0)+1;target.setdefault('結果',Counter())[truth(gate['pass'])]+=1
    target['unknownかつfalse併存']=target.get('unknownかつfalse併存',0)+int(gate['pass'] is None and bool(gate['false']))
    marginal=target.setdefault('条件別_重複あり',{});cumulative=target.setdefault('累積_コード順',{});prefix=[]
    for name,value in gate['checks'].items():
        marginal.setdefault(name,Counter())[truth(value)]+=1;prefix.append(value)
        flag=None if any(x is None for x in prefix) else all(prefix)
        cumulative.setdefault(name,Counter())[truth(flag)]+=1


def accumulate(target: dict,row: dict) -> None:
    """
    機能: 1q0の両側からR0→回帰環境/位置を異なる分母で数える。
    引数: target/row(dict)。返り値: None。
    """
    target['q0']+=1
    for policy in NEW:
        direction=row['decision']['directions'][policy];target['出生'][policy]['born' if direction else 'wait']+=1
        target['出生'][policy]['conflict']+=int(row['decision']['conflicts'][policy])
    members=[p for p in ('T30','V30') if row['decision']['directions'][p]]
    target['同q0_T30_V30']['|'.join(members) or 'なし']+=1
    for side in row['technical'].values():
        target['側数']+=1;target['R0'][truth(side['R0']['pass'])]+=1
        if side['R0']['pass'] is not True:continue
        for width in (15,30,60):
            w=target['窓別R0側'][str(width)];t=side['T'][str(width)];v=side['V'][str(width)];known=t['checks']['window_known'];r2=t['values']['r_squared']
            category='窓未知' if not known else 'R2未定義' if r2 is None else '進行R2>=.5' if r2>=.5 else '往復R2<.5'
            w['環境'][category]+=1;add_gate(w['T'],t);add_gate(w['V'],v)
            assert not (t['pass'] is True and v['pass'] is True)


def selection_counts(selection: dict) -> dict:
    """
    機能: 出生/取得event/uniqueq1とC1優先を別々に集計する。
    引数: selection(dict)。返り値: dict。
    """
    out={};policies=selection['政策']
    for name in NEW:
        count=selection['候補と取得'][name];out[name]={'出生と取得status':count,'unique取得':len(policies[name])}
        assert len(policies[name])==count.get('filled',0)-count.get('duplicate_q1',0)
    a={r['case_id'] for r in policies['T30']};b={r['case_id'] for r in policies['V30']}
    out['T30_V30取得重複']={'T':len(a),'V':len(b),'重複':len(a&b),'枝union':len(a|b),'N30':len(policies['N30'])}
    n={r['case_id']:r for r in policies['N30']};c={r['case_id']:r for r in policies['C1']};both=set(n)&set(c)
    out['C1優先']={'N30':len(n),'C1':len(c),'重複':len(both),'同方向':sum(n[k]['side']==c[k]['side'] for k in both),
        '反対方向':sum(n[k]['side']!=c[k]['side'] for k in both),'新case':len(set(n)-set(c)),'U30':len(policies['U30'])}
    assert len(policies['U30'])==len(set(n)|set(c))
    return out


def r0_group(row: dict) -> str:
    """
    機能: R0の元q0側と既採用R²=.5/回帰符号だけで群を固定する。
    引数: row(dict)。返り値: str。
    """
    side=row['decision']['directions']['R0'];assert side in (-1,1)
    value=row['technical'][str(side)];assert value['R0']['pass'] is True
    t=value['T']['30'];known=t['checks']['window_known'];r2=t['values']['r_squared'];slope=t['values']['slope_to_side']
    if not known:return '窓未知'
    if r2 is None:return 'R²未定義'
    if r2<.5:return '低R²'
    assert slope is not None
    return '進行同側' if slope>0 else '進行反対' if slope<0 else '進行傾きゼロ'


def group_r0(qrows: object,captures: dict,selection: dict,rows: list,sessions: list,old: object) -> dict:
    """
    機能: R0全出生statusと固定canonical取得の実正逆を元q0群へ結ぶ。
    引数: qrows(object)、captures/selection(dict)、rows/sessions(list)、old(object)。返り値: dict。
    """
    by_event={};references={r['event_id']:r for r in selection['政策']['R0']}
    assert len(references)==len(selection['政策']['R0'])
    for row in qrows:
        side=row['decision']['directions']['R0']
        if not side:continue
        event=row['event_id'];assert event not in by_event;cap=captures[event]
        assert (cap['session'],cap['contract'])==(row['session'],row['contract'])
        assert (cap['q0']['time'],cap['q0']['index'],cap['q0']['source_line'])==(row['q0_time'],row['q0_index'],row['q0_line'])
        group=r0_group(row);by_event[event]={'group':group,'session':row['session'],'status':cap['status']}
        if event in references:
            ref=references[event];assert cap['status']=='filled' and ref['case_id']==cap['case_id'] and ref['side']==side
            assert ref['stream']==cap['buy_stream' if side==1 else 'sell_stream']
    assert len(by_event)==selection['候補と取得']['R0']['born'] and set(references)<=set(by_event)
    assert {r['event_id'] for r in rows}==set(references)
    result={}
    for part,scope in [('all',sessions),('train',sessions[:48]),('validation',sessions[48:])]:
        result[part]={}
        for group in R0_GROUPS:
            born=[v for v in by_event.values() if v['group']==group and v['session'] in scope]
            filled=[r for r in rows if r['session'] in scope and by_event[r['event_id']]['group']==group]
            statuses=dict(Counter(v['status'] for v in born))
            result[part][group]={'出生q0':len(born),'出生場数':len({v['session'] for v in born}),'取得status':statuses,
                'unique取得':len(filled),'取得alias差':statuses.get('filled',0)-len(filled),'同q1実正逆':old.paired(filled)}
        assert sum(g['unique取得'] for g in result[part].values())==len([r for r in rows if r['session'] in scope])
        for direction in ('元方向','実逆'):
            total=old.summarize([r for r in rows if r['session'] in scope],'native' if direction=='元方向' else 'inverse')
            for key in ('件数','F','A','N','C','IFD既知','IFD未知','C5利益','C5損失絶対','C5差引'):
                assert sum(g['同q1実正逆'][direction][key] or 0 for g in result[part].values())==(total[key] or 0)
    return result


def save(path: Path,value: dict,replace: bool=False) -> None:
    """
    機能: 小正本を新規又は非金融→金融段階だけ更新する。
    引数: path(Path)、value(dict)、replace(bool)。返り値: None。
    """
    target=path.with_name(path.name+'.tmp') if replace else path
    with target.open('x',encoding='utf-8') as output:json.dump(value,output,ensure_ascii=False,indent=2,allow_nan=False);output.write('\n')
    if replace:os.replace(target,path)


def verify_f1(path: Path,expected: str) -> tuple:
    """
    機能: Root通知後のF1と選択参照を固定する。
    引数: path(Path)、expected(str)。返り値: tuple[dict,dict]。
    """
    assert sha(path)==expected;freeze=json.loads(path.read_bytes());assert freeze['成功'] and freeze['試行']==154
    refs={}
    for name in ('q0の判断.json','選択対応.json'):
        p=BASE/'入口選択'/name;refs[p]=freeze['ファイル'][p.relative_to(ROOT).as_posix()];assert sha(p)==refs[p]
    refs[path]=expected;return freeze,refs


def nonfinancial(args: object) -> None:
    """
    機能: Root F1後だけ新q0/選択を読み非金融小正本を作る。
    引数: args(object)。返り値: None。金融を開かない。
    """
    f1=BASE/'F1入口選択後.json';_,refs=verify_f1(f1,args.f1_sha256);before={str(p):[p.stat().st_size,p.stat().st_mtime_ns] for p in refs}
    assert sha(READER)==READER_SHA;old=module(READER,'stream154cause');selection=json.loads((BASE/'入口選択/選択対応.json').read_bytes())
    sessions=selection['全73場'];assert len(sessions)==73;counters={p:new_counter() for p in ('all','train','validation')}
    for row in old.array_items(BASE/'入口選択/q0の判断.json','rows'):
        accumulate(counters['all'],row);accumulate(counters['train' if row['session'] in sessions[:48] else 'validation'],row)
    assert counters['all']['q0']==35339 and counters['all']['側数']==70678
    for p in NEW:assert counters['all']['出生'][p]['born']==selection['候補と取得'][p].get('born',0)
    assert all(sha(p)==h for p,h in refs.items()) and before=={str(p):[p.stat().st_size,p.stat().st_mtime_ns] for p in refs}
    save(HERE/'診断.json',{'成功':True,'試行':154,'段階':'非金融のみ','F1_SHA256':args.f1_sha256,'全73場':sessions,
        '新条件採用':False,'全期既使用':True,'非金融':{'全期前後':counters,'取得接続':selection_counts(selection)},
        '非金融入力':{p.relative_to(ROOT).as_posix():h for p,h in refs.items()},'非金融前後SHA_stat同体':True})
    print(json.dumps({'成功':True,'非金融':selection_counts(selection),'出力SHA256':sha(HERE/'診断.json')},ensure_ascii=False))


def financial(args: object) -> None:
    """
    機能: 別Root金融通知後に固定成立集合を同q1実正逆で診断する。
    引数: args(object)。返り値: None。
    """
    target=HERE/'診断.json';previous_sha=sha(target);output=json.loads(target.read_bytes())
    assert output['段階']=='非金融のみ' and output['F1_SHA256']==args.f1_sha256
    _,refs=verify_f1(BASE/'F1入口選択後.json',args.f1_sha256)
    f2=BASE/'F2実金融集計前.json';summary_path=BASE/'金融集計/集計.json'
    assert sha(f2)==args.f2_sha256 and sha(summary_path)==args.summary_sha256 and sha(OBS)==OBS_SHA and sha(READER)==READER_SHA
    assert sha(SOURCE153/'金融を数える.py')==FIN153_SHA
    assert sha(CAPTURE)==CAPTURE_SHA and sha(DATA)==DATA_SHA
    refs.update({f2:args.f2_sha256,summary_path:args.summary_sha256,OBS:OBS_SHA,READER:READER_SHA,SOURCE153/'金融を数える.py':FIN153_SHA,CAPTURE:CAPTURE_SHA,DATA:DATA_SHA})
    before={str(p):[p.stat().st_size,p.stat().st_mtime_ns] for p in refs};freeze=json.loads(f2.read_bytes());assert freeze['F1_SHA256']==args.f1_sha256
    selection=json.loads((BASE/'入口選択/選択対応.json').read_bytes());summary=json.loads(summary_path.read_bytes());sessions=selection['全73場']
    assert summary['F1_SHA256']==args.f1_sha256 and summary['F2_SHA256']==args.f2_sha256
    selection=copy.deepcopy(selection);selection['政策']['RR0']=[{**r,'side':-r['side'],'stream':'reverse' if r['stream']=='original' else 'original'} for r in selection['政策']['R0']]
    old=module(READER,'fixed149one154cause');base=module(SOURCE153/'金融を数える.py','fixed153causestats154');base.POLICIES=FIN
    needed={r['case_id'] for p in FIN for r in selection['政策'][p]};cases={};scene_count=0
    for scene in old.array_items(OBS,'scenes'):
        assert scene['success'] and scene['session']==sessions[scene_count];scene_count+=1
        for case in scene['cases']:
            if case['id'] not in needed:continue
            assert case['id'] not in cases and case['original']['entry']==case['reverse']['entry']
            cases[case['id']]={'session':scene['session'],'q1':case['original']['entry'],'sides':{s:case[s]['birth']['side'] for s in ('original','reverse')},
                'original':old.one(case['original']),'reverse':old.one(case['reverse'])}
    assert scene_count==73 and set(cases)==needed;rows=base.policy_rows(selection,cases);parts={};checked=0
    fresh={r['case_id']:r for r in rows['N30']};legacy={r['case_id']:r for r in rows['C1']};shared=set(fresh)&set(legacy)
    for part,scope in [('all',sessions),('train',sessions[:48]),('validation',sessions[48:])]:
        parts[part]={}
        for policy in FIN:
            current=[r for r in rows[policy] if r['session'] in scope];paired=old.paired(current);expected=summary['集計'][part][policy]['BBO']['3600']['125']
            for key,field in base.STAT_KEYS.items():assert paired['元方向'][key]==expected[field],(part,policy,key);checked+=1
            parts[part][policy]={'同q1実正逆':paired,'参加と名目H60依存':base.overlap(current,scope)}
        keys=[k for k in shared if fresh[k]['session'] in scope]
        parts[part]['C1優先部分']={'重複':len(keys),'N30成立側':old.paired([fresh[k] for k in keys]),'C1保護側':old.paired([legacy[k] for k in keys]),
            '新N30差分':old.paired([r for r in rows['N30'] if r['session'] in scope and r['case_id'] not in legacy])}
    data=module(DATA,'capture_reader154cause');capture,_=data.read_ref(data.FileRef(CAPTURE,CAPTURE_SHA,CAPTURE_DECODED))
    capture_by_event={r['event_id']:r for r in capture['rows']};assert len(capture_by_event)==len(capture['rows'])==35339 and capture['sessions']==sessions
    groups=group_r0(old.array_items(BASE/'入口選択/q0の判断.json','rows'),capture_by_event,selection,rows['R0'],sessions,old)
    assert all(sha(p)==h for p,h in refs.items()) and before=={str(p):[p.stat().st_size,p.stat().st_mtime_ns] for p in refs}
    output.update(段階='非金融と保存実正逆の診断完了',金融={'全期前後':parts,'Root正本一致セル':checked,'R0既境界群':groups},金融前の診断SHA256=previous_sha,
        F2_SHA256=args.f2_sha256,金融入力={p.relative_to(ROOT).as_posix():h for p,h in refs.items()},金融前後SHA_stat同体=True)
    save(target,output,True);print(json.dumps({'成功':True,'一致セル':checked,'出力SHA256':sha(target)},ensure_ascii=False))


def main() -> None:
    """
    機能: Root通知に対応する二つの明示modeだけを運転する。
    引数: CLI mode/f1-sha256/f2-sha256/summary-sha256/execute-after-notification。
    返り値: None。Source変更/閾値探索/Raw読取を呼ばない。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--mode',choices=('nonfinancial','financial'),required=True)
    parser.add_argument('--f1-sha256',required=True);parser.add_argument('--f2-sha256');parser.add_argument('--summary-sha256')
    parser.add_argument('--execute-after-notification',action='store_true');args=parser.parse_args();assert args.execute_after_notification
    if args.mode=='nonfinancial':nonfinancial(args)
    else:
        assert args.f2_sha256 and args.summary_sha256;financial(args)


if __name__=='__main__':
    main()
