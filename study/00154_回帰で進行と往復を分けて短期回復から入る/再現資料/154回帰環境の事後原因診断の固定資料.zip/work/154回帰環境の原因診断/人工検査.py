"""154診断の分母・定数未知・C1優先と実行境界だけを人工で検査する。"""
from pathlib import Path
from unittest.mock import patch
import copy
import importlib.util
import sys
import unittest

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'work/154回帰環境の入口'))
spec=importlib.util.spec_from_file_location('fixture154cause',ROOT/'work/154回帰環境の入口/人工検査.py')
fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
spec=importlib.util.spec_from_file_location('link154cause',ROOT/'work/154回帰環境の入口/人工検査_運転.py')
link=importlib.util.module_from_spec(spec);spec.loader.exec_module(link)
spec=importlib.util.spec_from_file_location('diagnose154',HERE/'診断する.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


def row(kind: str='T',constant: bool=False) -> dict:
    """
    機能: 固定純部品から金融なしの1q0保存票を作る。
    引数: kind(str)、constant(bool)。返り値: dict。
    """
    b,s,d,r=fixture.case(kind)
    if constant:r['windows']['30']['fit'].update(constant=True,r_squared=None,slope_pt_per_minute=0)
    chosen=fixture.m.choose(b,s,fixture.NAMES,d,r)
    return {'event_id':'人工','session':'人工','technical':chosen['by_side'],'decision':chosen['decision']}


class Tests(unittest.TestCase):
    def test_q0と側と回帰環境(self):
        """
        機能: 買売2側をq0出生2件と誤計数しない。
        引数: self(Tests)。返り値: None。
        """
        value=row();before=copy.deepcopy(value);out=m.new_counter();m.accumulate(out,value)
        self.assertEqual((out['q0'],out['側数']),(1,2));self.assertEqual(out['R0']['true'],1)
        self.assertEqual(out['窓別R0側']['30']['環境'],{'進行R2>=.5':1})
        self.assertEqual(out['出生']['T30']['born'],1);self.assertEqual(value,before)

    def test_定数未知とfalse併存(self):
        """
        機能: 定数R²nullを低R²へ入れず、slope偽との併存を保存する。
        引数: self(Tests)。返り値: None。
        """
        out=m.new_counter();m.accumulate(out,row(constant=True));window=out['窓別R0側']['30']
        self.assertEqual(window['環境'],{'R2未定義':1});self.assertEqual(window['T']['結果'],{'unknown':1})
        self.assertEqual(window['T']['unknownかつfalse併存'],1)
        self.assertEqual(window['T']['条件別_重複あり']['slope_to_side_positive'],{'false':1})
        self.assertEqual(window['T']['累積_コード順']['ema8_distance_at_least_minus1'],{'unknown':1})

    def test_取得aliasとC1優先の分母(self):
        """
        機能: filled event/unique q1/C1保護の相違を保持する。
        引数: self(Tests)。返り値: None。
        """
        d,c,meta,s=link.make_links();selection=link.m.connect(d,c,meta,s,link.fixture.helper)
        result=m.selection_counts(selection)
        self.assertEqual(result['N30']['出生と取得status']['filled'],3);self.assertEqual(result['N30']['unique取得'],2)
        self.assertEqual(result['C1優先'],{'N30':2,'C1':87,'重複':1,'同方向':0,'反対方向':1,'新case':1,'U30':88})

    def test_未通知は本文IOなし(self):
        """
        機能: Root通知旗なしではF1も読まない。
        引数: self(Tests)。返り値: None。
        """
        with patch.object(sys,'argv',['診断する.py','--mode','nonfinancial','--f1-sha256','0'*64]),patch.object(m,'sha',side_effect=RuntimeError('本文IO禁止')) as io:
            with self.assertRaises(AssertionError):m.main()
            self.assertEqual(io.call_count,0)

    def test_R0既境界群と未取得status(self):
        """
        機能: 群を元q0側に固定し未取得/品質喪失を金融分母と混ぜない。
        引数: self(Tests)。返り値: None。
        """
        old=m.module(m.READER,'old149r0groupfixture');qrows=[];caps={};refs=[];filled=[]
        specs=[('同','filled','進行同側'),('反','filled','進行反対'),('低','expired','低R²'),('不明','quality_lost','窓未知')]
        for i,(name,status,expected) in enumerate(specs):
            value=row();value.update(event_id=name,contract='X',q0_time=100+i,q0_index=i,q0_line=i+1)
            t=value['technical']['1']['T']['30']
            if name=='反':t['values']['slope_to_side']=-1
            elif name=='低':t['values']['r_squared']=.49
            elif name=='不明':t['checks']['window_known']=False;t['values']['r_squared']=None
            self.assertEqual(m.r0_group(value),expected);qrows.append(value)
            caps[name]={'session':'人工','contract':'X','q0':{'time':100+i,'index':i,'source_line':i+1},'status':status,
                        'case_id':name if status=='filled' else None,'buy_stream':'original','sell_stream':'reverse'}
            if status=='filled':
                refs.append({'event_id':name,'case_id':name,'side':1,'stream':'original'})
                filled.append({'event_id':name,'case_id':name,'session':'人工','native':{'state':'F' if i==0 else 'A','ifd_known':True,'net5':100 if i==0 else -200},
                    'inverse':{'state':'A' if i==0 else 'F','ifd_known':True,'net5':-300 if i==0 else 50}})
        result=m.group_r0(qrows,caps,{'政策':{'R0':refs},'候補と取得':{'R0':{'born':4}}},filled,['人工'],old)['all']
        self.assertEqual(result['低R²']['取得status'],{'expired':1});self.assertEqual(result['低R²']['unique取得'],0)
        self.assertEqual(result['窓未知']['取得status'],{'quality_lost':1})
        self.assertEqual(result['進行反対']['同q1実正逆']['元方向']['A'],1)
        self.assertEqual(result['進行反対']['同q1実正逆']['実逆']['F'],1)


if __name__=='__main__':
    unittest.main(verbosity=2)
