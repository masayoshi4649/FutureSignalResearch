"""停止154原因を後発資料として保存し、条件へ採用せず結果の原因節へつなぐ。"""
from pathlib import Path
import importlib.util
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
FORMAL=ROOT/'study/00154_回帰で進行と往復を分けて短期回復から入る'


def main() -> None:
    """
    機能: 作者停止8小点を保存し、原因の事実と仮説を短く追記する。
    引数: なし。返り値: None。Source・採否・閾値・F0本文を変更しない。
    """
    spec=importlib.util.spec_from_file_location('archive154_cause',HERE/'保存する.py')
    base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base);lib=base.library()
    folder=ROOT/'work/154回帰環境の原因診断';stop_path=folder/'停止.json'
    stop_sha='d58c6f1b1f0d51cbcee43002b2a3edf19011db9a6afe005360cbb3e2d3240357'
    assert lib.sha(stop_path)==stop_sha;stop=json.loads(stop_path.read_bytes())
    assert stop['成功'] and stop['診断編集停止'] and not stop['新条件又は主又はSource変更']
    files={folder/name:h for name,h in stop['ファイル'].items()};files[stop_path]=stop_sha
    assert all(lib.sha(p)==h for p,h in files.items())
    index_path=FORMAL/'保管索引.json';index=json.loads(index_path.read_bytes());key='回帰環境の事後原因診断'
    assert key not in index
    saved=[]
    for source,dest,compressed in [(folder/'短報.md','根拠/回帰環境の分類で残った制限.md',False),
        (folder/'診断.json','根拠/回帰環境の診断.json.gz',True),
        (stop_path,'検査/回帰環境の原因診断の停止.json',False)]:
        record=lib.save_file(source,FORMAL/dest,files[source],compressed)
        lib.check_reference(record,files[source]);saved.append(record)
    existing=base.references(index)
    for record in saved:existing[record['復元先']]=record
    index[key]={'停止SHA256':stop_sha,'正本':saved,'全源復元参照':lib.resolve(
        {p.relative_to(ROOT).as_posix():h for p,h in files.items()},key,existing),
        'F0_F1事前固定へ遡及':False,'Source_閾値_主の変更':False}
    index_path.write_bytes(lib.json_bytes(index))
    text='''## どの条件で残り、実逆ではどうだったか

R0出生1,494側のうち30分窓known1,163、進行R²≥.5は355。同側傾きで124へ減り、EMA8下限による追加減少はなかった。往復R²<.5は808側だが端接触16、実P内半分で8。T124出生→118取得、V8→8だった。未知331側を低R²へ補わず、低R²だけをレンジの確証としない。

同q1実逆ではT30は55順49逆7未7不足・52.88%/C5−56,086円、N30も52.68%/−64,702円で、方向を反転しても目標へ届かなかった。進行がR0と反対だった別事後群は231出生→226取得、元99順100逆11未16不足/−216,171円、実逆80順115逆15未16不足/−740,094円。原/逆のどちらも新規則の採用根拠にしない。

[停止原因短報](根拠/回帰環境の分類で残った制限.md)は全/前48/後25・出生/取得・原/実逆を分け、主要270正本値へ一致した。過去30分の直線性と短期回復が同じ向きでも、現在からの125pt先着を支えるとは確認できなかった、という固定群の関連であり、OLS単独の因果効果や最終的な敗因を断定しない。153の新6取得から126へ増えたことも、70%/1hの共同達成ではない。

'''
    path=FORMAL/'README.md';body=path.read_text(encoding='utf-8');heading='## 閲覧・検査・再現と限界'
    assert heading in body and '## どの条件で残り' not in body
    path.write_bytes(body.replace(heading,text+heading).encode('utf-8'))
    for name in ('閲覧資料.md','再現手順.md'):
        path=FORMAL/name;body=path.read_bytes()
        path.write_bytes(body+('\n\n## 事後原因の保存\n\n[回帰環境の分類で残った制限](根拠/回帰環境の分類で残った制限.md)、'
            '[全診断](根拠/回帰環境の診断.json.gz)、[停止票](検査/回帰環境の原因診断の停止.json)。'
            '採否条件へ後付けせず、元q0側の群を固定して同q1実BBO逆と前後を比較した。\n').encode('utf-8'))
    print(json.dumps({'成功':True,'原因小点':len(files),'README_SHA256':lib.sha(FORMAL/'README.md'),'索引SHA256':lib.sha(index_path)},ensure_ascii=False))


if __name__=='__main__':
    main()
