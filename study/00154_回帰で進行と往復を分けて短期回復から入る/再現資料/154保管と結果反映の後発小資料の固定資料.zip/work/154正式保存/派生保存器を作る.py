"""153の停止保存器を別pathへ適合し、154だけの保存源を作る。"""
from pathlib import Path
import hashlib

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent


def main() -> None:
    """
    機能: 保存/人工の153由来を保ち154のpath/主U30へ限定変更する。
    引数: なし。返り値: None。原153や共有入力は編集しない。
    """
    for name in ('保存する.py','人工検査.py'):
        original=ROOT/'work/153正式保存'/name
        text=original.read_text(encoding='utf-8').replace('153','154').replace('U15','U30')
        text=text.replace('00154_長い先行域から順行と反転を独立出生する','00154_回帰で進行と往復を分けて短期回復から入る')
        text=text.replace('00154_先行高安の独立出生','00154_先行終値の回帰測定')
        if name=='保存する.py':
            old="""        previous = ROOT / 'study/00152_強い反対背景を複合回復で切り替える/保管索引.json'
        if previous.exists():
            for rel, record in references(json.loads(previous.read_bytes())).items():
                digest = record.get('解凍SHA256', record.get('sha256'))
                if digest is not None:
                    by_path.setdefault(rel, record)
                    by_sha.setdefault(digest, record)
"""
            new="""        for number in (153,152):
            previous = next((ROOT/'study').glob(f'{number:05d}_*/保管索引.json'),None)
            if previous is not None:
                for rel, record in references(json.loads(previous.read_bytes())).items():
                    digest = record.get('解凍SHA256', record.get('sha256'))
                    if digest is not None:
                        by_path.setdefault(rel, record)
                        by_sha.setdefault(digest, record)
"""
            assert old in text;text=text.replace(old,new)
        out=HERE/name
        assert not out.exists();out.write_bytes(text.encode('utf-8'))
        print(name,hashlib.sha256(out.read_bytes()).hexdigest())


if __name__=='__main__':
    main()
