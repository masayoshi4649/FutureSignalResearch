"""後発の現在価格診断5小点を恒久化し、154採用条件と分けて案内する。"""
from pathlib import Path
import importlib.util
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
FORMAL=ROOT/'study/00154_回帰で進行と往復を分けて短期回復から入る'


def main() -> None:
    """
    機能: 停止票の全5点を保存し、リンク起点だけ補正した短報へ接続する。
    引数: なし。返り値: None。Source/選択/主/閾値を変更しない。
    """
    spec=importlib.util.spec_from_file_location('archive154_current',HERE/'保存する.py')
    base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base);lib=base.library()
    folder=ROOT/'work/154現在価格と回復足の独立診断';stop_path=folder/'停止の確認.json'
    expected='2561b887354ebaee22d1ad114b5af3ab5b0d41b965b4f96809157bd510ed7d66'
    assert lib.sha(stop_path)==expected;stop=json.loads(stop_path.read_bytes())
    assert stop['成功'] and stop['編集停止'] and stop['群合計検査']==180
    files={folder/name:info['SHA256'] for name,info in stop['保存対象'].items()};files[stop_path]=expected
    assert len(files)==5 and all(lib.sha(p)==h for p,h in files.items())
    index_path=FORMAL/'保管索引.json';index=json.loads(index_path.read_bytes());key='現在価格と回復足の後発独立診断'
    assert key not in index
    saved=[]
    for source,destination in [(folder/'診断.json','根拠/現在価格の診断.json'),
        (folder/'区分の事前固定.md','根拠/現在価格_区分の事前固定.md'),
        (stop_path,'検査/現在価格診断の停止.json')]:
        record=lib.save_file(source,FORMAL/destination,files[source]);lib.check_reference(record,files[source]);saved.append(record)
    body=(folder/'短報.md').read_text(encoding='utf-8').replace('](区分の事前固定.md)','](現在価格_区分の事前固定.md)').replace('](診断.json)','](現在価格の診断.json)')
    target=FORMAL/'根拠/現在価格と回復足の維持を分ける.md';lib.write_new(target,body.encode('utf-8'))
    existing=base.references(index)
    for record in saved:existing[record['復元先']]=record
    index[key]={'停止SHA256':expected,'正本':saved,
        '恒久短報':{'path':target.relative_to(ROOT).as_posix(),'sha256':lib.sha(target),'原文からの変更':'ローカルリンク起点のみ'},
        '全源復元参照':lib.resolve({p.relative_to(ROOT).as_posix():h for p,h in files.items()},key,existing),
        'F0_F1事前固定へ遡及':False,'Source_閾値_主の変更':False}
    index_path.write_bytes(lib.json_bytes(index))
    text='''さらに[現在価格と回復足の独立診断](根拠/現在価格と回復足の維持を分ける.md)では、元向きにr始値を維持したR0の1,147件も45.97%/C5−2,174,163円だった。始値より逆側の108件を実逆にしても51.09%/−77,239円、逆端を破った79件の実逆も44.78%/−147,006円。始値は負・逆端非破りの29件だけは実逆68%/+69,767円だが、前48は50%赤字・後25は80%黒字という事後小群で未採用。単純な現在足始値の維持/喪失だけでは、固定R0を70%へ改善できる結果ではなかった。原因の証明や新政策の採用とは区別する。\n\n'''
    path=FORMAL/'README.md';body=path.read_text(encoding='utf-8');heading='## 閲覧・検査・再現と限界'
    assert heading in body;path.write_bytes(body.replace(heading,text+heading).encode('utf-8'))
    for name in ('閲覧資料.md','再現手順.md'):
        path=FORMAL/name;body=path.read_bytes()
        path.write_bytes(body+('\n\n[現在価格と回復足の維持の独立診断](根拠/現在価格と回復足の維持を分ける.md)も後発根拠として保存した。'
            '元q0側で区分を固定し、141別算術の全/前後元逆・180加法検査が成功した。事後小群の反転優位を新採用しない。\n').encode('utf-8'))
    print(json.dumps({'成功':True,'現在価格診断小点':len(files),'索引SHA256':lib.sha(index_path),'README_SHA256':lib.sha(FORMAL/'README.md')},ensure_ascii=False))


if __name__=='__main__':
    main()
