"""154の独立完了通知後だけ、F0原文を保って結果と閲覧案内を反映する。"""
from pathlib import Path
import gzip
import hashlib
import importlib.util
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
FORMAL=ROOT/'study/00154_回帰で進行と往復を分けて短期回復から入る'
OUTPUT='../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/154_回帰環境の切替'
POLICIES=['C0','C1','RC1','B152','UB152','U153','R0','RR0','T30','V30','N30','U30','RU30','N15','U15','N60','U60']


def sha(path: Path) -> str:
    """
    機能: 小型結果文書/正本の指紋を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def number(value: int | float | None,decimals: int=0) -> str:
    """
    機能: 未知を0にせず表示数値だけ整える。
    引数: value(int|float|None)、decimals(int)。返り値: str。
    """
    return '未定義' if value is None else f'{value:,.{decimals}f}'


def table(data: dict,part: str,policies: list[str]) -> str:
    """
    機能: H60±125実BBO正本の件数/率/利益損失をMarkdown表にする。
    引数: data(dict)、part(str)、policies(list[str])。返り値: str。
    """
    lines=['| 政策 | 取得 | 順/逆/未/不足 | 到達済率 | C5利益円 | 損失絶対円 | 差引円 | IFD未知 |',
           '| --- | ---: | --- | ---: | ---: | ---: | ---: | ---: |']
    for policy in policies:
        s=data['集計'][part][policy]['BBO']['3600']['125']
        rate='未定義' if s['resolved_rate'] is None else f"{s['resolved_rate']*100:.2f}%"
        counts='/'.join(str(s[k]) for k in ('forward','adverse','neither','censored'))
        lines.append(f"| {policy} | {s['entries']} | {counts} | {rate} | {number(s['ifd_net5_profit'])} | {number(s['ifd_net5_loss'])} | {number(s['ifd_net5_sum'])} | {s['ifd_unknown']} |")
    return '\n'.join(lines)


def main() -> None:
    """
    機能: 自然監査/金融/CSV成功後、3MD末尾と閲覧/再現を正式化する。
    引数: なし。返り値: None。実行前条件prefix/設定513セルと主U30を保持する。
    """
    audit=FORMAL/'検査/自然選択の独立監査.json';summary=FORMAL/'成果物/集計.json'
    assert sha(audit)=='57d87784a3d4224ec3292f90fd5f2844ed9eba72960c06f3d00be01ee130426e'
    assert sha(summary)=='41b160e6918b7bdd58e8fcacf857ca036cb5f93720bde617d0c062169fe0deef'
    data=json.loads(summary.read_bytes());assert data['成功'] and data['試行']==154 and data['主政策']=='U30'
    assert data['主評価']=={'全場最低1':True,'到達済70%':False,'全時間毎時1以上':False,'三目標共同':False}
    snapshot=json.loads(gzip.decompress((FORMAL/'検査/F0実行前文書.json.gz').read_bytes()))
    original={Path(row['path']).name:row['本文'].encode('utf-8') for row in snapshot['文書']}
    assert all((FORMAL/name).read_bytes()==body for name,body in original.items())
    whole=table(data,'all',POLICIES)
    compared=['C1','U153','T30','V30','N30','U30','U15','U60']
    front,back=table(data,'train',compared),table(data,'validation',compared)
    primary=data['集計']['all']['U30']['BBO']['3600']['125'];new=data['集計']['all']['N30']['BBO']['3600']['125']
    assert [primary[k] for k in ('entries','forward','adverse','neither','censored')]==[213,81,89,30,13]
    assert [new[k] for k in ('entries','forward','adverse','neither','censored')]==[126,39,71,9,7]
    readme=f'''# 154 回帰で進行と往復を分けて短期回復から入る

**実行済み・主U30は率と頻度の共同目標未達。** 213取得/全73場、81順89逆30未到達13不足、到達済み47.65%、平均0.2955回/時。C5既知利益1,072,300円/損失1,402,470円/差引−330,170円、未知3。新N30は126取得・35.45%で、旧C1を含めた主より低かった。結果の良い60分窓や旧対照へ主を交換していない。

## 検証した仮説と役割

153と同体の短期回復R0に対し、最新1分rを除く先行終値OLSの直線性と方向で進行/往復を分類した。TはR²≥.5・同向傾き・q0実側EMA8距離[-1,1]ATR。VはR²<.5・先行域端近傍からのClose/現在Last回復と、q0実側が端から内半分という取得位置を組み合わせた。R0の1分形状/現在回復、5分Hist/RSI増分、同足量は別役割で、5/15/30のMA・DI全方向/ADX ANDを追加していない。

窓は**r除外1分足×実時間15/30/60分**で、15/30/60分足ではない。30を主に固定し、15/60は比較。R²は標本内の直線性で将来勝率ではなく、境界.5/.25/[-1,1]/内半分は事前研究仮定だった。旧41の当足包含3分20点/終値突破への追加とは異なる仮説である。

全35,339q0を100特徴・先行域・OLSだけから先に保存し、その後取得対応と旧152/153対照を結合した。q1・教師・予測・旧選択を新資格へ使っていない。心理は「整った進行で同方向回復、往復では端近傍と内側位置」という仮説で、注文圧力や真の支持抵抗を観測したものではない。

[実行前条件](条件.md)と[設定済み513セル](設定と結果.md)はF0全文prefixを保持した。残る未実行表記はF0当時の記録で、現在の状態はこのREADMEと末尾結果で区別する。

## 全体結果・実BBO/H60±125

{whole}

独立1mini=100円/pt、往復77円+C5追加1,000円。金額はIFD既知小計で、未知を0円にしていない。主はIFD210既知/3未知。H完了分母は81/200=40.50%、全取得分母は81/213=38.03%、到達済分母は81/170=47.65%であり、未到達と不足を分ける。

| 目標 | 実測 | 判定 |
| --- | --- | --- |
| 到達済み先着70%以上 | 81/(81+89)=47.6471% | 未達 |
| 全73場min1 | 73/73 | 旧C1を保持して達成 |
| 全時間平均1回/時以上 | 213/720.9167h=0.295457回/時 | 未達 |
| 3条件共同 | 上記を同時判定 | **未達** |

新T30は118取得・36順67逆8未7不足=34.95%、C5−508,086円。V30は8取得・3順4逆1未=42.86%、−32,616円。両枝を合わせたN30は126取得・39順71逆9未7不足=35.45%、利益527,304円/損失1,068,006円/差引−540,702円、IFD全126既知だった。旧C1全87と新126は取得case重複0で、主全213へ加わった。

共通R0の1,375取得は旧153と全参照同体。元45.11%・−2,919,488円、実逆RR0も45.41%・−3,006,642円であり、広い回復を一律反転しても解決しない。旧U153は93取得・71.875%で固定対照として同体だが、頻度不足の過去結果を新154の達成へ置き換えない。

## 前48・後25（全期既使用の参考区分）

### 前48場

{front}

### 後25場

{back}

主の前48は44順46逆24未8不足、48.89%、C5−159,240円/未知2。後25は37順43逆6未5不足、46.25%、−170,930円/未知1。比較U60は全体56.30%・+53,527円でも、後25は44.26%・−172,236円だった。全73場既使用・153後着想で、前後を独立未知期の成績と呼ばない。良い窓/枝/場への主交換や条件の後付けはしていない。

## 閲覧・検査・再現と限界

[全セッションCSV]({OUTPUT}/全セッション.csv)から確認し、[入口別CSV]({OUTPUT}/入口別診断.csv)、[1020比較CSV]({OUTPUT}/正逆比較.csv)で分解する。[閲覧資料](閲覧資料.md)、[金融正本](成果物/集計.json)、[入力案内](../../inputs/00154_先行終値の回帰測定/README.md)、[保管索引](保管索引.json)、[再現手順](再現手順.md)を参照する。xlsxは作っていない。

[自然独立監査](検査/自然選択の独立監査.json)は35,339q0/12,186,941末端・全46固定源、[別金融算術](検査/金融独立検算.json)は1,020比較/24,480キー、[CSV独立再読](検査/CSV独立再読.json)は49,728セル/数値30,876セルを照合した。Rootは3支援画像を視認した。保存選択と共有観測からの再集計でも、[正本とtyped三表の全bytesが一致](検査/保存観測からの再現確認.json)した。検査は優位性の証明とは別である。

新3JSONだけを各1gzip保存し、153先行高安・148特徴/観測・152/153旧対照・既保存OLSは再複写しない。全既使用、近接H60/同場依存、CSV足と知得/実受信時計の違いを残す。入口IFD代用であり、実mini板、可変枚数、口座の重複保有・必須利益追尾は未評価。**154は未達として固定し、原因診断の仮説を154の条件へ採用しない。**
'''
    appendix=f'''\n\n## 2026-11-12 実行結果（F0条件・設定513セルは不変更）

先頭の未実行はF0当時の原文。現在は全件選択/金融/独立監査済み。主U30は213/73場、81順89逆30未13不足・47.6471%、平均0.295457回/時で率・頻度とも未達。主交換・閾値変更なし。

{whole}

主C5既知利益1,072,300円/損失1,402,470円/差引−330,170円、210既知3未知。H完了81/200=40.50%、全取得81/213=38.03%。新N30は126・35.45%/−540,702円、T30は34.95%/V30は42.86%。前48主48.89%/−159,240円/未知2、後25主46.25%/−170,930円/未知1。60分比較を主へ交換しない。

独立mini1枚・往復77円+C5追加1000円の入口IFD代用、全期既使用・前後も未知期でない。未知を0へ補完せず、口座/可変枚数/必須追尾を評価していない。[全体結果](README.md) / [閲覧](閲覧資料.md) / [再現](再現手順.md)。
'''
    (FORMAL/'README.md').write_bytes(readme.encode('utf-8'))
    for name in ('条件.md','設定と結果.md'):(FORMAL/name).write_bytes(original[name]+appendix.encode('utf-8'))
    viewer=f'''# 154のCSVを見る

まず[全セッションCSV]({OUTPUT}/全セッション.csv)。全73場とU30/N30/C1の利益・損失・差引・未知・累計を残した。IFD未知累積後の全件確定差引はnullのままで、既知小計と区別する。

[入口別CSV]({OUTPUT}/入口別診断.csv)は主213取得の同q1元/実逆、[比較CSV]({OUTPUT}/正逆比較.csv)は17政策1020比較。主はall/U30/BBO/H60/±125。比較窓や良い少数群へ交換しない。

主47.65%・平均0.2955回/時で共同未達、全73min1は旧C1を保持した結果。新N30は126取得35.45%であり、旧87と効果を分ける。C5利益1,072,300円/損失1,402,470円/差引−330,170円、IFD未知3。

[README](README.md)、[再現](再現手順.md)、[金融正本](成果物/集計.json)、[独立金融](検査/金融独立検算.json)、[CSV再読](検査/CSV独立再読.json)、[CSV作成票](検査/CSV作成の確認.json)。Rootの全49,728セル/数値30,876セル再読と3画像視認は、算術/Source監査と別の証拠。入口IFDであり口座利益保護ではなく、新xlsxは作らない。
'''
    replay='''# 154の保存資料から再現する

[保管索引](保管索引.json)へ元pathと保存先・物理/解凍SHAを残した。[F0](検査/F0入口選択前.json)42源、[F1](検査/F1入口選択後.json)46源、[F2](検査/F2実金融集計前.json)71源を区別する。実行前3MDは[F0原文](検査/F0実行前文書.json.gz)を使い、現在の結果文書を事前SHAへ当てない。条件/設定F0全prefix・設定57行513セルは保持した。

## 入力とSource

[154恒久入力](../../inputs/00154_先行終値の回帰測定/README.md)へ既保存OLSと最終book、今回の新3JSON各1gzipを一度保存した。153先行域・148の100特徴/取得対応/大観測・旧152/153対照は共有する。新モデル/原板/価格CSVを複写していない。

F0のSource・純/運転人工・独立レビューと、F1全判断/取得結合、F2金融源を保存小ZIP/既存保存へ結ぶ。元の相対構造で不足workだけ復元し、現存不一致を上書きしない。Root記録のWindows絶対pathがあるときは同じ研究ルートを使い、暗黙に書き換えない。F0準備文書にあるwork準備票へのリンクは、この保存復元源へ対応している。

再選択する場合は排他的未作成出力先を使用する。全新q0判断を保存した後だけcaptures/meta/旧対照を読む。新資格へq1/教師/予測を渡さず、同q0両方向は待機・別q0同q1最初canonical・C1優先を維持する。自然独立監査は作者logic/runnerをimportせず[35,339q0/12,186,941末端を確認](検査/自然選択の独立監査.json)した。後発監査をF0事前固定へ遡及して主張しない。

## 保存選択と共有観測から1020比較

```powershell
python -X utf8 'study/00154_回帰で進行と往復を分けて短期回復から入る/再現資料/保存選択から再集計する.py' `
  --output-dir 'work/154再現用の新規出力'
```

保存された選択/F1/F2と小型源だけを復元し、共有148正逆観測と凍結124/149算術で再集計する。再選択・新モデル・Raw走査を行わない。[正本とtyped三表bytes再現](検査/保存観測からの再現確認.json)に成功した。[Root別141算術](検査/金融独立検算.json)の1020比較/24,480キーと[CSV再読](検査/CSV独立再読.json)は別検査である。

旧152B0/U1→B152/UB152は全120条件2880キー、旧153U15/R0→U153/R0も全120条件2880キー同体。RR0の旧照合は既存BBO/H60±125の全/前48/後25・元実逆84統計値だけ。旧に無い全幅/Last/H30の照合済みとはしない。

## 結論の範囲

全73既使用・153後着想、前48/後25は独立未知期でない。標本内R²は未来勝率でなく、主/窓/定数を結果で交換しない。近接H60/同場依存、価格時計と実受信時計、実mini/可変枚数/口座利益保護の未評価を残す。事後診断は次の問いであり、この154条件の更新ではない。
'''
    for name,text in [('閲覧資料.md',viewer),('再現手順.md',replay)]:
        path=FORMAL/name;assert not path.exists();path.write_bytes(text.encode('utf-8'))
    spec=importlib.util.spec_from_file_location('archive154_result',HERE/'保存する.py')
    base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base);lib=base.library()
    proof=HERE/'保存選択の再集計/保存観測からの再現確認.json'
    assert json.loads(proof.read_bytes())['成功']
    lib.save_file(proof,FORMAL/'検査/保存観測からの再現確認.json',sha(proof))
    index_path=FORMAL/'保管索引.json';index=json.loads(index_path.read_bytes())
    output=ROOT/OUTPUT.replace('../../','',1)
    csv=sorted(output.glob('*.csv'));images=sorted((output/'支援画像').glob('*.png'))
    assert len(csv)==len(images)==3
    index['CSV正本']=[{'path':p.relative_to(ROOT).as_posix(),'sha256':sha(p),'bytes':p.stat().st_size} for p in csv]
    index['Root視認の支援画像']=[{'path':p.relative_to(ROOT).as_posix(),'sha256':sha(p)} for p in images]
    index['RootCSV検査通知']={'全セル':49728,'数値セル':30876,'画像':3,'閲覧と算術は別検査':True}
    index['保存選択からの金融三表再現']={'保存元':'検査/保存観測からの再現確認.json','正本と三表bytes同体':True,'新選択_新Raw走査':False}
    index_path.write_bytes(lib.json_bytes(index))
    proof={'成功':True,'試行':154,'主':'U30','共同未達':True,'自然監査SHA256':sha(audit),'金融正本SHA256':sha(summary),
        '条件と設定F0全bytes_prefix保持':True,'設定済み513セル変更':False,'主又は閾値変更':False,
        'Source_book_旧153以前変更':False,'正式3MD':{name:sha(FORMAL/name) for name in original},'更新器SHA256':sha(Path(__file__))}
    (HERE/'結果反映の確認.json').write_bytes((json.dumps(proof,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':
    main()
