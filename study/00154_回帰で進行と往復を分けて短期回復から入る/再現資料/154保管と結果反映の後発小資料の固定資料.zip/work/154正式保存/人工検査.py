"""154自然ファイルを使わず保存段階・原文・一回圧縮・実行guardを検査する。"""
from pathlib import Path
import gzip
import hashlib
import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
spec = importlib.util.spec_from_file_location('archive154_own', HERE / '保存する.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def dump(path: Path, value: dict) -> str:
    """
    機能: 人工JSONだけを新規配置して固定指紋を返す。
    引数: path(Path)、value(dict)。返り値: str。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    body = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    path.write_bytes(body)
    return hashlib.sha256(body).hexdigest()


class Tests(unittest.TestCase):
    """自然読取なしの3主群。"""

    def test_段階原文と新3JSONと共有参照(self) -> None:
        """
        機能: 人工RootでF0/F1/F2と成果物を保存し、元文書・三gzip・非複写を確認する。
        引数: self(Tests)。返り値: None。
        """
        lib = m.library()
        real_root = m.ROOT
        with tempfile.TemporaryDirectory(dir=HERE) as folder:
            temp = Path(folder).resolve()
            m.ROOT = lib.ROOT = temp
            try:
                formal = temp / m.FORMAL_REL
                formal.mkdir(parents=True)
                runtime = temp / 'work/人工生成'
                runtime.mkdir(parents=True)
                files = {}
                for name in ('README.md', '条件.md', '設定と結果.md'):
                    p = formal / name
                    p.write_bytes(('準備時の' + name + '\r\n').encode('utf-8'))
                    files[p.relative_to(temp).as_posix()] = lib.sha(p)
                shared = temp / 'inputs/既存共有/入力.json'
                shared_sha = dump(shared, {'共有': '新たに複写しない'})
                files[shared.relative_to(temp).as_posix()] = shared_sha
                v7 = temp / 'docs/議論/汎用表_版7.md'
                v7.parent.mkdir(parents=True)
                v7.write_bytes('人工のV7'.encode('utf-8'))
                files[v7.relative_to(temp).as_posix()] = lib.sha(v7)
                f0 = runtime / 'F0.json'
                h0 = dump(f0, {'成功': True, '試行': 154, '主政策': 'U30', 'ファイル': files})
                index = m.stage_freeze(lib, 'F0', f0, h0, None)
                snapshot = json.loads(gzip.decompress((formal / '検査/F0実行前文書.json.gz').read_bytes()))
                self.assertEqual(snapshot['文書'][0]['本文'], '準備時のREADME.md\r\n')
                self.assertEqual(len(index['固定段階']['F0']['全源復元参照']['既存恒久正本']), 1)
                # ----------------------------------------
                # 正式が結果化してもF0を現在結果から後造りせず、保存原文を参照する。
                (formal / 'README.md').write_bytes('人工の結果化'.encode('utf-8'))
                for name in m.GENERATED:
                    path = runtime / name
                    path.write_bytes(('人工生成' + name + '\n').encode('utf-8'))
                    files[path.relative_to(temp).as_posix()] = lib.sha(path)
                f1 = runtime / 'F1.json'
                h1 = dump(f1, {'成功': True, '試行': 154, '主政策': 'U30', '前段階SHA256': h0, 'ファイル': files})
                index = m.stage_freeze(lib, 'F1', f1, h1, runtime)
                self.assertEqual(len(index['154新生成3JSONを各1gzip保存']), 3)
                for name in m.GENERATED:
                    self.assertEqual(gzip.decompress((temp / m.INPUT_REL / (name + '.gz')).read_bytes()), (runtime / name).read_bytes())
                with self.assertRaises(AssertionError):
                    m.stage_freeze(lib, 'F1', f1, h1, runtime)
                f2 = runtime / 'F2.json'
                h2 = dump(f2, {'成功': True, '試行': 154, '主政策': 'U30', 'F1_SHA256': h1, 'ファイル': files})
                m.stage_freeze(lib, 'F2', f2, h2, None)
                artifact = runtime / '人工集計.json'
                ha = dump(artifact, {'自然金融': False})
                job = runtime / '保存job.json'
                hj = dump(job, {'試行': 154, 'Root結果通知後': True, '区分': '人工金融証跡',
                    '保存': [{'source': artifact.relative_to(temp).as_posix(), 'sha256': ha,
                               '正式相対path': '成果物/人工集計.json', '形式': '同体'},
                              {'source': shared.relative_to(temp).as_posix(), 'sha256': shared_sha, '形式': '参照'}]})
                index = m.artifacts(lib, job, hj)
                self.assertEqual((formal / '成果物/人工集計.json').read_bytes(), artifact.read_bytes())
                self.assertIn('参照のみ', index['人工金融証跡'][1])
                self.assertEqual(lib.sha(shared), shared_sha)
            finally:
                m.ROOT = real_root

    def test_通知flag無しはI_O前拒否(self) -> None:
        """
        機能: 存在しない自然pathでも通知flag無しならparser段階だけで拒否する。
        引数: self(Tests)。返り値: None。
        """
        process = subprocess.run([sys.executable, '-X', 'utf8', str(HERE / '保存する.py'),
            '--stage', 'F0', '--freeze', '存在しない自然固定票.json', '--sha256', '0' * 64], capture_output=True)
        self.assertEqual(process.returncode, 2)
        self.assertIn('Rootの段階通知後', process.stderr.decode('utf-8'))

    def test_成果物に正式外pathを拒否(self) -> None:
        """
        機能: 人工jobの保存先が正式154外へ逃げる場合は書込み前に拒否する。
        引数: self(Tests)。返り値: None。
        """
        lib = m.library()
        real_root = m.ROOT
        with tempfile.TemporaryDirectory(dir=HERE) as folder:
            temp = Path(folder).resolve()
            m.ROOT = lib.ROOT = temp
            try:
                formal = temp / m.FORMAL_REL
                dump(formal / '保管索引.json', {'試行': 154, '固定段階': {'F2': {}}})
                source = temp / 'work/人工.json'
                expected = dump(source, {'人工': True})
                job = temp / 'work/job.json'
                digest = dump(job, {'試行': 154, 'Root結果通知後': True, '区分': '外部拒否', '保存': [
                    {'source': source.relative_to(temp).as_posix(), 'sha256': expected,
                     '形式': '同体', '正式相対path': '../../旧試行へ出す.json'}]})
                with self.assertRaises(AssertionError):
                    m.artifacts(lib, job, digest)
            finally:
                m.ROOT = real_root


if __name__ == '__main__':
    unittest.main(verbosity=2)
