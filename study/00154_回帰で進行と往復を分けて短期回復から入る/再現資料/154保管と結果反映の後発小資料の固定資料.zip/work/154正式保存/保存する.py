"""Root段階通知後だけ154を保存する。準備時は自然JSONを開かない。"""
from pathlib import Path
import argparse
import gzip
import hashlib
import importlib.util
import json
import uuid
import zipfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
FORMAL_REL = 'study/00154_回帰で進行と往復を分けて短期回復から入る'
INPUT_REL = 'inputs/00154_先行終値の回帰測定'
GENERATED = ('q0の判断.json', '選択対応.json', '選択の確認.json')


def library():
    """
    機能: 旧151の保存関数を読取専用再用し、保存先を154へ分離する。
    引数: なし。返り値: ModuleType。旧ファイルを変更しない。
    """
    path = ROOT / 'work/151正式保存/保存部品.py'
    spec = importlib.util.spec_from_file_location('shared_archiving_for154', path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    result.ROOT, result.FORMAL_REL, result.INPUT_REL = ROOT, FORMAL_REL, INPUT_REL
    old_registry = result.registry

    def registry() -> tuple:
        """
        機能: 既存152の保存索引も共有参照へ加え、小Sourceの重複保存を防ぐ。
        引数: なし。返り値: tuple[dict,dict]。自然金融本文は読まない。
        """
        by_path, by_sha = old_registry()
        for number in (153,152):
            previous = next((ROOT/'study').glob(f'{number:05d}_*/保管索引.json'),None)
            if previous is not None:
                for rel, record in references(json.loads(previous.read_bytes())).items():
                    digest = record.get('解凍SHA256', record.get('sha256'))
                    if digest is not None:
                        by_path.setdefault(rel, record)
                        by_sha.setdefault(digest, record)
        return by_path, by_sha

    def pack(entries: dict, target: Path, aliases: dict | None = None) -> dict:
        """
        機能: 新しい小型Source ZIPの名前だけを154へ分離する。
        引数: entries(dict)、target(Path)、aliases(dict|None)。返り値: dict。
        """
        target = result.path_of(target.with_name(target.name.replace('151', '154', 1)))
        assert not target.exists()
        aliases = aliases or {}
        temporary = ROOT / 'work/154正式保存' / (uuid.uuid4().hex + '.zip.part')
        temporary.parent.mkdir(parents=True, exist_ok=True)
        records = []
        with zipfile.ZipFile(temporary, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for rel, expected in sorted(entries.items()):
                source = result.path_of(aliases.get(rel, rel))
                before = source.stat()
                assert result.sha(source) == expected
                digest = hashlib.sha256()
                count = 0
                info = zipfile.ZipInfo(rel, date_time=(2026, 11, 12, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                with source.open('rb') as original, archive.open(info, 'w', force_zip64=True) as output:
                    for block in iter(lambda: original.read(1 << 20), b''):
                        digest.update(block)
                        count += len(block)
                        output.write(block)
                after = source.stat()
                assert digest.hexdigest() == expected
                assert (before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns)
                records.append({'path': rel, 'ZIP内path': rel, 'sha256': expected, 'bytes': count})
        with zipfile.ZipFile(temporary) as archive:
            assert archive.testzip() is None
            for record in records:
                assert hashlib.sha256(archive.read(record['ZIP内path'])).hexdigest() == record['sha256']
        target.parent.mkdir(parents=True, exist_ok=True)
        assert temporary.resolve().is_relative_to(ROOT.resolve()) and target.resolve().is_relative_to(ROOT.resolve())
        temporary.rename(target)
        return {'保存元ZIP': target.relative_to(ROOT).as_posix(), 'ZIP_SHA256': result.sha(target),
                'ZIP_bytes': target.stat().st_size, '格納源': records}

    result.pack_zip = pack
    result.registry = registry
    return result


def references(value: dict) -> dict:
    """
    機能: 一度保存した元pathを再圧縮せず参照できるよう全索引を平坦化する。
    引数: value(dict)。返り値: dict[str,dict]。
    """
    result, pending = {}, [value]
    while pending:
        item = pending.pop()
        if isinstance(item, list):
            pending.extend(item)
        elif isinstance(item, dict):
            if '復元先' in item and ('sha256' in item or '解凍SHA256' in item):
                result[item['復元先']] = item
            if '格納源' in item and '保存元ZIP' in item:
                for row in item['格納源']:
                    result[row['path']] = {'復元先': row['path'], 'sha256': row['sha256'],
                        '保存元ZIP': item['保存元ZIP'], 'ZIP_SHA256': item['ZIP_SHA256'],
                        'ZIP内path': row['ZIP内path'], 'bytes': row['bytes']}
            pending.extend(item.values())
    return result


def snapshot(lib, frozen: dict, freeze_path: Path, expected: str) -> tuple:
    """
    機能: 実行前3MDを指紋一致するRoot退避又は同体現物から一gzipへ保存する。
    引数: lib(ModuleType)、frozen(dict)、freeze_path(Path)、expected(str)。
    返り値: tuple[dict,dict]は保存情報と復元票。結果から事前原文を後造りしない。
    """
    files = lib.normalized_files(frozen['ファイル'])
    rows = []
    for name in ('README.md', '条件.md', '設定と結果.md'):
        rel = FORMAL_REL + '/' + name
        candidates = [freeze_path.parent / 'F0実行前文書' / name, ROOT / rel]
        original = next((p for p in candidates if p.exists() and lib.sha(p) == files[rel]), None)
        assert original is not None, ('同指紋の実行前原文が必要', rel)
        raw = original.read_bytes()
        rows.append({'path': rel, 'sha256': files[rel], 'bytes': len(raw), '本文': raw.decode('utf-8')})
    target = ROOT / FORMAL_REL / '検査/F0実行前文書.json.gz'
    payload = {'試行': 154, '固定SHA256': expected, '文書': rows,
               '実行前Root退避又は同指紋現物': True, '事前固定の後造り': False}
    lib.write_new(target, gzip.compress(lib.json_bytes(payload), mtime=0))
    with gzip.open(target, 'rb') as stream:
        assert json.loads(stream.read()) == payload
    ref = {row['path']: {'復元先': row['path'], 'sha256': row['sha256'],
        '形式': '文書snapshot', '保存元': target.relative_to(ROOT).as_posix(),
        '保存SHA256': lib.sha(target), '抽出キー': row['path'], 'bytes': row['bytes']} for row in rows}
    return {'保存元': target.relative_to(ROOT).as_posix(), '保存SHA256': lib.sha(target)}, ref


def stage_freeze(lib, stage: str, freeze_path: Path, expected: str, generated: Path | None) -> dict:
    """
    機能: 通知済みF0/F1/F2を原文保存し、F1新3JSONだけを各一gzip保存する。
    引数: lib(ModuleType)、stage(str)、freeze_path(Path)、expected(str)、generated(Path|None)。
    返り値: dictは更新済み索引。Source/正式3MD/共有大入力は変更しない。
    """
    freeze_path = freeze_path.resolve()
    assert lib.sha(freeze_path) == expected
    frozen = json.loads(freeze_path.read_bytes())
    assert frozen.get('成功') is True and frozen.get('試行') == 154
    assert frozen.get('主政策', 'U30') == 'U30'
    files = lib.normalized_files(frozen['ファイル'])
    index_path = ROOT / FORMAL_REL / '保管索引.json'
    if stage == 'F0':
        assert not index_path.exists()
        record, existing = snapshot(lib, frozen, freeze_path, expected)
        index = {'試行': 154, '主政策': 'U30', '段階': 'F0保存・自然結果待ち',
                 '実行前文書': record, '実行前文書復元票': list(existing.values()),
                 '固定段階': {}, '共有大入力の新複写': False, '新モデル保存': False}
    else:
        index = json.loads(index_path.read_bytes())
        existing = references(index)
        assert stage not in index['固定段階']
        previous = 'F0' if stage == 'F1' else 'F1'
        assert previous in index['固定段階']
        prior_sha = index['固定段階'][previous]['SHA256']
        if stage == 'F1':
            assert frozen.get('前段階SHA256', frozen.get('F0_SHA256')) == prior_sha
        else:
            assert frozen.get('F1_SHA256', frozen.get('前段階SHA256')) == prior_sha
    if stage == 'F1':
        assert generated is not None and '154新生成3JSONを各1gzip保存' not in index
        saved = []
        for name in GENERATED:
            source = (generated / name).resolve()
            rel = source.relative_to(ROOT).as_posix()
            assert rel in files
            record = lib.save_file(source, ROOT / INPUT_REL / (name + '.gz'), files[rel], True)
            lib.check_reference(record, files[rel])
            existing[rel] = record
            saved.append(record)
        index['154新生成3JSONを各1gzip保存'] = saved
    # ----------------------------------------
    # 固定中の現在Sourceは原文退避3MDだけを例外にし、全指紋を検査する。
    for rel, digest in files.items():
        if rel in existing:
            lib.check_reference(existing[rel], digest)
        else:
            assert lib.sha(ROOT / rel) == digest
    origin = lib.save_file(freeze_path, ROOT / FORMAL_REL / '検査' / freeze_path.name, expected)
    existing[origin['復元先']] = origin
    resolved = lib.resolve(files, stage, existing)
    index['固定段階'][stage] = {'SHA256': expected, '原文': origin,
        '全源数': len(files), '全源復元参照': resolved}
    index['段階'] = stage + '原文/固定源を保存。金融結果又は事後監査は別通知。'
    index_path.write_bytes(lib.json_bytes(index))
    return index


def artifacts(lib, job_path: Path, expected: str) -> dict:
    """
    機能: 金融結果通知後だけ明示jobの金融/CSV票/監査を同体又はgzip保存する。
    引数: lib(ModuleType)、job_path(Path)、expected(str)。返り値: dict。
    """
    assert lib.sha(job_path) == expected
    job = json.loads(job_path.read_bytes())
    assert job['試行'] == 154 and job['Root結果通知後'] is True
    index_path = ROOT / FORMAL_REL / '保管索引.json'
    index = json.loads(index_path.read_bytes())
    assert 'F2' in index['固定段階']
    key = job['区分']
    assert key not in index
    saved = []
    for row in job['保存']:
        source = lib.path_of(row['source'])
        assert lib.sha(source) == row['sha256']
        mode = row['形式']
        assert mode in ('同体', 'gzip', '参照')
        if mode == '参照':
            saved.append({'参照のみ': source.relative_to(ROOT).as_posix(), 'sha256': row['sha256'],
                          '大共有入力の新複写': False})
            continue
        destination = (ROOT / FORMAL_REL / row['正式相対path']).resolve()
        assert destination.is_relative_to(ROOT / FORMAL_REL)
        record = lib.save_file(source, destination, row['sha256'], mode == 'gzip')
        lib.check_reference(record, row['sha256'])
        saved.append(record)
    index[key] = saved
    index_path.write_bytes(lib.json_bytes(index))
    return index


def main() -> None:
    """
    機能: Rootの段階通知と明示SHAがあるときだけ保存関数を呼ぶ。
    引数: CLI stage/sha256/freeze/generated-dir/job/execute-after-root-notice。
    返り値: None。実行flag不在なら自然ファイルのI_O前に拒否する。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', choices=('F0', 'F1', 'F2', '成果物'), required=True)
    parser.add_argument('--sha256', required=True)
    parser.add_argument('--freeze', type=Path)
    parser.add_argument('--generated-dir', type=Path)
    parser.add_argument('--job', type=Path)
    parser.add_argument('--execute-after-root-notice', action='store_true')
    args = parser.parse_args()
    if not args.execute_after_root_notice:
        parser.error('Rootの段階通知後だけ実行する。準備時の自然読取は禁止。')
    if len(args.sha256) != 64 or not set(args.sha256) <= set('0123456789abcdef'):
        parser.error('Root通知の完全SHA256が必要')
    if args.stage != '成果物' and args.freeze is None:
        parser.error('固定票の明示pathが必要')
    if args.stage == 'F1' and args.generated_dir is None:
        parser.error('F1は新3JSONの明示folderが必要')
    if args.stage == '成果物' and args.job is None:
        parser.error('金融結果通知後の明示jobが必要')
    lib = library()
    if args.stage == '成果物':
        result = artifacts(lib, args.job.resolve(), args.sha256)
    else:
        result = stage_freeze(lib, args.stage, args.freeze, args.sha256, args.generated_dir)
    print(json.dumps({'成功': True, '試行': 154, '段階': args.stage,
                      '固定段階': list(result['固定段階'])}, ensure_ascii=False))


if __name__ == '__main__':
    main()
