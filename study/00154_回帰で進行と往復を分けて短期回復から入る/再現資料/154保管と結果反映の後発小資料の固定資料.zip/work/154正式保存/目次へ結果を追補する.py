"""Rootの共通知見を保ち、4目次の153直前へ154結果案内だけを足す。"""
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def main() -> None:
    """
    機能: 全旧bytesを保持して154正式結果/CSV案内を目次へ一度追補する。
    引数: なし。返り値: None。旧試行本文やSourceを変更しない。
    """
    changes=[]
    for name,prefix in [('README.md','study/'),('study/README.md',''),('docs/README.md','../study/'),('docs/議論/README.md','../../study/')]:
        path=ROOT/name;before=path.read_bytes();newline=b'\r\n' if b'\r\n' in before[:300] else b'\n'
        assert b'00154_' not in before
        line=f'[154：回帰で進行と往復を分類]({prefix}00154_回帰で進行と往復を分けて短期回復から入る/README.md)。主U30は213取得/全73場、81順89逆30未13不足・47.65%、平均0.2955回/時で率/頻度とも未達。C5利益1,072,300円/損失1,402,470円/差引−330,170円、未知3。新N30は126取得35.45%、比較60窓へ主交換なし。[CSVと分母]({prefix}00154_回帰で進行と往復を分けて短期回復から入る/閲覧資料.md)。'
        insertion=line.encode('utf-8')+newline+newline;position=before.find(b'[153')
        assert position>=0
        after=before[:position]+insertion+before[position:]
        assert after.replace(insertion,b'',1)==before;path.write_bytes(after)
        changes.append({'path':name,'旧文面全bytes保持':True,'追補のみ':True,'現在SHA256':hashlib.sha256(after).hexdigest()})
    proof={'成功':True,'変更':changes,'旧正式又はSource変更':False,'Rootの共通知見最上段保持':True}
    target=HERE/'目次追補の確認.json';assert not target.exists()
    target.write_bytes((json.dumps(proof,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    print(json.dumps({'成功':True,'4目次追補':True},ensure_ascii=False))


if __name__=='__main__':
    main()
