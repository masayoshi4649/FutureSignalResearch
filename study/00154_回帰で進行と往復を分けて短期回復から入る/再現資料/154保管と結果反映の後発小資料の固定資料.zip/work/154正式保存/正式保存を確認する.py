"""154全源復元・実行前prefix・513設定・全リンクを検査して正式保存を停止する。"""
from pathlib import Path
import gzip
import hashlib
import importlib.util
import json
import re
from urllib.parse import unquote

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
FORMAL=ROOT/'study/00154_回帰で進行と往復を分けて短期回復から入る'


def catalog(text: str) -> list[str]:
    """
    機能: 57行9尺度の設定本表だけを他表から分ける。
    引数: text(str)。返り値: list[str]。
    """
    return [line for line in text.splitlines() if re.match(r'^\|\s+[A-Z]\d{2}\s+\|',line) and len(line.split('|'))==13]


def main() -> None:
    """
    機能: 保存実体の全復元と文書/源の不変を検査し最終票を新規保存する。
    引数: なし。返り値: None。Raw走査/再選択/新金融は実行しない。
    """
    spec=importlib.util.spec_from_file_location('archive154_final',HERE/'保存する.py')
    base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base);lib=base.library()
    index_path=FORMAL/'保管索引.json';index=json.loads(index_path.read_bytes());refs=base.references(index)
    source=HERE/'保存選択から再集計する.py';stored=FORMAL/'再現資料/保存選択から再集計する.py'
    assert source.read_bytes()==stored.read_bytes()
    record={'復元先':source.relative_to(ROOT).as_posix(),'保存元':stored.relative_to(ROOT).as_posix(),
        '形式':'同体','保存SHA256':lib.sha(stored),'解凍SHA256':lib.sha(source),
        '保存bytes':stored.stat().st_size,'解凍bytes':source.stat().st_size}
    index['保存再集計Source']=record;refs[record['復元先']]=record
    extras=list(HERE.glob('*.py'))+[HERE/name for name in ('入力README追記の確認.json','目次追補の確認.json','結果反映の確認.json')]
    files={p.relative_to(ROOT).as_posix():lib.sha(p) for p in extras}
    key='保管と結果反映の後発小資料';assert key not in index
    index[key]=lib.resolve(files,key,refs)
    index['段階']='F0/F1/F2・新3gzip・金融/CSV・独立全件監査・事後原因2本・保存選択再現を恒久保存。主U30率/頻度未達で最終停止。'
    index_path.write_bytes(lib.json_bytes(index))
    # ----------------------------------------
    # 全固定段階は実行前文書snapshotから復元し、現在文書を事前SHAへ使わない。
    original=json.loads(gzip.decompress((FORMAL/'検査/F0実行前文書.json.gz').read_bytes()))
    originals={Path(row['path']).name:row['本文'].encode('utf-8') for row in original['文書']}
    docs=[FORMAL/name for name in ('README.md','条件.md','設定と結果.md')]
    before_docs={p.name:lib.sha(p) for p in docs}
    for name in ('条件.md','設定と結果.md'):
        assert (FORMAL/name).read_bytes().startswith(originals[name])
    rows=catalog(docs[2].read_text(encoding='utf-8'))
    assert rows==catalog(originals['設定と結果.md'].decode('utf-8')) and len(rows)==57
    assert len({line.split('|')[1].strip() for line in rows})==57
    assert all(len(line.split('|')[3:-1])==9 for line in rows)
    assert '全セルは未設定・未検証。' not in docs[2].read_text(encoding='utf-8')
    intro=docs[0].read_text(encoding='utf-8').split('\n\n')[1]
    assert all(term in intro for term in ('実行済み','主U30','共同目標未達','47.65%'))
    summary=FORMAL/'成果物/集計.json'
    assert lib.sha(summary)=='41b160e6918b7bdd58e8fcacf857ca036cb5f93720bde617d0c062169fe0deef'
    data=json.loads(summary.read_bytes())
    assert data['主評価']=={'全場最低1':True,'到達済70%':False,'全時間毎時1以上':False,'三目標共同':False}
    render_spec=importlib.util.spec_from_file_location('result154_table_check',HERE/'結果と閲覧を反映する.py')
    renderer=importlib.util.module_from_spec(render_spec);render_spec.loader.exec_module(renderer)
    body=docs[0].read_text(encoding='utf-8');compared=['C1','U153','T30','V30','N30','U30','U15','U60']
    assert renderer.table(data,'all',renderer.POLICIES) in body
    assert renderer.table(data,'train',compared) in body and renderer.table(data,'validation',compared) in body
    restored={};unique={};stable={};checked=set()
    for name,stage in index['固定段階'].items():
        frozen=json.loads((ROOT/stage['原文']['保存元']).read_bytes());saved=base.references(stage['全源復元参照'])
        restored[name]=len(frozen['ファイル'])
        for relative,expected in frozen['ファイル'].items():
            key=(relative,expected)
            if key not in checked:
                lib.check_reference(saved[relative],expected);checked.add(key)
            unique[relative]=expected
            if not relative.startswith(FORMAL.relative_to(ROOT).as_posix()+'/'):
                assert lib.sha(ROOT/relative)==expected,relative;stable[relative]=expected
    assert restored=={'F0':42,'F1':46,'F2':71}
    for record in index['154新生成3JSONを各1gzip保存']+index['金融とCSV証跡']:
        lib.check_reference(record,record['解凍SHA256'])
    for key in ('自然選択の独立監査','回帰環境の事後原因診断','現在価格と回復足の後発独立診断'):
        for relative,record in base.references(index[key]['全源復元参照']).items():
            lib.check_reference(record,record.get('解凍SHA256',record.get('sha256')))
    for rel,expected in files.items():lib.check_reference(base.references(index['保管と結果反映の後発小資料'])[rel],expected)
    replay=json.loads((FORMAL/'検査/保存観測からの再現確認.json').read_bytes())
    assert replay['成功'] and replay['比較数']==1020 and replay['正本と三表bytes再現']
    input_dir=ROOT/'inputs/00154_先行終値の回帰測定';input_readme=input_dir/'README.md'
    assert {p.name for p in input_dir.glob('*.json.gz')}=={'先行回帰の入力.json.gz','q0の判断.json.gz','選択対応.json.gz','選択の確認.json.gz'}
    mutation=json.loads((HERE/'入力README追記の確認.json').read_bytes())
    prefix=input_readme.read_bytes().split('\n\n## 154新生成3JSON'.encode('utf-8'),1)[0]
    assert hashlib.sha256(prefix).hexdigest()==mutation['追記前SHA256']
    links=0
    for path in [*docs,FORMAL/'閲覧資料.md',FORMAL/'再現手順.md',input_readme,*sorted((FORMAL/'根拠').glob('*.md'))]:
        for target in re.findall(r'\]\(([^)]+)\)',path.read_text(encoding='utf-8')):
            if '://' in target or target.startswith('#'):continue
            local=unquote(target.strip('<>').split('#',1)[0]);assert (path.parent/local).exists(),(path,target)
            links+=1
    for name in ('README.md','study/README.md','docs/README.md','docs/議論/README.md'):
        assert '00154_回帰で進行と往復を分けて短期回復から入る/README.md' in (ROOT/name).read_text(encoding='utf-8')
    assert before_docs=={p.name:lib.sha(p) for p in docs}
    assert all(lib.sha(ROOT/relative)==expected for relative,expected in stable.items())
    author={'成功':True,'試行':154,'編集停止':True,'条件と設定F0全bytes_prefix保持':True,
        'V7':{'手法':57,'尺度':9,'セル':513,'F0設定済み行全文同体':True},
        'README先頭':'実行済み・主U30率/頻度とも共同目標未達','主交換_閾値変更':False,
        '正式3MD':before_docs,'全ローカルリンク実在':links,'4目次へ154追補':True,
        '結果表all17_前8_後8正本一致':True,'入力README全prefix保持':True,
        '固定源復元件数':restored,'固定源unique':len(unique),'Source前後同体':True,
        '新3JSON各1gzip再読同体':True,'正本とtyped三表bytes再現':True,
        '自然監査12186941_金融1020比較24480キー_CSV49728は別票':True,
        '作者原因8小点_現在価格独立5小点を後発保存':True,
        '現在始値維持だけでは70達成を確認できず_事後小群未採用':True,
        '新モデル_共有大入力_原板_追加2場の新複写':False,
        '文書作者の自己確認と独立算術は別':True,'確認器SHA256':lib.sha(Path(__file__))}
    target=FORMAL/'検査/正式資料の最終反映確認.json';lib.write_new(target,lib.json_bytes(author))
    final={'成功':True,'編集停止':True,'試行':154,'保管索引SHA256':lib.sha(index_path),
        '作者最終票SHA256':lib.sha(target),'F0_F1_F2全固定源復元同体':restored,
        '全リンク_513_原文prefix':True,'保存選択から1020比較と三表bytes再現':True,
        '主U30率_頻度とも未達':True,'Source_book_旧153以前不変更':True}
    final_path=FORMAL/'検査/正式保存の最終確認.json';lib.write_new(final_path,lib.json_bytes(final))
    stop={**final,'正式最終票SHA256':lib.sha(final_path),'正式3MD':before_docs,'保存Source':files}
    lib.write_new(HERE/'停止の確認.json',lib.json_bytes(stop))
    print(json.dumps({'成功':True,'リンク':links,'513':True,'作者最終票SHA256':lib.sha(target),
        '正式保存最終票SHA256':lib.sha(final_path),'索引SHA256':lib.sha(index_path),'停止SHA256':lib.sha(HERE/'停止の確認.json')},ensure_ascii=False))


if __name__=='__main__':
    main()
