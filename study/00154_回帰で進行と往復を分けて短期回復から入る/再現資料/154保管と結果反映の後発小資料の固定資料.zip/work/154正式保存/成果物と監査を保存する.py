"""Root完了通知後の154金融・CSV・独立自然監査だけを恒久保存する。"""
from pathlib import Path
import hashlib
import importlib.util
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
FORMAL=ROOT/'study/00154_回帰で進行と往復を分けて短期回復から入る'


def main() -> None:
    """
    機能: 明示Root結果SHAを確認し正本/三表/検査票と監査7小点を保存する。
    引数: なし。返り値: None。Source/正式3MD/共有大入力を変更しない。
    """
    spec=importlib.util.spec_from_file_location('saving154_artifacts',HERE/'保存する.py')
    base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base);lib=base.library()
    index_path=FORMAL/'保管索引.json';index=json.loads(index_path.read_bytes())
    assert 'F2' in index['固定段階'] and '金融とCSV証跡' not in index
    runtime=ROOT/'work/154回帰環境の評価';finance=runtime/'金融集計'
    output=ROOT/'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/154_回帰環境の切替'
    assert lib.sha(finance/'集計.json')=='41b160e6918b7bdd58e8fcacf857ca036cb5f93720bde617d0c062169fe0deef'
    assert lib.sha(finance/'CSV用の表.json')=='7c23d465a813b0517f628ffaf2d44e3db81a08614c3256a49c53b498c922ccd0'
    saved=[]
    for source,destination,compress in [(finance/'集計.json','成果物/集計.json',False),
        (finance/'CSV用の表.json','成果物/CSV用の表.json.gz',True),
        (finance/'集計完了.json','成果物/集計完了.json',False),
        (runtime/'金融独立検算.json','検査/金融独立検算.json',False),
        (runtime/'CSV独立再読.json','検査/CSV独立再読.json',False),
        (output/'CSVの確認.json','検査/CSV作成の確認.json',False)]:
        record=lib.save_file(source,FORMAL/destination,lib.sha(source),compress)
        lib.check_reference(record,record['解凍SHA256']);saved.append(record)
    index['金融とCSV証跡']=saved
    # ----------------------------------------
    # 自然監査はF0へ遡及せず、停止票にある最小7小点だけを保存する。
    folder=ROOT/'work/154自然選択の独立監査';stop_path=folder/'停止の確認.json'
    stop_sha='48c09cd0977c719abf69d8c2e3445fb29c8190e65ac35911e343868cbbedda1e'
    assert lib.sha(stop_path)==stop_sha
    stop=json.loads(stop_path.read_bytes());assert stop['成功'] and stop['編集停止']
    files={folder/name:info['SHA256'] for name,info in stop['保存対象'].items()};files[stop_path]=stop_sha
    audit=folder/'自然確認/監査の確認.json'
    assert lib.sha(audit)=='57d87784a3d4224ec3292f90fd5f2844ed9eba72960c06f3d00be01ee130426e'
    record=lib.save_file(audit,FORMAL/'検査/自然選択の独立監査.json',lib.sha(audit))
    existing=base.references(index);existing[record['復元先']]=record
    refs=lib.resolve({p.relative_to(ROOT).as_posix():h for p,h in files.items()},'自然選択の独立監査',existing)
    index['自然選択の独立監査']={'停止SHA256':stop_sha,'正本':[record],'全源復元参照':refs,
        'F0_F1事前固定へ遡及':False,'Source_閾値_主の変更':False}
    index_path.write_bytes(lib.json_bytes(index))
    print(json.dumps({'成功':True,'金融CSV証跡':len(saved),'監査小点':len(files),'索引SHA256':lib.sha(index_path)},ensure_ascii=False))


if __name__=='__main__':
    main()
