"""154保存選択の再集計手順と既存回帰入力READMEの末尾案内を作る。"""
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
FORMAL=ROOT/'study/00154_回帰で進行と往復を分けて短期回復から入る'


def sha(path: Path) -> str:
    """
    機能: 小型保存源の指紋を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 153再現源の154版を作り、元入力案内をprefix保持して追記する。
    引数: なし。返り値: None。再選択・Raw走査・旧文書変更を行わない。
    """
    original=ROOT/'work/153正式保存/保存選択から再集計する.py'
    text=original.read_text(encoding='utf-8')
    text=text.replace('153','154').replace('00154_長い先行域から順行と反転を独立出生する','00154_回帰で進行と往復を分けて短期回復から入る')
    text=text.replace('154独立出生の評価','154回帰環境の評価').replace('154独立出生の金融集計','154回帰環境の金融集計')
    text=text.replace('660比較','1020比較').replace("'比較数': 960","'比較数': 1020")
    text=text.replace('bf5a29225a69e4e8837df9d8b34f263adb59f43ee70908e7668cc35a1a97a758',
        'f1a6d038c1f25ae703b7aef45c41fe4470899a531481abfd735e17c6128df5ea')
    source=HERE/'保存選択から再集計する.py';stored=FORMAL/'再現資料/保存選択から再集計する.py'
    assert not source.exists() and not stored.exists()
    source.write_bytes(text.encode('utf-8'));stored.write_bytes(source.read_bytes())
    index=json.loads((FORMAL/'保管索引.json').read_bytes())
    path=ROOT/'inputs/00154_先行終値の回帰測定/README.md';before=path.read_bytes()
    assert '## 154新生成3JSON' not in before.decode('utf-8')
    lines=['\n\n## 154新生成3JSON（F1後の追加）\n',
        '元の回帰測定案内は全bytesを保持し、この節だけ追記した。新モデルはない。\n',
        '| 保存 | 物理bytes | 物理SHA256 | 解凍bytes | 解凍SHA256 |','| --- | ---: | --- | ---: | --- |']
    for row in index['154新生成3JSONを各1gzip保存']:
        name=Path(row['保存元']).name
        lines.append(f"| [{name}]({name}) | {row['保存bytes']:,} | `{row['保存SHA256']}` | {row['解凍bytes']:,} | `{row['解凍SHA256']}` |")
    lines.append('\n各gzipのCRC/解凍SHAを再読照合。153先行域/148特徴・観測/旧152153対照は共有参照のみ。'
        '[正式結果](../../study/00154_回帰で進行と往復を分けて短期回復から入る/README.md)・'
        '[保管索引](../../study/00154_回帰で進行と往復を分けて短期回復から入る/保管索引.json)。\n')
    path.write_bytes(before+'\n'.join(lines).encode('utf-8'))
    proof={'成功':True,'既存入力README全bytes_prefix保持':path.read_bytes().startswith(before),
        '追記前SHA256':hashlib.sha256(before).hexdigest(),'追記後SHA256':sha(path),
        '保存再現源SHA256':sha(source),'回帰入力_book_共有大入力の変更又は複写':False}
    (HERE/'入力README追記の確認.json').write_bytes((json.dumps(proof,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':
    main()
