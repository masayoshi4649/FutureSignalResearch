"""154の固定選択を、作者124とは別の141算術で全条件再集計する。"""
from pathlib import Path
import argparse
import gzip
import hashlib
import importlib.util
import json
import math

ROOT = Path(__file__).resolve().parent.parent
POLICIES = ('C0', 'C1', 'RC1', 'B152', 'UB152', 'U153', 'R0', 'RR0', 'T30', 'V30', 'N30', 'U30', 'RU30', 'N15', 'U15', 'N60', 'U60')


def sha(path: Path) -> str:
    """
    機能: ファイル全件を保持せず指紋を計算する。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


# ----------------------------------------
def load_json(path: Path) -> object:
    """
    機能: JSON又はgzip JSONを全読しCRC終端を検査する。
    引数: path(Path)は保存入力。
    返り値: objectはJSON値。解凍コピーは作らない。
    """
    opener = gzip.open if path.suffix == '.gz' else Path.open
    with opener(path, 'rt', encoding='utf-8') as source:
        return json.load(source)


# ----------------------------------------
def load_math() -> object:
    """
    機能: 固定した別実装の金融算術を読み込む。
    引数: なし。
    返り値: objectは141モジュール。
    """
    path = ROOT / 'work/141金融集計を独立に確認する.py'
    assert sha(path) == '30bd4aef8c2809699cb013f930cfbce152f3986fe8d3d3cc6b49452104c2269e'
    spec = importlib.util.spec_from_file_location('独立141算術154', path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


# ----------------------------------------
def orient(case: dict, stream: str) -> dict:
    """
    機能: 保存caseを変更せず、選択方向をoriginalに写した参照を作る。
    引数: case(dict)、stream(str)はoriginal又はreverse。
    返り値: dictは浅い参照。価格やtouchを再計算しない。
    """
    assert stream in ('original', 'reverse')
    if stream == 'original':
        return case
    value = dict(case)
    value.update(original=case['reverse'], reverse=case['original'],
                 chart_original=case['chart_reverse'], chart_reverse=case['chart_original'])
    return value


# ----------------------------------------
def main() -> None:
    """
    機能: 選択参照だけを固定母集団観測へ結合し1020条件を再計算する。
    引数: CLI summary/output(Path)は作者集計と未作成確認先。
    返り値: None。Raw・100特徴・モデルを読み込まず、政策を選び直さない。
    """
    parser = argparse.ArgumentParser(description='154金融集計の独立照合')
    parser.add_argument('--summary', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    own = ROOT / 'work/154回帰環境の評価'
    parent = ROOT / 'work/148全1分母集団の評価'
    paths = {'selection': own / '入口選択/選択対応.json', 'f1': own / 'F1入口選択後.json',
        'result': ROOT / 'study/00148_全1分知得から入口品質の母集団を固定する/成果物/固定取得の正逆観測.json.gz',
        'fixed': ROOT / 'inputs/00148_全1分入口母集団/固定取得入力.json.gz',
        'metadata': ROOT / 'inputs/00148_全1分入口母集団/入口参照.json.gz', 'summary': args.summary}
    before = {key: sha(path) for key, path in paths.items()}
    assert before['result'] == 'bd809bdf24400628817afee702063504c65682e6748a60e0f32d7690b7363c61'
    selection, f1, result, fixed, metadata, summary = [load_json(paths[key])
        for key in ('selection', 'f1', 'result', 'fixed', 'metadata', 'summary')]
    assert selection['試行'] == summary['試行'] == f1['試行'] == 154
    assert f1['ファイル'][paths['selection'].relative_to(ROOT).as_posix()] == before['selection']
    decoded_fixed = hashlib.sha256()
    with gzip.open(paths['fixed'], 'rb') as source:
        for block in iter(lambda: source.read(1048576), b''):
            decoded_fixed.update(block)
    assert decoded_fixed.hexdigest() == metadata['fixed_input_sha256'] == result['input_sha256']
    assert result['input_sha256'] == '12c43fe60e0ffd5ffa44bec7b5f7dd3d60bb92b291e0008db23587dcf19536d3'
    sessions = [scene['session'] for scene in fixed['scenes']]
    assert sessions == selection['全73場'] and len(sessions) == len(set(sessions)) == 73
    cases = {case['id']: (scene['session'], case) for scene in result['scenes'] for case in scene['cases']}
    assert len(cases) == fixed['expected_entry_count'] == 31642
    members = dict(selection['政策'])
    c0_ids = {entry['id'] for entry in metadata['entries'] if entry['model'] == 'C0'}
    members['C0'] = [ref for ref in members['C1'] if ref['case_id'] in c0_ids]
    assert len(c0_ids) == len(members['C0']) == 81 and len(members['C1']) == 87
    mathematics = load_math()
    checked = comparisons = 0
    coverage = {}
    reverse_policies = {'RC1': 'C1', 'RU30': 'U30', 'RR0': 'R0'}
    for part, target in (('all', sessions), ('train', sessions[:48]), ('validation', sessions[48:])):
        target_set = set(target)
        hours = sum((scene['end'] - 300 - scene['start']) / 3600 for scene in fixed['scenes'] if scene['session'] in target_set)
        for policy in POLICIES:
            reverse = policy in reverse_policies
            refs = [ref for ref in members[reverse_policies.get(policy, policy)] if ref['session'] in target_set]
            assert len({ref['case_id'] for ref in refs}) == len(refs)
            selected = []
            flips = 0
            times = {}
            for ref in refs:
                sid, case = cases[ref['case_id']]
                assert sid == ref['session']
                stream = ref['stream']
                assert case[stream]['birth']['side'] == ref['side']
                selected.append((sid, orient(case, stream)))
                flips += (stream == 'reverse') != reverse
                times.setdefault(sid, []).append(case[stream]['birth']['time'])
            count_by_session = {sid: sum(ref['session'] == sid for ref in refs) for sid in target}
            component_count = maximum_component = 0
            for entries in times.values():
                end = None
                size = 0
                for entry in sorted(entries):
                    if end is None or entry >= end:
                        component_count += 1
                        size = 1
                    else:
                        size += 1
                    end = entry + 3600
                    maximum_component = max(maximum_component, size)
            coverage[part + '/' + policy] = {'取得数': len(refs), '各場最小': min(count_by_session.values()),
                '各場最大': max(count_by_session.values()), '全場最低1': all(count_by_session.values()),
                '全時間平均毎時': len(refs) / hours, '全場数': len(target),
                '名目60分窓の連結群数': component_count, '最大連結群件数': maximum_component}
            present = summary['参加'][part][policy]
            frequency = summary['頻度'][part][policy]
            overlapping = summary['重複連結群と場集中'][part][policy]
            assert present['取得数'] == len(refs) and present['全場最低1取得'] == all(count_by_session.values())
            assert present['最小場件数'] == min(count_by_session.values()) and present['最大場件数'] == max(count_by_session.values())
            assert math.isclose(frequency['全時間取得毎時'], len(refs) / hours, rel_tol=1e-12)
            assert overlapping['連結群数'] == component_count and overlapping['最大群件数'] == maximum_component
            for axis in ('BBO', 'Last'):
                for horizon in (1800, 3600):
                    for width in (25, 50, 100, 125, 200):
                        expected = mathematics.calculate(selected, reverse, axis, horizon, width)
                        expected['flips'] = flips
                        actual = summary['集計'][part][policy][axis][str(horizon)][str(width)]
                        assert set(expected) == set(actual)
                        for key, value in expected.items():
                            if isinstance(value, float):
                                assert math.isclose(value, actual[key], rel_tol=1e-12, abs_tol=1e-8), (part, policy, axis, horizon, width, key)
                            else:
                                assert value == actual[key], (part, policy, axis, horizon, width, key, value, actual[key])
                            checked += 1
                        comparisons += 1
    assert comparisons == 1020
    main_stats = summary['集計']['all']['U30']['BBO']['3600']['125']
    main_coverage = coverage['all/U30']
    resolved = main_stats['forward'] + main_stats['adverse']
    target_rate = 10 * main_stats['forward'] >= 7 * resolved if resolved else None
    target_frequency = main_coverage['全時間平均毎時'] >= 1
    goals = {'全場最低1': main_coverage['全場最低1'], '到達済70%': target_rate,
             '全時間毎時1以上': target_frequency,
             '三目標共同': main_coverage['全場最低1'] and target_rate and target_frequency if target_rate is not None else None}
    assert summary['主評価'] == goals
    assert all(sha(path) == before[key] for key, path in paths.items())
    output = {'成功': True, '試行': 154, '比較数': comparisons, '統計キー数': checked,
        '目標の独立判定': goals,
        '選択条件又はラベルによる選び直し': False, '作者124算術import': False,
        '取得と参加頻度': coverage, '自然原板再走査': False,
        '入力': {str(path.resolve()): before[key] for key, path in paths.items()}}
    with args.output.open('x', encoding='utf-8', newline='\n') as target:
        json.dump(output, target, ensure_ascii=False, indent=2, allow_nan=False)
        target.write('\n')
    print(json.dumps({'成功': True, '比較数': comparisons, '統計キー数': checked}, ensure_ascii=False))


if __name__ == '__main__':
    main()
