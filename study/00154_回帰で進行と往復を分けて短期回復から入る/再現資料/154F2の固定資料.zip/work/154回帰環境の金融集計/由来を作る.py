"""停止153金融器の算術を変更せず、154の政策と主窓へ適合する。"""
from pathlib import Path
import hashlib
import re

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent


def replace_function(text: str, name: str, replacement: str) -> str:
    """
    機能: 由来が分かる本文で指定関数一個を置き換える。
    引数: text/name/replacement(str)。返り値: str。
    """
    pattern = re.compile(r'(?ms)^def ' + re.escape(name) + r'\(.*?(?=^def |^if __name__)')
    text, count = pattern.subn(lambda _: replacement + '\n\n', text)
    assert count == 1
    return text


def main() -> None:
    """
    機能: 153停止Sourceから154政策/主U30/旧153対照だけへ適合する。
    引数: なし。返り値: None。自然金融・特徴・選択本文を開かない。
    """
    original = ROOT / 'work/153独立出生の金融集計/集計する.py'
    body = original.read_bytes()
    assert hashlib.sha256(body).hexdigest() == '47a34ae2b963a2d99ef68da20d5a3bd1a4ca4774b04608075f044f42c6f34b5b'
    text = body.decode('utf-8')
    text = re.sub(r'(?<![\w])153(?![\w])', '154', text)
    names = {name+left:name+right for name in ('N','U','RU','NN','NB') for left,right in [('15','30'),('30','15')]}
    text = re.sub('|'.join(sorted(names, key=len, reverse=True)), lambda m:names[m.group(0)], text)
    text = text.replace('960比較', '1020比較').replace('len(comparisons)==960', 'len(comparisons)==1020')
    text = text.replace('153独立出生', '154回帰環境').replace('153固定別名', '154固定別名').replace('for153finance', 'for154finance')
    text = text.replace('153全q0', '154全q0').replace('153で新学習', '154で新学習').replace('153新資格', '154新資格')
    start, end = text.index('POLICIES='), text.index('\n', text.index('POLICIES='))
    text = text[:start] + "POLICIES=('C0','C1','RC1','B152','UB152','U153','R0','RR0','T30','V30','N30','U30','RU30','N15','U15','N60','U60')" + text[end:]
    text = text.replace("direct=('C1','B152','UB152','R0','PB','BR15','RV15','N30','U30','N15','U15','N60','U60')",
                        "direct=('C1','B152','UB152','U153','R0','T30','V30','N30','U30','N15','U15','N60','U60')")
    text = text.replace("for dest,source in [('RC1','C1'),('RU30','U30')]:", "for dest,source in [('RC1','C1'),('RR0','R0'),('RU30','U30')]:")
    anchor = "INPUTS={'出生台帳'"
    extra = """ANCESTOR153=ROOT/'work/153独立出生の金融集計/集計する.py'
PRIOR153=ROOT/'study/00153_長い先行域から順行と反転を独立出生する/成果物/集計.json'
RR153=ROOT/'study/00153_長い先行域から順行と反転を独立出生する/根拠/金融診断.json.gz'
SOURCES[ANCESTOR153]='47a34ae2b963a2d99ef68da20d5a3bd1a4ca4774b04608075f044f42c6f34b5b'
SOURCES[PRIOR153]='f8f1c4695d553ec1f0e7883c479fe381c8c954f4f0469346b60507a255ee3e44'
SOURCES[RR153]='202f08c3b3f2a39a8aff007456fb90685e08da8c1117da867d93dd3d6f7893ef'
RR153_DECODED='fed4e8c1c4481fe95b65ad70492e95f077baa7230f8119bed1b910d8be489ba9'
"""
    assert anchor in text
    text = text.replace(anchor, extra+anchor, 1)
    # ----------------------------------------
    # U153は旧unionの固定対照であり、新N30へ入れない。C1保護だけ再検査する。
    line = "    for alias in ('NN30','NB30'):"
    extra = """    fixed_union={row['case_id']:row for row in policies['U153']}
    assert len(fixed_union)==len(policies['U153']) and set(legacy)<=set(fixed_union)
    for key,row in legacy.items():
        assert all(fixed_union[key].get(field)==row.get(field) for field in ('case_id','session','side','stream','event_id','feature_ref','q0_time','q0_index','q0_line'))
"""
    assert line in text
    text = text.replace(line, extra+line, 1)
    insertion = '''def prior153_check(values: dict,prior: dict) -> dict:
    """
    機能: 旧153U15/R0を154の固定U153/R0へ全120条件で照合する。
    引数: values/prior(dict)。返り値: dictは条件数と統計セル数。
    """
    count=cells=0
    for part in ('all','train','validation'):
        for policy,old in [('U153','U15'),('R0','R0')]:
            for axis in AXES:
                for horizon in HORIZONS:
                    for width in WIDTHS:
                        actual=values[part][policy][axis][str(horizon)][str(width)]
                        expected=prior['集計'][part][old][axis][str(horizon)][str(width)]
                        assert actual==expected,(part,policy,old,axis,horizon,width)
                        count+=1;cells+=len(actual)
    assert count==120
    return {'成功':True,'旧試行':153,'政策対応':{'U153':'U15','R0':'R0'},'条件数':count,'統計セル数':cells,'全統計同体':True}


def prior_rr0_check(values: dict,prior: dict) -> dict:
    """
    機能: 既存153原因のR0元/実逆をBBO/H60±125の全期前後で照合する。
    引数: values/prior(dict)。返り値: dict。旧に無い幅/Last/H30へ同体範囲を広げない。
    """
    fields={'件数':'entries','場数':'sessions','F':'forward','A':'adverse','N':'neither','C':'censored',
        '到達済率':'resolved_rate','完了分母率':'complete_rate','IFD既知':'ifd_known','IFD未知':'ifd_unknown',
        'C5利益':'ifd_net5_profit','C5損失絶対':'ifd_net5_loss','C5差引':'ifd_net5_sum','PF':'ifd_net5_pf'}
    checked=0
    for part in ('all','train','validation'):
        for policy,old in [('R0','元方向'),('RR0','実逆')]:
            actual=values[part][policy]['BBO']['3600']['125']
            expected=prior['全期前後'][part]['R0']['同q1実正逆'][old]
            for key,field in fields.items():
                assert actual[field]==expected[key],(part,policy,field,actual[field],expected[key])
                checked+=1
    assert checked==84
    return {'成功':True,'旧試行':153,'比較軸':'BBO','H秒':3600,'同幅pt':125,'区分':['all','train','validation'],
        '元実逆統計値':checked,'旧に存在しない全幅_Last_H30の同体を主張':False}


'''
    text = text.replace('def cumulative_step(', insertion+'def cumulative_step(', 1)
    text = text.replace("else '固定複合回復'", "else '旧153固定対照'if policy in ('U153','R0','RR0')else '回帰環境と短期回復'")
    text = text.replace("prior_check=prior152_check(values,load(PRIOR152,SOURCES[PRIOR152]))",
                        "prior_check=prior152_check(values,load(PRIOR152,SOURCES[PRIOR152]));prior153=prior153_check(values,load(PRIOR153,SOURCES[PRIOR153]));priorrr=prior_rr0_check(values,load(RR153,SOURCES[RR153],RR153_DECODED))")
    text = text.replace("'旧152_B0_U1同体':prior_check,", "'旧152_B0_U1同体':prior_check,'旧153_U15_R0同体':prior153,'旧153_R0実逆同体':priorrr,")
    text = text.replace("'新資格へ予測又は旧152選択を渡す':False", "'新資格へ予測又は旧152_153選択を渡す':False")
    text = text.replace("'RU30':'U30の同q1反対BBO側'", "'RU30':'U30の同q1反対BBO側','RR0':'R0の同q1反対BBO側'")
    target = HERE / '集計する.py'
    target.write_bytes(text.encode('utf-8'))


if __name__ == '__main__':
    main()
