"""154金融は実行せず、8人工・AST5同体・共有入力指紋の宣言を固定する。"""
from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import os
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def sha(path: Path) -> str:
    """
    機能: 小源の物理指紋を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def function_ast(path: Path, name: str) -> str:
    """
    機能: 指定関数を位置情報を除くASTへ写す。
    引数: path(Path)、name(str)。返り値: str。
    """
    node=next(n for n in ast.parse(path.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef) and n.name==name)
    return ast.dump(node,include_attributes=False)


def main() -> None:
    """
    機能: 自然選択/金融本文なしで8人工と由来同体を確認し準備/停止票を作る。
    引数: なし。返り値: None。過去Sourceや自然入力は変更しない。
    """
    spec=importlib.util.spec_from_file_location('finance154_prepare',HERE/'集計する.py')
    source=importlib.util.module_from_spec(spec);spec.loader.exec_module(source)
    parent_spec=importlib.util.spec_from_file_location('finance153_same_inputs',source.ANCESTOR153)
    parent=importlib.util.module_from_spec(parent_spec);parent_spec.loader.exec_module(parent)
    assert source.INPUTS==parent.INPUTS and source.OBS_DECODED==parent.OBS_DECODED
    assert len(source.OBS_DECODED)==64 and len(source.POLICIES)==17
    deferred=(source.PRIOR152,source.PRIOR153,source.RR153,source.OLD_PAIRS,source.OLD_SUMMARY)
    paths=list(HERE.glob('*.py'))+[HERE/'条件.md']+[p for p in source.SOURCES if p not in deferred]
    paths += [ROOT/'work'/folder/'人工検査.py' for folder in
              ('153独立出生の金融集計','152複合回復の金融集計','151過去場判別の金融集計','150構造状態の金融集計','148母集団の診断集計')]
    paths=list(dict.fromkeys(paths));before={p:sha(p) for p in paths}
    assert all(before[p]==expected for p,expected in source.SOURCES.items() if p not in deferred)
    for path in HERE.glob('*.py'):
        tree=ast.parse(path.read_text(encoding='utf-8'))
        for node in ast.walk(tree):
            if isinstance(node,ast.FunctionDef):
                comment=ast.get_docstring(node)
                assert comment and '\n' in comment and all(k in comment for k in ('機能','引数','返り値'))
    copied={name:function_ast(HERE/'集計する.py',name)==function_ast(source.ANCESTOR153,name)
            for name in ('sha','load','module','selected','cumulative_step')}
    assert all(copied.values())
    result=subprocess.run([sys.executable,'-X','utf8',str(HERE/'人工検査.py')],capture_output=True,cwd=ROOT,
        env={**os.environ,'PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8','PYTHONDONTWRITEBYTECODE':'1'})
    output,error=result.stdout.decode('utf-8','strict'),result.stderr.decode('utf-8','strict')
    assert result.returncode==0 and '\ufffd' not in output+error
    assert before=={p:sha(p) for p in paths}
    proof={'成功':True,'試行':154,'自然154採否_容量_金融':False,
        '自然特徴_先行高安_回帰_観測_旧金融の本文読取':False,'新学習_再予測_新Raw_CSV_追加2場':False,
        '人工主数':8,'UTF8_strict_構文_関数コメント':True,'153基本5関数AST同体':copied,
        'INPUTSとOBS解凍SHAは153同体':True,'全源前後同体':True,
        '源':[{'path':p.relative_to(ROOT).as_posix(),'sha256':h,'bytes':p.stat().st_size} for p,h in before.items()],
        '後段のみ読む金融正本':[{'path':p.relative_to(ROOT).as_posix(),'sha256':source.SOURCES[p],'準備時の物理bytes読取':False} for p in deferred],
        '三表契約':{'正逆比較':[1020,34],'入口別診断':['U30可変件数・旧87保護',47],'全セッション':[73,69]},
        '固定対照':{'152B0_U1':[120,2880],'153U15_R0':[120,2880],'153R0元実逆_BBO_H60_125のみ':84},
        '主':'U30','全場累計':['U30','N30','C1'],
        '固定票':'F1選択後とF2金融前を別票別SHAで照合、F2からF1を参照',
        '独立性':'作者は153/152/149/124算術の継承。Root141別算術とは別。',
        '人工結果':{'終了値':result.returncode,'標準出力':output,'標準エラー':error}}
    ready=HERE/'準備の確認.json';stop=HERE/'停止.json'
    assert not ready.exists() and not stop.exists()
    ready.write_bytes((json.dumps(proof,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    stop.write_bytes((json.dumps({'成功':True,'編集停止':True,'試行':154,'自然未実行':True,'準備SHA256':sha(ready),
        '自源':{p.name:h for p,h in before.items() if p.parent==HERE}},ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    print(json.dumps({'成功':True,'準備SHA256':sha(ready),'停止SHA256':sha(stop),'集計SourceSHA256':sha(HERE/'集計する.py')},ensure_ascii=False))


if __name__=='__main__':
    main()
