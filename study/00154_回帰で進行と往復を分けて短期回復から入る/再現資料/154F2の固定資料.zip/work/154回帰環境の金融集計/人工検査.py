"""自然本文なしで154の17政策・固定対照・累計・1020三表を検査する。"""
from pathlib import Path
import copy
import gzip
import hashlib
import importlib.util
import json
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def module(path: Path, name: str):
    """
    機能: mainを実行せず停止した人工部品と算術だけを読む。
    引数: path(Path)、name(str)。返り値: ModuleType。
    """
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


m = module(HERE / '集計する.py', 'finance154artificial')
previous = module(ROOT / 'work/153独立出生の金融集計/人工検査.py', 'fixture153for154')


def fixture(empty: bool = False) -> tuple:
    """
    機能: 旧87・旧固定unionと新case1を含む17政策の人工参照を作る。
    引数: empty(bool)。返り値: tupleはrecords/場/固定/選択/meta/算術/members。
    """
    records, sessions, fixed, old, meta, parent, arith, members = previous.fixture(empty)
    policies = {p:copy.deepcopy(old['政策'][p]) for p in ('C1','B152','UB152','R0')}
    policies.update({'U153':copy.deepcopy(old['政策']['U15']),
                    'T30':copy.deepcopy(old['政策']['PB']),
                    'V30':copy.deepcopy(old['政策']['BR15']+old['政策']['RV15'])})
    for dest,source in [('N30','N15'),('U30','U15'),('N15','N30'),('U15','U30'),('N60','N60'),('U60','U60')]:
        policies[dest] = copy.deepcopy(old['政策'][source])
    policies['NN30'] = copy.deepcopy(policies['N30'])
    selection = {'成功':True,'試行':154,'選択時の金融ラベル利用':False,'政策':policies,
        '旧C1重複':{new:copy.deepcopy(old['旧C1重複'][prior]) for new,prior in [('U30','U15'),('U15','U30'),('U60','U60')]},
        '候補と取得':{},'全73場':sessions}
    parent.POLICIES = m.POLICIES
    arith.POLICIES = m.POLICIES
    arith.selected = m.selected
    return m.bind_choices(records,members,selection),sessions,fixed,selection,meta,parent,arith,members


class Tests(unittest.TestCase):
    """自然154の金融を実行しない8主群。"""

    def test_1020三表とC1優先と三実逆(self) -> None:
        """
        機能: 1020/47/69列、旧87保護とRC1/RR0/RU30の実streamを検査する。
        引数: self(Tests)。返り値: None。
        """
        records,sessions,fixed,selection,meta,parent,arith,_ = fixture()
        values,p,f,goals,overlaps = parent.calculate(records,sessions,fixed['scenes'],arith)
        tables,curves = m.tables(records,sessions,values,p,f,overlaps,selection,meta,parent,arith)
        self.assertEqual([(len(t['rows']),len(t['headers'])) for t in tables],[(1020,34),(88,47),(73,69)])
        self.assertEqual(records['人工00/0']['choices']['V30']['side'],1)
        self.assertEqual(records['人工00/0']['choices']['U30']['side'],-1)
        for source,inverse in [('C1','RC1'),('R0','RR0'),('U30','RU30')]:
            for record in records.values():
                if source in record['choices']:
                    a,b = record['choices'][source],record['choices'][inverse]
                    self.assertEqual(a['side'],-b['side'])
                    self.assertNotEqual(a['stream'],b['stream'])
        self.assertEqual(curves['U30'][sessions[-1]]['累計既知差引'],values['all']['U30']['BBO']['3600']['125']['ifd_net5_sum'])
        self.assertNotIn('NN30',values['all'])
        entry_times=[r[tables[1]['headers'].index('取得JST')] for r in tables[1]['rows']]
        self.assertEqual(entry_times,sorted(entry_times))

    def test_旧152と153各120条件(self) -> None:
        """
        機能: 別名旧対照各120条件2880セルを照合し一値差を拒否する。
        引数: self(Tests)。返り値: None。
        """
        records,sessions,fixed,_,_,parent,arith,_=fixture()
        values,*_=parent.calculate(records,sessions,fixed['scenes'],arith)
        for operation,aliases in [(m.prior152_check,{'B0':'B152','U1':'UB152'}),
                                  (m.prior153_check,{'U15':'U153','R0':'R0'})]:
            prior={'集計':{part:{old:copy.deepcopy(value[new]) for old,new in aliases.items()} for part,value in values.items()}}
            proof=operation(values,prior)
            self.assertEqual((proof['条件数'],proof['統計セル数']),(120,2880))
            first=next(iter(aliases))
            prior['集計']['validation'][first]['Last']['1800']['25']['entries']+=1
            with self.assertRaises(AssertionError):operation(values,prior)

    def test_旧R0実逆既存84値(self) -> None:
        """
        機能: 旧原因の元実逆84値だけを同単位で照合し逆利益差1を拒否する。
        引数: self(Tests)。返り値: None。
        """
        records,sessions,fixed,_,_,parent,arith,_=fixture()
        values,*_=parent.calculate(records,sessions,fixed['scenes'],arith)
        fields={'件数':'entries','場数':'sessions','F':'forward','A':'adverse','N':'neither','C':'censored',
            '到達済率':'resolved_rate','完了分母率':'complete_rate','IFD既知':'ifd_known','IFD未知':'ifd_unknown',
            'C5利益':'ifd_net5_profit','C5損失絶対':'ifd_net5_loss','C5差引':'ifd_net5_sum','PF':'ifd_net5_pf'}
        prior={'全期前後':{part:{'R0':{'同q1実正逆':{old:{key:value[policy]['BBO']['3600']['125'][field] for key,field in fields.items()}
            for old,policy in [('元方向','R0'),('実逆','RR0')]}}} for part,value in values.items()}}
        proof=m.prior_rr0_check(values,prior)
        self.assertEqual(proof['元実逆統計値'],84)
        self.assertFalse(proof['旧に存在しない全幅_Last_H30の同体を主張'])
        prior['全期前後']['all']['R0']['同q1実正逆']['実逆']['C5利益']+=1
        with self.assertRaises(AssertionError):m.prior_rr0_check(values,prior)

    def test_空新群と全73とLastnull(self) -> None:
        """
        機能: 新規0でも旧87/73場と1020行を保持し率/Last金額をnullにする。
        引数: self(Tests)。返り値: None。
        """
        records,sessions,fixed,selection,meta,parent,arith,_=fixture(True)
        values,p,f,_,overlaps=parent.calculate(records,sessions,fixed['scenes'],arith)
        tables,_=m.tables(records,sessions,values,p,f,overlaps,selection,meta,parent,arith)
        self.assertEqual(values['all']['N30']['BBO']['3600']['125']['entries'],0)
        self.assertIsNone(values['all']['N30']['BBO']['3600']['125']['resolved_rate'])
        self.assertEqual(p['all']['N30']['取得場数'],0)
        self.assertEqual(len(tables[2]['rows']),73)
        self.assertIsNone(values['all']['U30']['Last']['3600']['125']['ifd_net5_sum'])

    def test_C1上書きと重複を拒否(self) -> None:
        """
        機能: C1優先破壊、旧U153保護破壊、policy重複を拒否する。
        引数: self(Tests)。返り値: None。
        """
        records,_,_,selection,_,_,_,members=fixture()
        for policy in ('U30','U15','U60','UB152','U153'):
            damaged=copy.deepcopy(selection)
            damaged['政策'][policy][0]['side']*=-1
            with self.assertRaises(AssertionError):m.bind_choices(records,members,damaged)
        damaged=copy.deepcopy(selection)
        damaged['政策']['N30'].append(copy.deepcopy(damaged['政策']['N30'][0]))
        with self.assertRaises(AssertionError):m.bind_choices(records,members,damaged)

    def test_H不足touch費用未知累計(self) -> None:
        """
        機能: 不足でも既知touch/C5=1077を保持し未知累計を非回復にする。
        引数: self(Tests)。返り値: None。
        """
        records,_,_,_,_,_,arith,_=fixture()
        record=records['人工00/0'];observed=m.selected(record,'U30','BBO')
        observed['outcomes'][1]['status']='censored';observed['outcomes'][1]['endpoint']=None
        stats=arith.stats([record],'U30','BBO',3600,125)
        self.assertEqual((stats['complete'],stats['ifd_known'],stats['ifd_net5_sum']),(0,1,12500-1077))
        first=m.cumulative_step({},{'ifd_net5_profit':10,'ifd_net5_loss':0,'ifd_unknown':1})
        second=m.cumulative_step(first,{'ifd_net5_profit':20,'ifd_net5_loss':5,'ifd_unknown':0})
        self.assertEqual(second['累計既知差引'],25)
        self.assertIsNone(second['累計全件確定差引'])

    def test_別F1F2とgzipCRC(self) -> None:
        """
        機能: 固定段階同票/入替とCRC/解凍SHAの不一致を拒否する。
        引数: self(Tests)。返り値: None。
        """
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);selection=root/'選択.json';selection.write_bytes(b'{}');h=m.sha(selection)
            f1,f2=root/'F1.json',root/'F2.json'
            f1.write_text(json.dumps({'成功':True,'試行':154,'ファイル':{str(selection):h}}),encoding='utf-8');a=m.sha(f1)
            f2.write_text(json.dumps({'成功':True,'試行':154,'ファイル':{str(selection):h,str(f1):a}}),encoding='utf-8')
            m.verify_freezes(f1,a,f2,m.sha(f2),selection,h)
            with self.assertRaises(AssertionError):m.verify_freezes(f1,a,f1,a,selection,h)
            with self.assertRaises((AssertionError,KeyError)):m.verify_freezes(f2,m.sha(f2),f1,a,selection,h)
            path=root/'人工.json.gz';raw='{"日本語":true}'.encode('utf-8');path.write_bytes(gzip.compress(raw,mtime=0))
            self.assertEqual(m.load(path,m.sha(path),hashlib.sha256(raw).hexdigest()),{'日本語':True})
            with self.assertRaises(AssertionError):m.load(path,m.sha(path),'0'*64)
            body=bytearray(path.read_bytes());body[-8]^=1;path.write_bytes(body)
            with self.assertRaises((OSError,EOFError)):m.load(path,m.sha(path))

    def test_補助aliasは主へ二重加算しない(self) -> None:
        """
        機能: NN30を金融外の同体aliasに限定し方向を変えたaliasを拒否する。
        引数: self(Tests)。返り値: None。
        """
        records,_,_,selection,_,_,_,members=fixture()
        self.assertNotIn('NN30',m.POLICIES)
        selection['政策']['NN30'][0]['side']*=-1
        with self.assertRaises(AssertionError):m.bind_choices(records,members,selection)


if __name__=='__main__':
    unittest.main(verbosity=2)
