"""R0現在価格の維持状態を固定し、その後だけ同q1実正逆の金融を診断する。"""
from pathlib import Path
from collections import Counter
import gzip
import hashlib
import importlib.util
import json
import math
import re

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
MATH_PATH = ROOT / 'work/141金融集計を独立に確認する.py'
MATH_SHA = '30bd4aef8c2809699cb013f930cfbce152f3986fe8d3d3cc6b49452104c2269e'
PATHS = {
 'f1': ROOT / 'work/154回帰環境の評価/F1入口選択後.json',
 'f2': ROOT / 'work/154回帰環境の評価/F2実金融集計前.json',
 'selection': ROOT / 'work/154回帰環境の評価/入口選択/選択対応.json',
 'q0': ROOT / 'work/154回帰環境の評価/入口選択/q0の判断.json',
 'high': ROOT / 'inputs/00153_先行高安の独立出生/先行高安の入力.json.gz',
 'observations': ROOT / 'study/00148_全1分知得から入口品質の母集団を固定する/成果物/固定取得の正逆観測.json.gz',
 'baseline': ROOT / 'study/00153_長い先行域から順行と反転を独立出生する/検査/R0実逆の独立確認.json',
 'definition': HERE / '区分の事前固定.md'}
GROUPS = {'始値': ('正', '等', '負'), '逆端': ('非破り', '破り'),
          '交差': tuple(a + '/' + b for a in ('正', '等', '負') for b in ('非破り', '破り'))}


def sha(path: Path) -> str:
    """
    機能: 明示入力の全物理指紋をstreamで求める。
    引数: path(Path)。返り値: str。
    """
    value = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1 << 20), b''): value.update(block)
    return value.hexdigest()


# ----------------------------------------
def read_gzip(path: Path, physical: str, decoded: str) -> dict:
    """
    機能: gzip全CRCと物理/解凍SHAを検証してJSONを読む。
    引数: path(Path)、physical/decoded(str)。返り値: dict。
    """
    assert sha(path) == physical
    with gzip.open(path, 'rb') as source: body = source.read()
    assert hashlib.sha256(body).hexdigest() == decoded
    return json.loads(body)


# ----------------------------------------
def array(path: Path, name: str, evidence: dict):
    """
    機能: 大JSON配列を1要素ずつ読み全解凍指紋/CRCを完読する。
    引数: path(Path)、name(str)、evidence(dict)。返り値: Iterator[dict]。
    """
    digest = hashlib.sha256(); size = 0; buffer = ''; decoder = json.JSONDecoder()
    opener = gzip.open if path.suffix == '.gz' else Path.open
    with opener(path, 'rt', encoding='utf-8', newline='') as source:
        def more() -> str:
            """
            機能: UTF8境界を保って全bytesを指紋へ加える。
            引数: なし。返り値: str。
            """
            nonlocal size
            value = source.read(1 << 20); raw = value.encode('utf-8'); digest.update(raw); size += len(raw); return value
        while True:
            value = more(); assert value, '配列がない'
            buffer += value; match = re.search(r'(?m)^  "' + re.escape(name) + r'": \[', buffer)
            if match: buffer = buffer[match.end():]; break
        while True:
            buffer = buffer.lstrip()
            if buffer.startswith(']'): break
            if buffer.startswith(','): buffer = buffer[1:].lstrip()
            try: item, end = decoder.raw_decode(buffer)
            except json.JSONDecodeError:
                value = more(); assert value, '配列途中終了'; buffer += value; continue
            yield item; buffer = buffer[end:]
        while more(): pass
    evidence.update(decoded_sha256=digest.hexdigest(), decoded_bytes=size, gzip_full_crc_checked=path.suffix == '.gz')


# ----------------------------------------
def stamp(value: dict) -> tuple:
    """
    機能: q0と保存Stampの両物理行schemaを統一する。
    引数: value(dict)。返り値: tuple。
    """
    return value['time'], value['index'], value['line'] if 'line' in value else value['source_line']


# ----------------------------------------
def classify(side: int, row: dict, r: dict) -> tuple:
    """
    機能: 事前固定の始値3群・逆端2群へ元R0方向で一意に分類する。
    引数: side(int)、row/r(dict)。返り値: tuple[str,str]。
    """
    assert type(side) is int and side in (-1, 1)
    q = row['q0']; assert row['eligible'] and q['last_known'] and r['price_known'] and r['closed'] and not r['missing']
    assert stamp(r['stamp']) == stamp(q) and r['end'] <= r['available_at'] <= q['time']
    assert all(type(v) in (int, float) and math.isfinite(v) for v in (q['last'], r['ohlc']['open'], r['ohlc']['low'], r['ohlc']['high']))
    d_open = side * (q['last'] - r['ohlc']['open'])
    d_extreme = side * (q['last'] - r['ohlc']['low' if side == 1 else 'high'])
    return ('正' if d_open > 0 else '負' if d_open < 0 else '等', '破り' if d_extreme < 0 else '非破り')


# ----------------------------------------
def stat(value: dict) -> dict:
    """
    機能: 141結果の必要値だけを表示し空の損益nullを保つ。
    引数: value(dict)。返り値: dict。
    """
    fields = {'件数': 'entries', '場数': 'sessions', 'F': 'forward', 'A': 'adverse', 'N': 'neither', 'C': 'censored',
              '到達済率': 'resolved_rate', '完了分母率': 'complete_rate', 'IFD既知': 'ifd_known', 'IFD未知': 'ifd_unknown',
              'C5利益': 'ifd_net5_profit', 'C5損失絶対': 'ifd_net5_loss', 'C5差引': 'ifd_net5_sum', 'PF': 'ifd_net5_pf'}
    return {name: value[key] for name, key in fields.items()}


# ----------------------------------------
def group_name(pair: tuple, axis: str) -> str:
    """
    機能: 固定分類から各分割の名称を得る。
    引数: pair(tuple[str,str])、axis(str)。返り値: str。
    """
    return pair[0] if axis == '始値' else pair[1] if axis == '逆端' else '/'.join(pair)


# ----------------------------------------
def main() -> None:
    """
    機能: 非金融群固定・因果結合後にR0だけの実正逆を計算し、小票と短報へ保存する。
    引数: なし。返り値: None。新条件/新q0/新選択/Rawを生成しない。
    """
    output = HERE / '診断.json'; assert not output.exists()
    assert sha(MATH_PATH) == MATH_SHA
    before = {key: {'sha256': sha(path), 'bytes': path.stat().st_size, 'mtime_ns': path.stat().st_mtime_ns} for key, path in PATHS.items()}
    assert before['f1']['sha256'] == 'd3eb4ed12b2a62b46da3e0bc581e558f8a5a85514a0f56ac5bc4c6be12de942a'
    assert before['f2']['sha256'] == 'c14dc4005bd9bbdb3ce7987beb63796e8e97cd677964bb3b536f8f15eb72f0a8'
    assert before['observations']['sha256'] == 'bd809bdf24400628817afee702063504c65682e6748a60e0f32d7690b7363c61'
    f1 = json.loads(PATHS['f1'].read_bytes()); f2 = json.loads(PATHS['f2'].read_bytes()); selection = json.loads(PATHS['selection'].read_bytes())
    for key in ('selection', 'q0'):
        assert f1['ファイル'][PATHS[key].relative_to(ROOT).as_posix()] == before[key]['sha256']
        assert f2['ファイル'][PATHS[key].relative_to(ROOT).as_posix()] == before[key]['sha256']
    refs = selection['政策']['R0']; assert len(refs) == len({r['case_id'] for r in refs}) == 1375
    sessions = selection['全73場']; assert len(sessions) == len(set(sessions)) == 73
    high = read_gzip(PATHS['high'], '2c020fed5b336ed0b417d8e72a07c6336ea475b09b9a2ff37f26ec4ce4d56bf8',
                     '8e145275dda385e4c2f87500978716654d10efb0903a4011f2bcc304a7906b14')
    assert high['sessions'] == sessions
    source = {}
    for scene in high['scenes']:
        bars = {bar['id']: bar for bar in scene['bars']}
        for row in scene['rows']:
            assert row['event_id'] not in source
            source[row['event_id']] = (scene['session'], scene['contract'], row, bars[row['r_ref']])
    assert len(source) == 40544
    births = {}; q0_evidence = {}; q0_count = 0
    for decision in array(PATHS['q0'], 'rows', q0_evidence):
        q0_count += 1; side = decision['decision']['directions']['R0']
        if not side: continue
        sid, contract, row, r = source[decision['event_id']]
        assert (sid, contract, r['id']) == (decision['session'], decision['contract'], decision['r_ref'])
        assert stamp(row['q0']) == (decision['q0_time'], decision['q0_index'], decision['q0_line'])
        assert decision['event_id'] not in births
        births[decision['event_id']] = {'session': sid, 'side': side, 'group': classify(side, row, r)}
    assert q0_count == 35339 and len(births) == 1494 and q0_evidence['decoded_sha256'] == before['q0']['sha256']
    groups = {}
    for ref in refs:
        sid, contract, row, r = source[ref['event_id']]; birth = births[ref['event_id']]
        assert ref['session'] == sid == birth['session'] and ref['side'] == birth['side']
        assert stamp(row['q0']) == (ref['q0_time'], ref['q0_index'], ref['q0_line'])
        groups[ref['case_id']] = birth['group']
    assert len(groups) == 1375
    # ----------------------------------------
    # ここまで金融観測未読。元方向の群を以後固定し実逆でも組み替えない。
    spec = importlib.util.spec_from_file_location('固定141独立算術_154構造診断', MATH_PATH)
    mathematics = importlib.util.module_from_spec(spec); spec.loader.exec_module(mathematics)
    wanted = {ref['case_id']: ref for ref in refs}; cases = []; obs_evidence = {}; total_cases = scene_count = 0
    for scene in array(PATHS['observations'], 'scenes', obs_evidence):
        assert scene['success'] and scene['session'] == sessions[scene_count]; scene_count += 1; total_cases += len(scene['cases'])
        for case in scene['cases']:
            if case['id'] not in wanted: continue
            ref = wanted.pop(case['id']); stream = ref['stream']; other = 'reverse' if stream == 'original' else 'original'
            native, inverse = case[stream], case[other]
            assert native['birth']['side'] == ref['side'] and inverse['birth']['side'] == -ref['side']
            assert native['entry'] == inverse['entry'] and ref['session'] == scene['session']
            quote = native['entry']; assert quote['quote_ok'] and 0 < quote['bid'] < quote['ask']
            assert native['entry_price'] == quote['ask' if ref['side'] == 1 else 'bid']
            assert inverse['entry_price'] == quote['bid' if ref['side'] == 1 else 'ask']
            cases.append((scene['session'], {**case, 'original': native, 'reverse': inverse}))
    assert not wanted and scene_count == 73 and total_cases == 31642
    assert obs_evidence['decoded_sha256'] == 'd1b4cab8a258203f04b5c1d081f57d10ed2a0c58ce4cc160ef571d5fac0ceffc'
    result = {}; births_result = {}; sum_checks = 0
    for part, scope in (('all', sessions), ('train', sessions[:48]), ('validation', sessions[48:])):
        selected = [row for row in cases if row[0] in scope]; period = {'全R0': {}}
        for name, reverse in (('元方向', False), ('実逆', True)):
            period['全R0'][name] = stat(mathematics.calculate(selected, reverse, 'BBO', 3600, 125))
        births_scope = [birth for birth in births.values() if birth['session'] in scope]
        births_result[part] = {'出生数': len(births_scope), '場数': len({birth['session'] for birth in births_scope}), '分割': {}}
        for axis, labels in GROUPS.items():
            table = {}
            for label in labels:
                subset = [row for row in selected if group_name(groups[row[1]['id']], axis) == label]
                table[label] = {name: stat(mathematics.calculate(subset, reverse, 'BBO', 3600, 125)) for name, reverse in (('元方向', False), ('実逆', True))}
            period[axis] = table
            births_result[part]['分割'][axis] = {label: sum(group_name(birth['group'], axis) == label for birth in births_scope) for label in labels}
            assert sum(births_result[part]['分割'][axis].values()) == len(births_scope)
            for name in ('元方向', '実逆'):
                whole = period['全R0'][name]
                for key in ('件数', 'F', 'A', 'N', 'C', 'IFD既知', 'IFD未知'):
                    assert sum(table[label][name][key] for label in labels) == whole[key]; sum_checks += 1
                for key in ('C5利益', 'C5損失絶対', 'C5差引'):
                    total = sum(table[label][name][key] for label in labels if table[label][name]['IFD既知'])
                    assert total == whole[key]; sum_checks += 1
        result[part] = period
    # ----------------------------------------
    # 旧R0同体の独立票を最後に比較する。群分けや計算には使わない。
    baseline = json.loads(PATHS['baseline'].read_bytes())
    assert before['baseline']['sha256'] == '0425f7777d1c61f775d15899ada3ed05f401c5615d55c9a62eae9377388abd73'
    for part in result:
        for side in ('元方向', '実逆'): assert result[part]['全R0'][side] == baseline['再計算'][part][side]
    assert before == {key: {'sha256': sha(path), 'bytes': path.stat().st_size, 'mtime_ns': path.stat().st_mtime_ns} for key, path in PATHS.items()}
    assert sha(MATH_PATH) == MATH_SHA
    proof = {'成功': True, '編集停止': True, '試行': 154, '区分': '固定R0の現在価格とr始値/逆端だけの事後診断',
             '入力': before, 'コードSHA256': sha(Path(__file__)), '独立算術': {'path': MATH_PATH.relative_to(ROOT).as_posix(), 'SHA256': MATH_SHA},
             '全出生の非金融分布': births_result, '取得R0の金融診断': result,
             '群合計R0同体の加法検査数': sum_checks, '全R0は旧独立票の全/前後元逆と同体': True,
             'q0全stream指紋': q0_evidence, '観測全gzip_CRC_解凍指紋': obs_evidence,
             '全入力前後同体': True, '分群は金融読取前に固定/実逆でも元tの群を保持': True,
             '作者logic154/金融124/原因金融算術import': False, '新条件_新q0_入替政策_Raw_追加2場': False,
             '全期間既使用': True, '独立mini1_IFD既知合算で口座ではない': True}
    with output.open('x', encoding='utf-8', newline='\n') as target:
        json.dump(proof, target, ensure_ascii=False, indent=2); target.write('\n')
    print(json.dumps({'成功': True, '群合計検査数': sum_checks, '全出生': len(births), '全取得': len(cases), 'SHA256': sha(output)}, ensure_ascii=False))


if __name__ == '__main__': main()
