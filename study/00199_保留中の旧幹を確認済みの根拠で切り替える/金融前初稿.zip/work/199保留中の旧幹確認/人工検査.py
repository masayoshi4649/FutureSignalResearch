"""199の確認取消・独自受容を自然金融なしで検査する。"""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
import numpy as np
import rules199 as R

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('人工195_for199',R.ROOT/'work/195保留中Tの技術根拠/人工検査.py')
T=importlib.util.module_from_spec(spec);sys.modules[spec.name]=T;spec.loader.exec_module(T)


def fixture(reverse: bool=False,direction: int=1) -> tuple:
    """
    機能: 旧保留中の2番目q0へ非riskの旧幹を追加する。
    引数: reverse(bool)、direction(int)はT方向。
    返り値: tupleは特徴と元350pt/H60要求。
    """
    f,b=T.fixture(reverse,direction);b['birth']['core'][2]=-1 if reverse else 1;b['birth']['branches'][2]=0
    b['mw'][2]=b['fw'][2]=350;b['hi'][2]=1
    return f,b


def main() -> None:
    """
    機能: 因果prefix・鏡像・未来変更、旧対照同体、三方式とLC/未知/resetを照合する。
    引数: なし。
    返り値: None。人工票だけを保存する。
    """
    count=0;checks=[]
    def check(name: str,a: object,b: object) -> None:
        """
        機能: 人工値と期待値を比較する。
        引数: name(str)、a/b(object)。
        返り値: None。不一致時停止する。
        """
        nonlocal count
        a,b=np.asarray(a),np.asarray(b);assert a.shape==b.shape and np.array_equal(a,b),(name,a,b)
        count+=a.size;checks.append({'検査':name,'項目':int(a.size),'不一致':0})
    for reverse in (True,False):
        for direction in (-1,1):
            f,b=fixture(reverse,direction);original=R.build(f,b)
            for stop in range(9):
                pf,pb=T.T.T.T.sliced(f,b,stop);prefix=R.build(pf,pb)
                for identity in original['candidate_ids']:
                    for key,v in T.flat(original['bundles'][identity]).items():
                        check(f'prefix/{reverse}/{direction}/{stop}/{identity}/{key}',T.flat(prefix['bundles'][identity])[key],v[:stop])
            mf,mb=T.T.T.T.sliced(f,b,8);mf.buy_X,mf.sell_X=mf.sell_X.copy(),mf.buy_X.copy()
            p={k:v.copy() for k,v in mf.q0_prices.items()};mf.q0_prices['last']=-p['last'];mf.q0_prices['bid']=-p['ask'];mf.q0_prices['ask']=-p['bid']
            for key in ('core','technical'):mb['birth'][key]*=-1
            mirrored=R.build(mf,mb)
            for identity in original['candidate_ids']:
                for key,v in T.flat(original['bundles'][identity]).items():
                    check(f'鏡像/{reverse}/{direction}/{identity}/{key}',T.flat(mirrored['bundles'][identity])[key],-v if key in ('core','technical') else v)
            for stop in (1,3,6):
                pf,pb=T.T.T.T.sliced(f,b,8);pf.buy_X[stop:]=np.nan;pf.sell_X[stop:]=np.nan;pf.q0_prices['last'][stop:]+=99999
                future=R.build(pf,pb)
                for identity in original['candidate_ids']:
                    for key,v in T.flat(original['bundles'][identity]).items():
                        check(f'未来/{reverse}/{direction}/{stop}/{identity}/{key}',T.flat(future['bundles'][identity])[key][:stop],v[:stop])
            prior=R.G.build(f,b)
            for i,old in enumerate(R.CONTROLS):
                for key,v in T.flat(prior['bundles'][old]).items():
                    check(f'五対照同体/{reverse}/{direction}/{i}/{key}',T.flat(original['bundles'][f'E199_{i:02d}'])[key],v)
    # ----------------------------------------
    f,b=fixture(False);out=R.build(f,b)
    check('旧対照は逆向き旧幹を即時取得',out['bundles']['E199_03']['birth']['core'][2],1)
    for identity in ('E199_05','E199_06','E199_07'):
        check('新確認へ通す/'+identity,out['bundles'][identity]['birth']['core'][2],0)
    check('元C120で順行再開',out['diagnostics']['E199_05']['follow_confirmed'][4],True)
    check('新方向C60で再開',out['diagnostics']['E199_07']['own_confirmed'][4],True)
    check('独自種は新要求',out['diagnostics']['E199_07']['own_from'][4],2)
    check('独自幅を保持',out['bundles']['E199_07']['mw'][4],350)
    check('独自期限を保持',out['bundles']['E199_07']['hi'][4],1)
    f,b=fixture(True);out=R.build(f,b)
    check('同方向ならOPPOSITEは旧動作',out['bundles']['E199_06']['birth']['core'][2],-1)
    check('ALLは同方向も確認',out['bundles']['E199_05']['birth']['core'][2],0)
    # ----------------------------------------
    f,b=fixture(False);b['added'][3]=True;b['birth']['core'][3]=-1;b['birth']['branches'][3]=0;b['mw'][3]=b['fw'][3]=400;b['hi'][3]=3
    out=R.build(f,b)
    for key,v in T.flat(b).items():check('LC優先/'+key,T.flat(out['bundles']['E199_07'])[key][3],v[3])
    check('LCで独自受容reset',out['diagnostics']['E199_07']['own_confirmed'][4],False)
    check('LC後も独自種は保持',out['diagnostics']['E199_07']['own_from'][4],2)
    for name in ('m5_di_difference_to_side','m5_gap_to_side','m1_volume_relative_prior3'):
        f,b=fixture(False);j=f.columns.index(name);f.buy_X[3:,j]=f.sell_X[3:,j]=np.nan;out=R.build(f,b)
        check('独自確認の未知は不成立/'+name,out['diagnostics']['E199_07']['own_confirmed'].any(),False)
    f,b=fixture(False)
    for i in range(3,8):f.q0_meta[i]['q0_time']=f.q0_meta[2]['q0_time'];f.q0_prices['time'][i]=f.q0_prices['time'][2]
    out=R.build(f,b);check('独自確認の同秒不成立',out['diagnostics']['E199_07']['own_confirmed'].any(),False)
    f,b=fixture(False)
    for row in f.q0_meta[3:]:row['session']='別_Day';row['session_index']=1
    out=R.build(f,b);check('場境界で独自種失効',out['diagnostics']['E199_07']['own_active'][3:].any(),False)
    f,b=fixture(False);b['birth']['core'][3]=1;b['birth']['branches'][3]=0;b['mw'][3]=b['fw'][3]=350;b['hi'][3]=1;out=R.build(f,b)
    check('同方向旧要求で期限を延ばさない',out['diagnostics']['E199_07']['own_from'][4],2)
    f,b=fixture(False);b['birth']['core'][3]=-1;b['birth']['branches'][3]=0;b['mw'][3]=b['fw'][3]=350;b['hi'][3]=1;out=R.build(f,b)
    check('新riskで独自種を廃棄',out['diagnostics']['E199_07']['own_active'][3],False)
    check('新riskは従来setupへ',out['diagnostics']['E199_07']['guarded'][3],True)
    proof={'成功':True,'項目':count,'不一致':0,'自然金融未使用':True,'検査':checks,'SourceSHA':hashlib.sha256(Path(R.__file__).read_bytes()).hexdigest()}
    (HERE/'人工確認199.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:proof[k] for k in ('成功','項目','不一致')},ensure_ascii=False))


if __name__=='__main__':main()
