"""195のT判別が元確認を変えず、未来や保有を参照しないことを検査する。"""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
import numpy as np
import rules195 as R

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('人工193_for195',R.ROOT/'work/193構造拡大停止と取得位置/人工検査.py')
T=importlib.util.module_from_spec(spec);sys.modules[spec.name]=T;spec.loader.exec_module(T)


def flat(bundle: dict) -> dict:
    """
    機能: 純入口の配列を比較用に平坦化する。
    引数: bundle(dict)。
    返り値: dict[str,np.ndarray]。
    """
    return {**bundle['birth'],**{k:bundle[k] for k in ('mw','fw','hi','added')}}


def fixture(reverse: bool=False, direction: int=1) -> tuple:
    """
    機能: 193人工例へ各q0で成立するTを加える。
    引数: reverse(bool)、direction(int)はTの方向±1。
    返り値: tupleは特徴と純基準bundle。
    """
    f,b=T.fixture(reverse);b['birth']['technical'][:]=direction;b['birth']['tier'][:]=1
    return f,b


def main() -> None:
    """
    機能: prefix/鏡像/未来変更、条件分離、未知、T固有受容とLCを確認する。
    引数: なし。
    返り値: None。人工結果とSource指紋を保存する。
    """
    count=0;checks=[]
    def check(name: str,a: object,b: object) -> None:
        """
        機能: 人工結果と期待値を照合する。
        引数: name(str)、a/b(object)。
        返り値: None。不一致時停止する。
        """
        nonlocal count
        a,b=np.asarray(a),np.asarray(b);assert a.shape==b.shape and np.array_equal(a,b),(name,a,b)
        count+=a.size;checks.append({'検査':name,'項目':int(a.size),'不一致':0})
    for reverse in (True,False):
        for direction in (-1,1):
            f,b=fixture(reverse,direction);original=R.build(f,b)
            for stop in range(9):
                pf,pb=T.T.T.sliced(f,b,stop);prefix=R.build(pf,pb)
                for identity in original['candidate_ids']:
                    for key,v in flat(original['bundles'][identity]).items():
                        check(f'prefix/{reverse}/{direction}/{stop}/{identity}/{key}',flat(prefix['bundles'][identity])[key],v[:stop])
            mf,mb=T.T.T.sliced(f,b,8);mf.buy_X,mf.sell_X=mf.sell_X.copy(),mf.buy_X.copy()
            p={k:v.copy() for k,v in mf.q0_prices.items()};mf.q0_prices['last']=-p['last'];mf.q0_prices['bid']=-p['ask'];mf.q0_prices['ask']=-p['bid']
            for key in ('core','technical'):mb['birth'][key]*=-1
            mirror=R.build(mf,mb)
            for identity in original['candidate_ids']:
                for key,v in flat(original['bundles'][identity]).items():
                    check(f'鏡像/{reverse}/{direction}/{identity}/{key}',flat(mirror['bundles'][identity])[key],-v if key in ('core','technical') else v)
            for stop in (1,3,6):
                pf,pb=T.T.T.sliced(f,b,8);pf.buy_X[stop:]=np.nan;pf.sell_X[stop:]=np.nan;pf.q0_prices['last'][stop:]+=99999
                future=R.build(pf,pb)
                for identity in original['candidate_ids']:
                    for key,v in flat(original['bundles'][identity]).items():
                        check(f'未来/{reverse}/{direction}/{stop}/{identity}/{key}',flat(future['bundles'][identity])[key][:stop],v[:stop])
            prior=R.R.build(f,b)
            for rule in R.catalog()['rules']:
                identity=rule['id'];old=prior['bundles'][rule.get('base',rule.get('control'))]
                for key,v in flat(old).items():
                    if 'control' in rule or key not in ('technical','tier'):
                        check(f'元core幅期限同体/{reverse}/{direction}/{identity}/{key}',flat(original['bundles'][identity])[key],v)
    # ----------------------------------------
    f,b=fixture(False,1);out=R.build(f,b)
    check('全遮断は保留Tを止める',out['bundles']['E195_05']['birth']['technical'][1:4],[0,0,0])
    check('保留外Tは全遮断でも保持',out['bundles']['E195_05']['birth']['technical'][5:], [1,1,1])
    check('T独自のC60は初回不成立',out['bundles']['E195_07']['birth']['technical'][1],0)
    check('T独自の受容は元C120前に成立',out['bundles']['E195_07']['birth']['technical'][3],1)
    check('元C120のcoreはその後同体',out['bundles']['E195_07']['birth']['core'][4],1)
    check('元方向TはEXPANDで保持',out['bundles']['E195_06']['birth']['technical'][1],1)
    f,b=fixture(False,-1);j=f.columns.index('m15_gap_to_side');f.buy_X[1:,j]=2;f.sell_X[1:,j]=-2;out=R.build(f,b)
    check('構造拡大中の逆側Tは遮断',out['bundles']['E195_06']['birth']['technical'][1:4],[0,0,0])
    f.buy_X[1,j]=f.sell_X[1,j]=np.nan;out=R.build(f,b)
    check('未知の拡大は旧T保持',out['bundles']['E195_06']['birth']['technical'][1],-1)
    check('未知を明示',out['diagnostics']['E195_06']['pending_t_unknown'][1],True)
    # ----------------------------------------
    f,b=fixture(False,1);j=f.columns.index('m1_volume_relative_prior3');f.buy_X[:,j]=f.sell_X[:,j]=.49;out=R.build(f,b)
    check('低量のT受容を拒否',out['diagnostics']['E195_07']['pending_t_allowed'].any(),False)
    f,b=fixture(False,1);j=f.columns.index('m5_di_difference_to_side');f.buy_X[3,j]=np.nan;out=R.build(f,b)
    check('未知DIはT受容不成立',out['bundles']['E195_07']['birth']['technical'][3],0)
    f,b=fixture(False,1)
    for i in range(1,8):f.q0_meta[i]['q0_time']=f.q0_meta[0]['q0_time'];f.q0_prices['time'][i]=f.q0_prices['time'][0]
    out=R.build(f,b);check('同秒Tは成熟しない',out['diagnostics']['E195_07']['pending_t_allowed'].any(),False)
    f,b=fixture(False,1);b['added'][2]=True;b['birth']['core'][2]=1;b['birth']['branches'][2]=0
    b['mw'][2]=b['fw'][2]=400;b['hi'][2]=3;out=R.build(f,b)
    for key in b['birth']:check('LC保持/'+key,out['bundles']['E195_07']['birth'][key][2],b['birth'][key][2])
    check('LCがT受容をリセット',out['bundles']['E195_07']['birth']['technical'][3],0)
    f,b=fixture(False,1)
    for row in f.q0_meta[2:]:row['session']='別_Day';row['session_index']=1
    out=R.build(f,b);check('場境界後は元Tを保持',out['bundles']['E195_05']['birth']['technical'][2:],np.ones(6))
    proof={'成功':True,'項目':count,'不一致':0,'自然金融未使用':True,'検査':checks,'SourceSHA':hashlib.sha256(Path(R.__file__).read_bytes()).hexdigest()}
    (HERE/'人工確認195.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:proof[k] for k in ('成功','項目','不一致')},ensure_ascii=False))


if __name__=='__main__':main()
