"""固定195と固定198を結合し、旧81と追加2を分けて全83場の経路を診断する。"""
from pathlib import Path
import gzip
import json
import sys

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work/183損失安定性'))
import 安定性183 as A


def read(path: Path) -> dict:
    """
    機能: 正式保存済み金融packを読む。
    引数: path(Path)はgzip JSON。
    返り値: dictは金融正本。
    """
    return json.loads(gzip.decompress(path.read_bytes()))


# ----------------------------------------
def main() -> None:
    """
    機能: 同条件の旧81と追加2の台帳・保有を結合し、全83場を再集計する。
    引数: なし。
    返り値: None。元の金融正本・順位・条件を変更しない。
    """
    results=[];short=[]
    for code in ('00','02','03','05','07','08','10'):
        identity=f'E195_{code}__C0_IFD'
        old=read(ROOT/'study/00195_保留中の補完入口を技術根拠で判別する/保存金融'/(identity+'.json.gz'))
        new=read(ROOT/'study/00198_固定195入口を追加二場へ適用する/保存金融'/('NK225198_'+identity+'.json.gz'))
        assert set(old['ledger'])==set(new['ledger'])
        sessions=old['sessions']+new['sessions'];assert len(sessions)==83==len({s['scene'] for s in sessions})
        pack={'id':identity,'ledger':{k:old['ledger'][k]+new['ledger'][k] for k in old['ledger']},
              'sessions':sessions,'positions':old['positions']+new['positions']}
        periods={'旧81':[s['scene'] for s in old['sessions']],'追加2':[s['scene'] for s in new['sessions']]}
        stat=A.evaluate_pack(pack,periods);results.append(stat)
        for band in ('DAY','NIGHT'):
            g=stat['groups'][band];t=g['trades'];s=g['sessions'];p=g['path'];h=g['holding']
            short.append({'候補':identity,'帯':band,'利益':t['known_profit'],'損失':t['known_loss'],
                '既知収支':t['known_net'],'取引':t['all_count'],'赤字取引':t['negative_rate']['negative_count'],
                '未知':t['unknown_count'],'参加場':s['participating_count'],'全場':s['eligible_count'],
                '両中央値':g['both_medians_positive'],'保有下限':h['held_lower_ratio'],
                '場DD既知寄与':p['known_contribution']['max_drawdown']['amount'],
                '赤字場':s['negative_rate']['negative_count'],'最悪5場':g['rolling']['5']['worst_complete']})
    body=json.dumps({'注意':'全83既使用。旧81と追加2を分け、未知を0にしない事後の全経路診断。選択は変更しない。',
        'metrics':results,'short':short},ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n'
    (Path(__file__).parent/'全83の事後診断.json.gz').write_bytes(gzip.compress(body.encode(),mtime=0))
    print(json.dumps(short,ensure_ascii=False))


# ----------------------------------------
if __name__=='__main__':main()
