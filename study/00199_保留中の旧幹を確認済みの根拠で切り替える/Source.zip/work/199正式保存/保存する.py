"""199版2と追加二場診断・全83経路を正式保存し、198へ事後比較を追補する。"""
from pathlib import Path
import importlib.util
import json
import shutil
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('保存195_for199',ROOT/'work/195_198正式保存/保存する.py')
P=importlib.util.module_from_spec(spec);sys.modules[spec.name]=P;spec.loader.exec_module(P)
S=P.S


def main() -> None:
    """
    機能: 199の固定条件・結果・支持と、198の全83追補を保存する。
    引数: なし。
    返り値: None。初稿未金融と版2・各期間の選択を区別する。
    """
    trial=ROOT/'study/00199_保留中の旧幹を確認済みの根拠で切り替える';work=ROOT/'work/199保留中の旧幹確認_未知保持'
    original_read=S.read
    def revised_read(path):
        """
        機能: 共通保存器に199の版2条件を明示して渡す。
        引数: path(Path)。
        返り値: objectは版2又は元の保存値。
        """
        return original_read(trial/'条件_NK225_v2.json') if path==trial/'条件_NK225.json' else original_read(path)
    S.read=revised_read
    S.CASES={199:('199保留中の旧幹確認_未知保持',trial.name,[0,1,2,3,5,6,7,8,10])}
    S.STORIES={199:'''198では旧買いを保留した後、別の旧売りがrisk非該当として無確認に通り、追加Dayが41,000円悪化した。そこで保留中の全旧幹を元C120へ通すALL、逆向きだけ通すOPPOSITE、新方向自身の固定C60受容へ移るOWNを、R1/R2の二背景で比較した。条件は金融前に固定し、自然金融は版2だけへ接続した。

旧80で新6案は参加・両中央値等を保持したが、前48/全80の事前順位先頭は旧19505（当試行02）と旧19111（当試行01）のままだった。R1 ALL05は旧19507より損失を22,077円減らす一方、最悪5場−29,386→−33,001円、取得151→147。11/16Dayでは旧成功売り+33,923円が確認待ちで取得されなくなり、+7,615→−26,308円となった。旧80のOWN新独自確認は1取得−36,077円と支持が弱い。

同じ全11案を追加二場へ適用すると、新6案は全て11/17Day5取得・利益47,846円/損失64,231円/収支−16,385円、Night2取得−3,154円。旧195のDay−58,462円より改善したが、新確認枝自体の取得は0だった。旧825売り−24,077円と後続940売り−9,077円がなくなり、995売り+8,923円へ枠が替わった効果である。

全83場の事後経路では、旧基準よりDayの損失額・赤字取引・DD・最悪窓を改善する有望範囲が残った。195は赤字場を少なくし、19905は損失額・赤字取引をさらに減らす交換で、どちらも完全優位とはしない。全83は既使用であり、未来の安定採用や未見性能とは区別する。'''}
    S.main();S.read=original_read
    text=(trial/'README.md').read_text(encoding='utf-8').replace('[条件](条件_NK225.json)','[条件版2](条件_NK225_v2.json)')
    text+='''
## 全83場を同じ経路で比較した有望範囲

全83は既使用の事後比較。Day42場すべて取得・未知0・両中央値正。旧期間と追加二場の選択票は変更しない。

|条件|Day取得|保有率|利益|損失|収支|赤字取引|赤字場|場末DD|最悪5場収支|
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
|00 旧基準|166|52.26%|2,095,685|1,236,467|859,218|71|11|111,001|−102,233|
|02/03 19505/07|162|51.43%|2,187,300|1,129,774|1,057,526|62|10|65,231|−31,002|
|05 R1 ALL|156|49.46%|2,105,531|1,074,543|1,030,988|59|11|65,231|−33,001|
|07 R1 OWN|153|48.64%|2,056,685|1,064,466|992,219|58|11|65,231|−33,001|

19905は19505/07より損失55,231円・赤字取引3件を減らすが、赤字場が1場増えて収支26,538円を減らす。単場の失敗だけで全面不採用とせず、損失の頻度・深さ・まとまりのどれを改善したか区別する。全期間に対する独立49,698属性と、195/198の7候補に対する独立14,574属性の照合は[監査](監査/)へ。NightはR1新案と旧基準が同体、R2由来のNight悪化も残す。

## 役割混在の診断

R1 ALLで抑える旧幹は全83で20要求、親口座の実取得10件。成功した10/09・10/20・10/23・11/16も、失敗した11/17も短期MACD/RSI・1分進行が実方向と逆だった。一方、5/15分方向が実方向に沿う例があり、短期の反対向きの動きは押戻しにも転換にも現れる。短期一致だけを義務化すると両者を混ぜる。

[全当時特徴](監査/抑制旧幹の全当時特徴199.json.gz)は金融後の原因診断で、特定日の利益を温存する閾値ではない。次は旧要求の狙い、上位方向の持続/失速/伸び過ぎ、価格位置と量・板の根拠を分ける。

## 金融前の版管理

初稿はOWNの新固定種を価格/ATR未知で作れない場合に元の待機状態まで消す問題があった。金融前レビューで発見し、初稿Source/条件/純出生を[金融前初稿](金融前初稿.zip)へ保持。初稿の条件_NK225.jsonは未金融の履歴で、金融正本は[条件_NK225_v2.json](条件_NK225_v2.json)。版2では元pending/既存handoffを保持し、未知で待機理由を解除しない。

人工20,324項目、旧81の初稿/版2純配列差0・該当自然未知0、五対照105区分同体、旧81別算術46,332属性・追加二場4,752属性を確認した。追加二場は[追加二場条件](追加二場条件.json)と[追加二場正本](追加二場/)へ分離保存。新仮説自体が194/198追加二場の診断由来なので、追加二場を未見とは呼ばない。
'''
    (trial/'README.md').write_text(text,encoding='utf-8')
    settings=(trial/'設定と結果.md').read_text(encoding='utf-8').replace('[条件_NK225.json](条件_NK225.json)','[条件_NK225_v2.json](条件_NK225_v2.json)')
    settings+='\n199では保留中旧幹の取消をALL/OPPOSITE/OWNへ分離。OWNは新要求固定価格のC60と5分MA/DI・MACD/RSI・1分構造/量、未知時の元状態保持を版2へ固定。結果は全83事後経路と各期間を区別する。\n'
    (trial/'設定と結果.md').write_text(settings,encoding='utf-8')
    P.add_test_fixtures(trial)
    with zipfile.ZipFile(trial/'Source.zip','a',zipfile.ZIP_DEFLATED) as z:
        path=ROOT/'work/195保留中Tの技術根拠/人工検査.py'
        if path.relative_to(ROOT).as_posix() not in z.namelist():z.write(path,path.relative_to(ROOT).as_posix())
    first=ROOT/'work/199保留中の旧幹確認'
    with zipfile.ZipFile(trial/'金融前初稿.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(first.iterdir()):
            if p.is_file() and not p.name.endswith('.txt'):z.write(p,p.relative_to(ROOT).as_posix())
        z.write(trial/'条件_NK225.json',(trial/'条件_NK225.json').relative_to(ROOT).as_posix())
    extra=trial/'追加二場';extra.mkdir(exist_ok=True);extra_work=ROOT/'work/199追加二場の固定診断'
    for name in ('安定性199追加.json.gz','対照同体199追加.json','全純入口の封印.json','金融開始前固定.json'):
        shutil.copy2(extra_work/name,extra/name)
    (extra/'保存金融').mkdir(exist_ok=True)
    for p in (extra_work/'金融正本').glob('*.json.gz'):shutil.copy2(p,extra/'保存金融'/p.name)
    with zipfile.ZipFile(extra/'純入口.zip','w',zipfile.ZIP_DEFLATED) as z:
        for name in ('追加二場純出生.npz','追加二場純診断.json.gz'):
            p=extra_work/name;z.write(p,p.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(trial/'Source.zip','a',zipfile.ZIP_DEFLATED) as z:
        for p in (extra_work/'固定適用199追加.py',ROOT/'work/198全期間比較/集計.py',Path(__file__)):
            if p.relative_to(ROOT).as_posix() not in z.namelist():z.write(p,p.relative_to(ROOT).as_posix())
    P.manifest(trial,{'追加正式化Source':S.ref(Path(__file__)),'金融正本条件':'条件_NK225_v2.json','初稿金融未接続':True})
    # ----------------------------------------
    trial198=ROOT/'study/00198_固定195入口を追加二場へ適用する'
    shutil.copy2(ROOT/'work/198全期間比較/全83の事後診断.json.gz',trial198/'全83の事後診断.json.gz')
    shutil.copy2(ROOT/'work/199結果診断/195と198全83の独立照合.json',trial198/'監査/全83独立照合.json')
    text=(trial198/'README.md').read_text(encoding='utf-8')
    text+='''
## 固定195と合わせた全83場の事後経路

追加Dayだけでは195新案が悪化したが、旧81と同じ条件で結合するとDay全42場取得・未知0・両中央値正を保ち、19505/07は162取得・保有51.43%、利益2,187,300円/損失1,129,774円/収支+1,057,526円となった。旧基準は166取得・損失1,236,467円・収支+859,218円。

赤字取引71→62、赤字場11→10、場末DD111,001→65,231円、最悪5場−102,233→−31,002円。全経路では損失安定性の改善があり、追加Day一場の悪化だけで全面不採用とはしない。ただし195の193比の変更効果が一場に集中する点、追加二場の新条件選択ではない点、全83既使用は保持する。

[全83事後診断](全83の事後診断.json.gz)は7候補を同体結合し、独立14,574属性を[照合](監査/全83独立照合.json)。旧順位票・既存金融・固定条件は変更しない。再集計と独立確認のSourceは[199の保存Source](../00199_保留中の旧幹を確認済みの根拠で切り替える/Source.zip)に同梱した。
'''
    (trial198/'README.md').write_text(text,encoding='utf-8');P.manifest(trial198,{'全83追補Source':S.ref(Path(__file__))})
    print('199正式化、198全83追補完了')


if __name__=='__main__':main()
