"""199版2で封印した全11案を、追加二場へ条件変更なく適用する。"""
from pathlib import Path
from datetime import datetime,timezone
import argparse
import gzip
import hashlib
import json
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
TRIAL=ROOT/'study/00199_保留中の旧幹を確認済みの根拠で切り替える'
SELECTION=TRIAL/'旧81順位と追加二場固定適用.json'
for folder in ('work/194追加二場','work/199保留中の旧幹確認_未知保持','work/181反省を分解した改善','work/183損失安定性'):
    sys.path.insert(0,str(ROOT/folder))
import rules199 as R
import 実行199 as U
import NK純接続194 as N
import NK金融接続194 as NF
import 集計181 as A
import 安定性183 as S


def read(path: Path) -> object:
    """
    機能: 固定JSON/gzipを読み込む。
    引数: path(Path)。
    返り値: object。
    """
    data=path.read_bytes();return json.loads(gzip.decompress(data) if path.suffix=='.gz' else data)


def refs() -> list:
    """
    機能: 適用Sourceと既封印条件・入力の指紋を集める。
    引数: なし。
    返り値: list[dict]は内容指紋。
    """
    paths=[Path(__file__),Path(R.__file__),Path(N.__file__),Path(NF.__file__),SELECTION,
        TRIAL/'条件_NK225_v2.json',
        ROOT/'work/199保留中の旧幹確認_未知保持/全純入口の封印.json',
        N.DEST/'固定基準の純接続/純接続完了194.json']
    for module in list(sys.modules.values()):
        filename=getattr(module,'__file__',None)
        if filename:
            path=Path(filename).resolve()
            if path.suffix=='.py' and path.is_relative_to(ROOT) and 'site-packages' not in path.parts:paths.append(path)
    return [U.ref(p) for p in sorted(set(paths))]


def pure() -> None:
    """
    機能: 全11候補の追加二場純判断と固定条件を金融前に保存する。
    引数: なし。
    返り値: None。選択を取引成績で変えない。
    """
    selected=read(SELECTION);ids=selected['追加二場固定適用候補']
    assert ids==[f'E199_{i:02d}' for i in range(11)]
    p=N.load_pure_leg();p['features'].q0_prices=N.load_q0(p)
    built=R.build(p['features'],p['baselines']['全期_J035'],ids);payload={}
    for identity,bundle in built['bundles'].items():
        for k in ('mw','fw','hi','added'):payload[identity+'__'+k]=bundle[k]
        for k,v in bundle['birth'].items():payload[identity+'__birth__'+k]=v
    target=HERE/'追加二場純出生.npz';assert not target.exists();np.savez_compressed(target,**payload)
    U.save(HERE/'追加二場純診断.json.gz',built['diagnostics'])
    condition={'試行':199,'UTC':datetime.now(timezone.utc).isoformat(),'候補':ids,'選択根拠':selected,
        '入力':list(N.SCENES),'金融前の純封印':True,'旧81封印後の条件変更なし':True,
        '閲覧時計':'199は194/198の追加二場診断から作った新仮説。旧81全純判断を封印して金融を計算し、そのまま全11案を追加二場へ適用。全83既使用。',
        '金融':'193/195の固定単純IFD。元幅期限、mini1枚、往復手数料77円＋滑り10pt、実BBO。保有予約合計1、終了15分前。',
        'Source':refs(),'純出生':U.ref(target),'純診断':U.ref(HERE/'追加二場純診断.json.gz')}
    U.save(TRIAL/'追加二場条件.json',condition)
    U.save(HERE/'全純入口の封印.json',{'金融前':True,'条件':U.ref(TRIAL/'追加二場条件.json')})
    print(json.dumps({'純封印':True,'候補':ids},ensure_ascii=False),flush=True)


def finance() -> None:
    """
    機能: 固定済み純入口を194の共用金融へ接続して全11案を計算する。
    引数: なし。
    返り値: None。金融pack・安定性・対照同体を保存する。
    """
    condition=read(TRIAL/'追加二場条件.json');seal=read(HERE/'全純入口の封印.json')
    assert seal['条件']==U.ref(TRIAL/'追加二場条件.json')
    assert all(U.ref(ROOT/r['path'])==r for r in condition['Source']+[condition['純出生'],condition['純診断']])
    marker=HERE/'金融開始前固定.json';assert not marker.exists()
    U.save(marker,{'条件':seal['条件'],'UTC':datetime.now(timezone.utc).isoformat()})
    p=N.load_pure_leg();context=NF.load_unvalued_context(p)['context'];context=NF.attach_financial(context)['context']
    allpacks=[];metrics=[];checks=[]
    with np.load(HERE/'追加二場純出生.npz',allow_pickle=False) as raw:
        for identity in condition['候補']:
            bundle={k:raw[identity+'__'+k].copy() for k in ('mw','fw','hi','added')}
            bundle['birth']={k:raw[identity+'__birth__'+k].copy() for k in ('core','branches','technical','tier')}
            policy={'id':'NK225199_'+identity+'__C0_IFD','entry':identity,'exit':'C0_IFD'}
            pack=A.pack(context,bundle,policy,'追加2');U.save(HERE/'金融正本'/(pack['id']+'.json.gz'),pack)
            metrics.append(S.evaluate_pack(pack,{'追加2':list(N.SCENES)}));allpacks.append(pack)
            if identity in ('E199_00','E199_01','E199_02','E199_03','E199_04'):
                old={'E199_00':'E195_00','E199_01':'E195_02','E199_02':'E195_05','E199_03':'E195_07','E199_04':'E195_10'}[identity]
                prior=read(ROOT/'work/198固定195の追加二場/金融正本'/('NK225198_'+old+'__C0_IFD.json.gz'))
                for key in ('ledger','sessions','positions','evidence','periods','selection','engine'):
                    assert pack[key]==prior[key],(identity,key);checks.append([identity,key])
            print(json.dumps({'id':pack['id'],**A.short(pack['evidence'])},ensure_ascii=False),flush=True)
    U.save(HERE/'安定性199追加.json.gz',{'metrics':metrics})
    U.save(HERE/'対照同体199追加.json',{'成功':True,'198対照':checks,'Source不変':all(U.ref(ROOT/r['path'])==r for r in condition['Source'])})


def main() -> None:
    """
    機能: 純封印と金融適用を別段階で実行する。
    引数: CLI --pure/--financeのいずれか。
    返り値: None。
    """
    parser=argparse.ArgumentParser();group=parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--pure',action='store_true');group.add_argument('--finance',action='store_true');args=parser.parse_args()
    pure() if args.pure else finance()


if __name__=='__main__':main()
