"""抑制した旧幹の当時特徴を全件保存し、短期反発と中期背景を区別する。"""
from pathlib import Path
import importlib.util
import sys
import numpy as np
import 旧幹の切替と取得を分解する as D

ROOT=D.ROOT;HERE=Path(__file__).parent
sys.path.insert(0,str(ROOT/'work/194追加二場'))
import NK純接続194 as N


def main() -> None:
    """
    機能: R1全確認の抑制旧幹を、親口座の取得有無と全当時特徴へ接続する。
    引数: なし。
    返り値: None。損益後の診断票であり、新条件の設定ではない。
    """
    rows=[]
    for leg in ('旧73','追加7','本日1','追加2'):
        work=D.BASE if leg!='追加2' else ROOT/'work/199追加二場の固定診断'
        pure=D.C.load_pure_leg(leg) if leg!='追加2' else N.load_pure_leg();f=pure['features']
        diag=D.read(work/(leg+'_純成立診断.json.gz' if leg!='追加2' else '追加二場純診断.json.gz'))['E199_05']
        rawpath=work/(leg+'_新入口.npz' if leg!='追加2' else '追加二場純出生.npz')
        parent=D.read(work/'期間別'/leg/'E199_03__C0_IFD.json.gz') if leg!='追加2' else D.read(work/'金融正本/NK225199_E199_03__C0_IFD.json.gz')
        acquired={r['event']:r for r in D.rows(parent)}
        cols=[c['name'] if isinstance(c,dict) else c for c in f.columns]
        with np.load(rawpath,allow_pickle=False) as raw:directions=raw['E199_00__birth__core'].copy()
        for i in np.flatnonzero(diag['redirected_core']):
            i=int(i);sign=int(directions[i]);assert sign in (-1,1);x=f.buy_X[i] if sign==1 else f.sell_X[i]
            values={k:float(x[j]) if np.isfinite(x[j]) else None for j,k in enumerate(cols)}
            rows.append({'期間':leg,'event':i,'q0':f.q0_meta[i],'方向':sign,'保留開始':diag['redirected_from'][i],
                '旧親口座の実取得':acquired.get(i),'当時の実方向特徴':values})
    D.save(HERE/'抑制旧幹の全当時特徴199.json.gz',{'注意':'金融後の原因診断。旧取得損益と当時特徴を結合するが、特定日の利益温存閾値を定義しない。',
        '仮説':'旧幹の短期逆向き勢いは、失敗した反転だけでなく上位背景に沿う押戻しも含み得る。一律の順勢い回復待ちでは異なる取得役割を混同する。',
        'rows':rows})
    spec=importlib.util.spec_from_file_location('独立183_for199追加',ROOT/'work/183損失安定性/新候補の集計を独立検査する.py')
    V=importlib.util.module_from_spec(spec);sys.modules[spec.name]=V;spec.loader.exec_module(V)
    work=ROOT/'work/199追加二場の固定診断';count=0
    for state in D.read(work/'安定性199追加.json.gz')['metrics']:
        pack=D.read(work/'金融正本'/(state['id']+'.json.gz'));count+=V.verify(pack,state)
    D.save(HERE/'追加二場独立確認199.json',{'成功':True,'照合項目':count,'検査SourceSHA':D.hashlib.sha256(Path(V.__file__).read_bytes()).hexdigest()})
    print({'抑制旧幹':len(rows),'親実取得':sum(r['旧親口座の実取得'] is not None for r in rows),'追加二場独立照合':count})


if __name__=='__main__':main()
