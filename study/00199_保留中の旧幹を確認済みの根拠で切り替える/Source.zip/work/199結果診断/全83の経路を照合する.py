"""195/198の全83事後診断を独立照合し、199も同じ全経路で比較する。"""
from pathlib import Path
import copy
import importlib.util
import sys
import json
import gzip
import hashlib
import 旧幹の切替と取得を分解する as D

ROOT=D.ROOT;HERE=Path(__file__).parent
sys.path.insert(0,str(ROOT/'work/181反省を分解した改善'))
sys.path.insert(0,str(ROOT/'work/183損失安定性'))
import 集計181 as A
import 安定性183 as S
spec=importlib.util.spec_from_file_location('独立183_for全83',ROOT/'work/183損失安定性/新候補の集計を独立検査する.py')
V=importlib.util.module_from_spec(spec);sys.modules[spec.name]=V;spec.loader.exec_module(V)


def combine(old: dict,new: dict) -> dict:
    """
    機能: 同条件の旧81と追加2をIDだけ正規化して再集計する。
    引数: old/new(dict)。
    返り値: dictは全83場の口座pack。元正本を変更しない。
    """
    new=copy.deepcopy(new);new['id']=old['id'];pack=A.combine([old,new])
    pack['periods']['旧81']=old['evidence'];pack['periods']['追加2']=new['evidence']
    assert len(pack['sessions'])==83
    return pack


def main() -> None:
    """
    機能: rootの固定195全経路を独立確認し、199全11案を同じ全83尺度で追加する。
    引数: なし。
    返り値: None。旧選択・条件・各期間の正本は変更しない。
    """
    original=ROOT/'work/198全期間比較/全83の事後診断.json.gz'
    body=D.read(original);checks=[]
    for state in body['metrics']:
        identity=state['id']
        old=D.read(ROOT/'study/00195_保留中の補完入口を技術根拠で判別する/保存金融'/(identity+'.json.gz'))
        new=D.read(ROOT/'study/00198_固定195入口を追加二場へ適用する/保存金融'/('NK225198_'+identity+'.json.gz'))
        pack=combine(old,new);checks.append({'候補':identity,'照合':V.verify(pack,state)})
    D.save(HERE/'195と198全83の独立照合.json',{'成功':True,'候補':checks,'照合項目':sum(v['照合'] for v in checks),
        '正本SHA':hashlib.sha256(original.read_bytes()).hexdigest(),'検査SourceSHA':hashlib.sha256(Path(V.__file__).read_bytes()).hexdigest()})
    metrics=[];short=[];checks=[]
    for path in sorted((D.BASE/'集約').glob('*.json.gz')):
        old=D.read(path);new=D.read(ROOT/'work/199追加二場の固定診断/金融正本'/('NK225199_'+path.name))
        pack=combine(old,new);scenes=[r['scene'] for r in pack['sessions']]
        periods={'旧81':scenes[:81],'追加2':scenes[81:],'前48':scenes[:48],'後25':scenes[48:73],
            '追加7':scenes[73:80],'本日1':scenes[80:81],'全80':scenes[:80]}
        pack['全80比較']=old['全80比較'];state=S.evaluate_pack(pack,periods);metrics.append(state)
        checks.append({'候補':pack['id'],'照合':V.verify(pack,state)})
        for band in ('DAY','NIGHT'):
            g=state['groups'][band];t=g['trades'];s=g['sessions'];p=g['path'];h=g['holding']
            short.append({'候補':pack['id'],'帯':band,'取得':t['all_count'],'利益':t['known_profit'],'損失':t['known_loss'],
                '既知収支':t['known_net'],'未知':t['unknown_count'],'赤字取引':t['negative_rate']['negative_count'],
                '赤字場':s['negative_rate']['negative_count'],'場':s['eligible_count'],'取得場':s['participating_count'],
                '保有下限':h['held_lower_ratio'],'両中央値':g['both_medians_positive'],
                '場DD':p['known_contribution']['max_drawdown']['amount'],'最悪5場':g['rolling']['5']['worst_known_contribution']})
    D.save(HERE/'全83の事後診断199.json.gz',{'全83既使用':True,'旧選択を変更しない':True,'metrics':metrics,'short':short})
    D.save(HERE/'全83独立確認199.json',{'成功':True,'候補':checks,'照合項目':sum(v['照合'] for v in checks)})
    print(json.dumps(short,ensure_ascii=False))


if __name__=='__main__':main()
