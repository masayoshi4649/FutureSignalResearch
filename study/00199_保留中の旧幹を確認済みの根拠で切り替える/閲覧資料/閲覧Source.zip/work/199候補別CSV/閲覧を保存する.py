"""全83場の候補別CSVを再読検査し、再現資料と案内を保存する。"""
from pathlib import Path
import csv
import hashlib
import io
import json
import math
import shutil
import zipfile

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
OUT=ROOT/'outputs/00199_日経の損失軽減候補'
TRIAL=ROOT/'study/00199_保留中の旧幹を確認済みの根拠で切り替える'


def main() -> None:
    """
    機能: 全CSVの元セル・累計・無取引行・未知を確認し、比較説明を作る。
    引数: なし。
    返り値: None。旧選択と金融結果を変更しない。
    """
    data=json.loads((HERE/'閲覧入力.json').read_text(encoding='utf-8'))
    proof=json.loads((ROOT/'work/199CSV検査/作成確認.json').read_text(encoding='utf-8'))
    cells=0;nulls=0
    for item in proof['files']:
        path=OUT/item['相対path'];raw=path.read_bytes()
        assert hashlib.sha256(raw).hexdigest()==item['sha256']
        rows=list(csv.reader(io.StringIO(raw.decode('utf-8-sig'))))
        table=data['tables'][item['元表']];expected=[table['headers']]+[r for r in table['rows'] if r[0]==item['候補']]
        assert len(rows)==len(expected)
        for actual,source in zip(rows,expected,strict=True):
            assert len(actual)==len(source)
            for a,b in zip(actual,source,strict=True):
                cells+=1
                if b is None:assert a=='';nulls+=1
                elif isinstance(b,(int,float)):assert math.isclose(float(a),b,abs_tol=1e-7)
                else:assert a==b
        for row in rows[1:]:
            assert math.isclose(float(row[3])-float(row[4]),float(row[10]),abs_tol=1e-7)
        if item['元表']!='候補比較':
            cum=0.;complete=True
            for row in rows[1:]:
                cum+=float(row[10]);complete=complete and int(row[8])==0
                assert math.isclose(float(row[11]),cum,abs_tol=1e-7)
                if complete:assert math.isclose(float(row[6]),cum,abs_tol=1e-7)
                else:assert row[6]==''
    assert len(proof['files'])==15 and cells==6300 and nulls>0
    proof.update(CSV全セル再読=cells,未知空欄セル数=nulls,累計算術検査=True,全デイ42と夜間41を保持=True)
    support=TRIAL/'閲覧資料';support.mkdir(exist_ok=True)
    (support/'CSV確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    shutil.copy2(HERE/'閲覧入力.json',support/'閲覧入力.json')
    sources=[HERE/'入力を作る.py',Path(__file__),ROOT/'scripts/損益CSV/候補別に出力する.mjs']
    with zipfile.ZipFile(support/'閲覧Source.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for p in sources:archive.write(p,p.relative_to(ROOT).as_posix())
    index=[{'path':p.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sources]
    (support/'Source索引.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    explanations={'00_旧基準':'旧179の基準。入口の保留・再確認を追加する前の対照。',
        '02_補完制限':'195_05と同体。元方向の圧力が強い旧反転要求を確認待ちにし、その保留中は初参加用Tを止める。',
        '05_旧幹確認':'199_05。補完Tの固有確認に加え、保留中の別の旧幹も固定水準・方向・勢い・量の確認へ通す。'}
    links=[]
    for key,description in explanations.items():
        folder=OUT/('199_'+key)
        text=f'''# 199:{key}

{description}

2026-09-21〜2026-11-17、デイ42・ナイト41の全83セッション。日経mini1枚、ラージBBO代用、片道手数料38.5円＋滑り5pt、往復1,077円。単純IFD、保有/予約合計1、開始待機なし、終了15分前まで。

[集計](集計.csv) / [デイ](デイ.csv) / [ナイト全体](ナイト全体.csv) / [ナイト米国前](ナイト_米前.csv) / [ナイト米国後](ナイト_米後.csv)。

利益・損失は費用後の既知取引を分けた金額。未知を含む場の「収支確定」と、その後の「累計収支確定」は空欄。「既知寄与」は未知を解決した収支ではない。未知5件は全てナイト。無取引の小時間帯も行を残す。累計は候補・帯ごとに0円から計算。

保有時間率は対象の実時間を分母にした下限（0〜1）。終了前15分を除き、予約を保有に数えない。損益は新規取得した帯、保有時間は実際の重なりへ帰属するため、新規0回で保有率が正になる帯もある。

[比較と限界](../README.md) / [研究正本](../../../study/00199_保留中の旧幹を確認済みの根拠で切り替える/README.md)。
'''
        (folder/'README.md').write_text(text,encoding='utf-8')
        links.append(f'[{key}](199_{key}/README.md)')
    text='''# 日経の損失軽減候補・全83場

旧基準と、確認待ちの注文経路を変えた二案を候補別CSVにした。全83場は探索に既使用。将来の安定性を確定する結果ではない。

## デイ42セッションの比較

日経mini1枚・費用後・円。全3案で42場すべてに取得があり、建玉と場収支の両中央値が黒字、デイの金融未知は0。

|候補|利益|損失|収支|赤字取引 / 全取引|赤字場|保有時間率|場末最大DD|
|---|---:|---:|---:|---:|---:|---:|---:|
'''
    for row in data['デイ比較']:
        key=row['候補'].split(':')[1]
        text+=f"|[{key}](199_{key}/README.md)|{row['known_profit']:,.0f}|{row['known_loss']:,.0f}|{row['known_net']:,.0f}|{row['赤字取引']} / {row['all_count']}|{row['赤字場']}|{row['保有率']:.2%}|{row['場DD']:,.0f}|\n"
    text+='''
「02_補完制限」は195_05、「05_旧幹確認」は199_05。02は赤字場を減らし、05は損失総額と赤字取引をさらに減らす交換がある。DDは場末の実現収支から計算し、建玉保有中の最大時価DDとは異なる。保有率は全デイ対象時間の合算であり、各場が一律20%以上という意味ではない。

## ナイトと追加期間の扱い

この3案のナイトは同体。41場・124取得、既知利益1,561,302円/損失759,465円/既知収支801,837円、未知5件、保有時間率下限28.81%。夜間の未確定損益はデイの利益で隠さない。ナイト全体と米国前後は同じ取引の別集計なので合算して重複計上しない。

11/17デイでは02が旧より悪化し、05は旧並みまで戻った。一方11/16では02より05が悪化する。総額だけで完全優位とせず、[個別原因・新枝の支持・旧80と追加区分](../../study/00199_保留中の旧幹を確認済みの根拠で切り替える/README.md)を併読する。旧幹の取引が入れ替わる効果を含み、新しい確認枝だけの利益ではない。

## CSVの列と再現

利益/損失は費用後の既知寄与。確定収支・確定累計の空欄は未知を意味する。既知寄与累計を口座全体の確定利益としない。各候補のデイ42行、ナイト41行を残し、候補を混在させない。

[15CSV・6,300セルの再読照合](../../study/00199_保留中の旧幹を確認済みの根拠で切り替える/閲覧資料/CSV確認.json)。金融を再探索せず、正式保存済みの旧81＋追加2の台帳と、独立照合済みの全83集計から作成した。[再現資源](../../study/00199_保留中の旧幹を確認済みの根拠で切り替える/閲覧資料/README.md)。TOPIXは引き続き別に検証中。
'''
    (OUT/'README.md').write_text(text,encoding='utf-8')
    (support/'README.md').write_text('''# 199の候補別CSV再現

[閲覧入口](../../../outputs/00199_日経の損失軽減候補/README.md)。金融正本・条件・順位は変更せず、全83場の旧基準/195_05同体/199_05を取り出した。[型付き入力](閲覧入力.json)・[照合](CSV確認.json)・[Source](閲覧Source.zip)・[Source索引](Source索引.json)。

ZIPを元の相対構造へ展開して `python -X utf8 work/199候補別CSV/入力を作る.py` を実行する。既存の `scripts/損益CSV/候補別に出力する.mjs` に `--input work/199候補別CSV/閲覧入力.json --output 新規出力先 --proof 新規確認先 --dependencies Codex提供node_modules` を渡す。既存CSVフォルダへ上書きしない。Pythonの入力生成は正式study資源だけを読み、金融を実行しない。Node24.14.0、Codex提供artifact-toolを使用。xlsxは生成しない。

累計未知と既知寄与を分け、保有区間の帯別重なりを正本時間合計へ照合している。15CSVをPython csvで再読し全6,300セル一致、利益−損失と既知収支・累計算術も確認した。元の金融検査は199の監査正本を参照。
''',encoding='utf-8')
    print(json.dumps({'CSV':15,'全セル照合':cells,'未知空欄保持':nulls,'正式保存':True},ensure_ascii=False))


# ----------------------------------------
if __name__=='__main__':main()
