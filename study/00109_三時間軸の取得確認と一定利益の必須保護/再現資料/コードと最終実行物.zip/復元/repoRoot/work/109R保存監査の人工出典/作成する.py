"""停止Entryの既存人工入力helperだけを新しいAPI出典器へ複写する。"""

import hashlib
from pathlib import Path


def main():
    """機能: 3つの入力helperを新しいmain.goへ一度だけ書く。

    引数: なし。返り値: None。停止Entryや金融コードは変更しない。
    """
    own = Path(__file__).resolve().parent
    root = own.parents[1]
    source = root / 'work/三時間軸の入口判定/entry_test.go'
    stop = root / 'work/三時間軸の入口判定/停止.json'
    assert hashlib.sha256(stop.read_bytes()).hexdigest() == '834aedc70a31d5f0d7e2bee9ae6fc9d22d7b3ea726924fed791b2dfec7b283f9'
    text = source.read_text(encoding='utf-8')
    header = '''// Package main は停止純入口の人工Rを公開APIから保存監査へ渡します。
package main

import (
 "encoding/json"
 "flag"
 "fmt"
 "math"
 "os"
 entry "github.com/masayoshi4649/SessionTradeExecuter/threeentry"
 frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
)

const epoch = 100000.0
var widths = [3]int{300,900,1800}

// value は人工の既知値を作ります。
//
// 引数: v(float64)は値。返り値: frame.Valueは既知値です。
func value(v float64) frame.Value { return frame.Value{Known:true,Value:v} }

'''
    parts = []
    for name in ('artificialPivot', 'artificialSnapshot', 'transform'):
        begin = text.index('// ' + name + ' は')
        end = text.index('\n// ', text.index('func ' + name + '(', begin))
        parts.append(text[begin:end])
    tail = '''

type Step struct {
 Snapshot frame.Snapshot `json:"snapshot"`
 Candidates []entry.Candidate `json:"candidates"`
 Assessment entry.BatchAssessment `json:"assessment"`
}
type Result struct {
 Side int `json:"side"`
 Steps []Step `json:"steps"`
}

// path は停止純入口の既存人工Rを公開AssessBatchだけで評価します。
//
// 引数: mirror(bool)は符号反転。返り値: Result/errorは全公開入力と返り値又は失敗です。
func path(mirror bool) (Result,error) {
 side:=1
 if mirror { side=-1 }
 result:=Result{Side:side,Steps:[]Step{}}
 state:=entry.NewEntryState()
 for _,end:=range []float64{3600,3900,4200,4500} {
  s:=transform(artificialSnapshot(end,true),mirror,false)
  next,out,err:=entry.AssessBatch(state,s,nil,entry.EntryE1)
  if err!=nil { return result,err }
  state=next
  result.Steps=append(result.Steps,Step{s,nil,out})
 }
 bars:=[]frame.OHLC{{Open:92,High:95,Low:89,Close:89.5},{Open:90,High:95,Low:89.5,Close:93},{Open:94,High:102,Low:92,Close:101}}
 for i,o:=range bars {
  s:=artificialSnapshot(4800+300*float64(i),true)
  s.Scales[0].Current.OHLC=o
  s=transform(s,mirror,false)
  price:=101.0
  if mirror { price=199 }
  candidates:=[]entry.Candidate{{ID:fmt.Sprintf("1|人工Source|R%d",side),Side:side,At:s.AsOf,EntryQuote:price,Quantity:3}}
  next,out,err:=entry.AssessBatch(state,s,candidates,entry.EntryE1)
  if err!=nil { return result,err }
  state=next
  if len(out.Decisions)!=1 || out.Decisions[0].Allowed!=(i==2) { return result,fmt.Errorf("人工R三段の採否差") }
  if i==2 {
   a:=out.Decisions[0]
   if a.Role!=entry.Reversal || a.Structure.Active || a.Structure.Phase!="確認済み" || a.Structure.Event!="反対側突破" { return result,fmt.Errorf("停止純入口のR型差") }
  }
  result.Steps=append(result.Steps,Step{s,candidates,out})
 }
 return result,nil
}

// main は人工値と公開API結果だけを新規JSONへ出します。
//
// 引数: --out(string)は未使用ファイル。返り値: なし。不正時はpanicします。
func main() {
 target:=flag.String("out","","未使用人工JSON")
 flag.Parse()
 if *target=="" { panic("未使用出力先が必要") }
 a,err:=path(false);if err!=nil {panic(err)}
 b,err:=path(true);if err!=nil {panic(err)}
 value:=struct {
  Version int `json:"version"`
  Scope string `json:"scope"`
  Stop string `json:"stopped_entry_sha256"`
  Results []Result `json:"results"`
 }{1,"停止Entryの人工入力→公開AssessBatchの返り値。CSV/市場/Actor/CoreのR金融再走ではない","834aedc70a31d5f0d7e2bee9ae6fc9d22d7b3ea726924fed791b2dfec7b283f9",[]Result{a,b}}
 data,err:=json.MarshalIndent(value,"","  ");if err!=nil {panic(err)}
 f,err:=os.OpenFile(*target,os.O_WRONLY|os.O_CREATE|os.O_EXCL,0600);if err!=nil {panic(err)}
 defer f.Close()
 if _,err=f.Write(append(data,'\\n'));err!=nil {panic(err)}
 fmt.Println("正規純Rの両方向を新規保存")
}
'''
    with (own / 'main.go').open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(header + '\n\n'.join(parts) + tail)


if __name__ == '__main__':
    main()
