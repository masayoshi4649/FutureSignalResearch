// Package main は停止純入口の人工Rを公開APIから保存監査へ渡します。
package main

import (
	"encoding/json"
	"flag"
	"fmt"
	entry "github.com/masayoshi4649/SessionTradeExecuter/threeentry"
	frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
	"math"
	"os"
)

const epoch = 100000.0

var widths = [3]int{300, 900, 1800}

// value は人工の既知値を作ります。
//
// 引数: v(float64)は値。返り値: frame.Valueは既知値です。
func value(v float64) frame.Value { return frame.Value{Known: true, Value: v} }

// artificialPivot は連続5足の証拠を持つ確認済み5分pivotを作ります。
//
// 引数: kind(string)、price(float64)は高安の種類と人工価格です。
// 返り値: frame.Pivotは3900秒足で確認、3960秒公表の事前線です。
func artificialPivot(kind string, price float64) frame.Pivot {
	refs := [5]frame.BarRef{}
	for i := range refs {
		end := epoch + 2700 + float64(i)*300
		refs[i] = frame.BarRef{ID: fmt.Sprintf("人工pivot_%d", i), Start: end - 300, End: end, PublishedAt: end + 60}
	}
	return frame.Pivot{Known: true, Kind: kind, Price: price, CenterID: refs[2].ID, CenterStart: refs[2].Start, CenterEnd: refs[2].End, ConfirmID: refs[4].ID, ConfirmEnd: refs[4].End, PublishedAt: refs[4].PublishedAt, Left: [2]frame.BarRef{refs[0], refs[1]}, Right: [2]frame.BarRef{refs[3], refs[4]}}
}

// artificialSnapshot は価格・指標が未使用市場に依存しない公開値を作ります。
//
// 引数: end(float64)、reversal(bool)は場内の5分終了と上位逆向きの指定です。
// 返り値: frame.Snapshotは各足終了60秒後に利用する値copyです。
func artificialSnapshot(end float64, reversal bool) frame.Snapshot {
	s := frame.Snapshot{Session: frame.Session{ID: "人工場", Contract: "人工限月", Start: epoch, End: epoch + 86400, EOF: epoch + 86000}, AsOf: epoch + end + 60, ReplayObservedAt: epoch + end + 60, HasObserved: true, RecordOrdinal: uint64(end + 60)}
	for i, width := range widths {
		last := math.Floor(end/float64(width)) * float64(width)
		step := last / float64(width)
		tc := frame.Technical{HistoryBars: 100 + uint64(step), EMA8: value(102 + step*.2), EMA21: value(100 + step*.1), PreviousEMA8: value(102 + (step-1)*.2), PreviousEMA21: value(100 + (step-1)*.1), ATR: value(10), PreviousATR: value(10), TR: value(10), RSI: value(52 + step*.2), PreviousRSI: value(52 + (step-1)*.2), Histogram: value(step * .1), PreviousHistogram: value((step - 1) * .1)}
		if reversal && width != 300 {
			tc.EMA8 = value(98 - step*.2)
			tc.EMA21 = value(100 - step*.1)
			tc.PreviousEMA8 = value(98 - (step-1)*.2)
			tc.PreviousEMA21 = value(100 - (step-1)*.1)
			tc.RSI = value(42 + step*.2)
			tc.PreviousRSI = value(42 + (step-1)*.2)
			tc.Histogram = value(-5 + step*.1)
			tc.PreviousHistogram = value(-5 + (step-1)*.1)
		}
		tc.Gap = value(tc.EMA8.Value - tc.EMA21.Value)
		tc.EMA8Delta = value(tc.EMA8.Value - tc.PreviousEMA8.Value)
		tc.EMA21Delta = value(tc.EMA21.Value - tc.PreviousEMA21.Value)
		tc.GapATR = value(tc.Gap.Value / 10)
		tc.EMA8DeltaATR = value(tc.EMA8Delta.Value / 10)
		tc.EMA21DeltaATR = value(tc.EMA21Delta.Value / 10)
		ohlc := frame.OHLC{Open: 105, High: 110, Low: 90, Close: 100}
		if width == 300 {
			ohlc = frame.OHLC{Open: 99, High: 100, Low: 98, Close: 99}
		}
		f := frame.Frame{ID: fmt.Sprintf("人工_%d_%g", width, last), SessionID: s.Session.ID, Contract: s.Session.Contract, WidthSeconds: width, Start: epoch + last - float64(width), End: epoch + last, NominalAvailable: epoch + last + 60, AvailableAt: epoch + last + 60, ObservedAt: epoch + last + 60, DeliveryAt: epoch + last + 60, RecordOrdinal: uint64(last), PublicationOrdinal: uint64(last / float64(width)), PriceKnown: true, VolumeKnown: true, OHLC: ohlc, Volume: 100, Technical: tc}
		if width == 300 && last > 3900 {
			f.PriorHigh = artificialPivot("high", 100)
			f.PriorLow = artificialPivot("low", 80)
		}
		if width == 300 && last == 3900 {
			f.NewHigh = artificialPivot("high", 100)
			f.NewLow = artificialPivot("low", 80)
		}
		s.Scales[i] = frame.ScaleSnapshot{WidthSeconds: width, HasCurrent: true, Fresh: true, Current: f}
	}
	return s
}

// transform は人工鏡像と量未知を、全履歴へ一貫して適用します。
//
// 引数: s(frame.Snapshot)、mirror/unknownVolume(bool)は元値と変換指定です。
// 返り値: frame.Snapshotは原入力へaliasしない値です。
func transform(s frame.Snapshot, mirror, unknownVolume bool) frame.Snapshot {
	for i := range s.Scales {
		f := &s.Scales[i].Current
		if unknownVolume {
			f.VolumeKnown = false
		}
		if !mirror {
			continue
		}
		o := f.OHLC
		f.OHLC = frame.OHLC{Open: 300 - o.Open, High: 300 - o.Low, Low: 300 - o.High, Close: 300 - o.Close}
		tc := &f.Technical
		for _, v := range []*frame.Value{&tc.EMA8, &tc.EMA21, &tc.PreviousEMA8, &tc.PreviousEMA21} {
			if v.Known {
				v.Value = 300 - v.Value
			}
		}
		for _, v := range []*frame.Value{&tc.Gap, &tc.GapATR, &tc.EMA8Delta, &tc.EMA21Delta, &tc.EMA8DeltaATR, &tc.EMA21DeltaATR, &tc.Histogram, &tc.PreviousHistogram, &tc.CrossSessionJump} {
			if v.Known {
				v.Value = -v.Value
			}
		}
		for _, v := range []*frame.Value{&tc.RSI, &tc.PreviousRSI} {
			if v.Known {
				v.Value = 100 - v.Value
			}
		}
		flip := func(p frame.Pivot) frame.Pivot {
			if p.Known {
				p.Price = 300 - p.Price
				if p.Kind == "high" {
					p.Kind = "low"
				} else {
					p.Kind = "high"
				}
			}
			return p
		}
		f.PriorHigh, f.PriorLow = flip(f.PriorLow), flip(f.PriorHigh)
		f.NewHigh, f.NewLow = flip(f.NewLow), flip(f.NewHigh)
	}
	return s
}

type Step struct {
	Snapshot   frame.Snapshot        `json:"snapshot"`
	Candidates []entry.Candidate     `json:"candidates"`
	Assessment entry.BatchAssessment `json:"assessment"`
}
type Result struct {
	Side  int    `json:"side"`
	Steps []Step `json:"steps"`
}

// path は停止純入口の既存人工Rを公開AssessBatchだけで評価します。
//
// 引数: mirror(bool)は符号反転。返り値: Result/errorは全公開入力と返り値又は失敗です。
func path(mirror bool) (Result, error) {
	side := 1
	if mirror {
		side = -1
	}
	result := Result{Side: side, Steps: []Step{}}
	state := entry.NewEntryState()
	for _, end := range []float64{3600, 3900, 4200, 4500} {
		s := transform(artificialSnapshot(end, true), mirror, false)
		next, out, err := entry.AssessBatch(state, s, nil, entry.EntryE1)
		if err != nil {
			return result, err
		}
		state = next
		result.Steps = append(result.Steps, Step{s, nil, out})
	}
	bars := []frame.OHLC{{Open: 92, High: 95, Low: 89, Close: 89.5}, {Open: 90, High: 95, Low: 89.5, Close: 93}, {Open: 94, High: 102, Low: 92, Close: 101}}
	for i, o := range bars {
		s := artificialSnapshot(4800+300*float64(i), true)
		s.Scales[0].Current.OHLC = o
		s = transform(s, mirror, false)
		price := 101.0
		if mirror {
			price = 199
		}
		candidates := []entry.Candidate{{ID: fmt.Sprintf("1|人工Source|R%d", side), Side: side, At: s.AsOf, EntryQuote: price, Quantity: 3}}
		next, out, err := entry.AssessBatch(state, s, candidates, entry.EntryE1)
		if err != nil {
			return result, err
		}
		state = next
		if len(out.Decisions) != 1 || out.Decisions[0].Allowed != (i == 2) {
			return result, fmt.Errorf("人工R三段の採否差")
		}
		if i == 2 {
			a := out.Decisions[0]
			if a.Role != entry.Reversal || a.Structure.Active || a.Structure.Phase != "確認済み" || a.Structure.Event != "反対側突破" {
				return result, fmt.Errorf("停止純入口のR型差")
			}
		}
		result.Steps = append(result.Steps, Step{s, candidates, out})
	}
	return result, nil
}

// main は人工値と公開API結果だけを新規JSONへ出します。
//
// 引数: --out(string)は未使用ファイル。返り値: なし。不正時はpanicします。
func main() {
	target := flag.String("out", "", "未使用人工JSON")
	flag.Parse()
	if *target == "" {
		panic("未使用出力先が必要")
	}
	a, err := path(false)
	if err != nil {
		panic(err)
	}
	b, err := path(true)
	if err != nil {
		panic(err)
	}
	value := struct {
		Version int      `json:"version"`
		Scope   string   `json:"scope"`
		Stop    string   `json:"stopped_entry_sha256"`
		Results []Result `json:"results"`
	}{1, "停止Entryの人工入力→公開AssessBatchの返り値。CSV/市場/Actor/CoreのR金融再走ではない", "834aedc70a31d5f0d7e2bee9ae6fc9d22d7b3ea726924fed791b2dfec7b283f9", []Result{a, b}}
	data, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		panic(err)
	}
	f, err := os.OpenFile(*target, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if err != nil {
		panic(err)
	}
	defer f.Close()
	if _, err = f.Write(append(data, '\n')); err != nil {
		panic(err)
	}
	fmt.Println("正規純Rの両方向を新規保存")
}
