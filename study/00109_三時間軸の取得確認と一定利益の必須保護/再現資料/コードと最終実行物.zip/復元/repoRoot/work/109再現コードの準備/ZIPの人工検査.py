"""ZIP全entry検査の小人工と危険名拒否を確認する。"""

import copy
from pathlib import Path
import tempfile
import unittest

import 収集する as C
import ZIPを正式保存する as Z


class ZIP検査(unittest.TestCase):
    """安全名と全値の一致を確認する。"""

    def test_全entryのSHAとCRCと改変検出(self):
        """機能: 小人工1ファイルを圧縮・再読し期待SHA改変を拒否する。

        引数: self(ZIP検査)。返り値: None。
        """
        with tempfile.TemporaryDirectory(prefix='ZIP人工_', dir=C.OWN) as name:
            own = Path(name).resolve()
            self.assertTrue(own.is_relative_to(C.OWN))
            source = own / 'code.py'
            source.write_text('人工コードだけ\n', encoding='utf-8')
            registry = C.Registry()
            row = registry.file(source, 'ZIPの人工')
            path = own / '人工.zip'
            Z.write_zip(path, [row])
            checked = Z.verify_zip(path, [row])
            self.assertEqual(len(checked), 1)
            self.assertEqual(checked[row['location']['entry']]['sha256'], C.sha(source))
            broken = copy.deepcopy(row)
            broken['sha256'] = '0' * 64
            with self.assertRaises(ValueError):
                Z.verify_zip(path, [broken])

    def test_危険名とWindows同名を拒否する(self):
        """機能: 遡り/絶対path/drive/表記違い重複を保存前に拒否する。

        引数: self(ZIP検査)。返り値: None。
        """
        self.assertTrue(Z.safe('復元/repoRoot/work/人工.py'))
        for name in ('../x.py', '/absolute.py', 'C:/x.py', 'folder\\x.py'):
            self.assertFalse(Z.safe(name))
        with tempfile.TemporaryDirectory(prefix='ZIP人工_', dir=C.OWN) as name:
            own = Path(name).resolve()
            self.assertTrue(own.is_relative_to(C.OWN))
            rows = [{'location': {'entry': 'folder/A.py'}}, {'location': {'entry': 'folder/a.py'}}]
            with self.assertRaises(ValueError):
                Z.write_zip(own / '出力されない.zip', rows)


if __name__ == '__main__':
    unittest.main(verbosity=2)
