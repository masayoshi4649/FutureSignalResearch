"""再現collectorの対象制限と安全な所在を人工小ファイルで確認する。"""

from pathlib import Path
import tempfile
import unittest

import 収集する as C


class 収集検査(unittest.TestCase):
    """原位置/同体/種別の制限を検査する。"""

    def test_同SHAだけを重複統合する(self):
        """機能: 同pathの重複は役割だけ追加し、改変後は拒否する。

        引数: self(収集検査)。返り値: None。
        """
        with tempfile.TemporaryDirectory(prefix='人工_', dir=C.OWN) as name:
            own = Path(name).resolve()
            self.assertTrue(own.is_relative_to(C.OWN))
            path = own / 'small.py'
            path.write_text('人工だけのコード\n', encoding='utf-8')
            registry = C.Registry()
            expected = C.sha(path)
            a = registry.add(str(path), expected, '役割1')
            b = registry.add(str(path), expected, '役割2')
            self.assertEqual(len(registry.rows), 1)
            self.assertIs(a, b)
            self.assertEqual(a['roles'], ['役割1', '役割2'])
            self.assertEqual(a['restore']['root'], 'repoRoot')
            self.assertNotIn('..', a['location']['entry'].split('/'))
            path.write_text('改変\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                registry.add(str(path), expected, '改変は拒否')

    def test_実入力型と途中exeを拒否する(self):
        """機能: 価格CSV・実Native/Record・途中exeの偶発収集を防ぐ。

        引数: self(収集検査)。返り値: None。
        """
        with tempfile.TemporaryDirectory(prefix='人工_', dir=C.OWN) as name:
            own = Path(name).resolve()
            self.assertTrue(own.is_relative_to(C.OWN))
            for filename in ('price.csv', 'scene.Native.json.gz', 'records.gz', 'old.exe'):
                path = own / filename
                path.write_bytes('人工の最小値'.encode('utf-8'))
                with self.subTest(filename=filename), self.assertRaises(ValueError):
                    C.Registry().file(path, '偶発した入力', 'metadata')
            path = own / 'fake.json'
            path.write_text('{}', encoding='utf-8')
            with self.assertRaises(ValueError):
                C.Registry().file(path, '人工という名だけでは不十分', '人工')

    def test_Go本文は環境参照でLICENSEだけ同梱(self):
        """機能: SDK codeは非同梱、静的リンクのLICENSEは同梱と区別する。

        引数: self(収集検査)。返り値: None。
        """
        registry = C.Registry()
        source = registry.file(C.SDK / 'src/runtime/runtime.go', 'SDKの実選択')
        license_row = registry.file(C.SDK / 'LICENSE', 'Go利用条件', 'LICENSE')
        self.assertEqual(source['kind'], '環境')
        self.assertIsNone(source['location']['entry'])
        self.assertEqual(license_row['kind'], 'LICENSE')
        self.assertEqual(license_row['restore']['root'], 'goRoot')
        self.assertIsNotNone(license_row['location']['entry'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
