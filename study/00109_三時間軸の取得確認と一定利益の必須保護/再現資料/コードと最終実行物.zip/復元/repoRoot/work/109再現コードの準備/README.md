# 109再現コード・最終exeの保存計画

最初は計画だけを準備し、金融と純頻度の全70成功後のRoot依頼により、最終2exeを含むZIP・所在索引・再現.mdを生成する。最終閉鎖記録はRootだけが作る。collector/ZIP口は成功metadataだけを読み、実Native/Raw/価格CSV/Recordや未使用本文を読まない。

金融条件 `44b26bb18f66a92c09be7110ce3f24bc81397a4a3322960cfabd3c0bd0909b9b` の実選択codeと各停止の所有code・仕様・検査を重複統合する。Root実行helper、CSV生成/独立再読、頻度独立集計、R人工出典器を加える。停止コード・Go固定物を変更しない。

```powershell
python -B -X utf8 work/109再現コードの準備/収集する.py --plan work/109再現コードの準備/計画候補.json
```

作業計画は新規ファイルにだけ保存する。collectorはZIP生成・金融・Observer起動の口を持たない。`files`に元path、全bytes SHA、サイズ、役割、`restore.root/relative`、安全なarchive entry予定を残す。

## 保存する範囲

- 金融条件の1128実選択codeのうち非GoRoot411。新部品停止の所有test・仕様・検査と、後段codeを明示Refで補う。
- GoRoot717（ソース712、Go/compile等5tools）は元path・Go版・size・全SHAによる環境参照。SDK本文やtools本体をZIPへ複製しない。静的リンクしたGoのLICENSE/PATENTSだけは小資料として同梱する。
- OSSソースはtoml v1.5.0とexpr v1.17.8。実在するCOPYING/LICENSEとgo.modを添える。module cacheの選択されたソースだけを保存し、cache全体を複製しない。
- 最終market exe `3c01b3b05f730ab6e750ef1414b73f6bb4fe0826d08f484bd8c228e1f677813e` と最終Observer exe `459e86ed05ea126917f0d8e9ab2843d0b489f79bfc2880915f5b7beeeae09686` の2本。他の途中版exeは保存しない。元14,139,392bytes、deflate見積約7.22MB。
- 人工は停止が明示したSHAだけ。Core6、Observer33（重複除去）、R1に、Core/Reader/Actorのtestが読む旧人工4を補う。通常市場dataと別の`人工/` prefixに置き、元位置と全SHAを記録する。
- 原板・価格CSV・実Source/Tape/Header/Record・実Native本文はこのZIPへコピーしない。入力FileRefと旧正本/旧archiveの所在を残す。

## 復元の三つの範囲

1. **コードの復元**：`repoRoot`・`neighborRoot`・`moduleCacheRoot`へ索引どおり戻すと元の相対import/replace配置を保てる。GoRootは元のGo 1.24.2環境とSHAを別に用意する。Nodeの`@oai/artifact-tool`本体は非同梱で、その単体環境復元は保証しない。CSV2コードとPython独立再読を保存する。
2. **同停止exeの復元**：最終2本を全SHAで復元する。元コードからの再buildはGit VCS埋込情報や絶対path等で同SHAにならないことがあるため、再build成功と同exe復元を区別する。
3. **実入力の保持又は正確な復元**：109は106のSource/Tape/Header/Record、NK225の元価格CSV、旧108正式Nativeを入力にする。巨大なSource記録・公表Record等には現work参照があるため、workを全削除すればコード/exeだけでは現条件を実行できない。削除前に共用入力を保持するか、旧106の正式索引・再現.md・固定archivesを使って正確な入力を復元する必要がある。旧106 producerは109実選択411へ全て含まれるとは扱わず、正式旧索引のproducer entryとarchive全SHAへ参照する。元入力や元exeが失われた場合、再形成が自動的に同SHAになるとは保証しない。元Rawは共用のまま利用する。

金融条件内の絶対pathとSHAは維持する。移設・出力先変更・再buildで別条件になる場合は旧条件を書き換えず、新しい条件と指紋を作る。

## 正式生成

Rootの3追加helper、同入口比較py4+mjs1+README、Viewer旧純確認helper3本と元設定/起動証拠、成功を結び直す小metadata、ZIP生成器自身を追加する。未知11/09の次工程コードは対象外。`ZIPの人工検査.py`でSHA/CRC/危険名・Windows同名を確認する。

```powershell
python -B -X utf8 work/109再現コードの準備/収集する.py --plan work/109再現コードの準備/最終計画.json
python -B -X utf8 work/109再現コードの準備/ZIPを正式保存する.py --plan work/109再現コードの準備/最終計画.json --plan-sha <最終計画SHA256>
```

Root許可後だけ実行する。金融627444・純頻度ef9c12・正式Native台帳aa25bf・Viewer代表48fb7e8b・正式結果9f413dを既知の全SHAへ結び、候補ZIP全entryを再読してから正式へ同bytes保存する。正式先はtrial109/再現資料で、既存先へ再実行しない。全元code/環境の前後不変を確認する。閉鎖/採用/研究目標達成はfalseのまま。

## 生成時に行う確認

金融/純頻度全70成功後、Rootが最終保存・Viewer・CSV・報告等で実行したhelperを明示Refで追加し、collector自身を固定する。計画確定後に全入力/codeの現在SHAを再認証し、ZIP・全entry SHA/CRC・安全な相対path・所在索引・前後不変を検査する。正式出力はこの準備工程では行わない。
