# 109金融条件の準備：保存派生対応

Root専用の一度限りの固定器。既存の技法固定、同じ技法の成功頻度`full70/完成.json`、停止済み保存器を認証し、正式109の`金融条件.json`を新規生成する。**準備・人工検査のみ。こちらから実行せず、金融・価格の本文は読まない。** 元107/108と停止済みCLI/Core/Actorは変更しない。

元固定器停止177eを保持する別ディレクトリ版。保存器の絶対位置を旧ディレクトリへ固定せず、Rootが明示した`--saving-stop`のSHAと内容を認証する。そのparentを所有7codeの位置として使い、別ディレクトリの再用10codeを区別する。保存器が派生しても旧a189のcodeを新しい所有codeへ読み替えず、新停止が宣言する全17の現物と前後不変を要求する。技法・金融exe・金融式は変更しない。

```powershell
python -B -X utf8 work/109金融条件の準備_保存派生対応/固定する.py `
  --technique <絶対技法条件固定.json> --technique-sha <SHA256> `
  --frequency-completion <絶対full70完成.json> --frequency-sha <SHA256> `
  --saving-stop <絶対109保存停止.json> --saving-stop-sha <SHA256>
```

出力先は`study/00109_三時間軸の取得確認と一定利益の必須保護/金融条件.json`だけ。既存ファイルは拒否し、Root進行は更新しない。Root進行の未金融・ライブhandleなし・保留価格と損益未読を前後で要求する。

技法の全code・exe・停止・市場前specを現物SHAで再認証する。24設定とSource/baseline参照は技法から同体copyする。CLI schemaは停止型対応版、`own_module_dir`はその絶対位置、workers4、binaryは技法のmarket_binary。技法で未実施だったfrequency_executedは元固定へ書き戻さず、新金融条件の来歴にだけtrueを記す。金融はfalseのまま。

頻度は要求SHA・同技法Ref・manifest/corpus/completionを結び、70場順、主7980/副7700、予定=観測+未観測、非金融・非参加計算を検査する。first2成功と全70の先頭2報告SHA/末尾種も同体を要求する。頻度before/afterの宣言全同体と実使用code包含は、Rootが実行直後に確認した証拠へ結ぶものである。**金融前の価格品質を再計算したとは説明しない。**

再hashするのは技法/保存code、exe、stop/spec、小metadata、頻度要求/完成/頻度集計CSVだけ。頻度beforeに含まれる価格CSV・Source Record・原板、値を含む場別gz報告は読まず再hashもしない。要求内のCSVは宣言path/SHA/bytesだけをmanifestと照合する。最新globや新11/09の本文を探さない。

保存器a189型は全17codeを所有7/再用10へ分けて現物同体を認証し、元tech codeとの衝突を拒否して`code_sha256`へ結合する。保存器stopはGo停止型と異なるため、`saving_stop`と`specifications`で認証し、Go用`stops`へ混ぜない。保存器の仕様・人工成功・前後code/入力同体も結ぶ。独立保存検算の準備であり、市場の損益や採用成功を表さない。

人工検査は`python -B -X utf8 work/109金融条件の準備_保存派生対応/人工検査.py`。一時dirだけのmetadata・code・出力を使い、正式条件・実技法・実頻度・市場本文は開かない。新保存dirの正しい所有7/再用10を通し、旧dirの全codeを新dirへ読み替えた偽装は拒否する。固定器の実行はRootが行う。
