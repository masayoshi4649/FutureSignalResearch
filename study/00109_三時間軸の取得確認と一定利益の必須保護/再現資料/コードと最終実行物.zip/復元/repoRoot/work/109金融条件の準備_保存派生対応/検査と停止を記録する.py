"""金融条件の準備を人工metadataだけで検査し、固定器自体を停止記録へ結ぶ。"""
from __future__ import annotations

import ast
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[1]
NAMES = ('固定する.py', '人工検査.py', '検査と停止を記録する.py', 'README.md')
STOPS = {
    'work/109金融条件の準備/停止.json': '177e3fa14cacfbd2c82ea7f44664529701c723067fd88bd5b4fd60dbe775c71d',
    'work/三時間軸の市場入出力_停止型対応/停止.json': '1fc0ff6bf4d2ae30b88b200eeb8d2c0279619d50e1134e531adbdaa7a08dbbe8',
    'work/109保存会計の準備/停止.json': 'a18926dd7fcaaead71a1899120dc5341a38013dfd4493cbd00e89338b67c439c',
}


def sha(path: Path) -> str:
    """機能: 明示したcode/仕様/停止だけを同定する。

    引数: path(Path)は非価格ファイル。
    返り値: strはSHA256。市場・頻度の実結果は読まない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_new(path: Path, value: dict) -> None:
    """機能: 人工確認と停止を一度だけ保存する。

    引数: path(Path)、value(dict)は新規先と内容。
    返り値: None。既存成果物を変更しない。
    """
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def dependencies() -> dict:
    """機能: 接続するCLIと保存器の停止・全宣言codeを同体確認する。

    引数: なし。明示した停止とそこに含まれるcodeだけを読む。
    返り値: dictは前後再確認する非価格指紋。
    """
    before = {}
    for name, expected in STOPS.items():
        path = ROOT / name
        assert sha(path) == expected
        before[str(path)] = expected
        value = json.loads(path.read_text(encoding='utf-8-sig'))
        code = value.get('所有コードSHA256') or value['コードSHA256']
        assert code
        for label, wanted in code.items():
            code_path = Path(label)
            if not code_path.is_absolute():
                code_path = ROOT / code_path
            assert sha(code_path) == wanted
            before[str(code_path)] = wanted
    return before


def main() -> None:
    """機能: 4主検査と構文・前後同体を確認して準備完了を記録する。

    引数: なし。固定する.pyのmain、実技法/実頻度、金融を呼ばない。
    返り値: None。人工確認と停止JSONだけを新規保存する。
    """
    assert not (OWN / '停止.json').exists()
    assert not (OWN / '検査').exists()
    before = dependencies()
    owned = {str(OWN / n): sha(OWN / n) for n in NAMES}
    for name in NAMES:
        if name.endswith('.py'):
            ast.parse((OWN / name).read_text(encoding='utf-8'), filename=name)
    argv = [sys.executable, '-B', '-X', 'utf8', str(OWN / '人工検査.py')]
    run = subprocess.run(argv, capture_output=True, text=True, encoding='utf-8', cwd=OWN, check=False)
    assert run.returncode == 0, run.stdout + run.stderr
    assert 'Ran 4 tests' in run.stderr and '\nOK\n' in run.stderr
    assert before == {p: sha(Path(p)) for p in before}
    assert owned == {p: sha(Path(p)) for p in owned}
    (OWN / '検査').mkdir()
    check = {'成功': True, 'argv': argv, 'exit_code': run.returncode, 'stdout': run.stdout, 'stderr': run.stderr,
             '主検査': 4, 'コードSHA256前': owned, 'コードSHA256後': dict(owned),
             '依存SHA256前': before, '依存SHA256後': dict(before), '前後不変': True,
             '金融条件生成': False, '金融実行': False, '市場本文読取': False, '実頻度完成読取': False}
    write_new(OWN / '検査/Python確認.json', check)
    stopped = {'成功': True, '停止': True, 'version': 1, 'trial': 109,
               'UTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'scope': 'Root専用金融条件の生成準備・保存派生対応。人工metadataだけ。正式生成/金融/実頻度本文未実行',
               '所有コードSHA256': owned, '直接停止SHA256': STOPS, '依存前後不変': True,
               '主検査': 4, '構文Python': 3, '依存指紋数': len(before),
               '仕様': {'path': str(OWN / 'README.md'), 'sha256': sha(OWN / 'README.md')},
               '検査': {'path': str(OWN / '検査/Python確認.json'), 'sha256': sha(OWN / '検査/Python確認.json')},
               '金融条件生成': False, '金融実行': False, '市場本文読取': False,
               '実技法固定読取': False, '実頻度完成読取': False, '未使用11月09本文未読': True}
    write_new(OWN / '停止.json', stopped)
    print(json.dumps({'停止': str(OWN / '停止.json'), 'sha256': sha(OWN / '停止.json'), '主検査': 4,
                      '正式金融条件生成': False, '市場本文読取': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
