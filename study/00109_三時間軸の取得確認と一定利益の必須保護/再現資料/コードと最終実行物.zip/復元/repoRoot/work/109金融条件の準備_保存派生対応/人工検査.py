"""金融条件固定器の純metadata反例を検査する。実技法・頻度・価格を読まない。"""
from __future__ import annotations

import copy
import datetime
import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

OWN = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('金融条件固定の純検査対象', OWN / '固定する.py')
M = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)


def fixture(root: Path) -> tuple:
    """機能: 価格本文を持たない70場の固定・頻度metadataを作る。

    引数: root(Path)は一時dir。
    返り値: tupleは技法/Ref/要求Ref/manifest/要求/完成の人工値。
    """
    h = 'a' * 64
    ref = lambda name: {'path': str((root / name).resolve()), 'sha256': h}
    tech_ref, request_ref = ref('技法.json'), ref('要求.json')
    tech = {'version': 1, 'trial': 109, 'fixed': True, 'configs': M.expected_configs(), 'clock_model': M.CLOCK,
            'quiet_seconds': 1200, 'quote_max_age_seconds': 0, 'financial_executed': False, 'frequency_executed': False,
            'holdout_price_unread': True, 'adopted': False, 'goal_achieved': False,
            'market_binary': {'path': str(M.MARKET / '検査/三時間軸研究.exe'), 'sha256': h},
            'observer_binary': ref('Observer.exe'), 'observer_stop': ref('Observer停止.json'),
            'code_sha256': {str(root / '人工code.py'): h},
            'stops': [ref(f'人工停止{i}.json') for i in range(9)], 'specifications': [ref(f'仕様{i}.md') for i in range(4)]}
    tech.update({k: ref(k + '.json') for k in M.SOURCE_FIELDS})
    manifest = {'source_root': str(root / '存在しない価格dir'), 'sessions': []}
    request = {'version': 1, 'trial': 109, 'fixed': True, 'stage': 'full70', 'technique_fixed': tech_ref,
               'manifest': tech['source_manifest'], 'corpus': tech['source_corpus'], 'source_completion': tech['source_completion'],
               'clock_model': M.CLOCK, 'quote_max_age_seconds': 0, 'quiet_seconds': 1200,
               'output_dir': str(root / '頻度'), 'scenes': []}
    config = {k: request[k] for k in ('clock_model', 'quote_max_age_seconds', 'quiet_seconds')}
    frequency = {'version': 1, 'trial': 109, 'stage': 'full70', 'success': True, 'financial_executed': False,
                 'participation_calculated': False, 'unchanged': True, 'request': request_ref, 'technique_fixed': tech_ref,
                 'manifest': tech['source_manifest'], 'corpus': tech['source_corpus'], 'source_completion': tech['source_completion'],
                 'config': config, 'results': []}
    refs = [tech_ref, request_ref, tech['observer_binary'], tech['observer_stop'], tech['source_manifest'], tech['source_corpus'], tech['source_completion']]
    before = {r['path']: r['sha256'] for r in refs}
    before.update(tech['code_sha256'])
    # ----------------------------------------
    # 主/副分母の予定値は価格や成績から作らず、明示35日夜の時計から置きます。
    for i in range(70):
        date = datetime.date(2026, 9, 21) + datetime.timedelta(days=i // 2)
        kind = 'Day' if i % 2 == 0 else 'Night'
        sid = date.isoformat() + '_' + kind
        file = {'path': f'JP_OSE_Data/future/NK225/{sid}/candle_5min.csv', 'sha256': h, 'size': 100}
        manifest['sessions'].append({'id': sid, 'contract': '人工限月', 'files': {'NK225_candle_300': file}})
        request['scenes'].append({'session': sid, 'candle_csv': {'path': str((Path(manifest['source_root']) / file['path']).resolve()), 'sha256': h, 'bytes': 100}})
        p, s = (78, 74) if kind == 'Day' else (150, 146)
        frequency['results'].append({'session': sid, 'report': ref(f'頻度/{sid}.json.gz'),
            'primary_planned_grids': p, 'primary_observed_grids': p - 1, 'primary_unobserved_grids': 1,
            'secondary_planned_grids': s, 'secondary_observed_grids': s - 1, 'secondary_unobserved_grids': 1,
            'primary_technical_allowed_grids': 1, 'primary_source_allowed_grids': 0,
            'secondary_technical_allowed_grids': 1, 'secondary_source_allowed_grids': 0,
            'end_seed': {'session': {'id': sid, 'contract': '人工限月', 'start': 1, 'end': 3, 'eof': 2},
                         'observed_at': 2, 'sealed': True, 'history_bars': [1, 1, 1], 'sha256': h}})
    frequency['before'], frequency['after'] = before, dict(before)
    return tech, tech_ref, request_ref, manifest, request, frequency


class MetadataTests(unittest.TestCase):
    """金融・価格I/Oを呼ばない固定metadata検査。"""

    def test_frequency_and_rejections(self):
        """機能: 70場/分母/同技法/非金融/非参加/前後宣言の破損を拒否する。

        引数: self(MetadataTests)は人工検査。
        返り値: None。価格ファイルは作成も読取もしない。
        """
        with tempfile.TemporaryDirectory() as directory:
            original = fixture(Path(directory))
            with patch.object(M, 'sha', side_effect=AssertionError('頻度metadataで本文hashを呼んだ')):
                M.verify_frequency(original[5], original[4], original[0], original[1], original[2], original[3], 'full70')
                first = copy.deepcopy(original)
                first[5]['stage'], first[4]['stage'] = 'first2', 'first2'
                first[5]['results'], first[4]['scenes'] = first[5]['results'][:2], first[4]['scenes'][:2]
                M.verify_frequency(first[5], first[4], first[0], first[1], first[2], first[3], 'first2')
            changes = {
                '金融真': lambda a: a[5].update(financial_executed=True),
                '参加真': lambda a: a[5].update(participation_calculated=True),
                '未成功': lambda a: a[5].update(success=False),
                'first2混入': lambda a: a[5].update(stage='first2'),
                '前後差': lambda a: a[5]['after'].update({a[1]['path']: 'b' * 64}),
                '空指紋': lambda a: a[5].update(before={}, after={}),
                '技法差': lambda a: a[5]['technique_fixed'].update(sha256='b' * 64),
                'code使用漏れ': lambda a: a[5]['before'].pop(next(iter(a[0]['code_sha256']))),
                '場不足': lambda a: a[5]['results'].pop(),
                '場順差': lambda a: a[5]['results'].reverse(),
                'Source差': lambda a: a[5].update(corpus={'path': '/別.json', 'sha256': 'b' * 64}),
                '時計差': lambda a: a[5]['config'].update(clock_model='実測と誤称'),
                '年齢gate追加': lambda a: a[4].update(quote_max_age_seconds=90),
                '予定分母変更': lambda a: a[5]['results'][0].update(primary_planned_grids=77),
                '未知を除外': lambda a: a[5]['results'][0].update(primary_unobserved_grids=0),
                '負の分母': lambda a: a[5]['results'][0].update(secondary_unobserved_grids=-1),
                'boolを計数': lambda a: a[5]['results'][0].update(primary_technical_allowed_grids=True),
                '未観測を成立': lambda a: a[5]['results'][0].update(primary_source_allowed_grids=78),
                'CSV宣言差': lambda a: a[4]['scenes'][0]['candle_csv'].update(sha256='b' * 64),
                '報告別位置': lambda a: a[5]['results'][0]['report'].update(path=str(Path(directory) / '別.json.gz')),
                '種未封印': lambda a: a[5]['results'][0]['end_seed'].update(sealed=False),
                '種場差': lambda a: a[5]['results'][0]['end_seed']['session'].update(id='別場'),
            }
            for name, alter in changes.items():
                with self.subTest(name=name):
                    args = copy.deepcopy(original)
                    alter(args)
                    with self.assertRaises((ValueError, KeyError)):
                        M.verify_frequency(args[5], args[4], args[0], args[1], args[2], args[3], 'full70')

    def test_technique_and_journal(self):
        """機能: 24設定と未金融/handleなし/保留未読を固定する。

        引数: self(MetadataTests)は人工検査。
        返り値: None。
        """
        with tempfile.TemporaryDirectory() as directory:
            tech = fixture(Path(directory))[0]
            M.verify_technique(tech)
            for name, value in (('configs', tech['configs'][:23]), ('financial_executed', True), ('holdout_price_unread', False), ('clock_model', '別時計')):
                with self.subTest(name=name):
                    c = copy.deepcopy(tech)
                    c[name] = value
                    with self.assertRaises(ValueError):
                        M.verify_technique(c)
        journal = {'試行': 109, '市場金融実行': False, 'ライブ金融handle': None, '保留価格と損益未読': True, '研究目標達成': False, '採用': False}
        M.verify_journal(journal)
        for name, value in (('市場金融実行', True), ('ライブ金融handle', 123), ('保留価格と損益未読', False)):
            with self.subTest(name=name):
                with self.assertRaises(ValueError):
                    M.verify_journal({**journal, name: value})

    def test_saving_and_code(self):
        """機能: 保存の所有7/再用10、前後code同体と元tech指紋の置換拒否を検査する。

        引数: self(MetadataTests)は人工検査。
        返り値: None。一時codeだけを読む。
        """
        with tempfile.TemporaryDirectory() as directory:
            root, h = Path(directory), 'a' * 64
            saving = root / '保存器'
            code = {str(saving / f'所有{i}.py'): h for i in range(7)}
            code.update({str(root / '旧code' / f'再用{i}.py'): h for i in range(10)})
            stop = {'version': 1, 'trial': 109, '停止': True, '入力前後不変': True, '実市場読取': False, '実金融': False, 'CSV/xlsx生成': False, 'コードSHA256': code}
            check = {'成功': True, 'exit_code': 0, '前後不変': True, 'コードSHA256前': code, 'コードSHA256後': dict(code), '入力SHA256前': {'人工': h}, '入力SHA256後': {'人工': h}}
            self.assertEqual(tuple(map(len, M.verify_saving(stop, check, saving))), (7, 10))
            derived_dir = root / '保存器_R構造対応'
            with self.assertRaises(ValueError):
                M.verify_saving(stop, check, derived_dir)
            derived_stop, derived_check = copy.deepcopy((stop, check))
            derived_code = {str(derived_dir / Path(k).name) if Path(k).parent == saving else k: v for k, v in code.items()}
            derived_stop['コードSHA256'] = derived_code
            derived_check['コードSHA256前'], derived_check['コードSHA256後'] = derived_code, dict(derived_code)
            self.assertEqual(tuple(map(len, M.verify_saving(derived_stop, derived_check, derived_dir))), (7, 10))
            for name in ('不変偽', 'code差', '再用不足', '入力差'):
                with self.subTest(name=name):
                    s, c = copy.deepcopy((stop, check))
                    if name == '不変偽':
                        s['入力前後不変'] = False
                    elif name == 'code差':
                        c['コードSHA256後'][next(iter(code))] = 'b' * 64
                    elif name == '再用不足':
                        s['コードSHA256'].pop(str(root / '旧code/再用0.py'))
                    else:
                        c['入力SHA256後']['人工'] = 'b' * 64
                    with self.assertRaises(ValueError):
                        M.verify_saving(s, c, saving)
            path = root / '人工code.py'
            path.write_text('人工1', encoding='utf-8')
            first = M.sha(path)
            merged, before = {}, {}
            M.merge_code(merged, {str(path): first}, before)
            path.write_text('人工2', encoding='utf-8')
            with self.assertRaises(ValueError):
                M.merge_code(merged, {str(path): first}, before)
            with self.assertRaises(ValueError):
                M.merge_code(merged, {str(path): M.sha(path)}, {})

    def test_condition_shape_and_no_overwrite(self):
        """機能: tech参照の同体copyと保存停止のspec参照、既存出力の拒否を確認する。

        引数: self(MetadataTests)は人工検査。
        返り値: None。正式金融条件へ書かない。
        """
        with tempfile.TemporaryDirectory() as directory:
            tech, tr, rr, _, _, _ = fixture(Path(directory))
            sr = {'path': str(Path(directory) / '保存停止.json'), 'sha256': 'a' * 64}
            c = M.build_condition(tech, tr, rr, sr, sr, sr, tech['code_sha256'])
            self.assertEqual((c['workers'], c['configs'], c['stops'], c['binary']), (4, tech['configs'], tech['stops'], tech['market_binary']))
            self.assertNotIn(sr, c['stops'])
            self.assertIn(sr, c['specifications'])
            c['configs'][0]['quiet_seconds'] = 1
            self.assertEqual(tech['configs'][0]['quiet_seconds'], 1200)
            path = Path(directory) / '人工出力.json'
            M.write_new(path, {'人工': True})
            with self.assertRaises(FileExistsError):
                M.write_new(path, {'上書き': True})


if __name__ == '__main__':
    unittest.main(verbosity=2)
