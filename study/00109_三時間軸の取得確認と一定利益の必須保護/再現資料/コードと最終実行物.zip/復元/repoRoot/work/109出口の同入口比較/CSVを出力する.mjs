/**
 * 同入口比較の確定JSONを4つのCSV表へ変換する。
 * @param {string[]} process.argv - 入力JSON・期待SHA・未使用出力先。
 * @returns {Promise<void>} CSV4点と確認JSONを保存する。XLSXは作らない。
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {Workbook} from '@oai/artifact-tool';

/**
 * 全bytes指紋を求める。
 * @param {string|Uint8Array} value - 対象。
 * @returns {string} SHA256。
 */
function sha(value) { return crypto.createHash('sha256').update(value).digest('hex'); }

/**
 * RFC4180の単一フィールドを作る。
 * @param {string|number|boolean|null} value - セル値。
 * @returns {string} 必要なら引用した文字列。
 */
function field(value) {
  const text = value instanceof Date
    ? new Date(value.getTime() + 9 * 3600000).toISOString().replace(/\.(\d{3})Z$/, (_, ms) => (ms === '000' ? '' : '.' + ms + '000') + '+09:00')
    : value == null ? '' : String(value);
  return /[",\r\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}

/**
 * 比較IDから入口/保護/費用のラベルを取り出す。
 * @param {string} key - 確定比較ID。
 * @returns {Array<string|number>} ラベル5列。
 */
function labels(key) {
  const m = key.match(/^(entry_E[01])_(G[012])対(G[012])_C(0|5)_D(0|1)$/);
  assert.ok(m);
  return [m[1], m[2], m[3], Number(m[4]), Number(m[5])];
}

// ----------------------------------------
// 出典を認証して、比較の対象と単位を明示した表を作る。

const [inputArg, expectedSHA, outArg] = process.argv.slice(2);
assert.ok(inputArg && /^[a-f0-9]{64}$/.test(expectedSHA) && outArg);
const input = path.resolve(inputArg), out = path.resolve(outArg);
const before = await fs.readFile(input);
assert.equal(sha(before), expectedSHA);
const data = JSON.parse(before.toString('utf8'));
assert.equal(data['成功'], true);
assert.equal(data['全比較で入口同体'], true);
assert.equal(data['場別'].length, 1680);
const wb = Workbook.create();
const tables = [];
const summaryHeader = ['比較ID', '入口', '前保護', '後保護', '片道追加滑りpt', '遅延秒', '同入口件数', '同入口枚数', '前実現円', '後実現円', '実現差円', '前勝件数', '後勝件数', '勝から勝件数', '勝から勝の差円', '負から勝件数', '負から勝の差円', '負から負件数', '負から負の差円', '取得変更件数', '前のみ件数', '後のみ件数'];
const summaryRows = Object.entries(data['全条件']).map(([key, v]) => [key, ...labels(key), v['同実入口玉'], v['同実入口枚'], v['前実現円'], v['後実現円'], v['差円'], v['前勝玉'], v['後勝玉'], v['勝敗遷移']['勝→勝']?.['玉'] ?? 0, v['勝敗遷移']['勝→勝']?.['差円'] ?? 0, v['勝敗遷移']['負→勝']?.['玉'] ?? 0, v['勝敗遷移']['負→勝']?.['差円'] ?? 0, v['勝敗遷移']['負→負']?.['玉'] ?? 0, v['勝敗遷移']['負→負']?.['差円'] ?? 0, v['取得変更玉'], v['前のみ玉'], v['後のみ玉']]);
tables.push({name: '同入口の実現差.csv', sheetName: '同入口比較', header: summaryHeader, rows: summaryRows, a: 8, b: 9, delta: 10});
const sceneHeader = ['比較ID', 'セッション', '入口', '前保護', '後保護', '片道追加滑りpt', '遅延秒', '同入口件数', '同入口枚数', '前実現円', '後実現円', '実現差円', '前勝件数', '後勝件数', '入口同体'];
const sceneRows = data['場別'].map(v => [v['比較'], v.session, ...labels(v['比較']), v['同実入口玉'], v['同実入口枚'], v['前実現円'], v['後実現円'], v['差円'], v['前勝玉'], v['後勝玉'], v['全同実入口']]);
tables.push({name: '全セッションの実現差.csv', sheetName: '全セッション', header: sceneHeader, rows: sceneRows, a: 9, b: 10, delta: 11});
const floorHeader = ['条件ID', '実取引件数', '起動件数', '未起動件数', '起動後赤字件数', '初床が費用床単独件数', '初床が費用床同率件数', '保存点で峰引く幅が最低床超の件数', '最終床が最低床件数', '自己保護要求件数', '初回要求が最低床件数', '狭幅件数', 'H中央値pt', '起動幅中央値pt', '初回要求まで中央値秒'];
const floorRows = Object.entries(data['保護床']).map(([key, v]) => {
  const c = v['計数'], d = v['保存値分布'];
  return [key, c['実玉'] ?? 0, c['起動玉'] ?? 0, c['未起動玉'] ?? 0, c['起動後赤字玉'] ?? 0, c['起動床:費用床が単独支配'] ?? 0, c['起動床:費用床と同率'] ?? 0, c['保存点で峰−幅が最低床を上回った玉'] ?? 0, c['最終床が最低床の玉'] ?? 0, c['自己保護要求玉'] ?? 0, c['初回自己要求が最低床の玉'] ?? 0, c['狭幅玉'] ?? 0, d.Hpt?.median ?? null, d['起動幅pt']?.median ?? null, d['起動から初回自己要求秒']?.median ?? null];
});
tables.push({name: '保護床の診断.csv', sheetName: '保護床', header: floorHeader, rows: floorRows});
const novemberHeader = ['比較ID', 'セッション', 'Source手法', 'SourceSignalID', '方向', '枚数', '新規時刻', '新規価格', '前決済時刻', '後決済時刻', '前実現円', '後実現円', '実現差円', '勝敗遷移', '前初正益', '後初正益', '前保護起動', '後保護起動'];
const novemberRows = data['11月06日の同実入口'].map(v => [v['比較'], v.session, v['Source手法'], v.SourceSignalID, v['方向'], v['枚数'], v['新規時刻'], v['新規価格'], v['前決済時刻'], v['後決済時刻'], v['前実現円'], v['後実現円'], v['差円'], v['前後勝敗'], v['前初正益'], v['後初正益'], v['前保護起動'], v['後保護起動']]);
tables.push({name: '11月06日の取引比較.csv', sheetName: '十一月六日', header: novemberHeader, rows: novemberRows, a: 10, b: 11, delta: 12});

// ----------------------------------------
// 表で差額を再計算し、JSON原値と一致した数値をCSVへ保存する。

for (const t of tables) {
  const sheet = wb.worksheets.add(t.sheetName);
  sheet.getRangeByIndexes(0, 0, t.rows.length + 1, t.header.length).values = [t.header, ...t.rows];
  if (t.delta != null) {
    for (let i = 0; i < t.rows.length; i++) sheet.getCell(i + 1, t.delta).formulasR1C1 = [[`=RC[${t.b - t.delta}]-RC[${t.a - t.delta}]`]];
  }
  t.sheet = sheet;
}
wb.recalculate();
await fs.mkdir(out, {recursive: false});
const results = {};
for (const t of tables) {
  const matrix = t.sheet.getRangeByIndexes(0, 0, t.rows.length + 1, t.header.length).values;
  if (t.delta != null) for (let i = 0; i < t.rows.length; i++) assert.equal(matrix[i + 1][t.delta], t.rows[i][t.delta]);
  const body = '\uFEFF' + matrix.map(row => row.map(field).join(',')).join('\r\n') + '\r\n';
  await fs.writeFile(path.join(out, t.name), body, {encoding: 'utf8', flag: 'wx'});
  results[t.name] = {sha256: sha(body), rows: t.rows.length};
}
assert.equal(sha(await fs.readFile(input)), expectedSHA);
await fs.writeFile(path.join(out, 'CSV生成の確認.json'), JSON.stringify({成功: true, 入力: input, 入力SHA256: expectedSHA, 出力: results, 入力前後不変: true, xlsx生成: false}, null, 2), {flag: 'wx'});
console.log(JSON.stringify({成功: true, 出力: results}));
