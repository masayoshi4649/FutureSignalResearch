"""Artifact Toolが保存したCSV4点をDecimalで独立再読する。"""

from collections import defaultdict
import csv
from decimal import Decimal
import json
from pathlib import Path

import 比較する as A


def rows(path):
    """機能: BOM/RFC4180のCSVを辞書として読む。

    引数: path(Path)は作成済みCSV。返り値: list[dict]は全行。
    """
    with path.open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))


def decimal(value):
    """機能: 数値セルを空/未知と区別して十進数へ変換する。

    引数: value(str)はCSVセル。返り値: Decimalは有限数値。
    """
    result = Decimal(value)
    A.need(result.is_finite(), 'CSVの有限数値')
    return result


def main():
    """機能: 4CSVの全主要値・全場加法・11/06玉合計をJSON原値へ照合する。

    引数: なし。返り値: None。元JSONとCSVを編集せず確認JSONを新規保存する。
    """
    own = Path(__file__).resolve().parent
    source = own / '解析_確定.json'
    source_sha = '0a3bc36abad9af12df36655d47ed9a5a4ff64e28d095c9037c5b1c44b5f7b891'
    data = A.load(source, source_sha)
    directory = own / 'CSV_確定'
    before = {str(source): source_sha}
    names = ['同入口の実現差.csv', '全セッションの実現差.csv', '保護床の診断.csv', '11月06日の取引比較.csv']
    before.update({str(directory / name): A.sha(directory / name) for name in names})
    summary, scenes, floors, november = [rows(directory / name) for name in names]
    A.need([len(summary), len(scenes), len(floors), len(november)] == [24, 1680, 16, 288], 'CSVの完全行数')
    mapping = {'同入口件数': '同実入口玉', '同入口枚数': '同実入口枚', '前実現円': '前実現円', '後実現円': '後実現円', '実現差円': '差円', '前勝件数': '前勝玉', '後勝件数': '後勝玉'}
    compared = 0
    for row in summary:
        actual = data['全条件'][row['比較ID']]
        for column, field in mapping.items():
            A.need(decimal(row[column]) == actual[field], '比較CSV.' + column)
            compared += 1
        for label in ('勝から勝', '負から勝', '負から負'):
            key = label.replace('から', '→')
            v = actual['勝敗遷移'].get(key, {})
            A.need(decimal(row[label + '件数']) == v.get('玉', 0) and decimal(row[label + 'の差円']) == v.get('差円', 0), '勝敗遷移のCSV')
        A.need(decimal(row['後実現円']) - decimal(row['前実現円']) == decimal(row['実現差円']), 'CSV差額の独立式')
    scene_source = {(r['比較'], r['session']): r for r in data['場別']}
    sums = defaultdict(lambda: defaultdict(Decimal))
    for row in scenes:
        expected = scene_source[row['比較ID'], row['セッション']]
        A.need(row['入口同体'] == 'true', '同入口flag')
        for column, field in mapping.items():
            A.need(decimal(row[column]) == expected[field], '全セッションCSV.' + column)
            sums[row['比較ID']][field] += decimal(row[column])
            compared += 1
    for key, values in sums.items():
        A.need(all(values[field] == data['全条件'][key][field] for field in mapping.values()), '70場加法と24比較の一致')
    floor_mapping = {'実取引件数': '実玉', '起動件数': '起動玉', '未起動件数': '未起動玉', '起動後赤字件数': '起動後赤字玉', '初床が費用床単独件数': '起動床:費用床が単独支配', '初床が費用床同率件数': '起動床:費用床と同率', '保存点で峰引く幅が最低床超の件数': '保存点で峰−幅が最低床を上回った玉', '最終床が最低床件数': '最終床が最低床の玉', '自己保護要求件数': '自己保護要求玉', '初回要求が最低床件数': '初回自己要求が最低床の玉', '狭幅件数': '狭幅玉'}
    for row in floors:
        actual = data['保護床'][row['条件ID']]
        for column, field in floor_mapping.items():
            A.need(decimal(row[column]) == actual['計数'].get(field, 0), '保護床CSV.' + column)
            compared += 1
        for column, field in (('H中央値pt', 'Hpt'), ('起動幅中央値pt', '起動幅pt'), ('初回要求まで中央値秒', '起動から初回自己要求秒')):
            expected = actual['保存値分布'].get(field, {}).get('median')
            A.need(row[column] == '' if expected is None else decimal(row[column]) == expected, '保護床中央値の未知区別')
    ns = {(r['比較'], r['session'], r['Source手法'], r['SourceSignalID']): r for r in data['11月06日の同実入口']}
    november_sum = defaultdict(lambda: defaultdict(Decimal))
    for row in november:
        expected = ns[row['比較ID'], row['セッション'], row['Source手法'], row['SourceSignalID']]
        for column, field in (('方向', '方向'), ('枚数', '枚数'), ('新規価格', '新規価格'), ('前実現円', '前実現円'), ('後実現円', '後実現円'), ('実現差円', '差円')):
            A.need(decimal(row[column]) == expected[field], '11/06 CSV.' + column)
            compared += 1
        for field in ('新規時刻', '前決済時刻', '後決済時刻'):
            A.need(row[field] == expected[field], '11/06時刻の一致')
        for column, field in (('前初正益', '前初正益'), ('後初正益', '後初正益'), ('前保護起動', '前保護起動'), ('後保護起動', '後保護起動')):
            A.need(row[column] == str(expected[field]).lower(), '11/06利益旗')
        for column, field in (('前実現円', '前実現円'), ('後実現円', '後実現円'), ('実現差円', '差円')):
            november_sum[row['比較ID'], row['セッション']][field] += decimal(row[column])
    for key, values in november_sum.items():
        A.need(all(value == scene_source[key][field] for field, value in values.items()), '11/06全玉と場別額の一致')
    A.need(all(A.sha(Path(path)) == expected for path, expected in before.items()), '全CSV/元JSONの前後不変')
    proof = {'成功': True, 'scope': 'Artifact ToolのCSV4点をPython Decimalで全主要値/場別加法/勝敗遷移/11月06日玉合計まで独立再読', '行数': dict(zip(names, (24, 1680, 16, 288))), '数値照合': compared, '入力SHA256': before, '前後不変': True, '金融再実行': False, '原板/価格CSV/SourceRecord読取': False, '11月09日本文/hash読取': False, 'xlsx生成': False}
    with (directory / 'CSV独立再読の確認.json').open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(proof, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'成功': True, '数値照合': compared, '行数': proof['行数']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
