"""比較の要約と11月06日の保存保護点を小JSONへまとめる。"""

from datetime import datetime
import json
from pathlib import Path

import 比較する as A


def main():
    """機能: 確定比較とSHA認証した11/06 Nativeから小型要約を新規保存する。

    引数: なし。返り値: None。退出後の仮想値やMFE比率は作らない。
    """
    own = Path(__file__).resolve().parent
    path = own / '解析_確定.json'
    digest = '0a3bc36abad9af12df36655d47ed9a5a4ff64e28d095c9037c5b1c44b5f7b891'
    full = A.load(path, digest)
    saved = A.load(A.RESULT, A.RESULT_SHA)
    row = next(r for r in saved['Native参照'] if r['session'] == '2026-11-06_Day')
    native = A.load(Path(row['native']['path']), row['native']['sha256'])
    example = {}
    for policy in ('G0', 'G1', 'G2'):
        key = f'entry_E0_{policy}_C0_D0'
        book = native['books'][key]
        p = next(p for p in book['positions'] if p['source']['signal_id'].endswith('000007'))
        point = p['activation']
        data = {'新規時刻': datetime.fromtimestamp(float(p['entry_quote']['time']), A.JST).isoformat(), '新規価格': p['entry_price'], '方向': p['side'], '枚数': p['initial_quantity'], '実現円': p['realized_net'], '起動時計': datetime.fromtimestamp(float(point['quote']['time']), A.JST).isoformat(), '起動方向幅pt': point['gain_points'], '起動費用後単位円': point['unit_net'], '起動時実玉含み円': point['whole_net'], '最終床pt': p['floor_gain']}
        if policy != 'G0':
            state = next(x for x in native['composite_audits'][key]['positions'] if x['position_id'] == p['id'])['activation']['state']
            data['純起動保存値'] = {k: state[k] for k in ('threshold_points', 'minimum_floor', 'peak_points', 'floor_points', 'width_points')}
        example[policy] = data
    selected = {k: v for k, v in full['全条件'].items() if k.endswith('C0_D0')}
    result = {'成功': True, 'scope': full['scope'], '解析正本': {'path': str(path), 'sha256': digest}, '入力SHA256': full['入力SHA256'], '全24比較の実入口同体': full['全比較で入口同体'], '全条件': full['全条件'], 'C0D0の日夜': {k: full['日夜'][k] for k in selected}, 'C0D0の週別': {k: full['週別'][k] for k in selected}, '保護床': full['保護床'], '11月06日Day09時50分売7枚の保存点': example, '11月06日の場別実現差': [r for r in full['場別'] if r['session'].startswith('2026-11-06') and r['比較'].endswith('C0_D0')], 'CSV': {p.name: {'path': str(p), 'sha256': A.sha(p)} for p in (own / 'CSV_確定').glob('*.csv')}, '限界': full['限界']}
    with (own / '要約.json').open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, default=A.serial, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'成功': True, '要約SHA256': A.sha(own / '要約.json'), 'bytes': (own / '要約.json').stat().st_size}, ensure_ascii=False))


if __name__ == '__main__':
    main()
