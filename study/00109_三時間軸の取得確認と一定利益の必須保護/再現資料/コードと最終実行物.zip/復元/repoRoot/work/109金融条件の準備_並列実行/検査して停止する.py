"""並列実行向け金融条件の準備を人工metadataだけで検査して停止する。"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import datetime

OWN=Path(__file__).resolve().parent
ROOT=OWN.parents[1]
SOURCE=ROOT/'work/109金融条件の準備_保存派生対応'


def sha(path: Path) -> str:
    """
    機能: 自己code/再用code/人工確認だけを同定する。
    引数: path (Path) は非市場ファイル。
    返り値: str はSHA256。
    """
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def write_new(path: Path,value: dict) -> None:
    """
    機能: 新しい確認又は停止だけを保存する。
    引数: path (Path)、value (dict) は出力先とJSON。
    返り値: None。旧停止は上書きしない。
    """
    with path.open('x',encoding='utf-8',newline='\n') as stream:json.dump(value,stream,ensure_ascii=False,indent=2);stream.write('\n')


def main() -> None:
    """
    機能: prepare純metadata人工を確認し実金融前に停止する。
    引数: なし。正式prepare/金融条件生成/金融は呼ばない。
    返り値: None。
    """
    assert not (OWN/'停止.json').exists()
    stopped=json.loads((SOURCE/'停止.json').read_text(encoding='utf-8'))
    source={str(SOURCE/'停止.json'):'3311c68fa0e2b70014793c701efba71772a242afffc5f2eece87e09019af5e32',**stopped['所有コードSHA256']}
    assert all(sha(Path(name))==want for name,want in source.items())
    own={str(OWN/name):sha(OWN/name) for name in ('固定する.py','人工検査.py','検査して停止する.py','README.md')}
    result=subprocess.run([sys.executable,str(OWN/'人工検査.py')],cwd=OWN,capture_output=True,text=True,encoding='utf-8',check=False)
    assert result.returncode==0,result.stderr
    assert all(sha(Path(name))==want for name,want in {**source,**own}.items())
    write_new(OWN/'人工確認.json',{'成功':True,'exit_code':0,'stdout':result.stdout,'stderr':result.stderr,'再用前後不変':True,'自己code前後不変':True,'正式金融条件生成':False,'金融実行':False,'市場本文読込':False})
    write_new(OWN/'停止.json',{'成功':True,'停止':True,'version':1,'trial':109,'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'所有コードSHA256':own,'再用停止とcodeSHA256':source,'再用前後不変':True,'自己code前後不変':True,'人工確認SHA256':sha(OWN/'人工確認.json'),'範囲':'金融条件prepare/metadataだけ。実行順変更を同体金融へ結合','正式金融条件生成':False,'金融実行':False,'市場本文読込':False,'実Report読込':False,'未使用11月09本文未読':True})
    print(json.dumps({'成功':True,'停止SHA256':sha(OWN/'停止.json'),'人工確認SHA256':sha(OWN/'人工確認.json')},ensure_ascii=False))


if __name__=='__main__':main()
