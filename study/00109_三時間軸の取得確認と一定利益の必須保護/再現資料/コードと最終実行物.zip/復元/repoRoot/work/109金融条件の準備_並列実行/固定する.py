"""同じ技法・金融を維持し、成功first2頻度と全70頻度の並行実行を認証する。"""
from __future__ import annotations

import argparse
import copy
import importlib.util
from pathlib import Path

OWN=Path(__file__).resolve().parent
ROOT=OWN.parents[1]
TRIAL=ROOT/'study/00109_三時間軸の取得確認と一定利益の必須保護'
TARGET=TRIAL/'金融条件.json'
JOURNAL=ROOT/'work/109進行/現在.json'
SOURCE=ROOT/'work/109金融条件の準備_保存派生対応'
SOURCE_STOP_SHA='3311c68fa0e2b70014793c701efba71772a242afffc5f2eece87e09019af5e32'
SAVING=ROOT/'work/109保存会計の準備_R構造対応'
FREQUENCY_STAGE='first2_verified_full70_parallel'


def import_source():
    """
    機能: 停止3311の所有codeを実物認証してから純関数をimportする。
    引数: なし。金融/Observerの実行口は呼ばない。
    返り値: module は未変更の固定器純関数。
    """
    import hashlib,json
    stop=SOURCE/'停止.json'
    with stop.open('rb') as stream:actual=hashlib.file_digest(stream,'sha256').hexdigest()
    if actual!=SOURCE_STOP_SHA:raise ValueError('再用停止3311の指紋差')
    value=json.loads(stop.read_text(encoding='utf-8-sig'))
    if value.get('成功') is not True:raise ValueError('再用停止が未成功')
    for name,expected in value['所有コードSHA256'].items():
        with Path(name).open('rb') as stream:actual=hashlib.file_digest(stream,'sha256').hexdigest()
        if actual!=expected:raise ValueError('再用所有codeの指紋差:'+name)
    spec=importlib.util.spec_from_file_location('停止3311の純固定関数',SOURCE/'固定する.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


M=import_source()


def verify_pending_request(request: dict, validation: dict, tech: dict, tech_ref: dict,
                           request_ref: dict, first_ref: dict, manifest: dict) -> None:
    """
    機能: 全70の成功を要求せず、同条件要求と起動前metadata照合だけを認証する。
    引数: 各dictは全70要求・照合・技法・参照・先頭2成功・manifest。
    返り値: None。全70完成や価格/Report本文を読まない。
    """
    config={'clock_model':M.CLOCK,'quote_max_age_seconds':0,'quiet_seconds':1200}
    M.require(request.get('version')==1 and request.get('trial')==109 and request.get('fixed') is True and
              request.get('stage')=='full70' and request.get('technique_fixed')==tech_ref and
              request.get('first2_completion')==first_ref and all(request.get(k)==v for k,v in config.items()),'全70要求の同技法/先頭2/時計差')
    for fixed,field in (('source_manifest','manifest'),('source_corpus','corpus'),('source_completion','source_completion')):
        M.require(request.get(field)==tech[fixed],'全70要求のSource三参照差:'+field)
    ids=[row['id'] for row in manifest['sessions']]
    scenes=request.get('scenes',[])
    M.require(len(ids)==len(set(ids))==70 and ids==sorted(ids) and [row['session'] for row in scenes]==ids,'全70要求のmanifest順差')
    base=Path(manifest['source_root']);M.require(base.is_absolute(),'source_rootは絶対pathが必要')
    for scene,item in zip(scenes,manifest['sessions']):
        file=item['files']['NK225_candle_300']
        expected={'path':str((base/file['path']).resolve()),'sha256':file['sha256'],'bytes':file['size']}
        M.require(scene.get('candle_csv')==expected,'全70要求のCSV参照metadata差')
    M.require(Path(request.get('output_dir','')).is_absolute(),'全70要求outは絶対pathが必要')
    M.require(validation.get('成功') is True and validation.get('unchanged') is True and validation.get('before')==validation.get('after') and
              validation.get('request')==request_ref and validation.get('technique_fixed')==tech_ref and validation.get('stage')=='full70' and
              validation.get('scenes')==ids and validation.get('observer_binary')==tech['observer_binary'] and validation.get('observer_stop')==tech['observer_stop'],
              '全70要求の起動前metadata照合差')
    for flag in ('CSV本文読込','CSV本文SHA計算','RecordRawSource本文読込','Observer起動','金融実行'):
        M.require(type(validation.get(flag)) is int and validation[flag]==0,'metadata照合の範囲差:'+flag)
    M.require(validation.get('市場out作成') is False,'metadata照合が市場outを作成')
    recorded=M.fingerprint_map(validation['before'])
    for ref in [request_ref,tech_ref,tech['observer_binary'],tech['observer_stop']]+[tech[name] for name in ('source_manifest','source_corpus','source_completion')]:
        M.require(recorded.get(M.path_key(M.valid_ref(ref)))==ref['sha256'],'全70要求照合が使用した指紋の包含不足')
    stats=validation.get('csv_stat',[]);M.require(len(stats)==70,'起動前CSV stat70場が必要')
    for row,scene in zip(stats,scenes):
        value=scene['candle_csv']
        M.require(M.path_key(Path(row['path']))==M.path_key(Path(value['path'])) and row['bytes']==value['bytes'] and row['declared_sha256']==value['sha256'] and
                  row.get('body_read') is False and row.get('sha_recalculated') is False,'CSVはmetadata/stat照合だけ')


def verify_order(record: dict, tech_ref: dict, first_ref: dict, request_ref: dict, validation_ref: dict) -> None:
    """
    機能: Rootが金融開始前に実行順だけを変える記録を確認する。
    引数: recordと各Ref(dict)は事前記録と認証対象。
    返り値: None。技法/24条件の変更や全70成功の捏造を拒否する。
    """
    M.require(record.get('version')==1 and record.get('trial')==109 and record.get('fixed') is True and record.get('記録UTC') and
              record.get('変更範囲')=='実行の依存順だけ。技法・全24設定・時計・Source・市場入力・金融実行物・評価は不変', 'Root事前記録の変更範囲差')
    M.require(record.get('技法固定')==tech_ref and record.get('先頭2頻度')==first_ref and record.get('全70頻度要求')==request_ref and
              record.get('全70頻度要求のmetadata照合')==validation_ref,'実行順変更記録の参照差')
    M.require(type(record.get('全70頻度handle_記録時')) is int and record['全70頻度handle_記録時']>0 and
              record.get('全70頻度の成功完了_記録時') is False and record.get('金融条件生成_記録時') is False and
              record.get('金融開始_記録時') is False and record.get('保留11月09価格未読') is True and record.get('採用') is False and
              record.get('研究目標達成') is False,'Rootの事前並行/未金融/保留未読条件差')
    M.require(record.get('変更理由') and record.get('元の予定') and record.get('実行予定'),'実行順変更の理由が必要')


def build_parallel(tech: dict, tech_ref: dict, first_ref: dict, request_ref: dict, validation_ref: dict,
                   order_ref: dict, saving_ref: dict, saving: dict, code: dict) -> dict:
    """
    機能: 停止3311のCondition本体を再用し、実行順の事実だけを追記する。
    引数: techと各Ref/saving/code(dict)は認証済みmetadata。
    返り値: dict はfirst2認証/全70並行と明示した未金融Condition。
    """
    value=M.build_condition(tech,tech_ref,first_ref,saving_ref,saving['仕様'],saving['検査'],code)
    value['scope']='市場前固定の同じMain24金融。成功first2頻度を認証し、全70純頻度と独立に並行。既使用探索、採用/安定性未証明'
    value['frequency_stage']=FREQUENCY_STAGE
    value['full70_frequency_request']=copy.deepcopy(request_ref)
    value['full70_frequency_metadata_validation']=copy.deepcopy(validation_ref)
    value['execution_order_change']=copy.deepcopy(order_ref)
    value['full70_frequency_completion']=None
    value['frequency_evidence']='成功first2完成は停止3311の純verify_frequency(first2)で認証。全70は要求/起動前metadata照合/Root事前記録だけを結合し、成功完成を主張しない'
    value['specifications'] += [request_ref,validation_ref,order_ref]
    for key in ('configs','binary','stops')+M.SOURCE_FIELDS:
        expected=tech['market_binary'] if key=='binary' else tech[key]
        M.require(value[key]==expected,'金融本体の不変差:'+key)
    return value


def prepare(tech_ref: dict, first_ref: dict, request_ref: dict, validation_ref: dict,
            order_ref: dict, saving_ref: dict) -> tuple[dict,dict]:
    """
    機能: 正式Root metadataだけを認証し、並列金融条件を保存前の値にする。
    引数: 各Ref(dict)は技法・first2・全70要求・照合・事前変更記録・新R保存停止。
    返り値: tuple[dict,dict] はConditionと固定中に再認証する非価格指紋。
    """
    M.require(not TARGET.exists(),'金融条件は未生成の場合だけ')
    before={};journal_path=M.bind(M.reference(JOURNAL),before);journal=M.read(journal_path);M.verify_journal(journal)
    tech_path=M.bind(tech_ref,before);M.require(tech_path==TRIAL/'技法条件固定.json','正式109技法固定だけ');tech=M.read(tech_path);M.verify_technique(tech)
    M.require(journal.get('技法固定')==tech_ref,'Root進行と技法固定の参照差')
    code={};M.merge_code(code,tech['code_sha256'],before)
    for ref in [tech['market_binary'],tech['observer_binary'],tech['observer_stop']]+tech['stops']+tech['specifications']+list(tech.get('go_closures',{}).values()):M.bind(ref,before)
    for name in M.SOURCE_FIELDS:M.bind(tech[name],before)
    manifest=M.read(Path(tech['source_manifest']['path']))
    first_path=M.bind(first_ref,before);M.require(first_path.name=='完成.json','first2完成metadataが必要');first=M.read(first_path)
    first_request_ref=first['request'];first_request=M.read(M.bind(first_request_ref,before))
    M.require(Path(first_request['output_dir']).resolve()==first_path.parent,'先頭2完成の出力位置差')
    M.verify_frequency(first,first_request,tech,tech_ref,first_request_ref,manifest,'first2')
    request=M.read(M.bind(request_ref,before));validation=M.read(M.bind(validation_ref,before));verify_pending_request(request,validation,tech,tech_ref,request_ref,first_ref,manifest)
    M.require(Path(request['output_dir']).resolve()==ROOT/'work/109頻度/全70場','正式全70頻度outの要求だけ')
    order_path=M.bind(order_ref,before);M.require(order_path==TRIAL/'実行順序の変更.json','正式事前変更記録だけ')
    verify_order(M.read(order_path),tech_ref,first_ref,request_ref,validation_ref)
    saving_path=M.bind(saving_ref,before);M.require(saving_path==SAVING/'停止.json','新R保存器の停止だけを明示受付')
    saving=M.read(saving_path);saving_check=M.bind(saving['検査'],before);M.bind(saving['仕様'],before)
    owned,reused=M.verify_saving(saving,M.read(saving_check),SAVING);M.merge_code(code,owned,before);M.merge_code(code,reused,before)
    source_stop=SOURCE/'停止.json';M.bind({'path':str(source_stop),'sha256':SOURCE_STOP_SHA},before)
    source=M.read(source_stop);M.merge_code(code,source['所有コードSHA256'],before)
    M.merge_code(code,{str(OWN/name):M.sha(OWN/name) for name in ('固定する.py','人工検査.py','検査して停止する.py','README.md')},before)
    value=build_parallel(tech,tech_ref,first_ref,request_ref,validation_ref,order_ref,saving_ref,saving,code)
    value['saving_code_counts']={'owned':len(owned),'reused':len(reused)}
    value['specifications'] += [M.reference(OWN/'README.md'),M.reference(source_stop),source['仕様']]
    return value,before


def main() -> None:
    """
    機能: Root明示実行時だけ検査済み金融条件を新規保存する。
    引数: 各--*-ref用pathと--*-shaは6つの認証入力。
    返り値: None。金融/Observerを起動せずRoot進行も書き換えない。
    """
    import json
    parser=argparse.ArgumentParser(description=__doc__)
    names=('technique','first2-completion','full70-request','full70-validation','order-record','saving-stop')
    for name in names:parser.add_argument('--'+name,required=True,type=Path);parser.add_argument('--'+name+'-sha',required=True)
    args=parser.parse_args();refs=[{'path':str(getattr(args,name.replace('-','_'))),'sha256':getattr(args,name.replace('-','_')+'_sha')} for name in names]
    value,before=prepare(*refs)
    for path,expected in before.items():M.require(M.sha(Path(path))==expected,'固定中の非価格入力変更:'+path)
    M.verify_journal(M.read(JOURNAL));M.require(not TARGET.exists(),'金融条件が既に生成された');M.write_new(TARGET,value)
    print(json.dumps({'金融条件':M.reference(TARGET),'frequency_stage':FREQUENCY_STAGE,'金融実行':False,'全70頻度成功の主張':False},ensure_ascii=False))


if __name__=='__main__':main()
