# first2頻度を認証して全70頻度と金融を並行する

実行依存順だけを変更するRoot用の金融条件固定器。市場前の技法固定、24金融設定、時計、Source、入力、金融exe、Go閉包は変更しない。停止3311c68f…の純関数を実物認証してimportし、変更せず再用する。

```powershell
python 固定する.py --technique '<技法固定>' --technique-sha '<SHA>' --first2-completion '<成功first2完成>' --first2-completion-sha '<SHA>' --full70-request '<全70要求>' --full70-request-sha '<SHA>' --full70-validation '<起動前metadata照合>' --full70-validation-sha '<SHA>' --order-record '<実行順変更記録>' --order-record-sha '<SHA>' --saving-stop '<新R保存器停止>' --saving-stop-sha '<SHA>'
```

`prepare` は保存前のConditionと非価格指紋を返す。CLIは全検査後にだけ正式 `金融条件.json` を一度作る。準備段階ではCLIを実行しない。Observer/金融exe、CSV、Source/Record、Raw、場別Reportを呼ばない。Root進行も書き換えない。

成功first2は旧純 `verify_frequency(stage='first2')` で認証する。全70は同技法の要求と起動前metadata照合だけを束縛し、完成を開かない。Rootの金融開始前の変更理由・同一技法・参照・未金融・保留未読記録を必須にする。全70処理handleは記録時の識別であり、現在の実行中/成功を確認した値とはしない。

金融Conditionの `frequency_completion` は正しいfirst2参照、`frequency_stage=first2_verified_full70_parallel`、`full70_frequency_completion=null` とする。全70の成功を偽らない。`frequency_executed=true` はfirst2の実行済みを意味する。scopeと根拠も変更後の順序を説明する。

新R保存器は `work/109保存会計の準備_R構造対応/停止.json` の1位置だけを受付し、停止3311の所有7/再用10の検査を再用する。保存器のR監査修正を技法変更とは扱わない。保存停止はGo用stopsへ混ぜずspecificationへ入れる。並列固定器自身、再用3311の所有code/停止/specも金融codeとspecへ結ぶ。

現在の検査は手製metadataだけ。実条件生成・市場金融・実頻度Report読込は未実施。固定済み技法・仕様・旧停止を変更しない。
