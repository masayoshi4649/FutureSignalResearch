"""並列実行のmetadataだけを検査し、停止3311の純関数不変を確認する。"""
from __future__ import annotations
import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

OWN=Path(__file__).resolve().parent
SPEC=importlib.util.spec_from_file_location('並列固定の検査対象',OWN/'固定する.py')
P=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(P)
BASE_SPEC=importlib.util.spec_from_file_location('停止3311の手製器具',P.SOURCE/'人工検査.py')
F=importlib.util.module_from_spec(BASE_SPEC);BASE_SPEC.loader.exec_module(F)


def fixture(root: Path) -> tuple:
    """
    機能: 停止3311の手製metadataから成功first2と未完成full70要求を作る。
    引数: root (Path) はtemp位置。
    返り値: tuple は技法/参照/manifest/先頭2/全70/照合/事前変更記録。
    """
    tech,tr,_,manifest,request,frequency=F.fixture(root)
    ref=lambda name:{'path':str(root/name),'sha256':'a'*64}
    first_ref,first_request_ref,full_ref,validation_ref,order_ref=(ref(name) for name in ('first2/完成.json','first2要求.json','full70要求.json','metadata照合.json','実行順序の変更.json'))
    first_request=copy.deepcopy(request);first_request.update(stage='first2',scenes=request['scenes'][:2],output_dir=str(root/'first2'))
    first=copy.deepcopy(frequency);first.update(stage='first2',results=first['results'][:2],request=first_request_ref)
    for row in first['results']:row['report']['path']=str(root/'first2'/(row['session']+'.json.gz'))
    first['before'][first_request_ref['path']]=first_request_ref['sha256'];first['after']=dict(first['before'])
    request.update(first2_completion=first_ref,output_dir=str(root/'work/109頻度/全70場'))
    refs=[tr,full_ref,tech['observer_binary'],tech['observer_stop']]+[tech[name] for name in ('source_manifest','source_corpus','source_completion')]
    fingerprints={item['path']:item['sha256'] for item in refs}
    validation={'成功':True,'unchanged':True,'before':fingerprints,'after':dict(fingerprints),'request':full_ref,'technique_fixed':tr,'stage':'full70','scenes':[row['id'] for row in manifest['sessions']],
                'observer_binary':tech['observer_binary'],'observer_stop':tech['observer_stop'],'csv_stat':[{'path':s['candle_csv']['path'],'bytes':s['candle_csv']['bytes'],'declared_sha256':s['candle_csv']['sha256'],'body_read':False,'sha_recalculated':False} for s in request['scenes']],
                'CSV本文読込':0,'CSV本文SHA計算':0,'RecordRawSource本文読込':0,'Observer起動':0,'金融実行':0,'市場out作成':False}
    order={'version':1,'trial':109,'fixed':True,'記録UTC':'2026-11-09T09:44:33+00:00','変更範囲':'実行の依存順だけ。技法・全24設定・時計・Source・市場入力・金融実行物・評価は不変',
           '技法固定':tr,'先頭2頻度':first_ref,'全70頻度要求':full_ref,'全70頻度要求のmetadata照合':validation_ref,'全70頻度handle_記録時':123,
           '全70頻度の成功完了_記録時':False,'金融条件生成_記録時':False,'金融開始_記録時':False,'保留11月09価格未読':True,'採用':False,'研究目標達成':False,'変更理由':'人工の順序変更','元の予定':'全70後','実行予定':'並行'}
    return tech,tr,manifest,first_ref,first_request_ref,first_request,first,full_ref,request,validation_ref,validation,order_ref,order


class Tests(unittest.TestCase):
    """市場本文も実際の要求も読まない人工検査。"""

    def test_first2_and_pending_without_full_completion(self):
        """
        機能: full70完成なしで正しいfirst2認証と全70要求照合を行う。
        引数: self (Tests) は人工検査器。
        返り値: None。純関数内の本文hashも禁止する。
        """
        with tempfile.TemporaryDirectory() as d:
            a=fixture(Path(d));tech,tr,manifest,fr,frr,freqreq,freq,rr,request,vr,validation,ore,order=a
            with patch.object(P.M,'sha',side_effect=AssertionError('純metadataで本文hashを呼んだ')):
                P.M.verify_frequency(freq,freqreq,tech,tr,frr,manifest,'first2')
                P.verify_pending_request(request,validation,tech,tr,rr,fr,manifest)
                P.verify_order(order,tr,fr,rr,vr)
            self.assertFalse((Path(request['output_dir'])/'完成.json').exists())

    def test_pending_rejections(self):
        """
        機能: 同技法/first2/順序/照合指紋/size/非本文条件の差を拒否する。
        引数: self (Tests) は人工検査器。
        返り値: None。
        """
        with tempfile.TemporaryDirectory() as d:
            original=fixture(Path(d))
            changes={'first2差':lambda a:a[8].update(first2_completion={**a[8]['first2_completion'],'sha256':'b'*64}),'技法差':lambda a:a[8]['technique_fixed'].update(sha256='b'*64),'年齢変更':lambda a:a[8].update(quote_max_age_seconds=90),
                     'Source差':lambda a:a[8]['corpus'].update(sha256='b'*64),'場順':lambda a:a[8]['scenes'].reverse(),'照合未成功':lambda a:a[10].update(成功=False),
                     'size差':lambda a:a[10]['csv_stat'][0].update(bytes=999),'照合本文読込':lambda a:a[10].update(CSV本文読込=1),'照合前後差':lambda a:a[10]['after'].update({str(Path(d)/'別.json'):'b'*64})}
            for name,alter in changes.items():
                with self.subTest(name=name):
                    a=copy.deepcopy(original);alter(a)
                    with self.assertRaises(ValueError):P.verify_pending_request(a[8],a[10],a[0],a[1],a[7],a[3],a[2])

    def test_order_rejections(self):
        """
        機能: 金融後の変更や全70成功の偽装・参照差を拒否する。
        引数: self (Tests) は人工検査器。
        返り値: None。
        """
        with tempfile.TemporaryDirectory() as d:
            a=fixture(Path(d))
            for field,value in [('全70頻度の成功完了_記録時',True),('金融条件生成_記録時',True),('金融開始_記録時',True),('保留11月09価格未読',False),('変更範囲','技法も変更'),('全70頻度handle_記録時',None)]:
                with self.subTest(field=field),self.assertRaises(ValueError):P.verify_order({**a[12],field:value},a[1],a[3],a[7],a[9])

    def test_body_identical_and_first2_truth(self):
        """
        機能: 24/Source/baseline/exe/stopsを同体に保ちfirst2参照を正しく残す。
        引数: self (Tests) は人工検査器。
        返り値: None。
        """
        with tempfile.TemporaryDirectory() as d:
            a=fixture(Path(d));tech=copy.deepcopy(a[0]);saving={'仕様':a[11],'検査':a[11]};sr={'path':str(Path(d)/'saving停止.json'),'sha256':'a'*64}
            value=P.build_parallel(tech,a[1],a[3],a[7],a[9],a[11],sr,saving,tech['code_sha256'])
            for field in ('configs','stops')+P.M.SOURCE_FIELDS:self.assertEqual(value[field],tech[field])
            self.assertEqual(value['binary'],tech['market_binary']);self.assertEqual(value['frequency_completion'],a[3]);self.assertEqual(value['frequency_stage'],'first2_verified_full70_parallel');self.assertIsNone(value['full70_frequency_completion'])
            self.assertNotIn(sr,value['stops']);self.assertIn(sr,value['specifications']);self.assertFalse(value['financial_executed']);value['configs'][0]['quiet_seconds']=1;self.assertEqual(tech['configs'][0]['quiet_seconds'],1200)

    def test_prepare_artificial_io(self):
        """
        機能: 実prepareを人工JSON/code/停止で通し、価格を開かず未保存Conditionを得る。
        引数: self (Tests) はtemp所有者。
        返り値: None。正式ファイルへは書かない。
        """
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);trial=root/'study/109';trial.mkdir(parents=True);journal=root/'現在.json';saving_dir=root/'work/109保存会計の準備_R構造対応';saving_dir.mkdir(parents=True)
            def put(path,value):
                """
                機能: 人工metadataを保存して指紋を返す。
                引数: path (Path)、value (dict) はtemp保存先と内容。
                返り値: dict は実物SHA付き参照。
                """
                path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,ensure_ascii=False),encoding='utf-8');return P.M.reference(path)
            a=list(fixture(root));tech=copy.deepcopy(a[0]);manifest=a[2]
            code_path=root/'人工code.py';code_path.write_text('人工code',encoding='utf-8');tech['code_sha256']={str(code_path):P.M.sha(code_path)}
            for key in P.M.SOURCE_FIELDS:tech[key]=put(root/(key+'.json'),manifest if key=='source_manifest' else {'人工':True})
            tech['observer_binary']=put(root/'Observer.exe',{'起動しない':True});tech['observer_stop']=put(root/'Observer停止.json',{'成功':True})
            tech['stops']=[put(root/f'停止{i}.json',{'人工':True}) for i in range(9)];tech['specifications']=[put(root/f'仕様{i}.md',{'人工':True}) for i in range(4)]
            tech['market_binary']=P.M.reference(P.M.MARKET/'検査/三時間軸研究.exe')
            tr=put(trial/'技法条件固定.json',tech)
            first_request=copy.deepcopy(a[5]);first_request.update(technique_fixed=tr,manifest=tech['source_manifest'],corpus=tech['source_corpus'],source_completion=tech['source_completion'])
            frr=put(root/'first2要求.json',first_request);first=copy.deepcopy(a[6]);first.update(technique_fixed=tr,request=frr,manifest=tech['source_manifest'],corpus=tech['source_corpus'],source_completion=tech['source_completion'])
            used=[tr,frr,tech['observer_binary'],tech['observer_stop']]+[tech[k] for k in ('source_manifest','source_corpus','source_completion')];before={r['path']:r['sha256'] for r in used};before.update(tech['code_sha256']);first['before']=before;first['after']=dict(before);fr=put(root/'first2/完成.json',first)
            request=copy.deepcopy(a[8]);request.update(technique_fixed=tr,first2_completion=fr,manifest=tech['source_manifest'],corpus=tech['source_corpus'],source_completion=tech['source_completion']);rr=put(root/'full70要求.json',request)
            validation=copy.deepcopy(a[10]);validation.update(technique_fixed=tr,request=rr,observer_binary=tech['observer_binary'],observer_stop=tech['observer_stop']);used=[tr,rr,tech['observer_binary'],tech['observer_stop']]+[tech[k] for k in ('source_manifest','source_corpus','source_completion')];validation['before']={r['path']:r['sha256'] for r in used};validation['after']=dict(validation['before']);vr=put(root/'照合.json',validation)
            order=copy.deepcopy(a[12]);order.update(技法固定=tr,先頭2頻度=fr,全70頻度要求=rr,全70頻度要求のmetadata照合=vr);ore=put(trial/'実行順序の変更.json',order)
            code={}
            for i in range(17):
                path=(saving_dir if i<7 else root/'再用')/f'{i}.py';path.parent.mkdir(exist_ok=True);path.write_text('人工保存code',encoding='utf-8');code[str(path)]=P.M.sha(path)
            check={'成功':True,'exit_code':0,'前後不変':True,'コードSHA256前':code,'コードSHA256後':code,'入力SHA256前':{'人工':'a'*64},'入力SHA256後':{'人工':'a'*64}}
            sr=put(saving_dir/'停止.json',{'version':1,'trial':109,'停止':True,'入力前後不変':True,'実市場読取':False,'実金融':False,'CSV/xlsx生成':False,'コードSHA256':code,'仕様':put(saving_dir/'仕様.md',{'人工':True}),'検査':put(saving_dir/'確認.json',check)})
            put(journal,{'試行':109,'市場金融実行':False,'ライブ金融handle':None,'保留価格と損益未読':True,'研究目標達成':False,'採用':False,'技法固定':tr})
            original_sha=P.M.sha
            def guarded_sha(path):
                """
                機能: 人工prepareが価格/圧縮Report本文を開かないことを確認する。
                引数: path (Path) は要求された同定先。
                返り値: str は許可されたcode/metadataのSHA。
                """
                if path.suffix in ('.csv','.gz','.jsonl'):raise AssertionError('市場本文を開いた:'+str(path))
                return original_sha(path)
            with patch.multiple(P,ROOT=root,TRIAL=trial,TARGET=trial/'金融条件.json',JOURNAL=journal,SAVING=saving_dir),patch.object(P.M,'sha',side_effect=guarded_sha):
                value,proof=P.prepare(tr,fr,rr,vr,ore,sr)
                self.assertEqual(value['frequency_completion'],fr);self.assertEqual(value['configs'],tech['configs']);self.assertGreater(len(proof),17);self.assertFalse((trial/'金融条件.json').exists())
                wrong=put(root/'別保存停止.json',P.M.read(Path(sr['path'])))
                with self.assertRaisesRegex(ValueError,'新R保存器'):P.prepare(tr,fr,rr,vr,ore,wrong)


if __name__=='__main__':unittest.main(verbosity=2)
