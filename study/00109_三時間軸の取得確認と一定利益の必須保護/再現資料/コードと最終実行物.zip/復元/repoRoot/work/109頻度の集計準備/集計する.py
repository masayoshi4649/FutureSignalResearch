"""完成後の109純頻度Reportだけを独立再読し、条件とSource時計の重なりを集計する。"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import gzip
import hashlib
import json
import math
from pathlib import Path
import csv

CLOCK = 'csv_end_plus60_at_record_scheduler'
CONFIG = {'clock_model': CLOCK, 'quote_max_age_seconds': 0, 'quiet_seconds': 1200}
GROUPS = ('trend', 'reversal', 'trend_momentum', 'reversal_momentum', 'spike')


def need(condition: bool, reason: str) -> None:
    """
    機能: 保存値と独立集計の不一致を拒否する。
    引数: condition (bool)、reason (str) は条件と根拠。
    返り値: None。不一致ではValueErrorを返す。
    """
    if not condition:
        raise ValueError(reason)


def sha(path: Path) -> str:
    """
    機能: 明示した完成metadata又は場別頻度Reportを同定する。
    引数: path (Path) はCSV/Raw/SourceRecord以外の明示入力。
    返り値: str はSHA256。
    """
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read_ref(ref: dict, proof: dict, compressed: bool = False) -> dict:
    """
    機能: SHA認証したmetadata又は純頻度ReportだけをJSON化する。
    引数: ref/proof (dict)、compressed (bool) は参照・指紋台帳・圧縮指定。
    返り値: dict は保存値。CSV/Raw/SourceRecordはこの関数へ渡さない。
    """
    path = Path(ref['path'])
    need(path.is_absolute(), '絶対参照が必要')
    need(sha(path) == ref['sha256'], '参照SHA差:' + str(path))
    proof[str(path)] = ref['sha256']
    if compressed:
        with gzip.open(path, 'rt', encoding='utf-8-sig') as stream:
            return json.load(stream)
    return json.loads(path.read_text(encoding='utf-8-sig'))


def empty_counts() -> dict:
    """
    機能: Observerと同じ候補計数の空値を返す。
    引数: なし。
    返り値: dict は理由別の独立Counterを持つ。
    """
    return {**{key: 0 for key in ('candidates', 'known', 'unknown', 'allowed', 'wait', 'conflicts', 'trend_passed', 'reversal_passed')}, 'reasons': Counter()}


def add_unknown(counts: dict, number: int, reason: str) -> None:
    """
    機能: 未観測/BBO不明を候補分母へ残す。
    引数: counts (dict)、number (int)、reason (str) は集計先・候補数・理由。
    返り値: None。
    """
    counts['candidates'] += number
    counts['unknown'] += number
    counts['reasons'][reason] += number


def add_batch(counts: dict, batch: dict) -> None:
    """
    機能: 候補ごとに既知/待機/成立/競合とT/Rを数える。
    引数: counts/batch (dict) は集計先と純Batch。
    返り値: None。枚数・利益で重み付けしない。
    """
    for value in batch['decisions']:
        need(value['status'] in ('未知', '待機', '許可', '競合'), '純状態名差')
        need(value['known'] == (value['status'] != '未知'), '既知/状態差')
        need(value['allowed'] == (value['status'] == '許可'), '許可/状態差')
        need(value['policy'] == 'ENTRY_E1' and value['snapshot_id'] == batch['snapshot_id'], '純政策/snapshot差')
        counts['candidates'] += 1
        counts['known' if value['known'] else 'unknown'] += 1
        counts['allowed'] += value['allowed']
        counts['wait'] += value['status'] == '待機'
        counts['conflicts'] += value['status'] == '競合'
        counts['reasons'][value['reason']] += 1
        for field in ('trend', 'reversal'):
            check = value[field]
            need(not check['passed'] or check['known'], '未知の経路を成立に補完')
            counts[field + '_passed'] += check['known'] and check['passed']


def any_allowed(batch: dict) -> bool:
    """
    機能: 一方向以上が許可された技術枠だけを数える。
    引数: batch (dict) は純Batch。
    返り値: bool は実際の新規や保有参加を示さない。
    """
    return any(value['allowed'] for value in batch['decisions'])


def planned(start: float, end: float) -> int:
    """
    機能: EOFで切らず既知の場時計から300秒格子数を数える。
    引数: start/end (float) は半開区間の両端。
    返り値: int は計画分母。
    """
    return max(0, math.ceil(end / 300) - math.ceil(start / 300))


def scene_counts(report: dict) -> dict:
    """
    機能: 全gridから主/副/全観測の計数を保存集計と独立に照合する。
    引数: report (dict) は一場の純頻度Report。
    返り値: dict は再集計結果。指標や金融を再形成しない。
    """
    for flag in ('complete', 'inputs_unchanged', 'state_independent', 'policy_eof_redacted'):
        need(report[flag] is True, 'Report成功/不変flag差:' + flag)
    for flag in ('financial_executed', 'participation_calculated', 'source_reexecuted'):
        need(report[flag] is False, 'Reportへ金融/参加率/Source再実行混入')
    need(report['version'] == 1 and report['trial'] == 109 and report['config'] == CONFIG, 'Report版/時計条件差')
    session, rows = report['session'], report['grid_rows']
    start, end, eof = session['start'], session['end'], session['eof']
    force = end - 600
    need(start <= eof <= end, 'Report EOF差')
    output = {prefix: {'technical': empty_counts(), 'source': empty_counts(), 'observed': 0, 'technical_allowed_grids': 0, 'source_allowed_grids': 0} for prefix in ('all', 'primary', 'secondary')}
    output['primary']['planned'] = planned(start + 1200, force)
    output['secondary']['planned'] = planned(start + 1200, end - 1800)
    previous = None
    due_seen = set()
    for row in rows:
        at = row['at']
        need(at % 300 == 0 and start <= at < end and at <= eof and (previous is None or previous < at), 'grid時計/重複/未来差')
        previous = at
        primary, secondary = start + 1200 <= at < force, start + 1200 <= at < end - 1800
        need((row['primary'], row['secondary']) == (primary, secondary), '主副の分母tag差')
        need(row['state_independent'] is True, '候補集合でsetup進行が変化')
        for batch_name in ('technical_batch', 'source_planned_batch'):
            batch = row[batch_name]
            need(batch['snapshot_id'] == row['snapshot_id'] and batch['policy'] == 'ENTRY_E1', 'Batch公開識別差')
        need(row['technical_batch']['state'] == row['source_planned_batch']['state'], '二集合の公開履歴差')
        for birth in row['due_births']:
            need(birth['id'] not in due_seen and birth['born_at'] < at and birth['observed_at'] < at and birth['assignment']['assigned_at'] == at and birth['due_observed'], '予定出生の重複/先取り/割当差')
            due_seen.add(birth['id'])
        if row['quote_known']:
            q = row['quote']
            need(q is not None and q['quote_ok'] and 0 < q['bid'] < q['ask'] and q['time'] <= at, '観測済み正常BBO差')
            need([value['candidate']['side'] for value in row['technical_batch']['decisions']] == [1, -1], '全技術の買売二候補差')
            need([value['candidate']['id'] for value in row['source_planned_batch']['decisions']] == [birth['id'] for birth in row['due_births']], 'Source予定候補の全件結合差')
        else:
            need(not row['technical_batch']['decisions'] and not row['source_planned_batch']['decisions'], 'BBO不明から架空候補')
        for prefix in ['all'] + (['primary'] if primary else []) + (['secondary'] if secondary else []):
            counts = output[prefix]
            counts['observed'] += 1
            if row['quote_known']:
                add_batch(counts['technical'], row['technical_batch'])
                add_batch(counts['source'], row['source_planned_batch'])
            else:
                add_unknown(counts['technical'], 2, row['quote_reason'])
                add_unknown(counts['source'], len(row['due_births']), row['quote_reason'])
            counts['technical_allowed_grids'] += any_allowed(row['technical_batch'])
            counts['source_allowed_grids'] += any_allowed(row['source_planned_batch'])
    for prefix in ('primary', 'secondary'):
        counts = output[prefix]
        counts['unobserved'] = counts['planned'] - counts['observed']
        need(counts['unobserved'] >= 0, '計画より観測枠が多い')
        add_unknown(counts['technical'], 2 * counts['unobserved'], 'EOF等により当枠未観測。未来値を補わない')
        need(counts['planned'] == report[prefix + '_planned_grids'] and counts['observed'] == report[prefix + '_observed_grids'] and counts['unobserved'] == report[prefix + '_unobserved_grids'], '独立主副分母差')
        need(counts['technical'] == report[prefix + '_technical'] and counts['source'] == report[prefix + '_source_observed'], '独立主副候補計数差')
        for kind in ('technical', 'source'):
            need(counts[kind + '_allowed_grids'] == report[prefix + '_' + kind + '_allowed_grids'], '独立主副許可枠差')
    need(len(rows) == report['grids'] and output['all']['technical'] == report['technical'] and output['all']['source'] == report['source_planned'], '独立全観測候補計数差')
    need(output['all']['technical_allowed_grids'] == report['technical_any_allowed_grids'] and output['all']['source_allowed_grids'] == report['source_any_allowed_grids'], '全観測許可枠差')
    need(len({value['id'] for value in report['source_births']}) == len(report['source_births']), '出生ID重複')
    need({value['id'] for value in report['source_births'] if value['due_observed']} == due_seen, '出生と観測済み予定枠の過不足')
    return output


def group_state(check: dict, evaluated: bool) -> str:
    """
    機能: 未評価と評価済み未知を混同せず論理群を分類する。
    引数: check (dict)、evaluated (bool) はCheck値と共通可用性到達。
    返り値: str は未評価/未知/不成立/成立。
    """
    if not evaluated:
        return '共通可用性未達のため未評価'
    return '未知' if not check['known'] else '成立' if check['passed'] else '不成立'


def diagnostics(report: dict, ordinal: int, buckets: dict) -> None:
    """
    機能: 保存された論理群・構造段階・Source予定時刻の重なりを数える。
    引数: report/buckets (dict)、ordinal (int) はReport・集計先・manifest位置。
    返り値: None。取得距離の数値を復元せず、論理残差だけを診断する。
    """
    sid = report['session']['id']
    kind = sid.rsplit('_', 1)[-1]
    period = f'第{ordinal * 5 // 70 + 1}期'
    scopes = ('全体', kind, period)
    seen_times = {row['at'] for row in report['grid_rows']}
    for row in report['grid_rows']:
        for area in ['全観測'] + (['主'] if row['primary'] else []) + (['副'] if row['secondary'] else []):
            for collection, name in [('technical_batch', '全技法'), ('source_planned_batch', 'Source予定')]:
                batch = row[collection]
                if not row['quote_known']:
                    number = 2 if name == '全技法' else len(row['due_births'])
                    for scope in scopes:
                        buckets['reasons'][(scope, area, name, 'BBO', row['quote_reason'])] += number
                    continue
                for value in batch['decisions']:
                    side = value['candidate']['side']
                    index = 0 if side == 1 else 1
                    state = batch['state']
                    t, r = state['trend'][index], state['reversal'][index]
                    ready = bool(value['trend_momentum']['reason'])
                    aligned = all(item['known'] and item['direction'] == side for item in value['background'])
                    t_event = t['event_bar_id'] == state['last_five_id'] and bool(t['event'])
                    r_event = r['event_bar_id'] == state['last_five_id'] and r['event'] == '反対側突破'
                    tm, rm, sp = (value[key]['known'] and value[key]['passed'] for key in ('trend_momentum', 'reversal_momentum', 'spike'))
                    for scope in scopes:
                        buckets['reasons'][(scope, area, name, value['status'], value['reason'])] += 1
                        for key in GROUPS:
                            buckets['groups'][(scope, area, name, key, group_state(value[key], ready), value[key]['reason'])] += 1
                        for width, background in zip((300, 900, 1800), value['background']):
                            label = '未知' if not background['known'] else '同方向' if background['direction'] == side else '逆方向' if background['direction'] == -side else '並びと両傾き不一致/同値'
                            buckets['groups'][(scope, area, name, f'{width}秒背景', label, '')] += 1
                        for role, setup in [('T', t), ('R', r)]:
                            buckets['structure'][(scope, area, name, role, setup['phase'] or '未形成', setup['event'], setup['reason'])] += 1
                        chains = {'T': [ready, aligned, t_event, tm, sp], 'R': [ready, r_event, rm, sp]}
                        names = {'T': ['共通可用性', '三尺度方向', '当足構造イベント', '勢い一群', '複合スパイクなし'], 'R': ['共通可用性', '当足反転イベント', '回復勢い一群', '複合スパイクなし']}
                        for role, conditions in chains.items():
                            running = True
                            for step, condition in enumerate(conditions):
                                running = running and condition
                                buckets['chain'][(scope, area, name, role, step + 1, names[role][step], '累積成立' if running else '累積未成立')] += 1
                            if running:
                                final = value['trend' if role == 'T' else 'reversal']
                                label = '保存された経路ANDも成立' if final['passed'] else '距離条件が残る' if final['known'] else '保存経路が未知'
                                buckets['chain'][(scope, area, name, role, len(conditions) + 1, '取得距離の保存論理残差', label)] += 1
            # ----------------------------------------
            # 当時のdueコピーだけでSource予定枠と全技術を結びます。場末状態を過去へ戻しません。
            technical = {value['candidate']['side']: value for value in row['technical_batch']['decisions']}
            source_decisions = {value['candidate']['id']: value for value in row['source_planned_batch']['decisions']}
            for birth in row['due_births']:
                value = technical.get(birth['side'])
                status = 'BBO未知' if value is None else value['status']
                role = '' if value is None else value['role']
                source_flag = '取消を既観測' if birth['cancellation_seen'] else 'fillを既観測' if birth['filled_seen'] else 'fill未観測'
                planned_value=source_decisions.get(birth['id'])
                source_status='BBO未知' if planned_value is None else planned_value['status']
                source_role='' if planned_value is None else planned_value['role']
                for scope in scopes:
                    buckets['join'][(scope, area, birth['method'], status, role, source_status, source_role, source_flag, birth['assignment']['deferred'])] += 1
    for birth in report['source_births']:
        assigned = birth['assignment']['assigned_at']
        label = '観測済み割当枠' if assigned in seen_times else 'Force以後の割当' if assigned >= report['session']['end'] - 600 else '予定内だが未観測の割当枠'
        delay=assigned-birth['born_at']
        delay_bucket='60秒以下' if delay<=60 else '60秒超300秒以下' if delay<=300 else '300秒超1200秒以下' if delay<=1200 else '1200秒超'
        for scope in scopes:
            buckets['birth'][(scope, birth['method'], label, birth['assignment']['deferred'], delay_bucket)] += 1


def write_csv(path: Path, header: list[str], rows: list[list]) -> None:
    """
    機能: 小型の独立集計を新規CSVへ保存する。
    引数: path (Path)、header/rows (list) は出力先と表。
    返り値: None。損益列を作らない。
    """
    with path.open('x', encoding='utf-8', newline='') as stream:
        writer = csv.writer(stream)
        writer.writerow(header)
        writer.writerows(rows)


def aggregate(completion_ref: dict, technique_ref: dict, output: Path) -> dict:
    """
    機能: 成功full70頻度のReportを独立再読し、主副・論理群・時計相性を保存する。
    引数: completion_ref/technique_ref (dict)、output (Path) は期待SHA付き参照と未作成先。
    返り値: dict は集計結果。金融・参加率・未参加仮想利益は計算しない。
    """
    output = output.resolve()
    need(not output.exists(), '集計outは未作成folderが必要')
    proof = {}
    completion, technique = read_ref(completion_ref, proof), read_ref(technique_ref, proof)
    need(completion['success'] and completion['stage'] == 'full70' and completion['version'] == 1 and completion['trial'] == 109 and completion['config'] == CONFIG, '成功した同条件full70完成が必要')
    need(completion['unchanged'] and completion['before'] == completion['after'] and not completion['financial_executed'] and not completion['participation_calculated'], '純頻度の責務/入力不変差')
    need(completion['technique_fixed'] == technique_ref and technique['fixed'] and technique['version'] == 1 and technique['trial'] == 109, '技法固定と完成の結合差')
    need({key: technique[key] for key in CONFIG} == CONFIG, '技法時計条件差')
    need(completion['manifest'] == technique['source_manifest'] and completion['corpus'] == technique['source_corpus'] and completion['source_completion'] == technique['source_completion'], '固定入力三参照差')
    manifest = read_ref(technique['source_manifest'], proof)
    need(len(manifest['sessions']) == len(completion['results']) == 70, '全70場が必要')
    totals = {prefix: Counter() for prefix in ('primary', 'secondary')}
    split = defaultdict(Counter)
    buckets = {name: Counter() for name in ('reasons', 'groups', 'structure', 'chain', 'join', 'birth')}
    scene_rows, previous_seed = [], None
    for ordinal, (source, item) in enumerate(zip(manifest['sessions'], completion['results'])):
        need(item['session'] == source['id'], 'manifest順と完成の場順差')
        path = Path(item['report']['path'])
        need(path.resolve().parent == Path(completion_ref['path']).resolve().parent and path.name.endswith('.json.gz'), '場別Report参照の範囲差')
        report = read_ref(item['report'], proof, True)
        need(report['session']['id'] == source['id'], 'Report場差')
        need(report['input_seed'] == previous_seed, 'manifest順の数値種連鎖差')
        previous_seed = report['end_seed']
        need(item['end_seed'] == report['end_seed'], '完成とReportの末尾種差')
        for field in ('grids','technical','source_planned','primary_technical','secondary_technical','primary_source_observed','secondary_source_observed','primary_technical_allowed_grids','secondary_technical_allowed_grids','primary_source_allowed_grids','secondary_source_allowed_grids'):
            need(item[field]==report[field], '完成とReportの保存計数差:'+field)
        calculated = scene_counts(report)
        diagnostics(report, ordinal, buckets)
        row = {'session': source['id'], 'kind': source['id'].rsplit('_', 1)[-1], 'period': f'第{ordinal * 5 // 70 + 1}期', 'all_observed': report['grids']}
        for prefix in ('primary', 'secondary'):
            values = calculated[prefix]
            fields = {key: values[key] for key in ('planned', 'observed', 'unobserved', 'technical_allowed_grids', 'source_allowed_grids')}
            for kind in ('technical', 'source'):
                for key, value in values[kind].items():
                    if key != 'reasons':
                        fields[kind + '_' + key] = value
            for key, value in fields.items():
                row[prefix + '_' + key] = value
                totals[prefix][key] += value
                for scope in ('全体', row['kind'], row['period']):
                    split[(prefix, scope)][key] += value
            for key in ('planned', 'observed', 'unobserved'):
                need(values[key] == item[prefix + '_' + key + '_grids'], '完成の主副分母差')
        scene_rows.append(row)
    need(totals['primary']['planned'] == 7980 and totals['secondary']['planned'] == 7700, '全70の主7980/副7700分母差')
    need(totals['primary']['technical_candidates']==15960 and totals['secondary']['technical_candidates']==15400,'買売候補とgrid分母の区別')
    for path, expected in proof.items():
        need(sha(Path(path)) == expected, '集計中の入力変更:' + path)
    output.mkdir(parents=True)
    columns = list(scene_rows[0])
    write_csv(output / '場別の技法成立頻度.csv', columns, [[row[key] for key in columns] for row in scene_rows])
    fields = list(totals['primary'])
    write_csv(output / '日夜と時系列の頻度.csv', ['分母', '区分'] + fields, [[prefix, scope] + [values[key] for key in fields] for (prefix, scope), values in sorted(split.items())])
    headers = {'reasons': ['区分', '分母', '候補集合', '状態', '理由'], 'groups': ['区分', '分母', '候補集合', '論理群', '状態', '理由'],
               'structure': ['区分', '分母', '候補集合', '経路', '段階', 'イベント', '理由'], 'chain': ['区分', '分母', '候補集合', '経路', '順', '論理群', '累積状態'],
               'join': ['区分', '分母', 'Source手法', '全買売集合での技術状態', '全買売集合の技術経路', 'Source集合での技術状態', 'Source集合の技術経路', '当時Source観測', 'quiet繰越'], 'birth': ['区分', 'Source手法', '予定割当の観測', 'quiet繰越', '出生から予定枠秒']}
    names = {'reasons': '理由別.csv', 'groups': '論理群別.csv', 'structure': '構造段階別.csv', 'chain': '経路の累積条件別.csv', 'join': 'Source予定枠の重なり.csv', 'birth': '出生と予定取得時計.csv'}
    for name, values in buckets.items():
        write_csv(output / names[name], headers[name] + ['候補数'], [list(key) + [number] for key, number in sorted(values.items(), key=lambda item: tuple(str(value) for value in item[0]))])
    result = {'成功': True, 'scope': '独立再読の純技術成立頻度。金融適格性・実参加率・損益は未計算', 'completion': completion_ref, 'technique_fixed': technique_ref,
              'inputs_sha256': proof, 'unchanged': True, 'sessions': 70, 'totals': totals, 'groups': {'時間系列': 'manifest順の14場ずつ全5期。結果を見て区切らない',
              '分母': '主grid7980/買売候補15960、副grid7700/買売候補15400。Source候補数は当時出生済み予定集合',
              '代表理由': 'Trend/ReversalのReasonはANDの短絡順による代表。唯一の失敗要因や単独効果としない',
              '未評価': '共通可用性未達時の空Checkは勢い/スパイクが未知だと断定しない', '累積条件': '診断用の固定順AND。個別手法の因果効果ではない',
              '距離': '前段すべて成立時だけ保存された経路ANDの残差で判別。ATR/取得距離を再形成しない', 'R構造': '確認済みでActive=falseの成立も正しい',
              'Source': '出生済み予定割当との重なり。実Source hold/予約/余力/金融適格集合ではない'},
              'financial_executed': False, 'participation_calculated': False, 'opportunity_pnl_calculated': False, 'holdout_11_09_read': False}
    with (output / '独立集計.json').open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    return result


def main() -> None:
    """
    機能: Rootが成功完成SHAを明示した後だけ全70純頻度を再読する。
    引数: --completion/--completion-sha256/--technique-fixed/--technique-sha256/--out は絶対参照と新規先。
    返り値: None。金融やObserverの実行物を起動しない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('completion', 'completion-sha256', 'technique-fixed', 'technique-sha256', 'out'):
        parser.add_argument('--' + name, required=True)
    args = parser.parse_args()
    result = aggregate({'path': args.completion, 'sha256': args.completion_sha256}, {'path': args.technique_fixed, 'sha256': args.technique_sha256}, Path(args.out))
    print(json.dumps({'成功': result['成功'], '場数': 70, '主': result['totals']['primary'], '副': result['totals']['secondary']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
