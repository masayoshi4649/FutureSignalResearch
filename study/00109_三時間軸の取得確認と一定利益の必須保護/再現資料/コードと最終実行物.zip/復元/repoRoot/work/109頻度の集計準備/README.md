# 全70純頻度の独立再読

Observerの成功full70完成と技法固定を、Rootから指定された期待SHAで認証して場別Report 70個を再読する。実行は完成後のRoot指示まで行わない。現時点は手製70 Reportを使う人工検査だけ。

```powershell
python 集計する.py --completion '<完成JSON絶対path>' --completion-sha256 '<期待SHA256>' --technique-fixed '<技法固定JSON絶対path>' --technique-sha256 '<期待SHA256>' --out '<未作成の集計folder>'
```

完成・技法固定・manifest順、場別gzipの実物SHA、前場→次場のSeedInfo、保存された全候補集計と独立計数を照合する。Source/Record/Raw/価格CSVを開かず、Observer/金融を再実行しない。11/09は対象外。

主分母はgrid7,980、買売2候補で15,960。副はgrid7,700、買売候補15,400。未観測とBBO未知も分母へ残す。Source予定候補は別の分母で、実Source hold/予約/余力を考慮した金融適格集合ではない。ここでの許可枠は実参加率・新規・保有とは異なる。

出力するCSVは場別、日夜とmanifest順14場×5期、代表理由、論理群、構造段階、経路の累積AND、Source予定枠との重なり、出生から予定割当までの時計区分の8表。独立集計JSONに入力指紋と限界を残す。全gridや価格を再転記しない。

Trend/ReversalのReasonは短絡順で決まる代表理由であり、唯一の失敗要因や各手法の単独効果ではない。背景3尺度、TrendMomentum、ReversalMomentum、Spikeは保存値から並列計数する。共通可用性に未達のときの空Checkは「未評価」とし、勢い/スパイクの実値が未知と断定しない。共通到達の保存痕跡としてTrendMomentum.Reasonの非空を用いる。

構造はAssessment.StructureだけでなくBatch.State.Trend/Reversalを用いる。不許可時のAssessment.Structureは空だからである。Rの確認済み構造がActive=falseとなる定義も正しく扱う。Tの方向・当足イベント・勢い・Spike、Rの当足反転イベント・回復勢い・Spikeの累積ANDは、条件を狭める場所を見るための固定順の診断である。

取得距離のATR等はReportに実値がない。GapATR比から逆算せず、距離以外の保存群がすべて成立している場合だけ、経路ANDの残差として距離条件を区別する。その他の場合の距離合否は分からない。

全買売候補集合とSource予定候補集合は、両向き競合の有無で最終採否が変わる場合がある。Source重なり表には双方の状態を並べる。予定枠のFilledSeen/CancellationSeenはdue当時のコピーだけを使い、場末SourceBirthsの状態を過去の採否へ持ち込まない。

損益・金融適格性・参加率・未参加又は決済後の仮想利益を計算しない。閾値を変更する処理も持たない。

`python 集計の人工検査.py` は計数改変/未来出生の拒否、未観測の保持、R確認済み、手製全70gzipの独立再読を確認する。手製論理値の器具であり、技法の数値や有効性を検証するものではない。
