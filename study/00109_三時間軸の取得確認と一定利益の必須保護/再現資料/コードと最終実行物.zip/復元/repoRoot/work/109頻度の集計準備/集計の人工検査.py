"""保存論理だけの人工Reportで独立頻度集計を確認する。"""
from __future__ import annotations

from collections import Counter
import copy
import gzip
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

OWN=Path(__file__).resolve().parent
SPEC=importlib.util.spec_from_file_location('独立頻度集計',OWN/'集計する.py')
A=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(A)


def check(passed: bool, reason: str = '人工論理群') -> dict:
    """
    機能: 価格値を持たない保存Checkの人工を作る。
    引数: passed (bool)、reason (str) は成立と理由。
    返り値: dict は既知Check。
    """
    return {'known':True,'passed':passed,'reason':reason}


def fixture(index: int, previous_seed: dict|None = None) -> dict:
    """
    機能: T/R許可各1と待機2を持つ最小の手製頻度Reportを作る。
    引数: index (int)、previous_seed (dict|None) は人工場番号と前場識別。
    返り値: dict は人工Report。技法の有効性や数値生成を検証する器具ではない。
    """
    kind='Day' if index%2==0 else 'Night'
    start=1800000000+index*86400
    end=start+(25200 if kind=='Day' else 46800)
    sid=f'人工_{index:02d}_{kind}'
    def setup(role,foot,active):
        """
        機能: 保存構造の段階だけを作る。
        引数: role/foot (str)、active (bool) は役割・足ID・有効状態。
        返り値: dict は当足イベントを持つ構造。
        """
        return {'phase':'突破済み' if role=='T' else '確認済み','event':'突破' if role=='T' else '反対側突破','reason':'人工構造','event_bar_id':foot,'active':active}
    rows=[];births=[]
    for i,side in enumerate((1,-1)):
        at=start+1200+300*i;identity=f'snapshot{i}';foot=f'five{i}'
        empty={'phase':'','event':'','reason':'','event_bar_id':'','active':False}
        state={'last_five_id':foot,'trend':[setup('T',foot,True) if i==0 else dict(empty),dict(empty)],'reversal':[dict(empty),setup('R',foot,False) if i==1 else dict(empty)]}
        decisions=[]
        for direction in (1,-1):
            allowed=direction==side;role=('T' if i==0 else 'R') if allowed else ''
            value={'candidate':{'id':f'tech{direction}','side':direction,'at':at,'entry_quote':10000,'quantity':1},'snapshot_id':identity,'policy':'ENTRY_E1','known':True,'allowed':allowed,'status':'許可' if allowed else '待機','role':role,'reason':'人工'+role+'成立' if allowed else '人工待機',
                   'background':[{'known':True,'direction':1,'width_seconds':width} for width in (300,900,1800)],'trend':check(role=='T'),'reversal':check(role=='R'),'trend_momentum':check(True),'reversal_momentum':check(True),'spike':check(True)}
            decisions.append(value)
        birth={'id':f'birth{i}','method':'人工Source','signal_id':f's{i}','side':side,'quantity':1,'born_at':at-20,'observed_at':at-10,'assignment':{'assigned_at':at,'strict_at':at,'deferred':False},'filled_seen':True,'cancellation_seen':False,'due_observed':True}
        births.append(birth)
        selected=copy.deepcopy(next(value for value in decisions if value['candidate']['side']==side));selected['candidate']['id']=birth['id']
        rows.append({'at':at,'primary':True,'secondary':True,'state_independent':True,'snapshot_id':identity,'quote_known':True,'quote_reason':'人工正常BBO','quote':{'quote_ok':True,'bid':9995,'ask':10000,'time':at-1},'technical_batch':{'snapshot_id':identity,'policy':'ENTRY_E1','conflict':False,'state':state,'decisions':decisions},'source_planned_batch':{'snapshot_id':identity,'policy':'ENTRY_E1','conflict':False,'state':state,'decisions':[selected]},'due_births':[birth]})
    technical={'candidates':4,'known':4,'unknown':0,'allowed':2,'wait':2,'conflicts':0,'trend_passed':1,'reversal_passed':1,'reasons':{'人工T成立':1,'人工R成立':1,'人工待機':2}}
    source={'candidates':2,'known':2,'unknown':0,'allowed':2,'wait':0,'conflicts':0,'trend_passed':1,'reversal_passed':1,'reasons':{'人工T成立':1,'人工R成立':1}}
    report={'version':1,'trial':109,'config':A.CONFIG,'session':{'id':sid,'start':start,'end':end,'eof':start+1500},'grid_rows':rows,'grids':2,'technical':technical,'source_planned':source,'technical_any_allowed_grids':2,'source_any_allowed_grids':2,'source_births':births,'input_seed':previous_seed,'end_seed':{'人工末尾':sid},'complete':True,'inputs_unchanged':True,'state_independent':True,'policy_eof_redacted':True,'financial_executed':False,'participation_calculated':False,'source_reexecuted':False}
    for prefix,stop in [('primary',end-600),('secondary',end-1800)]:
        n=A.planned(start+1200,stop);values=copy.deepcopy(technical);values['candidates']+=2*(n-2);values['unknown']+=2*(n-2);values['reasons']['EOF等により当枠未観測。未来値を補わない']=2*(n-2)
        report.update({prefix+'_planned_grids':n,prefix+'_observed_grids':2,prefix+'_unobserved_grids':n-2,prefix+'_technical':values,prefix+'_source_observed':source,prefix+'_technical_allowed_grids':2,prefix+'_source_allowed_grids':2})
    return report


class Tests(unittest.TestCase):
    """独立計数・論理群の解釈・入力認証の人工検査。"""

    def test_counts_keep_unknown_and_r_inactive(self):
        """
        機能: 計画分母の未知とActive=falseのR成立を保持する。
        引数: self (Tests) は検査器。
        返り値: None。
        """
        report=fixture(0);counts=A.scene_counts(report)
        self.assertEqual(counts['primary']['planned'],78)
        self.assertEqual(counts['primary']['technical']['unknown'],152)
        buckets={name:Counter() for name in ('reasons','groups','structure','chain','join','birth')}
        A.diagnostics(report,0,buckets)
        self.assertTrue(any(key[3]=='R' and key[4]=='確認済み' for key in buckets['structure']))
        self.assertEqual(A.group_state({'known':False,'passed':False,'reason':''},False),'共通可用性未達のため未評価')

    def test_corruption_and_future(self):
        """
        機能: 計数改変と未来出生joinを拒否する。
        引数: self (Tests) は検査器。
        返り値: None。
        """
        report=fixture(0);report['primary_technical']['unknown']+=1
        with self.assertRaisesRegex(ValueError,'候補計数差'):A.scene_counts(report)
        report=fixture(0);report['grid_rows'][0]['due_births'][0]['observed_at']=report['grid_rows'][0]['at']
        with self.assertRaisesRegex(ValueError,'先取り'):A.scene_counts(report)

    def test_whole70_artificial_io(self):
        """
        機能: 70手製Reportのgzip認証と主7980/副7700を独立再読する。
        引数: self (Tests) はtemp所有者。
        返り値: None。実市場ファイルは開かない。
        """
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);inputs=root/'人工入力';inputs.mkdir();results=[];sessions=[];seed=None
            def put(path,value):
                """
                機能: 人工metadataを保存して指紋を返す。
                引数: path (Path)、value (dict) は人工先と内容。
                返り値: dict は絶対参照。
                """
                path.write_text(json.dumps(value,ensure_ascii=False),encoding='utf-8');return {'path':str(path),'sha256':A.sha(path)}
            for index in range(70):
                report=fixture(index,seed);seed=report['end_seed'];sid=report['session']['id'];path=inputs/f'{index:05d}.json.gz'
                with gzip.open(path,'wt',encoding='utf-8') as stream:json.dump(report,stream,ensure_ascii=False)
                item={key:report[key] for key in ('grids','technical','source_planned','end_seed','primary_technical','secondary_technical','primary_source_observed','secondary_source_observed','primary_technical_allowed_grids','secondary_technical_allowed_grids','primary_source_allowed_grids','secondary_source_allowed_grids')}
                for prefix in ('primary','secondary'):
                    for key in ('planned','observed','unobserved'):item[prefix+'_'+key+'_grids']=report[prefix+'_'+key+'_grids']
                item.update(session=sid,report={'path':str(path),'sha256':A.sha(path)});results.append(item);sessions.append({'id':sid})
            manifest=put(inputs/'manifest.json',{'sessions':sessions});technique={'version':1,'trial':109,'fixed':True,**A.CONFIG,'source_manifest':manifest,'source_corpus':manifest,'source_completion':manifest};tech=put(inputs/'技法固定.json',technique)
            completion={'version':1,'trial':109,'stage':'full70','success':True,'unchanged':True,'before':{},'after':{},'financial_executed':False,'participation_calculated':False,'config':A.CONFIG,'technique_fixed':tech,'manifest':manifest,'corpus':manifest,'source_completion':manifest,'results':results};complete=put(inputs/'完成.json',completion)
            output=root/'独立集計';summary=A.aggregate(complete,tech,output)
            self.assertEqual(summary['totals']['primary']['planned'],7980);self.assertEqual(summary['totals']['secondary']['planned'],7700)
            self.assertFalse(summary['participation_calculated']);self.assertEqual(len(list(output.glob('*.csv'))),8)
            with self.assertRaisesRegex(ValueError,'未作成'):A.aggregate(complete,tech,output)


if __name__=='__main__':
    unittest.main(verbosity=2)
