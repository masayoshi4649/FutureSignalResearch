"""109の技法・時計・実行物を、成立頻度と金融の市場実行前に固定する。"""

import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / "study/00109_三時間軸の取得確認と一定利益の必須保護"
STOP_DIRS = ["三時間軸の公開器", "三時間軸の入口判定", "三時間軸の市場入力口",
             "一定利益と費用床の純状態案", "一定利益と三時間軸の保護会計",
             "三時間軸の市場接続準備", "三時間軸の市場入出力_停止型対応",
             "107保存公表の再読口_埋込対応", "109入口の頻度前検査_参照正規化",
             "109頻度要求の照合_参照正規化"]


def sha(path: Path) -> str:
    """明示code・実行物・小metadataを指紋化する。

    引数: path(Path)は明示済みファイル。原板・足CSV・市場Recordを渡さない。
    返り値: strは小文字SHA256。
    """
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path: Path) -> dict:
    """小型JSONをUTF-8で読む。

    引数: path(Path)は条件/停止/閉包のmetadata。
    返り値: dictは元の全値。
    """
    return json.loads(path.read_text(encoding="utf-8-sig"))


def ref(path: Path) -> dict:
    """実物の絶対位置と指紋を結ぶ。

    引数: path(Path)はcode/仕様/metadata/実行物。
    返り値: dictはpath/sha256。
    """
    return {"path": str(path.resolve()), "sha256": sha(path)}


def verify_code(code: dict, path: Path, expected: str) -> None:
    """異なる閉包/停止が同じファイルの別指紋を宣言していないか検査する。

    引数: code(dict)は収集済み、path(Path)/expected(str)は明示対象。
    返り値: None。不在・内容差・二重宣言差は拒否する。
    """
    path = path.resolve()
    assert sha(path) == expected, str(path)
    key = str(path)
    assert key not in code or code[key] == expected, key
    code[key] = expected


def closure(code: dict, path: Path, expected: str, binary: Path, binary_sha: str,
            target_dir: Path, target_module: str) -> None:
    """Go実選択閉包の前後不変と候補実行物を認証する。

    引数: code(dict)は結合先、path/expectedは閉包、binary/binary_shaは停止exe、target_dir/target_moduleは対象。
    返り値: None。Goや市場の実行は行わない。
    """
    assert sha(path) == expected
    value = read(path)
    assert value["成功"] and value["全選択code前後不変"]
    assert Path(value["target_dir"]).resolve() == target_dir.resolve()
    assert value["target_module"] == target_module
    assert value["候補exe"]["sha256"] == binary_sha == sha(binary)
    assert Path(value["候補exe"]["path"]).resolve() == binary.resolve()
    for item in value["files"] + value["Go5tool"]:
        verify_code(code, Path(item["path"]), item["sha256"])
    verify_code(code, path, expected)


def main() -> None:
    """人工停止後の技法と実行物を、頻度の市場読取前に一度だけ固定する。

    引数: CLIで金融/Observerの閉包path/SHAとexe/path/SHAを明示する。
    返り値: None。金融固定/金融実行/市場本文読取は行わない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    for prefix in ("market", "observer"):
        parser.add_argument("--"+prefix+"-closure", type=Path, required=True)
        parser.add_argument("--"+prefix+"-closure-sha", required=True)
        parser.add_argument("--"+prefix+"-binary", type=Path, required=True)
        parser.add_argument("--"+prefix+"-binary-sha", required=True)
    args = parser.parse_args()
    target = TRIAL / "技法条件固定.json"
    assert not target.exists()
    journal_path = ROOT / "work/109進行/現在.json"
    before_journal = read(journal_path)
    assert before_journal["市場金融実行"] is False
    assert before_journal["ライブ金融handle"] is None
    assert before_journal["保留価格と損益未読"] is True
    assert not (ROOT / "work/109頻度/先頭2場").exists()
    assert not (ROOT / "work/109市場/先頭2場").exists()
    code = {}
    closures, binaries = {}, {}
    binary_modules = {"market": ("三時間軸の市場入出力_停止型対応", "threeguardcli109"),
                      "observer": ("109入口の頻度前検査_参照正規化", "threeentryfrequency109")}
    for prefix in ("market", "observer"):
        path = getattr(args, prefix+"_closure").resolve()
        expected = getattr(args, prefix+"_closure_sha")
        binary = getattr(args, prefix+"_binary").resolve()
        binary_sha = getattr(args, prefix+"_binary_sha")
        directory, module = binary_modules[prefix]
        stopped = read(ROOT / "work" / directory / "停止.json")
        assert stopped["成功"] and stopped["市場金融実行"] == 0
        assert Path(stopped["実行物"]).resolve() == binary
        assert stopped["実行物SHA256"] == binary_sha
        assert stopped["未使用11月09本文未読"] is True
        closure(code, path, expected, binary, binary_sha, ROOT / "work" / directory,
                "github.com/masayoshi4649/SessionTradeExecuter/"+module)
        closures[prefix] = ref(path)
        binaries[prefix] = ref(binary)
    # ----------------------------------------
    # 人工部品の所有コードを含め、技法の実行前版を結合します。
    stops = [ROOT / "work" / name / "停止.json" for name in STOP_DIRS]
    for stop in stops:
        value = read(stop)
        assert value["成功"], str(stop)
        if stop.parent.name == "三時間軸の公開器":
            assert value["前後不変"] and value["コードSHA256前"] == value["コードSHA256後"]
            owned = value["コードSHA256後"]
        else:
            owned = value["所有コードSHA256"]
        assert owned, str(stop)
        for name, expected in owned.items():
            path = Path(name)
            verify_code(code, path if path.is_absolute() else ROOT / path, expected)
    plan = TRIAL / "研究条件案.json"
    draft = read(plan)
    assert draft["trial"] == 109 and draft["catalog_version"] == 6
    assert not draft["fixed"] and not draft["financial_executed"]
    assert draft["holdout"]["price_interpreted"] is False
    assert draft["holdout"]["pnl_read"] is False
    assert sha(Path(draft["holdout"]["metadata"]["path"])) == draft["holdout"]["metadata"]["sha256"]
    assert draft["clock_model"] == "csv_end_plus60_at_record_scheduler"
    expected_configs = [{"candidate": f"{entry}_{protect}", "entry_policy": entry,
                         "protection_policy": protect, "entry_timing": "B5QD", "quiet_seconds": 1200,
                         "slip_pts": slip, "delay_seconds": delay}
                        for entry in ("entry_E0", "entry_E1") for protect in ("G0", "G1", "G2")
                        for slip in (0, 5) for delay in (0, 1)]
    assert draft["configs"] == expected_configs
    baseline = draft["baseline_closure"]
    assert sha(Path(baseline["path"])) == baseline["sha256"] == "d22a5c0a9bdad7b82dfa3afa2d9d100a2ebc834b9e97291099ada1db8093c30b"
    assert read(Path(baseline["path"]))["試行完了"]
    for name in ("source_manifest", "source_corpus", "source_completion", "baseline_native_index",
                 "baseline_completion", "method_catalog"):
        assert sha(Path(draft[name]["path"])) == draft[name]["sha256"], name
    for source in (Path(__file__).resolve(), ROOT / "scripts/レポート/試行109の設定表を作る.py",
                   ROOT / "scripts/レポート/手法カタログ_版6.json",
                   ROOT / "work/109市場コードの閉包/収集する.py",
                   ROOT / "work/109頻度コードの閉包/収集する.py",
                   ROOT / "work/109進行/頻度要求を作る.py"):
        verify_code(code, source, sha(source))
    sources = [TRIAL / "README.md", TRIAL / "設定と結果.md", plan,
               TRIAL / "保留入力のファイルメタデータ.json"]
    snapshots = [(path, TRIAL / "市場前仕様" / path.name, sha(path)) for path in sources]
    assert all(not dest.exists() for _, dest, _ in snapshots)
    # ----------------------------------------
    # 全検査成功後にだけ市場前仕様と技法固定を保存します。
    for source, dest, expected in snapshots:
        dest.parent.mkdir(parents=True, exist_ok=True)
        with dest.open("xb") as stream:
            stream.write(source.read_bytes())
        assert sha(source) == sha(dest) == expected
    result = {"version": 1, "trial": 109, "fixed": True,
              "scope": "既使用70の三時間軸入口/保護・時計。成立頻度と金融の前に同時固定。採用/有効性未証明",
              "clock_model": draft["clock_model"], "quiet_seconds": 1200, "quote_max_age_seconds": 0,
              "configs": expected_configs, "observer_binary": binaries["observer"], "market_binary": binaries["market"],
              "observer_stop": ref(ROOT / "work/109入口の頻度前検査_参照正規化/停止.json"),
              "stops": [ref(path) for path in stops], "go_closures": closures, "code_sha256": code,
              "specifications": [ref(dest) for _, dest, _ in snapshots],
              "financial_executed": False, "frequency_executed": False,
              "holdout_price_unread": True, "goal_achieved": False, "adopted": False,
              **{name: draft[name] for name in ("source_manifest", "source_corpus", "source_completion", "baseline_closure", "baseline_completion", "baseline_native_index", "method_catalog")}}
    with target.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    journal = read(journal_path)
    assert journal == before_journal, "固定処理中の進行台帳変更"
    journal.update({"段階": "技法/実行物固定・成立頻度と金融は未実行", "技法固定": ref(target),
                    "市場実行物": binaries["market"], "頻度実行物": binaries["observer"], "コード数": len(code),
                    "市場金融実行": False, "ライブ金融handle": None})
    journal_path.write_text(json.dumps(journal, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(json.dumps({"技法固定": ref(target), "コード数": len(code)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
