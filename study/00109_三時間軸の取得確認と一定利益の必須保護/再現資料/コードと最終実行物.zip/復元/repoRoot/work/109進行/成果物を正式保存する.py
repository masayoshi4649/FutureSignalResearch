"""109の検算済み成果物と金融Nativeを、原板を複製せず正式保存する。"""

import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / "study/00109_三時間軸の取得確認と一定利益の必須保護"
SAVED = ROOT / "work/109保存/全70場"


def sha(path: Path) -> str:
    """明示した保存成果物だけを指紋化する。

    引数: path(Path)は金融Native又は小型成果物。
    返り値: strはSHA256。原板や共有価格CSVを渡さない。
    """
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path: Path) -> dict:
    """UTF-8 JSONを読む。

    引数: path(Path)は成功完了/検算/集計JSON。
    返り値: dictは全値。
    """
    return json.loads(path.read_text(encoding="utf-8-sig"))


def copy_exact(source: Path, target: Path, expected: str) -> dict:
    """既存正本を変えず、新しい正式保存先へ同bytes複写する。

    引数: source/target(Path)、expected(str)は明示位置と期待SHA。
    返り値: dictは正式相対位置・元参照・bytes・指紋。
    """
    assert target.resolve().is_relative_to(TRIAL.resolve()) and not target.exists()
    assert sha(source) == expected
    target.parent.mkdir(parents=True, exist_ok=True)
    with source.open("rb") as src, target.open("xb") as dst:
        shutil.copyfileobj(src, dst)
    assert sha(target) == sha(source) == expected
    return {"path": target.relative_to(TRIAL).as_posix(), "sha256": expected,
            "bytes": target.stat().st_size, "元": {"path": str(source), "sha256": expected}, "同bytes": True}


def main() -> None:
    """成功金融/保存/頻度を確認し、必要な正式データだけを保存する。

    引数: なし。固定109の全70完了を対象にする。
    返り値: None。新金融・原板/CSV/Sourceの再形成、旧試行変更を行わない。
    """
    assert not (TRIAL / "成果物").exists() and not (TRIAL / "成果物_金融").exists()
    result_path = SAVED / "結果.json"
    assert sha(result_path) == "9f413d384b7831f60e0a2a743c3f3017a16d466592c7438e8aca956cd1a54804"
    result = load(result_path)
    assert result["成功"] and result["前後不変"] and result["場数"] == 70 and result["会計数"] == 1680
    confirmation = load(SAVED / "保存会計の確認.json")
    assert confirmation["成功"] and confirmation["不一致数"] == 0 and confirmation["旧対照"] == 280
    completion = ROOT / "work/109市場/全70場/完了.json"
    assert sha(completion) == "6274447512f129133012029d3c746969d4c5ebef0575dbf9b33cf326faad7c54"
    assert load(completion)["success"]
    # ----------------------------------------
    # 閲覧用は相対資源参照を保ち、全1680取引ファイルを同bytesで保存します。
    copied = []
    for source in sorted(SAVED.iterdir()):
        assert source.is_file() and source.suffix in (".json", ".jsonl"), str(source)
        copied.append(copy_exact(source, TRIAL / "成果物" / source.name, sha(source)))
    native = []
    for row in result["Native参照"]:
        source = Path(row["native"]["path"])
        saved = copy_exact(source, TRIAL / "成果物_金融/Native" / source.name, row["native"]["sha256"])
        native.append({"session": row["session"], **saved, "会計": 24,
                       "Source公表": {key: row[key] for key in ("sidecar_header", "sidecar_records")}})
    assert len(native) == 70
    index = {"成功": True, "試行": 109, "場数": 70, "金融会計": 1680,
             "基準": "Main24の金融Nativeを同bytes保存。Source公表/原板/CSVは参照し複製しない",
             "元金融完了": {"path": str(completion), "sha256": sha(completion)},
             "Native": native}
    index_path = TRIAL / "成果物_金融/Native参照台帳.json"
    with index_path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(index, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    # ----------------------------------------
    # 完了と小集計を保存し、価格を含む全頻度Reportは重複させません。
    extra = [
        (ROOT / "work/109市場/先頭2場/完了.json", "検査/金融先頭2場.json"),
        (completion, "検査/金融全70場.json"),
        (ROOT / "work/109保存要求/全70場.json", "検査/保存実行の固定.json"),
        (ROOT / "work/109頻度/先頭2場/完成.json", "検査/頻度先頭2場.json"),
        (ROOT / "work/109頻度/全70場/完成.json", "検査/頻度全70場.json"),
        (ROOT / "work/109頻度集計/全70場/独立集計.json", "検査/頻度の独立集計.json"),
    ]
    for source, target in extra:
        copied.append(copy_exact(source, TRIAL / target, sha(source)))
    for source in sorted((ROOT / "work/109頻度集計/全70場").glob("*.csv")):
        copied.append(copy_exact(source, TRIAL / "診断/入口頻度" / source.name, sha(source)))
    receipt = {"成功": True, "試行": 109, "成果物同bytes": copied,
               "Native台帳": {"path": index_path.relative_to(TRIAL).as_posix(), "sha256": sha(index_path)},
               "Native数": len(native), "原板複写": False, "共有CSV複写": False, "Source公表複写": False,
               "市場頻度全行転記": False, "研究目標達成": False, "採用": False}
    with (TRIAL / "検査/正式保存の確認.json").open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(receipt, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"成功": True, "金融Native": len(native), "同bytes成果物": len(copied),
                      "Native台帳SHA": sha(index_path)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
