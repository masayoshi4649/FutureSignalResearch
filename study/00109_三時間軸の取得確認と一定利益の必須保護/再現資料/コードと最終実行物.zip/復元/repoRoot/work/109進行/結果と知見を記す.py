"""109の固定済み数値からMarkdown・閲覧案内・累計図を作る。"""

import csv
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / "study/00109_三時間軸の取得確認と一定利益の必須保護"
CSV_DIR = ROOT / "outputs/01a1889f-f2af-7943-a047-543275ee9ed2/109損益CSV"
LABELS = {"entry_E0_G0": "元の入口＋旧保護（固定対照）", "entry_E0_G1": "元の入口＋一定利益の必須保護",
          "entry_E0_G2": "元の入口＋必須保護・可変幅", "entry_E1_G0": "三時間軸の入口＋旧保護",
          "entry_E1_G1": "三時間軸の入口＋必須保護", "entry_E1_G2": "三時間軸の入口＋必須保護・可変幅"}


def read(path: Path) -> dict:
    """UTF-8の固定正本を読む。

    引数: path(Path)は保存検算後のJSON。
    返り値: dictは全値。
    """
    return json.loads(path.read_text(encoding="utf-8-sig"))


def table(headers: list[str], rows: list[list[str]]) -> str:
    """単位を見出しに持つMarkdown表を作る。

    引数: headers(list[str])、rows(list[list[str]])は列と行。
    返り値: strは共通幅の表。
    """
    assert all(len(row) == len(headers) for row in rows)
    return "\n"+"\n".join("| "+" | ".join(row)+" |" for row in [headers, ["---"]*len(headers), *rows])+"\n\n"


def summary(value: dict) -> str:
    """主費用C0D0の六複合候補を同じ定義で表示する。

    引数: value(dict)は正本結果。
    返り値: strは純額・勝率・DD・参加・利益後赤字の比較。
    """
    rows = []
    for candidate, label in LABELS.items():
        a = value["集計"][candidate+"_C0_D0"]
        activity = a["活動主表"]
        rows.append([candidate, label, f"{a['net_yen']:+,}", str(a["positions"]),
                     f"{100*a['positive_positions']/a['positions']:.2f}%", f"{a['保存点連結時価DD']:,}",
                     f"{100*activity['active']/activity['denom']:.2f}%", str(a["unit_positive_closed_negative"])])
    return table(["候補", "条件", "費用後純額・円", "新規件数", "費用後プラスの割合", "保存点時価DD・円", "主参加率", "一度費用後正益→赤字"], rows)


def plot(value: dict) -> None:
    """同じ入口の三保護について実現純額の累計図を一枚作る。

    引数: value(dict)は全70の保存正本。
    返り値: None。未参加/退出後の仮想利益は描かない。
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.font_manager import FontProperties
    font = FontProperties(fname="C:/Windows/Fonts/meiryo.ttc")
    plt.rcParams["font.family"] = font.get_name()
    fig, ax = plt.subplots(figsize=(10, 4.5), layout="constrained")
    for guard, label, color in [("G0", "旧保護", "#234f83"), ("G1", "一定利益で必須起動", "#cb752c"), ("G2", "必須起動＋可変幅", "#377e5b")]:
        key = "entry_E0_"+guard+"_C0_D0"
        rows = sorted((r for r in value["場別"] if r["key"] == key), key=lambda r: r["session"])
        total, curve = 0, [0]
        for row in rows:
            total += row["net_yen"]
            curve.append(total/10000)
        assert total == value["集計"][key]["net_yen"] and len(rows) == 70
        ax.plot(range(71), curve, label=f"{label}：{total:+,}円", color=color, linewidth=2)
    ax.axhline(0, color="#888888", linewidth=.7)
    ax.set(title="同じ入口で利益保護を変えた実現収支（C0D0・既使用70セッション）", xlabel="セッションの時系列順", ylabel="累計純損益（万円）")
    ax.grid(alpha=.2)
    ax.legend(loc="upper left", fontsize=9)
    target = TRIAL / "図/同じ入口の実現累計.png"
    target.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(target, dpi=150)
    plt.close(fig)


def settings(value: dict) -> None:
    """市場前の全56×9表を保ち、複合評価24行だけを実績へ更新する。

    引数: value(dict)は保存検算済み正本。
    返り値: None。固定した市場前原本や指標単独の成績を変更しない。
    """
    text = (TRIAL / "市場前仕様/設定と結果.md").read_text(encoding="utf-8")
    text = text.replace("2026-11-09。市場結果前の設定記入。人工検査済みの部品があるが、新しい市場損益は未計算、採用・目標達成は未確認。金融条件の固定記録とは分ける。",
                        "2026-11-09。全70・1680会計の金融/独立保存と純頻度を検査済み。新候補の採用なし。市場前原本は市場前仕様/設定と結果.mdに保持する。")
    text = re.sub(r"(R[0-9〜/]+)・未検証", r"\1・複合評価済", text)
    text = text.replace("金額・回数・参加率は金融と保存検査の完了後に追記し、未実行を0円や成功としない。",
                        "金額・回数・参加率は全70金融/独立保存の正本から記入した。0取引場も残す。")
    lines = text.splitlines()
    for i, line in enumerate(lines):
        match = re.match(r"^\| R(\d{2}) \|", line)
        if not match:
            continue
        index = int(match.group(1))-1
        key = value["主key"][index]
        a = value["集計"][key]
        cells = line.strip("| ").split(" | ")
        assert len(cells) == 8
        cells[4:] = ["70場／7,980枠", f"{a['net_yen']:+,}円", f"{a['unit_positive_closed_negative']}件／DD {a['保存点連結時価DD']:,}円",
                     f"{100*a['活動主表']['active']/7980:.2f}%（{a['活動主表']['active']}/7980）"]
        lines[i] = "| "+" | ".join(cells)+" |"
    text = "\n".join(lines)+"\n"
    text += "\n## 実行後の知見\n\n[全結果と限界](README.md)、[費用後CSV](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/109損益CSV/README.md)、[純頻度の独立集計](検査/頻度の独立集計.json)を参照。市場前表を作る旧生成コードは固定履歴で、現在の結果表を上書きしない。本表の結果欄は`work/109進行/結果と知見を記す.py`で正本から再生成する。複合評価済みは、各指標単独の効果を検証したという意味ではない。\n"
    (TRIAL / "設定と結果.md").write_text(text, encoding="utf-8")


def main() -> None:
    """検算済み正本だけから資料・閲覧案内・共通知見を生成する。

    引数: なし。固定109の70場を対象にする。
    返り値: None。新金融・指標形成・閾値変更を行わない。
    """
    result_path = TRIAL / "成果物/結果.json"
    assert hashlib.sha256(result_path.read_bytes()).hexdigest() == "9f413d384b7831f60e0a2a743c3f3017a16d466592c7438e8aca956cd1a54804"
    value = read(result_path)
    assert value["成功"] and value["前後不変"] and value["会計数"] == 1680
    a, b = value["集計"]["entry_E0_G0_C0_D0"], value["集計"]["entry_E0_G2_C0_D0"]
    body = summary(value)
    shared = "新しい早期保護は、一度費用後利益があった後の赤字を188件から57件へ減らし、保護起動後の赤字も30件から0件へ減らした。一方、実利益総額は6,283,041円から2,191,254円へ、実損失総額は−4,109,424円から−2,518,637円へ変わり、純額は2,501,000円悪化した。勝率は入口の精度だけを表さず、出口を変えても動く。\n\n"
    shared += "全24比較で実入口・枚数・気配・Sourceが一致することを確認した。C0D0のG0→G1では、負から勝へ変わった131件が＋1,863,000円改善した。一方、両方で勝った203件の実現益は−4,383,000円変わり、総額は−2,520,000円となった。G2も負→勝の改善＋1,867,000円に対し、両勝群の実現差が−4,368,000円だった。G1/G2の起動328件は初床がすべて10ptで、初回自己保護要求が最低床だったのは267/277件、259/290件。要求までの中央値は21秒、25秒だった。これは保存点に基づく説明で、新しい起動水準の検証結果ではない。\n\n"
    shared += "入口E1の複合条件は全7,980枠のうち46枠で成立（T36/R16、同時成立6を重複計上しない）。Source予定558候補と重なったのは3件で、実新規も3件。これは30分線だけの効果を分離した比較ではない。全買売候補15,960件のうち既知12,928・未知3,032、技術成立頻度と新規＋保有の参加率は別である。\n\n"
    shared += "11/06はC0D0の旧保護がデイ−100,388円・ナイト−42,232円、G2がデイ−45,388円・ナイト＋37,768円。改善しても日夜合計は−7,620円で、全期間も赤字だった。E1の11/06は0取引であり、入口改善の証明にはしない。\n\n"
    next_steps = "次は三時間軸を背景として維持し、確認イベントが一度起きたことと現在も有効な前提を区別する。Sourceの一出生一回取得と、足終+60秒の確認時計の組合せも別に比較する。利益保護は必須のまま、起動時に費用床まで残せる戻り幅が通常の値幅より小さくなりすぎない水準を技術的な値幅と結ぶ。現在の閾値を結果へ合わせて書き換えず、別試行で検証する。\n\n"
    next_steps += "未参加・退出後の仮想利益やMFE回収率は評価しない。手法間の実現額比較は残す。新候補は採用せず、11/09 Dayの価格・損益は未読で保持する。\n\n"
    text = "# 00109：三時間軸の取得確認と一定利益の必須保護\n\n全70・1,680会計の金融、独立保存、純頻度、CSV再読を完了。コード保存・Viewer確認・試行の閉鎖は別の確認記録へ残す。新候補の採用なし、研究目標は未達。\n\n"
    text += "[設定と結果](設定と結果.md) / [集計CSV](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/109損益CSV/候補別集計.csv) / [全セッションCSV](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/109損益CSV/全セッション.csv) / [Viewer一覧](成果物/一覧.resources.json)\n\n"
    text += "## 仮説・入力・固定\n\n30分の背景、15分の押戻し、5分の取得確認と、一定利益での必須保護を比較した。元Sourceは106の既使用70場（2026-09-21〜11-06、夜間は開始日で表記）。miniは可変数量・各側最大10枚、100円/pt、片道税込38.5円。開始/米国開始20分静観、strict次5分と静観明け一回繰越、主分母は開始+20分〜予定末尾10分前の7,980枠、副は末尾30分前まで7,700枠。未知や待機を分母から落とさない。\n\n"
    text += "C0はラージBBO代理と手数料、C5はさらに片道5pt追加滑り、D1は価格時計1秒の仮定。CSVの足終+60秒をRecord.Atで公表するモデルで、実通信遅延ではない。入口E0/E1×保護G0/G1/G2×4費用の24設定。売買は同じ符号反転条件。固定済み108 Q0とE0/G0のBook/Width/Clock280比較は全同体。\n\n"
    text += "[技法固定](技法条件固定.json)、[金融条件](金融条件.json)、[市場前原本](市場前仕様/README.md)、[実行順序だけの変更](実行順序の変更.json)を保持。条件を先に固定し、成功first2の後、全70純頻度と金融を独立に並行した。新候補の閾値は途中変更していない。\n\n"
    text += "## 主費用C0D0の結果\n\n各行は独立した候補であり合算しない。費用後プラスの割合の分母は成立した新規件数。\n"+body
    text += "![同じ入口の累計](図/同じ入口の実現累計.png)\n\n## 分かったこと\n\n"+shared
    text += "C0D0でG1/G2は466件・979枚、参加はそれぞれ12.03%/9.75%。E1は0.14〜0.15%。全体25%を満たしたのは旧保護E0/G0の4費用だけで、50%は全24未達。夜間単独25%も全24未達。\n\n"
    text += "## 次の問いと限界\n\n"+next_steps
    text += "24設定は同じ市場を使った探索で、独立な24回の実証ではない。mini実板・実約定は未検証。独立保存は全約定・所有・費用・保存点MTM/DD・入口と保護の保存根拠までで、全指標や全tickの別engine再現とは呼ばない。\n\n"
    text += "[保存正本](成果物/結果.json) / [保存検算](成果物/保存会計の確認.json) / [金融全70](検査/金融全70場.json) / [純頻度の独立集計](検査/頻度の独立集計.json) / [同入口の出口診断](診断/同入口の出口比較/README.md) / [Native参照](成果物_金融/Native参照台帳.json)\n\n再現とコード保存は再現.mdへ接続する。市場前生成表と現在の結果表を区別する。\n"
    (TRIAL / "README.md").write_text(text, encoding="utf-8")
    settings(value)
    plot(value)
    # ----------------------------------------
    # 閲覧案内と共通知見は正本の数値を参照し、別の成績を捏造しません。
    guide = "# 109の損益CSV\n\nまず[候補別集計](候補別集計.csv)で条件IDを選び、[全セッション](全セッション.csv)を同じ条件IDで絞り込む。24行の独立条件と1,680行の全セッションを保持する。0取引行も削除しない。\n\n"
    guide += table(["候補", "意味"], [[key, label] for key, label in LABELS.items()])
    guide += "主比較は`C0_D0`。固定対照は`entry_E0_G0_C0_D0`（純額＋2,173,617円）。新G1/G2は利益後赤字を減らしたが全体純額は赤字となり、三時間軸の新入口E1は3件だけだった。新案の採用はない。C5/D1を最良順に足し合わせない。\n\n"
    guide += "金額は円、参加率は0〜100のパーセント。累計は条件IDごとに70場の時系列。ナイトの日付は開始日で、11/06ナイトには11/07早朝を含む。主判断枠は開始20分後〜末尾10分前、未知・欠測・米国静観も分母に残す。保有又は同枠実新規が参加。\n\n"
    guide += "mini100円/pt・片道38.5円。C0はラージBBO、C5は追加5pt/片道、D1は価格時計1秒の仮定。各側最大10枚。投下資金不明のROIや機会損失は計算しない。\n\n"
    guide += "[研究報告](../../../study/00109_三時間軸の取得確認と一定利益の必須保護/README.md) / [CSV再読検算](CSVの確認.json)\n\n原本は研究報告内の成果物/結果.json（SHA256 `9f413d384b7831f60e0a2a743c3f3017a16d466592c7438e8aca956cd1a54804`）。artifact-toolで純額・累計・参加率を再計算し、CSV再読で全1,680行・24集計・10,080数値を独立照合した。\n"
    (CSV_DIR / "README.md").write_text(guide, encoding="utf-8")
    common = "# 三時間軸と一定利益保護の比較結果\n\n2026-11-09。試行109の既使用70場。長期追加だけの効果とはせず、複合入口と利益保護を分けた。\n\n"
    common += "主費用C0D0の比較。\n"+body+shared+next_steps
    common += "[試行109の条件・全結果・再現](../../study/00109_三時間軸の取得確認と一定利益の必須保護/README.md) / [入口の役割](5分15分30分で入口の環境と確認を分ける.md) / [増分と維持の再調査](外部再調査/強さの持続とオシレーターの増分を分ける.md)\n"
    (ROOT / "docs/議論/三時間軸と一定利益保護の比較結果.md").write_text(common, encoding="utf-8")
    print("109の設定24結果・主比較・閲覧案内・累計図を正本から生成しました")


if __name__ == "__main__":
    main()
