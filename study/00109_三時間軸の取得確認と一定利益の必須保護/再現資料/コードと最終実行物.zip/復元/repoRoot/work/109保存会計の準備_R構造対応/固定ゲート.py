"""Rootの事後固定と成功completionを、金融Native本文より前に検査する。"""

from pathlib import Path
import types

import 集計 as S


def dependency_paths():
    """機能: 実際に再用する保存器のPython依存を列挙する。

    引数: なし。
    返り値: list[Path]は自作全pyと再帰的な旧module/関数の実ファイル。
    """
    paths = set(Path(__file__).resolve().parent.glob('*.py'))
    queue, seen = [S.A.OLD], set()
    while queue:
        obj = queue.pop()
        if id(obj) in seen:
            continue
        seen.add(id(obj))
        if isinstance(obj, (types.ModuleType, types.SimpleNamespace)):
            name = getattr(obj, '__file__', None)
            if name and Path(name).resolve().is_relative_to(S.ROOT):
                paths.add(Path(name).resolve())
            for child in vars(obj).values():
                if isinstance(child, (types.ModuleType, types.SimpleNamespace)):
                    child_path = getattr(child, '__file__', None)
                    if isinstance(child, types.SimpleNamespace) or child_path and Path(child_path).resolve().is_relative_to(S.ROOT):
                        queue.append(child)
                elif isinstance(child, types.FunctionType):
                    p = Path(child.__code__.co_filename)
                    if p.is_file() and p.resolve().is_relative_to(S.ROOT):
                        paths.add(p.resolve())
    return sorted(paths)


def bind(ref, base, before):
    """機能: FileRefの全bytesを認証して前指紋へ加える。

    引数: ref(dict)、base(Path)、before(dict)は参照・相対基準・指紋台帳。
    返り値: Pathは実体の絶対path。
    """
    S.need(set(ref) in ({'path', 'sha256'}, {'path', 'sha256', 'bytes'}) and S.OLD.SAVED.sha_valid(ref['sha256']), '固定FileRefの型')
    path = (base / ref['path']).resolve()
    S.equal(S.digest(path), ref['sha256'], 'FileRef全bytes指紋')
    if 'bytes' in ref:
        S.equal(path.stat().st_size, ref['bytes'], 'FileRef容量')
    S.need(str(path) not in before or before[str(path)] == ref['sha256'], '同pathの二指紋禁止')
    before[str(path)] = ref['sha256']
    return path


def validate_completion(condition, complete, manifest, stage, condition_sha):
    """機能: 同条件Main24成功と対象全場をNative本文前に認証する。

    引数: condition/complete/manifest(dict)、stage/condition_sha(str)は固定metadata。
    返り値: list[dict]は順序付きSceneResult。
    """
    S.need(stage in ('first2', 'full70'), '109のstage')
    n = 2 if stage == 'first2' else 70
    S.need(condition['version'] == 1 and condition['trial'] == 109 and condition['fixed'] is True, '109事前固定')
    S.equal(condition['configs'], list(S.declared_configs().values()), 'CSV互換の固定24設定')
    S.equal(condition['source_scope'], 'recorded_public_106', '106保存入力の再用')
    S.equal(condition['clock_model'], 'csv_end_plus60_at_record_scheduler', '109公表時計')
    ids = [r['id'] for r in manifest['sessions']]
    S.need(len(ids) == len(set(ids)) == 70 and ids == sorted(ids), '同70場の時系列')
    S.need(complete['version'] == 1 and complete['trial'] == 109 and complete['stage'] == stage and complete['success'] is True and not complete.get('error'), '109成功完了が必要')
    S.equal(complete['condition_sha256'], condition_sha, '完了と同じ金融条件')
    S.equal((complete['sessions'], complete['books_per_scene'], complete['books'], complete['shadow_books'], complete['baseline_comparisons']), (n, 24, n * 24, 0, n * 4), 'Main24/旧対照4/shadow0の区別')
    S.need(complete['unchanged'] and complete['before'] and complete['before'] == complete['after'], '金融前後不変')
    for name in ('source_scope', 'clock_model'):
        S.equal(complete[name], condition[name], '金融責務.' + name)
    flags = {'source_reexecuted': False, 'source_features_recomputed': False, 'charts_recomputed': False, 'bank_recomputed': False, 'cmp_recomputed': True, 'entry_candle_recomputed': True, 'new_series_bank_formed': True, 'protection_v5_formed': True, 'financial_executed': True, 'raw_market_read': False, 'raw_copied': False, 'csv_copied': False, 'csv_regenerated': False}
    for name, expected in flags.items():
        S.need(complete[name] is expected, '金融/形成の責務.' + name)
    tasks = complete['results']
    S.equal([r['session'] for r in tasks], ids[:n], '対象集合と順序')
    for row in tasks:
        S.need(row['books'] == 24 and row['shadow_books'] == 0 and row['baseline_comparisons'] == 4 and row['baseline_all'] and row['prior_reference_books'] == 12 and row['prior_reference_unchanged'] and row['end_seed_equal'] and row['expected_end_seed'] == row['actual_end_seed'] and row['financial_executed'] and row['unchanged'] and row['before'] == row['after'] and not row.get('error'), '各場Main24と旧保存参照12/種/指紋成功')
    return tasks


def prepare(fixed_path, fixed_sha, output):
    """機能: Root固定/停止code/金融成功/先頭2→70を認証し、実Native参照を解決する。

    引数: fixed_path/output(Path)、fixed_sha(str)はRoot固定と未使用先。
    返り値: tupleはtask・前指紋・固定証拠・完了。原板/CSV本文は読まない。
    """
    S.need(not output.exists() and S.digest(fixed_path) == fixed_sha, 'Root固定SHAと未使用出力先')
    fixed = S.load(fixed_path)
    S.need(fixed['version'] == 1 and fixed['trial'] == 109 and fixed['fixed'] is True, '109事後固定')
    before = {str(fixed_path): fixed_sha}
    condition_path = bind(fixed['condition'], fixed_path.parent, before)
    completion_path = bind(fixed['completion'], fixed_path.parent, before)
    own = {str(p): S.digest(p) for p in dependency_paths()}
    S.equal(fixed['code_sha256'], own, '実保存器と全再用依存の固定')
    before.update(own)
    condition, complete = S.load(condition_path), S.load(completion_path)
    S.need(condition['trial'] == 109 and condition['fixed'] and complete['success'], '未成功は本文より前に拒否')
    base = condition_path.parent
    refs = {name: bind(condition[name], base, before) for name in ('source_manifest', 'source_corpus', 'source_completion', 'baseline_closure', 'baseline_completion', 'baseline_native_index', 'binary')}
    if 'technique_fixed' in condition:
        bind(condition['technique_fixed'], base, before)
    for ref in condition['stops'] + condition['specifications']:
        bind(ref, base, before)
    for name, sha in condition['code_sha256'].items():
        p = (base / name).resolve()
        S.equal(S.digest(p), sha, '金融固定code')
        S.equal(complete['before'].get(str(p)), sha, '実金融使用code')
        before[str(p)] = sha
    manifest = S.load(refs['source_manifest'])
    tasks = validate_completion(condition, complete, manifest, fixed['stage'], fixed['condition']['sha256'])
    ids = [r['id'] for r in manifest['sessions']]
    old, index, source = (S.load(refs[name]) for name in ('baseline_completion', 'baseline_native_index', 'source_completion'))
    S.need(old['trial'] == 108 and old['success'] and old['stage'] == 'full70' and old['unchanged'], '旧108の成功完了')
    S.need(index['成功'] and index['試行'] == 108 and index['場数'] == 70 and index['金融会計'] == 840, '旧108正式Native台帳')
    S.equal([r['session'] for r in old['results']], ids, '旧108同70集合')
    S.equal([r['session'] for r in index['Native']], ids, '旧108正式台帳の同70集合')
    S.equal(index['元金融完了']['sha256'], condition['baseline_completion']['sha256'], '旧108台帳と金融完了の結合')
    S.need(source['trial'] == 106 and source['success'] and source['stage'] == 'full70' and source['unchanged'], '完成106入力')
    S.equal([r['session'] for r in source['results']], ids, '106同70集合')
    data_root = (refs['source_manifest'].parent / manifest['source_root']).resolve()
    resolved = []
    for i, row in enumerate(tasks):
        r = {name: bind(row[name], completion_path.parent, before) for name in ('native', 'sidecar_header', 'sidecar_records', 'prior_native', 'csv')}
        prior_index = index['Native'][i]
        S.equal(row['prior_native']['sha256'], prior_index['sha256'], '正式旧108 Native原値')
        S.equal(row['prior_native']['sha256'], old['results'][i]['native']['sha256'], '旧108成功完了由来')
        for name in ('sidecar_header', 'sidecar_records'):
            S.equal(row[name]['sha256'], source['results'][i][name]['sha256'], '106公表出典を無変更')
        S.need(row['before'] and all(S.digest(Path(name)) == sha for name, sha in row['before'].items()), 'Scene入力/コード現在不変')
        before.update(row['before'])
        market = (data_root / manifest['sessions'][i]['files']['NK225_book']['path']).resolve()
        resolved.append({**row, 'resolved': r, 'market_path': str(market), 'input': manifest['sessions'][i]})
    if fixed['stage'] == 'full70':
        first_path = bind(complete['first2'], completion_path.parent, before)
        first = S.load(first_path)
        validate_completion(condition, first, manifest, 'first2', fixed['condition']['sha256'])
        for i in range(2):
            for name in ('native', 'sidecar_header', 'sidecar_records', 'prior_native', 'csv'):
                S.equal(first['results'][i][name]['sha256'], tasks[i][name]['sha256'], '同条件先頭2→70の原値')
    return resolved, before, {'Root固定SHA256': fixed_sha, '金融条件SHA256': fixed['condition']['sha256'], '金融完了SHA256': fixed['completion']['sha256']}, complete
