"""109の保存された保護根拠を、会計とは別に独立した式で照合する。"""

from decimal import Decimal
import math
import re


def require(condition, message):
    """機能: 独立監査の不一致を拒否する。

    引数: condition(bool)、message(str)は成立条件と説明。
    返り値: None。不一致ではValueError。
    """
    if not condition:
        raise ValueError(message)


def equal(actual, expected, message):
    """機能: 数値型に依存しない完全な値一致を要求する。

    引数: actual/expected(any)、message(str)は比較値と説明。
    返り値: None。不一致ではValueError。
    """
    require(actual == expected, message + f": {actual!r} != {expected!r}")


def ceil5(value):
    """機能: 固定式の5pt切上げを行う。

    引数: value(number)は価格差。
    返り値: intは5pt格子の価格差。
    """
    return 5 * math.ceil(float(value) / 5)


def evidence(value, at, minimum=0):
    """機能: 保存尺度の識別と利用時点までの公表時計を確認する。

    引数: value(dict|None)、at(number)、minimum(number)は尺度・利用時点・下限。
    返り値: None。未知を捏造しない。
    """
    if value is not None:
        require(value['source_id'] and at >= value['available_at'] > 0 and value['value'] > 0 and value['value'] >= minimum, '公開尺度')


def source(value, at):
    """機能: 3分公表の出典を保存点の時刻へ結合する。

    引数: value(dict|None)、at(number)はSourceと利用時計。
    返り値: None。公表未取得のNoneを許す。
    """
    if value is not None:
        require(value['publication_id'] and 0 < value['delivered_at'] <= at, '保護Sourceの公開時計')
        require(all(re.fullmatch('[0-9a-f]{64}', value[k]) for k in ('frame_sha256', 'result_sha256')), '保護Sourceの全値指紋')


def warning(c, m, p):
    """機能: M AND (C OR P)の三値論理を独立に計算する。

    引数: c/m/p(int)は0未知・1偽・2真。
    返り値: intは警戒の三値。
    """
    require(all(x in (0, 1, 2) for x in (c, m, p)), '三値enum')
    disjunction = 2 if 2 in (c, p) else 1 if c == p == 1 else 0
    return 1 if 1 in (m, disjunction) else 2 if m == disjunction == 2 else 0


def snapshot(value, entry, at, scope):
    """機能: 固定新規とH/費用床/公開時計/保護床の下限を照合する。

    引数: value/entry/scope(dict)、at(number)は純状態・固定新規・場・利用時計。
    返り値: None。保存点間の未保存tickを再現したとは扱わない。
    """
    equal(value['entry'], entry, '固定新規の不変')
    equal(entry['scope'], scope, '保護の場と限月')
    equal(value['at'], at, '純状態の時計')
    cost = Decimal('.77') + 2 * entry['slip_points']
    expected_h = ceil5(max(20, 2 * cost, Decimal('.25') * entry['entry_v']['value'] if entry['entry_v'] else 0))
    for key, expected in (('cost_points', cost), ('threshold_points', expected_h), ('fee_floor', ceil5(cost)), ('minimum_floor', ceil5(cost + 5)), ('entry_v_fallback', entry['entry_v'] is None)):
        equal(value[key], expected, '固定導出式.' + key)
    evidence(entry['entry_v'], entry['at'], 5)
    evidence(entry['atr'], entry['at'])
    evidence(value['atr'], at)
    if entry['atr'] is not None:
        equal(value['atr'], entry['atr'], '新規時ATRの固定')
    require(0 <= value['reserved'] <= value['remaining'] <= entry['initial_quantity'] <= 10, '純状態の所有と予約')
    if value['latest_publication'] is not None:
        p = value['latest_publication']
        equal(p['scope'], scope, '3分公表scope')
        require(p['id'] and p['ordinal'] > 0 and scope['start'] < p['end'] <= p['available_at'] <= at and (p['end'] - scope['start']) % 180 == 0, '3分公表時計')
        require(p['v'] is None or p['v'] >= 5, 'Vの下限')
        pivot = p['prior_pivot']
        if pivot is not None:
            equal(pivot['scope'], scope, 'prior pivot scope')
            equal(pivot['kind'], 'low' if entry['side'] > 0 else 'high', 'prior pivot risk側')
            require(pivot['id'] and scope['start'] < pivot['center_end'] and pivot['confirm_end'] == pivot['center_end'] + 360 and pivot['confirm_end'] <= pivot['published_at'] < p['available_at'] and pivot['confirm_end'] < p['end'], 'prior pivotは公表前の右2本確認')
    if value['active']:
        require(entry['at'] <= value['activated_at'] <= at and value['floor_points'] >= value['minimum_floor'] and value['peak_points'] is not None, '一定利益後の最低費用床')
        if value['width_points'] is not None:
            require(value['width_points'] > 0 and value['width_points'] % 5 == 0 and value['floor_points'] >= value['peak_points'] - value['width_points'], '保存保護床はpeak−幅以上')
    else:
        require(all(value[k] is None for k in ('activated_at', 'floor_points', 'width_points')), '起動前nullable')
    require(value['narrowed'] == (value['narrowed_at'] is not None), '狭幅旗と時計')
    require(not value['narrowed'] or entry['policy'] == 'G2' and value['active'] and value['activated_at'] <= value['narrowed_at'] <= at, '狭幅はG2起動後')


def expected_width(state):
    """機能: G1/G2の現在選択幅を独立式で求める。

    引数: state(dict)は起動済み保存純状態。
    返り値: tuple[number|None,str]は幅と固定された由来名。
    """
    a = state['atr']['value'] if state['atr'] else None
    p = state['latest_publication']
    v = p['v'] if p else None
    if state['entry']['policy'] == 'G1':
        return (ceil5(2 * a), 'G1_旧2ATR') if a is not None else (None, 'G1_ATR不明_費用床のみ')
    if a is None and v is None:
        return state['width_points'], 'G2_両不明_既存幅保持'
    if state['narrowed']:
        if a is not None and v is not None:
            return ceil5(max(10, min(a, v))), 'G2_狭幅_minATR_V'
        return (ceil5(max(10, v)), 'G2_狭幅_V') if v is not None else (ceil5(max(10, a)), 'G2_狭幅_ATR')
    if a is not None and v is not None:
        return ceil5(max(15, min(2 * a, 2 * v))), 'G2_通常_min2ATR_2V'
    return (ceil5(max(15, 2 * v)), 'G2_通常_2V') if v is not None else (ceil5(2 * a), 'G2_V不明_旧2ATR')


def native_atr(position):
    """機能: Actualの固定nativeATRから純幅用の根拠を独立に射影する。

    引数: position(dict)は実玉。
    返り値: dict|Noneは生ATR・公開時計・元Available/Nominal識別。旧Widthは使わない。
    """
    atr = position['atr']
    if atr is None:
        return None
    return {'value': atr['value'], 'available_at': atr['available'], 'source_id': f"nativeATR/{float(atr['available']):.9f}/{float(atr['nominal']):.9f}"}


def step(value, position, initial, checked, scope):
    """機能: 保存stepの金額/警戒/幅/構造床/返済可能量を照合する。

    引数: value/position/initial/checked/scope(dict)はstep・玉・固定新規・独立会計・場。
    返り値: None。
    """
    point, state, decision = value['point'], value['state'], value['decision']
    entry = initial['entry']
    checked['timeline'].verify_position_point(position['id'], point)
    snapshot(state, entry, point['quote']['time'], scope)
    atr = position['atr']
    equal(state['atr'], native_atr(position) if atr is not None and point['quote']['index'] >= atr['quote']['index'] else None, '保存stepと実native生ATRの結合')
    equal(state['remaining'], point['quantity'], 'stepの残玉')
    equal(state['reserved'], point['reserved'], 'stepの自己要求前予約')
    equal(decision['gain_points'], point['gain_points'], 'step方向幅')
    equal(decision['unit_net_yen'], point['unit_net'], 'step費用後単位額')
    equal(decision['free_quantity'], point['quantity'] - point['reserved'], 'Source予約を除くfree')
    source(value['source'], point['quote']['time'])
    p = state['latest_publication']
    pivot = p['prior_pivot'] if p else None
    direction_p = 0 if p is None or p['close'] is None or pivot is None else 2 if entry['side'] * (p['close'] - pivot['price']) < 0 else 1
    equal(decision['p'], direction_p, 'prior構造の否定')
    expected_warning = warning(p['c'], p['m'], direction_p) if p else 0
    equal(decision['warning'], expected_warning, '複合警戒AND')
    if decision['activated_now']:
        require(point['unit_net'] >= 100 * state['threshold_points'] and state['activated_at'] == point['quote']['time'], 'Hへの費用後単位額到達')
    if decision['narrowed_now']:
        require(state['entry']['policy'] == 'G2' and expected_warning == 2 and state['narrowed_at'] == point['quote']['time'], '狭幅起動の複合根拠')
    structural = None
    if state['active']:
        width, origin = expected_width(state)
        equal(state['width_points'], width, 'G1/G2選択幅')
        equal(decision['width_source'], origin, '幅の出典')
        if entry['policy'] == 'G2' and expected_warning == 2 and pivot is not None and pivot['center_end'] - 180 >= entry['at']:
            candidate = entry['side'] * (pivot['price'] - entry['side'] * 5 - entry['price'])
            if candidate > state['minimum_floor']:
                structural = candidate
        if structural is not None:
            require(state['floor_points'] >= structural, '構造床を保護へ反映')
    equal(decision['structural_floor'], structural, '新規後だけのprior構造床')
    equal(decision['structural_eligible'], structural is not None, '構造床の適格旗')
    hit = state['active'] and point['gain_points'] <= state['floor_points']
    equal(decision['floor_hit'], hit, '保護床接触')
    equal(decision['eligible_exit_quantity'], decision['free_quantity'] if hit and point['phase'] == 'after_source' else 0, '自己返済はSource後の未予約残だけ')


def verify_protection(book, config, audit, checked):
    """機能: 新G1/G2の保存根拠と全自己返済要求を結合する。

    引数: book/config/audit/checked(dict)は実金融・外設定・複合監査・独立算術。
    返り値: dictは検査した保存点数/実保護要求数。
    """
    equal(audit['config'], {'entry_policy': config['entry_policy'], 'protection_policy': config['protection_policy'], 'slip_pts': config['slip_pts'], 'delay_seconds': config['delay_seconds'], 'us_open': book['session']['us_open']}, '複合設定の本名')
    equal(audit['quiet_seconds'], 1200, '20分静観の固定')
    positions = {p['id']: p for p in book['positions']}
    if config['protection_policy'] == 'G0':
        equal(audit['positions'], [], 'G0は新保護状態なし')
        return {'保存保護点': 0, '自己保護要求': 0}
    equal({p['position_id'] for p in audit['positions']}, set(positions), '取得済み全玉の新保護状態')
    seen_requests, count = set(), 0
    scope = {'session': book['session']['id'], 'contract': audit['contract'], 'start': book['session']['start']}
    for p in audit['positions']:
        actual = positions[p['position_id']]
        initial, last = p['initial'], p['last']
        entry = initial['entry']
        for key, expected in (('policy', config['protection_policy']), ('side', actual['side']), ('price', actual['entry_price']), ('at', actual['entry_quote']['time']), ('initial_quantity', actual['initial_quantity']), ('slip_points', config['slip_pts'])):
            equal(entry[key], expected, '純新規と実fill.' + key)
        snapshot(initial, entry, entry['at'], scope)
        require(initial['sequence'] == 0 and not initial['active'] and initial['remaining'] == actual['initial_quantity'] and initial['reserved'] == 0, '実取得時だけ新状態を作る')
        source(p['initial_source'], entry['at'])
        if entry['entry_v'] is not None:
            require(p['initial_source'] is not None, 'EntryVには公表出典が必要')
            equal(entry['entry_v']['source_id'], 'V5/' + p['initial_source']['publication_id'], 'EntryVの公表ID')
            require(entry['entry_v']['available_at'] <= p['initial_source']['delivered_at'] <= entry['at'], 'EntryVの公表後配送を許す時計')
        expected_atr = native_atr(actual)
        equal(entry['atr'], expected_atr if actual['atr'] is not None and not actual['atr']['after_entry'] else None, '取得時既知ATRだけをInitialへ固定')
        snapshot(last, entry, last['at'], scope)
        equal(last['atr'], expected_atr, '終端は実玉と同じ最初の既知ATR')
        require(last['finished'] and last['remaining'] == last['reserved'] == 0, '純保護状態も終端残0')
        values = [p[k] for k in ('last_step', 'activation', 'first_narrow', 'first_floor_hit', 'last_floor_update', 'first_full_reserved_hit') if p[k] is not None]
        values += [r['step'] for r in p['requests']]
        for value in values:
            step(value, actual, initial, checked, scope)
            count += 1
        ordered = sorted(values, key=lambda v: v['state']['sequence'])
        floors = [v['state']['floor_points'] for v in ordered if v['state']['active']]
        require(floors == sorted(floors), '保存された順序で保護床を不利に緩めない')
        require(not last['active'] or not floors or last['floor_points'] >= floors[-1], '終端の保護床を保持')
        equal(actual['protection_active'], last['active'], '実Actorと純起動旗')
        equal(actual['floor_gain'], last['floor_points'], '実Actorと純最終床')
        if p['activation'] is not None:
            require(p['activation']['decision']['activated_now'], '初回起動保存点')
            equal(actual['activation'], p['activation']['point'], '実Actor起動点')
        equal(last['active'], p['activation'] is not None, '起動記録の全性')
        equal(last['narrowed'], p['first_narrow'] is not None, '狭幅記録の全性')
        for point in actual['marks'].values():
            if point is not None and point['unit_net'] >= 100 * initial['threshold_points']:
                require(last['active'] and checked['timeline'] is not None, 'H到達保存点を未起動のまま放置しない')
                activation_point = p['activation']['point']
                before_order = (activation_point['quote']['index'], 0 if activation_point['phase'] == 'pre_fill' else 1)
                current_order = (point['quote']['index'], 0 if point['phase'] == 'pre_fill' else 1)
                require(before_order <= current_order, 'H到達保存点より後へ起動を遅らせない')
        for request in p['requests']:
            value = request['step']
            order = checked['orders'][request['order_id']]
            require(order['id'] not in seen_requests and order['protection_point'] == value['point'], '保護注文と一意な保存根拠')
            seen_requests.add(order['id'])
            require(value['point']['phase'] == 'after_source' and value['decision']['floor_hit'], 'Source後だけ自己保護要求')
            equal(request['requested'], value['decision']['eligible_exit_quantity'], '純未予約残と実要求')
            equal(order['quantity'], request['requested'], '実保護量')
            equal(request['reserved_before'], value['state']['reserved'], '自己要求前の純予約')
            equal(request['reserved_after'], request['reserved_before'] + request['requested'], '自己予約は一度だけ追加')
            require(request['reserved_after'] <= value['state']['remaining'], 'Sourceと自己の二重返済なし')
    equal(seen_requests, {o['id'] for o in book['orders'] if o['kind'] == 'exit' and o['protection_point'] is not None}, '全自己保護注文の保存要求結合')
    return {'保存保護点': count, '自己保護要求': len(seen_requests)}
