"""停止版の人工だけで96冊と破壊反例を検査する。"""

import copy
from decimal import Decimal
import json
from pathlib import Path
import unittest
import tempfile
import importlib.util

import 集計 as S
import 固定ゲート as G
import 新保護監査 as P
import 入口と活動の監査 as E


ART = S.ROOT / 'work/三時間軸の市場接続準備/人工_停止版'
SOURCE = ART / '方向1_saved.json'
PINS = {
    '方向1_saved.json': '3bcec9031e018f3d34ef062a33393a3dd49dd66040773a2ce3955fd91090417f',
    '方向1_fresh.json': 'e5590cbe952b24f97d9784c97b7bc4bf0e272438ad22687919c87696a1b0a69d',
    '方向-1_saved.json': '8dd982f3912a9770502014e545404288d6bda85dc6294aece4db6077064d7c41',
    '方向-1_fresh.json': 'dfc6ac41dc45214835672241374d88bd93a44730a89821685bfe12b50be48075',
}
R_SOURCE = S.ROOT / 'work/109R保存監査の人工出典/正規R.json'
R_SHA = '198da8719d9723027618c90d47e575e477e527dfcdbd0ce0f876caa4f2c7ca52'
EXTRA_PINS = {
    str(R_SOURCE): R_SHA,
    str(R_SOURCE.parent / 'go.mod'): '009959a81bc8f797b4940cdfffb058144dc149249f7d5fddd8044f8ed46d57ed',
    str(R_SOURCE.parent / 'main.go'): 'c10f2c3101bbb93cb9ebb8711e89baf16b713866ef02397c448a5c492e4da4f8',
    str(R_SOURCE.parent / '作成する.py'): '6622e414475334e8410903d3e4c9df7dd364237eb703ea83807ddd01b710f076',
    str(S.ROOT / 'work/三時間軸の入口判定/entry_test.go'): '9badd907df628632b19cbf03dace3c7533ce79b105f1b46eb0a3c3955173bf1e',
    str(S.ROOT / 'work/三時間軸の入口判定/停止.json'): '834aedc70a31d5f0d7e2bee9ae6fc9d22d7b3ea726924fed791b2dfec7b283f9',
    str(S.ROOT / 'work/109保存会計の準備/入口と活動の監査.py'): '2d6546b5ae920ae0526623290b6b69887dc1baeca09f40a0dcf08b57e3d9d696',
    str(S.ROOT / 'work/109保存会計の準備/停止.json'): 'a18926dd7fcaaead71a1899120dc5341a38013dfd4493cbd00e89338b67c439c',
}


def fixture():
    """機能: 停止人工の一器具を原値で読む。

    引数: なし。
    返り値: tuple[dict,str]はCore値と元字句。
    """
    S.equal(S.digest(SOURCE), PINS[SOURCE.name], '停止人工の固定SHA')
    raw = S.OLD.raw_members(S.read_text(SOURCE))['output']
    return json.loads(raw, parse_float=Decimal), raw


class 保存検査(unittest.TestCase):
    """保存会計と新監査の破損検出を確認する。"""

    def test_両方向と保存新規の全96冊(self):
        """機能: 全24非ゼロをsaved/fresh・符号反転の4器具で検算する。

        引数: self(保存検査)。返り値: None。
        """
        results = {}
        for side in (1, -1):
            for mode in ('saved', 'fresh'):
                path = ART / f'方向{side}_{mode}.json'
                before = S.digest(path)
                self.assertEqual(before, PINS[path.name])
                raw = S.OLD.raw_members(S.read_text(path))['output']
                data = json.loads(raw, parse_float=Decimal)
                checked = S.inspect_scene(data, raw, artificial=True)
                rows = S.scene_rows(data, checked['checked'])
                aggregate = S.aggregate(rows, 'artificial')
                self.assertEqual((len(rows), len(aggregate)), (24, 24))
                self.assertTrue(all(row['positions'] > 0 for row in rows))
                self.assertEqual(S.digest(path), before)
                results[side, mode] = {r['key']: (r['gross_yen'], r['fee_yen'], r['slip_yen'], r['net_yen'], r['活動主表']) for r in rows}
        self.assertEqual(results[1, 'saved'], results[-1, 'saved'])
        self.assertEqual(results[1, 'saved'], results[1, 'fresh'])
        self.assertEqual(results[-1, 'saved'], results[-1, 'fresh'])

    def test_会計と監査の破壊反例(self):
        """機能: 会計/未来出典/閾値/予約/候補echo等の改変を拒否する。

        引数: self(保存検査)。返り値: None。
        """
        original, raw = fixture()
        key = 'entry_E1_G2_C0_D0'
        mutations = {
            '手数料': lambda d: d['books'][key]['fills'][0].__setitem__('fee_yen', 0),
            '同原行約定': lambda d: d['books'][key]['fills'][0]['quote'].__setitem__('source_line', d['books'][key]['orders'][0]['request_quote']['source_line']),
            '旧key偽装': lambda d: d['books'][key].__setitem__('key', 'P0_C0_D0'),
            'Hの改変': lambda d: d['composite_audits'][key]['positions'][0]['last'].__setitem__('threshold_points', 5),
            '費用床0': lambda d: d['composite_audits'][key]['positions'][0]['activation']['state'].__setitem__('minimum_floor', 0),
            'G2をnative2Aと混同': lambda d: d['composite_audits'][key]['positions'][0]['activation']['state'].__setitem__('width_points', 40),
            '未来V': lambda d: d['composite_audits'][key]['positions'][0]['initial']['entry']['entry_v'].__setitem__('available_at', d['session']['end']),
            '未来pivot': lambda d: d['composite_audits'][key]['positions'][0]['last_step']['state']['latest_publication']['prior_pivot'].__setitem__('published_at', d['session']['end']),
            '未予約残以上': lambda d: d['composite_audits'][key]['positions'][0]['requests'][0].__setitem__('requested', 7),
            '二重予約': lambda d: d['composite_audits'][key]['positions'][0]['requests'][0].__setitem__('reserved_after', 12),
            'Source前要求': lambda d: d['composite_audits'][key]['positions'][0]['requests'][0]['step']['point'].__setitem__('phase', 'pre_fill'),
            '候補量変更': lambda d: d['entry_audits'][key]['nonempty_batches'][0]['decisions'][0]['candidate'].__setitem__('quantity', 7),
            '候補方向変更': lambda d: d['entry_audits'][key]['nonempty_batches'][0]['decisions'][0]['candidate'].__setitem__('side', -1),
            '未知の許可': lambda d: d['entry_audits'][key]['nonempty_batches'][0]['decisions'][0].__setitem__('known', False),
            '競合なのに片側許可': lambda d: d['entry_audits'][key]['nonempty_batches'][0].__setitem__('conflict', True),
            '量未知をgate化': lambda d: d['entry_audits'][key]['nonempty_batches'][0]['decisions'][0]['volume'][0].__setitem__('known', '未知'),
            '背景ANDをOR化': lambda d: d['entry_audits'][key]['nonempty_batches'][0]['decisions'][0]['background'][2].__setitem__('direction', -1),
            '状態期限到達': lambda d: d['entry_audits'][key]['nonempty_batches'][0]['decisions'][0]['structure'].__setitem__('expires_at', d['entry_audits'][key]['nonempty_batches'][0]['decisions'][0]['candidate']['at']),
            '枠欠落を隠す': lambda d: d['books'][key]['grid_traces'].pop(4),
            '当時保有の捏造': lambda d: d['books'][key]['grid_traces'][4].__setitem__('open_buy', 1),
            '出生再割当': lambda d: d['books'][key]['entry_opportunities'][0].__setitem__('assigned_at', d['books'][key]['entry_opportunities'][0]['assigned_at'] + 300),
            '保存の最終床緩和': lambda d: d['composite_audits'][key]['positions'][0]['last'].__setitem__('floor_points', 10),
            '純ATRの出典改変': lambda d: d['composite_audits'][key]['positions'][0]['last']['atr'].__setitem__('source_id', '別のATR'),
        }
        for label, mutate in mutations.items():
            with self.subTest(label=label):
                data = copy.deepcopy(original)
                mutate(data)
                with self.assertRaises((ValueError, KeyError, TypeError)):
                    S.inspect_scene(data, raw, artificial=True)

    def test_費用床と通常狭幅の境界(self):
        """機能: C0/C5の最低床、V欠測、幅の上下限を既知値で検査する。

        引数: self(保存検査)。返り値: None。
        """
        self.assertEqual((P.ceil5(Decimal('.77') + 5), P.ceil5(Decimal('10.77') + 5)), (10, 20))
        self.assertEqual((P.ceil5(20), P.ceil5(Decimal('20.01'))), (20, 25))
        state = {'entry': {'policy': 'G2'}, 'atr': {'value': 100}, 'latest_publication': {'v': 20}, 'narrowed': False, 'width_points': None}
        self.assertEqual(P.expected_width(state), (40, 'G2_通常_min2ATR_2V'))
        state['narrowed'] = True
        self.assertEqual(P.expected_width(state), (20, 'G2_狭幅_minATR_V'))
        state['latest_publication']['v'] = 5
        self.assertEqual(P.expected_width(state)[0], 10)
        state['latest_publication'] = None
        self.assertEqual(P.expected_width(state)[0], 100)
        state['atr'] = None
        state['width_points'] = 35
        self.assertEqual(P.expected_width(state), (35, 'G2_両不明_既存幅保持'))

    def test_未知を保つ三値警戒(self):
        """機能: MとC/PのAND境界を独立な論理期待値で確認する。

        引数: self(保存検査)。返り値: None。
        """
        self.assertEqual(P.warning(2, 1, 2), 1)
        self.assertEqual(P.warning(1, 2, 1), 1)
        self.assertEqual(P.warning(0, 2, 1), 0)
        self.assertEqual(P.warning(2, 2, 0), 2)
        self.assertEqual(P.warning(0, 2, 2), 2)
        self.assertEqual(P.warning(1, 0, 1), 1)

    def test_実保存入口は未固定成功を拒否(self):
        """機能: Root固定/成功completionなしで本文へ進まないことを確認する。

        引数: self(保存検査)。返り値: None。
        """
        condition = {'version': 1, 'trial': 109, 'fixed': False}
        with self.assertRaises(ValueError):
            G.validate_completion(condition, {}, {}, 'full70', '0' * 64)
        condition['fixed'] = True
        condition.update(configs=list(S.declared_configs().values()), source_scope='recorded_public_106', clock_model='csv_end_plus60_at_record_scheduler')
        manifest = {'sessions': [{'id': f'人工{i:02d}'} for i in range(70)]}
        complete = {'version': 1, 'trial': 109, 'stage': 'full70', 'success': False}
        with self.assertRaises(ValueError):
            G.validate_completion(condition, complete, manifest, 'full70', '0' * 64)

    def test_参加の未知分母と受理だけは非参加(self):
        """機能: 未知枠を分母に残し、同枠fillのない受理を参加へ混ぜない。

        引数: self(保存検査)。返り値: None。
        """
        value, _ = fixture()
        config = S.BY_KEY['entry_E1_G2_C0_D1']
        book = copy.deepcopy(value['books'][S.A.key_for(config)])
        checked = S.A.verify_finance(book, config)
        before = S.OLD.PARTICIPATION20(book, checked)
        book['grid_traces'] = []
        after = S.OLD.PARTICIPATION20(book, checked)
        self.assertEqual(before['denom'], after['denom'])
        self.assertEqual(after['active'], 0)
        self.assertEqual(after['unknown'], after['denom'])
        self.assertGreater(after['受理new'], 0)

    def test_保存Viewerの24資源を再読する(self):
        """機能: 実人工fillの価格/量/費用だけでViewer損益が一致することを再読する。

        引数: self(保存検査)。返り値: None。
        """
        value, _ = fixture()
        parent = Path(__file__).resolve().parent
        with tempfile.TemporaryDirectory(prefix='人工閲覧_', dir=parent) as name:
            out = Path(name).resolve()
            self.assertTrue(out.is_relative_to(parent))
            resources = S.save_viewer(value, out, '人工の原板は参照しない')
            self.assertEqual(len(resources), 24)
            for resource in resources:
                book = value['books'][resource['method_id']]
                rows = [json.loads(line, parse_float=Decimal) for line in (out / resource['pnl_path']).read_text(encoding='utf-8').splitlines()]
                self.assertEqual(len(rows), len(book['fills']))
                cash = Decimal(0)
                holdings = {}
                for row in rows:
                    direction = 1 if row['type'].startswith('Long') else -1
                    quantity = row['qty']
                    if row['type'].endswith('N'):
                        holdings[row['position_id']] = [direction, quantity, row['price']]
                        cash -= row['fee_yen']
                    else:
                        side, owned, price = holdings[row['position_id']]
                        self.assertEqual(direction, side)
                        self.assertGreaterEqual(owned, quantity)
                        cash += side * (row['price'] - price) * quantity * 100 - row['fee_yen']
                        holdings[row['position_id']][1] -= quantity
                self.assertTrue(all(x[1] == 0 for x in holdings.values()))
                self.assertEqual(cash, book['totals']['net_yen'])

    def test_EntryV公表後の遅配は合法(self):
        """機能: 公表時計と受信時計の同一視を避け、過去公表の遅配を許す。

        引数: self(保存検査)。返り値: None。
        """
        value, raw = fixture()
        key = 'entry_E1_G2_C0_D0'
        audit = value['composite_audits'][key]
        initial = audit['positions'][0]['initial_source']
        initial['delivered_at'] += 1
        checked = S.A.verify_finance(value['books'][key], S.BY_KEY[key])
        P.verify_protection(value['books'][key], S.BY_KEY[key], audit, checked)

    def test_正規純Rの保存と無効R拒否(self):
        """機能: 純APIが許可したRの両方向を未改変で保存監査へ通す。

        引数: self(保存検査)。返り値: None。CSV→CoreのR金融再走とは扱わない。
        """
        for path, expected in EXTRA_PINS.items():
            self.assertEqual(S.digest(Path(path)), expected)
        exported = S.load(R_SOURCE)
        self.assertEqual(exported['stopped_entry_sha256'], '834aedc70a31d5f0d7e2bee9ae6fc9d22d7b3ea726924fed791b2dfec7b283f9')
        legacy_path = S.ROOT / 'work/109保存会計の準備/入口と活動の監査.py'
        legacy_spec = importlib.util.spec_from_file_location('旧a189の入口保存監査', legacy_path)
        legacy = importlib.util.module_from_spec(legacy_spec)
        legacy_spec.loader.exec_module(legacy)
        allowed_quantity = 0
        for row in exported['results']:
            batch = row['steps'][-1]['assessment']
            pure = batch['decisions'][0]
            self.assertTrue(pure['known'] and pure['allowed'] and pure['role'] == 'R')
            self.assertFalse(pure['structure']['active'])
            c = pure['candidate']
            side, price, at = c['side'], c['entry_quote'], c['at']
            quote = {'time': at - 1, 'index': 1, 'source_line': 2, 'last': price, 'bid': price - 1 if side > 0 else price, 'ask': price if side > 0 else price + 1, 'quote_ok': True}
            candidate = {'ordinal': 1, 'at': at, 'side': side, 'source': {'method': '人工Source', 'signal_id': f'R{side}'}, 'quote': quote, 'available': 10, 'quantity': c['quantity']}
            decision = {k: pure[k] for k in ('snapshot_id', 'policy', 'known', 'allowed', 'role', 'reason')}
            actor = {'candidate': candidate, 'decision': decision}
            opportunity = {'gate': decision, 'available': 10, 'status': 'accepted'}
            E.pure_assessment(batch, actor, opportunity)
            allowed_quantity += c['quantity']
            with self.assertRaises(ValueError):
                legacy.pure_assessment(batch, actor, opportunity)
            invalid = {
                'Rなのに未消費active': lambda p: p['structure'].__setitem__('active', True),
                'R確認前': lambda p: p['structure'].__setitem__('phase', '復帰確認済み'),
                'R突破なし': lambda p: p['structure'].__setitem__('event', '再試験'),
                '失敗と復帰を同足に圧縮': lambda p: p['structure'].__setitem__('recovery_end', p['structure']['failure_end']),
                '復帰と突破を同足に圧縮': lambda p: p['structure'].__setitem__('breakout_end', p['structure']['recovery_end']),
                '反転構造群不成立': lambda p: p['reversal'].__setitem__('passed', False),
                '反転勢い不成立': lambda p: p['reversal_momentum'].__setitem__('passed', False),
                'R状態期限到達': lambda p: p['structure'].__setitem__('expires_at', p['candidate']['at']),
            }
            for label, mutate in invalid.items():
                with self.subTest(side=side, invalid=label):
                    broken = copy.deepcopy(batch)
                    mutate(broken['decisions'][0])
                    with self.assertRaises(ValueError):
                        E.pure_assessment(broken, actor, opportunity)
        self.assertEqual(allowed_quantity, 6)


if __name__ == '__main__':
    unittest.main(verbosity=2)
