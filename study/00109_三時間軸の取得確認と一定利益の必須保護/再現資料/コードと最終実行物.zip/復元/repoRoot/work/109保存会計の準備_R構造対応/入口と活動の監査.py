"""金融適格集合、複合入口の全値echo、一回割当と全予定分母を結合する。"""

from collections import Counter, defaultdict
import re

import 旧純算術 as A


need, equal, BASE, H = A.need, A.equal, A.BASE, A.OLD.GRID_SPACE


def known_quote(q):
    """機能: 保存BBOの正常性を判定する。

    引数: q(dict|None)は最後の原行。
    返り値: boolは実約定可能な正常気配。
    """
    return q is not None and q['quote_ok'] and q['ask'] > q['bid'] > 0


def quiet_at(book, at):
    """機能: 20分静観と米国20分静観を半開区間で判定する。

    引数: book(dict)、at(number)は口座と枠時刻。
    返り値: tuple[bool,bool|None]は全静観と米国静観。
    """
    s = book['session']
    us = s['us_open'] <= at < s['us_open'] + 1200 if s['kind'] == 'Night' and s['us_open'] > 0 else None
    return s['start'] <= at < s['start'] + 1200 or us is True, us


def deadline(book, opportunity):
    """機能: 元手法の予定終了制限を返す。

    引数: book/opportunity(dict)は口座と出生。
    返り値: numberはSource手法ごとのForce時計。
    """
    s = book['session']
    return min(s['force_close'], s['us_open'] - 900) if opportunity['source']['method'] == 'NK225_P164_06' else s['force_close']


def pure_assessment(batch, actor, opportunity):
    """機能: 純入口判定とActor採否の全候補echoを結合する。

    引数: batch/actor/opportunity(dict)は純一括判定・Actor候補判定・元出生。
    返り値: None。未保存の全指標をここで再形成しない。
    """
    c, d = actor['candidate'], actor['decision']
    expected_id = f"{c['ordinal']}|{c['source']['method']}|{c['source']['signal_id']}"
    candidates = [x for x in batch['decisions'] if x['candidate']['id'] == expected_id]
    equal(len(candidates), 1, '純候補とSourceの一意結合')
    p = candidates[0]
    equal(p['candidate'], {'id': expected_id, 'side': c['side'], 'at': c['at'], 'entry_quote': c['quote']['ask' if c['side'] > 0 else 'bid'], 'quantity': c['quantity']}, '純候補へ方向/数量/生BBOを無改変')
    for k in ('snapshot_id', 'policy', 'known', 'allowed', 'reason'):
        equal(d[k], p[k], '純判定からActorへのecho.' + k)
    equal(d['role'], p['role'] or p['status'], '純役割又は待機状態のecho')
    if opportunity.get('gate') is not None:
        equal(opportunity['gate'], d, '実出生採否のgate保存')
    else:
        need(opportunity['available'] == 0 and opportunity['status'] == 'expired', '同枠先行配賦で余力0の時だけ実gateを省略')
    need(p['policy'] == 'ENTRY_E1' and p['status'] in ('未知', '待機', '許可', '競合'), '純入口の本名と状態')
    need(not p['allowed'] or p['known'] and p['status'] == '許可' and p['role'] in ('T', 'R'), '未知を許可しない')
    for role in ('trend', 'reversal', 'momentum', 'trend_momentum', 'reversal_momentum', 'spike'):
        group = p[role]
        need(not group['passed'] or group['known'], '未知の群を成立へ補完しない')
    equal([x['width_seconds'] for x in p['background']], [300, 900, 1800], '背景の3尺度')
    equal([x['width_seconds'] for x in p['volume']], [300, 900, 1800], '量の3尺度は診断として保持')
    need(all(type(x['known']) is bool and (not x['known'] or x['value'] >= 0) for x in p['volume']), '量の既知/未知を区別')
    if p['allowed']:
        structure = p['structure']
        need(structure['id'] and structure['anchor_id'] and structure['pivot_id'] and structure['event_bar_id'], '成立には固定構造と別足の識別')
        need(structure['created_at'] <= c['at'] < structure['expires_at'] and structure['expires_at'] - structure['created_at'] == 1800, '構造状態の事前固定期限')
        need(structure['event'] and structure['trigger'] > 0 and p['spike']['passed'] and p['spike']['known'], '構造確認と複合スパイク否定')
        if p['role'] == 'T':
            need(structure['active'], 'Tの継続setupはactiveが必要')
            need(p['trend']['passed'] and p['trend_momentum']['passed'] and all(x['known'] and x['direction'] == c['side'] for x in p['background']), 'Tは複合ANDと3尺度方向')
            need(all(c['side'] * x[k] > 0 for x in p['background'] for k in ('gap', 'fast_delta', 'slow_delta')), '背景方向は実gapと両傾きのstrict AND')
        else:
            need(structure['active'] is False and structure['phase'] == '確認済み' and structure['event'] == '反対側突破', 'R成立は確認済みでsetupを消費する')
            need(p['reversal']['passed'] and p['reversal_momentum']['passed'] and structure['failure_end'] < structure['recovery_end'] < structure['breakout_end'], 'Rは別足の失敗→復帰→突破')
    if batch['conflict']:
        need(not p['allowed'] and p['status'] == '競合', '両方向競合は双方待機')


def verify_entry(book, config, clock, composite, audit, checked, full_clock):
    """機能: Source/一回割当/金融適格集合/全候補判定/実要求/活動列を照合する。

    引数: book/config/clock/composite/audit/checked(dict)、full_clock(bool)は保存値と連続枠要件。
    返り値: dictは時計/入口の件数。全予定参加集計の入力を検証する。
    """
    orders, timeline = checked['orders'], checked['timeline']
    opportunities, grids = book['entry_opportunities'], book['grid_traces']
    births = {(e['method'], e['signal_id']): e for e in book['source_events'] if e['kind'] == 'new_signal'}
    equal(len(opportunities), len(births), '全出生と機会数')
    equal(clock['timing'], 'B5QD', '本名の5分時計')
    equal(clock['opportunities'], [{'ordinal': p['ordinal'], 'source': p['source'], **A.OLD.assignment_for(book, p)} for p in opportunities], '固定strict次5分/静観1回繰越の全出生')
    equal(audit['policy'], config['entry_policy'], '入口監査の本名')
    batches, pure = composite['entry_batches'], audit['nonempty_batches']
    is_e1 = config['entry_policy'] == 'entry_E1'
    equal(len(batches), len(grids) if is_e1 else 0, 'E1は空候補枠も一回callback')
    equal(audit['calls'], len(grids) if is_e1 else 0, '純判定呼出数')
    if not is_e1:
        equal(pure, [], 'E0は公開器をgateへ接続しない')
    by_grid = defaultdict(list)
    seen, accepted = set(), set()
    for index, p in enumerate(opportunities, 1):
        equal(p['ordinal'], index, '出生Ordinal')
        identity = BASE.source_identity(p['source'])
        need(identity in births and identity not in seen, '出生の永久一回性')
        seen.add(identity)
        event = births[identity]
        equal((p['source']['birth_time'], p['source']['birth_quote'], p['side']), (event['at'], event['quote'], event['side']), '出生方向/時計/原行不変')
        equal(p['assigned_at'], A.OLD.assigned_at(book, p), '恣意的な再割当なし')
        need(p['consumed'] and p['status'] in ('accepted', 'expired') and p['evaluated_at'] >= event['at'], '終端機会状態')
        at, q = p['evaluated_at'], p['quote']
        if q is not None:
            BASE.quote(q, '新入口の原行', normal=False)
            need(q['time'] <= at, '取得時の未来BBO禁止')
            equal(p['available'], H['available_at'](book, orders, timeline, at, q, p['side'], accepted), '逐次配賦の片側余力')
            equal(p['quote_age_seconds'], H['clock_delta'](at, q['time']), '気配age')
        src = H['source_at'](book, at, q)[identity]
        equal((p['source_state'], p['source_hold_id'], p['source_quantity'], p['source_reserved']), (src['state'], src['hold'], src['q'], src['reserved']), '当時のSource状態')
        eof = p['reason'] == 'EOFで未消費出生機会を失効'
        eligible = not (eof or at != p['assigned_at'] or at >= deadline(book, p) or quiet_at(book, at)[0] or src['state'] in ('pending', 'cancelled') or src['q'] == 0 or (src['reserved'] or 0) > 0)
        unknown = eligible and not known_quote(q)
        eligible = eligible and known_quote(q) and p['available'] > 0
        gate = p.get('gate')
        if is_e1 and gate is not None:
            need(eligible, '金融不適格候補を純入口へ渡さない')
            unknown = not gate['known']
            eligible = gate['known'] and gate['allowed']
        else:
            need(not is_e1 or not eligible, '金融適格なのにE1判定なし')
            need(is_e1 or gate is None, 'E0へ技法gate混入')
        equal(p['required_unknown'], unknown, '未知を待機/許可へ変換しない')
        equal(p['status'], 'accepted' if eligible else 'expired', '独立した入口の採否')
        equal(p['requested'], min(p['source']['birth_quantity'], src['q'], p['available']) if eligible else 0, '実要求は出生/Source残/配賦余力のmin')
        if eligible:
            o = orders[p['entry_order_id']]
            for k, expected in (('source', p['source']), ('side', p['side']), ('quantity', p['requested']), ('request_time', at), ('request_quote', q), ('source_hold_id', p['source_hold_id'])):
                equal(o[k], expected, '入口と実注文.' + k)
            accepted.add(o['id'])
        else:
            need(not p['entry_order_id'] and p['requested'] == 0, '失効から架空注文を作らない')
        if not eof:
            by_grid[at].append(p)
        next_grid = next((x['at'] for x in grids if x['at'] >= p['assigned_at']), None)
        need(eof == (next_grid is None), 'EOF失効と観測枠の分離')
        if not eof:
            equal(at, next_grid, '割当後の再試行なし')
    equal(accepted, {o['id'] for o in book['orders'] if o['kind'] == 'entry'}, '全実新規要求の出生結合')
    if full_clock:
        H['verify_grid_prefix'](book['session'], [x['at'] for x in grids])
    counts = Counter()
    pure_by_id = {x['snapshot_id']: x for x in pure}
    need(len(pure_by_id) == len(pure), '非空純Batchの識別一意')
    equal(set(pure_by_id), {b['input']['snapshot_id'] for b in batches if b['input']['candidates']}, '非空純Batchを過不足なく結合')
    for index, trace in enumerate(grids):
        at, q = trace['at'], trace['quote']
        need(at % 300 == 0 and (index == 0 or grids[index - 1]['at'] < at), '枠の順序')
        quiet, us = quiet_at(book, at)
        equal((trace['quiet'], trace['quiet_applied'], trace['us_quiet'], trace['quote_known']), (quiet, quiet, us, known_quote(q)), '20分静観とBBO既知')
        points = by_grid[at]
        equal(trace['ordinals'], [p['ordinal'] for p in points], '枠候補の順序')
        for k, expected in (('candidate_count', len(points)), ('accepted_count', sum(p['status'] == 'accepted' for p in points)), ('accepted_quantity', sum(p['requested'] for p in points)), ('expired_count', sum(p['status'] == 'expired' for p in points)), ('unknown_count', sum(p['required_unknown'] for p in points))):
            equal(trace[k], expected, '枠の集計.' + k)
        allowed_before = {p['entry_order_id'] for p in opportunities if p['status'] == 'accepted' and p['evaluated_at'] < at}
        if q is not None:
            point = {'quote': q, 'phase': 'after_source'}
            for side, label in ((1, 'buy'), (-1, 'sell')):
                owned = sum(x['quantity'] for pid in timeline.histories if (x := timeline.state_at(pid, point)) is not None and x['side'] == side)
                equal(trace['open_' + label], owned, '枠開始時の実保有')
                allowed_after = allowed_before | {p['entry_order_id'] for p in points if p['status'] == 'accepted'}
                equal(trace['pending_' + label], H['pending_quantity'](book, orders, timeline, at, q, side, allowed_after), '枠後の新規予約')
        action = '新規' if trace['accepted_count'] else '保有' if trace['open_buy'] + trace['open_sell'] else '判定不能' if trace['unknown_count'] else '待機'
        equal(trace['action'], action, '受理と保有と未知を区別')
        if is_e1:
            b = batches[index]
            inp, out = b['input'], b['output']
            equal(inp['at'], at, '一括判定の枠')
            need(re.fullmatch('[0-9a-f]{64}', inp['snapshot_id']), '入口snapshot指紋')
            equal(out['snapshot_id'], inp['snapshot_id'], '一括採否snapshot不変')
            expected = []
            for side, name in ((1, 'buy'), (-1, 'sell')):
                free = H['available_at'](book, orders, timeline, at, q, side, allowed_before) if q is not None else 10
                equal(inp['available_' + name], free, '全候補を配賦前の同一余力で判定')
            for p in points:
                if at != p['assigned_at'] or at >= deadline(book, p) or quiet or p['source_state'] in ('pending', 'cancelled') or p['source_quantity'] == 0 or (p['source_reserved'] or 0) > 0 or not known_quote(q):
                    continue
                free = inp['available_buy' if p['side'] > 0 else 'available_sell']
                if free:
                    expected.append({'ordinal': p['ordinal'], 'at': at, 'side': p['side'], 'source': p['source'], 'quote': q, 'available': free, 'quantity': min(p['source']['birth_quantity'], p['source_quantity'], free)})
            equal(inp['candidates'], expected, '同枠の金融適格集合だけを全件査定')
            equal(len(out['decisions']), len(expected), '全候補に一回採否')
            equal([x['candidate'] for x in out['decisions']], expected, '全候補の順序と全値echo')
            directions = {x['candidate']['side'] for x in out['decisions'] if x['decision']['allowed']}
            need(len(directions) <= 1, '同枠の両方向成立を競合待機')
            if expected:
                pure_batch = pure_by_id[inp['snapshot_id']]
                equal(len(pure_batch['decisions']), len(expected), '純一括判定の候補数')
                for value in out['decisions']:
                    pure_assessment(pure_batch, value, opportunities[value['candidate']['ordinal'] - 1])
                    counts['candidates'] += 1
                    counts['allowed'] += value['decision']['allowed']
                    counts['unknown'] += not value['decision']['known']
                counts['conflicts'] += pure_batch['conflict']
    for k in ('candidates', 'allowed', 'unknown', 'conflicts'):
        equal(audit[k], counts[k], '純入口の全体計数.' + k)
    metrics = {'births': len(opportunities), 'grid_calls': len(grids), 'quiet_grids': sum(t['quiet'] for t in grids), 'unknown_us_grids': sum(not t['us_clock_known'] for t in grids), 'accepted': sum(p['status'] == 'accepted' for p in opportunities), 'expired': sum(p['status'] == 'expired' for p in opportunities), 'required_unknown': sum(p['required_unknown'] for p in opportunities), 'eof_expired': sum(p['reason'] == 'EOFで未消費出生機会を失効' for p in opportunities)}
    metrics.update({field: sum(t['action'] == label for t in grids) for label, field in (('新規', 'new_grids'), ('保有', 'holding_grids'), ('待機', 'waiting_grids'), ('判定不能', 'unknown_grids'))})
    equal(book['grid_metrics'], metrics, 'Actor全枠計数')
    return {'出生': len(opportunities), '一括候補': counts['candidates'], '一括許可': counts['allowed'], '一括未知': counts['unknown'], '一括競合': counts['conflicts']}
