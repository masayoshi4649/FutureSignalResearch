"""109保存器を人工だけで確認し、コードと入力指紋を停止記録へ固定する。"""

import ast
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys

import 集計 as S
import 固定ゲート as G
from 人工検査 import ART, PINS, EXTRA_PINS


def main():
    """機能: 人工検査/構文/全依存指紋/入力前後同体を記録して停止する。

    引数: なし。cwdや市場フォルダを列挙しない。
    返り値: None。停止記録が存在する場合は上書きせず拒否する。
    """
    own = Path(__file__).resolve().parent
    stop = own / '停止.json'
    S.need(not stop.exists(), '既存停止を上書きしない')
    paths = G.dependency_paths()
    code = {str(p): S.digest(p) for p in paths}
    inputs = {**{str(ART / name): sha for name, sha in PINS.items()}, **EXTRA_PINS}
    for name, sha in inputs.items():
        S.equal(S.digest(Path(name)), sha, '停止人工入力の一致')
    for path in paths:
        ast.parse(path.read_text(encoding='utf-8-sig'), filename=str(path))
    command = [sys.executable, '-B', '-X', 'utf8', str(own / '人工検査.py')]
    process = subprocess.run(command, cwd=S.ROOT, encoding='utf-8', capture_output=True)
    check_dir = own / '検査'
    check_dir.mkdir(exist_ok=True)
    (check_dir / '人工検査.txt').write_text(process.stdout + process.stderr, encoding='utf-8', newline='\n')
    S.equal(process.returncode, 0, '人工検査の実exit code')
    after = {name: S.digest(Path(name)) for name in inputs}
    code_after = {name: S.digest(Path(name)) for name in code}
    S.equal(after, inputs, '人工入力前後不変')
    S.equal(code_after, code, 'コード前後不変')
    report = {'成功': True, '検査argv': command, 'exit_code': process.returncode, '人工口座': 96, '非ゼロ24の器具': 4, '旧Book/Width/Clock各4対照の器具': 4, '主検査': 9, '破壊反例': 39, '正規純Rの許可候補': 2, '正規純Rの許可数量': 6, '無効R反例の種類': 8, '無効R反例の両方向件数': 16, '旧a189が正規Rを拒否する再現': 2, 'Viewer再読資源': 24, '構文ファイル': len(paths), '入力SHA256前': inputs, '入力SHA256後': after, 'コードSHA256前': code, 'コードSHA256後': code_after, '前後不変': True, '市場本文読取': False, '実70金融': False, 'CSVからCoreのR金融再走': False, '損益CSV生成': False, 'xlsx生成': False, 'HTTP通信': False, 'Python版': sys.version}
    S.BASE.write_json(check_dir / 'Python確認.json', report)
    S.BASE.write_json(stop, {'version': 1, 'trial': 109, '停止': True, 'scope': 'Root固定＋金融成功後の保存検算器。実70市場損益未読・金融再走0・技法変更0。', '日時UTC': datetime.now(timezone.utc).isoformat(), 'コードSHA256': code, '仕様': {'path': str(own / 'README.md'), 'sha256': S.digest(own / 'README.md')}, '検査': {'path': str(check_dir / 'Python確認.json'), 'sha256': S.digest(check_dir / 'Python確認.json')}, '入力前後不変': True, '実市場読取': False, '実金融': False, 'CSV/xlsx生成': False, '研究目標達成': False})
    print(json.dumps({'成功': True, '停止': str(stop), '停止SHA256': S.digest(stop), '全依存': len(paths)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
