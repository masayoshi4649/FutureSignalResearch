"""旧保存器の政策非依存会計だけを分離し、109の実設定へ適用する。"""

from __future__ import annotations

import ast
from decimal import Decimal
import hashlib
import importlib.util
import inspect
import math
from pathlib import Path
import textwrap
import types


ROOT = Path(__file__).resolve().parents[2]
OLD_PATH = ROOT / "work/108静観短縮の保存準備/集計.py"
OLD_SHA = "291d42dc23b492495fe441e1d72d0673ee3c87766056b117246c396c083d98d5"
if hashlib.sha256(OLD_PATH.read_bytes()).hexdigest() != OLD_SHA:
    raise ValueError("停止108保存器のSHA差")
SPEC = importlib.util.spec_from_file_location("109が再用する政策非依存保存", OLD_PATH)
OLD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(OLD)
BASE = OLD.BASE
need, equal, number = OLD.need, OLD.equal, BASE.number


def configurations() -> list[dict]:
    """機能: 本名の入口2×保護3×感度4を生成する。

    引数: なし。
    返り値: list[dict]はCoreの24設定で、旧policy名へ置き換えない。
    """
    return [{"entry_policy": e, "protection_policy": g, "slip_pts": c, "delay_seconds": d, "quiet_seconds": 1200}
            for e in ("entry_E0", "entry_E1") for g in ("G0", "G1", "G2") for c in (0, 5) for d in (0, 1)]


def key_for(config: dict) -> str:
    """機能: Core本名を検査し、一意の外keyを作る。

    引数: config(dict)はCore設定。
    返り値: strはentry_E0_G0_C0_D0等。
    """
    need(config in configurations(), "109の本名設定24以外")
    return f"{config['entry_policy']}_{config['protection_policy']}_C{config['slip_pts']}_D{config['delay_seconds']}"


def actual_config(book: dict, config: dict) -> None:
    """機能: 新Actualの本名Config/Keyを検査する。

    引数: book/config(dict)は実bookと外設定。
    返り値: None。bookやkeyを旧enumへ偽装しない。
    """
    key_for(config)
    gate = "ENTRY_E1" if config["entry_policy"] == "entry_E1" else ""
    activation = "LD10" if config["protection_policy"] == "G0" else config["protection_policy"]
    expected = {"policy": "P0", "slip_pts": config["slip_pts"], "delay_seconds": config["delay_seconds"], "entry_timing": "B5QD", "us_open": book["session"]["us_open"], "activation_policy": activation}
    if gate:
        expected["gate_policy"] = gate
    equal(book["config"], expected, "109のActualConfig本名")
    inner = f"{activation}_B5QD_P0_C{config['slip_pts']}_D{config['delay_seconds']}"
    equal(book["key"], ("ENTRY_E1_" if gate else "") + inner, "109のActual内key")
    need(not book.get("held_exit_grids") and not book.get("short_exit_events") and not book.get("short_exit_contract"), "未使用退出経路の混入")


def verify_saved_marks(position: dict, timeline, intrinsic: str) -> None:
    """機能: 保存点の金額・所有・符号・時系列・極値とnativeATR出典だけを検査する。

    引数: position(dict)、timeline(BASE.Timeline)、intrinsic(str)は実玉・全fill履歴・P0。
    返り値: None。起動H/新幅/床は新監査で別に検査する。
    """
    marks = position["marks"]
    names = {"first", "last", "first_unit_positive", "first_whole_positive", "first_unit_nonpositive_after", "first_unit_negative_after", "first_whole_nonpositive_after", "first_whole_negative_after", "unit_max", "unit_min", "whole_max", "whole_min"}
    equal(set(marks), names, "保存mark集合")
    points = list(marks.values()) + [position[k] for k in ("activation", "floor_updated", "first_floor_hit")]
    for point in points:
        if point is not None:
            timeline.verify_position_point(position["id"], point)
    for prefix, amount in (("unit", "unit_net"), ("whole", "whole_net")):
        first = marks["first_" + prefix + "_positive"]
        if first is not None:
            need(first[amount] > 0, "初正益strict符号")
        for suffix, strict in (("nonpositive_after", False), ("negative_after", True)):
            point = marks["first_" + prefix + "_" + suffix]
            if point is not None:
                need(first is not None and BASE.point_order(first) < BASE.point_order(point), "正益後保存点の順序")
                need(point[amount] < 0 if strict else point[amount] <= 0, "正益後の返し符号")
        high, low = marks[prefix + "_max"], marks[prefix + "_min"]
        if high is not None or low is not None:
            need(high is not None and low is not None and high[amount] >= low[amount], "極値対")
            need(all(low[amount] <= p[amount] <= high[amount] for p in marks.values() if p is not None), "保存点が極値内")
    if marks["first"] is None:
        need(position["has_mark"] is False and all(p is None for p in marks.values()), "未観測markのnullable")
    else:
        need(position["has_mark"] and marks["last"] is not None and marks["unit_max"] is not None, "観測markの対")
        equal(position["peak_gain"], marks["unit_max"]["gain_points"], "実玉の方向幅peak")
        need(all(BASE.point_order(marks["first"]) <= BASE.point_order(p) <= BASE.point_order(marks["last"]) for p in points if p is not None), "保存点の観測範囲")
    if position["protection_active"]:
        need(position["activation"] is not None and position["activation"]["unit_net"] > 0 and position["floor_gain"] is not None, "起動と正の費用後単価")
    else:
        need(all(position[k] is None for k in ("activation", "floor_gain", "floor_updated", "first_floor_hit")), "未起動の床nullable")
    atr = position["atr"]
    if atr is not None:
        BASE.quote(atr["quote"], "nativeATR.quote")
        need(atr["value"] > 0 and atr["quote"]["time"] >= atr["available"] >= atr["nominal"] > 0, "nativeATR公開時計")
        need(float(atr["age_seconds"]) == float(atr["quote"]["time"]) - float(atr["available"]), "nativeATR ageの元IEEE64")
        need(float(atr["width"]) == 5 * math.ceil(2 * float(atr["value"]) / 5), "nativeATRの旧2A出典（G2選択幅ではない）")
        equal(atr["after_entry"], atr["quote"]["index"] > position["entry_quote"]["index"], "nativeATR後取得flag")


def pure_accounting_function():
    """機能: 固定旧verify_bookの政策prefix4文だけを除き純会計本文を再用する。

    引数: なし。
    返り値: functionはbook/config/policyを明示受領する純会計。旧key/enum検査を実行しない。
    """
    tree = ast.parse(textwrap.dedent(inspect.getsource(BASE.verify_book)))
    function = tree.body[0]
    prefix = [ast.unparse(node) for node in function.body[1:5]]
    expected = ["require(key in KEYS and book['key'] == key, 'Actor key')", "policy, cost, delay = key.split('_')", "config = {'policy': policy, 'slip_pts': int(cost[1:]), 'delay_seconds': int(delay[1:])}", "equal(book['config'], config, 'Actor config')"]
    equal(prefix, expected, "旧純会計から分離する政策prefixの正確な4文")
    function.name = "pure_accounting"
    function.body = [function.body[0]] + function.body[5:]
    function.args.args = [ast.arg(arg=name) for name in ("book", "config", "policy")]
    function.args.defaults = []
    namespace = {**vars(BASE), "verify_marks": verify_saved_marks, "verify_source_events": OLD.GRID_SPACE["verify_source_b"]}
    exec(compile(ast.fix_missing_locations(tree), str(Path(__file__).resolve()) + ":旧純会計本文", "exec"), namespace)
    return namespace["pure_accounting"]


PURE_ACCOUNT = pure_accounting_function()


def verify_finance(book: dict, config: dict) -> dict:
    """機能: 新本名を先に確認し、全fill/fee/所有/MTM/DDの旧純会計を適用する。

    引数: book/config(dict)は原値の新ActorとCore設定。
    返り値: dictはTimeline/所有/全損益。新保護と入口の成立証明とは別。
    """
    actual_config(book, config)
    before = OLD.SAVED.canonical_sha(book)
    result = PURE_ACCOUNT(book, book["config"], "P0")
    for fill in book["fills"] or []:
        order = result["orders"][fill["order_id"]]
        need(fill["quote"]["source_line"] > order["request_quote"]["source_line"], "同じ/過去物理行でのfill")
    need(all(p.get("initial_risk") is None and p.get("gross_guard") is None for p in book["positions"] or []), "旧未使用risk状態の混入")
    equal(OLD.SAVED.canonical_sha(book), before, "新本名と金融値を変更しない")
    return {**result, "book": book}
