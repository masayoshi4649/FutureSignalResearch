"""145最終停止Sourceを独立overlay4群と全人工/vet/buildへ結び、自然前の証跡を保存する。"""
from pathlib import Path
import hashlib
import json
import re
import subprocess

ROOT=Path(__file__).resolve().parents[2]
OWN=Path(__file__).resolve().parent
SOURCE=ROOT/'work/145構造イベントの入口'


def sha(path: Path) -> str:
    """
    機能: 保存ファイルのSHA256を求める。
    引数: path(Path)。返り値: strは指紋。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 作者18源と旧再用を照合し、Sourceを変えず独立4人工を重ねて停止する。
    引数: なし。自然入力/Source/Raw/CSV/金融/追加2場は読まない。
    返り値: None。専有workへ準備の確認JSONを保存する。
    """
    author_path=SOURCE/'準備の確認.json'
    assert sha(author_path)=='c06a686db7bc2da2e974b43c343ef1f2308805a6fa460013c6eb87c8eb7e9e3a'
    author=json.loads(author_path.read_bytes());assert author['成功'] and author['人工主群数']==10 and len(author['源'])==18
    paths=[author_path]
    for row in author['源']+[author['実行ファイル']]:
        p=ROOT/row['path'];assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'];paths.append(p)
    assert author['実行ファイル']['sha256']=='1277f1d5feae7c90735669583904a470d713ba7a97c50da2042aa9abc6c9386a'
    old=json.loads((ROOT/'work/144旧P3strongの全成立/準備の確認.json').read_bytes())
    for row in old['源']:
        p=Path(row['path']);assert sha(p)==row['sha256'];paths.append(p)
    copied=json.loads((SOURCE/'由来.json').read_bytes())['同体再用'];assert len(copied)==4
    for row in copied:
        a,b=ROOT/row['source'],ROOT/row['target'];paths.extend((a,b))
        assert sha(a)==row['source_sha256'] and sha(b)==row['target_sha256']
        assert a.read_bytes().replace(b'package strongstream144',b'package structureevent145',1)==b.read_bytes()
    formal=ROOT/'work/145正式文書の準備確認.json';value=json.loads(formal.read_bytes());paths.append(formal)
    for name,h in value['正式3MD'].items():
        p=ROOT/name;assert sha(p)==h;paths.append(p)
    before={str(p.resolve()):sha(p) for p in set(paths)}
    overlay=OWN/'overlay.json'
    assert json.loads(overlay.read_bytes())=={'Replace':{str(SOURCE/'independent145_test.go'):str(OWN/'独立人工_test.go')}}
    logs=[]
    for arguments in (['go','test','-count=1','-overlay='+str(overlay),'-v','./...'],['go','vet','./...'],['go','build','./...']):
        done=subprocess.run(arguments,cwd=SOURCE,capture_output=True,text=True,encoding='utf-8')
        logs.append({'引数':arguments,'終了コード':done.returncode,'標準出力':done.stdout,'標準エラー':done.stderr})
        assert done.returncode==0,done.stdout+done.stderr
    main_pass=re.findall(r'^--- PASS: (\S+)',logs[0]['標準出力'],re.M)
    assert len(main_pass)==14 and sum(n.startswith('TestIndependent145') for n in main_pass)==4
    assert all(sha(Path(p))==h for p,h in before.items())
    report={'成功':True,'試行':145,'重大未解決':[],'作者最終18源/実行体一致':True,'旧144全20源同体':True,
            '再用4源package以外同体':True,'作者人工10主':True,'独立人工4主':True,'全14主非cache':True,'vet_build':True,
            '独立人工':['同Raw5/15/30の6順列×A/B売買でarm票同体',
                       'fresh期限直前の遅配confirm→1秒後次足pending取得・確定Hist量を差替えない/占有中足再arm不可',
                       'B現在30ゼロ/符号不一致・DI未知でもknown契約だけを維持',
                       '同Raw過去p/r catch-upで遡及arm→confirmを生成しない'],
            '参照時計':'Arm/Confirm各Evidenceはbirth以前に凍結。Event.refsは取得/取消の現在背景も含みentry/termination以前。遅配人工でbirth後entry以前のref追加を確認。',
            '静的因果確認':['全同Raw pub配送→1Snapshot→新5分ID処理済み→既episode/pending→新arm',
                          '歴史実連続5分refと現在fresh三尺度を分離、Technical.previousやRVOLで前量を補完しない',
                          'A現方向維持/B現在30はknownだけ、同現在ADX増分で排他',
                          'arm構造K/I±10/armATR凍結、W125/超過、Last/P固定域と実risk125',
                          'arm直後I取消、全期限等号/新規限界、終了Raw/確認足/占有足の再arm不可',
                          '未完episode/pending各1・1episode1born・現在背景/Last/連続性を維持',
                          '旧Raw採用/1走査/gzip/plain/末尾全pub/SHA/stat/限月/品質照合、0取得場を残す',
                          'Input122 trial/success無し/Raw.Bytes無し、Sourceへ旧C0未来状態を渡さない'],
            '実行':logs,'全対象前後SHA256':before,'独立人工SHA256':sha(OWN/'独立人工_test.go'),
            '自己コードSHA256':sha(Path(__file__)),'作者源/正式MD変更':False,
            '自然Input/Source/Raw/CSV/金融/追加2場読取':False,'編集停止':True}
    out=OWN/'準備の確認.json';assert not out.exists();out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'14主人工':True,'SHA256':sha(out)},ensure_ascii=False))


if __name__=='__main__':
    main()
