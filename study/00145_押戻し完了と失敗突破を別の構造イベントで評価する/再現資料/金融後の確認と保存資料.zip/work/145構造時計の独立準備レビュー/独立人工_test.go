package structureevent145

import (
	"encoding/json"
	"testing"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// independent145ArmPubs は同Rawへ来る5/15/30の人工を順序検査用に作ります。
//
// 引数: family(string)、side(int)。返り値: []rules.Publicationです。自然値は使いません。
func independent145ArmPubs(family string, side int) []rules.Publication {
	o := rules.OHLC{Open: 106, High: 108, Low: 99, Close: 100}
	hist := 1.
	if family == "B0" { o = rules.OHLC{Open: 90, High: 108, Low: 80, Close: 100}; hist = -2 }
	p := publication145(300, 1200, 1261, 4, o, hist)
	p.Frame.Frame.Technical.EMA8, p.Frame.Frame.Technical.EMA21 = val(999), val(999)
	p.Frame.Frame.Technical.PreviousHistogram = val(-999)
	m := publication145(900, 1200, 1261, 4, rules.OHLC{Open: 100, High: 110, Low: 90, Close: 105}, 1)
	l := publication145(1800, 1200, 1261, 4, rules.OHLC{Open: 100, High: 110, Low: 90, Close: 105}, 1)
	if family == "B0" { m.Frame.DMI.ADX = val(19); l.Frame.Frame.Technical.Gap = val(-10); l.Frame.Frame.Technical.EMA21Delta = val(-1) }
	return []rules.Publication{mirror145(p, side), mirror145(m, side), mirror145(l, side)}
}

// TestIndependent145BatchOrder は同Raw全幅の配送順を変えても同じarmになることを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。A/Bと両売買の6順列を比較します。
func TestIndependent145BatchOrder(t *testing.T) {
	orders := [][3]int{{0,1,2},{0,2,1},{1,0,2},{1,2,0},{2,0,1},{2,1,0}}
	for _, family := range []string{"A0","B0"} {
		for _, side := range []int{1,-1} {
			var first string
			for _, order := range orders {
				x := initial145(t,side,family); p := independent145ArmPubs(family,side)
				feed145(t,x,testQuote145(side,1261,4,100),p[order[0]],p[order[1]],p[order[2]])
				if len(x.d.Episodes)!=1 || x.d.active==nil || len(x.d.Events)!=0 { t.Fatal("arm/confirm順序差") }
				raw,err := json.Marshal(x.d.Episodes); if err!=nil { t.Fatal(err) }
				if first=="" { first=string(raw) } else if first!=string(raw) { t.Fatal("同Raw公表の幅順に依存した") }
			}
		}
	}
}

// TestIndependent145LateConfirmAndPending は遅配後のpendingが次足で再確認へ変わらないことを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。実前足が期限切れでも歴史として使います。
func TestIndependent145LateConfirmAndPending(t *testing.T) {
	for _, side := range []int{1,-1} {
		x := initial145(t,side,"A0"); arm145(t,x,nil)
		r := publication145(300,1500,1859,5,rules.OHLC{Open:110,High:130,Low:108,Close:120},3)
		r.Frame.Frame.Volume=120
		feed145(t,x,testQuote145(side,1859,5,120),mirror145(r,side))
		if len(x.d.Events)!=1 || x.d.Events[0].Status!="pending" { t.Fatal("fresh期限前の遅配確認が出生しない") }
		e := x.d.Events[0]; frozen := e.Confirm.Frame.Frame.Frame.ID
		// 次足は新しい調整の形だが量未知。pendingの確定済み確認と差し替えない。
		next := publication145(300,1800,1860,6,rules.OHLC{Open:106,High:108,Low:99,Close:100},1)
		next.Frame.Frame.VolumeKnown=false
		feed145(t,x,testQuote145(side,1860,6,120),mirror145(next,side))
		if e.Status!="filled" || e.Confirm.Frame.Frame.Frame.ID!=frozen || e.EntryQuote==nil { t.Fatal("pendingに次足Hist/量を再要求した") }
		if e.Arm.At.Time > e.Birth.Time || e.Confirm.At.Time > e.Birth.Time { t.Fatal("出生確定票が出生後へ変わった") }
		foundEntryRef := false
		for _, reference := range e.Refs {
			if reference.Delivered.Time > e.EntryQuote.Time || int64(reference.Delivered.Index) > e.EntryQuote.Index || int64(reference.Delivered.Line) > e.EntryQuote.SourceLine { t.Fatal("Event refsに取得後の参照がある") }
			if reference.ID == next.Frame.Frame.ID && reference.Delivered.Time > e.Birth.Time { foundEntryRef = true }
		}
		if !foundEntryRef { t.Fatal("取得時に再検査した背景refの追加を落とした") }
		if !x.d.processed[next.Frame.Frame.ID] { t.Fatal("pending中の新5分を処理済みにしなかった") }
		feed145(t,x,testQuote145(side,1861,7,120))
		if len(x.d.Episodes)!=1 || len(x.d.Events)!=1 { t.Fatal("取得後に占有中の新足をarmへ再利用した") }
	}
}

// TestIndependent145BCurrentKnownOnly は現在30のゼロ/不一致とDI未知を元d再要求にしないことを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。armの元dは固定したままです。
func TestIndependent145BCurrentKnownOnly(t *testing.T) {
	for _, side := range []int{1,-1} {
		for _, zero := range []bool{true,false} {
			x := initial145(t,side,"B0"); arm145(t,x,nil)
			r := publication145(300,1500,1561,5,rules.OHLC{Open:110,High:130,Low:108,Close:120},3)
			r.Frame.Frame.Volume=120
			m := publication145(900,1500,1561,5,rules.OHLC{Open:100,High:110,Low:90,Close:105},1)
			m.Frame.DMI.ADX=val(19); m.Frame.DMI.PlusDI=rules.Value{}; m.Frame.DMI.MinusDI=rules.Value{}
			l := publication145(1800,1500,1561,5,rules.OHLC{Open:100,High:110,Low:90,Close:105},1)
			l.Frame.Frame.Technical.Gap=val(10); l.Frame.Frame.Technical.EMA21Delta=val(-1)
			if zero { l.Frame.Frame.Technical.Gap=val(0); l.Frame.Frame.Technical.EMA21Delta=val(0) }
			feed145(t,x,testQuote145(side,1561,5,120),mirror145(r,side),mirror145(m,side),mirror145(l,side))
			if len(x.d.Events)!=1 || x.d.Episodes[0].OriginalDirection!=-side { t.Fatal("B現在30の元方向又はDIを追加要求した") }
			feed145(t,x,testQuote145(side,1562,6,120))
			if x.d.Events[0].Status!="filled" { t.Fatal("B現在knownだけの維持に失敗") }
		}
	}
}

// TestIndependent145CatchupNoChain は同Rawに過去調整と回復が来ても過去armへ遡らないことを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。歴史足は連続参照としてだけ保存します。
func TestIndependent145CatchupNoChain(t *testing.T) {
	x := initial145(t,1,"A0")
	p := publication145(300,1200,1561,4,rules.OHLC{Open:106,High:108,Low:99,Close:100},1)
	r := publication145(300,1500,1561,4,rules.OHLC{Open:110,High:130,Low:108,Close:120},3)
	r.Frame.Frame.Volume=120
	m := publication145(900,1500,1561,4,rules.OHLC{Open:100,High:110,Low:90,Close:105},1)
	l := publication145(1800,1500,1561,4,rules.OHLC{Open:100,High:110,Low:90,Close:105},1)
	feed145(t,x,testQuote145(1,1561,4,120),p,m,r,l)
	if len(x.d.Episodes)!=0 || len(x.d.Events)!=0 || !x.d.processed[r.Frame.Frame.ID] || len(x.history.Five)!=4 { t.Fatal("catch-up過去足でarm→confirmを作った") }
}
