"""145の固定条件を保持し、保存済み結果だけを正式文書へ反映する。"""

from pathlib import Path
import gzip
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[2]
FORMAL = ROOT / 'study/00145_押戻し完了と失敗突破を別の構造イベントで評価する'
OWN = Path(__file__).resolve().parent
SUMMARY = ROOT / 'work/145構造イベントの評価/金融評価/集計.json'
OUTPUT = ROOT / 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/145_構造イベント入口'


def fingerprint(path: Path) -> dict:
    """
    機能: 指定ファイルのサイズとSHA256を取得する。
    引数: path (Path) は既存のローカルファイル。
    返り値: dict はリポジトリ相対パス、bytes、sha256。
    """
    raw = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def rate(value: float | None) -> str:
    """
    機能: 分母0の率を数値0へ補完せず表示する。
    引数: value (float | None) は保存された率又は未知。
    返り値: str は百分率又は分母0の説明。
    """
    return '—（分母0）' if value is None else f'{value:.2%}'


def policy_table(data: dict) -> str:
    """
    機能: 実BBO/H60/同幅125の五政策を共通表にする。
    引数: data (dict) はSHA確認済み145集計正本。
    返り値: str は取得集合・三分母率・C5金額のMarkdown表。
    """
    result = '|政策|取得/取得場|順/逆/未到達/不足|到達済み率|H完了分母率|全取得分母率|C5利益円|C5損失円|C5既知差引円|金額未知件|\n'
    result += '|---|---|---|---|---|---|---|---|---|---|\n'
    for policy in ('U0', 'A0', 'B0', 'C0', 'RU'):
        value = data['集計']['all'][policy]['BBO']['3600']['125']
        result += (f"|{policy}|{value['entries']} / {value['sessions']}|"
                   f"{value['forward']}/{value['adverse']}/{value['neither']}/{value['censored']}|"
                   f"{rate(value['resolved_rate'])}|{rate(value['complete_rate'])}|"
                   f"{rate(value['forward']/value['entries'] if value['entries'] else None)}|"
                   f"{value['ifd_net5_profit']:,}|{value['ifd_net5_loss']:,}|"
                   f"{value['ifd_net5_sum']:+,}|{value['ifd_unknown']}|\n")
    return result


def main() -> None:
    """
    機能: 結果前の退避と正本SHAを確認し、許可された七文書だけを更新する。
    引数: なし。固定パスの既存文書と保存済み結果を使用する。
    返り値: None。元条件本文・汎用表513セルの保持と源の不変を証跡へ保存する。
    """
    for name in ('F0実行前文書.json.gz', 'F1実行前文書.json.gz'):
        assert (FORMAL / '検査' / name).is_file()
    assert fingerprint(SUMMARY)['sha256'] == 'fb374d53982ce7727c5ae936d72a20a973029de35480ed442a6cb2305fc9c861'
    assert fingerprint(FORMAL / '成果物/集計.json')['sha256'] == fingerprint(SUMMARY)['sha256']
    expected = {'README.md': 'a96eb9d5817b74533d4b25968b9c962df11f09f3b8b45f4437cec192dfa16cb5',
                '条件.md': '75d49527b555ef9c459683f1e444a0a70ec06aafa4803256fb29f5ad32ea6c9d',
                '設定と結果.md': '9b261978e35e46cd855de31826514159620068febf7e173d45ecfbe026ed76c9'}
    snapshot = json.loads(gzip.decompress((FORMAL/'検査/F0実行前文書.json.gz').read_bytes()))
    stored = {item['path']: item for item in snapshot['文書']}
    original = {}
    for name, digest in expected.items():
        path = FORMAL / name
        item = stored[path.relative_to(ROOT).as_posix()]
        raw = item['本文'].encode('utf-8')
        assert hashlib.sha256(raw).hexdigest() == digest == item['sha256']
        original[name] = raw

    protected = [SUMMARY, FORMAL / '成果物/集計.json',
                 ROOT / 'work/145_構造イベント入口の採用仕様.md',
                 ROOT / 'work/145構造イベントと旧対照を固定取得へ渡す.py',
                 ROOT / 'work/145出生と金融を分離して実行する.py',
                 ROOT / 'work/145構造イベントの金融集計/集計する.py',
                 ROOT / 'work/145構造イベントの評価/固定入力/固定取得入力.json',
                 ROOT / 'work/145構造イベントの評価/固定入力/入口参照.json']
    protected += [p for p in (ROOT / 'work/145構造イベントの入口').rglob('*')
                  if p.is_file() and p.suffix in ('.go', '.mod', '.exe')]
    protected += list((ROOT / 'study/00144_旧P3のstrongを全時間で評価する').glob('*.md'))
    before_protected = [fingerprint(p) for p in protected]
    data = json.loads(SUMMARY.read_bytes())
    assert data['試行'] == 145 and data['主政策'] == 'U0'
    main_value = data['集計']['all']['U0']['BBO']['3600']['125']
    assert [main_value[k] for k in ('entries','sessions','forward','adverse','neither','censored')] == [87,73,42,18,21,6]
    assert data['主評価']['三項目すべて達成'] is False
    assert data['主評価']['到達済み先着70%以上'] is True
    assert data['主評価']['全73場最低1取得'] is True
    assert data['取得集合数'] == {'C0':81,'A0':2,'B0':4,'U0':87}
    table = policy_table(data)

    # ----------------------------------------
    # 結果は固定後の追記とし、準備時点の条件と区別する。
    result = '''## 実行結果

全73場の自然Source・出生/取得・保存実正逆の300比較を実行した。主U0は87取得/全73場参加、42順/18逆/21未到達/6観測不足、到達済み42/60＝70.00%。**到達済み70%と全場最低1は達成したが、頻度0.12068件/時で共同目標は未達。採用達成とはしない。** H完了分母は42/81＝51.85%、全取得分母は42/87＝48.28%。未到達21件と不足6件を勝ちへ数えず、どの分母の70%かを区別する。

''' + table + '''
金額は独立mini1枚100円/ptのIFD代用で、往復税込77円、C5は追加往復10pt＝1,000円を控除する。主U0のC5利益544,996円/損失334,464円、既知差引+210,532円（PF約1.63）、84件既知/3件未知。追加滑り0の費用条件では+294,532円。未知を0円にせず、片側10枚・同時保有・資金制約・実IFD・必須利益追尾を備えた口座収支とは区別する。

新A0は2取得/2場、0順/0逆/2未到達で、到達済み率の分母は0。新B0は4取得/4場、2順/0逆/2未到達で、到達済み2/2＝100%でも全取得分母は2/4＝50%。**この2/2を安定した成功や一般化の根拠にしない。** 新A/B合計6件のC5既知差引は+10,538円。主87件の81件は旧C0であり、新stream単独で全場参加や高頻度を得た結果ではない。A0の未取得71場、B0の未取得69場も残した。

旧C0全81/73場は方向・Quote・全4stream/全H幅3,240ラベル・60比較で同体を確認。C0と新A/Bの同取得原行重複は0で、U0=81+2+4=87。C0の未来取得予定を新streamの抑止に使っていない。RUは旧C0も含む全U0を実BBO反対側で評価し、13順/55逆/13未到達/6不足＝19.12%、C5既知差引−623,468円。反対率を1−pでは作っていない。

頻度分母はΣ(scene.end−300−scene.start)＝720時間55分、主U0は87/720.9167＝0.12068件/時。名目新規可時間による頻度は副評価で、分母から静かな場・未取得場を落とさない。場ごとの偏りは許容したが、概ね1件/時には届かなかった。

|区分|取得/取得場|順/逆/未到達/不足|到達済み率|C5利益円|C5損失円|C5既知差引円|金額未知件|
|---|---|---|---|---|---|---|---|
|前48場|59 / 48|28/10/17/4|73.68%|373,228|203,617|+169,611|2|
|後25場|28 / 25|14/8/4/2|63.64%|171,768|130,847|+40,921|1|

前48/後25はいずれも全期既使用の記述区分であり、後25場を独立未知期とは呼ばない。主政策・閾値・取得集合を結果後に交換していない。

## 状態遷移で減った箇所

保存Sourceの[非金融診断](根拠/状態遷移のどこで減ったか.md)では、682arm（A524/B158）→45技術confirm（A19/B26）→13出生（A5/B8）→6取得（A2/B4）だった。全armの排他的な終端は、構造幅125超234、I到達282、episode期限91、現在背景28、共通新規限界2、confirm時Last位置不適合32、出生後の終端13で、合計682へ一致する。

I到達282はarm同Raw即取消101/後続Raw181。技術confirm45のうち位置不適合32はcap上限超26/K未回復6だった。足終値の構造回復と、実配送時の現在Lastが取得域内であることは別である。13出生は取得6/TTL失効4/pending LastのK割れ2/最初正常実P域外1に分かれた。Lastが域内でも実Bid/Askの取得域を満たすとは限らない。

仮に45技術confirm全てを取得できても0.062421件/時であり、cap上限だけの変更で頻度問題を解決できる件数ではない。確認未成立356チェックのHist不足318・量比較不足220・CloseのK未回復202・TRガード9は非排他的であり、合計を単一原因の内訳にしない。保存OHLCから個別化できなかった形状は未知のまま残し、その部分から全体へ外挿しない。

次は、構造幅、確認足の粒度と公表時計、勢い回復の初期/完了、背景の方向/強さを分けて問いを立てる。本試行のcap/I/TTL・Hist・量・ADX条件を結果に合わせて書き換えた結論ではなく、改善効果は別試行で検証する。

正本は[集計](成果物/集計.json)、全件は[CSVと分母](閲覧資料.md)、入力・元条件原文・コード・再現範囲は[保管索引](保管索引.json)と[再現手順](再現手順.md)。実receivedAt、mini実板、反転側の注文適格性の再構築、利益追尾の口座検証は未実施で、保存BBOの先着/IFD診断と区別する。
'''
    readme = original['README.md'].decode('utf-8')
    readme = readme.replace(
        '試行00145。2026-11-12、採用条件の正式準備。Source実装・事前人工の完成前で、自然生成・新出生/取得・方向・率/損益は未実行。新しい構造イベントから独立に入口を生み、旧C081とのunionを主U0として事前固定する。',
        '試行00145。2026-11-12、全73場の自然生成・取得・実正逆と金融300比較を実行した。主U0は87取得・到達済み先着率70.00%、全場参加を達成したが、平均0.12068件/時で共同目標は未達。新A/Bは6取得にとどまり、採用達成とはしない。')
    readme = readme.replace('出力数値やSHAは未生成のため記入しない。',
        'F0/F1の実行前正式原文を退避し、保存実正逆の別算術300比較とCSV三表の照合まで実行した。現在の結果は以下へ追記し、元の条件は変更していない。')
    assert 'Source実装・事前人工の完成前' not in readme
    (FORMAL / 'README.md').write_bytes((readme.rstrip()+'\n\n'+result).encode('utf-8'))

    condition_note = '''

## 固定後の実行案内

上記はF0固定時の条件・review・未実行の記録を保持した本文で、現在の実行状況を示す未実行宣言ではない。自然Source、取得、実正逆300比較と独立照合を完了した。閾値・未知処置・時計・取得集合は変更していない。

主U0は87取得/全73場、42順18逆21未到達6不足。到達済み70.00%と全場最低1は達成、平均0.12068件/時は未達で共同目標未達。[実行結果](README.md#実行結果)、[CSVと分母](閲覧資料.md)、[再現手順](再現手順.md)へ進む。元条件と実行前3文書はF0/F1 snapshotへ保存し、現在の追記済み文書を実行前と同一SHAとは扱わない。workパスは実行時の識別名であり、恒久保存との対応は[保管索引](保管索引.json)に残す。
'''
    (FORMAL / '条件.md').write_bytes(original['条件.md']+condition_note.encode('utf-8'))
    settings_note = ('> 現在は実行済み。主U0は87取得・到達済み70.00%・全73場参加、平均0.12068件/時で共同目標未達。'
                     '以下の「準備段階・未実行」はF0時点の原文記録として保持し、現在の数値は末尾の[固定後の実行結果](#固定後の実行結果)へ追記した。\n\n').encode('utf-8')
    raw = original['設定と結果.md']
    boundary = raw.index(b'\n', raw.index(b'\n')+1)+1
    settings = raw[:boundary]+settings_note+raw[boundary:]
    settings_tail = ('\n\n## 固定後の実行結果\n\n'
        '145E01の5政策/300比較を実行した。上の513セル・設定ID・F0時点の未実行表は変更せず保存している。'
        '次表は全73場/実BBO/H60/同幅±125の現在結果。\n\n'+table+'\n'
        '主の70.00%は42/60、H完了分母率51.85%は42/81、全取得分母率48.28%は42/87。'
        'C5は往復77円に追加1,000円を控除した独立mini1枚のIFD代用。主84件既知/3件未知、Last金額null。'
        '到達済み70%と全場最低1は達成、平均0.12068件/時は未達で共同目標未達。'
        '新B0は到達済み2/2だが、取得全4件中2件未到達で少数のため一般化しない。'
        '複合条件の結果をMA/ADX/MACD/量/心理の単独効果としない。'
        '全513セルの役割と今回評価した組合せを区別し、未使用セルを今回検証済みへ変更しない。\n\n'
        '前後区分・利益/損失・funnel・限界は[実行結果](README.md#実行結果)、全件は[CSVと分母](閲覧資料.md)へ。'
        '現在の追記済み文書とF0/F1の原文SHAを区別する。\n')
    (FORMAL / '設定と結果.md').write_bytes(settings+settings_tail.encode('utf-8'))

    # ----------------------------------------
    # 閲覧先と三目次だけを更新し、出力CSV自体は再生成しない。
    viewing = '''# 145のCSVと分母

主結果は全体（all）・政策U0・価格軸BBO・評価60分・同幅125pt。到達済み42/60＝70.00%、H完了42/81＝51.85%、全取得42/87＝48.28%を分けて読む。全73場参加は達成、頻度0.12068件/時は未達で共同目標未達である。

- [全セッション.csv](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/145_構造イベント入口/全セッション.csv)：全73場×81列。政策別取得・利益/損失・既知差引/累計・未知・頻度を比較する。未取得場を落とさない。
- [正逆比較.csv](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/145_構造イベント入口/正逆比較.csv)：300条件×34列。C0/A0/B0/U0/RU、全体/前48/後25、BBO/Last、H30/H60、同幅25/50/100/125/200を含む。
- [入口別診断.csv](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/145_構造イベント入口/入口別診断.csv)：基礎87取得×48列。旧C081/新A02/新B04、出生・実取得・union採否・各政策と実逆側を調べる。今回の同原行重複は0でU0も87件。

新A0は2件ともH60±125未到達で到達済み率は分母0。新B0は2順/0逆/2未到達、到達済み2/2でも全取得分母率50%で、成功の一般化根拠にはしない。A0/B0の0取得場も保存し、旧C0によって全場を補えた結果と区別する。

独立mini1枚100円/pt、往復税込77円。費用C0は追加滑り0、C5は追加往復10pt＝1,000円。政策C0（旧81）と費用C0は別である。利益と損失は取引ごとの費用後正負を分けた絶対額で、主U0のC5利益544,996円/損失334,464円/既知差引+210,532円、84件既知/3件未知。累計は独立入口の合計で口座残高ではない。

全H不足でも既知touchがあればIFD金額既知にできるため、H不足6件と金額未知3件は一致しない。未到達で清算価格不足なら未知とし、空欄を0円へ置き換えない。Lastの金額は空欄。RUは旧C0も含む主U0の全件を、同時点の実BBO反対側で評価する。1−pから反対率を作らない。

RootによるCSV全データ20,289セル・12,687数値の独立再読と3画像の視認を実施済み。[作成記録](検査/CSV作成の確認.json)と[独立再読](検査/CSV全セルの独立再読.json)を保存した。xlsxは生成していない。

全期既使用で、前48/後25も独立未知期ではない。mini実板・片側10枚の同時保有口座・実IFD/必須利益追尾は未検証。[実行結果](README.md#実行結果)、[金融正本](成果物/集計.json)、[再現手順](再現手順.md)を参照する。
'''
    (FORMAL / '閲覧資料.md').write_text(viewing, encoding='utf-8', newline='\n')
    note = ('主U0は87取得/全73場、42順18逆21未到達6不足で到達済み70.00%。'
            '70%と全場参加は達成したが、平均0.12068件/時で共同目標未達。'
            'C5利益544,996円/損失334,464円/既知差引+210,532円、未知3。'
            '新A/Bは計6取得で、新Bの2/2を一般化しない。')
    for path_name, prefix in (('study/README.md',''), ('docs/README.md','../study/'),
                              ('docs/議論/README.md','../../study/')):
        path = ROOT / path_name
        content = path.read_text(encoding='utf-8')
        content = '\n'.join(x for x in content.split('\n') if not x.startswith('[145：新しい構造イベントから入口を生成]'))
        heading, tail = content.split('\n',1)
        link = prefix+'00145_押戻し完了と失敗突破を別の構造イベントで評価する/'
        line = f'[145：新しい構造イベントから入口を生成]({link}README.md)。{note} [CSVと分母]({link}閲覧資料.md)。'
        content = heading+'\n\n'+line+'\n'+tail
        content = content.replace('145の採番・実装・率/頻度の検証はまだ行っていない。',
            'この候補は145として事前固定・実行済み。主は到達済み70%/全場参加を達成したが頻度未達で、共同目標は未達。')
        path.write_text(content, encoding='utf-8', newline='\n')

    # ----------------------------------------
    # 保持範囲と結果表の元値を確認して停止証跡を作成する。
    assert (FORMAL/'条件.md').read_bytes().startswith(original['条件.md'])
    assert (FORMAL/'設定と結果.md').read_bytes().replace(settings_note,b'',1).startswith(original['設定と結果.md'])
    old_rows = [x for x in original['設定と結果.md'].decode('utf-8').splitlines()
                if re.match(r'^\| [A-Z]\d{2} \|',x)]
    new_rows = [x for x in (FORMAL/'設定と結果.md').read_text(encoding='utf-8').splitlines()
                if re.match(r'^\| [A-Z]\d{2} \|',x)]
    assert old_rows == new_rows and len(old_rows)==57
    assert all(len(row.split('|')[3:-1])==9 for row in old_rows)
    assert [fingerprint(p) for p in protected] == before_protected
    targets = [FORMAL/name for name in ('README.md','条件.md','設定と結果.md','閲覧資料.md')]
    targets += [ROOT/name for name in ('study/README.md','docs/README.md','docs/議論/README.md')]
    proof = {'成功':True,'試行':145,'状態':'正式結果反映・編集停止',
        '更新対象':[fingerprint(p) for p in targets],
        '入力':[fingerprint(SUMMARY),fingerprint(ROOT/'work/145全episodeの非金融診断/状態遷移のどこで減ったか.md')],
        '元正式3SHA':expected,'条件prefix完全同体':True,'設定原文は状況注記を除き完全prefix同体':True,
        '汎用表':{'版':7,'行':57,'尺度':9,'セル':513,'全行文字同体':True},
        '主数値':main_value,'主評価':data['主評価'],'保護対象前後同体':before_protected,
        'CSV再生成':False,'Source金融の再計算':False,'Raw価格CSV追加2場読取':False,
        'F0F1原文退避確認':True,'金融値は指定SHA正本から参照':True}
    raw = (json.dumps(proof,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    (OWN/'文書反映の確認.json').write_bytes(raw)
    print(json.dumps({'updated':len(targets),'proof_sha256':hashlib.sha256(raw).hexdigest()},ensure_ascii=True))


if __name__ == '__main__':
    main()
