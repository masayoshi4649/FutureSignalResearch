"""145の追記済み正式文書を、元条件・正本数値・実在リンクから確認する。"""

from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
FORMAL = ROOT/'study/00145_押戻し完了と失敗突破を別の構造イベントで評価する'


def checksum(path: Path) -> str:
    """
    機能: ファイルの現在SHA256を取得する。
    引数: path (Path) は確認対象ファイル。
    返り値: str はSHA256の16進文字列。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 保存正本と正式二表の数値を別読取で照合し、文書の停止証跡を作る。
    引数: なし。新金融・Raw・CSV価格行を読み直さない。
    返り値: None。最終の文書SHAと検査結果をJSONへ保存する。
    """
    report = json.loads((OWN/'文書反映の確認.json').read_bytes())
    data = json.loads((FORMAL/'成果物/集計.json').read_bytes())
    numerical_cells = 0
    for name in ('README.md','設定と結果.md'):
        text = (FORMAL/name).read_text(encoding='utf-8')
        rows = [line.split('|')[1:-1] for line in text.splitlines()
                if re.match(r'^\|(U0|A0|B0|C0|RU)\|\d+ / \d+\|',line)]
        assert len(rows)==5
        for row in rows:
            value = data['集計']['all'][row[0]]['BBO']['3600']['125']
            assert [int(x) for x in row[1].split('/')] == [value['entries'],value['sessions']]
            assert [int(x) for x in row[2].split('/')] == [value[k] for k in ('forward','adverse','neither','censored')]
            for column, numerator, denominator in ((3,value['forward'],value['resolved']),
                                                   (4,value['forward'],value['complete']),
                                                   (5,value['forward'],value['entries'])):
                expected = '—（分母0）' if not denominator else f'{numerator/denominator:.2%}'
                assert row[column] == expected
            assert [int(x.replace(',','')) for x in row[6:]] == [value[k] for k in ('ifd_net5_profit','ifd_net5_loss','ifd_net5_sum','ifd_unknown')]
            numerical_cells += 13
    text = (FORMAL/'README.md').read_text(encoding='utf-8')
    for label, scope in (('前48場','train'),('後25場','validation')):
        row = next(line.split('|')[1:-1] for line in text.splitlines() if line.startswith('|'+label+'|'))
        value = data['集計'][scope]['U0']['BBO']['3600']['125']
        assert [int(x) for x in row[1].split('/')] == [value['entries'],value['sessions']]
        assert [int(x) for x in row[2].split('/')] == [value[k] for k in ('forward','adverse','neither','censored')]
        assert row[3] == f"{value['forward']/value['resolved']:.2%}"
        assert [int(x.replace(',','')) for x in row[4:]] == [value[k] for k in ('ifd_net5_profit','ifd_net5_loss','ifd_net5_sum','ifd_unknown')]
        numerical_cells += 11
    links = 0
    for name in ('README.md','条件.md','設定と結果.md','閲覧資料.md'):
        path = FORMAL/name
        text = path.read_text(encoding='utf-8')
        for target in re.findall(r'\]\(([^)]+)\)',text):
            target = target.split('#',1)[0]
            if target and not target.startswith(('https:','http:')):
                assert (path.parent/target).resolve().is_file(), (name,target)
                links += 1
    for row in report['保護対象前後同体']:
        path = ROOT/row['path']
        assert checksum(path)==row['sha256'] and path.stat().st_size==row['bytes']
    output = []
    for row in report['更新対象']:
        path = ROOT/row['path']
        assert checksum(path)==row['sha256']
        output.append(row)
    for name in ('study/README.md','docs/README.md','docs/議論/README.md'):
        assert (ROOT/name).read_text(encoding='utf-8').count('[145：新しい構造イベントから入口を生成]')==1
    proof = {'成功':True,'試行':145,'状態':'正式結果文書を停止',
             '成果物':output,'文書反映の確認SHA256':checksum(OWN/'文書反映の確認.json'),
             '更新器SHA256':checksum(OWN/'更新する.py'),'確認器SHA256':checksum(Path(__file__)),
             '結果表数値照合セル':numerical_cells,'正式4MDローカルリンク実在':links,
             '条件prefixと513セル保持':True,'保護対象ファイル数':len(report['保護対象前後同体']),
             '保護対象前後同体':True,'主共同目標未達を明記':True,'新Bの2件を一般化しない':True,
             'Raw価格CSV追加2場読取':False,'金融再計算':False,'CSV再生成':False}
    raw=(json.dumps(proof,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    (OWN/'停止の確認.json').write_bytes(raw)
    print(json.dumps({'proof_sha256':hashlib.sha256(raw).hexdigest(),'files':len(output),
                      'protected':len(report['保護対象前後同体']),'table_checks':numerical_cells,'links':links}))


if __name__=='__main__':
    main()
