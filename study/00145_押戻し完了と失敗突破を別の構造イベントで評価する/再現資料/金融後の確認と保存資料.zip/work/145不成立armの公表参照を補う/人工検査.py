"""公表結合の因果・Scope・既知maskを自然データなしで確認する。"""
from pathlib import Path
import importlib.util
import sys
import unittest

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('join145', HERE/'公表を結合する.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class JoinTests(unittest.TestCase):
    """当時参照を将来値へ置換しない境界を確認する。"""

    def test_因果等号と将来拒否(self) -> None:
        """
        機能: 配送の時刻/index/物理行とScopeの不正を拒否する。
        引数: self(JoinTests)。返り値: None。
        """
        p = {'stamp': {'time': 120, 'index': 2, 'source_line': 3},
             'frame': {'frame': {'id': 'p', 'session_id': 'S', 'contract': 'X', 'width_seconds': 300,
                                 'start': 0, 'end': 60, 'available_at': 120, 'delivery_at': 120}}}
        module.causal(p, {'time': 120, 'index': 2, 'source_line': 3}, 'S', 'X')
        for at, scene, contract in [({'time': 119, 'index': 2, 'source_line': 3}, 'S', 'X'),
                ({'time': 120, 'index': 1, 'source_line': 3}, 'S', 'X'),
                ({'time': 120, 'index': 2, 'source_line': 2}, 'S', 'X'),
                ({'time': 120, 'index': 2, 'source_line': 3}, '別場', 'X'),
                ({'time': 120, 'index': 2, 'source_line': 3}, 'S', '別限月')]:
            with self.assertRaises(AssertionError): module.causal(p, at, scene, contract)

    def test_未知と非排他的要素(self) -> None:
        """
        機能: 未知を既知0/不成立に変えず同時組と個別要素を分ける。
        引数: self(JoinTests)。返り値: None。
        """
        self.assertIsNone(module.val({'known': False, 'value': 0}))
        self.assertEqual(module.val({'known': True, 'value': 0}), 0)
        rows = [{'gates': {'x': True}}, {'gates': {'x': False}}, {'gates': {'x': None}}]
        self.assertEqual(module.summarize(rows)['要素']['x'], {'成立': 1, '不成立': 1, '未知': 1})


if __name__ == '__main__':
    unittest.main(verbosity=2)
