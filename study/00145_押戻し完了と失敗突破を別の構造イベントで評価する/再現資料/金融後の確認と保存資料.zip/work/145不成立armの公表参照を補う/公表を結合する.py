"""145の不成立armを当時公表だけへ完全結合して個別要素を補う。"""
from collections import Counter
from pathlib import Path
import argparse
import gzip
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
SOURCES = {
    'Source': ('work/145構造イベントの評価/構造イベントの出生と取得.json', 'b0b70aa28c990291eb5f7b8a8a8f19d29ff4b4231ee4367cee6828af99e69d5c'),
    '固定122公表': ('work/122全場入力/入力.json', '6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec'),
}


def sha(body: bytes) -> str:
    """
    機能: 読取入力又はコードの指紋を求める。
    引数: body(bytes)。返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


def val(item: dict) -> float | None:
    """
    機能: 公表の未知を0へ補わず値を返す。
    引数: item(dict)。返り値: float又はNone。
    """
    return item['value'] if item['known'] else None


def ref(pub: dict) -> dict:
    """
    機能: PublicationをSourceと同じ参照型へ射影する。
    引数: pub(dict)。返り値: dict。
    """
    f = pub['frame']['frame']
    return {'id': f['id'], 'width_seconds': f['width_seconds'], 'end': f['end'], 'delivered': pub['stamp']}


def causal(pub: dict, at: dict, session: str, contract: str) -> None:
    """
    機能: 場・限月・知得時計・市場時計を当該判定以前と検査する。
    引数: pub/at(dict)、session/contract(str)。返り値: None。不一致は例外。
    """
    f, stamp = pub['frame']['frame'], pub['stamp']
    assert f['session_id'] == session and f['contract'] == contract and f['width_seconds'] in (300, 900, 1800)
    assert f['start'] <= f['end'] <= f['available_at'] <= f['delivery_at'] <= stamp['time'] <= at['time']
    assert stamp['index'] <= at['index'] and stamp['source_line'] <= at['source_line']


def field_equal(fields: dict, key: str, expected: float | None) -> None:
    """
    機能: 公表から復元した値をSourceの保存原値/maskと照合する。
    引数: fields(dict)、key(str)、expected(float|None)。返り値: None。
    """
    item = fields.get(key)
    assert item is not None and item['known'] == (expected is not None)
    if expected is not None: assert item['value'] == expected


def summarize(rows: list[dict]) -> dict:
    """
    機能: 非排他的な要素別成立/否定/未知と全同時組を数える。
    引数: rows(list[dict])。返り値: dict。
    """
    names = sorted({k for row in rows for k in row['gates']})
    combinations = Counter(tuple('?' if row['gates'].get(k) is None else 'T' if row['gates'][k] else 'F' for k in names) for row in rows)
    return {'分母': len(rows), '要素別は非排他的': True,
            '要素': {k: {'成立': sum(r['gates'].get(k) is True for r in rows),
                        '不成立': sum(r['gates'].get(k) is False for r in rows),
                        '未知': sum(r['gates'].get(k) is None for r in rows)} for k in names},
            '同時組の列順': names, '同時組': [{'mask': list(k), '件数': n} for k, n in combinations.most_common()]}


def diagnose(source: dict, fixed: dict) -> dict:
    """
    機能: 保存不成立armを現足IDと実連続前足へ結び各AND要素を完全化する。
    引数: source/fixed(dict)。返り値: dict。新しい売買条件は作らない。
    """
    assert source['success'] and source['trial'] == 145 and not source['financial_labels_used']
    assert fixed['trial'] == 122 and len(fixed['scenes']) == len(source['scenes']) == 73
    assert [s['session'] for s in fixed['scenes']] == [s['session'] for s in source['scenes']]
    rows, unresolved = [], []
    pub_count = 0
    for scene_index, (scene, original) in enumerate(zip(source['scenes'], fixed['scenes'])):
        assert scene['contract'] == original['contract']
        assert scene['raw']['sha256'] == original['raw']['sha256']
        indexed = {}; five = []
        for p in original['publications']:
            f = p['frame']['frame']; key = (f['width_seconds'], f['id'])
            assert key not in indexed
            indexed[key] = p
            if f['width_seconds'] == 300: five.append(p)
        pub_count += len(indexed); positions = {p['frame']['frame']['id']: i for i, p in enumerate(five)}
        for check_index, check in enumerate(scene['arm_checks']):
            if not check['stage'].startswith('arm形状不成立/'): continue
            family = check['stage'].split('/')[-1]; assert family in ('A0', 'B0')
            background = check['background']; side = background['direction30'] * (1 if family == 'A0' else -1)
            assert side in (-1, 1) and background['known'] and background['pass']
            locator = f'scenes[{scene_index}].arm_checks[{check_index}]'
            pubs = {}
            try:
                for r in background['refs']:
                    p = indexed[(r['width_seconds'], r['id'])]
                    assert ref(p) == r
                    causal(p, check['at'], scene['session'], scene['contract'])
                    f = p['frame']['frame']; assert check['at']['time'] < f['end'] + f['width_seconds'] + 60
                    pubs[r['width_seconds']] = p
                assert set(pubs) == {300, 900, 1800}
                p = pubs[300]; f = p['frame']['frame']; assert f['price_known']
                need = 1 if family == 'A0' else 3
                i = positions[f['id']]; previous = five[max(0, i-need):i]
                for old in previous: causal(old, check['at'], scene['session'], scene['contract'])
                assert all(a['frame']['frame']['end'] == b['frame']['frame']['start'] and a['frame']['frame']['price_known']
                           for a, b in zip(previous, [*previous[1:], p]))
                assert len(previous) >= (1 if family == 'A0' else 3)
            except (KeyError, AssertionError) as error:
                unresolved.append({'session': scene['session'], 'family': family, 'source_locator': locator,
                                   '理由': type(error).__name__ + ': 参照/連続性/知得時計の結合不能'})
                continue
            fields = check['fields']; tech, ohlc = f['technical'], f['ohlc']
            body, atr = side*(ohlc['close']-ohlc['open']), val(tech['atr'])
            field_equal(fields, 'signed_body', body); field_equal(fields, 'arm_atr', atr)
            gates = {'armATR正': None if atr is None else atr > 0}; expected = []
            if atr is None or atr <= 0: expected.append('armATR未知又は非正')
            if family == 'A0':
                old = previous[-1]['frame']['frame']; prev = old['technical']
                h, ph, ema8, ema21 = val(tech['histogram']), val(prev['histogram']), val(prev['ema8']), val(prev['ema21'])
                dh = None if h is None or ph is None else h-ph
                field_equal(fields, 'actual_hist_delta', dh)
                field_equal(fields, 'previous_ema8', ema8); field_equal(fields, 'previous_ema21', ema21)
                low, high = (None, None) if ema8 is None or ema21 is None else (min(ema8, ema21), max(ema8, ema21))
                gates.update({'元側逆実体': body < 0, '元側Hist実増分悪化': None if dh is None else side*dh < 0,
                              '前足EMA帯接触': None if low is None else ohlc['high'] >= low and ohlc['low'] <= high})
                if dh is None or low is None: expected.append('前足EMA又は実Hist差未知')
                else:
                    field_equal(fields, 'previous_ema_low', low); field_equal(fields, 'previous_ema_high', high)
                    if not all(gates[k] for k in ('元側逆実体', '元側Hist実増分悪化', '前足EMA帯接触')):
                        expected.append('逆実体・Hist悪化・前EMA帯接触が未成立')
            else:
                low = min(x['frame']['frame']['ohlc']['low'] for x in previous)
                high = max(x['frame']['frame']['ohlc']['high'] for x in previous)
                field_equal(fields, 'range_low', low); field_equal(fields, 'range_high', high)
                up, down = ohlc['high'] > high, ohlc['low'] < low
                gates.update({'前3本域正幅': high > low, '両端突破ではない': not (up and down),
                              '元方向端を突破': up if side < 0 else down,
                              '終値は前3本域内': low <= ohlc['close'] <= high, '反転側実体': body > 0})
                if high <= low: expected.append('前3本域幅非正')
                if up and down: expected.append('両端突破で曖昧')
                if not all(gates[k] for k in ('元方向端を突破', '終値は前3本域内', '反転側実体')):
                    expected.append('元方向突破・域内終値・反対実体が未成立')
            assert expected and sorted(expected) == sorted(check['reason'].split('、'))
            assert not all(v is True for v in gates.values())
            rows.append({'session': scene['session'], 'contract': scene['contract'], 'family': family,
                         'side': side, 'source_locator': locator,
                         'at': {k: check['at'][k] for k in ('time', 'index', 'source_line')},
                         'frame5_ref': ref(p), 'previous_refs': [ref(x) for x in previous],
                         'gates': gates, '保存複合理由同体': True})
    assert pub_count == 12794
    summaries = {family: summarize([r for r in rows if r['family'] == family]) for family in ('A0', 'B0')}
    return {'成功': True, '試行': 145, '用途': '既保存不成立armの当時公表による非金融追補',
            '全73場': [s['session'] for s in source['scenes']], '公表総数': pub_count,
            '全結合済み': len(rows), '未解決': unresolved, 'family': summaries, '明細': rows,
            '新条件採用': False, '金融参照': False, 'Source又は元診断変更': False,
            '時計': '最新背景は当時fresh、過去足は実連続性と当時配送以前を検査し現在freshを再要求しない。'}


def main() -> None:
    """
    機能: 指定済み2入力を前後SHA確認し未作成出力先へ追補を保存する。
    引数: CLIのoutput-dir(str)。返り値: None。
    """
    parser = argparse.ArgumentParser(); parser.add_argument('--output-dir', required=True); args = parser.parse_args()
    target = Path(args.output_dir); assert not target.exists()
    docs, records = {}, {}
    for key, (relative, expected) in SOURCES.items():
        p = ROOT/relative; stat = p.stat(); body = p.read_bytes(); assert sha(body) == expected
        docs[key] = json.loads(body); records[key] = {'path': relative, 'sha256': expected, 'bytes': len(body), 'mtime_ns': stat.st_mtime_ns}
    result = diagnose(docs['Source'], docs['固定122公表'])
    for key, item in records.items():
        p = ROOT/item['path']; assert p.stat().st_size == item['bytes'] and p.stat().st_mtime_ns == item['mtime_ns'] and sha(p.read_bytes()) == item['sha256']
    result['入力参照'] = records; target.mkdir(parents=True)
    out = target/'全不成立armの個別内訳.json'; out.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    body = out.read_bytes(); compressed = target/'全不成立armの個別内訳.json.gz'
    compressed.write_bytes(gzip.compress(body, mtime=0))
    summary = {k: v for k, v in result.items() if k != '明細'}
    summary['明細参照'] = {'path': compressed.name, 'sha256': sha(compressed.read_bytes()), 'bytes': compressed.stat().st_size,
                         '解凍SHA256': sha(body), '解凍bytes': len(body)}
    (target/'要約.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'success': True, 'joined': result['全結合済み'], 'unresolved': len(result['未解決']),
                      'family': result['family'], 'sha256': sha(out.read_bytes())}, ensure_ascii=True))


if __name__ == '__main__':
    main()
