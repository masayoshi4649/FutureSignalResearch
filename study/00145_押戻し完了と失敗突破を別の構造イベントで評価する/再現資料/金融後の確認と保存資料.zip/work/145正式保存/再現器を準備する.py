"""144保存観測再現器を別145保存器へ適応する。実データは実行しない。"""
from pathlib import Path


def main() -> None:
    """
    機能: 固定源数を可変にし、145保存観測再集計コードを準備する。
    引数: なし。
    返り値: None。旧再現器と正式文書は変更しない。
    """
    root=Path(__file__).resolve().parents[2];here=Path(__file__).resolve().parent
    old=next((root/'study').glob('00144_*/再現資料/保存観測から再集計する.py'));before=old.read_bytes()
    text=before.decode('utf-8').replace('\r\n','\n').replace('144','145')
    text=text.replace('145の先行保管51源','145の可変数の固定源')
    text=text.replace("FORMAL=Path(__file__).resolve().parents[1]\nROOT=FORMAL.parent.parent", "HERE=Path(__file__).resolve().parent\nif HERE.name=='再現資料':\n    FORMAL=HERE.parent;ROOT=FORMAL.parent.parent\nelse:\n    ROOT=HERE.parent.parent;FORMAL=ROOT/'study/00145_押戻し完了と失敗突破を別の構造イベントで評価する'")
    text=text.replace('旧strongの全成立評価','構造イベントの入口評価').replace('145旧strongの全成立集計','145構造イベントの金融集計')
    text=text.replace("declared={relative(name):h for name,h in f1['ファイル'].items()};assert len(declared)==54 and len(excluded)==3", "declared={relative(name):h for name,h in f1['ファイル'].items()};assert len(declared)==m['F1直接源数']")
    text=text.replace('assert len(bodies)==51',"assert len(bodies)==len(declared)-len(excluded)")
    text=text.replace("'全54参照を解決/保存51源同bytes':True", "'全固定源の参照解決/非複製以外同bytes':True,'固定源数':len(declared),'保存bytes復元数':len(bodies)")
    text=text.replace("'保存51源同体':True", "'保存源同体':True")
    # Root実行先の名称は保存索引の元F1/固定/meta/観測参照から決めます。
    text=text.replace("put('work/145構造イベントの入口評価/F1金融前.json',f1raw,m['F1_SHA256'])", "put(m['F1原文']['復元先'],f1raw,m['F1_SHA256'])")
    oldline="fixed=dest/'work/145構造イベントの入口評価/固定入力/固定取得入力.json';metadata=dest/'work/145構造イベントの入口評価/固定入力/入口参照.json'"
    newline="fixed=dest/next(r['復元先'] for r in m['新共用入力'] if Path(r['保存元']).name=='固定取得入力.json.gz');metadata=dest/next(r['復元先'] for r in m['新共用入力'] if Path(r['保存元']).name=='入口参照.json.gz')"
    assert oldline in text;text=text.replace(oldline,newline)
    text=text.replace("result=dest/'work/145構造イベントの入口評価/固定取得の正逆観測.json';output=dest/'再集計'", "result=dest/m['保存済み正逆観測']['復元先'];output=dest/'再集計'")
    text=text.replace('51源は','保存源は')
    p=here/'保存観測から再集計する.py';assert not p.exists();p.write_text(text,encoding='utf-8');assert old.read_bytes()==before


if __name__=='__main__':main()
