"""145の金融完了通知後にだけ保存観測と金融正本を各一度保存する。"""
from pathlib import Path
import argparse
import json
from 保存部品 import FORMAL,ROOT,sha,save,json_bytes,write


def main() -> None:
    """
    機能: 明示した正逆観測/金融/表のSHAを、恒久索引へ追加する。
    引数: --result/--summary(Path)と各SHA、--tables-sha256、--after-result-notice(bool)。
    返り値: None。保存だけで新Raw/Source/金融を実行しない。
    """
    p=argparse.ArgumentParser()
    for name in ('result','summary'):
        p.add_argument('--'+name,type=Path,required=True);p.add_argument('--'+name+'-sha256',required=True)
    p.add_argument('--tables-sha256',required=True);p.add_argument('--after-result-notice',action='store_true');a=p.parse_args()
    assert a.after_result_notice
    target=FORMAL/'保管索引.json';index=json.loads(target.read_bytes());assert index['F1_SHA256']
    observed=save(a.result.resolve(),FORMAL/'成果物/固定取得の正逆観測.json.gz',a.result_sha256,True)
    aggregate=save(a.summary.resolve(),FORMAL/'成果物/集計.json',a.summary_sha256)
    index.update({'段階':'金融観測1gzip/金融正本を保存。CSV/別算術/事後/再現と正式結果は後続',
        '保存済み正逆観測':observed,'集計正本':aggregate,'表JSON再現期待SHA256':a.tables_sha256,'金融を新規実行':False})
    target.write_bytes(json_bytes(index))
    write(FORMAL/'検査/金融正本の保管確認.json',json_bytes({'成功':True,'試行':145,'観測一度gzip':observed,
        '集計SHA256':a.summary_sha256,'正式3MD変更':False,'新Raw/Source/新金融観測生成':False,'重大不足':[]}))


if __name__=='__main__':main()
