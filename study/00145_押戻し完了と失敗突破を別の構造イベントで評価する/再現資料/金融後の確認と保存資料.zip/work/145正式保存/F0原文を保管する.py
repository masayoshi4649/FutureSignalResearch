"""RootのF0通知後にだけ145固定原文を保存する。"""
from pathlib import Path
import argparse
from 保存部品 import f0


def main() -> None:
    """
    機能: 明示path/SHAのRoot F0を段階保存器へ渡す。
    引数: --f0(Path)、--sha256(str)。
    返り値: None。
    """
    p=argparse.ArgumentParser();p.add_argument('--f0',required=True,type=Path);p.add_argument('--sha256',required=True);a=p.parse_args()
    f0(a.f0.resolve(),a.sha256)


if __name__=='__main__':main()
