"""145の後発検査/保存器を小型ZIPへ保存し、固定前源へ後付けしない。"""
from pathlib import Path
import json
import zipfile
from 保存部品 import ROOT,FORMAL,sha,json_bytes,save,write


def record(path: Path, name: str) -> dict:
    """
    機能: 保存済み小ファイルの指紋と復元先を記録する。
    引数: path(Path)、name(str)は元の復元先。
    返り値: dictは同体保存参照。
    """
    raw=path.read_bytes()
    return {'保存元':path.relative_to(ROOT).as_posix(),'復元先':name,'形式':'同体',
        '保存bytes':len(raw),'保存SHA256':sha(raw),'解凍bytes':len(raw),'解凍SHA256':sha(raw)}


# ----------------------------------------
def main() -> None:
    """
    機能: 金融後の小資料を1ZIPで保存し、CSV作者等は既存恒久ZIPを参照する。
    引数: なし。
    返り値: None。正式3MD/固定源/旧成果を変更しない。
    """
    mpath=FORMAL/'保管索引.json';m=json.loads(mpath.read_bytes())
    sources=[]
    base=ROOT/'work/145正式保存'
    sources.extend(p for p in base.glob('*.py') if p.name!='保存観測から再集計する.py')
    sources.append(base/'準備とF0保存の確認.json')
    specifications={
        '145構造時計の独立準備レビュー':['独立人工_test.go','overlay.json','準備を確認する.py','準備の確認.json'],
        '145転送と運転の独立準備レビュー':['確認する.py','準備の確認.json','F1固定対象追加の確認.json','refs説明追加の確認.json'],
        '145全episodeの非金融診断':['人工検査.py','保存原値を個別に分ける.py','条件と分母.md','段階を診断する.py','準備の確認.json','状態遷移のどこで減ったか.md','結果/段階と削減理由.md'],
        '145正式結果を反映する':['更新する.py','確認する.py','文書反映の確認.json','停止の確認.json'],
    }
    for folder,names in specifications.items():sources.extend(ROOT/'work'/folder/n for n in names)
    old=next((ROOT/'study').glob('00144_*'));oldm=json.loads((old/'保管索引.json').read_bytes())
    m['金融後の共有コード']=oldm['金融後の共有コード']
    # 原診断へ後付けしない追加の122参照照合は、別の停止票と別項目で扱う。
    supplement=ROOT/'work/145不成立armの公表参照を補う'
    supplied=base/'122参照追補の保存指示.json'
    if supplied.exists():
        instruction=json.loads(supplied.read_bytes())
        assert instruction['停止済み'] and instruction['Sourceと原診断変更なし']
        m['122参照照合追補']=[]
        for item in instruction['同体保存']:
            source=supplement/item['元'];target=FORMAL/item['先']
            m['122参照照合追補'].append(save(source,target,item['sha256']))
        for item in instruction['本文リンク調整']:
            source=supplement/item['元'];raw=source.read_bytes();assert sha(raw)==item['sha256']
            body=raw.decode('utf8')
            for old,new in item['置換'].items():body=body.replace(old,new)
            target=FORMAL/item['先'];write(target,body.encode('utf8'))
            m['122参照照合追補'].append(record(target,source.relative_to(ROOT).as_posix())|{'原文SHA256':item['sha256'],'変更は恒久リンクのみ':True})
        for name in instruction['小ZIP']:sources.append(supplement/name)
        sources.append(supplied)
    else:raise AssertionError('122参照追補を停止通知後に保存指定する')
    # 同体で直接保存した原文/金融/段階票を再ZIPしない。
    destination=FORMAL/'再現資料/金融後の確認と保存資料.zip'
    entries=[];unique=set()
    with zipfile.ZipFile(destination,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as out:
        for source in sorted(sources):
            raw=source.read_bytes();name=source.relative_to(ROOT).as_posix()
            assert len(raw)<1_000_000
            if name in unique:continue
            unique.add(name);out.writestr(name,raw)
            entries.append({'復元先':name,'ZIP内path':name,'sha256':sha(raw),'bytes':len(raw)})
    with zipfile.ZipFile(destination) as saved:
        for item in entries:assert sha(saved.read(item['ZIP内path']))==item['sha256']
    m['金融後の小資料']={'保存元ZIP':destination.relative_to(ROOT).as_posix(),'ZIP_SHA256':sha(destination.read_bytes()),
        '格納源数':len(entries),'格納源':entries,'金融前固定への後付け':False}
    m['再集計器']=record(FORMAL/'再現資料/保存観測から再集計する.py','work/145正式保存/保存観測から再集計する.py')
    result=ROOT/'work/145正式結果を反映する'
    for name,target in [('文書反映の確認.json','結果文書の確認.json'),('停止の確認.json','結果文書の停止.json')]:
        source=result/name;save(source,FORMAL/'検査'/target,sha(source.read_bytes()))
    m['金融後正式文書SHA256']={name:sha((FORMAL/name).read_bytes()) for name in ('README.md','条件.md','設定と結果.md','閲覧資料.md')}
    m['正式結果文書確認SHA256']=sha((FORMAL/'検査/結果文書の確認.json').read_bytes())
    m['段階']='正式結果/固定前原文/全55参照/生成入力/観測/金融/CSV/非金融診断/追補/再集計を保存。最終確認待ち'
    mpath.write_bytes(json_bytes(m))
    print(json.dumps({'成功':True,'後発ZIP_SHA256':m['金融後の小資料']['ZIP_SHA256'],'格納源数':len(entries),'追加固定の偽造':False},ensure_ascii=False))


if __name__=='__main__':main()
