"""145のRoot金融/CSV/Source非金融診断を分けて保存する。正式3MDは変更しない。"""
from pathlib import Path
import json
from 保存部品 import ROOT,FORMAL,INPUTS,sha,save,json_bytes,write

OWN=ROOT/'work/145構造イベントの評価'
CSV=ROOT/'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/145_構造イベント入口'


def exact(source: Path, target: Path) -> dict:
    """
    機能: 停止済み小成果を同体保存する。
    引数: source/target(Path)。
    返り値: dictは保存参照。
    """
    return save(source,target,sha(source.read_bytes()))


# ----------------------------------------
def main() -> None:
    """
    機能: 保存金融とSourceだけのfunnelを区別し各一度保存する。
    引数: なし。
    返り値: None。Root正式3MD/Source/AGG/旧成果を変更しない。
    """
    mpath=FORMAL/'保管索引.json';m=json.loads(mpath.read_bytes())
    for source,name in [(OWN/'観測の完了.json','観測の完了.json'),(OWN/'集計の完了.json','集計の完了.json'),
        (OWN/'出生の完了.json','出生の完了.json'),(OWN/'転送の完了.json','転送の完了.json'),
        (OWN/'金融評価/集計完了.json','集計器の完了.json'),(OWN/'金融別算術の確認.json','金融別算術の確認.json'),
        (OWN/'CSV全セルの独立再読.json','CSV全セルの独立再読.json'),(CSV/'CSVの確認.json','CSV作成の確認.json')]:exact(source,FORMAL/'検査'/name)
    m['金融別算術SHA256']=sha((FORMAL/'検査/金融別算術の確認.json').read_bytes())
    assert m['金融別算術SHA256']=='aa2e8979be245869bc91eb52e1ffac93a5d5d014c2bd5025b7421f8415c58899'
    source=ROOT/'work/145全episodeの非金融診断';raw=(source/'停止の確認.json').read_bytes()
    assert sha(raw)=='f8785461771ef603e4bcb74230b48574d79e9a6cc513991a1f15061838d42584'
    stopped=json.loads(raw);assert stopped['成功'] and stopped['編集停止'] and not stopped['新金融読取']
    for name,item in stopped['停止対象'].items():assert sha((source/name).read_bytes())==item['sha256']
    exact(source/'停止の確認.json',FORMAL/'検査/Source非金融診断の停止.json')
    exact(source/'結果/診断の確認.json',FORMAL/'検査/Source段階診断の確認.json')
    funnel=save(source/'結果/全73場の段階件数.json',FORMAL/'根拠/全73場の段階件数.json.gz',stopped['停止対象']['結果\\全73場の段階件数.json']['sha256'],True)
    details=save(source/'結果/保存原値の個別内訳.json',FORMAL/'根拠/保存原値の個別内訳.json.gz',stopped['停止対象']['結果\\保存原値の個別内訳.json']['sha256'],True)
    body=(source/'状態遷移のどこで減ったか.md').read_text('utf-8').replace('(結果/全73場の段階件数.json)','(全73場の段階件数.json.gz)').replace('(結果/保存原値の個別内訳.json)','(保存原値の個別内訳.json.gz)')
    write(FORMAL/'根拠/状態遷移のどこで減ったか.md',body.encode('utf-8'))
    exact(ROOT/'work/145保存観測の再現確認/保存観測からの再現確認.json',FORMAL/'検査/保存観測からの再現確認.json')
    exact(ROOT/'work/145正式保存/保存観測から再集計する.py',FORMAL/'再現資料/保存観測から再集計する.py')
    m['Source非金融段階票']=funnel;m['Source非金融個別票']=details;m['Source非金融診断SHA256']=sha(raw)
    m['保存観測再現SHA256']=sha((FORMAL/'検査/保存観測からの再現確認.json').read_bytes())
    reader=json.loads((FORMAL/'検査/CSV全セルの独立再読.json').read_bytes());assert reader['成功'] and reader['全データセル比較数']==20289 and reader['数値比較数']==12687
    m['CSV正本']=CSV.relative_to(ROOT).as_posix();m['CSV_SHA256']={Path(t['CSV']['path']).name:t['CSV']['sha256'] for t in reader['表別']}
    for name,h in m['CSV_SHA256'].items():assert sha((CSV/name).read_bytes())==h
    m['段階']='F0/F1/生成入力/観測/金融/Root別算術/CSV/Source非金融診断/保存観測再現を保存。正式結果と最終確認は後続'
    mpath.write_bytes(json_bytes(m))
    write(INPUTS/'README.md',('# 145の構造イベント共用入力\n\nSource・固定取得・入口参照を各一度gzip保存。元bytes/圧縮SHAと復元先は[保管索引](../../study/'+FORMAL.name+'/保管索引.json)を参照する。原板・177MB派生・実行体を重複保存しない。\n').encode())
    print(json.dumps({'成功':True,'金融別算術SHA256':m['金融別算術SHA256'],'Source非金融診断SHA256':m['Source非金融診断SHA256'],'保存観測再現SHA256':m['保存観測再現SHA256']},ensure_ascii=False))


if __name__=='__main__':main()
