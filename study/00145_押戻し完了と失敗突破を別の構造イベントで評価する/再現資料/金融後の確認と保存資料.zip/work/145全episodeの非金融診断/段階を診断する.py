"""145の保存Sourceだけから全episodeと削減理由を集計する。"""
from collections import Counter
from pathlib import Path
import argparse
import hashlib
import json
import math

HERE = Path(__file__).resolve().parent
INPUT_SHA = '6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec'
FAMILIES = ('A0', 'B0')


def sha(body: bytes) -> str:
    """
    機能: 読取Source又はコードのSHAを求める。
    引数: body(bytes)。返り値: str。
    """
    return hashlib.sha256(body).hexdigest()


def reasons(items: list[list[str]]) -> dict:
    """
    機能: 複合理由を1チェック1組と各要素の非排他的件数へ分ける。
    引数: items(list[list[str]])。返り値: dict。
    """
    atoms, combinations = Counter(), Counter()
    for row in items:
        unique = sorted(set(row))
        atoms.update(unique)
        combinations[tuple(unique)] += 1
    return {'分母チェック数': len(items), '理由別は非排他的': True,
            '各理由': dict(atoms.most_common()),
            '理由の組': [{'理由': list(k), '件数': v} for k, v in combinations.most_common()]}


def family_summary(episodes: list[dict], events: list[dict], checks: list[dict], family: str) -> dict:
    """
    機能: A又はBのepisode・確認・出生・取得を別分母で数える。
    引数: episodes/events/checks(list[dict])、family(str)。返り値: dict。
    """
    es = [e for e in episodes if e['family'] == family]
    ev = [e for e in events if e['family'] == family]
    shape = [c for c in checks if c['stage'] == 'arm形状不成立/' + family]
    waiting = [trace for e in es for trace in e['trace'] if trace['stage'] == '確認待機']
    terminal = Counter(e['status'] for e in es)
    filled = [e for e in ev if e['status'] == 'filled']
    confirmed = [e for e in es if e['confirm'] is not None]
    background_losses = [e for e in es if e['status'] == 'background_lost']
    assessments = [e['trace'][-1]['background'] for e in background_losses]
    return {'family': family, '背景通過後のarm形状評価数': len(es) + len(shape),
            'arm形状不成立': len(shape), 'episode': len(es),
            '構造幅不適合': terminal['structure_width_rejected'],
            '背景取消': terminal['background_lost'],
            '背景取消内訳': {'現在必要値未知': sum(not a['known'] for a in assessments),
                           '必要値既知で不成立又はfresh5不適合': sum(a['known'] for a in assessments)},
            'episode期限': terminal['episode_expired'], 'pending期限': terminal['unfilled_expired'],
            '共通限界': terminal['force_close'], '構造連続性切断': terminal['structure_disconnected'],
            'I到達': terminal['invalidation_reached'], 'EOFepisode': terminal['eof_unfinished'],
            '確認未成立チェック数': len(waiting),
            '確認未成立を経験したepisode数': sum(any(t['stage'] == '確認待機' for t in e['trace']) for e in es),
            '技術confirm': len(confirmed), 'confirm時Last位置reject': terminal['confirm_position_rejected'],
            '出生': len(ev), 'pending中Last位置reject': terminal['last_position_rejected'],
            '最初正常実P位置reject': terminal['entry_position_rejected'], 'filled': len(filled),
            'episode終端status': dict(terminal), 'event終端status': dict(Counter(e['status'] for e in ev)),
            'arm形状不成立理由': reasons([c['reason'].split('、') for c in shape]),
            '確認未成立理由': reasons([t['evidence']['reasons'] for t in waiting]),
            '背景取消理由': reasons([a['reasons'] for a in assessments])}


def aggregate(source: dict) -> dict:
    """
    機能: 全73場と0件場を落とさずSource非金融funnelを組み立てる。
    引数: source(dict)。返り値: dict。生価格と金融ラベルは出力しない。
    """
    assert source['success'] and source['trial'] == 145 and source['input_sha256'] == INPUT_SHA
    assert source['financial_labels_used'] is False and source['source_positions_used'] is False
    scenes = source['scenes']; sessions = [s['session'] for s in scenes]
    assert len(scenes) == len(set(sessions)) == 73 and sessions == sorted(sessions)
    assert sum(s.endswith('_Day') for s in sessions) == 37 and sum(s.endswith('_Night') for s in sessions) == 36
    all_episodes, all_events, all_checks, per_scene = [], [], [], []
    counter = Counter()
    for s in scenes:
        assert s['success'] and s['counts'] == s['quality'] == s['expected_quality']
        assert s['actual_sha256'] == s['raw']['sha256'] and s['stat_before'] == s['stat_after']
        assert s['raw_passes'] == 1 and s['expected_accepted'] == s['counts']['source_parser_accepted']
        episodes, events, checks = s['episodes'], s['events'], s['arm_checks']
        assert all(type(x) is list for x in (episodes, events, checks))
        by_episode = {e['id']: e for e in episodes}
        assert len(by_episode) == len(episodes) and len({e['id'] for e in events}) == len(events)
        for e in episodes:
            assert e['family'] in FAMILIES and e['side'] in (-1, 1) and e['status'] not in ('armed', 'pending')
        fill_rows = set()
        for e in events:
            episode = by_episode[e['episode_id']]
            assert episode['event_id'] == e['id'] and episode['family'] == e['family'] and episode['side'] == e['side']
            assert e['status'] != 'pending' and e['confirm'] == episode['confirm']
            assert (e['entryQuote'] is not None) == (e['status'] == 'filled')
            if e['status'] == 'filled':
                q = e['entryQuote']; key = (q['time'], q['index'], q['source_line'])
                assert key not in fill_rows; fill_rows.add(key)
        hours = (s['end'] - 300 - s['start']) / 3600
        assert math.isfinite(hours) and hours > 0
        fs = {f: family_summary(episodes, events, checks, f) for f in FAMILIES}
        background_checks = [c for c in checks if c['stage'] == 'arm背景不成立']
        counted_new5 = len(episodes) + sum(fs[f]['arm形状不成立'] for f in FAMILIES) + len(background_checks) + s['stats'].get('arm最新5価格未知又はfresh不足', 0)
        residual = s['stats'].get('新5分処理', 0) - counted_new5
        assert residual >= 0
        for f in FAMILIES:
            assert fs[f]['episode'] == s['stats'].get('arm/' + f, 0)
            assert fs[f]['出生'] == s['stats'].get('出生/' + f, 0)
            assert fs[f]['filled'] == s['stats'].get('取得/' + f, 0)
        per_scene.append({'session': s['session'], 'contract': s['contract'], 'ザラバ名目時間h': hours,
                          '原行採用数': s['counts']['source_parser_accepted'], '最新5分初知枠': s['stats'].get('新5分処理', 0),
                          'arm背景不成立枠': len(background_checks),
                          'arm時最新5価格未知又はfresh不足枠': s['stats'].get('arm最新5価格未知又はfresh不足', 0),
                          '未細分の非arm最新5枠': residual, 'episode': len(episodes), '出生': len(events),
                          'filled': len(fill_rows), '取得ゼロ': len(fill_rows) == 0, 'family': fs,
                          '原板指紋': {'path': s['raw']['path'], 'sha256': s['actual_sha256'], 'stat': s['stat_before']}})
        counter.update(s['stats']); all_episodes.extend(episodes); all_events.extend(events); all_checks.extend(checks)
    families = {f: family_summary(all_episodes, all_events, all_checks, f) for f in FAMILIES}
    hours = sum(s['ザラバ名目時間h'] for s in per_scene)
    fills = sum(e['status'] == 'filled' for e in all_events)
    assert len(all_episodes) == source['summary'].get('episode数', 0)
    assert len(all_events) == source['summary'].get('出生数', 0) and fills == source['summary'].get('取得数', 0)
    return {'成功': True, '試行': 145, '非金融Source診断': True, '新条件採用': False,
            '全場数': 73, 'episode': len(all_episodes), '出生': len(all_events), 'filled': fills,
            '取得場数': sum(not s['取得ゼロ'] for s in per_scene), '取得ゼロ場': [s['session'] for s in per_scene if s['取得ゼロ']],
            'ザラバ名目時間h': hours, '時間加重取得頻度毎h': fills / hours,
            'family取得場数': {f: sum(s['family'][f]['filled'] > 0 for s in per_scene) for f in FAMILIES},
            'family取得ゼロ場': {f: [s['session'] for s in per_scene if s['family'][f]['filled'] == 0] for f in FAMILIES},
            '最新5分初知枠': sum(s['最新5分初知枠'] for s in per_scene),
            'arm背景不成立枠': sum(s['arm背景不成立枠'] for s in per_scene),
            '未細分の非arm最新5枠': sum(s['未細分の非arm最新5枠'] for s in per_scene),
            'family': families, '全73場': per_scene, '全stage統計': dict(counter),
            '分母と限界': ['最新5分初知枠は同Raw全配送後の最新IDだけ。catch-upで履歴へ入る古い5分を足数に加えない。全幅の公表総数ではない。',
                       '未細分の非arm最新5枠は占有中・取消Raw・新規限界等を含み、Sourceにない各足理由を推定しない。',
                       '確認未成立はチェック数とepisode数を区別。理由の組は排他的、各理由は非排他的。',
                       '原行採用数・最新5枠・背景通過後arm・episode・技術confirm・出生・取得は別分母。',
                       '頻度は全73場のザラバ名目時間で加重。C0unionの頻度/全場参加と新単独の取得を混同しない。',
                       '損益・先着・原板再走査を行っていない。']}


def markdown(result: dict) -> str:
    """
    機能: stage分母と主な削減を小さな日本語表へする。
    引数: result(dict)。返り値: strはMarkdown。
    """
    lines = ['# 145・全episodeの非金融funnel', '', '保存Sourceだけを集計。新金融・原板・価格CSV・追加2場は未読。新条件を採用しない。', '',
             f"全73場、episode {result['episode']}、出生 {result['出生']}、取得 {result['filled']}、取得場 {result['取得場数']}/73。",
             f"全場ザラバ名目時間 {result['ザラバ名目時間h']:.6f}h、時間加重頻度 {result['時間加重取得頻度毎h']:.6f}件/h。", '',
             '|段階/理由|A0|B0|', '|---|---:|---:|']
    keys = ['背景通過後のarm形状評価数', 'arm形状不成立', 'episode', '構造幅不適合', '背景取消', 'episode期限', 'pending期限',
            '共通限界', '構造連続性切断', 'I到達', '確認未成立チェック数', '確認未成立を経験したepisode数', '技術confirm',
            'confirm時Last位置reject', '出生', 'pending中Last位置reject', '最初正常実P位置reject', 'filled']
    for key in keys:
        lines.append(f"|{key}|{result['family']['A0'][key]}|{result['family']['B0'][key]}|")
    lines += ['', 'これらの行は異なる段階/分母を含み、縦方向に単純加算しない。episode終端statusの全件内訳はJSONに保存した。', '',
              f"最新5分初知枠 {result['最新5分初知枠']}、arm背景不成立枠 {result['arm背景不成立枠']}、未細分の非arm最新5枠 {result['未細分の非arm最新5枠']}。", '', '## 未成立の複合理由', '']
    for f in FAMILIES:
        for field in ('arm形状不成立理由', '確認未成立理由', '背景取消理由'):
            data = result['family'][f][field]
            lines.append(f"{f}・{field}：分母{data['分母チェック数']}チェック。各理由は非排他的。")
            lines.append('')
            for row in data['理由の組'][:6]:
                lines.append(f"- {row['件数']}件：{' / '.join(row['理由']) or '理由なし'}")
            lines.append('')
    lines += ['## 取得ゼロ場', '', ' / '.join(result['取得ゼロ場']) or 'なし', '', '## 分母と限界', '']
    lines += ['- ' + text for text in result['分母と限界']]
    lines += ['', '全73場・各familyの0件場・全理由組・stage原数は[JSON](全73場の段階件数.json)を参照。', '']
    return '\n'.join(lines)


def main() -> None:
    """
    機能: Root完成通知後のSourceを指定SHAで確認し未作成先へ診断する。
    引数: CLIのsource/sha256/output-dir(str)。返り値: None。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', required=True); parser.add_argument('--sha256', required=True)
    parser.add_argument('--output-dir', required=True)
    args = parser.parse_args()
    assert len(args.sha256) == 64 and all(c in '0123456789abcdef' for c in args.sha256)
    target = Path(args.output_dir); assert not target.exists(), '未作成出力先のみ'
    path = Path(args.source); before = path.stat(); body = path.read_bytes(); assert sha(body) == args.sha256
    result = aggregate(json.loads(body))
    assert before.st_size == path.stat().st_size and before.st_mtime_ns == path.stat().st_mtime_ns
    assert sha(path.read_bytes()) == args.sha256
    result['Source参照'] = {'path': str(path), 'sha256': args.sha256, 'bytes': len(body), 'mtime_ns': before.st_mtime_ns}
    target.mkdir(parents=True)
    out = target/'全73場の段階件数.json'; out.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    note = target/'段階と削減理由.md'; note.write_text(markdown(result), encoding='utf-8')
    proof = {'成功': True, '試行': 145, '作業': '保存Source全episodeの非金融funnel診断', 'Source参照': result['Source参照'],
             '診断コードSHA256': sha(Path(__file__).read_bytes()), '出力': {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())} for p in (out, note)},
             '原板再読': False, '価格CSV読取': False, '金融読取': False, '追加2場読取': False, '新条件採用': False}
    proof_path = target/'診断の確認.json'; proof_path.write_text(json.dumps(proof, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'success': True, 'proof_sha256': sha(proof_path.read_bytes()), 'episodes': result['episode'], 'births': result['出生'], 'fills': result['filled']}, ensure_ascii=True))


if __name__ == '__main__':
    main()
