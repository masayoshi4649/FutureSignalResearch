"""145非金融funnelの分母・0場・複合理由を人工だけで確認する。"""
import copy
import importlib.util
from pathlib import Path
import sys
import unittest

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('funnel145', HERE/'段階を診断する.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def source_fixture() -> dict:
    """
    機能: 73場すべて0出生の人工Source形を作る。
    引数: なし。返り値: dict。自然値を使わない。
    """
    quality = {'lines': 1, 'clock_missing': 0, 'clock_invalid': 0, 'outside_session': 0,
               'backward_clock': 0, 'last_non_positive': 0, 'last_non_finite': 0,
               'bad_bbo': 0, 'source_parser_accepted': 1, 'cutoff_excluded': 0, 'delivered': 1}
    scenes = []
    for n in range(73):
        session = f'人工{n:02d}' + ('_Day' if n < 37 else '_Night')
        scenes.append({'success': True, 'session': session, 'contract': 'X', 'start': n*10000,
                       'end': n*10000+8000, 'raw': {'path': '人工/原板未使用', 'sha256': 'a'*64},
                       'actual_sha256': 'a'*64, 'stat_before': {'bytes': 1, 'mtime_ns': 1},
                       'stat_after': {'bytes': 1, 'mtime_ns': 1}, 'counts': dict(quality),
                       'quality': dict(quality), 'expected_quality': dict(quality),
                       'expected_accepted': 1, 'raw_passes': 1, 'episodes': [], 'events': [], 'arm_checks': [], 'stats': {}})
    return {'success': True, 'trial': 145, 'input_sha256': module.INPUT_SHA,
            'financial_labels_used': False, 'source_positions_used': False,
            'scenes': scenes, 'summary': {'episode数': 0, '出生数': 0, '取得数': 0}}


def mixed_fixture() -> dict:
    """
    機能: 幅拒否・背景取消・pending失効・取得の4episodeを作る。
    引数: なし。返り値: dict。
    """
    source = source_fixture(); s = source['scenes'][0]
    data = [('a1', 'A0', 'structure_width_rejected', False), ('a2', 'A0', 'background_lost', False),
            ('a3', 'A0', 'unfilled_expired', True), ('b1', 'B0', 'filled', True)]
    for identity, family, status, confirmed in data:
        trace = []
        if identity == 'a2':
            trace = [{'stage': '確認待機', 'evidence': {'reasons': ['Hist', '量']}},
                     {'stage': '確認待機', 'evidence': {'reasons': ['Hist']}},
                     {'stage': '終了', 'background': {'known': False, 'reasons': ['ADX未知']}}]
        episode = {'id': identity, 'family': family, 'side': 1, 'status': status,
                   'confirm': {} if confirmed else None, 'trace': trace, 'event_id': identity+'/born' if confirmed else ''}
        s['episodes'].append(episode)
        if confirmed:
            s['events'].append({'id': identity+'/born', 'family': family, 'side': 1, 'status': status,
                                'episode_id': identity, 'confirm': {},
                                'entryQuote': {'time': 5, 'index': 5, 'source_line': 6} if status == 'filled' else None})
    s['arm_checks'] = [{'stage': 'arm形状不成立/A0', 'reason': '前EMA未知、逆実体なし'},
                       {'stage': 'arm背景不成立', 'reason': 'A/B背景不成立'}]
    s['stats'] = {'新5分処理': 10, 'arm/A0': 3, 'arm/B0': 1, '出生/A0': 1, '出生/B0': 1, '取得/B0': 1}
    source['summary'] = {'episode数': 4, '出生数': 2, '取得数': 1}
    return source


class FunnelTests(unittest.TestCase):
    """非金融Sourceだけの集計整合を確認する。"""

    def test_全73ゼロ場を保持(self) -> None:
        """
        機能: 全0件でも全73と両familyの0場を保持する。
        引数: self(FunnelTests)。返り値: None。
        """
        result = module.aggregate(source_fixture())
        self.assertEqual((result['全場数'], result['filled'], result['取得場数']), (73, 0, 0))
        self.assertEqual(len(result['取得ゼロ場']), 73)
        self.assertEqual(len(result['family取得ゼロ場']['A0']), 73)

    def test_段階と非排他的理由(self) -> None:
        """
        機能: 確認チェックとepisodeを分け、複合理由を加算誤認しない。
        引数: self(FunnelTests)。返り値: None。
        """
        original = mixed_fixture(); unchanged = copy.deepcopy(original)
        result = module.aggregate(original); a = result['family']['A0']
        self.assertEqual((result['episode'], result['出生'], result['filled'], result['取得場数']), (4, 2, 1, 1))
        self.assertEqual((a['確認未成立チェック数'], a['確認未成立を経験したepisode数'], a['技術confirm']), (2, 1, 1))
        self.assertEqual(a['確認未成立理由']['各理由'], {'Hist': 2, '量': 1})
        self.assertEqual((a['構造幅不適合'], a['背景取消'], a['pending期限']), (1, 1, 1))
        self.assertEqual(result['未細分の非arm最新5枠'], 4)
        self.assertEqual(original, unchanged)
        self.assertIn('全73場', module.markdown(result))

    def test_関係と品質の破損拒否(self) -> None:
        """
        機能: Source自身の件数・品質・結合不一致を除外せず拒否する。
        引数: self(FunnelTests)。返り値: None。
        """
        for mode in ('場数', 'summary', 'quality', 'episode'):
            value = mixed_fixture()
            if mode == '場数': value['scenes'].pop()
            elif mode == 'summary': value['summary']['取得数'] = 2
            elif mode == 'quality': value['scenes'][0]['counts']['lines'] = 2
            else: value['scenes'][0]['events'][0]['episode_id'] = '存在しない'
            with self.assertRaises((AssertionError, KeyError)): module.aggregate(value)


if __name__ == '__main__':
    unittest.main(verbosity=2)
