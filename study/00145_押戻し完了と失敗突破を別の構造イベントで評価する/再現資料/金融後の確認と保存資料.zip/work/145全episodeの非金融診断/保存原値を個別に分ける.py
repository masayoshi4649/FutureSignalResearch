"""保存済みSourceの原値だけで、複合ゲートと現在位置を分解する。"""
from collections import Counter
from pathlib import Path
import argparse
import hashlib
import json


def value(fields: dict, key: str) -> float | None:
    """
    機能: 既知maskを保ち未知を0にしない。
    引数: fields(dict)、key(str)。返り値: float又はNone。
    """
    item = fields.get(key)
    return None if item is None or not item['known'] else item['value']


def compare(v: float | None, relation: str) -> bool | None:
    """
    機能: 符号比較の未知と既知不成立を分ける。
    引数: v(float|None)、relation(str)。返り値: bool又はNone。
    """
    if v is None: return None
    return {'正': v > 0, '負': v < 0, '非負': v >= 0}[relation]


def masks(rows: list[dict]) -> dict:
    """
    機能: 固定論理要素の成立・不成立・未知と同時組を数える。
    引数: rows(list[dict])。返り値: dict。非排他的要素を単一原因と呼ばない。
    """
    names = sorted({k for r in rows for k in r})
    combinations = Counter(tuple('?' if r.get(k) is None else 'T' if r[k] else 'F' for k in names) for r in rows)
    return {'分母': len(rows), '要素別は非排他的': True, '要素': {k: {'成立': sum(r.get(k) is True for r in rows),
            '不成立': sum(r.get(k) is False for r in rows), '未知': sum(r.get(k) is None for r in rows)} for k in names},
            '組の列順': names, '同時組': [{'mask': list(k), '件数': v} for k, v in combinations.most_common()]}


def extract(source: dict) -> dict:
    """
    機能: 保存pubの同体結合、arm個別要素、I/位置/全13出生を非金融で診断する。
    引数: source(dict)。返り値: dict。
    """
    assert source['success'] and source['trial'] == 145 and not source['financial_labels_used']
    registry = {}
    for scene in source['scenes']:
        for ep in scene['episodes']:
            evidences = [ep['arm'], ep['confirm']] + [t.get('evidence') for t in ep['trace']]
            for e in evidences:
                if e is None: continue
                for p in [e['frame'], *e['previous']]:
                    f = p['frame']['frame']; key = (scene['session'], f['id'])
                    assert key not in registry or registry[key] == p
                    registry[key] = p
    shape = {'A0': [], 'B0': []}; coverage = Counter(); backgrounds = []
    counts = Counter(); details = []
    for scene in source['scenes']:
        for check in scene['arm_checks']:
            a, fields = check['background'], check['fields']
            if check['stage'] == 'arm背景不成立':
                f = a['fields']; d = a['direction30']; gap, slope, di, adx = (value(f, k) for k in ('gap30', 'ema21_delta30', 'di_difference15', 'adx_delta15'))
                backgrounds.append({'三尺度価格既知fresh': all(value(f, 'price_known_'+str(w)) == 1 for w in (300, 900, 1800)),
                                    '30方向d定義': None if gap is None or slope is None else d != 0,
                                    'DI15がd向き': None if di is None or d == 0 else d*di > 0,
                                    'ADX15増分非負_A': compare(adx, '非負'), 'ADX15増分負_B': compare(adx, '負')})
                continue
            if not check['stage'].startswith('arm形状不成立/'): continue
            family = check['stage'].split('/')[-1]; side = a['direction30'] * (1 if family == 'A0' else -1)
            refs = [r for r in a['refs'] if r['width_seconds'] == 300]; assert len(refs) == 1
            ref = refs[0]; p = registry.get((scene['session'], ref['id'])); foot = None
            if p is not None:
                f = p['frame']['frame']
                assert ref == {'id': f['id'], 'width_seconds': f['width_seconds'], 'end': f['end'], 'delivered': p['stamp']}
                assert all(p['stamp'][k] <= check['at'][k] for k in ('time', 'index', 'source_line'))
                foot = f['ohlc']; coverage[family+'/価格足復元'] += 1
            body = value(fields, 'signed_body'); atr = value(fields, 'arm_atr')
            row = {'armATR正': compare(atr, '正')}
            if family == 'A0':
                dh = value(fields, 'actual_hist_delta'); low, high = value(fields, 'previous_ema_low'), value(fields, 'previous_ema_high')
                row.update({'元側逆実体': compare(body, '負'), '元側Hist実増分悪化': compare(None if dh is None else side*dh, '負'),
                            '前足EMA帯接触': None if foot is None or low is None or high is None else foot['high'] >= low and foot['low'] <= high})
            else:
                low, high = value(fields, 'range_low'), value(fields, 'range_high')
                row.update({'反転側実体': compare(body, '正'), '前3本域正幅': None if low is None or high is None else high > low,
                            '両端突破ではない': '両端突破で曖昧' not in check['reason'],
                            '元方向端を突破': None if foot is None or low is None or high is None else (foot['high'] > high if side < 0 else foot['low'] < low),
                            '終値は前3本域内': None if foot is None or low is None or high is None else low <= foot['close'] <= high})
            shape[family].append(row)
        for e in scene['episodes']:
            q, st, side = e['terminationQuote'], e['structure'], e['side']
            if e['status'] == 'invalidation_reached':
                immediate = all(q[k] == e['arm']['at'][k] for k in ('time', 'index', 'source_line'))
                counts[e['family']+('/arm同Raw_I' if immediate else '/後続Raw_I')] += 1
            if e['status'] == 'confirm_position_rejected':
                distance = side*(q['last']-st['k'])
                counts[e['family']+('/confirm_K未達' if distance < 0 else '/confirm_cap超過')] += 1
        for event in scene['events']:
            q = event['terminationQuote'] or event['entryQuote']; side, st = event['side'], event['structure']
            assert q is not None
            price = q['ask'] if side > 0 else q['bid']
            actual = event['evaluation'] is not None
            details.append({'session': scene['session'], 'id': event['id'], 'family': event['family'], 'status': event['status'],
                            'birth_clock': event['birth']['clock'], 'termination_clock': q['clock'],
                            '出生から終端観測秒': q['time']-event['birth']['time'], 'pending期限秒': event['expires']-event['birth']['time'],
                            'structure': st, '出生Last_K符号距離': side*(event['birth']['last']-st['k']),
                            '終端Last_K符号距離': side*(q['last']-st['k']),
                            '正常実P評価あり': actual, '評価P_K符号距離': side*(price-st['k']) if actual else None,
                            '評価P_Iリスク': side*(price-st['i']) if actual else None})
    hours = sum((s['end']-300-s['start'])/3600 for s in source['scenes'])
    return {'成功': True, '試行': 145, 'arm形状未成立の個別要素': {f: masks(rows) for f, rows in shape.items()},
            'arm背景未成立の個別要素': masks(backgrounds), '保存pub同体結合coverage': dict(coverage),
            'Iとconfirm位置内訳': dict(counts), '全出生終端明細': details,
            '全技術confirm45を取得できた仮上限毎h': source['summary']['stage/技術確認']/hours,
            '説明': ['後のepisode内に再保存された同一pubからの復元は、ID/End/配送stamp全値を結合し、元の配送がarm_check以前と確認したものだけ。',
                     '保存Sourceに当該価格足がなければ接触/突破/終値要素はunknown。推定で0や不成立へ埋めない。',
                     '複合条件の個別要素は非排他的。不成立数を単一因果の寄与と呼ばない。',
                     '終端観測秒がTTLを越えても、次Rawで期限超過を記録しただけ。再待機や期限延長を意味しない。',
                     '技術confirm45仮上限は件数の上限診断であり、実現利益/先着率/間引き最適化ではない。']}


def main() -> None:
    """
    機能: Root許可済みSourceを指定SHAで読み小型追補を未作成先へ保存する。
    引数: CLIのsource/sha256/output(str)。返り値: None。
    """
    parser = argparse.ArgumentParser(); parser.add_argument('--source', required=True); parser.add_argument('--sha256', required=True); parser.add_argument('--output', required=True)
    args = parser.parse_args(); output = Path(args.output); assert not output.exists()
    source = Path(args.source); body = source.read_bytes(); assert hashlib.sha256(body).hexdigest() == args.sha256
    result = extract(json.loads(body)); assert hashlib.sha256(source.read_bytes()).hexdigest() == args.sha256
    result['Source参照'] = {'path': str(source), 'sha256': args.sha256, 'bytes': len(body)}
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'success': True, 'sha256': hashlib.sha256(output.read_bytes()).hexdigest(), 'coverage': result['保存pub同体結合coverage']}, ensure_ascii=True))


if __name__ == '__main__':
    main()
