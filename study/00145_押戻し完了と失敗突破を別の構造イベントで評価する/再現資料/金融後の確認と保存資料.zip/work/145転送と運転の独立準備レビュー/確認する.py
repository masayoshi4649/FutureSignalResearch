"""145の橋渡し/運転部を自然結果なしで確認し、Root人工と独立境界人工を実行する。"""
from pathlib import Path
import ast
import copy
import hashlib
import importlib.util
import json
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[2]
OWN=Path(__file__).resolve().parent
FILES=[ROOT/'work/145構造イベントと旧対照を固定取得へ渡す.py',
       ROOT/'work/145転送の人工検査.py',ROOT/'work/145出生と金融を分離して実行する.py']


def sha(path: Path) -> str:
    """
    機能: 保存したファイルの指紋を求める。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def module(path: Path, name: str) -> object:
    """
    機能: 自然入力を読まない純bridge/人工だけを読み込む。
    引数: path(Path)、name(str)。返り値: objectは私有モジュール。
    """
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value)
    return value


# ----------------------------------------
def main() -> None:
    """
    機能: cap0/2種類の上限・1episode・異方向union・時計を人工検査する。
    引数: なし。自然Source/Raw/CSV/金融/追加2場は読まない。
    返り値: None。自己専有workへ確認JSONを新規保存する。
    """
    before={str(p):sha(p) for p in FILES}
    for p in FILES:ast.parse(p.read_text(encoding='utf-8'))
    done=subprocess.run([sys.executable,'-X','utf8',str(FILES[1])],cwd=ROOT,capture_output=True,text=True,encoding='utf-8')
    assert done.returncode==0,done.stdout+done.stderr
    bridge=module(FILES[0],'独立145の転送');art=module(FILES[1],'独立145の人工素材')
    common,controls,source=art.fixture();original=copy.deepcopy((common,controls,source))
    fixed,meta=bridge.build(common,controls,source)
    assert (common,controls,source)==original
    assert len(meta['entries'])==fixed['expected_entry_count']==4 and len(meta['union'])==3
    assert 't8_side' not in meta['entries'][0]
    for entry in meta['entries']:
        case=next(e for s in fixed['scenes'] for e in s['entries'] if e['id']==entry['id'])
        assert case['side']==entry['native_side'] and case['entry']==entry['entry_quote']
    # ----------------------------------------
    # W=125/cap0は買売とも実P=Last=Kの点を許容する。
    for scene in source['scenes']:
        e=copy.deepcopy(scene['events'][0]);side=e['side'];k=e['structure']['k']
        e['structure']={'k':k,'i':k-side*125,'width':125,'cap':0,'arm_atr':20}
        e['birth']['last']=k;e['entryQuote']['last']=k;e['entry_price']=k
        e['entryQuote']['bid'],e['entryQuote']['ask']=(k,k+5) if side<0 else (k-5,k)
        bridge.validate_event(e,50000)
        bad=copy.deepcopy(e)
        field='bid' if side<0 else 'ask';bad['entryQuote'][field]+=side*.001;bad['entry_price']=bad['entryQuote'][field]
        try:bridge.validate_event(bad,50000)
        except AssertionError:pass
        else:raise AssertionError('cap0の実側超過を受理')
    # ----------------------------------------
    # ATR制約だけでなく、125-W側で切られる上限も売買鏡像で確認する。
    for scene in source['scenes']:
        e=copy.deepcopy(scene['events'][0]);side=e['side'];k=e['structure']['k']
        e['structure']={'k':k,'i':k-side*100,'width':100,'cap':25,'arm_atr':60}
        price=k+side*25;e['birth']['last']=price;e['entryQuote']['last']=price;e['entry_price']=price
        e['entryQuote']['bid'],e['entryQuote']['ask']=(price,price+5) if side<0 else (price-5,price)
        bridge.validate_event(e,50000)
        assert side*(price-e['structure']['i'])==125
    # ----------------------------------------
    # 先に存在するC0の将来取得で新Aの前の取得を落とさない。
    early=copy.deepcopy(source);e=early['scenes'][0]['events'][0]
    e['birth'].update({'time':69,'index':68,'source_line':69})
    e['expires']=99
    e['entryQuote'].update({'time':70,'index':70,'source_line':71})
    ef,em=bridge.build(common,controls,early)
    assert ef['expected_entry_count']==4 and len(em['union'])==4
    assert ef['scenes'][0]['entries'][0]['id'].startswith('A0/')
    assert ef['scenes'][0]['entries'][1]['id'].startswith('C0/')
    # ----------------------------------------
    # A/Bが同原行で反対向きに取得していてもC0優先dedupで隠さず拒否する。
    collision=copy.deepcopy(source);scene=collision['scenes'][0];e=copy.deepcopy(scene['events'][0])
    e.update({'id':'反対向きB','family':'B0','side':1,'episode_id':'別のepisode','entry_price':105})
    e['structure']={'k':100,'i':50,'width':50,'cap':20,'arm_atr':20}
    scene['episodes'].append({'id':e['episode_id'],'expires':950});scene['events'].append(e)
    try:bridge.build(common,controls,collision)
    except AssertionError:pass
    else:raise AssertionError('C0同原行の反対向きA/Bを隠して受理')
    # ----------------------------------------
    # 価格時計が進んでも同物理行は不可。event期限をepisodeより後へ置くのも不可。
    line=copy.deepcopy(source);e=line['scenes'][0]['events'][0]
    e['entryQuote']['source_line']=e['birth']['source_line']
    try:bridge.build(common,controls,line)
    except AssertionError:pass
    else:raise AssertionError('同物理行取得を受理')
    exp=copy.deepcopy(source);exp['scenes'][0]['episodes'][0]['expires']=128
    try:bridge.build(common,controls,exp)
    except AssertionError:pass
    else:raise AssertionError('episode後のpending期限を受理')
    assert {str(p):sha(p) for p in FILES}==before
    proof={'成功':True,'試行':145,'重大未解決':[],'構文3源':True,'Root人工15群':True,'独立人工5群':True,
           '独立人工':['W125/cap0の買売等号と微小超過拒否','ATR制約と125-W制約/実risk125の買売',
                      'C0未来取得の前の新streamを残す','C0重複で隠さず反対方向A/B同原行を拒否',
                      '別採用順/物理行・episode期限とpending期限の整合'],
           '入力非改変/nativeとQuoteのkernel射影':True,
           '静的確認':['新取得13必須と構造k/i/width/cap/arm_atrの照合',
                      '出生/取得のLastと実Ask/Bidが同じ固定域、risk125以下',
                      '全eventに1episode1born・同familyとA/Bの原行重複を拒否',
                      '旧C0は既保存native方向/Quoteのまま、T8を新streamへ付加しない',
                      'unionは原行キーでC0→A0→B0、方向をキーにしない',
                      'F0→Source→固定入力/meta→F1→保存正逆→金融を段階分離',
                      '全73場/旧81同体・H60新規限界・既存出力上書き拒否'],
           'Root人工ログ':{'終了コード':done.returncode,'標準出力':done.stdout,'標準エラー':done.stderr},
           'Root3源前後SHA256':before,'自己コードSHA256':sha(Path(__file__)),
           'Root/Source/正式3MD変更':False,'自然Source金融RawCSV追加2場読取':False,'編集停止':True}
    p=OWN/'準備の確認.json';assert not p.exists();p.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'SHA256':sha(p)},ensure_ascii=False))


if __name__=='__main__':
    main()
