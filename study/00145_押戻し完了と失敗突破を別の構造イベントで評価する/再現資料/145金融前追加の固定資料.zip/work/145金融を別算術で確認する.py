"""145の政策集合と金融300比較を、作者算術をimportせず再計算する。"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import math

ROOT=Path(__file__).resolve().parent.parent
CALCULATOR=ROOT/'work/141金融集計を独立に確認する.py'
CALCULATOR_SHA='30bd4aef8c2809699cb013f930cfbce152f3986fe8d3d3cc6b49452104c2269e'


def sha(path: Path) -> str:
    """
    機能: 保存bytesの指紋を求める。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 全基礎取得/unionを再構成し、300主要統計と全73の参加/頻度を照合する。
    引数: CLI --folder(Path)は145実行先、--output(Path)は新規証跡。
    返り値: None。原板/Source/追加2場を読まず、自然算術の作者関数も使わない。
    """
    p=argparse.ArgumentParser(description='145をRoot別算術で確認')
    p.add_argument('--folder',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();own=args.folder
    paths={'f1':own/'F1金融前.json','fixed':own/'固定入力/固定取得入力.json',
           'meta':own/'固定入力/入口参照.json','pairs':own/'固定取得の正逆観測.json',
           'summary':own/'金融評価/集計.json','calculator':CALCULATOR,'code':Path(__file__).resolve()}
    hashes={k:sha(v) for k,v in paths.items()};assert hashes['calculator']==CALCULATOR_SHA
    s=importlib.util.spec_from_file_location('145の別算術',CALCULATOR);calc=importlib.util.module_from_spec(s);s.loader.exec_module(calc)
    f1,fixed,meta,pairs=[json.loads(paths[n].read_bytes()) for n in ('f1','fixed','meta','pairs')]
    assert f1['試行']==meta['trial']==145 and pairs['trial']==133
    assert pairs['input_sha256']==meta['fixed_input_sha256']==hashes['fixed']
    assert all(f1['ファイル'][str(paths[n].resolve())]==hashes[n] for n in ('fixed','meta','calculator','code'))
    entries={e['id']:e for e in meta['entries']}
    cases={c['id']:(scene['session'],c) for scene in pairs['scenes'] for c in scene['cases']}
    assert len(entries)==len(meta['entries'])==len(cases)==fixed['expected_entry_count'] and set(entries)==set(cases)
    sessions=[scene['session'] for scene in fixed['scenes']]
    assert sessions==meta['sessions']==[s['session'] for s in pairs['scenes']] and len(sessions)==73
    members={m:{key for key,e in entries.items() if e['model']==m} for m in ('C0','A0','B0')}
    assert set.union(*members.values())==set(cases) and len(members['C0'])==81
    grouped={};new_stamps=set()
    for key,e in entries.items():
        sid,case=cases[key];q=e['entry_quote'];stamp=(sid,e['contract'],q['time'],q['index'],q['source_line'])
        assert e['native_side']==case['original_side'] and q==case['original']['entry']
        if e['model']!='C0':assert stamp not in new_stamps;new_stamps.add(stamp)
        grouped.setdefault(stamp,[]).append(key)
    canonical=set();seen_alias=set()
    for u in meta['union']:
        q=u['entry_stamp'];stamp=(u['session'],u['contract'],q['time'],q['index'],q['source_line'])
        ids=grouped.pop(stamp);want=min(ids,key=lambda key:({'C0':0,'A0':1,'B0':2}[entries[key]['model']],key))
        assert u['canonical_id']==want and set(u['alias_ids'])==set(ids)
        assert u['alias_sides']=={key:entries[key]['native_side'] for key in ids}
        assert not set(ids)&seen_alias;seen_alias.update(ids);canonical.add(want)
    assert not grouped and seen_alias==set(entries)
    members['U0']=canonical;expected={};participation={};frequency={}
    for part,subset in (('all',sessions),('train',sessions[:48]),('validation',sessions[48:])):
        hours=sum((s['end']-300-s['start'])/3600 for s in fixed['scenes'] if s['session'] in subset)
        participation[part]={};frequency[part]={};expected[part]={}
        for m,keys in members.items():
            selected=[cases[k] for k in keys if cases[k][0] in subset];present={sid for sid,_ in selected}
            participation[part][m]=(len(selected),len(present),len(present)==len(subset))
            frequency[part][m]=len(selected)/hours
        for policy in ('C0','A0','B0','U0','RU'):
            keys=members['U0' if policy=='RU' else policy]
            selected=[cases[k] for k in keys if cases[k][0] in subset]
            expected[part][policy]={}
            for axis in ('BBO','Last'):
                expected[part][policy][axis]={}
                for h in (1800,3600):
                    expected[part][policy][axis][str(h)]={str(w):calc.calculate(selected,policy=='RU',axis,h,w) for w in (25,50,100,125,200)}
    # ----------------------------------------
    # 期待値と集合が完成してから、作者の自然集計JSONを開きます。
    actual=json.loads(paths['summary'].read_bytes());assert actual['試行']==145
    assert actual['F1_SHA256']==hashes['f1'] and actual['自然結果SHA256']==hashes['pairs']
    comparisons=0;cells=0
    for part,policies in expected.items():
        for policy,axes in policies.items():
            for axis,horizons in axes.items():
                for h,widths in horizons.items():
                    for w,value in widths.items():
                        got=actual['集計'][part][policy][axis][h][w]
                        assert set(value)==set(got)
                        for name,wanted in value.items():
                            if isinstance(wanted,float):assert math.isclose(wanted,got[name],rel_tol=1e-12,abs_tol=1e-9),(part,policy,axis,h,w,name)
                            else:assert wanted==got[name],(part,policy,axis,h,w,name,wanted,got[name])
                            cells+=1
                        comparisons+=1
        for m,(count,present,all_present) in participation[part].items():
            got=actual['参加'][part][m]
            assert got['取得数']==count and got['取得場数']==present and got['全場最低1取得']==all_present
            assert math.isclose(actual['頻度'][part][m]['全時間平均件数毎時'],frequency[part][m],rel_tol=1e-12)
    assert comparisons==300 and all(sha(path)==hashes[k] for k,path in paths.items())
    report={'成功':True,'試行':145,'300比較':comparisons,'主要統計セル':cells,'基礎取得':len(cases),'union取得':len(canonical),
            '全73と参加頻度':True,'C0優先と新A/B同原行拒否':True,'作者124/138/145関数import':False,
            '計算方法':'Root141の別算術calculateを固定再利用。期待値を再構成後に作者summaryを開いた',
            '自然Raw/Source再走査':False,'入力':{str(path.resolve()):hashes[k] for k,path in paths.items()},
            '主U0':expected['all']['U0']['BBO']['3600']['125']}
    with args.output.open('x',encoding='utf-8',newline='\n') as f:
        json.dump(report,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps({'成功':True,'比較':comparisons,'統計セル':cells,'主U0':report['主U0']},ensure_ascii=False))


if __name__=='__main__':main()
