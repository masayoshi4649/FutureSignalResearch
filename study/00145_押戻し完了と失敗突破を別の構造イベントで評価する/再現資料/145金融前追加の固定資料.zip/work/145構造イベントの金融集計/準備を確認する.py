"""145の自然前金融adapterを人工・構文・CLI拒否と旧源不変で確認する。"""
from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 明示したコード/文書の指紋を求める。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 自然JSONを開かず、13人工と固定金融契約を確認して停止する。
    引数: なし。
    返り値: None。旧源/Source/金融/正式試行を変更しない。
    """
    files=[HERE/n for n in ('集計する.py','人工検査.py','条件.md','README.md')]
    old=[ROOT/f'work/{folder}/{name}' for folder in ('144旧strongの全成立集計','141独立入口とunionの集計') for name in ('集計する.py','人工検査.py')]
    before={p:sha(p) for p in files+old}
    run=subprocess.run([sys.executable,'-X','utf8',str(HERE/'人工検査.py')],capture_output=True,text=True,encoding='utf-8',check=True)
    artificial=json.loads(run.stdout);assert artificial['成功'] and artificial['人工群']==13 and artificial['三表列数']==[34,48,81]
    subprocess.run([sys.executable,'-m','py_compile',str(HERE/'集計する.py'),str(HERE/'人工検査.py')],capture_output=True,check=True)
    reject=subprocess.run([sys.executable,'-X','utf8',str(HERE/'集計する.py')],capture_output=True,text=True,encoding='utf-8')
    assert reject.returncode==2 and '--f1' in reject.stderr
    spec=importlib.util.spec_from_file_location('145準備契約',HERE/'集計する.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    assert m.POLICIES==('C0','A0','B0','U0','RU') and m.MODELS==('C0','A0','B0','U0')
    assert m.MODEL=={'C0':'C0','A0':'A0','B0':'B0','U0':'U0','RU':'U0'}
    assert [len(m.COMPARISON_HEADERS),len(m.DETAIL_HEADERS),len(m.SCENE_HEADERS)]==[34,48,81]
    assert all(sha(p)==h for p,h in before.items())
    for p,h in m.SOURCES.items():
        if p.suffix=='.py':assert sha(p)==h
    specification=sha(m.SPECIFICATION)
    assert specification=='38d1cc08e15438af669d318a9abd43814c590c48eadc1c8bb7ea0c255158f6b3'
    proof={'成功':True,'試行':145,'段階':'自然金融/Raw/追加2場未読の金融adapter準備・編集停止','人工':artificial,
        'compile':True,'CLI無指定を終了2で拒否':True,'政策順':list(m.POLICIES),'集合':list(m.MODELS),'政策集合対応':m.MODEL,
        '三表列数':[34,48,81],'表行数':'300/基礎81+N_A+N_B/73','union優先':'C0→A0→B0','alias_sides':'object {ID:int ±1}',
        'A/B同原行取得':'同方向/反対方向とも契約違反として拒否し後から相殺しない','RU':'C0代表を含む全U0の保存実逆',
        'Root_F1必須源':{str(p):h for p,h in m.SOURCES.items()},'Root_F1必須ローカル源':{str(p):before[p] for p in files[:3]},
        '採用仕様':{'path':str(m.SPECIFICATION),'sha256':specification},'旧144/141源前後不変':{str(p):before[p] for p in old},
        '旧C0対照':'旧138C0だけ全81/4stream/60条件。旧P0は新A/Bへ流用しない',
        '自然JSON/Raw/価格CSV/金融/追加2場読取':False,'旧試行変更':False,'F0/F1自然実行':False,'重大不足':[],
        'コードSHA256':sha(Path(__file__))}
    p=HERE/'準備の確認.json';p.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'準備SHA256':sha(p),'集計SHA256':before[files[0]],'人工SHA256':before[files[1]],'条件SHA256':before[files[2]],'人工群':13},ensure_ascii=False))


if __name__=='__main__':main()
