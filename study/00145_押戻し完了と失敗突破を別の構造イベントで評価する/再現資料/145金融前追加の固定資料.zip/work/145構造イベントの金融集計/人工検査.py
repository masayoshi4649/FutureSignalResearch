"""145集計器を価格ファイルなしの73場人工fixtureだけで検査する。"""
from pathlib import Path
import copy
import importlib.util
import json

HERE=Path(__file__).resolve().parent
S=importlib.util.spec_from_file_location('145人工対象',HERE/'集計する.py')
M=importlib.util.module_from_spec(S);S.loader.exec_module(M)


def fixture(new: bool=True) -> tuple:
    """
    機能: 原板を持たない73場・少数取得・異方向aliasの完全人工資料を作る。
    引数: new(bool)は新取得を含めるか。
    返り値: tuple[dict,dict,dict]は133形観測/固定入力/metadata。
    """
    fixed={'expected_entry_count':0,'scenes':[]};result={'success':True,'trial':133,'source_entry_count':0,'scenes':[]}
    meta={'success':True,'trial':145,'sessions':[],'entries':[],'union':[]}
    for i in range(73):
        sid=f'人工{i:02d}';start=1_000_000+i*100_000;meta['sessions'].append(sid)
        f={'session':sid,'contract':'人工限月','start':start,'end':start+7500,'force_close':start+7400,'raw':{'sha256':'a'*64},'expected_quality':{'人工':True},'entries':[]}
        r={'session':sid,'success':True,'actual_sha256':'a'*64,'quality':{'人工':True},'expected_quality':{'人工':True},
            'stat_before':{'bytes':0},'stat_after':{'bytes':0},'execution_end':start+7200,'effective_entry_limit':start+3600,'source_force_close':start+7400,'cases':[]}
        models=[('C0','旧1',1)] if i==0 else []
        if new and i==0:models.append(('A0','同原行の逆向き',-1))
        if new and i==1:models.append(('B0','別場の新1',1))
        for model,name,side in models:
            eid=model+'/'+name;q={'clock':'人工価格時計','time':start+100,'index':10,'source_line':100,'last':1000,'bid':995,'ask':1005,'quote_ok':True}
            f['entries'].append({'id':eid,'side':side,'entry':q});case={'id':eid,'original_side':side}
            for key in ('original','reverse','chart_original','chart_reverse'):
                chart=key.startswith('chart');s=side if key.endswith('original') else -side
                stream={'status':'filled','entry':q,'birth':{'side':s},'entry_price':q['last'] if chart else q['ask'] if s>0 else q['bid'],'outcomes':[]}
                for h in M.HORIZONS:
                    endpoint={**q,'time':q['time']+h,'index':100+h,'source_line':1000+h}
                    stream['outcomes'].append({'seconds':h,'deadline':q['time']+h,'status':'complete','endpoint':endpoint,
                        'touches':[{'width':w,'direction':0,'quote':None} for w in M.WIDTHS],'net0':None,'net5':None})
                case[key]=stream
            r['cases'].append(case);meta['entries'].append({'id':eid,'session':sid,'contract':f['contract'],'model':model,'candidate_id':name,
                'native_side':side,'entry_quote':q,'baseline':model=='C0','origins':[{'family':model}]})
        if models:
            meta['union'].append({'canonical_id':f['entries'][0]['id'],'alias_ids':[x['id'] for x in f['entries']],
                'alias_sides':{x['id']:x['side'] for x in f['entries']},'session':sid,'contract':f['contract'],'entry_stamp':{k:f['entries'][0]['entry'][k] for k in ('time','index','source_line')}})
        fixed['scenes'].append(f);result['scenes'].append(r)
    n=len(meta['entries']);fixed['expected_entry_count']=result['source_entry_count']=n
    return result,fixed,meta


# ----------------------------------------
def rejected(action: object) -> None:
    """
    機能: 不正fixtureのAssertionError拒否を確認する。
    引数: action(callable)。
    返り値: None。
    """
    try:action()
    except AssertionError:return
    raise AssertionError('不正fixtureを受け入れました')


# ----------------------------------------
def main() -> None:
    """
    機能: 145の4集合/5政策、A/B拒否、全実逆RUを人工だけで検査する。
    引数: なし。
    返り値: None。自然金融/Raw/価格CSV/追加2場を開かない。
    """
    arithmetic=M.load_arithmetic();tests=[]
    for include in (False,True):
        result,fixed,meta=fixture(include);basis,rows,sessions,phase,union=M.prepare(result,fixed,meta,False)
        values,part,freq,goal=M.calculate(rows,sessions,fixed['scenes'],arithmetic)
        tables=M.tables(basis,rows,sessions,values,part,freq,arithmetic)
        assert [(len(t['rows']),len(t['headers'])) for t in tables]==[(300,34),(len(basis),48),(73,81)]
        assert freq['all']['C0']['全時間h']==146 and part['all']['C0']['未取得場数']==72
        if not include:
            assert union['A0']==union['B0']==0 and union['C0']==union['U0']==1
            for model in ('A0','B0'):
                assert part['all'][model]['未取得場数']==73 and freq['all'][model]['全時間平均件数毎時']==0
                assert values['all'][model]['BBO']['3600']['125']['resolved_rate'] is None
                assert values['all'][model]['BBO']['3600']['125']['ifd_net5_sum'] is None
            assert values['all']['C0']['BBO']['3600']['125']==values['all']['U0']['BBO']['3600']['125']
            tests.append('A/B両方ゼロでも全73場/null/union=C0')
        else:
            assert union['C0']==union['A0']==union['B0']==1 and union['U0']==2
            assert union['同原行aliasで除いた取得数']==1 and union['代表と反対方向のalias数']==1
            detail={row[4]:dict(zip(tables[1]['headers'],row)) for row in tables[1]['rows']}
            assert detail['C0/旧1']['U0方向']==1 and detail['C0/旧1']['RU方向']==-1
            assert detail['A0/同原行の逆向き']['A0方向']==-1 and detail['A0/同原行の逆向き']['U0方向'] is None
            assert detail['B0/別場の新1']['B0方向']==detail['B0/別場の新1']['U0方向']==1
            assert detail['B0/別場の新1']['RU方向']==-1 and '保存T8方向' not in detail['B0/別場の新1']
            tests.append('C0反対aliasとstandalone保存/全union実逆RUはC0も反転')
        s=values['all']['C0']['BBO']['3600']['125'];assert s['ifd_known']==1 and s['ifd_net0_sum']==-1077 and s['ifd_net5_sum']==-2077
        assert values['all']['C0']['Last']['3600']['125']['ifd_net5_sum'] is None
    tests.append('元124費用77/1077円とLast金額null')
    # ----------------------------------------
    result,fixed,meta=fixture(True)
    bad=copy.deepcopy(meta);bad['union'][0]['canonical_id']='A0/同原行の逆向き'
    rejected(lambda:M.prepare(result,fixed,bad,False));tests.append('C0優先違反を拒否')
    bad=copy.deepcopy(meta);bad['union'][0]['alias_ids']=['C0/旧1']
    rejected(lambda:M.prepare(result,fixed,bad,False));tests.append('alias欠落を拒否')
    bad=copy.deepcopy(meta);bad['union'][0]['alias_sides']['A0/同原行の逆向き']=1
    rejected(lambda:M.prepare(result,fixed,bad,False));tests.append('alias_sidesの方向矛盾を拒否')
    bad=copy.deepcopy(meta);bad['union'][0]['alias_sides']['C0/旧1']=True
    rejected(lambda:M.prepare(result,fixed,bad,False));tests.append('alias側boolを整数1と誤認しない')
    # ----------------------------------------
    # 同方向でも反対方向でも、A/B同原行は取得後に相殺せず拒否します。
    for opposite in (False,True):
        rr,ff,mm=copy.deepcopy((result,fixed,meta));at=0 if opposite else 1
        c=copy.deepcopy(rr['scenes'][0]['cases'][at]);c['id']='B0/矛盾取得'
        e=copy.deepcopy(ff['scenes'][0]['entries'][at]);e['id']=c['id']
        m=copy.deepcopy(mm['entries'][at]);m.update({'id':c['id'],'model':'B0','candidate_id':'矛盾取得','baseline':False})
        rr['scenes'][0]['cases'].append(c);ff['scenes'][0]['entries'].append(e);mm['entries'].append(m)
        ff['expected_entry_count']+=1;rr['source_entry_count']+=1
        rejected(lambda:M.prepare(rr,ff,mm,False))
    tests.append('A/B同原行取得は同方向/反対方向とも拒否')
    rr,ff,mm=copy.deepcopy((result,fixed,meta));c=copy.deepcopy(rr['scenes'][0]['cases'][1]);c['id']='A0/重複'
    e=copy.deepcopy(ff['scenes'][0]['entries'][1]);e['id']=c['id'];m=copy.deepcopy(mm['entries'][1]);m['id']=c['id']
    rr['scenes'][0]['cases'].append(c);ff['scenes'][0]['entries'].append(e);mm['entries'].append(m);ff['expected_entry_count']+=1;rr['source_entry_count']+=1
    rejected(lambda:M.prepare(rr,ff,mm,False));tests.append('同じ基礎family内の同原行重複も拒否')
    rr=copy.deepcopy(result);rr['scenes'][0]['cases'][0]['original']['outcomes'][0]['endpoint']['time']=fixed['scenes'][0]['end']-300
    rejected(lambda:M.prepare(rr,fixed,meta,False));tests.append('ザラバ終端endpointを拒否')
    # ----------------------------------------
    rr,ff,mm=fixture(True);eid='B0/別場の新1'
    rr['scenes'][1]['cases']=[];ff['scenes'][1]['entries']=[];mm['entries']=[e for e in mm['entries'] if e['id']!=eid]
    mm['union']=[u for u in mm['union'] if u['canonical_id']!=eid];ff['expected_entry_count']-=1;rr['source_entry_count']-=1
    b,r,s,p,u=M.prepare(rr,ff,mm,False);v,part,f,g=M.calculate(r,s,ff['scenes'],arithmetic)
    assert u['B0']==0 and part['all']['B0']['未取得場数']==73 and v['all']['B0']['BBO']['3600']['125']['ifd_net5_sum'] is None
    tests.append('片familyだけ0でも全場分母とnullを保持')
    q={'time':1,'index':1,'source_line':1,'last':1050,'bid':900,'ask':1200,'quote_ok':True}
    out={'status':'complete','endpoint':{'time':2,'last':1050,'bid':1000,'ask':1100},'touches':[{'width':125,'direction':-1,'quote':{'time':2,'last':1050,'bid':1000,'ask':1100}}]}
    buy={'birth':{'side':1},'entry_price':1200};sell={'birth':{'side':-1},'entry_price':900}
    assert arithmetic.ifd(buy,out,125,'BBO')['net5']==arithmetic.ifd(sell,out,125,'BBO')['net5']==-21077
    unknown={**out,'status':'gap_censored','endpoint':None,'touches':[{'width':125,'direction':0,'quote':None}]}
    assert not arithmetic.ifd(buy,unknown,125,'BBO')['known'] and arithmetic.ifd(buy,{**unknown,'touches':out['touches']},125,'BBO')['known']
    tests.append('両側損失を許す実BBO/不足でも既知touchは金額既知')
    # ----------------------------------------
    control=[];pairs={'scenes':[]}
    for i in range(81):
        c=copy.deepcopy(result['scenes'][0]['cases'][0]);sid=f'旧対照人工{i}';c['id']=f'C0/人工{i}'
        control.append({'model':'C0','session':sid,'case':c});pairs['scenes'].append({'session':sid,'cases':[copy.deepcopy(c)]})
    oldvalues={part:{'C0':{axis:{str(h):{str(w):{'flips':0,'人工同体':81} for w in M.WIDTHS} for h in M.HORIZONS} for axis in M.AXES}} for part in ('all','train','validation')}
    baseline=M.baseline_check(control,oldvalues,{'集計':copy.deepcopy(oldvalues)},pairs)
    assert baseline['旧138C0全81']==81 and baseline['旧60条件同体']==60
    bad=copy.deepcopy(pairs);bad['scenes'][0]['cases'][0]['reverse']['entry_price']+=5
    rejected(lambda:M.baseline_check(control,oldvalues,{'集計':copy.deepcopy(oldvalues)},bad))
    tests.append('旧C0全81/4stream/60条件と逆側価格差の拒否')
    print(json.dumps({'成功':True,'人工群':len(tests),'人工':tests,'自然入力読取':False,'三表列数':[34,48,81]},ensure_ascii=False))


if __name__=='__main__':main()
