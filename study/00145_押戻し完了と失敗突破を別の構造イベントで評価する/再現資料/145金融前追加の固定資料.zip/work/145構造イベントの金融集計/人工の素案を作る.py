"""旧144の架空fixtureを145のA/B/alias方向票へ適応する。"""
from pathlib import Path


def main() -> None:
    """
    機能: 145人工の架空73場fixtureだけを用意する。
    引数: なし。
    返り値: None。旧源/自然入力は変更・読取しない。
    """
    here=Path(__file__).resolve().parent;source=here.parent/'144旧strongの全成立集計/人工検査.py';before=source.read_bytes()
    text=before.decode().replace('\r\n','\n');text=text[:text.index('\ndef rejected')]
    text=text.replace('144','145').replace('S0','A0').replace('s0','new')
    text=text.replace("models.append(('A0','別場の新1',1))","models.append(('B0','別場の新1',1))")
    text=text.replace("'t8_side':-side if model=='A0' else side,",'')
    text=text.replace("'session':sid,'contract':f['contract'],'entry_stamp'","'alias_sides':{x['id']:x['side'] for x in f['entries']},'session':sid,'contract':f['contract'],'entry_stamp'")
    assert 't8_side' not in text
    target=here/'人工検査.py';assert not target.exists();target.write_text(text,encoding='utf-8');assert source.read_bytes()==before


if __name__=='__main__':main()
