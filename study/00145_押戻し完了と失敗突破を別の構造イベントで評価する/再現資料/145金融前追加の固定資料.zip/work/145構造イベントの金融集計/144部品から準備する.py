"""凍結144の可変件数集計を別145部品へ適応する。旧源は変更しない。"""
from pathlib import Path
import hashlib

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def main() -> None:
    """
    機能: 新A/B native・C0保護union・全実逆RUの金融部品を作る。
    引数: なし。
    返り値: None。自然JSON/Raw/金融結果を開かず旧源も変更しない。
    """
    source=ROOT/'work/144旧strongの全成立集計/集計する.py';before=source.read_bytes()
    body=before.decode('utf-8').replace('\r\n','\n').replace('144','145')
    body=body.replace('旧strong全成立・固定T8・旧81・union','構造A/Bイベント・旧81・union全実逆')
    body=body.replace("SPECIFICATION=ROOT/'work/145_旧P3strongを全成立へ広げる採用仕様.md'","SPECIFICATION=ROOT/'work/145_構造イベント入口の採用仕様.md'")
    body=body.replace("POLICIES=('C0','S0','T0','U0','N0')","POLICIES=('C0','A0','B0','U0','RU')")
    body=body.replace("MODELS=('C0','S0','U0')","MODELS=('C0','A0','B0','U0')")
    body=body.replace("MODEL={'C0':'C0','S0':'S0','U0':'U0','T0':'S0','N0':'U0'}","MODEL={'C0':'C0','A0':'A0','B0':'B0','U0':'U0','RU':'U0'}")
    body=body.replace("'native方向','保存T8方向','固定対照由来'","'native方向','固定対照由来'")
    body=body.replace("c['original_side'],m['t8_side'],m['baseline']","c['original_side'],m['baseline']")
    body=body.replace('(len(basis),49)','(len(basis),48)').replace('(len(sessions),77)','(len(sessions),81)').replace('34/49/77','34/48/81')
    old="""    native=record['case']['original_side'];meta=record['meta']
    side=meta['t8_side'] if policy=='T0' or policy=='U0' and not meta['baseline'] else native
    assert type(side) is int and side in (-1,1)
    return record['case'][('chart_' if axis=='Last' else '')+('original' if side==native else 'reverse')]"""
    new="""    # RUはC0代表も含むunion全件を実逆にし、主のC0保護と分けます。
    return record['case'][('chart_' if axis=='Last' else '')+('reverse' if policy=='RU' else 'original')]"""
    assert old in body;body=body.replace(old,new,1)
    body=body.replace('保存native/T8とC0保護から対応する実BBO/Last側を選ぶ。','各native又はunion全実逆RUの保存BBO/Last側を選ぶ。')
    body=body.replace("assert m['model'] in ('C0','S0')","assert m['model'] in ('C0','A0','B0')")
    old="""            assert type(m['t8_side']) is int and m['t8_side'] in (-1,1)
            if m['baseline']:assert m['t8_side']==m['native_side'],'C0は保存方向を保護'"""
    assert old in body;body=body.replace(old,"            assert type(m['native_side']) is int and m['native_side'] in (-1,1)",1)
    line="        assert len({r['model'] for r in group})==len(group),'同一基礎集合内の原行重複'"
    assert line in body;body=body.replace(line,line+"\n        assert sum(r['model'] in ('A0','B0') for r in group)<=1,'A/B同原行取得はSource/bridge契約違反'",1)
    old="wanted=next((r for r in group if r['model']=='C0'),group[0]);assert chosen is wanted,'unionはC0を優先'"
    new="wanted=min(group,key=lambda r:{'C0':0,'A0':1,'B0':2}[r['model']]);assert chosen is wanted,'unionはC0/A0/B0順を優先'"
    assert old in body;body=body.replace(old,new,1)
    line="        assert len(u['alias_ids'])==len(set(u['alias_ids'])) and set(u['alias_ids'])==set(ids)"
    assert line in body;body=body.replace(line,line+"\n        assert type(u['alias_sides']) is dict and u['alias_sides']=={r['case']['id']:r['meta']['native_side'] for r in group}\n        assert all(type(v) is int and v in (-1,1) for v in u['alias_sides'].values())",1)
    body=body.replace("'S0':sum(r['model']=='S0' for r in basis),","'A0':sum(r['model']=='A0' for r in basis),'B0':sum(r['model']=='B0' for r in basis),")
    body=body.replace('S0が0件でも全73場を残す。','A0/B0が0件でも全73場を残す。')
    assert all(word not in body for word in ('t8_side','T0','N0','S0','144'))
    target=HERE/'集計する.py';assert not target.exists();target.write_text(body,encoding='utf-8');assert source.read_bytes()==before
    print('145集計作成。旧144源SHA256='+hashlib.sha256(before).hexdigest())


if __name__=='__main__':main()
