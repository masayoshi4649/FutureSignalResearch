package structureevent145

import rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"

// History は当場の価格既知・実連続5分と、連続性の切断を保存します。
type History struct {
	Five     []rules.Publication
	Epoch    uint64
	LatestID string
}

// observe は配送済み5分を最大4本保持し、未知価格・欠足で窓を切ります。
//
// 引数: p(rules.Publication)。返り値: ありません。歴史へ現在freshは再要求しません。
func (h *History) observe(p rules.Publication) {
	f := p.Frame.Frame
	if f.Width != 300 {
		return
	}
	h.LatestID = f.ID
	if !f.PriceKnown {
		h.Five = nil
		h.Epoch++
		return
	}
	if len(h.Five) > 0 {
		o := h.Five[len(h.Five)-1].Frame.Frame
		if o.SessionID != f.SessionID || o.Contract != f.Contract || o.End != f.Start {
			h.Five = nil
			h.Epoch++
		}
	}
	h.Five = append(h.Five, p)
	if len(h.Five) > 4 {
		h.Five = append([]rules.Publication(nil), h.Five[len(h.Five)-4:]...)
	}
}

// previous は指定した最新足を除いた実連続歴史を値copyで返します。
//
// 引数: id(string)。返り値: []rules.Publication。不在ならnilです。
func (h *History) previous(id string) []rules.Publication {
	if len(h.Five) == 0 || h.Five[len(h.Five)-1].Frame.Frame.ID != id {
		return nil
	}
	return append([]rules.Publication(nil), h.Five[:len(h.Five)-1]...)
}
