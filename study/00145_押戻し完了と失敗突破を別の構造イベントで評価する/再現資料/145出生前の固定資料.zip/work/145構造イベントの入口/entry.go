package structureevent145

import (
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"math"
	"strings"
)

type Scene145 struct {
	Session          string              `json:"session"`
	Contract         string              `json:"contract"`
	Start            float64             `json:"start"`
	End              float64             `json:"end"`
	ForceClose       float64             `json:"force_close"`
	Raw              FileRef             `json:"raw"`
	ExpectedAccepted int64               `json:"expected_accepted"`
	ExpectedQuality  *Counts             `json:"expected_quality"`
	Publications     []rules.Publication `json:"publications"`
}
type Input145 struct {
	Trial  int        `json:"trial"`
	Scenes []Scene145 `json:"scenes"`
}
type Input133 = Input145
type Structure struct {
	K      float64 `json:"k"`
	I      float64 `json:"i"`
	Width  float64 `json:"width"`
	Cap    float64 `json:"cap"`
	ArmATR float64 `json:"arm_atr"`
}
type Assessment struct {
	Known       bool                   `json:"known"`
	Pass        bool                   `json:"pass"`
	Direction30 int                    `json:"direction30"`
	Fields      map[string]rules.Value `json:"fields"`
	Refs        []rules.Ref            `json:"refs"`
	Reasons     []string               `json:"reasons"`
}
type Evidence struct {
	At         Quote                  `json:"at"`
	Frame      rules.Publication      `json:"frame"`
	Previous   []rules.Publication    `json:"previous"`
	Background Assessment             `json:"background"`
	Fields     map[string]rules.Value `json:"fields"`
	Reasons    []string               `json:"reasons"`
}
type Trace struct {
	Stage      string                 `json:"stage"`
	Reason     string                 `json:"reason"`
	At         Quote                  `json:"at"`
	Background Assessment             `json:"background"`
	Evidence   *Evidence              `json:"evidence,omitempty"`
	Fields     map[string]rules.Value `json:"fields"`
}
type Episode struct {
	ID                string    `json:"id"`
	Family            string    `json:"family"`
	Side              int       `json:"side"`
	OriginalDirection int       `json:"original_direction"`
	ConsumedKey       string    `json:"consumed_key"`
	Arm               Evidence  `json:"arm"`
	Confirm           *Evidence `json:"confirm"`
	Structure         Structure `json:"structure"`
	Expires           float64   `json:"expires"`
	Status            string    `json:"status"`
	Reason            string    `json:"reason"`
	TerminationQuote  *Quote    `json:"terminationQuote"`
	EventID           string    `json:"event_id"`
	Trace             []Trace   `json:"trace"`
	HistoryEpoch      uint64    `json:"history_epoch"`
}
type Event struct {
	ID               string      `json:"id"`
	Family           string      `json:"family"`
	Side             int         `json:"side"`
	Status           string      `json:"status"`
	Birth            Quote       `json:"birth"`
	EntryQuote       *Quote      `json:"entryQuote"`
	EntryPrice       *float64    `json:"entry_price"`
	Expires          float64     `json:"expires"`
	EpisodeID        string      `json:"episode_id"`
	Structure        Structure   `json:"structure"`
	Arm              Evidence    `json:"arm"`
	Confirm          Evidence    `json:"confirm"`
	Refs             []rules.Ref `json:"refs"`
	Evaluation       *Quote      `json:"evaluation"`
	TerminationQuote *Quote      `json:"terminationQuote"`
	Trace            []Trace     `json:"trace"`
}
type Detector struct {
	Scene      Scene145
	Episodes   []*Episode
	Events     []*Event
	ArmChecks  []Trace
	Stats      map[string]uint64
	active     *Episode
	pending    *Event
	processed  map[string]bool
	consumed   map[string]bool
	filledRows map[string]bool
}

// New は口座保有と旧C0を参照しない当場の単一episode状態を作ります。
//
// 引数: scene(Scene145)。返り値: *Detector/errorは空状態又は不正metadataです。
func New(scene Scene145) (*Detector, error) {
	if scene.Session == "" || scene.Contract == "" || !finite(scene.Start, scene.End, scene.ForceClose) || scene.End-3900 <= scene.Start || scene.ForceClose <= scene.Start || scene.ForceClose > scene.End {
		return nil, fmt.Errorf("145場定義不正")
	}
	return &Detector{Scene: scene, Episodes: []*Episode{}, Events: []*Event{}, ArmChecks: []Trace{}, Stats: map[string]uint64{}, processed: map[string]bool{}, consumed: map[string]bool{}, filledRows: map[string]bool{}}, nil
}

// limit はH60の観測を残す新規取得共通限界を返します。
//
// 引数: なし。返り値: float64はmin(元force,End−3900)です。
func (d *Detector) limit() float64 { return math.Min(d.Scene.ForceClose, d.Scene.End-3900) }

// quote145 はBankの現在原行型へ同じ価格時計と原行を写します。
//
// 引数: q(Quote)。返り値: rules.Quoteです。
func quote145(q Quote) rules.Quote {
	return rules.Quote{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine), Last: q.Last}
}

// val は有限な既知値を作り、異常な派生値を未知のまま返します。
//
// 引数: x(float64)。返り値: rules.Valueです。
func val(x float64) rules.Value {
	if !finite(x) {
		return rules.Value{}
	}
	return rules.Value{Known: true, Value: x}
}

// delta は実際に与えた既知の両端の差だけを計算します。
//
// 引数: a/b(rules.Value)。返り値: rules.Valueです。
func delta(a, b rules.Value) rules.Value {
	if !a.Known || !b.Known {
		return rules.Value{}
	}
	return val(a.Value - b.Value)
}

// sign はゼロを方向なしとして有限な値の符号を返します。
//
// 引数: x(float64)。返り値: intは−1/0/1です。
func sign(x float64) int {
	if x > 0 {
		return 1
	}
	if x < 0 {
		return -1
	}
	return 0
}

// ref は歴史足の実配送とIDを省略せず参照へ写します。
//
// 引数: p(rules.Publication)。返り値: rules.Refです。
func ref(p rules.Publication) rules.Ref {
	f := p.Frame.Frame
	return rules.Ref{ID: f.ID, Width: f.Width, End: f.End, Delivered: p.Stamp}
}

// mergeRefs は使用した全参照を改変せずID重複だけを除いて返します。
//
// 引数: groups(...[]rules.Ref)。返り値: []rules.Refです。
func mergeRefs(groups ...[]rules.Ref) []rules.Ref {
	out := []rules.Ref{}
	seen := map[string]bool{}
	for _, g := range groups {
		for _, r := range g {
			if !seen[r.ID] {
				seen[r.ID] = true
				out = append(out, r)
			}
		}
	}
	return out
}

// background は現在freshな三尺度とA/Bの異なる背景条件を検査します。
//
// 引数: s(rules.Snapshot)、family(string)、side(int)、arm(bool)。返り値: Assessmentです。
func background(s rules.Snapshot, family string, side int, arm bool) Assessment {
	a := Assessment{Known: true, Fields: map[string]rules.Value{}, Refs: append([]rules.Ref(nil), s.Refs...), Reasons: []string{}}
	for _, w := range []int{300, 900, 1800} {
		p, ok := s.Frames[w]
		k := ok && p.Frame.Frame.PriceKnown
		a.Fields[fmt.Sprintf("price_known_%d", w)] = val(0)
		if k {
			a.Fields[fmt.Sprintf("price_known_%d", w)] = val(1)
		} else {
			a.Known = false
			a.Reasons = append(a.Reasons, fmt.Sprintf("現在%d価格未知又はfresh不足", w))
		}
	}
	p30, p15 := s.Frames[1800], s.Frames[900]
	t := p30.Frame.Frame.Technical
	di := p15.Frame.DMI
	a.Fields["gap30"], a.Fields["ema21_delta30"] = t.Gap, t.EMA21Delta
	a.Fields["plus_di15"], a.Fields["minus_di15"], a.Fields["adx15"], a.Fields["previous_adx15"] = di.PlusDI, di.MinusDI, di.ADX, di.PreviousADX
	a.Fields["di_difference15"], a.Fields["adx_delta15"] = delta(di.PlusDI, di.MinusDI), delta(di.ADX, di.PreviousADX)
	for _, k := range []string{"gap30", "ema21_delta30", "adx15", "previous_adx15", "adx_delta15"} {
		if !a.Fields[k].Known {
			a.Known = false
			a.Reasons = append(a.Reasons, k+"未知")
		}
	}
	if t.Gap.Known && t.EMA21Delta.Known && sign(t.Gap.Value) != 0 && sign(t.Gap.Value) == sign(t.EMA21Delta.Value) {
		a.Direction30 = sign(t.Gap.Value)
	}
	adx := a.Fields["adx_delta15"]
	if family == "A0" {
		v := a.Fields["di_difference15"]
		if !v.Known {
			a.Known = false
			a.Reasons = append(a.Reasons, "15分DI差未知")
		}
		a.Pass = a.Known && side != 0 && a.Direction30 == side && v.Value*float64(side) > 0 && adx.Value >= 0
	} else {
		a.Pass = a.Known && adx.Value < 0 && (!arm || (a.Direction30 != 0 && side == -a.Direction30))
	}
	if !a.Pass && len(a.Reasons) == 0 {
		a.Reasons = append(a.Reasons, "現在背景不成立")
	}
	return a
}

// evidence は当時背景・当足・実際の連続前足を独立sliceで凍結します。
//
// 引数: q(Quote)、p(rules.Publication)、previous([]rules.Publication)、a(Assessment)。返り値: Evidenceです。
func evidence(q Quote, p rules.Publication, previous []rules.Publication, a Assessment) Evidence {
	return Evidence{At: q, Frame: p, Previous: append([]rules.Publication(nil), previous...), Background: a, Fields: map[string]rules.Value{}, Reasons: []string{}}
}

// armEvidence は前足EMA又は前3本域へ束縛した新しい調整・拒否を検査します。
//
// 引数: family(string)、side(int)、e(*Evidence)。返り値: boolはarm候補です。
func armEvidence(family string, side int, e *Evidence) bool {
	f := e.Frame.Frame.Frame
	t := f.Technical
	s := float64(side)
	e.Fields["arm_atr"] = t.ATR
	e.Fields["signed_body"] = val(s * (f.OHLC.Close - f.OHLC.Open))
	if !t.ATR.Known || t.ATR.Value <= 0 {
		e.Reasons = append(e.Reasons, "armATR未知又は非正")
	}
	if family == "A0" {
		if len(e.Previous) < 1 {
			e.Reasons = append(e.Reasons, "実連続前足なし")
			return false
		}
		o := e.Previous[len(e.Previous)-1].Frame.Frame
		dh := delta(t.Histogram, o.Technical.Histogram)
		e.Fields["actual_hist_delta"] = dh
		e.Fields["previous_ema8"], e.Fields["previous_ema21"] = o.Technical.EMA8, o.Technical.EMA21
		if !dh.Known || !o.Technical.EMA8.Known || !o.Technical.EMA21.Known {
			e.Reasons = append(e.Reasons, "前足EMA又は実Hist差未知")
		} else {
			low, high := math.Min(o.Technical.EMA8.Value, o.Technical.EMA21.Value), math.Max(o.Technical.EMA8.Value, o.Technical.EMA21.Value)
			e.Fields["previous_ema_low"], e.Fields["previous_ema_high"] = val(low), val(high)
			if s*(f.OHLC.Close-f.OHLC.Open) >= 0 || s*dh.Value >= 0 || f.OHLC.High < low || f.OHLC.Low > high {
				e.Reasons = append(e.Reasons, "逆実体・Hist悪化・前EMA帯接触が未成立")
			}
		}
	} else {
		if len(e.Previous) < 3 {
			e.Reasons = append(e.Reasons, "実連続前3本なし")
			return false
		}
		previous := e.Previous[len(e.Previous)-3:]
		low, high := math.Inf(1), math.Inf(-1)
		for _, p := range previous {
			low = math.Min(low, p.Frame.Frame.OHLC.Low)
			high = math.Max(high, p.Frame.Frame.OHLC.High)
		}
		e.Fields["range_low"], e.Fields["range_high"] = val(low), val(high)
		up, down := f.OHLC.High > high, f.OHLC.Low < low
		if high <= low {
			e.Reasons = append(e.Reasons, "前3本域幅非正")
		}
		if up && down {
			e.Reasons = append(e.Reasons, "両端突破で曖昧")
		}
		if (side < 0 && !up) || (side > 0 && !down) || f.OHLC.Close < low || f.OHLC.Close > high || s*(f.OHLC.Close-f.OHLC.Open) <= 0 {
			e.Reasons = append(e.Reasons, "元方向突破・域内終値・反対実体が未成立")
		}
	}
	return len(e.Reasons) == 0
}

// confirmEvidence は同じ確認足の価格・実Hist差・量・TRを束縛します。
//
// 引数: side(int)、structure(Structure)、e(*Evidence)。返り値: boolは技術確認成立です。
func confirmEvidence(side int, structure Structure, e *Evidence) bool {
	f := e.Frame.Frame.Frame
	t := f.Technical
	s := float64(side)
	e.Fields["signed_close_from_k"] = val(s * (f.OHLC.Close - structure.K))
	if len(e.Previous) < 1 {
		e.Reasons = append(e.Reasons, "確認の実連続前足なし")
		return false
	}
	u := e.Previous[len(e.Previous)-1].Frame.Frame
	dh := delta(t.Histogram, u.Technical.Histogram)
	e.Fields["histogram"], e.Fields["actual_hist_delta"] = t.Histogram, dh
	e.Fields["volume"], e.Fields["actual_previous_volume"] = rules.Value{Known: f.VolumeKnown, Value: f.Volume}, rules.Value{Known: u.VolumeKnown, Value: u.Volume}
	e.Fields["tr"], e.Fields["previous_atr"] = t.TR, t.PreviousATR
	if s*(f.OHLC.Close-structure.K) < 0 {
		e.Reasons = append(e.Reasons, "終値K未回復")
	}
	if !t.Histogram.Known || !dh.Known || s*t.Histogram.Value <= 0 || s*dh.Value <= 0 {
		e.Reasons = append(e.Reasons, "確認足Hist側符号又は実改善不足")
	}
	if !f.VolumeKnown || !u.VolumeKnown || f.Volume <= 0 || u.Volume <= 0 || f.Volume < u.Volume {
		e.Reasons = append(e.Reasons, "同足量・実前足量の比較不成立")
	}
	if !t.TR.Known || !t.PreviousATR.Known || t.TR.Value < 0 || t.PreviousATR.Value <= 0 || t.TR.Value > 2*t.PreviousATR.Value {
		e.Reasons = append(e.Reasons, "TR対実定義PreviousATRの急変ガード不成立")
	}
	return len(e.Reasons) == 0
}

// allowed はKから有利側へcap以内という固定取得域を検査します。
//
// 引数: side(int)、p(float64)、structure(Structure)。返り値: boolです。
func allowed(side int, p float64, structure Structure) bool {
	v := float64(side) * (p - structure.K)
	return finite(p, v) && v >= 0 && v <= structure.Cap
}

// end はepisodeと未取得eventの終端・現在背景を保存して占有を解放します。
//
// 引数: status/reason(string)、q(Quote)、a(Assessment)。返り値: ありません。
func (d *Detector) end(status, reason string, q Quote, a Assessment) {
	e := d.active
	if e == nil {
		return
	}
	z := q
	e.Status = status
	e.Reason = reason
	e.TerminationQuote = &z
	e.Trace = append(e.Trace, Trace{Stage: "終了", Reason: reason, At: q, Background: a, Fields: map[string]rules.Value{}})
	if d.pending != nil {
		d.pending.Status = status
		d.pending.TerminationQuote = &z
		d.pending.Trace = append(d.pending.Trace, Trace{Stage: "終了", Reason: reason, At: q, Background: a, Fields: map[string]rules.Value{}})
		d.pending.Refs = mergeRefs(d.pending.Refs, a.Refs)
	}
	d.Stats["終了/"+status]++
	d.active = nil
	d.pending = nil
}

// processPending は現在背景とLast域を監視し、別原行1秒後の最初正常実側だけで取得します。
//
// 引数: q(Quote)、a(Assessment)。返り値: errorは同原行取得重複です。
func (d *Detector) processPending(q Quote, a Assessment) error {
	e := d.pending
	s := float64(e.Side)
	if q.Time >= e.Expires {
		d.end("unfilled_expired", "pending期限等号又は超過", q, a)
		return nil
	}
	if !allowed(e.Side, q.Last, e.Structure) {
		d.end("last_position_rejected", "pending現在Lastが固定K/cap域外", q, a)
		return nil
	}
	if q.Index <= e.Birth.Index || q.SourceLine <= e.Birth.SourceLine || q.Time < e.Birth.Time+1 || !q.QuoteOK || !normal(q) {
		return nil
	}
	z := q
	e.Evaluation = &z
	p := q.Ask
	if e.Side < 0 {
		p = q.Bid
	}
	risk := s * (p - e.Structure.I)
	fields := map[string]rules.Value{"entry_price": val(p), "risk": val(risk)}
	e.Trace = append(e.Trace, Trace{Stage: "正常BBO評価", At: q, Background: a, Fields: fields})
	e.Refs = mergeRefs(e.Refs, a.Refs)
	if !allowed(e.Side, p, e.Structure) || risk <= 0 || risk > 125 {
		d.end("entry_position_rejected", "最初正常実側が固定域又は125ptリスク外", q, a)
		return nil
	}
	key := fmt.Sprintf("%g/%d/%d", q.Time, q.Index, q.SourceLine)
	if d.filledRows[key] {
		return fmt.Errorf("A/B同原行取得矛盾")
	}
	d.filledRows[key] = true
	e.EntryQuote = &z
	e.EntryPrice = &p
	e.Status = "filled"
	d.Stats["取得"]++
	d.Stats["取得/"+e.Family]++
	d.end("filled", "最初正常実側で取得", q, a)
	return nil
}

// Observe は同Raw全公表後の一つの現在SnapshotでA/Bを逐次判別します。
//
// 引数: bank(*rules.Bank)、history(*History)、q(Quote)。返り値: errorは入力又は同時成立の矛盾です。
func (d *Detector) Observe(bank *rules.Bank, history *History, q Quote) error {
	d.Stats["採用Raw"]++
	snapshot, err := bank.Current(quote145(q))
	if err != nil {
		return err
	}
	newFive := history.LatestID != "" && !d.processed[history.LatestID]
	if history.LatestID != "" {
		d.processed[history.LatestID] = true
	}
	p, present := snapshot.Frames[300]
	current := present && p.Frame.Frame.PriceKnown && p.Frame.Frame.ID == history.LatestID
	if newFive {
		d.Stats["新5分処理"]++
	}
	if d.active != nil {
		e := d.active
		a := background(snapshot, e.Family, e.Side, false)
		if q.Time >= d.limit() {
			d.end("force_close", "共通新規限界", q, a)
			return nil
		}
		if q.Time >= e.Expires {
			d.end("episode_expired", "episode期限等号又は超過", q, a)
			return nil
		}
		if e.HistoryEpoch != history.Epoch {
			d.end("structure_disconnected", "当場5分の連続性切断", q, a)
			return nil
		}
		if !current || !a.Pass {
			d.end("background_lost", "現在fresh5又は背景未知/不成立", q, a)
			return nil
		}
		if float64(e.Side)*(q.Last-e.Structure.I) <= 0 {
			d.end("invalidation_reached", "現在Lastが固定I到達又は越境", q, a)
			return nil
		}
		if d.pending != nil {
			return d.processPending(q, a)
		}
		if !newFive {
			return nil
		}
		if p.Frame.Frame.Start < e.Arm.Frame.Frame.Frame.End {
			return fmt.Errorf("後続確認足の市場時計矛盾")
		}
		c := evidence(q, p, history.previous(p.Frame.Frame.ID), a)
		if !confirmEvidence(e.Side, e.Structure, &c) {
			e.Trace = append(e.Trace, Trace{Stage: "確認待機", Reason: "後続新5分の確認未成立", At: q, Background: a, Evidence: &c, Fields: map[string]rules.Value{}})
			d.Stats["確認未成立"]++
			return nil
		}
		e.Confirm = &c
		d.Stats["技術確認"]++
		if !allowed(e.Side, q.Last, e.Structure) {
			d.end("confirm_position_rejected", "技術確認時の現在Lastが固定K/cap域外", q, a)
			return nil
		}
		refs := mergeRefs(e.Arm.Background.Refs, a.Refs, []rules.Ref{ref(e.Arm.Frame), ref(p)})
		for _, v := range append(append([]rules.Publication(nil), e.Arm.Previous...), c.Previous...) {
			refs = mergeRefs(refs, []rules.Ref{ref(v)})
		}
		born := &Event{ID: fmt.Sprintf("%s/born/%d", e.ID, q.Index), Family: e.Family, Side: e.Side, Status: "pending", Birth: q, Expires: math.Min(q.Time+30, math.Min(e.Expires, d.limit())), EpisodeID: e.ID, Structure: e.Structure, Arm: e.Arm, Confirm: c, Refs: refs, Trace: []Trace{}}
		e.Status = "pending"
		e.EventID = born.ID
		e.Trace = append(e.Trace, Trace{Stage: "出生", At: q, Background: a, Evidence: &c, Fields: map[string]rules.Value{}})
		d.pending = born
		d.Events = append(d.Events, born)
		d.Stats["出生"]++
		d.Stats["出生/"+e.Family]++
		return nil
	}
	if q.Time >= d.limit() {
		d.Stats["新規限界以後"]++
		return nil
	}
	if !newFive || !current {
		if newFive {
			d.Stats["arm最新5価格未知又はfresh不足"]++
		}
		return nil
	}
	dir := background(snapshot, "B0", 0, false).Direction30
	a, b := background(snapshot, "A0", dir, true), background(snapshot, "B0", -dir, true)
	if a.Pass && b.Pass {
		return fmt.Errorf("A/B同時arm背景矛盾")
	}
	family, side, assessment := "", 0, a
	if a.Pass {
		family, side, assessment = "A0", dir, a
	} else if b.Pass {
		family, side, assessment = "B0", -dir, b
	} else {
		d.Stats["arm背景不成立"]++
		d.ArmChecks = append(d.ArmChecks, Trace{Stage: "arm背景不成立", Reason: "A/Bとも現在背景不成立", At: q, Background: a, Fields: map[string]rules.Value{"A背景成立": val(0), "B背景成立": val(0)}})
		return nil
	}
	arm := evidence(q, p, history.previous(p.Frame.Frame.ID), assessment)
	if !armEvidence(family, side, &arm) {
		d.Stats["arm形状未成立/"+family]++
		for _, reason := range arm.Reasons {
			d.Stats["arm不成立理由/"+reason]++
		}
		d.ArmChecks = append(d.ArmChecks, Trace{Stage: "arm形状不成立/" + family, Reason: strings.Join(arm.Reasons, "、"), At: q, Background: assessment, Fields: arm.Fields})
		return nil
	}
	key := fmt.Sprintf("%s/%s/%d", family, p.Frame.Frame.ID, side)
	if d.consumed[key] {
		return fmt.Errorf("同armキー再利用矛盾")
	}
	d.consumed[key] = true
	f := p.Frame.Frame
	k, i := f.OHLC.High+10, f.OHLC.Low-10
	if side < 0 {
		k, i = f.OHLC.Low-10, f.OHLC.High+10
	}
	w := float64(side) * (k - i)
	atr := f.Technical.ATR.Value
	structure := Structure{K: k, I: i, Width: w, Cap: math.Min(atr, 125-w), ArmATR: atr}
	if !finite(k, i, w, structure.Cap, atr) || w <= 0 {
		return fmt.Errorf("固定構造の非有限又は非正幅")
	}
	e := &Episode{ID: fmt.Sprintf("%s/%s/episode/%d/%d", d.Scene.Session, family, side, q.Index), Family: family, Side: side, OriginalDirection: dir, ConsumedKey: key, Arm: arm, Structure: structure, Expires: math.Min(q.Time+900, d.limit()), Status: "armed", Trace: []Trace{}, HistoryEpoch: history.Epoch}
	d.active = e
	d.Episodes = append(d.Episodes, e)
	d.Stats["arm"]++
	d.Stats["arm/"+family]++
	if w > 125 {
		d.end("structure_width_rejected", "arm構造幅125超過", q, assessment)
		return nil
	}
	if float64(side)*(q.Last-i) <= 0 {
		d.end("invalidation_reached", "arm現在Lastが固定I到達又は越境", q, assessment)
	}
	return nil
}

// Finish はEOFで架空足・架空気配を作らず残るepisodeだけを閉じます。
//
// 引数: なし。返り値: ありません。消費した足を再利用しません。
func (d *Detector) Finish() {
	if d.active == nil {
		return
	}
	e := d.active
	e.Status = "eof_unfinished"
	e.Reason = "EOFで未完了"
	if d.pending != nil {
		d.pending.Status = "eof_unfilled"
		d.Stats["終了/eof_unfilled"]++
	} else {
		d.Stats["終了/eof_unfinished"]++
	}
	d.active = nil
	d.pending = nil
}
