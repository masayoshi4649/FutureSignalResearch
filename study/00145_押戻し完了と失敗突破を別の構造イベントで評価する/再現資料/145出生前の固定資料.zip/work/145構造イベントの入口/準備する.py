"""145の人工検査・由来・全依存指紋を自然実行前に保存する。"""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
SPEC = ROOT / 'work/145_構造イベント入口の採用仕様.md'
SPEC_SHA = '38d1cc08e15438af669d318a9abd43814c590c48eadc1c8bb7ea0c255158f6b3'


def sha(path: Path) -> str:
    """
    機能: 指定したコード・文書・実行ファイルのSHAを求める。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def record(path: Path) -> dict:
    """
    機能: 再現用の小型依存参照を保存する。
    引数: path(Path)。返り値: dictはpath/bytes/sha256。
    """
    return {'path': str(path.relative_to(ROOT)), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def run(arguments: list[str]) -> dict:
    """
    機能: 自然データを開かない人工検査又はビルドを実行する。
    引数: arguments(list[str])。返り値: dictは終了コードとUTF-8出力。
    """
    result = subprocess.run(arguments, cwd=HERE, capture_output=True, encoding='utf-8', errors='replace')
    assert result.returncode == 0, result.stdout + result.stderr
    return {'引数': arguments, '終了コード': result.returncode, '標準出力': result.stdout, '標準エラー': result.stderr}


def main() -> None:
    """
    機能: 旧源同体と最終人工10主群・静的検査・buildを証跡化する。
    引数: なし。返り値: None。自然Sourceと金融のCLIは呼ばない。
    """
    assert sha(SPEC) == SPEC_SHA
    old = ROOT / 'work/144旧P3strongの全成立'
    old_proof = old / '準備の確認.json'
    assert sha(old_proof) == 'c62787fc75ca9cf316576d30c9312ad3ac90fd0e6dd97b82d6c9b1c28cbef3b2'
    old_frozen = json.loads(old_proof.read_text(encoding='utf-8'))['源']
    assert all(sha(Path(item['path'])) == item['sha256'] for item in old_frozen)
    provenance = json.loads((HERE / '由来.json').read_text(encoding='utf-8'))
    for item in provenance['同体再用']:
        original, target = ROOT / item['source'], ROOT / item['target']
        assert sha(original) == item['source_sha256'] and sha(target) == item['target_sha256']
        assert original.read_bytes().replace(b'package strongstream144', b'package structureevent145', 1) == target.read_bytes()
    local = sorted([*HERE.rglob('*.go'), HERE/'go.mod', HERE/'README.md', HERE/'由来.json', Path(__file__).resolve()])
    deps = [ROOT/'work/118複数技法の入口条件'/name for name in ('bank.go', 'rules.go', 'types.go', 'go.mod')]
    sources = sorted(set(local + deps + [SPEC]))
    before = {str(path): sha(path) for path in sources}
    checks = [run(['go', 'version']), run(['go', 'test', '-count=1', '-v', './...']),
              run(['go', 'vet', './...']), run(['go', 'build', '-o', '構造イベント生成.exe', './cmd/run'])]
    assert before == {str(path): sha(path) for path in sources}
    assert all(sha(Path(item['path'])) == item['sha256'] for item in old_frozen)
    proof = {'成功': True, '試行': 145, '編集停止': True, '人工主群数': 10, '確認': checks,
             '源': [record(path) for path in sources], '実行ファイル': record(HERE/'構造イベント生成.exe'),
             '旧144固定全20源同体': len(old_frozen) == 20,
             '旧4源package行以外同体': True,
             '固定入力SHA256': '6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec',
             '採用仕様SHA256': SPEC_SHA,
             '自然Source生成': False, '自然RawCSV読取': False, '自然金融読取': False,
             '追加2場読取': False, '旧源変更': False,
             '範囲': '新A/Bの状態・歴史・Source。固定C0とのunionと金融はRoot橋渡し/固定133kernelで別処理。',
             '参照の時点': 'Event.refsは取得/取消までの現在背景も含む。出生確定票はarm/confirm各Evidence。',
             '未証明': ['自然出生・取得件数', '全73場参加', '概ね1件時', '同幅先着70%', '実約定・利益・必須追尾']}
    out = HERE/'準備の確認.json'
    out.write_text(json.dumps(proof, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'success': True, 'proof_sha256': sha(out), 'executable_sha256': sha(HERE/'構造イベント生成.exe'), 'sources': len(sources)}, ensure_ascii=True))


if __name__ == '__main__':
    main()
