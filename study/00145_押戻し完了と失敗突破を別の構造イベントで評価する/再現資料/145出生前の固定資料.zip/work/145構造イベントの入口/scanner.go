package structureevent145

import (
	"bufio"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"io"
	"os"
	"reflect"
	"strings"
	"sync"
)

const InputSHA = "6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec"

type SceneResult struct {
	Success          bool              `json:"success"`
	Session          string            `json:"session"`
	Contract         string            `json:"contract"`
	Start            float64           `json:"start"`
	End              float64           `json:"end"`
	ForceClose       float64           `json:"force_close"`
	EntryLimit       float64           `json:"entry_limit"`
	ExecutionEnd     float64           `json:"execution_end"`
	Raw              FileRef           `json:"raw"`
	ActualSHA        string            `json:"actual_sha256"`
	StatBefore       FileStat          `json:"stat_before"`
	StatAfter        FileStat          `json:"stat_after"`
	Counts           Counts            `json:"counts"`
	Quality          Counts            `json:"quality"`
	ExpectedAccepted int64             `json:"expected_accepted"`
	ExpectedQuality  *Counts           `json:"expected_quality"`
	RawPasses        int               `json:"raw_passes"`
	RawEncoding      string            `json:"raw_encoding"`
	Episodes         []*Episode        `json:"episodes"`
	Events           []*Event          `json:"events"`
	ArmChecks        []Trace           `json:"arm_checks"`
	Stats            map[string]uint64 `json:"stats"`
}
type Result struct {
	Success             bool              `json:"success"`
	Trial               int               `json:"trial"`
	InputSHA            string            `json:"input_sha256"`
	Scenes              []SceneResult     `json:"scenes"`
	Summary             map[string]uint64 `json:"summary"`
	FinancialLabelsUsed bool              `json:"financial_labels_used"`
	SourcePositionsUsed bool              `json:"source_positions_used"`
}

// Load は固定122のSHA/trial/73場を走査前に確認します。
//
// 引数: path/expected(string)。返り値: Input145/error。success旗やRaw.Bytesを新たに要求しません。
func Load(path, expected string) (Input145, error) {
	var input Input145
	if expected != InputSHA {
		return input, fmt.Errorf("固定122 SHA指定差")
	}
	b, e := os.ReadFile(path)
	if e != nil {
		return input, e
	}
	v := sha256.Sum256(b)
	if hex.EncodeToString(v[:]) != expected {
		return input, fmt.Errorf("入力SHA差")
	}
	if e = json.Unmarshal(b, &input); e != nil {
		return input, e
	}
	if input.Trial != 122 {
		return input, fmt.Errorf("入力trial122差")
	}
	if e = Validate(input, 1, true); e != nil {
		return input, e
	}
	return input, nil
}

// Validate は元validationに必須品質と固定73/12794を重ねます。
//
// 引数: input(Input145)、workers(int)、all73(bool)。返り値: error。falseは人工用です。
func Validate(input Input145, workers int, all73 bool) error {
	if workers < 1 || workers > 8 || len(input.Scenes) == 0 {
		return fmt.Errorf("並列/場数不正")
	}
	days, nights, pubs := 0, 0, 0
	if all73 {
		n, e := validateInput133(input, workers)
		if e != nil {
			return e
		}
		pubs = n
	}
	for i, s := range input.Scenes {
		if s.ExpectedQuality == nil || s.ExpectedAccepted <= 0 || s.Session == "" || s.Contract == "" || !validSHA133(s.Raw.SHA256) || s.Raw.Path == "" {
			return fmt.Errorf("必須品質metadata差")
		}
		if _, e := New(s); e != nil {
			return e
		}
		if i > 0 && s.Start <= input.Scenes[i-1].End {
			return fmt.Errorf("場逆順")
		}
		c := s.ExpectedQuality
		for _, n := range []int64{c.Lines, c.ClockMissing, c.ClockInvalid, c.Outside, c.Backward, c.LastNonPositive, c.LastNonFinite, c.BadBBO, c.Accepted, c.CutoffExcluded, c.Delivered} {
			if n < 0 {
				return fmt.Errorf("品質負値")
			}
		}
		if c.Accepted != s.ExpectedAccepted || c.Delivered != c.Accepted || c.CutoffExcluded != 0 || c.Lines != c.Accepted+c.ClockMissing+c.ClockInvalid+c.Outside+c.Backward+c.LastNonPositive+c.LastNonFinite || c.BadBBO > c.Accepted {
			return fmt.Errorf("品質分母算術差")
		}
		if strings.HasSuffix(s.Session, "_Day") {
			days++
		}
		if strings.HasSuffix(s.Session, "_Night") {
			nights++
		}
	}
	if all73 && (days != 37 || nights != 36 || pubs != 12794) {
		return fmt.Errorf("固定73場/12794公表差")
	}
	return nil
}

// scan は全Rawを一走査し旧順序で同Raw全公表後のA/B構造イベントを生成します。
//
// 引数: all([]Scene145)、at(int)。返り値: SceneResult/error。自然価格の複写はしません。
func scan(all []Scene145, at int) (SceneResult, error) {
	s := all[at]
	out := SceneResult{Session: s.Session, Contract: s.Contract, Start: s.Start, End: s.End, ForceClose: s.ForceClose,
		ExecutionEnd: s.End - 300, Raw: s.Raw, ExpectedAccepted: s.ExpectedAccepted, ExpectedQuality: s.ExpectedQuality, RawPasses: 1}
	bank := rules.NewBank()
	for i := 0; i < at; i++ {
		p := all[i]
		if e := bank.StartSession(p.Session, p.Contract); e != nil {
			return out, e
		}
		for _, pub := range p.Publications {
			if pub.Stamp.Time >= s.Start {
				return out, fmt.Errorf("前史時計差")
			}
			if e := bank.Add(pub); e != nil {
				return out, e
			}
		}
	}
	if e := bank.StartSession(s.Session, s.Contract); e != nil {
		return out, e
	}
	d, e := New(s)
	if e != nil {
		return out, e
	}
	out.EntryLimit = d.limit()
	window := &History{}
	f, e := os.Open(s.Raw.Path)
	if e != nil {
		return out, e
	}
	defer f.Close()
	before, e := f.Stat()
	if e != nil {
		return out, e
	}
	out.StatBefore = FileStat{Bytes: before.Size(), ModTimeNS: before.ModTime().UnixNano()}
	h := sha256.New()
	tee := io.TeeReader(f, h)
	reader, encoding, e := rawStream133(tee)
	if e != nil {
		return out, e
	}
	defer reader.Close()
	out.RawEncoding = encoding
	scanner := bufio.NewScanner(reader)
	scanner.Buffer(make([]byte, 65536), 8*1024*1024)
	previous, index, pi := s.Start, int64(0), 0
	contracts := map[string]bool{}
	definition := Scene{Session: s.Session, Contract: s.Contract, Start: s.Start, End: s.End, Raw: s.Raw}
	for scanner.Scan() {
		out.Counts.Lines++
		q, _, next, err := decodeRow(scanner.Bytes(), out.Counts.Lines, index, definition, previous, &out.Counts, contracts)
		previous = next
		if err != nil {
			return out, err
		}
		if q == nil {
			continue
		}
		index++
		for pi < len(s.Publications) && int64(s.Publications[pi].Stamp.Index) <= q.Index {
			p := s.Publications[pi]
			if int64(p.Stamp.Index) != q.Index || int64(p.Stamp.Line) != q.SourceLine || p.Stamp.Time != q.Time {
				return out, fmt.Errorf("背景配送原行差")
			}
			if e = bank.Add(p); e != nil {
				return out, e
			}
			window.observe(p)
			pi++
		}
		if e = d.Observe(bank, window, *q); e != nil {
			return out, e
		}
	}
	if e = scanner.Err(); e != nil {
		return out, e
	}
	if _, e = io.Copy(io.Discard, tee); e != nil {
		return out, e
	}
	out.ActualSHA = hex.EncodeToString(h.Sum(nil))
	after, e := f.Stat()
	if e != nil {
		return out, e
	}
	pathAfter, e := os.Stat(s.Raw.Path)
	if e != nil {
		return out, e
	}
	out.StatAfter = FileStat{Bytes: after.Size(), ModTimeNS: after.ModTime().UnixNano()}
	if out.ActualSHA != s.Raw.SHA256 || !os.SameFile(before, pathAfter) || before.Size() != after.Size() || !before.ModTime().Equal(after.ModTime()) || before.Size() != pathAfter.Size() || !before.ModTime().Equal(pathAfter.ModTime()) || out.StatBefore != out.StatAfter || !reflect.DeepEqual(out.Counts, *s.ExpectedQuality) || index != s.ExpectedAccepted || pi != len(s.Publications) || len(contracts) != 1 || !contracts[s.Contract] {
		return out, fmt.Errorf("Raw SHA/stat/品質/限月/背景差:%s", s.Session)
	}
	d.Finish()
	out.Episodes = d.Episodes
	out.Events = d.Events
	out.ArmChecks = d.ArmChecks
	out.Stats = d.Stats
	out.Quality = out.Counts
	out.Success = true
	return out, nil
}

// Generate は場順を保持して全場を独立生成し、0取得場も保存します。
//
// 引数: input(Input145)、workers(int)、all73(bool)。返り値: Result/error。falseは人工専用です。
func Generate(input Input145, workers int, all73 bool) (Result, error) {
	out := Result{Trial: 145, InputSHA: InputSHA, Scenes: make([]SceneResult, len(input.Scenes)), Summary: map[string]uint64{}}
	if e := Validate(input, workers, all73); e != nil {
		return out, e
	}
	jobs := make(chan int)
	errs := make([]error, len(input.Scenes))
	var wg sync.WaitGroup
	for n := 0; n < workers; n++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for i := range jobs {
				out.Scenes[i], errs[i] = scan(input.Scenes, i)
			}
		}()
	}
	for i := range input.Scenes {
		jobs <- i
	}
	close(jobs)
	wg.Wait()
	for i, s := range out.Scenes {
		if errs[i] != nil {
			return out, fmt.Errorf("%s:%w", input.Scenes[i].Session, errs[i])
		}
		out.Summary["場数"]++
		out.Summary["episode数"] += uint64(len(s.Episodes))
		out.Summary["出生数"] += uint64(len(s.Events))
		for _, e := range s.Events {
			out.Summary["status/"+e.Status]++
			if e.Status == "filled" {
				out.Summary["取得数"]++
			}
		}
		for k, v := range s.Stats {
			out.Summary["stage/"+k] += v
		}
	}
	out.Success = true
	return out, nil
}
