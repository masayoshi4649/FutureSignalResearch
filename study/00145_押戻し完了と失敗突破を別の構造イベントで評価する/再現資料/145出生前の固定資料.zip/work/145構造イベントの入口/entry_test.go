package structureevent145

import (
	"bytes"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"os"
	"path/filepath"
	"reflect"
	"testing"
	"time"
)

type fixture145 struct {
	d       *Detector
	bank    *rules.Bank
	history *History
	side    int
	family  string
}

// publication145 は全値既知の人工公表を作ります。
//
// 引数: width(int)、end/at(float64)、index(int)、ohlc(rules.OHLC)、hist(float64)。返り値: rules.Publicationです。
func publication145(width int, end, at float64, index int, ohlc rules.OHLC, hist float64) rules.Publication {
	f := rules.ChartFrame{ID: fmt.Sprintf("%d/%g", width, end), SessionID: "人工_Day", Contract: "X", Width: width, Start: end - float64(width), End: end, AvailableAt: end + 60, DeliveryAt: at, PriceKnown: true, VolumeKnown: true, Volume: 100, OHLC: ohlc, Technical: rules.Technical{EMA8: val(100), EMA21: val(102), EMA8Delta: val(1), EMA21Delta: val(1), Gap: val(10), ATR: val(50), PreviousATR: val(50), TR: val(20), RSI: val(50), PreviousRSI: val(49), Histogram: val(hist), PreviousHistogram: val(999)}}
	return rules.Publication{Stamp: rules.Stamp{Time: at, Index: index, Line: index + 1}, Frame: rules.Frame{Frame: f, DMI: rules.DMI{PlusDI: val(30), MinusDI: val(10), ADX: val(21), PreviousADX: val(20)}}}
}

// mirror145 は価格・符号・DIを物理反対へ写します。
//
// 引数: p(rules.Publication)、side(int)。返り値: rules.Publicationはside負なら鏡像です。
func mirror145(p rules.Publication, side int) rules.Publication {
	if side > 0 {
		return p
	}
	f := &p.Frame.Frame
	o := f.OHLC
	f.OHLC = rules.OHLC{Open: 200 - o.Open, High: 200 - o.Low, Low: 200 - o.High, Close: 200 - o.Close}
	f.Technical.EMA8.Value = 200 - f.Technical.EMA8.Value
	f.Technical.EMA21.Value = 200 - f.Technical.EMA21.Value
	for _, v := range []*rules.Value{&f.Technical.EMA8Delta, &f.Technical.EMA21Delta, &f.Technical.Gap, &f.Technical.Histogram, &f.Technical.PreviousHistogram} {
		v.Value = -v.Value
	}
	p.Frame.DMI.PlusDI, p.Frame.DMI.MinusDI = p.Frame.DMI.MinusDI, p.Frame.DMI.PlusDI
	return p
}

// testQuote145 は別原行で正常BBOを持つ人工価格時計を作ります。
//
// 引数: side(int)、at(float64)、index(int64)、last(float64)。返り値: Quoteです。
func testQuote145(side int, at float64, index int64, last float64) Quote {
	q := Quote{Clock: time.Unix(int64(at), 0).UTC().Format(time.RFC3339Nano), Time: at, Index: index, SourceLine: index + 1, Last: last, Bid: last - 1, Ask: last + 1, QuoteOK: true}
	if side < 0 {
		q.Last, q.Bid, q.Ask = 200-last, 200-q.Ask, 200-q.Bid
	}
	return q
}

// feed145 は全同原行公表の配送後だけ状態を一回観測します。
//
// 引数: t(*testing.T)、x(*fixture145)、q(Quote)、pubs(...rules.Publication)。返り値: ありません。
func feed145(t *testing.T, x *fixture145, q Quote, pubs ...rules.Publication) {
	t.Helper()
	for _, p := range pubs {
		if err := x.bank.Add(p); err != nil {
			t.Fatal(err)
		}
		x.history.observe(p)
	}
	if err := x.d.Observe(x.bank, x.history, q); err != nil {
		t.Fatal(err)
	}
}

// initial145 は3本歴史と現在背景を持つ人工場をarm直前まで作ります。
//
// 引数: t(*testing.T)、side(int)、family(string)。返り値: *fixture145です。
func initial145(t *testing.T, side int, family string) *fixture145 {
	t.Helper()
	d, err := New(Scene145{Session: "人工_Day", Contract: "X", Start: 0, End: 20000, ForceClose: 19500})
	if err != nil {
		t.Fatal(err)
	}
	x := &fixture145{d: d, bank: rules.NewBank(), history: &History{}, side: side, family: family}
	if err = x.bank.StartSession("人工_Day", "X"); err != nil {
		t.Fatal(err)
	}
	for i := 1; i <= 3; i++ {
		p := publication145(300, float64(i*300), float64(i*300+61), i, rules.OHLC{Open: 100, High: 110, Low: 90, Close: 105}, 2)
		feed145(t, x, testQuote145(side, float64(i*300+61), int64(i), 100), mirror145(p, side))
	}
	return x
}

// arm145 はA調整又はB失敗突破と現在の全背景を同Rawで配送します。
//
// 引数: t(*testing.T)、x(*fixture145)、mutate(func(*rules.Publication))。返り値: ありません。
func arm145(t *testing.T, x *fixture145, mutate func(*rules.Publication)) {
	t.Helper()
	o := rules.OHLC{Open: 106, High: 108, Low: 99, Close: 100}
	hist := 1.
	if x.family == "B0" {
		o = rules.OHLC{Open: 90, High: 108, Low: 80, Close: 100}
		hist = -2
	}
	p := publication145(300, 1200, 1261, 4, o, hist)
	p.Frame.Frame.Technical.EMA8 = val(999)
	p.Frame.Frame.Technical.EMA21 = val(999)
	p.Frame.Frame.Technical.PreviousHistogram = val(-999)
	if mutate != nil {
		mutate(&p)
	}
	b15 := publication145(900, 1200, 1261, 4, rules.OHLC{Open: 100, High: 110, Low: 90, Close: 105}, 1)
	b30 := publication145(1800, 1200, 1261, 4, rules.OHLC{Open: 100, High: 110, Low: 90, Close: 105}, 1)
	if x.family == "B0" {
		b15.Frame.DMI.ADX = val(19)
		b30.Frame.Frame.Technical.Gap = val(-10)
		b30.Frame.Frame.Technical.EMA21Delta = val(-1)
	}
	feed145(t, x, testQuote145(x.side, 1261, 4, 100), mirror145(p, x.side), mirror145(b15, x.side), mirror145(b30, x.side))
}

// confirmation145 は確認足の実前足量とHistへ束縛した回復を配送します。
//
// 引数: t(*testing.T)、x(*fixture145)、mutate(func(*rules.Publication))。返り値: ありません。
func confirmation145(t *testing.T, x *fixture145, mutate func(*rules.Publication)) {
	t.Helper()
	p := publication145(300, 1500, 1561, 5, rules.OHLC{Open: 110, High: 130, Low: 108, Close: 120}, 3)
	p.Frame.Frame.Volume = 120
	if mutate != nil {
		mutate(&p)
	}
	feed145(t, x, testQuote145(x.side, 1561, 5, 120), mirror145(p, x.side))
}

// Test145Aの前EMAと歴史fresh分離 は前足が現在期限切れでもarmの歴史証拠として使えることを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test145Aの前EMAと歴史fresh分離(t *testing.T) {
	for _, side := range []int{1, -1} {
		x := initial145(t, side, "A0")
		arm145(t, x, nil)
		if len(x.d.Episodes) != 1 || x.d.active == nil {
			t.Fatal("armなし")
		}
		e := x.d.Episodes[0]
		if e.Arm.At.Time < e.Arm.Previous[2].Frame.Frame.End+360 {
			t.Fatal("歴史fresh分離の人工不足")
		}
		if e.Structure.Width != 29 || e.Arm.Fields["actual_hist_delta"].Value != float64(-side) {
			t.Fatal(e)
		}
		confirmation145(t, x, nil)
		if len(x.d.Events) != 1 || x.d.Events[0].Status != "pending" {
			t.Fatal("確認なし")
		}
		feed145(t, x, testQuote145(side, 1561.5, 6, 120))
		if x.d.Events[0].EntryQuote != nil {
			t.Fatal("1秒未満で取得")
		}
		q := testQuote145(side, 1562, 7, 120)
		q.SourceLine = x.d.Events[0].Birth.SourceLine
		feed145(t, x, q)
		if x.d.Events[0].EntryQuote != nil {
			t.Fatal("同じ物理行で取得")
		}
		feed145(t, x, testQuote145(side, 1562, 8, 120))
		event := x.d.Events[0]
		if event.Status != "filled" || event.EntryPrice == nil || *event.EntryPrice != event.EntryQuote.Ask && side > 0 || *event.EntryPrice != event.EntryQuote.Bid && side < 0 {
			t.Fatal(event)
		}
		for _, r := range event.Refs {
			if r.Delivered.Time > event.EntryQuote.Time || r.Delivered.Index > int(event.EntryQuote.Index) || r.Delivered.Line > int(event.EntryQuote.SourceLine) {
				t.Fatal("未来参照")
			}
		}
	}
}

// Test145Bの鏡像と現在30方向変化 はarm時dを凍結し現在Bに元d維持を足さないことを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test145Bの鏡像と現在30方向変化(t *testing.T) {
	for _, side := range []int{1, -1} {
		x := initial145(t, side, "B0")
		arm145(t, x, nil)
		if x.d.active == nil || x.d.active.Family != "B0" || x.d.active.OriginalDirection != -side {
			t.Fatal("Barmなし")
		}
		p := publication145(300, 1500, 1561, 5, rules.OHLC{Open: 110, High: 130, Low: 108, Close: 120}, 3)
		p.Frame.Frame.Volume = 120
		p30 := publication145(1800, 1500, 1561, 5, rules.OHLC{Open: 100, High: 110, Low: 90, Close: 105}, 1)
		feed145(t, x, testQuote145(side, 1561, 5, 120), mirror145(p, side), mirror145(p30, side))
		if len(x.d.Events) != 1 {
			t.Fatal("Bへ元方向維持を追加した")
		}
		feed145(t, x, testQuote145(side, 1562, 6, 120))
		if x.d.Events[0].Status != "filled" {
			t.Fatal(x.d.Events[0])
		}
	}
}

// Test145実前足束縛と形状 は前値Technicalを代用せず量・Hist・TRとB曖昧を検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test145実前足束縛と形状(t *testing.T) {
	for _, kind := range []string{"Hist", "量未知", "量0", "量減少", "TR"} {
		t.Run(kind, func(t *testing.T) {
			x := initial145(t, 1, "A0")
			arm145(t, x, nil)
			confirmation145(t, x, func(p *rules.Publication) {
				f := &p.Frame.Frame
				switch kind {
				case "Hist":
					f.Technical.Histogram = val(.5)
					f.Technical.PreviousHistogram = val(-999)
				case "量未知":
					f.VolumeKnown = false
				case "量0":
					f.Volume = 0
				case "量減少":
					f.Volume = 99
				case "TR":
					f.Technical.TR = val(101)
				}
			})
			if len(x.d.Events) != 0 || x.d.active == nil {
				t.Fatal("不成立確認から出生又はepisode喪失")
			}
		})
	}
	for _, kind := range []string{"両端", "点域"} {
		x := initial145(t, 1, "B0")
		if kind == "点域" {
			for i := range x.history.Five {
				x.history.Five[i].Frame.Frame.OHLC = rules.OHLC{Open: 100, High: 100, Low: 100, Close: 100}
			}
		}
		arm145(t, x, func(p *rules.Publication) {
			if kind == "両端" {
				p.Frame.Frame.OHLC.High = 120
			}
		})
		if len(x.d.Episodes) != 0 {
			t.Fatal("B曖昧/点域arm")
		}
		if len(x.d.ArmChecks) == 0 {
			t.Fatal("拒否理由未保存")
		}
	}
}

// Test145構造幅とcap等号 は125幅の等号と幅超過・現在Last/実Pの上下限を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test145構造幅とcap等号(t *testing.T) {
	for _, side := range []int{1, -1} {
		for _, width := range []float64{100, 125, 126} {
			x := initial145(t, side, "A0")
			arm145(t, x, func(p *rules.Publication) {
				p.Frame.Frame.OHLC = rules.OHLC{Open: 58 + width - 23, High: 58 + width - 20, Low: 58, Close: 80}
			})
			e := x.d.Episodes[0]
			if e.Structure.Width != width {
				t.Fatal(e.Structure)
			}
			if width == 100 {
				if e.Structure.Cap != 25 {
					t.Fatal("125-Wのcap", e.Structure)
				}
				continue
			}
			if width > 125 {
				if e.Status != "structure_width_rejected" || x.d.active != nil {
					t.Fatal(e)
				}
				continue
			}
			if e.Structure.Cap != 0 {
				t.Fatal(e.Structure)
			}
			k := e.Structure.K
			f := publication145(300, 1500, 1561, 5, rules.OHLC{Open: 170, High: 180, Low: 160, Close: 173}, 3)
			f.Frame.Frame.Volume = 120
			feed145(t, x, testQuote145(side, 1561, 5, 173), mirror145(f, side))
			if len(x.d.Events) != 1 {
				t.Fatal("cap0出生")
			}
			q := testQuote145(side, 1562, 6, 173)
			if side > 0 {
				q.Ask = k
				q.Bid = k - 1
			} else {
				q.Bid = k
				q.Ask = k + 1
			}
			feed145(t, x, q)
			if x.d.Events[0].Status != "filled" {
				t.Fatal(x.d.Events[0])
			}
		}
	}
	st := Structure{K: 100, I: 80, Width: 20, Cap: 30, ArmATR: 30}
	if !allowed(1, 100, st) || !allowed(1, 130, st) || allowed(1, 99, st) || allowed(1, 131, st) {
		t.Fatal("域境界")
	}
}

// Test145最初正常域外と悪BBO は現在Lastを維持しても実Ask/Bid域外なら待ち直さないことを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test145最初正常域外と悪BBO(t *testing.T) {
	for _, side := range []int{1, -1} {
		x := initial145(t, side, "A0")
		arm145(t, x, nil)
		confirmation145(t, x, nil)
		q := testQuote145(side, 1562, 6, 120)
		q.QuoteOK = false
		q.Bid = 0
		q.Ask = 0
		feed145(t, x, q)
		if x.d.pending == nil {
			t.Fatal("悪BBOだけで取消")
		}
		q = testQuote145(side, 1563, 7, 120)
		if side > 0 {
			q.Ask = 200
		} else {
			q.Bid = 0.5
		}
		feed145(t, x, q)
		if x.d.Events[0].Status != "entry_position_rejected" {
			t.Fatal(x.d.Events[0])
		}
		feed145(t, x, testQuote145(side, 1564, 8, 120))
		if len(x.d.Events) != 1 || x.d.Events[0].EntryQuote != nil {
			t.Fatal("域外後再待機")
		}
	}
}

// Test145現在否定と期限 はI/背景/Last位置を毎Raw監視しTTL等号を拒否します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test145現在否定と期限(t *testing.T) {
	for _, kind := range []string{"I", "LastK", "TTL", "episodeTTL", "新規限界", "新背景未知"} {
		t.Run(kind, func(t *testing.T) {
			x := initial145(t, 1, "A0")
			arm145(t, x, nil)
			if kind == "episodeTTL" {
				feed145(t, x, testQuote145(1, 2161, 6, 100))
				if x.d.Episodes[0].Status != "episode_expired" {
					t.Fatal(x.d.Episodes[0])
				}
				return
			}
			confirmation145(t, x, nil)
			q := testQuote145(1, 1562, 6, 120)
			switch kind {
			case "新規限界":
				q.Time = x.d.limit()
			case "I":
				q.Last = x.d.Events[0].Structure.I
				q.QuoteOK = false
				q.Bid = 0
				q.Ask = 0
			case "LastK":
				q.Last = 117
			case "TTL":
				q.Time = 1591
			case "新背景未知":
				p := publication145(900, 1500, 1562, 6, rules.OHLC{Open: 100, High: 110, Low: 90, Close: 105}, 1)
				p.Frame.DMI.PreviousADX = rules.Value{}
				feed145(t, x, q, p)
				if x.d.Events[0].Status != "background_lost" {
					t.Fatal(x.d.Events[0])
				}
				return
			}
			feed145(t, x, q)
			if x.d.Events[0].EntryQuote != nil || x.d.active != nil {
				t.Fatal("否定後占有又は取得")
			}
		})
	}
}

// Test145占有中の新足と取消足再利用 はpending処理終了Rawの新IDを後からarmへ使わないことを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test145占有中の新足と取消足再利用(t *testing.T) {
	x := initial145(t, 1, "A0")
	arm145(t, x, nil)
	confirmation145(t, x, nil)
	p := publication145(300, 1800, 1861, 6, rules.OHLC{Open: 106, High: 108, Low: 99, Close: 100}, 1)
	feed145(t, x, testQuote145(1, 1861, 6, 100), p)
	if x.d.Events[0].Status != "unfilled_expired" {
		t.Fatal(x.d.Events[0])
	}
	feed145(t, x, testQuote145(1, 1862, 7, 100))
	if len(x.d.Episodes) != 1 || x.d.active != nil {
		t.Fatal("取消足再arm")
	}
}

// Test145欠足と同Raw最新のみ は履歴切断の取消とcatchup中の古い足arm禁止を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test145欠足と同Raw最新のみ(t *testing.T) {
	x := initial145(t, 1, "A0")
	arm145(t, x, nil)
	p := publication145(300, 1800, 1861, 5, rules.OHLC{Open: 110, High: 130, Low: 108, Close: 120}, 3)
	feed145(t, x, testQuote145(1, 1861, 5, 120), p)
	if x.d.Episodes[0].Status != "structure_disconnected" {
		t.Fatal(x.d.Episodes[0])
	}
	x = initial145(t, 1, "A0")
	p = publication145(300, 1200, 1561, 4, rules.OHLC{Open: 106, High: 108, Low: 99, Close: 100}, 1)
	r := publication145(300, 1500, 1561, 4, rules.OHLC{Open: 110, High: 130, Low: 108, Close: 120}, 3)
	b15 := publication145(900, 1200, 1561, 4, rules.OHLC{Open: 100, High: 110, Low: 90, Close: 105}, 1)
	b30 := publication145(1800, 1200, 1561, 4, rules.OHLC{Open: 100, High: 110, Low: 90, Close: 105}, 1)
	feed145(t, x, testQuote145(1, 1561, 4, 120), p, r, b15, b30)
	if len(x.d.Episodes) != 0 || len(x.d.Events) != 0 {
		t.Fatal("同Raw古いarm→confirm")
	}
}

// Test145arm即IとEOF はarmを保存して現在否定又はEOFで終えることを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test145arm即IとEOF(t *testing.T) {
	x := initial145(t, 1, "A0")
	arm145(t, x, func(p *rules.Publication) {
		p.Frame.Frame.OHLC.Low = 110
		p.Frame.Frame.OHLC.High = 120
		p.Frame.Frame.OHLC.Open = 120
		p.Frame.Frame.OHLC.Close = 110
	})
	if len(x.d.Episodes) != 0 {
		t.Fatal("前EMA非接触")
	}
	x = initial145(t, 1, "A0")
	x.history.Five[2].Frame.Frame.Technical.EMA8 = val(115)
	x.history.Five[2].Frame.Frame.Technical.EMA21 = val(115)
	arm145(t, x, func(p *rules.Publication) {
		p.Frame.Frame.OHLC = rules.OHLC{Open: 120, High: 120, Low: 110, Close: 110}
	})
	if len(x.d.Episodes) != 1 || x.d.Episodes[0].Status != "invalidation_reached" || x.d.active != nil || len(x.d.Events) != 0 {
		t.Fatal("arm同RawのI等号を取消しない")
	}
	x = initial145(t, 1, "A0")
	arm145(t, x, nil)
	x.d.Finish()
	if x.d.Episodes[0].Status != "eof_unfinished" || len(x.d.Events) != 0 {
		t.Fatal("EOF架空取得")
	}
	x = initial145(t, 1, "A0")
	arm145(t, x, nil)
	confirmation145(t, x, nil)
	before, _ := json.Marshal(x.d.Events[0].Arm)
	x.history.Five = nil
	after, _ := json.Marshal(x.d.Events[0].Arm)
	if !reflect.DeepEqual(before, after) {
		t.Fatal("履歴共有")
	}
	x.d.Finish()
	if x.d.Events[0].Status != "eof_unfilled" {
		t.Fatal(x.d.Events[0])
	}
}

// artificialRaw145 は全10深度の人工入力をplain/gzipの同じ価格時計で作ります。
//
// 引数: t(*testing.T)、compressed(bool)。返り値: Scene145は品質付き参照です。
func artificialRaw145(t *testing.T, compressed bool) Scene145 {
	t.Helper()
	var b bytes.Buffer
	for i, at := range []int64{120, 121, 122} {
		row := map[string]any{"Symbol": "X", "CurrentPriceTime": time.Unix(at, 0).UTC().Format(time.RFC3339Nano), "CurrentPrice": 100.}
		for j := 1; j <= 10; j++ {
			row[fmt.Sprintf("Buy%d", j)] = map[string]float64{"Price": 90, "Qty": 1}
			row[fmt.Sprintf("Sell%d", j)] = map[string]float64{"Price": 110, "Qty": 1}
		}
		if i == 1 {
			row["Buy1"] = map[string]float64{"Price": 0, "Qty": 1}
		}
		data, e := json.Marshal(row)
		if e != nil {
			t.Fatal(e)
		}
		b.Write(data)
		b.WriteByte('\n')
	}
	body := b.Bytes()
	if compressed {
		var z bytes.Buffer
		w := gzip.NewWriter(&z)
		_, _ = w.Write(body)
		_ = w.Close()
		body = z.Bytes()
	}
	path := filepath.Join(t.TempDir(), "raw")
	if e := os.WriteFile(path, body, 0600); e != nil {
		t.Fatal(e)
	}
	h := sha256.Sum256(body)
	return Scene145{Session: "人工_Day", Contract: "X", Start: 0, End: 10000, ForceClose: 9000, Raw: FileRef{Path: path, SHA256: hex.EncodeToString(h[:])}, ExpectedAccepted: 3, ExpectedQuality: &Counts{Lines: 3, Accepted: 3, Delivered: 3, BadBBO: 1}}
}

// Test145一走査と0場品質 は全原行の品質・SHAを保持し0出生場も配列で残すことを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test145一走査と0場品質(t *testing.T) {
	for _, compressed := range []bool{false, true} {
		s := artificialRaw145(t, compressed)
		r, e := Generate(Input145{Trial: 122, Scenes: []Scene145{s}}, 1, false)
		if e != nil {
			t.Fatal(e)
		}
		v := r.Scenes[0]
		if r.Trial != 145 || !r.Success || v.Counts != *s.ExpectedQuality || v.StatBefore != v.StatAfter || v.Events == nil || v.Episodes == nil || len(v.Events) != 0 || v.RawPasses != 1 {
			t.Fatal(v)
		}
		s.ExpectedQuality.BadBBO = 0
		if _, e = Generate(Input145{Scenes: []Scene145{s}}, 1, false); e == nil {
			t.Fatal("品質差受理")
		}
	}
	if _, e := Load("存在しない", "不正"); e == nil {
		t.Fatal("I/O前SHA拒否なし")
	}
}
