"""145の全取得を、金融を読まず133の固定取得形式へ転送する。"""
from pathlib import Path
import argparse
import copy
import gzip
import hashlib
import json
import math

ROOT=Path(__file__).resolve().parent.parent
COMMON=ROOT/'inputs/00124_同入口正逆の共用入力/入力.json.gz'
OLD=ROOT/'work/全成立poolの非金融manifest/manifest.json'
OLD_FIXED=ROOT/'work/138全成立入口の評価/固定入力_版2/固定取得入力.json'
SHAS={COMMON:'717f41674a4c99f94545a5e147495ae66498dbbc1afa48d7f34d04c40514843b',
      OLD:'e7ba444fd66f9ca52e10e929eeb31d21076f97afa161de738dabca14a8ff8e35',
      OLD_FIXED:'0c83e525dec3079ce188d942069c0d137c94f39009339752ec8227ec9ecb4ce7'}
QUOTE_FIELDS=('time','index','source_line','last','bid','ask','quote_ok','clock')


def sha(path: Path) -> str:
    """
    機能: 保存bytesの指紋を求める。
    引数: path(Path)は対象ファイル。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def save(path: Path, value: dict) -> None:
    """
    機能: UTF-8のJSONを未作成先へ保存する。
    引数: path(Path)、value(dict)は保存先と内容。
    返り値: None。
    """
    with path.open('x',encoding='utf-8',newline='\n') as f:
        json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')


# ----------------------------------------
def validate_event(event: dict, limit: float) -> None:
    """
    機能: 新取得の別Raw/期限と、実Ask/Bid・Lastの固定構造域を確認する。
    引数: event(dict)はfilled票、limit(float)は共通新規限界。
    返り値: None。不一致をAssertionErrorで拒否する。
    """
    required={'id','family','side','status','birth','entryQuote','entry_price','expires',
              'episode_id','structure','arm','confirm','refs'}
    assert required<=event.keys()
    assert event['family'] in ('A0','B0') and type(event['side']) is int and event['side'] in (-1,1)
    assert event['status']=='filled' and event['episode_id']
    b,q=event['birth'],event['entryQuote'];s=event['side'];v=event['structure']
    assert set(QUOTE_FIELDS)<=set(b) and set(QUOTE_FIELDS)<=set(q)
    assert all(type(v[k]) in (int,float) and math.isfinite(v[k]) for k in ('k','i','width','cap','arm_atr'))
    assert 0<v['width']<=125 and v['arm_atr']>0
    assert math.isclose(v['width'],s*(v['k']-v['i']),abs_tol=1e-9)
    assert math.isclose(v['cap'],min(v['arm_atr'],125-v['width']),abs_tol=1e-9)
    assert q['index']>b['index'] and q['source_line']>b['source_line']
    assert b['time']<event['expires']<=min(b['time']+30,limit)
    assert b['time']+1<=q['time']<event['expires']
    assert b['clock'] and q['clock'] and q['quote_ok'] and 0<q['bid']<q['ask']
    price=q['ask'] if s==1 else q['bid']
    assert event['entry_price']==price
    assert all(0<=s*(x-v['k'])<=v['cap'] for x in (b['last'],q['last'],price))
    assert 0<s*(price-v['i'])<=125


# ----------------------------------------
def build(common: dict, controls: list[dict], source: dict) -> tuple[dict,dict]:
    """
    機能: C0/A0/B0全取得とC0優先の同原行unionを組み立てる。
    引数: common(dict)、controls(list[dict])、source(dict)は場・旧対照・145自然票。
    返り値: tuple[dict,dict]は固定入力と入口参照。自然金融は開かない。
    """
    assert source['success'] and source['trial']==145
    sessions=[s['session'] for s in common['scenes']]
    assert [s['session'] for s in source['scenes']]==sessions
    specs={s['session']:s for s in common['scenes']}
    output={'scenes':[],'expected_entry_count':0}
    meta={'success':True,'trial':145,'sessions':sessions,'entries':[],'union':[],
          'dedup_key':'session/contract/取得time/index/source_line','dedup_priority':'C0→A0→B0',
          'policies':['C0','A0','B0','U0','RU'],'financial_labels_used':False,'portfolio_replay':False}
    by_scene={sid:[] for sid in sessions}
    for e in controls:
        by_scene[e['session']].append({'id':'C0/'+e['id'],'session':e['session'],'contract':e['contract'],
            'model':'C0','candidate_id':e['id'],'native_side':e['side'],'baseline':True,
            'entry_quote':copy.deepcopy(e['entryQuote']),'origins':copy.deepcopy(e['origins'])})
    for scene in source['scenes']:
        sid=scene['session'];spec=specs[sid];limit=min(spec['force_close'],spec['end']-3900)
        assert scene['success'] and scene['stat_before']==scene['stat_after']
        assert scene['contract']==spec['contract'] and scene['actual_sha256']==spec['raw']['sha256']
        assert scene['counts']==spec['expected_quality'] and isinstance(scene['events'],list)
        assert isinstance(scene['episodes'],list)
        episode_ids={e['id'] for e in scene['episodes']}
        episode_map={e['id']:e for e in scene['episodes']}
        assert len(episode_ids)==len(scene['episodes'])
        born_ids=set();born_episodes=set()
        for index,event in enumerate(scene['events']):
            assert event['id'] not in born_ids;born_ids.add(event['id'])
            assert event['episode_id'] in episode_ids
            assert event['episode_id'] not in born_episodes
            born_episodes.add(event['episode_id'])
            if event['status']!='filled':continue
            validate_event(event,limit)
            assert event['expires']<=episode_map[event['episode_id']]['expires']
            family=event['family']
            by_scene[sid].append({'id':family+'/'+event['id'],'session':sid,'contract':scene['contract'],
                'model':family,'candidate_id':event['id'],'native_side':event['side'],'baseline':False,
                'entry_quote':copy.deepcopy(event['entryQuote']),
                'origins':[{'family':family,'variant':'押戻し回復' if family=='A0' else '失敗突破の反転確認',
                    'episode_id':event['episode_id'],'source_locator':{'scene':sid,'event_index':index},
                    'birthQuote':copy.deepcopy(event['birth']),'structure':copy.deepcopy(event['structure']),
                    'refs':copy.deepcopy(event['refs']),
                    'refs_asof':'取得時点まで。出生確定票はSource.arm/confirmを参照'}]})
    seen_ids=set();priority={'C0':0,'A0':1,'B0':2}
    for original in common['scenes']:
        scene=copy.deepcopy(original);sid=scene['session'];scene['entries']=[]
        grouped={};new_stamps=set();per_model=set()
        basis=sorted(by_scene[sid],key=lambda e:(e['entry_quote']['index'],priority[e['model']],e['id']))
        for e in basis:
            q=e['entry_quote'];s=e['native_side']
            assert e['contract']==scene['contract'] and type(s) is int and s in (-1,1)
            assert e['id'] not in seen_ids and set(QUOTE_FIELDS)<=set(q)
            assert q['clock'] and q['quote_ok'] and 0<q['bid']<q['ask'] and q['last']>0
            assert scene['start']<=q['time']<min(scene['force_close'],scene['end']-3900)
            key=(sid,e['contract'],q['time'],q['index'],q['source_line'])
            assert (e['model'],key) not in per_model,('同family同原行',e['id'])
            if e['model']!='C0':
                assert key not in new_stamps,('単一pendingに反するA/B同原行取得',key)
                new_stamps.add(key)
            per_model.add((e['model'],key));seen_ids.add(e['id'])
            scene['entries'].append({'id':e['id'],'side':s,'entry':copy.deepcopy(q)})
            meta['entries'].append(e);grouped.setdefault(key,[]).append(e)
        for key,items in grouped.items():
            chosen=min(items,key=lambda e:priority[e['model']])
            assert all(all(e['entry_quote'][k]==chosen['entry_quote'][k] for k in QUOTE_FIELDS) for e in items)
            meta['union'].append({'canonical_id':chosen['id'],'alias_ids':[e['id'] for e in items],
                'session':sid,'contract':scene['contract'],'entry_stamp':{'time':key[2],'index':key[3],'source_line':key[4]},
                'alias_sides':{e['id']:e['native_side'] for e in items}})
        output['scenes'].append(scene);output['expected_entry_count']+=len(basis)
    assert output['expected_entry_count']==len(meta['entries'])
    return output,meta


# ----------------------------------------
def main() -> None:
    """
    機能: F0・Source・旧共用源の指紋を確認し、旧81同体と新全取得を保存する。
    引数: CLI f0/source/output-dirと明示SHA。
    返り値: None。自然金融・原板を読み込まない。
    """
    p=argparse.ArgumentParser(description='145の構造取得と旧対照を非金融転送')
    for key in ('f0','source','output-dir'):p.add_argument('--'+key,type=Path,required=True)
    p.add_argument('--f0-sha256',required=True);p.add_argument('--sha256',required=True);args=p.parse_args()
    assert sha(args.f0)==args.f0_sha256 and sha(args.source)==args.sha256
    frozen=json.loads(args.f0.read_bytes());assert frozen['成功'] and frozen['試行']==145
    assert all(sha(Path(n))==h for n,h in frozen['ファイル'].items())
    assert frozen['ファイル'][str(Path(__file__).resolve())]==sha(Path(__file__).resolve())
    for path,h in SHAS.items():assert sha(path)==frozen['ファイル'][str(path)]==h
    common=json.loads(gzip.decompress(COMMON.read_bytes()));controls=json.loads(OLD.read_bytes())['C0']
    assert len(common['scenes'])==73 and len(controls)==81
    fixed,meta=build(common,controls,json.loads(args.source.read_bytes()))
    prior=json.loads(OLD_FIXED.read_bytes())
    before={(s['session'],e['id']):e for s in prior['scenes'] for e in s['entries'] if e['id'].startswith('C0/')}
    after={(s['session'],e['id']):e for s in fixed['scenes'] for e in s['entries'] if e['id'].startswith('C0/')}
    assert before==after and len(after)==81
    for e in meta['entries']:
        if not e['baseline']:e['origins'][0]['source_file_sha']=args.sha256
    dest=args.output_dir;dest.mkdir(parents=True,exist_ok=True)
    assert not any((dest/n).exists() for n in ('固定取得入力.json','入口参照.json','転送の確認.json'))
    save(dest/'固定取得入力.json',fixed)
    meta.update({'fixed_input_sha256':sha(dest/'固定取得入力.json'),'source_sha256':args.sha256,'control_manifest_sha256':SHAS[OLD]})
    save(dest/'入口参照.json',meta)
    assert all(sha(Path(n))==h for n,h in frozen['ファイル'].items())
    counts={m:sum(e['model']==m for e in meta['entries']) for m in ('C0','A0','B0')}
    save(dest/'転送の確認.json',{'成功':True,'試行':145,'F0_SHA256':args.f0_sha256,'Source_SHA256':args.sha256,
        '基礎集合':counts,'union件数':len(meta['union']),'同原行alias除去数':len(meta['entries'])-len(meta['union']),
        '新A/B同原行取得なし':True,'旧81同体':True,'金融参照':False,
        '固定入力SHA256':meta['fixed_input_sha256'],'入口参照SHA256':sha(dest/'入口参照.json')})
    print(json.dumps({'成功':True,'基礎集合':counts,'union件数':len(meta['union']),'旧81同体':True},ensure_ascii=False))


if __name__=='__main__':main()
