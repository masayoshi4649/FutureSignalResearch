"""145の旧対照優先と新構造の取得域を人工資料で検査する。"""
from pathlib import Path
import copy
import importlib.util

SOURCE=Path(__file__).with_name('145構造イベントと旧対照を固定取得へ渡す.py')
spec=importlib.util.spec_from_file_location('145転送の純部品',SOURCE)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)


def fixture() -> tuple[dict,list,dict]:
    """
    機能: 旧2取得・A/B各1取得・取消1件を二場へ配置する。
    引数: なし。
    返り値: tuple[dict,list,dict]は場metadata・旧対照・145人工Source。
    """
    common={'scenes':[]};controls=[];source={'success':True,'trial':145,'scenes':[]}
    for number in range(2):
        sid='人工場'+str(number);start=10000*number
        q={'time':start+100,'index':100,'source_line':101,'clock':'人工価格時計',
           'last':100,'bid':95,'ask':105,'quote_ok':True}
        base={'session':sid,'contract':'人工限月','start':start,'end':start+8000,'force_close':start+7900,
              'raw':{'path':'人工原本','sha256':'0'*64},'expected_quality':{'人工品質':True},'entries':[]}
        common['scenes'].append(base)
        controls.append({'id':sid+'/対照','session':sid,'contract':'人工限月','side':1,'entryQuote':q,'origins':[{'人工':True}]})
        side=-1 if number==0 else 1;family='A0' if number==0 else 'B0'
        birth={**q,'time':start+99,'index':98,'source_line':99}
        event={'id':sid+'/出生','family':family,'side':side,'status':'filled','entryQuote':copy.deepcopy(q),
               'birth':birth,'entry_price':95 if side==-1 else 105,'expires':start+129,
               'episode_id':sid+'/過程','structure':{'k':100,'i':150 if side==-1 else 50,'width':50,'cap':20,'arm_atr':20},
               'arm':{'人工':True},'confirm':{'人工':True},'refs':[]}
        if number==1:event['entryQuote']={**q,'time':start+101,'index':101,'source_line':102}
        cancelled={**event,'id':sid+'/取消','episode_id':sid+'/取消過程','status':'cancelled','entryQuote':None,'entry_price':None}
        source['scenes'].append({'success':True,'session':sid,'contract':'人工限月','actual_sha256':'0'*64,
            'counts':{'人工品質':True},'stat_before':{'人工':True},'stat_after':{'人工':True},
            'episodes':[{'id':event['episode_id'],'expires':start+950},{'id':cancelled['episode_id'],'expires':start+950}],
            'events':[event,cancelled]})
    return common,controls,source


# ----------------------------------------
def main() -> None:
    """
    機能: 同原行C0優先、全場保持、実P構造域/TTL/重複の拒否を確認する。
    引数: なし。人工入力のみを使う。
    返り値: None。不一致はAssertionErrorで停止する。
    """
    common,controls,source=fixture();fixed,meta=module.build(common,controls,source)
    assert fixed['expected_entry_count']==4 and len(meta['union'])==3
    assert meta['union'][0]['canonical_id']=='C0/人工場0/対照'
    assert set(meta['union'][0]['alias_sides'].values())=={-1,1}
    assert {e['model'] for e in meta['entries']}=={'C0','A0','B0'}
    empty=copy.deepcopy(source)
    for scene in empty['scenes']:scene['events']=[];scene['episodes']=[]
    f,m=module.build(common,controls,empty)
    assert f['expected_entry_count']==len(m['union'])==2 and len(f['scenes'])==2
    kinds=('同episode再出生','A/B同原行','取得前出生','品質不一致','TTL等号','side不正',
           '実PがK未満','実Pがcap超','Lastがcap超','構造幅不一致','cap再描画','episode期限超','entry_price差')
    for kind in kinds:
        altered=copy.deepcopy(source);scene=altered['scenes'][0];e=scene['events'][0]
        if kind in ('同episode再出生','A/B同原行'):
            duplicate=copy.deepcopy(e);duplicate['id']='別の出生'
            if kind=='A/B同原行':
                duplicate['family']='B0';duplicate['episode_id']='別の過程'
                scene['episodes'].append({'id':'別の過程','expires':950})
            scene['events'].append(duplicate)
        elif kind=='取得前出生':e['birth']['time']+=100
        elif kind=='品質不一致':scene['counts']={'人工品質':False}
        elif kind=='TTL等号':e['entryQuote']['time']=e['expires']
        elif kind=='side不正':e['side']=True
        elif kind=='実PがK未満':e['entryQuote']['bid']=101;e['entry_price']=101
        elif kind=='実Pがcap超':e['entryQuote']['bid']=75;e['entry_price']=75
        elif kind=='Lastがcap超':e['entryQuote']['last']=75
        elif kind=='構造幅不一致':e['structure']['width']=49
        elif kind=='cap再描画':e['structure']['cap']=21
        elif kind=='episode期限超':scene['episodes'][0]['expires']=110
        else:e['entry_price']=94
        try:module.build(common,controls,altered)
        except AssertionError:pass
        else:raise AssertionError('拒否漏れ: '+kind)
    print('人工15群成功。自然原板・新損益未読。')


if __name__=='__main__':main()
