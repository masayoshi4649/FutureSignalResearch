"""
124の正逆結果・集計・独立検算を金融再実行なしで正式保存する。

Input/Raw/177MB公表/exe本文を読まず、既存CSVを変更しない。
"""

from pathlib import Path
import gzip
import hashlib
import json


ROOT = Path(__file__).resolve().parent.parent
STUDY = ROOT / "study/00124_逆行の原因と売買反転を同じ入口で検証する"


# ----------------------------------------
def sha(data: bytes) -> str:
    """
    機能: 読取済みbytesのSHA256を求める。
    引数: data(bytes)は対象。
    返り値: str型の指紋。
    """
    return hashlib.sha256(data).hexdigest()


# ----------------------------------------
def save_same(path: Path, data: bytes) -> None:
    """
    機能: 未作成先へ保存し、既存なら同bytesを要求する。
    引数: path(Path)は保存先、data(bytes)は内容。
    返り値: None。差があれば例外。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == data
    else:
        with path.open("xb") as stream:
            stream.write(data)


# ----------------------------------------
def main() -> None:
    """
    機能: F1原文と16コードを照合し、正本gzipと小さな検査だけを保存する。
    引数: なし。Rootが許可した結果を使用する。
    返り値: None。金融実行・原板/入力コピー・CSV変更なし。
    """
    checks = STUDY / "検査"
    fixed_bytes = (checks / "再生前固定.json").read_bytes()
    assert sha(fixed_bytes) == "7fdfbf3b8ef9166d7bcaf0b5503a711f6a808dcba718e67c951fe627f71210d3"
    fixed = json.loads(fixed_bytes)
    assert all(sha(Path(p).read_bytes()) == s for p, s in fixed["コード"].items())
    originals = json.loads(gzip.decompress((checks / "実行前文書.json.gz").read_bytes()))
    assert {x["source_path"]: x["SHA256"] for x in originals["原文"]} == fixed["事前文書"]
    for item in originals["原文"]:
        data = item["utf8_text"].encode("utf-8")
        assert sha(data) == item["SHA256"] and len(data) == item["bytes"]
    stored = []
    for source, name, expected in [
        (ROOT / "work/124入口の正逆比較/全73場の正逆結果.json", "全73場の正逆結果.json.gz", "25517066b291a0434211190299b9f0195e67f9a7d2e89c801d5b9e6b4b51c3a1"),
        (ROOT / "work/124入口の原因分析/集計.json", "集計.json.gz", "1ca939bd2c619f6d2a3926999cb1b8e57726d48f2584b798cc6688e42ece49f8"),
    ]:
        data = source.read_bytes()
        assert sha(data) == expected
        packed = gzip.compress(data, compresslevel=9, mtime=0)
        target = STUDY / "成果物" / name
        save_same(target, packed)
        assert gzip.decompress(target.read_bytes()) == data and sha(source.read_bytes()) == expected
        stored.append({"path": target.relative_to(ROOT).as_posix(), "SHA256": sha(packed), "bytes": len(packed), "解凍SHA256": expected, "解凍bytes": len(data)})
    for source, target_name in [
        (ROOT / "work/124入口の原因分析/再生完了.json", "再生完了.json"),
        (ROOT / "work/124正逆の独立検算/全73場の独立検算.json", "独立検算.json"),
        (ROOT / "work/124正逆の独立検算/完了.json", "独立検算器の完了.json"),
        (ROOT / "work/124正逆の独立検算/README.md", "独立レビュー.md"),
    ]:
        data = source.read_bytes()
        if target_name == "独立検算.json":
            assert sha(data) == "dd4754899cad43cbc97cb5fda9b1bbbdecdb0d36de0fc7037bf927c628b8e4d8"
        save_same(checks / target_name, data)
        stored.append({"path": (checks / target_name).relative_to(ROOT).as_posix(), "SHA256": sha(data), "bytes": len(data)})
    assert all(sha(Path(p).read_bytes()) == s for p, s in fixed["コード"].items())
    proof = {"試行": 124, "成功": True, "F1_SHA256": sha(fixed_bytes), "保存": stored, "F1原文6復元同体": True,
             "固定16コード前後不変": True, "金融実行": False, "金融再集計": False, "入力本文読取": False,
             "Raw読取": False, "177MB本文読取": False, "exe本文読取": False, "CSV変更": False}
    save_same(checks / "結果保管の確認.json", (json.dumps(proof, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
    print(json.dumps({"成功": True, "gzip": stored[:2]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
