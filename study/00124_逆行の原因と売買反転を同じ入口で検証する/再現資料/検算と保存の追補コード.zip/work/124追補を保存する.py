"""124金融後の独立checkerと保存器だけを小型ZIPへ保存する。金融再実行なし。"""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT=Path(__file__).resolve().parents[1]
FORMAL=ROOT/'study/00124_逆行の原因と売買反転を同じ入口で検証する'


def sha(data: bytes) -> str:
    """
    機能: 与えたbytesのSHA256を求める。
    引数: data(bytes)。返り値: strは小文字16進表記。
    """
    return hashlib.sha256(data).hexdigest()


# ----------------------------------------
def save(path: Path, value: dict) -> None:
    """
    機能: 未作成先へJSONの保存証跡を書く。
    引数: path(Path)、value(dict)。返り値: None。
    """
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')


# ----------------------------------------
def main() -> None:
    """
    機能: 独立検算コードと保存/文書化コードを保管し全entryを再読照合する。
    引数: なし。返り値: None。
    """
    frozen=FORMAL/'検査/再生前固定.json'
    assert sha(frozen.read_bytes())=='7fdfbf3b8ef9166d7bcaf0b5503a711f6a808dcba718e67c951fe627f71210d3'
    assert sha((FORMAL/'検査/独立検算.json').read_bytes())=='dd4754899cad43cbc97cb5fda9b1bbbdecdb0d36de0fc7037bf927c628b8e4d8'
    shutil.copy2(ROOT/'work/124入口の原因分析/説明用の二例.json',FORMAL/'根拠/説明用の二例.json')
    files=[ROOT/'work/124正逆の独立検算'/name for name in ('検算する.py','README.md','完了.json')]
    files.extend(ROOT/'work'/name for name in ('124結果を保管する.py','124正式文書を仕上げる.py','124追補を保存する.py'))
    before={str(p.relative_to(ROOT)).replace('\\','/'):p.read_bytes() for p in files}
    target=FORMAL/'再現資料/検算と保存の追補コード.zip'
    with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for name,data in sorted(before.items()):
            info=zipfile.ZipInfo(name,date_time=(2026,11,11,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED
            archive.writestr(info,data,compresslevel=9)
    entries=[]
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None
        for name,data in sorted(before.items()):
            assert archive.read(name)==data==(ROOT/name).read_bytes()
            entries.append({'entry':name,'restore_relative':name,'bytes':len(data),'SHA256':sha(data),'CRC32':f'{archive.getinfo(name).CRC:08x}'})
    value={'試行':124,'F1コード変更':False,'目的':'金融後の独立検算・保存・文書化。金融の再実行なし。',
           'zip':{'path':target.name,'bytes':target.stat().st_size,'SHA256':sha(target.read_bytes())},'entries':entries,
           '独立検算proof':{'path':'../検査/独立検算.json','SHA256':sha((FORMAL/'検査/独立検算.json').read_bytes())},
           '独立checker外部コード依存':False,'説明例':{'path':'../根拠/説明用の二例.json','SHA256':sha((FORMAL/'根拠/説明用の二例.json').read_bytes()),'用途':'最初の該当例の事後説明のみ。閾値/政策変更なし'}}
    save(FORMAL/'再現資料/追補コード復元索引.json',value)
    save(FORMAL/'検査/追補コード保管の確認.json',{'成功':True,'試行':124,'前後同体':True,'ZIP全entry再読':True,**value})
    print(json.dumps({'成功':True,'ZIP':value['zip'],'entry数':len(entries)},ensure_ascii=False))


if __name__=='__main__':
    main()
