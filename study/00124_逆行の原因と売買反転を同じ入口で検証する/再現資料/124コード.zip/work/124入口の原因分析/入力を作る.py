"""123の固定取得79件と73場の入力参照を、正逆の対比較用へ切り出す。"""
from pathlib import Path
from collections import Counter
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
OWN=Path(__file__).resolve().parent
SOURCES={
    ROOT/'work/123全場参加の入口比較/全73場の入口結果.json':'9823c9b3f257d97462f295e696b649d41a10ea538dd816490d70e60b34c4146f',
    ROOT/'work/122全場入力/入力.json':'6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec',
}


def digest(path: Path) -> str:
    """
    機能: ファイル全体のSHA256指紋を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 元の未取得を除外理由付きで保持し、取得時刻固定の小型入力を生成する。
    引数: なし。返り値: None。新しい勝敗や逆方向価格は計算しない。
    """
    assert all(digest(p)==s for p,s in SOURCES.items())
    original,source=[json.loads(p.read_text(encoding='utf-8')) for p in SOURCES]
    assert original['trial']==123 and original['success']
    assert len(original['scenes'])==len(source['scenes'])==73
    scenes=[]; paths=Counter(); missing=[]
    for result,scene in zip(original['scenes'],source['scenes']):
        assert result['success'] and result['session']==scene['session']
        assert result['actual_sha256']==scene['raw']['sha256']
        metadata={k:scene[k] for k in ('session','contract','start','end','force_close','raw','expected_accepted')}
        metadata['expected_quality']=result['quality']
        entries=[]
        for candidate in result['candidates']:
            if candidate['policy']!='P3':
                continue
            if candidate['entry'] is None:
                missing.append({'session':scene['session'],'id':candidate['birth']['id'],'status':candidate['status']})
                continue
            q=candidate['entry']; side=candidate['birth']['side']
            assert q['quote_ok'] and q['bid']>0 and q['ask']>q['bid']
            assert candidate['entry_price']==(q['ask'] if side==1 else q['bid'])
            entries.append({'id':candidate['birth']['id'],'side':side,'entry':q})
            paths[candidate['path']]+=1
        entries.sort(key=lambda e:(e['entry']['index'],e['id']))
        assert entries and len({e['id'] for e in entries})==len(entries)
        metadata['entries']=entries
        scenes.append(metadata)
    assert sum(len(s['entries']) for s in scenes)==79 and len(missing)==4
    result={'trial':124,'source_trial':123,'source_policy':'P3','source_sha256':list(SOURCES.values())[0],
            'scope':'既定取得の同時刻正逆対照。元の未取得4件を新しい約定としない。',
            'scenes':scenes,'source_unfilled':missing}
    path=OWN/'入力.json'
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    assert all(digest(p)==s for p,s in SOURCES.items())
    proof={'成功':True,'試行':124,'出典':{str(p):s for p,s in SOURCES.items()},'場数':73,'取得対数':79,
           '入口内訳':dict(paths),'元未取得':missing,'入力':{'path':str(path),'SHA256':digest(path),'bytes':path.stat().st_size},
           '勝敗による抽出':False,'公表全体の複写':False,'原板読取':False}
    with (OWN/'入力生成の確認.json').open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':
    main()
