"""124の正逆再生・当時の技術切替・集計条件を固定し、全73場へ適用する。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import subprocess

ROOT=Path(__file__).resolve().parents[2]
OWN=Path(__file__).resolve().parent
RUN=ROOT/'work/124入口の正逆比較'
FEATURES=ROOT/'work/124当時特徴の診断'
FORMAL=ROOT/'study/00124_逆行の原因と売買反転を同じ入口で検証する'


def sha(path: Path) -> str:
    """
    機能: ファイル全体のSHA256を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def save(path: Path, value: dict) -> None:
    """
    機能: 未作成の記録へUTF-8で保存する。
    引数: path(Path)、value(dict)。返り値: None。
    """
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')


# ----------------------------------------
def main() -> None:
    """
    機能: 固定後の同一入力・同一コードだけで正逆取得を再生する。
    引数: CLI --mode(str、固定又は実行)。返り値: None。
    """
    parser=argparse.ArgumentParser(description='124の事前固定と正逆再生')
    parser.add_argument('--mode',choices=('固定','実行'),required=True)
    mode=parser.parse_args().mode
    fixed=OWN/'再生前固定.json'
    if mode=='固定':
        input_path=OWN/'入力.json'
        assert sha(input_path)=='b2368b1f42c16e8c96a3acd098c58a902807a3b6a5023d6d4b1e75261f3ee51b'
        inputs=[input_path,FEATURES/'全79例の当時特徴.json',FEATURES/'T3追加の切替.json']
        assert sha(inputs[1])=='e4f0bf25156c1fe732b186c5c5d90b6e9f95718985a440d8eb7005588f734774'
        docs=[FORMAL/'README.md',FORMAL/'設定と結果.md',RUN/'README.md',FEATURES/'事前区分.md',FEATURES/'事前区分.json',FEATURES/'T3追加仕様.md']
        assert all(p.is_file() for p in inputs+docs)
        files=set()
        for folder in (OWN,RUN,FEATURES):
            files.update(p for p in folder.rglob('*') if p.is_file() and (p.suffix in ('.go','.py') or p.name=='go.mod'))
        exe=RUN/'入口比較.exe'
        assert exe.is_file()
        value={'試行':124,'成功':True,'固定UTC':datetime.now(timezone.utc).isoformat(),'主政策':'T1','主幅pt':125,'主時間秒':3600,
               '政策':['O0','R0','R1','R2','R3','T1','T2','T3'],'追加T3':'正逆結果を見る前の当時特徴監査から別specで追加、主T1/T2の閾値は不変',
               '価格軸':['実側BBO','Last純価格方向診断'],'IFD代用':'既知touchで即時気配清算、未到達completeのみ期限清算、他は未知。実IFDと区別。',
               '統計':'主125pt/60分C5の全73セッション復元抽出5000回seed124。探索内の参考区間、他政策・区分は多重比較未補正。',
               '入力':{str(p):sha(p) for p in inputs},'コード':{str(p):sha(p) for p in sorted(files)},'事前文書':{str(p):sha(p) for p in docs},
               '実行ファイル':{'path':str(exe),'sha256':sha(exe)},'未知データ検証':False,'実口座収支':False}
        save(fixed,value)
        print(json.dumps({'固定':True,'SHA256':sha(fixed),'コード数':len(files)},ensure_ascii=False))
        return
    # ----------------------------------------
    value=json.loads(fixed.read_text(encoding='utf-8'))
    expected={**value['入力'],**value['コード'],**value['事前文書']}
    exe=value['実行ファイル']; expected[exe['path']]=exe['sha256']
    assert all(sha(Path(p))==s for p,s in expected.items())
    input_path=OWN/'入力.json'
    output=RUN/'全73場の正逆結果.json'
    assert not output.exists()
    command=[exe['path'],'--input',str(input_path),'--sha256',sha(input_path),'--output',str(output),'--workers','8']
    subprocess.run(command,cwd=RUN,check=True)
    assert all(sha(Path(p))==s for p,s in expected.items())
    result=json.loads(output.read_text(encoding='utf-8'))
    assert result['success'] and result['trial']==124 and len(result['scenes'])==73
    assert all(s['success'] and s['cases'] for s in result['scenes'])
    assert sum(len(s['cases']) for s in result['scenes'])==79
    save(OWN/'再生完了.json',{'試行':124,'成功':True,'固定SHA256':sha(fixed),'入力コード文書前後同体':True,
                            '結果':{'path':str(output),'sha256':sha(output),'bytes':output.stat().st_size},'コマンド':command})
    print(json.dumps({'完了':True,'結果SHA256':sha(output)},ensure_ascii=False))


if __name__=='__main__':
    main()
