"""機能: 固定特徴だけで追加探索T3を計算し、人工鏡像と条件件数を保存する。

引数: コマンドライン引数なし。
返り値: なし。T3追加の切替.jsonと条件の診断.jsonを保存する。
"""

import ast
import hashlib
import json
from collections import Counter
from pathlib import Path


def sha(path: Path) -> str:
    """機能: ファイルのSHA256を求める。

    引数: path (Path) は対象ファイル。
    返り値: str は小文字16進表記。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def technical_choice(values: dict, side: int) -> dict:
    """機能: 価格位置と失速・拒否の2要素以上で元向きを切り替える。

    引数: values (dict[str,float | None]) は当時数値、side (int) は元向き。
    返り値: dict はside/action/reason/gatesを持つ固定T3票。
    """
    def test(key: str, predicate) -> bool | None:
        """機能: 一つの既知値を条件比較する。

        引数: key (str) は特徴名、predicate (callable) は判定。
        返り値: bool | None は成立又は未知。
        """
        return None if values[key] is None else predicate(values[key])

    waning_rsi = test("rsi_delta_signed_5", lambda x: x < 0)
    waning_hist = test("hist_delta_signed_5", lambda x: x < 0)
    wick = test("candle5_favorable_wick_ratio", lambda x: x >= .25)
    body = test("candle5_body_signed", lambda x: x < 0)
    rejection = True if wick is True or body is True else None if wick is None or body is None else False
    components = (waning_rsi, waning_hist, rejection)
    passed = sum(x is True for x in components)
    unknown = sum(x is None for x in components)
    two = True if passed >= 2 else False if passed + unknown < 2 else None
    extended = test("last_ema21_atr_signed_5", lambda x: x >= 1)
    current = test("last_close_signed_5", lambda x: x <= 0)
    flip = extended is True and current is True and two is True
    return {"side": -side if flip else side, "action": "flip" if flip else "keep",
            "reason": "過伸長と現在の押戻しに失速/拒否2要素以上" if flip else "固定した複合条件の成立を確認できない",
            "gates": {"extended_at_least_1atr": extended, "current_last_not_above_close_in_original_side": current,
                      "rsi_delta_waning": waning_rsi, "hist_delta_waning": waning_hist,
                      "candle_rejection": rejection, "two_or_more": two,
                      "known_pass_count": passed, "unknown_count": unknown}}


# ----------------------------------------
BASE = Path(__file__).resolve().parent
FEATURES = BASE / "全79例の当時特徴.json"
SPEC = BASE / "T3追加仕様.md"
FIXED = {FEATURES: "e4f0bf25156c1fe732b186c5c5d90b6e9f95718985a440d8eb7005588f734774",
         BASE / "事前区分.md": "2d4d816fdd5c38c5800db214fc677f800eecf57b9cdba0537277b99892ad247a",
         BASE / "事前区分.json": "a639902cf761a4517a5e946cefc93f81b30c815c7f3be5bd96da7af57277d7a1"}
BEFORE = {str(p): sha(p) for p in (*FIXED, SPEC, Path(__file__).resolve())}
assert all(BEFORE[str(p)] == h for p, h in FIXED.items())
source = json.loads(FEATURES.read_text(encoding="utf-8"))
assert source["success"] and source["row_count"] == 79 and not source["source_outcomes_used"]
rows = []
for row in source["features"]:
    values = {k: v["value"] if v["known"] else None for k, v in row["features"].items()}
    assert all(v["known"] == (v["value"] is not None) for v in row["features"].values())
    choice = technical_choice(values, row["original_side"])
    rows.append({"session": row["session"], "id": row["id"], "original_side": row["original_side"],
                 "strategy": row["strategy"], "choices": {"T3": choice}})
assert len(rows) == len({r["id"] for r in rows}) == 79

# ----------------------------------------
sample = {"last_ema21_atr_signed_5": 1, "last_close_signed_5": 0,
          "rsi_delta_signed_5": -1, "hist_delta_signed_5": -1,
          "candle5_favorable_wick_ratio": 0, "candle5_body_signed": 1}
assert technical_choice(sample, 1)["side"] == -1
assert technical_choice(sample, -1)["side"] == 1
for key, value in (("last_ema21_atr_signed_5", .999), ("last_close_signed_5", .001),
                   ("last_ema21_atr_signed_5", None), ("rsi_delta_signed_5", None)):
    changed = dict(sample)
    changed[key] = value
    assert technical_choice(changed, 1)["action"] == "keep", key
changed = dict(sample)
changed["hist_delta_signed_5"] = None
changed["candle5_favorable_wick_ratio"] = .25
assert technical_choice(changed, 1)["action"] == "flip"
changed["rsi_delta_signed_5"] = 0
assert technical_choice(changed, 1)["action"] == "keep"
for row in source["features"]:
    values = {k: v["value"] if v["known"] else None for k, v in row["features"].items()}
    # 元向きで正規化した特徴は、価格反射と売買反転で不変。
    a = technical_choice(values, row["original_side"])
    b = technical_choice(values, -row["original_side"])
    assert a["side"] == -b["side"] and a["action"] == b["action"] and a["gates"] == b["gates"]

# ----------------------------------------
diagnosis = {"成功": True, "勝敗使用": False, "新正逆結果読取": False,
             "T1": {}, "T2": {}, "T3": {}, "構造的な制約": [
                 "通常trend入口は元向きHist>0、RSI中心>=0、M>0を要求する。RSIΔとHistΔが両方逆なら4票のMは最大0となり、同じ票でT2には入れない。",
                 "通常reversal入口は元向きRSIΔ/HistΔ両方>0を要求するため、同じ票の両方<0を求めるT2は成立しない。",
                 "T1の上位整合と勢い・量が成立しても、元向きが既に同じならkeepとなる。条件成立数とflip数を区別する。",
                 "T3は失速2項又は失速1項＋拒否であり、通常trendとの論理的排他を緩める追加探索。元条件T1/T2は変更しない。"]}
for name in ("T1", "T2"):
    fixed_rows = [r["choices"][name] for r in source["features"]]
    diagnosis[name] = {
        "全例action": dict(Counter(r["action"] for r in fixed_rows)),
        "gate別": {k: dict(Counter(str(r["gates"][k]) for r in fixed_rows)) for k in fixed_rows[0]["gates"]},
        "モード別": {mode: {"件数": len(group), "action": dict(Counter(r["choices"][name]["action"] for r in group))}
                     for mode in ("E0", "trend", "reversal", "deadline")
                     if (group := [r for r in source["features"] if r["strategy"] == mode])}}
diagnosis["T3"] = {"全例action": dict(Counter(r["choices"]["T3"]["action"] for r in rows)),
                   "gate別": {k: dict(Counter(str(r["choices"]["T3"]["gates"][k]) for r in rows)) for k in rows[0]["choices"]["T3"]["gates"]},
                   "モード別": {mode: dict(Counter(r["choices"]["T3"]["action"] for r in rows if r["strategy"] == mode))
                                for mode in ("E0", "trend", "reversal", "deadline")}}
AFTER = {str(p): sha(p) for p in (*FIXED, SPEC, Path(__file__).resolve())}
assert BEFORE == AFTER
output = {"success": True, "trial": 124, "additional_exploration": True, "primary_changed": False,
          "source_features_sha256": BEFORE[str(FEATURES)], "spec_sha256": BEFORE[str(SPEC)],
          "row_count": len(rows), "choices": [{"session": r["session"], "id": r["id"], "T3": r["choices"]["T3"]} for r in rows],
          "source_outcomes_used": False, "new_direction_results_read": False}
OUT = BASE / "T3追加の切替.json"
OUT.write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
diagnosis.update({"前SHA256": BEFORE, "後SHA256": AFTER, "前後不変": True,
                  "T3choicesSHA256": sha(OUT), "人工検査": "反射鏡像/価格と時点境界/未知/既知0/2成立なら残る未知を許容/79票の符号鏡像"})
(BASE / "条件の診断.json").write_text(json.dumps(diagnosis, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"成功": True, "T3": diagnosis["T3"], "T3choicesSHA256": sha(OUT)}, ensure_ascii=False))
