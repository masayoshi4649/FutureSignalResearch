"""機能: 市場結果を開かず、切替・未知・境界・買売鏡像を検査する。

引数: コマンドライン引数なし。
返り値: なし。人工検査.jsonを保存する。不整合はAssertionError。
"""

import ast
import hashlib
import json
from pathlib import Path


def sha(path: Path) -> str:
    """機能: コードのSHA256を求める。

    引数: path (Path) は対象コード。
    返り値: str はSHA256の16進表記。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fixture() -> dict:
    """機能: 条件が未成立の人工特徴を作る。

    引数: なし。
    返り値: dict は市場価格を含まない人工票。
    """
    return {
        "gap_15": 0, "ema8_delta_15": 0, "ema21_delta_15": 0,
        "gap_30": 0, "ema8_delta_30": 0, "ema21_delta_30": 0,
        "rsi_delta_5": 0, "hist_delta_5": 0, "rvol5": 1,
        "candle5_favorable_wick_ratio": 0, "candle5_body_signed": 0,
        "adx_delta_5": 0, "adx_delta_30": None,
        "last_ema21_atr_signed_5": 0, "rsi_center_signed_5": 0,
        "rsi_delta_signed_5": 0, "hist_delta_signed_5": 0,
        "last_close_signed_5": 0,
    }


def mirror(features: dict) -> dict:
    """機能: 人工票を価格反射・売買反転する。

    引数: features (dict) は当時票。
    返り値: dict は元向き符号付き値を維持し、生の方向値だけ反転した票。
    """
    result = dict(features)
    for key in ("gap_15", "ema8_delta_15", "ema21_delta_15",
                "gap_30", "ema8_delta_30", "ema21_delta_30", "rsi_delta_5", "hist_delta_5"):
        if result[key] is not None:
            result[key] = -result[key]
    return result


# ----------------------------------------
BASE = Path(__file__).resolve().parent
SOURCE = BASE / "特徴を抽出する.py"
BEFORE = {str(p): sha(p) for p in (SOURCE, Path(__file__).resolve())}
tree = ast.parse(SOURCE.read_text(encoding="utf-8"), filename=str(SOURCE))
safe = ast.Module(body=[node for node in tree.body if isinstance(node, (ast.Import, ast.ImportFrom, ast.FunctionDef))], type_ignores=[])
scope = {}
exec(compile(safe, str(SOURCE), "exec"), scope)
choose = scope["choices"]
tests = []

a = fixture()
for key in ("gap_15", "ema8_delta_15", "ema21_delta_15", "gap_30", "ema8_delta_30", "ema21_delta_30"):
    a[key] = -1
a["rsi_delta_5"], a["hist_delta_5"], a["rvol5"] = -2, -1, 1
x = choose(a, 1, False)
y = choose(mirror(a), -1, False)
assert x["T1"]["side"] == -1 and x["T1"]["action"] == "flip"
assert y["T1"]["side"] == 1 and y["T1"]["action"] == "flip"
assert choose(a, 1, True)["T1"]["side"] == 1
assert choose(a, 1, None)["T1"]["side"] == 1
tests.append("T1長中期と勢い・量/鏡像/回復例外/回復未知")

b = dict(a)
b["gap_30"] = None
assert choose(b, 1, False)["T1"]["action"] == "keep"
b = dict(a)
b["rvol5"] = None
assert choose(b, 1, False)["T1"]["action"] == "keep"
tests.append("T1長期と量の未知を0支持へ置換しない")

c = fixture()
c.update({"last_ema21_atr_signed_5": 1, "rsi_center_signed_5": 15,
          "rsi_delta_signed_5": -1, "hist_delta_signed_5": -1,
          "candle5_favorable_wick_ratio": .25, "adx_delta_5": -.1,
          "last_close_signed_5": 0})
x, y = choose(c, 1, False), choose(mirror(c), -1, False)
assert x["T2"]["side"] == -1 and y["T2"]["side"] == 1
assert x["T2"]["action"] == y["T2"]["action"] == "flip"
for key, value in (("last_ema21_atr_signed_5", .999), ("rsi_center_signed_5", 14.999),
                   ("rsi_delta_signed_5", 0), ("rvol5", None), ("last_close_signed_5", .001)):
    changed = dict(c)
    changed[key] = value
    assert choose(changed, 1, False)["T2"]["action"] == "keep", key
tests.append("T2複合反転/鏡像/包含境界/厳密減速/未知保持/現在位置")

assert scope["number"]({"known": False, "value": 999}) is None
assert scope["number"]({"known": True, "value": 0}) == 0
assert scope["bin_value"](None, [-1, 0, 1]) == "unknown"
assert scope["bin_value"](0, [-1, 0, 1]) == "zero"
assert scope["bin_value"](1, [-1, 0, 1]) == "[1,inf)"
assert scope["all_true"](True, None) is None
assert scope["all_true"](False, None) is False
assert scope["any_true"](True, None) is True
assert scope["common_direction"]([1, 0, 1]) == 0
assert scope["common_direction"]([1, None, 1]) is None
tests.append("既知0/未知/区分境界/三値論理/同向の区別")

ohlc = {"open": 100, "high": 120, "low": 90, "close": 110}
reflected = {"open": 900, "high": 910, "low": 880, "close": 890}
assert scope["candle_features"](ohlc, 1, 20) == scope["candle_features"](reflected, -1, 20)
zero_range = scope["candle_features"]({"open": 100, "high": 100, "low": 100, "close": 100}, 1, 20)
assert zero_range["close_location_signed"] is None and zero_range["body_signed_ratio"] is None
tests.append("価格反射の実体/ヒゲ/終値位置/値幅0")

after = {str(p): sha(p) for p in (SOURCE, Path(__file__).resolve())}
assert BEFORE == after
output = {"成功": True, "試行": 124, "検査": tests, "市場結果読取": False,
          "前SHA256": BEFORE, "後SHA256": after, "前後不変": True}
(BASE / "人工検査.json").write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"成功": True, "主検査数": len(tests)}, ensure_ascii=False))
