"""機能: 固定公表を出生時の参照へ結合し、勝敗を読まず当時特徴と向きを保存する。

引数: コマンドライン引数なし。固定した123結果・122入力・事前区分を使う。
返り値: なし。全79例の当時特徴.jsonと抽出確認.jsonを作成する。
"""

import hashlib
import json
import math
from collections import Counter
from datetime import datetime, timedelta, timezone
from pathlib import Path


def sha(path: Path) -> str:
    """機能: ファイルのSHA256を求める。

    引数: path (Path) は対象ファイル。
    返り値: str は小文字16進表記。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical_sha(value: dict) -> str:
    """機能: 公表辞書の正規化JSON指紋を求める。

    引数: value (dict) は原入力から結合した公表。
    返り値: str はキー順整列・UTF-8・空白なしJSONのSHA256。
    """
    data = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


def number(value: dict | None) -> float | None:
    """機能: 既知の有限値だけを取り出す。

    引数: value (dict | None) はknown/value形式の保存票。
    返り値: float | None は既知値又は未知。
    """
    if not value or not value.get("known"):
        return None
    v = value["value"]
    assert isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)
    return v


def calc(function, *values: float | None) -> float | None:
    """機能: 全て既知の場合だけ計算する。

    引数: function (callable) は計算式、values (float | None) は各値。
    返り値: float | None は有限の計算結果又は未知。
    """
    if any(v is None for v in values):
        return None
    value = function(*values)
    assert math.isfinite(value)
    return value


def ratio(a: float | None, b: float | None) -> float | None:
    """機能: 正の分母でだけ比率を計算する。

    引数: a/b (float | None) は分子と分母。
    返り値: float | None は比率又は未知。
    """
    return a / b if a is not None and b is not None and b > 0 else None


def sign(value: float | None) -> int | None:
    """機能: 未知を維持して符号を求める。

    引数: value (float | None) は数値。
    返り値: int | None は−1/0/1又は未知。
    """
    return None if value is None else (1 if value > 0 else -1 if value < 0 else 0)


def all_true(*values: bool | None) -> bool | None:
    """機能: 未知を含む論理積を求める。

    引数: values (bool | None) は各条件。
    返り値: bool | None は偽優先・全真・未解決の区別。
    """
    if False in values:
        return False
    return None if None in values else True


def any_true(*values: bool | None) -> bool | None:
    """機能: 未知を含む論理和を求める。

    引数: values (bool | None) は各条件。
    返り値: bool | None は真優先・全偽・未解決の区別。
    """
    if True in values:
        return True
    return None if None in values else False


def compare(value: float | None, op, bound: float = 0) -> bool | None:
    """機能: 既知の値だけを条件比較する。

    引数: value (float | None)、op (callable)、bound (float) は値・演算・境界。
    返り値: bool | None は条件成立又は未知。
    """
    return None if value is None else op(value, bound)


def common_direction(values: list[float | None]) -> int | None:
    """機能: 全既知・全同符号の方向を求める。

    引数: values (list[float | None]) はMA並び等の票。
    返り値: int | None は同符号の±1、混在/0の0、欠測のNone。
    """
    if any(v is None for v in values):
        return None
    signs = {sign(v) for v in values}
    return next(iter(signs)) if len(signs) == 1 and 0 not in signs else 0


def check_value(saved: dict | None, expected: float | None) -> None:
    """機能: 元の保存成分と結合公表の数値を照合する。

    引数: saved (dict | None) は保存票、expected (float | None) は結合値。
    返り値: None。不整合はAssertionError。
    """
    actual = number(saved)
    assert (actual is None) == (expected is None), (saved, expected)
    if expected is not None:
        assert math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-9), (actual, expected)


def candle_features(ohlc: dict, side: int, atr: float | None) -> dict:
    """機能: 足の実体・ヒゲ・終値位置を売買対称に分解する。

    引数: ohlc (dict) は確定足、side (int) は元向き、atr (float | None) は5分ATR。
    返り値: dict は数値又は未知の足特徴。
    """
    o, h, l, c = (ohlc[k] for k in ("open", "high", "low", "close"))
    assert l <= min(o, c) <= max(o, c) <= h
    span = h - l
    upper, lower = h - max(o, c), min(o, c) - l
    return {
        "range": span,
        "range_atr5": ratio(span, atr),
        "body_signed": side * (c - o),
        "body_signed_ratio": ratio(side * (c - o), span),
        "close_location_signed": ratio(c - l if side > 0 else h - c, span),
        "favorable_wick_ratio": ratio(upper if side > 0 else lower, span),
        "adverse_wick_ratio": ratio(lower if side > 0 else upper, span),
    }


def bin_value(value: float | None, edges: list[float]) -> str:
    """機能: 固定境界で特徴を区分する。

    引数: value (float | None) は数値、edges (list[float]) は昇順境界。
    返り値: str は区分。未知・既知0は専用区分。
    """
    if value is None:
        return "unknown"
    if value == 0:
        return "zero"
    for i, upper in enumerate(edges):
        if value < upper:
            return f"[{edges[i-1] if i else '-inf'},{upper})"
    return f"[{edges[-1]},inf)"


def alignment(values: list[int | None], side: int) -> str:
    """機能: 三時間軸の全同向・対立・未成熟を区分する。

    引数: values (list[int | None]) は5/15/30の方向、side (int) は元向き。
    返り値: str は全支持/全逆/混在/部分既知/全未知。
    """
    known = [v for v in values if v is not None]
    if not known:
        return "all_unknown"
    if len(known) < len(values):
        return "partial_opposition" if any(v * side < 0 for v in known) else "partial_no_opposition"
    if all(v == side for v in known):
        return "all_support"
    if all(v == -side for v in known):
        return "all_opposite"
    return "mixed_or_neutral"


def choices(features: dict, side: int, recovery: bool | None) -> dict:
    """機能: 事前固定した二つの複合切替を計算する。

    引数: features (dict) は当時数値、side (int) は元向き、recovery (bool | None) は回復反転。
    返り値: dict はT1/T2の全例keep/flipと条件票。
    """
    bg = common_direction([features[k] for k in (
        "gap_15", "ema8_delta_15", "ema21_delta_15", "gap_30", "ema8_delta_30", "ema21_delta_30"
    )])
    bg_momentum = all_true(
        compare(calc(lambda x: bg * x, features["rsi_delta_5"]) if bg else None, lambda a, b: a > b),
        compare(calc(lambda x: bg * x, features["hist_delta_5"]) if bg else None, lambda a, b: a > b),
        compare(features["rvol5"], lambda a, b: a >= b, 1),
    )
    chosen = side
    reason = "長中期・勢い・量の複合条件が未成立"
    if recovery is True:
        reason = "確認済み失敗突破の回復を維持"
    elif recovery is None:
        reason = "回復構造の必要値が未解決のため維持"
    elif bg in (-1, 1) and bg_momentum is True:
        chosen, reason = bg, "長中期MA三条件の整合と5分勢い・量を採用"
    t1 = {"side": chosen, "action": "keep" if chosen == side else "flip", "reason": reason,
          "gates": {"background_direction": bg, "background_momentum_volume": bg_momentum,
                    "confirmed_recovery": recovery}}

    rejection = any_true(
        compare(features["candle5_favorable_wick_ratio"], lambda a, b: a >= b, .25),
        compare(features["candle5_body_signed"], lambda a, b: a < b),
    )
    adx_falling = any_true(
        compare(features["adx_delta_5"], lambda a, b: a < b),
        compare(features["adx_delta_30"], lambda a, b: a < b),
    )
    gates = {
        "extended_at_least_1atr": compare(features["last_ema21_atr_signed_5"], lambda a, b: a >= b, 1),
        "rsi_side_center_at_least_15": compare(features["rsi_center_signed_5"], lambda a, b: a >= b, 15),
        "rsi_delta_waning": compare(features["rsi_delta_signed_5"], lambda a, b: a < b),
        "hist_delta_waning": compare(features["hist_delta_signed_5"], lambda a, b: a < b),
        "candle_rejection": rejection,
        "current_last_not_above_close_in_original_side": compare(features["last_close_signed_5"], lambda a, b: a <= b),
        "adx_falling_5_or_30": adx_falling,
        "volume_ge_1": compare(features["rvol5"], lambda a, b: a >= b, 1),
    }
    flip = all_true(*gates.values())
    t2 = {"side": -side if flip is True else side, "action": "flip" if flip is True else "keep",
          "reason": "過伸長・失速・拒否・ADX低下・量が全成立" if flip is True else "反転の複合条件が未成立又は未知",
          "gates": gates}
    return {"T1": t1, "T2": t2}


def extract_scene(scene: dict, input_scene: dict, counts: Counter) -> list[dict]:
    """機能: 一場の取得済みP3から当時特徴だけを取り出す。

    引数: scene (dict) は123結果、input_scene (dict) は固定公表入力、counts (Counter) は検査数。
    返り値: list[dict] は勝敗を含まない特徴票。
    """
    assert scene["session"] == input_scene["session"]
    publications = {p["frame"]["frame"]["id"]: p for p in input_scene["publications"]}
    assert len(publications) == len(input_scene["publications"])
    result = []
    for candidate in scene["candidates"]:
        if candidate["policy"] != "P3" or candidate["status"] != "filled":
            continue
        c = candidate
        birth, side = c["birth"], c["birth"]["side"]
        q, entry = birth["quote"], c["entry"]
        assert side in (-1, 1) and c["entry_price"] == (entry["ask"] if side > 0 else entry["bid"])
        d = c.get("decision")
        event = scene["events"][c["event"]] if c["path"] == "E0" else None
        source_refs = event["refs"] if event else d["refs"]
        components = d["components"] if d else {}
        fields = event["fields"] if event else {}
        joined, refs = {}, []
        for ref in source_refs:
            p = publications[ref["id"]]
            f, stamp = p["frame"]["frame"], p["stamp"]
            assert ref == {"id": f["id"], "width_seconds": f["width_seconds"], "end": f["end"], "delivered": stamp}
            assert f["session_id"] == scene["session"] and f["contract"] == input_scene["contract"]
            assert f["start"] <= f["end"] <= f["available_at"] <= f["delivery_at"] <= stamp["time"] <= q["time"]
            assert stamp["index"] <= q["index"] and stamp["source_line"] <= q["source_line"]
            assert q["time"] < f["end"] + f["width_seconds"] + 60
            assert f["width_seconds"] not in joined
            joined[f["width_seconds"]] = p
            child_inputs = {(ch["input"]["path"], ch["input"]["sha256"], ch["input"]["bytes"])
                            for ch in f["children"] if ch.get("present") and ch["input"]["path"]}
            refs.append({**ref, "publication_sha256": canonical_sha(p),
                         "publication_sha256_encoding": "UTF-8・キー整列・空白なしJSON",
                         "available_at": f["available_at"], "delivery_at": f["delivery_at"],
                         "price_known": f["price_known"], "age_from_end_seconds": q["time"] - f["end"],
                         "child_inputs": [{"path": a, "sha256": b, "bytes": z} for a, b, z in sorted(child_inputs)]})
            counts["全項目参照結合"] += 1
        assert 300 in joined and joined[300]["frame"]["frame"]["price_known"]

        values = {}
        for width in (300, 900, 1800):
            suffix = str(width // 60)
            p = joined.get(width)
            known_price = bool(p and p["frame"]["frame"]["price_known"])
            t = p["frame"]["frame"]["technical"] if known_price else {}
            di = p["frame"]["dmi"] if known_price else {}
            for target, key in (("ema8", "ema8"), ("ema21", "ema21"), ("gap", "gap"),
                                ("ema8_delta", "ema8_delta"), ("ema21_delta", "ema21_delta"),
                                ("atr", "atr"), ("previous_atr", "previous_atr"), ("tr", "tr"),
                                ("rsi", "rsi"), ("previous_rsi", "previous_rsi"),
                                ("hist", "histogram"), ("previous_hist", "previous_histogram")):
                values[f"{target}_{suffix}"] = number(t.get(key))
            for key in ("plus_di", "minus_di", "adx", "previous_adx"):
                values[f"{key}_{suffix}"] = number(di.get(key))
            for now, prev, out in (("rsi", "previous_rsi", "rsi_delta"),
                                   ("hist", "previous_hist", "hist_delta"),
                                   ("adx", "previous_adx", "adx_delta"),
                                   ("plus_di", "minus_di", "di_delta")):
                values[f"{out}_{suffix}"] = calc(lambda a, b: a - b, values[f"{now}_{suffix}"], values[f"{prev}_{suffix}"])
            atr = values[f"atr_{suffix}"]
            values[f"rsi_center_signed_{suffix}"] = calc(lambda x: side * (x - 50), values[f"rsi_{suffix}"])
            for name in ("gap", "ema8_delta", "ema21_delta", "di_delta", "rsi_delta", "hist", "hist_delta"):
                raw = values[f"{name}_{suffix}"]
                values[f"{name}_signed_{suffix}"] = calc(lambda x: side * x, raw)
                values[f"{name}_atr_signed_{suffix}"] = ratio(values[f"{name}_signed_{suffix}"], atr)
            for ema in ("ema8", "ema21"):
                dist = calc(lambda x: side * (q["last"] - x), values[f"{ema}_{suffix}"])
                values[f"last_{ema}_signed_{suffix}"] = dist
                values[f"last_{ema}_atr_signed_{suffix}"] = ratio(dist, atr)
            values[f"tr_previous_atr_ratio_{suffix}"] = ratio(values[f"tr_{suffix}"], values[f"previous_atr_{suffix}"])
            terms = [values[f"{key}_{suffix}"] for key in ("gap", "ema8_delta", "ema21_delta", "di_delta")]
            signs = [sign(v) for v in terms if v is not None]
            values[f"trend_known_count_{suffix}"] = len(signs)
            values[f"trend_support_count_{suffix}"] = sum(v == side for v in signs)
            values[f"trend_opposite_count_{suffix}"] = sum(v == -side for v in signs)
            values[f"trend_neutral_count_{suffix}"] = sum(v == 0 for v in signs)
            values[f"trend_T_{suffix}"] = sum(signs) / len(signs) if signs else None
            values[f"ma_direction_{suffix}"] = common_direction(terms[:3])
            values[f"four_vote_direction_{suffix}"] = common_direction(terms)
            if d and known_price:
                for key in ("gap", "ema8_delta", "ema21_delta", "di_delta"):
                    check_value(components.get(f"{suffix}_{key}"), values[f"{key}_{suffix}"])
                    counts["保存方向成分照合"] += 1

        t5 = joined[300]["frame"]["frame"]
        atr5 = values["atr_5"]
        assert atr5 is not None and atr5 > 0 and c["atr5"] == atr5
        for key, value in candle_features(t5["ohlc"], side, atr5).items():
            values[f"candle5_{key}"] = value
        c5 = t5["ohlc"]["close"]
        values["last_close_signed_5"] = side * (q["last"] - c5)
        values["last_close_atr_signed_5"] = ratio(values["last_close_signed_5"], atr5)
        values["birth_spread"] = q["ask"] - q["bid"] if q["quote_ok"] and 0 < q["bid"] <= q["ask"] else None
        values["entry_spread"] = entry["ask"] - entry["bid"]
        values["entry_initial_liquidation_points"] = -values["entry_spread"]
        values["birth_fill_delay_seconds"] = entry["time"] - q["time"]
        values["entry_last_change_signed"] = side * (entry["last"] - q["last"])
        values["entry_price_from_birth_last_signed"] = side * (c["entry_price"] - q["last"])
        values["entry_price_from_entry_last_signed"] = side * (c["entry_price"] - entry["last"])
        values["entry_price_from_c5_atr_signed"] = ratio(side * (c["entry_price"] - c5), atr5)
        values["elapsed_minutes"] = (q["time"] - input_scene["start"]) / 60
        for w in (25, 50, 100, 125, 200):
            values[f"birth_spread_over_width_{w}"] = ratio(values["birth_spread"], w)
            values[f"entry_spread_over_width_{w}"] = values["entry_spread"] / w
        values["rvol5"] = number(fields.get("rvol5") if event else components.get("RVOL5"))
        source_ohlc = event["bar"]["ohlc"] if event else t5["ohlc"]
        values["source_candle_width"] = 60 if event else 300
        for key, value in candle_features(source_ohlc, side, atr5).items():
            values[f"source_candle_{key}"] = value
        values["source_candle_age_seconds"] = q["time"] - (event["bar"]["end"] if event else t5["end"])

        if d:
            for saved, expected in (("RSI5", "rsi_5"), ("previous_RSI5", "previous_rsi_5"),
                                    ("Hist5", "hist_5"), ("previous_Hist5", "previous_hist_5"),
                                    ("ATR5", "atr_5"), ("previous_ATR5", "previous_atr_5"), ("TR5", "tr_5")):
                check_value(components.get(saved), values[expected])
                counts["保存5分技術照合"] += 1
            values["score"] = number(d["score"])
            values["prior3_high_5"] = number(components.get("prior3_high"))
            values["prior3_low_5"] = number(components.get("prior3_low"))
            structure_refs = d.get("structure_refs", [])
            for ref in structure_refs:
                p = publications[ref["id"]]
                f, stamp = p["frame"]["frame"], p["stamp"]
                assert ref == {"id": f["id"], "width_seconds": f["width_seconds"], "end": f["end"], "delivered": stamp}
                assert f["session_id"] == scene["session"] and f["contract"] == input_scene["contract"]
                assert stamp["time"] <= q["time"] and stamp["index"] <= q["index"] and stamp["source_line"] <= q["source_line"]
                counts["構造参照結合"] += 1
            if values["prior3_high_5"] is not None or values["prior3_low_5"] is not None:
                fs = [publications[r["id"]]["frame"]["frame"] for r in structure_refs]
                assert len(fs) == 3 and all(f["price_known"] and f["width_seconds"] == 300 for f in fs)
                assert all(a["end"] == b["start"] for a, b in zip(fs, fs[1:])) and fs[-1]["end"] == t5["start"]
                assert values["prior3_high_5"] == max(f["ohlc"]["high"] for f in fs)
                assert values["prior3_low_5"] == min(f["ohlc"]["low"] for f in fs)
            broken = values["prior3_low_5"] if side > 0 else values["prior3_high_5"]
            extreme = t5["ohlc"]["low"] if side > 0 else t5["ohlc"]["high"]
            recovered_structure = all_true(
                compare(calc(lambda x: side * (extreme - x), broken), lambda a, b: a < b),
                compare(calc(lambda x: side * (c5 - x), broken), lambda a, b: a >= b, 5),
                compare(calc(lambda x: side * (q["last"] - x), broken), lambda a, b: a >= b, 5),
                None if values["prior3_low_5"] is None or values["prior3_high_5"] is None else values["prior3_low_5"] <= c5 <= values["prior3_high_5"],
                compare(calc(lambda x: side * (x - 50), values["previous_rsi_5"]), lambda a, b: a <= b, -15),
                compare(values["adx_delta_5"], lambda a, b: a < b),
                compare(values["tr_previous_atr_ratio_5"], lambda a, b: a <= b, 2),
            )
        else:
            for saved, expected in (("rsi5", "rsi_5"), ("previous_rsi5", "previous_rsi_5"),
                                    ("hist5", "hist_5"), ("previous_hist5", "previous_hist_5"),
                                    ("atr5", "atr_5"), ("rsi15", "rsi_15"), ("adx30", "adx_30"),
                                    ("gap30", "gap_30"), ("ema8_delta30", "ema8_delta_30"), ("ema21_delta30", "ema21_delta_30")):
                check_value(fields.get(saved), values[expected])
                counts["保存E0技術照合"] += 1
            extreme = event["bar"]["ohlc"]["low"] if side > 0 else event["bar"]["ohlc"]["high"]
            check_value(fields.get("extreme_ema21_5_signed"), side * (extreme - values["ema21_5"]))
            values["score"] = None
            values["prior3_high_5"] = values["prior3_low_5"] = None
            structure_refs = []
            recovered_structure = all_true(
                compare(number(fields.get("recovered_structure")), lambda a, b: a == b, 1),
                compare(number(fields.get("hold_pass")), lambda a, b: a == b, 1),
                compare(values["adx_delta_30"], lambda a, b: a < b),
            )
        recovery = all_true(recovered_structure,
                            compare(values["rsi_delta_signed_5"], lambda a, b: a > b),
                            compare(values["hist_delta_signed_5"], lambda a, b: a > b),
                            compare(values["rvol5"], lambda a, b: a >= b, 1))
        values["prior3_range_atr5"] = ratio(calc(lambda h, l: h - l, values["prior3_high_5"], values["prior3_low_5"]), atr5)
        decisions = choices(values, side, recovery)
        bins = {v["feature"]: bin_value(values.get(v["feature"]), v["edges"]) for v in BIN_DEFINITION["bins"]}
        bins.update({
            "ma_5_15_30_alignment": alignment([values[f"ma_direction_{s}"] for s in (5, 15, 30)], side),
            "four_vote_5_15_30_alignment": alignment([values[f"four_vote_direction_{s}"] for s in (5, 15, 30)], side),
            "strategy": "E0" if event else d["strategy"], "daynight": scene["session"].rsplit("_", 1)[1],
            "side": "buy" if side > 0 else "sell", "source_candle_width": str(values["source_candle_width"]),
        })
        result.append({"session": scene["session"], "id": birth["id"], "cohort_id": c["cohort_id"],
                       "original_side": side, "strategy": bins["strategy"], "path": c["path"],
                       "birth": {k: birth[k] for k in ("time", "index", "source_line")},
                       "birth_clock": datetime.fromtimestamp(q["time"], timezone(timedelta(hours=9))).isoformat(),
                       "birth_quote": q, "entry_quote": entry, "entry_price": c["entry_price"],
                       "features": {k: {"known": v is not None, "value": v} for k, v in values.items()},
                       "bins": bins, "choices": decisions, "refs": refs, "structure_refs": structure_refs,
                       "recovery": {"known": recovery is not None, "pass": recovery, "source_width": values["source_candle_width"]},
                       "rvol_source": "event.fields.rvol5" if event else "decision.components.RVOL5"})
    return result


# ----------------------------------------
BASE = Path(__file__).resolve().parent
ROOT = BASE.parent.parent
RESULT = ROOT / "work/123全場参加の入口比較/全73場の入口結果.json"
INPUT = ROOT / "work/122全場入力/入力.json"
BINS = BASE / "事前区分.json"
MD = BASE / "事前区分.md"
EXPECTED = {RESULT: "9823c9b3f257d97462f295e696b649d41a10ea538dd816490d70e60b34c4146f",
            INPUT: "6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec",
            BINS: "a639902cf761a4517a5e946cefc93f81b30c815c7f3be5bd96da7af57277d7a1",
            MD: "2d4d816fdd5c38c5800db214fc677f800eecf57b9cdba0537277b99892ad247a"}
BEFORE = {str(p): sha(p) for p in (*EXPECTED, Path(__file__).resolve())}
assert all(BEFORE[str(p)] == h for p, h in EXPECTED.items())
BIN_DEFINITION = json.loads(BINS.read_text(encoding="utf-8-sig"))
assert BIN_DEFINITION["md_sha256"] == BEFORE[str(MD)]
source = json.loads(RESULT.read_bytes())
publications_input = json.loads(INPUT.read_bytes())
assert source["input_sha256"] == BEFORE[str(INPUT)]
assert source["scene_count"] == len(source["scenes"]) == len(publications_input["scenes"]) == 73
assert [s["session"] for s in source["scenes"]] == [s["session"] for s in publications_input["scenes"]]
COUNTS = Counter()
ROWS = []
for SCENE, INPUT_SCENE in zip(source["scenes"], publications_input["scenes"]):
    ROWS.extend(extract_scene(SCENE, INPUT_SCENE, COUNTS))
assert len(ROWS) == len({r["id"] for r in ROWS}) == 79
assert len({r["session"] for r in ROWS}) == 73
assert Counter(r["strategy"] for r in ROWS) == {"E0": 9, "trend": 31, "reversal": 1, "deadline": 38}
assert all(r["choices"][s]["side"] in (-1, 1) for r in ROWS for s in ("T1", "T2"))
AFTER = {str(p): sha(p) for p in (*EXPECTED, Path(__file__).resolve())}
assert BEFORE == AFTER
output = {"success": True, "trial": 124, "source_sha256": BEFORE[str(RESULT)],
          "input_sha256": BEFORE[str(INPUT)], "bin_sha256": BEFORE[str(BINS)],
          "source_outcomes_used": False, "new_direction_results_read": False,
          "row_count": len(ROWS), "scene_count": 73, "features": ROWS}
OUT = BASE / "全79例の当時特徴.json"
OUT.write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
summary = {"成功": True, "試行": 124, "前SHA256": BEFORE, "後SHA256": AFTER, "前後不変": True,
           "当時特徴SHA256": sha(OUT), "行数": len(ROWS), "場数": 73,
           "検査数": dict(COUNTS), "モード別": dict(Counter(r["strategy"] for r in ROWS)),
           "特徴別既知数": {k: sum(r["features"][k]["known"] for r in ROWS) for k in ROWS[0]["features"]},
           "区分別件数": {k: dict(Counter(r["bins"][k] for r in ROWS)) for k in ROWS[0]["bins"]},
           "切替件数": {s: dict(Counter(r["choices"][s]["action"] for r in ROWS)) for s in ("T1", "T2")},
           "勝敗使用": False, "新正逆結果読取": False, "原板読取": False, "元指標と条件の変更": False}
(BASE / "抽出確認.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"成功": True, "行数": len(ROWS), "場数": 73, "当時特徴SHA256": sha(OUT),
                  "切替件数": summary["切替件数"]}, ensure_ascii=False))
