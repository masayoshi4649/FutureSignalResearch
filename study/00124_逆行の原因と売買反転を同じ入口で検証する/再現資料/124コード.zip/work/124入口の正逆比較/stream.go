package holdingohlc113

import (
	"bufio"
	"compress/gzip"
	"io"
)

// rawStream124 は拡張子に依存せず物理先頭magicからgzip/非圧縮を選びます。
//
// 引数: raw(io.Reader)は既にSHA計算teeを通った元bytes。
// 返り値: io.ReadCloser/string/error。元bytesを同じ順序で1回だけ読みます。
func rawStream124(raw io.Reader) (io.ReadCloser, string, error) {
	buffer := bufio.NewReader(raw)
	header, err := buffer.Peek(2)
	if err != nil && err != io.EOF {
		return nil, "", err
	}
	if len(header) == 2 && header[0] == 0x1f && header[1] == 0x8b {
		stream, err := gzip.NewReader(buffer)
		if err != nil {
			return nil, "gzip", err
		}
		return stream, "gzip", nil
	}
	return io.NopCloser(buffer), "plain", nil
}
