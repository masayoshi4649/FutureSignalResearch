package holdingohlc113

import (
	"bytes"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"testing"
	"time"
)

// fixedQuoteTest124 は人工取得・観測の全Quoteを作ります。
//
// 引数: at(float64)、index(int64)、bid/ask/last(float64)。返り値: Quoteです。
func fixedQuoteTest124(at float64, index int64, bid, ask, last float64) Quote {
	return Quote{Clock: time.Unix(int64(at), 0).UTC().Format(time.RFC3339), Time: at, Index: index, SourceLine: index + 1, Last: last, Bid: bid, Ask: ask, QuoteOK: true}
}

// TestFixedClockPricesAndSpread124 は正逆の再取得とspreadによる両負けを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestFixedClockPricesAndSpread124(t *testing.T) {
	q := fixedQuoteTest124(100, 0, 100, 130, 115)
	c := fixedCase124(FixedEntry124{ID: "人工", Side: 1, Entry: q}, q)
	if *c.Original.EntryPrice != 130 || *c.Reverse.EntryPrice != 100 || *c.ChartOriginal.EntryPrice != 115 || *c.ChartReverse.EntryPrice != 115 || c.Original.Birth.Side != 1 || c.Reverse.Birth.Side != -1 {
		t.Fatal("同原行の価格・方向差")
	}
	stepCase124(c, q, 100, 5000)
	for _, v := range candidates124(c) {
		if v.Outcomes[0].Touches[0].Direction != 0 {
			t.Fatal("取得原行を先着観測に混入")
		}
	}
	stepCase124(c, fixedQuoteTest124(101, 1, 100, 130, 115), 100, 5000)
	if c.Original.Outcomes[0].Touches[0].Direction != -1 || c.Reverse.Outcomes[0].Touches[0].Direction != -1 {
		t.Fatal("勝敗ラベル単純反転で両負けを消した")
	}
	if c.ChartOriginal.Outcomes[0].Touches[0].Direction != 0 || c.ChartReverse.Outcomes[0].Touches[0].Direction != 0 {
		t.Fatal("Last診断へspreadを混ぜた")
	}
	stepCase124(c, fixedQuoteTest124(102, 2, 140, 150, 145), 101, 5000)
	if c.ChartOriginal.Outcomes[0].Touches[0].Direction != 1 || c.ChartReverse.Outcomes[0].Touches[0].Direction != -1 {
		t.Fatal("Last方向の正逆差")
	}
}

// TestDeadlineKernelAndChartMoney124 は同期限原行・BBO恒等式・chart金額nilを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestDeadlineKernelAndChartMoney124(t *testing.T) {
	q := fixedQuoteTest124(100, 0, 95, 100, 98)
	c := fixedCase124(FixedEntry124{ID: "人工", Side: 1, Entry: q}, q)
	previous := 100.0
	index := int64(1)
	for at := 300.0; at < 1900; at += 200 {
		stepCase124(c, fixedQuoteTest124(at, index, 100, 105, 103), previous, 5000)
		previous = at
		index++
	}
	end := fixedQuoteTest124(1900, index, 110, 115, 112)
	stepCase124(c, end, previous, 5000)
	for _, v := range candidates124(c) {
		if v.Outcomes[0].Status != "complete" || *v.Outcomes[0].Endpoint != end {
			t.Fatal("同じ正常期限原行で評価しない")
		}
	}
	a, b := c.Original.Outcomes[0], c.Reverse.Outcomes[0]
	if *a.Points != 10 || *b.Points != -20 || *a.Net0 != 923 || *b.Net0 != -2077 || *a.Net0+*b.Net0 != -1154 {
		t.Fatal("反転価格・費用・spread恒等式差")
	}
	stepCase124(c, fixedQuoteTest124(1900, index+1, 250, 255, 252), 1900, 5000)
	if c.Original.Outcomes[0].Touches[0].Direction != 0 || c.ChartOriginal.Outcomes[0].Touches[0].Direction != 0 {
		t.Fatal("期限同秒の後続原行を再観測")
	}
	finalize124(c)
	if c.ChartOriginal.Outcomes[0].Points == nil || *c.ChartOriginal.Outcomes[0].Points != 14 || c.ChartOriginal.Outcomes[0].Net0 != nil || c.ChartReverse.Outcomes[0].Net5 != nil || c.ChartOriginal.Outcomes[1].Status != "eof_censored" {
		t.Fatal("chartに金融金額又はEOF未完了を保存")
	}
	if c.Original.Outcomes[0].Net0 == nil || *c.Original.Outcomes[0].Net0 != 923 {
		t.Fatal("BBO金融評価を消した")
	}
}

// TestGapAndNormalQuoteParity124 はchartも同じ欠測・正常BBO条件へ揃えることを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestGapAndNormalQuoteParity124(t *testing.T) {
	q := fixedQuoteTest124(100, 0, 95, 100, 98)
	for _, bboGap := range []bool{false, true} {
		c := fixedCase124(FixedEntry124{ID: "人工", Side: 1, Entry: q}, q)
		next := fixedQuoteTest124(401, 1, 195, 200, 198)
		previous := 100.0
		want := "gap_censored"
		if bboGap {
			next.QuoteOK = false
			previous = 400
			want = "bbo_gap_censored"
		}
		stepCase124(c, next, previous, 5000)
		finalize124(c)
		for _, v := range candidates124(c) {
			for _, o := range v.Outcomes {
				if o.Status != want || o.Points != nil || o.Net0 != nil || o.Touches[0].Direction != 0 {
					t.Fatal("正常BBO/欠測/未補完条件が軸間で異なる")
				}
			}
		}
	}
}

// rawFixtureTest124 はgzip又はplainの人工Rawと固定取得表を作ります。
//
// 引数: t(*testing.T)、compressed(bool)。返り値: Scene124です。
func rawFixtureTest124(t *testing.T, compressed bool) Scene124 {
	t.Helper()
	rows := []Quote{fixedQuoteTest124(100, 0, 95, 105, 100), fixedQuoteTest124(101, 1, 95, 105, 100), fixedQuoteTest124(102, 2, 95, 105, 100)}
	var raw bytes.Buffer
	for _, q := range rows {
		m := map[string]any{"Symbol": "X", "CurrentPrice": q.Last, "CurrentPriceTime": q.Clock}
		for d := 1; d <= 10; d++ {
			m[fmt.Sprintf("Buy%d", d)] = map[string]float64{"Price": q.Bid, "Qty": 1}
			m[fmt.Sprintf("Sell%d", d)] = map[string]float64{"Price": q.Ask, "Qty": 1}
		}
		data, e := json.Marshal(m)
		if e != nil {
			t.Fatal(e)
		}
		raw.Write(data)
		raw.WriteByte('\n')
	}
	data := raw.Bytes()
	name := "人工.jsonl"
	if compressed {
		var out bytes.Buffer
		z := gzip.NewWriter(&out)
		if _, e := z.Write(data); e != nil {
			t.Fatal(e)
		}
		if e := z.Close(); e != nil {
			t.Fatal(e)
		}
		data = out.Bytes()
		name += ".gz"
	}
	path := filepath.Join(t.TempDir(), name)
	if e := os.WriteFile(path, data, 0600); e != nil {
		t.Fatal(e)
	}
	hash := sha256.Sum256(data)
	quality := Counts{Lines: 3, Accepted: 3, Delivered: 3}
	return Scene124{Session: "人工", Contract: "X", Start: 100, End: 5000, ForceClose: 4900, Raw: FileRef{Path: path, SHA256: hex.EncodeToString(hash[:])}, ExpectedAccepted: 3, ExpectedQuality: &quality, Entries: []FixedEntry124{{ID: "人工a", Side: 1, Entry: rows[0]}, {ID: "人工b", Side: -1, Entry: rows[1]}}}
}

// TestExactRawJoinAndFingerprint124 は全Quote結合と採用数・品質・限月・SHAを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。自然Raw・取得表は読みません。
func TestExactRawJoinAndFingerprint124(t *testing.T) {
	for _, compressed := range []bool{false, true} {
		s := rawFixtureTest124(t, compressed)
		r, e := scan124(s)
		if e != nil || !r.Success || len(r.Cases) != 2 || r.Quality != *s.ExpectedQuality || r.Before != r.After || r.SourceEntries != 2 {
			t.Fatal("人工全行認証", e)
		}
		if r.Cases[0].Original.EntryPrice == nil || *r.Cases[0].Original.EntryPrice != 105 || *r.Cases[0].Reverse.EntryPrice != 95 || *r.Cases[1].Original.EntryPrice != 95 || *r.Cases[1].Reverse.EntryPrice != 105 {
			t.Fatal("元方向と反転方向のAsk/Bid差")
		}
		bad := s
		bad.Entries = append([]FixedEntry124{}, s.Entries...)
		bad.Entries[0].Entry.Bid = 90
		if _, e = scan124(bad); e == nil {
			t.Fatal("元Quote全値差を許可")
		}
		bad = s
		bad.Contract = "Y"
		if _, e = scan124(bad); e == nil {
			t.Fatal("限月差を許可")
		}
		bad = s
		bad.Raw.SHA256 = fmt.Sprintf("%064d", 0)
		if _, e = scan124(bad); e == nil {
			t.Fatal("RawSHA差を許可")
		}
		bad = s
		quality := *s.ExpectedQuality
		quality.BadBBO = 1
		bad.ExpectedQuality = &quality
		if _, e = scan124(bad); e == nil {
			t.Fatal("品質差を許可")
		}
		bad = s
		bad.Entries = append([]FixedEntry124{}, s.Entries...)
		bad.Entries[1].ID = bad.Entries[0].ID
		if _, e = scan124(bad); e == nil {
			t.Fatal("固定取得ID重複を許可")
		}
	}
}
