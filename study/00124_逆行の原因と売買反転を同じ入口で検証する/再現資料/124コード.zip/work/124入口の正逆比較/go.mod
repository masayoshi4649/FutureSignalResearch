module entryexperiment124

go 1.24.2
