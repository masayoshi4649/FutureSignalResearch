package holdingohlc113

import (
	"bufio"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"sync"
)

var Widths124 = []float64{25, 50, 100, 125, 200}
var Horizons124 = []float64{1800, 3600}

type FixedEntry124 struct {
	ID    string `json:"id"`
	Side  int    `json:"side"`
	Entry Quote  `json:"entry"`
}
type Scene124 struct {
	Session          string          `json:"session"`
	Contract         string          `json:"contract"`
	Start            float64         `json:"start"`
	End              float64         `json:"end"`
	ForceClose       float64         `json:"force_close"`
	Raw              FileRef         `json:"raw"`
	ExpectedAccepted int64           `json:"expected_accepted"`
	ExpectedQuality  *Counts         `json:"expected_quality"`
	Entries          []FixedEntry124 `json:"entries"`
}
type Input124 struct {
	Scenes []Scene124 `json:"scenes"`
}
type Signal124 struct {
	ID    string  `json:"id"`
	Side  int     `json:"side"`
	Time  float64 `json:"time"`
	Index int64   `json:"index"`
	Line  int64   `json:"source_line"`
	Quote Quote   `json:"quote"`
}
type First124 struct {
	Width     float64 `json:"width"`
	Direction int     `json:"direction"`
	Quote     *Quote  `json:"quote"`
}
type Outcome124 struct {
	Seconds  float64    `json:"seconds"`
	Deadline float64    `json:"deadline"`
	Status   string     `json:"status"`
	Touches  []First124 `json:"touches"`
	Endpoint *Quote     `json:"endpoint"`
	Points   *float64   `json:"points"`
	Net0     *float64   `json:"net0"`
	Net5     *float64   `json:"net5"`
}
type Candidate124 struct {
	Status         string       `json:"status"`
	Axis           string       `json:"axis"`
	Birth          Signal124    `json:"birth"`
	Entry          *Quote       `json:"entry"`
	EntryPrice     *float64     `json:"entry_price"`
	LastNormalTime float64      `json:"last_normal_time"`
	Outcomes       []Outcome124 `json:"outcomes"`
}
type Case124 struct {
	ID            string        `json:"id"`
	OriginalSide  int           `json:"original_side"`
	Original      *Candidate124 `json:"original"`
	Reverse       *Candidate124 `json:"reverse"`
	ChartOriginal *Candidate124 `json:"chart_original"`
	ChartReverse  *Candidate124 `json:"chart_reverse"`
}
type Result124 struct {
	Session         string     `json:"session"`
	Success         bool       `json:"success"`
	Error           string     `json:"error,omitempty"`
	Raw             FileRef    `json:"raw"`
	ActualSHA       string     `json:"actual_sha256"`
	Before          FileStat   `json:"stat_before"`
	After           FileStat   `json:"stat_after"`
	RawEncoding     string     `json:"raw_encoding"`
	Quality         Counts     `json:"quality"`
	ExpectedQuality *Counts    `json:"expected_quality"`
	Cases           []*Case124 `json:"cases"`
	RawPasses       int        `json:"raw_passes"`
	SourceEntries   int        `json:"source_entries"`
}

// fixedCandidate124 は元の取得原行に正又は逆の取得価格を固定します。
//
// 引数: id(string)、side(int)、q(Quote)、chart(bool)。返り値: *Candidate124です。
func fixedCandidate124(id string, side int, q Quote, chart bool) *Candidate124 {
	price := q.Ask
	axis := "BBO"
	if side < 0 {
		price = q.Bid
	}
	if chart {
		price = q.Last
		axis = "Last価格方向診断"
	}
	x := q
	c := &Candidate124{Status: "filled", Axis: axis, Birth: Signal124{ID: id, Side: side, Time: q.Time, Index: q.Index, Line: q.SourceLine, Quote: q}, Entry: &x, EntryPrice: &price, LastNormalTime: q.Time, Outcomes: []Outcome124{}}
	for _, h := range Horizons124 {
		o := Outcome124{Seconds: h, Deadline: q.Time + h, Status: "pending", Touches: []First124{}}
		for _, w := range Widths124 {
			o.Touches = append(o.Touches, First124{Width: w})
		}
		c.Outcomes = append(c.Outcomes, o)
	}
	return c
}

// fixedCase124 は同じ取得原行のBBO正逆とLast参考正逆を一組にします。
//
// 引数: source(FixedEntry124)、q(Quote)。返り値: *Case124です。
func fixedCase124(source FixedEntry124, q Quote) *Case124 {
	return &Case124{ID: source.ID, OriginalSide: source.Side, Original: fixedCandidate124(source.ID, source.Side, q, false), Reverse: fixedCandidate124(source.ID, -source.Side, q, false), ChartOriginal: fixedCandidate124(source.ID, source.Side, q, true), ChartReverse: fixedCandidate124(source.ID, -source.Side, q, true)}
}

// candidates124 は同時刻から始まる四つの独立観測を返します。
//
// 引数: c(*Case124)。返り値: []*Candidate124です。
func candidates124(c *Case124) []*Candidate124 {
	return []*Candidate124{c.Original, c.Reverse, c.ChartOriginal, c.ChartReverse}
}

// stepCase124 はBBOに固定kernel、価格参考にmarkだけLastのkernelを適用します。
//
// 引数: c(*Case124)、q(Quote)、previous/end(float64)。返り値: boolは未完了が残る場合です。
func stepCase124(c *Case124, q Quote, previous, end float64) bool {
	outcome124(c.Original, q, previous, end)
	outcome124(c.Reverse, q, previous, end)
	chartOutcome124(c.ChartOriginal, q, previous, end)
	chartOutcome124(c.ChartReverse, q, previous, end)
	for _, candidate := range candidates124(c) {
		for _, o := range candidate.Outcomes {
			if o.Status == "pending" {
				return true
			}
		}
	}
	return false
}

// finalize124 は未完了を打切りにし、約定不可の参考観測の金額を保存しません。
//
// 引数: c(*Case124)。返り値: ありません。価格方向・先着の値は変更しません。
func finalize124(c *Case124) {
	for _, candidate := range candidates124(c) {
		for i := range candidate.Outcomes {
			o := &candidate.Outcomes[i]
			if o.Status == "pending" {
				o.Status = "eof_censored"
			}
			if candidate.Axis != "BBO" {
				o.Net0 = nil
				o.Net5 = nil
			}
		}
	}
}

// validateEntries124 は固定取得表の重複・時点・正常BBOをmetadataで確認します。
//
// 引数: s(Scene124)。返り値: map[int64][]FixedEntry124/errorは物理行別要求です。
func validateEntries124(s Scene124) (map[int64][]FixedEntry124, error) {
	byLine := map[int64][]FixedEntry124{}
	ids := map[string]bool{}
	for _, e := range s.Entries {
		q := e.Entry
		if e.ID == "" || ids[e.ID] || (e.Side != 1 && e.Side != -1) || !finite(q.Time, q.Last, q.Bid, q.Ask) || q.Time < s.Start || q.Time >= s.ForceClose || q.Index < 0 || q.Index >= s.ExpectedAccepted || q.SourceLine < q.Index+1 || q.Clock == "" || !q.QuoteOK || !normal(q) || q.Last <= 0 {
			return nil, fmt.Errorf("固定取得のid/方向/時計/原行/BBO差:%s", e.ID)
		}
		ids[e.ID] = true
		byLine[q.SourceLine] = append(byLine[q.SourceLine], e)
	}
	return byLine, nil
}

// scan124 は全Rawを一走査し、元の取得原行を全項目同体で正逆観測へ結合します。
//
// 引数: s(Scene124)。返り値: Result124/errorです。新規判断やTTLを再実行しません。
func scan124(s Scene124) (out Result124, err error) {
	out = Result124{Session: s.Session, Raw: s.Raw, ExpectedQuality: s.ExpectedQuality, Cases: []*Case124{}, RawPasses: 1, SourceEntries: len(s.Entries)}
	wanted, e := validateEntries124(s)
	if e != nil {
		return out, e
	}
	f, e := os.Open(s.Raw.Path)
	if e != nil {
		return out, e
	}
	defer f.Close()
	before, e := f.Stat()
	if e != nil {
		return out, e
	}
	out.Before = FileStat{Bytes: before.Size(), ModTimeNS: before.ModTime().UnixNano()}
	h := sha256.New()
	tee := io.TeeReader(f, h)
	z, encoding, e := rawStream124(tee)
	if e != nil {
		return out, e
	}
	defer z.Close()
	out.RawEncoding = encoding
	scan := bufio.NewScanner(z)
	scan.Buffer(make([]byte, 65536), 8*1024*1024)
	scene := Scene{Session: s.Session, Contract: s.Contract, Start: s.Start, End: s.End, Raw: s.Raw}
	previous := s.Start
	var index int64
	contracts := map[string]bool{}
	active := []*Case124{}
	matched := 0
	for scan.Scan() {
		out.Quality.Lines++
		oldTime := previous
		q, reason, next, e := decodeRow(scan.Bytes(), out.Quality.Lines, index, scene, previous, &out.Quality, contracts)
		previous = next
		if e != nil {
			return out, e
		}
		if q != nil {
			index++
		}
		for _, target := range wanted[out.Quality.Lines] {
			if q == nil || target.Entry != *q {
				return out, fmt.Errorf("元取得原行全値差:%s 行%d 理由%s", target.ID, out.Quality.Lines, reason)
			}
			c := fixedCase124(target, *q)
			out.Cases = append(out.Cases, c)
			active = append(active, c)
			matched++
		}
		if q == nil {
			continue
		}
		keep := active[:0]
		for _, c := range active {
			if stepCase124(c, *q, oldTime, s.End) {
				keep = append(keep, c)
			}
		}
		active = keep
	}
	if e = scan.Err(); e != nil {
		return out, e
	}
	if _, e = io.Copy(io.Discard, tee); e != nil {
		return out, e
	}
	after, e := f.Stat()
	if e != nil {
		return out, e
	}
	out.After = FileStat{Bytes: after.Size(), ModTimeNS: after.ModTime().UnixNano()}
	out.ActualSHA = hex.EncodeToString(h.Sum(nil))
	if out.Raw.SHA256 != out.ActualSHA || out.Before != out.After {
		return out, fmt.Errorf("Raw SHA/stat差")
	}
	if len(contracts) != 1 || !contracts[s.Contract] || index != s.ExpectedAccepted || matched != len(s.Entries) {
		return out, fmt.Errorf("限月/採用数/固定取得結合数差")
	}
	if s.ExpectedQuality != nil && out.Quality != *s.ExpectedQuality {
		return out, fmt.Errorf("全行quality差")
	}
	for _, c := range out.Cases {
		finalize124(c)
	}
	out.Success = true
	return out, nil
}

// validSHA124 はRoot固定SHAの小文字16進64桁形式を確認します。
//
// 引数: value(string)。返り値: boolです。
func validSHA124(value string) bool {
	if len(value) != 64 {
		return false
	}
	for _, c := range value {
		if !(c >= '0' && c <= '9') && !(c >= 'a' && c <= 'f') {
			return false
		}
	}
	return true
}

// validateInput124 は73場とP3全79取得の固定範囲を確認します。
//
// 引数: in(Input124)、workers(int)。返り値: errorです。データ本文は開きません。
func validateInput124(in Input124, workers int) error {
	if len(in.Scenes) != 73 || workers < 1 || workers > 8 {
		return fmt.Errorf("73場/並列数差")
	}
	previous := 0.0
	seen := map[string]bool{}
	entries := 0
	for _, s := range in.Scenes {
		if s.Session == "" || seen[s.Session] || s.Contract == "" || !finite(s.Start, s.End, s.ForceClose) || s.Start <= previous || s.End < s.ForceClose || s.ForceClose <= s.Start || s.Raw.Path == "" || !validSHA124(s.Raw.SHA256) || s.ExpectedAccepted <= 0 || s.ExpectedQuality == nil {
			return fmt.Errorf("場/原板/期待品質宣言差:%s", s.Session)
		}
		seen[s.Session] = true
		previous = s.End
		if s.ExpectedQuality.Delivered != s.ExpectedAccepted || s.ExpectedQuality.Accepted < s.ExpectedQuality.Delivered || s.ExpectedQuality.Lines < s.ExpectedQuality.Accepted {
			return fmt.Errorf("品質と採用数差")
		}
		if _, e := validateEntries124(s); e != nil {
			return e
		}
		entries += len(s.Entries)
	}
	if entries != 79 {
		return fmt.Errorf("元P3全79取得と異なる:%d", entries)
	}
	return nil
}

// Run124 はRoot固定の小型取得表を用い全73場を最大8並列で保存します。
//
// 引数: input/expected/output(string)、workers(int)。返り値: errorです。
func Run124(input, expected, output string, workers int) error {
	if !validSHA124(expected) {
		return fmt.Errorf("固定SHAを指定")
	}
	data, e := os.ReadFile(input)
	if e != nil {
		return e
	}
	initial := sha256.Sum256(data)
	if hex.EncodeToString(initial[:]) != expected {
		return fmt.Errorf("入力SHA差")
	}
	var in Input124
	if e = json.Unmarshal(data, &in); e != nil {
		return e
	}
	if e = validateInput124(in, workers); e != nil {
		return e
	}
	if _, e = os.Stat(output); !os.IsNotExist(e) {
		return fmt.Errorf("未作成出力だけ")
	}
	results := make([]Result124, len(in.Scenes))
	jobs := make(chan int)
	var wg sync.WaitGroup
	for i := 0; i < workers; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for at := range jobs {
				r, e := scan124(in.Scenes[at])
				if e != nil {
					r.Error = e.Error()
				}
				results[at] = r
				fmt.Printf("%s 成功=%t %s\n", r.Session, r.Success, r.Error)
			}
		}()
	}
	for i := range in.Scenes {
		jobs <- i
	}
	close(jobs)
	wg.Wait()
	for _, r := range results {
		if !r.Success {
			return fmt.Errorf("%s:%s", r.Session, r.Error)
		}
	}
	out := map[string]any{"trial": 124, "success": true, "input_sha256": expected, "scenes": results, "scene_count": 73, "source_entry_count": 79, "horizons": Horizons124, "widths": Widths124, "candidate_quantity": 1, "portfolio_pnl": false, "fixed_source_entry_clock": true, "new_entry_gate_replayed": false, "chart_money_is_nil": true, "chart_model": "Last→Lastの約定不可の価格方向参考。正常BBO/欠測/期限対象RawはBBOと共通", "ifd_model": "先着touch.quoteの瞬時清算BBOを用いる別集計用証拠。実IFD約定・遅延・待ち行列の証明ではない"}
	encoded, e := json.MarshalIndent(out, "", "  ")
	if e != nil {
		return e
	}
	after, e := os.ReadFile(input)
	if e != nil {
		return e
	}
	if sha256.Sum256(after) != initial {
		return fmt.Errorf("入力前後差")
	}
	f, e := os.OpenFile(output, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if e != nil {
		return e
	}
	defer f.Close()
	_, e = f.Write(append(encoded, '\n'))
	return e
}
