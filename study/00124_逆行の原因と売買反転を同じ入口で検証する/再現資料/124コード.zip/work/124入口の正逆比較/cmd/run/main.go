package main

import (
	entry "entryexperiment124"
	"flag"
	"fmt"
	"os"
)

// main はRoot固定後だけ固定取得の正逆比較を開始します。
//
// 引数: input/sha256/output(string)、workers(int)。返り値: ありません。
func main() {
	p := flag.String("input", "", "固定小型入力")
	s := flag.String("sha256", "", "入力SHA")
	o := flag.String("output", "", "未作成出力")
	w := flag.Int("workers", 8, "場並列数")
	flag.Parse()
	if e := entry.Run124(*p, *s, *o, *w); e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
}
