"""123固定kernelとRaw streamだけを124へ移す。市場入力は読まない。"""
from pathlib import Path
own = Path(__file__).resolve().parent
source = own.parent / "123全場参加の入口比較"
for name in ("outcome.go", "stream.go"):
    path = own / name
    assert not path.exists()
    path.write_text((source / name).read_text(encoding="utf-8").replace("123", "124"), encoding="utf-8", newline="\n")
text = (own / "outcome.go").read_text(encoding="utf-8")
old_mark = 'mark := q.Bid\n\t\tif c.Birth.Side < 0 {\n\t\t\tmark = q.Ask\n\t\t}'
assert old_mark in text
text = text.replace("outcome124", "chartOutcome124").replace(old_mark, "mark := q.Last")
text = text.replace("同幅先着と期限清算評価", "約定不可のLast価格方向と期限価格差")
(own / "chart_outcome.go").write_text(text, encoding="utf-8", newline="\n")
print("124の固定kernelを準備しました。市場実行はしていません。")
