# 124の正逆比較CSV出力

Rootが固定したJSONの`tables`三表を転記する。表名は`正逆比較`、`入口別診断`、`全セッション`。ヘッダ・列順・行順・全セルの型と値をそのまま保持し、列数・行数は任意。0行の診断表もヘッダを残す。金融・群・率・bootstrapは再計算しない。

主T1・H60±125pt、O0/R0/R1/R2/R3/T1/T2、全79入口/73場の比較を想定するが、行列と定義はRootの確定表JSONへ従う。全H完了の先着率とIFD代用の既知清算分母を勝手に合わせず、Last-onlyの金額nilも保持する。候補や不都合な場を削らず、独立mini1枚の対照を実口座収支へ合算しない。

Node24.22.1、Artifact Tool2.8.129を固定し、`node_modules`は既存runtimeへのjunctionである。packageを変更しない。文字列・有限数値・boolean・nullを許し、安全整数範囲外を拒否する。xlsxは生成しない。

## 自然出力の手順

自然表とSHAを固定した後、最初の作成直前にRootが`create/3/csv`を一度記録する。同じ作成操作の再試行でmarkerを重ねない。出力器・再読器は自動でmarkerを実行しない。人工データのwork内試験では自然用markerを実行しない。

```powershell
$nodeExe = 'C:/Users/masay/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe'
& $nodeExe 'C:/Users/masay/.codex/plugins/cache/openai-primary-runtime/spreadsheets/26.1104.22356/skills/spreadsheets/container_tools/mark_artifact_operation_started.mjs' --operation-kind create --expected-output-count 3 --output-format csv
& $nodeExe 'work/124正逆CSV出力/出力する.mjs' --input 'Rootの確定三表.json' --sha256 '64桁SHA256' --output '未作成CSVフォルダ'
C:/Python314/python.exe -X utf8 'work/124正逆CSV出力/CSVを独立再読する.py' --input 'Rootの確定三表.json' --sha256 '64桁SHA256' --folder '作成したCSVフォルダ' --output 'work/124正逆CSV出力/全73独立再読.json'
```

既存出力先を拒否する。UTF-8 BOM・CRLF、nullは空欄、0は0、booleanは小文字true/false。元の文字列の先頭零・引用符・改行・式に見える文字も保持する。nullと空文字はCSV表現上区別できないため元JSONの型を基準に照合する。比率0.7は70%のままで、100倍しない。

## 検査

Artifact ToolのWorkbookへ三表を型付き投入し、再計算後のヘッダ/全データセルを元JSONの型と値へ一致照合する。数式0、エラー走査、入力前後SHA、保存bytesとSHAを記録してから完了する。入力自身の`#N/A`等は同じ文字として保持する。

標準csv/Decimal再読器は数値許容差なし、文字列も完全一致で比較し、0とnullを分ける。各表のA:G・最大5行を固定列幅/倍率1で描画する（正逆比較870px、入口別診断870px、全場850px）。自然出力後はRootが三画像を視認する。プレビューは全行列の代わりではない。

## 人工検査と編集停止

2026-11-11。123器から試行番号・表名・幅・評価単位の注記を124へ適応した。三表各3行×8列で72データセル/27数値、ヘッダ込み96セルが一致。入口別診断0行の変種も48データセル/18数値、ヘッダ込み72セルが一致した。Node構文とPython構文、独立再読が成功し、人工三画像と0行診断画像を視認した。他二画像は同bytesで確認する。

人工の先頭零IDとbooleanは画像側で短縮/チェック表示されるが、CSVの元型・値は保持した。人工成功から自然CSVや自然画像確認を先取りしない。

124金融結果・自然表・入力本文・Rawは未読、自然CSV/markerは未実行。準備proofを保存してCSV器の編集を停止する。正式な条件文書の更新は器の停止と別工程で行う。
