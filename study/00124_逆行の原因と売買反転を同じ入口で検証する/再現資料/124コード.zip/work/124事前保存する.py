"""
124のF1原文6点・コード・小型入力と当時特徴を正式保存する。

新金融結果・Raw・177MB入力・123結果・exe本文は開かない。
"""

from pathlib import Path
import gzip
import hashlib
import json
import zipfile


ROOT = Path(__file__).resolve().parent.parent
STUDY = ROOT / "study/00124_逆行の原因と売買反転を同じ入口で検証する"
INPUTS = ROOT / "inputs/00124_同入口正逆の共用入力"
FIXED = ROOT / "work/124入口の原因分析/再生前固定.json"
EXPECTED = "7fdfbf3b8ef9166d7bcaf0b5503a711f6a808dcba718e67c951fe627f71210d3"


# ----------------------------------------
def sha(data: bytes) -> str:
    """
    機能: 読取済みbytesのSHA256を求める。
    引数: data(bytes)は対象。
    返り値: str型の指紋。
    """
    return hashlib.sha256(data).hexdigest()


# ----------------------------------------
def encoded(value: dict) -> bytes:
    """
    機能: 日本語JSONをUTF-8へ符号化する。
    引数: value(dict)は保存記録。
    返り値: bytes型のJSON。
    """
    return (json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + "\n").encode("utf-8")


# ----------------------------------------
def save_same(path: Path, data: bytes) -> None:
    """
    機能: 未作成先へ保存し、既存なら同bytesを要求する。
    引数: path(Path)は保存先、data(bytes)は内容。
    返り値: None。差異は例外。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == data, path
    else:
        with path.open("xb") as stream:
            stream.write(data)


# ----------------------------------------
def main() -> None:
    """
    機能: F1同体を前後照合し、6原文・3共用入力gzipと小型ZIPを保存する。
    引数: なし。Rootが許可した固定パスだけを読む。
    返り値: None。金融再生・大入力/原板/実行物の複写なし。
    """
    raw = FIXED.read_bytes()
    assert sha(raw) == EXPECTED
    fixed = json.loads(raw)
    assert fixed["試行"] == 124 and fixed["成功"]
    assert len(fixed["コード"]) == 16 and len(fixed["事前文書"]) == 6
    assert fixed["主政策"] == "T1" and fixed["主幅pt"] == 125
    checks = STUDY / "検査"
    reproduction = STUDY / "再現資料"
    checks.mkdir(exist_ok=True)
    reproduction.mkdir(exist_ok=True)
    save_same(checks / "再生前固定.json", raw)
    originals = []
    for name, expected in fixed["事前文書"].items():
        path = Path(name)
        data = path.read_bytes()
        assert sha(data) == expected
        text = data.decode("utf-8")
        assert text.encode("utf-8") == data
        originals.append({"source_path": str(path), "restore_relative": path.relative_to(ROOT).as_posix(),
                          "SHA256": expected, "bytes": len(data), "utf8_text": text})
    contents = {"試行": 124, "F1_SHA256": EXPECTED, "原文": originals,
                "復元": "utf8_textをUTF-8へencodeしSHA/bytesを照合。文書と区分JSONを当時配置へ戻す。"}
    contents_bytes = encoded(contents)
    archive = gzip.compress(contents_bytes, compresslevel=9, mtime=0)
    save_same(checks / "実行前文書.json.gz", archive)
    unpacked = json.loads(gzip.decompress((checks / "実行前文書.json.gz").read_bytes()))
    assert unpacked == contents
    for item in unpacked["原文"]:
        data = item["utf8_text"].encode("utf-8")
        assert sha(data) == item["SHA256"] and len(data) == item["bytes"]
    input_refs = []
    for name, expected in fixed["入力"].items():
        path = Path(name)
        data = path.read_bytes()
        assert sha(data) == expected
        packed = gzip.compress(data, compresslevel=9, mtime=0)
        target = INPUTS / (path.name + ".gz")
        save_same(target, packed)
        assert gzip.decompress(target.read_bytes()) == data
        input_refs.append({"source_path": str(path), "restore_relative": path.relative_to(ROOT).as_posix(),
                           "path": target.relative_to(ROOT).as_posix(), "SHA256": sha(packed), "bytes": len(packed),
                           "解凍SHA256": expected, "解凍bytes": len(data)})
    save_same(INPUTS / "指紋.json", encoded({"試行": 124, "F1_SHA256": EXPECTED, "入力": input_refs,
              "大入力参照": "work/122全場入力/入力.json SHA6a6cd13d…・177709174B、正式122の復元経路へ参照。本文コピーなし",
              "元123結果参照": "9823c9b3f257d97462f295e696b649d41a10ea538dd816490d70e60b34c4146f",
              "Raw": "共有原板を参照。今回保存なし"}))
    packed_code = {}
    for name, expected in fixed["コード"].items():
        path = Path(name)
        data = path.read_bytes()
        assert sha(data) == expected
        packed_code[path.relative_to(ROOT).as_posix()] = data
    for name in ("出力する.mjs", "CSVを独立再読する.py", "README.md"):
        path = ROOT / "work/124正逆CSV出力" / name
        packed_code[path.relative_to(ROOT).as_posix()] = path.read_bytes()
    packed_code[Path(__file__).resolve().relative_to(ROOT).as_posix()] = Path(__file__).read_bytes()
    zip_path = reproduction / "124コード.zip"
    assert not zip_path.exists()
    with zipfile.ZipFile(zip_path, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, data in sorted(packed_code.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 11, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, data)
    entries = []
    with zipfile.ZipFile(zip_path) as z:
        assert z.testzip() is None
        for info in z.infolist():
            data = z.read(info.filename)
            assert data == packed_code[info.filename]
            entries.append({"entry": info.filename, "restore_relative": info.filename, "SHA256": sha(data),
                            "bytes": len(data), "CRC32": f"{info.CRC:08x}"})
    index = {"試行": 124, "F1_SHA256": EXPECTED,
             "zip": {"path": zip_path.name, "SHA256": sha(zip_path.read_bytes()), "bytes": zip_path.stat().st_size},
             "entries": entries, "備考": "F1コード16＋CSV器3＋保存器1。Goは標準ライブラリだけ。6原文と3共用入力は別gzipから復元。"}
    save_same(reproduction / "コード復元索引.json", encoded(index))
    copies = []
    for name, relative in [
        (ROOT / "work/124入口の原因分析/入力生成の確認.json", "検査/入力生成の確認.json"),
        (ROOT / "work/124当時特徴の診断/完了.json", "検査/当時特徴器の完了.json"),
        (ROOT / "work/124当時特徴の診断/人工検査.json", "検査/当時特徴器の人工検査.json"),
        (ROOT / "work/124当時特徴の診断/抽出確認.json", "検査/当時特徴の抽出確認.json"),
        (ROOT / "work/124当時特徴の診断/README.md", "根拠/当時特徴の診断.md"),
        (ROOT / "work/124正逆CSV出力/準備の確認.json", "検査/CSV器の準備.json"),
    ]:
        data = name.read_bytes()
        save_same(STUDY / relative, data)
        copies.append({"path": relative, "SHA256": sha(data), "bytes": len(data)})
    assert sha(FIXED.read_bytes()) == EXPECTED
    for group in ("コード", "事前文書", "入力"):
        assert all(sha(Path(name).read_bytes()) == expected for name, expected in fixed[group].items())
    proof = {"試行": 124, "成功": True, "F1_SHA256": EXPECTED,
             "原文gzip": {"path": "実行前文書.json.gz", "SHA256": sha(archive), "bytes": len(archive),
                          "解凍SHA256": sha(contents_bytes), "解凍bytes": len(contents_bytes), "原文数": 6},
             "F1コード16_文書6_入力3前後同体": True, "入力gzip": input_refs, "コードZIP": index["zip"], "entry数": len(entries),
             "小型検査の保存": copies, "金融実行": False, "新金融結果読取": False, "Raw読取": False,
             "177MB入力本文読取": False, "123結果本文読取": False, "exe本文読取": False}
    save_same(checks / "F1原文と共用入力保管の確認.json", encoded(proof))
    print(json.dumps({"成功": True, "原文gzip": proof["原文gzip"], "入力gzip": input_refs, "コードZIP": index["zip"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
