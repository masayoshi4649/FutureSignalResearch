"""
123のF1成立後に、原文3点と小型コードを金融再実行なしで正式保存する。

期待F1 SHAを必須とし、Input本文・Raw・自然結果・exe本文を読まない。
"""

from pathlib import Path
import argparse
import gzip
import hashlib
import json
import zipfile


ROOT = Path(__file__).resolve().parents[2]
STUDY = ROOT / "study/00123_複合入口で全セッション最低1回を検証する"
FIXED = ROOT / "work/123全場参加の集計/再生前固定.json"
SOURCE_ZIP = ROOT / "study/00121_失速と量で反転の入口を切り替える/再現資料/121コード.zip"
SOURCE_ZIP_SHA = "e2d974a7d13202caa1435d4b5f52b12214c0d4fa7fbe6f66f04f4c477e973994"
TEST_ZIP = ROOT / "study/00120_1分構造と無効化距離で入口を作る/再現資料/120コード.zip"
TEST_ZIP_SHA = "ac3c159fe9b9cffda8e8ed4260029e191577e9921537d982a973f6e454ced771"


# ----------------------------------------
def digest(data: bytes) -> str:
    """
    機能: 読取済みバイト列のSHA256を求める。
    引数: data(bytes)は対象。
    返り値: str型の小文字16進指紋。
    """
    return hashlib.sha256(data).hexdigest()


# ----------------------------------------
def encode(value: dict) -> bytes:
    """
    機能: 日本語を保持したJSONをUTF-8へ符号化する。
    引数: value(dict)はJSON化する記録。
    返り値: bytes型のUTF-8表現。
    """
    return (json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + "\n").encode("utf-8")


# ----------------------------------------
def save_same(path: Path, data: bytes) -> None:
    """
    機能: 未作成先へ保存し、既存の場合は同bytesを要求する。
    引数: path(Path)は保存先、data(bytes)は保存内容。
    返り値: None。既存内容が違えば例外。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == data, path
    else:
        with path.open("xb") as stream:
            stream.write(data)


# ----------------------------------------
def main() -> None:
    """
    機能: F1の3原文・固定コードを同体保存し、利用可能性監査3資料と再現索引を付ける。
    引数: CLIの--fixed-sha(str)はRootが通知したF1 SHA256。
    返り値: None。金融・Input本文・Raw・自然結果・exe本文を読まない。
    """
    parser = argparse.ArgumentParser(description="F1と同体の123原文/コードを正式保存")
    parser.add_argument("--fixed-sha", required=True)
    args = parser.parse_args()
    assert len(args.fixed_sha) == 64 and all(c in "0123456789abcdef" for c in args.fixed_sha)
    fixed_bytes = FIXED.read_bytes()
    assert digest(fixed_bytes) == args.fixed_sha
    fixed = json.loads(fixed_bytes)
    assert fixed["試行"] == 123 and fixed["成功"]
    assert len(fixed["対象全場"]) == 73 and len(set(fixed["対象全場"])) == 73
    assert fixed["主候補"] == "P3" and fixed["主先着幅pt"] == 125 and fixed["主時間秒"] == 3600
    assert fixed["入力"]["sha256"] == "6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec"
    checks = STUDY / "検査"
    reproduction = STUDY / "再現資料"
    checks.mkdir(exist_ok=True)
    reproduction.mkdir(exist_ok=True)
    originals = []
    for name, expected in fixed["実行前文書"].items():
        path = Path(name)
        data = path.read_bytes()
        assert digest(data) == expected, path
        text = data.decode("utf-8")
        assert text.encode("utf-8") == data
        originals.append({"source_path": str(path), "restore_relative": path.relative_to(ROOT).as_posix(),
                          "SHA256": expected, "bytes": len(data), "utf8_text": text})
    assert len(originals) == 3
    original_value = {"試行": 123, "F1_SHA256": args.fixed_sha, "原文": originals,
                      "復元": "utf8_textをUTF-8へencodeしSHA/bytes照合。当時の試行ルート又は元work配置でリンクを解釈。"}
    original_bytes = encode(original_value)
    original_gzip = gzip.compress(original_bytes, compresslevel=9, mtime=0)
    save_same(checks / "実行前文書.json.gz", original_gzip)
    restored = json.loads(gzip.decompress((checks / "実行前文書.json.gz").read_bytes()))
    assert restored == original_value
    for item in restored["原文"]:
        data = item["utf8_text"].encode("utf-8")
        assert digest(data) == item["SHA256"] and len(data) == item["bytes"]
    save_same(checks / "再生前固定.json", fixed_bytes)
    assert digest(SOURCE_ZIP.read_bytes()) == SOURCE_ZIP_SHA
    assert digest(TEST_ZIP.read_bytes()) == TEST_ZIP_SHA
    old_entries = {}
    with zipfile.ZipFile(SOURCE_ZIP) as archive:
        for info in archive.infolist():
            if info.filename.startswith(("work/118複数技法の入口条件/", "work/121入口の反転切替/")):
                data = archive.read(info.filename)
                old_entries[info.filename] = (digest(data), len(data))
    packed = {}
    external = []
    fixed_code = []
    for name, expected in fixed["コード"].items():
        path = Path(name)
        data = path.read_bytes()
        assert digest(data) == expected, path
        relative = path.relative_to(ROOT).as_posix()
        fixed_code.append({"restore_relative": relative, "SHA256": expected, "bytes": len(data)})
        if old_entries.get(relative) == (expected, len(data)):
            external.append({"archive": SOURCE_ZIP.relative_to(ROOT).as_posix(), "archive_SHA256": SOURCE_ZIP_SHA,
                             "entry": relative, "restore_relative": relative, "SHA256": expected, "bytes": len(data)})
        else:
            assert path.suffix in (".py", ".go") or path.name == "go.mod", path
            packed[relative] = data
    # ----------------------------------------
    # 121pureの人工対照依存を、金融F1の対象コードとは区別して旧正式ZIPへ参照する。
    with zipfile.ZipFile(TEST_ZIP) as archive:
        for info in archive.infolist():
            if not info.filename.startswith("work/120入口の1分構造/"):
                continue
            if not (info.filename.endswith(".go") or info.filename.endswith("/go.mod")):
                continue
            data = archive.read(info.filename)
            local = ROOT / info.filename
            assert local.read_bytes() == data
            external.append({"archive": TEST_ZIP.relative_to(ROOT).as_posix(), "archive_SHA256": TEST_ZIP_SHA,
                             "entry": info.filename, "restore_relative": info.filename, "SHA256": digest(data),
                             "bytes": len(data), "役割": "121pure人工対照のテスト依存・123金融F1対象外"})
    extras = [ROOT / "work/123全場CSV出力" / n for n in ("出力する.mjs", "CSVを独立再読する.py", "README.md")]
    audit = ROOT / "work/123全場参加の利用可能性"
    extras.extend(p for p in audit.rglob("*") if p.is_file() and (p.suffix in (".go", ".py") or p.name == "go.mod"))
    extras.append(Path(__file__).resolve())
    for path in extras:
        packed[path.relative_to(ROOT).as_posix()] = path.read_bytes()
    zip_path = reproduction / "123コード.zip"
    assert not zip_path.exists(), zip_path
    with zipfile.ZipFile(zip_path, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(packed.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 11, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, data)
    entries = []
    with zipfile.ZipFile(zip_path) as archive:
        assert archive.testzip() is None
        for info in archive.infolist():
            data = archive.read(info.filename)
            assert data == packed[info.filename]
            entries.append({"entry": info.filename, "restore_relative": info.filename, "SHA256": digest(data),
                            "bytes": len(data), "CRC32": f"{info.CRC:08x}"})
    index = {"試行": 123, "F1_SHA256": args.fixed_sha,
             "zip": {"path": zip_path.name, "SHA256": digest(zip_path.read_bytes()), "bytes": zip_path.stat().st_size},
             "entries": entries, "external_entries": external, "F1コード": fixed_code,
             "入力": fixed["入力"], "備考": "入力本文・Raw・Native・exe・詳細maskは複写しない。3原文は別の実行前文書gzipから復元。"}
    save_same(reproduction / "コード復元索引.json", encode(index))
    audit_owner = json.loads((audit / "完了.json").read_text(encoding="utf-8"))
    audit_refs = []
    for name in ("README.md", "全73場の利用可能性要約.json", "初日の時計監査.json"):
        data = (audit / name).read_bytes()
        assert digest(data) == audit_owner["SHA256"][name]
        target = STUDY / "根拠/当時利用可能性" / name
        save_same(target, data)
        audit_refs.append({"path": target.relative_to(ROOT).as_posix(), "SHA256": digest(data), "bytes": len(data)})
    save_same(checks / "利用可能性監査の完了.json", (audit / "完了.json").read_bytes())
    save_same(checks / "CSV器の準備.json", (ROOT / "work/123全場CSV出力/準備の確認.json").read_bytes())
    assert digest(FIXED.read_bytes()) == args.fixed_sha
    assert all(digest(Path(name).read_bytes()) == value for name, value in fixed["コード"].items())
    assert all(digest(Path(name).read_bytes()) == value for name, value in fixed["実行前文書"].items())
    proof = {"試行": 123, "成功": True, "F1_SHA256": args.fixed_sha,
             "原文gzip": {"path": "実行前文書.json.gz", "SHA256": digest(original_gzip), "bytes": len(original_gzip),
                          "解凍SHA256": digest(original_bytes), "解凍bytes": len(original_bytes),
                          "原文SHA256": {p["source_path"]: p["SHA256"] for p in originals}},
             "F1コード前後同体": True, "F1原文前後同体": True, "zip": index["zip"],
             "ZIP件数": len(entries), "外部依存件数": len(external), "利用可能性の正式3資料": audit_refs,
             "金融実行": False, "自然結果読取": False, "入力本文読取": False, "Raw読取": False, "exe本文読取": False}
    save_same(checks / "F1原文とコード保管の確認.json", encode(proof))
    print(json.dumps({"成功": True, "F1": args.fixed_sha, "原文gzip": proof["原文gzip"], "コードZIP": index["zip"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
