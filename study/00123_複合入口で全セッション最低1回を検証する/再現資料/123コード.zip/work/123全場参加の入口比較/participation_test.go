package holdingohlc113

import (
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"testing"
)

// TestSupplementFillAndPriority123 は補完の取得・同Raw優先取消・再試行を人工価格で検査します。
//
// 引数: t(*testing.T)。返り値: ありません。市場データは使いません。
func TestSupplementFillAndPriority123(t *testing.T) {
	for _, side := range []int{1, -1} {
		q := testQuote123(100, 0, 95, 105)
		d := Decision123{Eligible: true, Side: side, Components: map[string]rules.Value{"ATR5": {Known: true, Value: 10}}}
		scene := Scene123{Session: "s", Contract: "X", ForceClose: 5000}
		c := supplement123("P3", "deadline", d, q, scene)
		pending123(c, testQuote123(100, 1, 95, 105), 5000)
		if c.Entry != nil {
			t.Fatal("同秒取得")
		}
		covered := map[string]bool{}
		keep, fills := processPending123([]*Candidate123{c}, testQuote123(101, 2, 95, 105), 5000, covered, map[string]bool{})
		if len(keep) != 0 || len(fills) != 1 || !covered["P3"] || c.RiskAtDecision != nil {
			t.Fatal("補完取得をE0専用riskで拒否")
		}
		want := 105.0
		if side < 0 {
			want = 95
		}
		if *c.EntryPrice != want {
			t.Fatal("買Ask/売Bid差")
		}
		// ----------------------------------------
		// 先にリストへ入っている補完でも、同Rawに出生したE0が優先される。
		old := supplement123("P3", "strong", d, q, scene)
		at := testQuote123(101, 1, 95, 105)
		e0, err := new123(testEvent123(at, side), at, 0, scene)
		if err != nil {
			t.Fatal(err)
		}
		e0.Policy = "P3"
		covered = map[string]bool{}
		keep, fills = processPending123([]*Candidate123{old, e0}, at, 5000, covered, map[string]bool{"P3": true})
		if old.Status != "cancelled_e0_priority" || old.Entry != nil || len(fills) != 0 || len(keep) != 1 || covered["P3"] {
			t.Fatal("E0同Raw優先差")
		}
		// ----------------------------------------
		// E0取得成立を補完より先に数え、取得済み場へ追加補完しない。
		old = supplement123("P3", "strong", d, q, scene)
		e0, err = new123(testEvent123(q, side), q, 0, scene)
		if err != nil {
			t.Fatal(err)
		}
		e0.Policy = "P3"
		covered = map[string]bool{}
		keep, fills = processPending123([]*Candidate123{old, e0}, testQuote123(101, 1, 95, 105), 5000, covered, map[string]bool{})
		if len(keep) != 0 || len(fills) != 1 || fills[0] != e0 || old.Status != "cancelled_already_entered" || old.Entry != nil || !covered["P3"] {
			t.Fatal("E0取得後取消差")
		}
		// ----------------------------------------
		// 期限切れは参加と数えず、後の別要求だけを取得する。
		old = supplement123("P3", "deadline", d, q, scene)
		covered = map[string]bool{}
		keep, fills = processPending123([]*Candidate123{old}, testQuote123(130, 1, 95, 105), 5000, covered, map[string]bool{})
		if len(keep) != 0 || len(fills) != 0 || covered["P3"] || old.Status != "unfilled_expired" {
			t.Fatal("30秒TTL境界差")
		}
		next := supplement123("P3", "deadline", d, testQuote123(131, 2, 95, 105), scene)
		_, fills = processPending123([]*Candidate123{next}, testQuote123(132, 3, 95, 105), 5000, covered, map[string]bool{})
		if len(fills) != 1 || !covered["P3"] || old.Entry != nil {
			t.Fatal("未取得後の再要求差")
		}
	}
}

// TestDeadlinesAndNoRequestCoverage123 は政策別期限と未約定の参加除外を検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestDeadlinesAndNoRequestCoverage123(t *testing.T) {
	for p, want := range map[string]float64{"P2": 7200, "P3": 10800, "P4": 14400} {
		if deadline123(p) != want {
			t.Fatal("期限差")
		}
	}
	c := supplement123("P3", "deadline", Decision123{Side: 1}, testQuote123(100, 0, 95, 105), Scene123{Session: "s", ForceClose: 5000})
	covered := map[string]bool{}
	bad := testQuote123(101, 1, 100, 100)
	keep, fills := processPending123([]*Candidate123{c}, bad, 5000, covered, map[string]bool{})
	if len(keep) != 1 || len(fills) != 0 || covered["P3"] {
		t.Fatal("注文要求/異常BBOを取得と計上")
	}
}
