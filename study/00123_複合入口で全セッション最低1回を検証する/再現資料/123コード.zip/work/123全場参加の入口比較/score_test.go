package holdingohlc113

import (
	"fmt"
	"math"
	"testing"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// scorePublication123 は純スコア検査用の手製公表を返します。
//
// 引数: session(string)、width/index(int)、end(float64)。返り値: rules.Publicationです。
func scorePublication123(session string, width, index int, end float64) rules.Publication {
	t := rules.Technical{EMA8: value123(106), EMA21: value123(100), EMA8Delta: value123(2), EMA21Delta: value123(1), Gap: value123(6), ATR: value123(20), PreviousATR: value123(20), TR: value123(20), RSI: value123(60), PreviousRSI: value123(55), Histogram: value123(2), PreviousHistogram: value123(1)}
	f := rules.ChartFrame{ID: fmt.Sprintf("%s/%d/%g", session, width, end), SessionID: session, Contract: "X", Width: width, Start: end - float64(width), End: end, AvailableAt: end + 60, DeliveryAt: end + 60, PriceKnown: true, VolumeKnown: true, Volume: 100, OHLC: rules.OHLC{Open: 100, High: 110, Low: 90, Close: 105}, Technical: t}
	return rules.Publication{Stamp: rules.Stamp{Time: end + 60, Index: index, Line: index + 1}, Frame: rules.Frame{Frame: f, DMI: rules.DMI{PlusDI: value123(30), MinusDI: value123(10), ADX: value123(30), PreviousADX: value123(35)}}}
}

// mirrorPublication123 はK-priceの価格鏡像と符号指標の鏡像を同時に作ります。
//
// 引数: p(rules.Publication)、k(float64)。返り値: rules.Publicationです。
func mirrorPublication123(p rules.Publication, k float64) rules.Publication {
	f := &p.Frame.Frame
	o := f.OHLC
	f.OHLC = rules.OHLC{Open: k - o.Open, High: k - o.Low, Low: k - o.High, Close: k - o.Close}
	t := &f.Technical
	for _, v := range []*rules.Value{&t.EMA8, &t.EMA21} {
		if v.Known {
			v.Value = k - v.Value
		}
	}
	for _, v := range []*rules.Value{&t.EMA8Delta, &t.EMA21Delta, &t.Gap, &t.Histogram, &t.PreviousHistogram} {
		if v.Known {
			v.Value = -v.Value
		}
	}
	for _, v := range []*rules.Value{&t.RSI, &t.PreviousRSI} {
		if v.Known {
			v.Value = 100 - v.Value
		}
	}
	d := &p.Frame.DMI
	d.PlusDI, d.MinusDI = d.MinusDI, d.PlusDI
	return p
}

// scoreFixture123 は自然ファイルを使わず窓・公表・当Rawを作ります。
//
// 引数: t(*testing.T)、upper/mirror(bool)、change(func(*rules.Publication,int))。
// 返り値: *rules.Bank/*Window123/Quoteです。
func scoreFixture123(t *testing.T, upper, mirror bool, change func(*rules.Publication, int)) (*rules.Bank, *Window123, Quote) {
	t.Helper()
	b := rules.NewBank()
	if e := b.StartSession("prior", "X"); e != nil {
		t.Fatal(e)
	}
	for i := 0; i < 20; i++ {
		p := scorePublication123("prior", 300, i, 50000+float64(i*300))
		if mirror {
			p = mirrorPublication123(p, 400)
		}
		if e := b.Add(p); e != nil {
			t.Fatal(e)
		}
	}
	if e := b.StartSession("current", "X"); e != nil {
		t.Fatal(e)
	}
	w := &Window123{}
	for i := 0; i < 4; i++ {
		p := scorePublication123("current", 300, 40+i*20, 99940-float64((3-i)*300))
		if change != nil {
			change(&p, i)
		}
		if mirror {
			p = mirrorPublication123(p, 400)
		}
		if e := b.Add(p); e != nil {
			t.Fatal(e)
		}
		w.observe(p)
	}
	if upper {
		for _, width := range []int{900, 1800} {
			p := scorePublication123("current", width, 100, 99940)
			if change != nil {
				change(&p, 4)
			}
			if mirror {
				p = mirrorPublication123(p, 400)
			}
			if e := b.Add(p); e != nil {
				t.Fatal(e)
			}
		}
	}
	q := Quote{Time: 100000, Index: 100, SourceLine: 101, Last: 107, Bid: 105, Ask: 110, QuoteOK: true}
	if mirror {
		q.Last = 400 - q.Last
		q.Bid, q.Ask = 400-q.Ask, 400-q.Bid
	}
	return b, w, q
}

// TestScoreFullPriceMirror123 は三時間軸と全価格系のK-price鏡像を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestScoreFullPriceMirror123(t *testing.T) {
	b, w, q := scoreFixture123(t, true, false, nil)
	d, e := score123(b, q, w)
	if e != nil {
		t.Fatal(e)
	}
	mb, mw, mq := scoreFixture123(t, true, true, nil)
	md, e := score123(mb, mq, mw)
	if e != nil {
		t.Fatal(e)
	}
	if !d.Eligible || !md.Eligible || d.Side != 1 || md.Side != -1 || d.KnownCounts["T_scales"] != 3 || md.KnownCounts["T_scales"] != 3 {
		t.Fatal("三時間軸の成立又は鏡像方向差")
	}
	for _, key := range []string{"5_T", "15_T", "30_T", "T", "M", "P", "S"} {
		if math.Abs(d.Components[key].Value+md.Components[key].Value) > 1e-14 {
			t.Fatalf("鏡像の符号差 %s", key)
		}
	}
	for _, key := range []string{"ATR5", "previous_ATR5", "TR5", "RVOL5", "v", "g", "u"} {
		if d.Components[key] != md.Components[key] {
			t.Fatalf("鏡像の不変量差 %s", key)
		}
	}
	s, ok := strong123(d)
	ms, mok := strong123(md)
	if !ok || !mok || s.Strategy != "trend" || ms.Strategy != "trend" || s.Side != -ms.Side {
		t.Fatal("通常順行の鏡像差")
	}
}

// TestScoreUnknownMasksAndTie123 は長期未知の除外、短期必須、同率の確定終値差を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestScoreUnknownMasksAndTie123(t *testing.T) {
	b, w, q := scoreFixture123(t, false, false, func(p *rules.Publication, i int) {
		p.Frame.Frame.Technical.Histogram = rules.Value{}
		p.Frame.Frame.Technical.PreviousHistogram = rules.Value{}
	})
	d, e := score123(b, q, w)
	if e != nil || !d.Eligible || d.KnownCounts["T_scales"] != 1 || d.KnownCounts["M"] != 2 || d.Components["15_T"].Known || d.Components["30_T"].Known {
		t.Fatal("未知を支持した又は長期不足で全拒否", e)
	}
	b, w, q = scoreFixture123(t, true, false, func(p *rules.Publication, i int) {
		if p.Frame.Frame.Width == 300 {
			p.Frame.Frame.Technical.Gap = rules.Value{}
			p.Frame.Frame.Technical.EMA8Delta = rules.Value{}
			p.Frame.Frame.Technical.EMA21Delta = rules.Value{}
			p.Frame.DMI.PlusDI = rules.Value{}
		}
	})
	d, e = score123(b, q, w)
	if e != nil || d.Eligible || d.Components["5_T"].Known || !d.Components["15_T"].Known {
		t.Fatal("5分必須を上位足だけで埋めた", e)
	}
	flat := func(p *rules.Publication, i int) {
		x := &p.Frame.Frame.Technical
		x.Gap = value123(0)
		x.EMA8Delta = value123(0)
		x.EMA21Delta = value123(0)
		x.RSI = value123(50)
		x.PreviousRSI = value123(50)
		x.Histogram = value123(0)
		x.PreviousHistogram = value123(0)
		p.Frame.DMI.PlusDI = value123(20)
		p.Frame.DMI.MinusDI = value123(20)
		p.Frame.Frame.OHLC = rules.OHLC{Open: 100, High: 110, Low: 90, Close: 100}
		if i == 2 {
			p.Frame.Frame.OHLC.Close = 95
		}
	}
	b, w, q = scoreFixture123(t, true, false, flat)
	q.Last = 100
	d, e = score123(b, q, w)
	if e != nil || !d.Eligible || d.Score.Value != 0 || d.Side != 1 || d.Tie == "" {
		t.Fatal("同率終値差を使わない", e)
	}
	mb, mw, mq := scoreFixture123(t, true, true, flat)
	mq.Last = 300
	md, e := score123(mb, mq, mw)
	if e != nil || md.Score.Value != 0 || md.Side != -1 {
		t.Fatal("同率の価格鏡像差", e)
	}
	b, w, q = scoreFixture123(t, true, false, func(p *rules.Publication, i int) { flat(p, 4) })
	q.Last = 100
	d, e = score123(b, q, w)
	if e != nil || !d.Eligible || d.Side != 0 || len(d.Missing) == 0 {
		t.Fatal("完全対称を固定方向で埋めた", e)
	}
}

// TestStrongRecoveryAndGuards123 は構造が方向を決める反転と勢い・量・失速の必須性を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestStrongRecoveryAndGuards123(t *testing.T) {
	recovery := func(p *rules.Publication, i int) {
		if p.Frame.Frame.Width != 300 || i != 3 {
			return
		}
		f := &p.Frame.Frame
		f.OHLC = rules.OHLC{Open: 88, High: 110, Low: 85, Close: 95}
		x := &f.Technical
		x.Gap = value123(-6)
		x.EMA8Delta = value123(-2)
		x.EMA21Delta = value123(-1)
		x.RSI = value123(40)
		x.PreviousRSI = value123(30)
		x.Histogram = value123(-1)
		x.PreviousHistogram = value123(-2)
		x.TR = value123(25)
		p.Frame.DMI.PlusDI = value123(10)
		p.Frame.DMI.MinusDI = value123(30)
	}
	for _, mirror := range []bool{false, true} {
		b, w, q := scoreFixture123(t, false, mirror, recovery)
		q.Last = 96
		if mirror {
			q.Last = 304
		}
		d, e := score123(b, q, w)
		if e != nil {
			t.Fatal(e)
		}
		s, ok := strong123(d)
		want := 1
		if mirror {
			want = -1
		}
		if !ok || s.Strategy != "reversal" || s.Side != want || float64(want)*d.Score.Value >= 0 {
			t.Fatal("反転をADX又は総合score方向だけで決めた")
		}
		tie := d
		tie.Side = 0
		tie.Tie = "直近確定5分終値差"
		tie.Missing = []string{"方向同率が未解決"}
		resolved, ok := strong123(tie)
		if !ok || resolved.Side != want || len(resolved.Missing) != 0 || resolved.Tie == tie.Tie || len(tie.Missing) != 1 || resolved.Score != tie.Score {
			t.Fatal("構造解決後の診断又は呼出元の配列を変更")
		}
	}
	for _, bad := range []string{"ADX", "過熱", "量", "spike", "回復"} {
		b, w, q := scoreFixture123(t, false, false, func(p *rules.Publication, i int) {
			recovery(p, i)
			if p.Frame.Frame.Width != 300 || i != 3 {
				return
			}
			switch bad {
			case "ADX":
				p.Frame.DMI.ADX = value123(36)
			case "過熱":
				p.Frame.Frame.Technical.PreviousRSI = value123(50)
			case "量":
				p.Frame.Frame.Volume = 50
			case "spike":
				p.Frame.Frame.Technical.TR = value123(41)
			case "回復":
				p.Frame.Frame.OHLC.Low = 90
				p.Frame.Frame.OHLC.Open = 95
			}
		})
		q.Last = 96
		d, e := score123(b, q, w)
		if e != nil {
			t.Fatal(e)
		}
		if _, ok := strong123(d); ok {
			t.Fatalf("反転の必須条件を無視 %s", bad)
		}
	}
}

// TestScoreCausalWindowAndUpperOpposition123 は未来公表非参照・窓reset・上位逆向き拒否を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestScoreCausalWindowAndUpperOpposition123(t *testing.T) {
	b, w, q := scoreFixture123(t, true, false, nil)
	before, e := score123(b, q, w)
	if e != nil {
		t.Fatal(e)
	}
	future := scorePublication123("current", 300, 101, 100240)
	future.Frame.Frame.Technical.Gap = value123(-100)
	future.Frame.Frame.Technical.RSI = value123(1)
	if e = b.Add(future); e != nil {
		t.Fatal(e)
	}
	after, e := score123(b, q, w)
	if e != nil || before.Score != after.Score || before.Side != after.Side {
		t.Fatal("未来公表が過去scoreに混入", e)
	}
	gap := scorePublication123("current", 300, 200, 101140)
	w.observe(gap)
	if len(w.Five) != 1 {
		t.Fatal("非連続窓の補間")
	}
	gap.Frame.Frame.PriceKnown = false
	w.observe(gap)
	if len(w.Five) != 0 {
		t.Fatal("価格未知窓を継承")
	}
	b, w, q = scoreFixture123(t, true, false, func(p *rules.Publication, i int) {
		if p.Frame.Frame.Width == 1800 {
			p.Frame.Frame.Technical.Gap = value123(-6)
			p.Frame.Frame.Technical.EMA8Delta = value123(-2)
			p.Frame.Frame.Technical.EMA21Delta = value123(-1)
			p.Frame.DMI.PlusDI = value123(10)
			p.Frame.DMI.MinusDI = value123(30)
		}
	})
	d, e := score123(b, q, w)
	if e != nil {
		t.Fatal(e)
	}
	if s, ok := strong123(d); ok && s.Strategy == "trend" {
		t.Fatal("既知30分逆向きの通常順行を許可")
	}
}
