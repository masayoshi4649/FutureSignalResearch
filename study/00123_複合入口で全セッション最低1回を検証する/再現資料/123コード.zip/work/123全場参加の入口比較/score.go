package holdingohlc113

import (
	"math"
	"strconv"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

type Decision123 struct {
	At            rules.Quote            `json:"at"`
	Strategy      string                 `json:"strategy"`
	Eligible      bool                   `json:"eligible"`
	Side          int                    `json:"side"`
	Score         rules.Value            `json:"score"`
	Components    map[string]rules.Value `json:"components"`
	KnownCounts   map[string]int         `json:"known_counts"`
	Refs          []rules.Ref            `json:"refs"`
	StructureRefs []rules.Ref            `json:"structure_refs"`
	Missing       []string               `json:"missing"`
	Tie           string                 `json:"tie"`
	SourceFields  map[string]rules.Value `json:"source_fields,omitempty"`
}
type Window123 struct{ Five []rules.Publication }

// observe は当場の連続・価格既知5分公表だけを最大4本保持します。
//
// 引数: p(rules.Publication)。返り値: ありません。場・限月・欠足で窓を切ります。
func (w *Window123) observe(p rules.Publication) {
	f := p.Frame.Frame
	if f.Width != 300 {
		return
	}
	if !f.PriceKnown {
		w.Five = nil
		return
	}
	if len(w.Five) > 0 {
		old := w.Five[len(w.Five)-1].Frame.Frame
		if old.SessionID != f.SessionID || old.Contract != f.Contract || old.End != f.Start {
			w.Five = nil
		}
	}
	w.Five = append(w.Five, p)
	if len(w.Five) > 4 {
		w.Five = append([]rules.Publication{}, w.Five[len(w.Five)-4:]...)
	}
}

// value123 は有限な既知値を作ります。
//
// 引数: x(float64)。返り値: rules.Valueです。
func value123(x float64) rules.Value { return rules.Value{Known: finite(x), Value: x} }

// difference123 は両端が既知な差だけを作ります。
//
// 引数: a/b(rules.Value)。返り値: rules.Valueは未知を維持します。
func difference123(a, b rules.Value) rules.Value {
	if !a.Known || !b.Known {
		return rules.Value{}
	}
	return value123(a.Value - b.Value)
}

// sign123 は未知を支持0に変えず符号を返します。
//
// 引数: v(rules.Value)。返り値: rules.Valueです。
func sign123(v rules.Value) rules.Value {
	if !v.Known {
		return rules.Value{}
	}
	x := 0.0
	if v.Value > 0 {
		x = 1
	} else if v.Value < 0 {
		x = -1
	}
	return value123(x)
}

// mean123 は既知成分だけを分母にして平均します。
//
// 引数: values(...rules.Value)。返り値: rules.Value/intは平均と既知数です。
func mean123(values ...rules.Value) (rules.Value, int) {
	sum, n := 0.0, 0
	for _, v := range values {
		if v.Known {
			sum += v.Value
			n++
		}
	}
	if n == 0 {
		return rules.Value{}, 0
	}
	return value123(sum / float64(n)), n
}

// reference123 は現在までに配送された公表の参照を作ります。
//
// 引数: p(rules.Publication)。返り値: rules.Refです。
func reference123(p rules.Publication) rules.Ref {
	f := p.Frame.Frame
	return rules.Ref{ID: f.ID, Width: f.Width, End: f.End, Delivered: p.Stamp}
}

// score123 は5/15/30の方向、5分の勢い・価格・値幅・量を当時値で分解します。
//
// 引数: bank(*rules.Bank)、q(Quote)、window(*Window123)。返り値: Decision123/errorです。
func score123(bank *rules.Bank, q Quote, window *Window123) (Decision123, error) {
	d := Decision123{At: quote123(q), Strategy: "deadline", Components: map[string]rules.Value{}, KnownCounts: map[string]int{}, Refs: []rules.Ref{}, StructureRefs: []rules.Ref{}, Missing: []string{}}
	s, e := bank.Current(quote123(q))
	if e != nil {
		return d, e
	}
	d.Refs = append(d.Refs, s.Refs...)
	trends := []rules.Value{}
	for _, width := range []int{300, 900, 1800} {
		prefix := strconv.Itoa(width/60) + "_"
		p, ok := s.Frames[width]
		tf := rules.Value{}
		count := 0
		if ok && p.Frame.Frame.PriceKnown {
			t, di := p.Frame.Frame.Technical, p.Frame.DMI
			terms := []struct {
				key string
				v   rules.Value
			}{{"gap", t.Gap}, {"ema8_delta", t.EMA8Delta}, {"ema21_delta", t.EMA21Delta}, {"di_delta", difference123(di.PlusDI, di.MinusDI)}}
			values := []rules.Value{}
			for _, term := range terms {
				d.Components[prefix+term.key] = term.v
				signed := sign123(term.v)
				d.Components[prefix+term.key+"_sign"] = signed
				values = append(values, signed)
			}
			tf, count = mean123(values...)
		}
		d.Components[prefix+"T"] = tf
		d.KnownCounts[prefix+"T"] = count
		trends = append(trends, tf)
	}
	t, count := mean123(trends...)
	d.Components["T"] = t
	d.KnownCounts["T_scales"] = count
	p, ok := s.Frames[300]
	if !ok || !p.Frame.Frame.PriceKnown {
		d.Missing = append(d.Missing, "当場fresh価格既知5分がない")
		return d, nil
	}
	f := p.Frame.Frame
	tech := f.Technical
	c := d.Components
	c["RSI5"], c["previous_RSI5"], c["Hist5"], c["previous_Hist5"] = tech.RSI, tech.PreviousRSI, tech.Histogram, tech.PreviousHistogram
	rsiCenter := difference123(tech.RSI, value123(50))
	rsiDelta := difference123(tech.RSI, tech.PreviousRSI)
	histDelta := difference123(tech.Histogram, tech.PreviousHistogram)
	c["RSI_center"], c["RSI_delta"], c["Hist_delta"] = rsiCenter, rsiDelta, histDelta
	m, mn := mean123(sign123(rsiCenter), sign123(tech.Histogram), sign123(rsiDelta), sign123(histDelta))
	c["M"] = m
	d.KnownCounts["M"] = mn
	c["O5"], c["H5"], c["L5"], c["C5"], c["Last"] = value123(f.OHLC.Open), value123(f.OHLC.High), value123(f.OHLC.Low), value123(f.OHLC.Close), value123(q.Last)
	c["body"], c["close_position"], c["last_close"] = value123(f.OHLC.Close-f.OHLC.Open), value123(2*f.OHLC.Close-f.OHLC.High-f.OHLC.Low), value123(q.Last-f.OHLC.Close)
	position, pn := mean123(sign123(c["body"]), sign123(c["close_position"]), sign123(c["last_close"]))
	c["P"] = position
	d.KnownCounts["P"] = pn
	c["ATR5"], c["previous_ATR5"], c["TR5"], c["RVOL5"] = tech.ATR, tech.PreviousATR, tech.TR, s.RVOL5
	c["ADX5"], c["previous_ADX5"] = p.Frame.DMI.ADX, p.Frame.DMI.PreviousADX
	if !c["5_T"].Known {
		d.Missing = append(d.Missing, "5分方向の既知成分なし")
	}
	if !m.Known {
		d.Missing = append(d.Missing, "5分勢いの既知成分なし")
	}
	volatility := tech.ATR.Known && tech.PreviousATR.Known && tech.TR.Known && tech.ATR.Value > 0 && tech.PreviousATR.Value > 0 && tech.TR.Value >= 0
	if !volatility {
		d.Missing = append(d.Missing, "正のATR/前ATR又はTRが不足")
	}
	if window != nil && len(window.Five) > 0 && window.Five[len(window.Five)-1].Frame.Frame.ID == f.ID {
		if len(window.Five) >= 2 {
			prev := window.Five[len(window.Five)-2]
			c["previous_C5"] = value123(prev.Frame.Frame.OHLC.Close)
			c["tie_close_delta"] = value123(f.OHLC.Close - prev.Frame.Frame.OHLC.Close)
			d.StructureRefs = append(d.StructureRefs, reference123(prev))
		}
		if len(window.Five) == 4 {
			low, high := math.Inf(1), math.Inf(-1)
			for _, old := range window.Five[:3] {
				low = math.Min(low, old.Frame.Frame.OHLC.Low)
				high = math.Max(high, old.Frame.Frame.OHLC.High)
			}
			c["prior3_low"], c["prior3_high"] = value123(low), value123(high)
			d.StructureRefs = []rules.Ref{}
			for _, old := range window.Five[:3] {
				d.StructureRefs = append(d.StructureRefs, reference123(old))
			}
		}
	}
	if len(d.Missing) > 0 {
		return d, nil
	}
	v := tech.TR.Value / tech.PreviousATR.Value
	if !finite(v) {
		d.Missing = append(d.Missing, "値幅比が非有限")
		return d, nil
	}
	g := 1.0
	if v > 0 {
		g = math.Min(1, 2/v)
	}
	u := 0.0
	if s.RVOL5.Known {
		u = math.Min(1, math.Max(0, s.RVOL5.Value))
	}
	c["v"], c["g"], c["u"] = value123(v), value123(g), rules.Value{Known: s.RVOL5.Known, Value: u}
	denominator := 1 + g*(2+u)
	score := (t.Value + g*(m.Value+(1+u)*position.Value)) / denominator
	d.Score = value123(score)
	c["S"] = d.Score
	c["S_denominator"] = value123(denominator)
	d.Eligible = true
	d.Side = int(sign123(d.Score).Value)
	if d.Side == 0 {
		tie := sign123(c["tie_close_delta"])
		d.Tie = "直近確定5分終値差"
		if tie.Known {
			d.Side = int(tie.Value)
		}
		if d.Side == 0 {
			d.Missing = append(d.Missing, "方向同率が未解決")
		}
	}
	return d, nil
}

// strong123 は通常の順行又は回復反転を方向に依存しない順番で検査します。
//
// 引数: d(Decision123)。返り値: Decision123/boolは強い入口票と成立です。
func strong123(d Decision123) (Decision123, bool) {
	if !d.Eligible {
		return d, false
	}
	c := d.Components
	if !c["RVOL5"].Known || c["RVOL5"].Value < 1 || c["TR5"].Value > 2*c["previous_ATR5"].Value {
		return d, false
	}
	for _, side := range []int{1, -1} {
		s := float64(side)
		passed := true
		for _, key := range []string{"5_gap", "5_ema8_delta", "5_ema21_delta", "5_di_delta"} {
			if !c[key].Known || s*c[key].Value <= 0 {
				passed = false
			}
		}
		for _, key := range []string{"15_T", "30_T"} {
			if c[key].Known && s*c[key].Value < 0 {
				passed = false
			}
		}
		rsi := c["RSI5"]
		if !rsi.Known || s*(rsi.Value-50) < 0 || s*(rsi.Value-50) > 20 || !c["Hist5"].Known || s*c["Hist5"].Value <= 0 || s*c["M"].Value <= 0 || s*c["P"].Value <= 0 || math.Abs(d.Score.Value) < .5 {
			passed = false
		}
		if passed {
			return strongResolved123(d, "trend", side), true
		}
	}
	if !c["prior3_low"].Known || !c["prior3_high"].Known || !c["previous_RSI5"].Known || !c["RSI_delta"].Known || !c["Hist_delta"].Known || !c["ADX5"].Known || !c["previous_ADX5"].Known || c["ADX5"].Value >= c["previous_ADX5"].Value {
		return d, false
	}
	for _, side := range []int{1, -1} {
		s := float64(side)
		extreme, boundary := c["L5"].Value, c["prior3_low"].Value
		if side < 0 {
			extreme, boundary = c["H5"].Value, c["prior3_high"].Value
		}
		if s*(c["previous_RSI5"].Value-50) <= -15 && s*c["RSI_delta"].Value > 0 && s*c["Hist_delta"].Value > 0 && s*(extreme-boundary) < 0 && s*(c["C5"].Value-boundary) >= 5 && c["C5"].Value >= c["prior3_low"].Value && c["C5"].Value <= c["prior3_high"].Value && s*(c["Last"].Value-boundary) >= 5 {
			return strongResolved123(d, "reversal", side), true
		}
	}
	return d, false
}

// strongResolved123 は強い構造で方向が決まった票の未解決表示だけを整えます。
//
// 引数: d(Decision123)、strategy(string)、side(int)。返り値: Decision123です。
// 数値条件を変更せず、呼出元のMissing配列を共有更新しません。
func strongResolved123(d Decision123, strategy string, side int) Decision123 {
	d.Strategy = strategy
	d.Side = side
	missing := []string{}
	for _, reason := range d.Missing {
		if reason != "方向同率が未解決" {
			missing = append(missing, reason)
		}
	}
	d.Missing = missing
	if d.Tie != "" {
		d.Tie = "通常" + strategy + "条件で方向解決"
	}
	return d
}
