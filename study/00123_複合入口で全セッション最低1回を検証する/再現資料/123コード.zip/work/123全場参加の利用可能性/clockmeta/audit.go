package holdingohlc113

import (
	"bufio"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
	"math"
	"os"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// Audit は初日だけを価格時計/正常BBO/履歴長metadataに限定して再走査します。
//
// 引数: path/expected/session/contract(string)、start/end/force(float64)、pubs([]rules.Publication)。
// 返り値: map[string]any/error。OHLC/TR/ATR数値・売買/先着/損益は新計算しません。
func Audit(path, expected, session, contract string, start, end, force float64, pubs []rules.Publication) (map[string]any, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	before, err := f.Stat()
	if err != nil {
		return nil, err
	}
	h := sha256.New()
	tee := io.TeeReader(f, h)
	z, err := gzip.NewReader(tee)
	if err != nil {
		return nil, err
	}
	defer z.Close()
	bank := rules.NewBank()
	if err = bank.StartSession(session, contract); err != nil {
		return nil, err
	}
	scanner := bufio.NewScanner(z)
	scanner.Buffer(make([]byte, 65536), 8*1024*1024)
	quality := Counts{}
	contracts := map[string]bool{}
	scene := Scene{Session: session, Contract: contract, Start: start, End: end}
	index := int64(0)
	previous := start
	pi := 0
	var firstNormal, lastNormal, lastNormalBeforeForce *Quote
	var currentStart, lastTime float64
	hasCurrent := false
	history := 0
	closed, stale, eligible, resets, gapMinutes, pubMissing, historyMissing := 0, 0, 0, 0, 0, 0, 0
	gaps := []map[string]any{}
	ready := []map[string]any{}
	for scanner.Scan() {
		quality.Lines++
		q, _, next, e := decodeRow(scanner.Bytes(), quality.Lines, index, scene, previous, &quality, contracts)
		previous = next
		if e != nil {
			return nil, e
		}
		if q == nil {
			continue
		}
		index++
		for pi < len(pubs) && int64(pubs[pi].Stamp.Index) <= q.Index {
			p := pubs[pi]
			if int64(p.Stamp.Index) != q.Index || int64(p.Stamp.Line) != q.SourceLine || p.Stamp.Time != q.Time {
				return nil, fmt.Errorf("公表配送行差")
			}
			if e = bank.Add(p); e != nil {
				return nil, e
			}
			pi++
		}
		if q.QuoteOK {
			x := *q
			if firstNormal == nil {
				firstNormal = &x
			}
			lastNormal = &x
			if q.Time < force {
				lastNormalBeforeForce = &x
			}
		}
		minute := math.Floor(q.Time/60) * 60
		if !hasCurrent {
			currentStart = minute
			hasCurrent = true
			lastTime = q.Time
			continue
		}
		if q.Time-lastTime > 60 {
			resets++
			gaps = append(gaps, map[string]any{"previous_time": lastTime, "time": q.Time, "seconds": q.Time - lastTime, "index": q.Index, "source_line": q.SourceLine})
			if minute != currentStart+60 && minute != currentStart {
				gapMinutes++
			}
			history = 0
			currentStart = minute
			lastTime = q.Time
			continue
		}
		if minute != currentStart {
			barEnd := currentStart + 60
			closed++
			if q.Time-barEnd > 30 {
				stale++
			}
			if minute != barEnd {
				history = 0
				gapMinutes++
			} else {
				if q.Time-barEnd <= 30 {
					eligible++
					snapshot, e := bank.Current(rules.Quote{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine), Last: 1})
					if e != nil {
						return nil, e
					}
					if len(snapshot.Missing) > 0 {
						pubMissing++
					} else if history < 15 {
						historyMissing++
					} else {
						atr := snapshot.Frames[300].Frame.Frame.Technical.ATR
						ready = append(ready, map[string]any{"time": q.Time, "bar_end": barEnd, "index": q.Index, "source_line": q.SourceLine, "prior_closed_bars": history, "atr5_known_positive": atr.Known && atr.Value > 0, "normal_bbo": q.QuoteOK})
					}
				}
				history++
				if history > 20 {
					history = 20
				}
			}
			currentStart = minute
		}
		lastTime = q.Time
	}
	if err = scanner.Err(); err != nil {
		return nil, err
	}
	if _, err = io.Copy(io.Discard, tee); err != nil {
		return nil, err
	}
	after, err := f.Stat()
	if err != nil {
		return nil, err
	}
	sha := hex.EncodeToString(h.Sum(nil))
	if sha != expected || before.Size() != after.Size() || before.ModTime() != after.ModTime() || len(contracts) != 1 || !contracts[contract] || pi != len(pubs) {
		return nil, fmt.Errorf("Raw/Scope/公表終端差")
	}
	return map[string]any{"session": session, "raw_sha256": sha, "quality": quality, "first_normal_bbo": firstNormal, "last_normal_bbo": lastNormal, "last_normal_before_force_close": lastNormalBeforeForce, "closed_minute_bars": closed, "stale_closures": stale, "eligible_closures": eligible, "raw_gap_resets": resets, "gap_resets": gapMinutes, "publication_missing": pubMissing, "clock_implied_atr1_history_missing": historyMissing, "history_ready_and_three_price_ready": ready, "raw_gaps": gaps, "ohlc_or_atr_value_recalculated": false, "financial_replay": false}, nil
}
