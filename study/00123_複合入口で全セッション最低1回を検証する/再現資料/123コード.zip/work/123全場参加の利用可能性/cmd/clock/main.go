package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"

	clock "availability123/clockmeta"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// main は初日の許可された時計監査だけを実行します。
//
// 引数: なし。返り値: なし。他72場Rawと金融勝敗を読みません。
func main() {
	data, err := os.ReadFile("../122全場入力/入力.json")
	if err != nil {
		panic(err)
	}
	h := sha256.Sum256(data)
	if hex.EncodeToString(h[:]) != "6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec" {
		panic("固定InputSHA差")
	}
	var input struct {
		Scenes []struct {
			Session  string  `json:"session"`
			Contract string  `json:"contract"`
			Start    float64 `json:"start"`
			End      float64 `json:"end"`
			Force    float64 `json:"force_close"`
			Raw      struct {
				Path string `json:"path"`
				SHA  string `json:"sha256"`
			} `json:"raw"`
			Pubs []rules.Publication `json:"publications"`
		} `json:"scenes"`
	}
	if err = json.Unmarshal(data, &input); err != nil {
		panic(err)
	}
	s := input.Scenes[0]
	if s.Session != "2026-09-21_Day" {
		panic("初日以外は読まない")
	}
	result, err := clock.Audit(s.Raw.Path, s.Raw.SHA, s.Session, s.Contract, s.Start, s.End, s.Force, s.Pubs)
	if err != nil {
		panic(err)
	}
	bytes, err := json.MarshalIndent(result, "", "  ")
	if err != nil {
		panic(err)
	}
	f, err := os.OpenFile("初日の時計監査.json", os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if err != nil {
		panic(err)
	}
	defer f.Close()
	if _, err = f.Write(append(bytes, '\n')); err != nil {
		panic(err)
	}
	fmt.Println("初日の時計・最初末尾正常BBOだけを監査しました。OHLC/ATR数値と勝敗は計算していません。")
}
