"""
公表既知性と初日の時計監査だけを要約し、金融勝敗を使用しない。
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
from typing import Any


OWN = Path(__file__).resolve().parent
JST = timezone(timedelta(hours=9))


# ----------------------------------------
def stamp(value: float | None) -> str | None:
    """
    機能: 利用可能な価格時計をJSTへ表示する。
    引数: value(float | None)。返り値: str | None型。
    """
    return None if value is None else datetime.fromtimestamp(value, JST).strftime('%m/%d %H:%M:%S')


# ----------------------------------------
def contains(metric: dict, time: float) -> bool:
    """
    機能: 当時指標がknown/freshな半開区間へ価格時計が入るかを調べる。
    引数: metric(dict)、time(float)。返り値: bool型。実Rawや正常BBOの存在は含まない。
    """
    return any(w['start'] <= time < w['end'] for w in metric['windows'])


# ----------------------------------------
def table(headers: list[str], rows: list[list[Any]]) -> str:
    """
    機能: 要約用のMarkdown表を組む。
    引数: headers(list[str])、rows(list[list[Any]])。返り値: str型。
    """
    return '\n'.join(['| ' + ' | '.join(headers) + ' |', '| ' + ' | '.join(['---'] * len(headers)) + ' |', *['| ' + ' | '.join('—' if c is None else str(c) for c in row) + ' |' for row in rows]])


# ----------------------------------------
def main() -> None:
    """
    機能: 全73の初回/3h既知性と初日の履歴不足を短い資料へ保存する。
    引数: なし。返り値: None。Input/Raw/金融ラベルはここでは読まない。
    """
    detailed = OWN / '公表利用可能性_追加指標.json'
    audit = json.loads(detailed.read_text(encoding='utf-8'))
    first = json.loads((OWN / '初日の時計監査.json').read_text(encoding='utf-8'))
    scenes = audit['scenes']
    initial = scenes[0]
    for key in ('closed_minute_bars', 'stale_closures', 'eligible_closures', 'raw_gap_resets', 'gap_resets', 'publication_missing'):
        assert first[key] == initial['detector_stats'][key]
    assert first['quality'] == initial['quality']
    assert first['clock_implied_atr1_history_missing'] == initial['detector_stats']['atr1_unavailable'] == 177
    names = list(initial['metrics'])
    global_summary = {}
    for name in names:
        ready = [s for s in scenes if s['metrics'][name]['seconds_before_force_close'] > 0]
        before = [(s['metrics'][name]['first']['time'] - s['start'], s['session']) for s in ready]
        global_summary[name] = {'before_force_scenes': len(ready), 'at3h_scenes': sum(contains(s['metrics'][name], s['start'] + 10800) for s in scenes), 'initial_first_JST': stamp(initial['metrics'][name].get('first', {}).get('time')), 'latest_first_minutes_after_start': max(before)[0] / 60 if before else None, 'never_before_force': [s['session'] for s in scenes if s['metrics'][name]['seconds_before_force_close'] == 0]}
    primary = ['価格5', '価格15', '価格30', 'EMA5', 'EMA15', 'EMA30', 'ATR5', 'RSI5', 'RSI15', 'Hist5', 'RVOL5', 'BB15', 'DI30', 'ADX30', '前ADX30', 'E0必要指標', 'SMA3相当履歴と5分価格構造と量', 'P3短期値の完全可用']
    rows = []
    for s in scenes:
        for metric in s['metrics'].values():
            previous_end = s['start']
            for w in metric['windows']:
                assert s['start'] <= w['start'] < w['end'] <= s['end'] and previous_end <= w['start']
                previous_end = w['end']
        rows.append({'session': s['session'], 'common_1m': s['detector_stats']['policies']['E0/1']['considered'], 'raw_gap60': s['detector_stats']['raw_gap_resets'], 'first_JST': {name: stamp(s['metrics'][name].get('first', {}).get('time')) for name in primary}, 'at3h': {name: contains(s['metrics'][name], s['start'] + 10800) for name in primary}, 'e0_any_before_force': s['metrics']['E0必要指標']['seconds_before_force_close'] > 0})
    result = {'success': True, 'input_sha256': audit['input_sha256'], 'result_metadata_sha256': audit['result_sha256'], 'financial_labels_used': False, 'raw_read_scope': '初日だけの最初/末尾正常BBO・価格時計gap・履歴長。OHLC/ATR値は新計算しない。他72Raw未読。', 'metrics': global_summary, 'scenes': rows, 'clock_reconstruction_matches_fixed_counts': True, 'first_day_counts': {key: first[key] for key in ('closed_minute_bars', 'stale_closures', 'eligible_closures', 'raw_gap_resets', 'gap_resets', 'publication_missing', 'clock_implied_atr1_history_missing')}, 'detailed_sha256': hashlib.sha256(detailed.read_bytes()).hexdigest(), 'initial_clock_sha256': hashlib.sha256((OWN / '初日の時計監査.json').read_bytes()).hexdigest()}
    with (OWN / '全73場の利用可能性要約.json').open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(result, ensure_ascii=False, separators=(',', ':')) + '\n')
    timeline = table(['指標/必要履歴', '初日最初のknown/fresh JST', '期限前に一度でも利用可/73', '開始3hで利用可/73'], [[name, global_summary[name]['initial_first_JST'], global_summary[name]['before_force_scenes'], global_summary[name]['at3h_scenes']] for name in names])
    compact = table(['場', '共通1分数', 'Raw60秒超reset', 'EMA5初回', 'E0必要指標初回', '3h短期全値'], [[s['session'], s['common_1m'], s['raw_gap60'], s['first_JST']['EMA5'], s['first_JST']['E0必要指標'], '可' if s['at3h']['P3短期値の完全可用'] else '不可'] for s in rows])
    text = f'''# 全セッション参加に必要な当時情報の監査

2026-11-11。固定73場Inputの公表/metadataと122結果のquality/diagnosticだけを使う。勝敗ラベルや利益から閾値を選んでいない。詳細公表maskは作業領域にとどめ、正式保存向けは本MD・要約JSON・初日時計監査だけで足りる。

## 何が全場参加を妨げていたか

E0必要指標（当場freshな5/15/30価格、ATR5、BB15、RSI15、ADX30と前ADX30）が新規期限前に一度も揃わないDayが9場ある：{', '.join(global_summary['E0必要指標']['never_before_force'])}。全場参加の補完にも長期成熟指標を必須にすると、これらは条件を待ち続ける。

初日9/21 Dayの「共通1分1回」は、方向の弱さで1回へ選別された意味ではない。閉鎖243足のうち30秒超遅れ23、評価可能220。公表不足25、前ATR1履歴不足177、ATR5不足15、スパイク2、残り1だった。価格時計60秒超で1分形成/履歴を捨てるresetは103回。初日のRawを時計だけ再生すると閉鎖/遅れ/公表不足と履歴不足177が既存集計へ完全一致した。

1分の14本TR履歴が時計上そろい三足価格もある瞬間は18回。うちATR5が既知なのは10:12:00/10:13:08の2回だけだった。保存されたスパイク拒否等と合わさって共通1回になる。OHLC/TR/ATR値は新計算していないので、この2回のどちらが残ったかは断定しない。1分連続性を補完入口にも必須とすれば、pubの5分指標が利用可能でも入口を大幅に失う。

## 当時いつ利用可能だったか

EMAはEMA8とEMA21の両方、EMA傾きは両方の前回差が既知。DIは+DI/−DIの両方。RVOL5とBB15は固定Bank118の同限月窓carry/欠足resetで再形成し、未知/0分母を0へ補っていない。全て当場公表・price_known・freshを要求する。表の時刻は公表配送価格時計で、実受信時計ではない。

{timeline}

## 期限とfallbackの入力要件

開始3hの時計では、5分EMA8/21・両傾き・DI・ATR/前ATR・TR・RSI/前RSI・Hist/前Hist・RVOLは73/73場でknown/freshだった。P3の短期複合スコアに必要な値の入力基盤は全場にある。一方、同じ3hでE0必要指標は54場だけ。15/30成熟値は利用できた範囲をmaskで示し、未知を支持票にしない設計が必要である。

開始を早める案では、直近3本の連続確定5分価格からの短い平均、前2本高安/実体・終値位置、観測量変化という複数技法が使える。この履歴は73/73で開始17分37秒までに揃い、20/30/60/120/180分の各時計でも全73で利用可だった。平均線・構造・量の役割を分ける案であり、単独の1指標で埋める案ではない。完全EMA5を必須にすると初日は10:31まで必要で、3本平均の短履歴案と区別する。

「入力が利用可能」と「方向が非0」「次の正常BBOで取得できる」は別である。完全対称な価格列では、符号鏡像を保ちながら必ず片側を選ぶことはできない。価格clockの1秒条件と30秒TTL、Source新規期限までの正常BBOも必要となる。全場1取得は実再生で検証し、方向未解決や正常気配/時間不足を分母から落とさない。初日以外72Rawは今回再読しておらず、その全ての締切後BBO存在まで保証していない。

初日の正常BBOは08:45:01〜15:39:59、15:35新規期限前の最終は15:34:57。初日を丸ごと「データなし」として落とす状況ではない。Source CurrentPriceTimeのgapであり、WebSocket受信が同秒数途絶えたとの解釈はしない。

## 全73場の要点

各場の初回known時刻、開始3hの既知mask、共通1分数とRaw gap数は要約JSONへ73場全て保存した。本文への重複転記を避け、未利用可能もnull/falseのまま残す。

## 保存・再現

[全73要約](全73場の利用可能性要約.json)、[初日の時計監査](初日の時計監査.json)。Input SHA `{audit['input_sha256']}`、結果metadata SHA `{audit['result_sha256']}`。既定コードとSourceDataを変更していない。Rawは初日canonicalを一走査し指紋/statを照合、複写せず、最初/末尾正常BBO・価格時計gap・履歴長だけを保存した。

Goの`main.go`が公表利用可能性、`cmd/clock`が初日限定時計監査、`要約する.py`が本資料を生成する。既存出力へ上書きしない。詳細JSONとコードの指紋を完了証跡へ記し、大型全件maskを正式成果へ転記しない。
'''
    with (OWN / 'README.md').open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(text)
    print(json.dumps({'成功': True, 'P3完全可用3h': global_summary['P3短期値の完全可用']['at3h_scenes'], 'E0必要指標3h': global_summary['E0必要指標']['at3h_scenes'], '要約bytes': (OWN / '全73場の利用可能性要約.json').stat().st_size, '初日時計bytes': (OWN / '初日の時計監査.json').stat().st_size}, ensure_ascii=False))


if __name__ == '__main__':
    main()
