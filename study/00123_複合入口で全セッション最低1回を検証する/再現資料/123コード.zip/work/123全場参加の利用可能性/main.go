package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"sort"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

type FileRef struct {
	Path string `json:"path"`
	SHA  string `json:"sha256"`
}
type Scene struct {
	Session    string              `json:"session"`
	Contract   string              `json:"contract"`
	Start      float64             `json:"start"`
	End        float64             `json:"end"`
	ForceClose float64             `json:"force_close"`
	Raw        FileRef             `json:"raw"`
	Pubs       []rules.Publication `json:"publications"`
}
type Input struct {
	Scenes []Scene `json:"scenes"`
}
type ResultMeta struct {
	Scenes []struct {
		Session string                     `json:"session"`
		Quality map[string]int64           `json:"quality"`
		Stats   map[string]json.RawMessage `json:"detector_stats"`
	} `json:"scenes"`
}
type Point struct {
	Time              float64 `json:"time"`
	Index             int     `json:"index"`
	Line              int     `json:"source_line"`
	ActualPublication bool    `json:"actual_publication"`
}
type Window struct {
	Start float64 `json:"start"`
	End   float64 `json:"end"`
}
type Available struct {
	First                   *Point   `json:"first,omitempty"`
	Windows                 []Window `json:"windows"`
	SecondsBeforeForceClose float64  `json:"seconds_before_force_close"`
}

var names = []string{"価格5", "価格15", "価格30", "観測量5", "EMA5", "EMA15", "EMA30", "EMA傾き5", "EMA傾き15", "EMA傾き30", "ATR5", "前ATR5", "TR5", "RSI5", "RSI5前値", "RSI15", "Hist5", "Hist5前値", "RVOL5", "BB15", "DI5", "DI15", "DI30", "ADX5", "ADX15", "ADX30", "前ADX30", "三足価格", "三足価格とATR5", "E0必要指標", "5分2本価格構造", "5分2本価格と量", "EMA5と5分2本価格と量", "SMA3相当履歴と5分価格構造と量", "5と15価格とEMA5とATR5", "P3短期値の完全可用"}

// digest は指定バイト列の指紋を返します。
//
// 引数: data([]byte)。返り値: string型SHA256です。
func digest(data []byte) string { s := sha256.Sum256(data); return hex.EncodeToString(s[:]) }

// ----------------------------------------
// metrics は公表済み値だけの既知性を判定し、売買方向や勝敗を使いません。
//
// 引数: snapshot(rules.Snapshot)、five([]rules.Publication)。返り値: map[string]bool型の利用可否です。
func metrics(snapshot rules.Snapshot, five []rules.Publication) map[string]bool {
	r := map[string]bool{}
	for _, w := range []int{300, 900, 1800} {
		p, ok := snapshot.Frames[w]
		f := p.Frame.Frame
		t := f.Technical
		d := p.Frame.DMI
		suffix := fmt.Sprint(w / 60)
		known := ok && f.PriceKnown
		r["価格"+suffix] = known
		r["EMA"+suffix] = known && t.EMA8.Known && t.EMA21.Known
		r["EMA傾き"+suffix] = known && t.EMA8Delta.Known && t.EMA21Delta.Known
		r["DI"+suffix] = known && d.PlusDI.Known && d.MinusDI.Known
		r["ADX"+suffix] = known && d.ADX.Known
		if w == 300 {
			r["ATR5"] = known && t.ATR.Known && t.ATR.Value > 0
			r["前ATR5"] = known && t.PreviousATR.Known && t.PreviousATR.Value > 0
			r["TR5"] = known && t.TR.Known
			r["RSI5"] = known && t.RSI.Known
			r["RSI5前値"] = known && t.PreviousRSI.Known
			r["Hist5"] = known && t.Histogram.Known
			r["Hist5前値"] = known && t.PreviousHistogram.Known
			r["観測量5"] = known && f.VolumeKnown
			r["RVOL5"] = known && snapshot.RVOL5.Known
		}
		if w == 900 {
			r["RSI15"] = known && t.RSI.Known
			r["BB15"] = known && snapshot.BB15.Known
		}
		if w == 1800 {
			r["前ADX30"] = known && d.PreviousADX.Known
		}
	}
	r["三足価格"] = r["価格5"] && r["価格15"] && r["価格30"]
	r["三足価格とATR5"] = r["三足価格"] && r["ATR5"]
	r["E0必要指標"] = r["三足価格とATR5"] && r["BB15"] && r["RSI15"] && r["ADX30"] && r["前ADX30"]
	consecutive := r["価格5"] && len(five) >= 2
	quantity := false
	three := false
	if consecutive {
		a, b := five[len(five)-2].Frame.Frame, five[len(five)-1].Frame.Frame
		consecutive = a.PriceKnown && b.PriceKnown && b.End-a.End == 300
		quantity = consecutive && a.VolumeKnown && b.VolumeKnown
		if len(five) >= 3 {
			c := five[len(five)-3].Frame.Frame
			three = quantity && c.PriceKnown && a.End-c.End == 300
		}
	}
	r["5分2本価格構造"] = consecutive
	r["5分2本価格と量"] = quantity
	r["EMA5と5分2本価格と量"] = r["EMA5"] && quantity
	r["SMA3相当履歴と5分価格構造と量"] = three
	r["5と15価格とEMA5とATR5"] = r["価格5"] && r["価格15"] && r["EMA5"] && r["ATR5"]
	r["P3短期値の完全可用"] = r["EMA5"] && r["EMA傾き5"] && r["DI5"] && r["ATR5"] && r["前ATR5"] && r["TR5"] && r["RSI5"] && r["RSI5前値"] && r["Hist5"] && r["Hist5前値"] && r["RVOL5"]
	return r
}

// ----------------------------------------
// audit は配送原行群とfresh失効境界で利用可能な時計区間を組みます。
//
// 引数: bank(*rules.Bank)、scene(Scene)。返り値: map[string]*Available/errorです。
// 区間内に必ず原行や正常BBOがあるとは主張しません。
func audit(bank *rules.Bank, scene Scene) (map[string]*Available, error) {
	if err := bank.StartSession(scene.Session, scene.Contract); err != nil {
		return nil, err
	}
	available := map[string]*Available{}
	state := map[string]bool{}
	began := map[string]float64{}
	for _, name := range names {
		available[name] = &Available{Windows: []Window{}}
	}
	var five []rules.Publication
	index, line := 0, 1
	probe := func(at float64, actual bool) error {
		s, e := bank.Current(rules.Quote{Time: at, Index: index, Line: line, Last: 1})
		if e != nil {
			return e
		}
		current := metrics(s, five)
		for _, name := range names {
			if current[name] && !state[name] {
				began[name] = at
				if available[name].First == nil {
					available[name].First = &Point{Time: at, Index: index, Line: line, ActualPublication: actual}
				}
			}
			if !current[name] && state[name] {
				if at > began[name] {
					available[name].Windows = append(available[name].Windows, Window{Start: began[name], End: at})
				}
			}
			state[name] = current[name]
		}
		return nil
	}
	if err := probe(scene.Start, false); err != nil {
		return nil, err
	}
	expires := map[float64]bool{}
	for _, p := range scene.Pubs {
		t := p.Frame.Frame.End + float64(p.Frame.Frame.Width) + 60
		if t > scene.Start && t <= scene.End {
			expires[t] = true
		}
	}
	expiry := []float64{}
	for t := range expires {
		expiry = append(expiry, t)
	}
	sort.Float64s(expiry)
	xp := 0
	for i := 0; i < len(scene.Pubs); {
		first := scene.Pubs[i]
		at := first.Stamp.Time
		for xp < len(expiry) && expiry[xp] < at {
			if err := probe(expiry[xp], false); err != nil {
				return nil, err
			}
			xp++
		}
		j := i
		for j < len(scene.Pubs) && scene.Pubs[j].Stamp == first.Stamp {
			p := scene.Pubs[j]
			if err := bank.Add(p); err != nil {
				return nil, err
			}
			if p.Frame.Frame.Width == 300 {
				five = append(five, p)
				if len(five) > 3 {
					five = five[len(five)-3:]
				}
			}
			j++
		}
		index, line = first.Stamp.Index, first.Stamp.Line
		if err := probe(at, true); err != nil {
			return nil, err
		}
		for xp < len(expiry) && expiry[xp] == at {
			xp++
		}
		i = j
	}
	for xp < len(expiry) {
		if err := probe(expiry[xp], false); err != nil {
			return nil, err
		}
		xp++
	}
	for _, name := range names {
		if state[name] && scene.End > began[name] {
			available[name].Windows = append(available[name].Windows, Window{Start: began[name], End: scene.End})
		}
		for _, w := range available[name].Windows {
			available[name].SecondsBeforeForceClose += math.Max(0, math.Min(w.End, scene.ForceClose)-w.Start)
		}
	}
	return available, nil
}

// ----------------------------------------
// main は許可された固定Inputと結果metadataだけで全73場の指標履歴を監査します。
//
// 引数: なし。返り値: なし。Raw/価格CSV/勝敗を読み直したり損益を計算しません。
func main() {
	inputPath := "../122全場入力/入力.json"
	resultPath := "../122全場入口比較/全73場の入口結果.json"
	inputBytes, err := os.ReadFile(inputPath)
	if err != nil {
		panic(err)
	}
	inputSHA := digest(inputBytes)
	if inputSHA != "6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec" {
		panic("固定InputSHA差")
	}
	resultBytes, err := os.ReadFile(resultPath)
	if err != nil {
		panic(err)
	}
	resultSHA := digest(resultBytes)
	if resultSHA != "667193822462a71e1164db81aa2bed41ac31afd96ef6b8ddc141add321482c62" {
		panic("固定結果SHA差")
	}
	var input Input
	var result ResultMeta
	if err = json.Unmarshal(inputBytes, &input); err != nil {
		panic(err)
	}
	if err = json.Unmarshal(resultBytes, &result); err != nil {
		panic(err)
	}
	if len(input.Scenes) != 73 || len(result.Scenes) != 73 {
		panic("全73場でない")
	}
	bank := rules.NewBank()
	rows := []map[string]any{}
	for i, scene := range input.Scenes {
		if scene.Session != result.Scenes[i].Session {
			panic("場対応差")
		}
		available, err := audit(bank, scene)
		if err != nil {
			panic(err)
		}
		rows = append(rows, map[string]any{"session": scene.Session, "contract": scene.Contract, "start": scene.Start, "end": scene.End, "force_close": scene.ForceClose, "raw": scene.Raw, "metrics": available, "quality": result.Scenes[i].Quality, "detector_stats": result.Scenes[i].Stats})
	}
	if bytes, err := os.ReadFile(inputPath); err != nil || digest(bytes) != inputSHA {
		panic("Input前後差")
	}
	if bytes, err := os.ReadFile(resultPath); err != nil || digest(bytes) != resultSHA {
		panic("結果前後差")
	}
	data, err := json.MarshalIndent(map[string]any{"success": true, "input_sha256": inputSHA, "result_sha256": resultSHA, "scenes": rows, "raw_read": 0, "financial_labels_used": false, "financial_replay": false, "clock": "価格時計、公表配送原行及びfresh失効境界。連続区間に実Raw/正常BBO存在を保証しない"}, "", "  ")
	if err != nil {
		panic(err)
	}
	f, err := os.OpenFile("公表利用可能性_追加指標.json", os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if err != nil {
		panic(err)
	}
	defer f.Close()
	if _, err = f.Write(append(data, '\n')); err != nil {
		panic(err)
	}
	fmt.Println("全73場の公表利用可能性を保存しました。Raw/勝敗再計算なし。")
}
