# 123の3表CSV出力

Rootが固定したJSONの`tables`三表を転記する。表名は`候補別集計`、`全セッション`、`入口明細`。ヘッダ・列順・行順・全セルの値と型を保持し、列数・行数は任意。0行の表もヘッダだけで保存できる。参加判定・先着率・費用等は入力表を保持し、この器では金融を再集計しない。

123の主はP3・60分±125pt、対照はE0、開始時間比較はP2/P4。主全セッションは73行、候補別は4政策×2期限を基本とし、最終形はRootの表JSONへ従う。入口明細は全政策・期限を保持し、候補0・取得0・未取得・観測不足を出力器で削除/補完しない。独立mini1枚の期限評価を、片側10枚の運用口座損益へ合算しない。

Node 24.22.1、`@oai/artifact-tool` 2.8.129を固定する。`node_modules`は既存runtimeへのjunctionで、依存自体を変更しない。セルは文字列・有限数値・boolean・null、安全整数範囲外は拒否する。率0.7は70%で、表示用に100倍しない。新xlsxは生成しない。

## Rootによる自然出力

自然の表JSONとSHA256を固定した後、最初の作成直前にRootが`create/3/csv`の操作記録を一度実行する。三つの成果CSVが対象で、同じ作成操作の再試行では記録を重ねない。builderと独立再読器は記録を自動実行しない。人工データだけの試験では自然出力用markerを実行しない。

```powershell
$nodeExe = 'C:/Users/masay/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe'
& $nodeExe 'C:/Users/masay/.codex/plugins/cache/openai-primary-runtime/spreadsheets/26.1104.22356/skills/spreadsheets/container_tools/mark_artifact_operation_started.mjs' --operation-kind create --expected-output-count 3 --output-format csv
& $nodeExe 'work/123全場CSV出力/出力する.mjs' --input 'Rootの確定表.json' --sha256 '64桁SHA256' --output '未作成CSVフォルダ'
C:/Python314/python.exe -X utf8 'work/123全場CSV出力/CSVを独立再読する.py' --input 'Rootの確定表.json' --sha256 '64桁SHA256' --folder '作成したCSVフォルダ' --output 'work/123全場CSV出力/全73独立再読.json'
```

出力先は未作成を要求し、既存成果へ上書きしない。CSVはUTF-8 BOM・CRLF。nullは空欄、数値0は`0`、booleanは小文字`true`/`false`。先頭零・改行・引用符・式に見える文字は文字として保持する。CSV単体ではnullと空文字が共に空欄のため、元JSONの型を基準に照合する。

## 検査と表示

三表のヘッダと全データをWorkbookへ型付き投入し、再計算後の全セルを元JSONの型と値へ照合する。数式0とエラー走査を記録してからCSVを保存する。所与の値を再計算する数式は作らない。元JSONの`#N/A`等は同一の文字列として保持する。

各表のA1:G5以内を固定幅・倍率1で描画する。列幅合計は候補別830px、全セッション845px、入口明細895pxで、右端の端切れを避ける。自然のヘッダが長い場合はRootが自然作成後の三画像を視認して確認する。プレビューはCSV全列・全行の代わりではない。

`CSVの確認.json`は入力前後SHA、出力SHA・行列数、型付き全セル照合、依存版、コードSHAを持つ。独立再読器は標準csv/Decimalだけを用い、数値は許容差なし、文字列も先頭零を含め完全一致で比較する。nullと数値0を分け、JSON/CSVの前後SHAも確認する。

## 人工検査と編集停止

2026-11-11。122器から表名・表数・試行番号・プレビュー幅を適応した。三表各3行×8列の人工入力は72データセル・27数値、ヘッダを加え96セルで一致した。入口明細0行の人工変種も48データセル・18数値、ヘッダ込み72セルで一致した。構文検査と標準csv/Decimal独立再読が成功し、三表の画像と0行明細画像を視認した。他二画像は人工変種でも同bytesを確認する。

先頭零IDは画像側で短縮表示されるが、CSVと型付き照合では元の文字値を保持する。人工の真偽値は画像でチェックボックス表示となり、CSVは`true`/`false`を保持した。自然成果の視認成功は先取りしない。

自然123の結果・表・入力・Rawは未読、自然CSV未作成、marker未実行。準備proofへ指紋と検査範囲を保存し、CSV器の編集を停止する。具体金融仕様や文書更新はこの器の停止と別工程である。
