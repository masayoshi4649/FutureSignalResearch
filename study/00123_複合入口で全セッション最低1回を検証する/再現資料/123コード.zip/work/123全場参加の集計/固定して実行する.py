"""123の全条件・コード・入力を固定し、同じ指紋だけで73場を再生する。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import subprocess

ROOT=Path(__file__).resolve().parents[2]
OWN=Path(__file__).resolve().parent
RUN=ROOT/'work/123全場参加の入口比較'
FORMAL=ROOT/'study/00123_複合入口で全セッション最低1回を検証する'
INPUT=ROOT/'work/122全場入力/入力.json'
INPUT_SHA='6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec'


def sha(path: Path) -> str:
    """
    機能: ファイルの全バイトをSHA256で指紋化する。
    引数: path(Path)。返り値: strは小文字16進の指紋。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def save(path: Path, value: dict) -> None:
    """
    機能: 未作成先だけへ固定記録を保存する。
    引数: path(Path)、value(dict)。返り値: None。
    """
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')


# ----------------------------------------
def main() -> None:
    """
    機能: 再生前固定と固定後実行を分け、入力・コードの前後同体を検査する。
    引数: CLIの--mode(str、固定/実行)。返り値: None。
    """
    parser=argparse.ArgumentParser(description='123の条件を固定して全場を再生する')
    parser.add_argument('--mode',choices=('固定','実行'),required=True)
    mode=parser.parse_args().mode
    fixed=OWN/'再生前固定.json'
    if mode=='固定':
        assert sha(INPUT)==INPUT_SHA
        source=json.loads(INPUT.read_text(encoding='utf-8'))
        sessions=[s['session'] for s in source['scenes']]
        available=sorted(p.name for p in (ROOT.parent/'JP_OSE_Data/future/NK225').iterdir() if p.is_dir() and (p/'book.jsonl').is_file())
        assert len(sessions)==73 and sorted(sessions)==available
        files=set()
        for folder in (RUN,OWN,ROOT/'work/118複数技法の入口条件',ROOT/'work/121入口の反転切替'):
            assert folder.is_dir()
            files.update(p for p in folder.rglob('*') if p.is_file() and (p.suffix in ('.go','.py') or p.name=='go.mod'))
        docs=[FORMAL/'README.md',FORMAL/'設定と結果.md',RUN/'事前条件.md']
        assert all(p.is_file() for p in docs)
        exe=RUN/'入口比較.exe'
        assert exe.is_file()
        value={'試行':123,'成功':True,'固定UTC':datetime.now(timezone.utc).isoformat(),
               '主候補':'P3','主先着幅pt':125,'主時間秒':3600,'参加条件':'73場すべて最低1回の取得代用',
               '全候補':['E0','P2','P3','P4'],'P2P3P4期限秒':[7200,10800,14400],
               '入力':{'path':str(INPUT),'sha256':INPUT_SHA,'bytes':INPUT.stat().st_size},
               '対象全場':sessions,
               'コード':{str(p):sha(p) for p in sorted(files)},
               '実行前文書':{str(p):sha(p) for p in docs},
               '実行ファイル':{'path':str(exe),'sha256':sha(exe)},
               '実口座収支':False,'未知データ検証':False,'注記':'全73場は122で既知。新仕様をこの再生前に固定した研究内比較。'}
        save(fixed,value)
        print(json.dumps({'固定':True,'SHA256':sha(fixed),'コード数':len(files)},ensure_ascii=False))
        return
    # ----------------------------------------
    f=json.loads(fixed.read_text(encoding='utf-8'))
    assert f['成功'] and f['試行']==123
    expected=dict(f['コード'])
    expected.update(f['実行前文書'])
    expected[f['入力']['path']]=f['入力']['sha256']
    expected[f['実行ファイル']['path']]=f['実行ファイル']['sha256']
    assert all(sha(Path(p))==s for p,s in expected.items())
    output=RUN/'全73場の入口結果.json'
    assert not output.exists()
    command=[f['実行ファイル']['path'],'--input',f['入力']['path'],'--sha256',f['入力']['sha256'],'--output',str(output),'--workers','8']
    subprocess.run(command,cwd=RUN,check=True)
    assert all(sha(Path(p))==s for p,s in expected.items())
    value=json.loads(output.read_text(encoding='utf-8'))
    assert value['success'] and value['trial']==123 and len(value['scenes'])==73
    assert all(s['success'] for s in value['scenes'])
    save(OWN/'再生完了.json',{'試行':123,'成功':True,'固定SHA256':sha(fixed),'入力コード文書前後同体':True,
                             '結果':{'path':str(output),'sha256':sha(output),'bytes':output.stat().st_size},'コマンド':command})
    print(json.dumps({'完了':True,'結果SHA256':sha(output)},ensure_ascii=False))


if __name__=='__main__':
    main()
