"""複合入口の参加条件と同幅先着を、固定済み73場の全件から集計する。"""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone, timedelta
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
RUN = ROOT / 'work/123全場参加の入口比較'
POLICIES = ('E0', 'P2', 'P3', 'P4')
WIDTHS = (25, 50, 100, 125, 200)
HORIZONS = (1800, 3600)


def sha(path: Path) -> str:
    """
    機能: ファイルの全バイトの指紋を求める。
    引数: path(Path)。返り値: strはSHA256小文字16進表記。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def jst(value: float | None) -> str | None:
    """
    機能: 原価格時計を日本標準時の文字列へ変換する。
    引数: value(float|None)。返り値: str|None。
    """
    return None if value is None else datetime.fromtimestamp(value, timezone(timedelta(hours=9))).isoformat(sep=' ')


# ----------------------------------------
def outcome(candidate: dict, seconds: int) -> dict | None:
    """
    機能: 取得済み候補の指定期限の観測を選ぶ。
    引数: candidate(dict)、seconds(int)。返り値: dict|None。
    """
    return next((o for o in candidate['outcomes'] if o['seconds'] == seconds), None)


# ----------------------------------------
def touch(observation: dict, width: int) -> dict:
    """
    機能: 指定した同幅先着の観測を選ぶ。
    引数: observation(dict)、width(int)。返り値: dict。
    """
    return next(t for t in observation['touches'] if t['width'] == width)


# ----------------------------------------
def summary(candidates: list[dict], seconds: int, sessions: list[str]) -> dict:
    """
    機能: 未約定・観測不足・未到達を区別して参加と入口先着を集計する。
    引数: candidates(list[dict])、seconds(int)、sessions(list[str])。返り値: dict。
    """
    fills = [c for c in candidates if c['entry'] is not None]
    observations = [(c, outcome(c, seconds)) for c in fills]
    assert all(o is not None for _, o in observations)
    complete = [(c, o) for c, o in observations if o['status'] == 'complete']
    widths = {}
    for width in WIDTHS:
        counts = Counter(touch(o, width)['direction'] for _, o in complete)
        forward, adverse, neither = counts[1], counts[-1], counts[0]
        resolved = forward + adverse
        rate = forward / resolved if resolved else None
        all_rate = forward / len(complete) if complete else None
        widths[str(width)] = {'forward': forward, 'adverse': adverse, 'neither': neither, 'resolved': resolved,
                              'resolved_rate': rate, 'complete_rate': all_rate,
                              'resolved70': rate >= .7 if rate is not None else None,
                              'complete70': all_rate >= .7 if all_rate is not None else None}
    covered = {c['session'] for c in fills}
    return {'births': len(candidates), 'requested': sum(c['request'] is not None for c in candidates),
            'fills': len(fills), 'covered_sessions': len(covered), 'zero_sessions': [s for s in sessions if s not in covered],
            'all_sessions_entered': len(covered) == len(sessions), 'complete': len(complete), 'censored': len(fills)-len(complete),
            'states': dict(Counter(c['status'] for c in candidates)), 'paths': dict(Counter(c.get('path', 'E0') for c in fills)),
            'observations': dict(Counter(o['status'] for _, o in observations)), 'widths': widths,
            'endpoint_net5_mean': sum(o['net5'] for _, o in complete)/len(complete) if complete else None}


# ----------------------------------------
def validate(candidate: dict, scene: dict) -> None:
    """
    機能: 時間順序・取得側・期限算術と未約定の空値を検査する。
    引数: candidate(dict)、scene(dict)。返り値: None。不整合時は例外。
    """
    c = candidate
    assert c['policy'] in POLICIES and c['birth']['side'] in (-1, 1)
    if c['entry'] is None:
        assert c['entry_price'] is None and not c['outcomes']
        return
    q, req, side = c['entry'], c['request'], c['birth']['side']
    assert c['status'] == 'filled' and q['quote_ok'] and 0 < q['bid'] < q['ask']
    assert q['index'] > req['index'] and q['source_line'] > req['source_line']
    assert req['time']+1 <= q['time'] < c['expires']
    assert c['entry_price'] == (q['ask'] if side == 1 else q['bid'])
    assert len(c['outcomes']) == 2
    for o in c['outcomes']:
        assert o['seconds'] in HORIZONS and o['deadline'] == q['time']+o['seconds']
        assert len(o['touches']) == len(WIDTHS)
        for t in o['touches']:
            assert t['direction'] in (-1, 0, 1)
            if t['direction'] == 0:
                assert t['quote'] is None
            else:
                p = t['quote']
                assert p['index'] > q['index'] and p['source_line'] > q['source_line']
                assert q['time'] <= p['time'] <= o['deadline'] and p['quote_ok']
                assert t['direction']*side*((p['bid'] if side == 1 else p['ask'])-c['entry_price']) >= t['width']
        if o['status'] == 'complete':
            p = o['endpoint']
            assert p is not None and o['deadline'] <= p['time'] <= o['deadline']+30
            points = side*((p['bid'] if side == 1 else p['ask'])-c['entry_price'])
            assert (o['points'], o['net0'], o['net5']) == (points, points*100-77, points*100-1077)
        else:
            assert all(o[k] is None for k in ('endpoint', 'points', 'net0', 'net5'))


# ----------------------------------------
def label(observation: dict | None, width: int) -> str:
    """
    機能: 未約定と打切りを順行・逆行・未到達から区別する。
    引数: observation(dict|None)、width(int)。返り値: str。
    """
    if observation is None:
        return '未取得'
    direction = touch(observation, width)['direction']
    value = '順行先着' if direction == 1 else '逆行先着' if direction == -1 else '両方未到達'
    return value if observation['status'] == 'complete' else '観測不足（'+value+'）'


# ----------------------------------------
def write_new(path: Path, value: dict) -> None:
    """
    機能: 未作成先だけへUTF-8の正本JSONを保存する。
    引数: path(Path)、value(dict)。返り値: None。
    """
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


# ----------------------------------------
def main() -> None:
    """
    機能: 事前固定した全場条件の結果を検査し、3CSV用の値と集計を保存する。
    引数: なし。返り値: None。固定E0・全73場の欠落と数値の不整合は拒否する。
    """
    source = RUN/'全73場の入口結果.json'
    value = json.loads(source.read_text(encoding='utf-8'))
    original = json.loads((ROOT/'work/122全場入口比較/全73場の入口結果.json').read_text(encoding='utf-8'))
    assert value['success'] and value['trial'] == 123
    scenes = value['scenes']
    sessions = [s['session'] for s in scenes]
    assert len(scenes) == 73 and len(set(sessions)) == 73
    assert sessions == [s['session'] for s in original['scenes']]
    rows = []
    identities = set()
    baseline_count = 0
    for s, old in zip(scenes, original['scenes']):
        assert s['success'] and s['actual_sha256'] == old['actual_sha256'] and s['quality'] == old['quality']
        baseline = [c for c in s['candidates'] if c['policy'] == 'E0']
        expected = [c for c in old['candidates'] if c['policy'] == 'E0']
        assert len(baseline) == len(expected)
        for c, e in zip(baseline, expected):
            # 123のevent添字はE0以外のイベント配置により変わるため、金融内容から分離する。
            assert {k:c[k] for k in e if k != 'event'} == {k:v for k,v in e.items() if k != 'event'}
            assert s['events'][c['event']] == old['events'][e['event']]
            baseline_count += 1
        for c in s['candidates']:
            identity = (s['session'],c['policy'],c['birth']['id'])
            assert identity not in identities
            identities.add(identity)
            validate(c, s)
            rows.append(dict(c, session=s['session']))
    assert baseline_count == 9
    aggregate = {p:{str(h):summary([c for c in rows if c['policy']==p],h,sessions) for h in HORIZONS} for p in POLICIES}
    groups = {}
    for field, keys in (('path', ('E0','strong','deadline')), ('side',(-1,1)), ('daynight',('Day','Night'))):
        groups[field] = {}
        for key in keys:
            subset = [c for c in rows if (c['birth']['side'] if field=='side' else c['session'].split('_')[-1] if field=='daynight' else c.get('path','E0'))==key]
            groups[field][str(key)] = {p:summary([c for c in subset if c['policy']==p],3600,sessions) for p in POLICIES}
    per_session = {s:{p:summary([c for c in rows if c['session']==s and c['policy']==p],3600,[s]) for p in POLICIES} for s in sessions}
    result = {'成功':True,'試行':123,'主候補':'P3','主幅pt':125,'主時間秒':3600,'対象場数':73,
              '元結果SHA256':sha(source),'E0固定同体数':baseline_count,'集計':aggregate,'場別':per_session,'群別':groups,
              '全政策の全場取得条件':all(aggregate[p]['3600']['all_sessions_entered'] for p in POLICIES if p!='E0'),
              '実口座収支':False,'IFD実約定':False,'注意':'独立1miniの固定観測。重複候補を運用損益へ合算しない。'}
    write_new(OWN/'集計.json', result)
    # ----------------------------------------
    summary_headers = ['試行','候補','役割','評価分','対象場数','取得場数','取得0場数','全場1取得達成','出生数','要求数','取得数','観測完了数','観測不足数']
    for w in WIDTHS:
        summary_headers += [f'{w}pt順行',f'{w}pt逆行',f'{w}pt両方未到達',f'{w}pt到達済み順行率',f'{w}pt全完了順行率']
    summary_headers += ['125pt到達済み70%','125pt全完了70%','参加と125pt到達済み70%を達成','C5期限清算評価平均円（運用損益ではない）']
    summary_rows = []
    for p in POLICIES:
        for h in HORIZONS:
            st=aggregate[p][str(h)]; w125=st['widths']['125']
            r=[123,p,'主候補' if p=='P3' else '固定対照' if p=='E0' else '期限比較',h/60,73,st['covered_sessions'],len(st['zero_sessions']),st['all_sessions_entered'],st['births'],st['requested'],st['fills'],st['complete'],st['censored']]
            for w in WIDTHS:
                x=st['widths'][str(w)]; r += [x[k] for k in ('forward','adverse','neither','resolved_rate','complete_rate')]
            r += [w125['resolved70'],w125['complete70'],st['all_sessions_entered'] and w125['resolved70'],st['endpoint_net5_mean']]
            summary_rows.append(r)
    # ----------------------------------------
    session_headers=['試行','候補','セッション','日夜','出生数','要求数','取得数','最低1取得達成','初取得JST','初取得の入口','60分完了','60分観測不足','125pt順行','125pt逆行','125pt両方未到達','125pt到達済み順行率','125pt全完了順行率','100pt順行','100pt逆行','100pt両方未到達','100pt到達済み順行率','100pt全完了順行率','取得0理由']
    session_rows=[]
    for s in sessions:
        st=per_session[s]['P3']; filled=[c for c in rows if c['session']==s and c['policy']=='P3' and c['entry']]
        first=min(filled,key=lambda c:(c['entry']['time'],c['entry']['index'])) if filled else None
        r=[123,'P3',s,'デイ' if s.endswith('_Day') else 'ナイト',st['births'],st['requested'],st['fills'],st['all_sessions_entered'],jst(first['entry']['time']) if first else None,first.get('path','E0') if first else None,st['complete'],st['censored']]
        for w in (125,100):
            x=st['widths'][str(w)]; r += [x[k] for k in ('forward','adverse','neither','resolved_rate','complete_rate')]
        r += [None if filled else json.dumps(st['states'],ensure_ascii=False)]
        session_rows.append(r)
    # ----------------------------------------
    detail_headers=['試行','候補','入口','セッション','出生ID','共有取得ID','売買','出生JST','要求JST','取得状態','取得JST','取得価格','評価分','観測状態','期限JST','25pt先着','50pt先着','100pt先着','125pt先着','200pt先着','125pt初先着JST','期限評価JST','期限価格差pt','C0期限清算評価円（運用損益ではない）','C5期限清算評価円（運用損益ではない）','補完の判断型','方向スコア（確率ではない）','複合判断の正本参照']
    detail_rows=[]
    for c in rows:
        req,entry=c['request'],c['entry']
        shared=f"{c['session']}:{entry['index']}:{c['birth']['side']}" if entry else None
        for h in HORIZONS:
            o=outcome(c,h); t=touch(o,125) if o else None
            d=c.get('decision')
            detail_rows.append([123,c['policy'],c.get('path','E0'),c['session'],c['birth']['id'],shared,'買' if c['birth']['side']==1 else '売',jst(c['birth']['time']),jst(req['time']) if req else None,c['status'],jst(entry['time']) if entry else None,c['entry_price'],h/60,o['status'] if o else '未取得',jst(o['deadline']) if o else None,*[label(o,w) for w in WIDTHS],jst(t['quote']['time']) if t and t['quote'] else None,jst(o['endpoint']['time']) if o and o['endpoint'] else None,o['points'] if o else None,o['net0'] if o else None,o['net5'] if o else None,d.get('strategy') if d else None,d['score']['value'] if d and d['score']['known'] else None,f"全73場の入口結果.json.gz:scenes[{c['session']}].candidates[{c['policy']}:{c['birth']['id']}]" ])
    tables=[{'name':'候補別集計','headers':summary_headers,'rows':summary_rows},{'name':'全セッション','headers':session_headers,'rows':session_rows},{'name':'入口明細','headers':detail_headers,'rows':detail_rows}]
    for table in tables:
        assert all(len(r)==len(table['headers']) for r in table['rows'])
    write_new(OWN/'CSV用の表.json',{'試行':123,'成功':True,'result_sha256':sha(source),'意味':result['注意'],'tables':tables})
    print(json.dumps({'成功':True,'E0同体':baseline_count,'CSV行数':[len(t['rows']) for t in tables], '60分集計':{p:aggregate[p]['3600'] for p in POLICIES}},ensure_ascii=False))


if __name__ == '__main__':
    main()
