"""
123の保存結果/集計/三表と固定122対照だけを独立照合する。

Root集計関数は使わず、全場取得、先着分母、E0同体、期限算術を検査する。
"""

from __future__ import annotations

import argparse
from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone, timedelta
from decimal import Decimal
from fractions import Fraction
import hashlib
import importlib.util
import json
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[2]
HELPER = ROOT / 'work/122独立検算/独立検算する.py'
HELPER_SHA = '5ea22f01f1600ce266b602cca5e4ca518dc2560ada2e1249b06e0c5c9e26d5f4'
assert hashlib.sha256(HELPER.read_bytes()).hexdigest() == HELPER_SHA
SPEC = importlib.util.spec_from_file_location('independent122', HELPER)
OLD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(OLD)
POLICIES = ['E0', 'P2', 'P3', 'P4']
WIDTHS = [25, 50, 100, 125, 200]
HORIZONS = [1800, 3600]
JST = timezone(timedelta(hours=9))
COUNTS = Counter()
need, compare, quote = OLD.need, OLD.compare, OLD.quote


# ----------------------------------------
def sha(data: bytes) -> str:
    """
    機能: バイト列の指紋を返す。
    引数: data(bytes)。返り値: str型SHA256。
    """
    return hashlib.sha256(data).hexdigest()


# ----------------------------------------
def date_text(value: Any) -> str | None:
    """
    機能: 保存Unix価格時計を三表のJST表記へ変換する。
    引数: value(数値 | None)。返り値: str | None型。
    """
    return None if value is None else datetime.fromtimestamp(float(value), JST).isoformat(sep=' ')


# ----------------------------------------
def observation(c: dict, seconds: int) -> dict | None:
    """
    機能: 指定期限の保存観測を選ぶ。
    引数: c(dict)、seconds(int)。返り値: dict | None型。
    """
    return next((o for o in c['outcomes'] if o['seconds'] == seconds), None)


# ----------------------------------------
def hit(o: dict, width: int) -> dict:
    """
    機能: 保存先着の指定幅を選ぶ。
    引数: o(dict)、width(int)。返り値: dict型。
    """
    return next(t for t in o['touches'] if t['width'] == width)


# ----------------------------------------
def label(o: dict | None, width: int) -> str:
    """
    機能: 観測不足/未取得を先着方向と別に表記する。
    引数: o(dict | None)、width(int)。返り値: str型。
    """
    if o is None:
        return '未取得'
    d = hit(o, width)['direction']
    text = {1: '順行先着', -1: '逆行先着', 0: '両方未到達'}[d]
    return text if o['status'] == 'complete' else '観測不足（' + text + '）'


# ----------------------------------------
def summary(cases: list[dict], seconds: int, sessions: list[str]) -> dict:
    """
    機能: 全場取得と全幅先着を整数/Fractionで独立集計する。
    引数: cases(list[dict])、seconds(int)、sessions(list[str])。返り値: dict型。
    """
    fills = [c for c in cases if c['entry'] is not None]
    observed = [observation(c, seconds) for c in fills]
    need(all(o is not None for o in observed), '取得に期限がない')
    complete = [o for o in observed if o['status'] == 'complete']
    widths = {}
    for w in WIDTHS:
        count = Counter(hit(o, w)['direction'] for o in complete)
        forward, adverse, neither = count[1], count[-1], count[0]
        resolved = forward + adverse
        rate = Fraction(forward, resolved) if resolved else None
        all_rate = Fraction(forward, len(complete)) if complete else None
        widths[str(w)] = {'forward': forward, 'adverse': adverse, 'neither': neither, 'resolved': resolved, 'resolved_rate': rate, 'complete_rate': all_rate, 'resolved70': rate >= Fraction(7, 10) if rate is not None else None, 'complete70': all_rate >= Fraction(7, 10) if all_rate is not None else None}
    covered = {c['session'] for c in fills}
    return {'births': len(cases), 'requested': sum(c['request'] is not None for c in cases), 'fills': len(fills), 'covered_sessions': len(covered), 'zero_sessions': [s for s in sessions if s not in covered], 'all_sessions_entered': len(covered) == len(sessions), 'complete': len(complete), 'censored': len(fills) - len(complete), 'states': dict(Counter(c['status'] for c in cases)), 'paths': dict(Counter(c.get('path', 'E0') for c in fills)), 'observations': dict(Counter(o['status'] for o in observed)), 'widths': widths, 'endpoint_net5_mean': OLD.average([o['net5'] for o in complete])}


# ----------------------------------------
def candidate_check(c: dict, scene: dict) -> None:
    """
    機能: 全入口の要求/取得/固定観測の保存算術を確認する。
    引数: c/scene(dict)。返り値: None。Raw最初性は再証明しない。
    """
    side, birth = c['birth']['side'], c['birth']
    need(c['policy'] in POLICIES and side in (-1, 1) and c['path'] in ('E0', 'strong', 'deadline'), '候補分類差')
    quote(birth['quote'], scene)
    need(all(birth[k] == birth['quote'][k] for k in ('time', 'index', 'source_line')), '出生時計差')
    req, entry, evaluation = c['request'], c['entry'], c['evaluation']
    need(c['expires'] <= birth['time'] + 30, '30秒TTL差')
    if req is not None:
        need(req == birth['quote'], '要求と出生原行差')
    if evaluation is not None:
        quote(evaluation, scene, True)
        need(req is not None and OLD.later(evaluation, req, 1) and evaluation['time'] < c['expires'], '後原行1秒/TTL差')
    if entry is None:
        need(c['entry_price'] is None and c['outcomes'] == [] and c['status'] != 'filled', '未取得の0補完又は状態差')
        COUNTS['未取得nil'] += 1
        return
    need(c['status'] == 'filled' and entry == evaluation and req is not None, '取得証拠差')
    quote(entry, scene, True)
    need(c['entry_price'] == OLD.field_mark(entry, side, True), '新規BBO側差')
    need([o['seconds'] for o in c['outcomes']] == HORIZONS, '期限列差')
    for o in c['outcomes']:
        need(o['deadline'] == Decimal(str(float(entry['time']) + float(o['seconds']))), '固定期限算術差')
        need([t['width'] for t in o['touches']] == WIDTHS, '幅列差')
        for t in o['touches']:
            d, q = t['direction'], t['quote']
            need(d in (-1, 0, 1) and (q is None) == (d == 0), '先着方向/証拠差')
            if q is not None:
                quote(q, scene, True)
                need(OLD.later(q, entry) and q['time'] <= o['deadline'], '先着の原行/期限外')
                need(d * side * (OLD.field_mark(q, side, False) - c['entry_price']) >= t['width'], '先着幾何差')
                if o['endpoint'] is not None:
                    need(q['index'] <= o['endpoint']['index'], '評価後原行先着混入')
                COUNTS['先着幾何'] += 1
        if o['status'] == 'complete':
            q = o['endpoint']
            quote(q, scene, True)
            need(o['deadline'] <= q['time'] <= o['deadline'] + 30 and OLD.later(q, entry), '期限BBO/猶予差')
            points = side * (OLD.field_mark(q, side, False) - c['entry_price'])
            need((o['points'], o['net0'], o['net5']) == (points, points * 100 - 77, points * 100 - 1077), 'C0/C5期限費用算術差')
            COUNTS['完了期限算術'] += 1
        else:
            need(o['status'] in ('endpoint_missing', 'eof_censored', 'gap_censored', 'bbo_gap_censored', 'session_censored') and all(o[k] is None for k in ('endpoint', 'points', 'net0', 'net5')), '観測不足0補完')
            COUNTS['打切りnil'] += 1
    COUNTS['取得証拠'] += 1


# ----------------------------------------
def participation_check(scene: dict) -> None:
    """
    機能: 各政策の補完上限・E0優先と未解決件数を確認する。
    引数: scene(dict)。返り値: None。取消しの未保存原行は再形成しない。
    """
    for p in POLICIES[1:]:
        cases = [c for c in scene['candidates'] if c['policy'] == p]
        base = [c for c in cases if c['path'] == 'E0']
        extra = [c for c in cases if c['path'] != 'E0']
        fills = [c for c in cases if c['entry'] is not None]
        need(sum(c['entry'] is not None for c in extra) <= 1, '補完が1取得を超える')
        first = min((c['entry']['index'] for c in fills), default=None)
        for c in extra:
            d = c['decision']
            need(c['event'] == -1 and d['eligible'] and d['side'] == c['birth']['side'] and d['at'] == OLD.slim(c['birth']['quote']), '補完判断と出生差')
            need(c['risk_at_decision'] is None and c['entry_cap'] == c['invalidation'] == 0, '補完へE0専用条件を混入')
            if first is not None:
                need(c['birth']['index'] < first, '取得後に追加補完要求')
            begin, _ = OLD.bounds(scene['session'])
            deadline = begin + {'P2': 7200, 'P3': 10800, 'P4': 14400}[p]
            need((c['birth']['time'] >= deadline) == (c['path'] == 'deadline'), '期限/通常モード時計差')
            if c['path'] == 'deadline':
                need(d['strategy'] == 'deadline', '期限の判断型差')
                score = d['score']
                need(score['known'], '期限Sが未知')
                sign = 1 if score['value'] > 0 else -1 if score['value'] < 0 else 0
                if not sign:
                    tie = d['components'].get('tie_close_delta', {})
                    need(tie.get('known') and tie['value'] != 0, '同率を固定買い等で補完')
                    sign = 1 if tie['value'] > 0 else -1
                need(c['birth']['side'] == sign, '期限のスコア方向差')
            else:
                need(d['strategy'] in ('trend', 'reversal'), '通常複合判断型差')
            for ref in d['refs'] + d['structure_refs']:
                at = d['at']
                need(ref['end'] <= ref['delivered']['time'] <= at['time'] and ref['delivered']['index'] <= at['index'] and ref['delivered']['source_line'] <= at['source_line'], '補完が未来公表を参照')
            if c['entry'] is not None:
                need(not any(b['request'] is not None and b['birth']['index'] == c['entry']['index'] for b in base), 'E0同Raw優先を無視')
        stats = scene['participation'][p]
        need(stats['requests'] == len(extra) and stats['score_checks'] == stats['requests'] + stats['unknown'] + stats['unresolved'] + stats['strong_denied'], '補完判断件数分解差')
        need((stats.get('first_unavailable') is not None) == (stats['unknown'] + stats['unresolved'] > 0), '未解決代表証拠差')


# ----------------------------------------
def tables_check(tables: dict, rows: list, aggregate: dict, per_session: dict, sessions: list[str]) -> None:
    """
    機能: 三CSV用表の見出しと全セルを独立再生成値へ照合する。
    引数: tables/aggregate/per_session(dict)、rows(list)、sessions(list[str])。返り値: None。
    """
    summary_headers = ['試行','候補','役割','評価分','対象場数','取得場数','取得0場数','全場1取得達成','出生数','要求数','取得数','観測完了数','観測不足数']
    for w in WIDTHS:
        summary_headers += [f'{w}pt順行',f'{w}pt逆行',f'{w}pt両方未到達',f'{w}pt到達済み順行率',f'{w}pt全完了順行率']
    summary_headers += ['125pt到達済み70%','125pt全完了70%','参加と125pt到達済み70%を達成','C5期限清算評価平均円（運用損益ではない）']
    a = []
    for p in POLICIES:
        for h in HORIZONS:
            st = aggregate[p][str(h)]; t = st['widths']['125']
            row = [123,p,'主候補' if p=='P3' else '固定対照' if p=='E0' else '期限比較',h//60,73,st['covered_sessions'],len(st['zero_sessions']),st['all_sessions_entered'],st['births'],st['requested'],st['fills'],st['complete'],st['censored']]
            for w in WIDTHS:
                row += [st['widths'][str(w)][k] for k in ('forward','adverse','neither','resolved_rate','complete_rate')]
            row += [t['resolved70'],t['complete70'],st['all_sessions_entered'] and t['resolved70'],st['endpoint_net5_mean']]
            a.append(row)
    session_headers = ['試行','候補','セッション','日夜','出生数','要求数','取得数','最低1取得達成','初取得JST','初取得の入口','60分完了','60分観測不足','125pt順行','125pt逆行','125pt両方未到達','125pt到達済み順行率','125pt全完了順行率','100pt順行','100pt逆行','100pt両方未到達','100pt到達済み順行率','100pt全完了順行率','取得0理由']
    b = []
    for s in sessions:
        st = per_session[s]['P3']; fills = [c for c in rows if c['session']==s and c['policy']=='P3' and c['entry'] is not None]
        first = min(fills,key=lambda c:(c['entry']['time'],c['entry']['index'])) if fills else None
        row = [123,'P3',s,'デイ' if s.endswith('_Day') else 'ナイト',st['births'],st['requested'],st['fills'],st['all_sessions_entered'],date_text(first['entry']['time']) if first else None,first['path'] if first else None,st['complete'],st['censored']]
        for w in (125,100):
            row += [st['widths'][str(w)][k] for k in ('forward','adverse','neither','resolved_rate','complete_rate')]
        row += [None if fills else json.dumps(st['states'],ensure_ascii=False)]
        b.append(row)
    detail_headers = ['試行','候補','入口','セッション','出生ID','共有取得ID','売買','出生JST','要求JST','取得状態','取得JST','取得価格','評価分','観測状態','期限JST','25pt先着','50pt先着','100pt先着','125pt先着','200pt先着','125pt初先着JST','期限評価JST','期限価格差pt','C0期限清算評価円（運用損益ではない）','C5期限清算評価円（運用損益ではない）','補完の判断型','方向スコア（確率ではない）','複合判断の正本参照']
    crows = []
    for c in rows:
        req, entry = c['request'], c['entry']; shared = f"{c['session']}:{entry['index']}:{c['birth']['side']}" if entry else None
        for h in HORIZONS:
            o = observation(c,h); t = hit(o,125) if o else None; d = c.get('decision')
            crows.append([123,c['policy'],c['path'],c['session'],c['birth']['id'],shared,'買' if c['birth']['side']==1 else '売',date_text(c['birth']['time']),date_text(req['time']) if req else None,c['status'],date_text(entry['time']) if entry else None,c['entry_price'],h//60,o['status'] if o else '未取得',date_text(o['deadline']) if o else None,*[label(o,w) for w in WIDTHS],date_text(t['quote']['time']) if t and t['quote'] else None,date_text(o['endpoint']['time']) if o and o['endpoint'] else None,o['points'] if o else None,o['net0'] if o else None,o['net5'] if o else None,d.get('strategy') if d else None,d['score']['value'] if d and d['score']['known'] else None,f"全73場の入口結果.json.gz:scenes[{c['session']}].candidates[{c['policy']}:{c['birth']['id']}]" ])
    need([x['name'] for x in tables['tables']] == ['候補別集計','全セッション','入口明細'], '三表名差')
    for saved, headers, expected in zip(tables['tables'], (summary_headers,session_headers,detail_headers), (a,b,crows)):
        compare(saved['headers'],headers,saved['name']+'/見出し')
        compare(saved['rows'],expected,saved['name']+'/全セル')
        COUNTS[saved['name']+'行数'] = len(expected)
        COUNTS[saved['name']+'データセル数'] = len(expected)*len(headers)


# ----------------------------------------
def main() -> None:
    """
    機能: SHA指定の新三JSONと既許可122対照を読み、全数値とE0固定を検算する。
    引数: CLIのresult/aggregate/tables/baselineと各sha、output。返り値: None。
    """
    parser = argparse.ArgumentParser()
    for key in ('result','aggregate','tables','baseline'):
        parser.add_argument('--'+key,required=True);parser.add_argument('--'+key+'-sha',required=True)
    parser.add_argument('--output',required=True)
    args = vars(parser.parse_args()); output = Path(args['output']).absolute()
    need(not output.exists(),'確認先は未作成')
    values,before = {},{}
    for key in ('result','aggregate','tables','baseline'):
        path=Path(args[key]).absolute();data=path.read_bytes();need(sha(data)==args[key+'_sha'],key+'SHA差');before[str(path)]=sha(data);values[key]=json.loads(data,parse_float=Decimal)
    before[str(HELPER)]=HELPER_SHA;self=Path(__file__).absolute();before[str(self)]=sha(self.read_bytes())
    result,saved,tables,baseline=(values[k] for k in ('result','aggregate','tables','baseline'))
    need(result['success'] and result['trial']==123 and result['policies']==POLICIES and result['horizons']==HORIZONS and result['widths']==WIDTHS and not result['portfolio_pnl'] and not result['source_signals_used'] and result['candidate_quantity']==1,'条件/範囲差')
    need(result['input_sha256']==baseline['input_sha256']=='6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec','固定Input差')
    scenes=result['scenes'];sessions=[s['session'] for s in scenes]
    need(len(sessions)==73 and sessions==[s['session'] for s in baseline['scenes']] and sessions==sorted(set(sessions)),'全73場順序差')
    need(saved['成功'] and saved['試行']==tables['試行']==123 and tables['成功'] and saved['元結果SHA256']==tables['result_sha256']==args['result_sha'] and saved['主候補']=='P3' and saved['主幅pt']==125 and saved['主時間秒']==3600,'3JSON/主条件差')
    need(not saved['実口座収支'] and not saved['IFD実約定'],'口座範囲差')
    rows=[];identities=set();base_count=0
    for scene,old in zip(scenes,baseline['scenes']):
        need(scene['success'] and not scene['source_signals_used'] and scene['raw_passes']==1,'場実行証拠差')
        for key in ('raw','actual_sha256','quality','expected_quality','stat_before','stat_after','raw_encoding','publications','detector_stats'):
            need(scene[key]==old[key],'固定入力/品質/診断差:'+key)
        OLD.quality_check(scene)
        old_cases=[c for c in old['candidates'] if c['policy']=='E0'];old_by_id={c['birth']['id']:c for c in old_cases}
        need(scene['events']==[e for e in old['events'] if e['policy']=='E0'],'E0全イベント同体差')
        for p in POLICIES:
            current=[c for c in scene['candidates'] if c['policy']==p and c['path']=='E0']
            need(len(current)==len(old_cases),'E0保持数差')
            for c in current:
                original=old_by_id[c['birth']['id']]
                for key,value in original.items():
                    if key=='event':continue
                    need((('E0' if key=='policy' else c[key]))==value,'E0金融キー差:'+key)
                need(scene['events'][c['event']]==old['events'][original['event']],'E0参照原文差')
                COUNTS['全政策の固定E0同体']+=1
                if p=='E0':base_count+=1
        for c in scene['candidates']:
            identity=(scene['session'],c['policy'],c['birth']['id']);need(identity not in identities,'候補ID重複');identities.add(identity)
            candidate_check(c,scene)
            if c['path']=='E0':
                normalized=deepcopy(c);normalized['policy']='E0';OLD.candidate_check(normalized,scene,{e['id']:i for i,e in enumerate(scene['events'])})
            rows.append(dict(c,session=scene['session']))
        participation_check(scene)
    need(base_count==saved['E0固定同体数']==9,'E0対照9差')
    aggregate={p:{str(h):summary([c for c in rows if c['policy']==p],h,sessions) for h in HORIZONS} for p in POLICIES}
    compare(saved['集計'],aggregate,'全政策/全期限/全幅の分母と率')
    groups={}
    for field,keys in (('path',('E0','strong','deadline')),('side',(-1,1)),('daynight',('Day','Night'))):
        groups[field]={}
        for key in keys:
            selected=[c for c in rows if (c['birth']['side'] if field=='side' else c['session'].rsplit('_',1)[1] if field=='daynight' else c['path'])==key]
            groups[field][str(key)]={p:summary([c for c in selected if c['policy']==p],3600,sessions) for p in POLICIES}
    compare(saved['群別'],groups,'入口/売買/日夜全集計')
    per_session={s:{p:summary([c for c in rows if c['session']==s and c['policy']==p],3600,[s]) for p in POLICIES} for s in sessions}
    compare(saved['場別'],per_session,'73場全政策')
    need(saved['全政策の全場取得条件']==all(aggregate[p]['3600']['all_sessions_entered'] for p in POLICIES[1:]),'全場参加判定差')
    tables_check(tables,rows,aggregate,per_session,sessions)
    split={}
    p3=[c for c in rows if c['policy']=='P3']
    for kind in ('trend','reversal','deadline','E0'):
        chosen=[c for c in p3 if ('E0' if c['path']=='E0' else c['decision']['strategy'])==kind]
        split[kind]=summary(chosen,3600,sessions)
    first=[min((c for c in p3 if c['session']==s and c['entry'] is not None),key=lambda c:(c['entry']['time'],c['entry']['index'])) for s in sessions]
    first_summary=summary(first,3600,sessions)
    after={path:sha(Path(path).read_bytes()) for path in before};need(before==after,'検算中の入力/コード変更')
    proof={'成功':True,'試行':123,'場数':73,'主条件':'P3/60分125pt','E0固定対照数':base_count,'集計':OLD.serial(aggregate),'P3入口型別':OLD.serial(split),'P3初取得のみ':OLD.serial(first_summary),'検査件数':dict(COUNTS),'旧独立検算helper件数':dict(OLD.COUNTS),'入力SHA256':before,'後SHA256':after,'前後不変':True,'Root集計関数利用':False,'数値':'件数/費用は完全一致、率/平均はFractionで独立算出して倍精度1回丸め。未到達・観測不足・未取得を混ぜない。','Raw/Input/実CSV読取':0,'金融再生':False,'条件変更':False,'確認':'全73場参加/全政策全幅と2期限/同体E0全4政策/要求後BBO/補完上限/三表全セル。入口型/初取得分割は主変更に使わない。','未証明':['Raw最初性/途中欠測と全指標再形成は再証明しない','スコア式/未知mask/買売鏡像はF1前コード独立レビューと人工検査で確認、Raw反転値を新計算しない','実CSVはRootの別全セル再読で確認、本検算はCSV用JSONを照合','独立1mini期限観測はIFD実決済/利益追尾/口座損益ではない']}
    output.parent.mkdir(parents=True,exist_ok=True);encoded=(json.dumps(proof,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode('utf-8')
    with output.open('xb') as stream:stream.write(encoded)
    print(json.dumps({'成功':True,'proof_sha256':sha(encoded),'P3':OLD.serial(aggregate['P3']['3600']),'件数':dict(COUNTS)},ensure_ascii=False))


if __name__=='__main__':
    main()
