"""機能: 独立集計と事後補足の入口型・初取得分割を照合する。

引数: コマンドライン引数なし。
返り値: なし。成功時は補足の独立照合.jsonを保存する。
"""

import hashlib
import json
from fractions import Fraction
from pathlib import Path


def sha256(path: Path) -> str:
    """機能: ファイルの指紋を求める。

    引数: path (Path) は確認するファイル。
    返り値: str は SHA256 の小文字16進表記。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def compare(actual: dict, expected: dict) -> int:
    """機能: 補足1群を独立集計の件数と率に照合する。

    引数: actual (dict) は事後補足、expected (dict) は独立集計。
    返り値: int は照合した件数・率のセル数。
    """
    assert actual["取得数"] == expected["fills"]
    assert actual["60分完了数"] == expected["complete"]
    assert actual["60分不足数"] == expected["censored"]
    count = 3
    for width in ("25", "50", "100", "125", "200"):
        a = actual[width]
        e = expected["widths"][width]
        assert (a["順"], a["逆"], a["未到達"]) == (
            e["forward"], e["adverse"], e["neither"]
        )
        resolved = e["forward"] + e["adverse"]
        complete = resolved + e["neither"]
        assert complete == expected["complete"]
        r = float(Fraction(e["forward"], resolved)) if resolved else None
        c = float(Fraction(e["forward"], complete)) if complete else None
        assert a["到達済み分母順行率"] == r == e["resolved_rate"]
        assert a["全完了分母順行率"] == c == e["complete_rate"]
        count += 5
    return count


# ----------------------------------------
base = Path(__file__).resolve().parent
proof_path = base / "全73場の独立検算.json"
supplement_path = base.parent / "123全場参加の集計" / "入口型の補足.json"
paths = (proof_path, supplement_path, Path(__file__).resolve())
before = {str(p): sha256(p) for p in paths}
assert before[str(proof_path)] == "f23a71d89cf03b733ede6d66cf436734f94a6b0f47c71cabcb18e62eaef0fbeb"
assert before[str(supplement_path)] == "a9b420511d124869f9064cbee9f4dcc7c89ca1855b23605ac576df6ca677b0a7"
proof = json.loads(proof_path.read_text(encoding="utf-8-sig"))
supplement = json.loads(supplement_path.read_text(encoding="utf-8-sig"))
assert proof["成功"] and supplement["成功"]
assert supplement["試行"] == 123 and supplement["再生後補足"]
assert not supplement["閾値変更"] and not supplement["条件選択に利用"]
assert supplement["元結果SHA256"] == "9823c9b3f257d97462f295e696b649d41a10ea538dd816490d70e60b34c4146f"
cells = compare(supplement["全取得"], proof["集計"]["P3"]["3600"])
cells += compare(supplement["各場の初取得"], proof["P3初取得のみ"])
assert set(supplement["入口型"]) == set(proof["P3入口型別"])
for name, group in supplement["入口型"].items():
    cells += compare(group, proof["P3入口型別"][name])
after = {str(p): sha256(p) for p in paths}
assert before == after
output = {
    "成功": True,
    "試行": 123,
    "入力SHA256": before,
    "後SHA256": after,
    "前後不変": True,
    "照合群数": 6,
    "照合セル数": cells,
    "率の計算": "Fractionからのfloat変換。件数から独立再計算。",
    "閾値変更": False,
    "主評価変更": False,
    "金融再生": False,
    "Raw/Input/実CSV読取": False,
}
(base / "補足の独立照合.json").write_text(
    json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
)
print(json.dumps({"成功": True, "照合セル数": cells}, ensure_ascii=False))
