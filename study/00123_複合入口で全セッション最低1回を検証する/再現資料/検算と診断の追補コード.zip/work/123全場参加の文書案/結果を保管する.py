"""
123の完了済み結果・集計・補足・CSV検査を金融再実行なしで保管する。

Input本文・Raw・Native・exeは読まず、CSVを変更しない。
"""

from pathlib import Path
import gzip
import hashlib
import json


ROOT = Path(__file__).resolve().parents[2]
STUDY = ROOT / "study/00123_複合入口で全セッション最低1回を検証する"
OUTPUT = ROOT / "outputs/01a1889f-f2af-7943-a047-543275ee9ed2/123全場参加CSV"


# ----------------------------------------
def sha(data: bytes) -> str:
    """
    機能: 読取済みバイト列のSHA256を求める。
    引数: data(bytes)は対象。
    返り値: str型の16進指紋。
    """
    return hashlib.sha256(data).hexdigest()


# ----------------------------------------
def save_same(path: Path, data: bytes) -> None:
    """
    機能: 未作成先へ同bytesを保存し、既存なら同体を要求する。
    引数: path(Path)は保存先、data(bytes)は内容。
    返り値: None。既存差分は例外。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == data, path
    else:
        with path.open("xb") as stream:
            stream.write(data)


# ----------------------------------------
def main() -> None:
    """
    機能: 固定F1の原文・コードを照合し、金融/集計gzipと小検査を保存する。
    引数: なし。Rootが許可した成果だけを読む。
    返り値: None。金融再計算・巨大入力複写・CSV変更を行わない。
    """
    checks = STUDY / "検査"
    fixed_bytes = (checks / "再生前固定.json").read_bytes()
    assert sha(fixed_bytes) == "bf6481b5b1377743fce9687237c7adf0b1bdb845384df45a904a4d215306f509"
    fixed = json.loads(fixed_bytes)
    for name, expected in fixed["コード"].items():
        assert sha(Path(name).read_bytes()) == expected
    originals = json.loads(gzip.decompress((checks / "実行前文書.json.gz").read_bytes()))
    assert originals["F1_SHA256"] == sha(fixed_bytes)
    assert {item["source_path"]: item["SHA256"] for item in originals["原文"]} == fixed["実行前文書"]
    for item in originals["原文"]:
        data = item["utf8_text"].encode("utf-8")
        assert sha(data) == item["SHA256"] and len(data) == item["bytes"]
    stored = []
    jobs = [
        (ROOT / "work/123全場参加の入口比較/全73場の入口結果.json", "全73場の入口結果.json.gz", "9823c9b3f257d97462f295e696b649d41a10ea538dd816490d70e60b34c4146f"),
        (ROOT / "work/123全場参加の集計/集計.json", "集計.json.gz", "12c50ee931ca52024fab5c086c8206e885784ec1601c989b1db547a9a9e5b0ec"),
    ]
    for source, name, expected in jobs:
        data = source.read_bytes()
        assert sha(data) == expected
        packed = gzip.compress(data, compresslevel=9, mtime=0)
        target = STUDY / "成果物" / name
        save_same(target, packed)
        assert gzip.decompress(target.read_bytes()) == data
        assert sha(source.read_bytes()) == expected
        stored.append({"source": str(source), "path": target.relative_to(ROOT).as_posix(), "SHA256": sha(packed), "bytes": len(packed), "解凍SHA256": expected, "解凍bytes": len(data)})
    for source, relative in [
        (ROOT / "work/123全場参加の集計/再生完了.json", "検査/再生完了.json"),
        (ROOT / "work/123全場参加の集計/入口型の補足.json", "成果物/入口型の補足.json"),
        (OUTPUT / "CSVの確認.json", "検査/CSVの生成確認.json"),
        (ROOT / "work/123全場CSV出力/全73独立再読.json", "検査/CSVの独立再読.json"),
    ]:
        data = source.read_bytes()
        target = STUDY / relative
        save_same(target, data)
        stored.append({"source": str(source), "path": target.relative_to(ROOT).as_posix(), "SHA256": sha(data), "bytes": len(data)})
    expected_csv = {"候補別集計.csv": "ed59d586f475c26fd6585c0db641f1f40d4e64bc92e20cfbe49325eb75e9198e", "全セッション.csv": "d2d951775be009b69796909311d2e206d4b53fbdfe5d9457943aaf9b20e38237", "入口明細.csv": "7af34ef0e2d78a318e034110428111ca79a36991dcb5076cbf7a27ce9c3b19c7"}
    for name, expected in expected_csv.items():
        assert sha((OUTPUT / name).read_bytes()) == expected
    for name, expected in fixed["コード"].items():
        assert sha(Path(name).read_bytes()) == expected
    proof = {"試行": 123, "成功": True, "F1_SHA256": sha(fixed_bytes), "保存": stored, "原文3点復元SHA一致": True,
             "F1コード前後同体": True, "CSV3点SHA不変": expected_csv, "金融実行": False, "金融再集計": False,
             "Raw読取": False, "入力本文読取": False, "Native読取": False, "exe本文読取": False}
    save_same(checks / "結果保管の確認.json", (json.dumps(proof, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
    print(json.dumps({"成功": True, "gzip": stored[:2]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
