"""123の恒久成果物・固定原文・全73場・CSVの保管同体を最終確認する。"""
from pathlib import Path
from urllib.parse import unquote
import csv
import gzip
import hashlib
import io
import json
import re
import zipfile

ROOT=Path(__file__).resolve().parent.parent
FORMAL=ROOT/'study/00123_複合入口で全セッション最低1回を検証する'
CSV=ROOT/'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/123全場参加CSV'


def sha(data: bytes) -> str:
    """
    機能: バイト列のSHA256指紋を返す。
    引数: data(bytes)。返り値: str。
    """
    return hashlib.sha256(data).hexdigest()


# ----------------------------------------
def load(path: Path) -> dict:
    """
    機能: UTF-8のJSONを読み取る。
    引数: path(Path)。返り値: dict。
    """
    return json.loads(path.read_text(encoding='utf-8'))


# ----------------------------------------
def main() -> None:
    """
    機能: 成果物とF1の同体・全場保持・出力原板非複写・新規文書リンクを確認する。
    引数: なし。返り値: None。失敗時は正本の完了証跡を保存しない。
    """
    f1=load(FORMAL/'検査/再生前固定.json')
    f1sha=sha((FORMAL/'検査/再生前固定.json').read_bytes())
    assert f1sha=='bf6481b5b1377743fce9687237c7adf0b1bdb845384df45a904a4d215306f509'
    for p,s in f1['コード'].items():
        assert sha(Path(p).read_bytes())==s
    assert sha(Path(f1['実行ファイル']['path']).read_bytes())==f1['実行ファイル']['sha256']
    texts=json.loads(gzip.decompress((FORMAL/'検査/実行前文書.json.gz').read_bytes()))
    assert texts['F1_SHA256']==f1sha and len(texts['原文'])==3
    for item in texts['原文']:
        b=item['utf8_text'].encode('utf-8')
        assert len(b)==item['bytes'] and sha(b)==item['SHA256']==f1['実行前文書'][item['source_path']]
    # ----------------------------------------
    store=load(FORMAL/'検査/結果保管の確認.json')
    for item in store['保存']:
        path=ROOT/item['path']
        b=path.read_bytes()
        assert sha(b)==item['SHA256'] and len(b)==item['bytes']
        if '解凍SHA256' in item:
            plain=gzip.decompress(b)
            assert sha(plain)==item['解凍SHA256'] and len(plain)==item['解凍bytes']
        else:
            plain=b
        assert plain==Path(item['source']).read_bytes()
    result=json.loads(gzip.decompress((FORMAL/'成果物/全73場の入口結果.json.gz').read_bytes()))
    aggregate=json.loads(gzip.decompress((FORMAL/'成果物/集計.json.gz').read_bytes()))
    independent=FORMAL/'検査/独立検算.json'
    assert sha(independent.read_bytes())=='f23a71d89cf03b733ede6d66cf436734f94a6b0f47c71cabcb18e62eaef0fbeb'
    assert result['success'] and result['trial']==123 and len(result['scenes'])==73
    sessions=[s['session'] for s in result['scenes']]
    assert sessions==f1['対象全場'] and len(set(sessions))==73
    for policy in ('P2','P3','P4'):
        assert all(any(c['policy']==policy and c['entry'] is not None for c in s['candidates']) for s in result['scenes'])
    assert aggregate['集計']['P3']['3600']['fills']==79
    assert aggregate['集計']['P3']['3600']['widths']['125']['forward']==26
    assert aggregate['集計']['P3']['3600']['widths']['125']['adverse']==31
    # ----------------------------------------
    index=load(FORMAL/'再現資料/コード復元索引.json')
    archive=FORMAL/'再現資料'/index['zip']['path']
    assert sha(archive.read_bytes())==index['zip']['SHA256']
    restored={}
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for item in index['entries']:
            b=z.read(item['entry'])
            assert sha(b)==item['SHA256'] and len(b)==item['bytes']
            restored[str(ROOT/item['restore_relative'])]=sha(b)
    for item in index['external_entries']:
        archive=ROOT/item['archive']
        assert sha(archive.read_bytes())==item['archive_SHA256']
        with zipfile.ZipFile(archive) as z:
            b=z.read(item['entry'])
        assert sha(b)==item['SHA256'] and len(b)==item['bytes']
        restored[str(ROOT/item['restore_relative'])]=sha(b)
    assert all(restored.get(p)==s for p,s in f1['コード'].items())
    # ----------------------------------------
    csvproof=load(CSV/'CSVの確認.json')
    for name,item in csvproof['出力'].items():
        path=CSV/name
        assert sha(path.read_bytes())==item['sha256']
        rows=list(csv.reader(io.StringIO(path.read_text(encoding='utf-8-sig'),newline='')))
        assert len(rows)-1==item['データ行数'] and all(len(r)==item['列数'] for r in rows)
    rows=list(csv.DictReader((CSV/'全セッション.csv').open(encoding='utf-8-sig',newline='')))
    assert len(rows)==73 and [r['セッション'] for r in rows]==sessions
    assert all(r['最低1取得達成']=='true' and int(r['取得数'])>=1 for r in rows)
    assert sum(int(r['取得数']) for r in rows)==79
    assert not list(FORMAL.rglob('*.xlsx')) and not list(CSV.rglob('*.xlsx'))
    # ----------------------------------------
    documents=list(FORMAL.rglob('*.md'))
    documents += [ROOT/'README.md',ROOT/'study/README.md',ROOT/'docs/README.md',ROOT/'docs/議論/README.md']
    discussion=ROOT/'docs/議論/全場参加と入口精度を分けた複合入口の結果.md'
    if discussion.exists():
        documents.append(discussion)
    links=0
    for path in documents:
        for target in re.findall(r'\]\(([^)]+)\)',path.read_text(encoding='utf-8')):
            target=target.strip().strip('<>')
            if target.startswith(('https://','http://','mailto:','#')):
                continue
            target=unquote(target.split('#')[0])
            if not target:
                continue
            dest=Path(target) if re.match(r'^[A-Za-z]:[/\\]',target) else path.parent/target
            assert dest.exists(), (str(path),target)
            links+=1
    proof={'試行':123,'成功':True,'F1_SHA256':f1sha,'固定コード数':len(f1['コード']),
           '全対象73保持':True,'P2P3P4全場取得':True,'P3取得数':79,'E0対照一致':aggregate['E0固定同体数'],
           '圧縮正本と元bytes一致':True,'F1原文3件復元一致':True,'コード復元索引一致':True,
           'CSV3本の指紋と行列数一致':True,'新xlsx無し':True,'相対リンク確認数':links,
           '独立金融検算の恒久保管一致':True,
           '3プレビュー視認':'ヘッダと自然値を確認、明細IDは折り返し表示。CSVの全値は独立再読で確認。'}
    out=FORMAL/'検査/Root最終照合.json'
    with out.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':
    main()
