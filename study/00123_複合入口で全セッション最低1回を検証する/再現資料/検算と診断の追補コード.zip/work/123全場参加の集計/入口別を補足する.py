"""金融再生後に、条件を変えず入口の種類と初取得だけを補足集計する。"""
from pathlib import Path
from collections import Counter
import hashlib
import json

OWN=Path(__file__).resolve().parent
SOURCE=OWN.parent/'123全場参加の入口比較/全73場の入口結果.json'


def counts(cases: list[dict]) -> dict:
    """
    機能: 完了した60分観測について同幅先着を件数で集計する。
    引数: cases(list[dict])。返り値: dictは全取得数・完了数・先着内訳。
    """
    observations=[next(o for o in c['outcomes'] if o['seconds']==3600) for c in cases]
    complete=[o for o in observations if o['status']=='complete']
    result={'取得数':len(cases),'60分完了数':len(complete),'60分不足数':len(cases)-len(complete)}
    for w in (25,50,100,125,200):
        counter=Counter(next(t['direction'] for t in o['touches'] if t['width']==w) for o in complete)
        a,b,n=counter[1],counter[-1],counter[0]
        result[str(w)]={'順':a,'逆':b,'未到達':n,'到達済み分母順行率':a/(a+b) if a+b else None,'全完了分母順行率':a/len(complete) if complete else None}
    return result


# ----------------------------------------
def main() -> None:
    """
    機能: 主政策の入口型と各場の初取得を結果後の補足として保存する。
    引数: なし。返り値: None。金融条件と主解析を変更しない。
    """
    data=SOURCE.read_bytes()
    source=json.loads(data)
    fills=[c for s in source['scenes'] for c in s['candidates'] if c['policy']=='P3' and c['entry']]
    first=[]
    for scene in source['scenes']:
        cases=[c for c in scene['candidates'] if c['policy']=='P3' and c['entry']]
        first.append(min(cases,key=lambda c:(c['entry']['time'],c['entry']['index'])))
    result={'成功':True,'試行':123,'再生後補足':True,'閾値変更':False,'条件選択に利用':False,
            '元結果SHA256':hashlib.sha256(data).hexdigest(),'全取得':counts(fills),'各場の初取得':counts(first),'入口型':{}}
    for name in ('E0','trend','reversal','deadline'):
        cases=[c for c in fills if (c['decision']['strategy'] if c.get('decision') else 'E0')==name]
        result['入口型'][name]=counts(cases)
    with (OWN/'入口型の補足.json').open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':
    main()
