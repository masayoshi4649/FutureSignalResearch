# 178の薄い正式Sourceと固定再現

178で有望な結論を得たため新探索を一旦停止する。追加期Night悪化を保持し、安定実運用採用や独立未見性能とは区別する。

Sourceは176全Source→177薄いSource→178薄いSourceの順に元byteで復元する。各ZIP・索引・全memberを指紋照合し、祖先Sourceを178 ZIPへ重複保存しない。175〜177の正式ZIPは上書きしない。

小正本は178純方向/全段/固定四案旧追加全pack/全80/経路/独立検査/CSV型付き入力等を含む。主二案CSV八本だけをoutputs正本へ指紋参照し、近傍を含む四案の金融/packは保持する。CSV出力器は177正式Sourceの元byteを参照する。

旧小入力は177正式小正本から必要七memberだけ選択継承する。174の旧/追加純出生・対照pack、177の旧/追加G00対照pack、177固定票である。原板・feature cache・巨大金融配列は複製しない。

runnerは正式148を固定151/161 Sourceでキャッシュ無し射影し、旧178純方向84配列、固定4案×旧追加全pack、両端G00=177/G99=174、旧174追加なし四対照、全80全行と対象場/時間を再構成する。未知None・0取引場・addedとorigins0/2を保持する。

必要環境はPython 3.14.3、NumPy 2.5.4、tzdata 2026.6。隔離runnerは元work/cache/原板読込と共有inputs/studyへの書込を監査で拒否する。

保存前の隔離再現は成功した。固定四案の8候補期間、G00/G99の16対照、旧174no-addの8照合、旧84純方向と全80全行が一致し、禁止参照0。

```powershell
& 'work/複合テクニカル学習環境/Scripts/python.exe' 'work/178正式保存/保存178.py' --prepare
& 'work/複合テクニカル学習環境/Scripts/python.exe' 'work/178正式保存/隔離を準備する.py'
```

正式保存は隔離成功後のRoot GOを待ち、`保存178.py --execute --go` で行う。既存ZIP・隔離先は上書きしない。
