"""178の実方向ゲートを自然特徴・金融なしで検査する。"""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import gates178 as R


def features(n: int=16) -> object:
    """
    機能: 必要な実在特徴名を持つ人工100特徴を作る。
    引数: n(int)は人工q0数。
    返り値: SimpleNamespaceは買売の100列配列。
    """
    columns=list(R.LONG_COLUMNS)+['m15_hist_delta_to_side','m1_volume_relative_prior3',
        'm5_di_difference_to_side','m5_hist_delta_to_side','m5_rsi_delta_to_side']
    columns.extend(f'人工未使用{i}' for i in range(100-len(columns)))
    return SimpleNamespace(columns=columns,buy_X=np.ones((n,100)),sell_X=np.ones((n,100)))


def take(source: object,end: int) -> object:
    """
    機能: 人工特徴をprefixへ切り出す。
    引数: source(object)、end(int)。
    返り値: SimpleNamespaceは独立したprefix。
    """
    return SimpleNamespace(columns=list(source.columns),buy_X=source.buy_X[:end].copy(),sell_X=source.sell_X[:end].copy())


def main() -> None:
    """
    機能: 12固定ゲートの実方向・鏡像・未知・境界・因果性を検査する。
    引数: なし。
    返り値: None。辞書と人工確認を保存し、自然出生や金融を生成しない。
    """
    here=Path(__file__).resolve().parent;catalog=R.catalog();checks={};cells=0
    source=features();direction=np.asarray([1,-1,0,1,-1,1,0,-1]*2,dtype=np.int8)
    for i,name in enumerate(R.LONG_COLUMNS):
        source.buy_X[(np.arange(16)+i)%5==0,source.columns.index(name)]=-1
        source.sell_X[(np.arange(16)+i)%4==0,source.columns.index(name)]=-1
    for gate in catalog['gates']:
        identity=gate['id'];out=R.apply(source,direction,identity)
        mirror=SimpleNamespace(columns=source.columns,buy_X=source.sell_X,sell_X=source.buy_X)
        assert np.array_equal(R.apply(mirror,-direction,identity),-out)
        assert np.all((out==0)|(out==direction)) and np.all(out[direction==0]==0)
        for end in (1,7,12):
            assert np.array_equal(R.apply(take(source,end),direction[:end],identity),out[:end])
            future=take(source,16);future.buy_X[end:]=np.nan;future.sell_X[end:]=np.nan
            assert np.array_equal(R.apply(future,direction,identity)[:end],out[:end])
            cells+=2*end
        unknown=take(source,16);unknown.buy_X[:]=np.nan;unknown.sell_X[:]=np.nan
        blocked=R.apply(unknown,direction,identity)
        assert np.array_equal(blocked,direction if identity=='G00' else np.zeros_like(direction))
        for condition in gate['conditions']:
            single=features();column=single.columns.index(R.LONG_COLUMNS[0] if condition['factor']=='long_up_votes' else condition['factor'])
            single.buy_X[:,column]=np.nan;single.sell_X[:,column]=np.nan
            assert not R.apply(single,direction,identity).any()
        assert np.array_equal(R.apply(features(),direction,identity),direction)
        checks[identity]={'鏡像':True,'元方向の部分集合':True,'prefixと未来改変':True,
            '全未知と必要列未知':True,'全条件成立は同体':True}
    # ----------------------------------------
    # 長期票は各値>0だけを数え、票の必要数と等号は>=で判定する。
    for number,minimum in ((1,2),(2,3),(3,4)):
        identity=f'G{number:02d}'
        for votes in range(5):
            source=features();indices=[source.columns.index(name) for name in R.LONG_COLUMNS]
            source.buy_X[:,indices]=0;source.sell_X[:,indices]=0
            source.buy_X[:,indices[:votes]]=1;source.sell_X[:,indices[:votes]]=1
            expected=direction if votes>=minimum else np.zeros_like(direction)
            assert np.array_equal(R.apply(source,direction,identity),expected)
    for identity,column,threshold,inclusive in [('G04','m15_hist_delta_to_side',0,True),
            ('G06','m1_volume_relative_prior3',.75,True),('G08','m5_di_difference_to_side',0,False),
            ('G10','m5_hist_delta_to_side',0,False),('G10','m5_rsi_delta_to_side',0,False)]:
        for difference in (-1e-9,0,1e-9):
            source=features();position=source.columns.index(column)
            source.buy_X[:,position]=threshold+difference;source.sell_X[:,position]=threshold+difference
            passes=difference>=0 if inclusive else difference>0
            assert np.array_equal(R.apply(source,direction,identity),direction if passes else np.zeros_like(direction))
    # ----------------------------------------
    # 元Source買側が通っても、REVERSE後は売実側が通るかを別に判定する。
    source=features();source.sell_X[:]=-1;buy=np.ones(16,dtype=np.int8)
    for identity in ('G01','G02','G03','G04','G05','G06','G07','G08','G09','G10','G11'):
        assert np.array_equal(R.apply(source,buy,identity),buy)
        assert not R.apply(source,-buy,identity).any()
        wrong=-R.apply(source,buy,identity)
        assert not np.array_equal(wrong,R.apply(source,-buy,identity))
    sparse=np.zeros(16,dtype=np.int8);sparse[3]=1
    source=features();source.buy_X[3,source.columns.index(R.LONG_COLUMNS[0])]=np.nan
    assert not R.apply(source,sparse,'G01').any()
    assert R.apply(source,sparse,'G01')[4]==0
    dictionary=here/'候補辞書178.json';dictionary.write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    proof={'成功':True,'人工のみで自然特徴と金融未読':True,'ゲート数':12,'照合セル':cells,
        '各ゲート':checks,'長期票と厳密/包含閾値境界':True,'正逆変換後の実側を判定':True,
        '元EDGEを再発火しない':True,'G00追加制限なしを保持':True,
        'SourceSHA256':hashlib.sha256((here/'gates178.py').read_bytes()).hexdigest(),
        '候補辞書SHA256':hashlib.sha256(dictionary.read_bytes()).hexdigest()}
    (here/'人工確認178.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':
    main()
