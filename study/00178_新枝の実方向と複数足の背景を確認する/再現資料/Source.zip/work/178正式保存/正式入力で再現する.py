"""178純方向と固定四案を正式148から再生成し、旧/追加/全80と両端対照を照合する。"""
from pathlib import Path
from io import BytesIO
import argparse
import gzip
import json
import sys
import zipfile
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work/175局面別入口の再探索'))
import 基盤175 as BASE
B=BASE.B
TRIAL=ROOT/'study/00178_新枝の実方向と複数足の背景を確認する'


def main() -> None:
    """
    機能: 正式Source連鎖と小正本から全純方向/全pack/全80を再構成する。
    引数: --archive(Path)は178小正本ZIP、--output(Path)は新規work確認先。
    返り値: None。新探索や追加期選択、原板/cacheの読込を行わない。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--archive',type=Path,default=TRIAL/'再現資料/出生と比較正本.zip')
    parser.add_argument('--output',type=Path,required=True);args=parser.parse_args();output=args.output.resolve()
    assert output.is_relative_to(ROOT/'work') and not output.exists()
    adapter=B.P.module(ROOT/'work/178追加七場適用/固定政策を適用する.py','formal178_adapter')
    helper=B.P.module(ROOT/'work/177追加七場適用/固定政策を適用する.py','formal177_helper_for178')
    verification=B.P.module(ROOT/'work/178新枝の確認比較/検証178.py','formal178_verification')
    gates=B.P.module(ROOT/'work/178新枝の実方向確認/gates178.py','formal178_gates')
    builder=B.P.module(verification.P.BUILDER,'formal177_builder_for178')
    formal176=B.P.module(ROOT/'work/176正式保存/正式入力で再現する.py','formal176_context_for178')
    checks=[];endpoints={};noadd={};regenerated={};metadata={}
    with zipfile.ZipFile(args.archive) as archive:
        assert archive.testzip() is None
        def read(name: str) -> dict:
            """
            機能: 小正本ZIPのJSONを元byteから読む。
            引数: name(str)はmember名。
            返り値: dictはJSON又はgzip JSON。
            """
            body=archive.read(name);return json.loads(gzip.decompress(body) if name.endswith('.gz') else body)
        fixed_body=read('work/178新枝の確認比較/旧73の固定選択.json');parent_body=read('work/177高ADX枝の増分比較/旧73の固定選択.json')
        assert fixed_body['成功'] and parent_body['成功']
        fixed=[p for route in ('全期','前48') for p in fixed_body['選択'][route]['candidates']]
        parents=[p for route in ('全期','前48') for p in parent_body['選択'][route]['candidates']]
        assert len(fixed)==len(parents)==4 and {p['id'] for p in fixed}==adapter.IDS
        originals={r['birth_key']:r for p in parents for rows in p['options'].values() for r in rows};ids=sorted({r['rule_id'] for r in originals.values()})
        control=adapter.controls(parents,verification);parent_lookup={p['id']:p for p in parents}
        for period,context in (('旧73',formal176.old_context()),('追加7',B.load_context(True))):
            born=builder.build(context.features,np.asarray([s['start'] for s in context.scenes]),context.event_phases,candidate_ids=ids)
            assert born['candidate_ids']==ids and np.array_equal(born['phases'],context.event_phases)
            raw={name:born['directions'][i] for i,name in enumerate(ids)};pure={'phases':context.event_phases}
            for key,rule in originals.items():
                assert key==rule['rule_id']+'/'+rule['orientation'] and rule['orientation'] in ('NORMAL','REVERSE')
                oriented=raw[rule['rule_id']].copy() if rule['orientation']=='NORMAL' else -raw[rule['rule_id']]
                for number in range(12):
                    gate=f'G{number:02}';pure[gate+'|'+key]=gates.apply(context.features,oriented,gate)
            if period=='旧73':
                with np.load(BytesIO(archive.read('work/178新枝の確認比較/純出生178.npz')),allow_pickle=False) as sealed:
                    assert set(pure)==set(sealed.files)
                    assert all(np.array_equal(value,sealed[key]) for key,value in pure.items())
            report=read(f'work/178追加七場適用/{period}の全取得178.json.gz')
            assert len(report['rows'])==4 and [r['id'] for r in report['rows']]==[p['id'] for p in fixed]
            assert len({r['id'] for r in report['rows']})==4
            eligible,hours=helper.A.eligibility(context)
            meta={'場数':len(context.scenes),'場順':context.sessions,'対象場':eligible,'対象時間':hours,
                '幅順':list(context.table.widths),'期限順':list(context.table.horizons)}
            assert all(report[key]==value for key,value in meta.items()),(period,'metadata');metadata[period]=meta
            ref174={r['id']:r for r in read(f'work/174追加七場適用/{period}の全取得174.json.gz')['rows']}
            ref177={r['id']:r for r in read(f'work/177追加七場適用/{period}の全取得177.json.gz')['rows']}
            with np.load(BytesIO(archive.read(f'work/174追加七場適用/{period}の純出生174.npz')),allow_pickle=False) as sealed:
                assert np.array_equal(sealed['phases'],context.event_phases)
                bases={base:{key:sealed[base+'__'+key].copy() for key in helper.KEYS} for base in helper.BASE_IDS}
            noadd[period]=helper.no_add_check(context,bases,ref174,verification.P)
            assert noadd[period]==report['追加なし旧174四対照全pack同体']
            expected={r['id']:r for r in report['rows']};rows=[];endpoints[period]=[]
            with np.load(BytesIO(archive.read(f'work/178追加七場適用/{period}の純出生178.npz')),allow_pickle=False) as sealed:
                assert np.array_equal(sealed['phases'],context.event_phases);keys={'phases'}
                for policy in [*fixed,*control]:
                    birth,mw,fw,hi,active,blocked=verification.P.combine(bases[policy['base']],context.event_phases,policy['options'],pure,list(context.table.horizons))
                    arrays={**birth,'mw':mw,'fw':fw,'hi':hi,'active':active,'blocked':blocked}
                    for key,value in arrays.items():
                        name=policy['id']+'__'+key;keys.add(name);assert np.array_equal(value,sealed[name]),(period,name)
                    value=B.replay(context,birth,mw,fw,hi,True)
                    if policy in control:
                        if policy['gate']=='G00':
                            actual=helper.pack(context,value,parent_lookup[policy['parent']],active,verification.P)
                            assert actual==ref177[policy['parent']]
                        else:
                            actual=helper.A.pack(context,value,ref174[policy['base']]['policy'])
                            assert all(actual[k]==v for k,v in ref174[policy['base']].items())
                        endpoints[period].append({'parent':policy['parent'],'gate':policy['gate'],'全取得engine金融台帳一致':True,'取得':len(value[0].cases)})
                        continue
                    row=helper.pack(context,value,policy,active,verification.P);assert row==expected[policy['id']],(period,policy['id'],'全pack')
                    assert max((r['peak_global_reserved'] for r in row['engine']['audits']),default=0)<=1
                    rows.append(row);checks.append({'期間':period,'id':policy['id'],'取得':len(row['cases']),'新枝':row['new_count'],
                        '全純出生/全pack/added/origins/金融/経路一致':True})
                assert keys==set(sealed.files)
            assert endpoints[period]==report['G00=177_G99=174全pack同体'];regenerated[period]=rows
        expected80=read('work/178追加七場適用/全80の両中央値178.json.gz')
        eligible={n:metadata['旧73']['対象場'][n]+metadata['追加7']['対象場'][n] for n in ('DAY','PRE','POST')}
        hours={n:metadata['旧73']['対象時間'][n]+metadata['追加7']['対象時間'][n] for n in ('DAY','PRE','POST')}
        assert expected80['場数']==metadata['旧73']['場数']+metadata['追加7']['場数']==80
        assert expected80['対象場']==eligible and expected80['対象時間']==hours
        assert len(expected80['rows'])==4 and [r['id'] for r in expected80['rows']]==[p['id'] for p in fixed]
        actual_rows=[]
        for old,added in zip(regenerated['旧73'],regenerated['追加7'],strict=True):
            assert old['id']==added['id'];joined={n:old['ledger'][n]+added['ledger'][n] for n in ('net','known','label','scene')}
            phases=old['phases']+added['phases'];origins=old['origins']+added['origins'];flags=old['added']+added['added']
            financial=B.metrics173.evaluate_metrics(joined['net'],joined['known'],joined['label'],joined['scene'],phases,origins,eligible,hours)
            actual_rows.append({'id':old['id'],'policy':old['policy'],'financial':financial,'paths':helper.A.paths(financial),
                'ledger':joined,'phases':phases,'origins':origins,'added':flags,'new_count':sum(flags),
                'old_main_count':old['old_main_count']+added['old_main_count'],'fallback_count':old['fallback_count']+added['fallback_count'],
                '旧73':old['financial'],'追加7':added['financial']})
        assert actual_rows==expected80['rows']
    output.mkdir(parents=True)
    B.P.save(output/'再現確認.json',{'成功':True,'確認':checks,'旧178全84純方向再生成一致':True,'両端対照全pack同体':endpoints,
        '旧174追加なし四対照全pack同体':noadd,'全80全行/対象場時間/金融/経路/added一致':True,'正式148キャッシュ不使用':True,
        '小正本SHA256':B.P.sha(args.archive),'注意':'178で新探索を一旦停止した有望候補。既使用入力の固定再現であり追加期悪化を消さない。'})
    print(json.dumps({'成功':True,'候補期間':len(checks),'両端対照':sum(len(v) for v in endpoints.values()),
        '旧174noadd':sum(len(v) for v in noadd.values()),'全80全行一致':True},ensure_ascii=False))


if __name__=='__main__':main()
