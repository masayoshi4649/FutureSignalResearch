"""176→177の正式Source連鎖を参照し、178固定研究の薄いSourceと小正本を保存する。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import json
import os
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'work/177正式保存'))
import 保存177 as PREVIOUS
P=PREVIOUS.P
TRIAL=ROOT/'study/00178_新枝の実方向と複数足の背景を確認する'
PARENT=ROOT/'study/00177_固定幹を保ち高ADXの入口を増分比較する/再現資料'
DESTINATION=TRIAL/'再現資料'
CSV=ROOT/'outputs/00178_新枝の実方向確認'
IDS={'全期_J002_J000_K012','全期_J002_J000_K013','前48_J000_J005_K000','前48_J000_J005_K008'}


def verify_source(ref: dict) -> None:
    """
    機能: Source継承連鎖の各ZIP・索引・全memberを元byteへ照合する。
    引数: ref(dict)はarchive/index/membersと任意の親Source継承元。
    返り値: None。旧workの現在Sourceへ差し替えない。
    """
    if '親Source継承元' in ref:verify_source(ref['親Source継承元'])
    source=ROOT/ref['archive']['path'];assert P.fingerprint(source)==ref['archive']
    assert P.fingerprint(ROOT/ref['index']['path'])==ref['index']
    with zipfile.ZipFile(source) as archive:
        assert archive.testzip() is None and len(archive.namelist())==len(ref['members'])
        assert set(archive.namelist())=={r['path'] for r in ref['members']}
        assert all(P.member_reference(r['path'],archive.read(r['path']))==r for r in ref['members'])


def inherited() -> tuple:
    """
    機能: 177→176 Source参照と、174幹/177G00対照の必要七memberを継承する。
    引数: なし。
    返り値: tuple[dict,dict,dict,dict]はSource連鎖・旧小入力参照・元byte・CSV出力器参照。
    """
    index=P.read(PARENT/'保存索引.json');assert index['正式保存']
    source_ref={'archive':index['Source']['archive'],'index':P.fingerprint(PARENT/'保存索引.json'),
        'members':index['Source']['members'],'親Source継承元':index['Source継承元'],
        '復元順':'176全Source→177薄いSource→178薄いSource。各ZIP元byteを指紋照合する。'}
    verify_source(source_ref)
    dependency='work/177正式保存/保存177.py'
    assert P.fingerprint(Path(PREVIOUS.__file__))==next(r for r in source_ref['members'] if r['path']==dependency)
    csv_ref=next(r for r in source_ref['members'] if r['path']=='scripts/損益CSV/候補別に出力する.mjs')
    assert P.fingerprint(ROOT/csv_ref['path'])==csv_ref
    canonical=PARENT/'出生と比較正本.zip';assert P.fingerprint(canonical)==index['正本']['archive']
    expected={r['path']:r for r in index['正本']['members']}
    names=[f'work/174追加七場適用/{period}の{kind}174.{suffix}' for period in ('旧73','追加7') for kind,suffix in (('純出生','npz'),('全取得','json.gz'))]
    names.extend(f'work/177追加七場適用/{period}の全取得177.json.gz' for period in ('旧73','追加7'))
    names.append('work/177高ADX枝の増分比較/旧73の固定選択.json');contents={}
    with zipfile.ZipFile(canonical) as archive:
        assert archive.testzip() is None
        for name in names:
            body=archive.read(name);assert P.member_reference(name,body)==expected[name];contents[name]=body
    return source_ref,{'archive':P.fingerprint(canonical),'index':P.fingerprint(PARENT/'保存索引.json'),
        'members':[expected[n] for n in names],'元byte継承':True},contents,csv_ref


def collect() -> tuple:
    """
    機能: 178自身のSource・小正本だけを列挙し、画像とCSV本文を省略する。
    引数: なし。
    返り値: tuple[list,list,list]は新Source・小結果・省略指紋。
    """
    sources=[];results=[];omitted=[]
    for folder in sorted(p for p in (ROOT/'work').glob('178*') if p.is_dir() and '隔離再現' not in p.name):
        for current,dirs,files in os.walk(folder,followlinks=False):
            dirs[:]=[n for n in dirs if n not in P.EXCLUDED_DIRS and 'cache' not in n.lower()]
            for name in files:
                path=Path(current)/name
                if path.suffix in ('.py','.mjs'):sources.append(path);continue
                if path.is_relative_to(HERE) and path.name!='README.md':continue
                if path.suffix not in ('.md','.json','.gz','.npz','.png','.jpg','.webp','.csv'):continue
                reason=None
                if path.suffix=='.npz' and '予備統計' in path.name:reason='再生成中間の予備統計。純出生・軸・Source・固定票・指紋を保持する。'
                elif path.suffix in ('.png','.jpg','.webp'):reason='表示画像は再生成中間。重複保存しない。'
                elif path.suffix=='.csv':reason='閲覧CSV本文はoutputs正本を指紋参照する。'
                if reason:omitted.append({'file':P.fingerprint(path),'理由':reason})
                else:assert path.stat().st_size<16*1024*1024;results.append(path)
    results.extend(p for p in TRIAL.rglob('*') if p.is_file() and '再現資料' not in p.relative_to(TRIAL).parts and p.suffix in ('.json','.md'))
    assert Path(__file__) in sources and HERE/'正式入力で再現する.py' in sources
    return sorted(set(sources)),sorted(set(results)),sorted(omitted,key=lambda r:r['file']['path'])


def gates(final: bool, extra: list) -> dict:
    """
    機能: 固定四案・独立検査・主二案CSV八本・最終隔離を保存前確認する。
    引数: final(bool)、extra(list[Path])はRoot追加必須。
    返り値: dictは保存gateと全ファイル指紋。
    """
    fixed=P.read(ROOT/'work/178新枝の確認比較/旧73の固定選択.json')
    assert {r['id'] for v in fixed['選択'].values() for r in v['candidates']}==IDS
    required=[TRIAL/'条件.json',*[ROOT/'work/178新枝の確認比較'/n for n in ('両端対照の同体.json','帯別確認.json.gz','三帯接合.json.gz','純出生178.npz','旧73の固定選択.json')],
        *[ROOT/'work/178追加七場適用'/n for n in ('旧73の全取得178.json.gz','追加7の全取得178.json.gz','全80の両中央値178.json.gz','金融前の出生固定.json','完了.json')],
        *[ROOT/'work/178確認の独立検査'/n for n in ('純ゲートの独立確認.json','旧73金融と選択の独立結果.json','追加七場と全80の独立結果.json','主候補CSVの独立結果.json')],*extra]
    assert all(p.is_file() for p in required),[str(p) for p in required if not p.is_file()]
    assert P.read(ROOT/'work/178追加七場適用/完了.json')['金融後Source変更なし']
    assert all(P.read(ROOT/'work/178確認の独立検査'/n)['成功'] for n in ('純ゲートの独立確認.json','旧73金融と選択の独立結果.json','追加七場と全80の独立結果.json','主候補CSVの独立結果.json'))
    csv_files=sorted(CSV.rglob('*.csv'));assert len(csv_files)==8
    if final:
        assert all((TRIAL/n).is_file() for n in ('README.md','設定と結果.md','再現手順.md'))
        audit=ROOT/'work/178隔離再現/repo/work/監査結果.json';verification=ROOT/'work/178隔離再現/repo/work/正式runner確認/再現確認.json'
        assert P.read(audit)['成功'] and P.read(verification)['成功']
        assert P.fingerprint(ROOT/'work/178隔離再現/repo/work/178正式保存/正式入力で再現する.py')['sha256']==P.fingerprint(HERE/'正式入力で再現する.py')['sha256']
        assert P.read(audit)['監査SourceSHA256']==P.fingerprint(HERE/'監査実行.py')['sha256'];required.extend([audit,verification])
    return {'成功':True,'必須':[P.fingerprint(p) for p in sorted(set(required))],'固定四案と近傍pack保持':sorted(IDS),
        '主二案CSV':[P.fingerprint(p) for p in csv_files],'判断':'178の有望な結論で新探索一旦停止。追加期悪化を保持し安定実運用採用と区別する。'}


def execute(destination: Path, final: bool, extra: list) -> dict:
    """
    機能: 178新Sourceだけの薄いZIPと固定四案小正本を新規保存する。
    引数: destination(Path)、final(bool)、extra(list[Path])。
    返り値: dictは保存索引。175〜177 ZIPを上書きしない。
    """
    assert not any((destination/n).exists() for n in ('Source.zip','出生と比較正本.zip','保存索引.json'))
    gate=gates(final,extra);source_ref,old_ref,old_small,csv_ref=inherited();source_paths,result_paths,omitted=collect()
    before={p.relative_to(ROOT).as_posix():P.fingerprint(p) for p in source_paths+result_paths}
    source_bytes={p.relative_to(ROOT).as_posix():p.read_bytes() for p in source_paths}
    ancestor_names={r['path'] for r in source_ref['members']}|{r['path'] for r in source_ref['親Source継承元']['members']}
    assert not set(source_bytes)&ancestor_names
    source_bytes['継承/177Sourceの参照.json']=(json.dumps(source_ref,ensure_ascii=False,separators=(',',':'))+'\n').encode('utf-8')
    results={p.relative_to(ROOT).as_posix():p.read_bytes() for p in result_paths};assert not set(results)&set(old_small);results.update(old_small)
    if final:
        for path in (ROOT/'work/178隔離再現/repo/work/監査結果.json',ROOT/'work/178隔離再現/repo/work/正式runner確認/再現確認.json'):
            results['検査/178隔離/'+path.name]=path.read_bytes()
    destination.mkdir(parents=True,exist_ok=True)
    source=P.write_archive(destination/'Source.zip',source_bytes);canonical=P.write_archive(destination/'出生と比較正本.zip',results)
    assert all(P.fingerprint(ROOT/name)==value for name,value in before.items());verify_source(source_ref)
    assert P.fingerprint(PARENT/'出生と比較正本.zip')==old_ref['archive']
    index={'成功':True,'正式保存':final,'保存UTC':datetime.now(timezone.utc).isoformat(),'Source':source,'正本':canonical,
        'Source継承元':source_ref,'旧小入力の選択継承':old_ref,'CSV出力器継承':csv_ref,'新Source':[P.fingerprint(p) for p in source_paths],
        '完了gate':gate,'省略中間指紋':omitted,'保存器':P.fingerprint(Path(__file__)),
        '共用入力':'正式148射影・共有163/167。176全Source→177薄いSource→178薄いSourceを元byte復元。原板/cache/巨大金融副本なし。',
        '注意':'178で新探索一旦停止。全80既使用、追加期悪化を保持。主2案CSV8のみ閲覧化し、近傍を含む固定四案金融/packを恒久保存。'}
    (destination/'保存索引.json').write_text(json.dumps(index,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    return index


def main() -> None:
    """
    機能: 隔離用仮保存とRoot GO後の正式保存を明示指定で区別する。
    引数: --prepare(bool)、--execute/--go(bool)、--require(Path,反復可)。
    返り値: None。指定なしでは正式資料を作らない。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--prepare',action='store_true');parser.add_argument('--execute',action='store_true');parser.add_argument('--go',action='store_true')
    parser.add_argument('--require',type=Path,action='append',default=[]);args=parser.parse_args();extra=[(p if p.is_absolute() else ROOT/p).resolve() for p in args.require]
    if args.prepare:assert not args.execute and not args.go;result=execute(HERE/'仮保存',False,extra)
    elif args.execute or args.go:assert args.execute and args.go;result=execute(DESTINATION,True,extra)
    else:print(json.dumps({'準備済み':True,'正式保存未実行':True},ensure_ascii=False));return
    print(json.dumps({'成功':True,'正式保存':result['正式保存'],'Source':result['Source']['archive'],'正本':result['正本']['archive']},ensure_ascii=False))


if __name__=='__main__':main()
