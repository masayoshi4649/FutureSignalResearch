"""176→177→178の正式Source連鎖をZIPから復元して178固定再現を監査実行する。"""
from pathlib import Path
import argparse
import json
import os
import shutil
import subprocess
import sys
import venv
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
ISOLATION=ROOT/'work/178隔離再現'
sys.path.insert(0,str(ROOT/'work/176正式保存'))
import 隔離を準備する as P


def restore_source(ref: dict, repository: Path, seen: set) -> None:
    """
    機能: 祖先から順に正式Sourceの全byteを検証・復元する。
    引数: ref(dict)、repository(Path)、seen(set)は循環/重複防止集合。
    返り値: None。同じSourceを再度適用しない。
    """
    if '親Source継承元' in ref:restore_source(ref['親Source継承元'],repository,seen)
    key=ref['archive']['sha256'];assert key not in seen;seen.add(key)
    source=ROOT/ref['archive']['path'];index=ROOT/ref['index']['path']
    assert P.digest(source)==key and P.digest(index)==ref['index']['sha256']
    P.restore(source,ref['members'],repository,True)


def main() -> None:
    """
    機能: Source連鎖と必要小入力だけの新規隔離repo/venvを作り監査付き再現する。
    引数: --bundle(Path)は178正式又は仮保存の索引/二ZIPのフォルダ。
    返り値: None。元work/cache/原板や共有入力への書込はrunner監査で拒否する。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--bundle',type=Path,default=HERE/'仮保存');args=parser.parse_args();bundle=args.bundle.resolve()
    index=json.loads((bundle/'保存索引.json').read_text(encoding='utf-8'));assert index['成功'] and not ISOLATION.exists()
    for field,name in (('Source','Source.zip'),('正本','出生と比較正本.zip')):assert P.digest(bundle/name)==index[field]['archive']['sha256']
    repository=ISOLATION/'repo';repository.mkdir(parents=True);seen=set();restore_source(index['Source継承元'],repository,seen)
    P.restore(bundle/'Source.zip',index['Source']['members'],repository,True)
    P.restore(bundle/'出生と比較正本.zip',index['正本']['members'],repository,False)
    artifacts=repository/'artifacts';artifacts.mkdir();shutil.copy2(bundle/'出生と比較正本.zip',artifacts/'出生と比較正本.zip')
    P.junction(repository/'inputs',ROOT/'inputs');P.junction(repository/'study',ROOT/'study')
    environment=ISOLATION/'環境';venv.EnvBuilder(with_pip=False,symlinks=False).create(environment)
    site=Path(np.__file__).resolve().parent.parent;isolated_site=environment/'Lib/site-packages'
    packages=[p for p in site.iterdir() if p.name in ('numpy','numpy.libs','tzdata') or p.name.startswith(('numpy-','tzdata-')) and p.name.endswith('.dist-info')]
    assert any(p.name=='numpy' for p in packages) and any(p.name=='tzdata' for p in packages)
    for package in packages:shutil.copytree(package,isolated_site/package.name)
    audit=ISOLATION/'監査実行.py';shutil.copy2(HERE/'監査実行.py',audit)
    (ISOLATION/'準備.json').write_text(json.dumps({'成功':True,'祖先Source数':len(seen),'178新SourceSHA256':P.digest(bundle/'Source.zip'),
        '小正本SHA256':P.digest(bundle/'出生と比較正本.zip'),'環境':'新規venv・NumPy'+np.__version__+'・tzdata',
        '共有入力':'inputs/study読取監査、原板/cache/元work禁止','監査SourceSHA256':P.digest(audit)},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    env=os.environ.copy();env.pop('PYTHONPATH',None);env.update({'PYTHONIOENCODING':'utf-8','PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'})
    subprocess.run([str(environment/'Scripts/python.exe'),str(audit)],cwd=repository,env=env,check=True)


if __name__=='__main__':main()
