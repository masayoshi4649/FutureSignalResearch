"""固定178の全期主・前半主を、候補別CSV用の型付き値へ整理する。"""
from pathlib import Path
import gzip
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).parent


def main() -> None:
    """
    機能: 全80台帳から利益・損失・累計・旧主/新枝/T数を整理する。
    引数: なし。
    返り値: None。未知を空欄にするJSONを出力し、CSV authorは別に行う。
    """
    path=ROOT/'work/178追加七場適用/全80の両中央値178.json.gz'
    body=path.read_bytes();data=json.loads(gzip.decompress(body))
    tables={'候補比較':{'headers':['候補','選択範囲','区分','対象場数','取得場数','取得回数','旧主取得','新枝取得','初参加T取得',
        'F','A','N','C','金融未知件数','先着率','既知利益円','既知損失円','既知収支円','利益損失比',
        '建玉中央値下限円','建玉中央値上限円','場中央値下限円','場中央値上限円','完全場数','両中央値判定','取得毎時','全件確定収支円'],'rows':[]}}
    columns=['候補','選択範囲','セッション日','セッションID','利益円_既知','損失円_既知','収支円_全件確定','収支円_既知分',
        '累計収支円_全件確定','累計収支円_既知分','取得回数','旧主取得','新枝取得','初参加T取得','F','A','N','C','金融未知件数','累計金融未知件数','取引なし理由']
    for name in ('デイ','ナイト_米前','ナイト_米後'):tables[name]={'headers':columns,'rows':[]}
    seen=set();records=[]
    for record in data['rows']:
        route=record['policy']['route']
        if route in seen:continue
        seen.add(route);records.append(record)
    for record in records:
        identity='178:'+record['id'];route=record['policy']['route'];metric=record['financial']
        groups={**metric['phases_diagnostic'],'NIGHT':metric['session_groups_required']['NIGHT']}
        ledger=record['ledger'];phases=record['phases'];added=record['added']
        assert len(added)==len(phases)==len(ledger['net'])
        for band in ('DAY','NIGHT','PRE','POST'):
            g=groups[band];t=g['trades'];s=g['sessions'];fa=t['IFD_FIRSTFANC'];tm=t['net_median'];sm=s['net_median']
            selected=[i for i,p in enumerate(phases) if (p>0 if band=='NIGHT' else p==('DAY','PRE','POST').index(band))]
            new=sum(added[i] for i in selected);origins=g['origins'];profit=t['known_profit'];loss=t['known_loss']
            tables['候補比較']['rows'].append([identity,route,band,s['eligible_count'],s['participating_count'],t['all_count'],
                origins['主']['acquisition_count']-new,new,origins['補完']['acquisition_count'],*[fa[k] for k in ('F','A','N','C')],
                t['unknown_count'],fa['first_f_rate_reached'],profit,loss,t['known_net'],profit/loss if loss else None,
                tm['lower'],tm['upper'],sm['lower'],sm['upper'],s['complete_count'],g['decision']['status'],
                g['acquisitions_per_hour'],None if t['unknown_count'] else t['known_net']])
        for phase,(band,name) in enumerate((('DAY','デイ'),('PRE','ナイト_米前'),('POST','ナイト_米後'))):
            cumulative=0;unknown=0;rows=sorted(groups[band]['sessions']['rows'],key=lambda r:r['scene'])
            assert len(rows)==40
            for scene in rows:
                key=scene['scene'];cumulative+=scene['known_net'];unknown+=scene['unknown_count']
                selected=[i for i,(s,p) in enumerate(zip(ledger['scene'],phases,strict=True)) if s==key and p==phase]
                labels=[ledger['label'][i] for i in selected];counts=[labels.count(code) for code in (1,-1,0,2)]
                new=sum(added[i] for i in selected);assert sum(counts)==scene['all_count']
                reason='' if selected else '当該小帯で取得なし。Night全体の参加・技術成立/保有/失効は報告の原因診断を参照。'
                tables[name]['rows'].append([identity,route,key.split('_')[0],key,scene['known_profit'],scene['known_loss'],scene['all_net'],
                    scene['known_net'],cumulative if not unknown else None,cumulative,scene['all_count'],scene['main_count']-new,new,scene['supplement_count'],
                    *counts,scene['unknown_count'],unknown,reason])
            assert cumulative==groups[band]['trades']['known_net']
    target=HERE/'型付き入力.json';assert not target.exists()
    target.write_text(json.dumps({'trial':178,'確認日':'2026-11-16','inputs':[{'path':path.relative_to(ROOT).as_posix(),
        'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}],'tables':tables,
        '定義':'mini1枚、買売合計保有＋pending一枠。全80既使用。利益損失/既知累計は未知を除いた寄与、全件確定欄は未知以後空欄。先着率F/(F+A)は決済勝率ではない。'},ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'候補数':len(records),'表行数':{k:len(v['rows']) for k,v in tables.items()}},ensure_ascii=False))


if __name__=='__main__':main()
