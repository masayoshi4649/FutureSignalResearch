"""今回追加した研究文書のローカル参照を点検する。"""
from pathlib import Path
from urllib.parse import unquote
import json
import re

ROOT=Path(__file__).resolve().parents[2]


def main() -> None:
    """
    機能: 175以降の正式文書と出力案内の相対リンクを検査する。
    引数: なし。
    返り値: None。リンク先を変更せず不足だけ列挙する。
    """
    files=[ROOT/'README.md',ROOT/'docs/README.md',ROOT/'study/README.md',ROOT/'AGENTS.md',
        ROOT/'docs/議論/入口の全置換と局面別の増分を比較する.md']
    for number in (175,176,177,178):
        for folder in (ROOT/'study').glob(f'{number:05}_*'):files+=list(folder.glob('*.md'))
    for number in (177,178):
        for folder in (ROOT/'outputs').glob(f'{number:05}_*'):files+=list(folder.rglob('*.md'))
    missing=[];count=0
    for path in files:
        for target in re.findall(r'\]\(([^)]+)\)',path.read_text(encoding='utf-8')):
            target=target.strip('<>').split('#')[0]
            if not target or re.match(r'[a-z]+:',target,re.I):continue
            count+=1;resolved=(path.parent/unquote(target)).resolve()
            if not resolved.exists():missing.append({'文書':path.relative_to(ROOT).as_posix(),'参照':target})
    print(json.dumps({'文書数':len(files),'ローカル参照数':count,'不足':missing},ensure_ascii=False))


if __name__=='__main__':main()
