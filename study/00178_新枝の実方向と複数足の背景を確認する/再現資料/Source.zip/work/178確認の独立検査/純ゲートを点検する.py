"""178金融を読まず、実側の12ゲートを人工値の逐次判定へ照合する。"""
from pathlib import Path
from types import SimpleNamespace
import hashlib
import importlib.util
import json
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
SOURCE=ROOT/'work/178新枝の実方向確認/gates178.py'


def expected(features: object, direction: np.ndarray, number: int) -> np.ndarray:
    """
    機能: 実方向の一行ずつの値から12条件を独立に判定する。
    引数: features(object)は人工特徴、direction(np.ndarray)、number(int)は0..11。
    返り値: np.ndarrayは通す元方向又は0。
    """
    result=[];long=[f'm{m}_{name}' for m in (15,30) for name in ('ema21_delta_to_side','di_difference_to_side')]
    minimum={1:2,2:3,3:4,4:2,5:3,6:2,7:3,8:2,9:3,10:2,11:3}
    for index,side in enumerate(direction):
        if not number:result.append(side);continue
        if not side:result.append(0);continue
        row=(features.buy_X if side==1 else features.sell_X)[index]
        values={column:float(row[i]) for i,column in enumerate(features.columns)}
        long_values=[values[name] for name in long]
        ok=all(np.isfinite(v) for v in long_values) and sum(v>0 for v in long_values)>=minimum[number]
        checks=[]
        if number in (4,5):checks.append(('m15_hist_delta_to_side',0,True))
        if number in (6,7):checks.append(('m1_volume_relative_prior3',.75,True))
        if number in (8,9):checks.append(('m5_di_difference_to_side',0,False))
        if number in (10,11):checks.extend((name,0,False) for name in ('m5_hist_delta_to_side','m5_rsi_delta_to_side'))
        for name,threshold,inclusive in checks:
            value=values[name];ok &= np.isfinite(value) and (value>=threshold if inclusive else value>threshold)
        result.append(side if ok else 0)
    return np.asarray(result,dtype=np.int8)


def main() -> None:
    """
    機能: 金融を使わない人工分布で実側・未知・等号・鏡像・prefixを独立確認する。
    引数: なし。
    返り値: None。担当workへ確認JSONだけを保存し、178出生や金融は生成しない。
    """
    spec=importlib.util.spec_from_file_location('gates178_independent',SOURCE);G=importlib.util.module_from_spec(spec)
    sys.modules[spec.name]=G;spec.loader.exec_module(G)
    before=hashlib.sha256(SOURCE.read_bytes()).hexdigest()
    columns=list(G.LONG_COLUMNS)+['m15_hist_delta_to_side','m1_volume_relative_prior3','m5_di_difference_to_side','m5_hist_delta_to_side','m5_rsi_delta_to_side']
    rng=np.random.default_rng(178);n=97
    choices=np.asarray([-1.0,0.0,.749999,.75,.750001,1.0,np.nan,np.inf,-np.inf])
    features=SimpleNamespace(columns=columns,buy_X=rng.choice(choices,(n,len(columns))),sell_X=rng.choice(choices,(n,len(columns))))
    direction=rng.choice(np.asarray([-1,0,1],np.int8),n)
    comparisons=0
    for number in range(12):
        gate=f'G{number:02}';wanted=expected(features,direction,number);actual=G.apply(features,direction,gate)
        assert np.array_equal(wanted,actual);comparisons+=n
        mirror=SimpleNamespace(columns=columns,buy_X=features.sell_X,sell_X=features.buy_X)
        assert np.array_equal(G.apply(mirror,-direction,gate),-actual);comparisons+=n
        for end in (1,23,70):
            prefix=SimpleNamespace(columns=columns,buy_X=features.buy_X[:end],sell_X=features.sell_X[:end])
            assert np.array_equal(G.apply(prefix,direction[:end],gate),actual[:end]);comparisons+=end
        assert np.all((actual==0)|(actual==direction))
    assert G.catalog()==json.loads((SOURCE.parent/'候補辞書178.json').read_text(encoding='utf-8'))
    assert before==hashlib.sha256(SOURCE.read_bytes()).hexdigest()
    result={'成功':True,'178金融未読':True,'人工ゲート数':12,'照合セル':comparisons,
        '逐次独立判定':True,'正逆後の実側':True,'鏡像':True,'prefix':True,'元方向の部分集合':True,
        '未知と等号境界':True,'SourceSHA256':before,'Source変更なし':True,
        '読込範囲':['178純ゲートSource','178純辞書','この人工検査Source'],'自然入力なし':True}
    (HERE/'純ゲートの独立確認.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':main()
