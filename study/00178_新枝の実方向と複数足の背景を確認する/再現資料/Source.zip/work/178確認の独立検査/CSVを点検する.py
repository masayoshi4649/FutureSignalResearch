"""178の主二候補だけのCSVを、全80台帳の独立集計へ読取照合する。"""
from pathlib import Path
import importlib.util
import json
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
OUTPUT=ROOT/'outputs/00178_新枝の実方向確認'
PACK=ROOT/'work/178追加七場適用/全80の両中央値178.json.gz'
TYPED=ROOT/'work/178候補別CSV/型付き入力.json'
FIXED=ROOT/'work/178新枝の確認比較/旧73の固定選択.json'


def main() -> None:
    """
    機能: 主二候補×四CSVを固定選択・型付き値・独立金融へ照合する。
    引数: なし。
    返り値: None。CSVへ書込まず検査票だけ担当workへ保存する。
    """
    source=ROOT/'work/177増分の独立検査/CSVを点検する.py'
    spec=importlib.util.spec_from_file_location('csv177_for178',source);C=importlib.util.module_from_spec(spec)
    sys.modules[spec.name]=C;spec.loader.exec_module(C);V=C.V
    files=[PACK,TYPED,FIXED,*sorted(OUTPUT.rglob('*.csv')),Path(__file__),source]
    assert len(files)==13;before=[V.fingerprint(path) for path in files]
    body=V.read(PACK);typed=V.read(TYPED);fixed=V.read(FIXED)
    ids=[fixed['選択'][route]['主案'] for route in ('全期','前48')];assert all(ids) and len(set(ids))==2
    assert typed['trial']==178 and typed['inputs']==[V.fingerprint(PACK)]
    assert typed['tables']['候補比較']['headers']==C.SUMMARY_COLUMNS
    assert all(typed['tables'][name]['headers']==C.SESSION_COLUMNS for name in ('デイ','ナイト_米前','ナイト_米後'))
    assert all({values[0] for values in table['rows']}=={'178:'+identity for identity in ids} for table in typed['tables'].values())
    counter={'scalar':0,'files':0,'rows':0,'cells':0,'typed_tables':0};actual_files=set()
    for identity in ids:
        row=next(row for row in body['rows'] if row['id']==identity)
        tables=C.independent_tables(row,body['対象場'],body['対象時間'])
        for name,wanted in tables.items():
            for values in wanted:values[0]='178:'+identity
            selected=[values for values in typed['tables'][name]['rows'] if values[0]=='178:'+identity]
            V.compare(wanted,selected,identity+'/'+name+'/型付き値',counter);counter['typed_tables']+=1
            path=OUTPUT/('178_'+identity)/('集計.csv' if name=='候補比較' else name+'.csv')
            C.compare_csv(path,C.SUMMARY_COLUMNS if name=='候補比較' else C.SESSION_COLUMNS,wanted,counter);actual_files.add(path)
    assert actual_files==set(OUTPUT.rglob('*.csv')) and counter['files']==8
    assert before==[V.fingerprint(path) for path in files]
    result={'成功':True,'対象候補':ids,'不一致':0,'検査':counter,'CSVと入力不変':True,'入力':before,
        '方法':'旧73で固定した各route主だけを選び、8CSV全セルを独立台帳集計・型付き入力へ照合。各帯40場、未知空欄と累計、旧主/新枝/Tを確認。近傍はpackに保持。'}
    (HERE/'主候補CSVの独立結果.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps({key:result[key] for key in ('成功','対象候補','不一致','検査','CSVと入力不変')},ensure_ascii=False))


if __name__=='__main__':main()
