"""178固定四案の台帳金融・全体中央値・両端全packを独立点検する。"""
from pathlib import Path
from io import BytesIO
import gzip
import importlib.util
import json
import sys
import zipfile
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
PACK=ROOT/'work/178追加七場適用'
FIXED=ROOT/'work/178新枝の確認比較/旧73の固定選択.json'
SHA='a838e86a36c578f3f5c6ec99f4c1b6c7bbe532ba801d77a1324a95d68fa8433d'


def module(path: Path, name: str) -> object:
    """
    機能: mainを起動せず固定された検査部品を読む。
    引数: path(Path)、name(str)。
    返り値: objectは読み込んだ部品。
    """
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec)
    sys.modules[name]=value;spec.loader.exec_module(value);return value


A=module(ROOT/'work/177増分の独立検査/追加七場と全体を点検する.py','financial177_for178')
N=A.N;Q=A.Q;V=A.V;F=A.F


def official_rows(trial: str, period: str) -> dict:
    """
    機能: 正式ZIP/indexの物理指紋とmember指紋を確認して対照packを読む。
    引数: trial(str)は174又は177、period(str)は旧73又は追加7。
    返り値: dict[str,dict]はID別対照。
    """
    folder=ROOT/('study/00174_共同条件を残して単一建玉の入口を広げる/再現資料' if trial=='174'
        else 'study/00177_固定幹を保ち高ADXの入口を増分比較する/再現資料')
    index=V.read(folder/'保存索引.json');path=folder/'出生と比較正本.zip'
    assert V.fingerprint(path)==index['正本']['archive'];name=f'work/{trial}追加七場適用/{period}の全取得{trial}.json.gz'
    ref=next(row for row in index['正本']['members'] if row['path']==name)
    with zipfile.ZipFile(path) as archive:body=archive.read(name)
    assert ref['bytes']==len(body) and ref['sha256']==__import__('hashlib').sha256(body).hexdigest()
    return {row['id']:row for row in json.loads(gzip.decompress(body))['rows']}


def main() -> None:
    """
    機能: 追加金融GO後だけ、178全80の台帳・未知・両中央値・added・対照を検算する。
    引数: なし。Rootの追加7金融GO後に実行する。
    返り値: None。担当workにJSONを保存し、178戦略や固定正本を変更しない。
    """
    files=[PACK/(name+'.json.gz') for name in ('旧73の全取得178','追加7の全取得178','全80の両中央値178')]
    files += [FIXED,PACK/'固定政策を適用する.py',PACK/'金融前の出生固定.json',PACK/'完了.json',
        PACK/'旧73の純出生178.npz',PACK/'追加7の純出生178.npz',Path(__file__)]
    before=[V.fingerprint(path) for path in files];assert V.fingerprint(FIXED)['sha256']==SHA
    fixed=V.read(FIXED);policies=[p for route in ('全期','前48') for p in fixed['選択'][route]['candidates']];ids=[p['id'] for p in policies]
    bodies={name:V.read(path) for name,path in zip(('旧73','追加7','全80'),files[:3])}
    assert all(body['成功'] and [r['id'] for r in body['rows']]==ids for body in bodies.values())
    by_id={name:{r['id']:r for r in body['rows']} for name,body in bodies.items()}
    sys.path.insert(0,str(ROOT/'work/173両中央値と単一建玉'));import 基盤173 as B
    helper=B.P.module(ROOT/'work/177追加七場適用/固定政策を適用する.py','adapter177_178_independent')
    increment=B.P.module(ROOT/'work/177高ADX枝の増分比較/増分177.py','increment177_178_independent')
    parents=V.read(ROOT/'work/177高ADX枝の増分比較/旧73の固定選択.json')['選択']
    parents=[p for route in ('全期','前48') for p in parents[route]['candidates']]
    counters={'scalar':0,'financial_group':0,'full_risk':0,'replayed_financial_group':0,'request_capacity_checked':0,
        'shared_ledger':0,'period_compact':0,'added_flags':0,'endpoint_full_pack':0,'fixed_full_replay':0}
    summaries={};periods={};branches={};endpoint_checks=[]
    for new,name in ((False,'旧73'),(True,'追加7')):
        context=B.load_context(new);body=bodies[name];eligible,hours=Q.eligibility(context,np.ones(len(context.scenes),bool))
        assert context.sessions==body['場順'] and len(context.scenes)==body['場数']
        V.compare(eligible,body['対象場'],name+'/対象場',counters);V.compare(hours,body['対象時間'],name+'/時間',counters)
        independent={};periods[name]={};branches[name]={}
        refs={trial:official_rows(trial,name) for trial in ('174','177')}
        with np.load(PACK/(name+'の純出生178.npz'),allow_pickle=False) as sealed:
            assert np.array_equal(sealed['phases'],context.event_phases)
            for row in body['rows']:
                value=A.shared_value(context,row,counters);prefix=row['id']+'__'
                expected_added=sealed[prefix+'active'][np.asarray(row['events'])].tolist()
                V.compare(expected_added,row['added'],name+'/'+row['id']+'/added',counters);counters['added_flags']+=len(expected_added)
                branches[name][row['id']]=A.branch_counts(row)
                groups=F.financial_groups(row,eligible,hours);independent[row['id']]=groups
                Q.check_groups(groups,row['financial'],row['paths'],name+'/'+row['id'],counters)
                amended={**row,'count':len(row['cases']),'max_reserved':max(a['peak_global_reserved'] for a in row['engine']['audits'])}
                periods[name][row['id']]=N.replay_groups(context,value,amended,counters)
                for period,values in periods[name][row['id']].items():
                    for band in ('DAY','PRE','POST','NIGHT'):
                        V.compare(V.independent_risk(values[band]),{k:v for k,v in row['period_paths'][period][band].items()
                            if k not in ('version','notes')},name+'/'+row['id']+'/'+period+'/'+band+'/経路',counters)
                        counters['period_compact']+=1
                birth={key:sealed[prefix+key] for key in ('core','branches','technical','tier')}
                mw,fw,hi=[sealed[prefix+key] for key in ('mw','fw','hi')]
                replay=B.replay(context,birth,mw,fw,hi,True)
                actual=helper.pack(context,replay,row['policy'],sealed[prefix+'active'],increment)
                V.compare(actual,row,name+'/'+row['id']+'/全pack再生',counters);counters['fixed_full_replay']+=1
            for parent in parents:
                for gate in ('G00','G99'):
                    prefix='対照_'+parent['id']+'_'+gate+'__'
                    birth={key:sealed[prefix+key] for key in ('core','branches','technical','tier')}
                    mw,fw,hi=[sealed[prefix+key] for key in ('mw','fw','hi')]
                    value=B.replay(context,birth,mw,fw,hi,True)
                    if gate=='G00':
                        expected=refs['177'][parent['id']]
                        actual=helper.pack(context,value,expected['policy'],sealed[prefix+'active'],increment)
                        V.compare(actual,expected,name+'/'+parent['id']+'/G00全pack',counters)
                    else:
                        expected=refs['174'][parent['base']];actual=helper.A.pack(context,value,expected['policy'])
                        V.compare({key:actual[key] for key in expected},expected,name+'/'+parent['id']+'/G99全pack',counters)
                    counters['endpoint_full_pack']+=1;endpoint_checks.append({'期間':name,'parent':parent['id'],'gate':gate,'全pack一致':True})
        summaries[name]={candidate:{band:Q.brief(groups[band]) for band in ('DAY','PRE','POST','NIGHT','ALL')}
            for candidate,groups in independent.items()}
        del context
    # ----------------------------------------
    # 全80の金融・経路と三内訳を、実場IDと未知Noneを保持して再計算する。
    eligible={band:bodies['旧73']['対象場'][band]+bodies['追加7']['対象場'][band] for band in ('DAY','PRE','POST')}
    hours={band:bodies['旧73']['対象時間'][band]+bodies['追加7']['対象時間'][band] for band in ('DAY','PRE','POST')}
    assert not set(bodies['旧73']['場順'])&set(bodies['追加7']['場順'])
    V.compare(eligible,bodies['全80']['対象場'],'全80/対象場',counters);V.compare(hours,bodies['全80']['対象時間'],'全80/時間',counters)
    summaries['全80']={};branches['全80']={}
    for candidate in ids:
        old,added,row=[by_id[name][candidate] for name in ('旧73','追加7','全80')]
        joined={'ledger':{key:old['ledger'][key]+added['ledger'][key] for key in ('net','known','label','scene')},
            **{key:old[key]+added[key] for key in ('phases','origins','added')}}
        for key in joined:V.compare(joined[key],row[key],'全80/'+candidate+'/'+key,counters)
        groups=F.financial_groups(joined,eligible,hours);Q.check_groups(groups,row['financial'],row['paths'],'全80/'+candidate,counters)
        V.compare(old['financial'],row['旧73'],'全80/'+candidate+'/旧金融',counters);V.compare(added['financial'],row['追加7'],'全80/'+candidate+'/追加金融',counters)
        assert old['policy']==added['policy']==row['policy'];branches['全80'][candidate]=A.branch_counts(row)
        summaries['全80'][candidate]={band:Q.brief(groups[band]) for band in ('DAY','PRE','POST','NIGHT','ALL')}
    for period in ('前48','後25'):
        summaries[period]={candidate:{band:Q.brief(groups[period][band]) for band in ('DAY','PRE','POST','NIGHT','ALL')}
            for candidate,groups in periods['旧73'].items()}
    paired={scope:{candidate:{**row,'policy':{**row['policy'],'options':{'DAY':[],**row['policy']['options']}}}
        for candidate,row in by_id[scope].items()} for scope in ('旧73','追加7')}
    overlap={route:Q.overlap(paired['旧73'],paired['追加7'],*fixed['選択'][route]['参考候補']) for route in ('全期','前48')}
    assert before==[V.fingerprint(path) for path in files]
    result={'成功':True,'対象ID':ids,'固定SHA256':SHA,'検査':counters,'不一致':0,'Sourceと入力不変':True,
        '入力':before,'要約':summaries,'取得内訳':branches,'両端全pack':endpoint_checks,'近傍重複':overlap,
        '注意':['追加7を含め全80は既使用参考。追加7を見た主候補の交換はしない。',
            '未知Noneと0取得場を残す。既知寄与DDは金融未知のある全件DDとは区別し、保有中時価DDではない。',
            '独立部分は金融・経路・支持の再集計。出生からの全pack再生は凍結Source/共用engineを使った同体確認。']}
    (HERE/'追加七場と全80の独立結果.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps({key:result[key] for key in ('成功','対象ID','検査','不一致','Sourceと入力不変')},ensure_ascii=False))


if __name__=='__main__':main()
