"""178固定ゲートの全段経路・選択・G00/G99・Day同体を独立点検する。"""
from pathlib import Path
import importlib.util
import json
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
SOURCE=ROOT/'work/178新枝の確認比較'
TRIAL=ROOT/'study/00178_新枝の実方向と複数足の背景を確認する'


def module(path: Path, name: str) -> object:
    """
    機能: mainを起動せずSource又は独立部品を読む。
    引数: path(Path)、name(str)。
    返り値: objectは読み込んだ部品。
    """
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec)
    sys.modules[name]=value;spec.loader.exec_module(value);return value


N=module(ROOT/'work/177増分の独立検査/増分と選択を点検する.py','increment177_for178')
V=N.V;Q=N.Q


def joint_key(row: dict, route: str) -> tuple:
    """
    機能: 178のF0公開順位を対象routeだけから独立に再構成する。
    引数: row(dict)、route(str)は全期又は前48。
    返り値: tupleは昇順順位。
    """
    groups=row['periods'][route];paths=row['paths'][route];bands=('DAY','NIGHT')
    dual=all(groups[b]['decision']['status']=='適合' for b in bands)
    full=all(paths[b]['support']['zero_scene_count']==0 for b in bands);support=True
    for band in bands:
        group=groups[band];trade=group['trades'];fa=trade['IFD_FIRSTFANC']
        support &= trade['all_count']>=24 and fa['reached_count']>=12 and group['resolved_scene_count']>=6
        support &= (fa['first_f_rate_reached'] or 0)>=.7
    phase=sum(paths[b]['support']['phase_diagnostic_goal_met'] for b in ('PRE','POST'))
    unknown=max(groups[b]['trades']['unknown_count']/groups[b]['trades']['all_count'] if groups[b]['trades']['all_count'] else 1 for b in bands)
    windows=[w['negative_net_share_complete'] for b in bands for w in paths[b]['windows'].values() if w['complete_window_count']]
    burdens=[paths[b]['known_drawdown_to_known_profit'] for b in bands]
    return (-int(dual and full and support),-int(dual and full),-phase,unknown,max(windows,default=1),
        max(float('inf') if v is None else v for v in burdens),-sum(groups[b]['trades']['known_net'] for b in bands),row['id'])


def packed(value: tuple) -> dict:
    """
    機能: 取得とengine全体を保存packと同じ属性へ写す。
    引数: value(tuple)は共用数量再生の返り値。
    返り値: dictは全取得属性とengine。
    """
    return {'cases':value[0].cases.tolist(),'sides':value[0].sides.tolist(),'events':value[0].events.tolist(),
        'phases':value[0].phases.tolist(),'origins':value[1].tolist(),'widths':value[2].tolist(),
        'horizons':value[3].tolist(),'tiers':value[4].tolist(),'engine':value[5]}


def main() -> None:
    """
    機能: Rootの旧73金融GO後、全段経路・固定候補・同体対照を独立に検査する。
    引数: なし。
    返り値: None。担当workへ結果JSONだけを保存する。
    """
    M=module(SOURCE/'検証178.py','verify178_independent')
    f0=V.read(TRIAL/'条件.json');assert f0['試行']==178 and f0['GO']
    files=[TRIAL/'条件.json',SOURCE/'検証178.py',SOURCE/'純出生178.npz',SOURCE/'純出生178.json',
        SOURCE/'帯別確認.json.gz',SOURCE/'三帯接合.json.gz',SOURCE/'帯短表.json',SOURCE/'旧73の固定選択.json',
        SOURCE/'両端対照の同体.json',Path(__file__),HERE/'純ゲートの独立確認.json']
    files += [ROOT/r['path'] for r in f0['Source']];files=list(dict.fromkeys(files))
    before=[V.fingerprint(path) for path in files]
    for ref in f0['Source']:assert ref==V.fingerprint(ROOT/ref['path'])
    proof=V.read(SOURCE/'純出生178.json');assert proof['金融未入力']
    assert proof['F0SHA256']==V.fingerprint(TRIAL/'条件.json')['sha256']
    assert proof['出生SHA256']==V.fingerprint(SOURCE/'純出生178.npz')['sha256']
    counters={'scalar':0,'path_group':0,'compact_key':0,'shortlist':0,'period_guard':0,'F2_policies':0,
        'G00_G99_controls':0,'fixed_replays':0,'replayed_financial_group':0,'request_capacity_checked':0,'natural_combine':0,'pure_direction_arrays':0}
    stages={};day_by_base={};sizes={}
    for name in ('帯別確認','三帯接合'):
        rows=V.read(SOURCE/(name+'.json.gz'))['rows'];stages[name]=rows;sizes[name]=len(rows)
        sealed=V.read(TRIAL/'検査'/('F2_'+name+'.json'))
        assert sealed['成功'] and sealed['追加7未読'] and sealed['SourceSHA256']==V.fingerprint(SOURCE/'検証178.py')['sha256']
        V.compare(sealed['policies'],[r['policy'] for r in rows],name+'/F2政策列',counters);counters['F2_policies']+=1
        for row in rows:
            policy=row['policy'];assert set(policy['options'])<= {'PRE','POST'} and row['max_reserved']<=1
            if policy['base'] not in day_by_base:day_by_base[policy['base']]={p:g['DAY'] for p,g in row['periods'].items()}
            V.compare(day_by_base[policy['base']],{p:g['DAY'] for p,g in row['periods'].items()},row['id']+'/Day同体',counters)
            for period,groups in row['periods'].items():
                for band,group in groups.items():
                    saved=row['paths'][period][band]
                    V.compare(V.independent_risk(group),{k:v for k,v in saved.items() if k not in ('version','notes')},row['id']+'/'+period+'/'+band,counters)
                    full=M.P.STAGE.RISK.path_summary(group)
                    assert M.P.STAGE.compact_risk(full)==saved
                    assert M.P.STAGE.RISK.candidate_key(group,full,band)==M.P.STAGE.RISK.candidate_key(group,saved,band)
                    counters['path_group']+=1;counters['compact_key']+=1
    short=V.read(SOURCE/'帯短表.json')['選択']
    for parent in M.parents():
        route=parent['route']
        for band in ('PRE','POST'):
            subset=[r for r in stages['帯別確認'] if r['policy']['parent']==parent['id'] and band in r['policy']['options']]
            def chosen(values: list) -> list:
                """
                機能: 対象routeの短表にG00保持だけを適用する。
                引数: values(list[dict])は候補。
                返り値: list[dict]は最大8案。
                """
                selected=M.P.rank(values,route,band);control=next(r for r in values if r['policy']['gate_by_band'][band]=='G00')
                return selected if control['id'] in {r['id'] for r in selected} else selected[:7]+[control]
            actual=chosen(subset)
            assert [r['policy'] for r in actual]==short[parent['id']][band]
            guarded=[{**r,'periods':V.OnlyPeriod({route:r['periods'][route]}),'paths':V.OnlyPeriod({route:r['paths'][route]})} for r in subset]
            assert [r['id'] for r in chosen(guarded)]==[r['id'] for r in actual]
            counters['shortlist']+=1;counters['period_guard']+=1
    fixed=V.read(SOURCE/'旧73の固定選択.json');selection={}
    for route in ('全期','前48'):
        options=[r for r in stages['三帯接合'] if r['policy']['route']==route];ordered=sorted(options,key=lambda r:joint_key(r,route))
        eligible=[r for r in ordered if joint_key(r,route)[0]==-1];saved=fixed['選択'][route]
        assert len(eligible)==saved['共同適合数']==128 and saved['主案']==eligible[0]['id']
        assert saved['参考候補']==[r['id'] for r in ordered[:2]] and saved['candidates']==[r['policy'] for r in ordered[:2]]
        guarded=[{**r,'periods':V.OnlyPeriod({route:r['periods'][route]}),'paths':V.OnlyPeriod({route:r['paths'][route]})} for r in options]
        assert [r['id'] for r in sorted(guarded,key=lambda r:joint_key(r,route))]==[r['id'] for r in ordered]
        selection[route]={k:v for k,v in saved.items() if k!='candidates'};counters['period_guard']+=1
    # ----------------------------------------
    # 同じ共用時計へ独立合成を渡し、両端対照と固定候補の全金融を確認する。
    M.initialize();context=M.P.CTX
    parent177={r['id']:r for r in V.read(ROOT/'work/177追加七場適用/旧73の全取得177.json.gz')['rows']}
    parent174={r['id']:r for r in V.read(ROOT/'work/174追加七場適用/旧73の全取得174.json.gz')['rows']}
    G=module(M.BUILDER,'pure_gates178_verify');rules={r['birth_key']:r for p in M.parents() for rows in p['options'].values() for r in rows}
    catalog=V.read(M.P.CATALOG)['rules'];lookup={r['id']:i for i,r in enumerate(catalog)}
    with np.load(M.P.HERE/'純出生177.npz',allow_pickle=False) as raw:
        for key,rule in rules.items():
            direction=raw['directions'][lookup[rule['rule_id']]]*(1 if rule['orientation']=='NORMAL' else -1)
            for i in range(12):
                gate=f'G{i:02}';assert np.array_equal(G.apply(context.features,direction,gate),M.P.DIRS[gate+'|'+key])
                counters['pure_direction_arrays']+=1
    controls=[]
    for parent in M.parents():
        for gate,expected in [('G00',parent177[parent['id']]),('G99',parent174[parent['base']])]:
            options={band:M.policy(parent,band,gate)['options'][band] for band in ('PRE','POST')}
            actual=M.P.combine(M.P.BASES[parent['base']],context.event_phases,options,M.P.DIRS,list(context.table.horizons))
            N.compare_arrays(N.independent_combine(M.P.BASES[parent['base']],context.event_phases,options,M.P.DIRS,list(context.table.horizons)),actual)
            value=M.B.replay(context,*actual[:4],True,M.P.CAPS);got=packed(value)
            V.compare(got,{key:expected[key] for key in got},parent['id']+'/'+gate+'/全取得engine',counters)
            V.compare(M.B.financial(context,value),expected['financial'],parent['id']+'/'+gate+'/全金融',counters)
            controls.append({'parent':parent['id'],'gate':gate,'全金融全取得全engine同体':True})
            counters['G00_G99_controls']+=1;counters['natural_combine']+=1
    fixed_groups={};fixed_replays={};id_map={r['id']:r for r in stages['三帯接合']}
    for route,values in fixed['選択'].items():
        for policy in values['candidates']:
            base=M.P.BASES[policy['base']];actual=M.P.combine(base,context.event_phases,policy['options'],M.P.DIRS,list(context.table.horizons))
            N.compare_arrays(N.independent_combine(base,context.event_phases,policy['options'],M.P.DIRS,list(context.table.horizons)),actual)
            day=context.event_phases==0
            for key in actual[0]:assert np.array_equal(actual[0][key][day],base[key][day])
            for key,array in zip(('mw','fw','hi'),actual[1:4]):assert np.array_equal(array[day],base[key][day])
            value=M.B.replay(context,*actual[:4],True,M.P.CAPS);row=id_map[policy['id']]
            assert int(actual[-2][value[0].events].sum())==row['new_count'] and int(actual[-1].sum())==row['conflict_q0']
            fixed_groups[policy['id']]=N.replay_groups(context,value,row,counters)
            fixed_replays[policy['id']]={**packed(value),'added':actual[-2][value[0].events].tolist()}
            counters['fixed_replays']+=1;counters['natural_combine']+=1
    assert before==[V.fingerprint(path) for path in files]
    overlaps={}
    for route,values in fixed['選択'].items():
        a,b=[fixed_replays[p['id']] for p in values['candidates']]
        overlaps[route]={'取得数A':len(a['cases']),'取得数B':len(b['cases']),
            '全取得属性同体':all(a[key]==b[key] for key in ('cases','sides','events','phases','origins','widths','horizons','tiers','added')),
            '全engine同体':a['engine']==b['engine'],'期間金融同体':id_map[values['candidates'][0]['id']]['periods']==id_map[values['candidates'][1]['id']]['periods']}
    result={'成功':True,'対象':sizes,'検査':counters,'不一致':0,'Sourceと入力不変':True,'入力':before,'固定選択':selection,
        '両端対照':controls,'固定近傍重複':overlaps,'固定案要約':{candidate:{period:{band:Q.brief(groups[band]) for band in ('DAY','PRE','POST','NIGHT','ALL')}
            for period,groups in periods.items()} for candidate,periods in fixed_groups.items()},
        '注意':['追加7金融はこの検査では未読。全期発見と前48選択・後25診断を区別。',
            '独立部分は合成・金融・経路と選択照合。engineは共用Sourceであり独立実装ではない。未知を0円の全件損益へ置換しない。']}
    (HERE/'旧73金融と選択の独立結果.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps({key:result[key] for key in ('成功','対象','検査','不一致','Sourceと入力不変','固定選択','固定近傍重複')},ensure_ascii=False))


if __name__=='__main__':main()
