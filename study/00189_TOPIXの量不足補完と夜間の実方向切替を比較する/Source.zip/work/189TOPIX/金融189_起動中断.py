"""金融前に固定した168条件を同じ単純IFDで比較する。"""
from pathlib import Path
from copy import deepcopy
import gzip,json,sys
import 入口189 as E
M=E.M;HERE=Path(__file__).parent
import 金融を比較する as F
A=F.A


def main():
    """
    機能: 固定168条件を全81場再生し、損失安定性を比較する。
    引数: なし。
    返り値: None。全件正本と期間別集計を保存する。
    """
    cfg=M.read(HERE/'条件.json');assert cfg['SourceSHA']==M.sha(HERE/'入口189.py')
    assert cfg['純入口SHA']==M.sha(HERE/'純入口.json.gz')
    seal=HERE/'金融開始前固定.json';assert not seal.exists()
    M.save(seal,{'金融Source':M.sha(Path(__file__)),'条件SHA':M.sha(HERE/'条件.json'),
      'IFDSource':M.sha(M.HERE/'入口とIFD.py'),'安定性Source':M.sha(M.ROOT/'work/183損失安定性/安定性183.py'),
      '人工':M.read(HERE/'人工確認.json'),'注意':'圧力はEMA/DI/価格と相対量の代理。板フローや吸収の直接観測ではない。'})
    entries=deepcopy(M.read(M.HERE/'入力台帳.json')['entries'])
    permanent=M.read(E.ROOT/'inputs/TOPIX原順8列_20260921_20261116/台帳.json')
    mapping={x['session']:x for x in permanent['entries']}
    for e in entries:e['cache_absolute']=str(E.ROOT/mapping[e['session']]['path'])
    meta=F.sessions(entries);pure=json.loads(gzip.decompress((HERE/'純入口.json.gz').read_bytes()))
    by={k:{s['scene']:[] for s in meta} for k in range(2)}
    for k in by:
        for r in pure[str(k)]:by[k][r['session']].append(r)
    packs={}
    for form in range(2):
        for ci,name in enumerate(E.NAMES):
            for w in E.WIDTHS:
                packs[(form,ci,w)]=F.empty(f'TOPIX189_F{form}_{name}_{w}_H60',meta)
                packs[(form,ci,w)]['ledger']['origin']=[]
    for e in entries:
        route=M.Route(e);cache={}
        for (form,ci,w),pack in packs.items():
            busy=-float('inf');signals=blocked=expired=accepted=0
            for r in by[form][e['session']]:
                side=r['signals'][ci]
                if not side:continue
                signals+=1
                if r['time']<=busy:blocked+=1;continue
                fixed=E.E.width(r,w);key=(r['time'],r['line'],side,fixed)
                if key not in cache:cache[key]=route.cell(*key)
                cell=cache[key]
                if cell is None:expired+=1;continue
                accepted+=1;F.append(pack,cell);pack['ledger']['origin'].append(r['origins'][ci]);busy=route.end if cell['unknown'] else cell['exit_time']
            pack['diagnostics'].append({'scene':e['session'],'純成立':signals,'保有棄却':blocked,'取得':accepted,'失効':expired})
        print(e['session'],len(cache),flush=True)
    periods={'全80':[s['scene'] for s in meta[:-1]],'前48':[s['scene'] for s in meta[:48]],
      '後25':[s['scene'] for s in meta[48:73]],'追加7':[s['scene'] for s in meta[73:80]],'本日1':[meta[-1]['scene']]}
    stats={};short=[];rankings={}
    for key,pack in packs.items():
        stats[key]=A.evaluate_pack(pack,periods);stat=stats[key];M.save(HERE/'金融正本'/(pack['id']+'.json.gz'),pack)
        short.append({'id':pack['id'],'form':key[0],'candidate':E.NAMES[key[1]],'width':key[2],
          '全81':{k:F.terse(v) for k,v in stat['groups'].items()},
          '期間':{p:{k:F.terse(v) for k,v in block.items()} for p,block in stat['periods'].items()}})
    for form in range(2):
        for w in E.WIDTHS:
            for period in ('全80','前48'):
                for band in ('DAY','NIGHT'):
                    baseline=stats[(form,0,w)]['periods'][period][band]
                    keys=sorted((k for k in stats if k[0]==form and k[2]==w),key=lambda k:(A.rank_key(stats[k]['periods'][period][band],baseline),packs[k]['id']))
                    rankings[f'F{form}_{w}_{period}_{band}']=[{'id':packs[k]['id'],'gate':A.gate(stats[k]['periods'][period][band],baseline)} for k in keys]
    M.save(HERE/'全168組短表.json',{'rows':short,'順位':rankings});M.save(HERE/'全168組安定性.json.gz',{'metrics':list(stats.values()),'順位':rankings})
    for name,order in rankings.items():
        row=next(r for r in short if r['id']==order[0]['id'])
        if name.endswith('DAY') and '_全80_' in name:
            print(name,json.dumps({'id':row['id'],'gate':order[0]['gate'],'全81':row['全81']['DAY']},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
