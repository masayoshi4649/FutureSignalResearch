"""売買対称・同一足重複・価格受容・q0幅を金融前に確認する。"""
from pathlib import Path
from collections import deque
from copy import deepcopy
import gzip,json,sys
import 入口189 as U
E=U.E
M=E.M
import 人工検査 as T


def mirror_m(m):
    """
    機能: 足特徴の符号を鏡像へ変換する。
    引数: m(dict)。
    返り値: dictは価格原点4000の鏡像。
    """
    x=deepcopy(m)
    for key in ('close','ema8','ema21'):x[key]=8000-m[key]
    for key in ('slope','hist','hist_delta','rsi_delta','di','bbz'):x[key]=-m[key] if m[key] is not None else None
    x['rsi']=100-m['rsi'];return x


def main():
    """
    機能: 実特徴の鏡像と人工的な受容の境界を確認する。
    引数: なし。
    返り値: None。確認数と成功を保存する。
    """
    checks=0
    for file in ('純特徴183.json.gz','純特徴184直接.json.gz'):
        rows=json.loads(gzip.decompress((E.ROOT/'inputs/TOPIX原順8列_20260921_20261116'/file).read_bytes()))
        hist=deque(maxlen=3);previous=None;scene=None;ident=None
        for n,r in enumerate(rows):
            if scene!=r['session']:hist.clear();previous=None;ident=None;scene=r['session']
            now=(r['m5']['count'],r['m5']['end'],r['m5']['published'])
            if now!=ident:hist.append(r['m5']);ident=now
            if n%97==0:
                ctx={'history':list(hist),'previous':previous};mc={'history':[mirror_m(m) for m in hist],'previous':T.mirror(previous) if previous else None}
                for strict in (False,True):
                    for side in (1,-1):assert E.roles(r,side,ctx,strict)==E.roles(T.mirror(r),-side,mc,strict);checks+=12
            if n%97==0:
                plus=E.roles(r,1,ctx,False);minus=E.roles(r,-1,ctx,False)
                base=[]
                for i in range(12):
                    signal=1 if plus[i] and not minus[i] else -1 if minus[i] and not plus[i] else 0
                    base.extend([signal,signal])
                for q in range(3):
                    for policy in range(14):
                        decision=U.decide(r,ctx,base,q,policy)
                        mirror=U.decide(T.mirror(r),mc,[-v for v in base],q,policy)
                        assert decision[0]==-mirror[0] and decision[1]==mirror[1];checks+=1
            previous=r
    start,_,_=M.bounds('2026-09-21_Day');time=start+130*60
    m={'count':26,'close':4003.,'ema8':4001.,'ema21':4000.,'slope':.2,'hist':.3,'hist_delta':.1,'rsi':60.,'rsi_delta':1.,'atr':2.,'adx':20.,'di':.1,'bbz':1.,'published':time,'end':time,'tr':2.}
    r={'session':'2026-09-21_Day','time':time,'line':1,'band':'DAY','atr':2.,'m5':m,'m15':m,'m30':m,'close':4003.,'body':.2,'progress':.2,
       'position':.8,'range':1.,'live':.1,'spread':.5,'rvol':2.,'high':4004.,'low':4002.,'prior_high':4002.,'prior_low':3999.,'prior_close':4002.}
    previous=deepcopy(r);previous.update(time=time-60,close=4002.,prior_high=4001.5,prior_close=4000.)
    history=[dict(m,end=time+i*300,count=26+i) for i in (-2,-1,0)];ctx={'history':history,'previous':previous}
    assert E.roles(r,1,ctx,True)[2];checks+=1
    cut=deepcopy(r);cut['low']=4001.4
    assert E.roles(cut,1,ctx,False)[2] and not E.roles(cut,1,ctx,True)[2];checks+=2
    missing=deepcopy(ctx);missing['previous']['time']-=120
    assert not E.roles(r,1,missing,False)[2];checks+=1
    duplicated={'history':[m,m,m],'previous':previous}
    assert not E.roles(r,1,duplicated,False)[2];checks+=1
    assert E.width(r,'A15')==5 and E.width(dict(r,atr=20),'A25')==25 and E.width(dict(r,atr=3.11),'A25')==8;checks+=3
    r['rvol']=None;r['body']=-.2;r['progress']=-.2;r['close']=4001.;r['range']=.5
    assert U.supplement(r,1,ctx,'未知') and not U.supplement(r,1,ctx,'低量');checks+=2
    r['rvol']=.2
    assert not U.supplement(r,1,ctx,'未知') and U.supplement(r,1,ctx,'低量');checks+=2
    report={'成功':True,'確認数':checks,'対象':'売買対称・同じ5分足の重複拒否・受容の固定端/途中戻り/欠測・公開済みq0ATR幅'}
    M.save(U.HERE/'人工確認.json',report);print(json.dumps(report,ensure_ascii=False))


if __name__=='__main__':main()
