"""量補完の独立損益と主群の枠変化、Nightの形成差・未知を分ける。"""
from pathlib import Path
from collections import defaultdict,Counter
from datetime import datetime,timezone,timedelta
import gzip,json
import 入口189 as E
M=E.M;HERE=Path(__file__).parent;JST=timezone(timedelta(hours=9))


def read(p):
    """
    機能: JSON正本を読む。
    引数: p(Path)。
    返り値: object。
    """
    return json.loads(gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes())


def trades(identifier,band):
    """
    機能: 指定帯の取得を一意な要求・方向・幅で引く。
    引数: identifier(str),band(str)はDAY/NIGHT。
    返り値: dict[tuple,dict]は費用後損益と出生付き取得。
    """
    p=read(HERE/'金融正本'/(identifier+'.json.gz'));l=p['ledger'];rows={}
    for i,s in enumerate(l['scene']):
        if (l['phase'][i]==0)!=(band=='DAY'):continue
        key=(s,l['request_time'][i],l['request_line'][i],l['side'][i],l['width'][i])
        rows[key]={k:v[i] for k,v in l.items()}
    return rows


def total(rows):
    """
    機能: 小群の利益損失を分ける。
    引数: rows(iterable[dict])。
    返り値: dict。未知額は0扱いしない。
    """
    rr=list(rows);known=[r['net'] for r in rr if r['known']]
    return {'取得':len(rr),'未知':len(rr)-len(known),'利益':sum(max(v,0) for v in known),'損失':sum(-min(v,0) for v in known),
      '既知収支':sum(known),'場':len(set(r['scene'] for r in rr))}


def compare(a,b):
    """
    機能: 共通取得・失われた元取得・新取得を分ける。
    引数: a,b(dict[tuple,dict])。
    返り値: dictは差分。利益を取り逃したこと自体を最適化しない。
    """
    common=a.keys()&b.keys();assert all(a[k]['net']==b[k]['net'] for k in common)
    added=[b[k] for k in b.keys()-a.keys()];removed=[a[k] for k in a.keys()-b.keys()]
    return {'共通':total(a[k] for k in common),'元のみ':total(removed),'新のみ':total(added),
      '新のみ出生':{o:total(r for r in added if r['origin']==o) for o in sorted(set(r['origin'] for r in added))},
      '元合計':total(a.values()),'新合計':total(b.values())}


def main():
    """
    機能: 189後の原因を、金融結果を変更せず記録する。
    引数: なし。
    返り値: None。群別事後診断を保存する。
    """
    base=trades('TOPIX189_F1_Q0_N00_元P0_A25_H60','DAY');day={}
    for q in (1,2):
        candidate=trades(f'TOPIX189_F1_Q{q}_N00_元P0_A25_H60','DAY')
        day[f'Q{q}']=compare(base,candidate)
        day[f'Q{q}']['全取得の出生別']={o:total(r for r in candidate.values() if r['origin']==o) for o in sorted(set(r['origin'] for r in candidate.values()))}
    oldid='TOPIX189_F0_Q0_N07_米前反転米後費用比_W15_H60';newid='TOPIX189_F1_Q0_N07_米前反転米後費用比_W15_H60'
    old=trades(oldid,'NIGHT');direct=trades(newid,'NIGHT');night=compare(old,direct)
    pack=read(HERE/'金融正本'/(oldid+'.json.gz'));night['未参加']=[r for r in pack['diagnostics'] if r['scene'].endswith('Night') and r['取得']==0]
    night['未知']=[{k:r[k] for k in ('scene','phase','unknown_reason','reason','label','origin')}|
       {'要求JST':datetime.fromtimestamp(r['request_time'],JST).isoformat(),'取得JST':datetime.fromtimestamp(r['entry_time'],JST).isoformat()} for r in old.values() if not r['known']]
    # ----------------------------------------
    # q0の共通集合・公開特徴・実方向差を、金融前の保存純入口だけで照合する。
    raw=read(HERE/'純入口.json.gz');index={k:{(r['session'],r['time'],r['line']):r for r in rr if r['band']!='DAY'} for k,rr in raw.items()}
    c=index['0'].keys()&index['1'].keys();ci=7
    night['純q0差']={'旧q0':len(index['0']),'直接q0':len(index['1']),'共通q0':len(c),
       '共通で両方無成立':sum(index['0'][k]['signals'][ci]==index['1'][k]['signals'][ci]==0 for k in c),
       '共通で同方向成立':sum(index['0'][k]['signals'][ci]==index['1'][k]['signals'][ci]!=0 for k in c),
       '共通で旧のみ成立':sum(index['0'][k]['signals'][ci]!=0==index['1'][k]['signals'][ci] for k in c),
       '共通で直接のみ成立':sum(index['0'][k]['signals'][ci]==0!=index['1'][k]['signals'][ci] for k in c),
       '共通で反対方向':sum(index['0'][k]['signals'][ci]*index['1'][k]['signals'][ci]==-1 for k in c)}
    out={'事後診断':True,'Day量補完':day,'Night形成差':night,
      '注意':'既知低量は反対側圧力が弱いという仮説。量不明の代用品ではない。主群を純条件で保持しても枠配分で実取得は変わる。3未参加場や8未知を分母から除外しない。'}
    M.save(HERE/'原因診断.json',out)
    print(json.dumps({'Day量補完':day,'Night純q0':night['純q0差'],'Night未参加':night['未参加'],'Night未知':night['未知']},ensure_ascii=False))


if __name__=='__main__':main()
