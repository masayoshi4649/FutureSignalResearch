"""108の検算済み報告・原計画を正式反映し、CSVと次の問いへの参照を付ける。"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path


WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
TRIAL = ROOT / "study/00108_開始静観20分と30分の比較"
RENDERER = WORK / "報告を差し替える.py"
RENDERER_SHA = "a575686ace58a05c074437bde89a0cc4863ecfc4b56f5cc11b84ec806b42e4b6"


def sha(path: Path) -> str:
    """機能: コード・報告・小metadata・既存CSVの実指紋を得る。

    引数: path (Path) は固定参照。
    返り値: str はSHA256。金融Native本文は読まない。
    """
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main() -> None:
    """機能: 成功した金融/保存/8093/CSVを結び、正式MDを一度だけ更新する。

    引数: CLI fixed/fixed-sha は事後固定条件とそのSHA。
    返り値: None。金融、CSV生成、Viewer通信は実行しない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fixed", type=Path, required=True)
    parser.add_argument("--fixed-sha", required=True)
    args = parser.parse_args()
    fixed_path = args.fixed.resolve()
    assert sha(fixed_path) == args.fixed_sha and sha(RENDERER) == RENDERER_SHA
    spec = importlib.util.spec_from_file_location("108の検算済み報告の生成", RENDERER)
    renderer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(renderer)
    fixed = renderer.read_json(fixed_path)
    assert fixed["version"] == 1 and fixed["trial"] == 108 and fixed["fixed"] and fixed["phase"] == "正式報告"
    before = {str(fixed_path): args.fixed_sha, str(RENDERER): RENDERER_SHA}
    report_fixed = renderer.file_ref(fixed["report_fixed"], fixed_path.parent, before)
    code = renderer.file_ref(fixed["code"], fixed_path.parent, before)
    assert code == Path(__file__).resolve()
    result, report_inputs, viewer = renderer.prepare(report_fixed, fixed["report_fixed"]["sha256"])
    before.update(report_inputs)
    csv_path = renderer.file_ref(fixed["csv_check"], fixed_path.parent, before)
    csv_check = renderer.read_json(csv_path)
    report_condition = renderer.read_json(report_fixed)
    assert csv_check["成功"] and csv_check["試行"] == 108 and csv_check["入力前後不変"] and csv_check["金融再実行"] is False
    assert csv_check["入力SHA256"] == report_condition["summary"]["sha256"]
    assert set(csv_check["出力"]) == {"全セッション.csv", "候補別集計.csv"}
    assert csv_check["出力"]["全セッション.csv"]["データ行数"] == 840 and csv_check["出力"]["候補別集計.csv"]["データ行数"] == 12
    for name, item in csv_check["出力"].items():
        path = csv_path.parent / name
        assert sha(path) == item["sha256"]
        before[str(path)] = item["sha256"]
    assert viewer["確認"] and "8093" in viewer["scope"]
    outputs, plans = renderer.render(result, viewer)
    for name, expected in plans.items():
        assert sha(TRIAL / name) == expected
    assert not (TRIAL / "原計画").exists() and not (TRIAL / "検査/報告の確認.json").exists()
    links = {
        "集計CSV": "../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/108損益CSV/候補別集計.csv",
        "全セッションCSV": "../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/108損益CSV/全セッション.csv",
        "比較で得た知見": "../../docs/議論/開始静観20分と30分の比較結果.md",
        "11/06の入口と利益保護の診断": "../../docs/議論/11月06日の赤字を入口と利益保護から診断する.md",
        "次試行の5分・15分・30分の方針": "../../docs/議論/5分15分30分で入口の環境と確認を分ける.md",
    }
    assert all((TRIAL / path).resolve().is_file() for path in links.values())
    navigation = " / ".join(f"[{name}]({path})" for name, path in links.items())
    introduction = "# 開始静観20分と30分の比較\n\n" + navigation + "\n\n今後の損益表はCSV。旧30分は保存対照、新20分だけを再計算した。5分・15分・30分の入口追加は次試行の方針であり、この試行の検証結果には含めない。11/06診断は既存107の実約定に基づく別資料。\n\n"
    outputs["README.md"] = introduction.encode("utf-8") + outputs["README.md"]
    outputs["設定と結果.md"] = (navigation + "\n\n").encode("utf-8") + outputs["設定と結果.md"]
    for name, body in outputs.items():
        path = TRIAL / name
        path.parent.mkdir(parents=True, exist_ok=True)
        if name in plans:
            path.write_bytes(body)
        else:
            with path.open("xb") as stream:
                stream.write(body)
    after = {name: sha(Path(name)) for name in before}
    assert before == after
    assert all((TRIAL / ("原計画/" + name)).read_bytes() == (WORK / "原文" / name).read_bytes() for name in plans)
    proof = {"成功": True, "試行": 108, "scope": "新20分全70保存と旧30保存対照・専用8093のAPI限定証拠・CSVへのリンクを正式反映。5/15/30入口は次試行の未検証方針", "固定SHA256": args.fixed_sha, "原計画SHA256": plans, "55x9/S13K12/R12保持": True, "出力SHA256": {name: sha(TRIAL / name) for name in outputs}, "入力SHA256前": before, "入力SHA256後": after, "前後不変": True, "金融/CSV/HTTP再実行": 0}
    destination = TRIAL / "検査/報告の確認.json"
    with destination.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(proof, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"成功": True, "出力": proof["出力SHA256"], "報告確認SHA256": sha(destination)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
