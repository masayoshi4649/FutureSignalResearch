"""108の新20分12設定と旧30分保存対照を分け、原計画を保持して報告する。"""
from __future__ import annotations

import argparse
from decimal import Decimal
import hashlib
import importlib.util
import json
from pathlib import Path
import re

WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[1]
PREVIOUS=ROOT/'work/107報告の準備/報告を差し替える.py'
PREVIOUS_SHA='0e1f01baa6ac06486daaa7cb63906dca2ae3a86f232c1dab0a64b9cc174e751e'
SAVED_PATH=ROOT/'work/108静観短縮の保存準備/集計.py'
SAVED_SHA='291d42dc23b492495fe441e1d72d0673ee3c87766056b117246c396c083d98d5'
CONDITION_SHA='0a2a70a4658800060ab4c22a29cdcf21e29a9e2d87f916b0d1c327bb8cf88bd6'
ORIGINAL_SHA={'README.md':'5fb47ff47207c711ac25000205d5a680444458089e7c96160cbd1f670e0319c4','設定と結果.md':'f2851922bf2021cef0689a44550d633364062ac4eac222c18a4d571d1e76851e'}


def sha(path: Path) -> str:
    """
    機能: コード/原文/小集計の内容指紋を得る。
    引数: path (Path) は許可された対象。
    返り値: str はSHA256。Native/Record/Rawには呼ばない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


assert sha(PREVIOUS)==PREVIOUS_SHA and sha(SAVED_PATH)==SAVED_SHA
spec=importlib.util.spec_from_file_location('108が再用する停止107報告',PREVIOUS)
OLD=importlib.util.module_from_spec(spec);spec.loader.exec_module(OLD)
spec=importlib.util.spec_from_file_location('108報告の停止保存',SAVED_PATH)
SAVED=importlib.util.module_from_spec(spec);spec.loader.exec_module(SAVED)
read_json,file_ref,amount,rate,table,finite=OLD.read_json,OLD.file_ref,OLD.amount,OLD.rate,OLD.table,OLD.finite
FIELDS,COMPS,CLOCK_FIELDS=OLD.FIELDS,OLD.COMPS,OLD.CLOCK_FIELDS
KEYS=list(SAVED.KEYS)
GROUPS=OLD.GROUPS
ACTIVITY=('活動主表','活動副表','活動共通30主表','活動共通30副表')
BEGIN,END='<!-- REPORT108:RESULT:BEGIN -->','<!-- REPORT108:RESULT:END -->'


def pairs() -> dict[str,tuple[str,str,str,str,str]]:
    """
    機能: 静観長12と新20分内保護12を別の比較名で定義する。
    引数: なし。
    返り値: dictは比較名から前後phase/key/区分への対応。手法や閾値は増やさない。
    """
    out={'20分_'+k+'対30分_'+k:('30',k,'20',k,'静観長') for k in KEYS}
    for a,b in [('Q0','Q1'),('Q0','QE'),('Q1','QE')]:
        for c in (0,5):
            for d in (0,1):
                before,after=f'{a}_C{c}_D{d}',f'{b}_C{c}_D{d}'
                out['20分_'+after+'対20分_'+before]=('20',before,'20',after,'20分内保護')
    return out


def activity(t: dict, label: str, denom: int, *, scene: bool=False) -> None:
    """
    機能: 参加の分子/分母/和と集約率を検査する。
    引数: t (dict)、label (str)、denom (int)、scene (bool) は保存行・欄・予定母数・場別指定。
    返り値: None。場別counts-onlyへ率を要求せず、集約率欠落を補完しない。
    """
    a=t[label]
    assert a['denom']==denom and a['new']+a['hold']==a['active'] and a['active']+a['wait']+a['unknown']==denom
    assert all(type(a[k]) is int and a[k]>=0 for k in ('new','hold','active','wait','unknown','denom'))
    if not scene:
        assert abs(finite(a['参加率'])-Decimal(a['active'])/denom)<Decimal('1e-12')


def validate_row(t: dict, main: int, sub: int, *, scene: bool=False, common: tuple[int,int]|None=None) -> None:
    """
    機能: 固定107の基本算術/二旗/時計を再用し、追加の共通30観測を検査する。
    引数: t (dict)、main/sub (int)、scene (bool)、common (tuple[int,int]|None) は保存値と母数。
    返り値: None。共通観測を旧30再金融へ読み替えない。
    """
    OLD.OLD.validate_row(t,main,sub,scene=scene)
    OLD.validate_clock(t,'Q')
    if common:
        activity(t,'活動共通30主表',common[0],scene=scene)
        activity(t,'活動共通30副表',common[1],scene=scene)


def validate_part(part: dict, sessions: list[str], *, new: bool) -> None:
    """
    機能: 新旧それぞれ12集約/840場別・日夜/日別/履歴を別分母で検査する。
    引数: part (dict)、sessions (list[str])、new (bool) は保存部分・70場・20分指定。
    返り値: None。20分と30分を同じ集計へ合算しない。
    """
    assert set(part['集計'])==set(KEYS) and set(part['実現診断'])==set(KEYS)
    rows={(x['session'],x['key']):x for x in part['場別']}
    assert len(rows)==len(part['場別'])==840 and set(rows)=={(s,k) for s in sessions for k in KEYS}
    main,sub=(7980,7700) if new else (7840,7560)
    for k in KEYS:
        t=part['集計'][k]
        validate_row(t,main,sub,common=(7840,7560) if new else None)
        for s in sessions:
            day=s.endswith('_Day');m=(78 if day else 150) if new else (76 if day else 148);b=(74 if day else 146) if new else (72 if day else 144)
            row=rows[s,k]
            validate_row(row,m,b,scene=True,common=(76 if day else 148,72 if day else 144) if new else None)
            assert row['entry_timing']=='B5QD' and row['width_policy']==SAVED.BY_KEY[k]['protection_policy'] and row['history_class'] in GROUPS
        for field in FIELDS:
            assert sum(rows[s,k][field] for s in sessions)==t[field]
        for field in CLOCK_FIELDS:
            assert sum(rows[s,k]['時計割当'][field] for s in sessions)==t['時計割当'][field]
        for label in ACTIVITY if new else ACTIVITY[:2]:
            assert all(sum(rows[s,k][label][f] for s in sessions)==t[label][f] for f in ('new','hold','active','wait','unknown','denom'))
        diag=part['実現診断'][k]
        for kind in ('Day','Night'):
            selected=[rows[s,k] for s in sessions if s.endswith('_'+kind)]
            x=diag['日夜'][kind]
            validate_row(x,sum(r['活動主表']['denom'] for r in selected),sum(r['活動副表']['denom'] for r in selected),common=(sum(r['活動共通30主表']['denom'] for r in selected),sum(r['活動共通30副表']['denom'] for r in selected)) if new else None)
        assert sum(x['net_yen'] for x in diag['日夜'].values())==t['net_yen']
        assert len(diag['日別'])==35 and {x['開始日'] for x in diag['日別']}=={s[:10] for s in sessions} and sum(x['net_yen'] for x in diag['日別'])==t['net_yen']
        assert set(diag['履歴区分'])==set(GROUPS)
        for group,(_,count,_) in GROUPS.items():
            selected=[rows[s,k] for s in sessions if rows[s,k]['history_class']==group]
            assert len(selected)==count and sum(x['net_yen'] for x in selected)==diag['履歴区分'][group]['net_yen']
        if not k.startswith('QE_'):assert t['early_warning_activations']==0
        if k.startswith('Q0_'):assert t['narrowed_positions']==0


def validate_result(r: dict, sessions: list[str], contracts: list[str]) -> None:
    """
    機能: 全70新840/旧保存840と24実額比較・保存参照・一公表診断を結ぶ。
    引数: r (dict)、sessions/contracts (list[str]) は固定小集計とmetadata。
    返り値: None。Native/Recordや金融を再実行しない。
    """
    assert r['試行']==108 and r['成功'] is True and r['stage']=='full70' and (r['場数'],r['会計数'],r['旧30保存検算会計数'])==(70,840,840)
    assert len(sessions)==len(set(sessions))==70 and len({s[:10] for s in sessions})==35
    assert r['前後不変'] is True and r['入力codeSHA256前']==r['入力codeSHA256後']
    validate_part(r,sessions,new=True)
    old=r['30分保存対照'];assert old['再金融'] is False
    validate_part(old,sessions,new=False)
    assert (r['比較数'],r['静観長比較'],r['20分内保護比較'])==(24,12,12) and set(r['同実入口と実現額差'])==set(pairs())
    parts={'20':r,'30':old}
    for name,(a,k1,b,k2,kind) in pairs().items():
        c=r['同実入口と実現額差'][name];t=c['合計']
        assert c['区分']==kind and len(c['場別'])==70 and {x['session'] for x in c['場別']}==set(sessions)
        assert t['全差額']==parts[b]['集計'][k2]['net_yen']-parts[a]['集計'][k1]['net_yen']==t['同実入口差額']+t['取得変更差額']-t['前のみ実現額']+t['後のみ実現額']
        assert all(sum(x[f] for x in c['場別'])==t[f] for f in COMPS)
    refs=r['旧107Q30保存参照'];assert len(refs)==70 and {x['session'] for x in refs}==set(sessions)
    for x in refs:
        assert x['静観秒']==1800 and x['保存検算会計']==12 and x['全JSON_SHA結合'] is True and x['旧30の再金融'] is False and x['新20との同体照合'] is False
    public=r['一公表単位の役割診断'];assert len(public)==70 and {x['session'] for x in public}==set(sessions)
    by={x['session']:x for x in public}
    for i,s in enumerate(sessions):
        x=by[s];assert x['numeric_seed_carried'] is (i>0 and contracts[i]==contracts[i-1]) and 0<=x['C_pass']<=x['C_known']<=x['new_three']
        for side in ('buy','sell'):assert all(0<=x[side][p+'_pass']<=x[side][p+'_known']<=x['new_three'] for p in ('M','P'))


def prepare(path: Path, expected: str) -> tuple[dict,dict,dict]:
    """
    機能: Root全成功後の5FileRefだけから小集計を開封する。
    引数: path (Path)、expected (str) は事後固定JSONとSHA。
    返り値: tupleは新旧保存集計/前指紋/Viewer範囲。未固定は結果本文より先に拒否する。
    """
    assert sha(path)==expected
    f=read_json(path);assert f['version']==1 and f['trial']==108 and f['fixed'] is True and f['result_ready'] is True
    before={str(path.resolve()):expected,str(PREVIOUS):PREVIOUS_SHA,str(SAVED_PATH):SAVED_SHA,str(Path(__file__).resolve()):sha(Path(__file__))}
    files={k:file_ref(f[k],path.resolve().parent,before) for k in ('summary','saved_check','financial_completion','condition','prior_completion')}
    r,check,done,c,prior=[read_json(files[k]) for k in ('summary','saved_check','financial_completion','condition','prior_completion')]
    assert sha(files['condition'])==CONDITION_SHA and c['trial']==108 and c['fixed'] is True and c['configs']==SAVED.CONFIGS
    assert r['codeSHA256']==check['codeSHA256']==SAVED_SHA and r['conditionSHA256']==check['conditionSHA256']==done['condition_sha256']==CONDITION_SHA
    assert r['completionSHA256']==check['completionSHA256']==sha(files['financial_completion'])
    assert check['成功'] is True and (check['会計'],check['旧保存検算'],check['資源'],check['不一致数'])==(840,840,840,0) and check['前後不変'] is True and check['入力codeSHA256前']==check['入力codeSHA256後'] and check['出力SHA256']['結果.json']==sha(files['summary'])
    manifest=read_json(file_ref(c['source_manifest'],files['condition'].parent,before))
    sessions=[x['id'] for x in manifest['sessions']]
    SAVED.validate_completion(c,done,manifest,'full70',CONDITION_SHA)
    assert file_ref(c['prior_completion'],files['condition'].parent,before)==files['prior_completion'] and sha(files['prior_completion'])=='80faf888eda44badca7cdc0f5fb70aa7354b3dcc4c771411df18fe10409d3c01'
    assert prior['trial']==107 and prior['success'] is True and prior['stage']=='full70' and prior['sessions']==70 and prior['books']==1680 and prior['unchanged'] is True and prior['before']==prior['after']
    closed=read_json(file_ref(c['prior_closure'],files['condition'].parent,before));assert closed['試行']==107 and closed['試行完了'] is True
    assert [x['session'] for x in prior['results']]==sessions and c['source_scope']=='recorded_public_106'
    assert c['source_manifest']['sha256']=='902c6b5147763de172c0199f79b13cdc08f9a5636b05e0575f19bffd2da627e8' and c['source_corpus']['sha256']=='ca6206d47d36772fff84d230073bd4346b1e785d5b0bb98c565bafe6c92fb441' and c['source_completion']['sha256']=='c1370aac63c1905f132237becd5d5bb37c6bd06e20b061800c9d0caa02a1769f'
    assert r['Native参照']==[{k:x[k] for k in ('session','native','sidecar_header','sidecar_records','prior_native')} for x in done['results']]
    validate_result(r,sessions,[x['contract'] for x in manifest['sessions']])
    viewer={'scope':'実Viewer未確認。保存形式と実HTTPは別証拠','確認':False}
    if 'viewer_evidence' in f:
        p=file_ref(f['viewer_evidence'],path.parent,before);v=read_json(p);assert v['成功'] is True and v['scope'].strip()
        viewer={'scope':v['scope'],'確認':True,'SHA256':sha(p)}
    assert all(sha(Path(p))==h for p,h in before.items())
    return r,before,viewer


def main_summary(r: dict|None) -> str:
    """
    機能: 新20分の黒字/参加未達を市場実績受領後だけ数える。
    引数: r (dict|None) は検査済み小集計又は未検証。
    返り値: str は採用を断定しない主文。
    """
    if r is None:return '新20分の純額・最低25%・目標50%・旧30との差は未検証/null。'
    positive=sum(r['集計'][k]['net_yen']>0 for k in KEYS)
    below=[k for k in KEYS if 4*r['集計'][k]['活動主表']['active']<7980]
    target=sum(2*r['集計'][k]['活動主表']['active']<7980 for k in KEYS)
    night=sum(4*r['実現診断'][k]['日夜']['Night']['活動主表']['active']<5250 for k in KEYS)
    return f'新20分12設定の純額黒字{positive}/12、全体最低25%未達{len(below)}/12（'+('、'.join(below) if below else 'なし')+f'）、目標50%未達{target}/12、夜間単独25%未達{night}/12。旧30は保存対照で再金融0。黒字・参加・未見安定性・採用を分ける。'


def result_block(r: dict|None, viewer: dict) -> str:
    """
    機能: 新旧を別表にし、主副/共通参加・二旗・時計・24比較を表示する。
    引数: r (dict|None)、viewer (dict) は小集計又は未検証と閲覧範囲。
    返り値: str はREPORT108結果欄。仮想損益や指標単独の因果を作らない。
    """
    get=lambda k,f:None if r is None else r['集計'][k][f]
    lines=[BEGIN,'## 108の結果欄','','**未検証/null。市場結果は未取込。**' if r is None else '新20分70場840会計と旧30分保存840会計の検算を別に結合した。旧30を108で再金融したとは扱わない。','',main_summary(r),'',
           '### 新20分12設定','',table(['評価/外Key','粗額円','fee円','追加slip円','純額円','全正額円','全負額円','PF','保存点DD円','玉/枚'],[[f'R{i+1:02d} {k}']+[amount(get(k,f)) for f in ('gross_yen','fee_yen','slip_yen','net_yen','positive_yen','negative_yen')]+['未検証' if r is None else '未定義（負額0）' if r['集計'][k]['PF'] is None else f'{finite(r["集計"][k]["PF"]):.4f}',amount(get(k,'保存点連結時価DD')),f'{amount(get(k,"positions"))}/{amount(get(k,"entry_quantity"))}'] for i,k in enumerate(KEYS)]),'',
           '### 旧30分の保存対照（新成績へ合算しない）','',table(['Key','旧30純額円','新20−旧30円','旧30全負額円','旧30DD円','旧30玉/枚','旧30主率/7840'],[[k,amount(None if r is None else r['30分保存対照']['集計'][k]['net_yen']),amount(None if r is None else r['同実入口と実現額差']['20分_'+k+'対30分_'+k]['合計']['全差額']),amount(None if r is None else r['30分保存対照']['集計'][k]['negative_yen']),amount(None if r is None else r['30分保存対照']['集計'][k]['保存点連結時価DD']), '未検証' if r is None else f'{amount(r["30分保存対照"]["集計"][k]["positions"])}/{amount(r["30分保存対照"]["集計"][k]["entry_quantity"])}',rate(None if r is None else r['30分保存対照']['集計'][k]['活動主表']['active'],7840)] for k in KEYS]),'',
           '### 新20分の二旗・通常/早期/狭幅','',table(['Key','u正益玉','u後赤字玉/円','u未観測赤字円','起動玉','起動後赤字玉/円','通常/早期','狭幅'],[[k,amount(get(k,'unit_positive_positions')),f'{amount(get(k,"unit_positive_closed_negative"))}/{amount(get(k,"unit_positive_closed_negative_yen"))}',amount(get(k,'unit_unobserved_closed_negative_yen')),amount(get(k,'protection_activated_positions')),f'{amount(get(k,"activated_closed_negative"))}/{amount(get(k,"activated_closed_negative_yen"))}',f'{amount(get(k,"normal_ld10_activations"))}/{amount(get(k,"early_warning_activations"))}',amount(get(k,'narrowed_positions'))] for k in KEYS]),'',
           'u>0・LD10/E1起動・狭幅は別旗。名目建値床でも実Fillの費用後赤字0を保証しない。','',
           '### 日夜・20分主副・共通30観測','']
    rows=[]
    for k in KEYS:
        t=None if r is None else r['集計'][k]
        day,night=[None if r is None else r['実現診断'][k]['日夜'][x] for x in ('Day','Night')]
        rows.append([k,amount(None if day is None else day['net_yen']),rate(None if day is None else day['活動主表']['active'],2730),amount(None if night is None else night['net_yen']),rate(None if night is None else night['活動主表']['active'],5250)]+[rate(None if t is None else t[label]['active'],n) for label,n in zip(ACTIVITY,(7980,7700,7840,7560))])
    lines += [table(['Key','日中純額円','日中率/2730','夜間純額円','夜間率/5250','主率/7980','副率/7700','新20の共通30主/7840','新20の共通30副/7560'],rows),'',
              '共通30観測は新20の実経路を30分以降の窓で数えた値で、30分で再運転した成績ではない。US静観・未知・欠測を分母から落とさず、同枠実Fill又は当時実保有の和集合を数える。受理/保留を参加へ戻さない。','',
              '### 出生時計（新20と旧30を別計数）','']
    for phase in ('20','30'):
        part=None if r is None else r if phase=='20' else r['30分保存対照']
        lines += ['#### '+phase+'分','',table(['Key']+CLOCK_FIELDS,[[k]+[amount(None if part is None else part['集計'][k]['時計割当'][f]) for f in CLOCK_FIELDS] for k in KEYS]),'']
    lines += ['静観繰越は一度の割当変更であり、受理/実取得とは別。正数量受理後は0取得取消でも同出生を再要求しない。割当前保留枠延べは活動へ加算しない。','',
              '### 履歴区分と日別','',table(['Key']+[x[0]+'新20純額円' for x in GROUPS.values()],[[k]+[amount(None if r is None else r['実現診断'][k]['履歴区分'][g]['net_yen']) for g in GROUPS] for k in KEYS]),'',
              '70場・35開始日は全て既使用探索。12費用政策や新旧を独立市場例へ増やさない。日別35の合計を全体へ照合し、各日の詳細は保存正本を参照する。','',
              '### 一公表単位のC/M/Pとcold/carry','']
    public=None if r is None else r['一公表単位の役割診断']
    n=None if public is None else sum(x['new_three'] for x in public)
    roles=[]
    for side,p in [('', 'C'),('buy','M'),('buy','P'),('sell','M'),('sell','P')]:
        known=None if public is None else sum(x[side][p+'_known'] if side else x['C_known'] for x in public)
        passed=None if public is None else sum(x[side][p+'_pass'] if side else x['C_pass'] for x in public)
        roles.append([side+'/'+p if side else p,amount(n),amount(known),rate(known,n),amount(passed)])
    lines += [table(['役割','新3分公表母数','既知','率','成立'],roles),'',('cold/carry未検証。' if public is None else f'carry {sum(x["numeric_seed_carried"] for x in public)}場。')+' Source/Bank形成0、保存公表からCMP再評価。公表を12費用冊分に重複加算せず、Pは追加選別未使用。','',
              '### 静観長12比較と20分内保護12比較','']
    for kind in ('静観長','20分内保護'):
        lines += ['#### '+kind,'',table(['比較']+COMPS,[[name]+[amount(None if r is None else r['同実入口と実現額差'][name]['合計'][f]) for f in COMPS] for name,(_,_,_,_,group) in pairs().items() if group==kind]),'']
    lines += ['全差額＝同実入口差額＋取得変更差額−前のみ実現額＋後のみ実現額。Source全文と要求/実取得属性で対応し、数量一致だけを同入口としない。片側実額は仮想利益ではない。C5/D1は動的別運転で、差をC/M単独へ帰属しない。','',
              '旧107Q30は12Book/幅12/早期4の全JSON SHAと正式Native参照へ結合する保存対照で、新20との同体flagを設けない。全quote別engine金融照合ではない。','',
              'Viewer確認：'+viewer['scope']+'。機会損失・退出後価格・MFE・未参加仮想約定・元手未指定ROIは算出しない。採用・研究目標・未見安定性は未証明。',END,'']
    return '\n'.join(lines)


def render(r: dict|None, viewer: dict) -> tuple[dict[str,bytes],dict]:
    """
    機能: 108原文bytesを保持し全55×9/S13K12と新R12の結果欄だけを差し替える。
    引数: r (dict|None)、viewer (dict) は小集計又は未検証と閲覧範囲。
    返り値: tupleは文書bytesと原計画SHA。正式文書を直接編集しない。
    """
    original={n:(WORK/'原文'/n).read_bytes() for n in ORIGINAL_SHA}
    assert all(hashlib.sha256(b).hexdigest()==ORIGINAL_SHA[n] for n,b in original.items())
    readme,settings=[original[n].decode('utf-8-sig') for n in ('README.md','設定と結果.md')]
    before=settings
    if r:
        lines=settings.splitlines();names=[x.strip() for x in next(x for x in lines if x.startswith('| 評価ID |')).split('|')[1:-1]]
        for i,k in enumerate(KEYS):
            hits=[j for j,x in enumerate(lines) if x.startswith(f'| R{i+1:02d} |')];assert len(hits)==1
            p=lines[hits[0]].split('|');t=r['集計'][k]
            for name,value in [('純額',amount(t['net_yen'])+'円'),('主参加率',rate(t['活動主表']['active'],7980)),('副参加率',rate(t['活動副表']['active'],7700)),('状態','新20 full70金融/保存確認済み')]:p[names.index(name)+1]=' '+value+' '
            lines[hits[0]]='|'.join(p)
        settings='\n'.join(lines)+'\n'
    catalog=lambda text:[x for x in text.splitlines() if re.match(r'^\| (?:I|C|P|V|B|X|M|E)\d{2} \|',x)]
    assert catalog(before)==catalog(settings) and len(catalog(settings))==55 and all(len(x.split('|'))-2==11 for x in catalog(settings))
    for letter,count in [('S',13),('K',12),('R',12)]:
        a=[x for x in before.splitlines() if re.match(r'^\| '+letter+r'\d{2} \|',x)];b=[x for x in settings.splitlines() if re.match(r'^\| '+letter+r'\d{2} \|',x)]
        assert len(a)==len(b)==count
        if letter!='R':assert a==b
    prefix='<!-- REPORT108:STATUS:BEGIN -->\n**'+('未検証/nullの報告準備。' if r is None else '新20分全70の保存報告。旧30は保存対照。採用/目標達成とは別。')+'**\n原計画同bytesを原計画/へ保存し、旧予定は保存時点の記録として保持する。\n<!-- REPORT108:STATUS:END -->\n\n'
    block=result_block(r,viewer)
    out={'README.md':(prefix+block+'\n<details>\n<summary>保存時の原計画</summary>\n\n'+readme+'\n</details>\n').encode('utf-8'),'設定と結果.md':(prefix+settings+'\n'+block).encode('utf-8')}
    out.update({'原計画/'+n:b for n,b in original.items()})
    return out,ORIGINAL_SHA


def main() -> None:
    """
    機能: 未検証草案又はRoot成功固定の報告を新work先へ生成/checkする。
    引数: CLI out/fixed/fixed-sha/checkは新規先・事後固定・SHA・確認指定。
    返り値: None。金融/Source/Raw/API/xlsx/正式文書は実行・変更しない。
    """
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',type=Path,required=True);parser.add_argument('--fixed',type=Path);parser.add_argument('--fixed-sha');parser.add_argument('--check',action='store_true')
    a=parser.parse_args();assert (a.fixed is None)==(a.fixed_sha is None)
    r,inputs,viewer=prepare(a.fixed,a.fixed_sha) if a.fixed else (None,{}, {'scope':'実Viewer未確認'})
    out,plans=render(r,viewer)
    projection={'試行':108,'状態':'未検証/null' if r is None else '新20/旧30保存対照の報告','実績未取込':r is None,'計画':{'場数':70,'開始日':35,'新会計':840,'旧保存検算':840,'主分母':7980,'副分母':7700,'共通30主':7840,'共通30副':7560},
                '新20':{k:{f:None if r is None else r['集計'][k][f] for f in FIELDS+['時計割当']+list(ACTIVITY)} for k in KEYS},
                '旧30保存対照':{k:{f:None if r is None else r['30分保存対照']['集計'][k][f] for f in FIELDS+['時計割当','活動主表','活動副表']} for k in KEYS},
                '比較24':{name:None if r is None else r['同実入口と実現額差'][name]['合計'] for name in pairs()},'旧30再金融':False,'機会損失/退出後仮想利益':'未算出'}
    out['結果欄の値.json']=(json.dumps(projection,ensure_ascii=False,indent=2,default=str)+'\n').encode('utf-8')
    if a.check:assert a.out.is_dir() and all((a.out/n).read_bytes()==b for n,b in out.items())
    else:
        a.out.mkdir(parents=True,exist_ok=False)
        for n,b in out.items():
            p=a.out/n;p.parent.mkdir(parents=True,exist_ok=True)
            with p.open('xb') as f:f.write(b)
    assert all(sha(Path(p))==h for p,h in inputs.items())
    print(json.dumps({'成功':True,'scope':'未検証草案' if r is None else '新20全70/旧30保存対照','check':a.check,'codeSHA256':sha(Path(__file__)),'入力SHA256':inputs,'原計画SHA256':plans,'55x9/S13K12/R12保持':True,'金融/Native/Record/Raw/API/xlsx/正式編集':0},ensure_ascii=False))


if __name__=='__main__':main()
