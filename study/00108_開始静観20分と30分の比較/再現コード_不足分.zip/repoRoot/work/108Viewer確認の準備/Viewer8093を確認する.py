"""固定108の検査関数を再用し、独立した8093だけへ一覧と代表12GETを送る。"""

from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal
import hashlib
import importlib.util
import json
from pathlib import Path
import tomllib
from urllib.parse import urlencode
from urllib.request import Request, urlopen


ROOT = Path(__file__).resolve().parents[2]
ORIGINAL = ROOT / "work/108Viewer確認の準備/Viewerを確認する.py"
ORIGINAL_SHA = "94c01ad7a413fc54364c20bac8d51b7dbb6660d4aa2bc1db0b3fb8bfa1264b71"
BASE = "http://127.0.0.1:8093"


def sha(path: Path) -> str:
    """機能: 小metadata・コード・選択原板の指紋を得る。

    引数: path (Path) は明示した参照。
    返り値: str はSHA256。原板を展開・解析・複製しない。
    """
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def request(route: str, payload: dict | None = None) -> tuple[dict, str]:
    """機能: 独立8093のinfo・一覧読込・dataだけを呼ぶ。

    引数: route (str)、payload (dict|None) は許可したAPIと一覧path。
    返り値: tuple[dict,str] はDecimal保持の応答と本文SHA。
    """
    assert route == "/api/info" or route == "/api/catalogs/load" or route.startswith("/api/data?")
    assert (payload is not None) == (route == "/api/catalogs/load")
    raw = None if payload is None else json.dumps(payload).encode("utf-8")
    query = Request(BASE + route, data=raw, headers={"Content-Type": "application/json"})
    with urlopen(query, timeout=60) as response:
        body = response.read()
        digest = hashlib.sha256(body).hexdigest()
        expected = response.headers.get("x-chart-data-sha256")
        assert expected is None or expected == digest
        return json.loads(body, parse_float=Decimal), digest


def run(fixed_path: Path, expected: str, destination: Path) -> dict:
    """機能: 新規8093の固定参照と全840一覧・代表12のAPI会計を確認する。

    引数: fixed_path/destination (Path)、expected (str) はRoot固定と新規証拠先。
    返り値: dict はAPI限定の確認結果。旧8092操作・金融再実行はしない。
    """
    assert not destination.exists() and sha(fixed_path) == expected and sha(ORIGINAL) == ORIGINAL_SHA
    spec = importlib.util.spec_from_file_location("108が保存した検査の純関数", ORIGINAL)
    original = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(original)
    fixed = original.load(fixed_path)
    assert fixed["version"] == 1 and fixed["trial"] == 108 and fixed["fixed"] is True and fixed["stage"] == "full70"
    assert fixed["base"] == BASE and fixed["selected_session"] == original.SESSION
    before = {str(fixed_path): expected}
    files = {key: original.ref(fixed[key], fixed_path.parent, before, key in ("original_fixed", "server_launch"))[0] for key in ("original_fixed", "original_code", "wrapper", "server_launch", "server_config", "server_binary")}
    assert files["original_code"] == ORIGINAL and fixed["original_code"]["sha256"] == ORIGINAL_SHA
    assert files["wrapper"] == Path(__file__).resolve()
    launch = original.load(files["server_launch"])
    assert launch["新規専用起動"] and launch["PID"] == 9096 and launch["port"] == 8093 and launch["元8092の停止再起動設定変更"] == 0
    assert launch["exe"] == fixed["server_binary"]["sha256"] and launch["config"] == fixed["server_config"]["sha256"]
    config = tomllib.loads(files["server_config"].read_text(encoding="utf-8"))
    assert config["server"]["listen"] == "127.0.0.1:8093" and Path(config["paths"]["resource_root"]).resolve() == ROOT
    assert Path(config["paths"]["data_root"]).resolve() == (ROOT.parent / "JP_OSE_Data/future").resolve()
    plan = original.prepare(files["original_fixed"], fixed["original_fixed"]["sha256"], destination)
    for name, value in plan["before"].items():
        assert name not in before or before[name] == value
        before[name] = value
    baseline = original.load(files["original_fixed"])
    assert baseline["code"]["sha256"] == ORIGINAL_SHA
    condition = original.load(Path(baseline["condition"]["path"]))
    manifest_path, manifest = original.ref(condition["source_manifest"], Path(baseline["condition"]["path"]).parent, before)
    scene = next(row for row in manifest["sessions"] if row["id"] == original.SESSION)
    market_ref = scene["files"]["NK225_book"]
    market = (Path(manifest["source_root"]) / market_ref["path"]).resolve()
    assert all(Path(resource["market_path"]).resolve() == market for resource, _ in plan["selected"])
    assert sha(market) == market_ref["sha256"]
    before[str(market)] = market_ref["sha256"]
    # ----------------------------------------
    # 元のrunやOLD.BASEは呼出・変更せず、独立8093だけへ同じ検査を配送する。
    original_base = original.OLD.BASE
    assert original_base == "http://127.0.0.1:8092"
    info, info_sha = request("/api/info")
    assert Path(info["resource_root"]).resolve() == ROOT and Path(info["data_root"]).resolve() == market.parents[2]
    loaded, catalog_sha = request("/api/catalogs/load", {"path": plan["catalog"].relative_to(ROOT).as_posix()})
    assert len(loaded["resources"]) == 840 and {row["id"] for row in loaded["resources"]} == {row["id"] for row in plan["resources"]}

    def check(item: tuple) -> dict:
        """機能: 固定一資源の実純額・約定行数・最終残0を元検査で確認する。

        引数: item (tuple) は事前選択した資源と保存純額。
        返り値: dict は実応答の限定証拠。
        """
        resource, net = item
        identity = resource["id"]
        trades = plan["catalog"].parent / resource["pnl_path"]
        original_bytes = trades.read_bytes()
        query = urlencode({"catalog": loaded["catalog_id"], "resource": identity, "width": 1, "interval": "raw", "price": "last"})
        value, body_sha = request("/api/data?" + query)
        original.verify_response(value, identity, net, len(original_bytes.splitlines()))
        assert trades.read_bytes() == original_bytes
        return {"id": identity, "実約定行": len(value["events"]), "純額": net, "本文SHA256": body_sha}

    with ThreadPoolExecutor(max_workers=4) as pool:
        details = list(pool.map(check, plan["selected"]))
    after = {name: sha(Path(name)) for name in before}
    assert before == after and original.OLD.BASE == original_base and sha(ORIGINAL) == ORIGINAL_SHA
    proof = {"成功": True, "試行": 108, "scope": "新規専用Viewer8093の全840一覧の整合と事前固定2026-09-21_Dayの12設定GET。旧8092操作0。全840表示・12描画・ブラウザ視認ではない", "一覧": 840, "実GET": 12, "選択場": original.SESSION, "選択": list(original.KEYS), "details": details, "Root固定SHA256": expected, "元検査固定SHA256": fixed["original_fixed"]["sha256"], "server": {"base": BASE, "PID": 9096, "起動": fixed["server_launch"], "config": fixed["server_config"], "binary": fixed["server_binary"]}, "info本文SHA256": info_sha, "catalog load本文SHA256": catalog_sha, "入力SHA256前": before, "入力SHA256後": after, "前後不変": True, "選択原板指紋照合": 1, "選択原約定指紋照合": 12, "旧8092の停止再起動設定変更": 0, "金融再実行": 0, "Raw展開解析複製_Tape_Native読取": 0, "凍結helperとBASEの変更": 0}
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(proof, stream, ensure_ascii=False, indent=2, default=lambda value: float(value) if isinstance(value, Decimal) else value)
        stream.write("\n")
    return {"成功": True, "一覧": 840, "実GET": 12, "差": 0}


def main() -> None:
    """機能: 明示固定がある場合だけ専用8093の限定検査を開始する。

    引数: CLI fixed/fixed-sha/out はRoot固定と新規証拠先。
    返り値: None。旧serverや金融コードは操作しない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fixed", type=Path, required=True)
    parser.add_argument("--fixed-sha", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(run(args.fixed.resolve(), args.fixed_sha, args.out.resolve()), ensure_ascii=False))


if __name__ == "__main__":
    main()
