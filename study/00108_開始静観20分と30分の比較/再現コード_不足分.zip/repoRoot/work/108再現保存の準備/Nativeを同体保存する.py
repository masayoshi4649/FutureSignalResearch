"""成功済み108金融Nativeの圧縮bytesだけを正式保存し、本文を解析しない。"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil


WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
TRIAL = ROOT / "study/00108_開始静観20分と30分の比較"
CONDITION = TRIAL / "金融条件.json"
CONDITION_SHA = "0a2a70a4658800060ab4c22a29cdcf21e29a9e2d87f916b0d1c327bb8cf88bd6"
FIRST_SHA = "0fe28a346c5119160da54df0839156268885eeadc0a501a43470c0a3235392b9"


def sha(path: Path) -> str:
    """機能: コード・小metadata・圧縮Nativeの内容指紋を得る。

    引数: path (Path) は許可された実物。
    返り値: str はSHA256。gzipは解凍しない。
    """
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path: Path) -> dict:
    """機能: 小metadataの単一JSONを読む。

    引数: path (Path) は条件・完了・確認又は索引。
    返り値: dict は内容。金融Native本文には呼ばない。
    """
    return json.loads(path.read_text(encoding="utf-8-sig"))


def resolve(ref: dict, base: Path) -> Path:
    """機能: FileRefを基準親から解決する。

    引数: ref (dict)、base (Path) は参照と親。
    返り値: Path は絶対path。ここでは実物を開かない。
    """
    assert set(ref) == {"path", "sha256"} and re.fullmatch("[0-9a-f]{64}", ref["sha256"])
    return (base / ref["path"]).resolve()


def relative(path: Path) -> str:
    """機能: 試行親を基準に正式参照pathを得る。

    引数: path (Path) は参照対象。
    返り値: str は区切りを統一した相対path。
    """
    return os.path.relpath(path, TRIAL).replace("\\", "/")


def write_new(path: Path, value: dict) -> None:
    """機能: 小metadataを新規保存する。

    引数: path (Path)、value (dict) は保存先と内容。
    返り値: None。既存正本は上書きしない。
    """
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def main() -> None:
    """機能: 全70成功と保存成功を結び、Native70本を同体保存する。

    引数: CLI completion/completion-sha は成功後にRootが明示する完了参照。
    返り値: None。Source・価格・公表列の複製や金融再実行はしない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--completion", type=Path, required=True)
    parser.add_argument("--completion-sha", required=True)
    args = parser.parse_args()
    completion = args.completion.resolve()
    assert sha(CONDITION) == CONDITION_SHA and sha(completion) == args.completion_sha
    condition, done = read(CONDITION), read(completion)
    assert condition["trial"] == 108 and condition["fixed"] and len(condition["configs"]) == 12
    assert (done["trial"], done["stage"], done["success"], done["sessions"], done["books_per_scene"], done["books"]) == (108, "full70", True, 70, 12, 840)
    assert done["condition_sha256"] == CONDITION_SHA and done["unchanged"] and done["before"] == done["after"]
    assert done["source_scope"] == "recorded_public_106" and done["cmp_recomputed"] and done["financial_executed"]
    assert not any(done[k] for k in ("source_reexecuted", "features_recomputed", "charts_recomputed", "bank_recomputed"))
    check_path = TRIAL / "成果物/保存会計の確認.json"
    check = read(check_path)
    assert check["成功"] and check["completionSHA256"] == args.completion_sha and check["conditionSHA256"] == CONDITION_SHA
    assert check["会計"] == check["資源"] == 840 and check["不一致数"] == 0
    manifest_path = resolve(condition["source_manifest"], CONDITION.parent)
    assert sha(manifest_path) == condition["source_manifest"]["sha256"]
    ids = [row["id"] for row in read(manifest_path)["sessions"]]
    assert len(ids) == len(set(ids)) == 70 and [row["session"] for row in done["results"]] == ids
    first_path = resolve(done["first2"], completion.parent)
    assert sha(first_path) == done["first2"]["sha256"] == FIRST_SHA
    first = read(first_path)
    assert first["success"] and first["trial"] == 108 and first["stage"] == "first2" and first["sessions"] == 2 and first["books"] == 24 and first["condition_sha256"] == CONDITION_SHA
    for old, new in zip(first["results"], done["results"][:2]):
        assert old["session"] == new["session"] and old["native"]["sha256"] == new["native"]["sha256"]
    prior_path = resolve(condition["prior_native_index"], CONDITION.parent)
    assert sha(prior_path) == condition["prior_native_index"]["sha256"]
    prior = read(prior_path)
    assert prior["成功"] and prior["試行"] == 107 and prior["場数"] == 70
    inputs = {str(p): sha(p) for p in (CONDITION, completion, check_path, manifest_path, first_path, prior_path, Path(__file__).resolve())}
    sources = []
    for row in done["results"]:
        scene = row["session"]
        assert re.fullmatch(r"2026-\d{2}-\d{2}_(Day|Night)", scene)
        assert row["books"] == row["prior_reference_books"] == 12 and row["prior_reference_unchanged"] and not row.get("error")
        path = resolve(row["native"], completion.parent)
        assert path.parent == completion.parent and path.name == scene + ".Native.json.gz"
        assert sha(path) == row["native"]["sha256"]
        inputs[str(path)] = row["native"]["sha256"]
        sources.append((row, path))
    assert len({path for _, path in sources}) == 70
    native_dir = TRIAL / "成果物_金融/Native"
    index_path = native_dir.parent / "Native参照台帳.json"
    assert not native_dir.exists() and not index_path.exists() and not (WORK / "Native保存の確認.json").exists()
    # ----------------------------------------
    # 圧縮Nativeだけを保存し、公表列と旧107Nativeは参照に残す。
    native_dir.mkdir(parents=True, exist_ok=False)
    entries = []
    for row, source in sources:
        dest = native_dir / source.name
        with source.open("rb") as src, dest.open("xb") as dst:
            shutil.copyfileobj(src, dst)
        assert sha(dest) == row["native"]["sha256"] and dest.stat().st_size == source.stat().st_size
        public = {key: {"path": relative(resolve(row[key], completion.parent)), "sha256": row[key]["sha256"]} for key in ("sidecar_header", "sidecar_records")}
        entries.append({"session": row["session"], "path": relative(dest), "sha256": row["native"]["sha256"], "bytes": dest.stat().st_size, "会計": 12, "元": {"path": relative(source), "sha256": row["native"]["sha256"]}, "同bytes": True, "公開sidecar": public})
    after = {name: sha(Path(name)) for name in inputs}
    assert inputs == after
    index = {"成功": True, "試行": 108, "基準": "trialdir", "場数": 70, "金融会計": 840, "元金融完了": {"path": relative(completion), "sha256": args.completion_sha, "bytes": completion.stat().st_size}, "金融条件": {"path": relative(CONDITION), "sha256": CONDITION_SHA}, "Native": entries, "旧107Q30参照の共用": {"path": relative(prior_path), "sha256": condition["prior_native_index"]["sha256"], "対照会計/場": 12, "新規複製": 0}, "公開sidecar": "106の元work header/records参照のみ。新12会計は圧縮bytesのまま保持", "金融本文JSON解析/再実行": 0}
    write_new(index_path, index)
    proof = {"成功": True, "試行": 108, "場数": 70, "会計": 840, "Native総bytes": sum(row["bytes"] for row in entries), "索引": {"path": relative(index_path), "sha256": sha(index_path)}, "入力SHA256前": inputs, "入力SHA256後": after, "前後不変": True, "同bytes": 70, "金融本文JSON解析/再実行/Raw/Source/公表列複製": 0}
    write_new(WORK / "Native保存の確認.json", proof)
    print(json.dumps({"成功": True, "Native": 70, "bytes": proof["Native総bytes"], "索引SHA256": sha(index_path)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
