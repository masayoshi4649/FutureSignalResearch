"""108固定分を変更せず、成功後のCSV・報告等の不足コードだけを追加保存する。"""

from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import zipfile


WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
TRIAL = ROOT / "study/00108_開始静観20分と30分の比較"
LIBRARY = ROOT / "work/107再現保存の準備/再現metadataを準備する.py"
LIBRARY_SHA = "c1b57d4135e17b721458f458d88fc33ed8a312678dac37158778c9264591d606"
CONDITION_SHA = "0a2a70a4658800060ab4c22a29cdcf21e29a9e2d87f916b0d1c327bb8cf88bd6"


def sha(path: Path) -> str:
    """機能: コード・小metadata・ZIP・既存CSVの指紋を取得する。

    引数: path (Path) は許可済み参照。
    返り値: str はSHA256。Rawや金融Native本文には呼ばない。
    """
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write_new(path: Path, value: dict) -> None:
    """機能: 新しい小metadataを保存する。

    引数: path (Path)、value (dict) は新規先と内容。
    返り値: None。既存ZIP・索引は上書きしない。
    """
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def main() -> None:
    """機能: 固定分・全70保存・CSV検算に結んだ事後コードを保存する。

    引数: CLI plan/plan-sha/out はRoot固定の小計画・SHA・新規先。
    返り値: None。金融・CSV再生成・Viewer・正式配置は実行しない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--plan-sha", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    plan_path, output = args.plan.resolve(), args.out.resolve()
    assert not output.exists() and sha(plan_path) == args.plan_sha and sha(LIBRARY) == LIBRARY_SHA
    spec = importlib.util.spec_from_file_location("108事後コードの純所在", LIBRARY)
    library = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(library)
    library.TRIAL = TRIAL
    plan = library.read(plan_path)
    assert plan["version"] == 1 and plan["trial"] == 108 and plan["fixed"] and plan["phase"] == "postprocess_full70" and plan["pending"] == []
    inputs = {str(plan_path): args.plan_sha, str(LIBRARY): LIBRARY_SHA, str(Path(__file__).resolve()): sha(Path(__file__).resolve())}
    required = ("condition", "financial_completion", "summary", "saved_check", "prior_index", "csv_check")
    files = {key: library.bind(plan[key], plan_path.parent, inputs) for key in required}
    condition, done, check, index, csv_check = [library.read(files[key]) for key in ("condition", "financial_completion", "saved_check", "prior_index", "csv_check")]
    assert sha(files["condition"]) == CONDITION_SHA and condition["trial"] == 108 and condition["fixed"] and len(condition["code_sha256"]) == 1050
    assert done["trial"] == 108 and done["success"] and done["stage"] == "full70" and done["sessions"] == 70 and done["books"] == 840 and done["condition_sha256"] == CONDITION_SHA and done["unchanged"] and done["before"] == done["after"]
    assert check["成功"] and check["conditionSHA256"] == CONDITION_SHA and check["completionSHA256"] == sha(files["financial_completion"])
    assert (check["会計"], check["旧保存検算"], check["資源"], check["不一致数"]) == (840, 840, 840, 0) and check["出力SHA256"]["結果.json"] == sha(files["summary"])
    assert index["成功"] and index["試行"] == 108 and index["phase"] == "fixed_code_only" and index["固定code数"] == 1050
    assert csv_check["成功"] and csv_check["試行"] == 108 and csv_check["入力前後不変"] and csv_check["金融再実行"] is False
    assert csv_check["入力SHA256"] == sha(files["summary"]) and Path(csv_check["入力"]).resolve() == files["summary"].resolve()
    assert set(csv_check["出力"]) == {"全セッション.csv", "候補別集計.csv"}
    assert csv_check["出力"]["全セッション.csv"]["データ行数"] == 840 and csv_check["出力"]["候補別集計.csv"]["データ行数"] == 12
    for name, item in csv_check["出力"].items():
        csv_path = files["csv_check"].parent / name
        assert sha(csv_path) == item["sha256"]
        inputs[str(csv_path)] = item["sha256"]
    old_roles = {str(Path(item["original_path"]).resolve()): list(item["roles"]) for item in index["entries"]}
    items = library.collect(plan, condition, plan_path, index, files["prior_index"], inputs)
    for item in items:
        key = str(Path(item["original_path"]).resolve())
        old_count = len(old_roles.get(key, []))
        item["roles"] = item["roles"][:old_count] + [role.replace("106閉鎖所在を継承", "108固定分所在を継承").replace("107金融前固定code", "108金融前固定code").replace("107固定金融実行物", "108固定金融実行物").replace("107事後停止", "108事後停止").replace("107保存metadataのRoot計画", "108保存metadataのRoot計画") for role in item["roles"][old_count:]]
    # ----------------------------------------
    # 旧ZIPの全参照を検査し、同SHAの不足分だけを一つずつ格納する。
    archives = {}
    for item in items:
        location = item["location"]
        if location["kind"] == "既存archive":
            path = (TRIAL / location["archive"]["path"]).resolve()
            if path not in archives:
                assert sha(path) == location["archive"]["sha256"]
                inputs[str(path)] = location["archive"]["sha256"]
                archives[path] = []
            archives[path].append(item)
    for path, rows in archives.items():
        with zipfile.ZipFile(path) as archive:
            assert archive.testzip() is None
            cache = {}
            for item in rows:
                entry = item["location"]["entry"]
                assert library.OLD.safe(entry)
                if entry not in cache:
                    cache[entry] = hashlib.sha256(archive.read(entry)).hexdigest()
                assert cache[entry] == item["SHA256"]
    missing, by_sha = {}, {}
    for item in items:
        if item["location"]["kind"] == "新archive候補":
            entry = by_sha.setdefault(item["SHA256"], item["location"]["entry"])
            item["location"] = {"kind": "新archive", "entry": entry}
            missing.setdefault(entry, item)
    output.mkdir(parents=True)
    target = output / "再現コード_不足分.zip"
    with zipfile.ZipFile(target, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for entry, item in sorted(missing.items()):
            path = Path(item["original_path"])
            assert library.OLD.safe(entry) and item["restore"]["root"] != "goRoot" and path.suffix.lower() not in (".exe", ".gz", ".csv", ".xlsx", ".png") and sha(path) == item["SHA256"]
            archive.write(path, entry)
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None and len(archive.namelist()) == len(set(archive.namelist())) == len(missing)
        assert all(hashlib.sha256(archive.read(entry)).hexdigest() == item["SHA256"] for entry, item in missing.items())
    after = {name: sha(Path(name)) for name in inputs}
    assert inputs == after
    fixed = {str(Path(name).resolve()): value for name, value in condition["code_sha256"].items()}
    located = {str(Path(item["original_path"]).resolve()): item["SHA256"] for item in items}
    assert all(located.get(name) == value for name, value in fixed.items())
    zip_ref = {"path": target.name, "sha256": sha(target), "bytes": target.stat().st_size}
    result = {"成功": True, "試行": 108, "phase": "postprocess_full70", "計画SHA256": args.plan_sha, "金融条件": plan["condition"], "固定code数": 1050, "全所在数": len(items), "新ZIP": zip_ref, "新entry数": len(missing), "所在区分": dict(Counter(item["location"]["kind"] for item in items)), "roots": index["roots"], "Go環境": index["Go環境"], "entries": items, "除外": index["除外"], "入力SHA256前": inputs, "入力SHA256後": after, "前後不変": True, "金融/CSV/Viewer/xlsx実行": 0, "正式配置": False}
    index_path = output / "再現コードの所在.json"
    write_new(index_path, result)
    receipt = {"成功": True, "試行": 108, "phase": "postprocess_full70", "計画SHA256": args.plan_sha, "固定code数": 1050, "固定code所在欠落": 0, "全所在数": len(items), "新entry読戻しSHA一致": len(missing), "CRC差": 0, "危険path": 0, "前後不変": True, "索引SHA256": sha(index_path), "新ZIP": zip_ref, "金融/CSV/Viewer/xlsx実行": 0, "正式配置": False}
    write_new(output / "再現コード保存の確認.json", receipt)
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == "__main__":
    main()
