"""固定済み108の全70入力とコードを、再実行に先立って照合する。"""

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]


def digest(path: Path) -> str:
    """機能: ファイルの指紋を取得する。

    引数: path (Path) はコード又は保存入力。
    返り値: str は実物のSHA256。
    """
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main() -> None:
    """機能: 固定コードと全場の保存列/旧正式Nativeの不変性を確認する。

    引数: なし。108の固定条件と成功first2を参照する。
    返り値: None。検査結果だけを書き、金融や既存Nativeは変更しない。
    """
    trial = ROOT / "study/00108_開始静観20分と30分の比較"
    condition_path = trial / "金融条件.json"
    first_path = ROOT / "work/108市場/先頭2場/完了.json"
    condition = json.loads(condition_path.read_text(encoding="utf-8"))
    first = json.loads(first_path.read_text(encoding="utf-8"))
    source = json.loads(Path(condition["source_completion"]["path"]).read_text(encoding="utf-8"))
    prior_path = Path(condition["prior_native_index"]["path"])
    prior = json.loads(prior_path.read_text(encoding="utf-8"))
    references = dict(first["before"])
    for row in source["results"]:
        for key in ("native", "sidecar_header", "sidecar_records"):
            references[row[key]["path"]] = row[key]["sha256"]
    for row in prior["Native"]:
        references[str(prior_path.parent.parent / row["path"])] = row["sha256"]
    changed = []
    for name, declared in references.items():
        path = Path(name)
        if not path.is_file() or digest(path) != declared:
            changed.append(name)
    condition_sha = digest(condition_path)
    first_sha = digest(first_path)
    assert len(condition["code_sha256"]) == 1050
    assert all(first["before"].get(k) == v for k, v in condition["code_sha256"].items())
    output = {"試行": 108, "金融を実行した": False, "照合参照数": len(references), "コード数": len(condition["code_sha256"]), "全70保存入力と旧Native指紋差": changed, "条件SHA256": condition_sha, "先頭2SHA256": first_sha, "中断Nativeは保持": True, "出力先": "work/108市場/全70場_中断後の同条件再実行", "検査器の修正": "初回の一時検査では正式Native相対pathの基準を台帳親に取り、成果物_金融を二重連結した。現行は台帳の基準に従って試行親から解決し、実入力は未変更。"}
    destination = ROOT / "work/108進行/同条件再実行前の全入力確認.json"
    destination.write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(output, ensure_ascii=False))
    assert not changed
    assert condition_sha == "0a2a70a4658800060ab4c22a29cdcf21e29a9e2d87f916b0d1c327bb8cf88bd6"
    assert first_sha == "0fe28a346c5119160da54df0839156268885eeadc0a501a43470c0a3235392b9"


if __name__ == "__main__":
    main()
