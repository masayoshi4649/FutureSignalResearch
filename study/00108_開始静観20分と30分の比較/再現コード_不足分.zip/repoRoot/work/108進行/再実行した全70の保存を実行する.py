"""108の同条件再実行の全70成功と中断33場の同bytesを確認して保存する。"""

import hashlib
import json
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[2]


def ref(path: Path) -> dict:
    """機能: 絶対位置と実物指紋を取得する。

    引数: path (Path) は条件・完成記録・保存器・既存Native。
    返り値: dict はpath/sha256。
    """
    with path.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"path": str(path.resolve()), "sha256": digest}


def main() -> None:
    """機能: 108の再計算成功と中断分同体を確認し、新規保存する。

    引数: なし。凍結条件と新全70完成記録を使う。
    返り値: None。新金融・Raw/Source/Bank形成は実行しない。
    """
    trial = ROOT / "study/00108_開始静観20分と30分の比較"
    condition = trial / "金融条件.json"
    completion = ROOT / "work/108市場/全70場_中断後の同条件再実行/完了.json"
    code = ROOT / "work/108静観短縮の保存準備/集計.py"
    done = json.loads(completion.read_text(encoding="utf-8"))
    assert done["success"] and done["trial"] == 108 and done["stage"] == "full70"
    assert done["sessions"] == 70 and done["books"] == 840 and done["unchanged"]
    assert done["before"] == done["after"] and len(done["results"]) == 70
    assert done["condition_sha256"] == ref(condition)["sha256"] == "0a2a70a4658800060ab4c22a29cdcf21e29a9e2d87f916b0d1c327bb8cf88bd6"
    assert ref(code)["sha256"] == "291d42dc23b492495fe441e1d72d0673ee3c87766056b117246c396c083d98d5"
    by_scene = {row["session"]: row for row in done["results"]}
    partial_path = ROOT / "work/108進行/中断部分の検査.json"
    partial = json.loads(partial_path.read_text(encoding="utf-8"))
    assert partial["保存済み場数"] == len(partial["Native"]) == 33 and not partial["現在指紋差"]
    matches = []
    for row in partial["Native"]:
        old = Path(row["path"])
        current = by_scene[row["session"]]
        new = Path(current["native"]["path"])
        assert current["books"] == 12 and current["prior_reference_unchanged"] and not current.get("error")
        assert ref(old)["sha256"] == row["sha256"] == ref(new)["sha256"] == current["native"]["sha256"]
        matches.append({"session": row["session"], "中断分": str(old), "再計算分": str(new), "sha256": row["sha256"], "同bytes": True})
    comparison = {"試行": 108, "成功": True, "会計へ重複加算": False, "同条件の全再計算": True, "中断部分": ref(partial_path), "全70完了": ref(completion), "同bytes場数": len(matches), "Native": matches}
    comparison_path = ROOT / "work/108進行/中断33場との同体確認.json"
    with comparison_path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(comparison, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    fixed = {"version": 1, "trial": 108, "fixed": True, "stage": "full70", "condition": ref(condition), "completion": ref(completion), "code": ref(code)}
    fixed_path = trial / "保存条件.json"
    with fixed_path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(fixed, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    args = [sys.executable, "-B", "-X", "utf8", str(code), "--fixed", str(fixed_path), "--fixed-sha", ref(fixed_path)["sha256"], "--out", str(trial / "成果物")]
    print(json.dumps({"固定": ref(fixed_path), "中断33場同体": ref(comparison_path), "argv": args}, ensure_ascii=False), flush=True)
    subprocess.run(args, cwd=ROOT, check=True)


if __name__ == "__main__":
    main()
