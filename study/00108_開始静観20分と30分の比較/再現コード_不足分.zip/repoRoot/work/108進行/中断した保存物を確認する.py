"""108の中断部分を再実行せずに検査し、再開可否の根拠を保存する。"""

from __future__ import annotations

import datetime
import gzip
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
CONDITION = ROOT / "study/00108_開始静観20分と30分の比較/金融条件.json"
NATIVE = ROOT / "work/108市場/全70場"


def digest(path: Path) -> str:
    """機能: 既存実物を読取専用で指紋化する。

    引数: path (Path) はコード、保存列、条件又は既存Native。
    返り値: str はSHA256。原板の展開や売買再計算は行わない。
    """
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main() -> None:
    """機能: 部分Nativeの構造・同条件・入力の現在不変性を確認する。

    引数: なし。凍結108条件と既存の33場を参照する。
    返り値: None。検査JSONだけを新規保存し、完了記録は生成しない。
    """
    condition_sha = digest(CONDITION)
    assert condition_sha == "0a2a70a4658800060ab4c22a29cdcf21e29a9e2d87f916b0d1c327bb8cf88bd6"
    condition = json.loads(CONDITION.read_text(encoding="utf-8"))
    first_path = ROOT / "work/108市場/先頭2場/完了.json"
    first = json.loads(first_path.read_text(encoding="utf-8"))
    expected = dict(first["before"])
    assert len(condition["code_sha256"]) == 1050
    assert all(expected.get(k) == v for k, v in condition["code_sha256"].items())
    manifest = json.loads(Path(condition["source_manifest"]["path"]).read_text(encoding="utf-8"))
    ids = [row["id"] for row in manifest["sessions"]]
    rows = []
    for path in sorted(NATIVE.glob("*.Native.json.gz")):
        raw = path.read_bytes()
        value = json.loads(gzip.decompress(raw))
        scene = value["session"]["id"]
        assert scene in ids and path.name == scene + ".Native.json.gz"
        assert value["trial"] == 108 and value["complete"] and value["tape_unchanged"]
        assert value["condition_sha256"] == condition_sha and value["configs"] == condition["configs"]
        keys = set(value["books"])
        assert len(keys) == 12 and set(value["width_audits"]) == keys and len(value["early_audits"]) == 4 and set(value["clock_audits"]) == keys
        provenance = value["provenance"]
        assert provenance == {"source_scope": "recorded_public_106", "cmp_recomputed": True, "charts_recomputed": False, "raw_market_read": False, "source_reexecuted": False, "bank_recomputed": False, "financial_executed": True}
        proof = value["input_proof"]
        replay = value["replay_proof"]
        assert proof["scene_id"] == scene and proof["tape_canonical_sha256"] == value["tape_canonical_sha256"]
        assert replay["unchanged"] and replay["before"] == replay["after"] == proof["input_sha256"]
        prior = value["prior_reference"]
        assert prior["quiet_seconds"] == 1800 and prior["books"] == prior["width_audits"] == 12 and prior["early_audits"] == 4
        assert prior["tape_canonical_sha256"] == value["tape_canonical_sha256"]
        for name, declared in replay["before"].items():
            assert name not in expected or expected[name] == declared
            expected[name] = declared
        expected[prior["reference_path"]] = prior["reference_sha256"]
        rows.append({"session": scene, "path": str(path.resolve()), "sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw), "会計": 12, "構造と条件一致": True, "保存時入力前後一致": True})
    missing = [scene for scene in ids if scene not in {r["session"] for r in rows}]
    changed = []
    for name, declared in sorted(expected.items()):
        path = Path(name)
        if not path.is_file():
            changed.append({"path": name, "理由": "不存在"})
        elif digest(path) != declared:
            changed.append({"path": name, "理由": "指紋差"})
    first_same = []
    for entry in first["results"]:
        scene = entry["session"]
        row = next(r for r in rows if r["session"] == scene)
        assert row["sha256"] == entry["native"]["sha256"]
        first_same.append(scene)
    result = {"試行": 108, "確認日": datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).isoformat(), "中断": True, "全70完了記録": (NATIVE / "完了.json").exists(), "条件SHA256": condition_sha, "金融を再実行した": False, "正本を変更した": False, "保存済み場数": len(rows), "保存済み会計数": 12 * len(rows), "未完了場数": len(missing), "現在照合した参照数": len(expected), "現在指紋差": changed, "先頭2同bytes": first_same, "Native": rows, "未完了": missing, "再開機能": False, "理由": "凍結CLIはfirst2/full70だけを受理し、full70ではManifest全件を選択する。既存出力directoryを拒否する。実行中binaryのSHA照合があるため、別resumeコードを同条件の固定実行物として扱えない。全70成功や未処理分の実行は未確認。"}
    out = WORK / "中断部分の検査.json"
    with out.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"保存済み": len(rows), "未完了": len(missing), "参照": len(expected), "差": changed, "検査": str(out), "sha256": digest(out)}, ensure_ascii=False))
    assert not changed


if __name__ == "__main__":
    main()
