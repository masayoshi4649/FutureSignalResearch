"""108の全成果物を列挙して監査候補を作り、Root明示実行時だけ試行を閉じる。"""

from __future__ import annotations

import argparse
from datetime import datetime
import hashlib
import importlib.util
import json
from pathlib import Path, PurePosixPath
import re
import zipfile
from zoneinfo import ZoneInfo


ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / "study/00108_開始静観20分と30分の比較"
CSV = ROOT / "outputs/01a1889f-f2af-7943-a047-543275ee9ed2/108損益CSV"
CONDITION_SHA = "0a2a70a4658800060ab4c22a29cdcf21e29a9e2d87f916b0d1c327bb8cf88bd6"
COMPLETE_SHA = "bf0278e332386701221313de8a215fe04adea7666c22bad54c0055303440aae4"
RESULT_SHA = "a71d86cfbfb136449654fcb1b74ba1b37b5c061a9b2a08279d77341dd97cbcd2"
SAVED_SHA = "74719d540e6c616960d5aedaae47e39cfc7291ca47be2e927fb4131fac8ec499"
VIEWER_SHA = "c9a893d5b861cb5da2206bd70c69fb952c9c2ae40739914fe4a3fc82437c363f"
CSV_SHA = "8e03212d16331a0c74e9e683b17da5426b3038994b8138d89375b6fc575a41d6"


def sha(path: Path) -> str:
    """機能: 成果物又は明示コードの内容指紋を得る。

    引数: path (Path) は既存の実物。
    返り値: str はSHA256。金融再実行や原板展開はしない。
    """
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path: Path) -> dict:
    """機能: 保存済みの単一JSONを読む。

    引数: path (Path) は条件・集計・確認又は索引。
    返り値: dict は内容。Native本文は読まない。
    """
    return json.loads(path.read_text(encoding="utf-8-sig"))


def ref(path: Path) -> dict:
    """機能: 現物へ結び付いた参照を作る。

    引数: path (Path) は成果物又はコード。
    返り値: dict は絶対pathとSHA256。
    """
    return {"path": str(path.resolve()), "sha256": sha(path)}


def archives(index: dict) -> None:
    """機能: 所在索引の全ZIP・CRC・参照entryのSHAを再確認する。

    引数: index (dict) は108の事後保存済み索引。
    返り値: None。旧ZIPも含めて一切変更しない。
    """
    grouped = {}
    for item in index["entries"]:
        location = item["location"]
        if location["kind"] not in ("新archive", "既存archive"):
            continue
        archive_ref = index["新ZIP"] if location["kind"] == "新archive" else location["archive"]
        path = (TRIAL / archive_ref["path"]).resolve()
        grouped.setdefault(path, {"sha256": archive_ref["sha256"], "items": []})["items"].append(item)
        assert grouped[path]["sha256"] == archive_ref["sha256"]
    for path, group in grouped.items():
        assert sha(path) == group["sha256"]
        with zipfile.ZipFile(path) as archive:
            assert archive.testzip() is None
            cache = {}
            for item in group["items"]:
                entry = item["location"]["entry"]
                parsed = PurePosixPath(entry)
                assert entry and not parsed.is_absolute() and ".." not in parsed.parts and "\\" not in entry and ":" not in entry
                if entry not in cache:
                    cache[entry] = hashlib.sha256(archive.read(entry)).hexdigest()
                assert cache[entry] == item["SHA256"]


def audit() -> dict:
    """機能: 原計画・入力・70Native・840保存・12GET・840/12CSV・再現を列挙する。

    引数: なし。完成した正式108とRoot固定の外部CSVを使う。
    返り値: dict は決定的な完了候補。研究目標達成と採用は常にfalse。
    """
    assert not (TRIAL / "完了記録.json").exists()
    paths = {"金融条件": TRIAL / "金融条件.json", "金融完了": ROOT / "work/108市場/全70場_中断後の同条件再実行/完了.json", "保存結果": TRIAL / "成果物/結果.json", "保存検算": TRIAL / "成果物/保存会計の確認.json", "Viewer": TRIAL / "検査/Viewer専用8093代表12資源.json", "CSV": CSV / "CSVの確認.json"}
    expected = {"金融条件": CONDITION_SHA, "金融完了": COMPLETE_SHA, "保存結果": RESULT_SHA, "保存検算": SAVED_SHA, "Viewer": VIEWER_SHA, "CSV": CSV_SHA}
    assert all(sha(paths[key]) == value for key, value in expected.items())
    condition, done, result, saved, viewer, csv = [read(paths[key]) for key in paths]
    assert condition["trial"] == 108 and condition["fixed"] and len(condition["configs"]) == 12 and len(condition["code_sha256"]) == 1050
    assert all(sha(Path(name)) == value for name, value in condition["code_sha256"].items())
    assert done["success"] and done["trial"] == 108 and done["stage"] == "full70" and (done["sessions"], done["books_per_scene"], done["books"]) == (70, 12, 840)
    assert done["condition_sha256"] == CONDITION_SHA and done["unchanged"] and done["before"] == done["after"]
    assert result["成功"] and result["stage"] == "full70" and (result["場数"], result["会計数"], result["旧30保存検算会計数"]) == (70, 840, 840)
    assert saved["成功"] and (saved["会計"], saved["旧保存検算"], saved["資源"], saved["不一致数"]) == (840, 840, 840, 0)
    assert saved["前後不変"] and saved["入力codeSHA256前"] == saved["入力codeSHA256後"] and saved["conditionSHA256"] == CONDITION_SHA and saved["completionSHA256"] == COMPLETE_SHA
    assert all(sha(TRIAL / "成果物" / name) == value for name, value in saved["出力SHA256"].items())
    manifest_path = Path(condition["source_manifest"]["path"])
    assert sha(manifest_path) == condition["source_manifest"]["sha256"] and sha(Path(condition["source_corpus"]["path"])) == condition["source_corpus"]["sha256"]
    manifest = read(manifest_path)
    ids = [row["id"] for row in manifest["sessions"]]
    assert len(ids) == len(set(ids)) == 70 and [row["session"] for row in done["results"]] == ids
    renderer_path = ROOT / "work/108報告の準備/報告を差し替える.py"
    assert sha(renderer_path) == "a575686ace58a05c074437bde89a0cc4863ecfc4b56f5cc11b84ec806b42e4b6"
    spec = importlib.util.spec_from_file_location("108閉鎖の保存集計検算", renderer_path)
    renderer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(renderer)
    renderer.validate_result(result, ids, [row["contract"] for row in manifest["sessions"]])
    native_index_path = TRIAL / "成果物_金融/Native参照台帳.json"
    native = read(native_index_path)
    assert native["成功"] and (native["試行"], native["場数"], native["金融会計"]) == (108, 70, 840) and native["元金融完了"]["sha256"] == COMPLETE_SHA
    assert [row["session"] for row in native["Native"]] == ids
    for entry, source in zip(native["Native"], done["results"]):
        path = (TRIAL / entry["path"]).resolve()
        assert entry["同bytes"] and entry["会計"] == 12 and sha(path) == entry["sha256"] == source["native"]["sha256"] and path.stat().st_size == entry["bytes"]
    assert viewer["成功"] and (viewer["一覧"], viewer["実GET"]) == (840, 12) and viewer["選択場"] == "2026-09-21_Day"
    assert viewer["前後不変"] and viewer["入力SHA256前"] == viewer["入力SHA256後"] and viewer["旧8092の停止再起動設定変更"] == 0 and "8093" in viewer["scope"]
    assert csv["成功"] and csv["試行"] == 108 and csv["入力SHA256"] == RESULT_SHA and csv["入力前後不変"] and csv["金融再実行"] is False
    assert csv["出力"]["全セッション.csv"]["データ行数"] == 840 and csv["出力"]["候補別集計.csv"]["データ行数"] == 12
    independent = csv["CSV独立再読"]
    assert independent["成功"] and (independent["全行"], independent["集計行"], independent["数値対照件数"], independent["累計対照"], independent["参加率対照"]) == (840, 12, 5040, 840, 840)
    assert all(sha(CSV / name) == item["sha256"] for name, item in csv["出力"].items())
    report = read(TRIAL / "検査/報告の確認.json")
    assert report["成功"] and report["前後不変"] and report["入力SHA256前"] == report["入力SHA256後"] and report["55x9/S13K12/R12保持"]
    assert all(sha(TRIAL / name) == value for name, value in report["出力SHA256"].items())
    for name, value in report["原計画SHA256"].items():
        assert sha(TRIAL / "原計画" / name) == value
    original_settings = (TRIAL / "原計画/設定と結果.md").read_text(encoding="utf-8")
    current_settings = (TRIAL / "設定と結果.md").read_text(encoding="utf-8")
    for prefix, count in ((r"(?:I|C|P|V|B|X|M|E)", 55), ("S", 13), ("K", 12)):
        pattern = re.compile(r"^\| " + prefix + r"\d{2} \|", re.MULTILINE)
        old = [line for line in original_settings.splitlines() if pattern.match(line)]
        new = [line for line in current_settings.splitlines() if pattern.match(line)]
        assert len(old) == len(new) == count and old == new
    assert len(re.findall(r"^\| R\d{2} \|", current_settings, re.MULTILINE)) == 12
    archive_path = TRIAL / "再現コードの所在.json"
    archive = read(archive_path)
    archive_check = read(TRIAL / "検査/再現コード保存の確認.json")
    assert archive["成功"] and archive["試行"] == 108 and archive["phase"] == "postprocess_full70" and archive["固定code数"] == 1050
    assert archive_check["成功"] and archive_check["索引SHA256"] == sha(archive_path) and archive_check["固定code所在欠落"] == archive_check["CRC差"] == archive_check["危険path"] == 0
    assert archive["前後不変"] and archive["入力SHA256前"] == archive["入力SHA256後"]
    locations = {str(Path(item["original_path"]).resolve()): item["SHA256"] for item in archive["entries"]}
    assert all(locations.get(str(Path(name).resolve())) == value for name, value in condition["code_sha256"].items())
    assert locations[str(Path(__file__).resolve())] == sha(Path(__file__).resolve())
    archives(archive)
    assert (TRIAL / "再現.md").is_file()
    recovery = read(TRIAL / "検査/中断33場との同体確認.json")
    assert recovery["成功"] and recovery["同bytes場数"] == 33 and recovery["会計へ重複加算"] is False
    failure = read(TRIAL / "検査/Viewer接続の未成立.json")
    assert failure["成功"] is False and failure["data GET試行"] == 0 and failure["server停止再起動設定変更"] == 0
    introduction = read(TRIAL / "検査/事後保存器の導入部確認.json")
    assert introduction["成功"] and introduction["AttributeError"] is False and introduction["金融再実行"] is False
    old_trial = ROOT / "study/00107_見送り明けの初回取得と利益保護"
    old_closure_path = old_trial / "完了記録.json"
    assert sha(old_closure_path) == "86f059635b6dfc3915edc823a575a0b5162d41cfebce963b0bdd365ab860aa5d"
    old_closure = read(old_closure_path)
    assert all(sha(old_trial / name) == value for name, value in old_closure["SHA256"].items())
    main = result["集計"]
    fail25 = sum(4 * item["活動主表"]["active"] < 7980 for item in main.values())
    fail50 = sum(2 * item["活動主表"]["active"] < 7980 for item in main.values())
    night_fail = sum(4 * result["実現診断"][key]["日夜"]["Night"]["活動主表"]["active"] < 5250 for key in main)
    assert (fail25, fail50, night_fail) == (7, 12, 12)
    formal = sorted(path for path in TRIAL.rglob("*") if path.is_file())
    hashes = {path.relative_to(TRIAL).as_posix(): sha(path) for path in formal}
    return {"試行": 108, "準備監査成功": True, "試行完了": False, "研究目標達成": False, "実運用採用": False, "金融場数": 70, "開始日数": 35, "新経済会計": 840, "旧30保存検算": 840, "旧30再金融": False, "保存会計不一致": 0, "原計画同bytes": report["原計画SHA256"], "汎用表55x9/S13K12/R12保持": True, "入力指紋": {key: condition[key] for key in ("source_manifest", "source_corpus", "source_completion", "prior_closure", "prior_completion", "prior_native_index")}, "固定コード1050不変": True, "Native": {"参照台帳": ref(native_index_path), "場数": 70, "会計": 840, "全SHA同体": True}, "Viewer": {"証拠": ref(paths["Viewer"]), "scope": viewer["scope"], "一覧": 840, "実GET": 12}, "CSV": {"証拠": ref(paths["CSV"]), "全場行": 840, "集計行": 12, "独立再読": independent, "出力": {name: ref(CSV / name) for name in csv["出力"]}}, "再現索引": ref(archive_path), "再現手順": ref(TRIAL / "再現.md"), "全12費用後黒字": all(item["net_yen"] > 0 for item in main.values()), "最低参加25未達設定数": fail25, "目標参加50未達設定数": fail50, "夜間単独最低25未達設定数": night_fail, "主分母": 7980, "副分母": 7700, "政策費用別純額": {key: item["net_yen"] for key, item in main.items()}, "主参加枠": {key: item["活動主表"]["active"] for key, item in main.items()}, "旧107正式ファイル不変": len(old_closure["SHA256"]), "次の5分15分30分追加": "108で未実施・金融未検証。次試行の方針", "未達": ["全設定で参加50%未達", "7設定で全体参加25%未達、全12設定で夜間25%未達", "11/06主条件の赤字と利益保護の問題が残る", "全70は既使用探索で未見安定性・実運用収益は未証明"], "xlsx生成更新": 0, "閉鎖helper": ref(Path(__file__).resolve()), "正式ファイル数_本記録自身を除く": len(formal), "正式bytes_本記録自身を除く": sum(path.stat().st_size for path in formal), "SHA256": hashes}


def main() -> None:
    """機能: 監査候補を作るか、Root指定の候補SHAへ一致した記録だけ閉じる。

    引数: CLI prepare/out 又は close/candidate/candidate-sha は候補生成とRoot最終実行。
    返り値: None。金融・CSV・Viewerは実行せず、既存完了を上書きしない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--prepare", action="store_true")
    mode.add_argument("--close", action="store_true")
    parser.add_argument("--out", type=Path)
    parser.add_argument("--candidate", type=Path)
    parser.add_argument("--candidate-sha")
    args = parser.parse_args()
    current = audit()
    if args.prepare:
        assert args.out is not None and args.candidate is None and args.candidate_sha is None
        current["候補作成時刻"] = datetime.now(ZoneInfo("Asia/Tokyo")).isoformat()
        destination = args.out.resolve()
    else:
        assert args.out is None and args.candidate is not None and args.candidate_sha
        candidate_path = args.candidate.resolve()
        assert sha(candidate_path) == args.candidate_sha
        candidate = read(candidate_path)
        candidate.pop("候補作成時刻")
        assert current == candidate
        current.update({"試行完了": True, "完了時刻": datetime.now(ZoneInfo("Asia/Tokyo")).isoformat(), "監査候補": ref(candidate_path)})
        destination = TRIAL / "完了記録.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(current, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"成功": True, "試行完了": current["試行完了"], "研究目標達成": False, "実運用採用": False, "出力": ref(destination)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
