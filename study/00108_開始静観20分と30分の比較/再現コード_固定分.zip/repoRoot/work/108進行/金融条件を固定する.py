"""108の20分12設定・保存入力・成功停止・実行物を金融前に一度だけ固定する。"""

import argparse
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / "study/00108_開始静観20分と30分の比較"


def sha(path: Path) -> str:
    """機能: コード又は小metadataのSHA256を求める。

    引数: path(Path)は存在する実物。原板・CSVは指定しない。
    返り値: strは小文字指紋。
    """
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path: Path) -> dict:
    """機能: UTF-8 JSONを全値で読み込む。

    引数: path(Path)は準備結果又は既存閉鎖記録。
    返り値: dictは内容。
    """
    return json.loads(path.read_text(encoding="utf-8-sig"))


def ref(path: Path) -> dict:
    """機能: 実物の絶対位置と指紋を結ぶ。

    引数: path(Path)は固定する既存ファイル。
    返り値: dictはpath/sha256。
    """
    return {"path": str(path.resolve()), "sha256": sha(path)}


def main() -> None:
    """機能: 停止・依存・旧107閉鎖を照合して新金融条件を保存する。

    引数: CLIのbinary/binary-sha/closure-sha(str)は停止実行物とGo閉包の明示指紋。
    返り値: None。市場本文を読まず、金融を実行しない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--binary-sha", required=True)
    parser.add_argument("--closure-sha", required=True)
    args = parser.parse_args()
    target = TRIAL / "金融条件.json"
    assert not target.exists()
    binary = args.binary.resolve()
    assert sha(binary) == args.binary_sha
    closure_path = ROOT / "work/108市場コードの閉包/候補/Go閉包候補.json"
    assert sha(closure_path) == args.closure_sha
    closure = read(closure_path)
    assert closure["成功"] and closure["全選択code前後不変"]
    assert closure["候補exe"]["sha256"] == args.binary_sha
    code = {}
    for item in closure["files"] + closure["Go5tool"]:
        path = Path(item["path"]).resolve()
        assert sha(path) == item["sha256"], str(path)
        code[str(path)] = item["sha256"]
    stop_dirs = ["静観長を指定する入口時計", "静観長を分ける保護会計", "108静観短縮の市場接続準備",
                 "107保存公表の再読口_埋込対応", "108静観短縮の保存準備", "108市場の入出力準備"]
    stops = [ROOT / "work" / name / "停止.json" for name in stop_dirs]
    for stop in stops:
        value = read(stop)
        assert value["成功"] and value["所有コードSHA256"], str(stop)
        for name, expected in {**value.get("再用コードと停止SHA256", {}), **value["所有コードSHA256"]}.items():
            path = (ROOT / name).resolve()
            assert sha(path) == expected, name
            assert str(path) not in code or code[str(path)] == expected
            code[str(path)] = expected
    clock_check = TRIAL / "検査/時計の可用性.json"
    temporal = read(clock_check)
    assert temporal["成功"] and temporal["場数"] == 70
    assert temporal["所定分母合計"]["1200"] == {"force": 7980, "end30": 7700}
    for path in [Path(__file__).resolve(), ROOT / "work/108市場コードの閉包/収集する.py", closure_path,
                 ROOT / "work/108設定表の作成/設定表を作成する.py", ROOT / "work/108進行/市場を実行する.ps1", clock_check]:
        code[str(path)] = sha(path)
    specifications = []
    for name in ["README.md", "設定と結果.md"]:
        source, snapshot = TRIAL / name, TRIAL / "市場前仕様" / name
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        with snapshot.open("xb") as stream:
            stream.write(source.read_bytes())
        assert sha(source) == sha(snapshot)
        specifications.append(ref(snapshot))
    old106 = ROOT / "study/00106_収束失速で保護の起動と幅を切り替える"
    old107 = ROOT / "study/00107_見送り明けの初回取得と利益保護"
    prior_closure = old107 / "完了記録.json"
    assert sha(prior_closure) == "86f059635b6dfc3915edc823a575a0b5162d41cfebce963b0bdd365ab860aa5d"
    assert read(prior_closure)["試行完了"]
    configs = [{"candidate": name, "entry_timing": "B5QD", "protection_policy": policy,
                "slip_pts": cost, "delay_seconds": delay, "quiet_seconds": 1200}
               for name, policy in [("Q0", "W0"), ("Q1", "W1"), ("QE", "E1")]
               for cost in [0, 5] for delay in [0, 1]]
    condition = {"version": 1, "trial": 108, "fixed": True, "scope": "開始/US静観20分の12新金融対旧107 Q30保存参照、全70既使用探索",
                 "source_scope": "recorded_public_106", "workers": 4, "own_module_dir": str(ROOT / "work/108市場の入出力準備"),
                 "source_manifest": ref(old106 / "入力台帳_70場.json"), "source_corpus": ref(old106 / "Source台帳_70場.json"),
                 "source_completion": ref(ROOT / "work/106市場/全70場/完了.json"), "prior_closure": ref(prior_closure),
                 "prior_completion": ref(ROOT / "work/107市場/埋込対応_全70場/完了.json"),
                 "prior_native_index": ref(old107 / "成果物_金融/Native参照台帳.json"), "binary": ref(binary),
                 "stops": [ref(p) for p in stops], "specifications": specifications, "code_sha256": code, "configs": configs}
    with target.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(condition, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    journal_path = ROOT / "work/108進行/現在.json"
    journal = read(journal_path)
    journal.update({"段階": "108金融条件固定・市場未実行", "金融条件": ref(target), "実行物": ref(binary), "コード数": len(code)})
    journal_path.write_text(json.dumps(journal, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"金融条件": ref(target), "実行物": ref(binary), "コード数": len(code)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
