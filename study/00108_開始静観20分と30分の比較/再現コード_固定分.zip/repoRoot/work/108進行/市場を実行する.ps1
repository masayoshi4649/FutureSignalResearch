param([Parameter(Mandatory=$true)][string]$BinaryPath)
$ErrorActionPreference = 'Stop'
$conditionPath = (Resolve-Path -LiteralPath 'study/00108_開始静観20分と30分の比較/金融条件.json').Path
$conditionSHA = (Get-FileHash -LiteralPath $conditionPath -Algorithm SHA256).Hash.ToLowerInvariant()
$binaryFull = (Resolve-Path -LiteralPath $BinaryPath).Path
$firstOut = [System.IO.Path]::GetFullPath('work/108市場/先頭2場')
$fullOut = [System.IO.Path]::GetFullPath('work/108市場/全70場')
& $binaryFull --condition $conditionPath --condition-sha $conditionSHA --stage first2 --out $firstOut
if ($LASTEXITCODE -ne 0) { throw '先頭2場失敗。全70場は実行しません。' }
$firstPath = Join-Path $firstOut '完了.json'
$first = Get-Content -LiteralPath $firstPath -Raw -Encoding utf8 | ConvertFrom-Json
if (-not $first.success -or $first.sessions -ne 2 -or $first.books -ne 24 -or -not $first.unchanged) { throw '先頭2場の成功metadata不成立。' }
$firstSHA = (Get-FileHash -LiteralPath $firstPath -Algorithm SHA256).Hash.ToLowerInvariant()
& $binaryFull --condition $conditionPath --condition-sha $conditionSHA --stage full70 --out $fullOut --first2 $firstPath --first2-sha $firstSHA
if ($LASTEXITCODE -ne 0) { throw '全70場の金融に失敗しました。' }
