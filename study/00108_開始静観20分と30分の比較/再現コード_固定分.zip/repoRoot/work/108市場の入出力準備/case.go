package main

import (
	"encoding/json"
	"fmt"
	"path/filepath"
	"reflect"

	core "github.com/masayoshi4649/SessionTradeExecuter/quietguardruntime108"
	reader "github.com/masayoshi4649/SessionTradeExecuter/savedpublic107"
)

type SceneResult struct {
	Session        string  `json:"session"`
	Native         FileRef `json:"native"`
	Header         FileRef `json:"sidecar_header"`
	Records        FileRef `json:"sidecar_records"`
	Books          int     `json:"books"`
	PriorBooks     int     `json:"prior_reference_books"`
	PriorNative    FileRef `json:"prior_native"`
	PriorUnchanged bool    `json:"prior_reference_unchanged"`
	Error          string  `json:"error,omitempty"`
}

type Provenance struct {
	SourceScope       string `json:"source_scope"`
	CMPRecomputed     bool   `json:"cmp_recomputed"`
	ChartsRecomputed  bool   `json:"charts_recomputed"`
	RawRead           bool   `json:"raw_market_read"`
	SourceReexecuted  bool   `json:"source_reexecuted"`
	BankRecomputed    bool   `json:"bank_recomputed"`
	FinancialExecuted bool   `json:"financial_executed"`
}

type NativeOutput struct {
	core.Result
	ConditionSHA string             `json:"condition_sha256"`
	Input        reader.Proof       `json:"input_proof"`
	Replay       reader.ReplayProof `json:"replay_proof"`
	Provenance   Provenance         `json:"provenance"`
}

// loadControl は旧107Q30の正式Nativeから対象12冊と外auditを生JSONのまま認証します。
//
// 引数: ref(FileRef)は107成功完了と正式台帳へ結んだNativeです。
// 返り値: core.Control/errorは除外fieldのない12/12/4の保存参照です。成績を新会計へ転記しません。
func loadControl(ref FileRef) (core.Control, error) {
	before := map[string]string{}
	p, err := checkRef(ref, ".", before)
	if err != nil {
		return core.Control{}, err
	}
	var old struct {
		Trial    int                        `json:"trial"`
		Complete bool                       `json:"complete"`
		Session  json.RawMessage            `json:"session"`
		Contract string                     `json:"contract"`
		TapeSHA  string                     `json:"tape_canonical_sha256"`
		Configs  []core.Config              `json:"configs"`
		Books    map[string]json.RawMessage `json:"books"`
		Width    map[string]json.RawMessage `json:"width_audits"`
		Early    map[string]json.RawMessage `json:"early_audits"`
	}
	if err = readJSON(p, true, &old); err != nil {
		return core.Control{}, err
	}
	if old.Trial != 107 || !old.Complete || len(old.Books) != 24 || len(old.Width) != 24 || len(old.Early) != 8 || len(old.Configs) != 24 {
		return core.Control{}, fmt.Errorf("旧107Q30 Nativeの完了/24設定差")
	}
	c := core.Control{Kind: "provided_old107_q30", HistoryClass: "old_saved_70", ReferencePath: p, ReferenceSHA: ref.SHA, Contract: old.Contract, TapeSHA: old.TapeSHA, QuietSeconds: 1800, Books: map[string]json.RawMessage{}, WidthAudits: map[string]json.RawMessage{}, EarlyAudits: map[string]json.RawMessage{}}
	if err = json.Unmarshal(old.Session, &c.Session); err != nil {
		return c, err
	}
	expected := map[string]core.Config{}
	for _, cfg := range core.Configurations() {
		cfg.QuietSeconds = 0
		expected[core.Key(cfg)] = cfg
	}
	seen := map[string]bool{}
	for _, cfg := range old.Configs {
		k := core.Key(cfg)
		want, ok := expected[k]
		if !ok {
			continue
		}
		if seen[k] || !reflect.DeepEqual(cfg, want) {
			return c, fmt.Errorf("旧107Q30 Config差:%s", k)
		}
		seen[k] = true
	}
	if len(seen) != 12 {
		return c, fmt.Errorf("旧107Q30の12設定不足")
	}
	for _, cfg := range core.Configurations() {
		key := core.Key(cfg)
		if len(old.Books[key]) == 0 || len(old.Width[key]) == 0 {
			return c, fmt.Errorf("旧107Q30のBook/幅不足:%s", key)
		}
		c.Books[key], c.WidthAudits[key] = old.Books[key], old.Width[key]
		if cfg.Policy == "E1" {
			if len(old.Early[key]) == 0 {
				return c, fmt.Errorf("旧107Q30早期audit不足:%s", key)
			}
			c.EarlyAudits[key] = old.Early[key]
		}
	}

	_, err = recheck(before)
	return c, err
}

// runScene は一場の保存列だけを独立したQ20の12会計へ配送します。
//
// 引数: p(Plan)、id/out(string)は固定計画・一場・新規出力directory。
// 返り値: SceneResultはNative参照又は失敗理由です。他場の金融状態を共有しません。
func runScene(p Plan, id, out string) (result SceneResult) {
	result.Session = id
	loaded, err := reader.LoadTape(readerRequest(p, id))
	if err != nil {
		result.Error = err.Error()
		return
	}
	proof := loaded.Proof()
	priorRef := FileRef{}
	for i, scene := range p.Manifest.Sessions {
		if scene.ID == id {
			priorRef = p.PriorNative[i]
			break
		}
	}
	control, err := loadControl(priorRef)
	if err != nil {
		result.Error = err.Error()
		return
	}
	input := loaded.Tape()
	header := loaded.Header()
	runtime, err := core.NewCore(input, header.Scene.Contract, p.Condition.Scope, control)
	if err != nil {
		result.Error = err.Error()
		return
	}
	h, replay, err := reader.ReplayRecords(loaded, runtime.Feed)
	if err != nil {
		result.Error = err.Error()
		return
	}
	r, err := runtime.Finish(h)
	if err != nil {
		result.Error = err.Error()
		return
	}
	if !r.Complete || len(r.Books) != 12 || r.PriorReference.QuietSeconds != 1800 || r.PriorReference.Books != 12 || r.PriorReference.WidthAudits != 12 || r.PriorReference.EarlyAudits != 4 || !replay.Unchanged || r.SourceReexecuted || r.ChartRecomputed || r.BankRecomputed {
		result.Error = "新12会計/旧Q30保存参照12/幅12/早期4/再用の完了差"
		return
	}
	value := NativeOutput{Result: r, ConditionSHA: p.ConditionSHA, Input: proof, Replay: replay, Provenance: Provenance{SourceScope: p.Condition.Mode, CMPRecomputed: true, FinancialExecuted: true}}
	result.Native, err = writeJSON(filepath.Join(out, id+".Native.json.gz"), value, true)
	if err != nil {
		result.Error = err.Error()
		return
	}
	for _, old := range p.Source.Results {
		if old.Session == id {
			a, _ := absolute(p.Base, old.Header.Path)
			b, _ := absolute(p.Base, old.Records.Path)
			result.Header = FileRef{a, old.Header.SHA}
			result.Records = FileRef{b, old.Records.SHA}
			break
		}
	}
	result.Books, result.PriorBooks = 12, 12
	result.PriorNative = priorRef
	after, e := fileSHA(priorRef.Path)
	if e != nil || after != priorRef.SHA {
		result.Error = "旧Q30保存参照の実行前後SHA差"
		return
	}
	result.PriorUnchanged = true
	return
}
