package main

import (
	"encoding/json"
	"fmt"
	"path/filepath"
	"strings"
	"testing"
	"time"

	reader "github.com/masayoshi4649/SessionTradeExecuter/savedpublic107"
)

// metadataFixture は実物を開かない70場の手製metadata型を作ります。
//
// 引数: t(*testing.T)は検査器です。
// 返り値: PlanはSource106/旧107/正式indexの正接続型です。実金融成功の証拠ではありません。
func metadataFixture(t *testing.T) Plan {
	t.Helper()
	root := t.TempDir()
	h := strings.Repeat("a", 64)
	p := Plan{PriorIndexRoot: filepath.Join(root, "study", "旧107")}
	p.Condition.SourceManifest = FileRef{filepath.Join(root, "manifest.json"), "902c6b5147763de172c0199f79b13cdc08f9a5636b05e0575f19bffd2da627e8"}
	p.Condition.SourceCorpus = FileRef{filepath.Join(root, "corpus.json"), "ca6206d47d36772fff84d230073bd4346b1e785d5b0bb98c565bafe6c92fb441"}
	p.Condition.SourceCompletion = FileRef{filepath.Join(root, "source106.json"), "c1370aac63c1905f132237becd5d5bb37c6bd06e20b061800c9d0caa02a1769f"}
	p.Condition.PriorCompletion = FileRef{filepath.Join(root, "prior107.json"), "80faf888eda44badca7cdc0f5fb70aa7354b3dcc4c771411df18fe10409d3c01"}
	p.Condition.PriorNativeIndex = FileRef{filepath.Join(p.PriorIndexRoot, "成果物_金融", "Native参照台帳.json"), "4e6858a1107d2f910985c1833fc99e3cd60b6b06077e36fc65138a8fdaa650d2"}
	p.Source = reader.Completion{Version: 1, Trial: 106, Stage: "full70", Success: true, ConditionSHA: reader.Condition106, Sessions: 70, BooksPerScene: 20, Books: 1400, Before: map[string]string{"手製metadata": h}, After: map[string]string{"手製metadata": h}, Unchanged: true}
	p.Prior = PriorCompletion{Version: 1, Trial: 107, Stage: "full70", Success: true, ConditionSHA: "4ab51b9fadc6745ac25597b09365062b629ce329e88507f261fbc0f0760cab97", Sessions: 70, BooksPerScene: 24, Books: 1680, Before: map[string]string{"手製metadata": h}, After: map[string]string{"手製metadata": h}, Unchanged: true, InputMode: "recorded_public_106"}
	p.PriorIndex = PriorNativeIndex{Success: true, Trial: 107, Base: "trialdir", Sessions: 70, Books: 1680}
	scenes := []map[string]string{}
	for i := 0; i < 70; i++ {
		date := time.Date(2026, 9, 21+i/2, 0, 0, 0, 0, time.UTC)
		kind := "Day"
		if i%2 == 1 {
			kind = "Night"
		}
		id := date.Format("2006-01-02") + "_" + kind
		scenes = append(scenes, map[string]string{"id": id})
		header := reader.FileRef{Path: filepath.Join(root, "106", id+".header.json"), SHA: h}
		records := reader.FileRef{Path: filepath.Join(root, "106", id+".records.jsonl.gz"), SHA: h}
		p.Source.Results = append(p.Source.Results, reader.SceneOutput{Session: id, Native: reader.FileRef{Path: filepath.Join(root, "106", id+".Native.json.gz"), SHA: h}, Header: header, Records: records, Books: 20, W0Books: 4})
		oldNative := FileRef{filepath.Join(root, "107", id+".Native.json.gz"), h}
		p.Prior.Results = append(p.Prior.Results, PriorScene{Session: id, Native: oldNative, Header: FileRef{header.Path, h}, Records: FileRef{records.Path, h}, Books: 24, BaseBooks: 12})
		p.PriorIndex.Native = append(p.PriorIndex.Native, PriorNativeRow{Session: id, Path: filepath.ToSlash(filepath.Join("成果物_金融", "Native", id+".Native.json.gz")), SHA: h, Bytes: 100, Books: 24, Original: oldNative, SameBytes: true})
	}
	b, _ := json.Marshal(map[string]any{"sessions": scenes})
	if e := json.Unmarshal(b, &p.Manifest); e != nil {
		t.Fatal(e)
	}
	return p
}

// TestSourcePriorMetadata は106入力と107実績の混同・部分集合・偽結合を拒否します。
//
// 引数: t(*testing.T)は手製schemaだけの検査器です。
// 返り値: なし。Raw/保存市場列/Nativeは読みません。
func TestSourcePriorMetadata(t *testing.T) {
	p := metadataFixture(t)
	if e := validateSources(&p); e != nil {
		t.Fatal(e)
	}
	if len(p.PriorNative) != 70 || filepath.Dir(p.PriorNative[0].Path) != filepath.Join(p.PriorIndexRoot, "成果物_金融", "Native") {
		t.Fatal("正式index基準の解決差")
	}
	for _, name := range []string{"source_pointer", "source_trial", "partial", "prior_trial", "prior_source", "empty_before", "duplicate", "index_sha", "header_sha", "traversal"} {
		t.Run(name, func(t *testing.T) {
			p := metadataFixture(t)
			switch name {
			case "source_pointer":
				p.Condition.SourceCompletion = p.Condition.PriorCompletion
			case "source_trial":
				p.Source.Trial = 107
			case "partial":
				p.Prior.Results = p.Prior.Results[:2]
			case "prior_trial":
				p.Prior.Trial = 108
			case "prior_source":
				p.Prior.SourceReexecuted = true
			case "empty_before":
				p.Prior.Before = map[string]string{}
				p.Prior.After = map[string]string{}
			case "duplicate":
				p.PriorIndex.Native[1].Session = p.PriorIndex.Native[0].Session
			case "index_sha":
				p.PriorIndex.Native[0].SHA = strings.Repeat("b", 64)
			case "header_sha":
				p.Prior.Results[0].Header.SHA = strings.Repeat("b", 64)
			case "traversal":
				p.PriorIndex.Native[0].Path = fmt.Sprintf("../%s.Native.json.gz", p.Manifest.Sessions[0].ID)
			}
			if e := validateSources(&p); e == nil {
				t.Fatal("不正metadataを受理")
			}
		})
	}
}
