package main

import (
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"regexp"

	core "github.com/masayoshi4649/SessionTradeExecuter/quietguardruntime108"
	reader "github.com/masayoshi4649/SessionTradeExecuter/savedpublic107"
)

type Condition struct {
	Version          int               `json:"version"`
	Trial            int               `json:"trial"`
	Fixed            bool              `json:"fixed"`
	Scope            string            `json:"scope"`
	Mode             string            `json:"source_scope"`
	Workers          int               `json:"workers"`
	OwnModuleDir     string            `json:"own_module_dir"`
	SourceManifest   FileRef           `json:"source_manifest"`
	SourceCorpus     FileRef           `json:"source_corpus"`
	SourceCompletion FileRef           `json:"source_completion"`
	PriorClosure     FileRef           `json:"prior_closure"`
	PriorCompletion  FileRef           `json:"prior_completion"`
	PriorNativeIndex FileRef           `json:"prior_native_index"`
	Binary           FileRef           `json:"binary"`
	Stops            []FileRef         `json:"stops"`
	Specifications   []FileRef         `json:"specifications"`
	Code             map[string]string `json:"code_sha256"`
	Configs          []core.Config     `json:"configs"`
}

type PriorScene struct {
	Session   string  `json:"session"`
	Native    FileRef `json:"native"`
	Header    FileRef `json:"sidecar_header"`
	Records   FileRef `json:"sidecar_records"`
	Books     int     `json:"books"`
	BaseBooks int     `json:"base_control_books"`
	Error     string  `json:"error,omitempty"`
}
type PriorCompletion struct {
	Version          int               `json:"version"`
	Trial            int               `json:"trial"`
	Stage            string            `json:"stage"`
	Success          bool              `json:"success"`
	ConditionSHA     string            `json:"condition_sha256"`
	Sessions         int               `json:"sessions"`
	BooksPerScene    int               `json:"books_per_scene"`
	Books            int               `json:"books"`
	Results          []PriorScene      `json:"results"`
	Before           map[string]string `json:"before"`
	After            map[string]string `json:"after"`
	Unchanged        bool              `json:"unchanged"`
	InputMode        string            `json:"input_mode"`
	SourceReexecuted bool              `json:"source_reexecuted"`
	ChartsRecomputed bool              `json:"charts_recomputed"`
}
type PriorNativeRow struct {
	Session   string  `json:"session"`
	Path      string  `json:"path"`
	SHA       string  `json:"sha256"`
	Bytes     int64   `json:"bytes"`
	Books     int     `json:"会計"`
	Original  FileRef `json:"元"`
	SameBytes bool    `json:"同bytes"`
}
type PriorNativeIndex struct {
	Success  bool             `json:"成功"`
	Trial    int              `json:"試行"`
	Base     string           `json:"基準"`
	Sessions int              `json:"場数"`
	Books    int              `json:"金融会計"`
	Native   []PriorNativeRow `json:"Native"`
}
type Plan struct {
	Condition      Condition
	ConditionSHA   string
	Base           string
	Before         map[string]string
	Manifest       reader.Manifest
	Source         reader.Completion
	Prior          PriorCompletion
	PriorIndex     PriorNativeIndex
	PriorIndexRoot string
	PriorNative    []FileRef
}

// prepare は金融へ進む前に108条件と106入力/107Q30保存参照metadataを固定します。
//
// 引数: path/expected(string)はRoot固定JSONと明示SHAです。
// 返り値: Plan/errorは固定12設定・全70の参照又は不成立です。原板/CSVを読みません。
func prepare(path, expected string) (Plan, error) {
	p := Plan{Before: map[string]string{}}
	if !filepath.IsAbs(path) {
		return p, fmt.Errorf("条件JSONは絶対pathが必要です")
	}
	full, err := filepath.Abs(path)
	if err != nil {
		return p, err
	}
	p.Base, p.ConditionSHA = filepath.Dir(full), expected
	if _, err = checkRef(FileRef{full, expected}, p.Base, p.Before); err != nil {
		return p, err
	}
	if err = readJSON(full, false, &p.Condition); err != nil {
		return p, err
	}
	c := p.Condition
	if c.Version != 1 || c.Trial != 108 || !c.Fixed || c.Scope == "" || c.Mode != "recorded_public_106" || c.Workers < 1 || c.Workers > 4 || !filepath.IsAbs(c.OwnModuleDir) || !reflect.DeepEqual(c.Configs, core.Configurations()) || len(c.Stops) != 6 || len(c.Specifications) != 2 || len(c.Code) == 0 {
		return p, fmt.Errorf("108の固定条件/12設定/worker/仕様参照差")
	}
	refs := append([]FileRef{c.PriorClosure, c.SourceManifest, c.SourceCorpus, c.SourceCompletion, c.PriorCompletion, c.PriorNativeIndex, c.Binary}, c.Stops...)
	refs = append(refs, c.Specifications...)
	for _, ref := range refs {
		if _, err = checkRef(ref, p.Base, p.Before); err != nil {
			return p, err
		}
	}
	pinned := map[string]string{}
	for name, h := range c.Code {
		var checked string
		if checked, err = checkRef(FileRef{name, h}, p.Base, p.Before); err != nil {
			return p, err
		}
		pinned[checked] = h
	}
	ownRoot, err := absolute(p.Base, c.OwnModuleDir)
	if err != nil {
		return p, err
	}
	stops := []string{}
	seenStop := map[string]bool{}
	for _, ref := range c.Stops {
		q, _ := absolute(p.Base, ref.Path)
		if seenStop[q] {
			return p, fmt.Errorf("停止参照の重複")
		}
		seenStop[q] = true
		stops = append(stops, q)
	}
	if err = verifyCodeScope(ownRoot, pinned, stops); err != nil {
		return p, err
	}
	exe, err := os.Executable()
	if err != nil {
		return p, err
	}
	actual, err := fileSHA(exe)
	if err != nil {
		return p, err
	}
	if actual != c.Binary.SHA {
		return p, fmt.Errorf("実行binaryが固定物と異なる")
	}
	var closed struct {
		Trial    int  `json:"試行"`
		Complete bool `json:"試行完了"`
	}
	closure, _ := absolute(p.Base, c.PriorClosure.Path)
	if err = readJSON(closure, false, &closed); err != nil {
		return p, err
	}
	if closed.Trial != 107 || !closed.Complete {
		return p, fmt.Errorf("旧107未完了")
	}
	manifest, _ := absolute(p.Base, c.SourceManifest.Path)
	if err = readJSON(manifest, false, &p.Manifest); err != nil {
		return p, err
	}
	source, _ := absolute(p.Base, c.SourceCompletion.Path)
	if err = readJSON(source, false, &p.Source); err != nil {
		return p, err
	}
	prior, _ := absolute(p.Base, c.PriorCompletion.Path)
	if err = readJSON(prior, false, &p.Prior); err != nil {
		return p, err
	}
	index, _ := absolute(p.Base, c.PriorNativeIndex.Path)
	if err = readJSON(index, false, &p.PriorIndex); err != nil {
		return p, err
	}
	p.PriorIndexRoot = filepath.Dir(filepath.Dir(index))
	if err = validateSources(&p); err != nil {
		return p, err
	}

	return p, nil
}

// verifyCodeScope は当CLIと各成功停止の所有集合の固定漏れを拒否します。
//
// 引数: ownRoot(string)、code(map[string]string)、stops([]string)は絶対配置・認証済みcode・成功停止pathです。
// 返り値: errorは自己又は停止所有の包含不足です。Go依存閉包の列挙はRoot固定helperが別途行います。
func verifyCodeScope(ownRoot string, code map[string]string, stops []string) error {
	for _, name := range []string{"io.go", "metadata.go", "case.go", "main.go", "io_test.go", "go.mod", "go.sum"} {
		if len(code[filepath.Join(ownRoot, name)]) != 64 {
			return fmt.Errorf("CLI自己包含不足:%s", name)
		}
	}
	repoRoot := filepath.Dir(filepath.Dir(ownRoot))
	for _, path := range stops {
		var stop struct {
			Success bool              `json:"成功"`
			Owned   map[string]string `json:"所有コードSHA256"`
		}
		if err := readJSON(path, false, &stop); err != nil {
			return err
		}
		if !stop.Success || len(stop.Owned) == 0 {
			return fmt.Errorf("成功停止/所有集合が必要:%s", path)
		}
		for name, want := range stop.Owned {
			p, err := absolute(repoRoot, name)
			if err != nil {
				return err
			}
			if len(want) != 64 || code[p] != want {
				return fmt.Errorf("停止所有の固定包含差:%s", p)
			}
		}
	}
	return nil
}

// readerRequest は106入力専用参照をpure readerの型へ明示変換します。
//
// 引数: p(Plan)、id(string)は固定計画と一場です。
// 返り値: reader.Requestは全Refを絶対pathへ束縛した読取要求です。
func readerRequest(p Plan, id string) reader.Request {
	return reader.Request{Manifest: readerRef(p.Base, p.Condition.SourceManifest), Corpus: readerRef(p.Base, p.Condition.SourceCorpus), Completion: readerRef(p.Base, p.Condition.SourceCompletion), SceneID: id}
}

// readerRef は認証済み参照をpure readerのFileRefへ対応させます。
//
// 引数: base(string)、ref(FileRef)はprepareで検査した基準と参照です。
// 返り値: reader.FileRefは絶対pathと同じSHAです。追加の読取はしません。
func readerRef(base string, ref FileRef) reader.FileRef {
	path, _ := absolute(base, ref.Path)
	return reader.FileRef{Path: path, SHA: ref.SHA}
}

// validateSources は106の保存入力と107の旧30分実績をmetadataだけで区別して結びます。
//
// 引数: p(*Plan)は固定参照を読んだ計画です。
// 返り値: errorは全70集合/時計列/正式Native台帳の不一致です。価格本文を読みません。
func validateSources(p *Plan) error {
	c, s, old, idx := p.Condition, p.Source, p.Prior, p.PriorIndex
	if c.SourceManifest.SHA != "902c6b5147763de172c0199f79b13cdc08f9a5636b05e0575f19bffd2da627e8" || c.SourceCorpus.SHA != "ca6206d47d36772fff84d230073bd4346b1e785d5b0bb98c565bafe6c92fb441" || c.SourceCompletion.SHA != "c1370aac63c1905f132237becd5d5bb37c6bd06e20b061800c9d0caa02a1769f" || c.PriorCompletion.SHA != "80faf888eda44badca7cdc0f5fb70aa7354b3dcc4c771411df18fe10409d3c01" || c.PriorNativeIndex.SHA != "4e6858a1107d2f910985c1833fc99e3cd60b6b06077e36fc65138a8fdaa650d2" {
		return fmt.Errorf("106保存入力又は107Q30保存参照の固定指紋差")
	}
	if s.Version != 1 || !s.Success || s.Trial != 106 || s.Stage != "full70" || s.Sessions != 70 || s.BooksPerScene != 20 || s.Books != 1400 || s.Error != "" || !s.Unchanged || len(s.Before) == 0 || !reflect.DeepEqual(s.Before, s.After) || s.ConditionSHA != reader.Condition106 || len(s.Results) != 70 || len(p.Manifest.Sessions) != 70 {
		return fmt.Errorf("106保存入力の全70成功metadata差")
	}
	if old.Version != 1 || old.Trial != 107 || !old.Success || old.Stage != "full70" || old.Sessions != 70 || old.Books != 1680 || old.BooksPerScene != 24 || !old.Unchanged || len(old.Before) == 0 || !reflect.DeepEqual(old.Before, old.After) || old.ConditionSHA != "4ab51b9fadc6745ac25597b09365062b629ce329e88507f261fbc0f0760cab97" || old.InputMode != "recorded_public_106" || old.SourceReexecuted || old.ChartsRecomputed || len(old.Results) != 70 {
		return fmt.Errorf("107Q30保存参照の全70成功metadata差")
	}
	if !idx.Success || idx.Trial != 107 || idx.Base != "trialdir" || idx.Sessions != 70 || idx.Books != 1680 || len(idx.Native) != 70 {
		return fmt.Errorf("旧107正式Native台帳差")
	}
	seen := map[string]bool{}
	valid := regexp.MustCompile(`^\d{4}-\d{2}-\d{2}_(Day|Night)$`)
	p.PriorNative = nil
	for i, scene := range p.Manifest.Sessions {
		r, o, n := s.Results[i], old.Results[i], idx.Native[i]
		if !valid.MatchString(scene.ID) || seen[scene.ID] || r.Session != scene.ID || o.Session != scene.ID || n.Session != scene.ID || r.Books != 20 || r.W0Books != 4 || o.Books != 24 || o.BaseBooks != 12 || r.Error != "" || o.Error != "" || n.Books != 24 || !n.SameBytes || n.Bytes <= 0 || n.SHA != o.Native.SHA || n.Original.SHA != o.Native.SHA || r.Header.SHA != o.Header.SHA || r.Records.SHA != o.Records.SHA {
			return fmt.Errorf("106入力/107Q30/indexの場集合/全SHA差:%s", scene.ID)
		}
		for _, ref := range []FileRef{{r.Native.Path, r.Native.SHA}, {r.Header.Path, r.Header.SHA}, {r.Records.Path, r.Records.SHA}, o.Native, o.Header, o.Records} {
			if !filepath.IsAbs(ref.Path) || len(ref.SHA) != 64 {
				return fmt.Errorf("場の絶対参照/宣言SHA差")
			}
		}
		if filepath.Clean(n.Original.Path) != filepath.Clean(o.Native.Path) {
			// 台帳の元参照はtrialdir基準なので同じ絶対pathへ解決して比較する。
			original, err := absolute(p.PriorIndexRoot, n.Original.Path)
			if err != nil || filepath.Clean(original) != filepath.Clean(o.Native.Path) {
				return fmt.Errorf("旧107台帳元参照差")
			}
		}
		native, err := absolute(p.PriorIndexRoot, n.Path)
		if err != nil || !filepath.IsLocal(n.Path) || filepath.Base(native) != scene.ID+".Native.json.gz" {
			return fmt.Errorf("旧107正式Native位置差")
		}
		p.PriorNative = append(p.PriorNative, FileRef{native, n.SHA})
		seen[scene.ID] = true
	}
	return nil
}
