# 108の保存入力再読とQ20市場外周

新module `quietguardcli108`。停止Reader `savedpublic107`埋込対応d478をそのまま使い、Source106の固定manifest902c/corpusca62/completionc137からTape/Header/保存Streamを再読する。新Q20の12冊だけを金融再生し、旧107Q30はcompletion80fafと正式Native台帳4e68を別の保存参照へ結ぶ。106入力の成功を108金融成功に代用しない。

条件は`version:1,trial:108,fixed:true,source_scope:'recorded_public_106'`、`configs`はCoreの12固定順、`workers:1..4`。入力は`source_manifest/source_corpus/source_completion`、旧実績は`prior_closure/prior_completion/prior_native_index`。`binary/code_sha256/own_module_dir/stops6/specifications2`も必須。全FileRefとcode path、条件path、`--first2`は絶対pathで渡す。Rootが後で全依存閉包と実行物を固定し、未固定雛形は実入力へ進めない。

正式Native台帳は`基準:trialdir`として107試行dirから解決し、70場のSession/順/SHA/元参照を107完了へ一致させる。旧107のHeader/records宣言SHAは106入力と一致させる。Native本体は実行時だけSHA認証してQ30生Book12/Width12/Early4を読む。旧Q30の状態や成績を新Q20へ転記せず、Raw未知fieldを全JSON SHAへ保持する。

各場は`LoadTape`→Core.NewCore→`ReplayRecords(core.Feed)`→Core.Finish。最大4独立worker、場の金融状態を共有せず、失敗後の未着手は中止し、出力はmanifest順に戻す。結果Nativeは新12冊と保存参照proof、Input/ReplayProof、condition SHA、由来を持つ。Source/Bank/Chart形成false、CMP再評価true、金融実行trueを区別する。

completionは`version/trial/stage/success/condition_sha256/sessions/books_per_scene(12)/books/results/before/after/unchanged/first2?/source_scope/workers`と形成/実行flags。resultsは`session/native/sidecar_header/sidecar_records/books(12)/prior_reference_books(12)/prior_native/prior_reference_unchanged/error?`。新規directoryとO_EXCLだけへ保存し、完結不足や入力変更を成功にしない。

`first2`24冊成功後、同条件`full70`840冊へ進む。先頭2のNative/Header/recordsと旧参照のSHAを継承し、新Fullの先頭2Native bytes一致を確認する。Root固定前の実市場body読取・金融実行は0。人工は小FileRef/JSON/所有code包含、Source106/旧107/indexの正接続型と拒否、RawMessageの未知field保持に限定する。停止型Coreの手製12冊成功と、実Readerからの市場接続成功は別の範囲である。

```powershell
& '<固定exeの絶対path>' --condition '<108条件の絶対path>' --condition-sha '<SHA>' --stage first2 --out '<新規先頭2dir>'
& '<同exeの絶対path>' --condition '<同条件の絶対path>' --condition-sha '<同SHA>' --stage full70 --out '<新規全70dir>' --first2 '<成功先頭2完了の絶対path>' --first2-sha '<そのSHA>'
```

Source/Raw/Bank再形成や旧30の市場再金融の口は追加していない。70場は既使用であり、quiet1200/1800や12費用政策を独立標本にしない。採用/研究目標/未見安定性を部品テストから主張しない。
