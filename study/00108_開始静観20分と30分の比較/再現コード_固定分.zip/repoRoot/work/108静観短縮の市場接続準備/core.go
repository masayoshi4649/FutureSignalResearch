package quietguardruntime108

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"reflect"

	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	oldtype "github.com/masayoshi4649/SessionTradeExecuter/minichart"
	finance "github.com/masayoshi4649/SessionTradeExecuter/miniquietlength108"
	chart "github.com/masayoshi4649/SessionTradeExecuter/publicchart"
	delivery "github.com/masayoshi4649/SessionTradeExecuter/publicdelivery"
	stream "github.com/masayoshi4649/SessionTradeExecuter/publicsidecar"
)

// Config は外policy名を金融の内Keyから分離します。
type Config struct {
	Candidate    string  `json:"candidate"`
	Timing       string  `json:"entry_timing"`
	Policy       string  `json:"protection_policy"`
	Slip         float64 `json:"slip_pts"`
	Delay        int     `json:"delay_seconds"`
	QuietSeconds int     `json:"quiet_seconds"`
}

// Control は旧107のQ30保存実物を期待値転記せず認証するための入力です。
// 旧JSONの未知fieldはRawMessageの全値SHAと旧Native参照へ保持します。
type Control struct {
	Kind          string                     `json:"kind"`
	HistoryClass  string                     `json:"history_class"`
	ReferencePath string                     `json:"reference_path"`
	ReferenceSHA  string                     `json:"reference_sha256"`
	Session       finance.Session            `json:"session"`
	Contract      string                     `json:"contract"`
	TapeSHA       string                     `json:"tape_canonical_sha256"`
	QuietSeconds  int                        `json:"quiet_seconds"`
	Books         map[string]json.RawMessage `json:"-"`
	WidthAudits   map[string]json.RawMessage `json:"-"`
	EarlyAudits   map[string]json.RawMessage `json:"-"`
}
type Counts struct {
	Records      int `json:"records"`
	Quotes       int `json:"quotes"`
	Forces       int `json:"forces"`
	Grids        int `json:"grids"`
	Publications int `json:"publications"`
	Three        int `json:"three_publications"`
	Resets       int `json:"resets"`
	RawBoards    int `json:"raw_boards"`
}

// PublicRoleCounts は費用policyで反復加算しない一公表の既知/成立件数です。
type PublicRoleCounts struct {
	MKnown int `json:"M_known"`
	MPass  int `json:"M_pass"`
	PKnown int `json:"P_known"`
	PPass  int `json:"P_pass"`
}
type PublicDiagnostics struct {
	New3               int              `json:"new_three"`
	CKnown             int              `json:"C_known"`
	CPass              int              `json:"C_pass"`
	Buy                PublicRoleCounts `json:"buy"`
	Sell               PublicRoleCounts `json:"sell"`
	NumericSeedCarried bool             `json:"numeric_seed_carried"`
}

// ReferenceProof はQ30を保存参照として示し、新Q20との成績同体を表しません。
type ReferenceProof struct {
	Kind          string            `json:"kind"`
	HistoryClass  string            `json:"history_class"`
	QuietSeconds  int               `json:"quiet_seconds"`
	Books         int               `json:"books"`
	WidthAudits   int               `json:"width_audits"`
	EarlyAudits   int               `json:"early_audits"`
	BookSHA       map[string]string `json:"book_full_json_sha256"`
	WidthSHA      map[string]string `json:"width_full_json_sha256"`
	EarlySHA      map[string]string `json:"early_full_json_sha256"`
	ReferencePath string            `json:"reference_path"`
	ReferenceSHA  string            `json:"reference_sha256"`
	TapeSHA       string            `json:"tape_canonical_sha256"`
	Scope         string            `json:"scope"`
}

// Result は停止金融全値を外policy/cost namespaceへ保存します。
type Result struct {
	Version           int                               `json:"version"`
	Trial             int                               `json:"trial"`
	Scope             string                            `json:"scope"`
	Session           finance.Session                   `json:"session"`
	Contract          string                            `json:"contract"`
	Configs           []Config                          `json:"configs"`
	Books             map[string]finance.ActualResult   `json:"books"`
	WidthAudits       map[string]finance.WidthBookAudit `json:"width_audits"`
	EarlyAudits       map[string]finance.EarlyBookAudit `json:"early_audits"`
	ClockAudits       map[string]finance.ClockBookAudit `json:"clock_audits"`
	Counts            Counts                            `json:"counts"`
	PublicDiagnostics PublicDiagnostics                 `json:"public_diagnostics"`
	GridTimes         []float64                         `json:"grid_times"`
	SkippedGrids      []float64                         `json:"skipped_grids"`
	PriorReference    ReferenceProof                    `json:"prior_reference"`
	TapeSHA           string                            `json:"tape_canonical_sha256"`
	TapeUnchanged     bool                              `json:"tape_unchanged"`
	SourceReexecuted  bool                              `json:"source_reexecuted"`
	ChartRecomputed   bool                              `json:"charts_recomputed"`
	BankRecomputed    bool                              `json:"bank_recomputed"`
	CMPRecomputed     bool                              `json:"cmp_recomputed"`
	Complete          bool                              `json:"complete"`
}

// Core は全原行Book copyを蓄積しない新Q20の12会計Sinkです。Source/Bankを形成しません。
type Core struct {
	input                    tape.Tape
	contract, scope, tapeSHA string
	control                  Control
	priorDigest              string
	priorProof               ReferenceProof
	configs                  []Config
	actors                   []*finance.ActualBook
	pipeline                 *delivery.Pipeline
	cursor                   int
	last                     map[string]int64
	counts                   Counts
	publicStats              PublicDiagnostics
	lastAt                   float64
	haveAt, rawAt            bool
	rawAll                   map[string]int64
	pendingReset             map[string]chart.Quote
	preRank                  int
	grids                    []float64
	afterEOF                 int
	eof                      bool
	failed                   error
	finished                 bool
}

// Configurations はQ0/Q1/QE各C0D0/C0D1/C5D0/C5D1を返します。
//
// 引数: なし。返り値: []Configは108計画の固定順12設定です。
func Configurations() []Config {
	out := []Config{}
	for _, p := range []struct{ name, timing, policy string }{{"Q0", "B5QD", "W0"}, {"Q1", "B5QD", "W1"}, {"QE", "B5QD", "E1"}} {
		for _, c := range []float64{0, 5} {
			for _, d := range []int{0, 1} {
				out = append(out, Config{p.name, p.timing, p.policy, c, d, 1200})
			}
		}
	}
	return out
}

// Key は内金融Keyを変更せず外policy/costだけを識別します。
//
// 引数: c(Config)は固定設定。返り値: stringはQ0_C0_D0等です。
func Key(c Config) string { return fmt.Sprintf("%s_C%.0f_D%d", c.Candidate, c.Slip, c.Delay) }

// BaseKey は旧107Q30保存参照の同名外Keyを返します。
//
// 引数: c(Config)は固定設定。返り値: stringはQ0/Q1/QE_C0_D0等です。
func BaseKey(c Config) string { return Key(c) }

// digestValue は保存可能な全値のJSON SHAを求めます。
//
// 引数: value(any)はSource/Tape/公開値。返り値: string/errorは全JSONのSHAです。
func digestValue(value any) (string, error) {
	b, e := json.Marshal(value)
	if e != nil {
		return "", e
	}
	h := sha256.Sum256(b)
	return hex.EncodeToString(h[:]), nil
}

// sameJSON は許容やfield除外なしで全公開値を比較します。
//
// 引数: a/b(any)は公開型。返り値: boolは全JSON同体です。
func sameJSON(a, b any) bool {
	x, e := json.Marshal(a)
	if e != nil {
		return false
	}
	y, e := json.Marshal(b)
	return e == nil && bytes.Equal(x, y)
}

// NewCore は同じ固定Source入力へ新Q20の12金融と旧107Q30保存参照を作ります。
//
// 引数: input(Tape)、contract/scope(string)、control(Control)は固定値と対照の由来です。
// 返り値: *Core/errorはSink又は未対応/不正指定です。FileRef実物の認証は外周の責務です。
func NewCore(input tape.Tape, contract, scope string, control Control) (*Core, error) {
	c := &Core{input: input, contract: contract, scope: scope, control: control, configs: Configurations(), pipeline: delivery.NewPipeline(), last: map[string]int64{}, rawAll: map[string]int64{}, pendingReset: map[string]chart.Quote{}, preRank: -1, grids: []float64{}}
	if input.Version != 1 || input.Scope == "" || scope == "" || contract == "" || !reflect.DeepEqual(input.Capabilities, tape.Capabilities()) {
		return nil, fmt.Errorf("固定Tape/明示scope/限月が必要")
	}
	previous := 0.0
	rank := map[string]int{"force": 0, "grid": 1, "quote": 2}
	previousRank := -1
	for i, e := range input.Events {
		r, ok := rank[e.Kind]
		if !ok || e.Ordinal != i+1 || math.IsNaN(e.At) || math.IsInf(e.At, 0) || e.At < previous || e.At == previous && r < previousRank {
			return nil, fmt.Errorf("Source Tape ordinal/位相差")
		}
		if e.At != previous {
			previousRank = -1
		}
		previous, previousRank = e.At, r
	}
	h, e := digestValue(input)
	if e != nil {
		return nil, e
	}
	c.tapeSHA = h
	c.priorProof, e = c.validateReference()
	if e != nil {
		return nil, e
	}
	c.priorDigest, e = digestValue([]any{control.Books, control.WidthAudits, control.EarlyAudits})
	if e != nil {
		return nil, e
	}
	for _, cfg := range c.configs {
		a := finance.ActorConfig{Policy: "P0", ActivationPolicy: finance.ActivationLD10, EntryTiming: cfg.Timing, USOpen: input.Session.USOpen, SlipPts: cfg.Slip, DelaySeconds: cfg.Delay}
		var b *finance.ActualBook
		if cfg.Policy == "E1" {
			a.ActivationPolicy = finance.ActivationPolicy(cfg.Policy)
			b, e = finance.NewEarlyBookWithQuiet(input.Session, a, contract, cfg.QuietSeconds)
		} else {
			b, e = finance.NewWidthBookWithQuiet(input.Session, a, cfg.Policy, contract, cfg.QuietSeconds)
		}
		if e != nil {
			return nil, e
		}
		c.actors = append(c.actors, b)

	}
	return c, nil
}

// fail は部分処理を成功へ補わず失敗を保持します。
//
// 引数: e(error)は原因。返り値: errorは同じ原因です。
func (c *Core) fail(e error) error { c.failed = e; return e }

// batches は全Deltaを変更せず108金融の名前付き外型へ対応します。
//
// 引数: in([]oldtype.NativeBatch)は固定復元列。返り値: []finance.NativeBatchは順序/nil/全値を保持します。
func batches(in []oldtype.NativeBatch) []finance.NativeBatch {
	if in == nil {
		return nil
	}
	n := make([]finance.NativeBatch, len(in))
	for i, b := range in {
		n[i] = finance.NativeBatch{Method: b.Method, Delta: b.Delta}
	}
	return n
}

// source は固定Tapeの次quote/Force/gridだけを同じ順で一度配送します。
//
// 引数: r(stream.Record)は対応済みの保存公開列。返り値: errorはSource結合/金融の不一致です。
func (c *Core) source(r stream.Record) error {
	if c.cursor >= len(c.input.Events) {
		return fmt.Errorf("Source Tapeより余剰配送")
	}
	event := c.input.Events[c.cursor]
	if event.Kind != r.Kind || event.At != r.At {
		return fmt.Errorf("Source Tape次ordinalとの種別/時計差:%d", event.Ordinal)
	}
	switch r.Kind {
	case "quote":
		if event.Quote == nil || r.Scalar == nil || !reflect.DeepEqual(*event.Quote, *r.Scalar) || event.Context != nil {
			return fmt.Errorf("固定Scalar11差")
		}
	case "force":
		if r.Force == nil || r.Force.TapeOrdinal != event.Ordinal || r.Force.At != event.At || event.Quote != nil || event.Context != nil {
			return fmt.Errorf("元Force ordinal/時計差")
		}
	case "grid":
		if r.Grid == nil || r.Grid.Legacy.At != event.At || r.Grid.Legacy.Scene.ID != c.input.Session.ID || r.Grid.Legacy.Scene.Contract != c.contract || r.Grid.Legacy.Scene.Start != c.input.Session.Start || event.Quote != nil || len(event.Methods)+len(event.NonEmpty) != 0 || event.Context != nil && event.Context.At != event.At {
			return fmt.Errorf("元5分grid差")
		}
	}
	if r.Kind == "grid" {
		for _, b := range c.actors {
			if e := b.OnEntryGrid(event.At); e != nil {
				return e
			}
		}
		c.grids = append(c.grids, event.At)
		c.counts.Grids++
	} else {
		full, e := tape.RestoreBatches(event, c.last)
		if e != nil {
			return e
		}
		before, e := digestValue(full)
		if e != nil {
			return e
		}
		n := batches(full)
		for _, b := range c.actors {
			if r.Kind == "quote" {
				e = b.OnNativeStep(event.Quote.Observation(), event.Quote.SourceLine, n)
			} else {
				e = b.OnNativeForce(event.At, n)
			}
			if e != nil {
				return e
			}
		}
		after, e := digestValue(full)
		if e != nil || before != after {
			return fmt.Errorf("共有Source通知を変更")
		}
		if r.Kind == "quote" {
			c.counts.Quotes++
		} else {
			c.counts.Forces++
		}
	}
	c.cursor++
	return nil
}
