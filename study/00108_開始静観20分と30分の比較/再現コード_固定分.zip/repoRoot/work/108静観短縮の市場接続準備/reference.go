package quietguardruntime108

import (
	"encoding/hex"
	"encoding/json"
	"fmt"

	finance "github.com/masayoshi4649/SessionTradeExecuter/miniquietlength108"
)

// validateReference は旧107Q30を新Q20の期待成績にせず保存参照として認証します。
//
// 引数: c(*Core)は固定TapeとRawMessage12/12/4を受け取った未運転Coreです。
// 返り値: ReferenceProof/errorは全JSON指紋と参照由来又は場/設定/構造差です。
// 未知fieldも生JSONから指紋化し、既知型へ変換した値だけを保存値に置き換えません。
func (c *Core) validateReference() (ReferenceProof, error) {
	r := c.control
	p := ReferenceProof{}
	if r.Kind != "provided_old107_q30" || (r.HistoryClass != "old_saved_70" && r.HistoryClass != "artificial") || r.ReferencePath == "" || r.QuietSeconds != 1800 || len(r.ReferenceSHA) != 64 || r.Contract != c.contract || !sameJSON(r.Session, c.input.Session) || r.TapeSHA != c.tapeSHA || len(r.Books) != 12 || len(r.WidthAudits) != 12 || len(r.EarlyAudits) != 4 {
		return p, fmt.Errorf("旧107Q30保存参照の由来/場/限月/Tape/12,12,4差")
	}
	if _, e := hex.DecodeString(r.ReferenceSHA); e != nil {
		return p, fmt.Errorf("旧107Q30参照SHA不正")
	}
	p = ReferenceProof{Kind: r.Kind, HistoryClass: r.HistoryClass, QuietSeconds: 1800, Books: 12, WidthAudits: 12, EarlyAudits: 4, ReferencePath: r.ReferencePath, ReferenceSHA: r.ReferenceSHA, TapeSHA: r.TapeSHA,
		BookSHA: map[string]string{}, WidthSHA: map[string]string{}, EarlySHA: map[string]string{}, Scope: "旧107Q30の認証済みNative参照と12Book/幅12/早期4の全JSON指紋。新Q20との成績同体や旧Q30の市場再金融を意味しない"}
	for _, cfg := range c.configs {
		k := BaseKey(cfg)
		book := finance.ActualResult{}
		width := finance.WidthBookAudit{}
		activation := finance.ActivationLD10
		if cfg.Policy == "E1" {
			activation = finance.ActivationE1
		}
		expected := finance.ActorConfig{Policy: "P0", ActivationPolicy: activation, EntryTiming: "B5QD", USOpen: c.input.Session.USOpen, SlipPts: cfg.Slip, DelaySeconds: cfg.Delay}
		inner := fmt.Sprintf("%s_B5QD_P0_C%.0f_D%d", activation, cfg.Slip, cfg.Delay)
		if !json.Valid(r.Books[k]) || json.Unmarshal(r.Books[k], &book) != nil || book.Key != inner || !sameJSON(book.Session, c.input.Session) || !book.Complete || !book.Finished || book.Failure != "" || !sameJSON(book.Config, expected) || !json.Valid(r.WidthAudits[k]) || json.Unmarshal(r.WidthAudits[k], &width) != nil || width.Policy != cfg.Policy || width.Contract != c.contract {
			return ReferenceProof{}, fmt.Errorf("旧107Q30のKey/場/設定/完結/幅差:%s", k)
		}
		var e error
		if p.BookSHA[k], e = digestValue(r.Books[k]); e != nil {
			return ReferenceProof{}, e
		}
		if p.WidthSHA[k], e = digestValue(r.WidthAudits[k]); e != nil {
			return ReferenceProof{}, e
		}
		if cfg.Policy == "E1" {
			early := finance.EarlyBookAudit{}
			if !json.Valid(r.EarlyAudits[k]) || json.Unmarshal(r.EarlyAudits[k], &early) != nil || early.Policy != finance.ActivationE1 {
				return ReferenceProof{}, fmt.Errorf("旧107Q30の早期audit差:%s", k)
			}
			if p.EarlySHA[k], e = digestValue(r.EarlyAudits[k]); e != nil {
				return ReferenceProof{}, e
			}
		}
	}
	return p, nil
}
