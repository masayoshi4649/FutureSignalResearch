package quietguardruntime108

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"testing"

	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	stream "github.com/masayoshi4649/SessionTradeExecuter/publicsidecar"
)

type fixture107 struct {
	Scope   string          `json:"scope"`
	Tape    tape.Tape       `json:"tape"`
	Header  stream.Header   `json:"header"`
	Records []stream.Record `json:"records"`
	Output  struct {
		Contract string                     `json:"contract"`
		TapeSHA  string                     `json:"tape_canonical_sha256"`
		Books    map[string]json.RawMessage `json:"books"`
		Width    map[string]json.RawMessage `json:"width_audits"`
		Early    map[string]json.RawMessage `json:"early_audits"`
	} `json:"output"`
}

// loadFixture は停止107の買売手製Tape/Streamと旧Q30保存値を読みます。
//
// 引数: t(*testing.T)、side(int)は検査器と買売符号です。
// 返り値: fixture107/Controlは手製入力とQ30の生JSON保存参照です。市場本文は読みません。
func loadFixture(t *testing.T, side int) (fixture107, Control) {
	t.Helper()
	name := fmt.Sprintf("quiet繰越_方向%d.json", side)
	want := map[int]string{1: "f22e1bdbebd190896d8b24d8c7c293b5229fc7ebbee949d70024474316bee5a3", -1: "e16ad7baa88c0fd53661ae2146ef1bb7fdd9ea1809ca1a48673fdd86a5fd68f9"}[side]
	p, _ := filepath.Abs(filepath.Join("..", "107見送り繰越の市場接続準備", "人工_停止版", name))
	b, e := os.ReadFile(p)
	if e != nil {
		t.Fatal(e)
	}
	h := sha256.Sum256(b)
	if hex.EncodeToString(h[:]) != want {
		t.Fatal("停止107人工SHA差")
	}
	f := fixture107{}
	if e = json.Unmarshal(b, &f); e != nil {
		t.Fatal(e)
	}
	c := Control{Kind: "provided_old107_q30", HistoryClass: "artificial", ReferencePath: p, ReferenceSHA: want, Session: f.Tape.Session, Contract: f.Output.Contract, TapeSHA: f.Output.TapeSHA, QuietSeconds: 1800, Books: map[string]json.RawMessage{}, WidthAudits: map[string]json.RawMessage{}, EarlyAudits: map[string]json.RawMessage{}}
	for _, cfg := range Configurations() {
		k := Key(cfg)
		c.Books[k], c.WidthAudits[k] = f.Output.Books[k], f.Output.Width[k]
		if cfg.Policy == "E1" {
			c.EarlyAudits[k] = f.Output.Early[k]
		}
	}
	return f, c
}

// cloneJSON は破損人工だけを独立値へ複製します。
//
// 引数: t(*testing.T)、v(T)は検査器と公開値です。
// 返り値: Tは元人工を変えない独立値です。
func cloneJSON[T any](t *testing.T, v T) T {
	t.Helper()
	b, e := json.Marshal(v)
	if e != nil {
		t.Fatal(e)
	}
	var out T
	if e = json.Unmarshal(b, &out); e != nil {
		t.Fatal(e)
	}
	return out
}

// TestQ20Only は買売各12冊が完結し、Q30を保存参照としてだけ保持することを確認します。
//
// 引数: t(*testing.T)、環境RUNTIME108_EXPORT(string)は検査器と任意の新規型export先です。
// 返り値: なし。自然Source形成/市場成績やQ20とQ30の同値を証明しません。
func TestQ20Only(t *testing.T) {
	for _, side := range []int{1, -1} {
		t.Run(fmt.Sprint(side), func(t *testing.T) {
			f, prior := loadFixture(t, side)
			c, e := NewCore(f.Tape, f.Output.Contract, "停止107の手製保存列へ新Q20のみ12冊を配送。旧Q30は保存参照", prior)
			if e != nil {
				t.Fatal(e)
			}
			r, e := Run(c, f.Records, f.Header)
			if e != nil {
				t.Fatal(e)
			}
			if !r.Complete || r.Trial != 108 || len(r.Books) != 12 || len(r.WidthAudits) != 12 || len(r.EarlyAudits) != 4 || len(r.ClockAudits) != 12 || r.PriorReference.QuietSeconds != 1800 || r.PriorReference.Books != 12 || r.SourceReexecuted || r.ChartRecomputed || r.BankRecomputed || !r.CMPRecomputed {
				t.Fatal("新12冊/保存参照/由来差")
			}
			shifted := 0
			for _, cfg := range r.Configs {
				k := Key(cfg)
				b := r.Books[k]
				if cfg.QuietSeconds != 1200 || cfg.Timing != "B5QD" || b.Config.EntryTiming != cfg.Timing || b.Totals.EntryQuantity == 0 || !b.Complete || !b.Finished || b.Totals.OpenBuy+b.Totals.OpenSell+b.Totals.PendingBuy+b.Totals.PendingSell != 0 {
					t.Fatal("Q20非0完結/設定差", k)
				}
				var old struct {
					Opportunities []struct {
						AssignedAt float64 `json:"assigned_at"`
					} `json:"entry_opportunities"`
				}
				if e = json.Unmarshal(prior.Books[k], &old); e != nil {
					t.Fatal(e)
				}
				if len(old.Opportunities) > 0 && len(b.EntryOpportunities) > 0 && b.EntryOpportunities[0].AssignedAt < old.Opportunities[0].AssignedAt {
					shifted++
				}
			}
			if shifted != 12 {
				t.Fatal("手製静観内出生のQ20割当が12冊へ渡っていない", shifted)
			}
			if dir := os.Getenv("RUNTIME108_EXPORT"); dir != "" {
				value := struct {
					Scope   string          `json:"scope"`
					Prior   Control         `json:"prior107_reference"`
					Tape    tape.Tape       `json:"tape"`
					Header  stream.Header   `json:"header"`
					Records []stream.Record `json:"records"`
					Output  Result          `json:"output"`
				}{r.Scope, prior, f.Tape, f.Header, f.Records, r}
				data, e := json.MarshalIndent(value, "", "  ")
				if e != nil {
					t.Fatal(e)
				}
				if e = os.MkdirAll(dir, 0755); e != nil {
					t.Fatal(e)
				}
				p := filepath.Join(dir, fmt.Sprintf("方向%d.json", side))
				file, e := os.OpenFile(p, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0644)
				if e != nil {
					t.Fatal(e)
				}
				_, e = file.Write(append(data, '\n'))
				closeError := file.Close()
				if e != nil || closeError != nil {
					t.Fatal(e, closeError)
				}
			}
		})
	}
}

// TestPriorReferenceGuards は新旧を混同するmetadataと保存参照の変更を拒否します。
//
// 引数: t(*testing.T)は手製破損の検査器です。
// 返り値: なし。未知fieldは拒否せず全JSON指紋へ保持します。
func TestPriorReferenceGuards(t *testing.T) {
	for _, name := range []string{"quiet", "session", "contract", "tape", "missing", "extra", "config"} {
		t.Run(name, func(t *testing.T) {
			f, c := loadFixture(t, 1)
			switch name {
			case "quiet":
				c.QuietSeconds = 1200
			case "session":
				c.Session.ID = "別場"
			case "contract":
				c.Contract = "別限月"
			case "tape":
				c.TapeSHA = "別Tape"
			case "missing":
				delete(c.Books, "Q0_C0_D0")
			case "extra":
				c.Books["B0_C0_D0"] = c.Books["Q0_C0_D0"]
			case "config":
				var obj map[string]json.RawMessage
				json.Unmarshal(c.Books["Q0_C0_D0"], &obj)
				obj["key"] = json.RawMessage(`"LD10_B5Q_P0_C0_D0"`)
				c.Books["Q0_C0_D0"], _ = json.Marshal(obj)
			}
			if _, e := NewCore(f.Tape, f.Output.Contract, "手製metadata破損", c); e == nil {
				t.Fatal("不正参照を受理")
			}
		})
	}
	f, c := loadFixture(t, 1)
	var obj map[string]json.RawMessage
	json.Unmarshal(c.Books["Q0_C0_D0"], &obj)
	obj["未知fieldの保持"] = json.RawMessage(`{"値":123}`)
	c.Books["Q0_C0_D0"], _ = json.Marshal(obj)
	r, e := NewCore(f.Tape, f.Output.Contract, "未知fieldを全JSON指紋へ保持", c)
	if e != nil {
		t.Fatal(e)
	}
	want, _ := digestValue(c.Books["Q0_C0_D0"])
	if r.priorProof.BookSHA["Q0_C0_D0"] != want {
		t.Fatal("未知fieldが指紋から脱落")
	}
	c.Books["Q0_C0_D0"] = json.RawMessage(`{}`)
	if _, e = Run(r, f.Records, f.Header); e == nil {
		t.Fatal("参照入力の実行中変更を見逃した")
	}
}
