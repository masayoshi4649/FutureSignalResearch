# 108のQ20市場Core準備

新規再生はQ0/W0、Q1/W1、QE/E1各C0D0/C0D1/C5D0/C5D1の12冊だけ。入口B5QD・私有quiet_seconds=1200を明示APIへ渡す。LD10/E1、幅、数量、費用、Source比例返済、Force、同原行禁止は停止Actorへ直接委ねる。旧107のQ30は保存参照であり、108で30分の市場再金融を行わない。

module/packageは`github.com/masayoshi4649/SessionTradeExecuter/quietguardruntime108`。`Configurations/Key/BaseKey`、`NewCore(Tape, contract, scope, Control)`→`Feed(publicsidecar.Record)`→`Finish(Header)`、小型人工向け`Run`、`SourceForces`を公開する。107停止4faのSource/Scalar11/全board/公表/reset/Force/grid/EOF配送とC/M/P再評価を同じ本文で再用し、Chart Bank・Raw・Sourceは形成しない。

`Control`は`provided_old107_q30`、history=`old_saved_70`又は人工、quiet1800、同Session/contract/TapeSHA、旧107正式Nativeのpath/SHAとRawMessageのBook12/Width12/Early4を受ける。既知Config/内Key/完結と幅/早期の政策を検査し、未知fieldを切り捨てず全JSON SHAへ含める。実行中のRaw入力変更も拒否する。

`Result.books/width_audits/early_audits/clock_audits`は新12/12/4/12。`prior_reference`は旧1800・12/12/4・元NativeFileRef・TapeSHA・各全JSON SHA・scopeを保持し、`All`や新旧成績同体の旗を持たない。旧全文は参照先で保持し新Nativeへ重複同梱しない。SHAはGo `json.Marshal(RawMessage)`の全値compact/HTML escapeに基づき、field除外を行わない。保存側は同じ規範で照合する。

人工は停止107の買売`quiet繰越`2器具をSHAで直接再用する。Source/価格/公表は手製であり自然形成の証明ではない。新Q20各12冊が非0・完結、12冊の割当が旧Q30より前になる接続を確認する。新20の金額を旧30へ一致させない。参照metadata7拒否、未知fieldの指紋保持、実行中変更拒否を確認する。実市場Record/Native本文は未読、Root金融固定前の市場実行は0。

型人工は`人工_停止版/方向±1.json`へ新規exportする。`prior107_reference.reference_path`は停止107手製fixtureであり、その`output`を旧Q30人工として別に読む。旧24冊を新artifactへ全件転記しない。新旧市場の性能、全原行の別engine金融照合、採用/目標達成はこの部品の成功範囲ではない。
