"""108 Core/市場外周の非市場人工とビルドを記録し、二つの停止を新規保存する。"""
from __future__ import annotations

import difflib
import hashlib
import json
import os
from pathlib import Path
import subprocess

OWN=Path(__file__).resolve().parent
ROOT=OWN.parents[1]
CLI=ROOT/'work/108市場の入出力準備'


def sha(path: Path) -> str:
    """
    機能: コード・停止metadata・手製型のSHAを得る。
    引数: path (Path) は許可された対象。
    返り値: str はSHA256。実市場の価格/Nativeには呼ばない。
    """
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


def write_new(path: Path, value: dict) -> None:
    """
    機能: 新規の由来/停止metadataを保存する。
    引数: path (Path)、value (dict) は出力先と内容。
    返り値: None。停止元や既存資料は上書きしない。
    """
    with path.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')


def protected() -> dict[str,str]:
    """
    機能: 旧Core/旧CLIと停止Actor/Readerの所有コードだけを前後照合へ束縛する。
    引数: なし。
    返り値: dict[str,str] は元pathと宣言済みSHA。市場bodyを列挙しない。
    """
    refs={'work/107見送り繰越の市場接続準備/停止.json':'4fa185cd5337a427352dd82af8eff81e1a09a263ec63ac45da98cb3f08ce7b62',
          'work/107市場の入出力準備_埋込対応/停止.json':'5f44836625c191bce9ec8836e58409183fe1869dd53437f25f000d7b62666885',
          'work/静観長を分ける保護会計/停止.json':'1a17e2cf0e2229d8256a10c326acf0deba9d753b1317f405fa1b63ca0c700b3d',
          'work/107保存公表の再読口_埋込対応/停止.json':'d47881a6381e88e0ef2121830c5015e9bbfaa580ed7aa865bd2c12aca767e892'}
    out={}
    for name,h in refs.items():
        p=ROOT/name
        assert sha(p)==h
        out[str(p)]=h
        v=json.loads(p.read_text(encoding='utf-8-sig'))
        assert v['成功'] is True
        for code,want in v['所有コードSHA256'].items():
            q=(ROOT/code).resolve();assert sha(q)==want;out[str(q)]=want
    for side in (1,-1):
        q=ROOT/f'work/107見送り繰越の市場接続準備/人工_停止版/quiet繰越_方向{side}.json'
        out[str(q)]=sha(q)
    return out


def run(args: list[str], where: Path, env: dict | None = None) -> dict:
    """
    機能: 非市場のGo検査又はビルド一件を実行する。
    引数: args (list[str])、where (Path)、env (dict|None) はコマンド・module・環境。
    返り値: dict はargv/終了code/標準出力。失敗は停止成功へ補わない。
    """
    p=subprocess.run(args,cwd=where,env=env,capture_output=True,text=True,encoding='utf-8',check=False)
    v={'argv':args,'cwd':str(where),'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
    assert p.returncode==0,v
    return v


def diff(old: Path, new: Path, names: list[str]) -> str:
    """
    機能: 旧停止からの本文差を読み取れるpatchへまとめる。
    引数: old/new (Path)、names (list[str]) は旧新moduleと対象名。
    返り値: str はunified diff。元ファイルを変更しない。
    """
    parts=[]
    for name in names:
        a=(old/name).read_text(encoding='utf-8').splitlines(keepends=True) if (old/name).exists() else []
        b=(new/name).read_text(encoding='utf-8').splitlines(keepends=True)
        parts.extend(difflib.unified_diff(a,b,fromfile=str((old/name).relative_to(ROOT)),tofile=str((new/name).relative_to(ROOT))))
    return ''.join(parts)


def main() -> None:
    """
    機能: 買売24非0型/metadata境界を最終確認しCore/CLIを停止する。
    引数: なし。実市場実行の口は呼ばない。
    返り値: None。新型exportと新exeだけを新workへ作成する。
    """
    assert not (OWN/'停止.json').exists() and not (CLI/'停止.json').exists()
    before=protected()
    for directory,old,names in [(OWN,ROOT/'work/107見送り繰越の市場接続準備',['core.go','feed.go','reference.go','core_test.go','go.mod','go.sum']),
                                (CLI,ROOT/'work/107市場の入出力準備_埋込対応',['io.go','metadata.go','case.go','main.go','io_test.go','metadata_test.go','go.mod','go.sum'])]:
        (directory/'差分.patch').write_text(diff(old,directory,names),encoding='utf-8')
    checks=[]
    env=os.environ.copy();env['RUNTIME108_EXPORT']=str(OWN/'人工_停止版')
    checks.append(run(['go','test','./...','-v','-count=1'],OWN,env))
    checks.append(run(['go','vet','./...'],OWN))
    checks.append(run(['go','build','./...'],OWN))
    checks.append(run(['go','test','./...','-v','-count=1'],CLI))
    checks.append(run(['go','vet','./...'],CLI))
    exe=CLI/'検査/静観短縮.exe';exe.parent.mkdir(parents=True,exist_ok=True)
    checks.append(run(['go','build','-o',str(exe),'.'],CLI))
    after={name:sha(Path(name)) for name in before};assert before==after
    unchanged_functions=['source','batches']
    old=(ROOT/'work/107見送り繰越の市場接続準備/core.go').read_text(encoding='utf-8')
    new=(OWN/'core.go').read_text(encoding='utf-8')
    import re
    for name in unchanged_functions:
        pattern=rf'(?ms)^func (?:\(c \*Core\) )?{name}\(.*?^}}'
        assert re.search(pattern,old).group()==re.search(pattern,new).group()
    a=(ROOT/'work/107見送り繰越の市場接続準備/feed.go').read_text(encoding='utf-8');b=(OWN/'feed.go').read_text(encoding='utf-8')
    for name in ['raw','Feed','Run','SourceForces']:
        pattern=rf'(?ms)^func (?:\(c \*Core\) )?{name}\(.*?^}}'
        assert re.search(pattern,a).group()==re.search(pattern,b).group()
    provenance={'scope':'停止107からの最小派生。新Q20だけ12冊再生、旧Q30は正式参照','旧停止と依存の前SHA256':before,'後SHA256':after,'前後不変':True,
                '配送本文同体':unchanged_functions+['raw','Feed','Run','SourceForces'],'手製型の元':'停止107 quiet繰越の買売2例','市場/Raw/Native/Record本文/Source/Bank形成':0}
    write_new(OWN/'由来.json',provenance)
    write_new(CLI/'由来.json',{'scope':'Source106と旧Q30実績107を分ける外周。市場未実行','旧CLI停止SHA256':before[str(ROOT/'work/107市場の入出力準備_埋込対応/停止.json')],'原停止/依存不変':True,'実Readerからの市場接続':'未実施'})
    own_names=['core.go','feed.go','reference.go','core_test.go','go.mod','go.sum','README.md','検査と停止を記録する.py','差分.patch','由来.json']
    cli_names=['io.go','metadata.go','case.go','main.go','io_test.go','metadata_test.go','go.mod','go.sum','README.md','条件の雛形.json','差分.patch','由来.json']
    owned=lambda base,names:{str((base/n).relative_to(ROOT)).replace('\\','/'):sha(base/n) for n in names}
    artificial={str(p.relative_to(ROOT)).replace('\\','/'):sha(p) for p in sorted((OWN/'人工_停止版').glob('*.json'))}
    assert len(artificial)==2
    q=OWN/'検査';q.mkdir(exist_ok=True)
    write_new(q/'Go確認.json',{'成功':True,'checks':checks,'市場実行':0})
    common={'成功':True,'市場/Raw/市場Native/市場Record本文/Source/金融市場実行':0,'旧停止/依存前後不変':True,'未実施':['実first2/全70市場接続','全市場別engine金融照合','採用/研究目標達成']}
    corestop={**common,'scope':'手製買売各12の新Q20だけを再生し、旧Q30はRaw保存参照','所有コードSHA256':owned(OWN,own_names),'直接依存SHA256':before,
              '人工型SHA256':artificial,'新Q20会計':24,'全非0完結':True,'旧Q30金融再実行':0,'参照metadata拒否':7,'未知field指紋保持/参照変更拒否':True,'Go確認SHA256':sha(q/'Go確認.json')}
    write_new(OWN/'停止.json',corestop)
    clistop={**common,'scope':'絶対Ref/Source106・prior107・正式index/first2→full70のI/O準備','所有コードSHA256':owned(CLI,cli_names),
             'Core停止':{'path':str(OWN/'停止.json'),'sha256':sha(OWN/'停止.json')},'直接依存SHA256':before,'実行物':str(exe),'実行物SHA256':sha(exe),
             'Go確認SHA256':sha(q/'Go確認.json'),'metadata正接続':True,'Source/prior/index拒否':10,'RawMessage投影/JSON/自己停止包含人工':True,'市場処理':'未実行'}
    write_new(CLI/'停止.json',clistop)
    print(json.dumps({'成功':True,'Core停止SHA256':sha(OWN/'停止.json'),'CLI停止SHA256':sha(CLI/'停止.json'),'実行物':str(exe),'実行物SHA256':sha(exe),'型人工':artificial},ensure_ascii=False))


if __name__=='__main__':
    main()
