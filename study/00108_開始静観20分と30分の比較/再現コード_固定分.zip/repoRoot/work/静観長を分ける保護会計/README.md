# 静観長を20/30分に分ける保護会計

108の人工接続用。module/packageは `github.com/masayoshi4649/SessionTradeExecuter/miniquietlength108` / `miniquietlength108`。元107は `../見送り繰越の保護会計/停止.json`（ed5e63ab…）へ固定し、一字も変更しない。本版は別namespaceで同時importできる。

[先に固定した仕様](仕様.md)のとおり、静観長だけをconstructorの私有状態へ設定する。ActorConfig、innerKey、ActualResult、Width/Early/ClockAuditのJSONへdurationを追加しない。候補Q0/Q1/QEと静観1200/1800の設定は外側Coreの正本へ記録する。Snapshot等の全公開型と処理口は107と同じ。

```go
NewWidthBookWithQuiet(session, cfg, "W0", contract, 1200)
NewWidthBookWithQuiet(session, cfg, "W1", contract, 1200)
NewEarlyBookWithQuiet(session, cfg, contract, 1200) // cfg.ActivationPolicy=E1
```

追加の `NewActualBookWithQuiet` は幅配送を持たないLD10専用口。新しい3constructorの最後の引数はint型の1200又は1800だけを許す。B5QD/P0・Gate/Harvest/Risk/Exit空・LD10又はE1、幅W0/W1だけに限定する。従来の `NewActualBook/NewWidthBook/NewEarlyBook` は1800既定とし、従来許可範囲を狭めない。

変更箇所は次だけ。

- package/module名と旧107対照・新純時計の依存参照。
- ActualBookに未公開の `quietSeconds` を一つ追加。未指定0は互換1800へ解決。
- `gridQuiet` の場開始/US開始に同じ固定秒数を使用。20分の理由は20分、1800の文字列は旧107と同体。
- 出生登録で新 `quietlength108.AssignQuietOnceWithDuration` を一度だけ呼ぶ。
- quietでの失効理由も同じ秒数を表示する。

Force、PのUS−900、Source状態/数量/返済予約、受理後0取得取消の永久lock、手数料、片側上限、strict後続正常行、D1、通常LD10/早期/狭幅/最低建値・非緩和は変更しない。quiet以外で失効した出生を次枠へ再査定しない。生存Sourceであっても一度の割当である。

`quiet_length_test.go` は旧107を別importし、Day/US、買売、W0/W1/E1、C0/C5/D0/D1の48手製系列で、互換既定・明示1800・旧107の全時点/最終Result/Width/Early/Clockを除外0で照合する。20と30に同じSource通知・気配を流す48組では、割当/取得時刻と取得価格が異なることを確認する。別にNight開始終了等号、Source予約/取消、気配未知、容量10、Force/P締切/EOF、受理lockを確認する。元107人工も複製し再検査する。

人工のSourceは旧手製通知器具であり、自然Sourceエンジンを実行していない。ATR/C/M/Pも型人工で、市場形成の証拠ではない。20分の市場収支、参加率、安定性、採用は未検証。Raw/CSV/Native/市場Recordは読まず、金融の市場実行も行わない。

検査・停止はこのdirの `検査と停止を記録する.py` が `go test -count=1 -json ./...` / `go vet ./...` / `go build ./...` を実行し、差分・元所有と新所有の前後指紋・ログを新規保存する。前段停止と旧107は不変。新Coreは本版の停止を固定してから別途接続する。
