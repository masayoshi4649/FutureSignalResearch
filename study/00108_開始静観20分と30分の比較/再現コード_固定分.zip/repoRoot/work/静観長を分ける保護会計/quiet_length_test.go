package miniquietlength108

import (
	"encoding/json"
	"fmt"
	"strings"
	"testing"

	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	old "github.com/masayoshi4649/SessionTradeExecuter/miniquietguard"
)

// lengthBook108 は新明示constructorだけで108の三保護を作ります。
//
// 引数: s(Session)、policy(string)、cost(float64)、delay/seconds(int)は手製場と設定です。
// 返り値: *ActualBook/errorはB5QDの独立Book又は設定不正です。
func lengthBook108(s Session, policy string, cost float64, delay, seconds int) (*ActualBook, error) {
	c := ActorConfig{Policy: "P0", EntryTiming: TimingQuietDeferred, ActivationPolicy: ActivationLD10, USOpen: s.USOpen, SlipPts: cost, DelaySeconds: delay}
	if policy == "E1" {
		c.ActivationPolicy = ActivationE1
		return NewEarlyBookWithQuiet(s, c, "手製限月", seconds)
	}
	return NewWidthBookWithQuiet(s, c, policy, "手製限月", seconds)
}

// oldBook108 は凍結107を別moduleの実公開APIから作ります。
//
// 引数: s(Session)、policy(string)、cost(float64)、delay(int)は共通手製条件です。
// 返り値: *old.ActualBook/errorは旧107の30分口座です。新Configへ偽装しません。
func oldBook108(s Session, policy string, cost float64, delay int) (*old.ActualBook, error) {
	c := old.ActorConfig{Policy: "P0", EntryTiming: old.TimingQuietDeferred, ActivationPolicy: old.ActivationLD10, USOpen: s.USOpen, SlipPts: cost, DelaySeconds: delay}
	if policy == "E1" {
		c.ActivationPolicy = old.ActivationE1
		return old.NewEarlyBook(s, c, "手製限月")
	}
	return old.NewWidthBook(s, c, policy, "手製限月")
}

// oldBatches108 は同じNativeDeltaをnil/順序/全fieldのまま旧107の外型へ渡します。
//
// 引数: in([]NativeBatch)は一度形成した手製通知。返り値: []old.NativeBatchは名前付き外型だけの変換です。
func oldBatches108(in []NativeBatch) []old.NativeBatch {
	if in == nil {
		return nil
	}
	out := make([]old.NativeBatch, len(in))
	for i, b := range in {
		out[i] = old.NativeBatch{Method: b.Method, Delta: b.Delta}
	}
	return out
}

// oldWidth108 は採否/公開時計/SHAを変えず旧107の幅公表型へ明示対応します。
//
// 引数: o(WidthObservation)は手製公表。返り値: old.WidthObservationは全field同値です。
func oldWidth108(o WidthObservation) old.WidthObservation {
	return old.WidthObservation{Session: o.Session, Contract: o.Contract, Side: o.Side, PublicationID: o.PublicationID, Ordinal: o.Ordinal, End: o.End, AvailableAt: o.AvailableAt, C: old.WidthTruth{Known: o.C.Known, Passed: valueCopy(o.C.Passed)}, M: old.WidthTruth{Known: o.M.Known, Passed: valueCopy(o.M.Passed)}, P: old.WidthTruth{Known: o.P.Known, Passed: valueCopy(o.P.Passed)}, FrameSHA: o.FrameSHA, ResultSHA: o.ResultSHA}
}

// lengthSession108 はDay開始とNight米国開始を同じ手製配送で確認する場を返します。
//
// 引数: night(bool)は米国quietの試験有無。返り値: Session,float64,stringは場/quiet起点/合法Source手法です。
func lengthSession108(night bool) (Session, float64, string) {
	s := session()
	if !night {
		return s, s.Start, "D164_15"
	}
	s.ID, s.Kind = "手製108_Night", "Night"
	s.Start += 8*3600 + 15*60
	s.End, s.ForceClose = s.Start+46800, s.Start+46200
	s.USOpen = s.Start + 19800
	return s, s.USOpen, "U165_03"
}

// Test108ThirtyExact は互換既定/明示1800/旧107の全時点・最終JSONを除外0で比較します。
//
// 引数: t(*testing.T)はDay/US・買売・三保護・全C/Dの人工です。
// 返り値: なし。ActualResult/Width/Early/Clockの四JSONを別々に比較し、Sourceは手製だけです。
func Test108ThirtyExact(t *testing.T) {
	points, finals := 0, 0
	for _, night := range []bool{false, true} {
		for _, side := range []int{1, -1} {
			for _, policy := range []string{"W0", "W1", "E1"} {
				for _, cost := range []float64{0, 5} {
					for _, delay := range []int{0, 1} {
						s, start, method := lengthSession108(night)
						b, err := quietBook(s, policy, TimingQuietDeferred, cost, delay)
						if err != nil {
							t.Fatal(err)
						}
						explicit, err := lengthBook108(s, policy, cost, delay, 1800)
						if err != nil {
							t.Fatal(err)
						}
						control, err := oldBook108(s, policy, cost, delay)
						if err != nil {
							t.Fatal(err)
						}
						compare := func() {
							for _, n := range []*ActualBook{b, explicit} {
								equal103(t, n.Snapshot(), control.Snapshot(), "108旧107全時点Result")
								equal103(t, n.WidthAudit(), control.WidthAudit(), "108旧107全時点Width")
								equal103(t, n.EarlyAudit(), control.EarlyAudit(), "108旧107全時点Early")
								equal103(t, n.ClockAudit(), control.ClockAudit(), "108旧107全時点Clock")
							}
							points++
						}
						src, index := newSource(), int64(0)
						feed := func(at, move float64, bad bool, news ...native.Signal) {
							o := observation(at, move, side, index, bad)
							line := index + 20
							index++
							for i := range news {
								if news[i].Action == "new" {
									var e sourceEvidence
									_ = json.Unmarshal(news[i].Evidence, &e)
									e.Method = "NK225_" + method
									news[i].Evidence, _ = json.Marshal(e)
								}
							}
							batch := src.step(stamp(o, line), news)
							batch.Method = method
							batches := []NativeBatch{batch}
							for _, n := range []*ActualBook{b, explicit} {
								if e := n.OnNativeStep(o, line, batches); e != nil {
									t.Fatal(e)
								}
							}
							if e := control.OnNativeStep(o, line, oldBatches108(batches)); e != nil {
								t.Fatal(e)
							}
							compare()
						}
						grid := func(at float64) {
							for _, n := range []*ActualBook{b, explicit} {
								if e := n.OnEntryGrid(at); e != nil {
									t.Fatal(e)
								}
							}
							if e := control.OnEntryGrid(at); e != nil {
								t.Fatal(e)
							}
							compare()
						}
						feed(start+601, 0, false, birth("30分対照", side, 6))
						feed(start+602, 0, false)
						grid(start + 900)
						grid(start + 1200)
						pub := widthObs(side, 1, start+1620, WidthTruth{})
						pub.Session = s.ID
						pub.PublicationID = WidthPublicationID(s.ID, "手製限月", pub.End)
						for _, n := range []*ActualBook{b, explicit} {
							if e := n.OnWidthObservation(start+1798, pub); e != nil {
								t.Fatal(e)
							}
						}
						if e := control.OnWidthObservation(start+1798, oldWidth108(pub)); e != nil {
							t.Fatal(e)
						}
						compare()
						feed(start+1799, 0, false)
						grid(start + 1800)
						feed(start+1800, 0, false)
						feed(start+1801, 0, false)
						feed(start+1802, 60, false)
						feed(start+1803, 60, false, closeSignal("部分", "玉-30分対照", side, 3))
						feed(start+1804, 60, false)
						batch := src.force(start + 1805)
						batch.Method = method
						batch.Delta.SourceLine = src.last.SourceLine
						batches := []NativeBatch{batch}
						for _, n := range []*ActualBook{b, explicit} {
							if e := n.OnNativeForce(start+1805, batches); e != nil {
								t.Fatal(e)
							}
						}
						if e := control.OnNativeForce(start+1805, oldBatches108(batches)); e != nil {
							t.Fatal(e)
						}
						compare()
						feed(start+1805, 0, true)
						feed(start+1806, 0, false)
						feed(start+1807, 0, false)
						z, e := control.Finish()
						if e != nil {
							t.Fatal(e)
						}
						for _, n := range []*ActualBook{b, explicit} {
							r, e := n.Finish()
							if e != nil || !r.Complete || r.Totals.EntryQuantity != 6 {
								t.Fatal("30完結", e)
							}
							equal103(t, r, z, "108旧107最終Result")
							equal103(t, n.WidthAudit(), control.WidthAudit(), "108旧107最終Width")
							equal103(t, n.EarlyAudit(), control.EarlyAudit(), "108旧107最終Early")
							equal103(t, n.ClockAudit(), control.ClockAudit(), "108旧107最終Clock")
						}
						finals++
					}
				}
			}
		}
	}
	t.Logf("既定1800/明示1800対旧107:全時点%d×2×四JSON、最終%d×2×四JSON、除外0", points, finals)
}

// Test108TwentyAcquisition は同じSource/気配で20分と30分の取得時計が変わることを確認します。
//
// 引数: t(*testing.T)はDay/US・買売・三保護・全費用遅延の人工です。
// 返り値: なし。quiet/AssignedAt/理由は20へ揃え、fillはstrict後原行を維持します。
func Test108TwentyAcquisition(t *testing.T) {
	finals := 0
	mirrors := map[string][2]ActualTotals{}
	for _, night := range []bool{false, true} {
		for _, side := range []int{1, -1} {
			for _, policy := range []string{"W0", "W1", "E1"} {
				for _, cost := range []float64{0, 5} {
					for _, delay := range []int{0, 1} {
						s, start, method := lengthSession108(night)
						h20 := newQuietHarness(t, s, policy, side, cost, delay)
						h30 := newQuietHarness(t, s, policy, side, cost, delay)
						var e error
						h20.book, e = lengthBook108(s, policy, cost, delay, 1200)
						if e != nil {
							t.Fatal(e)
						}
						h20.method, h30.method = method, method
						for _, h := range []*quietHarness{h20, h30} {
							h.quote(start+601, false, birth("20分差", side, 6))
							h.quote(start+602, false)
							h.grid(start + 900)
						}
						r := h20.book.Snapshot()
						a := h20.book.ClockAudit().Opportunities[0]
						if r.EntryOpportunities[0].Consumed || !r.GridTraces[0].QuietApplied || !strings.Contains(r.GridTraces[0].QuietReason, "20分") || a.StrictAt != start+900 || a.AssignedAt != start+1200 || a.QuietEnd != start+1200 || !strings.Contains(a.Reason, "20分") {
							t.Fatal("20分の半開静観と一回割当が不一致")
						}
						for _, h := range []*quietHarness{h20, h30} {
							h.quote(start+1199, false)
							h.grid(start + 1200)
							h.quote(start+1200, false)
						}
						if h20.book.Snapshot().GridTraces[1].Quiet || h20.book.Snapshot().EntryOpportunities[0].Requested != 6 || h30.book.Snapshot().EntryOpportunities[0].Consumed {
							t.Fatal("20終了/30継続境界差")
						}
						if (h20.book.Snapshot().Totals.EntryQuantity == 6) != (delay == 0) || h30.book.Snapshot().Totals.EntryQuantity != 0 {
							t.Fatal("strict同秒別row/D1の境界差")
						}
						for _, h := range []*quietHarness{h20, h30} {
							h.quote(start+1201, false)
							h.move = 10
							h.quote(start+1799, false)
							h.grid(start + 1800)
							h.quote(start+1800, false)
							h.quote(start+1801, false)
						}
						var totals [2]ActualTotals
						for i, h := range []*quietHarness{h20, h30} {
							result := h.finish(start + 1802)
							if result.Totals.EntryQuantity != 6 || len(result.Positions) != 1 {
								t.Fatal("20/30の非0完結差")
							}
							totals[i] = result.Totals
						}
						mirrorKey := fmt.Sprintf("%t_%s_%.0f_%d", night, policy, cost, delay)
						if side == 1 {
							mirrors[mirrorKey] = totals
						} else {
							equal103(t, totals, mirrors[mirrorKey], "20/30それぞれの買売鏡像Totals")
						}
						p20, p30 := h20.book.Snapshot().Positions[0], h30.book.Snapshot().Positions[0]
						if p20.EntryQuote.Time >= p30.EntryQuote.Time || p20.EntryPrice == p30.EntryPrice {
							t.Fatal("手製価格/同一Sourceで取得時計差を観測できない")
						}
						for _, h := range []*quietHarness{h20, h30} {
							z := h.book.Snapshot()
							for _, f := range z.Fills {
								o := z.Orders[h.book.orders[f.OrderID]]
								if f.Quote.Index <= o.RequestQuote.Index || f.Quote.Time < o.RequestTime+float64(delay) {
									t.Fatal("同原行/遅延前fill")
								}
							}
						}
						finals++
					}
				}
			}
		}
	}
	t.Logf("20/30の取得差: %d組、Day/US・買売・W0/W1/E1・全C/D、手製Sourceのみ", finals)
}

// Test108TwentyConstraints は20分へ替えてもSource/Force/P/EOF/受理lockを救済しないことを確認します。
//
// 引数: t(*testing.T)は最小の終端・未知・容量の手製器具です。
// 返り値: なし。正常な失効は一度だけ保存し、未観測gridを生成しません。
func Test108TwentyConstraints(t *testing.T) {
	for _, side := range []int{1, -1} {
		for _, scenario := range []string{"取消", "予約", "未知", "容量", "Force", "EOF", "lock"} {
			t.Run(fmt.Sprintf("方向%d_%s", side, scenario), func(t *testing.T) {
				s := session()
				g := s.Start + 1200
				if scenario == "Force" {
					s.ForceClose = g
				}
				h := newQuietHarness(t, s, "W0", side, 0, 1)
				var e error
				h.book, e = lengthBook108(s, "W0", 0, 1, 1200)
				if e != nil {
					t.Fatal(e)
				}
				if scenario == "容量" {
					h.quote(s.Start+1, false, birth("対象", side, 6), birth("二つ目", side, 6), birth("三つ目", side, 2))
				} else {
					h.quote(s.Start+1, false, birth("対象", side, 6))
				}
				if scenario == "取消" {
					h.force(s.Start + 2)
				} else {
					h.quote(s.Start+2, false)
				}
				if scenario == "予約" {
					h.quote(g-2, false, closeSignal("先予約", "玉-対象", side, 6))
				}
				if scenario == "未知" {
					h.quote(g-1, true)
				}
				if scenario == "EOF" {
					r := h.finish(s.Start + 3)
					if !strings.Contains(r.EntryOpportunities[0].Reason, "EOF") || len(r.GridTraces) != 0 {
						t.Fatal("未観測gridを補った")
					}
					return
				}
				if scenario == "Force" {
					h.force(g)
				}
				h.grid(g)
				r := h.book.Snapshot()
				i := 0
				if scenario == "容量" {
					i = 2
					if r.EntryOpportunities[1].Requested != 4 {
						t.Fatal("片側10を超えた")
					}
				}
				p := r.EntryOpportunities[i]
				want := map[string]string{"取消": "取消済み", "予約": "返済予約", "未知": "必要未知", "容量": "空きなし", "Force": "Force境界"}
				if !p.Consumed {
					t.Fatal("未消費")
				}
				if scenario == "lock" {
					if p.Requested != 6 {
						t.Fatal("受理前提不正")
					}
					h.force(g)
					if h.book.Snapshot().Orders[0].Status != "cancelled" {
						t.Fatal("未取得newを取消しない")
					}
				} else if p.Requested != 0 || !strings.Contains(p.Reason, want[scenario]) {
					t.Fatal("失効理由", p.Reason)
				}
				h.quote(g+1, false)
				h.grid(g + 300)
				if h.book.Snapshot().GridTraces[1].CandidateCount != 0 {
					t.Fatal("失効/lockを復活")
				}
				h.finish(g + 301)
			})
		}
	}
	// ----------------------------------------
	// 20分でもPのUS-900とstrict出生枠を変更しません。
	for _, side := range []int{1, -1} {
		s := session()
		s.ID, s.Kind, s.USOpen = "手製108P_Night", "Night", s.Start+7200
		h := newQuietHarness(t, s, "W0", side, 0, 0)
		var e error
		h.book, e = lengthBook108(s, "W0", 0, 0, 1200)
		if e != nil {
			t.Fatal(e)
		}
		h.method = "P164_06"
		h.quote(s.USOpen-901, false, birth("P締切", side, 2))
		h.force(s.USOpen - 900)
		h.grid(s.USOpen - 900)
		p := h.book.Snapshot().EntryOpportunities[0]
		if p.Requested != 0 || !strings.Contains(p.Reason, "Force境界") {
			t.Fatal("P締切を短縮静観で救済")
		}
		h.finish(s.USOpen - 899)
	}
}

// Test108DurationGuard は明示静観を1200/1800と今回のB5QD三政策に限定します。
//
// 引数: t(*testing.T)は設定人工です。返り値: なし。旧constructor許可範囲は変更しません。
func Test108DurationGuard(t *testing.T) {
	for _, seconds := range []int{-1, 0, 1199, 1201, 1799, 1801} {
		for _, p := range []string{"W0", "W1", "E1"} {
			if _, e := lengthBook108(session(), p, 0, 0, seconds); e == nil {
				t.Fatal("未比較秒数を受理", seconds)
			}
		}
	}
	c := ActorConfig{Policy: "P0", EntryTiming: "B5Q", ActivationPolicy: ActivationLD10}
	if _, e := NewWidthBookWithQuiet(session(), c, "W0", "手製限月", 1200); e == nil {
		t.Fatal("明示1200のB5Qを受理")
	}
	if _, e := NewWidthBook(session(), c, "W0", "手製限月"); e != nil {
		t.Fatal("旧B5Qを狭めた", e)
	}
	c.EntryTiming = TimingQuietDeferred
	for _, seconds := range []int{1200, 1800} {
		b, e := NewActualBookWithQuiet(session(), c, seconds)
		if e != nil || b.quietDuration() != seconds {
			t.Fatal("裸LD10明示constructor", e)
		}
	}
	if _, e := NewWidthBookWithQuiet(session(), c, "W2", "手製限月", 1200); e == nil {
		t.Fatal("未比較W2")
	}
	c.ActivationPolicy = ActivationE2
	if _, e := NewEarlyBookWithQuiet(session(), c, "手製限月", 1200); e == nil {
		t.Fatal("未比較E2")
	}
}
