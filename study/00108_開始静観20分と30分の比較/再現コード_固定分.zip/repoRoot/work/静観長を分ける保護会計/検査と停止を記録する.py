"""108の静観長Actorの非市場検査と由来・差分・停止を保存する。"""
from __future__ import annotations

import argparse
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

WORK = Path(__file__).resolve().parent
ROOT = WORK.parent.parent
OLD = ROOT / "work/見送り繰越の保護会計"
CLOCK = ROOT / "work/静観長を指定する入口時計"
OLD_SHA = "ed5e63ab27e1b9aaf4aa2c18f63cc0cd48f881ec9416a89002e90ce78651c2b9"


def sha(p: Path) -> str:
    """機能: 実bytesを指紋化する。引数p(Path)。返り値strはSHA256。"""
    return hashlib.sha256(p.read_bytes()).hexdigest()


def rel(p: Path) -> str:
    """機能: repo内位置を相対化する。引数p(Path)。返り値strは安全な元path。"""
    return p.relative_to(ROOT).as_posix()


def save(p: Path, v: object) -> None:
    """機能: 新規JSONだけ保存する。引数p(Path),v(object)。返り値なし。"""
    with p.open("x", encoding="utf-8", newline="\n") as f:
        f.write(json.dumps(v, ensure_ascii=False, indent=2) + "\n")


def stopped(folder: Path, expected: str) -> dict[str, str]:
    """機能: 元停止と所有全件を検査する。引数folder(Path),expected(str)。返り値dictは実指紋。"""
    p = folder / "停止.json"
    assert sha(p) == expected, p
    v = json.loads(p.read_text(encoding="utf-8"))
    assert v["成功"] is True
    owned = v.get("所有コードSHA256", v.get("所有SHA256"))
    assert isinstance(owned, dict) and owned
    actual = {k: sha(ROOT / k) for k in owned}
    assert actual == owned
    actual[rel(p)] = expected
    return actual


def main() -> None:
    """機能: 旧不変と固定clockを結び全非市場検査を停止する。引数CLIのみ。返り値なし。"""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--clock-stop-sha", required=True)
    args = parser.parse_args()
    if (WORK / "停止.json").exists() or (WORK / "検査").exists():
        raise RuntimeError("停止済/既存検査は上書きしない")
    old_before = stopped(OLD, OLD_SHA)
    clock_before = stopped(CLOCK, args.clock_stop_sha)
    changed = {"actual.go", "clock_assignment.go", "entry_grid.go"}
    mechanical = {}
    for p in sorted(OLD.glob("*.go")):
        q = WORK / p.name
        if p.name not in changed:
            assert q.read_bytes().replace(b"package miniquietlength108", b"package miniquietguard") == p.read_bytes(), p
            mechanical[p.name] = {"元SHA256": sha(p), "package置換後SHA256": sha(q)}
    patch = ""
    for p in sorted(WORK.glob("*.go")):
        base = OLD / p.name
        before = base.read_text(encoding="utf-8").splitlines(keepends=True) if base.exists() else []
        if base.exists():
            # package宣言だけの機械差を外し、金融機能差を読める形で保存する。
            after = p.read_text(encoding="utf-8").replace("package miniquietlength108", "package miniquietguard").splitlines(keepends=True)
        else:
            after = p.read_text(encoding="utf-8").splitlines(keepends=True)
        if before != after:
            patch += "".join(difflib.unified_diff(before, after, fromfile="旧107/" + p.name if base.exists() else "/dev/null", tofile="108/" + p.name))
    before = (OLD / "go.mod").read_text(encoding="utf-8").splitlines(keepends=True)
    after = (WORK / "go.mod").read_text(encoding="utf-8").splitlines(keepends=True)
    patch += "".join(difflib.unified_diff(before, after, fromfile="旧107/go.mod", tofile="108/go.mod"))
    (WORK / "機能差分.patch").write_text(patch, encoding="utf-8", newline="\n")
    assert (OLD / "go.sum").read_bytes() == (WORK / "go.sum").read_bytes()
    origin = {
        "元停止": {"path": rel(OLD / "停止.json"), "sha256": OLD_SHA},
        "純時計停止": {"path": rel(CLOCK / "停止.json"), "sha256": args.clock_stop_sha},
        "module": "github.com/masayoshi4649/SessionTradeExecuter/miniquietlength108",
        "package以外元Go本文同体": mechanical,
        "変更Go": sorted(changed),
        "Config/Key/ActualResult/Width/Early/ClockAuditの型変更": False,
        "新API": ["NewActualBookWithQuiet(session,cfg,quietSeconds int)", "NewWidthBookWithQuiet(session,cfg,policy,contract,quietSeconds int)", "NewEarlyBookWithQuiet(session,cfg,contract,quietSeconds int)"],
        "新規API限定": "B5QD/P0・LD10(W0/W1)又はE1・Gate/Harvest/Risk/Exit空、1200/1800秒のみ",
        "私有状態": "quietSeconds。旧constructorの未設定0は1800。外Core設定がdurationを記録する",
        "元から変更しない": ["Source全通知/所有/部分返済", "Force/P US-900/EOF", "可変数量/片側10/永久lock", "手数料38.5/仮定滑り/次正常D0D1", "LD10/早期/幅/非緩和"],
        "人工": "Source/Scalar/ATR/CMPは旧手製型器具。市場形成/自然Source鏡像ではない",
        "初回接続過程": "新純clock差替前の20人工は旧1800割当のままで不成立。差替後に初めて20/30境界が成立。旧API人工を補完/書換していない",
        "市場本文/Raw/CSV/Native/新Source/実金融": 0,
    }
    save(WORK / "由来.json", origin)
    owned = sorted(p for p in WORK.iterdir() if p.is_file())
    before = {rel(p): sha(p) for p in owned}
    logs = WORK / "検査"
    logs.mkdir()
    commands = {"test": ["go", "test", "-mod=readonly", "-count=1", "-json", "./..."], "vet": ["go", "vet", "-mod=readonly", "./..."], "build": ["go", "build", "-mod=readonly", "./..."]}
    exits = {}
    for name, argv in commands.items():
        run = subprocess.run(argv, cwd=WORK, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
        (logs / f"{name}.stdout.txt").write_bytes(run.stdout)
        (logs / f"{name}.stderr.txt").write_bytes(run.stderr)
        exits[name] = run.returncode
        if run.returncode != 0:
            raise RuntimeError(f"{name}: {run.stderr.decode('utf-8', errors='replace')}")
    events = [json.loads(s) for s in (logs / "test.stdout.txt").read_text(encoding="utf-8").splitlines() if s.startswith("{")]
    assert not any(e.get("Action") == "fail" for e in events)
    passed = [e["Test"] for e in events if e.get("Action") == "pass" and e.get("Test")]
    skipped = [e["Test"] for e in events if e.get("Action") == "skip" and e.get("Test")]
    after = {rel(p): sha(p) for p in owned}
    old_after, clock_after = stopped(OLD, OLD_SHA), stopped(CLOCK, args.clock_stop_sha)
    assert before == after and old_before == old_after and clock_before == clock_after
    proof = {"成功": True, "test/vet/build終了": exits, "top成功": len([n for n in passed if "/" not in n]), "全成功": len(passed), "skip": skipped,
             "108追加試験": [n for n in passed if n.startswith("Test108")], "108出力log": [e["Output"] for e in events if e.get("Test", "").startswith("Test108") and e.get("Action") == "output" and not e.get("Output", "").startswith(("===", "---"))],
             "所有前": before, "所有後": after, "旧107前": old_before, "旧107後": old_after, "clock前": clock_before, "clock後": clock_after, "前後不変": True,
             "ログSHA256": {rel(p): sha(p) for p in sorted(logs.iterdir())}, "市場本文/Raw/CSV/Native/新Source/実金融": 0}
    save(logs / "人工確認.json", proof)
    stop = {"成功": True, "scope": "108静観20/30の非市場Actor最小派生。市場成績未検証", "module": origin["module"], "package": "miniquietlength108",
            "所有コードSHA256": after, "元停止": origin["元停止"], "純時計停止": origin["純時計停止"], "人工確認": {"path": rel(logs / "人工確認.json"), "sha256": sha(logs / "人工確認.json")},
            "test/vet/build終了": exits, "旧全JSON対照": "既定1800/明示1800対旧107、Day/US×買売×W0/W1/E1×全C/D48系列。768全時点×2×四JSON/最終48×2×四JSON・除外0",
            "20/30取得差": "48組非0、同じ手製Source/気配・買売Totals鏡像。Night開始等号、Force/P/EOF/予約/未知/容量/永久lockも別人工",
            "Config/JSON追加": False, "旧停止/所有前後不変": True, "市場本文/Raw/CSV/Native/新Source/実金融": 0,
            "未実施": ["Rootの108Core/CLI接続", "実70場の20分収支/参加", "未使用期間の安定性/採用"]}
    save(WORK / "停止.json", stop)
    print(json.dumps({"停止": rel(WORK / "停止.json"), "SHA256": sha(WORK / "停止.json"), "top成功": proof["top成功"], "全成功": len(passed), "終了": exits}, ensure_ascii=False))


if __name__ == "__main__":
    main()
