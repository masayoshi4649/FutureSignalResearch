package miniquietlength108

import (
	"fmt"
	"reflect"
)

type widthPosition struct {
	State            WidthState
	Update           WidthUpdate
	ResetGeneration  int
	FirstNarrow      *MTMPoint
	FirstObservation *WidthObservation
	FirstCondition   WidthTruth
}
type widthBook struct {
	Policy, Contract              string
	Latest                        map[int]*WidthObservation
	Last                          map[int]*WidthObservation
	At                            float64
	HaveClock                     bool
	ResetGeneration               int
	ResetReason                   string
	Positions                     map[string]*widthPosition
	Observations, Resets, Updates int
	Activations                   map[string]EarlyActivationAudit
}

// WidthPositionAudit は会計JSONと別の一玉状態と初回狭幅根拠です。
type WidthPositionAudit struct {
	PositionID       string            `json:"position_id"`
	State            WidthState        `json:"state"`
	LastUpdate       WidthUpdate       `json:"last_update"`
	FirstNarrow      *MTMPoint         `json:"first_narrow"`
	FirstObservation *WidthObservation `json:"first_narrow_observation"`
	FirstCondition   WidthTruth        `json:"first_narrow_condition"`
}

// WidthBookAudit はActualResultへ追加しない読取専用auditです。
type WidthBookAudit struct {
	Policy       string               `json:"policy"`
	Contract     string               `json:"contract"`
	Observations int                  `json:"observations"`
	Resets       int                  `json:"resets"`
	Updates      int                  `json:"updates"`
	Positions    []WidthPositionAudit `json:"positions"`
}

// NewWidthBook は旧Config/Key/ActualResultを変えず幅政策を外側で設定します。
//
// 引数: session(Session)、cfg(ActorConfig)、policy/contract(string)は旧LD10設定とW0/W1/W2・限月です。
// 返り値: *ActualBook/errorは小派生会計又は未比較の組合せです。Sourceを形成しません。
func NewWidthBook(session Session, cfg ActorConfig, policy, contract string) (*ActualBook, error) {
	if (policy != "W0" && policy != "W1" && policy != "W2") || cfg.EntryTiming == TimingQuietDeferred && policy == "W2" || contract == "" || cfg.ActivationPolicy != ActivationLD10 || cfg.Policy != "P0" || !quietEntryTiming(cfg.EntryTiming) || cfg.GatePolicy != "" || cfg.HarvestPolicy != "" || cfg.RiskPolicy != "" || cfg.ExitPolicy != "" {
		return nil, fmt.Errorf("可変幅は元LD10/B5Q/P0・W0/W1/W2専用")
	}
	b, e := NewActualBook(session, cfg)
	if e != nil {
		return nil, e
	}
	b.widthBook = &widthBook{Policy: policy, Contract: contract, Latest: map[int]*WidthObservation{}, Last: map[int]*WidthObservation{}, Positions: map[string]*widthPosition{}}
	return b, nil
}

// OnWidthObservation は外部因果検査済みC/M/Pを保管し、MTM/起動/注文を作りません。
//
// 引数: at(float64)、o(WidthObservation)は利用可能になった時計と一方向の公開結果です。
// 返り値: errorは別場/限月/未来/逆順/同公表破損です。ObservedClock gateや指標形成は追加しません。
func (b *ActualBook) OnWidthObservation(at float64, o WidthObservation) error {
	if e := b.ready(); e != nil {
		return e
	}
	w := b.widthBook
	if w == nil {
		return fmt.Errorf("幅の外側設定がありません")
	}
	if e := validateWidthObservation(o); e != nil {
		return e
	}
	if !finiteActual(at) || at < b.lastEventAt || (w.HaveClock && at < w.At) || o.Session != b.result.Session.ID || o.Contract != w.Contract || o.AvailableAt > at || o.End > at {
		return fmt.Errorf("幅公表の時計/場/限月差")
	}
	prior := w.Last[o.Side]
	if prior != nil {
		if o.PublicationID == prior.PublicationID {
			if !reflect.DeepEqual(o, *prior) {
				return fmt.Errorf("同公表の内容変更")
			}
			w.At, w.HaveClock = at, true
			return nil
		}
		if o.End <= prior.End || o.Ordinal <= prior.Ordinal {
			return fmt.Errorf("旧公表の再送")
		}
	}
	c := valueCopy(o)
	w.Latest[o.Side] = &c
	w.Last[o.Side] = &c
	w.At, w.HaveClock = at, true
	w.Observations++
	return nil
}

// ResetWidthObservation は観測だけを失効し既存狭幅/峰/床を保持します。
//
// 引数: at(float64)、reason(string)はLast0/欠測等の外部出典付き失効です。
// 返り値: errorは逆順又は空理由です。過去公表の同ID再送を復活させません。
func (b *ActualBook) ResetWidthObservation(at float64, reason string) error {
	if e := b.ready(); e != nil {
		return e
	}
	w := b.widthBook
	if w == nil || reason == "" || !finiteActual(at) || at < b.lastEventAt || (w.HaveClock && at < w.At) {
		return fmt.Errorf("観測resetの外側設定/時計/理由が不正")
	}
	w.Latest = map[int]*WidthObservation{}
	w.At, w.HaveClock = at, true
	w.ResetGeneration++
	w.ResetReason = reason
	w.Resets++
	return nil
}

// widthForPosition はLD起動後の床計算へ選択幅だけを返します。
//
// 引数: p(*ActualPosition)、point(MTMPoint)は旧会計の実玉と同じ正常markです。
// 返り値: *float64/errorは旧2ATR/狭1ATR又は不整合です。起動/峰/床/注文の権威は旧会計です。
func (b *ActualBook) widthForPosition(p *ActualPosition, point MTMPoint) (*float64, error) {
	var normal *float64
	if p.ATR != nil {
		normal = widthPointer(p.ATR.Width)
	}
	w := b.widthBook
	if w == nil || w.Policy == "W0" {
		return normal, nil
	}
	if w.HaveClock && w.At > point.Quote.Time {
		return nil, fmt.Errorf("幅公表より前のmark")
	}
	ps := w.Positions[p.ID]
	if ps == nil {
		state, e := NewWidthState(w.Policy, b.result.Session.ID, w.Contract, p.Side, p.EntryPrice)
		if e != nil {
			return nil, e
		}
		ps = &widthPosition{State: state}
		w.Positions[p.ID] = ps
	}
	var atr *float64
	if p.ATR != nil {
		atr = widthPointer(p.ATR.Value)
	}
	in := WidthMark{At: point.Quote.Time, Sequence: ps.State.Sequence + 1, Mark: widthPointer(point.MarkPrice), LDActive: p.ProtectionActive, ATRLock: atr, Observation: w.Latest[p.Side]}
	if ps.ResetGeneration != w.ResetGeneration {
		in.ResetReason = widthPointer(w.ResetReason)
	}
	was := ps.State.Narrowed
	out, e := AdvanceWidth(ps.State, in)
	if e != nil {
		return nil, e
	}
	if !was && out.State.Narrowed {
		ps.FirstNarrow = widthPointer(valueCopy(point))
		ps.FirstObservation = valueCopy(out.State.Latest)
		ps.FirstCondition = valueCopy(out.Condition)
	}
	ps.State, ps.Update, ps.ResetGeneration = out.State, out, w.ResetGeneration
	w.Updates++
	return out.Width, nil
}

// checkWidthFloor は選択幅を入れた旧会計床と停止純state床の同じ算術を照合します。
//
// 引数: p(*ActualPosition)、floor(float64)は旧会計の当時床です。
// 返り値: errorは二つの権威を矛盾したまま進めることを拒否します。金額許容は追加しません。
func (b *ActualBook) checkWidthFloor(p *ActualPosition, floor float64) error {
	if b.widthBook == nil || b.widthBook.Policy == "W0" {
		return nil
	}
	ps := b.widthBook.Positions[p.ID]
	if ps == nil || ps.State.Floor == nil || *ps.State.Floor != floor || ps.State.Peak == nil || *ps.State.Peak != p.PeakGain {
		return fmt.Errorf("純幅stateと旧会計峰/床の差")
	}
	return nil
}

// finishWidthPosition は実返済済みの玉状態だけを終了します。
//
// 引数: p(*ActualPosition)は旧会計が数量0にした実玉です。
// 返り値: errorは終玉時計の不整合です。架空mark/約定は作りません。
func (b *ActualBook) finishWidthPosition(p *ActualPosition) error {
	if b.widthBook == nil || b.widthBook.Policy == "W0" {
		return nil
	}
	ps := b.widthBook.Positions[p.ID]
	if ps == nil || ps.State.Finished {
		return nil
	}
	if p.ClosedQuote == nil || ps.State.LastAt == nil || p.ClosedQuote.Time < *ps.State.LastAt {
		return fmt.Errorf("幅stateの実終玉出典がありません")
	}
	ps.State.Finished = true
	ps.State.LastAt = widthPointer(p.ClosedQuote.Time)
	ps.State.Sequence++
	return nil
}

// WidthAudit は旧Book JSONと独立した状態/初回狭幅出典を返します。
//
// 引数: ありません。
// 返り値: WidthBookAuditはpointer/sliceを共有しない読取値です。ActualResultを変更しません。
func (b *ActualBook) WidthAudit() WidthBookAudit {
	out := WidthBookAudit{Positions: []WidthPositionAudit{}}
	w := b.widthBook
	if w == nil {
		return out
	}
	out.Policy, out.Contract, out.Observations, out.Resets, out.Updates = w.Policy, w.Contract, w.Observations, w.Resets, w.Updates
	for _, p := range b.result.Positions {
		if ps := w.Positions[p.ID]; ps != nil {
			out.Positions = append(out.Positions, WidthPositionAudit{PositionID: p.ID, State: valueCopy(ps.State), LastUpdate: valueCopy(ps.Update), FirstNarrow: valueCopy(ps.FirstNarrow), FirstObservation: valueCopy(ps.FirstObservation), FirstCondition: valueCopy(ps.FirstCondition)})
		}
	}
	return out
}
