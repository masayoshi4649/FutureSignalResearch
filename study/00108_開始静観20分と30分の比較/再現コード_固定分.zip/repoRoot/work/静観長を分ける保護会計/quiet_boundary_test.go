package miniquietlength108

import (
	"strings"
	"testing"
)

// Test108NightStartAndEqual はNight開始とstrict枠が20分終了に等しい境界を確認します。
//
// 引数: t(*testing.T)は買売の手製Nightです。返り値: なし。US静観やP締切を場開始へ混同しません。
func Test108NightStartAndEqual(t *testing.T) {
	for _, side := range []int{1, -1} {
		s, _, _ := lengthSession108(true)
		g := s.Start + 1200
		h := newQuietHarness(t, s, "W0", side, 0, 0)
		var err error
		h.book, err = lengthBook108(s, "W0", 0, 0, 1200)
		if err != nil {
			t.Fatal(err)
		}
		h.method = "P164_06"
		h.quote(s.Start+901, false, birth("境界", side, 2))
		h.quote(s.Start+902, false)
		a := h.book.ClockAudit().Opportunities[0]
		if a.StrictAt != g || a.AssignedAt != g || a.Deferred || a.Reason != "" {
			t.Fatal("strict枠が20分終了に等しいときも繰越した")
		}
		inside, reason, us := h.book.gridQuiet(g - 1)
		if !inside || !strings.Contains(reason, "20分") || us == nil || *us {
			t.Fatal("Night開始20分直前の静観差")
		}
		inside, _, us = h.book.gridQuiet(g)
		if inside || us == nil || *us {
			t.Fatal("半開終了/米国quiet混同")
		}
		h.grid(g)
		h.quote(g, false)
		if h.book.Snapshot().Totals.EntryQuantity != 2 {
			t.Fatal("終了等号のP取得を拒否")
		}
		h.finish(g + 1)
	}
}
