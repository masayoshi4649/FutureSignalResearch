package quietlength108

import (
	"encoding/json"
	"math"
	"testing"

	old "github.com/masayoshi4649/SessionTradeExecuter/quietassignment"
)

// TestDefaultAndExplicit1800MatchOld は別namespaceの旧時計へ全公開値を対照します。
//
// 引数: t(*testing.T)はGo試験器です。
// 返り値: なし。時計の全JSON・エラーを確認し金融を実行しません。
func TestDefaultAndExplicit1800MatchOld(t *testing.T) {
	clocks := []SessionClock{
		{Kind: "Day", Start: clockAt(8, 45)},
		{Kind: "Night", Start: clockAt(17, 0), USOpen: clockAt(23, 30)},
		{Kind: "Night", Start: clockAt(17, 0), USOpen: clockAt(22, 30)},
		{Kind: "Night", Start: 3000, USOpen: 4200},
		{Kind: "Night", Start: 3100, USOpen: 5000},
	}
	count := 0
	for _, clock := range clocks {
		for _, anchor := range []float64{clock.Start, clock.USOpen} {
			if anchor == 0 {
				continue
			}
			for _, offset := range []float64{-300, -.25, 0, 300, 899.75, 900, 1199.75, 1200, 1499.75, 1500, 1799.75, 1800, 2100} {
				birth := anchor + offset
				want, wantErr := old.AssignQuietOnce(old.SessionClock(clock), birth)
				for _, explicit := range []bool{false, true} {
					got, err := AssignQuietOnce(clock, birth)
					if explicit {
						got, err = AssignQuietOnceWithDuration(clock, birth, 1800)
					}
					if (err == nil) != (wantErr == nil) || (err != nil && err.Error() != wantErr.Error()) {
						t.Fatalf("旧エラー差: %+v/%g: %v/%v", clock, birth, err, wantErr)
					}
					a, _ := json.Marshal(got)
					b, _ := json.Marshal(want)
					if string(a) != string(b) {
						t.Fatalf("旧全JSON差: %s/%s", a, b)
					}
					count++
				}
			}
		}
	}
	t.Logf("旧1800全JSON対照=%d", count)
}

// TestExplicit1200Boundaries は20分静観の半開端点とstrict次枠だけを確認します。
//
// 引数: t(*testing.T)はGo試験器です。
// 返り値: なし。売買・注文・Source状態は使いません。
func TestExplicit1200Boundaries(t *testing.T) {
	day := SessionClock{Kind: "Day", Start: clockAt(8, 45)}
	night := SessionClock{Kind: "Night", Start: clockAt(17, 0), USOpen: clockAt(23, 30)}
	summer := night
	summer.USOpen = clockAt(22, 30)
	cases := []struct {
		name     string
		clock    SessionClock
		birth    float64
		strict   float64
		assigned float64
		reason   string
	}{
		{"開始同秒", day, clockAt(8, 45), clockAt(8, 50), clockAt(9, 5), "セッション開始20分"},
		{"開始静観最後の内枠", day, clockAt(8, 55), clockAt(9, 0), clockAt(9, 5), "セッション開始20分"},
		{"出生が静観内でも割当は終端", day, clockAt(9, 0), clockAt(9, 5), clockAt(9, 5), ""},
		{"終端直前", day, clockAt(9, 5) - .25, clockAt(9, 5), clockAt(9, 5), ""},
		{"終端同秒", day, clockAt(9, 5), clockAt(9, 10), clockAt(9, 10), ""},
		{"旧30分内だが新20分外", day, clockAt(9, 10), clockAt(9, 15), clockAt(9, 15), ""},
		{"通常直前", day, clockAt(10, 0) - .25, clockAt(10, 0), clockAt(10, 0), ""},
		{"Night開始", night, clockAt(17, 0), clockAt(17, 5), clockAt(17, 20), "セッション開始20分"},
		{"冬US開始枠", night, clockAt(23, 25), clockAt(23, 30), clockAt(23, 50), "米国開始20分"},
		{"冬US同秒", night, clockAt(23, 30), clockAt(23, 35), clockAt(23, 50), "米国開始20分"},
		{"U開始出生の次枠が静観終端", night, clockAt(23, 45), clockAt(23, 50), clockAt(23, 50), ""},
		{"US終端同秒", night, clockAt(23, 50), clockAt(23, 55), clockAt(23, 55), ""},
		{"夏US開始枠", summer, clockAt(22, 25), clockAt(22, 30), clockAt(22, 50), "米国開始20分"},
		{"P締切をこの関数で変更しない", night, clockAt(23, 10), clockAt(23, 15), clockAt(23, 15), ""},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			got, err := AssignQuietOnceWithDuration(c.clock, c.birth, 1200)
			if err != nil || got.StrictAt != c.strict || got.AssignedAt != c.assigned || got.Reason != c.reason || got.Deferred != (c.strict != c.assigned) {
				t.Fatalf("20分割当差: %+v %v", got, err)
			}
			if got.Deferred && got.QuietEnd-got.QuietStart != 1200 {
				t.Fatalf("静観長差: %+v", got)
			}
		})
	}
}

// TestDurationScopeAndErrors は連続静観、一回変更、不正durationの境界を確認します。
//
// 引数: t(*testing.T)はGo試験器です。
// 返り値: なし。Force/EOF等は引数に無い旧責務のままです。
func TestDurationScopeAndErrors(t *testing.T) {
	for _, us := range []float64{3900, 4200} {
		got, err := AssignQuietOnceWithDuration(SessionClock{Kind: "Night", Start: 3000, USOpen: us}, 3000, 1200)
		if err != nil || got.AssignedAt != us+1200 || got.QuietEnd != us+1200 || got.Reason != "開始・米国の連続静観" {
			t.Fatalf("重複又は接続の和集合差: %+v %v", got, err)
		}
	}
	// ----------------------------------------
	// 非整列の繰越先が別quietへ入っても、元割当の検査一回だけで返します。
	got, err := AssignQuietOnceWithDuration(SessionClock{Kind: "Night", Start: 3100, USOpen: 4400}, 3200, 1200)
	if err != nil || got.AssignedAt != 4500 || got.QuietEnd != 4300 {
		t.Fatalf("二回変更が混入: %+v %v", got, err)
	}
	day := SessionClock{Kind: "Day", Start: 3000}
	for _, seconds := range []int{-1, 0, 600, 1199, 1201, 1500, 1799, 1801, 3600} {
		if _, err := AssignQuietOnceWithDuration(day, 3000, seconds); err == nil {
			t.Fatalf("不正静観長を受理: %d", seconds)
		}
	}
	for _, seconds := range []int{1200, 1800} {
		for _, birth := range []float64{math.NaN(), math.Inf(1), 0, math.MaxFloat64} {
			if _, err := AssignQuietOnceWithDuration(day, birth, seconds); err == nil {
				t.Fatalf("不正出生を受理: %d/%g", seconds, birth)
			}
		}
	}
}
