# 静観長を明示する純割当時計

旧 `work/quietだけ繰り越す入口時計`（停止2f5c731d、本文531b32e7）を変更せず、module `github.com/masayoshi4649/SessionTradeExecuter/quietlength108` / package `quietlength108` へ最小派生する。Source、金融、実価格データは読まない。

- `AssignQuietOnce(clock SessionClock, birth float64) (Assignment, error)` は旧既定1800秒と同一の返り値・JSON・理由を維持する。
- `AssignQuietOnceWithDuration(clock SessionClock, birth float64, quietSeconds int) (Assignment, error)` は明示1200又は1800秒だけを受ける。開始とNight米国静観に同じ長さを使用する。1200は理由を20分と記す。
- strict割当は `300*(floor(birth/300)+1)`。元割当先が半開静観内にある場合だけ、終了以上の最初の300秒格子へ一度変更する。重複・接する静観は和集合として扱う。
- `SessionClock` / `Assignment` は旧と同じfieldとJSON tagを保持する。売買側を引数に持たず、左右で同じ時計を使う。

適用はSource出生registerで一度だけ行う。Consumed/entryBySource、正数量受理後0取得取消も永久lock、Source取消/完結、Force、P締切、EOFは呼出Actorの旧優先規則を維持する。この純関数は救済・再試行・終端後grid生成を行わず、他の時計定数も変えない。

純関数は旧と同様に非整列の時計も計算できるため、繰越先が別静観へ入っても二回目は行わない。実Session.Start/USOpenの300秒整列検査は新Actor側の責務。静観短縮の参加・損益優位は未検証である。

## 非市場確認

`go test -v ./...`、`go vet ./...`、`go build ./...`。旧手製境界をpackage名だけ変更して保持し、旧moduleを別namespaceでimportする既定/明示1800全JSON対照、20分境界、夏冬US、半開終端、連続静観、無効durationを狭く確認する。旧moduleは試験の比較先だけであり、新純時計本体は標準ライブラリのみを使う。

停止は `python 確認して停止する.py`。由来・差分・確認・停止をこのworkへ保存し、旧所有コードと停止の前後不変を記録する。新試行固定や市場実行を兼ねない。
