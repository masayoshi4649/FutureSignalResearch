"""旧停止を保ち、静観長だけの小型派生を人工で停止する。"""

from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OLD = ROOT / "work/quietだけ繰り越す入口時計"
OLD_STOP_SHA = "2f5c731d056662d3bd1233a55fab2e1766551f29d106bde03ff894770b9e8e75"


def sha(path: Path) -> str:
    """
    機能: 小型コード又は停止metadataのbytes指紋を計算する。
    引数: path(Path)は既存ファイルの位置。
    返り値: strはSHA256の16進文字列。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path: Path, value: dict) -> None:
    """
    機能: 確認先の上書きを避け日本語JSONを新規保存する。
    引数: path(Path)、value(dict)は保存先と小型証拠。
    返り値: None。
    """
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def rel(path: Path) -> str:
    """
    機能: 所有コードの位置をrepo相対に統一する。
    引数: path(Path)はrepo配下の位置。
    返り値: strは区切りを統一した相対path。
    """
    return path.relative_to(ROOT).as_posix()


def main() -> None:
    """
    機能: 時計だけの人工・vet/buildと由来・前後不変を保存し停止する。
    引数: なし。旧2f5停止とこの所有dirを使用する。
    返り値: None。既存証拠、試験失敗又は旧停止差は例外にする。
    """
    for name in ("由来.json", "差分.patch", "確認.json", "停止.json"):
        if (HERE / name).exists():
            raise ValueError("既存証拠への上書き拒否: " + name)
    old_stop_path = OLD / "停止.json"
    assert sha(old_stop_path) == OLD_STOP_SHA
    old_stop = json.loads(old_stop_path.read_text(encoding="utf-8"))
    before = dict(old_stop["所有コードSHA256"])
    before[rel(old_stop_path)] = OLD_STOP_SHA
    assert all(sha(ROOT / p) == value for p, value in before.items())
    # ----------------------------------------
    # 旧の実装・既存人工・moduleについてだけ、許可した派生差を記録する。
    names = ("assignment.go", "assignment_test.go", "go.mod")
    patch = "".join("".join(difflib.unified_diff(
        (OLD / name).read_text(encoding="utf-8").splitlines(keepends=True),
        (HERE / name).read_text(encoding="utf-8").splitlines(keepends=True),
        fromfile=rel(OLD / name), tofile=rel(HERE / name))) for name in names)
    with (HERE / "差分.patch").open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(patch)
    old_test = (OLD / "assignment_test.go").read_text(encoding="utf-8")
    new_test = (HERE / "assignment_test.go").read_text(encoding="utf-8")
    assert new_test.replace("package quietlength108", "package quietassignment") == old_test
    save(HERE / "由来.json", {
        "確認日": "2026-11-09", "元停止": rel(old_stop_path), "元停止SHA256": OLD_STOP_SHA,
        "元コードSHA256": before, "module": "github.com/masayoshi4649/SessionTradeExecuter/quietlength108",
        "差分": ["package/module名", "既定APIを1800秒wrapperにする", "明示APIと1200/1800検査", "quiet長を共通引数へ・1200理由は20分", "旧試験のpackage名・旧比較用require/replace", "追加手製試験と説明・停止helper"],
        "旧手製試験はpackage名以外同体": True,
        "維持": ["strict次300秒格子", "静観半開・和集合・一回変更", "SessionClock/Assignmentの全fieldとJSON", "1800理由を含む全返り値", "Force/P/EOF/Source/ConsumedはAPI外"],
        "市場又は金融接続": False,
    })
    owned_names = (*names, "duration_test.go", "README.md", "確認して停止する.py", "由来.json", "差分.patch")
    own_before = {rel(HERE / name): sha(HERE / name) for name in owned_names}
    checks = []
    for argv in (("go", "test", "-v", "./..."), ("go", "vet", "./..."), ("go", "build", "./...")):
        run = subprocess.run(argv, cwd=HERE, text=True, encoding="utf-8", capture_output=True, check=False)
        checks.append({"argv": argv, "exit_code": run.returncode, "stdout": run.stdout, "stderr": run.stderr})
        if run.returncode:
            raise ValueError("純時計の確認失敗: " + repr(checks[-1]))
    after = {p: sha(ROOT / p) for p in before}
    own_after = {p: sha(ROOT / p) for p in own_before}
    assert before == after and own_before == own_after
    stdout = checks[0]["stdout"]
    assert "旧1800全JSON対照=234" in stdout
    save(HERE / "確認.json", {
        "成功": True, "scope": "1200/1800純時計の手製境界と旧1800全JSON比較・市場と金融は対象外",
        "Go確認": checks, "top成功": len(re.findall(r"^--- PASS:", stdout, re.M)),
        "sub成功": len(re.findall(r"^    --- PASS:", stdout, re.M)), "旧1800全JSON対照": 234,
        "旧所有SHA256前": before, "旧所有SHA256後": after,
        "所有SHA256前": own_before, "所有SHA256後": own_after, "前後不変": True,
        "Raw_CSV_Native_Source_金融実行": 0, "機会損失算出": False,
    })
    save(HERE / "停止.json", {
        "成功": True, "scope": "静観長を1200/1800で指定する純時計・非市場停止",
        "module": "github.com/masayoshi4649/SessionTradeExecuter/quietlength108", "package": "quietlength108",
        "公開API": ["AssignQuietOnce(SessionClock,float64)(Assignment,error)", "AssignQuietOnceWithDuration(SessionClock,float64,int)(Assignment,error)"],
        "既定秒": 1800, "明示許可秒": [1200, 1800], "元停止SHA256": OLD_STOP_SHA,
        "所有コードSHA256": own_after, "確認SHA256": sha(HERE / "確認.json"),
        "旧1800全JSON対照": 234, "旧所有前後不変": True,
        "市場読取実行": 0, "Source又は金融への接続": False,
        "留保": ["適用一回・永久lockとSource終端は呼出Actorの責務", "Force/P/EOFの旧優先は変更しない", "実Sessionの300秒整列検査はActor側", "20分短縮の参加・損益優位は未検証"],
    })
    print(json.dumps({"成功": True, "停止": str(HERE / "停止.json"), "停止SHA256": sha(HERE / "停止.json"), "コードSHA256": sha(HERE / "assignment.go")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
