module github.com/masayoshi4649/SessionTradeExecuter/quietlength108

go 1.23.0

require github.com/masayoshi4649/SessionTradeExecuter/quietassignment v0.0.0

replace github.com/masayoshi4649/SessionTradeExecuter/quietassignment => "../quietだけ繰り越す入口時計"
