// Package quietlength108 は出生後の割当時計だけを計算します。
// Source状態、売買側、金融、Consumed、再試行の状態は持ちません。
package quietlength108

import (
	"fmt"
	"math"
)

// SessionClock は静観区間の計算に必要な公開時計だけを指定します。
// KindはDay又はNight、Start/USOpenはUnix秒です。DayではUSOpenを使いません。
// Force、手法別締切、場末、実際に観測されたgridの上限は旧Actor側が判定します。
type SessionClock struct {
	Kind   string  `json:"kind"`
	Start  float64 `json:"start"`
	USOpen float64 `json:"us_open"`
}

// Assignment は一出生につき一度だけ保存する割当結果です。
// Deferredは静観による時計変更だけを示し、新規受付や実取得の成功を示しません。
type Assignment struct {
	StrictAt   float64 `json:"strict_at"`
	AssignedAt float64 `json:"assigned_at"`
	Deferred   bool    `json:"deferred"`
	QuietStart float64 `json:"quiet_start,omitempty"`
	QuietEnd   float64 `json:"quiet_end,omitempty"`
	Reason     string  `json:"reason,omitempty"`
}

type quietInterval struct {
	start, end float64
	reason     string
}

// AssignQuietOnce はstrict次5分枠を求め、静観内にある割当先だけを一度繰り越します。
//
// 引数:
//   - clock(SessionClock): 開始時計と、Nightで必須の既知の米国開始時計です。
//   - birth(float64): Sourceの元Signal出生Unix秒です。配送時刻に置換しません。
//
// 返り値:
//   - Assignment: 旧300*(floor(birth/300)+1)と、静観終了以上の最初の300秒格子です。
//   - error: 時計が非有限、非正、場種不正、Nightの米国時計が未知又は開始以前の場合です。
//
// 静観は開始[Start,Start+1800)とNightの[USOpen,USOpen+1800)です。
// 重なる又は接する静観は一つの連続区間として扱います。
// 二回目の繰越、Source救済、Consumed解除、終端後のgrid生成は行いません。
// 生まれた場への所属確認、Force/P締切/EOF及び一回採否は呼出側が旧規則で行います。
func AssignQuietOnce(clock SessionClock, birth float64) (Assignment, error) {
	return AssignQuietOnceWithDuration(clock, birth, 1800)
}

// AssignQuietOnceWithDuration は静観長を明示し、元割当先の静観だけを一度繰り越します。
//
// 引数:
//   - clock(SessionClock): 開始時計とNightで必須の米国開始時計です。
//   - birth(float64): Sourceの元Signal出生Unix秒です。
//   - quietSeconds(int): 開始と米国に共通の静観長で、1200又は1800だけを指定します。
//
// 返り値:
//   - Assignment: strict次5分枠と静観終了以上の最初の300秒格子です。
//   - error: duration不正又は旧関数と同じ時計不正です。
//
// Force/P締切/EOF、出生所属、Source取消、Consumedと永久lockは呼出側が維持します。
// 1800は旧理由を含む同一値、1200は理由だけ20分として返します。
func AssignQuietOnceWithDuration(clock SessionClock, birth float64, quietSeconds int) (Assignment, error) {
	if quietSeconds != 1200 && quietSeconds != 1800 {
		return Assignment{}, fmt.Errorf("静観長は1200又は1800秒だけを指定してください")
	}
	if (clock.Kind != "Day" && clock.Kind != "Night") || !finitePositive(clock.Start) || !finitePositive(birth) || math.IsNaN(clock.USOpen) || math.IsInf(clock.USOpen, 0) || clock.USOpen < 0 {
		return Assignment{}, fmt.Errorf("出生又は場時計が不正です")
	}
	if clock.Kind == "Night" && clock.USOpen <= clock.Start {
		return Assignment{}, fmt.Errorf("Nightの米国開始時計が未知又は開始以前です")
	}
	strict := 300 * (math.Floor(birth/300) + 1)
	if !finitePositive(strict) || strict <= birth {
		return Assignment{}, fmt.Errorf("strict次5分枠を表現できません")
	}
	duration := float64(quietSeconds)
	startReason, usReason := "セッション開始30分", "米国開始30分"
	if quietSeconds == 1200 {
		startReason, usReason = "セッション開始20分", "米国開始20分"
	}
	intervals := []quietInterval{{clock.Start, clock.Start + duration, startReason}}
	if clock.Kind == "Night" {
		us := quietInterval{clock.USOpen, clock.USOpen + duration, usReason}
		if us.start <= intervals[0].end {
			intervals[0].end = math.Max(intervals[0].end, us.end)
			intervals[0].reason = "開始・米国の連続静観"
		} else {
			intervals = append(intervals, us)
		}
	}
	// ----------------------------------------
	// 元割当先を一度だけ調べ、割当変更後に別の静観へ再試行しません。
	result := Assignment{StrictAt: strict, AssignedAt: strict}
	for _, interval := range intervals {
		if !finitePositive(interval.end) || interval.end <= interval.start {
			return Assignment{}, fmt.Errorf("静観終了時計を表現できません")
		}
		if strict >= interval.start && strict < interval.end {
			assigned := 300 * math.Ceil(interval.end/300)
			if !finitePositive(assigned) || assigned <= strict || assigned < interval.end {
				return Assignment{}, fmt.Errorf("静観終了後の5分枠を表現できません")
			}
			result.AssignedAt, result.Deferred = assigned, true
			result.QuietStart, result.QuietEnd, result.Reason = interval.start, interval.end, interval.reason
			return result, nil
		}
	}
	return result, nil
}

// finitePositive は時計が有限の正数かを検査します。
//
// 引数: value(float64)はUnix秒又は計算した時計です。
// 返り値: boolは有限かつ正の場合だけtrueです。
func finitePositive(value float64) bool {
	return !math.IsNaN(value) && !math.IsInf(value, 0) && value > 0
}
