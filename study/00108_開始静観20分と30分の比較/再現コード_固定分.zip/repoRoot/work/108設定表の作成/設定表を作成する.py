"""107の市場前版5表を保持し、108の20分静観12設定を未検証で記録する。"""

import hashlib
import json
from pathlib import Path
import re


ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "study/00107_見送り明けの初回取得と利益保護/原計画/設定と結果.md"
TARGET = ROOT / "study/00108_開始静観20分と30分の比較/設定と結果.md"


def catalogue(text: str) -> list:
    """機能: 55手法のID・教材・9尺度セルを元の順で取り出す。

    引数: text(str)はMarkdown設定表。
    返り値: list[list[str]]は55行11列。
    """
    return [[x.strip() for x in line.split("|")[1:-1]] for line in text.splitlines()
            if re.match(r"^\| (?:I|C|P|V|B|X|M|E)\d{2} \|", line)]


def main() -> None:
    """機能: 全汎用表と12設定を、売買実行前の状態で一度だけ保存する。

    引数: なし。固定107原計画だけを入力にする。
    返り値: None。価格・金融結果を読み込まない。
    """
    source = SOURCE.read_text(encoding="utf-8")
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == "3e7ac70a96567ad3025dda16d743498f41447e18015993d58ca5c89b2add1d16"
    prefix = source[source.index("# 手法と時間スケールの汎用表・版5"):source.index("## 設定明細（実行前）")]
    prefix = prefix.replace("R05〜12/R17〜24", "R05〜12").replace("R01〜24", "R01〜12")
    rows = []
    for line in source.splitlines():
        if re.match(r"^\| S(?:0[1-9]|10) \|", line):
            rows.append(line.replace("R01〜24", "R01〜12").replace("107市場未検証", "108市場未検証"))
    assert len(rows) == 10
    rows.extend([
        "| S11 | 3分収束C | 既知EMA8/21の絶対間隔が新確定3本で厳密連続縮小 | R05〜12 | 未検証・未知/同値は不成立 |",
        "| S12 | 3分勢いM | MACD12/26/9の方向s×Hist増分<0 | R05〜12 | 未検証・Cとの複合選別、単独効果にしない |",
        "| S13 | 公開構造P | pivot左2厳密/右2同値可、当足判定後登録、s×(Close−前公表L)<0 | 診断のみ | 入口/起動/幅の追加選別に使わない |",
    ])
    settings = [
        ("K01", "入力出典", "106保存公表/固定Source70場を停止readerで再用", "R01〜12", "Raw/Bank/Sourceを再形成しない"),
        ("K02", "形成QAの範囲", "106のsymmetric/legacy/default形成QAは履歴として参照", "出典のみ", "108の形成成功や利益証明に数えない"),
        ("K03", "元Source", "元の方向/ATR/帯/再試験/短秒/数量と二市場支持、ER<=0.3、L/H両成立は待機を維持", "R01〜12", "追加gate・独自再参加なし"),
        ("K04", "通常起動", "A=native ATR12固定Value、残玉1枚u円>=100×max(10,A)", "R01〜12", "A未知は保留、元損失退出は継続"),
        ("K05", "20分の新規時計", "B5QD strict次5分。開始/USの[開始,開始+1200)内の割当だけ終了へ一度繰越", "R01〜12", "開始09:05/17:20、US実時計+20分。非静観再試行なし"),
        ("K06", "追尾幅/床", "通常5ceil(2A/5)、狭幅max(5,5ceil(A/5))。W1/E1は既知C&Mで狭幅", "全12・狭幅R05〜12", "最低名目建値、前床以上、終玉まで非拡大、既予約返済優先"),
        ("K07", "商品/費用", "mini各側10枚上限/可変、100円pt、片道38.5円、C0/C5、D0/D1", "R01〜12", "同原行fill禁止。C5/D1は追加滑り/価格秒の仮定"),
        ("K08", "参加", "同枠実取得又は当時実保有。主7980/副7700、共通30分枠7840/7560も別記", "R01〜12", "最低25%/目標50%。US静観/未知/欠測は分母に残す"),
        ("K09", "早期起動", "E1=通常LD10 OR u>=100×max(10,0.5A)かつ既知C&M", "R09〜12", "通常同時成立を優先。Pは早期選別しない"),
        ("K10", "因果公表", "106のcold/carry/mask/rollと保存のpublication/Force/grid/raw順を維持", "R01〜12", "20分に合わせて未知を補完せず、Scalarから未保存指標を復元しない"),
        ("K11", "30分保存対照", "107 Q0/Q1/QE各4冊の全文は正式Native参照と全JSON SHAで認証", "12参照対", "新20金融との同体検査/旧成績転記/30分再金融ではない"),
        ("K12", "出生と実取得", "strict/繰越先/Source状態/受理/実fillを結ぶ。正数量受理後永久lock", "R01〜12", "割当時未知等の任意再試行なし。受理だけは参加ではない"),
    ]
    rows.extend("| " + " | ".join(item) + " |" for item in settings)
    evaluations = []
    for candidate, policy in [("Q0", "W0"), ("Q1", "W1"), ("QE", "E1")]:
        for cost, delay in [(0, 0), (0, 1), (5, 0), (5, 1)]:
            evaluations.append({"評価ID": f"R{len(evaluations)+1:02}", "candidate": candidate, "entry_timing": "B5QD", "protection_policy": policy,
                                "quiet_seconds": 1200, "slip_pts": cost, "delay_seconds": delay, "純額": None, "主参加率": None, "副参加率": None, "状態": "未検証"})
    output = "# 00108：設定と結果\n\n市場実行前・実績未検証。20分B5QDの3候補×4費用＝12設定、既使用70場840会計を予定する。30分対照は107の保存Q12で、新金融へ転記しない。\n\n" + prefix
    output += "## 設定明細（実行前）\n\n| 設定ID | 役割 | 閾値/内容 | 適用評価 | 状態 |\n| --- | --- | --- | --- | --- |\n" + "\n".join(rows) + "\n\n"
    output += "## 複合評価（未実行）\n\n| 評価ID | 候補 | 保護 | 静観秒 | 片道追加滑りpt | 追加価格秒 | 純額 | 主参加率 | 副参加率 | 状態 |\n| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |\n"
    output += "\n".join(f"| {e['評価ID']} | {e['candidate']} | {e['protection_policy']} | 1200 | {e['slip_pts']} | {e['delay_seconds']} | 未検証 | 未検証 | 未検証 | 未実行 |" for e in evaluations) + "\n"
    original, copied = catalogue(source), catalogue(output)
    assert len(copied) == 55 and all(len(r) == 11 for r in copied)
    assert [r[:2] for r in original] == [r[:2] for r in copied]
    assert not re.search(r"(?<![A-Za-z0-9])R(?:1[3-9]|2\d)(?!\d)", output)
    for url in re.findall(r"\]\(([^)]+)\)", output):
        if "://" not in url and not url.startswith("#"):
            assert (TARGET.parent / url.split("#")[0]).resolve().exists(), url
    with TARGET.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(output)
    config = Path(__file__).with_name("実行前設定.json")
    with config.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump({"試行": 108, "市場実行": False, "設定": evaluations}, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"55行9尺度": True, "S": 13, "K": 12, "R": 12, "市場実行": False, "設定表SHA256": hashlib.sha256(TARGET.read_bytes()).hexdigest()}, ensure_ascii=False))


if __name__ == "__main__":
    main()
