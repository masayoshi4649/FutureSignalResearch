"""旧107の所在を継承し、108の固定コード不足分だけをworkへ保存する。"""

from __future__ import annotations

from collections import Counter
from copy import deepcopy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import zipfile


WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
TRIAL = ROOT / "study/00108_開始静観20分と30分の比較"
PRIOR = ROOT / "study/00107_見送り明けの初回取得と利益保護/再現コードの所在.json"
CONDITION = TRIAL / "金融条件.json"
OUTPUT = ROOT / "work/108再現保存の固定分"
LIBRARY = ROOT / "work/107再現保存の準備/再現metadataを準備する.py"


def sha(path: Path) -> str:
    """機能: 再現コード又は小metadataの実指紋を得る。

    引数: path (Path) はコード、ZIP、条件又は索引。
    返り値: str はSHA256。Rawや金融Nativeの本文には使用しない。
    """
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write_new(path: Path, value: dict) -> None:
    """機能: 小metadataを新規先へ保存する。

    引数: path (Path)、value (dict) は新規保存先と内容。
    返り値: None。既存正本やZIPを上書きしない。
    """
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def main() -> None:
    """機能: 同SHA重複を避けて108の金融前固定コードを保存する。

    引数: なし。固定108条件・旧107閉鎖索引と新規work先を使う。
    返り値: None。金融・保存集計・Viewer・CSV・正式配置は実行しない。
    """
    assert not OUTPUT.exists()
    assert sha(CONDITION) == "0a2a70a4658800060ab4c22a29cdcf21e29a9e2d87f916b0d1c327bb8cf88bd6"
    assert sha(PRIOR) == "0f2984363c6ef177741a0a5b827f88f312a92946b1d151d586152219801d741a"
    assert sha(LIBRARY) == "c1b57d4135e17b721458f458d88fc33ed8a312678dac37158778c9264591d606"
    spec = importlib.util.spec_from_file_location("108固定コードの旧純所在", LIBRARY)
    library = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(library)
    library.TRIAL = TRIAL
    condition = json.loads(CONDITION.read_text(encoding="utf-8"))
    prior = json.loads(PRIOR.read_text(encoding="utf-8"))
    closure_path = Path(condition["prior_closure"]["path"])
    assert sha(closure_path) == condition["prior_closure"]["sha256"]
    closed = json.loads(closure_path.read_text(encoding="utf-8"))
    assert closed["試行"] == 107 and closed["試行完了"] and prior["成功"] and prior["試行"] == 107
    assert condition["fixed"] and condition["trial"] == 108 and len(condition["code_sha256"]) == 1050
    before = {str(p): sha(p) for p in (CONDITION, PRIOR, LIBRARY, closure_path, Path(__file__).resolve())}
    items, by_sha = {}, {}
    for old in prior["entries"]:
        item = deepcopy(old)
        item["location"] = library.inherited_location(old, prior, PRIOR)
        item["roles"] = list(item.get("roles", [])) + ["107閉鎖所在を継承"]
        items[str(Path(item["original_path"]).resolve())] = item
        if item["location"]["kind"] == "既存archive":
            by_sha.setdefault(item["SHA256"], item["location"])

    def add(path: Path, expected: str, role: str) -> None:
        """機能: 固定コード又は小metadataを所在へ追加する。

        引数: path (Path)、expected/role (str) は実位置・SHA・役割。
        返り値: None。巨大データや同pathの別内容を拒否する。
        """
        path = path.resolve()
        restored = library.OLD.restore(path)
        assert not path.is_relative_to(ROOT.parent / "JP_OSE_Data")
        assert sha(path) == expected
        if restored["root"] != "goRoot":
            assert path.suffix in library.OLD.CODE_SUFFIX | {".ps1", ".exe"}
            assert path.suffix == ".exe" or path.stat().st_size < 5_000_000
        before[str(path)] = expected
        if str(path) in items:
            assert items[str(path)]["SHA256"] == expected
            if role not in items[str(path)]["roles"]:
                items[str(path)]["roles"].append(role)
            return
        item = {"original_path": path.as_posix(), "SHA256": expected, "bytes": path.stat().st_size, "restore": restored, "roles": [role]}
        item["location"] = library.choose_location(item, by_sha)
        items[str(path)] = item

    for name, expected in condition["code_sha256"].items():
        add(Path(name), expected, "108金融前固定code")
    add(Path(condition["binary"]["path"]), condition["binary"]["sha256"], "108固定金融実行物・本文は外部参照")
    add(CONDITION, sha(CONDITION), "108金融条件")
    add(Path(__file__).resolve(), sha(Path(__file__).resolve()), "108固定コード保存の実処理")
    add(LIBRARY, sha(LIBRARY), "108固定コード保存の純所在依存")
    # ----------------------------------------
    # 旧ZIPのSHA/CRCと参照entryを検査し、不足分だけを新規ZIPへ保存する。
    archives = {}
    for item in items.values():
        location = item["location"]
        if location["kind"] == "既存archive":
            path = (TRIAL / location["archive"]["path"]).resolve()
            if path not in archives:
                assert sha(path) == location["archive"]["sha256"]
                before[str(path)] = location["archive"]["sha256"]
                archives[path] = []
            archives[path].append(item)
    for path, rows in archives.items():
        with zipfile.ZipFile(path) as archive:
            assert archive.testzip() is None
            cache = {}
            for item in rows:
                entry = item["location"]["entry"]
                assert library.OLD.safe(entry)
                if entry not in cache:
                    cache[entry] = hashlib.sha256(archive.read(entry)).hexdigest()
                assert cache[entry] == item["SHA256"]
    missing, new_by_sha = {}, {}
    for item in items.values():
        if item["location"]["kind"] == "新archive候補":
            entry = new_by_sha.setdefault(item["SHA256"], item["location"]["entry"])
            item["location"] = {"kind": "新archive", "entry": entry}
            missing.setdefault(entry, item)
    OUTPUT.mkdir(parents=True)
    target = OUTPUT / "再現コード_固定分.zip"
    with zipfile.ZipFile(target, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for entry, item in sorted(missing.items()):
            path = Path(item["original_path"])
            assert library.OLD.safe(entry) and item["restore"]["root"] != "goRoot" and path.suffix.lower() not in (".exe", ".gz", ".csv", ".xlsx", ".png")
            assert sha(path) == item["SHA256"]
            archive.write(path, entry)
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None and len(archive.namelist()) == len(set(archive.namelist())) == len(missing)
        assert all(hashlib.sha256(archive.read(entry)).hexdigest() == item["SHA256"] for entry, item in missing.items())
    after = {name: sha(Path(name)) for name in before}
    assert before == after
    entries = list(items.values())
    located = {str(Path(item["original_path"]).resolve()): item["SHA256"] for item in entries}
    assert all(located.get(str(Path(name).resolve())) == expected for name, expected in condition["code_sha256"].items())
    zip_ref = {"path": target.name, "sha256": sha(target), "bytes": target.stat().st_size}
    index = {"成功": True, "試行": 108, "phase": "fixed_code_only", "金融条件": {"path": str(CONDITION), "sha256": sha(CONDITION)}, "固定code数": 1050, "固定code所在欠落": 0, "全所在数": len(entries), "新ZIP": zip_ref, "新entry数": len(missing), "所在区分": dict(Counter(item["location"]["kind"] for item in entries)), "roots": prior["roots"], "Go環境": prior["Go環境"], "旧107所在SHA256": sha(PRIOR), "除外": prior["除外"] + ["108のCSV/金融結果/Viewer実取得は未追加"], "entries": entries, "入力SHA256前": before, "入力SHA256後": after, "前後不変": True, "金融Native/経済結果保存": False, "正式配置": False, "試行閉鎖": False}
    index_path = OUTPUT / "再現コードの所在_固定分.json"
    write_new(index_path, index)
    receipt = {"成功": True, "試行": 108, "phase": "fixed_code_only", "固定code数": 1050, "全所在数": len(entries), "固定code所在欠落": 0, "新entry数": len(missing), "CRC差": 0, "危険path": 0, "前後不変": True, "新ZIP": zip_ref, "索引SHA256": sha(index_path), "金融/CSV/Viewer/xlsx実行": 0, "正式配置": False}
    write_new(OUTPUT / "再現コード保存の確認_固定分.json", receipt)
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == "__main__":
    main()
