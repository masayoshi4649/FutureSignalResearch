"""108保存器の局所時計hookと非市場型人工の停止指紋を残す。"""

from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import sys


def sha(path):
    """
    機能: 小型コード・停止・手製器具の指紋を計算する。
    引数: path(Path)は明示した許可ファイル。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    """
    機能: 既存先を変更せず日本語JSONを新規保存する。
    引数: path(Path)、value(dict)は保存先と停止証拠。
    返り値: None。
    """
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def main():
    """
    機能: 固定元の不変と買売Core型の最小保存接続を確認して停止する。
    引数: なし。市場固定や実市場Nativeは使用しない。
    返り値: None。停止済み・旧SHA差・人工不成立は例外にする。
    """
    here = Path(__file__).resolve().parent
    root = here.parents[1]
    if (here / "停止.json").exists() or (here / "由来.json").exists():
        raise ValueError("既存停止へ上書きしない")
    spec = importlib.util.spec_from_file_location("108保存停止", here / "集計.py")
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    refs = {
        "work/107見送り繰越の保存準備/集計.py": m.PREVIOUS_SHA,
        "work/107見送り繰越の保存準備/停止.json": "8540d8372dc12ae75cc6f046d59443627f8e6707518c827b3f930019e2a9f2ee",
        "work/静観長を指定する入口時計/assignment.go": m.CLOCK_SHA,
        "work/静観長を指定する入口時計/停止.json": "a56f4c64aa96fccc8e40e04bd11a867e4d9cf3cbd7768e4943c7b0792b839da1",
        "work/静観長を分ける保護会計/停止.json": "1a17e2cf0e2229d8256a10c326acf0deba9d753b1317f405fa1b63ca0c700b3d",
        "work/108静観短縮の市場接続準備/停止.json": "24bb58aabb761e85b7484511108cbb06b8d9feabd8588f1bab81ba717943040d",
        "work/108市場の入出力準備/停止.json": "1de300b09a79549b35cad34d68c02a1cf2e72f974c6c5ee2d555e16dc3702f42",
    }
    for module in (m.SAVED, m.SAVED.PREVIOUS, m.SAVED.PREVIOUS.BASE, m.OLD, m.PREVIOUS.GRID, m.BASE, m.SAVED.PUBLIC, m.SAVED.PUBLIC.pure):
        p = Path(module.__file__).resolve()
        refs[p.relative_to(root).as_posix()] = sha(p)
    # ----------------------------------------
    # 元停止の所有mapを先後に確認する。コードの指紋だけを読み市場入力は開かない。
    for name, expected in list(refs.items()):
        if sha(root / name) != expected:
            raise ValueError("固定参照SHA差:" + name)
        if name.endswith("/停止.json"):
            value = json.loads((root / name).read_text(encoding="utf-8"))
            for n, h in value.get("所有コードSHA256", {}).items():
                if sha(root / n) != h:
                    raise ValueError("旧所有SHA差:" + n)
                refs[n] = h
    before = {name: sha(root / name) for name in refs}
    hooks = {"旧107直import": True, "旧時計の1800定数3使用箇所と2理由": "1200秒/20分へ別code object",
             "旧95quietの1800定数4使用箇所": "1200秒へ別code object", "失効理由": "20分へ1文字列",
             "参加下端": "Start+1800の1箇所だけStart+1200へAST変更、副表End−1800は維持",
             "共通30": "旧参加関数を無改変再用", "金融/所有/費用/MTM/DD/幅/起動": "旧code object無改変",
             "元module変更": False}
    write(here / "由来.json", {"確認日": "2026-11-09", "元保存器": str(m.PREVIOUS_PATH.relative_to(root)), "元SHA256": m.PREVIOUS_SHA,
        "hook": hooks, "再用SHA256": before, "旧30": "旧107Q12を保存再検算・市場再金融0・新20同体要求0",
        "比較": {"静観長": 12, "20分内保護": 12}, "市場本文読取": 0})
    owned = {str((here / name).relative_to(root)).replace("\\", "/"): sha(here / name)
             for name in ("集計.py", "人工検査.py", "README.md", "停止を記録する.py", "由来.json")}
    run = subprocess.run([sys.executable, str(here / "人工検査.py"), str(here / "人工_停止版")], cwd=root,
                         text=True, encoding="utf-8", capture_output=True, check=False)
    if run.returncode:
        raise ValueError("保存人工失敗: " + run.stdout + run.stderr)
    proof_path = here / "人工_停止版/人工確認.json"
    proof = m.load(proof_path)
    if not proof["成功"] or proof["会計"] != 24 or proof["旧保存再検算"] != 24 or proof["非0会計"] != 24 or len(proof["破損拒否"]) != 7 or len(proof["metadata拒否"]) != 4:
        raise ValueError("保存人工scope差")
    after = {name: sha(root / name) for name in before}
    if before != after or owned != {n: sha(root / n) for n in owned}:
        raise ValueError("旧所有又は新所有の前後差")
    write(here / "停止.json", {"成功": True, "scope": "新20分12保存検算/旧30分保存参照12・24実額比較・共通30参加・Viewer型の非市場準備",
        "所有コードSHA256": owned, "再用コードと停止SHA256": before,
        "人工": {"path": str(proof_path.relative_to(root)).replace("\\", "/"), "SHA256": sha(proof_path), "新会計": 24, "旧保存再検算": 24, "Viewer形式": 12, "比較": 24, "破損拒否": 7, "metadata拒否": 4},
        "型人工集計SHA256": sha(here / "人工_停止版/型人工の集計.json"), "局所hook": hooks,
        "主/副/共通30主/共通30副": [7980, 7700, 7840, 7560],
        "旧所有SHA256前": before, "旧所有SHA256後": after, "前後不変": True,
        "市場本文_Raw_Record_金融再実行_HTTP": 0,
        "市場CLI": "python work/108静観短縮の保存準備/集計.py --fixed <Root3Ref固定JSON> --fixed-sha <SHA> --out <未使用dir>",
        "留保": "手製Sourceの買売2型だけ。新20と旧30同体/自然Source形成/全quote別engine再生/参加又は収益の優位は未検証"})
    print(json.dumps({"成功": True, "停止SHA256": sha(here / "停止.json"), "保存器SHA256": sha(here / "集計.py"), "人工確認SHA256": sha(proof_path)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
