# 108の20分静観と30分保存対照

新Q0/Q1/QE×C0/C5×D0/D1の12冊を検算する保存器。固定107 `edbc322b…` を直接importし、106/103/95/94の所有・費用・部分返済・全実約定・保存MTM/DD・起動/幅の規範を再用する。旧停止、Actor、Core、CLIは変更しない。

別namespaceで変えるのは、独立割当式のquiet長1800→1200と20分理由、grid quiet長、失効理由、参加関数のStart下端のみ。ActualResultの実Config/内Key B5QD・LD10/E1は原値を検査し、B5Qや旧policyへ偽装しない。金額・BBO・数量・Index/物理行・時計の比較許容は広げない。ATR等の旧IEEE境界は旧保存算術のまま。

主表 `[Start+1200,ForceClose)` は全70で7980枠、副表 `[Start+1200,End−1800)` は7700枠。新20分運転の共通30枠は旧 `participation` をそのまま呼び主7840/副7560を併記する。USquiet・欠測は分母に残す。場別はcounts-only、率/25%/50%は集約時に算出する。保留・受理・後の実取得を別にし、遅いfillを元枠の参加に戻さない。

旧107Q30は正式Native参照の12Book/Width12/Early4を旧107 `verify_book` へ原値で再検算する。旧30は再金融せず、新20と同体成功flagも作らない。全JSON SHAは元JSONの数値lexeme・field順・未知field・escapeを保持し、Go RawMessageのcompact/標準HTMLescapeと同じ指紋へ結ぶ。新旧が必要とする保存mark時刻を一つの公表registryへ集め、同じ保存公表列を一度だけ読戻す。公表済C/M/Pの再評価と全quote別engine金融再生は区別する。

比較正本欄は `同実入口と実現額差`。`20分_Q0_C0_D0対30分_Q0_C0_D0` 等の静観長12と、`20分_Q1_C0_D0対20分_Q0_C0_D0` 等の20分内保護3対×4の12、計24を保存する。固定103のSourceIdentity全文・実要求/実取得の全属性を使い、同実入口退出差、取得変更、片側実参加を実現額だけで加法分解する。未参加/退出後価格・機会損失・MFE・元手不明ROIは算出しない。

## 実行口

```powershell
python 'work/108静観短縮の保存準備/集計.py' --fixed '<固定JSON絶対path>' --fixed-sha '<SHA256>' --out '<未使用dir>'
```

Root市場成功後に次の最小固定を作る。金融完了は同条件first2→full70・全12集合・Native SHA・入力code前後不変を検査し、未成功時はNative本文前に拒否する。

```json
{"version":1,"trial":108,"fixed":true,"stage":"full70","condition":{"path":"絶対path","sha256":"…"},"completion":{"path":"絶対path","sha256":"…"},"code":{"path":"この集計.pyの絶対path","sha256":"…"}}
```

条件の `source_manifest/source_corpus/source_completion` は106保存入力、`prior_closure/prior_completion/prior_native_index` は107旧実績として別々に認証する。新Nativeのinput_proofは106、prior_referenceは107へ結ぶ。新12だけ840資源を `108_…` namespaceのschema1一覧と実Fill JSONLへ保存する。HTTP/既存Viewer操作は行わない。

非市場確認は停止Coreの買売各12型・旧107手製参照、少数破損、20分/共通30分母、Go RawMessage指紋、最小metadataを使う。旧30と新20の損益差はこの人工の目的ではない。実市場・Raw/CSV・保存record本文はRootが固定成功を通知するまで読まない。
