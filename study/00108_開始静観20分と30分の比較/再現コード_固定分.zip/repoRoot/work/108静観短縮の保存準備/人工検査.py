"""108停止Coreの手製型と小境界だけで保存口を確認する。"""

import copy
from datetime import date, timedelta
import hashlib
import importlib.util
import json
from pathlib import Path
import sys


def main():
    """
    機能: 新旧の手製保存台帳、24比較、Viewerと狭い破損拒否を確認する。
    引数: argv[1](str)は未使用人工先。市場本文・金融再生は使用しない。
    返り値: None。正常保存は新規先だけ、破損受理時は失敗する。
    """
    here = Path(__file__).resolve().parent
    spec = importlib.util.spec_from_file_location("108保存人工", here / "集計.py")
    s = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(s)
    output = Path(sys.argv[1]).resolve()
    s.need(not output.exists(), "人工は新規先")
    core = s.ROOT / "work/108静観短縮の市場接続準備"
    fixtures = sorted((core / "人工_停止版").glob("*.json"))
    s.equal(len(fixtures), 2, "買売2手製型")
    inputs = {str(p): s.digest(p) for p in fixtures}
    if (core / "停止.json").exists():
        inputs[str(core / "停止.json")] = s.digest(core / "停止.json")
    output.mkdir(parents=True)
    details, pair, count, reference_count = [], None, 0, 0
    for path in fixtures:
        f = s.load(path)
        original = copy.deepcopy(f)
        v, reference = f["output"], f["prior107_reference"]
        prior_path = Path(reference["reference_path"])
        s.equal(s.digest(prior_path), reference["reference_sha256"], "旧手製参照SHA")
        inputs[str(prior_path)] = reference["reference_sha256"]
        old = s.load(prior_path)["output"]
        registry = s.registry_for_pair(f["records"], v, old)
        checked = s.inspect_scene(v, registry, False, True)
        prior = s.inspect_prior(old, registry, False)
        proof = s.verify_prior_reference(v, old, prior_path, reference["reference_sha256"], True)
        comparisons = s.compare_scene(checked, prior)
        rows = s.scene_rows(v, checked)
        summary, diagnosis = s.aggregate(rows)
        for key in s.KEYS:
            c = comparisons["20分_" + key + "対30分_" + key]
            s.equal(c["全差額"], checked[key]["totals"]["net_yen"] - prior[key]["totals"]["net_yen"], "新旧実現差")
            for label in s.ACTIVITY:
                a = summary[key][label]
                s.equal(a["active"] + a["wait"] + a["unknown"], a["denom"], "参加4分類")
        s.equal(f, original, "元型不変")
        count += len(checked)
        reference_count += len(prior)
        details.append({"path": str(path), "SHA256": inputs[str(path)], "新会計": len(checked), "旧保存再検算": len(prior),
                        "非0": sum(v["books"][k]["totals"]["entry_quantity"] > 0 for k in s.KEYS), "比較": len(comparisons), "保存参照": proof, "成功": True})
        pair = (f, old, checked, prior)
    f, old, checked, prior = pair
    v = f["output"]
    viewer = output / "Viewer型"
    viewer.mkdir()
    resources = s.save_viewer(v, viewer, "手製原板の未使用参照")
    s.equal(len(resources), 12, "Viewer12型")
    for key, resource in zip(s.KEYS, resources):
        trades = [json.loads(line) for line in (viewer / resource["pnl_path"]).read_text(encoding="utf-8").splitlines()]
        s.equal(len(trades), len(v["books"][key]["fills"]), "Viewer全実fillだけ")
        s.need(resource["id"].startswith("108_") and resource["point_value"] == 100, "108 namespace")
    s.BASE.write_json(viewer / "一覧.resources.json", {"schema_version": 1, "path_base": "catalog", "resources": resources})
    rejects = []
    mutations = {
        "30分auditを20分へ混在": lambda x: x["clock_audits"]["Q0_C0_D0"]["opportunities"][0].update(assigned_at=x["clock_audits"]["Q0_C0_D0"]["opportunities"][0]["assigned_at"] + 600),
        "Source全文": lambda x: x["clock_audits"]["Q0_C0_D0"]["opportunities"][0]["source"].update(parent="別出生"),
        "消費解除": lambda x: x["books"]["Q0_C0_D0"]["entry_opportunities"][0].update(consumed=False),
        "半円費用": lambda x: x["books"]["Q0_C0_D0"]["fills"][0].update(fee_yen=x["books"]["Q0_C0_D0"]["fills"][0]["fee_yen"] + s.BASE.FEE),
        "20分を30分設定偽装": lambda x: x["configs"][0].update(quiet_seconds=1800),
        "旧参照を同体flagへ": lambda x: x["prior_reference"].update(all=True),
    }
    for name, mutate in mutations.items():
        bad = copy.deepcopy(v)
        mutate(bad)
        try:
            s.inspect_scene(bad, None, False, True)
        except (AssertionError, ValueError, KeyError, TypeError) as error:
            rejects.append({"名称": name, "拒否": type(error).__name__})
        else:
            raise AssertionError("破損を受理: " + name)
    bad = copy.deepcopy(v)
    bad["prior_reference"]["book_full_json_sha256"][s.KEYS[0]] = "0" * 64
    try:
        ref = f["prior107_reference"]
        s.verify_prior_reference(bad, old, Path(ref["reference_path"]), ref["reference_sha256"], True)
    except (AssertionError, ValueError) as error:
        rejects.append({"名称": "旧全JSON指紋改変", "拒否": type(error).__name__})
    else:
        raise AssertionError("旧全JSON指紋改変を受理")
    # ----------------------------------------
    # 金融値を持たない小器具で20分下端・副表終端・欠測分母の独立範囲を確認する。
    book = {"session": {"start": 3000, "force_close": 6600, "end": 7200}, "entry_opportunities": [], "fills": [],
            "grid_traces": [{"at": at, "open_buy": int(at == 4200), "open_sell": 0, "unknown_count": 0, "us_quiet": at == 4500} for at in (4200, 4500, 4800)]}
    empty_checked = {"orders": {}}
    a, b = s.PARTICIPATION20(book, empty_checked), s.OLD.participation(book, empty_checked)
    s.equal((a["denom"], b["denom"], a["active"], a["unknown"], a["USquiet"]), (8, 6, 1, 5, 1), "20分/共通30/欠測/US残す")
    s.equal((s.PARTICIPATION20(book, empty_checked, "end30")["denom"], s.OLD.participation(book, empty_checked, "end30")["denom"]), (4, 2), "副表終端は30分固定")
    raw = '{ "文字": "<&>\u2028\u2029", "n": 1e+03, "z":"\\u003c", "空白":" x y " }'
    compact = '{"文字":"\\u003c\\u0026\\u003e\\u2028\\u2029","n":1e+03,"z":"\\u003c","空白":" x y "}'
    s.equal(s.raw_go_sha(raw), hashlib.sha256(compact.encode("utf-8")).hexdigest(), "Go RawMessage escape/数値元字句")
    ids = [(date(2026, 9, 21) + timedelta(days=i//2)).isoformat() + ("_Day" if i%2 == 0 else "_Night") for i in range(70)]
    manifest = {"sessions": [{"id": x} for x in ids]}
    condition = {"version": 1, "trial": 108, "fixed": True, "source_scope": "recorded_public_106", "configs": s.CONFIGS}
    ref = {"path": "未読の手製参照", "sha256": "a"*64}
    complete = {"version": 1, "trial": 108, "stage": "first2", "success": True, "condition_sha256": "b"*64, "sessions": 2, "books_per_scene": 12, "books": 24,
                "before": {"手製code": "c"*64}, "after": {"手製code": "c"*64}, "unchanged": True, "source_scope": "recorded_public_106",
                "source_reexecuted": False, "features_recomputed": False, "charts_recomputed": False, "bank_recomputed": False, "cmp_recomputed": True, "financial_executed": True,
                "results": [{"session": x, "books": 12, "prior_reference_books": 12, "prior_reference_unchanged": True, "native": ref, "sidecar_header": ref, "sidecar_records": ref, "prior_native": ref} for x in ids[:2]]}
    s.validate_completion(condition, complete, manifest, "first2", "b"*64)
    metadata_rejects = []
    for name, field, value in (("失敗金融", "success", False), ("会計欠落", "books", 23), ("前後不変なし", "unchanged", False), ("同条件なし", "condition_sha256", "d"*64)):
        bad = copy.deepcopy(complete)
        bad[field] = value
        try:
            s.validate_completion(condition, bad, manifest, "first2", "b"*64)
        except (AssertionError, ValueError) as error:
            metadata_rejects.append({"名称": name, "拒否": type(error).__name__})
        else:
            raise AssertionError("metadata破損受理: " + name)
    s.equal({p: s.digest(Path(p)) for p in inputs}, inputs, "元型前後不変")
    result = {"成功": True, "scope": "手製Core108買売24/旧Q30保存24・保存算術/24比較/Raw全JSON SHA/Viewer型。市場ではない",
              "会計": count, "旧保存再検算": reference_count, "非0会計": sum(d["非0"] for d in details), "details": details,
              "Viewer形式": 12, "破損拒否": rejects, "metadata正常": 1, "metadata拒否": metadata_rejects,
              "20分分母と共通30": True, "RawJSON原字句": True,
              "入力SHA256前": inputs, "入力SHA256後": inputs, "前後不変": True, "金融再実行": 0, "市場本文読取": 0, "実Viewer通信": 0}
    s.BASE.write_json(output / "人工確認.json", result)
    s.BASE.write_json(output / "型人工の集計.json", {"試行": 108, "成功": True, "stage": "artificial", "scope": "停止Go手製の一系列12冊。市場70場へ換算しない",
        "場数": 1, "会計数": 12, "主key": list(s.KEYS), "Actor設定": s.BY_KEY,
        "集計": summary, "実現診断": diagnosis, "場別": rows,
        "同実入口と実現額差": comparisons, "比較数": 24, "旧30は保存参照": True})
    print(json.dumps({"成功": True, "会計": count, "旧保存再検算": reference_count, "破損拒否": len(rejects), "metadata拒否": len(metadata_rejects)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
