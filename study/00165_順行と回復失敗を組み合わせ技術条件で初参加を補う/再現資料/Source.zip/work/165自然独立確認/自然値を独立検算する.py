"""165の全取得制御と層別自然成績を、作者の選択・集計を使わず検算する。"""
from pathlib import Path
from collections import Counter
from datetime import datetime
from zoneinfo import ZoneInfo
import gzip
import hashlib
import json
import math
import sys
import time

import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
PARENT=ROOT/'work/165順行と回復失敗の複合'
COMPARE=PARENT/'比較'
TRIAL=ROOT/'study/00165_順行と回復失敗を組み合わせ技術条件で初参加を補う'
BOOK_SHA='f2b6aace1ee8fe79b3977d79fc2346cc03fd3c752f15609a628a3f189c93b5af'
DATA=ROOT/'work/163任意幅の数値化/自然数値表'
FIELDS=('count','F','A','N','C','rate','complete_rate','all_rate','profit','loss','net','pf',
        'known','unknown','scenes','all_scenes','per_hour','max_scene_share','new_count','old_count',
        'hold_mean_seconds','wins','loss_trades','realized_win_rate','new_scenes','technical_first_count','core_count')


def sha(path: Path) -> str:
    """
    機能: 物理bytesのSHA256を計算する。
    引数: path(Path)は入力ファイル。
    返り値: strはSHA256。
    """
    with path.open('rb') as source:return hashlib.file_digest(source,'sha256').hexdigest()


def read(path: Path) -> dict:
    """
    機能: JSON又はgzip JSONを全体CRC付きで読む。
    引数: path(Path)は入力ファイル。
    返り値: dictは解析済みオブジェクト。
    """
    body=path.read_bytes()
    return json.loads(gzip.decompress(body) if body[:2]==b'\x1f\x8b' else body)


def save(path: Path,value: dict) -> None:
    """
    機能: 未知NaNを勝手に0へしない日本語JSONを書き出す。
    引数: path(Path)は保存先、value(dict)は有限値又はnullの内容。
    返り値: None。保存する。
    """
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')


def key(quote: dict) -> tuple:
    """
    機能: 同秒を物理原行まで区別する。
    引数: quote(dict)は気配。
    返り値: tupleは時刻・index・source_line。
    """
    return quote['time'],quote['index'],quote['source_line']


def link(directions: np.ndarray,captures: list,mapping: dict) -> list:
    """
    機能: 成立した要求を最初の実取得で重複除去する。
    引数: directions(np.ndarray[int8])、captures(list[dict])、mapping(dict[str,int])。
    返り値: list[tuple]はcase・実側・q0番号・origin0。
    """
    seen=set();rows=[]
    for event,direction in enumerate(directions):
        capture=captures[event]
        if not direction or capture['status']!='filled':continue
        case=mapping[capture['case_id']]
        if case in seen:continue
        rows.append((case,0 if direction==1 else 1,event,0));seen.add(case)
    return rows


def technical_controller(directions: np.ndarray,technical: np.ndarray,captures: list,
                         scene_events: list,scenes: list,mapping: dict) -> tuple:
    """
    機能: 金融値を受け取らず、当時の主取得・主未決・技術未決から補完を予約する。
    引数: directions/technical(np.ndarray[int8])、captures(list[dict])、scene_events(list[list[int]])、
          scenes(list[dict])、mapping(dict[str,int])は要求時計と物理取得だけ。
    返り値: tuple[list,list]は補完取得と全73場の因果監査。
    """
    adopted=[];audits=[]
    for scene,events in enumerate(scene_events):
        requests=[event for event in events if directions[event]!=0]
        fills=[key(captures[event]['q1']) for event in requests if captures[event]['status']=='filled']
        first=min(fills,default=None)
        active_until=None;attempts=[];waits=0;chosen=None
        for event in events:
            capture=captures[event];now=key(capture['q0'])
            if now[0]<scenes[scene]['start']+2700:continue
            if first is not None and first<=now:break
            if active_until is not None and now<active_until:continue
            if directions[event]!=0 or technical[event]==0:continue
            # 当時までに出した主要求が未決の間は補完しない。
            pending=False
            for request in requests:
                original=captures[request];birth=key(original['q0'])
                if birth>now:continue
                expiry=(original['expires'],math.inf,math.inf)
                end=min(expiry,key(original['terminated_at'])) if original.get('terminated_at') is not None else expiry
                if now<end:pending=True;break
            if pending:
                waits+=1;continue
            expiry=(capture['expires'],math.inf,math.inf)
            active_until=min(expiry,key(capture['terminated_at'])) if capture.get('terminated_at') is not None else expiry
            attempts.append({'event_index':event,'q0':list(now),'side':int(technical[event]),'status':capture['status'],
                             'pending_until':[v if math.isfinite(v) else None for v in active_until]})
            if capture['status']=='filled':
                chosen=mapping[capture['case_id']]
                adopted.append((chosen,0 if technical[event]==1 else 1,event,2));break
        audits.append({'scene_index':scene,'session':scenes[scene]['session'],'first_core_q1':list(first) if first is not None else None,
                       'attempts':attempts,'core_pending_waits':waits,'technical_case':chosen,'financial_not_used':True})
    return adopted,audits


def merged(core: list,extra: list,technical: bool=False) -> list:
    """
    機能: 旧優先又は主技術順の予約取得を物理caseで一意にする。
    引数: core/extra(list[tuple])、technical(bool)は補完種別。
    返り値: list[tuple]は作者と同じ意味を持つ取得属性。
    """
    if technical:
        ordered=sorted(core+extra,key=lambda row:(row[2],row[3]));seen=set();out=[]
        for row in ordered:
            if row[0] in seen:continue
            seen.add(row[0]);out.append(row)
        return out
    old_cases={row[0] for row in extra}
    return [row for row in core if row[0] not in old_cases]+extra


def ny_open(session: str) -> float:
    """
    機能: セッション日のNY09:30を夏冬時間込みでUTC秒へする。
    引数: session(str)はYYYY-MM-DD_Night。
    返り値: floatはNY09:30のUTC秒。
    """
    return datetime.fromisoformat(session[:10]+'T09:30:00').replace(tzinfo=ZoneInfo('America/New_York')).timestamp()


def band(session: str,at: float) -> int:
    """
    機能: デイ・夜間米国前・以後の時計を分類する。
    引数: session(str)、at(float)は判定時刻。
    返り値: intは0/1/2。NY開始の同時刻は以後。
    """
    return 0 if session.endswith('_Day') else 1 if at<ny_open(session) else 2


def widths_for(rows: list,branches: np.ndarray,mw: int,fw: int,tw: int,widths: list) -> np.ndarray:
    """
    機能: q0で決まった枝の幅を物理取得へ結ぶ。
    引数: rows(list)、branches(np.ndarray[int8])、mw/fw/tw(int)、widths(list[int])。
    返り値: np.ndarray[int]は各取得の幅添字。
    """
    result=[]
    for case,side,event,origin in rows:
        value=200 if origin==1 else tw if origin==2 else mw if branches[event]==0 else fw
        if origin==0:assert branches[event] in (0,1)
        result.append(widths.index(value))
    return np.asarray(result,dtype=np.int8)


def summarize(rows: list,widths: np.ndarray,hi: int,arrays: dict,hours: np.ndarray,
              row_mask: np.ndarray|None=None,eligible: np.ndarray|None=None) -> np.ndarray:
    """
    機能: 生のIFD方向・金融既知・費用後金額から27指標を独立に算出する。
    引数: rows(list)、widths(np.ndarray[int])、hi(int)、arrays(dict)、hours(np.ndarray[float])、
          row_mask/eligible(np.ndarray[bool]又はNone)は部分抽出と分母場。
    返り値: np.ndarray[float,27]は未知率NaNを保持する集計。
    """
    eligible=np.ones(73,dtype=bool) if eligible is None else eligible
    mask=np.ones(len(rows),dtype=bool) if row_mask is None else row_mask
    chosen=[row for row,keep in zip(rows,mask,strict=True) if keep];w=widths[mask]
    case=np.asarray([r[0] for r in chosen],dtype=np.int32);side=np.asarray([r[1] for r in chosen],dtype=np.int8)
    origin=np.asarray([r[3] for r in chosen],dtype=np.int8);scene=arrays['session_index'][case]
    known=arrays['known'][case,side,w,hi];direction=arrays['direction'][case,side,w,hi]
    assert np.all(known[direction!=0])
    f=int((direction==1).sum());a=int((direction==-1).sum());n=int(((direction==0)&known).sum());c=int((~known).sum())
    money=arrays['net5'][case,side,w,hi][known];profit=sum(int(v) for v in money if v>0);loss=-sum(int(v) for v in money if v<0)
    total=len(chosen);counts=Counter(map(int,scene));old=origin==1
    duration=(arrays['exit_time'][case,side,w,hi]-arrays['entry_time'][case])[known]
    divide=lambda x,y:x/y if y else math.nan
    values={'count':total,'F':f,'A':a,'N':n,'C':c,'rate':divide(f,f+a),'complete_rate':divide(f,f+a+n),
            'all_rate':divide(f,total),'profit':profit,'loss':loss,'net':profit-loss,'pf':divide(profit,loss),
            'known':int(known.sum()),'unknown':c,'scenes':len(counts),
            'all_scenes':int(all(counts[int(i)]>0 for i in np.flatnonzero(eligible))),
            'per_hour':divide(total,float(hours[eligible].sum())),'max_scene_share':divide(max(counts.values(),default=0),total),
            'new_count':int((~old).sum()),'old_count':int(old.sum()),
            'hold_mean_seconds':float(duration.mean()) if len(duration) else math.nan,
            'wins':int((money>0).sum()),'loss_trades':int((money<0).sum()),'realized_win_rate':divide(int((money>0).sum()),len(money)),
            'new_scenes':len(set(map(int,scene[~old]))),'technical_first_count':int((origin==2).sum()),'core_count':int((origin==0).sum())}
    assert f+a+n+c==total
    return np.asarray([values[name] for name in FIELDS],dtype=float)


def match(actual: np.ndarray,expected: np.ndarray,where: object) -> None:
    """
    機能: 未定義の位置と有限の全統計を比較する。
    引数: actual/expected(np.ndarray)、where(object)は比較値と所在。
    返り値: None。不一致ではAssertionError。
    """
    assert actual.shape==expected.shape and np.allclose(actual,expected,rtol=1e-12,atol=1e-9,equal_nan=True),where


def clean(values: np.ndarray) -> dict:
    """
    機能: 27指標を未知null付き辞書にする。
    引数: values(np.ndarray[float,27])は統計。
    返り値: dictは日本語資料からも参照できる数値。
    """
    return {name:float(value) if math.isfinite(value) else None for name,value in zip(FIELDS,values,strict=True)}


# ----------------------------------------
def main() -> None:
    """
    機能: 全1200取得集合・480技術制御・層別政策と全配列の不変式を検算する。
    引数: なし。停止済み165と共用の旧73場だけを読む。
    返り値: None。元データ不変を確認し、検査票と主案の場別・時間帯別数値を保存する。
    """
    sys.stdout.reconfigure(encoding='utf-8');begin=time.monotonic()
    assert sha(TRIAL/'条件.json')==BOOK_SHA
    paths=[Path(__file__),TRIAL/'条件.json',COMPARE/'完了.json',COMPARE/'統計軸.json',COMPARE/'主案と探索結果.json',
           COMPARE/'複合入口の統計配列.npz',COMPARE/'全取得参照.json.gz',COMPARE/'初参加補完の因果監査.json.gz',
           PARENT/'全出生/全出生の確認.json',PARENT/'全出生/複合と技術補完.npz',
           ROOT/'work/151過去場判別の評価/入口選択/cache/feature_only/features_meta.json',
           ROOT/'inputs/00148_全1分入口母集団/取得対応.json.gz',ROOT/'inputs/00148_全1分入口母集団/入口参照.json.gz',
           DATA/'任意幅配列.npz',DATA/'任意幅識別.json.gz',PARENT/'比較する.py',PARENT/'評価基盤165.py',PARENT/'出生を作る.py']
    before={p.relative_to(ROOT).as_posix():sha(p) for p in paths}
    axes=read(paths[3]);report=read(paths[4]);assert axes['fields']==list(FIELDS)
    meta=read(paths[10]);q0=meta['q0_meta'];scenes=meta['scenes'];raw_meta=read(paths[14]);mapping={c:i for i,c in enumerate(raw_meta['case_ids'])}
    captures_by_event={r['event_id']:r for r in read(paths[11])['rows']};captures=[captures_by_event[q['event_id']] for q in q0]
    assert len(q0)==35339 and len(scenes)==73
    scene_events=[[] for _ in scenes]
    for event,q in enumerate(q0):
        scene_events[q['session_index']].append(event)
        assert key(captures[event]['q0'])==(q['q0_time'],q['q0_index'],q['q0_line'])
    with np.load(paths[13],allow_pickle=False) as source:arrays={name:source[name].copy() for name in source.files}
    with np.load(paths[9],allow_pickle=False) as source:birth={name:source[name].copy() for name in source.files}
    with np.load(paths[5],allow_pickle=False) as source:metrics=source['metrics'].copy()
    assert list(metrics.shape)==axes['shape']==[240,6,5,4,5,3,27]
    assert np.isin(birth['directions'],(-1,0,1)).all() and np.isin(birth['technical'],(-1,0,1)).all()
    references={(r['profile'],r['integration']):r for r in read(paths[6])['rows']}
    audit={(r['profile'],r['integration']):r['rows'] for r in read(paths[7])['rows']}
    assert len(references)==1200 and len(audit)==480
    scene_map={s['session']:i for i,s in enumerate(scenes)};legacy=[];first={}
    for row in read(paths[12])['entries']:
        signal=row['origins'][0]['birthQuote'];session=row['session'];scene=scene_map[session]
        item=(mapping[row['id']],0 if row['native_side']==1 else 1,-1,1)
        legacy.append(item);birth_key=key(signal)+(row['id'],)
        if scene not in first or birth_key<first[scene][0]:first[scene]=(birth_key,item)
    assert len(legacy)==87 and len(first)==73
    hours=np.zeros((73,3))
    for si,scene in enumerate(scenes):
        end=scene['end']-300
        if scene['session'].endswith('_Day'):hours[si,0]=(end-scene['start'])/3600
        else:
            boundary=ny_open(scene['session']);hours[si,1]=(min(boundary,end)-scene['start'])/3600
            hours[si,2]=(end-max(boundary,scene['start']))/3600
    assert abs(float(hours.sum())-(720+55/60))<1e-10
    all_rows={};controller_attempts=0;controller_scenes=0
    for pi,profile in enumerate(axes['profiles']):
        core=link(birth['directions'][pi],captures,mapping)
        earliest={}
        for case,side,event,origin in core:
            scene=int(arrays['session_index'][case]);entry=(arrays['entry_time'][case],int(arrays['entry_index'][case]),int(arrays['entry_line'][case]))
            if scene not in earliest or entry<earliest[scene]:earliest[scene]=entry
        fallback=[first[scene][1] for scene in range(73) if scene not in earliest or earliest[scene]>first[scene][0][:3]]
        versions={'N':core,'U':merged(core,legacy),'F':merged(core,fallback)}
        for ti,width in enumerate((150,200)):
            chosen,observed=technical_controller(birth['directions'][pi],birth['technical'][ti],captures,scene_events,scenes,mapping)
            assert observed==audit[profile['id'],f'T{width}'],(pi,width,'controller')
            controller_scenes+=len(observed);controller_attempts+=sum(len(r['attempts']) for r in observed)
            versions[f'T{width}']=merged(core,chosen,technical=True)
        for integration,rows in versions.items():
            ref=references[profile['id'],integration]
            for at,name in enumerate(('cases','sides','events','origins')):
                assert [r[at] for r in rows]==ref[name],(pi,integration,name)
            assert len({r[0] for r in rows})==len(rows)
            all_rows[pi,axes['integrations'].index(integration)]=rows
    print(json.dumps({'全取得集合':len(all_rows),'因果制御の場':controller_scenes,'補完要求':controller_attempts},ensure_ascii=False),flush=True)
    # ----------------------------------------
    # 全144000政策の保存統計に、既知/未知、符号、分解の不変式を適用する。
    f={name:i for i,name in enumerate(FIELDS)};v=lambda name:metrics[...,f[name]]
    assert np.array_equal(v('count'),v('F')+v('A')+v('N')+v('C'))
    assert np.array_equal(v('known')+v('unknown'),v('count'))
    assert np.array_equal(v('unknown'),v('C'))
    assert np.array_equal(v('net'),v('profit')-v('loss'))
    assert np.array_equal(v('new_count')+v('old_count'),v('count'))
    assert np.array_equal(v('old_count')+v('technical_first_count')+v('core_count'),v('count'))
    assert np.all(v('wins')+v('loss_trades')<=v('known'))
    for name in ('count','F','A','N','C','profit','loss','net','known','unknown','new_count','old_count','wins','loss_trades','technical_first_count','core_count'):
        value=v(name);assert np.array_equal(value[...,0],value[...,1]+value[...,2]),name
    sample=set()
    for pi in range(240):
        for ii in range(5):
            for mi,fi in ((0,0),(2,3),(5,4)):
                for hi in range(4):sample.add((pi,mi,fi,hi,ii))
    for candidate in [report['事前固定主案'],report['前48場だけで選択']]+report['頻度順上位']+report['native頻度順上位']:
        if candidate is not None:sample.add(tuple(candidate['position']))
    for position in sorted(sample):
        pi,mi,fi,hi,ii=position;rows=all_rows[pi,ii];integration=axes['integrations'][ii]
        tw=int(integration[1:]) if integration.startswith('T') else 200
        widths=widths_for(rows,birth['branches'][pi],axes['momentum_widths'][mi],axes['fade_widths'][fi],tw,raw_meta['widths'])
        scene=np.asarray([arrays['session_index'][r[0]] for r in rows],dtype=np.int16)
        for period in range(3):
            eligible=np.arange(73)<48 if period==1 else np.arange(73)>=48 if period==2 else np.ones(73,dtype=bool)
            expected=summarize(rows,widths,hi,arrays,hours,eligible[scene],eligible)
            match(metrics[position+(period,)],expected,(position,period))
    primary=report['事前固定主案'];pi,mi,fi,hi,ii=primary['position'];rows=all_rows[pi,ii]
    widths=widths_for(rows,birth['branches'][pi],primary['momentum_width'],primary['fade_width'],200,raw_meta['widths'])
    for period,name in enumerate(('全期','前48場','後25場')):
        reported=np.asarray([primary['periods'][name][field] if primary['periods'][name][field] is not None else np.nan for field in FIELDS])
        match(reported,metrics[pi,mi,fi,hi,ii,period],('主案JSON',name))
    scene=np.asarray([arrays['session_index'][r[0]] for r in rows],dtype=np.int16);scene_report=[]
    for si,item in enumerate(scenes):
        eligible=np.arange(73)==si
        scene_report.append({'session':item['session'],'metrics':clean(summarize(rows,widths,hi,arrays,hours,scene==si,eligible))})
    clocks={
        'q0出生':np.asarray([band(scenes[int(arrays['session_index'][r[0]])]['session'],q0[r[2]]['q0_time']) for r in rows]),
        'q1取得':np.asarray([band(scenes[int(arrays['session_index'][r[0]])]['session'],arrays['entry_time'][r[0]]) for r in rows])}
    band_report={}
    for clock,bands in clocks.items():
        band_report[clock]=[]
        for phase,name in enumerate(('デイ','ナイト米国前','ナイト米国後')):
            eligible=hours[:,phase]>0
            band_report[clock].append({'band':name,'metrics':clean(summarize(rows,widths,hi,arrays,hours[:,phase],bands==phase,eligible))})
    full=primary['periods']['全期']
    additive=('count','F','A','N','C','profit','loss','net','known','unknown','new_count','old_count','technical_first_count','core_count')
    for name in additive:
        assert sum(item['metrics'][name] for item in scene_report)==full[name],('全場合計',name)
        for clock in clocks:assert sum(item['metrics'][name] for item in band_report[clock])==full[name],(clock,name)
    save(HERE/'主案の全73場と三時間帯.json',{'成功':True,'position':primary['position'],'全期':full,'全73場':scene_report,'時間帯別':band_report,
        '不足場':[r['session'] for r in scene_report if r['metrics']['count']==0],
        '留意':'独立入口をmini1枚ずつ合算した研究損益。数量制約付き口座収支ではない。Cは損益0として確定しない。'})
    assert all(sha(ROOT/name)==digest for name,digest in before.items())
    save(HERE/'自然の独立確認.json',{'成功':True,'trial':165,'条件SHA256':BOOK_SHA,'入力とSource':before,
        '全政策数':144000,'保存統計セル数':int(metrics.size),'全取得集合':len(all_rows),'全取得参照属性数':sum(len(rows)*4 for rows in all_rows.values()),
        '因果制御政策数':480,'因果制御場数':controller_scenes,'因果制御要求数':controller_attempts,'因果制御の金融入力':False,
        '独立再計算政策数':len(sample),'独立再計算統計セル数':len(sample)*3*len(FIELDS),
        '全配列不変式':'件数分解・FANCと金融既知未知・利益損失・新旧枝・前後加法を全政策へ適用',
        '再計算':'全240profile×5統合×幅対3組×全4期限、主案・前半選択・全報告候補を追加',
        '主案の全73場と三時間帯SHA256':sha(HERE/'主案の全73場と三時間帯.json'),
        '未見7場の価格読取':False,'元入力変更':False,'限界':'全144000政策の全統計を個別再計算したわけではない。原板の全面再走査は前段163/164の独立照合を参照。',
        '経過秒':time.monotonic()-begin})
    save(HERE/'独立確認の停止.json',{'成功':True,'SourceSHA256':sha(Path(__file__)),'検査票SHA256':sha(HERE/'自然の独立確認.json'),
        '主案明細SHA256':sha(HERE/'主案の全73場と三時間帯.json'),'元入力不変':True})
    print(json.dumps({'成功':True,'独立政策数':len(sample),'主案':full,'検査票SHA256':sha(HERE/'自然の独立確認.json')},ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
