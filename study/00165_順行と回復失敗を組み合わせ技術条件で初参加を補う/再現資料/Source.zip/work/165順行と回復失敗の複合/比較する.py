"""二つの技術機構と因果的初参加補完を複数の対称幅で比較する。"""
from pathlib import Path
from itertools import product
import sys
import time
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
TRIAL=ROOT/'study/00165_順行と回復失敗を組み合わせ技術条件で初参加を補う'
BOOK_SHA='f2b6aace1ee8fe79b3977d79fc2346cc03fd3c752f15609a628a3f189c93b5af'
sys.path.insert(0,str(ROOT/'work/163入口と任意幅'))
from 共通163 import read,save,sha
from 評価基盤165 import Context165,widths_for_selection,extended_cube,FIELDS165,INTEGRATIONS165


def period_rows(array: np.ndarray) -> dict:
    """
    機能: 未定義率NaNをnullへし、三期間の指標を可読辞書にする。
    引数: array(np.ndarray[float,3,27])は一政策の統計。
    返り値: dictは全期/前48場/後25場の指標。
    """
    return {period:{name:float(value) if np.isfinite(value) else None for name,value in zip(FIELDS165,row,strict=True)}
        for period,row in zip(('全期','前48場','後25場'),array,strict=True)}


def ready_mask(metrics: np.ndarray, setting: dict) -> np.ndarray:
    """
    機能: 164と同じ品質支持で複合案の発見候補を抽出する。
    引数: metrics(np.ndarray)は候補軸×三期間×27指標、setting(dict)は固定支持。
    返り値: np.ndarray[bool]は発見報告候補。
    """
    f={name:i for i,name in enumerate(FIELDS165)};all_=metrics[...,0,:];a=metrics[...,1,:];b=metrics[...,2,:]
    return (all_[...,f['count']]>=setting['minimum_count'])&(all_[...,f['new_count']]>=setting['minimum_new_count'])&\
        (all_[...,f['F']]+all_[...,f['A']]>=setting['minimum_resolved'])&\
        (a[...,f['F']]+a[...,f['A']]>=setting['minimum_resolved_each_period'])&\
        (b[...,f['F']]+b[...,f['A']]>=setting['minimum_resolved_each_period'])&\
        (all_[...,f['all_scenes']]==1)&(all_[...,f['rate']]>=setting['minimum_rate'])&\
        (a[...,f['rate']]>=setting['minimum_rate_each_period'])&(b[...,f['rate']]>=setting['minimum_rate_each_period'])&\
        (all_[...,f['unknown']]<=setting['maximum_financial_unknown_fraction']*all_[...,f['count']])&\
        (a[...,f['net']]>0)&(b[...,f['net']]>0)


def prospective_mask(metrics: np.ndarray) -> np.ndarray:
    """
    機能: 前48場だけで固定候補を選ぶ支持条件を適用する。
    引数: metrics(np.ndarray)は候補軸×三期間×27指標。
    返り値: np.ndarray[bool]は前半で適格の候補。
    """
    f={name:i for i,name in enumerate(FIELDS165)};front=metrics[...,1,:]
    return (front[...,f['all_scenes']]==1)&(front[...,f['rate']]>=.7)&\
        (front[...,f['F']]+front[...,f['A']]>=60)&(front[...,f['new_count']]>=80)&\
        (front[...,f['new_scenes']]>=10)&(front[...,f['unknown']]<=.1*front[...,f['count']])&\
        ((front[...,f['pf']]>=1.2)|((front[...,f['loss']]==0)&(front[...,f['profit']]>0)))&(front[...,f['net']]>0)


# ----------------------------------------
def main() -> None:
    """
    機能: 固定240profile×30幅対×四期限×五統合を評価し、主案と前半選択を別保存する。
    引数: なし。165の固定条件・金融未入力で封印した出生を利用する。
    返り値: None。全統計配列、T因果監査、主案/前半選択/発見上位を保存する。
    """
    assert sha(TRIAL/'条件.json')==BOOK_SHA
    setting=read(TRIAL/'条件.json');out=HERE/'比較';assert not out.exists()
    proof=read(HERE/'全出生/全出生の確認.json');assert proof['成功'] and proof['金融未入力']
    path=HERE/'全出生/複合と技術補完.npz';assert sha(path)==proof['files'][path.name]['sha256']
    source_paths=[Path(__file__),HERE/'評価基盤165.py',HERE/'出生を作る.py',
        ROOT/'work/164先着確定と反転比較/比較する.py',ROOT/'work/163入口と任意幅/評価163.py',
        ROOT/'work/162入口探索/評価基盤.py',HERE/'全出生/全出生の確認.json']
    before={p.relative_to(ROOT).as_posix():sha(p) for p in source_paths}
    save(TRIAL/'検査/F1_複合比較前.json',{'成功':True,'条件SHA256':BOOK_SHA,'Sourceと出生':before,
        '技術初参加の監査JSONだけ未決原行なしをnull表記':True})
    with np.load(path,allow_pickle=False) as source:
        directions=source['directions'].copy();branches=source['branches'].copy();technical=source['technical'].copy()
    context=Context165();profiles=proof['profiles'];n=len(profiles)
    mw=setting['momentum_widths'];fw=setting['fade_widths'];nh=len(context.table.horizons)
    metrics=np.full((n,len(mw),len(fw),nh,len(INTEGRATIONS165),3,len(FIELDS165)),np.nan)
    audits=[];references=[];begin=time.monotonic();out.mkdir()
    for pi,profile in enumerate(profiles):
        core=context.link(directions[pi]);variants={}
        for integration in ('N','U','F'):
            selected=context.integrate(core,integration)
            variants[integration]=(selected,np.where(selected.old,1,0).astype(np.int8),200)
        for ti,tw in enumerate(proof['technical_widths']):
            selected,origins,clock_audits=context.technical_integrate(directions[pi],core,technical[ti])
            variants[f'T{tw}']=(selected,origins,tw)
            audits.append({'profile':profile['id'],'integration':f'T{tw}','rows':clock_audits})
        for integration,(selected,origins,tw) in variants.items():
            references.append({'profile':profile['id'],'integration':integration,'cases':selected.cases.tolist(),
                'sides':selected.sides.tolist(),'events':selected.events.tolist(),'origins':origins.tolist()})
            ii=INTEGRATIONS165.index(integration)
            for mi,fi in product(range(len(mw)),range(len(fw))):
                widths=widths_for_selection(context,selected,origins,branches[pi],mw[mi],fw[fi],tw)
                metrics[pi,mi,fi,:,ii]=extended_cube(context,selected,origins,widths)
        if (pi+1)%20==0:
            print(__import__('json').dumps({'複合profile':pi+1,'全profile':n,'経過秒':round(time.monotonic()-begin)},ensure_ascii=False),flush=True)
    np.savez_compressed(out/'複合入口の統計配列.npz',metrics=metrics)
    save(out/'初参加補完の因果監査.json.gz',{'成功':True,'rows':audits})
    save(out/'全取得参照.json.gz',{'成功':True,'rows':references})
    meta={'成功':True,'trial':165,'profiles':profiles,'momentum_widths':mw,'fade_widths':fw,
        'horizons':context.table.horizons,'integrations':INTEGRATIONS165,'periods':('全期','前48場','後25場'),
        'fields':FIELDS165,'shape':list(metrics.shape),'source_kind':'origin0=主複合、1=旧C1参照、2=新技術初参加'}
    save(out/'統計軸.json',meta)
    f={name:i for i,name in enumerate(FIELDS165)}
    def describe(position: np.ndarray|list) -> dict:
        """
        機能: 位置添字から条件・主支援・三期間の成績を取り出す。
        引数: position(np.ndarray[int]又はlist[int])は五候補軸。
        返り値: dictは条件と成績。
        """
        pi,mi,fi,hi,ii=map(int,position)
        return {'position':list(map(int,position)),'profile':profiles[pi],
            'momentum_width':mw[mi],'fade_width':fw[fi],'horizon':context.table.horizons[hi],
            'integration':INTEGRATIONS165[ii],'periods':period_rows(metrics[pi,mi,fi,hi,ii])}
    positions=sorted(np.argwhere(ready_mask(metrics,setting['discovery_support'])),
        key=lambda p:(-metrics[tuple(p)][0,f['count']],-metrics[tuple(p)][0,f['rate']],tuple(p)))
    primary=setting['main_profile']
    pi=next(i for i,p in enumerate(profiles) if all(p[k]==primary[k] for k in ('momentum','fade','background','timing')))
    primary_position=[pi,mw.index(primary['momentum_width']),fw.index(primary['fade_width']),
        context.table.horizons.index(primary['horizon']),INTEGRATIONS165.index(primary['integration'])]
    training_positions=sorted(np.argwhere(prospective_mask(metrics)),
        key=lambda p:(-metrics[tuple(p)][1,f['count']],-metrics[tuple(p)][1,f['rate']],tuple(p)))
    chosen=describe(training_positions[0]) if training_positions else None
    native=[p for p in positions if INTEGRATIONS165[int(p[-1])] in ('N','T150','T200')]
    save(out/'主案と探索結果.json',{'成功':True,'全期探索は発見用':True,
        '総政策数':n*len(mw)*len(fw)*nh*len(INTEGRATIONS165),'事前固定主案':describe(primary_position),
        '前48場だけで選択':chosen,'前48場で適格数':len(training_positions),
        '発見支持合格':len(positions),'native発見支持合格':len(native),
        '頻度順上位':[describe(p) for p in positions[:100]],'native頻度順上位':[describe(p) for p in native[:100]]})
    assert all(sha(ROOT/p)==value for p,value in before.items())
    save(out/'完了.json',{'成功':True,'条件SHA256':BOOK_SHA,'Sourceと出生':before,'経過秒':time.monotonic()-begin,
        'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in out.iterdir() if p.is_file()}})
    print(__import__('json').dumps({'成功':True,'主案':describe(primary_position),'発見支持合格':len(positions),
        'native発見支持合格':len(native),'上位':[describe(p) for p in native[:3]]},ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
