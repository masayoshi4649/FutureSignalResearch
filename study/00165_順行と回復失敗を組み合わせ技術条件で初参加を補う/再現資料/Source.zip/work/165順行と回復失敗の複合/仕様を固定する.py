"""勢い継続と回復失敗を組み合わせ、新しい因果的初参加補完を固定する。"""
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
TRIAL=ROOT/'study/00165_順行と回復失敗を組み合わせ技術条件で初参加を補う'


def main() -> None:
    """
    機能: 二機構の複合・対称可変幅・技術初参加Tを結果前に次試行へ固定する。
    引数: なし。
    返り値: None。新規条件と実行前READMEを保存する。
    """
    assert not TRIAL.exists()
    assert max(int(p.name[:5]) for p in (ROOT/'study').iterdir() if p.is_dir() and p.name[:5].isdigit())==164
    parent=ROOT/'study/00164_IFD最初到達の確定時計で入口と反転を比較する/条件.json'
    setting=json.loads(parent.read_text(encoding='utf-8'))
    setting.update(trial=165,name='順行と回復失敗を組み合わせ技術条件で初参加を補う')
    setting['parent_conditions']={'path':parent.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(parent.read_bytes()).hexdigest()}
    setting['hypothesis']='強い動力の継続MPと、深いBB端からの弱い回復EXをfadeする別機構を統合し、方向競合を待機にする。既存C1参照に頼らないtechnical初参加補完Tも比較する。'
    setting['momentum_rules']=['MP0057','MP0058','MP0081','MP0082']
    setting['fade_rules']=['EX0075','EX0076','EX0087','EX0088']
    setting['fade_background_votes']=[0,2,3]
    setting['fade_timing']=['IMMEDIATE','CONF5_BASIC','CONF5_STRONG','CONF10_BASIC','CONF10_STRONG']
    setting['background']='新しいfade注文側の15/30分EMA21傾きとDI差の4票が正の数。k0は追加filterなし、k2/3は4列全既知。'
    setting['confirmation']='元EXの成立への遷移で反対方向をarm。同場・限月・gap<=180秒を維持し5/10分以内にBASIC/STRONGが初成立したq0だけ発火。連続EXtrueで期限延長しない。'
    setting['confirm_basic']='注文側5分HistΔ>0、RSIΔ>0、q0Last−m1Closeの注文側ATR比>0、absRSIΔ<=12、正常spread>0かつ元EX上限以下、absq0gap<=1。'
    setting['confirm_strong']='BASICかつ注文側5分DI>0・1分相対量>=0.75。未知なら不成立。'
    setting['merge']='MPとfadeが同方向又は片方だけならその方向、反対側なら待機。同方向で両成立したとき幅はMP優先。全q0後にq1を結び、同物理は最初成立q0。'
    setting['momentum_widths']=[150,175,200,225,250,300]
    setting['fade_widths']=[250,300,350,400,500]
    setting['bracket']='各取得でその枝のwをq0で決め、対称±wをIFD決済まで固定。枝間でwが異なる。'
    setting['integration']=['N','U','F','T150','T200']
    setting['technical_first']={'after_start_seconds':2700,'widths':[150,200],
        'score_minimum':5,'minimum_side_margin':1,
        'gate':'正常spread0< <=20、absq0gap<=1、EMA8追値<=1ATR、RSI中心側<=25、absRSIΔ5<=12、相対量1分>=0.5。',
        'votes':'162 technical_scoreの8票。全必要17列既知、加えてEMA/DI方向整合どちらかとMACD/RSI/実体動力どれかを要求。両側のうちscore差>=1の高い側を採る。',
        'controller':'開始45分以降、主新規の実取得0かつ主注文未決なしの各q0でTを判断。失敗取消後は次成立q0で再試行、最初T取得後は補完停止。主新規は継続。',
        'request_priority':'同q0は主新規優先。未約定主要求の終了原行がまだ来なければ補完しない。同物理q1は最初要求q0、同時は主優先。',
        'no_future_best':'後の勝者を補完せず、旧C1保存参照を持ち込まない。未取得場は未達として残す。'}
    setting['profile_count']=4*4*3*5
    setting['main_profile']={'momentum':'MP0057','fade':'EX0076','background':0,'timing':'IMMEDIATE','momentum_width':200,'fade_width':400,'horizon':'H60','integration':'T200'}
    setting['causal_frozen_selection']='前48場だけで、全場/先着70%/到達60/新80/新10場/未知<=10%/PF>=1.2/差引>0を満たす候補から取得数最大、同数なら率最大・安定IDを1つ選び、後25へ固定適用する。全73場は既使用なので独立未見と呼ばない。'
    setting['screen_status']='164で発見した既使用由来の2機構。全期screenと前半選択を分離し、後付けで主案を置換しない。未達なら次仮説へ。'
    setting['holdout']='新規7場は165の探索に使わない。別の候補固定後の試行でN/Tを同一接続器により確認する。旧156未実行。'
    TRIAL.mkdir();(TRIAL/'検査').mkdir()
    p=TRIAL/'条件.json';p.write_text(json.dumps(setting,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (TRIAL/'README.md').write_text('# 00165 順行と回復失敗を組み合わせ技術条件で初参加を補う\n\n2026-11-14。自然判断前に[条件](条件.json)を固定。MP順行とEX回復失敗fadeの統合、反対側競合待機、背景確認/時間内再失速、新しい技術初参加補完Tを比較する。主案は事前固定、現在未実行。163/164の旧値は変更しない。\n',encoding='utf-8')
    print(json.dumps({'条件SHA256':hashlib.sha256(p.read_bytes()).hexdigest(),'profiles':setting['profile_count']},ensure_ascii=False))


if __name__=='__main__':
    main()
