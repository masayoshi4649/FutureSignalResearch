"""正式148・共通163金融・凍結出生から165又は166を隔離再現する。"""
from pathlib import Path
import argparse
import importlib.util
import json
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def load(path: Path,name: str) -> object:
    """
    機能: Sourceのmainを呼ばず登録名でmoduleを読み込む。
    引数: path(Path)、name(str)。
    返り値: objectはmodule。
    """
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec)
    sys.modules[name]=value;spec.loader.exec_module(value);return value


# ----------------------------------------
def main() -> None:
    """
    機能: work成果物の無いcheckoutで正式入力から当該出生と統計を再現する。
    引数: CLI --trial(int)は165又は166。
    返り値: None。作者Source byteと正式条件を変更せず、全NPZ配列を正本へ照合する。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--trial',type=int,choices=(165,166),required=True)
    args=parser.parse_args();helper=load(ROOT/'work/163_164正式保存/正式入力から再現する.py','正式再現共通165')
    t165=ROOT/'study/00165_順行と回復失敗を組み合わせ技術条件で初参加を補う'
    t166=ROOT/'study/00166_未公表の長期指標を捏造せず局所技術で参加を補う'
    engine=ROOT/('work/165順行と回復失敗の複合' if args.trial==165 else 'work/166可用指標の階層化')
    assert not(engine/'全出生').exists() and not(engine/'比較').exists(),'元成果物のあるcheckoutでは実行しない'
    canonical=ROOT/'inputs/00163_任意幅の共用価格索引/数値表'
    alias=ROOT/'work/163任意幅の数値化/自然数値表'
    assert alias.exists() and helper.sha(alias/'任意幅配列.npz')==helper.sha(canonical/'任意幅配列.npz')
    helper.restore(helper.T162/'再現資料/出生と探索.zip',('work/162可変幅評価/自然射影/',))
    helper.restore(helper.T163/'再現資料/出生と統計正本.zip',('work/163入口と任意幅/全出生/',
        'work/162複合入口候補/候補辞書.json','work/162複合入口候補/履歴候補辞書.json'))
    if args.trial==166:
        helper.restore(t165/'再現資料/出生と統計正本.zip',('work/165順行と回復失敗の複合/全出生/',
            'work/165順行と回復失敗の複合/比較/'))
    sys.path.insert(0,str(ROOT/'work/162入口探索'))
    common=helper.module(ROOT/'work/162入口探索/共通.py','共通');factory=common.data_module
    features=factory().load_feature_from_formal()
    def formal_data() -> object:
        """
        機能: 固定Sourceへ正式148から同体射影した特徴を接続する。
        引数: なし。
        返り値: objectはload_feature_datasetだけを実行時に接続したデータmodule。
        """
        value=factory();value.load_feature_dataset=lambda:features;return value
    common.data_module=formal_data
    sys.path.insert(0,str(engine));qa=HERE/f'再現{args.trial}の検査';assert not qa.exists();qa.mkdir()
    trial=t165 if args.trial==165 else t166;(qa/'条件.json').write_bytes((trial/'条件.json').read_bytes())
    paths=[engine/'出生を作る.py',engine/'比較する.py',ROOT/'work/165順行と回復失敗の複合/評価基盤165.py']
    if args.trial==166:paths.append(engine/'local166.py')
    before={path.relative_to(ROOT).as_posix():helper.sha(path) for path in paths}
    if args.trial==166:helper.module(engine/'局所人工検査.py','再現166局所人工').main()
    for filename in ('出生を作る.py','比較する.py'):
        component=helper.module(engine/filename,f'再現{args.trial}_{filename}');component.TRIAL=qa;component.main()
    count=helper.compare_arrays(trial/'再現資料/出生と統計正本.zip',engine.relative_to(ROOT).as_posix()+'/')
    assert all(helper.sha(ROOT/path)==digest for path,digest in before.items())
    proof={'成功':True,'試行':args.trial,'配列照合':count,'Source非改変':before,'正式148特徴':features.sources,
        '条件SHA256':helper.sha(trial/'条件.json'),'注意':'既使用固定入力の再現であり、新しい未見性能ではない。'}
    (qa/'再現確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'配列照合':count},ensure_ascii=False))


if __name__=='__main__':main()
