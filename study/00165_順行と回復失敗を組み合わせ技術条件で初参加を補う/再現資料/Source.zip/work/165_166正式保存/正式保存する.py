"""165/166の主案・前半選択・発見を分離して正式保存する。"""
from pathlib import Path
import importlib.util
import json
import os
import re
import sys
import platform
import importlib.metadata

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
T165=ROOT/'study/00165_順行と回復失敗を組み合わせ技術条件で初参加を補う'
T166=ROOT/'study/00166_未公表の長期指標を捏造せず局所技術で参加を補う'
BOOKS={165:'f2b6aace1ee8fe79b3977d79fc2346cc03fd3c752f15609a628a3f189c93b5af',
    166:'5c3ad73b0003da91749c50e0242b973951c74993db6a9156dfa951d8020f5a49'}
spec=importlib.util.spec_from_file_location('正式保存共通165',ROOT/'work/163_164正式保存/正式保存する.py')
B=importlib.util.module_from_spec(spec);spec.loader.exec_module(B)


def identify(record: dict) -> str:
    """
    機能: 主案・選択案の条件を短い識別子で表示する。
    引数: record(dict)は固定済み記述。
    返り値: strはprofile・階層・二幅・期限・統合の記述。
    """
    return record['profile']['id']+(' / '+record['hierarchy']['id'] if 'hierarchy' in record else '')+\
        f" / 順行{record['momentum_width']}・失速{record['fade_width']}pt / {record['horizon']} / {record['integration']}"


def settings(trial: int,destination: Path) -> None:
    """
    機能: 版8全63手法×9尺度に165又は166の実参照を記入する。
    引数: trial(int)、destination(Path)。
    返り値: None。未使用・未知・未検証の意味を区別する。
    """
    source=ROOT/'docs/議論/手法と時間スケールの汎用表_版8.md'
    body=source.read_text(encoding='utf-8').split('## 手法×時間スケール',1)[1].split('## 設定明細',1)[0]
    body=body[body.index('### 指標'):];u={}
    for scale in (3,4,5):
        u[('I01',scale)]='EMA21傾き。旧Tの5/15/30分方向票、背景filter'
        u[('I08',scale)]='DI差。'+('MPのADX水準/増分' if scale==4 else '旧T方向票/背景filter')
    for scale in (3,4):
        u[('I03',scale)]='Hist水準/増分'+('・ATR比' if scale==3 else '。MPの水準と旧Tの増分')
        u[('I04',scale)]='RSI中心差/増分' if scale==3 else '旧TのRSI増分'
    for method,scale,note in [('I01',0,'q0のEMA8距離/ATR5'),('I05',0,'旧Tの順側BB余地を150/200ptへ正規化'),
        ('I05',4,'EX端のσ位置、旧Tのabsσ<=1'),('I09',0,'EMA8/現在1分終値距離のATR5比'),
        ('I09',3,'Hist/ATR5、TR/ATR5'),('P01',3,'実体・終値位置・反対ヒゲ'),
        ('P05',0,'q0Last−m1Closeの実側ATR比、CONFでは正を要求'),('V01',1,'前3分比の相対観測量>=0.5/0.75/1。rvol5は未使用'),
        ('B01',0,'0<spread<=10/20、absq0gap<=1ATR'),('C01',0,'EMA/DI方向とMACD/RSI/実体動力、量/追値/急変gate'),
        ('C02',0,'EXはBB端・ヒゲ・動力・量の元側回復。新fadeは反対実側で確認/背景を別比較'),
        ('C04',0,'DI方向とMPのADX強度/増分'),('C07',0,'旧Tの5/15/30分。fade背景は15/30分4票'),
        ('E01',0,'順行150～300、失速250～500、補完150/200ptを出生で固定。IFD_FIRSTと4期限')]:u[(method,scale)]=note
    lines=[];count=0
    for line in body.splitlines():
        cells=[c.strip() for c in line.split('|')[1:-1]] if line.startswith('|') else []
        if len(cells)==11 and re.fullmatch('[A-Z][0-9]{2}',cells[0]):
            count+=1
            for scale in range(9):cells[2+scale]=f'S{trial}-X/Q：'+u[(cells[0],scale)]+f'。R{trial}' if (cells[0],scale) in u else '未使用・未検証'
            line='| '+' | '.join(cells)+' |'
        lines.append(line)
    assert count==63
    def relink(match: re.Match) -> str:
        """
        機能: 教材リンクを試行からの有効な相対位置へ置き直す。
        引数: match(re.Match)。
        返り値: strはMarkdownリンク。
        """
        target=match.group(2)
        if '://' in target or target.startswith('#'):return match.group(0)
        return '['+match.group(1)+']('+os.path.relpath((source.parent/target).resolve(),destination).replace('\\','/')+')'
    body=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',relink,'\n'.join(lines))
    text=f'# {trial} 設定と結果\n\n2026-11-15。[汎用表版8](../../docs/議論/手法と時間スケールの汎用表_版8.md)全63×9=567セルを複写。元SHA256 `{B.sha(source)}`。使用は複合評価R{trial}の実参照であり、指標単独の効果ではない。\n\n'
    text+='入力100Xに列が存在するだけの技法は未使用。rvol5等の供給済み未使用列と、VWAP/一目等の今回未生成の指標を区別する。必要値の未知は0/中立へ補完せず不成立・未知として保持する。M01/M02の学習器と新追尾E02は今回未使用、固定ルールの入口と単純IFDを先に比較した。\n\n## 手法×時間スケール\n\n'+body
    text+=f'''\n\n## 設定明細\n\n|設定ID|短い閾値・役割|複合評価|\n|---|---|---|\n|S{trial}-MP|MP0057/58/81/82。5分Hist/ATR下限、15分Hist正、Hist増分非負、RSI中心差下限/25上限と増分、ADX15水準/増分、相対量。全閾値は163出生正本の候補辞書|順行4|\n|S{trial}-EX|EX0075/76/87/88の元回復方向を反転。BB反対端・逆ヒゲ・RSI/Hist増分・実体・量の同条件を元側へ適用し、反対側BBOで取得|失速4|\n|S{trial}-B|失速注文側の15/30分EMA21傾きとDI差4票>=0/2/3。B0は追加filterなし、B2/3は必要4列全known|背景3|\n|S{trial}-CONF|IMMEDIATE又は元EXへの遷移でarm後5/10分以内の初BASIC/STRONG。連続EXtrueで延長なし、場/180秒超reset。BASICは注文側M5 HistΔ/RSIΔ/q0gap正、RSI絶対増分<=12と気配/乖離gate。STRONGはDI正・量>=0.75追加|時計5|\n|S{trial}-MERGE|MP/失速が同方向又は片方のみならその方向、逆なら待機。両同方向の幅はMP優先。同物理q1は最初成立q0|主枝|\n|S{trial}-T8|EMA3軸>=2・DI3軸>=2・HistΔ5/15正・RSIΔ5正15非負・実体正かつ終値位置>0.5・量>=1・BB absσ<=1かつ順余地>=幅0.5・absEMA8距離<=1かつTR/ATR<=1.5の8票。必要17列全known、>=5票・側差>=1|旧T150/200|\n|S{trial}-T_GATE|方向EMA/DIのどちらかとMACD/RSI/実体動力のどれか、0<spread<=20、absq0gap<=1、EMA8距離<=1、RSI中心<=25、absRSIΔ<=12、量>=0.5。8票とgate合計20必須列|旧T|\n|S{trial}-CTRL|開始45分以後、主実取得0・主pendingなし・同q0主方向0なら補完要求。取消後再試行。T要求後の後発主取得で事後取消ししない。同q1は最初要求、同q0は主優先|因果取得|\n|S{trial}-E|順行150/175/200/225/250/300、失速250/300/350/400/500、T150/200。H30/H60/H120/SESSIONのIFD_FIRST、同じ実BBO・100円/pt・往復77円+追加滑り1000円|単純IFD|\n|S{trial}-PAST|前48場だけで全場/先着>=70%/到達>=60/新>=80かつ10場/未知<=10%/PF>=1.2/差引>0。取得最大→率→固定添字順で選択し後25へ固定|既使用の前後比較|\n'''
    if trial==165:
        text+='\nR165：4MP×4EX×3背景×5時計=240profile、30幅対×4期限×N/U/F/T150/T200で144,000政策。Uは旧87全保持、Fは旧初回の因果補完。旧C1を使わないN/Tの発見支持は0。主案と前半選択と全期発見を交換しない。[主結果](README.md)参照。\n'
    else:
        text+='''|S166-L6|M5 EMA21傾き正、DI差正、Hist増分正、RSI増分正、実体正かつ終値位置>0.5、相対量>=0.5の6票。必要7列全known、4/5票・側差>=1。高側だけ資格確認、低側へ代用なし|局所4階層|
|S166-L_GATE|最低方向1票・動力1票、RSI中心−5..25、absRSIΔ<=12、absEMA8距離<=1、量>=0.5、TR/ATR<=2、0<spread<=20、absq0gap<=1。score+gate必要12列|局所|
|S166-L_AVAIL|その場で両実側いずれにもm15HistΔの有限値が当時まで一度も無く、開始120/180分以後。有限0も公表、当行から無効。次場のみreset、gapや後のNaNで再開しない|当時可用性|
|S166-H|旧T非0を絶対優先し、旧T0時だけLocal。tier0待機/1旧T/2局所。主/補完の取得制御は165同体、幅は150/200|H150/H200|

R166：主4profile×局所4階層×30幅対×4期限×H150/H200=3,840政策。全73場参加は旧C1補完ではなく、主693・旧技術T35・局所10の事前主案で確認した。旧T8票を局所6票へ全置換したわけではない。旧165対応対照は全要素同体。主案と前半選択と全期発見を交換しない。[主結果](README.md)参照。
'''
    text+='\n[条件](条件.json)、[心理・原因と限界](条件心理と原因.md)、[再現手順](再現手順.md)を参照。単純IFDの既知合算は同時建玉制約付き口座収支ではない。\n'
    (destination/'設定と結果.md').write_text(text,encoding='utf-8')


def docs() -> None:
    """
    機能: 固定主案・前半選択・全期発見を別々の表に記す。
    引数: なし。
    返り値: None。新7場の値又は後続採否を使わない。
    """
    common='''\n## 入力・費用と分母\n\n全73場・35,339q0・31,642物理caseの既存母集団を維持。共有148の当時100Xと163の実両側・任意幅IFD表を用いる。技術出生へ教師・q1・金融を渡さず、出生固定後に実取得対応を結ぶ。5/15/30分の足幅と新規判断の時計を混同せず、連続したq0を使う。DAY/夜間NY09:30前/以後は夏冬変換、q0出生帯とq1取得帯を区別する。各帯強制参加はしない。\n\n先着は164のIFD_FIRST：打切り前の最初の既知touchでF/A、touchなし期限完了でN、他C。F/(F+A)は到達済み先着率で、N/Cを含む全取得成功率や費用後実現勝率とは異なる。金融未知は0円実績にせず別計数。\n\n各入口を独立mini1枚、100円/pt、税込片道38.5円（往復77円）と追加往復滑り1,000円を控除。実BBOでBUY Ask/SELL Bid取得、反対側BBO清算する。順逆同じ幅を枝ごとq0で固定し、touch又は完了期限BBOで決済する。利益は費用後正の合計、損失は費用後負の絶対値合計、PF=利益/損失。既知差引は未知を解決した全損益ではない。\n\n頻度は全対象ザラバ720時間55分を分母とする。同じ入口の重複分割を回数へ水増ししない。独立入口は保有が重なり得るため、片側10枚上限を満たす実口座収支とは称さない。mini固有板・遅延・待ち行列も未再現。新7場は本試行の条件探索・成績へ使用しない。\n'''
    for trial,destination,folder in [(165,T165,'work/165順行と回復失敗の複合'),(166,T166,'work/166可用指標の階層化')]:
        d=B.read(ROOT/folder/'比較/主案と探索結果.json');primary=d['事前固定主案'];chosen=d['前48場だけで選択'];top=d['頻度順上位'][0]
        if trial==165:
            text='''# 165 順行と回復失速の複合入口\n\n2026-11-15。事前主案は728取得、220順85逆、到達済み72.13%、1.010回/時、利益7,878,969円・損失4,608,406円。ただし64/73場で全場参加は未達。無参加9場の長期MACD可用性を調べ、[166](../00166_未公表の長期指標を捏造せず局所技術で参加を補う/README.md)へ仮説を分ける。主案の好成績や不足を、後付けの全期上位で置き換えない。\n\n## 仮説・条件\n\nMPの勢い持続へ順行する入口と、EXの弱い回復に逆らう入口を複合し、旧C1とは別の複数技術の初参加補完を加える。失速側には15/30分方向票、5/10分内の動力・価格確認の有無を比較する。単に逆行過多で終了せず、元回復の失敗を実反対側で調べる。\n\n240profile×30幅対×4期限×5統合=144,000政策。主案はMP0057_EX0076_B0_IMMEDIATE、順行±200・失速±400・T±200・H60。反対同時成立は待機、同方向両成立の幅はMP優先。Tは45分以後の主未取得・未決なしの場合だけ予約し、失敗取消後に再試行する。\n'''
        else:
            text='''# 166 長期未公表時だけの局所技術補完\n\n2026-11-15。事前主案は**全73場・738取得、221順87逆、到達済み71.75%、1.024回/時、利益7,922,584円・損失4,684,791円**。主693・旧技術T35・局所10取得で、旧C1の保存入口を補完へ使っていない。既使用全73場での確認であり、安定した未見性能や実口座利益が確定したとは言わない。\n\n## 仮説・条件\n\n165の無参加9場では15分MACD Hist本体も増分も未公表だった。未知を0や中立へ捏造せず、当時まで長期増分が一度も有限でなかった場に限り、M5方向・動力・形状・量の局所6票で補完する。旧Tの8票を全置換せず、旧T非0は常に優先する。\n\n4主profile×4階層×30幅対×4期限×2統合=3,840政策。事前主案はMP0057_EX0076_B0_IMMEDIATE / L180_S4、順行±200・失速±400・補完±200・H60。開始180分以後、当時まで長期増分未公表、局所4票以上を要求する。\n'''
        text+=f"\n[条件](条件.json)SHA256 `{BOOKS[trial]}`。[設定と結果](設定と結果.md)はV8の全63×9セル。[心理と原因](条件心理と原因.md)に条件の役割と可用性の原因を記した。\n"+common
        text+='\n## 事前固定主案\n\n'+identify(primary)+'\n'+B.metric_table(primary)
        if trial==165:
            text+='\n主693取得・新技術初参加35取得、旧C1参照0。前48場は40/48場、後25場は24/25場で無参加を除外していない。\n'
        else:
            text+='\n局所追加10件の内訳は1順・2逆・7未到達・0観測不足。旧主案と比べ利益+43,615円、損失+76,385円、既知差引−32,770円、PF1.710→1.691。追加で単純に収益性が上がったとは言わず、全場参加を満たすための情報限定補完の費用を明記する。前48場は69.09%、後25場は74.83%で全期率だけを安定性と解釈しない。\n'
        text+='\n## 前48場だけの固定選択\n\n'
        if chosen:
            text+=identify(chosen)+'\n'+B.metric_table(chosen)
            if trial==165:text+='\nこの選択はU旧87を保持し、純新規の参加は56場。前半で選んだ候補の後半適用であり、全73場は既使用なので独立未見とは呼ばない。事前T主案をこのU案へ置換しない。\n'
            else:text+='\n後25場の到達済み率は67.76%で、前半72.46%より低い。後半既知差引は黒字でも、事前主案をこの選択案へ交換しない。全73場は既使用である。\n'
        else:text+='適格候補なし。\n'
        text+='\n## 全期探索の発見候補\n\n'
        text+=f"固定報告支持合格は{d['発見支持合格']:,}政策。"+('旧参照なしのN/Tの支持合格は0。' if trial==165 else '')
        text+=' 全期頻度順先頭は次の条件であり、自動採用又は未見実績ではない。\n\n'+identify(top)+'\n'+B.metric_table(top)
        text+='\n報告支持は取得200/新100/到達100・前後各30/全場/全期70%以上・前後65%以上/未知10%以下/前後既知差引正。前半固定選択は別の支持条件であり、掲載3案を一つの「最良」へ混ぜない。\n'
        if trial==165:
            text+='\n## 検査と限界\n\n純関数/controllerの独立人工610制御例、失速505例・鏡像500・未来毒500、技術票/gate80例が一致。自然では全1,200取得集合・35,040場制御と26,344補完要求が一致、全144,000政策の不変式、層化と全掲載候補を含む14,484政策1,173,204統計セルが一致した。全144,000政策を独立実装で個別再集計したものではない。\n'
        else:
            text+='\n## 検査と限界\n\n局所人工は鏡像3,160行、未来接尾毒9,440接頭行、未知と有限0、公表後無効化、旧T絶対優先、高側不合格時の低側代用禁止を確認。自然独立確認は全35,339q0×4階層の資格/得点/方向とtier、全32取得集合・2,336場制御・1,624補完要求、全3,840政策334,080セル・旧960対照77,760セルを独立再計算し一致。支持505と前半適格139・固定選択も一致した。自然の長期増分有限0は0件であり、その境界は人工確認として区別する。\n'
        text+='\n[再現手順](再現手順.md)、[保存索引](再現資料/保存索引.json)、[圧縮正本](再現資料/出生と統計正本.zip)を参照。共有価格索引・Go観測・金融表は[恒久入力](../../inputs/00163_任意幅の共用価格索引/README.md)の一組を再用し、正式閲覧をworkだけへ依存させない。CSV/globalは全体研究側で整理し、本担当はxlsxを生成しない。\n'
        (destination/'README.md').write_text(text,encoding='utf-8');settings(trial,destination)
        cause='''# 条件の心理・未参加原因・限界\n\n2026-11-15。心理は説明仮説、可用性と数値は既使用入力の確認事実である。\n\n## 二つの入口の役割\n\nMPはHist/RSI/ADXと量が伴う方向の継続を狙う。EXは伸びた端でヒゲ・短期動力回復を検出するが、弱い回復は継続トレンドに吸収される可能性がある。その元EX側へ逆らうfadeを実反対側BBOで比べた。売買は同じ正規化式を符号反転して扱い、反転率を1−pでは作らない。\n\n15/30分の方向票は元方向の地合い、5/10分の確認は短期の回復失敗を近似する。確認を増やすほど正しいという結論を事前に置かず、即時・背景・確認を別比較した。B0 IMMEDIATE主案には追加方向filterや後続失速確認が無いことも残す。\n\nBB接触やRSI過熱だけで反転を確定しない。[Bollinger本人のCMT講演](https://cmtassociation.org/wp-content/uploads/2024/01/Bollinger-Trading-Bands-1.pdf)（2026-11-14確認）の複数指標と価格動作の考え方を参考にした研究派生で、原典がこのfadeの利益を保証したわけではない。今回のCONFは[163の履歴Impulse派生](../00163_履歴を含む複合入口を任意幅と場末まで検証する/分類時計と次の仮説.md)そのものではない。\n\n## 165で静観した9場の原因\n\n固定122公表と指標生成Sourceの確認では、15分MACD Hist本体も増分も9デイで全公表未知だった。初回09/21Dayはcold start。他8デイは直前Nightの価格未知15分足でnumeric状態が全resetし、carry種が0～5本へ落ちていた。限月は9場とも161120018で変更なし。\n\nEMA26からSignal9を構成する既存生成器では、Hist初回に連続価格足34本、Hist差分には35本が必要。デイの15分公表27本だけでは到達せず、例10/28Dayは前Night04:30の未知足後5本carry、Day中は履歴6～32本だった。「増分だけ欠けた」問題でも限月交代でもない。未知足でresetする生成契約と、取引時間の長さの組合せである。\n\n旧Tは8票の必要17列に15分Hist増分を含み、gateまで含めると20列全knownを求める。そのため可用性不足の場では高得点側を評価できず、無参加になった。後から知られる相場方向や損益を使って穴埋めしたものではない。生成器を緩めて長期値を捏造せず、166は別の情報集合を使う仮説として分けた。\n\n## 166の階層化\n\n旧Tの長中短8票は保持し、当時まで一度も15分Hist増分が有限でなかった場合に限り、120/180分以後の局所6票を候補にする。有限0も公表として、その行から局所禁止。後に初めて既知になる時計を先取りせず、後のNaN/gapでも再有効化しない。旧T非0は常に優先する。\n\n局所はM5 EMA/DI方向、Hist/RSI/実体動力、相対量の6票、必要7列。RSI中心−5..25・絶対増分12以下・absEMA8距離1ATR以下・TR/ATR2以下・気配/乖離gateを含めると12列。旧Tと同等の長期確認があると称さず、方向の確認を短期へ限定する。高得点側の資格不合格時に低側へ代用しない。\n\n165→166主案では主693と旧T35は保持し、局所10を追加して全73場へ参加した。ただし追加分は1順2逆7未到達で既知差引−32,770円。機会損失を最適化したのではなく、参加条件を保つ補完と収益性を分けて評価した。局所10件の率だけから優位性は断定しない。\n\n## 残る限界\n\n同一の73場を繰り返し参照しており、前半選択/後半適用も独立未見ではない。主案、前半選択、全期発見上位は異なる役割で保存する。多数比較・幅・期限・未知/打切り・場集中を残し、全期最大額だけで入れ替えない。市場心理の説明が妥当でも、個別閾値の将来再現を証明しない。新7場の検証と建玉上限・連続約定・mini板での実行検査は別段階である。\n'''
        if trial==165:
            cause=cause.split('## 166の階層化',1)[0]+'''## 次の仮説\n\n当時まで長期指標を一度も利用できない場合だけ、M5方向/動力/形状/量の別の情報集合を使う局所補完を[166](../00166_未公表の長期指標を捏造せず局所技術で参加を補う/README.md)へ分ける。旧Tを全置換せず、旧T非0を優先する。後続結果を165の成績・採否へ混ぜず、ここでは未参加原因と次仮説までを残す。\n\n同じ73場は既使用であり、前半選択/後半適用も独立未見ではない。多数比較・幅・期限・未知/打切り・場集中、旧参照による参加寄与を残す。主案、前半選択、全期発見を交換しない。新7場と数量制約付き実行は別段階である。\n'''
        cause+='\n原因診断の再現用公表入力は[122再現手順](../00122_E0固定条件を全セッションで検証する/再現資料/再現手順.md)と[共用計画](../../inputs/00122_新規3場公表/README.md)から復元する。73場177MB入力を本試行へ再複製しない。欠5分17個はCSVに時刻行自体が無いことまで確認したが、取引なし/配信停止/保存欠落のどれが原因かは未判定。根拠Source・424,068Hist本体/増分セルの一致・9場表は165Source正本の診断に保存した。\n'
        (destination/'条件心理と原因.md').write_text(cause,encoding='utf-8')


def reproduction(trial: int,destination: Path) -> None:
    """
    機能: 親Sourceを共有し作業cacheを複製しない再現を記録する。
    引数: trial(int)、destination(Path)。
    返り値: None。正式値/旧停止票の上書きを避ける。
    """
    text=f'''# {trial} 再現手順\n\n2026-11-15。Python3.14.3/NumPy2.5.4/ijson3.6.0/tzdata2026.6。環境・Source/入力/全ZIP member・サイズ・SHAは[保存索引](再現資料/保存索引.json)に保持する。\n\n## 保存構成\n\n本試行の[Source.zip](再現資料/Source.zip)は新規部品・人工/自然独立確認・再現/保存Sourceを保持し、[出生と統計正本.zip](再現資料/出生と統計正本.zip)は出生NPZ、全統計NPZ、軸、取得参照、因果監査、主案/前半選択/発見上位JSONを保持する。NPZ/gzipは既に圧縮済みで、元byteのまま外側ZIPへ無圧縮格納する。全件MD転記やRaw複製を作らない。\n\n共有価格索引・Raw観測・任意幅金融表は[inputs/00163](../../inputs/00163_任意幅の共用価格索引/README.md)。163出生は[163正本](../00163_履歴を含む複合入口を任意幅と場末まで検証する/再現資料/出生と統計正本.zip)、旧金融/データ部品は[162正本](../00162_複合入口を広く探索し値幅ごとに過去選択する/再現資料/出生と探索.zip)と親Sourceを再用する。166は165出生/旧統計を[165正本](../00165_順行と回復失敗を組み合わせ技術条件で初参加を補う/再現資料/出生と統計正本.zip)へ参照し、重複収録しない。\n\n## 隔離再現\n\nworkの当該全出生/比較が存在しない別checkoutを使用。正式inputs/00148、親条件と停止票を保持する。162→163→164→165→166の必要Source.zipをリポジトリルートへ順に展開する。165だけなら166Sourceは不要。既存ファイルがあればbyte同体を要求し、固定Sourceを編集しない。\n\n元Sourceの固定workパスへ共有金融表を複製せずJunctionで結ぶ。\n\n```powershell\nNew-Item -ItemType Junction -Path 'work/163任意幅の数値化/自然数値表' -Target (Resolve-Path -LiteralPath 'inputs/00163_任意幅の共用価格索引/数値表')\n& 'work/複合テクニカル学習環境/Scripts/python.exe' -X utf8 'work/165_166正式保存/正式入力から再現する.py' --trial {trial}\n```\n\nラッパーは正式148の共有特徴から161の同体射影を使い、feature2cacheを重複保存しない。162金融と163出生、166の場合は165出生/旧比較を正本から必要時に復元する。作者の出生→比較mainを呼び、検査票の保存先だけworkへ隔離する。Sourceは前後同体、全出力NPZ配列はNaN込みで参照へ照合する。NPZ内部ZIP日時や実行秒のbyte一致は要求しない。保存時にはラッパーのcompile/--helpだけを確認しており、この追加ラッパーで全自然値をもう一度走らせてはいない。\n\n取得制御では主新規の実取得/pendingを当時原行順で使い、利益・label・成熟を判断へ渡さない。Contextが金融を保持することと、controllerが金融を判断に読むことを区別する。166局所generatorはContext165を生成せず、165出生と純特徴だけを読む。\n\n## 実施済み検査と範囲\n\n165は独立controller610件、失速505件・鏡像500・未来毒500、技術票/gate80件。自然では全1,200取得集合、35,040場の制御、26,344要求を照合した。全144,000政策の不変式と、層化/掲載を合わせ14,484政策1,173,204セルを独立再計算した。全144,000政策の全指標を別実装で再集計した主張ではない。\n\n166局所は人工鏡像3,160行・未来毒9,440接頭行、当時公表履歴と旧T優先を確認した。166自然独立確認のSource/票、可用性診断の根拠はSource/正本に保持し、検査票の範囲を超えて未見や自然Raw全再走査とは称さない。Raw/金融の基盤は163/164の独立Raw・全分類/成熟検査を参照する。\n\n原因となった公開器Sourceの価格未知reset、MACD連続34本/増分35本の契約と、固定122公表からの診断は新7場へアクセスせず確認した。生成器自体を変更して過去の未知を埋め直していない。\n'''
    (destination/'再現手順.md').write_text(text,encoding='utf-8')


# ----------------------------------------
def main() -> None:
    """
    機能: 出生・統計・独立根拠を共用入力重複なしに正式保存する。
    引数: なし。165/166の凍結済み成果物だけを扱う。
    返り値: None。CSV/global/新7場/旧Source・条件を変更しない。
    """
    for trial,destination in [(165,T165),(166,T166)]:assert B.sha(destination/'条件.json')==BOOKS[trial]
    folders={165:'work/165順行と回復失敗の複合',166:'work/166可用指標の階層化'}
    all_sources={165:B.source_files(folders[165])+B.source_files('work/165独立確認')+B.source_files('work/165自然独立確認'),
        166:B.source_files(folders[166])+B.source_files('work/166自然独立確認')}
    diagnosis=ROOT/'work/166十五分MACD可用性の診断'
    assert diagnosis.exists(),'可用性診断の正式根拠待ち'
    all_sources[165]+=B.source_files(diagnosis.relative_to(ROOT).as_posix())
    all_sources[165]+=B.source_files('work/三時間軸の公開器')+[ROOT/'work/148全1分候補の当時特徴/legacy74.go']
    all_sources={trial:[p for p in paths if p.suffix!='.txt'] for trial,paths in all_sources.items()}
    own=B.source_files('work/165_166正式保存')
    for trial in all_sources:all_sources[trial]+=[p for p in own if p.suffix in ('.py','.md')]
    originals=set(all_sources[165]+all_sources[166])
    data={trial:[p for name in ('全出生','比較') for p in (ROOT/folder/name).iterdir() if p.is_file()] for trial,folder in folders.items()}
    for values in data.values():originals.update(values)
    before={path:B.sha(path) for path in originals}
    docs()
    parent_refs=[B.reference(ROOT/'inputs/00163_任意幅の共用価格索引/保存索引.json'),
        B.reference(ROOT/'inputs/00122_新規3場公表/指紋.json')]
    for p in [B.T162/'再現資料/Source.zip',B.T162/'再現資料/出生と探索.zip',B.T163/'再現資料/Source.zip',
        B.T163/'再現資料/出生と統計正本.zip',B.T164/'再現資料/Source.zip']:
        parent_refs.append(B.reference(p))
    for trial,destination in [(165,T165),(166,T166)]:
        reproduction(trial,destination);archive=destination/'再現資料';archive.mkdir(exist_ok=True)
        source_records=B.archive(archive/'Source.zip',all_sources[trial]);data_records=B.archive(archive/'出生と統計正本.zip',data[trial])
        refs=parent_refs.copy()
        if trial==166:refs.extend([B.reference(T165/'再現資料/Source.zip'),B.reference(T165/'再現資料/出生と統計正本.zip')])
        B.save(archive/'保存索引.json',{'成功':True,'試行':trial,'条件':B.reference(destination/'条件.json'),
            '実行環境':{'Python':sys.version,'NumPy':importlib.metadata.version('numpy'),'ijson':importlib.metadata.version('ijson'),
                'tzdata':importlib.metadata.version('tzdata'),'OS':platform.platform()},
            '正本':[{'archive':B.reference(archive/'Source.zip'),'members':source_records},
                {'archive':B.reference(archive/'出生と統計正本.zip'),'members':data_records}],
            '共用入力と親参照':refs,'非重複':'共有Raw/価格索引/Go観測/金融表/161cacheは再保存しない。166の165対照統計は小型controlsとして当時の結果に含まれるが親全統計/出生を再収録しない。',
            '区別':'事前固定主案・前48だけの固定選択・全期発見を別保存。新7場未使用。',
            '保存検査':'全ZIP CRC/サイズ/SHA/元byte同体と前後Source/数値SHA、条件不変。追加再現ラッパーはcompile/helpのみ。'})
    assert all(B.sha(path)==digest for path,digest in before.items())
    print(json.dumps({'成功':True,'凍結実体前後同体':len(before),
        '165保存索引':B.reference(T165/'再現資料/保存索引.json'),'166保存索引':B.reference(T166/'再現資料/保存索引.json')},ensure_ascii=False))


if __name__=='__main__':main()
