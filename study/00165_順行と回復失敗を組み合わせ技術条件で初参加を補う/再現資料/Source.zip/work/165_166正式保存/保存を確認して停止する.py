"""165/166の圧縮正本と文書・主要表を確認し、正式保存だけを停止する。"""
from pathlib import Path
from io import BytesIO
import hashlib
import json
import re
import shutil
import zipfile
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
TRIALS={165:'00165_順行と回復失敗を組み合わせ技術条件で初参加を補う',
    166:'00166_未公表の長期指標を捏造せず局所技術で参加を補う'}
FOLDERS={165:'work/165順行と回復失敗の複合',166:'work/166可用指標の階層化'}


def sha(path: Path) -> str:
    """
    機能: 物理ファイルを全読了して指紋化する。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    with path.open('rb') as source:return hashlib.file_digest(source,'sha256').hexdigest()


def read(path: Path) -> object:
    """
    機能: 標準JSONを解析する。
    引数: path(Path)。
    返り値: objectは解析値。
    """
    return json.loads(path.read_bytes())


def reference(path: Path) -> dict:
    """
    機能: 正式資料のサイズとSHAを参照する。
    引数: path(Path)。
    返り値: dictはリポジトリ相対参照。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':sha(path)}


def ref_check(record: dict) -> None:
    """
    機能: 索引の参照ファイルがサイズ・SHA同体か確認する。
    引数: record(dict)。
    返り値: None。
    """
    path=ROOT/record['path'];assert path.stat().st_size==record['bytes'] and sha(path)==record['sha256']


# ----------------------------------------
def main() -> None:
    """
    機能: 全ZIP・参照・V8・リンクと主/前半/発見のNPZ一致を自己確認する。
    引数: なし。自然結果の独立確認は別担当の票を正式コピーする。
    返り値: None。成功票と全正式資料停止指紋を保存する。
    """
    proof={'成功':True,'範囲':'正式保存の自己確認。金融自然値の独立検査は別担当の保存票へ参照。','試行':{}}
    for trial,name in TRIALS.items():
        destination=ROOT/'study'/name;index=read(destination/'再現資料/保存索引.json');assert index['成功'] and index['試行']==trial
        ref_check(index['条件'])
        for record in index['共用入力と親参照']:ref_check(record)
        members=0
        for group in index['正本']:
            ref_check(group['archive'])
            with zipfile.ZipFile(ROOT/group['archive']['path']) as archive:
                assert archive.testzip() is None
                assert set(archive.namelist())=={record['path'] for record in group['members']}
                for record in group['members']:
                    body=archive.read(record['path']);assert len(body)==record['bytes']
                    assert hashlib.sha256(body).hexdigest()==record['sha256'];ref_check(record);members+=1
                    assert not record['path'].startswith(('inputs/00163','work/163任意幅Raw索引/自然','work/163任意幅の数値化/自然'))
        documents=sorted(destination.glob('*.md'));assert len(documents)==4
        links=0
        for path in documents:
            text=path.read_text(encoding='utf-8',errors='strict')
            for target in re.findall(r'\[[^\]]+\]\(([^)]+)\)',text):
                if '://' in target or target.startswith('#'):continue
                actual=(path.parent/target.split('#')[0]).resolve()
                assert actual.exists() and not actual.is_relative_to((ROOT/'work').resolve()),(path,target)
                links+=1
        text=(destination/'設定と結果.md').read_text(encoding='utf-8')
        rows=[line for line in text.splitlines() if re.match(r'^\| [A-Z][0-9]{2} \|',line)]
        assert len(rows)==63 and all(len(line.split('|')[1:-1])==11 for line in rows)
        summary=read(ROOT/FOLDERS[trial]/'比較/主案と探索結果.json')
        axes=read(ROOT/FOLDERS[trial]/'比較/統計軸.json')
        npz_name='複合入口の統計配列.npz' if trial==165 else '階層化入口の統計配列.npz'
        cells=0
        with np.load(ROOT/FOLDERS[trial]/'比較'/npz_name,allow_pickle=False) as array:
            for record in [summary['事前固定主案'],summary['前48場だけで選択'],summary['頻度順上位'][0]]:
                if record is None:continue
                values=array['metrics'][tuple(record['position'])]
                for pi,period in enumerate(axes['periods']):
                    for fi,field in enumerate(axes['fields']):
                        saved=record['periods'][period][field];expected=np.nan if saved is None else saved
                        assert np.isclose(values[pi,fi],expected,equal_nan=True,rtol=0,atol=0);cells+=1
        qa_folder=ROOT/f'work/{trial}自然独立確認';qa=read(qa_folder/'自然の独立確認.json');assert qa['成功']
        assert read(qa_folder/'独立確認の停止.json')['成功']
        for source,filename in [(qa_folder/'自然の独立確認.json','自然結果の独立確認.json'),(qa_folder/'独立確認の停止.json','自然結果の独立停止.json')]:
            shutil.copyfile(source,destination/'検査'/filename)
        proof['試行'][str(trial)]={'保存索引':reference(destination/'再現資料/保存索引.json'),'ZIP全member':members,
            '文書数':len(documents),'ローカルリンク':links,'V8全セル':567,'主前半発見の統計欄':cells,
            '自然結果の独立票':reference(destination/'検査/自然結果の独立確認.json')}
    proof['保存確認SourceSHA256']=sha(Path(__file__))
    ticket=HERE/'正式保存の確認.json';ticket.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    for trial,name in TRIALS.items():
        destination=ROOT/'study'/name;copy=destination/'検査/正式保存の確認.json';shutil.copyfile(ticket,copy)
        paths=[p for p in destination.rglob('*') if p.is_file() and p.name!='正式保存の停止.json']
        stop={'成功':True,'保存確認Source':reference(Path(__file__)),'保存確認':reference(copy),
            '全正式ファイル':[reference(p) for p in sorted(paths)],'範囲':'165/166保存の停止。研究全体の継続を停止しない。'}
        p=destination/'検査/正式保存の停止.json';p.write_text(json.dumps(stop,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':main()
