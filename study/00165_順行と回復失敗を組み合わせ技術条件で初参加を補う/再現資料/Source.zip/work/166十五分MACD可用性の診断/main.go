package main

import (
	"encoding/json"
	"fmt"
	"os"
	"strings"

	frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
)

// artificial は実価格を使わず同じ公開器のMACD助走と欠足resetを観測します。
//
// 機能: 5/15/30分でHist初回34本・Δ初回35本を独立に確認します。
// 引数: missing(bool)は途中の子5分を一つ省く指定。
// 返り値: map[string]any/errorです。
func artificial(missing bool) (map[string]any, error) {
	scene := frame.Session{ID: "人工MACD", Contract: "人工A", Start: 300, End: 300 + 120*1800 + 300, EOF: 300 + 120*1800 + 300}
	children := []frame.ChildBar{}
	for at := scene.Start; at < scene.End; at += 300 {
		if missing && at == scene.Start+60*1800 {
			continue
		}
		p := 10000 + (at-scene.Start)/300
		children = append(children, frame.ChildBar{Start: at, End: at + 300, OHLC: frame.OHLC{Open: p, High: p + 2, Low: p - 1, Close: p + 1}, Volume: 10, Closed: true, VolumeKnown: true, Input: frame.FileRef{Path: "人工.csv", Bytes: 1, SHA256: strings.Repeat("a", 64)}, Row: uint64((at-scene.Start)/300 + 2)})
	}
	b, err := frame.BeginSession(scene, children, nil)
	if err != nil {
		return nil, err
	}
	frames, err := b.AdvanceObserved(scene.End, 1)
	if err != nil {
		return nil, err
	}
	result := map[string]any{}
	for _, width := range []int{300, 900, 1800} {
		firstHist, firstDelta, postHist, postDelta := uint64(0), uint64(0), uint64(0), uint64(0)
		reset := false
		unknown := 0
		for _, f := range frames {
			if f.WidthSeconds == width {
				if !f.PriceKnown {
					reset = true
					unknown++
					if f.Technical.Histogram.Known {
						return nil, fmt.Errorf("未知足でHist既知")
					}
					continue
				}
				h := f.Technical
				if h.Histogram.Known && firstHist == 0 {
					firstHist = h.HistoryBars
				}
				if h.Histogram.Known && h.PreviousHistogram.Known && firstDelta == 0 {
					firstDelta = h.HistoryBars
				}
				if reset && h.Histogram.Known && postHist == 0 {
					postHist = h.HistoryBars
				}
				if reset && h.Histogram.Known && h.PreviousHistogram.Known && postDelta == 0 {
					postDelta = h.HistoryBars
				}
			}
		}
		if firstHist != 34 || firstDelta != 35 || missing && (unknown != 1 || postHist != 34 || postDelta != 35) {
			return nil, fmt.Errorf("人工助走差:%d/%d/%d/%d/%d", width, firstHist, firstDelta, postHist, postDelta)
		}
		result[fmt.Sprint(width)] = map[string]any{"Hist初回の正常本数": firstHist, "Δ初回の正常本数": firstDelta, "未知足": unknown, "reset後Hist初回": postHist, "reset後Δ初回": postDelta}
	}
	return result, nil
}

// main は人工結果だけを未見市場へ依存せず保存します。
//
// 機能: 既存公開器の数値契約を票へ残します。
// 引数: ありません。返り値: ありません。失敗時panicします。
func main() {
	baseline, err := artificial(false)
	if err != nil {
		panic(err)
	}
	reset, err := artificial(true)
	if err != nil {
		panic(err)
	}
	body, err := json.MarshalIndent(map[string]any{"成功": true, "初回": baseline, "子5分欠足後": reset, "自然価格読取": false}, "", "  ")
	if err != nil {
		panic(err)
	}
	if err = os.WriteFile("MACD初回とreset人工.json", append(body, '\n'), 0600); err != nil {
		panic(err)
	}
}
