"""旧73場の公表・特徴・該当CSV時刻から15分MACD全未知の由来を調べる。"""
from pathlib import Path
import csv
import datetime
import gzip
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
TARGETS = ('2026-09-21_Day','2026-09-23_Day','2026-09-24_Day','2026-09-28_Day','2026-10-01_Day',
           '2026-10-13_Day','2026-10-14_Day','2026-10-21_Day','2026-10-28_Day')


def sha(path: Path) -> str:
    """
    機能: 固定済み既使用入力を指紋照合する。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def clock(at: float) -> str:
    """
    機能: 説明用時刻をJSTへ整形する。
    引数: at(float)。
    返り値: strはISO8601。
    """
    return datetime.datetime.fromtimestamp(at, datetime.timezone(datetime.timedelta(hours=9))).isoformat()


def pub_summary(scene: dict, width: int) -> dict:
    """
    機能: Hist本体・Δ・価格品質・連続助走を別集計する。
    引数: scene(dict)、width(int)。
    返り値: dictは公表単位の非金融診断。
    """
    frames = [p['frame']['frame'] for p in scene['publications'] if p['frame']['frame']['width_seconds'] == width]
    return {'公表数': len(frames), '価格未知数': sum(not f['price_known'] for f in frames),
            '初回history': frames[0]['technical']['history_bars'], '末尾history': frames[-1]['technical']['history_bars'],
            'Hist既知数': sum(f['technical']['histogram']['known'] for f in frames),
            'Δ既知数': sum(f['technical']['histogram']['known'] and f['technical']['previous_histogram']['known'] for f in frames),
            '最終公表足End': clock(frames[-1]['end'])}


def main() -> None:
    """
    機能: 全Hist特徴のknown算術と9場の欠5分→reset→助走不足を確認する。
    引数: なし。
    返り値: None。候補選択・損益・新7場は読まない。
    """
    background = ROOT / 'work/122全場入力/入力.json'
    features = ROOT / 'inputs/00148_全1分入口母集団/当時特徴.json.gz'
    catalog = ROOT / 'inputs/00148_全1分入口母集団/100特徴の列定義.json'
    plan_path = ROOT / 'work/122全場入力/公表生成計画.json'
    expected = {background:'6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec',
                features:'464dad9dce7acb20f043c344e96c9fa6d19ab0049a9d557e6fc96f6d189abcb7',
                catalog:'c85223fbe1543e5457c28d4391f817534099d1af1d19664035c668ff5fe8a7b4',
                plan_path:'584e0e95da786dfa4bcf527ed20c1222f237d068bbf5e302fddd6024a13fb7e5'}
    assert all(sha(path) == value for path,value in expected.items())
    data = json.loads(background.read_text(encoding='utf-8'))
    assert len(data['scenes']) == 73 and data['scenes'][-1]['session'] == '2026-11-10_Day'
    known_plan = {s['session']:s for s in json.loads(plan_path.read_text(encoding='utf-8'))['history']}
    frames = {p['frame']['frame']['id']:p['frame']['frame'] for s in data['scenes'] for p in s['publications']}
    columns = {c['name']:i for i,c in enumerate(json.loads(catalog.read_text(encoding='utf-8')))}
    counts = {s['session']:{'適格q0':0, **{f'm{w}_{suffix}':0 for w in (5,15,30)
                for suffix in ('hist_to_side','hist_delta_to_side','ema21_delta_to_side','atr','価格fresh')}} for s in data['scenes']}
    checked = 0
    feature_rows = json.loads(gzip.decompress(features.read_bytes()))['rows']
    for row in feature_rows:
        stats = counts[row['session']]; stats['適格q0'] += 1
        for width in (5,15,30):
            foot = row['metadata']['feet'][f'm{width}']
            f = frames[foot['id']] if foot else None
            if f and f['price_known']:
                stats[f'm{width}_価格fresh'] += 1
            for suffix in ('hist_to_side','hist_delta_to_side','ema21_delta_to_side','atr'):
                stats[f'm{width}_{suffix}'] += row['buy']['x'][columns[f'm{width}_{suffix}']] is not None
            for suffix in ('hist_to_side','hist_delta_to_side'):
                field = columns[f'm{width}_{suffix}']
                t = f['technical'] if f else None
                known = bool(f and f['price_known'] and t['histogram']['known'] and (suffix == 'hist_to_side' or t['previous_histogram']['known']))
                for side, sign in (('buy',1),('sell',-1)):
                    value = row[side]['x'][field]
                    assert (value is not None) == known
                    if known:
                        expected_value = sign * (t['histogram']['value'] - (t['previous_histogram']['value'] if suffix == 'hist_delta_to_side' else 0))
                        assert value == expected_value
                    checked += 1
    feature_rows = None
    reports=[]; missing_rows=[]
    for i,scene in enumerate(data['scenes']):
        if scene['session'] not in TARGETS:
            continue
        assert counts[scene['session']]['m15_hist_to_side'] == counts[scene['session']]['m15_hist_delta_to_side'] == 0
        previous = data['scenes'][i-1] if i else None
        report = {'場':scene['session'],'限月':scene['contract'],'特徴可用性':counts[scene['session']],
                  '公表可用性':{str(w):pub_summary(scene,w) for w in (300,900,1800)},
                  '前場':previous['session'] if previous else None,
                  '前場公表可用性':{str(w):pub_summary(previous,w) for w in (300,900,1800)} if previous else None}
        if previous:
            assert previous['contract'] == scene['contract']
            reference = known_plan[previous['session']]['csv']
            csv_path = Path(reference['path']); assert sha(csv_path) == reference['sha256']
            with csv_path.open(encoding='utf-8-sig',newline='') as stream:
                csv_rows = list(csv.DictReader(stream))
            starts = {datetime.datetime.fromisoformat(row['time']).timestamp() for row in csv_rows}
            for p in previous['publications']:
                f=p['frame']['frame']
                if f['width_seconds'] != 900 or f['price_known']:
                    continue
                for child in f['children'][:f['child_count']]:
                    if child['price_known']:
                        continue
                    assert not child['present'] and child['start'] not in starts
                    missing_rows.append({'翌Day':scene['session'],'前Night':previous['session'],'15分足End':clock(f['end']),
                        '欠5分開始':clock(child['start']),'子足理由':f['reason'],'CSV本文で時刻行なしを確認':True,
                        'CSV参照':reference})
        reports.append(report)
    assert len(reports)==9 and len(missing_rows)==17
    result={'成功':True,'対象':list(TARGETS),'9場全てHist本体とΔとも全未知':True,
            '全73全100Xから検算したHist本体とΔセル':checked,'特徴の既知性又は値の不一致':0,
            '原因内訳':{'初回cold':1,'前Nightの欠5分→15分価格未知→全数値reset':8},
            '限月変更':False,'Hist初回正常本数':34,'Δ初回正常本数':35,
            '当該Dayの15分公表数':27,'当該Dayのhistory範囲':'1〜6で開始し27〜32で終了',
            '欠5分由来':missing_rows,'9場':reports,'全73特徴可用性':counts,
            '時間帯との関係':'未知足resetを受けたDayで長期助走が終わらず偏る。帯属性を足しても全known必須の前置条件は通らない。',
            '欠足の原因として未判定':'5分の保存行がないことまで確認。取引なし/配信停止/保存欠落の内訳はRawへ追加調査していない。',
            '入力':[{'path':str(path.relative_to(ROOT)),'sha256':value,'bytes':path.stat().st_size} for path,value in expected.items()],
            '未見7場価格読取':False,'金融又は候補損益参照':False,'旧Source変更':False}
    (HERE/'原因と可用性.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ('9場','全73特徴可用性','欠5分由来','入力')},ensure_ascii=False))


if __name__=='__main__':
    main()
