"""165の技術初参加controllerと失速確認出生を独立人工で検査する。"""
from pathlib import Path
from types import SimpleNamespace
import ast
import copy
import hashlib
import importlib.util
import json
import math
import sys

import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
SOURCE=ROOT/'work/165順行と回復失敗の複合'
BOOK=ROOT/'study/00165_順行と回復失敗を組み合わせ技術条件で初参加を補う/条件.json'
BOOK_SHA='f2b6aace1ee8fe79b3977d79fc2346cc03fd3c752f15609a628a3f189c93b5af'


def sha(path: Path) -> str:
    """
    機能: 物理bytesの指紋を求める。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    with path.open('rb') as source:return hashlib.file_digest(source,'sha256').hexdigest()


def load(path: Path,name: str) -> object:
    """
    機能: mainを実行せず対象Sourceを読み込む。
    引数: path(Path)、name(str)はSourceとmodule名。
    返り値: objectはmodule。
    """
    spec=importlib.util.spec_from_file_location(name,path);out=importlib.util.module_from_spec(spec)
    sys.modules[name]=out;spec.loader.exec_module(out);return out


class EntryOnly(dict):
    """金融配列へのアクセス自体を禁止する人工入力。"""
    def __getitem__(self,key: str) -> np.ndarray:
        """
        機能: entry物理時計以外を読もうとした時点で失敗させる。
        引数: key(str)は要求キー。
        返り値: np.ndarrayは取得時計。金融/教師キーはAssertionError。
        """
        assert key in ('entry_time','entry_index','entry_line'),('金融配列を参照',key)
        return super().__getitem__(key)


def fixture(rows: list,core_flags: np.ndarray,module: object) -> tuple:
    """
    機能: 人工の物理取得・要求終了を持つ73場contextを作る。
    引数: rows(list[dict])はq0/capture、core_flags(np.ndarray[int8])、module(object)は対象。
    返り値: tupleはContext代替と独立に物理一意化した主Selection。
    """
    keys={tuple(r['fill']):r['scene'] for r in rows if r['status']=='filled'}
    ordered=sorted(keys);case_map={str(k):i for i,k in enumerate(ordered)}
    scene=np.array([keys[k] for k in ordered],dtype=np.int16)
    arrays=EntryOnly({f'entry_{n}':np.asarray([k[j] for k in ordered],dtype=np.float64 if j==0 else np.int64)
        for j,n in enumerate(('time','index','line'))})
    captures=[];end=[]
    for row in rows:
        key=tuple(row.get('end',(row['q0'][0]+300,math.inf,math.inf)))
        captures.append({'status':row['status'],'case_id':str(tuple(row['fill'])) if row['status']=='filled' else None,
            'terminated_at':key,'expires':row['q0'][0]+300})
        end.append(key)
    scenes=[{'start':s*100000.0} for s in range(73)]
    context=SimpleNamespace(case_scene=scene,arrays=arrays,capture_rows=captures,end_keys=end,
        case_map=case_map,event_keys=[tuple(r['q0']) for r in rows],
        scene_events=[np.array([i for i,r in enumerate(rows) if r['scene']==s],dtype=np.int32) for s in range(73)],
        event_phases=np.array([i%3 for i in range(len(rows))],dtype=np.int8),scenes=scenes,sessions=[str(i) for i in range(73)])
    selected=[];seen=set()
    for event,side in enumerate(core_flags):
        row=rows[event]
        if side and row['status']=='filled':
            case=case_map[str(tuple(row['fill']))]
            if case not in seen:selected.append((case,0 if side==1 else 1,event,event%3));seen.add(case)
    columns=list(zip(*selected)) if selected else [[],[],[],[]]
    core=module.Selection(*(np.array(v,dtype=np.int32 if i in (0,2) else np.int8) for i,v in enumerate(columns)),np.zeros(len(selected),dtype=bool))
    return context,core


def event_oracle(rows: list,core_flags: np.ndarray,technical: np.ndarray,context: object) -> list:
    """
    機能: q0時点で終了/取得を反映するイベントシミュレーションから期待取得を作る。
    引数: rows(list[dict])、core_flags/technical(np.ndarray[int8])、context(object)は人工のみ。
    返り値: list[tuple]はcase/side/event/phase/origin。後の主取得で既予約Tを取り消さない。
    """
    acquired=[]
    for scene in range(73):
        active_core=[];active_technical=None;main_seen=False;technical_done=False
        for event,row in enumerate(rows):
            if row['scene']!=scene:continue
            now=tuple(row['q0']);remaining=[]
            for request in active_core:
                if tuple(rows[request]['end'])<=now:
                    if rows[request]['status']=='filled':main_seen=True
                else:remaining.append(request)
            active_core=remaining
            if active_technical is not None and tuple(rows[active_technical]['end'])<=now:
                if rows[active_technical]['status']=='filled':technical_done=True
                active_technical=None
            if core_flags[event]:
                active_core.append(event)
                if row['status']=='filled':
                    acquired.append((context.case_map[str(tuple(row['fill']))],0 if core_flags[event]==1 else 1,event,event%3,0))
                continue
            if now[0]<scene*100000+2700 or main_seen or technical_done or active_core or active_technical is not None or not technical[event]:continue
            active_technical=event
            if row['status']=='filled':
                acquired.append((context.case_map[str(tuple(row['fill']))],0 if technical[event]==1 else 1,event,event%3,2))
    seen=set();out=[]
    for row in sorted(acquired,key=lambda r:(r[2],r[4])):
        if row[0] not in seen:seen.add(row[0]);out.append(row)
    return out


def actual_rows(selected: object,origins: np.ndarray) -> list:
    """
    機能: 対象の返り値を比較用の不変tupleへ変換する。
    引数: selected(object)、origins(np.ndarray)は対象返り値。
    返り値: list[tuple]は全属性。
    """
    assert not selected.old.any()
    return [tuple(map(int,row)) for row in zip(selected.cases,selected.sides,selected.events,selected.phases,origins,strict=True)]


def controller_case(rows: list,main: list,technical: list,module: object) -> list:
    """
    機能: 1人工を独立イベント順oracleと照合し、同時に金融読取を禁止する。
    引数: rows(list[dict])、main/technical(list[int])、module(object)は対象。
    返り値: list[tuple]は一致した取得。
    """
    main=np.array(main,dtype=np.int8);technical=np.array(technical,dtype=np.int8)
    context,core=fixture(rows,main,module)
    expected=event_oracle(rows,main,technical,context)
    selected,origins,audit=module.Context165.technical_integrate(context,main,core,technical)
    actual=actual_rows(selected,origins);assert actual==expected,(rows,main,technical,expected,actual)
    assert len(audit)==73 and all(row['financial_not_used'] for row in audit)
    json.dumps(audit,allow_nan=False)
    # 金額/教師の全未来を追加・変化させても、金融キーを読むと例外になるまま結果は同じ。
    for name in ('net','known','label','known_at','net0','net5'):
        dict.__setitem__(context.arrays,name,np.array([np.inf,np.nan,-1e300,1e300]))
    poisoned,poison_origins,_=module.Context165.technical_integrate(context,main,core,technical)
    assert actual_rows(poisoned,poison_origins)==actual
    return actual


def row(now: float,status: str='filled',fill: tuple|None=None,end: tuple|None=None,scene: int=0,index: int|None=None) -> dict:
    """
    機能: q1がq0より後にある人工captureを作る。
    引数: now(float)、status(str)、fill/end(tuple又はNone)、scene/int、index(int又はNone)。
    返り値: dictは人工物理行。
    """
    q=(now,int(now*10) if index is None else index,int(now*10)+1 if index is None else index+1)
    if fill is None:fill=(now+20,int((now+20)*10),int((now+20)*10)+1)
    if end is None:end=fill if status=='filled' else (now+60,int((now+60)*10),int((now+60)*10)+1)
    assert tuple(fill)>q if status=='filled' else tuple(end)>q
    return {'q0':q,'status':status,'fill':fill,'end':end,'scene':scene}


def fade_oracle(original: np.ndarray,confirmation: np.ndarray,background: np.ndarray,scenes: np.ndarray,times: np.ndarray,lifetime: int) -> np.ndarray:
    """
    機能: 最後の遷移と未消費armの辞書から失速確認の期待値を作る。
    引数: original(np.ndarray)、confirmation/background(np.ndarray)、scenes/times(np.ndarray)、lifetime(int秒)。
    返り値: np.ndarray[int8]は場/時間ギャップと初確認を反映した出生。
    """
    arms={};prior_side=0;output=[]
    for i,side in enumerate(map(int,original)):
        if not i or scenes[i]!=scenes[i-1] or times[i]-times[i-1]>180:arms={};prior_side=0
        if side and side!=prior_side:arms[-side]=times[i]
        hits=[]
        for intended,at in list(arms.items()):
            if times[i]>at+lifetime:del arms[intended];continue
            side_index=0 if intended==1 else 1
            if bool(confirmation[side_index,i]) and bool(background[side_index,i]):
                hits.append(intended);del arms[intended]
        output.append(hits[0] if len(hits)==1 else 0);prior_side=side
    return np.array(output,dtype=np.int8)


def check_fades(module: object,rng: object) -> dict:
    """
    機能: 失速出生の期限境界、reset、対称性、未来毒を検査する。
    引数: module(object)は対象、rng(object)は固定seed乱数。
    返り値: dictは検査件数。
    """
    cases=0;prefixes=0;mirrors=0
    manual=[([1]*8,[0,60,120,180,240,300,360,420],[5],[-1 if i==5 else 0 for i in range(8)]),
        ([1]*8,[0,60,120,180,240,300,360,420],[6],[0]*8),
        ([1,0,1,0],[0,60,120,180],[3],[0,0,0,-1]),
        ([1,0],[0,181],[1],[0,0]),([1,0],[0,180],[1],[0,-1])]
    for original,times,hit,expected in manual:
        n=len(original);conf=np.zeros((2,n),dtype=bool);conf[1,hit]=True
        actual=module.confirmed_fade(np.array(original,dtype=np.int8),conf,np.ones((2,n),bool),np.zeros(n),np.array(times),300)
        assert actual.tolist()==expected,(actual,expected);cases+=1
    for _ in range(500):
        n=int(rng.integers(2,160));times=np.cumsum(rng.choice([0,1,30,60,180,181,240],n)).astype(float)
        scenes=np.cumsum(rng.random(n)<.03);original=rng.choice([-1,0,1],n).astype(np.int8)
        confirmation=rng.random((2,n))<.35;background=rng.random((2,n))<.7;lifetime=int(rng.choice([60,300,600]))
        expected=fade_oracle(original,confirmation,background,scenes,times,lifetime)
        actual=module.confirmed_fade(original,confirmation,background,scenes,times,lifetime)
        assert np.array_equal(actual,expected);cases+=1
        mirrored=module.confirmed_fade(-original,confirmation[::-1],background[::-1],scenes,times,lifetime)
        assert np.array_equal(mirrored,-actual);mirrors+=1
        cut=int(rng.integers(1,n));poison=original.copy();poison[cut:]=rng.choice([-1,0,1],n-cut)
        pc=confirmation.copy();pb=background.copy();pc[:,cut:]=~pc[:,cut:];pb[:,cut:]=~pb[:,cut:]
        assert np.array_equal(module.confirmed_fade(poison,pc,pb,scenes,times,lifetime)[:cut],actual[:cut]);prefixes+=1
    return {'独立oracle人工':cases,'売買鏡像':mirrors,'未来毒prefix':prefixes}


def check_technical(module: object,library: object,columns: list) -> dict:
    """
    機能: 複合票の実派生、必須列未知、閾値と売買対称性を人工で確認する。
    引数: module/library(object)は対象出生と162派生、columns(list)は当時100列名。
    返り値: dictは検査件数。
    """
    names=[x['name'] if isinstance(x,dict) else x for x in columns];index={n:i for i,n in enumerate(names)}
    buy=np.zeros((1,100));sell=np.zeros((1,100))
    positive={**{f'm{m}_ema21_delta_to_side':1 for m in (5,15,30)},
        **{f'm{m}_di_difference_to_side':1 for m in (5,15,30)},
        'm5_hist_delta_to_side':1,'m15_hist_delta_to_side':1,'m5_rsi_delta_to_side':2,'m15_rsi_delta_to_side':1,
        'm5_body_ratio_to_side':.5,'m5_close_position_to_side':.8,'m1_volume_relative_prior3':1,
        'bb15_position_sigma_to_side':0,'bb15_forward_room_125_ratio_to_side':1,
        'q0_entry_minus_ema8_atr5_to_side':.25,'m5_tr_atr_ratio':1,'q0_spread_points':10,
        'q0_last_minus_m1_close_atr5_to_side':.25,'m5_rsi_center_to_side':10}
    for name,value in positive.items():
        buy[0,index[name]]=value
        sell[0,index[name]]=1-value if name=='m5_close_position_to_side' else -value if name.endswith('_to_side') else value
    checked=0
    for width in (150,200):
        evaluate=library.PreparedEvaluator(buy,sell,columns,target_points=width)
        baseline=module.technical_first(object(),evaluate);assert baseline.tolist()==[1];checked+=1
        assert module.technical_first(object(),library.PreparedEvaluator(sell,buy,columns,target_points=width)).tolist()==[-1];checked+=1
        required=['m5_ema21_delta_to_side','m15_ema21_delta_to_side','m30_ema21_delta_to_side',
            'm5_di_difference_to_side','m15_di_difference_to_side','m30_di_difference_to_side',
            'm5_hist_delta_to_side','m15_hist_delta_to_side','m5_rsi_delta_to_side','m15_rsi_delta_to_side',
            'm5_body_ratio_to_side','m5_close_position_to_side','m1_volume_relative_prior3',
            'bb15_position_sigma_to_side','bb15_forward_room_125_ratio_to_side','q0_entry_minus_ema8_atr5_to_side','m5_tr_atr_ratio',
            'q0_spread_points','q0_last_minus_m1_close_atr5_to_side','m5_rsi_center_to_side']
        for name in required:
            a=buy.copy();b=sell.copy();a[0,index[name]]=np.nan;b[0,index[name]]=np.nan
            assert module.technical_first(object(),library.PreparedEvaluator(a,b,columns,target_points=width)).tolist()==[0],name
            checked+=1
        for name,value,expected in [('q0_spread_points',20,1),('q0_spread_points',20.00001,0),('q0_spread_points',0,0),
            ('q0_entry_minus_ema8_atr5_to_side',1,1),('q0_entry_minus_ema8_atr5_to_side',1.00001,0),
            ('m5_rsi_center_to_side',25,1),('m5_rsi_center_to_side',25.00001,0),
            ('m5_rsi_delta_to_side',12,1),('m5_rsi_delta_to_side',12.00001,0),
            ('q0_last_minus_m1_close_atr5_to_side',1,1),('q0_last_minus_m1_close_atr5_to_side',1.00001,0),
            ('m1_volume_relative_prior3',.5,1),('m1_volume_relative_prior3',.49999,0)]:
            a=buy.copy();a[0,index[name]]=value
            assert module.technical_first(object(),library.PreparedEvaluator(a,sell,columns,target_points=width)).tolist()==[expected],(width,name,value)
            checked+=1
        for first,second,expected in [(5,4,1),(5,4.00001,0),(4.99999,3,0),(5,5,0),(math.nan,4,0)]:
            prepared=library.PreparedEvaluator(buy,sell,columns,target_points=width)
            class ScoreOverride:
                """実派生の票だけを境界値へ置換する人工評価器。"""
                def factor(self,side: int,name: str) -> tuple:
                    """
                    機能: score以外は実100列の派生を利用する。
                    引数: side(int)、name(str)は実側と要求派生。
                    返り値: tuple[np.ndarray,np.ndarray]は値と既知。
                    """
                    if name=='technical_score':
                        value=np.array([first if side==0 else second]);return value,np.isfinite(value)
                    return prepared.factor(side,name)
            assert module.technical_first(object(),ScoreOverride()).tolist()==[expected],(first,second)
            checked+=1
    return {'実100列派生と票境界の人工':checked,'各側必須有限列':20}


def check_widths(module: object) -> dict:
    """
    機能: 最初の出生枝とT/旧由来に従う幅、入力不正時の例外を確認する。
    引数: module(object)は対象評価基盤。
    返り値: dictは成功した正常/例外検査件数。
    """
    grid=[125,150,175,200,225,250,300,350,400,500,750,1000]
    context=SimpleNamespace(table=SimpleNamespace(widths=grid))
    selected=module.Selection(np.arange(4),np.array([0,1,0,1],dtype=np.int8),np.array([3,5,-1,-1]),np.zeros(4,dtype=np.int8),np.array([0,0,0,1],bool))
    origins=np.array([0,0,2,1],dtype=np.int8);branches=np.array([-1,-1,-1,0,-1,1],dtype=np.int8)
    values=module.widths_for_selection(context,selected,origins,branches,200,400,150)
    assert [grid[int(i)] for i in values]==[200,400,150,200]
    selected.sides=1-selected.sides
    assert np.array_equal(module.widths_for_selection(context,selected,origins,branches,200,400,150),values)
    errors=0
    bad=branches.copy();bad[3]=-1
    try:module.widths_for_selection(context,selected,origins,bad,200,400,150)
    except AssertionError:errors+=1
    else:raise AssertionError('主枝未知を受理')
    try:module.widths_for_selection(context,selected,origins,branches,201,400,150)
    except ValueError:errors+=1
    else:raise AssertionError('未登録幅を受理')
    return {'由来と枝の幅割当':1,'売買対称':1,'不正入力例外':errors}


# ----------------------------------------
def main() -> None:
    """
    機能: 金融を入力しないcontroller/純出生人工とSource・入力契約を検査する。
    引数: なし。165自然金融結果は読まない。
    返り値: None。検査票を本作業域へ保存する。
    """
    assert sha(BOOK)==BOOK_SHA
    sources=[BOOK,SOURCE/'出生を作る.py',SOURCE/'評価基盤165.py',ROOT/'work/162複合入口候補/rules162.py',
        SOURCE/'全出生/全出生の確認.json',SOURCE/'全出生/複合と技術補完.npz',
        ROOT/'work/151過去場判別の評価/入口選択/cache/feature_only/features_meta.json',
        ROOT/'work/151過去場判別の評価/入口選択/cache/feature_only/features.npz']
    before={str(p.relative_to(ROOT)):sha(p) for p in sources}
    births=load(sources[1],'audit165_births');controller=load(sources[2],'audit165_controller');library=load(sources[3],'audit165_rules')
    rng=np.random.default_rng(165)
    # 45分境界、未決終了の同秒原行、TTL、同q0優先、同q1最初要求、後発主での取消禁止。
    cases=[
        ([row(2699),row(2700),row(2760)],[0,0,0],[1,1,-1]),
        ([row(2700),row(2760)],[1,0],[-1,-1]),
        ([row(2700,fill=(2900,29000,29001)),row(2760),row(2940)],[1,0,0],[0,1,1]),
        ([row(2700,'cancelled',end=(2800,28010,28011)),row(2800,index=28000),row(2800,index=28020)],[1,0,0],[0,1,1]),
        ([row(2700,'expired',end=(3000,math.inf,math.inf)),row(3000),row(3001)],[1,0,0],[0,1,1]),
        ([row(2700,'cancelled',end=(2800,28000,28001)),row(2760),row(2820)],[0,0,0],[1,1,-1]),
        ([row(2700,fill=(2950,29500,29501)),row(2760,fill=(2900,29000,29001))],[0,1],[1,0]),
        ([row(2700,fill=(2900,29000,29001)),row(2760,fill=(2900,29000,29001))],[0,-1],[1,0]),
        ([row(2700,fill=(2900,29000,29001)),row(2760,fill=(2900,29000,29001))],[1,0],[0,-1]),
        ([row(2700),row(102700,scene=1)],[0,0],[1,-1]),
    ]
    for rows,core,technical in cases:controller_case(rows,core,technical,controller)
    manual=len(cases);random_cases=0
    for _ in range(600):
        rows=[]
        for scene in range(2):
            now=scene*100000+2400
            for i in range(int(rng.integers(8,28))):
                now+=int(rng.choice([0,30,60,120]));index=int(now*10+i*2)
                fill_time=math.ceil(now/180)*180+30;fill=(fill_time,int(fill_time*10),int(fill_time*10)+1)
                if fill<= (now,index,index+1):fill=(now+30,int((now+30)*10),int((now+30)*10)+1)
                status=str(rng.choice(['filled','cancelled','expired'],p=[.65,.25,.1]))
                end=fill if status=='filled' else (now+300,math.inf,math.inf) if status=='expired' else (now+int(rng.choice([1,30,60,120])),index+10000,index+10001)
                rows.append(row(now,status,fill,end,scene,index))
        core=rng.choice([-1,0,1],len(rows),p=[.12,.76,.12]).tolist();technical=rng.choice([-1,0,1],len(rows)).tolist()
        controller_case(rows,core,technical,controller);random_cases+=1
    fading=check_fades(births,rng)
    metadata=json.loads(sources[-2].read_text(encoding='utf-8'))
    contract_sets={i:set() for i in range(73)}
    for q in metadata['q0_meta']:contract_sets[q['session_index']].add(q['contract'])
    assert all(len(v)==1 for v in contract_sets.values())
    with np.load(sources[-1],allow_pickle=False) as source:columns=source['columns'].tolist()
    technical=check_technical(births,library,columns)
    widths=check_widths(controller)
    with np.load(SOURCE/'全出生/複合と技術補完.npz',allow_pickle=False) as source:
        directions=source['directions'];branches=source['branches'];fallback=source['technical']
        assert directions.shape==branches.shape==(240,35339) and fallback.shape==(2,35339)
        assert np.isin(directions,(-1,0,1)).all() and np.isin(fallback,(-1,0,1)).all()
        assert np.array_equal(directions==0,branches==-1) and np.isin(branches,(-1,0,1)).all()
    assert all(sha(ROOT/p)==fingerprint for p,fingerprint in before.items())
    result={'成功':True,'条件SHA256':BOOK_SHA,'Sourceと入力':before,
        'controller手作り境界人工':manual,'controller独立イベント順乱数人工':random_cases,
        '全controller人工に金融読取禁止と未来金額毒':True,'監査JSON標準直列化':True,'controller対象場数':73,
        'confirmed_fade':fading,'technical_first':technical,'取得幅':widths,
        '封印された純特徴方向と枝の整合':True,
        '入力契約':{'場数':73,'各場単一限月':True,'q0数':len(metadata['q0_meta'])},
        '165自然金融を読んだ':False,'Source変更':False,
        '範囲':'新controllerと純出生の人工/静的検査。240自然profileの全出生再生成・金融成績再集計ではない。'}
    HERE.mkdir(exist_ok=True)
    (HERE/'人工と静的な確認.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='Sourceと入力'},ensure_ascii=False))


if __name__=='__main__':
    main()
