"""163/164の条件と共用価格索引の保存参照を、数値再計算なしで確認する。"""
from pathlib import Path
import ast
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
SHARED=ROOT/'inputs/00163_任意幅の共用価格索引'
TRIALS={163:('00163_履歴を含む複合入口を任意幅と場末まで検証する','a4e5a3ad0417b5790a7f17e768327648e27790d25867092e5e60944ed2863b10'),
    164:('00164_IFD最初到達の確定時計で入口と反転を比較する','e415f92ee290b8adad74e378255432e384114d67abe16082505af06a10b65f5d')}


def sha(path: Path) -> str:
    """
    機能: ファイルを全読了してSHA256を計算する。
    引数: path(Path)。
    返り値: strは小文字の物理指紋。
    """
    with path.open('rb') as source:return hashlib.file_digest(source,'sha256').hexdigest()


def read(path: Path) -> object:
    """
    機能: UTF-8 JSONを読み込む。
    引数: path(Path)。
    返り値: objectはJSON値。保存数値の再計算はしない。
    """
    return json.loads(path.read_text(encoding='utf-8',errors='strict'))


def relative_ref(folder: Path,record: dict) -> dict:
    """
    機能: manifest内の相対参照が同じ保存ディレクトリの実体へ結ぶことを確認する。
    引数: folder(Path)、record(dict)はpath/sha256を持つ参照。
    返り値: dictは解決位置と指紋。元Rawの絶対由来pathは開かない。
    """
    target=Path(record['path']);assert not target.is_absolute() and '..' not in target.parts
    path=(folder/target).resolve();assert path.is_relative_to(folder.resolve())
    assert path.is_file() and sha(path)==record['sha256']
    return {'path':str(path.relative_to(ROOT)),'bytes':path.stat().st_size,'sha256':record['sha256']}


def main() -> None:
    """
    機能: 152共有実体の指紋・由来・相対manifest連鎖と163/164条件を先行検査する。
    引数: なし。165や未見2場のファイルは開かない。
    返り値: None。work配下へ独立確認票だけを保存する。
    """
    index_path=SHARED/'保存索引.json';index=read(index_path);assert index['成功']
    files=index['files'];assert len(files)==152
    seen=set();originals=0;total=0
    for record in files:
        path=(ROOT/record['path']).resolve()
        assert path.is_relative_to(SHARED.resolve()) and path not in seen
        seen.add(path);assert path.stat().st_size==record['bytes'] and sha(path)==record['sha256']
        original=ROOT/record['origin']
        if original.exists():
            assert original.stat().st_size==record['bytes'] and sha(original)==record['sha256'];originals+=1
        assert '2026-11-10_Night' not in path.name and '2026-11-11_Day' not in path.name
        total+=record['bytes']
    actual={p.resolve() for p in SHARED.rglob('*') if p.is_file() and p!=index_path and p.name!='README.md'}
    assert actual==seen
    price=read(SHARED/'価格索引/manifest.json');observed=read(SHARED/'Raw観測/manifest.json')
    assert price['success'] and observed['success']
    assert len(price['scenes'])==len(observed['scenes'])==73
    assert [r['session'] for r in price['scenes']]==[r['session'] for r in observed['scenes']]
    assert price['source_entry_count']==observed['source_entry_count']==31642
    assert observed['index_manifest_sha256']==sha(SHARED/'価格索引/manifest.json')
    relative=[]
    for scene in price['scenes']:
        relative.append(relative_ref(SHARED/'価格索引',scene['index']))
        assert relative[-1]['bytes']==scene['index_bytes']
    for scene in observed['scenes']:
        relative.append(relative_ref(SHARED/'Raw観測',scene['file']))
        assert relative[-1]['bytes']==scene['bytes']
    numerical=read(SHARED/'数値表/完了.json');proof=read(SHARED/'数値表/入力と数値化の確認.json')
    assert numerical['成功'] and proof['成功']
    assert numerical['確認票SHA256']==sha(SHARED/'数値表/入力と数値化の確認.json')
    for name,record in numerical['cache'].items():relative.append(relative_ref(SHARED/'数値表',{'path':name,**record}))
    assert numerical['幅']==observed['config']['widths']
    assert numerical['時計']==[r['id'] for r in observed['config']['horizons']]
    conditions={}
    for trial,(folder,expected_sha) in TRIALS.items():
        path=ROOT/'study'/folder/'条件.json';assert sha(path)==expected_sha
        book=read(path);assert book['trial']==trial and book['candidate_count']==1460
        assert book['widths']==numerical['幅'] and [h['id'] for h in book['horizons']]==numerical['時計']
        conditions[str(trial)]={'path':str(path.relative_to(ROOT)),'sha256':expected_sha}
    source_info=[];source_folder=ROOT/'work/163_164正式保存'
    for path in source_folder.glob('*.py'):
        text=path.read_text(encoding='utf-8',errors='strict');tree=ast.parse(text)
        functions=[node for node in ast.walk(tree) if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef))]
        missing=[]
        for node in functions:
            doc=ast.get_docstring(node)
            if not doc or '\n' not in doc or not all(s in doc for s in ('機能','引数','返り値')):missing.append(node.name)
        assert not missing,(path.name,missing)
        source_info.append({'path':str(path.relative_to(ROOT)),'sha256':sha(path),'functions':len(functions),'comment_errors':missing})
    output={'成功':True,'範囲':'共有入力の物理保存・manifest参照・条件と正式保存Sourceの静的検査。自然統計の全面再計算なし。',
        '共有索引SHA256':sha(index_path),'共有READMEのSHA256':sha(SHARED/'README.md'),
        '共有実体数':len(files),'総bytes':total,'work由来同体':originals,
        '相対参照数':len(relative),'条件':conditions,'正式保存Source':source_info,
        '165と未見2場のファイル読取':False,'検査SourceSHA256':sha(Path(__file__))}
    (HERE/'共有入力と条件の先行確認.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(output,ensure_ascii=False))


if __name__=='__main__':
    main()
