"""163/164の正式保存を、自然計算を再実行せず独立に照合する。"""
from pathlib import Path, PurePosixPath
import ast
import hashlib
import json
import re
from urllib.parse import unquote
import zipfile

import numpy as np
from 先行確認 import ROOT,HERE,TRIALS,read,sha


def rows(path: Path) -> list:
    """
    機能: 汎用表の手法IDと9尺度を持つ63行を読む。
    引数: path(Path)はUTF-8のMarkdown。
    返り値: listはID・名称・9尺度の11欄。
    """
    answer=[]
    for line in path.read_text(encoding='utf-8').splitlines():
        cells=[c.strip() for c in line.split('|')[1:-1]] if line.startswith('|') else []
        if len(cells)==11 and re.fullmatch(r'[A-Z]\d{2}',cells[0]):answer.append(cells)
    return answer


def linked(path: Path,target: str) -> Path|None:
    """
    機能: ローカル文書リンクだけを相対解決する。
    引数: path(Path)は親文書、target(str)はMarkdownの参照先。
    返り値: Path又はNone。URLや同頁アンカーの内容は取得しない。
    """
    target=unquote(target.strip().strip('<>'))
    if re.match(r'^[A-Za-z]+://',target) or target.startswith('#'):return None
    target=target.split('#',1)[0]
    return (path.parent/target).resolve() if target else None


def file_ref(record: dict) -> None:
    """
    機能: 索引参照のbyte数とSHA256を現物で確認する。
    引数: record(dict)はpath/bytes/sha256を持つ。
    返り値: None。不整合はassert停止。
    """
    path=ROOT/record['path'];assert path.is_file(),record['path']
    assert path.stat().st_size==record['bytes'] and sha(path)==record['sha256'],record['path']


def archives(index: dict) -> list:
    """
    機能: ZIPを展開せず全CRC・member指紋・work原本との同体を照合する。
    引数: index(dict)は正式保存索引。
    返り値: listは各ZIPの件数、由来照合数、指紋。
    """
    answers=[]
    for record in index['正本']:
        file_ref(record['archive']);path=ROOT/record['archive']['path']
        expected={r['path']:r for r in record['members']};same=0;source_functions=0
        with zipfile.ZipFile(path) as source:
            assert source.testzip() is None
            names=source.namelist();assert len(names)==len(set(names))==len(expected)
            assert set(names)==set(expected)
            for name in names:
                relative=PurePosixPath(name);assert not relative.is_absolute() and '..' not in relative.parts
                assert not any(s in name for s in ('00165_','2026-11-10_Night','2026-11-11_Day'))
                assert not name.startswith(('inputs/','work/161三時間帯入口のデータ/feature2cache/'))
                assert not any(s in name for s in ('/自然索引/','/自然観測/','/自然数値表/'))
                assert not name.endswith(('book.jsonl','book.jsonl.gz','.csv','.xlsx'))
                if index['試行']==164:assert not name.startswith('work/163入口と任意幅/全出生/')
                body=source.read(name);wanted=expected[name]
                assert len(body)==wanted['bytes'] and hashlib.sha256(body).hexdigest()==wanted['sha256'],name
                local=ROOT/name;assert local.is_file(),name
                assert local.stat().st_size==len(body) and sha(local)==wanted['sha256'],name
                same+=1
                if name.endswith('.py'):
                    tree=ast.parse(body.decode('utf-8'))
                    for node in ast.walk(tree):
                        if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
                            doc=ast.get_docstring(node)
                            assert doc and '\n' in doc and all(k in doc for k in ('機能','引数','返り値')),(name,node.name)
                            source_functions+=1
        answers.append({'path':record['archive']['path'],'sha256':sha(path),'全CRC':True,
            'member数':len(expected),'元同体数':same,'Python関数コメント':source_functions})
    return answers


def displayed(cell: str,value: float|None,percent: bool=False) -> None:
    """
    機能: 表示の丸め桁を考慮して文書値を正本値へ照合する。
    引数: cell(str)、value(float又はNone)、percent(bool)は百分率。
    返り値: None。不整合はassert停止。
    """
    if value is None:
        assert cell in ('未定義','—','-');return
    clean=cell.replace(',','').replace('円','').replace('−','-').strip(' +*`%')
    actual=float(clean);value=float(value)*(100 if percent else 1)
    decimals=len(clean.split('.')[-1]) if '.' in clean else 0
    tolerance=.5*10**(-decimals)+1e-8 if '.' in clean or percent else 1e-8
    assert abs(actual-value)<=tolerance,(cell,value)


def numeric_tables(path: Path,summary: dict,trial: int) -> dict:
    """
    機能: READMEの全数値表を候補JSON正本の該当政策と照合する。
    引数: path(Path)、summary(dict)、trial(int)は163又は164。
    返り値: dictは照合行数・数値欄数と使用政策。
    """
    periods=('全期','前48場','後25場');headers=[];table=0;count=0;lines=0;ids=[]
    for line in path.read_text(encoding='utf-8').splitlines():
        if not line.startswith('|'):continue
        cells=[c.strip() for c in line.split('|')[1:-1]]
        if cells[0]=='期間':headers=cells;table+=1;continue
        if cells[0]=='規則':headers=cells;continue
        if cells[0] in periods:
            ref=summary['fixed'][0] if table==1 else summary['adaptive'][0]
            values=ref['periods'][cells[0]];ids.append(ref['rule'])
        elif re.fullmatch(r'[A-Z]{2}\d{4}',cells[0]):
            found=[r for r in summary['fixed'] if r['rule']==cells[0] and r['orientation']==cells[1]
                and r['width']==int(cells[2]) and r['horizon']==cells[3]
                and r['entry_mode']=='ALL' and r['integration']=='U']
            assert len(found)==1,cells;ref=found[0];values=ref['periods']['全期'];ids.append(ref['rule'])
        else:continue
        aliases={'取得':'count','F/(F+A)':'rate','利益円':'profit','損失円':'loss','既知差引円':'net',
            'PF':'pf','金融未知':'unknown','参加場':'scenes','回/時':'per_hour','先着率':'rate','未到達':'N','C':'C'}
        for header,cell in zip(headers,cells,strict=True):
            if header in ('F/A/N/C','順/逆'):
                keys=('F','A','N','C') if header=='F/A/N/C' else ('F','A')
                assert [int(c) for c in cell.split('/')]==[values[k] for k in keys],(header,cell)
                count+=len(keys)
            elif header in aliases:
                key=aliases[header];displayed(cell,values[key],key=='rate');count+=1
        lines+=1
    assert lines==(6 if trial==163 else 8),(trial,lines)
    return {'照合表行':lines,'照合数値欄':count,'政策':ids}


def summary_arrays(trial: int,folder: Path,summary: dict) -> dict:
    """
    機能: 文書参照JSONの主要政策を全統計配列の該当軸へ再照合する。
    引数: trial(int)、folder(Path)は自然統計親、summary(dict)。
    返り値: dictは照合した政策数と数値欄数。取引を再集計しない。
    """
    axis=read(folder/'統計軸.json');count=0;policies=0
    fields=axis['指標'];periods=axis['期間']
    archive=folder/('全探索の統計配列.npz' if trial==163 else '最初到達の統計配列.npz')
    with np.load(archive,allow_pickle=False) as arrays:
        groups=[('fixed',summary['fixed'][:5])]
        if trial==163:groups.append(('adaptive',summary['adaptive'][:1]))
        for kind,records in groups:
            values=arrays[kind if trial==163 else 'metrics']
            for record in records:
                cube=values[tuple(record['position'])]
                for pi,period in enumerate(periods):
                    for fi,field in enumerate(fields):
                        actual=cube[pi,fi];wanted=record['periods'][period][field]
                        assert np.isnan(actual) if wanted is None else actual==wanted,(trial,record['rule'],period,field)
                        count+=1
                policies+=1
    return {'政策数':policies,'全期前後の数値欄':count,'自然取引再集計':False}


def main() -> None:
    """
    機能: 両試行の文書・全保存ZIP・索引・V8・主要数値を一括照合する。
    引数: なし。165と未見2場のファイルは開かない。
    返り値: None。検査票だけをwork/163_164保存QAへ保存する。
    """
    template=ROOT/'docs/議論/手法と時間スケールの汎用表_版8.md'
    assert sha(template)=='45de4076b1416e409f60897a887209511835be4b7866f85c51b19a2fa5f1b138'
    wanted=rows(template);assert len(wanted)==63
    proof={'成功':True,'範囲':'保存と報告の独立照合。自然取引の全面再集計又は未見性能検証ではない。','試行':{}}
    for trial,(name,book_sha) in TRIALS.items():
        destination=ROOT/'study'/name;assert sha(destination/'条件.json')==book_sha
        documents=sorted(destination.glob('*.md'));assert len(documents)==4
        texts={p:p.read_text(encoding='utf-8',errors='strict') for p in documents};links=[]
        for path,text in texts.items():
            for label,target in re.findall(r'\[([^\]]+)\]\(([^)]+)\)',text):
                target_path=linked(path,target)
                if target_path is None:continue
                assert target_path.exists(),(path.name,target)
                assert not target_path.is_relative_to(ROOT/'work'),(path.name,target)
                assert '00165_' not in str(target_path)
                links.append((path.name,label,target))
        full='\n'.join(texts.values())
        for token in ('仮説','入力','条件','費用','結果','限界','再現手順','既使用','全期探索','未見','純新規','旧87','STRICT_H','IFD_FIRST'):
            assert token in full,(trial,token)
        assert '列が存在するだけ' in full and '必要値未知なら側不成立かつ未知計数' in full
        actual=rows(destination/'設定と結果.md');assert len(actual)==63
        for a,b in zip(actual,wanted,strict=True):
            assert a[0]==b[0] and len(a[2:])==9 and all(a[2:])
            an,at=re.search(r'\[([^\]]+)\]\(([^)]+)\)',a[1]).groups()
            bn,bt=re.search(r'\[([^\]]+)\]\(([^)]+)\)',b[1]).groups()
            assert an==bn and linked(destination/'設定と結果.md',at)==linked(template,bt),(a[0],an,bn)
        index_path=destination/'再現資料/保存索引.json';index=read(index_path)
        assert index['成功'] and index['試行']==trial and index['未採用の全期探索'] and index['旧試行非改変']
        file_ref(index['条件'])
        for record in index['共用入力と親参照']:file_ref(record)
        assert '1.24.2' in index['実行環境']['Go']
        result_archives=archives(index)
        folder=ROOT/('work/163入口と任意幅/広い評価' if trial==163 else 'work/164先着確定と反転比較/比較')
        summary=read(folder/'有望な発見候補.json')
        assert summary['成功'] and summary['全期探索で未採用']
        numbers=numeric_tables(destination/'README.md',summary,trial)
        array_check=summary_arrays(trial,folder,summary)
        assert not list(destination.rglob('*.csv')) and not list(destination.rglob('*.xlsx'))
        proof['試行'][str(trial)]={'条件SHA256':book_sha,'文書数':len(documents),'文書SHA256':{p.name:sha(p) for p in documents},
            'ローカルリンク数':len(links),'V8全手法':63,'V8全セル':567,'教材リンク同体':True,
            '保存索引SHA256':sha(index_path),'親共有参照数':len(index['共用入力と親参照']),
            'ZIP':result_archives,'README':numbers,'JSONとNPZ':array_check}
    baseline=read(ROOT/'work/162保存QA/既存試行の基準指紋.json')
    for path,record in baseline['files'].items():file_ref({'path':path,**record})
    proof['旧160と161の不変実体']=len(baseline['files'])
    proof['検査SourceSHA256']=sha(Path(__file__))
    proof['165と未見2場のファイル読取']=False
    (HERE/'正式保存の独立確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':main()
