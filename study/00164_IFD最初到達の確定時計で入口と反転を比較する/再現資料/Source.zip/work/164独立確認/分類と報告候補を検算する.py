"""164のIFD確定分類と報告候補を、Raw原始値と別の取得/統計実装で検算する。"""
from pathlib import Path
from collections import Counter,defaultdict
import gzip
import hashlib
import importlib.util
import json
import math
import sys

import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
TRIAL=ROOT/'study/00164_IFD最初到達の確定時計で入口と反転を比較する'
BOOK_SHA='e415f92ee290b8adad74e378255432e384114d67abe16082505af06a10b65f5d'
DATA=ROOT/'work/163任意幅の数値化/自然数値表'
COMPARE=ROOT/'work/164先着確定と反転比較/比較'
BIRTH=ROOT/'work/163入口と任意幅/全出生'
RAW=ROOT/'work/163任意幅Raw索引'
FIELDS=('count','F','A','N','C','rate','complete_rate','all_rate','profit','loss','net','pf','known','unknown',
    'scenes','all_scenes','per_hour','max_scene_share','new_count','old_count','hold_mean_seconds','wins','loss_trades','realized_win_rate','new_scenes')


def sha(path: Path) -> str:
    """
    機能: 全物理bytesのSHA256を計算する。
    引数: path(Path)はファイル。
    返り値: strは指紋。
    """
    with path.open('rb') as source:return hashlib.file_digest(source,'sha256').hexdigest()


def read(path: Path) -> dict:
    """
    機能: 小型JSONをgzip全CRCも確認して読む。
    引数: path(Path)は入力。
    返り値: dictは解析値。
    """
    body=path.read_bytes()
    return json.loads(gzip.decompress(body) if body[:2]==b'\x1f\x8b' else body)


def module(path: Path,name: str) -> object:
    """
    機能: 比較対象のContextをmain未実行で読み込む。
    引数: path(Path)、name(str)はSourceと登録名。
    返り値: objectはmodule。期待統計の計算には作者の集計関数を使わない。
    """
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec)
    sys.modules[name]=value;spec.loader.exec_module(value);return value


def selection(rows: list) -> tuple:
    """
    機能: 独立再構成した取得tupleを数値配列へまとめる。
    引数: rows(list[tuple])はcase/side/event/old。
    返り値: tuple[np.ndarray]は四属性。空集合も同じ型を持つ。
    """
    if not rows:
        return (np.empty(0,dtype=np.int32),np.empty(0,dtype=np.int8),np.empty(0,dtype=np.int32),np.empty(0,dtype=bool))
    return (np.asarray([r[0] for r in rows],dtype=np.int32),np.asarray([r[1] for r in rows],dtype=np.int8),
        np.asarray([r[2] for r in rows],dtype=np.int32),np.asarray([r[3] for r in rows],dtype=bool))


def link(directions: np.ndarray,event_cases: np.ndarray) -> tuple:
    """
    機能: q0物理順で最初に成立して取得できた要求だけを物理caseへ結ぶ。
    引数: directions(np.ndarray[int8])は全q0方向、event_cases(np.ndarray[int])は取得対応。
    返り値: tuple[np.ndarray]は重複のない純新規取得。
    """
    assert directions.shape==event_cases.shape and np.isin(directions,(-1,0,1)).all()
    rows=[];seen=set()
    for event in np.flatnonzero(directions):
        case=int(event_cases[event])
        if case>=0 and case not in seen:
            rows.append((case,0 if directions[event]==1 else 1,int(event),False));seen.add(case)
    return selection(rows)


def integrate(new: tuple,mode: str,legacy_rows: list,first_rows: list,arrays: dict,sessions: list) -> tuple:
    """
    機能: 純新規、旧全保持、当時初参加補完を別実装で統合する。
    引数: new(tuple)、mode(str N/U/F)、legacy_rows/first_rows(list[tuple])、arrays(dict)、sessions(list[str])。
    返り値: tuple[np.ndarray]は旧優先の一意取得。Fは実取得と真出生の物理時計で決める。
    """
    if mode=='N':return new
    case,side,event,old=new
    if mode=='U':adopt=legacy_rows
    else:
        assert mode=='F';earliest={}
        for ci in case:
            scene=int(arrays['session_index'][ci]);key=(arrays['entry_time'][ci],int(arrays['entry_index'][ci]),int(arrays['entry_line'][ci]))
            if scene not in earliest or key<earliest[scene]:earliest[scene]=key
        adopt=[row for row in first_rows if row[4] not in earliest or earliest[row[4]]>row[5]]
    protected={r[0] for r in adopt}
    rows=[(int(c),int(s),int(e),bool(o)) for c,s,e,o in zip(case,side,event,old,strict=True) if c not in protected]
    rows.extend(tuple(r[:4]) for r in adopt)
    assert len({r[0] for r in rows})==len(rows)
    return selection(rows)


def summarize(selected: tuple,wi: int,hi: int,arrays: dict,labels: np.ndarray,hours: np.ndarray) -> np.ndarray:
    """
    機能: 単一政策の三期間25指標を実取得から独立に計算する。
    引数: selected(tuple)、wi/hi(int)、arrays(dict)、labels(np.ndarray)、hours(np.ndarray)は原始配列と対象時間。
    返り値: np.ndarray[3,25]は未定義率/時間をNaNとした統計。
    """
    case,side,event,old=selected;scene=arrays['session_index'][case];result=np.full((3,len(FIELDS)),np.nan)
    for pi in range(3):
        eligible=np.arange(73)<48 if pi==1 else np.arange(73)>=48 if pi==2 else np.ones(73,dtype=bool)
        chosen=eligible[scene];c=case[chosen];s=side[chosen];o=old[chosen];sc=scene[chosen]
        l=labels[c,s,wi,hi];known=arrays['known'][c,s,wi,hi];money=arrays['net5'][c,s,wi,hi][known]
        f=int((l==1).sum());a=int((l==-1).sum());n=int((l==0).sum());u=int((l==2).sum());count=len(c)
        counts=Counter(map(int,sc));profit=sum(int(x) for x in money if x>0);loss=-sum(int(x) for x in money if x<0)
        wins=sum(int(x)>0 for x in money);loss_trades=sum(int(x)<0 for x in money)
        duration=(arrays['exit_time'][c,s,wi,hi]-arrays['entry_time'][c])[known]
        divide=lambda x,y:x/y if y else math.nan
        values={'count':count,'F':f,'A':a,'N':n,'C':u,'rate':divide(f,f+a),'complete_rate':divide(f,f+a+n),
            'all_rate':divide(f,count),'profit':profit,'loss':loss,'net':profit-loss,'pf':divide(profit,loss),
            'known':int(known.sum()),'unknown':count-int(known.sum()),'scenes':len(counts),
            'all_scenes':int(all(counts[int(i)]>0 for i in np.flatnonzero(eligible))),
            'per_hour':divide(count,float(hours[eligible].sum())),
            'max_scene_share':divide(max(counts.values(),default=0),count),'new_count':int((~o).sum()),'old_count':int(o.sum()),
            'hold_mean_seconds':float(duration.mean()) if len(duration) else math.nan,
            'wins':wins,'loss_trades':loss_trades,'realized_win_rate':divide(wins,int(known.sum())),
            'new_scenes':len(set(map(int,sc[~o])))}
        result[pi]=[values[k] for k in FIELDS]
    return result


def match(actual: np.ndarray,expected: np.ndarray,where: object) -> None:
    """
    機能: 統計の未知・整数・実数を全セル比較する。
    引数: actual/expected(np.ndarray)、where(object)は比較値と所在。
    返り値: None。不一致はAssertionError。
    """
    assert actual.shape==expected.shape and np.allclose(actual,expected,rtol=1e-12,atol=1e-9,equal_nan=True),where


# ----------------------------------------
def main() -> None:
    """
    機能: 全原始分類/成熟、全報告候補、旧対照と層化政策を独立再構成して検算する。
    引数: なし。164固定条件・163純観測と固定出生を利用する。
    返り値: None。範囲を明記した検査票を保存し、自然政策は変更しない。
    """
    assert sha(TRIAL/'条件.json')==BOOK_SHA
    paths=[Path(__file__),TRIAL/'条件.json',COMPARE/'完了.json',COMPARE/'統計軸.json',COMPARE/'有望な発見候補.json',
        COMPARE/'最初到達の統計配列.npz',DATA/'任意幅配列.npz',DATA/'任意幅識別.json.gz',
        BIRTH/'全出生の確認.json',RAW/'自然観測/manifest.json',RAW/'自然索引/manifest.json']
    paths.extend([
        ROOT/'work/164先着確定と反転比較/比較する.py',
        ROOT/'work/163入口と任意幅/評価163.py',ROOT/'work/163入口と任意幅/共通163.py',
        ROOT/'work/162入口探索/評価基盤.py',
        ROOT/'work/163入口と任意幅/広い評価/全探索の統計配列.npz',
        COMPARE/'分類差分と金融不変.json',
        ROOT/'work/151過去場判別の評価/入口選択/cache/feature_only/features_meta.json',
        ROOT/'inputs/00148_全1分入口母集団/取得対応.json.gz',
        ROOT/'inputs/00148_全1分入口母集団/入口参照.json.gz',
        ROOT/'inputs/00152_複合回復の方向切替/選択対応.json.gz',
        ROOT/'inputs/00153_先行高安の独立出生/選択対応.json.gz'])
    before={str(p.relative_to(ROOT)):sha(p) for p in paths}
    book=read(paths[1]);axes=read(paths[3]);found=read(paths[4]);meta=read(paths[7]);birth_proof=read(paths[8])
    assert axes['指標']==list(FIELDS) and axes['主label']=='IFD_FIRST'
    assert axes['幅']==meta['widths'] and axes['時計']==meta['horizon_ids']
    with np.load(paths[6],allow_pickle=False) as source:arrays={k:source[k].copy() for k in source.files}
    mapping={c:i for i,c in enumerate(meta['case_ids'])};labels=np.full_like(arrays['label'],2);maturity=np.full_like(arrays['known_at'],np.nan)
    raw_manifest=read(paths[9]);index_manifest=read(paths[10]);cells=0
    dtype=np.dtype([('time','<f8'),('line','<i8'),('last','<f8'),('bid','<f8'),('ask','<f8'),('normal','<u8')])
    # ----------------------------------------
    # touch参照の有無と実評価価格から分類する。作者のwhere式を期待値生成に使わない。
    for si,scene in enumerate(raw_manifest['scenes']):
        observation_path=RAW/'自然観測'/scene['file']['path'];assert sha(observation_path)==scene['file']['sha256']
        observed=read(observation_path);ix=index_manifest['scenes'][si]
        index_path=RAW/'自然索引'/ix['index']['path'];assert sha(index_path)==ix['index']['sha256']
        body=gzip.decompress(index_path.read_bytes());records=np.frombuffer(body,dtype=dtype,offset=8)
        for case in observed['cases']:
            ci=mapping[case['id']]
            for side_index,side in enumerate(case['sides']):
                sign=side['side'];price=side['entry_price']
                for hi,outcome in enumerate(side['outcomes']):
                    for wi,touch in enumerate(outcome['touches']):
                        at=(ci,side_index,wi,hi);ti=touch['touch_index']
                        if ti is not None:
                            movement=sign*(float(records['bid' if sign==1 else 'ask'][ti])-price)
                            assert abs(movement)>=touch['width'];labels[at]=1 if movement>0 else -1
                            maturity[at]=records['time'][ti]
                        elif outcome['complete']:
                            labels[at]=0;maturity[at]=outcome['known_at']
                        assert (labels[at]!=2)==arrays['known'][at]
                        cells+=1
        assert sha(observation_path)==scene['file']['sha256'] and sha(index_path)==ix['index']['sha256']
    assert cells==3037632 and np.array_equal(labels==2,~arrays['known'])
    assert np.array_equal(np.isfinite(maturity),labels!=2)
    old_labels=arrays['label'];difference={'old_C':int((old_labels==2).sum()),'new_C':int((labels==2).sum()),
        'C_to_F':int(((old_labels==2)&(labels==1)).sum()),'C_to_A':int(((old_labels==2)&(labels==-1)).sum()),'financial_changed':False}
    assert difference==read(COMPARE/'分類差分と金融不変.json')['reclassification']
    sys.path.insert(0,str(ROOT/'work/163入口と任意幅'))
    target=module(ROOT/'work/164先着確定と反転比較/比較する.py','context164_target')
    author=target.Context164()
    assert np.array_equal(labels,author.arrays['label']) and np.array_equal(maturity,author.arrays['known_at'],equal_nan=True)
    assert np.array_equal(arrays['net5'],author.arrays['net']) and np.array_equal(arrays['known'],author.arrays['known'])
    del author
    # ----------------------------------------
    # 入力読取を共有しても取得・旧補完・統計は独立の実装で作る。
    feature_meta=read(ROOT/'work/151過去場判別の評価/入口選択/cache/feature_only/features_meta.json')
    q0=feature_meta['q0_meta'];scenes=feature_meta['scenes'];events={r['event_id']:i for i,r in enumerate(q0)}
    capture=read(ROOT/'inputs/00148_全1分入口母集団/取得対応.json.gz')
    event_cases=np.full(len(events),-1,dtype=np.int32)
    for row in capture['rows']:
        if row['status']=='filled':event_cases[events[row['event_id']]]=mapping[row['case_id']]
    legacy=read(ROOT/'inputs/00148_全1分入口母集団/入口参照.json.gz')
    scene_map={s:i for i,s in enumerate(meta['session_order'])};old_rows=[];first={}
    for row in legacy['entries']:
        ci=mapping[row['id']];si=scene_map[row['session']];b=row['origins'][0]['birthQuote']
        key=(b['time'],b['index'],b['source_line']);item=(ci,0 if row['native_side']==1 else 1,-1,True,si,key)
        old_rows.append(item)
        if si not in first or (*key,row['id'])<first[si][0]:first[si]=((*key,row['id']),item)
    first_rows=[first[s][1] for s in range(73)];assert len(old_rows)==87
    hours=np.array([(s['end']-300-s['start'])/3600 for s in scenes]);assert abs(hours.sum()-(720+55/60))<1e-10
    with np.load(paths[5],allow_pickle=False) as source:metrics=source['metrics'];controls=source['controls']
    assert list(metrics.shape)==axes['shape']
    field={n:i for i,n in enumerate(FIELDS)};s=book['discovery_support'];full=metrics[...,0,:];front=metrics[...,1,:];back=metrics[...,2,:]
    eligible=(full[...,field['count']]>=s['minimum_count'])&(full[...,field['new_count']]>=s['minimum_new_count'])
    for values,minimum_resolved,minimum_rate in ((full,s['minimum_resolved'],s['minimum_rate']),
        (front,s['minimum_resolved_each_period'],s['minimum_rate_each_period']),
        (back,s['minimum_resolved_each_period'],s['minimum_rate_each_period'])):
        eligible &= (values[...,field['F']]+values[...,field['A']]>=minimum_resolved)&(values[...,field['rate']]>=minimum_rate)
    eligible &= (full[...,field['all_scenes']]==1)&(full[...,field['unknown']]<=s['maximum_financial_unknown_fraction']*full[...,field['count']])
    eligible &= (front[...,field['net']]>s['minimum_known_net_each_period'])&(back[...,field['net']]>s['minimum_known_net_each_period'])
    report_positions={tuple(map(int,p)) for p in np.argwhere(eligible)}
    assert len(report_positions)==found['報告支持合格']==186 and report_positions=={tuple(r['position']) for r in found['fixed']}
    # 全報告候補と全群×幅×時計×発火方式×方向×統合を層化して直接集計する。
    groups=defaultdict(list)
    for ri,rule in enumerate(axes['規則順']):groups[rule[:2]].append(ri)
    sample_positions=set()
    for group,indices in groups.items():
        ri=indices[len(indices)//2]
        for mi in range(2):
            for oi in range(2):
                for wi in range(12):
                    for hi in range(4):
                        for ii in range(3):sample_positions.add((ri,mi,oi,wi,hi,ii))
    todo=report_positions|sample_positions;tested=0;report_cells=0;sample_cells=0;mode_counts=Counter();positive=0
    for wi,width in enumerate(meta['widths']):
        birth_path=BIRTH/f'出生{int(width)}.npz';assert sha(birth_path)==birth_proof['files'][birth_path.name]['sha256']
        with np.load(birth_path,allow_pickle=False) as source:directions={k:source[k].copy() for k in source.files}
        cache={}
        for pos in sorted(p for p in todo if p[3]==wi):
            ri,mi,oi,_,hi,ii=pos;key=(ri,mi,oi,ii)
            if key not in cache:
                direction=directions[axes['発火方式'][mi]][ri]
                if oi:direction=-direction
                new=link(direction,event_cases)
                cache[key]=integrate(new,axes['統合'][ii],old_rows,first_rows,arrays,meta['session_order'])
            selected=cache[key];expected=summarize(selected,wi,hi,arrays,labels,hours)
            match(metrics[pos],expected,pos);tested+=1;positive+=bool(len(selected[0]))
            if pos in report_positions:report_cells+=expected.size
            if pos in sample_positions:sample_cells+=expected.size
            mode_counts[axes['方向'][oi]+'/'+axes['発火方式'][mi]+'/'+axes['統合'][ii]]+=1
        print(json.dumps({'独立検算幅':width,'政策累計':tested},ensure_ascii=False),flush=True)
    # ----------------------------------------
    # 保存旧対照もcase/side/event/originから独立に作り、全幅・全期限を確認する。
    legacy_selection=selection([tuple(r[:4]) for r in old_rows]);old_selections={'C1':legacy_selection}
    for folder,names in [('00152_複合回復の方向切替',('A0','U0','B0','U1')),('00153_先行高安の独立出生',('N15','U15'))]:
        saved=read(ROOT/'inputs'/folder/'選択対応.json.gz')
        for name in names:
            old_selections[folder[:5]+'_'+name]=selection([(mapping[r['case_id']],0 if r['side']==1 else 1,
                events.get(r['event_id'],-1),r['origin']=='C1') for r in saved['政策'][name]])
    old_cells=0
    for ci,name in enumerate(axes['旧対照順']):
        for wi in range(12):
            for hi in range(4):
                expected=summarize(old_selections[name],wi,hi,arrays,labels,hours)
                match(controls[ci,wi,hi],expected,(name,wi,hi));old_cells+=expected.size
    unchanged=[i for i,k in enumerate(FIELDS) if k not in ('F','A','N','C','rate','complete_rate','all_rate')]
    parent_path=ROOT/'work/163入口と任意幅/広い評価/全探索の統計配列.npz'
    with np.load(parent_path,allow_pickle=False) as source:previous=source['fixed']
    for fi in unchanged:match(metrics[:,:,0,...,fi],previous[...,fi],FIELDS[fi])
    for name in ('count','scenes','all_scenes','per_hour','max_scene_share','new_count','old_count','new_scenes'):
        fi=field[name];match(metrics[:,:,0,...,fi],metrics[:,:,1,...,fi],('方向反転の取得不変',name))
    assert all(sha(ROOT/p)==v for p,v in before.items()) and sha(TRIAL/'条件.json')==BOOK_SHA
    result={'成功':True,'試行':164,'条件SHA256':BOOK_SHA,'Sourceと入力':before,'全原始分類成熟セル':cells,
        '再分類':difference,'全報告支持候補':len(report_positions),'全報告候補独立統計セル':report_cells,
        '層化政策数':len(sample_positions),'層化統計セル':sample_cells,'重複除外検算政策数':tested,
        '取得あり検算政策':positive,'検算群':sorted(groups),'層化方式':dict(mode_counts),'旧対照数':len(old_selections),
        '旧対照全統計セル':old_cells,'全NORMALの旧金融取得不変':True,'全方向反転で取得属性不変':True,
        '範囲':'全1460規則×2発火×2方向×12幅×4時計×3統合の全政策再集計ではない。全原始値・全報告候補・全旧対照・層化政策を直接計算。',
        '基盤証拠':'163の全旧148同体・新幅SESSION線形人工・全探索配列Go同体と、既存Cube人工検査を併用する。',
        '作者の集計関数を期待値に使用':False,'採否変更':False}
    (HERE/'自然の独立確認.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='Sourceと入力'},ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
