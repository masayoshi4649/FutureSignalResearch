"""実際のIFD最初到達を主評価にし、反転対照も別試行で固定する。"""
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
TRIAL=ROOT/'study/00164_IFD最初到達の確定時計で入口と反転を比較する'


def main() -> None:
    """
    機能: 旧strictを残し、打切り前touch確定・同時点反転・品質支持を自然比較前に固定する。
    引数: なし。
    返り値: None。新規164の条件と実行前READMEを保存する。
    """
    assert not TRIAL.exists()
    assert max(int(p.name[:5]) for p in (ROOT/'study').iterdir() if p.is_dir() and p.name[:5].isdigit())==163
    parent=ROOT/'study/00163_履歴を含む複合入口を任意幅と場末まで検証する/条件.json'
    book=json.loads(parent.read_text(encoding='utf-8'))
    book.update(trial=164,name='IFD最初到達の確定時計で入口と反転を比較する')
    book['parent_conditions']={'path':parent.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(parent.read_bytes()).hexdigest()}
    book['hypothesis']='未来の期限完了によって既知touchを先着分母から除く選択を避け、実際に打切り前に確定したIFD到達を評価する。同じq0複合条件の方向を固定反転した対照も実BBOで検証する。'
    book['label_modes']={'primary':'IFD_FIRST','control':'STRICT_H'}
    book['first_label']='Rawdirection=+1/-1かつ金融knownなら期限未完了でもF/A。direction=0で期限completeならN、残りC。unknownをF/A/Nへ埋めない。'
    book['maturity']='F/Aは実touchのexit_time、Nは元known_at（strict endpoint又はSESSION境界観測）、CはNaN。'
    book['orientation']=['NORMAL','REVERSE']
    book['reverse']='全1460条件へ−directionを事前対照として追加。取得時点・原行は同じで実反対側のentry/mark/touchを使う。1−pを使わず未知・spread・先着を再評価。'
    book['entry_and_money_unchanged']='新規出生/取得母集団/幅/期限/金融算式は163と同じ。主labelと成熟時計だけ変更。旧試行は非改変。'
    book['discovery_support']={'minimum_count':200,'minimum_new_count':100,'minimum_resolved':100,
        'minimum_resolved_each_period':30,'minimum_rate':.70,'minimum_rate_each_period':.65,
        'maximum_financial_unknown_fraction':.10,'minimum_known_net_each_period':0,
        'all_73_acquisitions':True,'frequency_preferred_per_hour':.8,
        'interpretation':'全期探索の報告支持条件であり、未見統計保証や自動採用条件ではない。前後は既使用。'}
    book['next_validation']='有望条件は近傍・別幅・三帯・真の新規/旧補完・数量上限を確認し、必要な別試行で未見2場へ適用する。163/164探索中には未見2場を開かない。'
    TRIAL.mkdir();(TRIAL/'検査').mkdir()
    p=TRIAL/'条件.json';p.write_text(json.dumps(book,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (TRIAL/'README.md').write_text('# 00164 IFD最初到達の確定時計で入口と反転を比較する\n\n2026-11-14。自然比較前に[条件](条件.json)を固定。旧strictの全H完了条件と、打切り前に既に決済したIFDの最初到達を分ける。1460複合条件・12幅・4期限・NORMAL/REVERSEを評価する。現在は未実行。旧163や過去試行の数値は変更しない。\n',encoding='utf-8')
    print(json.dumps({'条件SHA256':hashlib.sha256(p.read_bytes()).hexdigest()},ensure_ascii=False))


if __name__=='__main__':
    main()
