"""凍結済み163/164を、共用入力の重複なしで正式保存する。"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib
import importlib.metadata
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
T162=ROOT/'study/00162_複合入口を広く探索し値幅ごとに過去選択する'
T163=ROOT/'study/00163_履歴を含む複合入口を任意幅と場末まで検証する'
T164=ROOT/'study/00164_IFD最初到達の確定時計で入口と反転を比較する'
SHARED=ROOT/'inputs/00163_任意幅の共用価格索引'
BOOKS={163:'a4e5a3ad0417b5790a7f17e768327648e27790d25867092e5e60944ed2863b10',
       164:'e415f92ee290b8adad74e378255432e384114d67abe16082505af06a10b65f5d'}


def sha(path: Path) -> str:
    """
    機能: 全物理ファイルを読み指紋化する。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    with path.open('rb') as source:return hashlib.file_digest(source,'sha256').hexdigest()


def read(path: Path) -> object:
    """
    機能: UTF-8のJSONを解析する。
    引数: path(Path)。
    返り値: objectは標準JSON値。
    """
    return json.loads(path.read_bytes())


def save(path: Path,value: object) -> None:
    """
    機能: 日本語UTF-8の標準JSONを保存する。
    引数: path(Path)、value(object)。
    返り値: None。
    """
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')


def reference(path: Path) -> dict:
    """
    機能: 正式又は凍結作業ファイルをサイズ・指紋・由来付きで参照する。
    引数: path(Path)。
    返り値: dictはリポジトリ相対参照。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':sha(path)}


def table(headers: list,rows: list) -> str:
    """
    機能: 少数の説明用結果をMarkdown表へ変換する。
    引数: headers(list)、rows(list)。
    返り値: strはMarkdown表。
    """
    return '\n| '+' | '.join(headers)+' |\n| '+' | '.join('---' for _ in headers)+' |\n'+''.join('| '+' | '.join(map(str,row))+' |\n' for row in rows)+'\n'


def format_rate(value: float|None) -> str:
    """
    機能: 未定義と定義済み率を区別して表示する。
    引数: value(float又はNone)。
    返り値: strは百分率又は未定義。
    """
    return f'{value:.2%}' if value is not None else '未定義'


def metric_table(record: dict) -> str:
    """
    機能: 一つの政策の三期間について分母・未知・利益損失を併記する。
    引数: record(dict)は固定済み結果。
    返り値: strは説明表。
    """
    rows=[]
    for name,d in record['periods'].items():
        rows.append([name,int(d['count']),f"{int(d['F'])}/{int(d['A'])}/{int(d['N'])}/{int(d['C'])}",
            format_rate(d['rate']),f"{d['profit']:,.0f}",f"{d['loss']:,.0f}",f"{d['net']:+,.0f}",
            f"{d['pf']:.3f}",int(d['unknown']),f"{int(d['scenes'])}",f"{d['per_hour']:.3f}"])
    return table(['期間','取得','F/A/N/C','F/(F+A)','利益円','損失円','既知差引円','PF','金融未知','参加場','回/時'],rows)


# ----------------------------------------
def settings(trial: int,destination: Path) -> None:
    """
    機能: 版8の63手法×9尺度を複写し、実際に使用した指標・履歴・時計を記入する。
    引数: trial(int)、destination(Path)。
    返り値: None。未使用を指標の無効性と混同しない。
    """
    original=ROOT/'docs/議論/手法と時間スケールの汎用表_版8.md'
    body=original.read_text(encoding='utf-8').split('## 手法×時間スケール',1)[1].split('## 設定明細',1)[0]
    body=body[body.index('### 指標'):];updates={}
    for scale in (3,4,5):
        updates[('I01',scale)]='EMA21傾き'+('・EMA8/21差' if scale==3 else '')
        updates[('I08',scale)]='DI差'+('・ADX水準/増分' if scale==4 else '')
    for scale in (3,4):
        updates[('I03',scale)]='Hist水準/増分'+('・ATR比' if scale==3 else '')
        updates[('I04',scale)]='RSI中心差/増分' if scale==3 else 'RSI増分'
    updates[('I03',5)]='IRの長期Impulse近似にHist増分を使用'
    notes=[('I01',0,'q0のEMA8距離/ATR5、履歴Impulse解除'),('I03',0,'5分Hist増分の過去10/20分持続'),
        ('I04',0,'5分RSI公表値の過去10/20分持続・spike除外・過去反対急変'),
        ('I05',0,'当時σ履歴30/60分の圧縮→再拡大、当時動的σの外→内復帰。順側/平均余地を対象幅へ正規化'),
        ('I05',4,'BB15位置σ・BB幅/ATR15。履歴窓を30/60分足へ換算しない'),
        ('I09',0,'q0距離/ATR5、163の選択幅=ATR5×2/3/4/6/8の上側grid'),
        ('I09',3,'ATR5によるHist/距離の尺度'),('I09',4,'BB幅/ATR15'),
        ('P01',1,'実体比と当時の生存回復'),('P01',3,'実体/反対ヒゲ/終値位置'),
        ('P02',0,'先行3分の高安端とq0現在価格'),('P06',0,'先行3分端に対する現在余地'),
        ('P07',0,'先行3分端超過>0/0.1/0.25ATR5'),('V01',1,'同r観測量の前3分比0.5～1.5。rvol5は未使用'),
        ('B01',0,'0<spread<=10/20、abs(q0Last−m1Close)/ATR5<=1'),
        ('C01',0,'EMA/Hist/RSIに量/構造/値幅等を重ねる'),('C02',0,'BB端とRSI回復、形状/量を確認'),
        ('C03',0,'BB/量又は短期端/量を群別使用。三者同時の単独効果・長い支持抵抗は未検証'),
        ('C04',0,'DI方向とADX水準/増分を別に使用'),('C07',0,'背景5/15/30分の同方向/混在/反対と短期確認'),
        ('E01',0,'実BBOの対称12幅125～1000pt、H30/H60/H120/SESSION。'+('STRICT_H分類' if trial==163 else 'IFD_FIRST分類とSTRICT_H対照、NORMAL/REVERSE'))]
    for key1,key2,note in notes:updates[(key1,key2)]=note
    if trial==164:updates[('I09',0)]='q0距離/ATR5。163のATR可変幅は164で再探索せず固定12幅のみ'
    rows=0;lines=[]
    for line in body.splitlines():
        cells=[c.strip() for c in line.split('|')[1:-1]] if line.startswith('|') else []
        if len(cells)==11 and re.fullmatch('[A-Z][0-9]{2}',cells[0]):
            rows+=1
            for scale in range(9):cells[2+scale]=f'S{trial}-X/Q：'+updates[(cells[0],scale)]+f'。R{trial}' if (cells[0],scale) in updates else '未使用・未検証'
            line='| '+' | '.join(cells)+' |'
        lines.append(line)
    assert rows==63
    def relink(match: re.Match) -> str:
        """
        機能: 元版の教材リンクを試行からの相対位置へ移す。
        引数: match(re.Match)。
        返り値: strは有効なMarkdownリンク。
        """
        target=match.group(2)
        if '://' in target or target.startswith('#'):return match.group(0)
        return '['+match.group(1)+']('+os.path.relpath((original.parent/target).resolve(),destination).replace('\\','/')+')'
    body=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',relink,'\n'.join(lines))
    prefix=f'# {trial} 設定と結果\n\n2026-11-14。[版8](../../docs/議論/手法と時間スケールの汎用表_版8.md)の全63手法×9尺度=567セルを複写。元SHA256 `{sha(original)}`。\n\n[固定条件](条件.json)と[結果](README.md)に対応する。使用欄は複合評価での使用であり、その指標単独の効果ではない。100Xに列が存在するだけの指標は使用と記さない。履歴の窓長と指標の足幅を区別する。\n\n## 手法×時間スケール\n\n'
    detail=f'''\n\n## 設定明細\n\n|設定ID|条件・短い閾値|複合評価|\n|---|---|---|\n|S{trial}-X|正式148の買売実側100X、q0までの確定5/15/30分、1分形状/量、q0幾何。教師・q1・損益は候補関数へ渡さない|R{trial}|\n|S{trial}-Q|0<spread<=10/20、abs(q0Last−m1Close)/ATR5<=1。必要値未知なら側不成立かつ未知計数、両側成立は競合待機|全規則|\n|S{trial}-V1|TP144/MX72/TR72/EX108/CP108/BO72/RG108/RM72/MP144/SC72。短い閾値は[162設定表](../00162_複合入口を広く探索し値幅ごとに過去選択する/設定と結果.md)、全閾値は出生正本の候補辞書.json|972規則|\n|S{trial}-SB|過去30/60分σmin/max<=0.7/0.85、現在σ/過去minが1.1/1.25/1.5を上抜け。BB幅/ATR<=8、長中期票>=2/3、実体>0.2、Hist/RSI増分正、量>=1/1.25|96規則|\n|S{trial}-BR|当時BB位置が反対側1.5/2/2.5σ外から内へ、長中期票<=1/2、ADX増分<=0、実体>=0.1/0.3、Hist/RSI増分正、量>=0.5/1/1.5|72規則|\n|S{trial}-IR|EMA21傾き+Hist増分のImpulse近似。短期反対→中立/同側、15/30分側が許可。長中期票>=2/3、EMA8距離<=1ATR、1分回復又は5分実体、量>=0.5/1/1.25|48規則|\n|S{trial}-SP|過去10/20分RSI中心差min>=0/5/10、絶対増分max<=8/12/16、長中期票>=3、Hist正、RSI増分>=0、EMA8距離<=0.5/1ATR、量>=0.5/1|144規則|\n|S{trial}-SF|過去10/20分RSI増分min<=−8/−12、現在増分>0かつ<=2/4、BB位置<=−1/0、Hist/実体正、現価格が1分終値以上、量>=0.75/1.25|64規則|\n|S{trial}-HP|過去10/20分Hist増分min>=0、RSI絶対増分max<=8/12、Hist/ATR>=0.05/0.1、長中期票>=2/3、ADX増分>=0、量>=0.75/1.25|64規則|\n|S{trial}-HIST|同場/同限月、180秒超reset、窓80%被覆とmax(3,分数//2)異時秒、窓内必要値全known。BB基準/過去反対spikeは現在を除き、RSI/Hist持続は現在を含む|履歴488|\n|S{trial}-BIRTH|ALL全成立q0、EDGEは0/反対→当該方向又は場/180秒超reset。US境界だけの再発火なし。同物理q1は最初成立q0|全1460|\n|S{trial}-L|N純新規、U旧87全優先保持、F旧初回の当時まで実取得0ならその1信号予約。未来取消しなし。反転は新規出生だけ、旧参照は元側|N/U/F|\n|S{trial}-E|対称幅125/150/175/200/225/250/300/350/400/500/750/1000。strict30/60/120分又はSESSION、実側BBO、mini1枚100円/pt−往復77円−追加滑り1000円|R{trial}|\n'''
    if trial==163:
        detail+='|S163-ATR|既使用MP0057/58/81/82のみ、q0 ATR5×2/3/4/6/8以上の最小grid150～1000、上限1000。未知/非正は待機、最初成立q0の幅を決済まで固定。旧は200|480政策|\n\nR163：固定1460×2発火×12幅×4期限×3統合=420,480政策。ATR適応4×2×5×4×3=480政策。全期/前48場/後25場の25指標を正本へ保存。STRICT_Hの将来観測完了条件による偏りを発見し、新採用なし。新しい過去学習器は使っていない。\n'
    else:
        detail+='|S164-CLASS|実touchあり金融knownならF/A、touchなし期限completeならN、他C。F/A成熟はtouch、Nは期限/場境界のknown_at。全NORMALの分類7指標以外は163同体|IFD_FIRST|\n|S164-REVERSE|全q0出生へ定数−1。実反対側Bid/Askで入口/先着/清算を再計算。旧参照87は元側のまま、率を1−pで置換しない|NORMAL/REVERSE|\n|S164-SUPPORT|200取得、新100、到達100かつ前後各30、全73場、全期70%以上・前後65%以上、金融未知<=10%、前後既知差引>0。希望頻度>=0.8/時は別記|報告支持186、頻度達成0|\n\nR164：1460×2発火×2向き×12幅×4期限×3統合=840,960政策。単純IFD入口比較の発見用探索であり、未見実績又は自動採用ではない。163のATR適応政策を164で再探索したものではない。\n'
    detail+='\nM01/M02は未使用。新追尾E02は今回未使用。入口・幅・時計の比較を先に行う最新方針による。原法の再現ではなく派生として検証した箇所と、未知・未検証は[再現手順](再現手順.md)と[分類時計と次の仮説](分類時計と次の仮説.md)を参照する。\n'
    (destination/'設定と結果.md').write_text(prefix+body+detail,encoding='utf-8')


def docs() -> None:
    """
    機能: 固定結果の小型表と分類時計の限界を二試行へ別々に記録する。
    引数: なし。
    返り値: None。後続の結果や未見場を参照しない。
    """
    d163=read(ROOT/'work/163入口と任意幅/広い評価/有望な発見候補.json')
    d164=read(ROOT/'work/164先着確定と反転比較/比較/有望な発見候補.json')
    common='''\n## 入力・取得・費用\n\n旧全73場、31,642物理case両実側、35,339判断q0を維持し、正式148の100特徴を用いた。5/15/30分の背景・勢いと、BB/ATR・実体ヒゲ・相対観測量・短期価格端を組み合わせる。初版10群972と履歴6群488、合計1,460規則。買売は実側で符号を正規化した同条件。入口の向きを探す関数へ教師・q1・金融は渡さない。デイ/夜間NY09:30前/以後は夏冬時刻でq0を区分し、今回の固定規則は共通条件、各帯の強制参加はしない。\n\nALLと状態遷移だけのEDGEを分け、同物理q1は最初の成立q0で一意化する。Nは純新規、Uは旧87全取得の保持統合、Fは各場の旧初回出生時まで実取得0ならその旧信号を因果的に予約する補完。U/Fで全73場参加でも純新規が全場参加したとは呼ばない。\n\n各取得を独立mini1枚として、同幅の利確・損切りIFDを比較。取得はBUY Ask/SELL Bid、清算はBUY Bid/SELL Ask。利益・損失は費用後正負の別集計、PF=利益/損失。100円/pt、税込片道38.5円（往復77円）、追加往復滑り1,000円（合計10pt相当）を控除する。実BBOのスプレッドも含む。未到達は完了期限BBOで清算、観測不足でも打切り前touchが確定していれば金融既知、それ以外は未知であり0円実績にしない。既知差引は未知を解決した全損益ではない。\n\nF=順側先着、A=逆側先着、N=両側未到達で期限完了、C=分類観測不足。到達済み先着率F/(F+A)と、全取得に対するF比率、費用後の実現勝率は別物。頻度の分母は全73場の対象ザラバ時間であり、候補成立時間だけではない。利益・損失は重複しうる独立入口の合算で、片側上限10枚を守る実口座収支ではない。\n'''
    text163='''# 163 履歴と任意幅の入口探索\n\n2026-11-14。**新規採用なし。** ±125/200ptに限定せず、履歴を含む複合入口1,460規則を12幅・4期限へ広げた。固定420,480政策とATR適応480政策を保存したが、SESSIONの高率に「後の期限完了で早期の既知先着まで除く」偏りを発見した。率をそのまま入口優位と解釈せず、[164](../00164_IFD最初到達の確定時計で入口と反転を比較する/README.md)で分類時計を別試行として再評価する。旧163正本は変更しない。\n\n## 仮説と条件\n\n持続するRSI/Hist、BB収縮後の再拡大、端からの回復、Impulse近似の禁止解除を、方向・構造・量と重ねれば、広い値幅でも高先着と頻度を両立できると仮説を立てた。全期探索であり、162で既使用のMP4候補も含む。過去だけの選択又は未見性能の証明ではない。\n\n[条件.json](条件.json)のSHA256は `'''+BOOKS[163]+'''`。[設定と結果](設定と結果.md)は汎用表版8を全セル複写している。\n\n幅は125/150/175/200/225/250/300/350/400/500/750/1000pt、期限はstrictH30/H60/H120とSESSION。厳密期限が場末までに完了しなければC。SESSIONは境界観測とザラバ終端前の正常BBO鮮度30秒以内を要求し、境界原行をtouch/清算へ使わない。\n\nATR適応は既使用MP0057/58/81/82だけ。q0のATR5×2/3/4/6/8以上の最小gridを選び、上限1000、未知/非正ATRは待機、最初成立q0の幅を決済まで固定。旧参照の幅は200。\n'''+common+'''\n## 結果と解釈\n\n当時の報告基準を満たした固定候補は986、適応候補は29。ただし固定上位160件だけを表示用JSONへ抜粋し、全420,480政策は数値NPZに保持している。163の報告基準は164の支持条件より緩く、前後各到達支持・未知比率を要求していなかった。候補数同士を直接比較しない。\n\n頻度順の表示先頭 TP0050 / ALL / ±1000 / SESSION / U は次の通り。**98.26%を採用根拠にしない。**\n'''+metric_table(d163['fixed'][0])+'''\n前48場のF/Aは0/0で率は未定義。Cが2,086件あり、その一部は既にIFD損益が確定している。F/(F+A)の分母115件が全2,739取得を代表するとは言えない。\n\nATR適応の表示先頭 MP0058 / ALL / ATR×3 / H120 / U：\n'''+metric_table(d163['adaptive'][0])+'''\n到達済み73.03%でも後25場は62.20%、新規取得の参加は全期29場だけで、U旧87が全場を支える。固定STRICT_Hの偏りも残り、新しい安定採用とはしない。\n\n## 検査と限界\n\n原板の一度の読取から共有索引を作り、segment treeで最初到達を検索した。独立確認は旧148の125/200×H30/H60先着253,136件、旧数値1,832,556欄、新幅の全IFD原始値3,037,632件、独立線形人工40,320状態、探索配列全3,037,632セルとSESSION成熟63,284件で一致。集計の独立人工25,200セルも一致。新幅の自然原板全件を別実装で再び線形走査したという主張ではない。\n\n候補の対称性・未知・競合・未来毒を人工確認済み。BBは当時の動的σで、固定過去バンド価格の回復ではない。ImpulseはEMA21派生、RSI持続はq0公表値の実時間持続で確定5分足本数ではない。正確な原法再現と区別する。\n\n[分類時計と次の仮説](分類時計と次の仮説.md)、[再現手順](再現手順.md)、[保存索引](再現資料/保存索引.json)を参照。共用Raw/161cacheを複製せず、価格索引・金融表は[恒久入力](../../inputs/00163_任意幅の共用価格索引/README.md)に一度保存した。閲覧CSVと共通目次は全体研究側で別途整理する。本試行からxlsxは生成しない。\n'''
    text164='''# 164 最初IFD到達による入口と反転比較\n\n2026-11-14。同じ出生・取得・幅・期限・金融を使い、最初の既知IFD到達で先着を確定するIFD_FIRSTへ分けた。NORMAL/REVERSEの840,960政策から報告支持186を得た。頻度順先頭は **EX0076 / ALL / REVERSE / ±400 / H60 / U：534取得、95順40逆、70.37%、既知利益5,650,364円・損失3,774,710円**。前後既知差引はともに黒字だが、0.741回/時で希望0.8へ届かず、新採用せず次の入口仮説へ継続する。\n\n## 仮説と条件\n\n後で観測が切れた取引でも、打切り前に既にIFD利確/損切りへ届いていればその時点の先着を数える。逆行過多条件については同じq0出生の向きを定数−1で反転し、実反対側BBOで再評価すれば有意な候補を分けられると仮説を立てた。利確側先着率を1−pで反転しない。\n\n[条件.json](条件.json)のSHA256は `'''+BOOKS[164]+'''`。163の12幅・4期限・1,460規則の固定出生を継承し、向き2通りを追加した。ATR適応480政策は164で再探索していない。[設定と結果](設定と結果.md)に全V8表と支持閾値を記した。\n\nIFD_FIRSTは、実touchありかつ金融knownなら期限未完了でもF/A、touchなし期限完了ならN、それ以外C。F/Aの成熟はtouch原行時計、Nは期限又は場境界のknown_at。全NORMALについて163と分類関連7指標以外の金融・取得指標が同体であることを全数assertした。旧STRICT_H値は書き換えない。反転するのは新規出生のみで、U/Fの旧参照は元側に保持する。\n'''+common+'''\n## 結果\n\n固定報告支持は200取得・新100・到達100・前後各30到達・全73場・全期70%以上・前後65%以上・金融未知10%以下・前後既知差引プラス。これを満たす186政策はすべて全期探索で得た未採用の発見候補である。希望頻度0.8回/時を満たすものは0。\n\n頻度順先頭 EX0076 / ALL / REVERSE / ±400 / H60 / U：\n'''+metric_table(d164['fixed'][0])+'''\n全73場参加はU旧87を含む。新規は447取得・54場であり、純新規だけの全場参加ではない。到達済み先着率70.37%の分母は135件、未到達363件、金融未知36件を別に残す。費用後実現勝率は53.82%で、先着率と一致しない。利益/損失比は1.497。\n\n近傍の頻度上位を比較する（いずれもALL/U、IFD_FIRST、全73場参加）。\n'''
    rows=[]
    for item in d164['fixed'][:5]:
        a=item['periods']['全期'];rows.append([item['rule'],item['orientation'],item['width'],item['horizon'],int(a['count']),
            f"{int(a['F'])}/{int(a['A'])}",format_rate(a['rate']),int(a['N']),int(a['C']),f"{a['profit']:,.0f}",f"{a['loss']:,.0f}",f"{a['per_hour']:.3f}"])
    text164+=table(['規則','向き','±pt','期限','取得','順/逆','先着率','未到達','C','利益円','損失円','回/時'],rows)
    text164+='''\nEX0076のNORMALは「反対側BB2σ以上の伸び、反対ヒゲ>=0.2、RSI中心差<=5、RSI/Hist増分正、実体>=0、相対量>=0.5、spread<=20、価格乖離<=1ATR」の回復近似。REVERSEはその弱い回復へ逆らう対照であり、反転方向の新たな構造確認を別途要求した候補ではない。弱い回復が元方向継続に負ける局面を見分けるという次仮説の材料にする。\n\n## 分類時計の発見と限界\n\n旧C947,664セルのうち、早期既知touchにより261,414セルがF、298,622セルがAへ確定し、新Cは387,628セルになった。これは全31,642case×両側×12幅×4期限の原始セルで、各政策の取得件数ではない。旧取得・実約定代用・既知IFD金融は変わらない。[分類時計と次の仮説](分類時計と次の仮説.md)で分母の違いを説明する。\n\n独立確認は全3,037,632分類/成熟、全186報告候補、16群の層化を含む重複除外9,402政策、旧7対照の25,200統計セル、全NORMAL金融不変を照合した。全840,960政策を独立実装で再集計したものではない。Raw部分は163の旧148同体・新幅の独立線形人工と共有する。\n\n同じ既使用73場の全期探索であり、前48/後25は未見分割ではない。候補間の重複・多数比較・未知・場集中、U旧参照による参加の寄与を残す。mini板、遅延、同時保有/片側10枚上限は未検証。この結果だけで安定した実運用収支を保証しない。\n\n[再現手順](再現手順.md)と[保存索引](再現資料/保存索引.json)を参照。共有入力は[恒久価格索引・金融表](../../inputs/00163_任意幅の共用価格索引/README.md)、出生は[163正本](../00163_履歴を含む複合入口を任意幅と場末まで検証する/再現資料/出生と統計正本.zip)へ参照し、複製しない。閲覧CSV・共通目次は全体研究側で別途整理し、後続の結果を本試行へ混ぜない。\n'''
    (T163/'README.md').write_text(text163,encoding='utf-8');(T164/'README.md').write_text(text164,encoding='utf-8')
    explanation='''# 分類時計と次の仮説\n\n2026-11-14。一般的な指標の説明、心理の仮説、実験で確かめた事実を分ける。\n\n## 確かめたこと\n\n163はSTRICT_Hを拡張した。先着F/Aを数える前提として、その後も期限又は場末まで観測が完了したことを要求する。このため、すでにIFD決済へ到達し金融が確定した取得でも、後のgap/境界不足によって先着分類Cとなる。SESSIONで98%等の高率が出ても、全取得へ外挿できない。実装の既知金融と、入口判定用labelの観測時計の用途が異なった。\n\n164は出生・取得・約定代用・費用・金融を維持し、最初touchがあればその時点でF/Aと成熟時計を確定した。touchなしで完了したものだけN、それ以外C。旧C947,664→新C387,628、差560,036はF261,414/A298,622。金融の既知/未知は変わらず、旧NORMALと分類関連7指標以外は全数同体。旧163正本は変更しない。\n\nこれにより、既知先着を後の観測完了で選別しない。touchのない観測不足は依然Cであり、未知を勝ち負けへ推定補完したものではない。IFD_FIRSTのF/(F+A)もN/Cを含む全取得成功率ではない。\n\n## 技術条件と心理の仮説\n\nEMA/DIの方向は参加者の平均的な含み方向、Hist/RSI増分は短期需給の加速、量は動きへの参加、BB/ATRは伸びや余地、実体/ヒゲや端回復は価格が受け入れられたかを近似する。これは心理の説明仮説であり、各指標の因果効果を実験が同定したわけではない。\n\nRSIの単発上昇と持続、BBの低い現幅と過去収縮からの再拡大、反対方向のImpulse禁止と解除を別にした。BB接触やRSI過熱だけで反転を確定せず、価格回復と他技術を重ねる。163/164の回復近似が逆行過多なら、単に不合格とせず、同じ出生を実反対側BBOで比較する。164のREVERSEはその対照であり、元方向継続/反転の追加確認を完成した政策とは称さない。\n\n次の仮説は、弱い回復へ逆らう条件と、本物の構造回復へ乗る条件を分け、方向/勢い/量/位置/当時履歴の複数役割で判別すること。固定回数の強制参加や取れなかった後の仮想利益を最適化対象にせず、成立した入口の先着・未知・利益損失・頻度と旧補完の寄与を比較する。結果を見て閾値を変える場合は新試行へ記録する。\n\n## 原典と研究派生\n\n- [Bollinger本人のCMT講演](https://cmtassociation.org/wp-content/uploads/2024/01/Bollinger-Trading-Bands-1.pdf)（2026-11-14確認）：バンドとオシレーターを組み合わせ、価格動作も確認する考え方を参考にした。動的σの外→内クロスとσmin/max圧縮は研究派生で、以前の固定バンド価格又は厳密なbandwidthの再現ではない。\n- [Elder公式マニュアル](https://s3-us-west-2.amazonaws.com/elderdownload/wp/wp-content/uploads/20180906134024/Elder-disk-for-TradeStation-v4.1.pdf)（2026-11-14確認）：Impulseを単独入口ではなく方向の禁止/許可フィルターとして扱い、長短衝突を待つ考え方を参考にした。既存EMA21とHistによる近似で、原EMA13の忠実再現ではない。\n\n公開説明は個別候補の利益を証明しない。元の候補辞書・Source、履歴窓と未知の契約、人工証拠を163のSource/出生正本へ保存した。共通知見の索引と閲覧CSVは全体研究側で整理する。\n'''
    for trial,destination in [(163,T163),(164,T164)]:
        (destination/'分類時計と次の仮説.md').write_text(explanation,encoding='utf-8');settings(trial,destination)


# ----------------------------------------
def archive(destination: Path,paths: list[Path]) -> list[dict]:
    """
    機能: 原本byteを変えずZIPへ格納し、全memberのCRC・SHAと前後同体を確認する。
    引数: destination(Path)、paths(list[Path])。
    返り値: list[dict]はmemberの由来・サイズ・SHA。
    """
    records=[reference(p) for p in sorted(set(paths))]
    with zipfile.ZipFile(destination,'w',allowZip64=True) as target:
        for record in records:
            path=ROOT/record['path'];kind=zipfile.ZIP_STORED if path.suffix in ('.npz','.gz','.zip') else zipfile.ZIP_DEFLATED
            target.write(path,arcname=record['path'],compress_type=kind,compresslevel=None if kind==zipfile.ZIP_STORED else 9)
    with zipfile.ZipFile(destination) as result:
        assert result.testzip() is None
        for record in records:
            body=result.read(record['path']);assert len(body)==record['bytes']
            assert hashlib.sha256(body).hexdigest()==record['sha256']==sha(ROOT/record['path'])
    return records


def source_files(folder: str) -> list[Path]:
    """
    機能: 指定作業フォルダ直下の小型Source・仕様・証拠だけを列挙する。
    引数: folder(str)はリポジトリ相対フォルダ。
    返り値: list[Path]。生成数値フォルダ・実行exe・pycは含めない。
    """
    return [p for p in (ROOT/folder).iterdir() if p.is_file() and (p.suffix in ('.py','.go','.mod','.md','.json','.txt'))]


def reproduction(trial: int,destination: Path) -> None:
    """
    機能: 作業cache不要の参照関係と凍結Sourceの再現手順を記録する。
    引数: trial(int)、destination(Path)。
    返り値: None。正式データや既存成果物を上書きする手順を避ける。
    """
    text=f'''# {trial} 再現手順\n\n2026-11-14。Windows・Python3.14.3、NumPy2.5.4、ijson3.6.0、tzdata2026.6。Go版は保存索引に記録する。作者Sourceと自然値は固定、実行環境/証拠/全member指紋は[保存索引](再現資料/保存索引.json)に記録した。\n\n## 正本の構成\n\n- [163の出生と統計正本](../00163_履歴を含む複合入口を任意幅と場末まで検証する/再現資料/出生と統計正本.zip)：12幅の全出生、候補辞書2版、出生証拠、163全統計と軸・当時の発見候補。NPZは既に圧縮済みで、そのbyteを外側ZIPへ無圧縮格納する。\n- [164の分類と比較正本](../00164_IFD最初到達の確定時計で入口と反転を比較する/再現資料/分類と比較正本.zip)：164全統計、軸、分類差分と金融不変、当時の発見候補。出生とRaw/数値表は重複しない。\n- [共用価格索引](../../inputs/00163_任意幅の共用価格索引/README.md)：価格索引35,138,192B、Go観測14,476,132B、数値表13,071,641B。73場ごとのmanifest参照は相対basenameなので別の親フォルダでも有効。raw.pathのSドライブ絶対パスは由来メタデータとして非改変。\n- [162Source](../00162_複合入口を広く探索し値幅ごとに過去選択する/再現資料/Source.zip)と[162出生と探索](../00162_複合入口を広く探索し値幅ごとに過去選択する/再現資料/出生と探索.zip)：Context163の親が参照する旧データ部品/金融表。共有148・161cacheの大きな複製を新たに作らない。\n\n全件MD転記や大量画像を作らず、数値NPZと軸JSONを正本とする。閲覧CSVは全体研究側が整理する。\n\n## 新しいcheckoutでの再現\n\n既存work成果物のない別checkoutを使う。リポジトリ内の正式inputs/00148の固定取得・100特徴・全生存入口を用意し、親と本試行の条件・検査を保持する。162Source.zip→163Source.zipの順でルートへ展開し、164を行う場合は164Source.zipも展開する。ZIP memberはリポジトリ相対work/...であり、既存ファイルがある場合は保存指紋が同一であることを確認する。旧161のfeature2cacheは不要で、ラッパーが正式148から同じ特徴を射影する。\n\n元Sourceは数値表のworkパスを持つため、複製せずJunctionを一つ作る。Source保存済みの親フォルダで以下を実行する（既存の自然数値表があれば作成しない）。\n\n```powershell\nNew-Item -ItemType Junction -Path 'work/163任意幅の数値化/自然数値表' -Target (Resolve-Path -LiteralPath 'inputs/00163_任意幅の共用価格索引/数値表')\n& 'work/複合テクニカル学習環境/Scripts/python.exe' -X utf8 'work/163_164正式保存/正式入力から再現する.py' --trial {trial}\n```\n\nラッパーはSource byteを変更しない。正式148の値同体loadとF検査のwork内保存先だけを実行時に接続する。163では全出生と全探索/ATRを再計算し、164では163正本の出生/旧統計を復元して全NORMAL/REVERSEを再計算する。NPZの全配列を参照正本とNaN込み同値比較し、元Source前後SHAを確認する。再現確認票はwork/163_164正式保存へ置く。ラッパーは保存時にpy_compileと--helpだけを確認し、完成自然値全体を追加再走査していない。この限界を人工/自然監査の実施済み範囲と混同しない。\n\n## Rawから作り直す場合\n\n163Source.zipのGoは標準ライブラリのみ。隔離作業先で `go test ./...`、`go vet ./...`、`go build` を行う。原板を配置する場合は固定取得入力に記録された原板パス・SHAと一致させる。元run_raw163.pyは停止時exeのbyteSHAも要求するため、再ビルドbinaryが異なる環境では旧停止票を上書きせず、新しい再現検査票へSource/環境/binarySHAを別記する。Go CLIの `--mode index` → `--mode evaluate` は共用索引manifestと観測条件SHAを渡し、未作成の出力先を用いる。仕様はSource.zip内work/163任意幅Raw索引/README.mdに保持した。\n\n数値表だけ再生成する場合は arrays163.read_table(価格索引親,manifestSHA,Raw観測親,manifestSHA,観測条件path,SHA) → save_table(未作成先)。旧125/200×H30/H60と同体・実Bid/Ask・全CRC/SHAを検査する。原板や観測を恒久先へ再複製せず、比較後の再現作業物はworkへ置く。\n\n## 検査の範囲\n\n163のGo作者人工48,832状態、独立線形人工40,320状態、旧148同体先着253,136件、全原始IFD数値3,037,632件、全探索配列セル3,037,632件、SESSION成熟63,284件、集計人工25,200セルを記録した。164は全原始分類/成熟3,037,632件と、支持186/層化を含む9,402政策/旧7対照の独立再集計、および全NORMAL非分類金融の163同体を記録した。全840,960政策の独立再集計又は自然新幅すべての別線形再走査とは称さない。\n\n候補Sourceの人工は初版133,164鏡像行、履歴49,288鏡像行・32,208未来毒行等。作者候補関数の独立自然再実装ではない。\n\n数値化の初期参照型検査で追加statメタデータを認めない停止があり、参照形を訂正後、再人工・Source停止・全数値化を実行した。訂正前Source/停止票とRaw参照形の訂正票も163Sourceへ小型証拠として保持し、初回から正常だったとは書かない。最終正式Source SHAは arrays163.py の0231ea14ce03979a733d1a307c175266ff6aed2492dbc283162de63e153b23e6。\n'''
    (destination/'再現手順.md').write_text(text,encoding='utf-8')


# ----------------------------------------
def main() -> None:
    """
    機能: 凍結した入力・Source・結果を正式ZIPと指紋索引へ保存する。
    引数: なし。共有148/161/Rawと旧試行・globalを変更しない。
    返り値: None。163/164の資料だけを作成する。
    """
    assert sha(T163/'条件.json')==BOOKS[163] and sha(T164/'条件.json')==BOOKS[164]
    assert sha(SHARED/'保存索引.json')=='19b81bf6b135c65b6355e2de3d1c24008a4c7c70616f7d45e5b87ccb6a23768b'
    original=[]
    for folder in ['work/163入口と任意幅','work/163任意幅Raw索引','work/163任意幅の数値化',
        'work/163独立Raw照合','work/163集計の独立確認','work/164先着確定と反転比較','work/164独立確認','work/164先着確定時計の確認']:
        original+=source_files(folder)
    original+=[p for parent in [ROOT/'work/163入口と任意幅/全出生',ROOT/'work/163入口と任意幅/広い評価',ROOT/'work/164先着確定と反転比較/比較'] for p in parent.iterdir() if p.is_file()]
    before={p:sha(p) for p in original}
    docs()
    common_sources=[ROOT/'work/151過去場判別/data151.py',ROOT/'work/161三時間帯入口のデータ/data161.py',
        ROOT/'work/162入口探索/共通.py',ROOT/'work/162入口探索/評価基盤.py',ROOT/'work/162可変幅評価/outcomes162.py']
    common_sources+=source_files('work/162複合入口候補')
    common_sources=[p for p in common_sources if p.name not in ('候補辞書.json','履歴候補辞書.json')]
    src163=common_sources+source_files('work/163入口と任意幅')+source_files('work/163任意幅Raw索引')+source_files('work/163任意幅の数値化')+source_files('work/163独立Raw照合')+source_files('work/163集計の独立確認')
    src164=source_files('work/164先着確定と反転比較')+source_files('work/164独立確認')+source_files('work/164先着確定時計の確認')
    own=source_files('work/163_164正式保存')+list((ROOT/'work/163_164保存QA').glob('*.py'));src163+=own;src164+=own
    birth163=[p for folder in ['work/163入口と任意幅/全出生','work/163入口と任意幅/広い評価'] for p in (ROOT/folder).iterdir() if p.is_file()]
    birth163+=[ROOT/'work/162複合入口候補/候補辞書.json',ROOT/'work/162複合入口候補/履歴候補辞書.json']
    result164=[p for p in (ROOT/'work/164先着確定と反転比較/比較').iterdir() if p.is_file()]
    common_refs=[reference(SHARED/'保存索引.json'),reference(ROOT/'inputs/00148_全1分入口母集団/固定取得入力.json.gz'),
        reference(ROOT/'inputs/00148_全1分入口母集団/100特徴の列定義.json'),reference(T162/'再現資料/Source.zip'),reference(T162/'再現資料/出生と探索.zip')]
    environment={'保存時計UTC':datetime.now(timezone.utc).isoformat(),'Python':sys.version,'OS':platform.platform(),
        'NumPy':importlib.metadata.version('numpy'),'ijson':importlib.metadata.version('ijson'),'tzdata':importlib.metadata.version('tzdata'),
        'Go':subprocess.check_output(['go','version'],text=True).strip()}
    for trial,destination,sources,data,name in [(163,T163,src163,birth163,'出生と統計正本.zip'),(164,T164,src164,result164,'分類と比較正本.zip')]:
        reproduction(trial,destination);folder=destination/'再現資料';folder.mkdir(exist_ok=True)
        source_members=archive(folder/'Source.zip',sources);data_members=archive(folder/name,data)
        refs=common_refs.copy()
        if trial==164:refs.extend([reference(T163/'再現資料/Source.zip'),reference(T163/'再現資料/出生と統計正本.zip')])
        index={'成功':True,'試行':trial,'条件':reference(destination/'条件.json'),'実行環境':environment,
            '正本':[{'archive':reference(folder/'Source.zip'),'members':source_members},{'archive':reference(folder/name),'members':data_members}],
            '共用入力と親参照':refs,'共有入力の由来':'163の1回のRaw走査・任意幅Go観測・純数値化。inputs/00163へ全152ファイルを元byte同体で一度保存。work原本は進行実験の参照用で恒久正本ではない。',
            '非重複':'本ZIPに共有Raw/価格索引/Go観測/数値NPZ/161cacheを含めない。164は163出生も含めない。',
            '保存時検査':'全ZIP CRC・全member bytes/SHA・元Source/数値前後SHA、条件不変。追加ラッパーはcompile/helpだけ。',
            '未採用の全期探索':True,'旧試行非改変':True}
        save(folder/'保存索引.json',index)
    assert all(sha(path)==digest for path,digest in before.items())
    assert sha(T163/'条件.json')==BOOKS[163] and sha(T164/'条件.json')==BOOKS[164]
    print(json.dumps({'成功':True,'163保存索引':reference(T163/'再現資料/保存索引.json'),'164保存索引':reference(T164/'再現資料/保存索引.json'),
        '凍結原本前後同体':len(before)},ensure_ascii=False))


if __name__=='__main__':main()
