"""163以降が再用する価格索引・Go観測・数値表を一度だけ恒久保存する。"""
from pathlib import Path
import gzip
import hashlib
import json
import shutil
import zipfile

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
DESTINATION=ROOT/'inputs/00163_任意幅の共用価格索引'
GROUPS={'価格索引':'work/163任意幅Raw索引/自然索引',
    'Raw観測':'work/163任意幅Raw索引/自然観測',
    '数値表':'work/163任意幅の数値化/自然数値表'}


def sha(path: Path) -> str:
    """
    機能: ファイルの物理指紋を計算する。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    with path.open('rb') as source:return hashlib.file_digest(source,'sha256').hexdigest()


def main() -> None:
    """
    機能: 相対manifest参照を保持したまま共有生成入力を一つの正式配置へ保存する。
    引数: なし。停止済みwork原本を読む。
    返り値: None。元Source/manifest/入力bytesを変更せず、CRC・SHA・参照を確認する。
    """
    assert not DESTINATION.exists();DESTINATION.mkdir(parents=True)
    registry=[];groups={}
    for name,origin in GROUPS.items():
        source=ROOT/origin;target=DESTINATION/name;target.mkdir()
        files=sorted(p for p in source.iterdir() if p.is_file())
        for path in files:
            before=sha(path);destination=target/path.name
            shutil.copyfile(path,destination)
            assert sha(path)==sha(destination)==before
            if destination.suffix=='.gz':
                with gzip.open(destination,'rb') as data:
                    for _ in iter(lambda:data.read(1<<20),b''):pass
            elif destination.suffix=='.npz':
                with zipfile.ZipFile(destination) as archive:assert archive.testzip() is None
            registry.append({'origin':path.relative_to(ROOT).as_posix(),'path':destination.relative_to(ROOT).as_posix(),
                'bytes':destination.stat().st_size,'sha256':before})
        if name in ('価格索引','Raw観測'):
            manifest=json.loads((target/'manifest.json').read_text(encoding='utf-8'))
            for scene in manifest['scenes']:
                ref=scene['index'] if name=='価格索引' else scene['file']
                assert Path(ref['path']).name==ref['path'] and sha(target/ref['path'])==ref['sha256']
        groups[name]={'origin':origin,'path':target.relative_to(ROOT).as_posix(),'files':len(files),
            'bytes':sum(p.stat().st_size for p in target.iterdir())}
    proof={'成功':True,'由来':'163でRaw全73場から一度生成し、163/164以後で再用する同一入力。',
        '保存日':'2026-11-14','Sourceと数値を非改変':True,'manifest参照形':'各ディレクトリ内の相対名を保持。raw.pathの絶対pathは元原板の由来として非改変。',
        'work原本':'実行中の後続研究を壊さないため元の作業コピーは移動しない。正式な恒久実体はこの一組だけ。',
        'groups':groups,'files':registry,'保存SourceSHA256':sha(Path(__file__))}
    (DESTINATION/'保存索引.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (DESTINATION/'README.md').write_text('''# 任意幅の共用価格索引と金融入力

2026-11-14。163で生成し163/164以後が再用する共有入力を、この一組だけ恒久保存する。各試行の正本ZIPへ同じデータを重複させない。

- `価格索引/`：73場の48byte原行順数値をgzipで保存。manifestのindex.pathは同じdirectory基準の相対名。
- `Raw観測/`：12幅×H30/H60/H120/SESSIONのGo観測。manifestのfile.pathは同じdirectory基準。独立Raw照合の入力として再用する。
- `数値表/`：探索用NPZと識別・入力確認。load_table(directory,expected)はdirectory基準で復元する。

[保存索引](保存索引.json)に由来work path、元と同じSHA・サイズ・保存Sourceを記録。元manifestの絶対raw.pathは由来であり、保存時に書き換えていない。各gzip/NPZの全CRCと物理SHA、manifest内の相対参照を確認した。原板本体、161の作業cache、各試行の統計出力はここへ複製していない。

研究再現時は各試行のSourceを別checkoutへ展開し、必要なら保存索引のorigin相対位置へこの一組を作業用に復元する。元Sourceとmanifest bytesを変更しない。後続が実行中の元workは移動せず残したが、正式な閲覧・保存は本directoryを参照する。
''',encoding='utf-8')
    print(json.dumps({'成功':True,'groups':groups,'files':len(registry),'index_sha256':sha(DESTINATION/'保存索引.json')},ensure_ascii=False))


if __name__=='__main__':
    main()
