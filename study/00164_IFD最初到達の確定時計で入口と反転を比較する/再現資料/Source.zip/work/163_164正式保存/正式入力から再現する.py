"""正式共有入力と圧縮正本から163又は164を新しいcheckout内で再現する。"""
from pathlib import Path,PurePosixPath
from io import BytesIO
import argparse
import hashlib
import importlib.util
import json
import sys
import zipfile

import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
T162=ROOT/'study/00162_複合入口を広く探索し値幅ごとに過去選択する'
T163=ROOT/'study/00163_履歴を含む複合入口を任意幅と場末まで検証する'
T164=ROOT/'study/00164_IFD最初到達の確定時計で入口と反転を比較する'


def sha(path: Path) -> str:
    """
    機能: 全物理ファイルを読了して固定指紋を返す。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    with path.open('rb') as source:return hashlib.file_digest(source,'sha256').hexdigest()


def module(path: Path,name: str) -> object:
    """
    機能: mainを呼ばずSourceを登録名で読み込む。
    引数: path(Path)、name(str)。
    返り値: objectはmodule。
    """
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec)
    sys.modules[name]=value;spec.loader.exec_module(value);return value


def restore(path: Path,prefixes: tuple[str,...]) -> None:
    """
    機能: 正本の選択memberを安全な相対位置へ復元し、既存なら同体を要求する。
    引数: path(Path)は正式ZIP、prefixes(tuple[str,...])は復元対象。
    返り値: None。既存成果物の上書きは禁止する。
    """
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        for name in archive.namelist():
            if not name.startswith(prefixes):continue
            relative=PurePosixPath(name);assert not relative.is_absolute() and '..' not in relative.parts
            target=ROOT.joinpath(*relative.parts);assert target.resolve().is_relative_to(ROOT.resolve())
            body=archive.read(name)
            if target.exists():assert target.read_bytes()==body
            else:target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(body)


def compare_arrays(reference: Path,prefix: str) -> int:
    """
    機能: 参照NPZの全配列を再現出力へ意味値で照合する。
    引数: reference(Path)は正本ZIP、prefix(str)は参照memberの共通先頭。
    返り値: intは比較した配列数。NPZ内部のZIP日時byte一致は要求しない。
    """
    count=0
    with zipfile.ZipFile(reference) as archive:
        for name in archive.namelist():
            if not name.startswith(prefix) or not name.endswith('.npz'):continue
            with np.load(BytesIO(archive.read(name)),allow_pickle=False) as original,np.load(ROOT/name,allow_pickle=False) as actual:
                assert original.files==actual.files
                for key in original.files:
                    assert np.array_equal(original[key],actual[key],equal_nan=True),(name,key)
                    count+=1
    return count


# ----------------------------------------
def main() -> None:
    """
    機能: Source非改変のまま特徴loadと検査保存先だけを実行時に接続して再現する。
    引数: CLI --trial(int)は163又は164。新しいcheckoutでの実行を要求する。
    返り値: None。正式試行を上書きせずworkへ再現検査を残す。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--trial',type=int,choices=(163,164),required=True)
    args=parser.parse_args();engine=ROOT/'work/163入口と任意幅'
    output=engine/'広い評価' if args.trial==163 else ROOT/'work/164先着確定と反転比較/比較'
    assert not output.exists(),'元成果物のあるcheckoutでは実行しない'
    if args.trial==163:assert not(engine/'全出生').exists()
    canonical=ROOT/'inputs/00163_任意幅の共用価格索引/数値表'
    alias=ROOT/'work/163任意幅の数値化/自然数値表'
    assert alias.exists() and sha(alias/'任意幅配列.npz')==sha(canonical/'任意幅配列.npz'),'再現手順のJunctionを先に用意する'
    restore(T162/'再現資料/出生と探索.zip',('work/162可変幅評価/自然射影/',))
    reference163=T163/'再現資料/出生と統計正本.zip'
    restore(reference163,('work/162複合入口候補/候補辞書.json','work/162複合入口候補/履歴候補辞書.json'))
    if args.trial==164:
        restore(reference163,('work/163入口と任意幅/全出生/','work/163入口と任意幅/広い評価/'))
    sys.path.insert(0,str(ROOT/'work/162入口探索'))
    common162=module(ROOT/'work/162入口探索/共通.py','共通');factory=common162.data_module
    features=factory().load_feature_from_formal()
    def formal_data() -> object:
        """
        機能: 値同体の正式148特徴を固定161データSourceへ供給する。
        引数: なし。
        返り値: objectはデータmodule。作業用feature2cacheを複製しない。
        """
        value=factory();value.load_feature_dataset=lambda:features;return value
    common162.data_module=formal_data
    sys.path.insert(0,str(engine));common163=module(engine/'共通163.py','共通163')
    qa=HERE/f'再現{args.trial}の検査';assert not qa.exists();qa.mkdir()
    original163=common163.TRIAL;common163.TRIAL=qa/'163';common163.TRIAL.mkdir()
    (common163.TRIAL/'条件.json').write_bytes((original163/'条件.json').read_bytes())
    paths=[engine/'共通163.py',engine/'評価163.py',engine/'全出生を作る.py',engine/'広く評価する.py']
    if args.trial==164:paths.append(ROOT/'work/164先着確定と反転比較/比較する.py')
    before={str(path.relative_to(ROOT)):sha(path) for path in paths}
    if args.trial==163:
        module(engine/'全出生を作る.py','再現163出生').main();module(engine/'広く評価する.py','再現163評価').main()
        count=compare_arrays(reference163,'work/163入口と任意幅/')
    else:
        component=module(ROOT/'work/164先着確定と反転比較/比較する.py','再現164比較')
        component.TRIAL=qa/'164';component.TRIAL.mkdir();(component.TRIAL/'条件.json').write_bytes((T164/'条件.json').read_bytes())
        component.main();count=compare_arrays(T164/'再現資料/分類と比較正本.zip','work/164先着確定と反転比較/比較/')
    assert all(sha(ROOT/path)==digest for path,digest in before.items())
    proof={'成功':True,'試行':args.trial,'全配列照合数':count,'Source非改変':before,
        '正式148特徴からの射影':features.sources,'参照163ZIP_SHA256':sha(reference163),
        '注意':'金融の前提・取得母集団を共有した再現であり、新しい未見性能検証ではない。'}
    (qa/'再現確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'配列数':count},ensure_ascii=False))


if __name__=='__main__':main()
