"""独立保存QAの成功後、163/164の正式指紋を停止する。"""
from pathlib import Path
from datetime import datetime,timezone
import argparse
import hashlib
import json
import shutil

ROOT=Path(__file__).resolve().parents[2]
TRIALS=[ROOT/'study/00163_履歴を含む複合入口を任意幅と場末まで検証する',
        ROOT/'study/00164_IFD最初到達の確定時計で入口と反転を比較する']


def reference(path: Path) -> dict:
    """
    機能: 正式ファイルを物理SHA・サイズで参照する。
    引数: path(Path)。
    返り値: dictはリポジトリ相対指紋。
    """
    with path.open('rb') as source:digest=hashlib.file_digest(source,'sha256').hexdigest()
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':digest}


# ----------------------------------------
def main() -> None:
    """
    機能: 成功した独立確認を両試行へ保存し、全正式資料の停止指紋を残す。
    引数: CLI --qa-ticket(Path)は独立保存確認票。
    返り値: None。Source/自然値/条件/旧試行は変更しない。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--qa-ticket',type=Path,required=True)
    args=parser.parse_args();qa=json.loads(args.qa_ticket.read_bytes());assert qa.get('成功') is True
    result=[]
    for trial in TRIALS:
        proof=trial/'検査/正式保存の独立確認.json';shutil.copyfile(args.qa_ticket,proof)
        paths=[path for path in trial.rglob('*') if path.is_file() and path.name!='正式保存の停止.json']
        index={'成功':True,'保存時計UTC':datetime.now(timezone.utc).isoformat(),
            '正式保存Source':reference(Path(__file__)),'独立保存QA':reference(proof),
            '正式全ファイル':[reference(path) for path in sorted(paths)],
            '共有入力索引':reference(ROOT/'inputs/00163_任意幅の共用価格索引/保存索引.json'),
            '範囲':'正式保存だけを停止する。研究全体の継続・次試行の採否を変更しない。'}
        stop=trial/'検査/正式保存の停止.json'
        stop.write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        result.append(reference(stop))
    print(json.dumps({'成功':True,'停止票':result},ensure_ascii=False))


if __name__=='__main__':main()
