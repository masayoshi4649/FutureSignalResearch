"""未来H完了と既に観測した最初touchを別時計として扱う提案の純計算。"""
import numpy as np


def observed_first_touch(strict_label: np.ndarray,direction: np.ndarray,financial_known: np.ndarray,
                          exit_time: np.ndarray,strict_known_at: np.ndarray) -> tuple:
    """
    機能: 観測済みtouchをその到達時点でF/Aへ確定し、未到達完了Nと未確定Cを保つ。
    引数: strict_label/direction(np.ndarray[int8])、financial_known(np.ndarray[bool])、exit_time/strict_known_at(np.ndarray[float])は同shapeの固定観測。
    返り値: tuple[np.ndarray,np.ndarray]は提案labelとその成熟時計。元配列は変更しない。
    """
    label=np.asarray(strict_label);move=np.asarray(direction);known=np.asarray(financial_known)
    clock=np.asarray(exit_time);mature=np.asarray(strict_known_at)
    assert label.shape==move.shape==known.shape==clock.shape==mature.shape
    assert np.isin(label,[-1,0,1,2]).all() and np.isin(move,[-1,0,1]).all() and known.dtype==np.bool_
    hit=move!=0;complete=label!=2
    assert np.all(~hit|known),'金融未知なのにtouch方向がある'
    assert np.all((label==2)|(label==move)),'旧strict labelと保存touch方向の不整合'
    assert np.all((~known)|(hit|complete)),'未完了・未touchなのに金融既知'
    assert np.array_equal(np.isfinite(clock),known)
    assert np.array_equal(np.isfinite(mature),complete)
    revised=np.where(hit,move,label).astype(np.int8)
    known_at=np.where(hit,clock,mature).astype(np.float64)
    assert np.array_equal(np.isfinite(known_at),revised!=2)
    return revised,known_at
