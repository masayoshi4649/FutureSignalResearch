"""新規政策や候補を選ばず、163保存観測の吸収状態としての先着を確認する。"""
from pathlib import Path
import importlib.util
import hashlib
import json
import math

import numpy as np

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def sha(path: Path) -> str:
    """
    機能: Sourceと既存数値表の物理SHA256を求める。
    引数: path(Path)は対象ファイル。
    返り値: strは小文字16進SHA256。
    """
    with path.open('rb') as source:
        return hashlib.file_digest(source,'sha256').hexdigest()


def main() -> None:
    """
    機能: 提案の純計算を人工で確認し、保存全セルの再分類前提だけを検査する。
    引数: なし。163観測配列は読むが、入口候補・選択結果・新規性能は読まない。
    返り値: None。変更しない元指紋と語義検査票を保存する。
    """
    source=HERE/'先着確定の純計算.py';spec=importlib.util.spec_from_file_location('observed_touch_semantics',source)
    pure=importlib.util.module_from_spec(spec);spec.loader.exec_module(pure)
    # ----------------------------------------
    # 後続経路が完了/EOF/gap/phaseのどれでも既知touchは同じ方向で吸収される。
    labels=np.array([2,2,1,-1,0,2],dtype=np.int8)
    direction=np.array([1,-1,1,-1,0,0],dtype=np.int8)
    known=np.array([True,True,True,True,True,False])
    exits=np.array([200,200,200,200,1900,math.nan])
    maturity=np.array([math.nan,math.nan,1900,1900,1900,math.nan])
    original=tuple(a.copy() for a in (labels,direction,known,exits,maturity))
    revised,at=pure.observed_first_touch(labels,direction,known,exits,maturity)
    assert revised.tolist()==[1,-1,1,-1,0,2]
    assert np.array_equal(at,np.array([200,200,200,200,1900,math.nan]),equal_nan=True)
    assert all(np.array_equal(a,b,equal_nan=True) for a,b in zip(original,(labels,direction,known,exits,maturity),strict=True))
    try:pure.observed_first_touch(np.array([2]),np.array([1]),np.array([False]),np.array([math.nan]),np.array([math.nan]))
    except AssertionError:pass
    else:raise AssertionError('未観測touchをFへ補った')
    # ----------------------------------------
    # これは全保存観測の状態整合だけの診断で、新しい入口条件の評価ではない。
    table=ROOT/'work/163任意幅の数値化/自然数値表/任意幅配列.npz'
    expected='72f8a79bcfb56585ee9276632d82705e6467bd99db5f9c03648a2b343b7c0a9a'
    assert sha(table)==expected
    with np.load(table,allow_pickle=False) as data:
        strict=data['label'];move=data['direction'];financial=data['known'];clock=data['exit_time'];mature=data['known_at']
    new,known_at=pure.observed_first_touch(strict,move,financial,clock,mature)
    changed=(strict==2)&(move!=0)
    assert np.all(new[changed]==move[changed]) and np.array_equal(np.isnan(known_at),new==2)
    assert np.array_equal(new[~changed],strict[~changed])
    assert np.all(clock[(strict==1)|(strict==-1)]<=mature[(strict==1)|(strict==-1)])
    assert sha(table)==expected
    proof={'成功':True,'用途':'既存観測の語義診断。164の新規採否/性能/採用は未実行。',
        '作者区分':'Go作者による観測契約説明と新評価時計の純計算。Raw自然同体の外部独立監査とは分ける。',
        'SourceSHA256':sha(source),'検査器SHA256':sha(Path(__file__)),'保存表SHA256':expected,
        '全状態数':int(strict.size),'未来完了に関係なく既知touch方向へ移せる旧C':int(changed.sum()),
        'うち順行':int(((strict==2)&(move==1)).sum()),'うち逆行':int(((strict==2)&(move==-1)).sum()),
        'その他の旧labelを変更しない':True,'入力配列変更なし':True,'元金融値と取得集合は未変更':True,
        '成熟時計':'既知touchはそのtouch/exit時計。Nは旧H endpoint/SESSION境界時計、未確定CはNaN。',
        '注意':'F/(F+A)は観測到達済み条件付き率。N/C、全取得分母率、金融未知、実現勝率を別に残す。'}
    (HERE/'観測先着の語義確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':
    main()
