"""107再現保存の成功gateと所在分類だけを手製metadataで確認する。"""
from __future__ import annotations

from copy import deepcopy
import importlib.util
from pathlib import Path
import tempfile
import unittest

WORK=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('archive_metadata107',WORK/'再現metadataを準備する.py')
M=importlib.util.module_from_spec(spec)
spec.loader.exec_module(M)


def fixture() -> tuple[dict,dict,dict,list[str]]:
    """
    機能: 金融値のない手製70件の完了schemaを作る。
    引数: なし。
    返り値: tuple[dict,dict,dict,list[str]] は条件・完了・保存確認・場名。実成功ではない。
    """
    ids=[f'人工{i:02d}' for i in range(70)]
    c={'version':1,'trial':107,'fixed':True,'configs':[{} for _ in range(24)]}
    d={'version':1,'trial':107,'stage':'full70','success':True,'condition_sha256':M.CONDITION_SHA,'sessions':70,'books_per_scene':24,'books':1680,
       'before':{'手製code':'a'},'after':{'手製code':'a'},'unchanged':True,'input_mode':'recorded_public_106','source_reexecuted':False,'features_recomputed':False,'charts_recomputed':False,'cmp_recomputed':True,'financial_executed':True,
       'results':[{'session':sid,'books':24,'base_control_books':12} for sid in ids]}
    s={'成功':True,'会計':1680,'資源':1680,'不一致数':0,'completionSHA256':'b'*64,'conditionSHA256':M.CONDITION_SHA,'出力SHA256':{'結果.json':'c'*64},'前後不変':True,'入力codeSHA256前':{'手製':'a'},'入力codeSHA256後':{'手製':'a'}}
    return c,d,s,ids


class Tests(unittest.TestCase):
    """実ZIP・市場成果物を扱わないmetadata境界の検査。"""

    def test_success_gate(self) -> None:
        """
        機能: 全70正常metadataと5つの拒否を確認する。
        引数: self (Tests) は検査器。
        返り値: None。人工を実金融成功として保存しない。
        """
        c,d,s,ids=fixture()
        M.verify_success(c,d,s,ids,M.CONDITION_SHA,'b'*64,'c'*64)
        for mode in ('first2','失敗','0冊','保存別完了','入力変更'):
            with self.subTest(mode=mode):
                c,d,s,ids=fixture()
                if mode=='first2':d['stage']='first2'
                elif mode=='失敗':d['success']=False
                elif mode=='0冊':d['books']=0
                elif mode=='保存別完了':s['completionSHA256']='d'*64
                elif mode=='入力変更':d['after']['手製code']='変更'
                with self.assertRaises(AssertionError):M.verify_success(c,d,s,ids,M.CONDITION_SHA,'b'*64,'c'*64)

    def test_locations(self) -> None:
        """
        機能: 同SHA参照・新候補・Go環境と危険path拒否を確認する。
        引数: self (Tests) は検査器。
        返り値: None。ZIPの生成・読込は行わない。
        """
        item={'original_path':str(M.ROOT/'work/人工コード.go'),'SHA256':'a'*64,'restore':{'root':'repoRoot','relative':'work/人工コード.go'}}
        old={'kind':'既存archive','archive':{'path':'../旧/コード.zip','sha256':'b'*64},'entry':'repo/work/旧コード.go'}
        self.assertEqual(M.choose_location(item,{'a'*64:old}),old)
        self.assertEqual(M.choose_location(item,{})['kind'],'新archive候補')
        go=deepcopy(item);go['restore']={'root':'goRoot','relative':'src/fmt/print.go'}
        self.assertEqual(M.choose_location(go,{})['本文保存'],False)
        exe=deepcopy(item);exe['original_path']=str(M.ROOT/'work/実行物.exe');exe['restore']['relative']='work/実行物.exe'
        self.assertEqual(M.choose_location(exe,{'a'*64:old})['kind'],'外部実行物')
        self.assertFalse(M.choose_location(exe,{})['本文保存'])
        bad=deepcopy(item);bad['restore']['relative']='../脱出.go'
        with self.assertRaises(AssertionError):M.choose_location(bad,{})

    def test_unfixed_before_refs(self) -> None:
        """
        機能: 未固定雛形を市場参照へ進む前に拒否する。
        引数: self (Tests) は検査器。
        返り値: None。実成績を開かない。
        """
        p=WORK/'保存計画_未固定.json'
        with tempfile.TemporaryDirectory() as d:
            target=Path(d)/'未生成'
            with self.assertRaises(AssertionError):M.prepare(p,M.sha(p),target)
            self.assertFalse(target.exists())
            with self.assertRaises(AssertionError):M.publish_fixed_code(p,M.sha(p),target)
            self.assertFalse(target.exists())


if __name__=='__main__':
    unittest.main()
