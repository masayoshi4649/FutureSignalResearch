# 107の再現保存準備

全70金融・保存成功は未確認。埋込対応の先頭2は2/48成功、full70は進行中である。Rootが固定コードの先行保存だけを許可したため、金融条件4ab51b9f…の1032コードと確定済み事後コードを別の`fixed_code_only`計画で保存する。金融結果保存・正式再現.md・試行閉鎖は後段であり、この保存成功へ含めない。106の[再現手順](../../study/00106_収束失速で保護の起動と幅を切り替える/再現.md)と所在索引方式を継承し、旧106のZIP・閉鎖・コードは変更しない。

Rootの最終金融条件_埋込対応、同条件first2→full70金融、全70保存の成功後に、新しい保存計画を作る。準備helperは条件/完了/保存確認等の小metadataを結び、旧106の1343所在を引き継ぎ、107で追加されたコードだけを不足候補へ分類する。現時点では雛形は未固定で、実参照へ補完しない。

復元先は106と同じrepoRoot/neighborRoot/moduleCacheRoot/goRoot。元pathとSHAが同じ既存所在はそのまま再参照し、別pathでも同じSHAなら既存archive＋entryを新復元位置へ結ぶ。新規不足コードの同SHAは一つのentryへまとめる。GoRootと実行物は元path・サイズ・SHAの外部参照であり、stdlib/Tool/exe本文を同梱しない。Raw/CSV、Source/価格Tape、Header/Record本文、金融Native、全人工帳簿、Node/Python環境、xlsx/画像も同梱しない。条件に固定されたPowerShellはコードとして保存する。全codeの実SHA、旧ZIPのSHA/CRC・参照entryのSHA、新ZIP全entryの読戻しSHA/CRCを検査する。

旧107 `金融条件.json` 4ae0da3f…と先頭2完了5da988ec…は、0/2・0冊の失敗metadataとして残す。匿名埋込対応の別reader/CLI・新条件を別由来にし、旧first2を新しい成功へ読み替えない。旧失敗口の巨大入力やNativeを複製しない。

新条件は `金融条件_埋込対応.json` 4ab51b9f…を参照する。Rootのfull70初回起動は相対`--first2`が条件parent基準へ解決されて失敗し、金融未開始のまま終了した。同条件のまま絶対pathで再起動した経緯を成功会計へ足さない。再現argvは`--condition/--first2/--out/--plan`を絶対pathで記載し、固定PSを変更・再封印したとはしない。

## 段階

1. 現在：Root許可の固定コードだけを先行保存する。金融Native/経済結果の保存と試行閉鎖は行わない。
2. Rootの全70金融24×70=1680/B12×70成功、同条件の先頭2prefix、保存1680/不一致0を小receiptで確認する。
3. Rootがhelperと新計画のSHAを固定後、metadata候補を新work先へ生成する。同SHA既存所在/Go外部環境/新規不足候補を分ける。
4. 先行固定分ZIPは変更せず、確定した事後コードだけを別の不足ZIPへ追加する。旧archiveの全SHA/CRCと新entry読戻しSHA/CRC/安全pathを検査し、同体重複を格納しない。
5. 再現.mdは実argv・全成功SHAと実Viewer範囲/報告/xlsx回数を受領してから仕上げる。今は未検証草案のみ。

`再現metadataを準備する.py --plan <Root保存計画の絶対path> --plan-sha <SHA> --out <新規work候補の絶対path>`は、全70成功後のJSON/手順草案だけを出す。雛形`保存計画_未固定.json`は未固定のままである。

`--code-only`を追加すると、別の固定code保存計画から`再現コード_固定分.zip`、`再現コードの所在_固定分.json`、`再現コード保存の確認_固定分.json`を出す。金融完了・保存結果・Nativeを開かず、保存後のreceiptを同じZIPへ入れる循環参照も作らない。FileRefは計画parent基準、条件内codeは条件parent基準又は絶対path。

107は30分静観の固定条件である。20分は今後の別条件であり、今回へ混ぜない。xlsxは候補別sheetに70場の損益と累計を示す新builderの停止後に追加する。旧single107builderは未使用であり、今回の実使用コードへ加えない。報告の型人工の由来に旧xlsx準備が記録されていても、実ブック編集の証明ではない。

コードだけで金融再生一式が完結するとはしない。保存済みSource/Tape/public Record、元環境、同じ実行物とその由来が必要。実行前条件・旧閉鎖・旧ZIPを上書きせず、再build後のexeが同じSHAになる保証も作らない。市場結果・未見安定性・実採用・研究目標の成功はこの準備では主張しない。
