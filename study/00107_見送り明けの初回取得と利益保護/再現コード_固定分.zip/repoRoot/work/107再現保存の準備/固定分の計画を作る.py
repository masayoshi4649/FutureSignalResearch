"""Root許可の固定コード保存に限る停止証拠と実行前計画を新規作成する。"""
from __future__ import annotations

import importlib.util
import json
from pathlib import Path
import subprocess
import sys

WORK=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('107固定コード保存',WORK/'再現metadataを準備する.py')
M=importlib.util.module_from_spec(spec)
spec.loader.exec_module(M)


def write_new(path: Path, value: dict) -> None:
    """
    機能: 小metadataを既存ファイルへ上書きせず新規保存する。
    引数: path (Path)、value (dict) は保存先と内容。
    返り値: None。金融結果や価格データは受け取らない。
    """
    with path.open('x',encoding='utf-8',newline='\n') as f:
        json.dump(value,f,ensure_ascii=False,indent=2)
        f.write('\n')


def file_ref(path: Path) -> dict:
    """
    機能: コード又は小metadataの絶対pathと現物SHAを固定する。
    引数: path (Path) は許可された対象。
    返り値: dict はFileRef。市場本文を開かない。
    """
    return {'path':path.resolve().as_posix(),'sha256':M.sha(path)}


def main() -> None:
    """
    機能: 手製metadata検査後に準備停止とcode-only計画を固定する。
    引数: なし。
    返り値: None。ZIP生成・正式配置・金融は別口であり実行しない。
    """
    plan_path=WORK/'固定コード保存の計画.json'
    stop_path=WORK/'準備停止.json'
    proof_path=WORK/'metadataの確認.json'
    assert not any(p.exists() for p in (plan_path,stop_path,proof_path))
    sources=['README.md','再現metadataを準備する.py','metadataを確認する.py','固定分の計画を作る.py','保存計画_未固定.json','再現手順_未検証草案.md']
    owned={str((WORK/name).relative_to(M.ROOT)).replace('\\','/'):M.sha(WORK/name) for name in sources}
    result=subprocess.run([sys.executable,'-B','-X','utf8',str(WORK/'metadataを確認する.py'),'-v'],capture_output=True,text=True,encoding='utf-8',check=False)
    assert result.returncode==0,result.stderr
    assert all(M.sha(M.ROOT/name)==h for name,h in owned.items())
    proof={'成功':True,'scope':'手製metadataと所在分類のみ。市場・実ZIPの検査ではない','test_exit':result.returncode,'stdout':result.stdout,'stderr':result.stderr,'所有コードSHA256':owned,'市場/Raw/Native/Source/金融/API/xlsx':0}
    write_new(proof_path,proof)
    stop={'成功':True,'scope':'107固定コードの先行保存口と全成功後metadata候補口の準備停止','所有コードSHA256':owned,
          '直接再用':file_ref(M.OLD_PATH),'人工確認':file_ref(proof_path),'金融条件SHA256':M.CONDITION_SHA,
          '旧106所在SHA256':M.INDEX106_SHA,'旧106閉鎖SHA256':M.CLOSURE106_SHA,'前後不変':True,
          '未実行':['code-only ZIP生成は次の固定計画で別実行','金融結果保存','全70経済結果の読取','正式再現.md','試行閉鎖'],
          '新候補別xlsx':'停止未受領。旧single107builderは未使用として実使用集合へ加えない'}
    write_new(stop_path,stop)
    condition=M.ROOT/'study/00107_見送り明けの初回取得と利益保護/金融条件_埋込対応.json'
    assert M.sha(condition)==M.CONDITION_SHA
    c=M.read(condition)
    stops=[]
    for ref in c['stops']:
        p=M.OLD.resolve(ref,condition.parent)
        stops.append(file_ref(p))
    stops.append(file_ref(M.ROOT/'work/107報告の準備/停止.json'))
    assert stops[-1]['sha256']=='2eb22dfc6c1986eae3a0c5d72f08f94d8cfa6ea8c9475088406dc6c36a1f77ee'
    old_plan=M.read(WORK/'保存計画_未固定.json')
    extras=[file_ref(WORK/name) for name in sources]+[file_ref(proof_path),file_ref(stop_path)]
    extras.extend(file_ref(M.ROOT/name) for name in ['work/107市場外周のpeer確認/修正後確認.json','work/107市場外周のpeer確認/埋込対応確認.json'])
    plan={'version':1,'trial':107,'fixed':True,'phase':'fixed_code_only','code_archive_authorized':True,
          'authorization':'Rootが全70進行中に固定済みcode保存部分だけの実行を明示許可。正式結果保存/試行閉鎖は未許可',
          'condition':file_ref(condition),'prior_index':file_ref(M.ROOT/'study/00106_収束失速で保護の起動と幅を切り替える/再現コードの所在.json'),
          'prior_closure':file_ref(M.ROOT/'study/00106_収束失速で保護の起動と幅を切り替える/完了記録.json'),
          'postprocess_stops':stops,'extra_files':extras,'failed_attempts':old_plan['failed_attempts'],'launch_errors':old_plan['launch_errors'],
          'pending_postprocess':['新107候補別xlsxの停止コードと実行固定','Viewer最終確認のコードと実行固定','報告実行固定/生成/確認の小metadata','全70金融/保存成功後の正式再現.mdと別不足ZIP'],
          '未使用':['旧single107xlsx builder。型人工の由来と実編集の使用は区別'],
          '時計':'30分静観の固定107を保存。20分は今後の別条件'}
    write_new(plan_path,plan)
    print(json.dumps({'成功':True,'準備停止SHA256':M.sha(stop_path),'計画SHA256':M.sha(plan_path),'code_only実行':False},ensure_ascii=False))


if __name__=='__main__':
    main()
