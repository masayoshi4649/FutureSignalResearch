"""107の再現metadata準備とRoot許可済み固定コードだけの先行保存を行う。"""
from __future__ import annotations

import argparse
from collections import Counter
from copy import deepcopy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import zipfile

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
TRIAL = ROOT/'study/00107_見送り明けの初回取得と利益保護'
OLD_PATH = ROOT/'work/106正式保存の準備/保存する.py'
OLD_SHA = '385ec1821b0b1b765da6b73bfa2cd18fa0da4009cbfb4ab1deb6c88eb2218ce1'
CONDITION_SHA = '4ab51b9fadc6745ac25597b09365062b629ce329e88507f261fbc0f0760cab97'
INDEX106_SHA = 'e23132978fb94e33713f3485855cc10dd6cbab64f81acb4f1d083cba4ca9d71a'
CLOSURE106_SHA = 'a25d267333c578937e9591358040a077fec4cf3b4a79142d7265fb37e8e81770'
FAILED_CONDITION_SHA = '4ae0da3fe69e5a0632aff13b4dd3d1848df65aaac334750f8aecbb902f0dc07d'
FAILED_COMPLETION_SHA = '5da988ec046b43f81dd17f10380b7a27f9b293f47e2bc4e054f5cd86435e5244'


def sha(path: Path) -> str:
    """
    機能: 許可されたコード又は小metadataの内容指紋を得る。
    引数: path (Path) は対象。
    返り値: str はSHA256。GoRootも指紋だけを確認し、本文を格納しない。Raw/金融Nativeには呼ばない。
    """
    with path.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()


assert sha(OLD_PATH)==OLD_SHA
spec = importlib.util.spec_from_file_location('107が再用する106保存純口',OLD_PATH)
OLD = importlib.util.module_from_spec(spec)
spec.loader.exec_module(OLD)


def read(path: Path) -> dict:
    """
    機能: 条件/完了/確認/所在索引の小metadataだけを読む。
    引数: path (Path) は対象。
    返り値: dict は内容。金融集計本文の解析には使わない。
    """
    return json.loads(path.read_text(encoding='utf-8-sig'))


def bind(ref: dict, base: Path, inputs: dict) -> Path:
    """
    機能: 明示FileRefをparent基準で解決しSHAを検査する。
    引数: ref (dict)、base (Path)、inputs (dict) は参照・基準・前指紋。
    返り値: Path は認証済み絶対path。
    """
    p = OLD.resolve(ref,base)
    inputs[str(p)] = ref['sha256']
    return p


def verify_success(condition: dict, complete: dict, check: dict, ids: list[str], condition_sha: str, complete_sha: str, summary_sha: str) -> None:
    """
    機能: 新条件と全70金融/保存の成功metadataを結ぶ。
    引数: condition/complete/check (dict)、ids (list[str])、各sha (str) は宣言値。
    返り値: None。先頭2/失敗/別条件を全70成功にしない。
    """
    assert condition_sha==CONDITION_SHA and condition['version']==1 and condition['trial']==107 and condition['fixed'] is True and len(condition['configs'])==24
    assert complete['version']==1 and complete['trial']==107 and complete['stage']=='full70' and complete['success'] is True and not complete.get('error')
    assert complete['condition_sha256']==condition_sha and (complete['sessions'],complete['books_per_scene'],complete['books'])==(70,24,1680)
    assert complete['unchanged'] is True and complete['before'] and complete['before']==complete['after']
    assert complete['input_mode']=='recorded_public_106' and complete['source_reexecuted'] is False and complete['features_recomputed'] is False and complete['charts_recomputed'] is False and complete['cmp_recomputed'] is True and complete['financial_executed'] is True
    assert len(ids)==len(set(ids))==70 and [x['session'] for x in complete['results']]==ids
    assert all(x['books']==24 and x['base_control_books']==12 and not x.get('error') for x in complete['results'])
    assert check['成功'] is True and (check['会計'],check['資源'],check['不一致数'])==(1680,1680,0)
    assert check['completionSHA256']==complete_sha and check['conditionSHA256']==condition_sha and check['出力SHA256']['結果.json']==summary_sha
    assert check['前後不変'] is True and check['入力codeSHA256前']==check['入力codeSHA256後']


def inherited_location(item: dict, index: dict, index_path: Path) -> dict:
    """
    機能: 旧106所在を107から参照できる位置へ直す。
    引数: item/index (dict)、index_path (Path) は旧entryと旧索引。
    返り値: dict はarchive参照又は外部Go環境。旧ZIPを開かない。
    """
    location = deepcopy(item['location'])
    if location['kind'] in ('外部Go環境','外部実行物'):
        return location
    ref = index['新ZIP'] if location['kind']=='新archive' else location['archive']
    p = (index_path.parent/ref['path']).resolve()
    assert OLD.safe(location['entry'])
    return {'kind':'既存archive','archive':{'path':os.path.relpath(p,TRIAL).replace('\\','/'),'sha256':ref['sha256']},'entry':location['entry']}


def choose_location(item: dict, by_sha: dict) -> dict:
    """
    機能: 同SHA共用・Go外部環境・新規不足候補をmetadataだけで分ける。
    引数: item/by_sha (dict) は新entryと旧所在のSHA索引。
    返り値: dict は保存予定の所在。この関数では実ZIPを作らない。
    """
    r = item['restore']
    assert OLD.safe(r['relative'])
    if r['root']=='goRoot':
        return {'kind':'外部Go環境','version':'go1.24.2','root':'goRoot','relative':r['relative'],'本文保存':False}
    if Path(item['original_path']).suffix.lower()=='.exe':
        return {'kind':'外部実行物','root':r['root'],'relative':r['relative'],'本文保存':False,'由来':'固定条件のcode/binary参照。再build同SHAは保証しない'}
    if item['SHA256'] in by_sha:
        return deepcopy(by_sha[item['SHA256']])
    name = r['root']+'/'+r['relative']
    assert OLD.safe(name)
    return {'kind':'新archive候補','entry':name}


def collect(plan: dict, condition: dict, plan_path: Path, index: dict, index_path: Path, inputs: dict) -> list[dict]:
    """
    機能: 旧106閉包へ107の不足コードと許可small metadataを追加する。
    引数: plan/condition/index (dict)、各path (Path)、inputs (dict) は固定と前指紋。
    返り値: list[dict] は元path/復元先/予定所在。本文の複製は行わない。
    """
    items,by_sha = {},{}
    for row in index['entries']:
        item = deepcopy(row)
        item['location'] = inherited_location(row,index,index_path)
        item['roles'] = list(item.get('roles',[]))+['106閉鎖所在を継承']
        items[str(Path(item['original_path']).resolve())] = item
        if item['location']['kind']=='既存archive':
            by_sha.setdefault(item['SHA256'],item['location'])

    def add(path: Path, expected: str, role: str) -> None:
        """
        機能: 明示したコード/小metadata一件の予定所在を追加する。
        引数: path (Path)、expected/role (str) は元位置・指紋・由来区分。
        返り値: None。Raw/Native/巨大人工・旧同path別SHAを拒否する。
        """
        path = path.resolve()
        assert OLD.valid_sha(expected) and not path.is_relative_to(ROOT.parent/'JP_OSE_Data')
        r = OLD.restore(path)
        key = str(path)
        if r['root']!='goRoot':
            assert path.suffix in (OLD.CODE_SUFFIX|{'.ps1','.exe'}) and not path.name.endswith(('.Native.json','.result.json','.resources.json'))
            assert not (path.suffix=='.json' and any(x in ('人工','人工_停止版','人工入力','成果物','成果物_金融','成果物_Source') for x in path.parts))
            assert path.suffix=='.exe' or path.stat().st_size<5_000_000
        assert sha(path)==expected
        inputs[key]=expected
        if key in items:
            assert items[key]['SHA256']==expected,'旧106の同pathコード変更:'+key
            if role not in items[key]['roles']:
                items[key]['roles'].append(role)
            return
        item={'original_path':path.as_posix(),'SHA256':expected,'bytes':path.stat().st_size,'restore':r,'roles':[role]}
        item['location']=choose_location(item,by_sha)
        if r['root']=='goRoot':
            item['指紋確認範囲']='Root金融条件の宣言SHAへ現物照合。stdlib/tool本文は保存しない'
        items[key]=item

    condition_path=(plan_path.parent/plan['condition']['path']).resolve()
    for name,h in condition['code_sha256'].items():
        add(condition_path.parent/name,h,'107金融前固定code')
    binary=bind(condition['binary'],condition_path.parent,inputs)
    add(binary,condition['binary']['sha256'],'107固定金融実行物・本文は外部参照')
    for ref in plan['postprocess_stops']:
        p=bind(ref,plan_path.parent,inputs)
        stop=read(p)
        assert stop['成功'] is True
        add(p,ref['sha256'],'107事後停止metadata')
        for field in ('所有コードSHA256','所有SHA256'):
            for name,h in stop.get(field,{}).items():
                add(ROOT/name,h,'107事後停止所有')
    for ref in plan['extra_files']:
        p=bind(ref,plan_path.parent,inputs)
        add(p,ref['sha256'],'Root指定small再現metadata')
    for attempt in plan['failed_attempts']:
        for field in ('condition','completion'):
            p=bind(attempt[field],plan_path.parent,inputs)
            add(p,attempt[field]['sha256'],'失敗由来・成功会計外')
    add(plan_path,sha(plan_path),'107保存metadataのRoot計画')
    return list(items.values())


def prepare(plan_path: Path, expected: str, output: Path) -> dict:
    """
    機能: Root全成功後だけコード所在metadataと再現草案を新work先へ出す。
    引数: plan_path/output (Path)、expected (str) は封印計画と新規先。
    返り値: dict は候補件数。ZIP/正式配置/金融を行わない。
    """
    assert not output.exists() and sha(plan_path)==expected
    p=read(plan_path)
    assert p['version']==1 and p['trial']==107 and p['fixed'] is True and p['result_ready'] is True and p['pending']==[] and p['postprocess_final'] is True
    inputs={str(plan_path):expected,str(OLD_PATH):OLD_SHA}
    paths={k:bind(p[k],plan_path.parent,inputs) for k in ('condition','financial_completion','saved_check','summary','prior_index','prior_closure')}
    assert p['prior_index']['sha256']==INDEX106_SHA and p['prior_closure']['sha256']==CLOSURE106_SHA
    condition,done,check,index,closed=[read(paths[k]) for k in ('condition','financial_completion','saved_check','prior_index','prior_closure')]
    assert closed['試行']==106 and closed['試行完了'] is True and index['成功'] is True and index['試行']==106
    manifest=read(bind(condition['input_manifest'],paths['condition'].parent,inputs))
    verify_success(condition,done,check,[x['id'] for x in manifest['sessions']],p['condition']['sha256'],p['financial_completion']['sha256'],p['summary']['sha256'])
    first=read(bind(done['first2'],paths['financial_completion'].parent,inputs))
    assert first['trial']==107 and first['stage']=='first2' and first['success'] is True and first['condition_sha256']==CONDITION_SHA
    assert first['sessions']==2 and first['books']==48 and first['unchanged'] is True and first['before']==first['after'] and len(first['results'])==2
    for a,b in zip(first['results'],done['results'][:2]):
        assert a['session']==b['session'] and not a.get('error') and a['books']==24 and a['base_control_books']==12
        assert all(a[k]['sha256']==b[k]['sha256'] for k in ('native','sidecar_header','sidecar_records'))
    failures=[]
    for a in p['failed_attempts']:
        cp=bind(a['condition'],plan_path.parent,inputs);dp=bind(a['completion'],plan_path.parent,inputs)
        c,d=read(cp),read(dp)
        assert c['trial']==107 and d['trial']==107 and d['success'] is False and d['condition_sha256']==a['condition']['sha256']
        failures.append({'condition':a['condition'],'completion':a['completion'],'stage':d['stage'],'success':False,'sessions':d['sessions'],'books':d['books']})
    assert any(a['condition']['sha256']==FAILED_CONDITION_SHA and a['completion']['sha256']==FAILED_COMPLETION_SHA and a['sessions']==a['books']==0 for a in failures)
    items=collect(p,condition,plan_path,index,paths['prior_index'],inputs)
    assert all(sha(Path(name))==h for name,h in inputs.items())
    counts=Counter(x['location']['kind'] for x in items)
    value={'成功':True,'scope':'コード所在metadata候補だけ。実ZIP/正式保存成功ではない','試行':107,'計画SHA256':expected,'conditionSHA256':p['condition']['sha256'],'旧106所在SHA256':INDEX106_SHA,
           '全所在数':len(items),'所在区分':dict(counts),'entries':items,'失敗由来':failures,'起動失敗由来':p.get('launch_errors',[]),'入力SHA256前':inputs,'入力SHA256後':inputs,'前後不変':True,'ZIP生成':0,'正式コピー':0}
    output.mkdir(parents=True)
    (output/'再現コード所在_候補.json').write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (output/'再現_草案.md').write_bytes((WORK/'再現手順_未検証草案.md').read_bytes())
    return {'成功':True,'全所在数':len(items),'所在区分':dict(counts),'ZIP生成':0,'正式コピー':0}


def publish_fixed_code(plan_path: Path, expected: str, output: Path) -> dict:
    """
    機能: Rootが先行保存を許可した固定コードだけを不足ZIP/所在へ保存する。
    引数: plan_path/output (Path)、expected (str) はcode-only封印計画と新規work先。
    返り値: dict はコード保存の件数。全70金融・保存結果・試行閉鎖を開封しない。
    """
    assert not output.exists() and sha(plan_path)==expected
    p=read(plan_path)
    assert p['version']==1 and p['trial']==107 and p['fixed'] is True and p['phase']=='fixed_code_only' and p['code_archive_authorized'] is True
    inputs={str(plan_path):expected,str(OLD_PATH):OLD_SHA}
    paths={k:bind(p[k],plan_path.parent,inputs) for k in ('condition','prior_index','prior_closure')}
    assert p['condition']['sha256']==CONDITION_SHA and p['prior_index']['sha256']==INDEX106_SHA and p['prior_closure']['sha256']==CLOSURE106_SHA
    c,index,closed=[read(paths[k]) for k in ('condition','prior_index','prior_closure')]
    assert c['trial']==107 and c['fixed'] is True and len(c['code_sha256'])==1032
    assert closed['試行']==106 and closed['試行完了'] is True and index['成功'] is True and index['試行']==106
    failures=[]
    for attempt in p['failed_attempts']:
        a=bind(attempt['condition'],plan_path.parent,inputs);b=bind(attempt['completion'],plan_path.parent,inputs)
        d=read(b)
        assert d['trial']==107 and d['success'] is False and d['condition_sha256']==attempt['condition']['sha256']
        failures.append({'condition':{'path':os.path.relpath(a,TRIAL).replace('\\','/'),'sha256':attempt['condition']['sha256']},'completion':{'path':os.path.relpath(b,TRIAL).replace('\\','/'),'sha256':attempt['completion']['sha256']},'sessions':d['sessions'],'books':d['books'],'success':False})
    assert any(x['condition']['sha256']==FAILED_CONDITION_SHA and x['completion']['sha256']==FAILED_COMPLETION_SHA and x['sessions']==x['books']==0 for x in failures)
    items=collect(p,c,plan_path,index,paths['prior_index'],inputs)
    fixed={str((paths['condition'].parent/name).resolve()):h for name,h in c['code_sha256'].items()}
    located={str(Path(x['original_path']).resolve()):x['SHA256'] for x in items}
    assert len(fixed)==1032 and all(located.get(name)==h for name,h in fixed.items())
    # ----------------------------------------
    # 旧ZIPは変更せず、参照entryのSHA/CRCを検査する。標準/ToolはZIPへ渡さない。
    archives={}
    for item in items:
        loc=item['location']
        if loc['kind']=='既存archive':
            q=(TRIAL/loc['archive']['path']).resolve()
            want=loc['archive']['sha256']
            if q not in archives:
                assert sha(q)==want
                inputs[str(q)]=want
                with zipfile.ZipFile(q) as z:assert z.testzip() is None
                archives[q]=want
    for q in archives:
        with zipfile.ZipFile(q) as z:
            cache={}
            for item in items:
                loc=item['location']
                if loc['kind']=='既存archive' and (TRIAL/loc['archive']['path']).resolve()==q:
                    name=loc['entry']
                    assert OLD.safe(name)
                    if name not in cache:cache[name]=hashlib.sha256(z.read(name)).hexdigest()
                    assert cache[name]==item['SHA256']
    output.mkdir(parents=True)
    zip_path=output/'再現コード_固定分.zip'
    missing,by_sha={},{}
    for item in items:
        loc=item['location']
        if loc['kind']=='新archive候補':
            name=by_sha.setdefault(item['SHA256'],loc['entry'])
            item['location']={'kind':'新archive','entry':name}
            missing.setdefault(name,item)
    with zipfile.ZipFile(zip_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,item in sorted(missing.items()):
            assert OLD.safe(name) and item['restore']['root']!='goRoot' and Path(item['original_path']).suffix.lower()!='.exe'
            assert sha(Path(item['original_path']))==item['SHA256']
            z.write(item['original_path'],name)
    with zipfile.ZipFile(zip_path) as z:
        assert z.testzip() is None and set(z.namelist())==set(missing)
        assert all(hashlib.sha256(z.read(name)).hexdigest()==item['SHA256'] for name,item in missing.items())
    after={name:sha(Path(name)) for name in inputs}
    assert after==inputs
    zip_ref={'path':zip_path.name,'sha256':sha(zip_path),'bytes':zip_path.stat().st_size}
    result={'成功':True,'試行':107,'phase':'fixed_code_only','scope':'固定code1032と確定済み事後codeの先行保存。金融結果/全試行完了ではない',
            '金融条件':p['condition'],'金融条件SHA256':CONDITION_SHA,'実行物':c['binary'],'固定code数':1032,'固定code所在欠落':0,'全所在数':len(items),'新ZIP':zip_ref,'新entry数':len(missing),
            '旧106所在SHA256':INDEX106_SHA,'旧106閉鎖SHA256':CLOSURE106_SHA,'entries':items,'roots':index['roots'],'Go環境':index['Go環境'],
            '失敗由来':failures,'起動失敗由来':p.get('launch_errors',[]),'未追加の事後工程':p.get('pending_postprocess',[]),'入力SHA256前':inputs,'入力SHA256後':after,'前後不変':True,
            '除外':index['除外']+['固定金融exe/Go Tool本文','未使用の旧single107 xlsxを実使用codeにしない'],
            '金融Native/経済結果保存':False,'試行閉鎖':False}
    idx=output/'再現コードの所在_固定分.json'
    idx.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    receipt={'成功':True,'試行':107,'phase':'fixed_code_only','計画SHA256':expected,'固定code1032所在欠落':0,'全所在数':len(items),'新entry読戻しSHA一致':len(missing),'CRC差':0,'危険path':0,'旧archive不変':True,'codeZIP':zip_ref,'索引SHA256':sha(idx),'入力前後不変':True,'Raw/Source/Bank/金融/Viewer/xlsx実行':0,'金融結果保存':False,'正式配置':False}
    (output/'再現コード保存の確認_固定分.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return {'成功':True,'固定code数':1032,'全所在数':len(items),'ZIP新entry':len(missing),'ZIP_SHA256':zip_ref['sha256'],'金融結果保存':False,'正式配置':False}


def main() -> None:
    """
    機能: 全成功後metadata又はRoot許可済み固定codeだけの先行保存を行う。
    引数: CLI plan/out (Path)、plan-sha (str)、code-only (bool) はRootの実行前固定と口の区別。
    返り値: None。code-onlyは金融/保存結果を読まず、金融Native等を保存しない。
    """
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan',type=Path,required=True);parser.add_argument('--plan-sha',required=True);parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--code-only',action='store_true')
    a=parser.parse_args()
    action=publish_fixed_code if a.code_only else prepare
    print(json.dumps(action(a.plan.resolve(),a.plan_sha,a.out.resolve()),ensure_ascii=False))


if __name__=='__main__':
    main()
