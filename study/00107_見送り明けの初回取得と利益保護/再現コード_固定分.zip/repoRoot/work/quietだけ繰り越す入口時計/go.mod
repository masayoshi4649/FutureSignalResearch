module github.com/masayoshi4649/SessionTradeExecuter/quietassignment

go 1.23.0
