"""手製時計だけを確認し、所有コードと静的参照の停止指紋を保存する。"""

from pathlib import Path
import hashlib
import json
import subprocess
import sys


def sha(path):
    """
    機能: 小型コードファイルのSHA256を取得する。
    引数: path(Path)はコード又は停止metadataの位置。
    返り値: strはSHA256の16進表記。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    """
    機能: 既存先を拒否し、日本語JSONを新規保存する。
    引数: path(Path)は保存先、value(dict)は小型の確認値。
    返り値: なし。
    """
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def main():
    """
    機能: 旧金融を実行せず、純時計の手製試験と前後不変を保存する。
    引数: なし。所有dirとrepo位置はこのファイルから求める。
    返り値: なし。試験失敗又は既存確認先があれば例外で停止する。
    """
    owned = Path(__file__).resolve().parent
    repo = owned.parents[1]
    for name in ("由来.json", "確認.json", "停止.json"):
        if (owned / name).exists():
            raise RuntimeError(f"確認先が既に存在します: {name}")
    refs = {
        "work/103多玉の保護会計/entry_grid.go": "strict次枠・quiet・P締切・一回採否・EOF",
        "work/103多玉の保護会計/actual.go": "constructor時計・cancelEntry永久lock・Source優先",
        "work/103多玉の保護会計/actual_types.go": "既存Config/Source/機会型",
        "work/103多玉の保護会計/停止.json": "旧金融停止の指紋参照だけ",
        "work/103多玉の一定利益保護/replay.go": "既存Tape順のActor配送",
        "work/104Source再生の接続準備/input.go": "場時計とNY09:30のDST変換",
        "work/104Source再生の接続準備/replay.go": "P締切・U開始・全board時計・EOFForce",
        "scripts/固定通知と価格行の再生/先頭2場の入力を作る.py": "同時計Force→grid→rawの固定構築式",
        "work/106可変保護の市場接続準備/停止.json": "106旧停止の指紋参照だけ",
    }
    before = {name: sha(repo / name) for name in refs}
    write(owned / "由来.json", {
        "確認日": "2026-11-09",
        "方式": "旧コードの静的時計式を参照し、標準ライブラリのみの独立純関数を新規実装",
        "旧コード本文の複写": False,
        "静的参照": {name: {"SHA256": before[name], "用途": purpose} for name, purpose in refs.items()},
        "旧コード変更": 0,
        "市場入力": 0,
        "金融実行": 0,
    })
    names = ["assignment.go", "assignment_test.go", "go.mod", "README.md", "確認して停止する.py", "由来.json"]
    own_before = {str((owned / name).relative_to(repo)).replace("\\", "/"): sha(owned / name) for name in names}
    # ----------------------------------------
    # 実入力loaderや旧金融を呼ばず、新しい純時計moduleだけを実行する。
    commands = [["go", "test", "-v", "./..."], ["go", "vet", "./..."], ["go", "build", "./..."]]
    checks = []
    for args in commands:
        result = subprocess.run(args, cwd=owned, text=True, encoding="utf-8", capture_output=True, check=False)
        checks.append({"argv": args, "exit_code": result.returncode, "stdout": result.stdout, "stderr": result.stderr})
        if result.returncode:
            raise RuntimeError(f"純時計の確認失敗: {args}: {result.stdout} {result.stderr}")
    after = {name: sha(repo / name) for name in refs}
    own_after = {name: sha(repo / name) for name in own_before}
    if before != after or own_before != own_after:
        raise RuntimeError("確認中に参照又は所有コードが変化しました")
    write(owned / "確認.json", {
        "成功": True,
        "scope": "手製時刻だけのquiet一回割当・静的接続境界。金融/市場/参加率の証明なし",
        "確認": checks,
        "静的参照SHA256前": before,
        "静的参照SHA256後": after,
        "所有コードSHA256前": own_before,
        "所有コードSHA256後": own_after,
        "前後不変": True,
        "市場本文読取": 0,
        "Source実行": 0,
        "金融実行": 0,
        "機会損失算出": False,
    })
    write(owned / "停止.json", {
        "成功": True,
        "scope": "quietだけを繰り越す独立純割当関数・非市場停止",
        "module": "github.com/masayoshi4649/SessionTradeExecuter/quietassignment",
        "公開API": "AssignQuietOnce(SessionClock, float64) (Assignment, error)",
        "所有コードSHA256": own_after,
        "確認SHA256": sha(owned / "確認.json"),
        "旧参照前後不変": True,
        "Source又は金融への接続": False,
        "市場読取実行": 0,
        "採用又は新試行固定": False,
        "留保": ["一回適用と永久lockは登録側の責務", "Force/P締切/EOFは旧Actorが優先", "非整列の別quietへの二回繰越なし・実使用可否は未決定", "参加率・損益未検証"],
    })
    print(json.dumps({"成功": True, "停止": str(owned / "停止.json"), "停止SHA256": sha(owned / "停止.json"), "関数SHA256": sha(owned / "assignment.go")}, ensure_ascii=False))


if __name__ == "__main__":
    sys.exit(main())
