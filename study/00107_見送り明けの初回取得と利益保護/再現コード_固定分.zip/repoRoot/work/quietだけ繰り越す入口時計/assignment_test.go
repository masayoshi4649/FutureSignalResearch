package quietassignment

import (
	"math"
	"testing"
	"time"
)

// clockAt は手製のJST時分をUnix秒にします。
//
// 引数: hour/minute(int)は同一手製日の時分です。
// 返り値: float64は2026年11月6日の当該時刻です。
func clockAt(hour, minute int) float64 {
	return float64(time.Date(2026, 11, 6, hour, minute, 0, 0, time.FixedZone("JST", 9*3600)).Unix())
}

// TestHandClockBoundaries は元出生と半開静観の境界だけを人工確認します。
//
// 引数: t(*testing.T)はGoの試験器です。
// 返り値: なし。金融や実データの読取は行いません。
func TestHandClockBoundaries(t *testing.T) {
	day := SessionClock{Kind: "Day", Start: clockAt(8, 45)}
	night := SessionClock{Kind: "Night", Start: clockAt(17, 0), USOpen: clockAt(23, 30)}
	summer := night
	summer.USOpen = clockAt(22, 30)
	cases := []struct {
		name     string
		clock    SessionClock
		birth    float64
		strict   float64
		assigned float64
		deferred bool
	}{
		{"開始同秒はstrict次枠から繰越", day, clockAt(8, 45), clockAt(8, 50), clockAt(9, 15), true},
		{"静観最終内枠", day, clockAt(9, 5), clockAt(9, 10), clockAt(9, 15), true},
		{"出生が静観内でも割当が終端なら変更なし", day, clockAt(9, 10), clockAt(9, 15), clockAt(9, 15), false},
		{"終端直前の小数秒", day, clockAt(9, 15) - .25, clockAt(9, 15), clockAt(9, 15), false},
		{"静観終端の出生は次枠", day, clockAt(9, 15), clockAt(9, 20), clockAt(9, 20), false},
		{"通常同秒はstrict次枠", day, clockAt(10, 0), clockAt(10, 5), clockAt(10, 5), false},
		{"通常直前は目前枠", day, clockAt(10, 0) - .25, clockAt(10, 0), clockAt(10, 0), false},
		{"Night開始", night, clockAt(17, 0), clockAt(17, 5), clockAt(17, 30), true},
		{"冬US開始枠が静観", night, clockAt(23, 25), clockAt(23, 30), clockAt(24, 0), true},
		{"冬US同秒出生", night, clockAt(23, 30), clockAt(23, 35), clockAt(24, 0), true},
		{"U開始同秒出生も静観", night, clockAt(23, 45), clockAt(23, 50), clockAt(24, 0), true},
		{"冬US終了枠は静観外", night, clockAt(23, 55), clockAt(24, 0), clockAt(24, 0), false},
		{"冬US終了同秒出生", night, clockAt(24, 0), clockAt(24, 5), clockAt(24, 5), false},
		{"夏US開始", summer, clockAt(22, 25), clockAt(22, 30), clockAt(23, 0), true},
		{"P締切は繰越前でも救済しない", night, clockAt(23, 10), clockAt(23, 15), clockAt(23, 15), false},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			got, err := AssignQuietOnce(c.clock, c.birth)
			if err != nil || got.StrictAt != c.strict || got.AssignedAt != c.assigned || got.Deferred != c.deferred {
				t.Fatalf("割当=%+v, error=%v", got, err)
			}
			if c.deferred && (got.QuietEnd > got.AssignedAt || got.QuietStart > got.StrictAt || got.StrictAt >= got.QuietEnd) {
				t.Fatalf("静観根拠が不整合です: %+v", got)
			}
		})
	}
}

// TestAssignmentScope は終端・売買側・消費状態を持たない純時計の範囲を確認します。
//
// 引数: t(*testing.T)はGoの試験器です。
// 返り値: なし。終端後の受付成功やSource状態の証明には使いません。
func TestAssignmentScope(t *testing.T) {
	clock := SessionClock{Kind: "Night", Start: 3000, USOpen: 4200}
	got, err := AssignQuietOnce(clock, 3000)
	if err != nil || got.AssignedAt != 6000 || got.QuietEnd != 6000 {
		t.Fatalf("重複静観の連続区間: %+v, %v", got, err)
	}
	clock.USOpen = 4800
	got, err = AssignQuietOnce(clock, 3000)
	if err != nil || got.AssignedAt != 6600 {
		t.Fatalf("接する静観の連続区間: %+v, %v", got, err)
	}
	// ----------------------------------------
	// Force/Endを持たないため、仮の終端4800と等しい割当も時計として返します。
	clock.Kind, clock.USOpen = "Day", 0
	a, err := AssignQuietOnce(clock, 3000)
	b, err2 := AssignQuietOnce(clock, 3000)
	if err != nil || err2 != nil || a != b || a.AssignedAt != 4800 {
		t.Fatalf("同一入力の純時計: %+v/%+v, %v/%v", a, b, err, err2)
	}
	// DayのUS時計は静観区間を作りません。
	clock.USOpen = 9000
	got, err = AssignQuietOnce(clock, 9000)
	if err != nil || got.Deferred || got.AssignedAt != 9300 {
		t.Fatalf("Dayで米国静観を追加しました: %+v, %v", got, err)
	}
	// 非整列時計も一回のみ。繰越先が別の静観に入っても二回目を行いません。
	clock = SessionClock{Kind: "Night", Start: 3100, USOpen: 5000}
	got, err = AssignQuietOnce(clock, 3200)
	if err != nil || got.AssignedAt != 5100 || got.QuietEnd != 4900 {
		t.Fatalf("二回繰越が混入しました: %+v, %v", got, err)
	}
}

// TestInvalidClocks は未知時計や表現不能値を支持として使わないことを確認します。
//
// 引数: t(*testing.T)はGoの試験器です。
// 返り値: なし。いずれも出生の再試行を生成しません。
func TestInvalidClocks(t *testing.T) {
	cases := []struct {
		clock SessionClock
		birth float64
	}{
		{SessionClock{Kind: "Day", Start: 3000}, math.NaN()},
		{SessionClock{Kind: "Day", Start: 3000}, math.Inf(1)},
		{SessionClock{Kind: "Day", Start: 3000}, 0},
		{SessionClock{Kind: "Day", Start: math.NaN()}, 3100},
		{SessionClock{Kind: "Day", Start: -1}, 3100},
		{SessionClock{Kind: "不明", Start: 3000}, 3100},
		{SessionClock{Kind: "Night", Start: 3000}, 3100},
		{SessionClock{Kind: "Night", Start: 3000, USOpen: 3000}, 3100},
		{SessionClock{Kind: "Night", Start: 3000, USOpen: math.Inf(1)}, 3100},
		{SessionClock{Kind: "Day", Start: 3000, USOpen: -1}, 3100},
		{SessionClock{Kind: "Day", Start: 3000}, math.MaxFloat64},
	}
	for i, c := range cases {
		if _, err := AssignQuietOnce(c.clock, c.birth); err == nil {
			t.Fatalf("不正時計%dを受理しました", i)
		}
	}
}
