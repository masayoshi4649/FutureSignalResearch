"""停止68011のGoを別moduleへ派生し、変更前後の由来を記録する。"""

from pathlib import Path
import hashlib
import json


def sha(path):
    """
    機能: 小型コード又は停止metadataのSHA256を求める。
    引数: path(Path)は対象ファイル。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    """
    機能: 旧金融を実行せず、停止済Go/mod/sumを独立namespaceへ写す。
    引数: なし。位置はこのファイルから解決する。
    返り値: なし。停止SHA不一致又は既存先は例外にする。
    """
    target = Path(__file__).resolve().parent
    repo = target.parents[1]
    source = target.parent / "収束失速で保護を早める会計案"
    stop = source / "停止.json"
    if sha(stop) != "68011a9c44cbf88f765216493d331849cb80efd95cfdf63d750bbfafe53e02c5":
        raise RuntimeError("旧停止SHA不一致")
    fixed = json.loads(stop.read_text(encoding="utf-8"))["所有コードSHA256"]
    for name, expected in fixed.items():
        if sha(repo / name) != expected:
            raise RuntimeError(f"旧所有コードSHA不一致: {name}")
    mapping = []
    for src in sorted(source.glob("*.go")) + [source / "go.mod", source / "go.sum"]:
        dst = target / src.name
        if dst.exists():
            raise RuntimeError(f"既存先: {dst}")
        text = src.read_text(encoding="utf-8")
        if src.suffix == ".go":
            text = text.replace("package miniearlyguard", "package miniquietguard", 1)
        elif src.name == "go.mod":
            text = text.replace("module github.com/masayoshi4649/SessionTradeExecuter/miniearlyguard", "module github.com/masayoshi4649/SessionTradeExecuter/miniquietguard", 1)
            text += "\nrequire github.com/masayoshi4649/SessionTradeExecuter/miniearlyguard v0.0.0\nreplace github.com/masayoshi4649/SessionTradeExecuter/miniearlyguard => ../収束失速で保護を早める会計案\n"
            text += "require github.com/masayoshi4649/SessionTradeExecuter/quietassignment v0.0.0\nreplace github.com/masayoshi4649/SessionTradeExecuter/quietassignment => ../quietだけ繰り越す入口時計\n"
        dst.write_text(text, encoding="utf-8", newline="\n")
        mapping.append({"元": str(src.relative_to(repo)).replace("\\", "/"), "元SHA256": sha(src), "先": str(dst.relative_to(repo)).replace("\\", "/"), "namespace変更直後SHA256": sha(dst)})
    (target / "元の前指紋.json").write_text(json.dumps({"旧停止SHA256": sha(stop), "旧所有コードSHA256": fixed, "対応": mapping}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
