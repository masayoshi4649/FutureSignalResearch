"""旧停止を保ち、独立Actorの人工と許可した機能差分を保存する。"""

from pathlib import Path
import difflib
import hashlib
import json
import subprocess


def sha(path):
    """
    機能: 小型コード又は停止metadataのSHA256を求める。
    引数: path(Path)は対象位置。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    """
    機能: UTF-8の新規JSONを保存する。
    引数: path(Path)は保存先、value(dict)は小型の確認値。
    返り値: なし。既存先は拒否する。
    """
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def main():
    """
    機能: Goの非市場人工だけを確認し、元前後不変と最終指紋を保存する。
    引数: なし。位置はこのファイルから解決する。
    返り値: なし。失敗又は停止済み先へは例外で停止する。
    """
    root = Path(__file__).resolve().parent
    repo = root.parents[1]
    source = root.parent / "収束失速で保護を早める会計案"
    for name in ("由来と差分.json", "確認.json", "停止.json"):
        if (root / name).exists():
            raise RuntimeError(f"既存確認先: {name}")
    original = json.loads((root / "元の前指紋.json").read_text(encoding="utf-8"))
    old_files = original["旧所有コードSHA256"]
    fixed = {
        "work/収束失速で保護を早める会計案/停止.json": "68011a9c44cbf88f765216493d331849cb80efd95cfdf63d750bbfafe53e02c5",
        "work/quietだけ繰り越す入口時計/停止.json": "2f5c731d056662d3bd1233a55fab2e1766551f29d106bde03ff894770b9e8e75",
    }
    clock_stop = json.loads((repo / "work/quietだけ繰り越す入口時計/停止.json").read_text(encoding="utf-8"))
    before = {**old_files, **clock_stop["所有コードSHA256"], **fixed}
    for name, expected in before.items():
        if sha(repo / name) != expected:
            raise RuntimeError(f"元指紋差: {name}")
    differences = []
    maps = []
    for row in original["対応"]:
        src, dst = repo / row["元"], repo / row["先"]
        a = src.read_text(encoding="utf-8")
        b = dst.read_text(encoding="utf-8")
        normalized = b.replace("package miniquietguard", "package miniearlyguard", 1) if dst.suffix == ".go" else b
        same = a == normalized
        maps.append({"元": row["元"], "先": row["先"], "元SHA256": sha(src), "新SHA256": sha(dst), "packageと改行正規化後同体": same})
        if not same:
            differences.extend(difflib.unified_diff(a.splitlines(True), normalized.splitlines(True), fromfile=row["元"], tofile=row["先"]))
    patch = root / "時計だけの機能差分.patch"
    with patch.open("x", encoding="utf-8", newline="\n") as stream:
        stream.writelines(differences)
    write(root / "由来と差分.json", {
        "旧停止SHA256": fixed["work/収束失速で保護を早める会計案/停止.json"],
        "純時計停止SHA256": fixed["work/quietだけ繰り越す入口時計/停止.json"],
        "対応": maps,
        "追加Go": ["clock_assignment.go", "clock_test.go"],
        "機能変更Go": ["actual.go", "activation.go", "early.go", "width_book.go", "entry_grid.go"],
        "差分SHA256": sha(patch),
        "数値/Source/予約/費用/Fill/床の旧本文変更": 0,
        "市場本文読取": 0,
    })
    names = sorted([p for p in root.iterdir() if p.is_file() and p.name not in ("確認.json", "停止.json")])
    owned_before = {str(p.relative_to(repo)).replace("\\", "/"): sha(p) for p in names}
    target = root / "検査"
    target.mkdir(exist_ok=False)
    checks = {}
    commands = {"test": ["go", "test", "-json", "./..."], "vet": ["go", "vet", "./..."], "build": ["go", "build", "./..."]}
    for kind, args in commands.items():
        p = subprocess.run(args, cwd=root, text=True, encoding="utf-8", capture_output=True, check=False)
        log = target / f"{kind}.txt"
        log.write_text(p.stdout + p.stderr, encoding="utf-8", newline="\n")
        checks[kind] = {"argv": args, "exit_code": p.returncode, "log": str(log.relative_to(repo)).replace("\\", "/"), "SHA256": sha(log)}
        if p.returncode:
            raise RuntimeError(f"Go確認失敗: {kind}: {p.stdout} {p.stderr}")
    after = {name: sha(repo / name) for name in before}
    owned_after = {name: sha(repo / name) for name in owned_before}
    if before != after or owned_before != owned_after:
        raise RuntimeError("元又は所有コードが確認中に変化しました")
    write(root / "確認.json", {
        "成功": True,
        "scope": "手製Source/ATR/CMPの公開APIだけ。旧68011全時点対照とB5QDの狭い時計境界",
        "test/vet/build": checks,
        "B5Q旧68011": {"全時点": 1056, "最終": 48, "各比較": ["ActualResult", "WidthAudit", "EarlyAudit"], "除外": []},
        "B5QD開始静観非0完結": 24,
        "B5QD失効とlock鏡像": 16,
        "Night": "夏冬Uの静観繰越/Force同時計、P US-900締切",
        "元SHA256前": before,
        "元SHA256後": after,
        "所有SHA256前": owned_before,
        "所有SHA256後": owned_after,
        "前後不変": True,
        "市場/Raw/CSV/Native/Source結果本文読取": 0,
        "金融本番実行": 0,
    })
    write(root / "停止.json", {
        "成功": True,
        "scope": "107用B5QDの一回割当・非市場Actor。参加率と成績は未検証",
        "module": "github.com/masayoshi4649/SessionTradeExecuter/miniquietguard",
        "package": "miniquietguard",
        "所有コードSHA256": owned_after,
        "元停止": fixed,
        "確認SHA256": sha(root / "確認.json"),
        "新API": "ClockAudit() ClockBookAudit。旧Result/WidthAudit/EarlyAuditのJSON形は不変",
        "B5QD対象": ["W0", "W1", "E1"],
        "B5Q旧全JSON": "全時点1056/最終48でResult/Width/Early各全文、除外0",
        "前後不変": True,
        "市場本文読取/金融本番実行": 0,
        "未実施": ["24Coreの実場接続", "参加率/実績", "新時計の市場採用"],
    })
    print(json.dumps({"成功": True, "停止": str(root / "停止.json"), "SHA256": sha(root / "停止.json")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
