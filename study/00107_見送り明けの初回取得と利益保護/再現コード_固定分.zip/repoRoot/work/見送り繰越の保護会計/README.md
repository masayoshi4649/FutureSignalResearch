# 見送り中の割当だけを繰り越す保護会計

2026-11-09。107接続用の非市場Actor案。停止68011 `miniearlyguard` を別module `github.com/masayoshi4649/SessionTradeExecuter/miniquietguard` / package `miniquietguard` に最小派生した。既存106・Source・105・旧停止と純割当停止2f5は変更しない。新市場、原板、CSV、Native、Source結果の本文読取・市場実行は0。参加率や成績の改善は未検証。

## 新時計

旧B5Qを保ち、新時計名 `B5QD` を明示する。出生登録 `appendOpportunity` で停止純時計 `AssignQuietOnce` を一回呼び、EntryOpportunityのAssignedAtだけをその時計へ変更する。

- strict次枠は元Signal出生の `300*(floor(birth/300)+1)`。
- 元割当先が開始 `[Start,Start+1800)` 又はNightの米国 `[USOpen,USOpen+1800)` 内の場合だけ、静観終了の最初の5分格子へ繰り越す。
- Session.Start、正のSession.USOpenとcfg.USOpenは300秒整列が必須。NightはSessionとActualのUSOpenも一致必須。非整列・未知は失敗し、推定・場skip・分母除外しない。B5Qにはこの新制約を加えない。
- B5QDでも旧quietガードとGridTrace.QuietAppliedを保つ。重複・接続静観の和集合は停止純時計の規則のまま。
- 静観終了と同秒に生まれた出生は、その次のstrict枠となる。終了枠へ遡らない。

今回B5QDで比較する設定はGate/Harvest/Risk/Exit空のP0、W0/W1ではActivationPolicy=LD10、E1ではActivationPolicy=E1、各C0/C5・D0/D1。B5QDのW2/E2その他は許可しない。B5Q側の旧W2/E2や既存比較用APIは必要な互換として維持する。

## 旧Actorが引き続き決める境界

Force、P手法の `min(ForceClose,USOpen-900)` 締切、Source取消・完結・返済予約、当枠の未取得・未知・容量不足・技法判定は旧順序のまま。P締切やSource取消を繰越で救済しない。Force→grid→同秒rawの配送を変更せず、同時計Forceを先に反映する。

評価時に一度Consumed=trueとし、受理も失効もentryBySourceへ登録する旧本文を維持する。正数量受理後に実取得0で取り消されてもlockを消さない。quiet以外の理由で後枠を再試行しない。EOFまでに割当枠が実在しなければ旧Finishで失効する。未来grid・気配・実Fillは作らない。

Source予約を先に反映した未予約量、片側上限10、数量min、Source部分返済・費用・MTM・LD起動・C/M/P・幅選択・非緩和床・同原行約定禁止・D1は旧計算を再用する。変更は時計選択と別auditだけで、新しいgateやSource再形成を加えない。

## 公開APIとkey

既存の `NewActualBook`、`NewWidthBook`、`NewEarlyBook`、`OnNativeStep`、`OnNativeForce`、`OnEntryGrid`、`OnWidthObservation`、`ResetWidthObservation`、`Snapshot`、`Finish`、`WidthAudit`、`EarlyAudit`、`PublicReceiver` を同形で公開する。元ActorにないNewBook/Feed/Pulse/Resultという別名の金融APIは追加していない。Coreは既存と同じ呼出へ接続する。

| 外側保護名 | constructor | 内key例 |
|---|---|---|
| W0/W1 | NewWidthBook(session,cfg,policy,contract) | LD10_B5Q_P0_C0_D0 / LD10_B5QD_P0_C0_D0 |
| E1 | NewEarlyBook(session,cfg,contract) | E1_B5Q_P0_C0_D0 / E1_B5QD_P0_C0_D0 |

W0/W1は元と同じ内keyなので、比較を混ぜず外側namespaceを使う。B5Q既存Result・幅/Early auditのJSON形は変えない。

新しい `ClockAudit() ClockBookAudit` はActualResultの外にだけ保存する。

```text
ClockBookAudit{timing:string, opportunities:[]ClockOpportunityAudit}
ClockOpportunityAudit{
  ordinal:int, source:SourceIdentity全文,
  strict_at:float64, assigned_at:float64,
  quiet_start?:float64, quiet_end?:float64, reason?:string,
  deferred:bool
}
```

B5Qではopportunitiesは空配列。B5QDでは全出生に一件保存し、繰越しなかった出生もDeferred=falseで残す。Accessorは独立copy。元SourceIdentityを文字列分割せず、ordinalとSource全文でEntryOpportunityへ結び、そのEntryOrderIDから要求・実Fillへ追跡する。Deferredは割当時計の変更であり、受理・実取得の成功ではない。

## 人工確認と限界

新規の確認は停止68011を別namespaceへimportして行う。手製イベントは既存の公開API器具から独立生成し、旧市場結果や保存Bookを期待値として読まない。

- B5Q：買売×ATR既知未知×W0/W1/E1×4費用の48口座。全時点1056でResult/WidthAudit/EarlyAudit、最終48でも同3種の全JSONを除外0比較。全48は非0・残0完結。
- B5QD：買売×三政策×4費用の24口座が開始静観→終了枠受理→後原行取得→Source/Force返済で非0完結。grid時にはFillなし。同時刻の別後原行ではD0だけ取得し、D1は1秒後を待つ。
- 取消・完結・予約・気配未知・Source未取得・容量・Force締切・正数量受理後0取得取消の各8ケース×買売で一回失効/永久lock/次枠で復活しないことを確認。
- 夏冬US時計のU静観繰越、静観終了とForceの同時計優先、PのUS-900締切、EOFの未観測枠失効、整列拒否、auditの共有なしを狭く確認。
- 派生元の既存人工も同moduleで確認する。旧Source・指標・金融の市場再生や参加率の検証は含まない。

`go test -json ./...` / `go vet ./...` / `go build ./...` の証拠は検査dir、元停止との対応・package宣言を揃えた機能差分は由来JSONとpatch、最終指紋は停止.jsonに保存する。元のJSON・Key・停止は変更しない。
