package miniquietguard

import (
	"bytes"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"

	old "github.com/masayoshi4649/SessionTradeExecuter/minidelayed103"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
)

// widthObs はC/M/P形成を主張しない外部境界型の人工公表を作ります。
//
// 引数: side/ordinal(int)、end(float64)、p(WidthTruth)は方向・順序・公表終端・構造既知性です。
// 返り値: WidthObservationは手製の確定三値です。OHLCやEMAを作りません。
func widthObs(side, ordinal int, end float64, p WidthTruth) WidthObservation {
	return WidthObservation{Session: session().ID, Contract: "手製限月", Side: side, PublicationID: WidthPublicationID(session().ID, "手製限月", end), Ordinal: ordinal, End: end, AvailableAt: end, C: WidthTruth{true, widthPointer(true)}, M: WidthTruth{true, widthPointer(true)}, P: p, FrameSHA: strings.Repeat("a", 64), ResultSHA: strings.Repeat("b", 64)}
}

// widthWave は旧103の手製Source器具から金融と独立した同一イベント列を作ります。
//
// 引数: side(int)、unknown(bool)は鏡像とATR初回未知です。
// 返り値: fixture103は公開通知/原行/Forceだけです。Sourceエンジンは実行しません。
func widthWave(side int, unknown bool, sourcePriority ...bool) fixture103 {
	s := session()
	g := s.Start + 1800
	f := fixture103{Session: s, Scope: "旧103同体の手製Source通知・ATR公開型。C/M/Pは別の型人工で市場形成ではない"}
	src := newSource()
	idx := int64(0)
	feed := func(at, move, atr float64, bad bool, news ...native.Signal) {
		o := observation(at, move, side, idx, bad)
		o.ATR, o.E01.ATR = atr, atr
		if atr == 0 {
			o.E01.ATRAvailable, o.E01.ATRNominal = 0, 0
		}
		line := idx + 20
		b := src.step(stamp(o, line), news)
		f.Events = append(f.Events, event103{"quote", len(f.Steps)})
		f.Steps = append(f.Steps, step103{o, line, []NativeBatch{b}})
		idx++
	}
	grid := func(at float64) {
		f.Events = append(f.Events, event103{"grid", len(f.Grids)})
		f.Grids = append(f.Grids, at)
	}
	atr := 40.75
	if unknown {
		atr = 0
	}
	feed(g-2, 0, atr, false, birth("初回", side, 6))
	feed(g-1, 0, atr, false)
	grid(g)
	feed(g+1, 0, atr, false)
	feed(g+2, 20, atr, false)
	feed(g+3, 25, atr, false, closeSignal("部分", "玉-初回", side, 3))
	feed(g+4, 25, atr, false)
	feed(g+5, 70, 40.75, false)
	feed(g+6, 120, 300, false)
	if len(sourcePriority) > 0 && sourcePriority[0] {
		feed(g+7, 60, 1, false, closeSignal("全予約", "玉-初回", side, 3))
	} else {
		feed(g+7, 60, 1, false)
	}
	feed(g+8, 0, 40.75, false)
	feed(g+8, 0, 40.75, true)
	feed(g+9, -10, 40.75, false)
	feed(g+298, 0, 40.75, false, birth("親追加", side, 4))
	feed(g+299, 0, 40.75, false)
	grid(g + 300)
	feed(g+301, 0, 40.75, false)
	feed(g+302, 30, 40.75, false)
	b := src.force(g + 302)
	b.Delta.SourceLine = src.last.SourceLine
	f.Events = append(f.Events, event103{"timer", len(f.Timers)})
	f.Timers = append(f.Timers, timer103{g + 302, []NativeBatch{b}})
	feed(g+302, 30, 40.75, true)
	feed(g+302, 20, 40.75, false)
	feed(g+303, 10, 40.75, false)
	return f
}

// oldBatches は固定NativeDeltaを旧103の名前付き外型へ明示対応します。
//
// 引数: in([]NativeBatch)は不変の手製通知です。
// 返り値: []old.NativeBatchはnil/順序/全Deltaを保持します。
func oldBatches(in []NativeBatch) []old.NativeBatch {
	if in == nil {
		return nil
	}
	out := make([]old.NativeBatch, len(in))
	for i, b := range in {
		out[i] = old.NativeBatch{Method: b.Method, Delta: b.Delta}
	}
	return out
}

// TestWidthW0Exact は新W0と独立生成した旧103四冊を全時点/最終で全文照合します。
//
// 引数: t(*testing.T)は非市場の公開API試験器です。
// 返り値: ありません。旧市場Nativeや金額対照を読みません。
func TestWidthW0Exact(t *testing.T) {
	for _, side := range []int{1, -1} {
		for _, unknown := range []bool{false, true} {
			f := widthWave(side, unknown)
			g := f.Session.Start + 1800
			before, _ := json.Marshal(f)
			news := []*ActualBook{}
			olds := []*old.ActualBook{}
			for _, c := range []float64{0, 5} {
				for _, d := range []int{0, 1} {
					cfg := ActorConfig{Policy: "P0", ActivationPolicy: ActivationLD10, EntryTiming: "B5Q", SlipPts: c, DelaySeconds: d}
					n, e := NewWidthBook(f.Session, cfg, "W0", "手製限月")
					if e != nil {
						t.Fatal(e)
					}
					o, e := old.NewActualBook(f.Session, old.ActorConfig{Policy: "P0", ActivationPolicy: old.ActivationLD10, EntryTiming: "B5Q", SlipPts: c, DelaySeconds: d})
					if e != nil {
						t.Fatal(e)
					}
					if e = n.OnWidthObservation(g-3, widthObs(side, 1, g-180, WidthTruth{})); e != nil {
						t.Fatal(e)
					}
					news = append(news, n)
					olds = append(olds, o)
				}
			}
			checks := 0
			finals := map[string]ActualResult{}
			controls := map[string]old.ActualResult{}
			for _, ev := range f.Events {
				for i, n := range news {
					var ne, oe error
					switch ev.Kind {
					case "quote":
						s := f.Steps[ev.Index]
						ne = n.OnNativeStep(s.Observation, s.SourceLine, s.Batches)
						oe = olds[i].OnNativeStep(s.Observation, s.SourceLine, oldBatches(s.Batches))
					case "grid":
						ne = n.OnEntryGrid(f.Grids[ev.Index])
						oe = olds[i].OnEntryGrid(f.Grids[ev.Index])
					case "timer":
						s := f.Timers[ev.Index]
						ne = n.OnNativeForce(s.At, s.Batches)
						oe = olds[i].OnNativeForce(s.At, oldBatches(s.Batches))
					}
					if ne != nil || oe != nil {
						t.Fatal(ne, oe)
					}
					equal103(t, n.Snapshot(), olds[i].Snapshot(), "W0全時点除外0")
					checks++
				}
			}
			for i, n := range news {
				nr, e := n.Finish()
				if e != nil {
					t.Fatal(e)
				}
				or, e := olds[i].Finish()
				if e != nil {
					t.Fatal(e)
				}
				equal103(t, nr, or, "W0最終除外0")
				finals[nr.Key] = nr
				controls[or.Key] = or
				if nr.Totals.EntryQuantity == 0 || !nr.Complete || nr.Totals.OpenBuy+nr.Totals.OpenSell+nr.Totals.PendingBuy+nr.Totals.PendingSell != 0 {
					t.Fatal("非0完結")
				}
			}
			after, _ := json.Marshal(f)
			if !bytes.Equal(before, after) {
				t.Fatal("入力変更")
			}
			t.Logf("方向%d 未知ATR%t 全時点%d 最終4 除外0", side, unknown, checks)
			if dir := os.Getenv("WIDTH_EXPORT"); dir != "" {
				data, _ := json.MarshalIndent(map[string]any{"scope": f.Scope, "fixture": f, "books": finals, "baseline103": controls, "all_points_checks": checks, "excluded": []string{}}, "", "  ")
				if e := os.WriteFile(filepath.Join(dir, fmt.Sprintf("W0方向%d_未知%t.json", side, unknown)), data, 0600); e != nil {
					t.Fatal(e)
				}
			}
		}
	}
}

// TestWidthDynamicAPI は起動前latest/初起動狭幅/構造必須/予約/悪化/Forceを結びます。
//
// 引数: t(*testing.T)は非市場の買売・C0C5・D0D1試験器です。
// 返り値: ありません。生C/M/P計算や市場利益の証明は含みません。
func TestWidthDynamicAPI(t *testing.T) {
	for _, side := range []int{1, -1} {
		for _, unknown := range []bool{false, true} {
			f := widthWave(side, unknown)
			g := f.Session.Start + 1800
			books := []*ActualBook{}
			for _, policy := range []string{"W1", "W2"} {
				for _, c := range []float64{0, 5} {
					for _, d := range []int{0, 1} {
						b, e := NewWidthBook(f.Session, ActorConfig{Policy: "P0", ActivationPolicy: ActivationLD10, EntryTiming: "B5Q", SlipPts: c, DelaySeconds: d}, policy, "手製限月")
						if e != nil {
							t.Fatal(e)
						}
						if e = b.OnWidthObservation(g-3, widthObs(side, 1, g-180, WidthTruth{})); e != nil {
							t.Fatal(e)
						}
						books = append(books, b)
					}
				}
			}
			for _, ev := range f.Events {
				if ev.Kind == "quote" && f.Steps[ev.Index].Observation.Time == g+6 {
					for _, b := range books {
						a := b.WidthAudit()
						p := a.Positions[0]
						if (a.Policy == "W1") != p.State.Narrowed || p.State.NarrowedAt != nil && *p.State.NarrowedAt != g+5 {
							t.Fatal("初起動latest/必要P", a)
						}
						if e := b.ResetWidthObservation(g+6, "手製Last0失効"); e != nil {
							t.Fatal(e)
						}
						if e := b.OnWidthObservation(g+6, widthObs(side, 1, g-180, WidthTruth{})); e != nil {
							t.Fatal(e)
						}
						if e := b.OnWidthObservation(g+6, widthObs(side, 2, g, WidthTruth{true, widthPointer(true)})); e != nil {
							t.Fatal(e)
						}
					}
				}
				for _, b := range books {
					var e error
					switch ev.Kind {
					case "quote":
						s := f.Steps[ev.Index]
						e = b.OnNativeStep(s.Observation, s.SourceLine, s.Batches)
					case "grid":
						e = b.OnEntryGrid(f.Grids[ev.Index])
					case "timer":
						s := f.Timers[ev.Index]
						e = b.OnNativeForce(s.At, s.Batches)
					}
					if e != nil {
						t.Fatal(side, unknown, e)
					}
				}
			}
			for _, b := range books {
				r, e := b.Finish()
				if e != nil {
					t.Fatal(e)
				}
				a := b.WidthAudit()
				if !r.Complete || r.Totals.EntryQuantity == 0 || len(a.Positions) != 2 || !a.Positions[0].State.Narrowed || a.Positions[0].FirstNarrow == nil || !a.Positions[0].State.Finished || a.Positions[0].FirstObservation == nil || a.Positions[0].FirstObservation.PublicationID != *a.Positions[0].State.NarrowedBy || !a.Positions[0].FirstCondition.Known || !*a.Positions[0].FirstCondition.Passed {
					t.Fatal("狭幅/終玉/非0", a)
				}
				if a.Positions[0].State.ATRLock == nil || *a.Positions[0].State.ATRLock != 40.75 {
					t.Fatal("取得ATR固定")
				}
				copyAudit := b.WidthAudit()
				copyAudit.Positions[0].FirstObservation.C.Passed = widthPointer(false)
				if !*b.WidthAudit().Positions[0].FirstObservation.C.Passed {
					t.Fatal("auditのpointer共有")
				}
				for _, order := range r.Orders {
					if order.Kind == "exit" && order.ProtectionPoint != nil && order.Quantity > order.ProtectionPoint.Quantity-order.ProtectionPoint.Reserved {
						t.Fatal("Source予約超過")
					}
				}
				if dir := os.Getenv("WIDTH_EXPORT"); dir != "" {
					data, _ := json.MarshalIndent(map[string]any{"scope": f.Scope, "fixture": f, "book": r, "width_audit": a}, "", "  ")
					path := filepath.Join(dir, fmt.Sprintf("方向%d_未知%t_%s_C%.0f_D%d.json", side, unknown, a.Policy, r.Config.SlipPts, r.Config.DelaySeconds))
					if e = os.WriteFile(path, data, 0600); e != nil {
						t.Fatal(e)
					}
				}
			}
		}
	}
}

// TestWidthBoundary は未来/改変/未知/非緩和と純stateの三値を狭く検査します。
//
// 引数: t(*testing.T)は型人工の試験器です。
// 返り値: ありません。独立全原行金融再生は主張しません。
func TestWidthBoundary(t *testing.T) {
	s, e := NewWidthState("W1", session().ID, "手製限月", 1, 1000)
	if e != nil {
		t.Fatal(e)
	}
	o := widthObs(1, 1, 100, WidthTruth{})
	up, e := AdvanceWidth(s, WidthMark{At: 100, Sequence: 1, Observation: &o})
	if e != nil {
		t.Fatal(e)
	}
	u, e := AdvanceWidth(up.State, WidthMark{At: 101, Sequence: 2, Mark: widthPointer(1100.0), LDActive: true, ATRLock: widthPointer(40.75)})
	if e != nil {
		t.Fatal(e)
	}
	if !u.State.Narrowed || *u.Width != 45 || *u.State.Floor != 55 {
		t.Fatal("非整数幅", u)
	}
	reset := "欠測"
	v, e := AdvanceWidth(u.State, WidthMark{At: 102, Sequence: 3, Mark: widthPointer(1001.0), LDActive: true, ResetReason: &reset, Observation: &o})
	if e != nil {
		t.Fatal(e)
	}
	if v.State.Latest != nil || !v.State.Narrowed || *v.State.Floor != 55 {
		t.Fatal("resetで緩和/同ID復活")
	}
	for _, name := range []string{"未来", "同ID改変", "ATR変更", "起動逆転", "順序逆転", "未知をfalse", "別場"} {
		t.Run(name, func(t *testing.T) {
			x := WidthMark{At: 103, Sequence: 4, Mark: widthPointer(1100.0), LDActive: true}
			bad := o
			switch name {
			case "未来":
				bad = widthObs(1, 2, 104, WidthTruth{})
				x.Observation = &bad
			case "同ID改変":
				bad.C.Passed = widthPointer(false)
				x.Observation = &bad
			case "ATR変更":
				x.ATRLock = widthPointer(50.0)
			case "起動逆転":
				x.LDActive = false
			case "順序逆転":
				x.Sequence = 3
			case "未知をfalse":
				bad.P.Passed = widthPointer(false)
				x.Observation = &bad
			case "別場":
				bad.Session = "別場"
				x.Observation = &bad
			}
			if _, e := AdvanceWidth(v.State, x); e == nil {
				t.Fatal("破損受理")
			}
		})
	}
	b, e := NewWidthBook(session(), ActorConfig{Policy: "P0", ActivationPolicy: ActivationLD10, EntryTiming: "B5Q"}, "W1", "手製限月")
	if e != nil {
		t.Fatal(e)
	}
	pub := widthObs(1, 1, session().Start, WidthTruth{})
	if e = b.OnWidthObservation(pub.End, pub); e != nil {
		t.Fatal(e)
	}
	snapshot := b.Snapshot()
	if len(snapshot.Positions) != 0 || snapshot.Metrics.Rows != 0 || b.WidthAudit().Updates != 0 {
		t.Fatal("公表だけで金融更新")
	}
}

// TestWidthSourcePriority は同原行の狭幅hitよりSource全予約を優先します。
//
// 引数: t(*testing.T)は買売・全費用/遅延のAPI人工試験器です。
// 返り値: ありません。prefill hitは観測だけ、after_source残予約0なら保護要求0です。
func TestWidthSourcePriority(t *testing.T) {
	for _, side := range []int{1, -1} {
		for _, c := range []float64{0, 5} {
			for _, d := range []int{0, 1} {
				f := widthWave(side, false, true)
				g := f.Session.Start + 1800
				b, e := NewWidthBook(f.Session, ActorConfig{Policy: "P0", ActivationPolicy: ActivationLD10, EntryTiming: "B5Q", SlipPts: c, DelaySeconds: d}, "W2", "手製限月")
				if e != nil {
					t.Fatal(e)
				}
				o := widthObs(side, 1, g-180, WidthTruth{true, widthPointer(true)})
				o.C.Passed = widthPointer(false)
				if e = b.OnWidthObservation(g-3, o); e != nil {
					t.Fatal(e)
				}
				for _, ev := range f.Events {
					if ev.Kind == "quote" && f.Steps[ev.Index].Observation.Time == g+7 {
						o = widthObs(side, 2, g, WidthTruth{true, widthPointer(true)})
						if e = b.OnWidthObservation(g+7, o); e != nil {
							t.Fatal(e)
						}
					}
					switch ev.Kind {
					case "quote":
						s := f.Steps[ev.Index]
						e = b.OnNativeStep(s.Observation, s.SourceLine, s.Batches)
					case "grid":
						e = b.OnEntryGrid(f.Grids[ev.Index])
					case "timer":
						s := f.Timers[ev.Index]
						e = b.OnNativeForce(s.At, s.Batches)
					}
					if e != nil {
						t.Fatal(e)
					}
				}
				r, e := b.Finish()
				if e != nil {
					t.Fatal(e)
				}
				a := b.WidthAudit()
				if r.Metrics.ProtectionExitRequests != 0 || a.Positions[0].FirstNarrow == nil || a.Positions[0].FirstNarrow.Phase != PhasePreFill || r.Positions[0].FirstFloorHit == nil {
					t.Fatal("Source予約優先/初hit出典", r.Metrics, a)
				}
			}
		}
	}
}

// TestWidthPureExport は停止Pythonへ渡す純状態の全field型を少数exportします。
//
// 引数: t(*testing.T)、環境WIDTH_PURE_EXPORT(string)は試験器と明示人工保存先です。
// 返り値: ありません。Source/会計/価格形成の人工とは分けます。
func TestWidthPureExport(t *testing.T) {
	path := os.Getenv("WIDTH_PURE_EXPORT")
	if path == "" {
		t.Skip("明示export時だけ")
	}
	cases := []map[string]any{}
	for _, policy := range []string{"W0", "W1", "W2"} {
		for _, side := range []int{1, -1} {
			state, e := NewWidthState(policy, session().ID, "手製限月", side, 1000)
			if e != nil {
				t.Fatal(e)
			}
			first := widthObs(side, 1, 100, WidthTruth{})
			second := widthObs(side, 2, 280, WidthTruth{true, widthPointer(true)})
			third := widthObs(side, 3, 281, WidthTruth{})
			third.C.Passed = widthPointer(false)
			third.M = WidthTruth{}
			reset := "手製欠測"
			marks := []WidthMark{
				{At: 100, Sequence: 1, Observation: &first},
				{At: 101, Sequence: 2, Mark: widthPointer(1000 + 20*float64(side)), ATRLock: widthPointer(40.75)},
				{At: 102, Sequence: 3, Mark: widthPointer(1000 + 80*float64(side)), LDActive: true},
				{At: 103, Sequence: 4, Mark: widthPointer(1000 + 75*float64(side)), LDActive: true, ResetReason: &reset},
				{At: 104, Sequence: 5, Mark: widthPointer(1000 + 70*float64(side)), LDActive: true, Observation: &first},
				{At: 280, Sequence: 6, Mark: widthPointer(1000 + 110*float64(side)), LDActive: true, Observation: &second},
				{At: 281, Sequence: 7, Mark: widthPointer(1000 + 50*float64(side)), LDActive: true, Observation: &third},
				{At: 282, Sequence: 8, Mark: widthPointer(1000.0), LDActive: true},
			}
			for _, in := range marks {
				output, e := AdvanceWidth(state, in)
				if e != nil {
					t.Fatal(e)
				}
				cases = append(cases, map[string]any{"state": state, "input": in, "output": output})
				state = output.State
			}
		}
	}
	data, e := json.MarshalIndent(map[string]any{"scope": "手製外部C/M/Pと正常markの純状態だけ。OHLC/指標/Source/会計形成0", "cases": cases}, "", "  ")
	if e != nil {
		t.Fatal(e)
	}
	if e = os.WriteFile(path, data, 0600); e != nil {
		t.Fatal(e)
	}
}
