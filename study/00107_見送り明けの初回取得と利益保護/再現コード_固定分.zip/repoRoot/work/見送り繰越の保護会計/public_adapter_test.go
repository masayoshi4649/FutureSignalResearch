package miniquietguard

import (
	"encoding/json"
	"os"
	"testing"

	prior "github.com/masayoshi4649/SessionTradeExecuter/minivariableguard"
	delivery "github.com/masayoshi4649/SessionTradeExecuter/publicdelivery"
)

// TestPublicReceiverExact は停止8c42の既存型を全fieldのまま新Eへ渡します。
//
// 引数: t(*testing.T)は公開12手製型の試験器。
// 返り値: ありません。公表配送だけで金融起動/注文を生成しません。
func TestPublicReceiverExact(t *testing.T) {
	raw, e := os.ReadFile("../収束可変幅の公開配送案/人工_停止版/Go公開12の配送.json")
	if e != nil {
		t.Fatal(e)
	}
	var v struct {
		Cases []struct {
			Scene    string            `json:"scene"`
			Delivery delivery.Delivery `json:"delivery"`
		} `json:"cases"`
	}
	if e = json.Unmarshal(raw, &v); e != nil {
		t.Fatal(e)
	}
	books := map[string]*ActualBook{}
	for _, c := range v.Cases {
		f := c.Delivery.Frame
		b := books[c.Scene]
		if b == nil {
			s := Session{ID: f.Session, Kind: "Day", Start: f.Start, End: f.Start + 25200, ForceClose: f.Start + 24600}
			b, e = NewEarlyBook(s, ActorConfig{Policy: "P0", ActivationPolicy: ActivationE1, EntryTiming: "B5Q"}, f.Contract)
			if e != nil {
				t.Fatal(e)
			}
			books[c.Scene] = b
		}
		for _, o := range []*prior.WidthObservation{c.Delivery.Buy, c.Delivery.Sell} {
			equal103(t, ConvertPublicObservation(*o), *o, "旧新named型全field")
		}
		if e = delivery.Send(c.Delivery, PublicReceiver{Book: b}); e != nil {
			t.Fatal(e)
		}
		if len(b.Snapshot().Positions) != 0 || b.Snapshot().Metrics.Rows != 0 || len(b.EarlyAudit().Positions) != 0 {
			t.Fatal("公表で金融を起動")
		}
	}
	if len(v.Cases) != 12 || len(books) != 2 {
		t.Fatal("元公開12の集合")
	}
}
