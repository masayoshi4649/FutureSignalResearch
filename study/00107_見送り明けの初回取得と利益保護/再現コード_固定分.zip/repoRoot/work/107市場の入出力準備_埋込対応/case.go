package main

import (
	"encoding/json"
	"fmt"
	"path/filepath"

	core "github.com/masayoshi4649/SessionTradeExecuter/quietguardruntime107"
	reader "github.com/masayoshi4649/SessionTradeExecuter/savedpublic107"
)

type SceneResult struct {
	Session   string  `json:"session"`
	Native    FileRef `json:"native"`
	Header    FileRef `json:"sidecar_header"`
	Records   FileRef `json:"sidecar_records"`
	Books     int     `json:"books"`
	BaseBooks int     `json:"base_control_books"`
	Error     string  `json:"error,omitempty"`
}

type Provenance struct {
	InputMode         string `json:"input_mode"`
	RawRead           bool   `json:"raw_market_read"`
	SourceReexecuted  bool   `json:"source_reexecuted"`
	BankRecomputed    bool   `json:"bank_recomputed"`
	FinancialExecuted bool   `json:"financial_executed"`
}

type NativeOutput struct {
	core.Result
	ConditionSHA string             `json:"condition_sha256"`
	Input        reader.Proof       `json:"input_proof"`
	Replay       reader.ReplayProof `json:"replay_proof"`
	Provenance   Provenance         `json:"provenance"`
}

// loadControl は認証済み106実物から対象12冊と外auditだけを全文取得します。
//
// 引数: ref(reader.FileRef)はLoadedが認証した106 Nativeです。
// 返り値: core.Control/errorは除外fieldのない12/12/4の期待値です。成績を新会計へ転記しません。
func loadControl(ref reader.FileRef) (core.Control, error) {
	before := map[string]string{}
	p, err := checkRef(FileRef{ref.Path, ref.SHA}, ".", before)
	if err != nil {
		return core.Control{}, err
	}
	var old struct {
		Trial    int                        `json:"trial"`
		Complete bool                       `json:"complete"`
		Books    map[string]json.RawMessage `json:"books"`
		Width    map[string]json.RawMessage `json:"width_audits"`
		Early    map[string]json.RawMessage `json:"early_audits"`
	}
	if err = readJSON(p, true, &old); err != nil {
		return core.Control{}, err
	}
	if old.Trial != 106 || !old.Complete {
		return core.Control{}, fmt.Errorf("旧106 Native未完了")
	}
	c := core.Control{Kind: "provided_old106", HistoryClass: "old_saved_70", ReferencePath: p, ReferenceSHA: ref.SHA, Books: map[string]json.RawMessage{}, WidthAudits: map[string]json.RawMessage{}, EarlyAudits: map[string]json.RawMessage{}}
	for _, policy := range []string{"W0", "W1", "E1"} {
		for _, cost := range []int{0, 5} {
			for _, delay := range []int{0, 1} {
				key := fmt.Sprintf("%s_C%d_D%d", policy, cost, delay)
				if len(old.Books[key]) == 0 || len(old.Width[key]) == 0 {
					return c, fmt.Errorf("旧106の基準Book/幅不足:%s", key)
				}
				c.Books[key], c.WidthAudits[key] = old.Books[key], old.Width[key]
				if policy == "E1" {
					if len(old.Early[key]) == 0 {
						return c, fmt.Errorf("旧106の早期audit不足:%s", key)
					}
					c.EarlyAudits[key] = old.Early[key]
				}
			}
		}
	}
	_, err = recheck(before)
	return c, err
}

// runScene は一場の保存列だけを独立した24会計へ配送します。
//
// 引数: p(Plan)、id/out(string)は固定計画・一場・新規出力directory。
// 返り値: SceneResultはNative参照又は失敗理由です。他場の金融状態を共有しません。
func runScene(p Plan, id, out string) (result SceneResult) {
	result.Session = id
	loaded, err := reader.LoadTape(readerRequest(p, id))
	if err != nil {
		result.Error = err.Error()
		return
	}
	proof := loaded.Proof()
	control, err := loadControl(proof.ExpectedNative)
	if err != nil {
		result.Error = err.Error()
		return
	}
	input := loaded.Tape()
	header := loaded.Header()
	runtime, err := core.NewCore(input, header.Scene.Contract, p.Condition.Scope, control)
	if err != nil {
		result.Error = err.Error()
		return
	}
	h, replay, err := reader.ReplayRecords(loaded, runtime.Feed)
	if err != nil {
		result.Error = err.Error()
		return
	}
	r, err := runtime.Finish(h)
	if err != nil {
		result.Error = err.Error()
		return
	}
	if !r.Complete || len(r.Books) != 24 || !r.BaseControl.All || r.BaseControl.Books != 12 || r.BaseControl.WidthAudits != 12 || r.BaseControl.EarlyAudits != 4 || !replay.Unchanged || r.SourceReexecuted || r.ChartRecomputed || r.BankRecomputed {
		result.Error = "24会計/基準12/幅12/早期4/再用の完了差"
		return
	}
	value := NativeOutput{Result: r, ConditionSHA: p.ConditionSHA, Input: proof, Replay: replay, Provenance: Provenance{InputMode: p.Condition.Mode, FinancialExecuted: true}}
	result.Native, err = writeJSON(filepath.Join(out, id+".Native.json.gz"), value, true)
	if err != nil {
		result.Error = err.Error()
		return
	}
	for _, old := range p.Prior.Results {
		if old.Session == id {
			a, _ := absolute(p.Base, old.Header.Path)
			b, _ := absolute(p.Base, old.Records.Path)
			result.Header = FileRef{a, old.Header.SHA}
			result.Records = FileRef{b, old.Records.SHA}
			break
		}
	}
	result.Books, result.BaseBooks = 24, 12
	return
}
