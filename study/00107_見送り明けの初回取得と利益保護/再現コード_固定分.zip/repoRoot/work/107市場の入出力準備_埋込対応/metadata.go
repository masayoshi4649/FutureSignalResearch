package main

import (
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"regexp"

	core "github.com/masayoshi4649/SessionTradeExecuter/quietguardruntime107"
	reader "github.com/masayoshi4649/SessionTradeExecuter/savedpublic107"
)

type Condition struct {
	Version         int               `json:"version"`
	Trial           int               `json:"trial"`
	Fixed           bool              `json:"fixed"`
	Scope           string            `json:"scope"`
	Mode            string            `json:"input_mode"`
	Workers         int               `json:"workers"`
	OwnModuleDir    string            `json:"own_module_dir"`
	PriorClosure    FileRef           `json:"prior_closure"`
	Manifest        FileRef           `json:"input_manifest"`
	Corpus          FileRef           `json:"source_corpus"`
	PriorCompletion FileRef           `json:"prior_completion"`
	Binary          FileRef           `json:"binary"`
	Stops           []FileRef         `json:"stops"`
	Specifications  []FileRef         `json:"specifications"`
	Code            map[string]string `json:"code_sha256"`
	Configs         []core.Config     `json:"configs"`
}

type Plan struct {
	Condition    Condition
	ConditionSHA string
	Base         string
	Before       map[string]string
	Manifest     reader.Manifest
	Prior        reader.Completion
}

// prepare は金融へ進む前に107条件と106成功metadataを固定します。
//
// 引数: path/expected(string)はRoot固定JSONと明示SHAです。
// 返り値: Plan/errorは固定24設定・全70の参照又は不成立です。原板/CSVを読みません。
func prepare(path, expected string) (Plan, error) {
	p := Plan{Before: map[string]string{}}
	full, err := filepath.Abs(path)
	if err != nil {
		return p, err
	}
	p.Base, p.ConditionSHA = filepath.Dir(full), expected
	if _, err = checkRef(FileRef{full, expected}, p.Base, p.Before); err != nil {
		return p, err
	}
	if err = readJSON(full, false, &p.Condition); err != nil {
		return p, err
	}
	c := p.Condition
	if c.Version != 1 || c.Trial != 107 || !c.Fixed || c.Scope == "" || c.Mode != "recorded_public_106" || c.Workers < 1 || c.Workers > 4 || c.OwnModuleDir == "" || !reflect.DeepEqual(c.Configs, core.Configurations()) || len(c.Stops) != 6 || len(c.Specifications) != 2 || len(c.Code) == 0 {
		return p, fmt.Errorf("107の固定条件/24設定/worker/仕様参照差")
	}
	refs := append([]FileRef{c.PriorClosure, c.Manifest, c.Corpus, c.PriorCompletion, c.Binary}, c.Stops...)
	refs = append(refs, c.Specifications...)
	for _, ref := range refs {
		if _, err = checkRef(ref, p.Base, p.Before); err != nil {
			return p, err
		}
	}
	pinned := map[string]string{}
	for name, h := range c.Code {
		var checked string
		if checked, err = checkRef(FileRef{name, h}, p.Base, p.Before); err != nil {
			return p, err
		}
		pinned[checked] = h
	}
	ownRoot, err := absolute(p.Base, c.OwnModuleDir)
	if err != nil {
		return p, err
	}
	stops := []string{}
	seenStop := map[string]bool{}
	for _, ref := range c.Stops {
		q, _ := absolute(p.Base, ref.Path)
		if seenStop[q] {
			return p, fmt.Errorf("停止参照の重複")
		}
		seenStop[q] = true
		stops = append(stops, q)
	}
	if err = verifyCodeScope(ownRoot, pinned, stops); err != nil {
		return p, err
	}
	exe, err := os.Executable()
	if err != nil {
		return p, err
	}
	actual, err := fileSHA(exe)
	if err != nil {
		return p, err
	}
	if actual != c.Binary.SHA {
		return p, fmt.Errorf("実行binaryが固定物と異なる")
	}
	var closed struct {
		Trial    int  `json:"試行"`
		Complete bool `json:"試行完了"`
	}
	closure, _ := absolute(p.Base, c.PriorClosure.Path)
	if err = readJSON(closure, false, &closed); err != nil {
		return p, err
	}
	if closed.Trial != 106 || !closed.Complete {
		return p, fmt.Errorf("旧106未完了")
	}
	manifest, _ := absolute(p.Base, c.Manifest.Path)
	if err = readJSON(manifest, false, &p.Manifest); err != nil {
		return p, err
	}
	prior, _ := absolute(p.Base, c.PriorCompletion.Path)
	if err = readJSON(prior, false, &p.Prior); err != nil {
		return p, err
	}
	if !p.Prior.Success || p.Prior.Trial != 106 || p.Prior.Stage != "full70" || p.Prior.Sessions != 70 || p.Prior.Books != 1400 || !p.Prior.Unchanged || !reflect.DeepEqual(p.Prior.Before, p.Prior.After) || p.Prior.ConditionSHA != reader.Condition106 || len(p.Prior.Results) != 70 || len(p.Manifest.Sessions) != 70 {
		return p, fmt.Errorf("106全70成功の結合差")
	}
	seen := map[string]bool{}
	valid := regexp.MustCompile(`^\d{4}-\d{2}-\d{2}_(Day|Night)$`)
	for i, s := range p.Manifest.Sessions {
		r := p.Prior.Results[i]
		if !valid.MatchString(s.ID) || seen[s.ID] || r.Session != s.ID || r.Books != 20 || r.W0Books != 4 || r.Error != "" || !filepath.IsAbs(r.Native.Path) || !filepath.IsAbs(r.Header.Path) || !filepath.IsAbs(r.Records.Path) {
			return p, fmt.Errorf("全70の場ID/順序/実物絶対参照差")
		}
		seen[s.ID] = true
	}
	return p, nil
}

// verifyCodeScope は当CLIと各成功停止の所有集合の固定漏れを拒否します。
//
// 引数: ownRoot(string)、code(map[string]string)、stops([]string)は絶対配置・認証済みcode・成功停止pathです。
// 返り値: errorは自己又は停止所有の包含不足です。Go依存閉包の列挙はRoot固定helperが別途行います。
func verifyCodeScope(ownRoot string, code map[string]string, stops []string) error {
	for _, name := range []string{"io.go", "metadata.go", "case.go", "main.go", "io_test.go", "go.mod", "go.sum"} {
		if len(code[filepath.Join(ownRoot, name)]) != 64 {
			return fmt.Errorf("CLI自己包含不足:%s", name)
		}
	}
	repoRoot := filepath.Dir(filepath.Dir(ownRoot))
	for _, path := range stops {
		var stop struct {
			Success bool              `json:"成功"`
			Owned   map[string]string `json:"所有コードSHA256"`
		}
		if err := readJSON(path, false, &stop); err != nil {
			return err
		}
		if !stop.Success || len(stop.Owned) == 0 {
			return fmt.Errorf("成功停止/所有集合が必要:%s", path)
		}
		for name, want := range stop.Owned {
			p, err := absolute(repoRoot, name)
			if err != nil {
				return err
			}
			if len(want) != 64 || code[p] != want {
				return fmt.Errorf("停止所有の固定包含差:%s", p)
			}
		}
	}
	return nil
}

// readerRequest は107固定参照をpure readerの型へ明示変換します。
//
// 引数: p(Plan)、id(string)は固定計画と一場です。
// 返り値: reader.Requestは全Refを絶対pathへ束縛した読取要求です。
func readerRequest(p Plan, id string) reader.Request {
	return reader.Request{Manifest: readerRef(p.Base, p.Condition.Manifest), Corpus: readerRef(p.Base, p.Condition.Corpus), Completion: readerRef(p.Base, p.Condition.PriorCompletion), SceneID: id}
}

// readerRef は認証済み参照をpure readerのFileRefへ対応させます。
//
// 引数: base(string)、ref(FileRef)はprepareで検査した基準と参照です。
// 返り値: reader.FileRefは絶対pathと同じSHAです。追加の読取はしません。
func readerRef(base string, ref FileRef) reader.FileRef {
	path, _ := absolute(base, ref.Path)
	return reader.FileRef{Path: path, SHA: ref.SHA}
}
