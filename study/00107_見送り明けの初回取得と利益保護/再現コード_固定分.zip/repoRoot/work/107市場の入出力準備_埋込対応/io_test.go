package main

import (
	"bytes"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"

	reader "github.com/masayoshi4649/SessionTradeExecuter/savedpublic107"
)

// TestPinnedReferences は同pathの宣言差と実行中変更を拒否することを確認します。
//
// 引数: t(*testing.T)は手製の小ファイルだけを使う検査器です。
// 返り値: なし。原板・保存市場列・金融は読みません。
func TestPinnedReferences(t *testing.T) {
	dir := t.TempDir()
	p := filepath.Join(dir, "固定.json")
	if err := os.WriteFile(p, []byte("{\"版\":1}\n"), 0600); err != nil {
		t.Fatal(err)
	}
	h, err := fileSHA(p)
	if err != nil {
		t.Fatal(err)
	}
	before := map[string]string{}
	if _, err = checkRef(FileRef{"固定.json", h}, dir, before); err != nil {
		t.Fatal(err)
	}
	if _, err = checkRef(FileRef{"固定.json", string(bytes.Repeat([]byte{'0'}, 64))}, dir, before); err == nil {
		t.Fatal("偽SHAを受理")
	}
	if _, err = recheck(before); err != nil {
		t.Fatal(err)
	}
	if err = os.WriteFile(p, []byte("{\"版\":2}\n"), 0600); err != nil {
		t.Fatal(err)
	}
	if _, err = recheck(before); err == nil {
		t.Fatal("読取後変更を受理")
	}
}

// TestJSONBoundary はgzip復元と余剰JSON・破損CRC・上書きの拒否を確認します。
//
// 引数: t(*testing.T)は経済値を含まない手製JSONの検査器です。
// 返り値: なし。ファイル形式だけを検査します。
func TestJSONBoundary(t *testing.T) {
	dir := t.TempDir()
	p := filepath.Join(dir, "値.json.gz")
	if _, err := writeJSON(p, map[string]string{"用途": "手製"}, true); err != nil {
		t.Fatal(err)
	}
	var got map[string]string
	if err := readJSON(p, true, &got); err != nil || got["用途"] != "手製" {
		t.Fatalf("復元:%v %v", got, err)
	}
	if _, err := writeJSON(p, map[string]string{}, true); err == nil {
		t.Fatal("既存出力の上書き")
	}
	b, err := os.ReadFile(p)
	if err != nil {
		t.Fatal(err)
	}
	b[len(b)-8] ^= 0xff
	bad := filepath.Join(dir, "破損.gz")
	if err = os.WriteFile(bad, b, 0600); err != nil {
		t.Fatal(err)
	}
	if err = readJSON(bad, true, &got); err == nil {
		t.Fatal("CRC破損を受理")
	}
	extra := filepath.Join(dir, "余剰.json")
	if err = os.WriteFile(extra, []byte("{}\n{}\n"), 0600); err != nil {
		t.Fatal(err)
	}
	if err = readJSON(extra, false, &got); err == nil {
		t.Fatal("余剰JSONを受理")
	}
}

// TestControlProjection は対象12/12/4をRawMessageのまま渡すことを確認します。
//
// 引数: t(*testing.T)は金融として実行しない不透明な手製payloadの検査器です。
// 返り値: なし。Bookの利益や妥当性をこのテストから主張しません。
func TestControlProjection(t *testing.T) {
	dir := t.TempDir()
	p := filepath.Join(dir, "人工.Native.json.gz")
	books := map[string]json.RawMessage{}
	width := map[string]json.RawMessage{}
	early := map[string]json.RawMessage{}
	for _, policy := range []string{"W0", "W1", "W2", "E1", "E2"} {
		for _, cost := range []string{"0", "5"} {
			for _, delay := range []string{"0", "1"} {
				key := policy + "_C" + cost + "_D" + delay
				books[key] = json.RawMessage(`{"不透明":{"追加欄":"保持"}}`)
				width[key] = json.RawMessage(`{"不透明幅":[1,2]}`)
				if policy == "E1" || policy == "E2" {
					early[key] = json.RawMessage(`{"不透明早期":true}`)
				}
			}
		}
	}
	ref, err := writeJSON(p, map[string]any{"trial": 106, "complete": true, "books": books, "width_audits": width, "early_audits": early}, true)
	if err != nil {
		t.Fatal(err)
	}
	c, err := loadControl(reader.FileRef{Path: ref.Path, SHA: ref.SHA})
	if err != nil {
		t.Fatal(err)
	}
	if len(c.Books) != 12 || len(c.WidthAudits) != 12 || len(c.EarlyAudits) != 4 {
		t.Fatal("対象集合差")
	}
	for key, value := range c.Books {
		if !bytes.Contains(value, []byte("追加欄")) || key[:2] == "W2" || key[:2] == "E2" {
			t.Fatal("未知fieldの投影又は対象差")
		}
	}
	delete(early, "E1_C5_D1")
	missing := filepath.Join(dir, "欠落.Native.json.gz")
	r, err := writeJSON(missing, map[string]any{"trial": 106, "complete": true, "books": books, "width_audits": width, "early_audits": early}, true)
	if err != nil {
		t.Fatal(err)
	}
	if _, err = loadControl(reader.FileRef{Path: r.Path, SHA: r.SHA}); err == nil {
		t.Fatal("早期対照欠落を受理")
	}
}

// TestCodeScope は自己又は停止所有を欠いた見かけの固定を拒否します。
//
// 引数: t(*testing.T)はcode集合metadataだけを持つ手製検査です。
// 返り値: なし。Goを動的に実行したり市場を開いたりしません。
func TestCodeScope(t *testing.T) {
	repo := t.TempDir()
	own := filepath.Join(repo, "work", "107市場の入出力準備")
	if err := os.MkdirAll(own, 0700); err != nil {
		t.Fatal(err)
	}
	h := string(bytes.Repeat([]byte{'a'}, 64))
	code := map[string]string{}
	for _, name := range []string{"io.go", "metadata.go", "case.go", "main.go", "io_test.go", "go.mod", "go.sum"} {
		code[filepath.Join(own, name)] = h
	}
	ownedName := "work/純部品/README.md"
	ownedPath := filepath.Join(repo, filepath.FromSlash(ownedName))
	code[ownedPath] = h
	stop := filepath.Join(repo, "停止.json")
	if _, err := writeJSON(stop, map[string]any{"成功": true, "所有コードSHA256": map[string]string{ownedName: h}}, false); err != nil {
		t.Fatal(err)
	}
	if err := verifyCodeScope(own, code, []string{stop}); err != nil {
		t.Fatal(err)
	}
	delete(code, filepath.Join(own, "metadata.go"))
	if err := verifyCodeScope(own, code, []string{stop}); err == nil {
		t.Fatal("自己欠落を受理")
	}
	code[filepath.Join(own, "metadata.go")] = h
	delete(code, ownedPath)
	if err := verifyCodeScope(own, code, []string{stop}); err == nil {
		t.Fatal("停止所有欠落を受理")
	}
	code[ownedPath] = string(bytes.Repeat([]byte{'b'}, 64))
	if err := verifyCodeScope(own, code, []string{stop}); err == nil {
		t.Fatal("停止所有の別SHAを受理")
	}
	code[ownedPath] = h
	bad := filepath.Join(repo, "未成功停止.json")
	if _, err := writeJSON(bad, map[string]any{"成功": false, "所有コードSHA256": map[string]string{ownedName: h}}, false); err != nil {
		t.Fatal(err)
	}
	if err := verifyCodeScope(own, code, []string{bad}); err == nil {
		t.Fatal("未成功停止を受理")
	}
}
