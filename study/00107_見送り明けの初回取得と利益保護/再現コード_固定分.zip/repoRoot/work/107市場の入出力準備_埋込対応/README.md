# 107の保存公表再読と24会計の市場口

106で完成した保存Record/Header・Tape/Source記録を入力にする。原板/CSVの読取・hash再計算、Bank/Source形成を行わず、savedpublic107の認証済み入力をquietguardruntime107へ配送する。現在は市場接続前の準備であり、経済結果や採用を主張しない。

## 固定と段階

Rootの条件JSONはversion1/trial107/fixedtrue、input_mode=recorded_public_106、workers1〜4、24 Configurationsと一致するconfigs、old106 closure/manifest/corpus/full70 completion、binary、成功停止6本、仕様前コピー2本、code_sha256とown_module_dirを持つ。

成功停止6本は純時計・Actor・Core・reader・保存器・当市場口。各停止の所有codeをcode集合へ含め、当市場口のGo4本・試験・mod/sumも包含する。Root固定helperはGo依存閉包とtoolchainも収集する。実binary SHAを確認し、metadata/codeは全処理前後、場入力はreaderのReplayProofで前後を確認する。

```powershell
work/107市場の入出力準備/検査/見送り繰越.exe `
  --condition study/00107_見送り明けの初回取得と利益保護/金融条件.json `
  --condition-sha <実SHA> --stage first2 --out work/107市場/先頭2場

work/107市場の入出力準備/検査/見送り繰越.exe `
  --condition study/00107_見送り明けの初回取得と利益保護/金融条件.json `
  --condition-sha <同SHA> --stage full70 --out work/107市場/全70場 `
  --first2 work/107市場/先頭2場/完了.json --first2-sha <先頭2成功SHA>
```

出力先は新規directoryだけ。first2は固定70の先頭2で48冊、同じ条件のfull70は1680冊。先頭2 Native gzip bytesを一致させるため、Nativeへstageや実行時刻・worker番号を入れない。完了記録に段階と完了状況を分ける。

## 配送と比較

各場でreader.LoadTape→106 Nativeの生RawMessageからW0/W1/E1の12 Book・幅12・早期4を取得→NewCore→ReplayRecords(Feed)→Finishを実行する。期待値を新しい金融成績へ転記せず、旧B側の全JSON対照へだけ使う。派生系はB0/B1/BE/Q0/Q1/QEの固定順である。

場間の可変金融状態は共有しない。保存公表の数値carryは既に106側で確定済み、107のC/M/P窓とBookは場ごとに新規なので最大4workerで独立実行する。結果は元manifest順へ戻し、完了順を損益連結順にしない。失敗を検出したら未着手の場は未実行として記録し、全体を不成功にする。残りの一部成功を全70成功へ補完しない。

各NativeはCore.Result＋condition_sha256/input_proof/replay_proof/provenance、完了には各native/旧sidecar refs/24冊/B側12と前後指紋を保存する。Header/Recordsを新たに複製しない。Source/Bank/Chart再形成falseとCMP公開再計算true、保存公表再用と新金融実行を区別する。

## 準備検査の範囲

当市場口の小ファイル試験はFileRef・実行中変更、gzip/余剰JSON/CRC/上書き拒否、RawMessageの未知field保持と12/12/4射影、自己・停止所有の包含不足を対象とする。経済値のない手製metadataであり、金融や市場の成功試験ではない。金融は停止Actor/Core/保存器の非0人工を別に参照し、市場の先頭2及び全70を別に確認する。

市場実行物のGo 1.24.2、選択依存ファイル、toolchain、コード/停止/実行物の実SHAは停止JSONと金融条件へ保存する。元106の停止・コード・正式結果は変更しない。
