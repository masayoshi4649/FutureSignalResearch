package main

import (
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"sync"
	"sync/atomic"
)

type Completion struct {
	Version            int               `json:"version"`
	Trial              int               `json:"trial"`
	Stage              string            `json:"stage"`
	Success            bool              `json:"success"`
	ConditionSHA       string            `json:"condition_sha256"`
	Sessions           int               `json:"sessions"`
	BooksPerScene      int               `json:"books_per_scene"`
	Books              int               `json:"books"`
	Results            []SceneResult     `json:"results"`
	Before             map[string]string `json:"before"`
	After              map[string]string `json:"after"`
	Unchanged          bool              `json:"unchanged"`
	First2             *FileRef          `json:"first2,omitempty"`
	InputMode          string            `json:"input_mode"`
	Workers            int               `json:"workers"`
	SourceReexecuted   bool              `json:"source_reexecuted"`
	FeaturesRecomputed bool              `json:"features_recomputed"`
	ChartsRecomputed   bool              `json:"charts_recomputed"`
	CMPRecomputed      bool              `json:"cmp_recomputed"`
	FinancialExecuted  bool              `json:"financial_executed"`
	Error              string            `json:"error,omitempty"`
}

// execute は固定後のfirst2又はfull70を一回だけ実行します。
//
// 引数: condition/conditionSHA/stage/first2/first2SHA/out(string)は明示した固定・段階・新規先です。
// 返り値: errorは段階・固定・配送・会計・前後指紋の不成立です。
func execute(condition, conditionSHA, stage, first2, first2SHA, out string) error {
	p, err := prepare(condition, conditionSHA)
	if err != nil {
		return err
	}
	if stage != "first2" && stage != "full70" {
		return fmt.Errorf("段階はfirst2/full70だけです")
	}
	var old Completion
	var firstRef *FileRef
	if stage == "full70" {
		path, e := checkRef(FileRef{first2, first2SHA}, p.Base, p.Before)
		if e != nil {
			return e
		}
		if e = readJSON(path, false, &old); e != nil {
			return e
		}
		if !old.Success || old.Stage != "first2" || old.Trial != 107 || old.ConditionSHA != conditionSHA || old.Sessions != 2 || old.Books != 48 || !old.Unchanged || !reflect.DeepEqual(old.Before, old.After) || len(old.Results) != 2 {
			return fmt.Errorf("同条件first2成功の固定不足")
		}
		firstRef = &FileRef{path, first2SHA}
	} else if first2 != "" || first2SHA != "" {
		return fmt.Errorf("first2段階へ旧段階を混入")
	}
	ids := []string{}
	for _, s := range p.Manifest.Sessions {
		ids = append(ids, s.ID)
	}
	if stage == "first2" {
		ids = ids[:2]
	}
	if firstRef != nil {
		for i, r := range old.Results {
			if r.Session != ids[i] || r.Error != "" || r.Books != 24 || r.BaseBooks != 12 {
				return fmt.Errorf("first2先頭集合差")
			}
		}
	}
	out, err = filepath.Abs(out)
	if err != nil {
		return err
	}
	if _, e := os.Stat(out); !os.IsNotExist(e) {
		return fmt.Errorf("出力先は未使用directoryが必要です")
	}
	if err = os.MkdirAll(out, 0755); err != nil {
		return err
	}
	done := Completion{Version: 1, Trial: 107, Stage: stage, ConditionSHA: conditionSHA, BooksPerScene: 24, Before: p.Before, First2: firstRef, InputMode: p.Condition.Mode, Workers: p.Condition.Workers, CMPRecomputed: true, FinancialExecuted: true}
	results := parallelScenes(p, ids, out)
	byID := map[string]SceneResult{}
	for _, r := range results {
		byID[r.Session] = r
	}
	for _, id := range ids {
		r, ok := byID[id]
		if !ok {
			r = SceneResult{Session: id, Error: "内部配送の結果欠落"}
		}
		done.Results = append(done.Results, r)
		if r.Error != "" {
			done.Error += id + ":" + r.Error + "\n"
		} else {
			done.Sessions++
			done.Books += r.Books
		}
	}
	if firstRef != nil {
		for i, r := range old.Results {
			if got := done.Results[i]; got.Error != "" || got.Native.SHA != r.Native.SHA {
				done.Error += "先頭2の同条件Native bytes差:" + r.Session + "\n"
			}
		}
	}
	done.After, err = recheck(p.Before)
	if err != nil {
		done.Error += err.Error() + "\n"
	}
	done.Unchanged = err == nil && reflect.DeepEqual(done.Before, done.After)
	done.Success = done.Error == "" && done.Sessions == len(ids) && done.Books == 24*len(ids) && done.Unchanged
	if _, err = writeJSON(filepath.Join(out, "完了.json"), done, false); err != nil {
		return err
	}
	if !done.Success {
		return fmt.Errorf("107保存公表の金融失敗:%s", done.Error)
	}
	fmt.Printf("107 %s 成功 %d場/%d会計\n", stage, done.Sessions, done.Books)
	return nil
}

// parallelScenes は固定保存列だけを最大4独立workerで再読します。
//
// 引数: p(Plan)、ids([]string)、out(string)は場集合と独立新規先です。
// 返り値: []SceneResultは完了順の結果です。集約側で元の時系列へ戻します。
func parallelScenes(p Plan, ids []string, out string) []SceneResult {
	jobs := make(chan string, len(ids))
	results := make(chan SceneResult, len(ids))
	for _, id := range ids {
		jobs <- id
	}
	close(jobs)
	var group sync.WaitGroup
	var failed atomic.Bool
	workers := p.Condition.Workers
	if workers > len(ids) {
		workers = len(ids)
	}
	for i := 0; i < workers; i++ {
		group.Add(1)
		go sceneWorker(p, out, jobs, results, &group, &failed)
	}
	go closeResults(&group, results)
	all := []SceneResult{}
	for r := range results {
		all = append(all, r)
		if r.Error == "" {
			fmt.Printf("107 %d/%d %s 24冊/B12\n", len(all), len(ids), r.Session)
		} else {
			fmt.Fprintf(os.Stderr, "107 %s 失敗:%s\n", r.Session, r.Error)
		}
	}
	return all
}

// sceneWorker は他workerのBookやSource状態を共有せず一場ずつ処理します。
//
// 引数: p(Plan)、out(string)、jobs/results(channel)、group(*sync.WaitGroup)は固定と独立仕事です。
// 返り値: なし。各場の結果をchannelへ一度送ります。
func sceneWorker(p Plan, out string, jobs <-chan string, results chan<- SceneResult, group *sync.WaitGroup, failed *atomic.Bool) {
	defer group.Done()
	for id := range jobs {
		if failed.Load() {
			results <- SceneResult{Session: id, Error: "他場失敗のため未実行"}
			continue
		}
		r := runScene(p, id, out)
		if r.Error != "" {
			failed.Store(true)
		}
		results <- r
	}
}

// closeResults は全worker終了後に結果channelを閉じます。
//
// 引数: group(*sync.WaitGroup)、results(chan SceneResult)は独立workerと結果先です。
// 返り値: なし。受信側は処理中にも進捗を取得できます。
func closeResults(group *sync.WaitGroup, results chan SceneResult) { group.Wait(); close(results) }

// main はRootが指紋指定した実行だけを受け付けます。
//
// 引数: コマンドラインのcondition/stage/first2/out。
// 返り値: なし。失敗は終了1、成功は終了0です。
func main() {
	condition := flag.String("condition", "", "107固定条件")
	sha := flag.String("condition-sha", "", "固定SHA256")
	stage := flag.String("stage", "", "first2/full70")
	first := flag.String("first2", "", "成功first2参照")
	firstSHA := flag.String("first2-sha", "", "成功first2 SHA")
	out := flag.String("out", "", "新規保存先")
	flag.Parse()
	if *condition == "" || *sha == "" || *out == "" {
		fmt.Fprintln(os.Stderr, "条件・SHA・新規先が必要です")
		os.Exit(1)
	}
	if err := execute(*condition, *sha, *stage, *first, *firstSHA, *out); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
