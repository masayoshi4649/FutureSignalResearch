"""107の成功停止・依存実物・市場前仕様を照合し、金融条件を一度だけ保存する。"""

import argparse
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / "study/00107_見送り明けの初回取得と利益保護"
OWN = ROOT / "work/107市場の入出力準備_埋込対応"


def sha(path: Path) -> str:
    """機能: ファイルのSHA256を計算する。

    引数: path(Path)はコード又は固定metadataの実物。
    返り値: strは小文字のSHA256。原板やCSVは指定しない。
    """
    return hashlib.file_digest(path.open("rb"), "sha256").hexdigest()


def read(path: Path) -> dict:
    """機能: UTF-8 JSONを読み込む。

    引数: path(Path)は保存済みmetadata。
    返り値: dictはJSONの全値。
    """
    return json.loads(path.read_text(encoding="utf-8"))


def write(path: Path, value: dict) -> None:
    """機能: JSONを既存物へ上書きせず保存する。

    引数: path(Path)は新規先、value(dict)は保存内容。
    返り値: None。既存の場合は例外を返す。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="\n") as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write("\n")


def ref(path: Path) -> dict:
    """機能: 絶対位置と実物指紋を結ぶ。

    引数: path(Path)は存在する固定ファイル。
    返り値: dictはpath/sha256。
    """
    return {"path": str(path.resolve()), "sha256": sha(path)}


def main() -> None:
    """機能: 107の市場実行前条件を固定する。

    引数: なし。ROOT以下の明示された停止・仕様だけを参照する。
    返り値: None。市場や金融処理は実行しない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate-sha", required=True)
    parser.add_argument("--binary-sha", required=True)
    args = parser.parse_args()
    candidate_path = ROOT / "work/107市場コードの閉包/埋込対応/Go閉包候補.json"
    candidate = read(candidate_path)
    assert sha(candidate_path) == args.candidate_sha
    assert candidate["成功"] and candidate["全選択code前後不変"]
    code = {}
    for item in candidate["files"] + candidate["Go5tool"]:
        path = Path(item["path"]).resolve()
        assert sha(path) == item["sha256"], str(path)
        code[str(path)] = item["sha256"]
    binary = OWN / "検査/見送り繰越.exe"
    assert sha(binary) == args.binary_sha
    peer = ROOT / "work/107市場外周のpeer確認/埋込対応確認.json"
    peer_value = read(peer)
    assert peer_value["成功"] and peer_value["阻害差"] == 0
    for name, want in peer_value["対象SHA256"].items():
        assert sha(ROOT / name) == want, name
    tests = [json.loads(line) for line in (OWN / "検査/最終テスト.jsonl").read_text(encoding="utf-8-sig").splitlines() if line.strip()]
    assert len([t for t in tests if t.get("Action") == "pass" and t.get("Test")]) == 4
    assert not any(t.get("Action") == "fail" for t in tests)
    own = {str((OWN / name).relative_to(ROOT)).replace("\\", "/"): sha(OWN / name)
           for name in ["io.go", "metadata.go", "case.go", "main.go", "io_test.go", "go.mod", "go.sum", "README.md"]}
    own_stop = OWN / "停止.json"
    write(own_stop, {"成功": True, "scope": "保存106公表から107を実行する市場外周の停止。市場結果は未実行", "所有コードSHA256": own,
                     "実行物": ref(binary), "Go依存とtoolchain": ref(candidate_path), "peer": ref(peer),
                     "検査": {"test_top": 4, "test_exit": 0, "vet_exit": 0, "build_exit": 0},
                     "原板CSV本文/市場金融実行": 0})
    stops = [ROOT / ("work/" + name + "/停止.json") for name in [
        "quietだけ繰り越す入口時計", "見送り繰越の保護会計", "107見送り繰越の市場接続準備",
        "107保存公表の再読口_埋込対応", "107見送り繰越の保存準備", "107市場の入出力準備_埋込対応"]]
    for stop in stops:
        value = read(stop)
        assert value["成功"]
        for name, want in {**value.get("再用コードと停止SHA256", {}), **value["所有コードSHA256"]}.items():
            path = (ROOT / name).resolve()
            assert sha(path) == want, str(path)
            if str(path) in code:
                assert code[str(path)] == want
            code[str(path)] = want
    code[str(Path(__file__).resolve())] = sha(Path(__file__))
    code[str(candidate_path)] = sha(candidate_path)
    for path in [ROOT / "work/107進行/埋込対応で市場を実行する.ps1",
                 ROOT / "work/107進行/全70の保存を実行する.py",
                 ROOT / "work/107市場コードの閉包/埋込対応を収集する.py"]:
        code[str(path)] = sha(path)
    specs = []
    for name in ["README.md", "設定と結果.md"]:
        dst = TRIAL / "市場前仕様" / name
        assert dst.is_file()
        specs.append(ref(dst))
    old = ROOT / "study/00106_収束失速で保護の起動と幅を切り替える"
    configs = [{"candidate": name, "entry_timing": timing, "protection_policy": policy, "slip_pts": cost, "delay_seconds": delay}
               for name, timing, policy in [("B0", "B5Q", "W0"), ("B1", "B5Q", "W1"), ("BE", "B5Q", "E1"), ("Q0", "B5QD", "W0"), ("Q1", "B5QD", "W1"), ("QE", "B5QD", "E1")]
               for cost in [0, 5] for delay in [0, 1]]
    condition = {"version": 1, "trial": 107, "fixed": True, "scope": "107見送り繰越と複数技法の利益保護。保存公表再用・全70既使用探索・24設定",
                 "input_mode": "recorded_public_106", "workers": 4, "own_module_dir": str(OWN),
                 "prior_closure": ref(old / "完了記録.json"), "input_manifest": ref(old / "入力台帳_70場.json"),
                 "source_corpus": ref(old / "Source台帳_70場.json"), "prior_completion": ref(ROOT / "work/106市場/全70場/完了.json"),
                 "binary": ref(binary), "stops": [ref(p) for p in stops], "specifications": specs,
                 "code_sha256": code, "configs": configs}
    condition["read_schema_fix"] = {"scope": "匿名埋込fieldをencoding/jsonと同じ平坦構造として読む。売買・数式・原入力不変", "failed_condition": ref(TRIAL / "金融条件.json"), "failed_completion": ref(ROOT / "work/107市場/先頭2場/完了.json")}
    target = TRIAL / "金融条件_埋込対応.json"
    write(target, condition)
    journal = {"試行": 107, "段階": "金融条件固定・市場未実行", "金融条件": ref(target), "実行物": ref(binary), "code数": len(code), "達成": False}
    (ROOT / "work/107進行/現在.json").write_text(json.dumps(journal, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(journal, ensure_ascii=False))


if __name__ == "__main__":
    main()
