"""107全70の金融成功だけを保存器へ渡し、正式成果物を生成する。"""

import hashlib
import json
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[2]


def ref(path: Path) -> dict:
    """機能: 保存済み実物の絶対位置と指紋を取得する。

    引数: path(Path)は条件・成功記録・保存コード。
    返り値: dictはpath/sha256。
    """
    with path.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"path": str(path.resolve()), "sha256": digest}


def main() -> None:
    """機能: 成功記録を確認して保存器を一度だけ実行する。

    引数: なし。107の明示された全70出力を参照する。
    返り値: None。金融再実行や原板の読取は行わない。
    """
    trial = ROOT / "study/00107_見送り明けの初回取得と利益保護"
    condition = trial / "金融条件_埋込対応.json"
    completion = ROOT / "work/107市場/埋込対応_全70場/完了.json"
    code = ROOT / "work/107見送り繰越の保存準備/集計.py"
    done = json.loads(completion.read_text(encoding="utf-8"))
    assert done["success"] and done["trial"] == 107 and done["stage"] == "full70"
    assert done["sessions"] == 70 and done["books"] == 1680 and done["unchanged"]
    assert done["before"] == done["after"]
    assert done["condition_sha256"] == ref(condition)["sha256"]
    assert ref(code)["sha256"] == "edbc322ba619d7c575f8c1baec66d1dfcb7f210dbf685fbae7a90f81a6eaea6d"
    fixed = {"version": 1, "trial": 107, "fixed": True, "stage": "full70", "condition": ref(condition), "completion": ref(completion), "code": ref(code)}
    fixed_path = trial / "保存条件.json"
    with fixed_path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(fixed, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    args = [sys.executable, "-B", "-X", "utf8", str(code), "--fixed", str(fixed_path), "--fixed-sha", ref(fixed_path)["sha256"], "--out", str(trial / "成果物")]
    print(json.dumps({"固定": ref(fixed_path), "argv": args}, ensure_ascii=False), flush=True)
    subprocess.run(args, cwd=ROOT, check=True)


if __name__ == "__main__":
    main()
