$ErrorActionPreference = 'Stop'
$conditionPath = 'study/00107_見送り明けの初回取得と利益保護/金融条件_埋込対応.json'
$conditionSHA = (Get-FileHash -LiteralPath $conditionPath -Algorithm SHA256).Hash.ToLowerInvariant()
$binaryPath = 'work/107市場の入出力準備_埋込対応/検査/見送り繰越.exe'
& $binaryPath --condition $conditionPath --condition-sha $conditionSHA --stage first2 --out 'work/107市場/埋込対応_先頭2場'
if ($LASTEXITCODE -ne 0) { throw '先頭2場に失敗したため全70場を実行しません。' }
$firstPath = 'work/107市場/埋込対応_先頭2場/完了.json'
$first = Get-Content -LiteralPath $firstPath -Raw -Encoding utf8 | ConvertFrom-Json
if (-not $first.success -or $first.sessions -ne 2 -or $first.books -ne 48 -or -not $first.unchanged) { throw '先頭2場の成功metadataが不成立です。' }
$firstSHA = (Get-FileHash -LiteralPath $firstPath -Algorithm SHA256).Hash.ToLowerInvariant()
& $binaryPath --condition $conditionPath --condition-sha $conditionSHA --stage full70 --out 'work/107市場/埋込対応_全70場' --first2 $firstPath --first2-sha $firstSHA
if ($LASTEXITCODE -ne 0) { throw '全70場の金融に失敗しました。' }
