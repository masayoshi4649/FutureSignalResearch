"""107の事前原文を保持し、固定保存集計だけを24評価の結果欄へ表示する。"""
from __future__ import annotations

import argparse
from decimal import Decimal
import hashlib
import importlib.util
import json
from pathlib import Path
import re

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
PREVIOUS = ROOT/'work/106報告の準備/報告を差し替える_実型対応.py'
PREVIOUS_SHA = '6ad47e55c07e3f37699e6f76f8618f9076a533a6104ad92ec4f7e81ba7aed89a'
SAVED_PATH = ROOT/'work/107見送り繰越の保存準備/集計.py'
SAVED_SHA = 'edbc322ba619d7c575f8c1baec66d1dfcb7f210dbf685fbae7a90f81a6eaea6d'
ORIGINAL_SHA = {'README.md': 'f7ad84677aa4a553fbd3ca6b1ae9579295f54615ec12728f47a479e32474bc4e',
                '設定と結果.md': '3e7ac70a96567ad3025dda16d743498f41447e18015993d58ca5c89b2add1d16'}


def sha(path: Path) -> str:
    """
    機能: 明示コード・小JSON・原文のSHA256を得る。
    引数: path (Path) は対象。
    返り値: str は内容指紋。Raw/Nativeを読まない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


assert sha(PREVIOUS) == PREVIOUS_SHA and sha(SAVED_PATH) == SAVED_SHA
spec = importlib.util.spec_from_file_location('107が再用する停止106報告', PREVIOUS)
OLD = importlib.util.module_from_spec(spec)
spec.loader.exec_module(OLD)
finite, amount, rate, table = OLD.finite, OLD.amount, OLD.rate, OLD.table
read_json, file_ref = OLD.read_json, OLD.file_ref
FIELDS, COMPS, GROUPS = OLD.FIELDS, OLD.COMPS, OLD.GROUPS
spec = importlib.util.spec_from_file_location('107報告が参照する停止保存', SAVED_PATH)
SAVED = importlib.util.module_from_spec(spec)
spec.loader.exec_module(SAVED)
KEYS = list(SAVED.KEYS)
CLOCK_FIELDS = ['出生', '静観繰越', '一回失効', '受理出生', '受理枚', '実取得出生', '実取得枚', '受理後0取得取消', '割当前の観測保留枠延べ']
BEGIN, END = '<!-- REPORT107:RESULT:BEGIN -->', '<!-- REPORT107:RESULT:END -->'


def validate_clock(t: dict, key: str) -> None:
    """
    機能: 保存済み時計集計の件数・和とB/Qの範囲を検査する。
    引数: t (dict)、key (str) は場別又は集約の本名。
    返り値: None。割当/採否や金融を再実行しない。
    """
    a = t['時計割当']
    assert set(a) == set(CLOCK_FIELDS)
    assert all(type(a[x]) is int and a[x] >= 0 for x in CLOCK_FIELDS)
    assert a['出生'] == a['一回失効'] + a['受理出生']
    assert a['実取得出生'] + a['受理後0取得取消'] == a['受理出生']
    assert a['受理枚'] >= a['実取得枚'] == t['entry_quantity']
    assert a['静観繰越'] <= a['出生']
    if key.startswith('B'):
        assert a['静観繰越'] == 0


def validate_result(r: dict, sessions: list[str], contracts: list[str]) -> None:
    """
    機能: 24集計/1680行・日夜履歴・時計9欄・36比較・B12対照を照合する。
    引数: r (dict)、sessions/contracts (list[str]) は小集計と固定metadata。
    返り値: None。旧106算術検査は本名を替えず直接再用する。
    """
    assert r['試行'] == 107 and r['成功'] is True and r['stage'] == 'full70' and r['場数'] == 70 and r['会計数'] == 1680
    assert len(sessions) == len(set(sessions)) == 70 and len({s[:10] for s in sessions}) == 35
    assert set(r['集計']) == set(KEYS) and r['前後不変'] is True and r['入力codeSHA256前'] == r['入力codeSHA256後']
    rows = {(x['session'], x['key']): x for x in r['場別']}
    assert len(rows) == len(r['場別']) == 1680 and set(rows) == {(s,k) for s in sessions for k in KEYS}
    for key in KEYS:
        t = r['集計'][key]
        OLD.validate_row(t, 7840, 7560)
        validate_clock(t, key)
        for field in FIELDS:
            assert sum(rows[s,key][field] for s in sessions) == t[field]
        for field in CLOCK_FIELDS:
            assert sum(rows[s,key]['時計割当'][field] for s in sessions) == t['時計割当'][field]
        for s in sessions:
            row = rows[s,key]
            OLD.validate_row(row, 76 if s.endswith('_Day') else 148, 72 if s.endswith('_Day') else 144, scene=True)
            validate_clock(row, key)
            cfg = SAVED.BY_KEY[key]
            assert row['entry_timing'] == cfg['entry_timing'] and row['width_policy'] == cfg['protection_policy'] and row['history_class'] in GROUPS
        diagnosis = r['実現診断'][key]
        for kind,n in [('Day',2660),('Night',5180)]:
            OLD.validate_row(diagnosis['日夜'][kind],n)
            validate_clock(diagnosis['日夜'][kind],key)
        assert sum(x['net_yen'] for x in diagnosis['日夜'].values()) == t['net_yen']
        assert len(diagnosis['日別']) == 35 and {x['開始日'] for x in diagnosis['日別']} == {s[:10] for s in sessions}
        assert sum(x['net_yen'] for x in diagnosis['日別']) == t['net_yen']
        assert set(diagnosis['履歴区分']) == set(GROUPS)
        for group,(_,count,denom) in GROUPS.items():
            selected = [rows[s,key] for s in sessions if rows[s,key]['history_class'] == group]
            assert len(selected) == count
            OLD.validate_row(diagnosis['履歴区分'][group],denom)
            validate_clock(diagnosis['履歴区分'][group],key)
            assert sum(x['net_yen'] for x in selected) == diagnosis['履歴区分'][group]['net_yen']
        if not key.startswith(('BE_','QE_')):
            assert t['early_warning_activations'] == 0
        if key.startswith(('B0_','Q0_')):
            assert t['narrowed_positions'] == 0
    pairs = {after+'対'+before:(before,after,kind) for before,after,kind in SAVED.comparison_pairs()}
    assert len(pairs) == 36 and set(r['同実入口と実現額差']) == set(pairs)
    assert (r['比較数'],r['時計差比較'],r['同時計内保護比較']) == (36,12,24)
    for name,(before,after,kind) in pairs.items():
        c = r['同実入口と実現額差'][name]
        t = c['合計']
        assert c['区分'] == kind and len(c['場別']) == 70 and {x['session'] for x in c['場別']} == set(sessions)
        assert t['全差額'] == r['集計'][after]['net_yen']-r['集計'][before]['net_yen'] == t['同実入口差額']+t['取得変更差額']-t['前のみ実現額']+t['後のみ実現額']
        assert all(sum(x[f] for x in c['場別']) == t[f] for f in COMPS)
    controls = r['B側旧106全文対照']
    assert len(controls) == 70 and {x['session'] for x in controls} == set(sessions)
    for x in controls:
        assert (x['kind'],x['history_class'],x['books'],x['width_audits'],x['early_audits'],x['all'],x['excluded'],x['all_point_comparisons']) == ('provided_old106','old_saved_70',12,12,4,True,[],0)
        assert x['保存側で旧106実物を再照合'] is True
    public = r['一公表単位の役割診断']
    assert len(public) == 70 and {x['session'] for x in public} == set(sessions)
    by_id = {x['session']:x for x in public}
    for i,s in enumerate(sessions):
        x = by_id[s]
        assert x['numeric_seed_carried'] is (i>0 and contracts[i]==contracts[i-1])
        assert 0 <= x['C_pass'] <= x['C_known'] <= x['new_three']
        for side in ('buy','sell'):
            assert all(0 <= x[side][p+'_pass'] <= x[side][p+'_known'] <= x['new_three'] for p in ('M','P'))


def prepare(path: Path, expected: str) -> tuple[dict,dict,dict]:
    """
    機能: 全70成功後の5FileRefからだけ実集約を開封する。
    引数: path (Path)、expected (str) はRoot事後固定と明示SHA。
    返り値: tuple[dict,dict,dict] は小集計・入力指紋・Viewer範囲。Native/Record本文を読まない。
    """
    assert sha(path) == expected
    f = read_json(path)
    assert f['version'] == 1 and f['trial'] == 107 and f['fixed'] is True and f['result_ready'] is True
    before = {str(path.resolve()):expected,str(PREVIOUS):PREVIOUS_SHA,str(SAVED_PATH):SAVED_SHA,str(Path(__file__).resolve()):sha(Path(__file__))}
    files = {k:file_ref(f[k],path.resolve().parent,before) for k in ('summary','saved_check','financial_completion','condition','prior_completion')}
    r,checked,done,condition,prior = [read_json(files[k]) for k in ('summary','saved_check','financial_completion','condition','prior_completion')]
    assert r['codeSHA256'] == checked['codeSHA256'] == SAVED_SHA
    assert r['completionSHA256'] == checked['completionSHA256'] == sha(files['financial_completion'])
    assert r['conditionSHA256'] == checked['conditionSHA256'] == done['condition_sha256'] == sha(files['condition'])
    assert checked['成功'] is True and checked['会計'] == checked['資源'] == 1680 and checked['不一致数'] == 0 and checked['前後不変'] is True
    assert checked['出力SHA256']['結果.json'] == sha(files['summary']) and checked['入力codeSHA256前'] == checked['入力codeSHA256後']
    assert done['success'] is True and done['trial'] == 107 and done['stage'] == 'full70' and done['sessions'] == 70 and done['books_per_scene'] == 24 and done['books'] == 1680 and len(done['results']) == 70
    assert done['unchanged'] is True and done['before'] == done['after'] and done['input_mode'] == 'recorded_public_106'
    assert done['source_reexecuted'] is False and done['features_recomputed'] is False and done['charts_recomputed'] is False and done['cmp_recomputed'] is True and done['financial_executed'] is True
    assert condition['trial'] == 107 and condition['fixed'] is True and condition['configs'] == SAVED.CONFIGS
    prior_path = file_ref(condition['prior_completion'],files['condition'].parent,before)
    assert prior_path == files['prior_completion']
    assert prior['trial'] == 106 and prior['stage'] == 'full70' and prior['success'] is True and prior['sessions'] == 70 and prior['books'] == 1400 and prior['unchanged'] is True and prior['before'] == prior['after']
    manifest = read_json(file_ref(condition['input_manifest'],files['condition'].parent,before))
    closed = read_json(file_ref(condition['prior_closure'],files['condition'].parent,before))
    assert closed['試行'] == 106 and closed['試行完了'] is True
    sessions = [x['id'] for x in manifest['sessions']]
    assert [x['session'] for x in done['results']] == [x['session'] for x in prior['results']] == sessions
    assert all(x['books'] == 24 and x['base_control_books'] == 12 and not x.get('error') for x in done['results'])
    assert r['Native参照'] == [{k:x[k] for k in ('session','native','sidecar_header','sidecar_records')} for x in done['results']]
    validate_result(r,sessions,[x['contract'] for x in manifest['sessions']])
    viewer = {'確認':False,'scope':'実Viewer未確認。保存形式と実HTTPは別証拠'}
    if 'viewer_evidence' in f:
        p = file_ref(f['viewer_evidence'],path.parent,before)
        v = read_json(p)
        assert v['成功'] is True and isinstance(v['scope'],str) and v['scope'].strip()
        viewer = {'確認':True,'scope':v['scope'],'SHA256':sha(p)}
    assert all(sha(Path(p)) == h for p,h in before.items())
    return r,before,viewer


def main_summary(r: dict | None) -> str:
    """
    機能: 全24の純額と全体/夜間の参加未達を別の件数で示す。
    引数: r (dict|None) は検査済み小集計又は未検証。
    返り値: str は採用を断定しない主要事実。
    """
    if r is None:
        return '純額・最低25%・目標50%・日夜の結論は未検証。'
    positive = sum(r['集計'][k]['net_yen']>0 for k in KEYS)
    below = [k for k in KEYS if 4*r['集計'][k]['活動主表']['active']<7840]
    target = sum(2*r['集計'][k]['活動主表']['active']<7840 for k in KEYS)
    night = sum(4*r['実現診断'][k]['日夜']['Night']['活動主表']['active']<5180 for k in KEYS)
    return f'純額黒字は{positive}/24、全体最低25%未達は{len(below)}/24（'+('、'.join(below) if below else 'なし')+f'）。全体目標50%未達は{target}/24、夜間単独最低25%未達は{night}/24。黒字・参加条件・未見安定性・採用は別に判断する。'


def result_block(r: dict | None, viewer: dict) -> str:
    """
    機能: 実名24の粗純・二旗・時計・参加・36比較を表示する。
    引数: r (dict|None)、viewer (dict) は小集計又は未検証と表示確認範囲。
    返り値: str は結果欄。機会損失や未参加仮想利益を作らない。
    """
    get = lambda k,f: r['集計'][k][f] if r else None
    rows = [[f'R{i+1:02d} {k}']+[amount(get(k,f)) for f in ('gross_yen','fee_yen','slip_yen','net_yen','positive_yen','negative_yen')]+['未検証' if r is None else '未定義（負額0）' if r['集計'][k]['PF'] is None else f'{finite(r["集計"][k]["PF"]):.4f}',amount(get(k,'保存点連結時価DD')),f'{amount(get(k,"positions"))}/{amount(get(k,"entry_quantity"))}'] for i,k in enumerate(KEYS)]
    lines = [BEGIN,'## 107の結果欄','', '**未検証/null。市場実績は未取込。**' if r is None else '全70/1680会計の保存集計を条件・金融・旧106完了へ指紋結合した。試行保存成功と採用/目標達成/未見安定性を分ける。','',main_summary(r),'',
             table(['評価/外Key','粗額円','fee円','仮定slip円','純額円','全正額円','全負額円','PF','保存点DD円','玉/枚'],rows),'',
             '### 利益保護の二旗・通常/早期/狭幅','',
             table(['Key','u正益玉','u後赤字玉/円','u未観測赤字円','起動玉','起動後赤字玉/円','通常/早期','狭幅'],[[k,amount(get(k,'unit_positive_positions')),f'{amount(get(k,"unit_positive_closed_negative"))}/{amount(get(k,"unit_positive_closed_negative_yen"))}',amount(get(k,'unit_unobserved_closed_negative_yen')),amount(get(k,'protection_activated_positions')),f'{amount(get(k,"activated_closed_negative"))}/{amount(get(k,"activated_closed_negative_yen"))}',f'{amount(get(k,"normal_ld10_activations"))}/{amount(get(k,"early_warning_activations"))}',amount(get(k,'narrowed_positions'))] for k in KEYS]),'',
             'u>0とLD10/E1の起動は別分母。名目建値床と実Fillは別で、起動後赤字0を保証しない。全負額・DD・純額も別の評価である。','',
             '### 一出生の時計割当','',table(['Key']+CLOCK_FIELDS,[[k]+[amount(r['集計'][k]['時計割当'][f] if r else None) for f in CLOCK_FIELDS] for k in KEYS]),'',
             '静観繰越は割当変更であり受理や実取得ではない。割当前の観測保留枠延べを参加/保有へ数えない。受理後0取得取消でも同出生を再要求しない。','',
             '### 日夜と主副参加','']
    rows = []
    for k in KEYS:
        t = r['集計'][k] if r else None
        day,night = [r['実現診断'][k]['日夜'][kind] if r else None for kind in ('Day','Night')]
        flags = '未検証' if t is None else ('達成' if 4*t['活動主表']['active']>=7840 else '未達')+'/'+('達成' if 2*t['活動主表']['active']>=7840 else '未達')
        rows.append([k,amount(day['net_yen'] if day else None),rate(day['活動主表']['active'] if day else None,2660),amount(night['net_yen'] if night else None),rate(night['活動主表']['active'] if night else None,5180),rate(t['活動主表']['active'] if t else None,7840),rate(t['活動副表']['active'] if t else None,7560),flags])
    lines += [table(['Key','日中純額円','日中率/2660','夜間純額円','夜間率/5180','主率/7840','副率/7560','全体25/50'],rows),'',
              '全体最低25%・目標50%と、日中/夜間の最低25%を別に記録。欠測/USquietを分母から落とさず、主参加は同枠実取得又は当時実保有の和集合。','',
              '### 旧54・105四・追加12と日別','',table(['Key']+[x[0]+'純額円' for x in GROUPS.values()],[[k]+[amount(r['実現診断'][k]['履歴区分'][g]['net_yen'] if r else None) for g in GROUPS] for k in KEYS]),'',
              '70セッション・35開始日は全て既使用探索。24政策費用や玉数を独立市場例へ増やさない。日別35の合計も全体へ照合し、内訳は保存正本を参照する。','',
              '### 一公表単位のC/M/P診断とcold/carry','']
    diagnostics = r['一公表単位の役割診断'] if r else None
    n = sum(x['new_three'] for x in diagnostics) if diagnostics else None
    role_rows = []
    for side,p in [('','C'),('buy','M'),('buy','P'),('sell','M'),('sell','P')]:
        known = sum((x[side][p+'_known'] if side else x['C_known']) for x in diagnostics) if diagnostics else None
        passed = sum((x[side][p+'_pass'] if side else x['C_pass']) for x in diagnostics) if diagnostics else None
        role_rows.append([side+'/'+p if side else p,amount(n),amount(known),rate(known,n),amount(passed)])
    lines += [table(['役割','新3分公表母数','既知','既知率','成立'],role_rows),'',
              ('carry '+str(sum(x['numeric_seed_carried'] for x in diagnostics))+'場、cold/roll '+str(sum(not x['numeric_seed_carried'] for x in diagnostics))+'場。' if diagnostics else 'cold/carryの実績は未検証。')+' 保存済み因果公表の再用でBank/Source再形成なし、CMP再評価を区別する。公表を24冊分重複加算せず、Pは今回の追加選別未使用で診断のみ。','',
              '### 時計12比較と同時計保護24比較','']
    for kind,label in [('時計','時計差12'),('同時計保護','同時計内保護差24')]:
        rows = []
        for before,after,k in SAVED.comparison_pairs():
            if k == kind:
                name = after+'対'+before
                t = r['同実入口と実現額差'][name]['合計'] if r else None
                rows.append([name]+[amount(t[f] if t else None) for f in COMPS])
        lines += ['#### '+label,'',table(['比較']+COMPS,rows),'']
    lines += ['全差額＝同実入口差額＋取得変更差額−前のみ実現額＋後のみ実現額。実Source全文と要求/実取得の属性が一致する入口だけを同実入口とし、片側だけの実額を仮想利益と呼ばない。時計と保護の差を分け、C/M単独の因果へ帰属しない。C5/D1は動的別運転。','',
              'B側12冊/場は106のW0/W1/E1各4冊と最終全JSON・幅12/早期4の除外0照合対象。'+('全70保存側の実物再照合を確認。' if r else '対照実績は未検証。')+'全市場原行の別engine照合又はQ側の旧同値とはしない。','',
              'Viewer確認：'+viewer['scope']+'。代表確認を全件表示へ拡張しない。機会損失、退出後価格、MFE回収率、未参加仮想約定、元手未指定ROIは算出しない。採用・研究目標・未使用期間安定性は未証明。',END,'']
    return '\n'.join(lines)


def render(r: dict | None, viewer: dict) -> tuple[dict[str,bytes],dict]:
    """
    機能: 原文bytesを別保存し、55×9/S13K12と24評価の結果欄だけを更新する。
    引数: r (dict|None)、viewer (dict) は検査済み小集計又は未検証。
    返り値: tuple[dict,dict] は出力bytesと原計画指紋。
    """
    originals = {n:(WORK/'原文'/n).read_bytes() for n in ORIGINAL_SHA}
    assert all(hashlib.sha256(b).hexdigest()==ORIGINAL_SHA[n] for n,b in originals.items())
    readme,settings = [originals[n].decode('utf-8-sig') for n in ('README.md','設定と結果.md')]
    before = settings
    assert BEGIN not in readme and BEGIN not in settings
    if r:
        lines = settings.splitlines()
        header = next(x for x in lines if x.startswith('| 評価ID |')).split('|')[1:-1]
        names = [x.strip() for x in header]
        for i,k in enumerate(KEYS):
            rid = f'R{i+1:02d}'
            found = [j for j,x in enumerate(lines) if x.startswith('| '+rid+' |')]
            assert len(found)==1
            parts = lines[found[0]].split('|')
            t = r['集計'][k]
            for name,value in [('純額',amount(t['net_yen'])+'円'),('主参加/7840',rate(t['活動主表']['active'],7840)),('副参加/7560',rate(t['活動副表']['active'],7560)),('状態','full70金融/保存確認済み')]:
                parts[names.index(name)+1] = ' '+value+' '
            lines[found[0]] = '|'.join(parts)
        settings = '\n'.join(lines)+'\n'
    catalog = lambda t:[x for x in t.splitlines() if re.match(r'^\| (?:I|C|P|V|B|X|M|E)\d{2} \|',x)]
    assert catalog(before)==catalog(settings) and len(catalog(settings))==55 and all(len(x.split('|'))-2==11 for x in catalog(settings))
    for letter,count in [('S',13),('K',12),('R',24)]:
        a = [x for x in before.splitlines() if re.match(r'^\| '+letter+r'\d{2} \|',x)]
        b = [x for x in settings.splitlines() if re.match(r'^\| '+letter+r'\d{2} \|',x)]
        assert len(a)==len(b)==count
        if letter!='R': assert a==b
    prefix = '<!-- REPORT107:STATUS:BEGIN -->\n**'+('未検証/nullの報告準備。' if r is None else '全70保存小集計の報告。採用・目標達成とは別。')+'**\n原計画の同bytesは原計画/へ保存し、旧予定は保存時点の記録として保持する。\n<!-- REPORT107:STATUS:END -->\n\n'
    block = result_block(r,viewer)
    out = {'README.md':(prefix+block+'\n<details>\n<summary>保存時の原計画</summary>\n\n'+readme+'\n</details>\n').encode('utf-8'),
           '設定と結果.md':(prefix+settings+'\n'+block).encode('utf-8')}
    out.update({'原計画/'+n:b for n,b in originals.items()})
    return out,ORIGINAL_SHA


def main() -> None:
    """
    機能: 未検証草案又はRoot成功固定後の報告を新規先だけへ生成/checkする。
    引数: CLI out/fixed/fixed-sha (Path/str)、check (bool) は出力先と固定参照。
    返り値: None。正式文書・xlsx・金融を変更又は実行しない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--fixed',type=Path)
    parser.add_argument('--fixed-sha')
    parser.add_argument('--check',action='store_true')
    args = parser.parse_args()
    assert (args.fixed is None)==(args.fixed_sha is None)
    r,inputs,viewer = prepare(args.fixed,args.fixed_sha) if args.fixed else (None,{}, {'scope':'実Viewer未確認'})
    out,plans = render(r,viewer)
    projection = {'試行':107,'状態':'未検証/null' if r is None else '全70保存集計の表示','実績未取込':r is None,'計画':{'場数':70,'開始日':35,'会計':1680,'主分母':7840,'副分母':7560},
                  '集計':{k:{f:None if r is None else r['集計'][k][f] for f in FIELDS+['時計割当','活動主表','活動副表']} for k in KEYS},
                  '比較36':{after+'対'+before:None if r is None else r['同実入口と実現額差'][after+'対'+before]['合計'] for before,after,_ in SAVED.comparison_pairs()},'機会損失/退出後仮想利益':'未算出'}
    out['結果欄の値.json'] = (json.dumps(projection,ensure_ascii=False,indent=2,default=str)+'\n').encode('utf-8')
    if args.check:
        assert args.out.is_dir() and all((args.out/n).read_bytes()==b for n,b in out.items())
    else:
        args.out.mkdir(parents=True,exist_ok=False)
        for n,b in out.items():
            p = args.out/n
            p.parent.mkdir(parents=True,exist_ok=True)
            with p.open('xb') as f: f.write(b)
    assert all(sha(Path(p))==h for p,h in inputs.items())
    print(json.dumps({'成功':True,'scope':'未検証草案' if r is None else '全70保存小集計の報告','check':args.check,'codeSHA256':sha(Path(__file__)),'入力SHA256':inputs,'原計画SHA256':plans,'55x9/S13K12/R24保持':True,'正式編集/Native/Raw/Source/金融/API/xlsx':0},ensure_ascii=False))


if __name__=='__main__':
    main()
