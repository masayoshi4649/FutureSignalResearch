"""107報告の未検証表示と停止保存APIの144手製集約型を検査する。"""
from __future__ import annotations

from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

WORK = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('report107',WORK/'報告を差し替える.py')
R = importlib.util.module_from_spec(spec)
spec.loader.exec_module(R)


class Tests(unittest.TestCase):
    """人工を市場全70の成績へ偽装せず、実保存と表示の型だけを結ぶ。"""

    def test_draft_and_plan(self) -> None:
        """
        機能: 未検証/null表示と55×9/S13K12/R24・原bytes保存を確認する。
        引数: self (Tests) は検査器。
        返り値: None。正式文書へ生成しない。
        """
        out,_ = R.render(None,{'scope':'未確認'})
        text = out['README.md'].decode('utf-8')
        self.assertIn('未検証/null',text)
        self.assertIn('R24 QE_C5_D1',text)
        self.assertIn('同時計内保護差24',text)
        for name in R.ORIGINAL_SHA:
            self.assertEqual(out['原計画/'+name],(WORK/'原文'/name).read_bytes())

    def test_actual_api_types_144(self) -> None:
        """
        機能: 6手製場×24の場別counts・集約率・時計9欄・36比較の型へ接続する。
        引数: self (Tests) は検査器。
        返り値: None。短縮人工の分母を76/148や70場へ水増ししない。
        """
        paths = sorted((WORK/'人工入力').glob('*.json'))
        self.assertEqual(len(paths),6)
        count = 0
        for path in paths:
            source_sha = R.sha(path)
            v = R.read_json(path)
            self.assertEqual(v['stage'],'artificial')
            self.assertFalse(v['市場実績'])
            self.assertEqual(set(v['集計']),set(R.KEYS))
            self.assertEqual(len(v['場別']),24)
            for row in v['場別']:
                # ----------------------------------------
                # 人工の明示された短い場の分母をそのまま使い、場別に率を発明しない。
                self.assertNotIn('参加率',row['活動主表'])
                R.OLD.validate_row(row,row['活動主表']['denom'],row['活動副表']['denom'],scene=True)
                R.validate_clock(row,row['key'])
                t = v['集計'][row['key']]
                R.OLD.validate_row(t,t['活動主表']['denom'],t['活動副表']['denom'])
                R.validate_clock(t,row['key'])
                count += 1
            expected = {after+'対'+before:kind for before,after,kind in R.SAVED.comparison_pairs()}
            self.assertEqual(set(v['同実入口と実現額差']),set(expected))
            for name,c in v['同実入口と実現額差'].items():
                self.assertEqual(c['区分'],expected[name])
                t = c['合計']
                after,before = name.split('対')
                self.assertEqual(t['全差額'],v['集計'][after]['net_yen']-v['集計'][before]['net_yen'])
                self.assertEqual(t['全差額'],t['同実入口差額']+t['取得変更差額']-t['前のみ実現額']+t['後のみ実現額'])
            with self.assertRaises(AssertionError):
                R.validate_result(v,[],[])
            self.assertEqual(R.sha(path),source_sha)
        self.assertEqual(count,144)

    def test_missing_and_corrupt_types(self) -> None:
        """
        機能: 集約率欠落・場別和・時計の破損を0補完せず拒否する。
        引数: self (Tests) は検査器。
        返り値: None。
        """
        v = R.read_json(next((WORK/'人工入力').glob('*.json')))
        key = R.KEYS[0]
        t = deepcopy(v['集計'][key])
        del t['活動主表']['参加率']
        with self.assertRaises(KeyError):
            R.OLD.validate_row(t,t['活動主表']['denom'],t['活動副表']['denom'])
        row = deepcopy(v['場別'][0])
        row['活動主表']['active'] += 1
        with self.assertRaises(AssertionError):
            R.OLD.validate_row(row,row['活動主表']['denom'],row['活動副表']['denom'],scene=True)
        t = deepcopy(v['集計'][key])
        t['時計割当']['静観繰越'] += 1
        with self.assertRaises(AssertionError):
            R.validate_clock(t,key)

    def test_not_ready(self) -> None:
        """
        機能: 市場成功のRoot開封固定前に結果FileRefを読まないことを確認する。
        引数: self (Tests) は検査器。
        返り値: None。
        """
        with tempfile.TemporaryDirectory() as d:
            p = Path(d)/'未固定.json'
            p.write_text(json.dumps({'version':1,'trial':107,'fixed':True,'result_ready':False,'summary':{'path':'存在しない未読結果','sha256':'a'*64}}),encoding='utf-8')
            with self.assertRaises(AssertionError):
                R.prepare(p,R.sha(p))


if __name__=='__main__':
    unittest.main()
