# 107報告の準備

停止106実型対応報告 `6ad47e55…` の算術・場別counts/集約率・金額整形をSHA再用し、107保存 `edbc322b…` の本名24口座・時計9欄・36比較へつなぐ。金融・Source・Bank・公開チャート・割当の計算は実行しない。

原文は市場前の正式107 README `f7ad8467…`、設定 `3e7ac70a…` を同bytesで保存した。55×9の495セル、S13/K12/R24を保持し、実結果許可後もRの純額/主副参加/状態とREPORT107結果欄だけを生成する。原計画2本は`原計画/`へ同bytes出力する。元Source S01〜10、C/Mの適用、P診断のみの意味は変更しない。

Root事後固定は`実結果の固定雛形.json`を参考に、`version:1/trial:107/fixed:true/result_ready:true`と5FileRefを新規作成する。必須はsummary（保存結果）、saved_check、financial_completion（107全70）、condition（107金融条件）、prior_completion（106全70）。Ref基準はそのJSONのparent、絶対pathも可。conditionのmanifest/旧閉鎖も結び、全70/1680、旧106の全70、24設定/1680行/35日、B12/audit・保存確認・前後指紋を確認する。optional `viewer_evidence`は成功scopeをそのまま表示し、代表APIを全件表示へ拡張しない。

```powershell
work/venvs/technical-tree/Scripts/python.exe -B -X utf8 `
  work/107報告の準備/報告を差し替える.py `
  --out <新規dir> --fixed <Root事後固定.json> --fixed-sha <そのSHA>
work/venvs/technical-tree/Scripts/python.exe -B -X utf8 `
  work/107報告の準備/報告を差し替える.py `
  --out <同dir> --fixed <同fixed> --fixed-sha <同SHA> --check
```

`--fixed`なしは未検証/null草案だけ。正式文書へ自動copyせず、xlsx/marker/APIは操作しない。生成物の相対リンクは正式107への配置基準である。

表示は粗純/全正負/PF/DD/玉枚、u正益後と起動後赤字、通常/早期/狭幅、時計の出生・繰越・失効・受理/実取得・0取得取消・保留枠延べ、日夜と主7840/副7560、旧54/105四/追加12、役割公表母数、時計差12と同時計内保護差24を含む。保留/受理を実参加へ数えず、片側実額を機会損失や仮想利益へ変えない。全て既使用で、24政策費用を市場標本へ水増ししない。

人工型は保存担当の6手製ケース×24を参照し、実保存APIのcounts-only場別/率を持つ集約/時計9欄/36比較に接続する。主分母6等の短い人工を76/148や全70へ延長しない。全70/1680の実結果接続はRoot成功後まで未検証。市場/Raw/Native/Source/金融/実Viewer/xlsx/正式文書編集0。
