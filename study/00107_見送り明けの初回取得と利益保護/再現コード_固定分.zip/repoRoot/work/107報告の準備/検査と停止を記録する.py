"""107報告prototypeの未検証草案と144人工型の検査だけを停止する。"""
from __future__ import annotations

import json
from pathlib import Path
import subprocess
import sys
import hashlib

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]


def sha(path: Path) -> str:
    """
    機能: コード・型人工・原文の内容指紋を得る。
    引数: path (Path) は明示した小ファイル。
    返り値: str はSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 人工型検査と未検証草案の生成/checkを記録して停止する。
    引数: なし。
    返り値: None。市場結果・Native・Raw・正式文書は読み書き又は実行しない。
    """
    dependencies = [ROOT/'work/106報告の準備/報告を差し替える_実型対応.py', ROOT/'work/106報告の準備/実型対応の停止.json',
                    ROOT/'work/107見送り繰越の保存準備/集計.py', ROOT/'work/107見送り繰越の保存準備/停止.json',
                    ROOT/'work/107見送り繰越の市場接続準備/停止.json', ROOT/'work/見送り繰越の保護会計/停止.json']
    dependencies += list((WORK/'原文').glob('*.md')) + list((WORK/'人工入力').glob('*.json'))
    before = {str(p):sha(p) for p in dependencies}
    logs = WORK/'検査'
    logs.mkdir(exist_ok=False)
    draft = WORK/'草案_最終'
    assert not draft.exists() and not (WORK/'停止.json').exists()
    base = [sys.executable,'-B','-X','utf8']
    commands = [('人工型',base+[str(WORK/'人工を確認する.py'),'-v']),
                ('草案生成',base+[str(WORK/'報告を差し替える.py'),'--out',str(draft)]),
                ('草案照合',base+[str(WORK/'報告を差し替える.py'),'--out',str(draft),'--check'])]
    records = []
    for name,argv in commands:
        p = subprocess.run(argv,capture_output=True,text=True,encoding='utf-8')
        (logs/(name+'.stdout.txt')).write_text(p.stdout,encoding='utf-8')
        (logs/(name+'.stderr.txt')).write_text(p.stderr,encoding='utf-8')
        assert p.returncode==0,p.stderr
        records.append({'検査':name,'argv':argv,'終了値':p.returncode})
    out = json.loads((draft/'結果欄の値.json').read_text(encoding='utf-8'))
    assert out['実績未取込'] is True and len(out['集計'])==24 and len(out['比較36'])==36
    assert all(x is None for t in out['集計'].values() for x in t.values()) and all(x is None for x in out['比較36'].values())
    assert all((draft/'原計画'/n).read_bytes()==(WORK/'原文'/n).read_bytes() for n in ('README.md','設定と結果.md'))
    assert all(sha(Path(p))==h for p,h in before.items())
    own = ['報告を差し替える.py','人工を確認する.py','検査と停止を記録する.py','README.md','実結果の固定雛形.json','人工型の由来.json']
    value = {'成功':True,'scope':'107報告の非市場prototype。未検証/null草案と停止保存API144手製型の接続だけ',
             '所有コードSHA256':{(WORK/n).relative_to(ROOT).as_posix():sha(WORK/n) for n in own},
             '入力SHA256前':before,'入力SHA256後':before,'前後不変':True,'検査':records,
             '確認':{'版':5,'手法行':55,'尺度':9,'S':13,'K':12,'R':24,'原計画同bytes':True,'人工型':144,'比較の型':36,'場別率必須':False,'集約率必須':True,'短縮人工分母維持':True,'人工の市場偽装6拒否':True,'破損と未開封拒否':4},
             '草案出力SHA256':{p.relative_to(ROOT).as_posix():sha(p) for p in sorted(draft.rglob('*')) if p.is_file()},
             'Root固定schema':'version1/trial107/fixedtrue/result_readytrue＋summary/saved_check/financial_completion/condition/prior_completionの5FileRef、optional viewer_evidence',
             '市場/Raw/Native/Source/金融/API/xlsx/正式文書編集':0,
             '未実証':['107全70/1680市場成績の開封と実報告','Root実成功の5FileRef結合','実Viewer/全表示','採用/研究目標/未見安定性']}
    p = WORK/'停止.json'
    p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'停止SHA256':sha(p),'報告コードSHA256':sha(WORK/'報告を差し替える.py'),'人工型':144,'草案check':True},ensure_ascii=False))


if __name__=='__main__':
    main()
