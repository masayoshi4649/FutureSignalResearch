"""107市場CLIの実選択Go依存とtoolchainをmetadataだけで収集する。"""

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import subprocess


ROOT = Path(__file__).resolve().parents[2]
TARGET = ROOT / "work/107市場の入出力準備_埋込対応"
FIELDS = ("GoFiles", "CgoFiles", "CFiles", "CXXFiles", "MFiles", "HFiles", "FFiles", "SFiles", "SwigFiles", "SwigCXXFiles", "SysoFiles", "EmbedFiles")
ENV_KEYS = ("GOVERSION", "GOROOT", "GOTOOLDIR", "GOOS", "GOARCH", "GOAMD64", "CGO_ENABLED", "GOMOD", "GOMODCACHE", "GOWORK", "GOTOOLCHAIN")


def sha(path):
    """
    機能: 明示されたcode/tool/小metadataをstreamで指紋化する。
    引数: path(Path)は実解決ファイル。
    返り値: strはSHA256。市場データを探索しない。
    """
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write(path, value):
    """
    機能: UTF-8 JSONを新規保存する。
    引数: path(Path)、value(dict)は保存先と値。
    返り値: None。既存候補/停止を上書きしない。
    """
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def command(args, output, name):
    """
    機能: buildしないGo metadata命令を実CLI位置で実行する。
    引数: args(list[str])、output(Path)、name(str)は命令と証拠先。
    返り値: bytesはstdout。失敗時は候補成功を作らない。
    """
    p = subprocess.run(args, cwd=TARGET, capture_output=True)
    (output / (name + ".stdout")).write_bytes(p.stdout)
    (output / (name + ".stderr")).write_bytes(p.stderr)
    write(output / (name + ".command.json"), {"argv": args, "cwd": str(TARGET), "exit_code": p.returncode})
    if p.returncode != 0:
        raise ValueError(name + "のmetadata命令失敗")
    return p.stdout


def objects(raw):
    """
    機能: go listの連続JSON objectを欠落なく分解する。
    引数: raw(bytes)は選択依存出力。
    返り値: list[dict]はpackage列。価格本文を対象にしない。
    """
    text = raw.decode("utf-8-sig")
    decoder, offset, result = json.JSONDecoder(), 0, []
    while offset < len(text):
        while offset < len(text) and text[offset].isspace():
            offset += 1
        if offset == len(text):
            break
        value, offset = decoder.raw_decode(text, offset)
        if value.get("Error") or value.get("DepsErrors") or value.get("Incomplete"):
            raise ValueError("Go解決不完了:" + value.get("ImportPath", ""))
        result.append(value)
    return result


def run(output, binary):
    """
    機能: 選択source/module/toolchain/buildinfoの候補指紋と前後証明を作る。
    引数: output/binary(Path)は新規work証拠先とRootの候補exe。
    返り値: dictは件数。go build/test/vetやexe起動は行わない。
    """
    if output.exists():
        raise ValueError("閉包出力は新規dirのみ")
    output.mkdir(parents=True)
    module_before = {str(TARGET / n): sha(TARGET / n) for n in ("go.mod", "go.sum")}
    env = json.loads(command(["go", "env", "-json", *ENV_KEYS], output, "Go環境"))
    if env["GOVERSION"] != "go1.24.2":
        raise ValueError("固定Go版差")
    version = command(["go", "version"], output, "Go版").decode("utf-8").strip()
    pkgs = objects(command(["go", "list", "-mod=readonly", "-deps", "-json", "./..."], output, "Go選択依存"))
    goroot = Path(env["GOROOT"]).resolve()
    cache = Path(env["GOMODCACHE"]).resolve()
    entries, packages, modules = {}, [], {}

    def add(path, role, package=""):
        """
        機能: 選択されたcodeだけを元root/役割/SHA/sizeへ結ぶ。
        引数: path(Path)、role/package(str)は実位置と選択根拠。
        返り値: None。市場系拡張子は指紋取得前に拒否する。
        """
        path = path.resolve()
        if path.suffix.lower() in (".csv", ".gz", ".jsonl", ".xlsx", ".png") or path.name.endswith((".Native.json", ".resources.json")):
            raise ValueError("code閉包へ市場/成果物混入:" + str(path))
        if path.is_relative_to(goroot):
            group, base = "goRoot", goroot
        elif path.is_relative_to(ROOT):
            group, base = "repoRoot", ROOT
        elif path.is_relative_to(ROOT.parent):
            group, base = "neighborRoot", ROOT.parent
        elif path.is_relative_to(cache):
            group, base = "moduleCacheRoot", cache
        else:
            raise ValueError("未定義code root:" + str(path))
        h = sha(path)
        key = str(path)
        if key not in entries:
            entries[key] = {"path": path.as_posix(), "sha256": h, "size": path.stat().st_size,
                            "root": group, "relative": path.relative_to(base).as_posix(), "roles": [], "packages": [],
                            "body保存": False, "環境参照": group == "goRoot"}
        if entries[key]["sha256"] != h:
            raise ValueError("収集中にcode変更:" + key)
        if role not in entries[key]["roles"]:
            entries[key]["roles"].append(role)
        if package and package not in entries[key]["packages"]:
            entries[key]["packages"].append(package)

    for pkg in pkgs:
        name, directory = pkg["ImportPath"], Path(pkg["Dir"])
        selection = {field: pkg[field] for field in FIELDS if pkg.get(field)}
        packages.append({"import_path": name, "directory": str(directory), "standard": pkg.get("Standard", False), "selected": selection, "module": pkg.get("Module")})
        for field, names in selection.items():
            for filename in names:
                add(directory / filename, field, name)
        module = pkg.get("Module", {})
        for value in (module, module.get("Replace", {})):
            if not value:
                continue
            key = value.get("GoMod") or value.get("Dir") or value.get("Path")
            modules[key] = value
            if value.get("GoMod"):
                add(Path(value["GoMod"]), "module_go.mod", name)
            if value.get("Dir"):
                p = Path(value["Dir"]) / "go.sum"
                if p.is_file():
                    add(p, "module_go.sum", name)
    for n in ("go.mod", "go.sum"):
        add(TARGET / n, "main_module")
    if env.get("GOWORK") and env["GOWORK"] != "off":
        work = Path(env["GOWORK"])
        add(work, "go.work")
        if Path(str(work) + ".sum").is_file():
            add(Path(str(work) + ".sum"), "go.work.sum")
    tools = [goroot / "bin/go.exe"] + [Path(env["GOTOOLDIR"]) / (n + ".exe") for n in ("compile", "link", "asm", "buildid")]
    for path in tools:
        if not path.is_file():
            raise ValueError("実Go tool不在:" + str(path))
        add(path, "Go_toolchain_5exe")
    binary = binary.resolve()
    candidate = {"path": binary.as_posix(), "sha256": sha(binary), "size": binary.stat().st_size}
    buildinfo = command(["go", "version", "-m", str(binary)], output, "候補exe_buildinfo").decode("utf-8")
    if "go1.24.2" not in buildinfo or "quietguardcli107" not in buildinfo:
        raise ValueError("候補exeの版/module差")
    after = {str(TARGET / n): sha(TARGET / n) for n in ("go.mod", "go.sum")}
    if after != module_before:
        raise ValueError("readonly命令中のmodule変更")
    for name, item in entries.items():
        if sha(Path(name)) != item["sha256"]:
            raise ValueError("閉包code前後差:" + name)
    if sha(binary) != candidate["sha256"]:
        raise ValueError("候補exe前後差")
    # 旧106で固定した実Go toolと同じ内容か、code宣言metadataへ照合する。
    old = ROOT / "study/00106_収束失速で保護の起動と幅を切り替える/金融条件.json"
    old_sha = sha(old)
    if old_sha != "d9319e0f5757cd198329f8d4e272f1cc6af8b084ea8a8cd80bd10d77c39f809f":
        raise ValueError("旧106条件metadata差")
    declared = {str(Path(n).resolve()): h for n, h in json.loads(old.read_text(encoding="utf-8-sig"))["code_sha256"].items()}
    if not all(declared.get(str(p.resolve())) == entries[str(p.resolve())]["sha256"] for p in tools):
        raise ValueError("旧106に固定したGo toolchainと差")
    result = {"成功": True, "候補": True, "scope": "107市場CLIの選択Go閉包。市場/ビルド/最終停止はRoot担当",
              "target_module": "github.com/masayoshi4649/SessionTradeExecuter/quietguardcli107", "target_dir": str(TARGET),
              "環境whitelist": list(ENV_KEYS), "Go環境": env, "go_version": version,
              "package数": len(packages), "module数": len(modules), "実選択ファイル数": len(entries), "root別件数": dict(Counter(x["root"] for x in entries.values())),
              "packages": packages, "modules": list(modules.values()), "files": list(entries.values()),
              "選択field": list(FIELDS), "非対象": ["TestGoFiles", "XTestGoFiles", "IgnoredGoFiles", "Raw/CSV/市場Record/Native", "ENV全量", "body複製"],
              "候補exe": candidate, "buildinfo": buildinfo, "最終exe保証": False,
              "Go5tool": [{"path": str(p), "sha256": entries[str(p.resolve())]["sha256"], "size": p.stat().st_size} for p in tools],
              "旧106Go5tool同体": True, "module指紋前": module_before, "module指紋後": after, "全選択code前後不変": True,
              "GoRoot扱い": "Go1.24.2の元位置/指紋による外部実行環境。stdlib/tool本文は複製しない",
              "市場データbody/hash/実行": 0, "Root最終codeへの結合": "この候補収集後の変更はRootが差分だけ再照合。候補exeを最終停止exeへ勝手に読み替えない"}
    write(output / "Go閉包候補.json", result)
    return {k: result[k] for k in ("成功", "package数", "module数", "実選択ファイル数", "root別件数", "候補exe")}


def main():
    """
    機能: Root指定の候補exeだけをmetadata収集する。
    引数: --out/--binary(Path)は新規証拠dirと実行せず参照するexe。
    返り値: None。CLI/依存コードは変更しない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--binary", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(run(args.out.resolve(), args.binary.resolve()), ensure_ascii=False))


if __name__ == "__main__":
    main()
