# 107の見送り繰越と24口座の保存検算

市場未実行の準備版。固定106保存器7451をSHA確認して直接importし、所有・部分返済・予約・片側10枚・全実Fill・費用・半円・保存MTM/DD・LD/E起動・幅・公表C/Mの既存検算を再用する。旧106、Actor ed5e、Core 4fa1、純時計2f5は編集しない。

外KeyはB0/B1/BE/Q0/Q1/QE各C0D0/C0D1/C5D0/C5D1。BはB5Q、QはB5QD、保護は順にW0/W1/E1。実内Key・Config・SourceIdentity・公表・注文・Fillを変更して旧時計やLDへ見せる口はない。共通94への基本P0投影は固定103の会計アダプターと同じで、実時計検査・E/W検査は元の実Bookへ別に適用する。

## 再用と時計固有の変更

固定関数を独立名前空間へ置き、ASTで次だけをパラメータ化する。元ファイル・元module globalsは変更しない。金額・Source・予約・Fill・MTM等の式は変更しない。

1. 固定103 `verify_book` のConfig.entry_timingの定数1箇所を実Keyから得たB5Q/B5QDへする。
2. 固定95 `verify_grid` のAssignedAtの式1箇所を、独立したquiet一回割当計算へ渡す。
3. 同関数のquiet適用比較2箇所をB5Q/B5QDとする。

変更箇所数が異なればimport段階で拒否する。新 `verify_clock` は停止531bの計算式をPythonで独立再計算し、Actor ClockAudit全欄をSourceIdentity全文＋OrdinalでEntryOpportunityへ一対一結合する。

- B5QのClockAuditは空配列。B5QDは非繰越の出生も含む全出生分が必要。
- 元Signal出生からstrict次300秒格子を計算。開始後30分／Night米国開始後30分の半開quietだけを一回繰り越す。非quiet出生の任意の移動を拒否。
- B5QDのSession/Actual開始・米国時計の整列、一致、将来や未知の支持なしを確認する。
- 各出生は最初の観測済み割当以降の枠で一回だけ採否。欠けた割当先を未来へ復活させず、EOF時は未観測枠を補わない。
- 失効した出生も含め当gridのQuote全文とageへ結合。旧優先順のForce/P締切、Source取消・未取得・完結・予約、気配未知、容量不足と受理理由を照合。
- 全Source newは一Opportunity。全実entry注文は受理Opportunityと一対一。正数量受理後の0取得取消も別件数とし、同出生の再要求を認めない。元の後原行index/物理行・D1・Source優先は固定規範が検算する。

保留は「割当前の観測保留枠延べ」、受理出生・受理枚・実取得出生・実取得枚・0取得取消と分ける。主参加は固定103の同枠内実取得new＋当時実保有の和集合。受理だけ／後のFillを要求枠へ戻した値／実Fill bucketは別欄。欠測・USquietは分母に残す。70場の主7840、副7560を維持する。

## 会計・比較・Viewer

全24の粗額/fee/slip/net、正負/PF、初回u正益後の最終赤字と保護起動後の最終赤字、保存極値の連結DD、回数/枚数、日夜・日別・履歴区分を保存する。全quote別engineでの金融再生やRawからの指標形成を証明しない。C/Mは保存公開値を固定Python純式で再評価し、追加のRaw/Source/Bank形成は行わない。

比較は時計差Q0対B0/Q1対B1/QE対BEの12本と、同時計内の三政策全対24本、計36本。固定103のSource全文・要求/実取得の全属性比較を直接呼び、全差額＝同実入口退出差＋取得変更差−前のみ実現額＋後のみ実現額を検算する。取得変更を退出効果へ混ぜず、未参加・決済後価格・機会損失・MFEを算出しない。費用感度や同Sourceを独立した市場例に数えない。

出力は結果.json、保存会計の確認.json、schema1の一覧.resources.json、実Fillだけの107_key_session.trades.jsonl。タイトルは「見送り繰越と利益保護 key session」。原板は元pathを参照し、複製・再hashしない。HTTPやViewerプロセスの操作は0。

## Root成功後の最小固定とCLI

```json
{
  "version": 1,
  "trial": 107,
  "fixed": true,
  "stage": "first2",
  "condition": {"path": "条件.json", "sha256": "64桁"},
  "completion": {"path": "金融完了.json", "sha256": "64桁"},
  "code": {"path": "集計.py", "sha256": "64桁"}
}
```

```powershell
python -B -X utf8 work/107見送り繰越の保存準備/集計.py `
  --fixed <Root事後固定JSON> --fixed-sha <そのSHA256> --out <新規保存dir>
```

FileRefはそれを持つmetadataファイルのparent基準。条件code_sha256も実107市場CLIと同じ条件parent基準又は絶対path。市場前条件・金融success・同条件・完全2/70場・24冊・前後不変・全出力SHAをNative本文より先に検査する。全70は同条件先頭2のNative/Header/records SHA一致を要求する。追加の「別engine独立成功」を創作したり必須条件に加えない。

107市場NativeはCore107のResultにcondition_sha256/input_proof/replay_proof/provenanceを埋めた実型を読む。Header/recordsは106完成列そのもの。保存側でも旧106の実NativeからB12/幅12/Early4を全JSON除外0で再照合する。Coreの最終対照を全時点対照へ拡張して呼ばない。

今回Rootの市場成功固定は未提供なので、実市場CLIは未実行。条件・完了の実SHAはコード定数を後編集せず、上記Root固定JSONで実行前に与える。

## 非市場人工の成功範囲

停止Core 4fa1の6型を使用。旧4は実繰越0、新しい買売2は手製Sourceの出生時刻/出典を動かした器具でQ24が実繰越する。自然quiet発生率・参加率や市場効果の証明ではない。

保存検算144冊非0、追加2の実繰越/受理/後続Fill24、各系列36比較、Viewer24資源の全実Fill型、破損10拒否、価格を持たないmetadata正常1/拒否5が成功。初回と当grid気配・理由結合を補った最終人工は別dirへ保持し、元のGo型6本文は前後不変。新金融の再実行は0。

旧Actorの買売/全C-D/取消・予約・締切・EOF等の人工はed5eの別証拠。今回の保存検算を全quote独立再生・自然Source形成へ拡大しない。
