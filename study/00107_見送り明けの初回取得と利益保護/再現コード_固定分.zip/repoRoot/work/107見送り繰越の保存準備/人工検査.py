"""Core107の停止Go型だけで保存検算・実名clock・破損拒否を確認する。"""

import copy
from datetime import date, timedelta
import importlib.util
import json
from pathlib import Path
import sys


def main():
    """
    機能: 停止6型144会計と狭い破損を検査し、小型証拠を新規保存する。
    引数: argv[1](str)は新規人工先。市場固定や市場Nativeは使用しない。
    返り値: なし。失敗は例外、新規先の重複も拒否する。
    """
    here = Path(__file__).resolve().parent
    spec = importlib.util.spec_from_file_location("107保存人工", here / "集計.py")
    s = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(s)
    output = Path(sys.argv[1]).resolve()
    s.need(not output.exists(), "人工は新規先")
    output.mkdir(parents=True)
    root = s.ROOT / "work/107見送り繰越の市場接続準備"
    stop = root / "停止.json"
    s.equal(s.digest(stop), "4fa185cd5337a427352dd82af8eff81e1a09a263ec63ac45da98cb3f08ce7b62", "Core停止")
    fixtures = sorted((root / "人工_停止版").glob("*.json"))
    s.equal(len(fixtures), 6, "Go型6系列")
    inputs = {str(stop): s.digest(stop), **{str(p): s.digest(p) for p in fixtures}}
    details, cached, total = [], {}, 0
    for path in fixtures:
        f = s.load(path)
        v = f["output"]
        original = copy.deepcopy(f)
        registry = s.SAVED.registry_from_records(f["records"], v)
        checked = s.inspect_scene(v, registry, False, True)
        comparisons = s.compare_scene(checked)
        s.equal(len(comparisons), 36, "全比較36")
        rows = s.scene_rows(v, checked)
        summary, _ = s.aggregate(rows)
        for name, comp in comparisons.items():
            after, before = name.split("対")
            s.equal(comp["全差額"], summary[after]["net_yen"] - summary[before]["net_yen"], "比較と保存純額")
        s.equal(f, original, "元Go型を変更しない")
        deferred = sum(a["deferred"] for audit in v["clock_audits"].values() for a in audit["opportunities"])
        if path.name.startswith("quiet"):
            s.equal(deferred, 12, "追加手製12冊の実繰越")
            for key in s.KEYS[12:]:
                counts = checked[key]["clock_counts"]
                s.need(counts["受理出生"] > 0 and counts["実取得出生"] > 0, "繰越後の受理/取得")
        else:
            s.equal(deferred, 0, "旧4器具の繰越非発動を成功に拡張しない")
        details.append({"path": str(path), "SHA256": inputs[str(path)], "保存会計": len(checked), "非0": sum(v["books"][k]["totals"]["entry_quantity"] > 0 for k in s.KEYS),
                        "実繰越": deferred, "比較": len(comparisons), "成功": True})
        cached[path.name] = f
        total += len(checked)
    quiet = next(f for name, f in cached.items() if name.startswith("quiet") and "方向1" in name)
    v = quiet["output"]
    viewer = output / "Viewer型"
    viewer.mkdir()
    resources = s.save_viewer(v, viewer, "手製原板への未使用参照")
    s.equal(len(resources), 24, "24資源型")
    for key, resource in zip(s.KEYS, resources):
        with (viewer / resource["pnl_path"]).open(encoding="utf-8") as stream:
            trades = [json.loads(line) for line in stream]
        s.equal(len(trades), len(v["books"][key]["fills"]), "全実FillだけのViewer")
        s.need(resource["id"].startswith("107_") and resource["point_value"] == 100, "107 namespace/mini")
    s.BASE.write_json(viewer / "一覧.resources.json", {"schema_version": 1, "path_base": "catalog", "resources": resources})
    rejected = []
    mutations = {
        "auditSource全文": lambda x: x["clock_audits"]["Q0_C0_D0"]["opportunities"][0]["source"].update(parent="別出生"),
        "auditOrdinal": lambda x: x["clock_audits"]["Q0_C0_D0"]["opportunities"][0].update(ordinal=2),
        "元strict": lambda x: x["clock_audits"]["Q0_C0_D0"]["opportunities"][0].update(strict_at=x["clock_audits"]["Q0_C0_D0"]["opportunities"][0]["strict_at"]+300),
        "二度目の割当": lambda x: x["clock_audits"]["Q0_C0_D0"]["opportunities"][0].update(assigned_at=x["clock_audits"]["Q0_C0_D0"]["opportunities"][0]["assigned_at"]+300),
        "消費解除": lambda x: x["books"]["Q0_C0_D0"]["entry_opportunities"][0].update(consumed=False),
        "QDをB5Qと偽る": lambda x: x["books"]["Q0_C0_D0"]["config"].update(entry_timing="B5Q"),
        "気配age": lambda x: x["books"]["Q0_C0_D0"]["entry_opportunities"][0].update(quote_age_seconds=99999),
        "Source予約": lambda x: x["books"]["Q0_C0_D0"]["entry_opportunities"][0].update(source_reserved=1),
        "半円費用": lambda x: x["books"]["Q0_C0_D0"]["fills"][0].update(fee_yen=x["books"]["Q0_C0_D0"]["fills"][0]["fee_yen"]+s.BASE.FEE),
        "当原行Fill": lambda x: x["books"]["Q0_C0_D0"]["fills"][0]["quote"].update(source_line=x["books"]["Q0_C0_D0"]["orders"][0]["request_quote"]["source_line"]),
    }
    for name, mutate in mutations.items():
        bad = copy.deepcopy(v)
        mutate(bad)
        try:
            s.inspect_scene(bad, None, False, True)
        except (AssertionError, ValueError, KeyError, TypeError) as error:
            rejected.append({"名称": name, "拒否": type(error).__name__})
        else:
            raise AssertionError("破損を受理: " + name)
    # ----------------------------------------
    # 価格を持たない手製metadataで、金融失敗や集合欠落をNative前に拒否する。
    ids = [(date(2026, 9, 21) + timedelta(days=i//2)).isoformat() + ("_Day" if i%2 == 0 else "_Night") for i in range(70)]
    manifest = {"sessions": [{"id": x} for x in ids]}
    condition = {"version": 1, "trial": 107, "fixed": True, "input_mode": "recorded_public_106", "configs": s.CONFIGS}
    ref = {"path": "未読の手製参照", "sha256": "a"*64}
    complete = {"version": 1, "trial": 107, "stage": "first2", "success": True, "condition_sha256": "b"*64, "sessions": 2, "books_per_scene": 24, "books": 48,
                "before": {"手製code": "c"*64}, "after": {"手製code": "c"*64}, "unchanged": True, "input_mode": "recorded_public_106",
                "source_reexecuted": False, "features_recomputed": False, "charts_recomputed": False, "cmp_recomputed": True, "financial_executed": True,
                "results": [{"session": x, "books": 24, "base_control_books": 12, "native": ref, "sidecar_header": ref, "sidecar_records": ref} for x in ids[:2]]}
    s.validate_completion(condition, complete, manifest, "first2", "b"*64)
    meta_rejects = []
    for name, field, value in (("失敗金融", "success", False), ("会計欠落", "books", 47), ("前後不変なし", "unchanged", False), ("条件違い", "condition_sha256", "d"*64), ("新Source形成", "source_reexecuted", True)):
        bad = copy.deepcopy(complete)
        bad[field] = value
        try:
            s.validate_completion(condition, bad, manifest, "first2", "b"*64)
        except (AssertionError, ValueError) as error:
            meta_rejects.append({"名称": name, "拒否": type(error).__name__})
        else:
            raise AssertionError("metadata破損を受理: " + name)
    s.equal({p: s.digest(Path(p)) for p in inputs}, inputs, "元型の前後不変")
    result = {"成功": True, "scope": "停止Coreの6手製系列144会計・保存算術/実名clock/公開型/36比較。市場ではない", "会計": total,
              "非0会計": sum(d["非0"] for d in details), "実繰越会計": sum(d["実繰越"] for d in details), "details": details,
              "Viewer形式": 24, "破損拒否": rejected, "metadata正常": 1, "metadata拒否": meta_rejects,
              "入力SHA256前": inputs, "入力SHA256後": inputs, "前後不変": True, "金融再実行": 0, "実Viewer通信": 0,
              "限界": "手製のSource時刻/出典移動でquiet発動を作った2器具と旧4を分離。自然quiet率や市場効果は未検証"}
    s.BASE.write_json(output / "人工確認.json", result)
    print(json.dumps({"成功": True, "会計": total, "実繰越": result["実繰越会計"], "破損拒否": len(rejected), "metadata拒否": len(meta_rejects)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
