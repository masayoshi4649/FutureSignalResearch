"""保存器の小型コードと非市場人工の最終指紋を新規保存する。"""

from pathlib import Path
import hashlib
import importlib.util
import json


def sha(path):
    """
    機能: コード又は型人工のSHA256を取得する。
    引数: path(Path)は許可された小型ファイル。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    """
    機能: 旧コードの固定SHAと人工成功を結び新保存器を停止する。
    引数: なし。位置はこのファイルから解決する。
    返り値: なし。既存停止・不成功・元指紋差は例外で拒否する。
    """
    root = Path(__file__).resolve().parent
    repo = root.parents[1]
    stop = root / "停止.json"
    if stop.exists():
        raise RuntimeError("停止済み")
    spec = importlib.util.spec_from_file_location("107保存停止", root / "集計.py")
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    refs = {
        "work/106可変保護の保存準備/集計.py": m.SAVED_SHA,
        "work/106可変保護の保存準備/停止.json": "3dd87ba97322a30c820d5b958f27d5846c4bce206e748ce0a88a962c881c9953",
        "work/見送り繰越の保護会計/停止.json": "ed5e63ab27e1b9aaf4aa2c18f63cc0cd48f881ec9416a89002e90ce78651c2b9",
        "work/107見送り繰越の市場接続準備/停止.json": "4fa185cd5337a427352dd82af8eff81e1a09a263ec63ac45da98cb3f08ce7b62",
        "work/quietだけ繰り越す入口時計/停止.json": "2f5c731d056662d3bd1233a55fab2e1766551f29d106bde03ff894770b9e8e75",
        m.CLOCK_SOURCE["path"]: m.CLOCK_SOURCE["sha256"],
    }
    for module in (m.SAVED.PREVIOUS, m.SAVED.PREVIOUS.BASE, m.OLD, m.GRID, m.BASE, m.SAVED.PUBLIC, m.SAVED.PUBLIC.pure):
        p = Path(module.__file__).resolve()
        refs[str(p.relative_to(repo)).replace("\\", "/")] = sha(p)
    for name, expected in refs.items():
        if sha(repo / name) != expected:
            raise RuntimeError("固定参照SHA差: " + name)
    artificial = root / "人工_停止版/人工確認.json"
    value = m.load(artificial)
    if not value["成功"] or value["会計"] != 144 or value["実繰越会計"] != 24 or len(value["破損拒否"]) != 10:
        raise RuntimeError("人工未成立")
    for name, expected in value["入力SHA256前"].items():
        if sha(Path(name)) != expected:
            raise RuntimeError("元型人工のSHA差")
    own = [root / n for n in ("集計.py", "人工検査.py", "README.md", "停止を記録する.py")]
    owned = {str(p.relative_to(repo)).replace("\\", "/"): sha(p) for p in own}
    proof = {"成功": True, "scope": "107の保存会計と実名clock・C/M/E/幅・36加法比較・Viewer型の非市場準備",
             "所有コードSHA256": owned, "再用コードと停止SHA256": refs,
             "人工": {"path": str(artificial.relative_to(repo)).replace("\\", "/"), "SHA256": sha(artificial), "会計": 144, "実繰越": 24, "Viewer形式": 24, "破損拒否": 10, "metadata拒否": 5},
             "AST時計hook": {"103Config実timing": 1, "95assigned独立式": 1, "95quietへB5QD": 2, "元module変更": False},
             "比較": {"時計": 12, "同時計保護": 24}, "原板/CSV/市場Native/Source本文読取": 0,
             "金融再実行/HTTP": 0, "市場CLI": "Root成功後にfixed/fixed-sha/outの最小3Refで実行。今回は未実行",
             "留保": "手製Source時刻移動の2器具を旧4と分離。全quote別engine・市場効果を主張しない"}
    with stop.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(proof, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"成功": True, "停止": str(stop), "SHA256": sha(stop), "保存器SHA256": sha(root / "集計.py")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
