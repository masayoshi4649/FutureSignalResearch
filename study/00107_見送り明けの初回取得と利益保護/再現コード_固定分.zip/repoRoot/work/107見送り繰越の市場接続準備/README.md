# 107見送り繰越の24会計Core

`quietguardruntime107` は106停止Core `c465bd16…` の小派生。Source/価格/公表を作らず、既存Tapeとpublicsidecar.Recordの保存列だけを受け取る。市場I/O・ファイル参照の認証はRoot外周の責務である。

```go
c, err := NewCore(inputTape, contract, scope, control)
err = c.Feed(record) // 保存列を元順で一件ずつ配送
result, err := c.Finish(header)
```

`Configurations()/Key(Config)`はB0/B1/BE/Q0/Q1/QE順、各C0D0/C0D1/C5D0/C5D1。Configは`Candidate/Timing/Policy/Slip/Delay`。B0/Q0はW0、B1/Q1はW1、BE/QEはE1で、BはB5Q、QはB5QD。内ActualResultのKey/Config/全fieldを外Keyへ改名しない。

Controlは`Kind=provided_old106`、`HistoryClass=old_saved_70`（手製はartificial）、`ReferencePath/ReferenceSHA`、`Books/WidthAudits/EarlyAudits`。三mapは旧106外KeyのW0/W1/E1各4を使い、Book12/幅12/早期4を`json.RawMessage`で全field保持する。B側の新最終結果/auditへ全JSON比較し、未知fieldを型射影で捨てない。期待値の転記や旧103Actorの別運転はしない。参照path/SHA実物の認証は外周が行う。

Resultは`books24/width_audits24/early_audits8/clock_audits24/base_control`を保存する。BaseControlは結果12/幅12/早期4、除外[]・全時点比較0。ClockAuditはActorの公開型をそのまま保存する。Source形成false、Chart/Bank再形成false、CMP再計算true。CMPは保存済み新3分公表から停止Pipelineで再評価し、Deliveryの全field/Frame/Result SHAと一致させる。公表だけではMTM/約定しない。

106の`finite/resetKey/raw/Feed`と`Run/SourceForces`の本文は同体。Source消費口は旧103対照ループを除き、同じScalar11・NativeBatch全Delta・Closes-only・SourceLine/ordinal・Force/grid/quote順を配送する。resetの元Quote全値、pre-raw公表→Force→grid、同秒Raw後戻し、EOF後補完禁止、Header完全消費、Source入力前後SHAの検査を残す。保護、費用、D1、数量等をCoreで実装し直さない。

人工は停止106 Coreの買売×cold/carry4ファイルを直接読んでFeedする。Bank/Sourceの再形成0、96冊非0、B最終48冊/幅48/早期16の旧JSON対照、Q48冊の時計出典/一回消費/終了後禁止と14破損拒否を確認する。元4人工の出生は開始+1680秒と+2400秒なので、この4器具の実繰越は0である。

別の買売2器具は、保存済み価格/公表/全board/Force/Fill/closeを変えず、人工の初回new一件だけを既存の開始+1380秒原行へ移す。Signalの時計/Index/QuoteとDeltaのAt/Lineもその原行へ明示結合する。Bは元+1500秒枠でquiet失効、Qは+1800秒へ一度繰り越し、その時点のSource存続と正数量受理、後続適格原行の一回実fillを検査する。同じ派生Tape/保存列を旧106 Coreへ別配送し、Qの結果を期待値にせずB12最終/幅12/早期4全JSONを照合する。これは人工通知の器具変更であり自然Source形成の証明ではない。2器具を加えた144冊は全非0、Q繰越24件を含む。

P締切/取消/失効lock/Nightの網羅はActor停止`ed5e63ab…`の別scope。6器具は同じscene名の独立手製ケースで、市場例数を6日へ増やさない。旧103別運転は107本番にはなく、2派生器具の旧106期待値生成だけでは旧106の内部対照も動く。いずれも市場全点の独立engine監査とは呼ばない。

市場/Raw/CSV/旧Native/保存市場Record/Source市場本文の読取・金融本番0。全市場原行の別engine照合、107市場Pnl、採用・未見安定性は未証明。Rootの固定と実行承認まではこの人工部品で停止する。
