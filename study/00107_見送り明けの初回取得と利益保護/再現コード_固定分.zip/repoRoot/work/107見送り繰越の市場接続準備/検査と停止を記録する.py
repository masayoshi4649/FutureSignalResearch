"""107 Coreの手製保存列接続だけを検査し、旧停止不変と新所有指紋を記録する。"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
STOPS = {'work/106可変保護の市場接続準備/停止.json': 'c465bd1696fe1e5d2f4c9b299712866c96b73b4126bf4883245acc47fec154f3',
         'work/見送り繰越の保護会計/停止.json': 'ed5e63ab27e1b9aaf4aa2c18f63cc0cd48f881ec9416a89002e90ce78651c2b9'}


def sha(path: Path) -> str:
    """
    機能: 明示したコード/停止又は手製人工のSHA256を得る。
    引数: path (Path) は対象の小ファイル。
    返り値: str は内容指紋。市場入力を読まない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def metadata_inputs() -> dict[str, str]:
    """
    機能: 旧Core/新Actorの成功停止と所有コードを現物へ結ぶ。
    引数: なし。
    返り値: dict[str,str] は停止・所有コードの前指紋。
    """
    before = {}
    for name, expected in STOPS.items():
        p = ROOT/name
        assert sha(p) == expected
        value = json.loads(p.read_text(encoding='utf-8'))
        assert value['成功'] is True
        before[str(p)] = expected
        owned = value.get('所有コードSHA256', value.get('所有SHA256'))
        assert isinstance(owned, dict) and owned
        for key, digest in owned.items():
            p = Path(key)
            if not p.is_absolute():
                p = ROOT/p
            assert sha(p) == digest
            before[str(p.resolve())] = digest
    return before


def main() -> None:
    """
    機能: 型人工export/test/vet/buildと限定同体検査を一度実行して停止する。
    引数: なし。明示した旧停止と4人工だけを使う。
    返り値: None。市場CLI、Source形成、Bank形成は実行しない。
    """
    before = metadata_inputs()
    for p in (ROOT/'work/106可変保護の市場接続準備/人工_停止版').glob('*.json'):
        before[str(p)] = sha(p)
    logs = WORK/'検査'
    logs.mkdir(exist_ok=False)
    export = WORK/'人工_停止版'
    assert not export.exists() and not (WORK/'停止.json').exists()
    env = dict(os.environ, RUNTIME107_EXPORT=str(export))
    records = []
    for name, argv in [('test', ['go', 'test', './...', '-count=1', '-json']), ('vet', ['go', 'vet', './...']), ('build', ['go', 'build', './...'])]:
        result = subprocess.run(argv, cwd=WORK, env=env, capture_output=True, text=True, encoding='utf-8')
        (logs/(name+'.stdout.txt')).write_text(result.stdout, encoding='utf-8')
        (logs/(name+'.stderr.txt')).write_text(result.stderr, encoding='utf-8')
        records.append({'検査': name, 'argv': argv, '終了値': result.returncode})
        assert result.returncode == 0, result.stderr
    # ----------------------------------------
    # 金融式を複写せず、保存結果のscope・冊数・全終端だけを確認する。
    artifacts, nonzero, q_nonzero, deferred = {}, 0, 0, 0
    for p in sorted(export.glob('*.json')):
        v = json.loads(p.read_text(encoding='utf-8'))
        r = v['output']
        assert r['trial'] == 107 and r['complete'] and len(r['books']) == len(r['clock_audits']) == 24
        assert (r['base_control']['books'], r['base_control']['width_audits'], r['base_control']['early_audits']) == (12, 12, 4)
        assert not r['source_reexecuted'] and not r['charts_recomputed'] and not r['bank_recomputed'] and r['cmp_recomputed']
        for k, b in r['books'].items():
            assert b['complete'] and b['finished'] and b['totals']['entry_quantity'] > 0
            nonzero += 1
            q_nonzero += int(k.startswith('Q'))
            deferred += sum(x['deferred'] for x in r['clock_audits'][k]['opportunities'])
        artifacts[p.relative_to(ROOT).as_posix()] = sha(p)
    assert len(artifacts) == 6 and nonzero == 144 and q_nonzero == 72 and deferred == 24
    old = ROOT/'work/106可変保護の市場接続準備/feed.go'
    original, current = old.read_text(encoding='utf-8'), (WORK/'feed.go').read_text(encoding='utf-8')
    assert original[original.index('// finite'):original.index('// Finish')] == current[current.index('// finite'):current.index('// Finish')]
    assert original[original.index('// Run'):] == current[current.index('// Run'):]
    assert all(sha(Path(p)) == s for p, s in before.items())
    event_log = [json.loads(x) for x in (logs/'test.stdout.txt').read_text(encoding='utf-8').splitlines()]
    passed = [x['Test'] for x in event_log if x.get('Action') == 'pass' and 'Test' in x]
    own = ['core.go', 'feed.go', 'core_test.go', 'go.mod', 'go.sum', 'README.md', '検査と停止を記録する.py']
    result = {'成功': True, 'scope': '手製保存Streamを使う107 Core24。市場未実行', 'module': 'github.com/masayoshi4649/SessionTradeExecuter/quietguardruntime107',
              '所有コードSHA256': {(WORK/n).relative_to(ROOT).as_posix(): sha(WORK/n) for n in own}, '由来停止SHA256': STOPS,
              '依存前指紋': before, '依存前後不変': True, '全24設定': json.loads(next(export.glob('*.json')).read_text(encoding='utf-8'))['output']['configs'],
              '人工出力SHA256': artifacts, '検査': records, 'Go成功top': sum('/' not in x for x in passed), '小試験込成功': len(passed),
              '人工': {'場面': 6, '非0冊': nonzero, 'Q非0冊': q_nonzero, '旧106_B最終全JSON': 72, '旧幅audit': 72, '旧早期audit': 24, '除外': [], '全時点比較': 0, '破損拒否': 14, '実繰越件数': deferred, '旧4器具': '繰越0・停止保存列直接配送', '追加買売2器具': '初回人工newの原行だけ変更、保存価格/公表/全board/Force/Fill/close無変更。B失効/Q12繰越→受理→実fill'},
              'Feed全board/公表/reset検査本文とRun/SourceForces本文同体': True,
              'API': 'NewCore(Tape,contract,scope,Control)→Feed(Record)→Finish(Header)',
              '市場/Raw/CSV/Source/旧Native/保存市場Record/金融本番': 0,
              '未実証': ['市場24冊×70場', '実市場quiet繰越', '全原行別engine照合', '採用と未見安定性'],
              '注意': 'Night/Force/P/取消lock網羅はActor停止ed5eの別scope。quiet実繰越2器具も自然Source形成又は市場利益の証明ではない。'}
    (WORK/'停止.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'成功': True, '停止SHA256': sha(WORK/'停止.json'), 'Go成功top': result['Go成功top'], '小試験込成功': len(passed), '非0冊': nonzero}, ensure_ascii=False))


if __name__ == '__main__':
    main()
