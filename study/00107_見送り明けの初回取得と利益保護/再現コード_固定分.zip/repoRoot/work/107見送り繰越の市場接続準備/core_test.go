package quietguardruntime107

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"testing"

	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	stream "github.com/masayoshi4649/SessionTradeExecuter/publicsidecar"
	previous "github.com/masayoshi4649/SessionTradeExecuter/variableguardruntime"
)

type stoppedFixture struct {
	Scope   string          `json:"scope"`
	Tape    tape.Tape       `json:"tape"`
	Header  stream.Header   `json:"header"`
	Records []stream.Record `json:"records"`
	Output  struct {
		Contract string                     `json:"contract"`
		Books    map[string]json.RawMessage `json:"books"`
		Width    map[string]json.RawMessage `json:"width_audits"`
		Early    map[string]json.RawMessage `json:"early_audits"`
	} `json:"output"`
}

var fixtureSHA = map[string]string{
	"方向1_助走false.json":  "338053abd284a1dadf2051e3d31f67cb4125a82ad7b659320ef93ef617ae25c1",
	"方向1_助走true.json":   "4a4da3282c85fa27ac9972b6ae6cfa1f89df2405cd018c4d78a25bea1dad6219",
	"方向-1_助走false.json": "5600ef162b9cdfecb00961ff4c6e550bcfd8a1ee1c2d1289f237b01ff59cbcf0",
	"方向-1_助走true.json":  "b251b4a991511a8ccad9e615c60356eb1be82262d7b55ba75f9c79e631a94b9e",
}

// loadFixture は停止106の手製保存列と期待最終値だけを読みます。
//
// 引数: t(*testing.T)、name(string)は試験器と四つの固定人工名です。
// 返り値: stoppedFixture/Controlは全保存列と旧106の生JSON対照です。Bank/Sourceを再形成しません。
func loadFixture(t *testing.T, name string) (stoppedFixture, Control) {
	t.Helper()
	p := filepath.Join("..", "106可変保護の市場接続準備", "人工_停止版", name)
	b, e := os.ReadFile(p)
	if e != nil {
		t.Fatal(e)
	}
	h := sha256.Sum256(b)
	if hex.EncodeToString(h[:]) != fixtureSHA[name] {
		t.Fatal("停止106人工SHA差")
	}
	f := stoppedFixture{}
	if e = json.Unmarshal(b, &f); e != nil {
		t.Fatal(e)
	}
	c := Control{Kind: "provided_old106", HistoryClass: "artificial", ReferencePath: p, ReferenceSHA: fixtureSHA[name], Books: map[string]json.RawMessage{}, WidthAudits: map[string]json.RawMessage{}, EarlyAudits: map[string]json.RawMessage{}}
	for _, cfg := range Configurations() {
		if cfg.Timing != "B5Q" {
			continue
		}
		k := BaseKey(cfg)
		c.Books[k], c.WidthAudits[k] = f.Output.Books[k], f.Output.Width[k]
		if cfg.Policy == "E1" {
			c.EarlyAudits[k] = f.Output.Early[k]
		}
	}
	return f, c
}

// cloneJSON は破損器具だけを元人工から分離します。
//
// 引数: t(*testing.T)、v(T)は試験器と保存型です。
// 返り値: Tは独立値です。元人工又は停止コードを変更しません。
func cloneJSON[T any](t *testing.T, v T) T {
	t.Helper()
	b, e := json.Marshal(v)
	if e != nil {
		t.Fatal(e)
	}
	var out T
	if e = json.Unmarshal(b, &out); e != nil {
		t.Fatal(e)
	}
	return out
}

// TestSavedTwentyFour は停止保存列だけでB旧12冊/幅12/早期4とQ非0を確認します。
//
// 引数: t(*testing.T)、環境RUNTIME107_EXPORT(string)は試験器と任意の新規型export先です。
// 返り値: なし。手製Source/公表の型接続であり、自然市場の発動や新Pnlを証明しません。
func TestSavedTwentyFour(t *testing.T) {
	for _, name := range []string{"方向1_助走false.json", "方向1_助走true.json", "方向-1_助走false.json", "方向-1_助走true.json"} {
		t.Run(name, func(t *testing.T) {
			f, control := loadFixture(t, name)
			c, e := NewCore(f.Tape, f.Output.Contract, "停止106手製Tape/保存Streamの直接再用。B12最終とaudit対照、Q時計の型接続", control)
			if e != nil {
				t.Fatal(e)
			}
			result, e := Run(c, f.Records, f.Header)
			if e != nil {
				t.Fatal(e)
			}
			if !result.Complete || len(result.Books) != 24 || !result.BaseControl.All || result.BaseControl.Books != 12 || result.BaseControl.WidthAudits != 12 || result.BaseControl.EarlyAudits != 4 || result.BaseControl.AllPointComparisons != 0 || result.SourceReexecuted || result.BankRecomputed || result.ChartRecomputed || !result.CMPRecomputed {
				t.Fatal("24冊/対照/形成scope差", result.BaseControl)
			}
			for _, cfg := range result.Configs {
				k := Key(cfg)
				b, a := result.Books[k], result.ClockAudits[k]
				if b.Totals.EntryQuantity == 0 || !b.Complete || !b.Finished || b.Config.EntryTiming != cfg.Timing || a.Timing != cfg.Timing || a.Opportunities == nil {
					t.Fatal("非0完結/時計語形差", k)
				}
				if cfg.Timing == "B5Q" {
					if len(a.Opportunities) != 0 {
						t.Fatal("旧B時計へ新audit混入")
					}
				} else {
					if len(a.Opportunities) != len(b.EntryOpportunities) {
						t.Fatal("全出生の時計出典欠落")
					}
					for i, x := range a.Opportunities {
						p := b.EntryOpportunities[i]
						if x.Ordinal != p.Ordinal || x.Source != p.Source || x.AssignedAt != p.AssignedAt || !p.Consumed || (x.Deferred && x.AssignedAt < x.QuietEnd) {
							t.Fatal("割当/消費/出典差")
						}
					}
				}
			}
			if e = c.Feed(f.Records[len(f.Records)-1]); e == nil {
				t.Fatal("終了後の再配送を許可")
			}
			if dir := os.Getenv("RUNTIME107_EXPORT"); dir != "" {
				if e = os.MkdirAll(dir, 0755); e != nil {
					t.Fatal(e)
				}
				value := struct {
					Scope     string          `json:"scope"`
					SourceSHA string          `json:"fixture106_sha256"`
					Tape      tape.Tape       `json:"tape"`
					Header    stream.Header   `json:"header"`
					Records   []stream.Record `json:"records"`
					Output    Result          `json:"output"`
				}{result.Scope, fixtureSHA[name], f.Tape, f.Header, f.Records, result}
				b, er := json.MarshalIndent(value, "", "  ")
				if er != nil {
					t.Fatal(er)
				}
				p := filepath.Join(dir, name)
				file, er := os.OpenFile(p, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0644)
				if er != nil {
					t.Fatal(er)
				}
				_, er = file.Write(b)
				ce := file.Close()
				if er != nil || ce != nil {
					t.Fatal(er, ce)
				}
			}
		})
	}
}

// TestQuietShiftIntegration は保存済み価格/公表を変えず人工出生だけをquiet内の別原行へ移します。
//
// 引数: t(*testing.T)、環境RUNTIME107_EXPORT(string)は試験器と任意の新規export先です。
// 返り値: なし。B12の旧106全JSONと、Qの一回繰越→受理→後続fillを同じ保存列で確認します。
func TestQuietShiftIntegration(t *testing.T) {
	for _, side := range []int{1, -1} {
		t.Run(fmt.Sprintf("方向%d", side), func(t *testing.T) {
			name := fmt.Sprintf("方向%d_助走false.json", side)
			f, _ := loadFixture(t, name)
			streamBefore, e := digestValue(f.Records)
			if e != nil {
				t.Fatal(e)
			}
			from, to := -1, -1
			for i, event := range f.Tape.Events {
				if event.Kind != "quote" {
					continue
				}
				if event.At == f.Tape.Session.Start+1380 {
					to = i
				}
				for _, batch := range event.NonEmpty {
					for _, signal := range batch.Delta.Signals {
						if signal.Signal.ID == "初回" && signal.Signal.Action == "new" {
							from = i
						}
					}
				}
			}
			if from < 0 || to < 0 || len(f.Tape.Events[from].NonEmpty) != 1 || len(f.Tape.Events[to].NonEmpty) != 0 {
				t.Fatal("人工出生の移動元/先が一意でない")
			}
			batch := f.Tape.Events[from].NonEmpty[0]
			if len(batch.Delta.Signals) != 1 || len(batch.Delta.Fills)+len(batch.Delta.Cancellations)+len(batch.Delta.Closes) != 0 {
				t.Fatal("人工出生以外の通知を変更しようとした")
			}
			q := f.Tape.Events[to].Quote
			batch.Delta.At, batch.Delta.SourceLine = q.Time, q.SourceLine
			r := &batch.Delta.Signals[0]
			r.At, r.Signal.Time, r.Signal.SourceIndex = q.Time, q.Time, q.Index
			r.Quote = native.QuoteStamp{Time: q.Time, Index: q.Index, SourceLine: q.SourceLine, Last: q.Last, Bid: q.Bid, Ask: q.Ask, QuoteOK: q.QuoteOK}
			f.Tape.Events[from].NonEmpty = nil
			f.Tape.Events[to].NonEmpty = append(f.Tape.Events[to].NonEmpty, batch)
			f.Tape.Scope = "停止106手製の初回newだけを開始+1380秒の既存quoteへ移動。Fill/close/Force/Scalar/公表は無変更"
			// ----------------------------------------
			// B期待値は旧106へ同じ派生入力を実配送し、Qの結果から逆算しません。
			old, e := previous.NewCore(f.Tape, f.Output.Contract, f.Tape.Scope, previous.Control{Kind: "same_input_old103", HistoryClass: "artificial"})
			if e != nil {
				t.Fatal(e)
			}
			baseline, e := previous.Run(old, f.Records, f.Header)
			if e != nil {
				t.Fatal(e)
			}
			control := Control{Kind: "provided_old106", HistoryClass: "artificial", ReferencePath: "手製派生の旧106API全最終", Books: map[string]json.RawMessage{}, WidthAudits: map[string]json.RawMessage{}, EarlyAudits: map[string]json.RawMessage{}}
			control.ReferenceSHA, e = digestValue(baseline)
			if e != nil {
				t.Fatal(e)
			}
			for _, cfg := range Configurations() {
				if cfg.Timing != "B5Q" {
					continue
				}
				k := BaseKey(cfg)
				control.Books[k], _ = json.Marshal(baseline.Books[k])
				control.WidthAudits[k], _ = json.Marshal(baseline.WidthAudits[k])
				if cfg.Policy == "E1" {
					control.EarlyAudits[k], _ = json.Marshal(baseline.EarlyAudits[k])
				}
			}
			c, e := NewCore(f.Tape, f.Output.Contract, "quiet初回取得の買売統合人工。Source自然生成の証明ではない", control)
			if e != nil {
				t.Fatal(e)
			}
			result, e := Run(c, f.Records, f.Header)
			if e != nil {
				t.Fatal(e)
			}
			shifted := 0
			for _, cfg := range result.Configs {
				b := result.Books[Key(cfg)]
				p := b.EntryOpportunities[0]
				if cfg.Timing == "B5Q" {
					if !p.Consumed || p.Requested != 0 || p.Status != "expired" || p.AssignedAt != f.Tape.Session.Start+1500 {
						t.Fatal("Bはquiet失効であるべき", Key(cfg), p)
					}
					continue
				}
				a := result.ClockAudits[Key(cfg)].Opportunities[0]
				if !a.Deferred || a.StrictAt != f.Tape.Session.Start+1500 || a.AssignedAt != f.Tape.Session.Start+1800 || a.QuietEnd != a.AssignedAt || !p.Consumed || p.Status != "accepted" || p.Requested <= 0 || p.EntryOrderID == "" || p.SourceQuantity == nil || *p.SourceQuantity <= 0 || p.SourceReserved == nil || *p.SourceReserved != 0 {
					t.Fatal("Qの繰越/存続/一実受理が不整合", Key(cfg), a, p)
				}
				fills := 0
				for _, fill := range b.Fills {
					if fill.OrderID == p.EntryOrderID {
						if fill.Action != "new" || fill.Quote.Time < a.AssignedAt+float64(cfg.Delay) || fill.Quote.Index <= p.Quote.Index {
							t.Fatal("Qの後続適格fill出典差")
						}
						fills++
					}
				}
				if fills != 1 {
					t.Fatal("Qの実新規fillが一回でない")
				}
				shifted++
			}
			after, e := digestValue(f.Records)
			if e != nil || after != streamBefore || shifted != 12 || !result.Complete || !result.BaseControl.All {
				t.Fatal("保存Stream変更/繰越12/完結/対照差")
			}
			if dir := os.Getenv("RUNTIME107_EXPORT"); dir != "" {
				value := struct {
					Scope     string          `json:"scope"`
					SourceSHA string          `json:"fixture106_sha256"`
					Tape      tape.Tape       `json:"tape"`
					Header    stream.Header   `json:"header"`
					Records   []stream.Record `json:"records"`
					Baseline  previous.Result `json:"baseline106_api"`
					Output    Result          `json:"output"`
				}{f.Tape.Scope, fixtureSHA[name], f.Tape, f.Header, f.Records, baseline, result}
				data, er := json.MarshalIndent(value, "", "  ")
				if er != nil {
					t.Fatal(er)
				}
				file, er := os.OpenFile(filepath.Join(dir, fmt.Sprintf("quiet繰越_方向%d.json", side)), os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0644)
				if er != nil {
					t.Fatal(er)
				}
				_, er = file.Write(data)
				ce := file.Close()
				if er != nil || ce != nil {
					t.Fatal(er, ce)
				}
			}
		})
	}
}

// TestControlCorruption は期待12冊を省略・改名・未知field混入で成功させないことを確認します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。破損した生JSONを型投影で捨てません。
func TestControlCorruption(t *testing.T) {
	for _, mode := range []string{"冊欠落", "幅欠落", "早期欠落", "外Key語形", "旧新時計語形", "Book未知field", "Width未知field", "Early未知field"} {
		t.Run(mode, func(t *testing.T) {
			f, control := loadFixture(t, "方向1_助走false.json")
			mutate := func(m map[string]json.RawMessage, key string) {
				v := map[string]json.RawMessage{}
				if e := json.Unmarshal(m[key], &v); e != nil {
					t.Fatal(e)
				}
				v["未定義の破損field"] = json.RawMessage(`true`)
				m[key], _ = json.Marshal(v)
			}
			switch mode {
			case "冊欠落":
				delete(control.Books, "W0_C0_D0")
			case "幅欠落":
				delete(control.WidthAudits, "W0_C0_D0")
			case "早期欠落":
				delete(control.EarlyAudits, "E1_C0_D0")
			case "外Key語形":
				control.Books["B0_C0_D0"] = control.Books["W0_C0_D0"]
				delete(control.Books, "W0_C0_D0")
			case "旧新時計語形":
				v := map[string]json.RawMessage{}
				json.Unmarshal(control.Books["W0_C0_D0"], &v)
				v["key"] = json.RawMessage(`"LD10_B5QD_P0_C0_D0"`)
				control.Books["W0_C0_D0"], _ = json.Marshal(v)
			case "Book未知field":
				mutate(control.Books, "W0_C0_D0")
			case "Width未知field":
				mutate(control.WidthAudits, "W0_C0_D0")
			case "Early未知field":
				mutate(control.EarlyAudits, "E1_C0_D0")
			}
			c, e := NewCore(f.Tape, f.Output.Contract, "破損拒否人工", control)
			if e == nil {
				_, e = Run(c, f.Records, f.Header)
			}
			if e == nil {
				t.Fatal("破損を成功へ投影", mode)
			}
		})
	}
}

// TestPreservedBinding は106由来のSource/Streamの検査が弱まっていないことを確認します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。人工の単一破損ごとに全経路を成功させないことを要求します。
func TestPreservedBinding(t *testing.T) {
	for _, mode := range []string{"Scalar", "Force", "公表", "reset", "Header", "EOF後補完"} {
		t.Run(mode, func(t *testing.T) {
			f, control := loadFixture(t, "方向1_助走false.json")
			found := false
			for i := range f.Records {
				r := &f.Records[i]
				if mode == "Scalar" && r.Kind == "quote" {
					r.Scalar.Last++
					found = true
				} else if mode == "Force" && r.Kind == "force" {
					r.Force.TapeOrdinal++
					found = true
				} else if mode == "公表" && r.Delivery != nil {
					r.Delivery.Frame.Ordinal++
					found = true
				} else if mode == "reset" && r.Kind == "reset" {
					r.Reset.Source.Bid++
					found = true
				}
				if found {
					break
				}
			}
			if mode == "Header" {
				f.Header.Records++
				found = true
			} else if mode == "EOF後補完" {
				for i := range f.Records {
					if f.Records[i].Kind == "force" {
						f.Records[i].AfterEOF, f.Records[i].Trigger = true, nil
						found = true
						break
					}
				}
			}
			if !found {
				t.Fatal("破損対象がない", mode)
			}
			c, e := NewCore(f.Tape, f.Output.Contract, "Source/全board結合破損人工", control)
			if e == nil {
				_, e = Run(c, f.Records, f.Header)
			}
			if e == nil {
				t.Fatal("破損を受理", mode)
			}
		})
	}
}

// TestConfigurationShape は候補/時計/費用順と旧内policy対応を人工確認します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。設定列を実市場の成功と見做しません。
func TestConfigurationShape(t *testing.T) {
	got := Configurations()
	if len(got) != 24 || got[0].Candidate != "B0" || got[23].Candidate != "QE" {
		t.Fatal("24順差")
	}
	for i, c := range got {
		if i < 12 && c.Timing != "B5Q" || i >= 12 && c.Timing != "B5QD" || !reflect.DeepEqual([]int{int(c.Slip), c.Delay}, [][]int{{0, 0}, {0, 1}, {5, 0}, {5, 1}}[i%4]) {
			t.Fatal(fmt.Sprint(i), c)
		}
	}
}
