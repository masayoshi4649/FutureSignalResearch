"""107固定分を変更せず、成功後の不足コードと小metadataだけを追加保存する。"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import zipfile

WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[1]
TRIAL=ROOT/'study/00107_見送り明けの初回取得と利益保護'
METADATA_SHA='c1b57d4135e17b721458f458d88fc33ed8a312678dac37158778c9264591d606'
spec=importlib.util.spec_from_file_location('107固定分の純所在口',WORK/'再現metadataを準備する.py')
M=importlib.util.module_from_spec(spec)
spec.loader.exec_module(M)


def write_new(path: Path, value: dict) -> None:
    """
    機能: 候補索引又は保存確認を新規保存する。
    引数: path (Path)、value (dict) は保存先と内容。
    返り値: None。旧ZIP/所在/停止は上書きしない。
    """
    with path.open('x',encoding='utf-8',newline='\n') as f:
        json.dump(value,f,ensure_ascii=False,indent=2)
        f.write('\n')


def publish(plan_path: Path, expected: str, output: Path) -> dict:
    """
    機能: 成功金融/保存/Viewer/xlsxの固定metadataを確認し事後不足だけを格納する。
    引数: plan_path/output (Path)、expected (str) は固定計画・新規候補先・計画SHA。
    返り値: dict は件数/指紋。Native/価格/公表列/経済結果の解析・再実行はしない。
    """
    assert M.sha(WORK/'再現metadataを準備する.py')==METADATA_SHA
    assert not output.exists() and M.sha(plan_path)==expected
    p=M.read(plan_path)
    assert p['version']==1 and p['trial']==107 and p['fixed'] is True and p['phase']=='postprocess_full70' and p['pending']==[]
    inputs={str(plan_path):expected,str(Path(__file__).resolve()):M.sha(Path(__file__)),str(WORK/'再現metadataを準備する.py'):METADATA_SHA}
    paths={k:M.bind(p[k],plan_path.parent,inputs) for k in ('condition','financial_completion','summary','saved_check','viewer','xlsx_check','prior_index','prior_closure')}
    c,d,s,index,closed=[M.read(paths[k]) for k in ('condition','financial_completion','saved_check','prior_index','prior_closure')]
    assert p['condition']['sha256']==M.CONDITION_SHA and p['financial_completion']['sha256']=='80faf888eda44badca7cdc0f5fb70aa7354b3dcc4c771411df18fe10409d3c01'
    assert p['prior_index']['sha256']=='d0460b56968bd0b3af1b1af125c7688668199284bbb550026649bf6ed26f5942' and index['phase']=='fixed_code_only'
    assert p['prior_closure']['sha256']==M.CLOSURE106_SHA and closed['試行完了'] is True
    manifest=M.read(M.bind(c['input_manifest'],paths['condition'].parent,inputs))
    M.verify_success(c,d,s,[x['id'] for x in manifest['sessions']],M.CONDITION_SHA,p['financial_completion']['sha256'],p['summary']['sha256'])
    viewer=M.read(paths['viewer']);xlsx=M.read(paths['xlsx_check'])
    assert viewer.get('成功',viewer.get('success')) is True and (viewer['一覧'],viewer['実GET'])==(1680,24) and xlsx['成功'] is True
    assert p['viewer']['sha256']=='a30d0cf474918407beb89091d39bba3e0f8d38b214990af573d596099f43fefc'
    assert p['xlsx_final_sha256']=='899a0b5558464744f235b3e3d0e1208bcc7547a27d2a39f7ebc04c78c77b3323'
    assert xlsx['最終ブックSHA256']==p['xlsx_final_sha256'] and xlsx['marker']['実行回数']==1 and xlsx['旧single107編集CLI実行']==0
    assert (xlsx['実Table'],xlsx['各データ行'],xlsx['全行'])==(24,70,1680) and xlsx['前後不変'] is True and xlsx['入力SHA256前']==xlsx['入力SHA256後']
    items=M.collect(p,c,plan_path,index,paths['prior_index'],inputs)
    libraries={str((plan_path.parent/x).resolve()) for x in p['pure_library_dependencies']}
    for item in items:
        if str(Path(item['original_path']).resolve()) in libraries:
            item['roles'].append('新6sheetの純射影/読取ライブラリ依存。旧single編集CLIは未実行')
    # ----------------------------------------
    # 固定分を含む旧archiveの全参照を認証し、同SHAの不足entryだけを格納する。
    archives={}
    for item in items:
        loc=item['location']
        if loc['kind']=='既存archive':
            q=(TRIAL/loc['archive']['path']).resolve()
            if q not in archives:
                assert M.sha(q)==loc['archive']['sha256']
                inputs[str(q)]=loc['archive']['sha256']
                archives[q]=[]
            archives[q].append(item)
    for q,rows in archives.items():
        with zipfile.ZipFile(q) as z:
            assert z.testzip() is None
            cache={}
            for item in rows:
                name=item['location']['entry'];assert M.OLD.safe(name)
                if name not in cache:cache[name]=hashlib.sha256(z.read(name)).hexdigest()
                assert cache[name]==item['SHA256']
    missing,by_sha={},{}
    for item in items:
        if item['location']['kind']=='新archive候補':
            name=by_sha.setdefault(item['SHA256'],item['location']['entry'])
            item['location']={'kind':'新archive','entry':name}
            missing.setdefault(name,item)
    output.mkdir(parents=True)
    target=output/'再現コード_不足分.zip'
    with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,item in sorted(missing.items()):
            assert M.OLD.safe(name) and item['restore']['root']!='goRoot'
            path=Path(item['original_path'])
            assert path.suffix.lower() not in ('.exe','.gz','.csv','.xlsx','.png') and M.sha(path)==item['SHA256']
            z.write(path,name)
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(missing)
        assert all(hashlib.sha256(z.read(name)).hexdigest()==item['SHA256'] for name,item in missing.items())
    after={name:M.sha(Path(name)) for name in inputs}
    assert after==inputs
    zip_ref={'path':target.name,'sha256':M.sha(target),'bytes':target.stat().st_size}
    result={'成功':True,'試行':107,'phase':'postprocess_full70','計画SHA256':expected,'金融条件':p['condition'],'固定code数':1032,
            '全所在数':len(items),'新ZIP':zip_ref,'新entry数':len(missing),'所在区分':dict(Counter(x['location']['kind'] for x in items)),
            'roots':index['roots'],'Go環境':index['Go環境'],'entries':items,'失敗由来':index['失敗由来'],'起動失敗由来':index['起動失敗由来'],
            '固定分索引':p['prior_index'],'純ライブラリ依存':'旧single eb28は入力射影/読取でのみ再用。実xlsx編集は候補別44e1の1回',
            '除外':index['除外'],'入力SHA256前':inputs,'入力SHA256後':after,'前後不変':True,'金融再実行/Raw/公表列複製/Native解析':0,'試行閉鎖':False}
    idx=output/'再現コードの所在.json';write_new(idx,result)
    proof={'成功':True,'試行':107,'計画SHA256':expected,'固定code1032所在欠落':0,'全所在数':len(items),'新entry数':len(missing),
           '新ZIP':zip_ref,'索引SHA256':M.sha(idx),'CRC差/entrySHA差/危険path':0,'旧archive前後不変':True,'入力前後不変':True,
           '金融/Source/Bank/Viewer/xlsx再実行':0,'正式配置':False}
    write_new(output/'再現コード保存の確認.json',proof)
    return {'成功':True,'全所在数':len(items),'新entry数':len(missing),'ZIP_SHA256':zip_ref['sha256'],'索引SHA256':M.sha(idx)}


def main() -> None:
    """
    機能: Root事後固定計画のSHAを受けて不足コード候補だけを生成する。
    引数: CLI plan/out (Path)、plan-sha (str) は計画/新規先/指紋。
    返り値: None。旧正式物を編集しない。
    """
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan',type=Path,required=True);parser.add_argument('--plan-sha',required=True);parser.add_argument('--out',type=Path,required=True)
    a=parser.parse_args()
    print(json.dumps(publish(a.plan.resolve(),a.plan_sha,a.out.resolve()),ensure_ascii=False))


if __name__=='__main__':
    main()
