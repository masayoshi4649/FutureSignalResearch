"""成功済み107金融Nativeの圧縮bytesだけを正式保存し、本文を解析しない。"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import shutil

WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[1]
TRIAL=ROOT/'study/00107_見送り明けの初回取得と利益保護'
COMPLETION=ROOT/'work/107市場/埋込対応_全70場/完了.json'
COMPLETION_SHA='80faf888eda44badca7cdc0f5fb70aa7354b3dcc4c771411df18fe10409d3c01'
CONDITION=TRIAL/'金融条件_埋込対応.json'
CONDITION_SHA='4ab51b9fadc6745ac25597b09365062b629ce329e88507f261fbc0f0760cab97'
FIRST2_SHA='489ac8057c9dc308ca0dba53cb46a7d7e6bce2d3cf6ffe02b1a9258169810ed1'


def sha(path: Path) -> str:
    """
    機能: コード・小metadata・圧縮Nativeの内容指紋を確認する。
    引数: path (Path) は許可済みファイル。
    返り値: str はSHA256。gzipは解凍せず圧縮bytesだけを読む。
    """
    with path.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()


def read(path: Path) -> dict:
    """
    機能: 条件/完了/参照台帳の小metadataを読む。
    引数: path (Path) はJSON metadata。
    返り値: dict は内容。Nativeに対しては呼ばない。
    """
    return json.loads(path.read_text(encoding='utf-8-sig'))


def resolve(ref: dict, base: Path) -> Path:
    """
    機能: FileRefを親基準又は絶対pathへ解決する。
    引数: ref (dict)、base (Path) は参照と基準。
    返り値: Path は絶対path。ここでは本文を開かない。
    """
    assert set(ref)=={'path','sha256'} and ref['path'] and re.fullmatch('[0-9a-f]{64}',ref['sha256'])
    return (base/ref['path']).resolve()


def relative(path: Path) -> str:
    """
    機能: 正式試行dirを基準に参照pathを表す。
    引数: path (Path) は参照対象。
    返り値: str は区切りを統一した相対path。
    """
    return os.path.relpath(path,TRIAL).replace('\\','/')


def write_new(path: Path, value: dict) -> None:
    """
    機能: 保存台帳又は確認metadataを新規作成する。
    引数: path (Path)、value (dict) は出力先と内容。
    返り値: None。既存ファイルは上書きしない。
    """
    with path.open('x',encoding='utf-8',newline='\n') as f:
        json.dump(value,f,ensure_ascii=False,indent=2)
        f.write('\n')


def main() -> None:
    """
    機能: 全70成功・先頭2継承をmetadataで認証しNative70本を同体保存する。
    引数: なし。Rootが指定した条件/完了SHAと正式dirを定数として使う。
    返り値: None。Source/価格/公表列の複製や金融再実行は行わない。
    """
    inputs={str(CONDITION):CONDITION_SHA,str(COMPLETION):COMPLETION_SHA,str(Path(__file__).resolve()):sha(Path(__file__))}
    assert all(sha(Path(name))==h for name,h in inputs.items())
    c,d=read(CONDITION),read(COMPLETION)
    assert (c['version'],c['trial'],c['fixed'],len(c['configs']))==(1,107,True,24)
    assert (d['version'],d['trial'],d['stage'],d['success'],d['sessions'],d['books_per_scene'],d['books'])==(1,107,'full70',True,70,24,1680)
    assert d['condition_sha256']==CONDITION_SHA and d['unchanged'] is True and d['before'] and d['before']==d['after']
    assert d['input_mode']=='recorded_public_106' and d['source_reexecuted'] is False and d['features_recomputed'] is False and d['charts_recomputed'] is False and d['cmp_recomputed'] is True and d['financial_executed'] is True
    manifest=resolve(c['input_manifest'],CONDITION.parent)
    inputs[str(manifest)]=c['input_manifest']['sha256']
    assert sha(manifest)==inputs[str(manifest)]
    ids=[x['id'] for x in read(manifest)['sessions']]
    assert len(ids)==len(set(ids))==70 and [x['session'] for x in d['results']]==ids
    first_path=resolve(d['first2'],COMPLETION.parent)
    assert d['first2']['sha256']==FIRST2_SHA and sha(first_path)==FIRST2_SHA
    inputs[str(first_path)]=FIRST2_SHA
    first=read(first_path)
    assert first['success'] is True and first['stage']=='first2' and first['trial']==107 and first['condition_sha256']==CONDITION_SHA
    assert first['sessions']==2 and first['books']==48 and first['unchanged'] is True and first['before']==first['after']
    assert len(first['results'])==2
    for a,b in zip(first['results'],d['results'][:2]):
        assert a['session']==b['session'] and a['native']['sha256']==b['native']['sha256']
        assert all(a[k]['sha256']==b[k]['sha256'] for k in ('sidecar_header','sidecar_records'))
    prior_index=ROOT/'study/00106_収束失速で保護の起動と幅を切り替える/成果物_金融/Native参照台帳.json'
    inputs[str(prior_index)]=sha(prior_index)
    prior=read(prior_index)
    assert prior['成功'] is True and prior['試行']==106 and prior['場数']==70 and [x['session'] for x in prior['Native']]==ids
    native_dir=TRIAL/'成果物_金融/Native'
    index_path=native_dir.parent/'Native参照台帳.json'
    assert not native_dir.exists() and not index_path.exists() and not (WORK/'Native保存の確認.json').exists()
    sources=[]
    for row in d['results']:
        sid=row['session']
        assert re.fullmatch(r'2026-\d{2}-\d{2}_(Day|Night)',sid)
        assert row['books']==24 and row['base_control_books']==12 and not row.get('error')
        p=resolve(row['native'],COMPLETION.parent)
        assert p.parent==COMPLETION.parent and p.name==sid+'.Native.json.gz'
        assert sha(p)==row['native']['sha256']
        inputs[str(p)]=row['native']['sha256']
        sources.append((row,p))
    assert len({p for _,p in sources})==70
    # ----------------------------------------
    # 圧縮bytesだけを複製し、公開Header/Recordと旧106Nativeは参照に残す。
    native_dir.mkdir(parents=True,exist_ok=False)
    entries=[]
    for row,p in sources:
        q=native_dir/p.name
        with p.open('rb') as source,q.open('xb') as dest:
            shutil.copyfileobj(source,dest)
        assert sha(q)==row['native']['sha256'] and q.stat().st_size==p.stat().st_size
        public={k:{'path':relative(resolve(row[k],COMPLETION.parent)),'sha256':row[k]['sha256']} for k in ('sidecar_header','sidecar_records')}
        entries.append({'session':row['session'],'path':relative(q),'sha256':row['native']['sha256'],'bytes':q.stat().st_size,'会計':24,
                        '元':{'path':relative(p),'sha256':row['native']['sha256']},'同bytes':True,'公開sidecar':public})
    after={name:sha(Path(name)) for name in inputs}
    assert after==inputs
    index={'成功':True,'試行':107,'基準':'trialdir','場数':70,'金融会計':1680,
           '元金融完了':{'path':relative(COMPLETION),'sha256':COMPLETION_SHA,'bytes':COMPLETION.stat().st_size},
           '金融条件':{'path':relative(CONDITION),'sha256':CONDITION_SHA},'Native':entries,
           'B側旧106参照の共用':{'path':relative(prior_index),'sha256':inputs[str(prior_index)],'対照会計/場':12,'新規複製':0},
           '公開sidecar':'106の元work header/records参照のみ。本文のSHA再読・複製なし。新24冊の金融fieldは圧縮bytesのまま保持',
           '金融本文JSON解析/再実行':0}
    write_new(index_path,index)
    proof={'成功':True,'scope':'成功完了の宣言SHAへNative圧縮bytesを認証し同体保存。金額の解析なし','場数':70,'会計':1680,
           'Native総bytes':sum(x['bytes'] for x in entries),'索引':{'path':relative(index_path),'sha256':sha(index_path)},
           '入力SHA256前':inputs,'入力SHA256後':after,'前後不変':True,'同bytes':70,'金融本文JSON解析/再実行/Raw/Source/公表列複製':0}
    write_new(WORK/'Native保存の確認.json',proof)
    print(json.dumps({'成功':True,'Native':70,'bytes':proof['Native総bytes'],'索引SHA256':sha(index_path),'確認SHA256':sha(WORK/'Native保存の確認.json')},ensure_ascii=False))


if __name__=='__main__':
    main()
