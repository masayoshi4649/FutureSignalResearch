"""停止済み107報告の生成/check済みbytesを正式文書と検査へ反映する。"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import subprocess
import sys

WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[1]
TRIAL=ROOT/'study/00107_見送り明けの初回取得と利益保護'
OUTPUT=ROOT/'work/107報告/最終'
CODE=ROOT/'work/107報告の準備/報告を差し替える.py'
CODE_SHA='0e1f01baa6ac06486daaa7cb63906dca2ae3a86f232c1dab0a64b9cc174e751e'
FIXED_SHA='80daaf99cca8e3bf1a71fb0bdff873ce34d6bb2bb43c6bd3184c4442e3b27a00'
ORIGINAL={'README.md':'f7ad84677aa4a553fbd3ca6b1ae9579295f54615ec12728f47a479e32474bc4e','設定と結果.md':'3e7ac70a96567ad3025dda16d743498f41447e18015993d58ca5c89b2add1d16'}


def sha(path: Path) -> str:
    """
    機能: コード/文書/小metadataの指紋を確認する。
    引数: path (Path) は対象。
    返り値: str はSHA256。金融Nativeには呼ばない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_new(path: Path, data: bytes) -> None:
    """
    機能: 原計画又は検査資料を新規作成する。
    引数: path (Path)、data (bytes) は出力先と認証済み内容。
    返り値: None。既存ファイルの上書きを拒否する。
    """
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as f:f.write(data)


def main() -> None:
    """
    機能: 報告check→原計画保存→ライブ二文書更新→同体確認を行う。
    引数: なし。Root固定の報告条件/停止code/生成先を使用する。
    返り値: None。Source/金融/API/xlsxや売買条件は実行・変更しない。
    """
    fixed=TRIAL/'報告条件.json'
    assert sha(CODE)==CODE_SHA and sha(fixed)==FIXED_SHA
    args=[sys.executable,'-B','-X','utf8',str(CODE),'--fixed',str(fixed.resolve()),'--fixed-sha',FIXED_SHA,'--out',str(OUTPUT.resolve()),'--check']
    p=subprocess.run(args,capture_output=True,text=True,encoding='utf-8',check=False)
    assert p.returncode==0,p.stderr
    check=json.loads(p.stdout)
    assert check['成功'] is True and check['check'] is True and check['codeSHA256']==CODE_SHA
    originals={name:(TRIAL/name).read_bytes() for name in ORIGINAL}
    assert all(hashlib.sha256(b).hexdigest()==ORIGINAL[name] for name,b in originals.items())
    assert all((OUTPUT/'原計画'/name).read_bytes()==b for name,b in originals.items())
    guard={name:h for name,h in check['入力SHA256'].items()}
    guard[str(Path(__file__).resolve())]=sha(Path(__file__))
    assert all(sha(Path(name))==h for name,h in guard.items())
    destinations={}
    for name,b in originals.items():
        q=TRIAL/'原計画'/name
        write_new(q,b)
        destinations[str(q.relative_to(TRIAL))]=sha(q)
    for name in ORIGINAL:
        q=TRIAL/name
        q.write_bytes((OUTPUT/name).read_bytes())
        assert q.read_bytes()==(OUTPUT/name).read_bytes()
        destinations[name]=sha(q)
    q=TRIAL/'検査/報告/結果欄の値.json'
    write_new(q,(OUTPUT/'結果欄の値.json').read_bytes())
    destinations[str(q.relative_to(TRIAL))]=sha(q)
    assert all(sha(Path(name))==h for name,h in guard.items())
    value={'成功':True,'試行':107,'scope':'固定保存集計の報告生成/check後の同bytes正式反映','報告条件SHA256':FIXED_SHA,'報告コードSHA256':CODE_SHA,
           '停止codeによるcheck':check,'出力SHA256':destinations,'原計画SHA256':ORIGINAL,
           '正式README/設定の生成bytes一致':True,'原計画同bytes':True,'55x9/S13K12/R24保持':True,
           '入力SHA256前':guard,'入力SHA256後':guard,'前後不変':True,'Raw/Native/Source/金融/API/xlsx':0,
           '留保':'24黒字と25/50参加・夜間条件、採用、未見安定性、研究目標は別。20分条件は混入しない'}
    q=TRIAL/'検査/報告/報告生成の確認.json'
    write_new(q,(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    print(json.dumps({'成功':True,'正式出力SHA256':destinations,'報告確認SHA256':sha(q)},ensure_ascii=False))


if __name__=='__main__':
    main()
