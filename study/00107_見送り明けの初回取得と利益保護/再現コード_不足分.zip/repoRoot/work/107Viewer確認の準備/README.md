# 107の一覧1680と固定代表24GETの準備

今回は手製metadataと応答型だけ。実HTTP、catalog load/登録、Rootの市場保存結果本文読取、描画、Viewerの停止・再起動・再設定は0。既存8092/PID19844は操作しない。

固定106のRoot helper `work/106進行/Viewerの20資源を確認する.py`（b068）をSHA確認してimportし、`request`関数をそのまま使う。小数はDecimal、応答のx-chart-data-sha256があれば本文SHAと照合する。金融・Source・Raw・新しい約定器は呼ばない。

対象は保存形式の全1680資源の一意集合とcatalog load後の同ID集合。数値GETは、成績で選ばず先頭 `2026-09-21_Day` の24設定（B0/B1/BE/Q0/Q1/QE各C0D0/C0D1/C5D0/C5D1）に事前固定する。全1680資源の表示・全24描画・ブラウザ目視を検証したとは呼ばない。

GETでは旧106と同じ、資源ID、保存場別の費用後実現純額、実trades行数、最終long/short/未実現残0を確認する。選択24tradesは保存checkのSHAへ結び、通信前後不変を確認する。全一覧のnamespace/title/mini単価100/実trades形式/対応24×70を確認する。約定・fee/slipの金融算術は停止保存器の検算であり、Viewer helperが再金融したことにはしない。

Rootが全70金融・保存成功後に次を実SHAで封印し、別途実行指示を出すまで実行しない。

```json
{
  "version": 1, "trial": 107, "fixed": false,
  "stage": "full70", "saved_ready": false,
  "selected_session": "2026-09-21_Day",
  "condition": {"path": "107条件.json", "sha256": "未固定"},
  "completion": {"path": "107全70金融完了.json", "sha256": "未固定"},
  "summary": {"path": "107結果.json", "sha256": "未固定"},
  "saved_check": {"path": "107保存会計の確認.json", "sha256": "未固定"},
  "catalog": {"path": "107一覧.resources.json", "sha256": "未固定"},
  "code": {"path": "Viewerを確認する.py", "sha256": "未固定"}
}
```

FileRefはこの固定JSONのparent基準。金融/保存の全70・1680・同条件/完了SHA、保存結果/一覧SHA、全入力code前後不変を確認してから、info GET→catalogs/load POST→選択24data GETだけを送る。processや設定APIは使わない。最大4並列は旧helperと同じ。

```powershell
python -B -X utf8 work/107Viewer確認の準備/Viewerを確認する.py `
  --run --fixed <Root成功固定JSON> --fixed-sha <そのSHA256> --out <新規Viewer証拠.json>
```

結果scopeは「全1680一覧の整合と事前固定2026-09-21_Dayの24設定GET」。実GET24と入力SHA前後を記録する。Viewerサーバーが既存価格参照を使うことを、ローカルでRawや新金融を再実行したと混同しない。

人工は価格なしの1680 metadataと24選択、半円応答型正常、metadata7拒否・応答4拒否まで。実市場結果・HTTPの成功は未実施。新たな採用基準や損益に基づく資源選別は行わない。
