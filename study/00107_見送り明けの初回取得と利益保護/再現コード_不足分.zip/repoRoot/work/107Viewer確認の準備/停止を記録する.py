"""実HTTPを呼ばずViewer準備コードと手製metadata成功を停止へ結ぶ。"""
from pathlib import Path
import hashlib
import json


def sha(path):
    """
    機能: 明示した小型コード又は人工証拠の指紋を求める。
    引数: path(Path)は対象位置。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    """
    機能: 実HTTP0の準備だけを新規停止保存する。
    引数: なし。
    返り値: なし。旧helper差や停止の上書きは拒否する。
    """
    work = Path(__file__).resolve().parent
    repo = work.parents[1]
    stop = work / "停止.json"
    assert not stop.exists()
    old = repo / "work/106進行/Viewerの20資源を確認する.py"
    expected = "b068ddffee9884109a1d5a18306700735327c2dd7e85fd3c4fe237107051f315"
    assert sha(old) == expected
    artificial = work / "人工確認.json"
    proof = json.loads(artificial.read_text(encoding="utf-8"))
    assert proof["成功"] and len(proof["metadata拒否"]) == 7 and len(proof["応答拒否"]) == 4 and proof["HTTP/登録/描画/サーバー操作"] == 0
    names = ["Viewerを確認する.py", "人工検査.py", "README.md", "停止を記録する.py"]
    value = {"成功": True, "scope": "107 Viewerのmetadata/応答型準備。実1680一覧loadと24GETは未実施",
             "所有コードSHA256": {str((work / n).relative_to(repo)).replace("\\", "/"): sha(work / n) for n in names},
             "旧106helper_SHA256": expected, "人工SHA256": sha(artificial), "一覧予定": 1680, "実GET予定": 24,
             "固定対象場": "2026-09-21_Day", "metadata拒否": 7, "応答拒否": 4,
             "HTTP/登録/描画/サーバー操作": 0, "市場/Raw/Tape/Native本文読取": 0, "旧コード変更": 0,
             "実行条件": "Root全70保存成功後の6FileRefと明示実行指示", "未実施": ["実1680一覧整合", "先頭Day24の実GET", "全描画/ブラウザ視認は対象外"]}
    with stop.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"成功": True, "停止": str(stop), "SHA256": sha(stop), "ViewerコードSHA256": sha(work / "Viewerを確認する.py")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
