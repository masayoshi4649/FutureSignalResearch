"""価格を持たない手製metadataとAPI応答型だけで107Viewer準備を確認する。"""
import copy
from datetime import date, timedelta
from decimal import Decimal
import importlib.util
import json
from pathlib import Path


def main():
    """
    機能: 1680一覧と事前固定24選択、半円応答型・破損拒否を人工確認する。
    引数: なし。Rootの実保存結果もHTTPも使用しない。
    返り値: なし。小型JSONをworkへ保存する。
    """
    root = Path(__file__).resolve().parent
    spec = importlib.util.spec_from_file_location("107Viewerの非市場型人工", root / "Viewerを確認する.py")
    v = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(v)
    ids = [(date(2026, 9, 21)+timedelta(days=i//2)).isoformat()+("_Day" if i%2 == 0 else "_Night") for i in range(70)]
    complete = {"version": 1, "trial": 107, "stage": "full70", "success": True, "sessions": 70, "books": 1680, "books_per_scene": 24,
                "unchanged": True, "before": {"手製code": "a"*64}, "after": {"手製code": "a"*64}, "condition_sha256": "b"*64}
    base = {"前後不変": True, "入力codeSHA256前": {"手製code": "a"*64}, "入力codeSHA256後": {"手製code": "a"*64}, "completionSHA256": "c"*64, "conditionSHA256": "b"*64}
    summary = {**base, "試行": 107, "成功": True, "stage": "full70", "場数": 70, "会計数": 1680,
               "場別": [{"session": s, "key": k, "net_yen": Decimal("0.5")} for s in ids for k in v.KEYS]}
    check = {**base, "成功": True, "会計": 1680, "資源": 1680, "不一致数": 0, "出力SHA256": {"結果.json": "d"*64, "一覧.resources.json": "e"*64}}
    resources = []
    for sid in ids:
        for key in v.KEYS:
            identity = f"107_{key}_{sid}"
            resources.append({"id": identity, "title": f"見送り繰越と利益保護 {key} {sid}", "session": sid, "method_id": key,
                              "symbol": "NK225", "product": "NK225mini", "point_value": 100, "pnl_format": "trades", "pnl_basis": "net", "pnl_path": identity+".trades.jsonl"})
    catalog = {"schema_version": 1, "path_base": "catalog", "resources": resources}
    args = [complete, summary, check, catalog, "b"*64, "c"*64, "d"*64, "e"*64]
    listed, selected = v.validate_values(*args)
    assert len(listed) == 1680 and len(selected) == 24
    assert [r[0]["id"] for r in selected] == [f"107_{k}_{v.SESSION}" for k in v.KEYS]
    rejected = []
    mutations = {"金融未完": lambda a: a[0].update(success=False), "冊数欠落": lambda a: a[0].update(books=1679),
                 "保存別条件": lambda a: a[2].update(conditionSHA256="f"*64), "別保存一覧": lambda a: a[2]["出力SHA256"].update({"一覧.resources.json": "f"*64}),
                 "一覧重複": lambda a: a[3]["resources"].__setitem__(1, a[3]["resources"][0]),
                 "別namespace": lambda a: a[3]["resources"][0].update(id="106_旧名"), "枚数単価違い": lambda a: a[3]["resources"][0].update(point_value=1000)}
    for name, mutate in mutations.items():
        bad = copy.deepcopy(args)
        mutate(bad)
        try:
            v.validate_values(*bad)
        except AssertionError:
            rejected.append(name)
        else:
            raise AssertionError("破損metadata受理: "+name)
    response = {"resource": {"id": selected[0][0]["id"]}, "summary": {"realized_pnl_yen": Decimal("0.5"), "long_qty": 0, "short_qty": 0, "unrealized_pnl_yen": 0}, "events": [{}, {}]}
    v.verify_response(response, response["resource"]["id"], Decimal("0.5"), 2)
    api_reject = []
    for name, mutate in (("純額半円差", lambda x: x["summary"].update(realized_pnl_yen=Decimal("1.0"))), ("最終残", lambda x: x["summary"].update(long_qty=1)), ("別資源", lambda x: x["resource"].update(id="別ID")), ("実Fill行不足", lambda x: x.update(events=[{}]))):
        bad = copy.deepcopy(response)
        mutate(bad)
        try:
            v.verify_response(bad, response["resource"]["id"], Decimal("0.5"), 2)
        except AssertionError:
            api_reject.append(name)
        else:
            raise AssertionError("破損応答受理: "+name)
    proof = {"成功": True, "scope": "手製metadata/応答型だけ。実1680保存/GET/価格/金融ではない", "手製一覧": 1680, "固定24選択": True,
             "metadata拒否": rejected, "半円型": True, "応答拒否": api_reject, "HTTP/登録/描画/サーバー操作": 0}
    with (root / "人工確認.json").open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(proof, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"成功": True, "metadata拒否": len(rejected), "応答拒否": len(api_reject), "HTTP": 0}, ensure_ascii=False))


if __name__ == "__main__":
    main()
