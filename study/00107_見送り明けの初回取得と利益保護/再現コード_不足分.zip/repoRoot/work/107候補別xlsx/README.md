# 107の候補ごとに全セッションを表示する6シート版

ユーザーの「候補ごとにシート、全セッションの損益と収支をテーブルへ」に対応する新準備。単一既存ブック69509c・旧5タブを保ち、新シートはB0/B1/BE/Q0/Q1/QEの6枚のみ。旧single107準備e439/eb28は変更せず、実編集もしていない。今回もmarker・xlsx編集/export・107市場結果本文読取は0。

各シートはC0D0（主条件）/C0D1/C5D0/C5D1の4つの実Excel Table。各表に時系列70場、0取引の場も行を残す。列順は共通で、開始日・Day/Night・新規件数（実取得建玉）・新規枚数・粗損益・手数料・仮定追加滑り・費用後純損益・累計収支・参加枠・分母・参加率。70件と列合計を各表直後へ置く。

累計は各候補×費用条件ごとに0から始め、当該表の純額列からSUM式にする。合計欄の累計は最後の累計へ参照する。0取引を落としたり、他費用の累計へ持ち越さない。フィルタ後も全70時系列での累計を維持する。新規件数/枚数は毎回10枚固定を意味しない。

各sheet上部にB/Q対照関係、W0/W1/E1の保護差、既使用35日70場、手数料片道38.5円、片側上限10枚の可変数量、C5/D1仮定、今回30分静観固定を置く。20分案は今回固定条件へ混ぜない。旧single版の36比較や公表診断は転記せず、グラフや概要tabも増やさない。

## 再用と現在の確認

旧107 `prepareTables` と日付/OOXML読取QAをSHA確認して再用。旧builderのCLIを誤起動しない専用flagを使い、旧`--append`/`--review`は新builderで拒否する。authoringはbundled Nodeの `@oai/artifact-tool` だけ。node_modulesはキャッシュへのwork内junction。

停止の手製1場24会計を6候補4条件へ接続し、追加の小さな配列で0行保持・半円純額・累計・条件内リセットを確認した。人工は1場のままで70場へ水増ししない。旧5タブの現ブックは読取確認のみ、SHA69509c不変。人工全組合せや新金融検査は増やしていない。

TableStyleMedium2、フィルタ、固定枠、金額/日付型をコードに設定する。実Table/行縞・新6シート描画はまだ未実施で、Root成功後の実exportでOOXML・画像を検査する。

## Root成功後の実行

金融full70/保存/Viewerの成功後、旧準備と同じ5Refs（code/summary/financial_completion/saved_check/viewer_evidence）＋4成功flags＋viewer_scopeを実SHAでRootが封印する。codeだけこの新builderを指す。実編集指示後、最初の編集コマンド直前にmarker edit/1xlsxを一度実行する。今回は未実行。

```powershell
& <bundled-node> work/107候補別xlsx/候補別に追記する.mjs `
  --append-candidates <Rootの実行固定JSON> <そのSHA256>
python -B -X utf8 work/107候補別xlsx/保存後を確認する.py `
  --source <同じ正本結果.json> --source-sha <そのSHA256> --out <新規QA.json>
```

同じxlsxへ一回export。保存後QAは旧5の全セル/式/型/書式/構造/旧8図表部品を保持し、新24 Tableの範囲/フィルタ/行縞・70件・全1680行12列の正本値・数量・参加・累計式・末尾合計を照合する。t=dのISO UTC午前0時又は従来数値serialは既知QAを再用する。

6シートそれぞれ先頭と最終表末尾のPNGを出し、実視認とQA成功後に完成とする。今回の準備成功を実ブック成功に拡張しない。Raw/Native/新金融/Source/HTTPの実行は0。
