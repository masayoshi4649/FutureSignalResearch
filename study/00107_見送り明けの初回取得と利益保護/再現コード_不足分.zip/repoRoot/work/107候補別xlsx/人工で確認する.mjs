/**
 * 停止射影の一手製型と0行/累計リセットだけを確認する。
 * @param {string[]} process.argv - 追加引数なし。
 * @returns {Promise<void>} 純配列の確認。marker/xlsx編集/exportは0。
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {prepareCandidateSheets,sessionTable,CANDIDATES,BOOK,BOOK_SHA} from './候補別に追記する.mjs';
const work=import.meta.dirname,repo=path.resolve(work,'../..'),source=path.join(repo,'work/107xlsx追記の準備/人工入力/quiet繰越_方向1.json');
const before=crypto.createHash('sha256').update(await fs.readFile(BOOK)).digest('hex');assert.equal(before,BOOK_SHA);
const result=JSON.parse(await fs.readFile(source,'utf8')),tables=prepareCandidateSheets(result,true);assert.equal(Object.keys(tables.sheets).length,6);for(const p of CANDIDATES){assert.equal(tables.sheets[p].length,4);for(const t of tables.sheets[p]){assert.equal(t.rows.length,1);assert.equal(t.rows[0][8],t.summary.net_yen);assert.ok(t.rows[0][0]instanceof Date);}}
const d=new Date('2026-09-21T00:00:00.000Z'),zero=[d,'日中','手製','B0','C0/D0',0,0,0,0,0,0,0,76,0],positive=[d,'夜間','手製','B0','C0/D0',77.5,77,0,.5,1,1,1,148,1/148],negative=[d,'日中','手製','B0','C0/D0',66.5,77,0,-10.5,1,1,1,76,1/76];const sourceRows=[zero,positive,negative,zero],original=structuredClone(sourceRows),rows=sessionTable(sourceRows);assert.equal(rows.length,4);assert.deepEqual(rows.map(r=>r[8]),[0,.5,-10,-10]);assert.equal(rows[0][2],0);assert.equal(rows[3][3],0);assert.equal(sessionTable([positive])[0][8],.5);assert.deepEqual(sourceRows,original);assert.throws(()=>prepareCandidateSheets(result));assert.equal(crypto.createHash('sha256').update(await fs.readFile(BOOK)).digest('hex'),before);
await fs.writeFile(path.join(work,'人工確認.json'),JSON.stringify({成功:true,停止型24会計の6候補4条件:true,型人工は1場のまま:true,'0取引行保持':true,半円純額と累計:true,条件ごとの累計リセット:true,人工市場偽装拒否:true,元ブックSHA256:before,marker_xlsx編集_export:0},null,2));
