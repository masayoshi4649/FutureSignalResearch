"""旧日付/OOXML読取QAを再用し、候補別6×4×70の全値と累計を確認する。"""
import argparse
from decimal import Decimal
import hashlib
import importlib.util
import json
from pathlib import Path
import xml.etree.ElementTree as ET

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
PRIOR_PATH = ROOT / "work/107xlsx追記の準備/保存後を確認する.py"
assert hashlib.sha256(PRIOR_PATH.read_bytes()).hexdigest() == "fc0c1af7deef9f13233f24a6cf581df4e810fefee93e5d6b34d6a2610084b0fa"
SPEC = importlib.util.spec_from_file_location("候補別107が再用する日付と正本射影", PRIOR_PATH)
QA = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(QA)
CANDIDATES = ["B0", "B1", "BE", "Q0", "Q1", "QE"]
COSTS = [(0, 0), (0, 1), (5, 0), (5, 1)]
HEADERS = [10, 88, 166, 244]


def verify(before, after, result):
    """
    機能: 旧5を全保持し、新6sheetの24実Tableと全値/累計式を検算する。
    引数: before/after(Path)、result(dict)はRoot成功後の退避・実ブック・同正本。
    返り値: dictは保持と全行照合の件数。ブックは変更しない。
    """
    assert QA.OLD.digest(before) == QA.BASE_SHA
    a, sa, ca = QA.OLD.read_workbook(before)
    b, sb, cb = QA.OLD.read_workbook(after)
    assert list(sa) == QA.SHEETS and list(sb) == QA.SHEETS+CANDIDATES
    for name in QA.SHEETS:
        assert ca[name] == cb[name]
        assert QA.OLD.normalized_part(a, sa[name]) == QA.OLD.normalized_part(b, sb[name])
    old_parts = [p for p in a if p.startswith(("xl/charts/", "xl/drawings/", "xl/tables/"))]
    assert all(p in b and QA.OLD.normalized_part(a, p) == QA.OLD.normalized_part(b, p) for p in old_parts)
    for name in ("fonts", "fills", "borders", "cellStyleXfs", "cellXfs", "cellStyles", "dxfs", "numFmts"):
        x = ET.fromstring(a["xl/styles.xml"]).find("m:"+name, QA.OLD.NS)
        y = ET.fromstring(b["xl/styles.xml"]).find("m:"+name, QA.OLD.NS)
        if x is not None:
            assert y is not None and len(y) >= len(x) and all(ET.tostring(p) == ET.tostring(q) for p, q in zip(x, y))
    flat = QA.source_tables(result)["details"]
    native_tables = {ET.fromstring(content).attrib["name"]: ET.fromstring(content) for p, content in b.items() if p.startswith("xl/tables/") and p.endswith(".xml") and p not in a}
    assert len(native_tables) == 24
    checked = dates = 0
    for candidate in CANDIDATES:
        cells = cb[candidate]
        for (cost, delay), header in zip(COSTS, HEADERS):
            key = f"{candidate}_C{cost}_D{delay}"
            rows = [r for r in flat if r[3] == candidate and r[4] == f"C{cost}/D{delay}"]
            assert len(rows) == 70
            first, last = header+1, header+70
            table = native_tables["T107_"+key]
            assert table.attrib["ref"] == f"A{header}:L{last}"
            assert table.find("m:autoFilter", QA.OLD.NS).attrib["ref"] == table.attrib["ref"]
            style = table.find("m:tableStyleInfo", QA.OLD.NS)
            assert style is not None and style.attrib["name"] == "TableStyleMedium2" and style.attrib.get("showRowStripes") in ("1", "true")
            balance = Decimal(0)
            for i, row in enumerate(rows, first):
                balance += row[8]
                expected = [row[0], "Day" if row[1] == "日中" else "Night", row[9], row[10], row[5], row[6], row[7], row[8], balance, row[11], row[12], row[13]]
                for j, value in enumerate(expected):
                    c = cells[chr(65+j)+str(i)]
                    if j == 0:
                        assert QA.date_value(c) == QA.date_value({"type": "d", "value": value})
                        dates += 1
                    elif j == 11:
                        assert abs(c["value"]-value) < Decimal("1e-13")
                    else:
                        assert c["value"] == value, (candidate, key, i, j)
                    checked += 1
                assert cells[f"H{i}"]["formula"][0] == f"E{i}-F{i}-G{i}"
                assert cells[f"I{i}"]["formula"][0] == f"SUM($H${first}:H{i})"
                assert cells[f"L{i}"]["formula"][0] == f"J{i}/K{i}"
            total = last+1
            summary = result["集計"][key]
            assert cells[f"B{total}"]["value"] == 70
            for col, field in (("C", "positions"), ("D", "entry_quantity"), ("E", "gross_yen"), ("F", "fee_yen"), ("G", "slip_yen"), ("H", "net_yen"), ("I", "net_yen")):
                assert cells[f"{col}{total}"]["value"] == summary[field]
            for col, field in (("J", "active"), ("K", "denom")):
                assert cells[f"{col}{total}"]["value"] == summary["活動主表"][field]
    assert not [c for cells in cb.values() for c in cells.values() if c["type"] == "e"]
    return {"成功": True, "旧5全セル": sum(len(ca[n]) for n in QA.SHEETS), "旧parts保持": len(old_parts), "新シート": 6, "実Table": 24,
            "全場行": 1680, "全値照合セル": checked, "日付": dates, "各表70件_累計と合計正本一致": True, "フィルタ_行縞": True, "marker_xlsx編集": 0}


def main():
    """
    機能: 実追記後だけ正本SHAを指定して読取QAを保存する。
    引数: --source/--source-sha/--outはRoot成功正本と新規QA先。
    返り値: なし。xlsxを編集又はexportしない。
    """
    p = argparse.ArgumentParser()
    p.add_argument("--source", type=Path, required=True)
    p.add_argument("--source-sha", required=True)
    p.add_argument("--out", type=Path, required=True)
    args = p.parse_args()
    assert QA.OLD.digest(args.source) == args.source_sha
    result = json.loads(args.source.read_text(encoding="utf-8-sig"), parse_float=Decimal)
    proof = verify(WORK / "候補別追記前.xlsx", QA.BOOK, result)
    proof.update(正本SHA256=args.source_sha, ブックSHA256=QA.OLD.digest(QA.BOOK))
    with args.out.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(proof, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps(proof, ensure_ascii=False))


if __name__ == "__main__":
    main()
