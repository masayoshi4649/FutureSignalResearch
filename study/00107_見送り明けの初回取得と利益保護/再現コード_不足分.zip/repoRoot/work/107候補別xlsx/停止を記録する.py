"""新6シート版の純人工と読取確認だけを停止へ結ぶ。"""
from pathlib import Path
import hashlib
import json


def sha(path):
    """
    機能: 明示したコード・ブックのSHA256を求める。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    """
    機能: 旧ブックと旧準備の不変を確認し新候補別版を停止する。
    引数: なし。marker・ブック編集・市場本文は読まない。
    返り値: なし。停止の上書きは拒否する。
    """
    root = Path(__file__).resolve().parent
    repo = root.parents[1]
    stop = root / "停止.json"
    assert not stop.exists()
    book = repo / "outputs/01a1889f-f2af-7943-a047-543275ee9ed2/元アルゴリズムと現行代表候補の損益比較.xlsx"
    assert sha(book) == "69509c40c1f65214322a73b27c1e94e791df3b44d35e384cff555a62a1872206"
    refs = {"work/107xlsx追記の準備/停止.json": "e4391aa0bacb1465eb75592194658ad778055027b467c2f83377842045ae9f35",
            "work/107xlsx追記の準備/107を追記する.mjs": "eb2879431c818b80737b8b5758a5e137466092f1a97669fb93f8472c2e8475b4",
            "work/107xlsx追記の準備/保存後を確認する.py": "fc0c1af7deef9f13233f24a6cf581df4e810fefee93e5d6b34d6a2610084b0fa"}
    assert all(sha(repo / p) == h for p, h in refs.items())
    names = ["候補別に追記する.mjs", "人工で確認する.mjs", "保存後を確認する.py", "README.md", "停止を記録する.py"]
    assert json.loads((root / "人工確認.json").read_text(encoding="utf-8"))["成功"]
    assert json.loads((root / "読取確認.json").read_text(encoding="utf-8"))["成功"]
    value = {"成功": True, "scope": "ユーザー指定の6候補別全セッション表の準備。実編集・新Table export・107市場本文は未実施",
             "所有コードSHA256": {str((root / n).relative_to(repo)).replace("\\", "/"): sha(root / n) for n in names},
             "元参照SHA256": refs, "人工SHA256": sha(root / "人工確認.json"), "読取SHA256": sha(root / "読取確認.json"),
             "元ブックSHA256": sha(book), "新シート": ["B0", "B1", "BE", "Q0", "Q1", "QE"], "表予定": 24, "各表予定行": 70,
             "列数": 12, "0行保持と累計リセット人工": True, "旧5タブと旧single107準備不変": True,
             "marker_xlsx編集_export_107市場本文": 0,
             "未実施": ["Root実5Refs接続", "実Table/filter/行縞export", "6シート画像視認", "旧5保持と1680行正本・累計・70件QA"]}
    with stop.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"成功": True, "停止": str(stop), "SHA256": sha(stop), "builderSHA256": sha(root / "候補別に追記する.mjs")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
