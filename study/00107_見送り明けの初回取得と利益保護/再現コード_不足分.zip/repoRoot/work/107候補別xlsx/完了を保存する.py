"""実編集一回の成功とRoot画像確認を小receiptへ結びJSONだけ正式保存する。"""
from pathlib import Path
import hashlib
import json
import shutil


def sha(path):
    """
    機能: 最終ブック・小証拠・PNGのSHA256を取得する。
    引数: path(Path)は明示した対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    """
    機能: Rootが全12PNGを確認した事実とQAを記録し、小JSON三本を同bytes保存する。
    引数: なし。この実行に金融・ブック編集・markerは含まない。
    返り値: なし。既存異体の正式先やreceipt上書きは拒否する。
    """
    work = Path(__file__).resolve().parent
    repo = work.parents[1]
    trial = repo / "study/00107_見送り明けの初回取得と利益保護"
    book = repo / "outputs/01a1889f-f2af-7943-a047-543275ee9ed2/元アルゴリズムと現行代表候補の損益比較.xlsx"
    assert sha(book) == "899a0b5558464744f235b3e3d0e1208bcc7547a27d2a39f7ebc04c78c77b3323"
    assert sha(work / "候補別追記前.xlsx") == "69509c40c1f65214322a73b27c1e94e791df3b44d35e384cff555a62a1872206"
    check = json.loads((work / "追記の確認.json").read_text(encoding="utf-8"))
    before = check["入力SHA256"]
    assert all(sha(Path(p)) == h for p, h in before.items())
    qa = work / "保存後QA_初回.json"
    assert json.loads(qa.read_text(encoding="utf-8"))["成功"]
    pngs = sorted(work.glob("*.png"))
    assert len(pngs) == 12
    receipt = work / "候補別追記の完了.json"
    assert not receipt.exists()
    mapping = {"保存後QA_初回.json": "候補別xlsxの保存後QA.json", "追記の確認.json": "候補別xlsxの追記確認.json", receipt.name: "候補別xlsxの完了.json"}
    value = {"成功": True, "scope": "ユーザー指定の候補別6sheet・全70場4条件のテーブルと累計。新金融計算なし",
             "最終ブック": str(book), "最終ブックSHA256": sha(book), "元ブックSHA256": sha(work / "候補別追記前.xlsx"),
             "Root実行固定SHA256": before[str(trial / "xlsx更新条件.json")],
             "実使用builderSHA256": sha(work / "候補別に追記する.mjs"), "実使用QA_SHA256": sha(work / "保存後を確認する.py"),
             "準備停止SHA256": sha(work / "停止.json"), "marker": {"operation_kind": "edit", "expected_output_count": 1, "output_format": "xlsx", "成功": True, "実行回数": 1},
             "実追記exec_session": 55009, "終了code": 0, "再試行": 0, "旧single107編集CLI実行": 0,
             "旧5タブ全セル保持": 41766, "旧図表parts保持": 8, "新6候補": ["B0", "B1", "BE", "Q0", "Q1", "QE"],
             "実Table": 24, "各データ行": 70, "全行": 1680, "全正本照合セル": 20160, "日付": 1680, "0建玉行保持": 24,
             "各条件累計と70件合計正本一致": True, "フィルタ_行縞_上8行固定": True, "式エラー": 0,
             "保存後QA": {"path": str(qa), "sha256": sha(qa)}, "追記確認SHA256": sha(work / "追記の確認.json"),
             "画像": {p.name: sha(p) for p in pngs}, "実視認": {"担当": "12枚全て、切れ/欠落なし", "Root": "12枚全て、見出し/説明/0行/累計/70件合計/正本表示を確認"},
             "入力SHA256前": before, "入力SHA256後": {p: sha(Path(p)) for p in before}, "前後不変": True,
             "金融_Raw_サーバー再実行": 0, "今回追加marker又は再編集": 0,
             "正式保存JSON": mapping, "画像保存": "workのみ。正式複製なし", "完了記録codeSHA256": sha(Path(__file__))}
    with receipt.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    saved = {}
    for src_name, dst_name in mapping.items():
        src, dst = work / src_name, trial / "検査" / dst_name
        assert not dst.exists() or sha(dst) == sha(src)
        if not dst.exists():
            shutil.copyfile(src, dst)
        assert sha(src) == sha(dst)
        saved[str(dst)] = sha(dst)
    assert sha(book) == value["最終ブックSHA256"]
    print(json.dumps({"成功": True, "work完了": str(receipt), "work完了SHA256": sha(receipt), "正式JSON": saved}, ensure_ascii=False))


if __name__ == "__main__":
    main()
