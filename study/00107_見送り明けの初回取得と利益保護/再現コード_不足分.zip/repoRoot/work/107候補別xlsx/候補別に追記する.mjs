/**
 * 既存5タブへ候補別6シートだけを追加する準備コード。
 * @param {string[]} process.argv - --review-candidates又は将来の--append-candidates fixedPath SHA。
 * @returns {Promise<void>} Root成功後だけ同じxlsxを更新する。
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {FileBlob,SpreadsheetFile} from '@oai/artifact-tool';

const WORK=import.meta.dirname,ROOT=path.resolve(WORK,'../..');
const PRIOR_PATH=path.join(ROOT,'work/107xlsx追記の準備/107を追記する.mjs');
const PRIOR_SHA='eb2879431c818b80737b8b5758a5e137466092f1a97669fb93f8472c2e8475b4';
if(process.argv.some(a=>a==='--append'||a==='--review'))throw Error('旧builderのCLI名は使いません');
assert.equal(crypto.createHash('sha256').update(await fs.readFile(PRIOR_PATH)).digest('hex'),PRIOR_SHA);
const PRIOR=await import('../107xlsx追記の準備/107を追記する.mjs');
export const {BOOK,BOOK_SHA,OLD_SHEETS}=PRIOR;
export const CANDIDATES=['B0','B1','BE','Q0','Q1','QE'];
export const COSTS=[[0,0],[0,1],[5,0],[5,1]];
export const HEADERS=['開始日','Day/Night','新規件数（実取得建玉）','新規枚数','粗損益（円）','手数料（円）','仮定追加滑り（円）','費用後純損益（円）','累計収支（円）','参加枠','分母','参加率'];
export const HEADER_ROWS=[10,88,166,244];
const DEFINITIONS={B0:['旧B5Q。Q0が同じ保護の繰越時計対照。','W0：通常LD10水準で起動し、2ATR追尾。'],B1:['旧B5Q。Q1が同じ保護の繰越時計対照。','W1：LD10起動後、C&M警戒で1ATRへ狭幅。'],BE:['旧B5Q。QEが同じ保護の繰越時計対照。','E1：通常LD10又はLD05水準＋C&Mで早期起動、警戒で1ATR。'],Q0:['B5QD。B0が同じ保護の旧時計対照。quiet内の割当だけ一回繰越。','W0：通常LD10水準で起動し、2ATR追尾。'],Q1:['B5QD。B1が同じ保護の旧時計対照。quiet内の割当だけ一回繰越。','W1：LD10起動後、C&M警戒で1ATRへ狭幅。'],QE:['B5QD。BEが同じ保護の旧時計対照。quiet内の割当だけ一回繰越。','E1：通常LD10又はLD05水準＋C&Mで早期起動、警戒で1ATR。']};

/**
 * 小入力のSHAを求める。
 * @param {Uint8Array|string} bytes - 対象。
 * @returns {string} SHA256。
 */
function sha(bytes){return crypto.createHash('sha256').update(bytes).digest('hex');}

/**
 * 一条件内の時系列行を0取引も保持して表へ写す。
 * @param {Array[]} details - 停止済み107射影の場別行。
 * @returns {Array[]} 日付・数量・実額・当条件だけの累計・活動の12列。
 */
export function sessionTable(details){let balance=0;return details.map(r=>{balance+=r[8];return [r[0],r[1]==='日中'?'Day':'Night',r[9],r[10],r[5],r[6],r[7],r[8],balance,r[11],r[12],r[13]];});}

/**
 * 旧107の実型検査/射影を再用し、6候補×4条件だけを取り出す。
 * @param {Object} result - Root成功後の保存正本又は限定手製1場型。
 * @param {boolean} artificial - 型人工だけか。市場ではfalse。
 * @returns {Object} 各sheet4表。比較36や公表診断は再転記しない。
 */
export function prepareCandidateSheets(result,artificial=false){
 const flat=PRIOR.prepareTables(result,artificial),count=flat.sessions.length,sheets={};
 if(!artificial){assert.equal(count,70);assert.equal(new Set(flat.sessions.map(s=>s.slice(0,10))).size,35);}
 for(const candidate of CANDIDATES){sheets[candidate]=COSTS.map(([c,d],i)=>{const key=`${candidate}_C${c}_D${d}`,rows=sessionTable(flat.details.filter(r=>r[3]===candidate&&r[4]===`C${c}/D${d}`)),summary=result['集計'][key];assert.equal(rows.length,count);for(const [col,field]of [[2,'positions'],[3,'entry_quantity'],[4,'gross_yen'],[5,'fee_yen'],[6,'slip_yen'],[7,'net_yen']])assert.equal(rows.reduce((s,r)=>s+r[col],0),summary[field],key+'/'+field);assert.equal(rows.at(-1)[8],summary.net_yen);assert.equal(rows.reduce((s,r)=>s+r[9],0),summary['活動主表'].active);assert.equal(rows.reduce((s,r)=>s+r[10],0),summary['活動主表'].denom);return {key,cost:c,delay:d,header:HEADER_ROWS[i],rows,summary};});}
 return {sheets,sessions:flat.sessions};
}

/**
 * 旧5タブの値・式・図参照を保持基準にする。
 * @param {Object} book - Artifact Workbook。
 * @returns {Array} 旧5だけの基準。
 */
function snapshot(book){return OLD_SHEETS.map(name=>{const s=book.worksheets.getItem(name),r=s.getUsedRange();return {name,values:r.values,formulas:r.formulas,charts:s.charts.items.map(c=>({type:c.type,title:c.title.text,series:c.series.items.map(x=>({formula:x.formula,categoryFormula:x.categoryFormula}))}))};});}

/**
 * FileRefをRoot固定SHAへ結ぶ。
 * @param {Object} ref - path/sha256。
 * @param {string} base - 固定JSON基準。
 * @param {Map} before - 前指紋。
 * @param {boolean} json - 復号するか。
 * @returns {Promise<Object>} 位置と値。
 */
async function readRef(ref,base,before,json=true){assert.ok(ref&&typeof ref.path==='string'&&/^[0-9a-f]{64}$/.test(ref.sha256));const p=path.resolve(base,ref.path),b=await fs.readFile(p);assert.equal(sha(b),ref.sha256);before.set(p,ref.sha256);return {path:p,sha256:ref.sha256,value:json?JSON.parse(b.toString('utf8').replace(/^\uFEFF/,'')):null};}

/**
 * 実金融・保存・Viewer成功後の既存5FileRef形式だけを受ける。
 * @param {string} fixedPath - Root固定。
 * @param {string} fixedSHA - 実SHA。
 * @returns {Promise<Object>} 認証した表。途中の市場結果は受けない。
 */
async function readFixed(fixedPath,fixedSHA){const inputs=new Map(),f=await readRef({path:fixedPath,sha256:fixedSHA},'.',inputs),x=f.value;assert.ok(x.version===1&&x.trial===107&&x.fixed===true);for(const k of ['result_ready','financial_checked','saved_checked','viewer_checked'])assert.equal(x[k],true);const refs={};for(const k of ['code','summary','financial_completion','saved_check','viewer_evidence'])refs[k]=await readRef(x[k],path.dirname(f.path),inputs,k!=='code');assert.equal(refs.code.path,path.resolve(import.meta.filename));const fin=refs.financial_completion.value,checked=refs.saved_check.value,result=refs.summary.value;assert.ok(fin.version===1&&fin.trial===107&&fin.stage==='full70'&&fin.success&&fin.sessions===70&&fin.books===1680&&fin.books_per_scene===24&&fin.unchanged);assert.deepEqual(fin.before,fin.after);assert.equal(checked['成功'],true);assert.equal(checked['会計'],1680);assert.equal(checked['不一致数'],0);assert.equal(checked.completionSHA256,refs.financial_completion.sha256);assert.equal(checked['出力SHA256']['結果.json'],refs.summary.sha256);assert.equal(result.completionSHA256,refs.financial_completion.sha256);assert.ok(refs.viewer_evidence.value['成功']===true||refs.viewer_evidence.value.success===true);assert.ok(typeof x.viewer_scope==='string'&&x.viewer_scope.trim());return {inputs,refs,fixed:x,...prepareCandidateSheets(result)};}

/**
 * 現ブックを読取だけで確認する。
 * @returns {Promise<void>} 旧5の保持基準。marker/exportは0。
 */
async function review(){assert.equal(sha(await fs.readFile(BOOK)),BOOK_SHA);const b=await SpreadsheetFile.importXlsx(await FileBlob.load(BOOK));for(let i=0;i<5;i++)assert.equal(b.worksheets.getItemAt(i).name,OLD_SHEETS[i]);for(const name of CANDIDATES)assert.throws(()=>b.worksheets.getItem(name));const prior=snapshot(b);assert.equal(sha(await fs.readFile(BOOK)),BOOK_SHA);await fs.writeFile(path.join(WORK,'読取確認.json'),JSON.stringify({成功:true,元ブックSHA256:BOOK_SHA,旧5タブ:prior.map(x=>x.name),marker_xlsx編集_export:0},null,2));}

/**
 * 6候補へ各4実Excel Tableを作り、元5タブを保って同一ブックへ一回exportする。
 * @param {string} fixedPath - Root実成功後の5Ref固定。
 * @param {string} fixedSHA - そのSHA。
 * @returns {Promise<void>} 実行直前marker一回とRoot編集指示が別途必要。
 */
async function append(fixedPath,fixedSHA){
 const v=await readFixed(fixedPath,fixedSHA);assert.equal(sha(await fs.readFile(BOOK)),BOOK_SHA);const b=await SpreadsheetFile.importXlsx(await FileBlob.load(BOOK)),prior=snapshot(b);await fs.writeFile(path.join(WORK,'候補別追記前.xlsx'),await fs.readFile(BOOK),{flag:'wx'});const money='#,##0.0;[Red](#,##0.0);0';
 for(const candidate of CANDIDATES){assert.throws(()=>b.worksheets.getItem(candidate));const s=b.worksheets.add(candidate);s.showGridLines=false;s.tabColor=candidate.startsWith('Q')?'#385B50':'#23354D';s.freezePanes.freezeRows(8);s.getRange('A1:L315').format.font={name:'Arial',size:10,color:'#202A35'};s.getRange('A1:L315').format.rowHeight=23;s.getRange('A1:L315').format.verticalAlignment='center';s.getRange('A1:L1').format.columnWidth=16;s.getRange('C1').format.columnWidth=23;s.getRange('G1').format.columnWidth=19;s.getRange('H1:I1').format.columnWidth=19;
 const notes=[`107 ${candidate} 全セッションの損益と累計収支`,DEFINITIONS[candidate][0],DEFINITIONS[candidate][1], '既使用35日・70場、2026-09-21〜11-06。0取引の場も全件表示。新規件数＝実取得建玉。', '片側上限10枚の可変数量。新規枚数は実取得枚数であり、10枚固定ではない。手数料は片道税込38.5円/枚。', 'C5は片道追加5pt滑り、D1は1秒遅延の仮定。開始/米国開始後30分見送りは今回固定。', '累計は各条件内の全70場時系列で0から。参加＝同枠実取得new＋当時保有、主分母7840。フィルタ後も累計は元系列。'];for(let i=0;i<notes.length;i++){const n=i+2;s.getRange(`A${n}:L${n}`).merge();s.getRange(`A${n}`).values=[[notes[i]]];s.getRange(`A${n}:L${n}`).format.wrapText=true;s.getRange(`A${n}:L${n}`).format.rowHeight=28;}s.getRange('A2').format.font={name:'Arial',size:15,bold:true,color:'#23354D'};
 for(const table of v.sheets[candidate]){const header=table.header,first=header+1,last=first+69,total=last+1;s.getRange(`A${header-1}:L${header-1}`).merge();s.getRange(`A${header-1}`).values=[[`${table.key}${table.cost===0&&table.delay===0?'（主条件）':''}：片道追加滑り${table.cost}pt、約定遅延${table.delay}秒`]];s.getRange(`A${header-1}`).format.font={name:'Arial',size:11,bold:true,color:'#23354D'};s.getRange(`A${header}:L${header}`).values=[HEADERS];s.getRange(`A${first}:L${last}`).values=table.rows;s.getRange(`A${header}:L${header}`).format={fill:'#23354D',font:{name:'Arial',size:10,bold:true,color:'#FFFFFF'},wrapText:true,rowHeight:40,horizontalAlignment:'center'};const native=s.tables.add(`A${header}:L${last}`,true,`T107_${table.key}`);native.style='TableStyleMedium2';native.showFilterButton=true;native.showBandedColumns=false;s.getRange(`A${first}:A${last}`).setNumberFormat('yyyy-mm-dd');s.getRange(`C${first}:D${total}`).setNumberFormat('#,##0');s.getRange(`E${first}:I${total}`).setNumberFormat(money);s.getRange(`J${first}:K${total}`).setNumberFormat('#,##0');s.getRange(`L${first}:L${total}`).setNumberFormat('0.00%');for(let n=first;n<=last;n++){s.getRange(`H${n}`).formulas=[[`=E${n}-F${n}-G${n}`]];s.getRange(`I${n}`).formulas=[[`=SUM($H$${first}:H${n})`]];s.getRange(`L${n}`).formulas=[[`=J${n}/K${n}`]];}s.getRange(`A${total}`).values=[['合計']];s.getRange(`B${total}`).formulas=[[`=COUNTA(A${first}:A${last})`]];for(const col of ['C','D','E','F','G','H','J','K'])s.getRange(`${col}${total}`).formulas=[[`=SUM(${col}${first}:${col}${last})`]];s.getRange(`I${total}`).formulas=[[`=I${last}`]];s.getRange(`L${total}`).formulas=[[`=J${total}/K${total}`]];s.getRange(`A${total}:L${total}`).format.font={name:'Arial',size:10,bold:true,color:'#23354D'};}
 }
 b.recalculate();assert.deepEqual(snapshot(b),prior);for(const candidate of CANDIDATES){const s=b.worksheets.getItem(candidate);for(const table of v.sheets[candidate]){const last=table.header+70,total=last+1;assert.equal(s.getRange(`B${total}`).values[0][0],70);assert.equal(s.getRange(`H${total}`).values[0][0],table.summary.net_yen);assert.equal(s.getRange(`I${last}`).values[0][0],table.summary.net_yen);}for(const [part,range]of [['先頭','A2:L27'],['末尾','A302:L315']]){const image=await b.render({sheetName:candidate,range,scale:1,format:'png'});await fs.writeFile(path.join(WORK,`${candidate}_${part}.png`),new Uint8Array(await image.arrayBuffer()));}}
 const errors=await b.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:100},maxChars:3000});await fs.writeFile(path.join(WORK,'式検査.ndjson'),errors.ndjson);for(const [p,h]of v.inputs)assert.equal(sha(await fs.readFile(p)),h);await(await SpreadsheetFile.exportXlsx(b)).save(BOOK);const saved=await SpreadsheetFile.importXlsx(await FileBlob.load(BOOK));assert.deepEqual(snapshot(saved),prior);await fs.writeFile(path.join(WORK,'追記の確認.json'),JSON.stringify({成功:true,元ブックSHA256:BOOK_SHA,最終ブックSHA256:sha(await fs.readFile(BOOK)),新6シート:CANDIDATES,実Table:24,各データ行:70,旧5値_式_図保持:true,入力SHA256:Object.fromEntries(v.inputs),保存後全正本とOOXML:'別QAと画像視認を必須'},null,2));
}

// ----------------------------------------
// 旧builderを誤起動しない専用CLI名。準備の既定はimportだけ。
if(process.argv.includes('--review-candidates'))await review();
else if(process.argv.includes('--append-candidates')){const i=process.argv.indexOf('--append-candidates');await append(process.argv[i+1],process.argv[i+2]);}
