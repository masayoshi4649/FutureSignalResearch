/**
 * 107保存結果を既存ブックの第六タブへ狭く追記する準備コード。
 * @param {string[]} process.argv - --review又は将来の--append fixedPath fixedSHA。
 * @returns {Promise<void>} 読取又はRoot事後固定後の一回追記。
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {FileBlob, SpreadsheetFile} from '@oai/artifact-tool';

const ROOT=path.resolve(import.meta.dirname,'../..'), WORK=import.meta.dirname;
export const BOOK=path.join(ROOT,'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/元アルゴリズムと現行代表候補の損益比較.xlsx');
export const BOOK_SHA='69509c40c1f65214322a73b27c1e94e791df3b44d35e384cff555a62a1872206';
export const OLD_SHEETS=['比較','セッション明細','新条件102','一定利益後103','収束早期保護106'];
export const SHEET='見送り繰越と保護107';
export const KEYS=['B0','B1','BE','Q0','Q1','QE'].flatMap(p=>[0,5].flatMap(c=>[0,1].map(d=>`${p}_C${c}_D${d}`)));
const HISTORY=['old104_54','saved105_4','fresh106_12'];
const LABELS={old104_54:'旧104の54場',saved105_4:'105の4場',fresh106_12:'追加12場',artificial:'手製型人工',Day:'日中',Night:'夜間'};
const FIELDS=['gross_yen','fee_yen','slip_yen','net_yen','positive_yen','negative_yen','positions','entry_quantity',
 'unit_positive_positions','unit_positive_closed_negative','unit_positive_closed_negative_yen','protection_activated_positions',
 'activated_closed_negative','activated_closed_negative_yen','normal_ld10_activations','early_warning_activations','narrowed_positions'];
const CLOCK_FIELDS=['出生','静観繰越','一回失効','受理出生','受理枚','実取得出生','実取得枚','受理後0取得取消','割当前の観測保留枠延べ'];
export const SPECS={
 summary:{row:12,headers:['候補','費用/遅延','純損益（円）','粗額（円）','手数料（円）','仮定滑り（円）','取引PF','保存点DD','玉数','取得枚数','活動枠','主分母','参加率','最低25%','目標50%','u後赤字額','起動後赤字額','狭幅玉数']},
 flags:{row:40,headers:['候補','費用/遅延','u正益玉','u後赤字玉','u後赤字額','保護起動玉','起動後赤字玉','起動後赤字額','通常LD10起動','早期起動','狭幅玉数','待機枠','不能枠']},
 clock:{row:68,headers:['候補','費用/遅延','出生数','静観繰越数','一回失効','受理出生','受理枚数','実取得出生','実取得枚数','0取得取消','割当前保留枠延べ','新規活動枠','実保有活動枠','不能枠','主分母','参加率']},
 daynight:{row:96,headers:['候補','費用/遅延','日夜','純損益（円）','取引PF','保存点DD','玉数','取得枚数','活動枠','主分母','参加率','u後赤字額','起動後赤字額','早期起動']},
 history:{row:148,headers:['候補','費用/遅延','履歴区分','純損益（円）','取引PF','保存点DD','玉数','取得枚数','活動枠','主分母','参加率','u後赤字額','起動後赤字額','早期起動']},
 details:{row:226,headers:['開始日','日夜','履歴区分','候補','費用/遅延','粗額（円）','手数料（円）','仮定滑り（円）','純損益（円）','玉数','取得枚数','活動枠','主分母','参加率','静観繰越数','受理出生','実取得出生','0取得取消','u後赤字額','起動後赤字額','早期起動','狭幅玉数']},
 comparisons:{row:1912,headers:['区分','変更後','変更前','全差額（円）','同実入口玉','同実入口差額','取得変更玉','取得変更差額','前のみ玉','前のみ実額','後のみ玉','後のみ実額']},
 publications:{row:1954,headers:['開始日','日夜','履歴区分','数値種carry','新3分公表','C既知','C成立','買M既知','買M成立','買P既知','買P成立','売M既知','売M成立','売P既知','売P成立']}
};

/**
 * 小入力又はブックの指紋を計算する。
 * @param {Uint8Array|string} bytes - 内容。
 * @returns {string} SHA256。
 */
function sha(bytes){return crypto.createHash('sha256').update(bytes).digest('hex');}

/**
 * 場別のcounts-onlyと集約の率を分けて基本算術を検査する。
 * @param {Object} row - 保存済み場別又は集約。
 * @param {number} denom - 対応する分母。
 * @param {boolean} aggregate - PF/保存点連結DDがある集約か。
 * @returns {void} 不整合は例外。
 */
function checkRow(row,denom,aggregate=false){
 for(const f of FIELDS)assert.ok(typeof row[f]==='number'&&Number.isFinite(row[f]),f);
 assert.equal(row.gross_yen-row.fee_yen-row.slip_yen,row.net_yen);assert.equal(row.positive_yen+row.negative_yen,row.net_yen);
 const a=row['活動主表'];assert.equal(a.denom,denom);assert.equal(a.new+a.hold,a.active);assert.equal(a.active+a.wait+a.unknown,denom);
 for(const f of ['new','hold','active','wait','unknown','denom'])assert.ok(Number.isInteger(a[f])&&a[f]>=0,f);
 for(const f of CLOCK_FIELDS)assert.ok(Number.isInteger(row['時計割当'][f])&&row['時計割当'][f]>=0,f);
 if(aggregate){assert.ok(row.negative_yen===0?row.PF===null:Math.abs(row.PF-row.positive_yen/-row.negative_yen)<1e-9);assert.ok(Number.isFinite(row['保存点連結時価DD']));}
}

/**
 * 集約と場別の金額・件数を照合する。
 * @param {Object} row - 正本集約。
 * @param {Object[]} scenes - 同じ母集団の場別。
 * @returns {void} 率は対応する分子/分母から計算する。
 */
function checkAggregate(row,scenes){
 checkRow(row,scenes.reduce((s,r)=>s+r['活動主表'].denom,0),true);
 for(const f of FIELDS)assert.equal(row[f],scenes.reduce((s,r)=>s+r[f],0),f);
 for(const f of CLOCK_FIELDS)assert.equal(row['時計割当'][f],scenes.reduce((s,r)=>s+r['時計割当'][f],0),f);
 for(const f of ['new','hold','active','wait','unknown'])assert.equal(row['活動主表'][f],scenes.reduce((s,r)=>s+r['活動主表'][f],0),f);
}

/**
 * 日夜又は履歴区分を共通の表示列へ写す。
 * @param {string} candidate - 外候補名。
 * @param {string} cost - 費用と遅延。
 * @param {string} label - 区分。
 * @param {Object} row - 保存済み集約。
 * @returns {Array} 数値型の一行。
 */
function groupRow(candidate,cost,label,row){const a=row['活動主表'];return [candidate,cost,label,row.net_yen,row.PF??'未定義',row['保存点連結時価DD'],row.positions,row.entry_quantity,a.active,a.denom,a.active/a.denom,row.unit_positive_closed_negative_yen,row.activated_closed_negative_yen,row.early_warning_activations];}

/**
 * 保存APIの実型を24候補・時計・日夜・明細・36比較へ射影する。
 * @param {Object} result - 107保存結果。市場はfull70成功、人工は実型の1場だけ。
 * @param {boolean} artificial - 手製型確認のみか。70場へ水増ししない。
 * @returns {Object} 第六タブの入力表。日付はUTC午前0時のDate。
 */
export function prepareTables(result,artificial=false){
 assert.equal(result['試行'],107);assert.equal(result['成功'],true);assert.equal(result['前後不変'],true);
 assert.deepEqual(result['入力codeSHA256前'],result['入力codeSHA256後']);assert.deepEqual(Object.keys(result['集計']).sort(),[...KEYS].sort());
 const sessions=[...new Set(result['場別'].map(r=>r.session))].sort(),n=artificial?sessions.length:70;
 assert.equal(sessions.length,n);assert.equal(result['場数'],n);assert.equal(result['会計数'],n*24);assert.equal(result['場別'].length,n*24);
 if(!artificial)assert.equal(result.stage,'full70');
 const pairs=new Map();for(const r of result['場別']){assert.ok(KEYS.includes(r.key));assert.ok((artificial?[...HISTORY,'artificial']:HISTORY).includes(r.history_class));const id=`${r.session}/${r.key}`;assert.ok(!pairs.has(id));pairs.set(id,r);checkRow(r,artificial?r['活動主表'].denom:(r.session.endsWith('_Day')?76:148));}
 const out={summary:[],flags:[],clock:[],daynight:[],history:[],details:[],comparisons:[],publications:[],sessions};
 for(const key of KEYS){
  const scenes=sessions.map(s=>pairs.get(`${s}/${key}`));assert.ok(scenes.every(Boolean));const r=result['集計'][key],a=r['活動主表'],[candidate,c,d]=key.split('_'),cost=`${c}/${d}`;
  checkAggregate(r,scenes);if(!artificial){assert.equal(a.denom,7840);assert.equal(r['活動副表'].denom,7560);}
  const rate=a.active/a.denom;out.summary.push([candidate,cost,r.net_yen,r.gross_yen,r.fee_yen,r.slip_yen,r.PF??'未定義',r['保存点連結時価DD'],r.positions,r.entry_quantity,a.active,a.denom,rate,rate>=.25?'達成':'未達',rate>=.5?'達成':'未達',r.unit_positive_closed_negative_yen,r.activated_closed_negative_yen,r.narrowed_positions]);
  out.flags.push([candidate,cost,r.unit_positive_positions,r.unit_positive_closed_negative,r.unit_positive_closed_negative_yen,r.protection_activated_positions,r.activated_closed_negative,r.activated_closed_negative_yen,r.normal_ld10_activations,r.early_warning_activations,r.narrowed_positions,a.wait,a.unknown]);
  out.clock.push([candidate,cost,...CLOCK_FIELDS.map(f=>r['時計割当'][f]),a.new,a.hold,a.unknown,a.denom,rate]);
  for(const kind of ['Day','Night']){const rows=scenes.filter(s=>s.session.endsWith('_'+kind));if(artificial&&!rows.length)continue;const v=result['実現診断'][key]['日夜'][kind];checkAggregate(v,rows);out.daynight.push(groupRow(candidate,cost,LABELS[kind],v));}
  for(const kind of artificial?[...new Set(scenes.map(s=>s.history_class))]:HISTORY){const rows=scenes.filter(s=>s.history_class===kind);if(!artificial)assert.equal(rows.length,kind==='old104_54'?54:kind==='saved105_4'?4:12);const v=result['実現診断'][key]['履歴区分'][kind];checkAggregate(v,rows);out.history.push(groupRow(candidate,cost,LABELS[kind],v));}
 }
 for(const session of sessions)for(const key of KEYS){const r=pairs.get(`${session}/${key}`),[p,c,d]=key.split('_'),a=r['活動主表'],clock=r['時計割当'];out.details.push([new Date(`${session.slice(0,10)}T00:00:00Z`),LABELS[session.split('_')[1]],LABELS[r.history_class],p,`${c}/${d}`,r.gross_yen,r.fee_yen,r.slip_yen,r.net_yen,r.positions,r.entry_quantity,a.active,a.denom,a.active/a.denom,clock['静観繰越'],clock['受理出生'],clock['実取得出生'],clock['受理後0取得取消'],r.unit_positive_closed_negative_yen,r.activated_closed_negative_yen,r.early_warning_activations,r.narrowed_positions]);}
 assert.equal(Object.keys(result['同実入口と実現額差']).length,36);for(const [name,row]of Object.entries(result['同実入口と実現額差'])){const [after,before]=name.split('対'),v=row['合計'];assert.equal(v['全差額'],result['集計'][after].net_yen-result['集計'][before].net_yen);assert.equal(v['全差額'],v['同実入口差額']+v['取得変更差額']-v['前のみ実現額']+v['後のみ実現額']);out.comparisons.push([row['区分'],after,before,...['全差額','同実入口玉','同実入口差額','取得変更玉','取得変更差額','前のみ玉','前のみ実現額','後のみ玉','後のみ実現額'].map(k=>v[k])]);}
 const publicRows=new Map(result['一公表単位の役割診断'].map(r=>[r.session,r]));assert.deepEqual([...publicRows.keys()].sort(),sessions);for(const session of sessions){const v=publicRows.get(session),history=pairs.get(`${session}/${KEYS[0]}`).history_class;out.publications.push([new Date(`${session.slice(0,10)}T00:00:00Z`),LABELS[session.split('_')[1]],LABELS[history],v.numeric_seed_carried,v.new_three,v.C_known,v.C_pass,...['buy','sell'].flatMap(side=>['M_known','M_pass','P_known','P_pass'].map(k=>v[side][k]))]);}
 for(const [name,spec]of Object.entries(SPECS))assert.ok(out[name].every(r=>r.length===spec.headers.length),name+'列数');return out;
}

/**
 * 旧5タブの値・式・図表参照を保持基準にする。
 * @param {Object} book - Artifact Workbook。
 * @returns {Array} 読取専用の基準。
 */
function snapshot(book){return OLD_SHEETS.map(name=>{const s=book.worksheets.getItem(name),r=s.getUsedRange();return {name,values:r.values,formulas:r.formulas,charts:s.charts.items.map(c=>({type:c.type,title:c.title.text,series:c.series.items.map(t=>({formula:t.formula,categoryFormula:t.categoryFormula}))}))};});}

/**
 * 既存ブックを読取・renderするだけで編集/export/markerを行わない。
 * @returns {Promise<void>} 現状PNGとSHA基準。
 */
async function review(){assert.equal(sha(await fs.readFile(BOOK)),BOOK_SHA);const b=await SpreadsheetFile.importXlsx(await FileBlob.load(BOOK));for(let i=0;i<5;i++)assert.equal(b.worksheets.getItemAt(i).name,OLD_SHEETS[i]);assert.throws(()=>b.worksheets.getItem(SHEET));const prior=snapshot(b),im=await b.render({sheetName:OLD_SHEETS[4],range:'A2:R25',scale:1,format:'png'});await fs.writeFile(path.join(WORK,'現在の106.png'),new Uint8Array(await im.arrayBuffer()));assert.deepEqual(snapshot(b),prior);assert.equal(sha(await fs.readFile(BOOK)),BOOK_SHA);await fs.writeFile(path.join(WORK,'読取確認.json'),JSON.stringify({成功:true,ブックSHA256:BOOK_SHA,旧5タブ:OLD_SHEETS,xlsx編集_export_marker:0},null,2));}

/**
 * 固定参照をSHAへ結ぶ。
 * @param {Object} ref - path/sha256。
 * @param {string} base - 明示基準。
 * @param {Map} inputs - 指紋。
 * @param {boolean} json - JSONを復号するか。
 * @returns {Promise<Object>} 位置と値。
 */
async function readRef(ref,base,inputs,json=true){assert.ok(ref&&typeof ref.path==='string'&&/^[0-9a-f]{64}$/.test(ref.sha256));const p=path.resolve(base,ref.path),bytes=await fs.readFile(p);assert.equal(sha(bytes),ref.sha256);inputs.set(p,ref.sha256);return {path:p,sha256:ref.sha256,value:json?JSON.parse(bytes.toString('utf8').replace(/^\uFEFF/,'')):null};}

/**
 * Rootの金融・保存・Viewer成功後だけ市場正本を許可する。
 * @param {string} fixedPath - Root固定。
 * @param {string} fixedSHA - 固定SHA。
 * @returns {Promise<Object>} 認証した5参照と表。
 */
async function readFixed(fixedPath,fixedSHA){const inputs=new Map(),f=await readRef({path:fixedPath,sha256:fixedSHA},'.',inputs),x=f.value;assert.ok(x.version===1&&x.trial===107&&x.fixed===true);for(const k of ['result_ready','financial_checked','saved_checked','viewer_checked'])assert.equal(x[k],true);const refs={};for(const k of ['code','summary','financial_completion','saved_check','viewer_evidence'])refs[k]=await readRef(x[k],path.dirname(f.path),inputs,k!=='code');assert.equal(refs.code.path,path.resolve(import.meta.filename));const fin=refs.financial_completion.value,saved=refs.saved_check.value,result=refs.summary.value;assert.ok(fin.version===1&&fin.trial===107&&fin.stage==='full70'&&fin.success&&fin.sessions===70&&fin.books===1680&&fin.books_per_scene===24&&fin.unchanged);assert.deepEqual(fin.before,fin.after);assert.equal(saved['成功'],true);assert.equal(saved['会計'],1680);assert.equal(saved['不一致数'],0);assert.equal(saved.completionSHA256,refs.financial_completion.sha256);assert.equal(saved['出力SHA256']['結果.json'],refs.summary.sha256);assert.equal(result.completionSHA256,refs.financial_completion.sha256);assert.ok(refs.viewer_evidence.value['成功']===true||refs.viewer_evidence.value.success===true);assert.ok(typeof x.viewer_scope==='string'&&x.viewer_scope.trim());return {inputs,refs,fixed:x,tables:prepareTables(result)};}

/**
 * 第六タブだけを追加し、旧5タブを保持して同じxlsxへ一回exportする。
 * @param {string} fixedPath - Root成功後の5参照固定。
 * @param {string} fixedSHA - そのSHA。
 * @returns {Promise<void>} Root別指示と直前marker一回が前提の編集。
 */
async function append(fixedPath,fixedSHA){
 const v=await readFixed(fixedPath,fixedSHA);assert.equal(sha(await fs.readFile(BOOK)),BOOK_SHA);const b=await SpreadsheetFile.importXlsx(await FileBlob.load(BOOK)),prior=snapshot(b);assert.throws(()=>b.worksheets.getItem(SHEET));await fs.writeFile(path.join(WORK,'107追記前.xlsx'),await fs.readFile(BOOK),{flag:'wx'});const s=b.worksheets.add(SHEET);s.showGridLines=false;s.tabColor='#23354D';s.freezePanes.freezeRows(11);s.getRange('A1:V2023').format.font={name:'Arial',size:10,color:'#202A35'};s.getRange('A1:V2023').format.rowHeight=24;s.getRange('A1:V2023').format.verticalAlignment='center';s.getRange('A1:V1').format.columnWidth=15;s.getRange('A1').format.columnWidth=14;s.getRange('C1').format.columnWidth=20;
 const notes=['見送りの出生だけを繰り越す時計と利益保護 107','B0/B1/BE=旧B5Q、Q0/Q1/QE=quietだけ一回繰越B5QD。保護は各W0/W1/E1。','W0=LD10後2ATR。W1=C&Mで1ATR。E1=LD05水準とC&Mで早期起動、通常LD10も維持。','手数料は片道38.5円。C5は片道5ptの仮定滑り、D1は1秒遅延。売買各上限10枚。','出生からstrict次5分。開始後30分とNight米国開始後30分だけ繰越。Force/P締切/取消/EOFは旧優先。','主7840枠・副7560枠。静観と欠測は分母に残す。受理だけを実参加に数えず新規実取得＋当時保有。','同じ既使用70場。時計差12・同時計保護差24。取得変更/片側実額を退出効果と混ぜない。',`Viewer確認範囲：${v.fixed.viewer_scope}`,`正本：${path.relative(ROOT,v.refs.summary.path).replaceAll('\\','/')}  SHA256：${v.refs.summary.sha256}`];for(let i=0;i<notes.length;i++){const n=i+2;s.getRange(`A${n}:V${n}`).merge();s.getRange(`A${n}`).values=[[notes[i]]];s.getRange(`A${n}:V${n}`).format.wrapText=true;s.getRange(`A${n}:V${n}`).format.rowHeight=i===0?27:25;}s.getRange('A2').format.font={name:'Arial',size:15,bold:true,color:'#23354D'};
 const money='#,##0.0;[Red](#,##0.0);0';for(const [name,spec]of Object.entries(SPECS)){const data=v.tables[name],col=String.fromCharCode(64+spec.headers.length),first=spec.row,last=first+data.length-1;const header=s.getRange(`A${first-1}:${col}${first-1}`);header.values=[spec.headers];header.format={fill:'#23354D',font:{name:'Arial',size:10,bold:true,color:'#FFFFFF'},wrapText:true,rowHeight:42,horizontalAlignment:'center'};s.getRange(`A${first}:${col}${last}`).values=data;s.getRange(`A${first}:${col}${last}`).setNumberFormat(money);}
 for(let i=0;i<24;i++){let n=SPECS.summary.row+i;s.getRange(`C${n}`).formulas=[[`=D${n}-E${n}-F${n}`]];s.getRange(`M${n}`).formulas=[[`=K${n}/L${n}`]];s.getRange(`N${n}`).formulas=[[`=IF(M${n}>=25%,"達成","未達")`]];s.getRange(`O${n}`).formulas=[[`=IF(M${n}>=50%,"達成","未達")`]];n=SPECS.clock.row+i;s.getRange(`P${n}`).formulas=[[`=(L${n}+M${n})/O${n}`]];}
 s.getRange('G12:G35').setNumberFormat('0.00');s.getRange('I12:L35').setNumberFormat('#,##0');s.getRange('M12:M35').setNumberFormat('0.00%');s.getRange('C68:O91').setNumberFormat('#,##0');s.getRange('P68:P91').setNumberFormat('0.00%');s.getRange('C40:D63').setNumberFormat('#,##0');s.getRange('F40:G63').setNumberFormat('#,##0');s.getRange('I40:M63').setNumberFormat('#,##0');
 s.getRange('R12:R35').setNumberFormat('#,##0');for(const col of ['E','G','I','K'])s.getRange(`${col}1912:${col}1947`).setNumberFormat('#,##0');
 for(const kind of ['daynight','history']){const first=SPECS[kind].row,last=first+v.tables[kind].length-1;for(let n=first;n<=last;n++)s.getRange(`K${n}`).formulas=[[`=I${n}/J${n}`]];s.getRange(`E${first}:E${last}`).setNumberFormat('0.00');s.getRange(`G${first}:J${last}`).setNumberFormat('#,##0');s.getRange(`K${first}:K${last}`).setNumberFormat('0.00%');s.getRange(`N${first}:N${last}`).setNumberFormat('#,##0');}
 const first=SPECS.details.row,last=first+v.tables.details.length-1;for(let n=first;n<=last;n++){s.getRange(`I${n}`).formulas=[[`=F${n}-G${n}-H${n}`]];s.getRange(`N${n}`).formulas=[[`=L${n}/M${n}`]];}s.getRange(`A${first}:A${last}`).setNumberFormat('yyyy-mm-dd');s.getRange(`J${first}:M${last}`).setNumberFormat('#,##0');s.getRange(`N${first}:N${last}`).setNumberFormat('0.00%');s.getRange(`O${first}:R${last}`).setNumberFormat('#,##0');s.getRange(`U${first}:V${last}`).setNumberFormat('#,##0');s.getRange('A1954:A2023').setNumberFormat('yyyy-mm-dd');s.getRange('E1954:O2023').setNumberFormat('#,##0');
 b.recalculate();assert.deepEqual(snapshot(b),prior);for(let i=0;i<24;i++)assert.equal(s.getRange(`C${12+i}`).values[0][0],v.tables.summary[i][2]);
 for(const [name,spec]of Object.entries(SPECS)){const end=Math.min(spec.row+v.tables[name].length-1,spec.row+(name==='summary'||name==='clock'||name==='flags'?23:14)),col=String.fromCharCode(64+spec.headers.length);const im=await b.render({sheetName:SHEET,range:`A${name==='summary'?2:spec.row-1}:${col}${end}`,scale:1,format:'png'});await fs.writeFile(path.join(WORK,`107_${name}.png`),new Uint8Array(await im.arrayBuffer()));}
 const errors=await b.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:100},maxChars:4000});await fs.writeFile(path.join(WORK,'107式検査.ndjson'),errors.ndjson);for(const [p,h]of v.inputs)assert.equal(sha(await fs.readFile(p)),h);await(await SpreadsheetFile.exportXlsx(b)).save(BOOK);const saved=await SpreadsheetFile.importXlsx(await FileBlob.load(BOOK));assert.deepEqual(snapshot(saved),prior);await fs.writeFile(path.join(WORK,'期待した全表.json'),JSON.stringify(v.tables));await fs.writeFile(path.join(WORK,'107追記の確認.json'),JSON.stringify({成功:true,元ブックSHA256:BOOK_SHA,最終ブックSHA256:sha(await fs.readFile(BOOK)),旧5タブ値_式_図参照保持:true,入力SHA256:Object.fromEntries(v.inputs),保存後OOXML全保持:'別QA必須'},null,2));
}

// ----------------------------------------
// 既定はimportだけ。実ブック編集とmarkerはRootの明示指示後に限る。
if(process.argv.includes('--review'))await review();
else if(process.argv.includes('--append')){const i=process.argv.indexOf('--append');await append(process.argv[i+1],process.argv[i+2]);}
