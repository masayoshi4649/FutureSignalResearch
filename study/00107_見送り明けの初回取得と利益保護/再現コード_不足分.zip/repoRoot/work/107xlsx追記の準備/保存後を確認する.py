"""旧5タブを全保持し、新107の全表とt=d日付を読取だけで検査する。"""
import argparse
import copy
import hashlib
from datetime import date, datetime
from decimal import Decimal
import importlib.util
import json
from pathlib import Path
import xml.etree.ElementTree as ET

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
OLD_PATH = ROOT / "work/xlsx比較_作成/103の保存比較QA.py"
assert hashlib.sha256(OLD_PATH.read_bytes()).hexdigest() == "7873f653e6c328dda12717e2a05b9572f8e4a09a53f8b1e618337984170fa633"
SPEC = importlib.util.spec_from_file_location("107が再用する固定OOXML読取", OLD_PATH)
OLD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(OLD)
BOOK = ROOT / "outputs/01a1889f-f2af-7943-a047-543275ee9ed2/元アルゴリズムと現行代表候補の損益比較.xlsx"
BASE_SHA = "69509c40c1f65214322a73b27c1e94e791df3b44d35e384cff555a62a1872206"
SHEETS = ["比較", "セッション明細", "新条件102", "一定利益後103", "収束早期保護106"]
TARGET = "見送り繰越と保護107"
ROWS = {"summary": 12, "flags": 40, "clock": 68, "daynight": 96, "history": 148, "details": 226, "comparisons": 1912, "publications": 1954}


def date_value(cell):
    """
    機能: ISO UTC午前0時のt=d又は旧数値serialだけを日付比較へ接続する。
    引数: cell(dict)は読取済みOOXMLセル。
    返り値: Decimalは1900serial。元セルとxlsxは変更しない。
    """
    if cell["type"] == "d":
        value = cell["value"]
        assert isinstance(value, str) and value.endswith("Z")
        parsed = datetime.fromisoformat(value[:-1] + "+00:00")
        assert parsed.tzinfo is not None and parsed.utcoffset() is not None
        assert parsed.utcoffset().total_seconds() == 0 and (parsed.hour, parsed.minute, parsed.second, parsed.microsecond) == (0, 0, 0, 0)
        return Decimal((parsed.date() - date(1899, 12, 30)).days)
    assert cell["type"] in (None, "n") and isinstance(cell["value"], Decimal)
    assert cell["value"].is_finite() and cell["value"] == cell["value"].to_integral_value()
    return cell["value"]


def source_tables(result, artificial=False):
    """
    機能: JSが保存した表を期待値にせず、正本値から全8領域を独立に作る。
    引数: result(dict)、artificial(bool)は正本又は限定手製1場型。
    返り値: dictは全表の値。市場実績のない領域を0で補わない。
    """
    assert result["試行"] == 107 and result["成功"]
    if not artificial:
        assert result["stage"] == "full70" and result["場数"] == 70 and result["会計数"] == 1680
    keys = [f"{p}_C{c}_D{d}" for p in ("B0", "B1", "BE", "Q0", "Q1", "QE") for c in (0, 5) for d in (0, 1)]
    labels = {"Day": "日中", "Night": "夜間", "old104_54": "旧104の54場", "saved105_4": "105の4場", "fresh106_12": "追加12場", "artificial": "手製型人工"}
    clock_fields = ["出生", "静観繰越", "一回失効", "受理出生", "受理枚", "実取得出生", "実取得枚", "受理後0取得取消", "割当前の観測保留枠延べ"]
    output = {k: [] for k in ROWS}
    sessions = sorted({r["session"] for r in result["場別"]})
    pairs = {(r["session"], r["key"]): r for r in result["場別"]}
    for key in keys:
        r = result["集計"][key]
        p, c, d = key.split("_")
        cost = c+"/"+d
        a = r["活動主表"]
        rate = Decimal(a["active"])/a["denom"]
        output["summary"].append([p, cost, r["net_yen"], r["gross_yen"], r["fee_yen"], r["slip_yen"], r["PF"] if r["PF"] is not None else "未定義", r["保存点連結時価DD"], r["positions"], r["entry_quantity"], a["active"], a["denom"], rate, "達成" if rate >= Decimal(".25") else "未達", "達成" if rate >= Decimal(".5") else "未達", r["unit_positive_closed_negative_yen"], r["activated_closed_negative_yen"], r["narrowed_positions"]])
        output["flags"].append([p, cost, *[r[x] for x in ("unit_positive_positions", "unit_positive_closed_negative", "unit_positive_closed_negative_yen", "protection_activated_positions", "activated_closed_negative", "activated_closed_negative_yen", "normal_ld10_activations", "early_warning_activations", "narrowed_positions")], a["wait"], a["unknown"]])
        output["clock"].append([p, cost, *[r["時計割当"][f] for f in clock_fields], a["new"], a["hold"], a["unknown"], a["denom"], rate])
        for name, field, kinds in (("daynight", "日夜", ("Day", "Night")), ("history", "履歴区分", tuple(sorted({pairs[s, key]["history_class"] for s in sessions})) if artificial else ("old104_54", "saved105_4", "fresh106_12"))):
            for kind in kinds:
                if artificial and name == "daynight" and not any(s.endswith("_"+kind) for s in sessions):
                    continue
                v = result["実現診断"][key][field][kind]
                b = v["活動主表"]
                output[name].append([p, cost, labels[kind], v["net_yen"], v["PF"] if v["PF"] is not None else "未定義", v["保存点連結時価DD"], v["positions"], v["entry_quantity"], b["active"], b["denom"], Decimal(b["active"])/b["denom"], v["unit_positive_closed_negative_yen"], v["activated_closed_negative_yen"], v["early_warning_activations"]])
    for session in sessions:
        for key in keys:
            r = pairs[session, key]
            p, c, d = key.split("_")
            a, clock = r["活動主表"], r["時計割当"]
            output["details"].append([session[:10]+"T00:00:00.000Z", labels[session.split("_")[1]], labels[r["history_class"]], p, c+"/"+d, r["gross_yen"], r["fee_yen"], r["slip_yen"], r["net_yen"], r["positions"], r["entry_quantity"], a["active"], a["denom"], Decimal(a["active"])/a["denom"], clock["静観繰越"], clock["受理出生"], clock["実取得出生"], clock["受理後0取得取消"], r["unit_positive_closed_negative_yen"], r["activated_closed_negative_yen"], r["early_warning_activations"], r["narrowed_positions"]])
    for name, item in result["同実入口と実現額差"].items():
        after, before = name.split("対")
        v = item["合計"]
        output["comparisons"].append([item["区分"], after, before, *[v[f] for f in ("全差額", "同実入口玉", "同実入口差額", "取得変更玉", "取得変更差額", "前のみ玉", "前のみ実現額", "後のみ玉", "後のみ実現額")]])
    public = {r["session"]: r for r in result["一公表単位の役割診断"]}
    for session in sessions:
        r = public[session]
        output["publications"].append([session[:10]+"T00:00:00.000Z", labels[session.split("_")[1]], labels[pairs[session, keys[0]]["history_class"]], r["numeric_seed_carried"], r["new_three"], r["C_known"], r["C_pass"], *[r[side][field] for side in ("buy", "sell") for field in ("M_known", "M_pass", "P_known", "P_pass")]])
    return output


def compare(before, after, appended):
    """
    機能: 旧5タブの全セル/式/型/書式/構造と全図表部品を照合する。
    引数: before/after(Path)、appended(bool)は追記前後と第六タブ追加の有無。
    返り値: dictは保持件数。既存の数値日付を新型へ正規化して差を隠さない。
    """
    assert OLD.digest(before) == BASE_SHA
    a, sa, ca = OLD.read_workbook(before)
    b, sb, cb = OLD.read_workbook(after)
    assert list(sa) == SHEETS and list(sb) == SHEETS + ([TARGET] if appended else [])
    counts = []
    for name in SHEETS:
        assert ca[name] == cb[name], name
        assert OLD.normalized_part(a, sa[name]) == OLD.normalized_part(b, sb[name]), name
        counts.append({"sheet": name, "旧全セル": len(ca[name]), "値_式_型_書式_構造保持": True})
    objects = [n for n in a if n.startswith(("xl/charts/", "xl/drawings/", "xl/tables/"))]
    assert set(objects) == {n for n in b if n.startswith(("xl/charts/", "xl/drawings/", "xl/tables/"))}
    assert all(OLD.normalized_part(a, n) == OLD.normalized_part(b, n) for n in objects)
    for name in ("fonts", "fills", "borders", "cellStyleXfs", "cellXfs", "cellStyles", "dxfs", "numFmts"):
        x = ET.fromstring(a["xl/styles.xml"]).find("m:"+name, OLD.NS)
        y = ET.fromstring(b["xl/styles.xml"]).find("m:"+name, OLD.NS)
        if x is not None:
            assert y is not None and len(y) >= len(x) and all(ET.tostring(u) == ET.tostring(v) for u, v in zip(x, y))
    for name in ("definedNames", "bookViews", "workbookProtection"):
        x = ET.fromstring(a["xl/workbook.xml"]).find("m:"+name, OLD.NS)
        y = ET.fromstring(b["xl/workbook.xml"]).find("m:"+name, OLD.NS)
        assert (ET.tostring(x) if x is not None else None) == (ET.tostring(y) if y is not None else None)
    assert not [n for cells in cb.values() for n, c in cells.items() if c["type"] == "e"]
    return {"旧5タブ": counts, "旧図表parts": len(objects), "旧styles定義保持": True, "全ZIP_CRC": True}


def verify_tables(expected, cells):
    """
    機能: 固定正本から生成した全表と保存後セルを全領域で照合する。
    引数: expected(dict)はJS mapperの表、cells(dict)は新タブのOOXML。
    返り値: dictは件数。金額/件数は厳密、比率/PFだけ1e-13の保存表現差を許す。
    """
    dates = checked = 0
    for kind, start in ROWS.items():
        for i, row in enumerate(expected[kind]):
            for j, value in enumerate(row):
                key = chr(65+j) + str(start+i)
                actual = cells[key]
                if j == 0 and kind in ("details", "publications"):
                    serial = date_value({"type": "d", "value": value})
                    assert date_value(actual) == serial
                    dates += 1
                elif isinstance(value, bool):
                    assert actual["type"] == "b" and actual["value"] == ("1" if value else "0")
                elif type(value) in (int, Decimal):
                    rate = (kind == "summary" and j in (6, 12)) or (kind == "clock" and j == 15) or (kind in ("daynight", "history") and j in (4, 10)) or (kind == "details" and j == 13)
                    if rate:
                        assert abs(actual["value"] - value) < Decimal("1e-13"), key
                    else:
                        assert actual["value"] == value, key
                else:
                    assert actual["value"] == value, key
                checked += 1
    return {"全表セル": checked, "日付": dates, "ISOと旧serialの型を区別": True}


def main():
    """
    機能: 今は旧5タブの基準、将来は追記後全領域を読取だけで検査する。
    引数: --baseline又は--source/--source-sha、--outは新規QA先。
    返り値: なし。xlsx編集/export/markerは行わない。
    """
    p = argparse.ArgumentParser()
    p.add_argument("--baseline", action="store_true")
    p.add_argument("--source", type=Path)
    p.add_argument("--source-sha")
    p.add_argument("--out", type=Path, required=True)
    args = p.parse_args()
    before = BOOK if args.baseline else WORK / "107追記前.xlsx"
    proof = compare(before, BOOK, not args.baseline)
    if not args.baseline:
        assert args.source and OLD.digest(args.source) == args.source_sha
        expected = source_tables(json.loads(args.source.read_text(encoding="utf-8-sig"), parse_float=Decimal))
        _, _, values = OLD.read_workbook(BOOK)
        original = copy.deepcopy(values[TARGET])
        proof.update(verify_tables(expected, values[TARGET]))
        assert values[TARGET] == original
    proof.update({"成功": True, "ブックSHA256": OLD.digest(BOOK), "xlsx編集_export_marker": 0,
                  "scope": "既存5タブ読取基準" if args.baseline else "旧5保持と107全表保存後照合"})
    with args.out.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(proof, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"成功": True, "旧5全セル": sum(x["旧全セル"] for x in proof["旧5タブ"]), "旧parts": proof["旧図表parts"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
