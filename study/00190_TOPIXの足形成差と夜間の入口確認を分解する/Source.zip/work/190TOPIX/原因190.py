"""形成差を同q0の実側・追加入口・保有枠の変化に分解する。"""
from pathlib import Path
from collections import defaultdict
import sys,json,gzip
import 入口190 as E
sys.path.insert(0,str(E.ROOT/'work/189TOPIX'))
import 原因189 as C
C.HERE=E.HERE
M=E.M


def financial(d,n):
    """
    機能: 指定Day/Night候補の金融台帳を読む。
    引数: d,n(int)。
    返り値: dictはpack。
    """
    return E.read(E.HERE/'金融正本'/('TOPIX190_'+E.DAY[d]+'_'+E.NIGHT[n]+'_DayA25_NightW15_H60.json.gz'))


def rows(pack,day):
    """
    機能: 実取得を要求の原行単位で引く。
    引数: pack(dict),day(bool)。
    返り値: dict[tuple,dict]は台帳行。売買方向をkeyへ含めず方向差を分離する。
    """
    l=pack['ledger'];out={}
    for i,scene in enumerate(l['scene']):
        if (l['phase'][i]==0)!=day:continue
        out[(scene,l['request_time'][i],l['request_line'][i])]={k:v[i] for k,v in l.items()}
    return out


def main():
    """
    機能: 保存金融だけから差分と深いDay損失場の当時特徴を記録する。
    引数: なし。
    返り値: None。未取得の仮想利益を機会損失として計算しない。
    """
    pure={(r['session'],r['time'],r['line']):r for r in E.read(E.HERE/'純入口.json.gz')}
    decomposed=[]
    for a,b in [(0,1),(1,2),(2,3),(1,9),(2,8)]:
        left=rows(financial(0,a),False);right=rows(financial(0,b),False);common=left.keys()&right.keys()
        same=[k for k in common if left[k]['side']==right[k]['side']];opposite=common-set(same)
        entry_changed={'旧のみ_相手入口なし':[],'旧のみ_相手枠抑制':[],'新のみ_相手入口なし':[],'新のみ_相手枠抑制':[]}
        for key in left.keys()-right.keys():entry_changed['旧のみ_相手入口なし' if pure[key]['signals'][b]==0 else '旧のみ_相手枠抑制'].append(left[key])
        for key in right.keys()-left.keys():entry_changed['新のみ_相手入口なし' if pure[key]['signals'][a]==0 else '新のみ_相手枠抑制'].append(right[key])
        assert all(left[k]['net']==right[k]['net'] for k in same)
        decomposed.append({'旧':E.NIGHT[a],'新':E.NIGHT[b],'旧合計':C.total(left.values()),'新合計':C.total(right.values()),
           '同q0同側':C.total(left[k] for k in same),'同q0逆側_旧':C.total(left[k] for k in opposite),'同q0逆側_新':C.total(right[k] for k in opposite),
           '入口と枠の差':{k:C.total(v) for k,v in entry_changed.items()}})
    day0=financial(0,0);day4=financial(4,0)
    a=C.trades(day0['id'],'DAY');b=C.trades(day4['id'],'DAY');day=C.compare(a,b)
    grouped=defaultdict(list)
    for r in rows(day4,True).values():grouped[r['scene']].append(r)
    worst=sorted(grouped,key=lambda scene:sum(r['net'] or 0 for r in grouped[scene]))[:3]
    features={(r['session'],r['time'],r['line']):r for r in E.read(E.ROOT/'inputs/TOPIX原順8列_20260921_20261116/純特徴184直接.json.gz')}
    evidence=[]
    for scene in worst:
        records=[]
        for r in grouped[scene]:
            key=(scene,r['request_time'],r['request_line']);f=features[key];s=r['side'];m=f['m5'];long=f['m30'];a=f['atr']
            records.append({'time':r['request_time'],'side':s,'net':r['net'],'width':r['width'],'origin':r['origin'],
             'RSI実側':m['rsi'] if s==1 else 100-m['rsi'],'ADX':m['adx'],'EMA8_21実側ATR':s*(m['ema8']-m['ema21'])/a,
             'MACD実側ATR':s*m['hist']/a,'MACD増分実側ATR':s*(m['hist_delta'] or 0)/a,'RSI増分実側':s*(m['rsi_delta'] or 0),
             '30分傾き実側':s*(long['slope'] or 0) if long else None,'BBz実側':s*m['bbz'] if m['bbz'] is not None else None,
             '相対量':f['rvol'],'1分逆行幅ATR':s*f['body'],'spread_ATR':f['spread']/a})
        evidence.append({'scene':scene,'集計':C.total(grouped[scene]),'入口時特徴':records})
    result={'事後診断':True,'Night形成分解':decomposed,'DayD4補完差':day,'Day深い赤字3場':evidence,
       '注意':'同q0でも方向を変えれば保有枠が変わり後続取得が変化する。入口不成立と枠抑制を分け、未取得仮想損益は計算しない。'}
    M.save(E.HERE/'原因診断.json',result)
    print(json.dumps({'DayD4補完差':day,'Day深い赤字3場':[{k:v for k,v in r.items() if k!='入口時特徴'} for r in evidence]},ensure_ascii=False))


if __name__=='__main__':main()
