"""版8の567セルを保ち、186/189/190の実使用設定を記録する。"""
from pathlib import Path
import hashlib,re,os
ROOT=Path(__file__).resolve().parents[2]


def make(number,path):
    """
    機能: 汎用表を試行へコピーし、使用指標・尺度・条件を記入する。
    引数: number(int),path(Path)は正式試行。
    返り値: None。旧固定試行の表は変更しない。
    """
    template=ROOT/'docs/議論/手法と時間スケールの汎用表_版8.md';raw=template.read_text('utf-8')
    body=raw.split('## 設定明細')[0].replace('# 手法と時間スケールの汎用表・版8',f'# {number} TOPIX 設定と結果・版8')
    body=body.replace('全セルは未設定・未検証。','使用セルを今回の固定設定で記入した。未使用は今回の入口で参照しないことを意味し、手法が無効と検証したことを意味しない。')
    body=body.replace('未設定・未検証','未使用')
    cfg={'I01':{3:'S1 EMA8/21・傾き・3確定足持続',4:'S1 中期方向'},'I02':{3:'S2 EMA8距離/ATR'},
       'I03':{3:'S3 MACD12/26/9・差分'},'I04':{3:'S3 RSI14・差分'},'I08':{3:'S4 DI/ADX14',4:'S4 DI符号'},
       'I09':{3:'S5 ATR14・q0以前公表'},'C01':{1:'S6 押戻し/再開',3:'S1〜S4 複合背景',4:'S1/S4 方向'},
       'C07':{1:'S6 確定1分確認',3:'S1/S3/S4',4:'S1/S4'},'P01':{1:'S6 実体・終値進行・足幅'},
       'P05':{1:'S6 現足/前終値増分'},'P07':{1:'S7 直前3本端と次足受容'},
       'P08':{1:'S7 EMA8回復・固定水準保持',3:'S1 固定EMA基準'},'V01':{1:'S8 相対量20本・既知/未知分離'},
       'B01':{0:'S9 正常BBO・spread≤1.5pt'},'B02':{0:'最良数量1以上の品質のみ。偏り未使用'},
       'E01':{0:'E1 固定同幅IFD・H60'},'E02':{0:'E2 固定TP/SL・終端。追尾対象外'}}
    if number==186:
        cfg['I05']={3:'S10 BB20z・R1端回復'};cfg['P09']={1:'S7 端回復'}
    else:
        for key in ('I01','I08','C07'):cfg[key][5]='S11 30分方向（量不明補完/支持）'
    if number==190:
        cfg['B01'][0]+='・直近300秒密度';cfg['I08'][3]='S4 DI14（ADX水準は未使用）'
        cfg.pop('P07')
    lines=[]
    for line in body.splitlines():
        if line.startswith('| '):
            f=[s.strip() for s in line.strip().strip('|').split('|')]
            if len(f)==11 and f[0] in cfg:
                for slot,value in cfg[f[0]].items():f[slot+2]=value
                line='| '+' | '.join(f)+' |'
        lines.append(line)
    body='\n'.join(lines)+'\n'
    body=re.sub(r'\]\(([^)]+)\)',lambda m:']('+os.path.relpath((template.parent/m.group(1)).resolve(),path).replace('\\','/')+')',body)
    details={186:'S1の持続は同じ5分足を重複させない3つの確定足、end間隔300秒。緩2/3・厳3/3。DI実方向0.015/0.04以上、位置−0.75〜1.5/1ATR、相対量0.5/1以上。圧力中の押戻し/再開・突破受容・反転受容等12組×2近傍×2形成×4幅＝216組。30分は入力に生成するが入口では未使用。',
      189:'主は186 P0緩。Q1は相対量不明だけ、三足同方向/3本5分持続/位置−0.5〜0.75ATRで補完。Q2は不明と別に既知相対量0.5未満・1分幅0.75ATR以下を許す。Night14方針は全反転とADX25/費用spread比0.25/30分逆向き/1分逆進0.3ATRかつrvol1.2等による切替。3×14×2形成×2幅＝168組。',
      190:'Day D0主/D1Q1/D2急変除外/D3翌足回復/D4量不明でもMACDとRSI改善。Night旧・共通旧・共通直接・直接の4対照＋合意/他形成DI支持/ATR交換/密度等12案、計60組。同q0は場・価格時計・公表原行が完全一致。直近300秒に異なる正常価格時計10以上・最大空白30秒以内。受信品質を経済的局面と同一視しない。'}
    widths={186:'固定10/15pt又はq0ATR×1.5/2.5',189:'固定15pt又はq0ATR×2.5',190:'全候補Day=q0直接ATR×2.5、Night=固定15pt'}
    body+='\n## 設定明細と複合評価\n\n'+details[number]+'\n\n'
    body+='S1〜S5は公開済み確定足のみ、EMA初値/平滑/時計は183実装修正1と184を固定。S6/S7は確定1分で、受容は前q0の固定端/EMAを次の連続1分でも同側に保持、実時間30〜90秒。途中戻り許容は厳0/緩0.1ATR。S8は当時可視の観測累積差分量で欠測を0にしない。S9はラージBBO代用でミニ約定を保証しない。\n\n'
    body+='E1は'+widths[number]+'、ATR幅は5〜25ptへ制限し0.25pt切上げ、取得後固定。E2はH60、保有予約1枚、Day15:29/Night05:44に終了要求し15:30/05:45まで。miniTOPIX1枚・片道41.8円＋0.25pt。途中追尾は対象外。\n\n'
    body+='完全閾値は[条件](条件.json)とSource、結果・採否・限界は[README](README.md)。複合成績を指標単独の有効性としない。未使用のVWAP/OFI/板偏り等は未検証。旧/直接の履歴不足・数量不明は当該入口を不成立とし0量へ補完しない。\n\n'
    body+=f'元の汎用表版8 SHA256 `{hashlib.sha256(template.read_bytes()).hexdigest()}`。63手法×9尺度＝567セル。\n'
    path.mkdir(parents=True,exist_ok=True);(path/'設定と結果.md').write_text(body,encoding='utf-8')


if __name__=='__main__':
    for number,name in [(186,'00186_TOPIXの圧力持続と反転受容を入口で分ける'),(189,'00189_TOPIXの量不足補完と夜間の実方向切替を比較する'),(190,'00190_TOPIXの足形成差と夜間の入口確認を分解する')]:make(number,ROOT/'study'/name)
