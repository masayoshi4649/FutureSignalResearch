"""同じDay/Night固定IFDで60口座の入口と形成差を比較する。"""
from pathlib import Path
from copy import deepcopy
import json,sys
import 入口190 as E
M=E.M
import 金融を比較する as F
A=F.A


def main():
    """
    機能: 共通q0と追加q0を含む60政策を全81場で再生する。
    引数: なし。
    返り値: None。全体と帯/期間別の正本を保存する。
    """
    cfg=E.read(E.HERE/'条件.json');assert cfg['SourceSHA']==M.sha(E.HERE/'入口190.py')
    assert cfg['純入口SHA']==M.sha(E.HERE/'純入口.json.gz')
    seal=E.HERE/'金融開始前固定.json';assert not seal.exists()
    M.save(seal,{'金融Source':M.sha(Path(__file__)),'条件SHA':M.sha(E.HERE/'条件.json'),'人工確認':E.read(E.HERE/'人工確認.json'),
      'IFDSource':M.sha(M.HERE/'入口とIFD.py'),'安定性Source':M.sha(E.ROOT/'work/183損失安定性/安定性183.py')})
    entries=deepcopy(E.read(M.HERE/'入力台帳.json')['entries']);mapping={r['session']:r for r in E.read(E.ROOT/'inputs/TOPIX原順8列_20260921_20261116/台帳.json')['entries']}
    for e in entries:e['cache_absolute']=str(E.ROOT/mapping[e['session']]['path'])
    meta=F.sessions(entries);by={e['session']:[] for e in entries}
    for r in E.read(E.HERE/'純入口.json.gz'):by[r['session']].append(r)
    packs=[]
    for name in E.NAMES:
        p=F.empty('TOPIX190_'+name+'_DayA25_NightW15_H60',meta);p['ledger']['origin']=[];packs.append(p)
    for e in entries:
        route=M.Route(e);cache={}
        for ci,pack in enumerate(packs):
            busy=-float('inf');signals=blocked=expired=accepted=0
            for r in by[e['session']]:
                side=r['signals'][ci]
                if not side:continue
                signals+=1
                if r['time']<=busy:blocked+=1;continue
                assert r['width'] is not None
                key=(r['time'],r['line'],side,r['width'])
                if key not in cache:cache[key]=route.cell(*key)
                cell=cache[key]
                if cell is None:expired+=1;continue
                accepted+=1;F.append(pack,dict(cell,origin=r['origins'][ci]));busy=route.end if cell['unknown'] else cell['exit_time']
            pack['diagnostics'].append({'scene':e['session'],'純成立':signals,'保有棄却':blocked,'取得':accepted,'失効':expired})
        print(e['session'],len(cache),flush=True)
    periods={'全80':[s['scene'] for s in meta[:-1]],'前48':[s['scene'] for s in meta[:48]],'後25':[s['scene'] for s in meta[48:73]],'追加7':[s['scene'] for s in meta[73:80]],'本日1':[meta[-1]['scene']]}
    stats=[];short=[];rankings={}
    for ci,pack in enumerate(packs):
        stat=A.evaluate_pack(pack,periods);stats.append(stat);M.save(E.HERE/'金融正本'/(pack['id']+'.json.gz'),pack)
        short.append({'id':pack['id'],'candidate':E.NAMES[ci],'Day':ci//12,'Night':ci%12,'全81':{b:F.terse(g) for b,g in stat['groups'].items()},
          '期間':{p:{b:F.terse(g) for b,g in block.items()} for p,block in stat['periods'].items()}})
    for period in ('全80','前48'):
        for band in ('DAY','NIGHT','ALL'):
            baseline=stats[0]['periods'][period][band]
            order=sorted(range(60),key=lambda i:(A.rank_key(stats[i]['periods'][period][band],baseline),packs[i]['id']))
            rankings[f'{period}_{band}']=[{'id':packs[i]['id'],'gate':A.gate(stats[i]['periods'][period][band],baseline)} for i in order]
    M.save(E.HERE/'全60組短表.json',{'rows':short,'順位':rankings});M.save(E.HERE/'全60組安定性.json.gz',{'metrics':stats,'順位':rankings})
    print('全60組金融完了',flush=True)


if __name__=='__main__':main()
