"""形成対照の同体・共通q0・公開幅・翌足回復の時計を金融前に確認する。"""
from pathlib import Path
import math,json
import 入口190 as E
M=E.M


def main():
    """
    機能: 60純入口の固定対照と時計を全q0で検査する。
    引数: なし。
    返り値: None。成績値は読まない。
    """
    raw=E.read(E.ROOT/'work/189TOPIX/純入口.json.gz');idx={int(k):{(r['session'],r['time'],r['line']):r for r in rows} for k,rows in raw.items()}
    rows=E.read(E.HERE/'純入口.json.gz');checks=0
    for r in rows:
        key=(r['session'],r['time'],r['line']);a=idx[0].get(key);b=idx[1].get(key);common=a is not None and b is not None
        assert r['common']==common;checks+=1
        if r['band']!='DAY':
            expected=[a['signals'][7] if a else 0,a['signals'][7] if common else 0,b['signals'][7] if common else 0,b['signals'][7] if b else 0]
            for d in range(5):assert r['signals'][d*12:d*12+4]==expected;checks+=4
            assert r['width']==15;checks+=1
        else:
            for n in range(12):
                assert r['signals'][n]==(b['signals'][0] if b else 0)
                assert r['signals'][12+n]==(b['signals'][14] if b else 0);checks+=2
            expected=math.ceil(min(25,max(5,b['atr']*2.5))*4)/4 if b else None
            assert r['width']==expected;checks+=1
        for s in r['signals']:assert s in (-1,0,1);checks+=1
        if r['観測密度']['密度合格']:
            assert r['観測密度']['観測異時刻数']>=10 and r['観測密度']['最大空白']<=30;checks+=2
    report={'成功':True,'確認数':checks,'対象':'同じ場/価格時計/公表原行でのq0共通、旧直接4対照同体、Day主とQ1同体、q0固定幅、観測品質条件'}
    M.save(E.HERE/'人工確認.json',report);print(json.dumps(report,ensure_ascii=False))


if __name__=='__main__':main()
