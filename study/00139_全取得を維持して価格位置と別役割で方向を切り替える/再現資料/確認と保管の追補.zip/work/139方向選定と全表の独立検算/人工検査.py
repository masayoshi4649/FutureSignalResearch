"""139独立検算部品の境界・未知・支持条件を人工だけで検査する。"""
from pathlib import Path
import copy
import importlib.util
import unittest

SPEC=importlib.util.spec_from_file_location('139独立算術',Path(__file__).with_name('検算する.py'))
M=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(M)


def row(identity: str, session: str='人工場', known: bool=True, price: float=1, hist: float=0) -> dict:
    """
    機能: A1/B3だけを持つ人工出生を作る。
    引数: identity/session(str)、known(bool)、price/hist(float)は識別・既知・境界値。
    返り値: dictは市場を参照しない出生。
    """
    return {'id':identity,'session':session,'baseline':False,'origins':[{'values':{
        M.A[0][1]:{'known':known,'value':price if known else None},
        M.B[2][1]:{'known':True,'value':hist}}}]}


# ----------------------------------------
def forty() -> tuple[list[dict],dict]:
    """
    機能: 10場各4件・両側完了かつ反転有利の人工40件を作る。
    引数: なし。
    返り値: tupleは出生列とID別ラベル。
    """
    rows=[row(f'人工{i}',f'人工場{i//4}') for i in range(40)]
    labels={r['id']:{'original':{'complete':True,'direction':-1,'ifd_known':True,'net5':-100},
        'reverse':{'complete':True,'direction':1,'ifd_known':True,'net5':1000}} for r in rows}
    return rows,labels


# ----------------------------------------
class Tests(unittest.TestCase):
    """自然金融・モデルを読まず検算算術を確認する。"""

    def test_rule_dictionary_and_boundaries(self) -> None:
        """
        機能: 28候補と含む/含まない閾値を検査する。
        引数: self(Tests)は状態。
        返り値: None。
        """
        self.assertEqual(len(M.RULES),28)
        self.assertFalse(any(a[0]=='A1' and b[0] in ('B1','B2') for a,b in M.RULES))
        self.assertTrue(M.predicate_all_origins(row('境界'),M.A[0]))
        self.assertTrue(M.predicate_all_origins(row('境界'),M.B[2]))
        self.assertFalse(M.predicate_all_origins(row('外',price=.999),M.A[0]))
        q={'origins':[{'values':{'rvol5':{'known':True,'value':.5}}}]}
        self.assertFalse(M.predicate_all_origins(q,M.B[8]))
        q['origins'][0]['values']['rvol5']['value']=2
        self.assertTrue(M.predicate_all_origins(q,M.B[9]))

    def test_unknown_and_multiple_origins(self) -> None:
        """
        機能: 未知や1originだけの失敗を0補完・多数決で通さない。
        引数: self(Tests)は状態。
        返り値: None。
        """
        self.assertFalse(M.predicate_all_origins(row('未知',known=False),M.A[0]))
        q=row('複数');q['origins'].append(copy.deepcopy(q['origins'][0]))
        q['origins'][1]['values'][M.A[0][1]]['value']=.5
        self.assertFalse(M.predicate_all_origins(q,M.A[0]))
        q['origins'][1]['values'][M.A[0][1]]={'known':False,'value':None}
        self.assertFalse(M.predicate_all_origins(q,M.A[0]))

    def test_40_pairs_10_sessions_utility_and_cash(self) -> None:
        """
        機能: 支持境界・utility差・費用差・最良1場除外を算術確認する。
        引数: self(Tests)は状態。
        返り値: None。
        """
        rows,labels=forty();r=M.score_rule((M.A[0],M.B[2]),0,rows,labels)
        self.assertEqual((r['complete_pairs'],r['support_sessions'],r['utility_gain'],r['score']), (40,10,80,77))
        self.assertEqual((r['net5_pair_gain'],r['gain_without_best_session']),(44000,72))
        self.assertTrue(r['eligible'])
        labels[rows[-1]['id']]['original']['complete']=False
        r=M.score_rule((M.A[0],M.B[2]),0,rows,labels)
        self.assertEqual((r['complete_pairs'],r['cash_pairs']),(39,40))
        self.assertFalse(r['eligible'])

    def test_money_unknown_is_not_zero(self) -> None:
        """
        機能: 両IFD既知が無い場合を0円有利として採用しない。
        引数: self(Tests)は状態。
        返り値: None。
        """
        rows,labels=forty()
        for label in labels.values():label['reverse']['ifd_known']=False;label['reverse']['net5']=None
        r=M.score_rule((M.A[0],M.B[2]),0,rows,labels)
        self.assertEqual(r['utility_gain'],80);self.assertIsNone(r['net5_pair_gain'])
        self.assertFalse(r['gates']['C5両側既知差正'])

    def test_one_session_dominance_and_zero_sessions(self) -> None:
        """
        機能: utilityゼロの支持場も数え、最良1場だけの改善を拒否する。
        引数: self(Tests)は状態。
        返り値: None。
        """
        rows,labels=forty()
        for i,r in enumerate(rows):
            if i<20:r['session']='改善1場'
            else:labels[r['id']]['original']['direction']=1
        r=M.score_rule((M.A[0],M.B[2]),0,rows,labels)
        self.assertEqual(r['gain_without_best_session'],0)
        self.assertFalse(r['gates']['最良1場除外gain正'])
        self.assertGreater(r['utility_gain'],0)


if __name__=='__main__':unittest.main(verbosity=2)
