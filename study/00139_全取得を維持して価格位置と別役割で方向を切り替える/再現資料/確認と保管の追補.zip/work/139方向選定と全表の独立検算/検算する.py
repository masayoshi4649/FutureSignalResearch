"""139の28ANDを独立算術で再選定し、全keepの180条件・3表を旧138へ照合する。"""
from pathlib import Path
from collections import defaultdict
import argparse
import hashlib
import json
import math

ROOT=Path(__file__).resolve().parents[2]
OWN=Path(__file__).resolve().parent
REFS={
    'F1':('work/139複合方向切替/F1学習前.json','410feaa8a6bf130b32018cc79587a008b5cf61be91d9eac19cd1c423ebd316a7'),
    'F2':('work/139複合方向切替/F2モデル固定.json','477d6b0e9bec0964709ed0c5af60335c68285d65821597917824555f5748c7f9'),
    'model':('work/139複合方向切替/選択モデル.json','9f393fa20ad1d9febf8e33d67dec70d743206947627537c6023e423020cea6c0'),
    'report':('work/139複合方向切替/前48の選定報告.json','9b07cddb8629db72e244e57eb3944b59b4cbc5d81ca5bb84357788e8e54eabd9'),
    'choices':('work/139複合方向切替/全752の方向.json','8de9503d793bfcefcc4e23d07c397fafd207c968e3792b31509307134b6806a3'),
    'features':('work/139複合方向切替/入力/出生特徴.json','1812f9d2479dcd383f257f8323cc83e714a8b42d28a0caa5b987fe1114dc5d5d'),
    'train':('work/139複合方向切替/入力/前48場のラベル.json','5ac6136ee3cede031b3a7569a4025da13b504b56365fef15983698ec664e8042'),
    'new_summary':('work/139複合方向切替/金融評価/集計.json','03e10dddb787472d53c241eddce85aa52beffc151ec04be2d4a0ffc6c03d3fd6'),
    'new_tables':('work/139複合方向切替/金融評価/CSV用の表.json','f0b077b63308651ec526a7d2bccd9b60e5a3235bedb7c5c5d9748f28b932ec1d'),
    'old_summary':('work/138全成立入口と頻度の集計/集計.json','6ef283db667603884b42260affce732ba5c9b31731d24b1bb18f9e96ee4b3486'),
    'old_tables':('work/138全成立入口と頻度の集計/CSV用の表.json','c8a83240c0345662353af42d5eeafa306bd68a710f53985be01dc0676c5f2f5d'),
}

# ----------------------------------------
# 条件.mdの表から独立に記述し、learner/Root集計の関数はimportしません。
A=[('A1','m5_price_ema21_atr_to_side','>=',1),('A2','bb15_position_sigma_to_side','>=',2),('A3','m5_forward_wick_ratio','>=',.25)]
B=[('B1','m30_gap_atr_to_side','<=',0),('B2','m15_ema21_delta_atr_to_side','<=',0),
    ('B3','m5_hist_delta_atr_to_side','<=',0),('B4','m15_hist_atr_to_side','<=',0),
    ('B5','m5_rsi_delta_to_side','<=',0),('B6','m15_adx','<=',20),('B7','m15_adx_delta','<=',0),
    ('B8','m5_tr_previous_atr_ratio','>=',2),('B9','rvol5','<',.5),('B10','rvol5','>=',2)]
RULES=[(a,b) for a in A for b in B if (a[0],b[0]) not in {('A1','B1'),('A1','B2')}]
assert len(RULES)==28


def sha(path: Path) -> str:
    """
    機能: 読取対象の全体指紋を取得する。
    引数: path(Path)は明示対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def verify_fixed(document: dict) -> int:
    """
    機能: F1/F2に列挙された全固定源を独立に照合する。
    引数: document(dict)は固定台帳。
    返り値: intは一致源数。原板のパスが含まれた場合は開かず拒否する。
    """
    for name,expected in document['ファイル'].items():
        path=Path(name)
        assert path.is_relative_to(ROOT) and ('work' in path.parts or 'study' in path.parts)
        assert 'JP_OSE_Data' not in path.parts and not name.endswith(('.ndjson','.book.gz'))
        assert sha(path)==expected,name
    return len(document['ファイル'])


# ----------------------------------------
def predicate_all_origins(row: dict, predicate: tuple) -> bool:
    """
    機能: 固定述語を全originが既知かつ満たす場合だけ成立とする。
    引数: row(dict)は出生行、predicate(tuple)はID・列・比較・閾値。
    返り値: bool。未知・1originでも不一致ならFalse。
    """
    _,column,operator,threshold=predicate
    assert row['origins']
    satisfied=True
    for origin in row['origins']:
        value=origin['values'][column]
        assert type(value['known']) is bool
        if not value['known']:
            assert value['value'] is None;satisfied=False
            continue
        number=value['value'];assert type(number) in (int,float) and math.isfinite(number)
        if operator=='>=':satisfied=satisfied and number>=threshold
        elif operator=='<=':satisfied=satisfied and number<=threshold
        else:
            assert operator=='<';satisfied=satisfied and number<threshold
    return satisfied


# ----------------------------------------
def score_rule(rule: tuple, order: int, rows: list[dict], labels: dict) -> dict:
    """
    機能: 1つのANDの支持・utility差・費用差と5資格を独立に算出する。
    引数: rule(tuple)、order(int)、rows(list[dict])は前48追加群、labels(dict)は同群を含む前48ラベル。
    返り値: dictは候補票。完了条件は選定時だけ、適用へ持ち込まない。
    """
    a,b=rule
    matched=[r for r in rows if predicate_all_origins(r,a) and predicate_all_origins(r,b)]
    pairs=0;utility_by_session=defaultdict(int);cash_differences=[]
    for r in matched:
        original,reverse=(labels[r['id']][k] for k in ('original','reverse'))
        if original['complete'] and reverse['complete']:
            pairs+=1;utility_by_session[r['session']]+=reverse['direction']-original['direction']
        if original['ifd_known'] and reverse['ifd_known']:
            cash_differences.append(reverse['net5']-original['net5'])
    gain=sum(utility_by_session.values());penalized=gain-3
    cash=sum(cash_differences) if cash_differences else None
    leave_best=gain-max(utility_by_session.values()) if utility_by_session else None
    gates={'40両側H完了':pairs>=40,'10場以上':len(utility_by_session)>=10,'gain罰則後正':penalized>0,
        'C5両側既知差正':cash is not None and cash>0,'最良1場除外gain正':leave_best is not None and leave_best>0}
    return {'rule_id':a[0]+'_'+b[0],'table_order':order,'matched_additional':len(matched),'complete_pairs':pairs,
        'support_sessions':len(utility_by_session),'utility_gain':gain,'score':penalized,'cash_pairs':len(cash_differences),
        'net5_pair_gain':cash,'gain_without_best_session':leave_best,'gates':gates,'eligible':all(gates.values())}


# ----------------------------------------
def financial_identity(new: dict, old: dict) -> int:
    """
    機能: 全keep時の139全180条件を旧138のnative/C0へ恒等照合する。
    引数: new/old(dict)は固定集計。
    返り値: intは一致条件数。算術関数を再用せず辞書全体を比較する。
    """
    count=0
    for split in ('all','train','validation'):
        for policy,prior in (('T0','P0'),('P0','P0'),('C0','C0')):
            for axis in ('BBO','Last'):
                for horizon in ('1800','3600'):
                    for width in ('25','50','100','125','200'):
                        assert new['集計'][split][policy][axis][horizon][width]==old['集計'][split][prior][axis][horizon][width],(split,policy,axis,horizon,width)
                        count+=1
    for key in ('参加','頻度','全4streamのphase検査','旧C0同体'):assert new[key]==old[key],key
    return count


# ----------------------------------------
def tables_identity(new: dict, old: dict) -> dict:
    """
    機能: 政策名・試行番号だけを移した旧138の三表全セルを照合する。
    引数: new/old(dict)は型付き表。
    返り値: dictは表別セル数。元結果・入力・反転価格を作り直さない。
    """
    assert new['試行']==139 and new['主政策']=='T0' and old['試行']==138
    assert [t['name'] for t in new['tables']]==[t['name'] for t in old['tables']]
    mapping=(('T0','P0'),('P0','P0'),('C0','C0'));checked={}
    for index,(current,prior) in enumerate(zip(new['tables'],old['tables'],strict=True)):
        assert (len(current['rows']),len(current['headers']))==[(180,34),(833,36),(73,49)][index]
        if index==0:
            assert current['headers']==prior['headers']
            look={(r[1],r[2],r[4],r[5],r[6]):r for r in prior['rows']}
            for actual in current['rows']:
                source={'T0':'P0','P0':'P0','C0':'C0'}[actual[2]]
                wanted=list(look[(actual[1],source,actual[4],actual[5],actual[6])])
                wanted[0]=139;wanted[2]=actual[2];assert actual==wanted
        else:
            prefix,block=(18,6) if index==1 else (13,12)
            old_policies=('P0','C0','R0')
            expected_headers=prior['headers'][:prefix]
            for policy,source in mapping:
                start=prefix+old_policies.index(source)*block
                expected_headers += [policy+h[len(source):] for h in prior['headers'][start:start+block]]
            assert current['headers']==expected_headers
            for actual,source_row in zip(current['rows'],prior['rows'],strict=True):
                wanted=list(source_row[:prefix]);wanted[0]=139
                for _,source in mapping:
                    start=prefix+old_policies.index(source)*block;wanted += source_row[start:start+block]
                assert actual==wanted
        checked[current['name']]=len(current['rows'])*len(current['headers'])
    assert sum(checked.values())==39685
    return checked


# ----------------------------------------
def main() -> None:
    """
    機能: Root通知の固定版だけを独立再選定・恒等検算して証跡を保存する。
    引数: CLI --execute-after-root-freeze(bool)は明示実行。
    返り値: None。学習器import・新Raw走査・条件最適化は行わない。
    """
    parser=argparse.ArgumentParser(description='139の独立選定と恒等検算')
    parser.add_argument('--execute-after-root-freeze',action='store_true',required=True)
    parser.parse_args()
    assert not (OWN/'独立検算.json').exists()
    for name,(relative,expected) in REFS.items():assert sha(ROOT/relative)==expected,name
    docs={name:json.loads((ROOT/relative).read_bytes()) for name,(relative,_) in REFS.items()}
    n1=verify_fixed(docs['F1']);n2=verify_fixed(docs['F2'])
    assert docs['F2']['F1_SHA256']==REFS['F1'][1] and docs['F2']['モデルSHA256']==REFS['model'][1]
    assert docs['F2']['選定報告SHA256']==REFS['report'][1] and docs['F2']['validationラベルを学習器へ渡した'] is False
    features,train=docs['features'],docs['train']
    assert len(features['rows'])==752 and len(features['sessions'])==73
    front=features['sessions'][:48];assert train['sessions']==front and train['split']=='train'
    labels={r['id']:r for r in train['rows']};assert len(labels)==len(train['rows'])==433
    assert set(labels)=={r['id'] for r in features['rows'] if r['session'] in front}
    for r in features['rows']:
        if r['id'] in labels:assert r['session']==labels[r['id']]['session']
    rows=[r for r in features['rows'] if r['session'] in front and not r['baseline']]
    assert len(rows)==379
    candidates=[score_rule(rule,i,rows,labels) for i,rule in enumerate(RULES)]
    assert candidates==docs['report']['candidates']
    qualified=[r for r in candidates if r['eligible']]
    winner=sorted(qualified,key=lambda r:(-r['score'],r['table_order']))[0] if qualified else None
    assert winner==docs['report']['winner'] is None
    model=docs['model'];assert model['selected_rule'] is None and model['protected_baseline']==81
    assert model['training_sessions']==front and model['features_sha256']==REFS['features'][1] and model['train_sha256']==REFS['train'][1]
    choices=docs['choices'];assert len(choices['rows'])==752 and choices['counts']=={'keep':752}
    assert choices['sessions']==features['sessions'] and choices['model_sha256']==REFS['model'][1]
    assert choices['features_sha256']==REFS['features'][1] and choices['labels_read'] is False
    protected=0
    for actual,feature in zip(choices['rows'],features['rows'],strict=True):
        assert all(actual[k]==feature[k] for k in ('id','session','native_side','baseline'))
        assert actual['selected_side']==feature['native_side'] and actual['action']=='keep' and actual['rule_id'] is None
        protected+=feature['baseline']
    assert protected==81
    conditions=financial_identity(docs['new_summary'],docs['old_summary'])
    cells=tables_identity(docs['new_tables'],docs['old_tables'])
    new=docs['new_summary'];native=docs['old_summary']['集計']['all']['P0']['BBO']['3600']['125']
    expected_main={'政策':'T0','順':native['forward'],'逆':native['adverse'],'未到達':native['neither'],'観測不足':native['censored'],
        '到達済み率':native['resolved_rate'],'70%以上':native['target70'],'取得数':752,
        '全73場最低1':new['参加']['all']['P0']['全場最低1取得'],'全時間平均件数毎時':new['頻度']['all']['P0']['全時間平均件数毎時']}
    assert new['主評価']==expected_main
    for k,name in [('モデルSHA256','model'),('方向SHA256','choices'),('F1_SHA256','F1'),('F2_SHA256','F2')]:assert new[k]==REFS[name][1]
    assert verify_fixed(docs['F1'])==n1 and verify_fixed(docs['F2'])==n2
    for name,(relative,expected) in REFS.items():assert sha(ROOT/relative)==expected,name
    result={'成功':True,'試行':139,'前48取得':433,'前48追加':379,'規則候補':28,'全候補票一致':True,
        '独立候補':candidates,'選定規則':None,'方向一致':752,'固定81保護':81,'全keep':True,
        '全財務条件一致':conditions,'全セル一致':sum(cells.values()),'表別セル数':cells,'F1全源一致':n1,'F2全源一致':n2,
        '入力源前後同体':True,'主評価':expected_main,'C5利益':native['ifd_net5_profit'],'C5損失':native['ifd_net5_loss'],
        'C5差引':native['ifd_net5_sum'],'IFD金額未知':native['ifd_unknown'],
        'learner_Root集計関数import':False,'後25ラベルを選定へ使用':False,'新Raw_CSV_追加2場読取':False,
        '金融検算の方式':'全keep752を独立に確認後、139の全180条件と39,685セルを旧138native/C0へ恒等照合',
        '参照入力':{name:{'path':relative,'sha256':expected} for name,(relative,expected) in REFS.items()},'検算コードSHA256':sha(Path(__file__))}
    with (OWN/'独立検算.json').open('x',encoding='utf-8') as stream:
        json.dump(result,stream,ensure_ascii=False,indent=2,allow_nan=False);stream.write('\n')
    print(json.dumps({'成功':True,'規則':None,'方向一致':752,'財務条件':conditions,'セル一致':sum(cells.values()),
        '検算SHA256':sha(OWN/'独立検算.json')},ensure_ascii=False))


if __name__=='__main__':main()
