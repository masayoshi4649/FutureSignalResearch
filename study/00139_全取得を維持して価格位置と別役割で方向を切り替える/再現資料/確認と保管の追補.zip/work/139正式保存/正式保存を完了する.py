"""139の追補コードを保管し、既存証跡/原文/リンクだけを確認して正式保存を閉じる。"""
from pathlib import Path
import gzip
import hashlib
import json
import re
import zipfile

ROOT=Path(__file__).resolve().parents[2]
FORMAL=next((ROOT/'study').glob('00139_*'))


def sha(body: bytes) -> str:
    """
    機能: 保存原文の指紋を求める。
    引数: body(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


# ----------------------------------------
def cells(body: str) -> list:
    """
    機能: 設定表の56行/504セルを抽出する。
    引数: body(str)。
    返り値: listはIDと9尺度値。
    """
    rows=[]
    for line in body.splitlines():
        if re.match(r'^\| [A-Z]+\d{2} \|',line):
            row=[x.strip() for x in line.strip('|').split('|')]
            if len(row)==11:rows.append([row[0],row[2:]])
    assert len(rows)==56 and sum(len(x[1]) for x in rows)==504
    return rows


# ----------------------------------------
def main() -> None:
    """
    機能: 新検証/金融をせず、保存済み139の最小再現資料と停止票を完成する。
    引数: なし。
    返り値: None。140の自然実行/採番、138以前変更、CSV生成をしない。
    """
    files=list((ROOT/'work/139正式保存').glob('*.py'))+list((FORMAL/'再現資料').glob('*.py'))
    files += [ROOT/'work/139方向選定と全表の独立検算'/n for n in ('README.md','検算する.py','人工検査.py')]
    files += [ROOT/'work/139未達原因と次の技術仮説'/n for n in ('短報と次の1案.md','報告を要約する.py')]
    files += [ROOT/'work/Source三手法の内側入口を照合する'/n for n in ('README.md','識別子だけを抽出する.py','同一性を監査する.py')]
    archive=FORMAL/'再現資料/確認と保管の追補.zip';entries=[]
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(set(files)):
            body=p.read_bytes();name=p.relative_to(ROOT).as_posix();z.writestr(name,body)
            entries.append({'path':name,'sha256':sha(body),'bytes':len(body),'区分':'独立検算・後発原因/Source監査・保管。F1/F2直接源とは別'})
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for item in entries:assert sha(z.read(item['path']))==item['sha256']
    mpath=FORMAL/'保管索引.json';m=json.loads(mpath.read_bytes())
    m['後発資料']={'ZIP':archive.name,'ZIP_SHA256':sha(archive.read_bytes()),'ZIP_bytes':archive.stat().st_size,'格納源数':len(entries),'格納源':entries}
    m['段階']='実行/独立検算/保存再現完了。モデルnull、全752keep、52.33%で70未達。新CSVなし'
    m['独立確認SHA256']='f1f8aece843fffea241f4974d5c081468aa6ae0d76cb7413827bb06b0a8b4c77'
    mpath.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    snapshot=json.loads(gzip.decompress((FORMAL/'検査/実行前文書.json.gz').read_bytes()))
    assert snapshot['文書数']==5 and snapshot['正式文書数']==3
    for item in snapshot['文書']:assert sha(item['本文'].encode('utf-8'))==item['sha256']
    original=next(x['本文'] for x in snapshot['文書'] if x['path'].endswith('/00139_全取得を維持して価格位置と別役割で方向を切り替える/設定と結果.md'))
    assert cells(original)==cells((FORMAL/'設定と結果.md').read_text('utf-8'))
    original=next(x['本文'] for x in snapshot['文書'] if x['path'].endswith('/00139_全取得を維持して価格位置と別役割で方向を切り替える/条件.md'))
    assert original.encode('utf-8')==(FORMAL/'条件.md').read_bytes()
    assert sha((FORMAL/'検査/F1学習前.json').read_bytes())==m['F1_SHA256'] and sha((FORMAL/'検査/F2モデル固定.json').read_bytes())==m['F2_SHA256']
    for item in m['共有入力']+m['新共用入力']+[m['固定モデル'],m['前48選定報告'],m['固定方向']]:
        body=(ROOT/item['保存元']).read_bytes();assert sha(body)==item['保存SHA256']
        raw=gzip.decompress(body) if item['形式']=='gzip' else body;assert sha(raw)==item['解凍SHA256']
    for item in [m['追加固定資料']]+m['共有固定コード群']:
        path=FORMAL/'再現資料'/item['ZIP'] if 'ZIP' in item else ROOT/item['保存元ZIP'];assert sha(path.read_bytes())==item['ZIP_SHA256']
        with zipfile.ZipFile(path) as z:
            assert z.testzip() is None
            for source in item['格納源']:assert sha(z.read(source.get('path',source.get('ZIP内path'))))==source['sha256']
    assert sha((FORMAL/'検査/独立検算.json').read_bytes())=='f1f8aece843fffea241f4974d5c081468aa6ae0d76cb7413827bb06b0a8b4c77'
    assert sha((FORMAL/'検査/独立停止の確認.json').read_bytes())=='dd811ad391d4ecdfecf3e490e8dfda5c495540abc2c005aed5ffd22eb5714aab'
    root=(FORMAL/'検査/Rootの金融段階の確定.json').read_bytes();assert sha(root)=='dfcfbc28719b8ec5c08cb8db334b899a1ff477c284945143697982d9ede7e07e'
    cert=json.loads(root);assert cert['F1_F2全源前後同体'] and cert['新CSV生成'] is False
    for name,h in cert['参照CSV'].items():assert sha((ROOT/m['CSV共有参照']/name).read_bytes())==h
    assert sha((FORMAL/'検査/保存入力の再現確認.json').read_bytes())=='71fba657c9d72fa9e12510ffdd6887cd533bb50a805c79084fda0ae97ec22a4e'
    model=json.loads((FORMAL/'成果物/選択モデル.json').read_bytes());assert model['selected_rule'] is None
    report=json.loads((FORMAL/'成果物/前48の選定報告.json').read_bytes());assert len(report['candidates'])==28 and report['winner'] is None
    assert sum(c['utility_gain']<0 and c['net5_pair_gain']<0 for c in report['candidates'])==27
    value=json.loads((FORMAL/'成果物/集計.json').read_bytes());main=value['集計']['all']['T0']['BBO']['3600']['125']
    assert [main[k] for k in ('entries','forward','adverse','neither','censored','ifd_net5_profit','ifd_net5_loss','ifd_net5_sum')]==[752,326,297,76,53,4217125,4631489,-414364]
    assert sha((FORMAL/'根拠/Source監査/完了.json').read_bytes())=='45422a1c2baaeba8d5979e483697c4e75f4357a429364d092560946a175b0d36'
    indices=[ROOT/p for p in ('README.md','study/README.md','docs/README.md','docs/議論/README.md')];links=0
    for p in list(FORMAL.rglob('*.md'))+indices:
        body=p.read_text('utf-8')
        if p in indices:assert '[139：' in body;body=body.split('\n\n',2)[1]
        for target in re.findall(r'\]\(([^)]+)\)',body):
            if target.startswith(('http:','https:','#')):continue
            assert (p.parent/target.strip('<>').split('#',1)[0]).resolve().exists(),(str(p),target);links+=1
    proof={'成功':True,'試行':139,'正式保存完了':True,'編集停止':True,'学習前全5MD/正式3MD同体保存':True,'条件/56手法504セル不変':True,
        'F1全30/F2全3源復元確認':True,'採用規則':None,'全752keep/旧81保護':True,'28中27のu/C5差負':True,
        '支持40完了10場の10規則も全て両差負':True,'独立28候補/180条件/39685表セル一致':True,'独立人工':5,
        '保存入力からモデル/候補票/方向/全金融/全表bytes再現':True,'CSVは138正本共有のみ':True,'新金融観測/Raw/CSV/140自然実行':False,
        'Source監査は同内側重複0で固定条件不変更':True,'138以前/追加2場変更':False,'4索引更新':True,'ローカルリンク':links,'重大不足':[],
        '主T0':main,'F1_SHA256':m['F1_SHA256'],'F2_SHA256':m['F2_SHA256'],'保管索引SHA256':sha(mpath.read_bytes()),
        '追補ZIP_SHA256':m['後発資料']['ZIP_SHA256'],'コードSHA256':sha(Path(__file__).read_bytes())}
    out=FORMAL/'検査/正式保存の最終確認.json';assert not out.exists();out.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'最終確認SHA256':sha(out.read_bytes()),'追補ZIP_SHA256':m['後発資料']['ZIP_SHA256'],'重大不足':[],'ローカルリンク':links},ensure_ascii=False))


if __name__=='__main__':
    main()
