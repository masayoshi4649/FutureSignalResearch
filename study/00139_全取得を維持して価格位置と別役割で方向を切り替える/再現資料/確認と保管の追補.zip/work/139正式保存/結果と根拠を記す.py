"""139の不採用モデル・28候補と共有CSVを正式に記録し、条件を不変に保つ。"""
from pathlib import Path
import gzip
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
FORMAL=next((ROOT/'study').glob('00139_*'))
OWN=ROOT/'work/139複合方向切替'


def sha(body: bytes) -> str:
    """
    機能: 停止資料の指紋を求める。
    引数: body(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


# ----------------------------------------
def write(path: Path,body: str) -> None:
    """
    機能: 日本語の正式説明をUTF-8で保存する。
    引数: path(Path)、body(str)。
    返り値: None。
    """
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(body.rstrip()+'\n',encoding='utf-8')


# ----------------------------------------
def record(source: Path,target: Path,packed: bool=False) -> dict:
    """
    機能: 原文を一度保存し指紋を残す。
    引数: source/target(Path)、packed(bool)。
    返り値: dictは両指紋と保存位置。
    """
    raw=source.read_bytes();body=gzip.compress(raw,mtime=0) if packed else raw;target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as handle:handle.write(body)
    return {'由来':source.relative_to(ROOT).as_posix(),'保存元':target.relative_to(ROOT).as_posix(),'形式':'gzip' if packed else '同体',
        '保存SHA256':sha(body),'原文SHA256':sha(raw),'保存bytes':len(body),'原文bytes':len(raw)}


# ----------------------------------------
def main() -> None:
    """
    機能: 正本から結果/28候補/未達短報/Source監査/4索引を整える。
    引数: なし。
    返り値: None。138以前・139条件・504セル・新CSVを変更/生成しない。
    """
    report=json.loads((FORMAL/'成果物/前48の選定報告.json').read_bytes());model=json.loads((FORMAL/'成果物/選択モデル.json').read_bytes())
    assert model['selected_rule'] is None and report['winner'] is None and len(report['candidates'])==28
    negative=[c for c in report['candidates'] if c['utility_gain']<0 and c['net5_pair_gain']<0]
    supported=[c for c in report['candidates'] if c['complete_pairs']>=40 and c['support_sessions']>=10]
    assert len(negative)==27 and len(supported)==10 and all(c in negative for c in supported)
    rows=[]
    for c in report['candidates']:
        support=c['complete_pairs']>=40 and c['support_sessions']>=10
        rows.append(f"|{c['rule_id']}|{c['matched_additional']}|{c['complete_pairs']}|{c['support_sessions']}|{c['utility_gain']:+}|{c['score']:+}|{c['net5_pair_gain']:+,}|{c['gain_without_best_session']:+}|{'○' if support else '×'}|{'採用' if c['eligible'] else '不採用'}|")
    write(FORMAL/'28候補の判定.md','''# 前48場だけで固定28候補を判定した結果

2026-11-12。前48の433取得のうち、保護対象54を除く追加379だけで判定した。後25の319取得のラベルや特徴値を選定へ使っていない。両期間は既使用で、真の未知期にはならない。詳細の[前48選定報告](成果物/前48の選定報告.json)、[固定条件](条件.md)を参照する。

uは両H完了例の順行+1/逆行−1/未到達0。Δuは実逆−native、罰則後はΔu−3。C5差は両側IFD既知のペアだけを用い、H不足でも既知touchを消さない。40両H完了/10場、罰則後正、C5差正、最高1場除外後Δu正の5条件を全て満たす規則だけを採る。

|規則|一致追加|両H完了|場|Δu|罰則後|C5ペア差・円|最高1場除外Δu|支持40/10|最終|
|---|---:|---:|---:|---:|---:|---:|---:|---|---|
'''+ '\n'.join(rows)+'''

全28中27はΔu/C5差とも負。40完了・10場を満たす10規則も全て両差が負だった。したがって、支持数の制限だけが不採用原因という説明にはならない。

唯一の両差正A3_B10（native順側ヒゲ比>=.25かつRVOL>=2）は一致14件、両H完了13件/9場、Δu+6・罰則後+3・C5差+121,000円・最高1場除外Δu+3。しかし40例/10場に届かず不採用。結果を見て支持や量の閾値を緩めていない。重複する28群を足して取引件数/損益を作らない。

結果は選択規則null、全752keep、旧81保護である。前48の既存情報から「伸長/ヒゲ＋別役割の弱さなら直ちに反転」という今回の候補を採用できなかった。全テクニカルの否定ではなく、実際の価格構造の失敗を確かめた新仮説とは別である。[未達と次の問い](根拠/未達と次案/短報と次の1案.md)。
''')
    write(FORMAL/'README.md','''# 全取得を維持して価格位置と別役割で方向を切り替える

試行00139。2026-11-12、前48限定の選定・モデル固定・適用・独立検算・保存再現を完了。**28候補から採用規則を得られず、selected_rule=null、全752をnativeのまま維持した。主T0は326順297逆76未到達53不足、H完了到達済み先着率52.33%で70%未達。**

## 仮説と結果

5分EMAからの1ATR伸長、15分BBの2σ位置、native順側ヒゲという価格位置/拒否Aに、別役割B（中長期MAの支持、MACD/RSI、ADX、値幅、量）をANDする28候補を事前固定した。単独の過熱で反転せず、全originsが既知・成立した場合だけ反転候補とした。後25ラベルを学習器へ渡さず、前48でモデルを固定してから全752へ適用した。

前48は433取得（旧81由来の保護54、追加379）。28候補中27は、実反転によるu差と費用C5差がともに負。40両H完了/10場を満たす10規則でも全て両差が負だった。支持件数の不足だけが問題だったわけではない。唯一の両差正A3_B10は13完了/9場で固定支持条件に届かず、閾値を緩めずに不採用とした。[全28候補の判定](28候補の判定.md)。

選択規則なしのため、T0は固定138P0と取得/方向/全金融数値が同体。追加671も間引かず、旧81の方向を保護した。全73場min1・平均1.0431164件/時を維持したが、改善規則を見つけた結果ではない。[条件](条件.md)と[全504セル](設定と結果.md)は実行前のまま、結果だけを追記した。

|政策|取得数|順/逆/未/不足|H完了到達済み先着率|C5利益・円|C5損失・円|既知差引・円|IFD既知/未知|
|---|---:|---|---:|---:|---:|---:|---|
|T0（主・規則なし）|752|326/297/76/53|52.33%|4,217,125|4,631,489|−414,364|732/20|
|P0（native対照）|752|326/297/76/53|52.33%|4,217,125|4,631,489|−414,364|732/20|
|C0（旧81）|81|40/18/17/6|68.97%|518,227|318,233|+199,994|78/3|

主率は326/(326+297)。全752分母は43.35%、H完了699分母は46.64%。未到達と観測不足、IFD金額未知は別に残す。費用条件C0（追加滑り0）なら主の既知差引+317,636円、費用C5は732既知件×追加1,000円で−414,364円となる。政策C0と費用条件C0は別の意味である。

前48の主T0は186順161逆・53.60%、C5−119,109円。後25は140順136逆・50.72%、−295,255円。全73場は既使用、後25を完全未知期とは呼ばない。入力の物理分離は選定への混入防止であり、新しい未知市場の証明ではない。

## 未達の解釈と次の問い

今回のAは平均/帯からの伸長やヒゲの状態であり、実際の突破失敗・支持抵抗の反転完成を証明していなかった。Bの弱さも、どの価格移動に伴う変化なのかを束縛しない一断面だった。継続中の過伸長や短い押戻しまで反転した可能性を原因仮説として残す。個々の悪化が全て持続トレンドだったと実測した結論ではない。

[停止済みの未達短報と次の1案](根拠/未達と次案/短報と次の1案.md)では、元向き突破が同じ確定足で旧域内へ戻る構造に、その足の勢い低下・量・出生現在の維持を束縛する問いへ分けた。この次案の抽出・成績を139の結果へ混ぜず、140以降に固定・検証する。支持数だけを緩めたりA3_B10へ主を交換したりしない。

別の[Source内側ID監査](根拠/Source監査/README.md)では、FAR初期456/P0由来420に同内側entry/同engine episodeの重複は見つからなかった。既除外の追加102以外に、この識別だけで頻度を減らす根拠はなかった。parent字面26群を誤結合せず、異なる技術setupの統計的独立を証明したとも呼ばない。139の選定規則や値を変更する監査ではない。

## 確認・限界・閲覧

別実装で28候補票・全752keep/81保護を確認し、主T0/P0と138P0、C0と138C0を対応させ、全180条件・三表39,685セルを恒等照合した。人工5群成功、learner/Root算術をimportせず、F1全30源/F2全3源は前後同体。保存入力から別workへ復元した再学習もモデル/選定報告/752方向が全bytes同体、全金融数値と三表JSONも再現した。

ラージ板による独立mini1枚100円/pt、往復77円、費用C5は追加1,000円。実IFD・利益追尾・mini実板・保有重複/片側10枚上限・資金制約を含む口座利益は未検証。反転側の注文geometryを再構築せず、保存BBOを使った同入口方向診断である。全期既使用、多重探索の中の固定一試行、追加2場は価格未読を維持した。

今回のCSVは重複生成せず、[139と138CSVの対応](閲覧資料.md)から既存三CSVを参照する。T0/P0→138P0、C0→138C0の対応を明記し、同じ取引を足して頻度や口座利益を作らない。

[再現手順](再現手順.md) / [保管索引](保管索引.json) / [独立検算](検査/独立検算.json) / [Rootの確定](検査/Rootの金融段階の確定.json)
''')
    setting=FORMAL/'設定と結果.md';text=setting.read_text('utf-8');assert '## 実行結果追記' not in text
    write(setting,text+'''

## 実行結果追記

2026-11-12。上の版6全56手法×9尺度＝504セルと条件は学習前F1から不変。28候補は前48の追加379から選定、採用なし・selected_rule=null・全752keep・旧81保護。支持40完了/10場を満たす10規則も全てu差/C5差が負であり、支持不足だけが原因ではない。唯一の両差正A3_B10も13完了/9場で不採用。[全28候補](28候補の判定.md)。

主T0=138P0(native)同体、326順297逆76未到達53不足・H完了到達済み52.33%、全73場min1・1.0431164件/時。C5利益4,217,125円/損失4,631,489円・既知差引−414,364円、732既知20未知。旧81対照は68.97%/+199,994円で不変。後25を使って再選択せず、主70%未達を固定した。

全180条件/39,685表セルは138との恒等性を独立確認。今回新CSVは作らず[138CSVの対応案内](閲覧資料.md)を参照する。[結果・限界](README.md)、[再現](再現手順.md)。
''')
    write(FORMAL/'閲覧資料.md','''# 139と既存138CSVの対応

2026-11-12。139は選択規則null・全752keepで、138と同じ取引の新しいCSVを生成していない。既存の[138 CSV案内](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/138全成立CSV/README.md)を参照する。

|139で読む政策|138CSVの対応|意味|
|---|---|---|
|T0（主）|P0|28候補から採用なし、全752native維持|
|P0（native対照）|P0|T0と同じ752、同じ方向/数値|
|C0（旧81保護）|C0|旧137A0の81取得/方向を固定|

138のR0は全実逆の参考診断で、139T0ではない。Root139の表JSONは政策名と試行番号を139へ置換しており、138 CSVとの対応を上表で示す。値の恒等性を確認した参照であり、CSVのヘッダにT0/139があると説明しない。

- [全セッション.csv](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/138全成立CSV/全セッション.csv)：73×49。P0列が139主T0、全場の取得/頻度/利益/損失/累計/未知を読む。
- [正逆比較.csv](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/138全成立CSV/正逆比較.csv)：180×34。主はall/P0/BBO/H60/±125。前48/後25・他H/幅・Lastを分ける。
- [入口別診断.csv](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/138全成立CSV/入口別診断.csv)：833×36。752+81の再掲で、833の独立取引数にしない。

全39,685セルの値を139表JSONへ政策/試行番号を対応させて独立照合した。既存のRoot CSV再読は16,951数値を含む全セル一致・三プレビュー確認済みで、139で再生成/新marker/xlsxを作っていない。三CSVのSHAは[Root確定](検査/Rootの金融段階の確定.json)と138案内に保存する。

独立mini1枚・費用C5の主既知差引−414,364円、利益4,217,125円/損失4,631,489円・未知20。口座残高ではない。金額未知を0にせず、先着率52.33%の分母は326/(326+297)として未到達76/不足53を別記する。
''')
    cause=ROOT/'work/139未達原因と次の技術仮説';sources=[]
    sources.append(record(cause/'診断.json',FORMAL/'根拠/未達と次案/診断.json'))
    body=(cause/'短報と次の1案.md').read_text('utf-8')
    body=body.replace('](../139複合方向切替/前48の選定報告.json)','](../../成果物/前48の選定報告.json)')
    body=body.replace('[報告を要約する.py](報告を要約する.py)','[要約コード（追補ZIP）](../../再現資料/確認と保管の追補.zip)')
    body=body.replace('](../次入口の因果順序を外部資料から整理する/README.md)','](../../../00135_公表差で不安定な方向上書きを抑える/根拠/次入口の因果順序.md)')
    title,rest=body.split('\n',1);write(FORMAL/'根拠/未達と次案/短報と次の1案.md',title+'\n\n保存注記：停止原文の値/条件は保持し、保存先リンクだけ調整した。次案の「未実行」は作成時点の履歴であり、後続の状態は各試行側で確認する。\n'+rest)
    audit=ROOT/'work/Source三手法の内側入口を照合する'
    assert sha((audit/'完了.json').read_bytes())=='45422a1c2baaeba8d5979e483697c4e75f4357a429364d092560946a175b0d36'
    for name in ('558通知の識別と時計.json','内側IDの監査.json'):sources.append(record(audit/name,FORMAL/'根拠/Source監査'/(name+'.gz'),True))
    sources.append(record(audit/'完了.json',FORMAL/'根拠/Source監査/完了.json'))
    body=(audit/'README.md').read_text('utf-8').replace('](内側IDの監査.json)','](内側IDの監査.json.gz)')
    write(FORMAL/'根拠/Source監査/README.md',body+'\n保存注記：結果/条件は原文のまま、JSONリンクだけgzip先へ調整した。原文MDと監査コードは追補ZIPへ保存した。')
    mpath=FORMAL/'保管索引.json';m=json.loads(mpath.read_bytes());m['未達短報とSource監査']=sources
    mpath.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    src=ROOT/'work/139保存入力の再現確認/保存入力の再現確認.json';record(src,FORMAL/'検査/保存入力の再現確認.json')
    for name,prefix,common in [('README.md','study/','docs/議論/'),('study/README.md','','../docs/議論/'),('docs/README.md','../study/','議論/'),('docs/議論/README.md','../../study/','')]:
        path=ROOT/name;body=path.read_text('utf-8');lines=body.splitlines();lines=[line for line in lines if not line.startswith('[139：')];head=lines[0];rest='\n'.join(lines[1:]).lstrip()
        summary=f'[139：価格位置と別役割で方向を切替]({prefix}{FORMAL.name}/README.md)を完了。前48限定28候補で採用0・モデルnull・全752keep/旧81保護。主52.33%、C5利益4,217,125円/損失4,631,489円・既知差引−414,364円で138P0同体、全73min1/1.04312件毎時を維持。支持40完了/10場の10規則も全てu/C5差が負。唯一両差正A3_B10は13完了/9場で不採用、支持だけが未達原因ではない。F1/F2原文・全504セル・28候補・全752方向・独立180条件/39,685表セルと完全再現を保存。CSVは138を共有参照。[閲覧対応]({prefix}{FORMAL.name}/閲覧資料.md)、[次の問い]({common}先着率を保ちながら時間あたりの取得数を増やす方針.md)。'
        write(path,head+'\n\n'+summary+'\n\n'+rest)
    print(json.dumps({'成功':True,'28候補':28,'採用':0,'条件/504セル':'不変','新CSV生成':False,'4索引':True},ensure_ascii=False))


if __name__=='__main__':
    main()
