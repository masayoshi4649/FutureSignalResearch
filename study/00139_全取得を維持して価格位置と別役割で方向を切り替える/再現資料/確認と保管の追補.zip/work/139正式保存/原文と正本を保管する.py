"""139の学習前F1/モデル固定F2と正式MDを先行退避し、必要入力を一度保存する。"""
from pathlib import Path
import gzip
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[2]
FORMAL=next((ROOT/'study').glob('00139_*'))
OWN=ROOT/'work/139複合方向切替'


def sha(body: bytes) -> str:
    """
    機能: 原文の指紋を求める。
    引数: body(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


# ----------------------------------------
def save(source: Path,target: Path,packed: bool=False) -> dict:
    """
    機能: 未作成先へ同体又はgzip保存し、復元票を返す。
    引数: source/target(Path)、packed(bool)。
    返り値: dictは保存/解凍のサイズとSHA。
    """
    raw=source.read_bytes();body=gzip.compress(raw,mtime=0) if packed else raw
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as handle:handle.write(body)
    return {'保存元':target.relative_to(ROOT).as_posix(),'復元先':source.relative_to(ROOT).as_posix(),'形式':'gzip' if packed else '同体',
        '保存bytes':len(body),'保存SHA256':sha(body),'解凍bytes':len(raw),'解凍SHA256':sha(raw)}


# ----------------------------------------
def main() -> None:
    """
    機能: F1全30源/F2全3源を重複なしで復元できるよう保存する。
    引数: なし。
    返り値: None。Raw/大入力/追加2場/138以前を変更しない。
    """
    f1raw=(OWN/'F1学習前.json').read_bytes();f2raw=(OWN/'F2モデル固定.json').read_bytes()
    assert sha(f1raw)=='410feaa8a6bf130b32018cc79587a008b5cf61be91d9eac19cd1c423ebd316a7'
    assert sha(f2raw)=='477d6b0e9bec0964709ed0c5af60335c68285d65821597917824555f5748c7f9'
    f1=json.loads(f1raw);f2=json.loads(f2raw);assert len(f1['ファイル'])==30 and len(f2['ファイル'])==3
    save(OWN/'F1学習前.json',FORMAL/'検査/F1学習前.json');save(OWN/'F2モデル固定.json',FORMAL/'検査/F2モデル固定.json')
    docs=[]
    for name,expected in f1['ファイル'].items():
        p=Path(name)
        if p.suffix=='.md':
            b=p.read_bytes();assert sha(b)==expected;docs.append({'path':p.relative_to(ROOT).as_posix(),'sha256':expected,'bytes':len(b),'本文':b.decode('utf-8')})
    assert len(docs)==5 and sum(x['path'].startswith('study/') for x in docs)==3
    snap={'試行':139,'段階':'学習前F1全MDの結果編集前原文','F1_SHA256':sha(f1raw),'F2_SHA256':sha(f2raw),'文書数':5,'正式文書数':3,'文書':docs,'F2に新MD':0,'事前固定の偽造':False}
    snapbody=gzip.compress((json.dumps(snap,ensure_ascii=False,indent=2)+'\n').encode('utf-8'),mtime=0)
    target=FORMAL/'検査/実行前文書.json.gz'
    with target.open('xb') as handle:handle.write(snapbody)
    prior133=next((ROOT/'study').glob('00133_*'));m133=json.loads((prior133/'保管索引.json').read_bytes())
    prior138=next((ROOT/'study').glob('00138_*'));m138=json.loads((prior138/'保管索引.json').read_bytes())
    groups=[];registry={}
    for folder,item in [(prior133,m133['固定コード']),(prior138,m138['追加固定資料'])]:
        path=folder/'再現資料'/item['ZIP'];assert sha(path.read_bytes())==item['ZIP_SHA256'];at=len(groups)
        groups.append({'保存元ZIP':path.relative_to(ROOT).as_posix(),'ZIP_SHA256':item['ZIP_SHA256'],'格納源':[]})
        for x in item['格納源']:registry.setdefault(x['sha256'],(at,x['path']))
    shared=[x for x in m138['共有入力'] if x['復元先'] in ('work/137既知回復と頻度の集計/集計.json','work/137既知回復の評価/固定取得の正逆観測.json')]
    shared += [x for x in m138['新共用入力'] if x['復元先'] in ('work/138全成立入口の評価/固定入力_版2/固定取得入力.json','work/138全成立入口の評価/固定入力_版2/入口参照.json','work/全成立poolの非金融manifest/manifest.json')]
    shared += [m138['保存済み正逆観測']];assert len(shared)==6
    new_inputs=[save(OWN/'入力'/name,ROOT/'inputs/00139_複合方向切替'/(name+'.gz'),True) for name in ('出生特徴.json','前48場のラベル.json','後25場のラベル.json')]
    inputs={x['復元先']:x for x in shared+new_inputs};new=[];bodies={}
    for name,expected in f1['ファイル'].items():
        p=Path(name);rel=p.relative_to(ROOT).as_posix()
        if rel in inputs:assert inputs[rel]['解凍SHA256']==expected;continue
        b=p.read_bytes();assert sha(b)==expected and len(b)<2_000_000
        if expected in registry:
            at,entry=registry[expected];groups[at]['格納源'].append({'復元先':rel,'ZIP内path':entry,'sha256':expected,'bytes':len(b)})
        else:new.append({'path':rel,'sha256':expected,'bytes':len(b)});bodies[rel]=b
    assert len(new)+sum(len(g['格納源']) for g in groups)+len(inputs)==30
    archive=FORMAL/'再現資料/139学習前の固定資料.zip';archive.parent.mkdir(exist_ok=True)
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for item in new:z.writestr(item['path'],bodies[item['path']])
    for g in groups:g['格納源数']=len(g['格納源'])
    model=save(OWN/'選択モデル.json',FORMAL/'成果物/選択モデル.json')
    report=save(OWN/'前48の選定報告.json',FORMAL/'成果物/前48の選定報告.json')
    choices=save(OWN/'全752の方向.json',ROOT/'inputs/00139_複合方向切替/全752の方向.json.gz',True)
    aggregate=save(OWN/'金融評価/集計.json',FORMAL/'成果物/集計.json')
    for source,target in [(OWN/'入力/分離の確認.json','入力分離の確認.json'),(OWN/'Rootの金融段階の確定.json','Rootの金融段階の確定.json'),
        (OWN/'金融評価の完了.json','金融評価の完了.json'),(ROOT/'work/139方向選定と全表の独立検算/独立検算.json','独立検算.json'),
        (ROOT/'work/139方向選定と全表の独立検算/停止の確認.json','独立停止の確認.json')]:save(source,FORMAL/'検査'/target)
    m={'試行':139,'段階':'原文/入力/正本の保存完了、結果編集前','F1_SHA256':sha(f1raw),'F2_SHA256':sha(f2raw),'F1直接源':30,'F2直接源':3,
        '追加固定資料':{'ZIP':archive.name,'ZIP_SHA256':sha(archive.read_bytes()),'ZIP_bytes':archive.stat().st_size,'格納源数':len(new),'格納源':new},
        '共有固定コード群':groups,'共有入力':shared,'新共用入力':new_inputs,'固定モデル':model,'前48選定報告':report,'固定方向':choices,'集計正本':aggregate,
        'CSV共有参照':'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/138全成立CSV','新CSV/Raw/大入力複製':False,
        '139T0/P0は138P0と金融数値同体':True,'保護C0は138C0同体':True,'追加2場読取/138以前変更':False}
    (FORMAL/'保管索引.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'原文MD':5,'正式MD':3,'F1全源復元':30,'新固定ZIP源':len(new),'共有固定源':sum(g['格納源数'] for g in groups),
        '新入力/方向gzip':4,'新ZIP_SHA256':m['追加固定資料']['ZIP_SHA256']},ensure_ascii=False))


if __name__=='__main__':
    main()
