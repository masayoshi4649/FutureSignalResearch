"""139固定報告だけを数え、閾値変更や金融の再計算を行わない。"""
import hashlib
import json
from pathlib import Path


def summarize(report: dict) -> dict:
    """
    機能: 固定28候補の支持条件と改善方向を分類する。
    引数: report(dict)は前48の固定選定報告。
    返り値: dictは件数・唯一の正差候補・因果推定の限界。
    """
    rows = report['candidates']
    assert report['trial'] == 139 and len(rows) == 28 and report['winner'] is None
    supported = [r for r in rows if r['gates']['40両側H完了'] and r['gates']['10場以上']]
    negative = [r for r in rows if r['utility_gain'] < 0 and r['net5_pair_gain'] < 0]
    positive = [r for r in rows if r['utility_gain'] > 0 and r['net5_pair_gain'] > 0]
    assert len(supported) == 10 and len(negative) == 27 and len(positive) == 1
    assert all(r in negative for r in supported)
    assert positive[0]['rule_id'] == 'A3_B10' and not positive[0]['eligible']
    return {
        '成功': True, '試行': 139, '学習場数': report['train_sessions'],
        '学習全例': report['train_entries'], '学習追加例': report['train_additional'],
        '固定候補数': 28, 'u差とC5差が共に負': len(negative),
        '40完了かつ10場を満たす候補数': len(supported),
        '支持条件を満たすがu差とC5差が共に負': len(supported),
        '唯一の両差正候補': positive[0], '選定規則': None,
        '固定報告から確認できること': '支持不足だけではなく、支持のある全10規則でも当該ANDの反転は悪化した',
        '固定報告だけでは確定できないこと': '各悪化例が持続トレンド、短い押戻し、価格時計差のどれだったかという個別原因',
        '後25を使う再選択': False, '139変更又は再学習': False,
        '原板又はCSV又は追加2場読取': False, '新候補の抽出又は金融計算': False,
    }


def main() -> None:
    """
    機能: 許可された固定報告を読み、小型診断を未作成先へ保存する。
    引数: なし。
    返り値: None。旧報告・モデル・規則は書き換えない。
    """
    source = Path(__file__).resolve().parents[1] / '139複合方向切替' / '前48の選定報告.json'
    data = source.read_bytes()
    result = summarize(json.loads(data))
    result['出典'] = {'path': str(source), 'sha256': hashlib.sha256(data).hexdigest()}
    result['コードSHA256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    target = Path(__file__).with_name('診断.json')
    with target.open('x', encoding='utf-8') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    assert hashlib.sha256(source.read_bytes()).hexdigest() == result['出典']['sha256']
    print(json.dumps({'成功': True, '保存先': str(target), 'SHA256': hashlib.sha256(target.read_bytes()).hexdigest()}, ensure_ascii=False))


if __name__ == '__main__':
    main()
