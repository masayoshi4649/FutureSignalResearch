"""Source558/初期456/P0由来420を、価格を使わず内側IDとエンジン型で監査する。"""
from pathlib import Path
from collections import Counter,defaultdict
import gzip
import argparse
import hashlib
import importlib.util
import json
import os
import zipfile

ROOT=Path(__file__).resolve().parents[2]
OWN=Path(__file__).resolve().parent
SPEC=importlib.util.spec_from_file_location('識別子の選択読取',OWN/'識別子だけを抽出する.py')
READER=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(READER)
ENGINE={'NK225_D164_15':'S01','NK225_P164_06':'P05','NK225_U165_03':'D07'}


def sha(body: bytes) -> str:
    """
    機能: 監査資料の指紋を返す。
    引数: body(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


# ----------------------------------------
def grouped(rows: list, fields: tuple, cross_only: bool=False) -> list:
    """
    機能: 指定した識別キーの反復群を抽出する。
    引数: rows(list)、fields(tuple[str])、cross_only(bool)。
    返り値: listはキーと識別行。同一価格や成績は参照しない。
    """
    groups=defaultdict(list)
    for r in rows:groups[tuple(r[k] for k in fields)].append(r)
    return [{'key':list(k),'count':len(v),'methods':sorted({r['method'] for r in v}),
        'rows':[{key:r[key] for key in ('session','method','id','engine','source_id','parent','kind','birth','source_fill')} for r in v]}
        for k,v in groups.items() if len(v)>1 and (not cross_only or len({r['method'] for r in v})>1)]


# ----------------------------------------
def describe(rows: list) -> dict:
    """
    機能: 内側ID/episodeと表面文字列・時計の一致を分けて数える。
    引数: rows(list)は識別子だけの行。
    返り値: dictは件数と比較可能な全重複群。
    """
    source=grouped(rows,('session','engine','source_id'))
    parent=grouped(rows,('session','engine','parent'))
    raw_source=grouped(rows,('session','source_id'),True)
    surface_parent=grouped(rows,('session','parent'),True)
    internal=grouped(rows,('session','internal_id'),True)
    births=grouped(rows,('session','birth_key'),True)
    fills=grouped(rows,('session','fill_key'),True)
    return {'通知数':len(rows),'場数':len({r['session'] for r in rows}),'手法別':dict(Counter(r['method'] for r in rows)),
        'kind別':dict(Counter(r['kind'] for r in rows)),'正規の内側entry一意数':len({(r['session'],r['engine'],r['source_id']) for r in rows}),
        '正規の内側episode一意数':len({(r['session'],r['engine'],r['parent']) for r in rows}),
        '内側entry反復群':source,'同エンジンepisode反復群':parent,
        '生source_idのcross_method一致':raw_source,'internal_idのcross_method一致':internal,
        'parent文字列だけのcross_method一致':surface_parent,'出生原行のcross_method一致':births,'Sourcefill原行のcross_method一致':fills}


# ----------------------------------------
def artificial() -> None:
    """
    機能: engine別の同parent・同source字面と真の再通知を区別する。
    引数: CLI --check(bool)は既存の監査出力を上書きせず同体確認する指定。
    返り値: None。
    """
    base={'session':'人工_Night','method':'M1','id':'通知1','engine':'E1','source_id':'源1','parent':'core/0','kind':'initial',
        'birth':{'time':1},'source_fill':{'time':2},'internal_id':'外1','birth_key':(1,1,1),'fill_key':(2,2,2)}
    other={**base,'method':'M2','id':'通知2','engine':'E2','internal_id':'外2'}
    v=describe([base,other]);assert v['正規の内側entry一意数']==2 and len(v['parent文字列だけのcross_method一致'])==1
    repeat={**base,'id':'再通知','internal_id':'外3','birth_key':(9,9,9),'fill_key':(10,10,10)}
    v=describe([base,repeat]);assert v['正規の内側entry一意数']==1 and len(v['内側entry反復群'])==1
    another={**base,'id':'追加','source_id':'源2','internal_id':'外4','kind':'source_add'}
    v=describe([base,another]);assert v['正規の内側entry一意数']==2 and v['正規の内側episode一意数']==1


# ----------------------------------------
def main() -> None:
    """
    機能: 固定識別台帳/manifestと凍結コードから内側IDの一意性を確定する。
    引数: なし。
    返り値: None。価格/PnL/数量/Raw/追加2場や138/139条件を読まない/変更しない。
    """
    parser_args=argparse.ArgumentParser();parser_args.add_argument('--check',action='store_true');args=parser_args.parse_args()
    artificial();source=OWN/'558通知の識別と時計.json';source_bytes=source.read_bytes()
    assert sha(source_bytes)=='214f9dd3a56be729317d011090e31396e1abd2dee166a8f4c572a5c8897e5768'
    original=json.loads(source_bytes)
    old=ROOT/'work/全成立poolの技術条件を整理する/Source558の初期と追加.json'
    assert sha(old.read_bytes())=='654476d552a4fd4ac9737219703627eb2ff0b4b5e5e912b2d2521ecca36e34ad'
    old_parser=READER.SelectedJSON(old.read_text('utf-8'))
    old_meta=old_parser.read({'行':[{'session':None,'method':None,'id':None,
        'source_paper_hold':{k:None for k in ('kind','parent','source_id')},
        'source_paper_entry_fill':{'stamp':READER.STAMP}}]})
    old_parser.space();assert old_parser.at==len(old_parser.text)
    ledger={(r['session'],r['method'],r['id']):r for r in old_meta['行']}
    rows=[]
    for r in original['行']:
        h=r['source_paper_hold'];f=r['source_paper_entry_fill'];s=r['signal'];key=r['session'],r['method'],r['id']
        previous=ledger[key];assert h['kind']==previous['source_paper_hold']['kind'] and h['parent']==previous['source_paper_hold']['parent'] and h['source_id']==previous['source_paper_hold']['source_id']
        assert h['entry_id']==f['signal_id']==s['id']==r['id'] and h['hold_id']==f['hold_id']==r['id']+'-玉'
        assert h['internal_id']==f['execution_id']==r['id']+'-参照約定'
        assert h['entry_quote']==f['quote']==previous['source_paper_entry_fill']['stamp']
        assert f['time']==f['quote']['time'] and s['time']==r['time'] and s['source_index']==r['index']
        assert f['quote']['index']>r['index'] and f['quote']['source_line']>r['source_line']
        rows.append({'session':r['session'],'method':r['method'],'id':r['id'],'engine':ENGINE[r['method']],
            'source_id':h['source_id'],'parent':h['parent'],'kind':h['kind'],'internal_id':h['internal_id'],
            'birth':{k:r[k] for k in ('time','index','source_line')},'source_fill':f['quote'],
            'birth_key':tuple(r[k] for k in ('time','index','source_line')),'fill_key':tuple(f['quote'][k] for k in ('time','index','source_line'))})
    packed=ROOT/'inputs/00138_全成立入口の共用入力/manifest.json.gz';packed_bytes=packed.read_bytes();manifest=gzip.decompress(packed_bytes)
    assert sha(manifest)=='e7ba444fd66f9ca52e10e929eeb31d21076f97afa161de738dabca14a8ff8e35'
    parser=READER.SelectedJSON(manifest.decode('utf-8'));m=parser.read({'P0':[{'id':None,'origins':[{'family':None,'id':None,'session':None}]}]});parser.space();assert parser.at==len(parser.text)
    selected={(o['session'],o['family'].split('/',1)[1],o['id']) for r in m['P0'] for o in r['origins'] if o['family'].startswith('FAR/')}
    assert len(selected)==420
    initial=[r for r in rows if r['kind'] in ('initial','delayed_initial')]
    pool=[r for r in rows if (r['session'],r['method'],r['id']) in selected]
    assert len(initial)==456 and len(pool)==420 and all(r['kind']!='source_add' for r in pool)
    formal111=next((ROOT/'study').glob('00111_*'));index=json.loads((formal111/'再現資料/コード所在索引.json').read_bytes())
    archive=formal111/'再現資料/コードと実使用実行物.zip';code_refs=[]
    wanted=['internal/strategy/selected_source.go','internal/strategy/selected_ledger.go','internal/strategy/methods.go']
    with zipfile.ZipFile(archive) as z:
        for relative in wanted:
            item=next(x for x in index['entries'] if x['original_path'].replace('\\','/').endswith('/SessionTradeExecuter/'+relative))
            body=z.read(item['location']['entry']);assert sha(body)==item['sha256']
            current=ROOT.parent/'SessionTradeExecuter'/relative;assert sha(current.read_bytes())==sha(body)
            code_refs.append({'凍結参照':archive.relative_to(ROOT).as_posix(),'ZIP内path':item['location']['entry'],'sha256':sha(body),
                '現在コードと同体':True,'役割':relative})
    findings={name:describe(r) for name,r in [('全558',rows),('初期456',initial),('P0由来420',pool)]}
    assert all(not x['生source_idのcross_method一致'] and not x['internal_idのcross_method一致'] for x in findings.values())
    assert not findings['初期456']['内側entry反復群'] and not findings['初期456']['同エンジンepisode反復群']
    assert not findings['P0由来420']['内側entry反復群'] and not findings['P0由来420']['同エンジンepisode反復群']
    result={'成功':True,'監査':'Source三手法の内側entry/episodeのcross_method同一性','エンジン対応':ENGINE,
        '識別子の意味':{'source_id':'stepSelectedSourceが渡したShadowの元Signal.ID','internal_id':'SelectedLot.ID=外側Source fill.ExecutionID。Shadowのentry IDではない','parent':'Shadow Owner/Campaign由来のepisode名。session/engineを伴わず同一視しない'},
        '集合別':findings,'558行は既存種別台帳と全件結合':True,'全558のinternal_idは外側ExecutionIDと同体':True,
        '凍結コード参照':code_refs,'558識別JSON_SHA256':sha(source_bytes),'77MB入力SHA256':READER.EXPECTED,
        'manifest解凍SHA256':sha(manifest),'manifest保存SHA256':sha(packed_bytes),
        '価格/PnL/数量/公表本文の値化又は比較':False,'Raw/Native/CSV/追加2場読取':False,'138/139固定変更':False,
        '限界':['異なるエンジンの経済的/統計的な同一setupや相関を判定した監査ではない','内側通知の生の出生時計/保有終了はこの抽出に無く、同じ時間帯に似た機会があったかは未判定','確認できたID/episodeの重複を理由に既存752/81や138/139を変更しない']}
    target=OWN/'内側IDの監査.json';output=(json.dumps(result,ensure_ascii=False,indent=2)+'\n').replace('\n',os.linesep).encode('utf-8')
    if args.check:
        assert target.read_bytes()==output
    else:
        assert not target.exists();target.write_bytes(output)
    print(json.dumps({'成功':True,'出力SHA256':sha(target.read_bytes()),'集合別':{k:{n:v[n] for n in ('通知数','正規の内側entry一意数','正規の内側episode一意数')} for k,v in findings.items()},
        'parentだけのcross_method群':{k:len(v['parent文字列だけのcross_method一致']) for k,v in findings.items()}},ensure_ascii=False))


if __name__=='__main__':
    main()
