"""許可118入力を選択的に解析し、識別子/出生/Sourcefill時計だけを抽出する。"""
from pathlib import Path
import hashlib
import json
import re

ROOT=Path(__file__).resolve().parents[2]
OWN=Path(__file__).resolve().parent
INPUT=ROOT/'work/118入口比較/入力.json'
EXPECTED='574771f654937036b48c78eceadb46a4c5ff3c10265f60b0ec7879efb0d862c3'
STAMP={'time':None,'index':None,'source_line':None}
RULE={'scenes':[{'session':None,'signals':[{
    'id':None,'method':None,'time':None,'index':None,'source_line':None,
    'signal':{'id':None,'owner':None,'campaign':None,'source_index':None,'time':None,'action':None},
    'source_paper_hold':{**{k:None for k in ('hold_id','internal_id','entry_id','parent','source_id','kind')},'entry_quote':STAMP},
    'source_paper_entry_fill':{**{k:None for k in ('signal_id','execution_id','hold_id','time')},'quote':STAMP},
}]}]}
TOKEN=re.compile(r'"(?:[^"\\]|\\.)*"|[{}\[\]]')
SCALAR=re.compile(r'(?:true|false|null|-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?)')


class SelectedJSON:
    """指定経路以外の値を文字列/数値へ値化せずに読み飛ばすJSON読取器。"""

    def __init__(self, source: str):
        """
        機能: SHA確認済みのJSON文字列を保持する。
        引数: source(str)。
        返り値: None。
        """
        self.text=source;self.at=0;self.decoder=json.JSONDecoder()

    def space(self) -> None:
        """
        機能: 次のJSONトークンまで空白を進める。
        引数: self(SelectedJSON)。
        返り値: None。
        """
        while self.at<len(self.text) and self.text[self.at].isspace():self.at+=1

    def skip(self) -> None:
        """
        機能: 未許可の値を構造だけ走査し、値をPythonオブジェクトへ変換しない。
        引数: self(SelectedJSON)。
        返り値: None。価格/PnL/公表本文を射影しない。
        """
        self.space();first=self.text[self.at]
        if first in '{[':
            stack=[]
            for match in TOKEN.finditer(self.text,self.at):
                token=match.group()
                if token.startswith('"'):continue
                if token in '{[':stack.append(token)
                else:
                    assert stack.pop()==('{' if token=='}' else '[')
                    if not stack:self.at=match.end();return
            raise ValueError('JSON構造が閉じていない')
        match=TOKEN.match(self.text,self.at) if first=='"' else SCALAR.match(self.text,self.at)
        assert match is not None
        self.at=match.end()

    def read(self, rule: object) -> object:
        """
        機能: allowlist経路だけを再帰的に値化する。
        引数: rule(dict/list/None)は許可する構造。
        返り値: objectは許可した識別子と時計だけ。
        """
        self.space()
        if self.text.startswith('null',self.at):self.at+=4;return None
        if rule is None:
            value,self.at=self.decoder.raw_decode(self.text,self.at)
            assert value is None or type(value) in (str,int,float,bool)
            return value
        if isinstance(rule,list):
            assert self.text[self.at]=='[';self.at+=1;rows=[];self.space()
            while self.text[self.at]!=']':
                rows.append(self.read(rule[0]));self.space()
                if self.text[self.at]==',':self.at+=1;self.space()
                else:assert self.text[self.at]==']'
            self.at+=1;return rows
        assert self.text[self.at]=='{';self.at+=1;result={};self.space()
        while self.text[self.at]!='}':
            key,self.at=self.decoder.raw_decode(self.text,self.at);assert type(key) is str
            self.space();assert self.text[self.at]==':';self.at+=1
            if key in rule:
                assert key not in result;result[key]=self.read(rule[key])
            else:self.skip()
            self.space()
            if self.text[self.at]==',':self.at+=1;self.space()
            else:assert self.text[self.at]=='}'
        self.at+=1;return result


# ----------------------------------------
def artificial() -> None:
    """
    機能: 値非依存・入れ子・文字内括弧・null・選択重複拒否を人工確認する。
    引数: なし。
    返り値: None。自然入力は開かない。
    """
    base={'scenes':[{'session':'人工_Night','signals':[{'id':'A','method':'M','time':1,'index':2,'source_line':3,
        'source_paper_hold':None,'source_paper_entry_fill':None,'price':999,'pnl':-999,'evidence':'"{}[]'}],
        'publications':[{'id':'偽A','time':999999,'price':50000}]}]}
    for unknown in [0,999999,{'x':['"{}[]',{'深い':None}]}]:
        base['scenes'][0]['signals'][0]['price']=unknown
        reader=SelectedJSON(json.dumps(base,ensure_ascii=False));value=reader.read(RULE);reader.space()
        assert reader.at==len(reader.text)
        signal=value['scenes'][0]['signals'][0]
        assert signal=={'id':'A','method':'M','time':1,'index':2,'source_line':3,'source_paper_hold':None,'source_paper_entry_fill':None}
    try:SelectedJSON('{"scenes":[],"scenes":[]}').read(RULE)
    except AssertionError:pass
    else:raise AssertionError('選択key重複を拒否していない')


# ----------------------------------------
def main() -> None:
    """
    機能: 77MB入力をSHA検査後に選択解析し、558通知の識別/時計だけ保存する。
    引数: なし。
    返り値: None。価格/PnL/数量は値化・使用・出力せず、Raw/追加2場は開かない。
    """
    artificial();before=INPUT.stat();raw=INPUT.read_bytes();assert hashlib.sha256(raw).hexdigest()==EXPECTED
    parser=SelectedJSON(raw.decode('utf-8'));data=parser.read(RULE);parser.space();assert parser.at==len(parser.text)
    rows=[]
    for scene in data['scenes']:
        for signal in scene['signals']:
            hold=signal['source_paper_hold'];fill=signal['source_paper_entry_fill'];assert hold and fill
            rows.append({'session':scene['session'],**signal})
    assert len(rows)==558 and len({(r['session'],r['method'],r['id']) for r in rows})==558
    assert INPUT.stat().st_size==before.st_size and INPUT.stat().st_mtime_ns==before.st_mtime_ns
    out=OWN/'558通知の識別と時計.json';assert not out.exists()
    value={'成功':True,'入力SHA256':EXPECTED,'入力bytes':len(raw),'通知数':558,'許可経路':RULE,'行':rows,
        '未知経路は字句/構造だけskipし値化しない':True,'価格/PnL/数量/公表本文の値化又は使用':False,
        'Raw/Native/CSV/追加2場読取':False,'元入力stat前後同体':True}
    out.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'通知数':558,'出力bytes':out.stat().st_size,'SHA256':hashlib.sha256(out.read_bytes()).hexdigest()},ensure_ascii=False))


if __name__=='__main__':
    main()
