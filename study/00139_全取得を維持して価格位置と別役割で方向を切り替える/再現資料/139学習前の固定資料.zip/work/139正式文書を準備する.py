"""139の固定候補辞書と汎用表版6を自然学習前の正式文書へ保存する。"""
from pathlib import Path
import hashlib
import json
import posixpath
import re

ROOT = Path(__file__).resolve().parent.parent
DEST = ROOT / 'study/00139_全取得を維持して価格位置と別役割で方向を切り替える'
PLAN = ROOT / 'work/全成立poolの複合方向切替を計画する/計画案.md'
TABLE = ROOT / 'docs/議論/手法と時間スケールの汎用表_版6.md'


def sha(path: Path) -> str:
    """
    機能: 保存内容のSHA256を求める。
    引数: path(Path)は対象。
    返り値: strは16進指紋。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def link(match: re.Match) -> str:
    """
    機能: 汎用表から正式試行への相対リンクを同じ参照先へ変換する。
    引数: match(re.Match)はMarkdownリンク。
    返り値: strは正式試行を基準にしたリンク。
    """
    label, target = match.group(1), match.group(2)
    if '://' in target or target.startswith('#'):
        return match.group(0)
    resolved = posixpath.normpath(posixpath.join('docs/議論', target))
    relative = posixpath.relpath(resolved, DEST.relative_to(ROOT).as_posix())
    return '[' + label + '](' + relative + ')'


# ----------------------------------------
def main() -> None:
    """
    機能: 3文書と56手法504セルを未作成先へ保存する。
    引数: なし。モデル選択や金融計算は行わない。
    返り値: None。リンク不整合と件数不一致は停止する。
    """
    assert sha(PLAN) == 'e41b9e777b570a652aa6aab115af6a8853724238fb5d285444e5086e9cf21bfb'
    DEST.mkdir(exist_ok=False)
    adopted = PLAN.read_text(encoding='utf-8').split('## 変更しない母集団', 1)[1]
    adopted = '## 変更しない母集団' + adopted
    adopted = adopted.replace('本案は計画であり、規則選定も139条件の確定もまだ行っていない。',
        '本条件を139へ採用した。規則選定・適用・金融集計はまだ実行していない。')
    protocol = '# 139：価格位置と別役割による方向切替の固定条件\n\n2026-11-12。138の752取得を不変更で残し、複数手法の条件で方向だけを切り替える。'
    protocol += '原案28規則を取引別ラベルの学習前に採用する。13述語のうちRVOLは共用なので入力は12特徴。\n\n' + adopted
    protocol += '\n\n## 固定入力と実行順\n\n出生特徴1812f9d2479dcd383f257f8323cc83e714a8b42d28a0caa5b987fe1114dc5d5d、前48ラベル5ac6136ee3cede031b3a7569a4025da13b504b56365fef15983698ec664e8042、後25ラベルe88b3a45b09426ed562a208519dc7a75079c90053a903b725ab91ca0d6959498。入力分離は752件を前433・後319へ分け、旧81を保持した。\n\nコード・人工・本条件をF1固定→前48だけで学習→モデルSHA固定→全752へ同じ規則適用→後25/前48/全体を分けて評価する。後25は既使用期の参照評価であり、未知期検証ではない。結果で規則辞書や40例/10場を緩和しない。実BBO・H60±125、費用77円/C5追加1000円、未知非0、独立mini1枚、反転注文適格性未再構築は138を継承する。\n'
    (DEST / '条件.md').write_text(protocol, encoding='utf-8', newline='\n')
    (DEST / 'README.md').write_text('# 00139：全取得を維持して複合テクニカルで方向を切り替える\n\n2026-11-12、準備中・自然学習未実行。\n\n[138](../00138_全成立の独立入口を統合して頻度と先着を診断する/README.md)は752回/73場・1.043回/時となった一方、実BBO同幅H60±125先着は52.33%、全反転は37.40%だった。価格位置/拒否と別の役割が一致する群だけ方向を切り替える仮説を検証する。\n\n[固定条件](条件.md) / [版6の設定表](設定と結果.md)。候補28から前48のみで一規則を選び、後25へ同じ規則を適用する。旧81を保護し、追加671も全件保持する。各場の回数は均等化せず、待機や件数削減で先着率を作らない。現時点でモデル・新損益・70%達成結果はない。\n', encoding='utf-8', newline='\n')
    configured = {
        ('I01', '5分'): 'R01/A1：価格−EMA21をATR5比>=1（候補）',
        ('I01', '15分'): 'R01/B2：sEMA21Δ/ATR15<=0（候補）',
        ('I01', '30分'): 'R01/B1：sGap/ATR30<=0（候補）',
        ('I03', '5分'): 'R01/B3：sΔHist/ATR5<=0（候補）',
        ('I03', '15分'): 'R01/B4：sHist/ATR15<=0（候補）',
        ('I04', '5分'): 'R01/B5：sΔRSI<=0（候補）',
        ('I05', '15分'): 'R01/A2：s価格位置>=2σ（候補）',
        ('I08', '15分'): 'R01/B6：ADX<=20、B7：ΔADX<=0（候補）',
        ('I09', '5分'): 'R01/A1・B3正規化、B8：TR/前ATR>=2（候補）',
        ('I09', '15分'): 'R01/B2・B4の同幅ATR尺度（候補）',
        ('I09', '30分'): 'R01/B1の同幅ATR尺度（候補）',
        ('P01', '5分'): 'R01/A3：native側ヒゲ比>=.25（候補）',
        ('V01', '5分'): 'R01/B9：RVOL<.5、B10：RVOL>=2（候補）',
        ('E01', '原板・逐次'): 'E01：保存実正逆、取得後H60±125。再取得なし',
    }
    scales = ('原板・逐次', '1分', '3分', '5分', '15分', '30分', '60分', 'セッション足', '日足')
    lines = ['# 00139：設定と結果（汎用表・版6）', '',
        '2026-11-12。56手法×9尺度＝504セル。入口の生成条件は138の固定対照として継承し、下表は139で新たに候補選定する出生特徴と評価を記す。R01は異なる役割のAND一組、28候補から最大一組を前48だけで選ぶ。候補選定に使用することと、選択後に全取引へ適用する条件を区別する。単独指標の効果は未検証。', '',
        '| ID | 手法 | ' + ' | '.join(scales) + ' |', '| ' + ' | '.join(['---'] * 11) + ' |']
    ids = []
    for line in TABLE.read_text(encoding='utf-8').splitlines():
        cells = [c.strip() for c in line.split('|')[1:-1]]
        if len(cells) != 11 or re.fullmatch('[A-Z][0-9]{2}', cells[0]) is None:
            continue
        identity = cells[0]
        ids.append(identity)
        label = re.sub(r'\[([^]]+)\]\(([^)]+)\)', link, cells[1])
        lines.append('| ' + ' | '.join([identity, label] + [configured.get((identity, scale), '未使用・未検証') for scale in scales]) + ' |')
    assert len(ids) == len(set(ids)) == 56
    lines += ['', '## 結果', '', '自然学習・適用・金融評価は未実行。選択モデルと各分母は実行後に追記する。', '']
    (DEST / '設定と結果.md').write_text('\n'.join(lines), encoding='utf-8', newline='\n')
    for path in DEST.glob('*.md'):
        for _, target in re.findall(r'\[([^]]+)\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
            if '://' not in target:
                assert (path.parent / target.split('#')[0]).exists(), (path, target)
    proof = {'成功': True, '試行': 139, '学習実行': False, '規則候補': 28, '述語': 13, '入力特徴': 12,
        '手法数': 56, '尺度数': 9, 'セル数': 504,
        '正式MD': {p.name: sha(p) for p in DEST.glob('*.md')}, '元計画SHA256': sha(PLAN),
        '汎用表SHA256': sha(TABLE), 'コードSHA256': sha(Path(__file__))}
    out = ROOT / 'work/139正式文書の準備確認.json'
    with out.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(proof, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps(proof, ensure_ascii=False))


if __name__ == '__main__':
    main()
