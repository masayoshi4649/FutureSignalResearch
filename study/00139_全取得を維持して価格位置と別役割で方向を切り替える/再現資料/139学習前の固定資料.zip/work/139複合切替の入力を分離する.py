"""139の出生特徴と前48場・後25場の実正逆ラベルを物理的に分離する。"""
from pathlib import Path
import hashlib
import importlib.util
import json
import math

ROOT = Path(__file__).resolve().parent.parent
OWN = ROOT / 'work/139複合方向切替/入力'
NAMES = ('m5_price_ema21_atr_to_side', 'bb15_position_sigma_to_side', 'm5_forward_wick_ratio',
    'm30_gap_atr_to_side', 'm15_ema21_delta_atr_to_side', 'm5_hist_delta_atr_to_side',
    'm15_hist_atr_to_side', 'm5_rsi_delta_to_side', 'm15_adx', 'm15_adx_delta',
    'm5_tr_previous_atr_ratio', 'rvol5')
SOURCES = {
    ROOT / 'work/全成立poolの非金融manifest/manifest.json': 'e7ba444fd66f9ca52e10e929eeb31d21076f97afa161de738dabca14a8ff8e35',
    ROOT / 'work/138全成立入口の評価/固定入力_版2/特徴照会.json': '81442c3ebaa3065213d0844417bb0462cfa3e5d0a05c4f44edfb3fb14191e75c',
    ROOT / 'work/138全成立入口の評価/全出生の当時特徴.json': 'c2b9b8efeb65ba22b2dac3147fdefa3b513cb5cc61cd69249864065f2fcca6e4',
    ROOT / 'work/138全成立入口の評価/固定取得の正逆観測.json': 'd272fc6f6768342ff67e1a9ec58b0b7307a0a5b07cc215ba5ff7bcb50865b742',
    ROOT / 'work/124入口の原因分析/集計する.py': '8479ca348231ffd77a637360797750833c9e6617c7fc4a6502e015c7a1d9f04a',
}


def sha(path: Path) -> str:
    """
    機能: ファイルの全体指紋を計算する。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def save(name: str, value: dict) -> str:
    """
    機能: 入力JSONを未作成先へ一度保存する。
    引数: name(str)はファイル名、value(dict)は内容。
    返り値: strは保存内容の指紋。
    """
    path = OWN / name
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')
    return sha(path)


# ----------------------------------------
def main() -> None:
    """
    機能: 752入口を不変更で保持し、特徴と評価用ラベルを別ファイルへ射影する。
    引数: なし。金融は確定138の保存結果だけを読む。
    返り値: None。学習・方向選択・Raw再読はしない。
    """
    for path, expected in SOURCES.items():
        assert sha(path) == expected, path
    paths = list(SOURCES)
    manifest, queries, features, observation = (json.loads(p.read_bytes()) for p in paths[:4])
    spec = importlib.util.spec_from_file_location('139入力射影の固定算術', paths[4])
    arithmetic = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(arithmetic)
    sessions = [s['session'] for s in observation['scenes']]
    assert len(sessions) == len(set(sessions)) == 73
    front = set(sessions[:48])
    feature_map = {r['query']['id']: r for r in features['rows']}
    assert len(feature_map) == 769 and features['financial_labels_used'] is False
    relations = {}
    for relation in queries['relations']:
        if relation['model'] == 'P0':
            relations.setdefault(relation['entry_id'], []).append(relation)
    cases = {c['id']: (s['session'], c) for s in observation['scenes'] for c in s['cases'] if c['id'].startswith('P0/')}
    assert len(cases) == len(relations) == len(manifest['P0']) == 752
    rows, train, validation = [], [], []
    for index, candidate in enumerate(manifest['P0']):
        identity = 'P0/' + candidate['id']
        session, case = cases[identity]
        assert session == candidate['session'] and case['original_side'] == candidate['side']
        origins = []
        for relation in sorted(relations[identity], key=lambda r: r['origin_index']):
            assert relation['manifest_index'] == index and relation['selected_side'] == relation['side'] == candidate['side']
            feature = feature_map[relation['query_id']]
            origin = candidate['origins'][relation['origin_index']]
            query = feature['query']
            assert query['side'] == candidate['side'] and query['session'] == session
            assert all(query['birthQuote'][k] == origin['birthQuote'][k] for k in ('time', 'index', 'source_line', 'last'))
            values = {name: feature['values'][name] for name in NAMES}
            for value in values.values():
                assert type(value['known']) is bool
                assert (type(value['value']) in (int, float) and math.isfinite(value['value'])) if value['known'] else value['value'] is None
            origins.append({'query_id': query['id'], 'values': values})
        assert len(origins) == len(candidate['origins'])
        rows.append({'id': identity, 'session': session, 'baseline': candidate['baseline'],
            'native_side': candidate['side'], 'origins': origins})
        label = {'id': identity, 'session': session}
        for key in ('original', 'reverse'):
            c = case[key]
            o = arithmetic.observation(c, 3600)
            touch = arithmetic.touch(o, 125)
            ifd = arithmetic.ifd(c, o, 125, 'BBO')
            label[key] = {'complete': o['status'] == 'complete', 'direction': touch['direction'],
                'ifd_known': ifd['known'], 'net5': ifd['net5']}
        (train if session in front else validation).append(label)
    assert len(rows) == len(train) + len(validation) == 752
    assert sum(r['baseline'] for r in rows) == 81
    OWN.mkdir(parents=True, exist_ok=True)
    feature_sha = save('出生特徴.json', {'success': True, 'trial': 139, 'sessions': sessions,
        'rows': rows, 'sources': {str(p): h for p, h in SOURCES.items() if p != paths[3]}, 'financial_labels_used': False})
    train_sha = save('前48場のラベル.json', {'success': True, 'trial': 139, 'split': 'train',
        'sessions': sessions[:48], 'features_sha256': feature_sha, 'rows': train})
    validation_sha = save('後25場のラベル.json', {'success': True, 'trial': 139, 'split': 'validation',
        'sessions': sessions[48:], 'features_sha256': feature_sha, 'rows': validation})
    for path, expected in SOURCES.items():
        assert sha(path) == expected, path
    proof_sha = save('分離の確認.json', {'成功': True, '試行': 139, '学習実行': False,
        '方向選択': False, '出生特徴SHA256': feature_sha, '前48SHA256': train_sha, '後25SHA256': validation_sha,
        '特徴数': len(NAMES), '全取得': 752, '旧固定': 81, '追加': 671,
        '前48件数': len(train), '後25件数': len(validation), '入力源前後同体': True,
        'コードSHA256': sha(Path(__file__)), '入力源': {str(p): h for p, h in SOURCES.items()}})
    print(json.dumps({'成功': True, '特徴数': len(NAMES), '全取得': 752, '前48件数': len(train),
        '後25件数': len(validation), '特徴SHA256': feature_sha, '前48SHA256': train_sha,
        '後25SHA256': validation_sha, '確認SHA256': proof_sha}, ensure_ascii=False))


if __name__ == '__main__':
    main()
