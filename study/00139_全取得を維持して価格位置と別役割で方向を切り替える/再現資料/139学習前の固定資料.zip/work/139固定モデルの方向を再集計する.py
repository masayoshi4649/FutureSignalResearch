"""139のモデル固定後だけ、138の保存実正逆観測を選び直して集計する。"""
from pathlib import Path
import argparse
from functools import partial
import hashlib
import importlib.util
import json

ROOT = Path(__file__).resolve().parent.parent
BASE = ROOT / 'work/138全成立入口と頻度の集計/集計する.py'
SOURCES = {
    BASE: 'e8671638600dc4b23ef9256ba5be535f20c6f8e1d5097457a56fbea9fb30c1f1',
    ROOT / 'work/138全成立入口の評価/固定入力_版2/固定取得入力.json': '0c83e525dec3079ce188d942069c0d137c94f39009339752ec8227ec9ecb4ce7',
    ROOT / 'work/138全成立入口の評価/固定入力_版2/入口参照.json': '75e4993571bdef17839aad3324acc6ee9ce09b3cb1f4ecad70637a1e01ccefd0',
    ROOT / 'work/138全成立入口の評価/固定取得の正逆観測.json': 'd272fc6f6768342ff67e1a9ec58b0b7307a0a5b07cc215ba5ff7bcb50865b742',
    ROOT / 'work/139複合方向切替/入力/出生特徴.json': '1812f9d2479dcd383f257f8323cc83e714a8b42d28a0caa5b987fe1114dc5d5d',
}


def sha(path: Path) -> str:
    """
    機能: 全バイトの指紋を求める。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def load(path: Path, name: str) -> object:
    """
    機能: 元コードを変更せず私有モジュールへ読み込む。
    引数: path(Path)、name(str)は位置と私有名。
    返り値: objectはモジュール。
    """
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# ----------------------------------------
def stream(record: dict, policy: str, axis: str, choices: dict) -> dict:
    """
    機能: T0の固定選択方向又はP0/C0のnative方向の実観測を選ぶ。
    引数: record(dict)、policy/axis(str)、choices(dict)は保存行、政策、軸、固定選択。
    返り値: dictは保存された正逆観測。反転を1−pで推定しない。
    """
    assert policy in ('T0', 'P0', 'C0') and axis in ('BBO', 'Last')
    assert record['model'] == ('C0' if policy == 'C0' else 'P0')
    native = record['case']['original_side']
    selected = choices[record['case']['id']]['selected_side'] if policy == 'T0' else native
    return record['case'][('chart_' if axis == 'Last' else '') + ('original' if selected == native else 'reverse')]


# ----------------------------------------
def main() -> None:
    """
    機能: F1と学習後F2の指紋を先に確認し全180条件を評価する。
    引数: CLIのF1/F2/model/choicesと各SHA、output-dir。
    返り値: None。モデルを再学習せず旧観測と原文を変更しない。
    """
    parser = argparse.ArgumentParser(description='139の固定方向モデルの保存観測集計')
    for name in ('f1', 'f2', 'model', 'choices'):
        parser.add_argument('--' + name, type=Path, required=True)
        parser.add_argument('--' + name + '-sha256', required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    paths = {n: getattr(args, n).resolve() for n in ('f1', 'f2', 'model', 'choices')}
    expected = {n: getattr(args, n + '_sha256') for n in paths}
    assert all(sha(paths[n]) == expected[n] for n in paths)
    f1, f2 = (json.loads(paths[n].read_bytes()) for n in ('f1', 'f2'))
    helper = load(ROOT / 'work/133金融前を固定して実行する.py', '139の固定照合')
    helper.verify(f1)
    helper.verify(f2)
    assert f2['試行'] == f1['試行'] == 139
    assert f2['F1_SHA256'] == expected['f1'] and f2['モデルSHA256'] == expected['model']
    assert f1['ファイル'][str(Path(__file__).resolve())] == sha(Path(__file__))
    for path, fingerprint in SOURCES.items():
        assert sha(path) == fingerprint and f1['ファイル'][str(path)] == fingerprint, path
    module = load(BASE, '139の固定138算術')
    for path, fingerprint in module.SOURCES.items():
        assert sha(path) == fingerprint and f1['ファイル'][str(path)] == fingerprint, path
    selected = json.loads(paths['choices'].read_bytes())
    assert selected['success'] and selected['trial'] == 139
    assert selected['model_sha256'] == expected['model']
    assert selected['features_sha256'] == SOURCES[ROOT / 'work/139複合方向切替/入力/出生特徴.json']
    choices = {r['id']: r for r in selected['rows']}
    assert len(choices) == len(selected['rows']) == 752
    features = json.loads((ROOT / 'work/139複合方向切替/入力/出生特徴.json').read_bytes())
    for row in features['rows']:
        c = choices[row['id']]
        assert all(c[k] == row[k] for k in ('session', 'native_side', 'baseline'))
        assert c['selected_side'] in (-1, 1)
        if row['baseline']:
            assert c['selected_side'] == row['native_side']
    module.POLICIES = ('T0', 'P0', 'C0')
    module.MODEL = {'T0': 'P0', 'P0': 'P0', 'C0': 'C0'}
    module.selected = partial(stream, choices=choices)
    module.DETAIL_HEADERS = module.DETAIL_HEADERS[:18] + [p + s for p in module.POLICIES for s in ('方向', '125全H', '125先着', 'IFD既知', '清算', '125C5代用円')]
    module.SCENE_HEADERS = module.SCENE_HEADERS[:13] + [p + s for p in module.POLICIES for s in ('反転数', '125順', '125逆', '125未到達', '全H不足', 'IFD既知', 'IFD未知', 'C5利益円', 'C5損失絶対円', 'C5既知差引円', 'C5既知累計円_口座収支ではない', '累計IFD未知')]
    fixed = json.loads((ROOT / 'work/138全成立入口の評価/固定入力_版2/固定取得入力.json').read_bytes())
    meta = json.loads((ROOT / 'work/138全成立入口の評価/固定入力_版2/入口参照.json').read_bytes())
    result = json.loads((ROOT / 'work/138全成立入口の評価/固定取得の正逆観測.json').read_bytes())
    manifest = json.loads(module.MANIFEST.read_bytes())
    rows, sessions, phase = module.prepare(result, fixed, meta, manifest)
    arithmetic = module.load_arithmetic()
    values, participation, frequency, _ = module.calculate(rows, sessions, fixed['scenes'], arithmetic)
    baseline = module.baseline_check(rows, values, json.loads(module.OLD137.read_bytes()), json.loads(module.OLD_PAIRS.read_bytes()))
    tables = module.tables(rows, sessions, values, participation, frequency, arithmetic)
    for table in tables:
        for row in table['rows']:
            assert row[0] == 138
            row[0] = 139
    s = values['all']['T0']['BBO']['3600']['125']
    main_result = {'政策': 'T0', '順': s['forward'], '逆': s['adverse'], '未到達': s['neither'], '観測不足': s['censored'],
        '到達済み率': s['resolved_rate'], '70%以上': s['target70'], '取得数': 752,
        '全73場最低1': participation['all']['P0']['全場最低1取得'],
        '全時間平均件数毎時': frequency['all']['P0']['全時間平均件数毎時']}
    output = {'成功': True, '試行': 139, '主評価': main_result, '集計': values, '参加': participation,
        '頻度': frequency, '全4streamのphase検査': phase, '旧C0同体': baseline,
        'モデルSHA256': expected['model'], '方向SHA256': expected['choices'], 'F1_SHA256': expected['f1'],
        'F2_SHA256': expected['f2'], '全期間既使用': True, '未知期検証': False,
        '新Raw走査': False, '反転注文適格性再構築': False, '口座損益': False}
    helper.verify(f1)
    helper.verify(f2)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    helper.save(args.output_dir / '集計.json', output)
    helper.save(args.output_dir / 'CSV用の表.json', {'成功': True, '試行': 139, '主政策': 'T0', 'tables': tables})
    print(json.dumps({'成功': True, '主評価': main_result}, ensure_ascii=False))


if __name__ == '__main__':
    main()
