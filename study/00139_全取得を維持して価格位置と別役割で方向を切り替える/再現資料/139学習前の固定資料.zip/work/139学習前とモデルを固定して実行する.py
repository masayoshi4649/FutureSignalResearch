"""139の学習前F1と学習後F2を分けて保存し、評価前にモデルを固定する。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
OWN = ROOT / 'work/139複合方向切替'
FORMAL = ROOT / 'study/00139_全取得を維持して価格位置と別役割で方向を切り替える'
AGGREGATOR = ROOT / 'work/139固定モデルの方向を再集計する.py'
FEATURES = OWN / '入力/出生特徴.json'
TRAIN = OWN / '入力/前48場のラベル.json'
VALIDATION = OWN / '入力/後25場のラベル.json'
FEATURES_SHA = '1812f9d2479dcd383f257f8323cc83e714a8b42d28a0caa5b987fe1114dc5d5d'
TRAIN_SHA = '5ac6136ee3cede031b3a7569a4025da13b504b56365fef15983698ec664e8042'
VALIDATION_SHA = 'e88b3a45b09426ed562a208519dc7a75079c90053a903b725ab91ca0d6959498'


def sha(path: Path) -> str:
    """
    機能: 全バイトの指紋を計算する。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def load(path: Path, name: str) -> object:
    """
    機能: mainを呼ばず宣言を読み込む。
    引数: path(Path)、name(str)は位置と私有名。
    返り値: objectはモジュール。
    """
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# ----------------------------------------
def main() -> None:
    """
    機能: 学習前固定、学習とモデル固定、適用、全観測集計を順に実行する。
    引数: CLI --mode(str)は固定、学習、適用、集計。
    返り値: None。validationラベルは学習CLIへ渡さない。
    """
    parser = argparse.ArgumentParser(description='139の学習前とモデル固定後を分離する')
    parser.add_argument('--mode', choices=('固定', '学習', '適用', '集計'), required=True)
    args = parser.parse_args()
    helper = load(ROOT / 'work/133金融前を固定して実行する.py', '139の保存と固定検査')
    f1 = OWN / 'F1学習前.json'
    f2 = OWN / 'F2モデル固定.json'
    model = OWN / '選択モデル.json'
    report = OWN / '前48の選定報告.json'
    choices = OWN / '全752の方向.json'
    if args.mode == '固定':
        assert sha(FEATURES) == FEATURES_SHA and sha(TRAIN) == TRAIN_SHA and sha(VALIDATION) == VALIDATION_SHA
        assert (OWN / '準備の確認.json').is_file()
        assert all((FORMAL / n).is_file() for n in ('README.md', '条件.md', '設定と結果.md'))
        aggregator = load(AGGREGATOR, '139固定前の集計依存宣言')
        base = load(ROOT / 'work/138全成立入口と頻度の集計/集計する.py', '139固定前の138依存宣言')
        dependencies = {**aggregator.SOURCES, **base.SOURCES}
        for path, expected in dependencies.items():
            assert sha(path) == expected, path
        files = set(dependencies) | {AGGREGATOR, Path(__file__).resolve(), ROOT / 'work/133金融前を固定して実行する.py',
            ROOT / 'work/139複合切替の入力を分離する.py', ROOT / 'work/139正式文書を準備する.py',
            ROOT / 'work/139正式文書の準備確認.json', ROOT / 'work/全成立poolの複合方向切替を計画する/計画案.md'}
        for folder in (OWN, FORMAL):
            files.update(p for p in folder.rglob('*') if p.is_file() and p.suffix in ('.py', '.md', '.json'))
        helper.save(f1, {'成功': True, '試行': 139, '段階': '学習前F1', 'UTC': datetime.now(timezone.utc).isoformat(),
            '主': 'T0/全752/旧81保護/実BBO/H60±125', '候補規則': 28, '学習': '前48のみ433取得',
            '評価': '後25の319取得。既使用の参照期', '追加2場未読': True,
            'ファイル': {str(p): sha(p) for p in sorted(files)}})
        print(json.dumps({'F1_SHA256': sha(f1), '固定源数': len(files)}, ensure_ascii=False))
        return
    fixed = json.loads(f1.read_bytes())
    helper.verify(fixed)
    if args.mode == '学習':
        assert not any(p.exists() for p in (model, report, f2))
        command = [sys.executable, '-X', 'utf8', str(OWN / '学習する.py'), '--features', str(FEATURES),
            '--features-sha256', FEATURES_SHA, '--train', str(TRAIN), '--train-sha256', TRAIN_SHA,
            '--output-model', str(model), '--output-report', str(report), '--execute-after-f1']
        subprocess.run(command, cwd=ROOT, check=True)
        helper.verify(fixed)
        helper.save(f2, {'成功': True, '試行': 139, '段階': '評価前モデル固定F2',
            'UTC': datetime.now(timezone.utc).isoformat(), 'F1_SHA256': sha(f1), 'モデルSHA256': sha(model),
            '選定報告SHA256': sha(report), 'validationラベルを学習器へ渡した': False,
            '実行列': command, 'ファイル': {str(p): sha(p) for p in (f1, model, report)}})
        print(json.dumps({'F2_SHA256': sha(f2), 'モデルSHA256': sha(model)}, ensure_ascii=False))
        return
    frozen_model = json.loads(f2.read_bytes())
    helper.verify(frozen_model)
    assert frozen_model['F1_SHA256'] == sha(f1) and frozen_model['モデルSHA256'] == sha(model)
    if args.mode == '適用':
        assert not choices.exists()
        command = [sys.executable, '-X', 'utf8', str(OWN / '適用する.py'), '--features', str(FEATURES),
            '--features-sha256', FEATURES_SHA, '--model', str(model), '--model-sha256', sha(model),
            '--output', str(choices), '--execute-after-model-freeze']
        subprocess.run(command, cwd=ROOT, check=True)
        helper.verify(fixed)
        helper.verify(frozen_model)
        return
    command = [sys.executable, '-X', 'utf8', str(AGGREGATOR)]
    for name, path in (('f1', f1), ('f2', f2), ('model', model), ('choices', choices)):
        command += ['--' + name, str(path), '--' + name + '-sha256', sha(path)]
    destination = OWN / '金融評価'
    command += ['--output-dir', str(destination)]
    subprocess.run(command, cwd=ROOT, check=True)
    helper.verify(fixed)
    helper.verify(frozen_model)
    helper.save(OWN / '金融評価の完了.json', {'成功': True, '試行': 139, 'F1_SHA256': sha(f1),
        'F2_SHA256': sha(f2), 'モデルSHA256': sha(model), '方向SHA256': sha(choices),
        '集計SHA256': sha(destination / '集計.json'), 'CSV用の表SHA256': sha(destination / 'CSV用の表.json'),
        '全固定源前後同体': True, '実行列': command})


if __name__ == '__main__':
    main()
