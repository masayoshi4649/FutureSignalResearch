"""139の規則選定/未知/保護/後25非使用を人工だけで確認する。"""
import copy
import unittest
from unittest.mock import patch
import learner as M
import importlib.util
import io
import json
import tempfile
from contextlib import redirect_stderr
from pathlib import Path


def fixture() -> tuple[dict,dict,dict,list[str]]:
    """
    機能: 全752/73場/固定81と独立した前48・後25ラベルを人工生成する。
    引数: なし。
    返り値: tupleは特徴・学習・評価・40標的ID。
    """
    sessions=[f'人工{i:03d}' for i in range(73)]
    f={'success':True,'trial':139,'sessions':sessions,'rows':[],'sources':{}}
    t={'success':True,'trial':139,'split':'train','sessions':sessions[:48],'features_sha256':'人工','rows':[]}
    v={'success':True,'trial':139,'split':'validation','sessions':sessions[48:],'features_sha256':'人工','rows':[]};targets=[]
    base={'m5_price_ema21_atr_to_side':0,'bb15_position_sigma_to_side':0,'m5_forward_wick_ratio':0,
        'm30_gap_atr_to_side':1,'m15_ema21_delta_atr_to_side':1,'m5_hist_delta_atr_to_side':1,'m15_hist_atr_to_side':1,
        'm5_rsi_delta_to_side':1,'m15_adx':30,'m15_adx_delta':1,'m5_tr_previous_atr_ratio':1,'rvol5':1}
    for i,sid in enumerate(sessions):
        for j in range(11 if i<22 else 10):
            identity=f'P0/{i}/{j}';values={k:{'known':True,'value':x} for k,x in base.items()};target=10<=i<20 and j<4
            if target:values['m5_price_ema21_atr_to_side']['value']=1;values['m5_hist_delta_atr_to_side']['value']=0;targets.append(identity)
            row={'id':identity,'session':sid,'baseline':len(f['rows'])<81,'native_side':1 if j%2==0 else -1,
                'origins':[{'query_id':'q/'+identity,'values':values}]};f['rows'].append(row)
            o={'id':identity,'session':sid,'original':{'complete':True,'direction':-1 if target else 1,'ifd_known':True,'net5':-12577 if target else 11423},
                'reverse':{'complete':True,'direction':1 if target else -1,'ifd_known':True,'net5':11423 if target else -12577}}
            (t if i<48 else v)['rows'].append(o)
    return f,t,v,targets


class Tests(unittest.TestCase):
    """固定28候補を増やさず選定/適用/評価を検査する。"""
    def test_28_rules_and_boundaries(self) -> None:
        """
        機能: 12特徴/28候補・MA二重計上除外・境界0を確認する。
        引数: self(Tests)は検査状態。
        返り値: None。
        """
        self.assertEqual(len(M.FEATURES),12);self.assertEqual(len(M.RULES),28)
        self.assertNotIn('A1_B1',[r['id'] for r in M.RULES]);self.assertNotIn('A1_B2',[r['id'] for r in M.RULES])
        f,t,_,_=fixture();model,report=M.learn(f,t)
        self.assertEqual(model['selected_rule']['id'],'A1_B3');self.assertEqual(report['winner']['complete_pairs'],40)
        self.assertEqual(report['winner']['support_sessions'],10);self.assertEqual(report['winner']['utility_gain'],80)
        self.assertEqual(report['winner']['score'],77);self.assertEqual(report['winner']['gain_without_best_session'],72)

    def test_keep_all_and_protect_mirror(self) -> None:
        """
        機能: 全752保有・81固定とnative符号鏡像を検査する。
        引数: self(Tests)は検査状態。
        返り値: None。
        """
        f,t,_,_=fixture();saved=copy.deepcopy((f,t));m,_=M.learn(f,t);out=M.apply(f,m)
        self.assertEqual(out['counts'],{'keep':712,'flip':40});self.assertEqual(len(out['rows']),752)
        self.assertTrue(all(r['action']=='keep' for r in out['rows'] if r['baseline']))
        mirror=copy.deepcopy(f)
        for r in mirror['rows']:r['native_side']*=-1
        b=M.apply(mirror,m)
        self.assertTrue(all(x['selected_side']==-y['selected_side'] and x['action']==y['action'] for x,y in zip(out['rows'],b['rows'])))
        self.assertEqual((f,t),saved)

    def test_unknown_and_all_origins(self) -> None:
        """
        機能: 未知0を使わず、全origins成立を必須にすることを検査する。
        引数: self(Tests)は検査状態。
        返り値: None。
        """
        f,t,_,ids=fixture();m,_=M.learn(f,t);r=next(r for r in f['rows'] if r['id']==ids[0]);r['origins'].append(copy.deepcopy(r['origins'][0]))
        r['origins'][1]['values']['m5_hist_delta_atr_to_side']={'known':False,'value':0}
        out=M.apply(f,m);self.assertEqual(next(x for x in out['rows'] if x['id']==ids[0])['action'],'keep')
        r['origins'][1]['values']['m5_hist_delta_atr_to_side']={'known':True,'value':.00001}
        self.assertEqual(next(x for x in M.apply(f,m)['rows'] if x['id']==ids[0])['action'],'keep')

    def test_minimum_cash_and_single_session_guard(self) -> None:
        """
        機能: 39例・費用差非正・単一有利場依存を不採用とする。
        引数: self(Tests)は検査状態。
        返り値: None。
        """
        f,t,_,ids=fixture();next(r for r in f['rows'] if r['id']==ids[0])['origins'][0]['values']['m5_price_ema21_atr_to_side']['value']=0
        self.assertIsNone(M.learn(f,t)[0]['selected_rule'])
        f,t,_,ids=fixture()
        for r in t['rows']:
            if r['id'] in ids:r['reverse']['net5']=r['original']['net5']
        self.assertIsNone(M.learn(f,t)[0]['selected_rule'])
        f,t,_,ids=fixture()
        for r in t['rows']:
            if r['id'] in ids and r['session']!='人工010':r['original']['direction']=r['reverse']['direction']=0
        model,report=M.learn(f,t);self.assertIsNone(model['selected_rule'])
        a=next(r for r in report['candidates'] if r['rule_id']=='A1_B3');self.assertFalse(a['gates']['最良1場除外gain正'])

    def test_heldout_values_not_used_and_no_label_argument(self) -> None:
        """
        機能: 後25特徴値を変えても学習不変、後25ラベルは受理しないことを検査する。
        引数: self(Tests)は検査状態。
        返り値: None。
        """
        f,t,v,_=fixture();a=M.learn(f,t);changed=copy.deepcopy(f)
        for r in changed['rows']:
            if r['session'] in v['sessions']:
                for o in r['origins']:
                    for x in o['values'].values():x['known']=True;x['value']=999999
        self.assertEqual(a,M.learn(changed,t))
        with self.assertRaises(AssertionError):M.learn(f,v)
        choices=M.apply(f,a[0])
        with patch.object(M,'learn',side_effect=RuntimeError('評価で学習禁止')):self.assertTrue(M.evaluate(choices,v)['success'])

    def test_known_touch_after_censor_and_unknown(self) -> None:
        """
        機能: 評価でH不足と既知IFDを分け、未知を0にしないことを確認する。
        引数: self(Tests)は検査状態。
        返り値: None。
        """
        f,t,v,_=fixture();m,_=M.learn(f,t);c=M.apply(f,m)
        for axis in ('original','reverse'):v['rows'][0][axis]['complete']=False;v['rows'][0][axis]['ifd_known']=False;v['rows'][0][axis]['net5']=None
        for axis in ('original','reverse'):v['rows'][1][axis]['complete']=False
        e=M.evaluate(c,v)['stats']['selected'];self.assertEqual(e['censored'],2);self.assertEqual(e['ifd_unknown'],1)

    def test_training_cli_only_opens_two_artificial_inputs(self) -> None:
        """
        機能: 学習CLIが特徴/前48だけを開き、別評価引数を拒否することを検査する。
        引数: self(Tests)は検査状態。
        返り値: None。自然ファイルは読まない。
        """
        here=Path(__file__).parent;spec=importlib.util.spec_from_file_location('人工学習CLI',here/'学習する.py');cli=importlib.util.module_from_spec(spec);spec.loader.exec_module(cli)
        f,t,_,_=fixture()
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);fp=root/'特徴.json';tp=root/'前48.json'
            fp.write_text(json.dumps(f),encoding='utf-8');fh=cli.io139.sha(fp);t['features_sha256']=fh
            tp.write_text(json.dumps(t),encoding='utf-8');th=cli.io139.sha(tp)
            args=['学習する.py','--features',str(fp),'--features-sha256',fh,'--train',str(tp),'--train-sha256',th,
                '--output-model',str(root/'model.json'),'--output-report',str(root/'report.json'),'--execute-after-f1']
            opened=[];original=cli.io139.load
            def guarded(path: Path,expected: str) -> dict:
                """
                機能: 人工2入力以外の読取を禁止する。
                引数: path(Path)、expected(str)は場所と指紋。
                返り値: dictは人工JSON。
                """
                self.assertIn(path,(fp,tp));opened.append(path);return original(path,expected)
            with patch('sys.argv',args),patch.object(cli,'FEATURES_SHA',fh),patch.object(cli,'TRAIN_SHA',th),patch.object(cli.io139,'load',side_effect=guarded):cli.main()
            self.assertEqual(opened,[fp,tp]);self.assertTrue((root/'model.json').exists())
            with patch('sys.argv',args+['--validation',str(root/'開かない後25.json')]),redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit):cli.main()


if __name__=='__main__':unittest.main(verbosity=2)
