"""139の明示SHA・未作成出力だけを扱う。固定データへの暗黙のアクセスはしない。"""
import hashlib
import json
from pathlib import Path


def sha(path: Path) -> str:
    """
    機能: 保存bytesのSHA256を求める。
    引数: path(Path)は対象。
    返り値: strは指紋。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path,expected: str) -> dict:
    """
    機能: 指定SHAだけのJSONを読む。
    引数: path(Path)、expected(str)は場所と期待指紋。
    返り値: dictは検査済みJSON。
    """
    assert len(expected)==64 and all(c in '0123456789abcdef' for c in expected)
    raw=path.read_bytes();assert hashlib.sha256(raw).hexdigest()==expected
    return json.loads(raw)


def save(path: Path,value: dict) -> str:
    """
    機能: 未作成先へUTF-8のJSONを保存する。
    引数: path(Path)、value(dict)は先と値。
    返り値: strは保存SHA256。
    """
    assert not path.exists();path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
    return sha(path)
