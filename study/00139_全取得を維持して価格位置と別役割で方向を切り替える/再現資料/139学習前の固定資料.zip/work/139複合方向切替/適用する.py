"""モデルSHA固定後に、ラベルを受けず全752方向を保存する。"""
import argparse
import json
from pathlib import Path
import learner
import io139


def main() -> None:
    """
    機能: 固定モデルを全出生特徴へ適用する。
    引数: CLI features/modelと各sha256、output、execute-after-model-freeze。
    返り値: None。全752・固定81を保った方向票を保存する。
    """
    p=argparse.ArgumentParser(description='139のラベルなし固定モデル適用')
    for n in ('features','model'):p.add_argument('--'+n,type=Path,required=True);p.add_argument('--'+n+'-sha256',required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--execute-after-model-freeze',action='store_true',required=True);a=p.parse_args()
    assert not a.output.exists();f=io139.load(a.features,a.features_sha256);m=io139.load(a.model,a.model_sha256)
    assert m['features_sha256']==a.features_sha256
    out=learner.apply(f,m);out.update({'model_sha256':a.model_sha256,'features_sha256':a.features_sha256})
    assert io139.sha(a.features)==a.features_sha256 and io139.sha(a.model)==a.model_sha256
    h=io139.save(a.output,out);print(json.dumps({'成功':True,'choices_sha256':h,'counts':out['counts']},ensure_ascii=False))


if __name__=='__main__':main()
