"""固定方向票と後25の主幅ラベルだけで診断する。学習器は呼ばない。"""
import argparse
import json
from pathlib import Path
import learner
import io139


def main() -> None:
    """
    機能: SHA固定済み方向票の後25だけを評価する。
    引数: CLI choices/validationと各sha256、model-sha256、output。
    返り値: None。主125pt/H60の診断を保存し再学習しない。
    """
    p=argparse.ArgumentParser(description='139選定後の後25主幅診断')
    for n in ('choices','validation'):p.add_argument('--'+n,type=Path,required=True);p.add_argument('--'+n+'-sha256',required=True)
    p.add_argument('--model-sha256',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    assert not a.output.exists();c=io139.load(a.choices,a.choices_sha256);v=io139.load(a.validation,a.validation_sha256)
    assert c['model_sha256']==a.model_sha256 and c['features_sha256']==v['features_sha256']
    result=learner.evaluate(c,v);result.update({'model_sha256':a.model_sha256,'choices_sha256':a.choices_sha256,'validation_sha256':a.validation_sha256})
    assert io139.sha(a.choices)==a.choices_sha256 and io139.sha(a.validation)==a.validation_sha256
    h=io139.save(a.output,result);print(json.dumps({'成功':True,'evaluation_sha256':h,'stats':result['stats']},ensure_ascii=False))


if __name__=='__main__':main()
