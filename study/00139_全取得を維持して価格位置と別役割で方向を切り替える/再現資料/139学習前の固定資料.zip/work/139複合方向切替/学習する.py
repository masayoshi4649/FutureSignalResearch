"""前48のラベルだけを受ける139学習CLI。別評価ラベルの引数を持たない。"""
import argparse
import json
from pathlib import Path
import learner
import io139

FEATURES_SHA='1812f9d2479dcd383f257f8323cc83e714a8b42d28a0caa5b987fe1114dc5d5d'
TRAIN_SHA='5ac6136ee3cede031b3a7569a4025da13b504b56365fef15983698ec664e8042'


def main() -> None:
    """
    機能: Root F1後の明示操作でだけ前48の規則を選定する。
    引数: CLI features/trainと各sha256、output-model/output-report、execute-after-f1。
    返り値: None。未作成モデルと選定報告を保存する。
    """
    p=argparse.ArgumentParser(description='139前48だけの学習')
    for n in ('features','train'):p.add_argument('--'+n,type=Path,required=True);p.add_argument('--'+n+'-sha256',required=True)
    p.add_argument('--output-model',type=Path,required=True);p.add_argument('--output-report',type=Path,required=True)
    p.add_argument('--execute-after-f1',action='store_true',required=True);a=p.parse_args()
    assert a.features_sha256==FEATURES_SHA and a.train_sha256==TRAIN_SHA
    assert a.output_model.resolve()!=a.output_report.resolve() and not a.output_model.exists() and not a.output_report.exists()
    f=io139.load(a.features,a.features_sha256);t=io139.load(a.train,a.train_sha256);assert t['features_sha256']==a.features_sha256
    model,report=learner.learn(f,t);model.update({'features_sha256':a.features_sha256,'train_sha256':a.train_sha256,
        'learner_sha256':io139.sha(Path(learner.__file__)),'training_cli_sha256':io139.sha(Path(__file__))})
    assert io139.sha(a.features)==a.features_sha256 and io139.sha(a.train)==a.train_sha256
    msha=io139.save(a.output_model,model);report.update({'features_sha256':a.features_sha256,'train_sha256':a.train_sha256,'model_sha256':msha})
    rsha=io139.save(a.output_report,report);print(json.dumps({'成功':True,'model_sha256':msha,'report_sha256':rsha,'selected_rule':model['selected_rule']},ensure_ascii=False))


if __name__=='__main__':main()
