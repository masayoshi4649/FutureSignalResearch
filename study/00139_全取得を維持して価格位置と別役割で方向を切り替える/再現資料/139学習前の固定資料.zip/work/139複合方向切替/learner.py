"""139の事前28ANDだけを選ぶ純学習部品。ファイルや金融計算器は読み込まない。"""
import hashlib
import json
import math
import copy
from collections import Counter

PARAMETERS={'minimum_complete_pairs':40,'minimum_sessions':10,'penalty':3,'protected_baseline':81,'entries':752,'sessions':73,'train_sessions':48}
PREDICATES=[
 {'id':'A1','feature':'m5_price_ema21_atr_to_side','op':'>=','threshold':1,'role':'構造','indicator':'MA'},
 {'id':'A2','feature':'bb15_position_sigma_to_side','op':'>=','threshold':2,'role':'構造','indicator':'BB'},
 {'id':'A3','feature':'m5_forward_wick_ratio','op':'>=','threshold':.25,'role':'構造','indicator':'足形'},
 {'id':'B1','feature':'m30_gap_atr_to_side','op':'<=','threshold':0,'role':'方向','indicator':'MA'},
 {'id':'B2','feature':'m15_ema21_delta_atr_to_side','op':'<=','threshold':0,'role':'方向','indicator':'MA'},
 {'id':'B3','feature':'m5_hist_delta_atr_to_side','op':'<=','threshold':0,'role':'勢い','indicator':'MACD'},
 {'id':'B4','feature':'m15_hist_atr_to_side','op':'<=','threshold':0,'role':'勢い','indicator':'MACD'},
 {'id':'B5','feature':'m5_rsi_delta_to_side','op':'<=','threshold':0,'role':'勢い','indicator':'RSI'},
 {'id':'B6','feature':'m15_adx','op':'<=','threshold':20,'role':'強度','indicator':'DMI'},
 {'id':'B7','feature':'m15_adx_delta','op':'<=','threshold':0,'role':'強度','indicator':'DMI'},
 {'id':'B8','feature':'m5_tr_previous_atr_ratio','op':'>=','threshold':2,'role':'値幅','indicator':'ATR'},
 {'id':'B9','feature':'rvol5','op':'<','threshold':.5,'role':'量','indicator':'出来高'},
 {'id':'B10','feature':'rvol5','op':'>=','threshold':2,'role':'量','indicator':'出来高'}]
BY_ID={p['id']:p for p in PREDICATES}
FEATURES=tuple(dict.fromkeys(p['feature'] for p in PREDICATES))
RULES=[{'id':a['id']+'_'+b['id'],'predicates':[a['id'],b['id']]} for a in PREDICATES[:3] for b in PREDICATES[3:] if a['indicator']!=b['indicator']]
assert len(FEATURES)==12 and len(RULES)==28


def rules_sha() -> str:
    """
    機能: 辞書・境界・制約を安定した指紋へまとめる。
    引数: なし。
    返り値: strは固定ルールセットSHA256。
    """
    return hashlib.sha256(json.dumps({'parameters':PARAMETERS,'predicates':PREDICATES,'rules':RULES},ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def finite(value: object) -> bool:
    """
    機能: bool以外の有限数値を判定する。
    引数: value(object)は値。
    返り値: boolは有限数値か。
    """
    return type(value) in (int,float) and math.isfinite(value)


def feature_index(features: dict) -> dict:
    """
    機能: 全752の識別/保護/出生特徴構造を検査する。
    引数: features(dict)は特徴だけの入力。
    返り値: dictはID別行。後25の数値を規則選択には使わない。
    """
    assert features['success'] and features['trial']==139
    sessions=features['sessions'];assert len(sessions)==len(set(sessions))==73
    index={r['id']:r for r in features['rows']};assert len(index)==len(features['rows'])==752
    assert sum(r['baseline'] is True for r in index.values())==81
    for r in index.values():
        assert r['session'] in sessions and type(r['baseline']) is bool and type(r['native_side']) is int and r['native_side'] in (-1,1)
        assert r['origins']
        for origin in r['origins']:assert origin['query_id'] and set(FEATURES)<=set(origin['values'])
    return index


def label(o: dict) -> None:
    """
    機能: 学習/評価用の主幅ラベルだけを検査する。
    引数: o(dict)はH60±125の保存情報。
    返り値: None。金融値を特徴へ混ぜない。
    """
    assert type(o['complete']) is bool and type(o['direction']) is int and o['direction'] in (-1,0,1)
    assert type(o['ifd_known']) is bool
    assert finite(o['net5']) if o['ifd_known'] else o['net5'] is None


def predicate(row: dict,p: dict) -> tuple[bool,bool]:
    """
    機能: 全originの既知値が同じ述語を満たすか確認する。
    引数: row/p(dict)は出生特徴行と固定述語。
    返り値: tuple[bool,bool]は全既知・全成立。未知を0にしない。
    """
    known=True;passed=True
    for origin in row['origins']:
        v=origin['values'][p['feature']];assert type(v['known']) is bool
        if not v['known']:known=False;passed=False;continue
        value=v['value'];assert finite(value)
        ok=value>=p['threshold'] if p['op']=='>=' else value<=p['threshold'] if p['op']=='<=' else value<p['threshold']
        passed=passed and ok
    return known,passed


def matches(row: dict,rule: dict) -> tuple[bool,str]:
    """
    機能: 別役割2条件ANDを全originsで判定する。
    引数: row/rule(dict)は出生行と固定規則。
    返り値: tuple[bool,str]は成立・理由。
    """
    results=[predicate(row,BY_ID[i]) for i in rule['predicates']]
    if not all(k for k,_ in results):return False,'特徴未知のためnative維持'
    return (True,'2役割ANDが全originで成立') if all(v for _,v in results) else (False,'固定AND不成立')


def learn(features: dict,train: dict) -> tuple[dict,dict]:
    """
    機能: 前48ラベルだけで1本の28AND又は全keepを選ぶ。
    引数: features/train(dict)は全特徴と物理分離した前48ラベル。
    返り値: tuple[dict,dict]はモデル・全28候補の選定証跡。
    """
    index=feature_index(features);sessions=features['sessions'][:48]
    assert train['success'] and train['trial']==139 and train['split']=='train' and train['sessions']==sessions
    labels={r['id']:r for r in train['rows']};expected={i for i,r in index.items() if r['session'] in sessions}
    assert set(labels)==expected and len(labels)==len(train['rows'])
    for i,o in labels.items():
        assert o['session']==index[i]['session'];label(o['original']);label(o['reverse'])
    candidates=[]
    # ----------------------------------------
    # 学習値はここで前48・非baselineだけに限定し、後25の特徴値を評価しません。
    rows=[index[i] for i in labels if not index[i]['baseline']]
    for order,rule in enumerate(RULES):
        selected=[r for r in rows if matches(r,rule)[0]];support=[];gain_by_session=Counter();cash=[]
        for r in selected:
            o=labels[r['id']];a,b=o['original'],o['reverse']
            if a['complete'] and b['complete']:
                support.append(r);gain_by_session[r['session']]+=b['direction']-a['direction']
            if a['ifd_known'] and b['ifd_known']:cash.append(b['net5']-a['net5'])
        gain=sum(gain_by_session.values());score=gain-3;cash_gain=sum(cash) if cash else None
        leave_best=gain-max(gain_by_session.values()) if gain_by_session else None
        gates={'40両側H完了':len(support)>=40,'10場以上':len(gain_by_session)>=10,'gain罰則後正':score>0,
            'C5両側既知差正':cash_gain is not None and cash_gain>0,'最良1場除外gain正':leave_best is not None and leave_best>0}
        candidates.append({'rule_id':rule['id'],'table_order':order,'matched_additional':len(selected),'complete_pairs':len(support),
            'support_sessions':len(gain_by_session),'utility_gain':gain,'score':score,'cash_pairs':len(cash),'net5_pair_gain':cash_gain,
            'gain_without_best_session':leave_best,'gates':gates,'eligible':all(gates.values())})
    eligible=[r for r in candidates if r['eligible']]
    winner=max(eligible,key=lambda r:(r['score'],-r['table_order'])) if eligible else None
    selected_rule=next((r for r in RULES if winner and r['id']==winner['rule_id']),None)
    model={'success':True,'trial':139,'model_type':'位置と別役割のAND1本','rules_sha256':rules_sha(),'parameters':dict(PARAMETERS),
        'selected_rule':copy.deepcopy(selected_rule),'training_sessions':list(sessions),'protected_baseline':81,'unknown':'keep','all_origins':'known AND一致',
        'heldout_labels_read':False,'decision_uses_label_or_family_or_date_or_id':False}
    report={'success':True,'trial':139,'train_entries':len(labels),'train_additional':len(rows),'train_sessions':48,'candidate_count':28,
        'candidates':candidates,'winner':winner,'heldout_labels_read':False,'heldout_feature_values_used_for_selection':False}
    return model,report


def apply(features: dict,model: dict) -> dict:
    """
    機能: 固定モデルを全752へ適用し、全件のnative/選択方向を返す。
    引数: features/model(dict)は特徴とSHA固定済みモデル。
    返り値: dictは全752方向票。ラベルは受け取らない。
    """
    index=feature_index(features);assert model['success'] and model['trial']==139 and model['rules_sha256']==rules_sha() and model['parameters']==PARAMETERS
    rule=model['selected_rule'];assert rule is None or rule in RULES
    rows=[]
    for r in features['rows']:
        flip=False;reason='選定規則なし・native維持'
        if r['baseline']:reason='固定81保護'
        elif rule is not None:flip,reason=matches(r,rule)
        rows.append({'id':r['id'],'session':r['session'],'native_side':r['native_side'],'selected_side':-r['native_side'] if flip else r['native_side'],
            'baseline':r['baseline'],'action':'flip' if flip else 'keep','reason':reason,'rule_id':rule['id'] if rule else None})
    assert len(rows)==752 and sum(r['baseline'] for r in rows)==81 and all(r['action']=='keep' for r in rows if r['baseline'])
    return {'success':True,'trial':139,'rows':rows,'counts':dict(Counter(r['action'] for r in rows)),
        'all_752_kept':True,'protected_81_kept':True,'sessions':list(features['sessions']),'labels_read':False}


def evaluate(choices: dict,labels: dict) -> dict:
    """
    機能: SHA固定後の方向票を後25の主幅ラベルだけで診断する。
    引数: choices/labels(dict)は全方向票と別評価ファイル。
    返り値: dictはnative/切替の完了/未知/利益損失。再学習しない。
    """
    assert choices['success'] and choices['trial']==139 and len(choices['rows'])==752 and len(choices['sessions'])==73
    assert all(r['native_side'] in (-1,1) and r['selected_side'] in (-1,1) and (not r['baseline'] or r['native_side']==r['selected_side']) for r in choices['rows'])
    assert labels['success'] and labels['trial']==139 and labels['split']=='validation' and labels['sessions']==choices['sessions'][48:]
    index={r['id']:r for r in choices['rows'] if r['session'] in labels['sessions']}
    assert set(index)=={r['id'] for r in labels['rows']} and len(labels['rows'])==len(index)
    out={}
    for policy in ('native','selected'):
        counts=Counter();money=[]
        for r in labels['rows']:
            c=index[r['id']];assert c['session']==r['session'];label(r['original']);label(r['reverse'])
            o=r['reverse'] if policy=='selected' and c['selected_side']!=c['native_side'] else r['original']
            counts['entries']+=1
            if o['complete']:counts['complete']+=1;counts[{1:'forward',-1:'adverse',0:'neither'}[o['direction']]]+=1
            else:counts['censored']+=1
            if o['ifd_known']:money.append(o['net5'])
        resolved=counts['forward']+counts['adverse'];profit=sum(x for x in money if x>0);loss=-sum(x for x in money if x<0)
        out[policy]={'entries':counts['entries'],'complete':counts['complete'],'censored':counts['censored'],'forward':counts['forward'],'adverse':counts['adverse'],'neither':counts['neither'],
            'resolved_rate':counts['forward']/resolved if resolved else None,'complete_rate':counts['forward']/counts['complete'] if counts['complete'] else None,
            'ifd_known':len(money),'ifd_unknown':counts['entries']-len(money),'net5_profit':profit if money else None,'net5_loss':loss if money else None,
            'net5_sum':sum(money) if money else None,'net5_pf':profit/loss if loss else None}
    return {'success':True,'trial':139,'split':'validation','主幅pt':125,'主秒':3600,'stats':out,'model_relearned':False,'independent_unknown_period':False}
