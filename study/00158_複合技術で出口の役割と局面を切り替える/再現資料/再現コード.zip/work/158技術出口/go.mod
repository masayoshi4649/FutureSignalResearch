module technicalexit158

go 1.24.2

require (
	exitreplay157 v0.0.0
	features158 v0.0.0
)

require (
	github.com/masayoshi4649/SessionTradeExecuter/entryrules118 v0.0.0 // indirect
	pricetape157 v0.0.0 // indirect
)

replace features158 => ../158技術特徴

replace pricetape157 => ../157固定入口と価格経路

replace exitreplay157 => ../157出口政策の再生

replace github.com/masayoshi4649/SessionTradeExecuter/entryrules118 => ../118複数技法の入口条件
