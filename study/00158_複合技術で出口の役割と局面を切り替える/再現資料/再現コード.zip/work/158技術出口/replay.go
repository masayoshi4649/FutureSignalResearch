package technicalexit158

import (
	"bufio"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"

	tape "pricetape157"
)

type CaseResult struct {
	ID           string               `json:"id"`
	OriginalSide int                  `json:"original_side"`
	Side         int                  `json:"side"`
	Stream       string               `json:"stream"`
	Entry        Quote                `json:"entry"`
	EntryPrice   float64              `json:"entry_price"`
	Memberships  []tape.Membership157 `json:"memberships"`
	Results      []Result             `json:"results"`
}

type SceneResult struct {
	Session        string               `json:"session"`
	Contract       string               `json:"contract"`
	Start          float64              `json:"start"`
	End            float64              `json:"end"`
	ForceClose     float64              `json:"force_close"`
	ContinuousEnd  float64              `json:"continuous_end"`
	EntriesMatched int                  `json:"entries_matched"`
	TapeRead       tape.TapeRead157     `json:"tape_read"`
	FeatureRead    *FeatureReadEvidence `json:"feature_read,omitempty"`
	Cases          []CaseResult         `json:"cases"`
}

type stateCase struct {
	fixed   tape.FixedCase157
	states  []*FSM
	matched bool
}

type Ref struct {
	Path   string `json:"path"`
	SHA256 string `json:"sha256"`
}

type Completion struct {
	Success            bool   `json:"success"`
	Trial              int    `json:"trial"`
	Result             Ref    `json:"result"`
	DecodedSHA256      string `json:"decoded_sha256"`
	DecodedBytes       int64  `json:"decoded_bytes"`
	Bytes              int64  `json:"bytes"`
	SceneCount         int    `json:"scene_count"`
	CaseCount          int    `json:"case_count"`
	MembershipCount    int    `json:"membership_count"`
	ConfigurationCount int    `json:"configuration_count"`
}

// ReplayScene は1場の薄いテープを1回完読して全物理caseを再生します。
//
// 引数: scene FixedScene157、stream SceneTape157、directory string、configs []Config。
// 返り値: SceneResult 型とerror。元Rawと将来の別場を読みません。
func ReplayScene(scene tape.FixedScene157, stream tape.SceneTape157, directory string, configs []Config, runtimes ...SceneRuntime) (SceneResult, error) {
	out := SceneResult{Session: scene.Session, Contract: scene.Contract, Start: scene.Start, End: scene.End, ForceClose: scene.ForceClose, ContinuousEnd: scene.ContinuousEnd}
	if !stream.Success || stream.Session != scene.Session || stream.Contract != scene.Contract || stream.Start != scene.Start || stream.End != scene.End || stream.ForceClose != scene.ForceClose || stream.ContinuousEnd != scene.ContinuousEnd || stream.Raw != scene.Raw || stream.ActualSHA256 != scene.Raw.SHA256 {
		return out, fmt.Errorf("固定場とテープの由来差:%s", scene.Session)
	}
	var runtime *SceneRuntime
	if len(runtimes) > 1 {
		return out, fmt.Errorf("特徴runtimeが複数です")
	}
	if len(runtimes) == 1 {
		runtime = &runtimes[0]
		if runtime.Close != nil {
			defer runtime.Close()
		}
	}
	holders := make([]*stateCase, len(scene.Cases))
	waiting := map[int64][]*stateCase{}
	declared := map[string]tape.EntryMatch157{}
	for _, m := range stream.EntryMatches {
		if _, ok := declared[m.CaseID]; ok {
			return out, fmt.Errorf("テープの取得宣言重複")
		}
		declared[m.CaseID] = m
	}
	if len(declared) != len(scene.Cases) {
		return out, fmt.Errorf("取得宣言件数差")
	}
	for i, c := range scene.Cases {
		m, ok := declared[c.ID]
		if !ok || m.Quote != c.Entry {
			return out, fmt.Errorf("取得宣言全Quote差:%s", c.ID)
		}
		x := &stateCase{fixed: c}
		holders[i] = x
		waiting[c.Entry.SourceLine] = append(waiting[c.Entry.SourceLine], x)
	}
	active := []*stateCase{}
	read, e := tape.ReadTape(directory, stream, func(raw tape.Quote) error {
		q := Quote(raw)
		var prepared *PreparedContext
		context := FeatureContext{}
		if runtime != nil {
			var err error
			prepared, err = runtime.Cursor(q)
			if err != nil {
				return err
			}
			context = prepared.context
		}
		next := active[:0]
		for _, x := range active {
			live := false
			for _, f := range x.states {
				if !f.Done() {
					var stepErr error
					if f.technical == nil {
						stepErr = f.Step(q)
					} else {
						stepErr = f.StepPrepared(q, prepared)
					}
					if e := stepErr; e != nil {
						return fmt.Errorf("%s/%s: %w", scene.Session, x.fixed.ID, e)
					}
				}
				if !f.Done() {
					live = true
				}
			}
			if live {
				next = append(next, x)
			}
		}
		active = next
		for _, x := range waiting[q.SourceLine] {
			if x.matched || tape.Quote(q) != x.fixed.Entry {
				return fmt.Errorf("固定取得原行全値差:%s", x.fixed.ID)
			}
			for _, c := range configs {
				var f *FSM
				var e error
				if def, ok := definitionFor(c.Policy); ok {
					if runtime == nil {
						return fmt.Errorf("技術政策に特徴runtimeがありません")
					}
					controller, err := Builtin(c.Policy)
					if err != nil {
						return err
					}
					f, e = NewTechnical(q, x.fixed.Side, x.fixed.EntryPrice, scene.ForceClose, scene.ContinuousEnd, c, Scope{scene.Session, scene.Contract}, def, controller)
					if e == nil {
						f.technical.entryContext = &context
					}
				} else {
					f, e = New(q, x.fixed.Side, x.fixed.EntryPrice, scene.ForceClose, scene.ContinuousEnd, c)
				}
				if e != nil {
					return e
				}
				x.states = append(x.states, f)
			}
			x.matched = true
			out.EntriesMatched++
			active = append(active, x)
		}
		return nil
	})
	if e != nil {
		return out, e
	}
	if runtime != nil && runtime.Finish != nil {
		if e = runtime.Finish(); e != nil {
			return out, e
		}
	}
	if runtime != nil && runtime.Evidence != nil {
		x := runtime.Evidence()
		out.FeatureRead = &x
	}
	out.TapeRead = read
	if out.EntriesMatched != len(scene.Cases) {
		return out, fmt.Errorf("未照合の固定取得:%s", scene.Session)
	}
	for _, x := range holders {
		c := x.fixed
		r := CaseResult{ID: c.ID, OriginalSide: c.OriginalSide, Side: c.Side, Stream: c.Stream, Entry: Quote(c.Entry), EntryPrice: c.EntryPrice, Memberships: c.Memberships}
		for _, f := range x.states {
			f.Finish()
			r.Results = append(r.Results, f.Result())
		}
		out.Cases = append(out.Cases, r)
	}
	return out, nil
}

// Run は固定指紋入力を検査し、出口結果gzipを新規に1回書きます。
//
// 引数: input/manifest/spec/output string と各固定SHA、progress func(string)。
// 返り値: Completion 型とerror。完成前のpartialを正本名へ移しません。
func Run(input, inputSHA, manifest, manifestSHA, spec, specSHA, output string, progress func(string), options ...RunOptions) (done Completion, err error) {
	if input == "" || manifest == "" || spec == "" || output == "" {
		return done, fmt.Errorf("固定入力/テープmanifest/実行条件/出力が必要です")
	}
	if err = verifyRef(spec, specSHA); err != nil {
		return done, err
	}
	opts := RunOptions{ControlsOnly: true}
	if len(options) > 1 {
		return done, fmt.Errorf("運転optionsが複数です")
	}
	if len(options) == 1 {
		opts = options[0]
	}
	if opts.F0 != "" {
		if err = verifyRef(opts.F0, opts.F0SHA); err != nil {
			return done, err
		}
	}
	in, e := tape.LoadFixed(input, inputSHA)
	if e != nil {
		return done, e
	}
	m, e := tape.ReadManifest(manifest, manifestSHA)
	if e != nil {
		return done, e
	}
	if m.Input.SHA256 != inputSHA || len(m.Scenes) != len(in.Scenes) {
		return done, fmt.Errorf("manifestの固定入力参照差")
	}
	if _, e = os.Stat(output); e == nil {
		return done, fmt.Errorf("既存結果を上書きしません")
	} else if !os.IsNotExist(e) {
		return done, e
	}
	if e = os.MkdirAll(filepath.Dir(output), 0755); e != nil {
		return done, e
	}
	partial := output + ".partial"
	file, e := os.OpenFile(partial, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0644)
	if e != nil {
		return done, e
	}
	defer func() {
		file.Close()
		if err != nil {
			_ = os.Remove(partial)
		}
	}()
	physical := sha256.New()
	pw := &countWriter{writer: io.MultiWriter(file, physical)}
	z := gzip.NewWriter(pw)
	buffer := bufio.NewWriterSize(z, 1024*1024)
	decoded := sha256.New()
	dw := &countWriter{writer: io.MultiWriter(buffer, decoded)}
	var featureManifest *FeatureManifest
	if !opts.ControlsOnly {
		if e = verifyRef(opts.Policies, opts.PoliciesSHA); e != nil {
			return done, e
		}
		if e = checkPolicyIDs(opts.Policies); e != nil {
			return done, e
		}
		loaded, err := LoadFeatureManifest(opts.Features, opts.FeaturesSHA)
		if err != nil {
			return done, err
		}
		featureManifest = &loaded
		if len(loaded.Scenes) != len(in.Scenes) {
			return done, fmt.Errorf("特徴入力の場数差")
		}
	}
	configs := Configurations()
	if opts.ControlsOnly {
		configs = BaselineConfigurations()
	}
	header := map[string]any{"success": true, "trial": 158, "schema": "technical_exit_results_v1", "input_ref": Ref{input, inputSHA}, "tape_manifest_ref": Ref{manifest, manifestSHA}, "source_refs": map[string]any{"execution_spec": Ref{spec, specSHA}, "fixed_input_parents": in.SourceRefs}, "configurations": configs, "scene_count": len(in.Scenes), "case_count": in.ExpectedCaseCount, "membership_count": in.ExpectedMembershipCount, "configuration_count": len(configs), "entry_row_attainment_excluded": true, "mfe_anchor_zero": true, "mae_includes_entry_spread": true, "last_ohlc_includes_entry": true, "main_delay": "D1", "account_pnl": false}
	if !opts.ControlsOnly {
		header["policy_ref"] = Ref{opts.Policies, opts.PoliciesSHA}
		header["features_ref"] = Ref{opts.Features, opts.FeaturesSHA}
	}
	if opts.F0 != "" {
		if e = verifyRef(opts.F0, opts.F0SHA); e != nil {
			return done, e
		}
		header["f0_ref"] = Ref{opts.F0, opts.F0SHA}
	}
	body, e := json.Marshal(header)
	if e != nil {
		return done, e
	}
	if _, e = dw.Write(append(body[:len(body)-1], []byte(",\"scenes\":[")...)); e != nil {
		return done, e
	}
	for i, s := range in.Scenes {
		if i > 0 {
			if _, e = dw.Write([]byte(",")); e != nil {
				return done, e
			}
		}
		var r SceneResult
		if featureManifest == nil {
			r, e = ReplayScene(s, m.Scenes[i], filepath.Dir(manifest), configs)
		} else {
			runtime, err := NewSceneRuntime(s, featureManifest.Scenes[i], filepath.Dir(opts.Features))
			if err != nil {
				return done, err
			}
			r, e = ReplayScene(s, m.Scenes[i], filepath.Dir(manifest), configs, runtime)
		}
		if e != nil {
			return done, e
		}
		body, e = json.Marshal(r)
		if e != nil {
			return done, e
		}
		if _, e = dw.Write(body); e != nil {
			return done, e
		}
		if progress != nil {
			progress(fmt.Sprintf("%d/%d %s 取得%d", i+1, len(in.Scenes), s.Session, r.EntriesMatched))
		}
	}
	if _, e = dw.Write([]byte("]}\n")); e != nil {
		return done, e
	}
	if e = buffer.Flush(); e != nil {
		return done, e
	}
	if e = z.Close(); e != nil {
		return done, e
	}
	if e = file.Sync(); e != nil {
		return done, e
	}
	if e = file.Close(); e != nil {
		return done, e
	}
	refs := []Ref{{input, inputSHA}, {manifest, manifestSHA}, {spec, specSHA}}
	if !opts.ControlsOnly {
		refs = append(refs, Ref{opts.Policies, opts.PoliciesSHA}, Ref{opts.Features, opts.FeaturesSHA})
	}
	if opts.F0 != "" {
		refs = append(refs, Ref{opts.F0, opts.F0SHA})
	}
	for _, r := range refs {
		if e = verifyRef(r.Path, r.SHA256); e != nil {
			return done, e
		}
	}
	if e = os.Rename(partial, output); e != nil {
		return done, e
	}
	return Completion{Success: true, Trial: 158, Result: Ref{output, hex.EncodeToString(physical.Sum(nil))}, DecodedSHA256: hex.EncodeToString(decoded.Sum(nil)), Bytes: pw.bytes, DecodedBytes: dw.bytes, SceneCount: len(in.Scenes), CaseCount: in.ExpectedCaseCount, MembershipCount: in.ExpectedMembershipCount, ConfigurationCount: len(configs)}, nil
}

type countWriter struct {
	writer io.Writer
	bytes  int64
}

// Write は書込bytesを数えます。
//
// 引数: body []byte。返り値: int/error。
func (w *countWriter) Write(body []byte) (int, error) {
	n, e := w.writer.Write(body)
	w.bytes += int64(n)
	return n, e
}

// verifyRef は小さい固定源の物理SHAを検査します。
//
// 引数: path/expected string。返り値: error。
func verifyRef(path, expected string) error {
	if len(expected) != 64 {
		return fmt.Errorf("明示SHAが必要です:%s", path)
	}
	f, e := os.Open(path)
	if e != nil {
		return e
	}
	defer f.Close()
	h := sha256.New()
	if _, e = io.Copy(h, f); e != nil {
		return e
	}
	if hex.EncodeToString(h.Sum(nil)) != expected {
		return fmt.Errorf("固定SHA差:%s", path)
	}
	return nil
}
