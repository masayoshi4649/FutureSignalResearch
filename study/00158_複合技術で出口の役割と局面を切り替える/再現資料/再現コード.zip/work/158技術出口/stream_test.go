package technicalexit158

import (
	"bytes"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"

	old "exitreplay157"
	tape "pricetape157"
)

// gzipFixture は人工JSONLを価格値のない一時領域へ保存します。
//
// 引数: t *testing.T、directory/name string、decoded []byte。
// 返り値: FeatureScene 型のgzip指紋参照。
func gzipFixture(t *testing.T, directory, name string, decoded []byte) FeatureScene {
	t.Helper()
	var compressed bytes.Buffer
	z := gzip.NewWriter(&compressed)
	if _, err := z.Write(decoded); err != nil {
		t.Fatal(err)
	}
	if err := z.Close(); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(directory, name), compressed.Bytes(), 0644); err != nil {
		t.Fatal(err)
	}
	ph, dh := sha256.Sum256(compressed.Bytes()), sha256.Sum256(decoded)
	return FeatureScene{Session: "人工場", Contract: "人工限月", Start: 0, End: 800, ForceClose: 200, ContinuousEnd: 500, Raw: tape.FileRef{Path: "未読Raw", SHA256: strings.Repeat("a", 64)}, Path: name, Bytes: int64(compressed.Len()), SHA256: hex.EncodeToString(ph[:]), DecodedSHA256: hex.EncodeToString(dh[:]), DecodedBytes: int64(len(decoded)), Rows: int64(bytes.Count(decoded, []byte{'\n'}))}
}

// fixedSceneFixture は固定取得1件を既存schemaで作ります。
//
// 引数: entry Quote。
// 返り値: FixedScene157 型。
func fixedSceneFixture(entry Quote) tape.FixedScene157 {
	return tape.FixedScene157{Session: "人工場", Contract: "人工限月", Start: 0, End: 800, ForceClose: 200, ContinuousEnd: 500, Raw: tape.FileRef{Path: "未読Raw", SHA256: strings.Repeat("a", 64)}, Cases: []tape.FixedCase157{{ID: "人工case", OriginalSide: 1, Side: 1, Stream: "original", Entry: tape.Quote(entry), EntryPrice: 1005, Memberships: []tape.Membership157{{Policy: "153U15", Side: 1, Stream: "original", EntryPrice: 1005}}}}}
}

// TestFeatureCursorCRCAndFreshness は未来票非適用・鮮度・末尾確認を検査します。
//
// 引数: t *testing.T。
// 返り値: なし。各RawのXを再計算せず更新イベントだけを再用します。
func TestFeatureCursorCRCAndFreshness(t *testing.T) {
	directory := t.TempDir()
	q := gainFixture(1, 20, 101, 2)
	context := contextFixture(q)
	value := context.Values["atr5"]
	value.ValidUntil = floatPtr(102)
	context.Values["atr5"] = value
	var body bytes.Buffer
	if err := json.NewEncoder(&body).Encode(context); err != nil {
		t.Fatal(err)
	}
	ref := gzipFixture(t, directory, "特徴.jsonl.gz", body.Bytes())
	entry, _ := entryFixture(1)
	fixed := fixedSceneFixture(entry)
	runtime, err := NewSceneRuntime(fixed, ref, directory)
	if err != nil {
		t.Fatal(err)
	}
	before, err := runtime.Cursor(entry)
	if err != nil {
		t.Fatal(err)
	}
	if len(before.context.Values) != 0 {
		t.Fatal("未来の特徴を使いました")
	}
	current, err := runtime.Cursor(q)
	if err != nil {
		t.Fatal(err)
	}
	if !current.context.Values["atr5"].Known {
		t.Fatal("現在の特徴がありません")
	}
	q = gainFixture(1, 20, 102, 3)
	expired, err := runtime.Cursor(q)
	if err != nil {
		t.Fatal(err)
	}
	if expired.context.Values["atr5"].Known || expired.context.Values["atr5"].Value != nil || !current.context.Values["atr5"].Known {
		t.Fatal("鮮度又は過去票不変性差")
	}
	if err = runtime.Finish(); err != nil {
		t.Fatal(err)
	}
	if !runtime.Evidence().Success || runtime.Evidence().Rows != 1 {
		t.Fatal("全読証跡差")
	}
	ref = gzipFixture(t, directory, "末尾不正.jsonl.gz", append(body.Bytes(), []byte("{\n")...))
	runtime, err = NewSceneRuntime(fixed, ref, directory)
	if err == nil {
		_, err = runtime.Cursor(gainFixture(1, 20, 101, 2))
	}
	if err == nil {
		t.Fatal("JSON末尾不正を受理しました")
	}
	ref = gzipFixture(t, directory, "CRC不正.jsonl.gz", body.Bytes())
	data, err := os.ReadFile(filepath.Join(directory, ref.Path))
	if err != nil {
		t.Fatal(err)
	}
	data[len(data)-8] ^= 1
	if err = os.WriteFile(filepath.Join(directory, ref.Path), data, 0644); err != nil {
		t.Fatal(err)
	}
	ph := sha256.Sum256(data)
	ref.SHA256 = hex.EncodeToString(ph[:])
	runtime, err = NewSceneRuntime(fixed, ref, directory)
	if err == nil {
		_, err = runtime.Cursor(gainFixture(1, 20, 101, 2))
	}
	if err == nil {
		t.Fatal("CRC破損を受理しました")
	}
}

// TestSceneControlsAndTechnicalReplay は共通価格/特徴cursorの結合を確認します。
//
// 引数: t *testing.T。
// 返り値: なし。旧3対照はScene再生でも157全結果同体です。
func TestSceneControlsAndTechnicalReplay(t *testing.T) {
	directory := t.TempDir()
	entry, _ := entryFixture(1)
	quotes := []Quote{gainFixture(1, -10, 99, 0), entry, gainFixture(1, 130, 101, 2), gainFixture(1, 10, 102, 3), gainFixture(1, 150, 103, 4)}
	for i := range quotes {
		quotes[i].Clock = "人工時計"
	}
	entry = quotes[1]
	var prices bytes.Buffer
	for _, q := range quotes {
		if err := json.NewEncoder(&prices).Encode(q); err != nil {
			t.Fatal(err)
		}
	}
	priceRef := gzipFixture(t, directory, "価格.jsonl.gz", prices.Bytes())
	first, last := tape.Quote(quotes[0]), tape.Quote(quotes[len(quotes)-1])
	stream := tape.SceneTape157{Success: true, Session: "人工場", Contract: "人工限月", Start: 0, End: 800, ForceClose: 200, ContinuousEnd: 500, Raw: priceRef.Raw, ActualSHA256: priceRef.Raw.SHA256, Tape: tape.TapeRef157{Path: priceRef.Path, Bytes: priceRef.Bytes, SHA256: priceRef.SHA256, DecodedSHA256: priceRef.DecodedSHA256, DecodedBytes: priceRef.DecodedBytes, Rows: int64(len(quotes))}, FirstQuote: &first, LastQuote: &last, EntryMatches: []tape.EntryMatch157{{CaseID: "人工case", Quote: tape.Quote(entry), TapeLine: 2}}}
	fixed := fixedSceneFixture(entry)
	newResult, err := ReplayScene(fixed, stream, directory, BaselineConfigurations())
	if err != nil {
		t.Fatal(err)
	}
	legacyConfigs := []old.Config{}
	for _, config := range BaselineConfigurations() {
		legacyConfigs = append(legacyConfigs, old.Config(config))
	}
	oldResult, err := old.ReplayScene(fixed, stream, directory, legacyConfigs)
	if err != nil {
		t.Fatal(err)
	}
	left, _ := json.Marshal(newResult.Cases[0].Results)
	right, _ := json.Marshal(oldResult.Cases[0].Results)
	if !bytes.Equal(left, right) {
		t.Fatal("Scene旧対照差")
	}
	context := fullFeatureFixture()
	context.At = Stamp{Time: 99, Index: 0, SourceLine: 1}
	context.UpdatedAt = context.At
	var features bytes.Buffer
	if err = json.NewEncoder(&features).Encode(context); err != nil {
		t.Fatal(err)
	}
	featureRef := gzipFixture(t, directory, "特徴.jsonl.gz", features.Bytes())
	runtime, err := NewSceneRuntime(fixed, featureRef, directory)
	if err != nil {
		t.Fatal(err)
	}
	r, err := ReplayScene(fixed, stream, directory, Configurations(), runtime)
	if err != nil {
		t.Fatal(err)
	}
	if len(r.Cases[0].Results) != 152 || r.FeatureRead == nil || !r.FeatureRead.Success {
		t.Fatal("全152再生又は特徴完読差")
	}
	if err = CheckFeatureCatalog(PolicyFeatureKeys()); err != nil {
		t.Fatal(err)
	}
	if err = CheckFeatureCatalog(PolicyFeatureKeys()[1:]); err == nil {
		t.Fatal("key不存在を当時unknownとしました")
	}
}
