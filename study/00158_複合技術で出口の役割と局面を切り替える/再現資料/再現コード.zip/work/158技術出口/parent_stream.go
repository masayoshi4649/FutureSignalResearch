package technicalexit158

import (
	"io"
	"os"
)

type countReader struct {
	reader io.Reader
	count  int64
}

// Read は解凍bytes数を数えながら同じデータだけを呼出側へ返します。
//
// 引数: p([]byte)。返り値: int/errorはio.Readerと同じ契約です。
func (c *countReader) Read(p []byte) (int, error) {
	n, err := c.reader.Read(p)
	c.count += int64(n)
	return n, err
}

// shaFormat は空や大文字を許容せず固定SHAを検査します。
//
// 引数: value(string)。返り値: boolです。
func shaFormat(value string) bool {
	if len(value) != 64 {
		return false
	}
	for _, c := range value {
		if !(c >= '0' && c <= '9' || c >= 'a' && c <= 'f') {
			return false
		}
	}
	return true
}

// stat は価格を含まない入力ファイルのサイズと変更時計を返します。
//
// 引数: info(os.FileInfo)。返り値: map[string]int64です。
func stat(info os.FileInfo) map[string]int64 {
	return map[string]int64{"bytes": info.Size(), "mtime_ns": info.ModTime().UnixNano()}
}
