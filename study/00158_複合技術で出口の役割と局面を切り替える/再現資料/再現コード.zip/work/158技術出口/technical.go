package technicalexit158

import (
	"fmt"
	"math"

	features "features158"
)

// Scope は価格経路と技術特徴の同場・同限月を束縛します。
type Scope struct {
	Session  string `json:"session"`
	Contract string `json:"contract"`
}

// Stamp は共有特徴部品と同じ実原行時計です。
type Stamp = features.Stamp

// FeatureValue は共有特徴部品の既知値です。
type FeatureValue = features.FeatureValue

// FeatureRef は共有特徴部品の由来票です。
type FeatureRef = features.FeatureRef

// FeatureContext は全batch適用後の共有特徴票です。
type FeatureContext = features.Context

// Definition は結果前に固定する技術政策の記述です。
type Definition struct {
	ID                 string             `json:"id"`
	Family             string             `json:"family"`
	Parameters         map[string]float64 `json:"parameters"`
	ArmThresholdPoints float64            `json:"arm_threshold_points"`
}

// StateView は保有中の状態を値コピーで技術判断へ渡します。
type StateView struct {
	Side           int                `json:"side"`
	Entry          Quote              `json:"entry"`
	Current        Quote              `json:"current"`
	EntryPrice     float64            `json:"entry_price"`
	GainPoints     float64            `json:"gain_points"`
	PeakPoints     float64            `json:"peak_points"`
	PeakTime       float64            `json:"peak_time"`
	StopPoints     float64            `json:"stop_points"`
	HeldSeconds    float64            `json:"held_seconds"`
	Armed          bool               `json:"armed"`
	FeatureChanged bool               `json:"feature_changed"`
	PreviousAt     *Stamp             `json:"previous_feature_at"`
	Memory         map[string]float64 `json:"memory"`
	EntryContext   *FeatureContext    `json:"entry_context"`
}

// Decision は起動閾値・起動後の床・返済要求を区別します。
type Decision struct {
	ArmThresholdPoints *float64           `json:"arm_threshold_points"`
	FloorPoints        *float64           `json:"floor_points"`
	TakeProfitPoints   *float64           `json:"take_profit_points"`
	ExitReason         string             `json:"exit_reason"`
	Reason             string             `json:"reason"`
	UsedFeatures       []string           `json:"used_features"`
	RefIDs             []string           `json:"ref_ids"`
	Memory             map[string]float64 `json:"memory"`
	Record             bool               `json:"record"`
	Fallback           bool               `json:"fallback"`
	MissingFeatures    []string           `json:"missing_features"`
}

// Controller は固定式の技術判断を実行する拡張点です。
//
// 引数: StateView 型の値コピー、FeatureContext 型の因果的な当時特徴。
// 返り値: Decision 型の提案と、型・時計・仕様不整合時の error。
type Controller interface {
	Evaluate(StateView, FeatureContext) (Decision, error)
}

// ControllerFunc は純関数を Controller へ接続します。
type ControllerFunc func(StateView, FeatureContext) (Decision, error)

// Evaluate は固定した判断関数を呼び出します。
//
// 引数: view StateView、context FeatureContext。
// 返り値: Decision 型の提案と error。
func (f ControllerFunc) Evaluate(view StateView, context FeatureContext) (Decision, error) {
	return f(view, context)
}

// TechnicalTrace は床の変更・起動・返済要求の根拠だけを保存します。
type TechnicalTrace struct {
	At                 Stamp    `json:"at"`
	FeatureAt          Stamp    `json:"feature_at"`
	Reason             string   `json:"reason"`
	ArmThresholdPoints float64  `json:"arm_threshold_points"`
	ArmStarted         bool     `json:"arm_started"`
	PreviousFloor      float64  `json:"previous_floor"`
	ProposedFloor      *float64 `json:"proposed_floor"`
	AppliedFloor       float64  `json:"applied_floor"`
	ExitReason         string   `json:"exit_reason"`
	TakeProfitPoints   *float64 `json:"take_profit_points"`
	Fallback           bool     `json:"fallback"`
	MissingFeatures    []string `json:"missing_features"`
	UsedFeatures       []string `json:"used_features"`
	RefIDs             []string `json:"ref_ids"`
}

type technicalState struct {
	scope          Scope
	definition     Definition
	controller     Controller
	context        FeatureContext
	previousAt     *Stamp
	memory         map[string]float64
	entryContext   *FeatureContext
	pendingUpdates []features.FeatureUpdate
	builtin        bool
}

// TechnicalCounts は判断・fallback・実発動を区別する分母です。
type TechnicalCounts struct {
	Evaluations         int64            `json:"evaluations"`
	FallbackEvaluations int64            `json:"fallback_evaluations"`
	FloorChanges        int64            `json:"floor_changes"`
	ArmStarts           int64            `json:"arm_starts"`
	TechnicalRequests   int64            `json:"technical_requests"`
	TakeProfitRequests  int64            `json:"take_profit_requests"`
	Reasons             map[string]int64 `json:"reasons"`
	MissingFeatures     map[string]int64 `json:"missing_features"`
}

// BaselineConfigurations は同体再生する旧3政策の24条件を返します。
//
// 引数: なし。
// 返り値: []Config 型。2期限・D0/D1・C0/C5を保持します。
func BaselineConfigurations() []Config {
	out := []Config{}
	for _, c := range LegacyConfigurations() {
		if c.Policy == "F125S125" || c.Policy == "T125W100TP250" || c.Policy == "E0W125" {
			out = append(out, c)
		}
	}
	return out
}

// NewTechnical は初期−125の独立1枚技術出口を作ります。
//
// 引数: entry Quote、side int、price/forceClose/continuousEnd float64、config Config、
// scope Scope、definition Definition、controller Controller。
// 返り値: *FSM 型と error。入口の選択・方向・価格を変更しません。
func NewTechnical(entry Quote, side int, price, forceClose, continuousEnd float64, config Config, scope Scope, definition Definition, controller Controller, entryContexts ...FeatureContext) (*FSM, error) {
	if controller == nil || scope.Session == "" || scope.Contract == "" || definition.ID == "" || definition.Family == "" || config.Policy != definition.ID || config.ID != definition.ID+"/"+config.Horizon+"/"+config.Delay+"/"+config.Cost || !finite(definition.ArmThresholdPoints) || definition.ArmThresholdPoints < 0 {
		return nil, fmt.Errorf("技術政策の束縛が不正です")
	}
	for _, v := range definition.Parameters {
		if !finite(v) {
			return nil, fmt.Errorf("技術政策の定数が非有限です")
		}
	}
	seed := config
	seed.Policy = "F125S125"
	seed.ID = seed.Policy + "/" + seed.Horizon + "/" + seed.Delay + "/" + seed.Cost
	f, err := New(entry, side, price, forceClose, continuousEnd, seed)
	if err != nil {
		return nil, err
	}
	f.config, f.rule = config, policy{id: definition.ID, sl: 125}
	f.result.ConfigID, f.result.Policy = config.ID, config.Policy
	definition.Parameters = copyNumbers(definition.Parameters)
	_, builtin := controller.(builtinController)
	f.technical = &technicalState{builtin: builtin, scope: scope, definition: definition, controller: controller, memory: map[string]float64{}}
	if len(entryContexts) > 1 {
		return nil, fmt.Errorf("取得時特徴が複数です")
	}
	if len(entryContexts) == 1 {
		context, err := normalizeContext(entryContexts[0], entry, scope)
		if err != nil {
			return nil, err
		}
		f.technical.entryContext = &context
	}
	f.result.TechnicalCounts = &TechnicalCounts{Reasons: map[string]int64{}, MissingFeatures: map[string]int64{}}
	return f, nil
}

// Step は旧対照又は技術出口へaccepted原行を1行配送します。
//
// 引数: q Quote、contexts ...FeatureContext（技術出口では正確に1件）。
// 返り値: error 型。終了済み状態・既予約は後の技術判断で変更しません。
func (f *FSM) Step(q Quote, contexts ...FeatureContext) error {
	if f.Done() {
		return nil
	}
	if len(contexts) > 1 || (f.technical != nil && len(contexts) != 1) {
		return fmt.Errorf("当時特徴の件数が不正です")
	}
	if f.technical != nil {
		context, err := normalizeContext(contexts[0], q, f.technical.scope)
		if err != nil {
			return err
		}
		f.technical.context = context
		for _, update := range context.Updates {
			if update.At.Time >= f.entry.Time && update.At.Index > f.entry.Index && update.At.SourceLine > f.entry.SourceLine {
				f.technical.pendingUpdates = append(f.technical.pendingUpdates, update)
			}
		}
	}
	return f.legacyStep(q)
}

// applyTechnical は既存床・期限・予約より後に固定式を評価します。
//
// 引数: q Quote 型の正常BBO行。
// 返り値: error 型。床は不利に緩めず、返済要求は既存D0/D1へ流します。
func (f *FSM) applyTechnical(q Quote) error {
	t := f.technical
	view := StateView{Side: f.side, Entry: f.entry, Current: q, EntryPrice: f.price, GainPoints: f.gain(q), PeakPoints: f.result.PeakPoints, StopPoints: f.result.StopPoints, HeldSeconds: q.Time - f.entry.Time, Armed: f.result.Armed, FeatureChanged: t.previousAt == nil || *t.previousAt != t.context.UpdatedAt, Memory: copyNumbers(t.memory), PeakTime: f.entry.Time}
	if f.result.PeakQuote != nil {
		view.PeakTime = f.result.PeakQuote.Time
	}
	if t.previousAt != nil {
		x := *t.previousAt
		view.PreviousAt = &x
	}
	if t.entryContext != nil {
		if t.builtin {
			view.EntryContext = t.entryContext
		} else {
			x := cloneContext(*t.entryContext)
			view.EntryContext = &x
		}
	}
	current := t.context
	if !t.builtin {
		current = cloneContext(t.context)
	}
	current.Updates = append([]features.FeatureUpdate(nil), t.pendingUpdates...)
	d, err := t.controller.Evaluate(view, current)
	if err != nil {
		return err
	}
	t.pendingUpdates = nil
	threshold := t.definition.ArmThresholdPoints
	if d.ArmThresholdPoints != nil {
		threshold = *d.ArmThresholdPoints
	}
	if !finite(threshold) || threshold < 0 || (d.FloorPoints != nil && !finite(*d.FloorPoints)) || (d.TakeProfitPoints != nil && (!finite(*d.TakeProfitPoints) || *d.TakeProfitPoints <= 0)) {
		return fmt.Errorf("技術判断の閾値・床・TPが不正です")
	}
	for _, value := range d.Memory {
		if !finite(value) {
			return fmt.Errorf("技術判断の状態が非有限です")
		}
	}
	refs := map[string]bool{}
	if len(d.RefIDs) > 0 {
		for _, ref := range t.context.Refs {
			refs[ref.ID] = true
		}
	}
	for _, name := range d.UsedFeatures {
		if _, ok := t.context.Values[name]; !ok {
			return fmt.Errorf("未配送の特徴参照:%s", name)
		}
	}
	for _, id := range d.RefIDs {
		if !refs[id] {
			return fmt.Errorf("未配送の由来参照:%s", id)
		}
	}
	counts := f.result.TechnicalCounts
	counts.Evaluations++
	if d.Fallback {
		counts.FallbackEvaluations++
	}
	if d.Reason != "" {
		counts.Reasons[d.Reason]++
	}
	for _, name := range d.MissingFeatures {
		counts.MissingFeatures[name]++
	}
	t.memory = copyNumbers(d.Memory)
	x := t.context.UpdatedAt
	t.previousAt = &x
	oldFloor, armStarted := f.result.StopPoints, false
	// ----------------------------------------
	// A15の許可判断を含む動的TPは、技術政策だけこの段階で判定します。
	if d.TakeProfitPoints != nil && view.GainPoints >= *d.TakeProfitPoints {
		counts.TakeProfitRequests++
		f.recordDecision(q, d, threshold, false, oldFloor)
		f.request("take_profit", q, false)
		return nil
	}
	if !f.result.Armed && view.GainPoints >= threshold && 100*view.GainPoints-f.result.FeeYen > 0 {
		f.result.Armed = true
		armStarted = true
		f.result.ArmQuote = quotePtr(q)
		counts.ArmStarts++
	}
	if f.result.Armed {
		f.result.StopPoints = math.Max(f.result.StopPoints, 0)
		if d.FloorPoints != nil {
			f.result.StopPoints = math.Max(f.result.StopPoints, *d.FloorPoints)
		}
	}
	if oldFloor != f.result.StopPoints {
		counts.FloorChanges++
	}
	if d.Record || armStarted || (oldFloor != f.result.StopPoints && view.FeatureChanged) || d.ExitReason != "" || (d.Fallback && counts.FallbackEvaluations == 1) {
		f.recordDecision(q, d, threshold, armStarted, oldFloor)
	}
	if view.GainPoints <= f.result.StopPoints {
		f.request("stop_after_update", q, true)
	} else if d.ExitReason != "" {
		counts.TechnicalRequests++
		f.request("technical:"+d.ExitReason, q, false)
	}
	return nil
}

// recordDecision は実際に使った特徴と返済提案を小票へ残します。
//
// 引数: q Quote、d Decision、threshold float64、arm bool、oldFloor float64。
// 返り値: なし。全原行の特徴値は重複保存しません。
func (f *FSM) recordDecision(q Quote, d Decision, threshold float64, arm bool, oldFloor float64) {
	trace := TechnicalTrace{At: Stamp{Time: q.Time, Index: q.Index, SourceLine: q.SourceLine}, FeatureAt: f.technical.context.UpdatedAt, Reason: d.Reason, ArmThresholdPoints: threshold, ArmStarted: arm, PreviousFloor: oldFloor, AppliedFloor: f.result.StopPoints, ExitReason: d.ExitReason, UsedFeatures: append([]string(nil), d.UsedFeatures...), RefIDs: append([]string(nil), d.RefIDs...), Fallback: d.Fallback, MissingFeatures: append([]string(nil), d.MissingFeatures...)}
	if d.FloorPoints != nil {
		trace.ProposedFloor = floatPtr(*d.FloorPoints)
	}
	if d.TakeProfitPoints != nil {
		trace.TakeProfitPoints = floatPtr(*d.TakeProfitPoints)
	}
	f.result.TechnicalTrace = append(f.result.TechnicalTrace, trace)
}

// normalizeContext は未来・scope違い・値矛盾を拒否し鮮度を適用します。
//
// 引数: input FeatureContext、q Quote、scope Scope。
// 返り値: FeatureContext 型の独立コピーと error。期限等号は未知です。
func normalizeContext(input FeatureContext, q Quote, scope Scope) (FeatureContext, error) {
	if input.Session != scope.Session || input.Contract != scope.Contract || !validStamp(input.At) || input.At.Time > q.Time || input.At.Index > q.Index || input.At.SourceLine > q.SourceLine {
		return FeatureContext{}, fmt.Errorf("技術特徴のscope又は当時時計が不正です")
	}
	if input.UpdatedAt != (Stamp{}) && (!validStamp(input.UpdatedAt) || input.UpdatedAt.Time > q.Time || input.UpdatedAt.Index > q.Index || input.UpdatedAt.SourceLine > q.SourceLine) {
		return FeatureContext{}, fmt.Errorf("技術特徴の最終更新時計が未来又は不正です")
	}
	out := cloneContext(input)
	for i, update := range out.Updates {
		if update.ID == "" || !validStamp(update.At) || update.At != input.At || update.WidthSeconds <= 0 {
			return FeatureContext{}, fmt.Errorf("特徴更新の当時時計又はIDが不正です")
		}
		checked, err := normalizeContext(FeatureContext{Session: input.Session, Contract: input.Contract, At: update.At, UpdatedAt: update.At, Values: update.Values, Refs: update.Refs}, q, scope)
		if err != nil {
			return FeatureContext{}, fmt.Errorf("特徴更新:%w", err)
		}
		update.Values = checked.Values
		out.Updates[i] = update
	}
	ids := map[string]bool{}
	for _, ref := range out.Refs {
		if ref.ID == "" || ids[ref.ID] || ref.Session == "" || ref.Contract != scope.Contract || ref.WidthSeconds <= 0 || !finite(ref.Start) || !finite(ref.End) || ref.End <= ref.Start || !finite(ref.AvailableAt) || ref.AvailableAt < ref.End || ref.End > q.Time || ref.AvailableAt > q.Time || !validStamp(ref.Stamp) || ref.Stamp.Time > q.Time || ref.Stamp.Time < ref.AvailableAt {
			return FeatureContext{}, fmt.Errorf("技術特徴の参照が不正です:%s", ref.ID)
		}
		if ref.Session == scope.Session && (ref.Stamp.Index > q.Index || ref.Stamp.SourceLine > q.SourceLine) {
			return FeatureContext{}, fmt.Errorf("技術特徴に未来の当場原行があります:%s", ref.ID)
		}
		ids[ref.ID] = true
	}
	for name, value := range out.Values {
		if name == "" || (value.Known && (value.Value == nil || !finite(*value.Value))) || (!value.Known && value.Value != nil) || (value.ValidUntil != nil && !finite(*value.ValidUntil)) {
			return FeatureContext{}, fmt.Errorf("特徴の値と既知性が矛盾します:%s", name)
		}
		for _, id := range value.RefIDs {
			if !ids[id] {
				return FeatureContext{}, fmt.Errorf("特徴の由来IDがありません:%s", id)
			}
		}
		if value.ValidUntil != nil && q.Time >= *value.ValidUntil {
			value.Known, value.Value = false, nil
			out.Values[name] = value
		}
	}
	return out, nil
}

// cloneContext はControllerによる呼出し元の参照変更を防ぎます。
//
// 引数: input FeatureContext。
// 返り値: FeatureContext 型の独立コピー。
func cloneContext(input FeatureContext) FeatureContext {
	out := input
	out.Refs = append([]FeatureRef(nil), input.Refs...)
	if input.Updates != nil {
		out.Updates = make([]features.FeatureUpdate, len(input.Updates))
	}
	for i, update := range input.Updates {
		update.Values = cloneContext(FeatureContext{Values: update.Values}).Values
		update.Refs = append([]FeatureRef(nil), update.Refs...)
		out.Updates[i] = update
	}
	out.Values = make(map[string]FeatureValue, len(input.Values))
	for key, value := range input.Values {
		value.RefIDs = append([]string(nil), value.RefIDs...)
		if value.Value != nil {
			value.Value = floatPtr(*value.Value)
		}
		if value.ValidUntil != nil {
			value.ValidUntil = floatPtr(*value.ValidUntil)
		}
		out.Values[key] = value
	}
	return out
}

// copyNumbers は政策の小さい状態をコピーします。
//
// 引数: input map[string]float64。
// 返り値: map[string]float64 型の独立コピー。
func copyNumbers(input map[string]float64) map[string]float64 {
	out := make(map[string]float64, len(input))
	for key, value := range input {
		out[key] = value
	}
	return out
}

// validStamp は有限の価格時計と有効な原行番号を確認します。
//
// 引数: at Stamp。
// 返り値: bool 型の妥当性。
func validStamp(at Stamp) bool {
	return finite(at.Time) && at.Index >= 0 && at.SourceLine > 0
}
