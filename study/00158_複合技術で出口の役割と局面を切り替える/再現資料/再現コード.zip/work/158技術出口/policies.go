package technicalexit158

import (
	"fmt"
	"math"
	"sort"
	"strings"

	features "features158"
)

// PolicyCatalog はRootが事前固定した16技術familyを返します。
//
// 引数: なし。
// 返り値: []Definition 型。主条件の微調整候補を追加しません。
func makePolicyCatalog() []Definition {
	names := []string{"CHAND_MOM", "KASE_VAR", "SUPER_CONFIRM", "SAR_ACCEL", "SWING_CONFIRM", "BB_CONTRACT", "VOL_DIVERGE", "VWAP_REVERT", "SPIKE_CONFIRM", "PROGRESS_CLOCK", "PROFIT_BUDGET", "VOL_SHOCK", "CUSUM_FAILURE", "PERSISTENT_CONSENSUS", "EXTEND_PERMISSION", "REGIME_SWITCH"}
	out := []Definition{}
	for i, family := range names {
		out = append(out, Definition{ID: fmt.Sprintf("A%02d_%s", i+1, family), Family: family, ArmThresholdPoints: 125, Parameters: map[string]float64{"initial_sl": 125, "base_width": 100, "base_tp": 250}})
	}
	return out
}

var policyDefinitions = makePolicyCatalog()

// PolicyCatalog は固定政策定義の独立コピーを返します。
//
// 引数: なし。
// 返り値: []Definition 型。呼出し元の変更は内部政策へ届きません。
func PolicyCatalog() []Definition {
	out := make([]Definition, len(policyDefinitions))
	for i, definition := range policyDefinitions {
		definition.Parameters = copyNumbers(definition.Parameters)
		out[i] = definition
	}
	return out
}

// Configurations は固定19政策と期限・約定・費用の152条件を返します。
//
// 引数: なし。
// 返り値: []Config 型。主と感度の条件を結果後に交換しません。
func Configurations() []Config {
	out := BaselineConfigurations()
	for _, definition := range policyDefinitions {
		for _, horizon := range []string{"H60", "SESSION"} {
			for _, delay := range []string{"D0", "D1"} {
				for _, cost := range []string{"C0", "C5"} {
					fee := 77.0
					if cost == "C5" {
						fee = 1077
					}
					out = append(out, Config{ID: definition.ID + "/" + horizon + "/" + delay + "/" + cost, Policy: definition.ID, Horizon: horizon, Delay: delay, Cost: cost, FeeYen: fee})
				}
			}
		}
	}
	return out
}

// definitionFor は固定技術政策をIDで照合します。
//
// 引数: id string。
// 返り値: Definition 型と bool 型の存在。旧対照はfalseです。
func definitionFor(id string) (Definition, bool) {
	for _, definition := range policyDefinitions {
		if definition.ID == id {
			return definition, true
		}
	}
	return Definition{}, false
}

// PolicyFeatureKeys は誤字を未知と混同しないため参照名の和集合を返します。
//
// 引数: なし。
// 返り値: []string 型の昇順。任意条件の参照名も含めます。
func PolicyFeatureKeys() []string {
	names := map[string]bool{}
	for _, definition := range policyDefinitions {
		for _, side := range []int{1, -1} {
			for _, name := range requirements(definition.ID[:3], side) {
				names[name] = true
			}
		}
	}
	for _, name := range []string{"m1.atr14", "m1.session_vwap_proxy", "m1.zscore", "m1.cmf20", "m1.er10", "m15.adx", "m5.hist"} {
		names[name] = true
	}
	for _, width := range []string{"m5", "m15", "m30"} {
		for _, name := range []string{"gap", "ema21_delta"} {
			names[width+"."+name] = true
		}
	}
	out := []string{}
	for name := range names {
		out = append(out, name)
	}
	sort.Strings(out)
	return out
}

// Builtin は固定familyの判断器を返します。
//
// 引数: id string 型のA01〜A16。
// 返り値: Controller 型と error。入口判断・ラベルを受けません。
func Builtin(id string) (Controller, error) {
	for _, definition := range policyDefinitions {
		if definition.ID == id {
			return builtinController{id: definition.ID[:3]}, nil
		}
	}
	return nil, fmt.Errorf("未固定の技術familyです:%s", id)
}

type builtinController struct{ id string }

// featureNumber は既知有限値だけを取り出します。
//
// 引数: context FeatureContext、name string。
// 返り値: float64 型の値と bool 型の既知性。0は既知0のままです。
func featureNumber(context FeatureContext, name string) (float64, bool) {
	v, ok := context.Values[name]
	if !ok || !v.Known || v.Value == nil || !finite(*v.Value) {
		return 0, false
	}
	return *v.Value, true
}

// requirements はfamily固有に必要な観測を返します。
//
// 引数: id string、side int。
// 返り値: []string 型。strongの未知false・entry例外はここへ混ぜません。
func buildRequirements(id string, side int) []string {
	weak := []string{"m1.hist_delta", "m1.hist", "m1.close", "m1.ema8"}
	br := "m1.prior_low5"
	forward20, swing10 := "m1.prior_high20", "m1.prior_low10"
	if side < 0 {
		br, forward20, swing10 = "m1.prior_high5", "m1.prior_low20", "m1.prior_high10"
	}
	extra := map[string][]string{
		"A01": {"m1.atr14", br},
		"A02": {"m1.trd_mean20", "m1.trd_sd20", "m1.cmf20", "m1.obv_delta5"},
		"A03": {"m1.atr14", "m1.supertrend_line", "m1.supertrend_direction", br},
		"A04": {"m1.atr14", "m1.psar_line", "m1.psar_direction", "m1.di_difference"},
		"A05": {"m1.atr14", swing10, br, "m1.cmf20", "m1.obv_delta5"},
		"A06": {"m1.atr14", "m1.bb_width", "m1.previous_bb_width", "m1.er10"},
		"A07": {forward20, "m1.cmf20", "m1.obv_delta5"},
		"A08": {},
		"A09": {"m1.open", "m1.high", "m1.low", "m1.atr14", "m1.rvol"},
		"A10": {"m1.er10", br},
		"A11": {"m1.atr14", br},
		"A12": {"m1.open", "m1.previous_atr14", "m1.tr", "m1.rvol", br},
		"A13": {"m1.previous_atr14", "m1.previous_close", br},
		"A14": {br, "m1.cmf20", "m1.obv_delta5", "m1.di_difference", "m1.bb_width", "m1.previous_bb_width"},
		"A15": {},
		"A16": {"m1.atr14", "m1.er10", "m1.chop14", br, "m1.cmf20", "m1.obv_delta5"},
	}
	if id == "A15" {
		return nil
	}
	return append(append([]string{}, weak...), extra[id]...)
}

type requirementKey struct {
	id   string
	side int
}

var requirementSets = makeRequirementSets()

// makeRequirementSets は固定参照名を初期化時だけ作ります。
//
// 引数: なし。
// 返り値: map[requirementKey][]string 型の不変一覧。
func makeRequirementSets() map[requirementKey][]string {
	out := map[requirementKey][]string{}
	for _, definition := range policyDefinitions {
		for _, side := range []int{1, -1} {
			out[requirementKey{definition.ID[:3], side}] = buildRequirements(definition.ID[:3], side)
		}
	}
	return out
}

// requirements は政策別の不変参照名を返します。
//
// 引数: id string、side int。
// 返り値: []string 型。政策側はこのsliceを変更しません。
func requirements(id string, side int) []string { return requirementSets[requirementKey{id, side}] }

// fallbackDecision は必要観測が未知の行だけC1の式へ戻します。
//
// 引数: view StateView、memory map[string]float64、missing []string。
// 返り値: Decision 型。既存床はFSMが保持するためfallbackで緩みません。
func fallbackDecision(view StateView, memory map[string]float64, missing []string) Decision {
	return Decision{ArmThresholdPoints: floatPtr(125), FloorPoints: floatPtr(view.PeakPoints - 100), TakeProfitPoints: floatPtr(250), Memory: memory, Fallback: true, MissingFeatures: missing, Reason: "必要観測未知のC1fallback"}
}

// strongBackground は三幅の方向と15分強度・5分勢いを合わせます。
//
// 引数: context FeatureContext、side int。
// 返り値: bool 型。必要値未知はfalseで、将来値で補いません。
func strongBackground(context FeatureContext, side int) bool {
	s := float64(side)
	for _, width := range []string{"m5", "m15", "m30"} {
		for _, name := range []string{"gap", "ema21_delta"} {
			v, known := featureNumber(context, width+"."+name)
			if !known || s*v <= 0 {
				return false
			}
		}
	}
	adx, ka := featureNumber(context, "m15.adx")
	hist, kh := featureNumber(context, "m5.hist")
	return ka && kh && adx >= 20 && s*hist > 0
}

// clamp は値を事前固定した閉区間へ制限します。
//
// 引数: value/lower/upper float64。
// 返り値: float64 型の制限値。
func clamp(value, lower, upper float64) float64 {
	return math.Max(lower, math.Min(upper, value))
}

// Evaluate は当時の値と小さい政策状態から固定式を計算します。
//
// 引数: view StateView、context FeatureContext。
// 返り値: Decision 型と error。全可変床はFSMがarm後だけ適用します。
func (controller builtinController) Evaluate(view StateView, context FeatureContext) (Decision, error) {
	memory := copyNumbers(view.Memory)
	s := float64(view.Side)
	value := func(name string) float64 { v, _ := featureNumber(context, name); return v }
	needed := requirements(controller.id, view.Side)
	missing := []string{}
	for _, name := range needed {
		if _, known := featureNumber(context, name); !known {
			missing = append(missing, name)
		}
	}
	for _, name := range []string{"m1.atr14", "m1.previous_atr14"} {
		for _, key := range needed {
			if key == name && value(name) <= 0 {
				missing = append(missing, name+":正値条件")
			}
		}
	}
	if controller.id == "A10" {
		if view.EntryContext == nil {
			missing = append(missing, "entry.m1.atr14")
		} else if atr, known := featureNumber(*view.EntryContext, "m1.atr14"); !known || atr <= 0 {
			missing = append(missing, "entry.m1.atr14")
		}
	}
	// ----------------------------------------
	// 履歴依存は閉鎖足イベントだけで進め、Raw反復で増やしません。
	if controller.id == "A09" || controller.id == "A13" || controller.id == "A14" {
		for _, update := range context.Updates {
			if update.WidthSeconds != 60 || len(update.Refs) == 0 {
				continue
			}
			end := update.Refs[len(update.Refs)-1].End
			for _, ref := range update.Refs {
				if ref.WidthSeconds == 60 && ref.ID == update.ID {
					end = ref.End
				}
			}
			if previous, exists := memory["last_m1_end"]; exists && end <= previous {
				continue
			}
			if previous, exists := memory["last_m1_end"]; exists && end != previous+60 {
				memory["cusum"], memory["consensus_streak"], memory["spike_flag"] = 0, 0, 0
			}
			memory["last_m1_end"] = end
			current := context
			current.Values = make(map[string]FeatureValue, len(context.Values)+len(update.Values))
			for key, v := range context.Values {
				if !strings.HasPrefix(key, "m1.") {
					current.Values[key] = v
				}
			}
			for key, v := range update.Values {
				current.Values[key] = v
			}
			processMinute(controller.id, view, current, update, memory)
		}
	}
	if len(missing) > 0 {
		sort.Strings(missing)
		if controller.id == "A13" {
			memory["cusum"] = 0
		}
		if controller.id == "A14" {
			memory["consensus_streak"] = 0
		}
		return fallbackDecision(view, memory, missing), nil
	}
	weak := s*value("m1.hist_delta") < 0 && (s*value("m1.hist") <= 0 || s*(value("m1.close")-value("m1.ema8")) < 0)
	broken := (view.Side > 0 && value("m1.close") < value("m1.prior_low5")) || (view.Side < 0 && value("m1.close") > value("m1.prior_high5"))
	volContra := s*value("m1.cmf20") < 0 && s*value("m1.obv_delta5") < 0
	strong := false
	switch controller.id {
	case "A06", "A08", "A11", "A15", "A16":
		strong = strongBackground(context, view.Side)
	}
	atr := value("m1.atr14")
	width, arm := 100.0, 125.0
	tp := floatPtr(250)
	var structuralFloor *float64
	exit, reason := "", "基本幅100・TP250"
	switch controller.id {
	case "A01":
		tp, width = nil, clamp(3*atr, 50, 200)
		if weak && broken {
			width, reason = clamp(1.5*atr, 25, 75), "勢いと構造の否定で幅縮小"
		}
	case "A02":
		tp = nil
		if view.EntryContext != nil {
			if entryATR, known := featureNumber(*view.EntryContext, "m1.atr14"); known && entryATR > 0 {
				arm = clamp(2*entryATR, 50, 125)
			}
		}
		width = clamp(value("m1.trd_mean20")+1.64*value("m1.trd_sd20"), 50, 200)
		if weak && volContra {
			width, reason = clamp(value("m1.trd_mean20")+value("m1.trd_sd20"), 25, 100), "TR偏差と逆数量で幅縮小"
		}
	case "A03":
		tp, width = nil, clamp(3*atr, 75, 200)
		if s*value("m1.supertrend_direction") > 0 && (weak || broken) {
			structuralFloor = floatPtr(s * (value("m1.supertrend_line") - view.EntryPrice))
			reason = "同方向ST線と勢い又は構造否定"
		}
		if s*value("m1.supertrend_direction") < 0 && weak && broken {
			exit = "ST逆転と勢い構造否定"
		}
	case "A04":
		tp, width = nil, clamp(3*atr, 75, 200)
		if s*value("m1.psar_direction") > 0 && weak && s*value("m1.di_difference") < 0 {
			structuralFloor = floatPtr(s * (value("m1.psar_line") - view.EntryPrice))
			reason = "SAR線と勢いDI否定"
		}
		if s*value("m1.psar_direction") < 0 && weak && s*value("m1.di_difference") < 0 {
			exit = "SAR逆転と勢いDI否定"
		}
	case "A05":
		if weak || volContra {
			line := value("m1.prior_low10") - .5*atr
			if view.Side < 0 {
				line = value("m1.prior_high10") + .5*atr
			}
			structuralFloor = floatPtr(math.Min(s*(line-view.EntryPrice), view.GainPoints-5))
			reason = "既知構造端と勢い又は数量否定"
		}
		if broken && weak && volContra && view.PeakPoints >= 50 {
			exit = "構造勢い数量の三重否定"
		}
	case "A06":
		if value("m1.bb_width") <= .9*value("m1.previous_bb_width") && weak && value("m1.er10") < .35 {
			width, reason = clamp(1.5*atr, 25, 60), "BB収縮と弱い効率"
		}
		if value("m1.bb_width") > value("m1.previous_bb_width") && strong {
			width, tp, reason = clamp(3*atr, 100, 200), nil, "BB拡大と上位支持で延伸"
		}
	case "A07":
		newHigh := (view.Side > 0 && value("m1.close") > value("m1.prior_high20")) || (view.Side < 0 && value("m1.close") < value("m1.prior_low20"))
		if volContra && weak {
			width, reason = 50, "数量乖離と勢い失速"
		}
		if newHigh && volContra && weak && view.PeakPoints >= 50 {
			exit = "新値と数量勢いの乖離"
		}
	case "A08":
		tp = floatPtr(125)
		if view.EntryContext != nil {
			if vwap, known := featureNumber(*view.EntryContext, "m1.session_vwap_proxy"); known {
				distance := s * (vwap - view.EntryPrice)
				if distance >= 50 && distance <= 250 {
					tp = floatPtr(distance)
					if view.GainPoints >= distance && weak {
						exit = "凍結近似VWAP到達と失速"
					}
				}
			}
		}
		if strong {
			tp = floatPtr(250)
		}
	case "A09":
		if memory["spike_failed"] == 1 && weak && view.PeakPoints >= 50 {
			exit = "急伸足実体中点の後足否定"
		}
	case "A10":
		entryATR, _ := featureNumber(*view.EntryContext, "m1.atr14")
		if view.HeldSeconds >= 900 && view.PeakPoints < .75*entryATR && broken && weak {
			exit = "15分の進行不足と構造否定"
		}
		if view.PeakPoints >= 50 && view.Current.Time-view.PeakTime >= 480 && value("m1.er10") < .3 && weak {
			width, arm, reason = 50, 50, "新峰8分停止と低効率"
		}
	case "A11":
		tp = nil
		if strong {
			width = math.Max(100, .5*view.PeakPoints)
		} else {
			width = clamp(.25*view.PeakPoints+atr, 25, 100)
		}
		if weak && broken {
			width, reason = clamp(atr, 25, 60), "失速構造否定でMFE予算縮小"
		}
	case "A12":
		previousATR := value("m1.previous_atr14")
		if s*(value("m1.close")-value("m1.open")) <= -previousATR && value("m1.tr") >= 2*previousATR && value("m1.rvol") >= 1.5 && broken {
			exit = "逆向き値幅数量ショック"
		}
	case "A13":
		if memory["cusum"] >= 3 && broken && weak {
			exit = "累積失速と構造否定"
		}
	case "A14":
		votes := voteCount(context, view.Side)
		if votes >= 2 && view.PeakPoints >= 50 {
			width, reason = 50, "複合二票で起動後幅縮小"
		}
		if memory["consensus_streak"] >= 2 {
			exit = "三票以上が二足連続"
		}
	case "A15":
		if memory["extend_decided"] == 0 && view.GainPoints >= 125 {
			cmf, kc := featureNumber(context, "m1.cmf20")
			er, ke := featureNumber(context, "m1.er10")
			memory["extend_decided"] = 1
			if strong && kc && ke && s*cmf > 0 && er >= .35 {
				memory["extend_permission"] = 1
			}
			reason = "初回125の延伸許可判定"
		}
		tp = floatPtr(125)
		if memory["extend_permission"] == 1 {
			tp = floatPtr(250)
		}
	case "A16":
		if strong && value("m1.er10") >= .35 {
			tp, width, reason = nil, clamp(3*atr, 100, 200), "進行環境"
		} else if value("m1.chop14") >= 61.8 || value("m1.er10") < .25 {
			tp, width, reason = floatPtr(125), clamp(1.5*atr, 25, 75), "往復環境"
		}
		if weak && broken && volContra && view.PeakPoints >= 50 {
			exit = "環境内の構造勢い数量否定"
		}
	}
	floor := view.PeakPoints - width
	if structuralFloor != nil {
		floor = *structuralFloor
	}
	d := Decision{ArmThresholdPoints: floatPtr(arm), FloorPoints: floatPtr(floor), TakeProfitPoints: tp, ExitReason: exit, Reason: reason, Memory: memory, UsedFeatures: needed}
	if controller.id == "A15" {
		d.Record = memory["extend_decided"] != view.Memory["extend_decided"]
	}
	return d, nil
}

// voteCount は5つの独立観測条件の成立数を数えます。
//
// 引数: context FeatureContext、side int。
// 返り値: int 型。未知条件は票を足さず、呼出し側がfallbackを扱います。
func voteCount(context FeatureContext, side int) int {
	v := func(name string) float64 { x, _ := featureNumber(context, name); return x }
	s := float64(side)
	votes := 0
	if (side > 0 && v("m1.close") < v("m1.prior_low5")) || (side < 0 && v("m1.close") > v("m1.prior_high5")) {
		votes++
	}
	if s*v("m1.hist_delta") < 0 && (s*v("m1.hist") <= 0 || s*(v("m1.close")-v("m1.ema8")) < 0) {
		votes++
	}
	if s*v("m1.cmf20") < 0 && s*v("m1.obv_delta5") < 0 {
		votes++
	}
	if s*v("m1.di_difference") < 0 {
		votes++
	}
	if v("m1.bb_width") <= .9*v("m1.previous_bb_width") {
		votes++
	}
	return votes
}

// processMinute は取得後の実際の1分配送イベントだけを処理します。
//
// 引数: id string、view StateView、context FeatureContext、update FeatureUpdate、memory map[string]float64。
// 返り値: なし。未知は状態をresetし観測0へ補完しません。
func processMinute(id string, view StateView, context FeatureContext, update features.FeatureUpdate, memory map[string]float64) {
	s := float64(view.Side)
	v := func(name string) (float64, bool) { return featureNumber(context, name) }
	if id == "A13" {
		close, kc := v("m1.close")
		previous, kp := v("m1.previous_close")
		atr, ka := v("m1.previous_atr14")
		if !update.PriceKnown || !kc || !kp || !ka || atr <= 0 {
			memory["cusum"] = 0
		} else {
			memory["cusum"] = math.Max(0, memory["cusum"]-s*(close-previous)/atr-.25)
		}
	}
	if id == "A14" {
		known := update.PriceKnown
		for _, name := range requirements("A14", view.Side) {
			if _, ok := v(name); !ok {
				known = false
			}
		}
		if known && voteCount(context, view.Side) >= 3 {
			memory["consensus_streak"]++
		} else {
			memory["consensus_streak"] = 0
		}
	}
	if id == "A09" {
		close, kc := v("m1.close")
		open, ko := v("m1.open")
		high, kh := v("m1.high")
		low, kl := v("m1.low")
		atr, ka := v("m1.atr14")
		rvol, kv := v("m1.rvol")
		z, kz := v("m1.zscore")
		if !update.PriceKnown || !kc || !ko || !kh || !kl || !ka || !kv || atr <= 0 || high <= low {
			memory["spike_flag"], memory["spike_failed"] = 0, 0
			return
		}
		if memory["spike_flag"] == 1 && s*(close-memory["spike_body_mid"]) < 0 {
			memory["spike_failed"] = 1
		}
		wick := high - math.Max(open, close)
		if view.Side < 0 {
			wick = math.Min(open, close) - low
		}
		bodyStrong := s*(close-open) >= 1.5*atr
		if (bodyStrong || (kz && s*z >= 2)) && rvol >= 1.5 && wick/(high-low) >= .35 {
			memory["spike_flag"], memory["spike_body_mid"], memory["spike_failed"] = 1, (open+close)/2, 0
		}
	}
}
