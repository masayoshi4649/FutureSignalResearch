# 158 技術複合出口エンジン

Rootが固定した19政策を同じ157の837物理case・924所属・73場へ適用する。入口・方向を変更せず、ラベル・学習・新Rawを読まない。自然再生はRootのF0固定と実行通知後だけ。特徴は一度生成した共有gzipを再用し、再計算・複写しない。

正本は `study/00158_複合技術で出口の役割と局面を切り替える/実行条件.md`（SHA f32efc55b5fc114534b601b981e3c961d12037e5b5462d71769634402789cc17）、同 `候補の固定.json`（e7e8ef7fd2a714b145cbb7c0fe280a391804247ec5a88db872f88a1be45734c7）。16familyの式と境界はこの正本に従う。

## 実動とAPI

moduleは `technicalexit158`。`New` は157固定対照、`NewTechnical` は初期SL125の技術出口、`Step` は検査付き純API、`StepPrepared` は共通cursorで一度検査した同原行特徴を全状態へ共有するAPI。`PolicyCatalog` は16定義、`Configurations` は19×2期限×2遅延×2費用の152条件。`PolicyFeatureKeys` とfeature manifestのcatalogの差はCLIを停止させる。存在するkeyの当時未知・鮮度切れと誤字を区別する。

Root金融前F0へ固定後のコマンド（repo rootを作業場所にする）：

```powershell
& 'work/158技術出口/技術出口再生.exe' `
 --input 'inputs/00157_固定入口と価格経路/固定入口入力.json' --input-sha256 <固定入口SHA> `
 --manifest 'inputs/00157_固定入口と価格経路/価格テープ/価格テープの確認.json' --manifest-sha256 <価格manifestSHA> `
 --features 'inputs/00158_複合技術特徴/特徴/特徴の確認.json' --features-sha256 <特徴manifestSHA> `
 --spec 'study/00158_複合技術で出口の役割と局面を切り替える/実行条件.md' --spec-sha256 <条件SHA> `
 --policies 'study/00158_複合技術で出口の役割と局面を切り替える/候補の固定.json' --policies-sha256 <政策SHA> `
 --execute-after-f0 <Root金融前F0path> --f0-sha256 <F0SHA> --output <未作成の出口結果.json.gz>
```

`--describe` は入力を開かず政策・152条件・参照名だけを表示する。`--controls-only` は旧3対照だけを再生する。全源のF0内容検査はRoot運転部が担当し、このCLIはF0そのものの物理SHAを前後照合する。

## 状態・因果・出力

- 157の品質/phase→既予約fill→期限timer→旧床を維持する。旧対照は旧TP/追尾順のまま。技術のみ旧床後に当時Planを決め、動的TP→必須arm/新床再判定→明示直接退出。A15の延伸許可をTP125より前に決める。
- D1は要求+1秒かつ後原行、TTL30秒等号可、予約は反発しても取消さない。期限要求時計は期限自身。欠測・EOF・未約定は未知、後から復旧しない。床は不利に緩めない。
- 新政策は事前閾値と費用後正益を両方満たす時に必須arm、以後床>=0。arm前は−125を維持し、明記した早期直接退出だけを許す。A10の閾値50も現在g>=50が必要。E0即時起動は旧固定対照だけ。
- Atは現在q、UpdatedAtは最後の特徴更新。各updateは元配送時計で未知/鮮度を判定し、取得より後だけを状態へ渡す。不正常BBOの足更新は次正常まで保持して一度処理。現在採否は現在qの最新値で別に判定する。後の値を過去updateへ複写しない。CUSUM・継続票・spikeは1分eventで進め、Raw反復で増やさない。
- 不足時は明示C1fallback（同じ状態のarm125/峰−100/TP250）。既存床はfallbackでも緩めない。strong未知=false、A02のentryATR未知=125、A08のentryVWAP未知/逆側/範囲外=TP125、A15未知=不許可は固定例外。entryATRとentryVWAPは取得時に凍結する。
- A08のVWAP到達は有効な順側entry距離50〜250のときだけ清算BBOで判定し、現在の動くVWAPへ交換しない。A12はbody/TRともpreviousATR基準。A14 BB収縮は<=.9previousWidth。
- 結果は157同様 `top.configurations/scenes[].cases[].results[]` のflat schema、trial158/schema `technical_exit_results_v1`。旧対照Resultは157全key同体。技術結果に `technical_counts` と `technical_trace` を追加する。
- countsは評価/fallback/床変更/起動/技術要求/TP要求/理由/未知名を全計数。traceは起動、特徴更新時の床変更、明示要求、初回fallbackなどの小票。通常Rawの新峰ごとの床変更はcountsで保持し全特徴を重複転記しない。未発動を有効と呼ばない。
- 価格/特徴gzipは全CRC/物理SHA/解凍SHA/件数/前後statを確認してからpartialを正本へ移す。全状態退出後もテープ・特徴を完読する。

由来：`fsm.go` は157 `fsm.go` の私有複写から拡張、`replay.go` は157共通テープ再生を派生、`parent_stream.go` のcountReader/SHA形式/statは148 reader由来。旧157・148・118源は不変更。特徴数学は別作者 `features158`、このエンジンは共有特徴を読む側であり数学の独立検算を主張しない。作者人工は旧3対照1,920経路全Result同体、売買鏡像・起動/非緩和・予約/期限・同Raw別足・未知/CRC・全152の小型結合を対象とする。
