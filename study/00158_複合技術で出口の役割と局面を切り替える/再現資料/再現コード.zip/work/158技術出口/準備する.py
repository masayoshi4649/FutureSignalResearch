"""158出口の人工・構文・ビルドと小さい接続metadataを確認する。"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
FORMAL = ROOT / "study/00158_複合技術で出口の役割と局面を切り替える"
FEATURES = ROOT / "inputs/00158_複合技術特徴/特徴/特徴の確認.json"
EXPECTED = {
    FORMAL / "実行条件.md": "f32efc55b5fc114534b601b981e3c961d12037e5b5462d71769634402789cc17",
    FORMAL / "候補の固定.json": "e7e8ef7fd2a714b145cbb7c0fe280a391804247ec5a88db872f88a1be45734c7",
    FEATURES: "a6dce32eb35102d95f44647d0a10811bf13ed6e36f46b08ef0956c52bb783d11",
}


def sha(path: Path) -> str:
    """物理SHAを計算する。

    引数: path (Path) 対象の小さい源。
    返り値: str 型のSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(arguments: list[str]) -> dict:
    """子出力をUTF-8 strictで取得する。

    引数: arguments (list[str]) シェルを介さない引数列。
    返り値: dict 型の成否と両出力。自然再生を呼ばない。
    """
    result = subprocess.run(arguments, cwd=HERE, env={**os.environ, "PYTHONUTF8": "1"}, capture_output=True, text=True, encoding="utf-8", errors="strict")
    if result.returncode or "\ufffd" in result.stdout + result.stderr:
        raise RuntimeError({"arguments": arguments, "code": result.returncode, "stdout": result.stdout, "stderr": result.stderr})
    return {"arguments": arguments, "code": result.returncode, "stdout": result.stdout, "stderr": result.stderr}


def main() -> None:
    """準備だけを固定し自然入力のイベント本文へは進まない。

    引数: なし。
    返り値: None。成功票と停止票を保存する。
    """
    local = sorted([*HERE.glob("*.go"), HERE / "go.mod", HERE / "README.md", HERE / "準備する.py", *HERE.glob("cmd/**/*.go")])
    dependencies = []
    for folder in ["157出口政策の再生", "157固定入口と価格経路", "158技術特徴", "118複数技法の入口条件"]:
        directory = ROOT / "work" / folder
        dependencies.extend(sorted([*directory.glob("*.go"), directory / "go.mod"]))
    sources = list(dict.fromkeys([*local, *dependencies, *EXPECTED]))
    before = {p.relative_to(ROOT).as_posix(): sha(p) for p in sources}
    for path, expected in EXPECTED.items():
        assert sha(path) == expected, str(path)
    logs = [run(["go", "test", "-count=1", "-v", "./..."]), run(["go", "vet", "./..."]), run(["go", "build", "-o", "技術出口再生.exe", "./cmd/replay"])]
    describe = run([str(HERE / "技術出口再生.exe"), "--describe"])
    schema = json.loads(describe["stdout"])
    manifest = json.loads(FEATURES.read_text(encoding="utf-8-sig"))
    book = json.loads((FORMAL / "候補の固定.json").read_text(encoding="utf-8-sig"))
    actual = {r["policy"] for r in schema["configurations"]}
    assert len(schema["configurations"]) == 152 and len(actual) == 19
    assert actual == {p["id"] for p in book["政策"]}
    assert set(schema["feature_keys"]) <= set(manifest["catalog"])
    assert len(manifest["scenes"]) == 73
    assert before == {p.relative_to(ROOT).as_posix(): sha(p) for p in sources}
    proof = {"成功": True, "試行": 158, "自然再生": False, "金融本文読取": False, "特徴本文読取": False, "接続metadata読取": True, "条件数": 152, "政策数": 19, "特徴catalog数": len(manifest["catalog"]), "参照key数": len(schema["feature_keys"]), "旧対照全結果同体人工経路": 1920, "人工主群": logs[0]["stdout"].count("--- PASS:"), "ログ": logs, "CLI": {"path": "work/158技術出口/技術出口再生.exe", "sha256": sha(HERE / "技術出口再生.exe")}, "源SHA256": before, "前後同体": True}
    prepared = HERE / "準備の確認.json"
    prepared.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    stopped = {"成功": True, "試行": 158, "準備票SHA256": sha(prepared), "源SHA256": before, "exeSHA256": proof["CLI"]["sha256"], "編集停止": True, "自然実行": "Root通知後にRootが一度実行"}
    (HERE / "停止.json").write_text(json.dumps(stopped, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"成功": True, "人工主群": proof["人工主群"], "準備SHA256": sha(prepared), "停止SHA256": sha(HERE / "停止.json"), "exeSHA256": proof["CLI"]["sha256"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
