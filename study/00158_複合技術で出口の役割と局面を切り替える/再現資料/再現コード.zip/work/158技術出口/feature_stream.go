package technicalexit158

import (
	"bufio"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"os"
	"path/filepath"
	"reflect"

	features "features158"
	tape "pricetape157"
)

// FeatureScene は一度だけ生成した場別特徴イベントの参照です。
type FeatureScene struct {
	Session       string       `json:"session"`
	Contract      string       `json:"contract"`
	Start         float64      `json:"start"`
	End           float64      `json:"end"`
	ForceClose    float64      `json:"force_close"`
	ContinuousEnd float64      `json:"continuous_end"`
	Raw           tape.FileRef `json:"raw"`
	Path          string       `json:"path"`
	Bytes         int64        `json:"bytes"`
	SHA256        string       `json:"sha256"`
	DecodedSHA256 string       `json:"decoded_sha256"`
	DecodedBytes  int64        `json:"decoded_bytes"`
	Rows          int64        `json:"rows"`
}

// FeatureManifest は共通特徴生成の成功票です。
type FeatureManifest struct {
	Success bool           `json:"success"`
	Trial   int            `json:"trial"`
	Schema  string         `json:"schema"`
	Catalog []string       `json:"catalog"`
	Scenes  []FeatureScene `json:"scenes"`
}

// FeatureReadEvidence は全CRC・SHA・末尾・前後stat確認後の証跡です。
type FeatureReadEvidence struct {
	Success       bool             `json:"success"`
	Rows          int64            `json:"rows"`
	Bytes         int64            `json:"bytes"`
	DecodedBytes  int64            `json:"decoded_bytes"`
	SHA256        string           `json:"sha256"`
	DecodedSHA256 string           `json:"decoded_sha256"`
	StatBefore    map[string]int64 `json:"stat_before"`
	StatAfter     map[string]int64 `json:"stat_after"`
}

// PreparedContext は一度検査した不変特徴を同原行の全状態へ共有します。
type PreparedContext struct {
	context FeatureContext
	quote   Quote
	scope   Scope
}

// SceneRuntime は場ごとの特徴cursorを出口再生へ接続します。
type SceneRuntime struct {
	Cursor   func(Quote) (*PreparedContext, error)
	Finish   func() error
	Evidence func() FeatureReadEvidence
	Close    func()
}

// RunOptions は固定特徴・政策・F0を金融再生へ束縛します。
type RunOptions struct {
	Policies     string
	PoliciesSHA  string
	Features     string
	FeaturesSHA  string
	F0           string
	F0SHA        string
	ControlsOnly bool
}

type eventCursor struct {
	file         *os.File
	before       os.FileInfo
	path         string
	reference    FeatureScene
	buffer       *bufio.Reader
	gzip         *gzip.Reader
	physical     io.Writer
	physicalHash interface{ Sum([]byte) []byte }
	decodedHash  interface{ Sum([]byte) []byte }
	decoded      *countReader
	decoder      *json.Decoder
	next         *FeatureContext
	lastEvent    *Stamp
	current      FeatureContext
	rows         int64
	eof          bool
	evidence     FeatureReadEvidence
	nextExpiry   float64
}

// CheckFeatureCatalog はkey不存在と当時known不足を分離します。
//
// 引数: names []string 型の全特徴名。
// 返り値: error 型。固定政策が参照する名の誤字なら停止します。
func CheckFeatureCatalog(names []string) error {
	set := map[string]bool{}
	for _, name := range names {
		if name == "" || set[name] {
			return fmt.Errorf("特徴catalog重複又は空です")
		}
		set[name] = true
	}
	for _, name := range PolicyFeatureKeys() {
		if !set[name] {
			return fmt.Errorf("固定政策の参照keyがcatalogにありません:%s", name)
		}
	}
	return nil
}

// LoadFeatureManifest は小さい完成票だけを読み政策とのkey整合を確認します。
//
// 引数: path/expected string。
// 返り値: FeatureManifest 型と error。ここで特徴を再計算しません。
func LoadFeatureManifest(path, expected string) (FeatureManifest, error) {
	var out FeatureManifest
	if err := verifyRef(path, expected); err != nil {
		return out, err
	}
	body, err := os.ReadFile(path)
	if err != nil {
		return out, err
	}
	if err = json.Unmarshal(body, &out); err != nil {
		return out, err
	}
	if !out.Success || out.Trial != 158 || out.Schema != "technical_features158_v1" || len(out.Scenes) == 0 {
		return out, fmt.Errorf("特徴manifestの成功・型が不正です")
	}
	if err = CheckFeatureCatalog(out.Catalog); err != nil {
		return out, err
	}
	return out, nil
}

// NewSceneRuntime は保存特徴の場scopeを照合して逐次cursorを開きます。
//
// 引数: fixed FixedScene157、reference FeatureScene、directory string。
// 返り値: SceneRuntime 型と error。別場やRawを読みません。
func NewSceneRuntime(fixed tape.FixedScene157, reference FeatureScene, directory string) (SceneRuntime, error) {
	if reference.Session != fixed.Session || reference.Contract != fixed.Contract || reference.Start != fixed.Start || reference.End != fixed.End || reference.ForceClose != fixed.ForceClose || reference.ContinuousEnd != fixed.ContinuousEnd || reference.Raw.Path != fixed.Raw.Path || reference.Raw.SHA256 != fixed.Raw.SHA256 || reference.Bytes <= 0 || reference.DecodedBytes < 0 || reference.Rows < 0 || !shaFormat(reference.SHA256) || !shaFormat(reference.DecodedSHA256) {
		return SceneRuntime{}, fmt.Errorf("特徴イベントの場・指紋・Raw参照差")
	}
	if filepath.IsAbs(reference.Path) || filepath.Clean(reference.Path) == ".." {
		return SceneRuntime{}, fmt.Errorf("特徴イベントはmanifest親への相対pathが必要です")
	}
	path := filepath.Join(directory, reference.Path)
	file, err := os.Open(path)
	if err != nil {
		return SceneRuntime{}, err
	}
	before, err := file.Stat()
	if err != nil {
		file.Close()
		return SceneRuntime{}, err
	}
	if before.Size() != reference.Bytes {
		file.Close()
		return SceneRuntime{}, fmt.Errorf("特徴gzipサイズ差")
	}
	ph, dh := sha256.New(), sha256.New()
	buffer := bufio.NewReader(io.TeeReader(file, ph))
	z, err := gzip.NewReader(buffer)
	if err != nil {
		file.Close()
		return SceneRuntime{}, err
	}
	decoded := &countReader{reader: io.TeeReader(z, dh)}
	c := &eventCursor{file: file, before: before, path: path, reference: reference, buffer: buffer, gzip: z, physicalHash: ph, decodedHash: dh, decoded: decoded, decoder: json.NewDecoder(decoded), current: FeatureContext{Session: fixed.Session, Contract: fixed.Contract, Values: map[string]FeatureValue{}}}
	if err = c.readNext(); err != nil {
		file.Close()
		return SceneRuntime{}, err
	}
	return SceneRuntime{Cursor: c.at, Finish: c.finish, Evidence: func() FeatureReadEvidence { return c.evidence }, Close: func() { c.gzip.Close(); c.file.Close() }}, nil
}

// readNext は次票を先読みしても現在特徴へ適用しません。
//
// 引数: なし。
// 返り値: error 型。未来票の数値はatで知得するまで出口へ渡しません。
func (c *eventCursor) readNext() error {
	var next FeatureContext
	err := c.decoder.Decode(&next)
	if err == io.EOF {
		c.eof = true
		c.next = nil
		return nil
	}
	if err != nil {
		return err
	}
	if next.Session != c.reference.Session || next.Contract != c.reference.Contract || !validStamp(next.At) || next.At.Time < c.reference.Start || next.At.Time >= c.reference.ContinuousEnd {
		return fmt.Errorf("特徴票のscope又は終端差")
	}
	if c.lastEvent != nil && (next.At.Time < c.lastEvent.Time || next.At.Index <= c.lastEvent.Index || next.At.SourceLine <= c.lastEvent.SourceLine) {
		return fmt.Errorf("特徴イベント順序が不正です")
	}
	q := Quote{Time: next.At.Time, Index: next.At.Index, SourceLine: next.At.SourceLine}
	normalized, err := normalizeContext(next, q, Scope{next.Session, next.Contract})
	if err != nil {
		return err
	}
	c.next = &normalized
	x := next.At
	c.lastEvent = &x
	c.rows++
	return nil
}

// at は現在qまでに知得したeventだけを適用し当時鮮度を評価します。
//
// 引数: q Quote。
// 返り値: *PreparedContext 型と error。消費しないRawのUpdatesは空です。
func (c *eventCursor) at(q Quote) (prepared *PreparedContext, err error) {
	defer func() {
		if err != nil {
			c.gzip.Close()
			c.file.Close()
		}
	}()
	updates := []features.FeatureUpdate{}
	for c.next != nil && c.next.At.Time <= q.Time && c.next.At.Index <= q.Index && c.next.At.SourceLine <= q.SourceLine {
		current := *c.next
		updates = append(updates, current.Updates...)
		c.current = current
		c.nextExpiry = math.Inf(1)
		for _, value := range current.Values {
			if value.Known && value.ValidUntil != nil && *value.ValidUntil < c.nextExpiry {
				c.nextExpiry = *value.ValidUntil
			}
		}
		if err := c.readNext(); err != nil {
			return nil, err
		}
	}
	if c.next != nil && (c.next.At.Time < q.Time || c.next.At.Index < q.Index || c.next.At.SourceLine < q.SourceLine) {
		return nil, fmt.Errorf("特徴と価格の三時計が交差しました")
	}
	current := c.current
	current.At = Stamp{Time: q.Time, Index: q.Index, SourceLine: q.SourceLine}
	current.Updates = updates
	changed := q.Time >= c.nextExpiry
	if changed {
		c.nextExpiry = math.Inf(1)
		current.Values = make(map[string]FeatureValue, len(c.current.Values))
		for key, value := range c.current.Values {
			if value.ValidUntil != nil && q.Time >= *value.ValidUntil {
				value.Known, value.Value = false, nil
			}
			if value.Known && value.ValidUntil != nil && *value.ValidUntil < c.nextExpiry {
				c.nextExpiry = *value.ValidUntil
			}
			current.Values[key] = value
		}
		c.current.Values = current.Values
	}
	return &PreparedContext{context: current, quote: q, scope: Scope{current.Session, current.Contract}}, nil
}

// finish は消費後にもgzip/JSON末尾・CRC・SHA・前後statを検査します。
//
// 引数: なし。
// 返り値: error 型。既退出が多くても特徴ファイルを途中で成功にしません。
func (c *eventCursor) finish() error {
	defer c.file.Close()
	defer c.gzip.Close()
	if c.next != nil {
		return fmt.Errorf("価格終端まで未消費の特徴イベントがあります")
	}
	if !c.eof {
		if err := c.readNext(); err != nil {
			return err
		}
	}
	if _, err := io.Copy(io.Discard, c.gzip); err != nil {
		return err
	}
	if _, err := io.Copy(io.Discard, c.buffer); err != nil {
		return err
	}
	after, err := c.file.Stat()
	if err != nil {
		return err
	}
	pathAfter, err := os.Stat(c.path)
	if err != nil {
		return err
	}
	ph, dh := hex.EncodeToString(c.physicalHash.Sum(nil)), hex.EncodeToString(c.decodedHash.Sum(nil))
	if !os.SameFile(c.before, pathAfter) || !reflect.DeepEqual(stat(c.before), stat(after)) || !reflect.DeepEqual(stat(c.before), stat(pathAfter)) || ph != c.reference.SHA256 || dh != c.reference.DecodedSHA256 || c.decoded.count != c.reference.DecodedBytes || c.rows != c.reference.Rows {
		return fmt.Errorf("特徴gzipのCRC/SHA/件数/前後stat差")
	}
	c.evidence = FeatureReadEvidence{Success: true, Rows: c.rows, Bytes: after.Size(), DecodedBytes: c.decoded.count, SHA256: ph, DecodedSHA256: dh, StatBefore: stat(c.before), StatAfter: stat(after)}
	return nil
}

// StepPrepared は共通cursorが一度検査した特徴を共有して処理します。
//
// 引数: q Quote、prepared *PreparedContext。
// 返り値: error 型。外部から未検査の票を構築できません。
func (f *FSM) StepPrepared(q Quote, prepared *PreparedContext) error {
	if f.Done() {
		return nil
	}
	if f.technical == nil {
		return f.legacyStep(q)
	}
	if prepared == nil || prepared.quote != q || prepared.scope != f.technical.scope {
		return fmt.Errorf("共通特徴の当原行束縛差")
	}
	f.technical.context = prepared.context
	for _, update := range prepared.context.Updates {
		if update.At.Time >= f.entry.Time && update.At.Index > f.entry.Index && update.At.SourceLine > f.entry.SourceLine {
			f.technical.pendingUpdates = append(f.technical.pendingUpdates, update)
		}
	}
	return f.legacyStep(q)
}

// checkPolicyIDs はRoot固定bookの19IDを実装集合と照合します。
//
// 引数: path string。
// 返り値: error 型。結果を見て政策を追加又は除外できません。
func checkPolicyIDs(path string) error {
	var book struct {
		Trial    int `json:"試行"`
		Policies []struct {
			ID string `json:"id"`
		} `json:"政策"`
	}
	body, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	if err = json.Unmarshal(body, &book); err != nil {
		return err
	}
	expected := map[string]bool{}
	for _, config := range Configurations() {
		expected[config.Policy] = true
	}
	if book.Trial != 158 || len(book.Policies) != len(expected) {
		return fmt.Errorf("Root固定政策件数差")
	}
	for _, policy := range book.Policies {
		if !expected[policy.ID] {
			return fmt.Errorf("Root固定政策ID差:%s", policy.ID)
		}
		delete(expected, policy.ID)
	}
	if len(expected) != 0 {
		return fmt.Errorf("未束縛の実装政策があります")
	}
	return nil
}
