package technicalexit158

import (
	"encoding/json"
	"math/rand"
	"reflect"
	"testing"

	old "exitreplay157"
)

// entryFixture は鏡像化できる正常取得を作ります。
//
// 引数: side int 型の方向。
// 返り値: Quote 型と float64 型の実取得価格。
func entryFixture(side int) (Quote, float64) {
	q := Quote{Time: 100, Index: 1, SourceLine: 2, Last: 1000, Bid: 995, Ask: 1005, QuoteOK: true}
	if side > 0 {
		return q, q.Ask
	}
	return q, q.Bid
}

// gainFixture は所定清算粗益の正常行を売買対称に作ります。
//
// 引数: side int、gain/second float64、index int64。
// 返り値: Quote 型の後原行。
func gainFixture(side int, gain, second float64, index int64) Quote {
	q, price := entryFixture(side)
	if side > 0 {
		q.Bid, q.Ask = price+gain, price+gain+10
	} else {
		q.Bid, q.Ask = price-gain-10, price-gain
	}
	q.Last = (q.Bid + q.Ask) / 2
	q.Time, q.Index, q.SourceLine = second, index, index+1
	return q
}

// contextFixture は当場で現在までに知った特徴を作ります。
//
// 引数: q Quote。
// 返り値: FeatureContext 型の人工票。
func contextFixture(q Quote) FeatureContext {
	return FeatureContext{Session: "人工場", Contract: "人工限月", At: Stamp{Time: q.Time, Index: q.Index, SourceLine: q.SourceLine}, UpdatedAt: Stamp{Time: q.Time, Index: q.Index, SourceLine: q.SourceLine}, EventID: "人工更新", Values: map[string]FeatureValue{"atr5": {Value: floatPtr(50), Known: true}}}
}

// technicalFixture は固定起動閾値の人工Controllerを接続します。
//
// 引数: t *testing.T、side int、threshold float64、controller Controller。
// 返り値: *FSM 型の独立状態。
func technicalFixture(t *testing.T, side int, threshold float64, controller Controller) *FSM {
	t.Helper()
	q, price := entryFixture(side)
	c := Config{ID: "人工/H60/D1/C5", Policy: "人工", Horizon: "H60", Delay: "D1", Cost: "C5", FeeYen: 1077}
	f, err := NewTechnical(q, side, price, 200, 500, c, Scope{"人工場", "人工限月"}, Definition{ID: "人工", Family: "人工のみ", ArmThresholdPoints: threshold}, controller)
	if err != nil {
		t.Fatal(err)
	}
	return f
}

// TestLegacyControlsExact は旧2対照の全結果を157と完全比較します。
//
// 引数: t *testing.T。
// 返り値: なし。全費用・遅延・期限・方向とランダム経路を人工で調べます。
func TestLegacyControlsExact(t *testing.T) {
	random := rand.New(rand.NewSource(158))
	compared := 0
	for _, config := range BaselineConfigurations() {
		for _, side := range []int{1, -1} {
			for path := 0; path < 40; path++ {
				entry, price := entryFixture(side)
				n, err := New(entry, side, price, 200, 500, config)
				if err != nil {
					t.Fatal(err)
				}
				o, err := old.New(old.Quote(entry), side, price, 200, 500, old.Config(config))
				if err != nil {
					t.Fatal(err)
				}
				second, gain := 100.0, 0.0
				for index := int64(2); index < 100; index++ {
					second += float64(random.Intn(5))
					gain += float64(random.Intn(101) - 50)
					q := gainFixture(side, gain, second, index)
					if index%13 == 0 {
						q.QuoteOK = false
					}
					if path%7 == 0 && index == 12 {
						q.Time += 301
					}
					en, eo := n.Step(q), o.Step(old.Quote(q))
					if (en == nil) != (eo == nil) {
						t.Fatalf("error差:%v/%v", en, eo)
					}
					if en != nil || n.Done() {
						break
					}
				}
				n.Finish()
				o.Finish()
				bn, _ := json.Marshal(n.Result())
				bo, _ := json.Marshal(o.Result())
				if string(bn) != string(bo) {
					t.Fatalf("旧対照全結果差:%s/%d/%d\n%s\n%s", config.ID, side, path, bn, bo)
				}
				compared++
			}
		}
	}
	if compared != 1920 {
		t.Fatalf("比較件数:%d", compared)
	}
}

// TestTechnicalThresholdMirrorReservation は起動・非緩和・予約を鏡像検査します。
//
// 引数: t *testing.T。
// 返り値: なし。最初の費用後正益だけでは125起動しないことも検査します。
func TestTechnicalThresholdMirrorReservation(t *testing.T) {
	for _, side := range []int{1, -1} {
		calls := 0
		controller := ControllerFunc(func(view StateView, context FeatureContext) (Decision, error) {
			calls++
			return Decision{FloorPoints: floatPtr(view.PeakPoints - 100), UsedFeatures: []string{"atr5"}}, nil
		})
		f := technicalFixture(t, side, 125, controller)
		for i, gain := range []float64{50, 125, 30, 20, 200} {
			q := gainFixture(side, gain, float64(101+i), int64(2+i))
			if err := f.Step(q, contextFixture(q)); err != nil {
				t.Fatal(err)
			}
			if i == 0 && (f.Result().Armed || f.Result().StopPoints != -125) {
				t.Fatal("指定利益前に起動しました")
			}
		}
		r := f.Result()
		if calls != 3 || r.Status != "closed" || r.ArmQuote.Time != 102 || r.Trigger.Time != 104 || r.Fill.Time != 105 || *r.ProfitPoints != 200 || r.StopPoints != 25 {
			t.Fatalf("技術状態:%+v calls=%d", r, calls)
		}
	}
}

// TestThresholdFeeAndFloor は粗益閾値と費用後正益を別に検査します。
//
// 引数: t *testing.T。
// 返り値: なし。動的閾値が後で上がっても解除・床緩和しません。
func TestThresholdFeeAndFloor(t *testing.T) {
	controller := ControllerFunc(func(view StateView, context FeatureContext) (Decision, error) {
		threshold := 0.0
		if view.Armed {
			threshold = 200
		}
		return Decision{ArmThresholdPoints: floatPtr(threshold), FloorPoints: floatPtr(-100)}, nil
	})
	f := technicalFixture(t, 1, 125, controller)
	for i, gain := range []float64{10, 20, 15} {
		q := gainFixture(1, gain, float64(101+i), int64(2+i))
		if err := f.Step(q, contextFixture(q)); err != nil {
			t.Fatal(err)
		}
		if i == 0 && f.Result().Armed {
			t.Fatal("費用後赤字で起動しました")
		}
	}
	if !f.Result().Armed || f.Result().StopPoints != 0 {
		t.Fatal("起動後の最低床又は非緩和が不正です")
	}
}

// TestUnknownFreshnessAndImmutability は鮮度切れと入力非改変を検査します。
//
// 引数: t *testing.T。
// 返り値: なし。未知を0や古い既知値へ補完しません。
func TestUnknownFreshnessAndImmutability(t *testing.T) {
	q := gainFixture(1, 50, 101, 2)
	context := contextFixture(q)
	v := context.Values["atr5"]
	v.ValidUntil = floatPtr(101)
	context.Values["atr5"] = v
	before, _ := json.Marshal(context)
	controller := ControllerFunc(func(view StateView, current FeatureContext) (Decision, error) {
		if current.Values["atr5"].Known || current.Values["atr5"].Value != nil {
			t.Fatal("鮮度終端等号を既知へしました")
		}
		current.Values["atr5"] = FeatureValue{Known: true, Value: floatPtr(999)}
		return Decision{}, nil
	})
	f := technicalFixture(t, 1, 125, controller)
	if err := f.Step(q, context); err != nil {
		t.Fatal(err)
	}
	after, _ := json.Marshal(context)
	if string(before) != string(after) {
		t.Fatal("呼出し元の特徴を変更しました")
	}
}

// TestFeatureCausalityRejects は未来参照とscope・既知値矛盾を拒否します。
//
// 引数: t *testing.T。
// 返り値: なし。同限月の過去場refの原行番号は当場番号と比較しません。
func TestFeatureCausalityRejects(t *testing.T) {
	q := gainFixture(1, 50, 101, 2)
	ref := FeatureRef{ID: "既知", Session: "人工場", Contract: "人工限月", WidthSeconds: 60, Start: -60, End: 0, AvailableAt: 60, Stamp: Stamp{Time: 60, Index: 1, SourceLine: 1}}
	for _, mutate := range []func(*FeatureContext){
		func(c *FeatureContext) { c.At.Time = 102 },
		func(c *FeatureContext) { c.At.Index = 3 },
		func(c *FeatureContext) { c.Contract = "別限月" },
		func(c *FeatureContext) { c.Values["atr5"] = FeatureValue{Known: true} },
		func(c *FeatureContext) { c.Refs[0].Stamp.SourceLine = 99 },
		func(c *FeatureContext) { c.Refs[0].AvailableAt = 102 },
	} {
		context := contextFixture(q)
		context.Refs = []FeatureRef{ref}
		mutate(&context)
		f := technicalFixture(t, 1, 125, ControllerFunc(func(StateView, FeatureContext) (Decision, error) { return Decision{}, nil }))
		if err := f.Step(q, context); err == nil {
			t.Fatal("不正特徴を受理しました")
		}
	}
	context := contextFixture(q)
	ref.Session, ref.Stamp.Index, ref.Stamp.SourceLine = "過去場", 10000, 10000
	context.Refs = []FeatureRef{ref}
	if _, err := normalizeContext(context, q, Scope{"人工場", "人工限月"}); err != nil {
		t.Fatal(err)
	}
}

// TestTechnicalDeadlineAndEOF は期限後の技術判断とEOF補完を禁止します。
//
// 引数: t *testing.T。
// 返り値: なし。期限要求時計は最初の観測原行へ遅らせません。
func TestTechnicalDeadlineAndEOF(t *testing.T) {
	called := false
	f := technicalFixture(t, 1, 125, ControllerFunc(func(StateView, FeatureContext) (Decision, error) { called = true; return Decision{}, nil }))
	q := gainFixture(1, 30, 201, 2)
	if err := f.Step(q, contextFixture(q)); err != nil {
		t.Fatal(err)
	}
	r := f.Result()
	if called || r.Trigger.Time != 200 || r.Fill.Time != 201 || r.Status != "closed" {
		t.Fatalf("期限時計:%+v", r)
	}
	before := f.Result()
	f.Finish()
	if !reflect.DeepEqual(before, f.Result()) {
		t.Fatal("完了損益をEOFで変更しました")
	}
	g := technicalFixture(t, 1, 125, ControllerFunc(func(StateView, FeatureContext) (Decision, error) { return Decision{}, nil }))
	g.Finish()
	if g.Result().Status != "unknown" || g.Result().ProfitYen != nil {
		t.Fatal("EOFを既知損益へ補完しました")
	}
}
