package technicalexit158

import (
	"fmt"
	"reflect"
	"strings"
	"testing"

	features "features158"
)

// fullFeatureFixture は全policy参照名を持つ非自然の観測を作ります。
//
// 引数: なし。
// 返り値: FeatureContext 型。学習値・自然価格・金融ラベルを使いません。
func fullFeatureFixture() FeatureContext {
	q := gainFixture(1, 150, 160, 10)
	c := contextFixture(q)
	raw := map[string]float64{"m1.open": 1000, "m1.high": 1030, "m1.low": 990, "m1.close": 1010, "m1.previous_close": 1005, "m1.ema8": 1005, "m1.atr14": 40, "m1.previous_atr14": 40, "m1.tr": 45, "m1.hist": 5, "m1.hist_delta": 1, "m1.di_difference": 10, "m1.prior_low5": 980, "m1.prior_high5": 1040, "m1.prior_low10": 970, "m1.prior_high10": 1050, "m1.prior_low20": 960, "m1.prior_high20": 1060, "m1.supertrend_line": 990, "m1.supertrend_direction": 1, "m1.psar_line": 985, "m1.psar_direction": 1, "m1.trd_mean20": 35, "m1.trd_sd20": 10, "m1.bb_width": 100, "m1.previous_bb_width": 110, "m1.er10": .5, "m1.chop14": 40, "m1.zscore": 0, "m1.rvol": 1, "m1.cmf20": .2, "m1.obv_delta5": 100, "m1.session_vwap_proxy": 1100, "m15.adx": 25, "m5.hist": 5}
	for _, width := range []string{"m5", "m15", "m30"} {
		raw[width+".gap"], raw[width+".ema21_delta"] = 10, 2
	}
	c.Values = map[string]FeatureValue{}
	for name, value := range raw {
		c.Values[name] = FeatureValue{Known: true, Value: floatPtr(value)}
	}
	return c
}

// mirrorFeatures は価格を正の定数中心で鏡像にし方向量を反転します。
//
// 引数: input FeatureContext。
// 返り値: FeatureContext 型の売り側観測。
func mirrorFeatures(input FeatureContext) FeatureContext {
	out := cloneContext(input)
	for name, value := range out.Values {
		if !value.Known {
			continue
		}
		key := name
		if name == "m1.high" {
			key = "m1.low"
		} else if name == "m1.low" {
			key = "m1.high"
		} else if strings.Contains(name, "prior_high") {
			key = strings.Replace(name, "prior_high", "prior_low", 1)
		} else if strings.Contains(name, "prior_low") {
			key = strings.Replace(name, "prior_low", "prior_high", 1)
		}
		x := *input.Values[key].Value
		price := name == "m1.open" || name == "m1.high" || name == "m1.low" || name == "m1.close" || name == "m1.previous_close" || name == "m1.ema8" || strings.Contains(name, "prior_") || name == "m1.supertrend_line" || name == "m1.psar_line" || name == "m1.session_vwap_proxy"
		if price {
			x = 3000 - x
		} else if strings.Contains(name, "hist") || strings.Contains(name, "di_difference") || strings.Contains(name, "gap") || strings.Contains(name, "ema21_delta") || name == "m1.cmf20" || name == "m1.obv_delta5" || name == "m1.zscore" || strings.Contains(name, "direction") {
			x = -x
		}
		value.Value = floatPtr(x)
		out.Values[name] = value
	}
	return out
}

// TestAllFamiliesMirror は16固定式の売買鏡像と入力非改変を確認します。
//
// 引数: t *testing.T。
// 返り値: なし。条件強化・弱化の双方で同じ粗益提案を要求します。
func TestAllFamiliesMirror(t *testing.T) {
	for _, weak := range []bool{false, true} {
		buy := fullFeatureFixture()
		if weak {
			for name, value := range map[string]float64{"m1.hist": -1, "m1.hist_delta": -2, "m1.close": 985, "m1.di_difference": -10, "m1.prior_low5": 990, "m1.cmf20": -.3, "m1.obv_delta5": -100, "m1.supertrend_direction": -1, "m1.psar_direction": -1} {
				buy.Values[name] = FeatureValue{Known: true, Value: floatPtr(value)}
			}
		}
		for _, definition := range PolicyCatalog() {
			controller, err := Builtin(definition.ID)
			if err != nil {
				t.Fatal(err)
			}
			sell := mirrorFeatures(buy)
			before := cloneContext(buy)
			view := StateView{Side: 1, EntryPrice: 1005, GainPoints: 150, PeakPoints: 170, PeakTime: 100, Current: gainFixture(1, 150, 160, 10), EntryContext: &buy, Memory: map[string]float64{}}
			left, err := controller.Evaluate(view, buy)
			if err != nil {
				t.Fatal(err)
			}
			view.Side, view.EntryPrice, view.EntryContext = -1, 1995, &sell
			right, err := controller.Evaluate(view, sell)
			if err != nil {
				t.Fatal(err)
			}
			left.UsedFeatures = nil
			right.UsedFeatures = nil
			if !reflect.DeepEqual(left, right) {
				t.Fatalf("鏡像差:%s weak=%v\n%+v\n%+v", definition.ID, weak, left, right)
			}
			if !reflect.DeepEqual(before, buy) {
				t.Fatalf("入力改変:%s", definition.ID)
			}
		}
	}
	if len(Configurations()) != 152 {
		t.Fatal("固定152条件差")
	}
}

// TestFallbackAndExtensionBoundary はunknown例外と初回125判断を確認します。
//
// 引数: t *testing.T。
// 返り値: なし。C1fallbackとA15不許可を同一扱いしません。
func TestFallbackAndExtensionBoundary(t *testing.T) {
	c := fullFeatureFixture()
	view := StateView{Side: 1, EntryPrice: 1005, GainPoints: 125, PeakPoints: 125, EntryContext: &c, Memory: map[string]float64{}}
	for _, definition := range PolicyCatalog() {
		controller, _ := Builtin(definition.ID)
		input := cloneContext(c)
		input.Values["m1.hist_delta"] = FeatureValue{}
		d, err := controller.Evaluate(view, input)
		if err != nil {
			t.Fatal(err)
		}
		if definition.ID[:3] != "A15" && (!d.Fallback || *d.TakeProfitPoints != 250 || *d.FloorPoints != 25) {
			t.Fatalf("C1fallback:%s %+v", definition.ID, d)
		}
	}
	controller, _ := Builtin("A15_EXTEND_PERMISSION")
	d, _ := controller.Evaluate(view, c)
	if *d.TakeProfitPoints != 250 || d.Memory["extend_permission"] != 1 {
		t.Fatal("125前の延伸許可がありません")
	}
	input := cloneContext(c)
	input.Values["m1.cmf20"] = FeatureValue{}
	d, _ = controller.Evaluate(view, input)
	if *d.TakeProfitPoints != 125 || d.Fallback {
		t.Fatal("A15未知を許可又はC1fallbackへしました")
	}
	view.Memory = d.Memory
	d, _ = controller.Evaluate(view, c)
	if *d.TakeProfitPoints != 125 {
		t.Fatal("初回の不許可を後から取直しました")
	}
}

// TestFrozenVWAPAndEntryATR は取得時の目標と起動基準を凍結します。
//
// 引数: t *testing.T。
// 返り値: なし。現在VWAPへの交換と逆側の到達済み扱いを防ぎます。
func TestFrozenVWAPAndEntryATR(t *testing.T) {
	entry := fullFeatureFixture()
	current := cloneContext(entry)
	current.Values["m1.session_vwap_proxy"] = FeatureValue{Known: true, Value: floatPtr(1400)}
	current.Values["m1.hist_delta"] = FeatureValue{Known: true, Value: floatPtr(-1)}
	current.Values["m1.hist"] = FeatureValue{Known: true, Value: floatPtr(-1)}
	current.Values["m5.hist"] = FeatureValue{Known: true, Value: floatPtr(-1)}
	view := StateView{Side: 1, EntryPrice: 1005, GainPoints: 100, PeakPoints: 100, EntryContext: &entry, Memory: map[string]float64{}}
	controller, _ := Builtin("A08_VWAP_REVERT")
	d, _ := controller.Evaluate(view, current)
	if *d.TakeProfitPoints != 95 || d.ExitReason == "" {
		t.Fatal("凍結VWAP目標差")
	}
	entry.Values["m1.session_vwap_proxy"] = FeatureValue{Known: true, Value: floatPtr(900)}
	d, _ = controller.Evaluate(view, current)
	if *d.TakeProfitPoints != 125 || d.ExitReason != "" {
		t.Fatal("逆側VWAPを既到達へしました")
	}
	controller, _ = Builtin("A02_KASE_VAR")
	entry.Values["m1.atr14"] = FeatureValue{Known: true, Value: floatPtr(30)}
	d, _ = controller.Evaluate(view, current)
	if *d.ArmThresholdPoints != 60 {
		t.Fatal("entry ATR起動差")
	}
	entry.Values["m1.atr14"] = FeatureValue{}
	d, _ = controller.Evaluate(view, current)
	if *d.ArmThresholdPoints != 125 || d.Fallback {
		t.Fatal("A02のentry未知例外差")
	}
}

// minuteUpdate は純人工の閉鎖イベントを作ります。
//
// 引数: context FeatureContext、end float64。
// 返り値: FeatureUpdate 型。1分値を全て含みます。
func minuteUpdate(context FeatureContext, end float64) features.FeatureUpdate {
	values := map[string]FeatureValue{}
	for name, value := range context.Values {
		if strings.HasPrefix(name, "m1.") {
			values[name] = value
		}
	}
	id := fmt.Sprintf("人工足/%.0f", end)
	ref := FeatureRef{ID: id, Session: context.Session, Contract: context.Contract, WidthSeconds: 60, Start: end - 60, End: end, AvailableAt: end + 60, Stamp: context.At}
	return features.FeatureUpdate{ID: id, At: context.At, WidthSeconds: 60, PriceKnown: true, VolumeKnown: true, Values: values, Refs: []FeatureRef{ref}}
}

// TestSameRawDistinctMinuteBatch は同Rawの異なる2足を元値で処理します。
//
// 引数: t *testing.T。
// 返り値: なし。最終足を先行足へ複写せず累積・継続・急伸旗を検査します。
func TestSameRawDistinctMinuteBatch(t *testing.T) {
	first := fullFeatureFixture()
	second := cloneContext(first)
	for _, c := range []*FeatureContext{&first, &second} {
		for name, value := range map[string]float64{"m1.hist": -1, "m1.hist_delta": -1, "m1.cmf20": -.2, "m1.obv_delta5": -100, "m1.di_difference": -10, "m1.bb_width": 80, "m1.previous_bb_width": 100, "m1.previous_atr14": 20} {
			c.Values[name] = FeatureValue{Known: true, Value: floatPtr(value)}
		}
	}
	first.Values["m1.close"], first.Values["m1.previous_close"] = FeatureValue{Known: true, Value: floatPtr(960)}, FeatureValue{Known: true, Value: floatPtr(1000)}
	second.Values["m1.close"], second.Values["m1.previous_close"] = FeatureValue{Known: true, Value: floatPtr(920)}, FeatureValue{Known: true, Value: floatPtr(960)}
	second.Updates = []features.FeatureUpdate{minuteUpdate(first, 60), minuteUpdate(second, 120)}
	view := StateView{Side: 1, EntryPrice: 1005, PeakPoints: 80, GainPoints: 30, Memory: map[string]float64{}}
	cusum, _ := Builtin("A13_CUSUM_FAILURE")
	d, _ := cusum.Evaluate(view, second)
	if d.Memory["cusum"] != 3.5 || d.ExitReason == "" {
		t.Fatalf("2足CUSUM:%+v", d)
	}
	consensus, _ := Builtin("A14_PERSISTENT_CONSENSUS")
	d, _ = consensus.Evaluate(view, second)
	if d.Memory["consensus_streak"] != 2 || d.ExitReason == "" {
		t.Fatalf("2足consensus:%+v", d)
	}
	spikeFirst := fullFeatureFixture()
	spikeSecond := cloneContext(spikeFirst)
	for name, value := range map[string]float64{"m1.open": 1000, "m1.close": 1100, "m1.high": 1200, "m1.low": 980, "m1.rvol": 2, "m1.zscore": 2} {
		spikeFirst.Values[name] = FeatureValue{Known: true, Value: floatPtr(value)}
	}
	for name, value := range map[string]float64{"m1.open": 1045, "m1.close": 1040, "m1.high": 1060, "m1.low": 1030, "m1.hist": -1, "m1.hist_delta": -1, "m1.zscore": -1} {
		spikeSecond.Values[name] = FeatureValue{Known: true, Value: floatPtr(value)}
	}
	spikeSecond.Updates = []features.FeatureUpdate{minuteUpdate(spikeFirst, 60), minuteUpdate(spikeSecond, 120)}
	spike, _ := Builtin("A09_SPIKE_CONFIRM")
	d, _ = spike.Evaluate(view, spikeSecond)
	if d.Memory["spike_body_mid"] != 1050 || d.Memory["spike_flag"] != 1 || d.Memory["spike_failed"] != 1 || d.ExitReason == "" {
		t.Fatalf("2足spike:%+v", d)
	}
}

// TestBadBBOBatchAndRawRepetition は不正常Rawの足を脱落・多重計数しません。
//
// 引数: t *testing.T。
// 返り値: なし。取得当Raw以前の履歴はCUSUMへ使いません。
func TestBadBBOBatchAndRawRepetition(t *testing.T) {
	seen := []int{}
	controller := ControllerFunc(func(view StateView, current FeatureContext) (Decision, error) {
		seen = append(seen, len(current.Updates))
		return Decision{Memory: copyNumbers(view.Memory)}, nil
	})
	f := technicalFixture(t, 1, 125, controller)
	q := gainFixture(1, 20, 130, 2)
	q.QuoteOK = false
	c := contextFixture(q)
	c.Updates = []features.FeatureUpdate{minuteUpdate(c, 60)}
	if err := f.Step(q, c); err != nil {
		t.Fatal(err)
	}
	q = gainFixture(1, 20, 131, 3)
	c = contextFixture(q)
	if err := f.Step(q, c); err != nil {
		t.Fatal(err)
	}
	q = gainFixture(1, 20, 132, 4)
	c = contextFixture(q)
	if err := f.Step(q, c); err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(seen, []int{1, 0}) {
		t.Fatalf("更新脱落又はRaw増殖:%v", seen)
	}
}

// TestCUSUMAndPersistentEvents は足イベントの累積と未知resetを確認します。
//
// 引数: t *testing.T。
// 返り値: なし。同じ足のRaw再送では連続回数が増えません。
func TestCUSUMAndPersistentEvents(t *testing.T) {
	c := fullFeatureFixture()
	for name, value := range map[string]float64{"m1.close": 900, "m1.previous_close": 1000, "m1.previous_atr14": 20, "m1.hist": -1, "m1.hist_delta": -1, "m1.cmf20": -.2, "m1.obv_delta5": -100, "m1.di_difference": -10, "m1.bb_width": 80, "m1.previous_bb_width": 100} {
		c.Values[name] = FeatureValue{Known: true, Value: floatPtr(value)}
	}
	view := StateView{Side: 1, EntryPrice: 1005, PeakPoints: 60, Current: gainFixture(1, 30, 160, 10), Memory: map[string]float64{}}
	c.Updates = []features.FeatureUpdate{minuteUpdate(c, 60)}
	controller, _ := Builtin("A13_CUSUM_FAILURE")
	d, _ := controller.Evaluate(view, c)
	if d.Memory["cusum"] != 4.75 || d.ExitReason == "" {
		t.Fatalf("CUSUM:%+v", d)
	}
	controller, _ = Builtin("A14_PERSISTENT_CONSENSUS")
	d, _ = controller.Evaluate(view, c)
	if d.Memory["consensus_streak"] != 1 || d.ExitReason != "" {
		t.Fatal("一足で二足継続としました")
	}
	view.Memory = d.Memory
	d, _ = controller.Evaluate(view, c)
	if d.Memory["consensus_streak"] != 1 {
		t.Fatal("同足を再計数しました")
	}
	c.Updates = []features.FeatureUpdate{minuteUpdate(c, 120)}
	d, _ = controller.Evaluate(view, c)
	if d.Memory["consensus_streak"] != 2 || d.ExitReason == "" {
		t.Fatal("二足継続差")
	}
	view.Memory = d.Memory
	c.Values["m1.hist_delta"] = FeatureValue{}
	c.Updates = []features.FeatureUpdate{minuteUpdate(c, 180)}
	d, _ = controller.Evaluate(view, c)
	if !d.Fallback || d.Memory["consensus_streak"] != 0 {
		t.Fatal("未知足で連続を維持しました")
	}
}
