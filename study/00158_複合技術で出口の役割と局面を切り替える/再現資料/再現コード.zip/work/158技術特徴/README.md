# 158の確定足特徴生成

147保存canonical OHLCVと122/118旧公表を配送Stampで合わせ、出口用Contextイベントを一度生成する。Raw/価格CSV/未見2場/金融ラベルは読まない。定義は[特徴の定義.md](特徴の定義.md)。主Sourceは人工9群/test-vet-build後停止、自然生成はRootが一回実行する。

repo rootからのCLI：

```powershell
& '.\work\158技術特徴\feature158.exe' --allow-natural `
  --parent '.\inputs\00147_中位価格位置と実体回復\Sourceの出生と取得.json.gz' `
  --background '.\work\122全場入力\入力.json' `
  --spec '.\study\00158_複合技術で出口の役割と局面を切り替える\実行条件.md' `
  --source-dir 'S:\GitHub\masayoshi4649\FutureSignalResearch\work\158技術特徴' `
  --output-dir 'S:\GitHub\masayoshi4649\FutureSignalResearch\work\158技術特徴の評価\特徴'
```

出力先は未作成を指定する。`特徴の確認.json`のscenes[].pathはmanifest親からの相対path、各gzip JSONL行はContextそのもの。catalogは全keyの辞書順。1原行1Context、同原行Updatesは背景→全1分の元順。CursorはAtのtime/index/source_line全て<=現在qのイベントだけを適用し、値のValidUntil等号でunknown化する。イベント無しの現在qはUpdates空にする。

検査は`go test -count=1 -v ./...`、`go vet ./...`、`go build -o feature158.exe ./cmd/run`。人工の主範囲は手計算/窓端/TRD22本、量0と未知、prefix非回復、PSARclamp/等号、100足の価格鏡像、batch/snapshot凍結、旧MTF実前/早期限、同限月carry、gzip全SHA/CRC/末尾失敗。自作数値の作者検査であり独立確認はRoot/archiveへ分離する。
