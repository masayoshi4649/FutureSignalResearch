package features158

// validPrice はcanonical足の閉鎖・価格既知を同時に要求します。
//
// 引数: b(Minute)。返り値: bool。
func validPrice(b Minute) bool { return b.Closed && !b.Missing && b.PriceKnown }

// validVolume は既知0を許容し閉鎖/量未知と区別します。
//
// 引数: b(Minute)。返り値: bool。
func validVolume(b Minute) bool { return b.Closed && !b.Missing && b.VolumeKnown }

// cmfWindow は価格と量が全既知の厳密20slotのCMFを返します。
//
// 引数: bs([]Minute)。返り値: *float64。H=Lは寄与0、量総和0はnilです。
func cmfWindow(bs []Minute) *float64 {
	if len(bs) != 20 {
		return nil
	}
	total, flow := 0., 0.
	for _, b := range bs {
		if !validPrice(b) || !validVolume(b) {
			return nil
		}
		o := b.OHLC
		m := 0.
		if o.High > o.Low {
			m = (2*o.Close - o.High - o.Low) / (o.High - o.Low)
		}
		total += b.Volume
		flow += m * b.Volume
	}
	if total <= 0 {
		return nil
	}
	return ptr(flow / total)
}

// quantityWindows は同じcanonical OHLCVだけから量とstrict session VWAP近似を作ります。
//
// 引数: out(map[string]*float64)、b(Minute)。返り値: なし。
func (s *MinuteState) quantityWindows(out map[string]*float64, b Minute) {
	n := len(s.all)
	if validVolume(b) {
		out["volume"] = ptr(b.Volume)
	}
	for _, width := range []int{3, 20} {
		if validVolume(b) && n >= width+1 {
			sum := 0.
			known := true
			for _, p := range s.all[n-width-1 : n-1] {
				known = known && validVolume(p)
				sum += p.Volume
			}
			if known && sum > 0 {
				key := "rvol"
				if width == 3 {
					key = "volume_relative_prior3"
				}
				out[key] = ptr(b.Volume / (sum / float64(width)))
			}
		}
	}
	out["relative_volume20"] = out["rvol"]
	for _, width := range []int{5, 15, 30} {
		if n >= width+1 {
			xs := s.all[n-width-1:]
			known := true
			change := 0.
			for i := 1; i < len(xs); i++ {
				p, c := xs[i-1], xs[i]
				if !validPrice(p) || !validPrice(c) || !validVolume(c) {
					known = false
					break
				}
				sign := 0.
				if c.OHLC.Close > p.OHLC.Close {
					sign = 1
				} else if c.OHLC.Close < p.OHLC.Close {
					sign = -1
				}
				change += sign * c.Volume
			}
			if known {
				if width == 5 {
					out["obv_delta5"] = ptr(change)
				} else if width == 15 {
					out["obv_delta15"] = ptr(change)
				} else {
					out["obv_delta30"] = ptr(change)
				}
			}
		}
	}
	if n >= 20 {
		out["cmf20"] = cmfWindow(s.all[n-20:])
	}
	if n >= 21 {
		out["cmf20_delta"] = delta(out["cmf20"], cmfWindow(s.all[n-21:n-1]))
	}
	if !validVolume(b) || b.Volume > 0 && !validPrice(b) {
		s.prefixKnown = false
	}
	if s.prefixKnown {
		s.prefixVolume += b.Volume
		if b.Volume > 0 {
			s.prefixWeighted += (b.OHLC.High + b.OHLC.Low + b.OHLC.Close) / 3 * b.Volume
		}
		out["session_volume"] = ptr(s.prefixVolume)
		if s.prefixVolume > 0 {
			out["session_vwap_proxy"] = ptr(s.prefixWeighted / s.prefixVolume)
		}
	}
	if n >= 20 {
		known := true
		sum, weighted := 0., 0.
		for _, p := range s.all[n-20:] {
			if !validPrice(p) || !validVolume(p) {
				known = false
				break
			}
			sum += p.Volume
			weighted += (p.OHLC.High + p.OHLC.Low + p.OHLC.Close) / 3 * p.Volume
		}
		if known && sum > 0 {
			out["hlc3_vwma20"] = ptr(weighted / sum)
		}
	}
	for _, v := range out {
		if v != nil && !finite(*v) {
			panic("量特徴の非有限")
		}
	}
}
