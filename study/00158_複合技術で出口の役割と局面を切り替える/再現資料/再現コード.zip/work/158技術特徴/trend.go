package features158

import "math"

// trendLines はST/PSARの鏡像seed派生とCKの式名付き水準を更新します。
//
// 引数: out(map[string]*float64)、previous(*Minute)、atr10(*float64)、b(Minute)。返り値: なし。
func (s *MinuteState) trendLines(out map[string]*float64, previous *Minute, atr10 *float64, b Minute) {
	o := b.OHLC
	// ----------------------------------------
	// STはATR助走後の最初の非零終値差で対称seedし、以後公開バンド式へ従います。
	if atr10 != nil {
		upper, lower := (o.High+o.Low)/2+3**atr10, (o.High+o.Low)/2-3**atr10
		if !s.stReady {
			if previous != nil && o.Close != previous.OHLC.Close {
				s.stReady = true
				if o.Close > previous.OHLC.Close {
					s.stDirection = 1
					s.stLine = lower
				} else {
					s.stDirection = -1
					s.stLine = upper
				}
				s.stUpper, s.stLower = upper, lower
			}
		} else {
			if !(upper < s.stUpper || previous.OHLC.Close > s.stUpper) {
				upper = s.stUpper
			}
			if !(lower > s.stLower || previous.OHLC.Close < s.stLower) {
				lower = s.stLower
			}
			if s.stDirection < 0 {
				if o.Close > upper {
					s.stDirection = 1
				}
			} else if o.Close < lower {
				s.stDirection = -1
			}
			s.stUpper, s.stLower = upper, lower
			if s.stDirection > 0 {
				s.stLine = lower
			} else {
				s.stLine = upper
			}
		}
		if s.stReady {
			out["supertrend_line"], out["supertrend_direction"] = ptr(s.stLine), ptr(float64(s.stDirection))
		}
	}
	// ----------------------------------------
	// PSARは当足確定後の表示状態。原行途中でこの値を過去へ有効化しません。
	if !s.sarReady {
		if previous != nil && o.Close != previous.OHLC.Close {
			s.sarReady = true
			s.af = .02
			if o.Close > previous.OHLC.Close {
				s.sarDirection = 1
				s.sar = math.Min(previous.OHLC.Low, o.Low)
				s.ep = math.Max(previous.OHLC.High, o.High)
			} else {
				s.sarDirection = -1
				s.sar = math.Max(previous.OHLC.High, o.High)
				s.ep = math.Min(previous.OHLC.Low, o.Low)
			}
		}
	} else {
		next := s.sar + s.af*(s.ep-s.sar)
		prior := s.chain[:len(s.chain)-1]
		if len(prior) > 2 {
			prior = prior[len(prior)-2:]
		}
		for _, p := range prior {
			if s.sarDirection > 0 {
				next = math.Min(next, p.OHLC.Low)
			} else {
				next = math.Max(next, p.OHLC.High)
			}
		}
		reverse := s.sarDirection > 0 && o.Low < next || s.sarDirection < 0 && o.High > next
		if reverse {
			s.sar = s.ep
			s.sarDirection = -s.sarDirection
			s.af = .02
			if s.sarDirection > 0 {
				s.ep = o.High
			} else {
				s.ep = o.Low
			}
		} else {
			s.sar = next
			if s.sarDirection > 0 && o.High > s.ep {
				s.ep = o.High
				s.af = math.Min(.2, s.af+.02)
			} else if s.sarDirection < 0 && o.Low < s.ep {
				s.ep = o.Low
				s.af = math.Min(.2, s.af+.02)
			}
		}
	}
	if s.sarReady {
		out["psar_line"], out["psar_direction"] = ptr(s.sar), ptr(float64(s.sarDirection))
	}
	// ----------------------------------------
	// CKは曖昧なlong/short名を使わずmax9(HH10−ATR10)とmin9(LL10+ATR10)です。
	if atr10 != nil && len(s.chain) >= 10 {
		h, l := extremes(s.chain[len(s.chain)-10:])
		s.ckHigh = append(s.ckHigh, h-*atr10)
		s.ckLow = append(s.ckLow, l+*atr10)
		if len(s.ckHigh) > 9 {
			s.ckHigh = s.ckHigh[1:]
			s.ckLow = s.ckLow[1:]
		}
		if len(s.ckHigh) == 9 {
			high, low := s.ckHigh[0], s.ckLow[0]
			for i := range s.ckHigh {
				high = math.Max(high, s.ckHigh[i])
				low = math.Min(low, s.ckLow[i])
			}
			out["ck_high_stop"], out["ck_low_stop"] = ptr(high), ptr(low)
		}
	}
}
