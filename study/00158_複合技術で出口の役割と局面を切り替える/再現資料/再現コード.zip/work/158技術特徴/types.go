// Package features158 は当時公表済みのcanonical足から出口用技術特徴を作ります。
package features158

import "pricetape157"

type Quote = pricetape157.Quote

type Stamp struct {
	Time       float64 `json:"time"`
	Index      int64   `json:"index"`
	SourceLine int64   `json:"source_line"`
}

type OHLC struct {
	Open  float64 `json:"open"`
	High  float64 `json:"high"`
	Low   float64 `json:"low"`
	Close float64 `json:"close"`
}

type Minute struct {
	ID           string  `json:"id"`
	Session      string  `json:"session"`
	Contract     string  `json:"contract"`
	WidthSeconds int     `json:"width_seconds"`
	Start        float64 `json:"start"`
	End          float64 `json:"end"`
	AvailableAt  float64 `json:"available_at"`
	Stamp        Stamp   `json:"stamp"`
	PriceKnown   bool    `json:"price_known"`
	VolumeKnown  bool    `json:"volume_known"`
	Closed       bool    `json:"closed"`
	Missing      bool    `json:"missing"`
	OHLC         OHLC    `json:"ohlc"`
	Volume       float64 `json:"volume"`
}

type FeatureRef struct {
	ID           string  `json:"id"`
	Session      string  `json:"session"`
	Contract     string  `json:"contract"`
	WidthSeconds int     `json:"width_seconds"`
	Start        float64 `json:"start"`
	End          float64 `json:"end"`
	AvailableAt  float64 `json:"available_at"`
	Stamp        Stamp   `json:"stamp"`
	Source       string  `json:"source"`
}

type FeatureValue struct {
	Value      *float64 `json:"value"`
	Known      bool     `json:"known"`
	ValidUntil *float64 `json:"valid_until"`
	RefIDs     []string `json:"ref_ids"`
}

type FeatureUpdate struct {
	ID           string                  `json:"id"`
	At           Stamp                   `json:"at"`
	WidthSeconds int                     `json:"width_seconds"`
	Source       string                  `json:"source"`
	PriceKnown   bool                    `json:"price_known"`
	VolumeKnown  bool                    `json:"volume_known"`
	Values       map[string]FeatureValue `json:"values"`
	Refs         []FeatureRef            `json:"refs"`
}

type Context struct {
	Session   string                  `json:"session"`
	Contract  string                  `json:"contract"`
	At        Stamp                   `json:"at"`
	UpdatedAt Stamp                   `json:"updated_at"`
	EventID   string                  `json:"event_id"`
	Values    map[string]FeatureValue `json:"values"`
	Refs      []FeatureRef            `json:"refs"`
	Updates   []FeatureUpdate         `json:"updates"`
}
