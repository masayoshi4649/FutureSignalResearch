package features158

import (
	"fmt"
	"math"
	"testing"
)

// artificialMinute は価格CSV/自然値を使わない連続足fixtureを作ります。
//
// 引数: i(int)、close(float64)。返り値: Minute。
func artificialMinute(i int, close float64) Minute {
	start := float64(i * 60)
	return Minute{ID: fmt.Sprintf("m%d", i), Session: "人工", Contract: "限月A", WidthSeconds: 60, Start: start, End: start + 60, AvailableAt: start + 120, Stamp: Stamp{Time: start + 120, Index: int64(i + 1), SourceLine: int64(i + 2)}, PriceKnown: true, VolumeKnown: true, Closed: true, OHLC: OHLC{Open: close - .25, High: close + 2, Low: close - 2, Close: close}, Volume: float64(i%4 + 1)}
}

// mustState は人工場を初期化して不正fixtureならテストを停止します。
//
// 引数: t(*testing.T)。返り値: *MinuteState。
func mustState(t *testing.T) *MinuteState {
	t.Helper()
	s, e := NewMinuteState("人工", "限月A", 0, 10000*60)
	if e != nil {
		t.Fatal(e)
	}
	return s
}

// assertNumber は手計算との差を許容誤差内で確認します。
//
// 引数: t(*testing.T)、value(*float64)、want(float64)。返り値: なし。
func assertNumber(t *testing.T, value *float64, want float64) {
	t.Helper()
	if value == nil || math.Abs(*value-want) > 1e-8 {
		t.Fatalf("数値不一致 value=%v want=%v", value, want)
	}
}

// Test窓端と手計算 は価格窓の助走/現足除外/TRDの2足前終値を照合します。
//
// 引数: t(*testing.T)。返り値: なし。
func Test窓端と手計算(t *testing.T) {
	s := mustState(t)
	bars := []Minute{}
	var out map[string]*float64
	for i := 0; i < 22; i++ {
		close := 100. + float64(i)
		if i%3 == 0 {
			close += 30
		}
		b := artificialMinute(i, close)
		bars = append(bars, b)
		var e error
		out, e = s.Add(b)
		if e != nil {
			t.Fatal(e)
		}
		if i == 6 && out["ema8"] != nil {
			t.Fatal("EMA8早着")
		}
		if i == 19 && (out["prior_high20"] != nil || out["trd_mean20"] != nil) {
			t.Fatal("前除外/TRD早着")
		}
		if i == 20 && out["trd_mean20"] != nil {
			t.Fatal("TRDは22本必要")
		}
	}
	xs := []float64{}
	for i := 2; i < 22; i++ {
		hi := math.Max(math.Max(bars[i].OHLC.High, bars[i-1].OHLC.High), bars[i-2].OHLC.Close)
		lo := math.Min(math.Min(bars[i].OHLC.Low, bars[i-1].OHLC.Low), bars[i-2].OHLC.Close)
		xs = append(xs, hi-lo)
	}
	mean, variance := 0., 0.
	for _, x := range xs {
		mean += x
	}
	mean /= 20
	for _, x := range xs {
		variance += (x - mean) * (x - mean)
	}
	assertNumber(t, out["trd_mean20"], mean)
	assertNumber(t, out["trd_sd20"], math.Sqrt(variance/20))
	h, l := extremes(bars[1:21])
	assertNumber(t, out["prior_high20"], h)
	assertNumber(t, out["prior_low20"], l)
	// ----------------------------------------
	// 単調終値の独立fixtureではBB/ER/EMA seedも閉形式と比較します。
	s = mustState(t)
	for i := 0; i < 21; i++ {
		out, _ = s.Add(artificialMinute(i, 100+float64(i)))
		if i == 7 {
			assertNumber(t, out["ema8"], 103.5)
		}
	}
	assertNumber(t, out["ema21"], 110)
	assertNumber(t, out["atr14"], 4)
	assertNumber(t, out["er20"], 1)
	assertNumber(t, out["bb_mean"], 110.5)
	assertNumber(t, out["bb_sd"], math.Sqrt(33.25))
	assertNumber(t, out["bb_width"], 4*math.Sqrt(33.25))
}

// Test未知と量の回復 は価格reset・known0・量未知・prefix非回復を分離します。
//
// 引数: t(*testing.T)。返り値: なし。
func Test未知と量の回復(t *testing.T) {
	s := mustState(t)
	b := artificialMinute(0, 100)
	b.VolumeKnown = false
	if _, e := s.Add(b); e != nil {
		t.Fatal(e)
	}
	var out map[string]*float64
	for i := 1; i <= 40; i++ {
		b = artificialMinute(i, 100+float64(i))
		out, _ = s.Add(b)
	}
	if out["session_vwap_proxy"] != nil || out["session_volume"] != nil {
		t.Fatal("strict prefixが回復")
	}
	if out["hlc3_vwma20"] == nil || out["rvol"] == nil || out["cmf20"] == nil {
		t.Fatal("有限窓が回復しない")
	}
	b = artificialMinute(41, 141)
	b.PriceKnown = false
	b.Missing = true
	out, _ = s.Add(b)
	if out["ema8"] != nil || out["atr14"] != nil {
		t.Fatal("価格未知fallback")
	}
	b = artificialMinute(42, 142)
	out, _ = s.Add(b)
	if out["previous_close"] != nil || out["ema8"] != nil {
		t.Fatal("欠分を圧縮")
	}
	// ----------------------------------------
	// 価格未知でも既知量0はVWAPへの寄与0、未知量とは区別します。
	s = mustState(t)
	b = artificialMinute(0, 100)
	b.PriceKnown = false
	b.Volume = 0
	out, _ = s.Add(b)
	assertNumber(t, out["session_volume"], 0)
	if out["session_vwap_proxy"] != nil {
		t.Fatal("量総和0を価格補完")
	}
	b = artificialMinute(1, 101)
	b.Volume = 3
	out, _ = s.Add(b)
	assertNumber(t, out["session_vwap_proxy"], 101)
	s = mustState(t)
	for i := 0; i < 22; i++ {
		b = artificialMinute(i, 100+float64(i))
		b.Volume = 0
		out, _ = s.Add(b)
	}
	assertNumber(t, out["obv_delta5"], 0)
	if out["rvol"] != nil || out["cmf20"] != nil || out["hlc3_vwma20"] != nil {
		t.Fatal("ゼロ量分母を補完")
	}
	bad := artificialMinute(23, 100)
	if _, e := s.Add(bad); e == nil {
		t.Fatal("欠分を飛ばしたAdd許容")
	}
}

// TestPSAR制約と等号 は前2足clamp後のstrict貫通を上下鏡像で確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestPSAR制約と等号(t *testing.T) {
	for _, mirror := range []bool{false, true} {
		s := mustState(t)
		values := []OHLC{{96, 100, 90, 96}, {105, 110, 100, 105}, {100, 110, 90.2, 100}, {100, 109, 90.2, 101}, {95, 109, 89.9, 95}}
		for i, o := range values {
			if mirror {
				o = OHLC{1000 - o.Open, 1000 - o.Low, 1000 - o.High, 1000 - o.Close}
			}
			b := artificialMinute(i, o.Close)
			b.OHLC = o
			out, e := s.Add(b)
			if e != nil {
				t.Fatal(e)
			}
			if i == 2 || i == 3 {
				d := 1.
				line := 90.
				if i == 3 {
					line = 90.2
				}
				if mirror {
					d = -1
					line = 1000 - line
				}
				assertNumber(t, out["psar_direction"], d)
				assertNumber(t, out["psar_line"], line)
			}
			if i == 4 {
				d := -1.
				if mirror {
					d = 1
				}
				assertNumber(t, out["psar_direction"], d)
			}
		}
	}
}

// Test物理鏡像 は数値の価格反射で線/符号/強度/量の役割が対称であることを確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func Test物理鏡像(t *testing.T) {
	a, b := mustState(t), mustState(t)
	levels := map[string]string{"open": "open", "high": "low", "low": "high", "close": "close", "previous_close": "previous_close", "ema8": "ema8", "ema21": "ema21", "bb_mean": "bb_mean", "supertrend_line": "supertrend_line", "psar_line": "psar_line", "ck_high_stop": "ck_low_stop", "ck_low_stop": "ck_high_stop", "session_vwap_proxy": "session_vwap_proxy", "hlc3_vwma20": "hlc3_vwma20"}
	for _, w := range []int{5, 10, 20} {
		levels[fmt.Sprintf("high%d", w)] = fmt.Sprintf("low%d", w)
		levels[fmt.Sprintf("low%d", w)] = fmt.Sprintf("high%d", w)
		levels[fmt.Sprintf("prior_high%d", w)] = fmt.Sprintf("prior_low%d", w)
		levels[fmt.Sprintf("prior_low%d", w)] = fmt.Sprintf("prior_high%d", w)
	}
	signed := map[string]bool{}
	for _, k := range []string{"body", "body_ratio", "ema8_delta", "ema21_delta", "gap", "macd", "macd_signal", "hist", "hist_delta", "rsi_delta", "di_difference", "zscore", "zscore_delta", "obv_delta5", "obv_delta15", "obv_delta30", "cmf20", "cmf20_delta", "supertrend_direction", "psar_direction"} {
		signed[k] = true
	}
	for i := 0; i < 100; i++ {
		c := 1000 + 20*math.Sin(float64(i)*.4) + float64(i)*.1
		x := artificialMinute(i, c)
		x.OHLC.Open = c + math.Sin(float64(i))
		y := x
		y.OHLC = OHLC{5000 - x.OHLC.Open, 5000 - x.OHLC.Low, 5000 - x.OHLC.High, 5000 - x.OHLC.Close}
		left, e := a.Add(x)
		if e != nil {
			t.Fatal(e)
		}
		right, e := b.Add(y)
		if e != nil {
			t.Fatal(e)
		}
		for key, value := range left {
			other := key
			if v, ok := levels[key]; ok {
				other = v
			}
			if key == "upper_wick" {
				other = "lower_wick"
			}
			if key == "lower_wick" {
				other = "upper_wick"
			}
			if key == "di_plus" {
				other = "di_minus"
			}
			if key == "di_minus" {
				other = "di_plus"
			}
			rv := right[other]
			if (value == nil) != (rv == nil) {
				t.Fatalf("鏡像known %s/%d", key, i)
			}
			if value == nil {
				continue
			}
			want := *value
			if _, ok := levels[key]; ok {
				want = 5000 - want
			}
			if signed[key] {
				want = -want
			}
			if key == "rsi14" {
				want = 100 - want
			}
			if math.Abs(*rv-want) > 1e-7 {
				t.Fatalf("鏡像 %s/%d actual=%g want=%g", key, i, *rv, want)
			}
		}
	}
}
