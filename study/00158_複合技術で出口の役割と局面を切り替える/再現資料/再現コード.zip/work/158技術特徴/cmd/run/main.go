package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	f "features158"
)

// main は明示された固定参照だけから特徴イベントgzipを一回生成します。
//
// 引数: CLIフラグ。返り値: なし。失敗時は完了票を残さず終了code1です。
func main() {
	parent := flag.String("parent", "", "147canonical gzip")
	parentBytes := flag.Int64("parent-bytes", 10401387, "147gzip物理bytes")
	parentSHA := flag.String("parent-sha", "b99c49f06fe7e2306e59733b1cff26e3bb351f64edee220c98bc30b62c016d77", "147gzip物理SHA")
	decodedSHA := flag.String("parent-decoded-sha", "d42d25ec0fe41e8358c1227fd71b4377ffa90c96a8cf582f1ee4537ebf455d63", "147解凍SHA")
	background := flag.String("background", "", "固定122公表JSON")
	backgroundSHA := flag.String("background-sha", f.BackgroundSHA, "固定122SHA")
	spec := flag.String("spec", "", "正式158実行条件")
	specSHA := flag.String("spec-sha", f.SpecSHA, "正式158条件SHA")
	output := flag.String("output-dir", "", "未作成の特徴出力directory")
	sourceDirectory := flag.String("source-dir", "", "このGo moduleの絶対path")
	allow := flag.Bool("allow-natural", false, "Root固定後の自然特徴生成を明示")
	flag.Parse()
	if !*allow || *parent == "" || *background == "" || *spec == "" || *output == "" || *sourceDirectory == "" {
		fmt.Fprintln(os.Stderr, "必要フラグ不足又は自然生成未許可")
		os.Exit(1)
	}
	options := f.GenerateOptions{Parent: f.ParentRef{Path: *parent, Bytes: *parentBytes, SHA256: *parentSHA, DecodedSHA256: *decodedSHA}, Background: f.FileReference{Path: *background, SHA256: *backgroundSHA}, Specification: f.FileReference{Path: *spec, SHA256: *specSHA}, OutputDirectory: *output, All73: true}
	manifest, e := f.Generate(options)
	if e == nil {
		// ----------------------------------------
		// 自分の小Source全bytesだけを指紋化し、大きな自然入力を複写しません。
		e = filepath.WalkDir(*sourceDirectory, func(path string, d os.DirEntry, err error) error {
			if err != nil {
				return err
			}
			if d.IsDir() {
				return nil
			}
			if !strings.HasSuffix(path, ".go") && filepath.Base(path) != "go.mod" {
				return nil
			}
			body, err := os.ReadFile(path)
			if err != nil {
				return err
			}
			manifest.Sources = append(manifest.Sources, f.FileReference{Path: path, Bytes: int64(len(body)), SHA256: f.Digest(body)})
			return nil
		})
	}
	if e == nil {
		var body []byte
		body, e = json.MarshalIndent(manifest, "", "  ")
		if e == nil {
			body = append(body, '\n')
			e = os.WriteFile(filepath.Join(*output, "特徴の確認.json"), body, 0644)
		}
	}
	if e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
	fmt.Printf("特徴完了 %d場 %d足 %d公表\n", manifest.SceneCount, manifest.MinuteCount, manifest.PublicationCount)
}
