package features158

import (
	"fmt"
	"testing"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// known は人工の既知公表値を作ります。
//
// 引数: x(float64)。返り値: rules.Value。
func known(x float64) rules.Value { return rules.Value{Known: true, Value: x} }

// artificialPublication は旧Bankへ渡す人工公表を作ります。
//
// 引数: width(int)、end/time(float64)、index(int)。返り値: rules.Publication。
func artificialPublication(width int, end, time float64, index int) rules.Publication {
	f := rules.ChartFrame{ID: fmt.Sprintf("p%d/%g", width, end), SessionID: "人工", Contract: "限月A", Width: width, Start: end - float64(width), End: end, AvailableAt: end + 60, DeliveryAt: time, PriceKnown: true, VolumeKnown: true, OHLC: rules.OHLC{Open: 100, High: 110, Low: 90, Close: 102}, Volume: 1, Technical: rules.Technical{EMA8: known(103), EMA21: known(101), Gap: known(2), ATR: known(10), Histogram: known(2), RSI: known(60)}}
	return rules.Publication{Stamp: rules.Stamp{Time: time, Index: index, Line: index + 1}, Frame: rules.Frame{Frame: f, DMI: rules.DMI{PlusDI: known(30), MinusDI: known(10), ADX: known(25)}}}
}

// TestBatchとSnapshot凍結 は同Raw複数足・stale更新・entrymap未来非依存を検査します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestBatchとSnapshot凍結(t *testing.T) {
	p := NewProvider()
	if e := p.StartSession("人工", "限月A", 0, 5040); e != nil {
		t.Fatal(e)
	}
	q := Quote{Time: 300, Index: 20, SourceLine: 21, Last: 103}
	bs := []Minute{}
	for i := 0; i < 3; i++ {
		b := artificialMinute(i, 100+float64(i))
		b.Stamp = stampQuote(q)
		bs = append(bs, b)
	}
	c, e := p.Observe(q, bs, nil)
	if e != nil {
		t.Fatal(e)
	}
	if len(c.Updates) != 3 || c.Updates[0].ID != "m0" || c.Updates[2].ID != "m2" {
		t.Fatal("batch順序差")
	}
	if c.Updates[0].Values["m1.close"].Known || c.Updates[1].Values["m1.close"].Known {
		t.Fatal("失効catchupを新鮮値へ")
	}
	assertNumber(t, c.Values["m1.close"].Value, 102)
	old := c.Values
	b := artificialMinute(3, 200)
	q = Quote{Time: 301, Index: 21, SourceLine: 22, Last: 200}
	b.Stamp = stampQuote(q)
	if _, e = p.Observe(q, []Minute{b}, nil); e != nil {
		t.Fatal(e)
	}
	assertNumber(t, old["m1.close"].Value, 102)
	q.Time = 420
	c, e = p.Current(q)
	if e != nil {
		t.Fatal(e)
	}
	if c.Values["m1.close"].Known || len(c.Updates) != 0 {
		t.Fatal("期限等号又は架空イベント")
	}
	assertNumber(t, old["m1.close"].Value, 102)
	b = artificialMinute(4, 100)
	b.Stamp.Time = 500
	b.Stamp.Index = 20
	b.Stamp.SourceLine = 23
	q.Time = 500
	q.Index = 22
	q.SourceLine = 23
	if _, e = p.Observe(q, []Minute{b}, nil); e == nil {
		t.Fatal("同時刻未来index許容")
	}
}

// Test旧MTF値と実前 は保存値同体・宣言Previous厳密照合・早期限を検査します。
//
// 引数: t(*testing.T)。返り値: なし。
func Test旧MTF値と実前(t *testing.T) {
	p := NewProvider()
	_ = p.StartSession("人工", "限月A", 0, 5040)
	pub := artificialPublication(300, 300, 360, 10)
	q := Quote{Time: 360, Index: 10, SourceLine: 11, Last: 102}
	c, e := p.Observe(q, nil, []rules.Publication{pub})
	if e != nil {
		t.Fatal(e)
	}
	assertNumber(t, c.Values["m5.hist"].Value, 2)
	if c.Values["m5.hist_delta"].Known {
		t.Fatal("実前なし補完")
	}
	q.Time = 660
	q.Index = 11
	q.SourceLine = 12
	c, e = p.Current(q)
	if e != nil {
		t.Fatal(e)
	}
	if c.Values["m5.hist"].Known {
		t.Fatal("旧Source早期限を延命")
	}
	pub2 := artificialPublication(300, 600, 660, 11)
	pub2.Frame.Frame.Technical.Histogram = known(5)
	pub2.Frame.Frame.Technical.PreviousHistogram = known(2)
	pub2.Frame.Frame.Technical.PreviousRSI = known(60)
	pub2.Frame.DMI.PreviousADX = known(25)
	c, e = p.Observe(q, nil, []rules.Publication{pub2})
	if e != nil {
		t.Fatal(e)
	}
	assertNumber(t, c.Values["m5.hist_delta"].Value, 3)
	assertNumber(t, c.Values["m5.adx_delta"].Value, 0)
	pub3 := artificialPublication(300, 900, 960, 12)
	pub3.Frame.Frame.Technical.PreviousHistogram = known(4)
	q.Time = 960
	q.Index = 12
	q.SourceLine = 13
	if _, e = p.Observe(q, nil, []rules.Publication{pub3}); e == nil {
		t.Fatal("Previous不一致を許容")
	}
}

// Test同限月carryと当場cold はBB窓carry/異限月resetとm1resetを確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func Test同限月carryと当場cold(t *testing.T) {
	p := NewProvider()
	_ = p.StartSession("人工", "限月A", 0, 20040)
	for i := 1; i <= 19; i++ {
		pub := artificialPublication(900, float64(i*900), float64(i*900+60), i)
		q := Quote{Time: pub.Stamp.Time, Index: int64(i), SourceLine: int64(i + 1), Last: 102}
		if _, e := p.Observe(q, nil, []rules.Publication{pub}); e != nil {
			t.Fatal(e)
		}
	}
	if e := p.StartSession("次場", "限月A", 21000, 25020); e != nil {
		t.Fatal(e)
	}
	pub := artificialPublication(900, 21900, 21960, 1)
	pub.Frame.Frame.SessionID = "次場"
	q := Quote{Time: 21960, Index: 1, SourceLine: 2, Last: 102}
	c, e := p.Observe(q, nil, []rules.Publication{pub})
	if e != nil {
		t.Fatal(e)
	}
	if !c.Values["m15.bb_mean"].Known || c.Values["m1.ema21"].Known {
		t.Fatal("同限月carry/当場cold差")
	}
	if e = p.StartSession("別限月", "限月B", 26000, 30020); e != nil {
		t.Fatal(e)
	}
	pub = artificialPublication(900, 26900, 26960, 1)
	pub.Frame.Frame.SessionID = "別限月"
	pub.Frame.Frame.Contract = "限月B"
	q.Time = 26960
	c, e = p.Observe(q, nil, []rules.Publication{pub})
	if e != nil {
		t.Fatal(e)
	}
	if c.Values["m15.bb_mean"].Known {
		t.Fatal("異限月窓carry")
	}
}
