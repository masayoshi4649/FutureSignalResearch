package features158

import (
	"bufio"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"os"
)

// ParentRef は共有gzipを解凍ファイルへ複写せず固定する参照です。
type ParentRef struct {
	Path          string `json:"path"`
	Bytes         int64  `json:"bytes"`
	SHA256        string `json:"sha256"`
	DecodedSHA256 string `json:"decoded_sha256"`
}

// ParentEvidence は全gzip/JSONを読み切った時点でのみ成功になる証跡です。
type ParentEvidence struct {
	Reference     ParentRef                  `json:"reference"`
	StatBefore    map[string]int64           `json:"stat_before"`
	StatAfter     map[string]int64           `json:"stat_after"`
	ActualSHA256  string                     `json:"actual_sha256"`
	DecodedSHA256 string                     `json:"decoded_sha256"`
	DecodedBytes  int64                      `json:"decoded_bytes"`
	Scenes        int                        `json:"scenes"`
	Top           map[string]json.RawMessage `json:"top"`
}

type countReader struct {
	reader io.Reader
	count  int64
}

// Read は解凍bytes数を数えながら同じデータだけを呼出側へ返します。
//
// 引数: p([]byte)。返り値: int/errorはio.Readerと同じ契約です。
func (c *countReader) Read(p []byte) (int, error) {
	n, err := c.reader.Read(p)
	c.count += int64(n)
	return n, err
}

// shaFormat は空や大文字を許容せず固定SHAを検査します。
//
// 引数: value(string)。返り値: boolです。
func shaFormat(value string) bool {
	if len(value) != 64 {
		return false
	}
	for _, c := range value {
		if !(c >= '0' && c <= '9' || c >= 'a' && c <= 'f') {
			return false
		}
	}
	return true
}

// stat は価格を含まない入力ファイルのサイズと変更時計を返します。
//
// 引数: info(os.FileInfo)。返り値: map[string]int64です。
func stat(info os.FileInfo) map[string]int64 {
	return map[string]int64{"bytes": info.Size(), "mtime_ns": info.ModTime().UnixNano()}
}

// ReadParent は共有147gzipを場単位で渡し圧縮/解凍の両指紋を確認します。
//
// 引数: ref(ParentRef)、visit(func(json.RawMessage)error)は一場の一時JSONを受けます。
// 返り値: ParentEvidence/errorです。visit成功だけでは全入力成功ではありません。
// 全SHA/CRC/stat成功後だけ上位が正式successを確定し、visit内で正式成果をcommitしません。
func ReadParent(ref ParentRef, visit func(json.RawMessage) error) (ParentEvidence, error) {
	out := ParentEvidence{Reference: ref, Top: map[string]json.RawMessage{}}
	if ref.Path == "" || ref.Bytes <= 0 || !shaFormat(ref.SHA256) || !shaFormat(ref.DecodedSHA256) || visit == nil {
		return out, fmt.Errorf("親gzip参照又はcallback不正")
	}
	f, err := os.Open(ref.Path)
	if err != nil {
		return out, err
	}
	defer f.Close()
	before, err := f.Stat()
	if err != nil {
		return out, err
	}
	out.StatBefore = stat(before)
	if before.Size() != ref.Bytes {
		return out, fmt.Errorf("親gzipサイズ差")
	}
	physical := sha256.New()
	buffer := bufio.NewReader(io.TeeReader(f, physical))
	gz, err := gzip.NewReader(buffer)
	if err != nil {
		return out, err
	}
	defer gz.Close()
	decoded := sha256.New()
	counter := &countReader{reader: io.TeeReader(gz, decoded)}
	decoder := json.NewDecoder(counter)
	token, err := decoder.Token()
	if err != nil {
		return out, err
	}
	if token != json.Delim('{') {
		return out, fmt.Errorf("親JSONがobjectでない")
	}
	seen := map[string]bool{}
	// ----------------------------------------
	// 巨大なscenesだけ一場単位で解釈し、未知topキーも重複を許しません。
	for decoder.More() {
		keyToken, err := decoder.Token()
		if err != nil {
			return out, err
		}
		key, ok := keyToken.(string)
		if !ok || seen[key] {
			return out, fmt.Errorf("親JSONのtopキー重複又は不正")
		}
		seen[key] = true
		if key != "scenes" {
			var value json.RawMessage
			if err = decoder.Decode(&value); err != nil {
				return out, err
			}
			out.Top[key] = value
			continue
		}
		token, err = decoder.Token()
		if err != nil {
			return out, err
		}
		if token != json.Delim('[') {
			return out, fmt.Errorf("親scenesが配列でない")
		}
		for decoder.More() {
			var scene json.RawMessage
			if err = decoder.Decode(&scene); err != nil {
				return out, err
			}
			if len(scene) == 0 || scene[0] != '{' {
				return out, fmt.Errorf("親sceneがobjectでない")
			}
			if err = visit(scene); err != nil {
				return out, err
			}
			out.Scenes++
		}
		token, err = decoder.Token()
		if err != nil {
			return out, err
		}
		if token != json.Delim(']') {
			return out, fmt.Errorf("親scenes終端不正")
		}
	}
	token, err = decoder.Token()
	if err != nil {
		return out, err
	}
	if token != json.Delim('}') || !seen["scenes"] {
		return out, fmt.Errorf("親JSON終端又はscenes不足")
	}
	var extra any
	if err = decoder.Decode(&extra); err != io.EOF {
		if err == nil {
			err = fmt.Errorf("親JSON末尾に別の値")
		}
		return out, err
	}
	// ----------------------------------------
	// gzip終端CRCと残り物理bytesも含め、全ての指紋が一致してから成功を返します。
	if _, err = io.Copy(io.Discard, gz); err != nil {
		return out, err
	}
	if _, err = io.Copy(io.Discard, buffer); err != nil {
		return out, err
	}
	out.ActualSHA256 = hex.EncodeToString(physical.Sum(nil))
	out.DecodedSHA256 = hex.EncodeToString(decoded.Sum(nil))
	out.DecodedBytes = counter.count
	after, err := f.Stat()
	if err != nil {
		return out, err
	}
	pathAfter, err := os.Stat(ref.Path)
	if err != nil {
		return out, err
	}
	out.StatAfter = stat(after)
	if out.ActualSHA256 != ref.SHA256 || out.DecodedSHA256 != ref.DecodedSHA256 || !os.SameFile(before, pathAfter) || before.Size() != after.Size() || before.Size() != pathAfter.Size() || !before.ModTime().Equal(after.ModTime()) || !before.ModTime().Equal(pathAfter.ModTime()) {
		return out, fmt.Errorf("親gzipのSHA又は前後stat差")
	}
	return out, nil
}
