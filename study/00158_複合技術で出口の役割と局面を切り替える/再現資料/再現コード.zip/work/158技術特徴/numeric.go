package features158

import (
	"fmt"
	"math"
)

// smooth は最初の期間SMAで初期化するEMA/RMAの私有状態です。
type smooth struct {
	Period, Count int
	Sum, Value    float64
	Known         bool
}

// update は146由来のSMA seed後EMA又はWilder更新を行います。
//
// 引数: x(float64)、wilder(bool)。返り値: *float64（助走中nil）。
func (s *smooth) update(x float64, wilder bool) *float64 {
	if !s.Known {
		s.Count++
		s.Sum += x
		if s.Count == s.Period {
			s.Value = s.Sum / float64(s.Period)
			s.Known = true
		}
	} else if wilder {
		s.Value = (s.Value*float64(s.Period-1) + x) / float64(s.Period)
	} else {
		s.Value += 2 / float64(s.Period+1) * (x - s.Value)
	}
	if !s.Known {
		return nil
	}
	return ptr(s.Value)
}

// ptr は有限数値の独立copyだけを返します。
//
// 引数: x(float64)。返り値: *float64。非有限はpanicとして上位品質検査へ残します。
func ptr(x float64) *float64 {
	if math.IsNaN(x) || math.IsInf(x, 0) {
		panic("非有限特徴値")
	}
	v := x
	return &v
}

// finite は浮動値が全て有限であることを確認します。
//
// 引数: x(...float64)。返り値: bool。
func finite(x ...float64) bool {
	for _, v := range x {
		if math.IsNaN(v) || math.IsInf(v, 0) {
			return false
		}
	}
	return true
}

// delta は両端既知の実差を返し、未知を補いません。
//
// 引数: a/b(*float64)。返り値: *float64。
func delta(a, b *float64) *float64 {
	if a == nil || b == nil {
		return nil
	}
	return ptr(*a - *b)
}

var M1Keys = []string{"open", "high", "low", "close", "previous_close", "body", "upper_wick", "lower_wick", "range", "body_ratio", "bar_start", "bar_end",
	"tr", "atr14", "previous_atr14", "ema8", "ema21", "ema8_delta", "ema21_delta", "gap", "macd", "macd_signal", "hist", "hist_delta", "rsi14", "rsi_delta",
	"di_plus", "di_minus", "di_difference", "adx14", "adx_delta", "bb_mean", "bb_sd", "bb_width", "previous_bb_width", "bb_width_delta", "zscore", "zscore_delta",
	"two_bar_range", "trd_mean20", "trd_sd20", "er10", "er20", "chop14", "high5", "low5", "high10", "low10", "high20", "low20",
	"prior_high5", "prior_low5", "prior_high10", "prior_low10", "prior_high20", "prior_low20", "volume", "rvol", "relative_volume20", "volume_relative_prior3",
	"obv_delta5", "obv_delta15", "obv_delta30", "cmf20", "cmf20_delta", "session_vwap_proxy", "hlc3_vwma20", "session_volume",
	"supertrend_line", "supertrend_direction", "psar_line", "psar_direction", "ck_high_stop", "ck_low_stop"}

type MinuteState struct {
	session, contract                                                                   string
	start, end, next                                                                    float64
	started                                                                             bool
	chain, all                                                                          []Minute
	trs                                                                                 []float64
	ema8, ema21, ema12, ema26, signal, gain, loss, atr14, atr10, dmtr, plus, minus, adx smooth
	previous                                                                            map[string]*float64
	stReady                                                                             bool
	stUpper, stLower, stLine                                                            float64
	stDirection                                                                         int
	sarReady                                                                            bool
	sar, ep, af                                                                         float64
	sarDirection                                                                        int
	ckHigh, ckLow                                                                       []float64
	prefixKnown                                                                         bool
	prefixVolume, prefixWeighted                                                        float64
}

// NewMinuteState は当場だけの連続数値状態を作ります。
//
// 引数: session/contract(string)、start/end(float64)。返り値: *MinuteState/error。
func NewMinuteState(session, contract string, start, end float64) (*MinuteState, error) {
	if session == "" || contract == "" || !finite(start, end) || end <= start || math.Mod(end-start, 60) != 0 {
		return nil, fmt.Errorf("m1場格子不正")
	}
	s := &MinuteState{session: session, contract: contract, start: start, end: end, next: start, started: true, prefixKnown: true}
	s.resetPrice()
	return s, nil
}

// resetPrice は欠分を飛ばして価格助走を繋がないよう全価格状態を初期化します。
//
// 引数: なし。返り値: なし。量の全slot列とsession prefixは消しません。
func (s *MinuteState) resetPrice() {
	s.chain = nil
	s.trs = nil
	s.previous = map[string]*float64{}
	s.ema8 = smooth{Period: 8}
	s.ema21 = smooth{Period: 21}
	s.ema12 = smooth{Period: 12}
	s.ema26 = smooth{Period: 26}
	s.signal = smooth{Period: 9}
	s.gain = smooth{Period: 14}
	s.loss = smooth{Period: 14}
	s.atr14 = smooth{Period: 14}
	s.atr10 = smooth{Period: 10}
	s.dmtr = smooth{Period: 14}
	s.plus = smooth{Period: 14}
	s.minus = smooth{Period: 14}
	s.adx = smooth{Period: 14}
	s.stReady = false
	s.stDirection = 0
	s.sarReady = false
	s.sarDirection = 0
	s.ckHigh = nil
	s.ckLow = nil
}

// Add は欠分も含む正確な1分格子を一度だけ受け、全m1値を既知/nullで更新します。
//
// 引数: b(Minute)。返り値: map[string]*float64/error。旧knownへのfallbackをしません。
func (s *MinuteState) Add(b Minute) (map[string]*float64, error) {
	if !s.started || b.Session != s.session || b.Contract != s.contract || b.ID == "" || b.WidthSeconds != 60 || b.Start != s.next || b.End != b.Start+60 || b.End > s.end || b.AvailableAt != b.End+60 || !finite(b.Start, b.End, b.AvailableAt, b.Stamp.Time) || b.Stamp.Time < b.AvailableAt || b.Stamp.Index < 0 || b.Stamp.SourceLine < 1 {
		return nil, fmt.Errorf("canonical m1 scope/連続格子/時計差")
	}
	if b.PriceKnown && (!finite(b.OHLC.Open, b.OHLC.High, b.OHLC.Low, b.OHLC.Close) || b.OHLC.Low <= 0 || b.OHLC.High < b.OHLC.Low || b.OHLC.Open < b.OHLC.Low || b.OHLC.Open > b.OHLC.High || b.OHLC.Close < b.OHLC.Low || b.OHLC.Close > b.OHLC.High) {
		return nil, fmt.Errorf("既知m1価格形状差")
	}
	if b.VolumeKnown && (!finite(b.Volume) || b.Volume < 0) {
		return nil, fmt.Errorf("既知m1量差")
	}
	out := map[string]*float64{}
	for _, k := range M1Keys {
		out[k] = nil
	}
	out["bar_start"] = ptr(b.Start)
	out["bar_end"] = ptr(b.End)
	s.next = b.End
	s.all = append(s.all, b)
	if len(s.all) > 64 {
		s.all = s.all[len(s.all)-64:]
	}
	priceKnown := b.PriceKnown && b.Closed && !b.Missing
	if !priceKnown {
		s.resetPrice()
	} else {
		o := b.OHLC
		n := len(s.chain)
		var previous *Minute
		if n > 0 {
			previous = &s.chain[n-1]
		}
		tr := o.High - o.Low
		if previous != nil {
			p := previous.OHLC
			out["previous_close"] = ptr(p.Close)
			tr = math.Max(tr, math.Max(math.Abs(o.High-p.Close), math.Abs(o.Low-p.Close)))
			change := o.Close - p.Close
			s.gain.update(math.Max(change, 0), true)
			s.loss.update(math.Max(-change, 0), true)
			up, down := o.High-p.High, p.Low-o.Low
			positive, negative := 0., 0.
			if up > down && up > 0 {
				positive = up
			}
			if down > up && down > 0 {
				negative = down
			}
			s.dmtr.update(tr, true)
			s.plus.update(positive, true)
			s.minus.update(negative, true)
		}
		out["open"], out["high"], out["low"], out["close"] = ptr(o.Open), ptr(o.High), ptr(o.Low), ptr(o.Close)
		out["body"], out["upper_wick"], out["lower_wick"], out["range"] = ptr(o.Close-o.Open), ptr(o.High-math.Max(o.Open, o.Close)), ptr(math.Min(o.Open, o.Close)-o.Low), ptr(o.High-o.Low)
		if o.High > o.Low {
			out["body_ratio"] = ptr((o.Close - o.Open) / (o.High - o.Low))
		}
		out["tr"] = ptr(tr)
		out["previous_atr14"] = s.previous["atr14"]
		out["atr14"] = s.atr14.update(tr, true)
		atr10 := s.atr10.update(tr, true)
		out["ema8"], out["ema21"] = s.ema8.update(o.Close, false), s.ema21.update(o.Close, false)
		a12, a26 := s.ema12.update(o.Close, false), s.ema26.update(o.Close, false)
		out["ema8_delta"], out["ema21_delta"], out["gap"] = delta(out["ema8"], s.previous["ema8"]), delta(out["ema21"], s.previous["ema21"]), delta(out["ema8"], out["ema21"])
		if a12 != nil && a26 != nil {
			out["macd"] = ptr(*a12 - *a26)
			out["macd_signal"] = s.signal.update(*out["macd"], false)
			out["hist"] = delta(out["macd"], out["macd_signal"])
		}
		out["hist_delta"] = delta(out["hist"], s.previous["hist"])
		if s.gain.Known && s.loss.Known {
			rsi := 50.
			if s.loss.Value == 0 && s.gain.Value > 0 {
				rsi = 100
			} else if s.loss.Value > 0 {
				rsi = 100 - 100/(1+s.gain.Value/s.loss.Value)
			}
			out["rsi14"] = ptr(rsi)
		}
		out["rsi_delta"] = delta(out["rsi14"], s.previous["rsi14"])
		if s.dmtr.Known && s.dmtr.Value > 0 && s.plus.Value+s.minus.Value > 0 {
			p, m := 100*s.plus.Value/s.dmtr.Value, 100*s.minus.Value/s.dmtr.Value
			out["di_plus"], out["di_minus"], out["di_difference"] = ptr(p), ptr(m), ptr(p-m)
			out["adx14"] = s.adx.update(100*math.Abs(p-m)/(p+m), true)
		} else {
			s.adx = smooth{Period: 14}
		}
		out["adx_delta"] = delta(out["adx14"], s.previous["adx14"])
		s.chain = append(s.chain, b)
		s.trs = append(s.trs, tr)
		if len(s.chain) > 64 {
			s.chain = s.chain[1:]
		}
		if len(s.trs) > 64 {
			s.trs = s.trs[1:]
		}
		s.priceWindows(out)
		s.trendLines(out, previous, atr10, b)
	}
	s.quantityWindows(out, b)
	if priceKnown {
		s.previous = out
	}
	return out, nil
}

// moments は母分散の平均/標準偏差を返します。
//
// 引数: xs([]float64)。返り値: float64/float64。
func moments(xs []float64) (float64, float64) {
	mean := 0.
	for _, x := range xs {
		mean += x
	}
	mean /= float64(len(xs))
	v := 0.
	for _, x := range xs {
		v += (x - mean) * (x - mean)
	}
	return mean, math.Sqrt(v / float64(len(xs)))
}

// extremes は指定した連続足の高安を返します。
//
// 引数: bs([]Minute)。返り値: float64/float64。
func extremes(bs []Minute) (float64, float64) {
	hi, lo := bs[0].OHLC.High, bs[0].OHLC.Low
	for _, b := range bs {
		hi = math.Max(hi, b.OHLC.High)
		lo = math.Min(lo, b.OHLC.Low)
	}
	return hi, lo
}

// priceWindows は欠分reset後の実連続窓からBB/ER/CHOP/TRD/現含/前除外高安を作ります。
//
// 引数: out(map[string]*float64)。返り値: なし。
func (s *MinuteState) priceWindows(out map[string]*float64) {
	bs := s.chain
	n := len(bs)
	for _, w := range []int{5, 10, 20} {
		if n >= w {
			h, l := extremes(bs[n-w:])
			out[fmt.Sprintf("high%d", w)], out[fmt.Sprintf("low%d", w)] = ptr(h), ptr(l)
		}
		if n >= w+1 {
			h, l := extremes(bs[n-w-1 : n-1])
			out[fmt.Sprintf("prior_high%d", w)], out[fmt.Sprintf("prior_low%d", w)] = ptr(h), ptr(l)
		}
	}
	if n >= 20 {
		closes := []float64{}
		for _, b := range bs[n-20:] {
			closes = append(closes, b.OHLC.Close)
		}
		mean, sd := moments(closes)
		width := 4 * sd
		out["bb_mean"], out["bb_sd"], out["bb_width"] = ptr(mean), ptr(sd), ptr(width)
		if sd > 0 {
			out["zscore"] = ptr((bs[n-1].OHLC.Close - mean) / sd)
		}
	}
	out["previous_bb_width"] = s.previous["bb_width"]
	out["bb_width_delta"] = delta(out["bb_width"], s.previous["bb_width"])
	out["zscore_delta"] = delta(out["zscore"], s.previous["zscore"])
	if n >= 2 {
		h, l := extremes(bs[n-2:])
		out["two_bar_range"] = ptr(h - l)
	}
	if n >= 22 {
		xs := []float64{}
		for i := n - 20; i < n; i++ {
			h, l := extremes(bs[i-1 : i+1])
			h = math.Max(h, bs[i-2].OHLC.Close)
			l = math.Min(l, bs[i-2].OHLC.Close)
			xs = append(xs, h-l)
		}
		mean, sd := moments(xs)
		out["trd_mean20"], out["trd_sd20"] = ptr(mean), ptr(sd)
	}
	for _, w := range []int{10, 20} {
		if n >= w+1 {
			den := 0.
			for i := n - w; i < n; i++ {
				den += math.Abs(bs[i].OHLC.Close - bs[i-1].OHLC.Close)
			}
			if den > 0 {
				out[fmt.Sprintf("er%d", w)] = ptr(math.Abs(bs[n-1].OHLC.Close-bs[n-w-1].OHLC.Close) / den)
			}
		}
	}
	if n >= 14 {
		h, l := extremes(bs[n-14:])
		sum := 0.
		for _, v := range s.trs[len(s.trs)-14:] {
			sum += v
		}
		if h > l && sum > 0 {
			out["chop14"] = ptr(100 * math.Log10(sum/(h-l)) / math.Log10(14))
		}
	}
}
