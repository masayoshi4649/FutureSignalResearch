package features158

import (
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"math"
	"sort"
)

var MTFKeys = []string{"atr14", "previous_atr14", "tr", "open", "high", "low", "close", "ema8", "ema21", "ema8_delta", "ema21_delta", "gap", "hist", "hist_delta", "rsi14", "rsi_delta", "di_plus", "di_minus", "di_difference", "adx", "adx_delta", "bb_mean", "bb_sd", "bb_width", "rvol"}

type Provider struct {
	bank              *rules.Bank
	minute            *MinuteState
	session, contract string
	start, end        float64
	lastPub           map[int]rules.Publication
	refs              map[string]FeatureRef
	values            map[string]FeatureValue
	updated           Stamp
	eventID           string
	lastQuote         *Quote
	nextExpiry        float64
}

// NewProvider はMTF旧公表とm1私有数値を分けた生成器を作ります。
//
// 引数: なし。返り値: *Provider。旧数値を上位足から再計算しません。
func NewProvider() *Provider {
	return &Provider{bank: rules.NewBank(), lastPub: map[int]rules.Publication{}, refs: map[string]FeatureRef{}, values: map[string]FeatureValue{}}
}

// StartSession は旧MTF窓だけを同限月で継承しm1は当場の連続格子へ初期化します。
//
// 引数: session/contract(string)、start/end(float64)。返り値: error。
func (p *Provider) StartSession(session, contract string, start, end float64) error {
	if p.minute != nil && start < p.end {
		return fmt.Errorf("場順後退")
	}
	m, e := NewMinuteState(session, contract, start, end)
	if e != nil {
		return e
	}
	if e = p.bank.StartSession(session, contract); e != nil {
		return e
	}
	p.minute = m
	p.session = session
	p.contract = contract
	p.start = start
	p.end = end
	p.lastPub = map[int]rules.Publication{}
	p.refs = map[string]FeatureRef{}
	p.values = map[string]FeatureValue{}
	p.updated = Stamp{}
	p.eventID = ""
	p.lastQuote = nil
	p.nextExpiry = math.Inf(1)
	for _, k := range M1Keys {
		p.values["m1."+k] = FeatureValue{RefIDs: []string{}}
	}
	for _, w := range []int{5, 15, 30} {
		for _, k := range MTFKeys {
			p.values[fmt.Sprintf("m%d.%s", w, k)] = FeatureValue{RefIDs: []string{}}
		}
	}
	return nil
}

// stampQuote は現在原行を一意な公表Stampへ射影します。
//
// 引数: q(Quote)。返り値: Stamp。
func stampQuote(q Quote) Stamp { return Stamp{Time: q.Time, Index: q.Index, SourceLine: q.SourceLine} }

// before は同場の市場/配送3時計が全て現在以前かを確認します。
//
// 引数: a/b(Stamp)。返り値: bool。
func before(a, b Stamp) bool {
	return a.Time <= b.Time && a.Index <= b.Index && a.SourceLine <= b.SourceLine
}

// same は公表を一つの原行に厳密結合します。
//
// 引数: a/b(Stamp)。返り値: bool。
func same(a, b Stamp) bool { return a == b }

// publicationRef は再計算しない上位公表の因果情報を保存します。
//
// 引数: pub(rules.Publication)。返り値: FeatureRef。
func publicationRef(pub rules.Publication) FeatureRef {
	f := pub.Frame.Frame
	return FeatureRef{ID: f.ID, Session: f.SessionID, Contract: f.Contract, WidthSeconds: f.Width, Start: f.Start, End: f.End, AvailableAt: f.AvailableAt, Stamp: Stamp{Time: pub.Stamp.Time, Index: int64(pub.Stamp.Index), SourceLine: int64(pub.Stamp.Line)}, Source: "fixed122/118Bank"}
}

// makeValues は既知/未知の両方に同じ期限と原公表refを付けます。
//
// 引数: prefix(string)、raw(map[string]*float64)、refs([]FeatureRef)、until(float64)。返り値: map[string]FeatureValue。
func makeValues(prefix string, raw map[string]*float64, refs []FeatureRef, until float64) map[string]FeatureValue {
	ids := []string{}
	for _, r := range refs {
		ids = append(ids, r.ID)
	}
	out := map[string]FeatureValue{}
	for key, value := range raw {
		out[prefix+key] = FeatureValue{Value: value, Known: value != nil, ValidUntil: ptr(until), RefIDs: append([]string{}, ids...)}
	}
	return out
}

// expireUpdate は配送時点で既に失効したcatch-up足を現在の判断へ使わせません。
//
// 引数: update(FeatureUpdate)。返り値: FeatureUpdate。数値助走履歴自体は変更しません。
func expireUpdate(update FeatureUpdate) FeatureUpdate {
	for key, value := range update.Values {
		if value.ValidUntil != nil && update.At.Time >= *value.ValidUntil {
			value.Known, value.Value = false, nil
			update.Values[key] = value
		}
	}
	return update
}

// merge は公表されたunknownも明示上書きし最新値へ進めます。
//
// 引数: update(FeatureUpdate)。返り値: なし。
func (p *Provider) merge(update FeatureUpdate) {
	for key, value := range update.Values {
		p.values[key] = value
	}
	for _, ref := range update.Refs {
		p.refs[ref.ID] = ref
	}
	p.updated = update.At
	p.eventID = fmt.Sprintf("%s/%d/%d", p.session, update.At.Index, update.At.SourceLine)
	p.nextExpiry = 0
}

// background は旧Technical/DMIとBankのBB/RVOLを射影し実前差は当場連続だけへ限定します。
//
// 引数: pub(rules.Publication)、q(Quote)。返り値: FeatureUpdate/error。
func (p *Provider) background(pub rules.Publication, q Quote) (FeatureUpdate, error) {
	f := pub.Frame.Frame
	r := publicationRef(pub)
	at := stampQuote(q)
	if r.Session != p.session || r.Contract != p.contract || (f.Width != 300 && f.Width != 900 && f.Width != 1800) || !same(r.Stamp, at) || f.End > f.AvailableAt || f.AvailableAt > r.Stamp.Time {
		return FeatureUpdate{}, fmt.Errorf("旧MTF配送scope/時計差")
	}
	if e := p.bank.Add(pub); e != nil {
		return FeatureUpdate{}, e
	}
	snapshot, e := p.bank.Current(rules.Quote{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine), Last: q.Last})
	if e != nil {
		return FeatureUpdate{}, e
	}
	raw := map[string]*float64{}
	for _, k := range MTFKeys {
		raw[k] = nil
	}
	put := func(key string, v rules.Value) {
		if f.PriceKnown && v.Known {
			raw[key] = ptr(v.Value)
		}
	}
	t, d := f.Technical, pub.Frame.DMI
	put("atr14", t.ATR)
	put("previous_atr14", t.PreviousATR)
	put("tr", t.TR)
	put("ema8", t.EMA8)
	put("ema21", t.EMA21)
	put("ema8_delta", t.EMA8Delta)
	put("ema21_delta", t.EMA21Delta)
	put("gap", t.Gap)
	put("hist", t.Histogram)
	put("rsi14", t.RSI)
	put("di_plus", d.PlusDI)
	put("di_minus", d.MinusDI)
	put("adx", d.ADX)
	if raw["di_plus"] != nil && raw["di_minus"] != nil {
		raw["di_difference"] = delta(raw["di_plus"], raw["di_minus"])
	}
	refs := []FeatureRef{r}
	if f.PriceKnown {
		raw["open"], raw["high"], raw["low"], raw["close"] = ptr(f.OHLC.Open), ptr(f.OHLC.High), ptr(f.OHLC.Low), ptr(f.OHLC.Close)
	}
	if prior, ok := p.lastPub[f.Width]; ok && prior.Frame.Frame.SessionID == f.SessionID && prior.Frame.Frame.End == f.Start {
		old := prior.Frame.Frame.Technical
		refs = append(refs, publicationRef(prior))
		if old.Histogram.Known && t.PreviousHistogram.Known {
			if old.Histogram.Value != t.PreviousHistogram.Value {
				return FeatureUpdate{}, fmt.Errorf("旧MTF前Hist不一致")
			}
			if raw["hist"] != nil {
				raw["hist_delta"] = ptr(*raw["hist"] - old.Histogram.Value)
			}
		}
		if prior.Frame.DMI.ADX.Known && d.PreviousADX.Known {
			if prior.Frame.DMI.ADX.Value != d.PreviousADX.Value {
				return FeatureUpdate{}, fmt.Errorf("旧MTF前ADX不一致")
			}
			if raw["adx"] != nil {
				raw["adx_delta"] = ptr(*raw["adx"] - prior.Frame.DMI.ADX.Value)
			}
		}
		if old.RSI.Known && t.PreviousRSI.Known && raw["rsi14"] != nil {
			if old.RSI.Value != t.PreviousRSI.Value {
				return FeatureUpdate{}, fmt.Errorf("旧MTF前RSI不一致")
			}
			raw["rsi_delta"] = ptr(*raw["rsi14"] - old.RSI.Value)
		}
	}
	if f.Width == 900 && snapshot.BB15.Known && f.PriceKnown {
		b := snapshot.BB15
		raw["bb_mean"], raw["bb_sd"], raw["bb_width"] = ptr(b.Mean), ptr(b.Sigma), ptr(b.Upper-b.Lower)
	}
	if f.Width == 300 && snapshot.RVOL5.Known {
		raw["rvol"] = ptr(snapshot.RVOL5.Value)
	}
	p.lastPub[f.Width] = pub
	return FeatureUpdate{ID: f.ID, At: at, WidthSeconds: f.Width, Source: r.Source, PriceKnown: f.PriceKnown, VolumeKnown: f.VolumeKnown, Values: makeValues(fmt.Sprintf("m%d.", f.Width/60), raw, refs, f.End+float64(f.Width)+60), Refs: refs}, nil
}

// Observe は同Raw全背景→元順m1を適用し、1回のFSM用Contextへbatchをまとめます。
//
// 引数: q(Quote)、minutes([]Minute)、pubs([]rules.Publication)。返り値: Context/error。
func (p *Provider) Observe(q Quote, minutes []Minute, pubs []rules.Publication) (Context, error) {
	at := stampQuote(q)
	if p.minute == nil || !finite(q.Time, q.Last) || q.Last <= 0 || q.Index < 0 || q.SourceLine < 1 || q.Time < p.start || q.Time >= p.end {
		return Context{}, fmt.Errorf("現在Quote/scope差")
	}
	if p.lastQuote != nil && !before(stampQuote(*p.lastQuote), at) {
		return Context{}, fmt.Errorf("現在Quote後退")
	}
	// ----------------------------------------
	// 既返却Context/取得時snapshotのmapは未来の公表で変更しません。
	if len(pubs)+len(minutes) > 0 {
		copyValues := make(map[string]FeatureValue, len(p.values))
		for key, value := range p.values {
			copyValues[key] = value
		}
		p.values = copyValues
	}
	updates := []FeatureUpdate{}
	for _, pub := range pubs {
		u, e := p.background(pub, q)
		if e != nil {
			return Context{}, e
		}
		u = expireUpdate(u)
		p.merge(u)
		updates = append(updates, u)
	}
	for _, bar := range minutes {
		if !same(bar.Stamp, at) {
			return Context{}, fmt.Errorf("m1は初配送Rawだけへ適用")
		}
		raw, e := p.minute.Add(bar)
		if e != nil {
			return Context{}, e
		}
		r := FeatureRef{ID: bar.ID, Session: bar.Session, Contract: bar.Contract, WidthSeconds: 60, Start: bar.Start, End: bar.End, AvailableAt: bar.AvailableAt, Stamp: bar.Stamp, Source: "canonical_csv147"}
		u := expireUpdate(FeatureUpdate{ID: bar.ID, At: at, WidthSeconds: 60, Source: r.Source, PriceKnown: validPrice(bar), VolumeKnown: validVolume(bar), Values: makeValues("m1.", raw, []FeatureRef{r}, bar.End+180), Refs: []FeatureRef{r}})
		p.merge(u)
		updates = append(updates, u)
	}
	x := q
	p.lastQuote = &x
	c, e := p.Current(q)
	c.Updates = updates
	return c, e
}

// Current は公表イベントを増やさず現在qで期限切れをunknownへ置換します。
//
// 引数: q(Quote)。返り値: Context/error。返却mapは読取専用です。
func (p *Provider) Current(q Quote) (Context, error) {
	at := stampQuote(q)
	if p.minute == nil || !finite(q.Time, q.Last) || q.Last <= 0 || q.Index < 0 || q.SourceLine < 1 || q.Time < p.start || q.Time >= p.end || p.lastQuote != nil && !before(stampQuote(*p.lastQuote), at) {
		return Context{}, fmt.Errorf("Currentが最新配送より前")
	}
	if q.Time >= p.nextExpiry {
		copyValues := map[string]FeatureValue{}
		p.nextExpiry = math.Inf(1)
		for key, value := range p.values {
			if value.ValidUntil != nil && q.Time >= *value.ValidUntil {
				value.Known = false
				value.Value = nil
			} else if value.ValidUntil != nil && *value.ValidUntil < p.nextExpiry {
				p.nextExpiry = *value.ValidUntil
			}
			copyValues[key] = value
		}
		p.values = copyValues
	}
	refs := []FeatureRef{}
	used := map[string]bool{}
	for _, value := range p.values {
		for _, id := range value.RefIDs {
			if !used[id] {
				r := p.refs[id]
				if r.Session == p.session && !before(r.Stamp, at) {
					return Context{}, fmt.Errorf("未来特徴ref")
				}
				refs = append(refs, r)
				used[id] = true
			}
		}
	}
	sort.Slice(refs, func(i, j int) bool { return refs[i].ID < refs[j].ID })
	return Context{Session: p.session, Contract: p.contract, At: at, UpdatedAt: p.updated, EventID: p.eventID, Values: p.values, Refs: refs, Updates: []FeatureUpdate{}}, nil
}

// CarryOnly は前場テープ終端後の旧公表だけを次場のBank窓へ供給します。
//
// 引数: pubs([]rules.Publication)。返り値: error。現在場の出口特徴イベントを作りません。
func (p *Provider) CarryOnly(pubs []rules.Publication) error {
	for _, pub := range pubs {
		f := pub.Frame.Frame
		if f.SessionID != p.session || f.Contract != p.contract || pub.Stamp.Time < p.end {
			return fmt.Errorf("carry-onlyは当場テープ終端以後")
		}
		if e := p.bank.Add(pub); e != nil {
			return e
		}
	}
	return nil
}
