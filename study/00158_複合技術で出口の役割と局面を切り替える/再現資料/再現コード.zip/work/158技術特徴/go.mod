module features158

go 1.24.2

require (
 pricetape157 v0.0.0
 github.com/masayoshi4649/SessionTradeExecuter/entryrules118 v0.0.0
)

replace pricetape157 => ../157固定入口と価格経路
replace github.com/masayoshi4649/SessionTradeExecuter/entryrules118 => ../118複数技法の入口条件
