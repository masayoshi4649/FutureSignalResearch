package features158

import (
	"bytes"
	"compress/gzip"
	"encoding/json"
	"io"
	"os"
	"path/filepath"
	"testing"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// fixtureGeneration は一場5格子の人工gzip/公表入力を一時領域へ作ります。
//
// 引数: t(*testing.T)。返り値: GenerateOptions。自然入力は開きません。
func fixtureGeneration(t *testing.T) GenerateOptions {
	t.Helper()
	dir := t.TempDir()
	raw := FileReference{Path: "共用の原板.gz", SHA256: digest([]byte("原板本文は不要"))}
	scene := parentScene{Success: true, Session: "人工", Contract: "限月A", Start: 0, End: 600, ExecutionEnd: 300, ForceClose: 240, Raw: raw, ActualSHA: raw.SHA256}
	for i := 0; i < 5; i++ {
		b := artificialMinute(i, 100+float64(i))
		q := Quote{Time: b.Stamp.Time, Index: b.Stamp.Index, SourceLine: b.Stamp.SourceLine, Last: b.OHLC.Close, Bid: b.OHLC.Close - 1, Ask: b.OHLC.Close + 1, QuoteOK: true}
		scene.Bars = append(scene.Bars, struct {
			Bar     Minute `json:"bar"`
			Context struct {
				At Quote `json:"at"`
			} `json:"context"`
		}{Bar: b, Context: struct {
			At Quote `json:"at"`
		}{q}})
	}
	pub := artificialPublication(300, 0, 90, 0)
	background := struct {
		Trial  int               `json:"trial"`
		Scenes []backgroundScene `json:"scenes"`
	}{122, []backgroundScene{{Session: scene.Session, Contract: scene.Contract, Start: scene.Start, End: scene.End, ForceClose: scene.ForceClose, Raw: raw, Publications: []rules.Publication{pub}}}}
	body, e := json.Marshal(background)
	if e != nil {
		t.Fatal(e)
	}
	bp := filepath.Join(dir, "背景.json")
	if e = os.WriteFile(bp, body, 0644); e != nil {
		t.Fatal(e)
	}
	parentBody, e := json.Marshal(struct {
		Success bool          `json:"success"`
		Trial   int           `json:"trial"`
		Scenes  []parentScene `json:"scenes"`
	}{true, 147, []parentScene{scene}})
	if e != nil {
		t.Fatal(e)
	}
	var buffer bytes.Buffer
	gz := gzip.NewWriter(&buffer)
	_, _ = gz.Write(parentBody)
	if e = gz.Close(); e != nil {
		t.Fatal(e)
	}
	pp := filepath.Join(dir, "親.json.gz")
	if e = os.WriteFile(pp, buffer.Bytes(), 0644); e != nil {
		t.Fatal(e)
	}
	sp := filepath.Join(dir, "条件.md")
	sb := []byte("人工条件")
	if e = os.WriteFile(sp, sb, 0644); e != nil {
		t.Fatal(e)
	}
	return GenerateOptions{Parent: ParentRef{Path: pp, Bytes: int64(buffer.Len()), SHA256: digest(buffer.Bytes()), DecodedSHA256: digest(parentBody)}, Background: FileReference{Path: bp, SHA256: digest(body)}, Specification: FileReference{Path: sp, SHA256: digest(sb)}, OutputDirectory: filepath.Join(dir, "出力")}
}

// Test場単位生成とgzip完読 は同原行統合/末尾非配送/CRC両SHAを人工入力で確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func Test場単位生成とgzip完読(t *testing.T) {
	o := fixtureGeneration(t)
	m, e := Generate(o)
	if e != nil {
		t.Fatal(e)
	}
	if !m.Success || m.SceneCount != 1 || m.MinuteCount != 5 || m.PublicationCount != 1 || m.RawRead || m.FinancialLabelsUsed {
		t.Fatal("生成分母/境界差")
	}
	s := m.Scenes[0]
	if s.Rows != 4 || s.MinuteUpdates != 3 || s.TailMinutes != 2 || s.BackgroundUpdates != 1 {
		t.Fatalf("イベント/末尾分母差:%+v", s)
	}
	physical, e := os.ReadFile(filepath.Join(o.OutputDirectory, s.Path))
	if e != nil {
		t.Fatal(e)
	}
	gz, e := gzip.NewReader(bytes.NewReader(physical))
	if e != nil {
		t.Fatal(e)
	}
	decoded, e := io.ReadAll(gz)
	if e != nil {
		t.Fatal(e)
	}
	if e = gz.Close(); e != nil {
		t.Fatal(e)
	}
	if digest(physical) != s.SHA256 || digest(decoded) != s.DecodedSHA256 || int64(len(decoded)) != s.DecodedBytes {
		t.Fatal("出力gzip指紋差")
	}
	lines := bytes.Split(bytes.TrimSpace(decoded), []byte{'\n'})
	for i, line := range lines {
		var c Context
		if e = json.Unmarshal(line, &c); e != nil {
			t.Fatal(e)
		}
		if c.At.Time >= 300 || len(c.Updates) != 1 {
			t.Fatal("末尾/イベント差")
		}
		if i == 0 && c.Values["m1.close"].Known {
			t.Fatal("未来m1混入")
		}
	}
	if _, e = Generate(o); e == nil {
		t.Fatal("既出力上書き許容")
	}
}

// Test親終端不正は成功禁止 は末尾SHA/CRC不正でも途中場の成功を完了扱いしません。
//
// 引数: t(*testing.T)。返り値: なし。
func Test親終端不正は成功禁止(t *testing.T) {
	o := fixtureGeneration(t)
	o.Parent.DecodedSHA256 = digest([]byte("異なる解凍"))
	if _, e := Generate(o); e == nil {
		t.Fatal("decoded差を許容")
	}
	if _, e := os.Stat(filepath.Join(o.OutputDirectory, "特徴の確認.json")); !os.IsNotExist(e) {
		t.Fatal("失敗完了票")
	}
	o = fixtureGeneration(t)
	body, e := os.ReadFile(o.Parent.Path)
	if e != nil {
		t.Fatal(e)
	}
	body[len(body)-5] ^= 1
	if e = os.WriteFile(o.Parent.Path, body, 0644); e != nil {
		t.Fatal(e)
	}
	o.Parent.SHA256 = digest(body)
	if _, e = Generate(o); e == nil {
		t.Fatal("gzipCRC破損を許容")
	}
}
