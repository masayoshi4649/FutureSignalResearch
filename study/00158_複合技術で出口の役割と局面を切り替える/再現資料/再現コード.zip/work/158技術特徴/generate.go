package features158

import (
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"reflect"
	"sort"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

const BackgroundSHA = "6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec"
const SpecSHA = "f32efc55b5fc114534b601b981e3c961d12037e5b5462d71769634402789cc17"

type FileReference struct {
	Path   string `json:"path"`
	Bytes  int64  `json:"bytes,omitempty"`
	SHA256 string `json:"sha256"`
}

type SceneFeatures struct {
	Session           string        `json:"session"`
	Contract          string        `json:"contract"`
	Start             float64       `json:"start"`
	End               float64       `json:"end"`
	ContinuousEnd     float64       `json:"continuous_end"`
	ForceClose        float64       `json:"force_close"`
	Raw               FileReference `json:"raw"`
	Path              string        `json:"path"`
	Bytes             int64         `json:"bytes"`
	SHA256            string        `json:"sha256"`
	DecodedSHA256     string        `json:"decoded_sha256"`
	DecodedBytes      int64         `json:"decoded_bytes"`
	Rows              int           `json:"rows"`
	MinuteUpdates     int           `json:"minute_updates"`
	BackgroundUpdates int           `json:"background_updates"`
	TailMinutes       int           `json:"tail_minutes"`
	CarryPublications int           `json:"carry_publications"`
}

type FeatureManifest struct {
	Catalog             []string        `json:"catalog"`
	Schema              string          `json:"schema"`
	Trial               int             `json:"trial"`
	Success             bool            `json:"success"`
	Parent              ParentEvidence  `json:"parent"`
	Background          FileReference   `json:"background"`
	Specification       FileReference   `json:"specification"`
	Sources             []FileReference `json:"sources"`
	Scenes              []SceneFeatures `json:"scenes"`
	SceneCount          int             `json:"scene_count"`
	MinuteCount         int             `json:"minute_count"`
	PublicationCount    int             `json:"publication_count"`
	RawRead             bool            `json:"raw_read"`
	FinancialLabelsUsed bool            `json:"financial_labels_used"`
}

type GenerateOptions struct {
	Parent          ParentRef
	Background      FileReference
	Specification   FileReference
	OutputDirectory string
	All73           bool
}

type backgroundScene struct {
	Session      string              `json:"session"`
	Contract     string              `json:"contract"`
	Start        float64             `json:"start"`
	End          float64             `json:"end"`
	ForceClose   float64             `json:"force_close"`
	Raw          FileReference       `json:"raw"`
	Publications []rules.Publication `json:"publications"`
}

type parentScene struct {
	Success      bool          `json:"success"`
	Session      string        `json:"session"`
	Contract     string        `json:"contract"`
	Start        float64       `json:"start"`
	End          float64       `json:"end"`
	ForceClose   float64       `json:"force_close"`
	ExecutionEnd float64       `json:"execution_end"`
	Raw          FileReference `json:"raw"`
	ActualSHA    string        `json:"actual_sha256"`
	Bars         []struct {
		Bar     Minute `json:"bar"`
		Context struct {
			At Quote `json:"at"`
		} `json:"context"`
	} `json:"bars"`
}

// digest は入力bytesのSHA256を小文字文字列で返します。
//
// 引数: body([]byte)。返り値: string。
func digest(body []byte) string { h := sha256.Sum256(body); return hex.EncodeToString(h[:]) }

// Digest はCLIの小Source指紋用にSHA256を返します。
//
// 引数: body([]byte)。返り値: string。
func Digest(body []byte) string { return digest(body) }

// checkedBytes は全bytesと前後statを照合して固定された小/中入力だけを読みます。
//
// 引数: ref(FileReference)。返り値: []byte/error。価格CSV/Rawを開きません。
func checkedBytes(ref FileReference) ([]byte, error) {
	if ref.Path == "" || !shaFormat(ref.SHA256) {
		return nil, fmt.Errorf("入力参照不正")
	}
	before, e := os.Stat(ref.Path)
	if e != nil {
		return nil, e
	}
	body, e := os.ReadFile(ref.Path)
	if e != nil {
		return nil, e
	}
	after, e := os.Stat(ref.Path)
	if e != nil {
		return nil, e
	}
	if digest(body) != ref.SHA256 || ref.Bytes > 0 && int64(len(body)) != ref.Bytes || !os.SameFile(before, after) || before.Size() != after.Size() || !before.ModTime().Equal(after.ModTime()) {
		return nil, fmt.Errorf("入力SHA/stat差:%s", ref.Path)
	}
	return body, nil
}

// stampLess は同場原行をindex/lineの物理順に並べます。
//
// 引数: a/b(Stamp)。返り値: bool。時刻後退はProviderが別途拒否します。
func stampLess(a, b Stamp) bool {
	return a.Index < b.Index || a.Index == b.Index && a.SourceLine < b.SourceLine
}

// emitScene は場内配送unionだけから1原行1Contextのgzipを一度生成します。
//
// 引数: provider(*Provider)、scene(parentScene)、background(backgroundScene)、directory(string)、number(int)。
// 返り値: SceneFeatures/error。未配送末尾を当場イベントへ戻しません。
func emitScene(provider *Provider, scene parentScene, background backgroundScene, directory string, number int) (SceneFeatures, error) {
	out := SceneFeatures{Session: scene.Session, Contract: scene.Contract, Start: scene.Start, End: scene.End, ContinuousEnd: scene.End - 300, ForceClose: scene.ForceClose, Raw: scene.Raw, Path: fmt.Sprintf("%03d.jsonl.gz", number)}
	if !scene.Success || scene.Session != background.Session || scene.Contract != background.Contract || scene.Start != background.Start || scene.End != background.End || scene.ForceClose != background.ForceClose || scene.ExecutionEnd != out.ContinuousEnd || scene.Raw.Path != background.Raw.Path || scene.Raw.SHA256 != background.Raw.SHA256 || scene.ActualSHA != scene.Raw.SHA256 {
		return out, fmt.Errorf("147/122場scope/由来差:%s", scene.Session)
	}
	if e := provider.StartSession(scene.Session, scene.Contract, scene.Start, out.ContinuousEnd); e != nil {
		return out, e
	}
	// ----------------------------------------
	// 入力の全格子・配送順は当場終端後の足も含め先に検査します。
	for i, k := range scene.Bars {
		if k.Bar.Start != scene.Start+float64(i)*60 || k.Bar.End != k.Bar.Start+60 || k.Bar.End > out.ContinuousEnd || k.Bar.Session != scene.Session || k.Bar.Contract != scene.Contract || k.Bar.WidthSeconds != 60 || k.Bar.AvailableAt != k.Bar.End+60 || k.Bar.Stamp != stampQuote(k.Context.At) || k.Bar.Stamp.Time < k.Bar.AvailableAt || k.Bar.Stamp.Time < scene.Start || k.Bar.Stamp.Time > scene.End {
			return out, fmt.Errorf("147足/初配送時計差:%s/%d", scene.Session, i)
		}
		if i > 0 && !before(scene.Bars[i-1].Bar.Stamp, k.Bar.Stamp) {
			return out, fmt.Errorf("147配送後退")
		}
	}
	for i, p := range background.Publications {
		f := p.Frame.Frame
		if f.SessionID != scene.Session || f.Contract != scene.Contract || p.Stamp.Time < scene.Start || p.Stamp.Time > scene.End || i > 0 && !before(publicationRef(background.Publications[i-1]).Stamp, publicationRef(p).Stamp) {
			return out, fmt.Errorf("122公表scope/順序差")
		}
	}
	f, e := os.OpenFile(filepath.Join(directory, out.Path), os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0644)
	if e != nil {
		return out, e
	}
	physical, decoded := sha256.New(), sha256.New()
	gz := gzip.NewWriter(io.MultiWriter(f, physical))
	counter := &countWriter{writer: io.MultiWriter(gz, decoded)}
	enc := json.NewEncoder(counter)
	defer f.Close()
	i, j := 0, 0
	for i < len(scene.Bars) || j < len(background.Publications) {
		var at Stamp
		if i == len(scene.Bars) {
			at = publicationRef(background.Publications[j]).Stamp
		} else if j == len(background.Publications) || stampLess(scene.Bars[i].Bar.Stamp, publicationRef(background.Publications[j]).Stamp) {
			at = scene.Bars[i].Bar.Stamp
		} else {
			at = publicationRef(background.Publications[j]).Stamp
		}
		minutes := []Minute{}
		pubs := []rules.Publication{}
		// 背景だけの行に本物のBBOは不要。Last=1はBank API用の定数で出力/特徴へは一切混ぜません。
		q := Quote{Time: at.Time, Index: at.Index, SourceLine: at.SourceLine, Last: 1}
		var witness *Quote
		for i < len(scene.Bars) && scene.Bars[i].Bar.Stamp == at {
			k := scene.Bars[i]
			if witness != nil && *witness != k.Context.At {
				return out, fmt.Errorf("同原行147Quote差")
			}
			x := k.Context.At
			witness = &x
			q = x
			minutes = append(minutes, k.Bar)
			i++
		}
		for j < len(background.Publications) && publicationRef(background.Publications[j]).Stamp == at {
			pubs = append(pubs, background.Publications[j])
			j++
		}
		if len(minutes)+len(pubs) == 0 {
			return out, fmt.Errorf("同index/lineの時刻不一致")
		}
		if at.Time >= out.ContinuousEnd {
			if e = provider.CarryOnly(pubs); e != nil {
				return out, e
			}
			out.CarryPublications += len(pubs)
			out.TailMinutes += len(minutes)
			continue
		}
		context, e := provider.Observe(q, minutes, pubs)
		if e != nil {
			return out, fmt.Errorf("%s/%d:%w", scene.Session, at.Index, e)
		}
		if e = enc.Encode(context); e != nil {
			return out, e
		}
		out.Rows++
		out.MinuteUpdates += len(minutes)
		out.BackgroundUpdates += len(pubs)
	}
	if e = gz.Close(); e != nil {
		return out, e
	}
	if e = f.Close(); e != nil {
		return out, e
	}
	info, e := os.Stat(filepath.Join(directory, out.Path))
	if e != nil {
		return out, e
	}
	out.Bytes = info.Size()
	out.DecodedBytes = counter.count
	out.SHA256 = hex.EncodeToString(physical.Sum(nil))
	out.DecodedSHA256 = hex.EncodeToString(decoded.Sum(nil))
	return out, nil
}

type countWriter struct {
	writer io.Writer
	count  int64
}

// Write はgzip前のJSONL bytesを計数します。
//
// 引数: p([]byte)。返り値: int/error。
func (w *countWriter) Write(p []byte) (int, error) {
	n, e := w.writer.Write(p)
	w.count += int64(n)
	return n, e
}

// Generate は147を一場ずつ読み、旧122公表と配送原行で結合して特徴だけを保存します。
//
// 引数: options(GenerateOptions)。返り値: FeatureManifest/error。全CRC/SHA成功前に完了票を保存しません。
func Generate(options GenerateOptions) (FeatureManifest, error) {
	out := FeatureManifest{Schema: "technical_features158_v1", Trial: 158, Background: options.Background, Specification: options.Specification, Scenes: []SceneFeatures{}}
	for _, key := range M1Keys {
		out.Catalog = append(out.Catalog, "m1."+key)
	}
	for _, width := range []int{5, 15, 30} {
		for _, key := range MTFKeys {
			out.Catalog = append(out.Catalog, fmt.Sprintf("m%d.%s", width, key))
		}
	}
	sort.Strings(out.Catalog)
	if options.All73 && (options.Background.SHA256 != BackgroundSHA || options.Specification.SHA256 != SpecSHA) {
		return out, fmt.Errorf("固定背景/正式条件SHA差")
	}
	if _, e := checkedBytes(options.Specification); e != nil {
		return out, e
	}
	body, e := checkedBytes(options.Background)
	if e != nil {
		return out, e
	}
	var background struct {
		Trial  int               `json:"trial"`
		Scenes []backgroundScene `json:"scenes"`
	}
	if e = json.Unmarshal(body, &background); e != nil {
		return out, e
	}
	body = nil
	if background.Trial != 122 || len(background.Scenes) == 0 || options.All73 && len(background.Scenes) != 73 {
		return out, fmt.Errorf("122全場数差")
	}
	if _, e = os.Stat(options.OutputDirectory); !os.IsNotExist(e) {
		return out, fmt.Errorf("出力先は未作成を指定")
	}
	if e = os.MkdirAll(options.OutputDirectory, 0755); e != nil {
		return out, e
	}
	provider := NewProvider()
	seen := map[string]bool{}
	count := 0
	evidence, e := ReadParent(options.Parent, func(raw json.RawMessage) error {
		var scene parentScene
		if e := json.Unmarshal(raw, &scene); e != nil {
			return e
		}
		if count >= len(background.Scenes) || seen[scene.Session] {
			return fmt.Errorf("147場重複/過剰")
		}
		seen[scene.Session] = true
		x, e := emitScene(provider, scene, background.Scenes[count], options.OutputDirectory, count)
		if e != nil {
			return e
		}
		out.Scenes = append(out.Scenes, x)
		out.MinuteCount += len(scene.Bars)
		out.PublicationCount += len(background.Scenes[count].Publications)
		count++
		fmt.Fprintf(os.Stderr, "特徴成功 %d/%d %s events=%d\n", count, len(background.Scenes), scene.Session, x.Rows)
		return nil
	})
	if e != nil {
		return out, e
	}
	var success bool
	var trial int
	if e = json.Unmarshal(evidence.Top["success"], &success); e != nil {
		return out, e
	}
	if e = json.Unmarshal(evidence.Top["trial"], &trial); e != nil {
		return out, e
	}
	if !success || trial != 147 || count != len(background.Scenes) || options.All73 && (count != 73 || out.MinuteCount != 43124 || out.PublicationCount != 12794) {
		return out, fmt.Errorf("147全入力完了/全数差")
	}
	// ----------------------------------------
	// 旧背景を末尾まで配送してからのみ次場へ進み、固定入力の前後同体も確認します。
	if _, e = checkedBytes(options.Background); e != nil {
		return out, e
	}
	if _, e = checkedBytes(options.Specification); e != nil {
		return out, e
	}
	out.Parent = evidence
	out.SceneCount = count
	out.Success = true
	return out, nil
}

// SameContext は人工再現で浮動値/NULL/参照を全値比較する補助です。
//
// 引数: a/b(Context)。返り値: bool。自然の採否へ使いません。
func SameContext(a, b Context) bool { return reflect.DeepEqual(a, b) }
