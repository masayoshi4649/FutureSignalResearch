"""第158試行の広い技術出口候補と、追加指標を含む汎用表を結果前に固定する。"""
from pathlib import Path
import hashlib
import json
import re

ROOT=Path(__file__).resolve().parents[2]
TRIAL=ROOT/'study/00158_複合技術で出口の役割と局面を切り替える'

POLICIES=[
 ('F125S125','固定対照','単純IFD±125pt。157同体。'),
 ('T125W100TP250','固定対照','+125で幅100/最低0床、TP250。157同体。'),
 ('E0W125','固定対照','費用後W>0で幅125/最低0床。157同体。'),
 ('A01_CHAND_MOM','通常揺れと失速','arm125/TPなし。幅clamp(3ATR,50,200)、weak&&break時はclamp(1.5ATR,25,75)。取得後BBO峰を使うChandelier派生。'),
 ('A02_KASE_VAR','逆行幅の分散','arm=clamp(2entryATR,50,125)、未知entryATRは125固定。TPなし。幅clamp(TRD平均20+1.64SD20,50,200)、weak&&volContra時clamp(TRD平均+SD,25,100)。'),
 ('A03_SUPER_CONFIRM','変動帯の失効','arm125/TPなし。同方向SuperTrend10×3線はweak||break時だけ床候補、他は峰−clamp(3ATR,75,200)。逆ST&&weak&&breakで退出。'),
 ('A04_SAR_ACCEL','時間と勢い','arm125/TPなし。同方向PSAR(.02,.2)線はweak&&signedDI1<0時だけ床候補、他は峰−clamp(3ATR,75,200)。逆SAR&&weak&&DI反対で退出。'),
 ('A05_SWING_CONFIRM','構造の失効','arm125/TP250。weak||volContra時は直前10足の買low−.5ATR/売high+.5ATRを床へ、候補線は現在g−5以下へ制限。他は幅100。MFE>=50&&break&&weak&&volContraで早期退出。'),
 ('A06_BB_CONTRACT','収束と継続','arm125/TP250/基本幅100。BB幅<=.9前幅&&weak&&ER10<.35で幅clamp(1.5ATR,25,60)。BB拡大&&strongなら幅clamp(3ATR,100,200)/TPなし。'),
 ('A07_VOL_DIVERGE','量価乖離','arm125/TP250/基本幅100。closeが買直前20高値超/売安値割れ&&volContra&&weak&&MFE>=50で退出。volContra&&weakなら幅50。'),
 ('A08_VWAP_REVERT','平均価格帯への回復','arm125/幅100。entry近似VWAPへの符号付き距離が50〜250なら固定TP、未知/逆側/範囲外はTP125。strong時はTP250。有効な順側固定目標だけ現在清算BBOの到達&&weakでも退出。動くVWAPへ目標交換しない。'),
 ('A09_SPIKE_CONFIRM','行き急ぎと否定','arm125/TP250/幅100。signedbody>=1.5ATR又はsignedBBz>=2、相対量>=1.5、順側wick/range>=.35で実体中点を記憶。後続確定足が中点逆側&&weak&&MFE>=50で退出。'),
 ('A10_PROGRESS_CLOCK','進行速度の寿命','arm125/TP250/幅100。取得15分後、MFE<.75entryATR&&break&&weakで退出。MFE>=50・最後の新峰から8分・ER10<.3・weakならarm50/幅50。'),
 ('A11_PROFIT_BUDGET','利益返却予算','arm125/TPなし。strongなら幅max(100,.5MFE)、他はclamp(.25MFE+ATR,25,100)。weak&&breakなら幅clamp(ATR,25,60)。'),
 ('A12_VOL_SHOCK','異常逆行と量','arm125/TP250/幅100。signedbody<=−prevATR、TR>=2prevATR、相対量>=1.5、breakの同時成立で損益不問の退出。'),
 ('A13_CUSUM_FAILURE','小さな失速の累積','arm125/TP250/幅100。取得後の新1分event毎にx=s*(close−prevClose)/prevATR、S=max(0,S−x−.25)。欠測は連続性reset。S>=3&&break&&weakで退出。'),
 ('A14_PERSISTENT_CONSENSUS','根拠失効の持続','arm125/TP250/幅100。break/weak/volContra/signedDI1<0/BB収縮の5票。3票以上2足連続で退出。2票以上&&MFE>=50なら幅50、arm125は維持。'),
 ('A15_EXTEND_PERMISSION','延伸を許可する条件','最初のg>=125時、strong&&signedCMF20>0&&ER10>=.35ならTP250/arm125/幅100。満たさなければTP125で退出。未知は不許可。'),
 ('A16_REGIME_SWITCH','順行と往復の切替','arm125。strong&&ER10>=.35ならTPなし/幅clamp(3ATR,100,200)。CHOP14>=61.8又はER10<.25ならTP125/幅clamp(1.5ATR,25,75)。他はTP250/幅100。MFE>=50&&weak&&break&&volContraで退出。'),
]


def sha(path: Path) -> str:
    """
    機能: ファイルのSHA256を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 政策19件、V8汎用表、試行設定表を新規生成する。
    引数: なし。返り値: None。自然価格/結果は読まない。
    """
    TRIAL.mkdir(parents=True,exist_ok=True)
    source=ROOT/'docs/議論/手法と時間スケールの汎用表_版7.md'
    target=source.with_name('手法と時間スケールの汎用表_版8.md')
    assert not target.exists()
    text=source.read_text(encoding='utf-8')
    body=text[text.index('## 手法×時間スケール'):]
    extra=[('I17','効率比ER','../technical-analysis/指標/効率比ER.md'),
        ('I18','Choppiness Index','../technical-analysis/指標/ChoppinessIndex.md'),
        ('I19','Kase DevStops・2足TR分散幅','../technical-analysis/指標/KaseDevStops.md'),
        ('I20','SuperTrend','../technical-analysis/指標/SuperTrend.md'),
        ('I21','Chande Kroll Stop','../technical-analysis/指標/ChandeKrollStop.md'),
        ('M03','CUSUMと根拠失効','../technical-analysis/組み合わせ/CUSUMと根拠失効.md')]
    for ident,name,link in extra:
        row='| '+ident+' | ['+name+']('+link+') | '+' | '.join(['未設定・未検証']*9)+' |'
        anchor='I16' if ident.startswith('I') else 'M02'
        match=re.search(r'(?m)^\| '+anchor+r' \|.*$',body)
        assert match
        body=body[:match.end()]+'\n'+row+body[match.end():]
    # 指標追加時の挿入をID順へ整える。
    rows=re.findall(r'(?m)^\| I(?:1[7-9]|2[01]) \|.*$',body)
    for row in rows:
        body=body.replace('\n'+row,'')
    match=re.search(r'(?m)^\| I16 \|.*$',body)
    body=body[:match.end()]+'\n'+'\n'.join(sorted(rows))+body[match.end():]
    table_rows=[line for line in body.splitlines() if re.match(r'^\| [ICPVBXME]\d{2} \| \[',line)]
    assert len(table_rows)==63
    target.write_text('# 手法と時間スケールの汎用表・版8\n\n2026-11-13。63手法×9尺度＝567組。'
        '版7の57手法を保持し、ER/CHOP/Kase/SuperTrend/ChandeKroll/CUSUMを追加した。'
        '旧版・固定試行は変更しない。ChandelierはC06、進行時計と利益予算はE02の設定差として記録する。'
        '\n\n[版7](手法と時間スケールの汎用表_版7.md)。新規教材は一般式・心理仮説・本研究派生を区別し、利益の証明とはしない。\n\n'+body,encoding='utf-8')
    book={'試行':158,'確認日':'2026-11-13','方針':'一般的手法と独自仮説の複数技術出口を比較し、例示固定幅だけに限定しない',
        '入口':'157固定837物理case/924所属、153U15全93・152U0全831・全73場を保持',
        '固定入口SHA256':'eabf9819351ef77fec44a7a132a8df13fd8a3aee7c3be6d87ac81dabe34ce279',
        '政策':[{'id':i,'系統':f,'固定式':d} for i,f,d in POLICIES],
        '観測期限':['H60','SESSION'],'遅延':['D1','D0'],'費用':['C5','C0'],
        '主比較':{'期限':'H60','遅延':'D1','費用':'C5'},
        '量':'147 canonical観測量。HLC3Vは近似VWAP、真の全約定VWAPや成行側数量ではない',
        '学習モデル':'今回未実装。hazard/Bellman等は次の仮説候補、採用済みとはしない',
        '汎用表':{'path':str(target.relative_to(ROOT)),'sha256':sha(target)}}
    path=TRIAL/'候補の固定.json'
    assert not path.exists()
    path.write_text(json.dumps(book,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    status={
        'I01':'EMA/傾き。158-weak/strongの複合条件', 'I03':'Hist/差分。158-weak、複合失効',
        'I04':'算出のみ・今回単独判断には未使用', 'I05':'BB20幅/z/収縮。A06/A09/A14',
        'I08':'DI/ADX。strong/A04/A14','I09':'ATR/TR。複数幅/異常逆行の尺度',
        'I10':'対称seedのPSAR派生。A04','I12':'HLC3V近似sessionVWAP。A08',
        'I17':'ER10/20。継続/往復/停滞、閾値.25/.3/.35','I18':'CHOP14。A16>=61.8',
        'I19':'TRD20平均/母SD。A02 1.64/1.0','I20':'ST10×3対称seed。A03',
        'I21':'算出のみ・主政策未使用、次候補','C03':'価格構造・BB・量の複合',
        'C04':'方向・強さを他の根拠と確認','C05':'VWAPと継続/失速','C06':'Chandelier等のラチェット派生',
        'C07':'5/15/30方向・傾きのstrong、確定/公表時計保持',
        'P01':'実体/ヒゲ/Close、A09/A12','P02':'直前高安の構造否定','P03':'過去の価格帯/構造線',
        'P04':'継続/失効の複合状態','P05':'符号付き価格変化/CUSUM','P06':'取得後峰と返却予算',
        'P07':'直前5/10/20の突破/失効','P12':'spikeの警戒と後足否定',
        'V01':'canonical観測量/相対量、未知を0補完しない','V02':'OBVdelta5、代理量','V06':'CMF20、代理量',
        'M03':'CUSUM .25/3、取得後足eventのみ、break+weak確認',
        'E01':'157対照・先着時計を維持','E02':'19政策/SL125/床非緩和/早期失効/進行時計/利益予算',
        'B01':'D1 +1秒/TTL30/gap300/実清算BBO'}
    setting=target.read_text(encoding='utf-8').split('## 手法×時間スケール',1)[1]
    setting='## 手法×時間スケール'+setting
    setting=setting.replace('(../technical-analysis/','(../../docs/technical-analysis/').replace('(../../scripts/','(../../scripts/')
    setting=setting.replace('(逆行200ptより先に順行400ptへ届く入口.md)','(../../docs/議論/逆行200ptより先に順行400ptへ届く入口.md)')
    output=[]
    for line in setting.splitlines():
        match=re.match(r'^\| ([ICPVBXME]\d{2}) \| \[',line)
        if match:
            fields=line.split('|')
            ident=match.group(1)
            for j in range(3,12):
                fields[j]=' 今回の新出口では未使用・未検証 '
            if ident in status:
                fields[3]=' 158設定：'+status[ident]+'；準備中 '
                if ident in ('C07','I01','I03','I08','I09'):
                    for j in (6,7,8):
                        fields[j]=' 158-MTF：5/15/30の公表済み背景。旧seed継承；準備中 '
            line='|'.join(fields)
        output.append(line)
    settings='# 158 設定と結果\n\n2026-11-13。V8全63手法×9尺度=567セル。版SHA `'+sha(target)+'`。'
    settings+='入口固定・出口19政策、複合評価であり単独指標の効果とはしない。政策閾値は[候補の固定](候補の固定.json)と[実行条件](実行条件.md)へ記録する。\n\n'+'\n'.join(output)
    settings+='\n\n## 固定政策一覧\n\n|ID|役割|閾値/処理|\n|---|---|---|\n'
    settings+='\n'.join('|'+i+'|'+f+'|'+d.replace('|','\\|')+'|' for i,f,d in POLICIES)+'\n'
    (TRIAL/'設定と結果.md').write_text(settings,encoding='utf-8')
    print(json.dumps({'成功':True,'政策':len(POLICIES),'表の手法':len(table_rows),'候補SHA256':sha(path),'V8SHA256':sha(target)},ensure_ascii=False))


if __name__=='__main__':
    main()
