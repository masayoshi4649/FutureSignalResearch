// Package exitreplay157 は固定入口に対する純粋な1枚の出口状態を計算します。
package exitreplay157

import (
	"fmt"
	"math"
)

type Quote struct {
	Clock      string  `json:"clock,omitempty"`
	Time       float64 `json:"time"`
	Index      int64   `json:"index"`
	SourceLine int64   `json:"source_line"`
	Last       float64 `json:"last"`
	Bid        float64 `json:"bid"`
	Ask        float64 `json:"ask"`
	QuoteOK    bool    `json:"quote_ok"`
}

type Config struct {
	ID      string  `json:"id"`
	Policy  string  `json:"policy"`
	Horizon string  `json:"horizon"`
	Delay   string  `json:"delay"`
	Cost    string  `json:"cost"`
	FeeYen  float64 `json:"fee_yen"`
}

type policy struct {
	id                 string
	sl, tp, arm, width float64
	always, positive   bool
}

var policies = []policy{
	{id: "F125S75", sl: 75, tp: 125}, {id: "F125S100", sl: 100, tp: 125},
	{id: "F125S125", sl: 125, tp: 125}, {id: "F250S125", sl: 125, tp: 250},
	{id: "F250S250", sl: 250, tp: 250}, {id: "T0W125", sl: 125, arm: 125, width: 125, always: true},
	{id: "E0W125", sl: 125, width: 125, positive: true}, {id: "T50W100", sl: 125, arm: 50, width: 100},
	{id: "T125W75", sl: 125, arm: 125, width: 75}, {id: "T125W100", sl: 125, arm: 125, width: 100},
	{id: "T125W125", sl: 125, arm: 125, width: 125}, {id: "T125W100TP250", sl: 125, tp: 250, arm: 125, width: 100},
}

type Stamp struct {
	Time       float64 `json:"time"`
	Index      int64   `json:"index"`
	SourceLine int64   `json:"source_line"`
}

type LastOHLC struct {
	Count   int64   `json:"count"`
	Open    float64 `json:"open"`
	High    float64 `json:"high"`
	Low     float64 `json:"low"`
	Close   float64 `json:"close"`
	OpenAt  Stamp   `json:"open_at"`
	HighAt  Stamp   `json:"high_at"`
	LowAt   Stamp   `json:"low_at"`
	CloseAt Stamp   `json:"close_at"`
}

type Trigger struct {
	Reason     string   `json:"reason"`
	Time       float64  `json:"time"`
	Quote      *Quote   `json:"quote"`
	StopPoints *float64 `json:"stop_points"`
}

type Result struct {
	ConfigID                string   `json:"config_id"`
	Policy                  string   `json:"policy"`
	Horizon                 string   `json:"horizon"`
	Delay                   string   `json:"delay"`
	Cost                    string   `json:"cost"`
	Status                  string   `json:"status"`
	UnknownReason           string   `json:"unknown_reason,omitempty"`
	Deadline                float64  `json:"deadline"`
	FeeYen                  float64  `json:"fee_yen"`
	EntryMarkPoints         float64  `json:"entry_mark_points"`
	ProfitPoints            *float64 `json:"profit_points"`
	ProfitYen               *float64 `json:"profit_yen"`
	Trigger                 *Trigger `json:"trigger"`
	Fill                    *Quote   `json:"fill"`
	HeldSeconds             *float64 `json:"held_seconds"`
	Armed                   bool     `json:"armed"`
	ArmQuote                *Quote   `json:"arm_quote"`
	StopPoints              float64  `json:"stop_points"`
	PeakPoints              float64  `json:"peak_points"`
	PeakQuote               *Quote   `json:"peak_quote"`
	TroughPoints            float64  `json:"trough_points"`
	TroughQuote             *Quote   `json:"trough_quote"`
	PositiveSeen            bool     `json:"positive_seen"`
	FirstPositiveQuote      *Quote   `json:"first_positive_quote"`
	Reached125              bool     `json:"reached125"`
	First125Quote           *Quote   `json:"first125_quote"`
	ProfitAfterPositiveLoss *bool    `json:"profit_after_positive_loss"`
	ProfitAfter125Loss      *bool    `json:"profit_after125_loss"`
	GivebackPoints          *float64 `json:"giveback_points"`
	ObservedRows            int64    `json:"observed_rows"`
	BadBBORows              int64    `json:"bad_bbo_rows"`
	LastOHLC                LastOHLC `json:"last_ohlc"`
}

type FSM struct {
	entry                            Quote
	side                             int
	price, continuousEnd, lastNormal float64
	previous                         Quote
	config                           Config
	rule                             policy
	result                           Result
}

// Configurations は12政策と2期限・2遅延・2費用を組み合わせます。
//
// 引数: なし。返り値: []Config 型の固定96条件。
func Configurations() []Config {
	var out []Config
	for _, p := range policies {
		for _, h := range []string{"H60", "SESSION"} {
			for _, d := range []string{"D0", "D1"} {
				for _, c := range []string{"C0", "C5"} {
					fee := 77.0
					if c == "C5" {
						fee = 1077
					}
					out = append(out, Config{ID: p.id + "/" + h + "/" + d + "/" + c, Policy: p.id, Horizon: h, Delay: d, Cost: c, FeeYen: fee})
				}
			}
		}
	}
	return out
}

// New は固定取得Quoteと条件から1枚の出口状態を作ります。
//
// 引数: entry Quote、side int、price/forceClose/continuousEnd float64、config Config。
// 返り値: *FSM 型の純状態と、契約違反時のerror。
func New(entry Quote, side int, price, forceClose, continuousEnd float64, config Config) (*FSM, error) {
	if side != 1 && side != -1 {
		return nil, fmt.Errorf("方向が不正です")
	}
	if !validQuote(entry) || !normal(entry) || !finite(price) || price <= 0 || !finite(forceClose) || !finite(continuousEnd) {
		return nil, fmt.Errorf("取得価格または時計が不正です")
	}
	expected := entry.Ask
	if side < 0 {
		expected = entry.Bid
	}
	if expected != price {
		return nil, fmt.Errorf("固定取得の実BBOが一致しません")
	}
	var p policy
	found := false
	for _, x := range policies {
		if x.id == config.Policy {
			p = x
			found = true
		}
	}
	if !found || (config.Horizon != "H60" && config.Horizon != "SESSION") || (config.Delay != "D0" && config.Delay != "D1") || (config.Cost != "C0" && config.Cost != "C5") {
		return nil, fmt.Errorf("条件が不正です")
	}
	fee := 77.0
	if config.Cost == "C5" {
		fee = 1077
	}
	if config.FeeYen != fee || config.ID != p.id+"/"+config.Horizon+"/"+config.Delay+"/"+config.Cost {
		return nil, fmt.Errorf("条件IDまたは費用が不正です")
	}
	deadline := forceClose
	if config.Horizon == "H60" {
		deadline = math.Min(deadline, entry.Time+3600)
	}
	if deadline < entry.Time || continuousEnd <= deadline {
		return nil, fmt.Errorf("期限が取得前またはザラバ終端以降です")
	}
	f := &FSM{entry: entry, side: side, price: price, continuousEnd: continuousEnd, lastNormal: entry.Time, previous: entry, config: config, rule: p}
	g := f.gain(entry)
	f.result = Result{ConfigID: config.ID, Policy: p.id, Horizon: config.Horizon, Delay: config.Delay, Cost: config.Cost, Status: "active", Deadline: deadline, FeeYen: fee, EntryMarkPoints: g, StopPoints: -p.sl, PeakPoints: 0, TroughPoints: math.Min(0, g), TroughQuote: quotePtr(entry)}
	f.addLast(entry)
	return f, nil
}

// Step は取得より後のaccepted原行を1行だけ処理します。
//
// 引数: q Quote 型の当時行。返り値: error 型。終了済み状態は変更しません。
func (f *FSM) Step(q Quote) error {
	if f.Done() {
		return nil
	}
	if !validQuote(q) || q.Time < f.previous.Time || q.Index <= f.previous.Index || q.SourceLine <= f.previous.SourceLine {
		return fmt.Errorf("原行の値または順序が不正です")
	}
	if q.Time >= f.continuousEnd {
		f.unknown("phase_cut")
		return nil
	}
	if q.Time-f.previous.Time > 300 {
		f.unknown("accepted_gap")
		return nil
	}
	if q.Time-f.lastNormal > 300 {
		f.unknown("normal_bbo_gap")
		return nil
	}
	if f.result.Trigger != nil && q.Time > f.result.Trigger.Time+30 {
		f.unknown("exit_ttl")
		return nil
	}
	if f.result.Trigger == nil && q.Time > f.result.Deadline+30 {
		f.result.Trigger = &Trigger{Reason: "deadline", Time: f.result.Deadline}
		f.unknown("exit_ttl")
		return nil
	}
	f.previous = q
	f.result.ObservedRows++
	f.addLast(q)
	if !normal(q) {
		f.result.BadBBORows++
	} else {
		f.lastNormal = q.Time
		f.observe(q)
	}
	if f.result.Trigger != nil {
		f.tryFill(q)
		return nil
	}
	if q.Time >= f.result.Deadline {
		f.result.Trigger = &Trigger{Reason: "deadline", Time: f.result.Deadline}
		f.tryFill(q)
		return nil
	}
	if !normal(q) {
		return nil
	}
	g := f.gain(q)
	if g <= f.result.StopPoints {
		f.request("stop", q, true)
		return nil
	}
	if f.rule.tp > 0 && g >= f.rule.tp {
		f.request("take_profit", q, false)
		return nil
	}
	if f.rule.width > 0 {
		if !f.result.Armed && ((f.rule.positive && 100*g-f.result.FeeYen > 0) || (!f.rule.positive && g >= f.rule.arm)) {
			f.result.Armed = true
			f.result.ArmQuote = quotePtr(q)
		}
		if f.rule.always || f.result.Armed {
			f.result.StopPoints = math.Max(f.result.StopPoints, f.result.PeakPoints-f.rule.width)
		}
		if f.result.Armed {
			f.result.StopPoints = math.Max(0, f.result.StopPoints)
		}
		if g <= f.result.StopPoints {
			f.request("stop_after_update", q, true)
		}
	}
	return nil
}

// Done は状態の終了を調べます。
//
// 引数: なし。返り値: bool 型の完了または観測不足。
func (f *FSM) Done() bool { return f.result.Status != "active" }

// Finish は価格テープEOFで未完了状態だけを観測不足にします。
//
// 引数: なし。返り値: なし。既に閉じた損益は変更しません。
func (f *FSM) Finish() {
	if !f.Done() {
		f.unknown("eof")
	}
}

// Result は現在までに確定した結果を返します。
//
// 引数: なし。返り値: Result 型。取得前の高安と退出後の価格は含みません。
func (f *FSM) Result() Result { return f.result }

// ----------------------------------------

// gain は清算側BBOの粗益を計算します。
//
// 引数: q Quote。返り値: float64 型の符号付きpt。
func (f *FSM) gain(q Quote) float64 {
	m := q.Bid
	if f.side < 0 {
		m = q.Ask
	}
	return float64(f.side) * (m - f.price)
}

// observe は正常気配について実保有中の峰・谷・到達だけを更新します。
//
// 引数: q Quote。返り値: なし。予約中と実約定行も含みます。
func (f *FSM) observe(q Quote) {
	g := f.gain(q)
	if g > f.result.PeakPoints {
		f.result.PeakPoints = g
		f.result.PeakQuote = quotePtr(q)
	}
	if g < f.result.TroughPoints {
		f.result.TroughPoints = g
		f.result.TroughQuote = quotePtr(q)
	}
	if !f.result.PositiveSeen && 100*g-f.result.FeeYen > 0 {
		f.result.PositiveSeen = true
		f.result.FirstPositiveQuote = quotePtr(q)
	}
	if !f.result.Reached125 && g >= 125 {
		f.result.Reached125 = true
		f.result.First125Quote = quotePtr(q)
	}
}

// addLast は当時Lastの実保有中OHLCを更新します。
//
// 引数: q Quote。返り値: なし。取得行をOpenに含み、高安時刻は初回です。
func (f *FSM) addLast(q Quote) {
	o := &f.result.LastOHLC
	at := Stamp{q.Time, q.Index, q.SourceLine}
	if o.Count == 0 {
		*o = LastOHLC{Open: q.Last, High: q.Last, Low: q.Last, Close: q.Last, OpenAt: at, HighAt: at, LowAt: at, CloseAt: at}
	}
	if q.Last > o.High {
		o.High = q.Last
		o.HighAt = at
	}
	if q.Last < o.Low {
		o.Low = q.Last
		o.LowAt = at
	}
	o.Close = q.Last
	o.CloseAt = at
	o.Count++
}

// request は返済予約を一度だけ作りD0なら現在行で約定させます。
//
// 引数: reason string、q Quote、stop bool。返り値: なし。
func (f *FSM) request(reason string, q Quote, stop bool) {
	t := &Trigger{Reason: reason, Time: q.Time, Quote: quotePtr(q)}
	if stop {
		t.StopPoints = floatPtr(f.result.StopPoints)
	}
	f.result.Trigger = t
	f.tryFill(q)
}

// tryFill は予約を厳密な時計/原行/TTLで約定または不足へ進めます。
//
// 引数: q Quote。返り値: なし。反発を取消条件に使いません。
func (f *FSM) tryFill(q Quote) {
	t := f.result.Trigger
	if t == nil {
		return
	}
	if q.Time > t.Time+30 {
		f.unknown("exit_ttl")
		return
	}
	if !normal(q) {
		return
	}
	if f.config.Delay == "D1" {
		if q.Time < t.Time+1 {
			return
		}
		if t.Quote != nil && (q.Index <= t.Quote.Index || q.SourceLine <= t.Quote.SourceLine) {
			return
		}
	}
	g := f.gain(q)
	yen := 100*g - f.result.FeeYen
	f.result.Status = "closed"
	f.result.Fill = quotePtr(q)
	f.result.ProfitPoints = floatPtr(g)
	f.result.ProfitYen = floatPtr(yen)
	f.result.HeldSeconds = floatPtr(q.Time - f.entry.Time)
	f.result.GivebackPoints = floatPtr(f.result.PeakPoints - g)
	f.result.ProfitAfterPositiveLoss = boolPtr(f.result.PositiveSeen && yen < 0)
	f.result.ProfitAfter125Loss = boolPtr(f.result.Reached125 && yen < 0)
}

// unknown は未退出の状態の損益だけを不明に保ちます。
//
// 引数: reason string。返り値: なし。
func (f *FSM) unknown(reason string) { f.result.Status = "unknown"; f.result.UnknownReason = reason }

// finite は有限実数を確認します。
//
// 引数: x float64。返り値: bool 型の有限性。
func finite(x float64) bool { return !math.IsNaN(x) && !math.IsInf(x, 0) }

// validQuote はaccepted行として必須の有限値を調べます。
//
// 引数: q Quote。返り値: bool 型。BBO不正常行の保存自体は認めます。
func validQuote(q Quote) bool {
	return finite(q.Time) && finite(q.Last) && q.Last > 0 && finite(q.Bid) && finite(q.Ask) && q.Index >= 0 && q.SourceLine > 0
}

// normal は正常な清算気配を確認します。
//
// 引数: q Quote。返り値: bool 型の正常性。
func normal(q Quote) bool { return q.QuoteOK && q.Bid > 0 && q.Bid < q.Ask }

// quotePtr は当時値をコピーして参照を作ります。
//
// 引数: q Quote。返り値: *Quote 型。
func quotePtr(q Quote) *Quote { x := q; return &x }

// floatPtr は有限計算結果の参照を作ります。
//
// 引数: x float64。返り値: *float64 型。
func floatPtr(x float64) *float64 { return &x }

// boolPtr は確定した診断旗の参照を作ります。
//
// 引数: x bool。返り値: *bool 型。
func boolPtr(x bool) *bool { return &x }
