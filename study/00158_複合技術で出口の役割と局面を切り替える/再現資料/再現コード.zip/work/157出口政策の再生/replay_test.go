package exitreplay157

import (
	"bytes"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"

	tape "pricetape157"
)

// writeFixtureTape は人工だけの小さい価格テープを作ります。
//
// 引数: t *testing.T、directory string、quotes []Quote。返り値: SceneTape157 型。
func writeFixtureTape(t *testing.T, directory string, quotes []Quote) tape.SceneTape157 {
	t.Helper()
	var decoded, compressed bytes.Buffer
	for _, q := range quotes {
		if e := json.NewEncoder(&decoded).Encode(q); e != nil {
			t.Fatal(e)
		}
	}
	z := gzip.NewWriter(&compressed)
	if _, e := z.Write(decoded.Bytes()); e != nil {
		t.Fatal(e)
	}
	if e := z.Close(); e != nil {
		t.Fatal(e)
	}
	if e := os.WriteFile(filepath.Join(directory, "人工.jsonl.gz"), compressed.Bytes(), 0644); e != nil {
		t.Fatal(e)
	}
	ph, dh := sha256.Sum256(compressed.Bytes()), sha256.Sum256(decoded.Bytes())
	first, last := tape.Quote(quotes[0]), tape.Quote(quotes[len(quotes)-1])
	return tape.SceneTape157{Success: true, Session: "人工", Contract: "人工限月", Start: 0, End: 800, ForceClose: 200, ContinuousEnd: 500, Raw: tape.FileRef{Path: "未読Raw", SHA256: strings.Repeat("a", 64)}, ActualSHA256: strings.Repeat("a", 64), Tape: tape.TapeRef157{Path: "人工.jsonl.gz", SHA256: hex.EncodeToString(ph[:]), DecodedSHA256: hex.EncodeToString(dh[:]), Bytes: int64(compressed.Len()), DecodedBytes: int64(decoded.Len()), Rows: int64(len(quotes))}, FirstQuote: &first, LastQuote: &last, EntryMatches: []tape.EntryMatch157{{CaseID: "人工case", Quote: tape.Quote(quotes[1]), TapeLine: 2}}}
}

// fixtureScene は人工caseと所属だけを作ります。
//
// 引数: entry Quote。返り値: FixedScene157 型。
func fixtureScene(entry Quote) tape.FixedScene157 {
	return tape.FixedScene157{Session: "人工", Contract: "人工限月", Start: 0, End: 800, ForceClose: 200, ContinuousEnd: 500, Raw: tape.FileRef{Path: "未読Raw", SHA256: strings.Repeat("a", 64)}, Cases: []tape.FixedCase157{{ID: "人工case", OriginalSide: 1, Side: 1, Stream: "original", Entry: tape.Quote(entry), EntryPrice: 1000, Memberships: []tape.Membership157{{Policy: "153U15", Side: 1, Stream: "original", EntryPrice: 1000}}}}}
}

// TestSceneReplayHoldsOnlyActualInterval は共有テープの取得と実保有区間を検査します。
//
// 引数: t *testing.T。返り値: なし。
func TestSceneReplayHoldsOnlyActualInterval(t *testing.T) {
	directory := t.TempDir()
	qs := []Quote{fixtureQuote(99, -5, 0), fixtureEntry(), fixtureQuote(101, 125, 2), fixtureQuote(102, -140, 3), fixtureQuote(103, 1000, 4)}
	for i := range qs {
		qs[i].Clock = "人工時計"
	}
	stream := writeFixtureTape(t, directory, qs)
	scene := fixtureScene(qs[1])
	var config Config
	for _, c := range Configurations() {
		if c.ID == "F125S125/H60/D1/C5" {
			config = c
		}
	}
	r, e := ReplayScene(scene, stream, directory, []Config{config})
	if e != nil {
		t.Fatal(e)
	}
	if !r.TapeRead.Success || r.TapeRead.Rows != 5 || r.EntriesMatched != 1 {
		t.Fatal("完読/取得差")
	}
	x := r.Cases[0].Results[0]
	near(t, *x.ProfitPoints, -140)
	near(t, x.PeakPoints, 125)
	if x.LastOHLC.Count != 3 || x.ObservedRows != 2 || x.Fill.Index != 3 {
		t.Fatal("保有前後を混入")
	}
}

// TestSceneReplayRejectsQuoteAndTapeChanges は取得と保存テープの改変を拒否します。
//
// 引数: t *testing.T。返り値: なし。
func TestSceneReplayRejectsQuoteAndTapeChanges(t *testing.T) {
	directory := t.TempDir()
	qs := []Quote{fixtureQuote(99, -5, 0), fixtureEntry(), fixtureQuote(101, 125, 2)}
	for i := range qs {
		qs[i].Clock = "人工時計"
	}
	stream := writeFixtureTape(t, directory, qs)
	scene := fixtureScene(qs[1])
	scene.Cases[0].Entry.Last++
	if _, e := ReplayScene(scene, stream, directory, Configurations()); e == nil {
		t.Fatal("取得改変を受理")
	}
	scene = fixtureScene(qs[1])
	if e := os.WriteFile(filepath.Join(directory, stream.Tape.Path), []byte("改変"), 0644); e != nil {
		t.Fatal(e)
	}
	if _, e := ReplayScene(scene, stream, directory, Configurations()); e == nil {
		t.Fatal("テープ物理改変を受理")
	}
}
