package exitreplay157

import (
	"math"
	"reflect"
	"testing"
)

// fixtureEntry は買いの固定取得を作ります。
//
// 引数: なし。返り値: Quote 型。
func fixtureEntry() Quote {
	return Quote{Time: 100, Index: 1, SourceLine: 2, Last: 995, Bid: 990, Ask: 1000, QuoteOK: true}
}

// fixtureQuote は現在清算粗益を指定して後原行を作ります。
//
// 引数: second/gain float64、index int64。返り値: Quote 型。
func fixtureQuote(second, gain float64, index int64) Quote {
	return Quote{Time: second, Index: index, SourceLine: index + 1, Last: 1005 + gain, Bid: 1000 + gain, Ask: 1010 + gain, QuoteOK: true}
}

// fixtureFSM は人工用の一条件を作ります。
//
// 引数: t *testing.T、policy/delay/cost string、deadline float64。返り値: *FSM 型。
func fixtureFSM(t *testing.T, policy, delay, cost string, deadline float64) *FSM {
	t.Helper()
	for _, c := range Configurations() {
		if c.Policy == policy && c.Horizon == "H60" && c.Delay == delay && c.Cost == cost {
			f, e := New(fixtureEntry(), 1, 1000, deadline, deadline+300, c)
			if e != nil {
				t.Fatal(e)
			}
			return f
		}
	}
	t.Fatal("人工条件不在")
	return nil
}

// feed は人工原行を順に配送します。
//
// 引数: t *testing.T、f *FSM、quotes ...Quote。返り値: なし。
func feed(t *testing.T, f *FSM, quotes ...Quote) {
	t.Helper()
	for _, q := range quotes {
		if e := f.Step(q); e != nil {
			t.Fatal(e)
		}
	}
}

// near は浮動小数計算の許容内を確認します。
//
// 引数: t *testing.T、got/want float64。返り値: なし。
func near(t *testing.T, got, want float64) {
	t.Helper()
	if math.Abs(got-want) > 1e-9 {
		t.Fatalf("数値差 got=%v want=%v", got, want)
	}
}

// TestFixedStopsAndTP は固定IFDを実現在値で約定させます。
//
// 引数: t *testing.T。返り値: なし。
func TestFixedStopsAndTP(t *testing.T) {
	for _, x := range []struct {
		p      string
		g      float64
		reason string
	}{{"F125S75", -75, "stop"}, {"F125S100", -130, "stop"}, {"F125S125", 140, "take_profit"}, {"F250S125", 270, "take_profit"}, {"F250S250", -270, "stop"}} {
		f := fixtureFSM(t, x.p, "D0", "C5", 200)
		feed(t, f, fixtureQuote(101, x.g, 2))
		r := f.Result()
		if r.Status != "closed" || r.Trigger.Reason != x.reason {
			t.Fatalf("固定決済:%+v", r)
		}
		near(t, *r.ProfitPoints, x.g)
		near(t, *r.ProfitYen, x.g*100-1077)
	}
}

// TestReservationDoesNotCancel は反発と同秒原行で予約を取り消しません。
//
// 引数: t *testing.T。返り値: なし。
func TestReservationDoesNotCancel(t *testing.T) {
	f := fixtureFSM(t, "F125S125", "D1", "C5", 200)
	feed(t, f, fixtureQuote(101, 125, 2), fixtureQuote(101, 150, 3), fixtureQuote(101.9, 250, 4))
	if f.Done() {
		t.Fatal("1秒前に約定")
	}
	feed(t, f, fixtureQuote(102, -140, 5))
	r := f.Result()
	near(t, *r.ProfitPoints, -140)
	if r.Trigger.Time != 101 || r.Fill.Index != 5 || !*r.ProfitAfterPositiveLoss || !*r.ProfitAfter125Loss {
		t.Fatalf("予約/正益後赤字:%+v", r)
	}
	near(t, r.PeakPoints, 250)
	near(t, *r.GivebackPoints, 390)
	feed(t, f, fixtureQuote(5000, 999, 6))
	near(t, f.Result().PeakPoints, 250)
}

// TestTrailingArmsAndFloors は常時追尾と起動後の床を分けます。
//
// 引数: t *testing.T。返り値: なし。
func TestTrailingArmsAndFloors(t *testing.T) {
	f := fixtureFSM(t, "T0W125", "D0", "C5", 200)
	if f.Result().StopPoints != -125 || f.Result().Armed {
		t.Fatal("初期建値床を混入")
	}
	feed(t, f, fixtureQuote(101, 50, 2))
	near(t, f.Result().StopPoints, -75)
	if f.Result().Armed {
		t.Fatal("早過ぎる利益保護")
	}
	feed(t, f, fixtureQuote(102, -75, 3))
	if !f.Done() {
		t.Fatal("常時追尾未発動")
	}
	for _, x := range []struct {
		p string
		w float64
	}{{"T125W75", 50}, {"T125W100", 25}, {"T125W125", 0}, {"T0W125", 0}, {"T125W100TP250", 25}} {
		g := fixtureFSM(t, x.p, "D0", "C0", 200)
		feed(t, g, fixtureQuote(101, 124, 2))
		if g.Result().Armed {
			t.Fatal("125未満で起動")
		}
		feed(t, g, fixtureQuote(102, 125, 3))
		if !g.Result().Armed {
			t.Fatal("125等号で未起動")
		}
		near(t, g.Result().StopPoints, x.w)
		feed(t, g, fixtureQuote(103, 126, 4), fixtureQuote(104, 125, 5))
		near(t, g.Result().StopPoints, x.w+1)
	}
	h := fixtureFSM(t, "T50W100", "D0", "C0", 200)
	feed(t, h, fixtureQuote(101, 49, 2))
	if h.Result().Armed {
		t.Fatal("50未満で起動")
	}
	feed(t, h, fixtureQuote(102, 50, 3))
	near(t, h.Result().StopPoints, 0)
}

// TestPositiveStrictAndCosts は費用後起動をC0/C5で分けます。
//
// 引数: t *testing.T。返り値: なし。
func TestPositiveStrictAndCosts(t *testing.T) {
	a := fixtureFSM(t, "E0W125", "D0", "C0", 200)
	b := fixtureFSM(t, "E0W125", "D0", "C5", 200)
	feed(t, a, fixtureQuote(101, 0, 2), fixtureQuote(102, 1, 3))
	feed(t, b, fixtureQuote(101, 0, 2), fixtureQuote(102, 1, 3))
	if !a.Result().Armed || b.Result().Armed {
		t.Fatal("費用後起動の差を失った")
	}
	feed(t, b, fixtureQuote(103, 10, 4))
	if b.Result().Armed {
		t.Fatal("C5費用前に起動")
	}
	feed(t, b, fixtureQuote(104, 15, 5))
	if !b.Result().Armed {
		t.Fatal("正益未起動")
	}
	feed(t, b, fixtureQuote(105, 0, 6))
	near(t, *b.Result().ProfitYen, -1077)
}

// TestDeadlineTimer は要求時計を最初の後Quoteへ遅らせません。
//
// 引数: t *testing.T。返り値: なし。
func TestDeadlineTimer(t *testing.T) {
	f := fixtureFSM(t, "E0W125", "D1", "C5", 150)
	feed(t, f, fixtureQuote(150, 100, 2))
	if f.Done() || f.Result().Armed || f.Result().Trigger.Time != 150 || f.Result().Trigger.Quote != nil {
		t.Fatal("期限で追尾または即約定")
	}
	feed(t, f, fixtureQuote(151, 90, 3))
	near(t, *f.Result().ProfitPoints, 90)
	for _, d := range []string{"D0", "D1"} {
		g := fixtureFSM(t, "F250S250", d, "C5", 150)
		feed(t, g, fixtureQuote(152, 7, 2))
		if !g.Done() || g.Result().Trigger.Time != 150 {
			t.Fatal("期限要求時刻を遅延")
		}
	}
}

// TestExpiryGapEOF はTTL/品質/終端により未知を保持します。
//
// 引数: t *testing.T。返り値: なし。
func TestExpiryGapEOF(t *testing.T) {
	f := fixtureFSM(t, "F125S125", "D1", "C5", 500)
	feed(t, f, fixtureQuote(101, 125, 2), fixtureQuote(131, -5, 3))
	if f.Result().Status != "closed" {
		t.Fatal("30秒等号を拒否")
	}
	g := fixtureFSM(t, "F125S125", "D1", "C5", 500)
	feed(t, g, fixtureQuote(101, 125, 2), fixtureQuote(131.001, 1000, 3))
	r := g.Result()
	if r.Status != "unknown" || r.UnknownReason != "exit_ttl" || r.ProfitYen != nil || r.ProfitAfter125Loss != nil || r.PeakPoints != 125 {
		t.Fatal("期限後を価格に使用")
	}
	h := fixtureFSM(t, "F250S250", "D1", "C5", 500)
	feed(t, h, fixtureQuote(400.001, 1, 2))
	if h.Result().UnknownReason != "accepted_gap" {
		t.Fatal("300秒超を補完")
	}
	i := fixtureFSM(t, "F250S250", "D1", "C5", 500)
	feed(t, i, fixtureQuote(400, 1, 2))
	if i.Done() {
		t.Fatal("300秒等号を拒否")
	}
	j := fixtureFSM(t, "F250S250", "D1", "C5", 500)
	q := fixtureQuote(250, 50, 2)
	q.QuoteOK = false
	feed(t, j, q)
	q = fixtureQuote(400, 100, 3)
	q.QuoteOK = false
	feed(t, j, q)
	feed(t, j, fixtureQuote(400.1, 1, 4))
	if j.Result().UnknownReason != "normal_bbo_gap" {
		t.Fatal("正常気配欠測を補完")
	}
	k := fixtureFSM(t, "F250S250", "D1", "C5", 150)
	feed(t, k, fixtureQuote(180.001, 99, 2))
	if k.Result().UnknownReason != "exit_ttl" || k.Result().ObservedRows != 0 {
		t.Fatal("遅過ぎる期限清算")
	}
	l := fixtureFSM(t, "F250S250", "D1", "C5", 200)
	feed(t, l, fixtureQuote(500, 1, 2))
	if l.Result().UnknownReason != "phase_cut" {
		t.Fatal("終端の値を使用")
	}
	m := fixtureFSM(t, "F250S250", "D1", "C5", 200)
	m.Finish()
	if m.Result().UnknownReason != "eof" {
		t.Fatal("EOF未反映")
	}
	before := f.Result()
	f.Finish()
	if !reflect.DeepEqual(before, f.Result()) {
		t.Fatal("終了後の欠測で改変")
	}
}

// mirror は価格全反射とBid/Ask交換を行います。
//
// 引数: q Quote。返り値: Quote 型。
func mirror(q Quote) Quote {
	q.Last = 10000 - q.Last
	q.Bid, q.Ask = 10000-q.Ask, 10000-q.Bid
	return q
}

// TestMirrorAll96 は全条件の売買対称と実側BBOを確かめます。
//
// 引数: t *testing.T。返り値: なし。
func TestMirrorAll96(t *testing.T) {
	cs := Configurations()
	if len(cs) != 96 {
		t.Fatal(len(cs))
	}
	for _, c := range cs {
		a, e := New(fixtureEntry(), 1, 1000, 200, 500, c)
		if e != nil {
			t.Fatal(e)
		}
		b, e := New(mirror(fixtureEntry()), -1, 9000, 200, 500, c)
		if e != nil {
			t.Fatal(e)
		}
		for n, g := range []float64{10, 50, 125, 130, 260, 200, -150, 0} {
			q := fixtureQuote(101+float64(n), g, int64(n+2))
			feed(t, a, q)
			feed(t, b, mirror(q))
		}
		a.Finish()
		b.Finish()
		x, y := a.Result(), b.Result()
		if x.Status != y.Status || x.Armed != y.Armed || x.PositiveSeen != y.PositiveSeen || x.Reached125 != y.Reached125 {
			t.Fatal("鏡像状態差", c)
		}
		near(t, x.PeakPoints, y.PeakPoints)
		near(t, x.TroughPoints, y.TroughPoints)
		near(t, x.StopPoints, y.StopPoints)
		if x.ProfitYen != nil {
			near(t, *x.ProfitYen, *y.ProfitYen)
			near(t, *x.ProfitPoints, *y.ProfitPoints)
		}
	}
}

// TestInputAndAfterEntry は取得行の到達除外と入力不変を確認します。
//
// 引数: t *testing.T。返り値: なし。
func TestInputAndAfterEntry(t *testing.T) {
	f := fixtureFSM(t, "T0W125", "D1", "C5", 200)
	r := f.Result()
	if r.PeakPoints != 0 || r.Reached125 || r.ObservedRows != 0 || r.LastOHLC.Count != 1 {
		t.Fatal("取得行を到達へ混入")
	}
	q := fixtureQuote(101, 20, 2)
	before := q
	feed(t, f, q)
	if q != before {
		t.Fatal("入力を変更")
	}
	if e := f.Step(q); e == nil {
		t.Fatal("同原行を再配送")
	}
	bad := fixtureQuote(102, 20, 3)
	bad.Last = math.NaN()
	if e := f.Step(bad); e == nil {
		t.Fatal("非有限を受理")
	}
	cs := Configurations()
	if _, e := New(fixtureEntry(), 1, 999, 200, 500, cs[0]); e == nil {
		t.Fatal("取得価格改変を受理")
	}
}
