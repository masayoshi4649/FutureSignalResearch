package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"path/filepath"

	exit "exitreplay157"
)

// main は明示入力だけを用いた価格テープ再生を起動します。
//
// 引数: CLI flags。返り値: なし。失敗時は非0終了します。
func main() {
	input := flag.String("input", "", "固定入口JSON")
	inputSHA := flag.String("input-sha256", "", "固定入口の物理SHA256")
	manifest := flag.String("manifest", "", "薄い価格テープmanifest JSON")
	manifestSHA := flag.String("manifest-sha256", "", "manifestの物理SHA256")
	spec := flag.String("spec", "", "固定実行条件Markdown")
	specSHA := flag.String("spec-sha256", "", "実行条件の物理SHA256")
	output := flag.String("output", "", "新規の出口結果.json.gz")
	flag.Parse()
	if flag.NArg() != 0 || *input == "" || *manifest == "" || *spec == "" || *output == "" || *inputSHA == "" || *manifestSHA == "" || *specSHA == "" {
		fmt.Fprintln(os.Stderr, "全固定path/SHAと新規出力を指定してください")
		os.Exit(2)
	}
	for _, p := range []*string{input, manifest, spec, output} {
		a, e := filepath.Abs(*p)
		if e != nil {
			fmt.Fprintln(os.Stderr, e)
			os.Exit(2)
		}
		*p = a
	}
	done, e := exit.Run(*input, *inputSHA, *manifest, *manifestSHA, *spec, *specSHA, *output, func(s string) { fmt.Fprintln(os.Stderr, s) })
	if e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
	if e = json.NewEncoder(os.Stdout).Encode(done); e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
}
