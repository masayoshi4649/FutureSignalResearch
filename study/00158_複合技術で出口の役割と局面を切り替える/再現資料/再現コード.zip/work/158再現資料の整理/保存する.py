"""機能: 停止済み158の最小再現源を元相対配置で保存し復元buildを確認する。"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
import platform
import re
import subprocess
import sys
import zipfile
import zlib

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
FORMAL = ROOT / 'study/00158_複合技術で出口の役割と局面を切り替える'
MODULES = ['118複数技法の入口条件', '157固定入口と価格経路', '157出口政策の再生', '158技術特徴', '158技術出口']
EXPECTED_SPEC = 'f32efc55b5fc114534b601b981e3c961d12037e5b5462d71769634402789cc17'
EXPECTED_BOOK = 'e7e8ef7fd2a714b145cbb7c0fe280a391804247ec5a88db872f88a1be45734c7'
EXPECTED_SETTINGS = 'ae74b8a87342a3bf14d24c83369bcf3aa7c1a49a759cac08b801acf58e55bc0a'


def sha(path: Path) -> str:
    """機能: 小源又は指定済み保存資源の物理SHAを求める。

    引数: path(Path)。返り値: str。
    """
    h = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def command(args: list[str], cwd: Path = ROOT) -> dict:
    """機能: 復元人工・構文・buildだけを実行する。

    引数: args(list[str])、cwd(Path)。返り値: dict型の実行記録。
    """
    result = subprocess.run(args, cwd=cwd, capture_output=True, text=True, encoding='utf-8')
    assert result.returncode == 0, (args, result.stdout, result.stderr)
    return {'引数': args, 'cwd': str(cwd), '終了値': result.returncode,
            'stdout': result.stdout, 'stderr': result.stderr}


def main() -> None:
    """機能: 小型ZIPを一度保存し全entryと復元人工を確認する。

    引数: なし。返り値: None。自然価格・金融・CSVの再生成はしない。
    """
    target = FORMAL / '再現資料/再現コード.zip'
    proof_path = FORMAL / '検査/再現コードの保存確認.json'
    assert not target.exists() and not proof_path.exists()
    selected = {}

    def add(path: Path, archive: str | None = None) -> None:
        """機能: allowlistの小源を元相対名へ一度だけ加える。

        引数: path(Path)、archive(str又はNone)。返り値: None。
        """
        assert path.is_file() and path.stat().st_size < 512_000, path
        name = archive or path.relative_to(ROOT).as_posix()
        parts = Path(name).parts
        assert not any(x in ('..', 'node_modules', '__pycache__', 'cache') for x in parts)
        assert not any(re.match(r'0?0?159', x) for x in parts), name
        assert Path(name).suffix in ('.go', '.mod', '.py', '.mjs', '.md', '.json'), name
        if name in selected:
            assert selected[name].read_bytes() == path.read_bytes()
        selected[name] = path

    # ----------------------------------------
    # Goの相対replaceを保ち、既存依存の小コードだけを同梱する。
    for name in MODULES:
        folder = ROOT / 'work' / name
        for path in folder.rglob('*.go'):
            add(path)
        add(folder / 'go.mod')
    for name, files in {
        '158技術特徴': ['README.md', '特徴の定義.md', '準備の確認.json', '停止の確認.json'],
        '158技術出口': ['README.md', '準備する.py', '準備の確認.json', '停止.json'],
    }.items():
        for file in files:
            add(ROOT / 'work' / name / file)
    for name in ('158研究条件', '158集計と閲覧'):
        for pattern in ('*.py', '*.mjs'):
            for path in (ROOT / 'work' / name).glob(pattern):
                add(path)
    # ----------------------------------------
    # 停止票が列挙する最小の独立源/人工/主票だけを一度格納する。
    numeric = json.loads((ROOT / 'work/158特徴の独立確認/停止の確認.json').read_bytes())
    for item in numeric['files']:
        path = ROOT / item['path']
        assert sha(path) == item['sha256']
        add(path)
    add(ROOT / 'work/158特徴の独立確認/停止の確認.json')
    checker = json.loads((ROOT / 'work/158結果の独立確認/停止の確認.json').read_bytes())
    for name, expected in checker['最小保存対象'].items():
        path = ROOT / 'work/158結果の独立確認' / name
        assert sha(path) == expected
        add(path)
    add(ROOT / 'work/158結果の独立確認/停止の確認.json')
    for name in ('特徴生成前.json', '金融前固定.json'):
        add(FORMAL / '検査' / name)
    add(FORMAL / '実行条件.md')
    add(FORMAL / '候補の固定.json')
    add(ROOT / 'docs/議論/手法と時間スケールの汎用表_版8.md')
    prepared_settings = HERE / '固定時文書/study/00158_複合技術で出口の役割と局面を切り替える/設定と結果.md'
    assert sha(prepared_settings) == EXPECTED_SETTINGS
    add(prepared_settings, 'study/00158_複合技術で出口の役割と局面を切り替える/設定と結果.md')
    add(FORMAL / '再現資料/README.md')
    add(Path(__file__))
    assert sha(FORMAL / '実行条件.md') == EXPECTED_SPEC
    assert sha(FORMAL / '候補の固定.json') == EXPECTED_BOOK
    assert sha(ROOT / 'work/158特徴の独立確認/自然確認_版2/確認.json') == '84575410f20bf8d521b87a4f4fc3b74ce68bc9862992dad50b443521fdf78e2f'
    assert sha(ROOT / 'work/158結果の独立確認/自然確認/独立確認.json') == 'eb34222e5e8e86f8cc7c829f36f831b5426716698b9f75bea78a87eb2f1fbb50'
    engine_stop = json.loads((ROOT / 'work/158技術出口/停止.json').read_bytes())
    for name, expected in engine_stop['源SHA256'].items():
        if name in selected:
            assert sha(selected[name]) == expected, name
    feature_prep = json.loads((ROOT / 'work/158技術特徴/準備の確認.json').read_bytes())
    for item in feature_prep['sources']:
        path = Path(item['path'])
        if path.suffix == '.exe':
            continue
        name = path.relative_to(ROOT).as_posix()
        if name in selected:
            assert sha(selected[name]) == item['sha256'], name

    package = ROOT / 'work/158集計と閲覧/node_modules/@oai/artifact-tool/package.json'
    sdk = json.loads(package.read_bytes())
    version = {name: command(args)['stdout'].strip() for name, args in {
        'Go': ['go', 'version'], '調査shellNode': ['node', '--version'],
    }.items()}
    version.update({'Python': platform.python_version(), '実行Python': sys.executable,
                    '特徴別算術NumPy': '2.5.3（自然主票記録）', 'Root集計NumPy': '未使用',
                    'CSV提供Node': 'v24.22.1（Root実行環境通知）',
                    'SDK': {'name': sdk['name'], 'version': sdk['version'], 'private': sdk['private'],
                            'dependencies': sdk['dependencies'], 'package_metadata_sha256': sha(package),
                            '提供SDK': True, 'runtime同梱': False}})
    result_proof = json.loads((ROOT / 'work/158結果の独立確認/自然確認/独立確認.json').read_bytes())
    ref_defs = {
        'inputs/00147_中位価格位置と実体回復/Sourceの出生と取得.json.gz': ('b99c49f06fe7e2306e59733b1cff26e3bb351f64edee220c98bc30b62c016d77', 'd42d25ec0fe41e8358c1227fd71b4377ffa90c96a8cf582f1ee4537ebf455d63'),
        'work/122全場入力/入力.json': ('6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec', None),
        'inputs/00157_固定入口と価格経路/固定入口入力.json': ('eabf9819351ef77fec44a7a132a8df13fd8a3aee7c3be6d87ac81dabe34ce279', None),
        'inputs/00157_固定入口と価格経路/価格テープ/価格テープの確認.json': ('05b703b99f4a444d0394aa40d5efd2c5ba9e7909f1a3261271143c239affb723', None),
        'inputs/00158_複合技術特徴/特徴/特徴の確認.json': ('a6dce32eb35102d95f44647d0a10811bf13ed6e36f46b08ef0956c52bb783d11', None),
        'study/00158_複合技術で出口の役割と局面を切り替える/成果物/出口結果.json.gz': ('70a4c3178206bbb3c8641901c7515f2121da11c28403b88c3f8e6f93cc0baa6c', '3c3df90244de838056ca7c98857ffe7b8f85514807e90194c07f73129ec277c7'),
        'work/158集計と閲覧/型付き表.json': ('506c8465150673f6ecfeb6d1263d08b4c6809652bcfdcfd94e342db08e3736f1', None),
        'study/00157_固定入口の到達距離と追尾退出を比較する/成果物/出口結果.json.gz': ('58bf2b448c7ca465e3e9f20ab78f10106d6a2c7312784d939acd7ffff22d2338', 'e03b01fbe1054ed65423adbc1f9aa359bf0f7ef895fc89f5f7763605d6e9e6e8'),
    }
    refs = {}
    for name, (expected, decoded) in ref_defs.items():
        p = ROOT / name
        assert p.is_file()
        if p.suffix == '.json' and p.stat().st_size < 512_000:
            assert sha(p) == expected
        refs[name] = {'sha256': expected, 'decoded_sha256': decoded,
                      'bytes': p.stat().st_size, 'ZIPへ格納': False,
                      '確認の由来': '小manifestは今回SHA照合。大資源は固定票/成功した自然・独立主票から参照し本文再読なし'}
    refs['work/122全場入力/入力.json']['復元手順'] = 'study/00122_E0固定条件を全セッションで検証する/再現資料/再現手順.md'
    entries = {}
    for name, p in sorted(selected.items()):
        data = p.read_bytes()
        entries[name] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data),
                         'crc32': f'{zlib.crc32(data):08x}', '元path': p.relative_to(ROOT).as_posix()}
    manifest = {'試行': 158, '用途': '結果後の再現資料。事前F0へ遡及追加しない',
                '格納ファイル': entries, '共有参照': refs, '依存': version,
                '当時exeSHA256': {'特徴': feature_prep['exe_sha256'], '出口': engine_stop['exeSHA256']},
                '固定時文書': {'元相対設定表': EXPECTED_SETTINGS,
                              '意味': '結果追記前の保存時現物。設定SHAがF0事前固定されていたとの主張はしない',
                              '現在正式文書': 'Root結果追記後は別版として保持し、元設定表と区別'},
                '検査の境界': result_proof['境界'] + ['特徴別算術は同一作者、ST/SAR/CK自然数式6列とMTF数値再実装は対象外'],
                '除外': ['Raw', '入力本体', 'feature gzip', '出口結果', '型付き表', 'CSV/画像',
                         'exe/dll', 'node_modules', 'cache', '159', '教材/外部調査の全件転記']}
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, p in sorted(selected.items()):
            info = zipfile.ZipInfo(name, (2026, 11, 13, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, p.read_bytes())
        z.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2).encode('utf-8'))
    restored = HERE / '復元確認'
    assert not restored.exists()
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
        assert set(z.namelist()) == set(entries) | {'manifest.json'}
        for name, expected in entries.items():
            data = z.read(name)
            assert len(data) == expected['bytes']
            assert hashlib.sha256(data).hexdigest() == expected['sha256']
            assert f'{zlib.crc32(data):08x}' == expected['crc32']
        z.extractall(restored)
    for name, p in selected.items():
        assert sha(p) == entries[name]['sha256'], name
        if name.endswith('.py'):
            compile((restored / name).read_bytes(), name, 'exec')

    def go_checks(name: str) -> dict:
        """機能: 復元Goモジュールの人工・vet・buildだけを実行する。

        引数: name(str)。返り値: dict。
        """
        cwd = restored / 'work' / name
        logs = [command(args, cwd) for args in (['go', 'test', '-count=1', './...'],
                                                ['go', 'vet', './...'], ['go', 'build', './...'])]
        return {'module': name, '実行': logs}
    with ThreadPoolExecutor(max_workers=2) as executor:
        go_logs = list(executor.map(go_checks, MODULES))
    node = [command(['node', '--check', str(restored / name)]) for name in selected if name.endswith('.mjs')]
    artificial = command([sys.executable, str(restored / 'work/158結果の独立確認/人工検査.py'),
                          '--output', str(restored / '再現した結果検査の人工.json')])
    for name, p in selected.items():
        assert sha(p) == entries[name]['sha256'], name
    links = []
    for raw in re.findall(r'\[[^\]]+\]\(([^)]+)\)', (FORMAL / '再現資料/README.md').read_text(encoding='utf-8')):
        if '://' not in raw and not raw.startswith('#'):
            p = (FORMAL / '再現資料' / raw.split('#')[0]).resolve()
            assert p.exists() or p == proof_path.resolve(), p
            links.append(raw)
    proof = {'成功': True, '試行': 158,
             'ZIP': {'path': target.relative_to(ROOT).as_posix(), 'sha256': sha(target), 'bytes': target.stat().st_size},
             '源ファイル': len(entries), 'manifest込み': len(entries)+1,
             '全格納SHA_bytes_CRC一致': True, '元源前後同体': True, 'Python全源構文': True,
             'Go復元人工_vet_build': go_logs, 'Node構文': node, '結果検査器復元人工': artificial,
             '再現READMEリンク': len(links), '自然再生成': False, '金融再計算': False, 'CSV再出力': False,
             '巨大資源複写': False, '159混入': False, '初期設定表SHA256': EXPECTED_SETTINGS,
             '特徴主票SHA256': numeric['natural_success_proof'], '結果主票SHA256': checker['主票SHA256'],
             '依存': version, '保存UTC': datetime.now(timezone.utc).isoformat(), '保存器SHA256': sha(Path(__file__))}
    proof_path.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, 'ZIP_SHA256': sha(target), '票SHA256': sha(proof_path),
                      '源数': len(entries), 'ZIP_bytes': target.stat().st_size}, ensure_ascii=False))


if __name__ == '__main__':
    main()
