"""158の実現決済差を、損失救済・利益伸長・利益喪失・未知へ分ける。"""
from pathlib import Path
from collections import Counter,defaultdict
import argparse
import gzip
import hashlib
import json


def classify(candidate: float, control: float) -> str:
    """
    機能: 双方の実現費用後損益の符号と大小から差の役割を分類する。
    引数: candidate/control(float)。返り値: str。
    """
    if candidate==control:
        return '同額'
    if control<0 and candidate>=0:
        return '赤字から非赤字へ救済'
    if control<0 and control<candidate<0:
        return '赤字額を軽減'
    if control>=0 and candidate<0:
        return '非赤字から赤字へ悪化'
    if control>0 and candidate>control:
        return '利益額を伸長'
    if control>0 and 0<=candidate<control:
        return '利益額を縮小'
    return 'その他の増減'


def main() -> None:
    """
    機能: 同一入口の既知決済だけを比較し、事後原因診断の要約を新規保存する。
    引数: CLI result/output(Path)。返り値: None。政策を変更しない。
    """
    parser=argparse.ArgumentParser()
    parser.add_argument('result',type=Path)
    parser.add_argument('output',type=Path)
    args=parser.parse_args()
    assert not args.output.exists()
    before=hashlib.sha256(args.result.read_bytes()).hexdigest()
    with gzip.open(args.result,'rt',encoding='utf-8') as source:
        data=json.load(source)
    assert data['success'] and data['trial']==158
    groups=defaultdict(lambda:{'全取得':0,'対応未知':0,'対応既知':0,'差引差':0,
        '利益総額差':0,'損失総額差':0,'分類':Counter(),'分類別差引差':Counter(),
        '候補決済理由':Counter(),'候補正益後赤字':0,'候補125後赤字':0,
        '125後赤字のうち粗益非負で費用負け':0,'125後赤字のうち粗益も赤字':0,
        '事後の改善上位例':[],'事後の悪化上位例':[]})
    for i,scene in enumerate(data['scenes']):
        for case in scene['cases']:
            policies={r['policy']:r for r in case['results']
                if r['horizon']=='H60' and r['delay']=='D1' and r['cost']=='C5'}
            for policy,r in policies.items():
                for benchmark in ('F125S125','T125W100TP250'):
                    b=policies[benchmark]
                    for member in case['memberships']:
                        for period in ('全73場','前48場' if i<48 else '後25場'):
                            key=(member['policy'],policy,benchmark,period)
                            a=groups[key]
                            a['全取得']+=1
                            if r['status']!=b['status'] or r['status']!='closed':
                                a['対応未知']+=1
                                continue
                            a['対応既知']+=1
                            delta=r['profit_yen']-b['profit_yen']
                            a['差引差']+=delta
                            a['利益総額差']+=max(0,r['profit_yen'])-max(0,b['profit_yen'])
                            a['損失総額差']+=max(0,-r['profit_yen'])-max(0,-b['profit_yen'])
                            category=classify(r['profit_yen'],b['profit_yen'])
                            a['分類'][category]+=1
                            a['分類別差引差'][category]+=delta
                            a['候補決済理由'][r['trigger']['reason']]+=1
                            a['候補正益後赤字']+=bool(r['profit_after_positive_loss'])
                            a['候補125後赤字']+=bool(r['profit_after125_loss'])
                            if r['profit_after125_loss']:
                                a['125後赤字のうち粗益非負で費用負け']+=r['profit_points']>=0
                                a['125後赤字のうち粗益も赤字']+=r['profit_points']<0
                            record={'case_id':case['id'],'session':scene['session'],'候補差引円':r['profit_yen'],
                                '対照差引円':b['profit_yen'],'差引差円':delta,'決済理由':r['trigger']['reason'],
                                '取得時刻':case['entry']['time'],'決済時刻':r['fill']['time'],
                                '実保有MFEpt':r['peak_points'],'実保有MAEpt':r['trough_points'],'追尾起動':r['armed']}
                            if delta>0:
                                a['事後の改善上位例'].append(record)
                                a['事後の改善上位例']=sorted(a['事後の改善上位例'],key=lambda x:-x['差引差円'])[:3]
                            if delta<0:
                                a['事後の悪化上位例'].append(record)
                                a['事後の悪化上位例']=sorted(a['事後の悪化上位例'],key=lambda x:x['差引差円'])[:3]
    rows=[]
    for key,a in sorted(groups.items()):
        assert a['対応既知']+a['対応未知']==a['全取得']
        assert sum(a['分類'].values())==a['対応既知']
        assert a['差引差']==a['利益総額差']-a['損失総額差']==sum(a['分類別差引差'].values())
        rows.append({'入口':key[0],'出口':key[1],'対照':key[2],'区間':key[3],**a})
    result={'成功':True,'試行':158,'範囲':'H60/D1/C5、同取得で双方既知の実現決済差だけ',
        '注意':'事後原因診断。退出後の仮想峰や機会損失を利益へ算入せず、未知額も0にしない。上位例を入口や政策の選別へ遡及利用しない。',
        '比較':rows,'結果SHA256':before,'コードSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    assert hashlib.sha256(args.result.read_bytes()).hexdigest()==before
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'群':len(rows)},ensure_ascii=False))


if __name__=='__main__':
    assert classify(-2,-5)=='赤字額を軽減'
    assert classify(2,-5)=='赤字から非赤字へ救済'
    assert classify(-2,5)=='非赤字から赤字へ悪化'
    assert classify(2,5)=='利益額を縮小'
    assert classify(7,5)=='利益額を伸長'
    main()
