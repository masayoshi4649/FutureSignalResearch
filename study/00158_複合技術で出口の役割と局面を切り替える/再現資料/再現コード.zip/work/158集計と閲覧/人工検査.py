"""固定入口の識別情報だけを使い、158の全群集計と共通既知順位を人工検査する。"""
from pathlib import Path
import importlib.util
import json

ROOT=Path(__file__).resolve().parents[2]
SPEC=importlib.util.spec_from_file_location('aggregation158',Path(__file__).with_name('集計する.py'))
MODULE=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def main() -> None:
    """
    機能: 152条件×固定837caseの人工だけで全表数/未知保持/順位を確認する。
    引数: なし。返り値: None。自然価格と損益ラベルを読まない。
    """
    fixed=json.loads((ROOT/'inputs/00157_固定入口と価格経路/固定入口入力.json').read_bytes())
    configs=[{'id':'/'.join((p,h,d,c)),'policy':p,'horizon':h,'delay':d,'cost':c,'fee_yen':1077 if c=='C5' else 77}
        for p in MODULE.POLICIES for h in ('H60','SESSION') for d in ('D0','D1') for c in ('C0','C5')]
    scenes=[]
    for scene in fixed['scenes']:
        cases=[]
        for case in scene['cases']:
            rows=[]
            for config in configs:
                rows.append({**config,'config_id':config['id'],'status':'closed','fill':{'time':case['entry']['time']+2},
                    'profit_points':125,'profit_yen':12500-config['fee_yen'],'armed':False,
                    'profit_after_positive_loss':False,'profit_after125_loss':False,
                    'held_seconds':2,'giveback_points':0})
            cases.append({'id':case['id'],'memberships':case['memberships'],'results':rows})
        scenes.append({'session':scene['session'],'cases':cases})
    result=MODULE.build({'success':True,'trial':158,'configurations':configs,'scenes':scenes})
    assert {k:len(t['rows']) for k,t in result['tables'].items()}=={'出口比較':912,'全セッション':22192,'研究順位と発動':38}
    table=result['tables']['出口比較']
    h=table['headers']
    assert len(h)==len(set(h))
    assert all(len(r)==len(h) for r in table['rows'])
    assert all(r[h.index('対応既知IFD差分円')]==0 and r[h.index('157対照_対応既知IFD差分円')]==0 for r in table['rows'])
    ranking=result['tables']['研究順位と発動']
    assert all(r[2]=='F125S125' for r in ranking['rows'] if r[1]==1)
    one=scenes[0]['cases'][0]['results'][0]
    one.update(status='unknown',fill=None,profit_points=None,profit_yen=None)
    partial=MODULE.build({'success':True,'trial':158,'configurations':configs,'scenes':scenes})
    assert any(r[h.index('全件確定差引円')] is None for r in partial['tables']['出口比較']['rows'])
    print('成功：152条件の全群/二対照/共通集合順位/未知保持')


if __name__=='__main__':
    main()
