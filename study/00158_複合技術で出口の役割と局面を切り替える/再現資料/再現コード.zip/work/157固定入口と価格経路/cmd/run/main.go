package main

import (
	"flag"
	"fmt"
	"os"
	"path/filepath"
	tape "pricetape157"
)

// main はRootの契約固定通知後だけ自然Rawの価格テープ生成を起動します。
//
// 引数: CLI input/sha256/output-dir(string)、workers(int)、execute-after-root-freeze(bool)。返り値: ありません。
func main() {
	input := flag.String("input", "", "固定入力JSON")
	sha := flag.String("sha256", "", "固定入力SHA256")
	output := flag.String("output-dir", "", "未作成出力先")
	workers := flag.Int("workers", 8, "全73場の並列数1..8")
	allow := flag.Bool("execute-after-root-freeze", false, "Root契約固定/自然実行通知後だけ指定")
	metadata := flag.Bool("metadata-only", false, "固定入力だけ検証しRawを開かない")
	flag.Parse()
	if *input == "" || flag.NArg() != 0 {
		fmt.Fprintln(os.Stderr, "inputとsha256が必要")
		os.Exit(2)
	}
	if *metadata {
		value, err := tape.LoadFixed(*input, *sha)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		fmt.Printf("固定入力検証成功: 場%d 物理%d 所属%d Raw読取なし\n", len(value.Scenes), value.ExpectedCaseCount, value.ExpectedMembershipCount)
		return
	}
	if !*allow || *output == "" {
		fmt.Fprintln(os.Stderr, "Root契約固定後の明示flag/input/sha256/未作成output-dirが必要")
		os.Exit(2)
	}
	i, e := filepath.Abs(*input)
	if e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
	o, e := filepath.Abs(*output)
	if e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
	if e = tape.Run157(i, *sha, o, *workers); e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
}
