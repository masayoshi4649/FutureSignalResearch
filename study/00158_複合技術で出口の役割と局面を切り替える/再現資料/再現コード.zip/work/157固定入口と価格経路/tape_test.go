package pricetape157

import (
	"bytes"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
	"time"
)

// raw157 は価格時計と10段気配を持つ人工WS行を作ります。
//
// 引数: at/last/bid/ask(float64)。返り値: []byte。
func raw157(at, last, bid, ask float64) []byte {
	row := map[string]any{"Symbol": "X", "CurrentPriceTime": time.Unix(int64(at), 0).UTC().Format(time.RFC3339Nano), "CurrentPrice": last}
	for i := 1; i <= 10; i++ {
		row["Buy"+string(rune('0'+i))] = map[string]float64{"Price": bid, "Qty": 1}
		row["Sell"+string(rune('0'+i))] = map[string]float64{"Price": ask, "Qty": 1}
	}
	// 10段目だけは二桁の固定名です。
	delete(row, "Buy:")
	delete(row, "Sell:")
	row["Buy10"] = map[string]float64{"Price": bid, "Qty": 1}
	row["Sell10"] = map[string]float64{"Price": ask, "Qty": 1}
	body, _ := json.Marshal(row)
	return append(body, '\n')
}

// fixture157 は場外・後退・異常BBO・同値・終端等号を含む人工Rawを作ります。
//
// 引数: t(*testing.T)。返り値: FixedScene157と人工ディレクトリstring。
func fixture157(t *testing.T) (FixedScene157, string) {
	t.Helper()
	dir := t.TempDir()
	raw := bytes.Join([][]byte{raw157(999, 100, 99, 101), raw157(1000, 100, 99, 101), raw157(1010, 100, 101, 100), raw157(1010, 100, 101, 100), raw157(1009, 100, 99, 101), raw157(1100, 101, 100, 102), raw157(9700, 102, 101, 103), raw157(9990, 103, 102, 104), raw157(10001, 104, 103, 105)}, nil)
	var compressed bytes.Buffer
	gz := gzip.NewWriter(&compressed)
	_, _ = gz.Write(raw)
	_ = gz.Close()
	path := filepath.Join(dir, "raw.gz")
	if e := os.WriteFile(path, compressed.Bytes(), 0644); e != nil {
		t.Fatal(e)
	}
	h := sha256.Sum256(compressed.Bytes())
	q := Quote{Clock: time.Unix(1100, 0).UTC().Format(time.RFC3339Nano), Time: 1100, Index: 3, SourceLine: 6, Last: 101, Bid: 100, Ask: 102, QuoteOK: true}
	quality := &Counts{Lines: 9, Outside: 2, Backward: 1, Accepted: 6, Delivered: 6, BadBBO: 2}
	s := FixedScene157{Session: "人工", Contract: "X", Start: 1000, End: 10000, ForceClose: 6000, ContinuousEnd: 9700, Raw: FileRef{Path: path, SHA256: hex.EncodeToString(h[:])}, ExpectedAccepted: 6, ExpectedQuality: quality}
	meta, _ := json.Marshal(map[string]any{"session": s.Session, "contract": s.Contract, "start": s.Start, "end": s.End, "force_close": s.ForceClose, "raw": map[string]any{"path": path, "sha256": s.Raw.SHA256, "bytes": len(compressed.Bytes()), "未知大整数": json.Number("9007199254740993")}, "expected_accepted": s.ExpectedAccepted, "expected_quality": quality})
	s.SourceScene = meta
	entry, _ := json.Marshal(map[string]any{"id": "case", "side": 1, "entry": q, "未知欄": nil})
	selection := json.RawMessage(`{"case_id":"case","session":"人工","side":1,"stream":"original","未知欄":{"大整数":9007199254740993}}`)
	s.Cases = []FixedCase157{{ID: "case", OriginalSide: 1, Side: 1, Stream: "original", Entry: q, EntryPrice: 102, SourceFixedEntry: entry, Memberships: []Membership157{{Policy: "153U15", SourceIndex: 0, Side: 1, Stream: "original", EntryPrice: 102, SourceSelectionRef: selection}}}}
	return s, dir
}

// TestFullAcceptedAndReader は全accepted行を同値/異常BBOも保持し終端だけ除くことを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestFullAcceptedAndReader(t *testing.T) {
	s, dir := fixture157(t)
	r, e := scanTape157(s, dir, "tapes/a.gz")
	if e != nil {
		t.Fatal(e)
	}
	if !r.Success || r.Tape.Rows != 4 || r.TapeBadBBO != 2 || len(r.EntryMatches) != 1 || r.EntryMatches[0].TapeLine != 4 || r.EntryMatches[0].Quote != s.Cases[0].Entry || r.Quality != *s.ExpectedQuality {
		t.Fatalf("全原行/品質/境界差:%+v", r)
	}
	var qs []Quote
	read, e := ReadTape(dir, r, func(q Quote) error { qs = append(qs, q); return nil })
	if e != nil {
		t.Fatal(e)
	}
	if !read.Success || len(qs) != 4 || qs[1].Time != qs[2].Time || qs[1].Last != qs[2].Last || qs[1].Index+1 != qs[2].Index || qs[1].QuoteOK || qs[3].Time >= s.ContinuousEnd {
		t.Fatal("同値又は異常行を削除した")
	}
}

// TestPlainAndMetadata は非圧縮magicと元全JSONの未利用値保持を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestPlainAndMetadata(t *testing.T) {
	s, dir := fixture157(t)
	body, e := os.ReadFile(s.Raw.Path)
	if e != nil {
		t.Fatal(e)
	}
	z, e := gzip.NewReader(bytes.NewReader(body))
	if e != nil {
		t.Fatal(e)
	}
	var raw bytes.Buffer
	_, _ = raw.ReadFrom(z)
	_ = z.Close()
	s.Raw.Path = filepath.Join(dir, "plain.jsonl")
	if e = os.WriteFile(s.Raw.Path, raw.Bytes(), 0644); e != nil {
		t.Fatal(e)
	}
	h := sha256.Sum256(raw.Bytes())
	s.Raw.SHA256 = hex.EncodeToString(h[:])
	var meta map[string]json.RawMessage
	_ = json.Unmarshal(s.SourceScene, &meta)
	meta["raw"], _ = json.Marshal(s.Raw)
	s.SourceScene, _ = json.Marshal(meta)
	before := append([]byte(nil), s.Cases[0].Memberships[0].SourceSelectionRef...)
	r, e := scanTape157(s, dir, "tapes/plain.gz")
	if e != nil {
		t.Fatal(e)
	}
	if r.RawEncoding != "plain" || !bytes.Equal(before, s.Cases[0].Memberships[0].SourceSelectionRef) || !bytes.Contains(before, []byte("9007199254740993")) {
		t.Fatal("元全JSON値の差")
	}
}

// TestEOFGuards は入口が既に見つかってもCRC/全品質/SHA差で成功させないことを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestEOFGuards(t *testing.T) {
	for _, kind := range []string{"CRC", "品質", "指紋"} {
		t.Run(kind, func(t *testing.T) {
			s, dir := fixture157(t)
			if kind == "CRC" {
				body, _ := os.ReadFile(s.Raw.Path)
				body[len(body)-8] ^= 1
				_ = os.WriteFile(s.Raw.Path, body, 0644)
				h := sha256.Sum256(body)
				s.Raw.SHA256 = hex.EncodeToString(h[:])
				var meta map[string]json.RawMessage
				_ = json.Unmarshal(s.SourceScene, &meta)
				meta["raw"], _ = json.Marshal(s.Raw)
				s.SourceScene, _ = json.Marshal(meta)
			}
			if kind == "品質" {
				s.ExpectedQuality.Lines++
				var meta map[string]json.RawMessage
				_ = json.Unmarshal(s.SourceScene, &meta)
				meta["expected_quality"], _ = json.Marshal(s.ExpectedQuality)
				s.SourceScene, _ = json.Marshal(meta)
			}
			if kind == "指紋" {
				s.Raw.SHA256 = strings.Repeat("0", 64)
				var meta map[string]json.RawMessage
				_ = json.Unmarshal(s.SourceScene, &meta)
				meta["raw"], _ = json.Marshal(s.Raw)
				s.SourceScene, _ = json.Marshal(meta)
			}
			r, e := scanTape157(s, dir, "tapes/fail.gz")
			if e == nil || r.Success {
				t.Fatal("EOF検証前の成功")
			}
			if _, e = os.Stat(filepath.Join(dir, "tapes/fail.gz")); !os.IsNotExist(e) {
				t.Fatal("不完了テープを完成名にした")
			}
		})
	}
}

// TestEntryAllQuoteMatch は固定時計/原行/全BBOの一値差でも停止することを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestEntryAllQuoteMatch(t *testing.T) {
	s, dir := fixture157(t)
	s.Cases[0].Entry.Last++
	var entry map[string]json.RawMessage
	_ = json.Unmarshal(s.Cases[0].SourceFixedEntry, &entry)
	entry["entry"], _ = json.Marshal(s.Cases[0].Entry)
	s.Cases[0].SourceFixedEntry, _ = json.Marshal(entry)
	r, e := scanTape157(s, dir, "tapes/mismatch.gz")
	if e == nil || r.Success {
		t.Fatal("入口全Quote差を許容")
	}
}

// TestReadTapeCRCAndPath は保存後の改変/CRC/path逃げを検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestReadTapeCRCAndPath(t *testing.T) {
	s, dir := fixture157(t)
	r, e := scanTape157(s, dir, "tapes/a.gz")
	if e != nil {
		t.Fatal(e)
	}
	bad := r
	bad.Tape.Path = "../外へ.gz"
	if _, e = ReadTape(dir, bad, nil); e == nil {
		t.Fatal("path逃げ許容")
	}
	path := filepath.Join(dir, filepath.FromSlash(r.Tape.Path))
	body, _ := os.ReadFile(path)
	body[len(body)-8] ^= 1
	_ = os.WriteFile(path, body, 0644)
	h := sha256.Sum256(body)
	r.Tape.SHA256 = hex.EncodeToString(h[:])
	if got, e := ReadTape(dir, r, nil); e == nil || got.Success {
		t.Fatal("テープCRC差許容")
	}
}

// TestFixedMembershipAndSchema は元売の実側と所属全値票の一致を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestFixedMembershipAndSchema(t *testing.T) {
	s, _ := fixture157(t)
	before := s.Cases[0].Entry
	if e := validateScene157(s); e != nil {
		t.Fatal(e)
	}
	s.Cases[0].OriginalSide = -1
	s.Cases[0].Stream = "reverse"
	s.Cases[0].Memberships[0].Stream = "reverse"
	var fixed map[string]json.RawMessage
	_ = json.Unmarshal(s.Cases[0].SourceFixedEntry, &fixed)
	fixed["side"] = json.RawMessage(`-1`)
	s.Cases[0].SourceFixedEntry, _ = json.Marshal(fixed)
	s.Cases[0].Memberships[0].SourceSelectionRef = json.RawMessage(`{"case_id":"case","session":"人工","side":1,"stream":"reverse"}`)
	if e := validateScene157(s); e != nil {
		t.Fatal(e)
	}
	if !reflect.DeepEqual(s.Cases[0].Entry, before) {
		t.Fatal("元売への対応で取得を変更")
	}
	s.Cases[0].Memberships[0].Side = -1
	if e := validateScene157(s); e == nil {
		t.Fatal("所属方向差許容")
	}
}
