// Package pricetape157 は固定入口を再判定せず、133と同じ採用原行を薄い価格テープへ保存します。
package pricetape157

import (
	"bufio"
	"bytes"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"os"
	"path/filepath"
	"strings"
	"sync"
)

type Membership157 struct {
	Policy             string          `json:"policy"`
	SourceIndex        int             `json:"source_index"`
	Side               int             `json:"side"`
	Stream             string          `json:"stream"`
	EntryPrice         float64         `json:"entry_price"`
	SourceSelectionRef json.RawMessage `json:"source_selection_ref"`
}

type FixedCase157 struct {
	ID               string          `json:"id"`
	OriginalSide     int             `json:"original_side"`
	Side             int             `json:"side"`
	Stream           string          `json:"stream"`
	Entry            Quote           `json:"entry"`
	EntryPrice       float64         `json:"entry_price"`
	SourceFixedEntry json.RawMessage `json:"source_fixed_entry"`
	Memberships      []Membership157 `json:"memberships"`
}

type FixedScene157 struct {
	Session          string          `json:"session"`
	Contract         string          `json:"contract"`
	Start            float64         `json:"start"`
	End              float64         `json:"end"`
	ForceClose       float64         `json:"force_close"`
	ContinuousEnd    float64         `json:"continuous_end"`
	Raw              FileRef         `json:"raw"`
	ExpectedAccepted int64           `json:"expected_accepted"`
	ExpectedQuality  *Counts         `json:"expected_quality"`
	SourceScene      json.RawMessage `json:"source_scene"`
	Cases            []FixedCase157  `json:"cases"`
}

type Input157 struct {
	Success                 bool            `json:"success"`
	Trial                   int             `json:"trial"`
	Schema                  string          `json:"schema"`
	SourceRefs              json.RawMessage `json:"source_refs"`
	Policies                json.RawMessage `json:"policies"`
	ExpectedCaseCount       int             `json:"expected_case_count"`
	ExpectedMembershipCount int             `json:"expected_membership_count"`
	Scenes                  []FixedScene157 `json:"scenes"`
}

type TapeRef157 struct {
	Path          string `json:"path"`
	SHA256        string `json:"sha256"`
	DecodedSHA256 string `json:"decoded_sha256"`
	Bytes         int64  `json:"bytes"`
	DecodedBytes  int64  `json:"decoded_bytes"`
	Rows          int64  `json:"rows"`
}

type EntryMatch157 struct {
	CaseID   string `json:"case_id"`
	Quote    Quote  `json:"quote"`
	TapeLine int64  `json:"tape_line"`
}

type SceneTape157 struct {
	Success       bool            `json:"success"`
	Error         string          `json:"error,omitempty"`
	Session       string          `json:"session"`
	Contract      string          `json:"contract"`
	Start         float64         `json:"start"`
	End           float64         `json:"end"`
	ForceClose    float64         `json:"force_close"`
	ContinuousEnd float64         `json:"continuous_end"`
	Raw           FileRef         `json:"raw"`
	ActualSHA256  string          `json:"actual_sha256"`
	Before        FileStat        `json:"stat_before"`
	After         FileStat        `json:"stat_after"`
	Quality       Counts          `json:"quality"`
	RawEncoding   string          `json:"raw_encoding"`
	RawPasses     int             `json:"raw_passes"`
	Tape          TapeRef157      `json:"tape"`
	FirstQuote    *Quote          `json:"first_quote"`
	LastQuote     *Quote          `json:"last_quote"`
	TapeBadBBO    int64           `json:"tape_bad_bbo"`
	EntryMatches  []EntryMatch157 `json:"entry_matches"`
}

type TapeManifest157 struct {
	Success         bool           `json:"success"`
	Trial           int            `json:"trial"`
	Schema          string         `json:"schema"`
	Input           FileRef        `json:"input"`
	SceneCount      int            `json:"scene_count"`
	CaseCount       int            `json:"case_count"`
	MembershipCount int            `json:"membership_count"`
	ClockBasis      string         `json:"clock_basis"`
	Scenes          []SceneTape157 `json:"scenes"`
}

type TapeRead157 struct {
	Success       bool   `json:"success"`
	Rows          int64  `json:"rows"`
	Bytes         int64  `json:"bytes"`
	DecodedBytes  int64  `json:"decoded_bytes"`
	SHA256        string `json:"sha256"`
	DecodedSHA256 string `json:"decoded_sha256"`
	FirstQuote    *Quote `json:"first_quote"`
	LastQuote     *Quote `json:"last_quote"`
}

// validSHA157 は小文字16進の固定指紋を確認します。
//
// 引数: value(string)。返り値: bool。
func validSHA157(value string) bool {
	if len(value) != 64 {
		return false
	}
	for _, c := range value {
		if !(c >= '0' && c <= '9' || c >= 'a' && c <= 'f') {
			return false
		}
	}
	return true
}

// validateScene157 は固定入口と全値元票の結合を価格本文の読取前に確認します。
//
// 引数: s(FixedScene157)。返り値: error。
func validateScene157(s FixedScene157) error {
	if strings.ContainsAny(s.Session, "/\\") || s.Session == "." || s.Session == ".." {
		return fmt.Errorf("場IDをpathへ利用できない")
	}
	if s.Session == "" || s.Contract == "" || !finite(s.Start, s.End, s.ForceClose, s.ContinuousEnd) || s.Start >= s.ForceClose || s.ForceClose >= s.ContinuousEnd || s.ContinuousEnd != s.End-300 || s.Raw.Path == "" || !validSHA157(s.Raw.SHA256) || s.ExpectedAccepted <= 0 || s.ExpectedQuality == nil || s.ExpectedQuality.Delivered != s.ExpectedAccepted {
		return fmt.Errorf("場/品質/終端/Rawの宣言差")
	}
	var meta struct {
		Raw              FileRef `json:"raw"`
		Session          string  `json:"session"`
		Contract         string  `json:"contract"`
		Start            float64 `json:"start"`
		End              float64 `json:"end"`
		ForceClose       float64 `json:"force_close"`
		ExpectedAccepted int64   `json:"expected_accepted"`
		ExpectedQuality  *Counts `json:"expected_quality"`
	}
	if json.Unmarshal(s.SourceScene, &meta) != nil || meta.Raw != s.Raw || meta.Session != s.Session || meta.Contract != s.Contract || meta.Start != s.Start || meta.End != s.End || meta.ForceClose != s.ForceClose || meta.ExpectedAccepted != s.ExpectedAccepted || meta.ExpectedQuality == nil || *meta.ExpectedQuality != *s.ExpectedQuality {
		return fmt.Errorf("元scene全値票と実利用値差")
	}
	seen := map[string]bool{}
	for _, c := range s.Cases {
		q := c.Entry
		if c.ID == "" || seen[c.ID] || (c.OriginalSide != 1 && c.OriginalSide != -1) || (c.Side != 1 && c.Side != -1) || !finite(q.Time, q.Last, q.Bid, q.Ask, c.EntryPrice) || q.Time < s.Start || q.Time >= math.Min(s.ForceClose, s.End-3900) || q.Index < 0 || q.Index >= s.ExpectedAccepted || q.SourceLine < q.Index+1 || q.Clock == "" || q.Last <= 0 || !q.QuoteOK || !normal(q) || len(c.Memberships) == 0 {
			return fmt.Errorf("固定case/取得/時計差:%s", c.ID)
		}
		seen[c.ID] = true
		wantSide := c.OriginalSide
		if c.Stream == "reverse" {
			wantSide = -wantSide
		} else if c.Stream != "original" {
			return fmt.Errorf("BBO以外のstream:%s", c.ID)
		}
		price := q.Ask
		if c.Side < 0 {
			price = q.Bid
		}
		if c.Side != wantSide || c.EntryPrice != price {
			return fmt.Errorf("固定方向/実側価格差:%s", c.ID)
		}
		var entry struct {
			ID    string `json:"id"`
			Side  int    `json:"side"`
			Entry Quote  `json:"entry"`
		}
		if json.Unmarshal(c.SourceFixedEntry, &entry) != nil || entry.ID != c.ID || entry.Side != c.OriginalSide || entry.Entry != c.Entry {
			return fmt.Errorf("元fixed全値票差:%s", c.ID)
		}
		members := map[string]bool{}
		for _, m := range c.Memberships {
			if (m.Policy != "153U15" && m.Policy != "152U0") || members[m.Policy] || m.SourceIndex < 0 || m.Side != c.Side || m.Stream != c.Stream || m.EntryPrice != price {
				return fmt.Errorf("所属/共通case方向差:%s", c.ID)
			}
			members[m.Policy] = true
			var ref struct {
				CaseID  string `json:"case_id"`
				Session string `json:"session"`
				Side    int    `json:"side"`
				Stream  string `json:"stream"`
			}
			if json.Unmarshal(m.SourceSelectionRef, &ref) != nil || ref.CaseID != c.ID || ref.Session != s.Session || ref.Side != m.Side || ref.Stream != m.Stream {
				return fmt.Errorf("元選択全値票差:%s", c.ID)
			}
		}
	}
	return nil
}

// LoadFixed は固定入力指紋と全73場/837case/924所属を確認します。
//
// 引数: path/expected(string)。返り値: Input157/error。Rawや保存観測は読みません。
func LoadFixed(path, expected string) (Input157, error) {
	var in Input157
	if !validSHA157(expected) {
		return in, fmt.Errorf("固定入力SHAが必要")
	}
	body, e := os.ReadFile(path)
	if e != nil {
		return in, e
	}
	h := sha256.Sum256(body)
	if hex.EncodeToString(h[:]) != expected {
		return in, fmt.Errorf("固定入力SHA差")
	}
	if e = json.Unmarshal(body, &in); e != nil {
		return in, e
	}
	if !in.Success || in.Trial != 157 || in.Schema != "fixed_exit_entries_v1" || len(in.Scenes) != 73 || in.ExpectedCaseCount != 837 || in.ExpectedMembershipCount != 924 || len(in.SourceRefs) == 0 || len(in.Policies) == 0 {
		return in, fmt.Errorf("固定入力の用途/件数差")
	}
	var policies []struct {
		ID              string `json:"id"`
		SourceTrial     int    `json:"source_trial"`
		SourcePolicy    string `json:"source_policy"`
		MembershipCount int    `json:"membership_count"`
	}
	if json.Unmarshal(in.Policies, &policies) != nil || len(policies) != 2 || policies[0].ID != "153U15" || policies[0].SourceTrial != 153 || policies[0].SourcePolicy != "U15" || policies[0].MembershipCount != 93 || policies[1].ID != "152U0" || policies[1].SourceTrial != 152 || policies[1].SourcePolicy != "U0" || policies[1].MembershipCount != 831 {
		return in, fmt.Errorf("元政策宣言差（152U1へ交換しない）")
	}
	seen := map[string]bool{}
	counts := map[string]int{}
	members := map[string]map[int]bool{"153U15": {}, "152U0": {}}
	cases, total := 0, 0
	previous := 0.0
	for _, s := range in.Scenes {
		if seen[s.Session] || s.Start <= previous {
			return in, fmt.Errorf("場順又は重複差")
		}
		seen[s.Session] = true
		previous = s.End
		if e = validateScene157(s); e != nil {
			return in, fmt.Errorf("%s:%w", s.Session, e)
		}
		cases += len(s.Cases)
		for _, c := range s.Cases {
			for _, m := range c.Memberships {
				if members[m.Policy][m.SourceIndex] {
					return in, fmt.Errorf("所属元index重複")
				}
				members[m.Policy][m.SourceIndex] = true
				counts[m.Policy]++
				total++
			}
		}
	}
	if cases != 837 || total != 924 || counts["153U15"] != 93 || counts["152U0"] != 831 {
		return in, fmt.Errorf("所属の総数差")
	}
	for policy, indices := range members {
		for i := 0; i < counts[policy]; i++ {
			if !indices[i] {
				return in, fmt.Errorf("所属元index欠落")
			}
		}
	}
	return in, nil
}

type countedWriter157 struct {
	Writer io.Writer
	Bytes  int64
}

// Write は書込みbytesを指紋対象と同じ経路で数えます。
//
// 引数: body([]byte)。返り値: int/error。
func (w *countedWriter157) Write(body []byte) (int, error) {
	n, e := w.Writer.Write(body)
	w.Bytes += int64(n)
	return n, e
}

// scanTape157 は当場Rawを一走査し、全accepted Quoteと入口witnessを保存します。
//
// 引数: s(FixedScene157)、directory/relative(string)。返り値: SceneTape157/error。
func scanTape157(s FixedScene157, directory, relative string) (out SceneTape157, err error) {
	out = SceneTape157{Session: s.Session, Contract: s.Contract, Start: s.Start, End: s.End, ForceClose: s.ForceClose, ContinuousEnd: s.ContinuousEnd, Raw: s.Raw, RawPasses: 1, EntryMatches: []EntryMatch157{}}
	if err = validateScene157(s); err != nil {
		return out, err
	}
	f, e := os.Open(s.Raw.Path)
	if e != nil {
		return out, e
	}
	defer f.Close()
	before, e := f.Stat()
	if e != nil {
		return out, e
	}
	out.Before = FileStat{Bytes: before.Size(), ModTimeNS: before.ModTime().UnixNano()}
	var originalRaw struct {
		Raw struct {
			Bytes int64 `json:"bytes"`
		} `json:"raw"`
	}
	if e = json.Unmarshal(s.SourceScene, &originalRaw); e != nil {
		return out, e
	}
	if originalRaw.Raw.Bytes > 0 && originalRaw.Raw.Bytes != before.Size() {
		return out, fmt.Errorf("宣言Raw bytes差")
	}
	rawHash := sha256.New()
	tee := io.TeeReader(f, rawHash)
	z, encoding, e := rawStream133(tee)
	if e != nil {
		return out, e
	}
	defer z.Close()
	out.RawEncoding = encoding
	final := filepath.Join(directory, filepath.FromSlash(relative))
	if e = os.MkdirAll(filepath.Dir(final), 0755); e != nil {
		return out, e
	}
	part := final + ".part"
	target, e := os.OpenFile(part, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0644)
	if e != nil {
		return out, e
	}
	defer target.Close()
	physicalHash, decodedHash := sha256.New(), sha256.New()
	physical := &countedWriter157{Writer: io.MultiWriter(target, physicalHash)}
	gz := gzip.NewWriter(physical)
	closed := false
	defer func() {
		if !closed {
			_ = gz.Close()
		}
	}()
	decoded := &countedWriter157{Writer: io.MultiWriter(gz, decodedHash)}
	encoder := json.NewEncoder(decoded)
	wanted := map[int64][]FixedCase157{}
	for _, c := range s.Cases {
		wanted[c.Entry.SourceLine] = append(wanted[c.Entry.SourceLine], c)
	}
	parserScene := Scene{Session: s.Session, Contract: s.Contract, Start: s.Start, End: s.End, Raw: s.Raw}
	contracts := map[string]bool{}
	previous := s.Start
	var index int64
	scan := bufio.NewScanner(z)
	scan.Buffer(make([]byte, 65536), 8*1024*1024)
	for scan.Scan() {
		out.Quality.Lines++
		q, reason, next, e := decodeRow(scan.Bytes(), out.Quality.Lines, index, parserScene, previous, &out.Quality, contracts)
		previous = next
		if e != nil {
			return out, e
		}
		if q != nil {
			index++
		}
		for _, c := range wanted[out.Quality.Lines] {
			if q == nil || c.Entry != *q || q.Time >= s.ContinuousEnd {
				return out, fmt.Errorf("入口原行全Quote差:%s:%s", c.ID, reason)
			}
			out.EntryMatches = append(out.EntryMatches, EntryMatch157{CaseID: c.ID, Quote: *q, TapeLine: out.Tape.Rows + 1})
		}
		if q == nil || q.Time >= s.ContinuousEnd {
			continue
		}
		if e = encoder.Encode(q); e != nil {
			return out, e
		}
		out.Tape.Rows++
		if !q.QuoteOK {
			out.TapeBadBBO++
		}
		if out.FirstQuote == nil {
			x := *q
			out.FirstQuote = &x
		}
		x := *q
		out.LastQuote = &x
	}
	if e = scan.Err(); e != nil {
		return out, e
	}
	if _, e = io.Copy(io.Discard, tee); e != nil {
		return out, e
	}
	after, e := f.Stat()
	if e != nil {
		return out, e
	}
	out.After = FileStat{Bytes: after.Size(), ModTimeNS: after.ModTime().UnixNano()}
	out.ActualSHA256 = hex.EncodeToString(rawHash.Sum(nil))
	if out.ActualSHA256 != s.Raw.SHA256 || out.Before != out.After || len(contracts) != 1 || !contracts[s.Contract] || index != s.ExpectedAccepted || out.Quality != *s.ExpectedQuality || len(out.EntryMatches) != len(s.Cases) {
		return out, fmt.Errorf("EOF後のRaw指紋/stat/限月/品質/入口全件性差")
	}
	if e = gz.Close(); e != nil {
		return out, e
	}
	closed = true
	if e = target.Close(); e != nil {
		return out, e
	}
	out.Tape.Path = filepath.ToSlash(relative)
	out.Tape.SHA256 = hex.EncodeToString(physicalHash.Sum(nil))
	out.Tape.DecodedSHA256 = hex.EncodeToString(decodedHash.Sum(nil))
	out.Tape.Bytes = physical.Bytes
	out.Tape.DecodedBytes = decoded.Bytes
	if _, e = os.Stat(final); !os.IsNotExist(e) {
		return out, fmt.Errorf("完成テープは未作成先のみ")
	}
	if e = os.Rename(part, final); e != nil {
		return out, e
	}
	out.Success = true
	return out, nil
}

// Run157 は固定入力だけから全73場のテープを生成し、完読成功後だけmanifestを保存します。
//
// 引数: input/expected/output(string)、workers(int)。返り値: error。入口や出口は再選択しません。
func Run157(input, expected, output string, workers int) error {
	if workers < 1 || workers > 8 {
		return fmt.Errorf("workersは1..8")
	}
	in, e := LoadFixed(input, expected)
	if e != nil {
		return e
	}
	if _, e = os.Stat(output); !os.IsNotExist(e) {
		return fmt.Errorf("未作成output-dirのみ")
	}
	if e = os.MkdirAll(output, 0755); e != nil {
		return e
	}
	results := make([]SceneTape157, len(in.Scenes))
	jobs := make(chan int)
	var wg sync.WaitGroup
	for n := 0; n < workers; n++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for i := range jobs {
				relative := fmt.Sprintf("tapes/%03d_%s.jsonl.gz", i, in.Scenes[i].Session)
				r, err := scanTape157(in.Scenes[i], output, relative)
				if err != nil {
					r.Error = err.Error()
				}
				results[i] = r
				fmt.Printf("%s 成功=%t テープ行=%d %s\n", r.Session, r.Success, r.Tape.Rows, r.Error)
			}
		}()
	}
	for i := range in.Scenes {
		jobs <- i
	}
	close(jobs)
	wg.Wait()
	for _, r := range results {
		if !r.Success {
			return fmt.Errorf("%s:%s（部分テープを全体成功へ転用しない）", r.Session, r.Error)
		}
	}
	if _, e = LoadFixed(input, expected); e != nil {
		return e
	}
	manifest := TapeManifest157{Success: true, Trial: 157, Schema: "accepted_quote_tapes_v1", Input: FileRef{Path: input, SHA256: expected}, SceneCount: 73, CaseCount: 837, MembershipCount: 924, ClockBasis: "CurrentPriceTimeの価格時計。同時計はaccepted index/物理source_line。実受信時刻ではない。", Scenes: results}
	body, e := json.MarshalIndent(manifest, "", "  ")
	if e != nil {
		return e
	}
	body = append(body, '\n')
	f, e := os.OpenFile(filepath.Join(output, "価格テープの確認.json"), os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0644)
	if e != nil {
		return e
	}
	_, e = f.Write(body)
	closeErr := f.Close()
	if e != nil {
		return e
	}
	return closeErr
}

// ReadManifest は生成完了票を明示指紋で認証します。
//
// 引数: path/expected(string)。返り値: TapeManifest157/error。価格テープはまだ開きません。
func ReadManifest(path, expected string) (TapeManifest157, error) {
	var out TapeManifest157
	if !validSHA157(expected) {
		return out, fmt.Errorf("manifest SHAが必要")
	}
	body, e := os.ReadFile(path)
	if e != nil {
		return out, e
	}
	h := sha256.Sum256(body)
	if hex.EncodeToString(h[:]) != expected {
		return out, fmt.Errorf("manifest SHA差")
	}
	if e = json.Unmarshal(body, &out); e != nil {
		return out, e
	}
	if !out.Success || out.Trial != 157 || out.Schema != "accepted_quote_tapes_v1" || out.SceneCount != 73 || len(out.Scenes) != 73 || out.CaseCount != 837 || out.MembershipCount != 924 {
		return out, fmt.Errorf("manifest用途/件数差")
	}
	return out, nil
}

// ReadTape は価格テープを順番に配信し、全完読CRC/物理解凍指紋/件数を検査します。
//
// 引数: directory(string)、scene(SceneTape157)、consume(func(Quote)error)。返り値: TapeRead157/error。
// consumeの途中状態は最終成功まで正本化しないでください。受取側からテープへ値を返しません。
func ReadTape(directory string, scene SceneTape157, consume func(Quote) error) (out TapeRead157, err error) {
	ref := scene.Tape
	if !scene.Success || !validSHA157(ref.SHA256) || !validSHA157(ref.DecodedSHA256) || filepath.IsAbs(ref.Path) {
		return out, fmt.Errorf("テープ宣言差")
	}
	clean := filepath.Clean(filepath.FromSlash(ref.Path))
	if !filepath.IsLocal(clean) {
		return out, fmt.Errorf("テープpathは相対localのみ")
	}
	if clean == ".." || strings.HasPrefix(clean, ".."+string(filepath.Separator)) {
		return out, fmt.Errorf("テープpathはmanifest配下のみ")
	}
	f, e := os.Open(filepath.Join(directory, clean))
	if e != nil {
		return out, e
	}
	defer f.Close()
	before, e := f.Stat()
	if e != nil {
		return out, e
	}
	if before.Size() != ref.Bytes {
		return out, fmt.Errorf("テープsize差")
	}
	physicalHash, decodedHash := sha256.New(), sha256.New()
	tee := io.TeeReader(f, physicalHash)
	z, e := gzip.NewReader(tee)
	if e != nil {
		return out, e
	}
	defer z.Close()
	decoded := &countedReader157{Reader: io.TeeReader(z, decodedHash)}
	scan := bufio.NewScanner(decoded)
	scan.Buffer(make([]byte, 65536), 8*1024*1024)
	var previous *Quote
	for scan.Scan() {
		var q Quote
		decoder := json.NewDecoder(bytes.NewReader(scan.Bytes()))
		if e = decoder.Decode(&q); e != nil {
			return out, e
		}
		if !finite(q.Time, q.Last, q.Bid, q.Ask) || q.Clock == "" || q.Last <= 0 || q.Time < scene.Start || q.Time >= scene.ContinuousEnd || q.Index < 0 || q.SourceLine < q.Index+1 || q.QuoteOK != normal(q) {
			return out, fmt.Errorf("テープQuote品質差")
		}
		if previous != nil && (q.Time < previous.Time || q.Index != previous.Index+1 || q.SourceLine <= previous.SourceLine) {
			return out, fmt.Errorf("テープ順序/採用Index差")
		}
		if previous == nil && q.Index != 0 {
			return out, fmt.Errorf("テープ先頭採用Indexは0")
		}
		if out.FirstQuote == nil {
			x := q
			out.FirstQuote = &x
		}
		x := q
		out.LastQuote = &x
		previous = &x
		out.Rows++
		if consume != nil {
			if e = consume(q); e != nil {
				return out, e
			}
		}
	}
	if e = scan.Err(); e != nil {
		return out, e
	}
	if _, e = io.Copy(io.Discard, tee); e != nil {
		return out, e
	}
	after, e := f.Stat()
	if e != nil {
		return out, e
	}
	out.Bytes = before.Size()
	out.DecodedBytes = decoded.Bytes
	out.SHA256 = hex.EncodeToString(physicalHash.Sum(nil))
	out.DecodedSHA256 = hex.EncodeToString(decodedHash.Sum(nil))
	if out.Rows != ref.Rows || out.DecodedBytes != ref.DecodedBytes || out.SHA256 != ref.SHA256 || out.DecodedSHA256 != ref.DecodedSHA256 || before.Size() != after.Size() || before.ModTime() != after.ModTime() {
		return out, fmt.Errorf("テープ全CRC/SHA/stat/件数差")
	}
	if (out.FirstQuote == nil) != (scene.FirstQuote == nil) || out.FirstQuote != nil && *out.FirstQuote != *scene.FirstQuote || (out.LastQuote == nil) != (scene.LastQuote == nil) || out.LastQuote != nil && *out.LastQuote != *scene.LastQuote {
		return out, fmt.Errorf("テープ端Quote差")
	}
	out.Success = true
	return out, nil
}

type countedReader157 struct {
	Reader io.Reader
	Bytes  int64
}

// Read は解凍bytesを同じ指紋経路で数えます。
//
// 引数: body([]byte)。返り値: int/error。
func (r *countedReader157) Read(body []byte) (int, error) {
	n, e := r.Reader.Read(body)
	r.Bytes += int64(n)
	return n, e
}
