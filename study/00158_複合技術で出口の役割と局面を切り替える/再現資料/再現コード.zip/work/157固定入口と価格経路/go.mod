module pricetape157

go 1.24.2
