"""別算術検査器の窓端/量scope/鮮度/未知を自然実行前に確認する。"""
import importlib.util
import json
import math
from pathlib import Path
import unittest

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('audit',HERE/'確認する.py')
audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)


def bar(i: int, close: float, volume: float=1.) -> dict:
    """
    機能: 手計算可能な同一由来OHLCVを作る。
    引数: i(int)、close/volume(float)。返り値: dict。
    """
    return {'id':str(i),'start':i*60,'end':i*60+60,'closed':True,'missing':False,
            'price_known':True,'volume_known':True,'ohlc':{'open':close,'high':close+2,'low':close-2,'close':close},'volume':volume}


class Tests(unittest.TestCase):
    def test_trd22と前除外(self) -> None:
        """
        機能: TRDの2足前Closeと22本助走/先行窓を手計算する。
        引数: self(Tests)。返り値: None。
        """
        bars=[bar(i,100) for i in range(22)];bars[0]=bar(0,130)
        x=audit.price_run(bars)
        self.assertTrue(math.isnan(x['trd_mean20'][20]))
        self.assertAlmostEqual(x['trd_mean20'][21],(32+19*4)/20)
        self.assertAlmostEqual(x['trd_sd20'][21],math.sqrt(((32-5.4)**2+19*(4-5.4)**2)/20))
        bars[-1]=bar(21,200);x=audit.price_run(bars)
        self.assertEqual(x['high20'][-1],202);self.assertEqual(x['prior_high20'][-1],102)

    def test相対量当足除外とBBO非依存(self) -> None:
        """
        機能: 当量を分母へ混ぜずQuote/BBO欄を量へ使わないことを確認する。
        引数: self(Tests)。返り値: None。
        """
        bars=[bar(i,100,2) for i in range(21)];bars[-1]['volume']=20
        keys=['rvol','relative_volume20','volume_relative_prior3','hist']
        a,_=audit.compute(bars,keys)
        self.assertEqual(a[-1]['rvol'],10)
        for b in bars:b['bid']=1;b['ask']=999999;b['last']=999999;b['quote_ok']=False
        b,_=audit.compute(bars,keys);self.assertEqual(a,b)

    def testprefix非回復と0量(self) -> None:
        """
        機能: unknown量とknown0を分け有限窓だけが回復することを確認する。
        引数: self(Tests)。返り値: None。
        """
        bars=[bar(i,100,1) for i in range(40)];bars[0]['volume_known']=False
        keys=['rvol','cmf20','hlc3_vwma20','session_vwap_proxy','session_volume','hist']
        a,_=audit.compute(bars,keys);self.assertIsNone(a[-1]['session_vwap_proxy']);self.assertEqual(a[-1]['hlc3_vwma20'],100)
        bars=[bar(i,100,0) for i in range(22)];a,_=audit.compute(bars,keys)
        self.assertEqual(a[-1]['obv_delta5'],0);self.assertIsNone(a[-1]['cmf20']);self.assertIsNone(a[-1]['rvol'])
        bars=[bar(0,100,0),bar(1,101,2)];bars[0]['price_known']=False
        a,_=audit.compute(bars,keys);self.assertEqual(a[-1]['session_vwap_proxy'],101)

    def test欠分を詰めない(self) -> None:
        """
        機能: 価格未知後の数値助走をresetすることを確認する。
        引数: self(Tests)。返り値: None。
        """
        bars=[bar(i,100+i) for i in range(60)];bars[40]['price_known']=False
        a,_=audit.compute(bars,['ema21','hist']);self.assertIsNotNone(a[39]['hist']);self.assertIsNone(a[-1]['hist']);self.assertIsNone(a[-1]['ema21'])

    def test期限等号と未来index(self) -> None:
        """
        機能: 鮮度等号と同秒未来indexが拒否されることを確認する。
        引数: self(Tests)。返り値: None。
        """
        value={'known':True,'value':1,'valid_until':240,'ref_ids':['x']}
        audit.check_value(value,{'time':239})
        with self.assertRaises(AssertionError):audit.check_value(value,{'time':240})
        self.assertFalse(audit.before({'time':100,'index':11,'source_line':12},{'time':100,'index':10,'source_line':12}))


def main() -> None:
    """
    機能: 自然値を読まず検査器の人工5群を実行する。
    引数: なし。返り値: None。
    """
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(Tests)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    assert result.wasSuccessful()
    (HERE/'人工の確認.json').write_text(json.dumps({'success':True,'groups':result.testsRun,'natural_read':False,'code':audit.fingerprint(Path(__file__))},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


if __name__=='__main__':main()
