"""147canonicalと158保存特徴を別言語/NumPy算術で全件照合する。Go作者関数は呼ばない。"""
from __future__ import annotations

import argparse
from collections import Counter
import gzip
import hashlib
import json
import math
from pathlib import Path
import re
import time

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
PARENT = ROOT / 'inputs/00147_中位価格位置と実体回復/Sourceの出生と取得.json.gz'
PARENT_SHA = 'b99c49f06fe7e2306e59733b1cff26e3bb351f64edee220c98bc30b62c016d77'
PARENT_DECODED = 'd42d25ec0fe41e8358c1227fd71b4377ffa90c96a8cf582f1ee4537ebf455d63'
MANIFEST = ROOT / 'inputs/00158_複合技術特徴/特徴/特徴の確認.json'
MANIFEST_SHA = 'a6dce32eb35102d95f44647d0a10811bf13ed6e36f46b08ef0956c52bb783d11'
UNTESTED_NUMERIC = {'supertrend_line', 'supertrend_direction', 'psar_line', 'psar_direction',
                    'ck_high_stop', 'ck_low_stop'}


def fingerprint(path: Path) -> dict:
    """
    機能: 全物理bytesのSHAと前後statを照合する。
    引数: path(Path)。返り値: dict。
    """
    old = path.stat(); h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(4 << 20), b''):
            h.update(chunk)
    now = path.stat()
    assert (old.st_size, old.st_mtime_ns) == (now.st_size, now.st_mtime_ns), path
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': old.st_size,
            'mtime_ns': old.st_mtime_ns, 'sha256': h.hexdigest()}


def scenes(path: Path, evidence: dict):
    """
    機能: 大きな147gzipのscenesを一場ずつ解釈し終端CRC/解凍SHAを確定する。
    引数: path(Path)、evidence(dict)。返り値: Iterator[dict]。
    """
    h = hashlib.sha256(); size = 0; decoder = json.JSONDecoder(); buffer = ''
    marker = re.compile(r'(?m)^  "scenes": \[')
    with gzip.open(path, 'rt', encoding='utf-8', newline='') as stream:
        def more() -> str:
            """
            機能: 元UTF8 bytesを指紋化しながら一塊読む。
            引数: なし。返り値: str。
            """
            nonlocal size
            chunk = stream.read(1 << 20); body = chunk.encode('utf-8')
            h.update(body); size += len(body); return chunk
        while True:
            chunk = more(); assert chunk, '親scenes無し'
            buffer += chunk; match = marker.search(buffer)
            if match:
                buffer = buffer[match.end():]; break
        while True:
            buffer = buffer.lstrip()
            if buffer.startswith(']'): break
            if buffer.startswith(','): buffer = buffer[1:].lstrip()
            try: value, end = decoder.raw_decode(buffer)
            except json.JSONDecodeError:
                chunk = more(); assert chunk, '親scenes途中終了'; buffer += chunk; continue
            yield value
            buffer = buffer[end:]
        while more(): pass
    evidence.update(decoded_sha256=h.hexdigest(), decoded_bytes=size, full_crc_checked=True)


def stamp(value: dict) -> tuple:
    """
    機能: 原行の3時計を同一順に取り出す。
    引数: value(dict)。返り値: tuple[float,int,int]。
    """
    return value['time'], value['index'], value['source_line']


def before(a: dict, b: dict) -> bool:
    """
    機能: 同場のtime/index/物理行が全て現在以前かを検査する。
    引数: a/b(dict)。返り値: bool。
    """
    return all(x <= y for x, y in zip(stamp(a), stamp(b)))


def run_smooth(values: np.ndarray, period: int, alpha: float) -> np.ndarray:
    """
    機能: 連続finite区間ごとSMA seed後の指数平滑を別算術で求める。
    引数: values(np.ndarray)、period(int)、alpha(float)。返り値: np.ndarray。
    """
    out = np.full(len(values), np.nan)
    for first, last in finite_runs(np.isfinite(values)):
        if last - first < period: continue
        i = first + period - 1; out[i] = np.mean(values[first:i + 1])
        for j in range(i + 1, last):
            out[j] = (1 - alpha) * out[j - 1] + alpha * values[j]
    return out


def finite_runs(mask: np.ndarray):
    """
    機能: 欠測を詰めない連続true区間を抽出する。
    引数: mask(np.ndarray[bool])。返り値: Iterator[tuple[int,int]]。
    """
    edges = np.flatnonzero(np.diff(np.r_[False, mask, False].astype(np.int8)))
    yield from zip(edges[::2], edges[1::2])


def previous(values: np.ndarray) -> np.ndarray:
    """
    機能: 同じ連続runの実前値を一つずらす。
    引数: values(np.ndarray)。返り値: np.ndarray。
    """
    return np.r_[np.nan, values[:-1]]


def price_run(bars: list[dict]) -> dict[str, np.ndarray]:
    """
    機能: 価格完全既知の一連続区間の主要数値をNumPyと閉形式で求める。
    引数: bars(list[dict])。返り値: dict[str,np.ndarray]。方向水準6列は対象外。
    """
    n = len(bars); o = np.array([b['ohlc']['open'] for b in bars], float)
    h = np.array([b['ohlc']['high'] for b in bars], float)
    l = np.array([b['ohlc']['low'] for b in bars], float)
    c = np.array([b['ohlc']['close'] for b in bars], float)
    p = previous(c); width = h - l
    tr = np.maximum.reduce([width, np.abs(h - p), np.abs(l - p)])
    tr[0] = width[0]
    out = {'open': o, 'high': h, 'low': l, 'close': c, 'previous_close': p,
           'body': c-o, 'upper_wick': h-np.maximum(o,c), 'lower_wick': np.minimum(o,c)-l,
           'range': width, 'body_ratio': np.divide(c-o,width,out=np.full(n,np.nan),where=width>0),
           'tr':tr, 'atr14':run_smooth(tr,14,1/14)}
    out['previous_atr14'] = previous(out['atr14'])
    for w in (8, 21):
        out[f'ema{w}'] = run_smooth(c,w,2/(w+1))
        out[f'ema{w}_delta'] = out[f'ema{w}']-previous(out[f'ema{w}'])
    out['gap'] = out['ema8']-out['ema21']
    out['macd'] = run_smooth(c,12,2/13)-run_smooth(c,26,2/27)
    out['macd_signal'] = run_smooth(out['macd'],9,2/10)
    out['hist'] = out['macd']-out['macd_signal']; out['hist_delta'] = out['hist']-previous(out['hist'])
    changes = c-p; gains = run_smooth(np.maximum(changes,0),14,1/14)
    losses = run_smooth(np.maximum(-changes,0),14,1/14)
    rsi = np.full(n,np.nan)
    for i in np.flatnonzero(np.isfinite(gains)):
        rsi[i] = 50 if gains[i]==losses[i]==0 else (100 if losses[i]==0 else 100-100/(1+gains[i]/losses[i]))
    out['rsi14'] = rsi; out['rsi_delta'] = rsi-previous(rsi)
    up, down = h-previous(h), previous(l)-l
    pos = np.where((up>down)&(up>0),up,0.); neg = np.where((down>up)&(down>0),down,0.)
    pos[0]=neg[0]=np.nan
    dmtr=tr.copy();dmtr[0]=np.nan
    dmtr=run_smooth(dmtr,14,1/14);pos=run_smooth(pos,14,1/14);neg=run_smooth(neg,14,1/14)
    ok=(dmtr>0)&((pos+neg)>0)
    plus=np.divide(100*pos,dmtr,out=np.full(n,np.nan),where=ok)
    minus=np.divide(100*neg,dmtr,out=np.full(n,np.nan),where=ok)
    out['di_plus']=plus;out['di_minus']=minus;out['di_difference']=plus-minus
    dx=np.divide(100*np.abs(plus-minus),plus+minus,out=np.full(n,np.nan),where=(plus+minus)>0)
    out['adx14']=run_smooth(dx,14,1/14);out['adx_delta']=out['adx14']-previous(out['adx14'])
    for k in ('bb_mean','bb_sd','bb_width','zscore','two_bar_range','trd_mean20','trd_sd20','er10','er20','chop14'):
        out[k]=np.full(n,np.nan)
    for w in (5,10,20):
        for k in (f'high{w}',f'low{w}',f'prior_high{w}',f'prior_low{w}'):out[k]=np.full(n,np.nan)
    # ----------------------------------------
    # rolling窓は当区間の厳密な添字だけを使い、参照期間を縮めない。
    trd=np.full(n,np.nan)
    for i in range(2,n):trd[i]=max(h[i],h[i-1],c[i-2])-min(l[i],l[i-1],c[i-2])
    for i in range(n):
        for w in (5,10,20):
            if i+1>=w:out[f'high{w}'][i]=np.max(h[i-w+1:i+1]);out[f'low{w}'][i]=np.min(l[i-w+1:i+1])
            if i>=w:out[f'prior_high{w}'][i]=np.max(h[i-w:i]);out[f'prior_low{w}'][i]=np.min(l[i-w:i])
        if i>=19:
            avg=np.mean(c[i-19:i+1]);sd=np.std(c[i-19:i+1],ddof=0)
            out['bb_mean'][i]=avg;out['bb_sd'][i]=sd;out['bb_width'][i]=4*sd
            if sd>0:out['zscore'][i]=(c[i]-avg)/sd
        if i>=1:out['two_bar_range'][i]=max(h[i-1:i+1])-min(l[i-1:i+1])
        if i>=21:out['trd_mean20'][i]=np.mean(trd[i-19:i+1]);out['trd_sd20'][i]=np.std(trd[i-19:i+1],ddof=0)
        for w in (10,20):
            if i>=w:
                denominator=np.sum(np.abs(np.diff(c[i-w:i+1])))
                if denominator>0:out[f'er{w}'][i]=abs(c[i]-c[i-w])/denominator
        if i>=13:
            span=np.max(h[i-13:i+1])-np.min(l[i-13:i+1]);total=np.sum(tr[i-13:i+1])
            if span>0 and total>0:out['chop14'][i]=100*np.log10(total/span)/np.log10(14)
    out['previous_bb_width']=previous(out['bb_width']);out['bb_width_delta']=out['bb_width']-out['previous_bb_width']
    out['zscore_delta']=out['zscore']-previous(out['zscore'])
    return out


def compute(bars: list[dict], keys: list[str]) -> tuple[list[dict], dict]:
    """
    機能: 全slot上で主要m1価格/量特徴を再算し数値助走と品質分母を数える。
    引数: bars(list[dict])、keys(list[str])。返り値: tuple[list[dict],dict]。
    """
    n=len(bars); expected=[dict.fromkeys(keys) for _ in bars]; count=Counter()
    pk=np.array([b['closed'] and not b['missing'] and b['price_known'] for b in bars])
    vk=np.array([b['closed'] and not b['missing'] and b['volume_known'] for b in bars])
    vol=np.array([b['volume'] for b in bars],float);cl=np.array([b['ohlc']['close'] for b in bars],float)
    for first,last in finite_runs(pk):
        raw=price_run(bars[first:last])
        for name,values in raw.items():
            for i,x in enumerate(values):expected[first+i][name]=None if not np.isfinite(x) else float(x)
        count['price_runs']+=1
        count['mature_runs_ge35']+=last-first>=35
    prefix_known=True;total=weighted=0.
    cmf=[]
    for i,b in enumerate(bars):
        out=expected[i];out['bar_start']=b['start'];out['bar_end']=b['end']
        if vk[i]:out['volume']=float(vol[i])
        for w,key in ((3,'volume_relative_prior3'),(20,'rvol')):
            if i>=w and vk[i-w:i+1].all() and np.sum(vol[i-w:i])>0:
                out[key]=float(vol[i]/np.mean(vol[i-w:i]))
        out['relative_volume20']=out.get('rvol')
        for w in (5,15,30):
            if i>=w and pk[i-w:i+1].all() and vk[i-w+1:i+1].all():
                out[f'obv_delta{w}']=float(np.dot(np.sign(np.diff(cl[i-w:i+1])),vol[i-w+1:i+1]))
        value=None
        if i>=19 and pk[i-19:i+1].all() and vk[i-19:i+1].all() and np.sum(vol[i-19:i+1])>0:
            flow=0.; hlc=0.
            for j in range(i-19,i+1):
                p=bars[j]['ohlc'];r=p['high']-p['low'];money=0 if r==0 else (2*p['close']-p['high']-p['low'])/r
                flow+=money*vol[j];hlc+=(p['high']+p['low']+p['close'])/3*vol[j]
            value=float(flow/np.sum(vol[i-19:i+1]));out['hlc3_vwma20']=float(hlc/np.sum(vol[i-19:i+1]))
        out['cmf20']=value
        if value is not None and cmf and cmf[-1] is not None:out['cmf20_delta']=value-cmf[-1]
        cmf.append(value)
        if not vk[i] or vol[i]>0 and not pk[i]:prefix_known=False
        if prefix_known:
            total+=vol[i]
            if vol[i]>0:
                p=b['ohlc'];weighted+=(p['high']+p['low']+p['close'])/3*vol[i]
            out['session_volume']=float(total)
            if total>0:out['session_vwap_proxy']=float(weighted/total)
        count['bars']+=1;count['price_known']+=bool(pk[i]);count['volume_known']+=bool(vk[i])
        count['known_volume_zero']+=bool(vk[i] and vol[i]==0);count['unknown_volume']+=not bool(vk[i])
        count['price_unknown_or_unclosed']+=not bool(pk[i])
        count['mature_hist']+=out.get('hist') is not None;count['trd_known_22_or_more']+=out.get('trd_mean20') is not None
    return expected,dict(count)


def numeric_equal(actual, expected, label: str, errors: list, stats: Counter) -> None:
    """
    機能: NULL一致と有限数値の絶対/相対差を累計して比較する。
    引数: actual/expected(float|None)、label(str)、errors(list)、stats(Counter)。返り値: なし。
    """
    stats['numeric_cells']+=1
    if actual is None or expected is None:
        if actual is not expected:errors.append({'field':label,'actual':actual,'expected':expected})
        stats['null_cells']+=expected is None;return
    difference=abs(actual-expected);stats['max_absolute_error']=max(stats['max_absolute_error'],difference)
    if not math.isclose(actual,expected,rel_tol=2e-9,abs_tol=2e-7):
        errors.append({'field':label,'actual':actual,'expected':expected,'difference':difference})


def json_scalar(value):
    """
    機能: NumPy集計スカラーだけを無損失でJSON標準数値へ直す。
    引数: value(np.generic)。返り値: int|float|bool。
    """
    assert isinstance(value,np.generic), type(value)
    return value.item()


def check_value(value: dict, at: dict) -> None:
    """
    機能: 全特徴のknown/null/有限/期限を検査する。
    引数: value(dict)、at(dict)。返り値: なし。
    """
    assert type(value['known']) is bool
    assert value['known']==(value['value'] is not None), value
    if value['value'] is not None:assert type(value['value']) in (int,float) and math.isfinite(value['value'])
    if value['valid_until'] is not None:
        assert math.isfinite(value['valid_until'])
        if value['known']:assert at['time']<value['valid_until'], ('期限切れknown',at,value)
    assert len(value['ref_ids'])==len(set(value['ref_ids']))


def inspect_scene(scene: dict, metadata: dict, manifest: dict, errors: list) -> dict:
    """
    機能: 一場の全出力を元足と結合し主要数値・全149keyの因果と更新を検査する。
    引数: scene/metadata/manifest(dict)、errors(list)。返り値: dict。
    """
    session=scene['session'];assert all(scene[k]==metadata[k] for k in ('session','contract','start','end','force_close'))
    assert metadata['continuous_end']==scene['end']-300 and scene['raw']['sha256']==metadata['raw']['sha256']
    bars=[k['bar'] for k in scene['bars']];knownbars={b['id']:(i,b,k['context']['at']) for i,(b,k) in enumerate(zip(bars,scene['bars']))}
    assert len(knownbars)==len(bars)
    keys=[key[3:] for key in manifest['catalog'] if key.startswith('m1.') and key[3:] not in UNTESTED_NUMERIC]
    expected,quality=compute(bars,keys);stats=Counter();stats.update(quality)
    state={key:{'value':None,'known':False,'valid_until':None,'ref_ids':[]} for key in manifest['catalog']}
    refs={};seen=set();last_at=None;last_id=None;rows=0;updates=0;mtf=0;digest=hashlib.sha256();decoded=0
    path=MANIFEST.parent/metadata['path'];physical=fingerprint(path);assert physical['sha256']==metadata['sha256'] and physical['bytes']==metadata['bytes']
    with gzip.open(path,'rb') as source:
        for line in source:
            digest.update(line);decoded+=len(line);row=json.loads(line);at=row['at'];rows+=1
            assert row['session']==session and row['contract']==scene['contract']
            assert scene['start']<=at['time']<metadata['continuous_end']
            if last_at is not None:assert before(last_at,at) and stamp(last_at)!=stamp(at)
            assert row['event_id']==f"{session}/{at['index']}/{at['source_line']}" and row['updated_at']==at
            assert row['updates'];minute_seen=False
            for update in row['updates']:
                assert update['at']==at and update['refs']
                primary=update['refs'][0];w=update['width_seconds'];assert primary['id']==update['id'] and primary['width_seconds']==w
                if w==60:
                    minute_seen=True;updates+=1;assert update['id'] not in seen;seen.add(update['id'])
                    i,b,q=knownbars[update['id']];assert stamp(q)==stamp(at)==stamp(b['stamp'])
                    assert all(primary[k]==b[k] for k in ('id','session','contract','width_seconds','start','end','available_at','stamp'))
                    assert update['price_known']==(b['closed'] and b['price_known'] and not b['missing'])
                    assert update['volume_known']==(b['closed'] and b['volume_known'] and not b['missing'])
                    assert set(update['values'])=={key for key in manifest['catalog'] if key.startswith('m1.')}
                    for key in keys:
                        want=expected[i][key] if at['time']<b['end']+180 else None
                        numeric_equal(update['values']['m1.'+key]['value'],want,f'{session}/{i}/{key}',errors,stats)
                    if i==21:stats['nominal_bar22_checked']+=1
                    stats['catchup_stale_minutes']+=at['time']>=b['end']+180
                    assert all(v['valid_until']==b['end']+180 for v in update['values'].values())
                else:
                    assert not minute_seen and w in (300,900,1800);mtf+=1
                    assert set(update['values'])=={key for key in manifest['catalog'] if key.startswith(f'm{w//60}.')}
                    assert all(v['valid_until']==primary['end']+w+60 for v in update['values'].values())
                for ref in update['refs']:
                    assert ref['session']==session and ref['contract']==scene['contract']
                    assert ref['end']<=ref['available_at']<=ref['stamp']['time'] and before(ref['stamp'],at)
                    if ref['id'] in refs:assert refs[ref['id']]==ref
                    refs[ref['id']]=ref
                for key,value in update['values'].items():
                    check_value(value,at);assert value['ref_ids']==[r['id'] for r in update['refs']]
                    state[key]=value
                stats['updates_values_checked']+=len(update['values'])
            assert set(row['values'])==set(manifest['catalog'])
            for key,value in row['values'].items():
                check_value(value,at);expected_value=state[key]
                desired=expected_value.copy()
                if desired['valid_until'] is not None and at['time']>=desired['valid_until']:
                    desired['known']=False;desired['value']=None
                assert value==desired,('最新値/fallback/期限差',session,rows,key)
                stats['all_values_checked']+=1
            ids=sorted({r for v in state.values() for r in v['ref_ids']})
            assert row['refs']==[refs[k] for k in ids]
            for ref in row['refs']:assert before(ref['stamp'],at)
            stats['refs_checked']+=len(row['refs']);last_at=at;last_id=row['event_id']
            if len(errors)>20:raise AssertionError(errors[:20])
    assert rows==metadata['rows'] and updates==metadata['minute_updates'] and mtf==metadata['background_updates']
    assert digest.hexdigest()==metadata['decoded_sha256'] and decoded==metadata['decoded_bytes']
    assert seen=={b['id'] for b in bars if b['stamp']['time']<metadata['continuous_end']}
    assert len(bars)-updates==metadata['tail_minutes']
    assert physical==fingerprint(path)
    return {'session':session,'rows':rows,'m1_updates':updates,'mtf_updates':mtf,'counts':dict(stats),
            'numeric_keys':keys,'decoded_sha256':digest.hexdigest(),'all_gzip_crc_checked':True}


def main() -> None:
    """
    機能: 人工後に許可済み自然2入力だけを読み全件比較票を新規保存する。
    引数: CLI --output-dir(Path)。返り値: なし。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--output-dir',type=Path,required=True);args=parser.parse_args()
    assert not args.output_dir.exists();args.output_dir.mkdir(parents=True)
    started=time.time();manifest_fp=fingerprint(MANIFEST);assert manifest_fp['sha256']==MANIFEST_SHA
    parent_fp=fingerprint(PARENT);assert parent_fp['sha256']==PARENT_SHA
    manifest=json.loads(MANIFEST.read_text(encoding='utf-8'));assert manifest['success'] and manifest['scene_count']==73
    assert len(manifest['catalog'])==149 and manifest['catalog']==sorted(set(manifest['catalog']))
    source_before=[fingerprint(Path(r['path'])) for r in manifest['sources']]
    assert [r['sha256'] for r in source_before]==[r['sha256'] for r in manifest['sources']]
    evidence={};reports=[];errors=[]
    for i,scene in enumerate(scenes(PARENT,evidence)):
        reports.append(inspect_scene(scene,manifest['scenes'][i],manifest,errors))
        print(f"独立別算術 {i+1}/73 {scene['session']} m1={reports[-1]['m1_updates']}",flush=True)
    assert len(reports)==73 and evidence['decoded_sha256']==PARENT_DECODED
    assert sum(r['counts']['bars'] for r in reports)==43124
    assert not errors,errors[:20]
    assert parent_fp==fingerprint(PARENT) and manifest_fp==fingerprint(MANIFEST)
    assert source_before==[fingerprint(Path(r['path'])) for r in manifest['sources']]
    totals=Counter()
    for report in reports:
        for key,value in report['counts'].items():
            if key=='max_absolute_error':totals[key]=max(totals[key],value)
            else:totals[key]+=value
    proof={'success':True,'trial':158,'method':'作者Goを呼ばないPython/NumPy別算術。Go特徴作者と同一人物のため人的独立を主張しない',
           'numpy_version':np.__version__,'manifest':manifest_fp,'parent':parent_fp,'parent_decoded':evidence,
           'scenes':73,'total_counts':dict(totals),'scene_reports':reports,'numeric_omissions':sorted(UNTESTED_NUMERIC),
           'mtf_numeric_scope':'保存数値は再実装せず全keyの有限NULL/更新/早期限/参照Stampを照合。元122を追加読取しない',
           'source_before_after_unchanged':True,'raw_read':False,'financial_labels_read':False,
           'elapsed_seconds':time.time()-started,'code':fingerprint(Path(__file__))}
    (args.output_dir/'確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2,allow_nan=False,default=json_scalar)+'\n',encoding='utf-8')


if __name__=='__main__':main()
