"""機能: 完了した独立結果確認の小源だけを停止票へ束縛する。"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json


def sha(path: Path) -> str:
    """機能: 小源・小票のSHAを求める。

    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """機能: 自然主票と実行源一致を確認し停止票を新規保存する。

    引数: なし。返り値: None。自然結果や大入力は再読しない。
    """
    folder = Path(__file__).parent
    target = folder / '停止の確認.json'
    assert not target.exists()
    names = ['確認する.py', '別計算.py', '人工検査.py', '人工の再確認.json',
             '準備の再確認.json', 'README.md', '自然確認/独立確認.json', '停止を確認する.py']
    proof = json.loads((folder / '自然確認/独立確認.json').read_bytes())
    assert proof['成功'] and proof['全状態'] == 127224 and proof['157対照全旧key同体状態'] == 20088
    assert proof['本コードSHA256'] == sha(folder / '確認する.py')
    assert proof['別計算SHA256'] == sha(folder / '別計算.py')
    prepared = json.loads((folder / '準備の再確認.json').read_bytes())
    for name in ('確認する.py', '別計算.py', '人工検査.py', '人工の再確認.json'):
        assert prepared['源'][name] == sha(folder / name)
    for name, (_, size, mtime) in proof['入力前後指紋'].items():
        stat = Path(name).stat()
        assert (stat.st_size, stat.st_mtime_ns) == (size, mtime)
    root = folder.parents[1]
    formal = root / 'study/00158_複合技術で出口の役割と局面を切り替える/検査/出口結果と集計の独立確認.json'
    assert sha(formal) == sha(folder / '自然確認/独立確認.json')
    result = {'成功': True, '試行': 158, '編集停止': True, '確認UTC': datetime.now(timezone.utc).isoformat(),
              '自然実行handle': 98762, '終了値': 0, '自然再生成': False, '再選択': False,
              '主票SHA256': sha(folder / '自然確認/独立確認.json'),
              '全セル': proof['全セル'], '数値null以外': proof['数値null以外'],
              '最小保存対象': {name: sha(folder / name) for name in names},
              '正式主票': {'path': formal.relative_to(root).as_posix(), 'sha256': sha(formal)},
              '初回と再準備の境界': '初回準備後、Root非戦略列と同点順を追加。再人工後の同一コードで自然1回成功。',
              '限界': proof['境界']}
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '停止SHA256': sha(target)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
