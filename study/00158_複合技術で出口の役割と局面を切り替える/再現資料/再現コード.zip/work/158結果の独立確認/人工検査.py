"""機能: 158独立結果検査器の主要反例を自然未読で検査する。"""
from copy import deepcopy
from fractions import Fraction
from pathlib import Path
from io import StringIO
import gzip
import hashlib
import json
import tempfile
import argparse

import 確認する as check
from 別計算 import Stats, sha, stream_scenes


def q(at=100, index=1, line=2, bid=990, ask=1000, last=995):
    """機能: 有限な人工Quoteを作る。

    引数: 時計・原行・価格(数値)。返り値: dict。
    """
    return {'time': at, 'index': index, 'source_line': line, 'bid': bid,
            'ask': ask, 'last': last, 'quote_ok': True}


def result(policy='F125S125', h='H60', d='D1', cost='C5', gross=125, unknown=False):
    """機能: 検査式に依存せず整合した人工結果を作る。

    引数: 政策・期限・遅延・費用(str)、gross(数値)、unknown(bool)。返り値: dict。
    """
    fee = 1077 if cost == 'C5' else 77
    fill = q(at=112, index=4, line=5, bid=1000+gross, ask=1010+gross, last=1005+gross)
    request = q(at=110, index=3, line=4, bid=1000+gross, ask=1010+gross, last=1005+gross)
    row = {'config_id': f'{policy}/{h}/{d}/{cost}', 'policy': policy, 'horizon': h,
           'delay': d, 'cost': cost, 'fee_yen': fee, 'status': 'closed', 'deadline': 1000,
           'entry_mark_points': -10, 'armed': False, 'arm_quote': None,
           'stop_points': -125, 'peak_points': max(0, gross), 'peak_quote': fill,
           'trough_points': min(-10, gross), 'trough_quote': q(),
           'profit_points': gross, 'profit_yen': 100*gross-fee, 'fill': fill,
           'trigger': {'reason': 'take_profit', 'time': 110, 'quote': request, 'stop_points': None},
           'held_seconds': 12, 'giveback_points': max(0, gross)-gross,
           'positive_seen': 100*gross-fee > 0, 'first_positive_quote': fill if 100*gross-fee > 0 else None,
           'reached125': gross >= 125, 'first125_quote': fill if gross >= 125 else None,
           'profit_after_positive_loss': False, 'profit_after125_loss': False,
           'observed_rows': 3, 'bad_bbo_rows': 0,
           'last_ohlc': {'count': 4, 'open': 995, 'high': 1005+gross, 'low': 995, 'close': 1005+gross}}
    if unknown:
        row.update(status='unknown', unknown_reason='eof')
        for key in ('profit_points', 'profit_yen', 'fill', 'held_seconds', 'giveback_points',
                    'profit_after_positive_loss', 'profit_after125_loss'):
            row[key] = None
    if policy.startswith('A'):
        row['technical_counts'] = {'evaluations': 3, 'fallback_evaluations': 1, 'floor_changes': 0,
                                   'arm_starts': 0, 'technical_requests': 1,
                                   'take_profit_requests': 0, 'missing_features': {'人工未知': 1}}
    return row


def scene(name='人工場', ids=('人工case',)):
    """機能: 全152状態と所属を持つ小さい人工場を作る。

    引数: name(str)、ids(tuple[str])。返り値: dict。
    """
    cases = []
    for cid in ids:
        rows = [result(p, h, d, c) for p in sorted(check.POLICIES)
                for h in ('H60', 'SESSION') for d in ('D0', 'D1') for c in ('C0', 'C5')]
        cases.append({'id': cid, 'original_side': 1, 'side': 1, 'stream': 'original',
                      'entry': q(), 'entry_price': 1000,
                      'memberships': [{'policy': '152U0'}], 'results': rows})
    return {'session': name, 'contract': '人工限月', 'start': 0, 'end': 1500,
            'force_close': 1000, 'continuous_end': 1200, 'cases': cases}


def expect_failure(action):
    """機能: 不正な人工値の拒否を確認する。

    引数: action(callable)。返り値: None。
    """
    try:
        action()
    except (AssertionError, ValueError, KeyError):
        return
    raise AssertionError('不正値を受理した')


def test_arithmetic():
    """機能: 売買鏡像・費用・遅延・未知nullの反例を確認する。

    引数: なし。返り値: None。
    """
    s = scene()
    case = s['cases'][0]
    row = result()
    check.check_result(s, case, row)
    mirror = deepcopy(case)
    mirror['side'] = -1
    mirror['entry'] = q(bid=1000, ask=1010, last=1005)
    opposite = deepcopy(row)
    opposite['fill'] = q(at=112, index=4, line=5, bid=865, ask=875, last=870)
    opposite['trigger']['quote'] = q(at=110, index=3, line=4, bid=865, ask=875, last=870)
    check.check_result(s, mirror, opposite)
    for key, bad in (('profit_yen', 9999), ('held_seconds', 0), ('fee_yen', 77)):
        changed = deepcopy(row)
        changed[key] = bad
        expect_failure(lambda: check.check_result(s, case, changed))
    for dt in (.5, 30.1):
        changed = deepcopy(row)
        changed['fill']['time'] = 110+dt
        expect_failure(lambda: check.check_result(s, case, changed))
    changed = result(unknown=True)
    check.check_result(s, case, changed)
    changed['profit_yen'] = 0
    expect_failure(lambda: check.check_result(s, case, changed))


def test_controls():
    """機能: 全旧key一致と追加診断keyの分離を確認する。

    引数: なし。返り値: None。
    """
    old = result()
    new = dict(deepcopy(old), technical_trace=[])
    assert check.old_projection(new, old) > 25
    new['fill']['ask'] += 1
    expect_failure(lambda: check.old_projection(new, old))
    changed = deepcopy(old)
    changed['trigger'].pop('quote')
    expect_failure(lambda: check.old_projection(changed, old))


def test_pair_ranking():
    """機能: 公平な共通既知順位・二対照・発動数を手計算で確認する。

    引数: なし。返り値: None。
    """
    audit = check.Audit()
    train = scene(ids=('共通', '一部未知'))
    a01, a02 = 'A01_CHAND_MOM', 'A02_KASE_VAR'
    train['cases'][0]['results'] = [result(r['policy'], r['horizon'], r['delay'], r['cost'],
        gross=150 if r['policy'] == a01 else 125) for r in train['cases'][0]['results']]
    train['cases'][1]['results'] = [result(r['policy'], r['horizon'], r['delay'], r['cost'],
        gross=500 if r['policy'] == a02 else 125, unknown=r['policy'] == a01)
        for r in train['cases'][1]['results']]
    audit.ingest(train)
    for i in range(1, 48):
        audit.ingest(scene(name=f'空場{i}', ids=()))
    late = scene(name='後場')
    late['cases'][0]['results'] = [result(r['policy'], r['horizon'], r['delay'], r['cost'],
        gross=500 if r['policy'] == a02 else 125) for r in late['cases'][0]['results']]
    audit.ingest(late)
    assert audit.common_n['152U0', '前48場'] == 1
    assert audit.common_delta['152U0', '前48場', a01] == 2500
    assert audit.common_delta['152U0', '前48場', a02] == 0
    order = sorted(check.POLICIES, key=lambda p: (-audit.common_delta['152U0', '前48場', p], *check.policy_tie(p)))
    assert order[0] == a01
    assert order[1:3] == ['F125S125', 'T125W100TP250']
    assert audit.common_delta['152U0', '後25場', a02] == 37500
    values = audit.summary(('152U0', 'H60', 'D1', 'C5', a01), '全73場')
    assert values['取得数'] == 3 and values['損益未知'] == 1
    assert values['IFD対応既知件数'] == 2 and values['対応既知IFD差分円'] == 2500
    assert values['157対照_対応既知IFD差分円'] == 2500
    assert values['対応既知で実決済が同じ取得数'] == 1
    assert values['対応既知で実決済が異なる取得数'] == 1
    assert values['157対照_対応既知で実決済が同じ取得数'] == 1
    assert values['157対照_対応既知で実決済が異なる取得数'] == 1
    # ----------------------------------------
    # 損益が等しくてもQuoteの約定時刻だけが違えば異なる実決済に数える。
    assert values['利確要求回数'] == 0
    equal_profit = scene(name='同損益別約定')
    for row in equal_profit['cases'][0]['results']:
        if row['policy'] == a01:
            row['fill']['time'] = 113
            row['held_seconds'] = 13
            row['technical_counts']['take_profit_requests'] = 1
    distinct = check.Audit()
    distinct.ingest(equal_profit)
    dv = distinct.summary(('152U0', 'H60', 'D1', 'C5', a01), '全73場')
    assert dv['対応既知IFD差分円'] == 0
    assert dv['対応既知で実決済が同じ取得数'] == 0
    assert dv['対応既知で実決済が異なる取得数'] == 1
    assert dv['利確要求回数'] == 1
    assert values['技術評価した取得数'] == 3 and values['特徴不足評価回数'] == 3
    assert values['不足特徴の種類数'] == 1 and values['全件確定差引円'] is None
    return audit


def test_stats_and_tables(audit):
    """機能: 同時刻DD・未知累計・最小typed表の全列比較を確認する。

    引数: audit(Audit)。返り値: None。
    """
    item = Stats()
    for gross, time in ((-10, 112), (20, 112), (-20, 113)):
        row = result(gross=gross)
        row['fill']['time'] = time
        item.add(row)
    assert item.values()['独立既知決済累計DD円'] == 4231
    prefix = ('152U0', 'H60', 'D1', 'C5', 'A01_CHAND_MOM')
    value = audit.summary(prefix, '全73場')
    head = ['入口', '保有期限', '約定代用', '費用', '出口', '区間', *value]
    # ----------------------------------------
    # 要約は全列を人工の手計算済み期待値へ束縛し、1円の改変を拒否する。
    raw = [*prefix, '全73場', *[float(v) if isinstance(v, Fraction) else v for v in value.values()]]
    tables = {'出口比較': {'headers': head, 'rows': [raw]},
              '全セッション': {'headers': ['未使用人工'], 'rows': []},
              '研究順位と発動': {'headers': ['未使用人工'], 'rows': []}}
    audit.compare_tables(tables, strict=False)
    tables['出口比較']['rows'][0][head.index('既知差引円')] += 1
    expect_failure(lambda: audit.compare_tables(tables, strict=False))


def test_stream_crc():
    """機能: 小gzipの全CRC/解凍指紋と不正CRC拒否を確認する。

    引数: なし。返り値: None。
    """
    with tempfile.TemporaryDirectory(prefix='158独立人工_') as tmp:
        path = Path(tmp) / '人工.json.gz'
        header = {'success': True, 'trial': 158, 'schema': 'technical_exit_results_v1',
                  'scene_count': 0, 'case_count': 0, 'membership_count': 0, 'configuration_count': 152,
                  'configurations': [{'policy': p} for p in sorted(check.POLICIES) for _ in range(8)], 'scenes': []}
        body = json.dumps(header, ensure_ascii=False).encode('utf-8') + b'\n'
        with gzip.GzipFile(filename=str(path), mode='wb', mtime=0) as f:
            f.write(body)
        evidence = {}
        assert list(stream_scenes(path, evidence, 158, check.POLICIES)) == []
        assert evidence['decoded_sha256'] == hashlib.sha256(body).hexdigest()
        broken = bytearray(path.read_bytes())
        broken[-8] ^= 1
        path.write_bytes(broken)
        try:
            list(stream_scenes(path, {}, 158, check.POLICIES))
        except (OSError, EOFError):
            pass
        else:
            raise AssertionError('CRC改変を受理した')


def main() -> None:
    """機能: 主要5人工を実行し準備用の小票を新規保存する。

    引数: なし。返り値: None。新自然・旧自然結果・Root集計は読まない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    test_arithmetic()
    test_controls()
    audit = test_pair_ranking()
    test_stats_and_tables(audit)
    test_stream_crc()
    root = Path(__file__).parent
    proof = {'成功': True, '人工': 5, '自然結果読取': False, 'Root集計import': False,
             '内容': ['売買実BBO・費用・D1境界・未知null', '対照全旧keyと新key分離',
                      '全19共通既知だけの前48順位・後25は不交換・二対照・発動',
                      '同時刻DDと未知保持・全列改変拒否', 'gzipCRCと解凍SHA'],
             '源SHA256': {p.name: sha(p) for p in (root/'確認する.py', root/'別計算.py', Path(__file__))}}
    target = args.output or root / '人工の確認.json'
    assert not target.exists()
    target.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(proof, ensure_ascii=False))


if __name__ == '__main__':
    main()
