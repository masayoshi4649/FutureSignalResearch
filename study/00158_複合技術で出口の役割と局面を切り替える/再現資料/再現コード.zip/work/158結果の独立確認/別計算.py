"""元出口を場単位に逐次読み、Rootの型付き二表を別集約で照合する。"""
from pathlib import Path
from collections import defaultdict
from fractions import Fraction
from dataclasses import dataclass, field
import argparse
import gzip
import hashlib
import json
import math

POLICIES = {"F125S75", "F125S100", "F125S125", "F250S125", "F250S250", "T0W125", "E0W125", "T50W100", "T125W75", "T125W100", "T125W125", "T125W100TP250"}


def sha(path: Path) -> str:
    """物理SHAを逐次確認する。

    引数: path(Path)。返り値: str型のSHA256。
    """
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


class Reader:
    """gzip JSONのsceneだけを1件ずつ読む。全leafの副本を残さない。"""

    def __init__(self, source):
        """読取状態を作る。

        引数: source(TextIO)。返り値: None。
        """
        self.source, self.buffer, self.at = source, "", 0
        self.decoder, self.digest, self.size = json.JSONDecoder(), hashlib.sha256(), 0

    def more(self) -> bool:
        """未消費部分だけを保って次のchunkを読む。

        引数: なし。返り値: bool型の読取成否。
        """
        part = self.source.read(1 << 18)
        if not part:
            return False
        b = part.encode("utf-8")
        self.digest.update(b)
        self.size += len(b)
        self.buffer, self.at = self.buffer[self.at:] + part, 0
        return True

    def space(self) -> None:
        """空白を読み飛ばす。

        引数: なし。返り値: None。
        """
        while True:
            while self.at < len(self.buffer) and self.buffer[self.at].isspace():
                self.at += 1
            if self.at < len(self.buffer) or not self.more():
                return

    def token(self, value: str) -> None:
        """JSON構造文字を検査する。

        引数: value(str)。返り値: None。
        """
        self.space()
        assert self.buffer[self.at:self.at + 1] == value
        self.at += 1

    def value(self):
        """一つのJSON値を必要な分だけ読む。

        引数: なし。返り値: JSON値。
        """
        self.space()
        while True:
            try:
                value, end = self.decoder.raw_decode(self.buffer, self.at)
                self.at = end
                return value
            except json.JSONDecodeError:
                assert self.more(), "JSONが未完了"


def stream_scenes(path: Path, evidence: dict, trial: int, policies: set[str]):
    """小さいヘッダとsceneを逐次読み全CRC/解凍SHAを確認する。

    引数: path(Path)、evidence(dict)。返り値: sceneのIterator。
    """
    with gzip.open(path, "rt", encoding="utf-8", newline="") as f:
        r = Reader(f)
        r.token("{")
        header = {}
        while True:
            key = r.value()
            r.token(":")
            if key == "scenes":
                break
            header[key] = r.value()
            r.token(",")
        assert header["success"] and header["trial"] == trial
        assert header["schema"] == ("fixed_exit_results_v1" if trial == 157 else "technical_exit_results_v1")
        configs = header["configurations"]
        assert len(configs) == 8 * len(policies) and {x["policy"] for x in configs} == policies
        evidence["source_header"] = header
        evidence["header"] = {k: header[k] for k in ("scene_count", "case_count", "membership_count", "configuration_count")}
        evidence["configurations"] = configs
        r.token("[")
        while True:
            r.space()
            if r.buffer[r.at:r.at + 1] == "]":
                r.token("]")
                break
            yield r.value()
            r.space()
            if r.buffer[r.at:r.at + 1] == ",":
                r.token(",")
            else:
                r.token("]")
                break
        r.token("}")
        r.space()
        assert r.at == len(r.buffer) and not f.read(), "後続値がある"
        evidence["decoded_sha256"] = r.digest.hexdigest()
        evidence["decoded_bytes"] = r.size


def number(x) -> Fraction:
    """保存済み有限数値を十進有理数へ変換する。

    引数: x(int|float)。返り値: Fraction型。
    """
    assert type(x) in (int, float) and math.isfinite(x)
    return Fraction(str(x))


@dataclass
class Stats:
    n: int = 0
    unknown: int = 0
    wins: int = 0
    losses: int = 0
    zero: int = 0
    profit: Fraction = Fraction(0)
    loss: Fraction = Fraction(0)
    held: Fraction = Fraction(0)
    giveback: Fraction = Fraction(0)
    armed: int = 0
    after_positive: int = 0
    after125: int = 0
    events: dict = field(default_factory=lambda: defaultdict(Fraction))

    def add(self, row: dict) -> None:
        """1行の金額/診断を整数件数と有理数で加える。

        引数: row(dict)。返り値: None。
        """
        self.n += 1
        if row["status"] == "unknown":
            assert row["profit_yen"] is row["profit_points"] is row["fill"] is None
            self.unknown += 1
            return
        assert row["status"] == "closed" and row["fill"] is not None
        money, points, fee = map(number, (row["profit_yen"], row["profit_points"], row["fee_yen"]))
        assert abs(money - (100 * points - fee)) < Fraction(1, 10000000)
        self.profit += max(money, 0)
        self.loss -= min(money, 0)
        self.wins += money > 0
        self.losses += money < 0
        self.zero += money == 0
        self.held += number(row["held_seconds"])
        self.giveback += number(row["giveback_points"])
        self.armed += bool(row["armed"])
        self.after_positive += bool(row["profit_after_positive_loss"])
        self.after125 += bool(row["profit_after125_loss"])
        self.events[row["fill"]["time"]] += money

    def merge(self, other) -> None:
        """場ごとの集計値を統合する。

        引数: other(Stats)。返り値: None。
        """
        for key in self.__dataclass_fields__:
            if key != "events":
                setattr(self, key, getattr(self, key) + getattr(other, key))
        for at, value in other.events.items():
            self.events[at] += value

    def values(self) -> dict:
        """固定列の指標を別の代数式で求める。

        引数: なし。返り値: dict型。
        """
        known = self.n - self.unknown
        lower = upper = None
        if known:
            z = 1.959963984540054
            center = (self.wins + z * z / 2) / (known + z * z)
            radius = z * math.sqrt(self.wins * (known - self.wins) / known + z * z / 4) / (known + z * z)
            lower, upper = max(0, center - radius), min(1, center + radius)
        running = peak = drawdown = Fraction(0)
        for _, change in sorted(self.events.items()):
            running += change
            peak = max(peak, running)
            drawdown = max(drawdown, peak - running)
        net = self.profit - self.loss
        return {"取得数": self.n, "決済既知": known, "損益未知": self.unknown,
                "利益取引": self.wins, "損失取引": self.losses, "同額取引": self.zero,
                "利益総額円": self.profit, "損失総額円": self.loss, "既知差引円": net,
                "全件確定差引円": None if self.unknown else net,
                "PF": self.profit / self.loss if self.loss else None,
                "利益側金額比率": self.profit / (self.profit + self.loss) if self.profit + self.loss else None,
                "既知決済勝率": Fraction(self.wins, known) if known else None,
                "勝率参考95下限": lower, "勝率参考95上限": upper,
                "追尾起動既知": self.armed, "費用後正益後赤字": self.after_positive,
                "125順行後赤字": self.after125,
                "平均保有秒": self.held / known if known else None,
                "平均吐出しpt": self.giveback / known if known else None,
                "独立既知決済累計DD円": drawdown}


def equal(expected, actual, where: tuple) -> None:
    """null/整数/有限数値を型別に比較する。

    引数: expected/actual(JSON値)、where(tuple)。返り値: None。
    """
    if expected is None or isinstance(expected, str):
        assert expected == actual, (where, expected, actual)
    elif type(expected) is int:
        assert type(actual) in (int, float) and expected == actual, (where, expected, actual)
    else:
        assert type(actual) in (int, float) and math.isfinite(actual)
        assert math.isclose(float(expected), actual, rel_tol=1e-11, abs_tol=1e-7), (where, float(expected), actual)


