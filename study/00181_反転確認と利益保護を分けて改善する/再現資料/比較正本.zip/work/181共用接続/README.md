# 181の全81場共用接続

旧179/180のSource・入力・結果を変更せず、旧73/追加7/本日1を同じAPIへ接続する。重い原板や当時特徴を再生成しない。

`共用181.py` をmoduleとして読み込む。期間名は `旧73` / `追加7` / `本日1`（別名 `old73` / `add7` / `today1`）。固定基準の名前は `全期_J035` / `旧178_新時計`。

1. `load_pure_leg(leg)` は金融表を読まず、当時100特徴・場/q0・固定基準2案・価格索引参照を返す。返り値の軽量 `context` は金融 `arrays` を持たず、基準方向は変更禁止の配列である。本日入力は旧180の全C未評価contextを利用する。
2. `seal_pure_leg(pure, output_dir=None)` は基準2案を `cache/{leg}_純基準181.npz` とJSONへ封印する。これは新候補の封印の代わりではない。研究側は新候補も金融評価前に別途封印する。
3. `attach_financial(pure)` は封印の存在・指紋を確認してから保存済み金融表を接続する。旧73/追加7は元179の `initialize/compose` と全純配列を照合し、`early179.load_overlay` のbindingも確認する。本日は固定180の金融指紋を確認する。
4. `load_leg(leg, output_dir=None)` は上の3段をこの順で実行する便宜API。

共通の返却キーは `leg/context/features/baselines/price_index/scene_masks/event_scene/proof/sealed`。金融付与後は `captures/financial_attached/case_index` も返す。`baselines[name]` は `birth`（core/branches/technical/tier）と `mw/fw/hi/added` を持つ。

`scene_masks` は場順bool配列。全対象と、旧73の前48/後25、追加7、本日1を分ける。Day/NightやPRE/POSTはcontextの既存の場・q0区分を使う。

`price_index` は `manifest` 指紋と、場順の `scenes=[{session,contract,path,sha256,rows}]`。`load_records(leg,session)` は必要な一場だけを48byte索引からCRC/SHA確認付きで読み、最大2場をメモリに保持する。原板の再走査や複製はしない。

`case_index` は全体case順の `case_ids/scene/contract/local_case/entry_index/entry_time/entry_line/entry_price` と `scene_index_refs`。`local_case` は `flatnonzero(case_scene==scene)` の中での0始まり番号であり、`entry_index` はその場の価格索引全行の0始まり位置。両者を混同しない。`entry_price[:,0/1]` は買いAsk/売りBid。既存81場は一場一限月で、manifest契約とq0契約が異なる混在があれば停止する。

`baseline_pack(loaded,name)` は封印した基準を元179の固定pack生成器へ渡す。元policy IDを保持し、本日だけ180と同じentry行/indexの追記を行う。

固定同体確認:

```powershell
$env:PYTHONUTF8='1'
$env:PYTHONIOENCODING='utf-8'
& 'work/複合テクニカル学習環境/Scripts/python.exe' 'work/181共用接続/共用181.py' --verify-fixed
```

基準2案×3期間の全pack辞書を、固定179の旧73/追加7と180の本日結果へ照合する。新しい手法の成績探索・順位付けはしない。確認票は `基準二案の全81場同体確認.json`。共有moduleの一時大域差替えは必ず復元するが、同じprocess内の複数threadから同時に呼ばない。並列再生は別processを使う。
