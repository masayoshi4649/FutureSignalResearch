"""追尾OFFだけを旧固定主の全81場取得へ適用し、既存179金融との接続を照合する。"""
from pathlib import Path
import hashlib
import json
import math
import sys
import numpy as np
import trail181 as T

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'work/181共用接続'))
import 共用181 as C
FIELDS = ('label', 'known', 'net', 'exit_time', 'known_at', 'holding_confirmed_until',
          'forced', 'status', 'exit_price', 'exit_index', 'exit_line')

# ----------------------------------------


def ref(path: Path) -> dict:
    """
    機能: 固定Sourceと条件の内容指紋を採る。
    引数: path(Path)は検査対象ファイル。
    返り値: dictは相対path・bytes・sha256。
    """
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def main() -> None:
    """
    機能: C0のみを各期間の179全期主取得へ計算し、旧表の11属性を完全照合する。
    引数: なし。新入口・追尾ありの自然結果を評価しない。
    返り値: None。OFF自然同体.jsonへ検査票を保存する。
    """
    sources = [Path(T.__file__), HERE / '候補181.json', Path(C.__file__), Path(__file__)]
    before = [ref(path) for path in sources]
    candidate = next(value for value in T.load_candidates() if value['mode'] == 'off')
    assert candidate['id'] == 'C0_IFD'
    checks = []
    all_cells = all_fields = all_scenes = 0
    for leg in C.LEGS:
        loaded = C.load_leg(leg)
        context = loaded['context']
        pack = C.baseline_pack(loaded, '全期_J035')
        selection = pack['selection']
        selected = list(zip(selection['cases'], selection['sides'],
                            selection['width_indices'], selection['horizon_indices'], strict=True))
        scene_cells = {}
        for key in selected:
            scene_cells.setdefault(int(context.case_scene[key[0]]), []).append(key)
        digest = hashlib.sha256()
        count = fields = 0
        inputs = []
        for scene, cells in sorted(scene_cells.items()):
            name = context.sessions[scene]
            records = C.load_records(leg, name)
            cases = np.flatnonzero(context.case_scene == scene)
            assert np.array_equal(loaded['case_index']['local_case'][cases], np.arange(len(cases)))
            engine = T.TrailEvaluator(records, context.arrays['entry_index'][cases], float(context.scenes[scene]['end']),
                list(context.table.widths), context.table.evidence['条件']['horizons'])
            inputs.append(loaded['price_index']['scenes'][scene])
            for key in cells:
                ci, side, wi, hi = key
                local = int(loaded['case_index']['local_case'][ci])
                result = engine.evaluate_cell(candidate, local, side, wi, hi)
                for name in FIELDS:
                    expected = context.arrays[name][key]
                    actual = result[name]
                    both_nan = isinstance(expected, (float, np.floating)) and math.isnan(expected) and math.isnan(actual)
                    assert both_nan or actual == expected, (leg, key, name, actual, expected)
                    fields += 1
                digest.update(json.dumps([list(map(int, key)), [None if isinstance(result[name], float) and math.isnan(result[name]) else result[name]
                    for name in FIELDS]], ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8'))
                count += 1
            del engine
        assert count == len(pack['ledger']['net']) == len(selected)
        checks.append({'期間': leg, '基準': '全期_J035', '取得セル': count, '属性照合': fields,
                       '場数': len(scene_cells), '全属性同体': True, '照合値SHA256': digest.hexdigest(), '価格索引': inputs})
        all_cells += count
        all_fields += fields
        all_scenes += len(scene_cells)
        print(json.dumps({'期間': leg, '成功': True, '取得セル': count, '属性照合': fields, '場数': len(scene_cells)}, ensure_ascii=False), flush=True)
    assert before == [ref(path) for path in sources]
    proof = {'成功': True, '基準OFFのみ': True, '追尾あり自然金融未実行': True, '新入口自然金融未実行': True,
             'Source不変': True, 'Source': before, '基準': '179全期J035', '全場': all_scenes,
             '全取得セル': all_cells, '完全照合属性数': all_fields, '照合属性': list(FIELDS), '期間別': checks}
    (HERE / 'OFF自然同体.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    print(json.dumps({key: value for key, value in proof.items() if key not in ('Source', '期間別')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
