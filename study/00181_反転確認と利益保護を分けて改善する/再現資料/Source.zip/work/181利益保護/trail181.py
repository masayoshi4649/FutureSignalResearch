"""179の時計・未知を維持して、費用後起動の追尾返済を疎なセルへ計算する。"""
from pathlib import Path
import importlib.util
import json
import math
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('early179_for_trail181', ROOT / 'work/179終了前決済/early179.py')
E = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = E
spec.loader.exec_module(E)

VERSION = '181費用後起動と遅延追尾1'
CONFIG = {**E.CONFIG, '追尾注文最小遅延秒': 1, 'mini呼値pt': 5, '技術鮮度秒': 180}
STATUS = {**E.STATUS, 5: '追尾接触後の遅延返済'}
EXTRA_FLOATS = ('trail_activation_time', 'trail_trigger_time', 'trail_trigger_price',
                'trail_floor_points', 'trail_floor_price', 'trail_floor_net', 'trail_peak_points',
                'trail_fill_minus_floor_points', 'first_observed_time')
EXTRA_INTS = ('trail_activation_line', 'trail_trigger_line', 'trail_floor_updates',
              'trail_technical_tightenings', 'trail_stale_fallbacks')

# ----------------------------------------


def load_candidates(path: Path | None = None) -> list[dict]:
    """
    機能: 金融結果を読まずに固定した候補辞書を読み込む。
    引数: path(Path|None)はJSON、省略時は同フォルダの候補181.json。
    返り値: list[dict]はIDが一意な候補。
    """
    value = json.loads((HERE / '候補181.json' if path is None else Path(path)).read_text(encoding='utf-8'))
    assert value['金融評価前固定']
    candidates = value['候補']
    assert len({candidate['id'] for candidate in candidates}) == len(candidates)
    return candidates


def empty_scalar() -> dict:
    """
    機能: 金融未知を0円にしない一セルの初期値を作る。
    引数: なし。
    返り値: dictは179互換属性と追尾監査属性。
    """
    value = {key: float('nan') for key in (*E.FLOAT_KEYS, *EXTRA_FLOATS)}
    value.update({key: -1 for key in ('exit_index', 'exit_line', *EXTRA_INTS)})
    value.update(label=2, known=False, forced=False, status=14, direction=0,
                 trail_activated=False, trail_triggered=False, first_observed_label=2, evaluated=True)
    for key in ('trail_floor_updates', 'trail_technical_tightenings', 'trail_stale_fallbacks'):
        value[key] = 0
    return value


def allocate(count: int, widths: list, horizons: list) -> dict:
    """
    機能: 全軸を持ちながら未評価セルを明示する追尾用の配列を作る。
    引数: count(int)、widths/horizons(list)は179と同じ評価軸。
    返り値: dict[str,np.ndarray]はcase×実側×幅×期限。evaluated=Falseを勝手に使わない。
    """
    arrays = E.allocate(count, widths, horizons)
    shape = arrays['known'].shape
    arrays.update({key: np.full(shape, np.nan) for key in EXTRA_FLOATS})
    arrays.update({key: np.full(shape, -1, np.int64) for key in EXTRA_INTS})
    arrays.update(trail_activated=np.zeros(shape, bool), trail_triggered=np.zeros(shape, bool),
                  first_observed_label=np.full(shape, 2, np.int8), evaluated=np.zeros(shape, bool))
    return arrays


class TrailEvaluator:
    """一場の価格木・期限・技術timeline・疎な金融セルを共有する。"""

    def __init__(self, records: np.ndarray, entries: np.ndarray, scene_end: float,
                 widths: list, horizons: list, technical: dict | None = None) -> None:
        """
        機能: 一場の正常実側BBO木と固定時計を用意し、技術値を時刻へ束縛する。
        引数: records(np.ndarray)、entries(np.ndarray[int])、scene_end(float)、widths/horizons(list)、technical(dict|None)。
        返り値: None。自然金融を自動評価せず、元配列も変更しない。
        """
        self.records = records
        self.entries = np.asarray(entries, np.int64)
        self.index = E.PriceIndex(records)
        self.widths = list(widths)
        self.horizons = list(horizons)
        self.cut = float(scene_end - CONFIG['終了前秒'])
        self.submit = self.cut - CONFIG['決済要求余裕秒']
        self.forced = self.index.first_normal(self.submit + CONFIG['強制注文最小遅延秒'])
        if self.forced >= 0 and self.index.times[self.forced] > self.cut:
            self.forced = -1
        assert np.all((self.entries >= 0) & (self.entries < len(records)))
        assert np.isin(self.entries, self.index.normal).all()
        self.cache = {}
        self.terms = {}
        self.technical = None
        if technical is not None:
            names = ('times', 'atr_points', 'ma_gap_atr', 'bb_width_ratio', 'momentum_atr')
            values = {key: np.asarray(technical[key], float) for key in names}
            times = values['times']
            assert times.ndim == 1 and np.isfinite(times).all() and np.all(np.diff(times) >= 0)
            assert all(value.shape == times.shape for value in values.values())
            self.technical = values

    def _term(self, entry: int, hi: int) -> tuple:
        """
        機能: 幅や追尾候補に依存しない179の期限・欠測打切りを共有する。
        引数: entry(int)は価格索引位置、hi(int)は期限軸。
        返り値: tuple[dict,float,int]は期限判定・表示用名目期限・全体gap位置。
        """
        key = (entry, hi)
        if key not in self.terms:
            horizon = self.horizons[hi]
            nominal = self.cut if horizon['kind'] == 'session' else float(self.index.times[entry]) + float(horizon['seconds'])
            term = E.terminal(self.index, entry, float('inf') if horizon['kind'] == 'session' else nominal,
                              self.cut, self.forced)
            gap, _ = self.index.censor(entry, self.cut)
            self.terms[key] = term, nominal, gap
        return self.terms[key]

    def _width(self, candidate: dict, at: float, sign: int) -> tuple:
        """
        機能: 当時までの新鮮なATRと複合技術だけで追尾幅を計算する。
        引数: candidate(dict)、at(float)は観測時計、sign(int)は買+1/売-1。
        返り値: tuple[float,bool,bool]は幅・複合縮小・未知/古い技術の固定代替。
        """
        fallback = float(candidate['trail_pt'])
        if candidate['mode'] == 'fixed':
            return fallback, False, False
        if self.technical is None:
            return fallback, False, True
        values = self.technical
        ti = int(np.searchsorted(values['times'], at, side='right')) - 1
        if ti < 0 or at - values['times'][ti] > CONFIG['技術鮮度秒']:
            return fallback, False, True
        atr = values['atr_points'][ti]
        if not math.isfinite(atr) or atr <= 0:
            return fallback, False, True
        width = max(float(candidate['minimum_pt']), min(float(candidate['maximum_pt']),
                    float(candidate['atr_multiplier']) * atr))
        tight = False
        if candidate['mode'] == 'technical':
            ma, bb, momentum = (values[key][ti] for key in ('ma_gap_atr', 'bb_width_ratio', 'momentum_atr'))
            mature = all(math.isfinite(float(value)) for value in (ma, bb, momentum)) and ma >= 0 and bb >= 0
            tight = mature and bb <= candidate['bb_width_ratio_max'] and (
                ma <= candidate['ma_gap_atr_max'] or sign * momentum <= candidate['momentum_atr_max'])
            if tight:
                width = min(width, float(candidate['tight_pt']))
        return width, bool(tight), False

    def _next_technical(self, after: int) -> int:
        """
        機能: 次の技術公表と現技術の180秒失効を、最初の正常BBO行へ結び付ける。
        引数: after(int)は処理済み原行位置。
        返り値: intは次の処理位置。該当なしは-1。
        """
        if self.technical is None:
            return -1
        times = self.technical['times']
        at = float(self.index.times[after])
        ti = int(np.searchsorted(times, at, side='right'))
        options = []
        if ti < len(times):
            options.append(self.index.first_normal(float(times[ti]), after))
        if ti > 0:
            expires = float(times[ti - 1]) + CONFIG['技術鮮度秒']
            if at <= expires:
                options.append(self.index.first_normal(float(np.nextafter(expires, math.inf)), after))
        return min((value for value in options if value >= 0), default=-1)

    def _fixed_hit(self, entry: int, stop: int, side: int, price: float, width: float,
                   keep_take_profit: bool) -> int:
        """
        機能: 元の初期逆指値と、維持する場合の利確指値の最初の接触を求める。
        引数: entry/stop/side(int)、price/width(float)、keep_take_profit(bool)。
        返り値: intは最初の原行位置、接触なしは-1。179の即時約定代用を維持する。
        """
        lower = price - width if keep_take_profit or side == 0 else -math.inf
        upper = price + width if keep_take_profit or side == 1 else math.inf
        return self.index.first_outside(entry + 1, stop, lower, upper, side)

    def _finish(self, result: dict, entry: int, side: int, width: float, term: dict,
                exit_index: int, status: int) -> dict:
        """
        機能: 金融既知/未知と、先に確定した同幅先着を別々に確定する。
        引数: result(dict)、entry/side/exit_index/status(int)、width(float)、term(dict)。
        返り値: dictは互換金融値と監査値。未知でも観測済みF/Aを消さない。
        """
        sign = 1 if side == 0 else -1
        price = float(self.records['ask' if side == 0 else 'bid'][entry])
        if exit_index >= 0:
            mark = float(self.records['bid' if side == 0 else 'ask'][exit_index])
            points = sign * (mark - price)
            at = float(self.index.times[exit_index])
            result.update(known=True, status=status, forced=status == 4,
                          exit_index=exit_index, exit_line=int(self.records['source_line'][exit_index]))
            for key, value in [('net0', points * CONFIG['1pt円'] - CONFIG['往復手数料円']),
                               ('net', points * CONFIG['1pt円'] - CONFIG['往復手数料円'] - CONFIG['往復追加滑り円']),
                               ('exit_time', at), ('known_at', at), ('holding_confirmed_until', at),
                               ('exit_quote_time', at), ('exit_price', mark), ('points', points)]:
                result[key] = value
            if status == 5:
                result['trail_fill_minus_floor_points'] = points - result['trail_floor_points']
        else:
            result['status'] = status
        stop = min(term['touch_end'], exit_index + 1) if exit_index >= 0 else term['touch_end']
        hit = self._fixed_hit(entry, stop, side, price, width, True)
        observed = (1 if sign * (float(self.records['bid' if side == 0 else 'ask'][hit]) - price) >= width else -1) if hit >= 0 else 0 if exit_index >= 0 else 2
        result['label'] = observed
        result['direction'] = observed if observed in (-1, 1) else 0
        result['first_observed_label'] = observed
        if hit >= 0:
            result['first_observed_time'] = float(self.index.times[hit])
        assert not result['known'] or result['exit_time'] <= self.cut
        return result

    def evaluate_cell(self, candidate: dict, ci: int, side: int, wi: int, hi: int) -> dict:
        """
        機能: 要求された一セルだけを評価し、候補IDと評価軸でキャッシュする。
        引数: candidate(dict)、ci/side/wi/hi(int)はcase・実側・幅・期限の位置。
        返り値: dictはscalar値。再呼出し時も変更できないコピーを返す。
        """
        identity = json.dumps(candidate, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
        key = (identity, int(ci), int(side), int(wi), int(hi))
        if key not in self.cache:
            self.cache[key] = self._evaluate(candidate, int(ci), int(side), int(wi), int(hi))
        return self.cache[key].copy()

    def _evaluate(self, candidate: dict, ci: int, side: int, wi: int, hi: int) -> dict:
        """
        機能: 起動・極値更新・技術更新・床接触へ飛び、追尾注文を実価格で返済する。
        引数: candidate(dict)、ci/side/wi/hi(int)は固定評価軸。
        返り値: dictは一セル。初期IFD/期限/強制の約定時計は179から変更しない。
        """
        assert side in (0, 1) and 0 <= ci < len(self.entries)
        assert candidate['mode'] in ('off', 'fixed', 'atr', 'technical')
        assert isinstance(candidate['keep_take_profit'], bool)
        if candidate['mode'] != 'off':
            assert candidate['activation_net_pt'] > 0 and candidate['trail_pt'] > 0
        result = empty_scalar()
        entry = int(self.entries[ci])
        entry_time = float(self.index.times[entry])
        if entry_time >= self.submit:
            result['status'] = 15
            return result
        term, nominal, gap = self._term(entry, hi)
        result.update(holding_confirmed_until=term['lower'], exit_deadline=term['exit_deadline'], nominal_deadline=nominal)
        sign = 1 if side == 0 else -1
        price = float(self.records['ask' if side == 0 else 'bid'][entry])
        width = float(self.widths[wi])
        stop = int(term['touch_end'])
        fixed = self._fixed_hit(entry, stop, side, price, width, candidate['keep_take_profit'])
        hard = min((index for index in (fixed, term['exit']) if index >= 0), default=-1)
        hard_status = (1 if sign * (float(self.records['bid' if side == 0 else 'ask'][fixed]) - price) >= width else 2) if fixed >= 0 and fixed == hard else term['status']
        if candidate['mode'] == 'off':
            assert candidate['keep_take_profit']
            return self._finish(result, entry, side, width, term, hard, hard_status)
        cost_points = (CONFIG['往復手数料円'] + CONFIG['往復追加滑り円']) / CONFIG['1pt円']
        activate = float(candidate['activation_net_pt']) + cost_points
        lower, upper = (-math.inf, price + activate) if side == 0 else (price - activate, math.inf)
        activation = self.index.first_outside(entry + 1, stop, lower, upper, side)
        if activation < 0 or hard >= 0 and hard <= activation:
            return self._finish(result, entry, side, width, term, hard, hard_status)
        result.update(trail_activated=True, trail_activation_time=float(self.index.times[activation]),
                      trail_activation_line=int(self.records['source_line'][activation]))
        peak = -math.inf
        floor = -math.inf
        current = activation
        while current >= 0 and current < stop:
            if hard >= 0 and current >= hard:
                return self._finish(result, entry, side, width, term, hard, hard_status)
            mark = float(self.records['bid' if side == 0 else 'ask'][current])
            points = sign * (mark - price)
            touched = points <= floor
            if not touched:
                peak = max(peak, points)
                distance, tightened, fallback = self._width(candidate, float(self.index.times[current]), sign)
                ideal = max(cost_points, peak - distance)
                proposed = math.ceil(ideal / CONFIG['mini呼値pt'] - 1e-12) * CONFIG['mini呼値pt']
                if proposed > floor:
                    floor = proposed
                    result['trail_floor_updates'] += 1
                    result['trail_technical_tightenings'] += int(tightened)
                result['trail_stale_fallbacks'] += int(fallback)
                touched = points <= floor
            result.update(trail_floor_points=float(floor), trail_floor_price=float(price + sign * floor),
                          trail_floor_net=float(floor * CONFIG['1pt円'] - CONFIG['往復手数料円'] - CONFIG['往復追加滑り円']),
                          trail_peak_points=float(peak))
            assert floor >= cost_points - 1e-9
            if touched:
                result.update(trail_triggered=True, trail_trigger_time=float(self.index.times[current]),
                              trail_trigger_line=int(self.records['source_line'][current]), trail_trigger_price=mark)
                fill = self.index.first_normal(float(self.index.times[current]) + CONFIG['追尾注文最小遅延秒'], current)
                valid = fill >= 0 and fill < gap and self.index.times[fill] <= self.cut and self.index.times[fill] <= term['exit_deadline']
                if hard >= 0 and (not valid or hard <= fill):
                    return self._finish(result, entry, side, width, term, hard, hard_status)
                if valid:
                    return self._finish(result, entry, side, width, term, fill, 5)
                return self._finish(result, entry, side, width, term, -1, term['status'])
            # ----------------------------------------
            # 次の極値更新・床接触・新しい技術公表だけを調べ、同値の板を飛ばす。
            if side == 0:
                lower, upper = price + floor, float(np.nextafter(price + peak, math.inf))
            else:
                lower, upper = float(np.nextafter(price - peak, -math.inf)), price - floor
            event = self.index.first_outside(current + 1, stop, lower, upper, side)
            technical_event = self._next_technical(current) if candidate['mode'] in ('atr', 'technical') else -1
            options = [index for index in (event, technical_event, hard) if current < index < stop]
            if not options:
                break
            current = min(options)
        return self._finish(result, entry, side, width, term, hard, hard_status)

    def evaluate_cells(self, candidate: dict, cells: list[tuple] | np.ndarray | None = None) -> dict:
        """
        機能: 全純要求の一意セルを評価し、数量一枚再生へ接続する同shape配列を返す。
        引数: candidate(dict)、cells(list[tuple]|np.ndarray|None)は(ci,side,wi,hi)。None時は全軸。
        返り値: dict[str,np.ndarray]は179互換表。未評価セルはevaluated=False。
        """
        arrays = allocate(len(self.entries), self.widths, self.horizons)
        wanted = np.ndindex(arrays['known'].shape) if cells is None else sorted({tuple(map(int, cell)) for cell in cells})
        for cell in wanted:
            assert len(cell) == 4
            value = self.evaluate_cell(candidate, *cell)
            for name, amount in value.items():
                arrays[name][cell] = amount
        return arrays

# ----------------------------------------


def evaluate_records(records: np.ndarray, entries: np.ndarray, scene_end: float,
                     widths: list, horizons: list, candidates: list[dict],
                     technical: dict | None = None, cells: list[tuple] | np.ndarray | None = None) -> dict:
    """
    機能: 一場の価格木を全追尾候補で共用し、指定された純要求セルだけを計算する。
    引数: records/entries(np.ndarray)、scene_end(float)、widths/horizons/candidates(list)、technical(dict|None)、cells(list|np.ndarray|None)。
    返り値: dict[str,dict[str,np.ndarray]]は候補ID別の金融表。容量一枚再生は呼出し側で全要求から行う。
    """
    assert len({candidate['id'] for candidate in candidates}) == len(candidates)
    evaluator = TrailEvaluator(records, entries, scene_end, widths, horizons, technical)
    return {candidate['id']: evaluator.evaluate_cells(candidate, cells) for candidate in candidates}
