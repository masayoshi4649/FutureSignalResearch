"""自然金融を読まず、遅延追尾・非緩和・技術失効・未知を人工経路で確認する。"""
from pathlib import Path
import hashlib
import json
import math
import numpy as np
import trail181 as T

HERE = Path(__file__).resolve().parent
RECORD = np.dtype({'names': ['time', 'source_line', 'last', 'bid', 'ask', 'normal'],
                  'formats': ['<f8', '<i8', '<f8', '<f8', '<f8', '<u8'],
                  'offsets': [0, 8, 16, 24, 32, 40], 'itemsize': 48})
CATALOG = {value['id']: value for value in T.load_candidates()}

# ----------------------------------------


def make(times: list, points: list, normal: list | None = None, mirror: bool = False) -> np.ndarray:
    """
    機能: 取得Ask10010から見た買い側評価値幅を、対称な人工板へ変換する。
    引数: times/points(list)、normal(list|None)、mirror(bool)は売り側鏡像。
    返り値: np.ndarrayは48byte人工索引。原板や金融結果を読まない。
    """
    normal = [1] * len(times) if normal is None else normal
    values = []
    for line, (at, p, valid) in enumerate(zip(times, points, normal, strict=True), 1):
        bid = 10010 + p
        ask = bid + 10 if valid else bid
        if mirror:
            bid, ask = 40000 - ask, 40000 - bid
        values.append((at, line, (bid + ask) / 2, bid, ask, valid))
    return np.asarray(values, dtype=RECORD)


def technical(times: list, atr: list, gap: list | None = None,
              bb: list | None = None, momentum: list | None = None) -> dict:
    """
    機能: 公表済み人工技術値を作り、欠測をNaNのまま渡す。
    引数: times/atr(list)、gap/bb/momentum(list|None)。
    返り値: dict[str,np.ndarray]は技術timeline。
    """
    n = len(times)
    return {'times': np.asarray(times, float), 'atr_points': np.asarray(atr, float),
            'ma_gap_atr': np.asarray([1.] * n if gap is None else gap, float),
            'bb_width_ratio': np.asarray([1.] * n if bb is None else bb, float),
            'momentum_atr': np.asarray([1.] * n if momentum is None else momentum, float)}


def run(records: np.ndarray, candidate: str, width: float = 350,
        cut: float = 200, horizon: dict | None = None, tech: dict | None = None, side: int = 0) -> dict:
    """
    機能: 一つの人工セルを公開lazy APIから評価する。
    引数: records(np.ndarray)、candidate(str)、width/cut(float)、horizon/tech(dict|None)、side(int)。
    返り値: dictは互換金融値と追尾監査。
    """
    h = {'id': '人工H100', 'kind': 'strict', 'seconds': 100} if horizon is None else horizon
    engine = T.TrailEvaluator(records, np.asarray([0]), cut + 900, [width], [h], tech)
    return engine.evaluate_cell(CATALOG[candidate], 0, side, 0, 0)


def equal(a: object, b: object) -> None:
    """
    機能: 179互換セルをNaN込みで比較する。
    引数: a/b(object)はscalar値。
    返り値: None。不一致はAssertionError。
    """
    if isinstance(a, (float, np.floating)) or isinstance(b, (float, np.floating)):
        assert math.isnan(a) and math.isnan(b) or math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-9), (a, b)
    else:
        assert a == b, (a, b)

# ----------------------------------------


def main() -> None:
    """
    機能: 目的別の人工反例と179 OFF全軸同体、買売対称性、疎評価を確認する。
    引数: なし。
    返り値: None。人工結果.jsonを同folderへ保存し、自然金融を実行しない。
    """
    fixtures = []
    checks = []
    session = {'id': 'SESSION', 'kind': 'session'}
    rows = make([0, 1, 2, 2, 3, 100, 141, 200], [-10, 70, 120, 60, 80, 20, 20, 20])
    fixtures.append(('同秒遅延', rows, 200))
    got = run(rows, 'F050_W050_TP')
    assert got['status'] == 5 and got['trail_trigger_time'] == 2 and got['exit_time'] == 3
    assert got['trail_floor_points'] == 70 and got['points'] == 80 and got['net'] == 6923
    assert got['trail_fill_minus_floor_points'] == 10
    checks.append('同秒後続では決済せず1秒後以降の実BBOで決済')
    mirror = make([0, 1, 2, 2, 3, 100, 141, 200], [-10, 70, 120, 60, 80, 20, 20, 20], mirror=True)
    sold = run(mirror, 'F050_W050_TP', side=1)
    for key in ('status', 'points', 'net', 'trail_activation_time', 'trail_trigger_time', 'exit_time', 'trail_floor_points'):
        equal(got[key], sold[key])
    checks.append('売買はBBO鏡像で同じ条件と損益')
    rows = make([0, 1, 2, 3, 100, 141, 200], [-10, 170, 10, -40, 0, 0, 0])
    # ----------------------------------------
    # 起動150・幅125ではpeak170−125=45、遅延中に床を割る実例。
    got = run(rows, 'F150_W125_TP')
    assert got['trail_floor_points'] == 45 and got['trail_floor_net'] == 3423
    assert got['status'] == 5 and got['net'] == -5077 and got['trail_fill_minus_floor_points'] == -85
    checks.append('正の注文床でも遅延後に赤字となる差を記録')
    rows = make([0, 1, 2, 3, 100, 141, 200], [-10, 120, 10, 0, 0, 0, 0])
    got = run(rows, 'F100_W100_TP')
    assert got['trail_floor_points'] == 20 and got['trail_floor_net'] == 923
    rows = make([0, 1, 2, 3, 100, 141, 200], [-10, 170, 10, 0, 0, 0, 0])
    trial = {**CATALOG['F150_W125_TP'], 'id': '人工だけの広幅', 'trail_pt': 500}
    engine = T.TrailEvaluator(rows, np.asarray([0]), 1100, [350], [{'id': 'H100', 'kind': 'strict', 'seconds': 100}])
    got = engine.evaluate_cell(trial, 0, 0, 0, 0)
    assert got['trail_floor_points'] == 15 and got['trail_floor_net'] == 423
    checks.append('費用回収10.77ptをmini5ptへ上丸めし最低床15pt')
    rows = make([0, 1, 2, 3, 4, 5, 6, 100, 141, 200], [-10, 120, 200, 160, 155, 140, 130, 100, 100, 100])
    fixtures.append(('幅非緩和', rows, 200))
    got = run(rows, 'A100_ATR_TP', tech=technical([1, 3, 4], [100, 10, 100]))
    assert got['trail_trigger_time'] == 5 and got['exit_time'] == 6 and got['trail_floor_points'] == 150
    assert got['net'] == 11923
    checks.append('ATR縮小後に拡大しても床150ptを緩めない')
    rows = make([0, 1, 2, 3, 100, 141, 200], [-10, 120, 60, 80, 80, 80, 80])
    got = run(rows, 'T100_ATR収束_TP', tech=technical([1], [100], [.1], [.8], [1]))
    assert got['trail_technical_tightenings'] >= 1 and got['trail_trigger_time'] == 2 and got['exit_time'] == 3
    unknown = run(rows, 'T100_ATR収束_TP', tech=technical([1], [100], [float('nan')], [.8], [1]))
    assert unknown['trail_technical_tightenings'] == 0 and unknown['status'] == 3
    checks.append('MAとBB収束を複合し一部未知を収束としない')
    rows = make([0, 1, 180, 182, 190, 191, 300, 500, 700, 900, 941, 1000],
                [-10, 200, 150, 150, 90, 80, 100, 100, 100, 100, 100, 100])
    fixtures.append(('鮮度失効', rows, 1000))
    got = run(rows, 'A100_ATR_TP', width=400, cut=1000, horizon=session, tech=technical([1], [100]))
    assert got['trail_trigger_time'] == 190 and got['exit_time'] == 191 and got['trail_floor_points'] == 100
    assert got['trail_stale_fallbacks'] >= 1
    checks.append('180秒超の失効だけで固定代替幅へ狭まり床を上げる')
    rows = make([0, 1, 2, 400, 700, 941, 1000], [-10, 120, 60, -200, -200, -200, -200])
    fixtures.append(('価格gap', rows, 1000))
    got = run(rows, 'F050_W050_OPEN', width=100, cut=1000, horizon=session)
    assert not got['known'] and got['status'] == 10 and math.isnan(got['net'])
    assert got['label'] == 1 and got['first_observed_label'] == 1 and got['first_observed_time'] == 1
    checks.append('価格gap後に復活せず先着Fと金融未知を分離')
    rows = make([0, 1, 2, 100, 200, 300, 303, 304, 500, 700, 900, 941, 1000],
                [-10, 120, 60, 60, 60, 60, 60, 50, 50, 50, 50, 50, 50],
                [1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1])
    fixtures.append(('BBOgap', rows, 1000))
    got = run(rows, 'F050_W050_TP', cut=1000, horizon=session)
    assert not got['known'] and got['status'] == 11 and got['label'] == 2
    checks.append('価格時計が続いても正常BBOの300秒超で未知')
    rows = make([0, 1, 2, 3, 100, 141, 200], [-10, 120, 60, -350, -350, -350, -350])
    fixtures.append(('元逆指値優先', rows, 200))
    got = run(rows, 'F050_W050_TP')
    assert got['trail_triggered'] and got['status'] == 2 and got['exit_time'] == 3 and got['net'] == -36077
    checks.append('追尾待機中の元IFDは同原行でも優先')
    rows = make([0, 1, 50, 100, 141, 200], [-10, 120, 100, 100, 100, 100])
    fixtures.append(('終了前予定決済', rows, 200))
    got = run(rows, 'F100_W100_TP', horizon=session)
    assert got['status'] == 4 and got['forced'] and got['exit_time'] == 141
    checks.append('終了前cut-60要求の1秒後正常BBOを維持')
    rows = make([0, 1, 100, 141, 200], [-10, 120, 60, 60, 60])
    fixtures.append(('通常期限同原行', rows, 200))
    got = run(rows, 'F050_W050_TP')
    assert got['status'] == 3 and got['exit_time'] == 100 and not got['trail_triggered']
    checks.append('通常期限同原行を新規追尾判断より優先')
    comparisons = 0
    cells = 0
    widths = [50, 100, 150, 350]
    horizons = [{'id': 'H30', 'kind': 'strict', 'seconds': 30},
                {'id': 'H100', 'kind': 'strict', 'seconds': 100}, session]
    for name, original, cut in fixtures:
        for mirror in [False, True]:
            records = original.copy()
            if mirror:
                records['bid'], records['ask'] = 40000 - original['ask'], 40000 - original['bid']
            expected = T.E.evaluate_records(records, np.asarray([0]), cut + 900, widths, horizons)
            engine = T.TrailEvaluator(records, np.asarray([0]), cut + 900, widths, horizons)
            for cell in np.ndindex(expected['known'].shape):
                actual = engine.evaluate_cell(CATALOG['C0_IFD'], *cell)
                for field in expected:
                    equal(actual[field], expected[field][cell])
                    comparisons += 1
                cells += 1
    engine = T.TrailEvaluator(fixtures[0][1], np.asarray([0]), 1100, widths, horizons)
    sparse = engine.evaluate_cells(CATALOG['F050_W050_TP'], [(0, 0, 3, 1)])
    assert sparse['evaluated'].sum() == 1 and sparse['evaluated'][0, 0, 3, 1]
    assert sparse['known'][0, 0, 3, 1] and not sparse['known'][~sparse['evaluated']].any()
    cached = engine.evaluate_cell(CATALOG['F050_W050_TP'], 0, 0, 3, 1)
    cached['net'] = 999
    assert engine.evaluate_cell(CATALOG['F050_W050_TP'], 0, 0, 3, 1)['net'] != 999
    checks.append('疎な全軸表の未評価を明示しキャッシュ破壊を防ぐ')
    proof = {'成功': True, '自然金融未読': True, '目的別確認': checks,
             '基準OFF比較セル': cells, '基準OFF比較属性数': comparisons,
             '候補数': len(CATALOG),
             'Source': [{'path': path.name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
                        for path in [HERE / 'trail181.py', HERE / '候補181.json', Path(__file__)]],
             '固定条件': T.CONFIG}
    (HERE / '人工結果.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    print(json.dumps(proof, ensure_ascii=False))


if __name__ == '__main__':
    main()
