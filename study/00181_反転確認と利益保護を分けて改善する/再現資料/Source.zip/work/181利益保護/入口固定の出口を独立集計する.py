"""全期間完成後にE181_00の出口十一案だけを台帳から独立再集計する。"""
from pathlib import Path
import gzip
import hashlib
import json
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
RUN = ROOT / 'work/181反省を分解した改善'
CONDITION = ROOT / 'study/00181_反転確認と利益保護を分けて改善する/条件.json'
sys.path.insert(0, str(ROOT / 'work/179固定結果の独立検査'))
import independent179 as I

# ----------------------------------------


def ref(path: Path) -> dict:
    """
    機能: 読取資料と独立計算Sourceの指紋を保存する。
    引数: path(Path)。
    返り値: dictは相対path・bytes・sha256。
    """
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def read(path: Path) -> dict:
    """
    機能: 全体が完成したgzip又はJSONを読み込む。
    引数: path(Path)。
    返り値: dict。欠落・不完全ファイルを0取引へ補正せず例外とする。
    """
    body = path.read_bytes()
    return json.loads(gzip.decompress(body) if path.suffix == '.gz' else body)


def subset(pack: dict, sessions: list[dict]) -> dict:
    """
    機能: 対象セッションを残し、取得と実保有を同じ場集合へ切り出す。
    引数: pack(dict)、sessions(list[dict])は対象の全場。
    返り値: dictは独立集計用のledger/sessions/positions。
    """
    scenes = {row['scene'] for row in sessions}
    take = [index for index, name in enumerate(pack['ledger']['scene']) if name in scenes]
    return {'ledger': {name: [values[index] for index in take] for name, values in pack['ledger'].items()},
            'sessions': sessions, 'positions': [row for row in pack['positions'] if row['scene'] in scenes]}


def merge(packs: list[dict]) -> dict:
    """
    機能: 同じ固定入口と出口の全期間台帳を連結する。
    引数: packs(list[dict])は完成した同一政策。
    返り値: dictは率や中央値を平均せず、全取得から再計算するための台帳。
    """
    result = {name: sum((pack[name] for pack in packs), []) for name in ('sessions', 'positions')}
    assert len({row['scene'] for row in result['sessions']}) == len(result['sessions'])
    assert all(set(pack['ledger']) == set(packs[0]['ledger']) for pack in packs)
    result['ledger'] = {name: sum((pack['ledger'][name] for pack in packs), []) for name in packs[0]['ledger']}
    return result


def calculate(pack: dict, actual: dict | None, label: str, counter: dict) -> dict:
    """
    機能: 利益・損失・中央値・保有下限を、既存Root集計と別の実装で計算する。
    引数: pack(dict)、actual(dict|None)は照合先evidence、label(str)、counter(dict)。
    返り値: dictは全金融群・独立保有・比較しやすい要約。
    """
    groups = I.financial_groups(pack)
    held = I.holding(pack['sessions'], pack['positions'])
    if actual is not None:
        old = actual['financial']
        mapping = {'ALL': old['all_reference'], 'DAY': old['session_groups_required']['DAY'],
                   'NIGHT': old['session_groups_required']['NIGHT'],
                   'PRE': old['phases_diagnostic']['PRE'], 'POST': old['phases_diagnostic']['POST']}
        I.V.compare(groups, mapping, label + '/金融', counter)
        I.V.compare(held, {key: actual['holding'][key] for key in held}, label + '/保有', counter)
    brief = {}
    for band in ('DAY', 'NIGHT', 'PRE', 'POST', 'ALL'):
        group = groups[band]
        trade, scenes, hold = group['trades'], group['sessions'], held['groups'][band]
        brief[band] = {'取得': trade['all_count'], '利益': trade['known_profit'], '損失': trade['known_loss'],
            '既知収支': trade['known_net'], '全件確定収支': trade['known_net'] if trade['unknown_count'] == 0 else None,
            '利益損失比': trade['known_profit'] / trade['known_loss'] if trade['known_loss'] else None,
            '金融未知': trade['unknown_count'], '建玉中央値下限': trade['net_median']['lower'],
            '場中央値下限': scenes['net_median']['lower'], '場中央値上限': scenes['net_median']['upper'],
            '両中央値': group['decision']['status'], '参加場': scenes['participating_count'],
            '対象場': scenes['eligible_count'], '完全黒字場': scenes['complete_positive_count'],
            '完全赤字場': scenes['complete_negative_count'], '未知場': scenes['unknown_count'],
            '保有下限': hold['held_lower_ratio'], '保有上限': hold['held_upper_ratio'],
            '場保有率中央値下限': hold['scene_ratio_median_lower'],
            '保有20%以上の場数': hold['scene_target_met_guaranteed_count']}
    return {'要約': brief, '金融': groups, '保有': held}


def shown(value: object, percent: bool = False, ratio: bool = False) -> str:
    """
    機能: 未知を0と表示せず、金額・率をMarkdownへ変換する。
    引数: value(object)、percent/ratio(bool)は表示単位。
    返り値: strは表示値。
    """
    if value is None:
        return '—'
    if percent:
        return f'{value:.2%}'
    return f'{value:.3f}' if ratio else f'{value:,.1f}'.removesuffix('.0')


def document(rows: dict, candidates: list[dict], counter: dict) -> str:
    """
    機能: 全80を主とし、本日1・全81を診断へ分けた出口十一案の表を作る。
    引数: rows(dict)は独立再集計、candidates(list[dict])、counter(dict)。
    返り値: strは所見を追記できる日本語Markdown。新候補の選択はしない。
    """
    text = ['# 固定入口E181_00の出口十一案', '',
        '入口・初期幅・期限は同じ。出口の変化で数量一枚の枠が早く空いた場合の後続取得も再生した結果であり、元の取得だけの出口置換ではない。', '',
        '全80（旧73＋追加7）を主比較とし、前48・後25を併記する。本日1と全81は診断専用で、ここで候補や閾値を選び直さない。全て既使用資料であり未見検証ではない。', '',
        '金額はmini1枚の費用後円。収支は既知寄与であり、金融未知を0円と確定していない。中央値下限は未知を任意値とした保証下限。保有は取得後だけを数えた全対象時間加重の下限。', '']
    for band, caption in [('DAY', 'デイ'), ('NIGHT', 'ナイト合計')]:
        text += [f'## 全80・{caption}', '',
            '| 出口ID | 回数 | 利益 | 損失 | 既知収支 | 利益/損失 | 建玉中央値下限 | 場中央値下限 | 金融未知 | 保有下限 | 参加場 |',
            '|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
        for candidate in candidates:
            name = candidate['id']; row = rows[name]['全80']['要約'][band]
            values = [name, shown(row['取得']), shown(row['利益']), shown(row['損失']), shown(row['既知収支']),
                shown(row['利益損失比'], ratio=True), shown(row['建玉中央値下限']), shown(row['場中央値下限']),
                shown(row['金融未知']), shown(row['保有下限'], percent=True), f"{row['参加場']}/{row['対象場']}"]
            text.append('| ' + ' | '.join(values) + ' |')
        text += ['', f'## {caption}の前後・追加期間差', '',
            '| 出口ID | 前48既知収支 | 後25既知収支 | 追加7既知収支 | 前48場中央値下限 | 後25場中央値下限 | 追加7場中央値下限 |',
            '|---|---:|---:|---:|---:|---:|---:|']
        for candidate in candidates:
            name = candidate['id']
            periods = [rows[name][period]['要約'][band] for period in ('前48', '後25', '追加7')]
            values = [name, *[shown(row['既知収支']) for row in periods], *[shown(row['場中央値下限']) for row in periods]]
            text.append('| ' + ' | '.join(values) + ' |')
        text += ['']
    text += ['## 本日一場・全81は診断', '',
        '| 出口ID | 本日利益 | 本日損失 | 本日収支 | 本日回数 | 本日保有下限 | 全81デイ既知収支 |',
        '|---|---:|---:|---:|---:|---:|---:|']
    for candidate in candidates:
        name = candidate['id']; today = rows[name]['本日1']['要約']['DAY']; all81 = rows[name]['全81']['要約']['DAY']
        values = [name, shown(today['利益']), shown(today['損失']), shown(today['既知収支']), shown(today['取得']),
                  shown(today['保有下限'], percent=True), shown(all81['既知収支'])]
        text.append('| ' + ' | '.join(values) + ' |')
    text += ['', '## 検算と解釈', '',
        f"33packの金融・保有と前48/後25を、台帳と実時間区間から独立計算し{counter['scalar']:,}項目を照合した。結果・Sourceの読取前後指紋も一致した。",
        '', 'TPは元利確を維持、OPENは元利確だけを撤廃する。C0_IFDは基準。OPENで先着済F/Aの後に金融未知となった建玉は、到達と金融未知を分けて保持する。',
        '', '保護床の費用後同値以上は注文判断値であり、接触後1秒以降の実BBO約定がその金額を保証するものではない。',
        '', '未知を含む群の収支・利益損失比は既知部分だけの比較。保有20%や全場参加が落ちた案は、損失額だけで全面改善と扱わない。',
        '', '完全な金融群・全場の中央値境界・保有上下限は自然比較の独立結果.jsonを参照する。']
    base_day = rows['C0_IFD']['全80']['要約']['DAY']
    early_day = rows['F050_W050_TP']['全80']['要約']['DAY']
    base_night = rows['C0_IFD']['全80']['要約']['NIGHT']
    early_night = rows['F050_W050_TP']['全80']['要約']['NIGHT']
    text += ['', '## 出口だけを変えた所見', '',
        f"固定入口では、50pt起動・50pt追尾によりデイの既知損失は{shown(base_day['損失']-early_day['損失'])}円減った一方、利益は{shown(base_day['利益']-early_day['利益'])}円減った。ナイトも損失減{shown(base_night['損失']-early_night['損失'])}円に対し利益減{shown(base_night['利益']-early_night['利益'])}円で、早い保護が過去の大きな勝ちを削った。",
        '', '全80では、比較した追尾十案の利益損失比・既知収支はデイもナイトも基準IFDに届かなかった。したがって、この固定入口に181の追尾を一律追加すれば全面改善する、とは言えない。',
        '', f"50pt追尾のナイト保有下限{shown(early_night['保有下限'], percent=True)}は20%を割る。取得回数が増えても、実保有時間の参加が十分とは限らない。",
        '', '追加7のナイトは全十一案で既知収支も場中央値下限も赤字のまま。全期の中央値や後25の黒字だけで期間の弱さを解消したとは扱えない。',
        '', '本日一場ではATR系TPの収支が+4,384円となるが、同じ出口の全80デイは基準IFDを大きく下回る。本日の改善だけを理由に採用・再選択しない。',
        '', 'この診断はE181_00に限る。新入口との組合せの成績や、182以降の候補へ一般化しない。']
    return '\n'.join(text) + '\n'

# ----------------------------------------


def main() -> None:
    """
    機能: 全528期間pack完成をgateに、固定入口出口11案を独立集計して保存する。
    引数: なし。欠落時は金融を読まず例外終了する。
    返り値: None。自然比較の独立結果.jsonと自然比較の所見.mdを作る。
    """
    condition = read(CONDITION)
    candidates = condition['出口']['候補']
    entries = condition['入口']['rules']
    expected = {entry['id'] + '__' + candidate['id'] + '.json.gz' for entry in entries for candidate in candidates}
    assert len(entries) == 16 and len(candidates) == 11 and len(expected) == 176
    legs = ('旧73', '追加7', '本日1')
    for leg in legs:
        existing = {path.name for path in (RUN / '期間別' / leg).glob('*.json.gz')}
        assert expected == existing, (leg, '全期間が未完成', len(existing), len(expected - existing))
    paths = [RUN / '期間別' / leg / ('E181_00__' + candidate['id'] + '.json.gz')
             for candidate in candidates for leg in legs]
    sources = [CONDITION, Path(__file__), Path(I.__file__), Path(I.F.__file__),
               HERE / 'trail181.py', HERE / '候補181.json', *paths]
    before = [ref(path) for path in sources]
    counter = {'scalar': 0}
    output = {}
    for candidate in candidates:
        name = candidate['id']
        packs = {leg: read(RUN / '期間別' / leg / ('E181_00__' + name + '.json.gz')) for leg in legs}
        values = {}
        for leg, pack in packs.items():
            assert pack['id'] == 'E181_00__' + name
            assert pack['policy']['entry'] == 'E181_00' and pack['policy']['exit'] == name
            values[leg] = calculate(pack, pack['evidence'], name + '/' + leg, counter)
        old = packs['旧73']
        assert len(old['sessions']) == 73
        for period, scenes in [('前48', old['sessions'][:48]), ('後25', old['sessions'][48:])]:
            values[period] = calculate(subset(old, scenes), old['periods'][period], name + '/' + period, counter)
        values['全80'] = calculate(merge([packs['旧73'], packs['追加7']]), None, name + '/全80', counter)
        values['全81'] = calculate(merge([packs[leg] for leg in legs]), None, name + '/全81', counter)
        output[name] = values
    assert before == [ref(path) for path in sources]
    proof = {'成功': True, '再選択なし': True, '入力不変': True, '全528pack完成後': True,
        '入口': 'E181_00', '候補数': len(candidates), '元pack': len(paths), '照合項目': counter,
        '資料': before, '候補': output, '注意': '全80/前48比較。全81と本日1は診断専用。未見検証ではない。'}
    (HERE / '自然比較の独立結果.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    (HERE / '自然比較の所見.md').write_text(document(output, candidates, counter), encoding='utf-8')
    print(json.dumps({'成功': True, '候補数': len(candidates), '元pack': len(paths), '照合項目': counter}, ensure_ascii=False))


if __name__ == '__main__':
    main()
