"""汎用表版8の63行567セルを残し、181の使用設定だけを未計算で記入する。"""
from pathlib import Path
import hashlib
import os
import re
import sys
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).parent
V8 = ROOT / 'docs/議論/手法と時間スケールの汎用表_版8.md'
DESTINATION = ROOT / 'study/00181_反転確認と利益保護を分けて改善する'
SCALES = ('原板・逐次', '1分', '3分', '5分', '15分', '30分', '60分', 'セッション足', '日足')


def grid(text: str) -> dict:
    """
    機能: 汎用表の手法行63本だけを取り出す。
    引数: text(str)はMarkdown本文。
    返り値: dictはIDから手法名と9尺度セルへの対応。
    """
    result = {}
    for line in text.splitlines():
        fields = [value.strip() for value in line.strip().strip('|').split('|')]
        if len(fields) == 11 and re.fullmatch('[ICPVBXME][0-9]{2}', fields[0]):
            assert fields[0] not in result
            result[fields[0]] = fields
    assert len(result) == 63
    return result


def main() -> None:
    """
    機能: 原表全文・継承セル・新比較セル・全候補設定を結果未計算の下書きへ保存する。
    引数: なし。
    返り値: None。正式文書へはRootが結果を追記して移す。
    """
    sys.path.insert(0, str(ROOT / 'work/181入口改善'))
    import rules181_v2 as entry
    raw = V8.read_text(encoding='utf-8')
    original = grid(raw)
    inherited = grid((ROOT / 'study/00179_保有時間参加率と終了前決済で入口を広げる/設定と結果.md').read_text(encoding='utf-8'))
    changed = {}
    settings = {
        'I01': ('原板・逐次', '5分', '15分', '30分'), 'I02': ('原板・逐次', '5分'),
        'I03': ('5分', '15分'), 'I04': ('5分',), 'I05': ('15分',),
        'I08': ('5分', '15分', '30分'), 'I09': ('原板・逐次', '1分', '5分'),
        'C01': ('5分', '15分', '30分'), 'C04': ('5分', '15分', '30分'),
        'C06': ('原板・逐次', '5分', '15分'), 'C07': ('1分', '5分', '15分', '30分'),
        'P01': ('1分',), 'P05': ('原板・逐次', '1分'), 'P06': ('原板・逐次', '1分'),
        'P07': ('原板・逐次', '1分'), 'P08': ('原板・逐次', '1分', '5分'),
        'V01': ('1分',), 'B01': ('原板・逐次',), 'E01': ('原板・逐次',),
        'E02': ('原板・逐次', '5分', '15分')}
    for identity, fields in original.items():
        cells = ['未使用・今回未検証'] * 9
        for i, prior in enumerate(inherited[identity][2:]):
            if 'S179-' in prior:
                cells[i] = '参照継承 S181-BASE/R181'
        for scale in settings.get(identity, ()):
            name = 'S181-EXIT' if identity in ('C06', 'E02') else 'S181-ENTRY'
            if identity == 'I05':
                name = 'S181-EXIT（入口は参照継承）'
            elif identity == 'I09' and scale == '5分':
                name = 'S181-ENTRY+EXIT'
            elif identity in ('I01', 'I03') and scale == '5分':
                name = 'S181-ENTRY+EXIT'
            elif identity == 'E01':
                name = 'S181-IFD'
            cells[SCALES.index(scale)] = '今回比較 ' + name + '/R181（未計算）'
        changed[identity] = cells
    lines = []
    for line in raw.splitlines():
        fields = [value.strip() for value in line.strip().strip('|').split('|')]
        if len(fields) == 11 and fields[0] in original:
            line = '| ' + ' | '.join(fields[:2] + changed[fields[0]]) + ' |'
        lines.append(line)
    text = '\n'.join(lines) + '\n'
    def rebase(match: re.Match) -> str:
        """
        機能: 原表の相対リンクを正式181試行階層からの相対リンクへ直す。
        引数: match(re.Match)はMarkdownリンク。
        返り値: strは移動後も同じ文書を指すリンク。
        """
        label, target = match.group(1), match.group(2)
        if '://' in target or target.startswith('#'):
            return match.group(0)
        path = (V8.parent / target).resolve()
        return '[' + label + '](' + os.path.relpath(path, DESTINATION).replace('\\', '/') + ')'
    text = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', rebase, text)
    text = text.replace('# 手法と時間スケールの汎用表・版8', '# 00181 設定と結果（下書き・結果未計算）', 1)
    text = text.replace('全セルは未設定・未検証。', '本表は版8全文をコピーした63手法×9尺度の567セル。今回比較・参照継承・未使用を区別し、全結果欄は未計算。', 1)
    text = text.replace('| S01 | 未設定 | 未設定 | 未設定 | 未設定 | R01 | 未検証 |',
        '| S181-BASE | 179/178固定複合の該当セル | 参照継承 | 旧73/追加7/本日1の当時100特徴・純固定出生。夜間とLCは不変 | 旧BO350/H60・MP150/H60・LC400/SESSION、旧T45分など元条件維持 | R181基準E181_00/C0_IFD | 固定基準の同体のみ確認、新成績未計算 |\n'
        '| S181-ENTRY | 表中の方向/動力/価格構造/量/品質 | 今回比較 | 1分・5分、早期枝は15/30分も代替背景に使用。場/限月/gap180秒で状態消去 | 下の入口16案と役割閾値。売買は符号対称 | R181-IN/R181-JOINT | 金融評価前の仮説、新成績未計算 |\n'
        '| S181-IFD | E01/原板・逐次 | 固定出口対照 | 取得後の実側BBO・元幅/期限・終了15分前打切り | 対称IFD幅150/350/400pt等の継承、通常H60又はSESSION | C0_IFD | 旧固定定義を継承、新入口との成績未計算 |\n'
        '| S181-EXIT | I01/I03/I05/I09/C06/E02 | 今回比較 | q0+1秒反映のATR5・MA差・MACD増分・BB15σの15実分前比、原板で追尾管理 | 下の出口11案。費用後50/100/150pt起動、最低床15pt・非緩和・追尾注文1秒遅延 | R181-EXIT/R181-JOINT | 金融評価前の仮説、新成績未計算 |')
    text = text.replace('| R01 | 未設定 | 未設定 | 未設定 | 未検証 | 未検証 |',
        '| R181-IN | 入口16案×C0_IFD | 旧73前48/後25・追加7・本日1、全81 | 全場・全取得・全予約、件数未計算 | 未計算。mini1枚・片道38.5円+5pt・実側BBO | 全て既使用、本日を踏まえた設計。未見検証ではない |\n'
        '| R181-EXIT | 基準E181_00×出口11案 | 同上 | 同一入口でも出口で枠解放と後続取得を再計算 | 未計算 | 利益保護で新しい取り逃がし利益を最適化しない |\n'
        '| R181-JOINT | 入口16案×出口11案の176組 | 同上。全80選択/前48選択と本日/全81診断を区別 | 全対象時間・0取引場・未知も残す | 未計算 | 構成指標単独の有効性とは解釈しない |')
    text += '\n## 181の設定補足（全結果未計算）\n\n'
    text += 'この下書きは自然成績を読まず作成。元版8の表は63行567セルを保持した。旧179に使用された役割だけを「参照継承」、今回比較する役割を「今回比較」とし、未使用を有効性なしとは扱わない。15/30分を記したセルも全足同方向を必須にしたという意味ではなく、EARLY枝ではいずれかの既知背景を代替で使用する。セッション打切り/H60は保有期限であり、セッション足/60分足の指標使用と区別する。\n\n'
    text += '使用Sourceと全閾値の正本は [条件.json](条件.json)。入口の旧8案を保持し、金融結果を見る前に早期回復/位置緩和8案を別IDで追加した。\n\n'
    text += '| 入口ID | BO | MP | 確認期限・位置 | 設定版 | 結果 |\n|---|---|---|---|---|---|\n'
    for rule in entry.catalog()['rules']:
        window = rule.get('bo_window_seconds')
        position = rule.get('bo_position', '厳格時−.25〜.75ATR5')
        upper = rule.get('mp_position_max')
        text += f"| {rule['id']} | {rule['bo']} | {rule['mp']} | {window if window is not None else '待ちなし'}秒 / BO位置{position} / MP上限{upper if upper is not None else '元条件又はQUALITY .75'} | {rule['source_version']} | 未計算 |\n"
    text += '\n厳格BO確認は、実方向の5分Hist増分>=0・RSI増分>0、5分EMA21傾き>0又はDI差>0、過去5実分からEMA8/直前3分端の回復、正の1分実体・進行/live、相対量>=.75、RSI中心−10〜20・増分絶対値<=8、TR/ATR比・spread・鮮度を複合する。STRICT30はBOのEMA8距離上限だけ.75→1.5ATR5とする。\n\n'
    text += 'EARLY15/30は、セットアップ時よりHist/RSI増分が共に悪化しない又は両水準改善、1分実体/進行/live>0と前実体<=0又は価格端回復又は終値位置>=.65、5/15/30分のEMA/DIのどれか又は15分Hist増分>=0又はADX低下、位置−1〜1.5ATR5、相対量>=.5、品質を組み合わせる。ADX低下単独で方向を決めない。\n\n'
    text += 'MP QUALITYは位置−.25〜.75ATR5、正の実体/live等の厳格確認。SOFTは位置−.5〜1.5/2ATR5で、実体<0・進行<0・live<=0の同時失敗、又は大TRとRSI増分/相対量の同時スパイクだけを除外する。RSIの高止まりだけでは禁止しない。旧MP/LCを確認BOより優先し、確認は後続q0で一度だけ行う。\n\n'
    exits = json.loads((ROOT / 'work/181利益保護/候補181.json').read_text(encoding='utf-8'))['候補']
    text += '| 出口ID | 起動（費用後pt） | 幅 | 元TP | 結果 |\n|---|---:|---|---|---|\n'
    for rule in exits:
        width = '元IFDのみ' if rule['mode'] == 'off' else str(rule['trail_pt']) + 'pt' if rule['mode'] == 'fixed' else '1.5×ATR5、50〜125pt、未知/古い時100pt' + ('、複合収束時50pt' if rule['mode'] == 'technical' else '')
        text += f"| {rule['id']} | {rule.get('activation_net_pt', '起動なし')} | {width} | {'維持' if rule['keep_take_profit'] else '撤廃'} | 未計算 |\n"
    text += '\n全追尾はピーク値幅−幅と往復費用10.77ptの大きい方をmini5pt刻みに上へ丸め、最低15ptを床とし、起動後は下げない。床は価格の保証ではなく判断値で、接触後1秒以降の最初の正常BBOを返済に使う。したがって実際の返済値が床を下回り、費用後赤字となる場合も残す。元IFD→通常/終了前返済→新追尾の同原行優先を守る。\n\n'
    text += '複合縮小はBB15σ/15実分前σ<=.9、かつ絶対MA8/21差/ATR5<=.25又は実方向MACD増分/ATR5<=0。参照BBは15実分前の直前q0で古さ90秒以内、q0+1秒から使用し、現技術の鮮度180秒を超えれば固定代替。ATR正常で他技術が一部未知ならATR幅だけを使い、未知を収束と見なさない。原板/正常BBO gap300超は既存未知規則を保持する。\n\n'
    text += '買売合計の保有+pendingを1件以下、開始一律待機なし、Day15:29/Night05:44に予定決済要求と新規停止・予約取消、締切15:30/05:45。1pt100円、往復手数料77円＋追加滑り1000円。全場の実保有時間/全対象時間20%以上、建玉/セッションの両中央値を評価し、黒字場・上位3正純益場除外後・DD・未知・頻度も併記する。\n\n'
    text += '## 外部一次資料と研究仮説\n\n'
    text += '[Fidelity公式RSI](https://www.fidelity.com/learning-center/trading-investing/technical-analysis/technical-indicator-guide/rsi)（確認2026-11-16）は、強いトレンドで過熱状態が持続し得ると説明する。これはRSI水準だけで反転を決めない一般的な背景で、今回の数値閾値の有効性の根拠ではない。\n\n'
    text += '[Fidelity公式ATR](https://www.fidelity.com/learning-center/trading-investing/technical-analysis/technical-indicator-guide/atr)（確認2026-11-16）は、ATRが方向を示さない値幅尺度で、固定幅とは異なる保護幅の調整へ使えると説明する。今回の起動50/100/150pt、ATR倍率1.5、幅50〜125、BB比.9/MA差.25は事前の研究仮説であり、教材の推奨をそのまま採用した条件ではない。複数指標の票を独立した確率として掛け合わせない。\n'
    before = grid(raw); after = grid(text)
    assert set(before) == set(after) and all(len(row) == 11 for row in after.values())
    assert all(before[key][1].split(']')[0] == after[key][1].split(']')[0] for key in before)
    assert 'S01 | 未設定' not in text and '| R01 | 未設定' not in text
    target = HERE / '設定と結果_下書き.md'
    target.write_text(text, encoding='utf-8')
    proof = {'成功': True, '原表': {'path': V8.relative_to(ROOT).as_posix(), 'sha256': hashlib.sha256(V8.read_bytes()).hexdigest()},
        '手法数': len(after), '尺度数': 9, 'セル数': len(after) * 9, '入口数': len(entry.catalog()['rules']), '出口数': len(exits),
        '新結果': '未計算', 'リンク基準': DESTINATION.relative_to(ROOT).as_posix(),
        '下書きSHA256': hashlib.sha256(target.read_bytes()).hexdigest()}
    (HERE / '設定下書きの確認.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(proof, ensure_ascii=False))


if __name__ == '__main__':
    main()
