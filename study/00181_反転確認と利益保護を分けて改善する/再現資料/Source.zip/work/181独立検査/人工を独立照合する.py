"""181追尾のイベント木と、独立した全正常原行ループを人工価格で照合する。"""
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
from 逐次追尾181 import SequentialScene

FIELDS = ('label', 'known', 'net', 'net0', 'exit_time', 'exit_price', 'exit_index', 'exit_line',
    'status', 'forced', 'known_at', 'holding_confirmed_until', 'exit_deadline', 'nominal_deadline',
    'exit_quote_time', 'points', 'direction', 'trail_activated', 'trail_triggered',
    'trail_activation_time', 'trail_activation_line', 'trail_trigger_time', 'trail_trigger_line',
    'trail_trigger_price', 'trail_floor_points', 'trail_floor_price', 'trail_floor_net',
    'trail_peak_points', 'trail_fill_minus_floor_points', 'first_observed_label', 'first_observed_time')
DTYPE = np.dtype([('time', '<f8'), ('source_line', '<i8'), ('last', '<f8'),
    ('bid', '<f8'), ('ask', '<f8'), ('normal', '<u8')])


def module(path: Path, name: str) -> object:
    """
    機能: 検査対象Sourceを独自名で読み込む。
    引数: path(Path)、name(str)。
    返り値: objectはmodule。
    """
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    sys.modules[name] = result
    spec.loader.exec_module(result)
    return result


def same(a: object, b: object) -> bool:
    """
    機能: 金融未知のNaNだけを同値とし、数値やboolを照合する。
    引数: a/b(object)はscalar。
    返り値: boolは同値かどうか。
    """
    if isinstance(a, (float, np.floating)) and isinstance(b, (float, np.floating)):
        if math.isnan(a) and math.isnan(b):
            return True
        return math.isclose(float(a), float(b), abs_tol=1e-9, rel_tol=1e-12)
    return bool(a == b)


def ref(path: Path) -> dict:
    """
    機能: 人工検査で用いたSourceを指紋へ束縛する。
    引数: path(Path)。
    返り値: dictはpath/bytes/sha256。
    """
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size,
        'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def main() -> None:
    """
    機能: 固定seed人工パスと両側・複数期限/幅・全11出口を全原行へ照合する。
    引数: なし。
    返り値: None。自然市場の成績や順位は読まず、独立人工結果JSONを作る。
    """
    source = ROOT / 'work/181利益保護/trail181.py'
    production = module(source, 'trail181_independent_synthetic')
    candidates = production.load_candidates()
    checked = 0; attributes = 0; mismatches = []
    horizons = [{'id': 'H300', 'kind': 'strict', 'seconds': 300}, {'id': 'SESSION', 'kind': 'session'}]
    for seed in range(20):
        rng = np.random.default_rng(181000 + seed)
        rows = np.zeros(400, dtype=DTYPE)
        rows['time'] = np.cumsum(rng.integers(1, 5, len(rows))).astype(float)
        rows['time'] -= rows['time'][0]
        if seed % 4 == 1:
            rows['time'][220:] += 350
        rows['source_line'] = np.arange(1, len(rows) + 1)
        bid = 10000 + np.cumsum(rng.integers(-12, 13, len(rows))) * 5
        rows['bid'] = bid; rows['ask'] = bid + 5; rows['last'] = bid
        rows['normal'] = 1
        invalid = rng.choice(np.arange(30, len(rows)), 25, replace=False)
        rows['normal'][invalid] = 0; rows['ask'][invalid] = rows['bid'][invalid]
        technical = {'times': np.asarray([1., 101., 201., 301., 401.]),
            'atr_points': np.asarray([100., 20., np.nan, 60., 90.]),
            'ma_gap_atr': np.asarray([.5, .1, .1, np.nan, .1]),
            'bb_width_ratio': np.asarray([1., .8, .8, .8, .8]),
            'momentum_atr': np.asarray([1., -1., 1., -1., np.nan])}
        scene_end = 1900.
        entries = np.asarray([0, 20], dtype=np.int64)
        slow = SequentialScene(rows, scene_end, technical)
        fast = production.TrailEvaluator(rows, entries, scene_end, [150, 400], horizons, technical)
        for candidate in candidates:
            for ci, entry in enumerate(entries):
                for side in (0, 1):
                    for wi, width in enumerate((150, 400)):
                        for hi, horizon in enumerate(horizons):
                            a = fast.evaluate_cell(candidate, ci, side, wi, hi)
                            b = slow.evaluate(candidate, int(entry), side, width, horizon)
                            checked += 1
                            assert b['床非緩和'] and b['最小床遵守'] and b['追尾遅延遵守']
                            for field in FIELDS:
                                attributes += 1
                                if not same(a[field], b[field]):
                                    mismatches.append({'seed': seed, 'candidate': candidate['id'], 'cell': [ci, side, wi, hi],
                                        'field': field, 'production': str(a[field]), 'independent': str(b[field])})
        if mismatches:
            break
    body = {'成功': not mismatches, '自然金融未入力': True, 'セル数': checked,
        '照合属性数': attributes, '不一致': mismatches[:30], '不一致総数': len(mismatches),
        'Source': [ref(source), ref(HERE / '逐次追尾181.py'), ref(Path(__file__)),
            ref(ROOT / 'work/181利益保護/候補181.json')]}
    (HERE / '独立人工結果.json').write_text(json.dumps(body, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(body, ensure_ascii=False))
    assert not mismatches


if __name__ == '__main__':
    main()
