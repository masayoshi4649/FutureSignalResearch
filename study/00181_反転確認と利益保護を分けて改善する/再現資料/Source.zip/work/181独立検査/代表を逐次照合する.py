"""181代表政策の全取得・全要求を、価格木を使わない独立逐次計算へ照合する。"""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import math
import statistics
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).parent
TARGET = ROOT / 'work/181反省を分解した改善'
sys.path.insert(0, str(ROOT / 'work/181共用接続'))
import 共用181 as C
from 逐次追尾181 import SequentialScene
from 人工を独立照合する import FIELDS


def read(path: Path) -> dict:
    """
    機能: 固定結果JSONを圧縮有無に従って読む。
    引数: path(Path)。
    返り値: dictはJSON値。
    """
    data = path.read_bytes()
    return json.loads(gzip.decompress(data) if path.suffix == '.gz' else data)


def safe(value: object) -> object:
    """
    機能: 非有限値だけを未知Noneへ直し、配列scalarをJSON比較可能にする。
    引数: value(object)。
    返り値: objectはJSON互換値。
    """
    if isinstance(value, dict):
        return {key: safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, np.ndarray)):
        return [safe(item) for item in value]
    if isinstance(value, (float, np.floating)):
        return float(value) if math.isfinite(float(value)) else None
    if isinstance(value, (np.integer, np.bool_)):
        return value.item()
    return value


def ref(path: Path) -> dict:
    """
    機能: 結果とSourceを保存指紋へ束縛する。
    引数: path(Path)。
    返り値: dictはpath/bytes/sha256。
    """
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size,
        'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def timeline(features: object, session: str, contract: str) -> dict:
    """
    機能: 根拠列を直接読み、独立に公表+1秒と15実分前BB比を作る。
    引数: features(FeatureDataset)、session/contract(str)。
    返り値: dictは技術時刻と4役割の配列。
    """
    columns = {name: i for i, name in enumerate(features.columns)}
    rows = [i for i, item in enumerate(features.q0_meta)
        if item['session'] == session and str(item['contract']) == str(contract)]
    clocks = np.asarray([features.q0_meta[i]['q0_time'] for i in rows], float)
    x = features.buy_X[rows]
    sigma = x[:, columns['bb15_sigma']]
    ratio = np.full(len(rows), np.nan)
    for i, time in enumerate(clocks):
        prior = [j for j in range(i) if clocks[j] <= time - 900]
        if prior:
            j = prior[-1]
            if time - 900 - clocks[j] <= 90 and np.isfinite(sigma[i]) and np.isfinite(sigma[j]) and sigma[j] > 0:
                ratio[i] = sigma[i] / sigma[j]
    return {'times': clocks + 1, 'atr_points': x[:, columns['m5_atr']],
        'ma_gap_atr': np.abs(x[:, columns['m5_gap_atr_to_side']]),
        'bb_width_ratio': ratio, 'momentum_atr': x[:, columns['m5_hist_delta_atr_to_side']]}


def independently_replay(loaded: dict, bundle: dict, cell: object) -> tuple:
    """
    機能: 一件だけの予約/保有状態を時系列で更新し、全q0要求と取得を再構成する。
    引数: loaded(dict)、bundle(dict)は封印入口、cell(callable)は独立金融計算。
    返り値: tuple[list,list]は取得recordsと全requests。既存engineを呼ばない。
    """
    context = loaded['context']; descriptors = loaded['captures']
    events = context.event_keys; births = bundle['birth']
    records = []; requests = []
    for scene in range(len(context.scenes)):
        pending = None; position = None; seen = set(); ever = False
        cut = float(context.deadlines[scene]); submit = float(context.close_submits[scene])
        def advance(now: tuple) -> None:
            """
            機能: 現在以前の取得・失効・返済だけを一件状態へ反映する。
            引数: now(tuple)は原行キー。未知返済はcutの秒末まで占有する。
            返り値: None。
            """
            nonlocal pending, position, ever
            if pending is not None and pending['finish'] <= now:
                value = pending; pending = None
                if value['status'] == 'filled' and value['record']['case'] not in seen:
                    record = value['record']; seen.add(record['case']); ever = True
                    outcome = cell(record['case'], record['side'], record['width'],
                        int(bundle['hi'][record['event']]) if record['origin'] == 0 else context.table.horizons.index('H60'))
                    exit_clock = outcome['exit_time'] if outcome['known'] else cut
                    assert exit_clock >= value['finish'][0]
                    position = {'finish': (float(exit_clock), math.inf, math.inf)}
                    records.append(record)
            if position is not None and position['finish'] <= now:
                position = None
        for event in np.flatnonzero(context.event_scenes == scene):
            event = int(event); now = tuple(events[event])
            if now[0] >= submit:
                continue
            advance(now)
            core = int(births['core'][event])
            if core:
                side = 0 if core == 1 else 1
                width = int(bundle['mw'][event] if births['branches'][event] == 0 else bundle['fw'][event])
                origin, tier = 0, 0
            elif now[0] >= context.scenes[scene]['start'] + 2700 and births['technical'][event] != 0 and not ever:
                side = 0 if births['technical'][event] == 1 else 1
                width, origin, tier = 200, 2, int(births['tier'][event])
            else:
                continue
            assert width > 0
            held = int(position is not None); reserved = int(pending is not None)
            reason = 'held' if held else 'pending' if reserved else None
            requests.append({'event': event, 'scene_index': scene, 'side': side, 'width': width,
                'origin': origin, 'tier': tier, 'at': list(now), 'held_total_before': held,
                'pending_total_before': reserved, 'accepted': reason is None, 'skip_reason': reason})
            if reason is not None:
                continue
            capture = descriptors[event]
            status = capture['status']
            finish = tuple(capture['fill_key'] if status == 'filled' else capture['finish_key'])
            if finish[0] >= submit:
                status = 'cancelled'; finish = (submit, math.inf, math.inf)
            record = {'event': event, 'case': int(capture['case']) if status == 'filled' else -1,
                'side': side, 'width': width, 'origin': origin, 'tier': tier}
            pending = {'status': status, 'finish': finish, 'record': record}
        advance((cut, math.inf, math.inf))
        assert pending is None and position is None
    records.sort(key=lambda row: (row['event'], row['origin']))
    return records, requests


def verify_pack(loaded: dict, pack: dict, bundle: dict, candidate: dict) -> dict:
    """
    機能: 一政策期間の全取得・追尾scalar・全要求・基本金融を独立照合する。
    引数: loaded/pack/bundle/candidate(dict)は共通期間、正本、封印純入口、出口設定。
    返り値: dictは検算件数。最小床・遅延・未知・単一保有を含む。
    """
    context = loaded['context']; scenes = {}; cache = {}; attributes = 0
    widths = {int(width): i for i, width in enumerate(context.table.widths)}
    specifications = context.table.evidence['条件']['horizons']
    def cell(case: int, side: int, width: int, hi: int) -> dict:
        """
        機能: 新金融表を読まず、必要な一セルを独立逐次ループへ結ぶ。
        引数: case/side/width/hi(int)は全体caseと評価軸。
        返り値: dictは独立金融と床の監査値。
        """
        key = (case, side, width, hi)
        if key not in cache:
            scene = int(context.case_scene[case])
            if scene not in scenes:
                session = context.sessions[scene]
                contract = loaded['case_index']['contract'][case]
                technical = timeline(context.features, session, contract)
                scenes[scene] = SequentialScene(C.load_records(loaded['leg'], session), context.scenes[scene]['end'], technical)
            entry = int(context.arrays['entry_index'][case])
            cache[key] = scenes[scene].evaluate(candidate, entry, side, width, specifications[hi])
        return cache[key]
    records, requests = independently_replay(loaded, bundle, cell)
    assert records == pack['engine']['records'], ('全取得', loaded['leg'], pack['id'])
    actual_requests = pack['engine']['requests']
    assert len(requests) == len(actual_requests)
    for expected, actual in zip(requests, actual_requests, strict=True):
        for key, value in expected.items():
            assert actual[key] == value, ('全要求', loaded['leg'], pack['id'], key, expected, actual)
            attributes += 1
    ledger = pack['ledger']; selected = pack['selection']
    assert len(records) == len(ledger['known'])
    mapping = {'known': 'known', 'label': 'label', 'status': 'status', 'forced': 'forced',
        'exit_time': 'exit_time', 'exit_price': 'exit_price', 'exit_index': 'exit_index', 'exit_line': 'exit_line', 'net': 'net'}
    for i, record in enumerate(records):
        case, side = record['case'], record['side']
        hi = int(selected['horizon_indices'][i])
        outcome = cell(case, side, record['width'], hi)
        assert outcome['床非緩和'] and outcome['最小床遵守'] and outcome['追尾遅延遵守']
        for target, source in mapping.items():
            expected = safe(outcome[source])
            assert ledger[target][i] == expected, ('金融', loaded['leg'], pack['id'], i, target, ledger[target][i], expected)
            attributes += 1
        for field in ('entry_time', 'entry_line', 'entry_index'):
            assert ledger[field][i] == context.arrays[field][case]
            attributes += 1
        assert ledger['entry_price'][i] == context.arrays['entry_price'][case, side]
        assert ledger['case_id'][i] == context.table.case_ids[case]
        assert ledger['width'][i] == record['width'] and ledger['origin'][i] == record['origin']
        if '追尾診断' in pack:
            actual = pack['追尾診断'][i]
            for field in FIELDS:
                assert actual[field] == safe(outcome[field]), ('追尾scalar', loaded['leg'], pack['id'], i, field, actual[field], safe(outcome[field]))
                attributes += 1
    for name, phases in [('DAY', (0,)), ('NIGHT', (1, 2)), ('PRE', (1,)), ('POST', (2,))]:
        indices = [i for i, phase in enumerate(ledger['phase']) if phase in phases]
        nets = [ledger['net'][i] for i in indices if ledger['known'][i]]
        group = pack['evidence']['financial']['session_groups_required'][name] if name in ('DAY', 'NIGHT') else pack['evidence']['financial']['phases_diagnostic'][name]
        trade = group['trades']
        assert trade['all_count'] == len(indices)
        assert trade['unknown_count'] == len(indices) - len(nets)
        assert trade['known_profit'] == sum(max(value, 0) for value in nets)
        assert trade['known_loss'] == -sum(min(value, 0) for value in nets)
        assert trade['known_net'] == sum(nets)
        if nets and len(nets) == len(indices):
            assert trade['net_median']['lower'] == trade['net_median']['upper'] == statistics.median(nets)
        attributes += 6
    return {'成功': True, 'leg': loaded['leg'], 'id': pack['id'], '取得': len(records),
        '全要求': len(requests), '独立セル数': len(cache), '照合属性': attributes,
        '実価格場数': len(scenes), '床非緩和/最低床/1秒遅延': True, '全取得と全要求同体': True}


def main() -> None:
    """
    機能: Root指定の固定代表だけを三期間で逐次照合し、結果票を保存する。
    引数: --ids(list[str])は固定候補ID。
    返り値: None。自然候補の順位付けや再選択はしない。
    """
    parser = argparse.ArgumentParser(); parser.add_argument('--ids', nargs='+', required=True)
    args = parser.parse_args()
    exits = {row['id']: row for row in read(ROOT / 'work/181利益保護/候補181.json')['候補']}
    checked = []; inputs = []
    for leg in C.LEGS:
        loaded = C.load_leg(leg)
        with np.load(TARGET / (leg + '_新入口.npz'), allow_pickle=False) as sealed:
            for identity in args.ids:
                entry, exit_id = identity.split('__', 1)
                bundle = {'birth': {key: sealed[entry + '__birth__' + key] for key in C.BIRTH_KEYS},
                    **{key: sealed[entry + '__' + key] for key in C.PARAM_KEYS}}
                path = TARGET / '期間別' / leg / (identity + '.json.gz')
                pack = read(path)
                assert pack['policy'] == {'id': identity, 'entry': entry, 'exit': exit_id}
                checked.append(verify_pack(loaded, pack, bundle, exits[exit_id]))
                inputs.append(ref(path))
                print(json.dumps(checked[-1], ensure_ascii=False), flush=True)
        del loaded
    paths = [Path(__file__), HERE / '逐次追尾181.py', HERE / '人工を独立照合する.py',
        ROOT / 'work/181利益保護/trail181.py', ROOT / 'work/181利益保護/候補181.json',
        ROOT / 'study/00181_反転確認と利益保護を分けて改善する/条件.json']
    body = {'成功': True, '順位の再選択なし': True, '全81場': True, '固定代表数': len(args.ids),
        '期間候補数': len(checked), '取得総数': sum(row['取得'] for row in checked),
        '全要求総数': sum(row['全要求'] for row in checked), '照合属性総数': sum(row['照合属性'] for row in checked),
        '不一致': 0, '検査': checked, '入力': inputs, 'Source': [ref(path) for path in paths]}
    target = HERE / '代表四案の全81逐次結果.json'
    target.write_text(json.dumps(body, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({key: value for key, value in body.items() if key not in ('検査', '入力', 'Source')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
