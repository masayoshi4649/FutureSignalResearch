"""価格木を使わず原行順の正常BBOループで181の一建玉を独立検査する。"""
import math
import numpy as np

COST = 10.77
TICK = 5.


class SequentialScene:
    """同一場の原行・正常BBO・欠測の位置を保持する独立参照器。"""

    def __init__(self, records: np.ndarray, scene_end: float, technical: dict | None = None):
        """
        機能: 既存48byte索引を原行順に読み、価格木に依存しない正常BBO/gapを記録する。
        引数: records(np.ndarray)、scene_end(float)、technical(dict|None)は公表+1秒の技術。
        返り値: None。金融Sourceや金融配列は参照しない。
        """
        self.rows = records
        self.times = records['time']
        self.cut = float(scene_end) - 900
        self.submit = self.cut - 60
        self.normal = np.asarray((records['normal'] == 1) & np.isfinite(records['bid']) &
            np.isfinite(records['ask']) & (records['bid'] > 0) & (records['bid'] < records['ask']))
        self.normals = np.flatnonzero(self.normal)
        price_gaps = []; bbo_gaps = []; previous = None
        for i, clock in enumerate(self.times):
            if i and clock - self.times[i - 1] > 300:
                price_gaps.append(i)
            if previous is not None and clock - self.times[previous] > 300:
                bbo_gaps.append((i, float(self.times[previous])))
            if self.normal[i]:
                previous = i
        self.price_gaps = price_gaps
        self.bbo_gaps = bbo_gaps
        self.technical = technical
        self.force = self.first_normal(self.submit + 1)
        if self.force >= 0 and self.times[self.force] > self.cut:
            self.force = -1

    def first_normal(self, time: float, after: int = -1) -> int:
        """
        機能: 正常BBOの時系列から指定秒以上かつafter後の最初の原行を選ぶ。
        引数: time(float)、after(int)は除外する原行位置。
        返り値: intは原行位置。存在しなければ-1。
        """
        candidates = self.normals[(self.normals > after) & (self.times[self.normals] >= time)]
        return int(candidates[0]) if len(candidates) else -1

    def gap(self, entry: int, observation: float) -> tuple:
        """
        機能: 取得後の価格/BBO gap300を原行順で切り分ける。
        引数: entry(int)、observation(float)は有効観測の終端時計。
        返り値: tuple[int,int]は排他的打切り位置とstatus。価格gapを同原行で優先。
        """
        end = len(self.rows); status = 0
        for i in self.price_gaps:
            if i > entry and self.times[i - 1] < observation:
                end, status = i, 10
                break
        for i, previous in self.bbo_gaps:
            if i > entry and previous < observation:
                if i < end:
                    end, status = i, 11
                break
        return end, status

    def terminal(self, entry: int, horizon: dict) -> dict:
        """
        機能: 旧179の通常期限猶予・事前強制返済・未知を独立に再構成する。
        引数: entry(int)、horizon(dict)はkindとstrict秒数。
        返り値: dictは返済原行、観測範囲、下限、未知status、時計。
        """
        session = horizon['kind'] == 'session'
        nominal = math.inf if session else float(self.times[entry] + horizon['seconds'])
        strict = self.first_normal(nominal, entry) if not session else -1
        if strict >= 0 and (self.times[strict] > nominal + 30 or self.times[strict] > self.cut):
            strict = -1
        options = []
        if strict >= 0:
            options.append((strict, 3))
        if self.force >= 0:
            options.append((self.force, 4))
        if options:
            selected, kind = sorted(options, key=lambda row: (row[0], -row[1]))[0]
        else:
            selected, kind = -1, 0
        selected_time = float(self.times[selected]) if selected >= 0 else self.cut
        expired = not session and selected_time > nominal + 30
        if expired:
            selected, kind = -1, 0
        observation = min(nominal, selected_time if selected >= 0 else self.cut)
        gap, gap_kind = self.gap(entry, observation)
        stop = int(np.searchsorted(self.times, min(nominal, self.cut), side='right'))
        if selected >= 0:
            stop = min(stop, selected + 1)
        stop = max(entry + 1, min(stop, gap))
        valid = selected >= 0 and selected < gap
        if valid:
            status = kind
        elif gap < int(np.searchsorted(self.times, self.cut, side='right')) and gap <= int(np.searchsorted(self.times, nominal + 30, side='right')):
            status = gap_kind
        elif self.times[-1] < min(nominal, self.cut):
            status = 14
        elif expired or not session and nominal + 30 < self.cut:
            status = 12
        else:
            status = 13
        last = self.normals[(self.normals >= entry) & (self.normals < stop)]
        lower = float(self.times[last[-1]]) if len(last) else float(self.times[entry])
        return {'exit': selected if valid else -1, 'status': status, 'stop': stop,
            'lower': lower, 'exit_deadline': min(nominal + 30, self.cut),
            'nominal_deadline': self.cut if session else nominal}

    def width(self, candidate: dict, time: float, sign: int) -> tuple:
        """
        機能: 当該正常行までに公表された値だけから保護幅を独立計算する。
        引数: candidate(dict)、time(float)、sign(int)は買+1/売-1。
        返り値: tuple[float,bool]は保護幅と技術縮小の有無。古い/未知は固定代替。
        """
        fallback = float(candidate['trail_pt'])
        tech = self.technical
        if candidate['mode'] == 'fixed' or tech is None:
            return fallback, False
        valid = np.flatnonzero(np.asarray(tech['times']) <= time)
        if not len(valid):
            return fallback, False
        i = int(valid[-1])
        if time - tech['times'][i] > 180:
            return fallback, False
        atr = float(tech['atr_points'][i])
        if not math.isfinite(atr) or atr <= 0:
            return fallback, False
        width = max(float(candidate['minimum_pt']), min(float(candidate['maximum_pt']), float(candidate['atr_multiplier']) * atr))
        tight = False
        if candidate['mode'] == 'technical':
            ma = float(tech['ma_gap_atr'][i]); bb = float(tech['bb_width_ratio'][i]); momentum = float(tech['momentum_atr'][i])
            if all(math.isfinite(value) for value in (ma, bb, momentum)) and ma >= 0 and bb >= 0:
                tight = bb <= candidate['bb_width_ratio_max'] and (ma <= candidate['ma_gap_atr_max'] or sign * momentum <= candidate['momentum_atr_max'])
                if tight:
                    width = min(width, float(candidate['tight_pt']))
        return width, bool(tight)

    def evaluate(self, candidate: dict, entry: int, side: int, width: float, horizon: dict) -> dict:
        """
        機能: 全正常BBOを順に調べ、IFD・期限・追尾接触と遅延約定を独立検証する。
        引数: candidate(dict)、entry/side(int)、width(float)、horizon(dict)。
        返り値: dictは金融・先着・起動/接触/床と、非緩和/最小床の検査。
        """
        value = {'label': 2, 'known': False, 'net': math.nan, 'net0': math.nan, 'exit_time': math.nan,
            'exit_price': math.nan, 'exit_index': -1, 'exit_line': -1, 'status': 14, 'forced': False,
            'known_at': math.nan, 'holding_confirmed_until': math.nan, 'exit_deadline': math.nan,
            'nominal_deadline': math.nan, 'exit_quote_time': math.nan, 'points': math.nan,
            'direction': 0, 'trail_activated': False, 'trail_triggered': False,
            'trail_activation_time': math.nan, 'trail_activation_line': -1,
            'trail_trigger_time': math.nan, 'trail_trigger_line': -1, 'trail_trigger_price': math.nan,
            'trail_floor_points': math.nan, 'trail_floor_price': math.nan, 'trail_floor_net': math.nan,
            'trail_peak_points': math.nan, 'trail_fill_minus_floor_points': math.nan,
            'first_observed_label': 2, 'first_observed_time': math.nan,
            '床非緩和': True, '最小床遵守': True, '追尾遅延遵守': True}
        assert side in (0, 1) and self.normal[entry]
        if self.times[entry] >= self.submit:
            value['status'] = 15
            return value
        sign = 1 if side == 0 else -1
        entry_price = float(self.rows['ask' if side == 0 else 'bid'][entry])
        column = 'bid' if side == 0 else 'ask'
        term = self.terminal(entry, horizon)
        value.update(holding_confirmed_until=term['lower'], exit_deadline=term['exit_deadline'], nominal_deadline=term['nominal_deadline'])
        stop = term['stop']
        fixed = -1
        first_hit = -1
        for i in range(entry + 1, stop):
            if not self.normal[i]:
                continue
            points = sign * (float(self.rows[column][i]) - entry_price)
            if first_hit < 0 and (points >= width or points <= -width):
                first_hit = i
            if points <= -width or candidate['keep_take_profit'] and points >= width:
                fixed = i
                break
        choices = [i for i in (fixed, term['exit']) if i >= 0]
        hard = min(choices) if choices else -1
        hard_status = (1 if sign * (float(self.rows[column][fixed]) - entry_price) >= width else 2) if fixed >= 0 and fixed == hard else term['status']
        exit_index, status = hard, hard_status
        activated = False; peak = -math.inf; floor = -math.inf
        if candidate['mode'] != 'off':
            gap, _ = self.gap(entry, self.cut)
            for i in range(entry + 1, stop):
                if hard >= 0 and i >= hard:
                    break
                if not self.normal[i]:
                    continue
                points = sign * (float(self.rows[column][i]) - entry_price)
                if not activated:
                    if points < candidate['activation_net_pt'] + COST:
                        continue
                    activated = True
                    value.update(trail_activated=True, trail_activation_time=float(self.times[i]),
                        trail_activation_line=int(self.rows['source_line'][i]))
                touched = points <= floor
                if not touched:
                    peak = max(peak, points)
                    distance, _ = self.width(candidate, float(self.times[i]), sign)
                    proposed = math.ceil(max(COST, peak - distance) / TICK - 1e-12) * TICK
                    previous = floor
                    floor = max(floor, proposed)
                    value['床非緩和'] &= floor >= previous
                    value['最小床遵守'] &= floor >= COST
                    touched = points <= floor
                value.update(trail_floor_points=float(floor), trail_floor_price=entry_price + sign * floor,
                    trail_floor_net=floor * 100 - 1077, trail_peak_points=peak)
                if touched:
                    value.update(trail_triggered=True, trail_trigger_time=float(self.times[i]),
                        trail_trigger_line=int(self.rows['source_line'][i]), trail_trigger_price=float(self.rows[column][i]))
                    fill = self.first_normal(float(self.times[i]) + 1, i)
                    valid = fill >= 0 and fill < gap and self.times[fill] <= min(self.cut, term['exit_deadline'])
                    if hard >= 0 and (not valid or hard <= fill):
                        exit_index, status = hard, hard_status
                    elif valid:
                        exit_index, status = fill, 5
                        value['追尾遅延遵守'] = self.times[fill] >= self.times[i] + 1
                    else:
                        exit_index, status = -1, term['status']
                    break
        value['status'] = status
        if exit_index >= 0:
            price = float(self.rows[column][exit_index])
            points = sign * (price - entry_price)
            clock = float(self.times[exit_index])
            value.update(known=True, net=points * 100 - 1077, net0=points * 100 - 77,
                exit_time=clock, exit_price=price, exit_index=exit_index,
                exit_line=int(self.rows['source_line'][exit_index]), forced=status == 4,
                known_at=clock, holding_confirmed_until=clock, exit_quote_time=clock, points=points)
            if status == 5:
                value['trail_fill_minus_floor_points'] = points - value['trail_floor_points']
        limit = min(stop, exit_index + 1) if exit_index >= 0 else stop
        observed = -1
        for i in range(entry + 1, limit):
            if self.normal[i]:
                points = sign * (float(self.rows[column][i]) - entry_price)
                if abs(points) >= width:
                    observed = i
                    break
        if observed >= 0:
            points = sign * (float(self.rows[column][observed]) - entry_price)
            label = 1 if points >= width else -1
            value['first_observed_time'] = float(self.times[observed])
        else:
            label = 0 if exit_index >= 0 else 2
        value.update(label=label, direction=label if label in (-1, 1) else 0, first_observed_label=label)
        return value
