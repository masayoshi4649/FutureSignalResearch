"""必要時配列と技術公表時計を、自然金融を使わず独立人工入力で確認する。"""
from pathlib import Path
from types import SimpleNamespace
import hashlib
import importlib.util
import json
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
TARGET = ROOT / 'work/181反省を分解した改善'


def module(name: str) -> object:
    """
    機能: Rootの検査対象moduleを独自名で読み込む。
    引数: name(str)は拡張子なしのファイル名。
    返り値: objectは読込済みmodule。
    """
    path = TARGET / (name + '.py')
    spec = importlib.util.spec_from_file_location('independent_' + name, path)
    result = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = result
    spec.loader.exec_module(result)
    return result


def main() -> None:
    """
    機能: 実配列参照、公表+1秒、15実分BB比、限月混在と欠測を人工確認する。
    引数: なし。
    返り値: None。独立接続人工結果JSONを保存する。
    """
    array_module = module('必要時配列181')
    values = np.arange(3 * 2 * 4 * 5).reshape((3, 2, 4, 5))
    calls = []
    def lookup(key: tuple) -> dict:
        """
        機能: 人工実配列の一セルを返し、未要求セルを計算しないことも記録する。
        引数: key(tuple[int,int,int,int])。
        返り値: dictは検査値。
        """
        calls.append(key)
        return {'v': values[key]}
    lazy = array_module.CellArray('v', values.shape, values.dtype, lookup)
    inputs = [(2, 1, 3, 4), (np.array([0, 2]), 1, np.array([3, 1]), 0),
        (np.array([[0], [2]]), 0, np.array([[0, 1, 3]]), np.array([[4, 2, 0]])),
        (np.array([], int), np.array([], int), np.array([], int), np.array([], int))]
    cells = 0
    for key in inputs:
        expected = values[key]
        actual = lazy[key]
        np.testing.assert_array_equal(actual, expected)
        cells += int(np.size(expected))
    assert len(calls) == cells

    tech_module = module('技術時計181')
    names = ['bb15_sigma', 'm5_atr', 'm5_gap_atr_to_side', 'm5_hist_delta_atr_to_side']
    clocks = [1000, 1090, 1900, 1990, 2080, 2181]
    data = SimpleNamespace(columns=names,
        q0_meta=[{'session': '人工_Day', 'contract': 'A', 'q0_time': time} for time in clocks],
        buy_X=np.asarray([[100, 10, -.1, 1], [50, 20, -.2, 2], [80, 30, -.3, 3],
            [40, 40, -.4, 4], [20, 50, -.5, 5], [10, 60, -.6, 6]], float))
    actual = tech_module.build(data, '人工_Day', 'A')
    np.testing.assert_array_equal(actual['times'], np.asarray(clocks) + 1)
    np.testing.assert_allclose(actual['bb_width_ratio'], [np.nan, np.nan, .8, .8, .4, np.nan], equal_nan=True)
    np.testing.assert_allclose(actual['ma_gap_atr'], [.1, .2, .3, .4, .5, .6])
    np.testing.assert_array_equal(actual['atr_points'], [10, 20, 30, 40, 50, 60])
    # ----------------------------------------
    # 公表時計を価格側から検索したとき、元q0の同秒には新値がまだ存在しない。
    for i, clock in enumerate(clocks):
        published = np.flatnonzero(actual['times'] <= clock)
        assert not len(published) or int(published[-1]) < i
        published = np.flatnonzero(actual['times'] <= clock + 1)
        assert int(published[-1]) == i
    mixed = SimpleNamespace(columns=names,
        q0_meta=[{'session': '人工_Day', 'contract': contract, 'q0_time': time}
            for contract, time in [('A', 1000), ('B', 1900)]],
        buy_X=np.asarray([[100, 10, .1, 1], [80, 20, .2, 2]], float))
    assert np.isnan(tech_module.build(mixed, '人工_Day')['bb_width_ratio']).all()
    assert tech_module.build(mixed, '人工_Day', 'A')['times'].tolist() == [1001]
    assert tech_module.build(mixed, '人工_Day', 'B')['times'].tolist() == [1901]
    sources = [TARGET / (name + '.py') for name in ('必要時配列181', '技術時計181', '集計181')]
    sources.append(Path(__file__))
    body = {'成功': True, '自然金融未入力': True, '配列要求セル数': cells,
        '検査': ['scalar/advanced2次元broadcast/空集合', '未要求セルを計算しない', 'q0+1秒反映',
            'BBσの15実分前比', '参照遅れ90秒は許可し91秒以上は未知', '異なる限月の値を混用しない'],
        '集計Sourceの読取レビュー': ['M.replayで単一建玉の後続要求を再生', '0取引場を対象場へ保持',
            '未知をNoneのまま台帳結合', '合算後に中央値/実保有和集合/集中を再計算', '前48/後25/追加7/本日1を別保存'],
        'Source': [{'path': p.relative_to(ROOT).as_posix(), 'bytes': p.stat().st_size,
            'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in sources]}
    (HERE / '独立接続人工結果.json').write_text(json.dumps(body, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(body, ensure_ascii=False))


if __name__ == '__main__':
    main()
