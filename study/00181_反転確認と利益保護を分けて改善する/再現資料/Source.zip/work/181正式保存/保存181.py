"""181のSource差分・純封印・短表・固定五候補を、180までの正式資料へ薄く接続する。"""
from pathlib import Path
from datetime import datetime, timezone
import gzip
import json
import os
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).parent
sys.path.insert(0, str(ROOT / 'work/178正式保存'))
import 保存178 as OLD
P = OLD.P
TRIAL = ROOT / 'study/00181_反転確認と利益保護を分けて改善する'
DEST = TRIAL / '再現資料'
PARENT = ROOT / 'study/00180_固定179入口を十一月十六日デイへ適用する/再現資料'
STAGE = ROOT / 'work/181反省を分解した改善'
FOLDERS = ('181共用接続', '181入口改善', '181利益保護', '181反省を分解した改善', '181独立検査')


def inherit() -> tuple:
    """
    機能: 親180から旧Source全連鎖を指紋確認し、必要旧小入力だけ元byte継承する。
    引数: なし。
    返り値: tuple[dict,dict,dict]はSource連鎖、必要小入力参照、元byte。
    """
    index = P.read(PARENT / '保存索引.json')
    assert index['正式保存'] and index['成功']
    source = {'archive': index['Source']['archive'], 'index': P.fingerprint(PARENT / '保存索引.json'),
        'members': index['Source']['members'], '親Source継承元': index['Source継承元'],
        '復元順': '176全Source→177→178→179→180→181の差分。各正式ZIPの元byteを使う。'}
    OLD.verify_source(source)
    canonical = PARENT / '本日結果と証拠.zip'
    assert P.fingerprint(canonical) == index['正本']['archive']
    names = ['work/174参加と両中央値の再探索/旧73jointの固定選択.json',
        'work/179保有参加の探索/旧73の固定選択.json',
        'study/00179_保有時間参加率と終了前決済で入口を広げる/条件.json',
        'study/00180_固定179入口を十一月十六日デイへ適用する/条件.json']
    expected = {row['path']: row for row in index['正本']['members']}
    contents = {}
    with zipfile.ZipFile(canonical) as archive:
        assert archive.testzip() is None
        for name in names:
            body = archive.read(name)
            assert P.member_reference(name, body) == expected[name]
            assert (ROOT / name).read_bytes() == body
            contents[name] = body
    reference = {'archive': P.fingerprint(canonical), 'index': P.fingerprint(PARENT / '保存索引.json'),
        'members': [expected[name] for name in names], '元byte継承': True}
    return source, reference, contents


def collect() -> tuple:
    """
    機能: 181自身のSourceと小成果物だけを収集し、528期間中間packを省略する。
    引数: なし。
    返り値: tuple[dict,dict,list,list]はSource byte、正本byte、省略票、可逆圧縮票。
    """
    sources = {}; results = {}; omitted = []; compressed = []
    for folder in FOLDERS:
        directory = ROOT / 'work' / folder
        for current, dirs, files in os.walk(directory):
            dirs[:] = [name for name in dirs if name not in ('__pycache__', 'node_modules', '期間別')]
            for name in files:
                path = Path(current) / name
                relative = path.relative_to(ROOT).as_posix()
                if path.suffix == '.py':
                    sources[relative] = path.read_bytes()
                elif path.suffix in ('.json', '.gz', '.npz', '.md'):
                    body = path.read_bytes()
                    if len(body) > 10 * 1024 * 1024 and path.suffix == '.json':
                        packed = gzip.compress(body, mtime=0)
                        assert gzip.decompress(packed) == body
                        member = relative + '.gz'
                        results[member] = packed
                        compressed.append({'元ファイル': P.fingerprint(path), '保存member': P.member_reference(member, packed),
                            '復元': 'gzipを解凍して末尾の.gzを外す。解凍後の元byte/SHAは元ファイルに一致。'})
                    else:
                        results[relative] = body
    for path in sorted((STAGE / '期間別').rglob('*.json.gz')):
        omitted.append({'file': P.fingerprint(path), '理由': '全528候補期間packは再生成中間。固定5候補の全81台帳/期間値と176短表、Source/F0/純封印を保存する。'})
    sources[Path(__file__).relative_to(ROOT).as_posix()] = Path(__file__).read_bytes()
    results[(TRIAL / '条件.json').relative_to(ROOT).as_posix()] = (TRIAL / '条件.json').read_bytes()
    return sources, results, omitted, compressed


def gates() -> dict:
    """
    機能: 181の金融前条件・純封印・固定結果・独立票を保存直前に確認する。
    引数: なし。
    返り値: dictは固定指紋と確認結果。市場の成績順位を選び直さない。
    """
    fixed = P.read(TRIAL / '条件.json')
    assert fixed['試行'] == 181 and fixed['入口']['candidate_count'] == 16
    for record in fixed['Source']:
        assert P.fingerprint(ROOT / record['path']) == record
    pure = P.read(STAGE / '全純入口の封印.json')
    assert pure['金融前'] and len(pure['入力']) == 3
    for item in pure['入力']:
        assert P.fingerprint(ROOT / item['path']) == item
    compact = json.loads(gzip.decompress((STAGE / '全176組の比較.json.gz').read_bytes()))
    selected = json.loads(gzip.decompress((STAGE / '保存する五候補.json.gz').read_bytes()))
    assert len(compact['rows']) == 176 and compact['成功']
    expected = {'E181_00__C0_IFD', 'E181_09__C0_IFD', 'E181_10__C0_IFD',
        'E181_00__F150_W125_OPEN', 'E181_10__F150_W125_OPEN'}
    assert {row['id'] for row in selected['rows']} == expected
    assert all(len(row['sessions']) == 81 and len({scene['scene'] for scene in row['sessions']}) == 81 for row in selected['rows'])
    paths = [ROOT / 'work/181共用接続/基準二案の全81場同体確認.json',
        ROOT / 'work/181入口改善/人工確認181.json', ROOT / 'work/181入口改善/人工確認181_v2.json',
        ROOT / 'work/181利益保護/人工結果.json', ROOT / 'work/181利益保護/OFF自然同体.json',
        ROOT / 'work/181利益保護/自然比較の独立結果.json',
        ROOT / 'work/181独立検査/独立人工結果.json', ROOT / 'work/181独立検査/独立接続人工結果.json',
        ROOT / 'work/181独立検査/代表四案の全81逐次結果.json']
    for path in paths:
        assert P.read(path)['成功']
    natural = P.read(paths[-1])
    assert natural['取得総数'] == 1111 and natural['全要求総数'] == 3796 and natural['不一致'] == 0
    shared = [ROOT / 'inputs/00163_任意幅の共用価格索引/価格索引/manifest.json',
        ROOT / 'inputs/00167_追加七場の入口と共用価格索引/原板数値索引/manifest.json',
        ROOT / 'inputs/00180_20261116デイの固定適用入力/保存索引.json',
        ROOT / 'inputs/00180_20261116デイの固定適用入力/原板数値索引/manifest.json',
        ROOT / 'inputs/00179_終了前決済の共用数値表/旧73_overlay179.json',
        ROOT / 'inputs/00179_終了前決済の共用数値表/追加7_overlay179.json']
    return {'成功': True, '候補数': 176, '保存固定候補': sorted(expected), '全81場': True,
        '自然独立検査': {'取得': 1111, '要求': 3796, '項目': 73077, '不一致': 0},
        '金融前固定': P.fingerprint(TRIAL / '条件.json'), '純封印': P.fingerprint(STAGE / '全純入口の封印.json'),
        '固定結果': P.fingerprint(STAGE / '保存する五候補.json.gz'),
        '独立票': [P.fingerprint(path) for path in paths], '共用入力参照': [P.fingerprint(path) for path in shared]}


def main() -> None:
    """
    機能: Source差分と比較正本を一度だけ保存し、全memberのCRC/SHAを再確認する。
    引数: なし。
    返り値: None。Source.zip/比較正本.zip/保存索引.jsonを新規作成する。
    """
    parent, small_ref, small = inherit()
    gate = gates()
    sources, results, omitted, compressed = collect()
    assert len(omitted) == 528
    assert not set(results) & set(small)
    results.update(small)
    DEST.mkdir(parents=True, exist_ok=True)
    source = P.write_archive(DEST / 'Source.zip', sources)
    canonical = P.write_archive(DEST / '比較正本.zip', results)
    assert gates() == gate
    index = {'成功': True, '正式保存': True, '保存UTC': datetime.now(timezone.utc).isoformat(),
        'Source': source, '正本': canonical, 'Source継承元': parent, '旧小入力の選択継承': small_ref,
        '完了gate': gate, '可逆圧縮保存': compressed, '省略中間指紋': omitted,
        '依存関係': {'Python': '3.14.3', 'NumPy': '2.5.4', 'tzdata': '2026.6'},
        '再現': '179/180までの正式Sourceと正本を復元し本Source差分と比較正本を重ねる。恒久inputsは共用し、実行181.pyで純出生封印後に全期間を再生、比較を集約する.pyで176短表を再計算する。省略した期間別packはその再生成物。',
        '保存方針': '正式Markdownは通常ファイルで参照。SourceZIPはPythonだけ。原板/価格索引/旧Source/全528期間packを複製しない。固定5案/全176短表/純封印/検査を保持。',
        '注意': '全81場既使用、全80/前48選択と本日/全81診断を区別。検算は共用索引による別算術であり全原JSONLの独立再走査ではない。'}
    destination = DEST / '保存索引.json'
    assert not destination.exists()
    destination.write_text(json.dumps(index, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, 'Source': source['archive'], 'Source数': len(source['members']),
        '正本': canonical['archive'], '正本数': len(canonical['members']), '索引': P.fingerprint(destination)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
