"""純候補を固定した後、三期間の方向配列と非金融ファネルだけを保存する。"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import sys
import numpy as np
import rules181 as R

HERE = Path(__file__).resolve().parent
COMMON = R.ROOT / 'work/181共用接続/共用181.py'


def ref(path: Path) -> dict:
    """
    機能: Source・辞書・純出生の物理指紋を記録する。
    引数: path(Path)。
    返り値: dictは相対path、bytes、sha256。
    """
    return {'path': path.relative_to(R.ROOT).as_posix(), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def save(path: Path, body: dict) -> None:
    """
    機能: 非金融正本を新規UTF-8 JSONとして保存する。
    引数: path(Path)、body(dict)。
    返り値: None。既存値を上書きしない。
    """
    assert not path.exists(), path
    path.write_text(json.dumps(body, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')


def role_flags(arrays: list, structure: np.ndarray) -> dict:
    """
    機能: BOの確認待ちがどの役割で止まったかを当時特徴だけで数える。
    引数: arrays(list[dict])は側別列、structure(np.ndarray[bool,2,N])。
    返り値: dict[str,np.ndarray[bool,2,N]]は既知かつ成立した役割。
    """
    output = {key: [] for key in ('momentum', 'short_direction', 'structure', 'live',
        'volume', 'position', 'rsi', 'range', 'quality')}
    for side in (0, 1):
        x = arrays[side]
        def known(*names: str) -> np.ndarray:
            """
            機能: 一役割の必要列が全既知のmaskを作る。
            引数: names(tuple[str])。
            返り値: np.ndarray[bool,N]。
            """
            return np.logical_and.reduce([np.isfinite(x[name]) for name in names])
        output['momentum'].append(known('m5_hist_delta_to_side', 'm5_rsi_delta_to_side')
            & (x['m5_hist_delta_to_side'] >= 0) & (x['m5_rsi_delta_to_side'] > 0))
        output['short_direction'].append(known('m5_ema21_delta_to_side', 'm5_di_difference_to_side')
            & ((x['m5_ema21_delta_to_side'] > 0) | (x['m5_di_difference_to_side'] > 0)))
        output['structure'].append(structure[side])
        output['live'].append(known('m1_body_ratio_to_side', 'm1_close_delta_atr5_to_side',
            'm1_body_reclaim_atr5_to_side', 'q0_last_minus_m1_close_atr5_to_side')
            & (x['m1_body_ratio_to_side'] > 0) & (x['m1_close_delta_atr5_to_side'] >= 0)
            & (x['m1_body_reclaim_atr5_to_side']+x['q0_last_minus_m1_close_atr5_to_side'] > 0))
        output['volume'].append(known('m1_volume_relative_prior3') & (x['m1_volume_relative_prior3'] >= .75))
        output['position'].append(known('q0_entry_minus_ema8_atr5_to_side')
            & (x['q0_entry_minus_ema8_atr5_to_side'] >= -.25) & (x['q0_entry_minus_ema8_atr5_to_side'] <= .75))
        output['rsi'].append(known('m5_rsi_center_to_side', 'm5_rsi_delta_to_side')
            & (x['m5_rsi_center_to_side'] >= -10) & (x['m5_rsi_center_to_side'] <= 20)
            & (np.abs(x['m5_rsi_delta_to_side']) <= 8))
        output['range'].append(known('m1_tr_atr5_ratio', 'm5_tr_previous_atr_ratio')
            & (x['m1_tr_atr5_ratio'] <= 1.5) & (x['m5_tr_previous_atr_ratio'] <= 2))
        output['quality'].append(known('q0_spread_points', 'q0_last_minus_m1_close_atr5_to_side')
            & (x['q0_spread_points'] > 0) & (x['q0_spread_points'] <= 20)
            & (np.abs(x['q0_last_minus_m1_close_atr5_to_side']) <= 1))
    return {key: np.asarray(value, dtype=bool) for key, value in output.items()}


def main() -> None:
    """
    機能: 候補とSourceを固定し、旧73・追加7・本日1の純方向を一度だけ生成する。
    引数: なし。
    返り値: None。自然金融の読込・順位・閾値変更を行わない。
    """
    dictionary = HERE / '候補辞書181.json'
    if not dictionary.exists():
        R.write_catalog(dictionary)
    paths = [HERE/'rules181.py', HERE/'人工検査.py', HERE/'人工確認181.json',
        HERE/'README.md', Path(__file__), dictionary]
    source = [ref(path) for path in paths]
    fixed_path = HERE/'純出生前の固定181.json'
    if not fixed_path.exists():
        save(fixed_path, {'成功': True, 'UTC': datetime.now(timezone.utc).isoformat(),
            '金融未入力': True, '候補': [r['id'] for r in R.catalog()['rules']], 'Source': source})
    else:
        fixed = json.loads(fixed_path.read_text(encoding='utf-8'))
        assert fixed['Source'] == source
    assert json.loads(dictionary.read_text(encoding='utf-8'))['source'] == ref(HERE/'rules181.py')
    spec = importlib.util.spec_from_file_location('common181_pure_entry', COMMON)
    common = importlib.util.module_from_spec(spec); sys.modules[spec.name] = common
    spec.loader.exec_module(common)
    all_summaries = []
    for leg in ('旧73', '追加7', '本日1'):
        pure = common.load_pure_leg(leg)
        assert pure['proof']['金融未入力'] and not pure['context'].financial_attached
        features = pure['features']; base = pure['baselines']['全期_J035']
        output = R.build(features, base)
        matrix, _, times, phases, reset = R._prepare(features)
        roles = role_flags(matrix, R._structures(matrix, times, reset))
        scenes = pure['event_scene']; day = phases == 0
        values = {'phases': phases, 'event_scene': scenes}
        rows = []
        for identity, bundle in output['bundles'].items():
            values.update({identity+'__'+k: v for k, v in bundle['birth'].items()})
            values.update({identity+'__'+k: bundle[k] for k in ('mw', 'fw', 'hi', 'added')})
            d = output['diagnostics'][identity]
            values.update({identity+'__diag_'+k: v for k, v in d.items()})
            if identity == 'E181_00':
                assert all(np.array_equal(bundle['birth'][k], base['birth'][k]) for k in base['birth'])
                assert all(np.array_equal(bundle[k], base[k]) for k in ('mw', 'fw', 'hi', 'added'))
            pending = d['eligible_pending']; pos = np.flatnonzero(pending)
            route_pass = {key: int(flags[d['pending_side'][pos], pos].sum()) for key, flags in roles.items()}
            all_roles = np.logical_and.reduce(list(roles.values()))
            ready = output['common_diagnostics']['bo_ready']
            assert np.array_equal(all_roles, ready)
            cum = np.ones(len(pos), bool); sequence = []
            for key, flags in roles.items():
                cum &= flags[d['pending_side'][pos], pos]
                sequence.append({'役割': key, '累積成立q0': int(cum.sum())})
            core = bundle['birth']['core']
            rows.append({'id': identity, 'DAY主成立q0': int(np.count_nonzero(core[day])),
                'DAY主成立場': len(set(scenes[day & (core != 0)].tolist())),
                '旧BOセットアップq0': int(d['bo_setup'].sum()), '旧MPセットアップq0': int(d['mp_setup'].sum()),
                '旧MP拒否q0': int((d['rejected'] & d['mp_setup']).sum()),
                '確認待ちで発火可能な後続q0': int(pending.sum()),
                '確認BO発火q0': int(d['bo_confirmed'].sum()),
                '確認BO発火場': len(set(scenes[d['bo_confirmed']].tolist())),
                '待ち後続q0の役割別成立': route_pass, '待ち後続q0の逐次ファネル': sequence})
        destination = HERE / f'{leg}_純出生181.npz'
        assert not destination.exists(), destination
        np.savez_compressed(destination, **values)
        summary = {'成功': True, 'leg': leg, '金融未入力': True, '候補辞書': ref(dictionary),
            '純出生前固定': ref(fixed_path), '共用Source': ref(COMMON), '純入力': pure['proof'],
            '純出生': ref(destination), '候補': rows,
            '注意': '成立q0・場数は非金融の要求候補であり取得数・利益・実保有時間ではない。'}
        save(destination.with_suffix('.json'), summary)
        all_summaries.append(summary)
        print(json.dumps({'純出生': leg, 'q0': len(phases),
            '件数': [{k: r[k] for k in ('id', 'DAY主成立q0', '確認BO発火q0', '旧MP拒否q0')} for r in rows]}, ensure_ascii=False), flush=True)
    assert source == [ref(path) for path in paths]
    save(HERE/'非金融ファネル181.json', {'成功': True, '金融未入力': True, '期間': all_summaries,
        'Source不変': True, '追加の閾値変更': False})


if __name__ == '__main__':
    main()
