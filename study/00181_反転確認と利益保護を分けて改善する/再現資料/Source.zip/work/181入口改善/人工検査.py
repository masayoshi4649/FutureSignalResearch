"""181純入口の鏡像・prefix・将来改変・未知・gapと状態期限を人工入力で検査する。"""
from pathlib import Path
from types import SimpleNamespace
import hashlib
import json
import numpy as np
import rules181 as R

HERE = Path(__file__).resolve().parent


def fixture(n: int = 40, ready_at: int = 1) -> tuple:
    """
    機能: 自然値を含まないBOセットアップと後続回復の対称入力を作る。
    引数: n(int)はq0数、ready_at(int)は回復が見える時点。
    返り値: tupleはFeatureDataset互換と179互換の出生bundle。
    """
    columns = list(R.RAW_COLUMNS); index = {name: j for j, name in enumerate(columns)}
    buy = np.zeros((n, len(columns)), np.float64)
    defaults = {'m5_hist_delta_to_side': 1, 'm5_rsi_delta_to_side': 1,
        'm5_rsi_center_to_side': 0, 'm5_ema21_delta_to_side': 1,
        'm5_di_difference_to_side': 1, 'm1_body_ratio_to_side': .5,
        'm1_body_reclaim_atr5_to_side': .2, 'm1_close_delta_atr5_to_side': .1,
        'q0_last_minus_m1_close_atr5_to_side': .1,
        'q0_entry_minus_ema8_atr5_to_side': .25,
        'q0_last_minus_prior3_forward_edge_atr5_to_side': .25,
        'm1_volume_relative_prior3': 1, 'm1_tr_atr5_ratio': 1,
        'm5_tr_previous_atr_ratio': 1, 'q0_spread_points': 10}
    for name, value in defaults.items():
        buy[:, index[name]] = value
    for name in ('m5_hist_delta_to_side', 'm5_rsi_delta_to_side',
                 'm5_ema21_delta_to_side', 'm5_di_difference_to_side',
                 'q0_entry_minus_ema8_atr5_to_side',
                 'q0_last_minus_prior3_forward_edge_atr5_to_side'):
        buy[:ready_at, index[name]] = -.25
    sell = buy.copy()
    for name, j in index.items():
        if name.endswith('_to_side'):
            sell[:, j] *= -1
    meta = [{'session': '人工_Day', 'session_index': 0, 'contract': '人工限月',
        'q0_time': 100000+60*i, 'q0_line': i+1, 'q0_index': i} for i in range(n)]
    feature = SimpleNamespace(buy_X=buy, sell_X=sell, columns=columns, q0_meta=meta,
        q0_timeband=np.zeros(n, np.int8))
    bundle = {'birth': {'core': np.zeros(n, np.int8), 'branches': np.full(n, -1, np.int8),
        'technical': np.ones(n, np.int8), 'tier': np.ones(n, np.int8)},
        'mw': np.full(n, 200, np.int16), 'fw': np.full(n, 200, np.int16),
        'hi': np.full(n, 1, np.int8), 'added': np.zeros(n, bool)}
    if n:
        bundle['birth']['core'][0] = 1; bundle['birth']['branches'][0] = 0
        bundle['mw'][0] = bundle['fw'][0] = 350
    return feature, bundle


def sliced(features: object, bundle: dict, stop: int) -> tuple:
    """
    機能: 入力のprefixだけを複写して先読み検査に渡す。
    引数: features(object)、bundle(dict)、stop(int)。
    返り値: tupleはprefix特徴と出生。
    """
    result = SimpleNamespace(buy_X=features.buy_X[:stop].copy(), sell_X=features.sell_X[:stop].copy(),
        columns=features.columns, q0_meta=[dict(q) for q in features.q0_meta[:stop]],
        q0_timeband=features.q0_timeband[:stop].copy())
    born = {'birth': {k: v[:stop].copy() for k, v in bundle['birth'].items()},
        **{k: bundle[k][:stop].copy() for k in ('mw', 'fw', 'hi', 'added')}}
    return result, born


def flatten(bundle: dict) -> dict:
    """
    機能: 照合対象の8配列を同じ辞書へ展開する。
    引数: bundle(dict)。
    返り値: dict[str,np.ndarray]。
    """
    return {**bundle['birth'], **{k: bundle[k] for k in ('mw', 'fw', 'hi', 'added')}}


def main() -> None:
    """
    機能: 非金融の人工ケースだけで純方向の不変条件と期限境界を確認する。
    引数: なし。
    返り値: None。結果JSONと金融前候補辞書を新規保存する。
    """
    checks = []; cells = 0

    def check(name: str, actual: object, expected: object) -> None:
        """
        機能: 人工検査の名前と比較項目数を記録する。
        引数: name(str)、actual/expected(object)。
        返り値: None。不一致で停止する。
        """
        nonlocal cells
        a, b = np.asarray(actual), np.asarray(expected)
        assert a.shape == b.shape and np.array_equal(a, b), (name, a, b)
        cells += a.size
        checks.append({'検査': name, '項目': int(a.size), '不一致': 0})

    f, base = fixture(); full = R.build(f, base)
    check('候補8', len(full['candidate_ids']), 8)
    for key, value in flatten(base).items():
        check('旧対照同体/'+key, flatten(full['bundles']['E181_00'])[key], value)
    check('遅延15は次q0で発火', full['diagnostics']['E181_04']['bo_confirmed'], np.arange(40) == 1)
    check('遅延30は次q0で発火', full['diagnostics']['E181_06']['bo_confirmed'], np.arange(40) == 1)
    for stop in range(41):
        pf, pb = sliced(f, base, stop); born = R.build(pf, pb)
        for identity in full['candidate_ids']:
            for key, prior in flatten(full['bundles'][identity]).items():
                check(f'prefix{stop}/{identity}/{key}', flatten(born['bundles'][identity])[key], prior[:stop])
    for stop in (1, 7, 19, 39):
        changed, cb = sliced(f, base, 40)
        changed.buy_X[stop:] = np.random.default_rng(stop).normal(size=changed.buy_X[stop:].shape)
        changed.sell_X[stop:] = np.random.default_rng(stop+100).normal(size=changed.sell_X[stop:].shape)
        born = R.build(changed, cb)
        for identity in full['candidate_ids']:
            for key, prior in flatten(full['bundles'][identity]).items():
                check(f'将来改変{stop}/{identity}/{key}', flatten(born['bundles'][identity])[key][:stop], prior[:stop])
    mirror, mb = sliced(f, base, 40)
    mirror.buy_X, mirror.sell_X = mirror.sell_X.copy(), mirror.buy_X.copy()
    for key in ('core', 'technical'):
        mb['birth'][key] *= -1
    mirrored = R.build(mirror, mb)
    for identity in full['candidate_ids']:
        for key, prior in flatten(full['bundles'][identity]).items():
            expected = -prior if key in ('core', 'technical') else prior
            check('鏡像/'+identity+'/'+key, flatten(mirrored['bundles'][identity])[key], expected)

    # ----------------------------------------
    for name in ('m5_hist_delta_to_side', 'm5_rsi_delta_to_side', 'm5_ema21_delta_to_side',
                 'm5_di_difference_to_side', 'm1_volume_relative_prior3'):
        unknown, ub = sliced(f, base, 40); unknown.buy_X[1, unknown.columns.index(name)] = np.nan
        result = R.build(unknown, ub, ['E181_04'])
        check('必要未知は確認しない/'+name, result['diagnostics']['E181_04']['bo_confirmed'][1], False)
    for change in ('gap', 'contract', 'scene', 'backward'):
        changed, cb = sliced(f, base, 40)
        if change == 'gap':
            for q in changed.q0_meta[1:]: q['q0_time'] += 121
        elif change == 'contract':
            for q in changed.q0_meta[1:]: q['contract'] = '次限月'
        elif change == 'scene':
            for q in changed.q0_meta[1:]: q['session'] = '別_Day'; q['session_index'] = 1
        else:
            for q in changed.q0_meta[1:]: q['q0_time'] -= 61
        born = R.build(changed, cb, ['E181_04'])
        check('状態reset/'+change, born['diagnostics']['E181_04']['bo_confirmed'].sum(), 0)
    for ready, expected in ((15, 1), (16, 0)):
        changed, cb = fixture(40, ready)
        born = R.build(changed, cb, ['E181_04'])
        check('15分期限含む境界/'+str(ready), born['diagnostics']['E181_04']['bo_confirmed'].sum(), expected)
    changed, cb = fixture(40, 16)
    cb['birth']['core'][10] = 1; cb['birth']['branches'][10] = 0
    cb['mw'][10] = cb['fw'][10] = 350
    born = R.build(changed, cb, ['E181_04', 'E181_06'])
    check('同方向setupで延長しない15', born['diagnostics']['E181_04']['bo_confirmed'].sum(), 0)
    check('30分内の継続確認', born['diagnostics']['E181_06']['bo_confirmed'].sum(), 1)
    changed, cb = fixture(8)
    changed.q0_timeband[5:] = 1
    cb['birth']['core'][3] = 1; cb['birth']['branches'][3] = 0
    cb['mw'][3] = cb['fw'][3] = 400; cb['hi'][3] = 3; cb['added'][3] = True
    cb['birth']['core'][6] = -1; cb['birth']['branches'][6] = 0
    cb['mw'][6] = cb['fw'][6] = 350
    born = R.build(changed, cb)
    for identity, bundle in born['bundles'].items():
        for key, prior in flatten(cb).items():
            check('LC固定/'+identity+'/'+key, flatten(bundle)[key][3], prior[3])
            check('夜間固定/'+identity+'/'+key, flatten(bundle)[key][5:], prior[5:])
    changed, cb = fixture(8)
    cb['birth']['core'][2] = 1; cb['birth']['branches'][2] = 0
    cb['mw'][2] = cb['fw'][2] = 150
    changed.buy_X[2, changed.columns.index('q0_entry_minus_ema8_atr5_to_side')] = 1
    born = R.build(changed, cb, ['E181_01'])['bundles']['E181_01']
    check('MP過伸長を拒否', born['birth']['core'][2], 0)
    check('MP拒否からT暗黙切替なし', born['birth']['technical'][2], 0)
    check('MP拒否からtier暗黙切替なし', born['birth']['tier'][2], 0)

    # ----------------------------------------
    result = {'成功': True, '自然特徴と金融未入力': True, '項目': cells,
        '不一致': 0, '検査': checks, 'Source': []}
    for path in (HERE/'rules181.py', Path(__file__)):
        result['Source'].append({'path': path.relative_to(R.ROOT).as_posix(),
            'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    target = HERE/'人工確認181.json'
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'成功': True, '項目': cells, '不一致': 0}, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
