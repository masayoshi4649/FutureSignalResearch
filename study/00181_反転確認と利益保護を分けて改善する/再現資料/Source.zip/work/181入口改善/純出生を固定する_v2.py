"""旧8案を保持した追加8案を金融前固定し、三期間の非金融診断を保存する。"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import sys
import numpy as np
import rules181 as V1
import rules181_v2 as R

HERE = Path(__file__).resolve().parent
COMMON = R.ROOT/'work/181共用接続/共用181.py'


def ref(path: Path) -> dict:
    """
    機能: 固定Sourceと生成純出生の指紋を記録する。
    引数: path(Path)。
    返り値: dictはpath/bytes/sha256。
    """
    return {'path': path.relative_to(R.ROOT).as_posix(), 'bytes': path.stat().st_size,
        'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def save(path: Path, body: dict) -> None:
    """
    機能: JSONの新規正本を保存する。
    引数: path(Path)、body(dict)。
    返り値: None。旧版と既存正本は上書きしない。
    """
    assert not path.exists(), path
    path.write_text(json.dumps(body, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')


def mp_v1_funnel(features: object, base: dict) -> dict:
    """
    機能: v1のMP全拒否を自然金融なしで役割別に分解する。
    引数: features(object)、base(dict)は固定179純出生。
    返り値: dictは旧MP各役割の通過数。取得や損益は含まない。
    """
    arrays, _, _, phases, _ = R._prepare(features)
    _, _, mp = V1._base(base, len(phases), phases)
    roles = {key: [] for key in ('position', 'positive_live', 'rsi', 'range')}
    positions = []
    for i in np.flatnonzero(mp):
        x = arrays[0 if base['birth']['core'][i] == 1 else 1]
        pos = x['q0_entry_minus_ema8_atr5_to_side'][i]
        if np.isfinite(pos): positions.append(float(pos))
        roles['position'].append(R._known(x, i, 'q0_entry_minus_ema8_atr5_to_side') and -.25 <= pos <= .75)
        roles['positive_live'].append(R._known(x, i, 'm1_body_ratio_to_side', 'm1_close_delta_atr5_to_side',
            'm1_body_reclaim_atr5_to_side', 'q0_last_minus_m1_close_atr5_to_side')
            and x['m1_body_ratio_to_side'][i] > 0 and x['m1_close_delta_atr5_to_side'][i] >= 0
            and x['m1_body_reclaim_atr5_to_side'][i]+x['q0_last_minus_m1_close_atr5_to_side'][i] > 0)
        roles['rsi'].append(R._known(x, i, 'm5_rsi_center_to_side', 'm5_rsi_delta_to_side')
            and x['m5_rsi_center_to_side'][i] <= 20 and abs(x['m5_rsi_delta_to_side'][i]) <= 8)
        roles['range'].append(R._known(x, i, 'm1_tr_atr5_ratio', 'm5_tr_previous_atr_ratio')
            and x['m1_tr_atr5_ratio'][i] <= 1.5 and x['m5_tr_previous_atr_ratio'][i] <= 2)
    cumulative = np.ones(int(mp.sum()), bool); sequence = []
    for key, value in roles.items():
        cumulative &= np.asarray(value, bool)
        sequence.append({'役割': key, '単独成立': sum(bool(v) for v in value), '累積成立': int(cumulative.sum())})
    return {'MP出生q0': int(mp.sum()), '役割': sequence,
        '位置ATRの最小四分位中央値四分位最大': np.quantile(positions, [0, .25, .5, .75, 1]).tolist() if positions else []}


def main() -> None:
    """
    機能: 追加版Sourceを固定後に3legの純出生16案とファネルを作る。
    引数: なし。
    返り値: None。自然金融は読み込まない。
    """
    dictionary = HERE/'候補辞書181_v2.json'
    if not dictionary.exists(): R.write_catalog(dictionary)
    sources = [ref(p) for p in (HERE/'rules181.py', HERE/'rules181_v2.py', HERE/'人工検査_v2.py',
        HERE/'人工確認181_v2.json', HERE/'README_v2.md', Path(__file__), dictionary)]
    fixed_path = HERE/'純出生前の固定181_v2.json'
    save(fixed_path, {'成功': True, '金融未入力': True, 'UTC': datetime.now(timezone.utc).isoformat(),
        '候補': [r['id'] for r in R.catalog()['rules']], 'Source': sources})
    spec = importlib.util.spec_from_file_location('common181_pure_entry_v2', COMMON)
    common = importlib.util.module_from_spec(spec); sys.modules[spec.name] = common
    spec.loader.exec_module(common)
    all_rows = []
    for leg in ('旧73', '追加7', '本日1'):
        pure = common.load_pure_leg(leg)
        assert pure['proof']['金融未入力'] and not pure['context'].financial_attached
        features = pure['features']; base = pure['baselines']['全期_J035']
        output = R.build(features, base)
        phases = pure['context'].event_phases; scenes = pure['event_scene']; day = phases == 0
        values = {'phases': phases, 'event_scene': scenes}; rows = []
        with np.load(HERE/f'{leg}_純出生181.npz', allow_pickle=False) as prior:
            for identity, bundle in output['bundles'].items():
                flat = {**bundle['birth'], **{k: bundle[k] for k in ('mw', 'fw', 'hi', 'added')}}
                for key, value in flat.items():
                    values[identity+'__'+key] = value
                    if int(identity[-2:]) < 8:
                        assert np.array_equal(value, prior[identity+'__'+key])
                d = output['diagnostics'][identity]
                values.update({identity+'__diag_'+k: v for k, v in d.items()})
                roles = {k: int((v & d['eligible_pending']).sum()) for k, v in d.items() if k.startswith('role_')}
                mp_roles = {k: int((v & d['mp_setup']).sum()) for k, v in d.items() if k.startswith('mp_role_')}
                core = bundle['birth']['core']
                rows.append({'id': identity, 'DAY主成立q0': int(np.count_nonzero(core[day])),
                    'DAY主成立場': len(set(scenes[day & (core != 0)].tolist())),
                    '確認BO発火q0': int(d['bo_confirmed'].sum()),
                    '確認BO発火場': len(set(scenes[d['bo_confirmed']].tolist())),
                    '旧MP出生q0': int(d['mp_setup'].sum()),
                    '旧MP拒否q0': int((d['rejected'] & d['mp_setup']).sum()),
                    '確認待ち後続q0': int(d['eligible_pending'].sum()), 'BO役割通過': roles, 'MP役割通過': mp_roles})
        target = HERE/f'{leg}_純出生181_v2.npz'; assert not target.exists()
        np.savez_compressed(target, **values)
        summary = {'成功': True, '金融未入力': True, 'leg': leg, '純入力': pure['proof'],
            '候補辞書': ref(dictionary), '純出生前固定': ref(fixed_path), '共用Source': ref(COMMON),
            '純出生': ref(target), '旧8の全配列同体': True, 'v1MPの原因': mp_v1_funnel(features, base),
            '候補': rows, '注意': '成立q0は取得回数・実保有率・利益ではない。'}
        save(target.with_suffix('.json'), summary); all_rows.append(summary)
        print(json.dumps({'純出生': leg, '候補': [{k: r[k] for k in
            ('id', 'DAY主成立q0', '確認BO発火q0', '旧MP拒否q0')} for r in rows if int(r['id'][-2:]) >= 8]}, ensure_ascii=False), flush=True)
    save(HERE/'非金融ファネル181_v2.json', {'成功': True, '金融未入力': True, '期間': all_rows})


if __name__ == '__main__':
    main()
