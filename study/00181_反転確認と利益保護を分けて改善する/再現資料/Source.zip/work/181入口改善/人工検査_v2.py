"""181追加版の旧8案同体と早期/厳格状態を自然値なしで確認する。"""
from pathlib import Path
import hashlib
import json
import numpy as np
import rules181 as V1
import rules181_v2 as R
import 人工検査 as T

HERE = Path(__file__).resolve().parent


def fixture(n: int = 20, ready_at: int = 1) -> tuple:
    """
    機能: 旧人工fixtureへ早期確認の背景・1分構造列を追加する。
    引数: n(int)、ready_at(int)。
    返り値: tupleは純特徴と固定基準bundle。
    """
    f, bundle = T.fixture(n, ready_at)
    extra = sorted(set(R.EXTRA_COLUMNS)-set(f.columns))
    add = np.ones((n, len(extra)))
    for j, name in enumerate(extra):
        if name == 'm1_previous_body_ratio_to_side': add[:, j] = -.5
        elif name == 'm1_close_position_to_side': add[:, j] = .8
        elif name == 'm15_adx_delta': add[:, j] = -.1
    f.buy_X = np.c_[f.buy_X, add]
    sell = add.copy()
    for j, name in enumerate(extra):
        if name.endswith('_to_side'):
            sell[:, j] = 1-add[:, j] if name == 'm1_close_position_to_side' else -add[:, j]
    f.sell_X = np.c_[f.sell_X, sell]; f.columns += extra
    return f, bundle


def main() -> None:
    """
    機能: 旧8同体・鏡像・全prefix・将来改変・未知・状態境界と高RSI非排除を検査する。
    引数: なし。
    返り値: None。自然特徴・金融は読み込まない。
    """
    checks = []; total = 0
    def check(name: str, actual: object, expected: object) -> None:
        """
        機能: 人工不変条件を記録する。
        引数: name(str)、actual/expected(object)。
        返り値: None。不一致で停止する。
        """
        nonlocal total
        a, b = np.asarray(actual), np.asarray(expected)
        assert a.shape == b.shape and np.array_equal(a, b), (name, a, b)
        total += a.size; checks.append({'検査': name, '項目': int(a.size), '不一致': 0})
    f, base = fixture(); output = R.build(f, base)
    check('16候補', len(output['candidate_ids']), 16)
    prior = V1.build(f, base)
    for identity in prior['candidate_ids']:
        for key, value in T.flatten(prior['bundles'][identity]).items():
            check('旧8同体/'+identity+'/'+key, T.flatten(output['bundles'][identity])[key], value)
    for stop in range(21):
        pf, pb = T.sliced(f, base, stop); born = R.build(pf, pb)
        for identity in output['candidate_ids']:
            for key, value in T.flatten(output['bundles'][identity]).items():
                check(f'prefix{stop}/{identity}/{key}', T.flatten(born['bundles'][identity])[key], value[:stop])
    mirror, mb = T.sliced(f, base, 20)
    mirror.buy_X, mirror.sell_X = mirror.sell_X.copy(), mirror.buy_X.copy()
    for key in ('core', 'technical'): mb['birth'][key] *= -1
    born = R.build(mirror, mb)
    for identity in output['candidate_ids']:
        for key, value in T.flatten(output['bundles'][identity]).items():
            check('鏡像/'+identity+'/'+key, T.flatten(born['bundles'][identity])[key],
                  -value if key in ('core', 'technical') else value)
    for stop in (1, 7, 15):
        changed, cb = T.sliced(f, base, 20)
        changed.buy_X[stop:] = np.nan; changed.sell_X[stop:] = np.nan
        born = R.build(changed, cb)
        for identity in output['candidate_ids']:
            for key, value in T.flatten(output['bundles'][identity]).items():
                check('将来改変/'+str(stop)+'/'+identity+'/'+key,
                    T.flatten(born['bundles'][identity])[key][:stop], value[:stop])

    # ----------------------------------------
    changed, cb = fixture()
    changed.buy_X[1:, changed.columns.index('m5_hist_delta_to_side')] = -.25
    changed.buy_X[1:, changed.columns.index('m5_rsi_delta_to_side')] = -.25
    born = R.build(changed, cb)
    check('早期は5分圧力不拡大と1分回復で可能', born['diagnostics']['E181_10']['bo_confirmed'].sum(), 1)
    check('厳格は5分実方向回復まで待つ', born['diagnostics']['E181_14']['bo_confirmed'].sum(), 0)
    changed, cb = fixture()
    changed.buy_X[1:, changed.columns.index('m5_hist_delta_to_side')] = -.5
    changed.buy_X[1:, changed.columns.index('m5_rsi_delta_to_side')] = -.5
    changed.buy_X[1:, changed.columns.index('m5_hist_to_side')] = 0
    changed.buy_X[1:, changed.columns.index('m5_rsi_center_to_side')] = -1
    born = R.build(changed, cb, ['E181_10'])
    check('圧力拡大中の早期禁止', born['diagnostics']['E181_10']['bo_confirmed'].sum(), 0)
    changed, cb = fixture()
    for name in ('m5_hist_delta_to_side', 'm5_rsi_delta_to_side', 'm5_hist_to_side', 'm5_rsi_center_to_side'):
        changed.buy_X[1:, changed.columns.index(name)] = np.nan
    born = R.build(changed, cb, ['E181_10'])
    check('未知圧力を補完しない', born['diagnostics']['E181_10']['bo_confirmed'].sum(), 0)
    changed, cb = fixture()
    cb['birth']['core'][2] = 1; cb['birth']['branches'][2] = 0
    cb['mw'][2] = cb['fw'][2] = 150
    changed.buy_X[2, changed.columns.index('m5_rsi_center_to_side')] = 30
    changed.buy_X[2, changed.columns.index('q0_entry_minus_ema8_atr5_to_side')] = 1.2
    born = R.build(changed, cb, ['E181_08'])
    check('MPの高RSIだけは禁止しない', born['bundles']['E181_08']['birth']['core'][2], 1)
    changed.buy_X[2, changed.columns.index('m1_body_ratio_to_side')] = -.5
    changed.buy_X[2, changed.columns.index('m1_close_delta_atr5_to_side')] = -.5
    changed.buy_X[2, changed.columns.index('m1_body_reclaim_atr5_to_side')] = -.5
    changed.buy_X[2, changed.columns.index('q0_last_minus_m1_close_atr5_to_side')] = -.5
    born = R.build(changed, cb, ['E181_08'])
    check('MP明確な直近崩れは拒否', born['bundles']['E181_08']['birth']['core'][2], 0)
    for change in ('gap', 'contract'):
        changed, cb = fixture()
        for q in changed.q0_meta[1:]:
            if change == 'gap': q['q0_time'] += 121
            else: q['contract'] = '次限月'
        born = R.build(changed, cb, ['E181_10'])
        check('早期状態reset/'+change, born['diagnostics']['E181_10']['bo_confirmed'].sum(), 0)
    for ready, expected in ((15, 1), (16, 0)):
        changed, cb = fixture(20, ready)
        changed.buy_X[:ready, changed.columns.index('m1_body_ratio_to_side')] = -.5
        born = R.build(changed, cb, ['E181_10'])
        check('早期期限/'+str(ready), born['diagnostics']['E181_10']['bo_confirmed'].sum(), expected)
    result = {'成功': True, '自然特徴と金融未入力': True, '項目': total, '不一致': 0,
        '検査': checks, 'Source': []}
    for path in (HERE/'rules181.py', HERE/'rules181_v2.py', Path(__file__)):
        result['Source'].append({'path': path.relative_to(R.ROOT).as_posix(), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    (HERE/'人工確認181_v2.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'成功': True, '項目': total, '不一致': 0}, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
