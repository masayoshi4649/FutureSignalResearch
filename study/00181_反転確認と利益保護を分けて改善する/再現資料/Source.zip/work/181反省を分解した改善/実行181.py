"""181の純入口と出口辞書を固定し、全81場の後続注文まで比較する。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import gzip
import hashlib
import importlib.util
import json
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).parent
TRIAL = ROOT / 'study/00181_反転確認と利益保護を分けて改善する'
for directory in ('work/181共用接続', 'work/181入口改善', 'work/181利益保護'):
    sys.path.insert(0, str(ROOT / directory))
import 共用181 as C
import rules181_v2 as R
import 技術時計181 as TECH
from 必要時配列181 import CellArray
import 集計181 as A


def ref(path: Path) -> dict:
    """
    機能: Source又は入力の内容指紋を記録する。
    引数: path(Path)。
    返り値: dictは相対パス・容量・SHA256。
    """
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def safe(value: object) -> object:
    """
    機能: NumPy値と非有限値をJSON保存用へ変換する。
    引数: value(object)。
    返り値: objectはJSON互換値。非有限値はNone。
    """
    if isinstance(value, dict):
        return {str(k): safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, np.ndarray)):
        return [safe(v) for v in value]
    if isinstance(value, np.bool_):
        return bool(value)
    if isinstance(value, np.integer):
        return int(value)
    if isinstance(value, (float, np.floating)):
        return float(value) if np.isfinite(value) else None
    return value


def save(path: Path, value: object) -> None:
    """
    機能: UTF-8又は決定的gzipへ結果を保存する。
    引数: path(Path)、value(object)。
    返り値: None。
    """
    data = (json.dumps(safe(value), ensure_ascii=False, separators=(',', ':'), allow_nan=False)+'\n').encode('utf-8')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(gzip.compress(data, mtime=0) if path.suffix == '.gz' else data)


class Manager:
    """一期間の価格索引と、各候補の必要時決済を共用する。"""

    def __init__(self, loaded: dict, trail: object):
        """
        機能: 固定金融の写しとcase対応を保存する。巨大な価格索引は必要時に一回だけ読む。
        引数: loaded(dict)は金融接続済み期間、trail(module)は181の追尾実装。
        返り値: None。
        """
        self.loaded, self.trail = loaded, trail
        self.context = loaded['context']
        self.original = dict(self.context.arrays)
        self.engines, self.cache = {}, {}
        self.candidate = None

    def engine(self, scene: int) -> object:
        """
        機能: 場の共用価格木と当時技術の更新時計を一回だけ生成する。
        引数: scene(int)は期間内場添字。
        返り値: TrailEvaluator。
        """
        if scene not in self.engines:
            context = self.context
            session = context.sessions[scene]
            records = C.load_records(self.loaded['leg'], session)
            cases = np.flatnonzero(context.case_scene == scene)
            contract = self.loaded['case_index']['contract'][int(cases[0])]
            technical = TECH.build(context.features, session, contract)
            entries = self.original['entry_index'][cases]
            specs = context.table.evidence['条件']['horizons']
            self.engines[scene] = self.trail.TrailEvaluator(records, entries,
                float(context.scenes[scene]['end']), list(context.table.widths), specs, technical=technical)
        return self.engines[scene]

    def lookup(self, key: tuple) -> dict:
        """
        機能: 注文再生が必要とした全セルの出口を求め、後続要求へ実決済時計を提供する。
        引数: key(tuple[int,int,int,int])は全体case・側・幅・期限。
        返り値: dictは181の金融値と追尾診断。同じセルを再計算しない。
        """
        name = self.candidate['id']
        memo = self.cache.setdefault(name, {})
        if key not in memo:
            case, side, wi, hi = key
            scene = int(self.context.case_scene[case])
            local = int(self.loaded['case_index']['local_case'][case])
            memo[key] = self.engine(scene).evaluate_cell(self.candidate, local, side, wi, hi)
        return memo[key]

    def attach(self, candidate: dict | None) -> None:
        """
        機能: 元の固定IFD又は候補の必要時決済配列へ切り替える。
        引数: candidate(dict|None)。Noneなら固定179そのもの。
        返り値: None。単一建玉エンジンは新しい出口で枠を解放する。
        """
        self.context.arrays = dict(self.original)
        self.candidate = candidate
        if candidate is None:
            return
        for key in ('label', 'known', 'net', 'exit_time', 'known_at', 'holding_confirmed_until',
                    'forced', 'status', 'exit_price', 'exit_index', 'exit_line'):
            prior = self.original[key]
            self.context.arrays[key] = CellArray(key, prior.shape, prior.dtype, self.lookup)


def freeze(exit_catalog: dict) -> dict:
    """
    機能: 自然金融前に、入口・出口・順位・技術時計・接続Sourceを固定する。
    引数: exit_catalog(dict)は出口候補辞書。
    返り値: dictは全条件と指紋。
    """
    files = [Path(__file__), HERE/'集計181.py', HERE/'技術時計181.py', HERE/'必要時配列181.py',
        HERE/'比較方針.json', Path(C.__file__), Path(R.__file__), ROOT/'work/181利益保護/trail181.py',
        ROOT/'work/181利益保護/候補181.json', ROOT/'work/181入口改善/rules181.py']
    body = {'試行': 181, 'UTC': datetime.now(timezone.utc).isoformat(),
        '方針': json.loads((HERE/'比較方針.json').read_text(encoding='utf-8')),
        '入口': R.catalog(), '出口': exit_catalog, 'Source': [ref(p) for p in files],
        '技術時計': 'q0+1秒から反映。5分ATR、EMA8/21差/ATR、MACD増分/ATR、BB15sigmaの15実分前比。前値は時刻差90秒以内、同場同限月。鮮度180秒を超えた技術は使わない。',
        '注意': '全81場は既使用。全80選択と前48選択を区別し、本日1/全81は診断専用。金融前固定は新候補の自然計算前を意味し、元179の全期選択に由来する汚染と今日を踏まえた設計を解消しない。'}
    target = TRIAL/'条件.json'
    if target.exists():
        old = json.loads(target.read_text(encoding='utf-8'))
        assert old['Source'] == body['Source'] and old['入口'] == body['入口'] and old['出口'] == body['出口']
        return old
    save(target, body)
    return body


def main() -> None:
    """
    機能: 全純候補を封印後に金融を接続し、各政策の全後続注文を再生する。
    引数: --leg(str|None)は一期間だけ実行する場合、--resume(bool)は完了packを再利用。
    返り値: None。gzip正本と短い進捗を保存する。
    """
    import trail181 as T
    parser = argparse.ArgumentParser()
    parser.add_argument('--leg', choices=C.LEGS)
    parser.add_argument('--resume', action='store_true')
    args = parser.parse_args()
    exit_catalog = json.loads((ROOT/'work/181利益保護/候補181.json').read_text(encoding='utf-8'))
    freeze(exit_catalog)
    candidates = exit_catalog['候補']
    all_pure = {}
    for leg in C.LEGS:
        pure = C.load_pure_leg(leg)
        C.seal_pure_leg(pure)
        built = R.build(pure['features'], pure['baselines']['全期_J035'])
        payload = {}
        for name, bundle in built['bundles'].items():
            for key in ('mw', 'fw', 'hi', 'added'):
                payload[name+'__'+key] = bundle[key]
            for key, value in bundle['birth'].items():
                payload[name+'__birth__'+key] = value
        target = HERE/f'{leg}_新入口.npz'
        if target.exists():
            with np.load(target, allow_pickle=False) as prior:
                assert set(prior.files) == set(payload)
                for key in payload:
                    np.testing.assert_array_equal(prior[key], payload[key])
        else:
            np.savez_compressed(target, **payload)
        all_pure[leg] = (pure, built)
    seal = {'金融前': True, '入力': [ref(HERE/f'{leg}_新入口.npz') for leg in C.LEGS],
            '条件': ref(TRIAL/'条件.json')}
    target = HERE/'全純入口の封印.json'
    if target.exists():
        assert json.loads(target.read_text(encoding='utf-8')) == seal
    else:
        save(target, seal)
    for leg in ([args.leg] if args.leg else C.LEGS):
        pure, built = all_pure[leg]
        loaded = C.attach_financial(pure)
        manager = Manager(loaded, T)
        for candidate in candidates:
            off = candidate['mode'] == 'off'
            manager.attach(None if off else candidate)
            for entry, bundle in built['bundles'].items():
                policy = {'id': entry+'__'+candidate['id'], 'entry': entry, 'exit': candidate['id']}
                target = HERE/'期間別'/leg/(policy['id']+'.json.gz')
                if args.resume and target.exists():
                    continue
                result = A.pack(manager.context, bundle, policy, leg)
                if not off:
                    keys = zip(result['selection']['cases'], result['selection']['sides'],
                        result['selection']['width_indices'], result['selection']['horizon_indices'], strict=True)
                    result['追尾診断'] = [safe(manager.lookup(tuple(key))) for key in keys]
                save(target, result)
                print(json.dumps({'期間': leg, '候補': policy['id'], **A.short(result['evidence'])},
                    ensure_ascii=False), flush=True)
        save(HERE/f'{leg}_必要時金融の使用数.json',
            {'候補別セル数': {k: len(v) for k, v in manager.cache.items()}, '索引場数': len(manager.engines)})
        del manager, loaded


if __name__ == '__main__':
    main()
