"""176組を同じ分母で並べ、前48選択と全期発見を区別する。"""
from pathlib import Path
import gzip
import json
import sys
import 集計181 as A

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).parent
sys.path.insert(0, str(ROOT/'work/181入口改善'))
import rules181_v2 as R


def read(path: Path) -> dict:
    """
    機能: UTF-8の圧縮JSONを読む。
    引数: path(Path)。
    返り値: dictは計算済み正本。
    """
    return json.loads(gzip.decompress(path.read_bytes()))


def main() -> None:
    """
    機能: 全期間完了した176政策の結果と固定順位を集計する。
    引数: なし。
    返り値: None。全候補短表と上位のIDを保存し、主案は自動で既存へ上書きしない。
    """
    paths = sorted((HERE/'期間別'/'旧73').glob('*.json.gz'))
    rows, oldrows = [], []
    for path in paths:
        packs = [read(HERE/'期間別'/leg/path.name) for leg in ('旧73', '追加7', '本日1')]
        rows.append(A.combine(packs))
        oldrows.append(A.combine(packs[:2]))
    assert len(rows) == 176
    baseline = next(r for r in oldrows if r['id'] == 'E181_00__C0_IFD')
    dictionary = {r['id']: r for r in R.catalog()['rules']}
    ranks = {}
    for band in ('DAY', 'NIGHT'):
        for period in (None, '前48'):
            order = sorted(oldrows, key=lambda r: A.rank(r, band, baseline, period), reverse=True)
            ranks[band+'_'+(period or '全80')] = [r['id'] for r in order]
    compact = []
    for row in rows:
        old = next(r for r in oldrows if r['id'] == row['id'])
        compact.append({'id': row['id'], 'policy': row['policy'],
            '入口定義': dictionary[row['policy']['entry']],
            '全80': {band: A.short(old['evidence'], band) for band in ('DAY','NIGHT','PRE','POST')},
            '全81': {band: A.short(row['evidence'], band) for band in ('DAY','NIGHT','PRE','POST')},
            '期間': {period: {band: A.short(e, band) for band in ('DAY','NIGHT')}
                     for period,e in row['periods'].items()}})
    body = {'成功': True, '全期間既使用': True, 'rows': compact, '順位': ranks}
    target = HERE/'全176組の比較.json.gz'
    target.write_bytes(gzip.compress((json.dumps(body, ensure_ascii=False, separators=(',', ':'), allow_nan=False)+'\n').encode(),mtime=0))
    for name, order in ranks.items():
        print(name)
        for identifier in order[:5]:
            row = next(r for r in compact if r['id'] == identifier)
            band, period = name.split('_')
            print(identifier, json.dumps(row['全80'][band] if period == '全80' else row['期間'][period][band], ensure_ascii=False))


if __name__ == '__main__':
    main()
