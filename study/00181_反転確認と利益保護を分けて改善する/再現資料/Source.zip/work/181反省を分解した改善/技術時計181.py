"""181の保有管理に、公表済み特徴だけを遅延付きで渡す。"""
import numpy as np


def build(features: object, session: str, contract: str | None = None) -> dict:
    """
    機能: 一場・一限月の特徴から利益保護に用いる技術更新時計を作る。
    引数: features(object)は当時特徴、session(str)は場名、contract(str|None)は限月。
    返り値: dict[str,np.ndarray]。同秒の後続原行からの先読みを避けq0の1秒後に反映。
    """
    columns = {name: i for i, name in enumerate(features.columns)}
    rows = [i for i, m in enumerate(features.q0_meta)
            if m['session'] == session and (contract is None or str(m['contract']) == str(contract))]
    rows = np.asarray(rows, dtype=np.int64)
    times = np.asarray([float(features.q0_meta[i]['q0_time']) for i in rows])
    assert len(times) == 0 or np.all(np.diff(times) >= 0)
    x = features.buy_X[rows]
    sigma = x[:, columns['bb15_sigma']]
    ratio = np.full(len(times), np.nan)
    for i, now in enumerate(times):
        j = int(np.searchsorted(times, now - 900, side='right')) - 1
        if j < 0 or now - 900 - times[j] > 90:
            continue
        if str(features.q0_meta[rows[j]]['contract']) != str(features.q0_meta[rows[i]]['contract']):
            continue
        if np.isfinite(sigma[i]) and np.isfinite(sigma[j]) and sigma[j] > 0:
            ratio[i] = sigma[i] / sigma[j]
    return {'times': times + 1,
            'atr_points': x[:, columns['m5_atr']].copy(),
            'ma_gap_atr': np.abs(x[:, columns['m5_gap_atr_to_side']]),
            'bb_width_ratio': ratio,
            'momentum_atr': x[:, columns['m5_hist_delta_atr_to_side']].copy()}


def synthetic_check() -> dict:
    """
    機能: 技術値の反映遅延と、15実分比較・欠測時の未知を確認する。
    引数: なし。
    返り値: dictは検査結果。未来値を過去へ埋めない。
    """
    from types import SimpleNamespace
    names = ['bb15_sigma', 'm5_atr', 'm5_gap_atr_to_side', 'm5_hist_delta_atr_to_side']
    data = SimpleNamespace(columns=names,
        q0_meta=[{'session': '人工_Day', 'contract': '人工', 'q0_time': t}
                 for t in (1000, 1900, 2000, 3100)],
        buy_X=np.array([[100, 40, -.3, 1], [80, 50, -.2, -1],
                        [70, 60, .4, 2], [90, 70, .5, 3]], float))
    got = build(data, '人工_Day')
    assert got['times'].tolist() == [1001, 1901, 2001, 3101]
    assert np.isnan(got['bb_width_ratio'][0]) and got['bb_width_ratio'][1] == .8
    assert np.isnan(got['bb_width_ratio'][2:]).all()
    assert np.allclose(got['ma_gap_atr'], [.3, .2, .4, .5])
    return {'成功': True, '確認': ['q0の1秒後反映', '15実分前比', '90秒を超える参照不足は未知', 'MA差の絶対値']}
