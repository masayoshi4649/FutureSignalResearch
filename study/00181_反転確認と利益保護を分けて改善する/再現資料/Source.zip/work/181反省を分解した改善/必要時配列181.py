"""新しい決済時刻で後続新規まで再生するための必要時金融配列。"""
import numpy as np


class CellArray:
    """旧検証器のスカラー・ベクトル参照に同じセル計算を提供する。"""

    def __init__(self, key: str, shape: tuple, dtype: object, lookup: object):
        """
        機能: 配列名と共用セル計算器を登録する。
        引数: key(str)、shape(tuple)、dtype(object)、lookup(callable)。
        返り値: None。
        """
        self.key, self.shape, self.dtype, self.lookup = key, shape, dtype, lookup

    def __getitem__(self, key: tuple) -> object:
        """
        機能: 4軸のセル参照を必要時計算し、複数配列軸を同時に扱う。
        引数: key(tuple)はcase、実側、幅添字、期限添字。sliceは使用しない。
        返り値: objectはスカラー、又はnp.ndarray。未知NaNを保存する。
        """
        assert isinstance(key, tuple) and len(key) == 4
        assert not any(isinstance(x, slice) for x in key)
        axes = np.broadcast_arrays(*[np.asarray(x) for x in key])
        if not axes[0].ndim:
            return self.lookup(tuple(int(x) for x in axes))[self.key]
        output = np.empty(axes[0].shape, dtype=self.dtype)
        for at in np.ndindex(output.shape):
            output[at] = self.lookup(tuple(int(x[at]) for x in axes))[self.key]
        return output


def synthetic_check() -> dict:
    """
    機能: スカラー・複数・空集合の参照を実配列と照合する。
    引数: なし。
    返り値: dictは検査結果。
    """
    base = np.arange(2*2*3*4).reshape(2, 2, 3, 4)
    def read(key: tuple) -> dict:
        """
        機能: 人工配列から一つの値を返す。
        引数: key(tuple)は4軸。
        返り値: dictはvの値。
        """
        return {'v': base[key]}
    value = CellArray('v', base.shape, base.dtype, read)
    for key in ((1, 0, 2, 3), (np.array([0, 1]), 1, np.array([2, 0]), 0),
                (np.array([], int), np.array([], int), np.array([], int), np.array([], int))):
        assert np.array_equal(value[key], base[key])
    return {'成功': True, '確認': ['単一セル', '複数配列参照', '空集合']}
