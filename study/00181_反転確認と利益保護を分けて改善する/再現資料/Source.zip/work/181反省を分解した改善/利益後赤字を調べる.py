"""実際に保有した区間だけから、利益後赤字と最大含み益の返上を診断する。"""
from pathlib import Path
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT/'work/181共用接続'))
import 共用181 as C


def diagnose(row: dict) -> dict:
    """
    機能: 決済が確定した取引の実保有内MFEを求め、利益後赤字を分ける。
    引数: row(dict)は181の全期間結合pack。
    返り値: dictは建玉診断とDAY/NIGHT/PRE/POST集計。ピーク決済可能性は仮定しない。
    """
    ledger = row['ledger']
    records_cache, details = {}, []
    for i, known in enumerate(ledger['known']):
        if not known:
            details.append({'i': i, 'known': False, 'MFE円': None})
            continue
        leg, scene = ledger['leg'][i], ledger['scene'][i]
        key = (leg, scene)
        if key not in records_cache:
            records_cache[key] = C.load_records(leg, scene)
        records = records_cache[key]
        start, end = ledger['entry_index'][i], ledger['exit_index'][i]
        assert start < end and records['time'][end] == ledger['exit_time'][i]
        selected = np.arange(start + 1, end + 1)
        selected = selected[(records['normal'][selected] == 1) &
                            (records['bid'][selected] > 0) & (records['bid'][selected] < records['ask'][selected])]
        side = ledger['side'][i]
        sign, field = (1, 'bid') if side == 0 else (-1, 'ask')
        values = sign * (records[field][selected] - ledger['entry_price'][i]) * 100 - 1077
        at = int(np.argmax(values))
        peak = float(values[at])
        details.append({'i': i, 'known': True, 'MFE円': peak,
            'MFE時刻': float(records['time'][selected[at]]),
            '利益後赤字': peak > 0 and ledger['net'][i] < 0,
            'ピーク返上円': max(0., peak - ledger['net'][i])})
    groups = {}
    for name, phases in [('DAY', (0,)), ('NIGHT', (1, 2)), ('PRE', (1,)), ('POST', (2,))]:
        indices = [i for i, p in enumerate(ledger['phase']) if p in phases]
        known_indices = [i for i in indices if ledger['known'][i]]
        positive_then_red = [i for i in known_indices if details[i]['利益後赤字']]
        groups[name] = {'取得': len(indices), '未知': len(indices) - len(known_indices),
            '利益化した建玉': sum(details[i]['MFE円'] > 0 for i in known_indices),
            '利益後赤字件数': len(positive_then_red),
            '利益後赤字損失円': -sum(ledger['net'][i] for i in positive_then_red),
            '利益化しない赤字件数': sum(ledger['net'][i] < 0 and details[i]['MFE円'] <= 0 for i in known_indices),
            '最大ピーク返上円': max((details[i]['ピーク返上円'] for i in known_indices), default=None)}
    return {'id': row['id'], '集計': groups, '建玉': details,
            '意味': '現実の取得から決済までに観測した費用後評価額。ピークとの差は事後診断であり、実現可能な利益又は取り逃がしの最適化目標ではない。未知取引のMFEは集計しない。'}
