package entrybirth120

import (
	"fmt"
	"math"
	"testing"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// ----------------------------------------
// known は、人工の既知値を作ります。
//
// 引数: v(float64)。返り値: rules.Valueです。
func known(v float64) rules.Value { return rules.Value{Known: true, Value: v} }

// ----------------------------------------
// artificial は、自然入力を使わない3公表と1分履歴を作ります。
//
// 引数: side(int)、reversal(bool)。返り値: *Detector/rules.Snapshot/Bar/rules.Quoteです。
func artificial(side int, reversal bool) (*Detector, rules.Snapshot, Bar, rules.Quote) {
	d := NewDetector()
	_ = d.StartSession("S", "K")
	end := 1200.0
	s := rules.Snapshot{SessionID: "S", Contract: "K", Frames: map[int]rules.Publication{}, BB15: rules.Bands{Known: true, Lower: 990, Upper: 1010}, RVOL5: known(1)}
	for _, w := range []int{300, 900, 1800} {
		f := rules.ChartFrame{ID: fmt.Sprintf("S/%d/1200", w), SessionID: "S", Contract: "K", Width: w, Start: end - float64(w), End: end, AvailableAt: end, DeliveryAt: end, PriceKnown: true, VolumeKnown: true, Volume: 100, OHLC: rules.OHLC{Open: 1000, High: 1010, Low: 990, Close: 1000}, Technical: rules.Technical{EMA8: known(1001), EMA21: known(1000), Gap: known(1), EMA8Delta: known(1), EMA21Delta: known(1), ATR: known(100), PreviousATR: known(100), TR: known(20), RSI: known(60), PreviousRSI: known(55), Histogram: known(1), PreviousHistogram: known(.5)}}
		p := rules.Publication{Stamp: rules.Stamp{Time: end, Index: 0, Line: 1}, Frame: rules.Frame{Frame: f, DMI: rules.DMI{PlusDI: known(30), MinusDI: known(20), ADX: known(24), PreviousADX: known(26)}}}
		s.Frames[w] = p
		s.Refs = append(s.Refs, rules.Ref{ID: f.ID, Width: w, End: end, Delivered: p.Stamp})
	}
	low, high, close := 990.0, 1010.0, 1000.0
	b := Bar{Start: end, End: end + 60, OHLC: rules.OHLC{Open: 995, High: 1025, Low: 990, Close: 1020}, TR: known(35), Rows: 4}
	if reversal {
		low, high, close = 1000, 1020, 1010
		b.OHLC = rules.OHLC{Open: 1003, High: 1020, Low: 995, Close: 1015}
		b.TR = known(25)
		s.BB15 = rules.Bands{Known: true, Lower: 1000, Upper: 1040}
		p := s.Frames[900]
		p.Frame.Frame.Technical.RSI = known(30)
		s.Frames[900] = p
	}
	for i := 0; i < 14; i++ {
		at := end - float64((14-i)*60)
		d.history = append(d.history, Bar{Start: at, End: at + 60, OHLC: rules.OHLC{Open: close, High: high, Low: low, Close: close}, TR: known(20), Rows: 4})
	}
	if side < 0 {
		for i := range d.history {
			o := d.history[i].OHLC
			d.history[i].OHLC = rules.OHLC{Open: 2000 - o.Open, High: 2000 - o.Low, Low: 2000 - o.High, Close: 2000 - o.Close}
		}
		o := b.OHLC
		b.OHLC = rules.OHLC{Open: 2000 - o.Open, High: 2000 - o.Low, Low: 2000 - o.High, Close: 2000 - o.Close}
		lower, upper := s.BB15.Lower, s.BB15.Upper
		s.BB15.Lower = 2000 - upper
		s.BB15.Upper = 2000 - lower
		for w, p := range s.Frames {
			z := &p.Frame.Frame.Technical
			z.EMA8 = known(2000 - z.EMA8.Value)
			z.EMA21 = known(2000 - z.EMA21.Value)
			z.Gap.Value *= -1
			z.EMA8Delta.Value *= -1
			z.EMA21Delta.Value *= -1
			z.RSI.Value = 100 - z.RSI.Value
			z.PreviousRSI.Value = 100 - z.PreviousRSI.Value
			z.Histogram.Value *= -1
			z.PreviousHistogram.Value *= -1
			p.Frame.DMI.PlusDI, p.Frame.DMI.MinusDI = p.Frame.DMI.MinusDI, p.Frame.DMI.PlusDI
			s.Frames[w] = p
		}
	}
	d.lastKnownBB15 = &BandWidth{Width: s.BB15.Upper - s.BB15.Lower, Ref: s.Refs[1]}
	d.previousKnownBB15 = &BandWidth{Width: 80, Ref: rules.Ref{ID: "prior15", Width: 900, End: 300}}
	q := rules.Quote{Time: b.End, Index: 100, Line: 101, Last: b.OHLC.Close}
	return d, s, b, q
}

// ----------------------------------------
// selectPolicy は、人工の返り値から政策と売買が一致するものを選びます。
//
// 引数: events([]Event)、policy(string)、side(int)。返り値: []Eventです。
func selectPolicy(events []Event, policy string, side int) []Event {
	out := []Event{}
	for _, e := range events {
		if e.Policy == policy && e.Side == side {
			out = append(out, e)
		}
	}
	return out
}

// ----------------------------------------
// artificialBank は、人工snapshotの3公表だけをbankへ配送します。
//
// 引数: t(*testing.T)、s(rules.Snapshot)。返り値: *rules.Bankです。
func artificialBank(t *testing.T, s rules.Snapshot) *rules.Bank {
	t.Helper()
	bank := rules.NewBank()
	if err := bank.StartSession("S", "K"); err != nil {
		t.Fatal(err)
	}
	for _, w := range []int{300, 900, 1800} {
		if err := bank.Add(s.Frames[w]); err != nil {
			t.Fatal(err)
		}
	}
	return bank
}

// ----------------------------------------
// TestCausalMinuteAndBoundaries は、未確定足・次分先頭・同原行冪等・時計拒否を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestCausalMinuteAndBoundaries(t *testing.T) {
	d, s, b, _ := artificial(1, false)
	bank := artificialBank(t, s)
	prices := []float64{b.OHLC.Open, b.OHLC.Low, b.OHLC.High, b.OHLC.Close}
	times := []float64{1200, 1210, 1220, 1259}
	for i, p := range prices {
		e, err := d.Observe(bank, rules.Quote{Time: times[i], Index: 10 + i, Line: 11 + i, Last: p})
		if err != nil || len(e) != 0 {
			t.Fatalf("未確定1分で候補 %v %#v", err, e)
		}
	}
	q := rules.Quote{Time: 1260, Index: 14, Line: 15, Last: 1020}
	e, err := d.Observe(bank, q)
	got := selectPolicy(e, "P1", 1)
	if err != nil || len(got) != 1 || got[0].Bar.OHLC.Close != 1020 || got[0].Bar.OHLC.High != 1025 || got[0].Bar.End != q.Time || got[0].Fields["atr1_before14"].Value != 20 || got[0].Bar.TR.Value != 35 {
		t.Fatalf("確定と前ATR %#v %v", got, err)
	}
	if more, err := d.Observe(bank, q); err != nil || len(more) != 0 {
		t.Fatal("同原行重複")
	}
	before := d.Stats().RawRows
	q.Last++
	if _, err := d.Observe(bank, q); err == nil || d.Stats().RawRows != before {
		t.Fatal("同Index改変を更新した")
	}
	q.Index++
	q.Line++
	q.Time--
	if _, err := d.Observe(bank, q); err == nil {
		t.Fatal("時計逆転を受理")
	}
	if d.Stats().ClosedMinuteBars != 1 || d.Stats().EligibleClosures != 1 {
		t.Fatal("閉鎖分母")
	}
}

// ----------------------------------------
// TestATRExcludesCurrentAndNeedsKnown は、当足除外・前14本・未知拒否を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestATRExcludesCurrentAndNeedsKnown(t *testing.T) {
	d, s, b, q := artificial(1, false)
	if a := priorATR(d.history, b.Start); !a.Known || a.Value != 20 {
		t.Fatal(a)
	}
	b.TR = known(1000)
	if e := d.analyze(s, b, q); len(e) != 0 || d.Stats().SpikeRejected != 1 {
		t.Fatal("当足をATRへ混入")
	}
	d.history[len(d.history)-1].TR = rules.Value{}
	if a := priorATR(d.history, b.Start); a.Known {
		t.Fatal("未知TRを0補完")
	}
	if a := priorATR(d.history[:13], b.Start); a.Known {
		t.Fatal("14本不足")
	}
}

// ----------------------------------------
// TestMinuteGapDelayAndHistoryCap は、欠分reset・30秒等号・最大20本を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestMinuteGapDelayAndHistoryCap(t *testing.T) {
	for _, delay := range []float64{30, 31, 60} {
		d, s, b, _ := artificial(1, false)
		bank := artificialBank(t, s)
		d.current = &b
		last := rules.Quote{Time: 1259, Index: 1, Line: 2, Last: b.OHLC.Close}
		d.last = &last
		e, err := d.Observe(bank, rules.Quote{Time: 1260 + delay, Index: 2, Line: 3, Last: b.OHLC.Close})
		if err != nil {
			t.Fatal(err)
		}
		if delay == 30 && len(selectPolicy(e, "P1", 1)) != 1 {
			t.Fatal("30秒等号を拒否")
		}
		if delay > 30 && len(e) != 0 {
			t.Fatal("遅配信号")
		}
		if delay == 60 && (len(d.history) != 0 || d.Stats().GapResets != 1) {
			t.Fatal("欠分を補間")
		}
	}
	d, s, _, _ := artificial(1, false)
	bank := artificialBank(t, s)
	for i := 0; i < 30; i++ {
		_, err := d.Observe(bank, rules.Quote{Time: 1200 + 60*float64(i), Index: i + 1, Line: i + 2, Last: 1000})
		if err != nil {
			t.Fatal(err)
		}
	}
	if len(d.Snapshot().History) != 20 {
		t.Fatal("履歴上限")
	}
}

// ----------------------------------------
// TestAllPoliciesMirrorAndCopies は、6政策の符号対称性・保存値・参照分離を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestAllPoliciesMirrorAndCopies(t *testing.T) {
	for _, reversal := range []bool{false, true} {
		var buy map[string]Event
		for _, side := range []int{1, -1} {
			d, s, b, q := artificial(side, reversal)
			events := d.analyze(s, b, q)
			want := []string{"P1", "P1plus", "P3", "P3plus"}
			if reversal {
				want = []string{"P2", "P2plus"}
			}
			current := map[string]Event{}
			for _, policy := range want {
				got := selectPolicy(events, policy, side)
				if len(got) != 1 {
					t.Fatalf("%s side=%d %#v", policy, side, events)
				}
				v := got[0]
				current[policy] = v
				if !v.PreviousFiveRange.Known || !v.Fields["atr5"].Known || v.Scope.SessionID != "S" {
					t.Fatal("保存根拠")
				}
			}
			if side > 0 {
				buy = current
			} else {
				for _, p := range want {
					if math.Abs(buy[p].EntryCap+current[p].EntryCap-2000) > 1e-9 || math.Abs(buy[p].Invalidation+current[p].Invalidation-2000) > 1e-9 || buy[p].Fields["risk_at_last"] != current[p].Fields["risk_at_last"] {
						t.Fatal("非対称", p)
					}
				}
			}
			st := d.Snapshot()
			st.History[0].OHLC.High = 1
			st.LastSignals["P1/1"] = 0
			st.Stats.Policies["P1/1"] = PolicyStats{}
			if d.history[0].OHLC.High == 1 || (side > 0 && !reversal && d.Stats().Policies["P1/1"].Births != 1) {
				t.Fatal("snapshot参照共有")
			}
			if len(events) > 1 {
				events[0].Fields["atr5"] = known(1)
				if events[1].Fields["atr5"].Value == 1 {
					t.Fatal("Event参照共有")
				}
			}
		}
	}
}

// ----------------------------------------
// TestUnknownAndFreshPublicationReject は、追加条件の未知・当場公表不足を拒否します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestUnknownAndFreshPublicationReject(t *testing.T) {
	d, s, b, q := artificial(1, false)
	s.RVOL5 = rules.Value{}
	e := d.analyze(s, b, q)
	if len(selectPolicy(e, "P1", 1)) != 1 || len(selectPolicy(e, "P1plus", 1)) != 0 {
		t.Fatal("RVOL未知を支持")
	}
	d, s, b, q = artificial(1, false)
	p := s.Frames[1800]
	p.Frame.Frame.Technical.EMA21Delta = rules.Value{}
	s.Frames[1800] = p
	if len(d.analyze(s, b, q)) != 0 {
		t.Fatal("背景未知を支持")
	}
	d, s, b, q = artificial(1, false)
	s.Missing = []string{"5分公表不足"}
	if len(d.analyze(s, b, q)) != 0 || d.Stats().PublicationMissing != 1 {
		t.Fatal("公表不足を通過")
	}
	d, s, b, q = artificial(1, false)
	bank := artificialBank(t, s)
	d.current = &b
	last := rules.Quote{Time: 1259, Index: 1, Line: 2, Last: 1020}
	d.last = &last
	p = s.Frames[300]
	p.Frame.Frame.PriceKnown = false
	p.Frame.Frame.ID = "S/300/1260"
	p.Frame.Frame.Start = 1200
	p.Frame.Frame.End = 1260
	p.Frame.Frame.AvailableAt = 1260
	p.Frame.Frame.DeliveryAt = 1260
	p.Stamp = rules.Stamp{Time: 1260, Index: 2, Line: 3}
	if err := bank.Add(p); err != nil {
		t.Fatal(err)
	}
	if e, err := d.Observe(bank, rules.Quote{Time: 1260, Index: 2, Line: 3, Last: 1020}); err != nil || len(e) != 0 {
		t.Fatal("価格未知を通過")
	}
	d, s, b, q = artificial(1, false)
	bank = artificialBank(t, s)
	for i := range d.history {
		d.history[i].Start += 300
		d.history[i].End += 300
	}
	b.Start += 300
	b.End += 300
	d.current = &b
	last = rules.Quote{Time: 1559, Index: 1, Line: 2, Last: 1020}
	d.last = &last
	if e, err := d.Observe(bank, rules.Quote{Time: 1560, Index: 2, Line: 3, Last: 1020}); err != nil || len(e) != 0 || d.Stats().PublicationMissing != 1 {
		t.Fatal("5分fresh期限等号を通過", e, err)
	}
}

// ----------------------------------------
// TestCooldownCapRiskAndGateCounts は、政策別300秒境界・cap・自然否定距離を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestCooldownCapRiskAndGateCounts(t *testing.T) {
	d, s, b, q := artificial(1, false)
	if len(selectPolicy(d.analyze(s, b, q), "P1", 1)) != 1 {
		t.Fatal("初回")
	}
	q.Time += 299
	if len(d.analyze(s, b, q)) != 0 {
		t.Fatal("cooldown未了")
	}
	q.Time++
	if len(selectPolicy(d.analyze(s, b, q), "P1", 1)) != 1 {
		t.Fatal("300秒等号")
	}
	c := d.Stats().Policies["P1/1"]
	if c.Considered != 3 || c.AllGatesPass != 3 || c.CooldownRejected != 1 || c.Births != 2 {
		t.Fatal(c)
	}
	for _, last := range []float64{1030, 1030.01, 985, 1036} {
		d, s, b, q = artificial(1, false)
		q.Last = last
		got := selectPolicy(d.analyze(s, b, q), "P1", 1)
		if last == 1030 && len(got) != 1 {
			t.Fatal("cap等号")
		}
		if last != 1030 && len(got) != 0 {
			t.Fatal("cap/距離不正", last)
		}
	}
	if err := d.StartSession("next", "K"); err != nil || d.Stats().Births != 0 || len(d.history) != 0 || d.lastKnownBB15 != nil {
		t.Fatal("当場reset")
	}
}

// ----------------------------------------
// TestBBPriorKnownSessionAndDistinct は、同場の別known公表だけを幅比較へ使います。
//
// 引数: t(*testing.T)。返り値: なし。
func TestBBPriorKnownSessionAndDistinct(t *testing.T) {
	d, s, _, _ := artificial(1, false)
	d.lastKnownBB15 = nil
	d.previousKnownBB15 = nil
	d.last15ID = ""
	d.updateBB(s)
	if d.previousKnownBB15 != nil {
		t.Fatal("初回から前幅")
	}
	d.updateBB(s)
	if d.previousKnownBB15 != nil {
		t.Fatal("同IDで前幅")
	}
	p := s.Frames[900]
	p.Frame.Frame.ID = "unknown15"
	s.Frames[900] = p
	s.BB15.Known = false
	d.updateBB(s)
	p.Frame.Frame.ID = "next15"
	s.Frames[900] = p
	s.BB15 = rules.Bands{Known: true, Lower: 995, Upper: 1005}
	d.updateBB(s)
	if d.previousKnownBB15 == nil || d.previousKnownBB15.Width != 20 || d.lastKnownBB15.Width != 10 {
		t.Fatal("known前公表の幅")
	}
	_ = d.StartSession("new", "K")
	if d.previousKnownBB15 != nil || d.lastKnownBB15 != nil {
		t.Fatal("他場幅carry")
	}
}

// ----------------------------------------
// TestRecoveredCloseRequiresCurrentHoldMirror は、回復済み終値の後に当Lastが境界を失った場合を拒否します。
//
// 引数: t(*testing.T)。返り値: なし。P1/P3のstrictとP2の5pt等号を買売で確認します。
func TestRecoveredCloseRequiresCurrentHoldMirror(t *testing.T) {
	for _, side := range []int{1, -1} {
		for _, reversal := range []bool{false, true} {
			d, s, b, q := artificial(side, reversal)
			boundary := 1010.0
			minimum := 0.0
			expected := []string{"P1", "P1plus", "P3", "P3plus"}
			if reversal {
				boundary = 1000
				minimum = 5
				expected = []string{"P2", "P2plus"}
			}
			if side < 0 {
				boundary = 2000 - boundary
			}
			q.Last = boundary + float64(side)*(minimum-.01)
			for _, policy := range expected {
				if len(selectPolicy(d.analyze(s, b, q), policy, side)) != 0 {
					t.Fatal("回復を喪失して出生", policy, side)
				}
			}
			if d.Stats().Policies[fmt.Sprintf("%s/%d", expected[0], side)].HoldPass != 0 {
				t.Fatal("維持ゲート")
			}
			d, s, b, q = artificial(side, reversal)
			q.Last = boundary + float64(side)*minimum
			events := d.analyze(s, b, q)
			for _, policy := range expected {
				got := selectPolicy(events, policy, side)
				if !reversal && len(got) != 0 {
					t.Fatal("strict等号で出生")
				}
				if reversal && (len(got) != 1 || got[0].Fields["hold_boundary"].Value != boundary || got[0].Fields["hold_minimum"].Value != 5 || got[0].Fields["hold_strict"].Value != 0) {
					t.Fatal("回復5pt等号又は保存値", got)
				}
			}
		}
	}
}

// ----------------------------------------
// TestRawGapAdjacentMinutesReset は、隣接minuteでも原行87秒欠測なら形成/履歴を捨てます。
//
// 引数: t(*testing.T)。返り値: なし。60秒等号は別境界として維持します。
func TestRawGapAdjacentMinutesReset(t *testing.T) {
	d, s, b, _ := artificial(1, false)
	bank := artificialBank(t, s)
	d.current = &b
	last := rules.Quote{Time: 1202, Index: 1, Line: 2, Last: 995}
	d.last = &last
	q := rules.Quote{Time: 1289, Index: 2, Line: 3, Last: 1020}
	e, err := d.Observe(bank, q)
	if err != nil || len(e) != 0 || len(d.history) != 0 || d.current.Start != 1260 || d.current.OHLC.Open != q.Last || d.Stats().RawGapResets != 1 || d.Stats().GapResets != 0 || d.Stats().ClosedMinuteBars != 0 {
		t.Fatal("隣接87秒欠測を継続扱い", e, err, d.Snapshot())
	}
	d, s, b, _ = artificial(1, false)
	bank = artificialBank(t, s)
	d.current = &b
	last = rules.Quote{Time: 1200, Index: 1, Line: 2, Last: 995}
	d.last = &last
	q = rules.Quote{Time: 1260, Index: 2, Line: 3, Last: 1020}
	if _, err = d.Observe(bank, q); err != nil || d.Stats().RawGapResets != 0 || d.Stats().ClosedMinuteBars != 1 {
		t.Fatal("60秒等号をreset")
	}
}
