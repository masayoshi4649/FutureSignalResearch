// Package entrybirth120 は、1分構造と公表済み複数技法から入口候補を生みます。
package entrybirth120

import rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"

var Policies = []string{"P1", "P1plus", "P2", "P2plus", "P3", "P3plus"}

type Scope struct {
	SessionID string `json:"session_id"`
	Contract  string `json:"contract"`
}

type Bar struct {
	Start float64     `json:"start"`
	End   float64     `json:"end"`
	OHLC  rules.OHLC  `json:"ohlc"`
	TR    rules.Value `json:"tr"`
	Rows  int         `json:"rows"`
	First rules.Quote `json:"first"`
	Last  rules.Quote `json:"last"`
}

type Range struct {
	Known bool    `json:"known"`
	Start float64 `json:"start"`
	End   float64 `json:"end"`
	Low   float64 `json:"low"`
	High  float64 `json:"high"`
	Count int     `json:"count"`
}

type BandWidth struct {
	Width float64   `json:"width"`
	Ref   rules.Ref `json:"ref"`
}

type Event struct {
	ID                string                 `json:"id"`
	Scope             Scope                  `json:"scope"`
	Policy            string                 `json:"policy"`
	Side              int                    `json:"side"`
	At                rules.Quote            `json:"at"`
	Bar               Bar                    `json:"bar"`
	PreviousFiveRange Range                  `json:"previous5range"`
	Refs              []rules.Ref            `json:"refs"`
	Fields            map[string]rules.Value `json:"fields"`
	EntryCap          float64                `json:"entry_cap"`
	Invalidation      float64                `json:"invalidation"`
}

type State struct {
	Scope             Scope              `json:"scope"`
	Last              *rules.Quote       `json:"last,omitempty"`
	Current           *Bar               `json:"current,omitempty"`
	History           []Bar              `json:"history"`
	LastKnownBB15     *BandWidth         `json:"last_known_bb15,omitempty"`
	PreviousKnownBB15 *BandWidth         `json:"previous_known_bb15,omitempty"`
	LastSignals       map[string]float64 `json:"last_signals"`
	Sequence          uint64             `json:"sequence"`
	Stats             Stats              `json:"stats"`
}

type PolicyStats struct {
	Considered       uint64 `json:"considered"`
	ShapePass        uint64 `json:"shape_pass"`
	RiskPass         uint64 `json:"risk_pass"`
	CapPass          uint64 `json:"cap_pass"`
	HoldPass         uint64 `json:"hold_pass"`
	BackgroundPass   uint64 `json:"background_pass"`
	StructurePass    uint64 `json:"structure_pass"`
	ExtraPass        uint64 `json:"extra_pass"`
	AllGatesPass     uint64 `json:"all_gates_pass"`
	CooldownRejected uint64 `json:"cooldown_rejected"`
	Births           uint64 `json:"births"`
}

type Stats struct {
	RawRows              uint64                 `json:"raw_rows"`
	ClosedMinuteBars     uint64                 `json:"closed_minute_bars"`
	GapResets            uint64                 `json:"gap_resets"`
	RawGapResets         uint64                 `json:"raw_gap_resets"`
	StaleClosures        uint64                 `json:"stale_closures"`
	EligibleClosures     uint64                 `json:"eligible_closures"`
	PublicationMissing   uint64                 `json:"publication_missing"`
	ATR1Unavailable      uint64                 `json:"atr1_unavailable"`
	ATR5Unavailable      uint64                 `json:"atr5_unavailable"`
	CurrentTRUnavailable uint64                 `json:"current_tr_unavailable"`
	SpikeRejected        uint64                 `json:"spike_rejected"`
	RangeRejected        uint64                 `json:"range_rejected"`
	Births               uint64                 `json:"births"`
	Policies             map[string]PolicyStats `json:"policies"`
}

type Detector struct {
	scope             Scope
	last              *rules.Quote
	current           *Bar
	history           []Bar
	lastKnownBB15     *BandWidth
	previousKnownBB15 *BandWidth
	last15ID          string
	lastSignals       map[string]float64
	sequence          uint64
	stats             Stats
}
