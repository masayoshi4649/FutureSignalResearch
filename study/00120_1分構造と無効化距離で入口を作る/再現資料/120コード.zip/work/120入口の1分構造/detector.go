package entrybirth120

import (
	"fmt"
	"math"
	"strings"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// ----------------------------------------
// NewDetector は、場開始前の空の発生器を作ります。
//
// 引数: なし。返り値: *Detector。Observeより先にStartSessionを呼びます。
func NewDetector() *Detector { return &Detector{} }

// ----------------------------------------
// StartSession は、1分履歴・BB比較・政策別クールダウンを当場へ初期化します。
//
// 引数: sessionID/contract(string)。返り値: errorは空の識別子です。
func (d *Detector) StartSession(sessionID, contract string) error {
	if sessionID == "" || contract == "" {
		return fmt.Errorf("場又は限月が空です")
	}
	*d = Detector{scope: Scope{SessionID: sessionID, Contract: contract}, lastSignals: map[string]float64{}, stats: Stats{Policies: map[string]PolicyStats{}}}
	for _, policy := range Policies {
		for _, side := range []int{1, -1} {
			d.stats.Policies[fmt.Sprintf("%s/%d", policy, side)] = PolicyStats{}
		}
	}
	return nil
}

// ----------------------------------------
// Snapshot は、外部と参照を共有しない現在の形成状態を返します。
//
// 引数: receiver(*Detector)。返り値: Stateは作業中足と最大20本履歴を含みます。
func (d *Detector) Snapshot() State {
	s := State{Scope: d.scope, History: append([]Bar{}, d.history...), LastSignals: map[string]float64{}, Sequence: d.sequence, Stats: d.Stats()}
	if d.last != nil {
		v := *d.last
		s.Last = &v
	}
	if d.current != nil {
		v := *d.current
		s.Current = &v
	}
	if d.lastKnownBB15 != nil {
		v := *d.lastKnownBB15
		s.LastKnownBB15 = &v
	}
	if d.previousKnownBB15 != nil {
		v := *d.previousKnownBB15
		s.PreviousKnownBB15 = &v
	}
	for k, v := range d.lastSignals {
		s.LastSignals[k] = v
	}
	return s
}

// ----------------------------------------
// Stats は、共通品質と政策別の独立ゲート件数を私有値として返します。
//
// 引数: receiver(*Detector)。返り値: Stats。各Passは同じConsidered分母、AllGatesPassは全条件ANDです。
func (d *Detector) Stats() Stats {
	s := d.stats
	s.Policies = map[string]PolicyStats{}
	for k, v := range d.stats.Policies {
		s.Policies[k] = v
	}
	return s
}

// ----------------------------------------
// makeBar は、UTCの60秒床へ属する最初の価格で1分足を作ります。
//
// 引数: q(rules.Quote)。返り値: *Bar。終了時計の原行は次足へ属します。
func makeBar(q rules.Quote) *Bar {
	start := math.Floor(q.Time/60) * 60
	return &Bar{Start: start, End: start + 60, OHLC: rules.OHLC{Open: q.Last, High: q.Last, Low: q.Last, Close: q.Last}, Rows: 1, First: q, Last: q}
}

// ----------------------------------------
// updateBar は、当該1分内の当時価格だけで形成足を更新します。
//
// 引数: b(*Bar)、q(rules.Quote)。返り値: なし。未確定足から信号は発しません。
func updateBar(b *Bar, q rules.Quote) {
	b.OHLC.High = math.Max(b.OHLC.High, q.Last)
	b.OHLC.Low = math.Min(b.OHLC.Low, q.Last)
	b.OHLC.Close = q.Last
	b.Rows++
	b.Last = q
}

// ----------------------------------------
// priorRange は、直前n本の連続確定1分足の高安を求めます。
//
// 引数: history([]Bar)、n(int)、end(float64)。返り値: Rangeは不足や不連続なら未知です。
func priorRange(history []Bar, n int, end float64) Range {
	r := Range{Count: n}
	if len(history) < n || n < 1 {
		return r
	}
	list := history[len(history)-n:]
	r.Start = list[0].Start
	r.End = end
	r.Low = math.Inf(1)
	r.High = math.Inf(-1)
	for i, b := range list {
		if b.End != b.Start+60 || (i > 0 && b.Start != list[i-1].End) {
			return Range{Count: n}
		}
		r.Low = math.Min(r.Low, b.OHLC.Low)
		r.High = math.Max(r.High, b.OHLC.High)
	}
	if list[n-1].End != end {
		return Range{Count: n}
	}
	r.Known = true
	return r
}

// ----------------------------------------
// priorATR は、当足を含めない前14本の既知TR単純平均を返します。
//
// 引数: history([]Bar)、end(float64)は評価当足の開始。返り値: rules.Valueは不足を未知のまま残します。
func priorATR(history []Bar, end float64) rules.Value {
	if !priorRange(history, 14, end).Known {
		return rules.Value{}
	}
	sum := 0.0
	for _, b := range history[len(history)-14:] {
		if !b.TR.Known {
			return rules.Value{}
		}
		sum += b.TR.Value
	}
	return rules.Value{Known: true, Value: sum / 14}
}

// ----------------------------------------
// updateBB は、同場の異なる既知15分公表の幅だけを順序保持します。
//
// 引数: s(rules.Snapshot)。返り値: なし。未知公表は既知の前比較値へ置換しません。
func (d *Detector) updateBB(s rules.Snapshot) {
	p, ok := s.Frames[900]
	if !ok || p.Frame.Frame.ID == d.last15ID {
		return
	}
	d.last15ID = p.Frame.Frame.ID
	if !s.BB15.Known || !p.Frame.Frame.PriceKnown {
		return
	}
	ref := rules.Ref{ID: p.Frame.Frame.ID, Width: 900, End: p.Frame.Frame.End, Delivered: p.Stamp}
	d.previousKnownBB15 = d.lastKnownBB15
	d.lastKnownBB15 = &BandWidth{Width: s.BB15.Upper - s.BB15.Lower, Ref: ref}
}

// ----------------------------------------
// positive は、既知値が売買符号の正側かを判定します。
//
// 引数: v(rules.Value)、side(int)。返り値: boolは未知を真としません。
func positive(v rules.Value, side int) bool { return v.Known && float64(side)*v.Value > 0 }

// ----------------------------------------
// deltaPositive は、前後とも既知の差分が売買符号の正側かを判定します。
//
// 引数: now/previous(rules.Value)、side(int)。返り値: boolです。
func deltaPositive(now, previous rules.Value, side int) bool {
	return now.Known && previous.Known && float64(side)*(now.Value-previous.Value) > 0
}

// ----------------------------------------
// centered は、RSIの中心50からの符号距離が閉区間内かを判定します。
//
// 引数: rsi(rules.Value)、side(int)、low/high(float64)。返り値: boolです。
func centered(rsi rules.Value, side int, low, high float64) bool {
	v := float64(side) * (rsi.Value - 50)
	return rsi.Known && v >= low && v <= high
}

// ----------------------------------------
// trendBackground は、長期配置/両傾きと中期方向/強さの同時成立を判定します。
//
// 引数: s(rules.Snapshot)、side(int)。返り値: boolです。
func trendBackground(s rules.Snapshot, side int) bool {
	t := s.Frames[1800].Frame.Frame.Technical
	d := s.Frames[900].Frame.DMI
	return positive(t.Gap, side) && positive(t.EMA8Delta, side) && positive(t.EMA21Delta, side) && d.PlusDI.Known && d.MinusDI.Known && float64(side)*(d.PlusDI.Value-d.MinusDI.Value) > 0 && d.ADX.Known && d.ADX.Value >= 20
}

// ----------------------------------------
// reverseBackground は、長期が弱い又は直前公表より失速した背景を判定します。
//
// 引数: s(rules.Snapshot)。返り値: boolです。
func reverseBackground(s rules.Snapshot) bool {
	d := s.Frames[1800].Frame.DMI
	return d.ADX.Known && (d.ADX.Value <= 25 || (d.PreviousADX.Known && d.ADX.Value < d.PreviousADX.Value))
}

// ----------------------------------------
// analyze は、確定した当足と当時公表だけから6政策の技術候補を評価します。
//
// 引数: s(rules.Snapshot)、b(Bar)、q(rules.Quote)。返り値: []Event。自然価格による成績は計算しません。
func (d *Detector) analyze(s rules.Snapshot, b Bar, q rules.Quote) []Event {
	if len(s.Missing) > 0 {
		d.stats.PublicationMissing++
		return nil
	}
	for _, w := range []int{300, 900, 1800} {
		if p, ok := s.Frames[w]; !ok || !p.Frame.Frame.PriceKnown {
			d.stats.PublicationMissing++
			return nil
		}
	}
	a1 := priorATR(d.history, b.Start)
	t5 := s.Frames[300].Frame.Frame.Technical
	t15 := s.Frames[900].Frame.Frame.Technical
	if !a1.Known || a1.Value <= 0 {
		d.stats.ATR1Unavailable++
		return nil
	}
	if !b.TR.Known {
		d.stats.CurrentTRUnavailable++
		return nil
	}
	if b.TR.Value > 2*a1.Value {
		d.stats.SpikeRejected++
		return nil
	}
	if !t5.ATR.Known || t5.ATR.Value <= 0 {
		d.stats.ATR5Unavailable++
		return nil
	}
	if b.OHLC.High <= b.OHLC.Low {
		d.stats.RangeRejected++
		return nil
	}
	range5 := priorRange(d.history, 5, b.Start)
	if len(d.history) == 0 {
		return nil
	}
	previous := d.history[len(d.history)-1]
	var events []Event
	for _, policy := range Policies {
		for _, side := range []int{1, -1} {
			sign := float64(side)
			extreme, boundary, location := b.OHLC.Low, previous.OHLC.High, (b.OHLC.Close-b.OHLC.Low)/(b.OHLC.High-b.OHLC.Low)
			if side < 0 {
				extreme, boundary, location = b.OHLC.High, previous.OHLC.Low, (b.OHLC.High-b.OHLC.Close)/(b.OHLC.High-b.OHLC.Low)
			}
			invalidation := extreme - sign*5
			maximumRisk := math.Min(100, .5*t5.ATR.Value)
			risk := sign * (q.Last - invalidation)
			cap := b.OHLC.Close + sign*math.Min(10, .15*t5.ATR.Value)
			key := fmt.Sprintf("%s/%d", policy, side)
			counts := d.stats.Policies[key]
			counts.Considered++
			riskOK, capOK, shapeOK := risk > 0 && risk <= maximumRisk, sign*(q.Last-cap) <= 0, sign*(b.OHLC.Close-b.OHLC.Open) > 0 && location >= .7
			if riskOK {
				counts.RiskPass++
			}
			if capOK {
				counts.CapPass++
			}
			if shapeOK {
				counts.ShapePass++
			}
			base := strings.TrimSuffix(policy, "plus")
			background, structure, extra := false, false, true
			holdBoundary, holdMinimum, holdStrict := rules.Value{Known: true, Value: boundary}, 0.0, true
			bbPrevious := rules.Value{}
			distance := rules.Value{Known: t5.EMA21.Known, Value: sign * (extreme - t5.EMA21.Value)}
			switch base {
			case "P1":
				background = trendBackground(s, side)
				structure = distance.Known && distance.Value >= -t5.ATR.Value && distance.Value <= .25*t5.ATR.Value && sign*(b.OHLC.Close-boundary) > 0
				if policy == "P1plus" {
					extra = (positive(t5.Histogram, side) || deltaPositive(t5.Histogram, t5.PreviousHistogram, side)) && centered(t5.RSI, side, -15, 20) && s.RVOL5.Known && s.RVOL5.Value >= .8
				}
			case "P2":
				band := s.BB15.Lower
				broken := range5.Low
				if side < 0 {
					band = s.BB15.Upper
					broken = range5.High
				}
				holdBoundary, holdMinimum, holdStrict = rules.Value{Known: range5.Known, Value: broken}, 5, false
				background = reverseBackground(s)
				structure = s.BB15.Known && sign*(extreme-band) <= 0 && centered(t15.RSI, side, math.Inf(-1), -15) && range5.Known && sign*(extreme-broken) < 0 && sign*(b.OHLC.Close-broken) >= 5 && b.OHLC.Close >= range5.Low && b.OHLC.Close <= range5.High
				if policy == "P2plus" {
					extra = deltaPositive(t5.Histogram, t5.PreviousHistogram, side) && deltaPositive(t5.RSI, t5.PreviousRSI, side) && s.RVOL5.Known && s.RVOL5.Value >= 1
				}
			case "P3":
				p15 := s.Frames[900].Frame.Frame
				if d.previousKnownBB15 != nil && d.lastKnownBB15 != nil && d.lastKnownBB15.Ref.ID == p15.ID {
					bbPrevious = rules.Value{Known: true, Value: d.previousKnownBB15.Width}
				}
				edge := range5.High
				if side < 0 {
					edge = range5.Low
				}
				holdBoundary = rules.Value{Known: range5.Known, Value: edge}
				background = trendBackground(s, side)
				structure = s.BB15.Known && bbPrevious.Known && s.BB15.Upper-s.BB15.Lower < bbPrevious.Value && range5.Known && range5.High-range5.Low <= .75*t5.ATR.Value && sign*(b.OHLC.Close-edge) > 0
				if policy == "P3plus" {
					extra = positive(t5.Histogram, side) && centered(t5.RSI, side, 0, 20) && s.RVOL5.Known && s.RVOL5.Value >= 1
				}
			}
			if background {
				counts.BackgroundPass++
			}
			if structure {
				counts.StructurePass++
			}
			if extra {
				counts.ExtraPass++
			}
			holdGap := sign * (q.Last - holdBoundary.Value)
			holdOK := holdBoundary.Known && ((holdStrict && holdGap > holdMinimum) || (!holdStrict && holdGap >= holdMinimum))
			if holdOK {
				counts.HoldPass++
			}
			if !(riskOK && capOK && shapeOK && background && structure && extra && holdOK) {
				d.stats.Policies[key] = counts
				continue
			}
			counts.AllGatesPass++
			if last, ok := d.lastSignals[key]; ok && q.Time-last < 300 {
				counts.CooldownRejected++
				d.stats.Policies[key] = counts
				continue
			}
			counts.Births++
			d.stats.Births++
			d.stats.Policies[key] = counts
			d.sequence++
			fields := map[string]rules.Value{"atr5": t5.ATR, "atr1_before14": a1, "min1_tr": b.TR, "min1_range": {Known: true, Value: b.OHLC.High - b.OHLC.Low}, "min1_close_position": {Known: true, Value: location}, "min1_body_signed": {Known: true, Value: sign * (b.OHLC.Close - b.OHLC.Open)}, "maximum_risk": {Known: true, Value: maximumRisk}, "risk_at_last": {Known: true, Value: risk}, "previous1_boundary": {Known: true, Value: boundary}, "extreme_ema21_5_signed": distance, "bb15_width": {Known: s.BB15.Known, Value: s.BB15.Upper - s.BB15.Lower}, "previous_known_bb15_width": bbPrevious, "rvol5": s.RVOL5, "rsi5": t5.RSI, "previous_rsi5": t5.PreviousRSI, "hist5": t5.Histogram, "previous_hist5": t5.PreviousHistogram, "rsi15": t15.RSI, "gap30": s.Frames[1800].Frame.Frame.Technical.Gap, "ema8_delta30": s.Frames[1800].Frame.Frame.Technical.EMA8Delta, "ema21_delta30": s.Frames[1800].Frame.Frame.Technical.EMA21Delta, "adx15": s.Frames[900].Frame.DMI.ADX, "plus_di15": s.Frames[900].Frame.DMI.PlusDI, "minus_di15": s.Frames[900].Frame.DMI.MinusDI, "adx30": s.Frames[1800].Frame.DMI.ADX, "previous_adx30": s.Frames[1800].Frame.DMI.PreviousADX}
			strictNumber := 0.0
			if holdStrict {
				strictNumber = 1
			}
			fields["hold_boundary"], fields["hold_minimum"], fields["hold_strict"], fields["hold_gap_at_birth"] = holdBoundary, knownValue(holdMinimum), knownValue(strictNumber), knownValue(holdGap)
			refs := append([]rules.Ref{}, s.Refs...)
			if base == "P3" && d.previousKnownBB15 != nil {
				refs = append(refs, d.previousKnownBB15.Ref)
			}
			events = append(events, Event{ID: fmt.Sprintf("%s/%s/%d/%06d", d.scope.SessionID, policy, side, d.sequence), Scope: d.scope, Policy: policy, Side: side, At: q, Bar: b, PreviousFiveRange: range5, Refs: refs, Fields: fields, EntryCap: cap, Invalidation: invalidation})
			d.lastSignals[key] = q.Time
		}
	}
	return events
}

// ----------------------------------------
// knownValue は、内部計算済みの有限値を保存用の既知値へ包みます。
//
// 引数: value(float64)。返り値: rules.Valueです。
func knownValue(value float64) rules.Value { return rules.Value{Known: true, Value: value} }

// ----------------------------------------
// Observe は、採用済み原行の価格時計順に1分を確定し技術候補を一度だけ返します。
//
// 引数: bank(*rules.Bank)は当原行までの公表、q(rules.Quote)は当時価格です。
// 返り値: []Event/error。同一原行再読は冪等、欠分は補間せず、確定から30秒超の信号を発しません。
func (d *Detector) Observe(bank *rules.Bank, q rules.Quote) ([]Event, error) {
	if bank == nil || d.scope.SessionID == "" {
		return nil, fmt.Errorf("場開始又はbankがありません")
	}
	s, err := bank.Current(q)
	if err != nil {
		return nil, err
	}
	if s.SessionID != d.scope.SessionID || s.Contract != d.scope.Contract {
		return nil, fmt.Errorf("公表と発生器の場又は限月差")
	}
	if d.last != nil {
		if q.Index == d.last.Index {
			if q != *d.last {
				return nil, fmt.Errorf("同原行の改変")
			}
			return nil, nil
		}
		if q.Index < d.last.Index || q.Line <= d.last.Line || q.Time < d.last.Time {
			return nil, fmt.Errorf("原行順が逆転")
		}
	}
	d.updateBB(s)
	d.stats.RawRows++
	currentStart := math.Floor(q.Time/60) * 60
	if d.last != nil && q.Time-d.last.Time > 60 {
		d.stats.RawGapResets++
		if d.current != nil && currentStart != d.current.End && currentStart != d.current.Start {
			d.stats.GapResets++
		}
		d.history = nil
		d.current = makeBar(q)
		v := q
		d.last = &v
		return nil, nil
	}
	var events []Event
	if d.current == nil {
		d.current = makeBar(q)
	} else if currentStart == d.current.Start {
		updateBar(d.current, q)
	} else {
		b := *d.current
		d.stats.ClosedMinuteBars++
		if q.Time-b.End > 30 {
			d.stats.StaleClosures++
		}
		if currentStart != b.End {
			d.history = nil
			d.stats.GapResets++
		} else {
			if len(d.history) > 0 {
				previous := d.history[len(d.history)-1]
				b.TR = rules.Value{Known: true, Value: math.Max(b.OHLC.High-b.OHLC.Low, math.Max(math.Abs(b.OHLC.High-previous.OHLC.Close), math.Abs(b.OHLC.Low-previous.OHLC.Close)))}
			}
			if q.Time-b.End <= 30 {
				d.stats.EligibleClosures++
				events = d.analyze(s, b, q)
			}
			d.history = append(d.history, b)
			if len(d.history) > 20 {
				d.history = append([]Bar{}, d.history[len(d.history)-20:]...)
			}
		}
		d.current = makeBar(q)
	}
	v := q
	d.last = &v
	return events, nil
}
