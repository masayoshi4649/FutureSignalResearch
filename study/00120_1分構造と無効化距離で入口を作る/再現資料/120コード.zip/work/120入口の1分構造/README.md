# 120：1分構造からの技術的な入口候補

自然Raw・Native・市場結果を読まずに作る純条件モジュール。6政策を同条件の買い/売りで評価する。Source通知・固定5分/15分の新規時計は用いず、確定した1分構造が条件を満たす場合だけ候補を返す。70%の先着率や収益は未証明。

```go
detector := entrybirth120.NewDetector()
detector.StartSession(sessionID, contract)
events, err := detector.Observe(bank, quote)
stats := detector.Stats()
```

`bank`は118の`entryrules118.Bank`、`quote`は`rules.Quote`。Rootは当原行までに実配送された115公表をbankへ追加してからObserveする。`StartSession`は1分履歴・BB比較・クールダウンをすべてresetする。Scope不一致、Index/物理行/価格時計の逆転、同Index改変を拒否し、同じ原行の再読は冪等とする。

## 形成・共通条件

Raw採用行のLastをUTCの`floor(Time/60)*60`へ区分し、次minute最初のRawで直前1分を確定する。境界の原行は次足へ属し、確定までの高安終値へ混入させない。空足は補間せず、非連続minuteなら前履歴を破棄し、そのRawで信号を出さない。履歴は当場最大20本、信号は確定足Endから30秒以内（等号可）。最終足は次Rawがなければ確定しない。

Raw採用行の価格時計差が60秒を超えれば、隣接minuteであっても1分履歴と形成中足を破棄し、当Rawを新しい形成開始とする。直後の候補は発しない。5/15/30分bankの数値窓や評価側300秒打切りとは別の、入口1分構造の品質条件。60秒等号はresetしない。

TRは高安差、前1分終値との高/安差の最大。当場最初又は欠分後最初の確定足は前close不足のためTR未知。前ATR1は当足を含めない直前14本の既知TR単純平均とし、14本不足・未知・0以下は候補を出さない。通常は16本目の確定1分以後に初めてATR条件がそろう。

当確定1分のTR≤2×前ATR1、range>0。5/15/30分は118と同じ当場・価格既知・fresh・公表配送済みを要求する。三足のどれかが未知/古ければ候補なし。5分ATRは既知かつ正であること。全政策で順側実体>0、終値の順側位置≥.7を要求する。

自然無効化価格は買い当1分Low−5pt、売りHigh+5pt。現在Lastから無効化までの符号距離は`0<risk≤min(100pt,.5×ATR5)`。追い過ぎcapは買い当1分Close+min(10pt,.15×ATR5)、売りは鏡像で、出生RawのLast自体がcapを超えれば候補なし。各policy/sideの出生から300秒は再出生しない。300秒等号は可。

## 政策

|政策|背景と1分構造|追加確認|
|---|---|---|
|P1|30分EMA8/21配置と両傾きが順側、15分DI差が順側かつADX≥20。逆側1分極値のEMA21_5からの符号距離が[−ATR5,+.25ATR5]。終値が前1分の順側高安をstrict突破|なし|
|P1plus|P1|5分Histが順側又はHist増分が順側、RSI買い35〜70/売り30〜65、RVOL5≥.8|
|P2|30分ADX≤25又は前公表より低下。逆側1分極値が15分BB20±2母σへ接触し、15分RSI買い≤35/売り≥65。極値が前5本1分rangeを逆側へstrict突破、終値がレンジ内へ境界から5pt以上回復|なし|
|P2plus|P2|5分Hist増分とRSI増分が順側、RVOL5≥1|
|P3|P1と同じ背景。現在BB15幅が同場の直前known15分公表より縮小。前5本1分range≤.75ATR5、当終値がその順側端をstrict突破|なし|
|P3plus|P3|5分Hist順側、RSI買い50〜70/売り30〜50、RVOL5≥1|

RSI水準と増分、EMA配置と傾きは別条件。BB幅比較はdistinctな同場の既知15分公表に限り、初回は前幅不足、同ID再観測では比較を進めない。未知公表は直前knownを置換せず、次のknownと比較する。前5本rangeとATR1は確定当足を含まない。

回復済み1分終値だけで発注しない。出生Rawの現在Lastも、P1は前1分順側高安をstrict維持、P2は前5本逆側境界から順側5pt以上、P3は前5本順側端をstrict維持する。`Fields[hold_boundary]`、`[hold_minimum]`（0又は5）、`[hold_strict]`（1又は0）、`[hold_gap_at_birth]`へ記録する。Rootは実行候補の次Rawでも同条件を再確認する。

## 返り値と責務

Eventは`ID/Scope/Policy/Side/At/Bar/PreviousFiveRange/Refs/Fields/EntryCap/Invalidation`を値複写して保存。1分OHLC/TR/物理行、直前5本range、5/15/30公表Ref、P3の前known15分Ref、ATR・量・勢い・リスク・維持境界を残す。`Fields[atr5]`は必ず既知正数。

このモジュールはBBO・新規約定・注文寿命・ForceClose・手数料・損益を計算しない。Rootは要求より後Rawかつ1秒後、30秒寿命、正常BBO、entry cap、実取得から自然無効化までの距離、現在Lastのholdを再確認する。候補は独立1mini試験で、重複ケースを運用口座収支へ合計しない。

`Stats()`と`Snapshot().Stats`は私有コピー。RawRows、閉鎖足数、欠分reset、RawGapResets、遅れ、利用可能閉鎖足、各品質不足、出生数を返す。RawGapResetsは形成中足を閉鎖せず破棄する。欠分も伴えばGapResetsも加算する。品質拒否は公表→前ATR1→当TR→スパイク→ATR5→rangeの順で最初の理由を数える。各reset/遅れは排他的な集計ではない。

`Policies`は`P1/1`等の12キーを初期0で持つ。品質を通過した同一Consideredを分母に、ShapePass/RiskPass/CapPass/HoldPass/BackgroundPass/StructurePass/ExtraPassを**独立に**数える。順番に落ちた累積通過率ではない。AllGatesPassは全条件AND、そこからCooldownRejectedとBirthsを区別する。plusなしのExtraPassは追加条件なしとして全件通過。

```powershell
go test -count=1 -v ./...
go vet ./...
go build ./...
```

人工9主テストで因果確定・欠足・隣接分87秒Raw欠測・30秒/60秒/300秒等号・前ATR当足除外・買売鏡像6政策・未知拒否・fresh期限・cap/距離・BB既知前史・現在hold・参照分離・統計分母を確認する。自然市場は未実行であり、この人工成功を入口精度の証拠としない。
