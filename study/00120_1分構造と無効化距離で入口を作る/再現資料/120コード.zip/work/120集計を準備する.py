"""固定済み119の集計関数を再用し120のイベント形式へ適応する。"""
from pathlib import Path
import hashlib

ROOT = Path(__file__).resolve().parent.parent


def main() -> None:
    """
    機能: 120の結果を読まず、独立比較・表出力のコードを新規保存する。
    引数: なし。返り値: None。119の固定ファイルは変更しない。
    """
    source = ROOT / 'work/119入口比較/集計する.py'
    text = source.read_text(encoding='utf-8')
    prefix = text[:text.index('def validate(')]
    stats = text[text.index('def stats('):text.index('def main()')]
    stats = stats.replace("b = baseline[(c['session'], c['birth']['id'])]", "b = baseline.get((c['session'], c['family'], c['bar_end'], c['birth']['side']))\n        if b is None:\n            continue")
    stats = stats.replace('paired_zone_mean_net5','paired_base_mean_net5')
    validate = '''def validate(c: dict, scene: dict) -> int:
    """
    機能: 1分構造・公表参照・取得cap/無効化距離と期限算術を照合する。
    引数: c/scene(dict)。返り値: intは完了期限数。Raw再走査は行わない。
    """
    event = scene['events'][c['event']]
    assert event['id'] == c['birth']['id'] and event['policy'] == c['policy'] and event['side'] == c['birth']['side']
    assert event['bar']['end'] <= event['at']['time'] <= event['bar']['end'] + 30
    for ref in event['refs']:
        assert ref['end'] <= event['at']['time'] and ref['delivered']['time'] <= event['at']['time'] and ref['delivered']['index'] <= event['at']['index'] and ref['delivered']['source_line'] <= event['at']['source_line']
    if c['entry'] is None:
        assert c['entry_price'] is None and not c['outcomes'] and c['status'] != 'filled'
        return 0
    q, request, side = c['entry'], c['request'], c['birth']['side']
    assert c['status'] == 'filled' and q['quote_ok'] and 0 < q['bid'] < q['ask']
    assert q['index'] > request['index'] and q['source_line'] > request['source_line'] and q['time'] >= request['time'] + 1 and q['time'] < c['expires']
    assert c['entry_price'] == (q['ask'] if side == 1 else q['bid'])
    assert side * (c['entry_price'] - event['entry_cap']) <= 0
    risk = side * (c['entry_price'] - event['invalidation'])
    assert 0 < risk <= min(100, .5 * event['fields']['atr5']['value'])
    checked = 0
    assert [o['seconds'] for o in c['outcomes']] == list(HORIZONS)
    for o in c['outcomes']:
        assert o['deadline'] == q['time'] + o['seconds']
        for t in o['touches']:
            assert t['direction'] in (-1, 0, 1)
            if not t['direction']:
                assert t['quote'] is None
            else:
                p = t['quote']
                assert p['index'] > q['index'] and p['source_line'] > q['source_line'] and q['time'] <= p['time'] <= o['deadline']
                assert t['direction'] * side * ((p['bid'] if side == 1 else p['ask']) - c['entry_price']) >= t['width']
                if o['endpoint']:
                    assert p['index'] <= o['endpoint']['index']
        if o['status'] == 'complete':
            e = o['endpoint']
            assert o['deadline'] <= e['time'] <= o['deadline'] + 30 and e['quote_ok'] and 0 < e['bid'] < e['ask']
            points = side * ((e['bid'] if side == 1 else e['ask']) - c['entry_price'])
            assert (o['points'], o['net0'], o['net5']) == (points, points * 100 - 77, points * 100 - 1077)
            checked += 1
        else:
            assert all(o[k] is None for k in ('endpoint', 'points', 'net0', 'net5'))
    return checked


'''
    body = text[text.index('def main()'):]
    body = body.replace('119','120')
    body = body.replace("rows, events, checked = [], Counter(), 0","rows, events, checked = [], Counter(), 0")
    body = body.replace("events.update(e['kind'] for e in scene['events'])","events.update(e['policy'] for e in scene['events'])")
    body = body.replace("c['session'] = scene['session']", "c['session'] = scene['session']\n            event = scene['events'][c['event']]\n            c['family'] = c['policy'].removesuffix('plus')\n            c['bar_end'] = event['bar']['end']\n            c['mode'] = c['family']\n            c['role'] = '追加確認' if c['policy'].endswith('plus') else '構造背景'\n            c['limit'] = None")
    body = body.replace("assert len(rows) == 3 * events['zone']","assert len(rows) == sum(events.values())")
    body = body.replace("baseline = {(c['session'], c['birth']['id']): c for c in rows if c['role'] == 'zone'}", "baseline = {(c['session'], c['family'], c['bar_end'], c['birth']['side']): c for c in rows if not c['policy'].endswith('plus')}")
    body = body.replace('同組領域入口','同組基本入口').replace('paired_zone_mean_net5','paired_base_mean_net5')
    body = body.replace("'参考二項区間の独立性':", "'元集計コードSHA256': 'SOURCE_SHA', '参考二項区間の独立性':")
    body = body.replace('SOURCE_SHA',hashlib.sha256(source.read_bytes()).hexdigest())
    body = body.replace("'方式','出生ID','方向','役割'", "'構造','出生ID','方向','確認段階'")
    out = ROOT / 'work/120入口比較/集計する.py'
    with out.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(prefix.replace('技術領域','1分構造')+validate+stats+body)
    print('120集計コードを準備。市場結果未読。')


if __name__=='__main__':
    main()
