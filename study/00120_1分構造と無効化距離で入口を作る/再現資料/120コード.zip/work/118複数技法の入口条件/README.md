# 118の複数技法による入口待機・確認

Go 1.24標準のみの純モジュール。自然市場、原板、Native、CSV、11月09は読まない。閾値は未検証の研究仮説であり、収益性や最適性を主張しない。Root側がSource候補、価格cap、期限、Raw配送、指値と実約定を担当する。

```go
bank := entryrules118.NewBank()
// 同限月の過去公表を時系列でAdd又はSeedFromPriorする。
bank.StartSession(sessionID, contract)
bank.Add(publication)
decision, err := bank.Evaluate(entryrules118.Thybrid, side, quote, &watch)
```

APIは `NewBank() *Bank`、`StartSession(sessionID,contract string) error`、`SeedFromPrior([]Publication) error`、`Add(Publication) error`、`Current(Quote) (Snapshot,error)`、`Evaluate(Mode,side int相当,Quote,*Watch) (Decision,error)`。実際のEvaluateのside型はint。ValueのKnownを保ち、TruthはUnknown=0/False=1/True=2。同IDの全値不変再配送は冪等、改変・足別時系列逆転は拒否する。

全枝で5/15/30分の当場価格既知公表が必要。公表のEnd/AvailableAt/DeliveryAtと配送Stampが要求以前で、`要求時刻 < End+足幅+60秒` を満たす当時最新を使う。未来公表は除外し、その前の公表へ戻って選択する。同秒でもIndexと物理行を検査する。Startは足開始と仮定しない。

数値窓は幅別。BB15は直近20公表終値の平均±2母標準偏差。RVOL5は当公表出来高を、その足を含まない直前20公表の平均出来高で割る。20本不足・窓内未知・分母0は未知。未知を飛ばしたり0へ補わない。同場の足Endが非連続なら当該幅窓を切る。StartSessionは前場latestを消して同限月の数値窓だけcarryし、限月変更では全窓を消す。

Ttrendの背景は30分の売買符号付きgap/EMA8傾き/EMA21傾きがすべて正、15分の符号付きDI差が正かつADX>=20。待機領域は5分ATR>0で `−ATR <= side*(Last−EMA21) <= 0.25ATR`。

Treversalの背景は30分ADX<=25 **又は** 前ADXからstrict低下。待機領域は買いLast<=15分BB下限、売りLast>=上限で、符号付き(RSI15−50)<=−15。

Watchは枝ごとに背景と待機領域がともに真になった初回Quoteを固定する。Thybridは2枝を並行更新する。確認は接触より後のIndexかつ物理行（同秒可）で、当場最新5分足のEndが接触Timeをstrictに超え、Lastが当足Highをstrict超過（買い）又はLowをstrict割れ（売り）。前ATR5>0、TR5<=2×前ATR5を共通に要求する。Ttrendは符号付きHist5>0、符号付き(RSI5−50)が0以上20以下、RVOL>=0.8。Treversalは符号付きHist差とRSI差がともに正、RVOL>=1。

確認時は背景を再検査する。領域への初回接触を記憶するため、突破時にも押戻し領域の現在位置を要求することはない。同一足の過去の接触前公表で確認しない。Watchの接触は書換えず、場/限月/sideを混ぜない。期限や50pt有利価格capは含めない。新しいSource候補には新Watchを渡す。

Missingと既知否定Reasonを分ける。否定がある三値ANDは偽、真があるORは真。ATR=0は既知否定、未知ATRと区別する。返す枝別TouchとSnapshotRefsは値複写し、Bank内部の窓へ参照を公開しない。

```powershell
go test -count=1 ./...
go vet ./...
go build ./...
```

人工5主は買売鏡像、接触後Raw/別確定足、反転の勢い差と水準の区別、三値OR、母BB20/前20量、未知量、同限月carry/異限月reset、欠足、未来公表除外、同ID改変、fresh等号、ATR0/未知を確認する。金融・指値約定・Raw最初性の検査ではない。
