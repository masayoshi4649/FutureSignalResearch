package entryrules118

import (
	"fmt"
	"math"
)

type sample struct {
	close  Value
	volume Value
}

type published struct {
	pub  Publication
	bb   Bands
	rvol Value
}

type Bank struct {
	session  string
	contract string
	windows  map[int][]sample
	last     map[int]Publication
	current  map[int][]published
	seen     map[string]Publication
}

// NewBank は、未知を補完しない公表窓を初期化します。
//
// 引数: なし。返り値: *Bankは空の状態です。
func NewBank() *Bank {
	return &Bank{windows: map[int][]sample{}, last: map[int]Publication{}, current: map[int][]published{}, seen: map[string]Publication{}}
}

// StartSession は、当場公表を消し同限月の数値窓だけを継承します。
//
// 引数: sessionID/contract(string)は当場と限月。返り値: errorは空識別子です。
func (b *Bank) StartSession(sessionID, contract string) error {
	if sessionID == "" || contract == "" {
		return fmt.Errorf("場/限月が空です")
	}
	if b.contract != "" && b.contract != contract {
		b.windows = map[int][]sample{}
		b.last = map[int]Publication{}
		b.seen = map[string]Publication{}
	}
	b.session, b.contract, b.current = sessionID, contract, map[int][]published{}
	return nil
}

// SeedFromPrior は、同限月の過去公表を時系列に受け取り数値窓を作ります。
//
// 引数: pubs([]Publication)は既知の過去公表。返り値: errorはAdd違反です。
func (b *Bank) SeedFromPrior(pubs []Publication) error {
	for _, p := range pubs {
		if err := b.Add(p); err != nil {
			return err
		}
	}
	return nil
}

// finite は、有限値を判定します。
//
// 引数: v(float64)。返り値: boolは有限なら真です。
func finite(v float64) bool { return !math.IsNaN(v) && !math.IsInf(v, 0) }

// validValue は、既知の数値だけ有限であることを検査します。
//
// 引数: v(Value)。返り値: boolです。未知値を既知0へ変えません。
func validValue(v Value) bool { return !v.Known || finite(v.Value) }

// validPublication は、公表時点と値の型を検査します。
//
// 引数: p(Publication)。返り値: errorは不正公表です。
func validPublication(p Publication) error {
	f := p.Frame.Frame
	if f.ID == "" || f.SessionID == "" || f.Contract == "" || (f.Width != 300 && f.Width != 900 && f.Width != 1800) {
		return fmt.Errorf("公表識別/足幅が不正です")
	}
	if p.Stamp.Index < 0 || p.Stamp.Line < 1 || !finite(p.Stamp.Time) || !finite(f.Start) || !finite(f.End) || !finite(f.AvailableAt) || !finite(f.DeliveryAt) || f.Start > f.End || f.End > f.AvailableAt || f.AvailableAt > f.DeliveryAt || f.DeliveryAt > p.Stamp.Time {
		return fmt.Errorf("公表の因果時計が不正です")
	}
	if f.PriceKnown && (!finite(f.OHLC.Open) || !finite(f.OHLC.High) || !finite(f.OHLC.Low) || !finite(f.OHLC.Close) || f.OHLC.Low <= 0 || f.OHLC.High < f.OHLC.Low || f.OHLC.Open < f.OHLC.Low || f.OHLC.Open > f.OHLC.High || f.OHLC.Close < f.OHLC.Low || f.OHLC.Close > f.OHLC.High) {
		return fmt.Errorf("既知OHLCが不正です")
	}
	if f.VolumeKnown && (!finite(f.Volume) || f.Volume < 0) {
		return fmt.Errorf("既知出来高が不正です")
	}
	t := f.Technical
	d := p.Frame.DMI
	for _, v := range []Value{t.EMA8, t.EMA21, t.EMA8Delta, t.EMA21Delta, t.Gap, t.ATR, t.PreviousATR, t.TR, t.RSI, t.PreviousRSI, t.Histogram, t.PreviousHistogram, d.PlusDI, d.MinusDI, d.ADX, d.PreviousADX} {
		if !validValue(v) {
			return fmt.Errorf("既知技法値が非有限です")
		}
	}
	return nil
}

// bands は、20公表終値の母標準偏差からBBを求めます。
//
// 引数: window([]sample)。返り値: Bandsは不足/未知を未知で保持します。
func bands(window []sample) Bands {
	r := Bands{Count: len(window)}
	if len(window) != 20 {
		return r
	}
	origin := window[0].close.Value
	sum := 0.0
	for _, v := range window {
		if !v.close.Known {
			return r
		}
		sum += v.close.Value - origin
	}
	mean := sum / 20
	variance := 0.0
	for _, v := range window {
		d := (v.close.Value - origin) - mean
		variance += d * d
	}
	r.Known = true
	r.Mean = origin + mean
	r.Sigma = math.Sqrt(variance / 20)
	r.Upper = r.Mean + 2*r.Sigma
	r.Lower = r.Mean - 2*r.Sigma
	return r
}

// relativeVolume は、当公表の量をその前20公表の平均量で割ります。
//
// 引数: previous([]sample)、now(Value)。返り値: Valueは既知0分母も未知です。
func relativeVolume(previous []sample, now Value) Value {
	if len(previous) != 20 || !now.Known {
		return Value{}
	}
	sum := 0.0
	for _, p := range previous {
		if !p.volume.Known {
			return Value{}
		}
		sum += p.volume.Value
	}
	if sum <= 0 {
		return Value{}
	}
	return Value{Known: true, Value: now.Value / (sum / 20)}
}

// Add は、公表を一度だけ取り込み同ID改変/時系列逆転を拒否します。
//
// 引数: p(Publication)は配送済み足。返り値: error。同場の欠足は窓を切り、場間は数値だけ継承します。
func (b *Bank) Add(p Publication) error {
	if err := validPublication(p); err != nil {
		return err
	}
	f := p.Frame.Frame
	if b.contract == "" {
		b.contract = f.Contract
	}
	if b.contract != f.Contract {
		return fmt.Errorf("異限月の公表です")
	}
	key := fmt.Sprintf("%s/%d/%s", f.SessionID, f.Width, f.ID)
	if old, ok := b.seen[key]; ok {
		if old != p {
			return fmt.Errorf("同ID公表の改変です")
		}
		return nil
	}
	if old, ok := b.last[f.Width]; ok {
		o := old.Frame.Frame
		if f.End <= o.End || p.Stamp.Time < old.Stamp.Time {
			return fmt.Errorf("公表時系列が逆転しました")
		}
		if f.SessionID == o.SessionID {
			if p.Stamp.Index < old.Stamp.Index || p.Stamp.Line < old.Stamp.Line {
				return fmt.Errorf("同場の原行順が逆転しました")
			}
			if f.End-o.End != float64(f.Width) {
				b.windows[f.Width] = nil
			}
		}
	}
	w := b.windows[f.Width]
	now := sample{close: Value{Known: f.PriceKnown, Value: f.OHLC.Close}, volume: Value{Known: f.VolumeKnown, Value: f.Volume}}
	rv := relativeVolume(w, now.volume)
	w = append(w, now)
	if len(w) > 20 {
		w = append([]sample(nil), w[len(w)-20:]...)
	}
	b.windows[f.Width] = w
	x := published{pub: p, rvol: rv}
	if f.Width == 900 {
		x.bb = bands(w)
	}
	b.last[f.Width] = p
	b.seen[key] = p
	if f.SessionID == b.session {
		b.current[f.Width] = append(b.current[f.Width], x)
	}
	return nil
}

// Current は、要求原行以前の当場freshな5/15/30分を選びます。
//
// 引数: q(Quote)は現在原行。返り値: Snapshot/error。未来公表を選ばず不足理由を明示します。
func (b *Bank) Current(q Quote) (Snapshot, error) {
	s := Snapshot{SessionID: b.session, Contract: b.contract, AsOf: q, Frames: map[int]Publication{}}
	if b.session == "" || b.contract == "" || q.Index < 0 || q.Line < 1 || !finite(q.Time) || !finite(q.Last) || q.Last <= 0 {
		return s, fmt.Errorf("要求原行/場が不正です")
	}
	for _, width := range []int{300, 900, 1800} {
		list := b.current[width]
		found := false
		for i := len(list) - 1; i >= 0; i-- {
			x := list[i]
			p := x.pub
			f := p.Frame.Frame
			if p.Stamp.Time > q.Time || p.Stamp.Index > q.Index || p.Stamp.Line > q.Line || f.DeliveryAt > q.Time || f.AvailableAt > q.Time || f.End > q.Time {
				continue
			}
			if q.Time >= f.End+float64(width)+60 {
				s.Missing = append(s.Missing, fmt.Sprintf("%d分公表が期限切れ", width/60))
				found = true
				break
			}
			s.Frames[width] = p
			s.Refs = append(s.Refs, Ref{ID: f.ID, Width: width, End: f.End, Delivered: p.Stamp})
			if width == 300 {
				s.RVOL5 = x.rvol
			}
			if width == 900 {
				s.BB15 = x.bb
			}
			if !f.PriceKnown {
				s.Missing = append(s.Missing, fmt.Sprintf("%d分価格が未知", width/60))
			}
			found = true
			break
		}
		if !found {
			s.Missing = append(s.Missing, fmt.Sprintf("%d分当場公表が不足", width/60))
		}
	}
	return s, nil
}
