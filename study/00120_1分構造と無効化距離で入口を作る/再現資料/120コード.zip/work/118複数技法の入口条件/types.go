// Package entryrules118 は、公表済み複数技法の待機領域と後続確認を分離します。
package entryrules118

type Truth uint8

const (
	Unknown Truth = iota
	False
	True
)

type Mode string

const (
	Ttrend    Mode = "Ttrend"
	Treversal Mode = "Treversal"
	Thybrid   Mode = "Thybrid"
)

type Value struct {
	Known bool    `json:"known"`
	Value float64 `json:"value"`
}

type Stamp struct {
	Time  float64 `json:"time"`
	Index int     `json:"index"`
	Line  int     `json:"source_line"`
}

type Quote struct {
	Time  float64 `json:"time"`
	Index int     `json:"index"`
	Line  int     `json:"source_line"`
	Last  float64 `json:"last"`
}

type OHLC struct {
	Open  float64 `json:"open"`
	High  float64 `json:"high"`
	Low   float64 `json:"low"`
	Close float64 `json:"close"`
}

type Technical struct {
	EMA8              Value `json:"ema8"`
	EMA21             Value `json:"ema21"`
	EMA8Delta         Value `json:"ema8_delta"`
	EMA21Delta        Value `json:"ema21_delta"`
	Gap               Value `json:"gap"`
	ATR               Value `json:"atr"`
	PreviousATR       Value `json:"previous_atr"`
	TR                Value `json:"tr"`
	RSI               Value `json:"rsi"`
	PreviousRSI       Value `json:"previous_rsi"`
	Histogram         Value `json:"histogram"`
	PreviousHistogram Value `json:"previous_histogram"`
}

type ChartFrame struct {
	ID          string    `json:"id"`
	SessionID   string    `json:"session_id"`
	Contract    string    `json:"contract"`
	Width       int       `json:"width_seconds"`
	Start       float64   `json:"start"`
	End         float64   `json:"end"`
	AvailableAt float64   `json:"available_at"`
	DeliveryAt  float64   `json:"delivery_at"`
	PriceKnown  bool      `json:"price_known"`
	VolumeKnown bool      `json:"volume_known"`
	OHLC        OHLC      `json:"ohlc"`
	Volume      float64   `json:"volume"`
	Technical   Technical `json:"technical"`
}

type DMI struct {
	PlusDI      Value `json:"plus_di"`
	MinusDI     Value `json:"minus_di"`
	ADX         Value `json:"adx"`
	PreviousADX Value `json:"previous_adx"`
}

type Frame struct {
	Frame ChartFrame `json:"frame"`
	DMI   DMI        `json:"dmi"`
}

type Publication struct {
	Stamp Stamp `json:"stamp"`
	Frame Frame `json:"frame"`
}

type Ref struct {
	ID        string  `json:"id"`
	Width     int     `json:"width_seconds"`
	End       float64 `json:"end"`
	Delivered Stamp   `json:"delivered"`
}

type Bands struct {
	Known bool    `json:"known"`
	Mean  float64 `json:"mean"`
	Sigma float64 `json:"sigma"`
	Upper float64 `json:"upper"`
	Lower float64 `json:"lower"`
	Count int     `json:"count"`
}

type Snapshot struct {
	SessionID string              `json:"session_id"`
	Contract  string              `json:"contract"`
	AsOf      Quote               `json:"asof"`
	Frames    map[int]Publication `json:"frames"`
	Refs      []Ref               `json:"refs"`
	Missing   []string            `json:"missing"`
	BB15      Bands               `json:"bb15"`
	RVOL5     Value               `json:"rvol5"`
}

type ZoneTouch struct {
	At     Quote `json:"at"`
	Frame5 Ref   `json:"frame5"`
}

type Watch struct {
	SessionID string     `json:"session_id"`
	Contract  string     `json:"contract"`
	Side      int        `json:"side"`
	Trend     *ZoneTouch `json:"trend,omitempty"`
	Reversal  *ZoneTouch `json:"reversal,omitempty"`
}

type Branch struct {
	Background Truth      `json:"background"`
	Zone       Truth      `json:"zone"`
	Confirm    Truth      `json:"confirm"`
	Truth      Truth      `json:"truth"`
	Touch      *ZoneTouch `json:"touch,omitempty"`
	Missing    []string   `json:"missing"`
	Denied     []string   `json:"denied"`
}

type Decision struct {
	Mode         Mode             `json:"mode"`
	Side         int              `json:"side"`
	At           Quote            `json:"at"`
	Truth        Truth            `json:"truth"`
	Missing      []string         `json:"missing"`
	Reason       []string         `json:"reason"`
	Zone         Truth            `json:"zone"`
	Confirm      Truth            `json:"confirm"`
	Trend        Branch           `json:"trend"`
	Reversal     Branch           `json:"reversal"`
	Fields       map[string]Value `json:"fields"`
	SnapshotRefs []Ref            `json:"snapshotrefs"`
}
