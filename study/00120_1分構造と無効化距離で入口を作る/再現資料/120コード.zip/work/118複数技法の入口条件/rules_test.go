package entryrules118

import (
	"fmt"
	"math"
	"testing"
)

// known は、人工の既知値を構築します。
//
// 引数: v(float64)。返り値: Valueです。
func known(v float64) Value { return Value{Known: true, Value: v} }

// fixture は、売買鏡像の人工公表を作ります。
//
// 引数: width/index/side(int)、end(float64)、session(string)。返り値: Publicationです。
func fixture(width, index, side int, end float64, session string) Publication {
	s := float64(side)
	f := ChartFrame{ID: fmt.Sprintf("%s-%d-%g", session, width, end), SessionID: session, Contract: "K", Width: width, Start: 0, End: end, AvailableAt: end, DeliveryAt: end, PriceKnown: true, VolumeKnown: true, Volume: 100, OHLC: OHLC{Open: 100, High: 101, Low: 99, Close: 100}, Technical: Technical{EMA8: known(100 + s), EMA21: known(100), EMA8Delta: known(s), EMA21Delta: known(s), Gap: known(s), ATR: known(10), PreviousATR: known(10), TR: known(2), RSI: known(50 + 10*s), PreviousRSI: known(50 + 5*s), Histogram: known(s), PreviousHistogram: known(.5 * s)}}
	return Publication{Stamp: Stamp{Time: end, Index: index, Line: index + 1}, Frame: Frame{Frame: f, DMI: DMI{PlusDI: known(25 + 5*s), MinusDI: known(25 - 5*s), ADX: known(24), PreviousADX: known(26)}}}
}

// seeded は、各20本の同限月前史と当場公表を用意します。
//
// 引数: t(*testing.T)、side(int)。返り値: *Bankです。
func seeded(t *testing.T, side int) *Bank {
	t.Helper()
	b := NewBank()
	for _, width := range []int{300, 900, 1800} {
		for i := 0; i < 20; i++ {
			p := fixture(width, i, side, 1000+float64((i+1)*width), "prior")
			if err := b.Add(p); err != nil {
				t.Fatal(err)
			}
		}
	}
	if err := b.StartSession("current", "K"); err != nil {
		t.Fatal(err)
	}
	for _, width := range []int{300, 900, 1800} {
		if err := b.Add(fixture(width, 0, side, 100000, "current")); err != nil {
			t.Fatal(err)
		}
	}
	return b
}

// quote は、鏡像の確認価格を返します。
//
// 引数: index(int)、at/last(float64)。返り値: Quoteです。
func quote(index int, at, last float64) Quote {
	return Quote{Time: at, Index: index, Line: index + 1, Last: last}
}

// TestTrendMirrorAndLaterBar は、初回接触の保持と別Raw/別足確認を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestTrendMirrorAndLaterBar(t *testing.T) {
	for _, side := range []int{1, -1} {
		b := seeded(t, side)
		w := &Watch{}
		first, err := b.Evaluate(Ttrend, side, quote(0, 100000, 100), w)
		if err != nil || first.Truth != False || w.Trend == nil {
			t.Fatalf("接触 %d %#v %v", side, first, err)
		}
		original := *w.Trend
		p := fixture(300, 1, side, 100300, "current")
		if err := b.Add(p); err != nil {
			t.Fatal(err)
		}
		d, err := b.Evaluate(Ttrend, side, quote(1, 100300, 100+float64(side)*2), w)
		if err != nil || d.Truth != True {
			t.Fatalf("確認 %d %#v %v", side, d, err)
		}
		if *w.Trend != original {
			t.Fatal("初回接触を置換しました")
		}
		d.Trend.Touch.At.Last = 1
		if w.Trend.At.Last != 100 {
			t.Fatal("接触参照を共有しました")
		}
	}
}

// TestReversalAndHybrid は、反転の改善票・OR・等号境界を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestReversalAndHybrid(t *testing.T) {
	for _, side := range []int{1, -1} {
		b := seeded(t, side)
		p := b.current[900][0].pub
		p.Frame.Frame.Technical.RSI = known(50 - 20*float64(side))
		b.current[900][0].pub = p
		w := &Watch{}
		d, err := b.Evaluate(Thybrid, side, quote(0, 100000, 100), w)
		if err != nil || w.Reversal == nil || d.Truth != False {
			t.Fatalf("反転接触 %#v %v", d, err)
		}
		p5 := fixture(300, 1, side, 100300, "current")
		p5.Frame.Frame.Technical.Histogram = known(-.1 * float64(side))
		p5.Frame.Frame.Technical.PreviousHistogram = known(-.5 * float64(side))
		if err = b.Add(p5); err != nil {
			t.Fatal(err)
		}
		d, err = b.Evaluate(Thybrid, side, quote(1, 100300, 100+2*float64(side)), w)
		if err != nil || d.Truth != True || d.Reversal.Truth != True || d.Trend.Truth != False {
			t.Fatalf("水準逆側でも改善 %#v %v", d, err)
		}
		b.current[300][1].pub.Frame.Frame.Technical.PreviousHistogram = b.current[300][1].pub.Frame.Frame.Technical.Histogram
		d, err = b.Evaluate(Treversal, side, quote(2, 100301, 100+2*float64(side)), w)
		if err != nil || d.Truth != False {
			t.Fatal("Hist差0を成立にしました")
		}
	}
	if Or(True, Unknown) != True || And(False, Unknown) != False || And(True, Unknown) != Unknown {
		t.Fatal("三値論理")
	}
}

// TestRollingUnknownAndReset は、母BB/前20量/未知維持/欠足/限月を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestRollingUnknownAndReset(t *testing.T) {
	b := NewBank()
	for i := 0; i < 20; i++ {
		p := fixture(900, i, 1, float64(900*(i+1)), "prior")
		v := float64(i + 1)
		p.Frame.Frame.OHLC = OHLC{Open: v, High: v, Low: v, Close: v}
		if err := b.Add(p); err != nil {
			t.Fatal(err)
		}
	}
	bb := bands(b.windows[900])
	if !bb.Known || bb.Mean != 10.5 || math.Abs(bb.Sigma-math.Sqrt(33.25)) > 1e-12 {
		t.Fatal(bb)
	}
	b = seeded(t, 1)
	s, _ := b.Current(quote(0, 100000, 100))
	if !s.RVOL5.Known || s.RVOL5.Value != 1 || !s.BB15.Known {
		t.Fatal("20本の数値継承")
	}
	p := fixture(300, 1, 1, 100300, "current")
	p.Frame.Frame.VolumeKnown = false
	if err := b.Add(p); err != nil {
		t.Fatal(err)
	}
	s, _ = b.Current(quote(1, 100300, 100))
	if s.RVOL5.Known {
		t.Fatal("未知の当量を補完")
	}
	p = fixture(300, 2, 1, 100600, "current")
	if err := b.Add(p); err != nil {
		t.Fatal(err)
	}
	s, _ = b.Current(quote(2, 100600, 100))
	if s.RVOL5.Known {
		t.Fatal("前20本の未知量を飛ばしました")
	}
	p = fixture(300, 3, 1, 101200, "current")
	if err := b.Add(p); err != nil {
		t.Fatal(err)
	}
	if len(b.windows[300]) != 1 {
		t.Fatal("欠足を補填しました")
	}
	if err := b.StartSession("next", "K2"); err != nil {
		t.Fatal(err)
	}
	if len(b.windows) != 0 {
		t.Fatal("異限月carry")
	}
}

// TestCausalityAndUnknown は、未来・期限・改変・接触以前を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestCausalityAndUnknown(t *testing.T) {
	b := seeded(t, 1)
	p := fixture(300, 10, 1, 100300, "current")
	if err := b.Add(p); err != nil {
		t.Fatal(err)
	}
	s, _ := b.Current(quote(0, 100000, 100))
	if s.Frames[300].Frame.Frame.End != 100000 {
		t.Fatal("未来公表を採用")
	}
	p.Frame.Frame.Volume = 99
	if b.Add(p) == nil {
		t.Fatal("同ID改変を許可")
	}
	w := &Watch{}
	d, _ := b.Evaluate(Ttrend, 1, quote(0, 100000, 100), w)
	if d.Truth == True {
		t.Fatal("接触同原行確認")
	}
	d, _ = b.Evaluate(Ttrend, 1, quote(1, 100001, 102), w)
	if d.Truth == True {
		t.Fatal("接触以前の足を再利用")
	}
	s, _ = b.Current(quote(20, 100660, 102))
	if len(s.Missing) == 0 {
		t.Fatal("fresh境界等号を許可")
	}
	b = seeded(t, 1)
	b.current[300][0].pub.Frame.Frame.Technical.ATR = Value{}
	d, _ = b.Evaluate(Ttrend, 1, quote(0, 100000, 100), &Watch{})
	if d.Truth != Unknown || len(d.Missing) == 0 {
		t.Fatal("未知領域を既知偽へ補完")
	}
	b.current[300][0].pub.Frame.Frame.Technical.ATR = known(0)
	d, _ = b.Evaluate(Ttrend, 1, quote(0, 100000, 100), &Watch{})
	if d.Truth != False {
		t.Fatal("ATR0を未知にしました")
	}
}

// TestRelativeVolumeUsesPrevious20 は、当量を分母へ混ぜないことを確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestRelativeVolumeUsesPrevious20(t *testing.T) {
	b := seeded(t, 1)
	p := fixture(300, 1, 1, 100300, "current")
	p.Frame.Frame.Volume = 200
	if err := b.Add(p); err != nil {
		t.Fatal(err)
	}
	s, _ := b.Current(quote(1, 100300, 100))
	if !s.RVOL5.Known || s.RVOL5.Value != 2 {
		t.Fatal(s.RVOL5)
	}
	if err := b.StartSession("next", "K"); err != nil {
		t.Fatal(err)
	}
	s, _ = b.Current(quote(0, 110000, 100))
	if len(s.Frames) != 0 || len(s.Missing) != 3 {
		t.Fatal("前場公表を当場公表にしました")
	}
}
