package entryrules118

import "fmt"

// And は、既知偽を優先する三値ANDを求めます。
//
// 引数: values(...Truth)。返り値: Truthです。
func And(values ...Truth) Truth {
	result := True
	for _, v := range values {
		if v == False {
			return False
		}
		if v == Unknown {
			result = Unknown
		}
	}
	return result
}

// Or は、既知真を優先する三値ORを求めます。
//
// 引数: values(...Truth)。返り値: Truthです。
func Or(values ...Truth) Truth {
	result := False
	for _, v := range values {
		if v == True {
			return True
		}
		if v == Unknown {
			result = Unknown
		}
	}
	return result
}

// testValue は、未知と既知否定を分けて条件を記録します。
//
// 引数: branch(*Branch)、name(string)、known/pass(bool)。返り値: Truthです。
func testValue(branch *Branch, name string, known, pass bool) Truth {
	if !known {
		branch.Missing = append(branch.Missing, name)
		return Unknown
	}
	if !pass {
		branch.Denied = append(branch.Denied, name)
		return False
	}
	return True
}

// signed は、既知値だけを売買符号で反転します。
//
// 引数: side(int)、v(Value)。返り値: Valueは既知性を維持します。
func signed(side int, v Value) Value { return Value{Known: v.Known, Value: float64(side) * v.Value} }

// touchCopy は、監視の接触を外部へ共有しない値へ複写します。
//
// 引数: t(*ZoneTouch)。返り値: *ZoneTouchはnilを維持します。
func touchCopy(t *ZoneTouch) *ZoneTouch {
	if t == nil {
		return nil
	}
	v := *t
	return &v
}

// branch は、当時背景・初回接触・後続確認を一枝分だけ評価します。
//
// 引数: mode(Mode)、side(int)、s(Snapshot)、touch(**ZoneTouch)、update(bool)、fields(map[string]Value)。
// 返り値: Branchは未形成/既知否定/成立を区別します。
func branch(mode Mode, side int, s Snapshot, touch **ZoneTouch, update bool, fields map[string]Value) Branch {
	r := Branch{}
	f5 := s.Frames[300].Frame.Frame
	f15 := s.Frames[900].Frame
	f30 := s.Frames[1800].Frame
	t5 := f5.Technical
	t15 := f15.Frame.Technical
	t30 := f30.Frame.Technical
	d15 := f15.DMI
	d30 := f30.DMI
	sign := float64(side)
	gap := signed(side, t30.Gap)
	a8 := signed(side, t30.EMA8Delta)
	a21 := signed(side, t30.EMA21Delta)
	di := Value{Known: d15.PlusDI.Known && d15.MinusDI.Known, Value: sign * (d15.PlusDI.Value - d15.MinusDI.Value)}
	fields["gap30_signed"], fields["ema8_delta30_signed"], fields["ema21_delta30_signed"] = gap, a8, a21
	fields["di15_signed"], fields["adx15"], fields["adx30"], fields["previous_adx30"] = di, d15.ADX, d30.ADX, d30.PreviousADX
	distance := Value{Known: t5.EMA21.Known, Value: sign * (s.AsOf.Last - t5.EMA21.Value)}
	fields["last_ema21_5_signed"] = distance
	fields["atr5"] = t5.ATR
	fields["previous_atr5"] = t5.PreviousATR
	fields["tr5"] = t5.TR
	fields["rvol5"] = s.RVOL5
	hist := signed(side, t5.Histogram)
	histDelta := Value{Known: t5.Histogram.Known && t5.PreviousHistogram.Known, Value: sign * (t5.Histogram.Value - t5.PreviousHistogram.Value)}
	rsi := Value{Known: t5.RSI.Known, Value: sign * (t5.RSI.Value - 50)}
	rsiDelta := Value{Known: t5.RSI.Known && t5.PreviousRSI.Known, Value: sign * (t5.RSI.Value - t5.PreviousRSI.Value)}
	fields["hist5_signed"], fields["hist5_delta_signed"], fields["rsi5_centered_signed"], fields["rsi5_delta_signed"] = hist, histDelta, rsi, rsiDelta
	if mode == Ttrend {
		r.Background = And(testValue(&r, "30分MA配置", gap.Known, gap.Value > 0), testValue(&r, "30分EMA8傾き", a8.Known, a8.Value > 0), testValue(&r, "30分EMA21傾き", a21.Known, a21.Value > 0), testValue(&r, "15分DI方向", di.Known, di.Value > 0), testValue(&r, "15分ADX20以上", d15.ADX.Known, d15.ADX.Value >= 20))
		r.Zone = And(testValue(&r, "5分ATR正", t5.ATR.Known, t5.ATR.Value > 0), testValue(&r, "5分EMA21押戻し領域", distance.Known && t5.ATR.Known, distance.Value >= -t5.ATR.Value && distance.Value <= .25*t5.ATR.Value))
	} else {
		level := testValue(&r, "30分ADX25以下", d30.ADX.Known, d30.ADX.Value <= 25)
		fall := testValue(&r, "30分ADX低下", d30.ADX.Known && d30.PreviousADX.Known, d30.ADX.Value < d30.PreviousADX.Value)
		r.Background = Or(level, fall)
		rsi15 := Value{Known: t15.RSI.Known, Value: sign * (t15.RSI.Value - 50)}
		fields["rsi15_centered_signed"] = rsi15
		band := s.BB15.Lower
		if side < 0 {
			band = s.BB15.Upper
		}
		fields["bb15_boundary"] = Value{Known: s.BB15.Known, Value: band}
		r.Zone = And(testValue(&r, "15分BB外側", s.BB15.Known, sign*(s.AsOf.Last-band) <= 0), testValue(&r, "15分RSI過熱側", rsi15.Known, rsi15.Value <= -15))
	}
	if update && *touch == nil && r.Background == True && r.Zone == True {
		*touch = &ZoneTouch{At: s.AsOf, Frame5: Ref{ID: f5.ID, Width: 300, End: f5.End, Delivered: s.Frames[300].Stamp}}
	}
	r.Touch = touchCopy(*touch)
	if *touch == nil {
		r.Confirm = False
		r.Denied = append(r.Denied, "初回接触未成立")
		r.Truth = And(r.Background, r.Zone)
		if r.Truth == True {
			r.Truth = False
		}
		return r
	}
	z := *touch
	after := s.AsOf.Index > z.At.Index && s.AsOf.Line > z.At.Line && s.AsOf.Time >= z.At.Time
	newBar := f5.End > z.At.Time
	boundary := f5.OHLC.High
	if side < 0 {
		boundary = f5.OHLC.Low
	}
	fields["confirm5_boundary"] = Value{Known: f5.PriceKnown, Value: boundary}
	common := []Truth{testValue(&r, "接触より後の原行", true, after), testValue(&r, "接触後に確定した5分足", true, newBar), testValue(&r, "5分高安の順側突破", f5.PriceKnown, sign*(s.AsOf.Last-boundary) > 0), testValue(&r, "前5分ATR正", t5.PreviousATR.Known, t5.PreviousATR.Value > 0), testValue(&r, "5分TRは前ATRの2倍以下", t5.TR.Known && t5.PreviousATR.Known, t5.TR.Value <= 2*t5.PreviousATR.Value)}
	if mode == Ttrend {
		common = append(common, testValue(&r, "5分Hist順側", hist.Known, hist.Value > 0), testValue(&r, "5分RSI確認領域", rsi.Known, rsi.Value >= 0 && rsi.Value <= 20), testValue(&r, "5分RVOL0.8以上", s.RVOL5.Known, s.RVOL5.Value >= .8))
	} else {
		common = append(common, testValue(&r, "5分Hist改善", histDelta.Known, histDelta.Value > 0), testValue(&r, "5分RSI改善", rsiDelta.Known, rsiDelta.Value > 0), testValue(&r, "5分RVOL1以上", s.RVOL5.Known, s.RVOL5.Value >= 1))
	}
	r.Confirm = And(common...)
	r.Truth = And(r.Background, True, r.Confirm)
	return r
}

// Evaluate は、初回領域接触と後続確認を一度の原行で因果評価します。
//
// 引数: mode(Mode)、side(int)、q(Quote)、w(*Watch)は候補ごとの状態です。
// 返り値: Decision/error。期限/cap/指値/約定は含みません。
func (b *Bank) Evaluate(mode Mode, side int, q Quote, w *Watch) (Decision, error) {
	r := Decision{Mode: mode, Side: side, At: q, Fields: map[string]Value{}}
	if (mode != Ttrend && mode != Treversal && mode != Thybrid) || (side != 1 && side != -1) || w == nil {
		return r, fmt.Errorf("候補/方向/Watchが不正です")
	}
	s, err := b.Current(q)
	if err != nil {
		return r, err
	}
	r.SnapshotRefs = append([]Ref(nil), s.Refs...)
	if w.SessionID == "" {
		w.SessionID, w.Contract, w.Side = s.SessionID, s.Contract, side
	}
	if w.SessionID != s.SessionID || w.Contract != s.Contract || w.Side != side {
		return r, fmt.Errorf("Watchの場/限月/方向が違います")
	}
	for _, t := range []*ZoneTouch{w.Trend, w.Reversal} {
		if t != nil && (t.At.Time > q.Time || t.At.Index > q.Index || t.At.Line > q.Line) {
			return r, fmt.Errorf("未来の接触を参照しています")
		}
	}
	if len(s.Missing) > 0 {
		r.Truth = Unknown
		r.Zone = Unknown
		r.Confirm = Unknown
		r.Missing = append([]string(nil), s.Missing...)
		return r, nil
	}
	r.Trend = branch(Ttrend, side, s, &w.Trend, mode != Treversal, r.Fields)
	r.Reversal = branch(Treversal, side, s, &w.Reversal, mode != Ttrend, r.Fields)
	selected := []Branch{r.Trend}
	if mode == Treversal {
		selected = []Branch{r.Reversal}
	}
	if mode == Thybrid {
		selected = append(selected, r.Reversal)
	}
	var truths, zones, confirms []Truth
	for _, v := range selected {
		truths = append(truths, v.Truth)
		zones = append(zones, v.Zone)
		confirms = append(confirms, v.Confirm)
		r.Missing = append(r.Missing, v.Missing...)
		r.Reason = append(r.Reason, v.Denied...)
	}
	r.Truth = Or(truths...)
	r.Zone = Or(zones...)
	r.Confirm = Or(confirms...)
	return r, nil
}
