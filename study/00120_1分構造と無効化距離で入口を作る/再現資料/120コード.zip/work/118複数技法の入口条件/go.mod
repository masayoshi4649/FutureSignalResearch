module github.com/masayoshi4649/SessionTradeExecuter/entryrules118

go 1.24
