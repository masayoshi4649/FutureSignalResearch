module entryexperiment120

go 1.24.2

require (
	github.com/masayoshi4649/SessionTradeExecuter/entryrules118 v0.0.0
	github.com/masayoshi4649/SessionTradeExecuter/entrybirth120 v0.0.0
)

replace github.com/masayoshi4649/SessionTradeExecuter/entryrules118 => ../118複数技法の入口条件
replace github.com/masayoshi4649/SessionTradeExecuter/entrybirth120 => ../120入口の1分構造
