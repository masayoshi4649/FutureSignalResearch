"""120の人工検査コード同体と固定文書を市場実行前に照合する。"""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[2]
STUDY = ROOT / 'study/00120_1分構造と無効化距離で入口を作る'


def sha(path: Path) -> str:
    """
    機能: 全bytesのSHA256を計算する。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 二つの人工検査で検査した版と現版の一致、文書リンクを確認する。
    引数: なし。返り値: None。入力JSON・Raw・市場結果を読まない。
    """
    first = ROOT / 'work/120入口の1分構造/検査/確認.json'
    assert sha(first) == 'edcf25c76152a5229caf10a5c9044a40c4a8f96793deb2a1da53faf266032d14'
    proof = json.loads(first.read_text(encoding='utf-8'))
    for key in ('所有ファイルSHA256','参照118純条件SHA256'):
        for path, expected in proof[key].items():
            assert sha(Path(path)) == expected, path
    second = ROOT / 'work/120入口実装検査/確認.json'
    proof2 = json.loads(second.read_text(encoding='utf-8'))
    assert proof2['成功'] and proof2['119kernel関数型名以外同体']
    for ref in proof2['コード']:
        path = ROOT / ref['path']
        assert sha(path) == ref['sha256'] and path.stat().st_size == ref['bytes'], ref['path']
    links = 0
    for name in ('README.md','設定と結果.md'):
        path = STUDY / name
        text = path.read_text(encoding='utf-8')
        for target in re.findall(r'\]\(([^)]+)\)',text):
            if target.startswith(('https://','http://','#')):
                continue
            assert (path.parent / target.split('#')[0]).exists(), (name,target)
            links += 1
    saved = STUDY / '実行前原文'
    saved.mkdir(exist_ok=False)
    for name in ('README.md','設定と結果.md'):
        with (saved / name).open('xb') as stream:
            stream.write((STUDY / name).read_bytes())
    report = {'成功':True,'試行':120,'純条件人工証跡SHA256':sha(first),'執行人工証跡SHA256':sha(second),'文書相対リンク数':links,'実行前原文':{name:sha(saved/name) for name in ('README.md','設定と結果.md')},'入力Raw市場結果読取':False}
    with (ROOT / 'work/120入口比較/実行前照合.json').open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(report,ensure_ascii=False))


if __name__=='__main__':
    main()
