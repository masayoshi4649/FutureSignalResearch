"""120の事前固定コードと人工検査を、市場結果を読まずに保管する。"""
from pathlib import Path
import hashlib
import io
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / 'work/120入口比較'
TRIAL = ROOT / 'study/00120_1分構造と無効化距離で入口を作る'


def sha(data: bytes) -> str:
    """
    機能: 全バイト列の保存指紋を求める。
    引数: data(bytes)は検査対象。
    返り値: strはSHA256の小文字16進値。
    """
    return hashlib.sha256(data).hexdigest()


# ----------------------------------------
def save(path: Path, data: bytes) -> dict:
    """
    機能: 正式先へ新規保存し、既存なら全bytes同体を認証する。
    引数: path(Path)は正式先、data(bytes)は保存内容。
    返り値: dictは相対path・サイズ・SHA256。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == data, str(path)
    else:
        path.write_bytes(data)
    assert path.read_bytes() == data
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(data), 'sha256': sha(data)}


# ----------------------------------------
def main() -> None:
    """
    機能: F1・人工証拠・固定ソースだけを正式保管する。
    引数: なし。市場結果や市場入力を対象へ列挙しない。
    返り値: None。金融再実行・Raw/Native/11/09読取なし。
    """
    fixed_bytes = (WORK / 'F1.json').read_bytes()
    assert sha(fixed_bytes) == '1fd5c518a3c22a20cbd3e12f6ef2568ccfebf53ca10e407561528ea4902a719f'
    fixed = json.loads(fixed_bytes)
    assert all(sha(Path(path).read_bytes()) == wanted for path, wanted in fixed['code_sha256'].items())
    assert all(sha(Path(path).read_bytes()) == wanted for path, wanted in fixed['premarket_documents'].items())
    sources = [
        ('work/120入口比較/F1.json', '検査/F1.json', '1fd5c518a3c22a20cbd3e12f6ef2568ccfebf53ca10e407561528ea4902a719f'),
        ('work/120入口比較/F1.sha256', '検査/F1.sha256', None),
        ('work/120入口比較/実行前照合.json', '検査/実行前照合.json', None),
        ('work/120入口の1分構造/検査/確認.json', '検査/発生器の人工検査.json', 'edcf25c76152a5229caf10a5c9044a40c4a8f96793deb2a1da53faf266032d14'),
        ('work/120入口実装検査/確認_確定.json', '検査/執行器の人工検査.json', '6beba43507331bca736aa9733377db9ae5f930e452f92004a5155d6c0181156f'),
        ('work/120入口レビュー/最終差分の確認.json', '検査/独立コードレビュー.json', 'c09c9db5ebe37bbbcb1062954a1b7ac0ac33bc02616430016b49674729e0f9a0'),
        ('work/120入口レビュー/事前論理レビュー.md', '検査/事前論理レビュー.md', None),
        ('work/120入口CSV出力/準備の確認.json', '検査/CSV器の準備.json', None),
    ]
    refs = []
    before = {}
    for source, dest, expected in sources:
        data = (ROOT / source).read_bytes()
        if expected is not None:
            assert sha(data) == expected
        before[source] = sha(data)
        refs.append(save(TRIAL / dest, data))
    paths = {Path(path) for path in fixed['code_sha256']}
    paths.update(ROOT / p for p in (
        'work/120設定を準備する.py', 'work/120集計を準備する.py', 'work/120実行準備を作る.py',
        'work/120入口比較/実行前を照合する.py', 'work/120入口比較/README.md',
        'work/120入口の1分構造/README.md', 'work/118複数技法の入口条件/README.md',
        'work/120入口CSV出力/出力する.mjs', 'work/120入口CSV出力/CSVを独立再読する.py', 'work/120入口CSV出力/README.md',
    ))
    paths.add(Path(__file__).resolve())
    entries = []
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as stream:
        for path in sorted(paths):
            data = path.read_bytes()
            relative = path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(relative, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            stream.writestr(info, data, compresslevel=9)
            entries.append({'entry': relative, 'restore_relative': relative, 'bytes': len(data), 'sha256': sha(data)})
    zipped = buffer.getvalue()
    with zipfile.ZipFile(io.BytesIO(zipped)) as stream:
        assert stream.testzip() is None
        assert set(stream.namelist()) == {row['entry'] for row in entries}
        for row in entries:
            data = stream.read(row['entry'])
            assert sha(data) == row['sha256'] and len(data) == row['bytes']
    zip_ref = save(TRIAL / '再現資料/120コード.zip', zipped)
    refs.append(zip_ref)
    index = {'試行': 120, '成功': True, '段階': '市場結果未読の固定コード保管', 'zip': zip_ref, 'restore_root': str(ROOT), 'entries': entries, '依存': {'Go': '1.24.2 windows/amd64', 'Python': '3.14.3', 'Node': '24.22.1', 'artifact_tool': '2.8.129'}, '実行物は同梱しない': fixed['executable'], '入力は同梱しない': fixed['input'], '原板Nativeは同梱しない': True, '入力再生成は118正式資料を参照': True}
    refs.append(save(TRIAL / '再現資料/コード復元索引.json', (json.dumps(index, ensure_ascii=False, indent=2) + '\n').encode('utf-8')))
    assert all(sha((ROOT / p).read_bytes()) == expected for p, expected in before.items())
    assert all(sha(Path(path).read_bytes()) == wanted for path, wanted in fixed['code_sha256'].items())
    proof = {'試行': 120, '成功': True, '段階': 'コードと人工検査のみ。市場結果保存は未実施', '保存対象': refs, '元固定コードと原文不変': True, 'コードZIP全entrySHAサイズCRC一致': True, '市場結果読取': False, '市場入力読取': False, 'Raw読取': 0, 'Native読取': 0, '11月09読取': False, '金融再実行': False, '金融再集計': False, '実行物入力RawNativeの複写': False, '保管器SHA256': sha(Path(__file__).read_bytes())}
    save(TRIAL / '検査/コード保管の確認.json', (json.dumps(proof, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    print(json.dumps({'成功': True, 'コードZIP': zip_ref, 'entry数': len(entries), '市場結果読取': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
