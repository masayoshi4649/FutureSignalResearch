"""120の市場実行前固定・実行ラッパーを準備する。"""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def main() -> None:
    """
    機能: 119の固定手順を120へ適応し、結果を読まず新規保存する。
    引数: なし。返り値: None。119固定文書・コードは変更しない。
    """
    before = ROOT / 'work/119入口比較'
    own = ROOT / 'work/120入口比較'
    wrapper = (before / '実行する.py').read_text(encoding='utf-8').replace('119','120')
    wrapper = wrapper.replace("zones = sum(e['kind'] == 'zone' for s in value['scenes'] for e in s['events'])", "zones = sum(len(s['events']) for s in value['scenes'])")
    wrapper = wrapper.replace('assert cases == 3 * zones','assert cases == zones').replace('領域出生数','構造出生数').replace('役割別候補数','政策別候補数')
    fixed = (before / '条件を固定する.py').read_text(encoding='utf-8').replace('119','120')
    fixed = fixed.replace('技術領域の出生と確認後再試験で入口を比較する','1分構造と無効化距離で入口を作る').replace('120入口の技術的出生','120入口の1分構造')
    fixed = fixed.replace("'Ttrend_zone','Ttrend_confirm','Ttrend_retest','Treversal_zone','Treversal_confirm','Treversal_retest'", "'P1','P1plus','P2','P2plus','P3','P3plus'")
    fixed = fixed.replace("'zone_lifetime_seconds':1800,", "'signal_source':'確定1分の回復又は突破。未確定足完成形なし。','same_policy_side_cooldown_seconds':300,'maximum_structure_risk':'min(100pt,.5ATR5)','entry_cap':'1分終値±min(10pt,.15ATR5)。初回正常BBOで不適なら即取消。',")
    fixed = fixed.replace("'retest_order_seconds':300,",'').replace("'retest_opposite_bbo_cross_points':10,",'').replace("'retest_tick_points':5,",'')
    fixed = fixed.replace('技術領域から原行連続','原行から形成した確定1分構造')
    for name, text in (('実行する.py',wrapper),('条件を固定する.py',fixed)):
        with (own / name).open('x',encoding='utf-8',newline='\n') as stream:
            stream.write(text)
    print('120固定・実行ラッパーを準備。F1作成・市場実行はまだ行わない。')


if __name__=='__main__':
    main()
