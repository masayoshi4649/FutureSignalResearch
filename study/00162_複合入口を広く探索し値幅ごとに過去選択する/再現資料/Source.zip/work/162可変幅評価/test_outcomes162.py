"""可変幅表の実側、時計、未知、費用、型保存とバッチ算術を人工検査する。"""
from pathlib import Path
import copy
import json
import tempfile

import numpy as np
import outcomes162 as M


def quote(at: int, index: int, bid: float, ask: float) -> dict:
    """
    機能: 実側が別価格の人工気配票を返す。
    引数: at/index(int)、bid/ask(float)は時計・原行と価格。
    返り値: dictは正常BBO気配。
    """
    return {'time':at,'index':index,'source_line':index+1,'bid':bid,'ask':ask,'last':(bid+ask)/2,'quote_ok':True}


def stream(side: int, touch_direction: int, complete: bool, width: int=200) -> tuple:
    """
    機能: 売買鏡像の単純観測を作る。
    引数: side(int±1)、touch_direction(int三値)、complete(bool)、width(int)。
    返り値: tupleはstreamとentry。
    """
    e=quote(100,10,1000,1010);price=e['ask' if side==1 else 'bid']
    mark=price+side*touch_direction*(width+10)
    touch=quote(110,11,mark,mark+10) if side==1 else quote(110,11,mark-10,mark)
    end=quote(1900,12,1020,1030)
    out={'seconds':1800,'deadline':1900,'status':'complete' if complete else 'gap_censored',
        'touches':[{'width':width,'direction':touch_direction,'quote':touch if touch_direction else None}],
        'endpoint':end if complete else None,'net5':-99999999}
    return {'status':'filled','axis':'BBO','birth':{'side':side},'entry':e,'entry_price':price,'outcomes':[out]},e


def main() -> None:
    """
    機能: 意味のある境界・鏡像・未知・バッチと保存の人工例を検査する。
    引数: なし。自然入力・新規採否を読まない。
    返り値: None。成功票JSONを標準出力へ返す。
    """
    tests=[]
    for side in M.SIDE_ORDER:
        for direction in (-1,0,1):
            for complete in (False,True):
                s,e=stream(side,direction,complete)
                r=M.project_stream(s,e,side,4000,200,1800)
                assert r['label']==(direction if complete else 2)
                assert r['known']==(complete or direction!=0)
                if direction:
                    assert r['points']==direction*210 and r['net5']==direction*21000-1077
                elif complete:
                    assert r['points']==(10 if side==1 else -30)
                else:
                    assert np.isnan(r['net5'])
    tests.append('買売×順逆未×完了不足12条件とC早期touch')
    s,e=stream(1,1,True);bad=copy.deepcopy(s);bad['outcomes'][0]['touches'][0]['quote']['index']=e['index']
    try:M.project_stream(bad,e,1,4000,200,1800)
    except AssertionError:pass
    else:raise AssertionError('取得原行混入を許した')
    bad=copy.deepcopy(s);bad['outcomes'][0]['touches'][0]['quote']['time']=4000
    try:M.project_stream(bad,e,1,4000,200,1800)
    except AssertionError:pass
    else:raise AssertionError('ザラバ境界等号混入を許した')
    tests.append('取得q1原行・市場境界等号の拒否')
    a=M.allocate(2,(200,),(1800,));statuses={}
    for i in range(2):
        buy,e=stream(1,1 if i==0 else -1,True)
        sell,_=stream(-1,-1 if i==0 else 0,True)
        c={'id':str(i),'original_side':1,'original':buy,'reverse':sell}
        M.project_case(a,i,c,{'id':str(i),'side':1,'entry':e},4000,(200,),(1800,),statuses)
    table=M.OutcomeTable(('0','1'),('場0','場1'),('場0','場1'),(200,),(1800,),a,tuple(statuses),{'side_order':[1,-1]})
    masks=np.asarray([[[1,0],[1,0]],[[0,1],[0,1]],[[0,0],[0,0]]],dtype=np.bool_)
    r=M.batch_summary(table,masks,200,1800)
    assert r['F'].tolist()==[1,0,0] and r['A'].tolist()==[1,1,0]
    assert r['N'].tolist()==[0,1,0] and r['取得'].tolist()==[2,2,0]
    assert r['既知差引'].tolist()==[-2154,-26154,0]
    assert np.isnan(r['到達済み率'][2])
    root=table.root_arrays();assert root['label'].shape==(2,2,1,1) and root['net'].dtype==np.int64
    assert root['session_index'].tolist()==[0,1] and root['known_at'][0,0,0,0]==1900
    tests.append('物理実側バッチ・費用1077・空政策・Root軸順')
    duplicate=masks.copy();duplicate[0,0]=True
    try:M.batch_summary(table,duplicate,200,1800)
    except AssertionError:pass
    else:raise AssertionError('同物理両側を許した')
    tests.append('同物理q1両側二重計数拒否')
    with tempfile.TemporaryDirectory() as temp:
        directory=Path(temp)/'table';refs=M.save_table(table,directory);again=M.load_table(directory,refs)
        assert again.case_ids==table.case_ids and again.widths==table.widths
        for name in M.ARRAY_NAMES:
            assert np.array_equal(again.arrays[name],table.arrays[name],equal_nan=True)
        bad=copy.deepcopy(refs);bad['観測配列.npz']['sha256']='0'*64
        try:M.load_table(directory,bad)
        except AssertionError:pass
        else:raise AssertionError('保存SHA改変を許した')
    tests.append('pickle無し全配列保存復元とSHA改変拒否')
    print(json.dumps({'成功':True,'自然入力なし':True,'検査群':tests,'源SHA256':M.sha(Path(M.__file__))},ensure_ascii=False))


if __name__=='__main__':
    main()
