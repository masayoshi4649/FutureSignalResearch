"""Rootが事前固定した162条件を検査後、旧保存幅の数値表を一度生成する。"""
from pathlib import Path
import argparse
import json

import outcomes162 as M


def save(path: Path, value: object) -> None:
    """
    機能: 未作成のUTF-8 JSONへ検査結果を保存する。
    引数: path(Path)、value(object)は保存先と値。
    返り値: None。
    """
    with path.open('x',encoding='utf-8',newline='\n') as output:
        json.dump(value,output,ensure_ascii=False,indent=2,allow_nan=False);output.write('\n')


def main() -> None:
    """
    機能: 固定bookと停止Source確認後、純観測を数値cacheへ変換する。
    引数: CLI --book(Path)、--book-sha256(str)、--output-dir(Path)は正式条件と未作成出力先。
    返り値: None。旧125/200×H30/H60のcase表と全入力確認を保存する。
    """
    parser=argparse.ArgumentParser()
    parser.add_argument('--book',type=Path,required=True)
    parser.add_argument('--book-sha256',required=True)
    parser.add_argument('--output-dir',type=Path,required=True)
    args=parser.parse_args()
    assert M.sha(args.book)==args.book_sha256
    book=json.loads(args.book.read_text(encoding='utf-8'));assert book.get('trial',book.get('試行'))==162
    here=Path(__file__).resolve().parent
    stop=json.loads((here/'旧保存幅の停止.json').read_text(encoding='utf-8'))
    assert stop['成功'] and stop['自然未実行']
    assert all(M.sha(here/name)==digest for name,digest in stop['Source'].items())
    assert not args.output_dir.exists()
    table=M.read_legacy_outcomes()
    refs=M.save_table(table,args.output_dir)
    assert M.sha(args.book)==args.book_sha256
    assert all(M.sha(here/name)==digest for name,digest in stop['Source'].items())
    save(args.output_dir/'入力と算式の確認.json',{'成功':True,'試行':162,'条件SHA256':args.book_sha256,
        'Source':stop['Source'],'入力':table.evidence,'cache':refs,'case順':'case_id辞書順',
        '探索器軸':'case,side,width,horizon。side BUY+1/SELL−1。known=Falseの整数net0は欠測格納値。',
        '新規採否を受け取らない':True,'自然新規探索なし':True})
    save(args.output_dir/'完了.json',{'成功':True,'試行':162,'case数':len(table.case_ids),'全場数':len(table.session_order),
        '条件SHA256':args.book_sha256,'cache':refs,'確認票SHA256':M.sha(args.output_dir/'入力と算式の確認.json')})
    print(json.dumps({'成功':True,'case数':len(table.case_ids),'全場数':len(table.session_order),'cache':refs},ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
