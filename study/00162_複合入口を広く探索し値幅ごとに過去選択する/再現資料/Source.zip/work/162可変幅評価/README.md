# 可変幅IFD評価の基盤

2026-11-14。162の前段は正式148保存済みの125/200pt×H30/H60を一度読み、数値NPZへ変換する。任意新幅は別Source・別試行のRaw索引で拡張する。200ptを最終固定幅とはしない。

## API

- `read_legacy_outcomes(widths=(125,200),horizons=(1800,3600)) -> OutcomeTable`。取得選択や学習を引数に持たない。正式148の全73場31,642caseをCパーサijson3.6.0で一場ずつ読む。物理/解凍SHA、全gzip CRC、全場のRaw指紋/stat/品質、固定取得照合を確認する。自然実行はRootの162F0後だけ。
- `save_table(table,directory)` / `load_table(directory,expected)`。pickle不要の数値NPZと小さな識別gzip。再読は全CRC/物理SHAを確認。NPZのZIP日時によるbyte差と、配列意味の同体は分ける。
- `table.case_ids` は辞書順31642件。`sessions`はcaseごとの場、`session_order`は元73場の時系列。`case_to_index()`で写像する。
- `table.root_arrays('C5')`は`label/net/known/exit_time/known_at`を **[case,side,width,horizon]** で返す。side=BUY+1/SELL−1、幅=(125,200)、期限=(1800,3600)。label=-1逆/A、0未/N、1順/F、2不足/C。netはint64円で未知0は格納値に過ぎず、必ずknownと同時に使う。内部の金融配列は未知NaN。
- `entry_time/index/line`はcase軸、`session_index`は0～72。`known_at`はstrictH完了のendpoint時刻であり、C早期touchの実現可能時刻とは違う。
- `table.view(width,seconds)`は各[case,side]のラベル/金融参照を返す。
- `batch_summary(table,masks,width,seconds,cost='C5')`は取得済み・物理q1重複除去済みのbool[K,N,2]を128政策ずつ集計。同一政策で同じcaseの両側を選ぶ誤りを拒否する。場別・期間別の母数と参加はRootが別に集計する。

## 時計と算式

q1原行そのものは先着に使わず、後続原行なら同秒も使う。買いAsk/売りBidで取得、買いBid/売りAskで清算。strictH完了だけF/A/N、ほかはC。Cでも打切り前に先着したtouchがあればIFD金融は既知。touchがなければ完了endpointだけで清算し、他は未知。`outcome.net5`はendpoint損益のためtouch清算へ使わない。

ザラバはEnd−300未満、等号から打切り。価格時計gap300秒、正常BBO gap300秒、期限endpoint猶予30秒。費用はmini1枚100円/pt、往復77円、C5は追加1000円控除。反転ラベルを1−pで作らない。

## 自然生成

停止Sourceと人工をRoot bookへ束縛後、未作成のwork先へ次を実行する。

```powershell
python -X utf8 work/162可変幅評価/run162.py --book study/00162_予定/条件.json --book-sha256 固定SHA --output-dir work/162可変幅評価/自然射影
```

これは純観測の射影だけであり、新しい入口候補や取引成績を生成したことにはしない。
