"""任意の保存幅と期限を数値配列へ射影し、多数の入口を同じIFDで高速評価する。"""
from dataclasses import dataclass
from pathlib import Path
import gzip
import hashlib
import json
import math

import ijson
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
OBSERVATIONS=ROOT/'study/00148_全1分知得から入口品質の母集団を固定する/成果物/固定取得の正逆観測.json.gz'
OBS_SHA='bd809bdf24400628817afee702063504c65682e6748a60e0f32d7690b7363c61'
OBS_DECODED_SHA='d1b4cab8a258203f04b5c1d081f57d10ed2a0c58ce4cc160ef571d5fac0ceffc'
FIXED=ROOT/'inputs/00148_全1分入口母集団/固定取得入力.json.gz'
FIXED_SHA='99f10a996ca6e8b6c428061f1b48624bbc479ec84c500a9633818d47e4298e2a'
FIXED_DECODED_SHA='12c43fe60e0ffd5ffa44bec7b5f7dd3d60bb92b291e0008db23587dcf19536d3'
SIDE_ORDER=(1,-1)
LABELS={'A':-1,'N':0,'F':1,'C':2}
ARRAY_NAMES=('labels','directions','known','points','net0','net5','exit_time','exit_index','exit_line',
    'complete','endpoint_time','endpoint_index','endpoint_line','endpoint_mark','status',
    'entry_time','entry_index','entry_line','entry_price','original_side')


def sha(path: Path) -> str:
    """
    機能: ファイルを固定長ずつ読み物理SHA256を返す。
    引数: path(Path)は入力ファイル。
    返り値: strは小文字16進SHA256。
    """
    with path.open('rb') as source:
        return hashlib.file_digest(source,'sha256').hexdigest()


def stat_key(path: Path) -> tuple:
    """
    機能: 入力の同一物理ファイルと変更時計を記録する。
    引数: path(Path)は入力ファイル。
    返り値: tupleはdev/ino/size/mtime_ns。
    """
    s=path.stat()
    return s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns


class DigestReader:
    """解凍ストリームの全bytesをCパーサへ渡しながらSHAを計算する。"""
    def __init__(self, source: object) -> None:
        """
        機能: 解凍済みバイナリ読取器と指紋を結ぶ。
        引数: source(object)はreadを持つバイナリ入力。
        返り値: None。
        """
        self.source=source;self.digest=hashlib.sha256();self.size=0

    def read(self, size: int=-1) -> bytes:
        """
        機能: 読み出した解凍bytesを一度だけ指紋へ加える。
        引数: size(int)は読取上限。
        返り値: bytesは読み出した値。
        """
        body=self.source.read(size);self.digest.update(body);self.size+=len(body)
        return body

    def readinto(self, buffer: object) -> int:
        """
        機能: Cパーサのバッファ読取へ同じ指紋計算を提供する。
        引数: buffer(object)は書込可能なバッファ。
        返り値: intは読取bytes数。
        """
        body=self.read(len(buffer));buffer[:len(body)]=body
        return len(body)


# ----------------------------------------
def checked_quote(quote: dict) -> None:
    """
    機能: 実BBOと物理原行時計を検査する。
    引数: quote(dict)はtime/index/source_line/bid/ask/quote_okを持つ。
    返り値: None。不正値は拒否する。
    """
    assert type(quote['time']) in (int,float) and math.isfinite(quote['time'])
    assert type(quote['index']) is int and quote['index']>=0
    assert type(quote['source_line']) is int and quote['source_line']>0
    assert quote['quote_ok'] is True and 0<quote['bid']<quote['ask']
    assert all(type(quote[k]) in (int,float) and math.isfinite(quote[k]) for k in ('bid','ask'))


def project_stream(stream: dict, entry: dict, side: int, execution_end: float,
                   width: float, seconds: int) -> dict:
    """
    機能: 指定同幅・期限の厳密先着とIFD瞬時BBO決済を独立に計算する。
    引数: stream/entry(dict)、side(int±1)、execution_end(float)、width(float>0)、seconds(int>0)。
    返り値: dictはlabel/direction/known/points/net0/net5と決済原行。未知を0へ埋めない。
    """
    checked_quote(entry)
    assert side in SIDE_ORDER and width>0 and seconds>0
    assert stream['status']=='filled' and stream['axis']=='BBO' and stream['birth']['side']==side
    assert stream['entry']==entry
    price=entry['ask' if side==1 else 'bid'];assert stream['entry_price']==price
    horizons=[o for o in stream['outcomes'] if o['seconds']==seconds];assert len(horizons)==1
    o=horizons[0];assert o['deadline']==entry['time']+seconds
    hits=[t for t in o['touches'] if t['width']==width];assert len(hits)==1
    hit=hits[0];direction=hit['direction'];assert type(direction) is int and direction in (-1,0,1)
    assert (hit['quote'] is None)==(direction==0)
    complete=o['status']=='complete';endpoint=o['endpoint'];assert (endpoint is not None)==complete
    for quote,is_endpoint in ((hit['quote'],False),(endpoint,True)):
        if quote is None:
            continue
        checked_quote(quote)
        assert quote['index']>entry['index'] and quote['source_line']>entry['source_line']
        assert quote['time']<execution_end
        if is_endpoint:
            assert o['deadline']<=quote['time']<=o['deadline']+30
        else:
            assert entry['time']<=quote['time']<=o['deadline']
            movement=side*(quote['bid' if side==1 else 'ask']-price)
            assert movement>=width-1e-9 if direction==1 else movement<=-width+1e-9
    label=2 if not complete else direction
    exit_quote=hit['quote'] if direction else endpoint if complete else None
    known=exit_quote is not None
    mark=exit_quote['bid' if side==1 else 'ask'] if known else math.nan
    points=side*(mark-price) if known else math.nan
    return {'label':label,'direction':direction,'known':known,'points':points,
        'net0':points*100-77 if known else math.nan,'net5':points*100-1077 if known else math.nan,
        'exit_quote':exit_quote,'complete':complete,'endpoint':endpoint,'status':o['status']}


@dataclass
class OutcomeTable:
    case_ids: tuple[str,...]
    sessions: tuple[str,...]
    session_order: tuple[str,...]
    widths: tuple[float,...]
    horizons: tuple[int,...]
    arrays: dict[str,np.ndarray]
    status_names: tuple[str,...]
    evidence: dict

    def case_to_index(self) -> dict[str,int]:
        """
        機能: case識別子から配列位置への一意写像を返す。
        引数: self(OutcomeTable)は完成した純観測表。
        返り値: dict[str,int]は全caseの位置。
        """
        return {case:i for i,case in enumerate(self.case_ids)}

    def view(self, width: float, seconds: int) -> dict[str,np.ndarray]:
        """
        機能: 指定幅・期限の実BUY/SELL列を参照として返す。
        引数: self(OutcomeTable)、width(float)、seconds(int)。
        返り値: dict[str,np.ndarray]はN×2のlabel/direction/known/points/net0/net5/exit原行。
        """
        wi=self.widths.index(width);hi=self.horizons.index(seconds)
        return {name:self.arrays[name][:,:,hi,wi] for name in
            ('labels','directions','known','points','net0','net5','exit_time','exit_index','exit_line')}

    def root_arrays(self, cost: str='C5') -> dict[str,np.ndarray]:
        """
        機能: 探索器向けにcase/実側/幅/期限の順と整数金融を提供する。
        引数: self(OutcomeTable)、cost(str)はC0又はC5。
        返り値: dict[str,np.ndarray]はlabel/net/known/entry_time/exit_time/known_at/session_index。net未知0はknownと同時使用する。
        """
        assert cost in ('C0','C5')
        net=self.arrays['net0' if cost=='C0' else 'net5'].transpose(0,1,3,2)
        known=self.arrays['known'].transpose(0,1,3,2)
        assert np.array_equal(np.isfinite(net),known)
        assert np.all(net[known]==np.rint(net[known])),'整数円へ無損失で写せない'
        mapping={s:i for i,s in enumerate(self.session_order)}
        shape=net.shape
        mature=np.broadcast_to(self.arrays['endpoint_time'][:,:,None,:],shape).copy()
        return {'label':self.arrays['labels'].transpose(0,1,3,2),
            'net':np.nan_to_num(net,nan=0).astype(np.int64),'known':known,
            'entry_time':self.arrays['entry_time'],'entry_index':self.arrays['entry_index'],
            'entry_line':self.arrays['entry_line'],'exit_time':self.arrays['exit_time'].transpose(0,1,3,2),
            'known_at':mature,'session_index':np.asarray([mapping[s] for s in self.sessions],dtype=np.int16)}


def allocate(n: int, widths: tuple, horizons: tuple) -> dict[str,np.ndarray]:
    """
    機能: 未知をNaN又は専用整数で持つ数値配列を確保する。
    引数: n(int)は物理case数、widths/horizons(tuple)は評価軸。
    返り値: dict[str,np.ndarray]はpickle不要の数値配列。
    """
    shape=(n,2,len(horizons),len(widths));short=shape[:3]
    out={name:np.full(shape,math.nan,dtype=np.float64) for name in ('points','net0','net5','exit_time')}
    out.update({name:np.full(shape,-1,dtype=np.int64) for name in ('exit_index','exit_line')})
    out.update(labels=np.full(shape,2,dtype=np.int8),directions=np.zeros(shape,dtype=np.int8),known=np.zeros(shape,dtype=np.bool_))
    out.update({name:np.full(short,math.nan,dtype=np.float64) for name in ('endpoint_time','endpoint_mark')})
    out.update({name:np.full(short,-1,dtype=np.int64) for name in ('endpoint_index','endpoint_line')})
    out.update(complete=np.zeros(short,dtype=np.bool_),status=np.full(short,-1,dtype=np.int16))
    out.update(entry_time=np.full(n,math.nan),entry_index=np.full(n,-1,dtype=np.int64),
        entry_line=np.full(n,-1,dtype=np.int64),entry_price=np.full((n,2),math.nan),original_side=np.zeros(n,dtype=np.int8))
    return out


def project_case(arrays: dict, index: int, case: dict, entry: dict, execution_end: float,
                 widths: tuple, horizons: tuple, status_codes: dict) -> None:
    """
    機能: 元/逆streamを実BUY/SELL順へ置き、指定全幅・期限を配列へ書く。
    引数: arrays(dict)、index(int)、case/entry(dict)、execution_end(float)、widths/horizons(tuple)、status_codes(dict)。
    返り値: None。渡された数値配列の当該case行だけを更新する。
    """
    assert case['id']==entry['id'] and case['original_side']==entry['side']
    q=entry['entry'];checked_quote(q)
    for name,key in (('entry_time','time'),('entry_index','index'),('entry_line','source_line')):
        arrays[name][index]=q[key]
    arrays['original_side'][index]=entry['side']
    for si,side in enumerate(SIDE_ORDER):
        stream=case['original' if case['original_side']==side else 'reverse']
        arrays['entry_price'][index,si]=q['ask' if side==1 else 'bid']
        for hi,horizon in enumerate(horizons):
            for wi,width in enumerate(widths):
                r=project_stream(stream,q,side,execution_end,width,horizon)
                at=(index,si,hi,wi)
                for name in ('known','points','net0','net5'):
                    arrays[name][at]=r[name]
                arrays['labels'][at]=r['label'];arrays['directions'][at]=r['direction']
                if r['known']:
                    for name,key in (('exit_time','time'),('exit_index','index'),('exit_line','source_line')):
                        arrays[name][at]=r['exit_quote'][key]
                if wi==0:
                    key=(index,si,hi)
                    arrays['complete'][key]=r['complete']
                    status=r['status'];status_codes.setdefault(status,len(status_codes));arrays['status'][key]=status_codes[status]
                    if r['endpoint'] is not None:
                        for name,key2 in (('endpoint_time','time'),('endpoint_index','index'),('endpoint_line','source_line')):
                            arrays[name][key]=r['endpoint'][key2]
                        arrays['endpoint_mark'][key]=r['endpoint']['bid' if side==1 else 'ask']


# ----------------------------------------
def read_legacy_outcomes(widths: tuple=(125,200), horizons: tuple=(1800,3600)) -> OutcomeTable:
    """
    機能: 正式148全73場を完読し、保存済み幅・期限の純数値表を作る。
    引数: widths(tuple)は25/50/100/125/200の部分集合、horizons(tuple)は1800/3600の部分集合。
    返り値: OutcomeTableは全31642case×実BUY/SELLのラベル・IFD。自然採否を受け取らない。
    """
    assert widths and horizons and len(widths)==len(set(widths)) and len(horizons)==len(set(horizons))
    assert set(widths)<={25,50,100,125,200} and set(horizons)<={1800,3600}
    before={p:stat_key(p) for p in (FIXED,OBSERVATIONS)}
    assert sha(FIXED)==FIXED_SHA and sha(OBSERVATIONS)==OBS_SHA
    body=gzip.decompress(FIXED.read_bytes());assert hashlib.sha256(body).hexdigest()==FIXED_DECODED_SHA
    fixed=json.loads(body);assert len(fixed['scenes'])==73 and fixed['expected_entry_count']==31642
    ids=[];sessions=[];session_order=[];arrays=allocate(31642,widths,horizons);status_codes={}
    with gzip.open(OBSERVATIONS,'rb') as source:
        hashed=DigestReader(source)
        for scene_index,observed in enumerate(ijson.items(hashed,'scenes.item',use_float=True)):
            assert scene_index<73;scene=fixed['scenes'][scene_index]
            assert observed['success'] and observed['session']==scene['session']
            assert observed['actual_sha256']==scene['raw']['sha256'] and observed['stat_before']==observed['stat_after']
            assert observed['quality']==observed['expected_quality']==scene['expected_quality']
            execution_end=scene['end']-300
            assert observed['execution_end']==execution_end
            assert observed['effective_entry_limit']==min(scene['force_close'],scene['end']-3900)
            entries={e['id']:e for e in scene['entries']};found=set()
            for case in observed['cases']:
                case_id=case['id'];assert case_id in entries and case_id not in found
                project_case(arrays,len(ids),case,entries[case_id],execution_end,widths,horizons,status_codes)
                found.add(case_id);ids.append(case_id);sessions.append(scene['session'])
            assert found==set(entries)
            session_order.append(scene['session'])
        assert hashed.read()==b''
        digest,size=hashed.digest.hexdigest(),hashed.size
    assert len(session_order)==73 and len(ids)==31642 and len(set(ids))==31642
    assert session_order[0]=='2026-09-21_Day' and session_order[-1]=='2026-11-10_Day'
    assert digest==OBS_DECODED_SHA
    assert all(stat_key(p)==s for p,s in before.items()) and sha(FIXED)==FIXED_SHA and sha(OBSERVATIONS)==OBS_SHA
    evidence={'成功':True,'自然採否なし':True,'全CRC':True,'全73場':session_order,'case数':len(ids),
        'ijson':ijson.__version__,'保存幅':list(widths),'保存期限秒':list(horizons),'side_order':list(SIDE_ORDER),
        '固定入力':{'path':str(FIXED.relative_to(ROOT)),'sha256':FIXED_SHA,'decoded_sha256':FIXED_DECODED_SHA},
        '元148観測':{'path':str(OBSERVATIONS.relative_to(ROOT)),'sha256':OBS_SHA,'decoded_sha256':digest,'decoded_bytes':size},
        '費用':'1mini100円/pt、往復77円。C5は追加控除1000円。',
        '時計':'取得q1原行は観測せず、同秒後続原行は可。厳密H完了のみF/A/N、他C。Cでも既知touch金融可。'}
    order=np.argsort(np.asarray(ids),kind='stable')
    ids=[ids[i] for i in order];sessions=[sessions[i] for i in order]
    arrays={name:array[order] for name,array in arrays.items()}
    return OutcomeTable(tuple(ids),tuple(sessions),tuple(session_order),tuple(widths),tuple(horizons),arrays,
        tuple(sorted(status_codes,key=status_codes.get)),evidence)


def save_table(table: OutcomeTable, directory: Path) -> dict:
    """
    機能: 数値NPZとgzip識別情報へ一度だけ保存する。
    引数: table(OutcomeTable)、directory(Path)は未作成保存先。
    返り値: dictは保存2ファイルの物理指紋とサイズ。
    """
    assert not directory.exists();directory.mkdir(parents=True)
    npz=directory/'観測配列.npz';np.savez_compressed(npz,**table.arrays)
    meta={'case_ids':table.case_ids,'sessions':table.sessions,'session_order':table.session_order,
        'widths':table.widths,'horizons':table.horizons,'status_names':table.status_names,'evidence':table.evidence,
        'arrays':{k:{'shape':list(v.shape),'dtype':str(v.dtype)} for k,v in table.arrays.items()}}
    encoded=json.dumps(meta,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode('utf-8')
    target=directory/'観測識別.json.gz'
    with target.open('xb') as raw:
        with gzip.GzipFile(filename='',mode='wb',mtime=0,fileobj=raw) as output:
            output.write(encoded)
    return {p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in (npz,target)}


def load_table(directory: Path, expected: dict) -> OutcomeTable:
    """
    機能: 保存指紋と全ZIP/gzip CRCを確認して数値表を復元する。
    引数: directory(Path)、expected(dict)は2保存ファイル名からsha256/bytesへの固定写像。
    返り値: OutcomeTableはpickleを使わない復元表。
    """
    for name,ref in expected.items():
        p=directory/name;assert p.stat().st_size==ref['bytes'] and sha(p)==ref['sha256']
    meta=json.loads(gzip.decompress((directory/'観測識別.json.gz').read_bytes()))
    with np.load(directory/'観測配列.npz',allow_pickle=False) as source:
        assert set(source.files)==set(ARRAY_NAMES)
        arrays={k:source[k].copy() for k in source.files}
    assert all(a.dtype.kind!='O' and list(a.shape)==meta['arrays'][k]['shape'] and str(a.dtype)==meta['arrays'][k]['dtype'] for k,a in arrays.items())
    assert set(meta['evidence']['side_order'])==set(SIDE_ORDER)
    return OutcomeTable(tuple(meta['case_ids']),tuple(meta['sessions']),tuple(meta['session_order']),
        tuple(meta['widths']),tuple(meta['horizons']),arrays,tuple(meta['status_names']),meta['evidence'])


def batch_summary(table: OutcomeTable, masks: np.ndarray, width: float, seconds: int,
                  cost: str='C5') -> dict[str,np.ndarray]:
    """
    機能: 複数政策の取得マスクを同じ幅・期限で高速集計する。
    引数: table(OutcomeTable)、masks(np.ndarray[bool,K,N,2])は重複除去済み実側選択、width(float)、seconds(int)、cost(str C0/C5)。
    返り値: dict[str,np.ndarray]は政策ごとの取得/F/A/N/C/既知/未知/利益/損失/差引/率/PF。
    """
    selected=np.asarray(masks);assert selected.dtype==np.bool_ and selected.ndim==3 and selected.shape[1:]==(len(table.case_ids),2)
    assert not np.any(selected.sum(axis=2)>1),'同じ物理q1の両側を一政策へ二重計数しない'
    assert cost in ('C0','C5');view=table.view(width,seconds);flat=selected.reshape(len(selected),-1)
    net=view['net0' if cost=='C0' else 'net5'].reshape(-1)
    columns={label:(view['labels'].reshape(-1)==code).astype(np.int64) for label,code in LABELS.items()}
    columns['取得']=np.ones(len(net),dtype=np.int64);columns['既知']=view['known'].reshape(-1).astype(np.int64)
    matrix=np.column_stack([*columns.values(),np.maximum(np.nan_to_num(net,nan=0),0),np.maximum(-np.nan_to_num(net,nan=0),0)])
    totals=np.empty((len(flat),matrix.shape[1]),dtype=np.float64)
    for begin in range(0,len(flat),128):
        totals[begin:begin+128]=flat[begin:begin+128].astype(np.float64)@matrix
    counts={name:totals[:,i].astype(np.int64) for i,name in enumerate(columns)}
    profit,loss=totals[:,-2],totals[:,-1]
    resolved=counts['F']+counts['A'];complete=resolved+counts['N']
    def divide(a: np.ndarray, b: np.ndarray) -> np.ndarray:
        """
        機能: 分母0の率をNaNとして保持する。
        引数: a/b(np.ndarray)は政策ごとの分子/分母。
        返り値: np.ndarray[float64]は比率。
        """
        return np.divide(a,b,out=np.full(len(a),np.nan),where=b!=0)
    return {**counts,'未知':counts['取得']-counts['既知'],'利益':profit,'損失':loss,'既知差引':profit-loss,
        '到達済み率':divide(counts['F'],resolved),'完了分母率':divide(counts['F'],complete),
        '全件分母率':divide(counts['F'],counts['取得']),'PF':divide(profit,loss)}
