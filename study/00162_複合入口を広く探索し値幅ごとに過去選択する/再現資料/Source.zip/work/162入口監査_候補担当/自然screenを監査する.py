"""保存済み出生と共有型付き金融から、162の全screenを独立再計算する。"""
from pathlib import Path
from collections import Counter
import gzip
import hashlib
import json
import sys
import time

import numpy as np
from 独立純計算 import ROOT,HERE,load_module,edge,link,integrate,stats,compare,timeband


def sha(path: Path) -> str:
    """
    機能: 物理ファイルを全読了して指紋化する。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    with path.open('rb') as source:return hashlib.file_digest(source,'sha256').hexdigest()


def read(path: Path) -> object:
    """
    機能: gzipの全CRCと前後の物理同体を確認してJSONを読む。
    引数: path(Path)。
    返り値: objectは解析済みJSON。
    """
    before=sha(path);body=path.read_bytes()
    result=json.loads(gzip.decompress(body) if path.suffix=='.gz' else body)
    assert sha(path)==before
    return result


def main() -> None:
    """
    機能: 原判断を再選択せず、全取得集合と全screen統計を別計算で照合する。
    引数: なし。広い評価の完了票が必要。原観測金融の再射影は別担当の検査範囲。
    返り値: None。全数比較と旧125対照の同体票を保存する。
    """
    sys.path.insert(0,str(ROOT/'work/162入口探索'))
    basis=load_module(ROOT/'work/162入口探索/評価基盤.py','basis162_natural_audit')
    book_path=ROOT/'study/00162_複合入口を広く探索し値幅ごとに過去選択する/条件.json'
    assert sha(book_path)=='4f890114b789da404d400f49a5cb888e9b9014013b00fcc0f77dc6ffd691088c'
    setting=read(book_path);screen_folder=ROOT/'work/162入口探索/広い評価'
    complete=read(screen_folder/'完了.json');assert complete['成功']
    birth_folder=ROOT/'work/162入口探索/全出生';birth_proof=read(birth_folder/'全出生の確認.json')
    paths=[Path(__file__),HERE/'独立純計算.py',book_path,ROOT/'work/162入口探索/評価基盤.py',
        ROOT/'work/162入口探索/全出生を作る.py',ROOT/'work/162入口探索/広く評価する.py',
        screen_folder/'完了.json',screen_folder/'旧対照.json.gz',birth_folder/'全出生の確認.json']
    paths += [screen_folder/f'全探索{w}.json.gz' for w in setting['widths']]
    paths += [birth_folder/f'出生{w}.npz' for w in setting['widths']]
    before={str(p.relative_to(ROOT)):sha(p) for p in paths}
    context=basis.Context();arrays=context.arrays;scenes=context.case_scene.tolist()
    q0=context.features.q0_meta;event_index={r['event_id']:i for i,r in enumerate(q0)}
    sessions=[s['session'] for s in context.features.scenes];scene_index={s:i for i,s in enumerate(sessions)}
    event_phases=[timeband(r['session'],r['q0_time']) for r in q0]
    assert event_phases==context.event_phases.tolist()
    case_phases=[timeband(s,float(t)) for s,t in zip(context.table.sessions,arrays['entry_time'],strict=True)]
    assert case_phases==context.case_phases.tolist()
    entry_quotes=list(zip(arrays['entry_time'].tolist(),arrays['entry_index'].tolist(),arrays['entry_line'].tolist(),strict=True))
    physical=[(scenes[i],*q) for i,q in enumerate(entry_quotes)]
    assert len(set(physical))==len(physical)
    # ----------------------------------------
    capture_path=ROOT/'inputs/00148_全1分入口母集団/取得対応.json.gz'
    metadata_path=ROOT/'inputs/00148_全1分入口母集団/入口参照.json.gz'
    assert sha(capture_path)=='7c27420abe6af0867f6cf3d8fd838205da3ed099df8db8e5b5d62892cbadf6bc'
    assert sha(metadata_path)=='ad53cccf8e4da093ebd32c1ddc80132ddcd4c73d8f20897c4033f0895fc966b6'
    capture=read(capture_path);metadata=read(metadata_path)
    event_cases=[-1]*len(q0)
    for row in capture['rows']:
        i=event_index[row['event_id']];expected=q0[i]
        assert tuple(row['q0'][k] for k in ('time','index','source_line'))==tuple(expected[k] for k in ('q0_time','q0_index','q0_line'))
        if row['status']=='filled':
            case=context.case_map[row['case_id']];event_cases[i]=case
            assert entry_quotes[case]==tuple(row['q1'][k] for k in ('time','index','source_line'))
    assert event_cases==context.event_cases.tolist()
    legacy=[];first=[None]*73;births=[None]*73;first_keys=[None]*73
    for row in metadata['entries']:
        scene=scene_index[row['session']];case=context.case_map[row['id']]
        birth=row['origins'][0]['birthQuote'];clock=tuple(birth[k] for k in ('time','index','source_line'))
        record=(case,0 if row['native_side']==1 else 1,-1,timeband(row['session'],birth['time']),True)
        legacy.append(record);key=clock+(row['id'],)
        if first[scene] is None or key<first_keys[scene]:first[scene]=record;births[scene]=clock;first_keys[scene]=key
    assert len(legacy)==87 and all(r is not None for r in first)
    assert sorted(legacy)==sorted(tuple(r) for r in zip(context.legacy.cases.tolist(),context.legacy.sides.tolist(),
        context.legacy.events.tolist(),context.legacy.phases.tolist(),context.legacy.old.tolist(),strict=True))
    # ----------------------------------------
    period_names=('全期','前48場','後25場');leaves=0;record_count=0;edge_comparisons=0;begin=time.monotonic()
    for wi,width in enumerate(setting['widths']):
        birth_path=birth_folder/f'出生{width}.npz'
        assert sha(birth_path)==birth_proof['files'][birth_path.name]['sha256']
        with np.load(birth_path,allow_pickle=False) as source:matrices={k:source[k].copy() for k in source.files}
        assert set(matrices)=={'ALL','EDGE'}
        full=read(screen_folder/f'全探索{width}.json.gz')
        assert full['成功']
        lookup={r['id']:r for r in full['rows']};assert len(lookup)==len(full['rows'])
        for i,rule in enumerate(birth_proof['規則順']):
            expected_edge=edge(matrices['ALL'][i].tolist(),context.event_scenes.tolist(),context.event_times.tolist())
            assert matrices['EDGE'][i].tolist()==expected_edge
            edge_comparisons+=len(expected_edge)
            for mode in ('ALL','EDGE'):
                directions=matrices[mode][i].tolist()
                new=link(directions,event_cases,event_phases)
                for integration in ('N','U','F'):
                    chosen=integrate(new,legacy,first,births,scenes,entry_quotes,integration)
                    assert len(chosen)==len({r[0] for r in chosen})
                    if integration!='N':assert len({scenes[r[0]] for r in chosen})==73
                    for hi,horizon in enumerate(setting['horizons']):
                        key=f'{rule}_{mode}_W{width}_H{horizon}_{integration}';record=lookup.pop(key)
                        assert record['born']==sum(v!=0 for v in directions) and record['acquired_new']==len(new)
                        expected_periods={p:stats(chosen,arrays,context.hours,case_phases,wi,hi,p) for p in period_names}
                        expected_bands={p:[stats(chosen,arrays,context.hours,case_phases,wi,hi,p,b) for b in range(3)] for p in period_names}
                        leaves+=compare(record['periods'],expected_periods,key+'/periods')
                        leaves+=compare(record['bands'],expected_bands,key+'/bands')
                        record_count+=1
            if i%150==0:print(json.dumps({'幅':width,'規則':i+1,'照合行':record_count,'秒':round(time.monotonic()-begin)},ensure_ascii=False),flush=True)
        assert not lookup
    # ----------------------------------------
    old_controls={'C1':legacy};old_inputs=[]
    for folder,names in [('00152_複合回復の方向切替',('A0','U0','B0','U1')),('00153_先行高安の独立出生',('N15','U15'))]:
        path=ROOT/'inputs'/folder/'選択対応.json.gz';old_inputs.append({'path':str(path.relative_to(ROOT)),'sha256':sha(path)})
        saved=read(path)
        for name in names:
            items=[]
            for r in saved['政策'][name]:
                event=event_index[r['event_id']] if r['event_id'] is not None else -1
                case=context.case_map[r['case_id']]
                phase=event_phases[event] if event>=0 else next(x[3] for x in legacy if x[0]==case)
                items.append((case,0 if r['side']==1 else 1,event,phase,r['origin']=='C1'))
            old_controls[folder[:5]+'_'+name]=items
    saved_controls=read(screen_folder/'旧対照.json.gz')['rows'];assert len(saved_controls)==28
    for r in saved_controls:
        wi=setting['widths'].index(r['width']);hi=setting['horizons'].index(r['horizon'])
        name=r['id'].rsplit('_W',1)[0];selected=old_controls[name]
        leaves+=compare(r['periods'],{p:stats(selected,arrays,context.hours,case_phases,wi,hi,p) for p in period_names},r['id'])
        leaves+=compare(r['bands'],{p:[stats(selected,arrays,context.hours,case_phases,wi,hi,p,b) for b in range(3)] for p in period_names},r['id'])
    # ----------------------------------------
    prior=read(ROOT/'study/00161_三時間帯の入口を共通属性分割で比較する/成果物/型付き四表.json')
    table=prior['tables']['比較一覧'];prior_rows={(d['政策'],d['期間']):d for d in [dict(zip(table['headers'],r)) for r in table['rows']]}
    aliases={'C1':'C1','00152_A0':'COMMON_P65_A_N','00152_U0':'COMMON_P65_A_U','00152_B0':'OLD152_B0_N',
        '00152_U1':'OLD152_U1','00153_N15':'OLD153_N15','00153_U15':'OLD153_U15'}
    mapping={'count':'取得','F':'順','A':'逆','N':'未到達','C':'観測不足','rate':'到達済み先着率',
        'profit':'利益総額','loss':'損失総額','net':'既知差引','unknown':'金融未知','known':'金融既知',
        'new_count':'新枝取得','old_count':'旧C1取得'}
    for source,target in aliases.items():
        for period in period_names:
            value=stats(old_controls[source],arrays,context.hours,case_phases,0,1,period)
            for key,column in mapping.items():leaves+=compare(value[key],prior_rows[(target,period)][column],source+'/'+period+'/'+key)
    assert all(sha(ROOT/p)==value for p,value in before.items())
    proof={'成功':True,'条件SHA256':sha(book_path),'全screen行':record_count,'旧対照行':len(saved_controls),
        'EDGE全q0照合':edge_comparisons,'比較葉数':leaves,'全場U/Fの実取得を確認':True,
        '旧125H60の7政策前後同体':True,'入力q0帯と出力q1帯を独立暦算':True,'旧入力':old_inputs,
        '範囲':'候補式の独立再実装ではなく、保存出生からの政策・時計・集計の独立検査。金融原観測の射影検査は別担当。',
        '金融配列':'作者のSHA固定型付き入力を共用。算式と取得・補完は別実装。',
        'Sourceと入力':before,'経過秒':time.monotonic()-begin}
    (HERE/'自然screen監査結果.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
