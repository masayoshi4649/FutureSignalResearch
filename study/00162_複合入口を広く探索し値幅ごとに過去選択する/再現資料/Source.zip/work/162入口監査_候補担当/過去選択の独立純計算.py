"""162の過去20場・同帯・支持順位を作者と別の逐次計算で再現する。"""
import math


def metric(rows: list,arrays: dict,current: int,band: int,starts: list,hours: object,identifier: dict) -> dict:
    """
    機能: 一候補の取得から成熟済み過去20場の同帯だけを逐次集計する。
    引数: rows(list[tuple])、arrays(dict)、current/band(int)、starts(list)、hours(object)、identifier(dict)。
    返り値: dictはselectorへ渡す集計。現場/未来は時計・ラベルを読む前に除外する。
    """
    first=max(0,current-20);f=a=n=profit=loss=0;counts={s:0 for s in range(first,current)}
    for case,side,event,phase,old in rows:
        scene=int(arrays['session_index'][case])
        if not(first<=scene<current) or phase!=band:continue
        # wi/hiは呼出側で一幅・一期限へ切り出してある。
        pair=arrays['label'][case]
        if any(int(value)==2 for value in pair):continue
        maturity=max(float(v) for v in arrays['known_at'][case])
        assert math.isfinite(maturity) and maturity<starts[current]
        label=int(pair[side]);money=int(arrays['net'][case,side]);assert bool(arrays['known'][case,side])
        f+=label==1;a+=label==-1;n+=label==0;profit+=max(money,0);loss+=max(-money,0);counts[scene]+=1
    count=f+a+n
    return {**identifier,'F':f,'A':a,'N':n,'C':0,'count':count,'profit':profit,'loss':loss,'net':profit-loss,
        'scene_count':sum(v>0 for v in counts.values()),'scene_max_share':max(counts.values(),default=0)/count if count else 0,
        'hours':sum(float(hours[s][band]) for s in range(first,current))}


def choose(metrics: list,setting: dict) -> dict:
    """
    機能: Wilson下限と頻度/場集中の別算式で採否・群優先順位を再構成する。
    引数: metrics(list[dict])は過去集計、setting(dict)は固定条件。
    返り値: dictはselected_ids・eligible_count・棄却理由数・選択行。
    """
    rows=[];rejected={};z=1.959963984540054
    for row in metrics:
        f=row['F'];a=row['A'];n=f+a;rate=f/n if n else None
        lower=((rate+z*z/(2*n)-z*math.sqrt(rate*(1-rate)/n+z*z/(4*n*n)))/(1+z*z/n)) if n else None
        assert setting['minimum_pf']==1.1
        pf_ok=row['profit']*10>=row['loss']*11 if row['loss'] else row['profit']>0
        reasons=[]
        if row['scene_count']<setting['minimum_scenes']:reasons.append('取得場数不足')
        if n<setting['minimum_resolved']:reasons.append('到達済み数不足')
        if rate is None or rate<setting['minimum_forward_rate']:reasons.append('先着率不足又は未定義')
        if not pf_ok:reasons.append('PF不足又は未定義')
        if row['net']<=setting['minimum_known_net']:reasons.append('既知差引は下限を超えない')
        if row['scene_max_share']>setting['maximum_scene_share']:reasons.append('最多場集中が上限を超過')
        for reason in reasons:rejected[reason]=rejected.get(reason,0)+1
        if not reasons:
            hourly=row['count']/row['hours'];score=lower+.02*math.log1p(hourly)-.15*row['scene_max_share']
            rows.append((score,row))
    ranked=sorted(rows,key=lambda pair:(-pair[0],pair[1]['id']))
    chosen=[];used_bases=set();used_groups=set()
    for distinct in (True,False):
        for score,row in ranked:
            if len(chosen)>=setting['top_k']:break
            base=row.get('rule_id',row.get('base_id',row['id'].rsplit('_',1)[0]))
            if base in used_bases or distinct and row['group'] in used_groups:continue
            chosen.append(row['id']);used_bases.add(base);used_groups.add(row['group'])
    return {'selected_ids':chosen,'eligible_count':len(ranked),'rejection_counts':dict(sorted(rejected.items()))}


def union(matrix: object,indices: list,events: list) -> list:
    """
    機能: 各q0で選択済み規則を逐次確認し両側競合を待機へする。
    引数: matrix(object)は規則方式×q0、indices(list[int])、events(list[int])。
    返り値: list[int]は当該eventsの方向。
    """
    out=[]
    for event in events:
        sides={int(matrix[i,event]) for i in indices if matrix[i,event]!=0}
        out.append(next(iter(sides)) if len(sides)==1 else 0)
    return out
