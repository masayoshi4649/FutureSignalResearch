"""162評価器の取得・補完・統計を、別の素朴な計算で照合する。"""
from datetime import date,datetime
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import sys

import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def load_module(path: Path,name: str) -> object:
    """
    機能: main未実行で監査対象の純メソッドを読み込む。
    引数: path(Path)、name(str)。
    返り値: objectは登録済みmodule。
    """
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec)
    sys.modules[name]=value;spec.loader.exec_module(value);return value


def timeband(session: str,timestamp: float) -> int:
    """
    機能: US夏時間暦の別計算から2026年等の三帯を判定する。
    引数: session(str)は場日付とDay/Night、timestamp(float)は価格UTC秒。
    返り値: intはDay0/米国前1/以後2。等号は以後。
    """
    text,kind=session.rsplit('_',1)
    if kind=='Day':return 0
    assert kind=='Night'
    day=date.fromisoformat(text);year=day.year;assert year>=2007
    march_sunday=1+(6-date(year,3,1).weekday())%7
    november_sunday=1+(6-date(year,11,1).weekday())%7
    summer=date(year,3,march_sunday+7)<=day<date(year,11,november_sunday)
    boundary=datetime.fromisoformat(text+('T22:30:00+09:00' if summer else 'T23:30:00+09:00')).timestamp()
    return 1 if timestamp<boundary else 2


def edge(directions: list,sessions: list,times: list) -> list:
    """
    機能: 同場の前方向と180秒の区切りから発火だけを残す。
    引数: directions/sessions/times(list)は当時q0順。
    返り値: list[int]は0を含む発火方向。帯境界は参照しない。
    """
    out=[]
    for index,value in enumerate(directions):
        reset=index==0 or sessions[index]!=sessions[index-1] or times[index]-times[index-1]>180
        out.append(value if reset or value!=directions[index-1] else 0)
    return out


def rows(selected: object) -> list:
    """
    機能: 作者Selectionを独立な組の一覧へ変換する。
    引数: selected(object)はcases/sides/events/phases/old。
    返り値: list[tuple]は物理case・側0/1・event・q0帯・旧旗。
    """
    return [tuple(int(x) if j<4 else bool(x) for j,x in enumerate(record)) for record in zip(
        selected.cases,selected.sides,selected.events,selected.phases,selected.old,strict=True)]


def link(directions: list,event_cases: list,event_phases: list) -> list:
    """
    機能: 全q0を逐次走査して最初の成立取得を一物理case一件にする。
    引数: directions/event_cases/event_phases(list)は当時出生と後結合した取得対応。
    返り値: list[tuple]は新規取得。未取得と後発aliasを加算しない。
    """
    used=set();out=[]
    for index,(direction,case,phase) in enumerate(zip(directions,event_cases,event_phases,strict=True)):
        if direction and case>=0 and case not in used:
            out.append((case,0 if direction==1 else 1,index,phase,False));used.add(case)
    return out


def integrate(new: list,legacy: list,first_legacy: list,first_birth: list,case_scene: list,
              entry_quotes: list,mode: str) -> list:
    """
    機能: 時計を組で比較してN/U/Fを作者のvector式とは別に再構成する。
    引数: new/legacy/first_legacy/first_birth/case_scene/entry_quotes(list)、mode(str)。
    返り値: list[tuple]は旧優先統合。未約定要求や損益を入力へ持たない。
    """
    if mode=='N':return list(new)
    if mode=='U':old=legacy
    else:
        assert mode=='F'
        acquired=[False]*73
        for record in new:
            scene=case_scene[record[0]]
            if tuple(entry_quotes[record[0]])<=tuple(first_birth[scene]):acquired[scene]=True
        old=[record for scene,record in enumerate(first_legacy) if not acquired[scene]]
    used={r[0] for r in old}
    return [r for r in new if r[0] not in used]+old


def stats(selected: list,arrays: dict,hours: object,case_phases: list,wi: int,hi: int,
          period: str='全期',band: int|None=None) -> dict:
    """
    機能: Pythonの逐次集計で先着・参加・未知・利益損失を再計算する。
    引数: selected(list[tuple])、arrays(dict)、hours(object)は73×3時間、case_phases(list)、
          wi/hi(int)、period(str)、band(int又はNone)。
    返り値: dictは作者statsと同じ意味の値。作者の算式関数を呼ばない。
    """
    eligible=[s for s in range(73) if (period=='全期' or (s<48 if period=='前48場' else s>=48))
        and (band is None or hours[s][band]>0)]
    wanted=set(eligible);counts={s:0 for s in range(73)};labels=[];money=[];durations=[];old=0
    for record in selected:
        case,side,event,phase,is_old=record;scene=int(arrays['session_index'][case])
        if scene not in wanted or band is not None and case_phases[case]!=band:continue
        labels.append(int(arrays['label'][case,side,wi,hi]));counts[scene]+=1;old+=is_old
        if bool(arrays['known'][case,side,wi,hi]):
            money.append(int(arrays['net'][case,side,wi,hi]))
            durations.append(float(arrays['exit_time'][case,side,wi,hi])-float(arrays['entry_time'][case]))
    duration=sum(sum(hours[s]) if band is None else hours[s][band] for s in eligible)
    f=labels.count(1);a=labels.count(-1);n=labels.count(0);c=labels.count(2)
    profit=sum(x for x in money if x>0);loss=-sum(x for x in money if x<0)
    ordered=sorted(durations);median=None
    if ordered:
        middle=len(ordered)//2;median=ordered[middle] if len(ordered)%2 else (ordered[middle-1]+ordered[middle])/2
    return {'count':len(labels),'F':f,'A':a,'N':n,'C':c,'rate':f/(f+a) if f+a else None,
        'complete_rate':f/(f+a+n) if f+a+n else None,'all_rate':f/len(labels) if labels else None,
        'profit':profit,'loss':loss,'net':profit-loss,'pf':profit/loss if loss else None,
        'known':len(money),'unknown':len(labels)-len(money),'scenes':sum(v>0 for v in counts.values()),
        'eligible_scenes':len(eligible),'all_scenes':bool(eligible) and all(counts[s]>0 for s in eligible),
        'hours':duration,'per_hour':len(labels)/duration if duration else None,
        'max_scene_share':max(counts.values())/len(labels) if labels else None,
        'new_count':len(labels)-old,'old_count':old,'hold_median_seconds':median}


def compare(actual: object,expected: object,path: str='') -> int:
    """
    機能: 数値の丸め以外を厳密に再帰比較する。
    引数: actual/expected(object)、path(str)は診断位置。
    返り値: intは比較した葉数。不一致はAssertionError。
    """
    if isinstance(expected,dict):
        assert set(actual)==set(expected),(path,'keys')
        return sum(compare(actual[k],v,path+'/'+str(k)) for k,v in expected.items())
    if isinstance(expected,(list,tuple)):
        assert len(actual)==len(expected),(path,'length')
        return sum(compare(a,b,path+'/'+str(i)) for i,(a,b) in enumerate(zip(actual,expected,strict=True)))
    if isinstance(expected,float):
        assert actual is not None and math.isclose(float(actual),expected,rel_tol=1e-12,abs_tol=1e-9),(path,actual,expected)
    else:assert actual==expected,(path,actual,expected)
    return 1
