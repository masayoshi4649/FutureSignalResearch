"""162過去選択の窓と未来不使用を人工教師だけで検査する。"""
from pathlib import Path
from types import SimpleNamespace
import hashlib
import json
import sys

import numpy as np
from 独立純計算 import ROOT,HERE,load_module,compare
from 過去選択の独立純計算 import metric,choose,union


def main() -> None:
    """
    機能: 過去窓集計・支持順位・未来毒入れ・競合を別実装と照合する。
    引数: なし。人工教師と固定bookだけを使う。
    返り値: None。自然結果未読の監査票を保存する。
    """
    sys.path.insert(0,str(ROOT/'work/162入口探索'))
    root=load_module(ROOT/'work/162入口探索/過去で選ぶ.py','past162_artificial_audit')
    selector=load_module(ROOT/'work/162過去規則選択/selector162.py','selector162_artificial_audit')
    setting=json.loads((ROOT/'study/00162_複合入口を広く探索し値幅ごとに過去選択する/条件.json').read_text(encoding='utf-8'))
    rng=np.random.default_rng(16241);starts=[10000+s*10000 for s in range(73)]
    hours=np.array([[7,0,0] if s%2==0 else [0,5.5,7.5] for s in range(73)])
    labels=rng.choice((-1,0,1,2),size=(500,2,1,1));scenes=np.arange(500)%73
    known=labels!=2;money=rng.integers(-15000,16000,size=labels.shape)
    clocks=np.array([starts[int(s)]+300 for s in scenes],dtype=float)[:,None,None,None]*np.ones((1,2,1,1))
    arrays={'label':labels,'session_index':scenes,'known':known,'net':money,'known_at':clocks}
    context=SimpleNamespace(arrays=arrays,case_scene=scenes,starts=np.array(starts),hours=hours)
    selected=[];records=[]
    for i in range(12):
        cases=np.arange(i*7,500,12);sides=rng.integers(0,2,size=len(cases));phases=np.array([0 if scenes[c]%2==0 else 1+c%2 for c in cases])
        selected.append(SimpleNamespace(cases=cases,sides=sides,phases=phases,
            take=lambda mask,c=cases,s=sides,p=phases:SimpleNamespace(cases=c[mask],sides=s[mask],phases=p[mask])))
        records.append([(int(c),int(s),-1,int(p),False) for c,s,p in zip(cases,sides,phases,strict=True)])
    # Root build_historyのtakeを返す型だけを人工で再現する。
    history,maturity=root.build_history(context,selected,0,0)
    identifiers=[{'id':f'人工{i:02d}_ALL','rule_id':f'人工{i:02d}','group':str(i%4)} for i in range(12)]
    narrow={k:(v[:,:,0,0] if k in ('label','known','net','known_at') else v) for k,v in arrays.items()}
    leaves=0;selections=0
    for current in (0,1,5,20,21,39,72):
        for band in range(3):
            actual,clock=root.past_metrics(history,maturity,context,identifiers,current,band)
            expected=[metric(r,narrow,current,band,starts,hours,identifier) for r,identifier in zip(records,identifiers,strict=True)]
            for a,b in zip(actual,expected,strict=True):leaves+=compare(a,b)
            poison=history.copy();poison[:,current:,:,:]=999999
            later=maturity.copy();later[:,current:,:]=1e20
            unchanged,after=root.past_metrics(poison,later,context,identifiers,current,band)
            assert unchanged==actual and after==clock
            if current>20:
                outside=history.copy();outside[:,:current-20,:,:]=777777
                ignored,_=root.past_metrics(outside,maturity,context,identifiers,current,band);assert ignored==actual
            for config in setting['selection']['selectors']:
                a=selector.select_with_audit(actual,config);b=choose(expected,config)
                for key in ('selected_ids','eligible_count','rejection_counts'):leaves+=compare(a[key],b[key])
                selections+=1
    # ----------------------------------------
    for iteration in range(100):
        generated=[]
        for i in range(30):
            f=int(rng.integers(0,80));a=int(rng.integers(0,40));n=int(rng.integers(0,30));count=f+a+n
            scenes_count=min(count,int(rng.integers(1,16)))
            profit=f*11423+n*1000;loss=a*13577
            generated.append({'id':f'G{(i//2)%4}R{i//2:02d}_{"ALL" if i%2==0 else "EDGE"}',
                'rule_id':f'G{(i//2)%4}R{i//2:02d}','group':f'G{(i//2)%4}','F':f,'A':a,'N':n,'C':0,'count':count,
                'profit':profit,'loss':loss,'net':profit-loss,'scene_count':scenes_count,
                'scene_max_share':1/scenes_count if count else 0,'hours':100.0})
        for config in setting['selection']['selectors']:
            a=selector.select_with_audit(generated,config);b=choose(generated,config)
            for key in ('selected_ids','eligible_count','rejection_counts'):leaves+=compare(a[key],b[key])
            selections+=1
    for count in (0,1,3,8):
        matrix=rng.choice((-1,0,1),size=(8,11));indices=list(range(count));events=list(range(11))
        assert root.union_directions(matrix,indices,np.array(events)).tolist()==union(matrix,indices,events)
    proof={'成功':True,'自然結果未読':True,'比較葉数':leaves,'選択照合':selections,
        '確認':['両実側complete pairだけ','過去20暦場と同q0帯','成熟strict時計','現在/未来毒入れ不変',
            '窓外過去毒入れ不変','8固定支持順位','異群優先と同base重複除外','両側OR競合待機'],
        'SourceSHA256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in
            (ROOT/'work/162入口探索/過去で選ぶ.py',ROOT/'work/162過去規則選択/selector162.py',HERE/'過去選択の独立純計算.py',Path(__file__))}}
    (HERE/'過去選択の人工監査結果.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':
    main()
