"""作者の自然評価を呼ばず、取得・補完・集計の境界を人工検査する。"""
from pathlib import Path
from types import SimpleNamespace
import hashlib
import json
import sys

import numpy as np
from 独立純計算 import ROOT,HERE,load_module,edge,rows,link,integrate,stats,compare,timeband


def main() -> None:
    """
    機能: 人工気配・出生・金額から作者評価器の純メソッドを独立検算する。
    引数: なし。自然X・観測・screen出力を読まない。
    返り値: None。境界とランダム場の検査結果を保存する。
    """
    sys.path.insert(0,str(ROOT/'work/162入口探索'))
    basis=load_module(ROOT/'work/162入口探索/評価基盤.py','basis162_artificial_audit')
    births=load_module(ROOT/'work/162入口探索/全出生を作る.py','birth162_artificial_audit')
    directions=[1,1,0,1,-1,-1,0,-1,1,1]
    scenes=[0]*8+[1]*2;times=[0,60,120,180,240,420,480,661,0,181]
    assert births.edge_directions(np.array(directions,dtype=np.int8),np.array(scenes),np.array(times)).tolist()==edge(directions,scenes,times)
    rng=np.random.default_rng(16231);cases=287;event_count=500
    case_scene=np.arange(cases,dtype=np.int16)%73
    entry_time=1000+np.arange(cases,dtype=np.float64)*3
    entry_index=np.arange(cases,dtype=np.int64)*2+10;entry_line=entry_index+100
    label=rng.choice((-1,0,1,2),size=(cases,2,2,2)).astype(np.int8)
    known=(label!=2)|(rng.random(label.shape)>.5)
    money=rng.integers(-20000,20001,size=label.shape,dtype=np.int64)
    exit_time=entry_time[:,None,None,None]+rng.integers(1,1801,size=label.shape)
    arrays={'session_index':case_scene,'entry_time':entry_time,'entry_index':entry_index,'entry_line':entry_line,
        'label':label,'known':known,'net':money,'exit_time':exit_time}
    context=object.__new__(basis.Context);context.arrays=arrays;context.case_scene=case_scene
    context.event_cases=rng.integers(-1,cases,size=event_count,dtype=np.int32)
    context.event_phases=rng.integers(0,3,size=event_count,dtype=np.int8)
    context.hours=np.array([[7,0,0] if i%2==0 else [0,5.5,7.5] for i in range(73)],dtype=float)
    context.case_phases=np.array([0 if int(s)%2==0 else 1+int(c)%2 for c,s in enumerate(case_scene)],dtype=np.int8)
    context.legacy=basis.Selection(np.arange(87,dtype=np.int32),rng.integers(0,2,size=87,dtype=np.int8),
        np.full(87,-1,dtype=np.int32),np.zeros(87,dtype=np.int8),np.ones(87,dtype=bool))
    context.first_legacy=context.legacy.take(np.arange(73));context.first_birth=entry_time[:73]-1
    context.first_index=entry_index[:73]-1;context.first_line=entry_line[:73]-1
    legacy=rows(context.legacy);first=rows(context.first_legacy)
    birth_quotes=list(zip(context.first_birth,context.first_index,context.first_line,strict=True))
    entry_quotes=list(zip(entry_time,entry_index,entry_line,strict=True))
    checked=0;iterations=40
    for trial in range(iterations):
        directions=rng.choice((-1,0,0,0,1),size=event_count).astype(np.int8)
        if trial==0:directions[:]=0
        acquired=context.link(directions)
        expected=link(directions.tolist(),context.event_cases.tolist(),context.event_phases.tolist())
        checked+=compare(rows(acquired),expected)
        for mode in ('N','U','F'):
            selected=context.integrate(acquired,mode)
            wanted=integrate(expected,legacy,first,birth_quotes,case_scene.tolist(),entry_quotes,mode)
            checked+=compare(rows(selected),wanted)
            for wi in range(2):
                for hi in range(2):
                    for period in ('全期','前48場','後25場'):
                        for band in (None,0,1,2):
                            actual=context.stats(selected,wi,hi,period,band)
                            independent=stats(wanted,arrays,context.hours,context.case_phases.tolist(),wi,hi,period,band)
                            checked+=compare(actual,independent)
    # ----------------------------------------
    # 同秒・同index・同原行は取得を先に認識し、ID文字列を比較しない。
    context.first_birth[0]=entry_time[73];context.first_index[0]=entry_index[73];context.first_line[0]=entry_line[73]
    equal=basis.Selection(np.array([73],dtype=np.int32),np.array([0],dtype=np.int8),
        np.array([0],dtype=np.int32),np.array([0],dtype=np.int8),np.array([False]))
    at=context.integrate(equal,'F');assert 0 not in at.cases and 73 in at.cases
    context.first_line[0]-=1
    pending=context.integrate(equal,'F');assert 0 in pending.cases and 73 in pending.cases
    # ----------------------------------------
    from datetime import datetime
    for session,clock,answer in [('2026-10-30_Night','2026-10-30T22:29:59+09:00',1),
        ('2026-10-30_Night','2026-10-30T22:30:00+09:00',2),
        ('2026-11-02_Night','2026-11-02T23:29:59+09:00',1),
        ('2026-11-02_Night','2026-11-02T23:30:00+09:00',2)]:
        assert timeband(session,datetime.fromisoformat(clock).timestamp())==answer
    proof={'成功':True,'自然入力未読':True,'ランダム人工反復':iterations,'比較葉数':checked,
        '確認':['q0最初成立の物理case正準','N/U/Fと旧優先','pending取得0','同原行<=でfill先認識',
            '後発新fillはF予約を取消さない','EDGEの0/反対/場/180秒区切り','三期間三帯と全体',
            'F/A/N/Cと金融既知未知を別集計','利益/損失/PF/頻度/参加','US夏冬等号'],
        'SourceSHA256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in
            (ROOT/'work/162入口探索/評価基盤.py',ROOT/'work/162入口探索/全出生を作る.py',HERE/'独立純計算.py',Path(__file__))}}
    (HERE/'人工評価監査結果.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':
    main()
