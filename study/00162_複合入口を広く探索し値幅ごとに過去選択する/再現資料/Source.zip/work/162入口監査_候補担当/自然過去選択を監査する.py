"""162の全過去選択を別の成熟集計・支持順位・取得処理で監査する。"""
from pathlib import Path
from collections import defaultdict
import hashlib
import json
import math
import sys
import time

import numpy as np
from 独立純計算 import ROOT,HERE,load_module,link,integrate,rows,stats,compare
from 過去選択の独立純計算 import metric,choose,union
from 自然screenを監査する import read,sha


def selected_details(row: dict,stage: int) -> dict:
    """
    機能: 選択済みmetricの確率・Wilson・score・段階を独立に再計算する。
    引数: row(dict)は成熟過去metric、stage(int)は異群1又は補充2。
    返り値: dictは作者selected_metricsで検算する意味欄。
    """
    f=row['F'];a=row['A'];n=f+a;p=f/n;z=1.959963984540054
    lower=(p+z*z/(2*n)-z*math.sqrt(p*(1-p)/n+z*z/(4*n*n)))/(1+z*z/n)
    hourly=row['count']/row['hours'];pf=row['profit']/row['loss'] if row['loss'] else None
    return {'id':row['id'],'group':row['group'],'base_id':row['rule_id'],
        **{k:row[k] for k in ('F','A','N','C','count','scene_count','profit','loss','hours','scene_max_share','net')},
        'resolved':n,'forward_rate':p,'wilson95_lower':max(0,lower),'hourly_count':hourly,'pf':pf,
        'pf_state':'有限' if row['loss'] else '損失0・利益あり','score':max(0,lower)+.02*math.log1p(hourly)-.15*row['scene_max_share'],
        'eligible':True,'reasons':[],'selected':True,'selection_stage':stage,
        'selection_reason':'異なる技術群を優先' if stage==1 else '不足枠へ同群の別規則を補充'}


def main() -> None:
    """
    機能: 全3488選択支持・32判断行列・96政策を別計算で確認する。
    引数: なし。独立screen監査成功とRoot過去選択完了が必要。
    返り値: None。現在/未来不使用の全自然監査票を保存する。
    """
    sys.path.insert(0,str(ROOT/'work/162入口探索'))
    prior=read(HERE/'自然screen監査結果.json');assert prior['成功']
    basis_path=ROOT/'work/162入口探索/評価基盤.py'
    assert sha(basis_path)==prior['Sourceと入力'][str(basis_path.relative_to(ROOT))]
    basis=load_module(basis_path,'basis162_past_natural_audit')
    setting_path=ROOT/'study/00162_複合入口を広く探索し値幅ごとに過去選択する/条件.json'
    setting=read(setting_path);assert sha(setting_path)==prior['条件SHA256']
    folder=ROOT/'work/162入口探索/過去選択';done=read(folder/'完了.json');assert done['成功']
    paths=[Path(__file__),HERE/'独立純計算.py',HERE/'過去選択の独立純計算.py',
        ROOT/'work/162入口探索/過去で選ぶ.py',ROOT/'work/162過去規則選択/selector162.py',
        folder/'完了.json',folder/'過去選択の支持.json.gz',folder/'過去選択の成績.json.gz',folder/'過去選択の取得.json.gz']
    paths += [folder/f'過去選択の全判断_W{w}_H{h}.npz' for w in setting['widths'] for h in setting['horizons']]
    before={str(p.relative_to(ROOT)):sha(p) for p in paths}
    context=basis.Context();arrays=context.arrays
    support=read(folder/'過去選択の支持.json.gz')['rows']
    audits={(r['width'],r['horizon'],r['session'],r['band'],r['setting']):r for r in support}
    assert len(audits)==len(support)==3488
    result=read(folder/'過去選択の成績.json.gz');references=read(folder/'過去選択の取得.json.gz')['rows']
    result_rows={r['id']:r for r in result['rows']};reference={r['id']:r for r in references}
    per_scene={(r['id'],r['session']):r for r in result['all_sessions']}
    assert len(result_rows)==len(reference)==96 and len(per_scene)==96*73
    legacy=rows(context.legacy);first=rows(context.first_legacy)
    births=list(zip(context.first_birth.tolist(),context.first_index.tolist(),context.first_line.tolist(),strict=True))
    entry_quotes=list(zip(arrays['entry_time'].tolist(),arrays['entry_index'].tolist(),arrays['entry_line'].tolist(),strict=True))
    case_scenes=context.case_scene.tolist();case_phases=context.case_phases.tolist()
    event_cases=context.event_cases.tolist();event_phases=context.event_phases.tolist()
    starts=context.starts.tolist();configurations=setting['selection']['selectors'];leaves=0;decision_cells=0
    birth_folder=ROOT/'work/162入口探索/全出生';birth_proof=read(birth_folder/'全出生の確認.json')
    begin=time.monotonic();checked_support=0;checked_policy=0
    for wi,width in enumerate(setting['widths']):
        birth_path=birth_folder/f'出生{width}.npz'
        assert sha(birth_path)==prior['Sourceと入力'][str(birth_path.relative_to(ROOT))]
        with np.load(birth_path,allow_pickle=False) as source:directions={k:source[k].copy() for k in source.files}
        identifiers=[];candidates=[];signals=[]
        for i,rule in enumerate(birth_proof['規則順']):
            for mode in ('ALL','EDGE'):
                identifiers.append({'id':rule+'_'+mode,'rule_id':rule,'group':rule[:2]})
                signals.append(directions[mode][i]);candidates.append(link(signals[-1].tolist(),event_cases,event_phases))
        matrix=np.array(signals,dtype=np.int8);lookup={r['id']:i for i,r in enumerate(identifiers)}
        for hi,horizon in enumerate(setting['horizons']):
            history=np.zeros((len(candidates),73,3,5),dtype=np.int64)
            maturity=np.full((len(candidates),73,3),np.nan)
            narrow={k:(v[:,:,wi,hi] if k in ('label','known','net','known_at') else v) for k,v in arrays.items()
                if k in ('label','known','net','known_at','session_index')}
            for ri,candidate in enumerate(candidates):
                for case,side,event,phase,old in candidate:
                    pair=narrow['label'][case]
                    if any(int(v)==2 for v in pair):continue
                    scene=case_scenes[case];label=int(pair[side]);money=int(narrow['net'][case,side])
                    assert bool(narrow['known'][case,side])
                    history[ri,scene,phase]+=np.array((int(label==1),int(label==-1),int(label==0),max(money,0),max(-money,0)))
                    now=max(float(v) for v in narrow['known_at'][case]);assert math.isfinite(now)
                    previous=maturity[ri,scene,phase]
                    maturity[ri,scene,phase]=now if not math.isfinite(previous) else max(previous,now)
            expected_directions=np.zeros((len(configurations),len(event_cases)),dtype=np.int8)
            for current,session in enumerate(context.sessions):
                first_scene=max(0,current-20)
                active=[i for i,s in enumerate(context.event_scenes) if int(s)==current]
                for band in sorted({event_phases[i] for i in active}):
                    events=[i for i in active if event_phases[i]==band]
                    one=audits[(width,horizon,session,band,configurations[0]['id'])]
                    actual_hours=float(one['clock']['hours'])
                    expected_hours=sum(float(context.hours[s,band]) for s in range(first_scene,current))
                    leaves+=compare(actual_hours,expected_hours)
                    metrics=[]
                    for ri,identifier in enumerate(identifiers):
                        past=history[ri,first_scene:current,band]
                        totals=[sum(int(row[k]) for row in past) for k in range(5)]
                        count_by_scene=[sum(int(v) for v in row[:3]) for row in past]
                        f,a,n,profit,loss=totals;count=f+a+n
                        metrics.append({**identifier,'F':f,'A':a,'N':n,'C':0,'count':count,'profit':profit,'loss':loss,
                            'net':profit-loss,'scene_count':sum(v>0 for v in count_by_scene),
                            'scene_max_share':max(count_by_scene,default=0)/count if count else 0,'hours':actual_hours})
                    # 各場の先頭規則はcacheせず原取得から直接再集計する。
                    for ri in (0,len(candidates)//2,len(candidates)-1):
                        direct=metric(candidates[ri],narrow,current,band,starts,context.hours,identifiers[ri])
                        for key in direct:leaves+=compare(metrics[ri][key],direct[key])
                    clocks=maturity[:,first_scene:current,band];finite=clocks[np.isfinite(clocks)]
                    maximum=float(finite.max()) if finite.size else None
                    assert maximum is None or maximum<starts[current]
                    digest=hashlib.sha256(json.dumps(metrics,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
                    metric_by_id={r['id']:r for r in metrics}
                    for ci,configuration in enumerate(configurations):
                        key=(width,horizon,session,band,configuration['id']);actual=audits.pop(key)
                        expected=choose(metrics,configuration)
                        for field in ('selected_ids','eligible_count','rejection_counts'):leaves+=compare(actual[field],expected[field])
                        clock=actual['clock'];assert clock['metrics_sha256']==digest
                        for field,value in {'window_first':first_scene,'window_last_exclusive':current,
                            'current_start':int(starts[current]),'maximum_known_at':maximum,'hours':actual_hours,
                            'complete_pair_only':True,'current_or_future_used':False}.items():leaves+=compare(clock[field],value)
                        selected_indices=[lookup[name] for name in expected['selected_ids']]
                        expected_directions[ci,events]=union(matrix,selected_indices,events)
                        assert actual['born']==int(np.count_nonzero(expected_directions[ci,events]))
                        chosen={};groups=set()
                        for name in expected['selected_ids']:
                            row=metric_by_id[name];stage=1 if row['group'] not in groups else 2
                            chosen[name]=selected_details(row,stage);groups.add(row['group'])
                        assert {r['id'] for r in actual['selected_metrics']}==set(chosen)
                        for row in actual['selected_metrics']:
                            for field,value in chosen[row['id']].items():leaves+=compare(row[field],value)
                        checked_support+=1
            path=folder/f'過去選択の全判断_W{width}_H{horizon}.npz'
            with np.load(path,allow_pickle=False) as source:
                assert source.files==['directions']
                actual_directions=source['directions']
            assert np.array_equal(expected_directions,actual_directions);decision_cells+=actual_directions.size
            for ci,configuration in enumerate(configurations):
                direction=expected_directions[ci].tolist();new=link(direction,event_cases,event_phases)
                for integration in ('N','U','F'):
                    selected=integrate(new,legacy,first,births,case_scenes,entry_quotes,integration)
                    key=f'{configuration["id"]}_W{width}_H{horizon}_{integration}';ref=reference.pop(key)
                    for field,position in (('cases',0),('sides',1),('events',2),('old',4)):
                        leaves+=compare(ref[field],[r[position] for r in selected])
                    actual=result_rows.pop(key)
                    for period in ('全期','前48場','後25場'):
                        leaves+=compare(actual['periods'][period],stats(selected,arrays,context.hours,case_phases,wi,hi,period))
                        leaves+=compare(actual['bands'][period],[stats(selected,arrays,context.hours,case_phases,wi,hi,period,b) for b in range(3)])
                    for si,session in enumerate(context.sessions):
                        subset=[r for r in selected if case_scenes[r[0]]==si]
                        actual_scene=per_scene.pop((key,session));labels=[];money=[];old=0
                        for case,side,event,phase,is_old in subset:
                            labels.append(int(arrays['label'][case,side,wi,hi]));old+=is_old
                            if bool(arrays['known'][case,side,wi,hi]):money.append(int(arrays['net'][case,side,wi,hi]))
                        expected_scene={'id':key,'session':session,'count':len(subset),'F':labels.count(1),'A':labels.count(-1),
                            'N':labels.count(0),'C':labels.count(2),'profit':sum(max(v,0) for v in money),
                            'loss':sum(max(-v,0) for v in money),'unknown':len(subset)-len(money),'old_count':old}
                        leaves+=compare(actual_scene,expected_scene)
                    checked_policy+=1
            print(json.dumps({'過去選択監査':True,'幅':width,'期限':horizon,'支持行':checked_support,
                '政策':checked_policy,'秒':round(time.monotonic()-begin)},ensure_ascii=False),flush=True)
    assert not audits and not reference and not result_rows and not per_scene
    assert all(sha(ROOT/p)==value for p,value in before.items())
    proof={'成功':True,'条件SHA256':sha(setting_path),'全支持行':checked_support,'全政策':checked_policy,
        '全セッション行':96*73,'全判断セル':decision_cells,'比較葉数':leaves,
        '現在未来除外':'場/帯を切り離して全1944metricの支持順位を再計算。全metricsSHAと成熟時計を一致確認。',
        '範囲':'screen監査で検証した型付き金融・q0/q1対応を共用し、過去規則選択と政策統合は別実装。',
        'Sourceと結果':before,'経過秒':time.monotonic()-begin}
    (HERE/'自然過去選択監査結果.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
