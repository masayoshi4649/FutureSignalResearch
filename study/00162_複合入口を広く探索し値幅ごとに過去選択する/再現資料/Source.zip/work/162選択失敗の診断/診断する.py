"""固定MP領域と過去選択政策の差を、採否を変えず事後分解する。"""
from pathlib import Path
from collections import Counter,defaultdict
import gzip
import hashlib
import importlib.util
import json
import sys

import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
ENGINE=ROOT/'work/162入口探索'
sys.path.insert(0,str(ENGINE))
from 共通 import read,save,sha,module,book
from 評価基盤 import Context
from 過去で選ぶ import build_history,past_metrics


def numbers(context: Context, cases: np.ndarray, sides: np.ndarray, wi: int, hi: int) -> dict:
    """
    機能: 与えられた実取得集合だけの先着と既知利益損失を集計する。
    引数: context(Context)、cases/sides(np.ndarray)は実取得、wi/hi(int)は固定幅/期限。
    返り値: dictは件数・F/A/N/C・利益損失・既知差引・場集中。
    """
    labels=context.arrays['label'][cases,sides,wi,hi]
    known=context.arrays['known'][cases,sides,wi,hi]
    net=context.arrays['net'][cases,sides,wi,hi][known]
    counts=np.bincount(context.case_scene[cases],minlength=73)
    f=int((labels==1).sum());a=int((labels==-1).sum())
    return {'count':len(cases),'F':f,'A':a,'N':int((labels==0).sum()),'C':int((labels==2).sum()),
        'rate':f/(f+a) if f+a else None,'profit':int(np.maximum(net,0).sum()),
        'loss':int(-np.minimum(net,0).sum()),'net':int(net.sum()),'unknown':int((~known).sum()),
        'scenes':int(np.count_nonzero(counts)),'max_scene_share':int(counts.max())/len(cases) if len(cases) else None}


def main() -> None:
    """
    機能: 保存済み162採否と金融を読み、群・支持・順位・乗換え・実取得の変化を診断する。
    引数: なし。新しい閾値・政策・自然取引は作らない。
    返り値: None。事後診断JSONとMarkdownを保存する。
    """
    paths=[Path(__file__),ENGINE/'過去選択/過去選択の支持.json.gz',ENGINE/'過去選択/過去選択の成績.json.gz',
        ENGINE/'過去選択/過去選択の取得.json.gz',ENGINE/'広い評価/全探索200.json.gz',
        ROOT/'work/162複合入口候補/候補辞書.json',ROOT/'work/162過去規則選択/selector162.py']
    before={str(p.relative_to(ROOT)):sha(p) for p in paths}
    config=book();context=Context();wi=context.table.widths.index(200);hi=context.table.horizons.index(3600)
    support=read(paths[1])['rows'];past=read(paths[2])['rows'];references={r['id']:r for r in read(paths[3])['rows']}
    screen=read(paths[4])['rows'];registry=read(paths[5]);rules={r['id']:r for r in registry['rules']}
    selector=module(paths[6],'selector162_diagnostic')
    fixed_names=['MP0058','MP0070','MP0082','MP0094','MP0081','MP0093']
    fixed_names=[n for n in fixed_names if n in rules]
    source=read(ENGINE/'全出生/全出生の確認.json');rule_order=source['規則順'];rule_index={r:i for i,r in enumerate(rule_order)}
    with np.load(ENGINE/'全出生/出生200.npz',allow_pickle=False) as arrays:
        directions={k:arrays[k].copy() for k in arrays.files}
    selected=[context.link(directions['ALL'][rule_index[r]]) for r in fixed_names]
    identifiers=[{'id':r+'_ALL','group':'MP','rule_id':r} for r in fixed_names]
    history,maturity=build_history(context,selected,wi,hi)
    settings={s['id']:s for s in config['selection']['selectors']}
    only=[r for r in support if r['width']==200 and r['horizon']==3600]
    support_map={(r['setting'],r['session'],r['band']):r for r in only}
    # ----------------------------------------
    # 代表MPの過去適格性と、実際の選択順位・不採用理由を再現する。
    mp=[]
    for current,scene in enumerate(context.scenes):
        active=np.flatnonzero(context.event_scenes==current)
        for band in np.unique(context.event_phases[active]):
            metrics,clock=past_metrics(history,maturity,context,identifiers,current,int(band))
            for name,setting in settings.items():
                audited=selector.select_with_audit(metrics,setting)
                saved=support_map[(name,scene['session'],int(band))]
                top=saved['selected_metrics'][0] if saved['selected_metrics'] else None
                for row in audited['rows']:
                    mp.append({'selector':name,'session':scene['session'],'band':int(band),
                        **{k:row[k] for k in ('id','F','A','N','C','count','scene_count','scene_max_share','forward_rate','wilson95_lower','score','eligible','reasons')},
                        'actual_selected':row['id'] in saved['selected_ids'],
                        'actual_top':top['id'] if top else None,'actual_top_score':top['score'] if top else None,
                        'score_below_actual_top':row['eligible'] and top is not None and row['score']<top['score'],
                        'clock':clock})
    # ----------------------------------------
    # 選択表は支持・乗換えだけ、取得の帰属はそのq0で本当に発火した選択規則だけに限る。
    families=[];switches=[];owners=[];matched={}
    for name in settings:
        slices=[r for r in only if r['setting']==name]
        by_band=defaultdict(list)
        for row in slices:by_band[row['band']].append(row)
        for band,rows in sorted(by_band.items()):
            appearances=Counter(g for row in rows for g in [x['group'] for x in row['selected_metrics']])
            base_ids={r for row in rows for r in row['selected_ids']}
            previous=None;changed=0;live_changed=0;comparisons=0
            for row in rows:
                current=tuple(row['selected_ids'])
                if previous is not None:
                    changed+=current!=previous
                    if current and previous:
                        comparisons+=1;live_changed+=current!=previous
                previous=current
            families.append({'selector':name,'band':band,'scene_steps':len(rows),'ready_steps':sum(bool(r['selected_ids']) for r in rows),
                'family_appearances':dict(appearances),'distinct_rule_modes':len(base_ids)})
            switches.append({'selector':name,'band':band,'between_steps':max(0,len(rows)-1),'changes_including_empty':changed,
                'live_comparisons':comparisons,'live_changes':live_changed})
        reference=references[f'{name}_W200_H3600_N']
        cases=np.asarray(reference['cases'],dtype=np.int32);sides=np.asarray(reference['sides'],dtype=np.int8)
        events=np.asarray(reference['events'],dtype=np.int32)
        owner_indices=defaultdict(list)
        for i,(case,side,event) in enumerate(zip(cases,sides,events,strict=True)):
            scene=context.sessions[context.case_scene[case]];band=int(context.event_phases[event])
            saved=support_map[(name,scene,band)]
            firing=[]
            for identifier in saved['selected_ids']:
                rule,mode=identifier.rsplit('_',1)
                if directions[mode][rule_index[rule],event]==(1 if side==0 else -1):firing.append(rule[:2])
            assert firing
            signature='+'.join(sorted(set(firing)))
            owner_indices[signature].append(i)
        for signature,indices in sorted(owner_indices.items()):
            at=np.asarray(indices,dtype=np.int32)
            owners.append({'selector':name,'owner_signature':signature,**numbers(context,cases[at],sides[at],wi,hi)})
        matched[name]={}
        chosen_pairs=set(zip(cases.tolist(),sides.tolist()))
        chosen_case_to_side=dict(zip(cases.tolist(),sides.tolist()))
        for fixed,selection in zip(fixed_names,selected,strict=True):
            pairs=set(zip(selection.cases.tolist(),selection.sides.tolist()))
            same=pairs&chosen_pairs
            opposite={(c,s) for c,s in pairs if c in chosen_case_to_side and chosen_case_to_side[c]!=s}
            added=[i for i,(c,s) in enumerate(zip(cases,sides,strict=True)) if (int(c),int(s)) not in pairs]
            shared=[i for i,(c,s) in enumerate(zip(cases,sides,strict=True)) if (int(c),int(s)) in pairs]
            matched[name][fixed]={'fixed_new_count':len(pairs),'same_case_same_side':len(same),
                'same_case_opposite_side':len(opposite),'fixed_case_not_acquired':len(pairs)-len(same)-len(opposite),
                'selected_actual_added':numbers(context,cases[added],sides[added],wi,hi),
                'selected_actual_shared':numbers(context,cases[shared],sides[shared],wi,hi),
                'untaken_profit_not_optimized':True}
    result={'成功':True,'試行':162,'事後診断のみ':True,'162採否変更':False,'input_sha256':before,
        'fixed_rules':{n:rules[n] for n in fixed_names},'mp_past_readiness':mp,'selected_family_support':families,
        'switches':switches,'actual_acquisition_owners':owners,'fixed_vs_selected_overlap':matched,
        'fixed_screen':[r for r in screen if r.get('rule') in fixed_names and r['entry_mode']=='ALL' and r['horizon']==3600],
        'past_policy_results':[r for r in past if r['width']==200 and r['horizon']==3600]}
    assert all(sha(ROOT/p)==v for p,v in before.items())
    save(HERE/'診断根拠.json.gz',result)
    compact={}
    for name in settings:
        subset=[r for r in mp if r['selector']==name and r['id']=='MP0058_ALL']
        compact[name]={'MP0058適格':sum(r['eligible'] for r in subset),'MP0058実選択':sum(r['actual_selected'] for r in subset),
            'MP0058適格だが上位負け':sum(r['score_below_actual_top'] for r in subset),
            'MP0058不適格理由':dict(Counter(x for r in subset for x in r['reasons'])),
            '選択群':dict(sum((Counter(r['family_appearances']) for r in families if r['selector']==name),Counter()))}
    save(HERE/'診断の要点.json',{'成功':True,'Root政策変更なし':True,'summary':compact,'owners':owners,'switches':switches,
        'best_overlap':matched['S65_B8_K1']['MP0058']})
    print(json.dumps({'成功':True,'summary':compact,'best_owners':[r for r in owners if r['selector']=='S65_B8_K1'],
        'best_overlap':matched['S65_B8_K1']['MP0058']},ensure_ascii=False))


if __name__=='__main__':
    main()
