"""161の作業cacheを複製せず、正式148の特徴から162を隔離再現する。"""
from pathlib import Path,PurePosixPath
from io import BytesIO
import argparse
import gzip
import hashlib
import importlib.util
import json
import shutil
import sys
import zipfile

import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
TRIAL=ROOT/'study/00162_複合入口を広く探索し値幅ごとに過去選択する'
BOOK_SHA='4f890114b789da404d400f49a5cb888e9b9014013b00fcc0f77dc6ffd691088c'


def sha(path: Path) -> str:
    """
    機能: 物理ファイルを全読了して指紋を計算する。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    with path.open('rb') as source:return hashlib.file_digest(source,'sha256').hexdigest()


def load_module(path: Path,name: str) -> object:
    """
    機能: mainを呼ばず登録名を指定してPython部品を読む。
    引数: path(Path)、name(str)。
    返り値: objectはmodule。
    """
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module;spec.loader.exec_module(module);return module


def decoded_json(body: bytes,name: str) -> object:
    """
    機能: archive内又は新規出力のJSONを同じ意味値へ復号する。
    引数: body(bytes)、name(str)は拡張子を含む名前。
    返り値: objectは標準JSON値。
    """
    return json.loads(gzip.decompress(body) if name.endswith('.gz') else body)


# ----------------------------------------
def main() -> None:
    """
    機能: 新しいcheckoutで元Sourceを変更せず、正式特徴と保存金融から全出生/探索/過去選択を再現する。
    引数: CLI --reference-zip(Path)は正式な出生と探索.zip。
    返り値: None。再現はwork内へ出力し、正式試行・共有入力を上書きしない。
    """
    parser=argparse.ArgumentParser()
    parser.add_argument('--reference-zip',type=Path,default=TRIAL/'再現資料/出生と探索.zip')
    args=parser.parse_args()
    assert sha(TRIAL/'条件.json')==BOOK_SHA
    engine=ROOT/'work/162入口探索'
    assert all(not(engine/name).exists() for name in ('全出生','広い評価','過去選択')),'元成果物のあるcheckoutでは実行しない'
    replay_trial=HERE/'隔離再現の検査';assert not replay_trial.exists()
    financial=ROOT/'work/162可変幅評価/自然射影';assert not financial.exists()
    expected=sha(args.reference_zip)
    with zipfile.ZipFile(args.reference_zip) as archive:
        assert archive.testzip() is None
        for name in archive.namelist():
            if not(name.startswith('work/162可変幅評価/自然射影/') or name=='work/162複合入口候補/候補辞書.json'):
                continue
            relative=PurePosixPath(name);assert not relative.is_absolute() and '..' not in relative.parts
            destination=ROOT/Path(*relative.parts)
            assert destination.resolve().is_relative_to(ROOT.resolve())
            body=archive.read(name)
            if destination.exists():assert destination.read_bytes()==body
            else:destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(body)
    sys.path.insert(0,str(engine))
    common=load_module(engine/'共通.py','共通')
    original_data_factory=common.data_module
    dataset_module=original_data_factory()
    features=dataset_module.load_feature_from_formal()
    def formal_data_factory() -> object:
        """
        機能: 同じSourceのデータ部品へ正式148から射影した特徴を接続する。
        引数: なし。
        返り値: objectは161部品。load_feature_datasetだけを値同体の正式射影へ接続する。
        """
        component=original_data_factory()
        component.load_feature_dataset=lambda:features
        return component
    common.data_module=formal_data_factory
    replay_trial.mkdir();shutil.copyfile(TRIAL/'条件.json',replay_trial/'条件.json')
    common.TRIAL=replay_trial
    for name in ('全出生を作る','広く評価する','過去で選ぶ'):
        load_module(engine/(name+'.py'),name).main()
    # ----------------------------------------
    arrays_checked=0;json_checked=0
    with zipfile.ZipFile(args.reference_zip) as archive:
        for name in archive.namelist():
            if not name.startswith('work/162入口探索/'):continue
            relative=PurePosixPath(name);actual=ROOT/Path(*relative.parts)
            if name.endswith('.npz'):
                with np.load(BytesIO(archive.read(name)),allow_pickle=False) as original,np.load(actual,allow_pickle=False) as replay:
                    assert original.files==replay.files
                    for key in original.files:
                        assert np.array_equal(original[key],replay[key],equal_nan=True),(name,key)
                        arrays_checked+=1
            elif relative.name in ('全探索125.json.gz','全探索200.json.gz','旧対照.json.gz',
                '過去選択の成績.json.gz','過去選択の支持.json.gz','過去選択の取得.json.gz'):
                assert decoded_json(archive.read(name),name)==decoded_json(actual.read_bytes(),name),name
                json_checked+=1
    assert sha(args.reference_zip)==expected and sha(TRIAL/'条件.json')==BOOK_SHA
    proof={'成功':True,'条件SHA256':BOOK_SHA,'参照ZIP_SHA256':expected,'cache複製なし':True,
        '正式148からの特徴射影':features.sources,'runtime接続':'作者Source byteは変えず、特徴loadだけを正式射影へ接続。F1/F2/F3はwork内の隔離先へ保存。',
        '配列照合':arrays_checked,'JSON正本照合':json_checked,'NPZのZIP日時byte同体は要求しない':True,
        'SourceSHA256':sha(Path(__file__))}
    (replay_trial/'正式入力による再現確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'配列':arrays_checked,'JSON正本':json_checked},ensure_ascii=False))


if __name__=='__main__':
    main()
