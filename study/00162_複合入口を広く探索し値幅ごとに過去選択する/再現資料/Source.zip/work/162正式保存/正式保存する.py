"""162の完成済み探索をMarkdownと二つの圧縮正本へ正式保存する。"""
from pathlib import Path
from datetime import datetime,timezone
import gzip
import hashlib
import importlib.metadata
import json
import os
import re
import shutil
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
TRIAL=ROOT/'study/00162_複合入口を広く探索し値幅ごとに過去選択する'
BOOK_SHA='4f890114b789da404d400f49a5cb888e9b9014013b00fcc0f77dc6ffd691088c'


def sha(path: Path) -> str:
    """
    機能: 物理ファイルを全読了して指紋化する。
    引数: path(Path)はファイル。
    返り値: strはSHA256。
    """
    with path.open('rb') as source:return hashlib.file_digest(source,'sha256').hexdigest()


def read(path: Path) -> object:
    """
    機能: JSON又はgzip JSONを全CRC確認して読む。
    引数: path(Path)は入力。
    返り値: objectは標準JSON値。
    """
    body=path.read_bytes()
    return json.loads(gzip.decompress(body) if path.suffix=='.gz' else body)


def save(path: Path,value: object) -> None:
    """
    機能: 日本語UTF-8の標準JSONを保存する。
    引数: path(Path)、value(object)。
    返り値: None。
    """
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')


def md_table(headers: list[str],rows: list[list]) -> str:
    """
    機能: 表示済み値をMarkdown表へ変換する。
    引数: headers(list[str])、rows(list[list])は列名と各行。
    返り値: strは表。
    """
    return '\n| '+' | '.join(headers)+' |\n| '+' | '.join('---' for _ in headers)+' |\n'+''.join(
        '| '+' | '.join(map(str,row))+' |\n' for row in rows)+'\n'


def pct(value: float|None) -> str:
    """
    機能: 未定義を残して百分率を表示する。
    引数: value(float又はNone)。
    返り値: strは百分率又は未定義。
    """
    return f'{value:.2%}' if value is not None else '未定義'


def number(value: int|float,sign: bool=False) -> str:
    """
    機能: 円の桁区切りと任意の正符号を付ける。
    引数: value(int又はfloat)、sign(bool)。
    返り値: strは表示値。
    """
    return f'{value:+,}' if sign else f'{value:,}'


def settings_document() -> None:
    """
    機能: 版8の63手法×9尺度を保持し、162で実際に比較した設定を記入する。
    引数: なし。
    返り値: None。設定と結果.mdを作成する。
    """
    source=ROOT/'docs/議論/手法と時間スケールの汎用表_版8.md'
    text=source.read_text(encoding='utf-8')
    body=text.split('## 手法×時間スケール',1)[1].split('## 設定明細',1)[0]
    body=body[body.index('### 指標'):]
    updates={}
    for scale in (3,4,5):
        updates[('I01',scale)]='S162-X：EMA21傾き'+('・EMA8/21差' if scale==3 else '')+'。R162'
        updates[('I08',scale)]='S162-X：DI差'+('・ADX水準/増分' if scale==4 else '')+'。R162'
    for scale in (3,4):
        updates[('I03',scale)]='S162-X：Hist水準/増分'+('・ATR比' if scale==3 else '')+'。R162'
        updates[('I04',scale)]='S162-X：RSI'+('中心差/増分' if scale==3 else '増分')+'。R162'
    for method,scale,note in [('I01',0,'q0のEMA8距離/ATR5'),('I05',0,'q0の順側/平均BB余地をptへ戻し対象幅で割る'),
        ('I05',4,'BB15位置σ・BB幅/ATR15'),('I09',0,'q0距離/ATR5'),('I09',3,'ATR5によるHist/距離の尺度'),
        ('I09',4,'BB幅/ATR15'),('P01',1,'実体比と生存回復'),('P01',3,'実体/ヒゲ/終値位置'),
        ('P02',0,'先行3分の端と現在価格'),('P06',0,'先行3分端に対する現在の余地'),
        ('P07',0,'先行3分端の超過0/0.1/0.25ATR5'),('V01',1,'同r観測量の前3分比0.5～1.5'),
        ('B01',0,'0<spread<=10/20・abs(q0Last−m1Close)/ATR5<=1'),
        ('C01',0,'EMA/Hist/RSIと量/形状等の複合条件'),('C02',0,'BB位置とRSI回復、形状/量も確認'),
        ('C03',0,'BB/量と短期端/量を各群で使用。三者同時は未検証、長い支持抵抗は新生成しない'),('C04',0,'DI方向とADX水準/増分を別に使用'),
        ('C07',0,'5/15/30分の投票。背景同方向/混在/反対を分ける'),('E01',0,'実BBO±125/200・strictH30/H60のF/A/N/CとIFD')]:
        updates[(method,scale)]='S162-X/Q：'+note+'。R162'
    count=0;lines=[]
    for line in body.splitlines():
        cells=[c.strip() for c in line.split('|')[1:-1]] if line.startswith('|') else []
        if len(cells)==11 and re.fullmatch(r'[A-Z][0-9]{2}',cells[0]):
            count+=1
            for scale in range(9):cells[2+scale]=updates.get((cells[0],scale),'未使用・未検証')
            line='| '+' | '.join(cells)+' |'
        lines.append(line)
    assert count==63
    def move_link(match: re.Match) -> str:
        """
        機能: 元版からの教材リンクを試行からの有効な相対位置へ移す。
        引数: match(re.Match)はMarkdownリンク。
        返り値: strは移設済みリンク。
        """
        target=match.group(2)
        if '://' in target or target.startswith('#'):return match.group(0)
        resolved=(source.parent/target).resolve()
        return '['+match.group(1)+']('+os.path.relpath(resolved,TRIAL).replace('\\','/')+')'
    body=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',move_link,'\n'.join(lines))
    prefix='# 162 設定と結果\n\n2026-11-14。[汎用表版8](../../docs/議論/手法と時間スケールの汎用表_版8.md)の63手法×9尺度=567セルを複写。元SHA256 `'+sha(source)+'`。\n\n'
    prefix+='[条件](条件.json)と[結果](README.md)を参照。100特徴を入力に持つことと、その列を条件で参照したことを区別する。表の使用セルは複合評価R162での使用であり、指標単独の効果ではない。M01/M02の木/HGBTは使わず、固定比較条件と票の合成である。履歴488規則は162へ追加せず後続163で検証する。\n\n## 手法×時間スケール\n\n'
    suffix='''

## 設定明細

|設定ID|条件・短い閾値|複合評価|
|---|---|---|
|S162-X|正式148の買売実側100X。q0までの確定5/15/30分、1分形状/量、q0幾何を使用。未知は0へ代用しない|R162|
|S162-Q|0<spread<=10/20、abs(q0Last−m1Close)/ATR5<=1。必要列が未知ならその側は不成立・未知計数。両側成立は競合待機|R162|
|S162-TP|EMA/DI各同方向数>=2/3、勢い票>=2/3、EMA8距離下限−0.5/0・上限0.25/0.5/1、量>=0.5/1/1.25|144規則|
|S162-MX|背景6票中2～4、短期票>=2/3、実体>=0.1/0.3/0.5、Hist/RSI増分正、RSI中心差<=10/20、量>=0.5/1/1.5|72規則|
|S162-TR|長中期4票<=1、ADX増分<=0/−0.25、短期動力正、BBσ位置<=−0.5/0/0.5、1分回復又は5分実体、量>=0.5/1/1.25|72規則|
|S162-EX|BBσ位置<=−1/−1.5/−2、逆ヒゲ>=0.2/0.4/0.6、RSI中心差<=−5/5、動力回復、量>=0.5/1/1.5|108規則|
|S162-CP|BB幅/ATR<=4/6/8、現在σ位置0～1.5、長中期票>=2/3、実体>=0.2/0.4/0.6、動力正、量>=1/1.25/1.5|108規則|
|S162-BO|先行3分端超過>0/0.1/0.25ATR5、実体>=0.2/0.4、動力正、RSI中心差<=15/25、量>=0.75/1/1.5|72規則|
|S162-RG|ADX<=15/20/25、BBσ位置<=−0.5/−1/−1.5、平均までの余地>=対象幅の0.25/0.5/1、実体/動力回復、量>=0.5/1|108規則|
|S162-RM|順側BB余地>=対象幅の0.5/1/1.5、長中期票>=2/3/4、動力正、EMA8距離0～0.5/1、RSI中心差<=10/20|72規則|
|S162-MP|Hist/ATR>=0/0.1/0.2、15分Hist同側、5分Hist増分非負、RSI中心差>=0/5・<=25、RSI増分>0/0.5、ADX>=15/20/25・増分非負、量>=0.75/1|144規則|
|S162-SC|異技法確認票>=6/7/8、EMA8距離<=0.5/1/1.5、RSI中心差<=15/25、順側BB余地>=幅の0/0.5|72規則|
|S162-EDGE|同場の0/反対から当該側へ変化したq0、又は180秒超の新ブロック。US帯境界で強制再発火しない。ALLは成立全q0|2発火方式|
|S162-L|同物理q1は最初成立q0。N純新規/U旧87全保持/F最初旧出生時に新実取得0ならその1信号予約、旧優先。未来取消しなし|N/U/F|
|S162-P|過去20暦場の同q0帯、両側strictH完了かつ最大成熟時計<当場開始。率>=65/70%、支持5場12到達又は8場24到達、上位1/3、PF>=1.1、既知差引>0、最多場比<=0.5|8選択設定|
|S162-RANK|Wilson95下限+0.02log1p(取得/全対象時間)−0.15最多場比。異groupを先に選び、枠不足だけ同group別規則。同base ALL/EDGEは重複選択しない|場開始だけ固定|
|S162-E|IFD±125/200、strictH30/H60、先着実BBO又は完了期限BBO。mini1枚100円/pt−往復77円−追加滑り1000円|C5|

## 複合条件と結果

R162-SCREEN：972規則×ALL/EDGE×2幅×2期限×N/U/F=23,328政策行。全期探索の発見結果であり、採用済み/未見成績ではない。旧7固定対照を同じ2幅×2期限で28行比較。

R162-PAST：8固定選択器×2幅×2期限×N/U/F=96政策。3,488場帯支持と全q0判断を保存。MP近傍の全期高率は過去選択で維持できなかった。[主結果](README.md)・[原因](原因と次の仮説.md)へ件数・分母・利益/損失・未知を記した。

全辞書は出生と探索.zip内の`work/162複合入口候補/候補辞書.json`。閾値は売買side正規化Xに同じ条件で適用する。CPは低い現在BB幅と推進の近似で、過去圧縮→再拡大の正確な履歴patternではない。TR/EX/RGも完全な失敗突破やBB外→内の履歴を新生成しない。RSI/MACDの複数列だけを独立した技術裏付けと数えず、量・方向・値幅・構造の役割を分けた。

E02の新追尾は今回対象外。ユーザーの最新指示により入口探索では単純IFDを使い、125へ固定せず上位複数幅へ広げる。200を最終固定幅とはしない。
'''
    (TRIAL/'設定と結果.md').write_text(prefix+body+suffix,encoding='utf-8')


# ----------------------------------------
def main() -> None:
    """
    機能: 自然結果を改変せず正式文書と再現圧縮正本を保存する。
    引数: なし。162の完了済み出力・独立監査・調査稿だけを利用する。
    返り値: None。共有Raw・161cache・163索引やglobal目次を変更しない。
    """
    assert sha(TRIAL/'条件.json')==BOOK_SHA
    source_dirs=['162入口探索','162過去規則選択','162可変幅評価','162入口監査_候補担当','162選択失敗の診断','162正式保存','162保存QA']
    source_files=set()
    for name in source_dirs:
        source_files.update(p for p in (ROOT/'work'/name).iterdir() if p.is_file() and p.suffix in ('.py','.md'))
    source_files.update(ROOT/p for p in ['work/162複合入口候補/rules162.py','work/162複合入口候補/人工検査.py',
        'work/162複合入口候補/README.md','work/161三時間帯入口のデータ/data161.py','work/151過去場判別/data151.py'])
    before={str(p.relative_to(ROOT)):sha(p) for p in sorted(source_files)}
    for name in ('全出生/全出生の確認.json','広い評価/完了.json','過去選択/完了.json'):
        assert read(ROOT/'work/162入口探索'/name)['成功']
    for name in ('自然screen監査結果.json','自然過去選択監査結果.json'):
        assert read(ROOT/'work/162入口監査_候補担当'/name)['成功']
    evidence=read(ROOT/'work/162保存QA/報告照合用の独立数値抽出.json')
    fixed={r['id']:r for r in evidence['fixed']};past={r['id']:r for r in evidence['past']}
    # ----------------------------------------
    (TRIAL/'成果物').mkdir(exist_ok=True);(TRIAL/'検査').mkdir(exist_ok=True)
    for destination,origin in {
        '候補の人工確認.json':'work/162複合入口候補/人工検査結果.json',
        '過去選択器の人工確認.json':'work/162過去規則選択/人工検査結果.json',
        '観測の人工確認.json':'work/162可変幅評価/旧保存幅の人工検査.json',
        '取得と統計の独立人工確認.json':'work/162入口監査_候補担当/人工評価監査結果.json',
        '過去選択の独立人工確認.json':'work/162入口監査_候補担当/過去選択の人工監査結果.json',
        '全screenの独立確認.json':'work/162入口監査_候補担当/自然screen監査結果.json',
        '過去選択の独立確認.json':'work/162入口監査_候補担当/自然過去選択監査結果.json',
        '金融観測射影の確認.json':'work/162可変幅評価/自然射影/入力と算式の確認.json',
        '外部調査の停止.json':'work/162外部調査と監査/調査停止票.json'}.items():
        shutil.copyfile(ROOT/origin,TRIAL/'検査'/destination)
    for name in ('診断根拠.json.gz',):shutil.copyfile(ROOT/'work/162選択失敗の診断'/name,TRIAL/'成果物'/name)
    detail=read(ROOT/'work/162選択失敗の診断/診断の要点.json')
    body=(json.dumps(detail,ensure_ascii=False,separators=(',',':'))+'\n').encode('utf-8')
    (TRIAL/'成果物/診断の要点.json.gz').write_bytes(gzip.compress(body,mtime=0))
    diagnosis=(ROOT/'work/162選択失敗の診断/なぜ過去選択でMP領域を維持できなかったか.md').read_text(encoding='utf-8')
    diagnosis=diagnosis.replace('`診断根拠.json.gz`と`診断の要点.json`','[診断根拠](成果物/診断根拠.json.gz)と[診断の要点](成果物/診断の要点.json.gz)')
    diagnosis+='\n\n正式移設時追記：本文数値と診断は元稿から変更せず、上の根拠リンクだけ移設した。[主結果](README.md)、[条件](条件.json)、[再現手順](再現手順.md)。後続163で任意幅と履歴候補の探索を継続する。\n'
    (TRIAL/'原因と次の仮説.md').write_text(diagnosis,encoding='utf-8')
    shutil.copyfile(ROOT/'work/162外部調査と監査/外部調査と可変幅探索の設計.md',TRIAL/'調査と候補.md')
    settings_document()
    # ----------------------------------------
    report='''# 00162 複合入口を広く探索し値幅ごとに過去選択する

2026-11-14。旧3案だけで探索を終えず、新しい複合テクニカル十群972規則を、同一の単純IFDで広く比較した。**全期探索では±200ptにMP近傍の高率・前後既知黒字を見つけた。一方、固定した過去選択器ではその技術領域を維持できなかった。** 発見と過去選択の結果を分け、[後続163](../00163_履歴を含む複合入口を任意幅と場末まで検証する/README.md)で履歴・他幅・期限の探索を続ける。162の保存は研究を止める意味ではない。

## 仮説と比較条件

旧P65の成立を必須にせず、方向/強度、構造、勢い、量、BB/ATRの別役割を組み合わせれば、静観過多と不適切な順行/反転を改善できると仮定した。過去3案だけの再評価ではなく、押戻し順行、混在再加速、旧方向失速から回復、バンド端回復、低BB幅下の推進近似、直近3分端突破、低ADX帯内回復、目標余地付き順行、勢い持続、異技法採点の十群を新生成した。

全73場・35,339判断q0・31,642物理観測case。買い/売りは実側100特徴へ同じside正規化条件を適用し、両側成立は待機。判断q0をデイ/ナイトNY09:30前/以後へ夏冬変換し、表の取得帯q1とは分けた。同物理q1は最初に成立したq0だけを残す。ALLは成立全q0、EDGEは0/反対から当該側への変化又は180秒超の新ブロックだけで、US帯境界では強制再発火しない。

出口はIFD対称幅125/200ptとstrictH30/H60を組み合わせた。保存148にある125超が200だけだったため、この試行で利用したのであって200を最適幅へ固定しない。ユーザーの250ptも例示として扱い、次のRaw任意幅基盤で複数のより広い幅へ比較を拡張する。場末を跨いだ価格は使わない。

費用は独立mini1枚100円/pt、往復手数料77円、追加滑り控除5pt×2=1000円、計1077円。買いは取得Ask/決済Bid、売りは取得Bid/決済Ask。strictH完了だけF順/A逆/N未到達、他C観測不足。Cでも打切り前の早期touchが分かれば金融は既知。touchがなければ完了期限の実BBOで清算し、他は金融未知を残す。未知を0円として損益へ混ぜない。

## 全期探索で見つけたMP近傍

以下はW200/H60、旧C1全87取得を保持するU政策。972規則×2発火×2幅×2期限×N/U/F=23,328政策行からの**既使用データ上の発見**であり、採用済み又は未見成績とはしない。金額は費用後の既知分。
'''
    records=[]
    for rule in ('MP0057','MP0058','MP0081','MP0082'):
        key=rule+'_ALL_W200_H3600_U';r=fixed[key]['periods']['全期']
        records.append([key,r['count'],f"{r['F']}/{r['A']}/{r['N']}/{r['C']}",pct(r['rate']),
            number(r['profit']),number(r['loss']),number(r['net'],True),f"{r['pf']:.3f}",r['unknown'],f"{r['per_hour']:.3f}"])
    report+=md_table(['政策ID','取得','順/逆/未/不足','到達済み率','利益円','損失円','既知差引円','PF','金融未知','毎時'],records)
    report+='共通する条件は15分ADX>=25かつ非低下、15分Hist同側、5分Hist/ATR>=0.1かつHist増分非負、5分RSIが中立より同側で再上昇、量の前3分比>=0.75等。0057/58はRSI中心差下限0、0081/82は5、奇数はspread<=10、偶数は<=20。RSI中心差上限25を含み、買いのRSI50～75又は55～75に対し、売りは25～50又は25～45という対称条件になる。完全な閾値は保存辞書と[設定と結果](設定と結果.md)を参照する。\n'
    records=[]
    for rule in ('MP0057','MP0058','MP0081','MP0082'):
        key=rule+'_ALL_W200_H3600_U';r=fixed[key]['periods']
        records.append([key,pct(r['前48場']['rate']),number(r['前48場']['net'],True),pct(r['後25場']['rate']),number(r['後25場']['net'],True)])
    report+=md_table(['政策ID','前48率','前48既知差引円','後25率','後25既知差引円'],records)
    report+='近傍4条件の結論が同様だった点は単独の最高値だけより検討価値がある。ただし前48/後25も両方既使用であり、近傍を見たことを未見確認へ置き換えない。頻度は約0.44～0.53回/時で、概ね毎時1回にはまだ届かない。1時間の経路が重なる近接入口は独立試行ではない。\n\n'
    report+='## 新入口自身と旧補完を分ける\n\n代表0058の純Nは29/73場、旧全保持Uと初参加補完Fは全73場で最低1取得となった。旧参照による参加を新技術が全場で発火した成果とはしない。\n'
    records=[]
    for integration in ('N','F','U'):
        key='MP0058_ALL_W200_H3600_'+integration;r=fixed[key]['periods']['全期']
        records.append([key,r['count'],f"{r['scenes']}/73",r['old_count'],pct(r['rate']),number(r['profit']),number(r['loss']),number(r['net'],True),r['unknown']])
    report+=md_table(['政策ID','取得','取得場','旧参照','到達済み率','利益円','損失円','既知差引円','未知'],records)
    report+='Fは各場最初の旧C1真出生で新実取得0なら当該1信号を予約する。pending要求を取得へ数えず、同原行の新fillを先に認識し、未来の新取得で予約を取り消さない。重複q1は旧優先。Uは旧87すべてを保持するためFと成績が同じとは限らない。\n\n'
    report+='## 三帯で同じ精度ではなかった\n\n代表MP0058の純新規Nを実取得q1の帯で分ける。新規条件と選択の帯はq0であり、帯境界を跨ぐ取得の有無を都合よく採否へ戻していない。\n'
    records=[]
    for name,r in zip(('デイ','米国前','米国後'),fixed['MP0058_ALL_W200_H3600_N']['bands']['全期'],strict=True):
        records.append([name,r['count'],f"{r['F']}/{r['A']}/{r['N']}/{r['C']}",pct(r['rate']),number(r['profit']),number(r['loss']),number(r['net'],True),r['unknown']])
    report+=md_table(['取得帯','取得','順/逆/未/不足','到達済み率','利益円','損失円','既知差引円','未知'],records)
    report+='近傍MP4候補とも米国前の純Nは約44～45%で既知赤字だった。全期70%を各帯同等の優位へ一般化しない。高率のデイと弱い米国前を、技術幹と限定した帯差分で分ける問いを次へ残す。代表Uの全取得分母順行率は41.69%、完了分母順行率45.27%。到達済み70.54%の分母にはN125件・C30件が含まれない。期限決済と未知も併読する。\n\n'
    report+='## 固定した過去選択器の結果\n\n当場開始時に、過去20暦場・同q0帯・両実側期限完了・成熟時計strict<当場開始だけから1944規則方式を比較した。率65/70%、支持5場12到達又は8場24到達、上位1/3の8設定を事前固定。PF>=1.1、既知差引>0、最多場比<=0.5、Wilson下限と頻度/場集中の順位を使い、異技術群を先に選ぶ。現在/未来の情報は渡さず、ナイトUS開始で再学習しない。\n\n次はW200/H60。主設定S70_B5_K3と、全場参加U/Fの中で全期率が最高だったS65_B8_K1を分けて示す。後者へ主設定をすり替えない。\n'
    records=[]
    for selector,integration in [('S70_B5_K3','N'),('S70_B5_K3','F'),('S70_B5_K3','U'),('S65_B8_K1','U')]:
        key=f'{selector}_W200_H3600_{integration}';r=past[key]['periods']['全期']
        records.append([key,r['count'],f"{r['scenes']}/73",pct(r['rate']),number(r['profit']),number(r['loss']),number(r['net'],True),r['unknown']])
    report+=md_table(['政策ID','取得','取得場','到達済み率','利益円','損失円','既知差引円','未知'],records)
    report+='全96政策の全場参加U/Fの最良先着率は56.12%で、固定MP近傍の高率を過去選択で維持できなかった。主S70_B5_K3のU/Fは前後とも既知赤字だが、最高S65_B8_K1_Uは前48+166,284円・後25+288,212円であり、全過去案が赤字だったわけではない。全期screenの70%候補を、過去選択器が事前に見つけて実行した結果とは呼ばない。\n\n'
    report+='## 未達の原因と次の実験\n\n代表MP0058の同帯20場内支持は109場帯判断で最大6場だった。B8では全109判断が取得場不足。B5で全条件に適格となった4回も別規則に順位負けし、代表0058は実選択0回だった。単に選択数を増やせば解決するとは言えない。過去最良S65_B8_K1の純新規507件は、固定MP0058純N292件と同case同側が11件だけで、新たな496取得は53.77%。主な取得をTP/EX/RG等へ乗り換えたことが劣化の実体だった。\n\n[原因と次の仮説](原因と次の仮説.md)に、共通技術幹と限定帯差分、支持階層化、過去内選択と確認の分離、条件の継続性、近傍領域、任意幅/期限の比較を残した。既使用の発見を根拠にした新設計であることを明示して、後続163へ進む。単に「未達」で終えず、162の条件や結果は書き換えない。\n\n'
    report+='## 入力・検査・限界\n\n元148の共有特徴・固定取得・入口参照・正逆観測を使用。金融は全73場31,642case両側を一度数値化し、全gzip CRC・物理/解凍SHA・固定取得と元148内のRaw指紋/前後statの整合を確認した。162ではRaw全行の新走査を行わず、保存済み125/200×H30/H60を再用した。原観測上の価格時計、gap300秒、endpoint猶予30秒、ザラバ終了等号の制約を継承する。\n\n候補鏡像133,164人工行、取得/統計261,560人工葉、過去選択968人工比較が成功。別計算で全23,328探索行/旧28対照の6,446,529葉、EDGE68,699,016q0セル、全3,488支持/1,130,848判断セル/96政策/7,008場の547,082葉を照合した。旧125H60の7政策×前後3期間は161と同体。金融型付き入力は共用し、政策・時計・集計・過去順位を別実装で監査した範囲であり、候補式すべてを二重実装したと主張しない。\n\n全73場・前48/後25は既使用で、未見の11/10ナイト・11/11デイと旧156は未使用。独立入口1miniの品質研究であり、重複保有の合算を片側10枚の口座収支とはしない。観測不足、金融未知、未到達、0取得の場を除外せず、未参加や決済後の仮想利益を機会損失として最適化していない。\n\n[条件JSON](条件.json) / [設定と結果・V8](設定と結果.md) / [結果前の調査稿](調査と候補.md) / [原因と次仮説](原因と次の仮説.md) / [再現手順](再現手順.md) / [保存索引](再現資料/保存索引.json)。条件SHA256 `'+BOOK_SHA+'`。閲覧用CSVは後続163を中心とする比較資料へ集約予定で、162のこの保存工程ではCSV/XLSXを生成していない。数値の正本は本試行の圧縮資料へ恒久保存した。\n'
    (TRIAL/'README.md').write_text(report,encoding='utf-8')
    # ----------------------------------------
    reproduce='''# 162の再現手順

2026-11-14。条件SHA `4f890114b789da404d400f49a5cb888e9b9014013b00fcc0f77dc6ffd691088c`。原試行の条件と結果を上書きせず、別checkout又は隔離先で実行する。正式文書・圧縮正本の閲覧はworkを必要としない。

## 保存物

- [Source.zip](再現資料/Source.zip)：Rootの共通/出生/取得統計/全screen/過去選択、旧保存幅金融reader、初版972候補、固定selector、各人工・独立監査・報告生成、正式入力再現アダプター。元のwork相対位置を保持する。
- [出生と探索.zip](再現資料/出生と探索.zip)：全出生NPZ、候補辞書、全screen圧縮JSON、旧28対照、過去全判断NPZ、全96政策/3488支持/7008場/取得参照、162の数値金融NPZ・識別・入力確認、生成入力の停止票。
- [保存索引](再現資料/保存索引.json)：各保存物/ZIP memberのサイズ・SHA、共有入力の由来、実行環境、正式移設の対応。元148 Raw、161cache、163索引は複製しない。
- `検査/`：F0～F3、人工/独立自然検査、元観測射影の確認。`成果物/`：診断根拠と要点。全探索をMarkdownで全件転記しない。

## 共有入力と環境

正式148の`100特徴の列定義.json`、`当時特徴.json.gz`、`固定取得入力.json.gz`、`取得対応.json.gz`、`入口参照.json.gz`、`固定取得の正逆観測.json.gz`を共有参照する。旧152/153の正式`選択対応.json.gz`を固定対照として参照する。各物理/解凍SHAは索引と検査票へ記録した。Raw本体の副本は不要。

自然実行はWindows、Python3.14.3、NumPy2.5.4、ijson3.6.0、tzdata2026.6。CatBoostを学習/推論していない。旧151由来の特徴2cacheは後発生成物の固定SHAを確認して再用したが、正式151の初回F1前から存在したとは主張しない。162では教師2cacheを読まない。NPZのZIP日時byte同体と配列値の同体を分ける。

## 同じcacheがある隔離checkoutでの元手順

Source.zipを元の相対位置へ展開し、作業出力先が未作成であることを確認する。旧保存幅の数値射影を先に一度作る。

```powershell
python -X utf8 work/162可変幅評価/run162.py --book study/00162_複合入口を広く探索し値幅ごとに過去選択する/条件.json --book-sha256 4f890114b789da404d400f49a5cb888e9b9014013b00fcc0f77dc6ffd691088c --output-dir work/162可変幅評価/自然射影
python -X utf8 work/162入口探索/全出生を作る.py
python -X utf8 work/162入口探索/広く評価する.py
python -X utf8 work/162入口探索/過去で選ぶ.py
```

これらの元CLIは条件・検査票を書き込むため、原試行があるcheckoutでは実行しない。Source同梱READMEの準備時仮pathより本手順を優先する。全出生は金融を渡さず確定し、取得/金融を後結合。全期screenと過去選択のSource/結果を別に保存する。

## 161cacheを持たない正式入力からの再現

共有の正式148/152/153が参照できる別checkoutへSource.zipだけを展開し、出生と探索.zipは展開せず参照にする。次の追加CLIは必要な162金融入力だけを圧縮正本から復元し、100特徴はSHA固定旧151/161射影で正式148から再生成する。161cacheの副本を作らない。

```powershell
python -X utf8 work/162正式保存/正式入力から再現する.py --reference-zip study/00162_複合入口を広く探索し値幅ごとに過去選択する/再現資料/出生と探索.zip
```

元の作者Source byteを変更せず、runtimeの特徴loadだけを正式射影へ接続し、F1/F2/F3はwork内の隔離再現検査へ出す。全出生/過去判断は配列値を、全screen/旧対照/過去の成績・支持・取得はJSON意味値を保存正本へ比較する。NPZ物理byte一致を要求しない。この追加CLI自体の全再実行は今回は行っておらず、構文/ヘルプだけを確認した。元の自然実行と全数独立監査は実施済みであり、両者を混同しない。

## 検算

Source内の`work/162入口監査_候補担当/`に独立取得・N/U/F・統計・過去支持順位の計算を保存。各自然監査はRoot完了票を要求し、全件・全帯・前後・0取得場を比較する。`過去選択の人工監査.py`では現在/未来と窓外過去への毒入れでも過去結果が不変。候補式は作者自身の入力と区別してRoot側の確認へ分担した。

金融は実側BBOの最初touch、なければcomplete期限endpoint、他は未知。C早期touchの既知金融とstrict先着ラベルを分ける。`outcome.net5`をtouch損益へ流用しない。反対側確率を1−pで作らない。旧153等の±125成績を200へ流用せず、同じ固定取得を各幅で再評価する。

旧156・未見2場はこの再現の入力にしない。条件や候補/幅/期限/選択規則を変える実験は新試行で固定する。162の事後診断を162採否へ戻していない。163の任意幅Raw索引は別の正式試行へ保存し、ここへ重複させない。
'''
    (TRIAL/'再現手順.md').write_text(reproduce,encoding='utf-8')
    # ----------------------------------------
    archive_dir=TRIAL/'再現資料';archive_dir.mkdir(exist_ok=True)
    source_archive=archive_dir/'Source.zip';data_archive=archive_dir/'出生と探索.zip'
    assert not source_archive.exists() and not data_archive.exists()
    with zipfile.ZipFile(source_archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for path in sorted(source_files):archive.write(path,path.relative_to(ROOT).as_posix())
    state_files=set()
    for folder in ('全出生','広い評価','過去選択'):
        state_files.update(p for p in (ROOT/'work/162入口探索'/folder).iterdir() if p.is_file())
    state_files.update(p for p in (ROOT/'work/162可変幅評価/自然射影').iterdir() if p.is_file())
    state_files.update(ROOT/p for p in ['work/162複合入口候補/候補辞書.json','work/162過去規則選択/停止票.json',
        'work/162可変幅評価/旧保存幅の停止.json','work/162保存QA/報告照合用の独立数値抽出.json',
        'work/162保存QA/既存試行の基準指紋.json'])
    assert not any('151過去場判別の評価' in str(p) or '163' in p.relative_to(ROOT).parts for p in state_files)
    with zipfile.ZipFile(data_archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for path in sorted(state_files):archive.write(path,path.relative_to(ROOT).as_posix())
    assert all(sha(ROOT/path)==digest for path,digest in before.items())
    assert sha(TRIAL/'条件.json')==BOOK_SHA
    archives={}
    for path in (source_archive,data_archive):
        with zipfile.ZipFile(path) as archive:
            assert archive.testzip() is None
            members=[]
            for info in archive.infolist():
                original=ROOT/Path(*info.filename.split('/'));body=archive.read(info.filename)
                assert original.read_bytes()==body
                members.append({'path':info.filename,'bytes':info.file_size,'sha256':hashlib.sha256(body).hexdigest(),'crc32':info.CRC})
            archives[path.name]={'bytes':path.stat().st_size,'sha256':sha(path),'members':members}
    shared_inputs=[]
    for folder in ('inputs/00148_全1分入口母集団','inputs/00152_複合回復の方向切替','inputs/00153_先行高安の独立出生'):
        names=('100特徴の列定義.json','当時特徴.json.gz','固定取得入力.json.gz','取得対応.json.gz','入口参照.json.gz') if '00148' in folder else ('選択対応.json.gz',)
        for name in names:
            path=ROOT/folder/name;shared_inputs.append({'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':sha(path)})
    original=ROOT/'study/00148_全1分知得から入口品質の母集団を固定する/成果物/固定取得の正逆観測.json.gz'
    shared_inputs.append({'path':original.relative_to(ROOT).as_posix(),'bytes':original.stat().st_size,'sha256':sha(original),
        'decoded_sha256':'d1b4cab8a258203f04b5c1d081f57d10ed2a0c58ce4cc160ef571d5fac0ceffc'})
    runtime={name:importlib.metadata.version(name) for name in ('numpy','ijson','tzdata')}
    runtime['python']='.'.join(map(str,sys.version_info[:3]));runtime['os']='Windows';runtime['CatBoost']='本試行で未使用'
    save(archive_dir/'保存索引.json',{'成功':True,'試行':162,'確認日':'2026-11-14','時計':datetime.now(timezone.utc).isoformat(),
        '条件SHA256':BOOK_SHA,'runtime':runtime,'archives':archives,'shared_inputs':shared_inputs,
        'source_fingerprints':before,'共用Rawと161cacheと163索引の複製':False,
        '正式入力再現CLI':'構文/ヘルプのみ確認。原自然と全数独立監査は実行済み。',
        '閲覧用CSV':'Rootが後続163中心の比較へ集約。162保存工程では未生成。',
        '後発QA':'この索引の後に作成する票は相互自己参照を避け、別の後発QA保存票で管理。',
        'formal_files':{p.relative_to(TRIAL).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)}
            for p in TRIAL.rglob('*') if p.is_file() and p.name!='保存索引.json'}})
    print(json.dumps({'成功':True,'試行':162,'archives':{name:{'bytes':v['bytes'],'sha256':v['sha256'],'members':len(v['members'])} for name,v in archives.items()},'runtime':runtime},ensure_ascii=False))


if __name__=='__main__':
    main()
