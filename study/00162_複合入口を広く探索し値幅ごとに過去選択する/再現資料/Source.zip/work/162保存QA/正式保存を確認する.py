"""162の正式文書・汎用表・保存ZIPを数値正本と独立照合する。"""
from pathlib import Path
import ast
import hashlib
import json
import re
from urllib.parse import unquote
import zipfile

from 数値を独立抽出する import ROOT,HERE,BOOK_SHA,sha,read

TRIAL=ROOT/'study/00162_複合入口を広く探索し値幅ごとに過去選択する'


def method_rows(path: Path) -> list:
    """
    機能: 指標IDと9尺度を持つ全手法行だけをMarkdownから読む。
    引数: path(Path)。
    返り値: list[list[str]]はID/名称/9尺度の11欄。
    """
    result=[]
    for line in path.read_text(encoding='utf-8').splitlines():
        values=[v.strip() for v in line.split('|')[1:-1]] if line.startswith('|') else []
        if len(values)==11 and re.fullmatch(r'[A-Z][0-9]{2}',values[0]):result.append(values)
    return result


def target_path(document: Path,target: str) -> Path|None:
    """
    機能: ローカルMarkdownリンクを閲覧時の絶対位置へ解決する。
    引数: document(Path)、target(str)。
    返り値: Path又はNone。外部URLと同頁アンカーはNone。
    """
    target=unquote(target.strip().strip('<>'))
    if re.match(r'^[a-zA-Z]+://',target) or target.startswith('#'):return None
    target=target.split('#',1)[0]
    if not target:return None
    return (document.parent/target).resolve()


def zip_checks(path: Path) -> dict:
    """
    機能: 全ZIPメンバーのCRC・パス安全性・現物同体と共有入力の非複製を確認する。
    引数: path(Path)。
    返り値: dictは件数と物理指紋。zip内容は展開しない。
    """
    proof={'path':str(path.relative_to(TRIAL)),'bytes':path.stat().st_size,'sha256':sha(path),
        'members':0,'全CRC完読':False,'元と同体':0,'元未存在':[],'禁止複製':[],'member_hashes':{}}
    with zipfile.ZipFile(path) as source:
        assert source.testzip() is None
        assert len(source.namelist())==len(set(source.namelist()))
        for info in source.infolist():
            if info.is_dir():continue
            name=info.filename.replace('\\','/');parts=Path(name).parts
            assert not name.startswith('/') and '..' not in parts
            body=source.read(info.filename);digest=hashlib.sha256(body).hexdigest()
            proof['member_hashes'][name]=digest
            assert len(body)==info.file_size
            local=ROOT/name
            if local.is_file():
                assert local.stat().st_size==len(body) and sha(local)==digest,(path.name,name,'元相違')
                proof['元と同体']+=1
            else:proof['元未存在'].append(name)
            forbidden=('work/151過去場判別の評価/入口選択/cache/' in name or name.startswith('inputs/00148_')
                or name.startswith('work/163') or name.endswith(('book.jsonl','book.jsonl.gz')))
            if forbidden:proof['禁止複製'].append(name)
            proof['members']+=1
    proof['全CRC完読']=True
    assert not proof['禁止複製'],proof['禁止複製']
    return proof


def numeric(value: str) -> float:
    """
    機能: 人が読む表の通貨・桁区切り・符号を数値へ解釈する。
    引数: value(str)は表示値。
    返り値: floatは数値。
    """
    cleaned=value.replace(',','').replace('円','').replace('−','-').replace('＋','+').strip().strip('`* ')
    return float(cleaned.rstrip('%'))


def readme_numbers(path: Path,reference: dict) -> dict:
    """
    機能: 政策IDが明示されたREADME表の主要数値を圧縮正本の抽出値と比較する。
    引数: path(Path)、reference(dict)は独立抽出したfixed/past。
    返り値: dictは検査した表行・欄数と未解釈ID。
    """
    lookup={r['id']:r for r in reference['fixed']+reference['past']}
    count=0;checked=[];headers=[];unknown=[]
    aliases={'取得':'count','取得数':'count','件数':'count','先着率':'rate','到達済み率':'rate','到達済み先着率':'rate',
        '利益':'profit','利益総額':'profit','損失':'loss','損失総額':'loss','既知差引':'net','差引':'net',
        '金融未知':'unknown','未知':'unknown','PF':'pf','毎時':'per_hour','取得/時':'per_hour','取得毎時':'per_hour'}
    for line in path.read_text(encoding='utf-8').splitlines():
        if not line.startswith('|'):continue
        cells=[c.strip() for c in line.split('|')[1:-1]]
        if any(h in '|'.join(cells) for h in ('政策','規則','候補','方式')) and not any(re.search(r'MP00[0-9]{2}|S(?:65|70)_B[58]_K[13]',c) for c in cells):
            headers=cells;continue
        matched=re.search(r'(MP00[0-9]{2}_ALL_W200_H3600_[NUF]|S(?:65|70)_B[58]_K[13]_W(?:125|200)_H(?:1800|3600)_[NUF])',line)
        if not matched:continue
        identifier=matched.group(1)
        if identifier not in lookup:unknown.append(identifier);continue
        row=lookup[identifier]
        period=next((c for c in cells if c in ('全期','前48場','後25場')),'全期')
        band=next((c for c in cells if c in ('デイ','米国前','米国後')),None)
        values=row['periods'][period] if band is None else row['bands'][period][('デイ','米国前','米国後').index(band)]
        for i,cell in enumerate(cells):
            if i>=len(headers):break
            header=headers[i].replace('円','').strip()
            if header.startswith('順/逆'):
                assert [int(v) for v in cell.split('/')]==[values[k] for k in ('F','A','N','C')],(identifier,header,cell)
                count+=4;continue
            selected_values=values
            if '前48' in header:
                selected_values=row['periods']['前48場'];key='rate' if '率' in header else 'net'
            elif '後25' in header:
                selected_values=row['periods']['後25場'];key='rate' if '率' in header else 'net'
            else:key=aliases.get(header,'rate' if '先着率' in header else None)
            if key is None:continue
            if selected_values[key] is None:
                assert cell in ('未定義','—','-','なし'),(identifier,header,cell)
            else:
                actual=numeric(cell);wanted=float(selected_values[key])
                if key=='rate':
                    decimal=len(cell.rstrip('%').split('.')[-1]) if '.' in cell else 0
                    assert abs(actual-wanted*100)<=.5*10**(-decimal)+1e-8,(identifier,header,actual,wanted*100)
                elif key in ('pf','per_hour'):
                    decimal=len(cell.split('.')[-1]) if '.' in cell else 0
                    assert abs(actual-wanted)<=.5*10**(-decimal)+1e-8,(identifier,header,actual,wanted)
                else:assert actual==wanted,(identifier,header,actual,wanted)
            count+=1
        checked.append(identifier)
    return {'表行':len(checked),'照合数値欄':count,'政策ID':checked,'未対象の表政策':unknown}


def main() -> None:
    """
    機能: 正式保存完了後、本文・数値・全リンク・表・ZIP・Source指紋を再確認する。
    引数: なし。文書・ZIPを変更せずwork/162保存QAへ結果票だけを保存する。
    返り値: None。欠落・不整合は停止する。
    """
    assert sha(TRIAL/'条件.json')==BOOK_SHA
    documents=sorted(TRIAL.glob('*.md'));assert len(documents)>=4
    texts={p:p.read_text(encoding='utf-8',errors='strict') for p in documents}
    all_text='\n'.join(texts.values())
    links=[];missing=[];work_dependency=[]
    for path,text in texts.items():
        for label,target in re.findall(r'\[([^\]]+)\]\(([^)]+)\)',text):
            resolved=target_path(path,target)
            if resolved is None:continue
            links.append((path.name,label,target))
            if not resolved.exists():missing.append((path.name,target))
            if str(resolved).startswith(str(ROOT/'work')):work_dependency.append((path.name,target))
    assert not missing,missing
    assert not work_dependency,work_dependency
    required={key:any(token in all_text for token in tokens) for key,tokens in {
        '仮説':('仮説',),'入力':('入力',),'条件':('条件',),'費用':('費用',),'結果':('結果',),
        '限界':('限界',),'再現手順':('再現手順',),'screenと過去選択を区別':('全期screen','全期探索'),
        '既使用を明記':('既使用',),'未見の限定':('未見',),'旧156の未実行':('156',),
        '未見2場':('11/10','11月10日'),'純新規と旧補完':('旧C1','旧補完'),
        '単純IFD':('IFD',),'未知と未到達':('未到達',),'163へ継続':('163',)}.items()}
    assert all(required.values()),required
    # ----------------------------------------
    template=ROOT/'docs/議論/手法と時間スケールの汎用表_版8.md'
    settings=TRIAL/'設定と結果.md';wanted=method_rows(template);actual=method_rows(settings)
    assert len(wanted)==len(actual)==63
    for a,b in zip(actual,wanted,strict=True):
        assert a[0]==b[0] and all(a[2:])
        aname,alink=re.search(r'\[([^\]]+)\]\(([^)]+)\)',a[1]).groups()
        bname,blink=re.search(r'\[([^\]]+)\]\(([^)]+)\)',b[1]).groups()
        assert aname==bname and target_path(settings,alink)==target_path(template,blink),(a[0],alink,blink)
    assert sha(template) in texts[settings]
    # ----------------------------------------
    archives=[zip_checks(TRIAL/'再現資料'/name) for name in ('Source.zip','出生と探索.zip')]
    members={k:v for p in archives for k,v in p['member_hashes'].items()}
    source_required=['work/162入口探索/'+name for name in ('共通.py','全出生を作る.py','評価基盤.py','広く評価する.py','過去で選ぶ.py')]
    source_required += ['work/162過去規則選択/selector162.py','work/162複合入口候補/rules162.py',
        'work/161三時間帯入口のデータ/data161.py','work/151過去場判別/data151.py','work/162可変幅評価/outcomes162.py']
    assert all(name in members for name in source_required),[name for name in source_required if name not in members]
    function_count=0;comments=[]
    with zipfile.ZipFile(TRIAL/'再現資料/Source.zip') as source:
        for info in source.infolist():
            if not info.filename.endswith('.py'):continue
            tree=ast.parse(source.read(info.filename).decode('utf-8'))
            for node in ast.walk(tree):
                if not isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):continue
                function_count+=1;doc=ast.get_docstring(node)
                if doc is None or '\n' not in doc or not all(token in doc for token in ('機能','引数','返り値')):
                    comments.append((info.filename,node.name))
    assert not comments,comments
    # F0は金融部品のfolder相対、F1/F2/F3はrepo相対。
    bindings=[]
    for path in sorted((TRIAL/'検査').glob('F[0-3]*.json')):
        evidence=read(path)
        assert evidence['条件SHA256']==BOOK_SHA
        source=evidence.get('Source',evidence.get('Sourceと出生',{}))
        for key,digest in source.items():
            normalized=key.replace('\\','/')
            if not normalized.startswith('work/'):normalized='work/162可変幅評価/'+normalized
            assert normalized in members and members[normalized]==digest,(path.name,normalized)
            bindings.append((path.name,normalized))
    # ----------------------------------------
    reference=read(HERE/'報告照合用の独立数値抽出.json')
    numbers=readme_numbers(TRIAL/'README.md',reference)
    assert numbers['表行']>=4 and numbers['照合数値欄']>=16,numbers
    assert not list(TRIAL.rglob('*.xlsx')) and not list(TRIAL.rglob('*.csv'))
    index=TRIAL/'再現資料/保存索引.json'
    assert index.exists()
    indexed=read(index);indexed_files=[]
    for key,record in indexed.get('formal_files',{}).items():
        path=TRIAL/key
        assert path.exists() and path.stat().st_size==record['bytes'] and sha(path)==record['sha256'],key
        indexed_files.append(key)
    baseline=read(HERE/'既存試行の基準指紋.json')
    for key,record in baseline['files'].items():
        path=ROOT/key
        assert path.stat().st_size==record['bytes'] and sha(path)==record['sha256'],('既存試行変更',key)
    proof={'成功':True,'試行':162,'範囲':'正式保存物・報告数値の独立QA。売買アルゴリズムの再実行ではない。',
        '条件SHA256':BOOK_SHA,'文書数':len(documents),'ローカルリンク数':len(links),'不存在':missing,'work閲覧依存':work_dependency,
        '必須項目':required,'V8':{'全手法':63,'尺度':9,'全セル':567,'ID名称教材リンク同体':True,'元SHA256':sha(template)},
        'ZIP':[dict((k,v) for k,v in p.items() if k!='member_hashes') for p in archives],
        'F0F1F2F3束縛数':len(bindings),'Source関数コメント確認数':function_count,
        'README数値':numbers,'保存索引参照検査数':len(indexed_files),'旧160と161の不変実体数':len(baseline['files']),
        '保存索引SHA256':sha(index),'検査SourceSHA256':sha(Path(__file__)),
        '本文SHA256':{p.name:sha(p) for p in documents}}
    (HERE/'正式保存の独立確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':
    main()
