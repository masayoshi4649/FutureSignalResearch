"""162圧縮正本から正式報告の照合対象だけを独立抽出する。"""
from pathlib import Path
from collections import Counter
import gzip
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
BOOK_SHA='4f890114b789da404d400f49a5cb888e9b9014013b00fcc0f77dc6ffd691088c'


def sha(path: Path) -> str:
    """
    機能: ファイルの物理指紋を全読了して計算する。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    with path.open('rb') as source:return hashlib.file_digest(source,'sha256').hexdigest()


def read(path: Path) -> object:
    """
    機能: gzip全CRCと前後SHAを確認してJSONを読む。
    引数: path(Path)。
    返り値: objectはJSON値。
    """
    fingerprint=sha(path);body=path.read_bytes()
    result=json.loads(gzip.decompress(body) if path.suffix=='.gz' else body)
    assert sha(path)==fingerprint
    return result


def main() -> None:
    """
    機能: MP近傍と過去選択の比較値を結果Sourceから新しい数値を作らず抽出する。
    引数: なし。自然計算自体の再実装は他の独立監査を参照する。
    返り値: None。JSONと小型Markdownの報告照合用資料を保存する。
    """
    trial=ROOT/'study/00162_複合入口を広く探索し値幅ごとに過去選択する'
    assert sha(trial/'条件.json')==BOOK_SHA
    screen_path=ROOT/'work/162入口探索/広い評価/全探索200.json.gz'
    past_path=ROOT/'work/162入口探索/過去選択/過去選択の成績.json.gz'
    support_path=ROOT/'work/162入口探索/過去選択/過去選択の支持.json.gz'
    screen=read(screen_path);past=read(past_path);support=read(support_path)
    fixed=[r for r in screen['rows'] if r['rule'] in ('MP0057','MP0058','MP0081','MP0082')
        and r['entry_mode']=='ALL' and r['horizon']==3600]
    selected=[r for r in past['rows'] if r['selector'] in ('S70_B5_K3','S65_B8_K1')]
    assert len(fixed)==12 and len(selected)==24
    summarized=[]
    for selector in ('S70_B5_K3','S65_B8_K1'):
        records=[r for r in support['rows'] if r['width']==200 and r['horizon']==3600 and r['setting']==selector]
        assert len(records)==109
        groups=Counter(name[:2] for r in records for name in r['selected_ids'])
        summarized.append({'selector':selector,'場帯判断':len(records),'空選択':sum(not r['selected_ids'] for r in records),
            'MP選択を含む判断':sum(any(name.startswith('MP') for name in r['selected_ids']) for r in records),
            '群別規則選択延数':dict(sorted(groups.items()))})
    result={'成功':True,'試行':162,'条件SHA256':BOOK_SHA,'fixed':fixed,'past':selected,'support_summary':summarized,
        'scope':'固定済み圧縮正本の数値抽出。再計算・探索・採否変更なし。',
        'inputs':{str(p.relative_to(ROOT)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in (screen_path,past_path,support_path)}}
    (HERE/'報告照合用の独立数値抽出.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    headers=['政策','取得','順/逆/未/不足','先着率','利益','損失','既知差引','未知','毎時','場']
    lines=['# 162報告数値の独立抽出','',
        '固定全期screenの発見候補と過去選択を別々に示す。全73場は既使用。',
        '', '| '+' | '.join(headers)+' |','| '+' | '.join('---' for _ in headers)+' |']
    focused=fixed+[r for r in selected if r['width']==200 and r['horizon']==3600]
    for r in focused:
        v=r['periods']['全期'];rate=f"{v['rate']:.6%}" if v['rate'] is not None else '未定義'
        values=[r['id'],str(v['count']),'/'.join(str(v[k]) for k in ('F','A','N','C')),rate,
            str(v['profit']),str(v['loss']),str(v['net']),str(v['unknown']),str(v['per_hour']),str(v['scenes'])]
        lines.append('| '+' | '.join(values)+' |')
    (HERE/'報告数値の照合表.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'MP全期U':[{'id':r['id'],**r['periods']['全期']} for r in fixed if r['integration']=='U'],
        '過去全期U':[{'id':r['id'],**r['periods']['全期']} for r in focused if r['group']=='PAST' and r['integration']=='U'],
        '支持':summarized},ensure_ascii=False))


if __name__=='__main__':
    main()
