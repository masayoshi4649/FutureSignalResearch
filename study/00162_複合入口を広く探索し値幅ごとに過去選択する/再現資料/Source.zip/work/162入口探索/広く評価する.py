"""新規972規則を単純IFDの複数幅・期限で探索的に比較する。"""
from pathlib import Path
import json
import time
import numpy as np
from 共通 import ROOT,HERE,TRIAL,BOOK_SHA,book,read,save,sha,module
from 評価基盤 import Context


def selections(context: Context, width: int):
    """
    機能: 固定済み全出生から規則と発火方式別の新規取得を順次返す。
    引数: context(Context)、width(int)は事前幅。
    返り値: generator[tuple]は規則ID・発火方式・全q0方向・新規Selection。
    """
    proof=read(HERE/'全出生/全出生の確認.json')
    path=HERE/'全出生'/f'出生{width}.npz'
    assert sha(path)==proof['files'][path.name]['sha256']
    with np.load(path,allow_pickle=False) as source:
        arrays={k:source[k].copy() for k in source.files}
    assert set(arrays)=={'ALL','EDGE'}
    for i,rule in enumerate(proof['規則順']):
        for mode in ('ALL','EDGE'):
            direction=arrays[mode][i]
            yield rule,mode,direction,context.link(direction)


def record(context: Context, selected: object, policy: str, group: str, wi: int, hi: int, extra: dict) -> dict:
    """
    機能: 一政策の前後・取得帯ごとの数値を欠落なく記録する。
    引数: context(Context)、selected(Selection)、policy/group(str)、wi/hi(int)、extra(dict)。
    返り値: dictは全期/前48/後25と三帯の統計。
    """
    return {'id':policy,'group':group,'width':context.table.widths[wi],'horizon':context.table.horizons[hi],**extra,
        'periods':{p:context.stats(selected,wi,hi,p) for p in ('全期','前48場','後25場')},
        'bands':{p:[context.stats(selected,wi,hi,p,b) for b in range(3)] for p in ('全期','前48場','後25場')}}


# ----------------------------------------
def main() -> None:
    """
    機能: 既存ラベルを新規出生へ後結合し、全screenと固定旧対照を保存する。
    引数: なし。162の条件と全出生・完成観測を利用する。
    返り値: None。探索結果は採用済み又は未見成績とは呼ばない。
    """
    setting=book();out=HERE/'広い評価';assert not out.exists()
    paths=[Path(__file__),HERE/'評価基盤.py',HERE/'共通.py',HERE/'全出生/全出生の確認.json']
    before={str(p.relative_to(ROOT)):sha(p) for p in paths}
    save(TRIAL/'検査/F2_広い評価前.json',{'成功':True,'条件SHA256':BOOK_SHA,'Sourceと出生':before,
        '全期screenは発見用':True,'全期最良を過去選択の結果と呼ばない':True})
    context=Context();out.mkdir();begin=time.monotonic()
    controls=[]
    for wi,width in enumerate(setting['widths']):
        for hi,horizon in enumerate(setting['horizons']):
            for name,selected in context.old_controls().items():
                controls.append(record(context,selected,f'{name}_W{width}_H{horizon}','CONTROL',wi,hi,{'origin':'旧固定対照'}))
    control=next(r for r in controls if r['id']=='00153_U15_W125_H3600')['periods']['全期']
    assert (control['count'],control['F'],control['A'],control['N'],control['C'],control['profit'],control['loss'],control['net'],control['unknown'])==(93,46,18,22,7,604611,337541,267070,3)
    save(out/'旧対照.json.gz',{'成功':True,'rows':controls})
    rows=[]
    for wi,width in enumerate(setting['widths']):
        count=0
        for rule,mode,direction,new in selections(context,width):
            variants={name:context.integrate(new,name) for name in ('N','U','F')}
            for hi,horizon in enumerate(setting['horizons']):
                for integration,selected in variants.items():
                    rows.append(record(context,selected,f'{rule}_{mode}_W{width}_H{horizon}_{integration}',rule[:2],wi,hi,
                        {'rule':rule,'entry_mode':mode,'integration':integration,
                         'born':int(np.count_nonzero(direction)),'acquired_new':len(new.cases)}))
            count+=1
            if count%150==0:
                print(json.dumps({'幅':width,'評価済規則方式':count,'保存予定行':len(rows),'経過秒':round(time.monotonic()-begin)},ensure_ascii=False),flush=True)
        save(out/f'全探索{width}.json.gz',{'成功':True,'trial':162,'採用済みではない':True,'rows':rows})
        rows=[]
    assert all(sha(ROOT/p)==v for p,v in before.items())
    # ----------------------------------------
    all_rows=[]
    for width in setting['widths']:
        all_rows.extend(read(out/f'全探索{width}.json.gz')['rows'])
    candidates=[r for r in all_rows if r['integration'] in ('F','U') and r['periods']['全期']['count']>=200
        and r['periods']['全期']['rate'] is not None and r['periods']['全期']['rate']>=.7]
    ordered=sorted(candidates,key=lambda r:(-r['periods']['全期']['count'],-r['periods']['全期']['rate'],r['id']))
    promising=[r for r in ordered if all(r['periods'][p]['net']>0 for p in ('前48場','後25場'))]
    top=sorted(all_rows,key=lambda r:(-(r['periods']['全期']['rate'] or 0),-r['periods']['全期']['count'],r['id']))[:100]
    save(out/'探索の要点.json',{'成功':True,'条件SHA256':BOOK_SHA,'全探索行':len(all_rows),'旧対照行':len(controls),
        '200取得以上かつ70%以上':len(candidates),'前後とも既知黒字':len(promising),'頻度順上位':ordered[:60],
        '前後黒字の頻度順上位':promising[:60],'率順上位100':top,'経過秒':time.monotonic()-begin})
    save(out/'完了.json',{'成功':True,'Source':before,'全探索行':len(all_rows),'旧対照行':len(controls),
        'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in out.iterdir() if p.is_file()}})
    print(json.dumps({'成功':True,'全探索行':len(all_rows),'200取得以上70%以上':len(candidates),
        '前後黒字':len(promising),'上位':[{'id':r['id'],**r['periods']['全期']} for r in promising[:5]]},ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
