"""金融を読む前に972条件と値幅別の全q0判断を確定する。"""
from pathlib import Path
import json
import numpy as np
from 共通 import ROOT,HERE,TRIAL,BOOK_SHA,book,sha,module,data_module,save


def edge_directions(directions: np.ndarray, sessions: np.ndarray, times: np.ndarray) -> np.ndarray:
    """
    機能: 場内の条件成立への遷移だけを出生とし、定時の回数上限を使わない。
    引数: directions(np.ndarray[int8])、sessions(np.ndarray[int])、times(np.ndarray[float])。
    返り値: np.ndarray[int8]は新しい成立又は180秒超のブロック開始だけの方向。
    """
    previous=np.r_[np.int8(0),directions[:-1]]
    resets=np.r_[True,(sessions[1:]!=sessions[:-1])|(times[1:]-times[:-1]>180)]
    return np.where((directions!=previous)|resets,directions,0).astype(np.int8)


# ----------------------------------------
def main() -> None:
    """
    機能: 取得/ラベルを引数へ渡さず全幅×規則×q0を保存する。
    引数: なし。固定162条件と実側100特徴だけを利用する。
    返り値: None。全出生NPZと未知・競合の計数を保存する。
    """
    setting=book();out=HERE/'全出生';assert not out.exists()
    rule_path=ROOT/setting['candidate_source']['path']
    assert sha(rule_path)==setting['candidate_source']['sha256']
    assert sha(ROOT/setting['registry']['path'])==setting['registry']['sha256']
    rules=module(rule_path,'rules162');data=data_module()
    paths=[Path(__file__),HERE/'共通.py',rule_path]
    before={str(p.relative_to(ROOT)):sha(p) for p in paths}
    save(TRIAL/'検査/F1_全出生前.json',{'成功':True,'条件SHA256':BOOK_SHA,'Source':before,'金融を入力にしない':True})
    features=data.load_feature_dataset()
    columns,_=data.read_json_ref(data.FileRef(ROOT/'inputs/00148_全1分入口母集団/100特徴の列定義.json',data.CATALOG_SHA256))
    registry=rules.candidate_catalog();assert len(registry)==setting['candidate_count']
    sessions=np.array([q['session_index'] for q in features.q0_meta],dtype=np.int16)
    times=np.array([q['q0_time'] for q in features.q0_meta],dtype=np.float64)
    out.mkdir()
    counts=[]
    for width in setting['widths']:
        evaluator=rules.PreparedEvaluator(features.buy_X,features.sell_X,columns,target_points=width)
        matrix=np.empty((len(registry),len(times)),dtype=np.int8);edge=np.empty_like(matrix)
        for i,decision in enumerate(evaluator.iter_decisions(registry)):
            assert decision['candidate_id']==registry[i]['id']
            matrix[i]=decision['directions'];edge[i]=edge_directions(matrix[i],sessions,times)
            counts.append({'rule':decision['candidate_id'],'width':width,'ALL':int(np.count_nonzero(matrix[i])),
                'EDGE':int(np.count_nonzero(edge[i])),'conflict':int(decision['conflicts'].sum()),
                'unknown_buy':int(decision['unknown_buy'].sum()),'unknown_sell':int(decision['unknown_sell'].sum())})
        np.savez_compressed(out/f'出生{width}.npz',ALL=matrix,EDGE=edge)
        print(json.dumps({'全出生確定':True,'width':width,'規則数':len(registry),'q0数':len(times)},ensure_ascii=False),flush=True)
    assert all(sha(ROOT/p)==v for p,v in before.items())
    save(out/'全出生の確認.json',{'成功':True,'条件SHA256':BOOK_SHA,'金融未入力':True,'Source':before,
        '特徴入力':features.sources,'規則順':[r['id'] for r in registry],'counts':counts,
        'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in out.iterdir() if p.is_file()}})


if __name__=='__main__':
    main()
