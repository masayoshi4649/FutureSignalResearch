"""場開始時点の成熟済み過去だけで複合規則を選び、三帯の入口を組み立てる。"""
from pathlib import Path
import hashlib
import json
import time
import numpy as np
from 共通 import ROOT,HERE,TRIAL,BOOK_SHA,book,read,save,sha,module
from 評価基盤 import Context
from 広く評価する import selections,record


def build_history(context: Context, selected_rows: list, wi: int, hi: int) -> tuple:
    """
    機能: 候補ごとに両側期限完了の物理取得を場・出生帯へ射影する。
    引数: context(Context)、selected_rows(list[Selection])、wi/hi(int)は幅と期限。
    返り値: tuple[np.ndarray,np.ndarray]はF/A/N/利益/損失の過去集計と成熟時計最大。
    """
    history=np.zeros((len(selected_rows),73,3,5),dtype=np.int64)
    maturity=np.full((len(selected_rows),73,3),np.nan)
    arrays=context.arrays
    for i,selected in enumerate(selected_rows):
        pair=np.all(arrays['label'][selected.cases,:,wi,hi]!=2,axis=1)
        selected=selected.take(pair)
        case,side=selected.cases,selected.sides
        if not len(case):continue
        scene=context.case_scene[case];phase=selected.phases;flat=scene*3+phase
        label=arrays['label'][case,side,wi,hi];known=arrays['known'][case,side,wi,hi]
        assert known.all()
        money=arrays['net'][case,side,wi,hi]
        for j,weights in enumerate(((label==1).astype(np.int64),(label==-1).astype(np.int64),(label==0).astype(np.int64),
            np.maximum(money,0),np.maximum(-money,0))):
            np.add.at(history[i,:,:,j],(scene,phase),weights)
        times=np.max(arrays['known_at'][case,:,wi,hi],axis=1)
        assert np.isfinite(times).all()
        for s in np.unique(scene):
            for b in np.unique(phase[scene==s]):
                values=times[(scene==s)&(phase==b)]
                maturity[i,s,b]=values.max()
    return history,maturity


def past_metrics(history: np.ndarray, maturity: np.ndarray, context: Context, identifiers: list,
                 current: int, band: int) -> tuple:
    """
    機能: 現在/未来を切り離した過去20暦場の同帯集計だけを選択器へ渡す。
    引数: history/maturity(np.ndarray)、context(Context)、identifiers(list[dict])、current/band(int)。
    返り値: tuple[list[dict],dict]は成熟過去metricと窓の検査情報。
    """
    first=max(0,current-20)
    past=history[:,first:current,band,:]
    clocks=maturity[:,first:current,band]
    finite=clocks[np.isfinite(clocks)]
    assert not finite.size or np.max(finite)<context.starts[current]
    totals=past.sum(axis=1);counts=past[:,:,:3].sum(axis=2)
    scene_counts=np.count_nonzero(counts,axis=1)
    maximum=counts.max(axis=1) if current>first else np.zeros(len(history),dtype=np.int64)
    hours=float(context.hours[first:current,band].sum())
    metrics=[]
    for i,identifier in enumerate(identifiers):
        f,a,n,profit,loss=map(int,totals[i]);count=f+a+n
        metrics.append({**identifier,'F':f,'A':a,'N':n,'C':0,'count':count,
            'profit':profit,'loss':loss,'net':profit-loss,'scene_count':int(scene_counts[i]),
            'scene_max_share':int(maximum[i])/count if count else 0,'hours':hours})
    digest=hashlib.sha256(json.dumps(metrics,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
    return metrics,{'window_first':first,'window_last_exclusive':current,'current_start':int(context.starts[current]),
        'maximum_known_at':float(finite.max()) if finite.size else None,'hours':hours,'metrics_sha256':digest,
        'complete_pair_only':True,'current_or_future_used':False}


def union_directions(matrix: np.ndarray, indices: list[int], events: np.ndarray) -> np.ndarray:
    """
    機能: 選択規則の当時方向を統合し、両側競合なら待機する。
    引数: matrix(np.ndarray[int8])は規則方式×q0、indices(list[int])、events(np.ndarray[int])は当場当帯。
    返り値: np.ndarray[int8]はeventsに対応する−1/0/+1。
    """
    if not indices:return np.zeros(len(events),dtype=np.int8)
    chosen=matrix[np.ix_(indices,events)]
    buy=np.any(chosen==1,axis=0);sell=np.any(chosen==-1,axis=0)
    return np.where(buy&~sell,1,np.where(sell&~buy,-1,0)).astype(np.int8)


# ----------------------------------------
def main() -> None:
    """
    機能: 固定8選択器を各幅/期限へ過去順適用し、完了後に入口損益を結ぶ。
    引数: なし。固定162条件・全出生・純観測を使う。
    返り値: None。選択支持・全q0採否・96政策・全場正本を保存する。
    """
    setting=book();out=HERE/'過去選択';assert not out.exists()
    selector_path=ROOT/'work/162過去規則選択/selector162.py'
    assert sha(selector_path)=='55fecbf09f04a6ce5d187e0e4efbf8e997eca5fba5363c8840151851cbc5cebb'
    selector=module(selector_path,'selector162_root')
    sources=[Path(__file__),HERE/'評価基盤.py',HERE/'共通.py',HERE/'広く評価する.py',selector_path]
    before={str(p.relative_to(ROOT)):sha(p) for p in sources}
    save(TRIAL/'検査/F3_過去選択前.json',{'成功':True,'条件SHA256':BOOK_SHA,'Source':before,
        '成熟は両実側期限完了の最大endpointstrict':True,'支持場は成熟取得のある場':True})
    context=Context();out.mkdir();rows=[];audits=[];all_sessions=[];reference=[];begin=time.monotonic()
    configurations=setting['selection']['selectors']
    for wi,width in enumerate(setting['widths']):
        candidates=list(selections(context,width))
        identifiers=[{'id':rule+'_'+mode,'rule_id':rule,'group':rule[:2]} for rule,mode,_,_ in candidates]
        lookup={r['id']:i for i,r in enumerate(identifiers)}
        matrix=np.stack([r[2] for r in candidates]);selected_rows=[r[3] for r in candidates]
        for hi,horizon in enumerate(setting['horizons']):
            history,maturity=build_history(context,selected_rows,wi,hi)
            decisions=np.zeros((len(configurations),len(context.events)),dtype=np.int8)
            for current,scene in enumerate(context.scenes):
                active=np.flatnonzero(context.event_scenes==current)
                for band in np.unique(context.event_phases[active]):
                    events=active[context.event_phases[active]==band]
                    metrics,clock=past_metrics(history,maturity,context,identifiers,current,int(band))
                    for ci,config in enumerate(configurations):
                        audit=selector.select_with_audit(metrics,config)
                        names=audit['selected_ids'];indices=[lookup[name] for name in names]
                        decisions[ci,events]=union_directions(matrix,indices,events)
                        audits.append({'width':width,'horizon':horizon,'session':scene['session'],'band':int(band),
                            'setting':config['id'],'clock':clock,'selected_ids':names,'eligible_count':audit['eligible_count'],
                            'rejection_counts':audit['rejection_counts'],'selected_metrics':[r for r in audit['rows'] if r['selected']],
                            'born':int(np.count_nonzero(decisions[ci,events]))})
                if (current+1)%15==0:
                    print(json.dumps({'幅':width,'期限':horizon,'場':current+1,'選択器':len(configurations),'経過秒':round(time.monotonic()-begin)},ensure_ascii=False),flush=True)
            # 全場の採否を先に封印し、その後に現在場のIFD金融へ結合する。
            decision_path=out/f'過去選択の全判断_W{width}_H{horizon}.npz'
            np.savez_compressed(decision_path,directions=decisions)
            for ci,config in enumerate(configurations):
                new=context.link(decisions[ci])
                for integration in ('N','U','F'):
                    selected=context.integrate(new,integration)
                    policy=f'{config["id"]}_W{width}_H{horizon}_{integration}'
                    rows.append(record(context,selected,policy,'PAST',wi,hi,
                        {'selector':config['id'],'integration':integration,'entry_mode':'過去で選ぶ',
                         'born':int(np.count_nonzero(decisions[ci])),'acquired_new':len(new.cases)}))
                    for scene_index,scene in enumerate(context.sessions):
                        subset=selected.take(context.case_scene[selected.cases]==scene_index)
                        labels=context.arrays['label'][subset.cases,subset.sides,wi,hi]
                        known=context.arrays['known'][subset.cases,subset.sides,wi,hi]
                        money=context.arrays['net'][subset.cases,subset.sides,wi,hi][known]
                        all_sessions.append({'id':policy,'session':scene,'count':len(subset.cases),
                            'F':int((labels==1).sum()),'A':int((labels==-1).sum()),'N':int((labels==0).sum()),'C':int((labels==2).sum()),
                            'profit':int(np.maximum(money,0).sum()),'loss':int(-np.minimum(money,0).sum()),'unknown':int((~known).sum()),
                            'old_count':int(subset.old.sum())})
                    reference.append({'id':policy,'cases':selected.cases.tolist(),'sides':selected.sides.tolist(),
                        'events':selected.events.tolist(),'old':selected.old.tolist()})
    assert all(sha(ROOT/p)==v for p,v in before.items())
    save(out/'過去選択の成績.json.gz',{'成功':True,'trial':162,'rows':rows,'all_sessions':all_sessions})
    save(out/'過去選択の支持.json.gz',{'成功':True,'rows':audits})
    save(out/'過去選択の取得.json.gz',{'成功':True,'rows':reference})
    ordered=sorted((r for r in rows if r['integration'] in ('F','U')),key=lambda r:(-(r['periods']['全期']['rate'] or 0),-r['periods']['全期']['count']))
    save(out/'完了.json',{'成功':True,'条件SHA256':BOOK_SHA,'Source':before,'政策数':len(rows),'支持行':len(audits),
        'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in out.iterdir() if p.is_file()}})
    print(json.dumps({'成功':True,'政策数':len(rows),'上位':[{'id':r['id'],**r['periods']['全期']} for r in ordered[:8]]},ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
