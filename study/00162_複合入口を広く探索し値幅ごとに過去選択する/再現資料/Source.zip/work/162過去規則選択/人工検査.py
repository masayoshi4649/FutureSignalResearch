"""162の規則選択を自然ラベルなしの人工集計で確認する。"""
from pathlib import Path
from decimal import Decimal, localcontext
import copy
import hashlib
import json
import math

import selector162 as selector

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
BOOK=ROOT/'study/00162_複合入口を広く探索し値幅ごとに過去選択する/条件.json'
BOOK_SHA='4f890114b789da404d400f49a5cb888e9b9014013b00fcc0f77dc6ffd691088c'


def candidate(identifier: str, group: str, forward: int=70, reverse: int=30, **changes: object) -> dict:
    """
    機能: 一貫した件数・金融を持つ人工候補を作り指定値だけを変更する。
    引数: identifier/group(str)、forward/reverse(int)、changes(dict[str,object])は上書き欄。
    返り値: dictは純選択器の人工入力。
    """
    row={'id':identifier,'group':group,'F':forward,'A':reverse,'N':0,'C':0,
        'count':forward+reverse,'scene_count':10,'scene_max_share':.2,'hours':30,
        'profit':1_000_000,'loss':400_000,'net':600_000}
    row.update(changes)
    return row


def must_reject(callable_value: object) -> None:
    """
    機能: 不正人工入力が選択へ進まずValueErrorとなることを確認する。
    引数: callable_value(object)は引数なしで実行できる関数。
    返り値: None。ValueError以外又は正常終了は検査失敗。
    """
    try:
        callable_value()
    except ValueError:
        return
    raise AssertionError('不正入力を受理した')


def decimal_wilson(forward: int, reverse: int) -> float|None:
    """
    機能: float以外の高精度演算でWilson下限を独立に計算する。
    引数: forward/reverse(int)は人工の順/逆件数。
    返り値: float又はNone。0到達は未定義。
    """
    if forward+reverse==0:
        return None
    with localcontext() as context:
        context.prec=60
        n=Decimal(forward+reverse);p=Decimal(forward)/n
        z=Decimal(str(selector.Z95));zz=z*z
        lower=(p+zz/(2*n)-z*(p*(1-p)/n+zz/(4*n*n)).sqrt())/(1+zz/n)
        return float(max(Decimal(0),lower))


# ----------------------------------------
def main() -> None:
    """
    機能: 固定8設定、支持境界、同点/群優先、重複、未知、不変性を人工検査する。
    引数: なし。正式bookは固定閾値だけ読み、自然候補・金融・採否を読み込まない。
    返り値: None。人工検査結果JSONを同フォルダへ保存する。
    """
    assert hashlib.sha256(BOOK.read_bytes()).hexdigest()==BOOK_SHA
    book=json.loads(BOOK.read_text(encoding='utf-8'))
    settings={s['id']:s for s in book['selection']['selectors']}
    basic=settings['S70_B5_K3'];tests={}
    for setting in settings.values():
        good=[candidate('TP1_ALL','TP'),candidate('MX1_ALL','MX'),candidate('BR1_ALL','BR')]
        assert len(selector.select_candidates(good,setting))==setting['top_k']
    tests['固定8設定']=8
    # ----------------------------------------
    zero=candidate('ZERO_ALL','ZERO',0,0,scene_count=0,scene_max_share=0,hours=0,profit=0,loss=0,net=0)
    result=selector.select_with_audit([zero],basic)
    assert result['selected_ids']==[] and result['unready'] and result['rows'][0]['score'] is None
    assert result['rows'][0]['forward_rate'] is None and result['rows'][0]['wilson95_lower'] is None
    assert json.loads(json.dumps(result,allow_nan=False))['rows'][0]['pf'] is None
    tests['ゼロ分母と非有限JSON不出力']=1
    # ----------------------------------------
    boundary=candidate('BOUND_ALL','B',14,6,scene_count=5,scene_max_share=.5,profit=110,loss=100,net=10)
    assert selector.select_candidates([boundary],basic)==['BOUND_ALL']
    reasons=selector.select_with_audit([candidate('SUP_ALL','S',8,4,scene_count=4,scene_max_share=.5)],basic)['rows'][0]['reasons']
    assert '取得場数不足' in reasons and '先着率不足又は未定義' in reasons
    assert selector.select_candidates([candidate('TWELVE_ALL','T',9,3,scene_count=5,scene_max_share=.5)],basic)==['TWELVE_ALL']
    assert selector.select_candidates([candidate('ELEVEN_ALL','T',8,3,scene_count=5,scene_max_share=.5)],basic)==[]
    assert selector.select_candidates([candidate('TWENTYFOUR_ALL','T',17,7,scene_count=8)],settings['S70_B8_K1'])==['TWENTYFOUR_ALL']
    assert selector.select_candidates([candidate('TWENTYTHREE_ALL','T',17,6,scene_count=8)],settings['S70_B8_K1'])==[]
    tests['支持と包含境界']=6
    # ----------------------------------------
    tied=[candidate('C_ALL','Z'),candidate('A_ALL','X'),candidate('B_ALL','Y')]
    initial=copy.deepcopy(tied)
    expected=['A_ALL','B_ALL','C_ALL']
    assert selector.select_candidates(tied,basic)==expected
    assert selector.select_candidates(tied[::-1],basic)==expected and tied==initial
    ranked=[candidate('A_ALL','X',95,5),candidate('B_ALL','X',90,10),candidate('C_ALL','Y',75,25),candidate('D_ALL','Z',70,30)]
    assert selector.select_candidates(ranked,basic)==['A_ALL','C_ALL','D_ALL']
    two_groups=ranked[:3]
    answer=selector.select_with_audit(two_groups,basic)
    assert answer['selected_ids']==['A_ALL','C_ALL','B_ALL']
    assert next(r for r in answer['rows'] if r['id']=='B_ALL')['selection_stage']==2
    tests['同点安定と群優先と同群補充']=4
    # ----------------------------------------
    duplicates=[candidate('A_ALL','X',95,5),candidate('A_EDGE','X',90,10),candidate('B_ALL','X',85,15),candidate('C_ALL','Y',75,25)]
    result=selector.select_with_audit(duplicates,basic)
    assert result['selected_ids']==['A_ALL','C_ALL','B_ALL']
    assert next(r for r in result['rows'] if r['id']=='A_EDGE')['selection_reason']=='同基底規則のALL/EDGE重複を除外'
    explicit=[candidate('fmt-one','X',95,5,base_id='REAL1'),candidate('fmt-two','X',90,10,rule_id='REAL1')]
    assert selector.select_candidates(explicit,basic)==['fmt-one']
    tests['ALLとEDGEの同基底規則重複']=2
    # ----------------------------------------
    win_only=candidate('WIN_ALL','W',20,0,loss=0,profit=100,net=100)
    row=selector.select_with_audit([win_only],basic)['rows'][0]
    assert row['eligible'] and row['pf'] is None and row['pf_state']=='損失0・利益あり'
    for row in [candidate('NET_ALL','N',profit=100,loss=100,net=0),candidate('PF_ALL','P',profit=109,loss=100,net=9),
        candidate('CONC_ALL','C',scene_max_share=.50000001)]:
        assert selector.select_candidates([row],basic)==[]
    tests['PFゼロ損失と金融集中ゲート']=4
    # ----------------------------------------
    pairs=[(0,0),(0,20),(20,0),(1,1),(14,6),(35,15),(70,30),(50,50),(7000,3000)]
    for f,a in pairs:
        actual=selector.wilson_lower(f,a);expected=decimal_wilson(f,a)
        assert actual is expected is None or actual is not None and math.isclose(actual,expected,rel_tol=1e-13,abs_tol=1e-14)
    expected=.5+.02*math.log1p(100/30)-.15*.2
    exact=selector.evaluate_metric(selector.normalize_metric(candidate('SCORE_ALL','S',50,50)),selector.validate_setting(basic))
    expected=decimal_wilson(50,50)+.02*math.log1p(100/30)-.15*.2
    assert math.isclose(exact['score'],expected,rel_tol=1e-14)
    tests['Wilson高精度とscore独立算式']=10
    # ----------------------------------------
    invalid=[]
    for key,value in [('F',True),('A',2.0),('profit',float('nan')),('hours',float('inf')),('count',99),
        ('net',1),('scene_count',101),('scene_count',0),('scene_max_share',.01),('scene_max_share',1.01),('hours',0)]:
        invalid.append(candidate('BAD_ALL','BAD',**{key:value}))
    for row in invalid:
        must_reject(lambda row=row:selector.select_candidates([row],basic))
    must_reject(lambda:selector.select_candidates([candidate('A_ALL','X'),candidate('A_ALL','X')],basic))
    must_reject(lambda:selector.select_candidates([candidate('A_ALL','X'),candidate('A_EDGE','Y')],basic))
    must_reject(lambda:selector.select_candidates([candidate('A_ALL','X',base_id='A',rule_id='B')],basic))
    for key,value in [('minimum_forward_rate',.75),('minimum_resolved',24),('id','SOME_OTHER'),('ranking','別式'),('top_k',True)]:
        bad_setting={**basic,key:value}
        must_reject(lambda b=bad_setting:selector.select_candidates([],b))
    tests['不正集計と固定条件変更の拒否']=19
    # ----------------------------------------
    class Poison:
        """未使用の未来欄へアクセスすると失敗する人工値。"""
        def __getattribute__(self,name: str) -> object:
            """
            機能: 未来欄を選択器が読んだ場合に人工検査を失敗させる。
            引数: self(Poison)、name(str)はアクセス属性。
            返り値: object。常にAssertionErrorを送出する。
            """
            raise AssertionError('未来欄へアクセスした')
    poison=candidate('SAFE_ALL','S');poison['future_labels']=Poison()
    assert selector.select_candidates([poison],basic)==['SAFE_ALL']
    tests['宣言済み集計欄だけを利用']=1
    assert hashlib.sha256(BOOK.read_bytes()).hexdigest()==BOOK_SHA
    proof={'成功':True,'試行':162,'自然データ利用':False,'条件SHA256':BOOK_SHA,
        'SourceSHA256':hashlib.sha256((HERE/'selector162.py').read_bytes()).hexdigest(),
        '検査SourceSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'検査':tests,
        '確認数':sum(tests.values()),'選択器の責務':'Rootが先に過去窓とstrict成熟で切った集計だけを評価する。'}
    (HERE/'人工検査結果.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':
    main()
