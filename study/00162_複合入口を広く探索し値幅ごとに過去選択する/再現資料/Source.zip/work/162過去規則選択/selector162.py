"""162の成熟済み過去集計だけから、固定支持条件と安定順位で規則を選ぶ。"""
from collections import Counter
from numbers import Integral, Real
import math
import re

Z95=1.959963984540054
RANKING='Wilson95下限+0.02*log1p(毎時取得)-0.15*最多場比。異なる技術群を優先。'
SETTING_NUMBERS=('minimum_forward_rate','minimum_scenes','minimum_resolved','top_k',
    'minimum_pf','minimum_known_net','maximum_scene_share')


def finite_number(value: object, name: str, minimum: float|None=None) -> float:
    """
    機能: bool・未知・非有限を除外し、指定された集計数値を有限floatへ正規化する。
    引数: value(object)、name(str)は欄名、minimum(float又はNone)は含む下限。
    返り値: floatは有限値。不正な値はValueError。
    """
    if isinstance(value,bool) or not isinstance(value,Real):
        raise ValueError(name+'は有限数値が必要')
    number=float(value)
    if not math.isfinite(number) or minimum is not None and number<minimum:
        raise ValueError(name+'は許容範囲の有限数値が必要')
    return number


def nonnegative_integer(value: object, name: str) -> int:
    """
    機能: boolを整数へ混ぜず、0以上の件数を正規化する。
    引数: value(object)は件数、name(str)は欄名。
    返り値: intは0以上。不正な値はValueError。
    """
    if isinstance(value,bool) or not isinstance(value,Integral) or value<0:
        raise ValueError(name+'は0以上の整数が必要')
    return int(value)


def validate_setting(setting: dict) -> dict:
    """
    機能: 162条件JSONの固定8設定に一致する支持・採否・順位条件だけを許可する。
    引数: setting(dict)はselection.selectorsの一要素。
    返り値: dictは固定数値の正規化コピー。入力は変更しない。
    """
    if not isinstance(setting,dict) or not all(k in setting for k in (*SETTING_NUMBERS,'id','ranking')):
        raise ValueError('固定設定の必須欄が不足')
    out={k:finite_number(setting[k],k) for k in SETTING_NUMBERS}
    if out['minimum_forward_rate'] not in (.65,.7):
        raise ValueError('先着率閾値は固定65/70のみ')
    if (out['minimum_scenes'],out['minimum_resolved']) not in ((5,12),(8,24)):
        raise ValueError('支持閾値は固定5場12到達又は8場24到達のみ')
    if out['top_k'] not in (1,3) or out['minimum_pf']!=1.1 or out['minimum_known_net']!=0 or out['maximum_scene_share']!=.5:
        raise ValueError('固定採否閾値からの変更')
    expected='S'+str(round(out['minimum_forward_rate']*100))+'_B'+str(int(out['minimum_scenes']))+'_K'+str(int(out['top_k']))
    if setting['id']!=expected or setting['ranking']!=RANKING:
        raise ValueError('設定ID又は順位式の変更')
    out['id']=expected
    for key in ('minimum_scenes','minimum_resolved','top_k'):
        out[key]=int(out[key])
    return out


# ----------------------------------------
def base_identifier(row: dict) -> str:
    """
    機能: 同じ規則のALL/EDGEを重複選択しないため基底規則IDを取り出す。
    引数: row(dict)はid/groupと任意のbase_id又はrule_idを持つ候補集計。
    返り値: strは基底規則ID。明示IDがなければ末尾のALL/EDGE区切りを除く。
    """
    values=[row[k] for k in ('base_id','rule_id') if k in row]
    if values:
        if any(not isinstance(v,str) or not v for v in values) or len(set(values))!=1:
            raise ValueError('基底規則IDが不正又は矛盾')
        return values[0]
    return re.sub(r'[/_:|.\-](ALL|EDGE)$','',row['id'])


def normalize_metric(row: dict) -> dict:
    """
    機能: 取得・先着・金融・場支持の集計間整合を検査し、必要欄だけをコピーする。
    引数: row(dict)はRootが過去窓とstrict成熟を先に適用した候補集計。
    返り値: dictは正規化済み候補。元データや時計・未来ラベルを読み込まない。
    """
    if not isinstance(row,dict) or not all(isinstance(row.get(k),str) and row[k] for k in ('id','group')):
        raise ValueError('候補ID/技術群が必要')
    out={k:row[k] for k in ('id','group')}
    out['base_id']=base_identifier(row)
    for key in ('F','A','N','C','count','scene_count'):
        out[key]=nonnegative_integer(row.get(key),key)
    if out['count']!=sum(out[k] for k in ('F','A','N','C')):
        raise ValueError('F/A/N/Cと取得数の不一致')
    if out['scene_count']>out['count'] or bool(out['scene_count'])!=bool(out['count']):
        raise ValueError('取得数と取得場数の不一致')
    for key in ('profit','loss','hours','scene_max_share'):
        out[key]=finite_number(row.get(key),key,0)
    out['net']=finite_number(row.get('net'),'net')
    if not math.isclose(out['net'],out['profit']-out['loss'],rel_tol=1e-12,abs_tol=1e-7):
        raise ValueError('利益/損失と既知差引の不一致')
    if out['scene_max_share']>1:
        raise ValueError('最多場比は0～1が必要')
    if out['count']:
        if out['hours']<=0 or out['scene_max_share']<=0:
            raise ValueError('取得がある場合は正の対象時間/最多場比が必要')
        if out['scene_max_share']+1e-12<1/out['scene_count']:
            raise ValueError('最多場比が均等配分の下限未満')
    elif out['scene_max_share']!=0 or out['profit']!=0 or out['loss']!=0:
        raise ValueError('取得0の場比/金融は0が必要')
    return out


def wilson_lower(forward: int, reverse: int) -> float|None:
    """
    機能: 到達済み順/逆だけから二側95%Wilson区間の下限を計算する。
    引数: forward/reverse(int)は0以上の順/逆件数。
    返り値: float又はNone。到達0なら未定義で、N/Cを分母へ混ぜない。
    """
    f=nonnegative_integer(forward,'F');a=nonnegative_integer(reverse,'A');n=f+a
    if not n:
        return None
    p=f/n;z2=Z95*Z95
    center=p+z2/(2*n)
    half=Z95*math.sqrt(p*(1-p)/n+z2/(4*n*n))
    return max(0.0,(center-half)/(1+z2/n))


# ----------------------------------------
def evaluate_metric(row: dict, setting: dict) -> dict:
    """
    機能: 正規化済み過去集計へ固定支持・先着率・PF・金融・集中の採否を適用する。
    引数: row(dict)はnormalize_metricの値、setting(dict)はvalidate_settingの値。
    返り値: dictは候補・score・採否理由。単独の学習窓/成熟判定は行わない。
    """
    n=row['F']+row['A'];p=row['F']/n if n else None
    lower=wilson_lower(row['F'],row['A'])
    hourly=row['count']/row['hours'] if row['hours'] else None
    if row['loss']:
        pf=row['profit']/row['loss'];pf_ok=pf>=setting['minimum_pf'];pf_state='有限'
    elif row['profit']:
        pf=None;pf_ok=True;pf_state='損失0・利益あり'
    else:
        pf=None;pf_ok=False;pf_state='利益損失とも0'
    reasons=[]
    if row['scene_count']<setting['minimum_scenes']:reasons.append('取得場数不足')
    if n<setting['minimum_resolved']:reasons.append('到達済み数不足')
    if p is None or p<setting['minimum_forward_rate']:reasons.append('先着率不足又は未定義')
    if not pf_ok:reasons.append('PF不足又は未定義')
    if row['net']<=setting['minimum_known_net']:reasons.append('既知差引は下限を超えない')
    if row['scene_max_share']>setting['maximum_scene_share']:reasons.append('最多場集中が上限を超過')
    score=lower+.02*math.log1p(hourly)-.15*row['scene_max_share'] if lower is not None and hourly is not None else None
    return {**row,'resolved':n,'forward_rate':p,'wilson95_lower':lower,'hourly_count':hourly,
        'pf':pf,'pf_state':pf_state,'score':score,'eligible':not reasons,'reasons':reasons,
        'selected':False,'selection_stage':None,'selection_reason':None}


def select_with_audit(candidate_metrics: list[dict], setting: dict) -> dict:
    """
    機能: 固定順位で異なる技術群を優先し、同基底規則のALL/EDGEを重ねず上位を選ぶ。
    引数: candidate_metrics(list[dict])はRootが過去窓/成熟で切った集計、setting(dict)は固定8設定の一つ。
    返り値: dictはselected_idsと全候補rows、採否理由数、順位条件。入力を変更せずI/Oも行わない。
    """
    config=validate_setting(setting)
    if not isinstance(candidate_metrics,list):
        raise ValueError('候補集計はlistが必要')
    normalized=[normalize_metric(row) for row in candidate_metrics]
    if len({r['id'] for r in normalized})!=len(normalized):
        raise ValueError('候補IDの重複')
    base_groups={}
    for row in normalized:
        previous=base_groups.setdefault(row['base_id'],row['group'])
        if previous!=row['group']:
            raise ValueError('同基底規則に異なる技術群')
    rows=[evaluate_metric(row,config) for row in normalized]
    ranked=sorted((r for r in rows if r['eligible']),key=lambda r:(-r['score'],r['id']))
    chosen=[];bases=set();groups=set()
    # ----------------------------------------
    # 第1段階は技術群を分散し、枠が余るときだけ同群の別規則を補充する。
    for stage in (1,2):
        for row in ranked:
            if len(chosen)>=config['top_k']:
                break
            if row['base_id'] in bases or stage==1 and row['group'] in groups:
                continue
            row['selected']=True;row['selection_stage']=stage
            row['selection_reason']='異なる技術群を優先' if stage==1 else '不足枠へ同群の別規則を補充'
            chosen.append(row['id']);bases.add(row['base_id']);groups.add(row['group'])
    for row in ranked:
        if not row['selected']:
            row['selection_reason']='同基底規則のALL/EDGE重複を除外' if row['base_id'] in bases else '選択枠外'
    reasons=Counter(reason for row in rows for reason in row['reasons'])
    return {'setting_id':config['id'],'selected_ids':chosen,'candidate_count':len(rows),
        'eligible_count':len(ranked),'selected_count':len(chosen),'unready':not chosen,
        'rejection_counts':dict(sorted(reasons.items())),'ranking':RANKING,
        'wilson_z':Z95,'tie_break':'score降順、id文字列昇順',
        'group_priority':'異群1件ずつを先に選び、不足枠のみ同群の別基底規則を順位順で補充',
        'maturity_owner':'Rootが過去20暦場とknown_at strict<当場開始を先に検査する',
        'rows':sorted(rows,key=lambda r:r['id'])}


def select_candidates(candidate_metrics: list[dict], setting: dict) -> list[str]:
    """
    機能: 固定支持・採否・群優先順位で選んだ候補IDだけを返す。
    引数: candidate_metrics(list[dict])は成熟済み過去集計、setting(dict)は162固定設定。
    返り値: list[str]は0～top_k個の候補ID。支持なしなら空配列。
    """
    return select_with_audit(candidate_metrics,setting)['selected_ids']
