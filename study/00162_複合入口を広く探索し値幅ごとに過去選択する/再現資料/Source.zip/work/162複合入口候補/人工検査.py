"""162候補の対称性と未知・境界を人工行だけで検査する。"""
from pathlib import Path
from collections import Counter
import hashlib
import json

import numpy as np
from rules162 import PreparedEvaluator,candidate_catalog,manifest

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def main() -> None:
    """
    機能: 自然データを読まず十群の全規則・幅変換・片側未知・競合を確認する。
    引数: なし。正式100列定義の名前だけを読む。
    返り値: None。候補辞書と成功票を保存する。
    """
    columns=json.loads((ROOT/'inputs/00148_全1分入口母集団/100特徴の列定義.json').read_text(encoding='utf-8'))
    names=[c['name'] for c in columns];index={n:i for i,n in enumerate(names)}
    rules=candidate_catalog();assert len(rules)==972
    assert len(set(r['id'] for r in rules))==len(rules)
    assert len({r['group'] for r in rules})==10
    rng=np.random.default_rng(162)
    buy=rng.normal(size=(137,100));sell=rng.normal(size=(137,100))
    for x in (buy,sell):
        x[:,index['q0_spread_points']]=rng.choice((0,5,10,20,25),size=137)
        x[:,index['m15_adx']]=rng.uniform(5,40,size=137)
        x[:,index['m1_volume_relative_prior3']]=rng.uniform(0,3,size=137)
    buy[0,0]=np.nan;sell[1,1]=np.nan
    original=PreparedEvaluator(buy,sell,columns,250)
    mirrored=PreparedEvaluator(sell,buy,columns,250)
    compared=0
    for candidate in rules:
        a=original.evaluate_one(candidate);b=mirrored.evaluate_one(candidate)
        assert np.array_equal(a['directions'],-b['directions'])
        assert np.array_equal(a['conflicts'],b['conflicts'])
        assert np.array_equal(a['unknown_buy'],b['unknown_sell'])
        assert np.array_equal(a['unknown_sell'],b['unknown_buy'])
        compared+=len(buy)
    # ----------------------------------------
    positive=np.zeros((1,100),dtype=np.float64)
    for name in names:
        if name.endswith('_to_side'):
            positive[0,index[name]]=1
    positive[0,index['q0_last_minus_m1_close_atr5_to_side']]=0
    positive[0,index['q0_entry_minus_ema8_atr5_to_side']]=0
    positive[0,index['q0_spread_points']]=5
    positive[0,index['m1_volume_relative_prior3']]=2
    negative=positive.copy()
    for name in names:
        if name.endswith('_to_side'):negative[0,index[name]]=-positive[0,index[name]]
    first=rules[0]
    good=PreparedEvaluator(positive,negative,columns).evaluate_one(first)
    assert good['directions'].tolist()==[1] and not good['unknown_buy'][0]
    collision=PreparedEvaluator(positive,positive,columns).evaluate_one(first)
    assert collision['directions'].tolist()==[0] and collision['conflicts'].tolist()==[True]
    missing=positive.copy();missing[0,index['m5_hist_delta_to_side']]=np.nan
    unknown=PreparedEvaluator(missing,negative,columns).evaluate_one(first)
    assert unknown['directions'].tolist()==[0] and unknown['unknown_buy'].tolist()==[True]
    zero=positive.copy();zero[0,index['m1_volume_relative_prior3']]=0
    known_zero=PreparedEvaluator(zero,negative,columns).evaluate_one(first)
    assert known_zero['directions'].tolist()==[0] and not known_zero['unknown_buy'][0]
    boundary=positive.copy();boundary[0,index['q0_spread_points']]=10
    at=PreparedEvaluator(boundary,negative,columns).evaluate_one(first)
    assert at['directions'].tolist()==[1]
    boundary[0,index['q0_spread_points']]=10.01
    over=PreparedEvaluator(boundary,negative,columns).evaluate_one(first)
    assert over['directions'].tolist()==[0] and not over['unknown_buy'][0]
    # ----------------------------------------
    positive[0,index['bb15_forward_room_125_ratio_to_side']]=1.5
    p125=PreparedEvaluator(positive,negative,columns,125)
    p250=PreparedEvaluator(positive,negative,columns,250)
    assert p125.factor(0,'bb_forward_room_target')[0].tolist()==[1.5]
    assert p250.factor(0,'bb_forward_room_target')[0].tolist()==[.75]
    for width in (0,-1,float('nan'),float('inf'),True):
        try:PreparedEvaluator(positive,negative,columns,width)
        except (AssertionError,TypeError):pass
        else:raise AssertionError('不正幅を受理')
    infinity=positive.copy();infinity[0,0]=np.inf
    try:PreparedEvaluator(infinity,negative,columns)
    except AssertionError:pass
    else:raise AssertionError('infを受理')
    # ----------------------------------------
    body=manifest()
    manifest_path=HERE/'候補辞書.json'
    manifest_path.write_text(json.dumps(body,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    proof={'成功':True,'自然X読取':False,'取得と金融読取':False,'候補数':len(rules),
        '群別数':dict(Counter(r['group'] for r in rules)),'全規則鏡像行比較':compared,
        '確認':['片側成立','買売配列交換で全方向符号反転','両側成立は競合待機','NaNは未知別記',
            '0は既知不成立','spread境界等号/超過','125比から250対象幅への余地換算',
            '不正幅拒否','無限大拒否','全規則3技法以上'],
        'SHA256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (HERE/'rules162.py',Path(__file__),manifest_path)}}
    (HERE/'人工検査結果.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':
    main()
