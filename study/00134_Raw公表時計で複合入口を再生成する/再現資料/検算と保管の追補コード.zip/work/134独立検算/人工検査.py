"""独立算術の既知touch/不足分母/費用/Last金額なしを人工検査する。自然JSONは開かない。"""
import importlib.util
from pathlib import Path
import unittest

spec=importlib.util.spec_from_file_location('independent134',Path(__file__).with_name('検算する.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


def candidate(side: int=1, axis: str='BBO', sign: int=1, status: str='complete') -> dict:
    """
    機能: 25pt到達だけを持つ人工候補を作る。
    引数: side(int)、axis(str)、sign(int)、status(str)は向き・軸・到達・全H状態。
    返り値: dictは人工取得と観測。
    """
    price=105 if axis=='Last' else 110 if side>0 else 100
    mark=price+side*sign*25
    bid=mark-5 if axis=='Last' else mark if side>0 else mark-10
    ask=bid+10;last=mark if axis=='Last' else (bid+ask)/2
    q={'time':200,'index':2,'source_line':3,'bid':bid,'ask':ask,'last':last,'quote_ok':True}
    outcomes=[{'seconds':h,'status':status,'touches':[{'width':25,'direction':sign,'quote':q if sign else None}],
               'endpoint':q if status=='complete' else None} for h in (1800,3600)]
    return {'birth':{'side':side},'entry_price':price,'outcomes':outcomes}


def record(sign: int=1, status: str='complete') -> dict:
    """
    機能: N0の単一人工取得を正逆/Last候補にまとめる。
    引数: sign(int)、status(str)はN0の到達と全H状態。
    返り値: dictは実データを使わない集計票。
    """
    return {'session':'人工','meta':{'model':'instant','source_side':1,'selected_side':1},
            'case':{'original_side':1,'original':candidate(1,'BBO',sign,status),
                    'reverse':candidate(-1,'BBO',-sign,status),'chart_original':candidate(1,'Last',sign,status),
                    'chart_reverse':candidate(-1,'Last',-sign,status)}}


class Tests(unittest.TestCase):
    """4主人工で本検算とは別の期待数値を確認する。"""
    def test_cost_and_pf_from_bbo(self):
        """
        機能: 買Bid清算と費用を固定数値で照合する。
        引数: self(Tests)。返り値: None。
        """
        rows=[record(1),record(-1)];s=m.stats(rows,'N0','BBO',3600,25)
        self.assertEqual((s['forward'],s['adverse'],s['resolved_rate']),(1,1,.5))
        self.assertEqual((s['ifd_net0_sum'],s['ifd_net5_profit'],s['ifd_net5_loss'],s['ifd_net5_sum']),(-154,1423,3577,-2154))
        self.assertAlmostEqual(s['ifd_net5_pf'],1423/3577)

    def test_known_touch_does_not_complete_H(self):
        """
        機能: H不足の既知touchをIFDへ残しても先着率分母へ入れない。
        引数: self(Tests)。返り値: None。
        """
        s=m.stats([record(1,'gap_censored')],'N0','BBO',3600,25)
        self.assertEqual((s['complete'],s['censored'],s['forward'],s['ifd_known'],s['ifd_net5_sum']),(0,1,0,1,1423))
        self.assertIsNone(s['resolved_rate'])
        c=candidate(1,'BBO',0,'gap_censored');e=m.ifd(c,3600,25,'BBO')
        self.assertFalse(e['known']);self.assertIsNone(e['net5'])

    def test_Last_money_nil_and_actual_reverse(self):
        """
        機能: Last参考へ費用後金額を作らず、逆は保存した逆側を選ぶ。
        引数: self(Tests)。返り値: None。
        """
        r=record(1)
        s=m.stats([r],'N0','Last',3600,25)
        self.assertEqual(s['forward'],1);self.assertIsNone(s['ifd_net5_sum']);self.assertIsNone(s['ifd_net5_profit'])
        r['case']['reverse']=candidate(-1,'BBO',-1)
        self.assertIs(m.choose(r,'R0','BBO'),r['case']['reverse'])
        self.assertEqual(m.stats([r],'R0','BBO',3600,25)['adverse'],1)

    def test_zero_group_unknown_and_typed_values(self):
        """
        機能: 0件・未知・既知0・bool型を分ける。
        引数: self(Tests)。返り値: None。
        """
        s=m.stats([],'N0','BBO',3600,25)
        self.assertEqual(s['entries'],0);self.assertIsNone(s['resolved_rate']);self.assertIsNone(s['ifd_net5_sum'])
        self.assertIsNone(m.number({'x':{'known':False,'value':0}},'x'))
        self.assertEqual(m.number({'x':{'known':True,'value':0}},'x'),0)
        with self.assertRaises(AssertionError):m.equal(0,False)


if __name__=='__main__':unittest.main()
