"""134の公表置換2入力を既存gzipとmetadataへ独立照合する。Raw/Source/金融は実行しない。"""
import copy
import gzip
import hashlib
import json
import math
from collections import Counter
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
OWN=ROOT/'work/P3をRaw公表時計で再生成する準備'


def sha(path: Path) -> str:
    """
    機能: SHA256を計算する。
    引数: path(Path)は対象。
    返り値: strは小文字16進SHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical(value: object) -> str:
    """
    機能: 型を保持したキー整列JSONの指紋を計算する。
    引数: value(object)はJSON可能値。
    返り値: strは正規化SHA256。非有限値は拒否する。
    """
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf-8')).hexdigest()


def invariant(publication: dict) -> str:
    """
    機能: 128のdelay.goが変更すると宣言した配送属性だけを除いて同値を確認する。
    引数: publication(dict)は即時又は遅延公表。
    返り値: strはOHLC/量/Technical/DMI/構造/raw_quality等の同体指紋。
    """
    p=copy.deepcopy(publication)
    for key in ('stamp','model','causal_close_stamp'):p.pop(key,None)
    f=p['frame']['frame']
    for key in ('nominal_available','available_at','delivery_at','record_ordinal'):f.pop(key)
    return canonical(p)


def same_metadata(actual: object, expected: object) -> bool:
    """
    機能: Goの数値型で同じ値となるmetadataを比較し、boolと未知の型は分ける。
    引数: actual/expected(object)は128由来と共用124のmetadata。
    返り値: boolは同体。JSONの整数/小数表記差だけは許可する。
    """
    if isinstance(expected,dict):
        return isinstance(actual,dict) and actual.keys()==expected.keys() and all(same_metadata(actual[k],v) for k,v in expected.items())
    if isinstance(expected,list):
        return isinstance(actual,list) and len(actual)==len(expected) and all(same_metadata(a,b) for a,b in zip(actual,expected))
    if type(expected) in (int,float):return type(actual) in (int,float) and math.isfinite(actual) and actual==expected
    return type(actual) is type(expected) and actual==expected


def check_scene(scene: dict, metadata: dict) -> Counter:
    """
    機能: 当場の公表scope/時計/採用行/順序を独立検査する。
    引数: scene/metadata(dict)は生成入力と共用場定義。
    返り値: Counterは足幅別件数。原板の時系列を新しく探索しない。
    """
    previous=None;ids=set();widths=Counter();end_at_stamp={}
    for p in scene['publications']:
        f=p['frame']['frame'];q=p['stamp'];width=f['width_seconds']
        assert width in (300,900,1800) and f['id'] and f['id'] not in ids
        ids.add(f['id']);widths[width]+=1
        assert f['session_id']==metadata['session'] and f['contract']==metadata['contract']
        assert metadata['start']<=f['start']<=f['end']<=metadata['end']
        assert f['end']-f['start']==width
        assert f['end']<=f['available_at']<=f['delivery_at']<=q['time']
        assert metadata['start']<=q['time']<=metadata['end']
        assert 0<=q['index']<metadata['expected_accepted'] and 1<=q['source_line']<=metadata['expected_quality']['lines']
        assert f['record_ordinal']==q['index']+1 and f['observed_at']<=q['time']
        stamp=(q['time'],q['index'],q['source_line'])
        if previous is not None:
            assert all(a>=b for a,b in zip(stamp,previous))
            if stamp[1]==previous[1]:assert stamp==previous
            else:assert stamp[2]>previous[2]
        previous=stamp
        # 同Raw・同Endの公表順は5→15→30。別Endまで無理に並べ替えない。
        key=(stamp,f['end']);prior=end_at_stamp.get(key)
        if prior is not None:assert prior<width
        end_at_stamp[key]=width
    return widths


def main() -> None:
    """
    機能: Root生成2入力の全metadata/公表同体と即時遅延の共通値・15EOF落ちを照合する。
    引数: なし。指定された既生成JSON/gzipと凍結コードだけを読む。
    返り値: None。独立確認JSONを新規保存する。Raw・新Source・金融は生成しない。
    """
    paths={
        OWN/'即時のSource入力.json':'905cab946d67e368633585219fc9f4fa04efab639104dcecdc6a3d01d18eeb01',
        OWN/'遅延60秒のSource入力.json':'8cc73c58fcf90968d177913bfdf66bdcacb3a98aa6ca1a787a35ad9301349139',
        ROOT/'work/128全場のRaw公表/gap300.json.gz':'e382858a62865b321449279d9653f5b1c644c97f6c4254cbae8dd9d3ea065e62',
        ROOT/'work/128全場のRaw公表/gap300_delay60.json.gz':'ce2add7e0a01fd1ab31c0510194b4647144c01034701f548253c307f6334c830',
        OWN/'入力を変換する.py':'2f159d05e555538818455722637b2b20501748c21d523f781b80abf003889c00',
        ROOT/'work/強い入口の探索期限を延ばす次仮説/Source入口の再生器/Source入口.exe':'e6d216ffbbc9ec8d640d5d482d163de3ac289c1f46392469abb9d66eb47a905e'}
    assert all(sha(p)==h for p,h in paths.items())
    metadata_path=ROOT/'inputs/00124_同入口正逆の共用入力/入力.json.gz'
    metadata_bytes=gzip.decompress(metadata_path.read_bytes())
    metadata_sha='b2368b1f42c16e8c96a3acd098c58a902807a3b6a5023d6d4b1e75261f3ee51b'
    assert hashlib.sha256(metadata_bytes).hexdigest()==metadata_sha
    base=json.loads(metadata_bytes);assert len(base['scenes'])==73
    metadata_compressed_sha=sha(metadata_path)
    keys=('session','contract','start','end','force_close','raw','expected_accepted','expected_quality')
    immediate_values={};immediate_clocks={};missing_immediate=set();common=0;clock_changes=0;dropped=[];model_proofs={}
    for model,input_path,original_path,expected_count in (
        ('即時',list(paths)[0],list(paths)[2],12809),('遅延60秒',list(paths)[1],list(paths)[3],12794)):
        target=json.loads(input_path.read_text(encoding='utf-8-sig'))
        original=json.loads(gzip.decompress(original_path.read_bytes()))
        assert original['success'] and len(target['scenes'])==len(original['scenes'])==73
        assert original['model']['carry_policy']=='validated-same-contract' and original['model']['max_gap_seconds']==300
        widths=Counter();pub_count=0;previous=None;scenes=[]
        for b,s,o in zip(base['scenes'],target['scenes'],original['scenes']):
            projected={k:b[k] for k in keys}
            assert canonical({k:s[k] for k in keys})==canonical(projected)
            assert set(s)==set(keys)|{'publications'}
            assert o['session']==b['session'] and o['contract']==b['contract']
            for key in keys:
                if key!='raw':assert same_metadata(o[key],b[key]),(model,b['session'],key)
            assert all(o['raw'][k]==b['raw'][k] for k in ('path','sha256'))
            assert o['counts']==b['expected_quality']
            assert canonical(s['publications'])==canonical(o['publications'])
            widths.update(check_scene(s,b));pub_count+=len(s['publications'])
            carry=o.get('carry_from','')
            expected_carry=previous['session'] if previous and previous['contract']==b['contract'] else ''
            assert carry==expected_carry,(model,b['session'],'carry')
            previous=b
            for p in s['publications']:
                f=p['frame']['frame'];identity=(b['session'],f['id']);stamp=p['stamp']
                if model=='即時':
                    assert f['nominal_available']==f['available_at']==f['end']
                    assert f['observed_at']==f['delivery_at']==stamp['time']
                    immediate_values[identity]=invariant(p)
                    immediate_clocks[identity]={'stamp':stamp,'end':f['end'],'width':f['width_seconds']}
                    missing_immediate.add(identity)
                else:
                    assert identity in immediate_values
                    assert invariant(p)==immediate_values[identity],identity
                    first=immediate_clocks[identity];eligible=max(first['end']+60,first['stamp']['time'])
                    assert p['causal_close_stamp']==first['stamp']
                    assert f['nominal_available']==f['end']+60 and f['available_at']==eligible
                    assert f['observed_at']==first['stamp']['time'] and f['delivery_at']==stamp['time']>=eligible
                    assert all(stamp[k]>=first['stamp'][k] for k in ('time','index','source_line'))
                    clock_changes+=stamp!=first['stamp'];common+=1;missing_immediate.remove(identity)
            if model=='遅延60秒':
                for item in o['eof_undelivered']:
                    key=(b['session'],item['id']);assert key in immediate_values
                    first=immediate_clocks[key]
                    assert item['end']==first['end'] and item['closed_at']==first['stamp']
                    assert item['eligible_at']==max(first['end']+60,first['stamp']['time'])
                    dropped.append({'session':b['session'],**item,'width_seconds':first['width']})
            scenes.append({'session':b['session'],'publications':len(s['publications']),
                           'raw_metadata_and_quality_equal':True,'carry_from':carry})
        assert pub_count==expected_count
        model_proofs[model]={'sessions':73,'publications':pub_count,'width_counts':dict(widths),
                            'all_publications_exact_original':True,'all_metadata_equal_common124':True,'scenes':scenes}
        del target,original
    assert common==12794 and len(missing_immediate)==len(dropped)==15
    assert missing_immediate=={(d['session'],d['id']) for d in dropped}
    assert all(d['width_seconds']==300 for d in dropped)
    assert all(sha(p)==h for p,h in paths.items()) and sha(metadata_path)==metadata_compressed_sha
    proof={'success':True,'scope':'134の入力JSON同体・metadata・配送時計だけの独立確認',
           'input_and_source_hashes_before_after_equal':True,'files':{str(p.relative_to(ROOT)):h for p,h in paths.items()},
           'metadata_gzip_sha256':metadata_compressed_sha,'metadata_decompressed_sha256':metadata_sha,
           'models':model_proofs,'common_foot_value_count':common,'common_foot_values_identical':True,
           'delivery_stamp_changed_count':clock_changes,'immediate_only_foot_count':15,'EOF_dropped':dropped,
           'EOF_drop_only_5min':True,'same_frame_IDs_and_observed_at_preserved':True,
           'native_Source_type_validation':'別担当のoverlay検査へ分離',
           'BB15_RVOL_delivered_window_may_differ_due_to_EOF':True,'price_volume_warmup_not_only_latency':True,
           'raw_read':False,'new_Source_scan':False,'financial_read_or_calculation':False,
           'Source_executable_rebuilt_or_edited':False,'code_sha256':sha(Path(__file__))}
    out=HERE/'入力の独立確認.json';assert not out.exists()
    out.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'success':True,'proof_sha256':sha(out),'common_foot_values':common,
                      'delivery_stamp_changed':clock_changes,'EOF_5min_missing':15},ensure_ascii=False))


if __name__=='__main__':main()
