"""134の新入力を一度保存し、133コードと共有資料は参照して重複を避ける。"""
from pathlib import Path
import gzip
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
FORMAL = ROOT / 'study/00134_Raw公表時計で複合入口を再生成する'
RUN = ROOT / 'work/134公表時計の評価'
INPUTS = ROOT / 'inputs/00134_Raw公表時計の共用入力'


def sha(body: bytes) -> str:
    """
    機能: 内容のSHA256を返す。
    引数: body(bytes)。
    返り値: str。
    """
    return hashlib.sha256(body).hexdigest()


# ----------------------------------------
def put(path: Path, body: bytes) -> None:
    """
    機能: 未作成の正式先へ原文bytesを保存する。
    引数: path(Path)、body(bytes)。
    返り値: None。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as handle:
        handle.write(body)


# ----------------------------------------
def packed(source: Path, target: Path, expected: str) -> dict:
    """
    機能: 固定JSONを一度gzip化して、保存/解凍指紋を記録する。
    引数: source/target(Path)、expected(str)。
    返り値: dictは保存先・復元先・形式・サイズ・指紋。
    """
    body = source.read_bytes(); assert sha(body) == expected
    encoded = gzip.compress(body, mtime=0); assert gzip.decompress(encoded) == body
    put(target, encoded)
    return {'保存元': target.relative_to(ROOT).as_posix(), '復元先': source.relative_to(ROOT).as_posix(),
            '形式': 'gzip', '保存bytes': len(encoded), '保存SHA256': sha(encoded),
            '解凍bytes': len(body), '解凍SHA256': sha(body)}


# ----------------------------------------
def reference(source: str, target: str, form: str, expected: str) -> dict:
    """
    機能: 既存恒久資源を複写せず、解凍/同体SHAを照合して参照登録する。
    引数: source/target/form/expected(str)。
    返り値: dictは共有参照。
    """
    body = (ROOT / source).read_bytes()
    decoded = gzip.decompress(body) if form == 'gzip' else body
    assert sha(decoded) == expected
    return {'保存元': source, '復元先': target, '形式': form,
            '保存SHA256': sha(body), '解凍SHA256': sha(decoded)}


# ----------------------------------------
def main() -> None:
    """
    機能: 新Source2・固定入力/方向・結果を保管し、既存133源と巨大入力を複製しない。
    引数: なし。
    返り値: None。83/84MB入力やRaw本文を読まず、新しい金融も実行しない。
    """
    assert (FORMAL / '検査/実行前文書.json.gz').is_file()
    f1 = json.loads((RUN / 'F1.json').read_bytes())
    previous = json.loads((ROOT / 'study/00133_全場参加を維持して強い入口の探索期限を延ばす/保管索引.json').read_bytes())
    inputs = [
        packed(RUN / 'instantのSource出生.json', INPUTS / 'instantのSource出生.json.gz', '9137c2adb4aec58d7de37a5ca725b933b618ba0f72669477f6ebd265c92ead1e'),
        packed(RUN / 'delayのSource出生.json', INPUTS / 'delayのSource出生.json.gz', '9aa496ff2e0d8a3ef238abf494c0a53b89d968cebbab1b12eec9cac9c21ce4b8'),
        packed(RUN / '固定入力/固定取得入力.json', INPUTS / '固定取得入力.json.gz', '5dafeceae9fe87c98e7d487f924f96c56d817cf00bc5a4a96379cb7377d2c526'),
        packed(RUN / '固定入力/方向と出生.json', INPUTS / '方向と出生.json.gz', '5f3442a81ce06916a94bb433f48befe5ec4cca6bec7154db18aa17cf1b2e1eb4'),
    ]
    observed = RUN / '固定取得の正逆観測.json'
    financial = packed(observed, FORMAL / '成果物/固定取得の正逆観測.json.gz', sha(observed.read_bytes()))
    aggregate = (ROOT / 'work/134公表時計別の集計/集計.json').read_bytes()
    assert sha(aggregate) == 'ac497334c10b7fc5ab3c90bcc82bfb5bc488a5c9e75bfc2cd6ee32d686d2d0f0'
    put(FORMAL / '成果物/集計.json', aggregate)
    specs = [
        ('inputs/00124_同入口正逆の共用入力/入力.json.gz', 'inputs/00124_同入口正逆の共用入力/入力.json.gz', '同体'),
        ('inputs/00133_探索期限延長の共用入力/Sourceの出生と取得.json.gz', 'work/133探索期限の評価/Sourceの出生と取得.json', 'gzip'),
        ('study/00124_逆行の原因と売買反転を同じ入口で検証する/成果物/全73場の正逆結果.json.gz', 'work/124入口の正逆比較/全73場の正逆結果.json', 'gzip'),
        ('study/00131_中期MACDの位相で複合入口の方向を切り替える/成果物/集計.json', 'work/131既存入口の位相切替評価/集計.json', '同体'),
        ('study/00133_全場参加を維持して強い入口の探索期限を延ばす/成果物/集計.json', 'work/133期限別の集計/集計.json', '同体'),
        ('study/00133_全場参加を維持して強い入口の探索期限を延ばす/検査/Sourceの準備確認.json', 'work/強い入口の探索期限を延ばす次仮説/準備の確認.json', '同体'),
        ('study/00133_全場参加を維持して強い入口の探索期限を延ばす/根拠/正逆器の準備/124からの由来.json', 'work/133固定取得の正逆評価器/124からの由来.json', '同体'),
        ('study/00133_全場参加を維持して強い入口の探索期限を延ばす/根拠/正逆器の準備/準備の確認.json', 'work/133固定取得の正逆評価器/準備の確認.json', '同体'),
    ]
    shared = [reference(source, target, form, f1['ファイル'][str(ROOT / target)]) for source, target, form in specs]
    taken = {x['復元先'] for x in inputs + shared}
    small = []
    for name, expected in f1['ファイル'].items():
        path = Path(name); relative = path.relative_to(ROOT).as_posix()
        if path.suffix != '.json' or relative in taken or path.stat().st_size > 10_000_000:
            continue
        body = path.read_bytes(); assert sha(body) == expected
        target = FORMAL / '検査/固定JSON' / (relative.replace('/', '／'))
        put(target, body)
        small.append({'保存元': target.relative_to(ROOT).as_posix(), '復元先': relative,
                      '形式': '同体', '保存SHA256': expected, '解凍SHA256': expected})
    for name in ('出生段階の完了.json', '正逆観測の完了.json', '金融段階の完了.json'):
        source = RUN / name
        if not any(x['復元先'] == source.relative_to(ROOT).as_posix() for x in small):
            put(FORMAL / '検査' / name, source.read_bytes())
    put(FORMAL / '検査/集計完了.json', (ROOT / 'work/134公表時計別の集計/集計完了.json').read_bytes())
    old_code = previous['固定コード']
    old_archive = ROOT / 'study/00133_全場参加を維持して強い入口の探索期限を延ばす/再現資料' / old_code['ZIP']
    assert sha(old_archive.read_bytes()) == old_code['ZIP_SHA256']
    old_items = {x['path']: x for x in old_code['格納源']}
    reused, fresh = [], []
    for name, expected in f1['ファイル'].items():
        path = Path(name); relative = path.relative_to(ROOT).as_posix()
        if path.suffix not in ('.go', '.mod', '.py', '.md'):
            continue
        assert sha(path.read_bytes()) == expected
        if relative in old_items and old_items[relative]['sha256'] == expected:
            reused.append(old_items[relative])
        else:
            fresh.append({'path': relative, 'bytes': path.stat().st_size, 'sha256': expected})
    archive = FORMAL / '再現資料/134追加固定コード.zip'
    archive.parent.mkdir(exist_ok=True)
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for item in fresh:
            z.writestr(item['path'], (ROOT / item['path']).read_bytes())
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for item in fresh:
            assert sha(z.read(item['path'])) == item['sha256']
    external = [{'path': Path(name).relative_to(ROOT).as_posix(), 'sha256': expected,
                 'bytes': Path(name).stat().st_size, '理由': '巨大派生入力は変換コード/128由来から再生成' if Path(name).suffix == '.json' else '凍結133実行物再用。実行体は複製せず再ビルド/元SHAを参照'}
                for name, expected in f1['ファイル'].items()
                if Path(name).suffix == '.exe' or Path(name).stat().st_size > 10_000_000]
    assert len(external) == 4 and len(reused) == 63 and len(fresh) == 15
    value = {'試行': 134, 'Sourceと後段engine試行': 133, '再ビルドして評価': False,
             '新共用入力': inputs, '新正逆観測': financial, '集計SHA256': sha(aggregate),
             '共有参照': shared, '小型段階証跡': small,
             '共有固定コード': {'保存元ZIP': old_archive.relative_to(ROOT).as_posix(), 'ZIP_SHA256': old_code['ZIP_SHA256'], '格納源数': len(reused), '格納源': reused},
             '追加固定コード': {'ZIP': archive.name, 'ZIP_SHA256': sha(archive.read_bytes()), 'ZIP_bytes': archive.stat().st_size, '格納源数': len(fresh), '格納源': fresh},
             '意図して複製しない固定源': external,
             '公表再生成の参照': {'正式128手順': 'study/00128_Raw価格時計で構造回復の出生を比較する/再現資料/再現手順.md',
                                '即時gzipSHA': 'e382858a62865b321449279d9653f5b1c644c97f6c4254cbae8dd9d3ea065e62',
                                '遅延gzipSHA': 'ce2add7e0a01fd1ab31c0510194b4647144c01034701f548253c307f6334c830'},
             '巨大派生入力本文読取': False, 'Raw複製/再走査': False, '新金融計算': False}
    put(FORMAL / '保管索引.json', (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    put(INPUTS / '指紋.json', (json.dumps({'試行': 134, '共用入力': inputs}, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    print(json.dumps({'成功': True, '追加固定コード': len(fresh), '既存133参照コード': len(reused),
                      '新共用gzip': len(inputs), '共用gzipbytes': sum(x['保存bytes'] for x in inputs),
                      '正逆観測gzipbytes': financial['保存bytes'], '追加ZIP_SHA256': value['追加固定コード']['ZIP_SHA256']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
