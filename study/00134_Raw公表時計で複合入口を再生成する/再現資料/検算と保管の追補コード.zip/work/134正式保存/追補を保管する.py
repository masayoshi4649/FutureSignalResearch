"""134の停止済み独立検算・CSV・事後監査を、F0/F1源とは別に最小保存する。"""
from pathlib import Path
import gzip
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
FORMAL = ROOT / 'study/00134_Raw公表時計で複合入口を再生成する'
OUTPUT = ROOT / 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/134公表時計CSV'


def sha(body: bytes) -> str:
    """
    機能: 保存内容の指紋を返す。
    引数: body(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


# ----------------------------------------
def copy(source: Path, destination: Path) -> None:
    """
    機能: 停止済み証跡を未作成の正式先へ同体保存する。
    引数: source/destination(Path)。
    返り値: None。
    """
    assert not destination.exists(), destination
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open('xb') as handle:
        handle.write(source.read_bytes())


# ----------------------------------------
def main() -> None:
    """
    機能: 独立証跡・事後監査・結果後の再現補助を原固定コードと分けて保管する。
    引数: なし。
    返り値: None。Raw/巨大派生入力を読まず、新条件の金融・CSV生成をしない。
    """
    independent = ROOT / 'work/134独立検算'
    assert sha((independent / '独立確認.json').read_bytes()) == '05c1f50c728ca5513b752f99a54897871151179bbedbff119d7708c91a1466df'
    for source, target in [
        (independent / '独立確認.json', FORMAL / '検査/独立確認.json'),
        (independent / '完了.json', FORMAL / '検査/独立検算の完了.json'),
        (ROOT / 'work/134公表時計CSV出力/CSV再読の確認.json', FORMAL / '検査/CSV独立再読.json'),
        (OUTPUT / 'CSVの確認.json', FORMAL / '検査/CSVの確認.json'),
        (ROOT / 'work/CSVとRawの足定義を監査する/監査結果.md', FORMAL / '根拠/足定義の監査.md'),
        (ROOT / 'work/CSVとRawの足定義を監査する/監査の確認.json', FORMAL / '根拠/足定義の監査.json'),
    ]:
        copy(source, target)
    formation_path = ROOT / 'work/CSV足とRaw足の形成差を確認する/同終端の形成差.json'
    formation = formation_path.read_bytes()
    assert sha(formation) == '614040bf85aa2d57df5c727eddefae679ce7e4e97eec864dbfdaa87b0edad6da'
    archive_formation = FORMAL / '根拠/同終端の形成差.json.gz'
    with archive_formation.open('xb') as handle:
        handle.write(gzip.compress(formation, compresslevel=9, mtime=0))
    extras = [ROOT / 'work/134公表置換の独立準備レビュー', ROOT / 'work/134Source接続の独立確認']
    for source in extras:
        for p in sorted(source.glob('*.json')):
            copy(p, FORMAL / '検査/金融前準備' / source.name / p.name)
    (FORMAL / '検査/独立検算.md').write_text('''# 134の独立検算

[数値正本](独立確認.json)と[停止票](独立検算の完了.json)を同体保存した。Root集計器・124算術をimportせず、保存BBO/Last QuoteからFractionで独立再計算した。全300条件、26,662表セル、旧C0の120条件・79取得・3,160のH幅観測、phase940stream/1,720endpoint/7,072touchが一致した。人工4成功。bootstrapの再実装はしていない。

三modelは全73場へ参加し、主N0は24順32逆未15不足7、42.857%。C5利益337,382円・損失502,080円・既知差引−164,698円。実CSV転記は[別の再読](CSV独立再読.json)で全26,662セル/13,975数値を検査した。

金融前の[入力置換検査](金融前準備/134公表置換の独立準備レビュー/入力の独立確認.json)と[Source接続検査](金融前準備/134Source接続の独立確認/接続の独立確認.json)を分ける。各確認コード・元README・人工コードは[後発ZIP](../再現資料/検算と保管の追補コード.zip)へ同体保管した。これらは結果後に保管した資源であり、新しい事前F0/F1ではない。
''', encoding='utf-8')
    (FORMAL / '根拠/事後の足形成診断.md').write_text('''# CSVとRawの足形成を事後に照合する

134の金融結果を得た後の原因診断であり、事前選択根拠ではない。[足定義の監査](足定義の監査.md)・[コード監査証跡](足定義の監査.json)と、保存済み公表を比べた[同終端の形成差JSON](同終端の形成差.json.gz)を残す。監査のSHAは373e0fa4d8feadb03bd7803efff25d7d36e5f194f79cf8855c3e6dd2d00eb216、形成差JSONの解凍SHAは614040bf85aa2d57df5c727eddefae679ce7e4e97eec864dbfdaa87b0edad6da。

研究122の直接入力は5分CSVであり、各5/15/30分のOHLCからその尺度の指標を再計算していた。収集器は受信時計で1分を進め、既に閉じた分の遅着を捨て、その1分を5分へまとめる。Rawの保存コードは受信時刻を付加せず、価格更新時刻だけからこの処理を完全には再現できない。サンプル2行のキー確認を全原板スキーマの証明へ拡大しない。価格更新の間隔だけで、価格が変わらない場合と受信欠測を識別できない。

保存公表はCSV12,794/Raw即時12,809で、共通End12,794、Rawのみ15。両側で価格既知の5分8,477件中、OHLC全同体8,408件・差69件。15分は2,784件中同体2,744件・差40件。30分は1,348件中同体1,344件・差4件。価格・量の既知性、履歴本数、EMA/RSI/ATR/MACDの数値にも差がある。同終端の大半が近くても、閾値境界・seed・欠測を通じて出生が変わり得る。

これらの差が134の損益悪化をどれだけ説明するかは未検証。入力形成・公表時刻・warmup・指標窓を一要因ずつ分離した比較が必要であり、旧CSVの68.42%をリアルタイムの性能と扱わない。次の同じ出生での非金融比較は134とは別作業とする。
''', encoding='utf-8')
    files = list(independent.glob('*.py')) + [independent / 'README.md']
    files += sorted((ROOT / 'work/134公表時計CSV出力').glob('*.py')) + sorted((ROOT / 'work/134公表時計CSV出力').glob('*.mjs'))
    files += [FORMAL / '再現資料/保存資料を復元する.py', FORMAL / '再現資料/保管を確認する.py']
    files += sorted((ROOT / 'work/134正式保存').glob('*.py'))
    for folder in extras:
        files += [p for p in folder.iterdir() if p.suffix in ('.py', '.md')]
    folder = ROOT / 'work/CSVとRawの足定義を監査する'
    files += [p for p in folder.iterdir() if p.suffix in ('.py', '.go', '.mod', '.jsonl')]
    files += [ROOT / 'work/CSV足とRaw足の形成差を確認する/比較する.py']
    index = []
    archive = FORMAL / '再現資料/検算と保管の追補コード.zip'
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in sorted(set(files)):
            name = p.relative_to(ROOT).as_posix(); body = p.read_bytes()
            z.writestr(name, body)
            index.append({'path': name, 'bytes': len(body), 'sha256': sha(body),
                          '区分': '結果後に保管した検算/閲覧/再現/監査資源。F0/F1源とは別'})
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for item in index:
            assert sha(z.read(item['path'])) == item['sha256']
    manifest_path = FORMAL / '保管索引.json'; manifest = json.loads(manifest_path.read_bytes())
    manifest['後発コード'] = {'ZIP': archive.name, 'ZIP_SHA256': sha(archive.read_bytes()),
                            'ZIP_bytes': archive.stat().st_size, '格納源数': len(index), '格納源': index}
    manifest['事後形成差'] = {'保存元': archive_formation.relative_to(ROOT).as_posix(),
                            '保存SHA256': sha(archive_formation.read_bytes()), '解凍SHA256': sha(formation)}
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '後発コード源': len(index), 'ZIP_SHA256': manifest['後発コード']['ZIP_SHA256'],
                      '独立条件': 300, '独立表セル': 26662, '新金融実行': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
