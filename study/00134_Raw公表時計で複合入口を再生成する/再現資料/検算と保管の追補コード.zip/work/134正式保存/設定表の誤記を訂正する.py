"""134の金融完了後に、指標行と足幅の文書誤記だけを固定源へ照合して訂正する。"""
from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[2]
FORMAL = ROOT / 'study/00134_Raw公表時計で複合入口を再生成する'


def sha(body: bytes) -> str:
    """
    機能: 訂正前後と固定コードの指紋を返す。
    引数: body(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


# ----------------------------------------
def cells(text: str) -> dict:
    """
    機能: 指標IDごとに版6の9尺度セルを抽出する。
    引数: text(str)。
    返り値: dictは56手法と504セル。
    """
    out = {}
    for line in text.splitlines():
        if re.match(r'^\| [A-Z][0-9]{2} ', line):
            p = [x.strip() for x in line.split('|')[1:-1]]
            if len(p) == 11:
                out[p[0]] = p[2:]
    assert len(out) == 56
    return out


# ----------------------------------------
def main() -> None:
    """
    機能: F1照合済みコードを根拠に誤記を直し、原文との差を全504セルで記録する。
    引数: なし。
    返り値: None。旧試行/F0/F1/生成コード/金融結果を変更しない。
    """
    proof_path = FORMAL / '検査/設定表の文書訂正.json'
    assert not proof_path.exists()
    frozen = json.loads((FORMAL / '検査/F1.json').read_bytes())['ファイル']
    sources = ['work/121入口の反転切替/policies.go', 'work/121入口の反転切替/detector.go',
               'work/強い入口の探索期限を延ばす次仮説/Source入口の再生器/score.go',
               'work/134正式文書を準備する.py']
    evidence = []
    for name in sources:
        body = (ROOT / name).read_bytes()
        assert sha(body) == frozen[str(ROOT / name)]
        evidence.append({'path': name, 'sha256': sha(body)})
    path = FORMAL / '設定と結果.md'
    before_body = path.read_bytes()
    changes = {
        'I04': {1: '未設定・未検証', 3: 'S02：元P3の5分RSI水準/増分。E0の1分RSIは用いない'},
        'I08': {3: 'S02：元P3の5分DI差/ADX低下', 4: 'S02：元P3の15分DI差',
                5: 'S02：元P3の30分DI差、E0のADX既知低下'},
        'I09': {1: 'S02：E0の前14本1分TR平均、当TR<=2倍（当足除外）',
                3: 'S02：元P3値幅/T8正規化、E0のcap/最大riskにATR5'},
        'I10': {3: '未設定・未検証', 5: '未設定・未検証'},
    }
    lines = before_body.decode('utf-8').splitlines()
    for i, line in enumerate(lines):
        if not re.match(r'^\| [A-Z][0-9]{2} ', line):
            continue
        p = [x.strip() for x in line.split('|')[1:-1]]
        if len(p) == 11 and p[0] in changes:
            for index, value in changes[p[0]].items():
                p[index + 2] = value
            lines[i] = '| ' + ' | '.join(p) + ' |'
    text = '\n'.join(lines) + '\n'
    text += '\n## 金融完了後の文書訂正\n\nDMI・ADXの設定をSAR行に置いた生成時の誤記をI08へ訂正した。I04の1分RSI表記を削除し、I09は実在する前14本1分TR平均と5分ATRによるcap/riskを区別した。E0は15分RSI位置、30分ADX低下、1分構造回復を使い、5分RSIの増分を必須条件にはしない。P3は5/15/30分DI差を方向票に使う。実行条件・閾値・出生・金融結果は不変。原文は[実行前退避](検査/実行前文書.json.gz)、全504セルの文書差分は[訂正証跡](検査/設定表の文書訂正.json)に残す。\n'
    snapshot = json.loads(gzip.decompress((FORMAL / '検査/実行前文書.json.gz').read_bytes()))
    original = next(x['本文'] for x in snapshot['文書'] if x['path'].endswith('/設定と結果.md'))
    old = cells(original); new = cells(text)
    scales = ['原板・逐次', '1分', '3分', '5分', '15分', '30分', '60分', 'セッション足', '日足']
    diff = [{'ID': name, '足幅': scales[i], '退避原文': a, '文書訂正後': b}
            for name in old for i, (a, b) in enumerate(zip(old[name], new[name])) if a != b]
    assert len(diff) == 9
    path.write_text(text, encoding='utf-8')
    proof = {'成功': True, '試行': 134, '訂正UTC': datetime.now(timezone.utc).isoformat(),
             '金融完了後の文書訂正': True, 'F0_F1原文と生成コード保持': True,
             '実行条件変更': False, '新しい金融実行': False, '出生変更': False,
             '根拠はF1と同体のコード': evidence, '確認セル数': 504, '文書差分セル数': len(diff),
             '文書差分': diff, 'その他495セル不変': True,
             '訂正直前MD_SHA256': sha(before_body), '訂正後MD_SHA256': sha(path.read_bytes()),
             '注意': 'I09の1分ATRは実在する品質ゲートであり、1分欄を未使用にはしない。5分ATRと役割を分けて記述。',
             'コードSHA256': sha(Path(__file__).read_bytes())}
    proof_path.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '文書差分セル': len(diff), '条件変更': False,
                      '証跡SHA256': sha(proof_path.read_bytes())}, ensure_ascii=False))


if __name__ == '__main__':
    main()
