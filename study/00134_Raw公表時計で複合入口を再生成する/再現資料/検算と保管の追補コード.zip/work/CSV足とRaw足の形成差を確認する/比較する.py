"""金融結果を使わず、同一場・足幅・足終端でCSV/Raw公表値を比較する。"""
from pathlib import Path
from collections import Counter, defaultdict
import hashlib
import json
import statistics

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
INPUTS = {
    'CSV': (ROOT / 'work/122全場入力/入力.json', '6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec'),
    'Raw': (ROOT / 'work/P3をRaw公表時計で再生成する準備/即時のSource入力.json', '905cab946d67e368633585219fc9f4fa04efab639104dcecdc6a3d01d18eeb01'),
}


def sha(path: Path) -> str:
    """
    機能: ファイル全体の指紋を求める。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def compact(path: Path, expected: str) -> dict:
    """
    機能: 公表からOHLC・指標と既知maskだけを同場/同幅/同Endで索引化する。
    引数: path(Path)、expected(str)。
    返り値: dictは小型比較用の公表。価格経路/金融/原板を開かない。
    """
    assert sha(path) == expected
    data = json.loads(path.read_text('utf-8')); assert len(data['scenes']) == 73
    result = {}
    for scene in data['scenes']:
        for publication in scene['publications']:
            frame = publication['frame']; bar = frame['frame']; tech = bar['technical']
            key = (scene['session'], bar['width_seconds'], bar['end'])
            assert key not in result
            result[key] = {'start': bar['start'], 'price_known': bar['price_known'], 'ohlc': bar['ohlc'],
                           'volume_known': bar['volume_known'], 'volume': bar['volume'],
                           'history_bars': tech['history_bars'], 'technical': tech, 'dmi': frame['dmi']}
    assert sha(path) == expected
    return result


# ----------------------------------------
def summary(values: list[float]) -> dict:
    """
    機能: 差の符号と大きさを記述統計にする。
    引数: values(list[float])はCSV−Raw。
    返り値: dictは件数・一致・平均絶対差・中央値・最大絶対差。
    """
    return {'比較数': len(values), '完全一致': sum(v == 0 for v in values),
            '差中央値_CSV_Raw': statistics.median(values) if values else None,
            '平均絶対差': statistics.fmean(abs(v) for v in values) if values else None,
            '最大絶対差': max(map(abs, values), default=None)}


# ----------------------------------------
def main() -> None:
    """
    機能: 同終端の価格・数値・既知差を全件比較し、事後原因診断として保存する。
    引数: なし。
    返り値: None。方向の新選択、勝率、新金融は計算しない。
    """
    frames = {name: compact(path, expected) for name, (path, expected) in INPUTS.items()}
    common = sorted(set(frames['CSV']) & set(frames['Raw']))
    groups = {}
    for width in (300, 900, 1800):
        keys = [k for k in common if k[1] == width]
        counters = Counter(); numeric = defaultdict(list); known = defaultdict(Counter)
        samples = []
        for key in keys:
            a, b = frames['CSV'][key], frames['Raw'][key]
            assert a['start'] == b['start']
            counters['全件'] += 1
            counters[f"price_known_CSV{a['price_known']}_Raw{b['price_known']}"] += 1
            if a['price_known'] and b['price_known']:
                equal = a['ohlc'] == b['ohlc']; counters['OHLC全値同体'] += equal
                for field in ('open', 'high', 'low', 'close'):
                    numeric[field].append(a['ohlc'][field] - b['ohlc'][field])
                if not equal and len(samples) < 3:
                    samples.append({'セッション': key[0], 'End': key[2], 'CSV': a['ohlc'], 'Raw': b['ohlc']})
            numeric['history_bars'].append(a['history_bars'] - b['history_bars'])
            for section, fields in (('technical', ('ema8', 'ema21', 'ema8_delta', 'ema21_delta', 'atr', 'rsi', 'histogram')),
                                    ('dmi', ('plus_di', 'minus_di', 'adx'))):
                for field in fields:
                    x, y = a[section][field], b[section][field]
                    known[field][f"CSV{x['known']}_Raw{y['known']}"] += 1
                    if x['known'] and y['known']:
                        numeric[field].append(x['value'] - y['value'])
            counters[f"volume_known_CSV{a['volume_known']}_Raw{b['volume_known']}"] += 1
            if a['volume_known'] and b['volume_known']:
                numeric['volume'].append(a['volume'] - b['volume'])
        groups[str(width)] = {'件数': dict(counters), '差': {k: summary(v) for k, v in numeric.items()},
                              '指標既知の組': {k: dict(v) for k, v in known.items()}, 'OHLC差の例': samples}
    output = {'成功': True, '事後の原因診断': True, '根拠': {k: str(p) for k, (p, _) in INPUTS.items()},
              '入力SHA256': {k: h for k, (_, h) in INPUTS.items()},
              '公表数': {k: len(v) for k, v in frames.items()}, '共通End数': len(common),
              'CSVだけ': len(set(frames['CSV']) - set(frames['Raw'])),
              'Rawだけ': len(set(frames['Raw']) - set(frames['CSV'])), '足幅別': groups,
              '原板読取': False, '金融結果読取': False, '新しい閾値選択': False,
              '限界': '同じラベルの終端でも生成時刻定義/価格種/取込範囲/seedが同体とは限らない。差を直ちにバグとしない',
              'コードSHA256': sha(Path(__file__))}
    with (OWN / '同終端の形成差.json').open('x', encoding='utf-8', newline='\n') as handle:
        json.dump(output, handle, ensure_ascii=False, indent=2); handle.write('\n')
    for width, group in groups.items():
        print(width, group['件数'], {k: group['差'].get(k) for k in ('close', 'ema21', 'histogram')}, flush=True)


if __name__ == '__main__':
    main()
