"""ローカル定義と小さい人工だけを監査し、自然金融・原板全走査を行わない。"""

from pathlib import Path
from collections import Counter
import gzip
import hashlib
import json
import os
import re
import subprocess

OWN = Path(__file__).resolve().parent
ROOT = OWN.parent.parent
COLLECTOR = ROOT.parent / 'kabus-controller'
PLAN = ROOT / 'work/122全場入力/公表生成計画.json'


# ----------------------------------------
def ref(path: Path) -> dict:
    """
    機能: コードと台帳だけの全ファイル指紋を得る。
    引数: path(Path)。返り値: dict。
    """
    return {'path': Path(os.path.relpath(path, ROOT)).as_posix(), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


# ----------------------------------------
def clock_keys(value: object, prefix: str = '') -> list[str]:
    """
    機能: 価格値を保存せず時刻らしいキーの階層だけを返す。
    引数: value(object)、prefix(str)。返り値: list[str]。
    """
    result = []
    if isinstance(value, dict):
        for key, child in value.items():
            at = prefix + '/' + key
            if re.search('time|stamp|received|receive', key, re.I):
                result.append(at)
            result.extend(clock_keys(child, at))
    elif isinstance(value, list):
        for child in value:
            result.extend(clock_keys(child, prefix + '/*'))
    return result


# ----------------------------------------
def main() -> None:
    """
    機能: 小型人工、限定CSV行と許可済みRaw先頭キーを証跡化する。
    引数: なし。返り値: None。Source・金融・全原板走査を呼ばない。
    """
    sources = [COLLECTOR / name for name in ('future_history_candles.go', 'future_history_candles_test.go',
                'future_history_store.go', 'future_history_archive.go', 'option_history_code.go', 'docs/future-history.md')]
    sources += [ROOT / name for name in ('work/三時間軸の市場入力口/candle.go', 'work/三時間軸の公開器/bank.go',
                'work/三時間軸の公開器/numeric.go', 'work/三時間軸の公開器/pivot.go',
                'work/115三時間軸と方向性の公開/bank.go', 'work/115三時間軸と方向性の公開/numeric.go',
                'work/122公表生成/export.go', 'work/122公表生成/plan.go')]
    sources += [PLAN, OWN / '監査結果.md', OWN / '足定義の人工検査_test.go', OWN / 'go.mod', Path(__file__).resolve()]
    before = [ref(p) for p in sources]
    for name in ('future_history_candles.go', 'future_history_candles_test.go'):
        assert (OWN / name).read_bytes() == (COLLECTOR / name).read_bytes()
    plan = json.loads(PLAN.read_bytes())
    history = plan['history']
    assert len(history) == 73 and all(Path(s['csv']['path']).name == 'candle_5min.csv' for s in history)
    result = subprocess.run(['go', 'test', '-count=1', '-json', '.'], cwd=OWN,
                            capture_output=True, text=True, encoding='utf-8', check=False)
    (OWN / '人工検査のログ.jsonl').write_text(result.stdout, encoding='utf-8')
    events = [json.loads(line) for line in result.stdout.splitlines() if line.startswith('{')]
    passed = [e['Test'] for e in events if e.get('Action') == 'pass' and e.get('Test')]
    assert result.returncode == 0 and len(passed) == 10 and not any(e.get('Action') in ('fail', 'skip') for e in events), result.stderr
    csv_samples = []
    for name in ('candle_1min.csv', 'candle_5min.csv'):
        path = ROOT.parent / 'JP_OSE_Data/future/NK225/2026-09-21_Day' / name
        stat = path.stat()
        with path.open('r', encoding='utf-8-sig') as handle:
            lines = [handle.readline().rstrip('\n') for _ in range(4)]
        after = path.stat()
        assert (stat.st_size, stat.st_mtime_ns) == (after.st_size, after.st_mtime_ns)
        csv_samples.append({'path': str(path), 'read_lines': 4, 'header_and_first3': lines,
                            'full_file_sha_recomputed': False})
    raw_keys = []
    for sid in ('2026-09-21_Day', '2026-11-09_Day'):
        path = ROOT.parent / 'JP_OSE_Data/future/NK225' / sid / 'book.jsonl.gz'
        stat = path.stat()
        with gzip.open(path, 'rb') as handle:
            line = handle.readline()
        value = json.loads(line)
        after = path.stat()
        assert (stat.st_size, stat.st_mtime_ns) == (after.st_size, after.st_mtime_ns)
        raw_keys.append({'session': sid, 'path': str(path), 'physical_lines_read': 1,
                         'top_keys': list(value), 'clock_key_paths': clock_keys(value),
                         'first_line_sha256': hashlib.sha256(line).hexdigest(), 'values_saved': False,
                         'full_file_sha_recomputed': False})
    head = subprocess.check_output(['git', '-C', str(COLLECTOR), 'rev-parse', 'HEAD'], text=True).strip()
    diff = subprocess.check_output(['git', '-C', str(COLLECTOR), 'diff',
        '0317c1e16a43542b45f814a81489a641b6df7a5f', 'HEAD', '--', 'future_history_candles.go'], text=True)
    assert head == '7a38c505db71644ff32d936538e7625e74d4f685' and not diff
    assert before == [ref(p) for p in sources]
    proof = {'成功': True, '対象': 'CSV形成定義だけ。134金融とは別監査', '実装と台帳の前後指紋': before,
             '収集器コピー同体': True, '人工成功': passed, '人工群数': len(passed),
             'CSV直接入力': '全73件candle_5min.csv', '台帳限月別場数': dict(Counter(s['contract'] for s in history)),
             '収集器HEAD': head, '初回実装コミットからの価格形成コード差分': False,
             '各日のサーバ稼働版の証明': False, '限定CSV行': csv_samples, '限定Rawキー': raw_keys,
             '全原板走査': False, '原板本文の読取範囲': '指定2ファイル各先頭1物理行。キーだけ保存',
             '新金融読取と再計算': False, 'Source本体変更': False, '正式資料変更': False,
             '無約定と受信欠測の実件数判定': False,
             '実行ログ': ref(OWN / '人工検査のログ.jsonl')}
    destination = OWN / '監査の確認.json'
    destination.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'success': True, 'proof_sha256': ref(destination)['sha256'], 'tests': len(passed)}, ensure_ascii=True))


if __name__ == '__main__':
    main()
