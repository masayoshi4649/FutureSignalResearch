package main

import (
	"math"
	"reflect"
	"strings"
	"testing"
	"time"

	frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
)

// ----------------------------------------
// TestAuditMinuteBoundary は、開始ラベルと分境界を越えた遅着の扱いを検査します。
//
// 引数: t(*testing.T)。返り値: なし。人工価格だけで現行生成コードを呼びます。
func TestAuditMinuteBoundary(t *testing.T) {
	start := historyCandleTestTime(t, "2026-09-21T08:45:00+09:00")
	c := newFutureHistoryCandles(start, start.Add(time.Hour))
	c.Apply(historyCandleTestQuote(start.Add(59*time.Second), 100, 10), start.Add(59*time.Second))
	if !c.minute.Time.Equal(start) {
		t.Fatal("足ラベルが開始時刻でない")
	}
	c.Apply(historyCandleTestQuote(start.Add(59*time.Second), 500, 11), start.Add(61*time.Second))
	if c.minuteExists || c.five.High != 100 {
		t.Fatal("前分への遅着を取り込んだ")
	}
	c.Apply(historyCandleTestQuote(start.Add(61*time.Second), 101, 12), start.Add(61*time.Second))
	c.Apply(historyCandleTestQuote(start.Add(59*time.Second), 600, 13), start.Add(62*time.Second))
	c.Advance(start.Add(5 * time.Minute))
	if c.five.High != 101 || c.five.Close != 101 || !c.five.Time.Equal(start) || !c.five.Closed {
		t.Fatal("遅着価格またはラベルの解釈差")
	}
}

// ----------------------------------------
// TestAuditSparseFive は、欠けた分を補完せず存在する分だけで5分足を作ることを検査します。
//
// 引数: t(*testing.T)。返り値: なし。2本だけの1分足から5分が確定します。
func TestAuditSparseFive(t *testing.T) {
	start := historyCandleTestTime(t, "2026-09-21T08:45:00+09:00")
	c := newFutureHistoryCandles(start, start.Add(time.Hour))
	c.Apply(historyCandleTestQuote(start, 100, 10), start)
	c.Apply(historyCandleTestQuote(start.Add(4*time.Minute), 104, 20), start.Add(4*time.Minute))
	c.Advance(start.Add(5 * time.Minute))
	if c.minuteIndex != 1 || c.five.Open != 100 || c.five.Close != 104 || !c.five.Closed {
		t.Fatal("疎な1分足の5分合成定義が変化")
	}
}

// ----------------------------------------
// auditChildren は、指標を解析的に確かめられる等差価格の人工5分足を作ります。
//
// 引数: なし。返り値: frame.Session/[]frame.ChildBarは原板を参照しません。
func auditChildren() (frame.Session, []frame.ChildBar) {
	s := frame.Session{ID: "人工前場", Contract: "人工限月", Start: 300000, End: 363300, EOF: 363300}
	bars := []frame.ChildBar{}
	for i := 0; i < 210; i++ {
		close := 100 + float64(i)
		start := s.Start + float64(i*300)
		bars = append(bars, frame.ChildBar{Start: start, End: start + 300,
			OHLC:   frame.OHLC{Open: close - 1, High: close + 1, Low: close - 1, Close: close},
			Volume: 1, Closed: true, VolumeKnown: true,
			Input: frame.FileRef{Path: "人工.csv", SHA256: strings.Repeat("a", 64), Bytes: 1}, Row: uint64(i + 2)})
	}
	return s, bars
}

// ----------------------------------------
// TestAuditIndependentScalesAndSeeds は、各尺度の期間・初期SMA・未知・限月別種を検査します。
//
// 引数: t(*testing.T)。返り値: なし。線形価格のEMAは終値から尺度別の解析的遅れになります。
func TestAuditIndependentScalesAndSeeds(t *testing.T) {
	s, bars := auditChildren()
	b, err := frame.BeginSession(s, bars, nil)
	if err != nil {
		t.Fatal(err)
	}
	pubs, err := b.AdvanceObserved(s.End, 1)
	if err != nil {
		t.Fatal(err)
	}
	seen := map[int]int{}
	for _, p := range pubs {
		x := p.Technical
		n := int(x.HistoryBars)
		seen[p.WidthSeconds]++
		if x.EMA8.Known != (n >= 8) || x.EMA21.Known != (n >= 21) || x.RSI.Known != (n >= 15) || x.Histogram.Known != (n >= 34) {
			t.Fatalf("初期化に必要な足数が違う: 幅%d 足%d %+v", p.WidthSeconds, n, x)
		}
		step := float64(p.WidthSeconds) / 300
		if x.EMA21.Known && math.Abs(x.EMA21.Value-(p.OHLC.Close-10*step)) > 1e-9 {
			t.Fatal("尺度ごとの21期間EMAでない")
		}
		if x.EMA8.Known && math.Abs(x.EMA8.Value-(p.OHLC.Close-3.5*step)) > 1e-9 {
			t.Fatal("尺度ごとの8期間EMAでない")
		}
		if x.RSI.Known && x.RSI.Value != 100 {
			t.Fatal("単調上昇のRSIが100でない")
		}
		if x.Histogram.Known && math.Abs(x.Histogram.Value) > 1e-9 {
			t.Fatal("等差価格のMACD差が解析値0と違う")
		}
	}
	if !reflect.DeepEqual(seen, map[int]int{300: 210, 900: 70, 1800: 35}) {
		t.Fatal("各尺度を独立に作っていない")
	}
	seed, _, err := b.Seal()
	if err != nil {
		t.Fatal(err)
	}
	for _, contract := range []string{s.Contract, "別限月"} {
		next := frame.Session{ID: "人工後場", Contract: contract, Start: 363600, End: 367200, EOF: 367200}
		bank, err := frame.BeginSession(next, nil, &seed)
		if err != nil {
			t.Fatal(err)
		}
		snap, err := bank.SnapshotAt(next.Start)
		if err != nil {
			t.Fatal(err)
		}
		for _, scale := range snap.Scales {
			if scale.HasCurrent || scale.SeedTechnical.EMA21.Known != (contract == s.Contract) || scale.SeedOnly != (contract == s.Contract) {
				t.Fatal("数値種を当場足や異限月へ混同")
			}
		}
	}
}

// ----------------------------------------
// TestAuditFutureIndependence は、後の子足が先の公表値へ混ざらないことを検査します。
//
// 引数: t(*testing.T)。返り値: なし。先読み済みCSV全体と、各公表時点の数値更新を分けます。
func TestAuditFutureIndependence(t *testing.T) {
	s, a := auditChildren()
	z := append([]frame.ChildBar(nil), a...)
	z[209].OHLC = frame.OHLC{Open: 99999, High: 99999, Low: 99999, Close: 99999}
	left, err := frame.BeginSession(s, a, nil)
	if err != nil {
		t.Fatal(err)
	}
	right, err := frame.BeginSession(s, z, nil)
	if err != nil {
		t.Fatal(err)
	}
	if early, err := left.AdvanceObserved(s.Start+359, 1); err != nil || len(early) != 0 {
		t.Fatalf("公表前に利用した: %+v %v", early, err)
	}
	x, ex := left.AdvanceObserved(s.Start+360, 2)
	y, ey := right.AdvanceObserved(s.Start+360, 1)
	if ex != nil || ey != nil || len(x) != 1 || len(y) != 1 || x[0].OHLC != y[0].OHLC || x[0].Technical != y[0].Technical {
		t.Fatal("後の価格を先の公表へ利用")
	}
}
