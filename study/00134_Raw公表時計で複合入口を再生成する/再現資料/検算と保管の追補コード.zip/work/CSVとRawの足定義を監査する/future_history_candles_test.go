package main

import (
	"math"
	"testing"
	"time"
)

// historyCandleTestTime は、テスト日時を日本時間で解析します。
//
// 引数:
//   - t *testing.T: テストの実行状態。
//   - text string: 時差を含む日時文字列。
//
// 返り値:
//   - time.Time: 解析した日時。
func historyCandleTestTime(t *testing.T, text string) time.Time {
	t.Helper()
	value, err := time.Parse(time.RFC3339Nano, text)
	if err != nil {
		t.Fatalf("テスト日時を解析できません: %v", err)
	}
	return value
}

// historyCandleTestQuote は、価格と出来高が同時刻の受信値を作成します。
//
// 引数:
//   - at time.Time: 価格と出来高の観測日時。
//   - price float64: 現在値。
//   - volume float64: 累積出来高。
//
// 返り値:
//   - futureHistoryQuote: テスト用受信値。
func historyCandleTestQuote(at time.Time, price, volume float64) futureHistoryQuote {
	return futureHistoryQuote{
		Symbol: "167120018", CurrentPrice: &price, CurrentPriceTime: at.Format(time.RFC3339Nano),
		TradingVolume: &volume, TradingVolumeTime: at.Format(time.RFC3339Nano),
	}
}

// TestFutureHistoryCandlesSameSecond は、同秒の価格変化と累積出来高の差分を取り込みます。
//
// 引数:
//   - t *testing.T: テストの実行状態。
//
// 返り値:
//   - なし。
func TestFutureHistoryCandlesSameSecond(t *testing.T) {
	start := historyCandleTestTime(t, "2026-09-21T08:45:00+09:00")
	candles := newFutureHistoryCandles(start, start.Add(7*time.Hour))
	previous := historyCandleTestQuote(start.Add(-3*time.Hour), 999, 100)
	if updates := candles.Apply(previous, start.Add(-time.Minute)); len(updates) != 0 {
		t.Fatalf("前立会の価格から足を作りました: %+v", updates)
	}
	for _, sample := range []struct{ price, volume float64 }{{100, 110}, {102, 115}, {102, 117}, {102, 117}, {98, 120}, {101, 125}} {
		candles.Apply(historyCandleTestQuote(start, sample.price, sample.volume), start)
	}
	actual := candles.minute
	if actual.Open != 100 || actual.High != 102 || actual.Low != 98 || actual.Close != 101 || actual.Volume != 25 || !actual.VolumeComplete || actual.Closed {
		t.Fatalf("同秒の価格変動または出来高が不正です: %+v", actual)
	}
	if candles.minuteIndex != 0 || candles.fiveIndex != 0 || candles.five.Volume != 25 {
		t.Fatalf("同じ足の更新で連番または五分足が増えました: %+v", candles)
	}
}

// TestFutureHistoryCandlesInitialAndResetVolume は、途中起動と出来高リセットを再基準化します。
//
// 引数:
//   - t *testing.T: テストの実行状態。
//
// 返り値:
//   - なし。
func TestFutureHistoryCandlesInitialAndResetVolume(t *testing.T) {
	start := historyCandleTestTime(t, "2026-09-21T08:45:00+09:00")
	candles := newFutureHistoryCandles(start, start.Add(7*time.Hour))
	initial := start.Add(12 * time.Minute)
	candles.Apply(historyCandleTestQuote(initial, 100, 8000), initial)
	if candles.minute.Volume != 0 || candles.minute.VolumeComplete {
		t.Fatalf("途中起動時の累積全量を計上しました: %+v", candles.minute)
	}
	candles.Apply(historyCandleTestQuote(initial.Add(time.Second), 102, 8004), initial.Add(time.Second))
	if candles.minute.Volume != 4 || candles.minute.VolumeComplete {
		t.Fatalf("基準取得後の差分が不正です: %+v", candles.minute)
	}

	// ----------------------------------------
	// 次の分は既知の基準から始まり、減少時だけ不完全になります。
	next := initial.Add(time.Minute)
	candles.Apply(historyCandleTestQuote(next, 101, 8010), next)
	if candles.minute.Volume != 6 || !candles.minute.VolumeComplete {
		t.Fatalf("次の分へ出来高基準を引き継げませんでした: %+v", candles.minute)
	}
	candles.Apply(historyCandleTestQuote(next.Add(time.Second), 103, 2), next.Add(time.Second))
	candles.Apply(historyCandleTestQuote(next.Add(2*time.Second), 102, 5), next.Add(2*time.Second))
	if candles.minute.Volume != 9 || candles.minute.VolumeComplete {
		t.Fatalf("出来高のリセットを正しく扱えませんでした: %+v", candles.minute)
	}
}

// TestFutureHistoryCandlesLateData は、確定した足を遅着で訂正しないことを確認します。
//
// 引数:
//   - t *testing.T: テストの実行状態。
//
// 返り値:
//   - なし。
func TestFutureHistoryCandlesLateData(t *testing.T) {
	start := historyCandleTestTime(t, "2026-09-21T08:45:00+09:00")
	candles := newFutureHistoryCandles(start, start.Add(7*time.Hour))
	candles.Apply(historyCandleTestQuote(start.Add(-time.Minute), 999, 100), start.Add(-time.Second))
	candles.Apply(historyCandleTestQuote(start.Add(10*time.Second), 100, 110), start.Add(10*time.Second))
	closed := candles.Advance(start.Add(time.Minute))
	if len(closed) != 2 || !closed[0].Candle.Closed || closed[0].Candle.Volume != 10 {
		t.Fatalf("一分足が確定しませんでした: %+v", closed)
	}
	late := historyCandleTestQuote(start.Add(59*time.Second), 999, 120)
	if updates := candles.Apply(late, start.Add(time.Minute)); len(updates) != 0 {
		t.Fatalf("前の分の遅着価格から足を作りました: %+v", updates)
	}
	fresh := start.Add(time.Minute + time.Second)
	candles.Apply(historyCandleTestQuote(fresh, 101, 123), fresh)
	if candles.minute.Open != 101 || candles.minute.High != 101 || candles.minute.Volume != 3 || candles.minuteIndex != 1 {
		t.Fatalf("遅着分を次の足へ加算しました: %+v", candles.minute)
	}
	if candles.five.High != 101 || candles.five.Volume != 13 {
		t.Fatalf("五分足へ遅着を反映しました: %+v", candles.five)
	}
	if closed[0].Candle.High != 100 || closed[0].Candle.Volume != 10 {
		t.Fatalf("公開済みの足が変更されました: %+v", closed[0].Candle)
	}

	// ----------------------------------------
	// 同じ分でも時刻が逆行する値は終値と出来高基準を巻き戻しません。
	candles.Apply(historyCandleTestQuote(start.Add(time.Minute), 900, 10), fresh)
	if candles.minute.High != 101 || candles.minute.Volume != 3 {
		t.Fatalf("古い観測値を反映しました: %+v", candles.minute)
	}
}

// TestFutureHistoryCandlesFiveMinutesAndEmptyGap は、五分足を一分足だけから集計します。
//
// 引数:
//   - t *testing.T: テストの実行状態。
//
// 返り値:
//   - なし。
func TestFutureHistoryCandlesFiveMinutesAndEmptyGap(t *testing.T) {
	start := historyCandleTestTime(t, "2026-09-21T17:00:00+09:00")
	candles := newFutureHistoryCandles(start, start.Add(13*time.Hour))
	candles.Apply(historyCandleTestQuote(start.Add(-time.Minute), 900, 100), start.Add(-time.Second))
	for _, sample := range []struct {
		minute        int
		price, volume float64
	}{{0, 100, 102}, {1, 103, 105}, {3, 98, 109}, {4, 102, 111}} {
		at := start.Add(time.Duration(sample.minute) * time.Minute)
		candles.Apply(historyCandleTestQuote(at, sample.price, sample.volume), at)
	}
	actual := candles.five
	if actual.Open != 100 || actual.High != 103 || actual.Low != 98 || actual.Close != 102 || actual.Volume != 11 || !actual.VolumeComplete || actual.Closed {
		t.Fatalf("五分足の集計が不正です: %+v", actual)
	}
	if candles.minuteIndex != 3 {
		t.Fatalf("空の分に足を作りました: %d", candles.minuteIndex)
	}
	updates := candles.Advance(start.Add(5 * time.Minute))
	if len(updates) != 2 || !updates[0].Candle.Closed || !updates[1].Candle.Closed {
		t.Fatalf("時間経過だけで足が確定しませんでした: %+v", updates)
	}
	if repeated := candles.Advance(start.Add(10 * time.Minute)); len(repeated) != 0 {
		t.Fatalf("空の期間に更新を生成しました: %+v", repeated)
	}
	lateStart := start.Add(12 * time.Minute)
	candles.Apply(historyCandleTestQuote(lateStart, 110, 112), lateStart)
	if candles.minuteIndex != 4 || candles.fiveIndex != 1 || !candles.five.Time.Equal(start.Add(10*time.Minute)) || candles.five.Open != 110 || candles.five.Volume != 1 {
		t.Fatalf("空白後の足に前の五分足が混ざりました: %+v", candles.five)
	}
}

// TestFutureHistoryCandlesSeparateTimes は、価格と出来高の観測日時を別に判定します。
//
// 引数:
//   - t *testing.T: テストの実行状態。
//
// 返り値:
//   - なし。
func TestFutureHistoryCandlesSeparateTimes(t *testing.T) {
	start := historyCandleTestTime(t, "2026-09-21T08:45:00+09:00")
	candles := newFutureHistoryCandles(start, start.Add(7*time.Hour))
	candles.Apply(historyCandleTestQuote(start.Add(-time.Minute), 999, 100), start.Add(-time.Second))
	volumeOnly := historyCandleTestQuote(start.Add(10*time.Second), 999, 104)
	volumeOnly.CurrentPriceTime = start.Add(-time.Hour).Format(time.RFC3339Nano)
	if updates := candles.Apply(volumeOnly, start.Add(10*time.Second)); len(updates) != 0 {
		t.Fatalf("前立会価格で出来高だけの足を作りました: %+v", updates)
	}
	at := start.Add(11 * time.Second)
	candles.Apply(historyCandleTestQuote(at, 100, 106), at)
	if candles.minute.Volume != 6 || candles.minute.Open != 100 {
		t.Fatalf("同じ分の価格観測前の出来高を失いました: %+v", candles.minute)
	}
	priceOnly := historyCandleTestQuote(at.Add(time.Second), 102, 1)
	priceOnly.TradingVolumeTime = "不正な日時"
	candles.Apply(priceOnly, at.Add(time.Second))
	if candles.minute.High != 102 || candles.minute.Volume != 6 {
		t.Fatalf("価格と出来高の日時を独立して処理できませんでした: %+v", candles.minute)
	}
}

// TestFutureHistoryCandlesInvalidAndClosing は、不正値と立会の最終境界を確認します。
//
// 引数:
//   - t *testing.T: テストの実行状態。
//
// 返り値:
//   - なし。
func TestFutureHistoryCandlesInvalidAndClosing(t *testing.T) {
	start := historyCandleTestTime(t, "2026-09-21T08:45:00+09:00")
	end := start.Add(7 * time.Hour)
	candles := newFutureHistoryCandles(start, end)
	for _, price := range []float64{0, -1, math.NaN(), math.Inf(1)} {
		if updates := candles.Apply(historyCandleTestQuote(start, price, 0), start); len(updates) != 0 {
			t.Fatalf("無効な価格で足を作りました: %+v", updates)
		}
	}
	last := end.Add(-time.Second)
	candles.Apply(historyCandleTestQuote(last, 100, 5), last)
	updates := candles.Apply(historyCandleTestQuote(end, 105, 8), end)
	if !candles.minute.Time.Equal(end.Add(-time.Minute)) || candles.minute.Close != 105 || candles.minute.Volume != 8 || !candles.minute.Closed || !candles.five.Closed {
		t.Fatalf("最終境界を最終の足に含められませんでした: %+v", candles.minute)
	}
	if len(updates) == 0 || updates[len(updates)-1].Interval != 5 || !updates[len(updates)-1].Candle.Closed {
		t.Fatalf("最終の確定更新がありません: %+v", updates)
	}
	if late := candles.Apply(historyCandleTestQuote(end, 999, 20), end.Add(time.Second)); len(late) != 0 || candles.minute.Close != 105 {
		t.Fatalf("立会後に確定足を訂正しました: %+v", late)
	}
}
