module candledefinitionaudit

go 1.24.2

require github.com/masayoshi4649/SessionTradeExecuter/threeframe v0.0.0

replace github.com/masayoshi4649/SessionTradeExecuter/threeframe => ../三時間軸の公開器
