"""134の235票を3つのSource結果へ非金融で独立接続確認する。Raw/金融は開かない。"""
import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def sha(path: Path) -> str:
    """
    機能: SHA256を求める。
    引数: path(Path)は対象。
    返り値: strは小文字16進SHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: native L0だけの全235票・73場参加・固定方向・期限・Source強条件を照合する。
    引数: なし。Root指定のSource/metadata/固定取得と旧133票だけを読む。
    返り値: None。新規独立proofを保存する。Sourceや金融は実行しない。
    """
    refs={
        'instant':('work/134公表時計の評価/instantのSource出生.json','9137c2adb4aec58d7de37a5ca725b933b618ba0f72669477f6ebd265c92ead1e'),
        'delay':('work/134公表時計の評価/delayのSource出生.json','9aa496ff2e0d8a3ef238abf494c0a53b89d968cebbab1b12eec9cac9c21ce4b8'),
        'csv':('work/133探索期限の評価/Sourceの出生と取得.json','4c9449b620c15a63c00f9810eeaa52fc8f0eb5f92f7ea2d124cc9db12cc728f6'),
        'metadata':('work/134公表時計の評価/固定入力/方向と出生.json','5f3442a81ce06916a94bb433f48befe5ec4cca6bec7154db18aa17cf1b2e1eb4'),
        'fixed':('work/134公表時計の評価/固定入力/固定取得入力.json','5dafeceae9fe87c98e7d487f924f96c56d817cf00bc5a4a96379cb7377d2c526'),
        'old_metadata':('work/133探索期限の評価/固定入力/方向と出生.json','a328f6b902e9ace8d4d764974570f6beeacda91bd099933d1b716b68875a49d2'),
        'old_fixed':('work/133探索期限の評価/固定入力/固定取得入力.json','5efb1b9ef1f1130d4507f926601f8cabe50757463d7523858351833abc6d0b5e'),
        'helper':('work/133独立検算/検算する.py','9e0dd15abae7ed5d63f3881e0d948a2f6f578da3b25178fde039a9e29e70102b')}
    assert all(sha(ROOT/p)==h for p,h in refs.values())
    load=lambda key:json.loads((ROOT/refs[key][0]).read_text(encoding='utf-8-sig'))
    spec=importlib.util.spec_from_file_location('own_frozen_nonfinancial_checks',ROOT/refs['helper'][0])
    helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
    # 私有の旧独立コードからdirection/strongだけを使う。main/算術/JSON読取は呼ばない。
    metadata,fixed,old_meta,old_fixed=load('metadata'),load('fixed'),load('old_metadata'),load('old_fixed')
    assert metadata['success'] and metadata['trial']==134 and metadata['source_engine_trial']==133
    assert metadata['new_outcomes_read'] is False and metadata['fixed_input_sha256']==refs['fixed'][1]
    assert metadata['source_sha256']=={k:refs[k][1] for k in ('instant','delay','csv')}
    assert fixed['expected_entry_count']==len(metadata['entries'])==235
    assert len(fixed['scenes'])==len(metadata['sessions'])==len(old_fixed['scenes'])==73
    mmap={(m['session'],m['id']):m for m in metadata['entries']};assert len(mmap)==235
    old_map={(m['session'],m['source_id']):m for m in old_meta['entries'] if m['model']=='L0'};assert len(old_map)==79
    fixed_map={s['session']:s for s in fixed['scenes']};seen=set();models={};strong_checks=0;csv_same=0
    expected_input_sha={'instant':'905cab946d67e368633585219fc9f4fa04efab639104dcecdc6a3d01d18eeb01',
                        'delay':'8cc73c58fcf90968d177913bfdf66bdcacb3a98aa6ca1a787a35ad9301349139',
                        'csv':'6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec'}
    for new,old in zip(fixed['scenes'],old_fixed['scenes']):
        for key in ('session','contract','start','end','force_close','raw','expected_accepted','expected_quality'):
            helper.equal(new[key],old[key],'共用metadata/'+key)
    for model in ('instant','delay','csv'):
        source=load(model)
        assert source['success'] and source['trial']==133 and source['input_sha256']==expected_input_sha[model]
        assert source['outcomes_computed'] is False and source['selected_direction_order_eligibility_rebuilt'] is False
        counts=Counter();types=Counter();source_native_L1=0;scene_rows=[];selected_flips=0
        for s in source['scenes']:
            sid=s['session'];f=fixed_map[sid];counts[sid]=0
            assert s['success'] and s['raw_passes']==1
            assert s['quality']==s['expected_quality']==f['expected_quality'] and s['actual_sha256']==f['raw']['sha256']
            assert s['execution_end']==f['end']-300 and s['entry_cutoff']==min(f['force_close'],f['end']-3900)
            assert s['fallback_at']['L0']==f['start']+10800
            inputs={e['id']:e for e in f['entries']}
            for c in s['candidates']:
                if c['status']=='filled' and c['policy']=='L1':source_native_L1+=1
                if c['status']!='filled' or c['policy']!='L0':continue
                identity=model+'/'+c['birth']['id'];key=(sid,identity)
                assert key in mmap and key not in seen;seen.add(key);m=mmap[key]
                assert m['model']==model and m['native_policy']=='L0' and m['source_id']==c['birth']['id']
                assert '/補完/L1/' not in m['source_id'] and m['path']==c['path']
                assert m['source_side']==c['birth']['side'] and m['selected_side']==c['direction']['selected_side']
                for name in ('birth','entry','direction'):helper.equal(m[name],c[name],model+'/'+sid+'/'+name)
                assert inputs[identity]=={'id':identity,'side':c['birth']['side'],'entry':c['entry']}
                helper.direction(m)
                q=c['entry'];r=c['request'];side=c['birth']['side']
                assert q['time']<s['entry_cutoff'] and q['time']<c['expires'] and q['time']>=r['time']+1
                assert q['index']>r['index'] and q['source_line']>r['source_line'] and q['quote_ok'] and 0<q['bid']<q['ask']
                assert c['entry_price']==(q['ask'] if side>0 else q['bid'])
                if c['path']=='E0':
                    assert m['strategy']=='E0' and m['direction']['e0_protected'] and m['selected_side']==side
                    event=s['events'][c['event']]
                    assert event['id']==c['birth']['id'] and event['side']==side
                    risk=side*(c['entry_price']-c['invalidation'])
                    assert 0<risk<=min(100,.5*c['atr5']) and side*(c['entry_price']-c['entry_cap'])<=0
                    hold=side*(q['last']-c['hold_boundary'])
                    assert hold>0 if c['hold_strict'] else hold>=c['hold_minimum']
                elif c['path']=='strong':
                    assert c['birth']['time']<s['fallback_at']['L0']
                    helper.strong(c);strong_checks+=1
                    assert m['strategy']==c['decision']['strategy']
                else:assert c['path']=='deadline' and c['birth']['time']>=s['fallback_at']['L0'] and m['strategy']=='deadline'
                if model=='csv':
                    old=old_map[(sid,m['source_id'])]
                    for name in ('source_id','legacy_id','source_side','selected_side','strategy','path','birth','entry','direction'):
                        helper.equal(m[name],old[name],'CSV79/'+name)
                    csv_same+=1
                selected_flips+=m['selected_side']!=side;counts[sid]+=1;types[m['strategy']]+=1
            assert counts[sid]>0 and metadata['coverage'][sid][model] is True
            assert s['coverage']['L0'] is True
            scene_rows.append({'session':sid,'native_L0_entries':counts[sid],'covered':True})
        total=sum(counts.values());assert len(counts)==73 and total==metadata['counts'][model]
        assert total=={'instant':78,'delay':78,'csv':79}[model]
        models[model]={'entries':total,'covered_sessions':73,'uncovered_sessions':0,'types':dict(types),
                       'selected_side_flips_from_Source':selected_flips,'native_L1_fills_not_used':source_native_L1,'scenes':scene_rows}
        del source
    assert len(seen)==235 and seen==set(mmap) and csv_same==79
    for s in fixed['scenes']:assert {e['id'] for e in s['entries']}=={m['id'] for m in metadata['entries'] if m['session']==s['session']}
    assert all(sha(ROOT/p)==h for p,h in refs.values())
    proof={'success':True,'scope':'134金融前Source235票接続の独立確認','source_count':235,'sessions':73,
           'models':models,'all_native_policy_L0_only':True,'native_L1_not_mixed':True,
           'CSV79_Source0_unchanged':csv_same,'strong_conditions_independently_verified':strong_checks,
           'fixed_B0_T8_E0_protection_verified':235,'all_entry_TTL_limit_and_quote_geometry_verified':True,
           'Source_geometry_not_reverse_order_eligibility':True,'source_hashes_before_after_equal':True,
           'sources':{p:h for p,h in refs.values()},'code_sha256':sha(Path(__file__)),
           'raw_reread':False,'new_financial_results_read_or_computed':False,'frozen_source_or_inputs_edited':False}
    out=HERE/'接続の独立確認.json';assert not out.exists()
    out.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'success':True,'proof_sha256':sha(out),'types':{m:p['types'] for m,p in models.items()},
                      'strong_checked':strong_checks,'CSV79_unchanged':csv_same},ensure_ascii=False))


if __name__=='__main__':main()
