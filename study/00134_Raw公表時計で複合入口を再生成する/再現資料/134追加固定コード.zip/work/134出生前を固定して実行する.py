"""134の入力置換と凍結Sourceを固定し、金融なしの候補再生成を行う。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parent.parent
OWN = ROOT / 'work/134公表時計の評価'
PLAN = ROOT / 'work/P3をRaw公表時計で再生成する準備'
FORMAL = ROOT / 'study/00134_Raw公表時計で複合入口を再生成する'
SOURCE_PLAN = ROOT / 'work/強い入口の探索期限を延ばす次仮説'
EXE = SOURCE_PLAN / 'Source入口の再生器/Source入口.exe'
EXE_SHA = 'e6d216ffbbc9ec8d640d5d482d163de3ac289c1f46392469abb9d66eb47a905e'
INPUTS = {'instant': ('即時のSource入力.json', '905cab946d67e368633585219fc9f4fa04efab639104dcecdc6a3d01d18eeb01'),
          'delay': ('遅延60秒のSource入力.json', '8cc73c58fcf90968d177913bfdf66bdcacb3a98aa6ca1a787a35ad9301349139')}


def sha(path: Path) -> str:
    """
    機能: ファイルの全体指紋を求める。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def save(path: Path, value: dict) -> None:
    """
    機能: 未作成のUTF-8 JSONへ保存する。
    引数: path(Path)、value(dict)。
    返り値: None。
    """
    with path.open('x', encoding='utf-8', newline='\n') as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2); handle.write('\n')


# ----------------------------------------
def verify(fixed: dict) -> None:
    """
    機能: 出生前に固定した全ファイルの現在指紋を検査する。
    引数: fixed(dict)。
    返り値: None。不一致は停止する。
    """
    for name, expected in fixed['ファイル'].items():
        assert sha(Path(name)) == expected, name


# ----------------------------------------
def main() -> None:
    """
    機能: F0固定後にだけ即時/遅延Sourceを再生成する。
    引数: CLI --mode(str、固定/出生)。
    返り値: None。先着・金融の観測は別段階へ残す。
    """
    parser = argparse.ArgumentParser(description='134の出生前固定と非金融再生成')
    parser.add_argument('--mode', choices=('固定', '出生'), required=True)
    args = parser.parse_args(); OWN.mkdir(parents=True, exist_ok=True)
    f0 = OWN / 'F0.json'
    if args.mode == '固定':
        assert sha(EXE) == EXE_SHA
        prepared = json.loads((SOURCE_PLAN / '準備の確認.json').read_text('utf-8'))
        files = {ROOT / name for name in prepared['source_and_dependency_hashes']}
        assert all(sha(ROOT / name) == expected for name, expected in prepared['source_and_dependency_hashes'].items())
        for filename, expected in INPUTS.values():
            path = PLAN / filename; assert sha(path) == expected; files.add(path)
        files.update((EXE, SOURCE_PLAN / '準備の確認.json', Path(__file__).resolve(),
                      ROOT / 'work/134正式文書を準備する.py', ROOT / 'inputs/00124_同入口正逆の共用入力/入力.json.gz',
                      ROOT / 'work/133探索期限の評価/Sourceの出生と取得.json'))
        for folder in (FORMAL, PLAN, ROOT / 'work/133固定取得の正逆評価器'):
            files.update(p for p in folder.rglob('*') if p.is_file() and p.suffix in ('.py', '.go', '.mod', '.md', '.json', '.exe'))
        save(f0, {'成功': True, '試行': 134, '段階': '出生前F0', 'UTC': datetime.now(timezone.utc).isoformat(),
                  '主': 'N0=Raw即時native L0複合。全73場最低1とH60±125先着70%を両判定',
                  'Source版': 133, '実行物再ビルド': False, 'NativeL1は採用しない': True,
                  '政策': ['N0', 'D0', 'C0', 'O0', 'R0'],
                  'ファイル': {str(p): sha(p) for p in sorted(files)}})
        print(json.dumps({'F0_SHA256': sha(f0), 'ファイル数': len(files)}, ensure_ascii=False)); return
    fixed = json.loads(f0.read_text('utf-8')); verify(fixed)
    results = {}
    for model, (filename, expected) in INPUTS.items():
        output = OWN / f'{model}のSource出生.json'
        command = [str(EXE), '--input', str(PLAN / filename), '--expected-sha', expected,
                   '--output', str(output), '--workers', '8', '--execute-after-f0']
        print(f'{model}の非金融Source再生成を開始', flush=True)
        subprocess.run(command, cwd=ROOT, check=True); verify(fixed)
        data = json.loads(output.read_text('utf-8'))
        assert data['success'] and data['trial'] == 133 and data['input_sha256'] == expected
        assert data['scene_count'] == len(data['scenes']) == 73 and data['outcomes_computed'] is False
        assert all(s['success'] and s['raw_passes'] == 1 for s in data['scenes'])
        rows = [c for s in data['scenes'] for c in s['candidates'] if c['policy'] == 'L0' and c['entry'] is not None]
        results[model] = {'Source_SHA256': sha(output), '取得数': len(rows),
                          '取得場数': sum(s['coverage']['L0'] for s in data['scenes']),
                          '未取得場': [s['session'] for s in data['scenes'] if not s['coverage']['L0']],
                          '実行列': command}
        print(json.dumps({'入力': model, **results[model]}, ensure_ascii=False), flush=True)
    save(OWN / '出生段階の完了.json', {'成功': True, '試行': 134, 'F0_SHA256': sha(f0),
         '全固定源前後同体': True, 'Source版': 133, '新金融未実行': True, '結果': results})


if __name__ == '__main__':
    main()
