"""134の三つの公表モデルのSource L0取得だけを、金融前の固定入力へ接続する。"""
from pathlib import Path
from collections import Counter
import gzip
import hashlib
import importlib.util
import json

ROOT = Path(__file__).resolve().parent.parent
OWN = ROOT / 'work/134公表時計の評価'
META = ROOT / 'inputs/00124_同入口正逆の共用入力/入力.json.gz'
META_SHA = 'b2368b1f42c16e8c96a3acd098c58a902807a3b6a5023d6d4b1e75261f3ee51b'
MODELS = {
    'instant': (OWN / 'instantのSource出生.json', '905cab946d67e368633585219fc9f4fa04efab639104dcecdc6a3d01d18eeb01'),
    'delay': (OWN / 'delayのSource出生.json', '8cc73c58fcf90968d177913bfdf66bdcacb3a98aa6ca1a787a35ad9301349139'),
    'csv': (ROOT / 'work/133探索期限の評価/Sourceの出生と取得.json', '6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec'),
}
DIRECTION = ROOT / 'work/133Source取得を固定入力へ渡す_版2.py'
DIRECTION_SHA = '6469ea3d473be6f25169f5629193ecb9ad681b4fc685ae78167525e311fcbd55'


def sha(path: Path) -> str:
    """
    機能: 全ファイルの指紋を求める。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def save(path: Path, value: dict) -> str:
    """
    機能: 未作成JSONへUTF-8で保存する。
    引数: path(Path)、value(dict)。
    返り値: strは保存SHA256。
    """
    with path.open('x', encoding='utf-8', newline='\n') as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False); handle.write('\n')
    return sha(path)


# ----------------------------------------
def main() -> None:
    """
    機能: 非金融Source三集合を一意結合し、出生/方向と全73場の取得0も保存する。
    引数: なし。RootのF0で固定した所定ファイルを使う。
    返り値: None。原板・先着結果・新金融を読み込まない。
    """
    f0 = json.loads((OWN / 'F0.json').read_text('utf-8'))
    assert all(sha(Path(p)) == h for p, h in f0['ファイル'].items())
    assert sha(DIRECTION) == DIRECTION_SHA
    spec = importlib.util.spec_from_file_location('133の固定方向検査', DIRECTION)
    pure = importlib.util.module_from_spec(spec); spec.loader.exec_module(pure)
    decoded = gzip.decompress(META.read_bytes()); assert hashlib.sha256(decoded).hexdigest() == META_SHA
    base = json.loads(decoded)['scenes']; assert len(base) == 73
    sources, source_hashes = {}, {}
    for model, (path, input_sha) in MODELS.items():
        source_hashes[model] = sha(path)
        data = json.loads(path.read_text('utf-8'))
        assert data['success'] and data['trial'] == 133 and data['input_sha256'] == input_sha
        assert data['scene_count'] == len(data['scenes']) == 73 and data['outcomes_computed'] is False
        assert [s['session'] for s in data['scenes']] == [s['session'] for s in base]
        sources[model] = {s['session']: s for s in data['scenes']}
    scenes, rows, coverage, attempts = [], [], {}, {}
    for meta in base:
        sid = meta['session']; coverage[sid] = {}; attempts[sid] = {}
        scene = {key: meta[key] for key in ('session', 'contract', 'start', 'end', 'force_close', 'raw',
                                           'expected_accepted', 'expected_quality')}
        scene['entries'] = []
        for model in MODELS:
            source = sources[model][sid]
            assert source['success'] and source['actual_sha256'] == meta['raw']['sha256']
            assert all(source['raw'][key] == meta['raw'][key] for key in ('path', 'sha256'))
            assert source['quality'] == source['expected_quality'] == meta['expected_quality']
            assert source['stat_before'] == source['stat_after']
            for key, stat_key in (('bytes', 'bytes'), ('mod_time_ns', 'mtime_ns')):
                if key in meta['raw']: assert meta['raw'][key] == source['stat_before'][stat_key]
            limit = min(meta['force_close'], meta['end'] - 3900)
            assert source['entry_cutoff'] == limit and source['execution_end'] == meta['end'] - 300
            assert source['fallback_at']['L0'] == meta['start'] + 10800
            selected = [c for c in source['candidates'] if c['policy'] == 'L0']
            attempts[sid][model] = dict(Counter(c['status'] for c in selected))
            filled = [c for c in selected if c['entry'] is not None]
            coverage[sid][model] = bool(filled)
            assert source['coverage']['L0'] == bool(filled)
            for candidate in filled:
                assert candidate['status'] == 'filled' and 'outcomes' not in candidate
                birth, entry, direction = candidate['birth'], candidate['entry'], candidate['direction']
                pure.verify_direction(direction, birth['side'], candidate['path'])
                assert all(birth[key] <= entry[key] for key in ('time', 'index', 'source_line'))
                assert meta['start'] <= birth['time'] <= entry['time'] < limit
                assert entry['quote_ok'] and 0 < entry['bid'] < entry['ask']
                assert candidate['entry_price'] == (entry['ask'] if birth['side'] == 1 else entry['bid'])
                for ref in direction['refs']:
                    assert ref['end'] <= ref['delivered']['time']
                    assert all(ref['delivered'][key] <= birth[key] for key in ('time', 'index', 'source_line'))
                identity = model + '/' + birth['id']
                strategy = 'E0' if candidate['path'] == 'E0' else candidate['decision']['strategy']
                rows.append({'session': sid, 'id': identity, 'model': model, 'native_policy': 'L0',
                             'source_id': birth['id'], 'legacy_id': birth['id'].replace('/補完/L0/', '/補完/P3/') if model == 'csv' else None,
                             'source_side': birth['side'], 'selected_side': direction['selected_side'],
                             'strategy': strategy, 'path': candidate['path'], 'birth': birth,
                             'entry': entry, 'direction': direction})
                scene['entries'].append({'id': identity, 'side': birth['side'], 'entry': entry})
        assert len({e['id'] for e in scene['entries']}) == len(scene['entries'])
        scenes.append(scene)
    assert len({(r['session'], r['id']) for r in rows}) == len(rows)
    assert sum(r['model'] == 'csv' for r in rows) == 79
    assert all(sha(MODELS[model][0]) == value for model, value in source_hashes.items())
    assert all(sha(Path(p)) == h for p, h in f0['ファイル'].items())
    output = OWN / '固定入力'; output.mkdir(exist_ok=False)
    input_sha = save(output / '固定取得入力.json', {'scenes': scenes, 'expected_entry_count': len(rows)})
    metadata_sha = save(output / '方向と出生.json', {'success': True, 'trial': 134, 'source_engine_trial': 133,
        'source_sha256': source_hashes, 'fixed_input_sha256': input_sha,
        'sessions': [s['session'] for s in base], 'entries': rows, 'coverage': coverage, 'attempts': attempts,
        'counts': dict(Counter(r['model'] for r in rows)), 'new_outcomes_read': False})
    save(output / '転送の確認.json', {'成功': True, '試行': 134, '全場': 73, '金融未実行': True,
        '入力SHA256': input_sha, 'metadataSHA256': metadata_sha, 'Source前後SHA256': source_hashes,
        '取得数': dict(Counter(r['model'] for r in rows)),
        '取得場数': {model: sum(c[model] for c in coverage.values()) for model in MODELS}, 'コードSHA256': sha(Path(__file__))})
    print(json.dumps({'成功': True, '入力SHA256': input_sha, 'metadataSHA256': metadata_sha,
                      '取得数': dict(Counter(r['model'] for r in rows)),
                      '取得場数': {model: sum(c[model] for c in coverage.values()) for model in MODELS}}, ensure_ascii=False))


if __name__ == '__main__':
    main()
