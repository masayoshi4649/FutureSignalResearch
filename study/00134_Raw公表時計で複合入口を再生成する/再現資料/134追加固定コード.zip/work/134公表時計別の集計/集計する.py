"""134のRoot固定後だけ、公表時計別の取得集合を金融集計するCLI。"""
from pathlib import Path
from collections import Counter
import argparse
import hashlib
import importlib.util
import json
import math

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('134公表時計別の純集計', OWN / '計算.py')
CALC = importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(CALC)
OLD_PAIRS = ROOT / 'work/124入口の正逆比較/全73場の正逆結果.json'
OLD133 = ROOT / 'work/133期限別の集計/集計.json'
OLD131 = ROOT / 'work/131既存入口の位相切替評価/集計.json'
SOURCES = {CALC.MODULE: CALC.MODULE_SHA,
           OLD_PAIRS: '25517066b291a0434211190299b9f0195e67f9a7d2e89c801d5b9e6b4b51c3a1',
           OLD133: '21e686aa350f6b093ae83b0503acecc006df38905b74478315967648f2d5858b',
           OLD131: '252a8d1744fe340b57a23db5c46d7dc7abd467fdfa59d273ce42f497b04843f3'}


def sha(path: Path) -> str:
    """
    機能: ファイルの全bytes指紋を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def valid_number(value: object) -> bool:
    """
    機能: boolを除いて有限数値を確認する。
    引数: value(object)。返り値: bool。
    """
    return type(value) in (int, float) and math.isfinite(value)


# ----------------------------------------
def direction(meta: dict) -> None:
    """
    機能: 金融を見ずに保存された固定B0/T8/E0保護の式を再確認する。
    引数: meta(dict)。返り値: None。
    """
    d = meta['direction']; fields = d['fields']; source = meta['source_side']
    assert type(source) is int and source in (-1, 1)
    body = CALC.number(fields, 'body5_signed_ratio_to_source')
    b0 = -source if body is not None and .5 <= body < .75 else source
    long = CALC.number(fields, 'ema21_delta30_to_B0'); hist = CALC.number(fields, 'hist5_atr_to_B0')
    t8 = -b0 if long is not None and long >= 0 and hist is not None and hist >= .1 else b0
    assert (d['source_side'], d['b0_side'], d['t8_side']) == (source, b0, t8)
    assert d['e0_protected'] is (meta['path'] == 'E0')
    assert d['selected_side'] == meta['selected_side'] == (source if meta['path'] == 'E0' else t8)
    birth = meta['birth']; entry = meta['entry']
    assert all(birth[k] <= entry[k] for k in ('time', 'index', 'source_line'))
    assert birth['quote']['time'] == birth['time'] and birth['quote']['index'] == birth['index']
    assert birth['quote']['source_line'] == birth['source_line']
    assert d['refs'] and any(r['width_seconds'] == 300 for r in d['refs'])
    for ref in d['refs']:
        assert ref['end'] <= ref['delivered']['time']
        assert all(ref['delivered'][k] <= birth[k] for k in ('time', 'index', 'source_line'))


# ----------------------------------------
def prepare_records(result: dict, metadata: dict, fixed: dict) -> tuple[list[dict], list[str], dict]:
    """
    機能: 固定入力/方向metadataと4streamの自然結果を一意結合する。
    引数: result/metadata/fixed(dict)。返り値: tuple[list[dict],list[str],dict]。
    """
    assert result['success'] and result['trial'] == 133 and metadata['success'] and metadata['trial'] == 134
    assert metadata['new_outcomes_read'] is False
    assert result['input_sha256'] == metadata['fixed_input_sha256']
    sessions = [s['session'] for s in fixed['scenes']]
    assert sessions == metadata['sessions'] == [s['session'] for s in result['scenes']] == sorted(sessions)
    assert len(sessions) == len(set(sessions)) == result['scene_count'] == 73
    assert tuple(result['widths']) == (25, 50, 100, 125, 200) and tuple(result['horizons']) == (1800, 3600)
    meta_map = {(m['session'], m['id']): m for m in metadata['entries']}
    assert len(meta_map) == len(metadata['entries']) == fixed['expected_entry_count'] == result['source_entry_count']
    rows = []; seen = set(); phase = Counter()
    for original, scene in zip(fixed['scenes'], result['scenes']):
        sid = scene['session']; boundary = original['end'] - 300
        assert scene['success']
        assert all(scene['raw'][k] == original['raw'][k] for k in ('path', 'sha256'))
        assert scene['actual_sha256'] == original['raw']['sha256']
        assert scene['stat_before'] == scene['stat_after'] and scene['quality'] == scene['expected_quality'] == original['expected_quality']
        if 'bytes' in original['raw']:
            assert scene['stat_before']['bytes'] == original['raw']['bytes']
        if 'mod_time_ns' in original['raw']:
            assert scene['stat_before']['mtime_ns'] == original['raw']['mod_time_ns']
        assert scene['execution_end'] == boundary and scene['source_force_close'] == original['force_close']
        limit = min(original['force_close'], original['end'] - 3900)
        assert scene['effective_entry_limit'] == limit
        fixed_entries = {e['id']: e for e in original['entries']}
        assert len(fixed_entries) == len(original['entries']) == len(scene['cases']) == scene['source_entries']
        for case in scene['cases']:
            key = (sid, case['id']); assert key in meta_map and key not in seen
            seen.add(key); m = meta_map[key]; e = fixed_entries[case['id']]
            assert m['model'] in CALC.MODELS and m['native_policy'] == 'L0'
            assert m['id'] == m['model'] + '/' + m['birth']['id'] and m['source_id'] == m['birth']['id']
            assert m['legacy_id'] == (m['birth']['id'].replace('/補完/L0/', '/補完/P3/') if m['model'] == 'csv' else None)
            assert e['side'] == case['original_side'] == m['source_side']
            assert case['original']['entry'] == e['entry'] == m['entry']
            direction(m)
            entry = e['entry']; assert original['start'] <= entry['time'] < limit
            assert entry['quote_ok'] and 0 < entry['bid'] < entry['ask']
            for name in ('original', 'reverse', 'chart_original', 'chart_reverse'):
                candidate = case[name]; chart = name.startswith('chart_')
                side = case['original_side'] if name in ('original', 'chart_original') else -case['original_side']
                assert candidate['status'] == 'filled' and candidate['birth']['side'] == side and candidate['entry'] == entry
                expected = entry['last'] if chart else entry['ask'] if side == 1 else entry['bid']
                assert candidate['entry_price'] == expected
                assert tuple(o['seconds'] for o in candidate['outcomes']) == (1800, 3600)
                phase['stream検査'] += 1; phase['entry検査'] += 1
                for o in candidate['outcomes']:
                    assert o['deadline'] == entry['time'] + o['seconds']
                    assert tuple(t['width'] for t in o['touches']) == (25, 50, 100, 125, 200)
                    assert o['status'] in ('complete', 'gap_censored', 'bbo_gap_censored', 'session_censored', 'endpoint_missing', 'phase_censored', 'eof_censored')
                    endpoint = o['endpoint']
                    assert (endpoint is not None) is (o['status'] == 'complete')
                    if endpoint is not None:
                        assert valid_number(endpoint['time']) and o['deadline'] <= endpoint['time'] <= o['deadline'] + 30
                        assert endpoint['time'] < boundary and endpoint['index'] > entry['index'] and endpoint['source_line'] > entry['source_line']
                        assert endpoint['quote_ok'] and 0 < endpoint['bid'] < endpoint['ask'] and valid_number(endpoint['last'])
                        phase['endpoint検査'] += 1
                    for touch in o['touches']:
                        assert type(touch['direction']) is int and touch['direction'] in (-1, 0, 1)
                        q = touch['quote']; assert (q is None) is (touch['direction'] == 0)
                        if q is not None:
                            assert valid_number(q['time']) and entry['time'] <= q['time'] <= o['deadline'] and q['time'] < boundary
                            assert q['index'] > entry['index'] and q['source_line'] > entry['source_line'] and q['quote_ok'] and 0 < q['bid'] < q['ask']
                            mark = q['last'] if chart else q['bid'] if side == 1 else q['ask']
                            gain = side * (mark - expected)
                            assert gain >= touch['width'] if touch['direction'] == 1 else gain <= -touch['width']
                            phase['touch検査'] += 1
                    if chart: assert o['net0'] is None and o['net5'] is None
            rows.append({'session': sid, 'model': m['model'], 'case': case, 'meta': m})
    assert seen == set(meta_map)
    assert metadata['counts'] == {model: sum(r['model'] == model for r in rows) for model in CALC.MODELS}
    for sid in sessions:
        for model in CALC.MODELS:
            assert metadata['coverage'][sid][model] is any(r['session'] == sid and r['model'] == model for r in rows)
    return rows, sessions, dict(phase)


# ----------------------------------------
def assert_baselines(records: list[dict], aggregate: dict, old_pairs: dict, old133: dict, old131: dict) -> dict:
    """
    機能: CSVの79Case/4streamとC0全区分・全条件を旧固定結果へ照合する。
    引数: records(list[dict])、aggregate/old_pairs/old133/old131(dict)。返り値: dict。
    """
    previous = {(s['session'], c['id']): c for s in old_pairs['scenes'] for c in s['cases']}
    rows = [r for r in records if r['model'] == 'csv']; used = set(); labels = 0
    assert len(previous) == len(rows) == 79
    for r in rows:
        key = (r['session'], r['meta']['legacy_id']); assert key in previous and key not in used
        used.add(key); old = previous[key]; case = r['case']
        assert case['original_side'] == old['original_side']
        for name in ('original', 'reverse', 'chart_original', 'chart_reverse'):
            a, b = case[name], old[name]
            assert a['entry'] == b['entry'] and a['entry_price'] == b['entry_price'] and a['birth']['side'] == b['birth']['side']
            assert a['outcomes'] == b['outcomes'], (key, name)
            labels += 2 * 5
    assert used == set(previous)
    count = 0
    for part in ('all', 'train', 'validation'):
        assert aggregate[part]['C0'] == old133['集計'][part]['L0'], (part, '133L0')
        assert aggregate[part]['C0'] == old131['集計'][part]['T8'], (part, '131T8')
        count += 40
    return {'成功': True, 'CSV取得時計と4stream全outcomes同体': 79,
            '全H幅のラベル比較': labels, '旧集計の全条件同体': count,
            '比較元': '旧133L0と131T8の全3区分各20条件', '旧対照を書き換え': False}


# ----------------------------------------
def main() -> None:
    """
    機能: Root F1と全入力SHAを確認してからだけ自然結果を集計する。
    引数: CLIの固定入力/metadata/result/F1と各SHA(str/Path)。返り値: None。
    """
    parser = argparse.ArgumentParser(description='134のRoot金融前固定後だけ集計する')
    for name in ('f1', 'fixed-input', 'metadata', 'result'):
        parser.add_argument('--' + name, required=True, type=Path)
        parser.add_argument('--' + name + '-sha256', required=True)
    parser.add_argument('--output-dir', required=True, type=Path); args = parser.parse_args()
    paths = {name: getattr(args, name.replace('-', '_')).resolve() for name in ('f1', 'fixed-input', 'metadata', 'result')}
    expected = {name: getattr(args, name.replace('-', '_') + '_sha256') for name in paths}
    assert all(len(h) == 64 and all(c in '0123456789abcdef' for c in h) for h in expected.values())
    assert sha(paths['f1']) == expected['f1']
    f1 = json.loads(paths['f1'].read_text('utf-8')); declared = {Path(p).resolve(): h for p, h in f1['ファイル'].items()}
    for name in ('fixed-input', 'metadata'):
        assert declared[paths[name]] == expected[name] and sha(paths[name]) == expected[name]
    local = [OWN / n for n in ('条件.md', '計算.py', '集計する.py', '人工検査.py')]
    assert all(declared[p.resolve()] == sha(p) for p in local)
    assert all(declared[p.resolve()] == h for p, h in SOURCES.items())
    checks = {**SOURCES, **{paths[n]: expected[n] for n in paths}, **{p: sha(p) for p in local}}
    assert all(sha(p) == h for p, h in checks.items())
    dest = args.output_dir; dest.mkdir(parents=True, exist_ok=True)
    assert not any((dest / n).exists() for n in ('集計.json', 'CSV用の表.json', '集計完了.json'))
    # ここまで自然金融結果のJSON内容は開かない。Rootの明示SHAとF1を先に確認する。
    fixed = json.loads(paths['fixed-input'].read_text('utf-8')); metadata = json.loads(paths['metadata'].read_text('utf-8'))
    result = json.loads(paths['result'].read_text('utf-8'))
    assert metadata['fixed_input_sha256'] == expected['fixed-input']
    records, sessions, phase = prepare_records(result, metadata, fixed)
    module = CALC.load_arithmetic(); aggregate, participation = CALC.aggregate(records, sessions, module)
    baseline = assert_baselines(records, aggregate, json.loads(OLD_PAIRS.read_text('utf-8')),
                                json.loads(OLD133.read_text('utf-8')), json.loads(OLD131.read_text('utf-8')))
    tables = CALC.tables(records, sessions, aggregate, participation, module)
    output = {'成功': True, '試行': 134, '主政策': 'N0', '主評価': CALC.goal(aggregate, participation),
              '後段engine試行': result['trial'], '全場数': 73, '取得集合数': metadata['counts'], '集計': aggregate, '参加': participation,
              '主N0と同群O0の両側既知ペア差': CALC.paired(records, 'N0', 'O0', module),
              'N0とD0とC0のcaseペア差': None, '異時計の比較': '各取得集合の実現代用損益を並べる。同case差ではない',
              'bootstrap': CALC.bootstrap(records, sessions), '全4streamのphase検査': phase, '旧対照同体': baseline,
              '全73場は既使用': True, '独立未知期検証': False, '多重比較補正': False,
              'F1_SHA256': expected['f1'], '固定入力SHA256': expected['fixed-input'], '方向metadataSHA256': expected['metadata'],
              '自然結果SHA256': expected['result'], '口座収支': False, '実IFD': False,
              '公表時計比較の限界': 'Raw即時/遅延は15 EOF欠落とBB15/RVOL窓差を含む。CSV対RawはOHLC/助走/数量proxyも違い、時刻だけの効果ではない',
              '数量費用': '独立mini1枚100円/pt、往復77円、C5追加1000円。Last金額null'}
    assert all(sha(p) == h for p, h in checks.items())
    module.save(dest / '集計.json', output)
    module.save(dest / 'CSV用の表.json', {'成功': True, '試行': 134, '主政策': 'N0', 'tables': tables,
                '意味': '異なるRaw即時/Raw遅延/CSV取得集合と同一取得内の方向対照。独立1mini代用、口座収支ではない'})
    module.save(dest / '集計完了.json', {'成功': True, '試行': 134, '前後SHA256': {str(p): h for p, h in checks.items()},
                '前後不変': True, '表行数': [len(t['rows']) for t in tables], '表列数': [len(t['headers']) for t in tables],
                '集計SHA256': sha(dest / '集計.json'), '表SHA256': sha(dest / 'CSV用の表.json')})
    print(json.dumps({'成功': True, '主評価': output['主評価'], '行数': [len(t['rows']) for t in tables]}, ensure_ascii=False))


if __name__ == '__main__':
    main()
