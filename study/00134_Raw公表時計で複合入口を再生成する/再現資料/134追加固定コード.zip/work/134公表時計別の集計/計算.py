"""政策ごとに取得集合を分離し、固定124算術を使う134の純集計関数。"""
from pathlib import Path
from collections import Counter
import importlib.util
import math

ROOT = Path(__file__).resolve().parents[2]
MODULE = ROOT / 'work/124入口の原因分析/集計する.py'
MODULE_SHA = '8479ca348231ffd77a637360797750833c9e6617c7fc4a6502e015c7a1d9f04a'
POLICIES = ('N0', 'D0', 'C0', 'O0', 'R0')
DISPLAY = ('N0', 'D0', 'C0', 'O0', 'R0')
MODELS = ('instant', 'delay', 'csv')
MODEL = {'N0': 'instant', 'D0': 'delay', 'C0': 'csv', 'O0': 'instant', 'R0': 'instant'}


def load_arithmetic() -> object:
    """
    機能: 原文不変の124算術をmainを実行せず私有moduleへ読み込む。
    引数: なし。返り値: objectは固定stats/ifd/bootstrap等。
    """
    import hashlib
    assert hashlib.sha256(MODULE.read_bytes()).hexdigest() == MODULE_SHA
    spec = importlib.util.spec_from_file_location('134専用の固定124算術', MODULE)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    module.selected = selected
    return module


# ----------------------------------------
def selected(record: dict, policy: str, axis: str) -> dict:
    """
    機能: 政策の取得集合を検査して、保存された実正逆又はLast側を選ぶ。
    引数: record(dict)、policy/axis(str)。返り値: dictは保存candidate。
    """
    assert policy in POLICIES and axis in ('BBO', 'Last') and record['model'] == MODEL[policy]
    original = record['case']['original_side']
    side = original if policy == 'O0' else record['meta']['selected_side']
    if policy == 'R0': side = -side
    assert side in (-1, 1)
    key = ('chart_' if axis == 'Last' else '') + ('original' if side == original else 'reverse')
    return record['case'][key]


# ----------------------------------------
def subset(records: list[dict], policy: str, sessions: list[str]) -> list[dict]:
    """
    機能: 政策と対象場に該当する取得だけをstatsへ渡す。
    引数: records(list[dict])、policy(str)、sessions(list[str])。返り値: list[dict]。
    """
    allowed = set(sessions)
    return [r for r in records if r['model'] == MODEL[policy] and r['session'] in allowed]


# ----------------------------------------
def coverage(records: list[dict], model: str, sessions: list[str]) -> dict:
    """
    機能: 未取得場も対象に残して参加を判定する。
    引数: records(list[dict])、model(str)、sessions(list[str])。返り値: dict。
    """
    assert model in MODELS and len(sessions) == len(set(sessions))
    counts = Counter(r['session'] for r in records if r['model'] == model and r['session'] in sessions)
    missing = [s for s in sessions if not counts[s]]
    return {'対象場数': len(sessions), '取得数': sum(counts.values()), '取得場数': len(counts),
            '未取得場数': len(missing), '未取得場': missing, '全場最低1取得': not missing and bool(sessions)}


# ----------------------------------------
def aggregate(records: list[dict], sessions: list[str], module: object) -> tuple[dict, dict]:
    """
    機能: 全体・前48・後25で、政策別の集合だけを300条件へ集計する。
    引数: records(list[dict])、sessions(list[str])、module(object)。返り値: tuple[dict,dict]。
    """
    assert len(sessions) == 73
    output, participation = {}, {}
    for part, ids in (('all', sessions), ('train', sessions[:48]), ('validation', sessions[48:])):
        participation[part] = {m: coverage(records, m, ids) for m in MODELS}
        output[part] = {}
        for policy in POLICIES:
            rows = subset(records, policy, ids)
            output[part][policy] = {axis: {str(h): {str(w): module.stats(rows, policy, axis, h, w)
                                      for w in module.WIDTHS} for h in module.HORIZONS} for axis in module.AXES}
    return output, participation


# ----------------------------------------
def goal(aggregate: dict, participation: dict) -> dict:
    """
    機能: 主N0の参加と同幅先着70%を別々に判定する。
    引数: aggregate/participation(dict)。返り値: dict。
    """
    s = aggregate['all']['N0']['BBO']['3600']['125']; p = participation['all']['instant']
    rate = s['target70'] is True
    return {'主': 'N0/Raw即時L0/全73場/実BBO/H60/±125pt', '全73場最低1取得': p['全場最低1取得'],
            '到達済み先着70%以上': rate, '両条件達成': bool(p['全場最低1取得'] and rate),
            '順': s['forward'], '逆': s['adverse'], '未到達': s['neither'], '全H不足': s['censored'],
            '到達済み率': s['resolved_rate'], '未到達込率': s['complete_rate'], '参加': p}


# ----------------------------------------
def paired(records: list[dict], policy: str, reference: str, module: object) -> dict:
    """
    機能: 同じRaw即時取得だけで、選択方向とSource方向の両側既知差を求める。
    引数: records(list[dict])、policy/reference(str)、module(object)。返り値: dict。
    """
    assert policy == 'N0' and reference == 'O0', '異なる取得集合のcaseペアを作らない'
    rows = [r for r in records if r['model'] == 'instant']
    values = []; left = right = neither = 0
    for r in rows:
        a = selected(r, policy, 'BBO'); b = selected(r, reference, 'BBO')
        x = module.ifd(a, module.observation(a, 3600), 125, 'BBO')
        y = module.ifd(b, module.observation(b, 3600), 125, 'BBO')
        if x['known'] and y['known']: values.append(x['net5'] - y['net5'])
        elif x['known']: left += 1
        elif y['known']: right += 1
        else: neither += 1
    return {'政策': policy, '同群の対照': reference, '取得集合': 'instant', '同case数': len(rows),
            '両側既知': len(values), '政策だけ既知': left, '対照だけ既知': right, '両側未知': neither,
            'C5既知ペア差引円': sum(values) if values else None,
            'C5既知ペア平均差円': sum(values) / len(values) if values else None}


# ----------------------------------------
def bootstrap(records: list[dict], sessions: list[str]) -> dict:
    """
    機能: 固定124の5000回/seed124算術を主N0と同群O0へ限定して適用する。
    引数: records(list[dict])、sessions(list[str])。返り値: dictは探索内の参考区間。
    """
    assert len(sessions) == 73
    module = load_arithmetic(); module.POLICIES = ('N0',)
    result = module.bootstrap([r for r in records if r['model'] == 'instant'], sessions)
    item = result['政策']['N0']
    item['O0との同群両側既知ペア平均差95区間'] = item.pop('O0との両側既知ペア平均差95区間')
    result['対照'] = 'Raw即時の同じ取得原行の元方向O0'
    result['異なる公表時計のN0とD0とC0をcaseペア化'] = False
    return result


# ----------------------------------------
def number(fields: dict, key: str) -> float | None:
    """
    機能: Go形式の未知格納0を既知0と区別する。
    引数: fields(dict)、key(str)。返り値: float|None。
    """
    item = fields.get(key, {'known': False, 'value': 0})
    assert type(item['known']) is bool
    if not item['known']: return None
    value = item['value']; assert type(value) in (int, float) and math.isfinite(value)
    return value


# ----------------------------------------
def tables(records: list[dict], sessions: list[str], values: dict, participation: dict, module: object) -> list[dict]:
    """
    機能: 300比較・可変入口・全73場の3表を作り、適用外をnullにする。
    引数: records/sessions(list)、values/participation(dict)、module(object)。返り値: list[dict]。
    """
    headers = ['試行', '区分', '政策', '取得集合', '価格軸', '評価分', '同幅pt', '対象場数', '取得場数', '取得数',
               'Source向きからの反転数', '全場最低1取得', '全H完了', '観測不足', '順行先着', '逆行先着', '両方未到達',
               '到達済み順行率', '未到達込順行率', '到達済み70%達成', '参加と70%両達成', 'IFD代用既知', 'IFD代用未知',
               'C0代用差引円', 'C5代用利益円', 'C5代用損失絶対円', 'C5代用差引円', 'C5代用平均円', 'C5代用PF']
    compare = []
    for part in ('all', 'train', 'validation'):
        for policy in DISPLAY:
            p = participation[part][MODEL[policy]]
            for axis in module.AXES:
                for h in module.HORIZONS:
                    for w in module.WIDTHS:
                        s = values[part][policy][axis][str(h)][str(w)]
                        compare.append([134, part, policy, MODEL[policy], axis, h / 60, w, p['対象場数'],
                            s['sessions'], s['entries'], s['flips'], p['全場最低1取得'], s['complete'], s['censored'],
                            s['forward'], s['adverse'], s['neither'], s['resolved_rate'], s['complete_rate'], s['target70'],
                            bool(p['全場最低1取得'] and s['target70'] is True), s['ifd_known'], s['ifd_unknown'],
                            s['ifd_net0_sum'], s['ifd_net5_profit'], s['ifd_net5_loss'], s['ifd_net5_sum'], s['ifd_net5_mean'], s['ifd_net5_pf']])
    detail_headers = ['試行', '参考区分', 'セッション', '取得集合', '出生ID', 'Source出生ID', '入口経路', 'native政策', 'Source向き',
                      'B0向き', 'T8向き', '選択向き', 'E0保護', '出生JST', '取得JST', '元取得価格', '逆取得価格',
                      '5分実体比_Source', '実体既知', '30分EMA21増分_B0', '長期既知', '5分HistATR_B0', '勢い既知', 'ATR5', 'ATR既知']
    for p in DISPLAY: detail_headers += [p + '向き', p + '125全H', p + '125先着', p + 'IFD既知', p + 'IFD清算', p + '125C5代用円']
    details = []; front = set(sessions[:48])
    for r in records:
        c, m = r['case'], r['meta']; d = m['direction']; f = d['fields']
        nums = [number(f, k) for k in ('body5_signed_ratio_to_source', 'ema21_delta30_to_B0', 'hist5_atr_to_B0', 'atr5')]
        row = [134, 'train' if r['session'] in front else 'validation', r['session'], r['model'], c['id'], m['source_id'],
               m['path'], m['native_policy'], c['original_side'], d['b0_side'], d['t8_side'], m['selected_side'], d['e0_protected'],
               module.jst(m['birth']['time']), module.jst(c['original']['entry']['time']),
               c['original']['entry_price'], c['reverse']['entry_price']]
        for v in nums: row += [v, v is not None]
        for p in DISPLAY:
            if MODEL[p] != r['model']: row += [None] * 6; continue
            candidate = selected(r, p, 'BBO'); o = module.observation(candidate, 3600); e = module.ifd(candidate, o, 125, 'BBO')
            row += [candidate['birth']['side'], o['status'], module.touch(o, 125)['direction'], e['known'], e['reason'], e['net5']]
        details.append(row)
    session_headers = ['試行', 'セッション', '参考区分'] + [m + '取得数' for m in MODELS] + [m + '最低1取得' for m in MODELS]
    for p in DISPLAY: session_headers += [p + '反転数', p + '125順', p + '125逆', p + '125未到達', p + '全H不足',
        p + 'IFD既知', p + 'IFD未知', p + 'C5利益円', p + 'C5損失絶対円', p + 'C5既知差引円',
        p + 'C5既知累計円（口座収支ではない）', p + '累計IFD未知']
    session_rows = []; cumulative = {p: 0 for p in POLICIES}; unknown = {p: 0 for p in POLICIES}
    for i, sid in enumerate(sessions):
        counts = {m: sum(r['model'] == m and r['session'] == sid for r in records) for m in MODELS}
        row = [134, sid, 'train' if i < 48 else 'validation'] + [counts[m] for m in MODELS] + [bool(counts[m]) for m in MODELS]
        for p in DISPLAY:
            s = module.stats(subset(records, p, [sid]), p, 'BBO', 3600, 125)
            if s['ifd_net5_sum'] is not None: cumulative[p] += s['ifd_net5_sum']
            unknown[p] += s['ifd_unknown']
            row += [s['flips'], s['forward'], s['adverse'], s['neither'], s['censored'], s['ifd_known'], s['ifd_unknown'],
                    s['ifd_net5_profit'], s['ifd_net5_loss'], s['ifd_net5_sum'], cumulative[p], unknown[p]]
        session_rows.append(row)
    result = [{'name': '正逆比較', 'headers': headers, 'rows': compare},
              {'name': '入口別診断', 'headers': detail_headers, 'rows': details},
              {'name': '全セッション', 'headers': session_headers, 'rows': session_rows}]
    assert [len(t['rows']) for t in result] == [300, len(records), 73]
    assert all(len(t['headers']) == len(set(t['headers'])) and all(len(row) == len(t['headers']) for row in t['rows']) for t in result)
    return result
