package holdingohlc113

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"reflect"
	"strings"
	"testing"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// ----------------------------------------
// rawPreparationInput は、原板を指さない人工73場を作ります。
//
// 引数: なし。返り値: Input133は公表0件、存在しない原板パスの人工入力です。
func rawPreparationInput() Input133 {
	in := Input133{}
	for i := 0; i < 73; i++ {
		start := float64(100000 + i*10000)
		in.Scenes = append(in.Scenes, Scene133{
			Session: fmt.Sprintf("人工%03d", i), Contract: "人工限月",
			Start: start, End: start + 8000, ForceClose: start + 7900,
			Raw:              FileRef{Path: "存在しない人工原板", SHA256: strings.Repeat("a", 64)},
			ExpectedAccepted: 100,
		})
	}
	return in
}

// ----------------------------------------
// rawPreparationPublication は、即時または遅延の人工公表を作ります。
//
// 引数: scene(Scene133)、delay(float64)。返り値: rules.Publicationは未知技法値を保持します。
func rawPreparationPublication(scene Scene133, delay float64) rules.Publication {
	end := scene.Start + 300
	return rules.Publication{
		Stamp: rules.Stamp{Time: end + delay, Index: 2, Line: 3},
		Frame: rules.Frame{Frame: rules.ChartFrame{
			ID: "raw-price-clock:人工ID", SessionID: scene.Session, Contract: scene.Contract,
			Width: 300, Start: scene.Start, End: end, AvailableAt: end + delay, DeliveryAt: end + delay,
			PriceKnown: true, VolumeKnown: false,
			OHLC: rules.OHLC{Open: 100, High: 102, Low: 99, Close: 101}, Volume: 123,
			Technical: rules.Technical{EMA21: rules.Value{Known: false, Value: 17}},
		}},
	}
}

// ----------------------------------------
// TestRawPublicationsPreparationArtificial は、モデル名・件数・ID・即時時計の互換性を検査します。
//
// 引数: t(*testing.T)。返り値: なし。validateInput133だけを呼び、原板走査は行いません。
func TestRawPublicationsPreparationArtificial(t *testing.T) {
	for _, delay := range []float64{0, 60} {
		in := rawPreparationInput()
		if n, err := validateInput133(in, 1); err != nil || n != 0 {
			t.Fatalf("公表0件を拒否: %d %v", n, err)
		}
		in.Scenes[0].Publications = []rules.Publication{rawPreparationPublication(in.Scenes[0], delay)}
		payload, err := json.Marshal(in)
		if err != nil {
			t.Fatal(err)
		}
		var extra map[string]any
		if err := json.Unmarshal(payload, &extra); err != nil {
			t.Fatal(err)
		}
		extra["clock"] = "任意のRaw時計名"
		extra["model"] = map[string]any{"name": "任意モデル名", "delay_seconds": delay}
		payload, err = json.Marshal(extra)
		if err != nil {
			t.Fatal(err)
		}
		var decoded Input133
		if err := json.Unmarshal(payload, &decoded); err != nil {
			t.Fatal(err)
		}
		before, _ := json.Marshal(decoded)
		if n, err := validateInput133(decoded, 1); err != nil || n != 1 {
			t.Fatalf("即時/遅延の公表を拒否: %.0f %d %v", delay, n, err)
		}
		after, _ := json.Marshal(decoded)
		if !reflect.DeepEqual(before, after) || decoded.Scenes[0].Publications[0].Frame.Frame.Technical.EMA21 != (rules.Value{Known: false, Value: 17}) {
			t.Fatal("入力の変更または未知値の補完")
		}
	}
}

// ----------------------------------------
// TestRawPublicationsPreparationRejectsFuture は、未知を補わず未来の配送を拒否することを検査します。
//
// 引数: t(*testing.T)。返り値: なし。入力metadataと公表だけを用います。
func TestRawPublicationsPreparationRejectsFuture(t *testing.T) {
	in := rawPreparationInput()
	pub := rawPreparationPublication(in.Scenes[0], 0)
	pub.Frame.Frame.AvailableAt = pub.Stamp.Time + 1
	in.Scenes[0].Publications = []rules.Publication{pub}
	if _, err := validateInput133(in, 1); err == nil {
		t.Fatal("未公表値を受理")
	}
	in = rawPreparationInput()
	in.Scenes[0].Publications = []rules.Publication{rawPreparationPublication(in.Scenes[0], 0)}
	in.Scenes[0].Publications[0].Frame.Frame.Contract = "異なる限月"
	if _, err := validateInput133(in, 1); err == nil {
		t.Fatal("異なる限月の公表を受理")
	}
}

// ----------------------------------------
// TestRawPublicationsPreparationInputs は、派生JSONを凍結Sourceの型とvalidateInput133へ通します。
//
// 引数: t(*testing.T)。環境変数 FSR_RAW_PREPARATION_INPUTS はpath/sha256/publicationsのJSON配列です。
// 返り値: なし。入力JSON以外を開かず、Source自然再生や原板走査は呼びません。
func TestRawPublicationsPreparationInputs(t *testing.T) {
	text := os.Getenv("FSR_RAW_PREPARATION_INPUTS")
	if text == "" {
		t.Skip("派生入力が指定されていないため人工検査だけを実行")
	}
	var specs []struct {
		Path         string `json:"path"`
		SHA256       string `json:"sha256"`
		Publications int    `json:"publications"`
	}
	if err := json.Unmarshal([]byte(text), &specs); err != nil || len(specs) != 2 {
		t.Fatalf("入力指定が2件でない: %v", err)
	}
	for _, spec := range specs {
		payload, err := os.ReadFile(spec.Path)
		if err != nil {
			t.Fatal(err)
		}
		sum := sha256.Sum256(payload)
		if hex.EncodeToString(sum[:]) != spec.SHA256 {
			t.Fatal("派生入力SHA不一致")
		}
		var in Input133
		if err := json.Unmarshal(payload, &in); err != nil {
			t.Fatal(err)
		}
		before, err := json.Marshal(in)
		if err != nil {
			t.Fatal(err)
		}
		n, err := validateInput133(in, 1)
		if err != nil || n != spec.Publications {
			t.Fatalf("派生入力不適合: %s %d %v", spec.Path, n, err)
		}
		after, err := json.Marshal(in)
		if err != nil || !reflect.DeepEqual(before, after) {
			t.Fatalf("型検査で入力を変更: %v", err)
		}
		t.Logf("入力SHA=%s 場=%d 公表=%d 原板走査なし", spec.SHA256, len(in.Scenes), n)
	}
}
