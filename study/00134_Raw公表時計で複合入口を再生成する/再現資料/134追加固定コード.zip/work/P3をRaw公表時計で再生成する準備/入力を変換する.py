"""既生成128公表と小型共用metadataだけから二つのSource入力を作る。"""
from pathlib import Path
from collections import Counter
import gzip
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
METADATA = ROOT / 'inputs/00124_同入口正逆の共用入力/入力.json.gz'
METADATA_SHA = 'b2368b1f42c16e8c96a3acd098c58a902807a3b6a5023d6d4b1e75261f3ee51b'
PUBLICATIONS = {
    '即時': ('gap300.json.gz', 'e382858a62865b321449279d9653f5b1c644c97f6c4254cbae8dd9d3ea065e62', 12809),
    '遅延60秒': ('gap300_delay60.json.gz', 'ce2add7e0a01fd1ab31c0510194b4647144c01034701f548253c307f6334c830', 12794),
}


def sha(data: bytes) -> str:
    """
    機能: bytes全体の指紋を求める。
    引数: data(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(data).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 73場の同一metadataへ既存公表を接続しSource用JSON二点を新規保存する。
    引数: なし。
    返り値: None。自然Raw・CSV・Source出生・金融結果は開かない。
    """
    data = gzip.decompress(METADATA.read_bytes()); assert sha(data) == METADATA_SHA
    base = json.loads(data); assert len(base['scenes']) == 73
    records = {}
    for name, (filename, expected, count) in PUBLICATIONS.items():
        path = ROOT / 'work/128全場のRaw公表' / filename
        body = path.read_bytes(); assert sha(body) == expected
        original = json.loads(gzip.decompress(body))
        assert original['success'] and len(original['scenes']) == 73
        scenes = []
        width_counts = Counter()
        for metadata, scene in zip(base['scenes'], original['scenes']):
            assert metadata['session'] == scene['session']
            for key in ('contract', 'start', 'end', 'force_close', 'expected_accepted', 'expected_quality'):
                assert metadata[key] == scene[key], (name, metadata['session'], key)
            assert all(metadata['raw'][key] == scene['raw'][key] for key in ('path', 'sha256'))
            pubs = scene['publications']
            previous = None
            for publication in pubs:
                stamp = publication['stamp']; frame = publication['frame']['frame']
                assert frame['session_id'] == metadata['session'] and frame['contract'] == metadata['contract']
                assert metadata['start'] <= stamp['time'] <= metadata['end']
                assert frame['end'] <= frame['available_at'] <= frame['delivery_at'] <= stamp['time']
                assert 0 <= stamp['index'] < metadata['expected_accepted'] and stamp['source_line'] >= 1
                current = tuple(stamp[k] for k in ('time', 'index', 'source_line'))
                if previous is not None:
                    assert all(a >= b for a, b in zip(current, previous))
                previous = current
                width_counts[frame['width_seconds']] += 1
            merged = {key: metadata[key] for key in ('session', 'contract', 'start', 'end', 'force_close',
                                                     'raw', 'expected_accepted', 'expected_quality')}
            merged['publications'] = pubs
            scenes.append(merged)
        assert sum(width_counts.values()) == count
        encoded = (json.dumps({'scenes': scenes}, ensure_ascii=False, allow_nan=False, separators=(',', ':')) + '\n').encode('utf-8')
        output = OWN / f'{name}のSource入力.json'
        with output.open('xb') as handle:
            handle.write(encoded)
        assert sha(output.read_bytes()) == sha(encoded) and sha(path.read_bytes()) == expected
        records[name] = {'生成元': str(path.relative_to(ROOT)), '生成元SHA256': expected,
                         '出力': str(output.relative_to(ROOT)), '出力SHA256': sha(encoded), 'bytes': len(encoded),
                         '全場': 73, '公表数': count, '足幅別': dict(width_counts), 'metadata共通': True}
        print(json.dumps({'入力': name, **records[name]}, ensure_ascii=False), flush=True)
    assert sha(gzip.decompress(METADATA.read_bytes())) == METADATA_SHA
    proof = {'成功': True, '試行番号未採番': True, 'Sourceルール変更': False, 'Source再ビルド': False,
             '原板読取': False, 'CSV読取': False, 'Source自然走査': False, '金融読取': False,
             'metadata解凍SHA256': METADATA_SHA, 'コードSHA256': sha(Path(__file__).read_bytes()), '入力': records}
    with (OWN / 'Root入力変換の確認.json').open('x', encoding='utf-8', newline='\n') as handle:
        json.dump(proof, handle, ensure_ascii=False, indent=2); handle.write('\n')


if __name__ == '__main__':
    main()
