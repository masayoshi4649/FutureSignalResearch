"""凍結Sourceの入力検査だけをoverlayから呼び、原板は開かない。"""

import hashlib
import json
import os
import pathlib
import subprocess

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent.parent
NATIVE = ROOT / "work/強い入口の探索期限を延ばす次仮説/Source入口の再生器"
INPUTS = [
    {"path": str(HERE / "即時のSource入力.json"), "sha256": "905cab946d67e368633585219fc9f4fa04efab639104dcecdc6a3d01d18eeb01", "publications": 12809},
    {"path": str(HERE / "遅延60秒のSource入力.json"), "sha256": "8cc73c58fcf90968d177913bfdf66bdcacb3a98aa6ca1a787a35ad9301349139", "publications": 12794},
]


# ----------------------------------------
def fingerprint(path):
    """機能: 指定ファイルだけを指紋化する。引数: path(Path)。返り値: dict。"""
    with path.open("rb") as stream:
        sha = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": path.stat().st_size, "sha256": sha}


# ----------------------------------------
def source_fingerprints():
    """機能: 凍結exeとSource依存コードを指紋化する。引数: なし。返り値: list[dict]。"""
    paths = [NATIVE / "Source入口.exe"]
    for folder in (NATIVE, ROOT / "work/118複数技法の入口条件", ROOT / "work/121入口の反転切替"):
        paths.extend(sorted(folder.rglob("*.go")))
        paths.extend(sorted(folder.glob("go.*")))
    return [fingerprint(path) for path in paths]


# ----------------------------------------
def save(path, value):
    """機能: UTF-8のJSON証跡を保存する。引数: path(Path),value(dict)。返り値: None。"""
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


# ----------------------------------------
def main():
    """機能: 限定3人工・型検査を実行する。引数: なし。返り値: None。"""
    virtual = NATIVE / "独立Raw公表準備_test.go"
    if virtual.exists():
        raise ValueError("overlay先が物理的に存在する")
    overlay = {"Replace": {str(virtual): str(HERE / "独立型検査_test.go")}}
    save(HERE / "独立overlay.json", overlay)
    before = source_fingerprints()
    if before[0]["sha256"] != "e6d216ffbbc9ec8d640d5d482d163de3ac289c1f46392469abb9d66eb47a905e":
        raise ValueError("凍結exe不一致")
    input_before = [fingerprint(pathlib.Path(item["path"])) for item in INPUTS]
    for spec, actual in zip(INPUTS, input_before):
        if spec["sha256"] != actual["sha256"]:
            raise ValueError("Root派生入力SHA不一致")
    environment = dict(os.environ)
    environment["FSR_RAW_PREPARATION_INPUTS"] = json.dumps(INPUTS, ensure_ascii=False)
    command = ["go", "test", "-overlay=" + str(HERE / "独立overlay.json"), "-run", "^TestRawPublicationsPreparation", "-count=1", "-json", "."]
    result = subprocess.run(command, cwd=NATIVE, env=environment, capture_output=True, encoding="utf-8", errors="strict", check=False)
    (HERE / "独立型検査の実行ログ.jsonl").write_text(result.stdout, encoding="utf-8")
    (HERE / "独立型検査の標準エラー.txt").write_text(result.stderr, encoding="utf-8")
    events = [json.loads(line) for line in result.stdout.splitlines() if line.strip().startswith("{")]
    passed = [e["Test"] for e in events if e.get("Action") == "pass" and e.get("Test")]
    failed = [e for e in events if e.get("Action") in ("fail", "skip")]
    if result.returncode or len(passed) != 3 or failed:
        raise ValueError("限定型検査失敗: " + result.stderr + result.stdout[-6000:])
    after = source_fingerprints()
    input_after = [fingerprint(pathlib.Path(item["path"])) for item in INPUTS]
    if before != after or input_before != input_after or virtual.exists():
        raise ValueError("Sourceまたは入力の変更")
    proof = {"success": True, "checks": passed, "command": command, "cwd": str(NATIVE),
             "raw_opened": False, "source_replayed": False, "finance_read": False,
             "source_exe_rebuilt": False, "native_validation_only": True,
             "inputs_before": input_before, "inputs_after": input_after,
             "frozen_before": before, "frozen_after": after, "unchanged": True,
             "checker": fingerprint(HERE / "独立型検査_test.go"), "runner": fingerprint(pathlib.Path(__file__).resolve()),
             "overlay": fingerprint(HERE / "独立overlay.json"), "log": fingerprint(HERE / "独立型検査の実行ログ.jsonl")}
    save(HERE / "独立型検査の確認.json", proof)
    print(json.dumps({"success": True, "proof": fingerprint(HERE / "独立型検査の確認.json"), "passed": passed}, ensure_ascii=True))


if __name__ == "__main__":
    main()
