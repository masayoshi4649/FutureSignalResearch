"""134の三取得集合を固定して凍結133正逆kernelと134集計器を明示実行する。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
OWN = ROOT / 'work/134公表時計の評価'
FIXED = OWN / '固定入力/固定取得入力.json'
META = OWN / '固定入力/方向と出生.json'
AGG = ROOT / 'work/134公表時計別の集計'
KERNEL = ROOT / 'work/133固定取得の正逆評価器/固定取得の正逆評価.exe'
FORMAL = ROOT / 'study/00134_Raw公表時計で複合入口を再生成する'
HELPER = ROOT / 'work/133金融前を固定して実行する.py'


def sha(path: Path) -> str:
    """
    機能: 全ファイルの指紋を求める。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def load(path: Path, name: str) -> object:
    """
    機能: mainを呼ばずに宣言と検査関数を読み込む。
    引数: path(Path)、name(str)。
    返り値: objectはmodule。
    """
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec); spec.loader.exec_module(result)
    return result


# ----------------------------------------
def main() -> None:
    """
    機能: 金融前F1固定、正逆観測、集計の三段階を分離して実行する。
    引数: CLI --mode(str、固定/再生/集計)。
    返り値: None。主N0と全場参加を結果後に交換しない。
    """
    parser = argparse.ArgumentParser(description='134の金融前固定と正逆観測')
    parser.add_argument('--mode', choices=('固定', '再生', '集計'), required=True)
    args = parser.parse_args()
    helper = load(HELPER, '凍結133の検査関数')
    f1 = OWN / 'F1.json'
    if args.mode == '固定':
        f0 = json.loads((OWN / 'F0.json').read_text('utf-8')); helper.verify(f0)
        assert sha(FIXED) == '5dafeceae9fe87c98e7d487f924f96c56d817cf00bc5a4a96379cb7377d2c526'
        assert sha(META) == '5f3442a81ce06916a94bb433f48befe5ec4cca6bec7154db18aa17cf1b2e1eb4'
        declared = load(AGG / '集計する.py', '134の金融前宣言')
        assert all(sha(path) == expected for path, expected in declared.SOURCES.items())
        files = {Path(path) for path in f0['ファイル']} | set(declared.SOURCES)
        files.update((OWN / 'F0.json', OWN / '出生段階の完了.json', OWN / 'instantのSource出生.json',
                      OWN / 'delayのSource出生.json', FIXED, META, OWN / '固定入力/転送の確認.json',
                      ROOT / 'work/134出生を固定入力へ渡す.py', ROOT / 'work/133Source取得を固定入力へ渡す_版2.py',
                      HELPER, Path(__file__).resolve()))
        for folder in (FORMAL, AGG):
            files.update(p for p in folder.rglob('*') if p.is_file() and p.suffix in ('.py', '.md', '.json'))
        helper.save(f1, {'成功': True, '試行': 134, '段階': '金融前F1', 'UTC': datetime.now(timezone.utc).isoformat(),
             '主': 'N0/Raw即時L0複合、全73場最低1取得と実BBO/H60±125先着70%の両条件',
             '政策': ['N0', 'D0', 'C0', 'O0', 'R0'], 'Sourceと正逆kernel版': 133,
             '副結果で主を交換しない': True, 'ファイル': {str(p): sha(p) for p in sorted(files)}})
        print(json.dumps({'F1_SHA256': sha(f1), 'ファイル数': len(files)}, ensure_ascii=False)); return
    fixed = json.loads(f1.read_text('utf-8')); helper.verify(fixed)
    output = OWN / '固定取得の正逆観測.json'
    if args.mode == '再生':
        command = [str(KERNEL), '--input', str(FIXED), '--sha256', sha(FIXED), '--output', str(output), '--workers', '8']
        subprocess.run(command, cwd=ROOT, check=True); helper.verify(fixed)
        helper.verify_result(json.loads(output.read_text('utf-8')), json.loads(FIXED.read_text('utf-8')))
        helper.save(OWN / '正逆観測の完了.json', {'成功': True, '試行': 134, 'engine_trial': 133,
             'F1_SHA256': sha(f1), '観測SHA256': sha(output), '全固定源前後同体': True, '実行列': command})
        return
    command = [sys.executable, '-X', 'utf8', str(AGG / '集計する.py'), '--f1', str(f1), '--f1-sha256', sha(f1),
               '--fixed-input', str(FIXED), '--fixed-input-sha256', sha(FIXED),
               '--metadata', str(META), '--metadata-sha256', sha(META),
               '--result', str(output), '--result-sha256', sha(output), '--output-dir', str(AGG)]
    subprocess.run(command, cwd=ROOT, check=True); helper.verify(fixed)
    helper.save(OWN / '金融段階の完了.json', {'成功': True, '試行': 134, 'F1_SHA256': sha(f1),
         '全固定源前後同体': True, '集計SHA256': sha(AGG / '集計.json'),
         'CSV用の表SHA256': sha(AGG / 'CSV用の表.json'), '実行列': command})


if __name__ == '__main__':
    main()
