"""既存選択q0の代数的な回復維持と端突破を別票として診断する。"""
from pathlib import Path
import copy
import hashlib
import importlib.util
import json
import math

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
BASE=ROOT/'work/149局面の位置と急変と実反転の診断'
SOURCE=BASE/'診断する.py'
DIAGNOSIS=BASE/'診断.json'
FEATURES=ROOT/'work/148全1分母集団の評価/母集団生成/当時特徴.json'
CATALOG=ROOT/'inputs/00148_全1分入口母集団/100特徴の列定義.json'
SPEC=HERE/'追加区分の事前固定.md'
EXPECTED={SOURCE:'963044ab01273131755f4f6df963af986e49a44d0100fa6258c4b340f1e9140a',DIAGNOSIS:'75ffae522c33069121b739be2294b93bb8982e82743c5fc3612936d01d91cb34',FEATURES:'572705d7db8529555c876eb1953f7d8e1cd1de0e554bf9de729a7d377e4d91af',CATALOG:'c85223fbe1543e5457c28d4391f817534099d1af1d19664035c668ff5fe8a7b4',SPEC:'a746042cc9f410d05ba08f927d21a135c1c0dc13c52aa5a0d389ce1ec9f58813'}
KEYS=('m1_body_reclaim_atr5_to_side','q0_last_minus_m1_close_atr5_to_side','q0_last_minus_prior3_forward_edge_atr5_to_side')
RECOVERY_BRANCHES=('T1','R2','R3','R4')


def load_source():
    """
    機能: 停止済み元診断の純集計関数だけを読み込む。
    引数: なし。返り値: ModuleType。
    """
    spec=importlib.util.spec_from_file_location('fixed149diagnosis',SOURCE);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


def recovery(body,last_close) -> tuple:
    """
    機能: q0の生存回復を指定2列の和だけで分類する。
    引数: body/last_close(float又はNone)。返り値: tuple[str,float又はNone]。
    """
    if body is None or last_close is None:return '未知',None
    value=body+last_close;assert math.isfinite(value)
    return ('>0'if value>0 else '=0'if value==0 else '<0'),value


def breakout(edge,last_close) -> tuple:
    """
    機能: r終値端突破とq0Last端突破の既知維持を区別する。
    引数: edge/last_close(float又はNone)。返り値: tuple[str,float又はNone]。
    """
    if edge is None or last_close is None:return '未知',None
    close=edge-last_close;assert math.isfinite(close)
    category='確認後に既に失敗'if close>0 and edge<=0 else '維持'if close>0 and edge>0 else '未突破等'
    return category,close


def main() -> None:
    """
    機能: 先固定追加区分を選択済みq0だけへ結合し前後期の正逆を残す。
    引数: なし。返り値: None。
    """
    module=load_source();assert all(module.sha(p)==h for p,h in EXPECTED.items());before={**EXPECTED,Path(__file__):module.sha(Path(__file__))}
    original=json.loads(DIAGNOSIS.read_bytes());sessions=original['全73場'];rows=[copy.deepcopy(r)for r in original['詳細']if r['branch']in (*RECOVERY_BRANCHES,'T4')]
    needed={r['event_id']for r in rows};indices={c['name']:i for i,c in enumerate(json.loads(CATALOG.read_bytes()))};projected={}
    for record in module.array_items(FEATURES,'rows'):
        if record['event_id']in needed:
            assert record['event_id']not in projected
            projected[record['event_id']]={side:{key:record[side]['x'][indices[key]]for key in KEYS}for side in ('buy','sell')}
    assert set(projected)==needed
    for row in rows:
        values=projected[row['event_id']]['buy'if row['selected_side']==1 else 'sell'];row['追加原値']=values
        row['生存回復群'],row['生存回復値']=recovery(values[KEYS[0]],values[KEYS[1]])
        row['突破維持群'],row['rClose突破値']=breakout(values[KEYS[2]],values[KEYS[1]])
    groups={}
    for part,scope in [('all',sessions),('train',sessions[:48]),('validation',sessions[48:])]:
        groups[part]={}
        for branch in (*RECOVERY_BRANCHES,'T4'):
            selected=[r for r in rows if r['session']in scope and r['branch']==branch];name='生存回復群'if branch in RECOVERY_BRANCHES else '突破維持群';levels=('>0','=0','<0','未知')if branch in RECOVERY_BRANCHES else ('確認後に既に失敗','維持','未突破等','未知')
            bins={level:module.paired([r for r in selected if r[name]==level])for level in levels};assert sum(x['元方向']['件数']for x in bins.values())==len(selected)
            assert module.paired(selected)==original['24対照と層別'][part][branch]['全取得']
            groups[part][branch]={'全取得':module.paired(selected),'群':bins}
    assert all(module.sha(p)==h for p,h in before.items())
    output={'成功':True,'用途':'全期事後のq0維持状態診断。元bin不変更・新条件採用なし。','追加区分票SHA256':EXPECTED[SPEC],'全73場':sessions,'全期既使用':True,'q1で群を決めない':True,'元side群を実逆にも維持':True,'前後':groups,'詳細':rows,'限界':'保存floatの指定加減算を厳密0分類。事後・小群・近接依存・複数比較。'}
    with (HERE/'追加診断.json').open('x',encoding='utf-8')as target:json.dump(output,target,ensure_ascii=False,indent=2,allow_nan=False);target.write('\n')
    with (HERE/'追加診断の確認.json').open('x',encoding='utf-8')as target:json.dump({'成功':True,'元対照全一致':True,'前後SHA一致':True,'原bin票変更':False,'源':{str(p.relative_to(ROOT)).replace('\\','/'):h for p,h in before.items()},'出力SHA256':module.sha(HERE/'追加診断.json'),'延べ所属数':len(rows),'uniqueq0数':len(needed)},target,ensure_ascii=False,indent=2);target.write('\n')
    print(json.dumps({'成功':True,'延べ':len(rows),'uniqueq0':len(needed),'出力SHA256':module.sha(HERE/'追加診断.json')},ensure_ascii=False))


if __name__=='__main__':
    main()
