"""追加代数式の厳密境界と未知・非改変を自然なしで確認する。"""
from pathlib import Path
import importlib.util
import unittest

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('supplement149',HERE/'追補を計算する.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


class Tests(unittest.TestCase):
    """新採用せず代数分類だけを確認する。"""

    def test_生存回復の0境界(self) -> None:
        """
        機能: 終値回復後のq0喪失・等号・維持を区別する。
        引数: self(Tests)。返り値: None。
        """
        self.assertEqual(m.recovery(.5,-.6)[0],'<0');self.assertEqual(m.recovery(.5,-.5),('=0',0));self.assertEqual(m.recovery(.5,-.4)[0],'>0');self.assertEqual(m.recovery(None,0),('未知',None))

    def test_端突破の等号と未知(self) -> None:
        """
        機能: rClose>0かつ現Last<=0だけを失敗とし未知を推定しない。
        引数: self(Tests)。返り値: None。
        """
        self.assertEqual(m.breakout(0,-.5),('確認後に既に失敗',.5));self.assertEqual(m.breakout(.1,-.4),('維持',.5));self.assertEqual(m.breakout(.1,.1),('未突破等',0));self.assertEqual(m.breakout(None,-.4),('未知',None))


if __name__=='__main__':
    unittest.main(verbosity=2)
