"""追加の固定群結果を転記し、新規採用せず停止する。"""
from pathlib import Path
import ast
import hashlib
import json
import os
import subprocess
import sys

HERE=Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 小成果をbytesから指紋化する。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 追加2人工をUTF-8で記録し、全群短報と停止指紋を保存する。
    引数: なし。返り値: None。
    """
    for path in HERE.glob('*.py'):ast.parse(path.read_text(encoding='utf-8'))
    process=subprocess.run([sys.executable,'-X','utf8',str(HERE/'人工検査.py')],capture_output=True,env={**os.environ,'PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8','PYTHONDONTWRITEBYTECODE':'1'})
    stdout=process.stdout.decode('utf-8','strict');stderr=process.stderr.decode('utf-8','strict');assert process.returncode==0 and '\ufffd'not in stdout+stderr
    with (HERE/'人工の確認.json').open('x',encoding='utf-8')as target:json.dump({'成功':True,'人工主群':2,'構文':True,'UTF8_strict':True,'標準出力':stdout,'標準エラー':stderr},target,ensure_ascii=False,indent=2);target.write('\n')
    data=json.loads((HERE/'追加診断.json').read_bytes())
    text=['# 149 現在Lastによる回復維持と突破失敗の追補','','元の固定5区分診断を停止した後、Rootが指定した追加の代数式を別票で先固定した。149の選択/Source/正式/金融は不変更。新条件採用はしていない。全期既使用・事後・複数比較であり、前48/後25を未知期とは呼ばない。','','選択済みT1/R2/R3/R4/T4の延べ773所属・uniqueq0 740だけを再結合した。元診断で保存BBO quoteから再計算済みの同q1正逆を使い、各枝/期間の全対照は元票と一致した。q1で群を決めず、元選択sideの群を実逆でも維持した。','','## 全期の追加群','','F/A/N/CはH60±125の順先着/逆先着/未到達/不足。IFDではH不足でも既知touchを残す。','','| 枝 | q0状態 | 件数 | 元 F/A/N/C | 元C5円 | 逆 F/A/N/C | 逆C5円 | 元/逆IFD未知 |','|---|---|---:|---|---:|---|---:|---|']
    for branch,value in data['前後']['all'].items():
        for name,pair in value['群'].items():
            a=pair['元方向'];b=pair['実逆'];text.append(f"| {branch} | {name} | {a['件数']} | {'/'.join(str(a[k])for k in 'FANC')} | {a['C5差引']} | {'/'.join(str(b[k])for k in 'FANC')} | {b['C5差引']} | {a['IFD未知']}/{b['IFD未知']} |")
    text+=['','## T4の前後期と解釈','','| 期間 | q0状態 | 件数 | 元 F/A/N/C | 逆 F/A/N/C | 元C5円 | 逆C5円 |','|---|---|---:|---|---|---:|---:|']
    for part in ('train','validation'):
        for name,pair in data['前後'][part]['T4']['群'].items():
            a=pair['元方向'];b=pair['実逆'];text.append(f"| {part} | {name} | {a['件数']} | {'/'.join(str(a[k])for k in 'FANC')} | {'/'.join(str(b[k])for k in 'FANC')} | {a['C5差引']} | {b['C5差引']} |")
    text+=['','T4はr.Closeで先行3足方向端を越えていても、q0Lastがその端以下へ戻っていた26件がある。元3F/17A/4N/2C・−230,002円に対し同q1実逆16F/4A/4N/2C・+112,998円。実逆の到達済率は80%だが全26件分母では61.54%、全期間を見た後の小群であり、新売買規則の達成や採用とはしない。前17件は逆10F/2A、後9件は6F/2Aだが、どちらも未知期ではない。','',
        'ただし端突破を維持していた20件も元5F/12Aから逆11F/6Aへ改善する。逆IFDには未知2があり、単純な逆合計差186,154円と両IFD既知だけのペア差158,000円は別である。「確認後失敗」だけでT4全悪化を説明できない。一方「未突破等」18件は元9F/7A・+12,614円、逆6F/10A・−83,386円で逆効果になる。','',
        '## 生存回復の符号は一律の良否でない','',
        '- R3の生存回復<0は25件で元14F/6A・+93,152円、逆4F/17A・−210,848円。q0でp.Openを下回ることを、将来の回復失敗又は逆張り優位と断定できない。より低い取得位置、別の背景、回復経路も交絡しうる。','- R2の生存回復>0は86件で元21F/41A・−288,698円、逆38F/24A・+11,225円。後期26件のH不足11件も落とさない。維持していても長期逆行側の入口が正しいという保証はない。','- T1は>0の246件でも元78F/101A・−554,172円。維持だけでは救済しない。T1<0群は前期実逆が悪化、後期は改善と符号が分かれる。','- R4は>0/=0/<0のどの元群も費用後負。単一のp.Open維持条件だけに不達原因を集約できない。','',
        '次の問いは、足の完成時に成立した証拠と、知得時点でその構造が保たれているかを分離することである。特にT4の「rClose端突破→知得時には端へ復帰」は出生時点で観測可能な別状態として次仕様で固定する候補になる。ただし同じ形の境界をR3等へ一律に移植せず、今回の良い群だけを選んだ新成績は作っていない。','',
        '## 再現と限界','',
        '追加区分の事前固定.md→人工検査.py→追補を計算する.py→短報を保存する.pyの順。前後期の全群・原値・未知・実側行列・両側IFD既知差は追加診断.json。全入力と停止済み元診断のSHAを固定し、元票へ追記していない。','',
        '計算は保存100Xの指定加減算を用いる。数学的に同じ価格差でもfloatの厳密0分類であり、許容差や後付け丸めを入れていない。近接H60窓の依存/場集中は元診断の要約を継承し、773所属を独立標本又は実口座取引数とは呼ばない。']
    with (HERE/'短報.md').open('x',encoding='utf-8')as target:target.write('\n'.join(text)+'\n')
    files=sorted(p for p in HERE.iterdir()if p.is_file()and p.name!='停止.json')
    proof={'成功':True,'編集停止':True,'元5bin票不変更':True,'149源変更':False,'新条件採用':False,'停止ファイル':[{'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p)}for p in files]}
    with (HERE/'停止.json').open('x',encoding='utf-8')as target:json.dump(proof,target,ensure_ascii=False,indent=2);target.write('\n')
    print(json.dumps({'成功':True,'停止SHA256':sha(HERE/'停止.json')},ensure_ascii=False))


if __name__=='__main__':
    main()
