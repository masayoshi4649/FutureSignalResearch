"""Root選択器をimportせず149の全q0と政策接続を別評価する。金融・Rawは読まない。"""
from pathlib import Path
from collections import Counter
import hashlib
import json
import math
import operator

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
BASE = ROOT / 'work/149可読8局面の評価'
SELECTED = BASE / '入口選択'
MOTHER = ROOT / 'work/148全1分母集団の評価/母集団生成'
FORMAL = ROOT / 'study/00149_継続と反転を可読8局面で判定する'
RULES = ROOT / 'work/149候補_可読8局面.json'
F0 = BASE / 'F0入口選択前.json'
F1 = BASE / 'F1入口選択後.json'
PINS = {
    F0: '413131894254c0afc0115583b95b1e2725a3dfc259ebe099d06f33d52d96d7ab',
    F1: '606aa4436b36db9c2df89d10bc1f9c9d9947a4bb1a3ab4372bc2ee4684fd7dde',
    RULES: 'bbb4f2dee4dc05007309351222205f76b3cca8d628b2ff436a835049c7cb67ad',
    MOTHER / '当時特徴.json': '572705d7db8529555c876eb1953f7d8e1cd1de0e554bf9de729a7d377e4d91af',
    MOTHER / '取得対応.json': 'e433b79f87411c34232acac57a8aed191da71bcd1888376b19196099cbf9909a',
    MOTHER / '入口参照.json': '66511104a6efd7bc936b0e624469a2de43e9fa5b5fa7645304499f793c25329c',
    SELECTED / 'q0の判断.json': '3ef42f65f50db41f243dd753528484dee6e90bc20362e6ce87dc37a25de1f2b4',
    SELECTED / '選択対応.json': 'ecb45e18bccad7c8df50dc7edb9908233a453108e73ff41196af328cbb5eeacb',
}
NAMES = ('T1', 'T2', 'T3', 'T4', 'R1', 'R2', 'R3', 'R4', 'OR8')
EXPECTED_COUNTS = {'T1': 442, 'T2': 2328, 'T3': 1212, 'T4': 64,
                   'R1': 31, 'R2': 127, 'R3': 59, 'R4': 81, 'OR8': 4085, 'C1': 87, 'U0': 4156}


def fingerprint(path: Path) -> dict:
    """
    機能: 明示した非金融入力だけを全bytes指紋で確認する。
    引数: path(Path)。返り値: dictはpath/bytes/mtime_ns/SHA256。
    """
    before = path.stat(); h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''): h.update(block)
    after = path.stat()
    assert before.st_size == after.st_size and before.st_mtime_ns == after.st_mtime_ns
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': before.st_size,
            'mtime_ns': before.st_mtime_ns, 'sha256': h.hexdigest()}


def read(path: Path) -> dict:
    """
    機能: 許可された非金融の保存JSONを読む。
    引数: path(Path)。返り値: dict。
    """
    with path.open('r', encoding='utf-8') as stream: return json.load(stream)


def evaluate(values: list, conditions: list, index: dict) -> bool:
    """
    機能: q0配列のみを独立の比較表でAND評価する。
    引数: values(list)、conditions(list)、index(dict)。返り値: bool。
    """
    comparisons = {'>': operator.gt, '>=': operator.ge, '<': operator.lt, '<=': operator.le}
    assert len(values) == 100
    answers = []
    for name, mode, *boundaries in conditions:
        value = values[index[name]]
        if value is None:
            answers.append(False)
            continue
        assert type(value) in (int, float) and math.isfinite(value)
        if mode == '範囲':
            answers.append(boundaries[0] <= value and value <= boundaries[1])
        else:
            answers.append(comparisons[mode](value, boundaries[0]))
    return all(answers)


def main() -> None:
    """
    機能: 全判断を再計算後にだけ取得を結び、政策の全参照を照合する。
    引数: なし。返り値: None。Root selector/金融算術をimportしない。
    """
    paths = list(PINS) + [SELECTED / '選択の確認.json'] + [FORMAL / n for n in ('README.md', '条件.md', '設定と結果.md')]
    before = {p: fingerprint(p) for p in paths}
    assert all(before[p]['sha256'] == expected for p, expected in PINS.items())
    f0, f1 = read(F0), read(F1)
    assert f0['成功'] and f1['成功'] and f0['試行'] == f1['試行'] == 149
    assert f1['F0_SHA256'] == PINS[F0]
    normalized_f0 = {str(Path(p).resolve()).casefold(): h for p, h in f0['ファイル'].items()}
    normalized_f1 = {str(Path(p).resolve()).casefold(): h for p, h in f1['ファイル'].items()}
    snapshots = HERE / '実行前3MD'
    snapshots.mkdir(exist_ok=True)
    snapshot_rows = []
    for p in (FORMAL / n for n in ('README.md', '条件.md', '設定と結果.md')):
        h = before[p]['sha256']; key = str(p.resolve()).casefold()
        assert normalized_f0[key] == normalized_f1[key] == h
        target = snapshots / p.name
        with target.open('xb') as stream: stream.write(p.read_bytes())
        snapshot_rows.append({'元path': p.relative_to(ROOT).as_posix(), '退避': target.relative_to(ROOT).as_posix(), 'sha256': h, 'bytes': before[p]['bytes']})
    (HERE / '実行前3MDの退避.json').write_text(json.dumps({'成功': True, '試行': 149,
        'F0_SHA256': PINS[F0], 'F1_SHA256': PINS[F1], '文書': snapshot_rows,
        '正式文書変更': False}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    book, features, actual_decisions = read(RULES), read(MOTHER / '当時特徴.json'), read(SELECTED / 'q0の判断.json')
    columns = [c['name'] for c in features['catalog']]
    assert len(columns) == len(set(columns)) == 100
    index = {name: i for i, name in enumerate(columns)}
    assert [r['id'] for r in book['ルール']] == list(NAMES[:8])
    assert actual_decisions['成功'] and actual_decisions['試行'] == 149
    assert actual_decisions['q1結合前に全件判断'] and not actual_decisions['金融ラベル利用']
    actual_by_id = {r['event_id']: r for r in actual_decisions['rows']}
    assert len(actual_by_id) == len(actual_decisions['rows']) == len(features['rows']) == 35339
    decisions = []
    conflict = 0
    hits_by_rule = {name: Counter() for name in NAMES[:8]}
    # ----------------------------------------
    # q1/capture/metaをまだ読まず、全35,339件の比較式を独立評価する。
    for row in features['rows']:
        commons, hits, directions = {}, {}, {}
        for key, vector, side in (('1', row['buy']['x'], 1), ('-1', row['sell']['x'], -1)):
            commons[key] = evaluate(vector, book['共通'], index)
            hits[key] = []
            for rule in book['ルール']:
                if commons[key] and evaluate(vector, rule['条件'], index):
                    hits[key].append(rule['id']); hits_by_rule[rule['id']][str(side)] += 1
        for name in NAMES:
            passing = {side for side, ids in ((1, hits['1']), (-1, hits['-1'])) if (bool(ids) if name == 'OR8' else name in ids)}
            directions[name] = next(iter(passing)) if len(passing) == 1 else 0
        both = bool(hits['1'] and hits['-1']); conflict += both
        expected = {'共通条件': commons, '成立ID': hits, '方向': directions, 'OR両方向成立': both}
        q = row['metadata']['q0']
        result = {'event_id': row['event_id'], 'session': row['session'], 'contract': row['contract'],
                  'q0_time': q['time'], 'q0_index': q['index'], 'q0_line': q['source_line'], '判断': expected}
        assert actual_by_id[row['event_id']] == result
        decisions.append(result)
    print(json.dumps({'段階': '全q0再評価一致', '判断': len(decisions), 'OR両方向待機': conflict}, ensure_ascii=False), flush=True)
    # ----------------------------------------
    # 判断完成後にだけ148既監査の取得参照を結び、canonicalと政策を別構成する。
    captures, metadata, actual = read(MOTHER / '取得対応.json'), read(MOTHER / '入口参照.json'), read(SELECTED / '選択対応.json')
    sessions = features['sessions']; assert len(sessions) == len(set(sessions)) == 73
    assert sessions == captures['sessions'] == metadata['sessions'] == actual['全73場']
    cap = {r['event_id']: r for r in captures['rows']}
    cases = {r['case_id']: r for r in metadata['population148']['cases']}
    assert set(cap) == {r['event_id'] for r in decisions}
    assert len(cap) == len(captures['rows']) and len(cases) == len(metadata['population148']['cases']) == 31642
    order = {sid: i for i, sid in enumerate(sessions)}
    decisions.sort(key=lambda d: (order[d['session']], d['q0_index'], d['q0_line'], d['event_id']))
    policy, counters = {n: {} for n in NAMES}, {n: Counter() for n in NAMES}
    for d in decisions:
        acq = cap[d['event_id']]
        assert acq['session'] == d['session'] and acq['contract'] == d['contract']
        assert (acq['q0']['time'], acq['q0']['index'], acq['q0']['source_line']) == (d['q0_time'], d['q0_index'], d['q0_line'])
        for name in NAMES:
            side = d['判断']['方向'][name]
            if side == 0: continue
            counters[name]['候補成立'] += 1
            counters[name][acq['status']] += 1
            if acq['status'] != 'filled': continue
            cid = acq['case_id']; case = cases[cid]
            assert case['session'] == d['session'] and case['contract'] == d['contract']
            if cid in policy[name]:
                counters[name]['同物理q1の後発参照'] += 1
                continue
            stream = 'original' if side == case['original_side'] else 'reverse'
            assert stream == acq['buy_stream' if side == 1 else 'sell_stream']
            policy[name][cid] = {'case_id': cid, 'session': d['session'], 'side': side, 'stream': stream,
                'event_id': d['event_id'], 'feature_ref': d['event_id'], 'q0_time': d['q0_time'],
                'q0_index': d['q0_index'], 'q0_line': d['q0_line'], '成立ID': d['判断']['成立ID'][str(side)], 'origin': name}
    controls = {cid: {'case_id': cid, 'session': case['session'], 'side': case['original_side'],
                     'stream': 'original', 'event_id': None, 'feature_ref': None, 'origin': 'C1'}
                for cid, case in cases.items() if case['c1_reused']}
    assert len(controls) == 87
    combined, overlaps = controls.copy(), []
    for cid, row in policy['OR8'].items():
        if cid in controls:
            overlaps.append({'case_id': cid, 'C1方向': controls[cid]['side'], 'OR8方向': row['side'], 'opposite': controls[cid]['side'] != row['side']})
        else: combined[cid] = row
    policy['C1'], policy['U0'] = controls, combined
    expected = {'政策': {n: list(rows.values()) for n, rows in policy.items()},
                '候補と取得': {n: dict(v) for n, v in counters.items()}, '旧C1重複': overlaps,
                '全73場': sessions, '選択時の金融ラベル利用': False, 'C1は後段固定対照としてのみ統合': True}
    for key, value in expected.items(): assert actual[key] == value, key
    counts = {name: len(rows) for name, rows in policy.items()}
    confirmation = read(SELECTED / '選択の確認.json')
    assert counts == EXPECTED_COUNTS == confirmation['政策別取得数'] == f1['政策別取得数']
    assert conflict == confirmation['OR両方向待機数'] == 23
    assert len(overlaps) == 16 and len(policy['U0']) == len(policy['OR8']) + 87 - len(overlaps)
    after = {p: fingerprint(p) for p in paths}
    assert before == after
    result = {'成功': True, '試行': 149, '状態': '選択の独立全件監査を編集停止',
              'F0_SHA256': PINS[F0], 'F1_SHA256': PINS[F1], '全q0判断': len(decisions),
              '共通/全8hits/全8方向/OR方向/競合を全件再算': True,
              '政策別unique取得': counts, '候補/未取得/取得の独立計数': expected['候補と取得'],
              'OR両方向待機': conflict, 'C1重複': len(overlaps), 'C1反対方向でも旧優先': sum(x['opposite'] for x in overlaps),
              '全政策全参照行と順序同体': True, 'canonical/方向/stream/旧87保持': True,
              'F0F1正式3MD退避': snapshot_rows, '母集団取得対応の継承': '148独立全件監査e4d628…と全case補足741995…',
              '選択器import/金融/Raw/追加2場読取': False, 'Source/仕様/F0/F1/正式編集': False,
              '役割境界': '監査者は148純case builder作者だが149 selectorの作者ではない。本票はq0全ルールを別評価し後段全参照を独立再構成。100数式/148firstnormalは既監査と人工を継承',
              '対象入力前後同体': list(before.values()), '監査コード': fingerprint(Path(__file__))}
    target = HERE / '監査の確認.json'
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '停止票SHA256': fingerprint(target)['sha256'], '政策別取得': counts}, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
