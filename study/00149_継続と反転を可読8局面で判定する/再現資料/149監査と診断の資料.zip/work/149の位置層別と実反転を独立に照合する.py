"""149の選択済み局面だけを対象に、q0区分と実BBO正逆の事後診断を照合する。"""
from pathlib import Path
from collections import Counter
import argparse
import hashlib
import importlib.util
import json
import math

ROOT = Path(__file__).resolve().parent.parent
FIELDS = {'EMA位置': 'q0_entry_minus_ema21_atr5_to_side', 'BB位置': 'q0_entry_minus_bbmean_sigma_to_side',
          'RSI急変': 'm5_rsi_delta_to_side', '1分量比': 'm1_volume_relative_prior3',
          '知得時価格差': 'q0_last_minus_m1_close_atr5_to_side'}


def sha(path: Path) -> str:
    """
    機能: 全保持を避け保存bytesのSHAを求める。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1048576), b''):
            digest.update(block)
    return digest.hexdigest()


# ----------------------------------------
def classify(name: str, value: float | None) -> str:
    """
    機能: Rootが事前指定した区間を独自の分岐で評価する。
    引数: name(str)は5軸、value(float|None)は選択方向のq0値。
    返り値: strは重複しない区分。未知は別群。
    """
    if value is None:
        return '未知'
    if name == 'EMA位置':
        return '<−1' if value < -1 else '[−1,0]' if value <= 0 else '(0,1]' if value <= 1 else '>1'
    if name == 'BB位置':
        return '<−1' if value < -1 else '[−1,1]' if value <= 1 else '>1'
    if name == 'RSI急変':
        return '>5' if value > 5 else '≤5'
    if name == '1分量比':
        return '≥2' if value >= 2 else '<2'
    assert name == '知得時価格差'
    return '<−.5' if value < -.5 else '[−.5,.5]' if value <= .5 else '>.5'


# ----------------------------------------
def oriented(case: dict, stream: str) -> dict:
    """
    機能: 保存価格を変更せず元選択方向へ参照を写す。
    引数: case(dict)、stream(str)は固定選択stream。
    返り値: dictはreadonly用途の浅い参照。
    """
    if stream == 'original':
        return case
    assert stream == 'reverse'
    value = dict(case)
    value.update(original=case['reverse'], reverse=case['original'],
                 chart_original=case['chart_reverse'], chart_reverse=case['chart_original'])
    return value


# ----------------------------------------
def main() -> None:
    """
    機能: 全4344所属の値/区分/個別正逆と全層別金融値を別算術で確認する。
    引数: CLI output(Path)は未作成確認票。
    返り値: None。新条件を採用せず、自然Raw/追加場を読まない。
    """
    parser = argparse.ArgumentParser(description='149事後位置診断の独立照合')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    paths = {'diagnosis': ROOT / 'work/149局面の位置と急変と実反転の診断/診断.json',
        'features': ROOT / 'work/148全1分母集団の評価/母集団生成/当時特徴.json',
        'result': ROOT / 'work/148全1分母集団の評価/固定取得の正逆観測.json',
        'math': ROOT / 'work/141金融集計を独立に確認する.py'}
    before = {name: sha(path) for name, path in paths.items()}
    assert before['diagnosis'] == '75ffae522c33069121b739be2294b93bb8982e82743c5fc3612936d01d91cb34'
    assert before['features'] == '572705d7db8529555c876eb1953f7d8e1cd1de0e554bf9de729a7d377e4d91af'
    assert before['result'] == 'd1b4cab8a258203f04b5c1d081f57d10ed2a0c58ce4cc160ef571d5fac0ceffc'
    assert before['math'] == '30bd4aef8c2809699cb013f930cfbce152f3986fe8d3d3cc6b49452104c2269e'
    spec = importlib.util.spec_from_file_location('別算術141位置診断', paths['math'])
    arithmetic = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(arithmetic)
    diagnosis = json.loads(paths['diagnosis'].read_bytes())
    features = json.loads(paths['features'].read_bytes())
    index = {column['name']: i for i, column in enumerate(features['catalog'])}
    projected = {row['event_id']: {side: {name: row[side]['x'][index[field]] for name, field in FIELDS.items()}
                 for side in ('buy', 'sell')} for row in features['rows']}
    del features
    observation = json.loads(paths['result'].read_bytes())
    cases = {case['id']: (scene['session'], case) for scene in observation['scenes'] for case in scene['cases']}
    details = diagnosis['詳細']
    assert len(details) == 4344
    reconstructed = {}
    for row in details:
        values = projected[row['event_id']]['buy' if row['selected_side'] == 1 else 'sell']
        assert row['values'] == values
        assert row['bins'] == {name: classify(name, value) for name, value in values.items()}
        sid, case = cases[row['case_id']]
        assert sid == row['session']
        view = oriented(case, row['stream'])
        assert view['original']['birth']['side'] == row['selected_side']
        reconstructed[(row['branch'], row['case_id'])] = (sid, view)
        for name, reverse in (('native', False), ('inverse', True)):
            expected = arithmetic.calculate([(sid, view)], reverse, 'BBO', 3600, 125)
            state = 'C' if expected['censored'] else 'F' if expected['forward'] else 'A' if expected['adverse'] else 'N'
            assert row[name]['state'] == state and row[name]['ifd_known'] == bool(expected['ifd_known'])
            assert row[name]['net5'] == expected['ifd_net5_sum']
            assert row[name]['points'] == expected['ifd_points_mean']
    assert len(reconstructed) == len(details)
    mapped = {'件数': 'entries', '場数': 'sessions', 'F': 'forward', 'A': 'adverse', 'N': 'neither', 'C': 'censored',
        '到達済率': 'resolved_rate', '完了分母率': 'complete_rate', 'IFD既知': 'ifd_known', 'IFD未知': 'ifd_unknown',
        'C5利益': 'ifd_net5_profit', 'C5損失絶対': 'ifd_net5_loss', 'C5差引': 'ifd_net5_sum', 'PF': 'ifd_net5_pf'}
    groups = cells = 0
    sessions = diagnosis['全73場']
    for part, target in (('all', sessions), ('train', sessions[:48]), ('validation', sessions[48:])):
        for branch, entry in diagnosis['24対照と層別'][part].items():
            scope = [row for row in details if row['branch'] == branch and row['session'] in target]
            tasks = [(entry['全取得'], scope)]
            for axis, bins in entry['単軸'].items():
                tasks.extend((value, [row for row in scope if row['bins'][axis] == label]) for label, value in bins.items())
            for ema, bins in entry['EMA位置×RSI急変'].items():
                tasks.extend((value, [row for row in scope if row['bins']['EMA位置'] == ema and row['bins']['RSI急変'] == rsi])
                             for rsi, value in bins.items())
            for actual, rows in tasks:
                selected = [reconstructed[(row['branch'], row['case_id'])] for row in rows]
                for name, reverse in (('元方向', False), ('実逆', True)):
                    expected = arithmetic.calculate(selected, reverse, 'BBO', 3600, 125)
                    for key, source in mapped.items():
                        value = expected[source]
                        if isinstance(value, float):
                            assert math.isclose(value, actual[name][key], rel_tol=1e-12, abs_tol=1e-8), (part, branch, name, key)
                        else:
                            assert value == actual[name][key], (part, branch, name, key, value, actual[name][key])
                        cells += 1
                pairs = Counter((row['native']['state'], row['inverse']['state']) for row in rows)
                assert actual['元→実逆行列'] == {a: {b: pairs[(a, b)] for b in ('F', 'A', 'N', 'C')} for a in ('F', 'A', 'N', 'C')}
                groups += 1
    assert all(sha(path) == before[name] for name, path in paths.items())
    output = {'成功': True, '試行': 149, '所属行数': len(details), '5特徴と区分の全件一致': True,
        '個別元方向と実逆': len(details) * 2, '群数': groups, '金融値数': cells,
        '作者算術import': False, '未選択取引追加': False, '新ルール採用': False,
        '入力': {str(path.resolve()): before[name] for name, path in paths.items()}}
    with args.output.open('x', encoding='utf-8', newline='\n') as target:
        json.dump(output, target, ensure_ascii=False, indent=2)
        target.write('\n')
    print(json.dumps(output, ensure_ascii=False))


if __name__ == '__main__':
    main()
