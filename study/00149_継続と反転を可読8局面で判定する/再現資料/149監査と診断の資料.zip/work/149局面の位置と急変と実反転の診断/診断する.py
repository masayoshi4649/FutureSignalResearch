"""149の選択済み8枝だけを固定区分で実BBO正逆比較する。"""
from pathlib import Path
from collections import Counter
import hashlib
import json
import math
import re
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
SELECT=ROOT/'work/149可読8局面の評価/入口選択/選択対応.json'
SUMMARY=ROOT/'work/149可読8局面の評価/金融診断/集計.json'
FEATURES=ROOT/'work/148全1分母集団の評価/母集団生成/当時特徴.json'
OBS=ROOT/'work/148全1分母集団の評価/固定取得の正逆観測.json'
CATALOG=ROOT/'inputs/00148_全1分入口母集団/100特徴の列定義.json'
SPEC=HERE/'区分の事前固定.md'
BRANCHES=('T1','T2','T3','T4','R1','R2','R3','R4')
KEYS={'EMA位置':'q0_entry_minus_ema21_atr5_to_side','BB位置':'q0_entry_minus_bbmean_sigma_to_side','RSI急変':'m5_rsi_delta_to_side','1分量比':'m1_volume_relative_prior3','知得時価格差':'q0_last_minus_m1_close_atr5_to_side'}
LEVELS={'EMA位置':('<−1','[−1,0]','(0,1]','>1','未知'),'BB位置':('<−1','[−1,1]','>1','未知'),'RSI急変':('>5','≤5','未知'),'1分量比':('≥2','<2','未知'),'知得時価格差':('<−.5','[−.5,.5]','>.5','未知')}
EXPECTED={SELECT:'ecb45e18bccad7c8df50dc7edb9908233a453108e73ff41196af328cbb5eeacb',SUMMARY:'7b6658adb89b10b8a49096e144aa4f572283f9471083896150c68547079f9082',FEATURES:'572705d7db8529555c876eb1953f7d8e1cd1de0e554bf9de729a7d377e4d91af',OBS:'d1b4cab8a258203f04b5c1d081f57d10ed2a0c58ce4cc160ef571d5fac0ceffc',CATALOG:'c85223fbe1543e5457c28d4391f817534099d1af1d19664035c668ff5fe8a7b4',SPEC:'0f18280890b563cdcd2f52087a9b4f8b085cc450099e783846d6ac68464e0aa5'}


def sha(path: Path) -> str:
    """
    機能: 大型の共有入力を複写せず指紋化する。
    引数: path(Path)。返り値: str。
    """
    h=hashlib.sha256()
    with path.open('rb')as source:
        for block in iter(lambda:source.read(1<<20),b''):h.update(block)
    return h.hexdigest()


def array_items(path: Path,key: str):
    """
    機能: 固定整形JSONの指定トップ配列を1要素ずつ読む。
    引数: path(Path)、key(str)。返り値: Iterator[dict]。
    """
    decoder=json.JSONDecoder();buffer='';found=False
    with path.open(encoding='utf-8')as source:
        while not found:
            chunk=source.read(1<<20)
            if not chunk:raise ValueError('指定配列がない')
            buffer+=chunk;match=re.search(r'(?m)^  "'+re.escape(key)+r'": \[',buffer)
            if match:buffer=buffer[match.end():];found=True
        while True:
            buffer=buffer.lstrip()
            if buffer.startswith(']'):return
            if buffer.startswith(','):buffer=buffer[1:].lstrip()
            try:value,end=decoder.raw_decode(buffer)
            except json.JSONDecodeError:
                chunk=source.read(1<<20)
                if not chunk:raise ValueError('配列の途中で終了')
                buffer+=chunk;continue
            yield value;buffer=buffer[end:]


def bucket(name: str,value) -> str:
    """
    機能: 事前固定した重複しない意味区間へ分類する。
    引数: name(str)、value(float又はNone)。返り値: str。
    """
    if value is None:return '未知'
    assert type(value)in (int,float)and math.isfinite(value)
    if name=='EMA位置':return '<−1'if value<-1 else '[−1,0]'if value<=0 else '(0,1]'if value<=1 else '>1'
    if name=='BB位置':return '<−1'if value<-1 else '[−1,1]'if value<=1 else '>1'
    if name=='RSI急変':return '>5'if value>5 else '≤5'
    if name=='1分量比':return '≥2'if value>=2 else '<2'
    if name=='知得時価格差':return '<−.5'if value<-.5 else '[−.5,.5]'if value<=.5 else '>.5'
    raise ValueError('未採用の区分')


def one(stream: dict) -> dict:
    """
    機能: 保存BBO側とquoteだけからH60±125の状態・C5を再計算する。
    引数: stream(dict)。返り値: dict。
    """
    side=stream['birth']['side'];entry=stream['entry'];price=entry['ask']if side==1 else entry['bid']
    assert side in (-1,1)and stream['entry_price']==price and entry['quote_ok']and 0<entry['bid']<entry['ask']
    outcome=next(o for o in stream['outcomes']if o['seconds']==3600);touch=next(t for t in outcome['touches']if t['width']==125)
    assert (touch['direction']==0)==(touch['quote']is None)
    status='C'if outcome['status']!='complete'else {1:'F',-1:'A',0:'N'}[touch['direction']]
    exit_quote=touch['quote']or(outcome['endpoint']if outcome['status']=='complete'else None)
    net=None;points=None
    if exit_quote is not None:
        mark=exit_quote['bid']if side==1 else exit_quote['ask'];points=side*(mark-price);net=points*100-77-1000
    return {'state':status,'touch_direction':touch['direction'],'ifd_known':exit_quote is not None,'points':points,'net5':net,'ifd_reason':'touch'if touch['quote']else 'endpoint'if exit_quote else 'unknown','ifd_exit_time':exit_quote['time']if exit_quote else None}


def summarize(rows: list,direction: str) -> dict:
    """
    機能: 未到達・不足・未知を落とさず実方向別に集計する。
    引数: rows(list[dict])、direction(str)。返り値: dict。
    """
    values=[r[direction]for r in rows];counts=Counter(v['state']for v in values);known=[v['net5']for v in values if v['ifd_known']];profit=sum(x for x in known if x>0);loss=-sum(x for x in known if x<0);resolved=counts['F']+counts['A']
    return {'件数':len(rows),'場数':len({r['session']for r in rows}),'F':counts['F'],'A':counts['A'],'N':counts['N'],'C':counts['C'],'到達済率':counts['F']/resolved if resolved else None,'完了分母率':counts['F']/(len(rows)-counts['C'])if len(rows)>counts['C']else None,'IFD既知':len(known),'IFD未知':len(rows)-len(known),'C5利益':profit if known else None,'C5損失絶対':loss if known else None,'C5差引':sum(known)if known else None,'PF':profit/loss if loss else None}


def paired(rows: list) -> dict:
    """
    機能: 同一取得の正逆状態行列と両IFD既知の費用後差を示す。
    引数: rows(list[dict])。返り値: dict。
    """
    both=[r for r in rows if r['native']['ifd_known']and r['inverse']['ifd_known']];matrix={a:{b:0 for b in 'FANC'}for a in 'FANC'}
    for row in rows:matrix[row['native']['state']][row['inverse']['state']]+=1
    return {'元方向':summarize(rows,'native'),'実逆':summarize(rows,'inverse'),'元→実逆行列':matrix,'両IFD既知':len(both),'両既知C5差_実逆引く元':sum(r['inverse']['net5']-r['native']['net5']for r in both)if both else None,'元だけ既知':sum(r['native']['ifd_known']and not r['inverse']['ifd_known']for r in rows),'逆だけ既知':sum(r['inverse']['ifd_known']and not r['native']['ifd_known']for r in rows)}


def stratify(rows: list,sessions: list) -> dict:
    """
    機能: 固定5単軸とEMA×RSIだけを全枝・既使用前後で比較する。
    引数: rows(list[dict])、sessions(list[str])。返り値: dict。
    """
    result={}
    for part,scope in [('all',sessions),('train',sessions[:48]),('validation',sessions[48:])]:
        result[part]={}
        for branch in BRANCHES:
            group=[r for r in rows if r['branch']==branch and r['session']in scope]
            one_axis={name:{level:paired([r for r in group if r['bins'][name]==level])for level in levels}for name,levels in LEVELS.items()}
            two_axis={ema:{rsi:paired([r for r in group if r['bins']['EMA位置']==ema and r['bins']['RSI急変']==rsi])for rsi in LEVELS['RSI急変']}for ema in LEVELS['EMA位置']}
            assert all(sum(value['元方向']['件数']for value in bins.values())==len(group)for bins in one_axis.values())
            assert sum(value['元方向']['件数']for column in two_axis.values()for value in column.values())==len(group)
            result[part][branch]={'全取得':paired(group),'単軸':one_axis,'EMA位置×RSI急変':two_axis}
    return result


def main() -> None:
    """
    機能: 先固定区分のもと選択済みq0だけを結合し停止用診断へ保存する。
    引数: なし。返り値: None。
    """
    assert all(sha(path)==expected for path,expected in EXPECTED.items())
    source_files={**EXPECTED,Path(__file__):sha(Path(__file__))};stats_before={str(p):{'bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns}for p in source_files}
    selection=json.loads(SELECT.read_bytes());summary=json.loads(SUMMARY.read_bytes());sessions=selection['全73場'];assert len(sessions)==73
    catalog=json.loads(CATALOG.read_bytes());indices={column['name']:i for i,column in enumerate(catalog)};needed={r['feature_ref']for b in BRANCHES for r in selection['政策'][b]};features={}
    for record in array_items(FEATURES,'rows'):
        if record['event_id']not in needed:continue
        assert record['event_id']not in features
        features[record['event_id']]={'session':record['session'],'contract':record['contract'],'q0':record['metadata']['q0'],'sides':{side:{name:record[side]['x'][indices[key]]for name,key in KEYS.items()}for side in ('buy','sell')}}
    assert set(features)==needed
    cases={};selected_ids={r['case_id']for b in BRANCHES for r in selection['政策'][b]};scene_count=0
    for scene in array_items(OBS,'scenes'):
        assert scene['success'];scene_count+=1
        for case in scene['cases']:
            if case['id']in selected_ids:
                assert case['id']not in cases;cases[case['id']]={'session':scene['session'],'case':case}
    assert scene_count==73 and set(cases)==selected_ids
    rows=[]
    for branch in BRANCHES:
        physical=set()
        for choice in selection['政策'][branch]:
            c=cases[choice['case_id']];feature=features[choice['feature_ref']];q0=feature['q0'];case=c['case'];stream=choice['stream'];inverse='reverse'if stream=='original'else 'original';q1=case[stream]['entry']
            assert c['session']==choice['session']==feature['session']and choice['event_id']==choice['feature_ref']
            assert (q0['time'],q0['index'],q0['source_line'])==(choice['q0_time'],choice['q0_index'],choice['q0_line'])
            assert case[stream]['birth']['side']==choice['side']==-case[inverse]['birth']['side']and case[inverse]['entry']==q1
            key=(choice['session'],feature['contract'],q1['time'],q1['index'],q1['source_line']);assert key not in physical;physical.add(key)
            values=feature['sides']['buy'if choice['side']==1 else 'sell'];bins={name:bucket(name,value)for name,value in values.items()}
            rows.append({'branch':branch,'session':choice['session'],'contract':feature['contract'],'case_id':choice['case_id'],'event_id':choice['event_id'],'selected_side':choice['side'],'stream':stream,'q0_time':q0['time'],'q1_time':q1['time'],'q0_to_q1_seconds':q1['time']-q0['time'],'values':values,'bins':bins,'native':one(case[stream]),'inverse':one(case[inverse])})
    result=stratify(rows,sessions)
    for part in result:
        for branch in BRANCHES:
            actual=result[part][branch]['全取得']['元方向'];expected=summary['集計'][part][branch]['BBO']['3600']['125']
            for a,b in [('件数','entries'),('F','forward'),('A','adverse'),('N','neither'),('C','censored'),('IFD既知','ifd_known'),('IFD未知','ifd_unknown'),('C5利益','ifd_net5_profit'),('C5損失絶対','ifd_net5_loss'),('C5差引','ifd_net5_sum')]:assert actual[a]==expected[b],(part,branch,a)
    assert all(sha(path)==expected for path,expected in source_files.items())
    assert stats_before=={str(p):{'bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns}for p in source_files}
    output={'成功':True,'試行':149,'用途':'選択済み8枝の固定区分による事後原因診断。新売買規則の採用なし。','区分票SHA256':EXPECTED[SPEC],'区分軸':KEYS,'全73場':sessions,'枝間重複所属加算禁止':True,'全期既使用':True,'実逆は1-pでない':True,'q0実側とq1価格は別':True,'24対照と層別':result,'詳細':rows,'元枝24対照は固定149と一致':True}
    target=HERE/'診断.json'
    with target.open('x',encoding='utf-8')as f:json.dump(output,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
    proof={'成功':True,'新条件採用':False,'Raw又はCSV追加読取':False,'未選択特徴の使用':False,'全枝case重複なし':True,'源':[{'path':str(p.relative_to(ROOT)).replace('\\','/'),'sha256':h,**stats_before[str(p)]}for p,h in source_files.items()],'全源前後SHA_stat同体':True,'出力SHA256':sha(target),'選択枝延べ件数':len(rows),'unique選択case':len(cases),'unique選択q0':len(needed)}
    with (HERE/'診断の確認.json').open('x',encoding='utf-8')as f:json.dump(proof,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps({'成功':True,'選択枝延べ':len(rows),'unique取得':len(cases),'出力SHA256':sha(target)},ensure_ascii=False))


if __name__=='__main__':
    main()
