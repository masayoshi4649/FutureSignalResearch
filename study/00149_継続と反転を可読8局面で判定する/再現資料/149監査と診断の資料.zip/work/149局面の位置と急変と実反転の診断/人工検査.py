"""固定区分の等号と保存BBO正逆の費用を自然入力なしで確認する。"""
from pathlib import Path
import importlib.util
import json
import tempfile
import unittest

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('diagnosis149',HERE/'診断する.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


def stream(side: int,status: str='complete',touch: int=0) -> dict:
    """
    機能: 同時点で買Ask/売Bidを分ける人工の保存側を作る。
    引数: side(int)、status(str)、touch(int)。返り値: dict。
    """
    entry={'time':100,'last':1000,'bid':995,'ask':1005,'quote_ok':True};end={'time':3700,'bid':995,'ask':1005}
    quote={'time':200,'bid':1130 if side==1 else 870,'ask':1130 if side==1 else 870}if touch else None
    return {'birth':{'side':side},'entry':entry,'entry_price':1005 if side==1 else 995,'outcomes':[{'seconds':3600,'status':status,'endpoint':end if status=='complete'else None,'touches':[{'width':125,'direction':touch,'quote':quote}]}]}


class Tests(unittest.TestCase):
    """自然特徴・金融を使わない4主群。"""

    def test_境界と未知(self) -> None:
        """
        機能: 固定された等号を単一群へ分類し未知を0にしない。
        引数: self(Tests)。返り値: None。
        """
        self.assertEqual([m.bucket('EMA位置',v)for v in [-1.01,-1,0,.01,1,1.01,None]],['<−1','[−1,0]','[−1,0]','(0,1]','(0,1]','>1','未知'])
        self.assertEqual([m.bucket('BB位置',v)for v in [-1,1]],['[−1,1]']*2)
        self.assertEqual(m.bucket('RSI急変',5),'≤5');self.assertEqual(m.bucket('1分量比',2),'≥2')
        self.assertEqual([m.bucket('知得時価格差',v)for v in [-.5,.5]],['[−.5,.5]']*2)

    def test_実側と非相補(self) -> None:
        """
        機能: 横ばいの同q1実正逆が共にspreadと費用で負けることを保つ。
        引数: self(Tests)。返り値: None。
        """
        native=m.one(stream(1));inverse=m.one(stream(-1));self.assertEqual(native['net5'],-2077);self.assertEqual(inverse['net5'],-2077)
        result=m.paired([{'session':'場','native':native,'inverse':inverse}]);self.assertEqual(result['元→実逆行列']['N']['N'],1);self.assertEqual(result['両既知C5差_実逆引く元'],0)

    def test_不足でもtouch優先(self) -> None:
        """
        機能: H不足はCに保持し既知touchの125pt清算を残す。
        引数: self(Tests)。返り値: None。
        """
        result=m.one(stream(1,'censored',1));self.assertEqual(result['state'],'C');self.assertEqual(result['net5'],11423)
        unknown=m.one(stream(1,'censored'));self.assertFalse(unknown['ifd_known']);self.assertIsNone(unknown['net5'])
        empty=m.paired([]);self.assertEqual(empty['元方向']['件数'],0);self.assertIsNone(empty['元方向']['到達済率'])

    def test_配列streamと区分維持(self) -> None:
        """
        機能: 固定JSON配列の引用括弧を破壊せず元向きbinを実逆でも維持する。
        引数: self(Tests)。返り値: None。
        """
        with tempfile.TemporaryDirectory()as folder:
            path=Path(folder)/'人工.json';payload={'rows':[{'text':'括弧 } ] と引用 "'},{'text':'次'}]};path.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
            self.assertEqual(list(m.array_items(path,'rows')),payload['rows'])
        row={'branch':'T1','session':'場','bins':{key:m.bucket(key,0)for key in m.KEYS},'native':m.one(stream(1)),'inverse':m.one(stream(-1))}
        result=m.stratify([row],['場']);group=result['all']['T1']['単軸']['EMA位置']['[−1,0]'];self.assertEqual(group['元方向']['件数'],1);self.assertEqual(group['実逆']['件数'],1)


if __name__=='__main__':
    unittest.main(verbosity=2)
