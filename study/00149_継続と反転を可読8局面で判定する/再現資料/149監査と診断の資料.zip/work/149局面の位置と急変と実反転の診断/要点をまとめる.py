"""固定診断の数値を短報へ写し、名目H60依存と場集中を残す。"""
from pathlib import Path
from collections import Counter
import hashlib
import json

HERE=Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 小成果のbytes指紋を返す。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dependence(rows: list,sessions: list) -> dict:
    """
    機能: 同一枝の名目H60重複連結と0件場を含む場集中を数える。
    引数: rows(list[dict])、sessions(list[str])。返り値: dict。
    """
    counts=Counter(r['session']for r in rows);groups=[]
    for sid in sessions:
        end=None;size=0
        for time in sorted(r['q1_time']for r in rows if r['session']==sid):
            if end is None or time>=end:
                if size:groups.append(size)
                size=1;end=time+3600
            else:size+=1;end=max(end,time+3600)
        if size:groups.append(size)
    n=len(rows)
    return {'取得数':n,'対象場数':len(sessions),'取得場数':len(counts),'未取得場':[s for s in sessions if not counts[s]],'場別':{s:counts[s]for s in sessions},'最小場件数':min((counts[s]for s in sessions),default=0),'最大場件数':max((counts[s]for s in sessions),default=0),'名目H60連結群数':len(groups),'最大連結群件数':max(groups,default=0),'上位5場割合':sum(sorted(counts.values(),reverse=True)[:5])/n if n else None}


def compact(pair: dict) -> dict:
    """
    機能: 元と実逆の件数・状態・率・費用・未知を要約へ残す。
    引数: pair(dict)。返り値: dict。
    """
    return {key:pair[key]for key in ('元方向','実逆','両IFD既知','両既知C5差_実逆引く元','元だけ既知','逆だけ既知')}


def main() -> None:
    """
    機能: 全24対照と事後説明を別小成果に固定し停止票を作る。
    引数: なし。返り値: None。
    """
    data=json.loads((HERE/'診断.json').read_bytes());sessions=data['全73場'];results=data['24対照と層別'];rows=data['詳細']
    output={'成功':True,'試行':149,'全期事後の診断':True,'新条件採用':False,'24対照':{},'近接依存':{},'固定区分の事後引用':{}}
    for part,scope in [('all',sessions),('train',sessions[:48]),('validation',sessions[48:])]:
        output['24対照'][part]={b:compact(v['全取得'])for b,v in results[part].items()}
        output['近接依存'][part]={b:dependence([r for r in rows if r['branch']==b and r['session']in scope],scope)for b in results[part]}
    for branch,axis,level in [('T2','EMA位置','>1'),('T3','EMA位置','>1'),('T2','RSI急変','>5'),('T3','RSI急変','>5'),('R2','EMA位置','>1'),('R3','EMA位置','[−1,0]')]:
        output['固定区分の事後引用'][branch+'/'+axis+'/'+level]={part:compact(results[part][branch]['単軸'][axis][level])for part in results}
    with (HERE/'要約.json').open('x',encoding='utf-8')as f:json.dump(output,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
    text=['# 149 位置・急変・実反転の事後診断','','149全体の未達を知った後に、指定5区分とEMA×RSIだけを先固定して実行した。閾値最適化、未選択例の利益、新規条件の採用は行っていない。全期既使用であり前48/後25とも未知期ではない。','','8枝延べ4,344所属、unique取得4,108、unique選択q0は診断確認票参照。枝内の同q1重複は0。枝間所属は重なり、合計して独立の取得全体としない。元方向24対照は149金融正本のF/A/N/C・費用利益損失・未知と一致した。実逆は保存された反対BBO側から直接計算し、1−pを使わない。','','## 全期の元方向と同q1実逆','','| 枝 | 全件 | 元 F/A/N/C | 元C5円 | 実逆 F/A/N/C | 実逆C5円 | 元/逆IFD未知 |','|---|---:|---|---:|---|---:|---|']
    for b,v in results['all'].items():
        pair=v['全取得'];a=pair['元方向'];z=pair['実逆'];text.append(f"| {b} | {a['件数']} | {'/'.join(str(a[k])for k in 'FANC')} | {a['C5差引']:,} | {'/'.join(str(z[k])for k in 'FANC')} | {z['C5差引']:,} | {a['IFD未知']}/{z['IFD未知']} |")
    text+=['','各IFD合計はそれぞれ既知の集合による。両IFD既知ペア差は診断JSONへ分離し、未知増減で発生した差と混同しない。','','## 当時情報から分かった範囲','','- 件数を占めるT2/T3はq0実側が5分EMA21から元方向へ1ATRを超える群が各1,731/2,328件、1,049/1,212件ある。ただしこの群の実逆C5はT2 −5,024,053円、T3 −2,696,924円で、伸長だけを逆張り理由にはできない。q0の位置でありq1の取得価格を特徴にした値ではない。','- RSI5元方向増分>5はT2で元105F/161Aから実逆143F/123Aへ改善するが、実逆C5は−131,255円、前期+6,064円に対し後期−137,319円。一方T3の同じ急変群は元69F/53A・+91,450円から実逆45F/82A・−751,550円へ悪化する。急変を一律の失速又は継続と解釈できない。','- T4全64件の実逆は33F/20A/7N/4C・+75,226円、前42件21F/12A・+36,843円、後22件12F/8A・+38,383円。元より改善するが全期到達済62.26%で70%未達、小群かつ近接依存もある。新規採用はしていない。','- 長期と逆の新DI方向を取るR2は、q0元側EMA距離>1群92件で元18F/51A・−460,160円から実逆49F/19A・+201,763円。前64件36F/16A・+142,457円、後28件13F/3A・+59,306円。ただしこれは多数の固定区分を見た後の事後関連であり、この群を勝群として抽出・採用していない。元の長期逆行、取得位置、短期回復の役割を次仕様で分離する問いに留める。','- R3の実逆は28F/16A・+109,611円を13F/32A・−326,389円へ壊す。BB下側という位置だけでなく低ADX・前逆実体からの回復を条件とする枝であり、R2/T4との違いを一律反転へ潰せない。','- 1分量比と知得時Last−1分Close差の全群は診断JSONに残した。量の大きさ・知得時の価格跳ねだけで各枝を普遍的に救えるとは示していない。価格と量の未知は別群、量0を未知へ読み替えていない。','','## 取得時計・依存と次の問い','','BB位置もq0買Ask/売Bidのσ比で、Last位置やq1実取得位置とは異なる。全binは元選択sideで一度決まり、実逆の成績でもそのbinを変えていない。100X全件の再転記はせず、選択q0の5列だけを保存した。','','名目[q1,q1+3600)のstrict重複を推移連結し、全73・前48・後25の0件場、最大場件数、最大群、上位5場割合を要約JSONへ保存した。連結群は独立標本数や実保有数ではなく、同時IFD合計は口座収支ではない。','','次に使えるのは「位置や急変の同じ数値でも、順行の突破/量と、長期へ逆らう回復、低強度での新方向を別の状態として扱う」という問いである。R2の伸長・T4の新方向で同じ逆側が改善した事実だけを一般化せず、旧方向維持/構造否定/再受容などの因果順を別仕様で事前固定し、現在の149を変更しない。','','## 再現','','同フォルダの人工検査.pyは自然なし4主群。診断する.pyは先固定区分票/選択/特徴/保存正逆/149正本のSHAを照合し、選択q0だけを読む。要点をまとめる.pyは停止診断から短報と近接依存を生成する。Root許可以外のRaw/CSV/追加2場は使用していない。']
    with (HERE/'短報.md').open('x',encoding='utf-8')as f:f.write('\n'.join(text)+'\n')
    files=[HERE/name for name in ('区分の事前固定.md','診断する.py','人工検査.py','人工の確認.json','診断.json','診断の確認.json','要点をまとめる.py','要約.json','短報.md')]
    proof={'成功':True,'編集停止':True,'新条件又は閾値変更':False,'金融再選択':False,'原Source変更':False,'停止ファイル':[{'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p)}for p in files],'限界':'全期事後・複数固定区分・小群・近接依存。仮説の確証又は新条件採用ではない。'}
    with (HERE/'停止.json').open('x',encoding='utf-8')as f:json.dump(proof,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps({'成功':True,'停止SHA256':sha(HERE/'停止.json')},ensure_ascii=False))


if __name__=='__main__':
    main()
