"""金融ラベルを使わず、確定足End・知得q0・取得q1・当時乖離を分けて集計する。"""
from pathlib import Path
from collections import Counter
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
MOTHER = ROOT / 'work/148全1分母集団の評価/母集団生成'
SEL = ROOT / 'work/149可読8局面の評価/入口選択'
NAMES = ('T1', 'T2', 'T3', 'T4', 'R1', 'R2', 'R3', 'R4', 'OR8')
DATA = {
    MOTHER / '出生台帳.json': '4f4d3ce3a652170d5d5f15941b591493592d5816bb0985c2e70c86b14323b219',
    MOTHER / '当時特徴.json': '572705d7db8529555c876eb1953f7d8e1cd1de0e554bf9de729a7d377e4d91af',
    MOTHER / '取得対応.json': 'e433b79f87411c34232acac57a8aed191da71bcd1888376b19196099cbf9909a',
    SEL / 'q0の判断.json': '3ef42f65f50db41f243dd753528484dee6e90bc20362e6ce87dc37a25de1f2b4',
    SEL / '選択対応.json': 'ecb45e18bccad7c8df50dc7edb9908233a453108e73ff41196af328cbb5eeacb',
}
SOURCES = [ROOT / 'docs/データと閲覧形式.md', ROOT / 'work/板の受信時計と価格時計の再確認/README.md',
           ROOT / 'work/147中位位置からの実体回復/csv.go', ROOT / 'work/147中位位置からの実体回復/decoder.go',
           ROOT / 'work/148全1分候補の当時特徴/catalog.go']


def fingerprint(path: Path) -> dict:
    """
    機能: 許可された派生JSON・文書・コードだけを指紋化する。
    引数: path(Path)。返り値: dictはpath/bytes/mtime_ns/SHA256。
    """
    stat = path.stat(); h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''): h.update(block)
    assert path.stat().st_size == stat.st_size and path.stat().st_mtime_ns == stat.st_mtime_ns
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': stat.st_size,
            'mtime_ns': stat.st_mtime_ns, 'sha256': h.hexdigest()}


def load(path: Path) -> dict:
    """
    機能: 指紋確認済みの非金融派生データを読む。
    引数: path(Path)。返り値: dict。
    """
    with path.open('r', encoding='utf-8') as stream: return json.load(stream)


def distribution(values: list) -> dict:
    """
    機能: 不明を0補完せず、順序統計の線形補間分位点を計算する。
    引数: values(list[float|None])。返り値: dictは件数/平均/分位点。
    """
    known = []
    for x in values:
        if x is None: continue
        assert type(x) in (int, float) and math.isfinite(x)
        known.append(x)
    known.sort()
    result = {'全件': len(values), '既知': len(known), '未知': len(values) - len(known)}
    if not known:
        return {**result, '平均': None, **{k: None for k in ('最小', 'p05', 'p25', '中央値', 'p75', 'p95', 'p99', '最大')}}
    result['平均'] = math.fsum(known) / len(known)
    for name, p in (('最小', 0), ('p05', .05), ('p25', .25), ('中央値', .5), ('p75', .75), ('p95', .95), ('p99', .99), ('最大', 1)):
        pos = (len(known) - 1) * p; low = math.floor(pos); high = math.ceil(pos)
        result[name] = known[low] + (known[high] - known[low]) * (pos - low)
    return result


def sample(eid: str, side: int, ledger: dict, features: dict, captures: dict, index: dict) -> dict:
    """
    機能: 1候補の市場時刻・知得・取得・価格差を分離する。
    引数: eid(str)、side(int)、ledger/features/captures/index(dict)。返り値: dictは非金融値。
    """
    row, x, cap = ledger[eid], features[eid], captures[eid]
    q0, bar = row['q0'], row['latest_bar_ref']
    assert x['session'] == cap['session'] == row['session'] and cap['q0'] == q0
    vector = x['buy' if side == 1 else 'sell']['x']
    gap = vector[index['q0_last_minus_m1_close_atr5_to_side']]
    result = {'q0_minus_end_s': q0['time'] - bar['end'],
              'q0_minus_available_s': q0['time'] - bar['available_at'],
              'last_minus_close_atr_signed': gap, 'last_minus_close_atr_abs': None if gap is None else abs(gap),
              'q1_minus_q0_s': None, 'q1_minus_end_s': None, 'q1_price_minus_q0_price_atr_signed': None}
    assert 60 <= result['q0_minus_end_s'] < 120 and result['q0_minus_available_s'] >= 0
    if cap['status'] == 'filled':
        q1 = cap['q1']; dt = q1['time'] - q0['time']
        assert 1 <= dt < 30
        result['q1_minus_q0_s'] = dt
        result['q1_minus_end_s'] = q1['time'] - bar['end']
        atr = vector[index['m5_atr']]
        if q0['quote_ok'] and atr is not None and atr > 0:
            p0, p1 = (q0['ask'], q1['ask']) if side == 1 else (q0['bid'], q1['bid'])
            result['q1_price_minus_q0_price_atr_signed'] = side * (p1 - p0) / atr
    return result


def summarize(items: list[tuple[str, int]], ledger: dict, features: dict, captures: dict, index: dict) -> dict:
    """
    機能: 同じルール内の候補を集計し、未取得と各指標未知を分ける。
    引数: items(list[tuple[str,int]])、各join辞書(dict)。返り値: dict。
    """
    rows = [sample(eid, side, ledger, features, captures, index) for eid, side in items]
    names = ('q0_minus_end_s', 'q0_minus_available_s', 'last_minus_close_atr_signed', 'last_minus_close_atr_abs')
    status = Counter(captures[eid]['status'] for eid, _ in items)
    result = {'候補数': len(items), '候補場数': len({ledger[eid]['session'] for eid, _ in items}),
              '取得数': status['filled'], '取得場数': len({ledger[eid]['session'] for eid, _ in items if captures[eid]['status'] == 'filled'}),
              '取得終端': dict(status), 'q0全候補': {name: distribution([r[name] for r in rows]) for name in names}}
    taken = [r for r, (eid, _) in zip(rows, items) if captures[eid]['status'] == 'filled']
    result['取得済みだけ'] = {name: distribution([r[name] for r in taken]) for name in rows[0] if name not in names} if rows else {}
    return result


def main() -> None:
    """
    機能: 保存台帳と選択参照だけからルール別の遅延/乖離を記録する。
    引数: なし。返り値: None。閾値探索・ラベル・新時計の自然生成をしない。
    """
    assert distribution([0, 2, None])['中央値'] == 1
    assert distribution([None])['中央値'] is None
    before = {p: fingerprint(p) for p in list(DATA) + SOURCES}
    assert all(before[p]['sha256'] == h for p, h in DATA.items())
    ld = load(MOTHER / '出生台帳.json'); fx = load(MOTHER / '当時特徴.json')
    cp = load(MOTHER / '取得対応.json'); dec = load(SEL / 'q0の判断.json'); selected = load(SEL / '選択対応.json')
    ledger = {r['event_id']: r for r in ld['rows'] if r['eligible']}
    features = {r['event_id']: r for r in fx['rows']}
    captures = {r['event_id']: r for r in cp['rows']}
    assert len(ledger) == len(features) == len(captures) == 35339 and set(ledger) == set(features) == set(captures)
    index = {c['name']: i for i, c in enumerate(fx['catalog'])}
    # ----------------------------------------
    # 全適格の符号は価格上向き基準、ルールの符号は実際の選択side基準と分ける。
    mother = summarize([(eid, 1) for eid in features], ledger, features, captures, index)
    rules = {}
    for name in NAMES:
        candidates = [(d['event_id'], d['判断']['方向'][name]) for d in dec['rows'] if d['判断']['方向'][name] != 0]
        summary = summarize(candidates, ledger, features, captures, index)
        unique = selected['政策'][name]
        assert len(unique) == summary['取得数']
        summary['unique取得数'] = len(unique)
        summary['候補内の買/売'] = dict(Counter('買' if side == 1 else '売' for _, side in candidates))
        rules[name] = summary
    assert before == {p: fingerprint(p) for p in before}
    result = {'成功': True, '確認日': '2026-11-12', '状態': '価格時計と確認遅延の非金融点検・停止',
              '分位点': '既知値を昇順にし(n−1)*pの隣接点を線形補間。未知は別件数',
              '符号': 'ルールは選択side s、全適格母集団だけは買+1の価格上向き基準。abs列は売買不変',
              '単位': '時間は秒、価格乖離はq0のATR5比。取得位置差はs*(P1_s−P0_s)/ATR5',
              '全適格母集団': mother, 'ルール別': rules,
              '政策C1_U0': 'C1には149 q0特徴refがないため遡及で作らず、純T/R/ORを比較。U0の旧87も混ぜない',
              '重複': '同eventが複数ルールへ属し得るためルール間を加算しない。近接H窓/同場依存あり',
              '選択条件の制約': '149共通条件にabs(q0Last−rClose)/ATR5<=1がある。選択群の乖離上限は経験的発見でない',
              'ラベル/金融/Raw/新CSV/追加2場/147Source全文読取': False,
              '147の継承': '148台帳の1分初配送/Start/End/AvailableAtと100特徴は147保存正本を継承したもの',
              '現Source/CSVラベル解釈変更/新入力生成/閾値探索': False,
              '対象前後同体': list(before.values()), 'コード': fingerprint(Path(__file__))}
    target = HERE / '分布の確認.json'
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    brief = {name: {'n': v['候補数'], 'filled': v['取得数'],
                    'age': [v['q0全候補']['q0_minus_end_s'][k] for k in ('中央値', 'p95', '最大')],
                    'latency': [v['取得済みだけ']['q1_minus_q0_s'][k] for k in ('中央値', 'p95', '最大')],
                    'gap_abs': [v['q0全候補']['last_minus_close_atr_abs'][k] for k in ('中央値', 'p95', '最大')]}
             for name, v in rules.items()}
    print(json.dumps({'proof_sha256': fingerprint(target)['sha256'], 'brief': brief,
                      'mother_age': mother['q0全候補']['q0_minus_end_s'],
                      'mother_gap_abs': mother['q0全候補']['last_minus_close_atr_abs']}, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
