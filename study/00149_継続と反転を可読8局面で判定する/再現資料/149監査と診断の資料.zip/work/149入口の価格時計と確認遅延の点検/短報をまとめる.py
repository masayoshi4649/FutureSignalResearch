"""非金融の分布票だけから、時計の意味と追加証拠を分けた短報を作る。"""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 専有成果物の現在bytesを指紋化する。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def value(number: float | None, digits: int = 1) -> str:
    """
    機能: 未知を0補完せず分布値を短く表示する。
    引数: number(float|None)、digits(int)。返り値: str。
    """
    return '—' if number is None else f'{number:.{digits}f}'


def main() -> None:
    """
    機能: 分布JSONと固定文書根拠を結んで短報・停止票だけを保存する。
    引数: なし。返り値: None。金融/Raw/新CSVを開かない。
    """
    data_path = HERE / '分布の確認.json'
    assert sha(data_path) == '7e910fc44b6b1527624b14848a99444a0967c2541bba642a8b5b0adee382c96b'
    data = json.loads(data_path.read_bytes())
    table = '|局面|q0候補/取得|q0−End秒 中央/p95|q1−q0秒 中央/p95|終値→q0Last絶対ATR比 中央/p95|\n|---|---:|---:|---:|---:|---:|\n'
    for name, r in data['ルール別'].items():
        age = r['q0全候補']['q0_minus_end_s']
        latency = r['取得済みだけ']['q1_minus_q0_s']
        gap = r['q0全候補']['last_minus_close_atr_abs']
        table += f"|{name}|{r['候補数']:,}/{r['取得数']:,}|{value(age['中央値'])}/{value(age['p95'])}|{value(latency['中央値'])}/{value(latency['p95'])}|{value(gap['中央値'],3)}/{value(gap['p95'],3)}|\n"
    text = '''# 149入口の価格時計と確認遅延の点検

2026-11-12。**確認時計と取得位置は検証の論点になる。ただし、この集計だけで不振の原因を遅延に帰したり、早くすれば改善すると結論できない。** 金融・先着ラベル・Raw・新CSV・追加2場は読んでいない。現Source・CSV時刻解釈・ルール・閾値は変更していない。

## 三つの時計を分ける

|項目|既存定義と今回の扱い|
|---|---|
|CSVのtime|ローカルの元生成コードでは足開始ラベル。1分はStart=time、End=time+60。closedは生成器の確定旗で、実際のClosedAtはCSVにない|
|研究の知得q0|147/148モデルはAvailableAt=End+60。以後最初の採用Rawで配送し、同Raw最新1分を知る。固定60秒はモデルの使用許可で、実測通信遅延ではない|
|取得q1|別原行・q0+1秒以後・TTL30秒strictの最初正常BBO。秒はRaw CurrentPriceTimeという価格時計で、実受信からの秒数ではない|

元ロガーはreceivedAtで作業分/閉鎖を進め、OHLCの採用には現値時計も使う。一方、book保存はpayloadだけで各行のreceivedAtを持たず、Source readerはCurrentPriceTimeを使用する。同価格時計でも板更新行が複数あり、物理Index/Lineは順序を保持するが実受信間隔を復元しない。静かな無約定と通信欠測を時計差だけで区別しない。

今回のEndは区間境界で、Closeが実際に更新された時刻ではない。Close自体の年齢は確定できない。各日のロガー稼働バイナリ同一性も未証明なので、現コード根拠を理由にCSVラベルを勝手に足終了へ読み替えたり、全時刻を60秒前へずらしたりしない。

根拠は[データと閲覧形式](../../docs/データと閲覧形式.md)、[既停止の時計監査](../板の受信時計と価格時計の再確認/README.md)、147の固定csv.go/decoder.go。147保存1分の初配送/Endは148台帳が継承しており、今回は巨大147 Sourceを再読せず、その派生正本と100特徴を使った。

## 保存された分布

全適格35,339件でq0−Endは最小60秒・中央値63秒・p95 95秒・最大119秒。すなわちモデルの固定60秒に、追加の配送待ち中央値3秒/p95 35秒が重なっている。全取得31,632件のq1−q0は中央値4秒/p95 22秒、q1−Endは中央値69秒/p95 104秒だった。

以下のq0は各ルールで単独の方向が決まった全候補、q1はその取得済み部分だけ。時間は秒、価格差はq0のATR5比。ルール間の重複所属や同場の近接を独立件数として加算しない。

''' + table + '''
OR8の取得4,085件では、q1−Endは中央値68秒/p95 100秒/最大146秒。少なくともモデル上、確定終値のある区間が終わってから約1分以上を経た取得を評価している。これは短い回復パターンの成立点と実際の取得位置を分けて考える理由になる。

一方、OR候補の方向付き(q0Last−r.Close)/ATR5は中央値0、p05約−0.559/p95約+0.547。q1実側価格とq0実側価格の方向付き差も中央値0、p05約−0.193/p95約+0.186だった。取得時の変化は両符号にあり、「待った分だけ常に順方向へ追いかけて不利」とは言えない。正の実側価格差は同方向へ高く/安く追った位置差で、将来の利益/損失そのものではない。

全適格母集団の絶対終値差は既知34,524/未知815、中央値0.215ATR5・p95 0.739ATR5・最大7.908ATR5。**149選択群には共通abs差<=1という制約があるため、その上限内の分布は経験的な良好性の発見ではない。** ATR5比を、そのまま目標125ptの消費率ともしない。旧C1/主U0の旧87には149のq0特徴refがないので、遡及してq0を作らず、純T/R/ORだけを比べた。

全分位点・符号付き/絶対差・既知/未知・未取得status・取得場数は[分布票](分布の確認.json)へ保存した。分位点は既知値を昇順にし(n−1)pの隣接点を線形補間した記述統計で、信頼区間や独立標本数ではない。

## 早い確認時計を別入力で検証する前に必要な証拠

1. **同じCSV完成足を早く知れるとする案**：生成器の版・足のStart/End・Close更新時刻・closed確定時刻・外部公開時刻・受信又は利用可能時刻を対応付ける。CSVのclosed=trueだけではEnd時点に全値を取得できた証明にならない。mtimeやCurrentPriceTimeを受信時計へ置換しない。
2. **Native Raw足へ替える案**：価格種・足区間・無約定/欠測の区別・数量時計/完全性・gap/reset・限月/跨場seed・公表/配送を先に固定し、同EndのOHLC/量/指標/既知性と元CSVとの差を監査する。Native Raw足を検証なしに真実とせず、足形成が違えば「時間だけを早めた比較」と呼ばない。受信時計のない過去Rawはあくまで価格時計モデルとなる。
3. **未確定足の途中回復を使う案**：その原行までのOpen/High/Low/Last/量だけで状態を更新し、将来の完成High/Low/Closeを参照しない。5/15/30背景も同じ時点で配送済みのものだけを使う。後に公表された良い背景へ置き換えず、確認/取消/再準備とq1取得を新仕様で固定する。

ライブ再現を強める収集証拠は、payload又は行hashに結合したreceived_at・receive_seq・価格/量時計・connection/reset・bar revision/ClosedAt・PublishedAtである。現在の保存だけから欠けた時計を補間してはいけない。

## 解釈の境界

この点検は時計・位置の記述で、パターンの心理が成立しなかったか、知得が遅れたため失敗したかを金融結果と結合していない。同じパターンで早い確認をした場合の±125/H60の先着・費用・参加/頻度も未測定。遅延と価格差の大小で後から勝ち群を選ばず、別時計の仮説は別入力・別試行として事前固定する必要がある。現149や147/148を修正する根拠にはしない。
'''
    target = HERE / '時計と取得位置の短報.md'
    target.write_text(text, encoding='utf-8')
    for link in re.findall(r'\]\(([^)]+)\)', text):
        assert (HERE / link).exists(), link
    proof = {'成功': True, '状態': '149入口の時計/位置の非金融点検を編集停止',
             '分布票SHA256': sha(data_path), '短報SHA256': sha(target),
             '分布集計コードSHA256': sha(HERE / '集計する.py'), '短報生成コードSHA256': sha(Path(__file__)),
             'CSV開始/終了ラベル/Source/閾値変更': False,
             'Raw/新CSV/追加2場/149金融ラベル読取': False,
             '表の条件': 'q0は単独方向の全候補、q1は取得済み部分だけ。旧C1は混ぜず未知を0補完しない',
             '金融因果/時計改善の成功を主張': False, '新study採番/新時計自然実行': False}
    result = HERE / '停止の確認.json'
    result.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'proof_sha256': sha(result), 'report_sha256': sha(target)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
