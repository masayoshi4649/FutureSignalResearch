"""149の固定選択と148共有観測を恒久保存だけから再集計する。"""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import subprocess
import sys
import zipfile
from 保存部品 import ROOT, FORMAL, registries, file_sha, json_bytes


def main():
    """未作成workへ必要源を復元し、900比較・原表・累計付表を照合する。

    引数: --destination(str)。返り値: None。Raw/Source/入口再選択を行わない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--destination', required=True)
    args = parser.parse_args()
    destination = (ROOT / args.destination).resolve()
    assert destination.is_relative_to((ROOT / 'work').resolve()) and not destination.exists()
    destination.mkdir(parents=True)
    index = json.loads((FORMAL / '保管索引.json').read_bytes())
    f1 = json.loads((ROOT / index['F1原文']['保存元']).read_bytes())
    f2 = json.loads((ROOT / index['F2原文']['保存元']).read_bytes())
    completion = json.loads((FORMAL / '成果物/集計完了.json').read_bytes())
    by_path, by_sha = registries()
    fingerprints = {}
    for values in (f1['ファイル'], f2['ファイル'], completion['前後SHA256']):
        for name, digest in values.items():
            path = Path(name)
            if not path.is_absolute():
                path = ROOT / path
            fingerprints[path.relative_to(ROOT).as_posix()] = digest
    restored, checked = [], {}

    def restore(rel):
        """一つの源を恒久保存から復元する。

        引数: rel(str)。返り値: Path。復元bytesの期待SHAを必ず確認する。
        """
        expected = fingerprints[rel]
        target = destination / rel
        if target.exists():
            assert file_sha(target) == expected
            return target
        target.parent.mkdir(parents=True, exist_ok=True)
        ref = by_path.get(rel)
        if not ref or ref.get('解凍SHA256') != expected:
            ref = by_sha[expected]
        if '保存元ZIP' in ref:
            source = ROOT / ref['保存元ZIP']
            if source not in checked:
                checked[source] = file_sha(source)
            assert checked[source] == ref['ZIP_SHA256']
            with zipfile.ZipFile(source) as bundle, bundle.open(ref['ZIP内path']) as stream, target.open('xb') as output:
                for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                    output.write(chunk)
        else:
            source = ROOT / ref['保存元']
            assert file_sha(source) == ref['保存SHA256']
            assert ref['形式'] in ('gzip', '同体')
            opener = gzip.open if ref['形式'] == 'gzip' else open
            with opener(source, 'rb') as stream, target.open('xb') as output:
                for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                    output.write(chunk)
        assert file_sha(target) == expected
        restored.append({'path': rel, 'sha256': expected, 'bytes': target.stat().st_size})
        return target

    preparation = restore('work/149可読局面の金融集計/準備の確認.json')
    prep = json.loads(preparation.read_bytes())
    for item in prep['源']:
        rel = Path(item['path']).as_posix()
        fingerprints[rel] = item['sha256']
        restore(rel)
    for rel in (
        *['work/148全1分母集団の評価/母集団生成/' + name + '.json' for name in ('固定取得入力', '入口参照', '出生台帳', '取得対応', '生成の確認')],
        'work/148全1分母集団の評価/固定取得の正逆観測.json',
        'work/149可読8局面の評価/入口選択/選択対応.json',
        'work/149のCSVに既知収支と未知件数の累計を付ける.py'):
        restore(rel)
    replay_f1 = {**f1, 'ファイル': {str(destination / Path(name).relative_to(ROOT)): digest for name, digest in f1['ファイル'].items()},
                 '再現専用': True, '元F1_SHA256': index['F1_SHA256']}
    local_f1 = destination / '再現F1.json'
    local_f1.write_bytes(json_bytes(replay_f1))
    output = destination / '再集計'
    script = destination / 'work/149可読局面の金融集計/集計する.py'
    selection = destination / 'work/149可読8局面の評価/入口選択/選択対応.json'
    command = [sys.executable, '-X', 'utf8', str(script), '--preparation-sha256', file_sha(preparation),
               '--f1', str(local_f1), '--f1-sha256', file_sha(local_f1), '--selection', str(selection),
               '--selection-sha256', file_sha(selection), '--generation-dir', str(destination / 'work/148全1分母集団の評価/母集団生成'),
               '--result', str(destination / 'work/148全1分母集団の評価/固定取得の正逆観測.json'),
               '--result-sha256', index['親148共有観測']['解凍SHA256'], '--output-dir', str(output)]
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (destination / '再実行.txt').write_bytes(result.stdout + result.stderr)
    assert result.returncode == 0, (result.stdout + result.stderr).decode('utf-8', 'replace')
    expected = json.loads((ROOT / index['保存金融正本']['保存元']).read_bytes())
    actual = json.loads((output / '集計.json').read_bytes())
    assert actual['F1_SHA256'] == file_sha(local_f1)
    actual['F1_SHA256'] = expected['F1_SHA256']
    assert actual == expected
    assert file_sha(output / 'CSV用の表.json') == index['元CSV用表SHA256']
    cumulative = output / 'CSV用の表_累計付.json'
    result = subprocess.run([sys.executable, '-X', 'utf8', str(destination / 'work/149のCSVに既知収支と未知件数の累計を付ける.py'),
        '--input', str(output / 'CSV用の表.json'), '--input-sha256', index['元CSV用表SHA256'],
        '--summary', str(output / '集計.json'), '--summary-sha256', file_sha(output / '集計.json'), '--output', str(cumulative)],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    assert result.returncode == 0, (result.stdout + result.stderr).decode('utf-8', 'replace')
    cum = json.loads(cumulative.read_bytes())
    cum['集計SHA256'] = index['保存金融正本']['解凍SHA256']
    normalized = (json.dumps(cum, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode('utf-8')
    assert hashlib.sha256(normalized).hexdigest() == index['保存CSV用の表_累計付']['解凍SHA256']
    proof = {'成功': True, '試行': 149, '復元源': restored, '元F1_SHA256': index['F1_SHA256'],
             '再現F1_SHA256': file_sha(local_f1), '900比較全dict一致': True, '元三表JSONbytes一致': True,
             '累計付表一致': True, '元表SHA256': index['元CSV用表SHA256'],
             '累計付表SHA256': index['保存CSV用の表_累計付']['解凍SHA256'],
             '許容差': 'pathだけの再現F1_SHA256と、それを含む集計SHA256の累計付metadata。数値/セルは完全一致',
             'RawSource又は入口選び直し': False, '元正本上書き': False, '親大観測の恒久再複製': False}
    target = destination / '保存観測からの再現確認.json'
    target.write_bytes(json_bytes(proof))
    print('proof_path=' + str(target.relative_to(ROOT)))
    print('proof_sha256=' + file_sha(target))


if __name__ == '__main__':
    main()
