"""149の正式保存・CSV・再現・独立根拠を最終確認して停止する。"""
from pathlib import Path
import gzip
import hashlib
import json
import re
from urllib.parse import unquote
import zipfile
from 保存部品 import ROOT, FORMAL, save, file_sha, json_bytes


def main():
    """最終小ZIPと確認票を作る。

    引数: なし。返り値: None。新金融探索・Raw走査・次採番を行わない。
    """
    here = Path(__file__).resolve().parent
    runtime = ROOT / 'work/149可読8局面の評価'
    output = ROOT / 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/149_継続と反転の可読8局面'
    index_path = FORMAL / '保管索引.json'
    index = json.loads(index_path.read_bytes())
    summary = json.loads((FORMAL / '成果物/集計.json').read_bytes())
    assert summary['主政策'] == 'U0' and not summary['主評価']['三目標共同']
    with gzip.open(FORMAL / '検査/F1実行前文書.json.gz', 'rb') as stream:
        original = {item['path']: item['本文'].encode('utf-8') for item in json.load(stream)['文書']}
    for name in ('条件.md', '設定と結果.md'):
        assert (FORMAL / name).read_bytes().startswith(original[(FORMAL / name).relative_to(ROOT).as_posix()])
    setting = FORMAL / '設定と結果.md'
    def rows(text):
        """V7本表だけを抽出する。

        引数: text(str)。返り値: list[str]。追加状態表は含めない。
        """
        return [line for line in text.splitlines() if re.match(r'^\|\s*[A-Z]\d{2}\s*\|', line) and len(line.split('|')) == 13]
    assert rows(setting.read_text(encoding='utf-8')) == rows(original[setting.relative_to(ROOT).as_posix()].decode('utf-8'))
    assert len(rows(setting.read_text(encoding='utf-8'))) == 57
    checked = 0
    for name in ('README.md', '条件.md', '設定と結果.md'):
        for line in (FORMAL / name).read_text(encoding='utf-8').splitlines():
            cells = line.split('|')[1:-1]
            if len(cells) != 8:
                continue
            for prefix, part in (('全73場 ', 'all'), ('前48場・既使用 ', 'train'), ('後25場・既使用 ', 'validation')):
                if not cells[0].startswith(prefix):
                    continue
                policy = cells[0][len(prefix):].split()[0]
                d = summary['集計'][part][policy]['BBO']['3600']['125']
                assert int(cells[1].replace(',', '')) == d['entries']
                assert [int(x.replace(',', '')) for x in cells[2].split('/')] == [d[k] for k in ('forward', 'adverse', 'neither', 'censored')]
                assert cells[3] == f"{d['resolved_rate'] * 100:.2f}%"
                assert [int(x.replace(',', '')) for x in cells[4:7]] == [d[k] for k in ('ifd_net5_profit', 'ifd_net5_loss', 'ifd_net5_sum')]
                assert [int(x.replace(',', '')) for x in cells[7].split('/')] == [d['ifd_known'], d['ifd_unknown']]
                checked += 11
    replay = ROOT / 'work/149保存観測の再現/保存観測からの再現確認.json'
    assert file_sha(replay) == '646adde11ff6034fb73a56a9d228933eb1eb125b3f5adc05837d3a188c498890'
    review_dir = ROOT / 'work/149正式結果の原文とリンクの独立確認'
    doc_review = review_dir / '確認の記録.json'
    assert file_sha(doc_review) == 'cc9b03bc1c016e42f7c8b155cbdb251fc56ae3d7c515bc4446010eebc5a1ced3'
    extra_dir = ROOT / 'work/149追加代数診断の独立検査'
    extra_proof = extra_dir / '独立検査の確認.json'
    assert file_sha(extra_proof) == '1e49d4b957db8feb54ab1e08226c13f925533b35a58f8ce33ef04d453ca3399d'
    csv_source = runtime / '金融診断/CSV独立再読.json'
    csv = json.loads(csv_source.read_bytes())
    assert csv['成功'] and csv['全データセル比較数'] == 230823 and csv['数値比較数'] == 102004
    for item in csv['表別']:
        assert file_sha(Path(item['CSV']['path'])) == item['CSV']['sha256']
    receipts = []
    for source, name in ((replay, '保存観測からの再現確認.json'), (doc_review, '正式原文とリンクの独立確認.json'),
                         (extra_proof, '追加代数の独立検査.json'), (csv_source, 'CSV独立再読.json')):
        destination = FORMAL / '検査' / name
        if destination.exists():
            assert file_sha(destination) == file_sha(source)
            receipts.append({'保存元': destination.relative_to(ROOT).as_posix(), '復元先': source.relative_to(ROOT).as_posix(),
                             '形式': '同体', '保存bytes': destination.stat().st_size, '保存SHA256': file_sha(destination),
                             '解凍bytes': source.stat().st_size, '解凍SHA256': file_sha(source)})
        else:
            receipts.append(save(source, destination, file_sha(source)))
    sources = sorted(here.glob('*.py')) + [review_dir / '確認する.py', extra_dir / '検査する.py', extra_dir / '再構成した全群.json']
    sources += [ROOT / 'work/確定三表のCSV出力' / name for name in ('出力する.mjs', 'CSVを独立再読する.py', '由来.json')]
    target = FORMAL / '再現資料/149正式化と再現の資料.zip'
    entries = []
    with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for path in sources:
            name, body = path.relative_to(ROOT).as_posix(), path.read_bytes()
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 12, 0, 0, 0))
            bundle.writestr(info, body, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
            entries.append({'path': name, 'bytes': len(body), 'sha256': file_sha(path)})
    with zipfile.ZipFile(target) as bundle:
        assert all(hashlib.sha256(bundle.read(item['path'])).hexdigest() == item['sha256'] for item in entries)
    new_common = ROOT / 'docs/議論/構造の成立水準と無効水準を局面別に分ける.md'
    images = sorted((output / '支援画像').glob('*.png'))
    assert len(images) == 3
    index.update({'段階': '正式保存完了・主U0共同目標未達・編集停止', '保存観測再現と検算票': receipts,
                  '正式化と再現の資料': {'保存元ZIP': target.relative_to(ROOT).as_posix(), 'ZIP_SHA256': file_sha(target),
                                       'ZIP_bytes': target.stat().st_size, '格納源': entries},
                  'CSV': {item['表名']: {'path': Path(item['CSV']['path']).relative_to(ROOT).as_posix(), 'sha256': item['CSV']['sha256'],
                                       'rows': item['行数'], 'columns': item['列数']} for item in csv['表別']},
                  'CSV表示確認': 'Rootが3PNG目視・marker1回。子自身の目視と区別',
                  '新共通知見': {'path': new_common.relative_to(ROOT).as_posix(), 'sha256': file_sha(new_common)},
                  '正式3MD最終SHA256': {name: file_sha(FORMAL / name) for name in ('README.md', '条件.md', '設定と結果.md')},
                  '主政策': 'U0', '主評価': summary['主評価'], '新政策選び直し': False, '追加採番': False})
    index_path.write_bytes(json_bytes(index))
    paths = [*FORMAL.glob('*.md'), *FORMAL.glob('根拠/*.md'), output / 'README.md', ROOT / 'inputs/00149_可読8局面の選択/README.md',
             ROOT / 'README.md', ROOT / 'docs/README.md', ROOT / 'docs/議論/README.md', ROOT / 'study/README.md', new_common]
    link_count = 0
    for path in paths:
        for link in re.findall(r'\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
            if link.startswith(('http:', 'https:', 'mailto:', '#')):
                continue
            assert (path.parent / unquote(link.split('#')[0])).resolve().exists(), (str(path), link)
            link_count += 1
    proof = {'成功': True, '試行': 149, '状態': '正式保存完了・編集停止',
             'F0_SHA256': index['F0_SHA256'], 'F1_SHA256': index['F1_SHA256'], 'F2_SHA256': index['F2_SHA256'],
             '各固定源数': [index['F0直接源数'], index['F1直接源数'], index['F2直接源数']],
             '選択3正本各一度gzip': True, '親148大入力と観測を共有': True,
             '条件設定prefixと全513セル同体': True, '文書表数値転記比較': checked,
             'Root独立金融': '900比較21600値', 'CSV全セル': 230823, 'CSV数値': 102004,
             '保存観測から900比較全dict/元表/累計付表一致': True, '再現票SHA256': file_sha(replay),
             '原表の恒久重複保存': False, '追加代数独立票SHA256': file_sha(extra_proof),
             'ローカルリンク実在数': link_count, '保管索引SHA256': file_sha(index_path),
             '正式3MD最終SHA256': index['正式3MD最終SHA256'], '新共通知見SHA256': file_sha(new_common),
             '主U0共同目標': False, '追加金融探索/Raw再走査/追加2場読取/次採番': False, '重大不足': []}
    final = FORMAL / '検査/正式保存の最終確認.json'
    final.write_bytes(json_bytes(proof))
    print('final_sha256=' + file_sha(final))
    print('index_sha256=' + file_sha(index_path))
    print('links=' + str(link_count))


if __name__ == '__main__':
    main()
