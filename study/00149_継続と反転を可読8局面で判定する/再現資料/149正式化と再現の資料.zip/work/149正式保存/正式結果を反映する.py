"""149の固定結果をREADME先頭へ整理し、条件/513セルは原文保持する。"""
from pathlib import Path
import gzip
import json
import re
from 保存部品 import ROOT, FORMAL, file_sha, json_bytes


def table(summary, parts, policies, names=None):
    """H60±125の正本をMarkdown表へ転記する。

    引数: summary(dict)、parts/policies(list[str])、names(dict|None)。返り値: str。
    """
    lines = ['|区分・政策|件数|順/逆/未/不足|到達済み率|利益円 C5|損失円 C5|差引円 C5|既知/未知|',
             '|---|---:|---|---:|---:|---:|---:|---|']
    labels = {'all': '全73場', 'train': '前48場・既使用', 'validation': '後25場・既使用'}
    for part in parts:
        for policy in policies:
            d = summary['集計'][part][policy]['BBO']['3600']['125']
            name = policy + (' ' + names[policy] if names and policy in names else '')
            lines.append(f"|{labels[part]} {name}|{d['entries']:,}|{d['forward']:,}/{d['adverse']:,}/{d['neither']:,}/{d['censored']:,}|{d['resolved_rate']*100:.2f}%|{d['ifd_net5_profit']:,}|{d['ifd_net5_loss']:,}|{d['ifd_net5_sum']:,}|{d['ifd_known']:,}/{d['ifd_unknown']:,}|")
    return '\n'.join(lines)


def main():
    """退避済みF1と同体を確認して結果のみ正式化する。

    引数: なし。返り値: None。金融計算やルール選び直しは行わない。
    """
    summary = json.loads((FORMAL / '成果物/集計.json').read_bytes())
    with gzip.open(FORMAL / '検査/F1実行前文書.json.gz', 'rb') as stream:
        original = {item['path']: item['本文'].encode('utf-8') for item in json.load(stream)['文書']}
    for rel, body in original.items():
        current = (ROOT / rel).read_bytes()
        assert current == body or (Path(rel).name != 'README.md' and current.startswith(body)) or (
            Path(rel).name == 'README.md' and current.decode('utf-8').startswith('# 可読8局面の選択・金融検証を完了'))
    original_settings = next(body for rel, body in original.items() if rel.endswith('/設定と結果.md'))
    original_v7 = [line for line in original_settings.decode('utf-8').splitlines()
                   if re.match(r'^\|\s*[A-Z]\d{2}\s*\|', line) and len(line.split('|')) == 13]
    assert len(original_v7) == 57
    rules = json.loads((ROOT / 'work/149候補_可読8局面.json').read_bytes())
    names = {rule['id']: rule['名称'] for rule in rules['ルール']}
    all_main = table(summary, ['all'], ['C1', 'OR8', 'U0', 'RC1', 'ROR8', 'RU0'])
    branch = table(summary, ['all'], ['T1', 'T2', 'T3', 'T4', 'R1', 'R2', 'R3', 'R4'], names)
    split = table(summary, ['train', 'validation'], ['C1', 'OR8', 'U0'])
    output = '../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/149_継続と反転の可読8局面'
    readme = f'''# 可読8局面の選択・金融検証を完了：主U0は未達

試行00149。固定した複合テクニカル8局面から選ぶ検証を完了した。主U0は**4,156件/全73場・平均5.76488件/時**、H60±125の到達済み先着率**46.62%（1,558順/1,784逆）**で、70%条件を満たさず共同目標未達。C5の既知利益20,851,011円・損失28,443,937円・差引−7,592,926円、金額未知118件。結果を見て主政策・8条件を変更していない。

[全セッションCSV]({output}/全セッション.csv)で各場と既知利益/損失/差引の累計を確認できる。未知は0にせず別累計で、未知があれば全件確定差引累計はNULL。[入口別CSV]({output}/入口別診断.csv)は主U0の4,156件、[正逆比較CSV]({output}/正逆比較.csv)は900比較を収録する。

## 固定した判断と取得の単位

[148](../00148_全1分知得から入口品質の母集団を固定する/README.md)で広く記録した適格q0全35,339件を、当時の買売100特徴だけで先に判断した。q1/取得できた事実/先着ラベルを選択器へ渡さず、必要値nullは待機。同側の複数成立は1候補にまとめ、OR8同時両方向23件を競合待機とした。後段で未取得も含む取得対応を結び、同q1は1物理取得、旧C1と重なる16件は旧C1の方向を優先した。旧87を成績で選別せず全件保持する。

8局面は、方向・強さ・勢い・価格位置/構造・値幅・量の役割を分ける。全技法を同方向へそろえる単一AND、一定時刻の強制新規、場ごとの均等化、回数上限での切捨ては採用しない。[条件](条件.md)と[513セルの設定表](設定と結果.md)がF0固定の閾値を保持している。

主U0は旧C1 87＋OR8 4,085−同q1重複16＝4,156件。OR8単独は68場で5場未取得、旧C1を統合して全73場min1を満たした。全場平均は全ザラバ720時間55分が分母で、1時間ごとの強制割当ではない。場別1〜151件の偏りをそのまま残す。

## 主評価と同時点の実逆

取得後60分・同幅125pt、実BBOの順/(順＋逆)をH完了内の到達済み率として示す。未到達/観測不足/IFD金額未知は別記し、全取引勝率と呼ばない。独立mini1枚100円/pt、往復77円＋C5追加往復1,000円。損失は絶対額。

{all_main}

RC1/ROR8/RU0はそれぞれC1/OR8/U0と同じ取得時点の反対BBOを直接使う。1−pで反転率を作らない。旧C1の70%/+210,532円は固定対照の維持で、新8局面の精度ではない。主・OR8の一律反転も改善していない。

{branch}

枝の所属は重なるため件数や損益を足して全体としない。R3は到達済63.64%・59件で相対的に良いが70%未達、小群であり主へ交換しない。T2/T3が多いことだけで高い確信度や持続を証明したことにはならない。

## 前後・集中・金額の限界

{split}

前48・後25はどちらも既使用で、独立未知期ではない。主U0の名目H60重複は136連結群・最大151件で、4,156件を独立標本数又は同時保有数と呼ばない。金額は固定入口ごとの独立IFD代用を合算した診断で、片側上限10枚・実mini板・実IFD・必須利益追尾の運用収支ではない。

全73場終端は既知差引累計−7,592,926円・IFD未知累計118、全件確定差引累計はNULLである。未知を0円として全件の最終収支を作らない。累計付き型付き表だけを恒久保存し、追加15列とmetadataを外せば元表bytesを復元できるため、元表を重複保存していない。

## 検査と次の問い

独立準備・自然選択の全件監査で全35,339q0、全8枝、OR競合23、11政策のcanonical/C1優先/stream/未取得を照合した。Rootの独立金融900比較/21,600値、旧C1全4streamの一致を確認。CSVは230,823データセル/102,004数値を独立再読し、Rootが3プレビューを確認した。Source/条件をCSV表示で選び直していない。

固定5区分の事後診断は、位置伸長やRSI急変を一律に順行/反転の根拠へできないことを示した。[根拠資料](根拠/位置と急変と実反転の事後診断.md)では、R2の当時5分EMA21からのq0実側距離>1ATR5群92件の実逆が49順19逆・到達済72.06%/+201,763円へ改善した。ただし14場に依存する事後群で、新政策の70%達成ではない。T2/T3の伸長群は一律反転しても救済できなかった。

[現在Lastの追補](根拠/現在Lastで回復と突破を確かめた追補.md)では、T4の「終値では突破、q0では既に端へ復帰」26件は元3順17逆から実逆16順4逆・80.00%/+112,998円へ改善した。一方、R3の回復喪失25件は元14順6逆/+93,152円から実逆4順17逆/−210,848円へ壊れた。いずれも事後小群で採用せず、構造の水準と役割を局面別に区別する次の問いである。「維持喪失なら全て反転」という共通則へまとめない。

[時計と取得位置の点検](根拠/入口時計と取得位置の点検.md)は金融を結び付けない別監査である。これらの原因資料は149の固定閾値・主結果を変更せず保存した。未採番の次候補は未採用である。

[金融正本](成果物/集計.json)、[独立検算](検査/金融独立検算.json)、[閲覧資料](閲覧資料.md)、[再現手順](再現手順.md)、[保管索引](保管索引.json)を参照する。F0/F1の3MD原文、選択3正本、候補JSON/selector/driver、累計表示scriptとF2を保管し、148の大入力/観測は共有した。追加2場は対象外・未読のまま。
'''
    (FORMAL / 'README.md').write_text(readme, encoding='utf-8')
    appendix = f'''

## 実行結果：固定8局面の主U0は未達

自然選択・金融900比較・独立900/21,600値・CSVを完了。上の準備/未実行は固定原文として保持し、閾値・8局面・全513セルは変更していない。主U0は4,156取得/全73場・5.76488件/時で、到達済み70%を満たさず共同目標未達。

{all_main}

旧C1全87と方向/Quote/origins/4streamを保持した。OR8単独4,085は68場、同原行16件の旧C1優先を適用した統合がU0。RC1/ROR8/RU0は実逆で1−pではない。前48/後25とも既使用、近接H60依存・金額未知を残す。利益/損失は独立mini1枚C5代用で、10枚口座の運用収支ではない。

CSV全セッションの既知利益/損失/差引累計、IFD未知累計、全件確定差引NULLを分ける。主全期の既知差引−7,592,926円・未知118で全件確定差引はNULL。元型付き表は累計付表からbytes復元可能で、重複保存しない。

[全セッションCSV]({output}/全セッション.csv)、[入口別CSV]({output}/入口別診断.csv)、[正逆比較CSV]({output}/正逆比較.csv)、[README](README.md)、[金融正本](成果物/集計.json)、[再現手順](再現手順.md)を参照する。CSV230,823データセル/102,004数値とRoot3PNGを確認済み。選択条件を出力や結果で変更せず、事後原因は別根拠へ分離する。
'''
    rows = {}
    for name in ('条件.md', '設定と結果.md'):
        path = FORMAL / name
        body = original[path.relative_to(ROOT).as_posix()]
        rows[name] = [line for line in body.decode('utf-8').splitlines()
                      if re.match(r'^\|\s*[A-Z]\d{2}\s*\|', line) and len(line.split('|')) == 13]
        path.write_bytes(body + appendix.encode('utf-8'))
        assert path.read_bytes().startswith(body)
    assert len(rows['設定と結果.md']) == 57
    assert rows['設定と結果.md'] == [line for line in (FORMAL / '設定と結果.md').read_text(encoding='utf-8').splitlines()
                               if re.match(r'^\|\s*[A-Z]\d{2}\s*\|', line) and len(line.split('|')) == 13]
    proof = {'成功': True, '試行': 149, 'README先頭': '完了・主U0未達', '条件設定prefixと513セル保持': True,
             '元3MDはF0F1に保存': True, '新金融計算': False, '正本SHA256': file_sha(FORMAL / '成果物/集計.json'),
             '初回検査範囲の補正': '追加状態表を含む79行でなくV7の13区切り57行を対象とした。原文/条件/数値は不変更',
             '正式3MD': {name: file_sha(FORMAL / name) for name in ('README.md', '条件.md', '設定と結果.md')}}
    (FORMAL / '検査/正式結果の反映確認.json').write_bytes(json_bytes(proof))
    print('proof_sha256=' + file_sha(FORMAL / '検査/正式結果の反映確認.json'))


if __name__ == '__main__':
    main()
