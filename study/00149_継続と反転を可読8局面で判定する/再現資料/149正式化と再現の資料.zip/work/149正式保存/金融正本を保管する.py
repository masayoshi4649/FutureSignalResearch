"""149のF2/金融と累計付正本を保存し、148の大入力・観測は共有する。"""
from pathlib import Path
import gzip
import hashlib
import json
import zipfile
from 保存部品 import ROOT, FORMAL, save, resolve, file_sha, json_bytes


def main():
    """金融通知後の正本を保存し、元表を累計付表から戻せることを確認する。

    引数: なし。返り値: None。金融・Sourceを再計算せず正式3MDは変更しない。
    """
    runtime = ROOT / 'work/149可読8局面の評価'
    folder = runtime / '金融診断'
    index_path = FORMAL / '保管索引.json'
    index = json.loads(index_path.read_bytes())
    f2 = runtime / 'F2金融集計前.json'
    f2_sha = file_sha(f2)
    assert f2_sha.startswith('27cab3')
    frozen = json.loads(f2.read_bytes())
    assert frozen['試行'] == 149 and frozen['主政策'] == 'U0'
    f1 = json.loads((ROOT / index['F1原文']['保存元']).read_bytes())
    for name in ('README.md', '条件.md', '設定と結果.md'):
        path = FORMAL / name
        assert file_sha(path) == f1['ファイル'][str(path)]
    completion = json.loads((folder / '集計完了.json').read_bytes())
    assert completion['成功'] and completion['集計SHA256'] == '7b6658adb89b10b8a49096e144aa4f572283f9471083896150c68547079f9082'
    f2_record = save(f2, FORMAL / '検査/F2金融集計前.json', f2_sha)
    groups = resolve(frozen['ファイル'], '金融集計前', [])
    summary_record = save(folder / '集計.json', FORMAL / '成果物/集計.json', completion['集計SHA256'])
    cumulative = folder / 'CSV用の表_累計付.json'
    assert file_sha(cumulative) == '49a3514d77768437946e3f4efe7adf6d7b9b1366ee344e5228dd6fd35769c7b6'
    table_record = save(cumulative, FORMAL / '成果物/CSV用の表_累計付.json.gz', file_sha(cumulative), True)
    # 原表を恒久保存で重ねず、追加15列と3metadataだけを外してbytes同体を確かめる。
    table = json.loads(cumulative.read_bytes())
    assert table.pop('元の表SHA256') == completion['表SHA256']
    table.pop('累計の定義')
    assert table.pop('集計SHA256') == completion['集計SHA256']
    sessions = next(item for item in table['tables'] if item['name'] == '全セッション')
    assert len(sessions['headers']) == 67
    assert all('累計' in name for name in sessions['headers'][-15:])
    sessions['headers'] = sessions['headers'][:-15]
    sessions['rows'] = [row[:-15] for row in sessions['rows']]
    original = (json.dumps(table, ensure_ascii=False, indent=2) + '\n').encode('utf-8').replace(b'\n', b'\r\n')
    assert hashlib.sha256(original).hexdigest() == completion['表SHA256']
    extras = []
    for name in ('集計完了.json', '独立検算.json'):
        path = folder / name
        extras.append(save(path, FORMAL / ('検査/金融独立検算.json' if name == '独立検算.json' else '成果物/集計完了.json'), file_sha(path)))
    parent = next((ROOT / 'study').glob('00148_*/保管索引.json'))
    parent_index = json.loads(parent.read_bytes())
    index.update({'段階': 'F0/F1/F2と選択3正本/金融/累計付表を保存。正式結果は次段階',
                  'F2_SHA256': f2_sha, 'F2原文': f2_record, 'F2直接源数': len(frozen['ファイル']), 'F2復元参照': groups,
                  '保存金融正本': summary_record, '保存CSV用の表_累計付': table_record,
                  '元CSV用表SHA256': completion['表SHA256'], '元表の恒久再複製': False,
                  '元表の復元': '累計付JSONの全セッション末尾15列と累計の定義/元の表SHA256/集計SHA256を除き、元のUTF8 CRLF整形へ戻す',
                  '元表bytes復元一致': True, '金融完成と独立票': extras,
                  '親148共有観測': parent_index['保存済み正逆観測'],
                  '主政策': 'U0', '最終選択取引数': 4156, '金融診断は運用収支': False})
    index_path.write_bytes(json_bytes(index))
    proof = {'成功': True, '試行': 149, 'F2_SHA256': f2_sha, 'F2全源数': len(frozen['ファイル']),
             '集計SHA256': summary_record['解凍SHA256'], '累計付表SHA256': table_record['解凍SHA256'],
             '原表SHA256': completion['表SHA256'], '原表bytes復元一致': True,
             '元表の恒久重複': False, '親148大入力又は観測の新複製': False, '正式3MD未変更': True,
             '保管索引SHA256': file_sha(index_path), '重大不足': []}
    target = FORMAL / '検査/金融正本の保管確認.json'
    assert not target.exists()
    target.write_bytes(json_bytes(proof))
    print('proof_sha256=' + file_sha(target))
    print('index_sha256=' + file_sha(index_path))


if __name__ == '__main__':
    main()
