"""149の停止済み事後診断・時計点検を小型源と一度gzipへ分けて保存する。"""
from pathlib import Path
import json
import zipfile
from 保存部品 import ROOT, FORMAL, file_sha, save, json_bytes


def main():
    """停止票の指紋を起点に根拠を恒久化する。

    引数: なし。返り値: None。親100X・原板・観測を複製/再計算しない。
    """
    jobs = [
        ('149局面の位置と急変と実反転の診断', '停止.json', 'b40faebb6d5288399af51574eaa15711a4d9c4cb962fff992203b40a0d07f96b',
         '診断.json', '固定5区分の事後診断.json.gz', '短報.md', '位置と急変と実反転の事後診断.md'),
        ('149現在Lastで回復と突破を確かめる追補', '停止.json', 'ae60b90b96f5c80190514e8065657bfcb875c9a4aa59f107a49411aeeab4d480',
         '追加診断.json', '現在Lastの追加診断.json.gz', '短報.md', '現在Lastで回復と突破を確かめた追補.md'),
        ('149入口の価格時計と確認遅延の点検', '停止の確認.json', 'e55b952bb7f0344f478859eebb143a36cb3608fb932fc1b44710f1b07e08bc08',
         '分布の確認.json', '時計と取得位置の分布.json.gz', '時計と取得位置の短報.md', '入口時計と取得位置の点検.md'),
    ]
    bodies, records, reports = {}, [], []
    for folder_name, stop_name, stop_sha, detail_name, packed_name, short_name, report_name in jobs:
        folder = ROOT / 'work' / folder_name
        assert file_sha(folder / stop_name) == stop_sha
        detail = folder / detail_name
        records.append(save(detail, FORMAL / '根拠' / packed_name, file_sha(detail), True))
        original = (folder / short_name).read_bytes()
        target = FORMAL / '根拠' / report_name
        tail = f'\n\n正式保存では[詳細gzip]({packed_name})と[コード/区分/人工/停止票](../再現資料/149監査と診断の資料.zip)を参照する。コードはZIP内の元work相対pathへ復元し、事後診断を新政策の採用成績と読み替えない。\n'.encode('utf-8')
        assert not target.exists()
        target.write_bytes(original + tail)
        reports.append({'path': target.relative_to(ROOT).as_posix(), 'sha256': file_sha(target),
                        '元MD_SHA256': file_sha(folder / short_name), '元MD_bytes': len(original), '差分': '恒久参照だけを末尾へ追加'})
        for path in folder.iterdir():
            if path.is_file() and path.suffix in ('.py', '.json', '.md') and path.name not in (detail_name, short_name):
                assert path.stat().st_size < 1_000_000, str(path)
                bodies[path.relative_to(ROOT).as_posix()] = path.read_bytes()
    audit = ROOT / 'work/149選択の独立全件監査'
    for name in ('監査する.py', '監査の確認.json', '実行前3MDの退避.json'):
        bodies[(audit / name).relative_to(ROOT).as_posix()] = (audit / name).read_bytes()
    independent = ROOT / 'work/149の位置層別と実反転を独立に照合する.py'
    bodies[independent.relative_to(ROOT).as_posix()] = independent.read_bytes()
    bodies[Path(__file__).relative_to(ROOT).as_posix()] = Path(__file__).read_bytes()
    target = FORMAL / '再現資料/149監査と診断の資料.zip'
    entries = []
    with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for name, body in sorted(bodies.items()):
            import hashlib
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 12, 0, 0, 0))
            bundle.writestr(info, body, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
            entries.append({'path': name, 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()})
    index_path = FORMAL / '保管索引.json'
    index = json.loads(index_path.read_bytes())
    index['停止診断の詳細gzip'] = records
    index['停止診断の短報'] = reports
    index['監査と診断の小資料'] = {'保存元ZIP': target.relative_to(ROOT).as_posix(), 'ZIP_SHA256': file_sha(target),
                                'ZIP_bytes': target.stat().st_size, '格納源': entries,
                                '区分': '主結果確認後の事後診断/時計点検。149の固定閾値・選択・主政策は不変更'}
    index['実行前3MDの私有退避'] = 'review退避メタはZIP、本文は正式F0/F1 snapshotから同bytesを復元。第三の全文複製はしない'
    index_path.write_bytes(json_bytes(index))
    print('zip_sha256=' + file_sha(target))
    print('index_sha256=' + file_sha(index_path))


if __name__ == '__main__':
    main()
