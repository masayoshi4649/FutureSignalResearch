"""149追加代数診断を作者関数なしで特徴・固定選択・保存BBOから照合する。"""
from pathlib import Path
from collections import Counter
import hashlib
import json
import math
import re

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
FILES = {
    '追加票': ('work/149現在Lastで回復と突破を確かめる追補/追加診断.json', '08d51d76ccc8911a4f1286ab67ea2312783f7f1df827cb2ab7b38d861329eab3'),
    '追加区分': ('work/149現在Lastで回復と突破を確かめる追補/追加区分の事前固定.md', 'a746042cc9f410d05ba08f927d21a135c1c0dc13c52aa5a0d389ce1ec9f58813'),
    '固定選択': ('work/149可読8局面の評価/入口選択/選択対応.json', 'ecb45e18bccad7c8df50dc7edb9908233a453108e73ff41196af328cbb5eeacb'),
    '当時特徴': ('work/148全1分母集団の評価/母集団生成/当時特徴.json', '572705d7db8529555c876eb1953f7d8e1cd1de0e554bf9de729a7d377e4d91af'),
    '列定義': ('inputs/00148_全1分入口母集団/100特徴の列定義.json', 'c85223fbe1543e5457c28d4391f817534099d1af1d19664035c668ff5fe8a7b4'),
    '保存正逆': ('work/148全1分母集団の評価/固定取得の正逆観測.json', 'd1b4cab8a258203f04b5c1d081f57d10ed2a0c58ce4cc160ef571d5fac0ceffc'),
    '元診断の独立票': ('work/149局面の位置と急変と実反転の診断/独立検算.json', None),
}
BRANCHES = ('T1', 'R2', 'R3', 'R4', 'T4')
EXTRA = ('m1_body_reclaim_atr5_to_side', 'q0_last_minus_m1_close_atr5_to_side',
         'q0_last_minus_prior3_forward_edge_atr5_to_side')
OLD_KEYS = {'EMA位置': 'q0_entry_minus_ema21_atr5_to_side',
            'BB位置': 'q0_entry_minus_bbmean_sigma_to_side',
            'RSI急変': 'm5_rsi_delta_to_side', '1分量比': 'm1_volume_relative_prior3',
            '知得時価格差': 'q0_last_minus_m1_close_atr5_to_side'}


def fingerprint(path: Path) -> dict:
    """
    機能: 大型ファイルを複写せず全bytesのSHAとstatを保存する。
    引数: path(Path)。返り値: dictはpath・bytes・mtime_ns・sha256。
    """
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(4 << 20), b''):
            digest.update(chunk)
    stat = path.stat()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': stat.st_size,
            'mtime_ns': stat.st_mtime_ns, 'sha256': digest.hexdigest()}


def read_array(path: Path, key: str):
    """
    機能: 固定JSONのトップ配列を要素ごとに復号してRAM消費を抑える。
    引数: path(Path)、key(str)。返り値: Iterator[dict]。
    """
    decoder = json.JSONDecoder()
    token = re.compile(r'(?m)^  "' + re.escape(key) + r'": \[')
    buffer = ''
    with path.open(encoding='utf-8') as source:
        while True:
            chunk = source.read(1 << 20)
            assert chunk, 'トップ配列が存在しない'
            buffer += chunk
            match = token.search(buffer)
            if match:
                buffer = buffer[match.end():]
                break
        while True:
            buffer = buffer.lstrip()
            if buffer.startswith(']'):
                return
            if buffer.startswith(','):
                buffer = buffer[1:].lstrip()
            try:
                value, end = decoder.raw_decode(buffer)
            except json.JSONDecodeError:
                chunk = source.read(1 << 20)
                assert chunk, '配列が未完'
                buffer += chunk
                continue
            yield value
            buffer = buffer[end:]


def recovery(body, gap) -> tuple:
    """
    機能: 保存floatの和を厳密ゼロで分類し、未知を伝播する。
    引数: body/gap(float又はNone)。返り値: tuple[str,float又はNone]。
    """
    if body is None or gap is None:
        return '未知', None
    value = body + gap
    assert math.isfinite(value)
    return ('>0' if value > 0 else '<0' if value < 0 else '=0'), value


def breakout(edge, gap) -> tuple:
    """
    機能: 終値での端突破と現在Lastの残存を別々に判定する。
    引数: edge/gap(float又はNone)。返り値: tuple[str,float又はNone]。
    """
    if edge is None or gap is None:
        return '未知', None
    close = edge - gap
    assert math.isfinite(close)
    if close <= 0:
        return '未突破等', close
    return ('維持' if edge > 0 else '確認後に既に失敗'), close


def boundary_tests() -> int:
    """
    機能: 未知・厳密等号・端維持の追加区分を人工境界で検査する。
    引数: なし。返り値: intは検査ケース数。
    """
    cases = [(None, 1, '未知'), (1, None, '未知'), (1, -1, '=0'),
             (1e-14, 0, '>0'), (-1e-14, 0, '<0')]
    for a, b, category in cases:
        assert recovery(a, b)[0] == category
    more = [(None, 0, '未知'), (0, None, '未知'), (0, -1, '確認後に既に失敗'),
            (-1, -2, '確認後に既に失敗'), (1, 0, '維持'),
            (1, 1, '未突破等'), (-1, 0, '未突破等'), (1e-14, 0, '維持')]
    for edge, gap, category in more:
        assert breakout(edge, gap)[0] == category
    return len(cases) + len(more)


def old_bin(name: str, value) -> str:
    """
    機能: 元の固定5区分を再計算し既存群の非改変を確認する。
    引数: name(str)、value(float又はNone)。返り値: str。
    """
    if value is None:
        return '未知'
    if name == 'EMA位置':
        return '<−1' if value < -1 else '[−1,0]' if value <= 0 else '(0,1]' if value <= 1 else '>1'
    if name == 'BB位置':
        return '<−1' if value < -1 else '[−1,1]' if value <= 1 else '>1'
    if name == 'RSI急変':
        return '>5' if value > 5 else '≤5'
    if name == '1分量比':
        return '≥2' if value >= 2 else '<2'
    assert name == '知得時価格差'
    return '<−.5' if value < -.5 else '[−.5,.5]' if value <= .5 else '>.5'


def observe(stream: dict) -> dict:
    """
    機能: 保存BBOから完了状態と費用後IFDを作者関数なしで求める。
    引数: stream(dict)。返り値: dictはFANC・touch・IFD既知・損益等。
    """
    side = stream['birth']['side']
    assert side in (-1, 1)
    entry = stream['entry']
    assert entry['quote_ok'] and 0 < entry['bid'] < entry['ask']
    price = entry['ask'] if side == 1 else entry['bid']
    assert price == stream['entry_price']
    outcome, = [o for o in stream['outcomes'] if o['seconds'] == 3600]
    touch, = [t for t in outcome['touches'] if t['width'] == 125]
    direction = touch['direction']
    assert direction in (-1, 0, 1) and (direction == 0) == (touch['quote'] is None)
    state = ('F' if direction == 1 else 'A' if direction == -1 else 'N') if outcome['status'] == 'complete' else 'C'
    # ----------------------------------------
    # H不足でも保存touchがあるならIFDは既知。H完了率と混同しない。
    exit_quote = touch['quote'] if direction else outcome['endpoint'] if outcome['status'] == 'complete' else None
    points = None
    net = None
    if exit_quote is not None:
        mark = exit_quote['bid'] if side == 1 else exit_quote['ask']
        points = side * (mark - price)
        net = points * 100 - 1077
    return {'state': state, 'touch_direction': direction, 'ifd_known': exit_quote is not None,
            'points': points, 'net5': net,
            'ifd_reason': 'touch' if direction else 'endpoint' if exit_quote else 'unknown',
            'ifd_exit_time': exit_quote['time'] if exit_quote else None}


def summary(rows: list, side: str) -> dict:
    """
    機能: ゼロ件と全未知を区別し群の先着・利益損失を再構成する。
    引数: rows(list[dict])、side(str)。返り値: dictは各群統計。
    """
    values = [r[side] for r in rows]
    states = Counter(v['state'] for v in values)
    money = [v['net5'] for v in values if v['ifd_known']]
    gain = sum(v for v in money if v > 0)
    loss = -sum(v for v in money if v < 0)
    resolved = states['F'] + states['A']
    completed = len(rows) - states['C']
    return {'件数': len(rows), '場数': len({r['session'] for r in rows}),
            **{key: states[key] for key in 'FANC'},
            '到達済率': states['F'] / resolved if resolved else None,
            '完了分母率': states['F'] / completed if completed else None,
            'IFD既知': len(money), 'IFD未知': len(rows) - len(money),
            'C5利益': gain if money else None, 'C5損失絶対': loss if money else None,
            'C5差引': sum(money) if money else None, 'PF': gain / loss if loss else None}


def paired(rows: list) -> dict:
    """
    機能: 同じ元side所属の実正逆行列と両既知の差を求める。
    引数: rows(list[dict])。返り値: dictは二方向の統計と対応行列。
    """
    matrix = {a: {b: 0 for b in 'FANC'} for a in 'FANC'}
    both = []
    for row in rows:
        matrix[row['native']['state']][row['inverse']['state']] += 1
        if row['native']['ifd_known'] and row['inverse']['ifd_known']:
            both.append(row['inverse']['net5'] - row['native']['net5'])
    return {'元方向': summary(rows, 'native'), '実逆': summary(rows, 'inverse'),
            '元→実逆行列': matrix, '両IFD既知': len(both),
            '両既知C5差_実逆引く元': sum(both) if both else None,
            '元だけ既知': sum(r['native']['ifd_known'] and not r['inverse']['ifd_known'] for r in rows),
            '逆だけ既知': sum(r['inverse']['ifd_known'] and not r['native']['ifd_known'] for r in rows)}


def compare(expected, actual, path: str = '') -> int:
    """
    機能: 再構成群の全キーと数値を再帰照合する。
    引数: expected/actual(JSON値)、path(str)。返り値: intは照合末端値数。
    """
    if isinstance(expected, dict):
        assert expected.keys() == actual.keys(), path
        return sum(compare(v, actual[k], path + '/' + str(k)) for k, v in expected.items())
    if isinstance(expected, float):
        assert actual is not None and math.isclose(expected, actual, rel_tol=1e-12, abs_tol=1e-9), (path, expected, actual)
    else:
        assert expected == actual, (path, expected, actual)
    return 1


def main() -> None:
    """
    機能: 全所属・式・固定参照・保存観測・全群を独立照合し停止票を保存する。
    引数: なし。返り値: None。Source/閾値を変更せずRaw/CSV/追加2場は開かない。
    """
    paths = {key: ROOT / item[0] for key, item in FILES.items()}
    before = {key: fingerprint(path) for key, path in paths.items()}
    for key, (_, expected_sha) in FILES.items():
        if expected_sha:
            assert before[key]['sha256'] == expected_sha, key
    artificial = boundary_tests()
    target = json.loads(paths['追加票'].read_bytes())
    selection = json.loads(paths['固定選択'].read_bytes())
    catalog = json.loads(paths['列定義'].read_bytes())
    index = {column['name']: i for i, column in enumerate(catalog)}
    assert len(index) == 100
    sessions = selection['全73場']
    assert len(sessions) == len(set(sessions)) == 73 and sessions == target['全73場']
    source_rows = {(r['branch'], r['case_id']): r for r in target['詳細']}
    assert len(source_rows) == len(target['詳細']) == 773
    choices = [(branch, row) for branch in BRANCHES for row in selection['政策'][branch]]
    assert {(b, r['case_id']) for b, r in choices} == source_rows.keys()
    required_events = {r['event_id'] for _, r in choices}
    required_cases = {r['case_id'] for _, r in choices}
    assert len(required_events) == 740
    features = {}
    for record in read_array(paths['当時特徴'], 'rows'):
        if record['event_id'] in required_events:
            assert record['event_id'] not in features
            features[record['event_id']] = record
    assert set(features) == required_events
    cases = {}
    seen_sessions = []
    for scene in read_array(paths['保存正逆'], 'scenes'):
        assert scene['success']
        seen_sessions.append(scene['session'])
        for case in scene['cases']:
            if case['id'] in required_cases:
                assert case['id'] not in cases
                cases[case['id']] = (scene['session'], case)
    assert seen_sessions == sessions and set(cases) == required_cases
    rebuilt = []
    per_branch = {branch: set() for branch in BRANCHES}
    for branch, choice in choices:
        row = source_rows[(branch, choice['case_id'])]
        feature = features[choice['event_id']]
        sid, case = cases[choice['case_id']]
        selected = choice['stream']
        opposite = 'reverse' if selected == 'original' else 'original'
        q0 = feature['metadata']['q0']
        q1 = case[selected]['entry']
        assert sid == choice['session'] == feature['session'] == row['session']
        assert choice['event_id'] == choice['feature_ref'] == row['event_id']
        assert choice['side'] == row['selected_side'] == case[selected]['birth']['side'] == -case[opposite]['birth']['side']
        assert selected == row['stream'] and q1 == case[opposite]['entry']
        assert (q0['time'], q0['index'], q0['source_line']) == (choice['q0_time'], choice['q0_index'], choice['q0_line'])
        assert row['contract'] == feature['contract'] and row['q0_time'] == q0['time']
        assert row['q1_time'] == q1['time'] and row['q0_to_q1_seconds'] == q1['time'] - q0['time']
        physical = (sid, feature['contract'], q1['time'], q1['index'], q1['source_line'])
        assert physical not in per_branch[branch]
        per_branch[branch].add(physical)
        vector = feature['buy' if choice['side'] == 1 else 'sell']['x']
        assert len(vector) == 100 and all(v is None or (type(v) in (int, float) and math.isfinite(v)) for v in vector)
        extra = {key: vector[index[key]] for key in EXTRA}
        assert row['追加原値'] == extra
        old_values = {name: vector[index[key]] for name, key in OLD_KEYS.items()}
        assert old_values == row['values']
        assert {name: old_bin(name, value) for name, value in old_values.items()} == row['bins']
        recover_group, recover_value = recovery(extra[EXTRA[0]], extra[EXTRA[1]])
        break_group, close_value = breakout(extra[EXTRA[2]], extra[EXTRA[1]])
        assert (row['生存回復群'], row['生存回復値']) == (recover_group, recover_value)
        assert (row['突破維持群'], row['rClose突破値']) == (break_group, close_value)
        native = observe(case[selected])
        inverse = observe(case[opposite])
        assert native == row['native'] and inverse == row['inverse']
        rebuilt.append({'branch': branch, 'session': sid, 'native': native, 'inverse': inverse,
                        '回復': recover_group, '突破': break_group})
    groups = {}
    group_count = 0
    for part, scope in (('all', sessions), ('train', sessions[:48]), ('validation', sessions[48:])):
        groups[part] = {}
        for branch in BRANCHES:
            selected_rows = [r for r in rebuilt if r['branch'] == branch and r['session'] in scope]
            axis = '突破' if branch == 'T4' else '回復'
            levels = ('確認後に既に失敗', '維持', '未突破等', '未知') if branch == 'T4' else ('>0', '=0', '<0', '未知')
            bins = {level: paired([r for r in selected_rows if r[axis] == level]) for level in levels}
            assert sum(item['元方向']['件数'] for item in bins.values()) == len(selected_rows)
            groups[part][branch] = {'全取得': paired(selected_rows), '群': bins}
            group_count += 1 + len(levels)
    cells = compare(groups, target['前後'])
    failure = groups['all']['T4']['群']['確認後に既に失敗']
    assert (failure['元方向']['件数'], failure['元方向']['F'], failure['元方向']['A'],
            failure['実逆']['F'], failure['実逆']['A']) == (26, 3, 17, 16, 4)
    assert before == {key: fingerprint(path) for key, path in paths.items()}
    own_groups = HERE / '再構成した全群.json'
    own_groups.write_text(json.dumps({'前後': groups}, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    proof = {'成功': True, '試行': 149, '編集停止': True, '全所属': len(rebuilt),
             'uniqueq0': len(required_events), 'uniquecase': len(required_cases),
             '三特徴の列番号0起点': {key: index[key] for key in EXTRA},
             '固定選択refs/side/stream/q0/物理q1全件一致': True,
             '回復和/突破差/現在端/厳密0/未知全件一致': True,
             '元5bin不変更': True, '境界人工': artificial,
             '全群数': group_count, '全群末端値数': cells, '個別正逆観測': len(rebuilt) * 2,
             'H不足touch既知と金額未知を分離': True,
             'T4確認後失敗26': failure, '作者/Root算術import': False,
             '保存133正逆観測から再計算': True,
             'Source/閾値変更/新規取引追加/採用/70達成主張': False,
             'Raw/CSV/追加2場読取': False, '全期事後/近接依存/重複所属限界': True,
             '入力前後同体': before, '独立コード': fingerprint(Path(__file__)),
             '再構成群': fingerprint(own_groups)}
    output = HERE / '独立検査の確認.json'
    output.write_text(json.dumps(proof, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '所属': len(rebuilt), 'q0': len(required_events),
                      '群': group_count, '値': cells, 'proof_sha256': fingerprint(output)['sha256']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
