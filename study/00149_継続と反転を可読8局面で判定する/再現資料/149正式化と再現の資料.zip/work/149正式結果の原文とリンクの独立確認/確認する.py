"""149正式文書の原文保持・513セル・見出し・リンクだけを非金融で確認する。"""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import re
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
FORMAL = ROOT / 'study/00149_継続と反転を可読8局面で判定する'


def fingerprint(path: Path) -> dict:
    """
    機能: 文書のbytesとSHAを取得する。
    引数: path(Path)。返り値: dictは相対path・bytes・sha256。
    """
    raw = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def catalog_rows(text: str) -> list[str]:
    """
    機能: 後追記の状態表と分離して版7の57行だけを取り出す。
    引数: text(str)。返り値: list[str]は13区切りを持つID付き原文行。
    """
    return [line for line in text.splitlines()
            if re.match(r'^\|\s+[A-Z]\d{2}\s+\|', line)
            and len(line.split('|')) == 13]


def main() -> None:
    """
    機能: F1退避原文と現在3MDを限定照合し、私有workへ証跡を保存する。
    引数: CLI --links-ready(bool)は全リンク実在を必須とする。
    返り値: None。金融・ラベルJSONとリンク先本文を開かず正式文書は変更しない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--links-ready', action='store_true')
    args = parser.parse_args()
    author = FORMAL / '検査/正式結果の反映確認.json'
    original = FORMAL / '検査/F1実行前文書.json.gz'
    paths = [FORMAL / n for n in ('README.md', '条件.md', '設定と結果.md')] + [author, original]
    before = {p: fingerprint(p) for p in paths}
    assert before[author]['sha256'] == '2b210b7f94c9d8428f748527d523b302bf2a9cb514a10c54ac1dc3535d8779e5'
    snapshot = json.loads(gzip.decompress(original.read_bytes()))
    by_path = {item['path'].replace('\\', '/'): item for item in snapshot['文書']}
    old = {}
    for name in ('README.md', '条件.md', '設定と結果.md'):
        item = by_path[(FORMAL / name).relative_to(ROOT).as_posix()]
        raw = item['本文'].encode('utf-8')
        assert hashlib.sha256(raw).hexdigest() == item['sha256']
        old[name] = raw
    for name in ('条件.md', '設定と結果.md'):
        assert (FORMAL / name).read_bytes().startswith(old[name]), name
    current_rows = catalog_rows((FORMAL / '設定と結果.md').read_text(encoding='utf-8'))
    old_rows = catalog_rows(old['設定と結果.md'].decode('utf-8'))
    assert current_rows == old_rows and len(current_rows) == 57
    assert len({line.split('|')[1].strip() for line in current_rows}) == 57
    assert all(len(line.split('|')[3:-1]) == 9 for line in current_rows)
    heading = (FORMAL / 'README.md').read_text(encoding='utf-8').splitlines()[0]
    assert '完了' in heading and '主U0' in heading and '未達' in heading
    links = []
    for path in paths[:3]:
        for target in re.findall(r'\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
            if '://' in target or target.startswith('#'):
                continue
            local = unquote(target.strip('<>').split('#', 1)[0])
            links.append({'文書': path.name, '参照': target, '実在': (path.parent / local).exists()})
    missing = [item for item in links if not item['実在']]
    if args.links_ready:
        assert not missing, missing
    assert before == {p: fingerprint(p) for p in paths}
    proof = {'成功': True, '試行': 149,
             '状態': '限定確認停止' if not missing else '原文と513確認済み・予定リンク実在化待ち',
             '条件/設定のF1元全bytesがprefix保持': True,
             'V7': {'手法': 57, '尺度': 9, 'セル': 513, '全57行文字同体': True,
                    '抽出': 'ID正規表現かつsplit縦線13区切り、追記状態表を含めない'},
             'README先頭': heading, 'リンク数': len(links), '未実在リンク': missing,
             '対象前後同体': list(before.values()),
             '金額/先着率の数値妥当性検査': False,
             '金融/ラベルJSON/Raw/追加2場読取': False,
             '独立金融確認': 'Root900条件21600統計値の別票へ分離',
             '正式/Root150編集': False, '確認コード': fingerprint(Path(__file__))}
    target = HERE / '確認の記録.json'
    target.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'proof_sha256': fingerprint(target)['sha256'], 'cells': 513,
                      'links': len(links), 'missing': missing}, ensure_ascii=False))


if __name__ == '__main__':
    main()
