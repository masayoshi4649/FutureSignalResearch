"""停止済み選択器人工を変えず、全8枝・正式3MD・V7のリンクを補足確認する。"""
from pathlib import Path
import hashlib
import importlib.util
import json
import re

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
FORMAL = ROOT / 'study/00149_継続と反転を可読8局面で判定する'
CODE = ROOT / 'work/149可読局面の入口選択/選択する.py'
RULES = ROOT / 'work/149候補_可読8局面.json'
TABLE = ROOT / 'docs/議論/手法と時間スケールの汎用表_版7.md'


def sha(path: Path) -> str:
    """
    機能: 既存の小文書/コードだけを指紋化する。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def without_links(text: str) -> str:
    """
    機能: 相対リンク補正を除いた表の同体を比較する。
    引数: text(str)。返り値: strはリンクラベルを残した本文。
    """
    return re.sub(r'\[([^]]+)\]\(([^)]+)\)', r'\1', text)


def main() -> None:
    """
    機能: 全8ルールの両side成立/各NULLと正式文書の全513セルを検査する。
    引数: なし。返り値: None。自然特徴へのルール適用・金融/Raw読取をしない。
    """
    old_proof = HERE / '準備の確認.json'
    assert sha(old_proof) == '0271cf9e18b367a409333af7734d197c52f409d806d7b9de8644e381755beec8'
    pins = {CODE: '6588ab9eca392d9ea3a7697fba949f816aab76b8270f1601f4fd2b0536c02e02',
            RULES: 'bbb4f2dee4dc05007309351222205f76b3cca8d628b2ff436a835049c7cb67ad',
            TABLE: '585d0d9ba69ff3601325e9e6564ede53aeb81b0d33a2da6cb67e20e175187c3d'}
    assert all(sha(p) == h for p, h in pins.items())
    spec = importlib.util.spec_from_file_location('149補足の確認対象', CODE)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    book = json.loads(RULES.read_bytes())
    catalog = json.loads((ROOT / 'work/148全1分候補の当時特徴/列定義.json').read_bytes())
    index = module.validate(book, catalog)
    checks = 0
    for rule in book['ルール']:
        values = {'q0_spread_points': 10, 'q0_last_minus_m1_close_atr5_to_side': 0}
        for name, op, *limits in rule['条件']:
            values[name] = (limits[0] + limits[1]) / 2 if op == '範囲' else limits[0] + 1 if op == '>' else limits[0] - 1 if op == '<' else limits[0]
        vector = [None] * 100
        for name, value in values.items(): vector[index[name]] = value
        blank = [None] * 100
        assert module.decide(vector, blank, book, index)['方向'][rule['id']] == 1
        assert module.decide(blank, vector, book, index)['方向'][rule['id']] == -1
        checks += 2
        for name, *_ in rule['条件']:
            missing = vector.copy(); missing[index[name]] = None
            assert module.decide(missing, blank, book, index)['方向'][rule['id']] == 0
            checks += 1
    settings = (FORMAL / '設定と結果.md').read_text(encoding='utf-8')
    original = TABLE.read_text(encoding='utf-8')
    table_rows = lambda body: [line for line in body.splitlines() if re.match(r'^\| [A-Z]\d{2} \|', line) and len(line.split('|')[1:-1]) == 11]
    a, b = table_rows(original), table_rows(settings)
    assert len(a) == len(b) == 57 and all(len(line.split('|')[3:-1]) == 9 for line in b)
    assert [without_links(line) for line in a] == [without_links(line) for line in b]
    links = 0
    for name in ('README.md', '条件.md', '設定と結果.md'):
        path = FORMAL / name
        for target in re.findall(r'\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
            if '://' in target or target.startswith('#'): continue
            assert (path.parent / target.split('#', 1)[0]).exists(), (name, target)
            links += 1
    condition = (FORMAL / '条件.md').read_text(encoding='utf-8')
    assert all(re.search(r'^\|' + r['id'] + r'\|', condition, re.M) for r in book['ルール'])
    assert all(text in condition for text in ('主U0', 'NULL', '両端', '0超20pt以下', '0.75～1.5', '−1.5～0.5', '旧C1全87'))
    assert '未実行' in settings and '未採用' in (ROOT / 'work/149候補_技術局面を分けた可読入口.md').read_text(encoding='utf-8')
    assert all(sha(p) == h for p, h in pins.items()) and sha(old_proof) == '0271cf9e18b367a409333af7734d197c52f409d806d7b9de8644e381755beec8'
    result = {'成功': True, '試行': 149, '状態': '正式3MDと全8局面の補足を編集停止',
              '選択器独立7群票SHA256': sha(old_proof), '全8枝の両side/必要NULL確認': checks,
              'V7全513セル': '57×9、リンク先以外の全セル原文同体', 'ローカルリンク実在': links,
              '正式3MD': {n: sha(FORMAL / n) for n in ('README.md', '条件.md', '設定と結果.md')},
              '固定対象': {p.relative_to(ROOT).as_posix(): h for p, h in pins.items()},
              '100数式再実装/自然選択/148金融/Raw/追加2場読取': False,
              '対象源/正式編集': False, '確認コードSHA256': sha(Path(__file__))}
    target = HERE / '正式と全8局面の補足.json'
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'補足票SHA256': sha(target), '全8枝確認': checks, 'links': links, 'formal': result['正式3MD']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
