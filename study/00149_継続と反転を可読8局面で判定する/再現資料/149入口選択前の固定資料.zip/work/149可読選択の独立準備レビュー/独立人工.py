"""149候補を自然選択せず、別fixtureでq0ルールと後段接続を確認する。"""
from pathlib import Path
from unittest import mock
import contextlib
import copy
import hashlib
import importlib.util
import io
import json
import math
import re
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
CODE = ROOT / 'work/149可読局面の入口選択/選択する.py'
RULES = ROOT / 'work/149候補_可読8局面.json'
MD = ROOT / 'work/149候補_技術局面を分けた可読入口.md'
CATALOG = ROOT / 'work/148全1分候補の当時特徴/列定義.json'
spec = importlib.util.spec_from_file_location('可読149の独立確認対象', CODE)
selector = importlib.util.module_from_spec(spec)
spec.loader.exec_module(selector)
BOOK = json.loads(RULES.read_bytes())
COLS = json.loads(CATALOG.read_bytes())
INDEX = selector.validate(BOOK, COLS)
SESSIONS = [f'人工{i:02d}_Day' for i in range(73)]


def digest(path: Path) -> str:
    """
    機能: 小コード・固定ルール・私有人工の指紋を計算する。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def vector(kind: str = '') -> list:
    """
    機能: 既にside変換済みの人工100特徴を作る。
    引数: kind(str)はT1/T3/両方又は空。返り値: listは未使用をnullのまま残す配列。
    """
    values = {'q0_spread_points': 10, 'q0_last_minus_m1_close_atr5_to_side': 0}
    if kind in ('T1', '両方'):
        values.update({'m30_ema21_delta_atr_to_side': 1, 'm15_di_difference_to_side': 1,
                       'm5_hist_delta_atr_to_side': 1, 'q0_entry_minus_ema8_atr5_to_side': 0,
                       'm1_close_delta_atr5_to_side': 1, 'm1_volume_ratio_previous': 1})
    if kind in ('T3', '両方'):
        values.update({'m15_ema21_delta_atr_to_side': 1, 'm5_di_difference_to_side': 1,
                       'q0_last_minus_prior3_forward_edge_atr5_to_side': 0,
                       'm1_body_ratio_to_side': .5, 'm1_volume_relative_prior3': 1.5, 'm1_tr_atr5_ratio': 2})
    out = [None] * 100
    for name, value in values.items(): out[INDEX[name]] = value
    return out


def cases_fixture() -> list[dict]:
    """
    機能: 自然旧87を読まず、87対照と1新caseの記述を作る。
    引数: なし。返り値: list[dict]は接続用の人工case。
    """
    result = []
    for i in range(87):
        side = -1 if i == 0 else 1
        result.append({'case_id': f'C1/{i}', 'session': SESSIONS[i % 73], 'contract': '人工限月',
                       'original_side': side, 'c1_reused': True,
                       'buy_stream': 'reverse' if side == -1 else 'original',
                       'sell_stream': 'original' if side == -1 else 'reverse'})
    result.append({'case_id': '新case', 'session': SESSIONS[0], 'contract': '人工限月',
                   'original_side': 1, 'c1_reused': False, 'buy_stream': 'original', 'sell_stream': 'reverse'})
    return result


def event(eid: str, index: int, buy: list, sell: list, case_id: str = '新case') -> tuple[dict, dict]:
    """
    機能: 人工q0判断と別の取得票を作る。
    引数: eid(str)、index(int)、buy/sell(list)、case_id(str)。返り値: tuple[dict,dict]。
    """
    decision = {'event_id': eid, 'session': SESSIONS[0], 'contract': '人工限月',
                'q0_time': 1000 + index, 'q0_index': index, 'q0_line': index + 100,
                '判断': selector.decide(buy, sell, BOOK, INDEX)}
    legacy_sell = case_id == 'C1/0'
    capture = {'event_id': eid, 'session': SESSIONS[0], 'contract': '人工限月',
               'q0': {'time': decision['q0_time'], 'index': index, 'source_line': index + 100},
               'status': 'filled', 'case_id': case_id,
               'buy_stream': 'reverse' if legacy_sell else 'original',
               'sell_stream': 'original' if legacy_sell else 'reverse',
               'q1': {'last': 123456, 'bid': 123450, 'ask': 123460}}
    return decision, capture


class Independent149(unittest.TestCase):
    """自然のq0にルールを適用しない、独立fixtureの準備検査。"""

    def test_01_null_and_boundaries(self) -> None:
        """
        機能: NULL・不正数値・演算子・範囲両端を検査する。
        引数: self(Independent149)。返り値: None。
        """
        for operator, boundary, value, expected in [('>', 0, 0, False), ('>=', 0, 0, True),
                                                   ('<', 0, 0, False), ('<=', 0, 0, True)]:
            v = vector(); v[INDEX['m15_adx']] = value
            self.assertEqual(selector.matches(v, [['m15_adx', operator, boundary]], INDEX), expected)
        for value, expected in [(-.5, True), (.5, True), (-.5000001, False), (.5000001, False), (None, False)]:
            v = vector(); v[INDEX['m15_adx']] = value
            self.assertEqual(selector.matches(v, [['m15_adx', '範囲', -.5, .5]], INDEX), expected)
        for value in (math.nan, math.inf, True):
            v = vector(); v[INDEX['m15_adx']] = value
            with self.assertRaises(AssertionError): selector.matches(v, [['m15_adx', '>', 0]], INDEX)

    def test_02_common_and_required_null(self) -> None:
        """
        機能: 共通スプレッド/乖離の境界と必要NULLを検査する。
        引数: self(Independent149)。返り値: None。
        """
        for spread, expected in [(0, 0), (20, 1), (20.0001, 0), (None, 0)]:
            v = vector('T1'); v[INDEX['q0_spread_points']] = spread
            self.assertEqual(selector.decide(v, vector(), BOOK, INDEX)['方向']['T1'], expected)
        for gap, expected in [(-1, 1), (1, 1), (-1.00001, 0), (1.00001, 0)]:
            v = vector('T1'); v[INDEX['q0_last_minus_m1_close_atr5_to_side']] = gap
            self.assertEqual(selector.decide(v, vector(), BOOK, INDEX)['方向']['T1'], expected)
        v = vector('T1'); v[INDEX['m30_ema21_delta_atr_to_side']] = None
        self.assertEqual(selector.decide(v, vector(), BOOK, INDEX)['方向']['T1'], 0)

    def test_03_side_symmetry_and_multiple_ids(self) -> None:
        """
        機能: 売り特徴を再negateせず、同側の成立IDを全保持する。
        引数: self(Independent149)。返り値: None。
        """
        a = selector.decide(vector('両方'), vector(), BOOK, INDEX)
        b = selector.decide(vector(), vector('両方'), BOOK, INDEX)
        self.assertEqual(a['成立ID']['1'], ['T1', 'T3'])
        self.assertEqual(b['成立ID']['-1'], ['T1', 'T3'])
        self.assertEqual((a['方向']['OR8'], b['方向']['OR8']), (1, -1))

    def test_04_both_sides_wait_or(self) -> None:
        """
        機能: 同じ又は違うルールの両側成立をORで待機にする。
        引数: self(Independent149)。返り値: None。
        """
        both = selector.decide(vector('T1'), vector('T1'), BOOK, INDEX)
        self.assertEqual(both['方向']['T1'], 0)
        self.assertEqual(both['方向']['OR8'], 0)
        cross = selector.decide(vector('T1'), vector('T3'), BOOK, INDEX)
        self.assertEqual((cross['方向']['T1'], cross['方向']['T3'], cross['方向']['OR8']), (1, -1, 0))
        self.assertTrue(cross['OR両方向成立'])

    def test_05_canonical_and_c1_priority(self) -> None:
        """
        機能: 同q1の最初選択q0と、反対側C1でも旧方向優先を検査する。
        引数: self(Independent149)。返り値: None。
        """
        early, ec = event('早い', 10, vector('両方'), vector())
        late, lc = event('遅い', 20, vector(), vector('T1'))
        old, oc = event('旧重複', 30, vector('T1'), vector(), 'C1/0')
        decisions, captures, cases = [late, old, early], [oc, lc, ec], cases_fixture()
        before = copy.deepcopy((decisions, captures, cases))
        result = selector.connect(decisions, captures, cases, SESSIONS)
        new = next(r for r in result['政策']['OR8'] if r['case_id'] == '新case')
        self.assertEqual((new['event_id'], new['side'], new['成立ID']), ('早い', 1, ['T1', 'T3']))
        self.assertEqual(len(result['政策']['OR8']), 2)
        self.assertEqual(len(result['政策']['U0']), 88)
        protected = next(r for r in result['政策']['U0'] if r['case_id'] == 'C1/0')
        self.assertEqual((protected['side'], protected['stream'], protected['event_id']), (-1, 'original', None))
        self.assertTrue(result['旧C1重複'][0]['opposite'])
        self.assertEqual(result['候補と取得']['OR8']['同物理q1の後発参照'], 1)
        self.assertEqual((decisions, captures, cases), before)

    def test_06_connection_guards(self) -> None:
        """
        機能: duplicate/scope/q0時点/73場不整合を拒否する。
        引数: self(Independent149)。返り値: None。
        """
        d, c = event('人工', 10, vector('T1'), vector())
        with self.assertRaises(AssertionError): selector.connect([d, d], [c], cases_fixture(), SESSIONS)
        with self.assertRaises(AssertionError): selector.connect([d], [c], cases_fixture(), SESSIONS + [SESSIONS[0]])
        for key in ('time', 'index', 'source_line'):
            bad = copy.deepcopy(c); bad['q0'][key] += 1
            with self.assertRaises(AssertionError): selector.connect([d], [bad], cases_fixture(), SESSIONS)
        bad = copy.deepcopy(c); bad['contract'] = '異限月'
        with self.assertRaises(AssertionError): selector.connect([d], [bad], cases_fixture(), SESSIONS)

    def test_07_main_order_and_q1_invariance(self) -> None:
        """
        機能: 全q0判断完了前はq1をparseせず、未来q1価格が判断を変えないことを確認する。
        引数: self(Independent149)。返り値: None。
        """
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            d, capture = event('人工', 10, vector('T1'), vector())
            common = {'success': True, 'trial': 148, 'sessions': SESSIONS, 'financial_labels_used': False,
                      'selected_trade_count': None, 'strategy_selected': False, 'counts': {'人工': 1}, 'statuses': {'filled': 1}}
            for key in ('input_sha256', 'parent_source_sha256', 'parent_gzip_sha256', 'background_sha256', 'catalog_sha256', 'catalog_definition_sha256'):
                common[key] = key + '人工'
            x = {**common, 'catalog': COLS, 'rows': [{'event_id': d['event_id'], 'session': d['session'], 'contract': d['contract'],
                 'metadata': {'q0': capture['q0']}, 'buy': {'side': 1, 'x': vector('T1')}, 'sell': {'side': -1, 'x': vector()}}]}
            m = {'success': True, 'trial': 148, 'sessions': SESSIONS, 'financial_labels_used': False, 'population148': {'cases': cases_fixture()}}
            original_decide, original_read = selector.decide, Path.read_bytes
            decisions = []
            for attempt in range(2):
                count = [0]; cap = copy.deepcopy(capture)
                cap['q1']['last'] += attempt * 100000
                paths = {name: base / f'{name}{attempt}.json' for name in ('rules', 'features', 'captures', 'metadata')}
                values = {'rules': BOOK, 'features': x, 'captures': {**common, 'rows': [cap]}, 'metadata': m}
                for name, path in paths.items(): path.write_text(json.dumps(values[name], ensure_ascii=False), encoding='utf-8')
                def spy_decide(*args):
                    """
                    機能: q0判定だけの完了回数を記録する。
                    引数: args(tuple)。返り値: dictは対象関数の結果。
                    """
                    count[0] += 1
                    return original_decide(*args)
                def spy_read(path):
                    """
                    機能: captures/metadataのparse前に全q0判定が済んだことを確認する。
                    引数: path(Path)。返り値: bytes。
                    """
                    if path in (paths['captures'], paths['metadata']): self.assertEqual(count[0], 1)
                    return original_read(path)
                output = base / f'output{attempt}'
                argv = ['選択する.py', '--output-dir', str(output)]
                for name, path in paths.items(): argv += ['--' + name, str(path), '--' + name + '-sha256', digest(path)]
                with mock.patch.object(selector, 'decide', side_effect=spy_decide), mock.patch.object(Path, 'read_bytes', new=spy_read), mock.patch.object(sys, 'argv', argv), contextlib.redirect_stdout(io.StringIO()):
                    selector.main()
                decisions.append((output / 'q0の判断.json').read_bytes())
            self.assertEqual(decisions[0], decisions[1])


def first_natural_row(path: Path) -> dict:
    """
    機能: 148生成物の先頭1rowだけをschema確認用に読む。
    引数: path(Path)。返り値: dict。売買条件の適用・自然選択は行わない。
    """
    text = ''
    with path.open('r', encoding='utf-8') as stream:
        while True:
            chunk = stream.read(65536)
            assert chunk
            text += chunk
            found = re.search(r'"rows"\s*:\s*\[', text)
            if not found: continue
            body = text[found.end():].lstrip()
            try:
                row, _ = json.JSONDecoder().raw_decode(body)
                return row
            except json.JSONDecodeError:
                assert len(text) < 1024 * 1024


def main() -> None:
    """
    機能: 独立7群と小範囲自然schemaを確認し停止票を保存する。
    引数: なし。返り値: None。148金融/Raw/追加2場/自然選択を行わない。
    """
    sources = (CODE, RULES, MD, CATALOG)
    before = {p.relative_to(ROOT).as_posix(): digest(p) for p in sources}
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(Independent149)
    log = io.StringIO()
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
    (HERE / '人工のログ.txt').write_text(log.getvalue(), encoding='utf-8')
    assert result.wasSuccessful(), log.getvalue()
    natural = ROOT / 'work/148全1分母集団の評価/母集団生成'
    x = first_natural_row(natural / '当時特徴.json')
    c = first_natural_row(natural / '取得対応.json')
    assert x['event_id'] == c['event_id'] and x['session'] == c['session'] and x['contract'] == c['contract']
    assert all(x['metadata']['q0'][k] == c['q0'][k] for k in ('time', 'index', 'source_line'))
    assert x['buy']['side'] == 1 and x['sell']['side'] == -1
    assert len(x['buy']['x']) == len(x['sell']['x']) == 100
    body = MD.read_text(encoding='utf-8')
    assert all(re.search(r'^\|' + rid + r'\|', body, re.M) for rid in ('T1', 'T2', 'T3', 'T4', 'R1', 'R2', 'R3', 'R4'))
    assert 'U0' in body and 'ATR' in body
    assert before == {p.relative_to(ROOT).as_posix(): digest(p) for p in sources}
    proof = {'成功': True, '状態': '149候補の独立準備レビュー・編集停止', '正式149採番': False,
             '独立人工主群': result.testsRun, '人工ログSHA256': digest(HERE / '人工のログ.txt'),
             '確認範囲': ['NULL/範囲包含/比較厳密境界', 'side変換済み配列へ同一条件', '同側成立ID全部保持',
                       '個別/OR両方向待機', '同q1最初選択q0/C1反対方向も旧優先',
                       'duplicate/scope/q0時点/73場guard', '全q0判断後だけq1 parse', '未来q1価格非依存'],
             'MD_JSON': '8行の意図/符号/閾値/共通条件を静的確認。主U0とATR正規化NULLの明文化をRootが反映',
             '自然schema確認': '生成features/capturesの先頭1rowだけ。metadata.q0.source_line/両side100/scene/contract/id一致。自然rowへdecideを適用していない',
             '自然選択/148金融/Raw/追加2場読取': False, '対象源前後同体': before,
             '対象コード編集': False, '私有人工コードSHA256': digest(Path(__file__)), '重大未解決': []}
    target = HERE / '準備の確認.json'
    target.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'proof_sha256': digest(target), 'groups': result.testsRun, 'sources': before}, ensure_ascii=False))


if __name__ == '__main__':
    main()
