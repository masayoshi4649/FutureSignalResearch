"""q0の技術特徴だけで8局面を判定し、後段で148の取得参照を結ぶ。"""
from pathlib import Path
from collections import Counter
import argparse
import hashlib
import json
import math


def sha(path: Path) -> str:
    """
    機能: 全件保持をせず保存bytesの指紋を計算する。
    引数: path(Path)は対象ファイル。
    返り値: strはSHA256。
    """
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


# ----------------------------------------
def save(path: Path, value: object) -> None:
    """
    機能: UTF-8の新規JSONを排他的に保存する。
    引数: path(Path)は未作成先、value(object)はJSON値。
    返り値: None。
    """
    with path.open('x', encoding='utf-8', newline='\n') as target:
        json.dump(value, target, ensure_ascii=False, indent=2, allow_nan=False)
        target.write('\n')


# ----------------------------------------
def validate(book: dict, catalog: list[dict]) -> dict[str, int]:
    """
    機能: 可読ルールの使用列・演算子・役割数を確認する。
    引数: book(dict)は固定ルール、catalog(list[dict])は100列の定義。
    返り値: dict[str,int]は列名から列番号への対応。
    """
    index = {column['name']: i for i, column in enumerate(catalog)}
    roles = {column['name']: column['role'] for column in catalog}
    assert len(index) == 100
    assert [r['id'] for r in book['ルール']] == ['T1', 'T2', 'T3', 'T4', 'R1', 'R2', 'R3', 'R4']
    for rule in [{'条件': book['共通']}] + book['ルール']:
        for term in rule['条件']:
            assert term[0] in index and term[1] in ('>', '>=', '<', '<=', '範囲')
            assert len(term) == (4 if term[1] == '範囲' else 3)
            assert all(isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) for v in term[2:])
            if term[1] == '範囲':
                assert term[2] <= term[3]
        if 'id' in rule:
            assert len({roles[t[0]] for t in rule['条件']}) >= 3
    return index


# ----------------------------------------
def matches(vector: list[float | None], terms: list[list], index: dict[str, int]) -> bool:
    """
    機能: 一方向の当時特徴だけでAND条件を判定する。
    引数: vector(list[float|None])、terms(list[list])、index(dict[str,int])。
    返り値: bool。必要な未知値は不成立、範囲は両端を含む。
    """
    assert len(vector) == 100
    for name, operator, *limits in terms:
        value = vector[index[name]]
        if value is None:
            return False
        assert isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)
        boundary = limits[0]
        result = (value > boundary if operator == '>' else value >= boundary if operator == '>='
                  else value < boundary if operator == '<' else value <= boundary if operator == '<='
                  else boundary <= value <= limits[1])
        if not result:
            return False
    return True


# ----------------------------------------
def decide(buy: list, sell: list, book: dict, index: dict[str, int]) -> dict:
    """
    機能: 同じ条件を両方向へ適用し、局面ごととORの方向を決める。
    引数: buy/sell(list)は独立に計算済みの100特徴、book(dict)、index(dict[str,int])。
    返り値: dictは共通条件・成立ID・方向。両方向成立は0で待機する。
    """
    hits = {}
    common = {}
    for side, vector in ((1, buy), (-1, sell)):
        common[str(side)] = matches(vector, book['共通'], index)
        hits[str(side)] = [r['id'] for r in book['ルール']
                           if common[str(side)] and matches(vector, r['条件'], index)]
    directions = {}
    for name in [r['id'] for r in book['ルール']] + ['OR8']:
        positive = bool(hits['1']) if name == 'OR8' else name in hits['1']
        negative = bool(hits['-1']) if name == 'OR8' else name in hits['-1']
        directions[name] = 1 if positive and not negative else -1 if negative and not positive else 0
    return {'共通条件': common, '成立ID': hits, '方向': directions,
            'OR両方向成立': bool(hits['1'] and hits['-1'])}


# ----------------------------------------
def connect(decisions: list[dict], captures: list[dict], cases: list[dict], sessions: list[str]) -> dict:
    """
    機能: 固定済みq0判断にq1取得結果を結び、物理取得を政策ごとに一度だけ数える。
    引数: decisions(list[dict])、captures(list[dict])、cases(list[dict])、sessions(list[str])。
    返り値: dictは政策別取得参照・出生/不取得計数・旧C1優先の統合参照。
    """
    cap = {row['event_id']: row for row in captures}
    physical = {row['case_id']: row for row in cases}
    assert len(cap) == len(captures) and len(physical) == len(cases)
    assert len({row['event_id'] for row in decisions}) == len(decisions)
    assert len(sessions) == len(set(sessions)) == 73
    assert set(cap) == {row['event_id'] for row in decisions}
    session_order = {session: i for i, session in enumerate(sessions)}
    policies = {name: {} for name in ('T1', 'T2', 'T3', 'T4', 'R1', 'R2', 'R3', 'R4', 'OR8')}
    counts = {name: Counter() for name in policies}
    ordered = sorted(decisions, key=lambda row: (session_order[row['session']], row['q0_index'], row['q0_line'], row['event_id']))
    for row in ordered:
        acquisition = cap[row['event_id']]
        assert acquisition['session'] == row['session'] and acquisition['contract'] == row['contract']
        assert all(acquisition['q0'][name] == row[target] for name, target in
                   (('time', 'q0_time'), ('index', 'q0_index'), ('source_line', 'q0_line')))
        for name, side in row['判断']['方向'].items():
            if not side:
                continue
            counts[name]['候補成立'] += 1
            counts[name][acquisition['status']] += 1
            if acquisition['status'] != 'filled':
                continue
            case_id = acquisition['case_id']
            case = physical[case_id]
            assert case['session'] == row['session'] and case['contract'] == row['contract']
            if case_id in policies[name]:
                counts[name]['同物理q1の後発参照'] += 1
                continue
            stream = acquisition['buy_stream' if side == 1 else 'sell_stream']
            assert stream == case['buy_stream' if side == 1 else 'sell_stream']
            policies[name][case_id] = {'case_id': case_id, 'session': row['session'], 'side': side,
                'stream': stream, 'event_id': row['event_id'], 'feature_ref': row['event_id'],
                'q0_time': row['q0_time'], 'q0_index': row['q0_index'], 'q0_line': row['q0_line'],
                '成立ID': row['判断']['成立ID'][str(side)], 'origin': name}
    legacy = {case_id: {'case_id': case_id, 'session': case['session'], 'side': case['original_side'],
              'stream': 'original', 'event_id': None, 'feature_ref': None, 'origin': 'C1'}
              for case_id, case in physical.items() if case['c1_reused']}
    assert len(legacy) == 87
    union = dict(legacy)
    overlaps = []
    for case_id, row in policies['OR8'].items():
        if case_id in union:
            overlaps.append({'case_id': case_id, 'C1方向': union[case_id]['side'], 'OR8方向': row['side'],
                             'opposite': union[case_id]['side'] != row['side']})
        else:
            union[case_id] = row
    policies['C1'] = legacy
    policies['U0'] = union
    return {'政策': {name: list(rows.values()) for name, rows in policies.items()},
            '候補と取得': {name: dict(values) for name, values in counts.items()},
            '旧C1重複': overlaps, '全73場': sessions,
            '選択時の金融ラベル利用': False, 'C1は後段固定対照としてのみ統合': True}


# ----------------------------------------
def main() -> None:
    """
    機能: ラベルを開かず全適格q0を判定し、別段階で取得/旧対照を結ぶ。
    引数: CLIのルール・特徴・取得・参照各Path/SHAと未作成output-dir。
    返り値: None。自然Raw・先着観測・損益を読まない。
    """
    parser = argparse.ArgumentParser(description='可読8局面のq0選択と取得対応')
    for name in ('rules', 'features', 'captures', 'metadata'):
        parser.add_argument('--' + name, type=Path, required=True)
        parser.add_argument('--' + name + '-sha256', required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output_dir.exists()
    paths = {name: getattr(args, name) for name in ('rules', 'features', 'captures', 'metadata')}
    before = {name: sha(path) for name, path in paths.items()}
    assert all(before[name] == getattr(args, name + '_sha256') for name in paths)
    book = json.loads(paths['rules'].read_bytes())
    features = json.loads(paths['features'].read_bytes())
    assert features['success'] and features['trial'] == 148 and not features['financial_labels_used']
    assert features['selected_trade_count'] is None and not features['strategy_selected']
    index = validate(book, features['catalog'])
    decisions = []
    for row in features['rows']:
        q0 = row['metadata']['q0']
        assert row['buy']['side'] == 1 and row['sell']['side'] == -1
        decisions.append({'event_id': row['event_id'], 'session': row['session'], 'contract': row['contract'],
            'q0_time': q0['time'], 'q0_index': q0['index'], 'q0_line': q0['source_line'],
            '判断': decide(row['buy']['x'], row['sell']['x'], book, index)})
    captures = json.loads(paths['captures'].read_bytes())
    metadata = json.loads(paths['metadata'].read_bytes())
    assert captures['trial'] == metadata['trial'] == 148
    assert captures['success'] and metadata['success']
    assert not captures['financial_labels_used'] and not metadata['financial_labels_used']
    assert captures['sessions'] == features['sessions'] == metadata['sessions']
    for name in ('input_sha256', 'parent_source_sha256', 'parent_gzip_sha256',
                 'background_sha256', 'catalog_sha256', 'catalog_definition_sha256', 'counts', 'statuses'):
        assert captures[name] == features[name], name
    result = connect(decisions, captures['rows'], metadata['population148']['cases'], features['sessions'])
    assert all(sha(path) == before[name] for name, path in paths.items())
    args.output_dir.mkdir(parents=True)
    save(args.output_dir / 'q0の判断.json', {'成功': True, '試行': 149, '出生判断数': len(decisions),
        'q1結合前に全件判断': True, '金融ラベル利用': False, 'rows': decisions})
    save(args.output_dir / '選択対応.json', {'成功': True, '試行': 149, '入力SHA256': before, **result})
    save(args.output_dir / '選択の確認.json', {'成功': True, '試行': 149, '金融ラベル未読': True,
        '入力': {str(path.resolve()): before[name] for name, path in paths.items()},
        '出力': {p.name: sha(p) for p in sorted(args.output_dir.iterdir()) if p.is_file()},
        '政策別取得数': {name: len(rows) for name, rows in result['政策'].items()},
        'OR両方向待機数': sum(row['判断']['OR両方向成立'] for row in decisions)})
    print(json.dumps({'成功': True, '判断数': len(decisions),
        '政策別取得数': {name: len(rows) for name, rows in result['政策'].items()}}, ensure_ascii=False))


if __name__ == '__main__':
    main()
