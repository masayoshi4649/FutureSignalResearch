"""149の可読ルールとq0入力を固定し、先着ラベルを開かず入口を選ぶ。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
OWN = ROOT / 'work/149可読8局面の評価'
GEN = ROOT / 'work/148全1分母集団の評価/母集団生成'
FORMAL = ROOT / 'study/00149_継続と反転を可読8局面で判定する'
RULES = ROOT / 'work/149候補_可読8局面.json'
SELECTOR = ROOT / 'work/149可読局面の入口選択/選択する.py'
INDEPENDENT = ROOT / 'work/149可読選択の独立準備レビュー'
INPUTS = {'rules': RULES, 'features': GEN / '当時特徴.json',
          'captures': GEN / '取得対応.json', 'metadata': GEN / '入口参照.json'}
EXPECTED = {'rules': 'bbb4f2dee4dc05007309351222205f76b3cca8d628b2ff436a835049c7cb67ad',
    'features': '572705d7db8529555c876eb1953f7d8e1cd1de0e554bf9de729a7d377e4d91af',
    'captures': 'e433b79f87411c34232acac57a8aed191da71bcd1888376b19196099cbf9909a',
    'metadata': '66511104a6efd7bc936b0e624469a2de43e9fa5b5fa7645304499f793c25329c'}


def sha(path: Path) -> str:
    """
    機能: 保存bytesを全保持せずSHAを求める。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


# ----------------------------------------
def helper_module() -> object:
    """
    機能: 既存の排他保存と固定源検査を共有する。
    引数: なし。
    返り値: objectは133補助モジュール。
    """
    spec = importlib.util.spec_from_file_location('固定補助149', ROOT / 'work/133金融前を固定して実行する.py')
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    return helper


# ----------------------------------------
def main() -> None:
    """
    機能: 入力/条件F0→q0判断/取得参照→選択後F1を別段階で作る。
    引数: CLI mode(str)は固定又は選択。
    返り値: None。既存出力を改変せず、先着ラベルを読み込まない。
    """
    parser = argparse.ArgumentParser(description='149可読8局面を固定して選択する')
    parser.add_argument('--mode', choices=('固定', '選択'), required=True)
    args = parser.parse_args()
    helper = helper_module()
    OWN.mkdir(parents=True, exist_ok=True)
    f0 = OWN / 'F0入口選択前.json'
    f1 = OWN / 'F1入口選択後.json'
    output = OWN / '入口選択'
    if args.mode == '固定':
        assert all(sha(path) == EXPECTED[name] for name, path in INPUTS.items())
        assert sha(SELECTOR) == '6588ab9eca392d9ea3a7697fba949f816aab76b8270f1601f4fd2b0536c02e02'
        proof = INDEPENDENT / '準備の確認.json'
        supplement = INDEPENDENT / '正式と全8局面の補足.json'
        assert sha(proof) == '0271cf9e18b367a409333af7734d197c52f409d806d7b9de8644e381755beec8'
        assert sha(supplement) == '9c8e47fbabcef0ce8ff0fae746bda5e6b116be675618afce59db3ec519023b23'
        confirmed = json.loads(supplement.read_bytes())
        assert confirmed['成功']
        for name, expected in confirmed['正式3MD'].items():
            assert sha(FORMAL / name) == expected
        for name, expected in confirmed['固定対象'].items():
            assert sha(ROOT / name) == expected
        files = set(INPUTS.values()) | {Path(__file__).resolve(), SELECTOR,
            ROOT / 'work/133金融前を固定して実行する.py',
            ROOT / 'work/149候補_技術局面を分けた可読入口.md',
            ROOT / 'work/148全1分母集団の評価/F1全case観測前.json',
            ROOT / 'work/148全1分母集団の評価/観測の完了.json',
            ROOT / 'work/148母集団の独立全件監査/監査の確認.json',
            ROOT / 'inputs/00148_全1分入口母集団/100特徴の列定義.json'}
        files.update(p for p in INDEPENDENT.iterdir() if p.is_file() and p.suffix in ('.py', '.json', '.md', '.txt'))
        files.update(FORMAL / name for name in ('README.md', '条件.md', '設定と結果.md'))
        files.update(ROOT / 'inputs/00148_全1分入口母集団' / (name + '.json.gz')
                     for name in ('当時特徴', '取得対応', '入口参照'))
        helper.save(f0, {'成功': True, '試行': 149, '段階': '可読8局面の入口選択前F0',
            'UTC': datetime.now(timezone.utc).isoformat(), '主政策': 'U0',
            '先着ラベルを選択へ渡す': False, '全73場は既使用': True, '追加2場価格未読': True,
            'ファイル': {str(path.resolve()): sha(path) for path in sorted(files)}})
        print(json.dumps({'F0_SHA256': sha(f0), '固定源数': len(files)}, ensure_ascii=False))
        return
    fixed = json.loads(f0.read_bytes())
    helper.verify(fixed)
    assert not output.exists()
    command = [sys.executable, '-X', 'utf8', str(SELECTOR)]
    for name, path in INPUTS.items():
        command += ['--' + name, str(path), '--' + name + '-sha256', EXPECTED[name]]
    command += ['--output-dir', str(output)]
    subprocess.run(command, cwd=ROOT, check=True)
    helper.verify(fixed)
    selection = json.loads((output / '選択の確認.json').read_bytes())
    assert selection['成功'] and selection['金融ラベル未読']
    decisions = json.loads((output / 'q0の判断.json').read_bytes())
    assert decisions['出生判断数'] == len(decisions['rows']) == 35339 and not decisions['金融ラベル利用']
    files = {Path(path) for path in fixed['ファイル']} | {f0}
    files.update(path for path in output.iterdir() if path.is_file())
    helper.save(f1, {'成功': True, '試行': 149, '段階': '全q0判断と取得参照後F1',
        'UTC': datetime.now(timezone.utc).isoformat(), 'F0_SHA256': sha(f0),
        'ラベルを開く前に入口選択済み': True, '親の観測SHA256': 'd1b4cab8a258203f04b5c1d081f57d10ed2a0c58ce4cc160ef571d5fac0ceffc',
        '政策別取得数': selection['政策別取得数'],
        'ファイル': {str(path.resolve()): sha(path) for path in sorted(files)}})
    print(json.dumps({'成功': True, 'F1_SHA256': sha(f1), '政策別取得数': selection['政策別取得数']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
