"""固定集計の全73場へ、既知収支と未知件数を区別した累計列を追加する。"""
from pathlib import Path
import argparse
import hashlib
import json


def sha(path: Path) -> str:
    """
    機能: 保存bytesのSHAを求める。
    引数: path(Path)は小型の表又は集計JSON。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 全場を残し、未知を0扱いしない累計を既存三表へ付ける。
    引数: CLI input/summary/output(Path)と入力2点の期待SHA。
    返り値: None。既存集計/売買選択を変更せず、新規typed JSONだけを保存する。
    """
    parser = argparse.ArgumentParser(description='149CSV用三表へ既知/未知の累計を追加')
    for name in ('input', 'summary', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    for name in ('input-sha256', 'summary-sha256'):
        parser.add_argument('--' + name, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    assert sha(args.input) == args.input_sha256 and sha(args.summary) == args.summary_sha256
    value = json.loads(args.input.read_bytes())
    summary = json.loads(args.summary.read_bytes())
    assert value['試行'] == summary['試行'] == 149
    table = next(table for table in value['tables'] if table['name'] == '全セッション')
    assert len(table['rows']) == 73
    original = list(table['headers'])
    for policy in ('U0', 'OR8', 'C1'):
        indices = {key: original.index(policy + key) for key in ('IFD既知', 'IFD未知', 'C5利益', 'C5損失絶対', 'C5差引')}
        table['headers'].extend(policy + suffix for suffix in ('C5既知利益累計', 'C5既知損失累計', 'C5既知差引累計', 'IFD未知累計', 'C5全件確定差引累計'))
        known = unknown = profit = loss = 0
        for number, row in enumerate(table['rows']):
            count = row[indices['IFD既知']]
            unknown += row[indices['IFD未知']]
            known += count
            if count:
                gain = row[indices['C5利益']]
                damage = row[indices['C5損失絶対']]
                assert gain - damage == row[indices['C5差引']]
                profit += gain
                loss += damage
            else:
                assert row[indices['C5利益']] is None and row[indices['C5損失絶対']] is None and row[indices['C5差引']] is None
            net = profit - loss if known else None
            row.extend([profit if known else None, loss if known else None, net, unknown, net if unknown == 0 else None])
            if number in (47, 72):
                part = 'train' if number == 47 else 'all'
                actual = summary['集計'][part][policy]['BBO']['3600']['125']
                assert known == actual['ifd_known'] and unknown == actual['ifd_unknown']
                assert net == actual['ifd_net5_sum']
                assert (profit if known else None) == actual['ifd_net5_profit']
                assert (loss if known else None) == actual['ifd_net5_loss']
    assert all(len(row) == len(table['headers']) for row in table['rows'])
    assert sha(args.input) == args.input_sha256 and sha(args.summary) == args.summary_sha256
    value['累計の定義'] = '独立mini1枚/C5。利益・損失・差引は既知分累計、IFD未知を別累計。未知が1件でもあれば全件確定差引はNULL。10枚口座収支ではない。'
    value['元の表SHA256'] = args.input_sha256
    value['集計SHA256'] = args.summary_sha256
    with args.output.open('x', encoding='utf-8', newline='\n') as target:
        json.dump(value, target, ensure_ascii=False, indent=2, allow_nan=False)
        target.write('\n')
    print(json.dumps({'成功': True, '全場数': 73, '全セッション列数': len(table['headers']), '表SHA256': sha(args.output)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
