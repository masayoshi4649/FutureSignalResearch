"""149の固定選択だけを148保存正逆へ結合し、900比較と主取得を診断する。"""
from pathlib import Path
from collections import Counter
import argparse
import copy
import importlib.util
import json
import math
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
BASE=ROOT/'work/148母集団の診断集計/集計する.py'
ARITHMETIC=ROOT/'work/124入口の原因分析/集計する.py'
OLD_PAIRS=ROOT/'work/145構造イベントの評価/固定取得の正逆観測.json'
OLD_SUMMARY=ROOT/'work/145構造イベントの評価/金融評価/集計.json'
SOURCES={BASE:'0ae8287b67b53df0d07c22963e2bf9ecd0775af9b0545a89f6a61af6ec2ec309',ARITHMETIC:'8479ca348231ffd77a637360797750833c9e6617c7fc4a6502e015c7a1d9f04a',OLD_PAIRS:'3b92da8b447d7be9ead6a2a112759ca7272a1e65d6cb5516989e3faf50c54d62',OLD_SUMMARY:'fb374d53982ce7727c5ae936d72a20a973029de35480ed442a6cb2305fc9c861'}
BRANCHES=('T1','T2','T3','T4','R1','R2','R3','R4')
POLICIES=('C0','C1','RC1',*BRANCHES,'OR8','ROR8','U0','RU0')
AXES=('BBO','Last');HORIZONS=(1800,3600);WIDTHS=(25,50,100,125,200)
COMPARISON_HEADERS=['試行','区分','政策','取得集合','価格軸','評価分','同幅pt','対象場数','取得場数','取得数','格納原側相対反転数','全場最低1取得','全H完了','観測不足','順行先着','逆行先着','両方未到達','到達済み順行率','完了分母順行率','全件分母順行率','到達済み70%','参加と70%共同','全時間取得毎時','名目新規可時間毎時','全時間毎時1以上','三目標共同','IFD既知','IFD未知','C0代用差引円','C5代用利益円','C5代用損失絶対円','C5代用差引円','C5代用平均円','C5代用PF']
DETAIL_HEADERS=['試行','参考区分','セッション','限月','固定caseID','旧新','origin','旧C0subset','選択方向','格納方向','選択stream','買stream','売stream','q0eventID','feature_ref','q0JST','q0index','q0物理行','成立IDs','同caseOR8成立IDs','旧C1とのOR8方向競合','取得JST','取得index','取得物理行','取得Last','取得Bid','取得Ask','選択実P','旧C1同原行保護']
for policy in ('U0','RU0'):DETAIL_HEADERS += [policy+s for s in ('方向','125H状態','125記録方向','125完了方向','125最初到達JST','IFD既知','IFD清算','IFD清算JST','125C5円')]
SCENE_HEADERS=['試行','セッション','参考区分','ザラバ時間h','名目新規可時間h',*[p+'取得数'for p in POLICIES],'U0全時間毎時','OR8全時間毎時','U0最低1','U0名目H60連結群数','U0最大連結群件数']
for policy in ('U0','OR8','C1'):SCENE_HEADERS += [policy+s for s in ('125順','125逆','125未','125不足','IFD既知','IFD未知','C5利益','C5損失絶対','C5差引')]


def sha(path: Path) -> str:
    """
    機能: 大型観測を固定bufferで指紋化する。
    引数: path(Path)。返り値: str。
    """
    h=__import__('hashlib').sha256()
    with path.open('rb')as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()


def module(path: Path,name: str):
    """
    機能: mainを実行せず固定コードだけを私有importする。
    引数: path(Path)、name(str)。返り値: ModuleType。
    """
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m


def selected(record: dict,policy: str,axis: str) -> dict:
    """
    機能: 固定side票のstreamを保持し実逆対照だけ反転する。
    引数: record(dict)、policy/axis(str)。返り値: dict。
    """
    return record['case'][('chart_'if axis=='Last'else '')+record['choices'][policy]['stream']]


def arithmetic():
    """
    機能: 作者124算術のselectedだけを149へ差し替える。
    引数: なし。返り値: ModuleType。
    """
    assert sha(ARITHMETIC)==SOURCES[ARITHMETIC];m=module(ARITHMETIC,'private124for149');m.selected=selected;m.POLICIES=POLICIES;return m


def bind_choices(records: dict,members: dict,selection: dict,strict: bool=True) -> dict:
    """
    機能: 一度決まった選択票を再判定せず全政策へ結合する。
    引数: records/members/selection(dict)、strict(bool)。返り値: dict。
    """
    assert selection['成功'] and selection['試行']==149 and not selection['選択時の金融ラベル利用']
    output={key:{**r,'choices':{}}for key,r in records.items()}
    policies={p:copy.deepcopy(selection['政策'][p])for p in (*BRANCHES,'OR8','C1','U0')}
    policies['C0']=[r for r in policies['C1']if r['case_id']in members['C0']]
    for dest,source in [('RC1','C1'),('ROR8','OR8'),('RU0','U0')]:
        policies[dest]=[{**r,'side':-r['side'],'stream':'reverse'if r['stream']=='original'else 'original','origin':dest}for r in policies[source]]
    assert {r['case_id']for r in policies['C1']}==members['C1']
    for policy,rows in policies.items():
        ids=set()
        for choice in rows:
            key=choice['case_id'];assert key not in ids;ids.add(key);r=output[key]
            assert r['session']==choice['session'] and choice['stream']in ('original','reverse') and choice['side']==r['case'][choice['stream']]['birth']['side']
            r['choices'][policy]=choice
    if strict:
        expected={'C0':81,'C1':87,'RC1':87,'T1':442,'T2':2328,'T3':1212,'T4':64,'R1':31,'R2':127,'R3':59,'R4':81,'OR8':4085,'ROR8':4085,'U0':4156,'RU0':4156}
        assert {p:sum(p in r['choices']for r in output.values())for p in POLICIES}==expected
    return output


def subset(records: dict,policy: str,scope: list) -> list:
    """
    機能: 固定政策と場の集合だけを絞る。
    引数: records(dict)、policy(str)、scope(list)。返り値: list。
    """
    return [r for r in records.values()if policy in r['choices'] and r['session']in scope]


def overlap(rows: list,sessions: list) -> dict:
    """
    機能: 名目H60半開窓の重複連結群を当場ごとに計数する。
    引数: rows(list)、sessions(list)。返り値: dict。
    """
    groups=[];per_scene={}
    for sid in sessions:
        ordered=sorted((r for r in rows if r['session']==sid),key=lambda r:(r['case']['original']['entry']['time'],r['case']['original']['entry']['index'],r['case']['id']))
        components=[];current=None
        for r in ordered:
            t=r['case']['original']['entry']['time'];end=t+3600
            if current is None or t>=current['end']:
                current={'session':sid,'start':t,'end':end,'cases':1};components.append(current)
            else:current['end']=max(current['end'],end);current['cases']+=1
        per_scene[sid]={'件数':len(ordered),'連結群数':len(components),'最大群件数':max((c['cases']for c in components),default=0)};groups.extend(components)
    n=len(rows);counts=[per_scene[s]['件数']for s in sessions];hhi=sum((x/n)**2 for x in counts)if n else None
    return {'定義':'当場[q1,q1+3600)のstrict重複連結。touchで短縮しない。独立標本数や実保有数ではない。','取得数':n,'連結群数':len(groups),'最大群件数':max((g['cases']for g in groups),default=0),
        '最小場件数':min(counts,default=0),'最大場件数':max(counts,default=0),'上位5場件数比':sum(sorted(counts,reverse=True)[:5])/n if n else None,'場HHI':hhi,'場別':per_scene,'群':groups}


def calculate(records: dict,sessions: list,scenes: list,m) -> tuple:
    """
    機能: 固定15政策を900比較し参加・頻度・共同目標を分離する。
    引数: records(dict)、sessions/scenes(list)、m(ModuleType)。返り値: tuple。
    """
    values={};participation={};freq={};goals={};overlaps={}
    for part,scope in [('all',sessions),('train',sessions[:48]),('validation',sessions[48:])]:
        values[part]={};participation[part]={};freq[part]={};goals[part]={};overlaps[part]={}
        hours=sum((s['end']-300-s['start'])/3600 for s in scenes if s['session']in scope);available=sum((min(s['force_close'],s['end']-3900)-s['start'])/3600 for s in scenes if s['session']in scope)
        for policy in POLICIES:
            rows=subset(records,policy,scope);counts=Counter(r['session']for r in rows);v={a:{str(h):{str(w):m.stats(rows,policy,a,h,w)for w in WIDTHS}for h in HORIZONS}for a in AXES};values[part][policy]=v
            p={'対象場数':len(scope),'取得数':len(rows),'取得場数':len(counts),'未取得場':[s for s in scope if not counts[s]],'全場最低1取得':len(counts)==len(scope),'最小場件数':min((counts[s]for s in scope),default=0),'最大場件数':max((counts[s]for s in scope),default=0)};participation[part][policy]=p
            f={'全時間h':hours,'名目新規可時間h':available,'全時間取得毎時':len(rows)/hours if hours else None,'名目新規可時間毎時':len(rows)/available if available else None};freq[part][policy]=f
            main=v['BBO']['3600']['125'];rate=main['target70'];frequency=f['全時間取得毎時']>=1 if f['全時間取得毎時']is not None else None
            goals[part][policy]={'全場最低1':p['全場最低1取得'],'到達済70%':rate,'全時間毎時1以上':frequency,'三目標共同':p['全場最低1取得'] and rate and frequency if rate is not None and frequency is not None else None}
            overlaps[part][policy]=overlap(rows,scope)
    return values,participation,freq,goals,overlaps


def tables(records: dict,sessions: list,values: dict,p: dict,f: dict,goals: dict,overlaps: dict,selection: dict,capture: dict,meta: dict,m) -> list:
    """
    機能: 900比較/主U0全取得/全73を既存三表契約で保存する。
    引数: records/values/p/f/goals/overlaps/selection/capture/meta(dict)、sessions(list)、m(ModuleType)。返り値: list。
    """
    comparison=[]
    for part in ('all','train','validation'):
        for policy in POLICIES:
            for axis in AXES:
                for h in HORIZONS:
                    for w in WIDTHS:
                        s=values[part][policy][axis][str(h)][str(w)];rate=s['target70'];frequency=f[part][policy]['全時間取得毎時'];present=p[part][policy]['全場最低1取得']
                        comparison.append([149,part,policy,'固定旧対照'if policy in ('C0','C1','RC1')else '固定可読選択',axis,h/60,w,p[part][policy]['対象場数'],s['sessions'],s['entries'],s['flips'],present,s['complete'],s['censored'],s['forward'],s['adverse'],s['neither'],s['resolved_rate'],s['complete_rate'],s['forward']/s['entries']if s['entries']else None,rate,present and rate if rate is not None else None,frequency,f[part][policy]['名目新規可時間毎時'],frequency>=1 if frequency is not None else None,present and rate and frequency>=1 if rate is not None and frequency is not None else None,s['ifd_known'],s['ifd_unknown'],s['ifd_net0_sum'],s['ifd_net5_profit'],s['ifd_net5_loss'],s['ifd_net5_sum'],s['ifd_net5_mean'],s['ifd_net5_pf']])
    descriptor={d['case_id']:d for d in meta['population148']['cases']};old_c0={e['id']for e in meta['entries']if e.get('baseline')is True};or8={x['case_id']:x for x in selection['政策']['OR8']};conflicts={x['case_id']:x['opposite']for x in selection['旧C1重複']}
    detail=[]
    for choice in selection['政策']['U0']:
        r=records[choice['case_id']];case=r['case'];q=case['original']['entry'];d=descriptor[choice['case_id']];o8=or8.get(choice['case_id']);stream=selected(r,'U0','BBO')
        row=[149,'train'if r['session']in sessions[:48]else 'validation',r['session'],r['scene']['contract'],choice['case_id'],'旧C1'if choice['origin']=='C1'else '新OR8',choice['origin'],choice['case_id']in old_c0,choice['side'],case['original_side'],choice['stream'],d['buy_stream'],d['sell_stream'],choice['event_id'],choice['feature_ref'],m.jst(choice['q0_time'])if choice.get('q0_time')is not None else None,choice.get('q0_index'),choice.get('q0_line'),'|'.join(choice.get('成立ID',[])),'|'.join(o8.get('成立ID',[]))if o8 else None,conflicts.get(choice['case_id']),m.jst(q['time']),q['index'],q['source_line'],q['last'],q['bid'],q['ask'],stream['entry_price'],choice['origin']=='C1']
        for policy in ('U0','RU0'):
            c=selected(r,policy,'BBO');o=m.observation(c,3600);t=m.touch(o,125);e=m.ifd(c,o,125,'BBO')
            row.extend([c['birth']['side'],o['status'],t['direction'],t['direction']if o['status']=='complete'else None,m.jst(t['quote']['time'])if t['quote']else None,e['known'],e['reason'],m.jst(e['exit']['time'])if e['exit']else None,e['net5']])
        detail.append(row)
    scenerows=[]
    for i,sid in enumerate(sessions):
        exemplar=next(r['scene']for r in records.values()if r['session']==sid);hours=(exemplar['end']-300-exemplar['start'])/3600;available=(min(exemplar['force_close'],exemplar['end']-3900)-exemplar['start'])/3600
        counts={policy:len(subset(records,policy,[sid]))for policy in POLICIES};ov=overlaps['all']['U0']['場別'][sid]
        row=[149,sid,'train'if i<48 else 'validation',hours,available,*[counts[policy]for policy in POLICIES],counts['U0']/hours,counts['OR8']/hours,counts['U0']>0,ov['連結群数'],ov['最大群件数']]
        for policy in ('U0','OR8','C1'):
            s=m.stats(subset(records,policy,[sid]),policy,'BBO',3600,125);row.extend([s['forward'],s['adverse'],s['neither'],s['censored'],s['ifd_known'],s['ifd_unknown'],s['ifd_net5_profit'],s['ifd_net5_loss'],s['ifd_net5_sum']])
        scenerows.append(row)
    result=[{'name':'正逆比較','headers':COMPARISON_HEADERS,'rows':comparison},{'name':'入口別診断','headers':DETAIL_HEADERS,'rows':detail},{'name':'全セッション','headers':SCENE_HEADERS,'rows':scenerows}]
    assert len(comparison)==900 and len(scenerows)==73
    for table in result:
        assert len(set(table['headers']))==len(table['headers'])
        assert all(len(row)==len(table['headers']) and all(v is None or type(v)in (str,bool,int,float)for v in row)for row in table['rows'])
        assert all(not isinstance(v,float)or math.isfinite(v)for row in table['rows']for v in row)
    return result


def main() -> None:
    """
    機能: 準備票と149F1/選択を先照合してから148保存観測を集計する。
    引数: CLI preparation-sha256/f1/f1-sha256/selection/selection-sha256/generation-dir/result/result-sha256/output-dir。返り値: None。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--preparation-sha256',required=True)
    for name in ('f1','selection','generation-dir','result','output-dir'):parser.add_argument('--'+name,required=True,type=Path)
    for name in ('f1-sha256','selection-sha256','result-sha256'):parser.add_argument('--'+name,required=True)
    args=parser.parse_args();prep_path=HERE/'準備の確認.json';assert sha(prep_path)==args.preparation_sha256;prep=json.loads(prep_path.read_bytes());assert prep['成功']
    assert all(sha(ROOT/x['path'])==x['sha256']for x in prep['源'])
    assert sha(args.f1)==args.f1_sha256 and sha(args.selection)==args.selection_sha256 and sha(args.result)==args.result_sha256
    f1=json.loads(args.f1.read_bytes());declared={str(Path(p).resolve()):h for p,h in f1['ファイル'].items()};assert declared[str(args.selection.resolve())]==args.selection_sha256
    paths={name:args.generation_dir/(name+'.json')for name in ('固定取得入力','入口参照','出生台帳','取得対応','生成の確認')};generation=json.loads(paths['生成の確認'].read_bytes())
    for name,path in paths.items():
        if name!='生成の確認':assert sha(path)==generation['files'][path.name]['sha256']
    inputs={**SOURCES,**{p:sha(p)for p in paths.values()},args.selection:args.selection_sha256,args.f1:args.f1_sha256,args.result:args.result_sha256,prep_path:args.preparation_sha256};assert all(sha(p)==h for p,h in inputs.items())
    # ----------------------------------------
    # 自然本文はRoot実行通知後のこの明示CLI段階だけで開きます。
    base=module(BASE,'frozen148for149');fixed,meta,ledger,capture=[json.loads(paths[n].read_bytes())for n in ('固定取得入力','入口参照','出生台帳','取得対応')]
    observed=json.loads(args.result.read_bytes());selection=json.loads(args.selection.read_bytes());records,members,sessions,phase=base.prepare(observed,fixed,meta,ledger,capture);records=bind_choices(records,members,selection);m=arithmetic()
    values,p,f,goals,overlaps=calculate(records,sessions,fixed['scenes'],m)
    baseline=base.baseline_check(records,values,json.loads(OLD_PAIRS.read_bytes()),json.loads(OLD_SUMMARY.read_bytes()),members)
    result_tables=tables(records,sessions,values,p,f,goals,overlaps,selection,capture,meta,m)
    out={'成功':True,'試行':149,'主政策':'U0','主幅pt':125,'主H秒':3600,'主評価':goals['all']['U0'],'集計':values,'参加':p,'頻度':f,'重複連結群と場集中':overlaps,
        '候補と取得':selection['候補と取得'],'旧C1重複':selection['旧C1重複'],'旧C1同体':baseline,'全4stream_phase':phase,'運用収支':False,'実IFD':False,'100X再読':False,'全期既使用':True,
        'F1_SHA256':args.f1_sha256,'選択対応SHA256':args.selection_sha256,'自然結果SHA256':args.result_sha256,'集計準備SHA256':args.preparation_sha256,
        '限界':['重複H60の連結群は独立標本数でも実ポジション数でもない','全て固定選択の事後金融診断で、新閾値を探していない','mini1枚/C5代用損益の同時合計は10枚口座収支ではない']}
    assert all(sha(p)==h for p,h in inputs.items());args.output_dir.mkdir(parents=True,exist_ok=True)
    base.save(args.output_dir/'集計.json',out);base.save(args.output_dir/'CSV用の表.json',{'成功':True,'試行':149,'主政策':'U0','tables':result_tables})
    base.save(args.output_dir/'集計完了.json',{'成功':True,'試行':149,'前後SHA256':{str(p):h for p,h in inputs.items()},'前後不変':True,'三表形状':[[len(t['rows']),len(t['headers'])]for t in result_tables],
        '集計SHA256':sha(args.output_dir/'集計.json'),'表SHA256':sha(args.output_dir/'CSV用の表.json'),'CSV又はmarker実行':False})
    print(json.dumps({'success':True,'main':goals['all']['U0'],'tables':[[len(t['rows']),len(t['headers'])]for t in result_tables]},ensure_ascii=True))


if __name__=='__main__':
    main()
