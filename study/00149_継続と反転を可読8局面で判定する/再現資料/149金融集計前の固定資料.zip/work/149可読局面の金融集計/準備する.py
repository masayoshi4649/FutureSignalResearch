"""自然観測を開かず149集計器の人工・構文・指紋を固定する。"""
from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import os
import subprocess
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.dont_write_bytecode=True


def sha(path: Path) -> str:
    """
    機能: 対象ファイルを固定bufferで指紋化する。
    引数: path(Path)。返り値: str。
    """
    h=hashlib.sha256()
    with path.open('rb')as source:
        for block in iter(lambda:source.read(1<<20),b''):h.update(block)
    return h.hexdigest()


def main() -> None:
    """
    機能: UTF-8 strict子Pythonの人工だけを実行し停止前の準備票を保存する。
    引数: なし。返り値: None。
    """
    spec=importlib.util.spec_from_file_location('prepare_aggregate149',HERE/'集計する.py')
    aggregate=importlib.util.module_from_spec(spec);spec.loader.exec_module(aggregate)
    own=sorted([*HERE.glob('*.py'),HERE/'条件.md'])
    fixture=ROOT/'work/148母集団の診断集計/人工検査.py'
    sources=list(dict.fromkeys([*own,fixture,*aggregate.SOURCES]))
    before={path:sha(path)for path in sources}
    assert all(before[path]==expected for path,expected in aggregate.SOURCES.items())
    for path in own:
        if path.suffix=='.py':ast.parse(path.read_text(encoding='utf-8'),filename=str(path))
    environment={**os.environ,'PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8','PYTHONDONTWRITEBYTECODE':'1'}
    command=[sys.executable,'-X','utf8',str(HERE/'人工検査.py')]
    process=subprocess.run(command,cwd=ROOT,env=environment,capture_output=True)
    stdout=process.stdout.decode('utf-8',errors='strict');stderr=process.stderr.decode('utf-8',errors='strict')
    assert process.returncode==0 and '\ufffd'not in stdout+stderr
    assert all(sha(path)==value for path,value in before.items())
    proof={'成功':True,'試行':149,'自然金融集計':False,'自然価格又はRaw読取':False,'構文検査':True,
        '人工主検査数':4,'実行':{'引数':command,'終了値':process.returncode,'標準出力':stdout,'標準エラー':stderr},
        '文字コード':{'子Python_X_utf8':True,'PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8','decode':'utf-8 strict','置換文字数':0},
        '源':[{'path':str(path.relative_to(ROOT)).replace('\\','/'),'sha256':value,'bytes':path.stat().st_size}for path,value in before.items()],
        '前後指紋一致':True,'三表契約':{'正逆比較':[900,len(aggregate.COMPARISON_HEADERS)],'入口別診断':[4156,len(aggregate.DETAIL_HEADERS)],'全セッション':[73,len(aggregate.SCENE_HEADERS)]},
        '独立性':'149作者は固定148結合と124作者算術を再用。Rootは別141算術で独立照合する。',
        '未実行':'149固定選択・148自然観測の本CLI集計はRootの指紋固定後にRootが実行する。'}
    target=HERE/'準備の確認.json'
    with target.open('x',encoding='utf-8',newline='\n')as output:json.dump(proof,output,ensure_ascii=False,indent=2,allow_nan=False);output.write('\n')
    print(json.dumps({'成功':True,'準備票SHA256':sha(target),'人工':4,'三表契約':proof['三表契約']},ensure_ascii=False))


if __name__=='__main__':
    main()
