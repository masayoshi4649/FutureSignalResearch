"""自然観測を使わず固定選択・実逆・重複窓と900三表を確認する。"""
from pathlib import Path
import copy
import importlib.util
import unittest

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def load(path: Path,name: str):
    """
    機能: mainを実行せず人工部品を読み込む。
    引数: path(Path)、name(str)。返り値: ModuleType。
    """
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m


module=load(HERE/'集計する.py','agg149test');old_test=load(ROOT/'work/148母集団の診断集計/人工検査.py','fixture148for149')


def fixture() -> tuple:
    """
    機能: 73場/旧87と固定8枝の人工取得票を作る。
    引数: なし。返り値: tuple。
    """
    observed,fixed,meta,ledger,capture=old_test.fixture()
    for descriptor in meta['population148']['cases']:
        descriptor['buy_stream']='original'if descriptor['original_side']==1 else 'reverse'
        descriptor['sell_stream']='reverse'if descriptor['original_side']==1 else 'original'
    base=load(module.BASE,'base148test149');records,members,sessions,phase=base.prepare(observed,fixed,meta,ledger,capture,False)
    legacy=[]
    for key,r in records.items():legacy.append({'case_id':key,'session':r['session'],'side':r['case']['original_side'],'stream':'original','event_id':None,'feature_ref':None,'origin':'C1'})
    selection={'成功':True,'試行':149,'選択時の金融ラベル利用':False,'全73場':sessions,'政策':{'C1':legacy,'U0':copy.deepcopy(legacy)},'旧C1重複':[],'候補と取得':{}}
    for i,branch in enumerate(module.BRANCHES):
        c=copy.deepcopy(legacy[i]);c.update({'origin':branch,'成立ID':[branch],'q0_time':100,'q0_index':1,'q0_line':2,'event_id':'人工'+str(i),'feature_ref':'人工'+str(i)})
        selection['政策'][branch]=[c];selection['候補と取得'][branch]={'候補成立':2,'filled':1,'expired':1}
    selection['政策']['OR8']=[{**copy.deepcopy(legacy[0]),'origin':'OR8','成立ID':['T1'],'q0_time':100,'q0_index':1,'q0_line':2}]
    selection['候補と取得']['OR8']={'候補成立':2,'filled':1,'expired':1}
    return records,members,sessions,fixed,selection,capture,meta


class AggregateTests(unittest.TestCase):
    """149の金融選択を変えずに扱う。"""

    def test_固定方向と900三表(self) -> None:
        """
        機能: 15政策のstream/件数と900比較を固定票どおりにする。
        引数: self(AggregateTests)。返り値: None。
        """
        records,members,sessions,fixed,selection,capture,meta=fixture();bound=module.bind_choices(records,members,selection,False);a=module.arithmetic()
        values,p,f,goals,overlaps=module.calculate(bound,sessions,fixed['scenes'],a);tables=module.tables(bound,sessions,values,p,f,goals,overlaps,selection,capture,meta,a)
        self.assertEqual([len(t['rows'])for t in tables],[900,87,73])
        self.assertEqual([len(t['headers'])for t in tables],[34,47,52])
        self.assertEqual(module.selected(bound['人工00/0'],'U0','BBO')['birth']['side'],-1)
        self.assertEqual(module.selected(bound['人工00/0'],'RU0','BBO')['birth']['side'],1)
        self.assertEqual(values['all']['U0']['BBO']['3600']['125']['forward'],87)
        self.assertEqual(values['all']['RU0']['BBO']['3600']['125']['adverse'],87)

    def test_半開重複と推移連結(self) -> None:
        """
        機能: 名目H60のstrict重複を推移的に連結し等号接触は別群にする。
        引数: self(AggregateTests)。返り値: None。
        """
        rows=[{'session':'場','case':{'id':str(i),'original':{'entry':{'time':t,'index':i}}}}for i,t in enumerate([0,3599,7198,10798])]
        output=module.overlap(rows,['場','ゼロ場'])
        self.assertEqual((output['連結群数'],output['最大群件数'],output['最小場件数']),(2,3,0))
        self.assertEqual(output['場別']['ゼロ場']['件数'],0)

    def test_票の副方向を黙って変更しない(self) -> None:
        """
        機能: 固定sideと保存streamが矛盾した票を拒否する。
        引数: self(AggregateTests)。返り値: None。
        """
        records,members,_,_,selection,_,_=fixture();selection['政策']['T1'][0]['side']*=-1
        with self.assertRaises(AssertionError):module.bind_choices(records,members,selection,False)

    def test_Last金額と未知は保持(self) -> None:
        """
        機能: Lastを金額化せず、H不足でも既知touchを清算へ残す。
        引数: self(AggregateTests)。返り値: None。
        """
        records,members,_,_,selection,_,_=fixture();bound=module.bind_choices(records,members,selection,False);r=bound['人工00/0'];a=module.arithmetic()
        s=a.stats([r],'U0','Last',3600,125);self.assertIsNone(s['ifd_net5_sum'])
        stream=module.selected(r,'U0','BBO');stream['outcomes'][1]['status']='censored';stream['outcomes'][1]['endpoint']=None
        s=a.stats([r],'U0','BBO',3600,125);self.assertEqual((s['complete'],s['ifd_known']),(0,1));self.assertIsNone(s['target70'])
        self.assertEqual(s['ifd_net5_sum'],125*100-77-1000)
        for touch in stream['outcomes'][1]['touches']:touch.update({'direction':0,'quote':None})
        unknown=a.stats([r],'U0','BBO',3600,125)
        self.assertEqual((unknown['ifd_known'],unknown['ifd_unknown']),(0,1));self.assertIsNone(unknown['ifd_net5_sum'])


if __name__=='__main__':
    unittest.main(verbosity=2)
