package midrecover147

import (
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"testing"
)

// independentCall は状態試験でも現在Contextの原行時計を現在Quoteへ一致させます。
//
// 引数: d(*Detector)、c(Context)、q(Quote)、batch([]ShortBar)。返り値: errorです。
func independentCall(d *Detector, c Context, q Quote, batch []ShortBar) error {
	c.At = q
	return d.observe(c, q, batch)
}

// independentFixture は作者fixtureを使わず、手計算できる一方向の2足を作ります。
//
// 引数: なし。返り値: Detector、初知Context、p/r、出生Quoteです。
func independentFixture() (*Detector, Context, ShortBar, ShortBar, Quote) {
	d := NewDetector(Scene{Session: "独立人工", Contract: "独立限月", Start: 0, End: 10000, ForceClose: 9900})
	c := Context{Direction30: 1, BBWindowID: "独立BB", BB15: rules.Bands{Known: true, Count: 20, Mean: 1000, Sigma: 200, Upper: 1400, Lower: 600}, Fields: map[string]rules.Value{}, Refs: []rules.Ref{}}
	for key, value := range map[string]float64{"price_known_300": 1, "price_known_900": 1, "price_known_1800": 1, "gap30": 30, "ema21_delta30": 2, "atr5": 80, "ema8_5": 1100, "ema21_5": 1050, "di_difference15": 8, "adx_delta15": 1, "hist_delta5": 2, "tr5": 100, "previous_atr5": 80} {
		c.Fields[key] = rules.Value{Known: true, Value: value}
	}
	p := ShortBar{ID: "独立p", Session: "独立人工", Contract: "独立限月", Width: 60, Start: 240, End: 300, AvailableAt: 360, Stamp: rules.Stamp{Time: 360, Index: 8, Line: 9}, PriceKnown: true, VolumeKnown: true, Closed: true, Volume: 100, OHLC: rules.OHLC{Open: 1100, High: 1110, Low: 1070, Close: 1080}}
	r := ShortBar{ID: "独立r", Session: p.Session, Contract: p.Contract, Width: 60, Start: 300, End: 360, AvailableAt: 420, Stamp: rules.Stamp{Time: 420, Index: 10, Line: 11}, PriceKnown: true, VolumeKnown: true, Closed: true, Volume: 150, OHLC: rules.OHLC{Open: 1080, High: 1140, Low: 1070, Close: 1130}}
	q := Quote{Clock: "人工", Time: 420, Index: 10, SourceLine: 11, Last: 1140, Bid: 1130, Ask: 1150, QuoteOK: true}
	return d, c, p, r, q
}

// independentObserve は初配送時計のContextを分離して1本だけ配送します。
//
// 引数: t(*testing.T)、d(*Detector)、c(Context)、b(ShortBar)。返り値: ありません。
func independentObserve(t *testing.T, d *Detector, c Context, b ShortBar) {
	t.Helper()
	q := Quote{Clock: "人工", Time: b.Stamp.Time, Index: int64(b.Stamp.Index), SourceLine: int64(b.Stamp.Line), Last: b.OHLC.Close, Bid: b.OHLC.Close - 10, Ask: b.OHLC.Close + 10, QuoteOK: true}
	c.At = q
	if err := independentCall(d, c, q, []ShortBar{b}); err != nil {
		t.Fatal(err)
	}
}

// Test独立初知BB凍結 はr現在の別BBでp初知位置を描き替えないことを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test独立初知BB凍結(t *testing.T) {
	d, c, p, r, q := independentFixture()
	independentObserve(t, d, c, p)
	changed := c
	changed.BBWindowID = "後のBB"
	changed.BB15 = rules.Bands{Known: true, Count: 20, Mean: 1300, Sigma: 5, Upper: 1310, Lower: 1290}
	if err := independentCall(d, changed, q, []ShortBar{r}); err != nil {
		t.Fatal(err)
	}
	if len(d.Events) != 1 {
		t.Fatalf("初知BBを使う出生は1件: %+v", d.Checks)
	}
	e := d.Events[0]
	if e.Structure.BBWindowID != "独立BB" || e.Structure.BBMean != 1000 || e.Structure.BBForward != 1400 || e.Structure.K != 1100 || e.Structure.I != 1060 || e.Structure.Cap != 80 {
		t.Fatalf("凍結構造不一致: %+v", e.Structure)
	}
	q.Time = 421
	q.Index = 11
	q.SourceLine = 12
	if err := independentCall(d, changed, q, nil); err != nil {
		t.Fatal(err)
	}
	if e.Status != "filled" || e.EntryPrice == nil || *e.EntryPrice != 1150 {
		t.Fatalf("実Pは旧BBで適格: %+v", e)
	}
}

// Test独立同Raw補完拒否 はp/rを初めて同時に知った場合の出生を拒否します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test独立同Raw補完拒否(t *testing.T) {
	d, c, p, r, q := independentFixture()
	p.Stamp = r.Stamp
	if err := independentCall(d, c, q, []ShortBar{p, r}); err != nil {
		t.Fatal(err)
	}
	if len(d.Events) != 0 || len(d.Groups) != 0 {
		t.Fatal("同Rawの過去準備を作った")
	}
	x := d.Checks[len(d.Checks)-1].Gates["p_r初配送strict"]
	if !x.Known || x.Value != 0 {
		t.Fatal("配送strictの既知不成立が残らない")
	}
}

// Test独立BB中心と実P境界 はLastとAskに別の位置検査を適用します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test独立BB中心と実P境界(t *testing.T) {
	d, c, p, r, q := independentFixture()
	c.BB15 = rules.Bands{Known: true, Count: 20, Mean: 1145, Sigma: 127.5, Upper: 1400, Lower: 890}
	independentObserve(t, d, c, p)
	if err := independentCall(d, c, q, []ShortBar{r}); err != nil {
		t.Fatal(err)
	}
	if len(d.Events) != 0 {
		t.Fatal("現在Last1140が中心1145より逆側でも出生した")
	}
	d, c, p, r, q = independentFixture()
	c.BB15 = rules.Bands{Known: true, Count: 20, Mean: 1000, Sigma: 135, Upper: 1270, Lower: 730}
	independentObserve(t, d, c, p)
	if err := independentCall(d, c, q, []ShortBar{r}); err != nil {
		t.Fatal(err)
	}
	q.Time = 421
	q.Index = 11
	q.SourceLine = 12
	q.Ask = 1150
	if err := independentCall(d, c, q, nil); err != nil {
		t.Fatal(err)
	}
	if len(d.Events) != 1 || d.Events[0].Status != "entry_position_rejected" {
		t.Fatal("Last1140は適格でもAsk1150はBB余地が120ptしかない")
	}
	q.Time = 422
	q.Index = 12
	q.SourceLine = 13
	q.Ask = 1145
	if err := independentCall(d, c, q, nil); err != nil {
		t.Fatal(err)
	}
	if d.Events[0].Status == "filled" {
		t.Fatal("最初正常実P失格を後の価格で救済した")
	}
}

// Test独立遅延時の最新未知 はTTL内に新たな未知足を知ったpendingを取消します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test独立遅延時の最新未知(t *testing.T) {
	d, c, p, r, q := independentFixture()
	p.Stamp = rules.Stamp{Time: 430, Index: 8, Line: 9}
	independentObserve(t, d, c, p)
	r.Stamp = rules.Stamp{Time: 469, Index: 10, Line: 11}
	q.Time = 469
	if err := independentCall(d, c, q, []ShortBar{r}); err != nil {
		t.Fatal(err)
	}
	if len(d.Events) != 1 || d.Events[0].Expires != 499 {
		t.Fatal("遅延配送でもfresh内の出生を得る前提")
	}
	unknown := ShortBar{ID: "独立未知", Session: p.Session, Contract: p.Contract, Width: 60, Start: 360, End: 420, AvailableAt: 480, Stamp: rules.Stamp{Time: 480, Index: 11, Line: 12}, PriceKnown: false, Closed: false}
	q.Time = 480
	q.Index = 11
	q.SourceLine = 12
	if err := independentCall(d, c, q, []ShortBar{unknown}); err != nil {
		t.Fatal(err)
	}
	if d.Events[0].Status != "short_unknown" {
		t.Fatalf("最新未知で取消しない: %s", d.Events[0].Status)
	}
	if !d.Checks[len(d.Checks)-1].Suppressed {
		t.Fatal("pending終了Rawの新rを消費/抑止していない")
	}
}
