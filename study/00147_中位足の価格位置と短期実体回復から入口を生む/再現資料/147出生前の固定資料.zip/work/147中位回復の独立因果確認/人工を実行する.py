"""作者の編集停止後にSourceを一時複写し、Root独自の因果境界4群を実行する。"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib
import json
import subprocess

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
GEN=ROOT/'work/147中位位置からの実体回復'


def sha(path: Path) -> str:
    """
    機能: ファイルの保存bytesの指紋を返す。
    引数: path(Path)は明示されたファイル。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 準備停止を確認し、私有コピーで独自人工を実行して前後同体を保存する。
    引数: なし。GEN/HEREの明示ファイルだけを使う。
    返り値: None。自然Raw/CSV/Source/金融は開かない。
    """
    ready=GEN/'準備の確認.json'
    assert ready.is_file() and json.loads(ready.read_bytes())['成功']
    paths=sorted([*GEN.glob('*.go'),GEN/'go.mod',ready,GEN/'中位実体回復生成.exe'])
    before={str(p.resolve()):sha(p) for p in paths}
    own=HERE/'実行用';own.mkdir(exist_ok=False)
    for path in GEN.glob('*.go'):
        if not path.name.endswith('_test.go'):(own/path.name).write_bytes(path.read_bytes())
    module=(GEN/'go.mod').read_text(encoding='utf-8').replace('=> ../118複数技法の入口条件','=> ../../118複数技法の入口条件')
    (own/'go.mod').write_text(module,encoding='utf-8',newline='\n')
    (own/'independent_test.go').write_bytes((HERE/'independent_test.go').read_bytes())
    result=subprocess.run(['go','test','-count=1','-run','^Test独立','-v','.'],cwd=own,capture_output=True,text=True,encoding='utf-8')
    output=result.stdout+result.stderr
    (HERE/'人工の実行.txt').write_text(output,encoding='utf-8',newline='\n')
    assert result.returncode==0,output
    assert output.count('--- PASS: Test独立')==4,output
    assert before=={str(p.resolve()):sha(p) for p in paths}
    report={'成功':True,'試行':147,'確認日UTC':datetime.now(timezone.utc).isoformat(),'独立確認者':'Root',
        '人工群':4,'範囲':'Source状態の私有observeへ独立fixtureを配送。Raw/CSVやcache数学の独立再計算ではない。',
        '群':['初知BB凍結','同Raw後補完拒否','Lastと実PのBB位置/余地と救済拒否','遅延配送後の最新未知取消と終了Raw抑止'],
        '作者fixture使用':False,'作者test複写':False,'GEN前後同体':True,'自然入力未読':True,
        'Source源':before,'独自テストSHA256':sha(HERE/'independent_test.go'),
        '実行器SHA256':sha(Path(__file__).resolve()),'実行記録SHA256':sha(HERE/'人工の実行.txt')}
    with (HERE/'準備の確認.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(report,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps({'成功':True,'人工群':4,'準備SHA256':sha(HERE/'準備の確認.json')},ensure_ascii=False))


if __name__=='__main__':main()
