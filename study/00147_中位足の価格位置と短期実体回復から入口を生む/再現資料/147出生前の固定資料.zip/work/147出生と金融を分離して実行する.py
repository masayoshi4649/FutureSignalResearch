"""147の中位価格位置と短期実体回復をF0/F1で段階固定する。"""
from pathlib import Path
from datetime import datetime,timezone
import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys

ROOT=Path(__file__).resolve().parent.parent
OWN=ROOT/'work/147中位実体回復の評価'
GEN=ROOT/'work/147中位位置からの実体回復'
AGG=ROOT/'work/147中位位置の金融集計'
FORMAL=ROOT/'study/00147_中位足の価格位置と短期実体回復から入口を生む'
SPECIFICATION=ROOT/'work/147_中位足の価格位置と短期実体回復の採用仕様.md'
INPUT=GEN/'入力参照.json'
BACKGROUND=ROOT/'work/122全場入力/入力.json'
MANIFEST=ROOT/'work/141VWMA独立入口の評価/CSV73参照.json'
BACKGROUND_SHA='6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec'
MANIFEST_SHA='07e136e2b77a0029ddacd955abad16a9240373fa849ec96b553c2875e1e85147'
SOURCE=OWN/'中位実体回復の出生と取得.json'
BRIDGE=ROOT/'work/147中位回復と旧87を固定取得へ渡す.py'
FIXED=OWN/'固定入力/固定取得入力.json'
META=OWN/'固定入力/入口参照.json'
OBSERVED=OWN/'固定取得の正逆観測.json'
KERNEL=ROOT/'work/133固定取得の正逆評価器/固定取得の正逆評価.exe'


def sha(path: Path) -> str:
    """
    機能: 保存bytesの指紋を求める。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def module(path: Path,name: str) -> object:
    """
    機能: mainを呼ばず依存宣言を私有読込する。
    引数: path(Path)、name(str)はコードと内部名。
    返り値: objectはモジュール。
    """
    before=list(sys.path)
    try:
        sys.path.insert(0,str(path.parent));s=importlib.util.spec_from_file_location(name,path)
        m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
    finally:sys.path[:]=before


# ----------------------------------------
def main() -> None:
    """
    機能: 参照/コードF0→全73生成→物理固定→算術F1→実正逆→300比較を分離する。
    引数: CLI --mode(str)は固定/出生/転送/金融前/観測/集計。
    返り値: None。既存成果を上書きせず、CSV/大入力を複写しない。
    """
    p=argparse.ArgumentParser(description='147の出生と金融を段階分離')
    p.add_argument('--mode',choices=('固定','出生','転送','金融前','観測','集計'),required=True)
    args=p.parse_args();helper=module(ROOT/'work/133金融前を固定して実行する.py','147固定補助')
    OWN.mkdir(parents=True,exist_ok=True);f0=OWN/'F0出生前.json';f1=OWN/'F1金融前.json'
    if args.mode=='固定':
        assert sha(BACKGROUND)==BACKGROUND_SHA and sha(MANIFEST)==MANIFEST_SHA
        assert sha(KERNEL)=='033cf22a052e985bc61aa020a04fa6d499119051aaa39bb2adb715a4af1e7736'
        source_ready=json.loads((GEN/'準備の確認.json').read_bytes())
        assert source_ready['成功'] and source_ready['採用仕様SHA256']==sha(SPECIFICATION)
        independent_dir=ROOT/'work/147中位回復の独立因果確認'
        independent=json.loads((independent_dir/'準備の確認.json').read_bytes())
        assert independent['成功'] and independent['人工群']==4
        for name,h in independent['Source源'].items():assert sha(Path(name))==h
        bridge=module(BRIDGE,'147転送宣言')
        files={Path(__file__).resolve(),INPUT,BACKGROUND,MANIFEST,KERNEL,BRIDGE,SPECIFICATION,
            ROOT/'work/147転送の人工検査.py',ROOT/'work/133金融前を固定して実行する.py',
            ROOT/'work/147金融を別算術で確認する.py',ROOT/'work/141金融集計を独立に確認する.py'}
        files.update(independent_dir/name for name in ('independent_test.go','人工を実行する.py','準備の確認.json','人工の実行.txt','README.md'))
        for path,h in bridge.SHAS.items():assert sha(path)==h;files.add(path)
        for folder in (GEN,FORMAL,AGG,ROOT/'work/118複数技法の入口条件'):
            assert folder.is_dir()
            files.update(q for q in folder.rglob('*') if q.is_file() and q.suffix in ('.go','.mod','.py','.md','.json','.exe'))
        for name in ('README.md','条件.md','設定と結果.md'):assert (FORMAL/name).is_file()
        helper.save(f0,{'成功':True,'試行':147,'段階':'中位位置と実体回復の自然出生前F0','UTC':datetime.now(timezone.utc).isoformat(),
            '主':'U0=旧145全87(C1)＋新物理group(T0)、同原行C1優先',
            '政策':['C0','C1','T0','U0','RU'],'追加2場未読':True,
            'Raw優先採用':False,'CSV参照全件は固定manifestに保存':True,'場の実効並列数':1,
            'ファイル':{str(q):sha(q) for q in sorted(files)}})
        print(json.dumps({'F0_SHA256':sha(f0),'固定源数':len(files),'入力SHA256':sha(INPUT)},ensure_ascii=False));return
    frozen=json.loads(f0.read_bytes());helper.verify(frozen)
    if args.mode=='出生':
        assert not SOURCE.exists()
        command=[str(GEN/'中位実体回復生成.exe'),'--input',str(INPUT),'--sha256',sha(INPUT),
            '--output',str(SOURCE),'--workers','1','--execute-after-f0']
    elif args.mode=='転送':
        command=[sys.executable,'-X','utf8',str(BRIDGE),'--f0',str(f0),'--f0-sha256',sha(f0),
            '--source',str(SOURCE),'--sha256',sha(SOURCE),'--output-dir',str(FIXED.parent)]
    elif args.mode=='金融前':
        declared=module(AGG/'集計する.py','147金融依存宣言')
        files={Path(q) for q in frozen['ファイル']}|{f0,SOURCE,FIXED,META,FIXED.parent/'転送の確認.json',
            ROOT/'work/147金融を別算術で確認する.py',ROOT/'work/141金融集計を独立に確認する.py'}
        for path,h in declared.SOURCES.items():assert sha(path)==h;files.add(path)
        files.update(q for q in AGG.rglob('*') if q.is_file() and q.suffix in ('.py','.md','.json'))
        helper.save(f1,{'成功':True,'試行':147,'段階':'全物理取得と所属を固定後F1','UTC':datetime.now(timezone.utc).isoformat(),
            'F0_SHA256':sha(f0),'主政策':'U0','主価格':'実BBO','主秒':3600,'主幅':125,
            '金融後主交換':False,'ファイル':{str(q):sha(q) for q in sorted(files)}})
        print(json.dumps({'F1_SHA256':sha(f1),'固定源数':len(files)},ensure_ascii=False));return
    else:
        finance=json.loads(f1.read_bytes());helper.verify(finance)
        if args.mode=='観測':
            assert not OBSERVED.exists()
            command=[str(KERNEL),'--input',str(FIXED),'--sha256',sha(FIXED),'--output',str(OBSERVED),'--workers','8']
        else:
            command=[sys.executable,'-X','utf8',str(AGG/'集計する.py'),'--f1',str(f1),'--f1-sha256',sha(f1),
                '--fixed-input',str(FIXED),'--fixed-input-sha256',sha(FIXED),'--metadata',str(META),'--metadata-sha256',sha(META),
                '--result',str(OBSERVED),'--result-sha256',sha(OBSERVED),'--output-dir',str(OWN/'金融評価')]
    subprocess.run(command,cwd=ROOT,check=True);helper.verify(frozen)
    if args.mode in ('観測','集計'):helper.verify(finance)
    if args.mode=='観測':helper.verify_result(json.loads(OBSERVED.read_bytes()),json.loads(FIXED.read_bytes()))
    helper.save(OWN/(args.mode+'の完了.json'),{'成功':True,'試行':147,'段階':args.mode,
        'F0_SHA256':sha(f0),'全固定源前後同体':True,'実行列':command})


if __name__=='__main__':main()
