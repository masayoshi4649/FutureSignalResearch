"""147の中位位置1分入口を、自然ファイルを使わず人工fixtureだけで検査する。"""
from pathlib import Path
import copy
import importlib.util
import json

HERE=Path(__file__).resolve().parent
S=importlib.util.spec_from_file_location('147人工対象',HERE/'集計する.py')
M=importlib.util.module_from_spec(S);S.loader.exec_module(M)


def fixture(new: bool=True) -> tuple:
    """
    機能: 73場・旧3件・新4物理取得・旧6由来へのaliasを人工で作る。
    引数: new(bool)は新T0を含めるか。
    返り値: tuple[dict,dict,dict]は133観測/固定入力/147metadata。
    """
    fixed={'expected_entry_count':0,'scenes':[]};result={'success':True,'trial':133,'source_entry_count':0,'scenes':[]}
    meta={'success':True,'trial':147,'sessions':[],'entries':[],'union':[]}
    for i in range(73):
        sid=f'人工{i:02d}';start=1_000_000+i*100_000;meta['sessions'].append(sid)
        f={'session':sid,'contract':'人工限月','start':start,'end':start+7500,'force_close':start+7400,'raw':{'sha256':'a'*64},'expected_quality':{'人工':True},'entries':[]}
        r={'session':sid,'success':True,'actual_sha256':'a'*64,'quality':{'人工':True},'expected_quality':{'人工':True},
            'stat_before':{'bytes':0},'stat_after':{'bytes':0},'execution_end':start+7200,'effective_entry_limit':start+3600,'source_force_close':start+7400,'cases':[]}
        plans=[]
        if i==0:plans.append(('C1','C0/旧1',1,'C0',[]))
        if i==2:plans.append(('C1','A0/旧A',-1,'A0',[]))
        if i==3:plans.append(('C1','B0/旧B',1,'B0',[]))
        if new:
            if i==0:plans.append(('T0','T0/旧と反対',-1,None,[60]))
            if i==1:plans.append(('T0','T0/新1',1,None,[60]))
            if i==2:plans.append(('T0','T0/旧Aと反対',1,None,[60]))
            if i==4:plans.append(('T0','T0/新2',1,None,[60]))
        for model,eid,side,legacy,widths in plans:
            q={'clock':'人工価格時計','time':start+100,'index':10,'source_line':100,'last':1000,'bid':995,'ask':1005,'quote_ok':True}
            f['entries'].append({'id':eid,'side':side,'entry':q});case={'id':eid,'original_side':side}
            for key in ('original','reverse','chart_original','chart_reverse'):
                chart=key.startswith('chart');s=side if key.endswith('original') else -side
                stream={'status':'filled','entry':q,'birth':{'side':s},'entry_price':q['last'] if chart else q['ask'] if s>0 else q['bid'],'outcomes':[]}
                for h in M.HORIZONS:
                    endpoint={**q,'time':q['time']+h,'index':100+h,'source_line':1000+h}
                    stream['outcomes'].append({'seconds':h,'deadline':q['time']+h,'status':'complete','endpoint':endpoint,
                        'touches':[{'width':w,'direction':0,'quote':None} for w in M.WIDTHS],'net0':None,'net5':None})
                case[key]=stream
            r['cases'].append(case)
            origins=[{'id':eid+'/候補'+str(w),'width':w,'family':'T','side':side} for w in widths] if model=='T0' else [{'family':legacy}]
            meta['entries'].append({'id':eid,'session':sid,'contract':f['contract'],'model':model,'legacy_model':legacy,'candidate_id':eid.split('/',1)[1],
                'native_side':side,'entry_quote':q,'baseline':legacy=='C0','origins':origins,'widths':widths})
        if plans:
            meta['union'].append({'canonical_id':f['entries'][0]['id'],'alias_ids':[x['id'] for x in f['entries']],
                'alias_sides':{x['id']:x['side'] for x in f['entries']},'session':sid,'contract':f['contract'],
                'entry_stamp':{k:f['entries'][0]['entry'][k] for k in ('time','index','source_line')}})
        fixed['scenes'].append(f);result['scenes'].append(r)
    n=len(meta['entries']);fixed['expected_entry_count']=result['source_entry_count']=n
    return result,fixed,meta


# ----------------------------------------
def rejected(action: object) -> None:
    """
    機能: 不正人工入力が停止することを確かめる。
    引数: action(callable)。
    返り値: None。
    """
    try:action()
    except (AssertionError,KeyError):return
    raise AssertionError('不正fixtureを受け入れました')


# ----------------------------------------
def controls(template: dict) -> tuple:
    """
    機能: 全87旧C1と旧81subsetの同体検査用に独立した人工旧票を作る。
    引数: template(dict)は人工case。
    返り値: tupleはC1行/旧fixed/旧meta/旧pairs/現在値/旧145値/旧138値。
    """
    basis=[];fixed={'scenes':[]};meta={'entries':[]};pairs={'scenes':[]}
    for i in range(87):
        legacy='C0' if i<81 else 'A0' if i<83 else 'B0';sid=f'旧対照人工{i}';c=copy.deepcopy(template);c['id']=f'{legacy}/人工{i}';q=c['original']['entry']
        m={'id':c['id'],'session':sid,'contract':'人工限月','model':legacy,'candidate_id':f'人工{i}',
            'native_side':c['original_side'],'entry_quote':q,'baseline':legacy=='C0','origins':[{'family':legacy}]}
        basis.append({'session':sid,'model':'C1','case':c,'meta':{**copy.deepcopy(m),'model':'C1','legacy_model':legacy}})
        fixed['scenes'].append({'session':sid,'entries':[{'id':c['id'],'side':c['original_side'],'entry':copy.deepcopy(q)}]})
        meta['entries'].append(copy.deepcopy(m));pairs['scenes'].append({'session':sid,'cases':[copy.deepcopy(c)]})
    values={part:{p:{a:{str(h):{str(w):{'flips':0,'人工件数':81 if p=='C0' else 87} for w in M.WIDTHS} for h in M.HORIZONS} for a in M.AXES} for p in ('C0','C1')} for part in ('all','train','validation')}
    old145={'集計':{part:{'U0':copy.deepcopy(v['C1'])} for part,v in values.items()}}
    old138={'集計':{part:{'C0':copy.deepcopy(v['C0'])} for part,v in values.items()}}
    return basis,fixed,meta,pairs,values,old145,old138


# ----------------------------------------
def main() -> None:
    """
    機能: 5政策/物理数/全旧87保護/実逆/費用/null/対照拒否を人工だけで確認する。
    引数: なし。
    返り値: None。自然金融/Raw/価格CSV/追加2場は開かない。
    """
    arithmetic=M.load_arithmetic();tests=[]
    for include in (False,True):
        result,fixed,meta=fixture(include);basis,rows,sessions,phase,union=M.prepare(result,fixed,meta,False)
        values,part,freq,goal=M.calculate(rows,sessions,fixed['scenes'],arithmetic)
        tables=M.tables(basis,rows,sessions,values,part,freq,arithmetic)
        assert [(len(t['rows']),len(t['headers'])) for t in tables]==[(300,34),(len(basis),48),(73,81)]
        assert freq['all']['U0']['全時間h']==2*len(sessions) and part['all']['C0']['未取得場数']==72
        assert union['C0']==1 and union['C1']==3
        if not include:
            assert union['T0']==0 and union['U0']==3
            for name in ('T0',):
                assert part['all'][name]['未取得場数']==73 and values['all'][name]['BBO']['3600']['125']['resolved_rate'] is None
                assert values['all'][name]['BBO']['3600']['125']['ifd_net5_sum'] is None
            assert values['all']['C1']['BBO']['3600']['125']==values['all']['U0']['BBO']['3600']['125']
            tests.append('新0件でも全73/null/主U0は旧C1全件')
        else:
            assert union['T0']==4 and union['U0']==5
            assert union['同原行aliasで除いた取得数']==2 and union['代表と反対方向のalias数']==2
            detail={row[4]:dict(zip(tables[1]['headers'],row)) for row in tables[1]['rows']}
            assert detail['T0/新2']['T0方向']==detail['T0/新2']['U0方向']==1
            assert detail['T0/新1']['C1方向'] is None
            assert detail['A0/旧A']['C0方向'] is None and detail['A0/旧A']['C1方向']==detail['A0/旧A']['U0方向']==-1
            assert detail['T0/旧Aと反対']['T0方向']==1 and detail['T0/旧Aと反対']['U0方向'] is None
            assert detail['C0/旧1']['RU方向']==-1 and detail['A0/旧A']['RU方向']==1
            tests.append('T0物理数/旧6も優先/反対aliasを保持し全RU実逆')
        s=values['all']['C0']['BBO']['3600']['125'];assert s['ifd_known']==1 and s['ifd_net0_sum']==-1077 and s['ifd_net5_sum']==-2077
        assert values['all']['C0']['Last']['3600']['125']['ifd_net5_sum'] is None
    tests.append('元124費用77/1077円とLast金額null')
    # ----------------------------------------
    result,fixed,meta=fixture(True)
    for operation in ('優先','alias欠落','alias方向','alias型','旧baseline','幅未知','幅bool','幅重複','origin方向','origin再利用'):
        bad=copy.deepcopy(meta)
        if operation=='優先':bad['union'][0]['canonical_id']='T0/旧と反対'
        if operation=='alias欠落':bad['union'][0]['alias_ids']=['C0/旧1']
        if operation=='alias方向':bad['union'][0]['alias_sides']['T0/旧と反対']=1
        if operation=='alias型':bad['union'][0]['alias_sides']['C0/旧1']=True
        if operation=='旧baseline':bad['entries'][0]['baseline']=False
        if operation=='幅未知':bad['entries'][1]['origins'][0]['width']=300
        if operation=='幅bool':bad['entries'][1]['origins'][0]['width']=True
        if operation=='幅重複':bad['entries'][1]['widths']=[60,180]
        if operation=='origin方向':bad['entries'][1]['origins'][0]['side']=1
        if operation=='origin再利用':bad['entries'][1]['origins'].append(copy.deepcopy(bad['entries'][1]['origins'][0]))
        rejected(lambda:M.prepare(result,fixed,bad,False));tests.append(operation+'を拒否')
    for opposite in (False,True):
        rr,ff,mm=copy.deepcopy((result,fixed,meta));at=0 if opposite else 1
        c=copy.deepcopy(rr['scenes'][0]['cases'][at]);c['id']='T0/矛盾group'
        e=copy.deepcopy(ff['scenes'][0]['entries'][at]);e['id']=c['id'];m=copy.deepcopy(mm['entries'][1])
        m.update({'id':c['id'],'candidate_id':'矛盾group','native_side':e['side'],'entry_quote':e['entry'],'origins':[{'id':'新origin','width':60,'side':e['side']}],'widths':[60]})
        rr['scenes'][0]['cases'].append(c);ff['scenes'][0]['entries'].append(e);mm['entries'].append(m);ff['expected_entry_count']+=1;rr['source_entry_count']+=1
        rejected(lambda:M.prepare(rr,ff,mm,False))
    tests.append('同原行の新複数物理groupは同方向/反対方向とも拒否')
    rr=copy.deepcopy(result);rr['scenes'][0]['cases'][0]['original']['outcomes'][0]['endpoint']['time']=fixed['scenes'][0]['end']-300
    rejected(lambda:M.prepare(rr,fixed,meta,False));tests.append('ザラバ終端endpointを拒否')
    # ----------------------------------------
    basis,oldfixed,oldmeta,oldpairs,values,old145,old138=controls(result['scenes'][0]['cases'][0])
    proof=M.legacy_check(basis,values,oldfixed,oldmeta,old145,oldpairs)
    assert proof['旧145全C1']==87 and proof['4stream全H幅']==3480 and proof['旧60条件同体']==60
    priorpairs={'scenes':[s for s in oldpairs['scenes'] if s['cases'][0]['id'].startswith('C0/')]}
    proof=M.baseline_check(basis,values,old138,priorpairs);assert proof['旧138C0全81']==81
    tests.append('旧138全81と旧145全87の4stream/各60条件を同体検査')
    for operation in ('旧6削除','旧逆値','旧origin差','旧方向差','旧6モデル差','旧87成績差'):
        b,f,m,p,v,s=copy.deepcopy((basis,oldfixed,oldmeta,oldpairs,values,old145))
        if operation=='旧6削除':b.pop()
        if operation=='旧逆値':b[-1]['case']['reverse']['entry_price']+=5
        if operation=='旧origin差':b[-1]['meta']['origins'].append({'family':'追加'})
        if operation=='旧方向差':b[-1]['meta']['native_side']=-1
        if operation=='旧6モデル差':b[-1]['meta']['legacy_model']='A0'
        if operation=='旧87成績差':s['集計']['all']['U0']['BBO']['3600']['125']['人工件数']=86
        rejected(lambda:M.legacy_check(b,v,f,m,s,p));tests.append(operation+'を拒否')
    # ----------------------------------------
    out={'status':'complete','endpoint':{'time':2,'last':1050,'bid':1000,'ask':1100},'touches':[{'width':125,'direction':-1,'quote':{'time':2,'last':1050,'bid':1000,'ask':1100}}]}
    buy={'birth':{'side':1},'entry_price':1200};sell={'birth':{'side':-1},'entry_price':900}
    assert arithmetic.ifd(buy,out,125,'BBO')['net5']==arithmetic.ifd(sell,out,125,'BBO')['net5']==-21077
    unknown={**out,'status':'gap_censored','endpoint':None,'touches':[{'width':125,'direction':0,'quote':None}]}
    assert not arithmetic.ifd(buy,unknown,125,'BBO')['known'] and arithmetic.ifd(buy,{**unknown,'touches':out['touches']},125,'BBO')['known']
    tests.append('両側損失は実BBOで確認/不足の既知touchと金額未知を分離')
    print(json.dumps({'成功':True,'人工群':len(tests),'人工':tests,'自然入力読取':False,'三表列数':[34,48,81]},ensure_ascii=False))


if __name__=='__main__':main()
