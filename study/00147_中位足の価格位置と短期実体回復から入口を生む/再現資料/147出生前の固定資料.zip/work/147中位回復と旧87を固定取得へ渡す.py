"""147の中位位置1分候補を検査し、旧87を保護して固定133形式へ転送する。"""
from pathlib import Path
import argparse
import copy
import hashlib
import json
import math

ROOT=Path(__file__).resolve().parent.parent
OLD_FIXED=ROOT/'work/145構造イベントの評価/固定入力/固定取得入力.json'
OLD_META=ROOT/'work/145構造イベントの評価/固定入力/入口参照.json'
BACKGROUND=ROOT/'work/122全場入力/入力.json'
SHAS={OLD_FIXED:'d2becb3b1d6de656a6cc3f04d576d95d99693dfc42efc03582ed04d2be8784e8',
      OLD_META:'3a3a144c478fa45f85e03ad4b8e4461e420592da24088458c7aa1cb748c8eb8d',
      BACKGROUND:'6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec'}
QUOTE_FIELDS=('time','index','source_line','last','bid','ask','quote_ok','clock')


def sha(path: Path) -> str:
    """
    機能: 保存bytesの指紋を返す。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def save(path: Path,value: dict) -> None:
    """
    機能: UTF-8 JSONを未作成先へ保存する。
    引数: path(Path)、value(dict)は保存先と値。
    返り値: None。
    """
    with path.open('x',encoding='utf-8',newline='\n') as f:
        json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')


# ----------------------------------------
def stamp_key(sid: str,contract: str,q: dict) -> tuple:
    """
    機能: 売買方向を加えず物理取得原行を識別する。
    引数: sid/contract(str)、q(dict)は場と取得Quote。
    返り値: tupleは場/限月/time/index/line。
    """
    return sid,contract,q['time'],q['index'],q['source_line']


# ----------------------------------------
def ref_key(ref: dict) -> tuple:
    """
    機能: IDだけで同場と誤結合せず、公表の全時計を参照キーにする。
    引数: ref(dict)は118参照。
    返り値: tupleはID/尺度/End/配送time/index/line。
    """
    d=ref['delivered'];return ref['id'],ref['width_seconds'],ref['end'],d['time'],d['index'],d['source_line']


# ----------------------------------------
def pub_ref(p: dict) -> dict:
    """
    機能: 背景公表を価格や指標を複製しない参照に射影する。
    引数: p(dict)は固定122公表。
    返り値: dictは118参照。
    """
    f=p['frame']['frame'];return {'id':f['id'],'width_seconds':f['width_seconds'],'end':f['end'],'delivered':copy.deepcopy(p['stamp'])}


# ----------------------------------------
def bands(window: list[dict]) -> dict:
    """
    機能: 20観測の終値と母分散からBBを独立算出し、未知を既知0へ補わない。
    引数: window(list[dict])は順序付き15分公表。
    返り値: dictはknown/count/mean/sigma/upper/lower。
    """
    result={'known':False,'count':len(window),'mean':0.,'sigma':0.,'upper':0.,'lower':0.}
    if len(window)!=20 or not all(p['frame']['frame']['price_known'] for p in window):return result
    closes=[p['frame']['frame']['ohlc']['close'] for p in window]
    assert all(type(v) in (int,float) and math.isfinite(v) and v>0 for v in closes)
    mean=math.fsum(closes)/20;sigma=math.sqrt(math.fsum((x-mean)**2 for x in closes)/20)
    return {'known':True,'count':20,'mean':mean,'sigma':sigma,'upper':mean+2*sigma,'lower':mean-2*sigma}


# ----------------------------------------
def same_bands(actual: dict,wanted: dict) -> None:
    """
    機能: BB既知性・観測数を厳密に、値を浮動誤差の範囲で比較する。
    引数: actual/wanted(dict)。
    返り値: None。未知を既知0と扱う改変も拒否する。
    """
    assert type(actual['known']) is bool and actual['known'] is wanted['known'] and type(actual['count']) is int and actual['count']==wanted['count']
    for name in ('mean','sigma','upper','lower'):
        assert type(actual[name]) in (int,float) and math.isfinite(actual[name])
        assert math.isclose(actual[name],wanted[name],rel_tol=1e-12,abs_tol=1e-8),(name,actual[name],wanted[name])


# ----------------------------------------
def background_index(background: dict) -> tuple[dict,dict,dict]:
    """
    機能: 固定122全公表から118のBB窓規約を別構成し、全refsを検索可能にする。
    引数: background(dict)は純入力。ファイルを開かず同限月carry/同場欠分resetを扱う。
    返り値: tupleは場/ID別BB窓、全時計別公表、場別重複除外公表。
    """
    assert background['trial']==122
    windows={};lookup={};ordered={};contract=None;window=[];last=None;seen={};session_ids=set()
    for scene in background['scenes']:
        sid=scene['session'];assert sid not in session_ids;session_ids.add(sid)
        if contract!=scene['contract']:window=[];last=None;seen={};contract=scene['contract']
        ordered[sid]=[]
        for p in scene['publications']:
            f=p['frame']['frame'];width=f['width_seconds'];assert f['session_id']==sid and f['contract']==contract and width in (300,900,1800)
            ref=pub_ref(p);key=ref_key(ref);assert key not in lookup or lookup[key]==p;lookup[key]=p
            identity=(sid,width,f['id'])
            if identity in seen:assert seen[identity]==p;continue
            seen[identity]=p;ordered[sid].append(p)
            if width!=900:continue
            if last is not None:
                previous=last['frame']['frame'];assert f['end']>previous['end'] and p['stamp']['time']>=last['stamp']['time']
                if sid==previous['session_id']:
                    assert p['stamp']['index']>=last['stamp']['index'] and p['stamp']['source_line']>=last['stamp']['source_line']
                    if f['end']-previous['end']!=900:window=[]
            window=(window+[p])[-20:];last=p
            windows[sid,f['id']]={'id':f['id'],'bands':bands(window),'refs':[pub_ref(x) for x in window]}
    return windows,lookup,ordered


# ----------------------------------------
def validate_windows(scene: dict,expected: dict) -> dict:
    """
    機能: 当場全900秒窓のID/順序付き元refs/独立BB値を照合する。
    引数: scene(dict)は保存Source場、expected(dict)は固定122からの独立窓。
    返り値: dictは当場窓ID索引。候補0でも全窓を検査する。
    """
    sid=scene['session'];table={}
    for w in scene['bb_windows']:
        assert w['id'] not in table;want=expected[sid,w['id']]
        assert w['refs']==want['refs'];same_bands(w['bands'],want['bands']);table[w['id']]=w
    assert set(table)=={wid for s,wid in expected if s==sid}
    return table


# ----------------------------------------
def value(item: dict) -> float|None:
    """
    機能: known付き値を未知のまま読み、既知有限値だけ返す。
    引数: item(dict)はValue。
    返り値: float|None。
    """
    assert type(item['known']) is bool
    if not item['known']:return None
    assert type(item['value']) in (int,float) and math.isfinite(item['value']);return item['value']


# ----------------------------------------
def asof(publications: list[dict],at: dict) -> dict:
    """
    機能: 当時までに配送された各尺度の最新公表だけを選ぶ。
    引数: publications(list[dict])は当場公表、at(dict)は実Raw。
    返り値: dictは300/900/1800別の最新公表。未来/古い既知足への置換を行わない。
    """
    result={}
    for p in publications:
        f=p['frame']['frame'];stamp=p['stamp']
        if stamp['time']<=at['time'] and stamp['index']<=at['index'] and stamp['source_line']<=at['source_line']:
            assert f['end']<=f['available_at']<=f['delivery_at']<=stamp['time']
            result[f['width_seconds']]=p
    return result


# ----------------------------------------
def current_values(publications: list[dict],at: dict,side: int,ctx: dict|None=None,complete: bool=True,references: list|None=None) -> dict:
    """
    機能: 当時背景から方向/実前5分・15分/急変ガードを独立検査する。
    引数: publications(list[dict])、at(dict)、side(int)、ctx(dict|None)、complete(bool)、references(list|None)は必要両端参照の収集先。
    返り値: dictは選ばれた3公表。pはATR/EMA/方向の準備だけを検査する。
    """
    selected=asof(publications,at);assert set(selected)=={300,900,1800}
    for width,p in selected.items():
        f=p['frame']['frame'];assert f['price_known'] and at['time']<f['end']+width+60
    t5=selected[300]['frame']['frame']['technical'];t30=selected[1800]['frame']['frame']['technical']
    gap,delta=value(t30['gap']),value(t30['ema21_delta'])
    assert gap is not None and delta is not None and side*gap>0 and side*delta>0
    required={'gap30':t30['gap'],'ema21_delta30':t30['ema21_delta'],'atr5':t5['atr'],'ema8_5':t5['ema8'],'ema21_5':t5['ema21']}
    if complete:
        priors={}
        for width in (300,900):
            now=selected[width]['frame']['frame']
            matches=[p for p in publications if p['frame']['frame']['width_seconds']==width and p['frame']['frame']['end']==now['end']-width]
            assert len(matches)==1;prior=matches[0];stamp=prior['stamp'];frame=prior['frame']['frame'];now_stamp=selected[width]['stamp']
            assert frame['end']<=frame['available_at']<=frame['delivery_at']<=stamp['time']
            assert all(stamp[k]<=at[k] and stamp[k]<=now_stamp[k] for k in ('time','index','source_line'))
            priors[width]=prior
        prior5=priors[300]['frame']['frame']['technical'];now15=selected[900]['frame']['dmi'];prior15=priors[900]['frame']['dmi']
        h=value(t5['histogram']);ph=value(prior5['histogram']);adx=value(now15['adx']);padx=value(prior15['adx'])
        assert h is not None and ph is not None and side*(h-ph)>0 and value(t5['previous_histogram'])==ph
        assert adx is not None and padx is not None and adx-padx>=0 and value(now15['previous_adx'])==padx
        plus,minus=value(now15['plus_di']),value(now15['minus_di']);assert plus is not None and minus is not None and side*(plus-minus)>0
        tr,atr=value(t5['tr']),value(prior5['atr']);assert tr is not None and atr is not None and 0<=tr<=2*atr and atr>0
        required.update({'hist_delta5':{'known':True,'value':h-ph},'adx_delta15':{'known':True,'value':adx-padx},
            'di_difference15':{'known':True,'value':plus-minus},'tr5':t5['tr'],'previous_atr5':prior5['atr']})
        if ctx is not None:assert {ref_key(pub_ref(p)) for p in priors.values()}<={ref_key(r) for r in (ctx['refs'] or [])}
        if references is not None:references.extend(pub_ref(p) for p in priors.values())
    if ctx is not None:
        refs={ref_key(r) for r in (ctx['refs'] or [])};assert {ref_key(pub_ref(p)) for p in selected.values()}<=refs
        assert all(ctx['fields'][f'price_known_{width}']=={'known':True,'value':1} for width in (300,900,1800))
        for name,want in required.items():assert ctx['fields'][name]==want
    if references is not None:references.extend(pub_ref(p) for p in selected.values())
    return selected


# ----------------------------------------
def validate_event(e: dict,group: dict,bars: dict,scene: dict,bb: dict,publications: dict,ordered: list[dict]) -> None:
    """
    機能: p/r実体/量・p初BBと構造・出生Last/取得Last/実Pを独立再検査する。
    引数: e/group/bars/scene/bb/publications(dict)、ordered(list[dict])はSource票と固定背景索引。
    返り値: None。Source判定結果や将来成績を正解にせず不一致を拒否する。
    """
    required={'id','family','width_seconds','side','status','birth','entryQuote','entry_price','expires',
              'group_id','structure','arm','confirm','refs'}
    assert required<=e.keys() and e['status']=='filled' and e['group_id']==group['id']
    assert e['family']=='T0' and type(e['side']) is int and e['side'] in (-1,1)
    assert e['width_seconds']==60 and e['side']==group['side']
    b,q=e['birth'],e['entryQuote'];side=e['side'];v=e['structure']
    assert all(q[k]==group['entryQuote'][k] for k in QUOTE_FIELDS) and all(b[k]==group['birth'][k] for k in QUOTE_FIELDS)
    assert q['clock'] and b['clock'] and q['quote_ok'] and 0<q['bid']<q['ask']
    limit=min(scene['force_close'],scene['end']-3900)
    assert scene['start']<=b['time']<e['expires']==min(b['time']+30,limit)
    assert b['time']+1<=q['time']<e['expires'] and q['index']>b['index'] and q['source_line']>b['source_line']
    assert v['cap_atr_width_seconds']==300 and all(type(v[k]) in (int,float) and math.isfinite(v[k]) for k in ('k','i','width','cap','arm_atr','bb_mean','bb_forward'))
    assert 0<v['width']<=125 and v['arm_atr']>0 and v['cap']>=0
    assert math.isclose(v['width'],side*(v['k']-v['i']),rel_tol=0,abs_tol=1e-9)
    chosen=[]
    for ref in (e['arm'],e['confirm']):
        record=bars[ref['id']];bar=record['bar'];ctx=record['context']
        assert ref['width_seconds']==bar['width_seconds']==60 and ref['end']==bar['end'] and ref['delivered']==bar['stamp']
        assert bar['session']==scene['session'] and bar['contract']==scene['contract']
        assert bar['price_known'] and bar['closed'] and not bar.get('missing',False) and bar['end']==bar['start']+60 and bar['available_at']==bar['end']+60
        assert all(bar['stamp'][k]==ctx['at'][k] for k in ('time','index','source_line')) and bar['stamp']['time']>=bar['available_at']
        assert all(bar['stamp'][k]<=b[k] for k in ('time','index','source_line'))
        chosen.append(record)
    p,r=[record['bar'] for record in chosen];pc,rc=[record['context'] for record in chosen]
    assert p['end']==r['start'] and p['stamp']['time']<r['stamp']['time'] and p['stamp']['index']<r['stamp']['index']
    assert r['stamp']=={k:b[k] for k in ('time','index','source_line')} and b['time']<r['end']+120
    assert all(rc['at'][k]==b[k] for k in QUOTE_FIELDS)
    op,orr=p['ohlc'],r['ohlc']
    assert side*(op['close']-op['open'])<0 and side*(orr['close']-orr['open'])>0 and side*(orr['close']-op['open'])>=0
    assert p['volume_known'] and r['volume_known'] and 0<p['volume']<=r['volume']
    expected_k=op['open'];expected_i=min(op['low'],orr['low'])-10 if side==1 else max(op['high'],orr['high'])+10
    assert v['k']==expected_k and v['i']==expected_i
    prep=current_values(ordered,pc['at'],side,pc,False);current_values(ordered,b,side,rc,True)
    atr=value(prep[300]['frame']['frame']['technical']['atr']);ema8=value(prep[300]['frame']['frame']['technical']['ema8']);ema21=value(prep[300]['frame']['frame']['technical']['ema21'])
    assert atr is not None and atr>0 and atr==v['arm_atr'] and ema8 is not None and ema21 is not None
    assert op['high']>=min(ema8,ema21) and op['low']<=max(ema8,ema21)
    tr=max(orr['high']-orr['low'],abs(orr['high']-op['close']),abs(orr['low']-op['close']));assert 0<=tr<=2*atr
    window=bb[pc['bb_window_id']];latest=prep[900]['frame']['frame']['id'];assert window['id']==latest==v['bb_window_id']
    same_bands(pc['bb15'],window['bands']);band=window['bands'];assert band['known'] and band['sigma']>0 and len(window['refs'])==20
    forward=band['upper'] if side==1 else band['lower'];assert v['bb_mean']==pc['bb15']['mean'] and v['bb_forward']==pc['bb15']['upper' if side==1 else 'lower']
    assert math.isclose(v['bb_mean'],band['mean'],rel_tol=1e-12,abs_tol=1e-8) and math.isclose(v['bb_forward'],forward,rel_tol=1e-12,abs_tol=1e-8)
    assert math.isclose(v['cap'],min(atr,125-v['width'],side*(v['bb_forward']-v['k'])-125),rel_tol=1e-12,abs_tol=1e-8)
    price=q['ask'] if side==1 else q['bid'];assert price==e['entry_price']
    for x in (b['last'],q['last'],price):
        assert 0<=side*(x-v['k'])<=v['cap'] and side*(x-v['bb_mean'])>=0 and side*(v['bb_forward']-x)>=125
    assert 0<side*(price-v['i'])<=125
    entry_refs=[];current_values(ordered,q,side,None,True,entry_refs)
    required_refs={ref_key(ref) for ref in (pc['refs'] or [])+(rc['refs'] or [])+[e['arm'],e['confirm']]+entry_refs}
    refs={ref_key(ref) for ref in e['refs']};assert required_refs<=refs
    for ref in e['refs']:
        if ref['width_seconds']==60:
            bar=bars[ref['id']]['bar'];assert ref['delivered']==bar['stamp'] and ref['end']==bar['end']
        else:
            pub=publications[ref_key(ref)];frame=pub['frame']['frame'];assert frame['contract']==scene['contract']
            assert pub['stamp']['time']<=q['time']
            if frame['session_id']==scene['session']:assert pub['stamp']['index']<=q['index'] and pub['stamp']['source_line']<=q['source_line']
        assert ref['delivered']['time']<=q['time']
    for context in (pc,rc):
        for ref in context['refs'] or []:
            pub=publications[ref_key(ref)];frame=pub['frame']['frame'];assert frame['session_id']==scene['session'] and frame['contract']==scene['contract']
            assert all(ref['delivered'][k]<=context['at'][k] for k in ('time','index','source_line'))
    for at,wanted in ((b,r),):
        available=[x['bar'] for x in bars.values() if all(x['bar']['stamp'][k]<=at[k] for k in ('time','index','source_line'))]
        assert available and max(available,key=lambda x:x['end'])['id']==wanted['id']
    available=[x['bar'] for x in bars.values() if all(x['bar']['stamp'][k]<=q[k] for k in ('time','index','source_line'))]
    latest=max(available,key=lambda x:x['end']);assert latest['price_known'] and latest['closed'] and not latest.get('missing',False) and q['time']<latest['end']+120


# ----------------------------------------
def build(old_fixed: dict,old_meta: dict,source: dict,background: dict) -> tuple[dict,dict]:
    """
    機能: 旧87全値と新groupを保持し、1分のBB/価格適格性と物理取得を確認する。
    引数: old_fixed/old_meta/source/background(dict)は145固定票・147Source・固定122公表。
    返り値: tuple[dict,dict]は固定入力とSource参照。金融を読まない。
    """
    assert old_meta['trial']==145 and source['success'] and source['trial']==147
    windows,publications,ordered=background_index(background)
    sessions=[s['session'] for s in old_fixed['scenes']]
    assert sessions==old_meta['sessions']==[s['session'] for s in source['scenes']]==[s['session'] for s in background['scenes']]
    old_entries={e['id']:e for e in old_meta['entries']}
    assert len(old_entries)==old_fixed['expected_entry_count']
    by_scene={sid:[] for sid in sessions};specs={s['session']:s for s in old_fixed['scenes']}
    for e in old_meta['entries']:
        item=copy.deepcopy(e);item['legacy_model']=item['model'];item['model']='C1'
        assert item['legacy_model'] in ('C0','A0','B0') and item['baseline']==(item['legacy_model']=='C0')
        by_scene[item['session']].append(item)
    for sc in source['scenes']:
        sid=sc['session'];scene=specs[sid]
        assert sc['success'] and sc['stat_before']==sc['stat_after'] and sc['counts']==scene['expected_quality']
        assert sc['contract']==scene['contract'] and sc['actual_sha256']==scene['raw']['sha256']
        assert all(isinstance(sc[k],list) for k in ('events','groups','bars','bb_windows'))
        bb=validate_windows(sc,windows)
        events={e['id']:e for e in sc['events']};bars={e['bar']['id']:e for e in sc['bars']}
        assert len(events)==len(sc['events']) and len(bars)==len(sc['bars'])
        seen_groups=set();used=set();physical=set()
        for gi,g in enumerate(sc['groups']):
            assert g['id'] not in seen_groups;seen_groups.add(g['id'])
            candidate_ids=g['candidate_ids'];filled=g['filled_candidate_ids']
            assert len(set(candidate_ids))==len(candidate_ids) and set(candidate_ids)<=set(events)
            assert len(set(filled))==len(filled) and set(filled)<=set(candidate_ids)
            assert {key for key in candidate_ids if events[key]['status']=='filled'}==set(filled)
            if not filled:
                assert g['status']!='filled';continue
            assert g['entryQuote'] is not None and type(g['side']) is int and g['side'] in (-1,1)
            assert g['status']=='filled' and len(candidate_ids)==len(filled)==1
            assert not set(filled)&used;used.update(filled)
            quote=g['entryQuote'];key=stamp_key(sid,sc['contract'],quote)
            assert key not in physical;physical.add(key)
            candidates=[events[key] for key in filled]
            for e in candidates:validate_event(e,g,bars,scene,bb,publications,ordered[sid])
            chosen=candidates[0]
            assert g['representative_id']==chosen['id']
            origins=[{'id':e['id'],'family':e['family'],'width':e['width_seconds'],'side':e['side'],
                'source_locator':{'scene':sid,'group_index':gi,'candidate_id':e['id']},
                'birthQuote':copy.deepcopy(e['birth']),'structure':copy.deepcopy(e['structure']),
                'arm':copy.deepcopy(e['arm']),'confirm':copy.deepcopy(e['confirm']),
                'refs':copy.deepcopy(e['refs']),'refs_asof':'取得時点まで。短期bars/contextは各初回配送時点'} for e in candidates]
            by_scene[sid].append({'id':'T0/'+g['id'],'session':sid,'contract':sc['contract'],'model':'T0',
                'candidate_id':g['id'],'native_side':g['side'],'baseline':False,'entry_quote':copy.deepcopy(quote),
                'origins':origins,'widths':sorted({o['width'] for o in origins})})
        assert used=={key for key,e in events.items() if e['status']=='filled'}
    fixed={'scenes':[],'expected_entry_count':0}
    meta={'success':True,'trial':147,'sessions':sessions,'entries':[],'union':[],
        'dedup_key':'session/contract/取得time/index/source_line','dedup_priority':'C1→T0',
        'policies':['C0','C1','T0','U0','RU'],'financial_labels_used':False,'portfolio_replay':False}
    seen=set()
    for original in old_fixed['scenes']:
        sc=copy.deepcopy(original);sid=sc['session'];sc['entries']=[];grouped={};per_model=set()
        for e in sorted(by_scene[sid],key=lambda e:(e['entry_quote']['index'],e['model']!='C1',e['id'])):
            q=e['entry_quote'];key=stamp_key(sid,e['contract'],q)
            assert e['id'] not in seen and type(e['native_side']) is int and e['native_side'] in (-1,1)
            assert e['contract']==sc['contract'] and q['clock'] and q['quote_ok'] and 0<q['bid']<q['ask']
            assert sc['start']<=q['time']<min(sc['force_close'],sc['end']-3900)
            assert (e['model'],key) not in per_model
            per_model.add((e['model'],key));seen.add(e['id'])
            sc['entries'].append({'id':e['id'],'side':e['native_side'],'entry':copy.deepcopy(q)})
            meta['entries'].append(e);grouped.setdefault(key,[]).append(e)
        for key,items in grouped.items():
            chosen=min(items,key=lambda e:(e['model']!='C1',e['id']))
            assert all(all(e['entry_quote'][k]==chosen['entry_quote'][k] for k in QUOTE_FIELDS) for e in items)
            meta['union'].append({'canonical_id':chosen['id'],'alias_ids':[e['id'] for e in items],
                'alias_sides':{e['id']:e['native_side'] for e in items},'session':sid,'contract':sc['contract'],
                'entry_stamp':{'time':key[2],'index':key[3],'source_line':key[4]}})
        fixed['scenes'].append(sc);fixed['expected_entry_count']+=len(sc['entries'])
    before={(sc['session'],e['id']):e for sc in old_fixed['scenes'] for e in sc['entries']}
    after={(sc['session'],e['id']):e for sc in fixed['scenes'] for e in sc['entries'] if e['id'] in old_entries}
    assert before==after
    return fixed,meta


# ----------------------------------------
def main() -> None:
    """
    機能: F0/Source/SHAを照合し、旧87と新1分・BB照合結果を金融前に固定取得へ転送する。
    引数: CLI --f0/--source/--output-dir(Path)、--f0-sha256/--sha256(str)。
    返り値: None。背景177MBは一度だけbytes読取し同じbytesでSHA照合とJSON化する。
    """
    parser=argparse.ArgumentParser(description='147中位回復と旧87の非金融転送')
    for key in ('f0','source','output-dir'):parser.add_argument('--'+key,type=Path,required=True)
    parser.add_argument('--f0-sha256',required=True);parser.add_argument('--sha256',required=True);args=parser.parse_args()
    raw=args.f0.read_bytes();assert hashlib.sha256(raw).hexdigest()==args.f0_sha256
    frozen=json.loads(raw);assert frozen['成功'] and frozen['試行']==147
    declared={Path(n).resolve():h for n,h in frozen['ファイル'].items()}
    assert declared[Path(__file__).resolve()]==sha(Path(__file__).resolve())
    loaded={};stats={}
    for path,h in SHAS.items():
        assert declared[path.resolve()]==h
        before=path.stat();body=path.read_bytes();assert hashlib.sha256(body).hexdigest()==h
        loaded[path]=json.loads(body);stats[path]=(before.st_size,before.st_mtime_ns);del body
        after=path.stat();assert stats[path]==(after.st_size,after.st_mtime_ns)
    assert all(sha(path)==h for path,h in declared.items() if path not in SHAS)
    source_stat=args.source.stat();source_body=args.source.read_bytes()
    assert hashlib.sha256(source_body).hexdigest()==args.sha256;source=json.loads(source_body);del source_body
    fixed,meta=build(loaded[OLD_FIXED],loaded[OLD_META],source,loaded[BACKGROUND])
    assert sum(e['model']=='C1' for e in meta['entries'])==87 and sum(e['model']=='C1' and e['baseline'] for e in meta['entries'])==81
    for entry in meta['entries']:
        if entry['model']=='T0':
            for origin in entry['origins']:origin['source_file_sha']=args.sha256
    destination=args.output_dir;destination.mkdir(parents=True,exist_ok=True)
    assert not any((destination/name).exists() for name in ('固定取得入力.json','入口参照.json','転送の確認.json'))
    save(destination/'固定取得入力.json',fixed)
    meta.update({'fixed_input_sha256':sha(destination/'固定取得入力.json'),'source_sha256':args.sha256,
        'old_fixed_sha256':SHAS[OLD_FIXED],'old_metadata_sha256':SHAS[OLD_META],'background_sha256':SHAS[BACKGROUND]})
    save(destination/'入口参照.json',meta)
    for path,before in stats.items():
        after=path.stat();assert before==(after.st_size,after.st_mtime_ns)
    assert all(sha(path)==h for path,h in declared.items() if path not in SHAS)
    after=args.source.stat();assert (source_stat.st_size,source_stat.st_mtime_ns)==(after.st_size,after.st_mtime_ns)
    new=[e for e in meta['entries'] if e['model']=='T0']
    report={'成功':True,'試行':147,'F0_SHA256':args.f0_sha256,'Source_SHA256':args.sha256,'旧87同体':True,
        '基礎C1':87,'T0物理取得':len(new),'union取得':len(meta['union']),'金融参照':False,
        '背景122一度読取':True,'BB窓を独立構成':True,'固定入力SHA256':meta['fixed_input_sha256'],
        '入口参照SHA256':sha(destination/'入口参照.json'),'background_SHA256':SHAS[BACKGROUND]}
    save(destination/'転送の確認.json',report);print(json.dumps(report,ensure_ascii=False))


if __name__=='__main__':main()
