"""147の人工・由来・依存を自然実行前に固定する。"""
from pathlib import Path
import hashlib
import json
import subprocess

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
OLD=ROOT/'work/146短期構造の入口'
SPEC=ROOT/'work/147_中位足の価格位置と短期実体回復の採用仕様.md'
SPEC_SHA='6bb9c317db1151d31af727b47987530788e5eeee334bcfdd1426f6f93e39624d'
EXE=HERE/'中位実体回復生成.exe'


def sha(path: Path) -> str:
    """
    機能: 価格値を開かずコード等の指紋を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def ref(path: Path) -> dict:
    """
    機能: 再現源を相対path/サイズ/SHAへ束縛する。
    引数: path(Path)。返り値: dict。
    """
    return {'path':str(path.relative_to(ROOT)),'bytes':path.stat().st_size,'sha256':sha(path)}


def main() -> None:
    """
    機能: 人工とbuildを実行し停止証跡を保存する。
    引数: なし。返り値: None。
    """
    assert sha(SPEC)==SPEC_SHA
    copies=['csv.go','csvtypes.go','rawtypes.go','decoder.go','input_base.go']
    origin=[]
    for name in copies:
        source=OLD/name;target=HERE/name
        assert source.read_bytes().replace(b'package shortpattern146',b'package midrecover147',1)==target.read_bytes(),name
        origin.append({'元':ref(source),'新':ref(target),'差分':'package行だけ'})
    provenance={'成功':True,'試行':147,'旧5源package以外本文同体':origin,
        '他の継承':'input.goは小参照trial147だけ、CSV/Rawの価格parseと品質分母は不変更。scannerは1分専用・BB正本配送、状態は147単一T。',
        '旧118Bank変更':False,'不要依存':'短期numeric/3分/threeframeは含めない。118だけへ依存。',
        '作者分担':{'review131':['publications.go','publications_test.go'],'settings119':'その他の新Source。cache作者を当該部品の独立役とはしない。'}}
    (HERE/'由来.json').write_text(json.dumps(provenance,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    own=[*HERE.glob('*.go'),*HERE.glob('cmd/**/*.go'),HERE/'go.mod',HERE/'入力参照.json',HERE/'README.md',HERE/'由来.json',Path(__file__).resolve()]
    deps=[ROOT/'work/118複数技法の入口条件'/name for name in ['bank.go','types.go','rules.go','go.mod']]
    all_paths=sorted(set(own+deps+[SPEC]+[OLD/name for name in copies]),key=str)
    before={str(path):sha(path) for path in all_paths}
    logs=[]
    for args in [['go','version'],['go','test','-count=1','-v','./...'],['go','vet','./...'],['go','build','-o',EXE.name,'./cmd/run']]:
        r=subprocess.run(args,cwd=HERE,capture_output=True,text=True,encoding='utf-8',errors='replace')
        logs.append({'引数':args,'終了コード':r.returncode,'標準出力':r.stdout,'標準エラー':r.stderr})
        assert r.returncode==0,logs[-1]
    assert before=={str(path):sha(path) for path in all_paths}
    assert logs[1]['標準出力'].count('--- PASS:')>=16
    result={'成功':True,'試行':147,'編集停止':True,'人工主群数':sum(line.startswith('--- PASS:') for line in logs[1]['標準出力'].splitlines()),
        '確認':logs,'源':[ref(path)for path in all_paths],'実行ファイル':ref(EXE),'採用仕様SHA256':SPEC_SHA,
        '実効workers':1,'自然CSV_Raw本文読取':False,'自然Source生成':False,'自然金融読取':False,'追加2場読取':False,
        '作者分担':provenance['作者分担'],'証明範囲':'作者人工/型/因果/鏡像/品質とbuildの確認。新手法の先着率・全場取得・頻度はまだ未実行。',
        '旧源変更':False,'全対象前後SHA一致':True,'短期数値carry又は3分':False}
    output=HERE/'準備の確認.json';output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'success':True,'proof_sha256':sha(output),'exe_sha256':sha(EXE),'sources':len(all_paths),'tests':result['人工主群数']}))


if __name__=='__main__':
    main()
