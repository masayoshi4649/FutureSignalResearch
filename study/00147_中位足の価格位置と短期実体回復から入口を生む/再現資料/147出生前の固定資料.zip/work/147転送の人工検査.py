"""147の中位BB/1分回復・実P・旧87保護を人工資料だけで検査する。"""
from pathlib import Path
import copy
import importlib.util
import json
import math

CODE=Path(__file__).with_name('147中位回復と旧87を固定取得へ渡す.py')
spec=importlib.util.spec_from_file_location('147転送の純部品',CODE)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


def v(x: float) -> dict:
    """
    機能: 人工の既知値を作る。
    引数: x(float)。
    返り値: dictはknown/value。
    """
    return {'known':True,'value':x}


# ----------------------------------------
def reference(pub: dict) -> dict:
    """
    機能: 人工公表から期待する全時計参照を作る。
    引数: pub(dict)。
    返り値: dictは人工期待ref。
    """
    f=pub['frame']['frame'];return {'id':f['id'],'width_seconds':f['width_seconds'],'end':f['end'],'delivered':copy.deepcopy(pub['stamp'])}


# ----------------------------------------
def fixture(cap_zero: bool=False) -> tuple[dict,dict,dict,dict]:
    """
    機能: 旧87と買い/売り各1新取得・正負BB端・同限月窓carryを人工で作る。
    引数: cap_zero(bool)はBB余地でcapがちょうど0の適格例指定。
    返り値: tupleは旧fixed/旧meta/Source/背景122。自然資料を読まない。
    """
    fixed={'scenes':[],'expected_entry_count':0};meta={'trial':145,'sessions':[],'entries':[]}
    source={'success':True,'trial':147,'scenes':[]};background={'trial':122,'scenes':[]};history=[]
    for number in range(2):
        start=40000*number;sid='人工場'+str(number);contract='人工限月';side=1 if number==0 else -1;k0=195 if cap_zero else 120
        mirror=lambda x:x if side==1 else 500-x
        bars_price=lambda o,h,l,c:{'open':mirror(o),'high':mirror(h) if side==1 else mirror(l),'low':mirror(l) if side==1 else mirror(h),'close':mirror(c)}
        pubs=[]
        for width in (300,900,1800):
            for n in range(1,30000//width):
                end=start+n*width;price=(20 if n%2 else 220) if width==900 else k0+5
                ema8=k0-5 if width==300 else k0+5
                tech={'ema8':v(mirror(ema8)),'ema21':v(mirror(k0)),'gap':v(side*(ema8-k0)),'ema21_delta':v(side),
                    'atr':v(100),'tr':v(40),'histogram':v(side*(n-70)),'previous_histogram':v(side*(n-71))}
                frame={'id':f'{sid}/{width}/{n}','session_id':sid,'contract':contract,'width_seconds':width,
                    'start':end-width,'end':end,'available_at':end+60,'delivery_at':end+60,'price_known':True,'volume_known':True,
                    'ohlc':bars_price(price,price+5,price-5,price),'technical':tech}
                pubs.append({'stamp':{'time':end+60,'index':n*width+60,'source_line':n*width+61},
                    'frame':{'frame':frame,'dmi':{'plus_di':v(30 if side==1 else 10),'minus_di':v(10 if side==1 else 30),'adx':v(20+n),'previous_adx':v(19+n)}}})
        pubs.sort(key=lambda p:(p['stamp']['index'],p['frame']['frame']['width_seconds']))
        bb_windows=[]
        for pub in pubs:
            if pub['frame']['frame']['width_seconds']!=900:continue
            history.append(pub);history=history[-20:];count=len(history)
            band={'known':count==20,'count':count,'mean':0.,'sigma':0.,'upper':0.,'lower':0.}
            if count==20:
                closes=[p['frame']['frame']['ohlc']['close'] for p in history];mean=sum(closes)/20;sigma=math.sqrt(sum((c-mean)**2 for c in closes)/20)
                band.update({'mean':mean,'sigma':sigma,'upper':mean+2*sigma,'lower':mean-2*sigma})
            bb_windows.append({'id':pub['frame']['frame']['id'],'bands':band,'refs':[reference(p) for p in history]})
        background['scenes'].append({'session':sid,'contract':contract,'publications':pubs})
        birth_time=start+20520
        def quote(time: int,index: int,last: float,bid: float,ask: float) -> dict:
            """
            機能: 人工の正常気配を価格鏡像で作る。
            引数: time/index(int)、last/bid/ask(float)。
            返り値: dictは全Quote。
            """
            return {'time':time,'index':index,'source_line':index+1,'clock':'人工価格時計','last':mirror(last),
                'bid':mirror(bid) if side==1 else mirror(ask),'ask':mirror(ask) if side==1 else mirror(bid),'quote_ok':True}
        b=quote(birth_time,20520,k0 if cap_zero else k0+5,k0-10 if cap_zero else k0,k0 if cap_zero else k0+10)
        oldq={**b,'time':birth_time+1,'index':20521,'source_line':20522};q={**oldq}
        if number==1:q.update({'time':birth_time+2,'index':20522,'source_line':20523})
        sc={'session':sid,'contract':contract,'start':start,'end':start+30000,'force_close':start+29900,
            'raw':{'path':'人工原板','sha256':'0'*64},'expected_quality':{'人工':True},
            'entries':[{'id':'C0/'+sid,'side':-side,'entry':copy.deepcopy(oldq)}]}
        fixed['scenes'].append(sc);meta['sessions'].append(sid)
        meta['entries'].append({'id':'C0/'+sid,'session':sid,'contract':contract,'model':'C0','candidate_id':sid,
            'native_side':-side,'baseline':True,'entry_quote':copy.deepcopy(oldq),'origins':[{'人工旧':True}]})
        def context(at: dict) -> dict:
            """
            機能: 人工の実公表からSource側の当時Context期待値を明示する。
            引数: at(dict)は初配送Quote。
            返り値: dictは当時の最新3公表/実前両端/BB。
            """
            current={w:max([p for p in pubs if p['frame']['frame']['width_seconds']==w and p['stamp']['time']<=at['time']],key=lambda p:p['frame']['frame']['end']) for w in (300,900,1800)}
            previous={w:next(p for p in pubs if p['frame']['frame']['width_seconds']==w and p['frame']['frame']['end']==current[w]['frame']['frame']['end']-w) for w in (300,900)}
            t5=current[300]['frame']['frame']['technical'];t30=current[1800]['frame']['frame']['technical'];d=current[900]['frame']['dmi']
            fields={f'price_known_{w}':v(1) for w in (300,900,1800)}
            fields.update({'gap30':t30['gap'],'ema21_delta30':t30['ema21_delta'],'atr5':t5['atr'],'ema8_5':t5['ema8'],'ema21_5':t5['ema21'],
                'hist_delta5':v(t5['histogram']['value']-previous[300]['frame']['frame']['technical']['histogram']['value']),
                'adx_delta15':v(d['adx']['value']-previous[900]['frame']['dmi']['adx']['value']),
                'di_difference15':v(d['plus_di']['value']-d['minus_di']['value']),'tr5':t5['tr'],'previous_atr5':previous[300]['frame']['frame']['technical']['atr']})
            win=next(w for w in bb_windows if w['id']==current[900]['frame']['frame']['id'])
            return {'at':copy.deepcopy(at),'direction30':side,'fields':copy.deepcopy(fields),'refs':[reference(x) for x in list(current.values())+list(previous.values())],
                'bb_window_id':win['id'],'bb15':copy.deepcopy(win['bands'])}
        pbar={'id':sid+'/p','session':sid,'contract':contract,'width_seconds':60,'start':start+20340,'end':start+20400,'available_at':start+20460,
            'stamp':{'time':start+20460,'index':20460,'source_line':20461},'price_known':True,'volume_known':True,'closed':True,'missing':False,
            'ohlc':bars_price(k0,k0+10,k0-20,k0-10),'volume':10}
        rbar={'id':sid+'/r','session':sid,'contract':contract,'width_seconds':60,'start':start+20400,'end':start+20460,'available_at':birth_time,
            'stamp':{'time':birth_time,'index':20520,'source_line':20521},'price_known':True,'volume_known':True,'closed':True,'missing':False,
            'ohlc':bars_price(k0-10,k0+20,k0-15,k0+10),'volume':20}
        pat=quote(start+20460,20460,k0-10,k0-15,k0-5);pc=context(pat);rc=context(b)
        refs=[{'id':bar['id'],'width_seconds':60,'end':bar['end'],'delivered':copy.deepcopy(bar['stamp'])} for bar in (pbar,rbar)]
        used=[]
        for ref in refs+pc['refs']+rc['refs']:
            if ref not in used:used.append(copy.deepcopy(ref))
        band=pc['bb15'];k=mirror(k0);i=mirror(k0-30);f=band['upper'] if side==1 else band['lower'];cap=min(100,95,side*(f-k)-125)
        event={'id':sid+'/T','family':'T0','width_seconds':60,'side':side,'status':'filled','birth':copy.deepcopy(b),'entryQuote':copy.deepcopy(q),
            'entry_price':q['ask'] if side==1 else q['bid'],'expires':birth_time+30,'group_id':sid+'/group',
            'structure':{'k':k,'i':i,'width':30,'cap':cap,'arm_atr':100,'cap_atr_width_seconds':300,'bb_mean':band['mean'],'bb_forward':f,'bb_window_id':pc['bb_window_id']},
            'arm':refs[0],'confirm':refs[1],'refs':used}
        group={'id':sid+'/group','side':side,'status':'filled','birth':copy.deepcopy(b),'entryQuote':copy.deepcopy(q),
            'candidate_ids':[event['id']],'filled_candidate_ids':[event['id']],'representative_id':event['id']}
        source['scenes'].append({'success':True,'session':sid,'contract':contract,'actual_sha256':'0'*64,'stat_before':{'人工':True},'stat_after':{'人工':True},
            'counts':{'人工':True},'bars':[{'bar':pbar,'context':pc},{'bar':rbar,'context':rc}],'events':[event],'groups':[group],'bb_windows':bb_windows})
    # 旧87全保護を、少数旧対照だけで代用しない。
    for j in range(85):
        family='C0' if j<79 else 'A0' if j<81 else 'B0';eid=family+'/人工追加'+str(j);scene=fixed['scenes'][0]
        q={'time':1000+j*10,'index':1000+j*10,'source_line':1001+j*10,'clock':'人工価格時計','last':125,'bid':120,'ask':130,'quote_ok':True}
        scene['entries'].append({'id':eid,'side':1,'entry':copy.deepcopy(q)})
        meta['entries'].append({'id':eid,'session':scene['session'],'contract':scene['contract'],'model':family,'candidate_id':'人工追加'+str(j),
            'native_side':1,'baseline':family=='C0','entry_quote':copy.deepcopy(q),'origins':[{'人工旧':True}]})
    fixed['expected_entry_count']=87
    for scene in fixed['scenes']:scene['entries'].sort(key=lambda e:(e['entry']['index'],e['id']))
    return fixed,meta,source,background


# ----------------------------------------
def reject(callable_: object) -> None:
    """
    機能: 不正人工票を拒否することを確認する。
    引数: callable_(callable)。
    返り値: None。
    """
    try:callable_()
    except (AssertionError,KeyError):return
    raise AssertionError('不正票を受け入れました')


# ----------------------------------------
def main() -> None:
    """
    機能: 価格鏡像/BB窓/境界/旧87/0取得を意味ある人工だけで確認する。
    引数: なし。
    返り値: None。自然Source/背景122本文/金融を開かない。
    """
    fixed,meta,source,background=fixture();out,ref=m.build(fixed,meta,source,background);tests=[]
    assert out['expected_entry_count']==89 and len(ref['union'])==88
    old=[e for e in ref['entries'] if e['model']=='C1'];new=[e for e in ref['entries'] if e['model']=='T0']
    assert len(old)==87 and sum(e['baseline'] for e in old)==81 and len(new)==2 and all(e['widths']==[60] and len(e['origins'])==1 for e in new)
    by_id={e['id']:e for e in meta['entries']}
    assert all({k:v for k,v in e.items() if k!='legacy_model'}=={**by_id[e['id']],'model':'C1'} for e in old)
    overlap=next(u for u in ref['union'] if len(u['alias_ids'])==2);assert overlap['canonical_id'].startswith('C0/') and set(overlap['alias_sides'].values())=={-1,1}
    tests.append('買い売り鏡像/旧87と旧6全保護/C1反対alias/新物理1')
    zero=copy.deepcopy(source)
    for scene in zero['scenes']:scene['events']=[];scene['groups']=[];scene['bars']=[]
    of,om=m.build(fixed,meta,zero,background);assert of==fixed and len(om['union'])==87;tests.append('新0件でも旧87/全場/BB窓を保持')
    m.build(*fixture(True));tests.append('BB余地cap0/中心と順端まで125の等号は適格')
    kinds=('BB元ref改変','BB値改変','BB20count改変','cap改変','中心逆側','実P域外','BB余地不足','pOpen回復不成立','量不足','旧ATR差替え',
        '同Raw知得','TTL等号','構造I差替え','filled欠落','代表誤り','物理重複','p背景未来ref','最新rでない','bool方向')
    for kind in kinds:
        changed=copy.deepcopy(source);scene=changed['scenes'][0];e=scene['events'][0];g=scene['groups'][0]
        if kind=='BB元ref改変':scene['bb_windows'][-1]['refs'][0]['end']+=900
        elif kind=='BB値改変':scene['bb_windows'][19]['bands']['sigma']+=1
        elif kind=='BB20count改変':scene['bb_windows'][19]['bands']['count']=19
        elif kind=='cap改変':e['structure']['cap']+=1
        elif kind=='中心逆側':e['birth']['last']=119;g['birth']['last']=119;scene['bars'][1]['context']['at']['last']=119
        elif kind in ('実P域外','BB余地不足'):
            q=e['entryQuote'];q.update({'last':200,'bid':195,'ask':205});g['entryQuote']=copy.deepcopy(q);e['entry_price']=205
        elif kind=='pOpen回復不成立':scene['bars'][1]['bar']['ohlc']['close']=119
        elif kind=='量不足':scene['bars'][1]['bar']['volume']=9
        elif kind=='旧ATR差替え':scene['bars'][0]['context']['fields']['atr5']['value']=101
        elif kind=='同Raw知得':
            scene['bars'][0]['bar']['stamp']=copy.deepcopy(scene['bars'][1]['bar']['stamp']);scene['bars'][0]['context']['at']=copy.deepcopy(scene['bars'][1]['context']['at']);e['arm']['delivered']=copy.deepcopy(scene['bars'][0]['bar']['stamp'])
        elif kind=='TTL等号':e['entryQuote']['time']=e['expires'];g['entryQuote']['time']=e['expires']
        elif kind=='構造I差替え':e['structure'].update({'i':89,'width':31})
        elif kind=='filled欠落':g['filled_candidate_ids']=[]
        elif kind=='代表誤り':g['representative_id']='存在しない候補'
        elif kind=='物理重複':scene['groups'].append(copy.deepcopy(g))
        elif kind=='p背景未来ref':scene['bars'][0]['context']['refs'][0]['delivered']['time']=e['birth']['time']+1000
        elif kind=='最新rでない':
            bar=copy.deepcopy(scene['bars'][-1]);bar['bar'].update({'id':'未来同Raw最新','start':bar['bar']['start']+60,'end':bar['bar']['end']+60});scene['bars'].append(bar)
        else:e['side']=True
        reject(lambda:m.build(fixed,meta,changed,background));tests.append(kind+'を拒否')
    # 同一IDの正しい重複は窓を増やさず、未知は既知0としない。
    bg=copy.deepcopy(background);bg['scenes'][0]['publications'].insert(1,copy.deepcopy(bg['scenes'][0]['publications'][0]))
    m.build(fixed,meta,source,bg);tests.append('同ID同値再配送はBB観測数を増やさない')
    index,_,_=m.background_index(background);first=next(p for p in background['scenes'][1]['publications'] if p['frame']['frame']['width_seconds']==900)
    w=index['人工場1',first['frame']['frame']['id']];assert w['bands']['count']==20 and w['bands']['known'] and any(r['id'].startswith('人工場0/') for r in w['refs']);tests.append('同限月は場間BB窓と過去refsだけcarry')
    bg=copy.deepcopy(background);f=next(p for p in bg['scenes'][0]['publications'] if p['frame']['frame']['width_seconds']==900);f['frame']['frame']['price_known']=False
    ix,_,_=m.background_index(bg);assert not ix['人工場0','人工場0/900/20']['bands']['known'] and ix['人工場0','人工場0/900/20']['bands']['count']==20;tests.append('未知価格を20窓に保持して既知0へしない')
    bg=copy.deepcopy(background);bg['scenes'][0]['publications']=[p for p in bg['scenes'][0]['publications'] if p['frame']['frame']['id']!='人工場0/900/2']
    ix,_,_=m.background_index(bg);assert ix['人工場0','人工場0/900/3']['bands']['count']==1 and not ix['人工場0','人工場0/900/3']['bands']['known'];tests.append('同場900秒の欠分で窓を切り観測数を圧縮しない')
    bg=copy.deepcopy(background);bg['scenes'][1]['contract']='次限月'
    for p in bg['scenes'][1]['publications']:p['frame']['frame']['contract']='次限月'
    ix,_,_=m.background_index(bg);assert ix['人工場1','人工場1/900/1']['bands']['count']==1 and not ix['人工場1','人工場1/900/1']['bands']['known'];tests.append('異限月はBB窓をcold resetする')
    print(json.dumps({'成功':True,'人工群':len(tests),'人工':tests,'自然Source/背景122本文/金融/Raw/CSV/追加2場読取':False},ensure_ascii=False))


if __name__=='__main__':main()
