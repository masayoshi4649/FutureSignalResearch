"""147の保存Sourceだけから分母と当時のBB/位置制約を診断する。"""
from collections import Counter
from pathlib import Path
import argparse
import importlib.util
import json
import math
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
READER=ROOT/'work/146短期パターンの非金融診断/段階を診断する.py'
GEN_PROOF=ROOT/'work/147中位位置からの実体回復/準備の確認.json'
EXPECTED_GEN_SHA='58d3e8d1b1b54f17b60d19e9f19bf360c5a3b0fb24d4adf8be275aaf403f55e8'
ROLES=[('当場隣接',['当場隣接p_r']),('配送strict',['p_r初配送strict']),
       ('p初価格方向ATR_BB',['p初300価格fresh','p初900価格fresh','p初1800価格fresh','p初30方向','p初ATR5正','p初BB15正sigma']),
       ('p逆実体',['p逆実体']),('p中位EMA帯接触',['p初EMA5帯接触']),
       ('現在価格30方向',['現在300価格fresh','現在900価格fresh','現在1800価格fresh','現在30方向']),
       ('現在15方向強さ',['現在15DI方向','現在15ADX非低下']),('現在5Hist実改善',['現在5Hist実改善']),
       ('r実体始値回復',['r順実体','r終値p始値回復']),('同足量',['p_r同足量']),
       ('二尺度TRとfresh',['短期TR上限','現在5TR急変ガード','r現在fresh'])]
ALL_GATES={key for _,keys in ROLES for key in keys}


def module(path: Path,name: str):
    """
    機能: mainを実行せず停止済み読取部品を私有importする。
    引数: path(Path)、name(str)。返り値: ModuleType。
    """
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value


reader=module(READER,'reader147diagnosis')


def point(value: dict):
    """
    機能: 未知を0補完せず既知値だけ返す。
    引数: value(dict)。返り値: float又はNone。
    """
    return value['value'] if value and value['known'] else None


def ref(bar: dict) -> dict:
    """
    機能: 短期正本の同一参照を作る。
    引数: bar(dict)。返り値: dict。
    """
    return {'id':bar['id'],'width_seconds':60,'end':bar['end'],'delivered':bar['stamp']}


def gate_pass(value: dict) -> bool:
    """
    機能: 既知かつ成立のgateだけを真にする。
    引数: value(dict)。返り値: bool。
    """
    return bool(value and value['known'] and value['value']==1)


def add_value(count: Counter,value) -> None:
    """
    機能: 数学的診断の未知と成立/不成立を別件数に加える。
    引数: count(Counter)、value(bool又はNone)。返り値: None。
    """
    count['未知' if value is None else '成立' if value else '不成立']+=1


def counter_view(count: Counter) -> dict:
    """
    機能: 条件件数の分母と既知/未知を明示する。
    引数: count(Counter)。返り値: dict。
    """
    known=count['成立']+count['不成立']
    return {'分母':known+count['未知'],'known':known,'成立':count['成立'],'不成立':count['不成立'],'未知':count['未知']}


def geometry(p: dict,r: dict,q: dict) -> dict:
    """
    機能: 技術未成立を含む形状窓全件へ既存幅/BB条件だけを再計算する。
    引数: p/r(dict)、q(dict)。返り値: dict[str,bool又はNone]。
    """
    names=['構造幅125以内','BB中心から順端125以上','Kから順端125以上','cap非負','固定全条件の共通価格域あり','Last_Kcap域','Last_BB中心順側','Last_順端125余地','Last全位置']
    out={name:None for name in names};c=p['context'];side=c['direction30'];bb=c['bb15'];atr=point(c['fields'].get('atr5'))
    if bb['known']:out['BB中心から順端125以上']=2*bb['sigma']>=125
    if side not in (-1,1):return out
    k=p['bar']['ohlc']['open'];i=min(p['bar']['ohlc']['low'],r['bar']['ohlc']['low'])-10 if side==1 else max(p['bar']['ohlc']['high'],r['bar']['ohlc']['high'])+10
    width=side*(k-i);out['構造幅125以内']=0<width<=125
    if not bb['known']:return out
    f=bb['upper'] if side==1 else bb['lower'];room=side*(f-k)-125;center=side*(bb['mean']-k)
    out['Kから順端125以上']=room>=0;out['Last_BB中心順側']=side*(q['last']-bb['mean'])>=0;out['Last_順端125余地']=side*(f-q['last'])>=125
    if atr is None:return out
    cap=min(atr,125-width,room);out['cap非負']=cap>=0
    out['固定全条件の共通価格域あり']=0<width<=125 and cap>=max(0,center)
    out['Last_Kcap域']=0<=side*(q['last']-k)<=cap
    out['Last全位置']=out['Last_Kcap域'] and out['Last_BB中心順側'] and out['Last_順端125余地']
    return out


def verify_context(context: dict,windows: dict,same_scene_ids: set) -> int:
    """
    機能: 当時ContextをBB正本へ結合し未来の参照混入を拒否する。
    引数: context(dict)、windows(dict)、same_scene_ids(set)。返り値: intは結合件数。
    """
    at=context['at']
    for item in context['refs'] or []:
        assert item['end']<=item['delivered']['time']
        assert all(item['delivered'][key]<=at[key] for key in ('time','index','source_line'))
    key=context['bb_window_id']
    if not key:
        assert not context['bb15']['known'];return 0
    w=windows[key];assert w['bands']==context['bb15']
    assert any(x['id']==key and x['width_seconds']==900 for x in context['refs'])
    for item in w['refs']:
        assert item['delivered']['time']<=at['time']
        if item['id'] in same_scene_ids:
            assert item['delivered']['index']<=at['index'] and item['delivered']['source_line']<=at['source_line']
    return 1


def analyze_scene(scene: dict) -> dict:
    """
    機能: 一場の全足/check/候補/groupを異なる分母のまま数える。
    引数: scene(dict)。返り値: dict。
    """
    assert scene['success'] and scene['raw_passes']==1 and scene['counts']==scene['quality']==scene['expected_quality']
    assert scene['stat_before']==scene['stat_after'] and scene['actual_sha256']==scene['raw']['sha256']
    windows={w['id']:w for w in scene['bb_windows']};assert len(windows)==len(scene['bb_windows'])
    window_stats=Counter();ids=set(windows)
    for w in windows.values():
        refs=w['refs'];b=w['bands'];assert len(refs)==b['count']<=20 and refs and refs[-1]['id']==w['id']
        assert all(x['width_seconds']==900 for x in refs)
        assert all(x['end']<=x['delivered']['time'] for x in refs)
        assert all(refs[i]['end']<refs[i+1]['end'] and refs[i]['delivered']['time']<=refs[i+1]['delivered']['time'] for i in range(len(refs)-1))
        if b['known']:assert len(refs)==20
        window_stats['正本窓']+=1;window_stats['known窓' if b['known'] else 'unknown窓']+=1
    bars={};history=[];pair={};counts=Counter();context_joins=0;latest={}
    for known in scene['bars']:
        b,c=known['bar'],known['context'];assert b['id'] not in bars and b['width_seconds']==60
        assert b['session']==scene['session'] and b['contract']==scene['contract']
        assert all(c['at'][k]==b['stamp'][k] for k in ('time','index','source_line'))
        assert b['end']<=b['available_at']<=b['stamp']['time'];bars[b['id']]=known
        context_joins+=verify_context(c,windows,ids);counts['全配送1分']+=1;counts['価格known_closed']+=bool(b['price_known'] and b['closed']);counts['量known_closed']+=bool(b['volume_known'] and b['closed'])
        latest[(b['stamp']['time'],b['stamp']['index'],b['stamp']['source_line'])]=b['id']
        if not b['price_known'] or not b['closed']:history=[];continue
        if history and history[-1]['bar']['end']!=b['start']:history=[]
        history.append(known);history=history[-2:]
        if len(history)==2:pair[b['id']]=history[0]
    statuses=Counter();gates={};reasons=Counter();cum=Counter();single_roles=Counter();p_known={};r_known={};geom={};partial=Counter();tech=0
    for check in scene['checks']:
        statuses[check['status']]+=1;reasons.update(set(check['reasons']));q=check['at'];rid=check['r']['id'];r=bars[rid]
        assert ref(r['bar'])==check['r'] and latest[(q['time'],q['index'],q['source_line'])]==rid
        assert all(q[k]==r['context']['at'][k] for k in ('time','index','source_line'))
        for item in check['used_refs']:assert item==ref(bars[item['id']]['bar'])
        for key,value in check['gates'].items():add_value(gates.setdefault(key,Counter()),None if not value['known'] else value['value']==1)
        if check['status']=='late_excluded':assert not check['gates'];continue
        assert gate_pass(check['gates']['当場隣接p_r'])==(rid in pair)
        active=True
        for name,keys in ROLES:
            passed=all(gate_pass(check['gates'].get(key)) for key in keys)
            if passed:single_roles[name]+=1
            active=active and passed
            if active:cum[name]+=1
        if rid not in pair:continue
        assert set(check['gates'])==ALL_GATES
        p=pair[rid];counts['形状窓あり全分母']+=1
        for label,context,target in [('p',p['context'],p_known),('r',r['context'],r_known)]:
            keys=set(context['fields'])|{'ema8_5','ema21_5','atr5','hist_delta5','previous_hist5','declared_previous_hist5','actual_previous_hist5','adx_delta15','previous_adx15','declared_previous_adx15','actual_previous_adx15'}
            for key in keys:
                tally=target.setdefault(key,Counter());tally['分母']+=1;tally['存在']+=key in context['fields'];tally['known']+=point(context['fields'].get(key)) is not None
            tally=target.setdefault('bb15_known',Counter());tally['分母']+=1;tally['存在']+=1;tally['known']+=context['bb15']['known']
        for key,value in geometry(p,r,q).items():add_value(geom.setdefault(key,Counter()),value)
        unknown=any(not x['known'] for x in check['gates'].values());failed=any(x['known'] and x['value']!=1 for x in check['gates'].values())
        partial['未知を含む']+=unknown;partial['既知不成立を含む']+=failed;partial['未知だけが残る']+=unknown and not failed
        if active:tech+=1
    assert tech==cum[ROLES[-1][0]]
    candidates={e['id']:e for e in scene['events']};assert len(candidates)==len(scene['events'])
    event_status=Counter(e['status'] for e in candidates.values());physical=set();in_group=set();group_status=Counter();filled_candidates=0
    for event in candidates.values():
        assert event['family']=='T0' and event['width_seconds']==60
        assert event['arm']==ref(bars[event['arm']['id']]['bar']) and event['confirm']==ref(bars[event['confirm']['id']]['bar'])
        for trace in event['trace']:context_joins+=verify_context(trace['context'],windows,ids)
    for group in scene['groups']:
        group_status[group['status']]+=1;in_group.update(group['candidate_ids'])
        for key in group['candidate_ids']:assert candidates[key]['group_id']==group['id']
        if group['status']!='filled':assert group['entryQuote'] is None;continue
        entries=[candidates[key] for key in group['filled_candidate_ids']];assert entries
        assert all(e['status']=='filled' and e['entryQuote']==group['entryQuote'] and e['side']==group['side'] for e in entries)
        assert group['representative_id']==min(e['id'] for e in entries)
        q=group['entryQuote'];key=(q['time'],q['index'],q['source_line']);assert key not in physical;physical.add(key);filled_candidates+=len(entries)
    assert all(e['id'] in in_group or e['status']=='suppressed' for e in candidates.values())
    assert filled_candidates==event_status['filled']
    eligible=statuses['birth_eligible']+statuses['suppressed'];assert eligible==len(candidates)
    assert tech==sum(statuses[k] for k in ('structure_rejected','target_room_rejected','position_rejected','birth_eligible','suppressed'))
    return {'session':scene['session'],'contract':scene['contract'],'hours':(scene['end']-300-scene['start'])/3600,'足':dict(counts),
        'check_status':dict(statuses),'個別gate':{k:counter_view(v)for k,v in gates.items()},'非排他的理由':dict(reasons),
        '説明順累積':dict(cum),'役割単独成立_重複あり':dict(single_roles),'形状窓内の未知区分':dict(partial),
        'p初Context既知':{k:dict(v)for k,v in p_known.items()},'r現在Context既知':{k:dict(v)for k,v in r_known.items()},
        '形状窓全件への別幾何診断':{k:counter_view(v)for k,v in geom.items()},'技術完成':tech,'候補数':len(candidates),
        '候補status':dict(event_status),'group_status':dict(group_status),'物理取得数':len(physical),'filled候補数':filled_candidates,
        'BB正本':dict(window_stats),'Context_BB正本結合数':context_joins,'原板指紋':{'path':scene['raw']['path'],'sha256':scene['actual_sha256'],'stat':scene['stat_before']}}


def diagnose(source_reader) -> dict:
    """
    機能: 全73場と全分母を小型の件数表へ統合する。
    引数: source_reader(SceneReader又は人工互換)。返り値: dict。
    """
    scenes=[analyze_scene(s) for s in source_reader];sessions=[s['session'] for s in scenes];top=source_reader.top
    assert len(scenes)==len(set(sessions))==73 and sessions==sorted(sessions)
    assert top['success'] and top['trial']==147 and not top['financial_labels_used'] and not top['source_positions_used']
    simple=['足','check_status','非排他的理由','説明順累積','役割単独成立_重複あり','形状窓内の未知区分','候補status','group_status','BB正本']
    nested=['個別gate','p初Context既知','r現在Context既知','形状窓全件への別幾何診断']
    result={'成功':True,'試行':147,'全場数':73,'全73場':scenes,'先着率':None,'IFD損益':None,'金融参照':False}
    for key in simple:
        tally=Counter()
        for row in scenes:tally.update(row[key])
        result[key]=dict(tally)
    for key in nested:
        tally={}
        for row in scenes:
            for name,counts in row[key].items():tally.setdefault(name,Counter()).update(counts)
        result[key]={name:dict(counts) for name,counts in tally.items()}
    for key in ['技術完成','候補数','物理取得数','filled候補数','Context_BB正本結合数']:result[key]=sum(s[key] for s in scenes)
    result['取得場数']=sum(s['物理取得数']>0 for s in scenes);result['全場最低1取得']=result['取得場数']==73
    result['未取得場']=[s['session'] for s in scenes if s['物理取得数']==0];result['hours']=sum(s['hours'] for s in scenes);result['物理平均毎h']=result['物理取得数']/result['hours']
    assert result['候補数']==top['summary'].get('候補数',0) and result['物理取得数']==top['summary'].get('物理取得数',0) and result['filled候補数']==top['summary'].get('filled候補数',0)
    return result


def short_report(result: dict) -> str:
    """
    機能: 成績を作らず排他的段階と重複役割の違いを短報にする。
    引数: result(dict)。返り値: str。
    """
    s=result['check_status'];tech=result['技術完成'];width=tech-s.get('structure_rejected',0);room=width-s.get('target_room_rejected',0);position=room-s.get('position_rejected',0)
    lines=['# 147非金融funnel診断','',f"全73場。取得{result['取得場数']}場、未取得{len(result['未取得場'])}場。新stream物理取得{result['物理取得数']}件、{result['物理平均毎h']:.6f}回/時。先着率・損益はnullで、取得ゼロを勝率0%とはしない。",'',
        '|段階|件数|','|---|---:|',f"|全配送1分|{result['足'].get('全配送1分',0)}|",f"|全check（末尾含む）|{sum(s.values())}|",f"|技術全条件成立|{tech}|",f"|構造幅後|{width}|",f"|BB目標余地後|{room}|",f"|完成時Last位置後|{position}|",f"|全候補（抑止含む）|{result['候補数']}|",f"|filled候補|{result['filled候補数']}|",f"|物理取得|{result['物理取得数']}|",'',
        '技術完成後の段階は排他的statusを引いたもの。個別gate/役割は重複するので足し合わせない。BB余地や位置は技術未成立の形状窓全件にも別診断を保存し、完成後だけの分母と区別する。','','|説明用に追加した役割|累積成立|単独成立（重複）|','|---|---:|---:|']
    for role,_ in ROLES:lines.append(f"|{role}|{result['説明順累積'].get(role,0)}|{result['役割単独成立_重複あり'].get(role,0)}|")
    lines+=['','この順序は原因の独立効果ではない。既存gateの同時成立を説明順で数えた。未知を0へ補完せず、各gate/Contextの存在・known・成立/不成立の分母は全73場JSONに保存した。',
        '', 'BB正本とContextの内部結合/知得因果を確認した。BBの原122による数学・全ref独立照合はbridge検査へ参照し、177MBの再読をしていない。Source担当自身による保存結果の再集計で、原板/CSVからの独立生成ではない。',
        '', '低頻度/ゼロ出生でも条件や閾値を変更しない。未取得場を落とさず、価格位置・背景助走・実体回復の各分母から次の問いを立てる。新金融・Raw・CSV・追加2場は参照していない。','']
    return '\n'.join(lines)


def main() -> None:
    """
    機能: Root完成通知後にだけ指定SHAのSourceを未作成先へ診断する。
    引数: CLI source/sha256/output-dir(str)。返り値: None。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--source',required=True);parser.add_argument('--sha256',required=True);parser.add_argument('--output-dir',required=True)
    args=parser.parse_args();source=Path(args.source);target=Path(args.output_dir)
    assert not target.exists() and len(args.sha256)==64 and all(x in '0123456789abcdef' for x in args.sha256)
    assert reader.file_sha(GEN_PROOF)==EXPECTED_GEN_SHA
    gen=json.loads(GEN_PROOF.read_bytes());assert all(reader.file_sha(ROOT/f['path'])==f['sha256'] for f in gen['源'])
    before=source.stat();assert reader.file_sha(source)==args.sha256
    result=diagnose(reader.SceneReader(source));after=source.stat();assert before.st_size==after.st_size and before.st_mtime_ns==after.st_mtime_ns and reader.file_sha(source)==args.sha256
    result['Source参照']={'path':str(source),'sha256':args.sha256,'bytes':before.st_size,'mtime_ns':before.st_mtime_ns}
    target.mkdir(parents=True);output=target/'全73場の中位回復段階.json';output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    report=target/'段階と分母の短報.md';report.write_text(short_report(result),encoding='utf-8')
    proof={'成功':True,'試行':147,'非金融':True,'Source参照':result['Source参照'],'Source前後指紋同体':True,'GEN全源同体':True,'GEN準備SHA256':EXPECTED_GEN_SHA,
        'コードSHA256':reader.file_sha(Path(__file__)),'readerSHA256':reader.file_sha(READER),'結果SHA256':reader.file_sha(output),'短報SHA256':reader.file_sha(report),
        '金融_Raw_CSV_追加2場読取':False,'Source又は条件変更':False,'原122再読':False,'先着率':None}
    out=target/'診断の確認.json';out.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'success':True,'proof_sha256':reader.file_sha(out),'births':result['候補数'],'fills':result['物理取得数']}))


if __name__=='__main__':
    main()
