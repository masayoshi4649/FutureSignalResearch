"""自然Sourceを使わず147の分母・BB結合・ゼロ成績を確認する。"""
from pathlib import Path
import copy
import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('diag147',HERE/'診断する.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)


def empty_scene(n: int) -> dict:
    """
    機能: 取得0でも保存する人工場を作る。
    引数: n(int)。返り値: dict。
    """
    return {'session':f'人工{n:02d}_Day','contract':'X','start':n*40000,'end':n*40000+30000,'success':True,'raw_passes':1,
        'raw':{'path':'人工未読','sha256':'a'*64},'actual_sha256':'a'*64,'counts':{},'quality':{},'expected_quality':{},'stat_before':{},'stat_after':{},
        'bb_windows':[],'bars':[],'checks':[],'events':[],'groups':[]}


def known_scene() -> dict:
    """
    機能: 実前値未知でも別にBB位置を診断できる人工2足を作る。
    引数: なし。返り値: dict。
    """
    scene=empty_scene(0)
    refs=[{'id':f'bb{i+1}','width_seconds':900,'end':(i+1)*900,'delivered':{'time':(i+1)*900+60,'index':i,'source_line':i+1}}for i in range(20)]
    bands={'known':True,'mean':995,'sigma':100,'upper':1195,'lower':795,'count':20}
    scene['bb_windows']=[{'id':'bb20','bands':bands,'refs':refs}]
    for name,start,index,o,h,l,c in [('p',19020,30,1000,1005,985,990),('r',19080,31,990,1010,990,1005)]:
        q={'time':start+120,'index':index,'source_line':index+1,'clock':'人工','last':c,'bid':c-1,'ask':c+1,'quote_ok':True}
        bar={'id':name,'session':scene['session'],'contract':'X','width_seconds':60,'start':start,'end':start+60,'available_at':start+120,
            'stamp':{k:q[k]for k in ('time','index','source_line')},'price_known':True,'volume_known':True,'closed':True,'volume':100,
            'ohlc':{'open':o,'high':h,'low':l,'close':c}}
        context={'at':q,'direction30':1,'fields':{'atr5':{'known':True,'value':100},'ema8_5':{'known':True,'value':1000},'ema21_5':{'known':True,'value':995},
            'hist_delta5':{'known':False,'value':0}},'refs':[refs[-1]],'bb15':bands,'bb_window_id':'bb20'}
        scene['bars'].append({'bar':bar,'context':context})
    p,r=scene['bars'];scene['checks']=[{'family':'T0','width_seconds':60,'status':'pattern_rejected','at':p['context']['at'],'r':module.ref(p['bar']),
        'used_refs':[],'gates':{'当場隣接p_r':{'known':True,'value':0}},'reasons':['当場隣接p_r不成立']}]
    gates={key:{'known':True,'value':1}for key in module.ALL_GATES};gates['現在5Hist実改善']={'known':False,'value':0}
    scene['checks'].append({'family':'T0','width_seconds':60,'status':'pattern_rejected','at':r['context']['at'],'r':module.ref(r['bar']),
        'used_refs':[module.ref(p['bar']),module.ref(r['bar'])],'gates':gates,'reasons':['現在5Hist実改善未知']})
    return scene


class FixtureReader:
    """Sourceのtopと73場を人工だけで与える。"""

    def __init__(self,scenes: list):
        """
        機能: 人工場と正本summaryを保持する。
        引数: scenes(list)。返り値: None。
        """
        self.scenes=scenes;self.top={'success':True,'trial':147,'financial_labels_used':False,'source_positions_used':False,
            'summary':{'候補数':sum(len(s['events'])for s in scenes),'filled候補数':sum(e['status']=='filled'for s in scenes for e in s['events']),
                '物理取得数':sum(g['status']=='filled'for s in scenes for g in s['groups'])}}

    def __iter__(self):
        """
        機能: 順序を変えず場を返す。
        引数: self(FixtureReader)。返り値: Iterator[dict]。
        """
        return iter(self.scenes)


class DiagnosisTests(unittest.TestCase):
    """意味の異なるゼロ/未知/同時条件を検査する。"""

    def test_全73ゼロは成績null(self) -> None:
        """
        機能: 未取得場を全件保持し先着率を0へ変えない。
        引数: self(DiagnosisTests)。返り値: None。
        """
        result=module.diagnose(FixtureReader([empty_scene(n)for n in range(73)]))
        self.assertEqual((result['取得場数'],len(result['未取得場']),result['物理平均毎h']),(0,73,0))
        self.assertIsNone(result['先着率']);self.assertIsNone(result['IFD損益'])
        self.assertIn('先着率・損益はnull',module.short_report(result))

    def test_未知でも形状全分母の位置を残す(self) -> None:
        """
        機能: Hist未知を不成立0へ埋めずBB/位置の別分母を求める。
        引数: self(DiagnosisTests)。返り値: None。
        """
        row=module.analyze_scene(known_scene())
        self.assertEqual(row['個別gate']['現在5Hist実改善'],{'分母':1,'known':0,'成立':0,'不成立':0,'未知':1})
        self.assertEqual(row['技術完成'],0);self.assertEqual(row['説明順累積']['p中位EMA帯接触'],1)
        self.assertEqual(row['形状窓全件への別幾何診断']['Last全位置']['成立'],1)
        self.assertEqual(row['p初Context既知']['hist_delta5']['known'],0)

    def test_BB正本と未来参照を拒否(self) -> None:
        """
        機能: 当時window結合の値差・20本欠損・未来原行を拒否する。
        引数: self(DiagnosisTests)。返り値: None。
        """
        for which in ('BB差','本数','未来'):
            scene=copy.deepcopy(known_scene())
            if which=='BB差':scene['bars'][0]['context']['bb15']={**scene['bars'][0]['context']['bb15'],'mean':996}
            if which=='本数':scene['bb_windows'][0]['refs'].pop(0)
            if which=='未来':scene['bars'][0]['context']['refs'][0]['delivered']['index']=999
            with self.assertRaises(AssertionError):module.analyze_scene(scene)

    def test_一物理取得と代表不一致(self) -> None:
        """
        機能: 全成立票と取得groupを一物理で結び二重加算を防ぐ。
        引数: self(DiagnosisTests)。返り値: None。
        """
        scene=known_scene();check=scene['checks'][1]
        check['gates']['現在5Hist実改善']={'known':True,'value':1};check['reasons']=[];check['status']='birth_eligible'
        p,r=scene['bars'];q=copy.deepcopy(r['context']['at']);q['time']+=1;q['index']+=1;q['source_line']+=1
        scene['events']=[{'id':'e','family':'T0','width_seconds':60,'status':'filled','side':1,'group_id':'g','arm':module.ref(p['bar']),
            'confirm':module.ref(r['bar']),'entryQuote':q,'trace':[]}]
        scene['groups']=[{'id':'g','side':1,'status':'filled','candidate_ids':['e'],'filled_candidate_ids':['e'],'representative_id':'e','entryQuote':q}]
        row=module.analyze_scene(scene);self.assertEqual((row['候補数'],row['技術完成'],row['物理取得数']),(1,1,1))
        bad=copy.deepcopy(scene);bad['groups'][0]['representative_id']='別物'
        with self.assertRaises(AssertionError):module.analyze_scene(bad)

    def test_売買鏡像と共通価格域なし(self) -> None:
        """
        機能: 固定価格位置を鏡像にしBB中心からの余地を別に確認する。
        引数: self(DiagnosisTests)。返り値: None。
        """
        s=known_scene();p,r=s['bars'];q=r['context']['at'];buy=module.geometry(p,r,q)
        p2,r2=copy.deepcopy(p),copy.deepcopy(r)
        for bar in (p2,r2):
            old=bar['bar']['ohlc'];bar['bar']['ohlc']={'open':2000-old['open'],'high':2000-old['low'],'low':2000-old['high'],'close':2000-old['close']}
            old=bar['context']['bb15'];bar['context']['bb15']={**old,'mean':2000-old['mean'],'upper':2000-old['lower'],'lower':2000-old['upper']}
            bar['context']['direction30']=-1
        sell=module.geometry(p2,r2,{**q,'last':2000-q['last']});self.assertEqual(buy,sell)
        p['context']['bb15']={**p['context']['bb15'],'mean':1050,'upper':1150,'lower':950,'sigma':50}
        result=module.geometry(p,r,q);self.assertTrue(result['Kから順端125以上']);self.assertFalse(result['BB中心から順端125以上']);self.assertFalse(result['固定全条件の共通価格域あり'])

    def test_CLI不正SHAは価格I_Oより前に拒否(self) -> None:
        """
        機能: 明示SHAの不備でSource読取や出力を開始しない。
        引数: self(DiagnosisTests)。返り値: None。
        """
        with tempfile.TemporaryDirectory()as name:
            target=Path(name)/'未作成';run=subprocess.run([sys.executable,str(HERE/'診断する.py'),'--source',str(Path(name)/'存在しない'),
                '--sha256','不正','--output-dir',str(target)],capture_output=True)
            self.assertNotEqual(run.returncode,0);self.assertFalse(target.exists())


if __name__=='__main__':
    unittest.main(verbosity=2)
