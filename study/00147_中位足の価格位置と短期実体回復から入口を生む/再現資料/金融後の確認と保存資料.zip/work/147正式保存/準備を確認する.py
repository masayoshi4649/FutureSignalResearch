"""147の保存器を自然入力なしで準備確認し、固定前保存を実行しない。"""
from pathlib import Path
import json
import subprocess
import sys
from 保存部品 import ROOT,sha,json_bytes,registries

HERE=Path(__file__).resolve().parent


def main() -> None:
    """
    機能: 一時人工・compile・CLI必須指定・旧保存源不変を検査して準備票を保存する。
    引数: なし。
    返り値: None。自然F0/F1・金融・Source・正式3MDは開かず保存もしない。
    """
    old=ROOT/'work/146正式保存'
    before={p.name:sha(p.read_bytes()) for p in old.glob('*.py')}
    inputs,codes=registries()
    expected={
        'work/145構造イベントの評価/固定入力/固定取得入力.json':'d2becb3b1d6de656a6cc3f04d576d95d99693dfc42efc03582ed04d2be8784e8',
        'work/145構造イベントの評価/固定入力/入口参照.json':'3a3a144c478fa45f85e03ad4b8e4461e420592da24088458c7aa1cb748c8eb8d',
        'work/145構造イベントの評価/金融評価/集計.json':'fb374d53982ce7727c5ae936d72a20a973029de35480ed442a6cb2305fc9c861',
        'work/145構造イベントの評価/固定取得の正逆観測.json':'3b92da8b447d7be9ead6a2a112759ca7272a1e65d6cb5516989e3faf50c54d62'}
    assert all(inputs[name]['解凍SHA256']==h for name,h in expected.items())
    assert '30bd4aef8c2809699cb013f930cfbce152f3986fe8d3d3cc6b49452104c2269e' in codes
    run=subprocess.run([sys.executable,'-X','utf8',str(HERE/'保存の人工検査.py')],text=True,encoding='utf8',capture_output=True)
    assert run.returncode==0,run.stdout+run.stderr
    artificial=json.loads(run.stdout);assert artificial['成功'] and artificial['人工群']==5
    scripts=list(HERE.glob('*.py'))
    compiled=subprocess.run([sys.executable,'-m','py_compile',*[str(p) for p in scripts]],capture_output=True)
    assert compiled.returncode==0,compiled.stderr.decode('utf8','replace')
    required=[]
    for name in ('F0原文を保管する.py','F1の追加資料を保管する.py','金融正本を保管する.py','保存観測から再集計する.py'):
        cli=subprocess.run([sys.executable,'-X','utf8',str(HERE/name)],text=True,encoding='utf8',capture_output=True)
        assert cli.returncode==2
        required.append({'CLI':name,'必須指定拒否':True})
    assert before=={p.name:sha(p.read_bytes()) for p in old.glob('*.py')}
    value={'成功':True,'試行':147,'状態':'F0原文読取前・保存器準備を停止','人工':artificial,'compile':True,'CLI':required,
        '可変F0/F1件数':True,'旧145の4対照源を恒久索引だけで解決':expected,
        '準備源':{p.name:sha(p.read_bytes()) for p in scripts+[HERE/'保存の準備.md']},
        '旧146保存器前後不変':before,'自然F0/F1/Source/金融/Raw/価格CSV/追加2場読取':False,'正式3MD変更':False,
        '生成入力/観測の保存実行':False,'実金融再集計':'Root F1/結果完了通知後だけ実行','重大不足':[]}
    p=HERE/'準備の確認.json';p.write_bytes(json_bytes(value))
    print(json.dumps({'成功':True,'準備SHA256':sha(p.read_bytes()),'人工群':5,'CLI必須拒否':len(required),'重大不足':[]},ensure_ascii=False))


if __name__=='__main__':main()
