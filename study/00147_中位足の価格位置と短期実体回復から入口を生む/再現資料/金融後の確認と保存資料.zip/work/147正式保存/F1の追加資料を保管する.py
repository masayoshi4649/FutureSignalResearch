"""RootのF1通知後にだけ147増分と生成入力を保存する。"""
from pathlib import Path
import argparse
from 保存部品 import f1


def main() -> None:
    """
    機能: 明示path/SHAと3生成入力を段階保存器へ渡す。
    引数: --f1/--source/--fixed-input/--metadata(Path)、--sha256(str)、--extra(list[Path])。
    返り値: None。
    """
    p=argparse.ArgumentParser()
    for name in ('f1','source','fixed-input','metadata'):p.add_argument('--'+name,required=True,type=Path)
    p.add_argument('--sha256',required=True);p.add_argument('--extra',action='append',type=Path,default=[]);a=p.parse_args()
    f1(a.f1.resolve(),a.sha256,a.source.resolve(),a.fixed_input.resolve(),a.metadata.resolve(),[p.resolve() for p in a.extra])


if __name__=='__main__':main()
