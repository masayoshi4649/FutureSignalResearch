"""147の保存Sourceだけによる非金融段階票を恒久保存する。"""
import gzip
import json
from 保存部品 import ROOT,FORMAL,sha,save,write,json_bytes


def main() -> None:
    """
    機能: 停止したSource診断の短報/要約/gzip/証跡を原文不変で保存する。
    引数: なし。
    返り値: None。Source/固定122/Raw/金融/正式3MDを再読・再計算しない。
    """
    folder=ROOT/'work/147中位実体回復の非金融診断';stop=folder/'停止の確認.json'
    assert sha(stop.read_bytes())=='8f3ddedba06946bebe39b6bb82abf0ab8537eb3d233ea5110f9a7410d6c6895b'
    proof=json.loads(stop.read_bytes());assert proof['成功'] and proof['編集停止'] and not proof['自然金融_Raw_CSV_追加2場読取']
    for item in proof['成果']:assert sha((ROOT/item['path']).read_bytes())==item['sha256']
    save(stop,FORMAL/'検査/中位回復非金融診断の停止.json',sha(stop.read_bytes()))
    source=folder/'結果/診断の確認.json';save(source,FORMAL/'検査/中位回復段階の確認.json',sha(source.read_bytes()))
    p=FORMAL/'保管索引.json';m=json.loads(p.read_bytes())
    m['中位回復非金融要約']=save(folder/'結果/要約.json',FORMAL/'根拠/中位回復_要約.json','af0a02a9ad6215c7871e80746ed746b045671ef8c0597d9cd8e7a8c65b31d87e')
    gz=folder/'結果/全73場の中位回復段階.json.gz';raw=gzip.decompress(gz.read_bytes());assert len(raw)==proof['詳細解凍']['bytes'] and sha(raw)==proof['詳細解凍']['sha256']
    m['中位回復非金融詳細']=save(gz,FORMAL/'根拠/全73場の中位回復段階.json.gz','87c46865652bdafdf1cdada6c428d5475f487a7672dcf296dd148adb4e4cc642')
    m['中位回復非金融詳細']['内部gzipの解凍SHA256']=sha(raw)
    report=folder/'どこで細ったか.md';assert sha(report.read_bytes())=='5741ff34c8f70ba910f1ea55a3ba5ae5acbd76482b8b80d43f70e36f35fd5561'
    body=report.read_text('utf8')+'\n恒久先: [要約](中位回復_要約.json)、[全73詳細gzip](全73場の中位回復段階.json.gz)、[診断確認](../検査/中位回復段階の確認.json)、[停止票](../検査/中位回復非金融診断の停止.json)。作者原短報/条件/コードは[後発ZIP](../再現資料/金融後の確認と保存資料.zip)へ保存する。\n'
    write(FORMAL/'根拠/どこで細ったか.md',body.encode('utf8'))
    m['非金融診断停止SHA256']=sha(stop.read_bytes());m['非金融原短報SHA256']=sha(report.read_bytes());p.write_bytes(json_bytes(m))
    print(json.dumps({'成功':True,'非金融段階を金融と分離':True,'plain詳細/元Source新複写':False},ensure_ascii=False))


if __name__=='__main__':main()
