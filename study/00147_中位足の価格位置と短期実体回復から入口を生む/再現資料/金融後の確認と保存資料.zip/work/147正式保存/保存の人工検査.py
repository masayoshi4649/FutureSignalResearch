"""147保存器を一時作業rootの架空F0/F1だけで検査する。自然資料を開かない。"""
from pathlib import Path
import gzip
import importlib.util
import json
import subprocess
import sys
import tempfile
import 保存部品 as M

HERE=Path(__file__).resolve().parent


def main() -> None:
    """
    機能: snapshot/共有/新小ZIP/非複製/生成gzip/復元を人工で検査する。
    引数: なし。
    返り値: None。実repositoryの正式147・自然Source/金融は変更・読取しない。
    """
    original_root=M.ROOT;original_formal=M.FORMAL;original_inputs=M.INPUTS;original_registry=M.registries
    inputs,codes=original_registry();assert '30bd4aef8c2809699cb013f930cfbce152f3986fe8d3d3cc6b49452104c2269e' in codes
    tests=['既存索引metadataだけからRoot141calculateの共有参照解決']
    with tempfile.TemporaryDirectory(prefix='人工保存_',dir=HERE) as temporary:
        root=Path(temporary);formal=root/'study/00147_中位足の価格位置と短期実体回復から入口を生む';own=root/'work/人工147実行先'
        M.ROOT=root;M.FORMAL=formal;M.INPUTS=root/'inputs/00147_中位価格位置と実体回復'
        def put(path: Path, raw: bytes) -> None:
            """
            機能: 架空rootだけへ人工原文を書く。
            引数: path(Path)、raw(bytes)。
            返り値: None。
            """
            assert path.is_relative_to(root);path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
        prior=root/'study/00138_人工の共有参照/保管索引.json';put(prior,M.json_bytes({'後段再現用の継承源':{'人工':True}}))
        documents=[formal/n for n in ('README.md','条件.md','設定と結果.md')]
        for p in documents:put(p,('# 人工原文 '+p.name+'\r\n').encode('utf-8'))
        small=root/'work/人工源.py';put(small,'"""人工コード。実行しない。"""\n'.encode())
        big=root/'work/122全場入力/入力.json';put(big,'同じpathを持つ小さい人工参照。実177MBではない。'.encode())
        binary=root/'work/人工.exe';put(binary,'人工exe'.encode('utf-8'))
        shared=root/'work/人工共有.json';packed=root/'inputs/人工共有.json.gz';body=M.json_bytes({'人工':True,'値':3});put(shared,body);put(packed,gzip.compress(body,mtime=0))
        descriptor={'保存元':packed.relative_to(root).as_posix(),'復元先':shared.relative_to(root).as_posix(),'形式':'gzip','保存SHA256':M.sha(packed.read_bytes()),'解凍SHA256':M.sha(body)}
        M.registries=lambda:({descriptor['復元先']:descriptor},{})
        files={str(p):M.sha(p.read_bytes()) for p in documents+[small,big,binary,shared]}
        f0=own/'F0人工前.json';put(f0,M.json_bytes({'試行':147,'人工':True,'ファイル':files}));M.f0(f0,M.sha(f0.read_bytes()))
        m=json.loads((formal/'保管索引.json').read_bytes());assert len(m['F0復元参照']['意図して非複製'])==2
        assert len(m['F0復元参照']['共有入力'])==1 and m['F0文書原文']['正式文書数']==3
        tests.append('正式3MDのCRLF原文snapshot/小ZIP/共有gzip/巨大入力exeの非複製分類')
        source=own/'Source.json';fixed=own/'固定入力.json';meta=own/'参照.json';extra=own/'確認.json'
        for p in (source,fixed,meta,extra):put(p,M.json_bytes({'人工':True,'kind':p.name}))
        updated={**files,**{str(p):M.sha(p.read_bytes()) for p in (f0,source,fixed,meta,extra)}}
        f1=own/'F1人工前.json';put(f1,M.json_bytes({'試行':147,'人工':True,'ファイル':updated}))
        M.f1(f1,M.sha(f1.read_bytes()),source,fixed,meta,[extra])
        m=json.loads((formal/'保管索引.json').read_bytes());assert len(m['新共用入力'])==3 and m['F1直接源数']==len(updated)
        for d in m['新共用入力']:assert M.sha(gzip.decompress((root/d['保存元']).read_bytes()))==d['解凍SHA256']
        tests.append('可変源数F1増分/Source固定meta各一度gzip/明示確認票を保存')
        snapshot=json.loads(gzip.decompress((formal/'検査/F0実行前文書.json.gz').read_bytes()))
        assert all(d['本文'].encode('utf-8')==(root/d['path']).read_bytes() for d in snapshot['文書'])
        # 結果追記後でも復元に使うのは現MDでなく固定原文です。
        for p in documents:put(p,p.read_bytes()+'\n人工の結果追記\n'.encode())
        result=own/'観測.json';put(result,M.json_bytes({'人工':True,'success':True}))
        m['保存済み正逆観測']=M.save(result,formal/'成果物/固定取得の正逆観測.json.gz',M.sha(result.read_bytes()),True)
        put(formal/'保管索引.json',M.json_bytes(m))
        script=formal/'再現資料/保存観測から再集計する.py';put(script,(HERE/'保存観測から再集計する.py').read_bytes())
        run=subprocess.run([sys.executable,'-X','utf8',str(script),'--destination','work/人工復元'],capture_output=True,text=True,encoding='utf-8')
        assert run.returncode==0,run.stdout+run.stderr
        restored=root/'work/人工復元';proof=json.loads((restored/'保存観測からの再現確認.json').read_bytes())
        assert proof['固定源数']==len(updated) and proof['保存bytes復元数']==len(updated)-2
        for d in snapshot['文書']:assert M.sha((restored/d['path']).read_bytes())==d['sha256']
        tests.append('現在MD結果追記後も固定原文を復元/可変源数と非複製を区別')
        try:M.save(source,M.INPUTS/'Sourceの出生と取得.json.gz',M.sha(source.read_bytes()),True)
        except FileExistsError:pass
        else:raise AssertionError('生成入力を上書きしました')
        tests.append('一度保存済みの生成gzipを上書きしない')
    M.ROOT=original_root;M.FORMAL=original_formal;M.INPUTS=original_inputs;M.registries=original_registry
    print(json.dumps({'成功':True,'人工群':len(tests),'人工':tests,'自然JSON/Raw/金融/正式147操作':False,'金融再現は実F1後に実行':True},ensure_ascii=False))


if __name__=='__main__':main()
