"""147のRoot別算術/CSVと保存観測再現を恒久保存する。正式3MDは変更しない。"""
from pathlib import Path
import json
from 保存部品 import ROOT,FORMAL,INPUTS,sha,save,write,json_bytes


def main() -> None:
    """
    機能: 金融完了通知後の小証跡を指紋照合し一度保存する。
    引数: なし。
    返り値: None。新金融/Raw/Source/CSVを生成しない。
    """
    own=ROOT/'work/147中位実体回復の評価';csv=ROOT/'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/147_中位位置と実体回復'
    p=FORMAL/'保管索引.json';m=json.loads(p.read_bytes())
    files=[(own/'出生の完了.json','出生の完了.json'),(own/'観測の完了.json','観測の完了.json'),
        (own/'転送の完了.json','転送の完了.json'),(own/'集計の完了.json','集計の完了.json'),
        (own/'金融評価/集計完了.json','集計器の完了.json'),(own/'金融別算術の確認.json','金融別算術の確認.json'),
        (own/'CSV独立再読.json','CSV全セルの独立再読.json'),(csv/'CSVの確認.json','CSV作成の確認.json'),
        (ROOT/'work/147保存観測の再現確認/保存観測からの再現確認.json','保存観測からの再現確認.json')]
    for source,name in files:save(source,FORMAL/'検査'/name,sha(source.read_bytes()))
    separate=json.loads((FORMAL/'検査/金融別算術の確認.json').read_bytes())
    assert separate['成功'] and separate['比較数']==300 and separate['主要統計セル']==7200
    assert sha((FORMAL/'検査/金融別算術の確認.json').read_bytes())=='8edb60a4c3cc50c87159b7d19edc28d5ef55a58ed1afda6832938c1018875789'
    reader=json.loads((FORMAL/'検査/CSV全セルの独立再読.json').read_bytes())
    assert reader['成功'] and reader['全データセル比較数']==20529 and reader['数値比較数']==13236
    m['CSV正本']=csv.relative_to(ROOT).as_posix();m['CSV_SHA256']={Path(t['CSV']['path']).name:t['CSV']['sha256'] for t in reader['表別']}
    for name,h in m['CSV_SHA256'].items():assert sha((csv/name).read_bytes())==h
    m['金融別算術SHA256']=sha((FORMAL/'検査/金融別算術の確認.json').read_bytes())
    m['保存観測再現SHA256']=sha((FORMAL/'検査/保存観測からの再現確認.json').read_bytes())
    assert m['保存観測再現SHA256']=='159cc908aa10f3c281c1ffe73006deed6bc1f3ce5a31dc25492795e8ee1c19f2'
    source=ROOT/'work/147正式保存/保存観測から再集計する.py'
    m['再集計器']=save(source,FORMAL/'再現資料/保存観測から再集計する.py',sha(source.read_bytes()))
    previous=json.loads(next((ROOT/'study').glob('00145_*/保管索引.json')).read_bytes())
    m['金融後の共有コード']=previous['金融後の共有コード']
    m['段階']='固定前原文/全81源/Source固定meta/観測/金融/Root別算術/CSV/保存再集計を保存。結果文書と非金融追補は後続'
    p.write_bytes(json_bytes(m))
    write(INPUTS/'README.md',('# 147の中位価格位置と実体回復の共用入力\n\nSource・固定取得・入口参照を各一度gzip保存。元bytes/圧縮指紋と復元先は[保管索引](../../study/'+FORMAL.name+'/保管索引.json)を参照する。Sourceの重複した価格参照を圧縮して保持し、原板・177MB派生・実行体は複製しない。\n').encode('utf8'))
    print(json.dumps({'成功':True,'300別算術/7200セル':True,'CSV20529/13236':True,'保存観測再現SHA256':m['保存観測再現SHA256']},ensure_ascii=False))


if __name__=='__main__':main()
