"""147の結果/診断/接続確認/保存器を、固定前源と区別して恒久保存する。"""
from pathlib import Path
import json
import zipfile
from 保存部品 import ROOT,FORMAL,sha,save,write,json_bytes


def main() -> None:
    """
    機能: 全担当停止後の小成果を一度保存し、F0/F1内の同体源は重ねて格納しない。
    引数: なし。新5診断の保存指示は停止後の別JSON。
    返り値: None。正式3MD/Source/旧結果を変更しない。
    """
    own=ROOT/'work/147正式保存';p=FORMAL/'保管索引.json';m=json.loads(p.read_bytes())
    sources=[q for q in own.glob('*.py') if q.name!='保存観測から再集計する.py']+[own/'保存の準備.md',own/'準備の確認.json']
    for folder,names in {
        '147接続の独立準備レビュー':['確認する.py','準備の確認.json'],
        '147転送の準備':['準備の確認.json'],
        '147中位位置の金融集計':['準備の確認.json'],
        '147中位実体回復の非金融診断':['診断する.py','人工検査.py','条件と分母.md','準備の確認.json','どこで細ったか.md','結果/段階と分母の短報.md'],
        '147正式結果を反映する':['更新する.py','確認する.py','結果草稿.md','Source要点.md','文書反映の確認.json','停止の確認.json'],
    }.items():sources += [ROOT/'work'/folder/name for name in names]
    sources += [ROOT/'work/147公表証拠cacheの準備確認.json',ROOT/'work/147正式文書の準備確認.json',ROOT/'work/147正式文書を準備する.py']
    result=ROOT/'work/147正式結果を反映する'
    for source,target in [(result/'文書反映の確認.json','結果文書の確認.json'),(result/'停止の確認.json','結果文書の停止.json'),
        (ROOT/'work/147中位実体回復の評価/CSV表示の目視確認.json','CSV表示の目視確認.json')]:save(source,FORMAL/'検査'/target,sha(source.read_bytes()))
    instruction=own/'金融診断の保存指示.json';extra=json.loads(instruction.read_bytes());assert extra['停止済み'] and extra['条件変更なし']
    m['新5金融事後診断']=[]
    for item in extra['同体保存']:
        source=ROOT/item['元'];m['新5金融事後診断'].append(save(source,FORMAL/item['先'],item['sha256'],item.get('gzip',False)))
    for item in extra['本文リンク調整']:
        source=ROOT/item['元'];raw=source.read_bytes();assert sha(raw)==item['sha256'];body=raw.decode('utf8')
        for a,b in item['置換'].items():body=body.replace(a,b)
        target=FORMAL/item['先'];write(target,body.encode('utf8'));m['新5金融事後診断'].append({'保存元':target.relative_to(ROOT).as_posix(),'保存SHA256':sha(target.read_bytes()),'原文SHA256':item['sha256'],'変更は恒久リンクのみ':True})
    sources += [ROOT/name for name in extra['小ZIP']]+[instruction]
    frozen={}
    for name in ('検査/F0出生前.json','検査/F1金融前.json'):frozen.update(json.loads((FORMAL/name).read_bytes())['ファイル'])
    entries=[];excluded=[];seen=set();zp=FORMAL/'再現資料/金融後の確認と保存資料.zip'
    with zipfile.ZipFile(zp,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for source in sorted(sources):
            raw=source.read_bytes();name=source.relative_to(ROOT).as_posix();assert len(raw)<1_000_000
            if name in seen:continue
            seen.add(name)
            if str(source.resolve()) in frozen:
                assert frozen[str(source.resolve())]==sha(raw);excluded.append({'復元先':name,'sha256':sha(raw),'既存F0/F1へ保存済み':True});continue
            archive.writestr(name,raw);entries.append({'復元先':name,'ZIP内path':name,'bytes':len(raw),'sha256':sha(raw)})
    with zipfile.ZipFile(zp) as archive:
        for item in entries:assert sha(archive.read(item['ZIP内path']))==item['sha256']
    m['金融後の小資料']={'保存元ZIP':zp.relative_to(ROOT).as_posix(),'ZIP_SHA256':sha(zp.read_bytes()),'格納源数':len(entries),'格納源':entries,'金融前固定への後付け':False}
    m['後発源のF0/F1同体重複除外']=excluded;m['正式結果文書確認SHA256']=sha((FORMAL/'検査/結果文書の確認.json').read_bytes())
    m['金融後正式文書SHA256']={name:sha((FORMAL/name).read_bytes()) for name in ('README.md','条件.md','設定と結果.md','閲覧資料.md')}
    m['段階']='F0/F1原文/全68参照/金融/Source段階/新5事後/再集計/CSV/文書を保存。最終確認待ち'
    p.write_bytes(json_bytes(m));print(json.dumps({'成功':True,'後発ZIP_SHA256':m['金融後の小資料']['ZIP_SHA256'],'格納源数':len(entries),'F0/F1内重複除外':len(excluded)},ensure_ascii=False))


if __name__=='__main__':main()
