"""147の保存指紋・正式文書・分母・リンクを最終確認する。新金融は実行しない。"""
from pathlib import Path
import gzip
import json
import re
import zipfile
from urllib.parse import unquote
from 保存部品 import ROOT,FORMAL,sha,json_bytes,write


def documents(raw: bytes) -> dict:
    """
    機能: gzip退避原文から復元先と本文を引く。
    引数: raw(bytes)はgzipJSON。
    返り値: dict[str,str]は原文。
    """
    return {item['path']:item['本文'] for item in json.loads(gzip.decompress(raw))['文書']}


# ----------------------------------------
def main() -> None:
    """
    機能: 保存済み証跡のみを照合し、成功時だけ編集停止票を作る。
    引数: なし。
    返り値: None。Source/Raw/価格CSV/新金融/旧成果を変更しない。
    """
    mpath=FORMAL/'保管索引.json';m=json.loads(mpath.read_bytes())
    checks=[];seen=set();archive_count=0;stored_count=0
    def inspect(item: object) -> None:
        """
        機能: 保存台帳を再帰してZIPとgzip/同体の指紋を確認する。
        引数: item(object)は台帳の任意要素。
        返り値: None。
        """
        nonlocal archive_count,stored_count
        if isinstance(item,list):
            for value in item:inspect(value)
        if not isinstance(item,dict):return
        if '保存元ZIP' in item and 'ZIP_SHA256' in item:
            p=ROOT/item['保存元ZIP'];key=(str(p),item['ZIP_SHA256'])
            if key not in seen:assert sha(p.read_bytes())==item['ZIP_SHA256'];seen.add(key);archive_count+=1
            entries=item.get('格納源',[item] if 'ZIP内path' in item else [])
            with zipfile.ZipFile(p) as saved:
                for entry in entries:assert sha(saved.read(entry.get('ZIP内path',entry.get('path'))))==entry['sha256']
        if 'ZIP' in item and 'ZIP_SHA256' in item and '格納源' in item:
            p=FORMAL/'再現資料'/item['ZIP'];key=(str(p),item['ZIP_SHA256'])
            if key not in seen:assert sha(p.read_bytes())==item['ZIP_SHA256'];seen.add(key);archive_count+=1
            with zipfile.ZipFile(p) as saved:
                for entry in item['格納源']:assert sha(saved.read(entry.get('ZIP内path',entry.get('path'))))==entry['sha256']
        if all(k in item for k in ('保存元','保存SHA256')):
            p=ROOT/item['保存元'];key=(str(p),item['保存SHA256'])
            if key not in seen:assert sha(p.read_bytes())==item['保存SHA256'];seen.add(key);stored_count+=1
            if '解凍SHA256' in item:
                raw=p.read_bytes();raw=gzip.decompress(raw) if item.get('形式')=='gzip' else raw
                assert sha(raw)==item['解凍SHA256']
        for value in item.values():inspect(value)
    inspect(m)
    for stage,expected in [('F0','50a3b62c2bf202ddce5916d11f1eb6b983f1af78c2b0320eea072c3cb2285af8'),('F1','8a858d589515a61582ffef45df887925787bc6a663150714ae4e6de7fa62a022')]:
        assert sha((FORMAL/('検査/F0出生前.json' if stage=='F0' else '検査/F1金融前.json')).read_bytes())==expected
    f0=json.loads((FORMAL/'検査/F0出生前.json').read_bytes());f1=json.loads((FORMAL/'検査/F1金融前.json').read_bytes())
    assert len(f0['ファイル'])==57 and len(f1['ファイル'])==68
    assert all(f1['ファイル'].get(name)==value for name,value in f0['ファイル'].items())
    before=documents((FORMAL/'検査/F0実行前文書.json.gz').read_bytes())
    condition=(FORMAL/'条件.md').read_text('utf8');prefix=before[FORMAL.relative_to(ROOT).as_posix()+'/条件.md']
    assert condition.startswith(prefix)
    old=before[FORMAL.relative_to(ROOT).as_posix()+'/設定と結果.md'];current=(FORMAL/'設定と結果.md').read_text('utf8')
    rows=lambda body:[line for line in body.splitlines() if re.match(r'^\| [A-Z]\d{2} \|',line)]
    assert rows(old)==rows(current) and len(rows(current))==57
    for row in rows(current):assert len(row.split('|')[3:-1])==9
    stop=json.loads((FORMAL/'検査/結果文書の停止.json').read_bytes())
    assert stop['成功'] and stop['元条件prefix完全同体'] and stop['版7全513セル文字同体']
    for item in stop['正式3MD']:assert sha((ROOT/item['path']).read_bytes())==item['sha256']
    summaryraw=(FORMAL/'成果物/集計.json').read_bytes();assert sha(summaryraw)=='afcef5ac1b72567cd7512c5818d2f832c77d0a93fdab07a8d7869b2ada167750'
    summary=json.loads(summaryraw);primary=summary['主評価'];assert summary['成功']
    assert [primary[k] for k in ('順','逆','未到達','全H不足')]==[44,19,23,6]
    assert primary['到達済み率']==44/63 and not primary['到達済み先着70%以上'] and primary['全73場最低1取得'] and not primary['三項目すべて達成']
    assert abs(primary['全時間平均件数毎時']-.12761530458906487)<1e-15
    stats=summary['集計']['all']['U0']['BBO']['3600']['125']
    assert [stats[k] for k in ('entries','ifd_known','ifd_unknown','ifd_net5_profit','ifd_net5_loss','ifd_net5_sum')]==[92,89,3,568842,365695,203147]
    assert summary['取得集合数']=={'C0':81,'C1':87,'T0':5,'U0':92}
    assert summary['旧C0同体']['成功'] and summary['旧C1同体']['成功'] and summary['union']['同原行aliasで除いた取得数']==0
    assert m['Root独立4群の固定区分']['F0直接源'] and m['Root独立4群の固定区分']['源数']==5
    funnel=json.loads((FORMAL/'検査/中位回復非金融診断の停止.json').read_bytes());assert funnel['成功'] and funnel['編集停止'] and not funnel['自然金融_Raw_CSV_追加2場読取']
    assert m['新5金融事後診断']
    separate=json.loads((FORMAL/'検査/金融別算術の確認.json').read_bytes());assert separate['成功'] and separate['比較数']==300 and separate['主要統計セル']==7200
    replay=json.loads((FORMAL/'検査/保存観測からの再現確認.json').read_bytes());assert replay['成功'] and replay['固定源数']==68 and replay['保存bytes復元数']==65 and len(replay['非複製'])==3
    assert replay['全300/参加頻度/union/phase/旧C0/C1同体'] and replay['三表JSON全bytes同体']
    reader=json.loads((FORMAL/'検査/CSV全セルの独立再読.json').read_bytes());assert reader['成功'] and reader['全データセル比較数']==20529 and reader['数値比較数']==13236
    visual=json.loads((FORMAL/'検査/CSV表示の目視確認.json').read_bytes());assert visual['成功'] and visual['試行']==147 and len(visual['三画像'])==3
    assert all((ROOT/m['CSV正本']/name).is_file() for name in visual['三画像'])
    for name,h in m['CSV_SHA256'].items():assert sha((ROOT/m['CSV正本']/name).read_bytes())==h
    # ----------------------------------------
    # 予定最終票自身だけは作成前なので存在判定を保留し、全ての他のリンクを確認する。
    count=0;missing=[];target=FORMAL/'検査/正式保存の最終確認.json'
    pages=list(FORMAL.rglob('*.md'))+[ROOT/m['CSV正本']/'README.md',ROOT/'inputs/00147_中位価格位置と実体回復/README.md']
    for page in pages:
        for link in re.findall(r'\]\(([^)]+)\)',page.read_text('utf8')):
            value=link.split('#',1)[0].strip('<>')
            if not value or re.match(r'^[a-zA-Z]+://',value):continue
            resolved=(page.parent/unquote(value)).resolve();count+=1
            if resolved!=target.resolve() and not resolved.exists():missing.append({'本文':str(page.relative_to(ROOT)),'先':link})
    assert not missing,missing
    for index in ('study/README.md','docs/README.md','docs/議論/README.md'):
        assert FORMAL.name in (ROOT/index).read_text('utf8')
    m['段階']='正式保存完了・編集停止。F0/F1原文/全68参照/65保存bytes/生成入力/観測/金融/CSV/Root4群F0内/Source段階/新5事後/再集計を確認'
    m['最終確認']='検査/正式保存の最終確認.json';m['重大不足']=[];mpath.write_bytes(json_bytes(m))
    report={'成功':True,'試行':147,'編集停止':True,'重大不足':[],
        'F0全57/F1全68の指紋と前段包含':True,'全68復元参照/65保存bytes/非複製3':True,
        '保存ZIP確認数':archive_count,'保存ファイル確認数':stored_count,'原条件prefixと57手法513セル不変':True,
        '結果文書の停止SHA256':sha((FORMAL/'検査/結果文書の停止.json').read_bytes()),'正式4MD_SHA256':m['金融後正式文書SHA256'],
        '主U0':{'全取得':92,'全場':73,'順':44,'逆':19,'未到達':23,'不足':6,'到達済み率':44/63,'頻度毎時':primary['全時間平均件数毎時'],
            '利益C5':568842,'損失C5':365695,'既知差引C5':203147,'IFD既知':89,'IFD未知':3,'共同目標達成':False},
        '全300別算術7200セル':True,'保存観測から全300/三表JSONbytes再現':True,'CSV20529セル13236数値/Root3preview':True,
        'F0内Root4群/Source非金融段階/新5金融事後を分離':True,'ローカルリンク確認数':count,'不足リンク':[],
        '3目次から到達':True,'追加2場/Raw価格CSV新読取':False,'新金融再計算':False,'旧146以前変更':False,
        '保管索引SHA256':sha(mpath.read_bytes()),'再現手順SHA256':sha((FORMAL/'再現手順.md').read_bytes()),
        '後発ZIP_SHA256':m['金融後の小資料']['ZIP_SHA256']}
    write(target,json_bytes(report))
    print(json.dumps({'成功':True,'最終確認SHA256':sha(target.read_bytes()),'保管索引SHA256':report['保管索引SHA256'],'重大不足':[]},ensure_ascii=False))


if __name__=='__main__':main()
