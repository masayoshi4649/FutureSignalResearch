"""147の採用本文と汎用表版7を、自然未実行の正式三文書へ保存する。"""

from pathlib import Path
import hashlib
import json
import posixpath
import re

ROOT=Path(__file__).resolve().parent.parent
DEST=ROOT/'study/00147_中位足の価格位置と短期実体回復から入口を生む'
SPEC=ROOT/'work/147_中位足の価格位置と短期実体回復の採用仕様.md'
TABLE=ROOT/'docs/議論/手法と時間スケールの汎用表_版7.md'
PINS={SPEC:'6bb9c317db1151d31af727b47987530788e5eeee334bcfdd1426f6f93e39624d',
      TABLE:'585d0d9ba69ff3601325e9e6564ede53aeb81b0d33a2da6cb67e20e175187c3d'}


def sha(path: Path) -> str:
    """
    機能: ファイルの保存bytes指紋を取得する。
    引数: path (Path) は既存ファイル。
    返り値: str はSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def relocate(text: str, origin: str) -> str:
    """
    機能: 原文の相対リンク先を保ち、新試行からの参照へ直す。
    引数: text/origin (str) は本文と元の相対ディレクトリ。
    返り値: str はリンク以外同じ本文。
    """
    def replace(match: re.Match) -> str:
        """
        機能: 一つの相対リンクだけを保存先へ移す。
        引数: match (re.Match) はラベルと参照先。
        返り値: str は同じ対象へのリンク。
        """
        target=match.group(2)
        if '://' in target or target.startswith('#'):return match.group(0)
        resolved=posixpath.normpath(posixpath.join(origin,target))
        return '['+match.group(1)+']('+posixpath.relpath(resolved,DEST.relative_to(ROOT).as_posix())+')'
    return re.sub(r'\[([^]]+)\]\(([^)]+)\)',replace,text)


def settings() -> str:
    """
    機能: 57手法×9尺度を保持し、T/P/X/Eの複合設定を記載する。
    引数: なし。固定版7を参照する。
    返り値: str は全513セルと未実行表のMarkdown。
    """
    scales=('原板・逐次','1分','3分','5分','15分','30分','60分','セッション足','日足')
    used={
        ('I01','5分'):'147T01：p初知EMA8/21帯へp高安接触。短期EMA助走は不要',
        ('I01','30分'):'147T01：p初知/r現在のGapとΔEMA21が同じ非零s、場間増分は既存carry',
        ('I03','5分'):'147T01：現在Hist−同場実前5分Histがs側strict正、宣言Previousを厳密照合',
        ('I05','15分'):'147P01：SMA20±母σ×2、同限月carry/欠分窓切断/20refs正本。p初知M/Fを凍結',
        ('I08','15分'):'147T01：現在sDI差>0、ADX−同場実前ADX>=0。宣言Previous厳密照合、pでは未要求',
        ('I09','1分'):'147T01：TRrを隣接p.Closeから直接計算、TRr<=2*p初知ATR5',
        ('I09','5分'):'147P01：pATR5>0固定。現在TR5<=2*実前ATR5、capはATR5/125−W/BB余地の最小',
        ('C01','5分'):'147T01：MA調整位置＋Hist実改善＋他役割の複合。短期Hist/RSI帯は不使用',
        ('C03','15分'):'147P01/T01：BB相対位置と目標余地を1分回復/量/上位動力と複合。裸接触反転なし',
        ('C04','15分'):'147T01：方向DIと強さADXの役割分離、ADXだけで売買を決めない',
        ('C07','1分'):'147X01：p初Context固定・p/r別配送time/index strict・各Raw最新rだけ',
        ('C07','5分'):'147X01：背景全配送後に現在判定、実前5mの両端refsとknown/有限を保存',
        ('C07','15分'):'147X01：実前15m連続照合とBB20refs正本を分離、未知を後で補完しない',
        ('C07','30分'):'147T01：同限月背景数値carry、形状は当場、30増分の場間由来を残す',
        ('P01','1分'):'147T01：p逆実体→隣接r順実体かつr.Closeがp.Open回復、未確定足不使用',
        ('P02','1分'):'147P01：K=p.Open、I=p/r逆側極値±10をr知得時に初固定、仮I/持続armなし',
        ('P04','1分'):'147T01：上位方向内の新調整と実体回復のみ。新R/長期反転の出生なし',
        ('P05','1分'):'147T01：実体符号と始値回復を隣接確定p/rへ束縛、過去Close取得なし',
        ('P06','原板・逐次'):'147P01：Last/P両方K/cap域・s(P−M)>=0・s(F−P)>=125・risk<=125',
        ('P08','1分'):'147T01：p初知5EMA帯に対する調整→p.Open回復。p高安突破とは別定義',
        ('V01','1分'):'147T01：r/p双方known正、r量>=p量。同足量比でありRVOL5ではない',
        ('B01','原板・逐次'):'147X01：出生別Raw+1秒/最初正常BBO/30秒strict/実PとLastを独立検査',
        ('E01','原板・逐次'):'147E01：C0 subset/C1全87/T0/U0主/RU・300比較、全73/三分母/IFD既知性別',
        ('E01','60分'):'147E01：主実BBO/H60±125、70%/全73min1/平均概ね1hの共同目標を維持',
        ('E02','原板・逐次'):'対象外：利益追尾/実口座は別段階。出生前・未取得の取消は147X01',
    }
    lines=['# 00147：設定と結果（汎用表・版7）','',
        '2026-11-12。採用条件の正式準備。Source実装・人工の完成前で、自然出生/取得・新率/損益は未実行。57手法×9尺度＝513セル。','',
        '147T01=上位方向内の1分実体回復、147P01=固定構造/中位BB位置/125pt余地、147X01=当時Context/実前公表/取得/再準備、147E01=固定5政策評価。単一Tの複合仮説であり、新Rや指標単独の成績ではない。','',
        '| ID | 手法 | '+' | '.join(scales)+' |','| '+' | '.join(['---']*11)+' |']
    ids=[]
    for line in TABLE.read_text(encoding='utf-8').splitlines():
        cells=[x.strip() for x in line.split('|')[1:-1]]
        if len(cells)!=11 or not re.fullmatch('[A-Z][0-9]{2}',cells[0]):continue
        ids.append(cells[0])
        lines.append('| '+' | '.join([cells[0],relocate(cells[1],'docs/議論')]+[used.get((cells[0],s),'未使用・未検証') for s in scales])+' |')
    assert len(ids)==len(set(ids))==57 and all(i in ids and s in scales for i,s in used)
    lines+=['','## 固定設定と未実行結果','',
        '|設定ID|条件の要点|状態|','|---|---|---|',
        '|147T01|p初MA30/EMA5調整位置→r現在MA30/DI15/ADX15/実前5Hist/1分実体/同足量|自然未実行|',
        '|147P01|p初BB15中心M/順側端FとATR5固定、K=p.Open/I=p,r逆側極値±10、cap三上限|自然未実行|',
        '|147X01|実前同場連続/宣言Previous未知非補完・既知不一致error/厳密float64等値/終了Raw新r抑止|実装人工完成前|',
        '|147E01|旧C1全87＋新T0物理union、C0旧81subset、RU旧も全実逆、300比較|新金融未実行|','',
        '|政策|取得集合と方向|新件数/率/金額の状態|','|---|---|---|',
        '|U0 主|C1旧87∪T0新物理、同原行C1優先、全alias保持|未実行|',
        '|RU|U0全件の同時点実BBO反対側、旧C1も反転|未実行|',
        '|T0|新しい単一Tパターンの全適格物理取得|未実行|',
        '|C1|旧145全87をID/Quote/native全保持、旧6件も選別しない|固定87、147同体比較未実行|',
        '|C0|C1内の旧81subset、C1へ二重加算しない|固定81、147同体比較未実行|','',
        '146の新26は旧正本へ全件保持済みだが未採用のため新主baselineへ混ぜない。良かった反転群だけを追加せず、旧146の結果改変と新147仮説の選択を分ける。','',
        '短期EMA/MACD/ATR助走、3分集約、短期Hist絶対符号、RSI、旧strong/T8、RVOL5閾値、VWAP/VWMA、MLは新Tでは未使用。Bankが保持する値と、147が条件へ使う値を分ける。','',
        '到達済み=順/(順+逆)、H完了分母=順/全H完了、全件分母=順/各政策自身の取得数。0分母null、未取得場・未到達・全H不足・金額未知を残す。独立mini1枚100円/pt、往復77円、C5追加1000円、Last金額null。','',
        '全73場最低1、全ザラバ平均概ね1件/時、実BBO/H60±125到達済み70%を別/共同判定する。各場均等化や毎時強制はしない。実口座利益追尾と入口IFD代用を区別し、未実行を0件/0円にしない。[条件](条件.md)、[README](README.md)を参照する。','']
    return '\n'.join(lines)


def main() -> None:
    """
    機能: 最大番号の次に正式147三文書だけを作り、採用本文と513セルを確認する。
    引数: なし。自然価格/Raw/金融/追加2場は開かない。
    返り値: None。旧146と採用源の不変を確認し準備票を保存する。
    """
    assert all(sha(p)==h for p,h in PINS.items())
    numbers=[int(p.name[:5]) for p in (ROOT/'study').iterdir() if p.is_dir() and re.match(r'^\d{5}_',p.name)]
    assert max(numbers)==146 and not DEST.exists()
    prior=ROOT/'study/00146_短期構造の完成パターンで入口を増やす'
    before={str(p.relative_to(ROOT)):sha(p) for p in prior.glob('*.md')}
    original=SPEC.read_text(encoding='utf-8').split('\n',1)[1].strip();adopted=relocate(original,'work')
    plain=lambda s:re.sub(r'\[([^]]+)\]\(([^)]+)\)',r'\1',s)
    assert plain(original)==plain(adopted)
    readme='''# 中位足の価格位置と短期実体回復から入口を生む

試行00147。2026-11-12、採用仕様の正式準備。Source実装・人工完了前で、自然生成・新出生/取得・率/損益は未実行。上位方向内の単一Tから新T0を生み、旧145全87のC1とunion U0を作る。旧C0全81はC1のsubsetとして保護する。

## 仮説と既使用期からの選択

146の新26は先着35%、全体U0も61.25%・0.15674件/時で共同未達だった。B12実逆の8順3逆は事後の少数群で、今回の一般的な反転則にはしない。短期の回復に、上位の動力・相対価格位置・125ptの目標余地を結び付ける新仮説を試す。146新26は旧正本へ全件残し、未採用のため今回の主baselineへ足さない。成功例だけを対照へ取り込むことや、旧結果の改変とは区別する。

この選択自体が既使用データの観察に影響されている。新条件を自然実行前に固定するが、未使用期で発見したとは呼ばない。前48/後25も全期既使用の記述区分であり、独立未知期ではない。

|役割|単一Tの判断|
|---|---|
|30分MA|p初知/r現在でGapとEMA21増分が同じ非零s。上位と逆の新Rは置かない|
|5分MA|逆実体pの高安がp初知の既知EMA8/21帯へ接触。短期EMA助走は使わない|
|15分DI/ADX|r現在でDIはs優勢、ADXは実前15分から非減少。方向と強さを分ける|
|5分MACD|現在Histが実前5分からs側へ改善。絶対符号や短期Histの正転を待たない|
|1分構造/量|隣接p逆実体→r順実体とp.Open回復、r/p既知正量でr量>=p量|
|BB15/値幅|p初知の中心M/順側端Fを固定し、中心の順側で実Pから端まで125ptを残す|

これらは相関した価格情報も含む役割分担で、独立票の数として加点しない。Bollingerの一般的説明は相対価格と別役割の確認を支える教材であり、この具体条件の70%や頻度を実証していない。

## 時計・実前足・正本

固定122背景5/15/30を118Bankへ配送し、146と同じ1分CSVモデルを使う。1分はEnd+60以後の最初採用Rawで知り、当場・確定・価格既知・closed・隣接p/rだけを使う。初配送time/indexの両方がstrict増加した場合だけ成立。同Raw catch-upを過去準備済みにせず、全背景/利用可能1分を配送してから最新rを一回だけ判定する。p初Context未知を後で補完しない。

実前5分Histと実前15分ADXは、同場・同限月・それぞれEnd差300/900の実公表と照合する。両端値はknown/有限、宣言Previousが未知ならgate未知、双方既知の不一致は品質errorで停止。float64へ復号した保存値の厳密等値であり、近似許容差や実前値による未知補完を置かない。30分EMA増分の同限月carryとは参照規約を区別する。

BB15は現公表を含む20終値のSMA20±母σ×2。同場欠分で窓を切り、同限月場間は継承/異限月resetする既存定義を保持する。20元公表refsとBB値は公表ID別canonical正本へ一度保存し、ContextはそのIDを参照できる。現在背景freshと、pに固定した歴史の参照を混同しない。

## 構造・取得・再準備

K=p.Open、I=買min(p.Low,r.Low)−10/売max(p.High,r.High)+10をr知得時に初固定する。完成前の仮I監視や持続armは置かない。W=s(K−I)は0<W<=125。p初知ATR5をAとして、cap=min(A,125−W,s(F−K)−125)を固定し、cap<0は不適格とする。

現在Lastと実Pのそれぞれで0<=s(価格−K)<=cap、s(価格−M)>=0、s(F−価格)>=125を要求し、実PからIまで125以内を確認する。p高安突破を待つ方式とは異なる早期の実体回復で、順側バンドは目標到達の保証でも必ず反転する抵抗でもない。r.Closeへ取得を遡らせない。短期TRはp.Closeから直接求めて2*A以内、現在5分TRは実前ATR5の2倍以内とする二尺度の急変ガードも保持する。

出生別Raw+1秒以降の最初正常BBOを買Ask/売Bidで検査し、不適合を後の好位置まで待ち直さない。TTL=min(birth+30,L)、L=min(force_close,End−3900)で等号拒否。pending中も現在背景/実増分/急変ガードと最新1分のknown/closed/fresh、固定Last位置を監視し、古い既知足へfallbackしない。

Raw開始時pendingがあれば、同Rawで取得/取消/失効しても届いた新rは全て抑止・消費する。次のさらに後の新rから再開し、同r再発注をしない。回数cap/毎時強制は置かず、保有や旧C1の未来取得予定をSourceへ渡さない。

## 政策・費用・共同目標

|政策|固定する取得集合と方向|
|---|---|
|U0 主|C1旧87∪T0新物理取得、同原行・同限月C1優先、全aliasを保存|
|RU|U0全件の同時点実BBO反対側、旧C1も反転|
|T0|新しい単一Tの全適格物理取得、0取得場も残す|
|C1|旧145全87、旧A/B6件の負け/未到達も全保持|
|C0|C1の旧81subset、C1へ二重加算しない|

実BBO/H60/同幅±125の到達済み先着70%以上、全73場最低1、全ザラバ平均概ね1件/時を別判定し共同達成も示す。高頻度場と1回だけの場の偏りを許容し、回数均等化/定時強制/枚数分割で水増ししない。5政策×BBO/Last×H30/H60×5幅×全体/前48/後25＝300比較を保存し、主を後からRUや別幅へ交換しない。

数量は独立mini1枚100円/pt、往復税込77円。追加滑り0とC5追加往復10pt＝1,000円を比較する。到達済み/完了/全件分母率、未到達/全H不足、IFD利益/損失/既知差引/未知を分ける。Last金額null、反対率を1−pでは作らない。実口座の片側10枚・mini板・実IFD・必須利益追尾は未検証で、入口IFD代用とは別段階。

## 固定・再現・限界

[条件](条件.md)に採用本文を相対リンクだけ補正して収録し、[設定と結果](設定と結果.md)に版7全513セルを保存する。F0→全73自然Source→全物理取得/方向/alias固定→F1→凍結133正逆観測→300比較/独立算術/CSV/恒久保存の順で進める。実装人工・自然件数・率/損益の成功をここでは先取りしない。

背景は固定122入力SHA `6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec`、CSV73参照SHA `07e136e2b77a0029ddacd955abad16a9240373fa849ec96b553c2875e1e85147`。旧C1は[145恒久保存](../00145_押戻し完了と失敗突破を別の構造イベントで評価する/保管索引.json)、旧146の不採用取得は[146全正本](../00146_短期構造の完成パターンで入口を増やす/保管索引.json)へ残す。大入力・原板・共用観測を不要に複写しない。

失敗仮説は、上位の動力が遅行している、BB距離が125ptの持続を支えない、条件が再び狭くなる、の三つ。未知/既知不成立と各段階を分け、自然後にcapや余地を緩めない。心理の仮説は上位方向の参加が短期調整後に再開することで、注文目的・参加者の確信は直接観測していない。実receivedAt/ClosedAtやWS完全性は復元しない。追加2場は価格未読、旧146とDocs目次は不変更。
'''
    protocol='# 147：中位位置と短期実体回復の固定条件\n\n2026-11-12。設定147T01/P01/X01/E01。実装・人工完成前、自然出生/取得・新率/金融は未実行。採用仕様SHA `'+PINS[SPEC]+'`。以下は採用本文を相対リンク以外同体で保存する。\n\n## 採用仕様の本文\n\n'+adopted+'\n\n'
    protocol+='''## 因果reviewと記録範囲

- p初知の方向/EMA5/ATR5/BBは保存後に補完しない。DI/ADX・Hist実増分はr現在/pendingの確認条件で、p初知へ同じ要件を勝手に追加しない。
- p/rの市場時刻の隣接と知得のstrict順を分ける。r.Closeへ出生を遡らず、同Raw catch-upを過去準備済みにしない。現在freshは最新公表そのもののknown/closedを含む。
- 実前5/15と宣言Previousがともに既知ならfloat64厳密等値、不一致は品質error。宣言未知はgate未知、実前値で補完しない。30増分とBB窓の跨場継承を混同しない。
- BB20refsはcanonicalに保持し、同IDを窓へ二重投入しない。σ0/未知を過去の良いBBで補完しない。凍結M/F/ATRを現在の好位置へ描き直さない。
- 0<=s(P−K)<=capからrisk=W+s(P−K)<=125。s(F−P)>=125は相対価格帯への拘束で、未来の到達を予測した証拠ではない。Lastと実Pを別に判定する。
- Raw開始時にpendingがある終了Rawも新rを抑止/消費し、同rの再提出や旧C1の未来情報で回数を変えない。独立Sourceへ1場1回の制限を追加しない。
- 旧C1全87/旧C0subsetを保持し、146新26は旧正本へ全件保存したまま新baselineへ混ぜない。146観察を踏まえた選択バイアスを、自然前固定しただけで解消済みとはしない。

到達済み=順/(順+逆)、H完了分母=順/全H完了、全件分母=順/各政策自身の物理取得数。分母0はnull、全73/未取得/未到達/全H不足/金額未知を除外しない。全時間頻度分母はΣ(scene.end−300−scene.start)/3600。名目新規可時間は副、場の単純平均を主平均としない。

政策C0旧81と費用C0追加滑り0は別。独立mini1枚100円/pt・往復77円・C5追加1,000円、Last金額null。H不足でも既知touchのIFD代用は金額既知、未到達清算不能は未知にする。利益追尾・mini実板・片側10枚口座の運用検証は別段階である。

この文書の因果reviewはSource人工/自然件数/目標達成の証跡ではない。新結果が出たら元条件と513セルのF0原文を保存したうえで追記し、結果後の条件変更は新試行へ分ける。
'''
    DEST.mkdir()
    for name,text in (('README.md',readme),('条件.md',protocol),('設定と結果.md',settings())):
        (DEST/name).write_text(text.rstrip()+'\n',encoding='utf-8',newline='\n')
    links=0
    for path in DEST.glob('*.md'):
        for target in re.findall(r'\]\(([^)]+)\)',path.read_text(encoding='utf-8')):
            if '://' not in target and not target.startswith('#'):
                assert (path.parent/target.split('#',1)[0]).resolve().exists(),target
                links+=1
    rows=[line for line in (DEST/'設定と結果.md').read_text(encoding='utf-8').splitlines() if re.match(r'^\| [A-Z]\d{2} \|',line)]
    assert len(rows)==57 and all(len(line.split('|')[3:-1])==9 for line in rows)
    assert all(sha(ROOT/p)==h for p,h in before.items()) and all(sha(p)==h for p,h in PINS.items())
    proof={'成功':True,'試行':147,'確認日':'2026-11-12','最大既存番号':146,'採番':DEST.name,
        '採用本文相対リンク以外同体':True,'採用仕様SHA256':PINS[SPEC],'汎用表SHA256':PINS[TABLE],
        '汎用表':{'版':7,'手法':57,'尺度':9,'全セル':513},'ローカルリンク実在':links,
        '正式3MD':{str(p.relative_to(ROOT)):sha(p) for p in sorted(DEST.glob('*.md'))},
        'review':'pending終了Raw抑止/Previous未知非補完と既知厳密等値をRootへ確認し明文化後の本文へ同体化。初Context/実前refs/BB正本/凍結位置/単一T/既使用選択/旧C1保持を照合、重大未解決なし。',
        '旧146MD前後同体':before,'自然価格Raw金融追加2場読取':False,'Source実装人工完了の主張':False,
        '生成コードSHA256':sha(Path(__file__)),'編集停止':True}
    target=ROOT/'work/147正式文書の準備確認.json';target.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps({'formal':proof['正式3MD'],'proof_sha256':sha(target),'cells':513},ensure_ascii=True))


if __name__=='__main__':
    main()
