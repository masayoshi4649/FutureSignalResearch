"""147のRoot運転・橋渡し・独立算術の接続を自然入力なしで確認する。"""

from pathlib import Path
import ast
import copy
import contextlib
import hashlib
import io
import math
import runpy
import subprocess
import json

ROOT=Path(__file__).resolve().parents[2]
OWN=Path(__file__).resolve().parent
BRIDGE=ROOT/'work/147中位回復と旧87を固定取得へ渡す.py'
TEST=ROOT/'work/147転送の人工検査.py'
DRIVER=ROOT/'work/147出生と金融を分離して実行する.py'
CALC=ROOT/'work/147金融を別算術で確認する.py'
AGG=ROOT/'work/147中位位置の金融集計/集計する.py'
AGG_READY=AGG.parent/'準備の確認.json'
DRIVER_SHA='469852f7c11cb35b6af0d2a23895085611c9262f927df29ac2843bf0b74bafbf'
CALC_SHA='62bb02e825e65d0d3ded5877a60de83a1776f2496b4be6257dea192c5c77358f'
AGG_SHA='56d9fce4f76273cd501cacdf7e5079ac40ae62edeaee0301e1dd795602e19d80'


def info(path: Path) -> dict:
    """
    機能: レビュー対象の保存指紋を求める。
    引数: path (Path) は既存コード。
    返り値: dict は相対パス/bytes/sha256。
    """
    raw=path.read_bytes()
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def artificial_pub(session: str, contract: str, end: int, number: int, close: float, known: bool=True) -> dict:
    """
    機能: BB窓の条件を手計算できる人工15分公表を作る。
    引数: session/contract (str)、end/number (int)、close (float)、known (bool) は架空値。
    返り値: dict は固定122と同形の最小公表。
    """
    return {'stamp':{'time':end+60,'index':number,'source_line':number+1},'frame':{'frame':{
        'id':f'{session}/900/{end}','session_id':session,'contract':contract,'width_seconds':900,
        'start':end-900,'end':end,'available_at':end+60,'delivery_at':end+60,
        'price_known':known,'ohlc':{'open':close,'high':close+1,'low':close-1,'close':close}}}}


def check_bands(bridge: object) -> list[str]:
    """
    機能: 20母分散の閉形式・同限月carry・欠分/未知・無取引窓保持を検査する。
    引数: bridge (object) はmain未実行の転送モジュール。
    返り値: list[str] は成功した独立の境界群。
    """
    first=[artificial_pub('A','C',900*i,i,10000+10*(i-1)) for i in range(1,21)]
    band=bridge.bands(first)
    assert band['known'] and band['count']==20 and band['mean']==10095
    assert math.isclose(band['sigma'],math.sqrt(3325),rel_tol=0,abs_tol=1e-12)
    assert not bridge.bands(first[:19])['known']
    flat=copy.deepcopy(first)
    for pub in flat:pub['frame']['frame']['ohlc']={'open':10000,'high':10001,'low':9999,'close':10000}
    assert bridge.bands(flat)['sigma']==0 and bridge.bands(flat)['known']
    last=copy.deepcopy(first);last[0]['frame']['frame']['price_known']=False
    assert not bridge.bands(last)['known'] and bridge.bands(last)['count']==20
    checks=['20本母分散を等差列の閉形式で照合・不足/σ0/未知を区別']
    bg={'trial':122,'scenes':[{'session':'A','contract':'C','publications':first+[copy.deepcopy(first[0])]},
        {'session':'B','contract':'C','publications':[artificial_pub('B','C',40000,1,10200),
            artificial_pub('B','C',41800,2,10210),artificial_pub('B','C',42700,3,0,False)]},
        {'session':'D','contract':'NEXT','publications':[artificial_pub('D','NEXT',60000,1,20000)]}]}
    old=copy.deepcopy(bg)
    windows,lookup,ordered=bridge.background_index(bg)
    assert bg==old and len(ordered['A'])==20
    carry=windows['B','B/900/40000'];assert carry['bands']['known'] and len(carry['refs'])==20
    assert carry['refs'][0]['id']=='A/900/1800' and carry['refs'][-1]['id']=='B/900/40000'
    assert windows['B','B/900/41800']['bands']['count']==1
    assert not windows['B','B/900/42700']['bands']['known'] and windows['B','B/900/42700']['bands']['count']==2
    assert not windows['D','D/900/60000']['bands']['known'] and windows['D','D/900/60000']['bands']['count']==1
    checks.append('同限月carry/当場欠分/未知非圧縮/異限月reset・同ID不増・入力非改変')
    scene={'session':'B','bb_windows':[copy.deepcopy(w) for (sid,_),w in windows.items() if sid=='B']}
    assert len(bridge.validate_windows(scene,windows))==3
    scene['bb_windows'].pop()
    try:bridge.validate_windows(scene,windows)
    except AssertionError:pass
    else:raise AssertionError('候補のないBB窓の欠落を許可')
    checks.append('取引のない公表窓も全canonical保存を検査')
    return checks


def check_fixture_roles(bridge: object, fixture: object) -> list[str]:
    """
    機能: 旧87/反対aliasの非改変とp準備・r現在の未知要件を分離する。
    引数: bridge/fixture (object) は人工だけを使う転送と生成関数。
    返り値: list[str] は追加した接続境界群。
    """
    arguments=fixture();before=copy.deepcopy(arguments)
    fixed,meta=bridge.build(*arguments)
    assert arguments==before and fixed['expected_entry_count']==89 and len(meta['union'])==88
    assert len([e for e in meta['entries'] if e['model']=='C1'])==87
    checks=['四入力辞書を非改変、旧87/新2/反対aliasを保持']
    old_fixed,old_meta,source,background=fixture()
    scene=source['scenes'][0];pc=scene['bars'][0]['context'];side=scene['events'][0]['side']
    publications=background['scenes'][0]['publications']
    selected=bridge.asof(publications,pc['at'])
    selected[900]['frame']['dmi']['plus_di']['known']=False
    selected[900]['frame']['dmi']['minus_di']['known']=False
    pc['fields']['di_difference15']={'known':False,'value':0}
    bridge.current_values(publications,pc['at'],side,pc,False)
    try:bridge.current_values(publications,pc['at'],side,pc,True)
    except AssertionError:pass
    else:raise AssertionError('p準備とr現在のDI要件を区別しない')
    checks.append('p初DI未知を準備で許し、現在確認では拒否')
    old_fixed,old_meta,source,background=fixture()
    event=source['scenes'][0]['events'][0]
    selected=bridge.asof(background['scenes'][0]['publications'],event['birth'])
    selected[300]['frame']['frame']['technical']['previous_histogram']['known']=False
    try:bridge.build(old_fixed,old_meta,source,background)
    except AssertionError:pass
    else:raise AssertionError('宣言Previous未知を実前既知で補完した')
    checks.append('宣言Previous未知のfilled票を実前既知で救済しない')
    return checks


def main() -> None:
    """
    機能: 最終コードでRoot人工と追加境界を実行し、運転/CLI/算術分離を束縛する。
    引数: なし。自然Source/背景/Raw/CSV/新金融を開かない。
    返り値: None。接続専用の停止証跡を保存する。
    """
    assert info(DRIVER)['sha256']==DRIVER_SHA and info(CALC)['sha256']==CALC_SHA and info(AGG)['sha256']==AGG_SHA
    assert info(AGG_READY)['sha256']=='7959bac5f8584a73aa5cc03a69809b6e0df144970721922258ca20d7595a3a94'
    assert info(BRIDGE)['sha256']=='6ed5837668e727e6358af19e9c3be66cb26465f557732e045833182bb957b27c'
    assert info(TEST)['sha256']=='5930d55772b6b100c81027be91d47ee354cd91546733cbd22bf2ef753da436ab'
    before=[info(path) for path in (BRIDGE,TEST,DRIVER,CALC,AGG,AGG_READY)]
    artificial=runpy.run_path(str(TEST),run_name='人工だけ')
    captured=io.StringIO()
    with contextlib.redirect_stdout(captured):artificial['main']()
    author_result=json.loads(captured.getvalue())
    assert author_result['成功']
    bridge=artificial['m']
    checks=check_bands(bridge)
    checks.extend(check_fixture_roles(bridge,artificial['fixture']))
    cli=[]
    for path in (BRIDGE,DRIVER,CALC):
        result=subprocess.run(['python','-X','utf8',str(path),'--help'],cwd=ROOT,capture_output=True,text=True,encoding='utf-8')
        assert result.returncode==0
        cli.append({'path':path.relative_to(ROOT).as_posix(),'終了コード':result.returncode,'標準出力':result.stdout})
    driver=DRIVER.read_text(encoding='utf-8');calculator=CALC.read_text(encoding='utf-8')
    assert "source_ready['採用仕様SHA256']==sha(SPECIFICATION)" in driver
    assert "independent['人工群']==4" in driver and "for name,h in independent['Source源'].items():assert sha(Path(name))==h" in driver
    assert "(GEN,FORMAL,AGG,ROOT/'work/118複数技法の入口条件')" in driver
    assert '147金融を別算術で確認する.py' in driver and '141金融集計を独立に確認する.py' in driver
    assert "'--workers','1','--execute-after-f0'" in driver and 'helper.verify(finance)' in driver
    assert "calc.calculate(selected,policy=='RU',axis,h,w)" in calculator
    assert "assert comparisons==300" in calculator and "CALCULATOR_SHA='30bd4aef8c2809699cb013f930cfbce152f3986fe8d3d3cc6b49452104c2269e'" in calculator
    assert calculator.index("expected={}")<calculator.index("actual=json.loads(paths['summary'].read_bytes())")
    for path in (BRIDGE,TEST,DRIVER,CALC,AGG):ast.parse(path.read_text(encoding='utf-8'))
    assert before==[info(path) for path in (BRIDGE,TEST,DRIVER,CALC,AGG,AGG_READY)]
    proof={'成功':True,'試行':147,'状態':'金融前接続レビューを停止','橋渡し作者人工':author_result,'追加境界群':len(checks),'追加境界':checks,
        'SourceRoot独立票との役割分離':'本agentはpublications.go/testの作者。Source/cacheの独立検算を本票として主張せず、Root運転/別算術とarchive作成の橋渡しだけを対象とする。',
        'AGGのSHA区分':'親へ確認済み。7959bac5…はAGG準備票、集計codeは56d9fce4…であり改変又は条件差ではない。両方へbindした。',
        '静的確認':'Source→BB20正本/p初値/固定C1,T0,union・旧C0subset・native/実逆・300factor・Root141独立算術SHA・F0/F1包含・CLIを照合。',
        'CLI':cli,'構文確認':5,'コード前後同体':before,'確認器SHA256':info(Path(__file__))['sha256'],
        '自然Source背景RawCSV新金融追加2場読取':False,'Source又はRoot又はarchiveコード編集':False}
    raw=(json.dumps(proof,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    (OWN/'準備の確認.json').write_bytes(raw)
    print(json.dumps({'proof_sha256':hashlib.sha256(raw).hexdigest(),'extra_groups':len(checks)}))


if __name__=='__main__':
    main()
