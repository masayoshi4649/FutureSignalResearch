"""touch優先・期限清算・未知と実P鏡像を人工で確認する。"""
from pathlib import Path
import copy
import importlib.util
import unittest

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('diag147five',HERE/'診断する.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)


def case_fixture(direction: int=0,status: str='complete') -> dict:
    """
    機能: 実側と終値を混ぜない人工の保存観測を作る。
    引数: direction(int)、status(str)。返り値: dict。
    """
    entry={'time':10,'last':100,'bid':99,'ask':100};endpoint={'time':3610,'last':81,'bid':80,'ask':82}
    touch={'time':20,'last':226,'bid':225,'ask':227}if direction else None
    stream={'entry':entry,'entry_price':100,'birth':{'side':1},'outcomes':[{'seconds':3600,'deadline':3610,'status':status,
        'endpoint':endpoint if status=='complete'else None,'touches':[{'width':125,'direction':direction,'quote':touch}]}]}
    return {'original':stream}


class FiveTests(unittest.TestCase):
    """方向と時計の代用計算を確認する。"""

    def test_touchは期限より優先(self) -> None:
        """
        機能: 後の赤字endpointに既知利確を置換しない。
        引数: self(FiveTests)。返り値: None。
        """
        value=module.arrival(case_fixture(1),False,125)
        self.assertEqual((value['IFD清算'],value['IFDpt'],value['取得から到達秒']),('順行到達',125,10))
        stats=module.arithmetic().calculate([('人工',case_fixture(1))],False,'BBO',3600,125)
        self.assertEqual(stats['ifd_net5_sum'],11423)

    def test_未到達の期限清算(self) -> None:
        """
        機能: 未到達を0損益にせず実BBO期限価格で計算する。
        引数: self(FiveTests)。返り値: None。
        """
        value=module.arrival(case_fixture(),False,125)
        self.assertEqual((value['方向'],value['IFD清算'],value['IFDpt']),(0,'期限清算',-20))
        stats=module.arithmetic().calculate([('人工',case_fixture())],False,'BBO',3600,125)
        self.assertEqual(stats['ifd_net5_sum'],-3077)

    def test_不足未到達は未知(self) -> None:
        """
        機能: H不足/未touchを未知として保つ。
        引数: self(FiveTests)。返り値: None。
        """
        value=module.arrival(case_fixture(0,'censored'),False,125)
        self.assertIsNone(value['方向']);self.assertIsNone(value['IFDpt']);self.assertEqual(value['IFD清算'],'未知')

    def test_固定BB実Pの売買鏡像(self) -> None:
        """
        機能: side別のAsk/Bidと固定位置を同じ距離へ写す。
        引数: self(FiveTests)。返り値: None。
        """
        output=[]
        for side in (1,-1):
            q0={'clock':'人工','time':100,'index':1,'source_line':2,'last':1000,'bid':999,'ask':1001,'quote_ok':True}
            last=1000+5*side;q1={**q0,'time':101,'index':2,'source_line':3,'last':last,'bid':last-1,'ask':last+1}
            st={'k':1000,'i':1000-25*side,'width':25,'cap':75,'arm_atr':100,'bb_mean':1000-5*side,'bb_forward':1000+200*side,'bb_window_id':'人工'}
            origin={'side':side,'structure':st,'birthQuote':q0,'confirm':{'end':40,'delivered':{k:q0[k]for k in ('time','index','source_line')}},'arm':{},'source_locator':{},'source_file_sha':'a'*64}
            entry={'origins':[origin],'native_side':side,'entry_quote':q1};case={'original_side':side,'original':{'entry_price':q1['ask'if side==1 else 'bid'],'entry':q1}}
            value=module.position(entry,case);output.append([value[k]for k in ['実P_K_signed','実P_I_risk','実P_BB中心_signed','BB順端までのsigned距離']])
        self.assertEqual(output[0],output[1]);self.assertEqual(output[0],[6,31,11,194])


if __name__=='__main__':
    unittest.main(verbosity=2)
