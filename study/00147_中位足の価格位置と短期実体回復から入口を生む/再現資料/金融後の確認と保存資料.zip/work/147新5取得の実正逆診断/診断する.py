"""147新5取得の固定構造と保存済み実正逆先着を小型に診断する。"""
from pathlib import Path
from collections import Counter
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
META=ROOT/'work/147中位実体回復の評価/固定入力/入口参照.json'
PAIRS=ROOT/'work/147中位実体回復の評価/固定取得の正逆観測.json'
CALC=ROOT/'work/141金融集計を独立に確認する.py'
WIDTHS=(25,50,100,125,200)


def sha(path: Path) -> str:
    """
    機能: 小型の保存入力又はコード指紋を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def arithmetic():
    """
    機能: Root指定の凍結141独立calculateだけを再用する。
    引数: なし。返り値: ModuleType。
    """
    spec=importlib.util.spec_from_file_location('frozen141diag147',CALC)
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value


def arrival(case: dict,inverse: bool,width: int) -> dict:
    """
    機能: 保存H60の最初到達とIFD代用の清算時計/価格を取り出す。
    引数: case(dict)、inverse(bool)、width(int)。返り値: dict。
    """
    stream=case['reverse' if inverse else 'original'];h=next(x for x in stream['outcomes']if x['seconds']==3600)
    touch=next(t for t in h['touches']if t['width']==width)
    exit_quote=touch['quote']if touch['direction'] else h['endpoint']if h['status']=='complete' else None
    side=stream['birth']['side'];mark=None if exit_quote is None else exit_quote['bid' if side==1 else 'ask']
    points=None if mark is None else side*(mark-stream['entry_price'])
    return {'width':width,'H状態':h['status'],'方向':touch['direction']if h['status']=='complete' else None,
        'touch方向_不足でも保持':touch['direction'],'最初到達Quote':touch['quote'],'H期限':h['deadline'],
        'Hendpoint':h['endpoint'],'IFD清算':'未知'if exit_quote is None else '順行到達'if touch['direction']==1 else '逆行到達'if touch['direction']==-1 else '期限清算',
        'IFD清算Quote':exit_quote,'IFD清算価格':mark,'IFDpt':points,
        '取得から到達秒':None if touch['quote']is None else touch['quote']['time']-stream['entry']['time'],
        '取得からIFD清算秒':None if exit_quote is None else exit_quote['time']-stream['entry']['time']}


def position(entry: dict,case: dict) -> dict:
    """
    機能: native実Pと凍結BB/K/Iの位置・知得遅れを分離する。
    引数: entry(dict)、case(dict)。返り値: dict。
    """
    assert len(entry['origins'])==1;origin=entry['origins'][0];side=entry['native_side'];st=origin['structure']
    q0=origin['birthQuote'];q1=entry['entry_quote'];p=case['original']['entry_price'];last=q1['last']
    assert origin['side']==case['original_side']==side and case['original']['entry']==q1
    assert p==q1['ask' if side==1 else 'bid']
    assert q1['time']>=q0['time']+1 and q1['time']<q0['time']+30 and q1['index']>q0['index'] and q1['source_line']>q0['source_line']
    assert all(origin['confirm']['delivered'][k]==q0[k] for k in ('time','index','source_line'))
    distance=side*(p-st['k']);risk=side*(p-st['i']);center=side*(p-st['bb_mean']);headroom=side*(st['bb_forward']-p)
    assert 0<=distance<=st['cap'] and 0<risk<=125 and center>=0 and headroom>=125
    assert st['width']==side*(st['k']-st['i'])
    return {'native_side':side,'structure':st,'実P':p,'entry_Last':last,'実P_K_signed':distance,'cap残':st['cap']-distance,
        '実P_I_risk':risk,'実P_BB中心_signed':center,'BB順端までのsigned距離':headroom,'125後のBB余地':headroom-125,
        'Last_K_signed':side*(last-st['k']),'Last_BB中心_signed':side*(last-st['bb_mean']),'LastからBB順端':side*(st['bb_forward']-last),
        'q0':q0,'q1':q1,'q0_q1秒':q1['time']-q0['time'],'rEnd_取得秒':q1['time']-origin['confirm']['end'],
        'rEnd_出生秒':q0['time']-origin['confirm']['end'],'p_ref':origin['arm'],'r_ref':origin['confirm'],
        'BB初知窓ID':st['bb_window_id'],'source_locator':origin['source_locator'],'source_sha256':origin['source_file_sha']}


def diagnostic(meta: dict,paired: dict,calc) -> dict:
    """
    機能: 新5件を落とさず全幅の原/実逆を計算し125未到達清算を分ける。
    引数: meta/paired(dict)、calc(ModuleType)。返り値: dict。
    """
    assert meta['trial']==147 and meta['success'] and paired['success'] and paired['input_sha256']==meta['fixed_input_sha256']
    entries={e['id']:e for e in meta['entries']if e['model']=='T0'};assert len(entries)==5
    cases={c['id']:(s,c)for s in paired['scenes']for c in s['cases']};rows=[];selected=[]
    for key,e in entries.items():
        scene,case=cases[key];assert e['session']==scene['session'];assert e['entry_quote']['time']<scene['effective_entry_limit']
        selected.append((e['session'],case));details=position(e,case);widths={}
        for width in WIDTHS:
            sides={}
            for name,inverse in [('native',False),('inverse',True)]:
                stats=calc.calculate([(e['session'],case)],inverse,'BBO',3600,width)
                saved=arrival(case,inverse,width)
                if saved['IFDpt']is None:assert stats['ifd_net5_sum']is None
                else:assert stats['ifd_net5_sum']==saved['IFDpt']*100-1077
                for quote in [saved['最初到達Quote'],saved['Hendpoint']]:
                    if quote:assert quote['time']<scene['execution_end']
                sides[name]={'集計':stats,**saved}
            widths[str(width)]=sides
        rows.append({'id':key,'session':e['session'],'contract':e['contract'],'position':details,'H60幅別':widths})
    aggregate={str(width):{name:calc.calculate(selected,inverse,'BBO',3600,width)for name,inverse in [('native',False),('inverse',True)]}for width in WIDTHS}
    exits={}
    for name in ('native','inverse'):
        groups={}
        for row in rows:
            cell=row['H60幅別']['125'][name];reason=cell['IFD清算'];stats=cell['集計'];group=groups.setdefault(reason,Counter())
            group['件数']+=1;group['既知']+=stats['ifd_known'];group['未知']+=stats['ifd_unknown']
            group['利益']+=stats['ifd_net5_profit']or 0;group['損失絶対']+=stats['ifd_net5_loss']or 0;group['差引']+=stats['ifd_net5_sum']or 0
        exits[name]={key:dict(value)for key,value in groups.items()}
    return {'成功':True,'試行':147,'診断対象':'新T0全5物理取得、旧C1を加算しない','全場数':len(meta['sessions']),
        '取得場数':len({row['session']for row in rows}),'未取得場':[s for s in meta['sessions']if s not in {row['session']for row in rows}],
        '全幅':aggregate,'主125清算別':exits,'全5':rows,'主幅':125,'主H秒':3600,'小幅へ主を交換':False,
        '注意':['5件の既使用期事後診断であり一般則ではない','保存touchは指定幅の最初到達で、MFE/MAEそのものではない',
            '同取得時計の実BBO反転で、逆側注文適格性を新たに生成していない','独立mini1枚100円/pt、手数料77円/C5追加滑り往復1000円の代用']}


def render(data: dict) -> str:
    """
    機能: 全5件の位置・幅別時計・未到達清算の寄与を短報にする。
    引数: data(dict)。返り値: str。
    """
    a=data['全幅']['125'];exits=data['主125清算別']
    lines=['# 147新5取得の実正逆と期限清算','', '2026-11-12。保存metadataと保存正逆観測だけを使用した。450MB Source・原板・CSV・122・追加2場を再読していない。Rootから主数値を受領して行った事後診断で、勝ち群を探して新条件へ採用していない。','',
        '## 主H60±125pt','', '|向き|順/逆/未/不足|到達済率|C5利益|C5損失絶対|C5差引|','|---|---|---:|---:|---:|---:|']
    for name,s in a.items():lines.append('|'+ '|'.join(map(str,[name,'/'.join(str(s[k])for k in ('forward','adverse','neither','censored')),format(s['resolved_rate'],'.2%')if s['resolved_rate']is not None else 'null',s['ifd_net5_profit'],s['ifd_net5_loss'],s['ifd_net5_sum']]))+'|')
    lines+=['', '両方向ともIFD既知5/未知0。nativeの到達済率は2/3だが、全5分母では2/5である。未到達2件の期限清算を捨てて損益を作らない。5取得は4場で、残る69場は新T0未取得である。旧C1を加えた全場参加と混同しない。','',
        '|向き/清算|件数|利益|損失絶対|差引|','|---|---:|---:|---:|---:|']
    for name,groups in exits.items():
        for reason,g in groups.items():lines.append('|'+ '|'.join(map(str,[name+'/'+reason,g['件数'],g['利益'],g['損失絶対'],g['差引']]))+'|')
    lines+=['', 'nativeでは未到達2件の期限清算が−10,077円と−7,077円、計−17,154円で、総損失31,231円の54.93%を占めた。これを125pt逆行到達1件の−14,077円と区別する。未到達2件は同じ10/07デイの近接した取得であり、独立した別相場の2例とはみなさない。実逆では同じ2件の期限清算が+5,923/+2,923円だった。', '',
        'H期限のnet5字段をそのままtouch清算へ使わず、最初touchが既知ならその実側価格を優先した。費用は往復77円、C5では追加滑り往復1000円。ラージBBOによるmini1枚100円/pt代用で、実注文/口座収支ではない。','',
        '## 固定構造と取得位置','', '|場/取得JST|side|K/I/W|cap|実P/Last|実P−Kの符号距離|実PからIのrisk|BB中心/順端|中心から実P|順端まで|q0→q1秒|r.End→取得秒|','|---|---:|---|---:|---|---:|---:|---|---:|---:|---:|---:|']
    for row in data['全5']:
        p=row['position'];s=p['structure'];cells=[row['session']+' '+p['q1']['clock'],p['native_side'],f"{s['k']:g}/{s['i']:g}/{s['width']:g}",f"{s['cap']:.4f}",f"{p['実P']:g}/{p['entry_Last']:g}",p['実P_K_signed'],p['実P_I_risk'],f"{s['bb_mean']:.4f}/{s['bb_forward']:.4f}",f"{p['実P_BB中心_signed']:.4f}",f"{p['BB順端までのsigned距離']:.4f}",p['q0_q1秒'],p['rEnd_取得秒']]
        lines.append('|'+ '|'.join(map(str,cells))+'|')
    lines+=['','K/I/ATR/BBは出生条件へ使ったp初知・r完成票からの固定値であり、後のBBへ置き換えていない。実Pは買Ask/売Bidで、Lastとは別。全5件とも固定中心の順側・K/cap内・順端まで125pt以上・risk125pt以下を満たした。これらは位置の適格性であって、その後の到達を保証するものではない。','',
        '## H60の幅別先着と時計','', 'F=順行先着、A=逆行先着、N=両方未到達。括弧内は最初touchのJST又はNの期限清算JST、続いてC5代用円。幅はMFE/MAEそのものではない。25/50/100/200を副診断へ残しても、主125の評価は交換しない。','',
        '|場/取得JST|向き|25pt|50pt|100pt|125pt|200pt|','|---|---|---|---|---|---|---|']
    for row in data['全5']:
        for name in ('native','inverse'):
            cells=[row['session']+' '+row['position']['q1']['clock'],name]
            for width in WIDTHS:
                cell=row['H60幅別'][str(width)][name];letter={1:'F',-1:'A',0:'N',None:'C'}[cell['方向']];q=cell['IFD清算Quote']
                cells.append(letter+' ('+(q.get('clock',str(q['time']))if q else '未知')+') / '+str(cell['集計']['ifd_net5_sum']))
            lines.append('|'+ '|'.join(cells)+'|')
    lines+=['','各Quoteのtime/index/source_line/Last/Bid/Ask、実際の最初到達秒とHendpoint、IFDpt/C0/C5は結果JSONに保存した。異なる幅は同じ5件に属する反復観測であり、別々の独立取引として回数を加算しない。','',
        '結論は、未到達の期限清算を含むとnative/実逆ともC5赤字で、単純な方向反転でも解決しないという5件の事実までである。個々の値から一般則を作らず、閾値の緩和や勝群選別をしていない。','']
    return '\n'.join(lines)


def main() -> None:
    """
    機能: 小型入力だけから指定5件の診断を未作成成果へ保存する。
    引数: なし。返り値: None。
    """
    inputs=[META,PAIRS,CALC,Path(__file__).resolve()];hashes={str(p):sha(p)for p in inputs}
    meta=json.loads(META.read_bytes());paired=json.loads(PAIRS.read_bytes());data=diagnostic(meta,paired,arithmetic())
    assert all(sha(p)==hashes[str(p)]for p in inputs)
    data['入力指紋']=hashes
    with (HERE/'結果.json').open('x',encoding='utf-8')as out:json.dump(data,out,ensure_ascii=False,indent=2);out.write('\n')
    (HERE/'未到達清算を含めた全5の実数.md').write_text(render(data),encoding='utf-8')
    print(json.dumps({'success':True,'main':data['全幅']['125'],'exits':data['主125清算別']},ensure_ascii=True))


if __name__=='__main__':
    main()
