"""147のF1原文・採用条件・513セルを保持し、保存正本から正式3MDを結果化する。"""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
FORMAL = ROOT / 'study/00147_中位足の価格位置と短期実体回復から入口を生む'
SUMMARY = ROOT / 'work/147中位実体回復の評価/金融評価/集計.json'
TABLES = SUMMARY.with_name('CSV用の表.json')
SOURCE = ROOT / 'work/147中位実体回復の非金融診断/どこで細ったか.md'
SUMMARY_SHA = 'afcef5ac1b72567cd7512c5818d2f832c77d0a93fdab07a8d7869b2ada167750'
TABLES_SHA = '963f190cb8cdbf5fac21b6cfc44a1b5a37e8cbf970a5604137734da2cd3ae336'
SOURCE_SHA = '5741ff34c8f70ba910f1ea55a3ba5ae5acbd76482b8b80d43f70e36f35fd5561'
BACKUP_SHA = 'b4f525cc4c4d9b389a97e65ee2405d7d326314638356ba84a84a26525dc9e4a5'
POLICIES = ('U0', 'T0', 'C1', 'C0', 'RU')


def fingerprint(path: Path) -> dict:
    """
    機能: 指定ファイルの保存bytesを指紋化する。
    引数: path(Path)。返り値: dictは相対パス・bytes・SHA256。
    """
    raw = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def number(value: int | None) -> str:
    """
    機能: 金額未知・対象0件を0円へ補完しない表示を作る。
    引数: value(int|None)。返り値: strは整数又は未集計記号。
    """
    return '—' if value is None else f'{value:,}'


def percent(value: float | None) -> str:
    """
    機能: 分母0を既知0%から区別する。
    引数: value(float|None)。返り値: strは百分率又は分母0の記号。
    """
    return '—（分母0）' if value is None else f'{value:.2%}'


def table(data: dict, scope: str, detailed: bool) -> str:
    """
    機能: 保存正本の政策別BBO/H60/125を表にする。
    引数: data(dict)、scope(str)、detailed(bool)。返り値: strはMarkdown表。
    """
    headers = ['政策', '取得/取得場', '順/逆/未到達/不足', '到達済み率']
    if detailed:
        headers += ['H完了分母率', '全取得分母率']
    headers += ['C5利益円', 'C5損失円', 'C5既知差引円', '金額未知件']
    out = '|' + '|'.join(headers) + '|\n|' + '|'.join(['---'] * len(headers)) + '|\n'
    for policy in POLICIES:
        v = data['集計'][scope][policy]['BBO']['3600']['125']
        cells = [policy, f"{v['entries']} / {v['sessions']}",
                 '/'.join(str(v[k]) for k in ('forward', 'adverse', 'neither', 'censored')),
                 percent(v['resolved_rate'])]
        if detailed:
            cells += [percent(v['complete_rate']),
                      percent(v['forward'] / v['entries'] if v['entries'] else None)]
        cells += [number(v[k]) for k in ('ifd_net5_profit', 'ifd_net5_loss', 'ifd_net5_sum')]
        cells += [str(v['ifd_unknown'])]
        out += '|' + '|'.join(cells) + '|\n'
    return out


def source_section() -> str:
    """
    機能: 停止済み非金融診断の分母を区別した要点を返す。
    引数: なし。返り値: strはSource原因節。新Source・原板を計算しない。
    """
    assert fingerprint(SOURCE)['sha256'] == SOURCE_SHA
    return '''[Source非金融診断](根拠/どこで細ったか.md)は先着・金融を読まず、保存Sourceの全73場を数えた。全配送1分43,124に対して最新rのcheck40,544、うち新規限界以後3,718だった。

|説明順の累積段階|件数|
|---|---:|
|当場隣接の形状窓|34,125|
|配送time/indexのstrict順も成立|33,175|
|p初価格/30方向/ATR/BBも成立|23,563|
|p逆実体も成立|8,779|
|p初5分EMA帯接触も成立|2,495|
|現在価格/30方向も成立|2,494|
|15分DI方向/ADX非低下も成立|1,265|
|5分Hist実増分も成立|145|
|r順実体/p始値回復も成立|36|
|同足量も成立|15|
|二尺度TR/freshも成立（技術完成）|13|

この累積表は既存gateを説明順で交差させたもので、先にある条件だけを排他的原因としない。後段は技術完成13→幅後13→BB目標余地後11→完成時Last位置後6→出生6→取得5。構造幅除外0、BB順端までのcap不足2、完成時Last位置外5、出生後Last位置取消1は、それぞれその後段における排他的statusである。

13件すべてを仮に取得できても約0.01803回/時にとどまり、BB/capだけを外して概ね1回/時へ届くとは言えない。実際の新T0は5取得/4場、未取得69場を残す。p初EMA21_5は33,017/34,125、現在Hist実増分は32,117/34,125既知で、146の短期MACD助走問題と同一視しない。助走後にも多時間軸・形状・量の同時成立域が細かった。

BB半幅が125pt以上ある判定はBB既知30,580中30,341で、半幅不足は239。帯そのものの狭さだけが主原因ではない。方向とBBを判別できる24,199判定では、Kから順端まで125pt余地なし8,838、固定K/capとBB中心/順端の共通価格域なし12,346、現在Lastの位置条件不成立19,273だった。これらは重複し、技術完成後13件とも別分母なので加算しない。

「価格帯へ戻る局面と5分Hist増勢の確認が同時に揃いにくい」は次の心理・時間軸上の仮説で、参加者意図や因果を実証したものではない。条件を順次保存する案や母集団を広げる案は、別試行で事前固定して検証する問いにとどめる。結果後にcap・余地・勢い条件を緩めず、新T0の勝ち2件だけを残していない。
'''


def result_section(data: dict) -> str:
    """
    機能: 正本と停止診断を用いて結果草稿を作る。
    引数: data(dict)。返り値: strはREADME追記用の本文。
    """
    return '''## 実行結果

全73場の自然Source、固定取得、凍結133による正逆観測、300比較を完了した。**主U0は44順/19逆/23未到達/6不足、到達済み44/63＝69.84126984%で70%未達。全場最低1取得は達成したが、平均0.127615件/時も不足し、共同目標未達・新Tの採用達成とはしない。丸めて70%へ扱わない。**

''' + table(data, 'all', True) + '''
主U0のC5利益568,842円/損失365,695円、既知差引+203,147円（89件既知/3件未知）。追加滑り0の費用条件では+292,147円で、ここでの費用C0と政策C0旧81は別である。独立mini1枚100円/pt、往復税込77円、C5は追加往復10pt＝1,000円。入口IFD代用の集計であり、片側10枚・同時保有・資金制約・mini実板・実IFD・必須利益追尾を備えた口座収支ではない。全H不足6と金額未知3も別で、H不足でも既知touchはIFD金額既知になり得る。

新T0は5取得/4場、2順/1逆/2未到達/0不足で66.67%（到達済み分母3）。全5件はH完了、H完了/全件分母率はともに40.00%。C5利益23,846円/損失31,231円/差引−7,385円だった。少数の2勝1敗を安定性や70%達成の根拠にしない。新T0は全て前48場にあり、後25場では0取得・率/金額nullを0%/0円へ補完しない。

旧C1全87は42順/18逆/21未到達/6不足＝70.00%、C5既知差引+210,532円で旧145同体。旧C0全81はC1のsubsetで二重加算しない。新5取得を足すと主の率・既知差引がともに低下した。今回同原行alias重複は0、物理U0=87+5=92。C0全81/C1全87の4stream・全H幅と各60条件を同体確認し、成績による取得選別は行っていない。未採用146新26も旧正本へ全件保存したまま今回のbaselineへ混ぜていない。

RUは旧C1を含むU0全92件の同時点実BBO反対側で、14順/57逆/15未到達/6不足＝19.72%。C5利益227,229円/損失858,082円/差引−630,853円（89件既知/3件未知）。反対率を1−pでは作らず、新T0単独の実逆とも混同しない。結果を見た後でRUへ主を交換していない。

全時間分母はΣ(scene.end−300−scene.start)＝720時間55分。主92/720.9167＝0.12761530458906487件/時、新T0単独は0.006935614379840482件/時。全場参加は旧C1を保護したunionとして達成し、新stream単独では69場が未取得である。各場の偏りを許容する条件で評価しており、毎時の強制取得や場ごとの均等割当で水増ししない。

### 前48場

''' + table(data, 'train', False) + '''
### 後25場

''' + table(data, 'validation', False) + '''
金額「—」は対象0件・既知0件で集計しない欄、率「—（分母0）」も0%ではない。主前48は30/11/19/4＝73.17%、C5+162,226円・金額未知2。主後25は14/8/4/2＝63.64%、C5+40,921円・金額未知1。全期既使用で、前48/後25は記述区分であり独立未知期の検証とは呼ばない。

## 状態遷移と次の問い

''' + source_section() + '''
## 閲覧・再現・限界

正本は[集計](成果物/集計.json)。[全セッションCSV](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/147_中位位置と実体回復/全セッション.csv)、[300条件CSV](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/147_中位位置と実体回復/正逆比較.csv)、[基礎92入口CSV](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/147_中位位置と実体回復/入口別診断.csv)で全場と取得集合を残す。Root別算術は300比較/7,200主要統計セルを一致確認した。CSV作成・再読の証跡は保管記録へ分けて保存し、xlsxは生成しない。

Source/固定取得/入口参照は[恒久入力](../../inputs/00147_中位価格位置と実体回復/)へ各一度だけgzip保存する。F0/F1原文・固定コード・保存正逆からの再集計は[保管索引](保管索引.json)と[再現手順](再現手順.md)を参照する。原板・共用大入力・観測の不要な重複を避ける。

採用条件・時計・未知処置・BB位置・cap・取得集合を結果後に変更していない。複数技法の条件変更を伴う複合評価であり、BB/Hist/指標単独の効果とはしない。価格時計の限界、実receivedAt/ClosedAt、反転注文の適格性再構築・mini実板・実IFD・利益追尾・口座収支は未検証。追加2場の価格も未読を維持する。
'''


def main() -> None:
    """
    機能: 草稿を保存し、適用指定時だけF1原文から3MDを更新する。
    引数: CLI --mode(str)は草稿又は適用。返り値: None。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=('草稿', '適用'), default='草稿')
    args = parser.parse_args()
    assert fingerprint(SUMMARY)['sha256'] == SUMMARY_SHA
    assert fingerprint(TABLES)['sha256'] == TABLES_SHA
    data = json.loads(SUMMARY.read_bytes())
    assert data['試行'] == 147 and data['主政策'] == 'U0'
    assert data['取得集合数'] == {'C0': 81, 'C1': 87, 'T0': 5, 'U0': 92}
    assert not data['主評価']['三項目すべて達成']
    draft = result_section(data)
    (OWN / '結果草稿.md').write_text('# 147・正式結果の草稿\n\n' + draft, encoding='utf-8')
    (OWN / 'Source要点.md').write_text(source_section(), encoding='utf-8')
    if args.mode == '草稿':
        print(json.dumps({'formal_changed': False, 'draft': fingerprint(OWN / '結果草稿.md')}))
        return
    backup = FORMAL / '検査/F1原文と増分の保管確認.json'
    assert fingerprint(backup)['sha256'] == BACKUP_SHA
    snapshot = json.loads(gzip.decompress((FORMAL / '検査/F1実行前文書.json.gz').read_bytes()))
    stored = {item['path'].replace('\\', '/'): item for item in snapshot['文書']}
    original = {}
    for name in ('README.md', '条件.md', '設定と結果.md'):
        path = FORMAL / name
        item = stored[path.relative_to(ROOT).as_posix()]
        raw = item['本文'].encode('utf-8')
        assert hashlib.sha256(raw).hexdigest() == item['sha256']
        assert path.read_bytes() == raw, f'固定後の未知の文書変更:{name}'
        original[name] = raw
    protected = [SUMMARY, TABLES, SOURCE, ROOT / 'work/147_中位足の価格位置と短期実体回復の採用仕様.md',
                 ROOT / 'work/147中位回復と旧87を固定取得へ渡す.py',
                 ROOT / 'work/147出生と金融を分離して実行する.py',
                 ROOT / 'work/147中位位置の金融集計/集計する.py', backup]
    protected += [p for p in (ROOT / 'work/147中位位置からの実体回復').rglob('*')
                  if p.is_file() and p.suffix in ('.go', '.mod', '.exe')]
    protected += list((ROOT / 'work/147中位実体回復の評価/固定入力').glob('*.json'))
    protected += list((ROOT / 'study/00146_短期構造の完成パターンで入口を増やす').glob('*.md'))
    before = [fingerprint(p) for p in protected]
    readme = original['README.md'].decode('utf-8')
    old = '試行00147。2026-11-12、採用仕様の正式準備。Source実装・人工完了前で、自然生成・新出生/取得・率/損益は未実行。上位方向内の単一Tから新T0を生み、旧145全87のC1とunion U0を作る。旧C0全81はC1のsubsetとして保護する。'
    new = '試行00147。2026-11-12、全73場の自然生成・取得・正逆観測と300比較を実行した。主U0は92取得、44順/19逆/23未到達/6不足＝69.84126984%・平均0.127615件/時。全場参加のみ達成、70%と頻度は未達で共同目標未達。新T0は5取得/4場・66.67%・C5差引−7,385円で、新しい型を採用達成とはしない。'
    assert old in readme
    readme = readme.replace(old, new, 1)
    readme = readme.replace('F0→全73自然Source→全物理取得/方向/alias固定→F1→凍結133正逆観測→300比較/独立算術/CSV/恒久保存の順で進める。実装人工・自然件数・率/損益の成功をここでは先取りしない。',
                            'F0→全73自然Source→全物理取得/方向/alias固定→F1→凍結133正逆観測→300比較/独立算術/CSVの順で実行した。実行前の正式3MDは先退避し、採用条件と元513セルを保持したうえで以下へ結果を追記する。')
    (FORMAL / 'README.md').write_text(readme.rstrip() + '\n\n' + draft, encoding='utf-8')
    condition_note = '''

## 固定後の実行案内

上記はF0/F1固定時の採用本文・review・未実行記録を保持したもので、現在の未実行宣言ではない。全73場の自然Source・取得・実正逆300比較とRoot別算術照合を完了した。主U0は92取得、44順/19逆/23未到達/6不足、到達済み44/63＝69.84126984%で70%未達。平均0.127615件/時も未達、全場最低1のみ達成し共同目標未達。新T0は5取得/4場で少数66.67%、C5差引−7,385円。採用条件・取得集合を結果後に変えず、型の採用達成とはしない。[実行結果](README.md#実行結果)を参照する。

元条件prefixと版7全513セル、実行前3MDは保持する。結果追記後の文書をF0/F1原文と同一SHAとは扱わない。work名は実行時識別子であり、恒久保存との対応は[保管索引](保管索引.json)と[再現手順](再現手順.md)を参照する。
'''
    (FORMAL / '条件.md').write_bytes(original['条件.md'] + condition_note.encode('utf-8'))
    note = ('> 現在は実行済み。主U0は92取得・69.84126984%・平均0.127615件/時で共同目標未達。'
            '以下の準備/未実行表はF0/F1原文記録で、現在結果は末尾の[固定後の実行結果](#固定後の実行結果)へ追記した。\n\n').encode('utf-8')
    raw = original['設定と結果.md']
    boundary = raw.index(b'\n', raw.index(b'\n') + 1) + 1
    tail = '\n\n## 固定後の実行結果\n\n全73場/実BBO/H60/同幅±125、147E01の現在結果。上の513セル・設定ID・未実行表はF0/F1原文を保持する。\n\n'
    tail += table(data, 'all', True)
    tail += '\n主は44/63＝69.84126984%で70%未達、H完了44/86＝51.16%、全取得44/92＝47.83%。全場最低1のみ達成、平均概ね1件/時も未達で共同目標未達。旧C1全87とC0subset全81は同体、新T0は5取得/4場・到達済み2/3＝66.67%で少数、C5差引−7,385円。全5件は前48所属、後25のT0は0件で率・金額null。\n\n'
    tail += '独立mini1枚100円/pt、往復77円、C5追加1,000円、Last金額null。主89件金額既知/3件未知と全H不足6を区別する。複合評価を指標単独効果・利益追尾・口座収支へ読み替えず、主をRU/別幅へ交換しない。前後区分・Source原因・CSV・恒久保存は[実行結果](README.md#実行結果)を参照する。\n'
    (FORMAL / '設定と結果.md').write_bytes(raw[:boundary] + note + raw[boundary:] + tail.encode('utf-8'))
    assert (FORMAL / '条件.md').read_bytes().startswith(original['条件.md'])
    assert (FORMAL / '設定と結果.md').read_bytes().replace(note, b'', 1).startswith(raw)
    extract = lambda text: [line for line in text.splitlines() if re.match(r'^\| [A-Z]\d{2} \|', line)]
    oldrows = extract(raw.decode('utf-8'))
    newrows = extract((FORMAL / '設定と結果.md').read_text(encoding='utf-8'))
    assert oldrows == newrows and len(oldrows) == 57
    assert all(len(line.split('|')[3:-1]) == 9 for line in oldrows)
    assert [fingerprint(p) for p in protected] == before
    proof = {'成功': True, '試行': 147, 'F1原文退避SHA256': BACKUP_SHA,
             '成果物': [fingerprint(FORMAL / n) for n in original],
             '指定正本': [fingerprint(p) for p in (SUMMARY, TABLES, SOURCE)],
             '条件prefix完全同体': True, '設定注記以外元原文prefix同体': True,
             '汎用表': {'版': 7, '手法': 57, '尺度': 9, 'セル': 513, '全行文字同体': True},
             '保護対象前後同体': before, '目次閲覧資料編集': False,
             'Source金融再計算': False, 'RawCSV追加2場読取': False,
             '更新器': fingerprint(Path(__file__)), 'Source節': fingerprint(OWN / 'Source要点.md')}
    (OWN / '文書反映の確認.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'formal': [x['sha256'] for x in proof['成果物']],
                      'proof_sha256': fingerprint(OWN / '文書反映の確認.json')['sha256']}))


if __name__ == '__main__':
    main()
