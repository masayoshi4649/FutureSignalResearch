"""147の正式3MDを保存正本・F1原文・停止診断から別に照合する。"""
from pathlib import Path
from fractions import Fraction
import argparse
import gzip
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
FORMAL = ROOT / 'study/00147_中位足の価格位置と短期実体回復から入口を生む'
POLICIES = ('U0', 'T0', 'C1', 'C0', 'RU')


def digest(path: Path) -> str:
    """
    機能: 現在の保存bytesの指紋を取得する。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(text: str) -> list[list[str]]:
    """
    機能: Markdownの表をセルへ分割する。
    引数: text(str)。返り値: list[list[str]]は空外周を除いた行。
    """
    return [line.split('|')[1:-1] for line in text.splitlines() if line.startswith('|')]


def policy_checks(text: str, summary: dict, detailed: bool) -> int:
    """
    機能: 文書表の件数・分母別率・金額を正本へ照合する。
    引数: text(str)、summary(dict)、detailed(bool)。返り値: intは一致数。
    """
    found = [r for r in rows(text) if r[0] in POLICIES and re.fullmatch(r'\d+ / \d+', r[1])]
    assert len(found) == 5
    count = 0
    for row in found:
        v = summary[row[0]]['BBO']['3600']['125']
        assert list(map(int, row[1].split('/'))) == [v['entries'], v['sessions']]
        assert list(map(int, row[2].split('/'))) == [v[k] for k in ('forward', 'adverse', 'neither', 'censored')]
        denoms = [v['resolved']]
        if detailed:
            denoms += [v['complete'], v['entries']]
        for cell, denominator in zip(row[3:], denoms):
            expected = '—（分母0）' if denominator == 0 else f"{v['forward'] / denominator:.2%}"
            assert cell == expected, (row[0], cell, expected)
        offset = 3 + len(denoms)
        for cell, key in zip(row[offset:], ('ifd_net5_profit', 'ifd_net5_loss', 'ifd_net5_sum', 'ifd_unknown'), strict=True):
            actual = None if cell == '—' else int(cell.replace(',', ''))
            assert actual == v[key], (row[0], key)
        count += 13 if detailed else 11
    return count


def main() -> None:
    """
    機能: 条件prefix・513セル・数値・リンク・保護源を確認し、停止票を作る。
    引数: CLI --allow-pending(bool)は恒久先未作成時の中間確認だけ。
    返り値: None。Source・金融・原板・CSVの再計算は行わない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--allow-pending', action='store_true')
    args = parser.parse_args()
    reflected = json.loads((OWN / '文書反映の確認.json').read_bytes())
    summary = json.loads((ROOT / 'work/147中位実体回復の評価/金融評価/集計.json').read_bytes())
    source = (ROOT / 'work/147中位実体回復の非金融診断/どこで細ったか.md').read_text(encoding='utf-8')
    readme = (FORMAL / 'README.md').read_text(encoding='utf-8')
    settings = (FORMAL / '設定と結果.md').read_text(encoding='utf-8')
    all_section = readme.split('## 実行結果\n', 1)[1].split('### 前48場', 1)[0]
    train = readme.split('### 前48場', 1)[1].split('### 後25場', 1)[0]
    validation = readme.split('### 後25場', 1)[1].split('## 状態遷移と次の問い', 1)[0]
    checked = policy_checks(all_section, summary['集計']['all'], True)
    checked += policy_checks(train, summary['集計']['train'], False)
    checked += policy_checks(validation, summary['集計']['validation'], False)
    checked += policy_checks(settings.split('## 固定後の実行結果', 1)[1], summary['集計']['all'], True)
    # ----------------------------------------
    # 停止済みSource短報を別に解析し、累積表を照合する。
    source_patterns = (
        ('当場隣接の形状窓', r'形状窓あり([\d,]+)'),
        ('配送time/indexのstrict順も成立', r'配送strict([\d,]+)'),
        ('p初価格/30方向/ATR/BBも成立', r'p初価格/30方向/ATR/BB([\d,]+)'),
        ('p逆実体も成立', r'p逆実体([\d,]+)'),
        ('p初5分EMA帯接触も成立', r'中位EMA帯接触([\d,]+)'),
        ('現在価格/30方向も成立', r'現在価格/30方向([\d,]+)'),
        ('15分DI方向/ADX非低下も成立', r'15分DI/ADX([\d,]+)'),
        ('5分Hist実増分も成立', r'5分Hist実増分([\d,]+)'),
        ('r順実体/p始値回復も成立', r'r実体/始値回復([\d,]+)'),
        ('同足量も成立', r'同足量([\d,]+)'),
        ('二尺度TR/freshも成立（技術完成）', r'二尺度TR/fresh([\d,]+)'),
    )
    source_checked = 0
    table_rows = {r[0]: r[1] for r in rows(readme) if len(r) == 2}
    for label, pattern in source_patterns:
        expected = int(re.search(pattern, source).group(1).replace(',', ''))
        assert int(table_rows[label].replace(',', '')) == expected
        source_checked += 1
    # ----------------------------------------
    # 現在率を丸めて合格にせず、原文保持と保護源の同体を直接確認する。
    assert Fraction(44, 63) < Fraction(7, 10)
    assert not summary['主評価']['到達済み先着70%以上']
    assert not summary['主評価']['三項目すべて達成']
    assert summary['主評価']['全73場最低1取得']
    assert '69.84126984%' in readme and '丸めて70%' in readme
    snapshot = json.loads(gzip.decompress((FORMAL / '検査/F1実行前文書.json.gz').read_bytes()))
    original_lookup = {r['path'].replace('\\', '/'): r for r in snapshot['文書']}
    originals = {name: original_lookup[(FORMAL / name).relative_to(ROOT).as_posix()]['本文'].encode('utf-8')
                 for name in ('README.md', '条件.md', '設定と結果.md')}
    assert (FORMAL / '条件.md').read_bytes().startswith(originals['条件.md'])
    header_note = re.search(r'^> 現在は実行済み。.*\n\n', settings, re.M).group(0)
    assert settings.replace(header_note, '', 1).encode('utf-8').startswith(originals['設定と結果.md'])
    original_rows = [r for r in originals['設定と結果.md'].decode('utf-8').splitlines() if re.match(r'^\| [A-Z]\d{2} \|', r)]
    current_rows = [r for r in settings.splitlines() if re.match(r'^\| [A-Z]\d{2} \|', r)]
    assert current_rows == original_rows and len(current_rows) == 57
    assert all(len(r.split('|')[3:-1]) == 9 for r in current_rows)
    for item in reflected['保護対象前後同体'] + reflected['成果物']:
        assert digest(ROOT / item['path']) == item['sha256']
    links, missing = 0, []
    for name in ('README.md', '条件.md', '設定と結果.md'):
        for target in re.findall(r'\]\(([^)]+)\)', (FORMAL / name).read_text(encoding='utf-8')):
            target = target.split('#', 1)[0]
            if target and '://' not in target:
                links += 1
                if not (FORMAL / target).exists():
                    missing.append([name, target])
    assert args.allow_pending or not missing, missing
    proof = {'成功': True, '試行': 147, '状態': '恒久先リンク待ち' if missing else '正式3MD結果反映を編集停止',
             '正式3MD': reflected['成果物'], '金融表の数値要素照合': checked,
             'Source累積表の停止短報との照合': source_checked,
             '元条件prefix完全同体': True, '元設定注記以外prefix同体': True,
             '版7全513セル文字同体': True, '69.84を70へ丸めず未達判定': True,
             '後25新T0の0件/null金額と率を保持': True,
             '保護源同体': len(reflected['保護対象前後同体']),
             'リンク数': links, '未作成リンク': missing,
             'Source金融再計算': False, 'RawCSV追加2場読取': False, '目次閲覧資料編集': False,
             '文書反映SHA256': digest(OWN / '文書反映の確認.json'),
             '更新器SHA256': digest(OWN / '更新する.py'), '確認器SHA256': digest(Path(__file__)),
             '草稿SHA256': digest(OWN / '結果草稿.md'), 'Source要点SHA256': digest(OWN / 'Source要点.md')}
    name = '中間の確認.json' if missing else '停止の確認.json'
    output = OWN / name
    output.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'proof': name, 'sha256': digest(output), 'numeric': checked,
                      'source': source_checked, 'links': links, 'missing': missing}, ensure_ascii=False))


if __name__ == '__main__':
    main()
