"""195の純T候補・初参加要求・実取得と旧口座の入替を分解する。"""
from pathlib import Path
from collections import Counter,defaultdict
import gzip
import hashlib
import json
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).parent
BASE=ROOT/'work/195保留中Tの技術根拠'
sys.path.insert(0,str(BASE))
sys.path.insert(0,str(ROOT/'work/181共用接続'))
import rules195 as R
import 共用181 as C


def read(path: Path) -> object:
    """
    機能: 固定JSONを読む。
    引数: path(Path)。
    返り値: object。
    """
    data=path.read_bytes();return json.loads(gzip.decompress(data) if path.suffix=='.gz' else data)


def save(path: Path,body: object) -> None:
    """
    機能: UTF-8のJSONを決定的に保存する。
    引数: path(Path)、body(object)。
    返り値: None。
    """
    data=(json.dumps(body,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode()
    path.write_bytes(gzip.compress(data,mtime=0) if path.suffix=='.gz' else data)


def rows(pack: dict) -> list:
    """
    機能: 実取得台帳を一件ずつの辞書へ変換する。
    引数: pack(dict)。
    返り値: list[dict]。
    """
    ledger=pack['ledger'];return [{k:v[i] for k,v in ledger.items()} for i in range(len(ledger['net']))]


def key(row: dict) -> tuple:
    """
    機能: 実取得時刻・実側・幅期限の同一性を定義する。
    引数: row(dict)。
    返り値: tuple。
    """
    return tuple(row[k] for k in ('scene','entry_time','entry_line','side','width','horizon'))


def summary(group: list) -> dict:
    """
    機能: 実取得だけから損益と未知・場数を集計する。
    引数: group(list[dict])。
    返り値: dict。未知を0円の確定損益へ変換しない。
    """
    values=[r['net'] for r in group if r['net'] is not None]
    return {'取得':len(group),'場':len({r['scene'] for r in group}),'未知':len(group)-len(values),
        '利益':sum(max(0,v) for v in values),'損失':-sum(min(0,v) for v in values),
        '既知収支':sum(values),'赤字':sum(v<0 for v in values)}


def main() -> None:
    """
    機能: 固定旧対照同体、T段階別件数、役割と実取得入替を診断する。
    引数: なし。
    返り値: None。診断と固定選択を保存する。
    """
    catalog=R.catalog();mapping={v['id']:v for v in catalog['rules']}
    comparison=read(BASE/'全候補比較.json.gz')
    diagnostics={leg:read(BASE/(leg+'_純成立診断.json.gz')) for leg in C.LEGS}
    packs={r['id']:read(BASE/'集約'/(r['id']+'.json.gz')) for r in comparison['rows']}
    scenes=[r['scene'] for r in next(iter(packs.values()))['sessions']]
    periods={'前48':set(scenes[:48]),'後25':set(scenes[48:73]),'追加7':set(scenes[73:80]),'本日1':set(scenes[80:]),'全80':set(scenes[:80]),'全81':set(scenes)}
    tables={}
    for identity,pack in packs.items():
        table=rows(pack)
        for row in table:
            d=diagnostics[row['leg']][pack['policy']['entry']];i=row['event']
            row['役割']=('LC' if row['added'] else '反転再開' if d.get('reverse_confirmed',[False]*(i+1))[i]
                else '順行切替' if d.get('follow_confirmed',[False]*(i+1))[i] else 'T' if row['origin']==2 else '旧幹')
            row['保留中T']=bool(row['origin']==2 and d.get('pending_t_signal',[False]*(i+1))[i])
        tables[identity]=table
    # ----------------------------------------
    result=[]
    for identity,table in tables.items():
        rule=mapping[identity.split('__')[0]];groups={}
        bases=['E195_00__C0_IFD']
        if 'base' in rule:bases.append(('E195_03' if rule['base']=='E193_04' else 'E195_04')+'__C0_IFD')
        for band,phases in {'DAY':{0},'NIGHT':{1,2},'PRE':{1},'POST':{2}}.items():
            for period,names in periods.items():
                picked=[r for r in table if r['scene'] in names and r['phase'] in phases]
                roles=defaultdict(list)
                for r in picked:roles[r['役割']].append(r)
                block={'全取得':summary(picked),'役割':{k:summary(v) for k,v in roles.items()},'比較':{}}
                for base in bases:
                    old=[r for r in tables[base] if r['scene'] in names and r['phase'] in phases]
                    oldkeys={key(r) for r in old};newkeys={key(r) for r in picked}
                    oldonly=[r for r in old if key(r) not in newkeys];newonly=[r for r in picked if key(r) not in oldkeys]
                    block['比較'][base]={'共通':summary([r for r in picked if key(r) in oldkeys]),
                        '旧のみ':summary(oldonly),'新のみ':summary(newonly),'旧のみ台帳':oldonly,'新のみ台帳':newonly}
                groups[band+'_'+period]=block
        result.append({'id':identity,'群':groups})
    save(HERE/'実取得の役割と入替195.json.gz',{'rows':result,'注意':'旧のみ/新のみは両政策の実取得。未参加の仮想利益ではない。'})
    # ----------------------------------------
    stage=[]
    for leg in C.LEGS:
        pure=C.load_pure_leg(leg);meta=pure['features'].q0_meta
        with np.load(BASE/(leg+'_新入口.npz'),allow_pickle=False) as raw:born={k:raw[k].copy() for k in raw.files}
        for identity,rule in mapping.items():
            if 'base' not in rule:continue
            d=diagnostics[leg][identity]
            original='E195_03' if rule['base']=='E193_04' else 'E195_04'
            pack=read(BASE/'期間別'/leg/(identity+'__C0_IFD.json.gz'));actual=rows(pack)
            basepack=read(BASE/'期間別'/leg/(original+'__C0_IFD.json.gz'))
            sceneinfo={r['scene']:r for r in pack['sessions']}
            first={}
            for r in actual:first[r['scene']]=min(first.get(r['scene'],float('inf')),r['entry_time'])
            requests={r['event']:r for r in pack['engine']['requests'] if r['origin']==2}
            base_requests={r['event']:r for r in basepack['engine']['requests'] if r['origin']==2}
            actual_by_event={r['event']:r for r in actual if r['origin']==2}
            original_rows=[]
            for i in np.flatnonzero(d['pending_t_signal']):
                i=int(i);seed=int(d['pending_t_from'][i]);scene=meta[i]['session'];time=float(meta[i]['q0_time'])
                sign=int(born[original+'__birth__technical'][i]);core=int(born[identity+'__birth__core'][i])
                direction=int(born['E195_00__birth__core'][seed]);request=requests.get(i);base_request=base_requests.get(i)
                first_eligible=sceneinfo[scene]['start']+2700<=time<min(first.get(scene,float('inf')),sceneinfo[scene]['end']-60)
                original_rows.append({'event':i,'scene':scene,'seed':seed,'T方向':sign,'保留反転方向':direction,
                    '元確認core上書き':bool(core),'反転方向と同じT':bool(sign and sign==direction),
                    '純許可':bool(d['pending_t_allowed'][i]),'純遮断':bool(d['pending_t_blocked'][i]),
                    '現在口座で45分後初取得前':bool(first_eligible),'実要求':request,
                    '親口座の同q0T要求':base_request,'実取得':actual_by_event.get(i)})
            counts=Counter()
            for r in original_rows:
                counts['保留中純T候補']+=1
                for name in ('元確認core上書き','反転方向と同じT','純許可','純遮断','現在口座で45分後初取得前'):counts[name]+=r[name]
                counts['実要求']+=r['実要求'] is not None
                counts['枠受理']+=bool(r['実要求'] and r['実要求']['accepted'])
                counts['実取得']+=r['実取得'] is not None
                counts['親口座の同q0T枠受理']+=bool(r['親口座の同q0T要求'] and r['親口座の同q0T要求']['accepted'])
            stage.append({'候補':identity,'期間':leg,'段階':dict(counts),'全行':original_rows})
    save(HERE/'純Tから初参加要求と取得195.json.gz',{'rows':stage,'注意':'保留は技術setup。未決注文や保有未知ではない。元core上書きの行をT実取得と数えない。'})
    # ----------------------------------------
    checks=[]
    for i,old in enumerate(R.CONTROLS):
        for leg in C.LEGS:
            fresh=read(BASE/'期間別'/leg/(f'E195_{i:02d}__C0_IFD.json.gz'))
            prior=read(ROOT/'work/193構造拡大停止と取得位置/期間別'/leg/(old+'__C0_IFD.json.gz'))
            for field in ('ledger','sessions','positions','evidence','periods','selection','engine'):
                assert fresh[field]==prior[field],(i,leg,field);checks.append([i,leg,field])
    condition=read(ROOT/'study/00195_保留中の補完入口を技術根拠で判別する/条件_NK225.json')
    for item in condition['Source']:assert hashlib.sha256((ROOT/item['path']).read_bytes()).hexdigest()==item['sha256'],item['path']
    save(HERE/'対照とSource同体195.json',{'成功':True,'対照':checks,'Source':len(condition['Source'])})
    for r in stage:print(json.dumps({k:v for k,v in r.items() if k!='全行'},ensure_ascii=False))
    print(json.dumps({'順位':comparison['順位']},ensure_ascii=False))


if __name__=='__main__':main()
