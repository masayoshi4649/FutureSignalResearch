"""機能: 125の主要80組を独立算術で照合し、元母集団と未知例を確認する。

引数: コマンドライン引数なし。Root許可済みの固定JSONを読み込む。
返り値: なし。全73場の独立検算.jsonを新規保存する。
"""

import copy
import hashlib
import importlib.util
import json
from pathlib import Path


def sha(path: Path) -> str:
    """機能: ファイルの全バイト指紋を求める。

    引数: path (Path) は確認するファイル。
    返り値: str はSHA256の小文字16進表記。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
SOURCE = ROOT / "work/124入口の正逆比較/全73場の正逆結果.json"
FEATURES = ROOT / "work/124当時特徴の診断/全79例の当時特徴.json"
CHOICES = ROOT / "work/125足の実体と反転切替/choices.json"
AGGREGATE = ROOT / "work/125足の実体と反転切替/集計.json"
TABLES = ROOT / "work/125足の実体と反転切替/CSV用の表.json"
F2 = ROOT / "work/125足の実体と反転切替/F2.json"
PRIOR = ROOT / "work/124入口の原因分析/集計.json"
HELPER = ROOT / "work/124正逆の独立検算/検算する.py"
FIXED = {
    SOURCE: "25517066b291a0434211190299b9f0195e67f9a7d2e89c801d5b9e6b4b51c3a1",
    FEATURES: "e4f0bf25156c1fe732b186c5c5d90b6e9f95718985a440d8eb7005588f734774",
    CHOICES: "16577b438f2de650c4398b313c2212fa124e812aea278e4dc00c529ffcb4c0a3",
    AGGREGATE: "e7a455deba346ac4cf1f1b2e6758a7a7301d1a6babaee0563891684100bf5c83",
    TABLES: "b7df2aaedc8aaf06dbc16f38555778a538b6f23acced7a0a7123c98907b7074a",
    F2: "ecf5222ca54cbbcf23bfa52713da77ec085cb6b5b6d3274f7d1f268a83659ff4",
    PRIOR: "1ca939bd2c619f6d2a3926999cb1b8e57726d48f2584b798cc6688e42ece49f8",
    HELPER: "0305f507a74f9728fbdb1ecabe406a3bfcb2f8657a4d1ee2556ca50dbe6585be",
}
BEFORE = {str(p): sha(p) for p in (*FIXED, Path(__file__).resolve())}
assert all(BEFORE[str(p)] == expected for p, expected in FIXED.items())
spec = importlib.util.spec_from_file_location("independent124_arithmetic", HELPER)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)

# ----------------------------------------
source = json.loads(SOURCE.read_text(encoding="utf-8"))
features = json.loads(FEATURES.read_text(encoding="utf-8"))
choices = json.loads(CHOICES.read_text(encoding="utf-8"))
aggregate = json.loads(AGGREGATE.read_text(encoding="utf-8"))
prior = json.loads(PRIOR.read_text(encoding="utf-8"))
f2 = json.loads(F2.read_text(encoding="utf-8"))
assert aggregate["成功"] and aggregate["試行"] == 125 and aggregate["主政策"] == "T1"
assert aggregate["主幅pt"] == f2["主幅pt"] == 125 and aggregate["主時間秒"] == f2["主秒"] == 3600
assert aggregate["元結果SHA256"] == FIXED[SOURCE] and aggregate["特徴SHA256"] == FIXED[FEATURES]
assert aggregate["選択票SHA256"] == FIXED[CHOICES]
assert aggregate["同一既知標本の事後仮説"] and not aggregate["独立検証"] and not aggregate["多重比較補正"]
assert not aggregate["口座収支"] and not aggregate["IFD実約定"]
assert choices["source_features_sha256"] == FIXED[FEATURES]
assert choices["policies"] == ["O0", "T1", "T2", "T3"]
fmap = {(r["session"], r["id"]): copy.deepcopy(r) for r in features["features"]}
cmap = {(r["session"], r["id"]): r for r in choices["choices"]}
assert len(fmap) == len(cmap) == 79 and list(fmap) == list(cmap)
flip_counts = {p: 0 for p in choices["policies"]}
for key, original in fmap.items():
    selected = cmap[key]
    assert selected["original_side"] == original["original_side"] and selected["strategy"] == original["strategy"]
    body, volume = original["features"]["candle5_body_signed_ratio"], original["features"]["rvol5"]
    hit = body["known"] and .5 <= body["value"] < .75
    expected = {"O0": False, "T1": hit, "T2": hit and original["strategy"] == "trend",
                "T3": hit and volume["known"] and 1 <= volume["value"] < 2}
    for policy, flip in expected.items():
        direction = selected["choices"][policy]
        assert direction["side"] == (-original["original_side"] if flip else original["original_side"])
        assert direction["action"] == ("flip" if flip else "keep")
        flip_counts[policy] += bool(flip)
    original["choices"] = selected["choices"]
assert flip_counts == choices["flip_counts"] == aggregate["反転数"] == {"O0": 0, "T1": 20, "T2": 9, "T3": 8}

# ----------------------------------------
records = []
sessions = []
for scene in source["scenes"]:
    assert scene["success"] and scene["cases"]
    sessions.append(scene["session"])
    for case in scene["cases"]:
        key = scene["session"], case["id"]
        feature = fmap[key]
        assert feature["entry_quote"] == case["original"]["entry"] == case["reverse"]["entry"]
        assert feature["original_side"] == case["original_side"]
        records.append({"session": scene["session"], "case": case, "feature": feature})
assert len(records) == len({(r['session'], r['case']['id']) for r in records}) == 79
assert len(sessions) == len(set(sessions)) == len({r["session"] for r in records}) == 73
assert aggregate["固定取得数"] == 79 and aggregate["全場数"] == 73
result = {}
values_checked = 0
for policy in choices["policies"]:
    result[policy] = {}
    for axis in ("BBO", "Last"):
        result[policy][axis] = {}
        for horizon in (1800, 3600):
            result[policy][axis][str(horizon)] = {}
            for width in (25, 50, 100, 125, 200):
                independent = helper.independent_stats(records, policy, axis, horizon, width)
                saved = aggregate["集計"][policy][axis][str(horizon)][str(width)]
                assert set(independent) == set(saved)
                for name, value in independent.items():
                    helper.equal(saved[name], value, f"{policy}/{axis}/{horizon}/{width}/{name}")
                    values_checked += 1
                result[policy][axis][str(horizon)][str(width)] = independent
assert result["O0"] == prior["集計"]["O0"]

# ----------------------------------------
unknown = []
for record in records:
    main = helper.pick(record, "T1", "BBO")
    evaluation = helper.ifd_value(main, 3600, 125, "BBO")
    if evaluation["known"]:
        continue
    assert evaluation["net0"] is None and evaluation["net5"] is None
    for policy in choices["policies"]:
        assert record["feature"]["choices"][policy]["action"] == "keep"
        assert helper.pick(record, policy, "BBO") is record["case"]["original"]
        assert helper.ifd_value(helper.pick(record, policy, "BBO"), 3600, 125, "BBO") == evaluation
    unknown.append({"session": record["session"], "id": record["case"]["id"],
                    "side": main["birth"]["side"], "status": helper.observation(main, 3600)["status"],
                    "全政策keep": True, "元IFD同体": True, "金額": None})
assert len(unknown) == 3
group = [r for r in records if r["feature"]["choices"]["T1"]["action"] == "flip"]
assert len(group) == 20
group_original = helper.independent_stats(group, "O0", "BBO", 3600, 125)
group_reverse = helper.independent_stats(group, "T1", "BBO", 3600, 125)
assert (group_original["forward"], group_original["adverse"], group_original["neither"]) == (4, 13, 3)
assert (group_reverse["forward"], group_reverse["adverse"], group_reverse["neither"]) == (12, 5, 3)
main = result["T1"]["BBO"]["3600"]["125"]
o0 = result["O0"]["BBO"]["3600"]["125"]
delta = main["ifd_net5_sum"] - o0["ifd_net5_sum"]
assert delta == group_reverse["ifd_net5_sum"] - group_original["ifd_net5_sum"]
AFTER = {str(p): sha(p) for p in (*FIXED, Path(__file__).resolve())}
assert BEFORE == AFTER
summary = {p: {a: {str(w): result[p][a]["3600"][str(w)] for w in (25, 100, 125)} for a in ("BBO", "Last")} for p in choices["policies"]}
proof = {"成功": True, "試行": 125, "主条件": ["T1", "BBO", 3600, 125],
         "前SHA256": BEFORE, "後SHA256": AFTER, "前後不変": True,
         "全場数": 73, "全例数": 79, "反転数": flip_counts,
         "選択票独立式照合数": 316, "全集計組数": 80, "集計値照合数": values_checked,
         "O0の124全指標同体": True, "未知3例": unknown, "C5主とO0の合計差": delta,
         "60分の主要幅": summary, "発見群20の元向き": group_original, "発見群20の逆向き": group_reverse,
         "計算": "自作124独立算術のFraction式を再用。125wrapper/Root集計関数を呼ばない。",
         "125wrapper再用": False, "Root集計import": False, "新金融再生": False,
         "限界": ["同一データで発見した群の探索内再評価。独立未知期検証ではない。",
                  "bootstrap再実装とCSV全表再構成は対象外。表JSONは指紋だけ確認。",
                  "未知3例を0円にしない。IFDは気配清算代用で実約定/口座収支ではない。"]}
OUT = BASE / "全73場の独立検算.json"
with OUT.open("x", encoding="utf-8", newline="\n") as stream:
    stream.write(json.dumps(proof, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
print(json.dumps({"成功": True, "出力SHA256": sha(OUT), "主T1": main, "C5主O0差": delta,
                  "集計値照合数": values_checked, "未知例数": len(unknown)}, ensure_ascii=False))
