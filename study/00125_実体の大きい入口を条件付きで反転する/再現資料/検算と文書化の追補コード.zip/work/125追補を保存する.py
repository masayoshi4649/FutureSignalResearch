"""125独立checkerと文書化器を、既124補助コードを参照して小型保管する。"""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[1]
FORMAL=ROOT/'study/00125_実体の大きい入口を条件付きで反転する'


def sha(data: bytes) -> str:
    """
    機能: バイト列のSHA256を返す。
    引数: data(bytes)。返り値: str。
    """
    return hashlib.sha256(data).hexdigest()


# ----------------------------------------
def save(path: Path, value: dict) -> None:
    """
    機能: 新規先へ日本語UTF-8の索引又は検査を保存する。
    引数: path(Path)、value(dict)。返り値: None。
    """
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')


# ----------------------------------------
def main() -> None:
    """
    機能: 独立checker/レビュー/完了と保存器をZIP化して全entryを同体照合する。
    引数: なし。返り値: None。金融計算はしない。
    """
    assert sha((FORMAL/'検査/独立検算.json').read_bytes())=='5e82485f15e490b25309541f07e958f63f9bb8570b4b2bcfc0a8490d08be27b8'
    sources=[ROOT/'work/125独立検算'/name for name in ('検算する.py','README.md','完了.json')]
    sources.extend(ROOT/'work'/name for name in ('125正式文書を仕上げる.py','125追補を保存する.py'))
    before={str(p.relative_to(ROOT)).replace('\\','/'):p.read_bytes() for p in sources}
    target=FORMAL/'再現資料/検算と文書化の追補コード.zip'
    with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for name,data in sorted(before.items()):
            info=zipfile.ZipInfo(name,date_time=(2026,11,11,0,0,0)); info.compress_type=zipfile.ZIP_DEFLATED
            archive.writestr(info,data,compresslevel=9)
    entries=[]
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None
        for name,data in sorted(before.items()):
            assert archive.read(name)==data==(ROOT/name).read_bytes()
            entries.append({'entry':name,'restore_relative':name,'bytes':len(data),'SHA256':sha(data),'CRC32':f'{archive.getinfo(name).CRC:08x}'})
    ref={'zip':'../../00124_逆行の原因と売買反転を同じ入口で検証する/再現資料/検算と保存の追補コード.zip','zip_SHA256':'b8c5158ddbf128df77594f61a04af60cc9c811a712201f488d5492f948f6d5e0','entry':'work/124正逆の独立検算/検算する.py','SHA256':'0305f507a74f9728fbdb1ecabe406a3bfcb2f8657a4d1ee2556ca50dbe6585be'}
    with zipfile.ZipFile(ROOT/'study/00124_逆行の原因と売買反転を同じ入口で検証する/再現資料/検算と保存の追補コード.zip') as archive:
        assert sha(archive.read(ref['entry']))==ref['SHA256']
    value={'試行':125,'用途':'金融後の独立検算と文書化、F2金融コードの変更なし','zip':{'path':target.name,'bytes':target.stat().st_size,'SHA256':sha(target.read_bytes())},'entries':entries,'外部復元':[ref]}
    save(FORMAL/'再現資料/追補コード復元索引.json',value)
    save(FORMAL/'検査/追補コード保管の確認.json',{'成功':True,'試行':125,'前後同体':True,'全ZIPentry再読CRC成功':True,**value})
    print(json.dumps({'成功':True,'ZIP':value['zip'],'entry数':len(entries),'外部コード参照数':1},ensure_ascii=False))


if __name__=='__main__':
    main()
