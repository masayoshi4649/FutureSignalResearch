"""124で発見した125条件を再評価前に固定し、正逆ペアの再利用だけで検証する。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import subprocess
import sys

ROOT=Path(__file__).resolve().parent.parent
OWN=ROOT/'work/125足の実体と反転切替'
FORMAL=ROOT/'study/00125_実体の大きい入口を条件付きで反転する'


def sha(path: Path) -> str:
    """
    機能: ファイルの全バイトを指紋化する。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 固定済み仮説の事前文書・コード・入力を同体に保ち評価する。
    引数: CLI --mode(str、固定/評価)。返り値: None。
    """
    parser=argparse.ArgumentParser(description='125のF2固定と評価')
    parser.add_argument('--mode',choices=('固定','評価'),required=True)
    mode=parser.parse_args().mode
    fixed=OWN/'F2.json'
    if mode=='固定':
        inputs=[ROOT/'work/124入口の正逆比較/全73場の正逆結果.json',ROOT/'work/124当時特徴の診断/全79例の当時特徴.json',OWN/'choices.json']
        code=list(OWN.glob('*.py'))+[Path(__file__).resolve(),ROOT/'work/124入口の原因分析/集計する.py']
        docs=[FORMAL/'README.md',FORMAL/'設定と結果.md',OWN/'条件.md']
        assert all(p.is_file() for p in inputs+code+docs)
        value={'試行':125,'成功':True,'固定UTC':datetime.now(timezone.utc).isoformat(),'主政策':'T1','主幅pt':125,'主秒':3600,
               '仮説':'元向き5分実体比[0.5,0.75)の20例のみ反転、全79/73を残す。T2/T3は既定の補助比較。',
               '限界':'124で選んだ群の同一データ再評価。独立未知期の検証や統計的有意性とはしない。',
               '入力':{str(p):sha(p) for p in inputs},'コード':{str(p):sha(p) for p in code},'事前文書':{str(p):sha(p) for p in docs}}
        with fixed.open('x',encoding='utf-8',newline='\n') as stream:
            stream.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
        print(json.dumps({'F2固定':True,'SHA256':sha(fixed)},ensure_ascii=False))
        return
    # ----------------------------------------
    f=json.loads(fixed.read_text(encoding='utf-8'))
    expected={**f['入力'],**f['コード'],**f['事前文書']}
    assert all(sha(Path(p))==s for p,s in expected.items())
    command=[sys.executable,'-X','utf8',str(OWN/'評価する.py'),'--evaluate-fixed-choices','16577b438f2de650c4398b313c2212fa124e812aea278e4dc00c529ffcb4c0a3']
    subprocess.run(command,cwd=ROOT,check=True)
    assert all(sha(Path(p))==s for p,s in expected.items())
    result={'試行':125,'成功':True,'F2_SHA256':sha(fixed),'入力コード文書前後不変':True,'コマンド':command,
            '集計SHA256':sha(OWN/'集計.json'),'表SHA256':sha(OWN/'CSV用の表.json')}
    with (OWN/'F2完了.json').open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':
    main()
