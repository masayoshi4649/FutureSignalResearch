"""固定済みの125選択票で124正逆ペアを選び、原板を再読せず比較する。"""
from pathlib import Path
import argparse
import copy
import hashlib
import importlib.util
import json

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
SOURCE = ROOT/'work/124入口の正逆比較/全73場の正逆結果.json'
SOURCE_SHA = '25517066b291a0434211190299b9f0195e67f9a7d2e89c801d5b9e6b4b51c3a1'
FEATURE = ROOT/'work/124当時特徴の診断/全79例の当時特徴.json'
FEATURE_SHA = 'e4f0bf25156c1fe732b186c5c5d90b6e9f95718985a440d8eb7005588f734774'
MODULE = ROOT/'work/124入口の原因分析/集計する.py'
MODULE_SHA = '8479ca348231ffd77a637360797750833c9e6617c7fc4a6502e015c7a1d9f04a'
CHOICES_SHA = '16577b438f2de650c4398b313c2212fa124e812aea278e4dc00c529ffcb4c0a3'
SPEC_SHA = '73e64c419fd643a25683f1b1dbae0f34a796ae7880c6c7b786e9e86fd1d729ad'
POLICIES = ('O0', 'T1', 'T2', 'T3')


def sha(path: Path) -> str:
    """
    機能: ファイルの全バイト指紋を求める。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def load_module(path: Path, name: str):
    """
    機能: 原文を変更せず、mainを呼ばずに計算関数を読み込む。
    引数: path(Path)、name(str)。返り値: 読込済みPythonモジュール。
    """
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# ----------------------------------------
def prepare_records(data: dict, features: dict, choices: dict, chooser) -> tuple[list[dict], list[str]]:
    """
    機能: 選択票と実BBO正逆を全件対応させ、新特徴のchoicesだけを差し替える。
    引数: data/features/choices(dict)、chooser(モジュール)。返り値: tuple[list[dict],list[str]]。
    """
    assert data['success'] and data['trial'] == 124 and len(data['scenes']) == 73
    assert features['success'] and features['trial'] == 124
    assert choices['success'] and choices['trial'] == 125
    assert choices['source_features_sha256'] == FEATURE_SHA
    assert choices['spec_sha256'] == SPEC_SHA
    assert tuple(choices['policies']) == POLICIES
    original = features['features']
    copied = copy.deepcopy(original)
    fmap = {(f['session'], f['id']): f for f in copied}
    fixed = {(f['session'], f['id']): f for f in choices['choices']}
    assert len(fmap) == len(fixed) == len(original) == 79
    for before, after in zip(original, copied):
        key = after['session'], after['id']
        c = fixed[key]
        for field in ('original_side', 'strategy', 'path', 'birth'):
            assert c[field] == before[field]
        assert c['body'] == before['features']['candle5_body_signed_ratio']
        assert c['rvol5'] == before['features']['rvol5']
        expected = chooser.choose(before['original_side'], before['strategy'], before['features'])
        assert c['choices'] == expected
        after['choices'] = {p: copy.deepcopy(c['choices'][p]) for p in ('T1', 'T2', 'T3')}
        restored = copy.deepcopy(after)
        restored['choices'] = before['choices']
        assert restored == before
    # ----------------------------------------
    records = []
    sessions = []
    seen = set()
    for scene in data['scenes']:
        assert scene['success'] and scene['cases']
        sid = scene['session']
        assert sid not in sessions
        sessions.append(sid)
        for case in scene['cases']:
            key = sid, case['id']
            assert key in fmap and key not in seen
            seen.add(key)
            f = fmap[key]
            side = case['original_side']
            assert side == f['original_side']
            assert case['original']['birth']['side'] == side
            assert case['reverse']['birth']['side'] == -side
            q = case['original']['entry']
            assert q == case['reverse']['entry'] == f['entry_quote']
            assert case['original']['entry_price'] == (q['ask'] if side == 1 else q['bid'])
            assert case['reverse']['entry_price'] == (q['bid'] if side == 1 else q['ask'])
            assert case['original']['entry_price'] == f['entry_price']
            for name in ('chart_original', 'chart_reverse'):
                chart = case[name]
                assert chart['entry'] == q and chart['entry_price'] == q['last']
                assert chart['birth']['side'] == (side if name == 'chart_original' else -side)
                assert all(o['net0'] is None and o['net5'] is None for o in chart['outcomes'])
            records.append({'session': sid, 'case': case, 'feature': f})
    assert seen == set(fmap) == set(fixed) and len(records) == 79 and len(sessions) == 73
    assert {p: sum(chooser.choose(f['original_side'], f['strategy'], f['features'])[p]['action'] == 'flip' for f in original) for p in POLICIES} == choices['flip_counts']
    return records, sessions


# ----------------------------------------
def tables_for(records: list[dict], sessions: list[str], aggregate: dict, module, choices: dict) -> list[dict]:
    """
    機能: 80比較・全79入口・全73場の3表を同じ集計値から作る。
    引数: records(list[dict])、sessions(list[str])、aggregate(dict)、module(モジュール)、choices(dict)。返り値: list[dict]。
    """
    headers = ['試行','政策','価格軸','評価分','同幅pt','取得場数','取得数','反転数','全H完了','観測不足','順行先着','逆行先着','両方未到達','到達済み順行率','全完了順行率','到達済み70%達成','IFD代用既知清算','IFD代用未知','C0代用合計円','C5代用利益円','C5代用損失絶対円','C5代用差引円','C5代用平均円','C5代用PF']
    rows = []
    for policy in POLICIES:
        for axis in module.AXES:
            for horizon in module.HORIZONS:
                for width in module.WIDTHS:
                    s = aggregate[policy][axis][str(horizon)][str(width)]
                    rows.append([125,policy,axis,horizon/60,width,s['sessions'],s['entries'],s['flips'],s['complete'],s['censored'],s['forward'],s['adverse'],s['neither'],s['resolved_rate'],s['complete_rate'],s['target70'],s['ifd_known'],s['ifd_unknown'],s['ifd_net0_sum'],s['ifd_net5_profit'],s['ifd_net5_loss'],s['ifd_net5_sum'],s['ifd_net5_mean'],s['ifd_net5_pf']])
    # ----------------------------------------
    detail_headers = ['試行','セッション','出生ID','入口型','元向き','取得JST','元取得価格','逆取得価格','spread','元向き5分実体比','実体比既知','RVOL','RVOL既知','特徴正本参照']
    for p in POLICIES:
        detail_headers += [p+'選択',p+'理由',p+'向き',p+'125BBO全H',p+'125BBO先着',p+'125Last全H',p+'125Last先着',p+'125IFD代用既知',p+'125C5代用円']
    fixed = {(r['session'],r['id']):r for r in choices['choices']}
    detail_rows = []
    for r in records:
        f, case = r['feature'], r['case']
        c = fixed[r['session'],case['id']]
        q = case['original']['entry']
        row = [125,r['session'],case['id'],f['strategy'],'買' if case['original_side']==1 else '売',module.jst(q['time']),case['original']['entry_price'],case['reverse']['entry_price'],q['ask']-q['bid'],c['body']['value'],c['body']['known'],c['rvol5']['value'],c['rvol5']['known'],c['feature_ref']]
        for p in POLICIES:
            selection = c['choices'][p]
            bbo = module.selected(r,p,'BBO')
            bo = module.observation(bbo,3600)
            lo = module.observation(module.selected(r,p,'Last'),3600)
            e = module.ifd(bbo,bo,125,'BBO')
            row += [selection['action'],selection['reason'],'買' if selection['side']==1 else '売',bo['status'],module.touch(bo,125)['direction'],lo['status'],module.touch(lo,125)['direction'],e['known'],e['net5']]
        detail_rows.append(row)
    # ----------------------------------------
    session_headers = ['試行','セッション','取得数','最低1回達成']
    for p in POLICIES:
        session_headers += [p+'反転数',p+'125順',p+'125逆',p+'125未到達',p+'全H観測不足',p+'IFD代用既知',p+'IFD代用未知',p+'C5代用利益円',p+'C5代用損失絶対円',p+'C5代用既知差引円',p+'C5代用既知累計円（口座収支ではない）',p+'累計IFD代用未知数']
    cumulative = {p:0 for p in POLICIES}
    unknown = {p:0 for p in POLICIES}
    session_rows = []
    for sid in sessions:
        subset = [r for r in records if r['session']==sid]
        row = [125,sid,len(subset),bool(subset)]
        for p in POLICIES:
            s = module.stats(subset,p,'BBO',3600,125)
            if s['ifd_net5_sum'] is not None:
                cumulative[p] += s['ifd_net5_sum']
            unknown[p] += s['ifd_unknown']
            row += [s['flips'],s['forward'],s['adverse'],s['neither'],s['censored'],s['ifd_known'],s['ifd_unknown'],s['ifd_net5_profit'],s['ifd_net5_loss'],s['ifd_net5_sum'],cumulative[p],unknown[p]]
        session_rows.append(row)
    tables = [{'name':'正逆比較','headers':headers,'rows':rows},
              {'name':'入口別診断','headers':detail_headers,'rows':detail_rows},
              {'name':'全セッション','headers':session_headers,'rows':session_rows}]
    assert [len(t['rows']) for t in tables] == [80,79,73]
    assert all(all(len(row)==len(t['headers']) for row in t['rows']) for t in tables)
    return tables


# ----------------------------------------
def main() -> None:
    """
    機能: Root固定後の明示引数を要求し、固定ペアを初めて読み評価する。
    引数: CLIの--evaluate-fixed-choices(str)は固定選択票SHA。返り値: None。
    """
    parser = argparse.ArgumentParser(description='125固定後にのみ実行する探索内比較')
    parser.add_argument('--evaluate-fixed-choices', required=True)
    args = parser.parse_args()
    assert args.evaluate_fixed_choices == CHOICES_SHA
    checks = {SOURCE:SOURCE_SHA, FEATURE:FEATURE_SHA, MODULE:MODULE_SHA,
              OWN/'choices.json':CHOICES_SHA, OWN/'条件.md':SPEC_SHA}
    for path, expected in checks.items():
        assert sha(path) == expected, str(path)
    assert not (OWN/'集計.json').exists() and not (OWN/'CSV用の表.json').exists()
    module = load_module(MODULE,'fixed_aggregate124_for125')
    module.POLICIES = POLICIES
    chooser = load_module(OWN/'choicesを作る.py','fixed_choices125')
    assert chooser.sha(OWN/'choicesを作る.py') == json.loads((OWN/'choices.json').read_text(encoding='utf-8'))['selection_code_sha256']
    data = json.loads(SOURCE.read_text(encoding='utf-8'))
    features = json.loads(FEATURE.read_text(encoding='utf-8'))
    fixed = json.loads((OWN/'choices.json').read_text(encoding='utf-8'))
    records, sessions = prepare_records(data,features,fixed,chooser)
    aggregate = {p:{axis:{str(h):{str(w):module.stats(records,p,axis,h,w) for w in module.WIDTHS} for h in module.HORIZONS} for axis in module.AXES} for p in POLICIES}
    result = {'成功':True,'試行':125,'主政策':'T1','主幅pt':125,'主時間秒':3600,'全場数':73,'固定取得数':79,
              '元結果SHA256':SOURCE_SHA,'特徴SHA256':FEATURE_SHA,'条件SHA256':SPEC_SHA,'選択票SHA256':CHOICES_SHA,
              '再用集計コードSHA256':MODULE_SHA,'評価コードSHA256':sha(Path(__file__)),
              '反転数':fixed['flip_counts'],'集計':aggregate,'bootstrap':module.bootstrap(records,sessions),
              '同一既知標本の事後仮説':True,'独立検証':False,'多重比較補正':False,'口座収支':False,'IFD実約定':False,
              '価格参考':'Last軸の金額は全てNone。原板Lastの方向診断であり約定できたとは扱わない。'}
    tables = tables_for(records,sessions,aggregate,module,fixed)
    for path, expected in checks.items():
        assert sha(path) == expected, str(path)
    module.save(OWN/'集計.json',result)
    module.save(OWN/'CSV用の表.json',{'試行':125,'成功':True,'result_sha256':SOURCE_SHA,'choices_sha256':CHOICES_SHA,
                '意味':'固定取得の一部正逆切替。独立1miniのIFD即時気配清算代用、口座収支と実IFDではない。','tables':tables})
    module.save(OWN/'評価完了.json',{'成功':True,'試行':125,'入力指紋前後不変':True,
                '集計SHA256':sha(OWN/'集計.json'),'表SHA256':sha(OWN/'CSV用の表.json'),
                '元ペアSHA256':SOURCE_SHA,'選択票SHA256':CHOICES_SHA,'評価コードSHA256':sha(Path(__file__)),
                'CSV行数':[len(t['rows']) for t in tables]})
    print(json.dumps({'成功':True,'試行':125,'CSV行数':[len(t['rows']) for t in tables],
                      '主125H60':{p:aggregate[p]['BBO']['3600']['125'] for p in POLICIES}},ensure_ascii=False))


if __name__ == '__main__':
    main()
