"""125の選択票を当時特徴だけから作り、金融結果を読まずに固定する。"""
from pathlib import Path
from collections import Counter
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
SOURCE = ROOT / 'work/124当時特徴の診断/全79例の当時特徴.json'
SOURCE_SHA = 'e4f0bf25156c1fe732b186c5c5d90b6e9f95718985a440d8eb7005588f734774'
POLICIES = ('O0', 'T1', 'T2', 'T3')


def sha(path: Path) -> str:
    """
    機能: ファイルの全バイト指紋を求める。
    引数: path(Path)は確認先。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def save(path: Path, value: dict) -> None:
    """
    機能: 未作成先へUTF-8でJSONを保存する。
    引数: path(Path)、value(dict)。返り値: None。
    """
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


# ----------------------------------------
def known_number(features: dict, key: str) -> tuple[bool, float | None]:
    """
    機能: 未知と既知0を区別し、既知の有限数だけを取り出す。
    引数: features(dict)、key(str)。返り値: tuple[bool,float|None]。
    """
    field = features.get(key, {'known': False, 'value': None})
    assert type(field['known']) is bool
    if not field['known']:
        assert field.get('value') is None
        return False, None
    value = field['value']
    assert type(value) in (int, float) and math.isfinite(value)
    return True, value


# ----------------------------------------
def choose(side: int, strategy: str, features: dict) -> dict:
    """
    機能: 元向き実体比と既知RVOLで4政策の正逆方向を選ぶ。
    引数: side(int)は±1、strategy(str)、features(dict)。返り値: dictは全政策の選択票。
    """
    assert side in (-1, 1)
    bk, body = known_number(features, 'candle5_body_signed_ratio')
    vk, volume = known_number(features, 'rvol5')
    body_group = bk and .5 <= body < .75
    flags = {'O0': False, 'T1': body_group,
             'T2': body_group and strategy == 'trend',
             'T3': body_group and vk and 1 <= volume < 2}
    output = {}
    for policy in POLICIES:
        flip = bool(flags[policy])
        if policy == 'O0':
            reason = '元向きの固定対照'
        elif not bk:
            reason = '実体比が未知のため元向き保持'
        elif not body_group:
            reason = '実体比が[0.5,0.75)の外のため元向き保持'
        elif policy == 'T2' and strategy != 'trend':
            reason = '元strategyがtrend以外のため元向き保持'
        elif policy == 'T3' and not vk:
            reason = 'RVOLが未知のため元向き保持'
        elif policy == 'T3' and not (1 <= volume < 2):
            reason = 'RVOLが[1,2)の外のため元向き保持'
        else:
            reason = '元向き5分実体比[0.5,0.75)' + ('かつtrend' if policy == 'T2' else 'かつRVOL[1,2)' if policy == 'T3' else '') + 'のため実逆方向'
        output[policy] = {'side': -side if flip else side, 'action': 'flip' if flip else 'keep',
                          'reason': reason, 'body_group': bool(body_group),
                          'known': {'body': bk, 'rvol5': vk}}
    return output


# ----------------------------------------
def artificial_tests() -> dict:
    """
    機能: 下端・上端・未知・買売鏡像・限定条件を人工値で検査する。
    引数: なし。返り値: dictは検査件数。
    """
    checks = 0
    cases = ((None, None), (-.5, 1.5), (0, 1.5), (.499999, 1.5),
             (.5, 1), (.6, 1.999999), (.749999, 2), (.75, 1.5), (.6, None), (.6, .999999))
    for body, volume in cases:
        fs = {'candle5_body_signed_ratio': {'known': body is not None, 'value': body},
              'rvol5': {'known': volume is not None, 'value': volume}}
        for strategy in ('trend', 'reversal', 'deadline', 'E0'):
            expected_body = body is not None and .5 <= body < .75
            expected = (False, expected_body, expected_body and strategy == 'trend',
                        expected_body and volume is not None and 1 <= volume < 2)
            buy, sell = choose(1, strategy, fs), choose(-1, strategy, fs)
            for policy, flip in zip(POLICIES, expected):
                assert buy[policy]['side'] == (-1 if flip else 1)
                assert sell[policy]['side'] == -buy[policy]['side']
                assert sell[policy]['action'] == buy[policy]['action']
                checks += 1
    # ----------------------------------------
    # 実価格K−priceでO/Cを反転しH/Lを入れ替えると、売買を反転した符号付き実体比は同じ。
    for o, h, l, c in ((100., 200., 100., 150.), (110., 200., 100., 170.), (110., 200., 100., 185.)):
        for side in (-1, 1):
            body = side * (c - o) / (h - l)
            mo, mh, ml, mc = 1000-o, 1000-l, 1000-h, 1000-c
            mirrored = -side * (mc - mo) / (mh - ml)
            assert body == mirrored
            fs = {'candle5_body_signed_ratio': {'known': True, 'value': body}}
            ms = {'candle5_body_signed_ratio': {'known': True, 'value': mirrored}}
            assert all(choose(side, 'trend', fs)[p]['side'] == -choose(-side, 'trend', ms)[p]['side'] for p in POLICIES)
            checks += 1
    return {'成功': True, '境界と限定条件': 160, 'OHLC価格鏡像': 6, '合計': checks}


# ----------------------------------------
def main() -> None:
    """
    機能: 人工検査後、許可済み当時特徴だけから全79件の選択票を作る。
    引数: なし。返り値: None。金融結果・原板・分足を開かない。
    """
    proof = artificial_tests()
    assert sha(SOURCE) == SOURCE_SHA
    original_bytes = SOURCE.read_bytes()
    data = json.loads(original_bytes)
    assert data['success'] and data['trial'] == 124
    rows = data['features']
    assert len(rows) == 79 and len({r['session'] for r in rows}) == 73
    assert len({(r['session'], r['id']) for r in rows}) == 79
    output = []
    for row in rows:
        assert row['original_side'] in (-1, 1)
        body = row['features']['candle5_body_signed_ratio']
        volume = row['features']['rvol5']
        bq, eq = row['birth_quote'], row['entry_quote']
        assert all(bq[k] <= eq[k] for k in ('time', 'index', 'source_line'))
        assert row['refs'] and any(r['width_seconds'] == 300 for r in row['refs'])
        assert all(r['delivered']['time'] <= bq['time'] for r in row['refs'])
        selected = choose(row['original_side'], row['strategy'], row['features'])
        output.append({'session': row['session'], 'id': row['id'], 'original_side': row['original_side'],
                       'strategy': row['strategy'], 'path': row['path'], 'birth': row['birth'],
                       'entry': {k: eq[k] for k in ('time', 'index', 'source_line')},
                       'body': body, 'rvol5': volume, 'rvol_source': row['rvol_source'],
                       'choices': selected,
                       'feature_ref': f"{SOURCE.relative_to(ROOT).as_posix()}:{row['session']}:{row['id']}"})
    assert sha(SOURCE) == SOURCE_SHA
    flip_counts = {p: sum(r['choices'][p]['action'] == 'flip' for r in output) for p in POLICIES}
    assert flip_counts['O0'] == 0
    assert all(r['choices']['T1']['action'] == 'flip' for r in output if r['choices']['T2']['action'] == 'flip' or r['choices']['T3']['action'] == 'flip')
    destination = OWN / 'choices.json'
    save(destination, {'trial': 125, 'success': True, 'primary': 'T1', 'policies': list(POLICIES),
                       'source_features_sha256': SOURCE_SHA, 'spec_sha256': sha(OWN/'条件.md'),
                       'selection_code_sha256': sha(Path(__file__)), 'financial_results_read': False,
                       'exploratory_in_sample': True, 'entries': 79, 'sessions': 73,
                       'flip_counts': flip_counts, 'choices': output})
    save(OWN/'選択票生成の確認.json', {'成功': True, '試行': 125, '人工検査': proof,
          '元特徴SHA256前後': SOURCE_SHA, '元特徴変更なし': SOURCE.read_bytes() == original_bytes,
          '条件SHA256': sha(OWN/'条件.md'), '選択コードSHA256': sha(Path(__file__)),
          '選択票SHA256': sha(destination), '全場': 73, '全件': 79, '政策反転数': flip_counts,
          '戦略別元件数': dict(Counter(r['strategy'] for r in output)), '金融結果を参照したか': False})
    print(json.dumps({'成功': True, '政策反転数': flip_counts, '選択票SHA256': sha(destination),
                      '条件SHA256': sha(OWN/'条件.md'), '人工検査': proof}, ensure_ascii=False))


if __name__ == '__main__':
    main()
