"""自然の価格・特徴・結果を開かず、125選択と集計の接続を人工79件で検査する。"""
from pathlib import Path
import copy
import importlib.util
import unittest

OWN = Path(__file__).resolve().parent


def load(path: Path, name: str):
    """
    機能: mainを呼ばずに人工検査対象を読み込む。
    引数: path(Path)、name(str)。返り値: 読込済みモジュール。
    """
    spec = importlib.util.spec_from_file_location(name,path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# ----------------------------------------
evaluation = load(OWN/'評価する.py','evaluation125_artificial')
chooser = load(OWN/'choicesを作る.py','chooser125_artificial')
aggregate = load(evaluation.MODULE,'aggregate124_artificial125')
aggregate.POLICIES = evaluation.POLICIES


def fixture() -> tuple[dict,dict,dict]:
    """
    機能: 買売・両側損失・H不足・未知・政策境界を含む人工79件73場を作る。
    引数: なし。返り値: tuple[dict,dict,dict]は人工ペア・特徴・固定票。
    """
    scenes = [{'session':f'人工{i:02d}','success':True,'cases':[]} for i in range(73)]
    features, choices = [], []
    for i in range(79):
        sid = scenes[i%73]['session']
        side = 1 if i%2==0 else -1
        q = {'time':10000.+i,'index':i+1,'source_line':i+1,'bid':1000.,'ask':1010.,'last':1005.}
        # ----------------------------------------
        # 最初の例は広いspread内だけの変化で±25双方逆、他は原価格上昇とする。
        end = dict(q,time=q['time']+3600,index=1000+i,source_line=1000+i,
                   bid=980. if i==0 else 1210.,ask=1030. if i==0 else 1220.,last=1005. if i==0 else 1215.)
        key = f'人工ID{i}'
        case = {'id':key,'original_side':side}
        for axis in ('BBO','Last'):
            for reverse in (False,True):
                direction = -side if reverse else side
                price = q['last'] if axis=='Last' else q['ask'] if direction==1 else q['bid']
                mark = end['last'] if axis=='Last' else end['bid'] if direction==1 else end['ask']
                points = direction*(mark-price)
                outcomes = []
                for seconds in (1800,3600):
                    endpoint = dict(end,time=q['time']+seconds)
                    touch = [{'width':w,'direction':1 if points>=w else -1 if points<=-w else 0,
                              'quote':endpoint if abs(points)>=w else None} for w in aggregate.WIDTHS]
                    status = 'complete'
                    if i in (1,2):
                        status = 'raw_gap'
                        endpoint = None
                        touch = [{'width':w,'direction':1 if i==1 and w==25 else 0,
                                  'quote':end if i==1 and w==25 else None} for w in aggregate.WIDTHS]
                    outcomes.append({'seconds':seconds,'deadline':q['time']+seconds,'status':status,
                                     'endpoint':endpoint,'points':points if status=='complete' else None,
                                     'net0':points*100-77 if axis=='BBO' and status=='complete' else None,
                                     'net5':points*100-1077 if axis=='BBO' and status=='complete' else None,
                                     'touches':touch})
                name = ('chart_' if axis=='Last' else '')+('reverse' if reverse else 'original')
                case[name] = {'birth':{'side':direction},'entry':q,'entry_price':price,'outcomes':outcomes}
        body = (None,.5,.749999,.75,.6)[i%5]
        volume = (None,1.,1.999999,2.,.5)[i%5]
        fs = {'candle5_body_signed_ratio':{'known':body is not None,'value':body},
              'rvol5':{'known':volume is not None,'value':volume}}
        strategy = ('trend','deadline','reversal','E0')[i%4]
        birth = {'time':q['time']-1,'index':q['index'],'source_line':q['source_line']}
        f = {'session':sid,'id':key,'original_side':side,'strategy':strategy,'path':'strong',
             'birth':birth,'entry_quote':q,'entry_price':case['original']['entry_price'],
             'features':fs,'choices':{'T1':{'旧票':'変更不可の原本'}},'人工':True}
        c = {'session':sid,'id':key,'original_side':side,'strategy':strategy,'path':'strong',
             'birth':birth,'body':fs['candle5_body_signed_ratio'],'rvol5':fs['rvol5'],
             'feature_ref':'人工だけ','choices':chooser.choose(side,strategy,fs)}
        scenes[i%73]['cases'].append(case)
        features.append(f)
        choices.append(c)
    return ({'success':True,'trial':124,'scenes':scenes},
            {'success':True,'trial':124,'features':features},
            {'success':True,'trial':125,'source_features_sha256':evaluation.FEATURE_SHA,
             'spec_sha256':evaluation.SPEC_SHA,'policies':list(evaluation.POLICIES),'choices':choices,
             'flip_counts':{p:sum(c['choices'][p]['action']=='flip' for c in choices) for p in evaluation.POLICIES}})


# ----------------------------------------
class Artificial125(unittest.TestCase):
    """自然結果を使わない125の機械検査。"""

    def test_boundaries(self) -> None:
        """
        機能: 選択関数の境界・未知・鏡像を検査する。
        引数: self(Artificial125)。返り値: None。
        """
        self.assertEqual(chooser.artificial_tests()['合計'],166)

    def test_deepcopy_and_all_scenes(self) -> None:
        """
        機能: 全79/73対応と原特徴不変を検査する。
        引数: self(Artificial125)。返り値: None。
        """
        data,features,choices = fixture()
        before = copy.deepcopy(features)
        records,sessions = evaluation.prepare_records(data,features,choices,chooser)
        self.assertEqual((len(records),len(sessions)),(79,73))
        self.assertEqual(features,before)
        for record in records:
            self.assertEqual(set(record['feature']['choices']),{'T1','T2','T3'})

    def test_actual_side_touch_before_censor_and_last_nil(self) -> None:
        """
        機能: 実方向選択・spread双方損失・既知touch優先・Last金額nilを検査する。
        引数: self(Artificial125)。返り値: None。
        """
        data,features,choices = fixture()
        records,_ = evaluation.prepare_records(data,features,choices,chooser)
        for reverse in ('original','reverse'):
            self.assertEqual(aggregate.touch(aggregate.observation(records[0]['case'][reverse],3600),25)['direction'],-1)
        for record in records:
            for policy in evaluation.POLICIES:
                selected = aggregate.selected(record,policy,'BBO')
                expected = record['case']['original_side'] if policy=='O0' else record['feature']['choices'][policy]['side']
                self.assertEqual(selected['birth']['side'],expected)
                last = aggregate.selected(record,policy,'Last')
                for width in aggregate.WIDTHS:
                    self.assertIsNone(aggregate.ifd(last,aggregate.observation(last,3600),width,'Last')['net5'])
        candidate = next(r['case']['original'] for r in records if r['case']['id']=='人工ID1')
        self.assertTrue(aggregate.ifd(candidate,aggregate.observation(candidate,3600),25,'BBO')['known'])
        self.assertFalse(aggregate.ifd(candidate,aggregate.observation(candidate,3600),125,'BBO')['known'])

    def test_all_tables_and_bootstrap(self) -> None:
        """
        機能: 80/79/73表と全73場bootstrapの接続を検査する。
        引数: self(Artificial125)。返り値: None。
        """
        data,features,choices = fixture()
        records,sessions = evaluation.prepare_records(data,features,choices,chooser)
        output = {p:{axis:{str(h):{str(w):aggregate.stats(records,p,axis,h,w) for w in aggregate.WIDTHS}
                                 for h in aggregate.HORIZONS} for axis in aggregate.AXES} for p in evaluation.POLICIES}
        tables = evaluation.tables_for(records,sessions,output,aggregate,choices)
        self.assertEqual([len(t['rows']) for t in tables],[80,79,73])
        self.assertTrue(all(row[3] for row in tables[2]['rows']))
        bootstrap = aggregate.bootstrap(records,sessions)
        self.assertEqual(set(bootstrap['政策']),set(evaluation.POLICIES))
        self.assertEqual(bootstrap['seed'],124)
        self.assertEqual(bootstrap['回数'],5000)


if __name__ == '__main__':
    unittest.main(verbosity=2)
