"""125のF2原文とコード・集計を恒久保存する。Raw再生と金融再集計は行わない。"""
from pathlib import Path
import gzip
import hashlib
import json
import shutil
import zipfile

ROOT=Path(__file__).resolve().parents[1]
FORMAL=ROOT/'study/00125_実体の大きい入口を条件付きで反転する'
WORK=ROOT/'work/125足の実体と反転切替'


def sha(data: bytes) -> str:
    """
    機能: 与えたバイト列のSHA256を返す。
    引数: data(bytes)。返り値: strは小文字16進表記。
    """
    return hashlib.sha256(data).hexdigest()


# ----------------------------------------
def save(path: Path, value: dict) -> None:
    """
    機能: 未作成先にUTF-8の証跡を保存する。
    引数: path(Path)、value(dict)。返り値: None。
    """
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')


# ----------------------------------------
def compact(source: bytes, target: Path) -> dict:
    """
    機能: 元bytesを一つのgzipへ可逆保存して指紋を記録する。
    引数: source(bytes)、target(Path)。返り値: dictは保存/解凍指紋。
    """
    data=gzip.compress(source,compresslevel=9,mtime=0)
    with target.open('xb') as stream: stream.write(data)
    assert gzip.decompress(target.read_bytes())==source
    return {'path':str(target.relative_to(FORMAL)).replace('\\','/'),'bytes':len(data),'SHA256':sha(data),'解凍bytes':len(source),'解凍SHA256':sha(source)}


# ----------------------------------------
def main() -> None:
    """
    機能: F2同体を確認し、3原文・8ソース・集計と検査だけを保存する。
    引数: なし。返り値: None。
    """
    for name in ('検査','成果物','再現資料'): (FORMAL/name).mkdir(exist_ok=True)
    fixed=(WORK/'F2.json').read_bytes()
    assert sha(fixed)=='ecf5222ca54cbbcf23bfa52713da77ec085cb6b5b6d3274f7d1f268a83659ff4'
    f=json.loads(fixed); original=[]
    for source,expected in f['事前文書'].items():
        path=Path(source); data=path.read_bytes(); assert sha(data)==expected
        original.append({'source_path':source,'restore_relative':str(path.relative_to(ROOT)).replace('\\','/'),'SHA256':expected,'bytes':len(data),'utf8_text':data.decode('utf-8')})
    for source,expected in f['コード'].items(): assert sha(Path(source).read_bytes())==expected
    for name in ('F2.json','F2完了.json','評価完了.json','人工検査.json','選択票生成の確認.json'):
        shutil.copy2(WORK/name,FORMAL/'検査'/name)
    docs=compact((json.dumps({'試行':125,'F2_SHA256':sha(fixed),'原文':original},ensure_ascii=False,indent=2)+'\n').encode('utf-8'),FORMAL/'検査/実行前文書.json.gz')
    aggregate=compact((WORK/'集計.json').read_bytes(),FORMAL/'成果物/集計.json.gz')
    for item in original:
        assert f['事前文書'][item['source_path']]==sha(item['utf8_text'].encode('utf-8'))
    # ----------------------------------------
    sources=[Path(p) for p in f['コード'] if '124入口の原因分析' not in p]
    sources.extend(ROOT/'work/125条件付き反転CSV出力'/name for name in ('出力する.mjs','CSVを独立再読する.py','README.md'))
    sources.append(Path(__file__))
    before={str(p.relative_to(ROOT)).replace('\\','/'):p.read_bytes() for p in sources}
    zip_path=FORMAL/'再現資料/125コード.zip'
    with zipfile.ZipFile(zip_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for name,data in sorted(before.items()):
            info=zipfile.ZipInfo(name,date_time=(2026,11,11,0,0,0)); info.compress_type=zipfile.ZIP_DEFLATED
            archive.writestr(info,data,compresslevel=9)
    entries=[]
    with zipfile.ZipFile(zip_path) as archive:
        assert archive.testzip() is None
        for name,data in sorted(before.items()):
            assert archive.read(name)==data==(ROOT/name).read_bytes()
            entries.append({'entry':name,'restore_relative':name,'bytes':len(data),'SHA256':sha(data),'CRC32':f'{archive.getinfo(name).CRC:08x}'})
    ref={'zip':'../../00124_逆行の原因と売買反転を同じ入口で検証する/再現資料/124コード.zip','zip_SHA256':'71664dd715fad8c6d44d0015ddc77ab85a3fcf148446020a3a88ed667e240753','entry':'work/124入口の原因分析/集計する.py','SHA256':'8479ca348231ffd77a637360797750833c9e6617c7fc4a6502e015c7a1d9f04a'}
    with zipfile.ZipFile(FORMAL/'../00124_逆行の原因と売買反転を同じ入口で検証する/再現資料/124コード.zip') as archive: assert sha(archive.read(ref['entry']))==ref['SHA256']
    index={'試行':125,'F2_SHA256':sha(fixed),'zip':{'path':zip_path.name,'bytes':zip_path.stat().st_size,'SHA256':sha(zip_path.read_bytes())},'entries':entries,'外部復元':[ref]}
    save(FORMAL/'再現資料/コード復元索引.json',index)
    # ----------------------------------------
    out=ROOT/'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/125条件付き反転CSV'
    csvs={'正逆比較.csv':'e93db6c6659c9387db2a4d5c5d8561d3f24d24f557fe164d89b74f5946d462b6','入口別診断.csv':'ccac751facf80f19cd83c7f267b5cc5f41a1a17ed671dc66864339fe612e2309','全セッション.csv':'61dbaab175e82ba7fd3024b491a22950a7db3eacabdb3d542761c3ebce58c7c4'}
    assert all(sha((out/name).read_bytes())==expected for name,expected in csvs.items())
    shutil.copy2(out/'CSVの確認.json',FORMAL/'検査/CSVの確認.json')
    shutil.copy2(ROOT/'work/125条件付き反転CSV出力/全73独立再読.json',FORMAL/'検査/CSV独立再読.json')
    save(FORMAL/'検査/原文とコードと集計保管の確認.json',{'成功':True,'試行':125,'F2原文3SHA同体':True,'F2コード5SHA同体':True,'ZIP再読CRC成功':True,'原文':docs,'集計':aggregate,'コード':index['zip'],'CSVbytes不変':csvs,'Raw再読':False,'元ペア特徴大型入力の複写':False})
    print(json.dumps({'成功':True,'原文':docs,'集計':aggregate,'ZIP':index['zip'],'entries':len(entries)},ensure_ascii=False))


if __name__=='__main__':
    main()
