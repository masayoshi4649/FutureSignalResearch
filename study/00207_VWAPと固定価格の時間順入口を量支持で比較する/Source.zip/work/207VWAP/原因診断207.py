"""207の固定金融を帯・背景・源からの位置・量・枠の違いへ事後分解する。"""
from collections import defaultdict,Counter
from pathlib import Path
from statistics import median
import gzip
import json
import math

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent


def read(path: Path) -> object:
    """
    機能: 固定JSONを読む。
    引数: path(Path)。
    返り値: object。
    """
    with gzip.open(path,'rt',encoding='utf-8') if path.suffix=='.gz' else path.open(encoding='utf-8') as f:return json.load(f)


def describe(items: list) -> dict:
    """
    機能: 実取得の損益と当時属性・取得遅れを要約する。
    引数: items(list[dict])。
    返り値: dict。遅れは事後執行診断であり入口フィルタではない。
    """
    net=[x['net'] for x in items if x['known']];labels=Counter(x['label'] for x in items)
    return {'取得':len(items),'未知':len(items)-len(net),'利益':sum(max(0,x) for x in net),'損失':sum(max(0,-x) for x in net),
        '既知収支':sum(net),'赤字取得':sum(x<0 for x in net),'到達':dict(labels),
        '源から秒中央値':median(x['源から秒'] for x in items) if items else None,
        '源から順行ATR中央値':median(x['源から順行ATR'] for x in items) if items else None,
        '約定代用遅れ中央値':median(x['約定代用遅れ秒'] for x in items) if items else None,
        '取得位置悪化pt中央値':median(x['取得位置悪化pt'] for x in items) if items else None}


def relation(channel: dict | None,side: int) -> str:
    """
    機能: 指標が当時既知なら方向整合を実側に対して分類する。
    引数: channel(dict|None)、side(int)。
    返り値: str。将来の足や符号反転勝率を推定しない。
    """
    if channel is None or channel['slope'] is None:return '未知'
    gap=side*(channel['ema8']-channel['ema21']);slope=side*channel['slope']
    return '実側整合' if gap>0 and slope>0 else '元側整合' if gap<0 and slope<0 else '非整合'


def main() -> None:
    """
    機能: 条件を変更せずQV単独役割の原因診断と量寄与を保存する。
    引数: なし。
    返り値: None。事後群を新入口の成績とは呼ばない。
    """
    rows=read(ROOT/'inputs/00207_TOPIXのVWAPと固定価格の純入口/純入口.json.gz')
    pure={(r['session'],r['time'],r['line']):r for r in rows}
    feat=read(ROOT/'inputs/TOPIX原順8列_20260921_20261116/純特徴184直接.json.gz')
    feat+=read(ROOT/'inputs/00194_20261116夜と1117昼の固定適用入力/TOPIX/純特徴184直接.json.gz')
    features={(r['session'],r['time'],r['line']):r for r in feat};result=[]
    for path in sorted((HERE/'金融/金融正本').glob('*QV*.json.gz')):
        pack=read(path);role=next((i for i,x in enumerate(('T_','R_','F_')) if path.name.startswith('TOPIX207_'+x)),None)
        if role is None:continue
        ledger=pack['ledger'];details=[];groups=defaultdict(list)
        for i in range(len(ledger['known'])):
            trade={k:v[i] for k,v in ledger.items()};key=(trade['scene'],trade['request_time'],trade['request_line'])
            current=features[key];b=pure[key]['births'][role];assert b is not None;source=b['source'];d=trade['side']
            row=trade|{'源から秒':trade['request_time']-source['time'],
                '源から順行ATR':d*(b['confirmation']['last']-source['last'])/b['atr'],
                '約定代用遅れ秒':trade['entry_time']-trade['request_time'],
                '取得位置悪化pt':d*(trade['entry_price']-b['confirmation']['last']),
                '15分背景':relation(current['m15'],d),'30分背景':relation(current['m30'],d),
                '5分DI実側':current['m5']['di']*d,'15分DI実側':current['m15']['di']*d,
                '量速度比':b['quantity']['relative_rate'],'区間平均の線から実側ATR':d*(b['quantity']['interval_vwap']-b['level'])/b['atr'],
                '旧190同q0方向':'同側' if pure[key]['signals'][0]==d else '逆側' if pure[key]['signals'][0]==-d else '不成立',
                'birth':b}
            details.append(row);band=('DAY','PRE','POST')[trade['phase']]
            labels=[('全体','全件'),('帯',band),('15分背景',row['15分背景']),('30分背景',row['30分背景']),
                ('5分DI','実側' if row['5分DI実側']>0 else '元側又は0'),
                ('15分DI','実側' if row['15分DI実側']>0 else '元側又は0'),
                ('量速度比','1以上' if row['量速度比']>=1 else '0.5以上1未満'),
                ('取得遅れ事後','5秒以内' if row['約定代用遅れ秒']<=5 else '5秒超'),
                ('旧190同q0',row['旧190同q0方向'])]
            for dim,value in labels:groups[(dim,value)].append(row)
            for dim in ('15分背景','30分背景'):
                groups[(dim+'帯別',band+'/'+row[dim])].append(row)
        result.append({'候補':pack['id'],'事後分類':True,'群':[{'軸':dim,'群':value,**describe(items)} for (dim,value),items in groups.items()],
            '実取得属性':details,'金融未知理由':dict(Counter(r['unknown_reason'] for r in details if not r['known']))})
    diff=read(HERE/'実取得差分.json.gz');quantity=[]
    for r in diff:
        if '_QK_' not in r['旧'] or '_QV_' not in r['新']:continue
        quantity.append({'旧':r['旧'],'新':r['新'],'全83':[x for x in r['比較'] if x['期間']=='全83']})
    output={'新条件ではない事後診断':True,'役割別':result,'量支持の共通枠差':quantity,
        '限界':'同じ取得を機械的に逆側へ入れば1−pになるとはしない。原板BBOでの逆側再生・参照水準変更・旧優先増分は新試行が必要。'}
    target=HERE/'原因診断.json.gz';assert not target.exists()
    target.write_bytes(gzip.compress((json.dumps(output,ensure_ascii=False,separators=(',',':'))+'\n').encode(),mtime=0))
    for r in result:
        print(r['候補'])
        for group in r['群']:
            if group['軸'] in ('帯','15分背景','30分背景','取得遅れ事後'):print({k:v for k,v in group.items() if k in ('軸','群','取得','未知','既知収支','赤字取得','源から順行ATR中央値','約定代用遅れ中央値')})


if __name__=='__main__':main()
