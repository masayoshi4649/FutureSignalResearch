"""207の源時既知端までの距離と期間別実績を事後診断する。"""
from pathlib import Path
from statistics import median
import gzip,json

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent


def read(path: Path) -> object:
    """
    機能: 固定JSONを読む。
    引数: path(Path)。
    返り値: object。
    """
    with gzip.open(path,'rt',encoding='utf-8') if path.suffix=='.gz' else path.open(encoding='utf-8') as f:return json.load(f)


def main() -> None:
    """
    機能: 未来高安を使わず源の過去端とIFD幅の関係を保存する。
    引数: なし。
    返り値: None。過去端を将来の確定利確余地とは扱わない。
    """
    data=read(HERE/'原因診断.json.gz');short=read(HERE/'全26口座短表.json.gz');by_id={r['id']:r for r in short}
    features=read(ROOT/'inputs/TOPIX原順8列_20260921_20261116/純特徴184直接.json.gz')
    features+=read(ROOT/'inputs/00194_20261116夜と1117昼の固定適用入力/TOPIX/純特徴184直接.json.gz')
    fm={(r['session'],r['time'],r['line']):r for r in features};records=[]
    for result in data['役割別']:
        values=[];source_moves=[];knownroom=0
        for item in result['実取得属性']:
            b=item['birth'];source=b['source'];s=fm[(item['scene'],source['time'],source['line'])];d=item['side']
            edge=s['prior_high'] if d==1 else s['prior_low'];distance=d*(edge-b['confirmation']['last'])
            values.append(distance/b['atr']);knownroom+=int(distance>=item['width']);source_moves.append(item['源から順行ATR'])
        r=by_id[result['候補']]
        records.append({'候補':result['候補'],'取得':len(values),'源前3本実側端まで距離ATR中央値':median(values) if values else None,
            '源前3本端がIFD幅以上先にある取得':knownroom,'源から順行ATR中央値':median(source_moves) if source_moves else None,
            '期間':{p:{b:{k:g[k] for k in ('取得','未知','利益','損失','既知収支','参加場','全場','保有下限','両中央値')} for b,g in groups.items() if b in ('ALL','DAY','NIGHT')} for p,groups in r['期間'].items()}})
    output={'事後診断':True,'注意':'源時の既知3本端までの距離であり将来の順行余地を保証しない。取得遅れ・期間分類で条件を作り替えない。','結果':records}
    target=HERE/'位置と期間.json';assert not target.exists();target.write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    for r in records:
        if r['候補'].endswith('A25'):print(r['候補'],r['取得'],r['源前3本実側端まで距離ATR中央値'],r['源前3本端がIFD幅以上先にある取得'],[(p,v['ALL']['取得'],round(v['ALL']['既知収支'])) for p,v in r['期間'].items()])


if __name__=='__main__':main()
