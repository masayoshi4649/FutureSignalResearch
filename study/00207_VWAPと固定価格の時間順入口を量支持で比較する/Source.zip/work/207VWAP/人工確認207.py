"""207の時間順・固定値・売買鏡像・量対照を人工列で検査する。"""
from copy import deepcopy
from datetime import datetime
from pathlib import Path
import importlib.util

HERE=Path(__file__).parent;spec=importlib.util.spec_from_file_location('entry207',HERE/'入口207.py')
E=importlib.util.module_from_spec(spec);spec.loader.exec_module(E)
START=datetime.fromisoformat('2026-11-04T08:50:00+09:00').timestamp();SCENE='2026-11-04_Day'


def row(offset: int,close: float,prior: float=99.5,**updates) -> dict:
    """
    機能: 公表済み足を持つ買い側の人工価格q0を作る。
    引数: offset(int)は源から秒、close/prior(float)、updates(dict)。
    返り値: dictは金融を含まない純価格特徴。
    """
    t=START+offset
    result={'session':SCENE,'time':t,'line':1000+offset,'band':'DAY','close':close,'prior_close':prior,
        'high':close+.2,'low':close-.2,'prior_high':101.,'prior_low':99.,'atr':2.,'range':.2,
        'body':.2 if close>prior else -.2,'progress':(close-prior)/2,'live':0.,'spread':.5,
        'm15':{'ema8':101.,'ema21':100.,'slope':.1,'end':START-300,'published':START-300},
        'm5':{'hist_delta':-.1,'end':START,'published':START}}
    result.update(updates);return result


def native(price: dict,q: float=1000.,value: float | None=None,**updates) -> dict:
    """
    機能: 同原行の内部整合する累積値を作る。
    引数: price(dict)、q(float)、value(float|None)、updates(dict)。
    返り値: dictは204互換の純小列。
    """
    v=100.*q*10000 if value is None else value
    result={'time':price['time'],'line':price['line'],'last':price['close'],'native':v/q/10000,'native_known':True,
        'epoch':0,'continuity':0,'volume':q,'value':v,'volume_time':price['time'],
        'contract':'161120005','exchange':2,'exchange_name':'大阪日通し','opening_time':START-50000,'opening_price':100.}
    result.update(updates);return result


def mirror(price: dict,quote: dict) -> tuple:
    """
    機能: 価格100を中心に売買を鏡像化し、代金も同じ変換を行う。
    引数: price/quote(dict)。
    返り値: tuple[dict,dict]は売り側価格と累積。
    """
    r=deepcopy(price);n=deepcopy(quote)
    for name in ('close','prior_close'):r[name]=200-r[name]
    r['high'],r['low']=200-price['low'],200-price['high'];r['prior_high'],r['prior_low']=200-price['prior_low'],200-price['prior_high']
    for name in ('body','progress','live'):r[name]=-r[name]
    for name in ('ema8','ema21'):r['m15'][name]=200-r['m15'][name]
    r['m15']['slope']=-r['m15']['slope'];r['m5']['hist_delta']=-r['m5']['hist_delta'] if r['m5']['hist_delta'] is not None else None
    n['last']=200-n['last'];n['native']=200-n['native'];n['value']=200*n['volume']*10000-n['value']
    return r,n


def scenario(role: int) -> tuple:
    """
    機能: T/R/Fの源から価格保持までの正しい時間順を作る。
    引数: role(int)は0/1/2。
    返り値: tuple[source,history,steps]は価格/累積の対を含む。
    """
    history=[]
    for off in (-180,-120,-60):
        r=row(off,100.5,100.4);history.append((r,native(r,1000+off)))
    if role==0:
        s=row(0,99.5,100.5);steps=[row(60,100.5,99.5),row(120,100.6,100.5)]
        means=(100.4,100.6)
    elif role==1:
        s=row(0,102.,100.9);steps=[row(60,100.6,102.),row(120,100.4,100.6)]
        means=(101.,100.5)
    else:
        s=row(0,102.,101.9);steps=[row(60,100.1,102.),row(120,100.8,100.1),row(180,100.9,100.8)]
        means=(100.5,100.8,100.9)
    q=1000;v=100*q*10000;pairs=[]
    for r,m in zip(steps,means):q+=100;v+=100*m*10000;pairs.append((r,native(r,q,v)))
    return (s,native(s)),history,pairs


def run() -> None:
    """
    機能: 明示した人工境界を検査してSource指紋付き証跡を保存する。
    引数: なし。
    返り値: None。金融や自然損益は読まない。
    """
    labels=[];attrs=0
    for role in range(3):
        for sell in (False,True):
            source,history,steps=scenario(role)
            if sell:source=mirror(*source);history=[mirror(*p) for p in history];steps=[mirror(*p) for p in steps]
            state=E.seed(*source,history,role);assert state is not None;attrs+=1
            fixed=(state['source'],state['level'],state['atr'],state['expiry']);birth=None
            for i,(r,n) in enumerate(steps):
                birth,why=E.advance(state,r,n);assert why is None;attrs+=1
                if i<len(steps)-1:assert birth is None;attrs+=1
                assert fixed==(state['source'],state['level'],state['atr'],state['expiry']);attrs+=1
            assert birth is not None and birth['quantity']['known'] and birth['quantity']['support'];attrs+=3
            side=(-1 if sell else 1)*(-1 if role==1 else 1);assert birth['side']==side;attrs+=1
            assert birth['recovery']['end']<birth['confirmation']['end'];attrs+=1
            if role==2:assert birth['source']['end']<birth['approach']['end']<birth['recovery']['end'];attrs+=1
            labels.append(f'{role}/'+('売り' if sell else '買い')+'の順序と代金鏡像')
    # ----------------------------------------
    source,history,steps=scenario(0);state=E.seed(*source,history,0)
    before=deepcopy(state);assert E.advance(state,*source)==(None,None) and state==before;attrs+=2
    bad=deepcopy(steps[0]);bad[0]['time']=source[0]['time'];bad[1]['time']=source[0]['time']
    assert E.advance(state,*bad)==(None,None);attrs+=1;labels.append('源同秒に回復しない')
    E.advance(state,*steps[0]);old=state['recovery'];bad=deepcopy(steps[1]);bad[0]['time']=steps[0][0]['time']+1;bad[1]['time']=bad[0]['time']
    assert E.advance(state,*bad)[0] is None;attrs+=1;labels.append('同じ完成足で保持しない')
    # ----------------------------------------
    for kind in ('中期未知','数量未知','連続性変更','量ゼロ','区間位置逆','数量速度不足'):
        source,history,steps=scenario(0);state=E.seed(*source,history,0)
        if kind=='中期未知':
            r,n=deepcopy(steps[0]);r['m15']['slope']=None
            before=deepcopy(state);assert E.advance(state,r,n)==(None,None) and state==before;attrs+=2
        else:
            E.advance(state,*steps[0]);r,n=deepcopy(steps[1])
            if kind=='数量未知':n['native_known']=False
            elif kind=='連続性変更':n['continuity']=1
            elif kind=='量ゼロ':n['volume']=steps[0][1]['volume'];n['value']=steps[0][1]['value']
            elif kind=='区間位置逆':n['value']=steps[0][1]['value']+100*99.8*10000
            else:n['volume']=steps[0][1]['volume']+10;n['value']=steps[0][1]['value']+10*100.6*10000
            b,why=E.advance(state,r,n);assert b is not None and why is None;attrs+=2
            assert not b['quantity']['support'];attrs+=1
            assert b['quantity']['known']==(kind in ('区間位置逆','数量速度不足'));attrs+=1
        labels.append(kind+'を価格出生と区別')
    # ----------------------------------------
    source,history,steps=scenario(0);state=E.seed(*source,history,0)
    r,n=deepcopy(steps[0]);n['epoch']=1
    assert E.advance(state,r,n)==(None,'既知起算変更');attrs+=1
    r,n=deepcopy(steps[0]);r['time']=state['expiry']+1;n['time']=r['time']
    assert E.advance(state,r,n)==(None,'源期限');attrs+=1;labels.append('既知起算と不変期限による理由付き失効')
    # ----------------------------------------
    source,history,steps=scenario(0);s,n=source;n['native']=101.;s['close']=100.5
    assert E.seed(s,n,history,0) is not None;attrs+=1
    altered=[(r,dict(v,native=102.)) for r,v in history]
    assert E.seed(s,n,altered,0) is None;attrs+=1;labels.append('過去のnativeは当時値で判定し源値を遡及しない')
    source,history,steps=scenario(1);source[0]['prior_high']=102.
    assert E.seed(*source,history,1) is None;attrs+=1;labels.append('Rは源当足でなく前3本固定端の突破が必要')
    # ----------------------------------------
    source,history,steps=scenario(1);state=E.seed(*source,history,1)
    for delta in (None,.1):
        r,n=deepcopy(steps[0]);r['m5']['hist_delta']=delta
        assert E.advance(state,r,n)==(None,None) and state['recovery'] is None;attrs+=2
    labels.append('元動力が未知又は再加速なら反転回復にしない')
    source,history,steps=scenario(2);state=E.seed(*source,history,2)
    r,n=deepcopy(steps[0]);r['close']=99.4
    assert E.advance(state,r,n)==(None,'native反対側へ受容');attrs+=1;labels.append('Fは成功した反対側回復を失敗へ読み替えない')
    # ----------------------------------------
    positive={'side':1,'quantity':{'known':True,'support':True}}
    negative={'side':-1,'quantity':{'known':True,'support':True}}
    assert E.choose([positive,positive,None],3,2)==(1,[0,1],False);attrs+=1
    assert E.choose([positive,negative,None],3,2)==(0,[0,1],True);attrs+=1
    unknown={'side':1,'quantity':{'known':False,'support':False}}
    assert E.choose([unknown,None,None],0,0)[0]==1 and E.choose([unknown,None,None],0,1)[0]==0 and E.choose([unknown,None,None],0,2)[0]==0;attrs+=3
    assert E.choose([unknown,negative,None],3,2)==(0,[0,1],True);attrs+=1
    labels.append('同側統合と逆側衝突と量対照の純選別')
    # ----------------------------------------
    source,history,steps=scenario(0);steps[1][1]['continuity']=1
    stream=history+[source]+steps;mapping={E.key(r):n for r,n in stream};births,counts=E.generate([r for r,n in stream],mapping)
    at=E.key(steps[-1][0]);b=births[at][0]
    assert b is not None and not b['quantity']['known'];attrs+=2
    assert sum(r[0] is not None for r in births.values())==1;attrs+=1
    labels.append('量不成立でも価格出生を一度で消費')
    proof={'成功':True,'金融未使用':True,'SourceSHA':E.ref(HERE/'入口207.py')['sha256'],'項目':len(labels),'比較属性':attrs,'確認':labels}
    E.save(HERE/'人工確認.json',proof);print('人工',len(labels),'項目',attrs,'属性成功')


if __name__=='__main__':run()
