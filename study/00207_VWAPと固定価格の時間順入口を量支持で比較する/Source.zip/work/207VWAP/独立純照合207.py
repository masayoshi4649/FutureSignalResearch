"""207の保存出生と全26信号を売買実装を呼ばず再検算する。"""
from collections import Counter
from datetime import datetime,timedelta,timezone
from pathlib import Path
import gzip
import hashlib
import json
import math

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent;JST=timezone(timedelta(hours=9))


def read(path: Path) -> object:
    """
    機能: 封印済み純JSONを読む。
    引数: path(Path)。
    返り値: object。
    """
    with gzip.open(path,'rt',encoding='utf-8') if path.suffix=='.gz' else path.open(encoding='utf-8') as f:return json.load(f)


def k(row: dict) -> tuple:
    """
    機能: 純q0の完全識別を作る。
    引数: row(dict)。
    返り値: tuple。
    """
    return row['session'],row['time'],row['line']


def end(scene: str,time: float) -> float:
    """
    機能: 既知の公表遅延条件から確定1分足終端を再計算する。
    引数: scene(str)、time(float)。
    返り値: float。
    """
    d=datetime.fromisoformat(scene[:10]).replace(tzinfo=JST)
    start=(d.replace(hour=8,minute=45) if scene.endswith('_Day') else d.replace(hour=17)).timestamp()
    return start+math.floor((time-start)/60)*60


def main() -> None:
    """
    機能: 保存された全価格出生の境界と量、26信号・幅・旧対照を照合する。
    引数: なし。
    返り値: None。全源/未成立の状態再生成とは区別する。
    """
    cfg=read(HERE/'条件.json');path=ROOT/'inputs/00207_TOPIXのVWAPと固定価格の純入口/純入口.json.gz'
    assert hashlib.sha256(path.read_bytes()).hexdigest()==cfg['純入口SHA']
    actual=read(path);parent=ROOT/'inputs/00200_TOPIXの観測被覆と時間順入口'
    baseline=read(parent/'純入口.json.gz')+read(parent/'追加二場純入口.json.gz')
    feature=read(ROOT/'inputs/TOPIX原順8列_20260921_20261116/純特徴184直接.json.gz')
    feature+=read(ROOT/'inputs/00194_20261116夜と1117昼の固定適用入力/TOPIX/純特徴184直接.json.gz')
    fmap={k(r):r for r in feature};nmap={}
    for p in (ROOT/'inputs/00204_両指数の配信VWAP純入力/TOPIX').glob('*.json.gz'):
        obj=read(p)
        for n in obj['rows']:nmap[(obj['session'],n['time'],n['line'])]=n
    count=0;birthcount=Counter()
    for r,old in zip(actual,baseline,strict=True):
        assert k(r)==k(old);scene=r['session'];current=fmap.get(k(r))
        assert r['signals'][:2]==[old['signals'][0]]*2 and r['widths'][:2]==[old['widths'][0],15.];count+=4
        for role,b in enumerate(r['births']):
            if b is None:continue
            birthcount[str(role)]+=1;d=b['side'];o=b['old_direction'];a=b['atr'];level=b['level']
            points=[b['source'],b['recovery'],b['confirmation']];source,recovery,held=points
            assert b['expiry']==source['time']+600 and source['time']<recovery['time']<held['time']<=b['expiry'];count+=2
            assert source['end']<recovery['end'] and held['end']==recovery['end']+60 and 30<=held['time']-recovery['time']<=90;count+=3
            price=[];quotes=[]
            for point in points:
                item=fmap[(scene,point['time'],point['line'])];n=nmap[(scene,point['time'],point['line'])]
                assert point['end']==end(scene,point['time']) and point['close']==item['close'];count+=2
                for field in ('last','native','native_known','epoch','continuity','volume','value','volume_time'):
                    assert point[field]==n[field];count+=1
                assert point['identity']==[n[x] for x in ('contract','exchange','exchange_name','opening_time','opening_price')];count+=1
                price.append(item);quotes.append(n)
            s,c,h=price;sn,cn,hn=quotes
            mid=s['m15'];original=1 if mid['ema8']>mid['ema21'] and mid['slope']>0 else -1 if mid['ema8']<mid['ema21'] and mid['slope']<0 else 0
            assert original==o and source['atr']==a and b['native_level']==sn['native'];count+=3
            if role==0:
                assert d==o and level==sn['native'] and -1.5<=d*(s['close']-level)/a<=-.1;count+=3
                assert [x['end'] for x in b['past_native']]==[source['end']-180,source['end']-120,source['end']-60];count+=1
                passed=[]
                for p in b['past_native']:
                    f=fmap[(scene,p['time'],p['line'])];n=nmap[(scene,p['time'],p['line'])];ext=f['high'] if d==1 else f['low']
                    test=d*(ext-n['native'])>=.1*f['atr'];passed.append(test)
                    assert p['native']==n['native'] and p['extreme']==ext and p['accepted']==test and n['epoch']==sn['epoch'];count+=4
                assert any(passed);count+=1
            elif role==1:
                assert d==-o and level==(s['prior_high'] if o==1 else s['prior_low']);count+=2
                assert o*(s['close']-sn['native'])>=.5*a and o*(s['close']-level)>=.5;count+=2
                assert all(p['m5']['hist_delta'] is not None and o*p['m5']['hist_delta']<=0 for p in (c,h));count+=2
            else:
                assert d==o and level==sn['native']+d*.25*a and .5<=d*(s['close']-sn['native'])/a<=2;count+=3
                approach=b['approach'];p=fmap[(scene,approach['time'],approach['line'])]
                assert source['end']<approach['end']<recovery['end'];count+=1
                assert -.25<=d*(p['close']-sn['native'])/a<=.1 and d*p['progress']<0;count+=2
            assert d*(c['prior_close']-level)<=0<d*(c['close']-level) and d*c['body']>0 and d*c['progress']>0;count+=3
            opposite=h['low'] if d==1 else h['high']
            assert d*(h['close']-level)>0 and d*(opposite-level)>=-.1*a;count+=2
            assert 0<d*(hn['last']-level)<=.75*a and 0<h['spread']<=1.5 and h['range']<=2.5 and h['live'] is not None and d*h['live']>=-.25;count+=4
            known=all(p['native_known'] and p['epoch']==source['epoch'] and p['continuity']==source['continuity'] and p['identity']==source['identity'] for p in points)
            spans=[]
            for left,right in zip(points,points[1:]):
                dq=right['volume']-left['volume'];dv=right['value']-left['value'];dt=right['time']-left['time']
                known=known and dq>0 and dv>0 and dt>0 and right['line']>left['line'] and right['volume_time']>left['volume_time']
                spans.append((dq,dv,dt))
            assert b['quantity']['known']==known;count+=1
            if known:
                q0,v0,t0=spans[0];q1,v1,t1=spans[1];mean=v1/q1/10000;ratio=(q1/t1)/(q0/t0)
                support=d*(mean-level)>=0 and q1/t1>=.5*(q0/t0)
                assert b['quantity']['support']==support and b['quantity']['interval_vwap']==mean and b['quantity']['relative_rate']==ratio;count+=3
        for role in range(4):
            base=[b for i,b in enumerate(r['births']) if b is not None and (role==3 or role==i)]
            sides={b['side'] for b in base}
            for mode in range(3):
                passed=[b for b in base if mode==0 or b['quantity']['known'] if mode!=2 or b['quantity']['support']]
                side=next(iter(sides)) if len(sides)==1 and passed else 0
                for wi in range(2):
                    ci=2+role*6+mode*2+wi;w=15. if wi==0 else math.ceil(min(25,max(5,current['atr']*2.5))*4)/4 if current else None
                    assert r['signals'][ci]==side and r['widths'][ci]==w;count+=2
    proof={'成功':True,'金融未使用':True,'q0':len(actual),'価格出生':dict(birthcount),'比較属性':count,
        '範囲':'全保存価格出生の源/回復/保持と同原行代金量、全26信号/幅、旧母体同体。未成立源まで含む全状態機械の独立再生成ではない。',
        'SourceSHA':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'純入口SHA':cfg['純入口SHA']}
    output=HERE/'純独立確認.json';assert not output.exists();output.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':main()
