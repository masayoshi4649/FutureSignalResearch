"""207固定金融の単一枠・集計・順位・実現取引差分を検査する。"""
from collections import defaultdict
from pathlib import Path
import gzip
import hashlib
import json
import math
import sys

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent;TARGET=HERE/'金融'
sys.path.insert(0,str(ROOT/'scripts/TOPIX入口研究'));import 共通金融 as C
sys.path.insert(0,str(ROOT/'work/183損失安定性'));import TOPIXを独立検算する as V


def read(path: Path) -> object:
    """
    機能: 固定結果を読む。
    引数: path(Path)。
    返り値: object。
    """
    with gzip.open(path,'rt',encoding='utf-8') if path.suffix=='.gz' else path.open(encoding='utf-8') as f:return json.load(f)


def save(path: Path,value: object) -> None:
    """
    機能: 検査・選択正本を新規保存し異なる上書きを拒否する。
    引数: path(Path)、value(object)。
    返り値: None。
    """
    raw=(json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode()
    data=gzip.compress(raw,mtime=0) if path.suffix=='.gz' else raw
    if path.exists():assert path.read_bytes()==data
    else:path.write_bytes(data)


def capacity(packs: list,rows: list) -> dict:
    """
    機能: 全q0を別の一枠状態で再生して全実取得を検査する。
    引数: packs(list[dict])、rows(list[dict])。
    返り値: dictは一致数と件数。固定Routeセルを共用し原板決済再監査とは呼ばない。
    """
    by=defaultdict(list)
    for r in rows:by[r['session']].append(r)
    checks=0;totals=defaultdict(int)
    for e in C.entries(True):
        scene=e['session'];route=C.M.Route(e);cells={}
        for ci,pack in enumerate(packs):
            ledger=pack['ledger'];selected=[i for i,s in enumerate(ledger['scene']) if s==scene];cursor=0;free_after=-math.inf
            for row in by[scene]:
                totals['全q0']+=1;side=row['signals'][ci]
                if not side:continue
                totals['純要求']+=1
                if row['time']<=free_after:totals['保有予約棄却']+=1;continue
                identity=(row['time'],row['line'],side,row['widths'][ci])
                if identity not in cells:cells[identity]=route.cell(*identity)
                cell=cells[identity]
                if cell is None:free_after=min(row['time']+30,route.force);totals['予約失効']+=1;continue
                assert cursor<len(selected);index=selected[cursor];cursor+=1;totals['取得']+=1
                expected={'known':not cell['unknown'],'net':None if cell['unknown'] else round(cell['gross_pt']*1000-83.6-500,1),
                    'scene':scene,'phase':{'DAY':0,'PRE':1,'POST':2}[cell['band']],'origin':row['origins'][ci]}
                for field,values in ledger.items():
                    value=expected[field] if field in expected else cell[field]
                    checks+=V.V.check_equal(values[index],value,(pack['id'],scene,index,field))
                free_after=route.end if cell['unknown'] else cell['exit_time']
            assert cursor==len(selected),(pack['id'],scene,'余分取得')
    return {'照合属性':checks,**totals,'範囲':'全q0単一枠の別状態再生。IFD決済は既存Route共用、原BBO決済の新たな独立走査ではない。'}


def trades(pack: dict) -> dict:
    """
    機能: 入口別名によらず物理取得と固定幅で実取引を識別する。
    引数: pack(dict)。
    返り値: dict[tuple,dict]。
    """
    ledger=pack['ledger'];out={}
    for i in range(len(ledger['known'])):
        r={k:v[i] for k,v in ledger.items()};key=(r['scene'],r['entry_line'],r['entry_time'],r['side'],r['width'])
        assert key not in out;out[key]=r
    return out


def subtotal(rows: list) -> dict:
    """
    機能: 成立した取得だけの利益・損失・未知を数える。
    引数: rows(list[dict])。
    返り値: dict。機会損失や不成立時の仮想利益は含めない。
    """
    values=[r['net'] for r in rows if r['known']]
    return {'取得':len(rows),'未知':sum(not r['known'] for r in rows),'利益':sum(max(0,n) for n in values),
        '損失':sum(max(0,-n) for n in values),'既知収支':sum(values),'赤字取得':sum(n<0 for n in values)}


def differences(packs: list) -> list:
    """
    機能: 旧190対照とP/QK/QVを共通・旧のみ・新のみの実取得へ分解する。
    引数: packs(list[dict])は候補順。
    返り値: list[dict]。幅の違う取得は共通へ混ぜない。
    """
    pairs={(0,i) for i in range(1,26)}|{(1,i) for i in range(2,26,2)}
    for family in range(4):
        for width in range(2):pairs.add((2+family*6+width,4+family*6+width));pairs.add((4+family*6+width,6+family*6+width))
    result=[];names=[s['scene'] for s in packs[0]['sessions']]
    periods={'全83':names,'全80':names[:80],'前48':names[:48],'後25':names[48:73],'追加7':names[73:80],'本日1':names[80:81],'追加2':names[81:]}
    for a,b in sorted(pairs):
        old,new=trades(packs[a]),trades(packs[b]);common=set(old)&set(new);left=set(old)-common;right=set(new)-common
        for key in common:
            assert all(old[key][field]==new[key][field] for field in ('known','net','entry_price','exit_price','exit_time','label'))
        summaries=[]
        for period,scenes in periods.items():
            for band in ('ALL','DAY','NIGHT','PRE','POST'):
                def includes(r: dict) -> bool:
                    """
                    機能: 元の要求帯と期間を維持して取引を選ぶ。
                    引数: r(dict)。
                    返り値: bool。
                    """
                    return r['scene'] in scenes and (band=='ALL' or band=='NIGHT' and r['phase']!=0 or r['phase']=={'DAY':0,'PRE':1,'POST':2}.get(band))
                summaries.append({'期間':period,'帯':band,'共通':subtotal([old[k] for k in common if includes(old[k])]),
                    '旧のみ':subtotal([old[k] for k in left if includes(old[k])]),'新のみ':subtotal([new[k] for k in right if includes(new[k])])})
        result.append({'旧':packs[a]['id'],'新':packs[b]['id'],'比較':summaries,
            '旧のみ実取得':[old[k] for k in sorted(left)],'新のみ実取得':[new[k] for k in sorted(right)]})
    return result


def main() -> None:
    """
    機能: 金融完了後に母体・全件枠・別算術・事前順位を確定する。
    引数: なし。
    返り値: None。条件・純出生・順位の基準は変更しない。
    """
    cfg=read(HERE/'条件.json');assert read(HERE/'純独立確認.json')['成功']
    for p,sha in cfg['Source'].items():assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==sha
    stats=read(TARGET/'安定性.json.gz')['metrics'];assert len(stats)==26
    packs=[read(TARGET/'金融正本'/(s['id']+'.json.gz')) for s in stats]
    expected_path=ROOT/cfg['母体期待']['path'];assert hashlib.sha256(expected_path.read_bytes()).hexdigest()==cfg['母体期待']['sha256']
    expected=read(expected_path)
    for field in ('ledger','positions','sessions'):assert packs[0][field]==expected[field],field
    same=[]
    for family in range(4):
        for width in range(2):
            p=2+family*6+width;q=p+2
            for field in ('positions','sessions'):assert packs[p][field]==packs[q][field]
            assert {k:v for k,v in packs[p]['ledger'].items() if k!='origin'}=={k:v for k,v in packs[q]['ledger'].items() if k!='origin'}
            same.append([packs[p]['id'],packs[q]['id']])
    count=sum(V.inspect_groups(p,s) for p,s in zip(packs,stats,strict=True))
    rows=read(ROOT/'inputs/00207_TOPIXのVWAPと固定価格の純入口/純入口.json.gz');slot=capacity(packs,rows)
    eligible=[i for i,n in enumerate(cfg['候補']) if '_QV_' in n];assert len(eligible)==8;rankings={}
    for period in ('前48','全80'):
        for band in ('DAY','NIGHT','ALL'):
            base=stats[0]['periods'][period][band]
            order=sorted(eligible,key=lambda i:(C.F.A.rank_key(stats[i]['periods'][period][band],base),packs[i]['id']))
            table=[{'候補':cfg['候補'][i],'id':packs[i]['id'],'gate':C.F.A.gate(stats[i]['periods'][period][band],base)} for i in order]
            acceptable=[r for r in table if r['gate']['suitable']]
            rankings[period+'_'+band]={'選択':acceptable[0] if acceptable else None,'参考先頭':table[0],'順位':table}
    save(HERE/'固定選択.json',{'採用候補はQVのみ':True,'全83既使用':True,'順位':rankings})
    save(HERE/'実取得差分.json.gz',differences(packs))
    short=[]
    for i,s in enumerate(stats):
        short.append({'候補':cfg['候補'][i],'id':s['id'],'全83':{b:C.F.terse(g) for b,g in s['groups'].items()},
            '期間':{p:{b:C.F.terse(g) for b,g in group.items()} for p,group in s['periods'].items()}})
    save(HERE/'全26口座短表.json.gz',short)
    save(HERE/'金融独立確認.json',{'成功':True,'母体同体':True,'P_QK同体':same,'別算術属性':count,'全件枠':slot,
        'SourceSHA':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        '範囲':'全固定台帳と別算術・単一枠。原BBOの決済は既存Route共用で新たな独立原板監査とは区別。'})
    print(json.dumps({'成功':True,'別算術':count,'枠':slot,'選択':{k:v['選択'] for k,v in rankings.items()}},ensure_ascii=False))


if __name__=='__main__':main()
