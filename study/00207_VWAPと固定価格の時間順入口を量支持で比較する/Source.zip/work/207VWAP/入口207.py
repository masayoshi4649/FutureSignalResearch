"""固定native/価格端の回復・拒否・量支持を時間順で生成する。金融は読まない。"""
from collections import Counter,deque
from datetime import datetime,timedelta,timezone
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import math

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
DATA=ROOT/'inputs/00204_両指数の配信VWAP純入力';PURE=ROOT/'inputs/00207_TOPIXのVWAPと固定価格の純入口'
JST=timezone(timedelta(hours=9));IDENTITY=('contract','exchange','exchange_name','opening_time','opening_price')
ROLES=('T_押戻し回復','R_端突破失敗反転','F_native回復失敗継続','M_三役割統合')
QUANTITY=('P_価格構造','QK_量可用性','QV_区間取引支持');WIDTHS=('W15','A25')
NAMES=('C0_旧190固定','C1_旧190全帯W15')+tuple(f'{r}_{q}_{w}' for r in ROLES for q in QUANTITY for w in WIDTHS)


def read(path: Path) -> object:
    """
    機能: 純入力JSON又はgzip JSONを読む。
    引数: path(Path)。
    返り値: objectは解析値。
    """
    with gzip.open(path,'rt',encoding='utf-8') if path.suffix=='.gz' else path.open(encoding='utf-8') as f:return json.load(f)


def ref(path: Path) -> dict:
    """
    機能: 正式入力とSourceの内容指紋を求める。
    引数: path(Path)。
    返り値: dictは相対path・容量・SHA256。
    """
    with path.open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':sha}


def save(path: Path,value: object) -> None:
    """
    機能: 非有限値を拒否し、固定結果の相違上書きをしないで保存する。
    引数: path(Path)、value(object)。
    返り値: None。
    """
    raw=(json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode()
    body=gzip.compress(raw,mtime=0) if path.suffix=='.gz' else raw;path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():assert path.read_bytes()==body,('既存結果が相違',path)
    else:path.write_bytes(body)


def key(row: dict) -> tuple:
    """
    機能: 当時q0を原行まで含めて識別する。
    引数: row(dict)。
    返り値: tuple[str,float,int]。
    """
    return row['session'],row['time'],row['line']


def minute_end(row: dict) -> float:
    """
    機能: 184の公表遅延30秒以内のq0から直前完成1分足endを求める。
    引数: row(dict)。
    返り値: float。価格時計と同じUnix秒。
    """
    date=datetime.fromisoformat(row['session'][:10]).replace(tzinfo=JST)
    start=(date.replace(hour=8,minute=45) if row['session'].endswith('_Day') else date.replace(hour=17)).timestamp()
    return start+int((row['time']-start)//60)*60


def direction(row: dict) -> int | None:
    """
    機能: 公表済み15分のEMA並びと21EMA傾きから中期方向を求める。
    引数: row(dict)。
    返り値: int|None。+1/-1整合、0既知非整合、None未知。
    """
    m=row.get('m15')
    if m is None or m['published']>row['time'] or any(m.get(k) is None for k in ('ema8','ema21','slope')):return None
    gap=m['ema8']-m['ema21'];slope=m['slope']
    return 1 if gap>0 and slope>0 else -1 if gap<0 and slope<0 else 0


def small_snapshot(row: dict,native: dict) -> dict:
    """
    機能: 源・回復・保持の公表足と同原行の累積値を固定する。
    引数: row(dict)、native(dict)は204の同原行。
    返り値: dict。後続更新で変化しない小列。
    """
    return {'time':row['time'],'line':row['line'],'end':minute_end(row),'close':row['close'],
        'last':native['last'],'atr':row['atr'],'native':native['native'],'native_known':native['native_known'],
        'epoch':native['epoch'],'continuity':native['continuity'],'volume':native['volume'],'value':native['value'],
        'volume_time':native['volume_time'],'identity':[native[k] for k in IDENTITY]}


def seed(row: dict,native: dict,history: list,role: int) -> dict | None:
    """
    機能: 旧P0と費用方向から独立に三役割の固定源を作る。
    引数: row/native(dict)、history(list[tuple[row,native]])は直前3q0、role(int)は0/1/2。
    返り値: dict|None。源から600秒の期限・ATR・価格線は不変。
    """
    d=direction(row)
    if d not in (-1,1) or not native['native_known']:return None
    a=row['atr'];w=native['native'];c=row['close'];depth=d*(c-w)/a;end=minute_end(row);level=w
    if role==0:
        if not -1.5<=depth<=-.1 or len(history)!=3:return None
        if [minute_end(h[0]) for h in history]!=[end-180,end-120,end-60]:return None
        if any(h[0]['session']!=row['session'] or not h[1]['native_known'] or h[1]['epoch']!=native['epoch'] for h in history):return None
        accepted=[d*((r['high'] if d==1 else r['low'])-n['native'])>=.1*r['atr'] for r,n in history]
        if not any(accepted):return None
        past=[{'time':r['time'],'line':r['line'],'end':minute_end(r),'native':n['native'],'atr':r['atr'],
            'extreme':r['high'] if d==1 else r['low'],'accepted':ok} for (r,n),ok in zip(history,accepted)]
    elif role==1:
        if depth<.5:return None
        level=row['prior_high'] if d==1 else row['prior_low']
        if d*(c-level)<.5:return None
        d=-d;past=None
    else:
        if not .5<=depth<=2:return None
        level=w+d*.25*a;past=None
    source=small_snapshot(row,native)
    return {'source':source,'side':d,'old_direction':-d if role==1 else d,'role':role,'level':level,'native_level':w,
        'atr':a,'expiry':row['time']+600,'stage':'接近待ち' if role==2 else '回復待ち','recovery':None,'approach':None,
        'prior_ends':[end-180,end-120,end-60],'past_native':past,
        'middle':{k:row['m15'][k] for k in ('ema8','ema21','slope','end','published')}}


def quantity(source: dict,recovery: dict,held: dict,side: int,level: float) -> dict:
    """
    機能: 二つの非重複区間の実代金/累積量から可用性と量支持を計算する。
    引数: source/recovery/held(dict)、side(int)、level(float)。
    返り値: dictはknown/support/区間平均/速度。未知を0へ置かない。
    """
    result={'known':False,'support':False,'reason':None,'reference_rate':None,'hold_rate':None,'interval_vwap':None}
    points=(source,recovery,held)
    if not all(p['native_known'] for p in points):result['reason']='当該原行未知';return result
    if any(p['epoch']!=source['epoch'] or p['continuity']!=source['continuity'] or p['identity']!=source['identity'] for p in points):
        result['reason']='累積区間又は連続性変更';return result
    intervals=[]
    for a,b in zip(points,points[1:]):
        if not a['time']<b['time'] or not a['line']<b['line'] or not a['volume_time']<b['volume_time']:
            result['reason']='時間又は原行非増加';return result
        dq=b['volume']-a['volume'];dv=b['value']-a['value'];dt=b['time']-a['time']
        if dq<=0 or dv<=0:result['reason']='代金又は数量差分非正';return result
        intervals.append((dq/dt,dv/dq/10000.))
    reference_rate=intervals[0][0];hold_rate,mean=intervals[1]
    result.update(known=True,support=side*(mean-level)>=0 and hold_rate>=.5*reference_rate,
        reference_rate=reference_rate,hold_rate=hold_rate,interval_vwap=mean,
        side_position=side*(mean-level),relative_rate=hold_rate/reference_rate)
    return result


def momentum(row: dict,state: dict) -> bool:
    """
    機能: Rだけ元5分の再加速がないことを公表時点で確認する。
    引数: row/state(dict)。
    返り値: bool。未知MACD増分を0へ変えない。
    """
    if state['role']!=1:return True
    m=row['m5'];delta=m.get('hist_delta')
    return m['published']<=row['time'] and delta is not None and state['old_direction']*delta<=0


def execution_quality(row: dict,native: dict,state: dict) -> bool:
    """
    機能: 発火原行の実Last位置と既存の共通取得品質を確認する。
    引数: row/native/state(dict)。
    返り値: bool。nativeの後続値で固定線を移動しない。
    """
    d=state['side'];distance=d*(native['last']-state['level']) if native['last'] is not None else -math.inf
    return (0<distance<=.75*state['atr'] and 0<row['spread']<=1.5 and row['range']<=2.5
        and row['live'] is not None and d*row['live']>=-.25)


def advance(state: dict,row: dict,native: dict) -> tuple:
    """
    機能: 接近→回復→次足保持を進め、価格出生と明示失効を返す。
    引数: state/row/native(dict)。
    返り値: tuple[birth|None,理由|None]。値未知で源を黙って解除しない。
    """
    source=state['source'];t=row['time'];end=minute_end(row);d=state['side'];a=state['atr'];level=state['level']
    if t>state['expiry']:return None,'源期限'
    if native['epoch']!=source['epoch'] or [native[k] for k in IDENTITY]!=source['identity']:
        # 未知識別の一時欠測と、既知の区間変更を分ける。
        if native['native_known'] or native['epoch']!=source['epoch']:return None,'既知起算変更'
    if t<=source['time'] or end<=source['end']:return None,None
    background=direction(row)
    if state['role']!=1:
        if background is None:return None,None
        if background!=d:return None,'中期非整合'
    if state['role']==2:
        depth=d*(row['close']-state['native_level'])/a
        if depth<-.25:return None,'native反対側へ受容'
        if state['stage']=='接近待ち':
            if -.25<=depth<=.1 and d*row['progress']<0:
                state['approach']=small_snapshot(row,native);state['stage']='回復待ち'
            return None,None
        if end<=state['approach']['end']:return None,None
    recovery=state['recovery']
    if recovery is not None:
        distinct=end==recovery['end']+60 and 30<=t-recovery['time']<=90 and row['line']>recovery['line']
        extreme=row['low'] if d==1 else row['high']
        held=d*(row['close']-level)>0 and d*(extreme-level)>=-.1*a
        if distinct and held and momentum(row,state) and execution_quality(row,native,state):
            now=small_snapshot(row,native);birth={k:v for k,v in state.items() if k!='stage'}
            birth.update(confirmation=now,quantity=quantity(source,recovery,now,d,level))
            return birth,None
        state['recovery']=None
    crossed=d*(row['prior_close']-level)<=0<d*(row['close']-level)
    if crossed and d*row['body']>0 and d*row['progress']>0 and momentum(row,state):
        state['recovery']=small_snapshot(row,native)
    return None,None


def generate(features: list,natives: dict) -> tuple:
    """
    機能: 量条件と独立な三役割の価格源/出生を一度だけ生成する。
    引数: features(list[dict])は直接形成原順、natives(dict)は201一致q0。
    返り値: tuple[dict,dict]は全価格出生と段階件数。量不足で発火を後へ繰越さない。
    """
    states=[None]*3;history=deque(maxlen=3);scene=None;result={};counts=Counter()
    for row in features:
        k=key(row);native=natives[k]
        if scene!=row['session']:scene=row['session'];states=[None]*3;history.clear()
        births=[]
        for role in range(3):
            state=states[role];birth=None
            if state is not None:
                before=(state['stage'],bool(state['recovery']))
                birth,why=advance(state,row,native)
                if why:states[role]=None;counts[f'{role}:失効:{why}']+=1
                elif birth is not None:
                    states[role]=None;counts[f'{role}:価格出生']+=1
                    counts[f'{role}:量可用']+=int(birth['quantity']['known']);counts[f'{role}:量支持']+=int(birth['quantity']['support'])
                else:
                    after=(state['stage'],bool(state['recovery']))
                    if before!=after:counts[f'{role}:段階:{before}->{after}']+=1
            else:
                state=seed(row,native,list(history),role)
                if state is not None:states[role]=state;counts[f'{role}:源']+=1
            births.append(birth)
        result[k]=births;history.append((row,native))
    return result,dict(counts)


def load_inputs() -> tuple:
    """
    機能: 旧83場の固定純入口・直接形成・204原行だけを指紋確認して読む。
    引数: なし。
    返り値: tuple[base,features,natives,refs]。金融ファイルは読まない。
    """
    source=ROOT/'inputs/00200_TOPIXの観測被覆と時間順入口';manifest=read(source/'入力台帳.json');refs=[ref(source/'入力台帳.json')]
    base=[]
    for name in ('旧81純出生','追加2純出生'):
        item=manifest[name];path=ROOT/item['path'];assert ref(path)==item;base+=read(path);refs.append(ref(path))
    paths=[ROOT/'inputs/TOPIX原順8列_20260921_20261116/純特徴184直接.json.gz',
        ROOT/'inputs/00194_20261116夜と1117昼の固定適用入力/TOPIX/純特徴184直接.json.gz']
    features=[]
    for path in paths:features+=read(path);refs.append(ref(path))
    official=read(ROOT/'study/00204_VWAPと価格構造の両指数入口/保存索引.json');expected={r['path']:r for r in official['正本']}
    done=read(DATA/'完了_TOPIX.json');assert not done['financial_labels_used'];refs.append(ref(DATA/'完了_TOPIX.json'))
    natives={}
    for scene in done['scenes']:
        path=DATA/'TOPIX'/(scene['session']+'.json.gz');record=ref(path);assert record==expected[record['path']];refs.append(record)
        for row in read(path)['rows']:
            k=(scene['session'],row['time'],row['line']);assert k not in natives;natives[k]=row
    assert len(base)==len(natives)==35361 and set(map(key,base))==set(natives)
    assert set(map(key,features))<=set(natives) and len(features)==len(set(map(key,features)))
    previous={}
    for row in base:
        scene,t,line=key(row)
        if scene in previous:assert previous[scene][0]<=t and previous[scene][1]<line
        previous[scene]=(t,line)
    assert list(previous)[80:]==['2026-11-16_Day','2026-11-16_Night','2026-11-17_Day']
    return base,features,natives,refs


def choose(births: list,role: int,mode: int) -> tuple:
    """
    機能: 同じ価格出生から量条件を選別し、統合時の売買衝突を待機へする。
    引数: births(list[dict|None])、role(int)は0〜3、mode(int)はP/QK/QV。
    返り値: tuple[int,list[int],bool]は方向・採用役割・衝突。
    """
    price_roles=[i for i,b in enumerate(births) if b is not None and (role==3 or role==i)]
    price_sides={births[i]['side'] for i in price_roles}
    if len(price_sides)>1:return 0,price_roles,True
    selected=[]
    for i in price_roles:
        b=births[i]
        if mode==1 and not b['quantity']['known']:continue
        if mode==2 and not b['quantity']['support']:continue
        selected.append(i)
    sides={births[i]['side'] for i in selected}
    if len(sides)!=1:return 0,selected,False
    return next(iter(sides)),selected,False


def prepare() -> None:
    """
    機能: レビュー済み26候補の純出生とSourceを金融前に封印する。
    引数: なし。
    返り値: None。量条件の変更や追加2による再選択はしない。
    """
    artificial=read(HERE/'人工確認.json');assert artificial['成功'] and artificial['金融未使用']
    assert artificial['SourceSHA']==ref(Path(__file__))['sha256']
    base,features,natives,input_refs=load_inputs();generated,counts=generate(features,natives);maps={key(r):r for r in features}
    output=[];support=Counter();conflicts=Counter()
    for row in base:
        k=key(row);births=generated.get(k,[None]*3);formed=maps.get(k)
        signals=[row['signals'][0],row['signals'][0]];widths=[row['widths'][0],15.];origins=[row['origins'][0],row['origins'][0]]
        choices=[]
        for role in range(4):
            for mode in range(3):
                side,roles,conflict=choose(births,role,mode);choices.append({'roles':roles,'conflict':conflict})
                if conflict:conflicts[f'{role}/{mode}']+=1
                for width in WIDTHS:
                    value=15. if width=='W15' else math.ceil(min(25.,max(5.,formed['atr']*2.5))*4)/4 if formed else None
                    index=len(signals);signals.append(side);widths.append(value);origins.append(NAMES[index])
                    if side:support[NAMES[index]+':'+row['band']]+=1
        assert len(signals)==26
        output.append({'session':row['session'],'time':row['time'],'line':row['line'],'band':row['band'],
            'signals':signals,'widths':widths,'origins':origins,'births':births,'choices':choices})
    save(PURE/'純入口.json.gz',output)
    sources=[Path(__file__),HERE/'人工確認207.py',HERE/'人工確認.json',HERE/'金融前設計案.md',
        ROOT/'scripts/TOPIX入口研究/共通金融.py',ROOT/'work/183TOPIX/金融を比較する.py',ROOT/'work/183TOPIX/入口とIFD.py',
        ROOT/'work/183損失安定性/安定性183.py',ROOT/'scripts/入口分析/分析.py']
    cfg={'試行':207,'候補':list(NAMES),'規模':26,'Source':{r['path']:r['sha256'] for r in map(ref,sources)},
        '純入口SHA':ref(PURE/'純入口.json.gz')['sha256'],'入力':input_refs,'情報区分':'全83既使用。前48選択と全80発見を分離。後25/追加7/本日1/追加2は診断。',
        '候補選択':'新候補はQVのみ。P/QKは価格と可用性の寄与対照。統合は同側一つ・反対衝突待機。',
        '条件正本':'work/207VWAP/金融前設計案.md','金融未実行':True,'価格出生共用':True,
        '幅期限':'新候補は全帯W15又はq0直接ATR5×2.5（5〜25pt、0.25切上げ）、H60、単純IFD。C0旧幅/C1全W15。',
        '数量費用':'保有予約合計1、終了15分前、miniTOPIX片道41.8円＋0.25pt。',
        '母体期待':ref(ROOT/'work/200TOPIX/全83金融正本/TOPIX200_N00_旧共通1分量_品質制限なし_源で即時_DayA25_NightW15_H60.json.gz')}
    save(HERE/'条件.json',cfg)
    save(HERE/'純封印.json',{'金融未使用':True,'条件':ref(HERE/'条件.json'),'純出生':ref(PURE/'純入口.json.gz'),
        'q0':len(output),'直接形成q0':len(features),'段階':counts,'純成立':dict(support),'衝突':dict(conflicts)})
    print(json.dumps({'候補':26,'q0':len(output),'段階':counts,'衝突':dict(conflicts)},ensure_ascii=False),flush=True)


if __name__=='__main__':prepare()
