"""207の固定条件・全金融・原因・版8・最小Sourceを正式保存する。"""
from pathlib import Path
import gzip,hashlib,json,os,re,shutil,zipfile

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
TRIAL=ROOT/'study/00207_VWAPと固定価格の時間順入口を量支持で比較する'
INPUT=ROOT/'inputs/00207_TOPIXのVWAPと固定価格の純入口'


def read(path: Path) -> object:
    """
    機能: 固定JSONを読む。
    引数: path(Path)。
    返り値: object。
    """
    with gzip.open(path,'rt',encoding='utf-8') if path.suffix=='.gz' else path.open(encoding='utf-8') as f:return json.load(f)


def ref(path: Path) -> dict:
    """
    機能: 正式資源の内容指紋を作る。
    引数: path(Path)。
    返り値: dictは相対path/bytes/SHA。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


def main() -> None:
    """
    機能: 原板と入力を複製せず正式な閲覧と再現の正本を保存する。
    引数: なし。
    返り値: None。固定207条件を変更せず新仮説は別試行にする。
    """
    TRIAL.mkdir(parents=True,exist_ok=True);cfg=read(HERE/'条件.json');assert read(HERE/'金融独立確認.json')['成功']
    names=('条件.json','純封印.json','人工確認.json','純独立確認.json','金融独立確認.json','固定選択.json',
        '全26口座短表.json.gz','実取得差分.json.gz','原因診断.json.gz','位置と期間.json')
    for name in names:shutil.copy2(HERE/name,TRIAL/name)
    shutil.copy2(HERE/'金融前設計案.md',TRIAL/'金融前条件.md')
    for name in ('金融開始前固定.json','安定性.json.gz'):shutil.copy2(HERE/'金融'/name,TRIAL/name)
    if (HERE/'金融再現/検算.json').exists():shutil.copy2(HERE/'金融再現/検算.json',TRIAL/'再現同体確認.json')
    (TRIAL/'金融正本').mkdir(exist_ok=True)
    for path in (HERE/'金融/金融正本').glob('*.json.gz'):shutil.copy2(path,TRIAL/'金融正本'/path.name)
    # ----------------------------------------
    rows=read(HERE/'全26口座短表.json.gz');table=['# 207 全26口座の比較','',
        '全83場・既使用。mini TOPIX1枚、片道41.8円＋0.25pt。未知がある金額は既知寄与。P/QKは対照、QVだけが新候補選択対象。',
        '', '| 候補 | 帯 | 取得/未知 | 参加場 | 保有% | 利益円 | 損失円 | 既知収支円 | 建玉/場中央値下限円 | DD円 |',
        '| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
    for row in rows:
        for band in ('DAY','NIGHT'):
            g=row['全83'][band];table.append(f"| {row['候補']} | {band} | {g['取得']}/{g['未知']} | {g['参加場']}/{g['全場']} | {100*g['保有下限']:.2f} | {g['利益']:,.1f} | {g['損失']:,.1f} | {g['既知収支']:,.1f} | {g['建玉中央値下限']}/{g['場中央値下限']} | {g['場末DD既知寄与']:,.1f} |")
    (TRIAL/'全26結果.md').write_text('\n'.join(table)+'\n',encoding='utf-8')
    # ----------------------------------------
    template=ROOT/'docs/議論/手法と時間スケールの汎用表_版8.md';body=template.read_text(encoding='utf-8').split('## 設定明細')[0]
    body=body.replace('# 手法と時間スケールの汎用表・版8','# 207 設定と結果（版8）').replace('全セルは未設定・未検証。','使用セルへ設定IDを記す。').replace('未設定・未検証','未使用')
    used={'I01':{3:'C0旧EMA',4:'S1中期8/21並びと21傾き'},'I02':{3:'S2源ATR距離'},'I03':{3:'S3元方向増分非正'},
        'I04':{3:'C0旧条件'},'I08':{3:'C0旧条件'},'I09':{3:'S2源固定ATR/R1発火ATR'},'I12':{0:'S2源native固定/S4区間代金数量比'},
        'C01':{4:'S1中期方向'},'C07':{1:'S2/S3回復と保持'},'P01':{1:'S3実体/端保持'},'P05':{1:'S3進行'},
        'P06':{1:'S2前3完成足端'},'P07':{1:'S3次足保持'},'V01':{0:'S4区間数量速度0.5倍'},
        'B01':{0:'正常BBO/Last位置/C0旧費用方向'},'E01':{0:'R1同幅IFD'},'E02':{0:'R1 H60/末尾15分'}}
    lines=[];count=0
    for line in body.splitlines():
        cells=[c.strip() for c in line.strip().strip('|').split('|')] if line.startswith('|') else []
        if len(cells)==11 and re.fullmatch(r'[A-Z][0-9]{2}',cells[0]):
            count+=1
            for i in range(9):cells[i+2]=used.get(cells[0],{}).get(i,'未使用')
            line='| '+' | '.join(cells)+' |'
        lines.append(line)
    assert count==63
    body='\n'.join(lines)+'\n';body=re.sub(r'\]\(([^)]+)\)',lambda m:']('+os.path.relpath((template.parent/m.group(1)).resolve(),TRIAL).replace('\\','/')+')',body)
    body+='''
## 設定明細と複合評価

C0は旧190 D4/N01。C1は同じ入口の全帯W15。S1〜S4は独立出生であり旧P0成立を必須にしない。

S1は公表済み15分EMA8/21の並びと21傾き。S2は源native又は当足を除く前3完成1分端、源ATRと全段階600秒を固定。Tの過去native側滞在は各過去q0の当時値で判定する。Fは源→接近→再開→保持、Rは端突破→失敗回復→保持。詳細の全閾値は[金融前条件](金融前条件.md)が正本。

S3は別完成1分end・別原行、次足30〜90秒、逆端侵入0.1源ATR以下、当時Lastの線から距離0.75源ATR以下。Rのみ5分MACD元方向増分非正。未知で元源を解除せず、明示的区間変更と期限は理由付き失効。売買は鏡像。

S4のPは量不使用の対照、QKは同じ累積/識別/continuityと正の代金量差分、QVは区間取引平均が固定線側かつ保持時数量速度が源→回復の0.5倍以上。native位置と傾きを独立二票に数えず、HLC3を取引VWAPと呼ばない。P/QK/QVの価格出生を共用し、量不成立を後の時刻へ繰り越さない。

R1は単純IFD W15/A25、A25は当時直接5分ATR×2.5を5〜25ptへ制限し0.25切上げ。H60、保有予約合計1枚、終了15分前、mini TOPIX片道41.8円＋0.25pt。

結果は[全26結果](全26結果.md)。前48/全80のQV選択は全てnull。F A25の13取得黒字は支持不足の有望診断として残す。指標単独の効果、全場20%達成、未見再現とはしない。
'''
    (TRIAL/'設定と結果.md').write_text(body,encoding='utf-8')
    # ----------------------------------------
    (TRIAL/'README.md').write_text('''# 207 VWAPと固定価格の時間順入口を量支持で比較する

2026-11-18。**全置換の採用候補は得られていない。nativeへの戻り失敗を元方向へ取るFは、少数ながら次に調べる価値を残す。** 全83場は既使用であり、前48選択と全80発見を分離した全6選択はnull。P/QKを新候補に昇格させない。

[全26結果](全26結果.md) / [設定と結果・版8](設定と結果.md) / [金融前条件](金融前条件.md) / [固定選択](固定選択.json) / [原因診断](原因診断.md) / [再現](再現.md)

## 仮説・入力・金融

旧18/19のnative位置＋傾きの同時ANDを繰り返さず、T押戻し、R端突破失敗、F回復失敗後の継続を時間順で分けた。旧190固定と全帯W15の2対照、新3役割＋統合×P/QK/QV×W15/A25の24案、合計26口座。新案は184直接形成から独立に出生し、旧P0や費用で方向を選ばない。

入力は旧81場と194追加2場、201と同じ35,361 q0、204で検算した同原行native/代金/数量。直接形成35,087 q0以外も旧母体・場分母には残す。nativeは当場VWAPと同じではない。[204入力監査](../00204_VWAPと価格構造の両指数入口/README.md)。原板は共用し複製しない。

mini TOPIX1枚、片道税込41.8円＋0.25pt滑り。単純IFDは±15pt又は発火時ATR5×2.5（5〜25pt、0.25切上げ）、H60、保有予約合計1、デイ15:30/ナイト05:45までの全決済。ラージBBOによる約定代用でありmini板の実約定保証ではない。未知は0円とせず、枠を場末まで保持する。

## 主な結果

- 旧190は全83場390取得、利益1,670,112.8円・損失1,385,631.6円・既知収支284,481.2円、未知7。新統合QV/A25は176取得、利益493,315.2円・損失785,192.8円・既知収支−291,877.6円、未知10。
- 統合QV/A25はDay38/42場・保有23.03%、Night39/41場・12.87%。Dayも両中央値は赤字で、参加だけの問題ではない。
- R/A25は145取得、既知−261,954円。141取得で確認時にも15分が元方向に整合し、この群は−277,619.6円。短い端の失敗を中期反転へ読み替えた点を次の検証対象とする。
- T/A25はDay13取得＋38,663.2円、Night30取得−58,090円（未知5）。30分実側整合の群も赤字で、長期条件のAND追加を解決としない。
- F/A25は13取得/11場、利益79,414円・損失20,250.8円・収支59,163.2円、未知0、保有1.27%。前48は5取得＋9,332円、後25は7取得＋35,414.8円、追加7は1取得＋14,416.4円。全場中央値0で少支持。これを安定採用や完了とはしない。

PとQKは全8組で金融同体。今回の量比較の差は欠測による選別ではなくQVの支持条件と、それで変わる後続枠である。量支持はNightの損失を減らす比較がある一方、RのDayでは黒字取引も除いて悪化した。

## 検査と限界

人工21項目119属性、純出生/全26信号1,859,767属性、金融別算術112,684属性、全919,386 q0の別状態枠再生61,541属性が一致。旧C0のledger/sessions/positionsとP/QK金融同体を確認した。

純照合は全保存出生の境界と信号を検算したもので、未成立源を含む全状態機械の別実装ではない。金融の別枠検査は固定Routeを共用し、原BBO決済の新たな独立再走査と区別する。過去端までの距離は将来の利益余地を保証しない。反転率を1−pで推定せず、新しい方向や参照水準は209で事前固定して再生する。
''',encoding='utf-8')
    (TRIAL/'原因診断.md').write_text('''# 207の役割・量・取得位置の診断

これは固定207の事後分解であり、新入口の成績ではない。[数値正本](原因診断.json.gz) / [位置と期間](位置と期間.json) / [共通取得と枠差](実取得差分.json.gz)

R/A25は145取得中141で15分が元方向のまま、30分も元側110取得で−178,362.4円。元方向の5分MACD増分が非正という小さな失速と、元の中期方向が崩れたことは異なる。取得遅れ5秒以内の110取得も−210,861.6円であり、執行遅れだけを原因にしない。反対側への取得は実BBOで別試行にて比較する必要がある。

T/A25の30分実側整合29取得は−52,840円。追加の長期ANDが常に救うという説明にはならない。量速度比1以上の群は21取得＋22,328.8円、0.5〜1未満は22取得−41,755.6円だが、事後群の閾値選択として扱い、207を書き換えない。

F/A25は源から入口までの価格移動中央値が実側−0.217ATR、Tは＋0.539、Rは＋0.505。源で取得するより有利な位置へ戻るFと、回復を待つ間に進んだT/Rを区別する。ただし源前3本の実側端までの距離中央値はF0.256ATR/T0.372/R0.202で、IFD幅以上先に端がある取得はF1/T0/R0。短い過去端を将来の確定抵抗・利確限界とはせず、短い価格構造の受容だけでH60の広い値幅を期待した点を調べる。

Fの源1,007件に対して戻り接近145件、価格出生19件、量支持13件。native付近まで戻る機会の限定が大きい。同じ「反対側に受容されず元側へ再開」の役割を、native以外の合理的な水準へ広げる余地がある。F13取得の12件は同q0で旧190が不成立であり、単なる旧N01コスト反転の修正ではない。

## 量の確認と枠

T/A25 Dayは量追加で共通13取得を残し、旧だけ1件の−12,583.6円がなくなった。Nightは旧だけ9件−28,252.4円を外す一方、新だけ2件−5,667.2円が入り、差を「除外した損失」だけで説明しない。

R/A25 Dayは共通76取得−188,603.6円、旧だけ7件＋41,414.8円、新だけ2件＋16,082.8円。量を伴う反転確認を強めても入口全体は改善しなかった。Nightは旧だけ20件−63,338.4円、新だけ7件−5,751.6円で損失軽減するが、全体赤字・未知・参加不足が残る。

F/A25 Nightは共通7件＋13,664.8円、旧だけ5件−10,918円、新だけ0。今回の量支持の差は実現取引の選別で確認できる。ただし全13取得の小さな支持で、一般化の証明ではない。

C0→C1は入口を変えずDayをW15へ変更し、利益は−8,749.2円、損失は−34,500円、収支は＋25,750.8円となる一方、赤字Day率は40.48%→54.76%、場中央値は＋1,873.4→−1,209円。幅を変えた累計増益を入口精度改善や安定性向上と呼ばない。
''',encoding='utf-8')
    # ----------------------------------------
    (TRIAL/'再現.md').write_text('''# 207の再現

Python3.14.3、NumPy2.5.4。Source ZIPをリポジトリ相対位置へ戻し、恒久inputsを参照する。原板は複製しない。

```powershell
& 'work/複合テクニカル学習環境/Scripts/python.exe' -X utf8 'work/207VWAP/人工確認207.py'
& 'work/複合テクニカル学習環境/Scripts/python.exe' -X utf8 'work/207VWAP/入口207.py'
& 'work/複合テクニカル学習環境/Scripts/python.exe' -X utf8 'work/207VWAP/独立純照合207.py'
& 'work/複合テクニカル学習環境/Scripts/python.exe' -X utf8 'scripts/TOPIX入口研究/共通金融.py' --condition 'work/207VWAP/条件.json' --births 'inputs/00207_TOPIXのVWAPと固定価格の純入口/純入口.json.gz' --output 'work/207VWAP/金融再現' --id-template 'TOPIX207_{name}' --extra --expected-dir 'study/00207_VWAPと固定価格の時間順入口を量支持で比較する/金融正本' --expected-metrics 'study/00207_VWAPと固定価格の時間順入口を量支持で比較する/安定性.json.gz'
```

既存の固定保存先へ異なる内容を書かない。抽出はすでに固定済みの入力を使い、純入力全体をSource ZIPへ重複格納しない。204の入力は[純入力正本](../../inputs/00204_両指数の配信VWAP純入力/README.md)、200の旧母体は[入力台帳](../../inputs/00200_TOPIXの観測被覆と時間順入口/入力台帳.json)、原順8列は[台帳](../../inputs/TOPIX原順8列_20260921_20261116/台帳.json)と[追加2台帳](../../inputs/00194_20261116夜と1117昼の固定適用入力/原順8列/入力台帳.json)を参照する。

純入口の生成は生産入口ファイルだけをimportし、金融は別工程。金融後確認はwork/207VWAP/金融を対象とするので、別環境の監査再実行では正式金融と同体な再現結果を当該位置へ復元してから実行する。旧C0比較用のwork/200TOPIX全83 N00正本は[201金融Source ZIP](../00201_板数量の更新尺度を複合入口へ加える/金融Source.zip)に元相対pathで保存済み。新たな親金融の複製を省く。

人工・純照合・金融後確認・原因診断のSourceと指紋は[Source索引](Source索引.json)、全正式資源は[保存索引](保存索引.json)で確認する。
''',encoding='utf-8')
    (INPUT/'README.md').write_text('# 207 TOPIXの純入口\n\n[研究正本](../../study/00207_VWAPと固定価格の時間順入口を量支持で比較する/README.md)。全83場35,361 q0・26候補を新金融前に封印。原板は共用、nativeは204の同原行。条件と金融はstudyに保存し、入力はこの場所に一度だけ保存する。\n',encoding='utf-8')
    (INPUT/'入力台帳.json').write_text(json.dumps({'試行':207,'純入口':ref(INPUT/'純入口.json.gz'),'条件':ref(TRIAL/'条件.json'),'全83既使用':True},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    # ----------------------------------------
    sources=set(ROOT/p for p in cfg['Source'])|set(HERE.glob('*.py'))
    sources.update(ROOT/'work/183損失安定性'/n for n in ('TOPIXを独立検算する.py','新候補の集計を独立検査する.py'))
    sources.update(ROOT/'work/183TOPIX'/n for n in ('入力台帳.json','条件_実装修正1.json'))
    with zipfile.ZipFile(TRIAL/'Source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(sources):z.write(p,p.relative_to(ROOT).as_posix())
    (TRIAL/'Source索引.json').write_text(json.dumps([ref(p) for p in sorted(sources)],ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    files=sorted(p for p in TRIAL.rglob('*') if p.is_file() and p.name!='保存索引.json')+sorted(INPUT.glob('*'))
    (TRIAL/'保存索引.json').write_text(json.dumps({'Source固定不変':all(ref(ROOT/p)['sha256']==sha for p,sha in cfg['Source'].items()),
        '汎用セル':567,'正本':[ref(p) for p in files]},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    links=0
    for p in [*TRIAL.glob('*.md'),INPUT/'README.md']:
        for link in re.findall(r'\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
            if '://' in link or link.startswith('#'):continue
            assert (p.parent/link.split('#')[0]).resolve().exists(),(p,link);links+=1
    print('正式正本',len(files),'Source',len(sources),'汎用セル567','リンク',links,'成功')


if __name__=='__main__':main()
