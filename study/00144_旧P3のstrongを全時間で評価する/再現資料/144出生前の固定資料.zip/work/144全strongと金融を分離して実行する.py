"""144の全strong出生・取得・金融を分離して固定するRoot運転部。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
OWN = ROOT/'work/144旧strongの全成立評価'
GEN = ROOT/'work/144旧P3strongの全成立'
AGG = ROOT/'work/144旧strongの全成立集計'
FORMAL = ROOT/'study/00144_旧P3のstrongを全時間で評価する'
INPUT = ROOT/'work/122全場入力/入力.json'
INPUT_SHA = '6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec'
SOURCE = OWN/'Sourceの出生と取得.json'
BRIDGE = ROOT/'work/144旧strongと対照を固定取得へ渡す.py'
FIXED = OWN/'固定入力/固定取得入力.json'
META = OWN/'固定入力/入口参照.json'
OBSERVED = OWN/'固定取得の正逆観測.json'
KERNEL = ROOT/'work/133固定取得の正逆評価器/固定取得の正逆評価.exe'


def sha(path: Path) -> str:
    """
    機能: 保存bytesの指紋を求める。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def module(path: Path, name: str) -> object:
    """
    機能: mainを呼ばず依存宣言を私有読込する。
    引数: path(Path)、name(str)はコードと内部名。
    返り値: objectはモジュール。
    """
    previous = list(sys.path)
    try:
        sys.path.insert(0,str(path.parent))
        spec = importlib.util.spec_from_file_location(name,path)
        value = importlib.util.module_from_spec(spec);spec.loader.exec_module(value)
        return value
    finally:
        sys.path[:] = previous


# ----------------------------------------
def main() -> None:
    """
    機能: 旧strong全成立の自然生成、固定取得、保存正逆の金融を別々に実行する。
    引数: CLI --mode(str)は固定/出生/転送/金融前/観測/集計。
    返り値: None。既存成果を上書きしない。
    """
    p = argparse.ArgumentParser(description='144の全strongと金融を分離する')
    p.add_argument('--mode',choices=('固定','出生','転送','金融前','観測','集計'),required=True)
    args = p.parse_args()
    helper = module(ROOT/'work/133金融前を固定して実行する.py','144の固定補助')
    f0,f1 = OWN/'F0出生前.json',OWN/'F1金融前.json'
    OWN.mkdir(parents=True,exist_ok=True)
    if args.mode == '固定':
        assert sha(INPUT) == INPUT_SHA
        assert sha(KERNEL) == '033cf22a052e985bc61aa020a04fa6d499119051aaa39bb2adb715a4af1e7736'
        assert json.loads((GEN/'準備の確認.json').read_bytes())['成功']
        bridge = module(BRIDGE,'144の転送宣言')
        files = {Path(__file__).resolve(),INPUT,KERNEL,BRIDGE,
            ROOT/'work/144転送の人工検査.py',ROOT/'work/144_旧P3strongを全成立へ広げる採用仕様.md',
            ROOT/'work/133金融前を固定して実行する.py'}
        for path,expected in bridge.SHAS.items(): assert sha(path) == expected,path;files.add(path)
        for folder in (GEN,FORMAL,ROOT/'work/118複数技法の入口条件'):
            assert folder.is_dir()
            files.update(q for q in folder.rglob('*') if q.is_file() and q.suffix in ('.go','.mod','.py','.md','.json','.exe'))
        for name in ('README.md','条件.md','設定と結果.md'): assert (FORMAL/name).is_file()
        helper.save(f0,{'成功':True,'試行':144,'段階':'全strong自然出生前F0','UTC':datetime.now(timezone.utc).isoformat(),
            '主':'U0=旧C081＋全strong出生時T8、同原行C0優先','政策':['U0','N0','S0','T0','C0'],
            '追加2場未読':True,'deadline新規連発':False,'場回数の均等化':False,
            'ファイル':{str(q):sha(q) for q in sorted(files)}})
        print(json.dumps({'F0_SHA256':sha(f0),'固定源数':len(files)},ensure_ascii=False));return
    frozen = json.loads(f0.read_bytes());helper.verify(frozen)
    if args.mode == '出生':
        assert not SOURCE.exists()
        command = [str(GEN/'Strong全成立生成.exe'),'--input',str(INPUT),'--sha256',INPUT_SHA,
            '--output',str(SOURCE),'--workers','8','--execute-after-f0']
    elif args.mode == '転送':
        command = [sys.executable,'-X','utf8',str(BRIDGE),'--f0',str(f0),'--f0-sha256',sha(f0),
            '--source',str(SOURCE),'--sha256',sha(SOURCE),'--output-dir',str(FIXED.parent)]
    elif args.mode == '金融前':
        declared = module(AGG/'集計する.py','144金融の依存宣言')
        files = {Path(q) for q in frozen['ファイル']} | {f0,SOURCE,FIXED,META,FIXED.parent/'転送の確認.json'}
        for path,expected in declared.SOURCES.items(): assert sha(path) == expected,path;files.add(path)
        files.update(q for q in AGG.rglob('*') if q.is_file() and q.suffix in ('.py','.md','.json'))
        helper.save(f1,{'成功':True,'試行':144,'段階':'全取得と二方向固定後F1','UTC':datetime.now(timezone.utc).isoformat(),
            'F0_SHA256':sha(f0),'主政策':'U0','主価格':'実BBO','主秒':3600,'主幅':125,
            '金融後の主交換':False,'ファイル':{str(q):sha(q) for q in sorted(files)}})
        print(json.dumps({'F1_SHA256':sha(f1),'固定源数':len(files)},ensure_ascii=False));return
    else:
        finance = json.loads(f1.read_bytes());helper.verify(finance)
        if args.mode == '観測':
            assert not OBSERVED.exists()
            command = [str(KERNEL),'--input',str(FIXED),'--sha256',sha(FIXED),'--output',str(OBSERVED),'--workers','8']
        else:
            command = [sys.executable,'-X','utf8',str(AGG/'集計する.py'),'--f1',str(f1),'--f1-sha256',sha(f1),
                '--fixed-input',str(FIXED),'--fixed-input-sha256',sha(FIXED),'--metadata',str(META),'--metadata-sha256',sha(META),
                '--result',str(OBSERVED),'--result-sha256',sha(OBSERVED),'--output-dir',str(OWN/'金融評価')]
    subprocess.run(command,cwd=ROOT,check=True);helper.verify(frozen)
    if args.mode in ('観測','集計'): helper.verify(finance)
    if args.mode == '観測': helper.verify_result(json.loads(OBSERVED.read_bytes()),json.loads(FIXED.read_bytes()))
    helper.save(OWN/(args.mode+'の完了.json'),{'成功':True,'試行':144,'段階':args.mode,
        'F0_SHA256':sha(f0),'全固定源前後同体':True,'実行列':command})


if __name__ == '__main__':
    main()
