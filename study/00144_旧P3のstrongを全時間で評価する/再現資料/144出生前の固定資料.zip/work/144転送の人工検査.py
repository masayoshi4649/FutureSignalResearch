"""144のunion転送を、自然価格を開かず人工資料で検査する。"""
from pathlib import Path
import copy
import importlib.util

SOURCE = Path(__file__).with_name('144旧strongと対照を固定取得へ渡す.py')
spec = importlib.util.spec_from_file_location('144転送の純部品', SOURCE)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def fixture() -> tuple[dict, list, dict]:
    """
    機能: 二場に旧対照2件・新規2件・非取得1件の人工資料を作る。
    引数: なし。
    返り値: tuple[dict,list,dict]は共用metadata・旧対照・V0資料。
    """
    common = {'scenes': []}; controls = []; source = {'success': True, 'trial': 144, 'scenes': []}
    for number in range(2):
        sid = '人工場' + str(number); start = 10000 * number
        q = {'time': start+100, 'index': 100, 'source_line': 101, 'clock': '人工価格時計', 'last': 100,
             'bid': 95, 'ask': 105, 'quote_ok': True}
        base = {'session': sid, 'contract': '人工限月', 'start': start, 'end': start+8000,
                'force_close': start+7900, 'raw': {'path': '人工原本', 'sha256': '0'*64},
                'expected_quality': {'人工品質': True}, 'entries': []}
        common['scenes'].append(base)
        controls.append({'id': sid+'/対照', 'session': sid, 'contract': '人工限月', 'side': 1,
                         'entryQuote': q, 'origins': [{'人工': True}]})
        birth = {**q, 'time': start+99, 'index': 98, 'source_line': 99}
        event = {'id': sid+'/新規', 'side': -1, 'status': 'filled', 'entryQuote': copy.deepcopy(q),
                 'birth': birth, 'episode_id': sid+'/過程', 'trace': {'人工': True}, 't8_side':1, 'strong_type':'trend', 'consumed_key':{'frame5':'人工5分','side':-1}, 'score':{'人工':True}, 'direction':{'人工':True}}
        if number == 1:
            event['entryQuote'] = {**q, 'time': start+101, 'index': 101, 'source_line': 102}
        source['scenes'].append({'success': True, 'session': sid, 'contract': '人工限月',
                                'actual_sha256': '0'*64, 'counts': {'人工品質': True},
                                'stat_before': {'人工': True}, 'stat_after': {'人工': True},
                                'events': [event, {**event, 'id': sid+'/取消', 'status': 'cancelled', 'entryQuote': None}]})
    return common, controls, source


# ----------------------------------------
def main() -> None:
    """
    機能: 異方向同原行の優先・0新規・重複拒否・時計拒否を検査する。
    引数: なし。fixtureの人工入力のみ使用する。
    返り値: None。不一致はassertionで停止する。
    """
    common, controls, source = fixture()
    fixed, meta = module.build(common, controls, source)
    assert fixed['expected_entry_count'] == len(meta['entries']) == 4 and len(meta['union']) == 3
    assert meta['union'][0]['canonical_id'] == 'C0/人工場0/対照' and len(meta['union'][0]['alias_ids']) == 2
    assert set(meta['union'][0]['alias_sides'].values()) == {-1, 1}
    empty = copy.deepcopy(source)
    for scene in empty['scenes']: scene['events'] = []
    f, m = module.build(common, controls, empty)
    assert f['expected_entry_count'] == len(m['union']) == 2 and len(f['scenes']) == 2
    for kind in ('同family同原行', '取得前出生', '品質不一致', 'T8不正', 'TTL等号'):
        altered = copy.deepcopy(source)
        if kind == '同family同原行':
            altered['scenes'][0]['events'].append({**altered['scenes'][0]['events'][0], 'id': '別名重複'})
        elif kind == '取得前出生':
            altered['scenes'][0]['events'][0]['birth']['time'] += 100
        elif kind == '品質不一致':
            altered['scenes'][0]['counts'] = {'人工品質': False}
        elif kind == 'T8不正':
            altered['scenes'][0]['events'][0]['t8_side'] = 0
        else:
            altered['scenes'][0]['events'][0]['entryQuote']['time'] = altered['scenes'][0]['events'][0]['birth']['time']+30
        try: module.build(common, controls, altered)
        except AssertionError: pass
        else: raise AssertionError('拒否漏れ: '+kind)
    print('人工7群成功。自然原板・新損益は未読。')


if __name__ == '__main__':
    main()
