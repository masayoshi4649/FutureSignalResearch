package strongstream144

import (
	"bytes"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"os"
	"path/filepath"
	"testing"
	"time"
)

// detectorFixture144 は旧score人工と同じSnapshotで新しい当場状態を作ります。
//
// 引数: t(*testing.T)。返り値: *DetectorはSource保有もcoveredも持たない状態です。
func detectorFixture144(t *testing.T) *Detector {
	t.Helper()
	d, e := New(Scene144{Session: "current", Contract: "X", Start: 90000, End: 110000, ForceClose: 108000})
	if e != nil {
		t.Fatal(e)
	}
	return d
}

// Test144消費キーとpending順序 は同足再要求抑止とpending中の新キー非消費を確認します。
//
// 引数: t(*testing.T)。返り値: なし。自然価格は読みません。
func Test144消費キーとpending順序(t *testing.T) {
	b, w, q := scoreFixture133(t, true, false, nil)
	d := detectorFixture144(t)
	q.Time = 100280
	q.Index = 180
	q.SourceLine = 181
	if e := d.Observe(b, w, q); e != nil {
		t.Fatal(e)
	}
	if len(d.Events) != 1 || d.Events[0].Status != "pending" {
		t.Fatal("初回出生")
	}
	first := d.Events[0]
	if first.ConsumedKey != fmt.Sprintf("%s/%d", first.Frame5.ID, first.Side) {
		t.Fatal("キーが足IDと元方向以外を含む")
	}
	p := scorePublication133("current", 300, 200, 100240)
	if e := b.Add(p); e != nil {
		t.Fatal(e)
	}
	w.observe(p)
	q.Time = 100300
	q.Index = 200
	q.SourceLine = 201
	q.QuoteOK = false
	q.Bid = 0
	q.Ask = 0
	if e := d.Observe(b, w, q); e != nil {
		t.Fatal(e)
	}
	if len(d.Events) != 1 || len(d.consumed) != 1 {
		t.Fatal("pending中に新キー消費")
	}
	q.Time = 100301
	q.Index = 201
	q.SourceLine = 202
	q.QuoteOK = true
	q.Bid = 105
	q.Ask = 110
	if e := d.Observe(b, w, q); e != nil {
		t.Fatal(e)
	}
	if first.Status != "filled" || len(d.Events) != 2 || d.Events[1].Frame5.ID != p.Frame.Frame.ID {
		t.Fatal("既pending終了後の新出生なし")
	}
	second := d.Events[1]
	q.Time = second.Expires
	q.Index++
	q.SourceLine++
	if e := d.Observe(b, w, q); e != nil {
		t.Fatal(e)
	}
	if second.Status != "unfilled_expired" || len(d.Events) != 2 {
		t.Fatal("等号失効後に同キー再要求")
	}
	d.Finish()
	if len(d.consumed) != 2 {
		t.Fatal("消費キー復活")
	}
}

// Test144同じ出生の価格鏡像 は旧score/strongとT8の方向が対称であることを確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func Test144同じ出生の価格鏡像(t *testing.T) {
	b, w, q := scoreFixture133(t, true, false, nil)
	mb, mw, mq := scoreFixture133(t, true, true, nil)
	d, md := detectorFixture144(t), detectorFixture144(t)
	if e := d.Observe(b, w, q); e != nil {
		t.Fatal(e)
	}
	if e := md.Observe(mb, mw, mq); e != nil {
		t.Fatal(e)
	}
	if len(d.Events) != 1 || len(md.Events) != 1 {
		t.Fatal("出生鏡像")
	}
	a, z := d.Events[0], md.Events[0]
	if a.Side != -z.Side || a.T8Side != -z.T8Side || a.StrongType != z.StrongType {
		t.Fatal("元/T8/型の鏡像差")
	}
	if e := CheckStoredStrong(a.Score, a.Direction, a.Side); e != nil {
		t.Fatal(e)
	}
	if e := CheckStoredStrong(z.Score, z.Direction, z.Side); e != nil {
		t.Fatal(e)
	}
	wrong := a.Direction
	wrong.T8Side = -wrong.T8Side
	if CheckStoredStrong(a.Score, wrong, a.Side) == nil {
		t.Fatal("旧保存T8不一致を受理")
	}
}

// Test144取得TTLと悪気配 は旧非E0の別行1秒/最初正常/TTL等号を確認します。
//
// 引数: t(*testing.T)。返り値: なし。cap/risk/現在strong再検査を追加しません。
func Test144取得TTLと悪気配(t *testing.T) {
	makeEvent := func() *Event {
		return &Event{Side: 1, T8Side: -1, Birth: Quote{Time: 100, Index: 1, SourceLine: 2}, Status: "pending", Expires: 130}
	}
	e := makeEvent()
	q := Quote{Time: 100, Index: 2, SourceLine: 3, Last: 5000, Bid: 4900, Ask: 5100, QuoteOK: true}
	pending144(e, q, 1000)
	if e.Status != "pending" {
		t.Fatal("同秒取得")
	}
	q.Time = 101
	q.QuoteOK = false
	pending144(e, q, 1000)
	if e.Status != "pending" {
		t.Fatal("悪気配取得")
	}
	q.Time = 102
	q.QuoteOK = true
	pending144(e, q, 1000)
	if e.Status != "filled" || *e.EntryPrice != 5100 || *e.EntryPriceT8 != 4900 || e.EntryQuote != e.Evaluation {
		t.Fatal("共通Quoteと別実側価格")
	}
	e = makeEvent()
	q.Time = 130
	pending144(e, q, 1000)
	if e.Status != "unfilled_expired" {
		t.Fatal("TTL等号")
	}
	e = makeEvent()
	q.Time = 120
	pending144(e, q, 120)
	if e.Status != "force_close" {
		t.Fatal("新規限界等号")
	}
}

// Test144期限方向を生成しない はstrong不成立なら3時間後でも出生しないことを確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func Test144期限方向を生成しない(t *testing.T) {
	b, w, q := scoreFixture133(t, true, false, func(p *rules.Publication, i int) {
		if p.Frame.Frame.Width == 300 {
			p.Frame.Frame.Technical.RSI = value133(80)
		}
	})
	d := detectorFixture144(t)
	q.Time = 100001
	if e := d.Observe(b, w, q); e != nil {
		t.Fatal(e)
	}
	if len(d.Events) != 0 || d.Stats["strong不成立"] != 1 {
		t.Fatal("deadlineを混ぜた")
	}
}

// artificialRaw144 は全10深度型を持つ人工原板を作ります。
//
// 引数: t(*testing.T)、compressed(bool)。返り値: Scene144は品質付き参照です。
func artificialRaw144(t *testing.T, compressed bool) Scene144 {
	t.Helper()
	var b bytes.Buffer
	for i, at := range []int64{120, 121, 122} {
		r := map[string]any{"Symbol": "X", "CurrentPriceTime": time.Unix(at, 0).UTC().Format(time.RFC3339Nano), "CurrentPrice": 100.}
		for j := 1; j <= 10; j++ {
			r[fmt.Sprintf("Buy%d", j)] = map[string]float64{"Price": 90, "Qty": 1}
			r[fmt.Sprintf("Sell%d", j)] = map[string]float64{"Price": 110, "Qty": 1}
		}
		if i == 1 {
			r["Buy1"] = map[string]float64{"Price": 0, "Qty": 1}
		}
		x, e := json.Marshal(r)
		if e != nil {
			t.Fatal(e)
		}
		b.Write(x)
		b.WriteByte('\n')
	}
	body := b.Bytes()
	if compressed {
		var z bytes.Buffer
		w := gzip.NewWriter(&z)
		_, _ = w.Write(body)
		_ = w.Close()
		body = z.Bytes()
	}
	path := filepath.Join(t.TempDir(), "raw")
	if e := os.WriteFile(path, body, 0600); e != nil {
		t.Fatal(e)
	}
	h := sha256.Sum256(body)
	return Scene144{Session: "人工_Day", Contract: "X", Start: 0, End: 10000, ForceClose: 9000, Raw: FileRef{Path: path, SHA256: hex.EncodeToString(h[:])}, ExpectedAccepted: 3, ExpectedQuality: &Counts{Lines: 3, Accepted: 3, Delivered: 3, BadBBO: 1}}
}

// Test144一走査と固定入力拒否 はplain/gzipと全品質・EOFを確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func Test144一走査と固定入力拒否(t *testing.T) {
	for _, compressed := range []bool{false, true} {
		s := artificialRaw144(t, compressed)
		r, e := Generate(Input144{Trial: 122, Scenes: []Scene144{s}}, 1, false)
		if e != nil {
			t.Fatal(e)
		}
		v := r.Scenes[0]
		if !r.Success || v.Counts != *s.ExpectedQuality || v.StatBefore != v.StatAfter || len(v.Events) != 0 || v.RawPasses != 1 {
			t.Fatal(v)
		}
		s.ExpectedQuality.BadBBO = 0
		if _, e = Generate(Input144{Scenes: []Scene144{s}}, 1, false); e == nil {
			t.Fatal("品質差受理")
		}
	}
	if _, e := Load("存在しない", "不正"); e == nil {
		t.Fatal("I/O前SHA拒否なし")
	}
}
