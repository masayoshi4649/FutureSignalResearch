// Package holdingohlc113 はSource入口の出生と取得だけを記録します。金融ラベルは持ちません。
package strongstream144

type FileRef struct {
	Path   string `json:"path"`
	SHA256 string `json:"sha256"`
}

type Quote struct {
	Clock      string  `json:"clock,omitempty"`
	Time       float64 `json:"time"`
	Index      int64   `json:"index"`
	SourceLine int64   `json:"source_line"`
	Last       float64 `json:"last"`
	Bid        float64 `json:"bid"`
	Ask        float64 `json:"ask"`
	QuoteOK    bool    `json:"quote_ok"`
}

type Counts struct {
	Lines           int64 `json:"lines"`
	ClockMissing    int64 `json:"clock_missing"`
	ClockInvalid    int64 `json:"clock_invalid"`
	Outside         int64 `json:"outside_session"`
	Backward        int64 `json:"backward_clock"`
	LastNonPositive int64 `json:"last_non_positive"`
	LastNonFinite   int64 `json:"last_non_finite"`
	BadBBO          int64 `json:"bad_bbo"`
	Accepted        int64 `json:"source_parser_accepted"`
	CutoffExcluded  int64 `json:"cutoff_excluded"`
	Delivered       int64 `json:"source_delivered"`
}

type FileStat struct {
	Bytes     int64 `json:"bytes"`
	ModTimeNS int64 `json:"mtime_ns"`
}

type Scene struct {
	Session  string
	Contract string
	Start    float64
	End      float64
	Cutoff   float64
	Raw      FileRef
}
