package main

import (
	"encoding/json"
	"flag"
	"fmt"
	source "github.com/masayoshi4649/SessionTradeExecuter/strongstream144"
	"os"
)

// main はRoot F0後の明示実行でだけstrong全成立Sourceを生成します。
//
// 引数: CLIのinput/sha256/output/workers/execute-after-f0。返り値: なし。不整合は終了1です。
func main() {
	input := flag.String("input", "", "固定122入力")
	sha := flag.String("sha256", "", "固定122 SHA")
	output := flag.String("output", "", "未作成出力")
	workers := flag.Int("workers", 4, "並列1..8")
	execute := flag.Bool("execute-after-f0", false, "Root F0後明示実行")
	flag.Parse()
	fail := func(e error) { fmt.Fprintln(os.Stderr, e); os.Exit(1) }
	if !*execute || *input == "" || *output == "" || flag.NArg() != 0 {
		fail(fmt.Errorf("F0後明示実行と全引数が必要"))
	}
	if _, e := os.Stat(*output); !os.IsNotExist(e) {
		fail(fmt.Errorf("未作成出力だけ許可"))
	}
	data, e := source.Load(*input, *sha)
	if e != nil {
		fail(e)
	}
	result, e := source.Generate(data, *workers, true)
	if e != nil {
		fail(e)
	}
	if _, e = source.Load(*input, *sha); e != nil {
		fail(e)
	}
	b, e := json.MarshalIndent(result, "", "  ")
	if e != nil {
		fail(e)
	}
	f, e := os.OpenFile(*output, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if e != nil {
		fail(e)
	}
	if _, e = f.Write(append(b, '\n')); e != nil {
		f.Close()
		fail(e)
	}
	if e = f.Close(); e != nil {
		fail(e)
	}
	fmt.Printf("144 Source成功 場=%d 出生=%d 取得=%d\n", len(result.Scenes), result.Summary["出生数"], result.Summary["取得数"])
}
