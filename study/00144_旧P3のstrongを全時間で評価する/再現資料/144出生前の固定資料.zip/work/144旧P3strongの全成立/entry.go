package strongstream144

import (
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"math"
)

type Scene144 struct {
	Session          string              `json:"session"`
	Contract         string              `json:"contract"`
	Start            float64             `json:"start"`
	End              float64             `json:"end"`
	ForceClose       float64             `json:"force_close"`
	Raw              FileRef             `json:"raw"`
	ExpectedAccepted int64               `json:"expected_accepted"`
	ExpectedQuality  *Counts             `json:"expected_quality"`
	Publications     []rules.Publication `json:"publications"`
}
type Input144 struct {
	Trial  int        `json:"trial"`
	Scenes []Scene144 `json:"scenes"`
}
type Input133 = Input144
type Event struct {
	ID               string       `json:"id"`
	Side             int          `json:"side"`
	T8Side           int          `json:"t8_side"`
	Birth            Quote        `json:"birth"`
	EntryQuote       *Quote       `json:"entryQuote"`
	EntryPrice       *float64     `json:"entry_price_native"`
	EntryPriceT8     *float64     `json:"entry_price_t8"`
	Status           string       `json:"status"`
	Evaluation       *Quote       `json:"evaluation"`
	TerminationQuote *Quote       `json:"terminationQuote"`
	Expires          float64      `json:"expires"`
	ConsumedKey      string       `json:"consumed_key"`
	Frame5           rules.Ref    `json:"frame5"`
	StrongType       string       `json:"strong_type"`
	Score            Decision133  `json:"score"`
	Direction        Direction133 `json:"direction"`
	Refs             []rules.Ref  `json:"refs"`
}
type Detector struct {
	Scene    Scene144
	Events   []*Event
	Stats    map[string]uint64
	pending  *Event
	consumed map[string]bool
}

// quote133 は旧score/strongと同じ原行を118公開型へ写します。
//
// 引数: q(Quote)。返り値: rules.Quoteは同じtime/index/source_line/Lastです。
func quote133(q Quote) rules.Quote {
	return rules.Quote{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine), Last: q.Last}
}

// New はSource保有もcoveredも持たない当場状態を作ります。
//
// 引数: scene(Scene144)。返り値: *Detector/errorは空状態又は不正metadataです。
func New(scene Scene144) (*Detector, error) {
	if scene.Session == "" || scene.Contract == "" || !finite(scene.Start, scene.End, scene.ForceClose) || scene.End-3900 <= scene.Start || scene.ForceClose <= scene.Start || scene.ForceClose > scene.End {
		return nil, fmt.Errorf("144場定義不正")
	}
	return &Detector{Scene: scene, Events: []*Event{}, Stats: map[string]uint64{}, consumed: map[string]bool{}}, nil
}

// limit は元forceとH60を残す共通取得限界を返します。
//
// 引数: なし。返り値: float64はmin(元force,End-3900)です。
func (d *Detector) limit() float64 { return math.Min(d.Scene.ForceClose, d.Scene.End-3900) }

// pending144 は旧非E0 pending133と同じ最初正常BBOの取得条件だけを適用します。
//
// 引数: e(*Event)、q(Quote)、force(float64)。返り値: なし。最新strong/cap/risk/holdを足しません。
func pending144(e *Event, q Quote, force float64) {
	if e.Status != "pending" || e.EntryQuote != nil {
		return
	}
	if q.Time >= force {
		z := q
		e.TerminationQuote = &z
		e.Status = "force_close"
		return
	}
	if q.Time >= e.Expires {
		z := q
		e.TerminationQuote = &z
		e.Status = "unfilled_expired"
		return
	}
	if q.Index <= e.Birth.Index || q.SourceLine <= e.Birth.SourceLine || q.Time < e.Birth.Time+1 || !q.QuoteOK || !normal(q) {
		return
	}
	z := q
	e.Evaluation = &z
	e.EntryQuote = &z
	p := q.Ask
	if e.Side < 0 {
		p = q.Bid
	}
	t := q.Ask
	if e.T8Side < 0 {
		t = q.Bid
	}
	e.EntryPrice = &p
	e.EntryPriceT8 = &t
	e.Status = "filled"
}

// Observe は全公表配送後、既pendingを先に処理し新しいstrongだけを生みます。
//
// 引数: bank(*rules.Bank)、window(*Window133)、q(Quote)。返り値: errorは公表/方向の不整合です。
func (d *Detector) Observe(bank *rules.Bank, window *Window133, q Quote) error {
	d.Stats["採用Raw"]++
	if d.pending != nil {
		pending144(d.pending, q, d.limit())
		if d.pending.Status == "pending" {
			d.Stats["pending中の新規抑止"]++
			return nil
		}
		d.Stats["要求終了/"+d.pending.Status]++
		d.pending = nil
	}
	if q.Time >= d.limit() {
		d.Stats["新規限界以後"]++
		return nil
	}
	raw, err := score133(bank, q, window)
	if err != nil {
		return err
	}
	d.Stats["score評価"]++
	if !raw.Eligible {
		d.Stats["score未知"]++
		return nil
	}
	decision, ok := strong133(raw)
	if !ok {
		d.Stats["strong不成立"]++
		return nil
	}
	snapshot, err := bank.Current(quote133(q))
	if err != nil {
		return err
	}
	p, ok := snapshot.Frames[300]
	if !ok || !p.Frame.Frame.PriceKnown {
		return fmt.Errorf("strongの当場5分参照欠落")
	}
	frame := reference133(p)
	key := fmt.Sprintf("%s/%d", frame.ID, decision.Side)
	if d.consumed[key] {
		d.Stats["5分ID方向消費済み"]++
		return nil
	}
	direction, err := direction133(decision.Side, "strong", snapshot)
	if err != nil {
		return err
	}
	refs := append([]rules.Ref(nil), direction.Refs...)
	seen := map[string]bool{}
	for _, ref := range refs {
		seen[ref.ID] = true
	}
	for _, ref := range decision.StructureRefs {
		if !seen[ref.ID] {
			refs = append(refs, ref)
			seen[ref.ID] = true
		}
	}
	e := &Event{ID: fmt.Sprintf("%s/strong144/%d/%d", d.Scene.Session, decision.Side, q.Index), Side: decision.Side, T8Side: direction.T8Side,
		Birth: q, Status: "pending", Expires: math.Min(q.Time+30, d.limit()), ConsumedKey: key, Frame5: frame,
		StrongType: decision.Strategy, Score: decision, Direction: direction, Refs: refs}
	d.consumed[key] = true
	d.pending = e
	d.Events = append(d.Events, e)
	d.Stats["出生"]++
	d.Stats["出生/"+decision.Strategy]++
	return nil
}

// Finish はEOFで架空の気配を作らず未取得要求を閉じます。
//
// 引数: なし。返り値: なし。消費キーは復活させません。
func (d *Detector) Finish() {
	if d.pending != nil {
		d.pending.Status = "eof_unfilled"
		d.Stats["要求終了/eof_unfilled"]++
		d.pending = nil
	}
}

// CheckStoredStrong は旧保存DecisionとDirectionからpredicateとT8を検査します。
//
// 引数: original(Decision133)、direction(Direction133)、side(int)。返り値: errorは元条件と保存方向の不整合です。
func CheckStoredStrong(original Decision133, direction Direction133, side int) error {
	d, ok := strong133(original)
	if !ok || d.Side != side || d.Strategy != original.Strategy {
		return fmt.Errorf("旧Strong保存predicate不一致")
	}
	f := direction.Fields
	ratio := f["body5_signed_ratio_to_source"]
	b0 := side
	if ratio.Known && ratio.Value >= .5 && ratio.Value < .75 {
		b0 = -side
	}
	t8 := b0
	long, hist := f["ema21_delta30_to_B0"], f["hist5_atr_to_B0"]
	if long.Known && long.Value >= 0 && hist.Known && hist.Value >= .1 {
		t8 = -b0
	}
	if direction.SourceSide != side || direction.B0Side != b0 || direction.T8Side != t8 || direction.SelectedSide != t8 || direction.E0Protected {
		return fmt.Errorf("旧Strong保存T8不一致")
	}
	return nil
}
