# 旧Strong32保存票の純回帰

2026-11-12。旧137 Sourceのlegacy.candidatesから、固定A0/L0/strongの32件をmetadataへ完全結合し、保存Decision/Direction/元sideを144の`CheckStoredStrong`へそのまま渡した。32件全て成功（trend31/reversal1）。

新144 Sourceフォルダ/F0対象は変更していない。自然Raw・CSV・新144 Source・金融を読まず、scannerを呼び出していない。**旧32時刻のSnapshotを独立再構築した確認ではない**。確認範囲は、既存の保存技術票を与えた時のstrong predicate/side/typeと固定T8の一致である。

入力は旧137 Source SHA `d5c2e8e7…` と固定metadata SHA `86f33705…`。射影した32票は [入力JSON](旧Strong32の保存票.json)、APIの各ID結果は [純回帰結果](純回帰の結果.json)、全指紋は [確認証跡](回帰の確認.json)。

```powershell
python 保存票を射影する.py
go run . --input 旧Strong32の保存票.json --sha256 faad4a3d3fbdcd62f0649bca11f35108e851b51f2be84e137d5784ed749c6106 --output 純回帰の結果.json
```

入力/出力は未作成先のみで、再実行時はこの小型runnerと固定入力を別作業先へ復元する。新streamの取得集合は再準備・優先処理が違うので、旧32約定集合と同体だとは主張しない。
