package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
	source "github.com/masayoshi4649/SessionTradeExecuter/strongstream144"
	"os"
)

type Ticket struct {
	Session   string              `json:"session"`
	ID        string              `json:"id"`
	Side      int                 `json:"side"`
	Strategy  string              `json:"strategy"`
	Decision  source.Decision133  `json:"decision"`
	Direction source.Direction133 `json:"direction"`
}

// main は既存保存票32件を固定Sourceの純APIへ渡すだけの回帰です。
//
// 引数: input/sha256/outputのCLI。返り値: なし。Raw/新Source/scannerを呼びません。
func main() {
	input := flag.String("input", "", "32保存票")
	expected := flag.String("sha256", "", "保存票SHA")
	output := flag.String("output", "", "未作成出力")
	flag.Parse()
	if *input == "" || len(*expected) != 64 || *output == "" {
		panic("全引数が必要")
	}
	b, e := os.ReadFile(*input)
	if e != nil {
		panic(e)
	}
	h := sha256.Sum256(b)
	if hex.EncodeToString(h[:]) != *expected {
		panic("保存票SHA差")
	}
	var tickets struct {
		Success bool     `json:"success"`
		Tickets []Ticket `json:"tickets"`
	}
	if e = json.Unmarshal(b, &tickets); e != nil {
		panic(e)
	}
	if !tickets.Success || len(tickets.Tickets) != 32 {
		panic("固定32件差")
	}
	rows := []map[string]any{}
	types := map[string]int{}
	seen := map[string]bool{}
	for _, t := range tickets.Tickets {
		if seen[t.ID] {
			panic("保存票ID重複")
		}
		seen[t.ID] = true
		if e = source.CheckStoredStrong(t.Decision, t.Direction, t.Side); e != nil {
			panic(fmt.Errorf("%s:%w", t.ID, e))
		}
		if t.Strategy != t.Decision.Strategy {
			panic("型差")
		}
		types[t.Strategy]++
		rows = append(rows, map[string]any{"session": t.Session, "id": t.ID, "source_side": t.Side, "b0_side": t.Direction.B0Side, "t8_side": t.Direction.T8Side, "strategy": t.Strategy, "pass": true})
	}
	if types["trend"] != 31 || types["reversal"] != 1 {
		panic("31/1型差")
	}
	result := map[string]any{"成功": true, "件数": 32, "型別": types, "保存票SHA256": *expected, "scanner独立再構築": false, "自然Raw新Source読取": false, "検査": rows}
	out, e := json.MarshalIndent(result, "", "  ")
	if e != nil {
		panic(e)
	}
	f, e := os.OpenFile(*output, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if e != nil {
		panic(e)
	}
	if _, e = f.Write(append(out, '\n')); e != nil {
		panic(e)
	}
	if e = f.Close(); e != nil {
		panic(e)
	}
	fmt.Println("旧Strong32保存票のpredicate/T8純回帰成功")
}
