"""旧137の32strong保存票だけを純回帰入力へ射影する。"""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
FILES = {
 'source': ('work/137既知回復の評価/Sourceの出生と取得.json', 'd5c2e8e772e1658015d82497760b56ef40d6cae07da40eb8f148f601795628e5'),
 'metadata': ('work/137既知回復の評価/固定入力/方向と出生.json', '86f33705ba40fd3ba1b845557a2368e44c2802635082fc3bad69346770103f93')}


def sha(body: bytes) -> str:
    """
    機能: bytesの指紋を求める。
    引数: body(bytes)。返り値: str。
    """
    return hashlib.sha256(body).hexdigest()


def main() -> None:
    """
    機能: 旧A0/L0strong32と元legacy候補を完全結合する。
    引数: なし。返り値: None。新しい価格や判定結果を生成しない。
    """
    docs = {}
    for key, (p, expected) in FILES.items():
        b = (ROOT/p).read_bytes(); assert sha(b) == expected; docs[key] = json.loads(b)
    selected = {r['source_id']: r for r in docs['metadata']['entries'] if r['model'] == 'A0' and r['kind'] == 'L0' and r['path'] == 'strong'}
    assert len(selected) == 32
    tickets, seen = [], set()
    for scene in docs['source']['scenes']:
        for c in scene['legacy']['candidates']:
            identity = c['birth']['id']
            if c['policy'] != 'L0' or identity not in selected:
                continue
            r = selected[identity]
            assert c['status'] == 'filled' and c['path'] == 'strong'
            assert c['direction'] == r['direction'] and c['birth'] == r['birth'] and c['entry'] == r['entryQuote']
            assert c['decision']['strategy'] == r['strategy'] and c['birth']['side'] == r['source_side']
            assert identity not in seen; seen.add(identity)
            tickets.append({'session': scene['session'], 'id': identity, 'side': c['birth']['side'],
                'strategy': c['decision']['strategy'], 'decision': c['decision'], 'direction': c['direction']})
    assert seen == set(selected) and all(sha((ROOT/p).read_bytes()) == h for p, h in FILES.values())
    p = OWN/'旧Strong32の保存票.json'
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump({'success': True, 'tickets': tickets, 'sources': {k: {'path': p, 'sha256': h} for k, (p, h) in FILES.items()}}, f, ensure_ascii=False, indent=2); f.write('\n')
    print(sha(p.read_bytes()))


if __name__ == '__main__':
    main()
