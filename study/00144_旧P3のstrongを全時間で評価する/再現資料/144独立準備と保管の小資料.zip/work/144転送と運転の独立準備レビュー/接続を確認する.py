"""144橋渡しと運転部を自然結果なしで静的・人工確認する。Root源は変更しない。"""
from pathlib import Path
import ast
import copy
import hashlib
import importlib.util
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
FILES = [ROOT/'work/144旧strongと対照を固定取得へ渡す.py',
         ROOT/'work/144転送の人工検査.py',ROOT/'work/144全strongと金融を分離して実行する.py']


def sha(path: Path) -> str:
    """
    機能: 保存bytesの指紋を計算する。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def module(path: Path, name: str) -> object:
    """
    機能: 自然ファイルを開かないbridge/人工モジュールだけを読む。
    引数: path(Path)、name(str)。返り値: objectはモジュール。
    """
    spec = importlib.util.spec_from_file_location(name,path)
    value = importlib.util.module_from_spec(spec);spec.loader.exec_module(value)
    return value


# ----------------------------------------
def main() -> None:
    """
    機能: 元側/T8保持・C0未来非抑止・期限境界と非改変を確認する。
    引数: なし。Root自然Source・金融・Raw・CSVは読まない。
    返り値: None。独立確認JSONだけを未作成の専有先へ保存する。
    """
    before = {str(p):sha(p) for p in FILES}
    for p in FILES: ast.parse(p.read_text(encoding='utf-8'))
    done = subprocess.run([sys.executable,'-X','utf8',str(FILES[1])],cwd=ROOT,capture_output=True,text=True,encoding='utf-8')
    assert done.returncode == 0,done.stdout+done.stderr
    bridge = module(FILES[0],'独立144橋渡し')
    artificial = module(FILES[1],'独立144人工素材')
    common,controls,source = artificial.fixture()
    original = copy.deepcopy((common,controls,source))
    fixed,meta = bridge.build(common,controls,source)
    assert (common,controls,source) == original
    case = next(e for s in fixed['scenes'] for e in s['entries'] if e['id']=='S0/人工場0/新規')
    item = next(e for e in meta['entries'] if e['id']==case['id'])
    assert case['side']==item['native_side']==-1 and item['t8_side']==1
    assert case['entry']==item['entry_quote']==source['scenes'][0]['events'][0]['entryQuote']
    u = next(u for u in meta['union'] if case['id'] in u['alias_ids'])
    assert u['canonical_id']=='C0/人工場0/対照'
    assert u['alias_sides'][case['id']]==-1 and u['alias_t8_sides'][case['id']]==1
    # ----------------------------------------
    # C0の将来取得より前に独立strongがある場合も両方を残す。
    earlier = copy.deepcopy(source)
    event = earlier['scenes'][0]['events'][0]
    event['entryQuote'].update({'time':70,'index':70,'source_line':71})
    event['birth'].update({'time':69,'index':68,'source_line':69})
    ef,em = bridge.build(common,controls,earlier)
    assert ef['expected_entry_count']==4 and len(em['union'])==4
    assert ef['scenes'][0]['entries'][0]['id']=='S0/人工場0/新規'
    assert ef['scenes'][0]['entries'][1]['id']=='C0/人工場0/対照'
    # ----------------------------------------
    # 共通新規限界等号も転送時に拒否する。
    bad = copy.deepcopy(source)
    q = bad['scenes'][1]['events'][0]['entryQuote'];birth=bad['scenes'][1]['events'][0]['birth']
    limit = min(common['scenes'][1]['force_close'],common['scenes'][1]['end']-3900)
    q['time']=limit;birth['time']=limit-1
    try: bridge.build(common,controls,bad)
    except AssertionError: pass
    else: raise AssertionError('共通H60新規限界の等号を受理')
    after = {str(p):sha(p) for p in FILES};assert before==after
    report = {'成功':True,'試行':144,'重大未解決':[],'Root源変更':False,
              '構文3源':True,'Root人工7群':True,'独立人工3群':True,
              '独立人工':['元sideをkernel originalへ保ちT8別保存・同Quote異方向aliasのC0優先/入力非改変',
                         'C0未来取得より前のstrongも独立取得とunionへ残す',
                         '共通H60新規限界の等号拒否'],
              '静的確認':['出生から別index/物理行+1秒以上30秒未満で取得',
                         'S0/T0は同entry_quoteから元/実逆を選び、T8をkernel元側へ誤適用しない',
                         'C0は既選定sideをnative/t8同値で保持し新T8を再適用しない',
                         'unionキーはsession/contract/time/index/source_line、方向を含めずC0優先',
                         '全場metadataを保持しC0旧81は旧固定入力と完全一致assert',
                         'F0でSource/bridge/正式/固定入力依存、F1でSource生成物/固定取得/meta/金融依存を固定',
                         '出生/転送/金融前/観測/集計を別modeで実行し既存出力を上書きしない'],
              'Root人工結果':{'終了コード':done.returncode,'標準出力':done.stdout,'標準エラー':done.stderr},
              'Root3源前後SHA256':before,'自己コードSHA256':sha(Path(__file__)),
              '自然Source金融RawCSV追加2場読取':False,'編集停止':True}
    p = OWN/'準備の確認.json';assert not p.exists()
    p.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'SHA256':sha(p)},ensure_ascii=False))


if __name__ == '__main__':
    main()
