"""144 F0/F1全54源の保存先解決と、非複製3源以外の保存bytes復元を確認する。"""
from pathlib import Path
import gzip
import hashlib
import json
import zipfile
from 保存部品 import ROOT, FORMAL, F0_SHA, F1_SHA, sha, write, json_bytes


def restored(item: dict) -> bytes:
    """
    機能: 共有gzip・同体・ZIP・文書snapshotから元bytesを再構成する。
    引数: item(dict)は復元参照。
    返り値: bytesは解凍又は抽出した原文。
    """
    if '保存元ZIP' in item:
        p=ROOT/item['保存元ZIP'];assert sha(p.read_bytes())==item['ZIP_SHA256']
        with zipfile.ZipFile(p) as z:return z.read(item['ZIP内path'])
    p=ROOT/item['保存元'];raw=p.read_bytes()
    if item['形式']=='文書snapshot':
        value=json.loads(gzip.decompress(raw))
        d=next(d for d in value['文書'] if d['path']==item['抽出キー'])
        return d['本文'].encode('utf-8')
    assert sha(raw)==item['保存SHA256']
    return gzip.decompress(raw) if item['形式']=='gzip' else raw


# ----------------------------------------
def main() -> None:
    """
    機能: F0/F1の固定源を恒久資料だけから解決し、範囲を明示した確認を保存する。
    引数: なし。177MB再生成/Raw/価格CSV/新金融は使わない。
    返り値: None。検査JSONを正式の検査先へ新規保存する。
    """
    index=json.loads((FORMAL/'保管索引.json').read_bytes())
    f0raw=(FORMAL/'検査/F0出生前.json').read_bytes();f1raw=(FORMAL/'検査/F1金融前.json').read_bytes()
    assert sha(f0raw)==F0_SHA and sha(f1raw)==F1_SHA
    f0,f1=json.loads(f0raw),json.loads(f1raw)
    registry={};exclusions={}
    for stage in ('F0復元参照','F1増分復元参照'):
        group=index[stage]
        for kind in ('文書snapshot','共有入力','共有コード','保存済み参照'):
            for r in group[kind]:
                rel=r['復元先'];assert rel not in registry;registry[rel]=r
        archive=group['固定ZIP']
        for r in archive['格納源']:
            rel=r['path'];assert rel not in registry
            registry[rel]={'保存元ZIP':(FORMAL/'再現資料'/archive['ZIP']).relative_to(ROOT).as_posix(),
                           'ZIP_SHA256':archive['ZIP_SHA256'],'ZIP内path':rel,'sha256':r['sha256'],'復元先':rel}
        for r in group['意図して非複製']:exclusions[r['path']]=r
    expected={Path(p).relative_to(ROOT).as_posix():h for p,h in f1['ファイル'].items()}
    assert len(expected)==54 and set(expected)==set(registry)|set(exclusions)
    report=[]
    for rel,r in registry.items():
        raw=restored(r);assert sha(raw)==expected[rel],rel
        report.append({'path':rel,'sha256':sha(raw),'bytes':len(raw),'保存資料から復元一致':True})
    assert len(report)==51 and len(exclusions)==3
    binary=[]
    for rel,r in exclusions.items():
        if rel.endswith('.exe'):
            assert sha((ROOT/rel).read_bytes())==expected[rel]
            binary.append({'path':rel,'sha256':expected[rel],'現物SHA一致':True,'再ビルド実行':False})
        else:
            assert rel=='work/122全場入力/入力.json' and r['sha256']==expected[rel]
            assert (ROOT/index['122巨大入力の復元']['手順']).is_file()
    # F1に継承された正式3MDはF0原文と同体。結果追記後の現物は比較しない。
    for p,h in f0['ファイル'].items():assert f1['ファイル'][p]==h
    proof={'成功':True,'試行':144,'F0全源':37,'F1全源':54,'全復元参照解決':True,
           '保存bytesから復元一致':51,'保存bytes照合':report,'非複製':list(exclusions.values()),
           '既存2exeの現物SHA照合':binary,'177MB':'既固定SHAと122復元手順だけを参照。本文読取/複製/再生成は実行しない。',
           '全54源の実bytes再生成を主張':False,'正式3MDのF0F1原文一致':True,'正式3MD現物変更':False,
           'Root金融結果/Raw/CSV価格/追加2場読取':False,'自己コードSHA256':sha(Path(__file__).read_bytes()),'重大不足':[]}
    p=FORMAL/'検査/F0F1全源の復元参照確認.json';write(p,json_bytes(proof))
    print(json.dumps({'成功':True,'全54源参照解決':True,'保存bytes復元':51,'SHA256':sha(p.read_bytes())},ensure_ascii=False))


if __name__=='__main__':
    main()
