"""144のF0/F1固定資料を保管し、正式3MDの本文を変更しない保存部品。"""
from pathlib import Path
import gzip
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
FORMAL = ROOT/'study/00144_旧P3のstrongを全時間で評価する'
RUN = ROOT/'work/144旧strongの全成立評価'
INPUTS = ROOT/'inputs/00144_旧P3strongの全成立'
F0_SHA = '7cba1a02875aaddf34375376ae7df2865bea01263bdaf6814986634491b99a1f'
F1_SHA = '42a57a1037342884c34a1fb71550eb2f2e504e8c66f93c84217cdb5be3da6e0b'


def sha(raw: bytes) -> str:
    """
    機能: 保存bytesの指紋を求める。
    引数: raw(bytes)。返り値: strはSHA256。
    """
    return hashlib.sha256(raw).hexdigest()


# ----------------------------------------
def write(path: Path, body: bytes) -> None:
    """
    機能: 未作成先だけへbytesを保存する。
    引数: path(Path)、body(bytes)。返り値: None。
    """
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as stream: stream.write(body)


# ----------------------------------------
def json_bytes(value: dict) -> bytes:
    """
    機能: UTF-8・日本語のJSONへ写す。
    引数: value(dict)。返り値: bytesは保存用原文。
    """
    return (json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode('utf-8')


# ----------------------------------------
def save(source: Path, target: Path, expected: str, packed: bool=False) -> dict:
    """
    機能: 原文SHA確認後だけ同体又は1回gzip保存し、復元指紋も確認する。
    引数: source/target(Path)、expected(str)、packed(bool)。返り値: dictは復元情報。
    """
    raw = source.read_bytes();assert sha(raw)==expected
    body = gzip.compress(raw,compresslevel=9,mtime=0) if packed else raw
    write(target,body)
    stored = target.read_bytes();assert stored==body
    restored = gzip.decompress(stored) if packed else stored
    assert sha(restored)==expected
    return {'保存元':target.relative_to(ROOT).as_posix(),'復元先':source.relative_to(ROOT).as_posix(),
            '形式':'gzip' if packed else '同体','保存bytes':len(body),'保存SHA256':sha(body),
            '解凍bytes':len(raw),'解凍SHA256':expected}


# ----------------------------------------
def registries() -> tuple:
    """
    機能: 既存共用入力と小型固定ZIPの復元参照を索引から得る。
    引数: なし。Raw/177MBや自然金融本文は解析しない。
    返り値: tuple[dict,dict]は入力復元先とコードSHAの索引。
    """
    inputs, codes = {},{}
    for n in (133,138,141,143):
        folder = next((ROOT/'study').glob(f'{n:05d}_*'))
        doc = json.loads((folder/'保管索引.json').read_bytes())
        stack = [doc]
        while stack:
            item = stack.pop()
            if isinstance(item,list): stack.extend(item);continue
            if not isinstance(item,dict): continue
            if all(k in item for k in ('保存元','復元先','保存SHA256','解凍SHA256')):
                inputs.setdefault(item['復元先'],item)
            stack.extend(item.values())
        if n not in (133,138): continue
        group = doc['固定コード' if n==133 else '追加固定資料']
        path = folder/'再現資料'/group['ZIP']; assert sha(path.read_bytes())==group['ZIP_SHA256']
        for e in group['格納源']:
            codes.setdefault(e['sha256'],{'保存元ZIP':path.relative_to(ROOT).as_posix(),
                'ZIP_SHA256':group['ZIP_SHA256'],'ZIP内path':e['path'],'sha256':e['sha256'],'bytes':e['bytes']})
    return inputs,codes


# ----------------------------------------
def snapshot(freeze: dict, stage: str, fingerprint: str) -> tuple:
    """
    機能: 固定された全MDを正式結果編集より先にgzip原文退避する。
    引数: freeze(dict)、stage/fingerprint(str)。返り値: tuple[dict,list]は保存情報と文書参照。
    """
    docs = []
    for name,h in freeze['ファイル'].items():
        p = Path(name)
        if p.suffix!='.md': continue
        body = p.read_bytes();assert sha(body)==h
        docs.append({'path':p.relative_to(ROOT).as_posix(),'sha256':h,'bytes':len(body),'本文':body.decode('utf-8')})
    assert sum(d['path'].startswith('study/00144_') for d in docs)==3
    value = {'試行':144,'段階':stage+'実行前文書の原文退避','固定SHA256':fingerprint,
             '正式文書数':3,'文書数':len(docs),'文書':docs,'事前固定の後造り':False,'正式3MD変更':False}
    body = json_bytes(value);target=FORMAL/'検査'/f'{stage}実行前文書.json.gz'
    write(target,gzip.compress(body,mtime=0));assert gzip.decompress(target.read_bytes())==body
    ref = {'保存元':target.relative_to(ROOT).as_posix(),'保存SHA256':sha(target.read_bytes()),
           '文書数':len(docs),'正式文書数':3}
    return ref,[{'復元先':d['path'],'sha256':d['sha256'],'bytes':d['bytes'],
                 '保存元':ref['保存元'],'形式':'文書snapshot','抽出キー':d['path']} for d in docs]


# ----------------------------------------
def resolve(items: dict, stage: str, references: dict, docs: list) -> dict:
    """
    機能: 固定源を文書snapshot・共有入力・共有コード・新小ZIP・非複製へ分ける。
    引数: items(dict)、stage(str)、references(dict)、docs(list)。返り値: dictは完全復元用索引。
    """
    known_inputs,codes = registries()
    document = {d['復元先']:d for d in docs}
    grouped = {'文書snapshot':[],'共有入力':[],'共有コード':[],'新固定源':[],'意図して非複製':[],'保存済み参照':[]}
    bodies = {};checked = set()
    for name,h in items.items():
        p = Path(name);rel = p.relative_to(ROOT).as_posix()
        if rel in document:
            assert document[rel]['sha256']==h;grouped['文書snapshot'].append(document[rel]);continue
        if rel in references:
            assert references[rel]['解凍SHA256']==h;grouped['保存済み参照'].append(references[rel]);continue
        if rel=='work/122全場入力/入力.json' or p.suffix=='.exe':
            grouped['意図して非複製'].append({'path':rel,'sha256':h,'bytes':p.stat().st_size,
                '理由':'旧共用177MB又は実行体。入力復元手順/保存Goから再ビルドし、この試行では複製しない'});continue
        if rel in known_inputs and known_inputs[rel]['解凍SHA256']==h:
            ref = known_inputs[rel];raw=(ROOT/ref['保存元']).read_bytes();assert sha(raw)==ref['保存SHA256']
            raw = gzip.decompress(raw) if ref['形式']=='gzip' else raw;assert sha(raw)==h
            grouped['共有入力'].append(ref);continue
        if h in codes:
            ref = dict(codes[h]);ref['復元先']=rel
            key = ref['保存元ZIP'],ref['ZIP内path']
            if key not in checked:
                with zipfile.ZipFile(ROOT/ref['保存元ZIP']) as z: assert sha(z.read(ref['ZIP内path']))==h
                checked.add(key)
            grouped['共有コード'].append(ref);continue
        raw = p.read_bytes();assert sha(raw)==h and len(raw)<1_000_000,(rel,len(raw))
        grouped['新固定源'].append({'path':rel,'sha256':h,'bytes':len(raw)});bodies[rel]=raw
    assert sum(len(v) for v in grouped.values())==len(items)
    archive=FORMAL/'再現資料'/f'144{stage}の固定資料.zip';archive.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for rel,raw in sorted(bodies.items()): z.writestr(rel,raw)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist())==len(bodies)
        for rel,raw in bodies.items(): assert z.read(rel)==raw
    grouped['固定ZIP']={'ZIP':archive.name,'ZIP_SHA256':sha(archive.read_bytes()),'ZIP_bytes':archive.stat().st_size,
                        '格納源数':len(bodies),'格納源':grouped['新固定源']}
    return grouped


# ----------------------------------------
def f0() -> None:
    """
    機能: 144のF0原文・正式3MD・固定小型資料を最初に保管する。
    引数: なし。返り値: None。正式3MDを変更しない。
    """
    p=RUN/'F0出生前.json';raw=p.read_bytes();assert sha(raw)==F0_SHA
    frozen=json.loads(raw);assert frozen['試行']==144 and len(frozen['ファイル'])==37
    save(p,FORMAL/'検査/F0出生前.json',F0_SHA)
    snap,docs=snapshot(frozen,'F0',F0_SHA)
    groups=resolve(frozen['ファイル'],'出生前',{},docs)
    prior=json.loads(next((ROOT/'study').glob('00138_*/保管索引.json')).read_bytes())
    index={'試行':144,'段階':'F0原文退避・Source/金融結果は未記入','F0_SHA256':F0_SHA,'F0直接源数':37,
           'F0文書原文':snap,'F0復元参照':groups,'追加固定資料':groups['固定ZIP'],
           '共有入力':groups['共有入力'],'共有固定コード':groups['共有コード'],'意図して複製しない固定源':groups['意図して非複製'],
           '122巨大入力の復元':{'手順':'study/00122_E0固定条件を全セッションで検証する/再現資料/再現手順.md',
              'SHA256':'6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec',
              '本文新複写/解析':False},'kernel共有源':prior['後段再現用の継承源'],
           '正式README/条件/513セル変更':False,'新Raw/価格CSV/追加2場/金融結果読取':False}
    write(FORMAL/'保管索引.json',json_bytes(index))
    proof={'成功':True,'試行':144,'F0_SHA256':F0_SHA,'全37源の保存又は共有参照解決':True,
           '正式3MD原文先退避':True,'文書数':len(docs),'区分件数':{k:len(v) for k,v in groups.items() if isinstance(v,list)},
           '固定ZIP_SHA256':groups['固定ZIP']['ZIP_SHA256'],'保管索引SHA256':sha((FORMAL/'保管索引.json').read_bytes()),
           '177MB/Raw/価格CSV/金融結果/追加2場読取':False,'正式3MD変更':False,'重大不足':[]}
    write(FORMAL/'検査/F0原文と源の保管確認.json',json_bytes(proof))
    print(json.dumps({'成功':True,'段階':'F0','proofSHA256':sha(json_bytes(proof))},ensure_ascii=False))


# ----------------------------------------
def f1() -> None:
    """
    機能: F1原文とSource/固定取得/metaを各一度だけgzip保存する。
    引数: なし。返り値: None。自然金融結果を開かず正式3MDも変更しない。
    """
    raw=(RUN/'F1金融前.json').read_bytes();assert sha(raw)==F1_SHA
    frozen=json.loads(raw);old=json.loads((FORMAL/'検査/F0出生前.json').read_bytes())
    assert frozen['試行']==144 and len(frozen['ファイル'])==54
    assert all(frozen['ファイル'][p]==h for p,h in old['ファイル'].items())
    saved_f1=save(RUN/'F1金融前.json',FORMAL/'検査/F1金融前.json',F1_SHA)
    snap,docs=snapshot(frozen,'F1',F1_SHA)
    refs={};new=[]
    for source,name in ((RUN/'Sourceの出生と取得.json','Sourceの出生と取得.json.gz'),
                        (RUN/'固定入力/固定取得入力.json','固定取得入力.json.gz'),
                        (RUN/'固定入力/入口参照.json','入口参照.json.gz')):
        rec=save(source,INPUTS/name,frozen['ファイル'][str(source)],True);new.append(rec);refs[rec['復元先']]=rec
    for source,name in ((RUN/'F0出生前.json','F0出生前.json'),(RUN/'固定入力/転送の確認.json','転送の確認.json')):
        if name=='F0出生前.json':
            saved=FORMAL/'検査'/name;body=saved.read_bytes();assert sha(body)==F0_SHA
            rec={'保存元':saved.relative_to(ROOT).as_posix(),'復元先':source.relative_to(ROOT).as_posix(),
                 '形式':'同体','保存bytes':len(body),'保存SHA256':F0_SHA,'解凍bytes':len(body),'解凍SHA256':F0_SHA}
        else: rec=save(source,FORMAL/'検査'/name,frozen['ファイル'][str(source)])
        refs[rec['復元先']]=rec
    addition={p:h for p,h in frozen['ファイル'].items() if p not in old['ファイル']}
    assert len(addition)==17
    groups=resolve(addition,'金融前追加',refs,docs)
    p=FORMAL/'保管索引.json';index=json.loads(p.read_bytes())
    index.update({'段階':'F0/F1原文・Sourceと固定入力meta恒久保存。金融正本は未保存',
                  'F1_SHA256':F1_SHA,'F1直接源数':54,'F1増分源数':17,'F1原文':saved_f1,'F1文書原文':snap,
                  'F1増分復元参照':groups,'F1増分固定資料':groups['固定ZIP'],'新共用入力':new,
                  'F1共有入力':groups['共有入力'],'F1共有コード':groups['共有コード'],'F1追加入力':groups['保存済み参照'],
                  'Source内容の数値分析':False,'新観測/金融/Raw/価格CSV/追加2場読取':False})
    p.write_bytes(json_bytes(index))
    proof={'成功':True,'試行':144,'F1_SHA256':F1_SHA,'F1増分17源の保存又は共有参照解決':True,
           '正式3MD原文先退避':True,'Source/固定入力/metadata各1gzip':True,'保存入力':new,
           '区分件数':{k:len(v) for k,v in groups.items() if isinstance(v,list)},
           '固定ZIP_SHA256':groups['固定ZIP']['ZIP_SHA256'],'保管索引SHA256':sha(p.read_bytes()),
           '正式3MD変更':False,'金融結果/Raw/価格CSV/177MB/追加2場読取':False,'重大不足':[]}
    write(FORMAL/'検査/F1原文と増分の保管確認.json',json_bytes(proof))
    readme='# 144の全strong共用入力\n\nSource・固定取得・入口参照を各一度gzip保存した。圧縮/解凍SHAとbytes、元workへの復元先は[保管索引](../../study/00144_旧P3のstrongを全時間で評価する/保管索引.json)の新共用入力を参照する。共有122/138入力と原板は複写していない。これらの保存で出生/先着の有効性や実口座運用を証明するものではない。\n'
    write(INPUTS/'README.md',readme.encode('utf-8'))
    print(json.dumps({'成功':True,'段階':'F1','proofSHA256':sha(json_bytes(proof)),
                      '入力gzip':[{k:r[k] for k in ('保存元','保存bytes','保存SHA256')} for r in new]},ensure_ascii=False))
