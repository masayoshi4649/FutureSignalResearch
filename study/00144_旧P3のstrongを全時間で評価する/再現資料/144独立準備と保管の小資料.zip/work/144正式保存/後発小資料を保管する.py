"""144の独立準備・保存票回帰・保管器を、F0/F1固定への後付けとせず小ZIPへ保存する。"""
from pathlib import Path
import json
import zipfile
from 保存部品 import ROOT, FORMAL, sha, write, json_bytes


def main() -> None:
    """
    機能: F0/F1直接源外の検査用小資料と保存器を一度だけ保管する。
    引数: なし。自然Source/金融/価格を解析しない。
    返り値: None。保管索引の専有部分を追補し停止証跡を保存する。
    """
    f1=json.loads((FORMAL/'検査/F1金融前.json').read_bytes());direct={Path(p).resolve() for p in f1['ファイル']}
    files=[]
    for name in ('144連続strongの因果を独立確認する','144転送と運転の独立準備レビュー','144旧Strong32保存票の回帰','144正式保存'):
        for p in (ROOT/'work'/name).iterdir():
            if p.is_file() and p.suffix in ('.py','.md','.json','.go') and p.resolve() not in direct:files.append(p)
    files += [ROOT/'work/144正式文書を準備する.py',ROOT/'work/144正式文書の準備確認.json']
    files=sorted(set(files));entries=[]
    archive=FORMAL/'再現資料/144独立準備と保管の小資料.zip'
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in files:
            raw=p.read_bytes();assert len(raw)<1_000_000
            rel=p.relative_to(ROOT).as_posix();z.writestr(rel,raw)
            entries.append({'path':rel,'sha256':sha(raw),'bytes':len(raw),'区分':'F0/F1直接源外の独立人工/保存票回帰/保管器'})
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for r in entries:assert sha(z.read(r['path']))==r['sha256']
    p=FORMAL/'保管索引.json';index=json.loads(p.read_bytes())
    index['後発の準備小資料']={'ZIP':archive.name,'ZIP_SHA256':sha(archive.read_bytes()),'ZIP_bytes':archive.stat().st_size,
                              '格納源数':len(entries),'格納源':entries,'F0/F1への追加固定主張':False}
    restore=FORMAL/'検査/F0F1全源の復元参照確認.json'
    assert json.loads(restore.read_bytes())['成功']
    index['F0F1復元参照確認SHA256']=sha(restore.read_bytes())
    index['段階']='F0/F1原文・全54源参照・3入力gzip・独立準備/保存票回帰を保管。金融正本/CSV/再集計は後担当。'
    p.write_bytes(json_bytes(index))
    proof={'成功':True,'試行':144,'専有保存工程':True,'F0F1正式3MD原文退避':True,'全54源参照解決':True,
           '保存bytes51源復元一致':True,'177MB/2exeの非複製を区別':True,'Source/固定入力/meta各1gzip':True,
           '後発小ZIP':{'path':archive.relative_to(ROOT).as_posix(),'sha256':sha(archive.read_bytes()),'源数':len(entries)},
           '保管索引停止SHA256':sha(p.read_bytes()),'金融正本/CSV/再集計未保存':True,'正式3MD変更':False,
           'Raw/177MB/価格CSV/新金融/追加2場読取':False,'重大不足':[],'編集停止':True}
    target=FORMAL/'検査/先行保管の停止確認.json';write(target,json_bytes(proof))
    print(json.dumps({'成功':True,'停止SHA256':sha(target.read_bytes()),'保管索引SHA256':sha(p.read_bytes()),
                      '小ZIP_SHA256':sha(archive.read_bytes()),'源数':len(entries)},ensure_ascii=False))


if __name__=='__main__':
    main()
