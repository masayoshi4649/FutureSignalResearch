"""144 F0原文を、正式3MDを変更せず先行保管する。"""
from 保存部品 import f0

if __name__ == '__main__':
    f0()
