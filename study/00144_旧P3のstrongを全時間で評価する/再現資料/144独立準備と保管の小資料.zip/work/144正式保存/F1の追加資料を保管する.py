"""144 F1原文とSource/固定入力/metaを各一度保存する。"""
from 保存部品 import f1

if __name__ == '__main__':
    f1()
