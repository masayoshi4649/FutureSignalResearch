"""144の採用仕様・旧strong条件を自然実行前の正式3MDと版7全513セルへ保存する。"""
from pathlib import Path
import hashlib
import json
import posixpath
import re

ROOT = Path(__file__).resolve().parent.parent
DEST = ROOT / 'study/00144_旧P3のstrongを全時間で評価する'
ADOPT = ROOT / 'work/144_旧P3strongを全成立へ広げる採用仕様.md'
TABLE = ROOT / 'docs/議論/手法と時間スケールの汎用表_版7.md'
OLD = ROOT / 'work/強い入口の探索期限を延ばす次仮説/Source入口の再生器'


def sha(path: Path) -> str:
    """
    機能: 文書と参照ソースの指紋を求める。
    引数: path(Path)は対象ファイル。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def link(match: re.Match) -> str:
    """
    機能: 汎用表の参照先を新試行からの相対リンクへ移す。
    引数: match(re.Match)は元Markdownリンク。
    返り値: strは同じ資料を指すリンク。
    """
    label, target = match.group(1), match.group(2)
    if '://' in target or target.startswith('#'): return match.group(0)
    target = posixpath.normpath(posixpath.join('docs/議論',target))
    return '['+label+']('+posixpath.relpath(target,DEST.relative_to(ROOT).as_posix())+')'


# ----------------------------------------
def settings() -> str:
    """
    機能: 元の57行と9尺度を保ち、旧score/strong/T8の複合設定を記入する。
    引数: なし。単独技法の効果や新成績は記入しない。
    返り値: strは513セルのMarkdown。
    """
    scales = ('原板・逐次','1分','3分','5分','15分','30分','60分','セッション足','日足')
    configured = {}
    for scale in ('5分','15分','30分'):
        configured.update({
            ('I01',scale):'144S01：Gap/EMA8・21増分の符号を既知成分平均Tへ',
            ('I08',scale):'144S01：DI差の符号をTへ・欠測を支持0へしない',
            ('C04',scale):'144S01/S02：方向DIを複合・ADXは5分反転で別役割',
            ('C07',scale):'144S01：当時配送済み5/15/30・fresh/同限月seedは旧118Bank',
        })
    configured.update({
        ('I01','5分'):'144S02：sGap/sΔEMA8/sΔEMA21>0・144D01：実体比B0',
        ('I01','30分'):'144S02：既知30T逆向き拒否・144D01：B0ΔEMA21>=0で第2段',
        ('I03','5分'):'144S01/S02：HistとΔのM・144D01：B0Hist/ATR>=.1',
        ('I04','5分'):'144S02：trend 0<=s(RSI−50)<=20、reversal 前s(RSI−50)<=−15/Δ回復',
        ('I08','5分'):'144S02：trend sDI差>0、reversal ADX<前ADX・強度と方向を分離',
        ('I09','5分'):'144S01/S02：ATR/前ATR>0・TR>=0/TR<=2前ATR・g値幅重み',
        ('C01','5分'):'144S02：MA/DI背景＋RSI/MACD勢い＋価格/値幅/量の複合',
        ('C01','15分'):'144S02：15Tは既知時だけ逆向き拒否・未知でも旧規則通り',
        ('C01','30分'):'144S02：30Tは既知時だけ逆向き拒否・T8の別段階も区別',
        ('P01','5分'):'144S01：実体/終値位置/Last−CのP、144D01：s実体比[.5,.75)',
        ('P02','5分'):'144S02：当場連続4本・当足除く前3本高安の復帰',
        ('P03','5分'):'144S02：前3高安を構造境界・新しい対向125pt余地条件なし',
        ('P04','5分'):'144S02：trend優先→構造reversal・単なる過熱/失速反転ではない',
        ('P05','5分'):'144S01：C−O/2C−H−L/当時Last−Cの符号・未確定OHLCなし',
        ('P06','5分'):'144S02：前3範囲内Close/境界5pt復帰・T8は入口選別と別',
        ('P09','5分'):'144S02：順側反対端strict試行→前3範囲内Close/Last5pt復帰',
        ('V01','5分'):'144S02：RVOL既知>=1・元118Bankの先行20公表量窓',
        ('B01','原板・逐次'):'144X01：別Raw+1秒/最初正常Bid<Ask/30秒strictTTL・Ask/Bid',
        ('E01','原板・逐次'):'144E01：U0主/N0/S0/T0/C0・300比較・3分母率/IFD別',
        ('E01','60分'):'144E01：主実BBO/H60±125、全73min1/平均概ね1hは別判定',
        ('E02','原板・逐次'):'対象外：入口診断。必須利益追尾/口座保有の本番検証は別段階',
    })
    out = ['# 00144：設定と結果（汎用表・版7）','',
           '2026-11-12。新Source・出生/取得・方向票・率/損益は未実行。版7の57手法×9尺度＝513セル。',
           '', '144S01=元score、144S02=元strong、144D01=出生固定B0→T8、144X01=全成立の再準備/取得、144E01=5政策評価。旧規則の複合条件を再用し、指標単独の効果や市場心理の因果を確認した表ではない。1分/3分へ新条件を加えず、Source保有/追加枚数による頻度水増しをしない。','',
           '| ID | 手法 | '+' | '.join(scales)+' |','| '+' | '.join(['---']*11)+' |']
    ids = []
    for line in TABLE.read_text(encoding='utf-8').splitlines():
        cells = [c.strip() for c in line.split('|')[1:-1]]
        if len(cells) != 11 or not re.fullmatch('[A-Z][0-9]{2}',cells[0]): continue
        identity = cells[0]; ids.append(identity)
        label = re.sub(r'\[([^]]+)\]\(([^)]+)\)',link,cells[1])
        out.append('| '+' | '.join([identity,label]+[configured.get((identity,s),'未使用・未検証') for s in scales])+' |')
    assert len(ids) == len(set(ids)) == 57
    assert all(i in ids and s in scales for i,s in configured)
    out += ['', '## 設定明細と未実行結果','',
            '|設定ID|役割・尺度|閾値と未知処置|適用・実行状態|','|---|---|---|---|',
            '|144S01|方向/勢い/価格/値幅/量のscore・5/15/30|元score133を再用。既知成分だけの符号平均・不足拒否・同Raw全公表後|新stream準備・自然未実行|',
            '|144S02|順行/構造反転・5/15/30|RVOL>=1/TR<=2前ATR・trend/reversalの元全AND、条件.mdへ全文|新stream準備・自然未実行|',
            '|144D01|B0→T8・5/30|元s実体比[.5,.75)でB0反転→B0ΔEMA21_30>=0かつB0Hist5/ATR5>=.1で再反転|出生時固定・段階別未知維持、学習再選定なし|',
            '|144X01|連続Raw・出生と取得|5分ID+元sideをborn消費、pending1、別Raw+1秒/30秒TTL/最初正常BBO|C0の未来状態で抑止しない・実装人工は後確認|',
            '|144E01|独立mini1枚・5政策|BBO/Last・H30/60・±25/50/100/125/200・全体/前48/後25=300|新金融未実行・Last金額null|','',
            '|項目|U0 主T8 union|N0 native union|S0新元側|T0新T8|C0旧81|','|---|---|---|---|---|---|',
            '|母集団|C0とT0同原行dedup|C0とS0同原行dedup|新strong全取得|S0同じ取得Quote|固定81/73場|',
            '|出生/取得/反転数|未実行|未実行|未実行|未実行|新streamへ再適用なし|',
            '|H60±125 順/逆/未到達/不足|未実行|未実行|未実行|未実行|144比較未実行|',
            '|到達済み/完了/全件分母率|未実行|未実行|未実行|未実行|144比較未実行|',
            '|C5利益/損失/差引/未知|未実行|未実行|未実行|未実行|144比較未実行|',
            '|全73min1/全時間頻度|C0保持は設計、数値は未実行|C0保持は設計、数値は未実行|0取得場も記録|0取得場も記録|固定対照同体を照合予定|','',
            '旧strong32の73.91%は17/(17+6)という既使用の小群の動機で、144の新stream成績ではない。deadline38はこの小群と分ける。旧C0内のdeadlineは保護するが、新deadlineの連発は作らない。','',
            '生まれた順側とT8の物理側は区別し、反転率を1−pで作らない。正常BBOの共通取得Quoteから各側Ask/Bidを使う。未使用・未検証、必要な値が未知のデータ不足、設計上の対象外を分け、未実行を0件/0円としない。詳細は[条件](条件.md)、研究の位置付けは[README](README.md)。','']
    return '\n'.join(out)


# ----------------------------------------
def main() -> None:
    """
    機能: 最大番号の次の144を新規作成し、仕様同体・513セル・リンクを確認する。
    引数: なし。新Source/価格/金融を読み取らない。
    返り値: None。正式3MDと準備proofだけを作成する。
    """
    nums = [int(p.name[:5]) for p in (ROOT/'study').iterdir() if p.is_dir() and re.match(r'^\d{5}_',p.name)]
    # 同じ採番の未固定3MDのリンク修正だけは、準備proof保存前に継続する。
    if DEST.exists():
        assert max(nums) == 144 and not (ROOT/'work/144正式文書の準備確認.json').exists()
        assert {p.name for p in DEST.iterdir()} == {'README.md','条件.md','設定と結果.md'}
    else:
        assert max(nums) == 143
    assert sha(TABLE) == '585d0d9ba69ff3601325e9e6564ede53aeb81b0d33a2da6cb67e20e175187c3d'
    pins = {ADOPT:sha(ADOPT),TABLE:sha(TABLE),**{OLD/n:sha(OLD/n) for n in ('score.go','direction.go','entry.go','clock.go')}}
    old143 = {str(p):sha(p) for p in (ROOT/'study/00143_複合テクニカルを過去の場だけで学び方向を判別する').glob('*.md')}
    adopted = ADOPT.read_text(encoding='utf-8').split('\n',1)[1].strip()
    readme = '''# 旧P3のstrongを全時間で評価する

試行00144。2026-11-12、新Source・出生/取得・方向票・先着率/損益は未実行。旧P3の初取得で止めていたstrong条件を、同じ技術条件のまま全時間へ広げる。主U0を事前固定し、結果後に政策を交換しない。

## 仮説と対照

旧L0補完70はstrong32（trend31/reversal1）とdeadline38だった。旧strong32のT8は17順/6逆/4未到達/5不足、到達済み73.91%、C5利益218,537円/損失103,770円/差引+114,767円だった。元側10順/14逆から改善したが、既使用の小群である。coveredが取得後のstrong評価より先に停止するため、この同じ条件の後続全成立は確認した旧試行にない。73.91%を新全成立や未知期へ外挿しない。旧32の確認は保存Decision/Direction票をCheckStoredStrongへ与えたpredicate/T8一致と、旧8源のpackage以外の本文同体・同じ122公表/118Bankの配送/seedの確認を範囲とする。新scannerが当時32Snapshotを独立に再構築したとは主張せず、checkpoint専用CLIも追加しない。

新streamはSource FARの通知・保有・追加枚数・coveredに依存せず、確定公表のMA/DI方向、RSI/MACD勢い、値幅、量、価格構造を複合して順行/構造反転を生む。新しい学習器や閾値探索は使わない。心理的な読みは、方向/勢い/参加量が整う順行と、過熱後の構造復帰・勢い回復を伴う反転を区別する仮説であり、心理の因果を証明するものではない。

|政策|内容|母集団と方向|
|---|---|---|
|U0 主|C0＋全T0のunion|同取得原行はC0優先。新strongは出生時T8|
|N0 対照|C0＋全S0のunion|同取得原行はC0優先。新strongは元P3側|
|S0|新strongの全取得|元strong方向。0取得場も残す|
|T0|S0と同じ取得|出生時固定B0→T8。方向別実Ask/Bid|
|C0|旧81|固定時刻/方向を保護。新streamを抑止する未来状態にしない|

5政策は別々の入口診断で、同じ口座へ合算しない。C0のE0やdeadlineを保護することと、新streamへE0/3時間deadlineを追加することを分ける。出生・取得・unionの数は未生成。旧138の752poolを全維持して狭い反転補正をする試行ではなく、独立した旧strong全成立stream＋旧81対照の比較である。

## 出生と取得の時計

固定122のCSV由来5/15/30分と118Bankを使い、同Rawの全公表を配送してから現在Lastで判定する。足End、AvailableAt/DeliveryAt、実際のモデル配送原行を区別し、未来足やRaw別形成足へ置換しない。実receivedAtの完全な復元とは呼ばない。

最新5分公表ID＋元strong方向をborn時に消費する。同足同方向は型が変わっても再出生しない。新5分IDなら再判定できる。全streamでpendingは1、各Rawで先に処理し、終了したRawでは別の未消費キーを判定できる。定時5分新規や毎時の強制建てではない。

旧非E0方式の別Rawかつ1秒後以降、最初の正常Bid<Askを取得代用にする。30秒TTLとH60新規限界は等号を拒否する。pending中に新しいstrong支持やcap/risk/2行holdを追加しない。新streamはC0の将来イベントを見て止めず、unionで実取得が同原行のものだけC0優先へ畳む。異なる方向のaliasも記録する。

## 評価と再現の段階

主U0の実BBO/H60/同幅±125ptで到達済み70%以上、全73場最低1、全ザラバ平均概ね1回/時を別判定し、共同達成も示す。場による頻度の偏りを許容し、均等割当・場別上限・毎時強制を置かない。standalone S0/T0の未取得場も除外しない。

5政策×BBO/Last×H30/H60×幅25/50/100/125/200×全体/前48/後25の300比較、可変入口一覧、全73場の3表をCSVで保存する。順/逆/未到達/不足と、到達済み・H完了・全件分母率を併記する。IFD金額の既知/未知は先着の未到達/不足と別。独立mini1枚100円/pt・往復77円、C5はさらに往復10pt=1,000円。Last金額はnull。政策C0と追加滑り0の費用C0を区別する。

F0で仕様/旧規則/入力/コード/正式3MDを固定→Raw73の全出生/取得と元/T8方向→F1→固定133の実正逆観測→300比較/独立検算/CSV/恒久保存。[条件](条件.md)に式と未知/因果境界、[設定と結果](設定と結果.md)に版7全513セルを残す。Sourceの実装人工・入力SHAと自然結果は未生成なので、完了を先取りしない。

## 入力と限界

既知73場と固定122公表入力SHA `6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec` を使う。旧81は[共有138入力](../../inputs/00138_全成立入口の共用入力/manifest.json.gz)と[137結果](../00137_市場終端後の既知回復を公表時点で確認する/README.md)を参照する。固定122の復元は[122手順](../00122_E0固定条件を全セッションで検証する/再現資料/再現手順.md)。新Raw/中間大入力は正式へ重複保存しない。

全期間は既使用で、前48/後25も独立未知期ではない。T8は既使用期で選定済みの規則であり、本144で新fitしないことを未学習の意味にしない。元strongの取得条件とT8の最終注文方向を分け、反転側の構造/riskを新設・再構築していない。ラージBBOによる独立mini1枚の診断で、mini実板・口座保有/片側10枚・実IFD/必須利益追尾の本番運用は別段階。追加2場の価格は未読。旧143以前は変更しない。
'''
    protocol = '# 144：旧P3 strong全成立の固定条件\n\n2026-11-12。新Source・出生/取得・方向・率/損益の自然実行前。採用仕様SHA `'+pins[ADOPT]+'`。\n\n## 採用仕様の原文\n\n'+adopted+'\n\n'
    protocol += '''## 元scoreとstrongの式・未知処置（144S01/S02）

元score133/strong133の実装を式・unknown・fresh・順序ごと再用する。次は読解用で、独立の簡略式への置換や閾値調整を許すものではない。sは元strongが選ぶ物理方向±1。EMA/RSI/MACD/ATR/DMIの期間・seed・previous定義は固定122公表値を使い、別計算で埋めない。

|段階|固定する計算・全条件|
|---|---|
|方向T_m|m=5/15/30。Gap、ΔEMA8、ΔEMA21、PlusDI−MinusDIのsignを既知成分だけで平均。Tは既知T_mだけの平均。未知を支持0へ数えない|
|勢いM|sign(RSI5−50)、sign(Hist5)、sign(ΔRSI5)、sign(ΔHist5)の既知平均。5分T又はMの全成分未知はeligible拒否|
|価格P|確定5分のsign(C−O)、sign(2C−H−L)、sign(出生Last−C)の平均。価格既知5分を必須|
|値幅と量|ATR5>0、前ATR5>0、TR5>=0を既知で要求。v=TR/前ATR、v=0ならg=1、他g=min(1,2/v)。u=clip(RVOL5,0,1)、未知RVOLをknownへ変えない。S=(T+g×(M+(1+u)P))/(1+g×(2+u))|
|strong共通|score eligible、RVOL5既知>=1、TR5<=2×前ATR5。RVOL未知を量0で合格にしない|
|順行trend|sGap5>0、sΔEMA8_5>0、sΔEMA21_5>0、sDI差5>0が全て既知。既知の15T/30TはsT>=0、未知は元規則どおり許容。RSI既知で0<=s(RSI−50)<=20、Hist既知でsHist>0、sM>0、sP>0、abs(S)>=0.5|
|構造反転reversal|trend未成立時。前3高安、前RSI、ΔRSI、ΔHist、ADX5/前ADXを既知にしADX5<前ADX。s(前RSI−50)<=−15、sΔRSI>0、sΔHist>0。買は当足Low<前3Low、売はHigh>前3High。境界B=買:前3Low/売:前3Highに対しs(C−B)>=5、前3Low<=C<=前3High、s(出生Last−B)>=5|

trendを買→売の順に検査後、reversalを買→売の順に検査する元の順番を保持する。reversalは構造からsを解決し、単にSの符号を反転する処置ではない。反転のabs(S)>=0.5や現在Histの位相、取得位置125pt余地などの新条件を足さない。strongが成立しない時は新deadlineへ逃がさない。

構造窓は当場の連続した価格既知5分4本（当足＋直前3本）。前3高安へ当足を混ぜない。場/限月変更、欠足、価格未知で窓を切り、前場の構造窓をcarryしない。指標の同限月seedと、当場freshの現在公表を分ける。Bankの現在公表はEnd<=AvailableAt<=DeliveryAt<=実配送<=出生、配送index/物理行<=出生、出生time<End+幅+60を満たす。最新が未知なら古い良い足へfallbackしない。RVOLは元Bankの先行20公表量の平均に対する当公表量で、量窓/未知/場初期化を元どおり扱う。

## 出生固定方向（144D01）

出生と同Snapshotの5分OHLCを用い、r=s(C−O)/(H−L)。H=Lならr未知でB0=s。既知rが0.5以上0.75未満のときだけB0=−s、その他B0=s。次にB0×ΔEMA21_30>=0とB0×Hist5/ATR5>=0.1が両方既知ならT8=−B0、その他T8=B0。比には既知ATR5>0が必要。実体比が未知でも第2段の別の既知入力まで止めない。

元strong方向、B0、T8、known/null、原値、refを保存する。出生後の背景や取得後結果で方向を選び直さない。S0とT0の取得Quoteは同じだが、買Ask/売Bidの物理側は別に評価する。反対先着を1−pで推定しない。C0は既に選ばれた旧方向でありT8を再適用しない。

## 状態と因果の固定（144X01）

|順序|状態遷移|
|---|---|
|場開始|旧順序で過去公表seedとStartSessionを行う。同限月の指標助走だけ継承。消費キー/pending/構造窓は当場で初期化|
|各Raw|同Rawで知得する全5/15/30公表を先に配送。新streamはC0のcovered/未来E0に依存せず監視|
|既pending|force/new-entry限界又はTTLへ到達なら等号で失効。出生とは別index/物理行、出生+1秒以降の最初の正常BBOで取得。未満・異常BBOでは待つ。最新strong/背景/cap/riskの再検査は追加しない|
|新出生|pendingが残る間は新候補もキー消費もしない。終了した同Rawは新候補評価可。fresh価格既知5分のID＋元strong sが未消費で、strong成立かつ現在が新規限界前なら出生し、即キー消費|
|終了後|取消/期限/取得後でも同じキーを再利用しない。strong型やT8側をキーへ足さない。新5分IDは同方向でも再準備可。固定cooldownを追加しない|
|union|全取得を保存後、session/contract/time/index/source_line同体でC0優先。方向をキーへ加えず異方向aliasも残す。C0に未来取得があることを理由にnewstreamの当時出生を止めない|

新規取得はmin(元force_close,場End−300−3600)よりstrict前、観測はEnd−300よりstrict前。出生時Expires=min(出生+30,新規限界)。同価格秒の後Rawだけでは取得せず、少なくとも1秒進む必要がある。30秒等号の正常BBOは取得しない。E0専用2行holdやcap/riskを非E0へ移植しない。

入力122はtop success無しのtrial122、Raw.bytes省略を宣言サイズ不明として扱い、原入力にない値を必須にしない。実stat/SHA・全Raw末尾までのquality・採用数を記録し、宣言SHA/品質を元73metadataと照合する。3場の保管Rawが105へ移る由来も元metadataどおりで、CSVとの内容同体を根拠なく主張しない。新しい公表時計や受信時計へ置き換えない。

## 評価と実行前の確認（144E01）

5政策×2軸×2H×5幅×3期間=300比較。主U0実BBO/H60±125の順/(順+逆)>=70%、全73場min1、全時間平均概ね1回/時を別判定して共同判定も保存する。全時間頻度の分母はΣ(scene.end−300−scene.start)/3600、新規可時間は副で名目時計と明記。政策自身の取得集合を分母にし、0取得場・未到達・不足を落とさない。0分母はnull。H完了分母率=順/全H完了、全件分母率=順/各政策全取得も併記する。

独立mini1枚、100円/pt、片道38.5円/往復77円。費用C0は追加0、費用C5はさらに往復10pt=1,000円。政策C0旧81とは名称を区別する。BBOの既存spreadを用い、IFD既知/未知、利益/損失絶対額/差引/PFを別に記録する。Last金額null。未到達/観測不足と金額未知を同一扱いにしない。保有重複を同時口座へ合算しない。

旧C0の全81方向・Quote・4stream/全幅対照を同体照合する。旧strong32の検査は、保存Decision/Direction票をCheckStoredStrongへ与えたpredicate/T8一致と、旧8源のpackage以外本文同体・同122公表/118Bank配送/seedの確認まで。新scannerが旧32時点のSnapshotを独立再構築したとの主張やcheckpoint専用CLIは加えない。born消費/pending優先/初取得後停止の有無が異なる全streamの約定集合まで同体とは主張しない。新stream元側とT8は同取得の実BBOで比較し、unionとstandaloneの集合を混ぜない。

採用仕様・正式3MD・旧関数と新Source/bridge/算術・入力SHAをF0固定→自然Source73→全出生/取消/取得と方向/union参照を保存→F1固定→金融→独立確認/三表CSV/恒久保存。未生成の出力件数/SHA/率/損益は未実行のままとする。

事前人工では売買鏡像、trend/reversalの反対方向の同時成立回避、unknown/fresh、同Raw全配送、同キー型変更の再出生拒否、新5分再準備、pending1と終了Raw再判定、出生/期限等号、別行+1秒最初BBO、C0未来非抑止と異方向alias同原行C0優先を確認する。本文の因果reviewは仕様の確認で、未完成Sourceの人工成功や自然結果を先取りしない。

全期既使用、追加2場価格未読。T8既選定、反転側geometry/mini実板/口座10枚/実IFD/必須利益追尾未再構築。複合成績を単独MA/RSI等の効果や市場心理の証明にしない。旧143以前は変更しない。
'''
    protocol += '\n## 固定資料の指紋\n\n|資料|SHA256|\n|---|---|\n'
    for p,h in pins.items():
        protocol += '|['+p.name+']('+posixpath.relpath(p.relative_to(ROOT).as_posix(),DEST.relative_to(ROOT).as_posix())+')|'+h+'|\n'
    protocol += '\n固定122公表入力の元SHAは `6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec`。新Sourceの全入力/由来/コード/exe/SHAはF0へ保存する。恒久共用資料は[138manifest](../../inputs/00138_全成立入口の共用入力/manifest.json.gz)、[133](../../inputs/00133_探索期限延長の共用入力/README.md)、[124](../../inputs/00124_同入口正逆の共用入力/README.md)を参照する。\n'
    DEST.mkdir(exist_ok=True)
    for name,text in (('README.md',readme),('条件.md',protocol),('設定と結果.md',settings())):
        with (DEST/name).open('w',encoding='utf-8',newline='\n') as f: f.write(text.rstrip()+'\n')
    assert adopted in protocol
    rows,links = [],[]
    for p in DEST.glob('*.md'):
        for _,target in re.findall(r'\[([^]]+)\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
            if '://' in target or target.startswith('#'): continue
            assert (p.parent/target.split('#')[0]).resolve().exists(),target
            links.append(target)
    for line in (DEST/'設定と結果.md').read_text(encoding='utf-8').splitlines():
        cells = [c.strip() for c in line.split('|')[1:-1]]
        if len(cells)==11 and re.fullmatch('[A-Z][0-9]{2}',cells[0]): rows.append(cells)
    assert len(rows)==57 and sum(len(r)-2 for r in rows)==513
    assert all(sha(p)==h for p,h in pins.items())
    assert all(sha(Path(p))==h for p,h in old143.items())
    proof = {'成功':True,'確認日':'2026-11-12','試行':144,'最大既存番号':143,'採番':DEST.name,
             '採用本文同体':True,'手法数':57,'尺度数':9,'全セル':513,'ローカルリンク':len(links),
             '採用と旧元規則':{str(p):h for p,h in pins.items()},
             '正式3MD':{str(p.relative_to(ROOT)):sha(p) for p in sorted(DEST.glob('*.md'))},
             '因果review':'仕様段階。既pending先/5分ID+元side born消費/同Raw配送/別Raw+1秒/strictTTLと新規限界/C0未来抑止なしを確認。',
             'Root確認済み補足':['15/30 unknownを元通り許容','非E0 pending strong再要求/cap追加なし','30秒と新規限界等号拒否','消費は元sideと5分IDだけ'],
             '新Source人工実行':False,'新Source自然実行':False,'新方向票金融価格RawCSV追加2場読取':False,
             '旧143MD前後同体':old143,'生成コードSHA256':sha(Path(__file__)),'編集停止':True}
    out = ROOT/'work/144正式文書の準備確認.json'
    with out.open('x',encoding='utf-8',newline='\n') as f: json.dump(proof,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps({'成功':True,'正式3MD':proof['正式3MD'],'準備SHA256':sha(out),'全513セル':True},ensure_ascii=False))


if __name__ == '__main__':
    main()
