package strongstream144

import (
	"testing"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// independent144Detector は自然ファイルを使わない連続strong状態を作ります。
//
// 引数: t(*testing.T)。返り値: *Detector/*rules.Bank/*Window133/Quoteです。
func independent144Detector(t *testing.T) (*Detector, *rules.Bank, *Window133, Quote) {
	t.Helper()
	b, w, q := scoreFixture133(t, true, false, nil)
	d, err := New(Scene144{Session: "current", Contract: "X", Start: 99000, End: 120000, ForceClose: 119000})
	if err != nil { t.Fatal(err) }
	return d, b, w, q
}

// TestIndependent144BornKey は同じ5分ID/元sideの出生消費と新ID再準備を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。自然価格と金融を読みません。
func TestIndependent144BornKey(t *testing.T) {
	d, b, w, q := independent144Detector(t)
	if err := d.Observe(b, w, q); err != nil { t.Fatal(err) }
	if len(d.Events) != 1 || d.Events[0].Side != 1 || d.Events[0].T8Side != -1 || len(d.consumed) != 1 {
		t.Fatal("元sideとT8側を分けた出生又はキー消費の差")
	}
	e := d.Events[0]
	q.Index++; q.SourceLine++
	if err := d.Observe(b, w, q); err != nil { t.Fatal(err) }
	if e.Status != "pending" { t.Fatal("同価格秒の後原行で取得した") }
	q.Time++
	if err := d.Observe(b, w, q); err != nil { t.Fatal(err) }
	if e.Status != "filled" || *e.EntryPrice != q.Ask || *e.EntryPriceT8 != q.Bid || len(d.Events) != 1 {
		t.Fatal("共通Quoteの別価格側又は同キー再要求の差")
	}
	p := scorePublication133("current", 300, 200, 100240)
	if err := b.Add(p); err != nil { t.Fatal(err) }; w.observe(p)
	q.Time, q.Index, q.SourceLine = 100300, 200, 201
	if err := d.Observe(b, w, q); err != nil { t.Fatal(err) }
	if len(d.Events) != 2 || d.Events[1].Status != "pending" || len(d.consumed) != 2 {
		t.Fatal("新5分IDで再準備しなかった")
	}
}

// TestIndependent144PendingThenNewBorn はpending中の別キー未消費と終了原行の新出生を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。C0未来状態を渡す経路を持ちません。
func TestIndependent144PendingThenNewBorn(t *testing.T) {
	d, b, w, q := independent144Detector(t)
	q.Time = 100299
	if err := d.Observe(b, w, q); err != nil { t.Fatal(err) }
	p := scorePublication133("current", 300, 200, 100240)
	if err := b.Add(p); err != nil { t.Fatal(err) }; w.observe(p)
	q.Time, q.Index, q.SourceLine, q.QuoteOK = 100300, 200, 201, false
	if err := d.Observe(b, w, q); err != nil { t.Fatal(err) }
	if len(d.Events) != 1 || len(d.consumed) != 1 || d.pending == nil { t.Fatal("pending中に別キーを消費した") }
	q.Time, q.Index, q.SourceLine, q.QuoteOK = 100301, 201, 202, true
	if err := d.Observe(b, w, q); err != nil { t.Fatal(err) }
	if len(d.Events) != 2 || d.Events[0].Status != "filled" || d.Events[1].Status != "pending" {
		t.Fatal("既pending処理の終了原行で新未消費キーを判定しなかった")
	}
	if d.Events[0].EntryQuote.Index != d.Events[1].Birth.Index || d.Events[1].EntryQuote != nil {
		t.Fatal("同原行の次出生を直ちに取得した")
	}
}

// TestIndependent144PendingClock は期限等号拒否と買売の共通Quoteを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。新たなcap/risk/背景条件は足しません。
func TestIndependent144PendingClock(t *testing.T) {
	for _, side := range []int{1, -1} {
		born := Quote{Time: 100, Index: 10, SourceLine: 20, Last: 100, Bid: 95, Ask: 105, QuoteOK: true}
		makeEvent := func() *Event { return &Event{Side:side, T8Side:-side, Birth:born, Status:"pending", Expires:130} }
		e := makeEvent(); q := born; q.Index++; q.SourceLine++; q.Time = 101; q.Last = 50
		pending144(e, q, 200)
		if e.Status != "filled" || e.EntryQuote == nil { t.Fatal("非E0の最初正常BBOを新構造条件で拒否した") }
		want, opposite := q.Ask, q.Bid
		if side < 0 { want, opposite = q.Bid, q.Ask }
		if *e.EntryPrice != want || *e.EntryPriceT8 != opposite { t.Fatal("物理価格側の鏡像差") }
		e = makeEvent(); q.Time = 130; pending144(e,q,200)
		if e.Status != "unfilled_expired" || e.EntryQuote != nil { t.Fatal("TTL等号を取得した") }
		e = makeEvent(); q.Time = 120; pending144(e,q,120)
		if e.Status != "force_close" || e.EntryQuote != nil { t.Fatal("新規限界等号を取得した") }
		e = makeEvent(); q.Time = 100.5; pending144(e,q,200)
		if e.Status != "pending" { t.Fatal("1秒未満を取得した") }
	}
}

// TestIndependent144UnknownPolicies は上位未知の許容と量未知の拒否を分けます。
//
// 引数: t(*testing.T)。返り値: ありません。未知を既知0へ変更しません。
func TestIndependent144UnknownPolicies(t *testing.T) {
	b, w, q := scoreFixture133(t, true, false, func(p *rules.Publication, i int) {
		if p.Frame.Frame.Width != 300 { p.Frame.Frame.PriceKnown = false }
	})
	d, err := score133(b,q,w); if err != nil { t.Fatal(err) }
	s, ok := strong133(d)
	if !ok || s.Side != 1 || d.Components["15_T"].Known || d.Components["30_T"].Known {
		t.Fatal("元規則の上位未知許容を変更した")
	}
	b, w, q = scoreFixture133(t, true, false, func(p *rules.Publication, i int) {
		if p.Frame.Frame.Width == 300 && i == 3 { p.Frame.Frame.VolumeKnown = false }
	})
	d, err = score133(b,q,w); if err != nil { t.Fatal(err) }
	_, ok = strong133(d)
	if ok || d.Components["RVOL5"].Known { t.Fatal("量未知を0/有効量に補完した") }
}
