"""144の最終停止Sourceに独立overlay人工を重ね、源不変と仕様の因果を確認する。"""
from pathlib import Path
import hashlib
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
SOURCE = ROOT / 'work/144旧P3strongの全成立'


def sha(path: Path) -> str:
    """
    機能: 対象の保存bytesから指紋を計算する。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 最終20源・元8源本文・人工19群とvet/buildを確認して停止する。
    引数: なし。自然入力/Raw/CSV/金融を読まない。
    返り値: None。自己専有フォルダの準備JSONを保存する。
    """
    author_path = SOURCE/'準備の確認.json'
    assert sha(author_path) == 'c62787fc75ca9cf316576d30c9312ad3ac90fd0e6dd97b82d6c9b1c28cbef3b2'
    author = json.loads(author_path.read_bytes()); assert author['成功'] and author['人工主群数']==15
    paths = [Path(r['path']) for r in author['源']]+[Path(author['実行ファイル']['path']),author_path]
    for row in author['源']+[author['実行ファイル']]:
        p = Path(row['path']); assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
    copied = json.loads((SOURCE/'由来.json').read_bytes())['複写']; assert len(copied)==8
    for row in copied:
        p,q = ROOT/row['source'],ROOT/row['target']; paths.extend((p,q))
        assert sha(p)==row['sha256'] and sha(q)==row['target_sha256']
        assert p.read_text(encoding='utf-8').replace('package holdingohlc113','package strongstream144',1)==q.read_text(encoding='utf-8')
    formal_path = ROOT/'work/144正式文書の準備確認.json'
    formal = json.loads(formal_path.read_bytes()); assert formal['成功'] and formal['全セル']==513
    paths.append(formal_path)
    for p,h in formal['正式3MD'].items():
        path = ROOT/p; assert sha(path)==h;paths.append(path)
    for p,h in formal['採用と旧元規則'].items():
        path = Path(p);assert sha(path)==h;paths.append(path)
    before = {str(p.resolve()):sha(p) for p in set(paths)}
    overlay = OWN/'overlay.json'
    assert json.loads(overlay.read_bytes())=={'Replace':{str(SOURCE/'independent144_test.go'):str(OWN/'独立人工_test.go')}}
    commands = [['go','test','-count=1','-overlay='+str(overlay),'-v','./...'],
                ['go','vet','./...'],['go','build','./...']]
    logs = []
    for command in commands:
        done = subprocess.run(command,cwd=SOURCE,capture_output=True,text=True,encoding='utf-8')
        logs.append({'引数':command,'終了コード':done.returncode,'標準出力':done.stdout,'標準エラー':done.stderr})
        assert done.returncode==0,done.stdout+done.stderr
    passed = re.findall(r'^--- PASS: (\S+)',logs[0]['標準出力'],re.M)
    assert len(passed)==19 and sum(n.startswith('TestIndependent144') for n in passed)==4
    assert all(sha(Path(p))==h for p,h in before.items())
    report = {'成功':True,'試行':144,'重大未解決':[],'作者最終20源一致':True,'旧8源package以外同体':True,
              '作者人工15群':True,'独立overlay4群':True,'全19人工非cache':True,'vet_build':True,
              '確認':logs,'確認対象前後SHA256':before,
              '因果review':['同Rawの全公表配送後に既pending→新score/strongを処理',
                           '元5分ID+元strong sideをborn消費、T8側と型を追加しない',
                           'pending中に別キーを消費せず、終了Rawに新未消費キーは可',
                           '別Raw+1秒の最初正常BBO、TTL/共通新規限界は等号拒否',
                           '非E0の最新strong/cap/risk/2行hold再要求を追加しない',
                           '15/30未知許容と量未知拒否を元どおり区別',
                           'C0の未来/保有/coveredを新streamへ渡さず、unionは後段',
                           '同限月の過去seedと当場current/構造窓を分離',
                           '取得限界以後も全Raw/全公表の末尾までSHA/stat/品質/限月を検査',
                           '固定122 trial/success無し/Raw bytes無しに適合、0取得場も保存'],
              '旧32の範囲':'CheckStoredStrongへ保存Decision/Directionを与えたpredicate/T8一致を確認するAPI。自然保存32票は本reviewでは未実行。新scannerの当時32Snapshot再構築は主張しない。',
              '新Source自然生成':False,'自然RawCSV金融追加2場読取':False,'作者源変更':False,
              '独立人工SHA256':sha(OWN/'独立人工_test.go'),'自己コードSHA256':sha(Path(__file__)),'編集停止':True}
    out = OWN/'準備の確認.json';assert not out.exists()
    out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'人工主群':len(passed),'SHA256':sha(out)},ensure_ascii=False))


if __name__ == '__main__':
    main()
