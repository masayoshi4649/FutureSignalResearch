# 144連続strongの因果・独立準備レビュー

作者停止proof `c62787fc75ca9cf316576d30c9312ad3ac90fd0e6dd97b82d6c9b1c28cbef3b2` と実行ファイル `08d0a17899b05dadd064d84bb6d9870fb6bf2c45e17a2f362ef6d9c796322e14` の版を確認した。最終20源・旧8源のpackage以外本文同体・正式3MD/採用仕様を照合し、重大な不一致はなかった。

Sourceを変更せず、Go overlayへ専用人工4群を追加し、作者15群と合わせた19群を非cacheで実行した。`go vet ./...`、`go build ./...` も成功。出生時の5分ID＋元side消費、新5分再準備、pending中の別キー非消費、終了Rawでの次出生、30秒/新規限界の等号拒否、別行1秒と共通Quoteの物理Ask/Bid、15/30未知許容とRVOL未知拒否を確認した。

同Raw全配送後に既pending→新判定、同限月の過去seedと当場構造窓の分離、限界以後も末尾までSHA/stat/品質を検査、C0未来状態の非使用、0取得場の保存を静的に確認した。全必要源の前後指紋は同体だった。自然Source・Raw/価格CSV・金融・追加2場は開いていない。

旧32の確認範囲は保存Decision/Direction票を `CheckStoredStrong` へ与えたpredicate/T8の一致であり、新scannerによる当時32Snapshotの独立再構築ではない。本レビューでは自然保存32票も実行せず、API人工と元関数同体を確認した。Rootが後段で保存票を与える検査とは区別する。

正本は `準備の確認.json`（SHA `408e55b878ff00dc2bb9aa842721e2a10d26b9dac0a132fe237ca4bbe090ab43`）。`独立人工_test.go`、`overlay.json`、`準備を確認する.py` が再現用の小型コードである。既存確認JSONを上書きせず、再現時は専用work直下の別フォルダへ復元して実行する。正式条件と全513セルは `study/00144_旧P3のstrongを全時間で評価する/` へ保存済み。
