"""Rootの144結果完了通知後にだけ、明示指紋で別算術検算を実行する。"""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 明示した保存ファイルの指紋を計算する。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 通知済み144入力を束縛し、別算術出力を未作成先へ保存する。
    引数: なし。
    返り値: None。作者AGG/Source/旧成果は変更しない。
    """
    source={p:sha(p) for p in [HERE/'検算する.py',HERE/'人工検査.py',HERE/'README.md']}
    run=subprocess.run([sys.executable,'-X','utf8',str(HERE/'人工検査.py')],text=True,encoding='utf-8',capture_output=True,check=True)
    artificial=json.loads(run.stdout);assert artificial['成功'] and artificial['群数']==7
    prep={'成功':True,'試行':144,'段階':'初回は300数値一致後に頻度の説明3キー欠落で停止。そのschema追補後の別算術準備',
        '人工':artificial,'source':{str(p):h for p,h in source.items()},'人員独立':False,
        '意味':'144AGG作者の別実装。Root141calculate/Fraction使用、AGG作者関数importなし','自然JSON読取前の初回原文':'検査器の初回.zip','数値/方向選択の変更':False}
    p=HERE/'準備の確認.json';p.write_text(json.dumps(prep,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    own=ROOT/'work/144旧strongの全成立評価'
    paths={'f1':own/'F1金融前.json','fixed-input':own/'固定入力/固定取得入力.json','metadata':own/'固定入力/入口参照.json',
        'result':own/'固定取得の正逆観測.json','summary':own/'金融評価/集計.json'}
    command=[sys.executable,'-X','utf8',str(HERE/'検算する.py')]
    for name,path in paths.items():command += ['--'+name,str(path),'--'+name+'-sha256',sha(path)]
    command += ['--output',str(HERE/'別算術の確認.json'),'--execute-after-notice']
    result=subprocess.run(command,text=True,encoding='utf-8',capture_output=True)
    assert all(sha(p)==h for p,h in source.items())
    assert result.returncode==0,result.stderr+result.stdout
    print(result.stdout)


if __name__=='__main__':main()
