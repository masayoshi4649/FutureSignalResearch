"""144を別算術で再構成する。AGG作者関数をimportせず、作者出力は最後に読む。"""
from pathlib import Path
from collections import Counter
from fractions import Fraction
import argparse
import importlib.util
import json
import hashlib
import math
import statistics

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
CALCULATOR=ROOT/'work/141金融集計を独立に確認する.py'
CALCULATOR_SHA='30bd4aef8c2809699cb013f930cfbce152f3986fe8d3d3cc6b49452104c2269e'
OLD_PAIRS=ROOT/'work/138全成立入口の評価/固定取得の正逆観測.json'
OLD_SUMMARY=ROOT/'work/138全成立入口と頻度の集計/集計.json'
OLD_PAIR_SHA='d272fc6f6768342ff67e1a9ec58b0b7307a0a5b07cc215ba5ff7bcb50865b742'
OLD_SUMMARY_SHA='6ef283db667603884b42260affce732ba5c9b31731d24b1bb18f9e96ee4b3486'
POLICIES=('C0','S0','T0','U0','N0')
MODELS=('C0','S0','U0')
MODEL={'C0':'C0','S0':'S0','T0':'S0','U0':'U0','N0':'U0'}
HORIZONS=(1800,3600)
WIDTHS=(25,50,100,125,200)


def sha(path: Path) -> str:
    """
    機能: 明示ファイルの指紋を求める。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def arithmetic() -> object:
    """
    機能: Root141の別算術calculateだけを使用できるよう読む。
    引数: なし。
    返り値: objectは自然JSONをimport時に読まない私有module。
    """
    assert sha(CALCULATOR)==CALCULATOR_SHA
    spec=importlib.util.spec_from_file_location('144別算術のRoot141計算',CALCULATOR)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


# ----------------------------------------
def equal(expected: object, actual: object) -> int:
    """
    機能: 型を保ち、有限floatだけ許容差付きで再帰照合する。
    引数: expected/actual(object)。
    返り値: intは照合leaf数。
    """
    if isinstance(expected,dict):
        assert isinstance(actual,dict) and set(expected)==set(actual),(set(expected),set(actual))
        return sum(equal(v,actual[k]) for k,v in expected.items())
    if isinstance(expected,list):
        assert isinstance(actual,list) and len(expected)==len(actual)
        return sum(equal(x,y) for x,y in zip(expected,actual))
    if isinstance(expected,float):assert type(actual) in (int,float) and math.isfinite(actual) and math.isclose(expected,actual,rel_tol=1e-12,abs_tol=1e-9),(expected,actual)
    else:assert expected==actual and (type(expected) is not bool or type(actual) is bool),(expected,actual)
    return 1


# ----------------------------------------
def key(session: str, contract: str, quote: dict) -> tuple:
    """
    機能: 成績や方向を使わない取得原行の識別子を作る。
    引数: session/contract(str)、quote(dict)。
    返り値: tuple。
    """
    return session,contract,quote['time'],quote['index'],quote['source_line']


# ----------------------------------------
def collect(fixed: dict, metadata: dict, result: dict, strict: bool=True) -> dict:
    """
    機能: 基礎全件を検査しC0優先のunionを独立に再構成する。
    引数: fixed/metadata/result(dict)、strict(bool)は自然73場81対照条件。
    返り値: dictは順序付き基礎・集合・場・phase・union。
    """
    assert metadata['success'] and metadata['trial']==144 and result['success'] and result['trial']==133
    sessions=[s['session'] for s in fixed['scenes']]
    assert len(sessions)==len(set(sessions))==73 and sessions==metadata['sessions']==[s['session'] for s in result['scenes']]
    count=fixed['expected_entry_count'];assert count==len(metadata['entries'])==result['source_entry_count']
    entries={(e['session'],e['id']):e for e in metadata['entries']};assert len(entries)==count
    records=[];seen=set();groups={};phase=Counter()
    for f,scene in zip(fixed['scenes'],result['scenes']):
        sid=f['session'];end=f['end']-300;limit=min(f['force_close'],end-3600)
        assert scene['success'] and scene['actual_sha256']==f['raw']['sha256']
        assert scene['quality']==scene['expected_quality']==f['expected_quality'] and scene['stat_before']==scene['stat_after']
        assert (scene['execution_end'],scene['effective_entry_limit'],scene['source_force_close'])==(end,limit,f['force_close'])
        kernel={e['id']:e for e in f['entries']};assert len(kernel)==len(f['entries'])==len(scene['cases'])
        for case in scene['cases']:
            identity=(sid,case['id']);assert identity not in seen;seen.add(identity);m=entries[identity];e=kernel[case['id']];q=e['entry']
            assert m['model'] in ('C0','S0') and case['id'].startswith(m['model']+'/') and m['contract']==f['contract']
            assert type(m['native_side']) is int and type(m['t8_side']) is int and m['native_side'] in (-1,1) and m['t8_side'] in (-1,1)
            assert m['baseline'] is (m['model']=='C0') and (not m['baseline'] or m['t8_side']==m['native_side'])
            assert e['side']==case['original_side']==m['native_side'] and q==m['entry_quote']
            assert q['clock'] and q['quote_ok'] and 0<q['bid']<q['ask'] and f['start']<=q['time']<limit
            for name in ('original','reverse','chart_original','chart_reverse'):
                s=case[name];chart=name.startswith('chart');side=m['native_side'] if name.endswith('original') else -m['native_side']
                assert s['status']=='filled' and s['entry']==q and s['birth']['side']==side
                assert s['entry_price']==(q['last'] if chart else q['ask'] if side>0 else q['bid'])
                phase['stream検査']+=1;phase['entry検査']+=1
                assert [h['seconds'] for h in s['outcomes']]==list(HORIZONS)
                for h in s['outcomes']:
                    assert h['deadline']==q['time']+h['seconds'] and [t['width'] for t in h['touches']]==list(WIDTHS)
                    assert (h['endpoint'] is not None)==(h['status']=='complete')
                    if h['endpoint'] is not None:
                        p=h['endpoint'];assert h['deadline']<=p['time']<=h['deadline']+30 and p['time']<end
                        assert p['quote_ok'] and 0<p['bid']<p['ask'] and p['index']>q['index'] and p['source_line']>q['source_line'];phase['endpoint検査']+=1
                    for t in h['touches']:
                        assert t['direction'] in (-1,0,1) and (t['quote'] is None)==(t['direction']==0)
                        if t['quote'] is not None:
                            p=t['quote'];assert q['time']<=p['time']<=h['deadline'] and p['time']<end
                            assert p['quote_ok'] and 0<p['bid']<p['ask'] and p['index']>q['index'] and p['source_line']>q['source_line'];phase['touch検査']+=1
                    if chart:assert h['net0'] is None and h['net5'] is None
            r={'session':sid,'meta':m,'case':case,'scene':f};records.append(r)
            groups.setdefault(key(sid,m['contract'],q),[]).append(r)
    assert seen==set(entries) and len(records)==count
    members={model:[r for r in records if r['meta']['model']==model] for model in ('C0','S0')}
    if strict:assert len(members['C0'])==81
    for group in groups.values():
        assert len({r['meta']['model'] for r in group})==len(group)
        assert all(r['case']['original']['entry']==group[0]['case']['original']['entry'] for r in group)
    union=[];covered=set();aliases=0;opposites=0
    assert len(metadata['union'])==len(groups)
    for u in metadata['union']:
        identity=key(u['session'],u['contract'],u['entry_stamp']);assert identity not in covered;covered.add(identity);group=groups[identity]
        assert len(u['alias_ids'])==len(set(u['alias_ids'])) and set(u['alias_ids'])=={r['case']['id'] for r in group}
        canonical=next((r for r in group if r['meta']['model']=='C0'),group[0]);assert u['canonical_id']==canonical['case']['id']
        union.append(canonical);aliases+=len(group)-1
        opposites+=sum(r['case']['original_side']!=canonical['case']['original_side'] for r in group)
    assert covered==set(groups);members['U0']=union
    proof={'成功':True,'基礎取得数':count,'C0':len(members['C0']),'S0':len(members['S0']),'U0':len(union),
           '同原行aliasで除いた取得数':aliases,'代表と反対方向のalias数':opposites,'C0優先':True,'方向/成績による選別':False}
    return {'basis':records,'members':members,'sessions':sessions,'phase':dict(phase),'union':proof}


# ----------------------------------------
def policy_rows(rows: list, policy: str) -> tuple:
    """
    機能: 保存t8とnativeから物理側を選び、Root141算術へoriginalとして渡す。
    引数: rows(list)、policy(str)。
    返り値: tupleは(sid,view)列とnative相対反転数。
    """
    views=[];flips=0
    for r in rows:
        m=r['meta'];case=r['case'];side=m['native_side']
        if policy=='T0' or policy=='U0' and m['model']=='S0':side=m['t8_side']
        reverse=side!=m['native_side'];flips+=reverse
        views.append((r['session'],{'original':case['reverse' if reverse else 'original'],'chart_original':case['chart_reverse' if reverse else 'chart_original']}))
    return views,flips


# ----------------------------------------
def fractions_check(cases: list, axis: str, horizon: int, width: int, expected: dict) -> None:
    """
    機能: 清算QuoteからFractionでIFD既知数と費用後利益損失を重ねて確認する。
    引数: cases(list)、axis(str)、horizon/width(int)、expected(dict)。
    返り値: None。Root141の浮動小数算術と別に、77円/追加1000円を導く。
    """
    money=[];known=0
    for _,case in cases:
        stream=case['chart_original' if axis=='Last' else 'original'];h=next(x for x in stream['outcomes'] if x['seconds']==horizon)
        t=next(x for x in h['touches'] if x['width']==width);q=t['quote'] if t['direction'] else h['endpoint'] if h['status']=='complete' else None
        if q is None:continue
        known+=1
        if axis=='BBO':
            side=stream['birth']['side'];mark=q['bid'] if side==1 else q['ask']
            point=side*(Fraction(str(mark))-Fraction(str(stream['entry_price'])))
            money.append(point*100-77-1000)
    assert expected['ifd_known']==known
    if axis=='BBO':
        equal(float(sum(money)) if money else None,expected['ifd_net5_sum'])
        equal(float(sum(v for v in money if v>0)) if money else None,expected['ifd_net5_profit'])
        equal(float(-sum(v for v in money if v<0)) if money else None,expected['ifd_net5_loss'])


# ----------------------------------------
def derive(data: dict, scenes: list, calculator: object) -> dict:
    """
    機能: 作者summaryを受け取らず全300条件と全場参加/加重頻度を再構成する。
    引数: data(dict)、scenes(list)、calculator(object)はRoot141別算術。
    返り値: dictは期待集計/参加/頻度と主結果。
    """
    sessions=data['sessions'];members=data['members'];values={};participation={};frequency={};per_scene={}
    for scene in scenes:
        sid=scene['session'];hours=(scene['end']-300-scene['start'])/3600
        nominal=max(0,min(scene['force_close'],scene['end']-3900)-scene['start'])/3600
        per_scene[sid]={'全時間h':hours,'名目新規可時間h':nominal,'models':{}}
        for name in MODELS:
            count=sum(r['session']==sid for r in members[name])
            per_scene[sid]['models'][name]={'取得数':count,'全時間頻度':count/hours,'名目新規可時間頻度':count/nominal if nominal else None}
    for part,ids in (('all',sessions),('train',sessions[:48]),('validation',sessions[48:])):
        values[part]={};participation[part]={};frequency[part]={}
        for name in MODELS:
            rs=[r for r in members[name] if r['session'] in ids];missing=[sid for sid in ids if not any(r['session']==sid for r in rs)]
            participation[part][name]={'対象場数':len(ids),'取得数':len(rs),'取得場数':len(ids)-len(missing),'未取得場数':len(missing),'未取得場':missing,'全場最低1取得':not missing and bool(ids)}
            total=sum(per_scene[sid]['全時間h'] for sid in ids);nominal=sum(per_scene[sid]['名目新規可時間h'] for sid in ids)
            distribution=[per_scene[sid]['models'][name]['全時間頻度'] for sid in ids]
            frequency[part][name]={'対象場数':len(ids),'取得数':len(rs),'全時間h':total,'名目新規可時間h':nominal,
                '全時間平均件数毎時':len(rs)/total if total else None,'名目新規可時間平均件数毎時':len(rs)/nominal if nominal else None,
                '全時間平均1件毎時以上':len(rs)/total>=1 if total else False,
                '場別頻度分布':{'最小':min(distribution) if distribution else None,'中央値':statistics.median(distribution) if distribution else None,
                    '最大':max(distribution) if distribution else None,'単純平均_主平均ではない':sum(distribution)/len(distribution) if distribution else None,
                    '0取得場数':len(missing),'1件毎時以上場数':sum(v>=1 for v in distribution)}}
        for p in POLICIES:
            rows=[r for r in members[MODEL[p]] if r['session'] in ids];views,flips=policy_rows(rows,p);values[part][p]={}
            for axis in ('BBO','Last'):
                values[part][p][axis]={}
                for h in HORIZONS:
                    values[part][p][axis][str(h)]={}
                    for w in WIDTHS:
                        expected=calculator.calculate(views,False,axis,h,w);expected['flips']=flips
                        fractions_check(views,axis,h,w,expected);values[part][p][axis][str(h)][str(w)]=expected
    frequency['場別']=per_scene
    frequency['定義']='全時間=sum(end-300-start)/3600。名目新規可時間=sum(min(force_close,end-3900)-start)/3600は副評価'
    frequency['各場回数cap']=False;frequency['毎時強制']=False
    return {'集計':values,'参加':participation,'頻度':frequency}


# ----------------------------------------
def check_old(data: dict, values: dict, old: dict, observed: dict) -> dict:
    """
    機能: 旧138のC0だけを使い全81/4stream/60条件を検査する。
    引数: data/values/old/observed(dict)。
    返り値: dictは照合件数。旧P0を新strongの成績へ混ぜない。
    """
    before={}
    for scene in observed['scenes']:
        for case in scene['cases']:
            if case['id'].startswith('C0/'):
                q=case['original']['entry'];k=(scene['session'],q['time'],q['index'],q['source_line']);assert k not in before;before[k]=case
    assert len(before)==len(data['members']['C0'])==81
    for r in data['members']['C0']:
        q=r['case']['original']['entry'];oldcase=before[r['session'],q['time'],q['index'],q['source_line']]
        assert oldcase['original_side']==r['case']['original_side']
        for name in ('original','reverse','chart_original','chart_reverse'):
            for field in ('entry','entry_price','outcomes'):assert oldcase[name][field]==r['case'][name][field]
    checked=0
    for part in ('all','train','validation'):
        for axis in ('BBO','Last'):
            for h in HORIZONS:
                for w in WIDTHS:equal(values[part]['C0'][axis][str(h)][str(w)],old['集計'][part]['C0'][axis][str(h)][str(w)]);checked+=1
    assert checked==60
    return {'旧C0取得':81,'4stream全H幅':3240,'旧金融条件':60}


# ----------------------------------------
def main() -> None:
    """
    機能: Root通知後だけ自然結果を独立再構成し、作者summaryは最後に照合する。
    引数: f1/fixed-input/metadata/result/summaryと各SHA、output、execute-after-notice。
    返り値: None。新自然走査・新学習・旧成果書換はしない。
    """
    parser=argparse.ArgumentParser(description='144の別算術金融検算')
    for name in ('f1','fixed-input','metadata','result','summary'):
        parser.add_argument('--'+name,type=Path,required=True);parser.add_argument('--'+name+'-sha256',required=True)
    parser.add_argument('--output',type=Path,required=True);parser.add_argument('--execute-after-notice',action='store_true');args=parser.parse_args()
    assert args.execute_after_notice and not args.output.exists()
    paths={name:getattr(args,name.replace('-','_')).resolve() for name in ('f1','fixed-input','metadata','result','summary')}
    hashes={name:getattr(args,name.replace('-','_')+'_sha256') for name in paths}
    assert all(len(v)==64 and all(c in '0123456789abcdef' for c in v) for v in hashes.values())
    assert all(sha(p)==hashes[n] for n,p in paths.items())
    frozen=json.loads(paths['f1'].read_bytes());assert frozen['試行']==144
    declared={Path(p).resolve():h for p,h in frozen['ファイル'].items()}
    assert all(declared[paths[n]]==hashes[n] for n in ('fixed-input','metadata'))
    fixed=json.loads(paths['fixed-input'].read_bytes());metadata=json.loads(paths['metadata'].read_bytes());result=json.loads(paths['result'].read_bytes())
    assert metadata['fixed_input_sha256']==result['input_sha256']==hashes['fixed-input']
    data=collect(fixed,metadata,result);expected=derive(data,fixed['scenes'],arithmetic())
    assert sha(OLD_PAIRS)==OLD_PAIR_SHA and sha(OLD_SUMMARY)==OLD_SUMMARY_SHA
    oldcheck=check_old(data,expected['集計'],json.loads(OLD_SUMMARY.read_bytes()),json.loads(OLD_PAIRS.read_bytes()))
    # ----------------------------------------
    # 全期待値ができてから作者の金融出力を開きます。
    summary=json.loads(paths['summary'].read_bytes());assert summary['成功'] and summary['試行']==144 and summary['F1_SHA256']==hashes['f1']
    assert summary['自然結果SHA256']==hashes['result'] and summary['固定入力SHA256']==hashes['fixed-input'] and summary['入口参照SHA256']==hashes['metadata']
    checked=equal(expected['集計'],summary['集計'])
    equal(expected['参加'],summary['参加']);equal(expected['頻度'],summary['頻度']);equal(data['union'],summary['union']);equal(data['phase'],summary['全4streamのphase検査'])
    assert summary['基礎集合の実観測件数']==len(data['basis']) and summary['全場数']==73
    equal({m:len(data['members'][m]) for m in MODELS},summary['取得集合数'])
    assert all(sha(p)==hashes[n] for n,p in paths.items()) and sha(CALCULATOR)==CALCULATOR_SHA
    proof={'成功':True,'試行':144,'比較数':300,'統計leaf数':checked,'全73場/基礎全件/union/C0保護':True,'参加/加重頻度/場別分布':True,
        'IFDFraction照合':True,'phase':data['phase'],'union':data['union'],'旧C0':oldcheck,'主U0':expected['集計']['all']['U0']['BBO']['3600']['125'],
        '作者summaryを開く前に全期待値を算出':True,'144/141AGG/124/138作者算術import':False,
        '別算術':'Root141 calculateのみ＋Fraction清算/独立結合・場頻度','人員独立':False,'担当者は144AGG作者でもある':True,
        '新Raw/価格CSV/学習/追加2場読取':False,'旧成果変更':False,'コードSHA256':sha(Path(__file__)),
        '入力':{str(p):hashes[n] for n,p in paths.items()},'Root141算術SHA256':CALCULATOR_SHA}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with args.output.open('x',encoding='utf-8') as f:json.dump(proof,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps({'成功':True,'確認SHA256':sha(args.output),'比較数':300,'主U0':proof['主U0']},ensure_ascii=False))


if __name__=='__main__':main()
