"""144別算術検算を独自の架空73場だけで確認する。AGGはimportしない。"""
from pathlib import Path
import copy
import importlib.util
import json

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('144別算術人工対象',HERE/'検算する.py')
M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)


def fixture(include: bool) -> tuple:
    """
    機能: 旧C0と新S0・反対aliasを含む架空の73場を作る。
    引数: include(bool)は新S0を含めるか。
    返り値: tupleはfixed/metadata/paired。自然ファイルは使わない。
    """
    fixed={'scenes':[],'expected_entry_count':0};meta={'success':True,'trial':144,'sessions':[],'entries':[],'union':[]}
    result={'success':True,'trial':133,'scenes':[],'source_entry_count':0}
    for i in range(73):
        sid=f'別算術人工{i:02d}';start=1000000+i*100000;end=start+7500;meta['sessions'].append(sid)
        f={'session':sid,'contract':'架空限月','start':start,'end':end,'force_close':end-10,'raw':{'sha256':'b'*64},'expected_quality':{'架空':True},'entries':[]}
        scene={'session':sid,'success':True,'actual_sha256':'b'*64,'quality':{'架空':True},'expected_quality':{'架空':True},'stat_before':{},'stat_after':{},'execution_end':end-300,'effective_entry_limit':end-3900,'source_force_close':end-10,'cases':[]}
        entries=[('C0',1,1)] if i==0 else []
        if include and i==0:entries.append(('S0',-1,1))
        if include and i==1:entries.append(('S0',1,-1))
        for model,side,t8 in entries:
            ident=model+'/'+sid;q={'clock':'架空時計','time':start+100,'index':10,'source_line':100,'last':1000,'bid':995,'ask':1005,'quote_ok':True}
            f['entries'].append({'id':ident,'side':side,'entry':q});case={'id':ident,'original_side':side}
            for name in ('original','reverse','chart_original','chart_reverse'):
                physical=side if name.endswith('original') else -side;chart=name.startswith('chart')
                stream={'status':'filled','birth':{'side':physical},'entry':q,'entry_price':1000 if chart else 1005 if physical==1 else 995,'outcomes':[]}
                for horizon in M.HORIZONS:
                    endpoint={**q,'time':q['time']+horizon,'index':10000,'source_line':20000}
                    direction=1 if i==1 and name.endswith('original') else -1 if i==1 else 0
                    touch={**q,'time':q['time']+1,'index':11,'source_line':101,'last':1150,'bid':1145,'ask':1155}
                    stream['outcomes'].append({'seconds':horizon,'deadline':q['time']+horizon,'status':'complete','endpoint':endpoint,
                        'touches':[{'width':w,'direction':direction,'quote':copy.deepcopy(touch) if direction else None} for w in M.WIDTHS],'net0':None,'net5':None})
                case[name]=stream
            scene['cases'].append(case)
            meta['entries'].append({'id':ident,'session':sid,'contract':f['contract'],'model':model,'native_side':side,'t8_side':t8,'baseline':model=='C0','entry_quote':q})
        if entries:meta['union'].append({'canonical_id':f['entries'][0]['id'],'alias_ids':[e['id'] for e in f['entries']],
            'session':sid,'contract':f['contract'],'entry_stamp':{k:f['entries'][0]['entry'][k] for k in ('time','index','source_line')}})
        fixed['scenes'].append(f);result['scenes'].append(scene)
    fixed['expected_entry_count']=result['source_entry_count']=len(meta['entries'])
    return fixed,meta,result


# ----------------------------------------
def rejected(action: object) -> None:
    """
    機能: 不正な人工条件の拒否を確認する。
    引数: action(callable)。
    返り値: None。
    """
    try:action()
    except AssertionError:return
    raise AssertionError('不正人工を受理しました')


# ----------------------------------------
def main() -> None:
    """
    機能: 別算術の方向選択/全場/費用/未知/重複拒否を人工で検査する。
    引数: なし。
    返り値: None。作者AGG/自然JSON/Raw/CSVを開かない。
    """
    calculator=M.arithmetic();tests=[]
    for include in (False,True):
        fixed,meta,result=fixture(include);data=M.collect(fixed,meta,result,False);values=M.derive(data,fixed['scenes'],calculator)
        if include:
            assert data['union']['U0']==2 and data['union']['同原行aliasで除いた取得数']==1
            assert values['集計']['all']['S0']['BBO']['3600']['125']['forward']==1
            assert values['集計']['all']['T0']['BBO']['3600']['125']['adverse']==1
            assert values['集計']['all']['U0']['BBO']['3600']['125']['adverse']==1
            assert values['集計']['all']['N0']['BBO']['3600']['125']['forward']==1
            assert values['頻度']['all']['U0']['全時間平均件数毎時']==2/146
            tests.append('C0優先反対aliasとS0/T0・unionT8/nativeの別側選択')
        else:
            assert values['参加']['all']['S0']['未取得場数']==73
            assert values['集計']['all']['T0']['BBO']['3600']['125']['ifd_net5_sum'] is None
            M.equal(values['集計']['all']['U0'],values['集計']['all']['C0'])
            tests.append('S0ゼロでも全73場/null/union=C0')
        s=values['集計']['all']['C0']['BBO']['3600']['125'];assert (s['ifd_net0_sum'],s['ifd_net5_sum'])==(-1077,-2077)
        assert values['集計']['all']['C0']['Last']['3600']['125']['ifd_net5_sum'] is None
    tests.append('Fraction清算の往復77円/追加1000円とLast金額null')
    fixed,meta,result=fixture(True)
    bad=copy.deepcopy(meta);bad['union'][0]['canonical_id']=bad['union'][0]['alias_ids'][1]
    rejected(lambda:M.collect(fixed,bad,result,False));tests.append('C0優先違反を拒否')
    bad=copy.deepcopy(meta);bad['entries'][0]['t8_side']=-1
    rejected(lambda:M.collect(fixed,bad,result,False));tests.append('C0方向上書きを拒否')
    bad=copy.deepcopy(result);bad['scenes'][0]['cases'][0]['original']['outcomes'][0]['endpoint']['time']=fixed['scenes'][0]['end']-300
    rejected(lambda:M.collect(fixed,meta,bad,False));tests.append('ザラバ終端endpointを拒否')
    case=copy.deepcopy(result['scenes'][0]['cases'][0]);h=case['original']['outcomes'][1];h['status']='gap_censored';h['endpoint']=None
    expected=calculator.calculate([('人工',{'original':case['original']})],False,'BBO',3600,125)
    assert expected['ifd_unknown']==1 and expected['ifd_net5_sum'] is None
    h['touches'][3]={'width':125,'direction':-1,'quote':{**case['original']['entry'],'time':1100000,'bid':900,'ask':910}}
    expected=calculator.calculate([('人工',{'original':case['original']})],False,'BBO',3600,125)
    M.fractions_check([('人工',{'original':case['original']})],'BBO',3600,125,expected)
    assert expected['complete']==0 and expected['ifd_known']==1 and expected['adverse']==0
    tests.append('H不足の既知touchはIFD既知/主先着分母には混ぜない')
    print(json.dumps({'成功':True,'人工':tests,'群数':len(tests),'作者AGGimport':False,'自然入力読取':False},ensure_ascii=False))


if __name__=='__main__':main()
