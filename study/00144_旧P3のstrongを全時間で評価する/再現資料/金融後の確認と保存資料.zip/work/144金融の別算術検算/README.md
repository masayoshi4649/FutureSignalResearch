# 144の別算術金融検算

144の金融adapter作者と同じ担当が、集計本体と別のコードで行う確認。人員上の独立ではない。144/141集計器・124/138作者算術はimportせず、Rootの141金融別算術 `calculate` を固定SHAで使い、清算はFractionでも照合する。

入力は明示SHA付きのF1/固定入力/metadata/133実正逆結果/作者summary。基礎全件・C0優先union・各側stream・phase・300主要条件・全73場の参加と加重頻度を先に構成し、旧138のC0全81/4stream/60条件も照合する。**作者summaryのJSONは期待値が全部できた後に開く。** 保存Quoteの再計算であり、原板やSourceを再走査しない。

準備中にRootからSource件数と主結果の見出しを受領している。新しい選別規則や閾値を作る検査ではなく、事前に固定された算術と接続の一致を確認するもの。準備は架空73場の人工7群で行い、自然のJSONを開くのはRoot結果完了通知後のCLIだけ。CSV全表・表示はRootの別工程であり、この検算は主要300条件と参加/頻度/C0/phaseの照合である。

```text
python -X utf8 検算する.py
  --f1 PATH --f1-sha256 SHA
  --fixed-input PATH --fixed-input-sha256 SHA
  --metadata PATH --metadata-sha256 SHA
  --result PATH --result-sha256 SHA
  --summary PATH --summary-sha256 SHA
  --output 未作成のJSON --execute-after-notice
```

初回自然照合は300主要数値一致後、頻度JSONの説明用3キー（定義/毎時強制/各場回数cap）が検算側に未定義だったため停止した。初回コード・準備票は `検査器の初回.zip` に残し、説明metadataだけを追補した。数値算術・方向選択・144条件・AGGは変更していない。

自然実行後に確認票と停止指紋を残す。旧Source/固定AGG/旧試行/追加2場は変更しない。
