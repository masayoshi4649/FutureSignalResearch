"""144の出生当時区分を保存実BBOへ結合する。新しいパラメータを探索しない。"""
from collections import Counter
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
FILES = {'metadata': ('work/144旧strongの全成立評価/固定入力/入口参照.json', 'cf7bc8c0324911a46f6f0c948e06255a7319949876118620a4614b7bc3bfcd71'),
 'observed': ('work/144旧strongの全成立評価/固定取得の正逆観測.json', 'b6395b8e123f3b562673a695e35a28023f2419fca7100d8f40b1dfb30070ca32')}
LABELS = ('順行', '逆行', '未到達', 'H不足')
BINS = {'position': ('0以下', '0..0.25', '0.25..0.75', '0.75..1', '1以上', '位置未知/幅非正'),
        'alignment': ('全3尺度が元向き', '全3尺度が反対向き', '全既知だが0を含む', '全既知で符号混在', '一部未知'),
        'momentum': ('双方改善', '双方悪化', '不一致/0', '勢い未知')}


def sha(body: bytes) -> str:
    """
    機能: bytesのSHAを求める。
    引数: body(bytes)。返り値: str。
    """
    return hashlib.sha256(body).hexdigest()


def number(components: dict, key: str) -> float | None:
    """
    機能: Source型のknown=falseを0へ変えず扱う。
    引数: components(dict)、key(str)。返り値: float又はNone。
    """
    item = components.get(key, {'known': False, 'value': 0})
    assert type(item['known']) is bool
    if not item['known']:
        return None
    v = item['value']; assert type(v) in (int, float) and math.isfinite(v)
    return v


def classify(components: dict, side: int) -> dict:
    """
    機能: 保存当時値だけを固定意味区分へ写す。
    引数: components(dict)、side(int)。返り値: dictは区分と診断値。
    """
    low, high, last, atr = (number(components, k) for k in ('prior3_low', 'prior3_high', 'Last', 'ATR5'))
    position = None
    if None not in (low, high, last) and high > low:
        position = (last-low)/(high-low) if side == 1 else (high-last)/(high-low)
    bucket = '位置未知/幅非正' if position is None else '0以下' if position <= 0 else '0..0.25' if position < .25 else '0.25..0.75' if position < .75 else '0.75..1' if position < 1 else '1以上'
    ts = [number(components, f'{m}_T') for m in (5, 15, 30)]
    signed = [None if v is None else side*v for v in ts]
    alignment = ('一部未知' if None in signed else '全3尺度が元向き' if all(v > 0 for v in signed) else
                 '全3尺度が反対向き' if all(v < 0 for v in signed) else '全既知だが0を含む' if 0 in signed else '全既知で符号混在')
    a, b = (number(components, k) for k in ('RSI_delta', 'Hist_delta'))
    a, b = (None if a is None else side*a), (None if b is None else side*b)
    momentum = '勢い未知' if a is None or b is None else '双方改善' if a > 0 and b > 0 else '双方悪化' if a < 0 and b < 0 else '不一致/0'
    ratio = (high-low)/atr if None not in (low, high, atr) and high >= low and atr > 0 else None
    distance = (high-last if side == 1 else last-low)/atr if None not in (low, high, last, atr) and atr > 0 else None
    return {'position': bucket, 'alignment': alignment, 'momentum': momentum,
            'values': {'prior3_low': low, 'prior3_high': high, 'birth_last': last, 'ATR5': atr,
                       'range_position_to_native': position, 'range_width_over_ATR5': ratio,
                       'forward_edge_distance_over_ATR5': distance, 'T_to_native': signed,
                       'RSI_delta_to_native': a, 'Hist_delta_to_native': b}}


def measure(stream: dict) -> dict:
    """
    機能: H60±125主ラベルとtouch優先のC5を独立計算する。
    引数: stream(dict)。返り値: dict。
    """
    h = next(h for h in stream['outcomes'] if h['seconds'] == 3600)
    t = next(t for t in h['touches'] if t['width'] == 125)
    assert t['direction'] in (-1, 0, 1) and (t['quote'] is None) == (t['direction'] == 0)
    complete = h['status'] == 'complete'
    label = 'H不足' if not complete else '順行' if t['direction'] == 1 else '逆行' if t['direction'] == -1 else '未到達'
    q = t['quote'] if t['direction'] else h['endpoint'] if complete else None
    side, entry = stream['birth']['side'], stream['entry_price']
    assert entry == (stream['entry']['ask'] if side == 1 else stream['entry']['bid'])
    money = None if q is None else 100*side*((q['bid'] if side == 1 else q['ask'])-entry)-1077
    return {'label': label, 'IFD_known': q is not None, 'C5': money}


def stats(rows: list, policy: str) -> dict:
    """
    機能: 全件・先着率・完了率・費用利益損失と未知を分ける。
    引数: rows(list)、policy(str)。返り値: dict。
    """
    c = Counter(r[policy]['label'] for r in rows); resolved = c['順行']+c['逆行']; complete = len(rows)-c['H不足']
    money = [r[policy]['C5'] for r in rows if r[policy]['IFD_known']]
    profit, loss = sum(v for v in money if v > 0), -sum(v for v in money if v < 0)
    return {'count': len(rows), **{k: c[k] for k in LABELS}, 'resolved': resolved,
        'resolved_fraction': str(Fraction(c['順行'], resolved)) if resolved else None,
        'resolved_rate': c['順行']/resolved if resolved else None,
        'complete_rate': c['順行']/complete if complete else None,
        'IFD_known': len(money), 'IFD_unknown': len(rows)-len(money),
        'C5_profit': profit, 'C5_loss_absolute': loss, 'C5_net': sum(money)}


def main() -> None:
    """
    機能: 元/native・実逆・T8を全329と固定区分へ集計する。
    引数: なし。返り値: None。新候補を採用しない。
    """
    docs = {}
    for key, (p, expected) in FILES.items():
        b = (ROOT/p).read_bytes(); assert sha(b) == expected; docs[key] = json.loads(b)
    meta, observed = docs['metadata'], docs['observed']
    entries = {e['id']: e for e in meta['entries'] if e['model'] == 'S0'}; assert len(entries) == 329
    sessions = [s['session'] for s in observed['scenes']]; assert sessions == meta['sessions'] and len(sessions) == 73
    rows, seen = [], set()
    for scene in observed['scenes']:
        for case in scene['cases']:
            if case['id'] not in entries:
                continue
            e = entries[case['id']]; assert e['session'] == scene['session'] and len(e['origins']) == 1
            origin = e['origins'][0]; score = origin['score']; side = e['native_side']
            assert case['original_side'] == side == score['side'] and e['t8_side'] in (-1, 1)
            assert case['original']['entry'] == case['reverse']['entry'] == e['entry_quote']
            assert all(score['at'][k] == origin['birthQuote'][k] for k in ('time', 'index', 'source_line', 'last'))
            groups = classify(score['components'], side)
            native, reverse = measure(case['original']), measure(case['reverse'])
            t8 = native if side == e['t8_side'] else reverse
            rows.append({'id': e['id'], 'session': e['session'], 'strong_type': score['strategy'],
                'native_side': side, 't8_side': e['t8_side'], 't8_flip': side != e['t8_side'], **groups,
                'native': native, 'reverse': reverse, 'T8': t8})
            assert e['id'] not in seen; seen.add(e['id'])
    assert seen == set(entries) and len(rows) == 329
    groups = {}
    for key, labels in BINS.items():
        table = []
        for group in labels:
            subset = [r for r in rows if r[key] == group]
            counts = Counter(r['session'] for r in subset)
            table.append({'group': group, 'stats': {p: stats(subset, p) for p in ('native', 'reverse', 'T8')},
                'scene_counts_all73': {s: counts[s] for s in sessions}, 'case_ids': [r['id'] for r in subset]})
        assert sum(t['stats']['native']['count'] for t in table) == 329
        groups[key] = table
    assert all(sha((ROOT/p).read_bytes()) == h for p, h in FILES.values())
    result = {'success': True, 'trial': 144, 'posthoc_after_financial_generation': True,
        'source_labels_used_as_features': False, 'new_threshold_search': False, 'new_candidate_adopted': False,
        'sessions_all73': sessions, 'source_fill_sessions': len({r['session'] for r in rows}),
        'all329': {p: stats(rows, p) for p in ('native', 'reverse', 'T8')},
        'groups': groups, 'details': rows,
        'sources': {k: {'path': p, 'sha256': h} for k, (p, h) in FILES.items()}}
    p = OWN/'固定区分の事後比較.json'; p.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'all329': result['all329'], 'groups': {k: [{'group': t['group'], 'stats': t['stats']} for t in g] for k, g in groups.items()}}, ensure_ascii=True))


if __name__ == '__main__':
    main()
