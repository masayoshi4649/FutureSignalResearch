"""144の固定条件・全513セル・結果文書を保存JSONへ照合する。Root文書を変更しない。"""
from pathlib import Path
from collections import Counter
import gzip
import hashlib
import json
import re

ROOT=Path(__file__).resolve().parents[2]
OWN=Path(__file__).resolve().parent
FORMAL=ROOT/'study/00144_旧P3のstrongを全時間で評価する'
RUN=ROOT/'work/144旧strongの全成立評価'


def sha(path: Path) -> str:
    """
    機能: 対象保存bytesの指紋を求める。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def catalog(text: str) -> list:
    """
    機能: 汎用表の57手法行だけを取り出す。
    引数: text(str)。返り値: list[list[str]]は名称と9尺度を含む行。
    """
    rows=[]
    for line in text.splitlines():
        cells=[c.strip() for c in line.split('|')[1:-1]]
        if len(cells)==11 and re.fullmatch('[A-Z][0-9]{2}',cells[0]):rows.append(cells)
    assert len(rows)==57 and sum(len(r)-2 for r in rows)==513
    return rows


# ----------------------------------------
def main() -> None:
    """
    機能: 事前条件不変と全政策/主分母/前後/初回後続の記載を確認する。
    引数: なし。自然Raw/CSV/追加2場は開かず固定結果JSONだけを使う。
    返り値: None。専有workへ結果文書レビューの証跡を保存する。
    """
    snap=FORMAL/'検査/F0実行前文書.json.gz'
    original=json.loads(gzip.decompress(snap.read_bytes()))
    prior={Path(d['path']).name:d['本文'] for d in original['文書'] if d['path'].startswith('study/00144_')}
    texts={n:(FORMAL/n).read_text(encoding='utf-8') for n in ('README.md','条件.md','設定と結果.md','閲覧資料.md')}
    assert texts['条件.md'].startswith(prior['条件.md'])
    assert catalog(texts['設定と結果.md'])==catalog(prior['設定と結果.md'])
    assert '未実行' not in '\n'.join(texts['設定と結果.md'].splitlines()[:5]),'設定表冒頭の未実行表記が残る'
    summary=RUN/'金融評価/集計.json';diagnosis=RUN/'初回と後続と方向の事後診断.json'
    d=json.loads(summary.read_bytes());g=json.loads(diagnosis.read_bytes())['群']
    assert d['主政策']=='U0' and not d['主評価']['三項目すべて達成']
    values={p:d['集計']['all'][p]['BBO']['3600']['125'] for p in ('U0','N0','S0','T0','C0')}
    for p,s in values.items():
        expected=f"|{p}|{s['entries']} / {s['sessions']}|{s['forward']}/{s['adverse']}/{s['neither']}/{s['censored']}|{s['resolved_rate']:.2%}|{s['ifd_net5_profit']:,}|{s['ifd_net5_loss']:,}|{s['ifd_net5_sum']:+,}|{s['ifd_unknown']}|"
        assert expected in texts['README.md'] and expected in texts['設定と結果.md'],p
    main=values['U0'];r=texts['README.md']
    for x in (f"{main['forward']}/{main['resolved']}＝{main['resolved_rate']:.2%}",
              f"{main['forward']}/{main['complete']}＝{main['complete_rate']:.2%}",
              f"{main['forward']}/{main['entries']}＝{main['forward']/main['entries']:.2%}",
              f"金額既知{main['ifd_known']}/未知{main['ifd_unknown']}",
              f"{main['ifd_net0_sum']:+,}円",f"{d['頻度']['all']['U0']['全時間平均件数毎時']:.5f}件/時"):
        assert x in r,x
    for part,label in (('train','前48場'),('validation','後25場')):
        s=d['集計'][part]['U0']['BBO']['3600']['125']
        assert label in r
        assert f"{s['forward']}順/{s['adverse']}逆/{s['neither']}未到達/{s['censored']}不足＝{s['resolved_rate']:.2%}" in r
        assert f"{s['ifd_net5_sum']:,}".replace('-','−') in r
    for name in ('初回','後続'):
        s=g[name]['固定T8']
        assert f"{s['entries']}取得" in r
        assert f"{s['forward']}順/{s['adverse']}逆/{s['neither']}未到達/{s['censored']}不足＝{s['resolved_rate']:.2%}" in r
        assert f"{s['ifd_net5_sum']:+,}".replace('-','−') in r
    for name in ('旧C0と同原行','旧C0以外'):
        s=g[name]['固定T8'];assert f"{s['entries']}取得" in r and f"{s['resolved_rate']:.2%}" in r
    s=g['全strong']['固定T8の実逆側']
    assert f"{s['forward']}順/{s['adverse']}逆/{s['neither']}未到達/{s['censored']}不足＝{s['resolved_rate']:.2%}" in r
    assert f"{s['ifd_net5_sum']:,}".replace('-','−') in r
    source=json.loads((RUN/'Sourceの出生と取得.json').read_bytes())
    status=Counter(e['status'] for s in source['scenes'] for e in s['events'])
    kinds=Counter(e['strong_type'] for s in source['scenes'] for e in s['events'] if e['status']=='filled')
    flip=sum(e['side']!=e['t8_side'] for s in source['scenes'] for e in s['events'] if e['status']=='filled')
    assert status=={'filled':329,'unfilled_expired':25} and kinds=={'trend':322,'reversal':7} and flip==221
    assert '354出生/329取得/25失効' in r and 'trend322取得/reversal7取得' in r and '221取得を反転' in r
    assert '2026-11-09_Day' in d['参加']['all']['S0']['未取得場']
    assert d['union']['同原行aliasで除いた取得数']==31 and values['U0']['entries']==81+329-31
    assert math_close(d['頻度']['all']['U0']['全時間h'],720+55/60)
    csv=json.loads((RUN/'CSV全セルの独立再読.json').read_bytes())
    # Root既実行証跡の存在と、自分の表の寸法を区別して確認する。
    tables=json.loads((RUN/'金融評価/CSV用の表.json').read_bytes())['tables']
    assert sum(len(row) for t in tables for row in t['rows'])==35911
    assert '35,911' in texts['閲覧資料.md'] and '18,751' in texts['閲覧資料.md']
    for name in ('study/README.md','docs/README.md','docs/議論/README.md'):
        content=(ROOT/name).read_text(encoding='utf-8')
        assert '144：旧strongを全時間へ拡張' in content and '52.48%' in content and '0.52572' in content
    proof={'成功':True,'試行':144,'元条件F0本文prefix同体':True,'汎用表57行513セル全同体':True,
           '全5政策結果表':True,'主の3分母率と費用':True,'前48後25':True,'初回後続と実逆':True,
           'Source件数とunion重複':True,'全場参加/70/頻度別判定':True,'Root3目次':True,
           'モデル/mini10枚/実IFD/利益追尾未検証を実績にしない':True,
           'Rootに指摘済みの修正':'設定と結果冒頭の未実行残り。修正後を確認した。',
           '重大未解決':[],'文書変更':False,'Raw/CSV/追加2場読取':False,
           '文書SHA256':{str(FORMAL/n):sha(FORMAL/n) for n in texts},
           '数値正本SHA256':{str(p):sha(p) for p in (summary,diagnosis,snap,RUN/'CSV全セルの独立再読.json')},
           '自己コードSHA256':sha(Path(__file__)),'編集停止':True}
    p=OWN/'確認.json';assert not p.exists();p.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'SHA256':sha(p)},ensure_ascii=False))


# ----------------------------------------
def math_close(a: float, b: float) -> bool:
    """
    機能: 頻度分母の浮動小数を比較する。
    引数: a/b(float)。返り値: boolは十分小さい誤差内なら真。
    """
    return abs(a-b)<1e-9


if __name__=='__main__':
    main()
