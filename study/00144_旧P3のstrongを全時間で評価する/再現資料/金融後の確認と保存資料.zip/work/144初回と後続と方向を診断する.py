"""144の保存実正逆で、初回と後続・技術型・方向変更を事後診断する。"""
from pathlib import Path
from collections import defaultdict
import hashlib
import importlib.util
import json

ROOT = Path(__file__).resolve().parent.parent
OWN = ROOT/'work/144旧strongの全成立評価'


def sha(path: Path) -> str:
    """
    機能: 保存bytesのSHA256を計算する。
    引数: path(Path)は対象ファイル。
    返り値: strは指紋。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 既生成の取得と実正逆を技術群別に集計し、新採用条件と区別して保存する。
    引数: なし。固定144保存先だけを参照する。
    返り値: None。原板・追加2場・作者金融算術を読まない。
    """
    paths = {'meta': OWN/'固定入力/入口参照.json', 'pairs': OWN/'固定取得の正逆観測.json',
             'calculator': ROOT/'work/141金融集計を独立に確認する.py'}
    fingerprints = {k: sha(p) for k,p in paths.items()}
    spec = importlib.util.spec_from_file_location('独立の保存正逆計算', paths['calculator'])
    calc = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(calc)
    meta = json.loads(paths['meta'].read_bytes())
    pairs = json.loads(paths['pairs'].read_bytes())
    cases = {c['id']: (s['session'],c) for s in pairs['scenes'] for c in s['cases']}
    entries = {e['id']: e for e in meta['entries']}
    assert set(cases) == set(entries)
    aliases = {u['canonical_id']:u['alias_ids'] for u in meta['union']}
    old_stamps = {(e['session'],e['entry_quote']['index'],e['entry_quote']['source_line'])
                  for e in entries.values() if e['model']=='C0'}
    first = {}
    for e in sorted(entries.values(),key=lambda x:(x['entry_quote']['time'],x['entry_quote']['index'])):
        if e['model']=='S0': first.setdefault(e['session'],e['id'])
    groups = defaultdict(list)
    for key,e in entries.items():
        if e['model']!='S0': continue
        origin=e['origins'][0]
        tags=['全strong','初回' if first[e['session']]==key else '後続',
              '技術型/'+origin['variant'], '方向変更' if e['native_side']!=e['t8_side'] else '方向維持',
              '旧C0と同原行' if (e['session'],e['entry_quote']['index'],e['entry_quote']['source_line']) in old_stamps else '旧C0以外']
        tags += [('デイ' if e['session'].endswith('_Day') else 'ナイト')]
        for tag in tags: groups[tag].append(key)
    output = {}
    for tag,keys in groups.items():
        output[tag] = {}
        for name,opposite in (('元方向',False),('固定T8',False),('固定T8の実逆側',True)):
            selected=[]
            for key in keys:
                e=entries[key];sid,case=cases[key]
                reverse = (e['t8_side']!=e['native_side']) if name!='元方向' else False
                if opposite: reverse=not reverse
                view=dict(case)
                for axis in ('','chart_'):
                    view[axis+'original']=case[axis+('reverse' if reverse else 'original')]
                selected.append((sid,view))
            value=calc.calculate(selected,False,'BBO',3600,125)
            value.pop('flips')
            output[tag][name]=value
    assert sum(len(v) for k,v in groups.items() if k in ('初回','後続')) == len(groups['全strong']) == 329
    assert all(sha(p)==fingerprints[k] for k,p in paths.items())
    result={'成功':True,'試行':144,'事後診断':True,'新条件の選定に利用済みではない':True,
            '主評価を変更しない':True,'口座損益ではない':True,'主幅pt':125,'秒':3600,
            'C5': '独立mini1枚、往復77円＋追加1000円',
            '入力':{str(p):fingerprints[k] for k,p in paths.items()},'群':output}
    dest=OWN/'初回と後続と方向の事後診断.json'
    with dest.open('x',encoding='utf-8',newline='\n') as f:
        json.dump(result,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps({'成功':True,'群数':len(groups),'結果SHA256':sha(dest),'群':output},ensure_ascii=False))


if __name__=='__main__': main()
