"""144 Source JSONだけから出生/取得/失効と場別頻度を診断する。金融/原板は読まない。"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import statistics


def sha(body: bytes) -> str:
    """
    機能: bytesのSHA256を求める。
    引数: body(bytes)。返り値: str。
    """
    return hashlib.sha256(body).hexdigest()


def at(quote: dict) -> tuple:
    """
    機能: 保存価格時計/採用順/物理行の比較tupleを返す。
    引数: quote(dict)。返り値: tuple。
    """
    return tuple(quote[k] for k in ('time', 'index', 'source_line'))


def diagnose(source: dict) -> dict:
    """
    機能: 全場全候補を落とさず非金融の因果キー/件数/頻度を集計する。
    引数: source(dict)。返り値: dict。
    """
    assert source['success'] and source['trial'] == 144
    assert not source['financial_labels_used'] and not source['source_positions_used']
    assert len(source['scenes']) == 73
    scenes, details, hours, status, born_types, fill_types = [], [], 0., Counter(), Counter(), Counter()
    seen_ids = set(); first_birth_status = Counter(); born_flip = fill_flip = 0
    for scene in source['scenes']:
        assert scene['success'] and scene['counts'] == scene['quality'] == scene['expected_quality']
        assert scene['actual_sha256'] == scene['raw']['sha256'] and scene['stat_before'] == scene['stat_after']
        assert scene['entry_limit'] == min(scene['force_close'], scene['end']-3900) and scene['execution_end'] == scene['end']-300
        h = (scene['end']-300-scene['start'])/3600; hours += h
        events = scene['events']; assert len(events) == scene['stats'].get('出生', 0)
        keys, entries = set(), set(); local_status, local_born, local_fill = Counter(), Counter(), Counter()
        fills = [e for e in events if e['status'] == 'filled']
        ranks = {e['id']: i+1 for i, e in enumerate(sorted(fills, key=lambda e: at(e['entryQuote'])))}
        previous_terminal = None
        for i, event in enumerate(events):
            q = event['birth']; side = event['side']; changed = side != event['t8_side']
            assert event['id'] not in seen_ids; seen_ids.add(event['id'])
            assert side in (-1, 1) and event['t8_side'] in (-1, 1)
            assert scene['start'] <= q['time'] < scene['entry_limit']
            assert event['expires'] == min(q['time']+30, scene['entry_limit'])
            assert event['consumed_key'] == event['frame5']['id']+'/'+str(side) and event['consumed_key'] not in keys
            keys.add(event['consumed_key'])
            assert event['strong_type'] in ('trend', 'reversal') and event['score']['strategy'] == event['strong_type']
            assert event['score']['side'] == side and event['direction']['source_side'] == side
            assert event['direction']['t8_side'] == event['t8_side'] and event['direction']['selected_side'] == event['t8_side']
            assert not event['direction']['e0_protected']
            for ref in event['refs']:
                assert ref['end'] <= q['time'] and all(a <= b for a, b in zip(at(ref['delivered']), at(q)))
            if previous_terminal is not None:
                assert all(a <= b for a, b in zip(at(previous_terminal), at(q)))
            typ, state = event['strong_type'], event['status']
            assert state in ('filled', 'unfilled_expired', 'force_close', 'eof_unfilled')
            status[state] += 1; local_status[state] += 1; born_types[typ] += 1; local_born[typ] += 1
            born_flip += changed
            if i == 0: first_birth_status[state] += 1
            entry = event['entryQuote']
            if state == 'filled':
                assert entry is not None and entry == event['evaluation'] and entry['quote_ok'] and 0 < entry['bid'] < entry['ask']
                assert q['time']+1 <= entry['time'] < event['expires'] and entry['index'] > q['index'] and entry['source_line'] > q['source_line']
                assert event['entry_price_native'] == (entry['ask'] if side == 1 else entry['bid'])
                assert event['entry_price_t8'] == (entry['ask'] if event['t8_side'] == 1 else entry['bid'])
                assert at(entry) not in entries; entries.add(at(entry)); previous_terminal = entry
                fill_types[typ] += 1; local_fill[typ] += 1; fill_flip += changed
            else:
                assert entry is None and event['entry_price_native'] is None and event['entry_price_t8'] is None
                previous_terminal = event['terminationQuote']
                if state == 'unfilled_expired': assert previous_terminal is not None and previous_terminal['time'] >= event['expires']
                if state == 'force_close': assert previous_terminal is not None and previous_terminal['time'] >= scene['entry_limit']
                if state == 'eof_unfilled': assert i == len(events)-1
            details.append({'session': scene['session'], 'id': event['id'], 'strong_type': typ,
                'status': state, 'birth_rank': i+1, 'fill_rank': ranks.get(event['id']),
                'native_side': side, 't8_side': event['t8_side'], 't8_flip': changed,
                'frame5_id': event['frame5']['id'], 'consumed_key': event['consumed_key'],
                'birth_stamp': dict(zip(('time', 'index', 'source_line'), at(q))),
                'entry_stamp': None if entry is None else dict(zip(('time', 'index', 'source_line'), at(entry))),
                'termination_stamp': None if event['terminationQuote'] is None else dict(zip(('time', 'index', 'source_line'), at(event['terminationQuote']))),
                'expires': event['expires']})
        scenes.append({'session': scene['session'], 'hours': h, 'births': len(events), 'fills': len(fills),
            'first_birth_status': events[0]['status'] if events else None,
            'first_fill_count': int(bool(fills)), 'following_fills': max(0, len(fills)-1),
            'fill_frequency_per_hour': len(fills)/h, 'birth_frequency_per_hour': len(events)/h,
            'status': dict(local_status), 'birth_types': dict(local_born), 'fill_types': dict(local_fill),
            't8_flip_births': sum(e['side'] != e['t8_side'] for e in events),
            't8_flip_fills': sum(e['side'] != e['t8_side'] for e in fills)})
    births, fills = len(details), sum(s['fills'] for s in scenes)
    assert births == source['summary']['出生数'] and fills == source['summary'].get('取得数', 0)
    frequencies = [s['fill_frequency_per_hour'] for s in scenes]
    expired_ages = [d['termination_stamp']['time']-d['birth_stamp']['time'] for d in details if d['status'] == 'unfilled_expired']
    total = {'sessions': 73, 'hours': hours, 'births': births, 'fills': fills, 'status': dict(status),
        'birth_types': dict(born_types), 'fill_types': dict(fill_types), 't8_flip_births': born_flip, 't8_flip_fills': fill_flip,
        'sessions_with_births': sum(s['births'] > 0 for s in scenes), 'sessions_with_fills': sum(s['fills'] > 0 for s in scenes),
        'sessions_without_fills': [s['session'] for s in scenes if not s['fills']],
        'first_birth_status': dict(first_birth_status),
        'first_fills': sum(s['first_fill_count'] for s in scenes), 'following_fills': sum(s['following_fills'] for s in scenes),
        'birth_frequency_per_hour': births/hours, 'fill_frequency_per_hour': fills/hours,
        'scene_fill_frequency_min': min(frequencies), 'scene_fill_frequency_median': statistics.median(frequencies),
        'scene_fill_frequency_max': max(frequencies), 'max_scene_fills': max(s['fills'] for s in scenes),
        'scenes_at_least_one_fill_per_hour': sum(v >= 1 for v in frequencies),
        'C081_plus_all_new_fills_upper_count_before_dedup': fills+81,
        'C081_plus_all_new_fills_upper_frequency_before_dedup': (fills+81)/hours}
    total['expiry_observed_age_seconds'] = {'min': min(expired_ages) if expired_ages else None,
        'median': statistics.median(expired_ages) if expired_ages else None, 'max': max(expired_ages) if expired_ages else None}
    total['first_following_fills'] = {name: {'count': len(items), 't8_flips': sum(d['t8_flip'] for d in items)}
        for name, items in [('first', [d for d in details if d['fill_rank'] == 1]),
                            ('following', [d for d in details if d['fill_rank'] is not None and d['fill_rank'] > 1])]}
    total['day_night'] = {kind: {'sessions': len(items), 'births': sum(s['births'] for s in items),
        'fills': sum(s['fills'] for s in items), 'hours': sum(s['hours'] for s in items)}
        for kind, items in [('Day', [s for s in scenes if s['session'].endswith('_Day')]),
                            ('Night', [s for s in scenes if s['session'].endswith('_Night')])]}
    return {'success': True, 'trial': 144, 'financial_labels_read': False, 'source_only': True,
            'summary': total, 'sessions': scenes, 'details': details}


def main() -> None:
    """
    機能: 固定SourceだけをSHA確認して件数診断を保存する。
    引数: --source/--sha256/--output。返り値: None。
    """
    p = argparse.ArgumentParser(); p.add_argument('--source', type=Path, required=True)
    p.add_argument('--sha256', required=True); p.add_argument('--output', type=Path, required=True); args = p.parse_args()
    assert len(args.sha256) == 64 and not args.output.exists()
    body = args.source.read_bytes(); assert sha(body) == args.sha256
    result = diagnose(json.loads(body)); assert sha(args.source.read_bytes()) == args.sha256
    result['source'] = {'path': str(args.source.resolve()), 'sha256': args.sha256}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(result, f, ensure_ascii=False, indent=2); f.write('\n')
    print(json.dumps(result['summary'], ensure_ascii=True))


if __name__ == '__main__':
    main()
