"""先行保管を引き継ぎ144の観測・金融・CSV・別算術正本を保存する。"""
from pathlib import Path
import gzip
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
FORMAL=next((ROOT/'study').glob('00144_*'))
OWN=ROOT/'work/144旧strongの全成立評価'
CSV=ROOT/'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/144_旧P3strong全成立'


def sha(raw: bytes) -> str:
    """
    機能: 正本bytesの指紋を求める。
    引数: raw(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(raw).hexdigest()


# ----------------------------------------
def preserve(source: Path, destination: Path, compressed: bool=False) -> dict:
    """
    機能: 明示した正本を同体又は一度のgzipとして保存する。
    引数: source/destination(Path)、compressed(bool)。
    返り値: dictは保存/解凍指紋と復元先。
    """
    raw=source.read_bytes();packed=gzip.compress(raw,mtime=0) if compressed else raw
    destination.parent.mkdir(parents=True,exist_ok=True)
    with destination.open('xb') as f:f.write(packed)
    return {'保存元':destination.relative_to(ROOT).as_posix(),'復元先':source.relative_to(ROOT).as_posix(),
        '形式':'gzip' if compressed else '同体','保存bytes':len(packed),'保存SHA256':sha(packed),'解凍bytes':len(raw),'解凍SHA256':sha(raw)}


# ----------------------------------------
def main() -> None:
    """
    機能: 51源先行保管を不変に継承し、金融後の小成果だけ追加する。
    引数: なし。
    返り値: None。正式3MD/旧試行/Source/AGGを変更・再実行しない。
    """
    p=FORMAL/'保管索引.json';before=p.read_bytes();assert sha(before)=='16ee6a39c49fa7a0ed792514e3b248966ede3fb52e15e613c285d0060f564f14'
    m=json.loads(before)
    # 先行時点の索引原文も履歴として小さく保持する。
    (FORMAL/'検査/先行保管の索引.json.gz').write_bytes(gzip.compress(before,mtime=0))
    (FORMAL/'成果物').mkdir(exist_ok=True);(FORMAL/'根拠').mkdir(exist_ok=True)
    m['保存済み正逆観測']=preserve(OWN/'固定取得の正逆観測.json',FORMAL/'成果物/固定取得の正逆観測.json.gz',True)
    assert m['保存済み正逆観測']['解凍SHA256']=='b6395b8e123f3b562673a695e35a28023f2419fca7100d8f40b1dfb30070ca32'
    m['集計正本']=preserve(OWN/'金融評価/集計.json',FORMAL/'成果物/集計.json')
    for source,name in [(OWN/'観測の完了.json','観測の完了.json'),(OWN/'出生の完了.json','出生の完了.json'),
        (OWN/'転送の完了.json','転送の完了.json'),(OWN/'集計の完了.json','集計の完了.json'),
        (OWN/'金融評価/集計完了.json','集計器の完了.json'),(OWN/'CSV全セルの独立再読.json','CSV全セルの独立再読.json'),
        (CSV/'CSVの確認.json','CSV作成の確認.json')]:preserve(source,FORMAL/'検査'/name)
    independent=ROOT/'work/144金融の別算術検算';stopraw=(independent/'停止の確認.json').read_bytes();stop=json.loads(stopraw)
    assert sha(stopraw)=='768128094cc3b38a42dae5eb8fc2201f4cc870f1acd3b7533e0912896a01fdd0' and stop['成功'] and stop['編集停止']
    for name,h in stop['保存対象'].items():assert sha((independent/name).read_bytes())==h
    preserve(independent/'別算術の確認.json',FORMAL/'検査/金融別算術の確認.json')
    preserve(independent/'停止の確認.json',FORMAL/'検査/金融別算術の停止.json')
    m['金融別算術SHA256']=sha((independent/'別算術の確認.json').read_bytes());m['金融別算術停止SHA256']=sha(stopraw)
    m['Root事後診断']=preserve(OWN/'初回と後続と方向の事後診断.json',FORMAL/'根拠/初回と後続と方向の事後診断.json.gz',True)
    assert m['Root事後診断']['解凍SHA256']=='a9db05b42d4802f6958e87f32af621ebd62c1f482ee124dc7e2f1913ad801a4b'
    # ----------------------------------------
    funnel=ROOT/'work/144全成立Sourceの件数診断';proofraw=(funnel/'件数診断の確認.json').read_bytes()
    assert sha(proofraw)=='40278da868a46e2695c51135aa0a8af979d2272c0c31aa9fb97147999792cead'
    proof=json.loads(proofraw);assert proof['成功']
    m['Source件数票']=preserve(funnel/'全73場の出生取得件数.json',FORMAL/'根拠/全73場の出生取得件数.json.gz',True)
    preserve(funnel/'件数診断の確認.json',FORMAL/'検査/Source件数診断の確認.json')
    m['Source件数確認SHA256']=sha(proofraw)
    # ----------------------------------------
    csv=json.loads((OWN/'CSV全セルの独立再読.json').read_bytes());assert csv['成功'] and csv['全データセル比較数']==35911 and csv['数値比較数']==18751
    m['CSV正本']=CSV.relative_to(ROOT).as_posix();m['CSV_SHA256']={Path(t['CSV']['path']).name:t['CSV']['sha256'] for t in csv['表別']}
    for name,h in m['CSV_SHA256'].items():assert sha((CSV/name).read_bytes())==h
    completion=json.loads((OWN/'金融評価/集計完了.json').read_bytes());m['表JSON再現期待SHA256']=completion['表SHA256']
    m['正式README/条件/513セル変更']='Rootが金融後結果を追記。元条件本文/元513セルは不変として最終確認する'
    m['段階']='先行37/54源に観測1gzip・金融・CSV・別算術・事後/Source件数を追加保存。保存観測再集計と最終確認は未完'
    p.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    report={'成功':True,'試行':144,'先行索引SHA256':sha(before),'観測一度gzip':m['保存済み正逆観測'],'金融別算術SHA256':m['金融別算術SHA256'],
        'CSV35911セル18751数値':True,'Source件数と事後診断を区別':True,'正式3MD/Source/AGG/旧成果変更':False,'不足':[],
        '保管索引SHA256':sha(p.read_bytes())}
    p=FORMAL/'検査/金融正本の保管確認.json';p.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'保管確認SHA256':sha(p.read_bytes()),'観測gzipSHA256':m['保存済み正逆観測']['保存SHA256'],'不足':[]},ensure_ascii=False))


if __name__=='__main__':main()
