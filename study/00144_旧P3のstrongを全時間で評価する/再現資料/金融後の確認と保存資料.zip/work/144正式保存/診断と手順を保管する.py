"""停止した144の診断を一度保存し、正式3MDを触らず再現手順へ結ぶ。"""
from pathlib import Path
import json
from 金融正本を保管する import ROOT,FORMAL,OWN,CSV,sha,preserve


def main() -> None:
    """
    機能: Source件数・当時状態・気配幅の根拠と保存観測再現を記録する。
    引数: なし。
    返り値: None。Root正式3MD/Source/条件/政策を変更しない。
    """
    source=ROOT/'work/144当時位置と勢いの事後診断';raw=(source/'診断の確認.json').read_bytes()
    assert sha(raw)=='fe334ac5737eecb6ae5e2723b125dfed2acf704e39d0d82c307c1da32aaccdfb'
    proof=json.loads(raw);assert proof['成功'] and proof['編集停止']
    for name,item in proof['停止対象'].items():assert sha((source/name).read_bytes())==item['sha256']
    preserve(source/'診断の確認.json',FORMAL/'検査/当時位置と勢い診断の確認.json')
    desc=preserve(source/'固定区分の事後比較.json',FORMAL/'根拠/固定区分の事後比較.json.gz',True)
    preserve(source/'区分と先読みの扱い.md',FORMAL/'根拠/区分と先読みの扱い.md')
    body=(source/'当時位置と勢いから見た限界.md').read_text('utf-8').replace('(固定区分の事後比較.json)','(固定区分の事後比較.json.gz)').replace('(事後診断する.py)','(../再現資料/金融後の確認と保存資料.zip)')
    (FORMAL/'根拠/当時位置と勢いから見た限界.md').write_text(body,encoding='utf-8')
    funnel=ROOT/'work/144全成立Sourceの件数診断';fp=json.loads((funnel/'件数診断の確認.json').read_bytes())
    for item in fp['保存資料']:assert sha(Path(item['path']).read_bytes())==item['sha256']
    body=(funnel/'出生取得と偏り.md').read_text('utf-8').replace('(全73場の出生取得件数.json)','(全73場の出生取得件数.json.gz)')
    (FORMAL/'根拠/出生取得と偏り.md').write_text(body,encoding='utf-8')
    spread=preserve(OWN/'気配幅と両側逆行の事後診断.json',FORMAL/'根拠/気配幅と両側逆行の事後診断.json.gz',True)
    preserve(ROOT/'work/144保存観測の再現確認/保存観測からの再現確認.json',FORMAL/'検査/保存観測からの再現確認.json')
    review=ROOT/'work/144結果文書の独立確認';preserve(review/'確認.json',FORMAL/'検査/結果文書の確認.json')
    assert sha((review/'確認.json').read_bytes())=='9afd9b85a607e03a678bd45adaddf4f99559d69696bbe2c04d33742023898c35'
    mpath=FORMAL/'保管索引.json';m=json.loads(mpath.read_bytes());m['当時状態の事後診断']=desc;m['当時状態診断SHA256']=sha(raw)
    m['気配幅の事後診断']=spread;m['保存観測再現SHA256']=sha((FORMAL/'検査/保存観測からの再現確認.json').read_bytes())
    m['Root結果文書確認SHA256']=sha((review/'確認.json').read_bytes())
    mpath.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    # ----------------------------------------
    text='''# 144の保存と再現

2026-11-12。旧P3 strongの全成立Sourceから、元/T8方向と旧81を実BBOで比較した。新しい観測を作る再実行と、保存観測からの金融再集計を分ける。Root更新の正式README/条件/設定はここでは変更せず、元条件本文と版7全513セルを原文へ照合する。

## 固定原文と保存範囲

[F0](検査/F0出生前.json)は37源/SHA `7cba1a02875aaddf34375376ae7df2865bea01263bdaf6814986634491b99a1f`、[F1](検査/F1金融前.json)は54源/SHA `42a57a1037342884c34a1fb71550eb2f2e504e8c66f93c84217cdb5be3da6e0b`。正式3MD等の[F0原文](検査/F0実行前文書.json.gz)/[F1原文](検査/F1実行前文書.json.gz)を結果編集前に退避した。金融後の現正式MDを元F1の入力として検証しない。

[先行復元確認](検査/F0F1全源の復元参照確認.json)は54参照を解決し、保存bytesから51源を同体復元した。残る177MBの122派生入力と2exeは意図して複製していない。2exeは実行時の現物SHAを確認済みで、ここで再ビルド同体や177MB再生成を実施した意味ではない。[122の入力復元](../00122_E0固定条件を全セッションで検証する/再現資料/再現手順.md)と、[保管索引](保管索引.json)のkernel共有源/Go源を参照する。Goは1.24.2 windows/amd64、Pythonは3.14.3。Sourceのgo.modもgo1.24.2を指定し、118規則moduleを相対replaceする。

Source5.9MB/固定入力/入口参照は[inputsの共用gzip](../../inputs/00144_旧P3strongの全成立/)へ各一度保存、[新しい正逆観測](成果物/固定取得の正逆観測.json.gz)11MBも一度gzip保存した。旧138の大観測はC0同体検査だけに共有利用する。原板・177MB派生・実行体・古い指標入力を重複保存しない。元Source/133kernelを新規実行せず金融を復元できる。

## 保存観測だけから全300比較を再現

標準ライブラリのみ。ルートから未作成work宛先を指定する。

```powershell
python -X utf8 "study/00144_旧P3のstrongを全時間で評価する/再現資料/保存観測から再集計する.py" --destination "work/144任意の再現先" --replay
```

51源は正式MDを含め原文へ復元する。元F0/F1・元観測・metadataは不変で、復元先へ向けた金融後の再現専用path台帳だけを新たに作る。これは金融前固定を後造りしたものではない。177MB/2exeは固定参照として明示し、実bytesが復元されたとはしない。

[再現確認](検査/保存観測からの再現確認.json)で、全300条件/参加頻度/union/phase/旧C0が同体、三表JSONも全bytes一致した。集計JSONの相違は再現用F1台帳の指紋だけ。Raw/Source/価格CSV/新しい先着観測を再生しない。--replayなしでは入力/コード復元だけを行う。

## 別算術の金融確認

[金融別算術](検査/金融別算術の確認.json)はRoot141のcalculateのみを固定SHAで使い、144/141AGG・124/138作者関数をimportしない。基礎410・union379・C0優先・全73参加/頻度・phase・旧C0全81/4stream/60条件を再構成し、全300主要統計を一致した。清算はFractionでも検査し、作者summaryは期待値ができた後に開いた。主U0は159順144逆49未27不足、C5利益2,092,293/損失2,331,091/差引−238,798円、IFD既知374/未知5。

担当者はAGG作者と同じであり、人員上の独立とは言わない。Source件数/主結果の見出しを受領後に準備した別実装による確認である。初回は300数値一致後に頻度の説明metadata3キーの欠落で停止し、初回コード/準備票を小ZIPへ残して説明schemaだけを追補した。数値算術・方向・条件は変更していない。[停止票](検査/金融別算術の停止.json)とコードは[金融後の追補ZIP](再現資料/金融後の確認と保存資料.zip)へ保存する。

## 人工・旧保存票・Source件数

Source独立準備19人工/vet/build、橋渡し/APIの人工・準備、旧strong32の保存Decision/Direction票を使うpredicate/T8回帰は、先行の[小資料ZIP](再現資料/144独立準備と保管の小資料.zip)へ保存済み。旧32時刻のSnapshotを新scannerが独立に再構築した主張ではない。F0/F1後に用意した証跡を、金融前の固定源へ後付けしたとも言わない。

[Source件数短報](根拠/出生取得と偏り.md)と[確認](検査/Source件数診断の確認.json)はSourceのみの非金融診断。354出生/329取得/25失効、72/73場、初回72/後続257を保存した。失効が出生後30〜192秒に記録されたのは期限後の最初の採用Rawで取消を記録した時計であり、TTLを延長して取得した意味ではない。全354/全73の[台帳](根拠/全73場の出生取得件数.json.gz)を残す。

## 事後診断の範囲

[初回/後続/方向票](根拠/初回と後続と方向の事後診断.json.gz)はRootの金融後診断。新streamの初回はT8で62.26%、後続は48.13%で、旧32の73.91%を全成立へ外挿できなかった。主政策や取得集合を交換せず記録する。

[当時位置と勢いの短報](根拠/当時位置と勢いから見た限界.md)、[区分](根拠/区分と先読みの扱い.md)、[確認](検査/当時位置と勢い診断の確認.json)と[全329/全73票](根拠/固定区分の事後比較.json.gz)も金融後の事後診断である。群結果前の区分固定と、完全事前の未知期検証を区別する。出生時の直前3端以上181件でも一律実逆は39.04%、T8は45.89%で、位置だけによる反転を採用していない。

[気配幅/両側票](根拠/気配幅と両側逆行の事後診断.json.gz)ではS0の329気配幅は10/20ptのみで、303H完了中の両実側逆行19・両未到達28。異常に広い気配だけを低率の主因としない。Rootの「T8方向の実逆39.41%」と、当時位置診断の「元P3方向の実逆43.91%」は基準方向が違い、同じ比較ではない。

## CSVと文書

[閲覧資料](閲覧資料.md)から300×34/410×49/73×77の三表を参照する。[再読](検査/CSV全セルの独立再読.json)は35,911セル/18,751数値が一致し、Rootが3画像を視認した。[作成証跡](検査/CSV作成の確認.json)と汎用作者v2/readerは保存索引から共有参照する。create/3/csvは今回1回、xlsxは生成していない。ここでCSVを再生成しない。

[結果文書確認](検査/結果文書の確認.json)はRootの最新正式3MDと、原条件prefix/513セル/各政策数値/分母/Source/union/3目次を照合した。未達・不採用、全期既使用、独立mini1枚の入口診断という範囲を保持する。10枚口座・実IFD・必須利益追尾の運用成績とはしない。旧143以前と追加2場は不変更/未読である。
'''
    (FORMAL/'再現手順.md').write_text(text,encoding='utf-8')
    print(json.dumps({'成功':True,'当時状態JSON_SHA256':desc['解凍SHA256'],'気配診断JSON_SHA256':spread['解凍SHA256'],'保存観測再現SHA256':m['保存観測再現SHA256']},ensure_ascii=False))


if __name__=='__main__':main()
