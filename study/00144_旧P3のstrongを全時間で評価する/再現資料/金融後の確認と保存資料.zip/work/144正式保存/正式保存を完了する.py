"""144の金融後小資料を閉じ、原文/51源復元/正本/再現/リンクを確認して停止する。"""
from pathlib import Path
import gzip
import hashlib
import json
import re
import zipfile

ROOT=Path(__file__).resolve().parents[2]
FORMAL=next((ROOT/'study').glob('00144_*'))


def sha(raw: bytes) -> str:
    """
    機能: 保存原文の指紋を求める。
    引数: raw(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(raw).hexdigest()


# ----------------------------------------
def cells(body: str) -> list:
    """
    機能: 57手法9尺度の設定を抽出する。
    引数: body(str)。
    返り値: listはIDと513セル。
    """
    rows=[]
    for line in body.splitlines():
        if re.match(r'^\| [A-Z]+\d{2} \|',line):
            row=[v.strip() for v in line.strip('|').split('|')]
            if len(row)==11:rows.append([row[0],row[2:]])
    assert len(rows)==57 and sum(len(r[1]) for r in rows)==513;return rows


# ----------------------------------------
def main() -> None:
    """
    機能: 既存根拠の範囲だけを検査し、Root正式3MD不変更で保存を完了する。
    引数: なし。
    返り値: None。新Raw/Source/観測/CSV再生成や旧試行変更はしない。
    """
    mpath=FORMAL/'保管索引.json';m=json.loads(mpath.read_bytes())
    original_formal={p:sha(p.read_bytes()) for p in [FORMAL/n for n in ('README.md','条件.md','設定と結果.md')]}
    archive_prior=m['後発の準備小資料'];registry={r['sha256']:r['path'] for r in archive_prior['格納源']}
    files=list((ROOT/'work/144正式保存').glob('*.py'))+list((FORMAL/'再現資料').glob('*.py'))
    files += [ROOT/n for n in ('work/144初回と後続と方向を診断する.py','work/144気配幅と両側逆行を診断する.py',
        'work/144全成立Sourceの件数診断/件数を診断する.py','work/144全成立Sourceの件数診断/出生取得と偏り.md',
        'work/144当時位置と勢いの事後診断/事後診断する.py','work/144当時位置と勢いの事後診断/当時位置と勢いから見た限界.md',
        'work/144結果文書の独立確認/確認する.py')]
    files += [ROOT/item['path'] for item in m.get('集合差の追加小資料',[])]
    independent=ROOT/'work/144金融の別算術検算';stop=json.loads((independent/'停止の確認.json').read_bytes())
    assert stop['成功'] and stop['編集停止']
    for name,h in stop['保存対象'].items():
        p=independent/name;assert sha(p.read_bytes())==h
        if name!='別算術の確認.json':files.append(p)
    items=[];bodies={};reused=[]
    for p in sorted(set(files)):
        raw=p.read_bytes();h=sha(raw);rel=p.relative_to(ROOT).as_posix();assert len(raw)<1000000
        if h in registry:reused.append({'復元先':rel,'ZIP内path':registry[h],'sha256':h,'bytes':len(raw)})
        else:items.append({'path':rel,'sha256':h,'bytes':len(raw),'区分':'F0/F1直接源外の金融後診断/別算術/結果文書/保存再現'});bodies[rel]=raw
    archive=FORMAL/'再現資料/金融後の確認と保存資料.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for r in items:z.writestr(r['path'],bodies[r['path']])
    m['金融後の小資料']={'ZIP':archive.name,'ZIP_SHA256':sha(archive.read_bytes()),'ZIP_bytes':archive.stat().st_size,'格納源数':len(items),'格納源':items,'F0/F1への後付け固定主張':False}
    m['先行小資料共有参照']={'保存元ZIP':(FORMAL/'再現資料'/archive_prior['ZIP']).relative_to(ROOT).as_posix(),'ZIP_SHA256':archive_prior['ZIP_SHA256'],'格納源':reused}
    prior=next((ROOT/'study').glob('00143_*'));pm=json.loads((prior/'保管索引.json').read_bytes());groups=list(pm['後発共有コード'])
    for group in pm['共有固定コード群']:
        selected=[r for r in group['格納源'] if r['sha256']=='30bd4aef8c2809699cb013f930cfbce152f3986fe8d3d3cc6b49452104c2269e']
        if selected:groups.append({**group,'格納源':selected,'格納源数':len(selected)})
    assert sum(r['sha256']=='30bd4aef8c2809699cb013f930cfbce152f3986fe8d3d3cc6b49452104c2269e' for g in groups for r in g['格納源'])==1
    m['金融後の共有コード']=groups
    m['段階']='Source/転送/固定観測/300金融/別算術/CSV/事後診断/保存観測再現を保存。最終参照検査中'
    m['後段で実行した範囲']={'保存金融JSON読取と再集計':True,'新Source/Raw/価格CSV/新観測/新CSV生成/旧143以前変更/追加2場読取':False,
        '別算術は計算実装の独立/人員独立ではない':True,'現正式3MDはRoot結果更新/本保存担当は不変更':True}
    mpath.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    # ----------------------------------------
    for stage in ('F0文書原文','F1文書原文'):
        item=m[stage];raw=(ROOT/item['保存元']).read_bytes();assert sha(raw)==item['保存SHA256']
        snapshot=json.loads(gzip.decompress(raw));assert snapshot['正式文書数']==3
        for d in snapshot['文書']:assert sha(d['本文'].encode('utf-8'))==d['sha256']
        original={Path(d['path']).name:d['本文'] for d in snapshot['文書'] if d['path'].startswith('study/')}
        assert cells(original['設定と結果.md'])==cells((FORMAL/'設定と結果.md').read_text('utf-8'))
        assert (FORMAL/'条件.md').read_bytes().startswith(original['条件.md'].encode('utf-8'))
    assert sha((FORMAL/'検査/F0出生前.json').read_bytes())==m['F0_SHA256']
    assert sha((FORMAL/'検査/F1金融前.json').read_bytes())==m['F1_SHA256']
    for item in (m['追加固定資料'],m['F1増分固定資料'],m['後発の準備小資料'],m['金融後の小資料']):
        zp=FORMAL/'再現資料'/item['ZIP'];assert sha(zp.read_bytes())==item['ZIP_SHA256']
        with zipfile.ZipFile(zp) as z:
            assert z.testzip() is None
            for r in item['格納源']:assert sha(z.read(r['path']))==r['sha256']
    for group in groups:
        zp=ROOT/group['保存元ZIP'];assert sha(zp.read_bytes())==group['ZIP_SHA256']
        with zipfile.ZipFile(zp) as z:
            for r in group['格納源']:assert sha(z.read(r.get('ZIP内path',r.get('path'))))==r['sha256']
    for item in m['新共用入力']+m['F1共有入力']+m['F1追加入力']+[m['保存済み正逆観測'],m['集計正本'],m['Root事後診断'],m['Source件数票'],m['当時状態の事後診断'],m['気配幅の事後診断'],m['旧32と新31の集合差']]:
        raw=(ROOT/item['保存元']).read_bytes();assert sha(raw)==item['保存SHA256']
        decoded=gzip.decompress(raw) if item['形式']=='gzip' else raw;assert sha(decoded)==item['解凍SHA256']
    assert sha((FORMAL/'検査/F0F1全源の復元参照確認.json').read_bytes())==m['F0F1復元参照確認SHA256']
    assert sha((FORMAL/'検査/金融別算術の確認.json').read_bytes())==m['金融別算術SHA256']
    assert sha((FORMAL/'検査/金融別算術の停止.json').read_bytes())==m['金融別算術停止SHA256']
    assert sha((FORMAL/'検査/保存観測からの再現確認.json').read_bytes())==m['保存観測再現SHA256']
    replay=json.loads((FORMAL/'検査/保存観測からの再現確認.json').read_bytes());assert replay['全300/参加頻度/union/phase/旧C0同体'] and replay['三表JSON全bytes同体']
    csv=json.loads((FORMAL/'検査/CSV全セルの独立再読.json').read_bytes());assert csv['全データセル比較数']==35911 and csv['数値比較数']==18751
    for name,h in m['CSV_SHA256'].items():assert sha((ROOT/m['CSV正本']/name).read_bytes())==h
    creator=json.loads((FORMAL/'検査/CSV作成の確認.json').read_bytes());assert len(creator['プレビュー'])==3 and creator['コードSHA256']=='0994706575ed4fc634fe5d0577d48b5b79e95ff0db2330407daf02a74ca478d3'
    for name in creator['プレビュー']:assert (ROOT/m['CSV正本']/name).exists()
    aggregate=json.loads((FORMAL/'成果物/集計.json').read_bytes());primary=aggregate['集計']['all']['U0']['BBO']['3600']['125']
    assert [primary[k] for k in ('entries','forward','adverse','neither','censored','ifd_known','ifd_unknown','ifd_net5_profit','ifd_net5_loss','ifd_net5_sum')]==[379,159,144,49,27,374,5,2092293,2331091,-238798]
    assert aggregate['取得集合数']=={'C0':81,'S0':329,'U0':379}
    assert sha((FORMAL/'検査/結果文書の確認.json').read_bytes())==m['Root結果文書確認SHA256']
    assert sha((FORMAL/'検査/旧32と新31の集合差確認.json').read_bytes())==m['集合差確認SHA256']
    assert all(sha(p.read_bytes())==h for p,h in original_formal.items())
    # ----------------------------------------
    indices=[ROOT/n for n in ('study/README.md','docs/README.md','docs/議論/README.md')];links=0
    for p in list(FORMAL.rglob('*.md'))+[ROOT/m['CSV正本']/'README.md']+indices:
        body=p.read_text('utf-8')
        if p in indices:body=next(x for x in body.split('\n\n') if '[144' in x or '00144_' in x)
        for target in re.findall(r'\]\(([^)]+)\)',body):
            if target.startswith(('https:','http:','#')):continue
            assert (p.parent/target.strip('<>').split('#',1)[0]).resolve().exists(),(p,target);links+=1
    m['段階']='Source/転送/固定観測/300金融/別算術/CSV/事後診断/保存観測再現/正式保存完了。主52.48%で未達・不採用、編集停止'
    mpath.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    proof={'成功':True,'試行':144,'正式保存完了':True,'編集停止':True,'重大不足':[],
        'F0全37/F1全54源原文/正式3MD先退避':True,'54参照解決/保存51源同bytes/177MB2exeは非複製参照':True,
        '元条件prefixと57x9_513セル不変':True,'Root最新正式3MDは結果確認9afd版のまま本保存で不変更':True,
        'Source/固定/metadata各一度gzip/新正逆観測も一度gzip':True,'300別算術/全73/基礎410/union379/phase/旧C0一致':True,
        '別算術は人員独立ではない/説明metadata3キー追補履歴保存':True,'CSV35911セル18751数値再読/Root三画像視認通知':True,
        '保存観測の全300/三表JSONbytes同体再現':True,'pure32は保存票predicate/T8回帰/当時Snapshot新scanner再構築ではない':True,
        'Source件数非金融/Root初回後続/気配/当時状態の事後を分離':True,'主未達不採用/新条件や政策へ交換なし':True,
        '旧32新31の差は同5分キーの失効後再要求でありpredicate差としない':True,
        '旧143以前/追加2場/新Raw/Source再生/新観測/新CSV生成':False,'Root3目次の導線確認':True,'ローカルリンク':links,'主U0':primary,
        '保管索引SHA256':sha(mpath.read_bytes()),'金融後ZIP_SHA256':m['金融後の小資料']['ZIP_SHA256'],
        '金融別算術SHA256':m['金融別算術SHA256'],'保存観測再現SHA256':m['保存観測再現SHA256'],'コードSHA256':sha(Path(__file__).read_bytes())}
    p=FORMAL/'検査/正式保存の最終確認.json';assert not p.exists();p.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'最終確認SHA256':sha(p.read_bytes()),'保管索引SHA256':sha(mpath.read_bytes()),'金融後ZIP_SHA256':m['金融後の小資料']['ZIP_SHA256'],'重大不足':[]},ensure_ascii=False))


if __name__=='__main__':main()
