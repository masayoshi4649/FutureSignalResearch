"""旧strong32と新同原行31の再要求差を、条件変更せず最後の小追補へ残す。"""
from pathlib import Path
import json
from 金融正本を保管する import ROOT,FORMAL,sha,preserve


def main() -> None:
    """
    機能: 停止済み集合差票を1gzip、確認票と短報を恒久保存する。
    引数: なし。
    返り値: None。正式3MD/Source/AGG/旧取得集合は変更しない。
    """
    source=ROOT/'work/144旧Strong32の取得集合差'
    known={'集合差の確認.json':'1c8817cfba5969fb2177997f819ee9e75355dcb928870953268de2afa3739bcc',
        '旧32と新329の取得集合差.json':'fd7e99ee5042bf5962677c11e075f75e5bbe45cc1023f2ba3c63e8c90365628d',
        '欠けた旧1件と出生消費.md':'2355f32cd75359aff188f53aac7772438ba3dedcc7357a4348b863740d38206c',
        '取得集合差を照合する.py':'bc0d9415d9c5bd536c48ae4d0da26e7629574074835e44cdc57e15774e2ce3cd'}
    for name,h in known.items():assert sha((source/name).read_bytes())==h
    preserve(source/'集合差の確認.json',FORMAL/'検査/旧32と新31の集合差確認.json')
    descriptor=preserve(source/'旧32と新329の取得集合差.json',FORMAL/'根拠/旧32と新329の取得集合差.json.gz',True)
    body=(source/'欠けた旧1件と出生消費.md').read_text('utf-8').replace('(旧32と新329の取得集合差.json)','(旧32と新329の取得集合差.json.gz)').replace('(取得集合差を照合する.py)','(../再現資料/金融後の確認と保存資料.zip)').replace('(集合差の確認.json)','(../検査/旧32と新31の集合差確認.json)')
    (FORMAL/'根拠/欠けた旧1件と出生消費.md').write_text(body,encoding='utf-8')
    mpath=FORMAL/'保管索引.json';m=json.loads(mpath.read_bytes());m['旧32と新31の集合差']=descriptor;m['集合差確認SHA256']=known['集合差の確認.json']
    m['集合差の追加小資料']=[{'path':(source/n).relative_to(ROOT).as_posix(),'sha256':known[n]} for n in ('取得集合差を照合する.py','欠けた旧1件と出生消費.md')]
    mpath.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    p=FORMAL/'再現手順.md';text=p.read_text('utf-8')
    text += '''
## 旧32と新同原行31の集合差

[短報](根拠/欠けた旧1件と出生消費.md)・[小票](根拠/旧32と新329の取得集合差.json.gz)・[停止確認](検査/旧32と新31の集合差確認.json)は、10/27ナイトの旧L0/31751だけの差を追跡した。旧新とも19:01:07出生、TTL19:01:37、19:01:42の原行で失効し、先行Decision/Direction/出生Quote/Expires/statusは同体。旧だけが同じ5分ID＋買方向で19:01:42に再要求し19:01:51に取得した。144はborn時のキー消費を保持するため再要求せず、predicate/T8の差ではなく新しい再準備契約による取得集合差だった。旧C0はunionへ保護されている。Raw/Snapshotを新たに再構築した診断ではなく、旧32と新31が完全同じ約定集合だとも主張しない。コードと原短報は金融後の小資料ZIPに保存した。
'''
    p.write_text(text,encoding='utf-8')
    print(json.dumps({'成功':True,'集合差SHA256':descriptor['解凍SHA256'],'確認SHA256':known['集合差の確認.json']},ensure_ascii=False))


if __name__=='__main__':main()
