"""旧32保存票と144の取得集合差を保存Sourceだけで説明する。"""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
FILES = {
    '旧32保存票': ('work/144旧Strong32保存票の回帰/旧Strong32の保存票.json', 'faad4a3d3fbdcd62f0649bca11f35108e851b51f2be84e137d5784ed749c6106'),
    '旧137Source': ('work/137既知回復の評価/Sourceの出生と取得.json', 'd5c2e8e772e1658015d82497760b56ef40d6cae07da40eb8f148f601795628e5'),
    '旧137metadata': ('work/137既知回復の評価/固定入力/方向と出生.json', '86f33705ba40fd3ba1b845557a2368e44c2802635082fc3bad69346770103f93'),
    '新144Source': ('work/144旧strongの全成立評価/Sourceの出生と取得.json', '03b20f5a2181ce2eabae04ca650f235d8a039a9112747a0ea7197a704cc2b73e'),
    '旧133要求処理': ('work/強い入口の探索期限を延ばす次仮説/Source入口の再生器/entry.go', '1c4de9282190e2a3c00c86f8a80ef9568ac329e5c24fe8948e0098fb4058652f'),
    '新144要求処理': ('work/144旧P3strongの全成立/entry.go', 'a9934447a1ab4bf5f12c8b08d6178ca31a664909eb2a3fdcd3ce8fa6029b05ae'),
}


def sha(body: bytes) -> str:
    """
    機能: 保存ファイル又は正規化JSONの指紋を求める。
    引数: body(bytes)。返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


def raw_key(session: str, quote: dict) -> tuple:
    """
    機能: 同原行の場・価格時計・採用順・物理行を表す。
    引数: session(str)、quote(dict)。返り値: tuple。
    """
    return (session, quote['time'], quote['index'], quote['source_line'])


def object_sha(value: dict) -> str:
    """
    機能: 保存技術票の全値同体を小型の指紋で記録する。
    引数: value(dict)。返り値: str。
    """
    return sha(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8'))


def legacy_projection(candidate: dict) -> dict:
    """
    機能: 旧候補の取得契約と当時方向を小さく射影する。
    引数: candidate(dict)。返り値: dict。金融値は扱わない。
    """
    return {
        'id': candidate['birth']['id'], 'policy': candidate['policy'], 'path': candidate['path'],
        'strong_type': candidate['decision']['strategy'], 'native_side': candidate['birth']['side'],
        't8_side': candidate['direction']['t8_side'], 'birth': candidate['birth']['quote'],
        'expires': candidate['expires'], 'status': candidate['status'],
        'evaluation': candidate['evaluation'], 'entryQuote': candidate['entry'],
        'entry_price': candidate['entry_price'], 'refs': candidate['decision']['refs'],
        'score全値SHA256': object_sha(candidate['decision']),
        'direction全値SHA256': object_sha(candidate['direction']),
    }


def main() -> None:
    """
    機能: 旧strong32の同原行重複31と欠落1の要求履歴を検証して保存する。
    引数: なし。返り値: None。新しい出生・価格・損益は生成しない。
    """
    docs, inputs = {}, {}
    for key, (relative, expected) in FILES.items():
        body = (ROOT / relative).read_bytes()
        assert sha(body) == expected
        inputs[key] = {'path': relative, 'sha256': expected, 'bytes': len(body)}
        if relative.endswith('.json'):
            docs[key] = json.loads(body)

    tickets = {x['id']: x for x in docs['旧32保存票']['tickets']}
    old_rows = [x for x in docs['旧137metadata']['entries'] if x['model'] == 'A0' and x['source_id'] in tickets]
    assert len(tickets) == len(old_rows) == 32
    new_source = docs['新144Source']
    new_fills = {(c['session'], *raw_key('', e['entryQuote'])[1:]): e
                 for c in new_source['scenes'] for e in c['events'] if e['status'] == 'filled'}
    assert len(new_fills) == 329
    matched, missing = [], []
    for old in old_rows:
        event = new_fills.get(raw_key(old['session'], old['entryQuote']))
        if event is None:
            missing.append(old)
        else:
            assert old['entryQuote'] == event['entryQuote']
            assert old['source_side'] == event['side'] and old['selected_side'] == event['t8_side']
            matched.append({'session': old['session'], 'old_id': old['source_id'], 'new_id': event['id'],
                            'entry原行': list(raw_key(old['session'], old['entryQuote'])),
                            '元方向同体': True, 'T8方向同体': True, '取得Quote全値同体': True})
    assert len(matched) == 31 and len(missing) == 1

    # ----------------------------------------
    # 失効前後の旧要求と、新bornで消費された同じ5分ID・元方向を照合する。
    old = missing[0]
    ticket = tickets[old['source_id']]
    assert old['session'] == '2026-10-27_Night' and old['source_id'].endswith('/L0/31751')
    old_scene = next(x for x in docs['旧137Source']['scenes'] if x['session'] == old['session'])
    new_scene = next(x for x in new_source['scenes'] if x['session'] == old['session'])
    refs5 = [x for x in ticket['direction']['refs'] if x['width_seconds'] == 300]
    assert len(refs5) == 1
    frame = refs5[0]
    key = f"{frame['id']}/{old['source_side']}"
    consumed = [x for x in new_scene['events'] if x['consumed_key'] == key]
    assert len(consumed) == 1
    new = consumed[0]
    old_candidates = [x for x in old_scene['legacy']['candidates'] if x['policy'] == 'L0']
    early = next(x for x in old_candidates if x['birth']['quote'] == new['birth'])
    retry = next(x for x in old_candidates if x['birth']['id'] == old['source_id'])
    assert early['decision'] == new['score'] and early['direction'] == new['direction']
    assert early['expires'] == new['expires'] == new['birth']['time'] + 30
    assert early['status'] == new['status'] == 'unfilled_expired'
    assert early['entry'] is None and new['entryQuote'] is None
    assert retry['decision'] == ticket['decision'] and retry['direction'] == ticket['direction']
    assert retry['birth'] == old['birth'] and retry['entry'] == old['entryQuote']
    assert new['terminationQuote'] == old['birth']['quote']
    assert new['terminationQuote']['time'] >= new['expires']
    assert retry['birth']['time'] < retry['entry']['time'] < retry['expires']
    assert retry['entry']['time'] - retry['birth']['time'] == 9
    assert next(x for x in retry['decision']['refs'] if x['width_seconds'] == 300) == frame
    assert not any(raw_key(new_scene['session'], x['birth']) == raw_key(old['session'], old['birth']['quote'])
                   for x in new_scene['events'])

    result = {
        '成功': True, '試行': 144, '作業': '旧strong32の取得集合差の保存記録追補',
        '旧保存票数': 32, '同原行重複': 31, '欠落': 1,
        '照合キー': ['session', 'entry.time', 'entry.index', 'entry.source_line'],
        '重複31': matched, '欠落旧候補': legacy_projection(retry),
        '同キー先行旧候補': legacy_projection(early),
        '新144同キー要求': {k: new[k] for k in ('id', 'side', 't8_side', 'birth', 'entryQuote',
            'expires', 'status', 'terminationQuote', 'consumed_key', 'strong_type', 'frame5')},
        '先行要求の全値一致': {'score': True, 'direction': True, 'birthQuote': True, 'expires': True, 'status': True},
        '旧再要求までの同一5分参照': frame,
        '新144同場stats': new_scene['stats'],
        '原因': '旧L0は失効後も未取得のため同じ5分ID・元sideを再要求。144は最初のbornで消費したキーを失効後も保持する。',
        '限界': '保存記録と固定コードの契約からの集合差説明。全32Snapshot又は中間Raw/正常BBO列を再構築していない。',
        '原板再読': False, '新金融参照': False, '新条件採用': False, '入力': inputs,
    }
    assert all(sha((ROOT / p).read_bytes()) == h for p, h in FILES.values())
    out = HERE / '旧32と新329の取得集合差.json'
    with out.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
        f.write('\n')
    print(json.dumps({'success': True, 'matched': 31, 'missing': old['source_id'], 'sha256': sha(out.read_bytes())}, ensure_ascii=True))


if __name__ == '__main__':
    main()
