"""144取得の気配幅と、保存実正逆の両側逆行を事後診断する。"""
from pathlib import Path
from collections import Counter,defaultdict
import hashlib
import json

ROOT=Path(__file__).resolve().parent.parent
OWN=ROOT/'work/144旧strongの全成立評価'


def main() -> None:
    """
    機能: 同取得の実BBO両側を比較し、費用前の気配幅と失敗の関係を数える。
    引数: なし。144固定入口と保存正逆だけを参照する。
    返り値: None。新しいフィルタを選定せず、原板を再走査しない。
    """
    paths=[OWN/'固定入力/入口参照.json',OWN/'固定取得の正逆観測.json',Path(__file__).resolve()]
    fingerprints={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    meta,pairs=[json.loads(p.read_bytes()) for p in paths[:2]]
    entries={e['id']:e for e in meta['entries']}
    result={}
    for model in ('S0','C0'):
        bins=defaultdict(Counter);spreads=[];counts=Counter();rows=[]
        for scene in pairs['scenes']:
            for c in scene['cases']:
                e=entries[c['id']]
                if e['model']!=model:continue
                q=e['entry_quote'];spread=q['ask']-q['bid'];spreads.append(spread)
                band='10pt以下' if spread<=10 else '10超20pt以下' if spread<=20 else '20超50pt以下' if spread<=50 else '50超125pt未満' if spread<125 else '125pt以上'
                outcomes=[next(o for o in c[n]['outcomes'] if o['seconds']==3600) for n in ('original','reverse')]
                bins[band]['全取得']+=1
                if all(o['status']=='complete' for o in outcomes):
                    hits=tuple(next(t for t in o['touches'] if t['width']==125)['direction'] for o in outcomes)
                    counts[str(hits)]+=1;bins[band][str(hits)]+=1
                else:bins[band]['H不足']+=1;hits=None
                rows.append({'id':c['id'],'session':scene['session'],'spread':spread,'両側先着':hits})
        spreads.sort()
        result[model]={'全取得':len(spreads),'気配幅最小':spreads[0],'中央値':spreads[len(spreads)//2],
                       '95%点':spreads[int((len(spreads)-1)*.95)],'最大':spreads[-1],
                       '両側順逆組':dict(counts),'気配幅区分':{k:dict(v) for k,v in bins.items()},'取得票':rows}
    value={'成功':True,'試行':144,'事後診断':True,'新しい気配幅フィルタ未採用':True,
           '入力':fingerprints,'H秒':3600,'同幅pt':125,'元と実逆側の両側':result}
    assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in fingerprints.items())
    dest=OWN/'気配幅と両側逆行の事後診断.json'
    with dest.open('x',encoding='utf-8',newline='\n') as f:
        json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps({m:{k:v for k,v in r.items() if k!='取得票'} for m,r in result.items()},ensure_ascii=False))


if __name__=='__main__':main()
