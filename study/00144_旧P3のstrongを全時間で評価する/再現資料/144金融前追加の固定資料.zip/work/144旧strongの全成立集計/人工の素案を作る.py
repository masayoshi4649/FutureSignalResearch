"""旧141の人工fixtureを別ファイルの144素案へ適応する。"""
from pathlib import Path


def main() -> None:
    """
    機能: 144の政策名とT8列だけを人工fixtureへ反映する。
    引数: なし。
    返り値: None。旧人工源を変更せず、自然入力を開かない。
    """
    here=Path(__file__).resolve().parent;source=here.parent/'141独立入口とunionの集計/人工検査.py';before=source.read_bytes()
    text=before.decode().replace('141','144').replace('V0','S0').replace('v0','s0').replace('RV','T0').replace('RU','N0')
    text=text.replace('[34,48,77]','[34,49,77]')
    text=text.replace("'native_side':side,'entry_quote':q","'native_side':side,'t8_side':-side if model=='S0' else side,'entry_quote':q")
    text=text.replace("detail['C0/旧1']['N0方向']==-1","detail['C0/旧1']['N0方向']==1")
    target=here/'人工検査.py';assert not target.exists();target.write_text(text,encoding='utf-8');assert source.read_bytes()==before


if __name__=='__main__':main()
