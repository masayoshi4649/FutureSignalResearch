"""144集計器を価格ファイルなしの73場人工fixtureだけで検査する。"""
from pathlib import Path
import copy
import importlib.util
import json

HERE=Path(__file__).resolve().parent
S=importlib.util.spec_from_file_location('144人工対象',HERE/'集計する.py')
M=importlib.util.module_from_spec(S);S.loader.exec_module(M)


def fixture(s0: bool=True) -> tuple:
    """
    機能: 原板を持たない73場・少数取得・異方向aliasの完全人工資料を作る。
    引数: s0(bool)は新取得を含めるか。
    返り値: tuple[dict,dict,dict]は133形観測/固定入力/metadata。
    """
    fixed={'expected_entry_count':0,'scenes':[]};result={'success':True,'trial':133,'source_entry_count':0,'scenes':[]}
    meta={'success':True,'trial':144,'sessions':[],'entries':[],'union':[]}
    for i in range(73):
        sid=f'人工{i:02d}';start=1_000_000+i*100_000;meta['sessions'].append(sid)
        f={'session':sid,'contract':'人工限月','start':start,'end':start+7500,'force_close':start+7400,'raw':{'sha256':'a'*64},'expected_quality':{'人工':True},'entries':[]}
        r={'session':sid,'success':True,'actual_sha256':'a'*64,'quality':{'人工':True},'expected_quality':{'人工':True},
            'stat_before':{'bytes':0},'stat_after':{'bytes':0},'execution_end':start+7200,'effective_entry_limit':start+3600,'source_force_close':start+7400,'cases':[]}
        models=[('C0','旧1',1)] if i==0 else []
        if s0 and i==0:models.append(('S0','同原行の逆向き',-1))
        if s0 and i==1:models.append(('S0','別場の新1',1))
        for model,name,side in models:
            eid=model+'/'+name;q={'clock':'人工価格時計','time':start+100,'index':10,'source_line':100,'last':1000,'bid':995,'ask':1005,'quote_ok':True}
            f['entries'].append({'id':eid,'side':side,'entry':q});case={'id':eid,'original_side':side}
            for key in ('original','reverse','chart_original','chart_reverse'):
                chart=key.startswith('chart');s=side if key.endswith('original') else -side
                stream={'status':'filled','entry':q,'birth':{'side':s},'entry_price':q['last'] if chart else q['ask'] if s>0 else q['bid'],'outcomes':[]}
                for h in M.HORIZONS:
                    endpoint={**q,'time':q['time']+h,'index':100+h,'source_line':1000+h}
                    stream['outcomes'].append({'seconds':h,'deadline':q['time']+h,'status':'complete','endpoint':endpoint,
                        'touches':[{'width':w,'direction':0,'quote':None} for w in M.WIDTHS],'net0':None,'net5':None})
                case[key]=stream
            r['cases'].append(case);meta['entries'].append({'id':eid,'session':sid,'contract':f['contract'],'model':model,'candidate_id':name,
                'native_side':side,'t8_side':-side if model=='S0' else side,'entry_quote':q,'baseline':model=='C0','origins':[{'family':model}]})
        if models:
            meta['union'].append({'canonical_id':f['entries'][0]['id'],'alias_ids':[x['id'] for x in f['entries']],
                'session':sid,'contract':f['contract'],'entry_stamp':{k:f['entries'][0]['entry'][k] for k in ('time','index','source_line')}})
        fixed['scenes'].append(f);result['scenes'].append(r)
    n=len(meta['entries']);fixed['expected_entry_count']=result['source_entry_count']=n
    return result,fixed,meta


# ----------------------------------------
def rejected(action: object) -> None:
    """
    機能: 不正な人工資料がAssertionErrorで拒否されるか確認する。
    引数: action(callable[[],object])。
    返り値: None。拒否されなければ検査失敗。
    """
    try:action()
    except AssertionError:return
    raise AssertionError('不正fixtureを受け入れました')


# ----------------------------------------
def main() -> None:
    """
    機能: 可変/空S0・原行dedup・null・費用・独立正逆・phaseの人工群を実行する。
    引数: なし。
    返り値: None。自然金融/Raw/CSV/追加2場は読まない。
    """
    arithmetic=M.load_arithmetic();tests=[]
    for has_s0 in (False,True):
        result,fixed,meta=fixture(has_s0);basis,rows,sessions,phase,union=M.prepare(result,fixed,meta,False)
        values,part,freq,goal=M.calculate(rows,sessions,fixed['scenes'],arithmetic)
        tables=M.tables(basis,rows,sessions,values,part,freq,arithmetic)
        assert len(tables[0]['rows'])==300 and len(tables[1]['rows'])==len(basis) and len(tables[2]['rows'])==73
        assert freq['all']['C0']['全時間h']==146 and part['all']['C0']['未取得場数']==72
        if not has_s0:
            assert union['S0']==0 and union['C0']==union['U0']==1
            assert part['all']['S0']['未取得場数']==73 and freq['all']['S0']['全時間平均件数毎時']==0
            assert values['all']['S0']['BBO']['3600']['125']['resolved_rate'] is None
            assert values['all']['T0']['BBO']['3600']['125']['ifd_net5_sum'] is None
            assert values['all']['C0']['BBO']['3600']['125']==values['all']['U0']['BBO']['3600']['125']
            tests.append('S0ゼロでも全73場/300比較/null/union=C0')
        else:
            assert union['C0']==1 and union['S0']==2 and union['U0']==2 and union['同原行aliasで除いた取得数']==1
            assert union['代表と反対方向のalias数']==1 and freq['all']['U0']['全時間平均件数毎時']==2/146
            detail={row[4]:dict(zip(tables[1]['headers'],row)) for row in tables[1]['rows']}
            assert detail['C0/旧1']['U0方向']==1 and detail['C0/旧1']['N0方向']==1
            assert detail['S0/同原行の逆向き']['S0方向']==-1 and detail['S0/同原行の逆向き']['U0方向'] is None
            assert detail['S0/同原行の逆向き']['T0方向']==1
            assert detail['S0/別場の新1']['S0方向']==1 and detail['S0/別場の新1']['T0方向']==-1
            assert detail['S0/別場の新1']['U0方向']==-1 and detail['S0/別場の新1']['N0方向']==1
            assert detail['S0/別場の新1']['保存T8方向']==-1 and detail['C0/旧1']['保存T8方向']==1
            tests.append('異方向aliasを保存しC0優先/別場の原行を誤結合しない')
        s=values['all']['C0']['BBO']['3600']['125'];assert s['ifd_known']==1 and s['ifd_net0_sum']==-1077 and s['ifd_net5_sum']==-2077
        assert values['all']['C0']['Last']['3600']['125']['ifd_net5_sum'] is None
    tests.append('元124算術の往復77/1077円とLast金額null')
    # ----------------------------------------
    result,fixed,meta=fixture(True)
    bad=copy.deepcopy(meta);bad['union'][0]['canonical_id']='S0/同原行の逆向き'
    rejected(lambda:M.prepare(result,fixed,bad,False));tests.append('C0優先違反を拒否')
    bad=copy.deepcopy(meta);bad['union'][0]['alias_ids']=['C0/旧1']
    rejected(lambda:M.prepare(result,fixed,bad,False));tests.append('alias欠落を拒否')
    bad=copy.deepcopy(meta);bad['entries'][0]['t8_side']=-1
    rejected(lambda:M.prepare(result,fixed,bad,False));tests.append('C0のt8方向上書きを拒否')
    bad=copy.deepcopy(meta);bad['entries'][1]['t8_side']=0
    rejected(lambda:M.prepare(result,fixed,bad,False));tests.append('T8方向0を拒否')
    rr,ff,mm=copy.deepcopy((result,fixed,meta))
    duplicate=copy.deepcopy(rr['scenes'][0]['cases'][1]);duplicate['id']='S0/重複'
    rr['scenes'][0]['cases'].append(duplicate);e=copy.deepcopy(ff['scenes'][0]['entries'][1]);e['id']='S0/重複';ff['scenes'][0]['entries'].append(e)
    m=copy.deepcopy(mm['entries'][1]);m['id']='S0/重複';mm['entries'].append(m);ff['expected_entry_count']+=1;rr['source_entry_count']+=1
    rejected(lambda:M.prepare(rr,ff,mm,False));tests.append('同一基礎集合内の同原行重複を拒否')
    rr=copy.deepcopy(result);rr['scenes'][0]['cases'][0]['original']['outcomes'][0]['endpoint']['time']=fixed['scenes'][0]['end']-300
    rejected(lambda:M.prepare(rr,fixed,meta,False));tests.append('ザラバ終端endpointを拒否')
    # ----------------------------------------
    q={'time':1,'index':1,'source_line':1,'last':1050,'bid':900,'ask':1200,'quote_ok':True}
    out={'status':'complete','endpoint':{'time':2,'last':1050,'bid':1000,'ask':1100},'touches':[{'width':125,'direction':-1,'quote':{'time':2,'last':1050,'bid':1000,'ask':1100}}]}
    buy={'birth':{'side':1},'entry_price':1200};sell={'birth':{'side':-1},'entry_price':900}
    assert arithmetic.ifd(buy,out,125,'BBO')['net5']==arithmetic.ifd(sell,out,125,'BBO')['net5']==-21077
    tests.append('同取得実BBOで両側損失を許し反転を1-pにしない')
    unknown={**out,'status':'gap_censored','endpoint':None,'touches':[{'width':125,'direction':0,'quote':None}]}
    assert arithmetic.ifd(buy,unknown,125,'BBO')['known'] is False
    known={**unknown,'touches':out['touches']};assert arithmetic.ifd(buy,known,125,'BBO')['known'] is True
    tests.append('H不足でも既知touchを優先/未到達不足は金額未知')
    # ----------------------------------------
    rr,ff,mm=fixture(True);case=rr['scenes'][1]['cases'][0];entry=case['original']['entry']
    touchquote={**entry,'time':entry['time']+1,'index':entry['index']+1,'source_line':entry['source_line']+1,'last':1150,'bid':1145,'ask':1155}
    for name in ('original','reverse','chart_original','chart_reverse'):
        direction=1 if name.endswith('original') else -1
        for outcome in case[name]['outcomes']:
            outcome['touches']=[{'width':w,'direction':direction,'quote':copy.deepcopy(touchquote)} for w in M.WIDTHS]
    b,r,s,_,u=M.prepare(rr,ff,mm,False);v,p,f,g=M.calculate(r,s,ff['scenes'],arithmetic)
    assert v['all']['S0']['BBO']['3600']['125']['forward']==1
    assert v['all']['T0']['BBO']['3600']['125']['adverse']==1
    assert v['all']['U0']['BBO']['3600']['125']['adverse']==1
    assert v['all']['N0']['BBO']['3600']['125']['forward']==1
    assert M.selected(next(x for x in r if x['model']=='S0' and x['session']==s[1]),'T0','BBO') is case['reverse']
    tests.append('S0/T0とU0/N0の同取得別方向を保存実streamで選択')
    # ----------------------------------------
    control=[];oldpairs={'scenes':[]}
    for i in range(81):
        c=copy.deepcopy(result['scenes'][0]['cases'][0]);sid=f'対照人工{i:02d}';c['id']=f'C0/人工対照{i}'
        control.append({'model':'C0','session':sid,'case':c})
        oldpairs['scenes'].append({'session':sid,'cases':[copy.deepcopy(c)]})
    oldvalues={part:{'C0':{a:{str(h):{str(w):{'flips':0,'人工同体':81} for w in M.WIDTHS} for h in M.HORIZONS} for a in M.AXES}} for part in ('all','train','validation')}
    proof=M.baseline_check(control,oldvalues,{'集計':copy.deepcopy(oldvalues)},oldpairs)
    assert proof['旧138C0全81']==81 and proof['旧60条件同体']==60
    bad=copy.deepcopy(oldpairs);bad['scenes'][0]['cases'][0]['reverse']['entry_price']+=5
    rejected(lambda:M.baseline_check(control,oldvalues,{'集計':copy.deepcopy(oldvalues)},bad))
    tests.append('旧C0全81/4stream/60条件の同体と逆側取得価格の改変拒否')
    print(json.dumps({'成功':True,'人工群':len(tests),'人工':tests,'自然価格/金融読取':False,'全表列数':[34,49,77]},ensure_ascii=False))


if __name__=='__main__':main()
