"""144の旧strong全成立・固定T8・旧81・unionを保存133正逆観測から集計する。"""
from pathlib import Path
from collections import Counter
import argparse
import copy
import hashlib
import importlib.util
import json
import math

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
BASE=ROOT/'work/138全成立入口と頻度の集計/集計する.py'
ARITHMETIC=ROOT/'work/124入口の原因分析/集計する.py'
OLD_BASELINE=ROOT/'work/138全成立入口と頻度の集計/集計.json'
OLD_PAIRS=ROOT/'work/138全成立入口の評価/固定取得の正逆観測.json'
SPECIFICATION=ROOT/'work/144_旧P3strongを全成立へ広げる採用仕様.md'
SOURCES={BASE:'e8671638600dc4b23ef9256ba5be535f20c6f8e1d5097457a56fbea9fb30c1f1',
    ARITHMETIC:'8479ca348231ffd77a637360797750833c9e6617c7fc4a6502e015c7a1d9f04a',
    OLD_BASELINE:'6ef283db667603884b42260affce732ba5c9b31731d24b1bb18f9e96ee4b3486',
    OLD_PAIRS:'d272fc6f6768342ff67e1a9ec58b0b7307a0a5b07cc215ba5ff7bcb50865b742'}
POLICIES=('C0','S0','T0','U0','N0')
MODELS=('C0','S0','U0')
MODEL={'C0':'C0','S0':'S0','U0':'U0','T0':'S0','N0':'U0'}
AXES=('BBO','Last');HORIZONS=(1800,3600);WIDTHS=(25,50,100,125,200)
COMPARISON_HEADERS=['試行','区分','政策','取得集合','価格軸','評価分','同幅pt','対象場数','取得場数','取得数',
    'native向きからの反転数','全場最低1取得','全H完了','観測不足','順行先着','逆行先着','両方未到達',
    '到達済み順行率','完了分母順行率','全取得分母順行率','到達済み70%達成','参加と70%両達成',
    '全時間平均件数毎時','名目新規可時間平均件数毎時','全時間平均1件毎時以上','参加と70%と頻度すべて達成',
    'IFD代用既知','IFD代用未知','C0代用差引円','C5代用利益円','C5代用損失絶対円','C5代用差引円','C5代用平均円','C5代用PF']
DETAIL_HEADERS=['試行','参考区分','セッション','基礎集合','固定取得ID','候補ID','native方向','保存T8方向','固定対照由来',
    'union採用','union代表ID','alias取得ID','origin数','origin系統','取得JST','元取得価格','逆取得価格','H60新規限界JST','原板SHA256']
for _p in POLICIES:DETAIL_HEADERS += [_p+s for s in ('方向','125全H','125先着','IFD既知','清算','125C5代用円')]
SCENE_HEADERS=['試行','セッション','参考区分','ザラバ時間h','名目新規可時間h']
for _s in ('取得数','最低1取得','全時間頻度','名目新規可時間頻度'):SCENE_HEADERS += [m+_s for m in MODELS]
for _p in POLICIES:SCENE_HEADERS += [_p+s for s in ('反転数','125順','125逆','125未到達','全H不足','IFD既知','IFD未知','C5利益円','C5損失絶対円','C5既知差引円','C5既知累計円_口座収支ではない','累計IFD未知')]


def sha(path: Path) -> str:
    """
    機能: 明示ファイルの指紋を求める。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def module(path: Path,name: str) -> object:
    """
    機能: 旧源を変更しない私有importを行う。
    引数: path(Path)、name(str)。
    返り値: objectはモジュール。import時に自然JSONを開かない部品だけを使う。
    """
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m


# ----------------------------------------
def selected(record: dict,policy: str,axis: str) -> dict:
    """
    機能: 保存native/T8とC0保護から対応する実BBO/Last側を選ぶ。
    引数: record(dict)、policy/axis(str)。
    返り値: dictは保存stream。率の補数から反転を作らない。
    """
    assert policy in POLICIES and axis in AXES and record['model']==MODEL[policy]
    native=record['case']['original_side'];meta=record['meta']
    side=meta['t8_side'] if policy=='T0' or policy=='U0' and not meta['baseline'] else native
    assert type(side) is int and side in (-1,1)
    return record['case'][('chart_' if axis=='Last' else '')+('original' if side==native else 'reverse')]


# ----------------------------------------
def subset(rows: list[dict],policy: str,ids: list[str]) -> list[dict]:
    """
    機能: 集合と場を選ぶ。
    引数: rows(list[dict])、policy(str)、ids(list[str])。
    返り値: list[dict]は当該政策の取得。0取得場は場一覧から落とさない。
    """
    return [r for r in rows if r['model']==MODEL[policy] and r['session'] in ids]


# ----------------------------------------
def load_arithmetic() -> object:
    """
    機能: 凍結124算術の選択関数だけを私有144向けへ設定する。
    引数: なし。
    返り値: objectは元式のstats/ifd等。旧ファイルを変更しない。
    """
    assert sha(ARITHMETIC)==SOURCES[ARITHMETIC]
    m=module(ARITHMETIC,'144私有124算術');m.selected=selected;m.POLICIES=POLICIES;return m


# ----------------------------------------
def union_key(session: str,contract: str,quote: dict) -> tuple:
    """
    機能: 方向や成績を含まない同取得原行キーを作る。
    引数: session/contract(str)、quote(dict)。
    返り値: tupleは場/限月/価格時計/採用Index/物理行。
    """
    return session,contract,quote['time'],quote['index'],quote['source_line']


# ----------------------------------------
def prepare(result: dict,fixed: dict,metadata: dict,strict: bool=True) -> tuple:
    """
    機能: 可変基礎取得を133観測へ結合し、union/C0優先/全phaseを検査する。
    引数: result/fixed/metadata(dict)、strict(bool)は自然73場81対照の検査指定。
    返り値: tupleは基礎行、3集合参照行、場順、phase票、union票。
    """
    assert result['success'] and result['trial']==133 and metadata['success'] and metadata['trial']==144
    count=fixed['expected_entry_count'];assert result['source_entry_count']==count==len(metadata['entries'])
    mmap={(m['session'],m['id']):m for m in metadata['entries']};assert len(mmap)==count
    assert len(result['scenes'])==len(fixed['scenes'])
    basis=[];sessions=[];seen=set();phase=Counter();groups={}
    for scene,f in zip(result['scenes'],fixed['scenes']):
        sid=scene['session'];sessions.append(sid);assert sid==f['session'] and scene['success']
        assert scene['actual_sha256']==f['raw']['sha256'] and scene['quality']==scene['expected_quality']==f['expected_quality']
        assert scene['stat_before']==scene['stat_after']
        end=f['end']-300;limit=min(f['force_close'],end-3600)
        assert scene['execution_end']==end and scene['effective_entry_limit']==limit and scene['source_force_close']==f['force_close']
        entries={e['id']:e for e in f['entries']};assert len(entries)==len(f['entries'])==len(scene['cases'])
        for case in scene['cases']:
            key=sid,case['id'];assert key in mmap and key not in seen;seen.add(key);m=mmap[key];e=entries[case['id']];q=e['entry']
            assert m['model'] in ('C0','S0') and case['id'].startswith(m['model']+'/') and m['contract']==f['contract']
            assert case['original_side']==e['side']==m['native_side'] and m['native_side'] in (-1,1)
            assert q==m['entry_quote'] and m['baseline'] is (m['model']=='C0')
            assert type(m['t8_side']) is int and m['t8_side'] in (-1,1)
            if m['baseline']:assert m['t8_side']==m['native_side'],'C0は保存方向を保護'
            assert q['clock'] and q['quote_ok'] and 0<q['bid']<q['ask'] and f['start']<=q['time']<limit
            for name in ('original','reverse','chart_original','chart_reverse'):
                stream=case[name];chart=name.startswith('chart');side=e['side'] if name.endswith('original') else -e['side']
                assert stream['status']=='filled' and stream['entry']==q and stream['birth']['side']==side
                assert stream['entry_price']==(q['last'] if chart else q['ask'] if side>0 else q['bid'])
                phase['stream検査']+=1;phase['entry検査']+=1
                assert [o['seconds'] for o in stream['outcomes']]==list(HORIZONS)
                for o in stream['outcomes']:
                    assert o['deadline']==q['time']+o['seconds'] and [t['width'] for t in o['touches']]==list(WIDTHS)
                    assert (o['endpoint'] is not None)==(o['status']=='complete')
                    if o['endpoint'] is not None:
                        a=o['endpoint'];assert o['deadline']<=a['time']<=o['deadline']+30 and a['time']<end
                        assert a['quote_ok'] and 0<a['bid']<a['ask'] and a['index']>q['index'] and a['source_line']>q['source_line'];phase['endpoint検査']+=1
                    for t in o['touches']:
                        assert t['direction'] in (-1,0,1) and (t['quote'] is None)==(t['direction']==0)
                        if t['quote'] is not None:
                            a=t['quote'];assert q['time']<=a['time']<=o['deadline'] and a['time']<end
                            assert a['quote_ok'] and 0<a['bid']<a['ask'] and a['index']>q['index'] and a['source_line']>q['source_line'];phase['touch検査']+=1
                    if chart:assert o['net0'] is None and o['net5'] is None
            r={'session':sid,'model':m['model'],'meta':m,'case':case,'scene':f,'union_selected':False}
            basis.append(r);groups.setdefault(union_key(sid,m['contract'],q),[]).append(r)
    assert len(sessions)==len(set(sessions)) and sessions==metadata['sessions'] and len(basis)==count and seen==set(mmap)
    if strict:assert len(sessions)==73 and sum(r['model']=='C0' for r in basis)==81
    for group in groups.values():
        assert len({r['model'] for r in group})==len(group),'同一基礎集合内の原行重複'
        assert all(r['case']['original']['entry']==group[0]['case']['original']['entry'] for r in group),'同一原行のQuote不一致'
    assert len(metadata['union'])==len(groups)
    rows=list(basis);used=set();aliases=0;opposite_aliases=0
    for u in metadata['union']:
        stamp=u['entry_stamp'];key=union_key(u['session'],u['contract'],stamp);assert key in groups and key not in used;used.add(key)
        group=groups[key];ids=[r['case']['id'] for r in group]
        assert len(u['alias_ids'])==len(set(u['alias_ids'])) and set(u['alias_ids'])==set(ids)
        chosen=next(r for r in group if r['case']['id']==u['canonical_id'])
        wanted=next((r for r in group if r['model']=='C0'),group[0]);assert chosen is wanted,'unionはC0を優先'
        chosen['union_selected']=True
        for r in group:r['union_canonical_id']=u['canonical_id'];r['alias_ids']=u['alias_ids']
        rows.append({**chosen,'model':'U0'});aliases+=len(group)-1
        opposite_aliases+=sum(r['case']['original_side']!=chosen['case']['original_side'] for r in group)
    assert used==set(groups)
    proof={'成功':True,'基礎取得数':len(basis),'C0':sum(r['model']=='C0' for r in basis),'S0':sum(r['model']=='S0' for r in basis),
        'U0':len(groups),'同原行aliasで除いた取得数':aliases,'代表と反対方向のalias数':opposite_aliases,'C0優先':True,'方向/成績による選別':False}
    return basis,rows,sessions,dict(phase),proof


# ----------------------------------------
def calculate(rows: list[dict],sessions: list[str],scenes: list[dict],arithmetic: object) -> tuple:
    """
    機能: 5政策300比較と3集合の参加・加重頻度を作る。
    引数: rows/sessions/scenes(list)、arithmetic(object)は固定124算術。
    返り値: tupleは集計/参加/頻度/主判定。S0が0件でも全73場を残す。
    """
    values={};participation={}
    for part,ids in (('all',sessions),('train',sessions[:48]),('validation',sessions[48:])):
        values[part]={};participation[part]={}
        for model in MODELS:
            rs=[r for r in rows if r['model']==model and r['session'] in ids]
            missing=[sid for sid in ids if not any(r['session']==sid for r in rs)]
            participation[part][model]={'対象場数':len(ids),'取得数':len(rs),'取得場数':len(ids)-len(missing),'未取得場数':len(missing),'未取得場':missing,'全場最低1取得':not missing and bool(ids)}
        for p in POLICIES:values[part][p]={a:{str(h):{str(w):arithmetic.stats(subset(rows,p,ids),p,a,h,w) for w in WIDTHS} for h in HORIZONS} for a in AXES}
    base=module(BASE,'144私有138頻度');base.MODELS=MODELS
    frequency=base.frequency(rows,sessions,scenes)
    s=values['all']['U0']['BBO']['3600']['125'];part=participation['all']['U0'];rate=s['target70'] is True;hour=frequency['all']['U0']['全時間平均1件毎時以上']
    goal={'主':'U0/union/全73場/実BBO/H60/±125pt','全73場最低1取得':part['全場最低1取得'],'到達済み先着70%以上':rate,
        '全時間平均1件毎時以上':hour,'三項目すべて達成':bool(part['全場最低1取得'] and rate and hour),'順':s['forward'],'逆':s['adverse'],
        '未到達':s['neither'],'全H不足':s['censored'],'到達済み率':s['resolved_rate'],'完了分母率':s['complete_rate'],
        '全件分母率':s['forward']/s['entries'] if s['entries'] else None,'全時間平均件数毎時':frequency['all']['U0']['全時間平均件数毎時'],'参加':part}
    return values,participation,frequency,goal


# ----------------------------------------
def tables(basis: list[dict],rows: list[dict],sessions: list[str],values: dict,participation: dict,frequency: dict,arithmetic: object) -> list:
    """
    機能: 300比較・可変基礎取得・全73場の型付き3表JSONを作る。
    引数: basis/rows/sessions(list)、values/participation/frequency(dict)、arithmetic(object)。
    返り値: list[dict]は34/49/77列の表。非適用政策はnull、未知金額を0としない。
    """
    comparison=[]
    for part in ('all','train','validation'):
        for p in POLICIES:
            v=participation[part][MODEL[p]];f=frequency[part][MODEL[p]]
            for a in AXES:
                for h in HORIZONS:
                    for w in WIDTHS:
                        s=values[part][p][a][str(h)][str(w)];quality=bool(v['全場最低1取得'] and s['target70'] is True)
                        comparison.append([144,part,p,MODEL[p],a,h/60,w,v['対象場数'],s['sessions'],s['entries'],s['flips'],v['全場最低1取得'],s['complete'],s['censored'],s['forward'],s['adverse'],s['neither'],
                            s['resolved_rate'],s['complete_rate'],s['forward']/s['entries'] if s['entries'] else None,s['target70'],quality,f['全時間平均件数毎時'],f['名目新規可時間平均件数毎時'],f['全時間平均1件毎時以上'],quality and f['全時間平均1件毎時以上'],
                            s['ifd_known'],s['ifd_unknown'],s['ifd_net0_sum'],s['ifd_net5_profit'],s['ifd_net5_loss'],s['ifd_net5_sum'],s['ifd_net5_mean'],s['ifd_net5_pf']])
    detail=[]
    for r in basis:
        m=r['meta'];c=r['case'];origins=m.get('origins',[])
        row=[144,'train' if r['session'] in sessions[:48] else 'validation',r['session'],r['model'],c['id'],m['candidate_id'],c['original_side'],m['t8_side'],m['baseline'],
            r['union_selected'],r['union_canonical_id'],'|'.join(r['alias_ids']),len(origins),'|'.join(sorted({str(o.get('family','')) for o in origins})),arithmetic.jst(c['original']['entry']['time']),
            c['original']['entry_price'],c['reverse']['entry_price'],arithmetic.jst(min(r['scene']['force_close'],r['scene']['end']-3900)),r['scene']['raw']['sha256']]
        for p in POLICIES:
            view={**r,'model':'U0'} if MODEL[p]=='U0' and r['union_selected'] else r
            if view['model']!=MODEL[p]:row += [None]*6;continue
            q=selected(view,p,'BBO');o=arithmetic.observation(q,3600);e=arithmetic.ifd(q,o,125,'BBO')
            row += [q['birth']['side'],o['status'],arithmetic.touch(o,125)['direction'],e['known'],e['reason'],e['net5']]
        detail.append(row)
    scene_rows=[];cumulative=Counter();unknown=Counter()
    for i,sid in enumerate(sessions):
        f=frequency['場別'][sid];row=[144,sid,'train' if i<48 else 'validation',f['全時間h'],f['名目新規可時間h']]
        row += [f['models'][m]['取得数'] for m in MODELS]+[bool(f['models'][m]['取得数']) for m in MODELS]+[f['models'][m]['全時間頻度'] for m in MODELS]+[f['models'][m]['名目新規可時間頻度'] for m in MODELS]
        for p in POLICIES:
            s=arithmetic.stats(subset(rows,p,[sid]),p,'BBO',3600,125);cumulative[p]+=s['ifd_net5_sum'] or 0;unknown[p]+=s['ifd_unknown']
            row += [s['flips'],s['forward'],s['adverse'],s['neither'],s['censored'],s['ifd_known'],s['ifd_unknown'],s['ifd_net5_profit'],s['ifd_net5_loss'],s['ifd_net5_sum'],cumulative[p],unknown[p]]
        scene_rows.append(row)
    result=[{'name':'正逆比較','headers':COMPARISON_HEADERS,'rows':comparison},{'name':'入口別診断','headers':DETAIL_HEADERS,'rows':detail},{'name':'全セッション','headers':SCENE_HEADERS,'rows':scene_rows}]
    assert [(len(t['rows']),len(t['headers'])) for t in result]==[(300,34),(len(basis),49),(len(sessions),77)]
    assert all(len(set(t['headers']))==len(t['headers']) and all(len(r)==len(t['headers']) and all(v is None or type(v) in (int,float,str,bool) and (not isinstance(v,float) or math.isfinite(v)) for v in r) for r in t['rows']) for t in result)
    return result


# ----------------------------------------
def baseline_check(basis: list[dict], values: dict, old: dict, pairs: dict) -> dict:
    """
    機能: 旧138のC0だけへ全81取得/4stream/60条件を同体照合する。
    引数: basis(list[dict])、values/old/pairs(dict)。
    返り値: dict。138の追加752側は新strongの観測に使わない。
    """
    lookup={};labels=0;n=0
    for scene in pairs['scenes']:
        for case in scene['cases']:
            if not case['id'].startswith('C0/'):continue
            q=case['original']['entry'];key=(scene['session'],q['time'],q['index'],q['source_line'])
            assert key not in lookup;lookup[key]=case
    assert len(lookup)==81
    for row in basis:
        if row['model']!='C0':continue
        q=row['case']['original']['entry'];key=(row['session'],q['time'],q['index'],q['source_line']);before=lookup[key]
        assert row['case']['original_side']==before['original_side']
        for name in ('original','reverse','chart_original','chart_reverse'):
            for field in ('entry','entry_price','outcomes'):assert row['case'][name][field]==before[name][field]
            labels+=10
        n+=1
    assert n==81
    count=0
    for part in ('all','train','validation'):
        for axis in AXES:
            for h in HORIZONS:
                for width in WIDTHS:
                    current=values[part]['C0'][axis][str(h)][str(width)];prior=old['集計'][part]['C0'][axis][str(h)][str(width)]
                    assert current==prior and current['flips']==0;count+=1
    assert count==60
    return {'成功':True,'旧138C0全81':81,'4stream全H幅':labels,'旧60条件同体':count,'C0反転数':0,'旧結果変更':False}


# ----------------------------------------
def main() -> None:
    """
    機能: Root F1後に明示SHAの保存正逆だけを集計する。
    引数: CLI f1/fixed-input/metadata/resultと各SHA、output-dir。
    返り値: None。原板/CSV/Sourceの自然再生を行わず、既存出力を上書きしない。
    """
    p=argparse.ArgumentParser(description='144の可変取得とC0優先unionを集計')
    for n in ('f1','fixed-input','metadata','result'):p.add_argument('--'+n,type=Path,required=True);p.add_argument('--'+n+'-sha256',required=True)
    p.add_argument('--output-dir',type=Path,required=True);args=p.parse_args()
    paths={n:getattr(args,n.replace('-','_')).resolve() for n in ('f1','fixed-input','metadata','result')}
    expected={n:getattr(args,n.replace('-','_')+'_sha256') for n in paths}
    assert all(len(h)==64 and all(c in '0123456789abcdef' for c in h) for h in expected.values())
    assert sha(paths['f1'])==expected['f1'];f1=json.loads(paths['f1'].read_bytes());assert f1['試行']==144
    declared={Path(n).resolve():h for n,h in f1['ファイル'].items()}
    local=[HERE/n for n in ('集計する.py','人工検査.py','条件.md')]+[SPECIFICATION]
    checks={**SOURCES,**{x:sha(x) for x in local},**{paths[n]:expected[n] for n in ('fixed-input','metadata')}}
    assert all(declared[n.resolve()]==h and sha(n)==h for n,h in checks.items())
    assert sha(paths['result'])==expected['result']
    # ----------------------------------------
    # F1/入力/コード/依存の照合完了後だけ自然金融本文を開きます。
    fixed=json.loads(paths['fixed-input'].read_bytes());meta=json.loads(paths['metadata'].read_bytes());result=json.loads(paths['result'].read_bytes())
    assert meta['fixed_input_sha256']==result['input_sha256']==expected['fixed-input']
    basis,rows,sessions,phase,union=prepare(result,fixed,meta);arithmetic=load_arithmetic()
    values,participation,frequency,goal=calculate(rows,sessions,fixed['scenes'],arithmetic)
    baseline=baseline_check(basis,values,json.loads(OLD_BASELINE.read_bytes()),json.loads(OLD_PAIRS.read_bytes()))
    output_tables=tables(basis,rows,sessions,values,participation,frequency,arithmetic)
    output={'成功':True,'試行':144,'主政策':'U0','主評価':goal,'後段engine試行':result['trial'],'全場数':len(sessions),
        '取得集合数':{m:participation['all'][m]['取得数'] for m in MODELS},'基礎集合の実観測件数':len(basis),'union':union,
        '集計':values,'参加':participation,'頻度':frequency,'全4streamのphase検査':phase,'旧C0同体':baseline,
        'F1_SHA256':expected['f1'],'固定入力SHA256':expected['fixed-input'],'入口参照SHA256':expected['metadata'],'自然結果SHA256':expected['result'],
        '全73場は既使用':True,'独立未知期検証':False,'bootstrap再実装':False,'口座収支':False,'実IFD':False,'反転注文適格性再構築':False,
        '数量費用':'独立mini1枚100円/pt、往復77円、C5追加1000円。Last金額null','反転数基準':'各コホートnative方向相対'}
    assert all(sha(n)==h for n,h in checks.items()) and sha(paths['f1'])==expected['f1'] and sha(paths['result'])==expected['result']
    dest=args.output_dir;dest.mkdir(parents=True,exist_ok=True)
    assert not any((dest/n).exists() for n in ('集計.json','CSV用の表.json','集計完了.json'))
    arithmetic.save(dest/'集計.json',output);arithmetic.save(dest/'CSV用の表.json',{'成功':True,'試行':144,'主政策':'U0','tables':output_tables})
    arithmetic.save(dest/'集計完了.json',{'成功':True,'試行':144,'前後不変':True,'全依存SHA256':{str(n):h for n,h in checks.items()},
        '表形状':[(len(t['rows']),len(t['headers'])) for t in output_tables],'集計SHA256':sha(dest/'集計.json'),'表SHA256':sha(dest/'CSV用の表.json')})
    print(json.dumps({'成功':True,'主評価':goal,'取得集合数':output['取得集合数'],'表形状':[(len(t['rows']),len(t['headers'])) for t in output_tables]},ensure_ascii=False))


if __name__=='__main__':main()
