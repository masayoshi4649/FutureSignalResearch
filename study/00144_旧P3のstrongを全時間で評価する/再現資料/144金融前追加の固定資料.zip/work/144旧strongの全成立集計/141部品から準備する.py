"""凍結141の可変件数集計を別144部品へ適応する。旧源は変更しない。"""
from pathlib import Path
import hashlib

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
SOURCE=ROOT/'work/141独立入口とunionの集計/集計する.py'


def main() -> None:
    """
    機能: native/T8同取得比較とC0優先unionの144集計部品を作る。
    引数: なし。
    返り値: None。自然入力や旧Source/試行は開かず、新しいコードだけを生成する。
    """
    before=SOURCE.read_bytes();body=before.decode('utf-8').replace('141','144').replace('V0','S0').replace('RV','T0').replace('RU','N0')
    body=body.replace("OLD137=ROOT/'work/137既知回復と頻度の集計/集計.json'","OLD_BASELINE=ROOT/'work/138全成立入口と頻度の集計/集計.json'")
    body=body.replace("OLD_PAIRS=ROOT/'work/137既知回復の評価/固定取得の正逆観測.json'","OLD_PAIRS=ROOT/'work/138全成立入口の評価/固定取得の正逆観測.json'")
    body=body.replace("SPECIFICATION=ROOT/'work/144_VWMA独立入口の採用仕様.md'","SPECIFICATION=ROOT/'work/144_旧P3strongを全成立へ広げる採用仕様.md'")
    body=body.replace("OLD137:'f7c73cc87948fa17174e3909f89aa63d74abe76191bf435788e71cb0d400548b'","OLD_BASELINE:'6ef283db667603884b42260affce732ba5c9b31731d24b1bb18f9e96ee4b3486'")
    body=body.replace("OLD_PAIRS:'f0adca92cf1f1db25e75e4d92187952e2920ea7126b3790ece89df1c7f00369a'","OLD_PAIRS:'d272fc6f6768342ff67e1a9ec58b0b7307a0a5b07cc215ba5ff7bcb50865b742'")
    body=body.replace("POLICIES=('C0','S0','U0','T0','N0')","POLICIES=('C0','S0','T0','U0','N0')")
    body=body.replace("'native方向','固定対照由来'","'native方向','保存T8方向','固定対照由来'")
    body=body.replace("c['original_side'],m['baseline']","c['original_side'],m['t8_side'],m['baseline']")
    body=body.replace('(len(basis),48)','(len(basis),49)').replace('34/48/77','34/49/77')
    old="""    return record['case'][('chart_' if axis=='Last' else '')+('reverse' if policy in ('T0','N0') else 'original')]"""
    new="""    native=record['case']['original_side'];meta=record['meta']
    side=meta['t8_side'] if policy=='T0' or policy=='U0' and not meta['baseline'] else native
    assert type(side) is int and side in (-1,1)
    return record['case'][('chart_' if axis=='Last' else '')+('original' if side==native else 'reverse')]"""
    assert old in body;body=body.replace(old,new,1)
    line="            assert q==m['entry_quote'] and m['baseline'] is (m['model']=='C0')"
    assert line in body
    body=body.replace(line,line+"\n            assert type(m['t8_side']) is int and m['t8_side'] in (-1,1)\n            if m['baseline']:assert m['t8_side']==m['native_side'],'C0は保存方向を保護'",1)
    body=body.replace('各集合native又は対応する実逆BBO/Lastを選ぶ。','保存native/T8とC0保護から対応する実BBO/Last側を選ぶ。')
    old="baseline=base.baseline_check(basis,values,json.loads(OLD137.read_bytes()),json.loads(OLD_PAIRS.read_bytes()))"
    assert old in body;body=body.replace(old,"baseline=baseline_check(basis,values,json.loads(OLD_BASELINE.read_bytes()),json.loads(OLD_PAIRS.read_bytes()))")
    insertion='''def baseline_check(basis: list[dict], values: dict, old: dict, pairs: dict) -> dict:
    """
    機能: 旧138のC0だけへ全81取得/4stream/60条件を同体照合する。
    引数: basis(list[dict])、values/old/pairs(dict)。
    返り値: dict。138の追加752側は新strongの観測に使わない。
    """
    lookup={};labels=0;n=0
    for scene in pairs['scenes']:
        for case in scene['cases']:
            if not case['id'].startswith('C0/'):continue
            q=case['original']['entry'];key=(scene['session'],q['time'],q['index'],q['source_line'])
            assert key not in lookup;lookup[key]=case
    assert len(lookup)==81
    for row in basis:
        if row['model']!='C0':continue
        q=row['case']['original']['entry'];key=(row['session'],q['time'],q['index'],q['source_line']);before=lookup[key]
        assert row['case']['original_side']==before['original_side']
        for name in ('original','reverse','chart_original','chart_reverse'):
            for field in ('entry','entry_price','outcomes'):assert row['case'][name][field]==before[name][field]
            labels+=10
        n+=1
    assert n==81
    count=0
    for part in ('all','train','validation'):
        for axis in AXES:
            for h in HORIZONS:
                for width in WIDTHS:
                    current=values[part]['C0'][axis][str(h)][str(width)];prior=old['集計'][part]['C0'][axis][str(h)][str(width)]
                    assert current==prior and current['flips']==0;count+=1
    assert count==60
    return {'成功':True,'旧138C0全81':81,'4stream全H幅':labels,'旧60条件同体':count,'C0反転数':0,'旧結果変更':False}


# ----------------------------------------
'''
    assert '\ndef main() -> None:' in body;body=body.replace('\ndef main() -> None:','\n'+insertion+'def main() -> None:',1)
    assert 'OLD137' not in body and '141' not in body and 'RV' not in body and 'RU' not in body
    path=HERE/'集計する.py';assert not path.exists();path.write_text(body,encoding='utf-8')
    assert SOURCE.read_bytes()==before
    print('144可変集計を作成。旧141源SHA256='+hashlib.sha256(before).hexdigest())


if __name__=='__main__':main()
