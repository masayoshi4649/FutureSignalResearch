"""144金融adapterの人工・compile・CLI拒否と源の不変を記録する。"""
from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 明示したコード/文書の指紋を求める。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 人工13群と構文/CLIガードだけを実行し、自然前準備を停止する。
    引数: なし。
    返り値: None。自然JSON/Raw/CSV/金融を開かず旧コードを変更しない。
    """
    files=[HERE/n for n in ('集計する.py','人工検査.py','条件.md','README.md')]
    old=[ROOT/'work/141独立入口とunionの集計'/n for n in ('集計する.py','人工検査.py')]
    before={p:sha(p) for p in files+old}
    command=[sys.executable,'-X','utf8',str(HERE/'人工検査.py')]
    run=subprocess.run(command,capture_output=True,text=True,encoding='utf-8',check=True)
    artificial=json.loads(run.stdout);assert artificial['成功'] and artificial['人工群']==13 and artificial['全表列数']==[34,49,77]
    subprocess.run([sys.executable,'-m','py_compile',str(HERE/'集計する.py'),str(HERE/'人工検査.py')],capture_output=True,check=True)
    reject=subprocess.run([sys.executable,'-X','utf8',str(HERE/'集計する.py')],capture_output=True,text=True,encoding='utf-8')
    assert reject.returncode==2 and '--f1' in reject.stderr
    module_spec=importlib.util.spec_from_file_location('144準備契約',HERE/'集計する.py');m=importlib.util.module_from_spec(module_spec);module_spec.loader.exec_module(m)
    assert m.POLICIES==('C0','S0','T0','U0','N0') and m.MODELS==('C0','S0','U0')
    assert m.MODEL=={'C0':'C0','S0':'S0','U0':'U0','T0':'S0','N0':'U0'}
    assert [len(m.COMPARISON_HEADERS),len(m.DETAIL_HEADERS),len(m.SCENE_HEADERS)]==[34,49,77]
    assert all(sha(p)==h for p,h in before.items())
    for p,h in m.SOURCES.items():
        if p.suffix=='.py':assert sha(p)==h
    proof={'成功':True,'試行':144,'段階':'自然Source/F1結果未読の金融adapter準備・編集停止','人工':artificial,
        'compile':True,'CLI無指定は終了2で拒否':True,'政策順':list(m.POLICIES),'集合':list(m.MODELS),'政策集合対応':m.MODEL,
        '三表列数':[34,49,77],'表行数':'300/基礎81+N/73','旧C0照合':'旧138C0だけ全81/4stream/60条件。追加P0を新strongへ流用しない',
        '本来の方向':'C0/S0/N0はnative、T0は保存t8、U0はC0保護と新S0の保存t8',
        'Root_F1必須源':{str(p):h for p,h in m.SOURCES.items()},'Root_F1必須ローカル源':{str(p):before[p] for p in files[:3]},
        '採用仕様':{'path':str(m.SPECIFICATION),'sha256':sha(m.SPECIFICATION)},'旧141源前後不変':{str(p):before[p] for p in old},
        '自然価格/教師/結果JSON/新Raw/CSV/金融/追加2場読取':False,'旧試行変更':False,'F0/F1自然実行':False,
        '重大不足':[],'コードSHA256':sha(Path(__file__))}
    p=HERE/'準備の確認.json';p.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'準備SHA256':sha(p),'集計SHA256':before[files[0]],'人工SHA256':before[files[1]],'条件SHA256':before[files[2]],'人工群':13},ensure_ascii=False))


if __name__=='__main__':main()
