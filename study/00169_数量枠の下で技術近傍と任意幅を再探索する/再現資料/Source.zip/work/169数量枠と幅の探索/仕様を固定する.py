"""数量枠により崩れた先着率を幅・期限と技術近傍で再探索する条件を固定する。"""
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
TRIAL=ROOT/'study/00169_数量枠の下で技術近傍と任意幅を再探索する'


def main() -> None:
    """
    機能: cap10探索と前48場固定選択を追加七場の成績参照前に固定する。
    引数: なし。166と168の既固定条件を入力する。
    返り値: None。169条件と未実行README、追加成績未参照のF0を保存する。
    """
    assert not TRIAL.exists()
    assert max(int(p.name[:5]) for p in (ROOT/'study').iterdir() if p.is_dir() and p.name[:5].isdigit())==168
    parent=ROOT/'study/00166_未公表の長期指標を捏造せず局所技術で参加を補う/条件.json'
    setting=json.loads(parent.read_text(encoding='utf-8'))
    setting={k:setting[k] for k in ('core_profiles','hierarchy_variants','momentum_widths','fade_widths',
        'integration','technical_first','cost','discovery_support')}
    setting.update(trial=169,date='2026-11-15',name='数量枠の下で技術近傍と任意幅を再探索する')
    setting['parents']=[{'path':p.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
        for p in (parent,ROOT/'study/00168_固定複合入口を片側十枚の数量枠で再生する/条件.json')]
    setting['reason']='168主案は片側10枚を守り全73場/0.932hを維持したが195順86逆で69.395%へ低下。元入口を固定10枚へ増幅せず、取得の保有時間と重複を変える枝幅・期限及び技術近傍を比べる。'
    setting['capacity']='168の同体・人工確認済みengineを未改変で利用。買売各10枚、要求1枚、pending予約、未知は場末枠保持、同秒exit保守時計。'
    setting['horizons']=['H30','H60','H120','SESSION']
    setting['screen']='4主profile×4階層×6順行幅×5回復失敗幅×4期限×H150/H200=3840政策。旧73場の発見用。全期bestを未見性能と称さない。'
    setting['training']='前48場のみで固定二選択A/Bを行う。追加七場の価格・金融入力は生成済みだがRoot/選択担当は成績を未参照。後25場も既使用なので新規未見とは呼ばない。'
    setting['base_support']={'minimum_count':250,'minimum_resolved':100,'minimum_rate':.70,
        'minimum_per_hour':.75,'all_48_scenes':True,'maximum_unknown_fraction':.10,'minimum_pf':1.2,'minimum_net':0}
    setting['score']='前48場F/(F+A)のWilson95%下限を順位指標とする。近接取得の独立性は仮定できず統計保証として使わない。次に取得数、PF、安定添字。'
    setting['selectors']={'A':'base_support適格からscore最大。',
        'B':'base_supportかつ前48の三帯それぞれ到達6以上・率55%以上・既知PF1.05以上・差引正からscore最大。適格なしならnullを保持。'}
    setting['new_period']='固定A/Bだけを追加七場へ適用。3840全候補の追加七場探索は禁止し、追加成績によりA/Bを交換しない。167/168の固定主案も対照として残す。'
    setting['report']='全場参加・頻度・FANC・決済勝率・利益損失・前後とq0/q1三帯・数量棄却・最大同時数。各技術近傍と幅・期限を明示。'
    TRIAL.mkdir();(TRIAL/'検査').mkdir()
    path=TRIAL/'条件.json';path.write_text(json.dumps(setting,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (TRIAL/'README.md').write_text('# 00169 数量枠の下で技術近傍と任意幅を再探索する\n\n2026-11-15。[条件](条件.json)を追加期間の候補成績参照前に固定。168で70%をわずかに下回った原因を、数量枠・保有時間・枝幅・技術近傍として再比較する。現在未実行。\n',encoding='utf-8')
    (TRIAL/'検査/F0_追加成績参照前.json').write_text(json.dumps({'成功':True,
        '条件SHA256':hashlib.sha256(path.read_bytes()).hexdigest(),'Rootと選択担当の追加候補成績未参照':True},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'条件SHA256':hashlib.sha256(path.read_bytes()).hexdigest()},ensure_ascii=False))


if __name__=='__main__':
    main()
