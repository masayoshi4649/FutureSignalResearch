"""169の正式Source・統計・null封印・文書を照合し保存停止する。"""
from pathlib import Path
from io import BytesIO
import hashlib
import json
import re
import zipfile

import numpy as np

ROOT=Path(__file__).resolve().parents[2]
TRIAL=ROOT/'study/00169_数量枠の下で技術近傍と任意幅を再探索する'


def reference(path: Path) -> dict:
    """
    機能: 対象の物理指紋を返す。
    引数: path(Path)。返り値: dict。
    """
    with path.open('rb') as stream:sha=hashlib.file_digest(stream,'sha256').hexdigest()
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':sha}


def read(path: Path) -> dict:
    """
    機能: 保存済みJSONを読む。
    引数: path(Path)。返り値: dict。
    """
    return json.loads(path.read_bytes())


def main() -> None:
    """
    機能: 全ZIP/member・567セル・親参照・null選択と元不変を照合する。
    引数: なし。返り値: None。自然再生を行わない。
    """
    index=read(TRIAL/'再現資料/保存索引.json')
    assert index['A_B']=={'A':None,'B':None}
    assert reference(TRIAL/'条件.json')['sha256']=='526d2c7bacf2ca3b3050ddbbb152ff9e26a8659515a5ef33166266f3a395b884'
    members=0
    for group in index['正本']:
        assert reference(ROOT/group['archive']['path'])==group['archive']
        with zipfile.ZipFile(ROOT/group['archive']['path']) as source:
            assert source.testzip() is None
            for entry in group['members']:
                body=source.read(entry['path']);assert len(body)==entry['bytes'] and hashlib.sha256(body).hexdigest()==entry['sha256']
                members+=1
    for entry in index['親共有参照']:assert reference(ROOT/entry['path'])==entry
    stop=read(ROOT/'work/169数量枠と技術近傍/部品の停止.json')
    for entry in stop['Sourceと結果']:assert reference(ROOT/entry['path'])==entry
    documents=[TRIAL/name for name in ('README.md','設定と結果.md','条件心理と限界.md','再現手順.md')]
    links=0
    for path in documents:
        text=path.read_text(encoding='utf-8');assert '現在未実行' not in text
        for target in re.findall(r'\[[^\]]+\]\(([^)]+)\)',text):
            if '://' in target or target.startswith('#'):continue
            assert (path.parent/target.split('#')[0]).resolve().exists(),(path.name,target)
            links+=1
    rows=[line for line in (TRIAL/'設定と結果.md').read_text(encoding='utf-8').splitlines() if re.match(r'^\| [A-Z]\d{2} \|',line)]
    assert len(rows)==63 and all(len(line.split('|')[1:-1])==11 for line in rows)
    prefix='work/169数量枠と技術近傍/旧73探索/'
    with zipfile.ZipFile(TRIAL/'再現資料/統計正本.zip') as source:
        seal=json.loads(source.read(prefix+'前半固定AとBの封印.json'));assert seal['選択']=={'A':None,'B':None} and seal['追加七場成績未読']
        found=json.loads(source.read(prefix+'全期発見の上位.json'));assert found['支持合格']==106 and len(found['上位'])==40
        axes=json.loads(source.read(prefix+'統計軸.json'))
        with np.load(BytesIO(source.read(prefix+'数量枠探索の統計配列.npz')),allow_pickle=False) as arrays:
            assert arrays['metrics'].shape==tuple(axes['shape']) and arrays['bands'].shape==tuple(axes['bands_shape'])
            assert int(np.prod(axes['shape'][:-2]))==3840
    result={'成功':True,'確認日':'2026-11-15','試行':169,'文書':[reference(path) for path in documents],
        '保存索引':reference(TRIAL/'再現資料/保存索引.json'),'全ZIP_member数':members,'V8セル':567,'有効リンク':links,
        'A':None,'B':None,'全期発見106を採用に交換':False,'統計政策数':3840,'追加七場を選択へ入力':False,
        '検算範囲':'selector人工/runner静的/統計自己不変式/168二案156欄同体/保存前半統計からnull選択再現。全3840を別engineで独立自然再生した確認ではない。',
        '元Source_条件_F0_統計不変':True,'原Raw_CSV_共用数値複製':False,'CSV_global変更':False,'PDF_xlsx生成':False}
    (TRIAL/'検査/正式保存の停止.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'停止票':reference(TRIAL/'検査/正式保存の停止.json')},ensure_ascii=False))


if __name__=='__main__':main()
