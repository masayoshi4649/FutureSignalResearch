"""169の前半null選択と旧73全期発見を分離して正式保存する。"""
from pathlib import Path
import importlib.util
import importlib.metadata
import json
import platform
import re
import shutil
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
TRIAL=ROOT/'study/00169_数量枠の下で技術近傍と任意幅を再探索する'
ENGINE=ROOT/'work/169数量枠と技術近傍'
DATA=ENGINE/'旧73探索'
BOOK_SHA='526d2c7bacf2ca3b3050ddbbb152ff9e26a8659515a5ef33166266f3a395b884'
spec=importlib.util.spec_from_file_location('保存共通169',ROOT/'work/163_164正式保存/正式保存する.py')
B=importlib.util.module_from_spec(spec);spec.loader.exec_module(B)


def identify(record: dict) -> str:
    """
    機能: 発見条件を閾値・幅・期限付きで表記する。
    引数: record(dict)。返り値: str。
    """
    c=record['candidate']
    return f"{c['profile']['id']} / {c['hierarchy']['id']} / 順行{c['momentum_width']}・元EX反対{c['fade_width']} / {c['horizon']} / {c['integration']}"


def metric_table(record: dict) -> str:
    """
    機能: 発見の前後を利益・損失・未知・数量棄却付きで表示する。
    引数: record(dict)。返り値: strはMarkdown。
    """
    rows=[]
    for label,m in record['periods'].items():
        rows.append([label,int(m['count']),f"{int(m['F'])}/{int(m['A'])}/{int(m['N'])}/{int(m['C'])}",B.format_rate(m['rate']),
            f"{m['profit']:,.0f}",f"{m['loss']:,.0f}",f"{m['net']:+,.0f}",f"{m['pf']:.3f}" if m['pf'] is not None else '未定義',
            int(m['unknown']),f"{m['per_hour']:.3f}",int(m['quantity_rejected_core'])])
    return B.table(['期間','取得','F/A/N/C','先着率','利益円','損失円','既知差引円','PF','未知','回/時','主数量棄却'],rows)


def documents() -> None:
    """
    機能: A/B nullを採用しないまま、支持106の発見と原因を記す。
    引数: なし。返り値: None。
    """
    seal=B.read(DATA/'前半固定AとBの封印.json');found=B.read(DATA/'全期発見の上位.json')
    assert seal['選択']=={'A':None,'B':None} and found['支持合格']==106
    first=found['上位'][0]
    text='''# 00169 数量枠の下で技術近傍と任意幅を再探索する\n\n2026-11-15。前48場だけの固定選択A/Bはともにnullで封印した。全期発見では106政策が報告支持を満たしたが、A/Bを全期bestへ交換していない。追加7場の成績を選択へ入力せず、169のA/Bを追加7場へ適用していない。\n\n## 仮説・固定条件\n\n168で数量枠を付けると入口分布が変わったため、同じ技術群の近傍、枝幅、保有期限を再比較した。4主profile×4局所階層×6順行幅×5元EX反対幅×4期限×H150/H200=3,840政策。全政策で買売各10枚、1要求1mini、pending予約/保有/未知の枠を初期化して旧73場を因果再生した。取得集合だけを固定して幅の損益を差し替える方法ではない。\n\n[条件](条件.json)SHA `526d2c7bacf2ca3b3050ddbbb152ff9e26a8659515a5ef33166266f3a395b884`。[全567設定](設定と結果.md)、[条件・心理と限界](条件心理と限界.md)、[再現手順](再現手順.md)を参照する。\n\n## 前48だけのA/B\n\nAは250取得以上・同幅到達100以上・全48場・0.75回/時以上・先着70%以上・未知10%以下・PF1.2以上・既知差引正。Bはさらに前48のq0三帯ごと到達6以上・率55%以上・PF1.05以上・既知差引正を要求する。順位はWilson95%下限→取得数→PF→安定添字。近接取引の独立性を仮定した保証には使わない。\n\n|選択|適格|封印された候補|追加7場適用|\n|---|---:|---|---|\n|A|0|null|なし|\n|B|0|null|なし|\n\n前48の先着70%以上は4政策だけで、4政策とも未知10%を超えた。率以外の支持を全て満たす808政策の最高は393取得・142順63逆=69.268%、PF1.465。支持を後から緩めず、全期又は後25の良い値で救済しない。[原因の原票](再現資料/Source.zip) と統計正本へ残した。\n\n## 全期探索の発見\n\n支持106は既使用73場を用いた発見で、自動採用・未見実績ではない。取得数→率→安定添字順の先頭は次の条件。\n\n'''+identify(first)+'\n'+metric_table(first)
    text+='''\nこの候補は前48先着66.67%、PF1.120でAに不適格。全期70.00%の見出しだけで採用しない。全期653取得の同幅到達は150件、471件は未到達期限返済、未知32件。期限返済込みの既知差引と、到達済み先着率を別に読む。\n\n上位一覧は40件だけを説明用JSONへ残し、全3,840政策は統計配列の正本に保存した。支持の0.8回/時は条件上の優先目安であり、runnerの支持maskには含まれていない。全場参加・率・前後到達数/率・未知・前後既知差引正は支持maskへ入る。\n\n## 入力・費用・数量の意味\n\n対象は既使用73場、全ザラバ720時間55分。前48と後25も既使用であり独立未見とは称さない。166の固定出生と163の実両側12幅4時計表を再用する。旧C1保存信号で補完しない。\n\n各要求1mini、1pt=100円、往復税込77円と追加往復滑り1,000円。買売は同一条件の符号反転。pendingが片側10枠を予約し、取得後は保有へ移す。既知決済は価格時計の秒末で解放し、金融未知は場末まで枠を保つ。同秒q0に後のexitを使わない。未知損益を0円実績へ置換しない。\n\n利益は既知決済の費用後正、損失は負の絶対値。両者の差引は既知合算であり、未知が残る全件収支はnull。数量枠の模型を通したとしても、ラージ板をminiへ代用し、実約定・待ち行列・注文遅延を完全再現した口座実績ではない。\n\n## 検査と次の問い\n\n純selectorの人工とrunnerの静的確認は成功。全保存政策のF/A/N/C・既知/未知・利益損失・前後/三帯加法・上限10を自己確認し、168固定二案は三期間各78欄、合計156欄が同体だった。全3,840政策を別engineで独立自然再生した確認ではない。\n\nrunnerはT150/H200の配列順を166固定由来へ依存しており、出生元を変えるときは明示照合が必要。PFのJSON非有限値はnullだがselectorは利益/損失からPF∞を計算する。今回前48の全体/帯でPF∞は0件だった。\n\nA/B未成立の原因を率と未知のトレードオフへ切り分けた。幅/保有時間が枠を占有してどの枝を落とすかが次の問いであり、未達を解決済みとせず新試行へ分ける。追加期間を見て本試行の閾値を改変しない。CSV/globalと後続170は本保存で変更していない。\n'''
    (TRIAL/'README.md').write_text(text,encoding='utf-8')
    parent=ROOT/'study/00166_未公表の長期指標を捏造せず局所技術で参加を補う/設定と結果.md'
    body=parent.read_text(encoding='utf-8').split('## 手法×時間スケール',1)[1]
    body=body.replace('S166','S169').replace('R166','R169')
    body=body.replace('MP0057/58/81/82','MP0057/58').replace('EX0075/76/87/88','EX0075/76')
    body=body.replace('4MP×4EX×3背景×5時計','4主profile×4階層×30幅対×4期限×2補完')
    body=body.replace('主4profile×局所4階層×30幅対×4期限×H150/H200=3,840政策。全73場参加は旧C1補完ではなく、主693・旧技術T35・局所10の事前主案で確認した。旧T8票を局所6票へ全置換したわけではない。旧165対応対照は全要素同体。主案と前半選択と全期発見を交換しない。',
        '数量枠下の4主profile×4局所階層×30幅対×4期限×H150/H200=3,840政策。A/Bはともにnull。全期発見106はA/Bへ交換しない。')
    body=body.replace('MPの水準と旧Tの増分','MPの水準と旧Tの増分').replace('fade背景は15/30分4票','今回はB0で追加背景票なし')
    body=body.replace('新fadeは反対実側で確認/背景を別比較','元EX方向を反転しIMMEDIATE。追加確認/背景票なし')
    body=body.replace('CONFでは正を要求','今回はCONF未使用').replace('条件心理と原因.md','条件心理と限界.md')
    body=body.replace('|S169-B|失速注文側の15/30分EMA21傾きとDI差4票>=0/2/3。B0は追加filterなし、B2/3は必要4列全known|背景3|','|S169-B|B0固定、追加背景票なし。5/15/30票は旧T内で使用|背景固定|')
    body=body.replace('|S169-CONF|IMMEDIATE又は元EXへの遷移でarm後5/10分以内の初BASIC/STRONG。連続EXtrueで延長なし、場/180秒超reset。BASICは注文側M5 HistΔ/RSIΔ/q0gap正、RSI絶対増分<=12と気配/乖離gate。STRONGはDI正・量>=0.75追加|時計5|','|S169-CONF|IMMEDIATE固定。元EX回復方向の反対実側へ。後続の失敗足を待つ確認は今回未使用|時計固定|')
    body=body.replace('|S169-PAST|前48場だけで全場/先着>=70%/到達>=60/新>=80かつ10場/未知<=10%/PF>=1.2/差引>0。取得最大→率→固定添字順で選択し後25へ固定|既使用の前後比較|','|S169-PAST|前48場のみ、250取得/100到達/全48/0.75h/70%/未知10%以下/PF1.2/差引正。Wilson下限→回数→PF→安定添字。Bは三帯支持も要求|A/B両null|')
    header='# 169 設定と結果\n\n2026-11-15。V8全63手法×9尺度=567セルを複写。使用列は複合評価R169で、指標単独の効果ではない。元V8 SHA `'+B.sha(ROOT/'docs/議論/手法と時間スケールの汎用表_版8.md')+'`。数量枠は買売各10、1要求1mini。未知を0/中立にせず、E02の追尾は未使用。\n\n## 手法×時間スケール\n'
    body+='\n|S169-CAP|168 engine未変更。片側10、pending予約、既知は秒末解放、未知は場末まで予約。各幅/期限で新しく再生|数量模型|\n'
    rows=[line for line in body.splitlines() if re.match(r'^\| [A-Z]\d{2} \|',line)];assert len(rows)==63
    (TRIAL/'設定と結果.md').write_text(header+body,encoding='utf-8')
    psychology='''# 169 条件・心理と限界\n\n2026-11-15。技術の入口が良くても、長く枠を占有する入口が先に入り、後続の別枝を受けられない場合がある。168の片側10枠を各政策で再生し、幅/期限と技術近傍の組合せを調べた。利益額や後の勝敗を見て要求を採否する模型ではない。\n\n主profileはMP0057/58とEX0075/76の反対側の4組合せ。MPはMACD5/15、RSI、ADX15、量と価格乖離、EXはBB15端・ヒゲ・回復動力・量を同時に使う。EXは回復の失敗を後で確認する方式ではなく、元の回復方向を当時反転するIMMEDIATE/B0固定。詳細は166/167の固定設定を引き継ぐ。\n\n旧Tの複数軸・複数技法の票を優先し、長期未公表時だけ局所方向/動力/形状/量を使う4階層を比較した。未知指標を中立とみなすのではなく、その時点の可用性から別の資格を選ぶ仮説である。\n\n幅を広げれば短いノイズを避けられる可能性がある一方、期限未到達や未知が増え、建玉枠を占有する。短期限は枠を早く返すが、後の伸びを待つルールとは別の出口になる。取り逃がした仮想利益を最適化せず、各手法で実際に成立した取得と既知損益を比較した。\n\nA/Bのnullは価格心理を否定する結果ではない。固定した前半支持で率70%と未知10%以下を同時に満たすものが無かった。全期106発見も既使用73場を利用した探索であり、未見確率を保証しない。Wilson95%下限は順位指標で、近接した取得の独立性を保証していない。\n\n数量の未知枠を場末まで保持し、exitの秒内原行順をengineへ渡さず秒末解放とする保守時計を用いた。実約定やbrokerの注文状態を再現したわけではない。未知の金額を0円に置かず、既知差引と全収支nullを区別する。\n\n[結果](README.md)、[設定](設定と結果.md)、[固定条件](条件.json)を参照する。\n'''
    (TRIAL/'条件心理と限界.md').write_text(psychology,encoding='utf-8')


def main() -> None:
    """
    機能: 元条件・Source・統計を非変更でZIPと正式索引へ保存する。
    引数: なし。返り値: None。自然再探索しない。
    """
    assert B.sha(TRIAL/'条件.json')==BOOK_SHA
    documents();archive=TRIAL/'再現資料';archive.mkdir(exist_ok=True)
    paths=B.source_files('work/169数量枠と技術近傍')+B.source_files('work/169数量枠と幅の探索')+B.source_files('work/169正式保存')
    before={p:B.sha(p) for p in paths+[p for p in DATA.iterdir() if p.is_file()]}
    src=B.archive(archive/'Source.zip',paths)
    stats=B.archive(archive/'統計正本.zip',[p for p in DATA.iterdir() if p.is_file()])
    for name in ('選択の人工確認.json','runnerの静的確認.md','部品の停止.json'):
        target=TRIAL/'検査'/name;target.parent.mkdir(exist_ok=True)
        if target.exists():assert target.read_bytes()==(ENGINE/name).read_bytes()
        else:shutil.copyfile(ENGINE/name,target)
    target=TRIAL/'検査/前半固定AとBの封印.json'
    if target.exists():assert target.read_bytes()==(DATA/'前半固定AとBの封印.json').read_bytes()
    else:shutil.copyfile(DATA/'前半固定AとBの封印.json',target)
    refs=[B.reference(ROOT/path) for path in ('study/00166_未公表の長期指標を捏造せず局所技術で参加を補う/再現資料/Source.zip',
        'study/00166_未公表の長期指標を捏造せず局所技術で参加を補う/再現資料/出生と統計正本.zip',
        'study/00167_固定した複合入口を追加七場へ適用する/再現資料/Source.zip',
        'study/00168_固定複合入口を片側十枚の数量枠で再生する/再現資料/Source.zip',
        'inputs/00163_任意幅の共用価格索引/保存索引.json')]
    B.save(archive/'保存索引.json',{'成功':True,'条件':B.reference(TRIAL/'条件.json'),'正本':[
        {'archive':B.reference(archive/'Source.zip'),'members':src},{'archive':B.reference(archive/'統計正本.zip'),'members':stats}],
        '親共有参照':refs,'環境':{'Python':sys.version,'platform':platform.platform(),'numpy':importlib.metadata.version('numpy')},
        '全期発見と採用を区別':True,'A_B':{'A':None,'B':None},'追加七場の成績を選択へ利用':False,
        '自然検算範囲':'全保存統計不変式/前後三帯加法/上限10の自己確認、168二案の三期間156欄同体。全3840独立engine再生ではない。'})
    assert all(B.sha(path)==value for path,value in before.items())
    print(json.dumps({'成功':True,'Sourceメンバー':len(src),'統計メンバー':len(stats),'A':None,'B':None},ensure_ascii=False))


if __name__=='__main__':main()
