"""169前48だけでA/Bが適格無しになった理由を固定支持ごとに分解する。"""
from pathlib import Path
import json
import hashlib
import numpy as np
import selector169

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 固定した統計正本を指紋化する。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    with path.open('rb') as source:return hashlib.file_digest(source,'sha256').hexdigest()


def main() -> None:
    """
    機能: 保存済み前48統計のみから支持の単独通過・累積・一条件解除を診断する。
    引数: なし。新7場と後25場の統計値は参照しない。
    返り値: None。固定支持やA/B封印を変更せず診断JSON/MDだけを保存する。
    """
    folder=HERE/'旧73探索';axes=json.loads((folder/'統計軸.json').read_bytes())
    fields=axes['fields'];source=folder/'数量枠探索の統計配列.npz'
    with np.load(source,allow_pickle=False) as archive:
        # 物理NPZ memberは共有、選択診断では前48sliceだけを式へ渡す。
        front=archive['metrics'].reshape(3840,3,len(fields))[:,1,:].copy()
        bands=archive['bands'].reshape(3840,3,2,3,len(fields))[:,1,0,:,:].copy()
    book=json.loads((ROOT/'study/00169_数量枠の下で技術近傍と任意幅を再探索する/条件.json').read_bytes())
    v=selector169.derived(front,fields);b=selector169.derived(bands,fields)
    conditions={'250取得':v['count']>=250,'100到達':v['resolved']>=100,
        '全48場':(v['all_scenes']==1)&(v['scenes']==48),'0.75回毎時':v['per_hour']>=.75,
        '未知10パーセント以下':v['unknown_fraction']<=.1,'先着70パーセント':v['rate']>=.7,
        'PF1.2以上':v['pf']>=1.2,'既知差引正':v['net']>0}
    cumulative=np.ones(3840,dtype=bool);rows=[]
    for name,mask in conditions.items():
        cumulative &= mask;others=np.ones(3840,dtype=bool)
        for other,value in conditions.items():
            if other!=name:others &= value
        rows.append({'条件':name,'単独通過':int(mask.sum()),'順に累積通過':int(cumulative.sum()),'当条件だけ外す適格':int(others.sum())})
    except_rate=np.logical_and.reduce([mask for name,mask in conditions.items() if name!='先着70パーセント'])
    eligible=np.flatnonzero(except_rate);eligible=sorted(eligible,key=lambda i:(-v['rate'][i],-v['count'][i],int(i)))
    best=[]
    for index in eligible[:5]:
        best.append({'stable_index':int(index),'position':list(map(int,np.unravel_index(index,(4,4,6,5,4,2)))),
            '前48':{name:float(front[index,fi]) if np.isfinite(front[index,fi]) else None for fi,name in enumerate(fields)}})
    result=selector169.select_front48(front,bands,fields,book)
    proof={'成功':True,'前48のみの診断':True,'追加七場未読':True,'正本SHA256':sha(source),
        '条件ごと':rows,'先着率以外の支持を満たす数':int(except_rate.sum()),
        '率以外適格の上位':best,'A適格':int(result['A']['eligible'].sum()),'B適格':int(result['B']['eligible'].sum()),
        'PF無限大の前半政策':int(np.isinf(v['pf']).sum()),'前48q0帯のPF無限大セル':int(np.isinf(b['pf']).sum()),
        '注意':'条件解除は原因診断のみ。固定A/Bの条件を緩和しない。前後は既使用。'}
    (folder/'前半不適格の原因.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    text='# 169 前半固定A/Bが空になった理由\n\n2026-11-15。固定支持を変更せず前48だけを診断。A/Bはnullのまま保持する。追加7場の成績は未読。\n\n'
    text+='|条件|単独通過|左から累積|この条件だけ外す|\n|---|---:|---:|---:|\n'
    for row in rows:text+='|'+str(row['条件'])+'|'+str(row['単独通過'])+'|'+str(row['順に累積通過'])+'|'+str(row['当条件だけ外す適格'])+'|\n'
    if best:
        value=best[0]['前48'];text+=f"\n先着率以外を満たす最も高率の候補は、{int(value['count'])}取得、{int(value['F'])}順{int(value['A'])}逆、{value['rate']:.3%}。stable index {best[0]['stable_index']}。これは採用候補ではなく不足幅の診断。\n"
    text+='\n幅/期限が長いほど独立合算では積み増せた入口が数量枠で棄却され、先着分布も変わる。元の無制限成績を10枚へ増幅することや、前半支持の不成立を後半・追加7の好成績で救うことはしない。次仮説は新試行へ分け、どの役割の入口が数量枠を使いどの失速/伸長局面を落としたかを比較する。\n'
    (folder/'前半不適格の原因.md').write_text(text,encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':main()
