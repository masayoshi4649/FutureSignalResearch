"""169保存配列の全不変式と168固定二案同体を自己確認する。"""
from pathlib import Path
import hashlib
import json
import numpy as np
import selector169

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 検査対象を物理指紋化する。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    with path.open('rb') as source:return hashlib.file_digest(source,'sha256').hexdigest()


def main() -> None:
    """
    機能: 全政策の期間/帯加法・上限・枝件数・A/B再計算と旧168二案同体を確認する。
    引数: なし。旧73保存結果だけを読み、新7場は開かない。
    返り値: None。自己確認票を残す。全3840を別engineで再生した検査ではない。
    """
    folder=HERE/'旧73探索';axes=json.loads((folder/'統計軸.json').read_bytes());fields=axes['fields'];f={name:i for i,name in enumerate(fields)}
    path=folder/'数量枠探索の統計配列.npz'
    with np.load(path,allow_pickle=False) as source:
        values=source['metrics'].reshape(3840,3,len(fields));bands=source['bands'].reshape(3840,3,2,3,len(fields))
    additive=('count','F','A','N','C','profit','loss','net','known','unknown','wins','loss_trades',
        'core_count','old_technical_count','local_technical_count')
    for name in additive:
        i=f[name];assert np.array_equal(values[:,0,i],values[:,1,i]+values[:,2,i]),name
        for clock in (0,1):assert np.array_equal(values[:,:,i],bands[:,:,clock,:,i].sum(axis=2)),(name,clock)
    assert np.array_equal(values[:,:,f['F']]+values[:,:,f['A']]+values[:,:,f['N']]+values[:,:,f['C']],values[:,:,f['count']])
    assert np.array_equal(values[:,:,f['C']],values[:,:,f['unknown']])
    assert np.array_equal(values[:,:,f['known']]+values[:,:,f['unknown']],values[:,:,f['count']])
    assert np.array_equal(values[:,:,f['profit']]-values[:,:,f['loss']],values[:,:,f['net']])
    assert np.array_equal(values[:,:,f['core_count']]+values[:,:,f['old_technical_count']]+values[:,:,f['local_technical_count']],values[:,:,f['count']])
    assert np.all((values[:,:,f['peak_reserved_buy']]<=10)&(values[:,:,f['peak_reserved_sell']]<=10))
    for name in ('quantity_rejected_core','quantity_rejected_technical'):
        i=f[name];assert np.array_equal(values[:,0,i],values[:,1,i]+values[:,2,i])
    old=json.loads((ROOT/'work/168数量枠の因果再生/旧73比較/二案の数量比較.json').read_bytes())
    tested=[]
    for record,position in zip(old['rows'],((1,2,2,3,1,1),(3,0,4,3,2,0)),strict=True):
        index=np.ravel_multi_index(position,(4,4,6,5,4,2));count=0
        for pi,period in enumerate(axes['periods']):
            for name,wanted in record['cap10']['periods'][period].items():
                if name not in f:continue
                actual=values[index,pi,f[name]]
                if wanted is None:assert np.isnan(actual),(record['id'],period,name)
                else:assert actual==wanted,(record['id'],period,name)
                count+=1
        assert values[index,0,f['quantity_rejected_core']]==record['cap10']['quantity_rejected_core']
        tested.append({'id':record['id'],'position':list(position),'三期間同体欄':count})
    book=json.loads((ROOT/'study/00169_数量枠の下で技術近傍と任意幅を再探索する/条件.json').read_bytes())
    selection=selector169.select_front48(values[:,1],bands[:,1,0],fields,book)
    sealed=json.loads((folder/'前半固定AとBの封印.json').read_bytes())
    assert sealed['選択']=={'A':None,'B':None}
    assert selection['A']['position'] is selection['B']['position'] is None
    proof={'成功':True,'自己確認の範囲':'全保存配列の不変式/168固定二案同体/前半選択再計算。別実装による全自然再生ではない。',
        '追加七場未読':True,'政策数':3840,'期間数':3,'帯時計数':2,'各三帯':3,
        '全期前後と三帯加法指標':list(additive),'168同体':tested,'AとBの封印不変':True,
        '統計正本SHA256':sha(path),'SourceSHA256':sha(Path(__file__))}
    (folder/'自然統計の自己確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':main()
