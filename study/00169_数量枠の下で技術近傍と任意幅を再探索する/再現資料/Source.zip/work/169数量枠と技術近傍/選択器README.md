# 169 前48場だけの固定A/B選択器

2026-11-15。`selector169.select_front48(metrics, bands, fields, book)` は、前48場の統計 `[政策,指標]` とq0三帯 `[政策,3,指標]`、一意の列名、固定bookのみを受け取る純関数。自然実行は3,840政策を安定した入力順で渡す。ファイル取得・後25場・追加七場・167結果を読む処理はない。

返り値の `A` / `B` に `eligible`（真偽配列）、`ranking`（安定入力添字）、`position`（先頭添字又はNone）、`score`（Wilson95%下限又はNone）を持つ。共通 `derived` と `band_derived` に計算根拠、`band_eligible` に三帯の適格、`stable_position` に入力添字を残す。

Aは固定base_support、BはAかつ各帯到達6以上・率55%以上・PF1.05以上・差引正。順位はWilson95%下限降順→取得数降順→PF降順→安定添字昇順。minimum_net=0は差引正と解釈する。Wilson下限は順位用であり、近接取得の独立性や未見成績を保証しない。

率はF/(F+A)、PFは費用後利益/損失から再算出する。損失0利益正は∞、両0は未定義で不適格。保存pf欄の未定義値は順位へ直接使わない。全48場はall_scenes=1とscenes=48の両方を要求し、未知比はunknown/count。FANC、既知/未知、利益損失/差引、q0三帯分解を検査し、不整合は例外で止める。ゼロ到達率は未定義。

必要列は `count,F,A,N,C,known,unknown,profit,loss,net,scenes,all_scenes,per_hour`。`rate` があると基本計数との同体も検査する。他の共通統計列は使用しない。全期などの期間軸や、後半・未来情報用の追加引数は受理しない。前48場だけを渡す責任とbookの物理SHA検査はrunner側にも保持する。

```powershell
& 'work/複合テクニカル学習環境/Scripts/python.exe' -X utf8 'work/169数量枠と技術近傍/選択器を人工確認する.py'
```

固定book SHA256：`526d2c7bacf2ca3b3050ddbbb152ff9e26a8659515a5ef33166266f3a395b884`。
