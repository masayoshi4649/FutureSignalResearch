"""169選択器を自然入力なしの支持境界・順位・漏洩APIで人工確認する。"""
from pathlib import Path
import copy
import hashlib
import inspect
import json
import math
import numpy as np
import selector169 as M

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
BOOK=ROOT/'study/00169_数量枠の下で技術近傍と任意幅を再探索する/条件.json'
BOOK_SHA='526d2c7bacf2ca3b3050ddbbb152ff9e26a8659515a5ef33166266f3a395b884'
FIELDS=list(M.REQUIRED)+['rate','pf']


def sha(path: Path) -> str:
    """
    機能: 条件と選択器の物理指紋を計算する。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    with path.open('rb') as source:return hashlib.file_digest(source,'sha256').hexdigest()


def policy(count: int=250,f: int=70,a: int=30,unknown: int=25,
           profit: float=120.,loss: float=100.) -> tuple:
    """
    機能: 前48全体と、整数分割した整合するq0三帯を作る。
    引数: count/f/a/unknown(int)、profit/loss(float)。
    返り値: tuple[np.ndarray,np.ndarray]は一政策の全体と三帯。
    """
    def split(value: int) -> list:
        """
        機能: 非負整数を和が同じ三分割へする。
        引数: value(int)。
        返り値: list[int]は差が最大1の三分割。
        """
        return [value//3+(i<value%3) for i in range(3)]
    band=[]
    for c,ff,aa,u in zip(split(count),split(f),split(a),split(unknown),strict=True):
        pp=profit/3;ll=loss/3
        record={'count':c,'F':ff,'A':aa,'N':c-ff-aa-u,'C':u,'known':c-u,'unknown':u,
            'profit':pp,'loss':ll,'net':pp-ll,'scenes':min(48,c),'all_scenes':1,'per_hour':.75,
            'rate':ff/(ff+aa) if ff+aa else np.nan,'pf':np.nan}
        band.append([record[k] for k in FIELDS])
    total={'count':count,'F':f,'A':a,'N':count-f-a-unknown,'C':unknown,'known':count-unknown,'unknown':unknown,
        'profit':profit,'loss':loss,'net':profit-loss,'scenes':min(48,count),'all_scenes':1,'per_hour':.75,
        'rate':f/(f+a) if f+a else np.nan,'pf':np.nan}
    return np.array([total[k] for k in FIELDS]),np.array(band)


def select(book: dict,policies: list) -> dict:
    """
    機能: 人工政策を安定順に積み、固定選択器へ渡す。
    引数: book(dict)、policies(list[tuple])。
    返り値: dictは純選択器の返り値。
    """
    return M.select_front48(np.stack([p[0] for p in policies]),np.stack([p[1] for p in policies]),FIELDS,book)


def expect_error(callback: object) -> None:
    """
    機能: 不整合又は未来引数が拒否されることを確認する。
    引数: callback(callable)は人工呼出し。
    返り値: None。ValueError/TypeErrorでなければ停止。
    """
    try:callback()
    except (ValueError,TypeError):return
    raise AssertionError('拒否すべき入力が受理された')


def main() -> None:
    """
    機能: 基本支持・B三帯・PF例外・順位・後半引数禁止を人工確認する。
    引数: なし。固定bookだけを読み自然値を取得しない。
    返り値: None。人工確認票をworkへ保存する。
    """
    assert sha(BOOK)==BOOK_SHA;book=json.loads(BOOK.read_text(encoding='utf-8'));checks=[]
    base=policy();r=select(book,[base]);assert r['A']['position']==r['B']['position']==0
    assert r['derived']['unknown_fraction'][0]==.1 and r['derived']['rate'][0]==.7
    checks.append('取得250・到達100・率70%・頻度0.75・未知10%・PF1.2の等号は適格')
    for title,data in [('取得数',policy(count=249)),('到達数',policy(f=70,a=29)),
        ('率',policy(f=69,a=31)),('未知',policy(unknown=26)),('PF',policy(profit=119.99))]:
        value=select(book,[data]);assert value['A']['position'] is None,title
    for name,value in [('per_hour',.749999),('all_scenes',0),('scenes',47)]:
        data=copy.deepcopy(base);data[0][FIELDS.index(name)]=value
        assert select(book,[data])['A']['position'] is None,name
    checks.append('各基本支持の境界直下・全場boolean偽・取得47場を不適格')
    for data in (policy(profit=0,loss=0),policy(profit=100,loss=100),policy(profit=0,loss=10)):
        assert select(book,[data])['A']['position'] is None
    inf=select(book,[policy(profit=120,loss=0)]);assert inf['A']['position']==0 and np.isinf(inf['derived']['pf'][0])
    assert np.isnan(select(book,[policy(profit=0,loss=0)])['derived']['pf'][0])
    checks.append('損失0利益正はPF∞、両0はPF未定義、差引0/負は不適格')
    # ----------------------------------------
    m,b=base;bad_b=b.copy();fi=FIELDS.index('F');ai=FIELDS.index('A');ni=FIELDS.index('N');ri=FIELDS.index('rate')
    bad_b[0,fi]-=6;bad_b[0,ai]+=6;bad_b[1,fi]+=6;bad_b[1,ai]-=6
    bad_b[:,ri]=bad_b[:,fi]/(bad_b[:,fi]+bad_b[:,ai])
    r=select(book,[(m,bad_b)]);assert r['A']['position']==0 and r['B']['position'] is None
    low=b.copy();low[0,FIELDS.index('profit')]=34.;low[1,FIELDS.index('profit')]=46.
    low[:,FIELDS.index('net')]=low[:,FIELDS.index('profit')]-low[:,FIELDS.index('loss')]
    r=select(book,[(m,low)]);assert r['A']['position']==0 and r['B']['position'] is None
    checks.append('全体支持は維持して三帯率/PFだけを悪化させるとA適格・B不適格')
    for ff,aa,wanted in [([4,33,33],[2,14,14],True),([4,33,33],[1,14,15],False),
        ([11,29,30],[9,10,11],True),([10,30,30],[10,10,10],False)]:
        special=b.copy();special[:,fi]=ff;special[:,ai]=aa
        special[:,ni]=special[:,FIELDS.index('count')]-special[:,fi]-special[:,ai]-special[:,FIELDS.index('C')]
        special[:,ri]=special[:,fi]/(special[:,fi]+special[:,ai])
        got=select(book,[(m,special)]);assert bool(got['B']['eligible'][0])==wanted
    for first_profit,wanted in [(21.,True),(20.99999,False),(20.,False)]:
        special=b.copy();special[:,FIELDS.index('profit')]=[first_profit,(120-first_profit)/2,(120-first_profit)/2]
        special[:,FIELDS.index('loss')]=[20.,40.,40.]
        special[:,FIELDS.index('net')]=special[:,FIELDS.index('profit')]-special[:,FIELDS.index('loss')]
        assert bool(select(book,[(m,special)])['B']['eligible'][0])==wanted
    checks.append('B各帯6到達/55%/PF1.05の等号と直下、差引正の境界を確認')
    for key,edit in [('到達',lambda x:x.__setitem__((0,fi),0)),('FANC',lambda x:x.__setitem__((0,ni),-1))]:
        broken=b.copy();edit(broken);expect_error(lambda:M.select_front48(m[None,:],broken[None,:,:],FIELDS,book))
    checks.append('F+A+N+C、非負整数、全体と三帯分解不整合を拒否')
    # ----------------------------------------
    repeated=select(book,[base,base,base]);assert repeated['A']['ranking'].tolist()==[0,1,2]
    high_count=policy(count=300);rank=select(book,[base,high_count]);assert rank['A']['position']==1
    high_pf=policy(profit=130);rank=select(book,[base,high_pf]);assert rank['A']['position']==1
    infinite=policy(profit=120,loss=0);rank=select(book,[high_pf,infinite]);assert rank['A']['position']==1
    high_wilson=policy(f=140,a=60,count=350,unknown=25);rank=select(book,[high_pf,high_wilson])
    assert rank['A']['position']==1
    rank=select(book,[policy(f=99,a=1),policy(f=140,a=60,count=350)])
    assert rank['A']['position']==0
    checks.append('Wilson下限→count→PF→安定添字、完全同点の入力順、適格なしNone')
    n=100;p=.7;z=M.Z95;expected=(p+z*z/(2*n)-z*math.sqrt((p*(1-p)+z*z/(4*n))/n))/(1+z*z/n)
    assert abs(repeated['A']['score']-expected)<1e-14
    checks.append('Wilson95%下限を独立スカラー式と照合')
    # ----------------------------------------
    signature=inspect.signature(M.select_front48);assert tuple(signature.parameters)==('metrics','bands','fields','book')
    expect_error(lambda:M.select_front48(m[None,:],b[None,:,:],FIELDS,book,after25=np.zeros((1,))))
    expect_error(lambda:M.select_front48(m[None,:],b[None,:,:],FIELDS,book,future=np.zeros((1,))))
    expect_error(lambda:M.select_front48(np.zeros((1,3,len(FIELDS))),b[None,:,:],FIELDS,book))
    poisoned=copy.deepcopy(book);poisoned['future_net']=10**90;poisoned['after25']={'rate':1.}
    left=select(book,[base,high_pf]);right=select(poisoned,[base,high_pf])
    assert left['A']['ranking'].tolist()==right['A']['ranking'].tolist() and left['B']['ranking'].tolist()==right['B']['ranking'].tolist()
    checks.append('後半/未来引数と全期期間軸を拒否、book未使用の未来毒は順位不変')
    changed=copy.deepcopy(book);changed['base_support']['minimum_rate']=.69
    expect_error(lambda:select(changed,[base]))
    assert sha(BOOK)==BOOK_SHA
    proof={'成功':True,'範囲':'自然成績未入力の169純選択器人工確認。後25場・追加七場・167結果ファイル未読。',
        '検査群':checks,'固定bookSHA256':BOOK_SHA,'選択器SHA256':sha(HERE/'selector169.py'),
        '人工SourceSHA256':sha(Path(__file__)),'selector_sourceSHA256':sha(HERE/'selector169.py'),
        'API':str(signature),'自然値読取':False}
    (HERE/'選択の人工確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':main()
