"""182の正式ZIPと親参照・42CSVを、保存器に依存しない標準処理で最終点検する。"""
from pathlib import Path, PurePosixPath
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).parent
FORMAL = ROOT / 'study/00182_反転の危険局面と値幅に応じた保護を組み合わせる/再現資料'
EXPECTED = 'c3346029d2e9b19cf3cd47e895623c37d703c1cd889af92fb2b64047931f7268'


def ref(path: Path) -> dict:
    """
    機能: ZIP・索引・CSVの元byte指紋を独立に取得する。
    引数: path(Path)。
    返り値: dictは相対path/bytes/sha256。
    """
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size, 'sha256': digest}


def main() -> None:
    """
    機能: 新ZIP全member・旧正式依存・README・CSV42指紋を読み取りだけで照合する。
    引数: なし。
    返り値: None。独立確認JSONを作る。Source/金融/正式ZIPは変更しない。
    """
    index_path = FORMAL / '保存索引.json'
    assert ref(index_path)['sha256'] == EXPECTED
    index = json.loads(index_path.read_text(encoding='utf-8'))
    assert index['成功'] and index['正式保存']
    checked = {}; count = 0; references = 0
    def archive(node: dict, exact: bool = False, current: bool = False) -> None:
        """
        機能: 一つの正式ZIPを全CRCとmember元byteへ照合する。
        引数: node(dict)、exact(bool)はmember集合一致、current(bool)は新成果物の現byte照合。
        返り値: None。旧文書の現在byteを過去snapshotの正本にはしない。
        """
        nonlocal count, references
        path = ROOT / node['archive']['path']
        assert ref(path) == node['archive']
        if 'index' in node:
            assert ref(ROOT / node['index']['path']) == node['index']
            references += 1
        with zipfile.ZipFile(path) as data:
            names = data.namelist()
            assert len(names) == len(set(names)) and data.testzip() is None
            for name in names:
                posix = PurePosixPath(name)
                assert not posix.is_absolute() and '..' not in posix.parts and ':' not in name and '\\' not in name
            wanted = node.get('members', [])
            if exact:
                assert set(names) == {item['path'] for item in wanted}
            for item in wanted:
                body = data.read(item['path'])
                assert len(body) == item['bytes'] and hashlib.sha256(body).hexdigest() == item['sha256']
                if current:
                    assert (ROOT / item['path']).read_bytes() == body
                count += 1
        checked[node['archive']['path']] = {'members': len(names), 'archive': node['archive']}
    archive(index['Source'], True, True)
    archive(index['正本'], True, True)
    def walk(value: object) -> None:
        """
        機能: Source連鎖と親正本を辞書/配列参照から辿る。
        引数: value(object)は保存索引の枝。
        返り値: None。member一覧を通常ファイル参照と誤認しない。
        """
        if isinstance(value, list):
            for item in value:
                walk(item)
        elif isinstance(value, dict):
            if 'archive' in value:
                archive(value)
            for key, item in value.items():
                if key not in ('members', 'archive', 'index'):
                    walk(item)
    for key in ('Source継承元', '正本継承元', '親正本参照'):
        walk(index[key])
    for group in ('金融前固定', '全純入口封印', '固定七候補'):
        value = index['完了gate'][group]
        assert ref(ROOT / value['path']) == value
        references += 1
    for group in ('独立検査', '共用恒久入力参照', 'CSV'):
        for value in index['完了gate'][group]:
            assert ref(ROOT / value['path']) == value
            references += 1
    assert ref(ROOT / index['README']['path']) == index['README']
    references += 1
    exporter = index['CSV出力器継承']
    with zipfile.ZipFile(ROOT / exporter['archive']['path']) as data:
        body = data.read(exporter['member']['path'])
        assert len(body) == exporter['member']['bytes']
        assert hashlib.sha256(body).hexdigest() == exporter['member']['sha256']
        assert (ROOT / exporter['member']['path']).read_bytes() == body
    csv = index['完了gate']['CSV']
    output = ROOT / 'outputs/00182_反転確認と値幅保護の比較'
    assert len(csv) == 42 and {item['path'] for item in csv} == {path.relative_to(ROOT).as_posix() for path in output.rglob('*.csv')}
    regenerated = json.loads((ROOT / 'work/182正式保存/再生成確認.json').read_text(encoding='utf-8'))
    assert regenerated['成功'] and regenerated['三期間pack数'] == 21
    assert regenerated['全81連結正本同体'] == regenerated['利益後赤字診断同体'] == 7
    assert ref(index_path)['sha256'] == EXPECTED
    body = {'成功': True, '正式Source変更なし': True, '新計算なし': True,
        '索引': ref(index_path), '新Source数': len(index['Source']['members']), '新正本数': len(index['正本']['members']),
        'ZIP参照数': len(checked), 'member照合回数': count, '外部指紋照合数': references,
        '全42CSV指紋': True, 'Source継承とCSV出力器元byte': True,
        'README指紋': ref(ROOT / index['README']['path']), '再生成21期間/全81七案/含み益七案票': True,
        'ZIP': checked, '検査Source': ref(Path(__file__))}
    (HERE / '正式保存の独立確認.json').write_text(json.dumps(body, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({key: value for key, value in body.items() if key != 'ZIP'}, ensure_ascii=False))


if __name__ == '__main__':
    main()
