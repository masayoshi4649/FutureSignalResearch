"""固定した比較候補を、期間別正本から全81場の閲覧用正本へまとめる。"""
from pathlib import Path
import gzip
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).parent
sys.path.insert(0, str(ROOT/'work/181反省を分解した改善'))
import 集計181 as A
import 利益後赤字を調べる as M


def main() -> None:
    """
    機能: 閲覧名で指定した候補を結合し、利益後赤字も実保有内だけで集計する。
    引数: なし。閲覧名.jsonの候補IDを使用。
    返り値: None。金融値や候補順位を変更しない。
    """
    names = json.loads((HERE/'閲覧名.json').read_text(encoding='utf-8'))
    rows = []
    for name in names:
        packs = [json.loads(gzip.decompress((HERE/'期間別'/leg/(name+'.json.gz')).read_bytes()))
                 for leg in ('旧73', '追加7', '本日1')]
        row = A.combine(packs)
        if '追尾診断' in packs[0]:
            row['追尾診断'] = sum((p['追尾診断'] for p in packs), [])
        row['全80比較'] = A.combine(packs[:2])['evidence']
        rows.append(row)
    body = json.dumps({'rows': rows}, ensure_ascii=False, separators=(',', ':'), allow_nan=False)+'\n'
    (HERE/'保存する候補.json.gz').write_bytes(gzip.compress(body.encode(), mtime=0))
    result = [M.diagnose(row) for row in rows]
    (HERE/'利益後赤字の比較.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'候補数': len(rows), '全81場': all(len(r['sessions']) == 81 for r in rows)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
