"""182全84pack完成後に、旧対照同体と自然金融・参加・期間順位を独立確認する。"""
from pathlib import Path
import gzip
import importlib.util
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
RUN = ROOT / 'work/182局面と値幅の改善'
OLD = ROOT / 'work/181反省を分解した改善/期間別'
CONDITION = ROOT / 'study/00182_反転の危険局面と値幅に応じた保護を組み合わせる/条件.json'
helper = ROOT / 'work/181利益保護/入口固定の出口を独立集計する.py'
spec = importlib.util.spec_from_file_location('independent_exit181_for182', helper)
D = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = D
spec.loader.exec_module(D)
I = D.I

# ----------------------------------------


def summarize(pack: dict, evidence: dict | None, label: str, counter: dict) -> dict:
    """
    機能: 台帳から金融・保有・場末DD・上位三場除外後収支を独立集計する。
    引数: pack(dict)、evidence(dict|None)は正本、label(str)、counter(dict)。
    返り値: dictはDAY/NIGHTの要約。未知群のDDは既知寄与と完全を区別する。
    """
    calculated = D.calculate(pack, evidence, label, counter)
    result = {name: calculated['要約'][name] for name in ('DAY', 'NIGHT')}
    for band, row in result.items():
        group = calculated['金融'][band]
        scene_rows = group['sessions']['rows']
        if not scene_rows:
            row.update(DD完全=None, DD既知寄与=None, DD区分='対象なし', 上位3場除外後=None)
            continue
        risk = I.Q.full_risk(group)
        if evidence is not None:
            actual = {key: value for key, value in evidence['concentration'][band]['path'].items()
                      if key not in ('version', 'notes')}
            I.V.compare(risk, actual, label + '/' + band + '/経路', counter)
        positive = sorted([value for value in scene_rows if value['known_net'] > 0],
                          key=lambda value: (-value['known_net'], value['scene']))[:3]
        remaining = sum(value['known_net'] for value in scene_rows) - sum(value['known_net'] for value in positive)
        if evidence is not None:
            I.V.compare(remaining,
                evidence['concentration'][band]['concentration']['positive_scene_net']['top'][1]['remaining']['known_net'],
                label + '/' + band + '/上位3除外', counter)
        row.update(DD完全=risk['exact_path']['max_drawdown_amount'] if risk['exact_path'] else None,
                   DD既知寄与=risk['known_contribution']['max_drawdown_amount'],
                   DD区分='完全' if risk['exact_path'] else '既知寄与', 上位3場除外後=remaining)
    return result


def rank(row: dict, band: str, baseline: dict) -> tuple:
    """
    機能: 金融前の固定辞書順だけで全80又は前48の順位を独立に計算する。
    引数: row/baseline(dict)は独立要約、band(str)。
    返り値: tupleは大きいほど優先。本日1と全81を参照しない。
    """
    a, b = row[band], baseline[band]
    suitable = (a['両中央値'] == '適合' and a['保有下限'] is not None and a['保有下限'] >= .2
                and a['参加場'] == a['対象場'] and a['金融未知'] <= b['金融未知'])
    n = max(1, a['対象場'])
    return (suitable, a['完全黒字場'] / n, (a['上位3場除外後'] or 0) / n,
            a['利益損失比'] or 0, -(a['DD既知寄与'] or 0), a['保有下限'] or 0)


def make_document(rows: dict, rankings: dict, counter: dict, control_count: int) -> str:
    """
    機能: 全80主比較と前48・本日診断を分け、候補の強弱を表にまとめる。
    引数: rows/rankings(dict)、counter(dict)、control_count(int)。
    返り値: strは日本語Markdown。
    """
    text = ['# 182の旧対照と自然比較の独立所見', '',
        f'全84pack完成後に確認。旧対照6政策×3期間={control_count}組はevidence・ledger・selection・engine・positions・sessions・追尾scalarが同体。候補ID以外の差を許していない。', '',
        f"全28政策の金融・保有・DD・集中と、全80/前48の順位を独立再計算し、{counter['scalar']:,}項目を照合した。Source・入力指紋は不変。",
        '', '金額はmini1枚の費用後円。金融未知がある場合の収支とDDは既知寄与を表示し、完全な収支/DDと区別する。全80が主比較、前48が過去順の選択。本日1/全81は診断専用で未見検証ではない。', '',
        '## 全80デイの全28政策', '',
        '| 政策 | 取得 | 利益 | 損失 | 既知収支 | PF | 場中央値下限 | 建玉中央値下限 | 保有下限 | 未知 | DD | DD区分 | 参加場 | 黒字場 | 上位3場除外後 |',
        '|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|---:|---:|']
    for name in sorted(rows):
        a = rows[name]['全80']['DAY']
        values = [name, D.shown(a['取得']), D.shown(a['利益']), D.shown(a['損失']), D.shown(a['既知収支']),
                  D.shown(a['利益損失比'], ratio=True), D.shown(a['場中央値下限']), D.shown(a['建玉中央値下限']),
                  D.shown(a['保有下限'], percent=True), D.shown(a['金融未知']), D.shown(a['DD既知寄与']),
                  a['DD区分'], f"{a['参加場']}/{a['対象場']}", D.shown(a['完全黒字場']), D.shown(a['上位3場除外後'])]
        text.append('| ' + ' | '.join(values) + ' |')
    text += ['', '## 全80ナイトの出口七案', '',
        '入口四案の夜間台帳が同体であることを別確認したためE182_00だけを表示する。', '',
        '| 出口 | 利益 | 損失 | 既知収支 | PF | 場中央値下限 | 建玉中央値下限 | 保有下限 | 未知 | 既知寄与DD |',
        '|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
    for name in sorted(key for key in rows if key.startswith('E182_00__')):
        a = rows[name]['全80']['NIGHT']
        values = [name.split('__')[1], D.shown(a['利益']), D.shown(a['損失']), D.shown(a['既知収支']),
                  D.shown(a['利益損失比'], ratio=True), D.shown(a['場中央値下限']), D.shown(a['建玉中央値下限']),
                  D.shown(a['保有下限'], percent=True), D.shown(a['金融未知']), D.shown(a['DD既知寄与'])]
        text.append('| ' + ' | '.join(values) + ' |')
    selected = list(dict.fromkeys([rankings[key][0] for key in ('DAY_全80', 'DAY_前48', 'NIGHT_全80', 'NIGHT_前48')]))
    selected += ['E182_01__F150_W125_OPEN']
    selected = list(dict.fromkeys(selected))
    text += ['', '## 固定順位の先頭と損失軽減対照の期間差', '',
        '| 政策 | 帯 | 前48収支 | 後25収支 | 追加7収支 | 本日1収支 | 全80両中央値 | 全80保有下限 |',
        '|---|---|---:|---:|---:|---:|---|---:|']
    for name in selected:
        for band in ('DAY', 'NIGHT'):
            a = rows[name]['全80'][band]
            values = [name, band, *[D.shown(rows[name][period][band]['既知収支']) if rows[name][period][band]['対象場'] else '対象なし'
                                   for period in ('前48', '後25', '追加7', '本日1')],
                      a['両中央値'], D.shown(a['保有下限'], percent=True)]
            text.append('| ' + ' | '.join(values) + ' |')
    text += ['', '## 本日1デイ・全政策の診断', '',
        '| 政策 | 利益 | 損失 | 収支 | 回数 | 保有下限 |', '|---|---:|---:|---:|---:|---:|']
    for name in sorted(rows):
        a = rows[name]['本日1']['DAY']
        text.append('| ' + ' | '.join([name, D.shown(a['利益']), D.shown(a['損失']), D.shown(a['既知収支']),
                                       D.shown(a['取得']), D.shown(a['保有下限'], percent=True)]) + ' |')
    text += ['', '## 所見', '',
        '固定順位の先頭は全80デイE182_00＋C0_IFD、前48デイE182_03＋C0_IFD。全80・前48のナイト先頭は元IFDである。相対幅にした追尾も、全期の基準入口＋IFDを全面的に置き換える結果ではない。',
        '', '利益の大きさ、損失総額、DD、黒字場数、保有参加、追加期の弱さは同じ評価ではない。入口確認＋保護が損失やDDを減らす場合も、減った利益と前半選択後の後半を併記して判断する。',
        '', 'E182_02＋C0は、基準より利益21,077円増・損失23,077円減で収支+44,154円、PF1.983、DD65,231円は同じ。しかし黒字場は31→30、上位3場除外後収支は666,682→630,605円へ下がるため、固定した安定順位では基準の後となる。本日も−100,462円で基準の−93,539円より悪い。',
        '', '入口E182_01の中ではR075固定とATRが、C0に対し利益13,231円減・損失91,231円減で収支+78,000円、DD74,154→70,001円へ改善した。全40場取得・未知0・両中央値正・保有43.63%も維持する。この二つのデイ台帳は三期間で同体なので、独立した二成功とは数えない。',
        '', 'E182_01＋旧F150_OPENはDD32,231円・損失740,003円まで減る一方、利益も1,441,916円まで減り、収支701,913円。元の基準より利益と損失の両方を削る保守的な対照として分ける。',
        '', 'ナイトR050は損失743,388→698,234円、既知寄与DD205,539→159,539円へ減らすが、利益も1,548,379→1,435,532円へ減り、既知収支は67,693円低下する。両中央値正・全40場・保有26.66%を維持した損失軽減とのトレードオフである。',
        '', '本日1の改善は診断であり、全80選択を本日結果で交換しない。既使用81場内でのPDCAであるため将来性能の確認にはならない。']
    return '\n'.join(text) + '\n'

# ----------------------------------------


def main() -> None:
    """
    機能: 対照全同体・全28独立集計・全80/前48固定順位を確認して保存する。
    引数: なし。自然結果後の戦略Source・閾値・順位は変更しない。
    返り値: None。旧対照の全期間同体.json、自然比較の独立結果.json、自然比較の所見.mdを保存する。
    """
    condition = D.read(CONDITION)
    exits = condition['出口']['候補']
    entries = condition['入口']['rules']
    names = {entry['id'] + '__' + exit['id'] for entry in entries for exit in exits}
    assert len(entries) == 4 and len(exits) == 7 and len(names) == 28
    legs = ('旧73', '追加7', '本日1')
    paths = [RUN / '期間別' / leg / (name + '.json.gz') for leg in legs for name in sorted(names)]
    for leg in legs:
        assert {path.name for path in (RUN / '期間別' / leg).glob('*.json.gz')} == {name + '.json.gz' for name in names}
    controls = ('C0_IFD', 'F150_W125_TP', 'F150_W125_OPEN')
    old_paths = [OLD / leg / (entry + '__' + exit + '.json.gz') for leg in legs
                 for entry in ('E181_00', 'E181_10') for exit in controls]
    aggregation_path = RUN / '全28組の比較.json.gz'
    sources = [CONDITION, aggregation_path, Path(__file__), helper, Path(I.__file__), Path(I.F.__file__),
               HERE / 'trail182.py', HERE / '候補182.json', ROOT / 'work/181利益保護/trail181.py', *paths, *old_paths]
    before = [D.ref(path) for path in sources]
    counter = {'scalar': 0}
    complete = {leg: {name: D.read(RUN / '期間別' / leg / (name + '.json.gz')) for name in names} for leg in legs}
    checks = []
    for leg in legs:
        for entry, old_entry in [('E182_00', 'E181_00'), ('E182_01', 'E181_10')]:
            for exit in controls:
                name = entry + '__' + exit
                old = D.read(OLD / leg / (old_entry + '__' + exit + '.json.gz'))
                new = complete[leg][name]
                assert new['policy']['exit'] == old['policy']['exit']
                for field in ('evidence', 'ledger', 'selection', 'engine', 'positions', 'sessions'):
                    assert old[field] == new[field], (leg, name, field)
                    I.V.compare(old[field], new[field], leg + '/' + name + '/' + field, counter)
                assert old.get('追尾診断') == new.get('追尾診断'), (leg, name, '追尾診断')
                checks.append({'期間': leg, '182': name, '181': old_entry + '__' + exit,
                               '全指定属性同体': True, '取得数': len(new['ledger']['net'])})
    prior_counters = counter.copy()
    results = {}
    for name in sorted(names):
        packs = {leg: complete[leg][name] for leg in legs}
        values = {leg: summarize(pack, pack['evidence'], name + '/' + leg, counter) for leg, pack in packs.items()}
        old = packs['旧73']
        assert len(old['sessions']) == 73
        for period, scenes in [('前48', old['sessions'][:48]), ('後25', old['sessions'][48:])]:
            values[period] = summarize(D.subset(old, scenes), old['periods'][period], name + '/' + period, counter)
        values['全80'] = summarize(D.merge([packs['旧73'], packs['追加7']]), None, name + '/全80', counter)
        values['全81'] = summarize(D.merge([packs[leg] for leg in legs]), None, name + '/全81', counter)
        results[name] = values
    aggregate = D.read(aggregation_path)
    rankings = {}
    for band in ('DAY', 'NIGHT'):
        for period in ('全80', '前48'):
            baseline = results['E182_00__C0_IFD'][period]
            rankings[band + '_' + period] = sorted(sorted(names), key=lambda name: rank(results[name][period], band, baseline), reverse=True)
            assert rankings[band + '_' + period] == aggregate['順位'][band + '_' + period]
    for exit in exits:
        for leg in legs:
            baseline = D.subset(complete[leg]['E182_00__' + exit['id']],
                                [row for row in complete[leg]['E182_00__' + exit['id']]['sessions'] if row['kind'] == 'NIGHT'])
            for entry in entries[1:]:
                compared = D.subset(complete[leg][entry['id'] + '__' + exit['id']], baseline['sessions'])
                assert baseline == compared, (leg, exit['id'], entry['id'], '夜間同体')
    day_duplicate = []
    for entry in entries:
        matches = []
        for leg in legs:
            pair = [complete[leg][entry['id'] + '__' + exit] for exit in ('R075_W050_TP', 'A075_ATR2_TP')]
            scenes = [row for row in pair[0]['sessions'] if row['kind'] == 'DAY']
            matches.append(D.subset(pair[0], scenes) == D.subset(pair[1], scenes))
        if all(matches):
            day_duplicate.append(entry['id'])
    assert 'E182_01' in day_duplicate
    assert before == [D.ref(path) for path in sources]
    controls_proof = {'成功': True, '比較政策': 6, '比較期間': 3, '全組数': len(checks), '照合項目': prior_counters,
                      '照合': checks, '注意': 'policy/idだけが別名称。金融・参加・実時刻・全要求は同体。'}
    (HERE / '旧対照の全期間同体.json').write_text(json.dumps(controls_proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    proof = {'成功': True, '再選択なし': True, 'Source入力不変': True, '全84pack完成後': True,
             '政策数': len(names), '照合項目': counter, '資料': before, '独立順位': rankings,
             '候補': results, '旧対照全組数': len(checks), 'R075とATRのデイ三期間同体': day_duplicate}
    (HERE / '自然比較の独立結果.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    (HERE / '自然比較の所見.md').write_text(make_document(results, rankings, counter, len(checks)), encoding='utf-8')
    print(json.dumps({'成功': True, '旧対照組数': len(checks), '政策数': len(names), '照合項目': counter,
                      '独立順位先頭': {key: value[0] for key, value in rankings.items()}}, ensure_ascii=False))


if __name__ == '__main__':
    main()
