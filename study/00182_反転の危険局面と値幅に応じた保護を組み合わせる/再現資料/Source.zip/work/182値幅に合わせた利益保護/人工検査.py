"""元幅に応じた182の起動・追尾条件を、自然金融を使わず確認する。"""
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import sys
import numpy as np
import trail182 as T

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(T.ROOT / 'work/181利益保護'))
spec = importlib.util.spec_from_file_location('artificial181_for182', T.ROOT / 'work/181利益保護/人工検査.py')
P = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = P
spec.loader.exec_module(P)
CATALOG = {candidate['id']: candidate for candidate in T.load_candidates()}

# ----------------------------------------


def main() -> None:
    """
    機能: 小幅TP先行・相対起動・技術幅比較・旧対照同体・遅延を人工板で確認する。
    引数: なし。自然金融結果を読まない。
    返り値: None。人工結果.jsonを保存する。
    """
    checks = []
    horizons = [{'id': 'H100', 'kind': 'strict', 'seconds': 100}, {'id': 'SESSION', 'kind': 'session'}]
    widths = [150, 350, 400]
    relative = [candidate for candidate in CATALOG.values() if candidate['mode'].startswith('relative_')]
    controls = [candidate for candidate in CATALOG.values() if not candidate['mode'].startswith('relative_')]
    for width in [125, *widths]:
        r50 = T.resolve_candidate(CATALOG['R050_W050_TP'], width)
        r75 = T.resolve_candidate(CATALOG['R075_W050_TP'], width)
        atr = T.resolve_candidate(CATALOG['A075_ATR2_TP'], width)
        tight = T.resolve_candidate(CATALOG['T075_ATR2_Q025_TP'], width)
        assert r50['activation_net_pt'] == max(150, width * .5)
        assert r75['activation_net_pt'] == atr['activation_net_pt'] == tight['activation_net_pt'] == max(150, width * .75)
        assert r50['trail_pt'] == r75['trail_pt'] == atr['trail_pt'] == tight['trail_pt'] == width * .5
        assert atr['atr_multiplier'] == tight['atr_multiplier'] == 2
        assert atr['maximum_pt'] == tight['maximum_pt'] == width * .5
        assert atr['minimum_pt'] == tight['minimum_pt'] == min(75, width * .5)
        assert tight['tight_pt'] == width * .25
    checks.append('125/150/350/400ptの起動額・半幅・四分の一幅とATR下限上限を数式へ照合')
    for mirrored in (False, True):
        rows = P.make([0, 1, 2, 100, 141, 200], [-10, 170, 120, 100, 100, 100], mirror=mirrored)
        engine = T.TrailEvaluator(rows, np.asarray([0]), 1100, widths, horizons,
                                  P.technical([1], [40], [.1], [.8], [-1 if not mirrored else 1]))
        for candidate in relative:
            value = engine.evaluate_cell(candidate, 0, int(mirrored), 0, 0)
            assert value['known'] and value['status'] == 1 and value['exit_time'] == 1
            assert not value['trail_activated'] and not value['trail_triggered']
            assert value['points'] == 170 and value['net'] == 15923
    checks.append('元幅150ptの四新案は買売ともTPが先に成立し追尾を起動しない')
    rows = P.make([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 100, 141, 200],
                  [-10, 200, 270, 300, 210, 190, 140, 130, 120, 110, 100, 100, 100])
    tech = P.technical([1], [50], [.1], [.8], [1])
    engine = T.TrailEvaluator(rows, np.asarray([0]), 1100, widths, horizons, tech)
    f50 = engine.evaluate_cell(CATALOG['R050_W050_TP'], 0, 0, 1, 0)
    f75 = engine.evaluate_cell(CATALOG['R075_W050_TP'], 0, 0, 1, 0)
    atr = engine.evaluate_cell(CATALOG['A075_ATR2_TP'], 0, 0, 1, 0)
    tight = engine.evaluate_cell(CATALOG['T075_ATR2_Q025_TP'], 0, 0, 1, 0)
    assert f50['trail_activation_time'] == 1 and f75['trail_activation_time'] == 3
    assert atr['trail_activation_time'] == tight['trail_activation_time'] == f75['trail_activation_time']
    assert f75['trail_trigger_time'] == 8 and f75['exit_time'] == 9 and f75['trail_floor_points'] == 125
    assert atr['trail_trigger_time'] == 5 and atr['exit_time'] == 6 and atr['trail_floor_points'] == 200
    assert tight['trail_trigger_time'] == 4 and tight['exit_time'] == 5 and tight['trail_floor_points'] == 215
    checks.append('R050対R075は起動時点、R075固定対ATR対複合は幅の違いとして分離')
    assert tight['resolved_tight_pt'] == 87.5 and tight['trail_technical_tightenings'] > 0
    assert f75['resolved_activation_net_pt'] == 262.5 and f75['resolved_trail_pt'] == 175
    checks.append('元幅からの具体条件を全scalarへ保存し追尾接触後1秒の実BBOで返済')
    unknown = T.TrailEvaluator(rows, np.asarray([0]), 1100, widths, horizons)
    unknown_atr = unknown.evaluate_cell(CATALOG['A075_ATR2_TP'], 0, 0, 1, 0)
    for field in T.BASE.empty_scalar():
        if field != 'trail_stale_fallbacks':
            P.equal(unknown_atr[field], f75[field])
    assert unknown_atr['trail_stale_fallbacks'] > 0
    checks.append('ATR未知時は元幅半分の固定代替へ戻り床を緩めない')
    rng = np.random.default_rng(182)
    compared = 0
    cells = 0
    for seed in range(8):
        times = np.r_[0, np.arange(1, 141), 141, 200]
        points = np.r_[-10, np.cumsum(rng.choice([-30, -10, 0, 10, 30], 140)), 0, 0]
        for mirrored in (False, True):
            records = P.make(times.tolist(), points.tolist(), mirror=mirrored)
            tech = P.technical([1, 40, 80], [40, 100, 60], [.1, 1, .2], [.8, 1.1, .9], [1, -1, 1])
            old = T.BASE.TrailEvaluator(records, np.asarray([0]), 1100, widths, horizons, tech)
            new = T.TrailEvaluator(records, np.asarray([0]), 1100, widths, horizons, tech)
            for candidate in controls:
                for wi in range(len(widths)):
                    for hi in range(len(horizons)):
                        before = old.evaluate_cell(candidate, 0, int(mirrored), wi, hi)
                        after = new.evaluate_cell(candidate, 0, int(mirrored), wi, hi)
                        assert set(before) == set(after)
                        for field in before:
                            P.equal(before[field], after[field]); compared += 1
                        cells += 1
    checks.append('旧対照三案は181と全scalar同体')
    arrays = engine.evaluate_cells(CATALOG['T075_ATR2_Q025_TP'], [(0, 0, 1, 0)])
    assert arrays['evaluated'].sum() == 1 and arrays['resolved_tight_pt'][0, 0, 1, 0] == 87.5
    checks.append('疎な全軸表も具体設定値を保持する')
    proof = {'成功': True, '自然金融未実行': True, '目的別確認': checks,
             '旧対照同体セル': cells, '旧対照属性比較': compared,
             '候補数': len(CATALOG), '新規': len(relative), '固定対照': len(controls),
             '継承SourceSHA256': T.PARENT_SHA,
             'Source': [{'path': path.name, 'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
                        for path in [HERE / 'trail182.py', HERE / '候補182.json', Path(__file__)]]}
    (HERE / '人工結果.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    print(json.dumps(proof, ensure_ascii=False))


if __name__ == '__main__':
    main()
