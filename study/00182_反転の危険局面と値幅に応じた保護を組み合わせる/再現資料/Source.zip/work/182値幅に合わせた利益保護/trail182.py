"""181の約定時計を継承し、元IFD幅から起動額と追尾幅を決める。"""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
PARENT = ROOT / 'work/181利益保護/trail181.py'
PARENT_SHA = '02b5c30673fef7ec30570144bb0efad231579260a05568819d20783fe871d46c'
assert hashlib.sha256(PARENT.read_bytes()).hexdigest() == PARENT_SHA
spec = importlib.util.spec_from_file_location('trail181_frozen_for182', PARENT)
BASE = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = BASE
spec.loader.exec_module(BASE)

VERSION = '182元IFD幅で解決する保護1'
CONFIG = BASE.CONFIG.copy()
STATUS = BASE.STATUS.copy()

# ----------------------------------------


def load_candidates(path: Path | None = None) -> list[dict]:
    """
    機能: 金融評価前の七候補を読み、旧対照三案の値が181と一致することを確認する。
    引数: path(Path|None)は候補JSON、省略時は候補182.json。
    返り値: list[dict]は旧対照3・新規4の一意ID候補。
    """
    source = HERE / '候補182.json' if path is None else Path(path)
    body = json.loads(source.read_text(encoding='utf-8'))
    assert body['金融評価前固定']
    candidates = body['候補']
    assert len(candidates) == 7 and len({value['id'] for value in candidates}) == 7
    prior = {value['id']: value for value in BASE.load_candidates()}
    for value in candidates:
        if not value['mode'].startswith('relative_'):
            assert value == prior[value['id']]
    return candidates


def resolve_candidate(candidate: dict, width: float) -> dict:
    """
    機能: 当該セルの元幅だけを使い、181が受け取る具体的な保護条件へ変換する。
    引数: candidate(dict)は182候補、width(float)は元IFD幅。
    返り値: dictは具体起動pt・固定代替幅・ATR上限・複合縮小幅を持つ候補。
    """
    mode = candidate['mode']
    if not mode.startswith('relative_'):
        return candidate.copy()
    assert width > 0
    result = candidate.copy()
    result['mode'] = mode.removeprefix('relative_')
    result['activation_net_pt'] = max(float(candidate['activation_net_min_pt']),
                                     width * float(candidate['activation_width_fraction']))
    result['trail_pt'] = width * float(candidate['trail_width_fraction'])
    assert result['trail_pt'] > 0
    if result['mode'] in ('atr', 'technical'):
        result['maximum_pt'] = result['trail_pt']
        # ----------------------------------------
        # 軸に150pt未満があっても、下限が元幅の半分を上回らないよう上限を優先する。
        result['minimum_pt'] = min(float(candidate['minimum_pt']), result['maximum_pt'])
    if result['mode'] == 'technical':
        result['tight_pt'] = width * float(candidate['tight_width_fraction'])
        assert result['tight_pt'] > 0
    return result


class TrailEvaluator(BASE.TrailEvaluator):
    """181のエンジンを変更せず、元幅から候補だけを解決する。"""

    def evaluate_cell(self, candidate: dict, ci: int, side: int, wi: int, hi: int) -> dict:
        """
        機能: 元幅から事前規則どおりに保護値を決め、既存のlazyセルAPIへ接続する。
        引数: candidate(dict)、ci/side/wi/hi(int)はcase・側・幅・期限の軸位置。
        返り値: dictは181と同じ金融scalar。新規案だけ具体設定値も追加する。
        """
        relative = candidate['mode'].startswith('relative_')
        resolved = resolve_candidate(candidate, float(self.widths[wi]))
        value = super().evaluate_cell(resolved, ci, side, wi, hi)
        if relative:
            value.update(resolved_activation_net_pt=float(resolved['activation_net_pt']),
                         resolved_trail_pt=float(resolved['trail_pt']),
                         resolved_atr_min_pt=float(resolved.get('minimum_pt', np.nan)),
                         resolved_atr_max_pt=float(resolved.get('maximum_pt', np.nan)),
                         resolved_tight_pt=float(resolved.get('tight_pt', np.nan)))
        return value

    def evaluate_cells(self, candidate: dict, cells: list[tuple] | np.ndarray | None = None) -> dict:
        """
        機能: 具体設定の監査値を持つ182候補も、疎な全軸配列へ変換する。
        引数: candidate(dict)、cells(list[tuple]|np.ndarray|None)は全純要求のセル。
        返り値: dict[str,np.ndarray]は181金融軸と追加設定値。旧対照は181と同じ属性だけ。
        """
        arrays = BASE.allocate(len(self.entries), self.widths, self.horizons)
        if candidate['mode'].startswith('relative_'):
            for key in ('resolved_activation_net_pt', 'resolved_trail_pt', 'resolved_atr_min_pt',
                        'resolved_atr_max_pt', 'resolved_tight_pt'):
                arrays[key] = np.full(arrays['known'].shape, np.nan)
        wanted = np.ndindex(arrays['known'].shape) if cells is None else sorted({tuple(map(int, cell)) for cell in cells})
        for cell in wanted:
            value = self.evaluate_cell(candidate, *cell)
            for key, amount in value.items():
                arrays[key][cell] = amount
        return arrays

# ----------------------------------------


def evaluate_records(records: np.ndarray, entries: np.ndarray, scene_end: float,
                     widths: list, horizons: list, candidates: list[dict],
                     technical: dict | None = None, cells: list[tuple] | np.ndarray | None = None) -> dict:
    """
    機能: 一場の価格木を共有し、182候補を元幅別の具体条件で計算する。
    引数: records/entries(np.ndarray)、scene_end(float)、widths/horizons/candidates(list)、technical(dict|None)、cells(list|np.ndarray|None)。
    返り値: dictは候補ID別の互換金融表。数量一枚の全後続要求再生は呼出側で行う。
    """
    assert len({candidate['id'] for candidate in candidates}) == len(candidates)
    engine = TrailEvaluator(records, entries, scene_end, widths, horizons, technical)
    return {candidate['id']: engine.evaluate_cells(candidate, cells) for candidate in candidates}
