"""182の局面判別・UNKNOWN・継承対照と因果状態を人工値で確認する。"""
from pathlib import Path
import hashlib
import json
import numpy as np
import rules182 as R
import 人工検査 as T1
import 人工検査_v2 as T2

HERE = Path(__file__).resolve().parent


def fixture(n: int = 20, ready_at: int = 1) -> tuple:
    """
    機能: 181人工入力へADX水準を足す。
    引数: n(int)、ready_at(int)。
    返り値: tupleは純特徴と固定179互換bundle。
    """
    f, base = T2.fixture(n, ready_at)
    f.columns = list(f.columns)+['m15_adx']
    f.buy_X = np.c_[f.buy_X, np.full(n, 30.)]
    f.sell_X = np.c_[f.sell_X, np.full(n, 30.)]
    return f, base


def risky(features: object, event: int = 0, count: int = 6) -> None:
    """
    機能: 指定q0の実買い方向背景を逆向きにする。
    引数: features(object)、event/count(int)。
    返り値: None。人工行だけ変更する。
    """
    for number, name in enumerate(R.BACKGROUND):
        features.buy_X[event, features.columns.index(name)] = -1 if number < count else 1
        features.sell_X[event, features.columns.index(name)] = 1 if number < count else -1
    for side in (features.buy_X, features.sell_X):
        side[event, features.columns.index('m15_adx_delta')] = .2


def main() -> None:
    """
    機能: 継承同体・三値・閾値境界・鏡像・全prefix・将来改変・resetを検査する。
    引数: なし。
    返り値: None。自然特徴・新金融は読まず確認JSONだけを保存する。
    """
    checks = []; total = 0
    def check(name: str, actual: object, expected: object) -> None:
        """
        機能: 人工不変条件を照合する。
        引数: name(str)、actual/expected(object)。
        返り値: None。不一致で停止する。
        """
        nonlocal total
        a, b = np.asarray(actual), np.asarray(expected)
        assert a.shape == b.shape and np.array_equal(a, b), (name, a, b)
        total += a.size; checks.append({'検査': name, '項目': int(a.size), '不一致': 0})
    f, base = fixture(); risky(f)
    output = R.build(f, base)
    inherited = R.P.build(f, base, ['E181_00', 'E181_10'])
    for current, prior in [('E182_00', 'E181_00'), ('E182_01', 'E181_10')]:
        for key, value in T1.flatten(inherited['bundles'][prior]).items():
            check('継承全同体/'+current+'/'+key, T1.flatten(output['bundles'][current])[key], value)
    check('6逆は局面切替', output['diagnostics']['E182_02']['risk_setup'][0], True)
    check('6逆後の確認で1回発火', output['diagnostics']['E182_02']['bo_confirmed'], np.arange(20) == 1)
    for stop in range(21):
        pf, pb = T1.sliced(f, base, stop); born = R.build(pf, pb)
        for identity in output['candidate_ids']:
            for key, value in T1.flatten(output['bundles'][identity]).items():
                check(f'prefix{stop}/{identity}/{key}', T1.flatten(born['bundles'][identity])[key], value[:stop])
    mirrored, mb = T1.sliced(f, base, 20)
    mirrored.buy_X, mirrored.sell_X = mirrored.sell_X.copy(), mirrored.buy_X.copy()
    for key in ('core', 'technical'): mb['birth'][key] *= -1
    born = R.build(mirrored, mb)
    for identity in output['candidate_ids']:
        for key, value in T1.flatten(output['bundles'][identity]).items():
            check('鏡像/'+identity+'/'+key, T1.flatten(born['bundles'][identity])[key],
                -value if key in ('core', 'technical') else value)
    for stop in (1, 7, 15):
        changed, cb = T1.sliced(f, base, 20)
        changed.buy_X[stop:] = np.nan; changed.sell_X[stop:] = np.nan
        born = R.build(changed, cb)
        for identity in output['candidate_ids']:
            for key, value in T1.flatten(output['bundles'][identity]).items():
                check('未来改変/'+str(stop)+'/'+identity+'/'+key,
                    T1.flatten(born['bundles'][identity])[key][:stop], value[:stop])

    # ----------------------------------------
    changed, cb = fixture(); risky(changed, count=4)
    born = R.build(changed, cb)
    check('4逆だけでは6逆でない', born['diagnostics']['E182_02']['risk_setup'][0], False)
    check('4逆とADX上昇は強圧力', born['diagnostics']['E182_03']['risk_setup'][0], True)
    changed.buy_X[0, changed.columns.index('m15_adx')] = 25
    check('ADX25を含む', R.build(changed, cb)['diagnostics']['E182_03']['risk_setup'][0], True)
    changed.buy_X[0, changed.columns.index('m15_adx_delta')] = 0
    check('ADX横ばいは上昇でない', R.build(changed, cb)['diagnostics']['E182_03']['risk_setup'][0], False)
    changed, cb = fixture()
    changed.buy_X[0, changed.columns.index('m30_ema21_delta_to_side')] = np.nan
    born = R.build(changed, cb)
    check('背景不足はUNKNOWN', born['diagnostics']['E182_02']['risk_unknown'][0], True)
    check('UNKNOWN既定は旧幹保持', born['bundles']['E182_02']['birth']['core'][0], 1)
    check('UNKNOWNを後続setupにしない', born['diagnostics']['E182_02']['bo_confirmed'].sum(), 0)
    for name in R.BACKGROUND:
        changed.buy_X[0, changed.columns.index(name)] = np.nan
    changed.sell_X[0, changed.columns.index('q0_last_minus_prior3_forward_edge_atr5_to_side')] = .75
    changed.sell_X[0, changed.columns.index('m1_volume_relative_prior3')] = 1.5
    changed.sell_X[0, changed.columns.index('m1_tr_atr5_ratio')] = 1.5
    born = R.build(changed, cb)
    check('背景未知でも既知spikeの真は有効', born['diagnostics']['E182_03']['risk_setup'][0], True)
    check('spikeでも背景不足を残す', born['diagnostics']['E182_03']['background_unknown'][0], True)
    changed.sell_X[0, changed.columns.index('q0_last_minus_prior3_forward_edge_atr5_to_side')] = .5
    check('突破.5ちょうどは厳密超でない', R.build(changed, cb)['diagnostics']['E182_03']['risk_setup'][0], False)
    for change in ('gap', 'contract', 'scene', 'backward'):
        changed, cb = fixture(); risky(changed)
        for q in changed.q0_meta[1:]:
            if change == 'gap': q['q0_time'] += 121
            elif change == 'contract': q['contract'] = '次限月'
            elif change == 'scene': q['session'] = '別_Day'; q['session_index'] = 1
            else: q['q0_time'] -= 61
        born = R.build(changed, cb, ['E182_02'])
        check('reset/'+change, born['diagnostics']['E182_02']['bo_confirmed'].sum(), 0)
    for ready, expected in ((15, 1), (16, 0)):
        changed, cb = fixture(20, ready); risky(changed)
        changed.buy_X[:ready, changed.columns.index('m1_body_ratio_to_side')] = -.5
        born = R.build(changed, cb, ['E182_02'])
        check('15分期限境界/'+str(ready), born['diagnostics']['E182_02']['bo_confirmed'].sum(), expected)
    changed, cb = fixture(); risky(changed)
    cb['birth']['core'][1] = 1; cb['birth']['branches'][1] = 0
    cb['mw'][1] = cb['fw'][1] = 350
    born = R.build(changed, cb, ['E182_02'])
    check('新非riskBO優先で旧待ち取消', born['diagnostics']['E182_02']['bo_confirmed'].sum(), 0)
    check('非riskBO原出生は保持', born['bundles']['E182_02']['birth']['core'][1], 1)

    # ----------------------------------------
    result = {'成功': True, '自然特徴と新182金融未入力': True, '項目': total,
        '不一致': 0, '検査': checks, 'Source': []}
    for path in (Path(__file__), HERE/'rules182.py', Path(R.P.__file__), Path(R.V1.__file__)):
        result['Source'].append({'path': path.relative_to(R.ROOT).as_posix(), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    (HERE/'人工確認182.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'成功': True, '項目': total, '不一致': 0}, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
