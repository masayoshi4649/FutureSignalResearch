"""182の4案を金融前固定し、三期間の純方向と非金融局面分布を保存する。"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import sys
import numpy as np
import rules182 as R

HERE = Path(__file__).resolve().parent
COMMON = R.ROOT/'work/181共用接続/共用181.py'


def ref(path: Path) -> dict:
    """
    機能: Source・辞書・純出生の物理指紋を作る。
    引数: path(Path)。
    返り値: dictはpath/bytes/sha256。
    """
    return {'path': path.relative_to(R.ROOT).as_posix(), 'bytes': path.stat().st_size,
        'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def save(path: Path, body: dict) -> None:
    """
    機能: 非金融正本を新規JSONとして保存する。
    引数: path(Path)、body(dict)。
    返り値: None。固定済み正本は上書きしない。
    """
    assert not path.exists(), path
    path.write_text(json.dumps(body, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')


def main() -> None:
    """
    機能: 四候補を固定した後に純出生だけを生成し、通過率で再調整しない。
    引数: なし。
    返り値: None。新182自然金融・順位は読まない。
    """
    dictionary = HERE/'候補辞書182.json'
    if not dictionary.exists(): R.write_catalog(dictionary)
    paths = [HERE/'rules182.py', HERE/'人工検査.py', HERE/'人工確認182.json',
        HERE/'README.md', Path(__file__), dictionary, Path(R.V1.__file__), Path(R.P.__file__)]
    before = [ref(p) for p in paths]
    fixed_path = HERE/'純出生前の固定182.json'
    save(fixed_path, {'成功': True, '新182金融未入力': True, 'UTC': datetime.now(timezone.utc).isoformat(),
        '候補': [r['id'] for r in R.catalog()['rules']], 'Source': before})
    spec = importlib.util.spec_from_file_location('common181_pure_for182', COMMON)
    common = importlib.util.module_from_spec(spec); sys.modules[spec.name] = common
    spec.loader.exec_module(common)
    summaries = []
    for leg in ('旧73', '追加7', '本日1'):
        pure = common.load_pure_leg(leg)
        assert pure['proof']['金融未入力'] and not pure['context'].financial_attached
        features = pure['features']; base = pure['baselines']['全期_J035']
        output = R.build(features, base)
        phases = pure['context'].event_phases; scenes = pure['event_scene']; day = phases == 0
        values = {'phases': phases, 'event_scene': scenes}; rows = []
        with np.load(R.ROOT/f'work/181入口改善/{leg}_純出生181_v2.npz', allow_pickle=False) as prior:
            for identity, bundle in output['bundles'].items():
                flat = {**bundle['birth'], **{k: bundle[k] for k in ('mw', 'fw', 'hi', 'added')}}
                for key, value in flat.items():
                    values[identity+'__'+key] = value
                    if identity in ('E182_00', 'E182_01'):
                        parent = 'E181_00' if identity == 'E182_00' else 'E181_10'
                        assert np.array_equal(value, prior[parent+'__'+key])
                d = output['diagnostics'][identity]
                values.update({identity+'__diag_'+k: v for k, v in d.items()})
                bo = d['bo_setup']; core = bundle['birth']['core']
                rows.append({'id': identity, 'DAY主成立q0': int(np.count_nonzero(core[day])),
                    'DAY主成立場': len(set(scenes[day & (core != 0)].tolist())),
                    '旧BO出生q0': int(bo.sum()), 'リスクで待たせるBOq0': int(d.get('risk_setup', np.zeros(len(day), bool)).sum()),
                    'リスク判別UNKNOWN_BOq0': int(d.get('risk_unknown', np.zeros(len(day), bool)).sum()),
                    '背景6列不足BOq0': int(d.get('background_unknown', np.zeros(len(day), bool)).sum()),
                    '確認BO発火q0': int(d['bo_confirmed'].sum()),
                    '確認BO発火場': len(set(scenes[d['bo_confirmed']].tolist())),
                    '確認待ち後続q0': int(d['eligible_pending'].sum()),
                    'リスク4ADX真BOq0': int(((d.get('risk4_adx', np.full(len(day), -1)) == 1) & bo).sum()),
                    '元方向スパイク真BOq0': int(((d.get('spike', np.full(len(day), -1)) == 1) & bo).sum())})
        target = HERE/f'{leg}_純出生182.npz'; assert not target.exists()
        np.savez_compressed(target, **values)
        summary = {'成功': True, '新182金融未入力': True, 'leg': leg, '純入力': pure['proof'],
            '候補辞書': ref(dictionary), '純出生前固定': ref(fixed_path), '共用Source': ref(COMMON),
            '純出生': ref(target), '旧E00_E10全配列同体': True, '候補': rows,
            '注意': '通過q0は取得数・保有率・損益ではない。結果を見て閾値を動かさない。'}
        save(target.with_suffix('.json'), summary); summaries.append(summary)
        print(json.dumps({'純出生': leg, '候補': rows}, ensure_ascii=False), flush=True)
    assert before == [ref(p) for p in paths]
    save(HERE/'非金融ファネル182.json', {'成功': True, '新182金融未入力': True,
        'Sourceと閾値不変': True, '期間': summaries})


if __name__ == '__main__':
    main()
