"""181の独立逐次核を変えず、182の元IFD幅割合だけを独立に解決する。"""
from pathlib import Path
import argparse
import json
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).parent
sys.path.insert(0, str(ROOT / 'work/181独立検査'))
from 逐次追尾181 import SequentialScene
import 代表を逐次照合する as I
from 人工を独立照合する import DTYPE, FIELDS, module, same, ref

RESOLVED = ('resolved_activation_net_pt', 'resolved_trail_pt', 'resolved_atr_min_pt',
    'resolved_atr_max_pt', 'resolved_tight_pt')


def resolve(candidate: dict, width: float) -> dict:
    """
    機能: 金融やproductionの解決関数を使わず、元幅に対する事前設定を具体値へ直す。
    引数: candidate(dict)、width(float)は当該IFD幅。
    返り値: dictは181独立核へ渡す具体起動pt・保護幅。
    """
    result = dict(candidate)
    prefix = 'relative_'
    if not result['mode'].startswith(prefix):
        return result
    assert width > 0
    result['mode'] = result['mode'][len(prefix):]
    fraction = float(candidate['activation_width_fraction'])
    minimum = float(candidate['activation_net_min_pt'])
    result['activation_net_pt'] = width * fraction if width * fraction > minimum else minimum
    result['trail_pt'] = width * float(candidate['trail_width_fraction'])
    if result['mode'] in ('atr', 'technical'):
        result['maximum_pt'] = result['trail_pt']
        result['minimum_pt'] = min(result['maximum_pt'], float(candidate['minimum_pt']))
    if result['mode'] == 'technical':
        result['tight_pt'] = width * float(candidate['tight_width_fraction'])
    return result


class RelativeSequentialScene(SequentialScene):
    """181の逐次ループへ、元幅から解決した条件だけを渡す。"""

    def evaluate(self, candidate: dict, entry: int, side: int, width: float, horizon: dict) -> dict:
        """
        機能: 独立割合解決を行い、181の同じ原行逐次核を再用する。
        引数: candidate(dict)、entry/side(int)、width(float)、horizon(dict)。
        返り値: dictは金融と、新候補だけの具体設定5項目。
        """
        concrete = resolve(candidate, width)
        value = super().evaluate(concrete, entry, side, width, horizon)
        if candidate['mode'].startswith('relative_'):
            value.update(resolved_activation_net_pt=concrete['activation_net_pt'],
                resolved_trail_pt=concrete['trail_pt'], resolved_atr_min_pt=concrete.get('minimum_pt', np.nan),
                resolved_atr_max_pt=concrete.get('maximum_pt', np.nan), resolved_tight_pt=concrete.get('tight_pt', np.nan))
        return value


def synthetic() -> dict:
    """
    機能: 全七出口と小幅/大幅の割合設定を、181独立核の人工価格へ照合する。
    引数: なし。
    返り値: dictは不一致0票。自然金融は読まない。
    """
    path = ROOT / 'work/182値幅に合わせた利益保護/trail182.py'
    production = module(path, 'trail182_independent_synthetic')
    candidates = production.load_candidates()
    checked = 0; count = 0
    for candidate in candidates:
        for width in (100, 125, 150, 200, 350, 400, 500, 1000):
            assert resolve(candidate, width) == production.resolve_candidate(candidate, width)
    for seed in range(10):
        rng = np.random.default_rng(182000 + seed)
        rows = np.zeros(260, dtype=DTYPE)
        rows['time'] = np.arange(len(rows)) * 5.
        if seed % 3 == 0:
            rows['time'][200:] += 350
        rows['source_line'] = np.arange(1, len(rows) + 1)
        rows['bid'] = 10000 + np.cumsum(rng.integers(-20, 21, len(rows))) * 5
        rows['ask'] = rows['bid'] + 5; rows['last'] = rows['bid']; rows['normal'] = 1
        technical = {'times': np.asarray([1., 101., 201., 301., 401.]),
            'atr_points': np.asarray([150., 20., np.nan, 60., 90.]),
            'ma_gap_atr': np.asarray([.5, .1, .1, np.nan, .1]),
            'bb_width_ratio': np.asarray([1., .8, .8, .8, .8]),
            'momentum_atr': np.asarray([1., -1., 1., -1., np.nan])}
        widths = [100, 125, 150, 350, 400, 1000]
        horizons = [{'id': 'H300', 'kind': 'strict', 'seconds': 300}, {'id': 'SESSION', 'kind': 'session'}]
        entries = np.asarray([0, 20])
        fast = production.TrailEvaluator(rows, entries, 1900., widths, horizons, technical)
        slow = RelativeSequentialScene(rows, 1900., technical)
        for candidate in candidates:
            fields = FIELDS + (RESOLVED if candidate['mode'].startswith('relative_') else ())
            for ci, entry in enumerate(entries):
                for side in (0, 1):
                    for wi, width in enumerate(widths):
                        for hi, horizon in enumerate(horizons):
                            actual = fast.evaluate_cell(candidate, ci, side, wi, hi)
                            expected = slow.evaluate(candidate, int(entry), side, width, horizon)
                            assert expected['床非緩和'] and expected['最小床遵守'] and expected['追尾遅延遵守']
                            for field in fields:
                                assert same(actual[field], expected[field]), (seed, candidate['id'], ci, side, width, hi, field, actual[field], expected[field])
                                count += 1
                            checked += 1
    body = {'成功': True, '自然金融未入力': True, '旧181独立核変更なし': True,
        'セル数': checked, '照合属性数': count, '不一致': 0,
        'Source': [ref(path), ref(Path(__file__)), ref(ROOT / 'work/181独立検査/逐次追尾181.py'),
            ref(ROOT / 'work/182値幅に合わせた利益保護/候補182.json')]}
    (HERE / '独立割合人工結果.json').write_text(json.dumps(body, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return body


def main() -> None:
    """
    機能: 人工検査、又はRoot指定の182代表政策を全三期間で独立監査する。
    引数: --synthetic(bool)、--ids(list[str]|None)。選定IDが来るまで自然評価はしない。
    返り値: None。結果票を182独立検査内へ保存する。
    """
    parser = argparse.ArgumentParser(); parser.add_argument('--synthetic', action='store_true')
    parser.add_argument('--ids', nargs='+')
    args = parser.parse_args()
    if args.synthetic:
        print(json.dumps(synthetic(), ensure_ascii=False))
    if args.ids:
        I.SequentialScene = RelativeSequentialScene
        target = ROOT / 'work/182局面と値幅の改善'
        exits = {row['id']: row for row in I.read(ROOT / 'work/182値幅に合わせた利益保護/候補182.json')['候補']}
        checked = []; inputs = []
        for leg in C_LEGS():
            loaded = I.C.load_leg(leg)
            with np.load(target / (leg + '_新入口.npz'), allow_pickle=False) as sealed:
                for identity in args.ids:
                    entry, exit_id = identity.split('__', 1)
                    bundle = {'birth': {key: sealed[entry + '__birth__' + key] for key in I.C.BIRTH_KEYS},
                        **{key: sealed[entry + '__' + key] for key in I.C.PARAM_KEYS}}
                    path = target / '期間別' / leg / (identity + '.json.gz')
                    pack = I.read(path)
                    result = I.verify_pack(loaded, pack, bundle, exits[exit_id])
                    resolved_count = 0
                    if exits[exit_id]['mode'].startswith('relative_'):
                        for i, width in enumerate(pack['ledger']['width']):
                            candidate = resolve(exits[exit_id], width)
                            expected = {'resolved_activation_net_pt': candidate['activation_net_pt'],
                                'resolved_trail_pt': candidate['trail_pt'], 'resolved_atr_min_pt': candidate.get('minimum_pt'),
                                'resolved_atr_max_pt': candidate.get('maximum_pt'), 'resolved_tight_pt': candidate.get('tight_pt')}
                            for key, value in expected.items():
                                assert pack['追尾診断'][i][key] == value
                                resolved_count += 1
                    result['割合解決の照合属性'] = resolved_count
                    checked.append(result); inputs.append(ref(path))
                    print(json.dumps(result, ensure_ascii=False), flush=True)
            del loaded
        body = {'成功': True, '順位再選択なし': True, '全81場': True, '固定代表数': len(args.ids),
            '期間候補数': len(checked), '取得総数': sum(row['取得'] for row in checked),
            '全要求総数': sum(row['全要求'] for row in checked),
            '照合属性総数': sum(row['照合属性'] + row['割合解決の照合属性'] for row in checked),
            '不一致': 0, '検査': checked, '入力': inputs,
            'Source': [ref(Path(__file__)), ref(ROOT / 'work/181独立検査/逐次追尾181.py'), ref(ROOT / 'work/181独立検査/代表を逐次照合する.py')]}
        (HERE / '固定代表の全81逐次結果.json').write_text(json.dumps(body, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print(json.dumps({key: value for key, value in body.items() if key not in ('検査', '入力', 'Source')}, ensure_ascii=False))


def C_LEGS() -> tuple:
    """
    機能: 継承した共用接続の期間順をそのまま使う。
    引数: なし。
    返り値: tuple[str]は旧73/追加7/本日1。
    """
    return I.C.LEGS


if __name__ == '__main__':
    main()
