"""元の五候補と追加二候補の独立検査票を、数値を再選択せず一つの索引へまとめる。"""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).parent


def ref(path: Path) -> dict:
    """
    機能: 検査票と固定結果の元byte指紋を記録する。
    引数: path(Path)。
    返り値: dictはpath/bytes/sha256。
    """
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size,
        'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def main() -> None:
    """
    機能: 五案票と追加二案票が重ならず全七案三期間を覆うことを確認する。
    引数: なし。
    返り値: None。集約票と説明Markdownを保存する。元の二票は変更しない。
    """
    paths = [HERE / '固定五案の全81逐次結果.json', HERE / '固定代表の全81逐次結果.json']
    values = [json.loads(path.read_text(encoding='utf-8')) for path in paths]
    assert all(value['成功'] and value['不一致'] == 0 for value in values)
    rows = [row for value in values for row in value['検査']]
    pairs = {(row['leg'], row['id']) for row in rows}
    assert len(rows) == len(pairs) == 21 and len({row['id'] for row in rows}) == 7
    assert {row['leg'] for row in rows} == {'旧73', '追加7', '本日1'}
    source = [Path(__file__), HERE / '幅割合を独立解決する.py',
        ROOT / 'work/181独立検査/逐次追尾181.py', ROOT / 'work/181独立検査/代表を逐次照合する.py',
        ROOT / 'work/182値幅に合わせた利益保護/trail182.py', ROOT / 'work/182値幅に合わせた利益保護/候補182.json',
        ROOT / 'study/00182_反転の危険局面と値幅に応じた保護を組み合わせる/条件.json']
    body = {'成功': True, '再選択なし': True, '旧181独立核変更なし': True,
        '候補数': 7, '候補期間数': len(rows), '全対象場': 81,
        '取得': sum(row['取得'] for row in rows), '要求': sum(row['全要求'] for row in rows),
        '照合項目': sum(row['照合属性'] + row['割合解決の照合属性'] for row in rows),
        '不一致': 0, '検査票': [ref(path) for path in paths], 'Source': [ref(path) for path in source],
        '全候補期間': rows,
        '限界': '共用48byte索引に対する独立原行逐次演算。全81の原JSONLを別走査したものではなく、未来利益・探索選択偏り解消の証明でもない。'}
    (HERE / '全七案の全81逐次集約.json').write_text(json.dumps(body, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    text = f'''# 182の独立割合解決と全81場検査

2026-11-16。181の独立逐次核を変更せず、元IFD幅から起動水準・固定/ATR幅・複合縮小幅を決める設定解決だけを別Sourceへ追加した。新しい候補や順位は作っていない。

- [割合の独立人工結果](独立割合人工結果.json)：7候補・複数幅・両側・2期限・2取得位置、3,360セル/113,760属性、不一致0。100〜1000ptでATR下限と上限も確認した。
- [最初の固定五案](固定五案の全81逐次結果.json)と[追加二案](固定代表の全81逐次結果.json)：計7候補×3期間＝21候補期間、{body['取得']:,}取得・全{body['要求']:,}要求・{body['照合項目']:,}属性、不一致0。
- [全七案の集約](全七案の全81逐次集約.json)：二票の指紋と全21候補期間を参照する。元票を上書きしていない。

原行順の全正常BBOを処理し、金融/返済時計・実側価格・手数料/滑り、先着ラベルと金融未知の分離、最低床・非緩和・接触後1秒以上の返済を照合した。封印純入口と非金融取得descriptorから、全q0で一件だけの保有/予約を再構成し、全要求の受否と後続取得も一致した。新しい未知セルを0円や既知へ変更していない。

核は181の `逐次追尾181.py` SHA `0d6e17fbaba39d9ae18334b1b41707b0377641c36ea69f05a789559de658e86e`。182の設定解決は `幅割合を独立解決する.py`。この検査は共用48byte索引に対する別算術であり、全81場の原JSONLを独立再走査した検査ではない。検算通過と市場優位性・将来の安定利益は別である。

```powershell
$env:PYTHONUTF8='1'
& 'work/複合テクニカル学習環境/Scripts/python.exe' 'work/182独立検査/幅割合を独立解決する.py' --synthetic
```

自然監査は同Sourceの `--ids` へRoot指定の候補IDだけを渡す。五案と二案を再計算する場合は、先の結果票を別名へ保持してから後の二案を実行し、最後に `七案の検査票をまとめる.py` を実行する。
'''
    (HERE / 'README.md').write_text(text, encoding='utf-8')
    print(json.dumps({key: value for key, value in body.items() if key not in ('Source', '全候補期間', '検査票')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
