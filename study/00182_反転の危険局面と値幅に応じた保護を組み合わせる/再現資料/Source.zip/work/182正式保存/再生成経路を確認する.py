"""固定七候補を純出生から再生し、省略期間packと保存全81正本の再生成を確認する。"""
from pathlib import Path
import gzip
import hashlib
import importlib.util
import json
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
STAGE = ROOT / 'work/182局面と値幅の改善'
INDEX = ROOT / 'study/00182_反転の危険局面と値幅に応じた保護を組み合わせる/再現資料/保存索引.json'
sys.path.insert(0, str(STAGE))
import 実行182 as X
import trail182 as T
import 利益後赤字を調べる as MFE

# ----------------------------------------


def read(path: Path) -> object:
    """
    機能: JSON又はgzipを読む。
    引数: path(Path)。
    返り値: objectは復元したJSON。
    """
    data = path.read_bytes()
    return json.loads(gzip.decompress(data) if path.suffix == '.gz' else data)


def ref(path: Path) -> dict:
    """
    機能: 再生に用いるSource・条件・正本の指紋を記録する。
    引数: path(Path)。
    返り値: dictは相対path・bytes・sha256。
    """
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def main() -> None:
    """
    機能: 固定七案×三期間を全純要求から再生し、元21packのSHAと連結正本を確認する。
    引数: なし。正式索引があれば省略票から期待SHAを読み、未保存時は元期間packから採る。
    返り値: None。再生成確認.jsonを担当workへ保存する。完全なcache隔離監査ではない。
    """
    condition_path = X.TRIAL / '条件.json'
    condition = read(condition_path)
    for item in condition['Source']:
        assert ref(ROOT / item['path']) == item
    selected_path = STAGE / '保存する候補.json.gz'
    selected = read(selected_path)['rows']
    names = read(STAGE / '閲覧名.json')
    assert len(selected) == len(names) == 7 and {row['id'] for row in selected} == set(names)
    expected_selected = {row['id']: row for row in selected}
    if INDEX.exists():
        expected_files = {item['file']['path']: item['file'] for item in read(INDEX)['省略中間指紋']}
    else:
        expected_files = {path.relative_to(ROOT).as_posix(): ref(path) for path in sorted((STAGE / '期間別').rglob('*.json.gz'))}
    assert len(expected_files) == 84
    sources = [condition_path, selected_path, STAGE / '閲覧名.json', STAGE / '利益後赤字の比較.json',
               Path(__file__), Path(T.__file__), Path(X.__file__), Path(MFE.__file__)]
    before = [ref(path) for path in sources]
    candidate_by_id = {value['id']: value for value in T.load_candidates()}
    packs = {name: [] for name in names}
    checks = []
    for leg in X.C.LEGS:
        pure = X.C.load_pure_leg(leg)
        X.C.seal_pure_leg(pure)
        built = X.R.build(pure['features'], pure['baselines']['全期_J035'])
        payload = {}
        for name, bundle in built['bundles'].items():
            for key in ('mw', 'fw', 'hi', 'added'):
                payload[name + '__' + key] = bundle[key]
            for key, value in bundle['birth'].items():
                payload[name + '__birth__' + key] = value
        with np.load(STAGE / (leg + '_新入口.npz'), allow_pickle=False) as frozen:
            assert set(frozen.files) == set(payload)
            for key in payload:
                np.testing.assert_array_equal(frozen[key], payload[key])
        loaded = X.C.attach_financial(pure)
        manager = X.Manager(loaded, T)
        for name in names:
            policy = expected_selected[name]['policy']
            candidate = candidate_by_id[policy['exit']]
            manager.attach(None if candidate['mode'] == 'off' else candidate)
            result = X.A.pack(manager.context, built['bundles'][policy['entry']], policy, leg)
            if candidate['mode'] != 'off':
                keys = zip(result['selection']['cases'], result['selection']['sides'],
                           result['selection']['width_indices'], result['selection']['horizon_indices'], strict=True)
                result['追尾診断'] = [X.safe(manager.lookup(tuple(key))) for key in keys]
            result = X.safe(result)
            body = (json.dumps(result, ensure_ascii=False, separators=(',', ':'), allow_nan=False) + '\n').encode('utf-8')
            packed = gzip.compress(body, mtime=0)
            path = (STAGE / '期間別' / leg / (name + '.json.gz')).relative_to(ROOT).as_posix()
            expected = expected_files[path]
            assert len(packed) == expected['bytes'] and hashlib.sha256(packed).hexdigest() == expected['sha256'], (leg, name)
            packs[name].append(result)
            checks.append({'期間': leg, 'id': name, '純出生全同体': True,
                           '元期間packのSHA同体': True, '取得': len(result['ledger']['net'])})
        print(json.dumps({'期間': leg, '固定候補': len(names), '純出生/元pack_SHA': '一致'}, ensure_ascii=False), flush=True)
        del manager, loaded
    regenerated = []
    for name in names:
        row = X.A.combine(packs[name])
        if '追尾診断' in packs[name][0]:
            row['追尾診断'] = sum((pack['追尾診断'] for pack in packs[name]), [])
        row['全80比較'] = X.A.combine(packs[name][:2])['evidence']
        row = X.safe(row)
        assert row == expected_selected[name], name
        regenerated.append(row)
    diagnostics = [MFE.diagnose(row) for row in regenerated]
    assert diagnostics == read(STAGE / '利益後赤字の比較.json')
    assert before == [ref(path) for path in sources]
    proof = {'成功': True, '再選択なし': True, 'Source入力不変': True,
        '固定七候補': len(names), '三期間pack数': len(checks), '全81連結正本同体': len(regenerated),
        '利益後赤字診断同体': len(diagnostics), '確認': checks, '資料': before,
        '意味': '共用恒久入力と181までの復元Sourceを使い、純出生→新金融lazy→全後続要求→容量1→全81正本を再生成。全work/cacheの隔離監査ではない。'}
    target = HERE / '再生成確認.json'
    target.write_text(json.dumps(proof, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    print(json.dumps({key: value for key, value in proof.items() if key not in ('確認', '資料')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
