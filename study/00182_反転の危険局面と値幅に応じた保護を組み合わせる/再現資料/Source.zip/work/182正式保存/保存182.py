"""182差分Source・固定七案・監査票だけを保存し、親181とCSVは指紋で参照する。"""
from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
import zipfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
TRIAL = ROOT / 'study/00182_反転の危険局面と値幅に応じた保護を組み合わせる'
DEST = TRIAL / '再現資料'
STAGE = ROOT / 'work/182局面と値幅の改善'
PARENT = ROOT / 'study/00181_反転確認と利益保護を分けて改善する/再現資料'
OUTPUT = ROOT / 'outputs/00182_反転確認と値幅保護の比較'
FOLDERS = ('182局面別の反転確認', '182値幅に合わせた利益保護', '182局面と値幅の改善',
           '182独立検査', '182閲覧資料', '182CSV検査', '182正式保存')

# ----------------------------------------


def read(path: Path) -> object:
    """
    機能: JSON又はgzipを読み込む。
    引数: path(Path)。
    返り値: objectはJSON値。
    """
    body = path.read_bytes()
    return json.loads(gzip.decompress(body) if path.suffix == '.gz' else body)


def member(path: str, body: bytes) -> dict:
    """
    機能: ZIP内又は通常ファイルの物理指紋を同じ形式へ揃える。
    引数: path(str)、body(bytes)。
    返り値: dictはpath/bytes/sha256。
    """
    return {'path': path, 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def ref(path: Path) -> dict:
    """
    機能: リポジトリ内ファイルの内容指紋を採る。
    引数: path(Path)。
    返り値: dictは相対path/bytes/sha256。
    """
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size, 'sha256': digest}


def verify(reference: dict) -> None:
    """
    機能: 参照指紋を現ファイルへ照合する。
    引数: reference(dict)はpath/bytes/sha256。
    返り値: None。不一致時は保存を止める。
    """
    assert ref(ROOT / reference['path']) == reference, reference['path']


def source_chain(node: dict) -> list[dict]:
    """
    機能: 親Sourceから全正式ZIP参照を重複なく辿り、CRCと全memberを確認する。
    引数: node(dict)はarchive/membersと親参照を持つSource情報。
    返り値: list[dict]は最新から古いSource参照。元workの変更済み文書を正本としない。
    """
    output = []
    stack = [node]
    seen = set()
    while stack:
        value = stack.pop()
        if not isinstance(value, dict):
            continue
        if 'archive' in value and 'members' in value:
            identity = value['archive']['path']
            if identity not in seen:
                verify(value['archive'])
                if 'index' in value:
                    verify(value['index'])
                with zipfile.ZipFile(ROOT / identity) as archive:
                    assert archive.testzip() is None
                    for item in value['members']:
                        assert member(item['path'], archive.read(item['path'])) == item
                output.append(value)
                seen.add(identity)
        stack.extend(item for key, item in value.items() if key not in ('members', 'archive', 'index') and isinstance(item, dict))
    return output


def inherit() -> tuple:
    """
    機能: 181のSource・正本を親参照とし、旧ZIPを182へ複製しない。
    引数: なし。
    返り値: tuple[dict,dict,list,dict]はSource親、正本親、必要旧正本参照、CSV出力器参照。
    """
    index_path = PARENT / '保存索引.json'
    index = read(index_path)
    assert index['成功'] and index['正式保存']
    source = {'archive': index['Source']['archive'], 'index': ref(index_path),
              'members': index['Source']['members'], '親Source継承元': index['Source継承元'],
              '復元順': '176全Source→177→178→179→180→181→182。親を先に復元して新差分を重ねる。'}
    chain = source_chain(source)
    canonical = {'archive': index['正本']['archive'], 'index': ref(index_path),
                 'members': index['正本']['members'], '複製なし': True}
    verify(canonical['archive'])
    with zipfile.ZipFile(ROOT / canonical['archive']['path']) as archive:
        assert archive.testzip() is None
        for item in canonical['members']:
            assert member(item['path'], archive.read(item['path'])) == item
    old_canonical = []
    for node in chain:
        if 'index' not in node:
            continue
        prior = read(ROOT / node['index']['path'])
        if '正本' in prior:
            value = {'archive': prior['正本']['archive'], 'index': node['index'],
                     '理由': '旧純出生・選択・180終了前金融等を、各正式正本から元byte復元する。'}
            verify(value['archive'])
            old_canonical.append(value)
    script = 'scripts/損益CSV/候補別に出力する.mjs'
    found = []
    for node in chain:
        matches = [item for item in node['members'] if item['path'] == script]
        if matches:
            found.append({'archive': node['archive'], 'index': node.get('index'), 'member': matches[0]})
    assert found
    exporter = found[0]
    assert ref(ROOT / script) == exporter['member']
    return source, canonical, old_canonical, exporter


def gates() -> dict:
    """
    機能: 条件不変・七候補・全監査・再生成・42CSVの完成を保存前後に確認する。
    引数: なし。
    返り値: dictは最終固定指紋と完成件数。成績からの候補交換はしない。
    """
    condition = read(TRIAL / '条件.json')
    assert condition['試行'] == 182 and len(condition['入口']['rules']) == 4 and len(condition['出口']['候補']) == 7
    for item in condition['Source']:
        verify(item)
    seal = read(STAGE / '全純入口の封印.json')
    assert seal['金融前'] and len(seal['入力']) == 3
    for item in seal['入力']:
        verify(item)
    compact = read(STAGE / '全28組の比較.json.gz')
    fixed = read(STAGE / '保存する候補.json.gz')
    names = read(STAGE / '閲覧名.json')
    assert compact['成功'] and len(compact['rows']) == 28
    assert len(fixed['rows']) == len(names) == 7 and {row['id'] for row in fixed['rows']} == set(names)
    assert all(len(row['sessions']) == len({s['scene'] for s in row['sessions']}) == 81 for row in fixed['rows'])
    proof_paths = [ROOT / 'work/182局面別の反転確認/人工確認182.json',
        ROOT / 'work/182値幅に合わせた利益保護/人工結果.json',
        ROOT / 'work/182値幅に合わせた利益保護/旧対照の全期間同体.json',
        ROOT / 'work/182値幅に合わせた利益保護/自然比較の独立結果.json',
        ROOT / 'work/182独立検査/独立割合人工結果.json',
        ROOT / 'work/182独立検査/固定五案の全81逐次結果.json',
        ROOT / 'work/182独立検査/固定代表の全81逐次結果.json',
        ROOT / 'work/182独立検査/全七案の全81逐次集約.json',
        HERE / '再生成確認.json', ROOT / 'work/182閲覧資料/型付き入力の確認.json',
        ROOT / 'work/182CSV検査/作成確認.json']
    for path in proof_paths:
        assert read(path)['成功'], path
    natural = read(ROOT / 'work/182独立検査/全七案の全81逐次集約.json')
    assert (natural['候補数'], natural['候補期間数'], natural['取得'], natural['要求'], natural['照合項目'], natural['不一致']) == (7, 21, 1947, 6837, 139683, 0)
    regenerated = read(HERE / '再生成確認.json')
    assert regenerated['固定七候補'] == regenerated['全81連結正本同体'] == regenerated['利益後赤字診断同体'] == 7
    assert regenerated['三期間pack数'] == 21 and regenerated['Source入力不変']
    typed_path = ROOT / 'work/182閲覧資料/型付き入力.json'
    csv_check_path = ROOT / 'work/182CSV検査/作成確認.json'
    csv_check = read(csv_check_path)
    assert csv_check['入力SHA256'] == ref(typed_path)['sha256'] == '91af671db8d8510c789f20b79e568a41b5daade58b051ed06cecf6c72d80e74b'
    assert csv_check['出力器SHA256'] == ref(ROOT / 'scripts/損益CSV/候補別に出力する.mjs')['sha256']
    files = csv_check['files']
    assert len(files) == 42 and csv_check['候補数'] == 7
    assert sum(item['全セル照合'] for item in files) == 105390
    csv_refs = []
    for item in files:
        value = ref(OUTPUT / item['相対path'])
        assert value['bytes'] == item['bytes'] and value['sha256'] == item['sha256']
        csv_refs.append(value)
    assert {path.relative_to(ROOT).as_posix() for path in OUTPUT.rglob('*.csv')} == {item['path'] for item in csv_refs}
    shared = [ROOT / 'inputs/00163_任意幅の共用価格索引/価格索引/manifest.json',
        ROOT / 'inputs/00167_追加七場の入口と共用価格索引/原板数値索引/manifest.json',
        ROOT / 'inputs/00180_20261116デイの固定適用入力/保存索引.json',
        ROOT / 'inputs/00180_20261116デイの固定適用入力/原板数値索引/manifest.json',
        ROOT / 'inputs/00179_終了前決済の共用数値表/旧73_overlay179.json',
        ROOT / 'inputs/00179_終了前決済の共用数値表/追加7_overlay179.json']
    return {'成功': True, '全候補': 28, '全期間pack': 84, '保存候補': list(names),
        '金融前固定': ref(TRIAL / '条件.json'), '全純入口封印': ref(STAGE / '全純入口の封印.json'),
        '固定七候補': ref(STAGE / '保存する候補.json.gz'), '独立検査': [ref(path) for path in proof_paths],
        '全七案の自然独立': {'期間': 21, '取得': 1947, '要求': 6837, '項目': 139683, '不一致': 0},
        '共用恒久入力参照': [ref(path) for path in shared], 'CSV': csv_refs, 'CSV全セル一致': 105390}


def collect() -> tuple:
    """
    機能: 新182全Sourceと小正本を集め、84中間・CSV本文・旧ZIPの重複を避ける。
    引数: なし。
    返り値: tuple[dict,dict,list,list]はSource byte、正本byte、省略票、可逆圧縮票。
    """
    sources, results, omitted, compressed = {}, {}, [], []
    for folder in FOLDERS:
        directory = ROOT / 'work' / folder
        assert directory.is_dir(), folder
        for current, dirs, files in os.walk(directory):
            dirs[:] = [name for name in dirs if name not in ('__pycache__', 'node_modules', '期間別')]
            for name in files:
                path = Path(current) / name
                relative = path.relative_to(ROOT).as_posix()
                if path.suffix == '.py':
                    sources[relative] = path.read_bytes()
                elif path.suffix in ('.json', '.gz', '.npz', '.md'):
                    body = path.read_bytes()
                    if path.suffix == '.json' and len(body) > 10 * 1024 * 1024:
                        packed = gzip.compress(body, mtime=0)
                        assert gzip.decompress(packed) == body
                        results[relative + '.gz'] = packed
                        compressed.append({'元ファイル': ref(path), '保存member': member(relative + '.gz', packed),
                                           '復元': 'gzipを解凍して末尾の.gzを外し、元byteとSHAを照合する。'})
                    else:
                        results[relative] = body
    extra_source = ROOT / 'work/181反省を分解した改善/利益後赤字を調べる.py'
    extra_result = ROOT / 'work/181反省を分解した改善/代表四案の利益後赤字.json'
    sources[extra_source.relative_to(ROOT).as_posix()] = extra_source.read_bytes()
    results[extra_result.relative_to(ROOT).as_posix()] = extra_result.read_bytes()
    results[(TRIAL / '条件.json').relative_to(ROOT).as_posix()] = (TRIAL / '条件.json').read_bytes()
    for path in sorted((STAGE / '期間別').rglob('*.json.gz')):
        omitted.append({'file': ref(path), '理由': '84期間packは実行182.pyの再生成中間。7候補全81正本・28短表・純封印・監査は比較正本へ保存。'})
    assert len(omitted) == 84
    return sources, results, omitted, compressed


def write_archive(path: Path, contents: dict[str, bytes]) -> dict:
    """
    機能: 元byteを決定的ZIPへ保存し、CRC・member集合・全SHAを再読確認する。
    引数: path(Path)、contents(dict[str,bytes])はリポジトリ相対名と元byte。
    返り値: dictはarchive指紋と全member指紋。異なる既存ZIPは上書きしない。
    """
    if not path.exists():
        with zipfile.ZipFile(path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for name, body in sorted(contents.items()):
                info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o644 << 16
                archive.writestr(info, body)
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == set(contents)
        for name, body in contents.items():
            assert archive.read(name) == body, name
    return {'archive': ref(path), 'members': [member(name, body) for name, body in sorted(contents.items())]}


def write_readme() -> None:
    """
    機能: 親Source復元・恒久入力・84中間の再生成・CSV参照の手順を記述する。
    引数: なし。
    返り値: None。正式試行README/設定/共通知見は変更せず、再現資料READMEだけを作る。
    """
    body = '''# 182の再現資料

`保存索引.json` を入口にする。Source.zipは新182のPython Sourceと181未収録の利益後赤字診断Source、比較正本.zipは固定7案全81場・全28短表・純出生/辞書/封印・人工/独立/再生成/CSV作成の監査票を保持する。正式試行README・設定表・共通知見は通常ファイルで管理し、このZIPへ転記しない。

親は181の正式Source.zipと比較正本.zip。保存索引のSource継承元と親正本参照から、176→177→178→179→180→181のSourceを古い順にリポジトリルートへ復元する。各段の正本も元byteで重ね、可逆gzip保存のmemberは解凍して末尾の.gzを外す。最後に182のSource.zip/比較正本.zipを同じルートへ復元する。旧ZIPや原板・共用価格索引は182へ複製していない。

恒久inputsは共有し、旧73の148入口・163価格索引、追加7の167入口/索引、179終了前overlay、本日180の入口/索引を各指紋へ照合する。Python3.14.3・NumPy2.5.4・tzdata2026.6を使用した。旧Go入力生成には親資料の依存関係を用いる。

全84期間packを再生成する場合は、復元した `work/182局面と値幅の改善/実行182.py` を実行する。純出生を先に照合・封印してから金融へ接続し、28政策×3期間を全後続要求から容量1で再生する。`比較を集約する.py` で28短表、`閲覧候補を保存する.py` で閲覧名.jsonの7案全81正本と利益後赤字診断を再生成する。既存packがある場合の --resume は、入力Source指紋と旧結果の一致確認後だけ用いる。

`work/182正式保存/再生成経路を確認する.py` は固定7案×3期間を実際に再計算し、省略票の元21pack SHA・連結7正本・7利益後赤字診断へ照合する。正式索引が存在すれば省略票を期待SHAとして読み、元期間packが残っていなくても検査できる。完全なwork/cache隔離監査ではない。

CSV本文42本は outputs/00182_反転確認と値幅保護の比較 に置き、保存索引の完了gate.CSVでSHA参照する。型付きJSON・生成Source・確認票は比較正本へ保存し、CSV出力器は親Source連鎖の元memberを参照する。Node v24.22.1を使用し、7候補・105,390セルが型付き入力と一致した。再生成時は親出力器の依存関係も復元する。

全81場は既使用で、全80/前48の選択と本日1/全81の診断を分ける。保存時に入口・出口・順位・候補を変更していない。独立監査は共用価格索引を別の逐次算術で評価したものであり、全原JSONLの独立再取得ではない。
'''
    (DEST / 'README.md').write_text(body, encoding='utf-8')

# ----------------------------------------


def main() -> None:
    """
    機能: 最終gateを満たしたSource差分・比較正本・索引を正式保存する。
    引数: なし。
    返り値: None。旧正式資料を改変せず、182再現資料の四ファイルを作成する。
    """
    index_path = DEST / '保存索引.json'
    assert not index_path.exists(), '正式索引の自動上書きは禁止。'
    parent_source, parent_canonical, old_canonical, exporter = inherit()
    gate = gates()
    sources, results, omitted, compressed = collect()
    DEST.mkdir(parents=True, exist_ok=True)
    write_readme()
    source = write_archive(DEST / 'Source.zip', sources)
    canonical = write_archive(DEST / '比較正本.zip', results)
    assert gates() == gate
    assert {name: body for name, body in sources.items()} == collect()[0]
    index = {'成功': True, '正式保存': True, '保存UTC': datetime.now(timezone.utc).isoformat(),
        'Source': source, '正本': canonical, 'Source継承元': parent_source, '正本継承元': parent_canonical,
        '親正本参照': old_canonical, 'CSV出力器継承': exporter, '完了gate': gate,
        '可逆圧縮保存': compressed, '省略中間指紋': omitted, 'README': ref(DEST / 'README.md'),
        '再生成確認': ref(HERE / '再生成確認.json'),
        '追加の181資料': [ref(ROOT / 'work/181反省を分解した改善/利益後赤字を調べる.py'),
                          ref(ROOT / 'work/181反省を分解した改善/代表四案の利益後赤字.json')],
        '依存関係': {'Python': '3.14.3', 'NumPy': '2.5.4', 'tzdata': '2026.6', 'Node': 'v24.22.1'},
        '保存方針': '新182全Source・辞書/封印/人工/独立監査・固定7案/28短表・CSV型付き生成/確認を保存。全84pack/CSV本文/親ZIP/原板/価格索引を複製しない。正式Markdownは通常ファイル。',
        '再現': '再現資料README参照。固定7案21期間を純出生から再計算し元pack SHAと全81正本/利益後赤字診断へ一致。完全なwork/cache隔離ではない。',
        '注意': '全81は既使用。全80と前48を選択軸、本日1/全81は診断。未知収支や未知DDを0で確定せず、床は実約定利益を保証しない。'}
    index_path.write_text(json.dumps(index, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, 'Source': source['archive'], 'Source数': len(source['members']),
        '正本': canonical['archive'], '正本数': len(canonical['members']), 'CSV参照': len(gate['CSV']),
        '省略pack': len(omitted), '索引': ref(index_path)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
