"""Root F0後の場順学習・現在予測・方向固定。各train/scoreに現在ラベルを渡さない。"""
import argparse
import copy
import json
from pathlib import Path
from features143 import NAMES, families
from data143 import join
from model143 import fit, score
from logic143 import choose, fixed_spec
from io143 import (HERE, MANIFEST, QUERIES, FEATURES, NONFINANCIAL, LABEL_SOURCES,
                   sha, load, save, verify_freeze, local_sources, load_prefix)


def sequential(cohort: dict, label_manifest: dict, output: Path) -> tuple:
    """
    機能: 初期8場native、以後過去prefixだけで学習して現場特徴を予測する。
    引数: cohort/label_manifest(dict)、output(Path)。返り値: tupleはモデル監査と全予測。
    """
    assert label_manifest['success'] and label_manifest['trial'] == 143 and label_manifest['sessions'] == cohort['sessions']
    files = label_manifest['files']; assert len(files) == 73
    assert [f['session'] for f in files] == cohort['sessions'] and [f['session_index'] for f in files] == list(range(73))
    models, predictions = [], []
    for index, meta in enumerate(files):
        current = [r for r in cohort['rows'] if r['session'] == meta['session']]
        if index < 8:
            model, audit = None, {'status': 'warmup8', 'model_ref': None, 'training': None}
        else:
            prefix = files[:index]
            prior_labels = load_prefix(prefix, index, meta['session'], meta['start'])
            prior_ids = {r['id'] for doc in prior_labels for r in doc['rows']}
            prior_features = [r for r in cohort['rows'] if r['id'] in prior_ids]
            assert all(r['session'] != meta['session'] for r in prior_features)
            model, audit = fit(prior_features, prior_labels, meta['start'], output/'models'/f'{index:02d}.json')
        rows = score(model, current, audit)
        predictions.extend(rows)
        models.append({'session_index': index, 'session': meta['session'], 'start': meta['start'], 'end': meta['end'], **audit})
    assert len(predictions) == 752 and len(models) == 73
    return models, predictions


def main() -> None:
    """
    機能: 指紋固定済み入力で逐次学習し、モデルと予測と方向を別artifactへ保存する。
    引数: F0、labels-manifestと各SHA、output-dir、execute-after-f0。返り値: None。
    """
    p = argparse.ArgumentParser(description='143の過去場逐次学習と現在予測')
    for name in ('f0', 'labels-manifest'):
        p.add_argument('--'+name, type=Path, required=True); p.add_argument('--'+name+'-sha256', required=True)
    p.add_argument('--output-dir', type=Path, required=True); p.add_argument('--execute-after-f0', action='store_true')
    args = p.parse_args(); assert args.execute_after_f0 and not args.output_dir.exists()
    required = {**NONFINANCIAL, **LABEL_SOURCES, **local_sources()}; _, declared = verify_freeze(args.f0, args.f0_sha256, required)
    manifest, queries, features = (load(path, NONFINANCIAL[path]) for path in (MANIFEST, QUERIES, FEATURES))
    cohort = join(manifest, queries, features); labels = load(args.labels_manifest, args.labels_manifest_sha256)
    assert labels['features_sha256'] == NONFINANCIAL[FEATURES] and labels['F0_SHA256'] == args.f0_sha256
    for path, h in labels['sources'].items(): assert declared[Path(path).resolve()] == h
    model_sha = sha(HERE/'固定条件.json'); assert load(HERE/'固定条件.json', model_sha) == fixed_spec()
    assert load(HERE/'特徴系統.json', sha(HERE/'特徴系統.json')) == families()
    models, rows = sequential(cohort, labels, args.output_dir)
    model_manifest_path = args.output_dir/'モデル参照.json'
    model_manifest_sha = save(model_manifest_path, {'success': True, 'trial': 143, 'models': models,
        'labels_manifest_sha256': args.labels_manifest_sha256, 'features_sha256': NONFINANCIAL[FEATURES],
        'model_spec_sha256': model_sha, 'F0_SHA256': args.f0_sha256})
    pred = {'success': True, 'trial': 143, 'sessions': cohort['sessions'], 'feature_names': list(NAMES),
        'models': models, 'rows': rows, 'features_sha256': NONFINANCIAL[FEATURES], 'model_spec_sha256': model_sha,
        'labels_manifest_sha256': args.labels_manifest_sha256, 'models_manifest_sha256': model_manifest_sha}
    pred_path = args.output_dir/'全752の予測.json'; pred_sha = save(pred_path, pred)
    directions = choose(manifest, queries, features, pred)
    directions.update({'model_sha256': model_sha, 'features_sha256': NONFINANCIAL[FEATURES],
        'manifest_sha256': NONFINANCIAL[MANIFEST], 'queries_sha256': NONFINANCIAL[QUERIES],
        'predictions_sha256': pred_sha, 'predictions_path': str(pred_path.resolve()),
        'models_manifest_sha256': model_manifest_sha, 'models_manifest_path': str(model_manifest_path.resolve()),
        'labels_manifest_sha256': args.labels_manifest_sha256, 'labels_manifest_path': str(args.labels_manifest.resolve()),
        'F0_SHA256': args.f0_sha256})
    sources = {str(path.resolve()): h for path, h in NONFINANCIAL.items()}
    sources.update({str((HERE/'固定条件.json').resolve()): model_sha, str(pred_path.resolve()): pred_sha,
                    str(model_manifest_path.resolve()): model_manifest_sha, str(args.labels_manifest.resolve()): args.labels_manifest_sha256})
    for m in models:
        if m['model_ref'] is not None: sources[m['model_ref']['path']] = m['model_ref']['sha256']
    directions['sources'] = sources
    verify_freeze(args.f0, args.f0_sha256, required)
    assert sha(args.labels_manifest) == args.labels_manifest_sha256
    for m in models:
        if m['model_ref'] is not None: assert sha(Path(m['model_ref']['path'])) == m['model_ref']['sha256']
    direction_sha = save(args.output_dir/'全752の方向.json', directions)
    save(args.output_dir/'方向票の確認.json', {'成功': True, '試行': 143, '方向SHA256': direction_sha,
        '予測SHA256': pred_sha, 'モデル参照SHA256': model_manifest_sha, '固定条件SHA256': model_sha,
        'F0_SHA256': args.f0_sha256, '方向件数': directions['counts'], 'fallback件数': directions['fallback_counts'],
        '結合': directions['join_proof'], '過去完了教師を使用': True, '現在labelをtrain又はscoreへ渡した': False,
        '全期未使用主張': False, '新Raw又はCSV': False, '追加2場読取': False, '金融再集計': False})
    print(json.dumps({'成功': True, '方向SHA256': direction_sha, '方向件数': directions['counts'], 'fallback': directions['fallback_counts']}, ensure_ascii=False))


if __name__ == '__main__': main()
