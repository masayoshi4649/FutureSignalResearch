"""F1後だけ、固定138算術へ143の逐次学習方向票を渡して保存実正逆を再集計する。"""
import argparse
import copy
from collections import Counter
from functools import partial
import json
from pathlib import Path
from logic143 import choose,fixed_spec,stream
from io143 import ROOT,HERE,MANIFEST,QUERIES,FEATURES,NONFINANCIAL,sha,load,save,module,verify_freeze,local_sources

BASE=ROOT/'work/138全成立入口と頻度の集計/集計する.py'
FIXED=ROOT/'work/138全成立入口の評価/固定入力_版2/固定取得入力.json'
METADATA=ROOT/'work/138全成立入口の評価/固定入力_版2/入口参照.json'
OBSERVED=ROOT/'work/138全成立入口の評価/固定取得の正逆観測.json'
OLD138=ROOT/'work/138全成立入口と頻度の集計/集計.json'
SOURCES={**NONFINANCIAL,BASE:'e8671638600dc4b23ef9256ba5be535f20c6f8e1d5097457a56fbea9fb30c1f1',
 FIXED:'0c83e525dec3079ce188d942069c0d137c94f39009339752ec8227ec9ecb4ce7',
 METADATA:'75e4993571bdef17839aad3324acc6ee9ce09b3cb1f4ecad70637a1e01ccefd0',
 OBSERVED:'d272fc6f6768342ff67e1a9ec58b0b7307a0a5b07cc215ba5ff7bcb50865b742',
 OLD138:'6ef283db667603884b42260affce732ba5c9b31731d24b1bb18f9e96ee4b3486',
 ROOT/'work/124入口の原因分析/集計する.py':'8479ca348231ffd77a637360797750833c9e6617c7fc4a6502e015c7a1d9f04a',
 ROOT/'work/137既知回復と頻度の集計/集計.json':'f7c73cc87948fa17174e3909f89aa63d74abe76191bf435788e71cb0d400548b',
 ROOT/'work/137既知回復の評価/固定取得の正逆観測.json':'f0adca92cf1f1db25e75e4d92187952e2920ea7126b3790ece89df1c7f00369a'}


def configure(base: object, choices: dict) -> None:
    """
    機能: 138私有モジュールの政策と選択関数だけを143へ合わせる。
    引数: base(object)、choices(dict)は私有算術と全752方向票。
    返り値: None。元138ファイルと費用/先着/IFD算術は変更しない。
    """
    base.POLICIES=('T0','P0','C0');base.MODEL={'T0':'P0','P0':'P0','C0':'C0'}
    base.selected=partial(stream,choices=choices)
    base.DETAIL_HEADERS=base.DETAIL_HEADERS[:18]+[p+s for p in base.POLICIES for s in ('方向','125全H','125先着','IFD既知','清算','125C5代用円')]
    base.SCENE_HEADERS=base.SCENE_HEADERS[:13]+[p+s for p in base.POLICIES for s in ('反転数','125順','125逆','125未到達','全H不足','IFD既知','IFD未知','C5利益円','C5損失絶対円','C5既知差引円','C5既知累計円_口座収支ではない','累計IFD未知')]


def native_check(values: dict,old: dict) -> dict:
    """
    機能: native P0/C0の全120条件が旧138と同体か確認する。
    引数: values/old(dict)は新旧全幅集計。
    返り値: dictは変更しない対照の照合件数。
    """
    n=0
    for part in ('all','train','validation'):
        for policy in ('P0','C0'):
            for axis in ('BBO','Last'):
                for h in ('1800','3600'):
                    for w in ('25','50','100','125','200'):
                        assert values[part][policy][axis][h][w]==old['集計'][part][policy][axis][h][w]
                        n+=1
    assert n==120
    return {'成功':True,'P0旧60条件':60,'C0旧60条件':60,'合計':n}


def main() -> None:
    """
    機能: F1へbindした仕様/方向票だけを保存実正逆へ適用する。
    引数: CLIのF1/model/choices及び各SHA、output-dir。
    返り値: None。新Raw再生・学習・反転注文適格性再構築は行わない。
    """
    p=argparse.ArgumentParser(description='143の逐次学習方向を再集計')
    for name in ('f1','model','choices'):
        p.add_argument('--'+name,type=Path,required=True);p.add_argument('--'+name+'-sha256',required=True)
    p.add_argument('--output-dir',type=Path,required=True);args=p.parse_args()
    assert not any((args.output_dir/n).exists() for n in ('集計.json','CSV用の表.json','集計完了.json'))
    required={**NONFINANCIAL,**SOURCES,**local_sources(),args.model:args.model_sha256,args.choices:args.choices_sha256}
    f1,declared=verify_freeze(args.f1,args.f1_sha256,required)
    assert load(args.model,args.model_sha256)==fixed_spec()
    selected=load(args.choices,args.choices_sha256)
    assert selected['success'] and selected['trial']==143 and selected['model_sha256']==args.model_sha256
    dynamic={Path(n):h for n,h in selected['sources'].items()}
    for n,h in dynamic.items():assert declared[n.resolve()]==h and sha(n)==h
    manifest=load(MANIFEST,NONFINANCIAL[MANIFEST]);queries=load(QUERIES,NONFINANCIAL[QUERIES])
    assert selected['features_sha256']==NONFINANCIAL[FEATURES]
    prediction_paths=[n for n,h in dynamic.items() if h==selected['predictions_sha256']];assert len(prediction_paths)==1
    predictions=load(prediction_paths[0],selected['predictions_sha256'])
    assert any(h==selected['models_manifest_sha256'] for h in dynamic.values())
    regenerated=choose(manifest,queries,load(FEATURES,NONFINANCIAL[FEATURES]),predictions)
    assert all(selected[k]==regenerated[k] for k in regenerated)
    choices={r['id']:r for r in selected['rows']};assert len(choices)==752
    # ----------------------------------------
    # 学習器へは戻らず、F1固定済み予測を保存実正逆の金額へ結合します。
    base=module(BASE,'143私有138算術')
    for n,h in base.SOURCES.items():assert declared[n.resolve()]==h and sha(n)==h
    configure(base,choices)
    fixed=load(FIXED,SOURCES[FIXED]);metadata=load(METADATA,SOURCES[METADATA]);observed=load(OBSERVED,SOURCES[OBSERVED])
    assert observed['input_sha256']==metadata['fixed_input_sha256']==SOURCES[FIXED]
    records,sessions,phase=base.prepare(observed,fixed,metadata,manifest);assert sessions==selected['sessions']
    arithmetic=base.load_arithmetic();values,participation,frequency,_=base.calculate(records,sessions,fixed['scenes'],arithmetic)
    baseline=base.baseline_check(records,values,load(base.OLD137,base.SOURCES[base.OLD137]),load(base.OLD_PAIRS,base.SOURCES[base.OLD_PAIRS]))
    old_sha=SOURCES[OLD138];native=native_check(values,load(OLD138,old_sha))
    tables=base.tables(records,sessions,values,participation,frequency,arithmetic)
    for t in tables:
        for row in t['rows']:assert row[0]==138;row[0]=143
    stats=values['all']['T0']['BBO']['3600']['125'];part=participation['all']['P0'];freq=frequency['all']['P0']
    main_result={'政策':'T0','順':stats['forward'],'逆':stats['adverse'],'未到達':stats['neither'],'観測不足':stats['censored'],
        '到達済み率':stats['resolved_rate'],'70%以上':stats['target70'],'取得数':752,'全73場最低1':part['全場最低1取得'],
        '全時間平均件数毎時':freq['全時間平均件数毎時'],'参加と70%と頻度すべて達成':part['全場最低1取得'] and stats['target70'] is True and freq['全時間平均1件毎時以上']}
    groups={}
    for name in sorted({'保護81','モデル適用'}|{str(r.get('fallback_kind')) for r in choices.values() if not r['baseline'] and not r['model_applied']}):
        group_ids={r['id'] for r in choices.values() if (r['baseline'] if name=='保護81' else not r['baseline'] and r['model_applied'] if name=='モデル適用' else not r['baseline'] and not r['model_applied'] and str(r['fallback_kind'])==name)}
        group=[r for r in records if r['case']['id'] in group_ids]
        groups[name]={p:arithmetic.stats(group,p,'BBO',3600,125) for p in ('T0','P0')}
    assert sum(v['T0']['entries'] for v in groups.values())==752
    training_summary={'場別モデル状態':dict(Counter(m['status'] for m in predictions['models'])),
        '予測場数':len(predictions['models']),'数値特徴列数':len(predictions['feature_names']),
        '全752の適用区分':{name:group['T0']['entries'] for name,group in groups.items()}}
    output={'成功':True,'試行':143,'主政策':'T0','主評価':main_result,'適用区分別':groups,'集計':values,'参加':participation,'頻度':frequency,
        '全4streamのphase検査':phase,'旧C0同体':baseline,'旧138native同体':native,'非金融結合':selected['join_proof'],
        '方向件数':selected['counts'],'モデルSHA256':args.model_sha256,'方向SHA256':args.choices_sha256,
        '出生特徴SHA256':selected['features_sha256'],'F1_SHA256':args.f1_sha256,'本試行の過去場学習':True,'学習モデルF1後交換':False,'学習予測の要約':training_summary,'全期間既使用':True,'未知期検証':False,
        '新Raw走査':False,'反転注文適格性再構築':False,'口座損益':False,'実IFD':False,
        '数量費用':'独立mini1枚100円/pt、往復77円、C5追加1000円。Last金額null'}
    verify_freeze(args.f1,args.f1_sha256,required)
    assert all(sha(n)==h for n,h in dynamic.items()) and all(sha(n)==h for n,h in base.SOURCES.items())
    assert sha(OLD138)==old_sha
    save(args.output_dir/'集計.json',output);save(args.output_dir/'CSV用の表.json',{'成功':True,'試行':143,'主政策':'T0','tables':tables})
    save(args.output_dir/'集計完了.json',{'成功':True,'試行':143,'前後不変':True,'モデルSHA256':args.model_sha256,'方向SHA256':args.choices_sha256,
        '全対照同体':native,'表形状':[(len(t['rows']),len(t['headers'])) for t in tables],
        '集計SHA256':sha(args.output_dir/'集計.json'),'表SHA256':sha(args.output_dir/'CSV用の表.json')})
    print(json.dumps({'成功':True,'主評価':main_result,'方向件数':selected['counts']},ensure_ascii=False))


if __name__=='__main__':main()
