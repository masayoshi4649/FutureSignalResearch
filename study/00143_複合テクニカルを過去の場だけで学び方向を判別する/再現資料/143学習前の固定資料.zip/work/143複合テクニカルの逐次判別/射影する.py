"""Root F0後、固定観測から143用教師を場ごとの別ファイルへ射影する。"""
import argparse
import json
from pathlib import Path
from data143 import join, project_labels
from io143 import MANIFEST, QUERIES, FEATURES, FIXED, OBSERVED, NONFINANCIAL, LABEL_SOURCES, sha, load, save, verify_freeze, local_sources


def main() -> None:
    """
    機能: 全73場の教師を物理分割し出典指紋を保存する。
    引数: --f0/--f0-sha256/--output-dir/--execute-after-f0。返り値: None。
    """
    p = argparse.ArgumentParser(description='143の過去場教師を射影')
    p.add_argument('--f0', type=Path, required=True); p.add_argument('--f0-sha256', required=True)
    p.add_argument('--output-dir', type=Path, required=True); p.add_argument('--execute-after-f0', action='store_true')
    args = p.parse_args(); assert args.execute_after_f0 and not args.output_dir.exists()
    required = {**NONFINANCIAL, **LABEL_SOURCES, **local_sources()}; verify_freeze(args.f0, args.f0_sha256, required)
    cohort = join(load(MANIFEST, NONFINANCIAL[MANIFEST]), load(QUERIES, NONFINANCIAL[QUERIES]), load(FEATURES, NONFINANCIAL[FEATURES]))
    labels = project_labels(load(OBSERVED, LABEL_SOURCES[OBSERVED]), load(FIXED, LABEL_SOURCES[FIXED]), cohort)
    files = []
    for doc in labels:
        path = args.output_dir/'場別'/f'{doc["session_index"]:02d}.json'; h = save(path, doc)
        files.append({k: doc[k] for k in ('session_index', 'session', 'start', 'end')} | {'path': str(path.resolve()), 'sha256': h})
    verify_freeze(args.f0, args.f0_sha256, required)
    h = save(args.output_dir/'ラベル参照.json', {'success': True, 'trial': 143, 'sessions': cohort['sessions'], 'files': files,
        'features_sha256': NONFINANCIAL[FEATURES], 'F0_SHA256': args.f0_sha256,
        'label_definition': '両H60complete、0逆/1未/2順、両endpointの最大時計',
        'sources': {str(path.resolve()): value for path, value in {**NONFINANCIAL, **LABEL_SOURCES}.items()}})
    print(json.dumps({'成功': True, '場数': len(files), 'ラベル参照SHA256': h}, ensure_ascii=False))


if __name__ == '__main__': main()
