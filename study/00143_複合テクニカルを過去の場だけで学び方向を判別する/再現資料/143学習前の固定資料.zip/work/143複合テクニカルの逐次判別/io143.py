"""143の明示ファイルとRoot固定だけを扱う。モデル学習・金融算術を含まない。"""
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
MANIFEST = ROOT/'work/全成立poolの非金融manifest/manifest.json'
QUERIES = ROOT/'work/138全成立入口の評価/固定入力_版2/特徴照会.json'
FEATURES = ROOT/'work/138全成立入口の評価/全出生の当時特徴.json'
FIXED = ROOT/'work/138全成立入口の評価/固定入力_版2/固定取得入力.json'
OBSERVED = ROOT/'work/138全成立入口の評価/固定取得の正逆観測.json'
NONFINANCIAL = {MANIFEST: 'e7ba444fd66f9ca52e10e929eeb31d21076f97afa161de738dabca14a8ff8e35',
               QUERIES: '81442c3ebaa3065213d0844417bb0462cfa3e5d0a05c4f44edfb3fb14191e75c',
               FEATURES: 'c2b9b8efeb65ba22b2dac3147fdefa3b513cb5cc61cd69249864065f2fcca6e4'}
LABEL_SOURCES = {FIXED: '0c83e525dec3079ce188d942069c0d137c94f39009339752ec8227ec9ecb4ce7',
                 OBSERVED: 'd272fc6f6768342ff67e1a9ec58b0b7307a0a5b07cc215ba5ff7bcb50865b742'}


def sha(path: Path) -> str:
    """
    機能: 明示ファイルのSHA256を求める。
    引数: path(Path)。
    返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path, expected: str) -> dict:
    """
    機能: SHA確認後だけJSONを読む。
    引数: path(Path)、expected(str)。
    返り値: dict。
    """
    assert len(expected) == 64 and all(c in '0123456789abcdef' for c in expected)
    body = path.read_bytes(); assert hashlib.sha256(body).hexdigest() == expected
    return json.loads(body)


def save(path: Path, data: dict) -> str:
    """
    機能: 未作成先だけへUTF-8 JSONを保存。
    引数: path(Path)、data(dict)。
    返り値: strはSHA。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(data, f, ensure_ascii=False, indent=2, allow_nan=False); f.write('\n')
    return sha(path)


def module(path: Path, name: str) -> object:
    """
    機能: 元源を変更せず私有import。
    引数: path(Path)、name(str)。
    返り値: object。
    """
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    return m


def verify_freeze(path: Path, expected: str, required: dict) -> tuple:
    """
    機能: Root143固定と必要源の現SHAを照合。
    引数: path(Path)、expected(str)、required(dict)。
    返り値: tuple。
    """
    fixed = load(path, expected); assert fixed['試行'] == 143
    declared = {Path(p).resolve(): h for p, h in fixed['ファイル'].items()}
    for p, h in required.items(): assert declared[p.resolve()] == h and sha(p) == h, p
    return fixed, declared


def local_sources() -> dict:
    """
    機能: F0/F1へ必要な143源を列挙。
    引数: なし。
    返り値: dict[Path,str]。自己proofは除く。
    """
    names = ('features143.py', 'data143.py', 'model143.py', 'logic143.py', 'io143.py', '射影する.py',
             '学習予測する.py', '人工検査.py', '集計する.py', '条件.md', '固定条件.json', '特徴系統.json', '依存版.json')
    return {HERE/n: sha(HERE/n) for n in names}


def load_prefix(prefix: list, current_index: int, current_session: str, current_start: float) -> list:
    """
    機能: 渡された過去prefixのラベルpathだけを開く。
    引数: prefix(list)、current_index(int)、current_session(str)、current_start(float)。返り値: list。
    """
    assert len(prefix) == current_index and [p['session_index'] for p in prefix] == list(range(current_index))
    result = []
    for item in prefix:
        assert item['session'] != current_session and item['start'] < current_start and item['end'] <= current_start
        doc = load(Path(item['path']), item['sha256'])
        assert all(doc[k] == item[k] for k in ('session_index', 'session', 'start', 'end'))
        result.append(doc)
    return result
