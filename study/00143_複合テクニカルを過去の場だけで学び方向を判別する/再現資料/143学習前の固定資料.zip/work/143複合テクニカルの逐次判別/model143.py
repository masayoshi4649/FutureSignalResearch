"""143の過去場限定CPU学習と現在特徴だけの予測。現在ラベルの引数は持たない。"""
from collections import Counter, defaultdict
import copy
import hashlib
import json
import math
from pathlib import Path
from features143 import NAMES, families, mirror, vector

PARAMS = {'iterations': 128, 'depth': 3, 'learning_rate': .05, 'l2_leaf_reg': 10,
          'loss_function': 'MultiClass', 'classes_count': 3, 'random_seed': 143,
          'boosting_type': 'Plain', 'bootstrap_type': 'No', 'random_strength': 0,
          'has_time': True, 'nan_mode': 'Min', 'use_best_model': False,
          'allow_writing_files': False, 'verbose': False, 'task_type': 'CPU', 'thread_count': 1}
EPSILON = 1e-12


def training_rows(prior_features: list, prior_labels: list, current_start: float) -> dict:
    """
    機能: 過去だけを受け取り、両方向/全originの配分と場等重みを作る。
    引数: prior_features(list)、prior_labels(list)、current_start(float)。返り値: dictは学習配列と監査。
    """
    assert math.isfinite(current_start)
    fby = {r['id']: r for r in prior_features}; assert len(fby) == len(prior_features)
    expected_ids, used_ids, sessions = set(), set(), []
    eligible, discarded, one_side = [], 0, 0
    for doc in prior_labels:
        assert doc['success'] and doc['trial'] == 143 and doc['start'] < current_start and doc['end'] <= current_start
        assert doc['session'] not in sessions; sessions.append(doc['session'])
        for row in doc['rows']:
            assert row['id'] not in expected_ids; expected_ids.add(row['id'])
            f = fby[row['id']]; assert f['session'] == row['session'] == doc['session'] and f['native_side'] == row['native_side']
            a, b = row['original'], row['reverse']
            pair = a['complete'] and b['complete']; assert row['eligible_pair'] is pair
            assert row['one_side_only_complete'] is (a['complete'] != b['complete'])
            one_side += row['one_side_only_complete']
            if not pair:
                discarded += 1
                continue
            assert all(type(v['class']) is int and v['class'] in (0, 1, 2) for v in (a, b))
            known_at = max(a['known_at'], b['known_at'])
            assert row['label_known_at'] == known_at and math.isfinite(known_at) and known_at < current_start
            eligible.append((f, row)); used_ids.add(row['id'])
    assert expected_ids == set(fby)
    by_scene = Counter(f['session'] for f, _ in eligible)
    x, y, weights, query_ids, row_keys = [], [], [], [], []
    for f, row in eligible:
        assert f['origins']
        base = 1/(len(f['origins'])*2*by_scene[f['session']])
        for origin in sorted(f['origins'], key=lambda o: o['origin_index']):
            for reverse in (False, True):
                values = mirror(origin['values']) if reverse else origin['values']
                x.append(vector(values)); y.append(row['reverse' if reverse else 'original']['class']); weights.append(base)
                query_ids.append(origin['query_id']); row_keys.append({'id': f['id'], 'session': f['session'],
                    'query_id': origin['query_id'], 'origin_index': origin['origin_index'], 'reverse': reverse})
    if x:
        factor = len(x)/len(by_scene)
        weights = [v*factor for v in weights]
        totals = defaultdict(float)
        for w, key in zip(weights, row_keys): totals[key['session']] += w
        assert max(totals.values())-min(totals.values()) < 1e-8 and abs(sum(weights)-len(weights)) < 1e-8
    else:
        totals = {}
    audit = {'training_sessions': sessions, 'training_case_ids': [f['id'] for f, _ in eligible],
             'training_query_ids': list(dict.fromkeys(query_ids)), 'training_canonical_complete_pairs': len(eligible),
             'discarded_incomplete_canonical': discarded, 'one_side_only_complete': one_side,
             'training_physical_rows': len(x), 'classes': sorted(set(y)), 'class_rows': dict(Counter(y)),
             'max_label_known_at': max((r['label_known_at'] for _, r in eligible), default=None),
             'current_start': current_start, 'scene_weight_sums': dict(totals),
             'protected_baseline_canonical_included_once': sum(f['baseline'] for f, _ in eligible),
             'current_labels_received': False, 'feature_names': list(NAMES),
             'row_order': '過去場の保存case順→origin_index順→native/実逆'}
    return {'X': x, 'y': y, 'weights': weights, 'audit': audit}


def used_families(exported: dict) -> dict:
    """
    機能: 公開JSONの実FloatFeature分岐を1系統ずつ数える。
    引数: exported(dict)。返り値: dictは使用列と系統。重要度を使わない。
    """
    floats = {f['feature_index']: f for f in exported['features_info']['float_features']}
    indices = set()
    for tree in exported['oblivious_trees']:
        for split in tree.get('splits') or []:
            assert split['split_type'] == 'FloatFeature'
            feature = floats[split['float_feature_index']]
            index = feature['flat_feature_index']; assert feature['feature_id'] == NAMES[index]
            indices.add(index)
    names = [NAMES[i] for i in sorted(indices)]; mapping = families()
    return {'used_features': names, 'used_technical_families': sorted({mapping[n] for n in names}),
            'criterion': 'public export JSONの実FloatFeature分岐。正規化ATRによる二重票なし'}


def fit(prior_features: list, prior_labels: list, current_start: float, model_path: Path) -> tuple:
    """
    機能: 過去完了32canonical/3class以上だけで固定CPUモデルを学ぶ。
    引数: prior_features/prior_labels(list)、current_start(float)、model_path(Path)。
    返り値: tuple[object|None,dict]は適格モデル又はfallbackと監査。現在特徴/ラベルは渡さない。
    """
    training = training_rows(prior_features, prior_labels, current_start); audit = training['audit']
    if audit['training_canonical_complete_pairs'] < 32:
        return None, {'status': 'insufficient_complete32', 'model_ref': None, 'training': audit}
    if audit['classes'] != [0, 1, 2]:
        return None, {'status': 'missing_three_classes', 'model_ref': None, 'training': audit}
    import catboost
    from catboost import CatBoostClassifier, Pool
    assert catboost.__version__ == '1.2.10'
    pool = Pool(training['X'], label=training['y'], weight=training['weights'], feature_names=list(NAMES))
    model = CatBoostClassifier(**PARAMS); model.fit(pool)
    assert list(model.classes_) == [0, 1, 2]
    assert not model_path.exists(); model_path.parent.mkdir(parents=True, exist_ok=True)
    model.save_model(str(model_path), format='json')
    body = model_path.read_bytes(); exported = json.loads(body); used = used_families(exported)
    ref = {'path': str(model_path.resolve()), 'sha256': hashlib.sha256(body).hexdigest(), 'format': 'catboost_json',
           'catboost_version': catboost.__version__, 'parameters': model.get_all_params(), **used}
    eligible = len(used['used_technical_families']) >= 2
    audit['used_split_families'] = used
    return model if eligible else None, {'status': 'active' if eligible else 'fewer_than_two_technical_families',
                                         'model_ref': ref, 'training': audit}


def probability_choice(side: int, native: list, reverse: list) -> dict:
    """
    機能: 2側のP順−P逆を比べ、同点はnativeへする。
    引数: side(int)、native/reverse(list[float])。返り値: dictは確率/score/選択物理方向。
    """
    assert side in (-1, 1)
    for p in (native, reverse):
        assert len(p) == 3 and all(math.isfinite(v) and 0 <= v <= 1 for v in p) and abs(sum(p)-1) < 1e-9
    a, b = native[2]-native[0], reverse[2]-reverse[0]
    tie = abs(a-b) <= EPSILON
    return {'native_probabilities': list(native), 'reverse_probabilities': list(reverse),
            'native_score': a, 'reverse_score': b, 'tie': tie,
            'selected_side': -side if b-a > EPSILON else side}


def score(model: object | None, current_features: list, audit: dict) -> list:
    """
    機能: 現場特徴だけを予測し全origin方向票の材料を作る。
    引数: model(object|None)、current_features(list)、audit(dict)。返り値: list[dict]。ラベル引数なし。
    """
    rows, x, positions = [], [], []
    for f in current_features:
        row = {'id': f['id'], 'session': f['session'], 'native_side': f['native_side'], 'baseline': f['baseline'],
               'model_status': audit['status'], 'model_ref': copy.deepcopy(audit['model_ref']), 'origins': []}
        for origin in f['origins']:
            item = {'query_id': origin['query_id'], 'origin_index': origin['origin_index'],
                    'probabilities': None, 'selected_side': f['native_side'],
                    'fallback': 'protected_baseline' if f['baseline'] else audit['status'] if model is None else None}
            row['origins'].append(item)
            if model is not None and not f['baseline']:
                x.extend([vector(origin['values']), vector(mirror(origin['values']))])
                positions.append((item, f['native_side']))
        rows.append(row)
    if x:
        predictions = model.predict_proba(x).tolist(); assert len(predictions) == len(x)
        for i, (item, side) in enumerate(positions):
            vote = probability_choice(side, predictions[2*i], predictions[2*i+1])
            item['probabilities'] = vote; item['selected_side'] = vote['selected_side']
    return rows
