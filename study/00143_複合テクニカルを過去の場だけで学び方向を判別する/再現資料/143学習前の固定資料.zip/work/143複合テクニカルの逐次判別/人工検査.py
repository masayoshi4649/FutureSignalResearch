"""143の純鏡像・過去限定学習・同一モデル再推論を人工資料だけで検査する。"""
import copy
import importlib.util
import json
import math
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from features143 import NAMES, families, mirror, vector
from data143 import INPUT_SHA, QUERY_SHA, MANIFEST_SHA, origin_query, join, label
from model143 import training_rows, fit, score, probability_choice, used_families
from logic143 import choose, fixed_spec
from io143 import save, load_prefix


def values(x=0., y=0.) -> dict:
    """
    機能: 固定74列の人工known値を作る。
    引数: x/y(float)。
    返り値: dict。
    """
    out = {n: {'known': True, 'value': 0.} for n in NAMES}
    out['m5_gap_to_side']['value'] = x; out['m5_hist_to_side']['value'] = y
    for n in ('bb15_percent_to_side', 'm5_close_position_to_side'): out[n]['value'] = .5
    for n in ('m5_forward_wick_ratio', 'm5_opposite_wick_ratio'): out[n]['value'] = .2
    out['m5_atr']['value'] = 100.
    return out


def prior_fixture():
    """
    機能: 2過去場32canonicalを作る。
    引数: なし。
    返り値: tupleは特徴/教師。
    """
    features, labels = [], []
    for scene in range(2):
        doc = {'success': True, 'trial': 143, 'session_index': scene, 'session': f'過去{scene}',
               'start': scene*3000, 'end': (scene+1)*3000, 'rows': []}
        for i in range(16):
            x, y = (1. if i & 1 else -1.), (1. if i & 2 else -1.)
            forward = 2 if x > 0 and y > 0 else 0 if x < 0 and y < 0 else 1
            reverse = 0 if forward == 2 else 2 if forward == 0 else 1
            identity = f'P0/{scene}/{i}'
            features.append({'id': identity, 'session': doc['session'], 'native_side': 1, 'baseline': i < 2,
                'origins': [{'query_id': f'q/{scene}/{i}/{o}', 'origin_index': o, 'values': values(x, y)} for o in range(2 if i == 0 else 1)]})
            at = doc['end']-100
            doc['rows'].append({'id': identity, 'session': doc['session'], 'native_side': 1,
                'original': {'complete': True, 'class': forward, 'known_at': at},
                'reverse': {'complete': True, 'class': reverse, 'known_at': at},
                'eligible_pair': True, 'label_known_at': at, 'one_side_only_complete': False})
        labels.append(doc)
    return features, labels


def joined_fixture():
    """
    機能: 全833/850/769形の人工cohortを作る。
    引数: なし。
    返り値: tuple。
    """
    manifest = {'success': True, 'financial_labels_used': False, 'C0': [], 'P0': [],
                'frequency': {'P0': {'scenes': [{'session': f'人工/{i}'} for i in range(73)]}}}
    queries = {'success': True, 'trial': 138, 'manifest_sha256': MANIFEST_SHA, 'queries': [], 'relations': []}
    features = {'success': True, 'input_sha256': INPUT_SHA, 'queries_sha256': QUERY_SHA, 'financial_labels_used': False,
                'entry_prices_used': False, 'source_scene_count': 73, 'query_count': 769,
                'catalog': {n: {} for n in NAMES}, 'rows': []}
    counter = 0
    for i in range(752):
        q = {'time': 200000+i*100, 'index': 10000+i*100, 'source_line': 10050+i*100,
             'last': 1000, 'bid': 990, 'ask': 1010, 'quote_ok': True}
        c = {'id': f'人工/{i}', 'session': f'人工/{i%73}', 'contract': '人工', 'side': 1,
             'baseline': i < 81, 'entryQuote': q, 'origins': []}
        for oi in range(2 if 81 <= i < 98 else 1):
            b = {k: q[k]-2-oi for k in ('time', 'index', 'source_line')}; b['last'] = 1000
            origin = {'source_file_sha': f'{counter:064x}', 'source_locator': {'人工': counter}, 'side': 1,
                      'family': '人工', 'birthQuote': b, 'entryQuote': copy.deepcopy(q)}
            c['origins'].append(origin); query = origin_query(origin, c); queries['queries'].append(query)
            refs, feet = [], {}
            for m, age in ((5, 120), (15, 200), (30, 400)):
                at = {k: b[k]-1 for k in ('time', 'index', 'source_line')}; end = b['time']-age
                feet[f'm{m}'] = {'end': end, 'available_at': end+60, 'delivery_at': at['time'], 'delivered': at}
                refs.append({'id': f'公表/{counter}/{m}', 'width_seconds': m*60, 'end': end, 'delivered': at})
            v = values(); features['rows'].append({'query': query, 'values': v,
                'known_mask': {n: True for n in NAMES}, 'refs': refs, 'feet': feet}); counter += 1
        manifest['P0'].append(c)
        if i < 81: manifest['C0'].append(copy.deepcopy(c))
    for model in ('C0', 'P0'):
        for index, c in enumerate(manifest[model]):
            for oi, o in enumerate(c['origins']):
                q = origin_query(o, c)
                queries['relations'].append({'entry_id': model+'/'+c['id'], 'query_id': q['id'], 'model': model,
                    'manifest_index': index, 'origin_index': oi, 'family': o['family'], 'side': 1, 'selected_side': 1})
    return manifest, queries, features


class Cases(unittest.TestCase):
    """自然資料を読まず143の因果境界とCPU実装を確認します。"""

    def test_74列鏡像と未知交換(self):
        """
        機能: 鏡像2回とknown交換を検査。
        引数: self(Cases)。
        返り値: None。
        """
        v = values(2, -1); v['bb15_percent_to_side']['value'] = 1.4
        v['m5_forward_wick_ratio'] = {'known': False, 'value': None}
        original = copy.deepcopy(v); m = mirror(v)
        self.assertAlmostEqual(m['bb15_percent_to_side']['value'], -.4)
        self.assertEqual(m['m5_opposite_wick_ratio'], {'known': False, 'value': None})
        self.assertEqual(m['m5_forward_wick_ratio']['value'], .2)
        self.assertTrue(all((mirror(m)[n]['known'] == v[n]['known'] and (not v[n]['known'] or math.isclose(mirror(m)[n]['value'], v[n]['value']))) for n in NAMES))
        self.assertEqual(v, original); self.assertTrue(math.isnan(vector(v)[list(NAMES).index('m5_forward_wick_ratio')]))
        self.assertEqual(families()['m5_price_ema21_atr_to_side'], 'MA')
        self.assertEqual(families()['m5_hist_delta_atr_to_side'], 'MACD')
        self.assertEqual(families()['bb15_width_atr_ratio'], 'BB')
        self.assertEqual(len(set(families().values())), 8)

    def test_教師時計と片側完了除外(self):
        """
        機能: endpointでH完了を知り片側完了を補完しない。
        引数: self(Cases)。
        返り値: None。
        """
        q = {'time': 3700, 'index': 5, 'source_line': 10, 'bid': 100, 'ask': 110, 'quote_ok': True}
        stream = {'entry': {'time': 100, 'index': 1, 'source_line': 2},
                  'outcomes': [{'seconds': 3600, 'deadline': 3700, 'status': 'complete', 'endpoint': q,
                    'touches': [{'width': 125, 'direction': 1, 'quote': q}]}]}
        self.assertEqual(label(stream, 4000), {'complete': True, 'class': 2, 'known_at': 3700})
        stream['outcomes'][0]['endpoint']['time'] = 3699
        with self.assertRaises(AssertionError): label(stream, 4000)
        f, docs = prior_fixture(); r = docs[0]['rows'][0]; r['reverse'] = {'complete': False, 'class': None, 'known_at': None}
        r['eligible_pair'], r['one_side_only_complete'], r['label_known_at'] = False, True, None
        t = training_rows(f, docs, 7000)
        self.assertEqual(t['audit']['training_canonical_complete_pairs'], 31); self.assertEqual(t['audit']['one_side_only_complete'], 1)

    def test_場等重みと未来拒否(self):
        """
        機能: origin重複を等配分しcurrentStart等号を拒否。
        引数: self(Cases)。
        返り値: None。
        """
        f, docs = prior_fixture(); t = training_rows(f, docs, 7000)
        self.assertEqual(t['audit']['training_canonical_complete_pairs'], 32)
        sums = list(t['audit']['scene_weight_sums'].values()); self.assertAlmostEqual(sums[0], sums[1]); self.assertAlmostEqual(sum(t['weights'])/len(t['weights']), 1)
        r = docs[0]['rows'][0]; r['label_known_at'] = 7000; r['original']['known_at'] = 7000
        with self.assertRaises(AssertionError): training_rows(f, docs, 7000)

    def test_CPU固定学習とモデル再推論(self):
        """
        機能: 実CPU学習/系統guard/同一モデル再推論を確認。
        引数: self(Cases)。
        返り値: None。
        """
        from catboost import CatBoostClassifier
        f, docs = prior_fixture(); before = copy.deepcopy((f, docs))
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/'model.json'; model, audit = fit(f, docs, 7000, path)
            self.assertEqual(audit['status'], 'active'); self.assertGreaterEqual(len(audit['model_ref']['used_technical_families']), 2)
            test = copy.deepcopy(f[:2]); test[0]['baseline'] = False
            result = score(model, test, audit)
            loaded = CatBoostClassifier(); loaded.load_model(str(path), format='json')
            self.assertEqual(result, score(loaded, test, audit))
            again, audit2 = fit(f, docs, 7000, Path(folder)/'again.json')
            a = score(again, test, audit2)
            self.assertEqual([o['probabilities'] for r in result for o in r['origins']], [o['probabilities'] for r in a for o in r['origins']])
            self.assertEqual((f, docs), before)

    def test_prefixだけ読取と初期8場(self):
        """
        機能: current/futureラベルpathを開かない。
        引数: self(Cases)。
        返り値: None。
        """
        f, docs = prior_fixture()
        with tempfile.TemporaryDirectory() as folder:
            prefix = []
            for doc in docs:
                path = Path(folder)/f'{doc["session_index"]}.json'; h = save(path, doc)
                prefix.append({k: doc[k] for k in ('session_index', 'session', 'start', 'end')} | {'path': str(path), 'sha256': h})
            current = Path(folder)/'現在.json'; current.write_text('{"class":2}', encoding='utf-8')
            original = Path.read_bytes
            def guarded(path):
                """
                機能: 現在ラベルの読取を人工的に禁止する。
                引数: path(Path)。返り値: bytesは許可された過去ファイル。
                """
                if path == current: raise RuntimeError('現在label読取')
                return original(path)
            with patch.object(Path, 'read_bytes', guarded):
                loaded = load_prefix(prefix, 2, '現在', 7000); self.assertEqual(loaded, docs)
                a, audit_a = fit(f, loaded, 7000, Path(folder)/'a.json')
                current.write_text('{"class":0,"未来ラベルを全て変更":true}', encoding='utf-8')
                loaded_again = load_prefix(prefix, 2, '現在', 7000)
                b, audit_b = fit(f, loaded_again, 7000, Path(folder)/'b.json')
                test = copy.deepcopy(f[:2]); test[0]['baseline'] = False
                ap = score(a, test, audit_a); bp = score(b, test, audit_b)
                self.assertEqual([o['probabilities'] for r in ap for o in r['origins']], [o['probabilities'] for r in bp for o in r['origins']])
            with self.assertRaises(AssertionError): load_prefix(prefix+[{'session_index': 2}], 2, '現在', 7000)

    def test_全結合と保護とfallback(self):
        """
        機能: 全752/81/73と初期/不足fallbackを再結合。
        引数: self(Cases)。
        返り値: None。
        """
        data = joined_fixture(); cohort = join(*data); models, rows = [], []
        for i, session in enumerate(cohort['sessions']):
            audit = {'status': 'warmup8' if i < 8 else 'insufficient_complete32', 'model_ref': None,
                     'training': None if i < 8 else {'training_sessions': cohort['sessions'][:i],
                        'current_start': i*10000, 'max_label_known_at': None, 'training_canonical_complete_pairs': 0, 'classes': []}}
            models.append({'session_index': i, 'session': session, 'start': i*10000, **audit})
            rows.extend(score(None, [r for r in cohort['rows'] if r['session'] == session], audit))
        p = {'success': True, 'trial': 143, 'sessions': cohort['sessions'], 'features_sha256': fixed_spec()['features_sha256'],
             'feature_names': list(NAMES), 'models': models, 'rows': rows}
        got = choose(*data, p)
        self.assertEqual(len(got['rows']), 752); self.assertEqual(got['counts'], {'keep': 752})
        self.assertEqual(sum(r['fallback_kind'] == 'baseline' for r in got['rows']), 81)
        self.assertFalse(any(r['model_applied'] for r in got['rows']))

    def test_逐次制御のprefix物理分離(self):
        """
        機能: 実行制御が初期8無学習/以後prefixのみを渡す。
        引数: self(Cases)。
        返り値: None。
        """
        path = Path(__file__).with_name('学習予測する.py')
        spec = importlib.util.spec_from_file_location('人工逐次143', path); cli = importlib.util.module_from_spec(spec); spec.loader.exec_module(cli)
        cohort = join(*joined_fixture()); opened = []
        files = [{'session_index': i, 'session': s, 'start': i*10000, 'end': i*10000+9000,
                  'path': f'開くことのない人工/{i}', 'sha256': '0'*64} for i, s in enumerate(cohort['sessions'])]
        def prefix_only(prefix, index, session, start):
            """
            機能: 逐次制御から渡るpath列が過去だけか確認する。
            引数: prefix(list)、index(int)、session(str)、start(float)。返り値: listは人工過去資料。
            """
            self.assertGreaterEqual(index, 8); self.assertEqual([f['session_index'] for f in prefix], list(range(index)))
            self.assertTrue(all(f['session'] != session for f in prefix)); opened.append(index)
            return [{**item, 'success': True, 'trial': 143, 'rows': []} for item in prefix]
        def no_fit(features, labels, start, path):
            """
            機能: 逐次制御の検査で学習せず不足fallbackを返す。
            引数: features/labels(list)、start(float)、path(Path)。返り値: tupleはNoneと監査。
            """
            self.assertEqual(features, [])
            return None, {'status': 'insufficient_complete32', 'model_ref': None,
                'training': {'training_sessions': [d['session'] for d in labels], 'current_start': start,
                             'max_label_known_at': None, 'training_canonical_complete_pairs': 0, 'classes': []}}
        with tempfile.TemporaryDirectory() as folder, patch.object(cli, 'load_prefix', prefix_only), patch.object(cli, 'fit', no_fit):
            models, rows = cli.sequential(cohort, {'success': True, 'trial': 143, 'sessions': cohort['sessions'], 'files': files}, Path(folder))
        self.assertEqual(opened, list(range(8, 73))); self.assertEqual(len(rows), 752)
        self.assertTrue(all(m['status'] == 'warmup8' for m in models[:8]))

    def test_score同点と実系統の二重計上防止(self):
        """
        機能: 同点nativeと実分岐の系統判定を検査。
        引数: self(Cases)。
        返り値: None。
        """
        a, b = [.1, .2, .7], [.7, .2, .1]
        self.assertEqual(probability_choice(1, a, b)['selected_side'], probability_choice(-1, b, a)['selected_side'])
        self.assertEqual(probability_choice(-1, a, a)['selected_side'], -1)
        i = list(NAMES).index('m5_price_ema21_atr_to_side')
        exported = {'features_info': {'float_features': [{'feature_index': 0, 'flat_feature_index': i, 'feature_id': NAMES[i]}]},
                    'oblivious_trees': [{'splits': [{'split_type': 'FloatFeature', 'float_feature_index': 0}]}]}
        self.assertEqual(used_families(exported)['used_technical_families'], ['MA'])


if __name__ == '__main__': unittest.main(verbosity=2)
