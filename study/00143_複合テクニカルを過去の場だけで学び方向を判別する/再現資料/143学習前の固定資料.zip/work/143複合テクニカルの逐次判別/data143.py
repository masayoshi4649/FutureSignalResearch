"""143の完全結合とH60完了教師の場別射影。学習器へ現在ラベルを渡さない。"""
import copy
import hashlib
import json
import math
from features143 import NAMES, validate

INPUT_SHA = '6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec'
QUERY_SHA = '81442c3ebaa3065213d0844417bb0462cfa3e5d0a05c4f44edfb3fb14191e75c'
MANIFEST_SHA = 'e7ba444fd66f9ca52e10e929eeb31d21076f97afa161de738dabca14a8ff8e35'
FEATURES_SHA = 'c2b9b8efeb65ba22b2dac3147fdefa3b513cb5cc61cd69249864065f2fcca6e4'


def stamp(quote: dict) -> tuple:
    """
    機能: 有限時計と非負採用順/正原行を検査する。
    引数: quote(dict)。返り値: tuple。
    """
    assert type(quote['time']) in (int, float) and math.isfinite(quote['time'])
    assert type(quote['index']) is int and quote['index'] >= 0
    assert type(quote['source_line']) is int and quote['source_line'] > 0
    return tuple(quote[k] for k in ('time', 'index', 'source_line'))


def origin_query(origin: dict, candidate: dict) -> dict:
    """
    機能: 固定138の由来hashから照会を再構築する。
    引数: origin/candidate(dict)。返り値: dict。
    """
    birth = origin['birthQuote']; at = stamp(birth)
    key = json.dumps([origin['source_file_sha'], origin['source_locator'], origin['side'], at],
                     ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
    return {'id': 'origin/'+hashlib.sha256(key).hexdigest()[:32], 'session': candidate['session'],
            'contract': candidate['contract'], 'side': origin['side'],
            'birthQuote': {k: birth[k] for k in ('time', 'index', 'source_line', 'last')}}


def join(manifest: dict, queries: dict, features: dict) -> dict:
    """
    機能: 833入口/850由来/769出生を結合しP0だけを学習単位へ射影する。
    引数: manifest/queries/features(dict)。返り値: dictは752canonicalと73順。
    """
    assert manifest['success'] and not manifest['financial_labels_used']
    assert queries['success'] and queries['trial'] == 138 and queries['manifest_sha256'] == MANIFEST_SHA
    assert features['success'] and features['input_sha256'] == INPUT_SHA and features['queries_sha256'] == QUERY_SHA
    assert features['financial_labels_used'] is False and features['entry_prices_used'] is False
    assert features['source_scene_count'] == 73 and features['query_count'] == 769
    qmap = {q['id']: q for q in queries['queries']}; fmap = {r['query']['id']: r for r in features['rows']}
    assert len(qmap) == len(queries['queries']) == len(fmap) == len(features['rows']) == 769 and set(qmap) == set(fmap)
    assert set(features['catalog']) == set(NAMES)
    for key, f in fmap.items():
        q = qmap[key]; at = stamp(q['birthQuote']); assert f['query'] == q
        validate(f['values']); assert all(f['known_mask'][n] is f['values'][n]['known'] for n in NAMES)
        for ref in f['refs']:
            assert ref['end'] <= at[0] and all(a <= b for a, b in zip(stamp(ref['delivered']), at))
        for minute in (5, 15, 30):
            foot = f['feet']['m'+str(minute)]
            if foot is not None:
                assert foot['end'] <= foot['available_at'] <= foot['delivery_at'] <= foot['delivered']['time'] <= at[0]
                assert all(a <= b for a, b in zip(stamp(foot['delivered']), at))
                assert at[0] < foot['end']+minute*60+60
    rels = {(r['model'], r['manifest_index'], r['origin_index']): r for r in queries['relations']}
    assert len(rels) == len(queries['relations']) == 850
    assert [len(manifest[m]) for m in ('C0', 'P0')] == [81, 752]
    sessions = [r['session'] for r in manifest['frequency']['P0']['scenes']]
    assert len(sessions) == len(set(sessions)) == 73
    controls = {c['id']: c for c in manifest['C0']}; assert len(controls) == 81
    used, seen, rows, entry_origins = set(), set(), [], []
    for model in ('C0', 'P0'):
        identities = set()
        for index, c in enumerate(manifest[model]):
            assert c['id'] not in identities and c['session'] in sessions; identities.add(c['id'])
            assert type(c['baseline']) is bool and type(c['side']) is int and c['side'] in (-1, 1)
            if model == 'C0' or c['baseline']:
                assert c['baseline'] and c['id'] in controls
                assert all(c[k] == controls[c['id']][k] for k in ('session', 'contract', 'side', 'entryQuote'))
            origins = []
            for oi, origin in enumerate(c['origins']):
                q = origin_query(origin, c); qid = q['id']; rkey = (model, index, oi)
                assert qmap[qid] == q and q['side'] == c['side']
                assert rels[rkey] == {'entry_id': model+'/'+c['id'], 'query_id': qid, 'model': model,
                    'manifest_index': index, 'origin_index': oi, 'family': origin['family'],
                    'side': origin['side'], 'selected_side': c['side']}
                assert all(a <= b for a, b in zip(stamp(q['birthQuote']), stamp(c['entryQuote'])))
                assert all(origin['entryQuote'][k] == c['entryQuote'][k] for k in ('time', 'index', 'source_line', 'last', 'bid', 'ask', 'quote_ok'))
                origins.append({'query_id': qid, 'origin_index': oi, 'values': copy.deepcopy(fmap[qid]['values']),
                    'refs': copy.deepcopy(fmap[qid]['refs']), 'birthQuote': copy.deepcopy(q['birthQuote'])})
                used.add(qid); seen.add(rkey)
            assert origins
            entry_origins.append({'id': model+'/'+c['id'], 'session': c['session'], 'model': model,
                                  'origin_query_ids': [o['query_id'] for o in origins]})
            if model == 'P0':
                rows.append({'id': 'P0/'+c['id'], 'session': c['session'], 'native_side': c['side'],
                             'baseline': c['baseline'], 'origins': origins})
    assert len(rows) == 752 and len({r['id'] for r in rows}) == 752 and sum(r['baseline'] for r in rows) == 81
    assert used == set(qmap) and seen == set(rels) and len(entry_origins) == 833
    return {'sessions': sessions, 'rows': rows, 'entry_origins': entry_origins,
            'join_proof': {'P0': 752, 'C0': 81, 'entries': 833, 'relations': 850, 'unique_queries': 769,
                           'all_relations_joined': True, 'all_queries_used': True}}


def label(stream: dict, execution_end: float) -> dict:
    """
    機能: H60完了だけを3classへ写しendpointで知得時計を定める。
    引数: stream(dict)、execution_end(float)。返り値: dict。IFD金額は読まない。
    """
    h = next(h for h in stream['outcomes'] if h['seconds'] == 3600)
    assert h['deadline'] == stream['entry']['time']+3600
    complete = h['status'] == 'complete'
    if not complete:
        assert h['endpoint'] is None
        return {'complete': False, 'class': None, 'known_at': None}
    q = h['endpoint']; assert q is not None and h['deadline'] <= q['time'] <= h['deadline']+30 and q['time'] < execution_end
    assert q['quote_ok'] and 0 < q['bid'] < q['ask']
    assert q['index'] > stream['entry']['index'] and q['source_line'] > stream['entry']['source_line']
    touch = next(t for t in h['touches'] if t['width'] == 125)
    assert touch['direction'] in (-1, 0, 1) and (touch['quote'] is None) == (touch['direction'] == 0)
    return {'complete': True, 'class': touch['direction']+1, 'known_at': q['time']}


def project_labels(observed: dict, fixed: dict, cohort: dict) -> list:
    """
    機能: 全P0を各場1ファイルの教師へ射影し片側完了を別記する。
    引数: observed/fixed/cohort(dict)。返り値: list[dict]は73場別教師。
    """
    assert observed['success'] and observed['trial'] == 133 and observed['source_entry_count'] == fixed['expected_entry_count'] == 833
    assert [s['session'] for s in observed['scenes']] == [s['session'] for s in fixed['scenes']] == cohort['sessions']
    cmap = {r['id']: r for r in cohort['rows']}; result, seen = [], set()
    for index, (scene, meta) in enumerate(zip(observed['scenes'], fixed['scenes'])):
        assert scene['success'] and scene['execution_end'] == meta['end']-300
        rows = []
        for c in scene['cases']:
            if not c['id'].startswith('P0/'):
                continue
            f = cmap[c['id']]; assert f['session'] == scene['session'] and c['original_side'] == f['native_side']
            assert c['original']['entry'] == c['reverse']['entry']
            for reverse in (False, True):
                stream = c['reverse' if reverse else 'original']
                assert stream['status'] == 'filled' and stream['axis'] == 'BBO'
                assert stream['birth']['side'] == (-c['original_side'] if reverse else c['original_side'])
            a, b = label(c['original'], scene['execution_end']), label(c['reverse'], scene['execution_end'])
            pair = a['complete'] and b['complete']
            known_at = max(a['known_at'], b['known_at']) if pair else None
            rows.append({'id': c['id'], 'session': scene['session'], 'native_side': c['original_side'],
                         'original': a, 'reverse': b, 'eligible_pair': pair, 'label_known_at': known_at,
                         'one_side_only_complete': a['complete'] != b['complete']})
            assert c['id'] not in seen; seen.add(c['id'])
        result.append({'success': True, 'trial': 143, 'session_index': index, 'session': scene['session'],
                       'start': meta['start'], 'end': meta['end'], 'rows': rows})
    assert seen == set(cmap) and len(result) == 73
    return result
