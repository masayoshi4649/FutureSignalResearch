"""143の固定仕様と、予測済み全originの純再結合。再学習や金融I/Oをしない。"""
from collections import Counter
import copy
from features143 import NAMES, families
from model143 import PARAMS, EPSILON, probability_choice
from data143 import INPUT_SHA, QUERY_SHA, MANIFEST_SHA, FEATURES_SHA, join


def fixed_spec() -> dict:
    """
    機能: F0前に固定する逐次判別仕様を返す。
    引数: なし。返り値: dict。
    """
    return {'success': True, 'trial': 143, 'learned': True, 'learning_scope': '各場より前の完了場だけ',
        'main_policy': 'T0', 'controls': ['P0', 'C0'], 'entries': 752, 'sessions': 73, 'protected_baseline': 81,
        'features': list(NAMES), 'feature_families': families(), 'classes': {'0': '逆行先着', '1': '未到達', '2': '順行先着'},
        'horizon_seconds': 3600, 'width_points': 125, 'warmup_sessions': 8, 'minimum_complete_canonical': 32,
        'complete_canonical': '原/実逆が両H60complete、label_known_at=max両endpoint.time)<currentStart',
        'three_classes_required': True, 'minimum_used_families': 2,
        'family_guard': 'public export JSONの実FloatFeature分岐を1列1系統へ分類、2系統以上',
        'catboost_version': '1.2.10', 'parameters': dict(PARAMS), 'unknown': 'NaN、0補完なし',
        'training_weight': 'canonical内originと2方向へ等配分、過去場等重み、全行平均1',
        'baseline_in_training': 'P0の81保護canonicalを各1回含め、別C0を重ねない',
        'prediction': '両物理側のP順-P逆を比較、差の絶対値<=1e-12はnative', 'tie_tolerance': EPSILON,
        'all_origins': '同じnative基準、最終物理方向全一致で採用、競合はnative',
        'baseline': '旧81の方向と取得時計を保護、モデル再適用なし',
        'current_labels_received_by_train_or_score': False, 'retraining_after_f1': False,
        'model_reproducibility': 'F1後の同一JSONモデル再推論と、再学習数値再現を区別。GUID/時刻を含むSHA再同体は保証しない',
        'all_period_previously_used': True, 'new_order_geometry_rebuilt': False,
        'input_sha256': INPUT_SHA, 'queries_sha256': QUERY_SHA, 'manifest_sha256': MANIFEST_SHA, 'features_sha256': FEATURES_SHA}


def choose(manifest: dict, queries: dict, features: dict, predictions: dict) -> dict:
    """
    機能: 固定済み予測を出生へ再結合し、確率から全752方向を再計算する。
    引数: manifest/queries/features/predictions(dict)。返り値: dictは142互換方向票。学習しない。
    """
    cohort = join(manifest, queries, features)
    assert predictions['success'] and predictions['trial'] == 143 and predictions['sessions'] == cohort['sessions']
    assert predictions['features_sha256'] == FEATURES_SHA and predictions['feature_names'] == list(NAMES)
    pby = {p['id']: p for p in predictions['rows']}; assert len(pby) == len(predictions['rows']) == 752
    models = {m['session']: m for m in predictions['models']}; assert len(models) == len(predictions['models']) == 73
    for index, session in enumerate(cohort['sessions']):
        m = models[session]; assert m['session_index'] == index
        if index < 8:
            assert m['status'] == 'warmup8' and m['model_ref'] is None and m['training'] is None
            continue
        assert m['status'] in ('active', 'insufficient_complete32', 'missing_three_classes', 'fewer_than_two_technical_families')
        a = m['training']; assert a['training_sessions'] == cohort['sessions'][:index]
        assert a['current_start'] == m['start'] and (a['max_label_known_at'] is None or a['max_label_known_at'] < m['start'])
        if m['status'] == 'insufficient_complete32': assert a['training_canonical_complete_pairs'] < 32
        elif m['status'] == 'missing_three_classes': assert a['training_canonical_complete_pairs'] >= 32 and a['classes'] != [0, 1, 2]
        else:
            assert a['training_canonical_complete_pairs'] >= 32 and a['classes'] == [0, 1, 2]
            roles = m['model_ref']['used_technical_families']
            assert (len(roles) >= 2) is (m['status'] == 'active')
    rows = []
    for f in cohort['rows']:
        p = pby[f['id']]; assert all(p[k] == f[k] for k in ('id', 'session', 'native_side', 'baseline'))
        m = models[f['session']]; assert p['model_status'] == m['status'] and p['model_ref'] == m['model_ref']
        if m['status'] == 'active':
            a = m['training']; assert a['training_canonical_complete_pairs'] >= 32 and a['classes'] == [0, 1, 2]
            assert a['max_label_known_at'] < m['start'] and len(m['model_ref']['used_technical_families']) >= 2
            assert f['session'] not in a['training_sessions']
        assert len(p['origins']) == len(f['origins'])
        votes = []
        for original, saved in zip(f['origins'], p['origins']):
            assert saved['query_id'] == original['query_id'] and saved['origin_index'] == original['origin_index']
            if f['baseline'] or m['status'] != 'active':
                assert saved['probabilities'] is None and saved['selected_side'] == f['native_side']
            else:
                prob = saved['probabilities']; vote = probability_choice(f['native_side'], prob['native_probabilities'], prob['reverse_probabilities'])
                assert prob == vote and saved['selected_side'] == vote['selected_side'] and saved['fallback'] is None
            votes.append(copy.deepcopy(saved))
        sides = {v['selected_side'] for v in votes}; agreement = len(sides) == 1
        selected = next(iter(sides)) if agreement else f['native_side']
        if f['baseline']:
            selected, fallback = f['native_side'], 'protected_baseline'
        elif m['status'] != 'active':
            fallback = m['status']
        elif not agreement:
            fallback = 'origin_direction_conflict'
        else:
            fallback = None
        flip = selected != f['native_side']
        fallback_kind = ('baseline' if f['baseline'] else 'seed' if m['status'] == 'warmup8' else
            'insufficient_training' if m['status'] in ('insufficient_complete32', 'missing_three_classes') else
            'single_tech' if m['status'] == 'fewer_than_two_technical_families' else
            'origin_conflict' if not agreement else 'none')
        model_applied = not f['baseline'] and m['status'] == 'active' and agreement
        rows.append({'id': f['id'], 'session': f['session'], 'native_side': f['native_side'], 'selected_side': selected,
            'baseline': f['baseline'], 'flip': flip, 'action': 'flip' if flip else 'keep', 'reason': fallback or '過去場モデルの全origin方向一致',
            'fallback': fallback, 'model_status': m['status'], 'model_ref': copy.deepcopy(m['model_ref']),
            'model_applied': model_applied, 'fallback_kind': fallback_kind,
            'all_origins_agree': agreement, 'origin_query_ids': [v['query_id'] for v in votes],
            'origin_count': len(votes), 'origins': votes})
    assert len(rows) == 752 and all(not r['flip'] for r in rows if r['baseline'])
    return {'success': True, 'trial': 143, 'sessions': cohort['sessions'], 'rows': rows, 'entry_origins': cohort['entry_origins'],
        'counts': dict(Counter(r['action'] for r in rows)), 'reasons': dict(Counter(r['reason'] for r in rows)),
        'fallback_counts': dict(Counter(r['fallback'] or 'model_applied' for r in rows)), 'join_proof': cohort['join_proof'],
        'all_752_kept': True, 'protected_81_kept': True, 'all_73_sessions': True, 'learned': True,
        'label_scope': 'F0後に過去場H60完了ラベルを使用。現場/未来ラベルはtrain/scoreへ渡さない'}


def stream(record: dict, policy: str, axis: str, choices: dict) -> dict:
    """
    機能: 固定方向票に従い保存実正逆streamを選ぶ。
    引数: record(dict)、policy/axis(str)、choices(dict)。返り値: dict。
    """
    assert policy in ('T0', 'P0', 'C0') and axis in ('BBO', 'Last') and record['model'] == ('C0' if policy == 'C0' else 'P0')
    native = record['case']['original_side']; side = choices[record['case']['id']]['selected_side'] if policy == 'T0' else native
    return record['case'][('chart_' if axis == 'Last' else '')+('original' if side == native else 'reverse')]
