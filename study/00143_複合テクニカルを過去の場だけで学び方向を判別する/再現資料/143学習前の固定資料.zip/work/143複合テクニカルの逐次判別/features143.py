"""143の74当時特徴・方向鏡像・技法系統。ラベルやファイルは読まない。"""
import copy
import math

BASE = ('gap_to_side', 'gap_atr_to_side', 'ema8_delta_to_side', 'ema8_delta_atr_to_side',
        'ema21_delta_to_side', 'ema21_delta_atr_to_side', 'di_difference_to_side', 'adx', 'adx_delta',
        'rsi_center_to_side', 'rsi_delta_to_side', 'hist_to_side', 'hist_atr_to_side',
        'hist_delta_to_side', 'hist_delta_atr_to_side', 'price_ema8_atr_to_side', 'price_ema21_atr_to_side',
        'atr', 'tr_atr_ratio', 'atr_tr_ratio', 'tr_previous_atr_ratio')
EXTRA = ('m5_range', 'm5_body_to_side', 'm5_body_ratio_to_side', 'm5_forward_wick_ratio',
         'm5_opposite_wick_ratio', 'm5_close_position_to_side', 'rvol5', 'bb15_sigma',
         'bb15_position_sigma_to_side', 'bb15_percent_to_side', 'bb15_width_atr_ratio')
NAMES = tuple(sorted([f'm{m}_{name}' for m in (5, 15, 30) for name in BASE]+list(EXTRA)))
assert len(NAMES) == len(set(NAMES)) == 74


def number(item: dict) -> float | None:
    """
    機能: 未知nullと有限の既知数値を区別する。
    引数: item(dict)。返り値: float又はNone。
    """
    assert type(item['known']) is bool
    if not item['known']:
        assert item['value'] is None
        return None
    value = item['value']
    assert type(value) in (int, float) and math.isfinite(value)
    return value


def validate(values: dict) -> None:
    """
    機能: 指定74列だけがあり無限値がないことを検査する。
    引数: values(dict)。返り値: None。
    """
    assert set(values) == set(NAMES)
    for item in values.values():
        number(item)


def mirror(values: dict) -> dict:
    """
    機能: 同じ物理市場の反対側へ74特徴を変換する。
    引数: values(dict)はknown/value付き74列。返り値: dictは独立copy。
    """
    validate(values)
    out = copy.deepcopy(values)
    for key in NAMES:
        value = number(values[key])
        if value is None:
            continue
        if key in ('bb15_percent_to_side', 'm5_close_position_to_side'):
            out[key]['value'] = 1-value
        elif key.endswith('_to_side'):
            out[key]['value'] = -value
    out['m5_forward_wick_ratio'] = copy.deepcopy(values['m5_opposite_wick_ratio'])
    out['m5_opposite_wick_ratio'] = copy.deepcopy(values['m5_forward_wick_ratio'])
    return out


def vector(values: dict) -> list:
    """
    機能: 固定順の数値配列へ未知をNaNとして射影する。
    引数: values(dict)。返り値: list[float]。0補完しない。
    """
    validate(values)
    return [math.nan if number(values[n]) is None else number(values[n]) for n in NAMES]


def family(name: str) -> str:
    """
    機能: 正規化のATRを二重票にしない優先順で技法を1系統へ分類する。
    引数: name(str)は固定列名。返り値: strは8系統の一つ。
    """
    assert name in NAMES
    if 'hist' in name:
        return 'MACD'
    if 'ema' in name or 'gap' in name:
        return 'MA'
    if 'rsi' in name:
        return 'RSI'
    if 'di_difference' in name or 'adx' in name:
        return 'DMI/ADX'
    if name.startswith('bb15_'):
        return 'BB'
    if '_atr' in name or '_tr_' in name:
        return 'ATR/TR'
    if any(word in name for word in ('body', 'position', 'wick', 'range')):
        return '足形'
    if name == 'rvol5':
        return 'RVOL'
    raise AssertionError(name)


def families() -> dict:
    """
    機能: F0前に固定する74列→1系統表を返す。
    引数: なし。返り値: dict[str,str]。
    """
    out = {n: family(n) for n in NAMES}
    assert len(set(out.values())) == 8
    return out
