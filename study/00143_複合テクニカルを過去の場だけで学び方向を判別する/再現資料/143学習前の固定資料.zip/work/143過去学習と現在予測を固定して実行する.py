"""143の教師射影・過去場学習・現在予測・金融再集計を分離するRoot運転部。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
OWN = ROOT / 'work/143逐次判別の評価'
LOGIC = ROOT / 'work/143複合テクニカルの逐次判別'
FORMAL = ROOT / 'study/00143_複合テクニカルを過去の場だけで学び方向を判別する'
PYTHON = ROOT / 'work/複合テクニカル学習環境/Scripts/python.exe'
MODEL = LOGIC / '固定条件.json'
LABELS = OWN / '教師/ラベル参照.json'
PREDICTION_DIR = OWN / '学習予測'
CHOICES = PREDICTION_DIR / '全752の方向.json'


def sha(path: Path) -> str:
    """
    機能: 保存bytesの指紋を求める。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def module(path: Path, name: str) -> object:
    """
    機能: 主処理を呼ばず私有モジュールを読む。
    引数: path(Path)、name(str)はコードと内部名。
    返り値: objectはモジュール。
    """
    previous = list(sys.path)
    try:
        sys.path.insert(0, str(path.parent))
        spec = importlib.util.spec_from_file_location(name, path)
        value = importlib.util.module_from_spec(spec);spec.loader.exec_module(value)
        return value
    finally:
        sys.path[:] = previous


# ----------------------------------------
def main() -> None:
    """
    機能: 教師の全期間投影と、各学習器への過去prefix限定を区別して順に実行する。
    引数: CLI --mode(str)は固定/射影/学習予測/金融前/集計。
    返り値: None。自然モデルを金融結果から交換しない。
    """
    parser = argparse.ArgumentParser(description='143の過去学習と現在予測を固定する')
    parser.add_argument('--mode', required=True, choices=('固定','射影','学習予測','金融前','集計'))
    args = parser.parse_args()
    helper = module(ROOT / 'work/133金融前を固定して実行する.py', '143の固定補助')
    io = module(LOGIC / 'io143.py', '143の入力宣言')
    f0, f1 = OWN / 'F0学習前.json', OWN / 'F1予測固定後.json'
    OWN.mkdir(parents=True, exist_ok=True)
    if args.mode == '固定':
        assert PYTHON.is_file()
        assert json.loads((LOGIC / '準備の確認.json').read_bytes())['成功']
        declared = {**io.NONFINANCIAL, **io.LABEL_SOURCES}
        files = set(declared) | set(io.local_sources()) | {Path(__file__).resolve(),
            ROOT / 'work/143_複合テクニカル逐次判別の採用仕様.md',
            ROOT / 'work/133金融前を固定して実行する.py',
            LOGIC / '準備の確認.json',
            ROOT / 'work/複合テクニカルの逐次学習案/導入版.txt',
            ROOT / 'work/複合テクニカルの逐次学習案/計算環境の確認.json'}
        for path, expected in declared.items(): assert sha(path) == expected, path
        for name in ('README.md','条件.md','設定と結果.md'):
            path = FORMAL / name;assert path.is_file();files.add(path)
        helper.save(f0, {'成功': True,'試行':143,'段階':'教師射影と逐次学習前F0',
            'UTC':datetime.now(timezone.utc).isoformat(),
            '主':'T0・過去場だけの74特徴3分類・全752/保護81/物理正逆・全origin合意',
            '教師ファイル': '既使用138の保存正逆を73場へ射影。各trainへは前場までのlabel pathsだけを渡す',
            '再調整':'深さ/seed/閾値/主政策を新成績で変更しない',
            '追加2場未読':True,'全期間既使用':True,'python':str(PYTHON),
            'ファイル':{str(p):sha(p) for p in sorted(files)}})
        print(json.dumps({'F0_SHA256':sha(f0),'固定源数':len(files)},ensure_ascii=False));return
    frozen = json.loads(f0.read_bytes());helper.verify(frozen)
    if args.mode == '射影':
        command = [str(PYTHON),'-X','utf8',str(LOGIC/'射影する.py'),'--f0',str(f0),'--f0-sha256',sha(f0),
            '--output-dir',str(LABELS.parent),'--execute-after-f0']
    elif args.mode == '学習予測':
        command = [str(PYTHON),'-X','utf8',str(LOGIC/'学習予測する.py'),'--f0',str(f0),'--f0-sha256',sha(f0),
            '--labels-manifest',str(LABELS),'--labels-manifest-sha256',sha(LABELS),
            '--output-dir',str(PREDICTION_DIR),'--execute-after-f0']
    elif args.mode == '金融前':
        choices = json.loads(CHOICES.read_bytes())
        assert choices['success'] and choices['trial'] == 143 and len(choices['rows']) == 752
        assert choices['model_sha256'] == sha(MODEL)
        declared = module(LOGIC/'集計する.py','143の金融依存宣言')
        files = {Path(p) for p in frozen['ファイル']} | {f0,CHOICES,
            ROOT/'work/141金融集計を独立に確認する.py',ROOT/'work/143金融集計を独立に確認する.py'}
        for folder in (LABELS.parent,PREDICTION_DIR):
            files.update(p for p in folder.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
        for path,expected in declared.SOURCES.items(): assert sha(path) == expected, path;files.add(path)
        inherited = module(declared.BASE,'143の共通算術依存')
        for path,expected in inherited.SOURCES.items(): assert sha(path) == expected, path;files.add(path)
        helper.save(f1, {'成功':True,'試行':143,'段階':'全場モデルと予測の固定後F1',
            'UTC':datetime.now(timezone.utc).isoformat(),'F0_SHA256':sha(f0),'方向SHA256':sha(CHOICES),
            '主':'全752/T0/実BBO/H60±125pt','金融後のモデル交換':False,
            'ファイル':{str(p):sha(p) for p in sorted(files)}})
        print(json.dumps({'F1_SHA256':sha(f1),'固定源数':len(files)},ensure_ascii=False));return
    else:
        finance = json.loads(f1.read_bytes());helper.verify(finance)
        command = [str(PYTHON),'-X','utf8',str(LOGIC/'集計する.py'),'--f1',str(f1),'--f1-sha256',sha(f1),
            '--model',str(MODEL),'--model-sha256',sha(MODEL),'--choices',str(CHOICES),'--choices-sha256',sha(CHOICES),
            '--output-dir',str(OWN/'金融評価')]
    subprocess.run(command,cwd=ROOT,check=True)
    helper.verify(frozen)
    if args.mode == '集計': helper.verify(finance)
    helper.save(OWN/(args.mode+'の完了.json'), {'成功':True,'試行':143,'段階':args.mode,
        'F0_SHA256':sha(f0),'全固定源前後同体':True,'実行列':command})


if __name__ == '__main__':
    main()
