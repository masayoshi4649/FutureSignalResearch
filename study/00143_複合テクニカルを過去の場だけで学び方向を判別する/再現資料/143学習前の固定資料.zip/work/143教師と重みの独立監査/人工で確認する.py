"""143の教師・時刻・重み・74列を人工だけで独立確認する。自然入力は開かない。"""
from pathlib import Path
from collections import Counter, defaultdict
import copy
import hashlib
import importlib.util
import json
import math
import sys
import tempfile

ROOT=Path(__file__).resolve().parents[2]
SOURCE=ROOT/'work/143複合テクニカルの逐次判別'
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(SOURCE))
import features143 as features
import data143 as data
import model143 as model
import io143 as io


def digest(raw: bytes) -> str:
    """
    機能: 明示した原文の指紋を求める。
    引数: raw(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(raw).hexdigest()


# ----------------------------------------
def rejects(call: object) -> bool:
    """
    機能: 人工の不正条件が拒否されるかを確認する。
    引数: call(引数なしcallable)。
    返り値: bool。AssertionErrorだけを期待拒否とする。
    """
    try:call()
    except AssertionError:return True
    return False


# ----------------------------------------
def quote(at: float, index: int=10) -> dict:
    """
    機能: 人工の有限時計と正常BBOを作る。
    引数: at(float)、index(int)。
    返り値: dictは架空Quote。
    """
    return {'time':at,'index':index,'source_line':index+1,'last':100,'bid':95,'ask':105,'quote_ok':True}


# ----------------------------------------
def stream(start: float, direction: int, complete: bool=True, offset: int=0) -> dict:
    """
    機能: 架空のH60観測を作る。価格の成績を読み込まない。
    引数: start(float)、direction(int)、complete(bool)、offset(int)。
    返り値: dictは人工stream。
    """
    entry=quote(start,10);deadline=start+3600
    return {'entry':entry,'outcomes':[{'seconds':3600,'deadline':deadline,'status':'complete' if complete else 'censored',
        'endpoint':quote(deadline+offset,20) if complete else None,
        'touches':[{'width':125,'direction':direction,'quote':quote(start+1,11) if direction else None}]}]}


# ----------------------------------------
def fixture() -> tuple:
    """
    機能: 752canonical/81重複対照/769出生/850関係だけの人工結合を作る。
    引数: なし。
    返り値: tupleはmanifest/queries/features。自然ファイルを使わない。
    """
    scenes=[f'人工場{i:02d}' for i in range(73)];p0=[];queries=[];frows=[];relations=[]
    for i in range(752):
        session=scenes[i%73];start=(i%73)*10000;entry=quote(start+101,100+i*3)
        side=1 if i%2==0 else -1;origins=[]
        for oi in range(2 if 81<=i<98 else 1):
            birth=quote(start+100,90+i*3+oi)
            origin={'source_file_sha':digest(f'人工源{i}:{oi}'.encode()),'source_locator':f'人工位置{i}:{oi}',
                'side':side,'family':'人工family','birthQuote':birth,'entryQuote':copy.deepcopy(entry)}
            origins.append(origin)
        candidate={'id':f'人工入口{i:03d}','session':session,'contract':'人工限月','side':side,'entryQuote':entry,
                   'baseline':i<81,'origins':origins}
        p0.append(candidate)
    manifest={'success':True,'financial_labels_used':False,'C0':copy.deepcopy(p0[:81]),'P0':p0,
              'frequency':{'P0':{'scenes':[{'session':s} for s in scenes]}}}
    seen=set()
    for family in ('C0','P0'):
        for index,c in enumerate(manifest[family]):
            for oi,origin in enumerate(c['origins']):
                q=data.origin_query(origin,c)
                relations.append({'entry_id':family+'/'+c['id'],'query_id':q['id'],'model':family,'manifest_index':index,
                    'origin_index':oi,'family':origin['family'],'side':origin['side'],'selected_side':c['side']})
                if q['id'] not in seen:
                    seen.add(q['id']);queries.append(q)
                    values={n:{'known':True,'value':.25} for n in features.NAMES}
                    values[features.NAMES[index%74]]={'known':False,'value':None}
                    frows.append({'query':copy.deepcopy(q),'values':values,'known_mask':{n:v['known'] for n,v in values.items()},
                                  'refs':[],'feet':{'m5':None,'m15':None,'m30':None}})
    qdoc={'success':True,'trial':138,'manifest_sha256':data.MANIFEST_SHA,'queries':queries,'relations':relations}
    fdoc={'success':True,'input_sha256':data.INPUT_SHA,'queries_sha256':data.QUERY_SHA,'financial_labels_used':False,
          'entry_prices_used':False,'source_scene_count':73,'query_count':769,'catalog':list(features.NAMES),'rows':frows}
    return manifest,qdoc,fdoc


# ----------------------------------------
def observations(cohort: dict) -> tuple:
    """
    機能: 全場の教師射影用の人工833観測を作る。
    引数: cohort(dict)は人工結合結果。
    返り値: tupleはobserved/fixed。P0だけが教師となることを検査するためC0も含める。
    """
    scenes=[];fixed=[]
    for index,session in enumerate(cohort['sessions']):
        start=index*10000;end=start+10000;cases=[]
        for row in (r for r in cohort['rows'] if r['session']==session):
            n=int(row['id'].split('人工入口')[1]);a=stream(start+101,(-1,0,1)[n%3]);b=stream(start+101,(1,-1,0)[n%3],offset=7)
            a.update({'status':'filled','axis':'BBO','birth':{'side':row['native_side']}})
            b.update({'status':'filled','axis':'BBO','birth':{'side':-row['native_side']}})
            cases.append({'id':row['id'],'original_side':row['native_side'],'original':a,'reverse':b})
            if row['baseline']:
                control=copy.deepcopy(cases[-1]);control['id']=control['id'].replace('P0/','C0/',1);cases.append(control)
        scenes.append({'session':session,'success':True,'execution_end':end-300,'cases':cases})
        fixed.append({'session':session,'start':start,'end':end})
    return {'success':True,'trial':133,'source_entry_count':833,'scenes':scenes},{'expected_entry_count':833,'scenes':fixed}


# ----------------------------------------
def main() -> None:
    """
    機能: 作者関数へ人工だけを渡し、独立の期待算術で教師/重み/入力境界を照合する。
    引数: なし。
    返り値: None。Source/学習の自然実行や自然価格/教師ファイルの読取はしない。
    """
    tracked={p:p.read_bytes() for p in SOURCE.glob('*.py')}
    tracked[ROOT/'work/143_複合テクニカル逐次判別の採用仕様.md']=(ROOT/'work/143_複合テクニカル逐次判別の採用仕様.md').read_bytes()
    tests={}
    expected={-1:0,0:1,1:2}
    for direction,target in expected.items():
        s=stream(100,direction);r=data.label(s,10000);assert r=={'complete':True,'class':target,'known_at':3700}
    partial=stream(100,1,False);assert data.label(partial,10000)=={'complete':False,'class':None,'known_at':None}
    assert data.label(stream(100,0,offset=30),10000)['known_at']==3730
    assert rejects(lambda:data.label(stream(100,0,offset=31),10000))
    assert rejects(lambda:data.label(stream(100,0),3700))
    tests['教師0逆1未2順/早着でもH不足除外/endpoint30秒含む/ザラバ終端strict']=True
    # ----------------------------------------
    manifest,queries,fdoc=fixture();cohort=data.join(manifest,queries,fdoc)
    assert len(cohort['rows'])==752 and sum(r['baseline'] for r in cohort['rows'])==81
    assert not any(r['id'].startswith('C0/') for r in cohort['rows'])
    assert len(cohort['entry_origins'])==833 and sum(len(r['origins']) for r in cohort['rows'])==769
    bad=copy.deepcopy(manifest);bad['P0'][100]['side']*=-1
    assert rejects(lambda:data.join(bad,queries,fdoc))
    tests['人工752/81/769/850結合とC0別標本排除/全origin方向一致必須']=True
    observed,fixed=observations(cohort);docs=data.project_labels(observed,fixed,cohort)
    assert len(docs)==73 and sum(len(d['rows']) for d in docs)==752
    assert all(r['label_known_at']==max(r['original']['known_at'],r['reverse']['known_at']) for d in docs for r in d['rows'])
    altered=copy.deepcopy(observed);case=next(c for c in altered['scenes'][0]['cases'] if c['id'].startswith('P0/'))
    case['reverse']|=stream(101,-1,False)
    partialdocs=data.project_labels(altered,fixed,cohort)
    assert sum(r['eligible_pair'] for d in partialdocs for r in d['rows'])==751
    assert next(r for r in partialdocs[0]['rows'] if r['id']==case['id'])['one_side_only_complete']
    tests['両Hcomplete必須/既知は両endpoint最大/片側不足は教師不適格']=True
    # ----------------------------------------
    prefix_count=16;start=prefix_count*10000;prior=docs[:prefix_count];ids={r['id'] for d in prior for r in d['rows']};fs=[r for r in cohort['rows'] if r['id'] in ids]
    result=model.training_rows(fs,prior,start);x,y,w,a=result['X'],result['y'],result['weights'],result['audit']
    assert len(x)==len(y)==len(w) and len(x)>2*len(ids) and all(len(v)==74 for v in x)
    assert a['training_canonical_complete_pairs']==len(ids) and a['classes']==[0,1,2]
    totals=defaultdict(float);canonical=defaultdict(float);origin=defaultdict(float)
    fby={f['id']:f for f in fs};ordered=[fby[r['id']] for d in prior for r in d['rows']]
    for weight,key in zip(w,[{'id':f['id'],'session':f['session'],'origin_index':o['origin_index']}
        for f in ordered for o in sorted(f['origins'],key=lambda z:z['origin_index']) for _ in (False,True)]):
        totals[key['session']]+=weight;canonical[key['id']]+=weight;origin[(key['id'],key['origin_index'])]+=weight
    assert all(math.isclose(v,len(w)/prefix_count,rel_tol=1e-12) for v in totals.values()) and math.isclose(sum(w)/len(w),1)
    nscene=Counter(f['session'] for f in fs)
    for f in fs:
        expected_weight=len(w)/prefix_count/nscene[f['session']]
        assert math.isclose(canonical[f['id']],expected_weight,rel_tol=1e-12)
        assert all(math.isclose(origin[(f['id'],o['origin_index'])],expected_weight/len(f['origins']),rel_tol=1e-12) for o in f['origins'])
    assert a['protected_baseline_canonical_included_once']==sum(f['baseline'] for f in fs)
    bad=copy.deepcopy(prior);r=next(r for d in bad for r in d['rows']);r['reverse']['known_at']=start;r['label_known_at']=start
    assert rejects(lambda:model.training_rows(fs,bad,start))
    bad=copy.deepcopy(prior);bad.append(copy.deepcopy(bad[0]));assert rejects(lambda:model.training_rows(fs,bad,start))
    tests['場等重み/canonical等配分/origin2側配分/平均1/同場重複とknown等号拒否']=True
    # ----------------------------------------
    with tempfile.TemporaryDirectory(prefix='143教師人工_') as temp:
        temp=Path(temp)
        mini=copy.deepcopy(docs[:1]);mini[0]['rows']=[copy.deepcopy(docs[0]['rows'][0]) for _ in range(31)]
        minifs=[]
        for i,r in enumerate(mini[0]['rows']):
            r['id']=f'人工gate{i}';f=copy.deepcopy(fs[0]);f['id']=r['id'];f['session']=r['session'];f['native_side']=r['native_side'];minifs.append(f)
        _,audit=model.fit(minifs,mini,10000,temp/'未生成31.json');assert audit['status']=='insufficient_complete32' and not (temp/'未生成31.json').exists()
        r=copy.deepcopy(mini[0]['rows'][0]);r['id']='人工gate31';mini[0]['rows'].append(r);f=copy.deepcopy(minifs[0]);f['id']=r['id'];minifs.append(f)
        _,audit=model.fit(minifs,mini,10000,temp/'未生成32.json');assert audit['status']=='missing_three_classes'
        assert audit['training']['training_canonical_complete_pairs']==32 and not (temp/'未生成32.json').exists()
        records=[]
        for d in docs:
            p=temp/f'場{d["session_index"]:02d}.json';raw=json.dumps(d,ensure_ascii=False).encode();p.write_bytes(raw)
            records.append({k:d[k] for k in ('session_index','session','start','end')}|{'path':str(p),'sha256':digest(raw)})
        opened=[];original_load=io.load
        def spy_load(path: Path, expected: str) -> dict:
            """
            機能: 自作人工ファイルの読取先だけを記録する。
            引数: path(Path)、expected(str)。
            返り値: dictは人工教師文書。
            """
            opened.append(Path(path));assert Path(path).is_relative_to(temp)
            return original_load(path,expected)
        io.load=spy_load
        try:
            loaded=io.load_prefix(records[:prefix_count],prefix_count,records[prefix_count]['session'],records[prefix_count]['start'])
            assert opened==[Path(r['path']) for r in records[:prefix_count]]
            before=model.training_rows(fs,loaded,start)
            future=Path(records[prefix_count]['path']);future.write_text('現場ラベルを破損しても過去prefixだけを読む',encoding='utf-8')
            opened.clear();after=model.training_rows(fs,io.load_prefix(records[:prefix_count],prefix_count,records[prefix_count]['session'],records[prefix_count]['start']),start)
            assert before['y']==after['y'] and before['weights']==after['weights'] and before['audit']==after['audit']
            assert all((a==b) or (math.isnan(a) and math.isnan(b)) for va,vb in zip(before['X'],after['X']) for a,b in zip(va,vb))
            assert Path(records[prefix_count]['path']) not in opened
            assert rejects(lambda:io.load_prefix(records[:prefix_count+1],prefix_count,records[prefix_count]['session'],records[prefix_count]['start']))
        finally:io.load=original_load
    tests['32はcanonical数/31fallback/32でも3class不足fallback/現場path非読取']=True
    # ----------------------------------------
    assert len(features.NAMES)==74 and len(set(features.families().values()))==8
    allowed=('m5_','m15_','m30_','rvol5','bb15_')
    assert all(n.startswith(allowed) for n in features.NAMES)
    forbidden={'session','date','method','family','quantity','id','entry','exit','outcome','profit','baseline'}
    assert not any(set(n.split('_'))&forbidden for n in features.NAMES)
    v=copy.deepcopy(fdoc['rows'][0]['values']);unknown=next(n for n in features.NAMES if not v[n]['known'])
    assert math.isnan(features.vector(v)[features.NAMES.index(unknown)])
    bad=copy.deepcopy(v);bad['future_label']={'known':True,'value':2};assert rejects(lambda:features.vector(bad))
    bad=copy.deepcopy(v);bad[features.NAMES[0]]={'known':True,'value':math.inf};assert rejects(lambda:features.vector(bad))
    bad=copy.deepcopy(v);bad[features.NAMES[0]]={'known':False,'value':0};assert rejects(lambda:features.vector(bad))
    tests['モデル入力74固定/禁則metadataなし/未知NaN/余分列と無限と未知0補完拒否']=True
    after={p:p.read_bytes() for p in tracked};assert after==tracked
    proof={'成功':True,'試行':143,'段階':'F0前の独立コードレビューと人工のみ','自然価格/教師/成績ファイル読取':False,
        '自然学習/新方向/金融/追加2場読取':False,'CatBoost学習実行':False,'作者源変更':False,
        '検査':tests,'人工期待':'教師算術・場重み配分・74列を独立に算出。作者公開純関数へ人工だけ入力',
        '特徴数':74,'系統別列数':dict(Counter(features.families().values())),
        '教師時刻':'両H60complete、両endpoint.time最大がcurrentStart未満。早いtouchだけでは学習しない',
        'モデルへのファイル分離':'学習CLIはlabel参照全73のmetadataを持つが、load_prefixへfiles[:index]だけ、fitへその過去docと過去特徴だけ。scoreは現在特徴だけ',
        '分離の限界':'OS権限による隔離ではない。CLIはF0指紋検査で保存観測の全bytesをhashするが、教師値をfit/scoreへ渡す経路とは別',
        '重大差':[],'前後源不変':True,'源SHA256':{p.relative_to(ROOT).as_posix():digest(raw) for p,raw in tracked.items()},
        '監査コードSHA256':digest(Path(__file__).read_bytes())}
    p=HERE/'独立人工の確認.json';p.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'人工群数':len(tests),'確認SHA256':digest(p.read_bytes()),'重大差':[]},ensure_ascii=False))


if __name__=='__main__':main()
