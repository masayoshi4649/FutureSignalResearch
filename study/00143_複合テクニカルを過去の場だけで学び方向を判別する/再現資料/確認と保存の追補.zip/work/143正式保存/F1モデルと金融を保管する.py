"""143の固定済み全モデル・予測・方向と金融正本を一度保存する。"""
from pathlib import Path
import gzip
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[2]
FORMAL=next((ROOT/'study').glob('00143_*'))
OWN=ROOT/'work/143逐次判別の評価'


def sha(raw: bytes) -> str:
    """
    機能: 原文の指紋を求める。
    引数: raw(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(raw).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: F1の178源を既存共有と新規68モデル関連/1コードへ分けて保存する。
    引数: なし。
    返り値: None。学習・予測・金融を再実行せず正式3MDも編集しない。
    """
    mpath=FORMAL/'保管索引.json';m=json.loads(mpath.read_bytes())
    raw=(OWN/'F1予測固定後.json').read_bytes();h=sha(raw);assert h=='c0a2d1e8032cbb06bcdef11f3c707a2998225f44c416fe7b0a683ebc2312545c'
    f1=json.loads(raw);assert len(f1['ファイル'])==178
    for name,expected in f1['ファイル'].items():assert sha(Path(name).read_bytes())==expected
    (FORMAL/'検査/F1予測固定後.json').write_bytes(raw)
    snapshot=json.loads(gzip.decompress((FORMAL/'検査/F0実行前文書.json.gz').read_bytes()))
    assert all(f1['ファイル'][str(ROOT/d['path'])]==d['sha256'] for d in snapshot['文書'])
    m['F1_SHA256']=h;m['F1直接源']=178
    m['F1文書原文']={'方式':'F0原文5MDと全bytes同体なので再複写せず共有','保存元':m['F0文書原文']['保存元'],'保存SHA256':m['F0文書原文']['保存SHA256'],'原文照合数':5}
    prior=next((ROOT/'study').glob('00142_*'));pm=json.loads((prior/'保管索引.json').read_bytes())
    m['共有入力']=[d for d in pm['共有入力'] if str(ROOT/d['復元先']) in f1['ファイル']]
    assert len(m['共有入力'])==9
    m['共有固定コード群']=[]
    for group in pm['共有固定コード群']:
        entries=[e for e in group['格納源'] if str(ROOT/e['復元先']) in f1['ファイル']]
        if entries:m['共有固定コード群'].append({**group,'格納源':entries,'格納源数':len(entries)})
    assert sum(len(g['格納源']) for g in m['共有固定コード群'])==4
    modelpaths=[Path(p) for p in f1['ファイル'] if Path(p).is_relative_to(OWN/'学習予測')]
    assert len(modelpaths)==68 and sum(p.parent.name=='models' for p in modelpaths)==64
    target=ROOT/'inputs/00143_逐次学習の教師/モデルと予測.zip';members=[]
    with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(modelpaths):
            raw=p.read_bytes();rel=p.relative_to(ROOT).as_posix();z.writestr(rel,raw)
            members.append({'path':rel,'sha256':sha(raw),'bytes':len(raw),'区分':'保存モデル再推論の正本。再学習SHA同体は保証しない'})
    m['学習済み入力']={'保存元ZIP':target.relative_to(ROOT).as_posix(),'ZIP_SHA256':sha(target.read_bytes()),'ZIP_bytes':target.stat().st_size,'格納源数':68,'モデル数':64,'格納源':members}
    p=ROOT/'work/143金融集計を独立に確認する.py';raw=p.read_bytes();assert sha(raw)==f1['ファイル'][str(p)]
    archive=FORMAL/'再現資料/143金融前の追加固定資料.zip'
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:z.writestr(p.relative_to(ROOT).as_posix(),raw)
    m['F1追加固定資料']={'ZIP':archive.name,'ZIP_SHA256':sha(archive.read_bytes()),'ZIP_bytes':archive.stat().st_size,'格納源数':1,
        '格納源':[{'path':p.relative_to(ROOT).as_posix(),'sha256':sha(raw),'bytes':len(raw)}]}
    (FORMAL/'成果物').mkdir(exist_ok=True)
    p=OWN/'金融評価/集計.json';raw=p.read_bytes();assert sha(raw)=='c6b038d790b45fdf387a65ba275f5e132528ac9e24534bf92d663c6c2586a8d0'
    (FORMAL/'成果物/集計.json').write_bytes(raw)
    m['集計正本']={'保存元':(FORMAL/'成果物/集計.json').relative_to(ROOT).as_posix(),'復元先':p.relative_to(ROOT).as_posix(),'形式':'同体','保存bytes':len(raw),
        '保存SHA256':sha(raw),'解凍bytes':len(raw),'解凍SHA256':sha(raw)}
    for source,name in [(OWN/'学習予測の完了.json','学習予測の完了.json'),(OWN/'集計の完了.json','集計の完了.json'),
        (OWN/'金融評価/集計完了.json','集計器の完了.json'),(OWN/'金融集計の独立確認.json','金融集計の独立確認.json')]:
        (FORMAL/'検査'/name).write_bytes(source.read_bytes())
    m['表JSON再現期待SHA256']='dcbdee058937d729f0acc2b97a261512e5d70391155b3208ed9e45a7dbf55b4f'
    m['方向SHA256']='b3bb4faffd6622d15a6eb3f48156a7c8082ee11c32aec1863ec167f36aedc107'
    m['段階']='F0/F1原文178源・モデル64・予測・方向・教師・金融正本を保存。結果本文/独立/CSVは後続'
    mpath.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    for name,expected in f1['ファイル'].items():assert sha(Path(name).read_bytes())==expected
    proof={'成功':True,'試行':143,'F1全178源前後同体':True,'F1全5MD原文はF0と同体で共有':True,'64モデルと予測方向68源を一度ZIP':True,
        '教師74源は既存1ZIP共有':True,'旧大観測/features/177MB/venv/DLL/wheel新複写':False,'自然学習/予測/金融再実行':False,
        '正式3MD変更':False,'保存モデルの再推論と再学習SHA同体を区別':True,'不足':[],
        'F1_SHA256':h,'モデルZIP_SHA256':m['学習済み入力']['ZIP_SHA256'],'保管索引SHA256':sha(mpath.read_bytes())}
    p=FORMAL/'検査/F1保存の確認.json';p.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'F1保存SHA256':sha(p.read_bytes()),'モデルZIP_SHA256':m['学習済み入力']['ZIP_SHA256'],'モデルZIP_bytes':m['学習済み入力']['ZIP_bytes'],'不足':[]},ensure_ascii=False))


if __name__=='__main__':main()
