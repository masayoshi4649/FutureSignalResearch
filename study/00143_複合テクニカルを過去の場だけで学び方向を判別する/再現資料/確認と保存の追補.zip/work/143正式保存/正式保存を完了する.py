"""143の停止済み小資料と共有参照を閉じ、原文と正本の限定検査で停止する。"""
from pathlib import Path
import gzip
import hashlib
import json
import re
import zipfile

ROOT=Path(__file__).resolve().parents[2]
FORMAL=next((ROOT/'study').glob('00143_*'))


def sha(raw: bytes) -> str:
    """
    機能: 保存原文の指紋を求める。
    引数: raw(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(raw).hexdigest()


# ----------------------------------------
def cells(body: str) -> list:
    """
    機能: 固定した57手法9尺度の設定を抽出する。
    引数: body(str)。
    返り値: listはIDと513セル。
    """
    rows=[]
    for line in body.splitlines():
        if re.match(r'^\| [A-Z]+\d{2} \|',line):
            row=[v.strip() for v in line.strip('|').split('|')]
            if len(row)==11:rows.append([row[0],row[2:]])
    assert len(rows)==57 and sum(len(row[1]) for row in rows)==513
    return rows


# ----------------------------------------
def main() -> None:
    """
    機能: 保存済み証拠の範囲で143正式を完了し編集停止する。
    引数: なし。
    返り値: None。新学習/自然推論/観測/CSV/旧試行変更を行わない。
    """
    mpath=FORMAL/'保管索引.json';m=json.loads(mpath.read_bytes())
    p=FORMAL/'README.md';body=p.read_text('utf-8')
    body=body.replace('自然独立照合・CSV・再現を確認済み、正式保存を最終確認中。','自然独立照合・CSV・再現・正式保存を完了し、未達として固定・編集停止。')
    p.write_text(body,encoding='utf-8')
    indices=[ROOT/n for n in ('README.md','study/README.md','docs/README.md','docs/議論/README.md')]
    for p in indices:
        body=p.read_text('utf-8');paragraph=next(x for x in body.split('\n\n') if '[143：' in x)
        updated=paragraph.replace('は学習/予測/金融を実行済み、自然独立照合/CSV/正式保存を確定中。','は学習/予測/金融/自然独立/CSV/再現・正式保存を完了。')
        updated += ' 保存64モデルの3,876確率セル再推論、教師/過去prefix/重み/全方向と金融180/適用群192・CSV39,685セルを照合済み。'
        p.write_text(body.replace(paragraph,updated,1),encoding='utf-8')
    # ----------------------------------------
    files=list((ROOT/'work/143正式保存').glob('*.py'))+list((FORMAL/'再現資料').glob('*.py'))
    independent=ROOT/'work/143過去学習と全方向の独立検算'
    stop=json.loads((independent/'停止の確認.json').read_bytes());assert stop['成功'] and stop['編集停止'] and not stop['重大未解決']
    for name,h in stop['停止ファイル'].items():assert sha(Path(name).read_bytes())==h
    files += [independent/n for n in ('検算する.py','README.md')]
    prep=ROOT/'work/143過去prefixと物理反対の独立準備レビュー'
    assert sha((prep/'準備の確認.json').read_bytes())==stop['準備レビュー']['sha256']
    files += [prep/n for n in ('人工検査.py','人工CPU再推論.json','停止を確認する.py','準備の確認.json','README.md')]
    files.append(ROOT/'work/143モデル確率の診断.py')
    bodies={};members=[]
    for p in sorted(set(files)):
        raw=p.read_bytes();assert len(raw)<1000000;rel=p.relative_to(ROOT).as_posix();bodies[rel]=raw
        members.append({'path':rel,'sha256':sha(raw),'bytes':len(raw),'区分':'F0/F1直接源外の独立/事後診断/保存と復元'})
    archive=FORMAL/'再現資料/確認と保存の追補.zip'
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for item in members:z.writestr(item['path'],bodies[item['path']])
    m['後発資料']={'ZIP':archive.name,'ZIP_SHA256':sha(archive.read_bytes()),'ZIP_bytes':archive.stat().st_size,'格納源数':len(members),'格納源':members}
    prior=next((ROOT/'study').glob('00142_*'));pm=json.loads((prior/'保管索引.json').read_bytes());m['後発共有コード']=pm['後発共有コード']
    m['段階']='過去場学習/方向/金融/保存モデル再推論独立/CSV/事後診断/保存予測再現/正式保存完了。主51.12%で不採用・編集停止'
    m['入力復元コード']['sha256']=sha((FORMAL/'再現資料/入力を復元する.py').read_bytes())
    mpath.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    # ----------------------------------------
    snap=m['F0文書原文'];packed=(ROOT/snap['保存元']).read_bytes();assert sha(packed)==snap['保存SHA256']
    snapshot=json.loads(gzip.decompress(packed));assert snapshot['正式文書数']==3 and snapshot['文書数']==5
    for item in snapshot['文書']:assert sha(item['本文'].encode())==item['sha256']
    original={Path(x['path']).name:x['本文'] for x in snapshot['文書'] if x['path'].startswith('study/')}
    assert cells(original['設定と結果.md'])==cells((FORMAL/'設定と結果.md').read_text('utf-8'))
    assert (FORMAL/'条件.md').read_bytes().startswith(original['条件.md'].encode('utf-8'))
    f0raw=(FORMAL/'検査/F0学習前.json').read_bytes();f1raw=(FORMAL/'検査/F1予測固定後.json').read_bytes()
    assert sha(f0raw)==m['F0_SHA256'] and sha(f1raw)==m['F1_SHA256']
    f0=json.loads(f0raw);f1=json.loads(f1raw);assert len(f0['ファイル'])==27 and len(f1['ファイル'])==178
    assert all(f1['ファイル'][p]==h for p,h in f0['ファイル'].items())
    for item in [m['追加固定資料'],m['F1追加固定資料'],m['後発資料'],m['教師入力'],m['学習済み入力']]+m['共有固定コード群']+m['後発共有コード']:
        zp=ROOT/item['保存元ZIP'] if '保存元ZIP' in item else FORMAL/'再現資料'/item['ZIP'];assert sha(zp.read_bytes())==item['ZIP_SHA256']
        with zipfile.ZipFile(zp) as z:
            assert z.testzip() is None
            for entry in item['格納源']:assert sha(z.read(entry.get('ZIP内path',entry.get('path'))))==entry['sha256']
    assert m['教師入力']['格納源数']==74 and m['学習済み入力']['モデル数']==64 and m['学習済み入力']['格納源数']==68
    for item in m['共有入力']+[m['集計正本'],m['Root事後診断']]:
        raw=(ROOT/item['保存元']).read_bytes();assert sha(raw)==item['保存SHA256']
        decoded=gzip.decompress(raw) if item['形式']=='gzip' else raw;assert sha(decoded)==item['解凍SHA256']
    for name,h in [('過去学習と再推論の独立検算.json',m['自然独立SHA256']),('過去学習独立の停止.json',m['自然独立停止SHA256']),
                   ('金融集計の独立確認.json',m['Root金融独立SHA256']),('保存予測からの再現確認.json',m['保存予測再現SHA256'])]:
        assert sha((FORMAL/'検査'/name).read_bytes())==h
    financial=json.loads((FORMAL/'検査/金融集計の独立確認.json').read_bytes())
    assert financial['成功'] and financial['比較数']==180 and financial['統計セル数']==4320 and financial['適用区分の統計セル数']==192
    csv=json.loads((FORMAL/'検査/CSV全セルの独立再読.json').read_bytes())
    assert csv['成功'] and csv['全データセル比較数']==39685 and csv['数値比較数']==16947
    for name,h in m['CSV_SHA256'].items():assert sha((ROOT/m['CSV正本']/name).read_bytes())==h
    creator=json.loads((FORMAL/'検査/CSV作成の確認.json').read_bytes())
    assert creator['コードSHA256']=='0994706575ed4fc634fe5d0577d48b5b79e95ff0db2330407daf02a74ca478d3' and len(creator['プレビュー'])==3
    for name in creator['プレビュー']:assert (ROOT/m['CSV正本']/name).exists()
    aggregate=json.loads((FORMAL/'成果物/集計.json').read_bytes());primary=aggregate['集計']['all']['T0']['BBO']['3600']['125']
    assert [primary[k] for k in ('entries','forward','adverse','neither','censored','ifd_known','ifd_unknown','ifd_net5_profit','ifd_net5_loss','ifd_net5_sum')]==[752,319,305,75,53,733,19,4159587,4720028,-560441]
    assert aggregate['適用区分別']['モデル適用']['T0']['entries']==631 and aggregate['方向件数']=={'keep':454,'flip':298}
    assert aggregate['学習予測の要約']['場別モデル状態']=={'warmup8':8,'insufficient_complete32':1,'active':64}
    replay=json.loads((FORMAL/'検査/保存予測からの再現確認.json').read_bytes())
    assert replay['F1全178源同bytes'] and replay['三表JSON全bytes同体'] and replay['保存予測から全180/適用群/参加頻度/旧120/phase一致']
    # ----------------------------------------
    links=0
    for p in list(FORMAL.rglob('*.md'))+[ROOT/m['CSV正本']/'README.md']+indices:
        body=p.read_text('utf-8')
        if p in indices:body=next(x for x in body.split('\n\n') if '[143：' in x);assert '確定中' not in body
        for target in re.findall(r'\]\(([^)]+)\)',body):
            if target.startswith(('http:','https:','#')):continue
            assert (p.parent/target.strip('<>').split('#',1)[0]).resolve().exists(),(p,target);links+=1
    proof={'成功':True,'試行':143,'正式保存完了':True,'編集停止':True,'重大不足':[],
        'F0全27/F1全178源/正式3MD含む5MD原文を先保存':True,'元条件本文と57x9_513セル不変':True,
        '73教師+参照74源と64モデル+予測方向68源を各一度ZIP':True,'共有大観測/features/manifest/177MB/venv/DLL/wheel新恒久複写':False,
        '自然独立64モデル3876確率セル再推論/752方向/教師と65prefix重み一致':True,'再推論最大差2.22e-16/再学習なし':True,
        'Root金融独立180条件4320セル/適用群192セル一致':True,'CSV39685セル16947数値再読/Root三画像視認通知':True,
        '恒久資料から178源同bytes/保存予測の全180/三表JSONbytes再現':True,'再現台帳は金融後で事前固定の後造りではない':True,
        '全752と適用631/保護81/fallback分離':True,'主51.12%で不採用/後調整なし':True,
        'Root事後診断の確率>=0.7群は2順5逆未0H不足1と確認':True,
        '新自然学習/モデル再推論/Raw/価格CSV/出生/金融観測/新CSV生成/142以前変更/追加2場読取':False,
        '4索引更新':True,'ローカルリンク':links,'主T0':primary,'F0_SHA256':m['F0_SHA256'],'F1_SHA256':m['F1_SHA256'],
        '自然独立SHA256':m['自然独立SHA256'],'Root金融独立SHA256':m['Root金融独立SHA256'],'保存予測再現SHA256':m['保存予測再現SHA256'],
        '保管索引SHA256':sha(mpath.read_bytes()),'追補ZIP_SHA256':m['後発資料']['ZIP_SHA256'],'コードSHA256':sha(Path(__file__).read_bytes())}
    p=FORMAL/'検査/正式保存の最終確認.json';assert not p.exists();p.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'最終確認SHA256':sha(p.read_bytes()),'保管索引SHA256':sha(mpath.read_bytes()),'追補ZIP_SHA256':m['後発資料']['ZIP_SHA256'],'重大不足':[]},ensure_ascii=False))


if __name__=='__main__':main()
