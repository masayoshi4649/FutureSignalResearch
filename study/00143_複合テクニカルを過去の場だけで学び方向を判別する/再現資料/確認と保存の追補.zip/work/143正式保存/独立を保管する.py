"""143の停止済み自然再推論と過去prefixの独立照合を保存する。"""
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
FORMAL=next((ROOT/'study').glob('00143_*'))
SOURCE=ROOT/'work/143過去学習と全方向の独立検算'


def sha(raw: bytes) -> str:
    """
    機能: 停止済み原文の指紋を求める。
    引数: raw(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(raw).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 自然再推論と金融独立の範囲を分けて恒久保存する。
    引数: なし。
    返り値: None。自然モデルを再学習/再推論せず固定源を変更しない。
    """
    stopraw=(SOURCE/'停止の確認.json').read_bytes();assert sha(stopraw)=='2254a893c5e2847e4edb59cadd3cc1cf8bbfa7f60c78b39035a0749157fac763'
    stop=json.loads(stopraw);assert stop['成功'] and stop['編集停止'] and not stop['重大未解決']
    for name,h in stop['停止ファイル'].items():assert sha(Path(name).read_bytes())==h
    proofraw=(SOURCE/'独立検算.json').read_bytes();assert sha(proofraw)=='3b2a8c1303c3dab764b9568b398dfeccf0e5bbd9752bc9d41e22d65f1881de73'
    (FORMAL/'検査/過去学習と再推論の独立検算.json').write_bytes(proofraw)
    (FORMAL/'検査/過去学習独立の停止.json').write_bytes(stopraw)
    (FORMAL/'根拠').mkdir(exist_ok=True)
    body=(SOURCE/'README.md').read_text('utf-8')
    at=body.index('正本は `独立検算.json`')
    body=body[:at]+'''[独立正本](../検査/過去学習と再推論の独立検算.json)、[停止票](../検査/過去学習独立の停止.json)、[Root金融独立](../検査/金融集計の独立確認.json)を恒久保存する。元短報・再現コード・金融前の独立人工は[確認と保存の追補ZIP](../再現資料/確認と保存の追補.zip)へ保管する。F0/F1/教師/モデル/予測は[保管索引](../保管索引.json)から復元する。元コードの絶対pathを新しいrootへ付け替える場合は別の再現用台帳を用い、元の固定を後造りしない。\n'''
    (FORMAL/'根拠/過去学習と再推論の独立照合.md').write_text(body,encoding='utf-8')
    p=FORMAL/'README.md';body=p.read_text('utf-8')
    body=body.replace('モデル/逐次prefixの自然独立照合とCSVの確定は別証跡で追記する。',
        '[自然独立照合](根拠/過去学習と再推論の独立照合.md)は64保存JSONモデル/3,876確率セルを再推論し最大差2.22e−16（許容1e−12）、全752方向・旧81・73教師・65過去prefix・重み・実split2系統以上を一致した。作者関数importや再学習はせず、金融180/適用192のRoot照合と役割を分けた。CSVの確定は別証跡で追記する。')
    p.write_text(body,encoding='utf-8')
    p=FORMAL/'再現手順.md';body=p.read_text('utf-8')
    body=body.replace('現段階はF0固定源と教師入力の恒久保存である。モデル・予測・金融・CSVの保存と照合は後続段階で追記する。正式なREADME/条件/全513セルとRoot凍結Sourceは変更していない。',
        'F0/F1固定源・教師・64モデル・予測・全方向・金融正本・自然独立照合を保存した。CSVはRoot確定後に案内する。正式な条件本文/全513セルとRoot凍結Sourceは不変で、結果は金融後の追記として分ける。')
    body=body.replace('F0全27源と教師73場を同bytesで復元する。元F0・教師参照には実行時の絶対pathが含まれるため、そのまま別rootで自然CLIを実行する手順ではない。再実行用の別path台帳や参照pathの機械的な付替えは、元固定を変更せず、金融後の再現用であると明記して後続段階へ分ける。ここでは教師再射影・学習・予測・金融・新Raw走査を行わない。',
        '''F0全27源/F1全178源、教師73場、64モデル/予測/方向を同bytesで復元する。元F0/F1・教師参照には実行時の絶対pathが含まれ、原文は変更しない。`--replay` を付けると、復元先へ向けた別の予測/方向票と「金融後の再現専用path台帳」を作り、保存予測から実正逆を選び直して集計する。新しい金融前固定を後造りしたものではない。

```powershell
python -X utf8 "study/00143_複合テクニカルを過去の場だけで学び方向を判別する/再現資料/入力を復元する.py" --destination "work/143任意の再集計先" --replay
```

[再現確認](検査/保存予測からの再現確認.json)で178源同bytes、全180条件/適用区分/旧120対照/参加頻度/phaseと三表JSON全bytesが一致した。集計の相違は再現専用F1台帳とpath変更方向の2指紋だけ。保存実正逆は138を共有し、新しいRaw観測や教師再射影・学習・実モデル推論・CSV生成を行っていない。

## 保存モデルを用いた独立再推論

F1はSHA `c0a2d1e8032cbb06bcdef11f3c707a2998225f44c416fe7b0a683ebc2312545c`。64モデル＋モデル参照/全予測/方向/確認の68源は[モデルと予測の1ZIP](../../inputs/00143_逐次学習の教師/モデルと予測.zip)へ各一度保存した。新たなRoot金融独立コード1源は[追加固定ZIP](再現資料/143金融前の追加固定資料.zip)、旧共有源は保管索引で解決する。F1の正式3MD等5MDはF0原文と同bytesのためsnapshotを共有した。

[自然独立短報](根拠/過去学習と再推論の独立照合.md)と[正本](検査/過去学習と再推論の独立検算.json)では、CatBoost1.2.10で64保存JSONを読み3,876確率セルを再推論、最大差2.22e−16で全752方向を一致した。全73教師、65過去prefix、maturity・場等重み・2side配分も再構成し、元の保存監査と一致した。実splitの使用系統は7〜8であり、個別経路が常に2技法同時成立する主張ではない。

独立コードは作者の学習/結合/方向選択関数をimportしない。学習時の全数値・各行重み自体はモデルJSONへ格納されないため、その入力は固定コードの分離と独立再構成監査の一致で確認している。同じモデルからの推論再現と、自然再学習のGUID/時刻込みSHA同体を区別する。独立コード・原短報と金融前の独立人工は[追補ZIP](再現資料/確認と保存の追補.zip)へ保存する。''')
    body=body.replace('自然モデルが保存された後は、そのモデルを正本として参照する。','保存済み64モデルを正本として参照し、結果後に深さ・seed・閾値やモデルを交換していない。')
    p.write_text(body,encoding='utf-8')
    mpath=FORMAL/'保管索引.json';m=json.loads(mpath.read_bytes());m['自然独立SHA256']=sha(proofraw);m['自然独立停止SHA256']=sha(stopraw)
    m['Root金融独立SHA256']=stop['金融独立はRoot担当']['sha256'];assert sha((FORMAL/'検査/金融集計の独立確認.json').read_bytes())==m['Root金融独立SHA256']
    m['保存予測再現SHA256']=sha((FORMAL/'検査/保存予測からの再現確認.json').read_bytes())
    m['入力復元コード']['sha256']=sha((FORMAL/'再現資料/入力を復元する.py').read_bytes())
    mpath.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'自然独立SHA256':sha(proofraw),'保存予測再現SHA256':m['保存予測再現SHA256']},ensure_ascii=False))


if __name__=='__main__':main()
