"""143のF0原文と教師入力だけを保存する。モデル結果は読まない。"""
from pathlib import Path
import gzip
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[2]
FORMAL=next((ROOT/'study').glob('00143_*'))
OWN=ROOT/'work/143逐次判別の評価'


def sha(raw: bytes) -> str:
    """
    機能: 原文bytesの指紋を求める。
    引数: raw(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(raw).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 既存大入力を共有し、F0小型源と場別教師を各一度恒久保存する。
    引数: なし。
    返り値: None。正式3MD/凍結源/モデル/自然学習を変更・再実行しない。
    """
    f0raw=(OWN/'F0学習前.json').read_bytes();assert sha(f0raw)=='f00c2a5e19fcad802cb75286a73e76f4612ea15b3b7aa52618ad85919a7bee5c'
    f0=json.loads(f0raw);assert len(f0['ファイル'])==27
    declared={Path(p):h for p,h in f0['ファイル'].items()}
    for p,h in declared.items():assert sha(p.read_bytes())==h
    for name in ('検査','再現資料'): (FORMAL/name).mkdir(exist_ok=True)
    (FORMAL/'検査/F0学習前.json').write_bytes(f0raw)
    prior=next((ROOT/'study').glob('00142_*'));pm=json.loads((prior/'保管索引.json').read_bytes())
    shared=[d for d in pm['共有入力'] if (ROOT/d['復元先']) in declared]
    assert len(shared)==5
    groups=[];resolved={ROOT/d['復元先'] for d in shared}
    for group in pm['共有固定コード群']:
        entries=[e for e in group['格納源'] if (ROOT/e['復元先']) in declared]
        if entries:
            groups.append({**group,'格納源':entries,'格納源数':len(entries)})
            resolved.update(ROOT/e['復元先'] for e in entries)
    assert len(resolved)==6
    docs=[];bodies={}
    for p,h in declared.items():
        if p in resolved:continue
        raw=p.read_bytes();rel=p.relative_to(ROOT).as_posix()
        if p.suffix=='.md':docs.append({'path':rel,'sha256':h,'bytes':len(raw),'本文':raw.decode('utf-8')})
        else:bodies[rel]=raw
    assert len(docs)==5 and sum(d['path'].startswith('study/') for d in docs)==3 and len(bodies)==16
    snapshot={'試行':143,'段階':'F0原文・モデル自然結果閲覧前の保存','正式文書数':3,'文書数':5,'文書':docs,'事前固定の後造り':False}
    raw=(json.dumps(snapshot,ensure_ascii=False,indent=2)+'\n').encode();packed=gzip.compress(raw,mtime=0)
    (FORMAL/'検査/F0実行前文書.json.gz').write_bytes(packed)
    independent=ROOT/'work/143教師と重みの独立監査';stop=json.loads((independent/'停止の確認.json').read_bytes())
    extra=[]
    for name,h in stop['保存対象'].items():
        p=independent/name;raw=p.read_bytes();assert sha(raw)==h;bodies[p.relative_to(ROOT).as_posix()]=raw;extra.append(p.relative_to(ROOT).as_posix())
    p=independent/'停止の確認.json';bodies[p.relative_to(ROOT).as_posix()]=p.read_bytes();extra.append(p.relative_to(ROOT).as_posix())
    archive=FORMAL/'再現資料/143学習前の固定資料.zip';items=[]
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for rel,raw in sorted(bodies.items()):
            assert len(raw)<1000000;z.writestr(rel,raw)
            items.append({'path':rel,'sha256':sha(raw),'bytes':len(raw),'区分':'F0源外の独立人工監査' if rel in extra else 'F0直接固定源'})
    # ----------------------------------------
    teacherraw=(OWN/'教師/ラベル参照.json').read_bytes();assert sha(teacherraw)=='ff30882dfa64f6450224ec6423c6660d47a4ffe3cbda1f75a8a8d8e69842d930'
    teacher=json.loads(teacherraw);assert len(teacher['files'])==73 and teacher['F0_SHA256']==sha(f0raw)
    target=ROOT/'inputs/00143_逐次学習の教師/場別教師.zip';target.parent.mkdir(parents=True,exist_ok=True)
    members=[]
    with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        p=OWN/'教師/ラベル参照.json';rel=p.relative_to(ROOT).as_posix();z.writestr(rel,teacherraw)
        members.append({'path':rel,'sha256':sha(teacherraw),'bytes':len(teacherraw),'区分':'73場の指紋と参照metadata'})
        for item in teacher['files']:
            p=Path(item['path']);raw=p.read_bytes();assert sha(raw)==item['sha256'];rel=p.relative_to(ROOT).as_posix();z.writestr(rel,raw)
            members.append({'path':rel,'sha256':sha(raw),'bytes':len(raw),'区分':'場別教師・成績分布は本保存で集計しない'})
    (FORMAL/'検査/射影の完了.json').write_bytes((OWN/'射影の完了.json').read_bytes())
    m={'試行':143,'段階':'F0原文/新源/教師入力の恒久保存。モデル/金融/CSVは未保管','F0_SHA256':sha(f0raw),'F0直接源':27,
       'F0文書原文':{'保存元':(FORMAL/'検査/F0実行前文書.json.gz').relative_to(ROOT).as_posix(),'保存SHA256':sha(packed),'保存bytes':len(packed),
                     '解凍SHA256':sha((json.dumps(snapshot,ensure_ascii=False,indent=2)+'\n').encode()),'文書':[{k:d[k] for k in ('path','sha256','bytes')} for d in docs]},
       '追加固定資料':{'ZIP':archive.name,'ZIP_SHA256':sha(archive.read_bytes()),'ZIP_bytes':archive.stat().st_size,'格納源数':len(items),'F0直接源数':16,'格納源':items},
       '共有固定コード群':groups,'共有入力':shared,
       '教師入力':{'保存元ZIP':target.relative_to(ROOT).as_posix(),'ZIP_SHA256':sha(target.read_bytes()),'ZIP_bytes':target.stat().st_size,'格納源数':74,'格納源':members,
                   'ラベル参照SHA256':sha(teacherraw),'教師成績の新集計':False},
       '元F0の復元参照':{'保存元':(FORMAL/'検査/F0学習前.json').relative_to(ROOT).as_posix(),'復元先':(OWN/'F0学習前.json').relative_to(ROOT).as_posix(),'SHA256':sha(f0raw)},
       'venv/DLL/wheel/原板/177MB/大観測/featuresの新恒久複写':False,'正式3MD/Root凍結Source変更':False,'追加2場読取':False}
    (FORMAL/'保管索引.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    for p,h in declared.items():assert sha(p.read_bytes())==h
    proof={'成功':True,'試行':143,'F0全27源前後同体':True,'正式3MD/採用仕様/源条件の原文5MD':True,
           '旧6源共有/新16源ZIP/独立人工4源区分':True,'教師73場/参照1を一度ZIP':True,'自然モデル/予測/金融結果読取':False,
           'venv/DLL/wheels/原板/大入力の新恒久複写':False,'正式3MD/Root凍結Source変更':False,'不足':[],
           'F0_SHA256':sha(f0raw),'保管索引SHA256':sha((FORMAL/'保管索引.json').read_bytes()),'固定ZIP_SHA256':sha(archive.read_bytes()),'教師ZIP_SHA256':sha(target.read_bytes())}
    p=FORMAL/'検査/F0保存の確認.json';p.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'保存確認SHA256':sha(p.read_bytes()),'固定ZIP_SHA256':sha(archive.read_bytes()),'教師ZIP_SHA256':sha(target.read_bytes()),'不足':[]},ensure_ascii=False))


if __name__=='__main__':main()
