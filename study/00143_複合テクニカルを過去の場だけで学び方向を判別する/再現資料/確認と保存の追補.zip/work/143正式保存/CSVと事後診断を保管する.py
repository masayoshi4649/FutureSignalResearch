"""143のRoot確定CSVと閾値未採用の事後診断を保存する。"""
from pathlib import Path
import gzip
import hashlib
import json
import os

ROOT=Path(__file__).resolve().parents[2]
FORMAL=next((ROOT/'study').glob('00143_*'))
OWN=ROOT/'work/143逐次判別の評価'
CSV=ROOT/'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/143_複合テクニカル逐次判別'


def sha(raw: bytes) -> str:
    """
    機能: Root正本の指紋を求める。
    引数: raw(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(raw).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 再読済みCSV案内と小さい事後診断を追加し、元条件を変更しない。
    引数: なし。
    返り値: None。新CSV/新金融計算/閾値政策を作らない。
    """
    expected={'正逆比較.csv':'3fc6fe45c0d20cef52ec9965c423cb605ab54b66593dd73770171d59bbbee75a',
        '入口別診断.csv':'28a6dafccd4b300b222e668e80014b1eed365de77866065f179129e843980020',
        '全セッション.csv':'4211b4d756f12091d6cd1be967f55654ce1d6a35600403f99e644a3a70b26153'}
    for name,h in expected.items():assert sha((CSV/name).read_bytes())==h
    raw=(OWN/'CSV全セルの独立再読.json').read_bytes();proof=json.loads(raw)
    assert proof['成功'] and proof['全データセル比較数']==39685 and proof['数値比較数']==16947
    (FORMAL/'検査/CSV全セルの独立再読.json').write_bytes(raw)
    (FORMAL/'検査/CSV作成の確認.json').write_bytes((CSV/'CSVの確認.json').read_bytes())
    raw=(OWN/'モデル確率と変更群の事後診断.json').read_bytes();assert sha(raw)=='53d48e163e6323a60911a443ce75b9b61268d2893450f96a40de4a252cd06197'
    cause=json.loads(raw);assert cause['成功'] and sum(cause['全変更行列'].values())==298
    hi=[cause['予測順確率'][n] for n in ('0.7以上0.8未満','0.8以上1.000001未満')]
    assert [sum(d[k] for d in hi) for k in ('entries','forward','adverse','neither','censored')]==[8,2,5,0,1]
    packed=gzip.compress(raw,mtime=0);target=FORMAL/'根拠/モデル確率と変更群の事後診断.json.gz'
    with target.open('xb') as f:f.write(packed)
    note='''## 変更群と確率の事後診断

[Rootの事後診断票](根拠/モデル確率と変更群の事後診断.json.gz)では反転298のうち、元順→逆120、元逆→順113、両逆22、未到達→逆6、逆→未到達5、未→未13、H不足19。救えた元負けより失った元勝ちが多かった。全originにおける選択側P順の最小値が0.7以上だった8件も2順5逆・未到達0・H不足1で、高い予測確率が実測の高率を示さなかった。少数の事後区分であり、校正済み確率や新しい閾値政策の有効性を主張しない。

これは金融後にRootが保存結果を区分した診断で、独立した再推論や未使用期検証とは別。閾値の再調整・取引の間引き・モデル交換は行っていない。単に列や学習器を増やすだけでは全体の方向判別を改善できなかったことを次の問いとして残す。

'''
    p=FORMAL/'README.md';body=p.read_text('utf-8');body=body.replace('## 保存・再現・状態',note+'## 保存・再現・状態',1)
    body=body.replace('自然独立照合とCSVを確定中。','自然独立照合・CSV・再現を確認済み、正式保存を最終確認中。')
    body=body.replace('CSVの確定は別証跡で追記する。','[CSV独立再読](検査/CSV全セルの独立再読.json)は39,685セル/16,947数値が一致し、Rootが3画像を視認した。CSVは180×34/833×36/73×49、create/3/csvは今回1回で、xlsxは作っていない。')
    p.write_text(body,encoding='utf-8')
    relative=os.path.relpath(CSV,FORMAL).replace('\\','/')
    body=f'''# 143のCSVと分母

まず[全セッション.csv]({relative}/全セッション.csv)で全73場を確認する。[入口別診断.csv]({relative}/入口別診断.csv)は833基礎入口、[正逆比較.csv]({relative}/正逆比較.csv)は180条件。T0が逐次複合モデル、P0が同752native、C0が旧81保護である。

主T0は319順305逆75未到達53H不足、到達済み先着51.12%=319/(319+305)。完了699中45.64%、全752中42.42%と分母を分ける。全73場min1、平均1.04312件/時だが70%未達。C5利益4,159,587円/損失4,720,028円・既知差引−560,441円、未知19。未知を0円とせず、全独立mini1枚代用の合算を同時口座収支と呼ばない。

モデル適用631は265順269逆/49.63%・C5−677,586円。保護81の68.97%/+199,994円と分ける。表のT0/P0の既知集合も733/732で異なり、合計差を同じ両既知caseのペア差としない。政策C0と費用C0（追加滑り0）も別の定義。

[Root独立再読](検査/CSV全セルの独立再読.json)で39,685データセル/16,947数値が一致し、Rootが3画像を確認した。汎用作者v2は数字を再計算せず、xlsxは生成していない。[正式結果](README.md)、[再現手順](再現手順.md)、[集計正本](成果物/集計.json)。
'''
    (FORMAL/'閲覧資料.md').write_text(body,encoding='utf-8')
    relative=os.path.relpath(FORMAL,CSV).replace('\\','/')
    (CSV/'README.md').write_text(f'# 143 複合テクニカル逐次判別\n\nまず[全セッション.csv](全セッション.csv)で全73場を見る。[入口別診断.csv](入口別診断.csv)は833基礎行、[正逆比較.csv](正逆比較.csv)は180条件。主T0は752/73場・1.04312件/時、319順305逆75未到達53H不足・到達済み51.12%。C5利益4,159,587円/損失4,720,028円・既知差引−560,441円、未知19で不採用。\n\nP0は同752native、C0は旧81保護。モデル適用631は49.63%で、保護81の68.97%と分ける。独立mini1枚代用と口座収支、政策C0と費用C0、先着分母とIFD金額既知性を区別する。[正式結果]({relative}/README.md)、[閲覧定義]({relative}/閲覧資料.md)。\n',encoding='utf-8')
    p=FORMAL/'再現手順.md';body=p.read_text('utf-8').replace('CSVはRoot確定後に案内する。','CSVもRootの全セル再読・3画像確認が完了した。[閲覧資料](閲覧資料.md)を参照する。')
    body += '\n## CSVと事後診断の保存\n\nRootの汎用CSV作者v2（Node24.22.1/Artifact Tool2.8.129）の同SHAコードとreaderは既存141/140の追補ZIPを共有する。今回create/3/csvは1回、39,685セル/16,947数値を再読し3画像をRootが確認した。こちらの復元ではCSVを重複生成しない。[作成証跡](検査/CSV作成の確認.json)と[再読](検査/CSV全セルの独立再読.json)を保存する。\n\n[変更群/確率の小票](根拠/モデル確率と変更群の事後診断.json.gz)はRootの金融後の事後診断で、元コードは追補ZIPへ保存する。選択側P順の全origin最小値>=0.7群8件は2順5逆・H不足1であり、未到達1ではない。新しい閾値政策には採用していない。\n'
    p.write_text(body,encoding='utf-8')
    mpath=FORMAL/'保管索引.json';m=json.loads(mpath.read_bytes());m['CSV正本']=CSV.relative_to(ROOT).as_posix();m['CSV_SHA256']=expected
    m['Root事後診断']={'保存元':target.relative_to(ROOT).as_posix(),'形式':'gzip','保存bytes':len(packed),'保存SHA256':sha(packed),'解凍bytes':len(raw),'解凍SHA256':sha(raw)}
    mpath.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'CSV39685セル16947数値':True,'事後診断原文SHA256':sha(raw),'事後診断gzipSHA256':sha(packed)},ensure_ascii=False))


if __name__=='__main__':main()
