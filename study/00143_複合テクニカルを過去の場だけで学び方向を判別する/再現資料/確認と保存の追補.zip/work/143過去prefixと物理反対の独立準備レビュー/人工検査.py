"""143の過去prefix・物理反対・教師maturity・CPU再推論だけを自然入力なしで確認する。"""
from pathlib import Path
from collections import Counter
from unittest.mock import patch
import copy
import importlib.util
import json
import math
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
SOURCE = ROOT / 'work/143複合テクニカルの逐次判別'
sys.path.insert(0, str(SOURCE))
import features143 as feat
import data143 as data
import model143 as mod
import io143 as io
spec = importlib.util.spec_from_file_location('独立人工用143逐次制御', SOURCE / '学習予測する.py')
controller = importlib.util.module_from_spec(spec)
spec.loader.exec_module(controller)


def values(x: float = 1, y: float = 1) -> dict:
    """
    機能: 74数値列の小型人工を作る。
    引数: x/y(float)は独立なMA/RSI値。
    返り値: dictは未知をnullで保持する特徴。
    """
    v = {n: {'known': True, 'value': 0.0} for n in feat.NAMES}
    v['m5_gap_to_side']['value'] = x
    v['m5_rsi_center_to_side']['value'] = y
    return v


# ----------------------------------------
def check_mirror() -> None:
    """
    機能: 1−x/符号/不変/ヒゲknown交換/二重鏡像を検査する。
    引数: なし。
    返り値: None。系統表も一度ずつ数える。
    """
    v = values(2, -3)
    v['bb15_percent_to_side']['value'] = 1.2
    v['m5_close_position_to_side']['value'] = .15
    v['m5_forward_wick_ratio'] = {'known': False, 'value': None}
    v['m5_opposite_wick_ratio'] = {'known': True, 'value': .3}
    v['m15_atr']['value'] = 100
    original = copy.deepcopy(v); m = feat.mirror(v)
    assert v == original and m['m5_gap_to_side']['value'] == -2 and m['m5_rsi_center_to_side']['value'] == 3
    assert math.isclose(m['bb15_percent_to_side']['value'], -.2, abs_tol=1e-12)
    assert math.isclose(m['m5_close_position_to_side']['value'], .85, abs_tol=1e-12)
    assert m['m5_forward_wick_ratio'] == v['m5_opposite_wick_ratio'] and m['m5_opposite_wick_ratio'] == v['m5_forward_wick_ratio']
    assert m['m15_atr'] == v['m15_atr']
    twice = feat.mirror(m)
    for n in feat.NAMES:
        assert twice[n]['known'] == v[n]['known']
        if v[n]['known']: assert math.isclose(twice[n]['value'], v[n]['value'], rel_tol=0, abs_tol=1e-12)
        else: assert twice[n]['value'] is None
    assert math.isnan(feat.vector(v)[feat.NAMES.index('m5_forward_wick_ratio')])
    assert Counter(feat.families().values()) == {'MA':24,'MACD':12,'RSI':6,'DMI/ADX':9,'ATR/TR':12,'BB':4,'足形':6,'RVOL':1}


# ----------------------------------------
def training_fixture() -> tuple[list, list]:
    """
    機能: 2場32canonical/3class・origin数可変の人工過去資料を作る。
    引数: なし。
    返り値: tuple[list,list]は過去特徴と過去ラベル。
    """
    features, docs = [], []
    grid = (-2., -1., 1., 2.)
    for s in range(2):
        sid = '人工過去場' + str(s); start = 1000+s*10000
        doc = {'success':True,'trial':143,'session':sid,'start':start,'end':start+9000,'rows':[]}
        for k in range(16):
            i = s*16+k; x,y = grid[k%4],grid[k//4]
            target = 2 if x > 0 and y > 0 else 0 if x < 0 and y < 0 else 1
            origins = [{'query_id':f'人工q/{i}/{oi}','origin_index':oi,'values':values(x,y)} for oi in range(2 if i%5==0 else 1)]
            f = {'id':f'P0/人工/{i}','session':sid,'native_side':1,'baseline':i<4,'origins':origins}
            known = start+5000+k
            label = {'id':f['id'],'session':sid,'native_side':1,'eligible_pair':True,'one_side_only_complete':False,'label_known_at':known,
                     'original':{'complete':True,'class':target,'known_at':known},'reverse':{'complete':True,'class':2-target,'known_at':known}}
            features.append(f);doc['rows'].append(label)
        docs.append(doc)
    return features,docs


# ----------------------------------------
def check_labels_and_weights() -> None:
    """
    機能: touchとH完了知得の分離・strict maturity・canonical重みを検査する。
    引数: なし。
    返り値: None。
    """
    endpoint = {'time':3710,'index':10,'source_line':11,'quote_ok':True,'bid':100,'ask':110}
    stream = {'entry':{'time':100,'index':0,'source_line':1},'outcomes':[{'seconds':3600,'deadline':3700,'status':'complete','endpoint':endpoint,
               'touches':[{'width':125,'direction':1,'quote':{'time':200}}]}]}
    got = data.label(stream,4000)
    assert got == {'complete':True,'class':2,'known_at':3710}
    stream['outcomes'][0].update(status='gap_censored',endpoint=None)
    assert data.label(stream,4000) == {'complete':False,'class':None,'known_at':None}
    f,l = training_fixture(); t = mod.training_rows(f,l,30000)
    assert t['audit']['training_canonical_complete_pairs'] == 32 and t['audit']['classes'] == [0,1,2]
    assert t['audit']['protected_baseline_canonical_included_once'] == 4
    assert len(t['X']) == len(t['weights']) == sum(len(r['origins'])*2 for r in f)
    cursor = 0
    for row in f:
        count = len(row['origins'])*2
        assert math.isclose(sum(t['weights'][cursor:cursor+count]),len(t['X'])/2/16,abs_tol=1e-10)
        cursor += count
    bad = copy.deepcopy(l); bad[-1]['rows'][-1]['label_known_at'] = 30000
    bad[-1]['rows'][-1]['original']['known_at'] = 30000
    try: mod.training_rows(f,bad,30000)
    except AssertionError: pass
    else: raise AssertionError('label既知時刻の等号を受理した')
    extra = copy.deepcopy(f); extra.append({**f[0],'id':'P0/current'})
    try: mod.training_rows(extra,l,30000)
    except AssertionError: pass
    else: raise AssertionError('現在特徴の混入を受理した')


# ----------------------------------------
def prefix_fixture() -> tuple[dict, dict, dict]:
    """
    機能: labelを実ファイルへ書かない73場752行の制御用人工を作る。
    引数: なし。
    返り値: tuple[dict,dict,dict]はcohort/manifest/場別doc。
    """
    sessions = ['人工場'+str(i) for i in range(73)]
    cohort = {'sessions':sessions,'rows':[]}; manifest = {'success':True,'trial':143,'sessions':sessions,'files':[]}; docs = {}
    for i,sid in enumerate(sessions):
        start = i*10000
        info = {'session_index':i,'session':sid,'start':start,'end':start+9000,'path':str(OWN/f'未作成人工label_{i}.json'),'sha256':str(i)}
        rows = []
        for j in range(11 if i<22 else 10):
            identity = f'P0/{i}/{j}'
            cohort['rows'].append({'id':identity,'session':sid,'native_side':1,'baseline':False,'origins':[],'marker':0})
            rows.append({'id':identity,'original':{'class':0}})
        docs[i] = {k:info[k] for k in ('session_index','session','start','end')} | {'success':True,'trial':143,'rows':rows}
        manifest['files'].append(info)
    return cohort,manifest,docs


# ----------------------------------------
def prefix_run(cohort: dict, manifest: dict, docs: dict) -> tuple[list, list]:
    """
    機能: 実load_prefixを捕捉し、fit/score境界だけを偽モデルで検査する。
    引数: cohort/manifest/docs(dict)は小型人工。
    返り値: tuple[list,list]は予測と開示path記録。モデル性能は検証しない。
    """
    log = []; context = {'index':None}; actual_prefix = io.load_prefix
    def read_label(path: Path, expected: str) -> dict:
        """
        機能: 人工pathを開かず、現在/未来へのアクセスを即失敗にする。
        引数: path(Path)、expected(str)は人工参照。
        返り値: dictは過去docのcopy。
        """
        i = next(i for i,f in enumerate(manifest['files']) if f['path']==str(path))
        assert i < context['index']; log.append((context['index'],i))
        return copy.deepcopy(docs[i])
    def prefix(files: list, index: int, sid: str, start: float) -> list:
        """
        機能: 実prefix検査へ現在場の制御情報を付ける。
        引数: files(list)、index(int)、sid(str)、start(float)。
        返り値: listは実load_prefixが許可したdoc。
        """
        context['index'] = index
        return actual_prefix(files,index,sid,start)
    def fit(prior_features: list, prior_labels: list, start: float, model_path: Path) -> tuple:
        """
        機能: 引数が過去だけか検査して敏感な人工markerを作る。
        引数: prior_features/prior_labels(list)、start(float)、model_path(Path)。
        返り値: tupleは偽モデルと監査。CPU学習とは別の制御試験。
        """
        index = context['index']; permitted = set(cohort['sessions'][:index])
        assert all(f['session'] in permitted for f in prior_features)
        assert all(d['session'] in permitted and d['end']<=start for d in prior_labels)
        marker = sum(r['original']['class'] for d in prior_labels for r in d['rows'])
        return marker,{'status':'人工active','model_ref':None,'training':None}
    def score(model: object, current_features: list, audit: dict) -> list:
        """
        機能: 現在特徴だけで予測する呼出し形を検査する。
        引数: model(object)、current_features(list)、audit(dict)。
        返り値: listは人工の値。ラベル引数はない。
        """
        assert len({f['session'] for f in current_features})==1
        return [{'id':f['id'],'session':f['session'],'marker':(model or 0)+f['marker']} for f in current_features]
    with patch.object(io,'load',read_label),patch.object(controller,'load_prefix',prefix),patch.object(controller,'fit',fit),patch.object(controller,'score',score):
        _,rows = controller.sequential(cohort,manifest,OWN/'未作成人工models')
    assert all(i>=8 and j<i for i,j in log)
    return rows,log


# ----------------------------------------
def check_prefix() -> None:
    """
    機能: 未来label/featureを変えても、それ以前の予測が変わらないことを捕捉する。
    引数: なし。
    返り値: None。自然の学習/ラベルを読まない。
    """
    c,m,d = prefix_fixture(); base,log = prefix_run(c,m,d)
    future = copy.deepcopy(d); future[30]['rows'][0]['original']['class'] = 2
    changed,_ = prefix_run(c,m,future)
    sid_to_i = {sid:i for i,sid in enumerate(c['sessions'])}
    assert [r for r in base if sid_to_i[r['session']]<=30] == [r for r in changed if sid_to_i[r['session']]<=30]
    assert any(a!=b for a,b in zip(base,changed))
    c2 = copy.deepcopy(c)
    for row in c2['rows']:
        if row['session']==c['sessions'][30]: row['marker']=123
    current_changed,_ = prefix_run(c2,m,d)
    assert [r for r in base if sid_to_i[r['session']]<30] == [r for r in current_changed if sid_to_i[r['session']]<30]
    assert len(log)==sum(range(8,73))


# ----------------------------------------
def check_cpu_reload() -> dict:
    """
    機能: 小型CPUモデルを1回学び、同じ保存JSONの再読込予測を照合する。
    引数: なし。
    返り値: dictは数値一致/使用系統の小型証跡。再学習SHA一致は要求しない。
    """
    from catboost import CatBoostClassifier
    f,l = training_fixture()
    with tempfile.TemporaryDirectory(prefix='人工CPU_',dir=OWN) as name:
        folder = Path(name).resolve(); assert folder.is_relative_to(OWN)
        model,audit = mod.fit(f,l,30000,folder/'model.json')
        assert audit['status']=='active' and model is not None and len(audit['model_ref']['used_technical_families'])>=2
        current = copy.deepcopy(f[:4])
        for row in current: row['baseline']=False;row['session']='人工現在場'
        original = mod.score(model,current,audit)
        restored = CatBoostClassifier();restored.load_model(str(folder/'model.json'),format='json')
        replay = mod.score(restored,current,audit)
        largest = 0.0
        for a,b in zip(original,replay):
            for x,y in zip(a['origins'],b['origins']):
                assert x['selected_side']==y['selected_side']
                for field in ('native_probabilities','reverse_probabilities'):
                    largest=max(largest,max(abs(v-w) for v,w in zip(x['probabilities'][field],y['probabilities'][field])))
        assert largest<=1e-12
        return {'同JSON再推論最大差':largest,'使用系統':audit['model_ref']['used_technical_families'],'人工JSON_SHA256':audit['model_ref']['sha256'],'再学習_SHA同体要求':False}


# ----------------------------------------
def main() -> None:
    """
    機能: 必要4主群を実行し、CPU再推論の結果だけを保存する。
    引数: なし。
    返り値: None。自然143モデルや出力を作らない。
    """
    check_mirror();check_labels_and_weights();check_prefix();cpu=check_cpu_reload()
    out = OWN/'人工CPU再推論.json';assert not out.exists()
    out.write_text(json.dumps({'成功':True,'人工4主群':True,**cpu},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'人工4主群':True,**cpu},ensure_ascii=False))


if __name__ == '__main__': main()
