"""143の独立人工結果と、作者停止13源・F0の指紋を確認する。自然教師本文は開かない。"""
from pathlib import Path
import ast
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
SOURCE = ROOT / 'work/143複合テクニカルの逐次判別'


def sha(path: Path) -> str:
    """
    機能: 保存したファイルのSHA256を算出する。
    引数: path(Path)はファイル。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 作者停止源・F0と独立人工を結合した準備証跡を保存する。
    引数: なし。教師・自然予測・金融本文は開かない。
    返り値: None。自己専有フォルダへ確認JSONを保存する。
    """
    author = SOURCE / '準備の確認.json'
    assert sha(author) == 'baa2a36e140e8984b62b50f9d48c8793569cf278985bca7cf810bf8d2a3c111d'
    report = json.loads(author.read_bytes())
    expected = report['ローカル13源']
    assert len(expected) == 13
    actual = {p: sha(Path(p)) for p in expected}
    assert actual == expected
    f0 = ROOT / 'work/143逐次判別の評価/F0学習前.json'
    assert sha(f0) == 'f00c2a5e19fcad802cb75286a73e76f4612ea15b3b7aa52618ad85919a7bee5c'
    frozen = json.loads(f0.read_bytes())
    assert all(frozen['ファイル'][p] == value for p, value in actual.items())
    driver = ROOT / 'work/143過去学習と現在予測を固定して実行する.py'
    ast.parse(driver.read_text(encoding='utf-8'))
    assert frozen['ファイル'][str(driver)] == sha(driver)
    artificial = OWN / '人工CPU再推論.json'
    tests = json.loads(artificial.read_bytes())
    assert tests['成功'] and tests['人工4主群'] and tests['同JSON再推論最大差'] == 0
    result = {
        '成功': True, '試行': 143, '重大未解決': [],
        '作者停止13源一致': True, 'F0内13源一致': True,
        '作者人工8主': '停止proofの成功証跡を再用',
        '独立人工4主': ['74列の物理反対と8系統・未知維持',
                    '両H完了maturity・strict知得時計・場とcanonical重み',
                    '初8場ラベル未読・過去prefix限定・将来変更の前場非依存',
                    '実CPU学習後の同JSON再読込・数値再推論'],
        '同JSON再推論最大差': tests['同JSON再推論最大差'],
        '再現性の区別': '同じ保存JSONの再推論一致を検査。GUID・学習時計を含む再学習SHA一致は要求しない。',
        '静的確認': ['current特徴とlabelはfitへ渡さない、scoreはcurrent特徴だけ',
                   '両H60完了endpoint最大知得時刻がcurrentSceneStartより厳密前',
                   'P0保護81をcanonicalとして一度学習し別C0複写を加えない',
                   '全originのquery.side一致・反対特徴の変換・最終方向合意',
                   '固定CPUパラメータ・学習Poolのみ量子化・実FloatFeature分岐2系統guard',
                   'F0→教師射影→逐次学習予測→F1→金融の分離、金融から再学習なし',
                   'Root金融adapterは固定済み算術を再用し方向だけ再結合'],
        '自然教師本文読取': False, '自然学習実行': False, '自然予測読取': False,
        '新金融読取': False, 'Raw価格CSV追加2場読取': False, 'Root源変更': False,
        '作者停止証跡': {'path': str(author), 'sha256': sha(author)},
        'F0': {'path': str(f0), 'sha256': sha(f0)},
        '作者13源': actual,
        '独立人工': {'path': str(OWN / '人工検査.py'), 'sha256': sha(OWN / '人工検査.py')},
        '人工結果': {'path': str(artificial), 'sha256': sha(artificial)},
        'Root運転部': {'path': str(driver), 'sha256': sha(driver)},
        '編集停止': True,
    }
    path = OWN / '準備の確認.json'
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '停止証跡': str(path), 'SHA256': sha(path)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
