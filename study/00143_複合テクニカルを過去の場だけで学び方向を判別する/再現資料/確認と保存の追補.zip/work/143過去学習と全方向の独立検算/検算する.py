"""143の保存モデル再推論・教師時計・過去prefix・全方向を作者関数なしで検算する。"""
from pathlib import Path
from collections import Counter, defaultdict
from fractions import Fraction
import hashlib
import json
import math
import catboost
from catboost import CatBoostClassifier

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
RUN = ROOT / 'work/143逐次判別の評価'
SOURCE = ROOT / 'work/143複合テクニカルの逐次判別'
BASE = ('gap_to_side', 'gap_atr_to_side', 'ema8_delta_to_side', 'ema8_delta_atr_to_side',
        'ema21_delta_to_side', 'ema21_delta_atr_to_side', 'di_difference_to_side', 'adx', 'adx_delta',
        'rsi_center_to_side', 'rsi_delta_to_side', 'hist_to_side', 'hist_atr_to_side',
        'hist_delta_to_side', 'hist_delta_atr_to_side', 'price_ema8_atr_to_side',
        'price_ema21_atr_to_side', 'atr', 'tr_atr_ratio', 'atr_tr_ratio', 'tr_previous_atr_ratio')
EXTRA = ('m5_range', 'm5_body_to_side', 'm5_body_ratio_to_side', 'm5_forward_wick_ratio',
         'm5_opposite_wick_ratio', 'm5_close_position_to_side', 'rvol5', 'bb15_sigma',
         'bb15_position_sigma_to_side', 'bb15_percent_to_side', 'bb15_width_atr_ratio')
NAMES = sorted([f'm{m}_{n}' for m in (5, 15, 30) for n in BASE] + list(EXTRA))
PARAMS = {'iterations':128, 'depth':3, 'learning_rate':.05, 'l2_leaf_reg':10,
          'loss_function':'MultiClass', 'classes_count':3, 'random_seed':143,
          'boosting_type':'Plain', 'bootstrap_type':'No', 'random_strength':0,
          'has_time':True, 'nan_mode':'Min', 'use_best_model':False,
          'allow_writing_files':False, 'verbose':0, 'task_type':'CPU', 'thread_count':1}
READ = {}


def sha(path: Path) -> str:
    """
    機能: 指定ファイルの保存bytesをSHA256へ写す。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def load(path: Path, expected: str | None = None) -> dict:
    """
    機能: 保存JSONの指紋を記録し、指定された指紋を照合して読む。
    引数: path(Path)、expected(str|None)。
    返り値: dictは保存JSON。
    """
    body = path.read_bytes(); h = hashlib.sha256(body).hexdigest()
    if expected is not None:
        assert h == expected, path
    READ[str(path.resolve())] = h
    return json.loads(body)


# ----------------------------------------
def family(name: str) -> str:
    """
    機能: 固定74列を重複しない8技法系統へ分類する。
    引数: name(str)は列名。
    返り値: strは技法系統。
    """
    if name == 'rvol5': return 'RVOL'
    if name.startswith('bb15_'): return 'BB'
    if 'hist' in name: return 'MACD'
    if 'ema' in name or 'gap' in name: return 'MA'
    if 'rsi' in name: return 'RSI'
    if 'di_difference' in name or 'adx' in name: return 'DMI/ADX'
    if name in ('m5_range', 'm5_body_to_side', 'm5_body_ratio_to_side',
                 'm5_forward_wick_ratio', 'm5_opposite_wick_ratio', 'm5_close_position_to_side'):
        return '足形'
    assert '_atr' in name or '_tr_' in name
    return 'ATR/TR'


# ----------------------------------------
def raw_value(item: dict) -> float | None:
    """
    機能: 未知nullと既知の有限数値を区別する。
    引数: item(dict)はknown/value。
    返り値: float|None。
    """
    assert type(item['known']) is bool
    if not item['known']:
        assert item['value'] is None
        return None
    assert type(item['value']) in (int, float) and math.isfinite(item['value'])
    return item['value']


# ----------------------------------------
def vector(values: dict, reverse: bool) -> list:
    """
    機能: 74列を同じ物理市場のnative又は反対方向へ独立変換する。
    引数: values(dict)、reverse(bool)。
    返り値: list[float]は未知をNaNで保持したモデル入力。
    """
    assert set(values) == set(NAMES)
    result = []
    for name in NAMES:
        key = name
        if reverse and name == 'm5_forward_wick_ratio': key = 'm5_opposite_wick_ratio'
        if reverse and name == 'm5_opposite_wick_ratio': key = 'm5_forward_wick_ratio'
        v = raw_value(values[key])
        if v is None:
            result.append(math.nan); continue
        if reverse and name in ('bb15_percent_to_side', 'm5_close_position_to_side'): v = 1-v
        elif reverse and name.endswith('_to_side'): v = -v
        result.append(v)
    return result


# ----------------------------------------
def at(quote: dict) -> tuple:
    """
    機能: 時刻と採用順・物理行を取り出す。
    引数: quote(dict)。
    返り値: tuple[float,int,int]。
    """
    return tuple(quote[k] for k in ('time', 'index', 'source_line'))


# ----------------------------------------
def join(manifest: dict, queries: dict, features: dict) -> tuple:
    """
    機能: 833入口・850由来・769出生を作者関数なしで結合する。
    引数: manifest/queries/features(dict)。
    返り値: tupleはP0の752行・全由来・場順。
    """
    qmap = {r['id']:r for r in queries['queries']}
    fmap = {r['query']['id']:r for r in features['rows']}
    assert len(qmap) == len(fmap) == 769 and qmap.keys() == fmap.keys()
    assert set(features['catalog']) == set(NAMES)
    for qid, f in fmap.items():
        assert f['query'] == qmap[qid]
        born = at(qmap[qid]['birthQuote'])
        a, b = vector(f['values'], False), vector(f['values'], True)
        v = {n:{'known':not math.isnan(x), 'value':None if math.isnan(x) else x} for n,x in zip(NAMES,b)}
        aa = vector(v, True)
        assert all((math.isnan(x) and math.isnan(y)) or math.isclose(x,y,abs_tol=1e-12,rel_tol=0) for x,y in zip(a,aa))
        for name in NAMES: assert f['known_mask'][name] is f['values'][name]['known']
        for ref in f['refs']:
            assert ref['end'] <= born[0] and all(x <= y for x,y in zip(at(ref['delivered']),born))
        for m in (5,15,30):
            foot = f['feet']['m'+str(m)]
            if foot is None: continue
            assert foot['end'] <= foot['available_at'] <= foot['delivery_at'] <= foot['delivered']['time'] <= born[0]
            assert all(x <= y for x,y in zip(at(foot['delivered']),born))
            assert born[0] < foot['end']+m*60+60
    relations = {(r['model'],r['manifest_index'],r['origin_index']):r for r in queries['relations']}
    assert len(relations) == 850
    controls = {r['id']:r for r in manifest['C0']}; assert len(controls) == 81
    sessions = [r['session'] for r in manifest['frequency']['P0']['scenes']]
    seen, used, rows, entry_origins = set(), set(), [], []
    for model in ('C0','P0'):
        for index, candidate in enumerate(manifest[model]):
            if candidate['baseline'] or model == 'C0':
                assert candidate['baseline']
                assert all(candidate[k] == controls[candidate['id']][k] for k in ('side','session','contract','entryQuote'))
            origins = []
            for oi, origin in enumerate(candidate['origins']):
                rel = relations[model,index,oi]; qid = rel['query_id']; query = qmap[qid]
                key = json.dumps([origin['source_file_sha'],origin['source_locator'],origin['side'],at(origin['birthQuote'])],
                                 ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
                assert qid == 'origin/'+hashlib.sha256(key).hexdigest()[:32]
                assert query == {'id':qid, 'session':candidate['session'], 'contract':candidate['contract'],
                                 'side':origin['side'], 'birthQuote':{k:origin['birthQuote'][k] for k in ('time','index','source_line','last')}}
                assert query['side'] == candidate['side']
                assert rel == {'entry_id':model+'/'+candidate['id'],'query_id':qid,'model':model,'manifest_index':index,
                               'origin_index':oi,'family':origin['family'],'side':origin['side'],'selected_side':candidate['side']}
                assert all(x <= y for x,y in zip(at(query['birthQuote']),at(candidate['entryQuote'])))
                assert all(origin['entryQuote'][k] == candidate['entryQuote'][k] for k in ('time','index','source_line','last','bid','ask','quote_ok'))
                origins.append({'query_id':qid,'origin_index':oi,'values':fmap[qid]['values']})
                seen.add((model,index,oi)); used.add(qid)
            entry_origins.append({'id':model+'/'+candidate['id'],'session':candidate['session'],'model':model,
                                  'origin_query_ids':[o['query_id'] for o in origins]})
            if model == 'P0':
                rows.append({'id':'P0/'+candidate['id'],'session':candidate['session'],'native_side':candidate['side'],
                             'baseline':candidate['baseline'],'origins':origins})
    assert len(rows) == 752 and sum(r['baseline'] for r in rows) == 81
    assert len(sessions) == len(set(sessions)) == 73 and len(entry_origins) == 833
    assert used == set(qmap) and seen == set(relations)
    return rows, entry_origins, sessions


# ----------------------------------------
def label(stream: dict, end: float) -> dict:
    """
    機能: 保存実BBOのH60完了と±125先着を独立に教師へ写す。
    引数: stream(dict)、end(float)はザラバ終了。
    返り値: dictはcomplete/class/known_at。早いtouchを知得時計にしない。
    """
    h = next(r for r in stream['outcomes'] if r['seconds'] == 3600)
    deadline = stream['entry']['time']+3600
    assert h['deadline'] == deadline
    if h['status'] != 'complete':
        assert h['endpoint'] is None
        return {'complete':False,'class':None,'known_at':None}
    q = h['endpoint']
    assert deadline <= q['time'] <= deadline+30 and q['time'] < end
    assert q['quote_ok'] and 0 < q['bid'] < q['ask']
    assert q['index'] > stream['entry']['index'] and q['source_line'] > stream['entry']['source_line']
    touch = next(t for t in h['touches'] if t['width'] == 125)
    assert touch['direction'] in (-1,0,1)
    assert (touch['quote'] is None) == (touch['direction'] == 0)
    return {'complete':True,'class':touch['direction']+1,'known_at':q['time']}


# ----------------------------------------
def teachers(observed: dict, fixed: dict, labels: dict, cohort: list, sessions: list) -> list:
    """
    機能: 73場の保存教師を元観測から再射影して同体を確認する。
    引数: observed/fixed/labels(dict)、cohort/sessions(list)。
    返り値: list[dict]は全教師場。
    """
    assert observed['trial'] == 133 and fixed['expected_entry_count'] == observed['source_entry_count'] == 833
    assert labels['sessions'] == sessions
    fby = {f['id']:f for f in cohort}; docs = []
    for i, (s, m, item) in enumerate(zip(observed['scenes'],fixed['scenes'],labels['files'])):
        assert s['session'] == m['session'] == item['session'] == sessions[i]
        assert s['execution_end'] == m['end']-300
        projected = []
        for c in s['cases']:
            if not c['id'].startswith('P0/'): continue
            f = fby[c['id']]; assert c['original_side'] == f['native_side'] and f['session'] == s['session']
            assert c['original']['entry'] == c['reverse']['entry']
            for sign, key in ((1,'original'),(-1,'reverse')):
                stream = c[key]
                assert stream['axis'] == 'BBO' and stream['status'] == 'filled'
                assert stream['birth']['side'] == sign*c['original_side']
            a,b = label(c['original'],s['execution_end']),label(c['reverse'],s['execution_end'])
            pair = a['complete'] and b['complete']
            projected.append({'id':c['id'],'session':s['session'],'native_side':c['original_side'],'original':a,'reverse':b,
                              'eligible_pair':pair,'label_known_at':max(a['known_at'],b['known_at']) if pair else None,
                              'one_side_only_complete':a['complete'] != b['complete']})
        expected = {'success':True,'trial':143,'session_index':i,'session':s['session'],
                    'start':m['start'],'end':m['end'],'rows':projected}
        doc = load(Path(item['path']),item['sha256']); assert doc == expected
        assert all(doc[k] == item[k] for k in ('session_index','session','start','end'))
        docs.append(doc)
    assert len(docs) == 73 and sum(len(d['rows']) for d in docs) == 752
    return docs


# ----------------------------------------
def audit_prefix(index: int, model: dict, docs: list, fby: dict, sessions: list) -> dict:
    """
    機能: 過去prefixだけから教師・重み・学習監査を独立再構成する。
    引数: index(int)、model(dict)、docs(list)、fby(dict)、sessions(list)。
    返り値: dictは照合した小型の学習概要。
    """
    prefix = docs[:index]; current = docs[index]; eligible, incomplete, one = [],0,0
    assert model['session_index'] == index and model['session'] == current['session']
    assert model['start'] == current['start'] and model['end'] == current['end']
    if index < 8:
        assert model['status'] == 'warmup8' and model['model_ref'] is None and model['training'] is None
        return {'index':index,'status':'warmup8','label_paths_for_train':0}
    for d in prefix:
        assert d['start'] < current['start'] and d['end'] <= current['start']
        assert d['session'] != current['session']
        for r in d['rows']:
            if not r['eligible_pair']:
                incomplete += 1; one += r['one_side_only_complete']; continue
            assert r['label_known_at'] == max(r['original']['known_at'],r['reverse']['known_at']) < current['start']
            eligible.append(r)
    count = Counter(r['session'] for r in eligible)
    keys, queryids, classes = [],[],[]
    for r in eligible:
        f = fby[r['id']]
        for o in sorted(f['origins'],key=lambda x:x['origin_index']):
            for rev in (False,True):
                keys.append((r['id'],r['session'],o['query_id'],o['origin_index'],rev))
                queryids.append(o['query_id']); classes.append(r['reverse' if rev else 'original']['class'])
    n = len(keys); ns = len(count); sums = defaultdict(Fraction)
    for cid,sid,qid,oi,rev in keys:
        w = Fraction(n,ns*len(fby[cid]['origins'])*2*count[sid])
        sums[sid] += w
    assert all(v == Fraction(n,ns) for v in sums.values()) and sum(sums.values()) == n
    expected = {'training_sessions':sessions[:index],'training_case_ids':[r['id'] for r in eligible],
                'training_query_ids':list(dict.fromkeys(queryids)),'training_canonical_complete_pairs':len(eligible),
                'discarded_incomplete_canonical':incomplete,'one_side_only_complete':one,
                'training_physical_rows':n,'classes':sorted(set(classes)),
                'class_rows':{str(k):v for k,v in Counter(classes).items()},
                'max_label_known_at':max((r['label_known_at'] for r in eligible),default=None),
                'current_start':current['start'],'scene_weight_sums':{sid:float(v) for sid,v in sums.items()},
                'protected_baseline_canonical_included_once':sum(fby[r['id']]['baseline'] for r in eligible),
                'current_labels_received':False,'feature_names':NAMES,
                'row_order':'過去場の保存case順→origin_index順→native/実逆'}
    audit = model['training']
    for k,v in expected.items():
        if k == 'scene_weight_sums':
            assert set(audit[k]) == set(v)
            assert all(math.isclose(audit[k][sid],w,abs_tol=1e-8,rel_tol=0) for sid,w in v.items())
        else: assert audit[k] == v, (index,k)
    status = ('insufficient_complete32' if len(eligible)<32 else
              'missing_three_classes' if sorted(set(classes)) != [0,1,2] else
              'active' if len(model['model_ref']['used_technical_families'])>=2 else 'fewer_than_two_technical_families')
    assert model['status'] == status
    return {'index':index,'status':status,'label_paths_for_train':index,'canonical_complete_pairs':len(eligible),
            'physical_rows':n,'max_known_at':expected['max_label_known_at'],'current_start':current['start'],
            'protected_baseline_once':expected['protected_baseline_canonical_included_once'],
            'scene_weight_sum_fraction':str(Fraction(n,ns)),'scene_equal_weights':True,'audit_fields_equal':True}


# ----------------------------------------
def replay_model(model: dict, current: list, saved: dict) -> tuple:
    """
    機能: 同じ保存モデルを再読込し、独立74列から全originを再推論する。
    引数: model(dict)、current(list)、saved(dict)は保存予測索引。
    返り値: tupleは再計算票・最大確率差・照合確率数・実使用系統。
    """
    ref = model['model_ref']; loaded = None; usedfamilies = []
    if ref is not None:
        exported = load(Path(ref['path']),ref['sha256'])
        flat = exported['model_info']['params']['flat_params']
        assert flat == PARAMS
        assert len(exported['oblivious_trees']) == 128
        floats = {v['feature_index']:v for v in exported['features_info']['float_features']}
        names = set()
        for tree in exported['oblivious_trees']:
            for split in tree.get('splits') or []:
                assert split['split_type'] == 'FloatFeature'
                f = floats[split['float_feature_index']]
                assert f['feature_id'] == NAMES[f['flat_feature_index']]
                names.add(f['feature_id'])
        usedfamilies = sorted({family(n) for n in names})
        assert ref['used_features'] == sorted(names) and ref['used_technical_families'] == usedfamilies
        assert model['training']['used_split_families']['used_features'] == sorted(names)
        assert model['training']['used_split_families']['used_technical_families'] == usedfamilies
        assert (len(usedfamilies)>=2) is (model['status']=='active')
        loaded = CatBoostClassifier(); loaded.load_model(ref['path'],format='json')
        assert list(loaded.classes_) == [0,1,2] and list(loaded.feature_names_) == NAMES
    vectors, targets, votes = [],[],{}
    for f in current:
        pred = saved[f['id']]
        assert all(pred[k] == f[k] for k in ('id','session','native_side','baseline'))
        assert pred['model_status'] == model['status'] and pred['model_ref'] == ref
        assert len(pred['origins']) == len(f['origins'])
        votes[f['id']] = []
        for o,p in zip(f['origins'],pred['origins']):
            assert all(o[k] == p[k] for k in ('query_id','origin_index'))
            if f['baseline'] or model['status'] != 'active':
                expected = 'protected_baseline' if f['baseline'] else model['status']
                assert p['probabilities'] is None and p['selected_side'] == f['native_side'] and p['fallback'] == expected
                votes[f['id']].append(p.copy())
            else:
                vectors.extend((vector(o['values'],False),vector(o['values'],True)))
                targets.append((f,p))
    maximum, cells = 0.,0
    if vectors:
        prob = loaded.predict_proba(vectors).tolist()
        for i,(f,p) in enumerate(targets):
            a,b = prob[2*i],prob[2*i+1]
            assert all(math.isfinite(x) and 0<=x<=1 for row in (a,b) for x in row)
            assert all(abs(sum(row)-1)<1e-9 for row in (a,b))
            sa,sb = a[2]-a[0],b[2]-b[0]; side = -f['native_side'] if sb-sa>1e-12 else f['native_side']
            expected = {'native_probabilities':a,'reverse_probabilities':b,'native_score':sa,'reverse_score':sb,
                        'tie':abs(sa-sb)<=1e-12,'selected_side':side}
            got = p['probabilities']; assert got['tie'] == expected['tie'] and got['selected_side'] == side
            for key in ('native_probabilities','reverse_probabilities'):
                for x,y in zip(got[key],expected[key]):
                    maximum = max(maximum,abs(x-y)); assert abs(x-y)<=1e-12; cells += 1
            for key in ('native_score','reverse_score'): assert abs(got[key]-expected[key])<=1e-12
            assert p['selected_side'] == side and p['fallback'] is None
            votes[f['id']].append({**p,'probabilities':expected,'selected_side':side})
    return votes,maximum,cells,usedfamilies


# ----------------------------------------
def main() -> None:
    """
    機能: Root許可済み143自然保存物だけで全方向と学習因果を照合する。
    引数: なし。Raw/CSV・追加2場・自然再学習は使わない。
    返り値: None。独立検算JSONだけを自己専有先へ保存する。
    """
    assert catboost.__version__ == '1.2.10'
    assert len(NAMES) == 74 and len({family(n) for n in NAMES}) == 8
    f0 = load(RUN/'F0学習前.json','f00c2a5e19fcad802cb75286a73e76f4612ea15b3b7aa52618ad85919a7bee5c')
    f1 = load(RUN/'F1予測固定後.json','c0a2d1e8032cbb06bcdef11f3c707a2998225f44c416fe7b0a683ebc2312545c')
    assert f1['F0_SHA256'] == sha(RUN/'F0学習前.json')
    author = load(SOURCE/'準備の確認.json','baa2a36e140e8984b62b50f9d48c8793569cf278985bca7cf810bf8d2a3c111d')
    for path,h in author['ローカル13源'].items():
        assert sha(Path(path)) == h == f0['ファイル'][path] == f1['ファイル'][path]
        READ[path] = h
    choices = load(RUN/'学習予測/全752の方向.json','b3bb4faffd6622d15a6eb3f48156a7c8082ee11c32aec1863ec167f36aedc107')
    prediction = load(Path(choices['predictions_path']),choices['predictions_sha256'])
    modeldoc = load(Path(choices['models_manifest_path']),choices['models_manifest_sha256'])
    labels = load(Path(choices['labels_manifest_path']),'ff30882dfa64f6450224ec6423c6660d47a4ffe3cbda1f75a8a8d8e69842d930')
    manifest = load(ROOT/'work/全成立poolの非金融manifest/manifest.json','e7ba444fd66f9ca52e10e929eeb31d21076f97afa161de738dabca14a8ff8e35')
    queries = load(ROOT/'work/138全成立入口の評価/固定入力_版2/特徴照会.json','81442c3ebaa3065213d0844417bb0462cfa3e5d0a05c4f44edfb3fb14191e75c')
    features = load(ROOT/'work/138全成立入口の評価/全出生の当時特徴.json','c2b9b8efeb65ba22b2dac3147fdefa3b513cb5cc61cd69249864065f2fcca6e4')
    cohort, entry_origins, sessions = join(manifest,queries,features)
    assert choices['entry_origins'] == entry_origins
    observed = load(ROOT/'work/138全成立入口の評価/固定取得の正逆観測.json','d272fc6f6768342ff67e1a9ec58b0b7307a0a5b07cc215ba5ff7bcb50865b742')
    fixed = load(ROOT/'work/138全成立入口の評価/固定入力_版2/固定取得入力.json','0c83e525dec3079ce188d942069c0d137c94f39009339752ec8227ec9ecb4ce7')
    docs = teachers(observed,fixed,labels,cohort,sessions)
    assert modeldoc['models'] == prediction['models'] and len(modeldoc['models']) == 73
    assert prediction['feature_names'] == NAMES and choices['sessions'] == prediction['sessions'] == sessions
    pby = {r['id']:r for r in prediction['rows']}; cby = {r['id']:r for r in choices['rows']}
    fby = {r['id']:r for r in cohort}; assert set(pby) == set(cby) == set(fby) and len(pby) == 752
    audits, replay, counts, kinds, maxdiff, cells = [],[],Counter(),Counter(),0.,0
    for i,model in enumerate(modeldoc['models']):
        audit = audit_prefix(i,model,docs,fby,sessions)
        current = [r for r in cohort if r['session'] == sessions[i]]
        votes,diff,n,used = replay_model(model,current,pby)
        maxdiff = max(maxdiff,diff); cells += n
        for f in current:
            row = cby[f['id']]; originvotes = votes[f['id']]
            sides = {v['selected_side'] for v in originvotes}; agree = len(sides)==1
            side = next(iter(sides)) if agree else f['native_side']
            fallback = ('protected_baseline' if f['baseline'] else model['status'] if model['status']!='active' else
                        'origin_direction_conflict' if not agree else None)
            kind = ('baseline' if f['baseline'] else 'seed' if model['status']=='warmup8' else
                    'insufficient_training' if model['status'] in ('insufficient_complete32','missing_three_classes') else
                    'single_tech' if model['status']=='fewer_than_two_technical_families' else 'origin_conflict' if not agree else 'none')
            applied = not f['baseline'] and model['status']=='active' and agree
            if f['baseline']: side = f['native_side']
            expected = {'id':f['id'],'session':f['session'],'native_side':f['native_side'],'selected_side':side,
                        'baseline':f['baseline'],'flip':side!=f['native_side'],'action':'flip' if side!=f['native_side'] else 'keep',
                        'reason':fallback or '過去場モデルの全origin方向一致','fallback':fallback,'model_status':model['status'],
                        'model_ref':model['model_ref'],'model_applied':applied,'fallback_kind':kind,'all_origins_agree':agree,
                        'origin_query_ids':[v['query_id'] for v in originvotes],'origin_count':len(originvotes)}
            for key,value in expected.items(): assert row[key] == value,(f['id'],key)
            assert len(row['origins']) == len(originvotes)
            for a,b in zip(row['origins'],originvotes):
                assert a['query_id'] == b['query_id'] and a['selected_side'] == b['selected_side']
                assert a['probabilities'] == pby[f['id']]['origins'][a['origin_index']]['probabilities']
            counts[expected['action']] += 1; kinds[kind] += 1
            replay.append({'id':f['id'],'side':side,'model_applied':applied,'fallback_kind':kind})
        audit.update({'current_cases':len(current),'prediction_probability_cells':n,'max_probability_difference':diff,
                      'actual_split_families':used})
        audits.append(audit)
        if i in (8,24,48,72): print(json.dumps({'確認済み場':i+1,'最大確率差':maxdiff},ensure_ascii=False),flush=True)
    assert dict(counts) == choices['counts'] == {'keep':454,'flip':298}
    assert Counter(m['status'] for m in modeldoc['models']) == {'active':64,'warmup8':8,'insufficient_complete32':1}
    assert sum(r['model_applied'] for r in replay) == 631
    assert all(sha(Path(p)) == h for p,h in READ.items())
    for path,h in READ.items():
        if path not in (str((RUN/'F0学習前.json').resolve()),str((RUN/'F1予測固定後.json').resolve())):
            assert f1['ファイル'][path] == h, path
    report = {'成功':True,'試行':143,'作者関数import':False,'独立再学習':False,
              'Raw価格CSV追加2場読取':False,'重大差':[],
              '確認':{'全場':73,'場別教師':73,'教師canonical':752,'全入口':833,'全由来':850,'一意出生':769,
                      'モデル保存JSON':64,'過去prefix監査':65,'初8場未学習':8,'全74列鏡像出生':769,
                      '保護81':81,'全752方向一致':True,'model_applied':631,'flip':298,'keep':454,
                      '予測確率セル':cells,'同JSON再推論最大差':maxdiff,'全必要源前後SHA一致':True,
                      'モデルstatus':dict(Counter(m['status'] for m in modeldoc['models'])),'fallback_kind':dict(kinds)},
              '限界':['保存JSONに学習入力の全数値や各行重み自体は格納されない。固定コードの過去prefix渡しと保存auditを独立再構成して照合した。',
                      '同一モデルの再推論同体を確認し、GUID/学習時計を含む再学習SHA同体は要求せず再学習もしない。',
                      '全期は既使用。各場のモデルがそれ以前だけを学習することと、独立未知期での成績は別。',
                      '反転方向の新しい注文構造は再構築していない。'],
              '場別監査':audits,'入出力SHA256':READ,'自検算コードSHA256':sha(Path(__file__)),'編集停止':True}
    output = OWN/'独立検算.json'; assert not output.exists()
    output.write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'検算SHA256':sha(output),'再推論最大差':maxdiff,'確率セル':cells},ensure_ascii=False))


if __name__ == '__main__':
    main()
