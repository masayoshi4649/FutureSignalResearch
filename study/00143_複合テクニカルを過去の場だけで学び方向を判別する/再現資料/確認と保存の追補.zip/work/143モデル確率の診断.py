"""143の固定方向と確率を事後診断する。閾値を新政策へ採用しない。"""
from pathlib import Path
from collections import Counter
import hashlib
import importlib.util
import json


def main() -> None:
    """
    機能: 変更群の先着行列と予測確率/両方向差の区分を再集計する。
    引数: なし。143の固定方向票と138保存正逆を使う。
    返り値: None。既存の診断があれば同体を照合し、原板やモデルを再計算しない。
    """
    root = Path(__file__).resolve().parent.parent
    own = root/'work/143逐次判別の評価'
    paths = [own/'学習予測/全752の方向.json',root/'work/138全成立入口の評価/固定取得の正逆観測.json']
    fingerprints = {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    directions = json.loads(paths[0].read_bytes());observed = json.loads(paths[1].read_bytes())
    cases = {c['id']:(s['session'],c) for s in observed['scenes'] for c in s['cases']}
    spec = importlib.util.spec_from_file_location('診断用独立算術',root/'work/141金融集計を独立に確認する.py')
    arithmetic = importlib.util.module_from_spec(spec);spec.loader.exec_module(arithmetic)
    rows, matrix = [], Counter()
    for row in directions['rows']:
        sid,case = cases[row['id']];flip = row['selected_side'] != case['original_side']
        stream = case['reverse' if flip else 'original']
        a,b = case['original']['outcomes'][1],stream['outcomes'][1]
        if flip:
            matrix[(next(t['direction'] for t in a['touches'] if t['width']==125) if a['status']=='complete' else '不足',
                    next(t['direction'] for t in b['touches'] if t['width']==125) if b['status']=='complete' else '不足')] += 1
        if not row['model_applied']: continue
        probabilities = [o['probabilities'] for o in row['origins']]
        forward = min(p['reverse_probabilities' if flip else 'native_probabilities'][2] for p in probabilities)
        margin = min(abs(p['native_score']-p['reverse_score']) for p in probabilities)
        rows.append((forward,margin,sid,{'original':stream}))
    result = {'成功':True,'試行':143,'性質':'事後診断、閾値を新政策へ採用しない',
        '全変更行列':{str(k):v for k,v in matrix.items()},'モデル適用':len(rows),
        '予測順確率':{},'両方向score差':{},'入力':fingerprints}
    # ----------------------------------------
    # originのうち最も小さい確率/差で区分し、有利な出生を選ばない。
    for name,edges,key in [('予測順確率',[0,.5,.6,.7,.8,1.000001],0),('両方向score差',[0,.1,.2,.4,.6,2.000001],1)]:
        for lower,upper in zip(edges,edges[1:]):
            selected = [(r[2],r[3]) for r in rows if lower<=r[key]<upper]
            result[name][f'{lower}以上{upper}未満'] = arithmetic.calculate(selected,False,'BBO',3600,125)
    assert all(hashlib.sha256(p.read_bytes()).hexdigest()==fingerprints[str(p)] for p in paths)
    output = own/'モデル確率と変更群の事後診断.json'
    if output.exists(): assert json.loads(output.read_bytes()) == result
    else:
        with output.open('x',encoding='utf-8',newline='\n') as out:json.dump(result,out,ensure_ascii=False,indent=2);out.write('\n')
    print(json.dumps({'成功':True,'診断SHA256':hashlib.sha256(output.read_bytes()).hexdigest()},ensure_ascii=False))


if __name__ == '__main__':
    main()
