"""旧73・追加7・本日1を、純基準の封印と固定金融接続へ分けて共用する。"""
from pathlib import Path
from types import SimpleNamespace
from contextlib import contextmanager
from functools import lru_cache
import argparse
import hashlib
import json
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'work/179保有参加の探索'))
import 探索179 as P
import 基盤179 as M

LEGS = ('旧73', '追加7', '本日1')
ALIASES = {'old73': '旧73', 'add7': '追加7', 'today1': '本日1'}
BASELINES = ('全期_J035', '旧178_新時計')
BIRTH_KEYS = ('core', 'branches', 'technical', 'tier')
PARAM_KEYS = ('mw', 'fw', 'hi', 'added')
OVERLAY = ROOT / 'inputs/00179_終了前決済の共用数値表'
TODAY = ROOT / 'work/180本日デイ適用'
INPUT_TODAY = ROOT / 'inputs/00180_20261116デイの固定適用入力'


def normalize(leg: str) -> str:
    """
    機能: 三つの期間名と短い別名を正規化する。
    引数: leg(str)は旧73/追加7/本日1又はold73/add7/today1。
    返り値: strは正式な期間名。
    """
    result = ALIASES.get(leg, leg)
    assert result in LEGS, result
    return result


def ref(path: Path) -> dict:
    """
    機能: 大きな原板を複製せず、リポジトリ内入力の指紋だけを記録する。
    引数: path(Path)は参照ファイル。
    返り値: dictは相対path・bytes・sha256。
    """
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size, 'sha256': digest}


def feature_sha(features: object) -> str:
    """
    機能: 金融を含まない100特徴・q0・場順の意味内容を同体照合する。
    引数: features(FeatureDataset互換)は既存の純特徴。
    返り値: strは列・メタデータと両実側特徴のSHA256。
    """
    digest = hashlib.sha256()
    metadata = {'columns': list(features.columns), 'q0': features.q0_meta, 'scenes': features.scenes}
    digest.update(json.dumps(metadata, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8'))
    for value in (features.buy_X, features.sell_X, features.q0_timeband):
        array = np.ascontiguousarray(value)
        digest.update(str(array.dtype).encode('ascii'))
        digest.update(json.dumps(array.shape).encode('ascii'))
        digest.update(array.tobytes())
    return digest.hexdigest()


@contextmanager
def temporary(**values: object):
    """
    機能: 旧179のmodule大域を一つの同期呼出し中だけ差し替え、必ず戻す。
    引数: values(dict[str,object])は一時設定するCTX/CAPS/compose等。
    返り値: contextmanagerは処理後に旧状態を復元する。並列は別processで使う。
    """
    previous = {key: getattr(P, key) for key in values}
    try:
        for key, value in values.items():
            setattr(P, key, value)
        yield
    finally:
        for key, value in previous.items():
            setattr(P, key, value)


def policies(leg: str) -> dict:
    """
    機能: 固定179主と同じ終了時計の旧178対照だけを取り出す。
    引数: leg(str)は正規化済み期間名。
    返り値: dictは共通API名から元の固定policyへの対応。
    """
    fixed = P.B.P.read(ROOT / 'work/179保有参加の探索/旧73の固定選択.json')
    main = next(row for row in fixed['選択']['全期']['candidates'] if row['id'] == '全期_J035')
    if leg == '本日1':
        condition = P.B.P.read(ROOT / 'study/00180_固定179入口を十一月十六日デイへ適用する/条件.json')
        assert main == condition['主政策']
        contrast = {'id': '旧178_新時計', 'route': '固定対照', '説明': condition['対照']}
    else:
        contrast = {'id': 'C178_全期_J002_J000_K012', 'base': '178/全期_J002_J000_K012', 'route': '全期', 'changes': {}}
    return {'全期_J035': main, '旧178_新時計': contrast}


def indices(leg: str, features: object) -> dict:
    """
    機能: 既存48byte価格索引のmanifestと場別参照だけを共通形式へ整える。
    引数: leg(str)、features(FeatureDataset互換)。
    返り値: dictはmanifest指紋と場順に並べたsession/path/sha256/rows。
    """
    folders = {'旧73': ROOT / 'inputs/00163_任意幅の共用価格索引/価格索引',
        '追加7': ROOT / 'inputs/00167_追加七場の入口と共用価格索引/原板数値索引',
        '本日1': INPUT_TODAY / '原板数値索引'}
    folder = folders[leg]
    manifest_path = folder / 'manifest.json'
    manifest = P.B.P.read(manifest_path)
    assert manifest['success'] and [row['session'] for row in manifest['scenes']] == [row['session'] for row in features.scenes]
    rows = []
    for row in manifest['scenes']:
        path = folder / row['index']['path']
        assert path.parent == folder and path.is_file()
        rows.append({'session': row['session'], 'contract': row['contract'], 'path': path.relative_to(ROOT).as_posix(),
            'sha256': row['index']['sha256'], 'rows': row['rows']})
    return {'manifest': ref(manifest_path), 'scenes': rows}


def pure_baselines(leg: str, features: object) -> dict:
    """
    機能: 将来価格・金融表を読まず、固定部品から基準2案を同じcomposeで作る。
    引数: leg(str)、features(FeatureDataset互換)は当時情報だけ。
    返り値: dictは各案のbirth/mw/fw/hi/added。旧固定元配列は変更しない。
    """
    if leg == '本日1':
        builder = P.B.P.module(TODAY / '純方向180.py', 'pure180_for181')
        result = builder.build(features)
    else:
        base_id = '全期_J002_J000_K012'
        with np.load(ROOT / f'work/178追加七場適用/{leg}の純出生178.npz', allow_pickle=False) as sealed:
            assert np.array_equal(sealed['phases'], features.q0_timeband)
            base = {key: sealed[base_id + '__' + key].copy() for key in BIRTH_KEYS + ('mw', 'fw', 'hi')}
        proof = P.B.P.read(ROOT / f'work/179保有参加の探索/{leg}の純出生179.json')
        with np.load(ROOT / f'work/179保有参加の探索/{leg}の純出生179.npz', allow_pickle=False) as sealed:
            assert np.array_equal(sealed['phases'], features.q0_timeband)
            matrix = sealed['directions']
        directions = {identity + '/' + orientation: matrix[i] if orientation == 'NORMAL' else -matrix[i]
            for i, identity in enumerate(proof['候補順']) for orientation in ('NORMAL', 'REVERSE')}
        axes = P.B.P.read(ROOT / 'work/163任意幅Raw索引/観測条件の雛形.json')
        pure_context = SimpleNamespace(event_phases=features.q0_timeband,
            table=SimpleNamespace(horizons=[row['id'] for row in axes['horizons']]))
        result = {}
        with temporary(CTX=pure_context, DIRS=directions, SEALS={'178/' + base_id: base}):
            for name, policy in policies(leg).items():
                birth, mw, fw, hi, added = P.compose(policy)
                result[name] = {'birth': birth, 'mw': mw, 'fw': fw, 'hi': hi, 'added': added}
    assert set(result) == set(BASELINES)
    for bundle in result.values():
        for array in list(bundle['birth'].values()) + [bundle[key] for key in PARAM_KEYS]:
            assert len(array) == len(features.q0_meta)
            array.setflags(write=False)
    return result


@lru_cache(maxsize=3)
def load_pure_leg(leg: str) -> dict:
    """
    機能: 三期間を共通APIへ接続し、金融未読の純特徴・固定基準を返す。
    引数: leg(str)は期間名。別名も可。
    返り値: dictは軽量context/features/baselines/price_index/scene_masks/proof。
    """
    leg = normalize(leg)
    P.verify()
    if leg == '旧73':
        features = P.B.P.R168.BASE.data_module().load_feature_dataset()
        captures = P.B.P.read(ROOT / 'inputs/00148_全1分入口母集団/取得対応.json.gz')['rows']
    elif leg == '追加7':
        features, captures, _ = P.B.P.R168.BASE.load_features(ROOT / 'inputs/00167_追加七場の入口と共用価格索引/入口母集団')
    else:
        source = P.B.P.module(TODAY / '入力180.py', 'input180_for181')
        loaded = source.load_context()
        assert not loaded['context'].arrays['known'].any()
        features = loaded['features']
        captures = loaded['context'].capture_rows
    n = len(features.q0_meta)
    scene_count = len(features.scenes)
    assert scene_count == {'旧73': 73, '追加7': 7, '本日1': 1}[leg]
    axes = P.B.P.read(ROOT / 'work/163任意幅Raw索引/観測条件の雛形.json')
    context = SimpleNamespace(features=features, scenes=features.scenes,
        sessions=[row['session'] for row in features.scenes], capture_rows=captures,
        event_phases=np.asarray(features.q0_timeband),
        event_scenes=np.asarray([row['session_index'] for row in features.q0_meta], dtype=np.int16),
        event_keys=[(row['q0_time'], row['q0_index'], row['q0_line']) for row in features.q0_meta],
        table=SimpleNamespace(widths=tuple(axes['widths']), horizons=tuple(row['id'] for row in axes['horizons'])),
        arrays={}, financial_attached=False)
    scene_masks = {'全対象': np.ones(scene_count, bool)}
    for name in ('前48', '後25', '追加7', '本日1'):
        scene_masks[name] = np.zeros(scene_count, bool)
    if leg == '旧73':
        scene_masks['前48'][:48] = True
        scene_masks['後25'][48:] = True
    else:
        scene_masks[leg][:] = True
    result = {'leg': leg, 'context': context, 'features': features,
        'baselines': pure_baselines(leg, features), 'price_index': indices(leg, features),
        'scene_masks': scene_masks, 'event_scene': context.event_scenes,
        'proof': {'成功': True, '金融未入力': True, 'features_sha256': feature_sha(features), 'q0': n,
            '場数': scene_count, '開始待機': 0, '終了時計': '179固定のcut/submit'}}
    return result


def seal_pure_leg(pure: dict, output_dir: Path | None = None) -> dict:
    """
    機能: 基準純出生を金融表接続前に共用NPZ/JSONへ一度封印する。
    引数: pure(dict)はload_pure_legの返り値、output_dir(Path|None)は既定cache。
    返り値: dictは封印ファイル指紋・特徴指紋。既存時は全配列同体を確認する。
    """
    output_dir = HERE / 'cache' if output_dir is None else Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    target = output_dir / (pure['leg'] + '_純基準181.npz')
    values = {}
    for name, bundle in pure['baselines'].items():
        values.update({name + '__' + key: value for key, value in bundle['birth'].items()})
        values.update({name + '__' + key: bundle[key] for key in PARAM_KEYS})
    values['phases'] = pure['context'].event_phases
    values['event_scene'] = pure['event_scene']
    if target.exists():
        with np.load(target, allow_pickle=False) as sealed:
            assert set(sealed.files) == set(values)
            for key, value in values.items():
                np.testing.assert_array_equal(sealed[key], value)
    else:
        np.savez_compressed(target, **values)
    body = {'成功': True, '金融未入力': True, 'leg': pure['leg'], '純入力': pure['proof'],
        'NPZ': ref(target), 'Source': ref(Path(__file__)), '価格索引': pure['price_index']}
    metadata = target.with_suffix('.json')
    if metadata.exists():
        assert P.B.P.read(metadata) == body
    else:
        P.B.P.save(metadata, body)
    pure['sealed'] = {'npz': ref(target), 'metadata': ref(metadata)}
    return pure['sealed']


def case_mapping(context: object, index: dict) -> dict:
    """
    機能: 物理caseから場・限月・場内case番号・原価格索引位置への対応を作る。
    引数: context(GenericContext)、index(dict)は既存索引の場順参照。
    返り値: dictはcase_ids/scene/contract/local_case/entry_index等のcase順対応。
    """
    scene = np.asarray(context.case_scene, dtype=np.int32)
    local = np.empty(len(scene), dtype=np.int32)
    contracts = []
    for si, row in enumerate(index['scenes']):
        assert context.sessions[si] == row['session']
        values = {q['contract'] for q in context.features.q0_meta if q['session_index'] == si}
        assert not values or values == {row['contract']}, ('単一場内の限月混在は別索引対応が必要', si, values)
        cases = np.flatnonzero(scene == si)
        local[cases] = np.arange(len(cases), dtype=np.int32)
        contracts.append(row['contract'])
    return {'case_ids': tuple(context.table.case_ids), 'scene': scene,
        'contract': tuple(contracts[int(si)] for si in scene), 'local_case': local,
        'entry_index': np.asarray(context.arrays['entry_index'], dtype=np.int64),
        'entry_time': np.asarray(context.arrays['entry_time'], dtype=np.float64),
        'entry_line': np.asarray(context.arrays['entry_line'], dtype=np.int64),
        'entry_price': np.asarray(context.arrays['entry_price'], dtype=np.float64),
        'scene_index_refs': index['scenes']}


def attach_financial(pure: dict) -> dict:
    """
    機能: 純基準封印後に、保存済み179/180金融だけを既存Contextへ付与する。
    引数: pure(dict)はseal_pure_leg実行済みの純期間。
    返り値: dictはGenericContext/capturesを追加した共通期間。純配列を全件照合する。
    """
    assert 'sealed' in pure
    assert ref(ROOT / pure['sealed']['npz']['path']) == pure['sealed']['npz']
    leg = pure['leg']
    if leg == '本日1':
        source = P.B.P.module(TODAY / '入力180.py', 'input180_for181')
        loaded = source.load_context()
        context = loaded['context']
        early = P.B.P.module(ROOT / 'work/179終了前決済/early179.py', 'early179_for181')
        metadata = P.B.P.read(TODAY / '終了前金融の接続.json')
        assert metadata['価格索引']['sha256'] == loaded['index_ref']['sha256']
        assert metadata['overlay'] == ref(TODAY / '本日の終了前金融.npz')
        assert metadata['金融Source'] == ref(Path(early.__file__))
        with np.load(TODAY / '本日の終了前金融.npz', allow_pickle=False) as raw:
            context.arrays.update({key: raw[key].copy() for key in raw.files})
        original = M.B.load_context
        try:
            M.B.load_context = lambda new=False: context
            context = M.load_context()
        finally:
            M.B.load_context = original
    else:
        with temporary(CTX=P.CTX, CAPS=P.CAPS, DIRS=P.DIRS, SEALS=P.SEALS):
            P.initialize(leg == '追加7')
            context = P.CTX
            for name, policy in policies(leg).items():
                values = P.compose(policy)
                expected = pure['baselines'][name]
                for key in BIRTH_KEYS:
                    np.testing.assert_array_equal(values[0][key], expected['birth'][key])
                for value, key in zip(values[1:], PARAM_KEYS, strict=True):
                    np.testing.assert_array_equal(value, expected[key])
        early = P.B.P.module(ROOT / 'work/179終了前決済/early179.py', 'early179_for181')
        checked = early.load_overlay(context, leg == '追加7', OVERLAY)
        for key in ('known', 'net', 'label', 'exit_time'):
            np.testing.assert_array_equal(checked['arrays'][key], context.arrays[key])
    assert feature_sha(context.features) == pure['proof']['features_sha256']
    assert context.sessions == pure['context'].sessions
    assert context.event_keys == pure['context'].event_keys
    context.financial_attached = True
    return {**pure, 'context': context, 'captures': M.B.captures(context), 'financial_attached': True,
        'case_index': case_mapping(context, pure['price_index'])}


def load_leg(leg: str, output_dir: Path | None = None) -> dict:
    """
    機能: 純生成・基準封印・固定金融付与をこの順でまとめて行う便宜API。
    引数: leg(str)、output_dir(Path|None)は純基準cache先。
    返り値: dictは同じ共通期間API。
    """
    pure = load_pure_leg(normalize(leg))
    seal_pure_leg(pure, output_dir)
    return attach_financial(pure)


@lru_cache(maxsize=2)
def load_records(leg: str, session: str) -> np.ndarray:
    """
    機能: 一場の既存48byte索引を全CRC/SHA付きで遅延読込する。
    引数: leg(str)、session(str)。原板の走査や複製は行わない。
    返り値: np.ndarrayは時刻・原行・価格・Bid/Ask・normalの構造化配列。
    """
    pure = load_pure_leg(normalize(leg))
    row = next(row for row in pure['price_index']['scenes'] if row['session'] == session)
    helper = P.B.P.module(ROOT / 'work/163任意幅の数値化/arrays163.py', 'records163_for181')
    result = helper.load_records(ROOT / row['path'], row['sha256'], row['rows'])
    result.setflags(write=False)
    return result


def baseline_pack(loaded: dict, name: str) -> dict:
    """
    機能: 共用基準を旧179packと同じSourceで再生する。新手法は評価しない。
    引数: loaded(dict)は金融接続済み期間、name(str)は基準2案の共通名。
    返り値: dictは元の固定政策IDを保持した全台帳・保有・金融pack。
    """
    assert loaded['financial_attached'] and name in BASELINES
    fixed = P.B.P.module(ROOT / 'work/179保有参加の探索/固定結果を作る.py', 'fixed179_for181')
    bundle = loaded['baselines'][name]
    def compose(policy: dict) -> tuple:
        """
        機能: 今回の封印済み基準配列を固定再生器へ渡す。
        引数: policy(dict)は元の固定政策。
        返り値: tupleはbirth/mw/fw/hi/added。
        """
        return tuple(bundle[key] for key in ('birth',) + PARAM_KEYS)
    with temporary(CTX=loaded['context'], CAPS=loaded['captures'], compose=compose):
        result = fixed.pack(policies(loaded['leg'])[name], loaded['leg'] != '旧73')
    if loaded['leg'] == '本日1':
        cases = np.asarray(result['selection']['cases'], dtype=np.int64)
        result['ledger']['entry_line'] = loaded['context'].arrays['entry_line'][cases].tolist()
        result['ledger']['entry_index'] = loaded['context'].arrays['entry_index'][cases].tolist()
    return result


def verify_fixed_baselines() -> dict:
    """
    機能: 全81場の基準2案を旧固定packへ全辞書同体で照合する。
    引数: なし。
    返り値: dictは6候補期間の不一致0票。探索・順位付けは実施しない。
    """
    checks = []
    for leg in LEGS:
        loaded = load_leg(leg)
        source = TODAY / '本日の固定結果.json.gz' if leg == '本日1' else ROOT / f'work/179保有参加の探索/{leg}の固定全取得179.json.gz'
        expected = {row['id']: row for row in P.B.P.read(source)['rows']}
        for name in BASELINES:
            result = baseline_pack(loaded, name)
            assert result == expected[result['id']], (leg, name)
            checks.append({'leg': leg, '基準': name, '元policy': result['id'], '全pack同体': True,
                '取得数': len(result['ledger']['net']), '純基準': loaded['sealed']})
    body = {'成功': True, '探索なし': True, '場数': 81, '政策数': 2,
        '全候補期間数': len(checks), '照合': checks, 'Source': ref(Path(__file__))}
    P.B.P.save(HERE / '基準二案の全81場同体確認.json', body)
    return body


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--verify-fixed', action='store_true')
    args = parser.parse_args()
    if args.verify_fixed:
        print(json.dumps(verify_fixed_baselines(), ensure_ascii=False))
