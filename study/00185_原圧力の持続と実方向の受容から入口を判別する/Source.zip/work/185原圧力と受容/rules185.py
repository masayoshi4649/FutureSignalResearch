"""185の純入口。元圧力の代理指標と固定価格側の持続受容を分ける。"""
from pathlib import Path
import hashlib
import json
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work/183入口候補'))
import rules183 as P

VERSION='185固定価格側の持続受容1'
PROFILES={
 'C60':{'observations':2,'seconds':60,'penetration_atr':.10,'volume_each':.5,'volume_mean':.75},
 'C120':{'observations':3,'seconds':120,'penetration_atr':.10,'volume_each':.5,'volume_mean':.75},
 'V120':{'observations':3,'seconds':120,'penetration_atr':.20,'volume_each':.75,'volume_mean':1.},
}
FAMILIES={'TA':'順行押戻し後の受容とDI/MA拡散','FA':'固定突破失敗後の反対側受容','RA':'元圧力失速と短期転換後の受容'}
RAW_COLUMNS=tuple(sorted(set(P.RAW_COLUMNS)|{'m5_gap_to_side'}))


def catalog() -> dict:
    """
    機能: 固定2対照と3構造×3持続×2統合の20候補を定義する。
    引数: なし。
    返り値: dictは全閾値・時計・未知・心理仮説の金融前辞書。
    """
    rules=[{'id':'E185_00','control':'E183_00','family':'CONTROL','description':'旧179基準・単純IFD'},
           {'id':'E185_01','control':'E183_04','family':'CONTROL','description':'183の単発EMA回復ADD・固定対照'}]
    for family in FAMILIES:
        for profile in PROFILES:
            for mode in ('ADD','GUARD'):
                rules.append({'id':f'E185_{len(rules):02d}','family':family,'profile':profile,'mode':mode,
                    'description':FAMILIES[family]+'／'+profile+'／'+mode,'setup_seconds':1800})
    return {'version':VERSION,'candidate_count':20,'rules':rules,'profiles':PROFILES,'raw_columns':list(RAW_COLUMNS),
      'common':'正常q0価格・ATR5>0、spread>0かつ<=20、q0Last−1分終値絶対値<=1ATR5、現在entry−EMA8は−.5〜1.5ATR5、1分TR/ATR5<=2.5・5分TR/前ATR<=4。必要値既知。',
      'acceptance':'同じ絶対水準の実方向側>=0で開始。q0で観測した最大逆側侵入がprofile上限以内で、異なる秒の正常q0数・実秒・相対量各値/平均を満たす。実発火時の側距離>=.1ATRかつ開始価格からの実進行>=.1ATR。',
      'acceptance_reset':'q0間隔90秒超・不正常q0・量未知/下限未達・許容侵入超で受容をやり直す。setup水準と期限は延長しない。場/限月/時計後退/180秒超gapではsetupも消す。',
      'same_second':'同秒原行は観測数・量平均へ追加しない。価格侵入/正常性/量不足の無効化だけ反映。実秒経過を同秒行数で水増ししない。',
      'TA':'5分EMA21傾き>=0、15又は30分のEMA21/DIが両正、現在EMA8近辺−1〜.25ATR、量>=.5を種に固定EMA8を記憶。発火は5分DI>0・EMA8/21差>0、種よりDI又はMA差が拡大、5分Hist/RSI増分が両非負で一方正、1分構造を要す。',
      'FA':'元方向の3本端突破>.25ATR、5分実体>=.4・Hist/RSI増分両正・量>=.75を種に固定端を記憶。反対側が受容した後、元DIが種より低下しHist増分又はEMA傾きも低下、実方向DI又はMA差>0・標準動力・1分構造を確認。',
      'RA':'元方向の5分EMA/DIと15又は30分EMA/DIが両正、ADX15>=20、Hist/RSI増分両正・量>=.75から観測ピークを記憶。反対へ.35ATR戻った最初のq0で反転水準を固定し受容を開始。元DI/Hist失速・実方向短期転換・標準動力・1分構造と、ADX15増分<=0又は実方向15分Hist増分>=0を要す。',
      'pressure_proxy':'EMA/DI・実価格進行・相対量の代理。5分と長期一足の両整合・動力・MA差が持続し、固定EMA8側の受容をprofile条件で確認したもの。継続圧力状態には30分setup期限を課さず、現在の方向要件が壊れるか共通resetまで同じ水準を維持する。受容部分の90秒/量/侵入resetは適用する。板数量・完全OFI・注文吸収の直接測定ではない。',
      'ADD':'旧core優先、LC保持。新受容の発火をcore=0のq0に追加。新たな保有が後続取得を変える。',
      'GUARD':'逆側の持続圧力代理が成立した旧要求だけ保留。自動反転せず、同じ実方向の当該構造受容が後刻出た時だけ元幅期限で再要求。独立新構造は足さない。その他旧幹/Tは保持。',
      'width':'単純IFDの幅・期限を変更しない。ADDは構造setup、GUARDは元保留要求のmw/fw/hiを記憶。LC added=Trueを保持し、新規/延期受容はadded=Falseで診断区分を別記。',
      'state':'TA/FA/RAのsetupと保留要求は30実分。継続圧力状態はpressure_proxyに従い別扱い。同方向で期限延長せず、発火は一度。両方向競合は待ち。新しい通常旧coreが出たら古い保留要求を取消。取得可否や損益は純状態へ戻さない。',
      'limits':['価格側の保持と最大侵入はq0で観測した範囲。q0間の原板全行で逆行がなかったとは証明しない。',
        '相対量平均はq0観測値の算術平均。完全な約定フローの合計ではない。',
        '全81場は既使用。新185金融前の仮説固定であり未見検証ではない。',
        '一つの回復と持続受容を分ける研究仮説で、成立数や人工成功は利益・損失の証明ではない。']}


def _prepare(features: object) -> tuple:
    """
    機能: 183の純価格・時計へMA差を追加する。
    引数: features(FeatureDataset互換)。
    返り値: tupleは側別列・q0・秒・帯・reset・価格。
    """
    arrays,meta,times,phases,reset,prices=P._prepare(features)
    cols=[c['name'] if isinstance(c,dict) else c for c in P._get(features,'columns')]
    assert set(RAW_COLUMNS)<=set(cols)
    j=cols.index('m5_gap_to_side')
    for side,name in enumerate(('buy_X','sell_X')):arrays[side]['m5_gap_to_side']=np.asarray(P._get(features,name))[:,j]
    for i in range(1,len(meta)):
        if times[i]==times[i-1] and (meta[i]['q0_index'],meta[i]['q0_line'])<=(meta[i-1]['q0_index'],meta[i-1]['q0_line']):reset[i]=True
    return arrays,meta,times,phases,reset,prices


def _has(x: dict, i: int, *names: str) -> bool:
    """
    機能: 必要列が当時すべて有限か確認する。
    引数: x(dict)、i(int)、names(tuple[str])。
    返り値: bool。未知を0へ置かない。
    """
    return all(np.isfinite(x[n][i]) for n in names)


def _long(x: dict, i: int) -> bool:
    """
    機能: 15又は30分でEMA傾きとDIが実方向に揃ったかを確認する。
    引数: x(dict)、i(int)。
    返り値: boolは必要既知の代替が一つ以上真。
    """
    return any(_has(x,i,f'm{m}_ema21_delta_to_side',f'm{m}_di_difference_to_side')
        and x[f'm{m}_ema21_delta_to_side'][i]>0 and x[f'm{m}_di_difference_to_side'][i]>0 for m in (15,30))


def _momentum(x: dict, i: int, strong: bool=False) -> bool:
    """
    機能: 5分のMACD/RSI増分を同時確認する。
    引数: x(dict)、i(int)、strong(bool)は両方正を要す。
    返り値: bool。
    """
    if not _has(x,i,'m5_hist_delta_to_side','m5_rsi_delta_to_side'):return False
    a,b=x['m5_hist_delta_to_side'][i],x['m5_rsi_delta_to_side'][i]
    return bool(a>0 and b>0) if strong else bool(a>=0 and b>=0 and (a>0 or b>0))


def _structure(x: dict, i: int) -> bool:
    """
    機能: 実方向の1分実体・価格進行・liveを同時確認する。
    引数: x(dict)、i(int)。
    返り値: bool。回復1点だけでは発火しない。
    """
    names=('m1_body_ratio_to_side','m1_close_delta_atr5_to_side','m1_body_reclaim_atr5_to_side','q0_last_minus_m1_close_atr5_to_side')
    return bool(_has(x,i,*names) and x[names[0]][i]>0 and x[names[1]][i]>0 and x[names[2]][i]+x[names[3]][i]>0)


def _quality(x: dict, i: int, prices: dict) -> bool:
    """
    機能: 現在の位置・値幅・価格鮮度を実方向で確認する。
    引数: x(dict)、i(int)、prices(dict)。
    返り値: bool。
    """
    names=('m5_atr','q0_spread_points','q0_last_minus_m1_close_atr5_to_side','q0_entry_minus_ema8_atr5_to_side','m1_tr_atr5_ratio','m5_tr_previous_atr_ratio')
    return bool(prices['normal'][i] and _has(x,i,*names) and x['m5_atr'][i]>0
        and 0<x['q0_spread_points'][i]<=20 and abs(x['q0_last_minus_m1_close_atr5_to_side'][i])<=1
        and -.5<=x['q0_entry_minus_ema8_atr5_to_side'][i]<=1.5
        and x['m1_tr_atr5_ratio'][i]<=2.5 and x['m5_tr_previous_atr_ratio'][i]<=4)


def _accept(state: dict, x: dict, i: int, sign: int, times: np.ndarray, prices: dict, profile: dict) -> dict | None:
    """
    機能: 同じ絶対水準に対する受容を連続q0と実時間で更新する。
    引数: state(dict)はlevel/atr/accept、x(dict)、i/sign(int)、times(np.ndarray)、prices/profile(dict)。
    返り値: dict|Noneは現在までの受容状態。金額や後続価格は参照しない。
    """
    old=state.get('accept');now=float(times[i])
    if not prices['normal'][i] or not _has(x,i,'m1_volume_relative_prior3'):
        state['accept']=None;return None
    volume=float(x['m1_volume_relative_prior3'][i]);distance=sign*(float(prices['last'][i])-state['level'])/state['atr']
    if volume<profile['volume_each'] or distance< -profile['penetration_atr']:
        state['accept']=None;return None
    if old is not None and now-old['last_observed_time']>90:old=None
    if old is None:
        if distance<0:state['accept']=None;return None
        old={'event':i,'time':now,'price':float(prices['last'][i]),'count':1,'volume_sum':volume,
            'last_count_time':now,'last_observed_time':now,'min_distance':distance}
    else:
        old['min_distance']=min(old['min_distance'],distance);old['last_observed_time']=now
        if now>old['last_count_time']:
            old['count']+=1;old['volume_sum']+=volume;old['last_count_time']=now
    state['accept']=old
    return old


def _mature(state: dict, accept: dict | None, i: int, sign: int, times: np.ndarray, prices: dict, profile: dict) -> bool:
    """
    機能: 観測個数・実秒・量平均・価格進行・侵入の全部を確認する。
    引数: state/accept(dict|None)、i/sign(int)、times(np.ndarray)、prices/profile(dict)。
    返り値: boolは当時までの受容が成熟した場合だけTrue。
    """
    if accept is None:return False
    distance=sign*(float(prices['last'][i])-state['level'])/state['atr']
    progress=sign*(float(prices['last'][i])-accept['price'])/state['atr']
    return bool(accept['count']>=profile['observations'] and times[i]-accept['time']>=profile['seconds']
        and accept['volume_sum']/accept['count']>=profile['volume_mean']
        and accept['min_distance']>=-profile['penetration_atr'] and distance>=.1 and progress>=.1)


def _technical(family: str, arrays: list, side: int, i: int, setup: int) -> bool:
    """
    機能: 受容後のDI/MA拡散又は元圧力失速と実方向転換を確認する。
    引数: family(str)、arrays(list)、side/i/setup(int)。
    返り値: bool。必要値未知は成立させない。
    """
    x=arrays[side];source=arrays[1-side]
    if not _has(x,i,'m5_di_difference_to_side','m5_gap_to_side') or not _momentum(x,i) or not _structure(x,i):return False
    if family=='TA':
        names=('m5_di_difference_to_side','m5_gap_to_side')
        return bool(_has(x,setup,*names) and x[names[0]][i]>0 and x[names[1]][i]>0
            and (x[names[0]][i]>x[names[0]][setup] or x[names[1]][i]>x[names[1]][setup]))
    names=('m5_di_difference_to_side','m5_hist_delta_to_side','m5_ema21_delta_to_side')
    if not _has(source,i,*names) or not _has(source,setup,*names):return False
    fading=(source[names[0]][i]<source[names[0]][setup]
        and (source[names[1]][i]<source[names[1]][setup] or source[names[2]][i]<source[names[2]][setup]))
    turn=x['m5_di_difference_to_side'][i]>0 or x['m5_gap_to_side'][i]>0
    if family=='RA':
        slow=(np.isfinite(x['m15_adx_delta'][i]) and x['m15_adx_delta'][i]<=0
            or np.isfinite(x['m15_hist_delta_to_side'][i]) and x['m15_hist_delta_to_side'][i]>=0)
        return bool(fading and turn and slow)
    return bool(fading and turn)


def _signals(family: str, arrays: list, prices: dict, times: np.ndarray, reset: np.ndarray, profile: dict, base: dict) -> dict:
    """
    機能: 三構造の固定価格受容を将来情報なしで追跡する。
    引数: family(str)、arrays(list)、prices/base/profile(dict)、times/reset(np.ndarray)。
    返り値: dictは方向・setup・受容監査・元幅期限。
    """
    n=len(times);out={'direction':np.zeros(n,np.int8),'setup_event':np.full(n,-1,np.int64),
        'accept_event':np.full(n,-1,np.int64),'accept_count':np.zeros(n,np.int16),'accept_seconds':np.zeros(n),
        'max_penetration_atr':np.full(n,np.nan),'level':np.full(n,np.nan),
        **{k:base[k].copy() for k in ('mw','fw','hi')}}
    states=[None,None]
    for i in range(n):
        if reset[i]:states=[None,None]
        ready=[]
        for source_side in (0,1):
            sign=1 if source_side==0 else -1;x=arrays[source_side];state=states[source_side]
            target_side=source_side if family=='TA' else 1-source_side;target_sign=1 if target_side==0 else -1
            if state is not None and times[i]-times[state['event']]>1800:state=None;states[source_side]=None
            if state is not None:
                if family=='RA' and state['level'] is None and prices['normal'][i]:
                    state['peak']=max(state['peak'],sign*float(prices['last'][i]))
                    if state['peak']-sign*float(prices['last'][i])>=.35*state['atr']:
                        state['level']=sign*(state['peak']-.35*state['atr'])
                if state['level'] is not None:
                    accept=_accept(state,arrays[target_side],i,target_sign,times,prices,profile)
                    if (i>state['event'] and times[i]>times[state['event']]
                        and _mature(state,accept,i,target_sign,times,prices,profile)
                        and _quality(arrays[target_side],i,prices) and _technical(family,arrays,target_side,i,state['event'])):
                        ready.append((target_side,state));states[source_side]=None;continue
            if states[source_side] is not None or not prices['normal'][i] or not _has(x,i,'m5_atr','m1_volume_relative_prior3'):continue
            atr=float(x['m5_atr'][i]);volume=x['m1_volume_relative_prior3'][i]
            if atr<=0:continue
            level=None;seed=False
            if family=='TA':
                seed=(_has(x,i,'m5_ema21_delta_to_side','q0_entry_minus_ema8_atr5_to_side','m5_di_difference_to_side','m5_gap_to_side')
                    and x['m5_ema21_delta_to_side'][i]>=0 and _long(x,i)
                    and -1<=x['q0_entry_minus_ema8_atr5_to_side'][i]<=.25 and volume>=.5)
                if seed:level=float(prices['ask'][i] if source_side==0 else prices['bid'][i])-sign*x['q0_entry_minus_ema8_atr5_to_side'][i]*atr
            elif family=='FA':
                seed=(_has(x,i,'q0_last_minus_prior3_forward_edge_atr5_to_side','m5_body_ratio_to_side','m5_di_difference_to_side','m5_ema21_delta_to_side')
                    and x['q0_last_minus_prior3_forward_edge_atr5_to_side'][i]>.25 and x['m5_body_ratio_to_side'][i]>=.4 and _momentum(x,i,True) and volume>=.75)
                if seed:level=float(prices['last'][i])-sign*x['q0_last_minus_prior3_forward_edge_atr5_to_side'][i]*atr
            else:
                seed=(_has(x,i,'m5_ema21_delta_to_side','m5_di_difference_to_side','m5_gap_to_side','m15_adx')
                    and x['m5_ema21_delta_to_side'][i]>0 and x['m5_di_difference_to_side'][i]>0 and _long(x,i)
                    and x['m15_adx'][i]>=20 and _momentum(x,i,True) and volume>=.75)
            if seed:
                states[source_side]={'event':i,'atr':atr,'level':level,'accept':None,'peak':sign*float(prices['last'][i])}
        if len({side for side,_ in ready})==1:
            side,state=ready[0];accept=state['accept'];event=state['event']
            out['direction'][i]=1 if side==0 else -1;out['setup_event'][i]=event;out['accept_event'][i]=accept['event']
            out['accept_count'][i]=accept['count'];out['accept_seconds'][i]=times[i]-accept['time']
            out['max_penetration_atr'][i]=max(0,-accept['min_distance']);out['level'][i]=state['level']
            for key in ('mw','fw','hi'):out[key][i]=base[key][event]
    return out


def _pressure(arrays: list, prices: dict, times: np.ndarray, reset: np.ndarray, profile: dict) -> np.ndarray:
    """
    機能: 元方向の持続圧力代理を同じ価格側の受容から作る。
    引数: arrays(list)、prices/profile(dict)、times/reset(np.ndarray)。
    返り値: np.ndarray[bool,2,N]は当時観測で成立した方向。板数量は使わない。
    """
    n=len(times);out=np.zeros((2,n),bool);states=[None,None]
    for i in range(n):
        if reset[i]:states=[None,None]
        for side in (0,1):
            x=arrays[side];sign=1 if side==0 else -1
            known=_has(x,i,'m5_ema21_delta_to_side','m5_di_difference_to_side','m5_gap_to_side','m5_atr','q0_entry_minus_ema8_atr5_to_side')
            valid=(known and prices['normal'][i] and x['m5_ema21_delta_to_side'][i]>0 and x['m5_di_difference_to_side'][i]>0
                and x['m5_gap_to_side'][i]>0 and x['m5_atr'][i]>0 and _long(x,i) and _momentum(x,i))
            if not valid:states[side]=None;continue
            if states[side] is None:
                entry=float(prices['ask'][i] if side==0 else prices['bid'][i])
                states[side]={'event':i,'atr':float(x['m5_atr'][i]),'level':entry-sign*x['q0_entry_minus_ema8_atr5_to_side'][i]*x['m5_atr'][i],'accept':None}
            state=states[side];accept=_accept(state,x,i,sign,times,prices,profile)
            out[side,i]=_mature(state,accept,i,sign,times,prices,profile)
    return out


def build(features: object, base_bundle: dict, candidate_ids: list | None=None) -> dict:
    """
    機能: 20候補の純入口を全3帯で生成し元幅期限を保持する。
    引数: features(FeatureDataset互換、q0_prices必須)、base_bundle(dict)、candidate_ids(list[str]|None)。
    返り値: dictはcandidate_ids/bundles/diagnostics。金融・口座結果は入力しない。
    """
    mapping={r['id']:r for r in catalog()['rules']};ids=list(mapping) if candidate_ids is None else candidate_ids
    assert len(ids)==len(set(ids)) and set(ids)<=set(mapping)
    arrays,meta,times,phases,reset,prices=_prepare(features);n=len(meta)
    base,_,_=P.OLD.V1._base(base_bundle,n,phases)
    controls=P.build(features,base_bundle,[mapping[key]['control'] for key in ids if mapping[key]['family']=='CONTROL'])
    profiles={mapping[key]['profile'] for key in ids if mapping[key]['family']!='CONTROL'}
    pressures={key:_pressure(arrays,prices,times,reset,PROFILES[key]) for key in profiles}
    pairs={(mapping[key]['family'],mapping[key]['profile']) for key in ids if mapping[key]['family']!='CONTROL'}
    signals={(family,p):_signals(family,arrays,prices,times,reset,PROFILES[p],base) for family,p in pairs}
    bundles={};diagnostics={}
    for identity in ids:
        rule=mapping[identity]
        if rule['family']=='CONTROL':
            bundles[identity]=controls['bundles'][rule['control']];diagnostics[identity]=controls['diagnostics'][rule['control']];continue
        signal=signals[(rule['family'],rule['profile'])];pressure=pressures[rule['profile']]
        out={'birth':{k:v.copy() for k,v in base['birth'].items()},**{k:base[k].copy() for k in ('mw','fw','hi','added')}}
        core=out['birth']['core'];new=np.zeros(n,bool);guarded=np.zeros(n,bool);deferred=np.zeros(n,bool)
        pending=None;deferred_from=np.full(n,-1,np.int64)
        for i in range(n):
            if reset[i]:pending=None
            if pending is not None and times[i]-times[pending['event']]>1800:pending=None
            if base['added'][i]:continue
            original=int(base['birth']['core'][i])
            if rule['mode']=='GUARD' and original:
                side=0 if original==1 else 1
                if pressure[1-side,i]:
                    guarded[i]=True;core[i]=0;out['birth']['branches'][i]=-1
                    out['birth']['technical'][i]=0;out['birth']['tier'][i]=0
                    if pending is None or pending['direction']!=original:pending={'event':i,'direction':original}
                else:pending=None
            chosen=int(signal['direction'][i])
            if core[i]!=0 or chosen==0:continue
            if rule['mode']=='GUARD':
                if pending is None or chosen!=pending['direction'] or times[i]<=times[pending['event']]:continue
                event=pending['event'];deferred_from[i]=event;deferred[i]=True;pending=None
            else:event=int(signal['setup_event'][i]);new[i]=True
            core[i]=chosen;out['birth']['branches'][i]=0;out['birth']['technical'][i]=0;out['birth']['tier'][i]=0;out['added'][i]=False
            for key in ('mw','fw','hi'):out[key][i]=base[key][event]
        lc=base['added'].astype(bool)
        assert all(np.array_equal(out['birth'][k][lc],base['birth'][k][lc]) for k in base['birth'])
        bundles[identity]=out
        diagnostics[identity]={'new_structure':new,'deferred_confirmed':deferred,'guarded':guarded,
            'deferred_from':deferred_from,'pressure_buy':pressure[0].copy(),'pressure_sell':pressure[1].copy(),
            **{k:v.copy() for k,v in signal.items() if k not in ('mw','fw','hi')}}
    return {'version':VERSION,'candidate_ids':ids,'bundles':bundles,'diagnostics':diagnostics}


def write_catalog(path: Path) -> None:
    """
    機能: 候補辞書と新旧Source指紋を新185金融前に固定する。
    引数: path(Path)。
    返り値: None。既存辞書・旧Sourceを改変しない。
    """
    assert not path.exists();sources=[]
    for source in (Path(__file__),Path(P.__file__)):
        sources.append({'path':source.relative_to(ROOT).as_posix(),'bytes':source.stat().st_size,'sha256':hashlib.sha256(source.read_bytes()).hexdigest()})
    path.write_text(json.dumps({**catalog(),'Source':sources,'新185金融未入力':True},ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
