"""185の持続受容と保留要求を、自然特徴・金融なしで検査する。"""
from pathlib import Path
from types import SimpleNamespace
import hashlib
import importlib.util
import json
import sys
import numpy as np
import rules185 as R

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('fixtures183_for185',R.ROOT/'work/183入口候補/人工検査.py')
T=importlib.util.module_from_spec(spec);sys.modules[spec.name]=T;spec.loader.exec_module(T)


def fixture(n: int=8) -> tuple:
    """
    機能: 183の純人工入力へ185が使うMA差を足す。
    引数: n(int)。
    返り値: tupleは特徴と純基準bundle。
    """
    f,b=T.fixture(n)
    if 'm5_gap_to_side' not in f.columns:
        f.columns=list(f.columns)+['m5_gap_to_side'];f.buy_X=np.c_[f.buy_X,np.ones(n)];f.sell_X=np.c_[f.sell_X,-np.ones(n)]
    return f,b


def sided(f: object, i: int, side: int) -> None:
    """
    機能: 人工の実方向へMA差と他の方向列を揃える。
    引数: f(object)、i/side(int)。
    返り値: None。
    """
    T.side(f,i,side);j=f.columns.index('m5_gap_to_side')
    f.buy_X[i,j]=1 if side==0 else -1;f.sell_X[i,j]=-f.buy_X[i,j]


def sliced(f: object, base: dict, stop: int) -> tuple:
    """
    機能: q0価格と特徴のprefixを複写する。
    引数: f(object)、base(dict)、stop(int)。
    返り値: tupleはprefix入力。
    """
    return T.sliced(f,base,stop)


def trend_case() -> tuple:
    """
    機能: 固定EMA8への戻りを3q0保持する人工例を作る。
    引数: なし。
    返り値: tupleは特徴と純基準。
    """
    f,b=fixture();j=f.columns.index('q0_entry_minus_ema8_atr5_to_side');f.buy_X[0,j]=0;f.sell_X[0,j]=0
    for i,value in enumerate((100.,100.6,102.,103.4,104.,104.2,104.3,104.4)):T.price(f,i,value)
    for i in range(2,8):f.buy_X[i,f.columns.index('m5_di_difference_to_side')]=2;f.sell_X[i,f.columns.index('m5_di_difference_to_side')]=-2
    return f,b


def failure_case(guard: bool=False) -> tuple:
    """
    機能: 元突破から固定端の反対側受容までの人工例を作る。
    引数: guard(bool)は持続買い圧力に逆らう旧売り要求を含むか。
    返り値: tupleは特徴と純基準。
    """
    f,b=fixture();j=f.columns.index('q0_last_minus_prior3_forward_edge_atr5_to_side');f.buy_X[0,j]=.5;f.sell_X[0,j]=-.5
    for i,value in enumerate((100.,101.2,94.5,93.3,92.1,91.8,91.5,91.4)):T.price(f,i,value)
    for i in range(2,8):sided(f,i,1)
    if guard:
        b['birth']['core'][:]=0;b['birth']['branches'][:]=-1;b['mw'][:]=b['fw'][:]=200
        b['birth']['core'][1]=-1;b['birth']['branches'][1]=0;b['mw'][1]=b['fw'][1]=350
    return f,b


def main() -> None:
    """
    機能: 実秒・同秒・侵入・量・価格側・転換・保留・鏡像・prefix・未来改変を照合する。
    引数: なし。
    返り値: None。人工確認JSONのみ保存する。
    """
    checks=[];total=0
    def check(name: str, actual: object, expected: object) -> None:
        """
        機能: 一つの人工期待値を確認する。
        引数: name(str)、actual/expected(object)。
        返り値: None。不一致で停止する。
        """
        nonlocal total
        a,b=np.asarray(actual),np.asarray(expected)
        assert a.shape==b.shape and np.array_equal(a,b),(name,a,b)
        total+=a.size;checks.append({'検査':name,'項目':int(a.size),'不一致':0})
    for label,maker in [('順行',trend_case),('失敗',failure_case),('保留',lambda:failure_case(True))]:
        f,b=maker();born=R.build(f,b)
        for stop in range(9):
            pf,pb=sliced(f,b,stop);prior=R.build(pf,pb)
            for identity in born['candidate_ids']:
                for key,value in T.flat(born['bundles'][identity]).items():check('prefix/'+label+f'/{stop}/'+identity+'/'+key,T.flat(prior['bundles'][identity])[key],value[:stop])
        mf,mb=sliced(f,b,8);mf.buy_X,mf.sell_X=mf.sell_X.copy(),mf.buy_X.copy()
        old={k:v.copy() for k,v in mf.q0_prices.items()};mf.q0_prices['last']=-old['last'];mf.q0_prices['bid']=-old['ask'];mf.q0_prices['ask']=-old['bid']
        for key in ('core','technical'):mb['birth'][key]*=-1
        mirrored=R.build(mf,mb)
        for identity in born['candidate_ids']:
            for key,value in T.flat(born['bundles'][identity]).items():check('鏡像/'+label+'/'+identity+'/'+key,T.flat(mirrored['bundles'][identity])[key],-value if key in ('core','technical') else value)
        for stop in (1,3,6):
            cf,cb=sliced(f,b,8);cf.buy_X[stop:]=np.nan;cf.sell_X[stop:]=np.nan;cf.q0_prices['last'][stop:]+=10000
            changed=R.build(cf,cb)
            for identity in born['candidate_ids']:
                for key,value in T.flat(born['bundles'][identity]).items():check('将来改変/'+label+f'/{stop}/'+identity+'/'+key,T.flat(changed['bundles'][identity])[key][:stop],value[:stop])
    f,b=trend_case();born=R.build(f,b)
    check('60秒型は回復一回で入らない',born['diagnostics']['E185_02']['direction'][1],0)
    check('60秒型は次q0で発火',born['diagnostics']['E185_02']['direction'][2],1)
    check('120秒型は60秒で未成熟',born['diagnostics']['E185_04']['direction'][2],0)
    check('120秒型は3q0で成熟',born['diagnostics']['E185_04']['direction'][3],1)
    check('元setup幅を継承',born['bundles']['E185_02']['mw'][2],350)
    check('受容実秒',born['diagnostics']['E185_04']['accept_seconds'][3],120)
    f,b=failure_case(True);born=R.build(f,b)
    check('反対圧力が持続した旧売りを保留',born['diagnostics']['E185_09']['guarded'][1],True)
    check('保留は無確認で買いへ反転しない',born['bundles']['E185_09']['birth']['core'][1],0)
    check('反対側受容後に元売りを再要求',born['bundles']['E185_09']['birth']['core'][3],-1)
    check('延期要求の幅は元要求350',born['bundles']['E185_09']['mw'][3],350)
    check('新独立種の幅と混同しない',born['bundles']['E185_08']['mw'][3],200)
    check('延期区分',born['diagnostics']['E185_09']['deferred_confirmed'][3],True)

    # ----------------------------------------
    f,b=fixture(3);arrays,meta,times,phases,reset,prices=R._prepare(f);x=arrays[0];profile=R.PROFILES['C60']
    def accept_case(last: list, seconds: list, volumes: list) -> tuple:
        """
        機能: 固定水準100の受容だけを検査する。
        引数: last/seconds/volumes(list)は人工観測列。
        返り値: tupleは各時点の成熟旗と最終受容状態。
        """
        state={'level':100.,'atr':10.,'accept':None};p={k:v.copy() for k,v in prices.items()};p['last']=np.asarray(last,float);t=np.asarray(seconds,float)
        xx={k:v.copy() for k,v in x.items()};xx['m1_volume_relative_prior3']=np.asarray(volumes,float);result=[]
        for i in range(3):
            a=R._accept(state,xx,i,1,t,p,profile);result.append(R._mature(state,a,i,1,t,p,profile))
        return result,state['accept']
    flags,a=accept_case([100,101.2,101.3],[0,0,60],[1,1,1])
    check('同秒は観測数を増やさない',flags,[False,False,True]);check('同秒の量を重複加算しない',a['count'],2)
    flags,a=accept_case([100,98.8,101.3],[0,0,60],[1,1,1]);check('同秒でも侵入でやり直し',flags,[False,False,False])
    flags,a=accept_case([100,99.5,101.2],[0,60,120],[1,1,1]);check('許容内侵入の後で成熟',flags[-1],True);check('観測最大侵入',max(0,-a['min_distance']),.05)
    flags,a=accept_case([100,98.9,101.2],[0,60,120],[1,1,1]);check('許容超侵入は成熟しない',flags[-1],False)
    flags,a=accept_case([100,101.2,102.4],[0,91,151],[1,1,1]);check('91秒穴で受容やり直し',flags[1],False)
    flags,a=accept_case([100,101.2,102.4],[0,90,150],[1,1,1]);check('90秒ちょうどは許容',flags[1],True)
    flags,a=accept_case([100,101.2,102.4],[0,60,120],[1,np.nan,1]);check('量未知を無事通過にしない',flags[-1],False)
    flags,a=accept_case([100,101.2,102.4],[0,60,120],[1,.4,1]);check('低量で受容をやり直す',flags[-1],False)
    f,b=trend_case();j=f.columns.index('m5_di_difference_to_side');f.buy_X[:,j]=1;f.sell_X[:,j]=-1
    check('DI/MA拡散なしではTAを入れない',R.build(f,b)['diagnostics']['E185_02']['direction'].sum(),0)
    for change in ('gap','contract','scene','backward'):
        f,b=trend_case()
        for q in f.q0_meta[1:]:
            if change=='gap':q['q0_time']+=121
            elif change=='contract':q['contract']='次限月'
            elif change=='scene':q['session']='別_Night';q['session_index']=1
            else:q['q0_time']-=61
        f.q0_prices['time']=np.asarray([q['q0_time'] for q in f.q0_meta])
        check('setup reset/'+change,R.build(f,b)['diagnostics']['E185_02']['direction'][2],0)
    f,b=trend_case();f.q0_timeband[1:]=1
    check('NY境界だけではsetupを消さない',R.build(f,b)['diagnostics']['E185_02']['direction'][2],1)
    result={'成功':True,'新185金融と自然特徴未入力':True,'項目':total,'不一致':0,'検査':checks,'Source':[]}
    for path in (HERE/'rules185.py',Path(__file__)):
        result['Source'].append({'path':path.relative_to(R.ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    (HERE/'人工確認185.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'項目':total,'不一致':0},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
