"""単純IFDの全候補を結合し、損失優先の固定順位と期間別結果を保存する。"""
from pathlib import Path
import argparse
import gzip
import json
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).parent
for directory in ('work/181反省を分解した改善','work/183損失安定性'):
    sys.path.insert(0,str(ROOT/directory))
import 集計181 as A
import 安定性183 as S


def read(path: Path) -> dict:
    """
    機能: UTF-8圧縮JSONを読み込む。
    引数: path(Path)。
    返り値: dictは計算済み正本。
    """
    return json.loads(gzip.decompress(path.read_bytes()))


def save(path: Path, body: dict) -> None:
    """
    機能: 集計結果を決定的な圧縮JSONへ保存する。
    引数: path(Path)、body(dict)。
    返り値: None。
    """
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(gzip.compress((json.dumps(body,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode(),mtime=0))


def compact(group: dict, baseline: dict) -> dict:
    """
    機能: 金融・参加・損失安定性から比較に必要な小表を作る。
    引数: group/baseline(dict)は同じ対象帯・期間。
    返り値: dictは率の上下限、既知損益と未知、分母を保持する。
    """
    t,s,h,p=group['trades'],group['sessions'],group['holding'],group['path']
    window=group['rolling']['5']['worst_known_contribution']
    return {'適合':S.gate(group,baseline),'取得':t['all_count'],'未知':t['unknown_count'],
        '利益':t['known_profit'],'損失':t['known_loss'],'既知収支':t['known_net'],
        '取得場':s['participating_count'],'全場':s['eligible_count'],
        '赤字場':s['negative_rate'],'赤字取引':t['negative_rate'],
        '連続赤字場':s['negative_streak'],'連敗':t['negative_streak'],
        '保有率下限':h['held_lower_ratio'],'保有率上限':h['held_upper_ratio'],
        '建玉中央値':t['net_median'],'場中央値':s['net_median'],
        '最悪5場既知寄与':window,'最大場損失既知寄与':max(0,-p['known_contribution']['worst_scene_net']) if p['known_contribution']['worst_scene_net'] is not None else None,
        'DD既知寄与':p['known_contribution']['max_drawdown'],
        '全件経路確定':p['full_exact'] is not None,'既知損失毎取得':t['known_loss_per_acquisition']}


def main() -> None:
    """
    機能: 全3期間を同一候補ごとに結合し、前48選択と全80発見を分ける。
    引数: CLI --baseline(str)は金融前固定した基準ID。
    返り値: None。全候補台帳・損失診断・小表・順位を保存する。
    """
    parser=argparse.ArgumentParser()
    parser.add_argument('--baseline',required=True)
    args=parser.parse_args()
    paths=sorted((HERE/'期間別/旧73').glob('*.json.gz'))
    rows=[];states=[]
    for path in paths:
        packs=[read(HERE/'期間別'/leg/path.name) for leg in ('旧73','追加7','本日1')]
        row=A.combine(packs)
        row['全80比較']=A.combine(packs[:2])['evidence']
        scenes=[v['scene'] for v in row['sessions']]
        assert len(scenes)==81
        periods={'旧73':scenes[:73],'前48':scenes[:48],'後25':scenes[48:73],
                 '追加7':scenes[73:80],'本日1':scenes[80:],'全80':scenes[:80]}
        state=S.evaluate_pack(row,periods)
        rows.append(row);states.append(state)
        save(HERE/'集約'/(row['id']+'.json.gz'),row)
    baseline=next(v for v in states if v['id']==args.baseline)
    ranks={}
    for period in ('前48','全80'):
        for band in ('DAY','NIGHT'):
            ranked=sorted(states,key=lambda v:(S.rank_key(v['periods'][period][band],baseline['periods'][period][band]),v['id']))
            ranks[band+'_'+period]=[v['id'] for v in ranked]
    small=[]
    for state in states:
        small.append({'id':state['id'],
            '全81':{b:compact(g,baseline['groups'][b]) for b,g in state['groups'].items()},
            '期間':{p:{b:compact(g,baseline['periods'][p][b]) for b,g in groups.items()}
                    for p,groups in state['periods'].items()}})
    save(HERE/'全候補の損失安定性.json.gz',{'rows':states})
    save(HERE/'全候補比較.json.gz',{'baseline':args.baseline,'全81既使用':True,'rows':small,'順位':ranks})
    for key,names in ranks.items():
        band,period=key.split('_')
        print(key,flush=True)
        for name in names[:4]:
            value=next(v for v in small if v['id']==name)
            print(json.dumps({'id':name,**value['期間'][period][band]},ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
