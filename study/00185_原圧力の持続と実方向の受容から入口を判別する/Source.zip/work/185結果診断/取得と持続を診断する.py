"""185の実取得を新受容・延期・旧幹へ分解し、固定対照と指紋を確認する。"""
from pathlib import Path
from collections import defaultdict
import gzip
import hashlib
import json
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).parent
BASE=ROOT/'work/185原圧力と受容'


def read(path: Path) -> object:
    """
    機能: 保存済みJSONを読む。
    引数: path(Path)はJSON又はgzip JSON。
    返り値: objectは保存値。
    """
    data=path.read_bytes()
    return json.loads(gzip.decompress(data) if path.suffix=='.gz' else data)


def save(path: Path, body: object) -> None:
    """
    機能: 診断を決定的gzip JSONへ保存する。
    引数: path(Path)、body(object)。
    返り値: None。金融・条件を変更しない。
    """
    data=(json.dumps(body,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode()
    path.write_bytes(gzip.compress(data,mtime=0) if path.suffix=='.gz' else data)


def summary(rows: list) -> dict:
    """
    機能: 実取得群の利益・損失・未知を集計する。
    引数: rows(list[dict])は取得済み台帳。
    返り値: dict。未知額を0円として全件収支を確定しない。
    """
    net=[r['net'] for r in rows if r['net'] is not None]
    labels=defaultdict(int)
    for row in rows:labels[str(row['label'])]+=1
    return {'取得':len(rows),'取得場':len({r['scene'] for r in rows}),'未知':len(rows)-len(net),
        '利益':sum(max(x,0) for x in net),'損失':-sum(min(x,0) for x in net),'既知収支':sum(net),
        '赤字':sum(x<0 for x in net),'先着':dict(labels)}


def main() -> None:
    """
    機能: 全候補の役割別実取得・取得差・固定対照同体を診断する。
    引数: なし。
    返り値: None。取得診断とSource不変票を保存する。
    """
    comparison=read(BASE/'全候補比較.json.gz')
    diagnostics={leg:read(BASE/(leg+'_純成立診断.json.gz')) for leg in ('旧73','追加7','本日1')}
    packs={r['id']:read(BASE/'集約'/(r['id']+'.json.gz')) for r in comparison['rows']}
    scenes=[r['scene'] for r in next(iter(packs.values()))['sessions']]
    periods={'前48':set(scenes[:48]),'後25':set(scenes[48:73]),'追加7':set(scenes[73:80]),
        '本日1':set(scenes[80:]),'全80':set(scenes[:80]),'全81':set(scenes)}
    tables={}
    for identity,pack in packs.items():
        ledger=pack['ledger'];rows=[];entry=pack['policy']['entry']
        for i in range(len(ledger['net'])):
            row={k:v[i] for k,v in ledger.items()}
            detail=diagnostics[row['leg']][entry];event=row['event']
            role=('LC' if row['added'] else '延期確認' if detail.get('deferred_confirmed',[False]*(event+1))[event]
                else '新受容' if detail.get('new_structure',[False]*(event+1))[event] else '旧幹又はT')
            if entry=='E185_01' and role=='新受容':role='旧183単発EM'
            row['役割']=role
            row['key']=(row['scene'],row['entry_time'],row['entry_line'],row['side'],row['width'],row['horizon'])
            if role in ('新受容','延期確認'):
                for key in ('setup_event','accept_event','accept_count','accept_seconds','max_penetration_atr','level'):
                    row[key]=detail[key][event]
            rows.append(row)
        tables[identity]=rows
    baseline=tables['E185_00__C0_IFD'];results=[]
    for identity,rows in tables.items():
        groups={};entry=packs[identity]['policy']['entry']
        for band,phases in {'DAY':{0},'NIGHT':{1,2},'PRE':{1},'POST':{2}}.items():
            for period,names in periods.items():
                picked=[r for r in rows if r['scene'] in names and r['phase'] in phases]
                old=[r for r in baseline if r['scene'] in names and r['phase'] in phases]
                keys={r['key'] for r in picked};oldkeys={r['key'] for r in old}
                classes=defaultdict(list)
                for row in picked:classes[row['役割']].append(row)
                groups[band+'_'+period]={'全取得':summary(picked),'役割':{k:summary(v) for k,v in classes.items()},
                    '基準だけの実取得':summary([r for r in old if r['key'] not in keys]),
                    '候補だけの実取得':summary([r for r in picked if r['key'] not in oldkeys]),
                    '新受容又は延期の実取得':[{k:r[k] for k in ('scene','event','side','width','horizon','net','label','役割',
                        'setup_event','accept_event','accept_count','accept_seconds','max_penetration_atr','level')}
                        for r in picked if r['役割'] in ('新受容','延期確認')]}
        pure={}
        for leg,diag in diagnostics.items():
            detail=diag[entry]
            pure[leg]={k:int(np.count_nonzero(detail[k])) for k in ('direction','new_structure','deferred_confirmed','guarded') if k in detail}
        results.append({'id':identity,'純成立':pure,'群':groups})
    save(HERE/'実取得と持続の診断185.json.gz',{'baseline':comparison['baseline'],'rows':results,
        '注意':'新群の実取得と口座全体を分ける。取得差は両口座で実取得した取引の差であり、未参加の仮想利益を最適化しない。'})
    # ----------------------------------------
    checks=[]
    for fresh,old in (('E185_00','E183_00'),('E185_01','E183_04')):
        for leg in ('旧73','追加7','本日1'):
            new=read(BASE/'期間別'/leg/(fresh+'__C0_IFD.json.gz'))
            previous=read(ROOT/'work/183単純IFD検証/期間別'/leg/(old+'__C0_IFD.json.gz'))
            for key in ('ledger','sessions','positions','evidence','periods','selection','engine'):
                assert new[key]==previous[key],(fresh,leg,key)
                checks.append({'候補':fresh,'期間':leg,'比較':key,'同体':True})
    conditions=read(ROOT/'study/00185_原圧力の持続と実方向の受容から入口を判別する/条件_NK225.json')
    for item in conditions['Source']:
        assert hashlib.sha256((ROOT/item['path']).read_bytes()).hexdigest()==item['sha256'],item['path']
    save(HERE/'対照とSourceの同体185.json',{'成功':True,'固定対照':checks,'Source不変':len(conditions['Source']),
        '注意':'同じ金融インフラにおける旧対照との同体。新群全金融を原板から別実装した独立検算ではない。'})
    for result in results:
        if result['id'].split('__')[0] in ('E185_02','E185_03','E185_06','E185_08','E185_14','E185_18'):
            print(json.dumps({'id':result['id'],'DAY全80':result['群']['DAY_全80'],
                'NIGHT全80':result['群']['NIGHT_全80']},ensure_ascii=False))


if __name__=='__main__':main()
