"""191の旧要求起点・二方向受容を自然金融なしで検査する。"""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
import numpy as np
import rules191 as R

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('fixtures185_for191',R.ROOT/'work/185原圧力と受容/人工検査.py')
T=importlib.util.module_from_spec(spec);sys.modules[spec.name]=T;spec.loader.exec_module(T)


def fixture(reverse: bool=True) -> tuple:
    """
    機能: 旧売り要求に対して買い圧力がある人工入力を作る。
    引数: reverse(bool)は後刻の帯内反転か元方向再テストか。
    返り値: tupleは純特徴と350pt/H60の元要求を含むbundle。
    """
    f,b=T.fixture(8);b['birth']['core'][:]=0;b['birth']['branches'][:]=-1
    b['birth']['core'][0]=-1;b['birth']['branches'][0]=0
    j=f.columns.index('q0_entry_minus_bbmean_sigma_to_side');f.buy_X[0,j]=1.5;f.sell_X[0,j]=-1.5
    values=(100,95,93.8,92.6,91.4,91,90.7,90.4) if reverse else (100,99.8,100.5,101.7,102.9,103.2,103.4,103.6)
    for i,value in enumerate(values):T.T.price(f,i,value)
    if reverse:
        for i in range(1,8):T.sided(f,i,1)
    else:
        for i in range(1,8):
            T.sided(f,i,0)
            for col in ('m5_di_difference_to_side','m5_gap_to_side'):
                f.buy_X[i,f.columns.index(col)]=2;f.sell_X[i,f.columns.index(col)]=-2
    return f,b


def main() -> None:
    """
    機能: 確認可能性・鏡像・prefix・未来改変・未知・境界・resetを検査する。
    引数: なし。
    返り値: None。人工確認JSONだけ新規保存する。
    """
    checks=[];total=0
    def check(name: str, actual: object, expected: object) -> None:
        """
        機能: 人工期待値を比較し不一致時停止する。
        引数: name(str)、actual/expected(object)。
        返り値: None。
        """
        nonlocal total
        a,b=np.asarray(actual),np.asarray(expected)
        assert a.shape==b.shape and np.array_equal(a,b),(name,a,b)
        total+=a.size;checks.append({'検査':name,'項目':int(a.size),'不一致':0})
    for label,reverse in (('帯内反転',True),('元方向再テスト',False)):
        f,b=fixture(reverse);built=R.build(f,b)
        for stop in range(9):
            pf,pb=T.sliced(f,b,stop);prefix=R.build(pf,pb)
            for identity in built['candidate_ids']:
                for key,value in T.T.flat(built['bundles'][identity]).items():
                    check(f'prefix/{label}/{stop}/{identity}/{key}',T.T.flat(prefix['bundles'][identity])[key],value[:stop])
        mf,mb=T.sliced(f,b,8);mf.buy_X,mf.sell_X=mf.sell_X.copy(),mf.buy_X.copy()
        price={k:v.copy() for k,v in mf.q0_prices.items()};mf.q0_prices['last']=-price['last'];mf.q0_prices['bid']=-price['ask'];mf.q0_prices['ask']=-price['bid']
        for key in ('core','technical'):mb['birth'][key]*=-1
        mirrored=R.build(mf,mb)
        for identity in built['candidate_ids']:
            for key,value in T.T.flat(built['bundles'][identity]).items():
                check(f'鏡像/{label}/{identity}/{key}',T.T.flat(mirrored['bundles'][identity])[key],-value if key in ('core','technical') else value)
        for stop in (1,3,6):
            cf,cb=T.sliced(f,b,8);cf.buy_X[stop:]=np.nan;cf.sell_X[stop:]=np.nan;cf.q0_prices['last'][stop:]+=10000
            changed=R.build(cf,cb)
            for identity in built['candidate_ids']:
                for key,value in T.T.flat(built['bundles'][identity]).items():
                    check(f'未来改変/{label}/{stop}/{identity}/{key}',T.T.flat(changed['bundles'][identity])[key][:stop],value[:stop])
    f,b=fixture(True);v=R.build(f,b)
    check('元q0は無確認反転せず保留',v['bundles']['E191_04']['birth']['core'][0],0)
    check('旧要求自身から反転再開',v['bundles']['E191_04']['birth']['core'][2],-1)
    check('独立familyの種なしで再開',v['diagnostics']['E191_04']['pending_from'][2],0)
    check('固定BB1σ端を使用',v['diagnostics']['E191_04']['level'][2],95.5)
    check('60秒受容',v['diagnostics']['E191_04']['accept_seconds'][2],60)
    check('120秒は60秒で未発火',v['bundles']['E191_05']['birth']['core'][2],0)
    check('120秒で発火',v['bundles']['E191_05']['birth']['core'][3],-1)
    check('元幅350を維持',v['bundles']['E191_04']['mw'][2],350)
    check('後刻の既定幅200へ置換しない',v['bundles']['E191_04']['fw'][2],350)
    f,b=fixture(False);v=R.build(f,b)
    check('再テスト当時発火禁止',v['bundles']['E191_06']['birth']['core'][1],0)
    check('元方向側受容一回では不足',v['bundles']['E191_06']['birth']['core'][2],0)
    check('元方向側60秒受容後に買いへ切替',v['bundles']['E191_06']['birth']['core'][3],1)
    check('元方向再テストの記憶',v['diagnostics']['E191_06']['retest_event'][3],1)
    check('WAITは順行切替しない',v['diagnostics']['E191_04']['follow_confirmed'].any(),False)
    check('切替幅は旧要求時',v['bundles']['E191_06']['mw'][3],350)
    check('切替は新LCと混同しない',v['bundles']['E191_06']['added'][3],False)
    # ----------------------------------------
    f,b=fixture(True)
    for m in (f.buy_X,f.sell_X):m[0,:]=np.nan
    v=R.build(f,b,['E191_04'])
    check('未知をリスクに置換しない',v['bundles']['E191_04']['birth']['core'][0],-1)
    check('未知を別旗',v['diagnostics']['E191_04']['risk_unknown'][0],True)
    f,b=fixture(True);b['added'][0]=True;b['mw'][0]=b['fw'][0]=400;b['hi'][0]=3;v=R.build(f,b,['E191_04'])
    check('旧LC保持',v['bundles']['E191_04']['birth']['core'][0],-1)
    check('旧LCは保留しない',v['diagnostics']['E191_04']['guarded'][0],False)
    f,b=fixture(True);b['added'][2]=True;b['birth']['core'][2]=-1;b['birth']['branches'][2]=0;b['mw'][2]=b['fw'][2]=400;b['hi'][2]=3
    v=R.build(f,b,['E191_04'])
    check('途中LC保持',v['bundles']['E191_04']['birth']['core'][2],-1)
    check('LCを飛ばした連続受容を仮定しない',v['diagnostics']['E191_04']['reverse_confirmed'][3],False)
    check('LC後も元setupを保持し再受容',v['diagnostics']['E191_04']['reverse_confirmed'][4],True)
    for kind in ('contract','scene','gap','backward'):
        f,b=fixture(True)
        if kind=='contract':
            for q in f.q0_meta[2:]:q['contract']='別限月'
        elif kind=='scene':
            for q in f.q0_meta[2:]:q['session']='別_Day';q['session_index']=1
        else:
            delta=181 if kind=='gap' else -121
            for i in range(2,8):f.q0_meta[i]['q0_time']+=delta;f.q0_prices['time'][i]+=delta
        v=R.build(f,b,['E191_04']);check('reset/'+kind,v['diagnostics']['E191_04']['reverse_confirmed'].any(),False)
    f,b=fixture(True);f.q0_meta[2]['q0_time']=f.q0_meta[1]['q0_time'];f.q0_prices['time'][2]=f.q0_prices['time'][1]
    v=R.build(f,b,['E191_04']);check('同秒q0で60秒水増し禁止',v['diagnostics']['E191_04']['reverse_confirmed'][2],False)
    f,b=fixture(True);f.q0_timeband[:]=1;f.q0_timeband[2:]=2;v=R.build(f,b,['E191_04'])
    check('NY帯境界だけではsetup維持',v['diagnostics']['E191_04']['reverse_confirmed'][2],True)
    f,b=fixture(True);a,_,_,_,_,prices=R.P._prepare(f);x=a[0]
    x['m15_adx'][0]=24;x['m15_adx_delta'][0]=0;x['q0_entry_minus_bbmean_sigma_to_side'][0]=1
    check('BB1σ境界はリスク',R._risk(x,0,'R2',True),1)
    x['q0_entry_minus_bbmean_sigma_to_side'][0]=.999
    check('BB境界未満とADX未満は非該当',R._risk(x,0,'R2',True),0)
    x['m15_adx'][0]=25;x['m15_adx_delta'][0]=.01
    check('ADX25上昇境界',R._risk(x,0,'R2',True),1)
    x['m15_adx_delta'][0]=0
    check('ADX増分0は上昇でない',R._risk(x,0,'R2',True),0)
    proof={'成功':True,'新191自然特徴と金融未入力':True,'項目':total,'不一致':0,'検査':checks,
        'SourceSHA':hashlib.sha256(Path(R.__file__).read_bytes()).hexdigest()}
    (HERE/'人工確認191.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:proof[k] for k in ('成功','項目','不一致')},ensure_ascii=False))


if __name__=='__main__':main()
