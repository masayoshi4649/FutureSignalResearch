"""旧BOの元方向圧力が強い局面だけ、固定181の早期反転確認へ切り替える。"""
from pathlib import Path
import hashlib
import json
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT/'work/181入口改善'))
import rules181 as V1
import rules181_v2 as P

VERSION = '182強い元圧力だけEARLY15へ切替1'
BACKGROUND = tuple(f'm{m}_{name}' for m in (5, 15, 30)
                   for name in ('ema21_delta_to_side', 'di_difference_to_side'))


def catalog() -> dict:
    """
    機能: 旧幹・無条件確認・局面切替2案の四候補を公開する。
    引数: なし。
    返り値: dictは条件、未知、優先順位と固定比較の定義。金融を入力しない。
    """
    return {'version': VERSION, 'candidate_count': 4, 'rules': [
        {'id': 'E182_00', 'mode': 'E181_00', 'description': '旧179全期J035＝181E00を全同体で保持'},
        {'id': 'E182_01', 'mode': 'E181_10', 'description': '181E10の無条件EARLY15を全同体で保持'},
        {'id': 'E182_02', 'mode': 'RISK6', 'description': '5/15/30分EMA21傾き・DI差全6が実方向と逆の時だけEARLY15'},
        {'id': 'E182_03', 'mode': 'RISK4ADX_OR_SPIKE', 'description': '4/6逆とADX上昇、又は元方向の突破・値幅・量スパイク時だけEARLY15'}],
        'base': '固定179全期J035の全帯birth/mw/fw/hi/added。DAYの旧BOだけ局面切替。',
        'risk6': {'columns': list(BACKGROUND), 'opposite_threshold_strict': 0, 'opposite_required': 6,
            'known': '6列全有限の時だけTrue/Falseを確定。それ以外はUNKNOWN。'},
        'risk4_adx': {'columns': list(BACKGROUND), 'opposite_threshold_strict': 0, 'opposite_required': 4,
            'm15_adx_min': 25, 'm15_adx_delta_min_strict': 0,
            'known': '6方向列・ADX・ADX増分が全有限の時だけ確定。'},
        'spike': {'source_side': '取得する実方向の反対側＝元BOの突破方向を参照。',
            'source_forward_edge_atr5_min_strict': .5, 'relative_volume_min': 1.5,
            'range': '1分TR/ATR5>=1.5 又は5分TR/前ATR>=2。',
            'combination': '元方向の端突破>0.5ATR5 AND相対量>=1.5 AND値幅条件。未知を0にせず三値論理で判定。'},
        'tri_state': 'RISK4ADX又はSPIKEに既知Trueが一つあればリスク。両方既知Falseなら非該当。他はUNKNOWN。',
        'unknown_action': 'UNKNOWNは旧BOを保持する既定行動。安全と認定したのではなく、背景不足・risk_unknownを別記する。',
        'confirmation': '固定181v2 EARLY15の全役割・閾値を同体再用。元BO後900秒以内、後続q0、実方向1分構造回復と元5分圧力不拡大・背景・量・位置・品質。',
        'state': 'リスクBOだけセットアップ。期限・reset・一度発火・同方向非延長は181と同じ。新しい非リスク又はUNKNOWNのBOが出たら既定旧BOを優先して旧待ち状態を取消す。',
        'preserved': 'MP/LC/夜間/Tと幅期限は保持。ただしリスクBOを待たせる元q0と確認発火q0はTへ暗黙切替しない。',
        'financial_scope': '純方向だけ。口座・費用・出口・保有は別。新182金融は未入力。旧81場は既使用であり未見検証ではない。',
        'hypothesis': '強い持続圧力の突破をただ逆に売買すると継続に逆らう。他方、全ての反転候補に完成確認を課すと既存の反転利益まで削る。圧力状態が当時観測できた部分だけ確認コストを払う仮説。',
        'threshold_note': '閾値はチャート上の役割を分ける研究仮説。自然の通過率・今日だけの有利さ・新金融結果から合わせない。'}


def _prepare(features: object) -> tuple:
    """
    機能: 181の因果時計・実側列へ、リスク判別用ADX水準を加える。
    引数: features(FeatureDataset互換)。
    返り値: tupleは側別列・q0・秒・帯・reset。
    """
    arrays, meta, times, phases, reset = P._prepare(features)
    columns = [c['name'] if isinstance(c, dict) else c for c in V1._feature(features, 'columns')]
    assert 'm15_adx' in columns
    j = columns.index('m15_adx')
    for side, name in enumerate(('buy_X', 'sell_X')):
        arrays[side]['m15_adx'] = np.asarray(V1._feature(features, name), dtype=np.float64)[:, j]
    return arrays, meta, times, phases, reset


def _and(items: list) -> int:
    """
    機能: 三値のANDを計算する。
    引数: items(list[int])はTrue=1/False=0/UNKNOWN=-1。
    返り値: intは既知False優先の三値AND。
    """
    return 0 if 0 in items else -1 if -1 in items else 1


def _or(items: list) -> int:
    """
    機能: 三値のORを計算する。
    引数: items(list[int])はTrue=1/False=0/UNKNOWN=-1。
    返り値: intは既知True優先の三値OR。
    """
    return 1 if 1 in items else -1 if -1 in items else 0


def _compare(x: dict, event: int, name: str, threshold: float, strict: bool = False) -> int:
    """
    機能: 必要値未知を別値にせず、一つのしきい値を判定する。
    引数: x(dict)、event(int)、name(str)、threshold(float)、strict(bool)。
    返り値: intは三値比較。strict=Falseは>=、Trueは>。
    """
    value = x[name][event]
    return -1 if not np.isfinite(value) else int(value > threshold if strict else value >= threshold)


def _risks(arrays: list, side: int, event: int) -> dict:
    """
    機能: 実方向の背景圧力と元方向の突破スパイクを三値で分ける。
    引数: arrays(list[dict])、side(int)は実際に取る側、event(int)。
    返り値: dictはrisk6/risk4_adx/spike/combinedと背景不足・逆向き数。
    """
    x = arrays[side]; source = arrays[1-side]
    all_known = all(np.isfinite(x[name][event]) for name in BACKGROUND)
    opposite = sum(x[name][event] < 0 for name in BACKGROUND) if all_known else -1
    risk6 = int(opposite == 6) if all_known else -1
    adx_known = P._known(x, event, 'm15_adx', 'm15_adx_delta')
    risk4 = (int(opposite >= 4 and x['m15_adx'][event] >= 25 and x['m15_adx_delta'][event] > 0)
             if all_known and adx_known else -1)
    price = _compare(source, event, 'q0_last_minus_prior3_forward_edge_atr5_to_side', .5, True)
    volume = _compare(source, event, 'm1_volume_relative_prior3', 1.5)
    ranges = _or([_compare(source, event, 'm1_tr_atr5_ratio', 1.5),
                  _compare(source, event, 'm5_tr_previous_atr_ratio', 2)])
    spike = _and([price, volume, ranges])
    return {'risk6': risk6, 'risk4_adx': risk4, 'spike': spike,
        'combined': _or([risk4, spike]), 'background_unknown': not all_known,
        'adx_unknown': not adx_known, 'opposite_count': opposite}


def build(features: object, base_bundle: dict, candidate_ids: list | None = None) -> dict:
    """
    機能: 旧幹・無条件確認対照と、圧力局面だけ確認する二案の純方向を作る。
    引数: features(FeatureDataset互換)、base_bundle(dict)、candidate_ids(list[str]|None)。
    返り値: dictはcandidate_ids/bundles/diagnostics。APIは181と同型。
    """
    mapping = {r['id']: r for r in catalog()['rules']}
    ids = list(mapping) if candidate_ids is None else candidate_ids
    assert len(set(ids)) == len(ids) and set(ids) <= set(mapping)
    inherited_ids = [mapping[key]['mode'] for key in ids if mapping[key]['mode'].startswith('E181_')]
    inherited = P.build(features, base_bundle, inherited_ids)
    arrays, meta, times, phases, reset = _prepare(features)
    base, bo_rows, mp_rows = V1._base(base_bundle, len(meta), phases)
    risk = {key: np.full(len(meta), -1, np.int8) for key in
        ('risk6', 'risk4_adx', 'spike', 'combined', 'opposite_count')}
    background_unknown = np.zeros(len(meta), bool); adx_unknown = np.zeros(len(meta), bool)
    for i in np.flatnonzero(bo_rows):
        value = _risks(arrays, 0 if base['birth']['core'][i] == 1 else 1, int(i))
        for key in risk: risk[key][i] = value[key]
        background_unknown[i] = value['background_unknown']; adx_unknown[i] = value['adx_unknown']
    bundles = {}; diagnostics = {}
    for identity in ids:
        mode = mapping[identity]['mode']
        if mode.startswith('E181_'):
            bundles[identity] = inherited['bundles'][mode]
            diagnostics[identity] = inherited['diagnostics'][mode]
            continue
        output = {'birth': {k: v.copy() for k, v in base['birth'].items()},
            **{k: base[k].copy() for k in ('mw', 'fw', 'hi', 'added')}}
        classification = risk['risk6'] if mode == 'RISK6' else risk['combined']
        selected = bo_rows & (classification == 1)
        core = output['birth']['core']; core[selected] = 0
        output['birth']['branches'][selected] = -1
        output['birth']['technical'][selected] = 0; output['birth']['tier'][selected] = 0
        confirmed = np.zeros(len(meta), bool); pending_rows = np.zeros(len(meta), bool)
        setup_at = np.full(len(meta), -1, np.int64); pending_sides = np.full(len(meta), -1, np.int8)
        roles = {}; pending_direction = 0; pending_event = -1
        for i in range(len(meta)):
            if reset[i] or phases[i] != 0:
                pending_direction = 0; pending_event = -1
            if pending_event >= 0 and times[i]-times[pending_event] > 900:
                pending_direction = 0; pending_event = -1
            if bo_rows[i]:
                if selected[i]:
                    fresh = int(base['birth']['core'][i])
                    if fresh != pending_direction:
                        pending_direction = fresh; pending_event = i
                else:
                    pending_direction = 0; pending_event = -1
            if pending_event < 0 or times[i] <= times[pending_event] or core[i] != 0:
                continue
            side = 0 if pending_direction == 1 else 1
            pending_rows[i] = True; pending_sides[i] = side
            value = P._early_roles(arrays[side], i, pending_event)
            for key, yes in value.items():
                if key not in roles: roles[key] = np.zeros(len(meta), bool)
                roles[key][i] = yes
            if all(value.values()):
                core[i] = pending_direction; output['birth']['branches'][i] = 0
                output['birth']['technical'][i] = 0; output['birth']['tier'][i] = 0
                output['mw'][i] = output['fw'][i] = 350; output['hi'][i] = 1; output['added'][i] = False
                confirmed[i] = True; setup_at[i] = pending_event
                pending_direction = 0; pending_event = -1
        bundles[identity] = output
        diagnostics[identity] = {'bo_setup': bo_rows.copy(), 'mp_setup': mp_rows.copy(),
            'risk_setup': selected, 'risk_unknown': bo_rows & (classification == -1),
            'background_unknown': background_unknown.copy(), 'adx_unknown': adx_unknown.copy(),
            **{k: v.copy() for k, v in risk.items()},
            'rejected': selected, 'bo_confirmed': confirmed, 'bo_setup_event': setup_at,
            'eligible_pending': pending_rows, 'pending_side': pending_sides,
            **{'role_'+key: value for key, value in roles.items()}}
        protected = (phases != 0) | mp_rows | base['added'].astype(bool)
        assert all(np.array_equal(output['birth'][k][protected], base['birth'][k][protected]) for k in base['birth'])
        assert all(np.array_equal(output[k][protected], base[k][protected]) for k in ('mw', 'fw', 'hi', 'added'))
    return {'version': VERSION, 'candidate_ids': ids, 'bundles': bundles, 'diagnostics': diagnostics,
        'common_diagnostics': {'reset': reset, **risk, 'background_unknown': background_unknown}}


def write_catalog(path: Path) -> None:
    """
    機能: 新182の四候補と継承Source指紋を金融前に新規保存する。
    引数: path(Path)。
    返り値: None。旧181を改変しない。
    """
    assert not path.exists()
    sources = []
    for source in (Path(__file__), Path(V1.__file__), Path(P.__file__)):
        sources.append({'path': source.relative_to(ROOT).as_posix(), 'bytes': source.stat().st_size,
            'sha256': hashlib.sha256(source.read_bytes()).hexdigest()})
    path.write_text(json.dumps({**catalog(), 'Source': sources, '新182金融未入力': True},
        ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')
