"""181旧8案を保持し、直近失速と早期構造回復を分けた8案を追加する。"""
from pathlib import Path
import hashlib
import json
import numpy as np
import rules181 as V1

ROOT = V1.ROOT
VERSION = '181純入口追加版2'
EXTRA_COLUMNS = tuple(sorted({
    'm5_hist_to_side', 'm1_previous_body_ratio_to_side', 'm1_close_position_to_side',
    'm15_hist_delta_to_side', 'm15_adx_delta',
    *[f'm{m}_{field}' for m in (5, 15, 30) for field in
      ('ema21_delta_to_side', 'di_difference_to_side')]}))


def catalog() -> dict:
    """
    機能: 旧8案を保持し、MP緩和・BO早期回復と厳格位置緩和の8案を加える。
    引数: なし。
    返り値: dictは計16候補の固定定義。金融・自然特徴を読まない。
    """
    settings = [('KEEP', 1.5), ('KEEP', 2.), ('EARLY15', None), ('EARLY30', None),
        ('EARLY15', 1.5), ('EARLY30', 2.), ('STRICT30', None), ('STRICT30', 1.5)]
    rules = []
    for number, (bo, mp) in enumerate(settings, 8):
        rules.append({'id': f'E181_{number:02d}', 'source_version': 2, 'bo': bo,
            'mp': 'KEEP' if mp is None else 'SOFT', 'mp_position_max': mp,
            'bo_window_seconds': None if bo == 'KEEP' else 900 if bo == 'EARLY15' else 1800,
            'bo_position': None if bo == 'KEEP' else [(-.25 if bo == 'STRICT30' else -1.), 1.5],
            'description': bo + ('＋旧MP' if mp is None else f'＋MP位置上限{mp}ATRと明確な直近失速の除外')})
    return {'version': VERSION, 'candidate_count': 16,
        'rules': [{**r, 'source_version': 1} for r in V1.catalog()['rules']] + rules,
        'raw_columns': sorted(set(V1.RAW_COLUMNS) | set(EXTRA_COLUMNS)),
        '旧版保持': 'E181_00〜07とrules181.py・候補辞書181.json・純出生は変更しない。',
        'early_roles': {
            'pressure': 'セットアップ時の実方向5分Hist増分/RSI増分より現在が共に悪化していない。又は実方向Hist値・RSI中心がセットアップ時より共に改善。両代替とも必要値既知。',
            'structure': '1分実体>0、価格進行>0、live>0、かつ前1分実体<=0又は現在の直前3分順方向端差>0又は1分終値位置>=.65。全て取得実方向で評価。',
            'background': '5/15/30分のいずれか一足でEMA21傾き又はDI差が実方向>0（その足の両列既知）。又は既知15分Hist増分>=0、又は既知15分ADX増分<=0。ADXは向きでなく元圧力失速の別情報。',
            'position': '取得側−EMA8は−1〜1.5ATR5。既知。',
            'volume': '1分相対量>=.5。平常以上の量を意味しない。',
            'quality': 'スプレッド>0かつ<=20、q0Last−1分終値絶対値<=1ATR5、1分TR/ATR5<=2、5分TR/前ATR<=3。既知。RSI高止まりだけの禁止なし。'},
        'strict_roles': 'v1の厳格確認を保持し、取得側−EMA8上限だけ.75→1.5ATR5へ分ける。',
        'mp_soft': {'position_min': -.5, 'position_max': [1.5, 2.],
            'clear_failure': '既知1分実体<0、価格進行<0、live<=0が同時なら除外。単に正値が全て揃わないだけでは除外しない。',
            'shock': '1分TR/ATR5>2又は5分TR/前ATR>3、かつRSI増分絶対値>8又は相対量>2.5が同時なら除外。',
            'rsi': '中心値の水準だけでは禁止しない。元MPのRSI/MACD/ADX/量は保持。',
            'unknown': '位置と失速/スパイク判定の必要列は全既知。'},
        'state_priority_unknown': V1.catalog()['state']+' '+V1.catalog()['priority']+' '+V1.catalog()['unknown'],
        'finance': '純Sourceは金融・保有・将来到達・出口成績を入力しない。既使用81場であり未見検証ではない。',
        '追加版の理由': 'v1非金融で位置.75がボトルネック、厳格MPが全拒否。元8案と金融結果を見ずに代替仮説を追加。'}


def _prepare(features: object) -> tuple:
    """
    機能: 旧181の時計と純列へ、早期回復の背景・価格列を追加する。
    引数: features(FeatureDataset互換)。
    返り値: tupleは側別列、q0、秒、帯、reset。
    """
    arrays, meta, times, phases, reset = V1._prepare(features)
    columns = [c['name'] if isinstance(c, dict) else c for c in V1._feature(features, 'columns')]
    assert set(EXTRA_COLUMNS) <= set(columns)
    index = {name: i for i, name in enumerate(columns)}
    for side, key in enumerate(('buy_X', 'sell_X')):
        matrix = np.asarray(V1._feature(features, key), dtype=np.float64)
        arrays[side].update({name: matrix[:, index[name]] for name in EXTRA_COLUMNS})
    return arrays, meta, times, phases, reset


def _known(x: dict, event: int, *names: str) -> bool:
    """
    機能: 一パターンの必要列が全有限かを確認する。
    引数: x(dict[str,np.ndarray])、event(int)、names(tuple[str])。
    返り値: bool。未知を0として補完しない。
    """
    return all(np.isfinite(x[name][event]) for name in names)


def _mp_roles(x: dict, event: int, upper: float) -> dict:
    """
    機能: 強いトレンドをRSI水準だけで切らず、位置と明確な直近崩れを確認する。
    引数: x(dict[str,np.ndarray])、event(int)、upper(float)は1.5又は2ATR。
    返り値: dict[str,bool]は役割ごとの既知かつ成立。
    """
    position = _known(x, event, 'q0_entry_minus_ema8_atr5_to_side') and -.5 <= x['q0_entry_minus_ema8_atr5_to_side'][event] <= upper
    live_known = _known(x, event, 'm1_body_ratio_to_side', 'm1_close_delta_atr5_to_side',
        'm1_body_reclaim_atr5_to_side', 'q0_last_minus_m1_close_atr5_to_side')
    failure = (live_known and x['m1_body_ratio_to_side'][event] < 0
        and x['m1_close_delta_atr5_to_side'][event] < 0
        and x['m1_body_reclaim_atr5_to_side'][event]+x['q0_last_minus_m1_close_atr5_to_side'][event] <= 0)
    shock_known = _known(x, event, 'm1_tr_atr5_ratio', 'm5_tr_previous_atr_ratio',
        'm5_rsi_delta_to_side', 'm1_volume_relative_prior3')
    shock = (shock_known and (x['m1_tr_atr5_ratio'][event] > 2 or x['m5_tr_previous_atr_ratio'][event] > 3)
        and (abs(x['m5_rsi_delta_to_side'][event]) > 8 or x['m1_volume_relative_prior3'][event] > 2.5))
    return {'position': bool(position), 'no_clear_failure': bool(live_known and not failure),
            'no_shock': bool(shock_known and not shock)}


def _early_roles(x: dict, event: int, setup: int) -> dict:
    """
    機能: 元圧力が拡大しない間の1分構造回復を、実方向・当時値で確認する。
    引数: x(dict[str,np.ndarray])、event/setup(int)は現在と元BO出生。
    返り値: dict[str,bool]は圧力・構造・背景・位置・量・品質の成立。
    """
    delta_names = ('m5_hist_delta_to_side', 'm5_rsi_delta_to_side')
    pressure_a = (_known(x, event, *delta_names) and _known(x, setup, *delta_names)
        and all(x[name][event] >= x[name][setup] for name in delta_names))
    level_names = ('m5_hist_to_side', 'm5_rsi_center_to_side')
    pressure_b = (_known(x, event, *level_names) and _known(x, setup, *level_names)
        and all(x[name][event] > x[name][setup] for name in level_names))
    live_names = ('m1_body_ratio_to_side', 'm1_close_delta_atr5_to_side',
        'm1_body_reclaim_atr5_to_side', 'q0_last_minus_m1_close_atr5_to_side')
    live = (_known(x, event, *live_names) and x['m1_body_ratio_to_side'][event] > 0
        and x['m1_close_delta_atr5_to_side'][event] > 0
        and x['m1_body_reclaim_atr5_to_side'][event]+x['q0_last_minus_m1_close_atr5_to_side'][event] > 0)
    triggers = [(_known(x, event, 'm1_previous_body_ratio_to_side') and x['m1_previous_body_ratio_to_side'][event] <= 0),
        (_known(x, event, 'q0_last_minus_prior3_forward_edge_atr5_to_side') and x['q0_last_minus_prior3_forward_edge_atr5_to_side'][event] > 0),
        (_known(x, event, 'm1_close_position_to_side') and x['m1_close_position_to_side'][event] >= .65)]
    background = False
    for m in (5, 15, 30):
        a, b = f'm{m}_ema21_delta_to_side', f'm{m}_di_difference_to_side'
        background |= _known(x, event, a, b) and (x[a][event] > 0 or x[b][event] > 0)
    background |= _known(x, event, 'm15_hist_delta_to_side') and x['m15_hist_delta_to_side'][event] >= 0
    background |= _known(x, event, 'm15_adx_delta') and x['m15_adx_delta'][event] <= 0
    position = _known(x, event, 'q0_entry_minus_ema8_atr5_to_side') and -1 <= x['q0_entry_minus_ema8_atr5_to_side'][event] <= 1.5
    volume = _known(x, event, 'm1_volume_relative_prior3') and x['m1_volume_relative_prior3'][event] >= .5
    quality_names = ('q0_spread_points', 'q0_last_minus_m1_close_atr5_to_side',
        'm1_tr_atr5_ratio', 'm5_tr_previous_atr_ratio')
    quality = (_known(x, event, *quality_names) and 0 < x['q0_spread_points'][event] <= 20
        and abs(x['q0_last_minus_m1_close_atr5_to_side'][event]) <= 1
        and x['m1_tr_atr5_ratio'][event] <= 2 and x['m5_tr_previous_atr_ratio'][event] <= 3)
    return {key: bool(value) for key, value in {'pressure': pressure_a or pressure_b,
        'structure': live and any(triggers), 'background': background,
        'volume': volume, 'position': position, 'quality': quality}.items()}


def _strict_roles(x: dict, event: int, structure: bool) -> dict:
    """
    機能: 旧181の厳格確認の役割を維持し、価格上限だけ1.5へ広げる。
    引数: x(dict[str,np.ndarray])、event(int)、structure(bool)は旧価格構造。
    返り値: dict[str,bool]は厳格確認・位置の成立。必要列未知は不成立。
    """
    names = ['q0_entry_minus_ema8_atr5_to_side', 'm1_body_ratio_to_side',
        'm1_close_delta_atr5_to_side', 'm1_body_reclaim_atr5_to_side',
        'q0_last_minus_m1_close_atr5_to_side', 'm5_rsi_center_to_side', 'm5_rsi_delta_to_side',
        'm1_tr_atr5_ratio', 'm5_tr_previous_atr_ratio', 'm5_hist_delta_to_side',
        'm5_ema21_delta_to_side', 'm5_di_difference_to_side', 'm1_volume_relative_prior3', 'q0_spread_points']
    known = _known(x, event, *names)
    if not known:
        return {'strict_confirmation': False, 'position': False}
    result = (structure and x['m1_body_ratio_to_side'][event] > 0
        and x['m1_close_delta_atr5_to_side'][event] >= 0
        and x['m1_body_reclaim_atr5_to_side'][event]+x['q0_last_minus_m1_close_atr5_to_side'][event] > 0
        and -10 <= x['m5_rsi_center_to_side'][event] <= 20 and abs(x['m5_rsi_delta_to_side'][event]) <= 8
        and x['m1_tr_atr5_ratio'][event] <= 1.5 and x['m5_tr_previous_atr_ratio'][event] <= 2
        and x['m5_hist_delta_to_side'][event] >= 0 and x['m5_rsi_delta_to_side'][event] > 0
        and (x['m5_ema21_delta_to_side'][event] > 0 or x['m5_di_difference_to_side'][event] > 0)
        and x['m1_volume_relative_prior3'][event] >= .75
        and 0 < x['q0_spread_points'][event] <= 20 and abs(x['q0_last_minus_m1_close_atr5_to_side'][event]) <= 1)
    return {'strict_confirmation': bool(result),
        'position': bool(-.25 <= x['q0_entry_minus_ema8_atr5_to_side'][event] <= 1.5)}


def build(features: object, base_bundle: dict, candidate_ids: list | None = None) -> dict:
    """
    機能: 旧8案を同体保持して、解釈可能な緩和8案の純方向を生成する。
    引数: features(FeatureDataset互換)、base_bundle(dict)、candidate_ids(list[str]|None)。
    返り値: dictは旧APIと同じbundles/diagnosticsに、計16候補を保持する。
    """
    mapping = {r['id']: r for r in catalog()['rules']}
    ids = list(mapping) if candidate_ids is None else candidate_ids
    assert len(set(ids)) == len(ids) and set(ids) <= set(mapping)
    old_ids = [key for key in ids if mapping[key]['source_version'] == 1]
    old = V1.build(features, base_bundle, old_ids)
    arrays, meta, times, phases, reset = _prepare(features)
    base, bo_rows, mp_rows = V1._base(base_bundle, len(meta), phases)
    structure = V1._structures(arrays, times, reset)
    bundles = dict(old['bundles']); diagnostics = dict(old['diagnostics'])
    for identity in ids:
        rule = mapping[identity]
        if rule['source_version'] == 1:
            continue
        output = {'birth': {k: v.copy() for k, v in base['birth'].items()},
            **{k: base[k].copy() for k in ('mw', 'fw', 'hi', 'added')}}
        rejected = np.zeros(len(meta), bool)
        if rule['bo'] != 'KEEP': rejected |= bo_rows
        mp_flags = {key: np.ones(len(meta), bool) for key in ('position', 'no_clear_failure', 'no_shock')}
        if rule['mp'] != 'KEEP':
            for i in np.flatnonzero(mp_rows):
                role = _mp_roles(arrays[0 if base['birth']['core'][i] == 1 else 1], i, rule['mp_position_max'])
                for key, value in role.items(): mp_flags[key][i] = value
                if not all(role.values()): rejected[i] = True
        core = output['birth']['core']; core[rejected] = 0
        output['birth']['branches'][rejected] = -1
        output['birth']['technical'][rejected] = 0; output['birth']['tier'][rejected] = 0
        confirmed = np.zeros(len(meta), bool); setup_at = np.full(len(meta), -1, np.int64)
        pending_rows = np.zeros(len(meta), bool); pending_sides = np.full(len(meta), -1, np.int8)
        role_rows = {}
        if rule['bo_window_seconds'] is not None:
            pending_direction = 0; pending_event = -1
            for i in range(len(meta)):
                if reset[i] or phases[i] != 0:
                    pending_direction = 0; pending_event = -1
                if pending_event >= 0 and times[i]-times[pending_event] > rule['bo_window_seconds']:
                    pending_direction = 0; pending_event = -1
                if bo_rows[i]:
                    direction = int(base['birth']['core'][i])
                    if direction != pending_direction: pending_direction = direction; pending_event = i
                if pending_event < 0 or times[i] <= times[pending_event] or core[i] != 0: continue
                side = 0 if pending_direction == 1 else 1
                pending_rows[i] = True; pending_sides[i] = side
                role = (_strict_roles(arrays[side], i, bool(structure[side, i])) if rule['bo'] == 'STRICT30'
                    else _early_roles(arrays[side], i, pending_event))
                for key, value in role.items():
                    if key not in role_rows: role_rows[key] = np.zeros(len(meta), bool)
                    role_rows[key][i] = value
                if all(role.values()):
                    core[i] = pending_direction; output['birth']['branches'][i] = 0
                    output['birth']['technical'][i] = 0; output['birth']['tier'][i] = 0
                    output['mw'][i] = output['fw'][i] = 350; output['hi'][i] = 1; output['added'][i] = False
                    confirmed[i] = True; setup_at[i] = pending_event
                    pending_direction = 0; pending_event = -1
        bundles[identity] = output
        diagnostics[identity] = {'bo_setup': bo_rows.copy(), 'mp_setup': mp_rows.copy(),
            'rejected': rejected, 'bo_confirmed': confirmed, 'bo_setup_event': setup_at,
            'eligible_pending': pending_rows, 'pending_side': pending_sides,
            **{'role_'+key: value for key, value in role_rows.items()},
            **{'mp_role_'+key: value for key, value in mp_flags.items()}}
        night = phases != 0
        assert all(np.array_equal(output['birth'][k][night], base['birth'][k][night]) for k in base['birth'])
        assert all(np.array_equal(output[k][night], base[k][night]) for k in ('mw', 'fw', 'hi', 'added'))
    return {'version': VERSION, 'candidate_ids': ids,
        'bundles': {key: bundles[key] for key in ids},
        'diagnostics': {key: diagnostics[key] for key in ids}, 'common_diagnostics': old['common_diagnostics']}


def write_catalog(path: Path) -> None:
    """
    機能: 追加版の全16候補と新旧Source指紋を金融前に新規保存する。
    引数: path(Path)。
    返り値: None。旧辞書と旧Sourceは変更しない。
    """
    assert not path.exists()
    sources = []
    for file in (Path(__file__), Path(V1.__file__)):
        sources.append({'path': file.relative_to(ROOT).as_posix(), 'bytes': file.stat().st_size,
            'sha256': hashlib.sha256(file.read_bytes()).hexdigest()})
    path.write_text(json.dumps({**catalog(), 'Source': sources, '金融未入力': True},
        ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')
