"""旧179デイのBOを確認待ちへ分け、MPの取得位置を確認する純入口。"""
from pathlib import Path
from itertools import product
import hashlib
import json
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
VERSION = '181固定BOの確認待ちとMP位置確認1'
RAW_COLUMNS = tuple(sorted({
    'm5_hist_delta_to_side', 'm5_rsi_delta_to_side', 'm5_rsi_center_to_side',
    'm5_ema21_delta_to_side', 'm5_di_difference_to_side',
    'm1_body_ratio_to_side', 'm1_body_reclaim_atr5_to_side',
    'm1_close_delta_atr5_to_side', 'q0_last_minus_m1_close_atr5_to_side',
    'q0_entry_minus_ema8_atr5_to_side',
    'q0_last_minus_prior3_forward_edge_atr5_to_side',
    'm1_volume_relative_prior3', 'm1_tr_atr5_ratio',
    'm5_tr_previous_atr_ratio', 'q0_spread_points'}))


def catalog() -> dict:
    """
    機能: BO待ち状態とMP品質確認の直交8案を公開する。
    引数: なし。
    返り値: dictは候補、全閾値、既知性・時計・限界の有限辞書。自然金融を読まない。
    """
    rules = []
    for number, (bo, mp) in enumerate(product(('KEEP', 'DROP', 'WAIT15', 'WAIT30'), ('KEEP', 'QUALITY'))):
        rules.append({'id': f'E181_{number:02d}', 'bo': bo, 'mp': mp,
            'description': {'KEEP': '旧BOそのまま', 'DROP': '旧BO禁止対照',
                'WAIT15': 'BOの反転実方向を15実分以内に確認',
                'WAIT30': 'BOの反転実方向を30実分以内に確認'}[bo]
                + ('＋旧MPそのまま' if mp == 'KEEP' else '＋MP位置と直近価格の確認'),
            'bo_window_seconds': {'KEEP': None, 'DROP': None, 'WAIT15': 900, 'WAIT30': 1800}[bo],
            'bo_confirmation': None if bo in ('KEEP', 'DROP') else {
                'momentum': '5分Hist増分>=0かつ5分RSI増分>0。元BOの実方向では両方<0だった状態から改善する。',
                'short_direction': '5分EMA21傾き>0又は5分DI差>0。両列既知。',
                'price_structure': '過去5実分の既知観測でentry−EMA8<=0、現在>=0、又は直前3分端差<=0、現在>0。いずれかの回復を確認。',
                'live': '1分実体>0、1分価格進行>=0、live>0。live=1分実体回復/ATR5＋q0Last−1分終値/ATR5。',
                'volume_min': .75, 'entry_ema8_atr5_min': -.25, 'entry_ema8_atr5_max': .75,
                'rsi_center_min': -10, 'rsi_center_max': 20,
                'abs_rsi_delta_max': 8, 'm1_tr_atr5_max': 1.5,
                'm5_tr_previous_atr_max': 2, 'spread_max': 20, 'abs_q0_close_gap_max': 1},
            'mp_quality': None if mp == 'KEEP' else {
                'entry_ema8_atr5_min': -.25, 'entry_ema8_atr5_max': .75,
                'm1_body_min_strict': 0, 'm1_advance_min': 0, 'live_min_strict': 0,
                'rsi_center_max': 20, 'abs_rsi_delta_max': 8,
                'm1_tr_atr5_max': 1.5, 'm5_tr_previous_atr_max': 2},
            'width_horizon': '旧BO±350/H60、旧MP±150/H60、LC±400/SESSIONを継承'})
    return {'version': VERSION, 'candidate_count': len(rules), 'rules': rules,
        'raw_columns': list(RAW_COLUMNS),
        'base': '179全期J035の封印済みbirth/mw/fw/hi/added。DAYのBO/MPだけ修正。LCと夜間は固定。',
        'classification': 'DAY core非零でadded=False、幅350/H60をBO、幅150/H60をMPと識別。LCはadded=True。未知のDAY幹は拒否。',
        'state': 'BO出生で反転後の実方向をセットアップとして保存。同方向の追加出生で期限を延長しない。反対BO出生は置換。期限内の後続q0で一度だけ要求。',
        'priority': '旧MP/旧LCの非零coreを先に保持。確認BOはそれらのないq0だけ。保有・予約は後段口座で一件枠を維持する。',
        'fallback': 'BO/MPを拒否した元出生q0でTへ暗黙切替しないようtechnical/tierを0。遅延BO発火時もTを0。その他のTは固定。',
        'clock': '場/scene/限月変更、時刻後退、180秒超gapでセットアップと5実分履歴を消去。NY境界では消去しない。追加一律待機なし。',
        'unknown': '各役割の必要列が既知の時だけ確認。代替構造は既知真が一つあれば可。未知を0票へ補完せず、欠測を跨いで構造履歴を復元しない。',
        'scope': '純方向と継承幅期限だけ。約定・保有・費用・利益保護・将来価格・金融教師は入力しない。',
        'limitations': ['旧81場と11月16日の診断を踏まえるため、同期間の比較を未見検証と呼ばない。',
            '閾値は解釈可能な研究仮説で、公開教材の推奨値や独立投票確率ではない。',
            'BOを単純反転のまま現在動力>0で濾過すると構造上全拒否になるため、確認待ちを別の出生へする。',
            '先着・利益・参加は後段再生まで未確認。入口を減らせば必ず良くなるとは仮定しない。']}


def _feature(features: object, key: str) -> object:
    """
    機能: FeatureDataset互換又は辞書から指定属性だけを読む。
    引数: features(object|dict)、key(str)。
    返り値: objectは指定された純入力。
    """
    return features[key] if isinstance(features, dict) else getattr(features, key)


def _prepare(features: object) -> tuple:
    """
    機能: 必要列と実時間resetを検査し、金融を持たない二側配列へ接続する。
    引数: features(FeatureDataset互換)。
    返り値: tupleは側別列辞書、q0識別、時刻、帯、reset配列。
    """
    columns = [c['name'] if isinstance(c, dict) else c for c in _feature(features, 'columns')]
    assert len(set(columns)) == len(columns) and set(RAW_COLUMNS) <= set(columns)
    index = {name: i for i, name in enumerate(columns)}
    meta = _feature(features, 'q0_meta'); n = len(meta)
    arrays = []
    for name in ('buy_X', 'sell_X'):
        matrix = np.asarray(_feature(features, name), dtype=np.float64)
        assert matrix.shape == (n, len(columns)) and not np.isinf(matrix).any()
        arrays.append({column: matrix[:, index[column]] for column in RAW_COLUMNS})
    times = np.asarray([q['q0_time'] for q in meta], dtype=np.float64)
    phases = np.asarray(_feature(features, 'q0_timeband'), dtype=np.int8)
    assert phases.shape == (n,) and np.isin(phases, (0, 1, 2)).all()
    reset = np.ones(n, bool)
    for i in range(1, n):
        left, right = meta[i-1], meta[i]
        reset[i] = ((right['session'], right['session_index'], right['contract'])
            != (left['session'], left['session_index'], left['contract'])
            or times[i] < times[i-1] or times[i] - times[i-1] > 180)
    return arrays, meta, times, phases, reset


def _guard(values: dict, event: int, bo: bool) -> bool:
    """
    機能: 実方向の当時値だけで価格位置・過熱・直近価格・量等を確認する。
    引数: values(dict[str,np.ndarray])、event(int)、bo(bool)はBO確認又はMP確認。
    返り値: boolは全必要条件が既知かつ成立した場合だけTrue。
    """
    names = ['q0_entry_minus_ema8_atr5_to_side', 'm1_body_ratio_to_side',
        'm1_close_delta_atr5_to_side', 'm1_body_reclaim_atr5_to_side',
        'q0_last_minus_m1_close_atr5_to_side', 'm5_rsi_center_to_side',
        'm5_rsi_delta_to_side', 'm1_tr_atr5_ratio', 'm5_tr_previous_atr_ratio']
    if bo:
        names += ['m5_hist_delta_to_side', 'm5_ema21_delta_to_side', 'm5_di_difference_to_side',
                  'm1_volume_relative_prior3', 'q0_spread_points']
    if not all(np.isfinite(values[name][event]) for name in names):
        return False
    x = {name: values[name][event] for name in names}
    good = (-.25 <= x['q0_entry_minus_ema8_atr5_to_side'] <= .75
        and x['m1_body_ratio_to_side'] > 0 and x['m1_close_delta_atr5_to_side'] >= 0
        and x['m1_body_reclaim_atr5_to_side'] + x['q0_last_minus_m1_close_atr5_to_side'] > 0
        and x['m5_rsi_center_to_side'] <= 20 and abs(x['m5_rsi_delta_to_side']) <= 8
        and x['m1_tr_atr5_ratio'] <= 1.5 and x['m5_tr_previous_atr_ratio'] <= 2)
    if bo:
        good = (good and x['m5_hist_delta_to_side'] >= 0 and x['m5_rsi_delta_to_side'] > 0
            and (x['m5_ema21_delta_to_side'] > 0 or x['m5_di_difference_to_side'] > 0)
            and x['m5_rsi_center_to_side'] >= -10 and x['m1_volume_relative_prior3'] >= .75
            and 0 < x['q0_spread_points'] <= 20
            and abs(x['q0_last_minus_m1_close_atr5_to_side']) <= 1)
    return bool(good)


def _structures(arrays: list, times: np.ndarray, reset: np.ndarray) -> np.ndarray:
    """
    機能: 過去5実分に見えた価格位置からEMA8又は価格端の回復を確認する。
    引数: arrays(list[dict])、times(np.ndarray[N])、reset(np.ndarray[bool,N])。
    返り値: np.ndarray[bool,2,N]は側別構造回復。現在より後の行は使わない。
    """
    n = len(times); output = np.zeros((2, n), bool); segment = 0
    names = ('q0_entry_minus_ema8_atr5_to_side', 'q0_last_minus_prior3_forward_edge_atr5_to_side')
    for i in range(n):
        if reset[i]:
            segment = i
        left = max(segment, int(np.searchsorted(times[segment:i+1], times[i]-300, side='left'))+segment)
        for side in (0, 1):
            for name in names:
                current = arrays[side][name][i]
                prior = arrays[side][name][left:i]
                missing = np.flatnonzero(~np.isfinite(prior))
                if len(missing):
                    prior = prior[int(missing[-1])+1:]
                seen_below = np.any(np.isfinite(prior) & (prior <= 0))
                recovered = current >= 0 if name == names[0] else current > 0
                if np.isfinite(current) and recovered and seen_below:
                    output[side, i] = True
    return output


def _base(bundle: dict, n: int, phases: np.ndarray) -> tuple:
    """
    機能: 179全期J035の封印済み出生を複写し、DAYのBO/MP/LCを識別する。
    引数: bundle(dict)はbirth/mw/fw/hi/added、n(int)、phases(np.ndarray)。
    返り値: tupleは複写bundle、BO行、MP行。入力を変更しない。
    """
    assert set(bundle) >= {'birth', 'mw', 'fw', 'hi', 'added'}
    result = {'birth': {k: np.asarray(bundle['birth'][k]).copy()
        for k in ('core', 'branches', 'technical', 'tier')},
        **{k: np.asarray(bundle[k]).copy() for k in ('mw', 'fw', 'hi', 'added')}}
    assert all(value.shape == (n,) for value in result['birth'].values())
    assert all(result[k].shape == (n,) for k in ('mw', 'fw', 'hi', 'added'))
    assert np.isin(result['birth']['core'], (-1, 0, 1)).all()
    day_core = (phases == 0) & (result['birth']['core'] != 0)
    bo = day_core & ~result['added'].astype(bool) & (result['mw'] == 350) & (result['fw'] == 350) & (result['hi'] == 1)
    mp = day_core & ~result['added'].astype(bool) & (result['mw'] == 150) & (result['fw'] == 150) & (result['hi'] == 1)
    lc = day_core & result['added'].astype(bool) & (result['mw'] == 400) & (result['fw'] == 400) & (result['hi'] == 3)
    assert np.array_equal(day_core, bo | mp | lc), '179固定DAY幹以外の入力'
    return result, bo, mp


def build(features: object, base_bundle: dict, candidate_ids: list | None = None) -> dict:
    """
    機能: 旧179の全帯出生を基準に、DAYのBO確認待ちとMP品質確認を純生成する。
    引数: features(FeatureDataset互換)、base_bundle(dict)は179全期J035固定出生、
          candidate_ids(list[str]|None)は公開8案の部分集合。
    返り値: dictはcandidate_ids、bundles[id]={birth,mw,fw,hi,added}、純diagnostics。
    """
    arrays, meta, times, phases, reset = _prepare(features)
    base, bo_rows, mp_rows = _base(base_bundle, len(meta), phases)
    rules = catalog()['rules']; mapping = {r['id']: r for r in rules}
    if candidate_ids is not None:
        assert len(set(candidate_ids)) == len(candidate_ids) and set(candidate_ids) <= set(mapping)
        rules = [mapping[key] for key in candidate_ids]
    structure = _structures(arrays, times, reset)
    bo_good = np.asarray([[_guard(arrays[s], i, True) and structure[s, i]
        for i in range(len(meta))] for s in (0, 1)], dtype=bool)
    mp_good = np.asarray([[_guard(arrays[s], i, False) for i in range(len(meta))]
        for s in (0, 1)], dtype=bool)
    bundles = {}; diagnostics = {}
    for rule in rules:
        output = {'birth': {k: v.copy() for k, v in base['birth'].items()},
            **{k: base[k].copy() for k in ('mw', 'fw', 'hi', 'added')}}
        core = output['birth']['core']; rejected = np.zeros(len(meta), bool)
        if rule['bo'] != 'KEEP':
            rejected |= bo_rows
        if rule['mp'] == 'QUALITY':
            for i in np.flatnonzero(mp_rows):
                if not mp_good[0 if base['birth']['core'][i] == 1 else 1, i]:
                    rejected[i] = True
        core[rejected] = 0
        output['birth']['branches'][rejected] = -1
        output['birth']['technical'][rejected] = 0; output['birth']['tier'][rejected] = 0
        confirmed = np.zeros(len(meta), bool)
        setup_at = np.full(len(meta), -1, np.int64)
        eligible_pending = np.zeros(len(meta), bool)
        pending_side = np.full(len(meta), -1, np.int8)
        if rule['bo_window_seconds'] is not None:
            pending_direction = 0; pending_event = -1
            for i in range(len(meta)):
                if reset[i] or phases[i] != 0:
                    pending_direction = 0; pending_event = -1
                if pending_event >= 0 and times[i] - times[pending_event] > rule['bo_window_seconds']:
                    pending_direction = 0; pending_event = -1
                if bo_rows[i]:
                    fresh = int(base['birth']['core'][i])
                    if fresh != pending_direction:
                        pending_direction = fresh; pending_event = i
                if pending_event < 0 or times[i] <= times[pending_event] or core[i] != 0:
                    continue
                side = 0 if pending_direction == 1 else 1
                eligible_pending[i] = True; pending_side[i] = side
                if bo_good[side, i]:
                    core[i] = pending_direction; output['birth']['branches'][i] = 0
                    output['birth']['technical'][i] = 0; output['birth']['tier'][i] = 0
                    output['mw'][i] = output['fw'][i] = 350; output['hi'][i] = 1
                    output['added'][i] = False
                    confirmed[i] = True; setup_at[i] = pending_event
                    pending_direction = 0; pending_event = -1
        bundles[rule['id']] = output
        diagnostics[rule['id']] = {'bo_setup': bo_rows.copy(), 'mp_setup': mp_rows.copy(),
            'rejected': rejected, 'bo_confirmed': confirmed, 'bo_setup_event': setup_at,
            'eligible_pending': eligible_pending, 'pending_side': pending_side}
        night = phases != 0
        assert all(np.array_equal(output['birth'][k][night], base['birth'][k][night]) for k in base['birth'])
        assert all(np.array_equal(output[k][night], base[k][night]) for k in ('mw', 'fw', 'hi', 'added'))
    return {'version': VERSION, 'candidate_ids': [r['id'] for r in rules],
        'bundles': bundles, 'diagnostics': diagnostics,
        'common_diagnostics': {'reset': reset, 'bo_ready': bo_good, 'mp_ready': mp_good}}


def write_catalog(path: Path) -> None:
    """
    機能: 候補の全定義を金融前のUTF-8 JSONへ保存する。
    引数: path(Path)は新規候補辞書。
    返り値: None。既存の固定辞書は上書きしない。
    """
    assert not path.exists()
    source = Path(__file__)
    body = {**catalog(), 'source': {'path': source.relative_to(ROOT).as_posix(),
        'sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'bytes': source.stat().st_size},
        '金融未入力': True}
    path.write_text(json.dumps(body, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')
