"""193の構造非拡大・取得位置・履歴時計を自然金融なしで検査する。"""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
import numpy as np
import rules193 as R

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('人工191_for193',R.ROOT/'work/191要求起点の受容/人工検査.py')
T=importlib.util.module_from_spec(spec);sys.modules[spec.name]=T;spec.loader.exec_module(T)


def fixture(reverse: bool=True) -> tuple:
    """
    機能: 191人工例へ15分MA差を加え、追加確認の既知状態を作る。
    引数: reverse(bool)は反転又は順行。
    返り値: tupleは特徴と旧要求。
    """
    f,b=T.fixture(reverse)
    f.columns=list(f.columns)+['m15_gap_to_side']
    f.buy_X=np.c_[f.buy_X,np.ones(8)];f.sell_X=np.c_[f.sell_X,-np.ones(8)]
    return f,b


def main() -> None:
    """
    機能: prefix/未来改変/鏡像・役割分離・未知・非拡大・位置境界を確認する。
    引数: なし。
    返り値: None。人工結果を保存する。
    """
    count=0;checks=[]
    def check(name: str,a: object,b: object) -> None:
        """
        機能: 人工値と期待値を比較する。
        引数: name(str),a/b(object)。
        返り値: None。不一致時停止。
        """
        nonlocal count
        a,b=np.asarray(a),np.asarray(b);assert a.shape==b.shape and np.array_equal(a,b),(name,a,b)
        count+=a.size;checks.append({'検査':name,'項目':int(a.size),'不一致':0})
    for reverse in (True,False):
        f,b=fixture(reverse);original=R.build(f,b)
        for stop in range(9):
            pf,pb=T.T.sliced(f,b,stop);prefix=R.build(pf,pb)
            for identity in original['candidate_ids']:
                for key,v in T.T.T.flat(original['bundles'][identity]).items():
                    check(f'prefix/{reverse}/{stop}/{identity}/{key}',T.T.T.flat(prefix['bundles'][identity])[key],v[:stop])
        mf,mb=T.T.sliced(f,b,8);mf.buy_X,mf.sell_X=mf.sell_X.copy(),mf.buy_X.copy()
        p={k:v.copy() for k,v in mf.q0_prices.items()};mf.q0_prices['last']=-p['last'];mf.q0_prices['bid']=-p['ask'];mf.q0_prices['ask']=-p['bid']
        for key in ('core','technical'):mb['birth'][key]*=-1
        mirror=R.build(mf,mb)
        for identity in original['candidate_ids']:
            for key,v in T.T.T.flat(original['bundles'][identity]).items():
                check(f'鏡像/{reverse}/{identity}/{key}',T.T.T.flat(mirror['bundles'][identity])[key],-v if key in ('core','technical') else v)
        for stop in (1,3,6):
            pf,pb=T.T.sliced(f,b,8);pf.buy_X[stop:]=np.nan;pf.sell_X[stop:]=np.nan;pf.q0_prices['last'][stop:]+=99999
            future=R.build(pf,pb)
            for identity in original['candidate_ids']:
                for key,v in T.T.T.flat(original['bundles'][identity]).items():
                    check(f'未来/{reverse}/{stop}/{identity}/{key}',T.T.T.flat(future['bundles'][identity])[key][:stop],v[:stop])
    # ----------------------------------------
    f,b=fixture(True);out=R.build(f,b)
    check('構造収縮後に反転を再開',out['diagnostics']['E193_04']['reverse_confirmed'][3],True)
    check('厳でも異なる背景更新後に再開',out['diagnostics']['E193_05']['reverse_confirmed'][3],True)
    check('元幅を保持',out['bundles']['E193_05']['mw'][3],350)
    for column in ('m5_gap_to_side','m15_gap_to_side','m15_ema21_delta_to_side'):
        f,b=fixture(True);j=f.columns.index(column);f.buy_X[1:,j]=3;f.sell_X[1:,j]=-3;out=R.build(f,b)
        check('元構造拡大を拒否/'+column,out['diagnostics']['E193_04']['reverse_confirmed'].any(),False)
    f,b=fixture(True);j=f.columns.index('m15_gap_to_side');f.buy_X[1:,j]=f.sell_X[1:,j]=np.nan;out=R.build(f,b)
    check('未知の中期MA差は収束でない',out['diagnostics']['E193_04']['reverse_confirmed'].any(),False)
    check('反転不明は元母集団を消さない',len(out['bundles']['E193_04']['mw']),8)
    # ----------------------------------------
    f,b=fixture(False);out=R.build(f,b)
    check('適切な位置で順行切替',out['diagnostics']['E193_06']['follow_confirmed'][4],True)
    for column,limit in (('q0_entry_minus_ema8_atr5_to_side',1.),('q0_entry_minus_bbmean_sigma_to_side',1.5)):
        f,b=fixture(False);j=f.columns.index(column);f.buy_X[1:,j]=limit+.01;f.sell_X[1:,j]=-limit-.01;out=R.build(f,b)
        check('追過ぎを拒否/'+column,out['diagnostics']['E193_06']['follow_confirmed'].any(),False)
        check('REVのみは位置制限を追加しない/'+column,out['diagnostics']['E193_04']['follow_confirmed'].any(),True)
    f,b=fixture(True)
    for i in range(1,8):f.q0_meta[i]['q0_time']=f.q0_meta[0]['q0_time'];f.q0_prices['time'][i]=f.q0_prices['time'][0]
    out=R.build(f,b);check('同秒はC120を満たさない',out['diagnostics']['E193_04']['reverse_confirmed'].any(),False)
    for kind in ('scene','gap'):
        f,b=fixture(True)
        if kind=='scene':
            for row in f.q0_meta[2:]:row['session']='別_Day';row['session_index']=1
        else:
            for i in range(2,8):f.q0_meta[i]['q0_time']+=181;f.q0_prices['time'][i]+=181
        out=R.build(f,b);check('reset/'+kind,out['diagnostics']['E193_04']['reverse_confirmed'].any(),False)
    proof={'成功':True,'項目':count,'不一致':0,'自然金融未使用':True,'検査':checks,
        'SourceSHA':hashlib.sha256(Path(R.__file__).read_bytes()).hexdigest()}
    (HERE/'人工確認193.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:proof[k] for k in ('成功','項目','不一致')},ensure_ascii=False))


if __name__=='__main__':main()
