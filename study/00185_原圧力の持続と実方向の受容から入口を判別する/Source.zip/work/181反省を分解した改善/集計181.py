"""181の単一建玉再生と、場を残した同一定義の比較を行う。"""
from pathlib import Path
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'work/179保有参加の探索'))
import 基盤179 as M


def pack(context: object, bundle: dict, policy: dict, leg: str) -> dict:
    """
    機能: 新しい決済時計を使い、全後続要求と買売合計1枠を再生する。
    引数: context(object)、bundle(dict)は純入口、policy(dict)、leg(str)は期間。
    返り値: dictは金融・実保有・全取引と要求の監査台帳。
    """
    birth, mw, fw, hi, added = (bundle[k] for k in ('birth', 'mw', 'fw', 'hi', 'added'))
    value = M.replay(context, birth, mw, fw, hi, True, M.B.captures(context))
    selected, origin, wi, his, tier, engine = value
    key = (selected.cases, selected.sides, wi, his)
    known = np.asarray(context.arrays['known'][key], dtype=bool)
    ledger = {'known': known.tolist(), 'label': context.arrays['label'][key].tolist(),
        'scene': [context.sessions[int(s)] for s in context.case_scene[selected.cases]],
        'phase': selected.phases.tolist(), 'origin': origin.tolist(), 'event': selected.events.tolist(),
        'case': selected.cases.tolist(), 'case_id': [context.table.case_ids[int(i)] for i in selected.cases],
        'side': selected.sides.tolist(), 'width': [int(context.table.widths[i]) for i in wi],
        'horizon': [context.table.horizons[i] for i in his],
        'entry_time': context.arrays['entry_time'][selected.cases].tolist(),
        'entry_price': context.arrays['entry_price'][selected.cases, selected.sides].tolist(),
        'entry_index': context.arrays['entry_index'][selected.cases].tolist(),
        'entry_line': context.arrays['entry_line'][selected.cases].tolist(),
        'added': added[selected.events].tolist(), 'leg': [leg] * len(selected.cases)}
    for name in ('net', 'exit_time', 'exit_price'):
        ledger[name] = [float(v) if k else None for v, k in zip(context.arrays[name][key], known, strict=True)]
    for name in ('exit_index', 'exit_line', 'forced', 'status'):
        ledger[name] = context.arrays[name][key].tolist()
    evidence = M.evidence(context, value)
    periods = {leg: evidence}
    if leg == '旧73':
        for label, mask in [('前48', np.arange(len(context.scenes)) < 48),
                            ('後25', np.arange(len(context.scenes)) >= 48)]:
            periods[label] = M.evidence(context, value, mask)
    return {'id': policy['id'], 'policy': policy, 'evidence': evidence, 'periods': periods,
        'ledger': ledger, 'positions': M.positions(context, value), 'sessions': M.session_windows(context),
        'selection': {'cases': selected.cases.tolist(), 'sides': selected.sides.tolist(),
            'events': selected.events.tolist(), 'origins': origin.tolist(),
            'width_indices': wi.tolist(), 'horizon_indices': his.tolist(), 'tiers': tier.tolist()},
        'engine': engine}


def combine(packs: list[dict]) -> dict:
    """
    機能: 同一候補の期間別台帳を結合し、率と中央値を全件から計算し直す。
    引数: packs(list[dict])は旧73・追加7・本日1の同じ政策。
    返り値: dictは全81場の結果。率の平均や未知の0円化をしない。
    """
    assert packs and len({p['id'] for p in packs}) == 1
    ledger = {k: sum((p['ledger'][k] for p in packs), []) for k in packs[0]['ledger']}
    sessions = sum((p['sessions'] for p in packs), [])
    positions = sum((p['positions'] for p in packs), [])
    assert len({s['scene'] for s in sessions}) == len(sessions)
    eligible = {k: [] for k in ('DAY', 'PRE', 'POST')}
    hours = {k: 0. for k in eligible}
    for session in sessions:
        for phase in session['phases']:
            eligible[phase['name']].append(session['scene'])
            hours[phase['name']] += (phase['end'] - phase['start']) / 3600
    financial = M.B.metrics173.evaluate_metrics(ledger['net'], ledger['known'], ledger['label'],
        ledger['scene'], ledger['phase'], ledger['origin'], eligible, hours)
    if M.ACTIVITY is None:
        M.ACTIVITY = M.B.P.module(M.ACTIVITY_PATH, 'activity181_merge')
    holding = M.ACTIVITY.holding_summary(sessions, positions, target_ratio=.2)
    groups = {**financial['phases_diagnostic'], 'NIGHT': financial['session_groups_required']['NIGHT']}
    concentration = {k: M.ACTIVITY.financial_diagnostics(v) for k, v in groups.items()}
    periods = {k: v for p in packs for k, v in p['periods'].items()}
    return {'id': packs[0]['id'], 'policy': packs[0]['policy'],
        'evidence': {'financial': financial, 'holding': holding, 'concentration': concentration},
        'ledger': ledger, 'sessions': sessions, 'positions': positions, 'periods': periods}


def short(evidence: dict, band: str = 'DAY') -> dict:
    """
    機能: 候補比較に必要な金融・参加・集中・期間経路の値を取り出す。
    引数: evidence(dict)、band(str)はDAY/NIGHT/PRE/POST。
    返り値: dictは表示と順位用の同一定義の値。
    """
    finance = evidence['financial']
    group = (finance['session_groups_required'][band] if band in ('DAY', 'NIGHT')
             else finance['phases_diagnostic'][band])
    trade, session = group['trades'], group['sessions']
    diag = evidence['concentration'][band]
    held = evidence['holding']['groups'][band]
    path = diag['path']['known_contribution']
    return {'取引': trade['all_count'], '未知': trade['unknown_count'],
        '利益': trade['known_profit'], '損失': trade['known_loss'], '既知収支': trade['known_net'],
        '利益損失比': trade['known_profit'] / trade['known_loss'] if trade['known_loss'] else None,
        '建玉中央値下限': trade['net_median']['lower'], '場中央値下限': session['net_median']['lower'],
        '両中央値': group['decision']['status'], '参加場': session['participating_count'],
        '全場': session['eligible_count'], '黒字場': session['complete_positive_count'],
        '保有下限': held['held_lower_ratio'], '保有上限': held['held_upper_ratio'],
        '上位3除外後': diag['concentration']['positive_scene_net']['top'][1]['remaining']['known_net'],
        '場末DD': path['max_drawdown_amount'] if path else None,
        '最悪場': path['worst_scene_net'] if path else None}


def rank(row: dict, band: str, baseline: dict, period: str | None = None) -> tuple:
    """
    機能: 金融前に定めた参加・中央値・分散の順位を計算する。
    引数: row/baseline(dict)は候補、band(str)、period(str|None)は前48又は全体。
    返り値: tupleは大きいほど優先。IDは呼出側の昇順安定整列を使用する。
    """
    a = short(row['evidence'] if period is None else row['periods'][period], band)
    b = short(baseline['evidence'] if period is None else baseline['periods'][period], band)
    suitable = (a['両中央値'] == '適合' and a['保有下限'] is not None and a['保有下限'] >= .2
        and a['参加場'] == a['全場'] and a['未知'] <= b['未知'])
    n = max(1, a['全場'])
    return (suitable, a['黒字場'] / n, a['上位3除外後'] / n,
        a['利益損失比'] or 0, -(a['場末DD'] or 0), a['保有下限'] or 0)
