"""終了前決済の新時計を単一建玉再生・保有参加率へ接続する。"""
from pathlib import Path
import copy
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).parent
sys.path.insert(0,str(ROOT/'work/175局面別入口の再探索'))
import 基盤175 as BASE
B=BASE.B
ACTIVITY_PATH=ROOT/'work/179参加時間と利益集中/activity179.py'
ACTIVITY=None


def load_context(new: bool=False, overlay_path: Path | None=None) -> object:
    """
    機能: 共用入力へ179の早期終了金融を重ね、対象時間を15分前までにする。
    引数: new(bool)は追加7、overlay_path(Path|None)は固定後に作った早期終了表。
    返り値: GenericContext。元ファイルや旧Contextの定義は変更しない。
    """
    context=B.load_context(new)
    if overlay_path is not None:
        with np.load(overlay_path,allow_pickle=False) as raw:
            for key in ('label','known','net','exit_time','known_at','holding_confirmed_until','forced','status','exit_price','exit_index','exit_line'):
                if key in raw:
                    assert raw[key].shape==context.arrays['known'].shape,(key,raw[key].shape)
                    context.arrays[key]=raw[key].copy()
            if 'entry_time' in raw:
                assert np.array_equal(raw['entry_time'],context.arrays['entry_time'])
    context.deadlines=np.asarray([s['end']-900 for s in context.scenes],dtype=float)
    context.close_submits=context.deadlines-60
    context.hours=np.zeros((len(context.scenes),3),float)
    data=B.P.R168.BASE.data_module()
    for index,scene in enumerate(context.scenes):
        start=float(scene['start']);end=float(context.deadlines[index])
        if scene['session'].endswith('_Day'):
            context.hours[index,0]=(end-start)/3600
        else:
            boundary=float(data.us_open_time(scene['session']))
            context.hours[index,1]=max(0,min(end,boundary)-start)/3600
            context.hours[index,2]=max(0,end-max(start,boundary))/3600
    return context


def replay(context: object, birth: dict, mw: np.ndarray, fw: np.ndarray,
           event_hi: np.ndarray, fallback: bool=True, descriptors: list | None=None) -> tuple:
    """
    機能: 全決済要求時から新規とpendingを止め、単一建玉の後続要求まで再生する。
    引数: context(object)、birth(dict)、mw/fw/event_hi(np.ndarray)、fallback(bool)、descriptors(list|None)。
    返り値: tupleは旧173と同じSelection/origin/幅添字/期限添字/tier/engine。
    """
    n=len(context.event_keys)
    assert all(len(v)==n for v in (mw,fw,event_hi,birth['core'],birth['technical']))
    times=np.asarray([k[0] for k in context.event_keys])
    active=np.flatnonzero(times<context.close_submits[context.event_scenes])
    captures=B.captures(context) if descriptors is None else descriptors
    clipped=[]
    for event in active:
        row=copy.deepcopy(captures[int(event)])
        stop=float(context.close_submits[context.event_scenes[event]])
        clock=tuple(row['fill_key'] if row['status']=='filled' else row['finish_key'])
        if clock[0]>=stop:
            row={'status':'cancelled','finish_key':(stop,float('inf'),float('inf')),
                 'reason':'終了前の予定全決済要求による新規予約取消'}
        clipped.append(row)
    widths={int(w):i for i,w in enumerate(context.table.widths)}
    default_hi=context.table.horizons.index('H60')

    def exit_lookup(event: int, case: int, side: int, width: int) -> float | None:
        """
        機能: subeventを元q0へ戻し、改訂表の既知決済時刻だけを返す。
        引数: event/case/side/width(int)。
        返り値: float|None。未知を決済済みと扱わない。
        """
        original=int(active[event]);hi=int(event_hi[original]) if birth['core'][original]!=0 else default_hi
        key=(case,side,widths[width],hi)
        if not context.arrays['known'][key]:return None
        result=float(context.arrays['exit_time'][key])
        assert context.arrays['entry_time'][case]<=result<=context.deadlines[context.case_scene[case]]
        return result

    technical=birth['technical'] if fallback else np.zeros(n,np.int8)
    tiers=birth['tier'] if fallback else np.zeros(n,np.int8)
    result=B.engine173.replay([context.event_keys[i] for i in active],context.event_scenes[active],
        np.asarray([s['start'] for s in context.scenes]),context.deadlines,clipped,
        birth['core'][active],birth['branches'][active],technical[active],tiers[active],
        mw[active],fw[active],200,exit_lookup,capacity=1)
    for row in result['records']+result['requests']:
        row['event']=int(active[row['event']])
    rows=result['records'];events=np.asarray([r['event'] for r in rows],np.int32)
    selected=B.P.Selection(np.asarray([r['case'] for r in rows],np.int32),
        np.asarray([r['side'] for r in rows],np.int8),events,context.event_phases[events],np.zeros(len(rows),bool))
    origins=np.asarray([r['origin'] for r in rows],np.int8)
    wi=np.asarray([widths[r['width']] for r in rows],np.int8)
    hi=np.where(origins==2,default_hi,event_hi[events]).astype(np.int8)
    tier=np.asarray([r['tier'] for r in rows],np.int8)
    result['exit_clock']='予定全決済要求は場終了16分前、期限は15分前。同秒決済は秒末解放。未知の管理上占有を確定保有とはしない。'
    return selected,origins,wi,hi,tier,result


def session_windows(context: object, eligible: np.ndarray | None=None) -> list:
    """
    機能: 分母を固定した全対象場と米国境界の実時間窓を返す。
    引数: context(object)、eligible(np.ndarray|None)。
    返り値: list[dict]。欠測や未参加で時間を除外しない。
    """
    if eligible is None:eligible=np.ones(len(context.scenes),bool)
    out=[]
    for index in np.flatnonzero(eligible):
        scene=context.scenes[index];start=float(scene['start']);end=float(context.deadlines[index])
        day=bool(context.hours[index,0]>0)
        if day:phases=[{'name':'DAY','start':start,'end':end}]
        else:
            boundary=start+context.hours[index,1]*3600
            phases=[{'name':'PRE','start':start,'end':boundary},{'name':'POST','start':boundary,'end':end}]
        out.append({'scene':scene['session'],'kind':'DAY' if day else 'NIGHT','start':start,'end':end,
                    'phases':phases,'close_deadline':end,'original_end':float(scene['end'])})
    return out


def positions(context: object, value: tuple, eligible: np.ndarray | None=None) -> list:
    """
    機能: 実取得だけを確定/未知保有区間へ変換する。
    引数: context(object)、value(tuple)、eligible(np.ndarray|None)。
    返り値: list[dict]。未知の下限情報がなければ取得瞬間までに限定する。
    """
    selected,origins,wi,hi,_,_=value
    if eligible is None:eligible=np.ones(len(context.scenes),bool)
    out=[]
    for i,case in enumerate(selected.cases):
        scene=int(context.case_scene[case])
        if not eligible[scene]:continue
        key=(case,selected.sides[i],wi[i],hi[i]);known=bool(context.arrays['known'][key])
        fill=float(context.arrays['entry_time'][case]);end=float(context.deadlines[scene])
        lower=float(context.arrays['holding_confirmed_until'][key]) if 'holding_confirmed_until' in context.arrays else fill
        lower=fill if not np.isfinite(lower) else max(fill,min(lower,end))
        out.append({'scene':context.sessions[scene],'fill':fill,
            'exit':float(context.arrays['exit_time'][key]) if known else None,
            'confirmed_until':lower,'possible_until':end,'quantity':1,
            'event':int(selected.events[i]),'case':int(case),'side':int(selected.sides[i]),'origin':int(origins[i])})
    return out


def evidence(context: object, value: tuple, eligible: np.ndarray | None=None) -> dict:
    """
    機能: 同じ対象場で金融中央値・保有参加・利益集中を一括評価する。
    引数: context(object)、value(tuple)、eligible(np.ndarray|None)。
    返り値: dict。金融の帯は新規時点、保有時間の帯は実時間分割。
    """
    global ACTIVITY
    if eligible is None:eligible=np.ones(len(context.scenes),bool)
    scene=context.case_scene[value[0].cases]
    financial=B.financial(context,value,eligible[scene],eligible)
    if ACTIVITY is None:ACTIVITY=B.P.module(ACTIVITY_PATH,'activity179_forbase')
    held=ACTIVITY.holding_summary(session_windows(context,eligible),positions(context,value,eligible),target_ratio=.2)
    groups={**financial['phases_diagnostic'],'NIGHT':financial['session_groups_required']['NIGHT']}
    concentration={name:ACTIVITY.financial_diagnostics(group) for name,group in groups.items()}
    return {'financial':financial,'holding':held,'concentration':concentration}
