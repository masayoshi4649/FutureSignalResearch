"""保有参加率と利益の広がりを先に固定して、複合入口を段階比較する。"""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from itertools import combinations,product
from datetime import datetime,timezone
import argparse
import copy
import json
import sys
import time
import numpy as np

from 基盤179 import ROOT,HERE,B,BASE,load_context,replay,evidence
sys.path.insert(0,str(ROOT/'work/175局面別入口の再探索'))
import 予備評価175 as SCREEN

TRIAL=ROOT/'study/00179_保有時間参加率と終了前決済で入口を広げる'
BUILDER=ROOT/'work/179量と構造の純入口/rules179.py'
CATALOG=ROOT/'work/179量と構造の純入口/候補辞書179.json'
OVERLAY_DIR=ROOT/'inputs/00179_終了前決済の共用数値表'
CTX=CAPS=DIRS=SEALS=None
BASE_IDS={'全期':'178/全期_J002_J000_K012','前48':'178/前48_J000_J005_K000'}
PERIODS=('全期','前48','後25')
BANDS=('DAY','PRE','POST')


def ref(path: Path) -> dict:
    """
    機能: 入力とSourceの内容指紋を記録する。
    引数: path(Path)。
    返り値: dictは相対path/bytes/sha256。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':B.P.sha(path)}


def freeze() -> None:
    """
    機能: 価格再計算と自然金融評価の前に、条件と探索順位を固定する。
    引数: なし。
    返り値: None。固定済み条件を上書きしない。
    """
    paths=[Path(__file__),HERE/'基盤179.py',HERE/'予備179.py',HERE/'固定結果を作る.py',BUILDER,CATALOG,
        ROOT/'work/179終了前決済/early179.py',ROOT/'work/179参加時間と利益集中/activity179.py',
        ROOT/'work/173追加なしの因果再生/engine173.py',ROOT/'work/173追加なしの評価/metrics173.py',
        ROOT/'work/175局面別入口の再探索/基盤175.py',ROOT/'work/175局面別入口の再探索/予備評価175.py']
    for source,name in [(BUILDER,'pure179_freeze'),(ROOT/'work/179終了前決済/early179.py','early179_freeze'),
        (ROOT/'work/179参加時間と利益集中/activity179.py','activity179_freeze')]:
        B.P.module(source,name)
    for module in list(sys.modules.values()):
        filename=getattr(module,'__file__',None)
        if filename:
            source=Path(filename).resolve()
            if source.suffix=='.py' and source.is_relative_to(ROOT):paths.append(source)
    for trial,folder in [(174,'174追加七場適用'),(177,'177追加七場適用'),(178,'178追加七場適用')]:
        paths.extend(ROOT/'work'/folder/f'{period}の純出生{trial}.npz' for period in ('旧73','追加7'))
        paths.append(ROOT/'work'/folder/'金融前の出生固定.json')
    paths=sorted(set(p.resolve() for p in paths),key=lambda p:p.as_posix())
    body={'試行':179,'GO':True,'UTC':datetime.now(timezone.utc).isoformat(),
        'ユーザー条件':'開始一律待機なし。対象時間中の実保有時間20%以上を目指す。終了15分前全決済。両中央値黒字、全買売合計保有・pending1件。先着70%硬足切りなし。',
        '時計':'Day08:45-15:30/Night17:00-05:45。cut=場末-900秒。submit=cut-60秒に全決済要求と新規停止/pending取消、submit+1秒以降cut以下の最初有効BBOで返済。通常IFD/期限が先なら先の出口。分母はcutまで残す。',
        '参加':'pendingは除く実保有区間合併。未知は確定保有下限と上限、下限20%以上だけ達成。PRE/POST保有は実時間分割、金融はq0帯帰属。欠測も分母に残す。',
        '費用':'mini1枚、1pt100円、片道38.5円+5ptと実BBO。幅は対称IFD、Nは期限返済、Cと金融未知を分ける。',
        '仮説':'方向/構造/動力と価格・量の関係を複合し、入口の追加と帯別置換を比較する。量なし/下限/回復/スパイク警戒を区別する。',
        '純候補':'179の6群576候補×実側正逆2。旧174/177/178各全期主/前半主の純入口は保持し、新時計で再生する。',
        '幅期限':'125/150/175/200/225/250/300/350/400/500/750/1000、H30/H60/H120/SESSION。終了前返済を全てへ適用。',
        '予備':'独立一枚で幅期限全比較、各帯/route/6群に利益損失・参加・決済正率・先着支持の各2案。1出生最大2幅期限、最大48/帯。12取得/6場/6FA/4FA場、未知<=20%、FA単場<=50%の支持を要す。口座損益とはしない。',
        '段階':'各予備候補を178固定幹へのADD/REPLACEで単一建玉再生。各帯最大8短表。異群二規則ORをADD/REPLACEで比較し、各帯最大6へ。3帯直積を全口座で再生。対照枝無変更を短表に残す。',
        '順位':'必須の両中央値正+全場取得、保有下限20%を共同表示し優先。続いて黒字場の広がり、上位3場除外後既知収支正、上位3場利益集中の低さ、未知率、経路、取得数を比較する。場別回数は均等化しない。',
        '期間':'旧73全期発見と前48のみ選択を別に行う。後25は前半選択順位に使わない。追加7は各route固定最大2案と旧6対照のみ参考適用。全期間既使用であり未見ではない。',
        '保存':'固定少数案は全取得/時間参加/金融/経路と候補別CSV。旧固定資料は変更しない。',
        'Source':[ref(p) for p in paths]}
    assert not (TRIAL/'条件.json').exists()
    B.P.save(TRIAL/'条件.json',body)
    print(json.dumps(ref(TRIAL/'条件.json'),ensure_ascii=False),flush=True)


def verify() -> None:
    """
    機能: F0後に主要Sourceが変わっていないことを確認する。
    引数: なし。
    返り値: None。不一致は停止する。
    """
    fixed=B.P.read(TRIAL/'条件.json');assert fixed['GO'] and fixed['試行']==179
    for item in fixed['Source']:assert B.P.sha(ROOT/item['path'])==item['sha256'],item['path']


def birth() -> None:
    """
    機能: 自然金融を読まず、旧73と追加7の純方向を封印する。
    引数: なし。
    返り値: None。
    """
    verify();builder=B.P.module(BUILDER,'pure179')
    old=B.P.R168.BASE.data_module().load_feature_dataset()
    added,_,_=B.P.R168.BASE.load_features(ROOT/'inputs/00167_追加七場の入口と共用価格索引/入口母集団')
    for name,features in [('旧73',old),('追加7',added)]:
        result=builder.build(features,np.asarray([s['start'] for s in features.scenes]),features.q0_timeband)
        target=HERE/(name+'の純出生179.npz');assert not target.exists()
        np.savez_compressed(target,directions=result['directions'],phases=result['phases'])
        B.P.save(target.with_suffix('.json'),{'成功':True,'金融未入力':True,'候補順':result['candidate_ids'],
            'F0SHA256':B.P.sha(TRIAL/'条件.json'),'出生':ref(target)})
        print(json.dumps({'純出生':name,'候補数':len(result['candidate_ids'])},ensure_ascii=False),flush=True)


def initialize(new: bool=False) -> None:
    """
    機能: workerへ新時計の金融と純方向・旧固定幹を一度だけ接続する。
    引数: new(bool)は追加7。
    返り値: None。
    """
    global CTX,CAPS,DIRS,SEALS
    period='追加7' if new else '旧73'
    CTX=load_context(new,OVERLAY_DIR/f'{period}_overlay179.npz')
    CAPS=B.captures(CTX)
    proof=B.P.read(HERE/(period+'の純出生179.json'))
    with np.load(HERE/(period+'の純出生179.npz'),allow_pickle=False) as raw:
        assert np.array_equal(raw['phases'],CTX.event_phases)
        matrix=raw['directions'];DIRS={identity+'/'+orientation:matrix[i] if orientation=='NORMAL' else -matrix[i]
            for i,identity in enumerate(proof['候補順']) for orientation in ('NORMAL','REVERSE')}
    SEALS={}
    for trial,folder,ids in [(174,'174追加七場適用',['全期_J002','前48_J000']),
        (177,'177追加七場適用',['全期_J002_J000','前48_J000_J005']),
        (178,'178追加七場適用',['全期_J002_J000_K012','前48_J000_J005_K000'])]:
        with np.load(ROOT/'work'/folder/f'{period}の純出生{trial}.npz',allow_pickle=False) as raw:
            assert np.array_equal(raw['phases'],CTX.event_phases)
            for identity in ids:
                SEALS[f'{trial}/{identity}']={k:raw[identity+'__'+k].copy() for k in ('core','branches','technical','tier','mw','fw','hi')}


def compose(policy: dict) -> tuple:
    """
    機能: 旧幹へ帯別の追加又は置換を適用し、逆方向競合は待機する。
    引数: policy(dict)はbase/changes。
    返り値: tupleはbirth/mw/fw/hi/新枝印。
    """
    base=SEALS[policy['base']]
    birth={k:base[k].copy() for k in ('core','branches','technical','tier')}
    mw,fw,hi=[base[k].copy() for k in ('mw','fw','hi')];added=np.zeros(len(mw),bool)
    for band,change in policy.get('changes',{}).items():
        if change['mode']=='KEEP':continue
        new,nw,nf,nh,_,conflict=BASE.compose(CTX.event_phases,{band:change['rules']},DIRS,list(CTX.table.horizons))
        in_band=CTX.event_phases==BANDS.index(band)
        active=in_band&((base['core']==0) if change['mode']=='ADD' else True)
        birth['core'][active]=new['core'][active]
        birth['branches'][active]=new['branches'][active]
        mw[active]=nw[active];fw[active]=nf[active];hi[active]=nh[active]
        birth['technical'][active&conflict]=0;birth['tier'][active&conflict]=0
        added[active]=new['core'][active]!=0
    return birth,mw,fw,hi,added


def evaluate(policy: dict) -> dict:
    """
    機能: 一つの候補を新時計の単一口座として再生し、全期/前後を評価する。
    引数: policy(dict)。
    返り値: dictは政策・期間ごとの金融/保有/集中。後半は前半順位へ使わない。
    """
    birth,mw,fw,hi,added=compose(policy);value=replay(CTX,birth,mw,fw,hi,True,CAPS)
    masks={'全期':np.ones(len(CTX.scenes),bool),'前48':np.arange(len(CTX.scenes))<48,'後25':np.arange(len(CTX.scenes))>=48}
    periods={name:evidence(CTX,value,eligible) for name,eligible in masks.items()}
    return {'id':policy['id'],'policy':policy,'periods':periods,'count':len(value[0].cases),
        'new_count':int(added[value[0].events].sum()),
        'max_reserved':max((r['peak_global_reserved'] for r in value[-1]['audits']),default=0)}


def group(row: dict, route: str, band: str) -> tuple:
    """
    機能: 一つの選択期間・帯の金融と保有を取り出す。
    引数: row(dict)、route/band(str)。
    返り値: tuple[dict,dict]は金融群と保有群。
    """
    record=row['periods'][route];f=record['financial']
    g=f['session_groups_required']['NIGHT'] if band=='NIGHT' else f['phases_diagnostic'][band]
    return g,record['holding']['groups'][band]


def ranking(row: dict, route: str, bands: tuple) -> tuple:
    """
    機能: 率の硬い足切りをせず、両中央値・実保有・利益の広がりで順位を作る。
    引数: row(dict)、route(str)、bands(tuple[str])。
    返り値: tupleは昇順。
    """
    groups=[group(row,route,b) for b in bands]
    dual=all(g['decision']['status']=='適合' for g,h in groups)
    full=all(g['sessions']['participating_count']==g['sessions']['eligible_count'] for g,h in groups)
    holds=[h['held_lower_ratio'] or 0 for g,h in groups];target=all(r>=.2 for r in holds)
    positive=[];removed=[];shares=[];unknown=[];burdens=[];negative_windows=[];count=0;net=0
    for g,h in groups:
        scenes=g['sessions']['rows'];n=len(scenes)
        positive.append(sum(r['unknown_count']==0 and r['known_net']>0 for r in scenes)/n if n else 0)
        winners=sorted((max(0,r['known_net']) for r in scenes),reverse=True);total=sum(winners)
        top=sum(winners[:3]);known_net=g['trades']['known_net']
        removed.append(known_net-top);shares.append(top/total if total else 1)
        trades=g['trades'];unknown.append(trades['unknown_count']/max(1,trades['all_count']))
        cumulative=np.cumsum([r['known_net'] for r in scenes]);peaks=np.maximum.accumulate(np.r_[0,cumulative])
        drawdown=float(np.max(peaks[1:]-cumulative)) if len(cumulative) else 0
        burdens.append(drawdown/max(1,trades['known_profit']))
        windows=[scenes[i:i+5] for i in range(max(0,len(scenes)-4))]
        complete=[w for w in windows if not any(r['unknown_count'] for r in w)]
        negative_windows.append(sum(sum(r['known_net'] for r in w)<0 for w in complete)/len(complete) if complete else 1)
        count+=trades['all_count'];net+=known_net
    return (-int(dual and full and target),-int(dual and target),-int(dual),-int(full),
        -min(min(r,.2) for r in holds),-min(positive),-sum(v>0 for v in removed),max(shares),
        max(unknown),max(negative_windows),max(burdens),-count,-net,row['id'])


def shortlist(rows: list, route: str, band: str, maximum: int) -> list:
    """
    機能: 共同条件・参加・集中・収支の異なる視点から短表を残す。
    引数: rows(list)、route/band(str)、maximum(int)。
    返り値: list[dict]。同じ候補の重複選択はしない。
    """
    out=[];seen=set()
    for view in ('共同','参加','集中','収支'):
        def key(row: dict) -> tuple:
            """
            機能: 指定視点の補助順位を、同じ期間だけから作る。
            引数: row(dict)。
            返り値: tuple。
            """
            g,h=group(row,route,band);general=ranking(row,route,(band,))
            if view=='共同':return general
            if view=='参加':return (-int(g['decision']['status']=='適合'),-min(h['held_lower_ratio'] or 0,.2),-g['sessions']['participating_count'],-g['trades']['all_count'],general)
            if view=='収支':return (-int(g['decision']['status']=='適合'),-g['trades']['known_net'],general)
            return (general[5],general[6],general[7],general)
        taken=0
        for row in sorted(rows,key=key):
            if row['id'] in seen:continue
            out.append(row);seen.add(row['id']);taken+=1
            if taken==2 or len(out)>=maximum:break
        if len(out)>=maximum:break
    return out


def run(name: str, policies: list) -> list:
    """
    機能: 段階の候補一覧を封印してから旧73を並列再生する。
    引数: name(str)、policies(list)。
    返り値: list[dict]。
    """
    verify();path=HERE/(name+'.json.gz');assert not path.exists()
    B.P.save(TRIAL/'検査'/('F2_'+name+'.json'),{'成功':True,'SourceSHA256':B.P.sha(Path(__file__)),'policies':policies})
    rows=[];start=time.monotonic()
    with ProcessPoolExecutor(max_workers=4,initializer=initialize) as pool:
        for row in pool.map(evaluate,policies,chunksize=2):
            rows.append(row)
            if len(rows)%24==0:print(json.dumps({'段階':name,'完了':len(rows),'全数':len(policies),'秒':round(time.monotonic()-start,1)},ensure_ascii=False),flush=True)
    B.P.save(path,{'成功':True,'rows':rows});return rows


def controls() -> None:
    """
    機能: 旧174/177/178固定主の新時計だけの対照を再生する。
    引数: なし。
    返り値: None。
    """
    names=[(174,'全期_J002'),(174,'前48_J000'),(177,'全期_J002_J000'),(177,'前48_J000_J005'),
        (178,'全期_J002_J000_K012'),(178,'前48_J000_J005_K000')]
    run('旧入口の新時計対照',[{'id':f'C{trial}_{name}','base':f'{trial}/{name}',
        'route':'前48' if name.startswith('前48') else '全期','changes':{}} for trial,name in names])


def stages(stage: str) -> None:
    """
    機能: 単独追加/置換、二局面OR、三帯接合を事前固定の順で実行する。
    引数: stage(str)はsingle/mix/joint。
    返り値: None。各routeの順位は指定期間だけから決める。
    """
    policies=[]
    if stage=='single':
        source=B.P.read(HERE/'予備短表179.json')['選択']
        for route,bands in source.items():
            for band,rules in bands.items():
                for rule in rules:
                    for mode in ('ADD','REPLACE'):
                        policies.append({'id':f'{route}_{band}_{mode}_{rule["id"]}','route':route,'base':BASE_IDS[route],
                            'changes':{band:{'mode':mode,'rules':[rule]}}})
        rows=run('単帯の追加置換',policies);chosen={}
        for route in BASE_IDS:
            chosen[route]={}
            for band in BANDS:
                candidates=[r for r in rows if r['policy']['route']==route and band in r['policy']['changes']]
                chosen[route][band]=[r['policy'] for r in shortlist(candidates,route,band,8)]
        B.P.save(HERE/'単帯短表.json',{'成功':True,'選択':chosen})
    elif stage=='mix':
        source=B.P.read(HERE/'単帯短表.json')['選択']
        for route,bands in source.items():
            for band,singles in bands.items():
                seen=set();entries=[]
                for single in singles:
                    entries.append(single['changes'][band])
                unique={r['id']:r for s in singles for r in s['changes'][band]['rules']}
                for first,second in combinations(unique.values(),2):
                    if first['family']==second['family']:continue
                    for mode in ('ADD','REPLACE'):entries.append({'mode':mode,'rules':[first,second]})
                entries.append({'mode':'KEEP','rules':[]})
                for change in entries:
                    signature=(change['mode'],tuple(sorted(r['id'] for r in change['rules'])))
                    if signature in seen:continue
                    seen.add(signature)
                    policies.append({'id':f'{route}_{band}_M{len(seen):03}','route':route,'base':BASE_IDS[route],
                        'changes':{band:change}})
        rows=run('二局面の追加置換',policies);chosen={}
        for route in BASE_IDS:
            chosen[route]={}
            for band in BANDS:
                candidates=[r for r in rows if r['policy']['route']==route and band in r['policy']['changes']]
                selected=shortlist(candidates,route,band,6)
                control=next(r for r in candidates if r['policy']['changes'][band]['mode']=='KEEP')
                if control['id'] not in {r['id'] for r in selected}:selected=selected[:5]+[control]
                chosen[route][band]=[r['policy'] for r in selected]
        B.P.save(HERE/'帯接合短表.json',{'成功':True,'選択':chosen})
    else:
        source=B.P.read(HERE/'帯接合短表.json')['選択']
        for route,bands in source.items():
            for i,items in enumerate(product(*[bands[b] for b in BANDS])):
                changes={b:item['changes'][b] for b,item in zip(BANDS,items,strict=True)}
                policies.append({'id':f'{route}_J{i:03}','route':route,'base':BASE_IDS[route],'changes':changes})
        rows=run('三帯の保有参加比較',policies);chosen={}
        for route in BASE_IDS:
            ordered=sorted([r for r in rows if r['policy']['route']==route],key=lambda r:ranking(r,route,('DAY','NIGHT')))
            qualified=[r for r in ordered if ranking(r,route,('DAY','NIGHT'))[0]==-1]
            chosen[route]={'主案':qualified[0]['id'] if qualified else None,'共同適合数':len(qualified),
                '参考候補':[r['id'] for r in ordered[:2]],'candidates':[r['policy'] for r in ordered[:2]]}
        B.P.save(HERE/'旧73の固定選択.json',{'成功':True,'選択':chosen,'追加7当該政策金融未読':True})
        print(json.dumps({r:{k:v for k,v in x.items() if k!='candidates'} for r,x in chosen.items()},ensure_ascii=False),flush=True)


def main() -> None:
    """
    機能: 自然金融前固定、純出生、対照再生の指定段階を実行する。
    引数: --stage(str)。
    返り値: None。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--stage',choices=('freeze','birth','controls','single','mix','joint'),required=True)
    stage=parser.parse_args().stage
    if stage=='freeze':freeze()
    elif stage=='birth':birth()
    elif stage=='controls':controls()
    else:stages(stage)


if __name__=='__main__':main()
