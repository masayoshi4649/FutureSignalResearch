"""新規判断q0と同じ原行の価格だけを、共用価格索引から抽出する。"""
from pathlib import Path
import hashlib
import json
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
DEST = ROOT / 'inputs/00183_入口判断時点の価格'
sys.path.insert(0, str(ROOT / 'work/181共用接続'))
import 共用181 as C


def ref(path: Path) -> dict:
    """
    機能: 生成物の内容指紋を取得する。
    引数: path(Path)は対象ファイル。
    返り値: dictは相対パス・サイズ・SHA256。
    """
    data = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


def load_q0(pure: dict) -> dict:
    """
    機能: q0原行のLast/Bid/Askを取り出し、金融から独立して保存・照合する。
    引数: pure(dict)は共用181.load_pure_legの返り値。
    返り値: dict[str,np.ndarray]はlast/bid/ask/time/line/normal。q1価格は使わない。
    """
    DEST.mkdir(parents=True, exist_ok=True)
    target = DEST / (pure['leg'] + '_q0.npz')
    manifest = target.with_suffix('.json')
    expected = {'features_sha256': C.feature_sha(pure['features']),
                '価格索引': pure['price_index'], 'Source': ref(Path(__file__))}
    if target.exists():
        saved = json.loads(manifest.read_text(encoding='utf-8'))
        assert saved['入力'] == expected
        assert saved['NPZ'] == ref(target)
        with np.load(target, allow_pickle=False) as values:
            return {key: values[key].copy() for key in values.files}
    helper = C.P.B.P.module(ROOT/'work/163任意幅の数値化/arrays163.py', 'q0_records183')
    meta = pure['features'].q0_meta
    count = len(meta)
    values = {key: np.full(count, np.nan, dtype=np.float64) for key in ('last','bid','ask','time')}
    values['line'] = np.zeros(count, np.int64)
    values['normal'] = np.zeros(count, bool)
    scenes = np.asarray([row['session_index'] for row in meta], dtype=np.int32)
    for si, source in enumerate(pure['price_index']['scenes']):
        ids = np.flatnonzero(scenes == si)
        records = helper.load_records(ROOT/source['path'], source['sha256'], source['rows'])
        indices = np.asarray([meta[int(i)]['q0_index'] for i in ids], dtype=np.int64)
        selected = records[indices]
        np.testing.assert_array_equal(selected['source_line'], [meta[int(i)]['q0_line'] for i in ids])
        np.testing.assert_array_equal(selected['time'], [meta[int(i)]['q0_time'] for i in ids])
        assert all(meta[int(i)]['session'] == source['session'] and
                   meta[int(i)]['contract'] == source['contract'] for i in ids)
        for key in ('last','bid','ask','time','normal'):
            values[key][ids] = selected[key]
        values['line'][ids] = selected['source_line']
    np.savez_compressed(target, **values)
    body = {'成功': True, '金融未入力': True, 'q0原行一致': count, '入力': expected, 'NPZ': ref(target)}
    manifest.write_text(json.dumps(body, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    return values


# ----------------------------------------
if __name__ == '__main__':
    for leg in C.LEGS:
        pure = C.load_pure_leg(leg)
        values = load_q0(pure)
        print(json.dumps({'期間': leg, '判断数': len(values['time']),
            '正常板': int(values['normal'].sum())}, ensure_ascii=False), flush=True)
