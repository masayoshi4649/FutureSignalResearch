"""183純入口を自然金融なしで検査する。"""
from pathlib import Path
from types import SimpleNamespace
import hashlib
import json
import numpy as np
import rules183 as R

HERE = Path(__file__).resolve().parent


def fixture(n: int = 10) -> tuple:
    """
    機能: 100特徴互換の必要列と当時価格だけから人工入力を作る。
    引数: n(int)は判断行数。
    返り値: tupleはfeaturesと179互換base_bundle。
    """
    columns = list(R.RAW_COLUMNS); index = {name:i for i,name in enumerate(columns)}
    buy = np.zeros((n,len(columns)))
    defaults = {'m5_atr':10,'m15_adx':20,'m15_adx_delta':-.1,'m15_hist_delta_to_side':1,
        'm5_hist_delta_to_side':1,'m5_hist_to_side':1,'m5_rsi_delta_to_side':1,'m5_rsi_center_to_side':5,
        'm1_body_ratio_to_side':.5,'m1_previous_body_ratio_to_side':-.5,'m1_close_delta_atr5_to_side':.2,
        'm1_body_reclaim_atr5_to_side':.2,'q0_last_minus_m1_close_atr5_to_side':.1,
        'm1_close_position_to_side':.8,'m5_body_ratio_to_side':.5,
        'q0_entry_minus_ema8_atr5_to_side':.5,'q0_last_minus_prior3_forward_edge_atr5_to_side':-.2,
        'm1_volume_relative_prior3':1,'m1_tr_atr5_ratio':1,'m5_tr_previous_atr_ratio':1,
        'q0_spread_points':1,'bb15_sigma':10,'q0_entry_minus_bbmean_sigma_to_side':0}
    for m in (5,15,30):
        defaults[f'm{m}_ema21_delta_to_side'] = 1; defaults[f'm{m}_di_difference_to_side'] = 1
    for name,value in defaults.items(): buy[:,index[name]] = value
    sell = buy.copy()
    for name,j in index.items():
        if name.endswith('_to_side'): sell[:,j] *= -1
    meta = [{'session':'人工_Day','session_index':0,'contract':'人工限月','q0_time':100000+60*i,
        'q0_index':i,'q0_line':i+1} for i in range(n)]
    prices = {'last':np.full(n,100.),'bid':np.full(n,99.5),'ask':np.full(n,100.5),
        'time':np.array([q['q0_time'] for q in meta]),'line':np.arange(n)+1,'normal':np.ones(n,bool)}
    f = SimpleNamespace(buy_X=buy,sell_X=sell,columns=columns,q0_meta=meta,
        q0_timeband=np.zeros(n,np.int8),q0_prices=prices)
    base = {'birth':{'core':np.zeros(n,np.int8),'branches':np.full(n,-1,np.int8),
        'technical':np.ones(n,np.int8),'tier':np.ones(n,np.int8)},
        'mw':np.full(n,200,np.int16),'fw':np.full(n,200,np.int16),'hi':np.full(n,1,np.int8),'added':np.zeros(n,bool)}
    if n:
        base['birth']['core'][0]=1; base['birth']['branches'][0]=0
        base['mw'][0]=base['fw'][0]=350
    return f,base


def price(f: object, event: int, value: float) -> None:
    """
    機能: 人工q0のLastと正常BBOを同時に設定する。
    引数: f(object)、event(int)、value(float)。
    返り値: None。
    """
    f.q0_prices['last'][event]=value; f.q0_prices['bid'][event]=value-.5; f.q0_prices['ask'][event]=value+.5


def side(f: object, event: int, actual: int) -> None:
    """
    機能: 人工の実方向の構造・動力を対称に揃える。
    引数: f(object)、event(int)、actual(int)は買0/売1。
    返り値: None。
    """
    for name in f.columns:
        if not name.endswith('_to_side'): continue
        j=f.columns.index(name)
        if name in ('q0_entry_minus_bbmean_sigma_to_side',): continue
        value = .5
        if name=='m1_previous_body_ratio_to_side': value=-.5
        if name=='m1_close_position_to_side': value=.8
        if name=='q0_last_minus_prior3_forward_edge_atr5_to_side': value=-.2
        if name=='m5_rsi_center_to_side': value=5
        (f.buy_X if actual==0 else f.sell_X)[event,j]=value
        (f.sell_X if actual==0 else f.buy_X)[event,j]=-value


def sliced(f: object, base: dict, stop: int) -> tuple:
    """
    機能: 特徴・q0価格・出生のprefixを複写する。
    引数: f(object)、base(dict)、stop(int)。
    返り値: tupleはprefix入力。
    """
    pf=SimpleNamespace(buy_X=f.buy_X[:stop].copy(),sell_X=f.sell_X[:stop].copy(),columns=f.columns,
        q0_meta=[dict(q) for q in f.q0_meta[:stop]],q0_timeband=f.q0_timeband[:stop].copy(),
        q0_prices={k:v[:stop].copy() for k,v in f.q0_prices.items()})
    pb={'birth':{k:v[:stop].copy() for k,v in base['birth'].items()},
        **{k:base[k][:stop].copy() for k in ('mw','fw','hi','added')}}
    return pf,pb


def flat(bundle: dict) -> dict:
    """
    機能: 照合する8配列を平坦化する。
    引数: bundle(dict)。
    返り値: dict[str,np.ndarray]。
    """
    return {**bundle['birth'],**{k:bundle[k] for k in ('mw','fw','hi','added')}}


def setup_case(family: str, n: int = 10) -> tuple:
    """
    機能: 各構造が発火する段階的な人工価格を用意する。
    引数: family(str)、n(int)。
    返り値: tupleはfeatures/base/期待発火位置/期待方向。
    """
    f,b=fixture(n); j={name:i for i,name in enumerate(f.columns)}
    at,sign=1,1
    if family=='EM':
        f.buy_X[0,j['q0_entry_minus_ema8_atr5_to_side']]=0
        f.sell_X[0,j['q0_entry_minus_ema8_atr5_to_side']]=0
        price(f,1,101.6)
    elif family in ('BT','BF'):
        f.buy_X[0,j['q0_last_minus_prior3_forward_edge_atr5_to_side']]=.5
        f.sell_X[0,j['q0_last_minus_prior3_forward_edge_atr5_to_side']]=-.5
        if family=='BT':
            price(f,1,96.5); price(f,2,97.1); at=2
        else:
            price(f,1,93.9); side(f,1,1); sign=-1
    elif family=='PR':
        price(f,1,96); side(f,1,1); sign=-1
    elif family=='RG':
        f.buy_X[0,j['q0_entry_minus_bbmean_sigma_to_side']]=-1.5
        f.sell_X[0,j['q0_entry_minus_bbmean_sigma_to_side']]=1.5
        price(f,1,106)
    elif family=='MX':
        for i in range(n):
            for name in ('m30_ema21_delta_to_side','m30_di_difference_to_side'):
                f.buy_X[i,j[name]]=-1; f.sell_X[i,j[name]]=1
        for name in ('m5_di_difference_to_side','m5_hist_delta_to_side'):
            f.buy_X[0,j[name]]=-1; f.sell_X[0,j[name]]=1
    return f,b,at,sign


def main() -> None:
    """
    機能: 6構造と28候補の対称性・因果性・未知・固定水準・幅期限継承を検査する。
    引数: なし。
    返り値: None。自然特徴・新183金融を読まない。
    """
    checks=[]; total=0
    def check(name: str, actual: object, expected: object) -> None:
        """
        機能: 人工の期待値と項目数を記録する。
        引数: name(str)、actual/expected(object)。
        返り値: None。不一致で停止する。
        """
        nonlocal total
        a,c=np.asarray(actual),np.asarray(expected)
        assert a.shape==c.shape and np.array_equal(a,c),(name,a,c)
        total+=a.size; checks.append({'検査':name,'項目':int(a.size),'不一致':0})
    for family in R.FAMILIES:
        f,b,at,sign=setup_case(family); output=R.build(f,b)
        identity=next(r['id'] for r in R.catalog()['rules'] if r.get('family')==family and r.get('mode')=='ADD')
        check(family+'の価格構造',output['diagnostics'][identity]['structure_signal'][at],sign)
        check(family+'の新規方向',output['bundles'][identity]['birth']['core'][at],sign)
        check(family+'の元幅継承',output['bundles'][identity]['mw'][at],200 if family=='MX' else 350)
        if family=='BT':
            check('BT再テスト同q0は発火不可',output['diagnostics'][identity]['structure_signal'][1],0)
        inherited=R.OLD.build(f,b)
        for i in range(4):
            for key,value in flat(inherited['bundles'][f'E182_{i:02d}']).items():
                check('固定対照/'+family+f'/{i}/'+key,flat(output['bundles'][f'E183_{i:02d}'])[key],value)
        for stop in range(11):
            pf,pb=sliced(f,b,stop); born=R.build(pf,pb)
            for candidate in output['candidate_ids']:
                for key,value in flat(output['bundles'][candidate]).items():
                    check('prefix/'+family+f'/{stop}/'+candidate+'/'+key,flat(born['bundles'][candidate])[key],value[:stop])
        mf,mb=sliced(f,b,10); mf.buy_X,mf.sell_X=mf.sell_X.copy(),mf.buy_X.copy()
        oldp={k:v.copy() for k,v in mf.q0_prices.items()}
        mf.q0_prices['last']=-oldp['last']; mf.q0_prices['bid']=-oldp['ask']; mf.q0_prices['ask']=-oldp['bid']
        for key in ('core','technical'): mb['birth'][key]*=-1
        born=R.build(mf,mb)
        for candidate in output['candidate_ids']:
            for key,value in flat(output['bundles'][candidate]).items():
                check('鏡像/'+family+'/'+candidate+'/'+key,flat(born['bundles'][candidate])[key],-value if key in ('core','technical') else value)
        changed,cb=sliced(f,b,10); changed.buy_X[at+1:]=np.nan; changed.sell_X[at+1:]=np.nan
        changed.q0_prices['last'][at+1:]+=10000
        born=R.build(changed,cb)
        for candidate in output['candidate_ids']:
            for key,value in flat(output['bundles'][candidate]).items():
                check('将来改変/'+family+'/'+candidate+'/'+key,flat(born['bundles'][candidate])[key][:at+1],value[:at+1])

    # ----------------------------------------
    f,b,_,_=setup_case('BT'); a,*_=R._prepare(f)
    for m in (5,15,30):
        j=f.columns.index(f'm{m}_di_difference_to_side'); f.buy_X[:,j]=-1; f.sell_X[:,j]=1
    arrays,_,_,_,_,prices=R._prepare(f); fact=R._facts(arrays,prices)
    check('EMA/DI対立足は買い支持0',fact[0]['support'],np.zeros(10))
    check('EMA/DI対立足は売り支持0',fact[1]['support'],np.zeros(10))
    for name in ('m1_volume_relative_prior3','m5_hist_delta_to_side','m5_atr'):
        f,b,at,_=setup_case('BF'); f.sell_X[at,f.columns.index(name)]=np.nan
        born=R.build(f,b)
        identity=next(r['id'] for r in R.catalog()['rules'] if r.get('family')=='BF' and r.get('mode')=='ADD')
        check('必要未知の反転禁止/'+name,born['diagnostics'][identity]['structure_signal'][at],0)
    f,b,_,_=setup_case('BT')
    f.buy_X[1:,f.columns.index('q0_last_minus_prior3_forward_edge_atr5_to_side')]=-10
    check('記憶した突破価格を現在端で動かさない',R.build(f,b)['diagnostics']['E183_08']['structure_signal'][2],1)
    f,b,_,_=setup_case('RG');f.buy_X[1:,f.columns.index('bb15_sigma')]=500
    check('記憶したBB帯端を現在sigmaで動かさない',R.build(f,b)['diagnostics']['E183_20']['structure_signal'][1],1)
    f,b,_,_=setup_case('EM');f.q0_timeband[:]=1;b['fw'][0]=200;b['hi'][0]=3
    born=R.build(f,b)['bundles']['E183_04']
    check('後続発火の元幅期限を全て保持',[born[k][1] for k in ('mw','fw','hi')],[350,200,3])
    f,b,at,_=setup_case('BF'); f.q0_prices['normal'][at]=False
    check('不正常q0では新構造なし',R.build(f,b)['diagnostics']['E183_12']['structure_signal'][at],0)
    for change in ('gap','contract','scene','backward'):
        f,b,at,_=setup_case('BF')
        for q in f.q0_meta[1:]:
            if change=='gap': q['q0_time']+=121
            elif change=='contract': q['contract']='次限月'
            elif change=='scene': q['session']='別_Night';q['session_index']=1
            else:q['q0_time']-=61
        f.q0_prices['time']=np.array([q['q0_time'] for q in f.q0_meta])
        check('状態reset/'+change,R.build(f,b)['diagnostics']['E183_12']['structure_signal'][at],0)
    f,b,at,_=setup_case('BF'); old=f.q0_prices['line'][at];f.q0_prices['line'][at]=old+1
    failed=False
    try:R.build(f,b)
    except AssertionError:failed=True
    check('原行不一致は停止',failed,True)
    f,b,_,_=setup_case('BT'); f.q0_timeband[1:]=1
    check('NY境界だけで状態を切らない',R.build(f,b)['diagnostics']['E183_08']['structure_signal'][2],1)
    f,b=fixture();b['birth']['core'][4]=1;b['birth']['branches'][4]=0
    b['mw'][4]=b['fw'][4]=400;b['hi'][4]=3;b['added'][4]=True
    born=R.build(f,b)
    for identity,bundle in born['bundles'].items():
        if int(identity[-2:])<4:continue
        for key,value in flat(b).items():check('LC固定/'+identity+'/'+key,flat(bundle)[key][4],value[4])
    result={'成功':True,'自然特徴と新183金融未入力':True,'項目':total,'不一致':0,'検査':checks,'Source':[]}
    for path in (HERE/'rules183.py',Path(__file__)):
        result['Source'].append({'path':path.relative_to(R.ROOT).as_posix(),'bytes':path.stat().st_size,
            'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    (HERE/'人工確認183.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'項目':total,'不一致':0},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
