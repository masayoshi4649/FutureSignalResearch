"""183のNK225純入口。固定4対照と、6種の価格構造×4統合方式を比較する。"""
from pathlib import Path
import hashlib
import json
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT/'work/182局面別の反転確認'))
import rules182 as OLD

VERSION = '183当時背景と固定価格構造の純入口1'
FAMILIES = {
    'EM': '上位方向内のEMA8押戻し回復',
    'BT': '固定した突破水準の再テスト後に順行',
    'BF': '固定した突破水準の失敗後に反転',
    'PR': '元圧力の失速と価格反転回復',
    'RG': '低ADXの固定BB帯端内への回復',
    'MX': '混在背景からDIと動力が整理される',
}
MODES = {'ADD': '旧幹を優先し新構造を追加', 'RISK': '既知の強い反対圧力は待ち新構造を追加',
    'FOLLOW': '強い元圧力と順行回復が揃えば方向を切替', 'LATE': '過伸長と直近崩れが同時の入口だけ待つ'}
RAW_COLUMNS = tuple(sorted(set(OLD.V1.RAW_COLUMNS) | set(OLD.P.EXTRA_COLUMNS) | {
    'm15_adx', 'm5_atr', 'm5_body_ratio_to_side', 'bb15_sigma',
    'q0_entry_minus_bbmean_sigma_to_side'}))


def catalog() -> dict:
    """
    機能: 固定4対照と6構造×4方式の全28候補を金融前に定義する。
    引数: なし。
    返り値: dictはID・閾値・状態・未知・価格/幅期限の由来。
    """
    rules = [{'id': f'E183_{i:02d}', 'control': f'E182_{i:02d}', 'family': 'CONTROL',
        'description': OLD.catalog()['rules'][i]['description']} for i in range(4)]
    for family in FAMILIES:
        for mode in MODES:
            rules.append({'id': f'E183_{len(rules):02d}', 'family': family, 'mode': mode,
                'description': FAMILIES[family]+'／'+MODES[mode],
                'window_seconds': {'EM': 1200, 'BT': 1200, 'BF': 900, 'PR': 1800, 'RG': 1800, 'MX': 0}[family]})
    return {'version': VERSION, 'candidate_count': len(rules), 'rules': rules,
        'raw_columns': list(RAW_COLUMNS), '対象': 'NK225・全DAY/PRE/POST。商品単位・費用は後段。TOPIXへ無確認流用しない。',
        'input': '当時100特徴、q0識別、q0_timeband、features.q0_prices(last,bid,ask,time,line,normal)、179全期J035純基準。',
        'normal': '追加q0価格のtime/lineを元q0へ照合。正常BBO・有限Lastだけ使用し、q1/取得価格で補完しない。',
        'common_quality': 'spread>0かつ<=20pt、q0Lastと確定1分終値の絶対差<=1ATR5、entry−EMA8は−1〜2ATR5、相対量>=.5、ATR5>0。必要列既知。',
        'spike': '1分TR/ATR5>2.5又は5分TR/前ATR>4、かつRSI増分絶対値>12又は相対量>3、かつentry−EMA8>1.5ATR5が同時なら除外。RSI水準単独では禁止しない。',
        'momentum': '5分Hist増分とRSI増分が両方既知・>=0、少なくとも一方>0。強確認は両方>0。',
        'structure': '1分実体>0・価格進行>0・live>0、又は順方向3分端差>0・実体>=0・進行>=0。各代替の必要列既知。',
        'background': '5/15/30分の各足はEMA21傾きとDI差が両方既知かつ両方実方向>0の時だけ順行支持票を作る。両者が対立する足は順行支持にせずMXの混在で別扱い。未知を逆票や0票へ補完しない。',
        'EM': '方向支持2足以上でentry−EMA8が−1.5〜.25ATR5の押戻しを観測。q0売買側価格とATRから固定EMA8価格を逆算し、後続で実方向に.1ATR5超回復＋動力/構造/量を確認。20実分。',
        'BT': '元方向端差>.25ATR5・相対量>=.75・方向支持1足以上・動力で突破を観測。固定端=Last−符号×端差×ATR5。端から−.35〜.2ATR5の再テストq0を記憶し、それより後のq0で>.1ATR5へ復帰。再テストと同じq0では発火しない。20実分。',
        'BF': '同じ固定端の突破後、元方向と逆に>.1ATR5戻り、実方向の1分構造と動力回復又はセットアップ時よりMACD/RSI圧力が悪化せず改善を確認。背景代替と相対量を伴う。15実分。',
        'PR': '方向支持2足以上・ADX15>=20・元方向動力から観測ピークを記憶。反対へ.35ATR5以上戻り、元5分圧力改善・実方向構造・背景代替を確認。ADX20は中間帯を含む仮説。30実分。',
        'RG': 'ADX15<=25、取得側BB位置<=−1σ、相対量>=.5から固定1σ帯端を記憶。後続で帯端内へ戻り動力と1分構造を確認。30実分。BB/RSI水準だけの反転ではない。',
        'MX': '方向6列中4列以上既知で、既知の正負が混在。5分DI又はHist増分が直前既知値<=0から>0へ変化し、実方向の動力/構造/量を確認。entry−EMA8<=1.5ATR5。',
        'risk': '旧182の6列全逆、又は4逆＋ADX>=25上昇、又は元方向の価格端/量/値幅スパイク。既知リスクだけ作用し、UNKNOWNは別旗で旧幹を保つ既定行動。',
        'late': 'entry−EMA8>=1.5ATR5かつ1分実体<0・進行<0・live<=0、又はentry−EMA8>=1ATR5かつ(1分TR/ATR5>2.5又は5分TR/前ATR>4)とRSI増分絶対値>12が同時。必要値既知。',
        'modes': MODES,
        'FOLLOW': '既知リスク時、反対側の方向支持2足・強動力・1分構造・量/位置が揃った時だけ方向反転。それ以外は待つ。ADXだけで売買しない。',
        'priority': '固定対照は完全同体。新24案はLC(added=True)を保持、変更しない旧幹は新構造より優先。新構造の両方向競合は待ち。拒否元q0/新発火q0はTへ暗黙切替しない。',
        'width_horizon': '新しい幅・期限の軸なし。セットアップ時の基準mw/fw/hiを記憶し、後刻発火へ同じ値を渡す。独立セットアップ時に基準core=0ならそのq0の既定幅/期限を継承。',
        'clock': '場/scene/限月変更、時刻後退、180秒超gapで状態・直前値を消去。期限はq0秒の実時間、初期一律待機なし。同方向setupで期限延長しない。発火は後続q0で一度、取得結果は純状態へ戻さない。',
        'limitations': ['板数量を入力しないため完全OFI・注文吸収の直接観測とは呼ばない。',
            '価格ピークはq0で観測した範囲。途中原板の未観測ピークを将来から補わない。',
            '全81場は既使用。新金融を読む前の仮説固定であり、未見の利益証明ではない。',
            '新構造追加により枠と後続取得が変わる。単独利益の足し算で評価しない。']}


def _get(features: object, key: str) -> object:
    """
    機能: 互換特徴の属性又は辞書を取得する。
    引数: features(object|dict)、key(str)。
    返り値: objectは指定純入力。
    """
    return features[key] if isinstance(features, dict) else getattr(features, key)


def _prepare(features: object) -> tuple:
    """
    機能: 当時価格をq0識別へ照合して、必要列・因果時計を接続する。
    引数: features(FeatureDataset互換)。
    返り値: tupleは側別列・メタ・秒・帯・reset・価格辞書。
    """
    arrays, meta, times, phases, reset = OLD._prepare(features)
    columns = [c['name'] if isinstance(c, dict) else c for c in _get(features, 'columns')]
    assert set(RAW_COLUMNS) <= set(columns)
    index = {name: i for i, name in enumerate(columns)}
    for side, key in enumerate(('buy_X', 'sell_X')):
        matrix = np.asarray(_get(features, key), dtype=np.float64)
        arrays[side].update({name: matrix[:, index[name]] for name in RAW_COLUMNS})
    source = _get(features, 'q0_prices')
    prices = {name: np.asarray(source[name]) for name in ('last', 'bid', 'ask', 'time', 'line', 'normal')}
    assert all(value.shape == times.shape for value in prices.values())
    assert np.array_equal(prices['time'], times)
    assert np.array_equal(prices['line'], [q['q0_line'] for q in meta])
    normal = prices['normal'].astype(bool)
    assert np.all(np.isfinite(prices['last'][normal]))
    assert np.all(np.isfinite(prices['bid'][normal]) & np.isfinite(prices['ask'][normal]) & (prices['bid'][normal] < prices['ask'][normal]))
    return arrays, meta, times, phases, reset, prices


def _known(x: dict, *names: str) -> np.ndarray:
    """
    機能: 一役割の列が全既知のmaskを作る。
    引数: x(dict[str,np.ndarray])、names(tuple[str])。
    返り値: np.ndarray[bool,N]。
    """
    return np.logical_and.reduce([np.isfinite(x[name]) for name in names])


def _facts(arrays: list, prices: dict) -> list:
    """
    機能: 背景・動力・価格構造・位置・観測量を役割別の当時maskへ分ける。
    引数: arrays(list[dict])、prices(dict)。
    返り値: list[dict]は買売側別の既知成立と方向票数。
    """
    facts = []
    for x in arrays:
        pair_known = np.asarray([_known(x, f'm{m}_ema21_delta_to_side', f'm{m}_di_difference_to_side') for m in (5,15,30)])
        positive = np.asarray([pair_known[j] & (x[f'm{m}_ema21_delta_to_side'] > 0) & (x[f'm{m}_di_difference_to_side'] > 0) for j,m in enumerate((5,15,30))])
        mom_known = _known(x, 'm5_hist_delta_to_side', 'm5_rsi_delta_to_side')
        h, r = x['m5_hist_delta_to_side'], x['m5_rsi_delta_to_side']
        momentum = mom_known & (h >= 0) & (r >= 0) & ((h > 0) | (r > 0))
        strong = mom_known & (h > 0) & (r > 0)
        live_known = _known(x, 'm1_body_reclaim_atr5_to_side', 'q0_last_minus_m1_close_atr5_to_side')
        live = x['m1_body_reclaim_atr5_to_side'] + x['q0_last_minus_m1_close_atr5_to_side']
        a = (_known(x, 'm1_body_ratio_to_side', 'm1_close_delta_atr5_to_side') & live_known
            & (x['m1_body_ratio_to_side'] > 0) & (x['m1_close_delta_atr5_to_side'] > 0) & (live > 0))
        b = (_known(x, 'm1_body_ratio_to_side', 'm1_close_delta_atr5_to_side', 'q0_last_minus_prior3_forward_edge_atr5_to_side')
            & (x['m1_body_ratio_to_side'] >= 0) & (x['m1_close_delta_atr5_to_side'] >= 0)
            & (x['q0_last_minus_prior3_forward_edge_atr5_to_side'] > 0))
        needed = ('q0_spread_points', 'q0_last_minus_m1_close_atr5_to_side', 'q0_entry_minus_ema8_atr5_to_side',
            'm1_volume_relative_prior3', 'm1_tr_atr5_ratio', 'm5_tr_previous_atr_ratio', 'm5_rsi_delta_to_side', 'm5_atr')
        known = _known(x, *needed)
        position = x['q0_entry_minus_ema8_atr5_to_side']; volume = x['m1_volume_relative_prior3']
        large = (x['m1_tr_atr5_ratio'] > 2.5) | (x['m5_tr_previous_atr_ratio'] > 4)
        shock = large & ((np.abs(r) > 12) | (volume > 3)) & (position > 1.5)
        quality = (known & prices['normal'].astype(bool) & (x['q0_spread_points'] > 0) & (x['q0_spread_points'] <= 20)
            & (np.abs(x['q0_last_minus_m1_close_atr5_to_side']) <= 1) & (position >= -1) & (position <= 2)
            & (volume >= .5) & (x['m5_atr'] > 0) & ~shock)
        background = ((positive.sum(axis=0) >= 1)
            | (np.isfinite(x['m15_hist_delta_to_side']) & (x['m15_hist_delta_to_side'] >= 0))
            | (np.isfinite(x['m15_adx_delta']) & (x['m15_adx_delta'] <= 0)))
        late_known = _known(x, 'q0_entry_minus_ema8_atr5_to_side', 'm1_body_ratio_to_side', 'm1_close_delta_atr5_to_side',
            'm1_body_reclaim_atr5_to_side', 'q0_last_minus_m1_close_atr5_to_side', 'm1_tr_atr5_ratio', 'm5_tr_previous_atr_ratio', 'm5_rsi_delta_to_side')
        late = late_known & (((position >= 1.5) & (x['m1_body_ratio_to_side'] < 0) & (x['m1_close_delta_atr5_to_side'] < 0) & (live <= 0))
            | ((position >= 1) & large & (np.abs(r) > 12)))
        directional = np.asarray([x[name] for name in OLD.BACKGROUND])
        finite = np.isfinite(directional); positives = ((directional > 0) & finite).sum(axis=0)
        mixed = (finite.sum(axis=0) >= 4) & (positives > 0) & (positives < finite.sum(axis=0))
        facts.append({'support': positive.sum(axis=0), 'known_frames': pair_known.sum(axis=0),
            'momentum': momentum, 'strong': strong, 'structure': a | b, 'live_structure': a,
            'quality': quality, 'background': background, 'late': late, 'late_unknown': ~late_known,
            'mixed': mixed, 'trend_ready': quality & strong & (a | b) & (positive.sum(axis=0) >= 2)})
    return facts


def _pressure(arrays: list, side: int, now: int, setup: int, strict: bool = False) -> bool:
    """
    機能: 実方向のMACD/RSIがセットアップ時から悪化していないかを確認する。
    引数: arrays(list[dict])、side/now/setup(int)、strict(bool)は一方以上の改善を要す。
    返り値: bool。未知は成立させない。
    """
    x = arrays[side]; names = ('m5_hist_delta_to_side', 'm5_rsi_delta_to_side')
    if not all(np.isfinite(x[name][i]) for name in names for i in (now, setup)):
        return False
    valid = all(x[name][now] >= x[name][setup] for name in names)
    return bool(valid and (not strict or any(x[name][now] > x[name][setup] for name in names)))


def _signals(family: str, arrays: list, facts: list, prices: dict, times: np.ndarray,
             reset: np.ndarray, base: dict) -> dict:
    """
    機能: 一つの価格構造を全3帯の因果状態として生成する。
    引数: family(str)、arrays/facts(list)、prices/base(dict)、times/reset(np.ndarray)。
    返り値: dictは方向、元setup、継承幅期限、競合、setup方向の配列。
    """
    n = len(times); direction = np.zeros(n, np.int8); setup_at = np.full(n, -1, np.int64)
    mw, fw, hi = [base[key].copy() for key in ('mw','fw','hi')]
    conflict = np.zeros(n, bool); seeded = np.zeros((2,n), bool)
    windows = {'EM':1200,'BT':1200,'BF':900,'PR':1800,'RG':1800,'MX':0}
    states = [None, None]
    for i in range(n):
        if reset[i]: states = [None, None]
        if not bool(prices['normal'][i]): continue
        last = float(prices['last'][i]); ready = []
        for side in (0,1):
            sign = 1 if side == 0 else -1; x = arrays[side]; f = facts[side]
            state = states[side]
            if state is not None and times[i]-times[state['event']] > windows[family]:
                state = None; states[side] = None
            if family == 'MX':
                if i == 0 or reset[i]: continue
                crossed = any(np.isfinite(x[name][i-1]) and np.isfinite(x[name][i])
                    and x[name][i-1] <= 0 < x[name][i] for name in ('m5_di_difference_to_side','m5_hist_delta_to_side'))
                if (f['mixed'][i] and f['quality'][i] and f['strong'][i] and f['structure'][i]
                    and x['q0_entry_minus_ema8_atr5_to_side'][i] <= 1.5 and crossed):
                    ready.append((side, i))
                continue
            if state is not None and i > state['event'] and times[i] > times[state['event']]:
                event = state['event']; atr = state['atr']; level = state['level']
                if family == 'PR':
                    state['peak'] = max(state['peak'], sign*last)
                distance = sign*(last-level)/atr
                if family == 'BT' and -.35 <= distance <= .2 and state['retest_event'] < 0:
                    state['retest_event'] = i
                target_side = 1-side if family in ('BF','PR') else side
                target = facts[target_side]; tx = arrays[target_side]
                common = target['quality'][i] and target['structure'][i]
                passed = False
                if family == 'EM': passed = distance > .1 and target['momentum'][i] and target['support'][i] >= 1
                elif family == 'BT': passed = (state['retest_event'] >= 0 and i > state['retest_event']
                    and times[i] > times[state['retest_event']] and distance > .1 and target['momentum'][i])
                elif family == 'BF': passed = (distance < -.1 and target['background'][i]
                    and (target['momentum'][i] or _pressure(arrays,target_side,i,event,True)))
                elif family == 'PR': passed = (state['peak']-sign*last >= .35*atr and target['background'][i]
                    and _pressure(arrays,target_side,i,event,True))
                elif family == 'RG': passed = distance >= 0 and target['momentum'][i]
                if common and passed:
                    ready.append((target_side,event)); states[side] = None
                    continue
            if states[side] is not None: continue
            atr = x['m5_atr'][i]
            if not np.isfinite(atr) or atr <= 0: continue
            edge = x['q0_last_minus_prior3_forward_edge_atr5_to_side'][i]
            volume = x['m1_volume_relative_prior3'][i]
            position = x['q0_entry_minus_ema8_atr5_to_side'][i]
            level = None
            if family == 'EM':
                if (f['support'][i] >= 2 and np.isfinite(position) and -1.5 <= position <= .25
                    and np.isfinite(volume) and volume >= .5):
                    entry = float(prices['ask'][i] if side == 0 else prices['bid'][i])
                    level = entry-sign*float(position)*float(atr)
            elif family in ('BT','BF'):
                if (np.isfinite(edge) and edge > .25 and np.isfinite(volume) and volume >= .75
                    and f['momentum'][i] and (family == 'BF' or f['support'][i] >= 1)):
                    level = last-sign*float(edge)*float(atr)
            elif family == 'PR':
                if f['support'][i] >= 2 and f['strong'][i] and np.isfinite(x['m15_adx'][i]) and x['m15_adx'][i] >= 20:
                    level = last
            elif family == 'RG':
                sigma = x['bb15_sigma'][i]; bbpos = x['q0_entry_minus_bbmean_sigma_to_side'][i]
                if (np.isfinite(x['m15_adx'][i]) and x['m15_adx'][i] <= 25 and np.isfinite(sigma) and sigma > 0
                    and np.isfinite(bbpos) and bbpos <= -1 and np.isfinite(volume) and volume >= .5):
                    entry = float(prices['ask'][i] if side == 0 else prices['bid'][i])
                    mean = entry-sign*float(bbpos)*float(sigma); level = mean-sign*float(sigma)
            if level is not None and np.isfinite(level):
                states[side] = {'event':i,'atr':float(atr),'level':float(level),'peak':sign*last,'retest_event':-1}
                seeded[side,i] = True
        if len({side for side,_ in ready}) > 1:
            conflict[i] = True
        elif ready:
            side,event = ready[0]; direction[i] = 1 if side == 0 else -1; setup_at[i] = event
            mw[i], fw[i], hi[i] = base['mw'][event], base['fw'][event], base['hi'][event]
    return {'direction':direction,'setup_event':setup_at,'mw':mw,'fw':fw,'hi':hi,
        'conflict':conflict,'seeded':seeded}


def build(features: object, base_bundle: dict, candidate_ids: list | None = None) -> dict:
    """
    機能: 固定4対照と全3帯の構造追加・待機・順逆切替24案を純生成する。
    引数: features(FeatureDataset互換、q0_prices必須)、base_bundle(dict)、candidate_ids(list[str]|None)。
    返り値: dictはcandidate_ids/bundles[id]/diagnostics。金融・約定結果は入力しない。
    """
    mapping = {r['id']:r for r in catalog()['rules']}; ids = list(mapping) if candidate_ids is None else candidate_ids
    assert len(set(ids)) == len(ids) and set(ids) <= set(mapping)
    arrays, meta, times, phases, reset, prices = _prepare(features); n = len(meta)
    base, _, _ = OLD.V1._base(base_bundle,n,phases)
    facts = _facts(arrays,prices)
    control_ids = [mapping[key]['control'] for key in ids if mapping[key]['family']=='CONTROL']
    controls = OLD.build(features,base_bundle,control_ids)
    risks = np.full(n,-1,np.int8); risk_unknown = np.zeros(n,bool); late_unknown = np.zeros(n,bool)
    for i in np.flatnonzero(base['birth']['core']):
        side = 0 if base['birth']['core'][i] == 1 else 1
        value = OLD._risks(arrays,side,int(i)); risks[i] = OLD._or([value['risk6'],value['combined']])
        risk_unknown[i] = risks[i] == -1; late_unknown[i] = facts[side]['late_unknown'][i]
    families = {mapping[key]['family'] for key in ids if mapping[key]['family']!='CONTROL'}
    signals = {family:_signals(family,arrays,facts,prices,times,reset,base) for family in families}
    bundles = {}; diagnostics = {}
    for identity in ids:
        rule = mapping[identity]
        if rule['family']=='CONTROL':
            bundles[identity] = controls['bundles'][rule['control']]
            diagnostics[identity] = controls['diagnostics'][rule['control']]
            continue
        output = {'birth':{k:v.copy() for k,v in base['birth'].items()},
            **{k:base[k].copy() for k in ('mw','fw','hi','added')}}
        core = output['birth']['core']; mode = rule['mode']; signal = signals[rule['family']]
        rejected = np.zeros(n,bool); flipped = np.zeros(n,bool); added = np.zeros(n,bool)
        for i in range(n):
            if base['added'][i]: continue
            original = int(base['birth']['core'][i])
            if original:
                side = 0 if original == 1 else 1
                reject = (mode in ('RISK','FOLLOW') and risks[i] == 1) or (mode=='LATE' and facts[side]['late'][i])
                if reject:
                    rejected[i] = True; core[i] = 0; output['birth']['branches'][i] = -1
                    output['birth']['technical'][i] = 0; output['birth']['tier'][i] = 0
                    if mode=='FOLLOW' and facts[1-side]['trend_ready'][i]:
                        core[i] = -original; output['birth']['branches'][i] = 0; flipped[i] = True
            if core[i] == 0 and signal['direction'][i] != 0:
                core[i] = signal['direction'][i]; output['birth']['branches'][i] = 0
                output['birth']['technical'][i] = 0; output['birth']['tier'][i] = 0
                output['mw'][i],output['fw'][i],output['hi'][i] = signal['mw'][i],signal['fw'][i],signal['hi'][i]
                output['added'][i] = False; added[i] = True
            elif core[i] == 0 and signal['conflict'][i]:
                output['birth']['technical'][i] = 0; output['birth']['tier'][i] = 0
        lc = base['added'].astype(bool)
        assert all(np.array_equal(output['birth'][k][lc],base['birth'][k][lc]) for k in base['birth'])
        bundles[identity] = output
        diagnostics[identity] = {'rejected':rejected,'flipped':flipped,'new_structure':added,
            'setup_event':signal['setup_event'].copy(),'structure_signal':signal['direction'].copy(),
            'structure_conflict':signal['conflict'].copy(),'risk_unknown':risk_unknown.copy(),
            'late_unknown':late_unknown.copy(),'risk_state':risks.copy()}
    return {'version':VERSION,'candidate_ids':ids,'bundles':bundles,'diagnostics':diagnostics,
        'common_diagnostics':{'reset':reset,'normal':prices['normal'].astype(bool)}}


def write_catalog(path: Path) -> None:
    """
    機能: 28候補の全仕様と参照Sourceの指紋を新金融前に固定する。
    引数: path(Path)。
    返り値: None。既存辞書と旧Sourceを改変しない。
    """
    assert not path.exists()
    sources = []
    for source in (Path(__file__),Path(OLD.__file__),Path(OLD.P.__file__),Path(OLD.V1.__file__)):
        sources.append({'path':source.relative_to(ROOT).as_posix(),'bytes':source.stat().st_size,
            'sha256':hashlib.sha256(source.read_bytes()).hexdigest()})
    path.write_text(json.dumps({**catalog(),'Source':sources,'新183金融未入力':True},ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
