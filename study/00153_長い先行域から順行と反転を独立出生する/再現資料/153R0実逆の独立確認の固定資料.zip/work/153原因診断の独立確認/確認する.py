"""固定R0の同q1実逆を141別算術で計算し、作者診断を最後に照合する。"""
from pathlib import Path
from collections import Counter
import gzip
import hashlib
import importlib.util
import json
import math
import re

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
MATH = ROOT / 'work/141金融集計を独立に確認する.py'
MATH_SHA = '30bd4aef8c2809699cb013f930cfbce152f3986fe8d3d3cc6b49452104c2269e'
PATHS = {
    'f1': ROOT / 'work/153独立出生の評価/F1入口選択後.json',
    'selection': ROOT / 'work/153独立出生の評価/入口選択/選択対応.json',
    'observations': ROOT / 'study/00148_全1分知得から入口品質の母集団を固定する/成果物/固定取得の正逆観測.json.gz',
    'diagnosis': ROOT / 'work/153独立出生の原因診断/金融診断.json'}


def sha(path: Path) -> str:
    """
    機能: 明示入力をstreamで指紋化する。
    引数: path(Path)。返り値: str。
    """
    h = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1 << 20), b''): h.update(block)
    return h.hexdigest()


# ----------------------------------------
def scenes(path: Path, evidence: dict):
    """
    機能: 保存gzipを場単位で読み、全CRC・解凍bytesの指紋を完読確認する。
    引数: path(Path)、evidence(dict)。返り値: Iterator[dict]。
    """
    h = hashlib.sha256(); size = 0; buffer = ''; decoder = json.JSONDecoder()
    with gzip.open(path, 'rt', encoding='utf-8', newline='') as source:
        def more() -> str:
            """
            機能: UTF8境界を維持し全解凍指紋へ加える。
            引数: なし。返り値: str。
            """
            nonlocal size
            value = source.read(1 << 20); raw = value.encode('utf-8'); h.update(raw); size += len(raw)
            return value
        while True:
            value = more(); assert value, 'scenesがない'
            buffer += value; match = re.search(r'(?m)^  "scenes": \[', buffer)
            if match: buffer = buffer[match.end():]; break
        while True:
            buffer = buffer.lstrip()
            if buffer.startswith(']'): break
            if buffer.startswith(','): buffer = buffer[1:].lstrip()
            try: value, end = decoder.raw_decode(buffer)
            except json.JSONDecodeError:
                value = more(); assert value, 'scenes途中終了'; buffer += value; continue
            yield value; buffer = buffer[end:]
        while more(): pass
    evidence.update(decoded_sha256=h.hexdigest(), decoded_bytes=size, full_gzip_crc_checked=True)


# ----------------------------------------
def orient(case: dict, stream: str) -> dict:
    """
    機能: 選択R0実側をoriginal、同q1の反対実側をreverseへ参照写像する。
    引数: case(dict)、stream(str)。返り値: dict。保存価格・touchは変更しない。
    """
    assert stream in ('original', 'reverse')
    other = 'reverse' if stream == 'original' else 'original'
    return {**case, 'original': case[stream], 'reverse': case[other]}


# ----------------------------------------
def statistic(value: dict) -> dict:
    """
    機能: 141算術の主要値を診断表の日本語列へ一対一対応させる。
    引数: value(dict)。返り値: dict。
    """
    keys = {'件数': 'entries', '場数': 'sessions', 'F': 'forward', 'A': 'adverse', 'N': 'neither', 'C': 'censored',
            '到達済率': 'resolved_rate', '完了分母率': 'complete_rate', 'IFD既知': 'ifd_known', 'IFD未知': 'ifd_unknown',
            'C5利益': 'ifd_net5_profit', 'C5損失絶対': 'ifd_net5_loss', 'C5差引': 'ifd_net5_sum', 'PF': 'ifd_net5_pf'}
    return {key: value[source] for key, source in keys.items()}


# ----------------------------------------
def label(value: dict) -> str:
    """
    機能: 一件のH60完了ラベルをF/A/N、不足をCとして取り出す。
    引数: value(dict)は141 calculate一件結果。返り値: str。
    """
    assert value['entries'] == 1
    if value['censored']: return 'C'
    return 'F' if value['forward'] else 'A' if value['adverse'] else 'N'


# ----------------------------------------
def compare(expected: dict, actual: dict) -> int:
    """
    機能: 診断表の全キーと数値を別算術結果へ照合する。
    引数: expected/actual(dict)。返り値: intは末端比較数。
    """
    assert set(expected) == set(actual)
    count = 0
    for key, value in expected.items():
        other = actual[key]
        if isinstance(value, dict): count += compare(value, other)
        else:
            if isinstance(value, float): assert type(other) in (int, float) and math.isclose(value, other, rel_tol=1e-12, abs_tol=1e-8), (key, value, other)
            else: assert value == other, (key, value, other)
            count += 1
    return count


# ----------------------------------------
def main() -> None:
    """
    機能: 固定R0だけの全/前48/後25の同q1正逆を再計算して1票に保存する。
    引数: なし。返り値: None。作者124/153金融/原因算術をimportしない。
    """
    target = HERE / '独立確認.json'; assert not target.exists()
    assert sha(MATH) == MATH_SHA
    before = {key: {'sha256': sha(path), 'bytes': path.stat().st_size, 'mtime_ns': path.stat().st_mtime_ns}
              for key, path in PATHS.items()}
    assert before['f1']['sha256'] == '27d40d463d1a098121829476343d476e3a31f063c5b9630b6912f4d6168ba936'
    assert before['observations']['sha256'] == 'bd809bdf24400628817afee702063504c65682e6748a60e0f32d7690b7363c61'
    assert before['diagnosis']['sha256'] == 'fed4e8c1c4481fe95b65ad70492e95f077baa7230f8119bed1b910d8be489ba9'
    f1 = json.loads(PATHS['f1'].read_bytes()); selection = json.loads(PATHS['selection'].read_bytes())
    assert f1['ファイル'][PATHS['selection'].relative_to(ROOT).as_posix()] == before['selection']['sha256']
    refs = selection['政策']['R0']; wanted = {row['case_id']: row for row in refs}; sessions = selection['全73場']
    assert len(refs) == len(wanted) == 1375 and len(sessions) == len(set(sessions)) == 73
    spec = importlib.util.spec_from_file_location('固定141別算術_R0検算', MATH)
    mathematics = importlib.util.module_from_spec(spec); spec.loader.exec_module(mathematics)
    selected = []; evidence = {}; physical = set(); scene_count = total_cases = 0
    for scene in scenes(PATHS['observations'], evidence):
        assert scene['success'] and scene['session'] == sessions[scene_count]; scene_count += 1
        total_cases += len(scene['cases'])
        for case in scene['cases']:
            if case['id'] not in wanted: continue
            ref = wanted.pop(case['id']); sid = scene['session']; assert sid == ref['session']
            oriented = orient(case, ref['stream']); native, inverse = oriented['original'], oriented['reverse']
            assert native['birth']['side'] == ref['side'] and inverse['birth']['side'] == -ref['side']
            assert native['entry'] == inverse['entry']
            quote = native['entry']; position = (sid, quote['time'], quote['index'], quote['source_line'])
            assert position not in physical; physical.add(position)
            assert 0 < quote['bid'] < quote['ask'] and quote['quote_ok']
            assert native['entry_price'] == quote['ask' if ref['side'] == 1 else 'bid']
            assert inverse['entry_price'] == quote['bid' if ref['side'] == 1 else 'ask']
            selected.append((sid, oriented))
    assert not wanted and scene_count == 73 and total_cases == 31642
    assert evidence['decoded_sha256'] == 'd1b4cab8a258203f04b5c1d081f57d10ed2a0c58ce4cc160ef571d5fac0ceffc'
    computed = {}
    for part, scope in (('all', sessions), ('train', sessions[:48]), ('validation', sessions[48:])):
        values = [row for row in selected if row[0] in scope]
        native = mathematics.calculate(values, False, 'BBO', 3600, 125)
        inverse = mathematics.calculate(values, True, 'BBO', 3600, 125)
        matrix = {key: {other: 0 for other in ('F', 'A', 'N', 'C')} for key in ('F', 'A', 'N', 'C')}
        both = only_native = only_inverse = 0; difference = 0
        for row in values:
            one = mathematics.calculate([row], False, 'BBO', 3600, 125)
            reverse = mathematics.calculate([row], True, 'BBO', 3600, 125)
            matrix[label(one)][label(reverse)] += 1
            known_one, known_reverse = one['ifd_known'] == 1, reverse['ifd_known'] == 1
            if known_one and known_reverse: both += 1; difference += reverse['ifd_net5_sum'] - one['ifd_net5_sum']
            elif known_one: only_native += 1
            elif known_reverse: only_inverse += 1
        computed[part] = {'元方向': statistic(native), '実逆': statistic(inverse), '元→実逆行列': matrix,
                          '両IFD既知': both, '両既知C5差_実逆引く元': difference,
                          '元だけ既知': only_native, '逆だけ既知': only_inverse}
    # ----------------------------------------
    # 独立再計算完了後にだけ作者診断の数値を読み、R0の表全体へ照合する。
    diagnosis = json.loads(PATHS['diagnosis'].read_bytes()); cells = 0
    for part, expected in computed.items(): cells += compare(expected, diagnosis['全期前後'][part]['R0']['同q1実正逆'])
    assert before == {key: {'sha256': sha(path), 'bytes': path.stat().st_size, 'mtime_ns': path.stat().st_mtime_ns}
                      for key, path in PATHS.items()}
    assert sha(MATH) == MATH_SHA
    proof = {'成功': True, '編集停止': True, '試行': 153, '範囲': '固定R0の同q1実逆H60±125、全/前48/後25だけ。',
             '比較末端': cells, '再計算': computed, '入力': before, '保存観測の全CRC/解凍指紋': evidence,
             '独立算術': {'path': MATH.relative_to(ROOT).as_posix(), 'SHA256': MATH_SHA},
             '確認コードSHA256': sha(Path(__file__)), 'R0取得と同q1反対実BBOの全件一致': True,
             '費用': 'mini1枚の独立IFD、往復77円+C5ストレス1000円/件。未知は0補完しない。',
             '作者124/153金融/原因金融の算術import': False, '新条件探索/新選択/Raw/追加2場': False,
             '実口座収支又は独立未知期': False}
    with target.open('x', encoding='utf-8', newline='\n') as output:
        json.dump(proof, output, ensure_ascii=False, indent=2); output.write('\n')
    print(json.dumps({'成功': True, '比較末端': cells, '全期R0実逆': computed['all']['実逆'], 'SHA256': sha(target)}, ensure_ascii=False))


if __name__ == '__main__': main()
