"""自然本文を開かず、153の先検査と後段接続だけを人工で検査する。"""
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import copy
import importlib.util
import sys
import tempfile
import unittest
import numpy as np
import 人工検査 as fixtures
import logic153 as core

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('runner153test',HERE/'選択する.py')
run=importlib.util.module_from_spec(spec);spec.loader.exec_module(run)
helper=run.module(run.ROOT/'scripts/入口研究/固定特徴から可読条件を選択する.py','link153test')


def joined_fixture() -> tuple:
    """
    機能: 価格本文を使わず1場1q0と同体short_refsを作る。
    引数: なし。返り値: tupleは特徴/照合票/高安DTO。
    """
    buy,sell,d,_,_=fixtures.fixture();q=d['q0'];r=d['r']
    meta={'event_id':'e0','session':'人工','contract':'X','session_index':0,
          'q0_time':q['time'],'q0_index':q['index'],'q0_line':q['source_line']}
    features=SimpleNamespace(columns=fixtures.NAMES,buy_X=np.array([buy]),sell_X=np.array([sell]),q0_meta=[meta],
        scenes=[{'session':'人工','contract':'X','start':0,'end':10800,'force_close':10500}])
    quote={k:q[k] for k in ('time','index','source_line','last','bid','ask','quote_ok','normal_bbo')}
    quote.update(bid_finite=True,ask_finite=True)
    short={k:copy.deepcopy(r[k]) for k in ('id','start','end','available_at','stamp','price_known','volume_known','closed')}
    short.update(session='人工',contract='X')
    witness={'e0':{'q0':quote,'short_refs':[short]}}
    high={'success':True,'schema':'prior_time_range_v1','windows_minutes':[15,30,60],
          'financial_labels_used':False,'strategy_selected':False,'selected_trade_count':None,'selected_trade_frequency':None,
          'sessions':['人工'],'scenes':[{'session':'人工','contract':'X','start':0,'continuous_end':10500,'bars':[r],
          'rows':[{'event_id':'e0','eligible':True,'q0':q,'r_ref':'r','slot_refs':['r'],'delivered_refs':['r'],'prior_ranges':d['prior_ranges']}]}]}
    return features,witness,high


def link_fixture() -> tuple:
    """
    機能: 旧87と同q1の反対alias/別caseを人工で作る。
    引数: なし。返り値: tupleは判断/capture/metadata/場順。
    """
    sessions=[f'場{i:02}' for i in range(73)]
    descriptors=[{'case_id':f'旧{i:02}','session':sessions[min(i,72)],'contract':'X','original_side':-1 if i==0 else 1,
        'c1_reused':True,'buy_stream':'reverse' if i==0 else 'original','sell_stream':'original' if i==0 else 'reverse'} for i in range(87)]
    descriptors.append({'case_id':'新','session':sessions[0],'contract':'X','original_side':1,'c1_reused':False,'buy_stream':'original','sell_stream':'reverse'})
    decisions=[];captures=[]
    for event,index,side,key in [('先',1,1,'新'),('後',2,-1,'新'),('旧反対',3,1,'旧00')]:
        directions={k:side for k in (*core.POLICIES,'NN15')};conflicts={k:False for k in directions}
        decisions.append({'event_id':event,'session':sessions[0],'contract':'X','q0_time':100+index,'q0_index':index,'q0_line':index+1,
            'decision':{'directions':directions,'conflicts':conflicts,'evidence':[{'rule':k,'order_side':side} for k in core.POLICIES]}})
        descriptor=next(d for d in descriptors if d['case_id']==key)
        captures.append({'event_id':event,'session':sessions[0],'contract':'X','q0':{'time':100+index,'index':index,'source_line':index+1},
            'status':'filled','case_id':key,'buy_stream':descriptor['buy_stream'],'sell_stream':descriptor['sell_stream']})
    return decisions,{'rows':captures},{'population148':{'cases':descriptors}},sessions


class Tests(unittest.TestCase):
    def test_全参照先検査と排他保存(self):
        """
        機能: 後行参照差をchoose前に拒否し、判断保存の上書きを拒否する。
        引数: self(Tests)。返り値: None。
        """
        f,w,h=joined_fixture();before=copy.deepcopy((w,h))
        with patch.object(core,'choose',wraps=core.choose) as choose:
            dto=run.measurements(f,w,h,core,1);self.assertEqual(choose.call_count,0)
            rows=run.project(f,dto,core);self.assertEqual(choose.call_count,1)
        self.assertEqual((w,h),before);self.assertEqual(rows[0]['decision']['directions']['NN15'],1)
        for path in ('q0','short'):
            bad=copy.deepcopy(w)
            if path=='q0':bad['e0']['q0']['last']+=1
            else:bad['e0']['short_refs'][0]['stamp']['line']+=1
            with self.assertRaises(AssertionError):run.measurements(f,bad,h,core,1)
        with tempfile.TemporaryDirectory() as temporary:
            output=Path(temporary)/'判断.json';run.save(output,{'rows':rows})
            with self.assertRaises(FileExistsError):run.save(output,{})

    def test_正常価格とfiniteだけの違い(self):
        """
        機能: finiteな0を正値knownへ偽装せず元Quoteのまま照合する。
        引数: self(Tests)。返り値: None。
        """
        _,w,h=joined_fixture();q=copy.deepcopy(h['scenes'][0]['rows'][0]['q0']);other=copy.deepcopy(w['e0']['q0'])
        q.update(bid=None,bid_known=False,normal_bbo=False);other.update(bid=0,normal_bbo=False)
        run.quote_equal(q,other)
        q['bid_known']=True
        with self.assertRaises(AssertionError):run.quote_equal(q,other)

    def test_同q1最初とC1優先三union(self):
        """
        機能: 後発反対aliasを再選択せず旧売C1を3unionで保護する。
        引数: self(Tests)。返り値: None。
        """
        d,c,m,s=link_fixture();before=copy.deepcopy((d,c,m))
        out=run.connect(d,c,m,s,helper)
        for policy in ('U15','U30','U60'):
            by={r['case_id']:r for r in out['政策'][policy]}
            self.assertEqual(len(by),88);self.assertEqual(by['新']['event_id'],'先')
            self.assertEqual((by['旧00']['side'],by['旧00']['stream']),(-1,'original'))
            self.assertTrue(out['旧C1重複'][policy][0]['opposite'])
        self.assertEqual((d,c,m),before)

    def test_固定152対照全値copy(self):
        """
        機能: 旧B0/U1の未知フィールドまで保持しC1不一致を拒否する。
        引数: self(Tests)。返り値: None。
        """
        d,c,m,s=link_fixture();result=run.connect(d,c,m,s,helper)
        old={'成功':True,'試行':152,'選択時の金融ラベル利用':False,'政策':{'C1':copy.deepcopy(result['政策']['C1']),
             'B0':[{'未知欄':{'配列':[1,None]}}],'U1':[{'固定':2}]}}
        before=copy.deepcopy(old);run.bind_controls(result,old,{'C1':87,'B152':1,'UB152':1})
        self.assertEqual(result['政策']['B152'],old['政策']['B0']);result['政策']['B152'][0]['未知欄']['配列'].append(3)
        self.assertEqual(old,before);old['政策']['C1'][0]['side']*=-1
        with self.assertRaises(AssertionError):run.bind_controls(result,old,{'C1':87,'B152':1,'UB152':1})

    def test_明示実行前はファイルIOなし(self):
        """
        機能: 実行旗なしなら存在しないbookも読まず停止する。
        引数: self(Tests)。返り値: None。
        """
        with patch.object(sys,'argv',['選択する.py','--book','存在しない.json','--book-sha256','0'*64,'--output-dir','存在しない出力']),patch.object(run,'sha',side_effect=RuntimeError('I/O禁止')) as digest:
            with self.assertRaises(AssertionError):run.main()
            self.assertEqual(digest.call_count,0)


if __name__=='__main__':
    unittest.main(verbosity=2)
