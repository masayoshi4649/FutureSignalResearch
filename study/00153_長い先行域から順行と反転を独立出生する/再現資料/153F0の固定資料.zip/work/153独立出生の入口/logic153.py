"""153は共通100Xと当時先行域だけから独立方向を判定する。"""
import math

WINDOWS=(15,30,60)
R_KEYS=('m1_body_ratio_to_side','m1_body_reclaim_atr5_to_side','q0_last_minus_m1_close_atr5_to_side','m5_hist_delta_to_side','m5_rsi_delta_to_side','m1_volume_relative_prior3')
TREND_KEYS=('m5_ema21_delta_to_side','m15_ema21_delta_to_side','m30_ema21_delta_to_side','m5_di_difference_to_side','m15_di_difference_to_side','m30_di_difference_to_side','m15_adx','m15_adx_delta')
ATR='m5_atr'
DISTANCE='q0_entry_minus_ema8_atr5_to_side'
GAP='q0_last_minus_m1_close_atr5_to_side'
POLICIES=('R0','PB','BR15','RV15','N15','N30','N60')


def number(value) -> float | None:
    """
    機能: None/NaNを未知として保持し、非有限や非数値を拒否する。
    引数: value(float|int|None)。
    返り値: float|None。boolと無限大はValueError。
    """
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError('数値型ではない')
    result = float(value)
    if math.isnan(result):
        return None
    if not math.isfinite(result):
        raise ValueError('無限大は入力不正')
    return result


def values(vector: list, index: dict, keys: tuple) -> dict:
    """
    機能: 入力を変更せず指定列だけの値と既知性を取り出す。
    引数: vector(list)、index(dict[str,int])、keys(tuple[str])。
    返り値: dict[str,float|None]。
    """
    return {key: number(vector[index[key]]) for key in keys}


def recovery(v: dict) -> dict:
    """
    機能: 実体・現在生存回復・5分動力・同r量の全known確認を行う。
    引数: v(dict[str,float|None])はR6列。
    返り値: dictはknown/value/values。量=1を含み他のゼロはfalse。
    """
    out = dict(v)
    a, b = v[R_KEYS[1]], v[R_KEYS[2]]
    live = a + b if a is not None and b is not None else None
    if live is not None and not math.isfinite(live):
        raise ValueError('生存回復の派生overflow')
    out['live_reclaim'] = live
    known = all(x is not None for x in v.values())
    flag = (v[R_KEYS[0]] > 0 and live > 0 and v[R_KEYS[3]] > 0
            and v[R_KEYS[4]] > 0 and v[R_KEYS[5]] >= 1) if known else None
    return {'known': known, 'value': flag, 'values': out}


def stamp(value: dict) -> tuple:
    """
    機能: q0/足の時計と原行を同じ順序で取り出す。
    引数: value(dict)。
    返り値: tuple[float,int,int]。
    """
    time=number(value['time']);index=value['index'];line=value.get('line',value.get('source_line'))
    if time is None or type(index) is not int or index<0 or type(line) is not int or line<1:
        raise ValueError('時計又は原行不正')
    return time,index,line


def compare(a,operator: str,b) -> bool | None:
    """
    機能: 未知をfalseへせず有限値の比較だけを返す。
    引数: a/b(float|None)、operator(str)。
    返り値: bool|None。
    """
    if a is None or b is None:return None
    if operator=='>':return a>b
    if operator=='>=':return a>=b
    if operator=='<':return a<b
    if operator=='<=':return a<=b
    raise ValueError('未知の演算子')


def gate(checks: dict,observed: dict=None) -> dict:
    """
    機能: 全必要条件のknownを要求し、偽と未知を別に残す。
    引数: checks(dict[str,bool|None])、observed(dict|None)。
    返り値: dictはknown/pass/不成立/未知/観測値。
    """
    if any(x is not None and type(x) is not bool for x in checks.values()):raise ValueError('条件真偽型差')
    known=all(x is not None for x in checks.values())
    return {'known':known,'pass':all(checks.values()) if known else None,
        'false':[k for k,v in checks.items() if v is False],'unknown':[k for k,v in checks.items() if v is None],
        'checks':dict(checks),'values':dict(observed or {})}


def logical_or(values: list) -> bool | None:
    """
    機能: 既知true枝を未知枝より優先する三値ORを返す。
    引数: values(list[bool|None])。
    返り値: bool|None。
    """
    if any(v is True for v in values):return True
    return None if any(v is None for v in values) else False


def validate_measurement(measurement: dict) -> None:
    """
    機能: r/q0の因果と各先行域のscope/既知nullを確認する。
    引数: measurement(dict)は場とcanonical足を結合済み。
    返り値: None。不正な未来/窓/値はValueError。
    """
    if not measurement['session'] or not measurement['contract'] or type(measurement['eligible']) is not bool:raise ValueError('場又は適格旗差')
    q,r=measurement['q0'],measurement['r'];now=stamp(q);at=stamp(r['stamp'])
    start,end,available=(number(r[k]) for k in ('start','end','available_at'))
    if start is None or end!=start+60 or available!=end+60 or at[0]<available or at!=now:raise ValueError('r市場/初配送/q0差')
    for key in ('price_known','volume_known','closed','missing'):
        if type(r[key]) is not bool:raise ValueError('r品質旗型差')
    if r['price_known']:
        o=r['ohlc'];p={k:number(o[k]) for k in ('open','high','low','close')}
        if any(x is None for x in p.values()) or not(0<p['low']<=p['open']<=p['high'] and p['low']<=p['close']<=p['high']):raise ValueError('r価格形状差')
    elif r['ohlc'] is not None:raise ValueError('未知rのOHLC差')
    if measurement['eligible'] and not(r['price_known'] and r['closed'] and not r['missing'] and now[0]<end+120):raise ValueError('適格q0の最新r品質差')
    for key in ('last_known','bid_known','ask_known','quote_ok','normal_bbo'):
        if type(q[key]) is not bool:raise ValueError('q0品質旗型差')
    for key in ('last','bid','ask'):
        value=number(q[key]);known=q[key+'_known']
        if known and (value is None or value<=0) or not known and value is not None:raise ValueError('q0価格known差')
    normal=q['quote_ok'] and q['bid_known'] and q['ask_known'] and q['bid']<q['ask']
    if normal!=q['normal_bbo']:raise ValueError('q0正常BBO旗差')
    ranges=measurement['prior_ranges']
    if set(ranges)!=set(map(str,WINDOWS)):raise ValueError('窓種類差')
    for width in WINDOWS:
        w=ranges[str(width)]
        if type(w['known']) is not bool or w['from']!=start-width*60 or w['to']!=start or w['duration_seconds']!=width*60 or w['expected_count']!=width:raise ValueError('r除外実時間窓差')
        if w['known']:
            if any(w[k]!=width for k in ('slot_record_count','observed_count','closed_count','price_known_count')) or any(w[k]!=0 for k in ('missing_count','absent_count','before_session_count')):raise ValueError('完全窓count差')
            high,low=number(w['high']),number(w['low'])
            if high is None or low is None or not(0<low<=high) or w['range_points']!=high-low or w['range_zero']!=(high==low):raise ValueError('既知域値差')
            for key in ('high_first_ref','low_first_ref'):
                ref=w[key]
                if ref['id']==r['id'] or not(w['from']<=ref['start']<ref['end']<=w['to']) or ref['end']!=ref['start']+60:raise ValueError('極値ref差')
        elif any(w[k] is not None for k in ('high','low','high_first_ref','low_first_ref','range_points','range_zero')):raise ValueError('未知域はnull')


def decide_sides(by_side: dict) -> dict:
    """
    機能: 同側成立を重ねず、反対側競合なら防御待機する。
    引数: by_side(dict[str,dict])。
    返り値: dictは方向/競合/全成立ID。
    """
    directions={};conflicts={};evidence=[]
    for policy in POLICIES:
        hits=[]
        for t in (1,-1):
            branch=by_side[str(t)]
            selected=branch['BR']['15'] if policy=='BR15' else branch['RV']['15'] if policy=='RV15' else branch[policy]
            flag=selected['pass']
            if flag is True:hits.append(t)
        directions[policy]=hits[0] if len(hits)==1 else 0
        conflicts[policy]=len(hits)>1
        for t in hits:
            selected=by_side[str(t)].get(policy,{})
            origins=selected.get('origins',[policy])
            evidence.append({'rule':policy,'signal_side':t,'order_side':t,
                'roles':['構造','勢い','量'] if policy=='R0' else ['方向','強度','構造','勢い','量'],
                'origins':list(origins)})
    return {'directions':directions,'conflicts':conflicts,'evidence':evidence}


def choose(buy: list,sell: list,columns: list,measurement: dict) -> dict:
    """
    機能: 共通100Xと当時のr/長窓だけで独立出生を両側判定する。
    引数: buy/sell(list[float|None])、columns(list[dict|str])、measurement(dict)。
    返り値: dictはby_side/decision。P65/旧取引/q1/ラベルは受け取らない。
    """
    names=[c['name'] if isinstance(c,dict) else c for c in columns]
    required=tuple(sorted(set((*R_KEYS,*TREND_KEYS,ATR,DISTANCE,GAP))))
    if len(names)!=100 or len(set(names))!=100 or len(buy)!=100 or len(sell)!=100 or not set(required)<=set(names):raise ValueError('100列差')
    validate_measurement(measurement);index={name:i for i,name in enumerate(names)}
    q,r=measurement['q0'],measurement['r'];o=r['ohlc'] if r['price_known'] else {};out={}
    for t,vector in ((1,buy),(-1,sell)):
        v=values(vector,index,tuple(required));atr=v[ATR];distance=v[DISTANCE];last=number(q['last'])
        price=number(q['ask' if t==1 else 'bid']) if q['normal_bbo'] else None
        valid_atr=atr is not None and atr>0
        ema=price-t*distance*atr if price is not None and distance is not None and valid_atr else None
        band=.25*atr if valid_atr else None
        if ema is not None and not math.isfinite(ema):raise ValueError('EMA8復元overflow')
        rr=recovery({k:v[k] for k in R_KEYS})
        spread=q['ask']-q['bid'] if q['normal_bbo'] else None
        common=gate({'eligible':measurement['eligible'],'R':rr['value'],'normal_bbo':q['normal_bbo'],
            'spread_positive':compare(spread,'>',0),'spread_max20':compare(spread,'<=',20),
            'gap_abs_max1':compare(abs(v[GAP]) if v[GAP] is not None else None,'<=',1),
            'ema8_chase_max1':compare(distance,'<=',1),'atr5_positive':compare(atr,'>',0)},
            {'atr5':atr,'entry_price_q0':price,'ema8_distance_atr5':distance,'last_close_gap_atr5':v[GAP],'spread':spread})
        trend=gate({**{k:compare(v[k],'>',0) for k in TREND_KEYS[:6]},
            'adx15_above25':compare(v['m15_adx'],'>',25),'adx15_delta_nonnegative':compare(v['m15_adx_delta'],'>=',0)},
            {k:v[k] for k in TREND_KEYS})
        op=t*(o['open']-ema) if o and ema is not None else None
        cp=t*(o['close']-ema) if o and ema is not None else None
        lp=t*(last-ema) if last is not None and ema is not None else None
        pb=gate({'common':common['pass'],'trend':trend['pass'],'r_open_nonpositive':compare(op,'<=',0),
            'r_close_positive':compare(cp,'>',0),'last_positive':compare(lp,'>',0),
            'entry_distance_positive':compare(distance,'>',0),'entry_distance_max_half':compare(distance,'<=',.5)},
            {'ema8_q0':ema,'r_open_to_ema8':op,'r_close_to_ema8':cp,'last_to_ema8':lp,'entry_distance_atr5':distance})
        branch={'R0':common,'R':rr,'Trend':trend,'PB':pb,'BR':{},'RV':{},
            'geometry':{'r_ref':r['id'],'ema8_q0':ema,'entry_price_q0':price,'atr5':atr,'band':band}}
        for width in WINDOWS:
            w=measurement['prior_ranges'][str(width)];high,low=w['high'],w['low'];forward=high if t==1 else low;opposite=low if t==1 else high
            close_break=t*(o['close']-forward) if o and forward is not None else None
            live_break=t*(last-forward) if last is not None and forward is not None else None
            br=gate({'common':common['pass'],'trend':trend['pass'],'window_known':w['known'],
                'close_beyond_band':compare(close_break,'>',band),'last_beyond_band':compare(live_break,'>',band),
                'volume_at_least_1_25':compare(v['m1_volume_relative_prior3'],'>=',1.25)},
                {'window_minutes':width,'lower':low,'upper':high,'band':band,'close_forward_difference':close_break,'last_forward_difference':live_break})
            extreme=o.get('low' if t==1 else 'high')
            trial=t*(extreme-opposite) if extreme is not None and opposite is not None else None
            lower=low+band if low is not None and band is not None else None
            upper=high-band if high is not None and band is not None else None
            rv=gate({'common':common['pass'],'old_ema30_opposite':compare(v['m30_ema21_delta_to_side'],'<',0),
                'old_di30_opposite':compare(v['m30_di_difference_to_side'],'<',0),'adx15_delta_negative':compare(v['m15_adx_delta'],'<',0),
                'di15_now_favorable':compare(v['m15_di_difference_to_side'],'>',0),'di5_now_favorable':compare(v['m5_di_difference_to_side'],'>',0),
                'window_known':w['known'],'width_more_two_bands':compare(w['range_points'],'>',2*band if band is not None else None),
                'opposite_extreme_outside':compare(trial,'<',-band if band is not None else None),
                'close_above_inner_low':compare(o.get('close'),'>',lower),'close_below_inner_high':compare(o.get('close'),'<',upper),
                'last_above_inner_low':compare(last,'>',lower),'last_below_inner_high':compare(last,'<',upper),
                'volume_at_least_1_25':compare(v['m1_volume_relative_prior3'],'>=',1.25)},
                {'window_minutes':width,'lower':low,'upper':high,'band':band,'opposite_extreme_difference':trial,'inner_low':lower,'inner_high':upper})
            branch['BR'][str(width)]=br;branch['RV'][str(width)]=rv
            union=logical_or([pb['pass'],br['pass'],rv['pass']])
            branch['N'+str(width)]={'known':union is not None,'pass':union,
                'origins':[name for name,value in [('PB',pb['pass']),('BR'+str(width),br['pass']),('RV'+str(width),rv['pass'])] if value is True]}
        out[str(t)]=branch
    return {'by_side':out,'decision':decide_sides(out)}
