# 153の独立出生部品

準備完了・F0未固定。自然153の入力本文、採否、容量、金融は未実行。全73場既使用、151/152後の事後着想であり、152の方向切替自体が改善要因だったという主張はしない。主U15と15分窓は結果を見る前に採用し、30/60分は比較に固定する。

純APIは `logic153.choose(buy, sell, columns, measurement)`。共用100列とq0時点のr/先行域だけを受け取り、P65/P60、旧B0、q1、モデル、教師、先着ラベルを引数に持たない。共通Rは152の片側6入力の数式だけを再用し、152のGや両側R既知必須は継承しない。各側の枝が全必要knownでtrueなら、反対側unknownでも一方向採用。同q0両trueは待機、trueなしは待機。枝ORはknown true優先。

式と境界の正本は [条件.json](条件.json)。共通Rと正常q0 BBO・spread(0,20]・Last対r.CloseのATR5距離絶対値1以下・最終実側EMA8距離1以下・ATR5正を要求。PBはTrendとq0既知EMA8をrへ当てた回復形状、実側距離(0,0.5]。BR/RVの帯は0.25ATR5、量比1.25以上、価格比較は指定の厳密不等号。RVにADX水準条件は追加しない。Hist/RSIは同じ勢い役割として記録する。

先行域はrを除く `[r.Start−W×60,r.Start)` の実時間15/30/60分。完全knownだけを使い、未知域を観測高安や後足で埋めない。r/全slotの実配送Stampはq0以前、市場End/AvailableAtを検査する。q0既知EMAをrへ後から当てた観測形状であり、r形成中から支持やarmが有効だったとは言わない。高安はCSV足の既知性であり支持水準の真偽ではない。

運転CLI:

```powershell
& work/複合テクニカル学習環境/Scripts/python.exe -X utf8 work/153独立出生の入口/選択する.py --book work/153独立出生の入口/条件.json --book-sha256 <固定SHA> --output-dir work/153独立出生の評価/入口選択 --execute-after-f0
```

実行順は、全入力の物理SHA→features/fixedのCRC/解凍SHA/前後stat→全35,339件のmetadata/r/Quote/窓照合→全新q0判断→`q0の判断.json`排他保存→capture/meta読取→固定152選択とF1を読取→取得結合。Raw/CSV/133観測は開かない。自然実行はRootがF0固定後に行う。準備器は人工のみで、自然CLIを呼ばない。

出力は以下の3JSON。大入力は複写せず恒久gzipを直接読む。

- `q0の判断.json`: 成功/試行/全q0判断数/rows。各rowは event_id/session/contract/session_index/q0_time/q0_index/q0_line/r_ref、technical[±1]の各gateと値/未知、decision.directions/conflicts/evidence。未取得も全件保持。
- `選択対応.json`: 従来の政策dict、候補と取得、全73場。R0/PB/BR15/RV15/N15/N30/N60、C1優先U15/U30/U60、固定B152/UB152。NN15はN15同体aliasで金融対象外。旧C1重複はU15/U30/U60別dict。
- `選択の確認.json`: 全源SHA、gzip物理/解凍CRCとstat証跡、出力SHA、政策件数。

別q0が同q1なら最初q0index→line→IDをcanonicalとし、後発aliasの反対側へ取り直さない。C1が優先。旧152はB0=614をB152、U1=697をUB152へ全row値copyし、C1=87の全値同体を検査する。旧選択表は全新q0保存後にしか読まない。旧利益を新出生資格へ使わない。

主全73min1はC1保護、全時間平均概ね1/hと同幅70%は別及び共同判定。未知窓や量を元の母数から落とさず、未取得も候補台帳へ残す。無選択母集団と実口座運用収支を混同しない。

準備人工は純7群と運転5群。純部分は152のnumber/values/recoveryのAST本文同体を確認し、売買価格鏡像・未知OR・0/0.5/1.25/帯境界・未来原行/r混入を検査。運転は全metadata先検査、排他保存、finiteと正値knownの区別、同q1canonical、売C1の優先3union、固定対照deepcopy、実行旗なしI/O禁止を検査する。

外部一般資料の説明/心理仮説と研究採用式は別で、根拠は停止済み `work/153独立した技術出生の設計案/設計案.md` を参照する。ここでは新しい成績保証や条件選別を行わない。
