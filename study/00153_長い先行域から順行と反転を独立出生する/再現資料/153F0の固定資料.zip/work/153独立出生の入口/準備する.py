"""自然本文を開かず153の人工と指紋だけを停止する。"""
from pathlib import Path
import ast
import hashlib
import json
import os
import subprocess
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def sha(path: Path) -> str:
    """
    機能: 物理ファイルの指紋をbufferで得る。
    引数: path(Path)。返り値: str。
    """
    h=hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda:source.read(1<<20),b''):h.update(block)
    return h.hexdigest()


def save(path: Path,value: dict) -> None:
    """
    機能: 停止証跡をUTF8排他保存する。
    引数: path(Path)、value(dict)。返り値: None。
    """
    with path.open('x',encoding='utf-8') as output:json.dump(value,output,ensure_ascii=False,indent=2,allow_nan=False);output.write('\n')


def main() -> None:
    """
    機能: 純/運転人工と構文/由来を検査し自然未実行票を保存する。
    引数: なし。返り値: None。
    """
    book=json.loads((HERE/'条件.json').read_bytes())
    paths=list(sorted(HERE.glob('*.py')))+[HERE/'README.md',HERE/'条件.json']
    paths+=list(ROOT/path for path in book['sources'] if ROOT/path not in paths)
    before={str(p.relative_to(ROOT)).replace('\\','/'):sha(p) for p in paths}
    syntax=[]
    for path in HERE.glob('*.py'):
        tree=ast.parse(path.read_text(encoding='utf-8'));compile(tree,str(path),'exec')
        for node in ast.walk(tree):
            if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
                doc=ast.get_docstring(node)
                assert doc and all(word in doc for word in ('機能:','引数:','返り値:')) and '\n' in doc,(path.name,node.name)
        syntax.append(path.name)
    parent=ast.parse((ROOT/'work/152複合回復の入口/logic152.py').read_text(encoding='utf-8'))
    current=ast.parse((HERE/'logic153.py').read_text(encoding='utf-8'))
    for name in ('number','values','recovery'):
        a=next(n for n in parent.body if isinstance(n,ast.FunctionDef) and n.name==name)
        b=next(n for n in current.body if isinstance(n,ast.FunctionDef) and n.name==name)
        assert ast.dump(ast.Module(body=a.body,type_ignores=[]),include_attributes=False)==ast.dump(ast.Module(body=b.body,type_ignores=[]),include_attributes=False),name
    env=dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8:strict')
    command=[sys.executable,'-X','utf8','-m','unittest','人工検査.py','人工検査_運転.py','-v']
    run=subprocess.run(command,cwd=HERE,env=env,capture_output=True,encoding='utf-8',errors='strict')
    assert run.returncode==0 and '\ufffd' not in run.stdout+run.stderr,run.stderr
    refs=list(book['features_source'].values())+[book['range_input'],book['fixed152_control']['selection'],book['fixed152_control']['f1']]
    refs+=[{'path':'inputs/00148_全1分入口母集団/100特徴の列定義.json','sha256':book['catalog_definition_sha256']}]
    physical={}
    for ref in refs:
        path=ROOT/ref['path'];stat=path.stat();actual=sha(path);assert actual==ref['sha256']
        physical[ref['path']]={'sha256':actual,'bytes':stat.st_size,'mtime_ns':stat.st_mtime_ns,'自然JSON本文未読':True}
    assert all(sha(ROOT/p)==h for p,h in before.items())
    assert all(sha(ROOT/p)==h for p,h in book['sources'].items())
    proof={'成功':True,'試行':153,'状態':'準備完了/F0未固定','自然153採否_容量_金融_未実行':True,
           '自然入力本文未読':True,'Raw_CSV_追加2場未読':True,'新教師又は学習なし':True,'純人工数':7,'運転人工数':5,
           'UTF8_strict':True,'人工':{'command':command,'exit_code':run.returncode,'stdout':run.stdout,'stderr':run.stderr},
           '構文と関数コメント':syntax,'152継承AST本文同体':['number','values','recovery'],
           '入力物理指紋のみ':physical,'源':before,'源前後同体':True}
    save(HERE/'準備の確認.json',proof)
    save(HERE/'停止.json',{'成功':True,'試行':153,'編集停止':True,'自然未実行':True,'源':before,'準備の確認_SHA256':sha(HERE/'準備の確認.json')})
    print(json.dumps({'成功':True,'準備':sha(HERE/'準備の確認.json'),'停止':sha(HERE/'停止.json'),'条件':sha(HERE/'条件.json')},ensure_ascii=False))


if __name__=='__main__':
    main()
