"""153の価格帯・未知OR・買売鏡像と入力時計だけを人工で検査する。"""
import copy
import inspect
import unittest
import logic153 as m

REQ=sorted(set((*m.R_KEYS,*m.TREND_KEYS,m.ATR,m.DISTANCE,m.GAP)))
NAMES=sorted(REQ+[f'人工追加{i:03}' for i in range(100-len(REQ))])
INDEX={name:i for i,name in enumerate(NAMES)}


def ranges(known: bool,low: float=99,high: float=101) -> dict:
    """
    機能: r除外の完全窓又は価格未知の窓を作る。
    引数: known(bool)、low/high(float)。
    返り値: dict[str,dict]。
    """
    result={}
    for width in m.WINDOWS:
        start=3600-width*60
        result[str(width)]={'from':start,'to':3600,'duration_seconds':width*60,'expected_count':width,
            'slot_record_count':width,'observed_count':width,'closed_count':width,'price_known_count':width if known else width-1,
            'missing_count':0,'absent_count':0,'before_session_count':0,'known':known,'unknown_reasons':[] if known else ['price_unknown'],
            'high':high if known else None,'low':low if known else None,'range_points':high-low if known else None,
            'range_zero':high==low if known else None,
            'high_first_ref':{'id':f'高{width}','start':start,'end':start+60} if known else None,
            'low_first_ref':{'id':f'低{width}','start':start,'end':start+60} if known else None}
    return result


def fixture(kind: str='PB',volume: float=1.25) -> tuple:
    """
    機能: PB/BR/RVの同足量とq0実価格をそろえた小型入力を作る。
    引数: kind(str)、volume(float)。
    返り値: tuple[list,list,dict,float,str]。
    """
    q={'time':3721,'index':10,'source_line':11,'last':100.75,'bid':100,'ask':101,
       'last_known':True,'bid_known':True,'ask_known':True,'quote_ok':True,'normal_bbo':True}
    r={'id':'r','start':3600,'end':3660,'available_at':3720,'stamp':{'time':3721,'index':10,'line':11},
       'price_known':True,'volume_known':True,'closed':True,'missing':False,'ohlc':{'open':100,'high':102,'low':99,'close':100.5}}
    measurement={'session':'人工','contract':'X','eligible':True,'q0':q,'r':r,'prior_ranges':ranges(kind!='PB')}
    ema=100
    if kind=='BR':
        q.update(last=103.5,bid=103,ask=104);r['ohlc'].update(open=102,close=103,high=104,low=101)
    if kind=='RV':
        q.update(last=103.5,bid=103,ask=104);r['ohlc'].update(open=100,close=103,high=106,low=98.5)
        measurement['prior_ranges']=ranges(True,100,110);ema=103.5
    buy,sell=features(measurement,ema,volume,kind)
    return buy,sell,measurement,ema,kind


def features(measurement: dict,ema: float,volume: float,kind: str) -> tuple:
    """
    機能: 同じq0/rから両実側の100列を独立に作る。
    引数: measurement(dict)、ema/volume(float)、kind(str)。
    返り値: tuple[list,list]。
    """
    q=measurement['q0'];o=measurement['r']['ohlc'];atr=4.;p_open=o['close']-2
    result=[]
    for t in (1,-1):
        v=[0.]*100
        for key in m.TREND_KEYS[:6]:v[INDEX[key]]=float(t)
        v[INDEX['m15_adx']]=26;v[INDEX['m15_adx_delta']]=-1 if kind=='RV' else 0
        if kind=='RV':
            v[INDEX['m30_ema21_delta_to_side']]=-t;v[INDEX['m30_di_difference_to_side']]=-t
        v[INDEX[m.ATR]]=atr;v[INDEX[m.DISTANCE]]=t*(q['ask' if t==1 else 'bid']-ema)/atr
        v[INDEX[m.GAP]]=t*(q['last']-o['close'])/atr
        v[INDEX['m1_body_ratio_to_side']]=t*(o['close']-o['open'])/(o['high']-o['low'])
        v[INDEX['m1_body_reclaim_atr5_to_side']]=t*(o['close']-p_open)/atr
        v[INDEX['m5_hist_delta_to_side']]=t;v[INDEX['m5_rsi_delta_to_side']]=t
        v[INDEX['m1_volume_relative_prior3']]=volume
        result.append(v)
    return tuple(result)


def mirror(measurement: dict) -> dict:
    """
    機能: 全物理価格を220で反射しBid/Askと高安参照を交換する。
    引数: measurement(dict)。
    返り値: dictは入力を変えない鏡像。
    """
    out=copy.deepcopy(measurement);q=out['q0'];old=measurement['q0']
    q.update(last=220-old['last'],bid=220-old['ask'],ask=220-old['bid'])
    o=measurement['r']['ohlc'];out['r']['ohlc']={'open':220-o['open'],'close':220-o['close'],'high':220-o['low'],'low':220-o['high']}
    for key,w in out['prior_ranges'].items():
        if w['known']:
            old=measurement['prior_ranges'][key];w.update(high=220-old['low'],low=220-old['high'],high_first_ref=copy.deepcopy(old['low_first_ref']),low_first_ref=copy.deepcopy(old['high_first_ref']))
    return out


class Tests(unittest.TestCase):
    def test_PB未知窓と三値OR(self):
        """
        機能: 窓未知でも独立PB成立がN15/30/60を既知trueにする。
        引数: self(Tests)。返り値: None。
        """
        buy,sell,measurement,_,_=fixture();out=m.choose(buy,sell,NAMES,measurement)
        self.assertTrue(out['by_side']['1']['PB']['pass'])
        self.assertIsNone(out['by_side']['1']['BR']['15']['pass'])
        self.assertEqual([out['decision']['directions'][f'N{x}'] for x in (15,30,60)],[1,1,1])
        self.assertEqual([m.logical_or(x) for x in ([None,True],[False,None],[False,False])],[True,None,False])

    def test_PB方向距離とOpen境界(self):
        """
        機能: PBの0超/0.5以下とr.Open等号許可を確認する。
        引数: self(Tests)。返り値: None。
        """
        buy,sell,d,_,_=fixture();out=m.choose(buy,sell,NAMES,d);self.assertTrue(out['by_side']['1']['PB']['pass'])
        for distance,expected in [(0,False),(.5,True),(.50001,False)]:
            changed=copy.deepcopy(d);changed['q0'].update(ask=100+4*distance,bid=99+4*distance)
            b,s=features(changed,100,1.25,'PB')
            result=m.choose(b,s,NAMES,changed)
            self.assertEqual(result['by_side']['1']['PB']['pass'],expected)
        d['r']['ohlc']['open']=100.1
        self.assertFalse(m.choose(buy,sell,NAMES,d)['by_side']['1']['PB']['checks']['r_open_nonpositive'])
        b,s,changed,ema,kind=fixture();changed['r']['ohlc'].update(open=99.5,close=100)
        b,s=features(changed,ema,1.25,kind)
        self.assertFalse(m.choose(b,s,NAMES,changed)['by_side']['1']['PB']['checks']['r_close_positive'])
        b,s,changed,ema,kind=fixture();changed['q0']['last']=100;b,s=features(changed,ema,1.25,kind)
        self.assertFalse(m.choose(b,s,NAMES,changed)['by_side']['1']['PB']['checks']['last_positive'])

    def test_BR厳密帯と同r量(self):
        """
        機能: BRのClose/Last等号を拒否し量比1.25等号を許可する。
        引数: self(Tests)。返り値: None。
        """
        buy,sell,d,ema,kind=fixture('BR');self.assertTrue(m.choose(buy,sell,NAMES,d)['by_side']['1']['BR']['15']['pass'])
        for key,value,check in [('close',102,'close_beyond_band'),('last',102,'last_beyond_band')]:
            changed=copy.deepcopy(d)
            if key=='last':changed['q0'][key]=value
            else:changed['r']['ohlc'].update(open=101,close=value)
            b,s=features(changed,ema,1.25,kind);self.assertFalse(m.choose(b,s,NAMES,changed)['by_side']['1']['BR']['15']['checks'][check])
        b,s=features(d,ema,1.249,kind);self.assertFalse(m.choose(b,s,NAMES,d)['by_side']['1']['BR']['15']['pass'])

    def test_RV減速内域と幅境界(self):
        """
        機能: RVはADX水準不要で内域/侵入/幅を厳密に判定する。
        引数: self(Tests)。返り値: None。
        """
        buy,sell,d,ema,kind=fixture('RV');buy[INDEX['m15_adx']]=None
        out=m.choose(buy,sell,NAMES,d);self.assertTrue(out['by_side']['1']['RV']['15']['pass']);self.assertEqual(out['decision']['directions']['N15'],1)
        for key,value,check in [('low',99,'opposite_extreme_outside'),('close',101,'close_above_inner_low'),('last',109,'last_below_inner_high')]:
            changed=copy.deepcopy(d)
            if key=='last':changed['q0'][key]=value
            else:changed['r']['ohlc'][key]=value
            b,s=features(changed,ema,1.25,kind)
            self.assertFalse(m.choose(b,s,NAMES,changed)['by_side']['1']['RV']['15']['checks'][check])
        changed=copy.deepcopy(d);changed['prior_ranges']=ranges(True,100,102)
        self.assertFalse(m.choose(buy,sell,NAMES,changed)['by_side']['1']['RV']['15']['checks']['width_more_two_bands'])
        b=list(buy);b[INDEX['m15_adx_delta']]=0
        self.assertFalse(m.choose(b,sell,NAMES,d)['by_side']['1']['RV']['15']['pass'])

    def test_共通knownと未学習入力(self):
        """
        機能: 共通の未知/ATR0/追い値超過を待機しP65/教師引数を持たない。
        引数: self(Tests)。返り値: None。
        """
        b,s,d,_,_=fixture('BR')
        for key,value in [('m1_volume_relative_prior3',None),(m.ATR,0),(m.DISTANCE,1.01),(m.GAP,1.01)]:
            v=list(b);v[INDEX[key]]=value
            self.assertIsNot(m.choose(v,s,NAMES,d)['by_side']['1']['R0']['pass'],True)
        other=list(s);other[INDEX['m1_body_ratio_to_side']]=None
        self.assertEqual(m.choose(b,other,NAMES,d)['decision']['directions']['N15'],1)
        self.assertEqual(list(inspect.signature(m.choose).parameters),['buy','sell','columns','measurement'])

    def test_売買鏡像と非改変(self):
        """
        機能: PB/BR/RVの物理価格反射で全出生方向を反転する。
        引数: self(Tests)。返り値: None。
        """
        for kind in ('PB','BR','RV'):
            b,s,d,_,_=fixture(kind);before=copy.deepcopy((b,s,d,NAMES))
            a=m.choose(b,s,NAMES,d);z=m.choose(s,b,NAMES,mirror(d))
            for policy in m.POLICIES:self.assertEqual(a['decision']['directions'][policy],-z['decision']['directions'][policy],(kind,policy))
            self.assertEqual((b,s,d,NAMES),before)
            a['by_side']['1']['R']['values']['live_reclaim']=999
            self.assertEqual((b,s,d,NAMES),before)

    def test_未来rとr混入と未知値偽装(self):
        """
        機能: 同時刻後原行・r混入窓・未知域の値埋めを拒否する。
        引数: self(Tests)。返り値: None。
        """
        b,s,d,_,_=fixture('BR')
        changed=copy.deepcopy(d);changed['r']['stamp']['line']+=1
        with self.assertRaises(ValueError):m.choose(b,s,NAMES,changed)
        changed=copy.deepcopy(d);changed['prior_ranges']['15']['high_first_ref']['id']='r'
        with self.assertRaises(ValueError):m.choose(b,s,NAMES,changed)
        changed=copy.deepcopy(d);changed['prior_ranges']['15']['to']+=60
        with self.assertRaises(ValueError):m.choose(b,s,NAMES,changed)
        changed=copy.deepcopy(d);changed['prior_ranges']=ranges(False);changed['prior_ranges']['15']['high']=101
        with self.assertRaises(ValueError):m.choose(b,s,NAMES,changed)


if __name__=='__main__':
    unittest.main(verbosity=2)
