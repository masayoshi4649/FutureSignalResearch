"""153は全q0の新技術判定を保存した後にだけ取得と旧152対照へ結ぶ。"""
from pathlib import Path
import argparse
import copy
import gc
import hashlib
import importlib.util
import json
import math
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 物理bytesの指紋を固定bufferで計算する。
    引数: path(Path)。返り値: str。
    """
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()


def module(path: Path,name: str) -> object:
    """
    機能: mainを呼ばず固定部品を私有importする。
    引数: path(Path)、name(str)。返り値: object。
    """
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec)
    sys.modules[name]=value;spec.loader.exec_module(value);return value


def save(path: Path,value: dict) -> None:
    """
    機能: UTF8で新規JSONを排他保存する。
    引数: path(Path)、value(dict)。返り値: None。
    """
    with path.open('x',encoding='utf-8') as f:json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')


def validate_book(book: dict) -> None:
    """
    機能: 採用窓と数値境界/旧対照読取段階を本文読取前に検査する。
    引数: book(dict)。返り値: None。
    """
    assert book['trial']==153 and book['parent_trial']==148 and book['primary']=='U15'
    assert book['comparison_unions']==['U30','U60'] and book['primary_window_minutes']==15
    assert (book['feature_rows'],book['session_count'],book['legacy_count'],book['catalog_count'])==(35339,73,87,100)
    assert book['no_P65_P60_qualification'] and book['no_model_or_teacher']
    assert book['common']=={'R_all6known_same_as_152':True,'normal_q0_bbo':True,'spread_range':'(0,20]',
        'abs_last_close_atr5_max':1,'final_order_ema8_distance_upper_inclusive':1,'atr5_strict_positive':True}
    assert book['Trend']=={'all_required_known':True,'ema21_real_delta_positive_widths':[5,15,30],
        'di_difference_positive_widths':[5,15,30],'adx15_strict_above':25,'adx15_delta_at_least':0}
    assert book['PB']=={'common_and_Trend':True,'q0_known_ema8_applied_to_r':True,'open_to_side_max_inclusive':0,
        'close_and_last_to_side_strict_positive':True,'entry_distance_range':'(0,0.5]','window_independent':True}
    for name in ('BR','RV'):
        assert book[name]['windows_minutes']==[15,30,60] and book[name]['band_atr5_ratio']==.25
        assert book[name]['same_r_volume_relative_prior3_at_least']==1.25
    assert book['RV']['width_strict_more_than_two_bands'] and book['RV']['adx15_delta_strict_negative']
    assert not book['RV']['require_adx_level'] and not book['RV']['claim_cross_occurred']
    assert book['R']['per_side_all_required_known'] and book['R']['one_true_other_unknown_choose_true']
    assert book['R']['both_true_wait'] and book['R']['no_true_wait']
    assert book['fixed152_control']['read_only_after_all_new_q0_saved']
    assert book['fixed152_control']['expected_counts']=={'B152':614,'UB152':697,'C1':87}


def witnesses(raw_features: dict) -> dict:
    """
    機能: 大100X原辞書からq0と短期refsだけを残す。
    引数: raw_features(dict)。返り値: dict[str,dict]。価格特徴全体は複写しない。
    """
    out={}
    for row in raw_features['rows']:
        key=row['event_id'];assert key not in out
        out[key]={'q0':dict(row['metadata']['q0']),'short_refs':copy.deepcopy(row['metadata']['short_refs'])}
    return out


def quote_equal(measured: dict,feature: dict) -> None:
    """
    機能: 正値knownと単なるfiniteの違いを保ちq0全価格を照合する。
    引数: measured/feature(dict)。返り値: None。
    """
    for key in ('time','index','source_line','last','quote_ok','normal_bbo'):assert measured[key]==feature[key],key
    for key in ('bid','ask'):
        value=feature[key];known=type(value) in (int,float) and math.isfinite(value) and value>0
        assert measured[key+'_known']==known
        assert measured[key]==(value if known else None)


def measurements(features: object,witness: dict,high: dict,core: object,expected_rows: int=40544) -> list:
    """
    機能: 全metadata/r/Quote/先行窓を先検査し特徴順の照会DTOを返す。
    引数: features(object)、witness/high(dict)、core(object)、expected_rows(int)。
    返り値: list[dict]。ここではchoose/取得/旧取引を呼ばない。
    """
    assert high['success'] and high['schema']=='prior_time_range_v1' and high['windows_minutes']==[15,30,60]
    assert not high['financial_labels_used'] and not high['strategy_selected']
    assert high['selected_trade_count'] is None and high['selected_trade_frequency'] is None
    sessions=[s['session'] for s in features.scenes];assert high['sessions']==sessions and len(high['scenes'])==len(sessions)
    metas={r['event_id']:r for r in features.q0_meta};assert set(metas)==set(witness)
    out={};seen=set();total=0
    for scene,expected in zip(high['scenes'],features.scenes):
        assert (scene['session'],scene['contract'],scene['start'],scene['continuous_end'])==(expected['session'],expected['contract'],expected['start'],expected['end']-300)
        bars={b['id']:b for b in scene['bars']};by_start={b['start']:b for b in scene['bars']}
        assert len(bars)==len(by_start)==len(scene['bars'])
        for row in scene['rows']:
            total+=1;event=row['event_id'];assert event not in seen;seen.add(event)
            assert row['r_ref']==row['slot_refs'][-1]==row['delivered_refs'][-1]
            r=bars[row['r_ref']];q=row['q0'];now=core.stamp(q)
            for key in row['delivered_refs']:assert core.stamp(bars[key]['stamp'])==now
            if not row['eligible']:
                assert event not in metas
                continue
            assert event in metas and event not in out
            meta=metas[event];assert (meta['session'],meta['contract'])==(scene['session'],scene['contract'])
            assert now==(meta['q0_time'],meta['q0_index'],meta['q0_line'])
            assert q['time']<min(expected['force_close'],expected['end']-3900)
            quote_equal(q,witness[event]['q0'])
            short=witness[event]['short_refs'];assert [x['id'] for x in short]==row['slot_refs'] and 1<=len(short)<=4
            for ref in short:
                b=bars[ref['id']];assert (ref['session'],ref['contract'])==(scene['session'],scene['contract'])
                for key in ('id','start','end','available_at','stamp','price_known','volume_known','closed'):assert ref[key]==b[key],key
                assert all(a<=z for a,z in zip(core.stamp(b['stamp']),now))
            dto={'session':scene['session'],'contract':scene['contract'],'eligible':True,'q0':q,'r':r,
                 'p':bars[row['slot_refs'][-2]] if len(row['slot_refs'])>=2 else None,'prior_ranges':row['prior_ranges']}
            core.validate_measurement(dto)
            for width in core.WINDOWS:
                w=row['prior_ranges'][str(width)]
                if not w['known']:continue
                assert w['from']>=scene['start']
                span=[by_start[w['from']+60*i] for i in range(width)]
                assert all(b['id']!=r['id'] and b['price_known'] and b['closed'] and not b['missing'] for b in span)
                assert all(all(a<=z for a,z in zip(core.stamp(b['stamp']),now)) for b in span)
                high_value=max(b['ohlc']['high'] for b in span);low_value=min(b['ohlc']['low'] for b in span)
                assert (w['high'],w['low'])==(high_value,low_value)
                assert next(b['id'] for b in span if b['ohlc']['high']==high_value)==w['high_first_ref']['id']
                assert next(b['id'] for b in span if b['ohlc']['low']==low_value)==w['low_first_ref']['id']
            out[event]=dto
    assert total==expected_rows and set(out)==set(metas)
    return [out[r['event_id']] for r in features.q0_meta]


def project(features: object,joined: list,core: object) -> list:
    """
    機能: 先検査済み全q0をI/Oや旧予測なしで判定する。
    引数: features(object)、joined(list[dict])、core(object)。返り値: list[dict]。
    """
    assert len(joined)==len(features.q0_meta)
    out=[]
    for i,(meta,dto) in enumerate(zip(features.q0_meta,joined)):
        chosen=core.choose(features.buy_X[i].tolist(),features.sell_X[i].tolist(),list(features.columns),dto)
        decision=chosen['decision'];decision['directions']['NN15']=decision['directions']['N15'];decision['conflicts']['NN15']=decision['conflicts']['N15']
        out.append({**meta,'r_ref':dto['r']['id'],'technical':chosen['by_side'],'decision':decision})
        if (i+1)%5000==0:print(json.dumps({'判定済q0':i+1,'全q0':len(joined)},ensure_ascii=False),flush=True)
    return out


def connect(decisions: list,captures: dict,metadata: dict,sessions: list,helper: object) -> dict:
    """
    機能: 全q0保存後の参照だけからC1優先3unionを作る。
    引数: decisions(list)、captures/metadata(dict)、sessions(list)、helper(object)。返り値: dict。
    """
    names=['R0','PB','BR15','RV15','N15','N30','N60']
    setting={'rules':[{'id':p} for p in names],'union_rules':['N15'],'union_id':'NN15','legacy_id':'C1','main_id':'U15','session_count':len(sessions),'legacy_count':87}
    out=helper.connect(decisions,captures['rows'],metadata['population148']['cases'],sessions,setting)
    baseline={r['case_id']:r for r in out['政策']['C1']};overlap={'U15':out.pop('旧C1重複')}
    for union,new in [('U30','N30'),('U60','N60')]:
        merged=dict(baseline);collision=[]
        for row in out['政策'][new]:
            key=row['case_id']
            if key in merged:collision.append({'case_id':key,'legacy_side':merged[key]['side'],'new_side':row['side'],'opposite':merged[key]['side']!=row['side']})
            else:merged[key]=row
        out['政策'][union]=list(merged.values());overlap[union]=collision
    out['旧C1重複']=overlap
    return out


def bind_controls(result: dict,old: dict,expected: dict) -> None:
    """
    機能: 新判断後に固定152対照を全値保持し同C1を照合する。
    引数: result/old/expected(dict)。返り値: None。新出生判定へ戻さない。
    """
    assert old['成功'] and old['試行']==152 and old['選択時の金融ラベル利用'] is False
    original={r['case_id']:r for r in old['政策']['C1']};current={r['case_id']:r for r in result['政策']['C1']}
    assert original==current and len(current)==expected['C1']
    for dest,source in [('B152','B0'),('UB152','U1')]:
        assert len(old['政策'][source])==expected[dest]
        result['政策'][dest]=copy.deepcopy(old['政策'][source])
    result['固定152同体']={'成功':True,'B152件数':expected['B152'],'UB152件数':expected['UB152'],'C1全値同体':True,'対照を新出生へ未使用':True}


def main() -> None:
    """
    機能: RootのF0後だけ全新q0保存→取得/固定対照結合の順で運転する。
    引数: CLI book(Path)/book-sha256(str)/output-dir(Path)/execute-after-f0(bool)。
    返り値: None。観測/教師/モデル/Rawは読まない。
    """
    parser=argparse.ArgumentParser()
    parser.add_argument('--book',type=Path,required=True);parser.add_argument('--book-sha256',required=True)
    parser.add_argument('--output-dir',type=Path,required=True);parser.add_argument('--execute-after-f0',action='store_true')
    args=parser.parse_args();args.book=args.book.resolve();args.output_dir=args.output_dir.resolve()
    assert args.execute_after_f0 and not args.output_dir.exists() and sha(args.book)==args.book_sha256
    book=json.loads(args.book.read_bytes());validate_book(book)
    declared={ROOT/p:h for p,h in book['sources'].items()};declared[args.book]=args.book_sha256
    for value in book['features_source'].values():declared[ROOT/value['path']]=value['sha256']
    for value in [book['range_input'],book['fixed152_control']['selection'],book['fixed152_control']['f1']]:declared[ROOT/value['path']]=value['sha256']
    catalog=ROOT/'inputs/00148_全1分入口母集団/100特徴の列定義.json';declared[catalog]=book['catalog_definition_sha256']
    assert all(sha(p)==h for p,h in declared.items())
    before={str(p):[p.stat().st_size,p.stat().st_mtime_ns] for p in declared}
    data=module(ROOT/'work/151過去場判別/data151.py','feature_only153')
    core=module(HERE/'logic153.py','logic153run');helper=module(ROOT/'scripts/入口研究/固定特徴から可読条件を選択する.py','helper153')
    refs={k:data.FileRef(ROOT/v['path'],v['sha256'],v['decoded_sha256']) for k,v in book['features_source'].items()}
    raw,a=data.read_ref(refs['features']);fixed,b=data.read_ref(refs['fixed'])
    features=data.feature_dataset_from_objects(raw,fixed,73,35339);witness=witnesses(raw)
    assert list(features.columns)==[c['name'] for c in json.loads(catalog.read_bytes())]
    del raw,fixed;gc.collect()
    r=book['range_input'];high,range_evidence=data.read_ref(data.FileRef(ROOT/r['path'],r['sha256'],r['decoded_sha256']))
    joined=measurements(features,witness,high,core);del high,witness;gc.collect()
    decisions=project(features,joined,core);del joined;gc.collect()
    assert all(sha(p)==h for p,h in declared.items())
    args.output_dir.mkdir(parents=True)
    save(args.output_dir/'q0の判断.json',{'成功':True,'試行':153,'全q0判断数':len(decisions),'新学習又はモデル':False,
        'P65_P60又は旧B0を資格へ使用':False,'全新q0判断後に取得結合':True,'rows':decisions})
    # ----------------------------------------
    # ここからだけcapture/metaと固定152の選択表を読む。新判断へは渡さない。
    captures,_=data.read_ref(refs['captures']);metadata,_=data.read_ref(refs['metadata']);sessions=[s['session'] for s in features.scenes]
    assert captures['sessions']==metadata['sessions']==sessions
    result=connect(decisions,captures,metadata,sessions,helper)
    control=book['fixed152_control'];f1_path=ROOT/control['f1']['path'];f1=json.loads(f1_path.read_bytes())
    assert f1['ファイル']['work/152複合回復の評価/入口選択/選択対応.json']==control['selection']['decoded_sha256']
    old,_=data.read_ref(data.FileRef(ROOT/control['selection']['path'],control['selection']['sha256'],control['selection']['decoded_sha256']))
    bind_controls(result,old,control['expected_counts'])
    save(args.output_dir/'選択対応.json',{'成功':True,'試行':153,'主政策':'U15','book_sha256':args.book_sha256,
        '高安入力解凍SHA256':r['decoded_sha256'],'固定152選択解凍SHA256':control['selection']['decoded_sha256'],**result})
    assert all(sha(p)==h for p,h in declared.items()) and before=={str(p):[p.stat().st_size,p.stat().st_mtime_ns] for p in declared}
    save(args.output_dir/'選択の確認.json',{'成功':True,'試行':153,'新学習又は金融又はRaw':False,'全metadata検査後に判断':True,
        '全新q0保存後に取得と固定152読取':True,'入力':{str(p.relative_to(ROOT)).replace('\\','/'):h for p,h in declared.items()},
        '全入力前後SHA_stat同体':True,'高安読取証跡':range_evidence,'特徴読取証跡':a,'固定入力読取証跡':b,
        '政策別取得数':{k:len(v) for k,v in result['政策'].items()},'出力':{p.name:sha(p) for p in args.output_dir.iterdir() if p.is_file()}})
    print(json.dumps({'成功':True,'政策別取得数':{k:len(v) for k,v in result['政策'].items()}},ensure_ascii=False))


if __name__=='__main__':
    main()
