"""153運転部を私有2行I/Oに縮約し、全metadata検査と後結合の順序を確認する。"""
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import copy
import gzip
import hashlib
import importlib.util
import json
import os
import sys
import tempfile
import 独立人工 as pure

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 小型の明示人工/Sourceだけの物理指紋を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def load(path: Path, name: str):
    """
    機能: 作者mainを起動せず対象codeだけを私有importする。
    引数: path(Path)、name(str)。返り値: module。
    """
    spec = importlib.util.spec_from_file_location(name, path); value = importlib.util.module_from_spec(spec)
    sys.modules[name] = value; spec.loader.exec_module(value)
    return value


class Vector:
    """numpyを使わず、純人工行へtolistだけを提供する。"""
    def __init__(self, value: list):
        """
        機能: 人工特徴行を保存する。
        引数: value(list)。返り値: None。
        """
        self.value = list(value)

    def tolist(self) -> list:
        """
        機能: 呼出側へ新しい人工配列を返す。
        引数: なし。返り値: list。
        """
        return list(self.value)


# ----------------------------------------
def fixtures() -> tuple:
    """
    機能: 60分の人工bar正本・2q0・旧87と新1の取得だけを作る。
    引数: なし。返り値: tupleはfeatures/raw/high/capture/meta/old152。
    """
    buy, sell, measurement = pure.fixture('PB'); sid, contract = measurement['session'], measurement['contract']
    scene = {'session': sid, 'contract': contract, 'start': 2400, 'end': 20000, 'force_close': 18000}
    bars = []
    for i in range(60):
        start = 2400 + i * 60
        bars.append({'id': f'先行{i}', 'start': start, 'end': start + 60, 'available_at': start + 120,
                     'stamp': {'time': start + 121, 'index': i, 'line': i + 1},
                     'price_known': True, 'volume_known': True, 'closed': True, 'missing': False,
                     'ohlc': {'open': 1000, 'high': 1010, 'low': 990, 'close': 1000}})
    qrows, xrows, metas = [], [], []
    for i in range(2):
        m = copy.deepcopy(measurement); start = 6000 + i * 60; index = 100 + i * 10
        r = m['r']; r.update(id=f'人工r{i}', start=start, end=start + 60, available_at=start + 120,
                             stamp={'time': start + 121, 'index': index, 'line': index + 1})
        q = m['q0']; q.update(time=start + 121, index=index, source_line=index + 1)
        bars.append(r)
        ranges = {}
        for width in (15, 30, 60):
            w = copy.deepcopy(m['prior_ranges'][str(width)]); first = 60 + i - width
            w.update({'from': start - width * 60, 'to': start,
                      'high_first_ref': {k: bars[first][k] for k in ('id', 'start', 'end')},
                      'low_first_ref': {k: bars[first][k] for k in ('id', 'start', 'end')}})
            ranges[str(width)] = w
        event = f'独立event{i}'; slots = bars[-4:]
        row = {'event_id': event, 'eligible': True, 'q0': q, 'r_ref': r['id'],
               'slot_refs': [b['id'] for b in slots], 'delivered_refs': [r['id']], 'prior_ranges': ranges}
        qrows.append(row)
        short = [{**{k: b[k] for k in ('id', 'start', 'end', 'available_at', 'stamp', 'price_known', 'volume_known', 'closed')},
                  'session': sid, 'contract': contract} for b in slots]
        xrows.append({'event_id': event, 'session': sid, 'contract': contract,
                      'metadata': {'q0': q, 'short_refs': short}})
        metas.append({'event_id': event, 'session': sid, 'contract': contract, 'session_index': 0,
                      'q0_time': q['time'], 'q0_index': index, 'q0_line': index + 1})
    features = SimpleNamespace(columns=pure.NAMES, buy_X=[Vector(buy), Vector(buy)], sell_X=[Vector(sell), Vector(sell)],
                               q0_meta=metas, scenes=[scene])
    high = {'success': True, 'schema': 'prior_time_range_v1', 'windows_minutes': [15, 30, 60],
            'financial_labels_used': False, 'strategy_selected': False, 'selected_trade_count': None,
            'selected_trade_frequency': None, 'sessions': [sid], 'scenes': [
                {'session': sid, 'contract': contract, 'start': 2400, 'continuous_end': 19700, 'bars': bars, 'rows': qrows}]}
    descriptors = [{'case_id': f'旧{i}', 'session': sid, 'contract': contract, 'original_side': -1,
                    'buy_stream': 'reverse', 'sell_stream': 'original', 'c1_reused': True} for i in range(87)]
    descriptors.append({'case_id': '新', 'session': sid, 'contract': contract, 'original_side': 1,
                        'buy_stream': 'original', 'sell_stream': 'reverse', 'c1_reused': False})
    captures = {'sessions': [sid], 'rows': []}
    for i, key in enumerate(('旧0', '新')):
        captures['rows'].append({'event_id': metas[i]['event_id'], 'session': sid, 'contract': contract,
                                'q0': copy.deepcopy(qrows[i]['q0']), 'status': 'filled', 'case_id': key,
                                'buy_stream': 'reverse' if i == 0 else 'original',
                                'sell_stream': 'original' if i == 0 else 'reverse'})
    metadata = {'sessions': [sid], 'population148': {'cases': descriptors}}
    legacy = [{'case_id': row['case_id'], 'session': sid, 'side': -1, 'stream': 'original',
               'event_id': None, 'feature_ref': None, 'origin': 'C1'} for row in descriptors if row['c1_reused']]
    new_control = [{'case_id': f'固定B{i}', 'side': 1, '由来': '人工旧152対照'} for i in range(610)]
    old = {'成功': True, '試行': 152, '選択時の金融ラベル利用': False,
           '政策': {'C1': legacy, 'B0': [*copy.deepcopy(legacy[:4]), *new_control],
                    'U1': [*copy.deepcopy(legacy), *copy.deepcopy(new_control)]}}
    return features, {'rows': xrows}, high, captures, metadata, old


# ----------------------------------------
def main() -> None:
    """
    機能: 全metadata先検査/実main順/相対path/実C1優先/固定対照の保存を人工確認する。
    引数: なし。返り値: None。自然入力を一切開かない。
    """
    paths = [ROOT / 'work/153独立出生の入口/logic153.py', ROOT / 'work/153独立出生の入口/選択する.py',
             ROOT / 'work/153独立出生の入口/条件.json', ROOT / 'scripts/入口研究/固定特徴から可読条件を選択する.py',
             ROOT / 'work/151過去場判別/data151.py']
    before = {p.relative_to(ROOT).as_posix(): sha(p) for p in paths}
    logic = load(paths[0], '私有153pure'); driver = load(paths[1], '私有153runner'); helper = load(paths[3], '凍結共通link153')
    book = json.loads(paths[2].read_bytes()); driver.validate_book(book)
    features, raw, high, captures, metadata, old = fixtures()
    original = copy.deepcopy((raw, high, captures, metadata, old))
    witness = driver.witnesses(raw); joined = driver.measurements(features, witness, high, logic, expected_rows=2)
    decisions = driver.project(features, joined, logic)
    assert len(decisions) == 2 and all(row['decision']['directions']['N15'] == 1 for row in decisions)
    assert (raw, high, captures, metadata, old) == original
    rejected = []
    for change in ('last_meta_clock', 'late_short_ref', 'late_window_value', 'late_window_r_ref'):
        h, w = copy.deepcopy(high), copy.deepcopy(witness)
        if change == 'last_meta_clock': h['scenes'][0]['rows'][-1]['q0']['time'] += 1
        elif change == 'late_short_ref': w['独立event1']['short_refs'][-1]['available_at'] += 1
        elif change == 'late_window_value': h['scenes'][0]['rows'][-1]['prior_ranges']['15']['high'] += 1
        else: h['scenes'][0]['rows'][-1]['prior_ranges']['15']['high_first_ref']['id'] = '人工r1'
        try: driver.measurements(features, w, h, logic, expected_rows=2)
        except (AssertionError, ValueError): rejected.append(change)
        else: raise AssertionError(change)
    result = driver.connect(decisions, captures, metadata, [features.scenes[0]['session']], helper)
    for policy in ('U15', 'U30', 'U60'):
        assert len(result['政策'][policy]) == 88
        assert next(row for row in result['政策'][policy] if row['case_id'] == '旧0')['side'] == -1
        assert result['旧C1重複'][policy][0]['opposite'] is True
    later = copy.deepcopy(decisions[-1]); later['event_id'] = '後発反対'; later['q0_time'] += 1
    later['q0_index'] += 1; later['q0_line'] += 1
    for policy in later['decision']['directions']: later['decision']['directions'][policy] *= -1
    for evidence in later['decision']['evidence']:
        evidence['signal_side'] *= -1; evidence['order_side'] *= -1
    later_cap = copy.deepcopy(captures['rows'][-1]); later_cap['event_id'] = later['event_id']
    later_cap['q0'].update(time=later['q0_time'], index=later['q0_index'], source_line=later['q0_line'])
    repeated = driver.connect([*decisions, later], {**captures, 'rows': [*captures['rows'], later_cap]}, metadata,
                              [features.scenes[0]['session']], helper)
    assert next(row for row in repeated['政策']['N15'] if row['case_id'] == '新')['event_id'] == '独立event1'
    assert repeated['候補と取得']['N15']['duplicate_q1'] == 1
    driver.bind_controls(result, old, {'C1': 87, 'B152': 614, 'UB152': 697})
    assert result['政策']['B152'] == old['政策']['B0'] and result['政策']['UB152'] == old['政策']['U1']
    result['政策']['B152'][0]['side'] = 9; assert old == original[-1]
    # ----------------------------------------
    # mainの数量だけを2q0/1場へ縮約し、I/Oと実純判定/実linkは維持する。
    events = []
    with tempfile.TemporaryDirectory(prefix='source153_') as temporary:
        sandbox = Path(temporary); local = copy.deepcopy(book)
        def put(relative: str, value: dict, zipped: bool = False) -> dict:
            """
            機能: 自然入力と無関係な小型人工ファイルだけを作る。
            引数: relative(str)、value(dict)、zipped(bool)。返り値: dictは参照。
            """
            body = json.dumps(value, ensure_ascii=False, allow_nan=False).encode('utf-8')
            path = sandbox / relative; path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(gzip.compress(body, mtime=0) if zipped else body)
            return {'path': relative, 'sha256': sha(path), 'decoded_sha256': hashlib.sha256(body).hexdigest()}
        local['sources'] = {}
        for key, value in [('features', raw), ('fixed', {'scenes': features.scenes}), ('captures', captures), ('metadata', metadata)]:
            local['features_source'][key] = put(f'人工入力/{key}.json.gz', value, True)
        local['range_input'] = put('人工入力/high.json.gz', high, True)
        control = put('人工入力/old152.json.gz', old, True)
        local['fixed152_control']['selection'] = control
        local['fixed152_control']['f1'] = put('人工入力/F1.json', {'ファイル': {
            'work/152複合回復の評価/入口選択/選択対応.json': control['decoded_sha256']}})
        local['catalog_definition_sha256'] = put('inputs/00148_全1分入口母集団/100特徴の列定義.json',
                                                [{'name': n} for n in pure.NAMES])['sha256']
        book_path = sandbox / '人工入力/book.json'; book_path.write_text(json.dumps(local, ensure_ascii=False), encoding='utf-8')
        refs_by_name = {Path(row['path']).name: key for key, row in local['features_source'].items()}
        refs_by_name['high.json.gz'] = 'ranges'; refs_by_name['old152.json.gz'] = 'control'
        output = sandbox / 'work/出力'
        def read_ref(ref):
            """
            機能: 私有gzipのSHA/CRCを確認し読取順を記録する。
            引数: ref(SimpleNamespace)。返り値: tuple[dict,dict]。
            """
            kind = refs_by_name[ref.path.name]
            assert sha(ref.path) == ref.sha256
            with gzip.open(ref.path, 'rb') as f: body = f.read()
            assert hashlib.sha256(body).hexdigest() == ref.decoded_sha256
            if kind in ('captures', 'metadata', 'control'): assert (output / 'q0の判断.json').exists()
            events.append('read_' + kind); return json.loads(body), {'人工': True, 'gzip全CRC': True}
        def feature_builder(a, b, sessions, rows):
            """
            機能: 固定feature射影を私有2行に縮約する。
            引数: a/b(dict)、sessions/rows(int)。返り値: SimpleNamespace。
            """
            assert sessions == 73 and rows == 35339
            events.append('feature_projection'); return features
        data = SimpleNamespace(FileRef=lambda path, a, b: SimpleNamespace(path=path, sha256=a, decoded_sha256=b),
                               read_ref=read_ref, feature_dataset_from_objects=feature_builder)
        def get_module(path, name):
            """
            機能: 自然データを開かない私有I/Oと、実純判定/凍結linkへ依存を分ける。
            引数: path(Path)、name(str)。返り値: object。
            """
            return logic if path.name == 'logic153.py' else data if path.name == 'data151.py' else helper
        original_measurements, original_project, original_save = driver.measurements, driver.project, driver.save
        def small_measurements(*args):
            """
            機能: 実metadata検査を2台帳へ縮約し、全検査完了を記録する。
            引数: args(tuple)。返り値: list。
            """
            value = original_measurements(*args, expected_rows=2); events.append('all_metadata_checked'); return value
        def project(*args):
            """
            機能: 取得読取前の実project全2判断を確認する。
            引数: args(tuple)。返り値: list。
            """
            assert events[-1] == 'all_metadata_checked'
            value = original_project(*args); events.append('all_q0_chosen'); return value
        def save(path, value):
            """
            機能: 実排他保存後にq0保存を記録する。
            引数: path(Path)、value(dict)。返り値: None。
            """
            original_save(path, value)
            if path.name == 'q0の判断.json': events.append('all_q0_saved')
        cwd = Path.cwd()
        try:
            os.chdir(sandbox)
            argv = ['人工153', '--book', '人工入力/book.json', '--book-sha256', sha(book_path),
                    '--output-dir', 'work/出力', '--execute-after-f0']
            with patch.object(driver, 'ROOT', sandbox), patch.object(driver, 'HERE', sandbox / 'work'), \
                 patch.object(driver, 'module', get_module), \
                 patch.object(driver, 'measurements', small_measurements), patch.object(driver, 'project', project), \
                 patch.object(driver, 'save', save), patch.object(sys, 'argv', argv): driver.main()
        finally: os.chdir(cwd)
        assert events == ['read_features', 'read_fixed', 'feature_projection', 'read_ranges', 'all_metadata_checked',
                          'all_q0_chosen', 'all_q0_saved', 'read_captures', 'read_metadata', 'read_control']
        final = json.loads((output / '選択対応.json').read_bytes())
        assert final['主政策'] == 'U15' and final['政策']['B152'] == old['政策']['B0']
        assert final['政策']['UB152'] == old['政策']['U1']
        for name in ('U15', 'U30', 'U60'): assert len(final['政策'][name]) == 88
    assert before == {p.relative_to(ROOT).as_posix(): sha(p) for p in paths}
    proof = {'成功': True, '自然153/148本文/金融/Raw/追加2場': False, '全metadata先検査の拒否': rejected,
             '新判断2行の保存順': events, '相対book/outputのresolve': True,
             '主U15/対照U30_U60のC1反対優先': True, '固定B152_UB152全値copy/非改変': True,
             '別q0同q1の後発反対が最早canonicalを上書きしない': True,
             'gzipの物理/解凍SHA_CRC人工': True, '旧F1の選択解凍SHA照合': True,
             'ZIP使用': '153はZIPを読まない。固定152選択gzipを全新q0保存後だけ読取。',
             'Source前後同体': before, '独立人工SHA256': sha(Path(__file__)),
             '人工縮約の限界': 'mainは数量確認だけを2q0/1場へ縮約。現bookの完全validateは別に成功し、実choose/measurements/project/connect/saveを使用。共有data151のnumpy射影・read_refはI/O人工代用で、自然全件や金融検算ではない。'}
    with (HERE / '運転の最終確認.json').open('x', encoding='utf-8', newline='\n') as out:
        json.dump(proof, out, ensure_ascii=False, indent=2); out.write('\n')
    print(json.dumps({'成功': True, '全metadata拒否数': len(rejected), '運転票SHA256': sha(HERE / '運転の最終確認.json')}, ensure_ascii=False))


if __name__ == '__main__': main()
