"""153の純判定を、作者fixture/helperを再用せず明示式のoracleで確認する。"""
from pathlib import Path
from collections import Counter
import copy
import hashlib
import importlib.util
import inspect
import itertools
import json
import math

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
LOGIC = ROOT / 'work/153独立出生の入口/logic153.py'
R = ('m1_body_ratio_to_side', 'm1_body_reclaim_atr5_to_side', 'q0_last_minus_m1_close_atr5_to_side',
     'm5_hist_delta_to_side', 'm5_rsi_delta_to_side', 'm1_volume_relative_prior3')
TREND = ('m5_ema21_delta_to_side', 'm15_ema21_delta_to_side', 'm30_ema21_delta_to_side',
         'm5_di_difference_to_side', 'm15_di_difference_to_side', 'm30_di_difference_to_side')
ATR, DIST = 'm5_atr', 'q0_entry_minus_ema8_atr5_to_side'
REQUIRED = sorted(set((*R, *TREND, 'm15_adx', 'm15_adx_delta', ATR, DIST)))
NAMES = sorted(REQUIRED + [f'独立人工の余剰列{i:03d}' for i in range(100 - len(REQUIRED))])
INDEX = {name: pos for pos, name in enumerate(NAMES)}


def known(value: object) -> float | None:
    """
    機能: 独立期待式だけで必要列の有限値と未知を分類する。
    引数: value(object)。返り値: float|None。bool/無限は不正。
    """
    if value is None: return None
    if type(value) not in (int, float): raise ValueError('独立の数値型拒否')
    result = float(value)
    if math.isnan(result): return None
    if not math.isfinite(result): raise ValueError('独立の無限拒否')
    return result


# ----------------------------------------
def all_required(conditions: list) -> bool | None:
    """
    機能: 既知falseがあっても未充足のrequiredを未知のまま残す。
    引数: conditions(list[bool|None])。返り値: bool|None。
    """
    if None in conditions: return None
    return False not in conditions


# ----------------------------------------
def tri_or(conditions: list) -> bool | None:
    """
    機能: 独立した既知true枝がある場合だけ未知ORを救う。
    引数: conditions(list[bool|None])。返り値: bool|None。
    """
    if True in conditions: return True
    return None if None in conditions else False


# ----------------------------------------
def oracle(buy: list, sell: list, measurement: dict) -> dict:
    """
    機能: Root採用式からR0/PB/BR/RV/Nを両実側で独立に求める。
    引数: buy/sell(list)、measurement(dict)。返り値: dictはpass/方向/EMA復元値。
    """
    q, r = measurement['q0'], measurement['r']; output = {}
    for side, vector in ((1, buy), (-1, sell)):
        x = {key: known(vector[INDEX[key]]) for key in REQUIRED}
        def predicate(keys: tuple, calculate) -> bool | None:
            """
            機能: 式の必要列だけに全knownを要求する。
            引数: keys(tuple)、calculate(callable)。返り値: bool|None。
            """
            return None if any(x[key] is None for key in keys) else bool(calculate())
        def relation(a, symbol: str, b) -> bool | None:
            """
            機能: 未知をfalseにしない独立比較を行う。
            引数: a/b(float|None)、symbol(str)。返り値: bool|None。
            """
            if a is None or b is None: return None
            return {'>': a > b, '<': a < b, '>=': a >= b, '<=': a <= b}[symbol]
        recovery = predicate(R, lambda: (x[R[0]] > 0 and math.fsum((x[R[1]], x[R[2]])) > 0
                                        and x[R[3]] > 0 and x[R[4]] > 0 and x[R[5]] >= 1))
        normal = q['normal_bbo']
        spread = q['ask'] - q['bid'] if normal else None
        common = all_required([measurement['eligible'], recovery, normal, relation(spread, '>', 0),
                               relation(spread, '<=', 20), relation(abs(x[R[2]]) if x[R[2]] is not None else None, '<=', 1),
                               relation(x[DIST], '<=', 1), relation(x[ATR], '>', 0)])
        trend = all_required([*(relation(x[key], '>', 0) for key in TREND),
                              relation(x['m15_adx'], '>', 25), relation(x['m15_adx_delta'], '>=', 0)])
        price = q['ask'] if side == 1 else q['bid']
        ema = (price - side * x[DIST] * x[ATR] if normal and x[DIST] is not None
               and x[ATR] is not None and x[ATR] > 0 else None)
        band = .25 * x[ATR] if x[ATR] is not None and x[ATR] > 0 else None
        o = r['ohlc']
        so = side * (o['open'] - ema) if o is not None and ema is not None else None
        sc = side * (o['close'] - ema) if o is not None and ema is not None else None
        sl = side * (q['last'] - ema) if q['last'] is not None and ema is not None else None
        pb = all_required([common, trend, relation(so, '<=', 0), relation(sc, '>', 0),
                           relation(sl, '>', 0), relation(x[DIST], '>', 0), relation(x[DIST], '<=', .5)])
        flags = {'R0': common, 'PB': pb}
        for width in (15, 30, 60):
            w = measurement['prior_ranges'][str(width)]; low, high = w['low'], w['high']
            edge = high if side == 1 else low
            close_break = side * (o['close'] - edge) if o is not None and edge is not None else None
            last_break = side * (q['last'] - edge) if q['last'] is not None and edge is not None else None
            br = all_required([common, trend, w['known'], relation(close_break, '>', band),
                               relation(last_break, '>', band), relation(x[R[5]], '>=', 1.25)])
            other = low if side == 1 else high
            extreme = o['low' if side == 1 else 'high'] if o is not None else None
            penetration = side * (extreme - other) if extreme is not None and other is not None else None
            inner_low = low + band if low is not None and band is not None else None
            inner_high = high - band if high is not None and band is not None else None
            close = o['close'] if o is not None else None
            rv = all_required([common, relation(x[TREND[2]], '<', 0), relation(x[TREND[5]], '<', 0),
                               relation(x['m15_adx_delta'], '<', 0), relation(x[TREND[4]], '>', 0),
                               relation(x[TREND[3]], '>', 0), w['known'],
                               relation(w['range_points'], '>', 2 * band if band is not None else None),
                               relation(penetration, '<', -band if band is not None else None),
                               relation(close, '>', inner_low), relation(close, '<', inner_high),
                               relation(q['last'], '>', inner_low), relation(q['last'], '<', inner_high),
                               relation(x[R[5]], '>=', 1.25)])
            flags.update({f'BR{width}': br, f'RV{width}': rv, f'N{width}': tri_or([pb, br, rv])})
        output[str(side)] = {'flags': flags, 'ema': ema}
    directions, conflicts = {}, {}
    for policy in ('R0', 'PB', 'BR15', 'RV15', 'N15', 'N30', 'N60'):
        sides = [side for side in (1, -1) if output[str(side)]['flags'][policy] is True]
        directions[policy] = sides[0] if len(sides) == 1 else 0; conflicts[policy] = len(sides) > 1
    return {'sides': output, 'directions': directions, 'conflicts': conflicts}


# ----------------------------------------
def fixture(kind: str) -> tuple:
    """
    機能: 作者fixtureとは独立の価格・ATR20・spread4で当時入力を作る。
    引数: kind(str)はPB/BR/RV。返り値: tuple[list,list,dict]。
    """
    raw = {
        'PB': (999, 1005, 997, 1001, 1002, 1000, 1004, 1000, 990, 1010),
        'BR': (1000, 1016, 999, 1012, 1013, 1011, 1015, 1000, 990, 1005),
        'RV': (1006, 1020, 994, 1010, 1012, 1010, 1014, 1010, 1000, 1040)}[kind]
    op, hi, lo, close, last, bid, ask, ema, lower, upper = raw
    q = {'clock': '独立人工', 'time': 6121, 'index': 40, 'source_line': 41,
         'last': last, 'bid': bid, 'ask': ask, 'last_known': True, 'bid_known': True,
         'ask_known': True, 'quote_ok': True, 'normal_bbo': True}
    r = {'id': '独立r', 'start': 6000, 'end': 6060, 'available_at': 6120,
         'stamp': {'time': 6121, 'index': 40, 'line': 41}, 'price_known': True,
         'volume_known': True, 'closed': True, 'missing': False,
         'ohlc': {'open': op, 'high': hi, 'low': lo, 'close': close}}
    windows = {}
    for width in (15, 30, 60):
        start = 6000 - width * 60
        windows[str(width)] = {'from': start, 'to': 6000, 'duration_seconds': width * 60,
            'expected_count': width, 'slot_record_count': width, 'observed_count': width,
            'closed_count': width, 'price_known_count': width, 'missing_count': 0,
            'absent_count': 0, 'before_session_count': 0, 'known': True, 'unknown_reasons': [],
            'high': upper, 'low': lower, 'range_points': upper - lower, 'range_zero': False,
            'high_first_ref': {'id': '独立高' + str(width), 'start': start, 'end': start + 60},
            'low_first_ref': {'id': '独立低' + str(width), 'start': start + 60, 'end': start + 120}}
    measurement = {'session': '独立人工場', 'contract': '独立人工限月', 'eligible': True,
                   'q0': q, 'r': r, 'prior_ranges': windows}
    vectors = []
    for side in (1, -1):
        x = [None] * 100
        for key in TREND: x[INDEX[key]] = side * .5
        x[INDEX['m15_adx']] = 30
        x[INDEX['m15_adx_delta']] = -.5 if kind == 'RV' else 0
        if kind == 'RV':
            x[INDEX[TREND[2]]] = -side * .5; x[INDEX[TREND[5]]] = -side * .5
        x[INDEX[ATR]] = 20
        x[INDEX[DIST]] = side * ((ask if side == 1 else bid) - ema) / 20
        x[INDEX[R[0]]] = side * (close - op) / (hi - lo)
        x[INDEX[R[1]]] = side * (close - (close - 2)) / 20
        x[INDEX[R[2]]] = side * (last - close) / 20
        x[INDEX[R[3]]] = side * .3; x[INDEX[R[4]]] = side * .2
        x[INDEX[R[5]]] = 1.25
        vectors.append(x)
    return *vectors, measurement


# ----------------------------------------
def reflect(measurement: dict, center: float = 3000) -> dict:
    """
    機能: 物理価格を反射し、Bid/Ask・上下端・上下極値参照を交換する。
    引数: measurement(dict)、center(float)。返り値: dict。
    """
    value = copy.deepcopy(measurement); q = value['q0']; old = measurement['q0']
    q.update(last=center - old['last'], bid=center - old['ask'], ask=center - old['bid'])
    o = measurement['r']['ohlc']
    value['r']['ohlc'] = {'open': center - o['open'], 'close': center - o['close'],
                         'high': center - o['low'], 'low': center - o['high']}
    for key, w in value['prior_ranges'].items():
        if w['known']:
            old = measurement['prior_ranges'][key]
            w.update(high=center - old['low'], low=center - old['high'],
                     high_first_ref=copy.deepcopy(old['low_first_ref']), low_first_ref=copy.deepcopy(old['high_first_ref']))
    return value


# ----------------------------------------
def unknown_window(measurement: dict, width: int) -> None:
    """
    機能: 値を0に補わず対象窓だけを正規の未知へ変換する。
    引数: measurement(dict)、width(int)。返り値: None。
    """
    w = measurement['prior_ranges'][str(width)]; w['known'] = False
    w['price_known_count'] -= 1; w['unknown_reasons'] = ['price_unknown']
    for key in ('high', 'low', 'high_first_ref', 'low_first_ref', 'range_points', 'range_zero'): w[key] = None


# ----------------------------------------
def check(module, buy: list, sell: list, measurement: dict) -> int:
    """
    機能: 作者純判定と独立oracleの全枝pass/known・方向・競合・EMAを比較する。
    引数: module(対象module)、buy/sell(list)、measurement(dict)。返り値: intは比較数。
    """
    before = copy.deepcopy((buy, sell, measurement, NAMES))
    expected = oracle(buy, sell, measurement); actual = module.choose(buy, sell, NAMES, measurement)
    assert (buy, sell, measurement, NAMES) == before
    count = 0
    for side in (1, -1):
        branch = actual['by_side'][str(side)]
        for name, flag in expected['sides'][str(side)]['flags'].items():
            got = branch['BR'][name[2:]] if name.startswith('BR') else branch['RV'][name[2:]] if name.startswith('RV') else branch[name]
            assert got['pass'] is flag, (side, name, flag, got)
            assert got['known'] is (flag is not None), (side, name, got)
            count += 2
        assert branch['geometry']['ema8_q0'] == expected['sides'][str(side)]['ema']; count += 1
    assert actual['decision']['directions'] == expected['directions']
    assert actual['decision']['conflicts'] == expected['conflicts']; count += 14
    actual['by_side']['1']['geometry']['r_ref'] = '出力だけ変更'
    assert (buy, sell, measurement, NAMES) == before
    return count


# ----------------------------------------
def main() -> None:
    """
    機能: 自然値なしで独立算術・境界・鏡像・未知・拒否を検査する。
    引数: なし。返り値: None。153自然採否/金融/148本文を読まない。
    """
    original = hashlib.sha256(LOGIC.read_bytes()).hexdigest()
    spec = importlib.util.spec_from_file_location('対象153純部品', LOGIC)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    assert tuple(inspect.signature(module.choose).parameters) == ('buy', 'sell', 'columns', 'measurement')
    cases, cells, checks = 0, 0, Counter()
    for kind in ('PB', 'BR', 'RV'):
        buy, sell, measurement = fixture(kind)
        baseline = module.choose(buy, sell, NAMES, measurement)['by_side']['1']
        assert (baseline['PB'] if kind == 'PB' else baseline[kind]['15'])['pass'] is True
        for side, vector in ((1, buy), (-1, sell)):
            for key in REQUIRED:
                for value in (None, -.1, 0, .1, 1, float('nan')):
                    b, s = list(buy), list(sell); (b if side == 1 else s)[INDEX[key]] = value
                    # NaNを入力同体比較できるよう、対象のunknown表現はNoneと別に実行する。
                    if isinstance(value, float) and math.isnan(value):
                        raw = module.choose(b, s, NAMES, measurement)
                        (b if side == 1 else s)[INDEX[key]] = None
                        assert raw == module.choose(b, s, NAMES, measurement); checks['NaN等価'] += 1
                    cells += check(module, b, s, measurement); cases += 1
        first = module.choose(buy, sell, NAMES, measurement)
        reflected = module.choose(sell, buy, NAMES, reflect(measurement))
        for policy, side in first['decision']['directions'].items():
            assert reflected['decision']['directions'][policy] == -side
        for side in (1, -1):
            for key in ('R0', 'PB', 'N15', 'N30', 'N60'):
                assert first['by_side'][str(side)][key]['pass'] is reflected['by_side'][str(-side)][key]['pass']
        checks['全物理価格反射/売買別実側'] += 1
        moved = copy.deepcopy(measurement)
        for key in ('last', 'bid', 'ask'): moved['q0'][key] += 10000
        for key in ('open', 'high', 'low', 'close'): moved['r']['ohlc'][key] += 10000
        for w in moved['prior_ranges'].values(): w['high'] += 10000; w['low'] += 10000
        cells += check(module, buy, sell, moved); cases += 1
        assert module.choose(buy, sell, NAMES, moved)['decision'] == first['decision']; checks['価格平行移動'] += 1
    # ----------------------------------------
    # 独立PBがtrueなら窓unknownでもORはtrueになる。R0へTrendを直列追加しない。
    buy, sell, measurement = fixture('PB')
    for width in (15, 30, 60): unknown_window(measurement, width)
    actual = module.choose(buy, sell, NAMES, measurement)
    assert actual['by_side']['1']['PB']['pass'] is True and actual['decision']['directions']['N15'] == 1
    assert actual['by_side']['1']['BR']['15']['pass'] is None
    cells += check(module, buy, sell, measurement); cases += 1; checks['独立PB/未知OR'] += 1
    for key in (*TREND, 'm15_adx', 'm15_adx_delta'): buy[INDEX[key]] = None
    assert module.choose(buy, sell, NAMES, measurement)['by_side']['1']['R0']['pass'] is True
    cells += check(module, buy, sell, measurement); cases += 1; checks['R0独立'] += 1
    # ----------------------------------------
    # 各厳密境界は隣接浮動小数と等号を個別比較する。
    for kind, key, boundary in [('PB', DIST, 0), ('PB', DIST, .5), ('BR', DIST, 1),
                                ('BR', R[5], 1.25), ('PB', 'm15_adx', 25),
                                ('PB', 'm15_adx_delta', 0), ('RV', 'm15_adx_delta', 0), ('BR', R[5], 1)]:
        buy, sell, measurement = fixture(kind)
        for value in (math.nextafter(boundary, -math.inf), boundary, math.nextafter(boundary, math.inf)):
            b = list(buy); b[INDEX[key]] = value; cells += check(module, b, sell, measurement); cases += 1
        checks['特徴値等号/両隣'] += 1
    for last, close in ((1020, 1010), (1010, 1020), (1010, 1010)):
        buy, sell, measurement = fixture('BR'); measurement['q0']['last'] = last
        measurement['r']['ohlc'].update(open=1000, close=close, high=1025, low=999)
        buy[INDEX[R[2]]] = (last - close) / 20; sell[INDEX[R[2]]] = -(last - close) / 20
        cells += check(module, buy, sell, measurement); cases += 1
        checks['BR実価格等号'] += 1
    for spread in (0, 20, 20.000001):
        buy, sell, measurement = fixture('PB'); measurement['q0']['ask'] = measurement['q0']['bid'] + spread
        measurement['q0']['quote_ok'] = measurement['q0']['normal_bbo'] = spread > 0
        buy[INDEX[DIST]] = (measurement['q0']['ask'] - 1000) / 20
        cells += check(module, buy, sell, measurement); cases += 1
        checks['spread境界'] += 1
    # ----------------------------------------
    # Root明確化: 片側true/反対側unknownは採用し、両側trueだけを競合待機する。
    buy, sell, measurement = fixture('PB'); sell[INDEX[R[3]]] = None
    actual = module.choose(buy, sell, NAMES, measurement)
    assert actual['by_side']['-1']['R0']['pass'] is None and actual['decision']['directions']['R0'] == 1
    cells += check(module, buy, sell, measurement); cases += 1; checks['片側true/反対unknownを拒否しない'] += 1
    sell = list(buy)
    actual = module.choose(buy, sell, NAMES, measurement)
    assert actual['decision']['directions']['R0'] == 0 and actual['decision']['conflicts']['R0'] is True
    cells += check(module, buy, sell, measurement); cases += 1; checks['両側true競合'] += 1
    for op in (1000, 1000.000001):
        buy, sell, measurement = fixture('PB'); measurement['r']['ohlc']['open'] = op
        actual = module.choose(buy, sell, NAMES, measurement)
        assert actual['by_side']['1']['PB']['checks']['r_open_nonpositive'] is (op == 1000)
        cells += check(module, buy, sell, measurement); cases += 1; checks['PB実Open等号'] += 1
    for key, value, check_key in [('low', 995, 'opposite_extreme_outside'),
                                  ('close', 1005, 'close_above_inner_low'), ('close', 1035, 'close_below_inner_high'),
                                  ('last', 1005, 'last_above_inner_low'), ('last', 1035, 'last_below_inner_high')]:
        buy, sell, measurement = fixture('RV')
        if key == 'last': measurement['q0'][key] = value
        else:
            measurement['r']['ohlc'][key] = value
            measurement['r']['ohlc']['high'] = max(measurement['r']['ohlc']['high'], value)
        actual = module.choose(buy, sell, NAMES, measurement)
        assert actual['by_side']['1']['RV']['15']['checks'][check_key] is False
        cells += check(module, buy, sell, measurement); cases += 1; checks['RV実価格等号'] += 1
    buy, sell, measurement = fixture('RV')
    for w in measurement['prior_ranges'].values(): w['high'] = 1010; w['range_points'] = 10
    actual = module.choose(buy, sell, NAMES, measurement)
    assert actual['by_side']['1']['RV']['15']['checks']['width_more_two_bands'] is False
    cells += check(module, buy, sell, measurement); cases += 1; checks['RV幅2b等号'] += 1
    buy, sell, measurement = fixture('PB'); buy[INDEX[R[1]]] = -buy[INDEX[R[2]]]
    assert module.choose(buy, sell, NAMES, measurement)['by_side']['1']['R']['value'] is False
    cells += check(module, buy, sell, measurement); cases += 1; checks['生存回復和0'] += 1
    buy, sell, measurement = fixture('PB'); buy[INDEX[DIST]] = -5
    assert module.choose(buy, sell, NAMES, measurement)['by_side']['1']['R0']['pass'] is True
    cells += check(module, buy, sell, measurement); cases += 1; checks['共通距離の下限なし'] += 1
    # ----------------------------------------
    # 不正値はunknownへの暗黙補正ではなく拒否する。
    rejected = 0
    for bad in (True, False, '1', float('inf'), -float('inf')):
        buy, sell, measurement = fixture('BR'); buy[INDEX[R[3]]] = bad
        try: module.choose(buy, sell, NAMES, measurement)
        except (ValueError, TypeError, OverflowError): rejected += 1
        else: raise AssertionError('不正数値を受理')
    for corrupt in ('future_time', 'future_index', 'future_line', 'r_in_window', 'window_end', 'unknown_fill'):
        buy, sell, measurement = fixture('BR')
        if corrupt.startswith('future_'):
            measurement['r']['stamp'][corrupt[7:]] += 1
        elif corrupt == 'r_in_window': measurement['prior_ranges']['15']['high_first_ref']['id'] = measurement['r']['id']
        elif corrupt == 'window_end': measurement['prior_ranges']['15']['to'] += 60
        else:
            unknown_window(measurement, 15); measurement['prior_ranges']['15']['high'] = 1005
        try: module.choose(buy, sell, NAMES, measurement)
        except (ValueError, TypeError, OverflowError): rejected += 1
        else: raise AssertionError(corrupt)
    assert hashlib.sha256(LOGIC.read_bytes()).hexdigest() == original
    proof = {'成功': True, '区分': '153純判定の独立人工、運転部は別確認待ち', '人工ケース': cases,
             '全枝known/pass/方向/EMA比較': cells, '独立追加': dict(checks), '不正拒否': rejected,
             '対象SourceSHA256': original, '独立人工SHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             '作者fixture/helperを期待値に再用': False, '自然153/148本文/金融/Raw/追加2場': False}
    with (HERE / '純判定の最終確認.json').open('x', encoding='utf-8', newline='\n') as output:
        json.dump(proof, output, ensure_ascii=False, indent=2); output.write('\n')
    print(json.dumps(proof, ensure_ascii=False, indent=2))


if __name__ == '__main__': main()
