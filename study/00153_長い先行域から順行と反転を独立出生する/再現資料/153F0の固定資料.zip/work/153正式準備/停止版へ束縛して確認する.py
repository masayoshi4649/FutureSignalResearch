"""153の最終bookだけを束縛し、事前3MD/設定513構造を確認する。"""
from pathlib import Path
import argparse
import hashlib
import json
import re
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
FORMAL = ROOT / 'study/00153_長い先行域から順行と反転を独立出生する'
PERMANENT = ROOT / 'inputs/00153_先行高安の独立出生/条件.json'


def sha(path: Path) -> str:
    """
    機能: 小型Source/正式資料の物理指紋を計算する。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def catalog(text: str) -> list[list[str]]:
    """
    機能: 57手法の9尺度行だけを他の設定/結果表と分けて抽出する。
    引数: text(str)。返り値: list[list[str]]。
    """
    return [line.split('|')[1:-1] for line in text.splitlines()
            if re.match(r'^\|\s+[A-Z]\d{2}\s+\|', line) and len(line.split('|')) == 13]


def main() -> None:
    """
    機能: 指定停止版を初めて束縛して、自然本文なしで構造/閾値/リンクを確認する。
    引数: CLI --book/--source-proof(Path)、各--sha256(str)。返り値: None。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--book', type=Path, required=True)
    parser.add_argument('--book-sha256', required=True)
    parser.add_argument('--source-proof', type=Path, required=True)
    parser.add_argument('--source-proof-sha256', required=True)
    args = parser.parse_args()
    args.book = args.book.resolve()
    args.source_proof = args.source_proof.resolve()
    assert sha(args.book) == args.book_sha256 and sha(args.source_proof) == args.source_proof_sha256
    book = json.loads(args.book.read_bytes())
    source_proof = json.loads(args.source_proof.read_bytes())
    assert source_proof.get('成功') is True
    expected_policies = ['C0','C1','RC1','B152','UB152','R0','PB','BR15','RV15','N15','U15','RU15','N30','U30','N60','U60']
    assert book['trial'] == 153 and book['primary'] == 'U15' and book['primary_window_minutes'] == 15
    assert book['financial_policies'] == expected_policies
    assert book['no_P65_P60_qualification'] is True and book['no_model_or_teacher'] is True
    assert book['R']['per_side_all_required_known'] is True
    assert book['R']['one_true_other_unknown_choose_true'] is True
    assert book['R']['both_true_wait'] is True and book['R']['no_true_wait'] is True
    assert book['BR']['band_atr5_ratio'] == book['RV']['band_atr5_ratio'] == .25
    assert book['BR']['same_r_volume_relative_prior3_at_least'] == book['RV']['same_r_volume_relative_prior3_at_least'] == 1.25
    assert book['Trend']['adx15_strict_above'] == 25 and book['Trend']['adx15_delta_at_least'] == 0
    assert book['PB']['entry_distance_range'] == '(0,0.5]'
    assert book['RV']['require_adx_level'] is False and book['RV']['claim_cross_occurred'] is False
    if PERMANENT.exists():
        assert PERMANENT.read_bytes() == args.book.read_bytes()
    else:
        PERMANENT.write_bytes(args.book.read_bytes())
    # ----------------------------------------
    # 事前文書の定数はそのままで、Source最終版という実行前情報だけを追補する。
    condition = FORMAL / '条件.md'
    text = condition.read_text(encoding='utf-8')
    assert '## F0前の最終停止版' not in text
    text = text.replace('book/Sourceは準備中、最終path/SHAはF0前に追補する。',
                        'book/Sourceの最終停止版は末尾へ束縛済み。')
    binding = f'''

## F0前の最終停止版

[153恒久book](../../inputs/00153_先行高安の独立出生/条件.json) SHA256 `{args.book_sha256}`。[Source準備票](../../{args.source_proof.relative_to(ROOT).as_posix()}) SHA256 `{args.source_proof_sha256}`。上の作成時の束縛予定をこの最終版で確定した。主U15/窓15と全定数は不変。自然選択・容量・金融は引き続き未実行。

両側のR knownを同時必須にしない153のSideUnknown解釈、同q0競合と別q0同q1 canonicalの区別は、このbookと本文を正本とする。未採用時設計案の異なる文言は適用しない。
'''
    condition.write_bytes((text + binding).encode('utf-8'))
    readme = FORMAL / 'README.md'
    current = readme.read_text(encoding='utf-8')
    current = current.replace('Source/bookは準備中で、最終停止版のSHAをF0前に追補する。',
                              'Source/bookは[条件末尾](条件.md)の最終停止版へ束縛済み。')
    readme.write_bytes(current.encode('utf-8'))
    v7 = ROOT / 'docs/議論/手法と時間スケールの汎用表_版7.md'
    original = catalog(v7.read_text(encoding='utf-8'))
    configured = catalog((FORMAL / '設定と結果.md').read_text(encoding='utf-8'))
    assert len(original) == len(configured) == 57 and all(len(row[2:]) == 9 for row in configured)
    assert [row[0] for row in original] == [row[0] for row in configured]
    heading = '| ID | 手法 | 原板・逐次 | 1分 | 3分 | 5分 | 15分 | 30分 | 60分 | セッション足 | 日足 |'
    assert (FORMAL / '設定と結果.md').read_text(encoding='utf-8').count(heading) == v7.read_text(encoding='utf-8').count(heading)
    by_id = {row[0].strip(): row[2:] for row in configured}
    assert '1分足×実時間15/30/60分' in by_id['P06'][1]
    assert '153-BR/RV' in by_id['P07'][1]
    assert all('未使用' in by_id[key][i] for key in ('P06','P07') for i in (4,5,6))
    assert '153-R' in by_id['I03'][3] and '153-R' in by_id['I04'][3]
    link_count = 0
    docs = [FORMAL / name for name in ('README.md', '条件.md', '設定と結果.md')]
    for path in docs:
        for target in re.findall(r'\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
            if '://' in target or target.startswith('#'):
                continue
            local = unquote(target.strip('<>').split('#', 1)[0])
            assert (path.parent / local).exists(), (path.name, target)
            link_count += 1
    for index in (ROOT / 'docs/README.md', ROOT / 'docs/議論/README.md'):
        assert '方向切替と待機の効果を分けて評価する.md' in index.read_text(encoding='utf-8')
    assert sha(args.book) == args.book_sha256 and sha(args.source_proof) == args.source_proof_sha256
    proof = {'成功': True, '試行': 153, '編集停止': True,
        '自然153選択_容量_金融_新価格入力本文読取': False,
        'Source最終SHA束縛': True, 'book恒久1回保存同体': {'path': PERMANENT.relative_to(ROOT).as_posix(), 'sha256': sha(PERMANENT)},
        'Source準備票': {'path': args.source_proof.relative_to(ROOT).as_posix(), 'sha256': args.source_proof_sha256},
        'V7': {'手法': 57, '尺度': 9, 'セル': 513, 'ID時間列保持': True, '使用セル閾値記入': True,
               '長窓15_30_60はP06P07の1分セル': True},
        '主': 'U15', '比較': ['U30','U60'], '金融政策': expected_policies, '比較数': 960,
        '153SideUnknownと同q0別q0競合を明示': True, 'ローカルリンク実在': link_count,
        '共通目次2点の新議論へのリンク追補': True, '旧152以前の正式編集': False,
        'Source独立レビューとは別の文書作者自己確認': True,
        '正式3MD': {path.name: sha(path) for path in docs},
        '確認器SHA256': sha(Path(__file__))}
    target = HERE / '準備の確認.json'
    assert not target.exists()
    target.write_bytes((json.dumps(proof, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    print(json.dumps({'成功': True, '513': True, 'リンク': link_count,
                      '準備SHA256': sha(target), '正式3MD': proof['正式3MD']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
