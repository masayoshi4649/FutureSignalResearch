"""153の独立した技術出生を、自然選択の前後で固定する。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent.parent
BOOK = ROOT / 'inputs/00153_先行高安の独立出生/条件.json'
STUDY = ROOT / 'study/00153_長い先行域から順行と反転を独立出生する'


def sha(path: Path) -> str:
    """
    機能: 物理ファイルを小分けに指紋化する。
    引数: path(Path)。返り値: strはSHA256。
    """
    result = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1048576), b''):
            result.update(block)
    return result.hexdigest()


# ----------------------------------------
def declared_files(value: object) -> set[Path]:
    """
    機能: bookのFileRefとSourceのpath/SHAを再帰的に照合する。
    引数: value(object)はJSON値。返り値: set[Path]は同体確認済みの入力と源。
    """
    found = set()
    if isinstance(value, dict):
        expected = value.get('sha256', value.get('physical_sha256'))
        if isinstance(value.get('path'), str) and isinstance(expected, str) and re.fullmatch('[0-9a-f]{64}', expected):
            path = (ROOT / value['path']).resolve()
            assert path.is_relative_to(ROOT) and sha(path) == expected, str(path)
            found.add(path)
        for name, item in value.items():
            if isinstance(name, str) and ('/' in name or '\\' in name) and isinstance(item, str) and re.fullmatch('[0-9a-f]{64}', item):
                path = (ROOT / name).resolve()
                assert path.is_relative_to(ROOT) and sha(path) == item, str(path)
                found.add(path)
            found.update(declared_files(item))
    elif isinstance(value, list):
        for item in value:
            found.update(declared_files(item))
    return found


# ----------------------------------------
def main() -> None:
    """
    機能: F0で入力/Source/3文書を固定し、F1で同体と生成判断を束縛する。
    引数: CLI stage(str:F0/F1)、output-dir(Path)。返り値: None。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', choices=('F0', 'F1'), required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    previous = None
    if args.stage == 'F0':
        book = json.loads(BOOK.read_bytes())
        assert book['trial'] == 153 and book['primary'] == 'U15'
        files = declared_files(book)
        assert len(files) >= 6
        files.update((BOOK, Path(__file__).resolve(), ROOT / 'docs/議論/手法と時間スケールの汎用表_版7.md'))
        for folder in ('work/153独立出生の入口', 'work/153独立出生の実行前レビュー', 'work/153正式準備'):
            base = ROOT / folder
            assert base.exists(), folder
            files.update(p for p in base.iterdir() if p.is_file())
        for name in ('README.md', '条件.md', '設定と結果.md'):
            path = STUDY / name
            target = output / 'F0実行前文書' / name
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as sink:
                sink.write(path.read_bytes())
            files.add(path)
    else:
        f0 = output / 'F0入口選択前.json'
        previous = sha(f0)
        before = json.loads(f0.read_bytes())
        files = {ROOT / name for name in before['ファイル']}
        for name, expected in before['ファイル'].items():
            assert sha(ROOT / name) == expected, name
        files.add(f0)
        selected = output / '入口選択'
        for name in ('q0の判断.json', '選択対応.json', '選択の確認.json'):
            files.add(selected / name)
        selection = json.loads((selected / '選択対応.json').read_bytes())
        assert selection['成功'] and selection['試行'] == 153
        assert selection['主政策'] == 'U15' and selection['book_sha256'] == sha(BOOK)
    result = {'成功': True, '試行': 153, '段階': args.stage,
        'UTC': datetime.now(timezone.utc).isoformat(), '前段階SHA256': previous,
        '主政策': 'U15', '主先行窓分': 15, '比較窓分': [30, 60],
        '固定対照': ['B152', 'UB152'], '新出生は旧予測を参照しない': True,
        '全73場既使用/152後の事後着想': True, '追加2場価格未読': True,
        '新判断へ教師又はq1を渡す': False,
        'ファイル': {path.relative_to(ROOT).as_posix(): sha(path) for path in sorted(files)}}
    target = output / ('F0入口選択前.json' if args.stage == 'F0' else 'F1入口選択後.json')
    with target.open('x', encoding='utf-8', newline='\n') as sink:
        json.dump(result, sink, ensure_ascii=False, indent=2, allow_nan=False)
        sink.write('\n')
    print(json.dumps({'成功': True, '段階': args.stage, '指紋数': len(files), 'sha256': sha(target)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
