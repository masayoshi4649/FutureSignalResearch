"""153保存q0のgateと取得参照だけを非金融で記述する。"""
from pathlib import Path
from collections import Counter
import argparse
import hashlib
import importlib.util
import json
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
BASE=ROOT/'work/153独立出生の評価'
F1=BASE/'F1入口選択後.json'
F1_SHA='27d40d463d1a098121829476343d476e3a31f063c5b9630b6912f4d6168ba936'
DECISION=BASE/'入口選択/q0の判断.json'
SELECT=BASE/'入口選択/選択対応.json'
STREAM=ROOT/'work/149局面の位置と急変と実反転の診断/診断する.py'
GATES=('R6','R0','Trend','方向6','PB','BR15','RV15','N15')
POLICIES=('R0','PB','BR15','RV15','N15','N30','N60')


def sha(path: Path) -> str:
    """
    機能: 本文を複写せず物理SHAを計算する。
    引数: path(Path)。返り値: str。
    """
    h=hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda:source.read(1<<20),b''):h.update(block)
    return h.hexdigest()


def module(path: Path,name: str) -> object:
    """
    機能: mainを呼ばず既存配列readerだけを私有importする。
    引数: path(Path)、name(str)。返り値: object。
    """
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec)
    sys.modules[name]=m;spec.loader.exec_module(m);return m


def truth(value) -> str:
    """
    機能: NoneとFalseを混ぜず三値名へ写す。
    引数: value(bool|None)。返り値: str。
    """
    assert value is None or type(value) is bool
    return 'unknown' if value is None else 'true' if value else 'false'


def conjunction(values: list) -> bool | None:
    """
    機能: Source同様に全必要known後だけANDを確定する。
    引数: values(list[bool|None])。返り値: bool|None。
    """
    return None if any(x is None for x in values) else all(values)


def disjunction(values: list) -> bool | None:
    """
    機能: N15だけはSourceと同じ既知true優先ORで累積する。
    引数: values(list[bool|None])。返り値: bool|None。
    """
    return True if any(x is True for x in values) else None if any(x is None for x in values) else False


def checks_for(side: dict) -> dict:
    """
    機能: 保存R6/各gateを同じ条件辞書へ整える。
    引数: side(dict)。返り値: dict[str,dict]。
    """
    values=side['R']['values']
    rchecks={k:(None if values[k] is None else values[k]>0) for k in ('m1_body_ratio_to_side','live_reclaim','m5_hist_delta_to_side','m5_rsi_delta_to_side')}
    volume=values['m1_volume_relative_prior3'];rchecks['同r量1以上']=None if volume is None else volume>=1
    # 生存回復を構成する2列のknownも必要で、派生値を0補完しない。
    for key in ('m1_body_reclaim_atr5_to_side','q0_last_minus_m1_close_atr5_to_side'):rchecks[key+'_known']=None if values[key] is None else True
    result={'R6':rchecks,'R0':side['R0']['checks'],'Trend':side['Trend']['checks'],
            '方向6':{k:v for k,v in side['Trend']['checks'].items() if k.startswith(('m5_','m15_','m30_'))},
            'PB':side['PB']['checks'],'BR15':side['BR']['15']['checks'],'RV15':side['RV']['15']['checks'],
            'N15':{'PB':side['PB']['pass'],'BR15':side['BR']['15']['pass'],'RV15':side['RV']['15']['pass']}}
    assert conjunction(list(rchecks.values()))==side['R']['value']
    return result


def new_counter() -> dict:
    """
    機能: 足側分母とq0分母を別々に初期化する。
    引数: なし。返り値: dict。
    """
    return {'q0':0,'側数':0,'gate':{},'選択':{p:Counter() for p in POLICIES},'R0_Trend組合せ':Counter(),
            'Trend8条件mask':Counter(),'R0成立側_Trend8条件mask':Counter(),'PB_BR_RV同側所属':Counter()}


def accumulate_gate(target: dict,name: str,checks: dict,flag,conditioned: dict) -> None:
    """
    機能: 重複理由と説明用固定順累積を異なる欄へ加算する。
    引数: target(dict)、name(str)、checks(dict)、flag(bool|None)、conditioned(dict)。返り値: None。
    """
    record=target.setdefault(name,{'全側':{},'R0成立側':{},'R0かつTrend成立側':{}})
    for scope,take in [('全側',True),*conditioned.items()]:
        if not take:continue
        item=record[scope];item['分母']=item.get('分母',0)+1;item['結果']=Counter(item.get('結果',{}));item['結果'][truth(flag)]+=1
        item['unknownかつfalse併存']=item.get('unknownかつfalse併存',0)+int(flag is None and any(v is False for v in checks.values()))
        item.setdefault('条件別_重複あり',{});item.setdefault('累積_コード固定順',{})
        prefix=[]
        for key,value in checks.items():
            current=item['条件別_重複あり'].setdefault(key,Counter());current[truth(value)]+=1;prefix.append(value)
            current=item['累積_コード固定順'].setdefault(key,Counter());current[truth(disjunction(prefix) if name=='N15' else conjunction(prefix))]+=1
        if 'window_known' in checks:
            item['先行窓未完備側']=item.get('先行窓未完備側',0)+int(checks['window_known'] is False)
            item['窓完備でも不成立又は未知']=item.get('窓完備でも不成立又は未知',0)+int(checks['window_known'] is True and flag is not True)


def accumulate(target: dict,row: dict) -> None:
    """
    機能: 1q0の両側gateと一方向出生を異なる分母で数える。
    引数: target(dict)、row(dict)。返り値: None。
    """
    target['q0']+=1
    for policy in POLICIES:
        side=row['decision']['directions'][policy];target['選択'][policy]['born' if side else 'wait']+=1
        target['選択'][policy]['conflict']+=int(row['decision']['conflicts'][policy])
    for side in row['technical'].values():
        target['側数']+=1;r0=side['R0']['pass'];trend=side['Trend']['pass'];checks=checks_for(side)
        conditions={'R0成立側':r0 is True,'R0かつTrend成立側':r0 is True and trend is True}
        target['R0_Trend組合せ'][truth(r0)+'/'+truth(trend)]+=1
        mask=''.join('?' if v is None else '1' if v else '0' for v in side['Trend']['checks'].values())
        target['Trend8条件mask'][mask]+=1
        if r0 is True:target['R0成立側_Trend8条件mask'][mask]+=1
        membership='|'.join(name for name,gate in [('PB',side['PB']),('BR15',side['BR']['15']),('RV15',side['RV']['15'])] if gate['pass'] is True) or 'なし'
        target['PB_BR_RV同側所属'][membership]+=1
        for name,values in checks.items():
            flag=side['R']['value'] if name=='R6' else side['BR']['15']['pass'] if name=='BR15' else side['RV']['15']['pass'] if name=='RV15' else conjunction(list(values.values())) if name=='方向6' else side[name]['pass']
            accumulate_gate(target['gate'],name,values,flag,conditions)


def selection_counts(selection: dict) -> dict:
    """
    機能: filled/canonical/C1優先の異なる段階を数える。
    引数: selection(dict)。返り値: dict。
    """
    policies=selection['政策'];out={}
    for name in POLICIES:
        counts=selection['候補と取得'][name];out[name]={'q0出生と取得status':counts,'unique取得case':len(policies[name])}
        assert len(policies[name])==counts.get('filled',0)-counts.get('duplicate_q1',0)
    branches={p:{r['case_id'] for r in policies[p]} for p in ('PB','BR15','RV15')}
    out['枝unique取得の重複']={'枝延べ':sum(map(len,branches.values())),'OR_unique':len(set.union(*branches.values())),
        'PB_BR':len(branches['PB']&branches['BR15']),'PB_RV':len(branches['PB']&branches['RV15']),'BR_RV':len(branches['BR15']&branches['RV15'])}
    fresh={r['case_id']:r for r in policies['N15']};legacy={r['case_id']:r for r in policies['C1']}
    shared=set(fresh)&set(legacy)
    out['N15とC1優先']={'N15':len(fresh),'C1':len(legacy),'同case':len(shared),'同方向':sum(fresh[k]['side']==legacy[k]['side'] for k in shared),
        '反対方向':sum(fresh[k]['side']!=legacy[k]['side'] for k in shared),'新case':len(set(fresh)-set(legacy)),'U15':len(policies['U15'])}
    assert len(policies['U15'])==len(set(fresh)|set(legacy))
    return out


def save(path: Path,value: dict) -> None:
    """
    機能: 新JSONを排他保存し元固定成果を変更しない。
    引数: path(Path)、value(dict)。返り値: None。
    """
    with path.open('x',encoding='utf-8') as output:json.dump(value,output,ensure_ascii=False,indent=2,allow_nan=False);output.write('\n')


def main() -> None:
    """
    機能: Root許可済みF1の判断/selectionだけを読み小型非金融正本を作る。
    引数: CLI --execute-after-f1(bool)。返り値: None。金融/100X/高安/Rawは読まない。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--execute-after-f1',action='store_true');args=parser.parse_args();assert args.execute_after_f1
    assert sha(F1)==F1_SHA;freeze=json.loads(F1.read_bytes());paths={F1:F1_SHA,STREAM:sha(STREAM),HERE/'診断範囲.md':sha(HERE/'診断範囲.md'),Path(__file__):sha(Path(__file__))}
    for path in (DECISION,SELECT):
        key=str(path.relative_to(ROOT)).replace('\\','/');paths[path]=freeze['ファイル'][key]
    assert all(sha(p)==h for p,h in paths.items());before={str(p):[p.stat().st_size,p.stat().st_mtime_ns] for p in paths}
    selection=json.loads(SELECT.read_bytes());sessions=selection['全73場'];assert len(sessions)==73
    counters={part:new_counter() for part in ('all','train','validation')};reader=module(STREAM,'reader153cause')
    for row in reader.array_items(DECISION,'rows'):
        accumulate(counters['all'],row);accumulate(counters['train' if row['session'] in sessions[:48] else 'validation'],row)
    assert counters['all']['q0']==35339 and counters['all']['側数']==70678
    for name in POLICIES:assert counters['all']['選択'][name]['born']==selection['候補と取得'][name].get('born',0)
    result={'成功':True,'試行':153,'金融本文未読':True,'全73場':sessions,'新採否又は閾値変更':False,'全期既使用':True,
        '分母':'q0とq0×2側を分離。条件別は重複あり、累積は固定コード順だけ。unknownにfalse併存も別記。',
        'Trend_mask順序':['EMA5','EMA15','EMA30','DI5','DI15','DI30','ADX15>25','ADX15Δ>=0'],
        '段階':counters,'取得接続':selection_counts(selection)}
    assert all(sha(p)==h for p,h in paths.items()) and before=={str(p):[p.stat().st_size,p.stat().st_mtime_ns] for p in paths}
    save(HERE/'非金融段階.json',result);save(HERE/'非金融の確認.json',{'成功':True,'金融本文未読':True,'新条件採用':False,
        '源':{str(p.relative_to(ROOT)).replace('\\','/'):h for p,h in paths.items()},'源前後SHA_stat同体':True,'出力SHA256':sha(HERE/'非金融段階.json')})
    print(json.dumps({'成功':True,'q0数':counters['all']['q0'],'取得接続':result['取得接続'],'出力SHA256':sha(HERE/'非金融段階.json')},ensure_ascii=False))


if __name__=='__main__':
    main()
