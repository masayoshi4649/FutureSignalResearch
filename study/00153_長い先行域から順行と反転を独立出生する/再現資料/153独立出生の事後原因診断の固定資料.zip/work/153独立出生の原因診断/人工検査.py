"""診断分母/未知併存/N15のORを小型保存票だけで検査する。"""
from pathlib import Path
import copy
import importlib.util
import sys
import unittest

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'work/153独立出生の入口'))
import 人工検査_運転 as fixtures
spec=importlib.util.spec_from_file_location('diagnose153test',HERE/'非金融を数える.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


class Tests(unittest.TestCase):
    def test_未知とfalse併存を分離(self):
        """
        機能: 全必要known ANDとknowntrue ORの異なる意味を保持する。
        引数: self(Tests)。返り値: None。
        """
        self.assertIsNone(m.conjunction([False,None]));self.assertIs(m.disjunction([True,None]),True)
        target={};m.accumulate_gate(target,'PB',{'既知否定':False,'未知':None},None,{'R0成立側':True,'R0かつTrend成立側':False})
        out=target['PB']['全側'];self.assertEqual(out['unknownかつfalse併存'],1)
        self.assertEqual(out['結果'],{'unknown':1});self.assertEqual(out['条件別_重複あり']['既知否定'],{'false':1})
        m.accumulate_gate(target,'N15',{'PB':True,'BR15':None,'RV15':None},True,{})
        self.assertEqual(target['N15']['全側']['累積_コード固定順']['RV15'],{'true':1})

    def test_両側分母とq0出生数(self):
        """
        機能: 1q0の2側と一方向出生を重複加算しない。
        引数: self(Tests)。返り値: None。
        """
        f,w,h=fixtures.joined_fixture();dto=fixtures.run.measurements(f,w,h,fixtures.core,1)
        row=fixtures.run.project(f,dto,fixtures.core)[0];before=copy.deepcopy(row);out=m.new_counter();m.accumulate(out,row)
        self.assertEqual((out['q0'],out['側数']),(1,2));self.assertEqual(out['選択']['PB']['born'],1)
        self.assertEqual(out['gate']['R0']['全側']['分母'],2);self.assertEqual(out['gate']['PB']['R0かつTrend成立側']['分母'],1)
        self.assertEqual(row,before)

    def test_同q1とC1保護の分母(self):
        """
        機能: 取得eventとuniquecaseとC1優先の差を区別する。
        引数: self(Tests)。返り値: None。
        """
        d,c,meta,s=fixtures.link_fixture();selected=fixtures.run.connect(d,c,meta,s,fixtures.helper)
        out=m.selection_counts(selected)
        self.assertEqual(out['N15']['q0出生と取得status']['filled'],3)
        self.assertEqual(out['N15']['unique取得case'],2)
        self.assertEqual(out['N15とC1優先'],{'N15':2,'C1':87,'同case':1,'同方向':0,'反対方向':1,'新case':1,'U15':88})


if __name__=='__main__':
    unittest.main(verbosity=2)
