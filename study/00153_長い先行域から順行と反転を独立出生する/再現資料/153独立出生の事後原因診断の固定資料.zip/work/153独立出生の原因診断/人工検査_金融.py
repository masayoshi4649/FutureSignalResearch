"""実側再生/不足時touch既知/空政策とC1優先の金融診断人工。"""
from pathlib import Path
import copy
import importlib.util
import unittest

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('finance153test',HERE/'金融を数える.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
old=m.module(m.PARENT,'fixed149one153test')


def stream(side: int,direction: int,status: str='complete') -> dict:
    """
    機能: 同入口で正逆が必ず補集合になるとは限らない人工観測を作る。
    引数: side/direction(int)、status(str)。返り値: dict。
    """
    q={'time':100,'index':1,'source_line':2,'last':100,'bid':99,'ask':101,'quote_ok':True}
    exit={**q,'time':200,'index':2,'source_line':3,'bid':226 if side==1 else 224,'ask':228 if side==1 else 226}
    return {'birth':{'side':side},'entry':q,'entry_price':q['ask' if side==1 else 'bid'],
        'outcomes':[{'seconds':3600,'status':status,'touches':[{'width':125,'direction':direction,'quote':exit if direction else None}],
                     'endpoint':exit if status=='complete' else None}]}


class Tests(unittest.TestCase):
    def test_不足でもtouch既知と費用(self):
        """
        機能: H不足でも既知touchのIFDを保持しmini1費用1077円を引く。
        引数: self(Tests)。返り値: None。
        """
        result=old.one(stream(1,1,'censored'))
        self.assertEqual((result['state'],result['ifd_known'],result['net5']),('C',True,12500-1077))
        other=old.one(stream(-1,0,'censored'));self.assertFalse(other['ifd_known']);self.assertIsNone(other['net5'])
        rows=[{'session':'人工','native':result,'inverse':other}];paired=old.paired(rows)
        self.assertEqual((paired['元方向']['C'],paired['実逆']['C']),(1,1));self.assertEqual(paired['元だけ既知'],1)

    def test_空と未到達を0勝率にしない(self):
        """
        機能: 空政策と未到達のみの率はnullとし期限清算損益は残す。
        引数: self(Tests)。返り値: None。
        """
        self.assertIsNone(old.paired([])['元方向']['到達済率'])
        value=old.one(stream(1,0));result=old.paired([{'session':'人工','native':value,'inverse':value}])
        self.assertEqual(result['元方向']['N'],1);self.assertIsNone(result['元方向']['到達済率']);self.assertEqual(result['元方向']['IFD既知'],1)

    def test_保存逆streamとC1優先を分離(self):
        """
        機能: 売格納caseの新買と旧売を同caseの異なる実streamで評価する。
        引数: self(Tests)。返り値: None。
        """
        native=old.one(stream(-1,-1));inverse=old.one(stream(1,1))
        case={'session':'場00','contract':'X','q1':{'time':100,'index':1,'source_line':2},'sides':{'original':-1,'reverse':1},'original':native,'reverse':inverse}
        new={'case_id':'x','session':'場00','event_id':'e','side':1,'stream':'reverse'}
        legacy={**new,'event_id':None,'side':-1,'stream':'original'}
        selection={'政策':{p:[] for p in m.POLICIES}}
        for p in ('R0','PB','N15'):selection['政策'][p]=[copy.deepcopy(new)]
        for p in ('U15','C1'):selection['政策'][p]=[copy.deepcopy(legacy)]
        before=copy.deepcopy(selection);rows=m.policy_rows(selection,{'x':case});summary={'集計':{}}
        sessions=[f'場{i:02}' for i in range(73)]
        for part,scope in [('all',sessions),('train',sessions[:48]),('validation',sessions[48:])]:
            summary['集計'][part]={}
            for p,values in rows.items():
                stats=old.summarize([r for r in values if r['session'] in scope],'native')
                summary['集計'][part][p]={'BBO':{'3600':{'125':{field:stats[key] for key,field in m.STAT_KEYS.items()}}}}
        result=m.financial(selection,{'x':case},sessions,old,summary)
        pair=result['全期前後']['all']['C1へ優先されたN15']
        self.assertEqual((pair['重複件数'],pair['反対方向']),(1,1));self.assertEqual(pair['N15成立側の実績']['元方向']['F'],1)
        self.assertEqual(pair['C1保護側の実績']['元方向']['A'],1);self.assertEqual(selection,before)
        empty=result['全期前後']['validation']['RV15']['参加と名目H60依存'];self.assertEqual((empty['対象場数'],empty['取得場数']),(25,0))

    def test_名目60分等号は非連結(self):
        """
        機能: H60半開端等号を別群にし0取得場も残す。
        引数: self(Tests)。返り値: None。
        """
        rows=[{'session':'場','q1_time':t,'case_id':str(t)} for t in (0,3599,7199)]
        result=m.overlap(rows,['場','空'])
        self.assertEqual((result['連結群数'],result['最大群件数']),(2,2));self.assertEqual(result['未取得場'],['空'])


if __name__=='__main__':
    unittest.main(verbosity=2)
