"""固定153成立集合を保存BBO正逆へ結び直す小型事後診断。"""
from pathlib import Path
import argparse
import copy
import hashlib
import importlib.util
import json
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
BASE=ROOT/'work/153独立出生の評価'
F1=BASE/'F1入口選択後.json'
F2=BASE/'F2実金融集計前.json'
SELECTION=BASE/'入口選択/選択対応.json'
SUMMARY=BASE/'金融集計/集計.json'
OBS=ROOT/'work/148全1分母集団の評価/固定取得の正逆観測.json'
PARENT=ROOT/'work/149局面の位置と急変と実反転の診断/診断する.py'
F1_SHA='27d40d463d1a098121829476343d476e3a31f063c5b9630b6912f4d6168ba936'
OBS_SHA='d1b4cab8a258203f04b5c1d081f57d10ed2a0c58ce4cc160ef571d5fac0ceffc'
PARENT_SHA='963044ab01273131755f4f6df963af986e49a44d0100fa6258c4b340f1e9140a'
POLICIES=('R0','PB','BR15','RV15','N15','U15','C1')
STAT_KEYS={'件数':'entries','F':'forward','A':'adverse','N':'neither','C':'censored','IFD既知':'ifd_known',
           'IFD未知':'ifd_unknown','C5利益':'ifd_net5_profit','C5損失絶対':'ifd_net5_loss','C5差引':'ifd_net5_sum'}


def sha(path: Path) -> str:
    """
    機能: 大観測をbufferで指紋化し副本を作らない。
    引数: path(Path)。返り値: str。
    """
    h=hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda:source.read(1<<20),b''):h.update(block)
    return h.hexdigest()


def module(path: Path,name: str) -> object:
    """
    機能: 保存quote実側算術と配列readerをmainなしで私有再用する。
    引数: path(Path)、name(str)。返り値: object。
    """
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec)
    sys.modules[name]=m;spec.loader.exec_module(m);return m


def policy_rows(selection: dict,cases: dict) -> dict:
    """
    機能: 選択物理側と同q1の反対側を別streamの保存値へ結ぶ。
    引数: selection/cases(dict)。返り値: dict[str,list]。
    """
    result={}
    for policy in POLICIES:
        seen=set();rows=[]
        for choice in selection['政策'][policy]:
            case=cases[choice['case_id']];stream=choice['stream'];other='reverse' if stream=='original' else 'original'
            assert case['session']==choice['session'] and choice['side']==case['sides'][stream]
            physical=(case['session'],case['q1']['time'],case['q1']['index'],case['q1']['source_line'])
            assert physical not in seen;seen.add(physical)
            rows.append({'session':case['session'],'case_id':choice['case_id'],'event_id':choice['event_id'],'side':choice['side'],
                'physical':physical,'q1_time':case['q1']['time'],'native':case[stream],'inverse':case[other]})
        result[policy]=rows
    return result


def overlap(rows: list,sessions: list) -> dict:
    """
    機能: 全場を残し名目H60半開区間の連結群を数える。
    引数: rows(list)、sessions(list)。返り値: dict。独立標本数とは呼ばない。
    """
    per_scene={};groups=[]
    for sid in sessions:
        ordered=sorted((r for r in rows if r['session']==sid),key=lambda r:(r['q1_time'],r['case_id']))
        components=[]
        for row in ordered:
            time=row['q1_time']
            if not components or time>=components[-1]['end']:components.append({'start':time,'end':time+3600,'count':1})
            else:components[-1]['end']=max(components[-1]['end'],time+3600);components[-1]['count']+=1
        per_scene[sid]={'件数':len(ordered),'連結群数':len(components),'最大群件数':max((r['count'] for r in components),default=0)}
        groups.extend(components)
    return {'対象場数':len(sessions),'取得場数':sum(v['件数']>0 for v in per_scene.values()),'未取得場':[s for s in sessions if not per_scene[s]['件数']],
            '最小場件数':min((v['件数'] for v in per_scene.values()),default=0),'最大場件数':max((v['件数'] for v in per_scene.values()),default=0),
            '連結群数':len(groups),'最大群件数':max((r['count'] for r in groups),default=0),'場別':per_scene}


def financial(selection: dict,cases: dict,sessions: list,old: object,summary: dict) -> dict:
    """
    機能: 固定枝の前後とC1優先部分を同q1実正逆で診断する。
    引数: selection/cases/summary(dict)、sessions(list)、old(object)。返り値: dict。
    """
    policies=policy_rows(selection,cases);result={};checked=0
    fresh={r['case_id']:r for r in policies['N15']};legacy={r['case_id']:r for r in policies['C1']};shared=set(fresh)&set(legacy)
    for part,scope in [('all',sessions),('train',sessions[:48]),('validation',sessions[48:])]:
        current={p:[r for r in rows if r['session'] in scope] for p,rows in policies.items()}
        result[part]={}
        for policy,rows in current.items():
            paired=old.paired(rows);expected=summary['集計'][part][policy]['BBO']['3600']['125']
            for key,field in STAT_KEYS.items():assert paired['元方向'][key]==expected[field],(part,policy,key);checked+=1
            result[part][policy]={'同q1実正逆':paired,'参加と名目H60依存':overlap(rows,scope)}
        keys=[k for k in shared if fresh[k]['session'] in scope]
        result[part]['C1へ優先されたN15']={'重複件数':len(keys),'同方向':sum(fresh[k]['side']==legacy[k]['side'] for k in keys),
             '反対方向':sum(fresh[k]['side']!=legacy[k]['side'] for k in keys),'N15成立側の実績':old.paired([fresh[k] for k in keys]),
             'C1保護側の実績':old.paired([legacy[k] for k in keys]),'新規N15差分':old.paired([r for r in current['N15'] if r['case_id'] not in legacy])}
    return {'全期前後':result,'Root正本一致セル':checked}


def save(path: Path,value: dict) -> None:
    """
    機能: 小型正本を排他保存する。
    引数: path(Path)、value(dict)。返り値: None。
    """
    with path.open('x',encoding='utf-8') as output:json.dump(value,output,ensure_ascii=False,indent=2,allow_nan=False);output.write('\n')


def main() -> None:
    """
    機能: Root金融通知後だけ保存同q1を読み実逆を算出する。
    引数: CLI f2-sha256/summary-sha256(str)、execute-after-notification(bool)。返り値: None。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--f2-sha256',required=True);parser.add_argument('--summary-sha256',required=True)
    parser.add_argument('--execute-after-notification',action='store_true');args=parser.parse_args();assert args.execute_after_notification
    paths={F1:F1_SHA,F2:args.f2_sha256,SUMMARY:args.summary_sha256,OBS:OBS_SHA,PARENT:PARENT_SHA,
           HERE/'診断範囲.md':sha(HERE/'診断範囲.md'),Path(__file__):sha(Path(__file__))}
    assert all(sha(p)==h for p,h in paths.items());f1=json.loads(F1.read_bytes());f2=json.loads(F2.read_bytes())
    key=str(SELECTION.relative_to(ROOT)).replace('\\','/');paths[SELECTION]=f1['ファイル'][key]
    assert f2['ファイル'][key]==paths[SELECTION] and f2['F1_SHA256']==F1_SHA and sha(SELECTION)==paths[SELECTION]
    before={str(p):[p.stat().st_size,p.stat().st_mtime_ns] for p in paths}
    selection=json.loads(SELECTION.read_bytes());summary=json.loads(SUMMARY.read_bytes());sessions=selection['全73場']
    assert len(sessions)==73 and summary['F1_SHA256']==F1_SHA and summary['F2_SHA256']==args.f2_sha256
    old=module(PARENT,'fixed149onefor153cause');needed={r['case_id'] for p in POLICIES for r in selection['政策'][p]};cases={};scene_count=0
    for scene in old.array_items(OBS,'scenes'):
        assert scene['success'] and scene['session']==sessions[scene_count];scene_count+=1
        for case in scene['cases']:
            if case['id'] not in needed:continue
            assert case['id'] not in cases and case['original']['entry']==case['reverse']['entry']
            cases[case['id']]={'session':scene['session'],'q1':case['original']['entry'],
                'sides':{s:case[s]['birth']['side'] for s in ('original','reverse')},
                'original':old.one(case['original']),'reverse':old.one(case['reverse'])}
    assert scene_count==73 and set(cases)==needed
    values=financial(selection,cases,sessions,old,summary)
    assert all(sha(p)==h for p,h in paths.items()) and before=={str(p):[p.stat().st_size,p.stat().st_mtime_ns] for p in paths}
    output={'成功':True,'試行':153,'主U15不変':True,'H秒':3600,'同幅pt':125,'全期既使用':True,
        '実逆は1-pでない':True,'同時IFD合計は実口座収支でない':True,'未取得機会損失なし':True,'新条件採用なし':True,**values}
    save(HERE/'金融診断.json',output);save(HERE/'金融の確認.json',{'成功':True,'新観測又はRaw読取':False,'Source又は閾値変更':False,
        '源':{str(p.relative_to(ROOT)).replace('\\','/'):h for p,h in paths.items()},'源前後SHA_stat同体':True,'出力SHA256':sha(HERE/'金融診断.json')})
    print(json.dumps({'成功':True,'一致セル':values['Root正本一致セル'],'R0実正逆':values['全期前後']['all']['R0']['同q1実正逆']},ensure_ascii=False))


if __name__=='__main__':
    main()
