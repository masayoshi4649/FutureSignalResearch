"""独立条件表と取得結合だけを小人工で先に確かめる。"""
from pathlib import Path
import copy
import hashlib
import json
import sys
import 当時条件 as c
import 監査する as a

HERE = Path(__file__).resolve().parent


def main() -> None:
    """
    機能: 既存独立oracleの3枝/未知ORとC1/同q1/cancelの最小人工を実行する。
    引数: なし。返り値: None。作者153と自然判断・金融は読まない。
    """
    count = 0
    for kind in ('PB', 'BR', 'RV'):
        b, s, m = c.old.fixture(kind); value = c.reconstruct(b, s, c.old.NAMES, m)
        assert value['decision']['directions']['N15'] == 1
        assert value['decision']['directions']['NN15'] == 1; count += 1
        z = c.reconstruct(s, b, c.old.NAMES, c.old.reflect(m))
        assert all(z['decision']['directions'][key] == -side for key, side in value['decision']['directions'].items()); count += 1
    b, s, m = c.old.fixture('PB')
    for width in (15, 30, 60): c.old.unknown_window(m, width)
    value = c.reconstruct(b, s, c.old.NAMES, m)
    assert value['technical']['1']['N15']['pass'] is True and value['technical']['1']['BR']['15']['pass'] is None; count += 1
    sessions = ['人工場']; descriptors = [{'case_id': f'旧{i}', 'session': '人工場', 'contract': 'X', 'original_side': -1,
        'buy_stream': 'reverse', 'sell_stream': 'original', 'c1_reused': True} for i in range(87)]
    descriptors.append({'case_id': '新', 'session': '人工場', 'contract': 'X', 'original_side': 1,
        'buy_stream': 'original', 'sell_stream': 'reverse', 'c1_reused': False})
    rows, caps = [], []
    for i, (key, status) in enumerate([('旧0', 'filled'), ('新', 'filled'), ('新', 'filled'), (None, 'expired')]):
        meta = {'event_id': f'E{i}', 'session': '人工場', 'contract': 'X', 'session_index': 0,
                'q0_time': 100 + i, 'q0_index': i, 'q0_line': i + 1}
        rows.append({**meta, 'decision': copy.deepcopy(value['decision'])})
        caps.append({'event_id': meta['event_id'], 'session': '人工場', 'contract': 'X',
            'q0': {'time': 100 + i, 'index': i, 'source_line': i + 1}, 'status': status, 'case_id': key,
            'buy_stream': 'reverse' if key == '旧0' else 'original', 'sell_stream': 'original' if key == '旧0' else 'reverse'})
    result = a.join(rows, {'rows': caps, 'sessions': sessions}, {'population148': {'cases': descriptors}, 'sessions': sessions}, sessions)
    for policy in ('U15', 'U30', 'U60'):
        assert len(result['政策'][policy]) == 88
        assert next(r for r in result['政策'][policy] if r['case_id'] == '旧0')['side'] == -1
    assert next(r for r in result['政策']['N15'] if r['case_id'] == '新')['event_id'] == 'E1'
    assert result['候補と取得']['N15']['duplicate_q1'] == 1 and result['候補と取得']['N15']['expired'] == 1
    count += 1
    assert a.stamp({'time': 1, 'index': 0, 'line': 1}) == a.stamp({'time': 1, 'index': 0, 'source_line': 1})
    count += 1
    assert not any('/153独立出生の入口/' in str(getattr(value, '__file__', '')).replace('\\', '/') for value in sys.modules.values())
    proof = {'成功': True, '人工確認': count, '作者logic153/runner_import': False,
             '自然153出力/金融/Raw本文読取': False, '区分': 'F1通知後、自然全件監査を始める前の人工。F0事前固定ではない。',
             '固定源': {name: hashlib.sha256((HERE / name).read_bytes()).hexdigest() for name in ('当時条件.py', '監査する.py', '準備人工.py')},
             '依存独立oracleSHA256': hashlib.sha256(c.ORACLE_PATH.read_bytes()).hexdigest()}
    with (HERE / '準備の確認.json').open('x', encoding='utf-8', newline='\n') as output:
        json.dump(proof, output, ensure_ascii=False, indent=2); output.write('\n')
    print(json.dumps({'成功': True, '人工確認': count}, ensure_ascii=False))


if __name__ == '__main__': main()
