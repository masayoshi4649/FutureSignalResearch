"""153全q0条件を先に再構成し、その後に取得と固定対照を独立結合する。"""
from pathlib import Path
from collections import Counter
import argparse
import copy
import gzip
import hashlib
import json
import math
import re
import 当時条件 as condition

ROOT = Path(__file__).resolve().parents[2]
NAMES = (*condition.POLICIES, 'NN15')


def sha(path: Path) -> str:
    """
    機能: 明示された固定入力の全物理指紋を求める。
    引数: path(Path)。返り値: str。
    """
    value = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1 << 20), b''): value.update(block)
    return value.hexdigest()


# ----------------------------------------
def read(path: Path, physical: str, decoded: str | None = None) -> dict:
    """
    機能: SHAとgzip全CRCを確認しplain副本を作らずJSONを読む。
    引数: path(Path)、physical(str)、decoded(str|None)。返り値: dict。
    """
    assert sha(path) == physical
    with (gzip.open(path, 'rb') if path.suffix == '.gz' else path.open('rb')) as source: body = source.read()
    assert decoded is None or hashlib.sha256(body).hexdigest() == decoded
    return json.loads(body)


# ----------------------------------------
def rows(path: Path, evidence: dict):
    """
    機能: 巨大なq0 JSONを1行ずつ解析して全bytesを指紋へ加える。
    引数: path(Path)、evidence(dict)。返り値: Iterator[dict]。
    """
    digest = hashlib.sha256(); size = 0; decoder = json.JSONDecoder(); buffer = ''
    with path.open('rt', encoding='utf-8', newline='') as source:
        def more() -> str:
            """
            機能: 文字境界を保ったblockを読み指紋を更新する。
            引数: なし。返り値: str。
            """
            nonlocal size
            text = source.read(1 << 20); raw = text.encode('utf-8'); digest.update(raw); size += len(raw)
            return text
        while True:
            text = more(); assert text, 'rowsがない'
            buffer += text; match = re.search(r'(?m)^  "rows": \[', buffer)
            if match: buffer = buffer[match.end():]; break
        while True:
            buffer = buffer.lstrip()
            if buffer.startswith(']'): break
            if buffer.startswith(','): buffer = buffer[1:].lstrip()
            try: item, end = decoder.raw_decode(buffer)
            except json.JSONDecodeError:
                text = more(); assert text, 'rows途中終了'; buffer += text; continue
            yield item; buffer = buffer[end:]
        while more(): pass
    evidence.update(sha256=digest.hexdigest(), bytes=size)


# ----------------------------------------
def stamp(value: dict) -> tuple:
    """
    機能: 保存Stampとq0のline/source_lineを同じ物理行として取り出す。
    引数: value(dict)。返り値: tuple[float,int,int]。
    """
    return value['time'], value['index'], value['line'] if 'line' in value else value['source_line']


# ----------------------------------------
def equal(expected, actual, path: str = '') -> int:
    """
    機能: 全キー・配列順・型付き末端を漏れなく照合する。
    引数: expected/actual(object)、path(str)。返り値: intは末端比較数。
    """
    if isinstance(expected, dict):
        assert isinstance(actual, dict) and set(expected) == set(actual), path
        return sum(equal(value, actual[key], path + '/' + str(key)) for key, value in expected.items())
    if isinstance(expected, list):
        assert isinstance(actual, list) and len(expected) == len(actual), path
        return sum(equal(value, actual[i], path + '/' + str(i)) for i, value in enumerate(expected))
    if expected is None: assert actual is None, path
    elif isinstance(expected, bool): assert type(actual) is bool and expected == actual, (path, expected, actual)
    elif type(expected) in (int, float): assert type(actual) in (int, float) and math.isfinite(actual) and expected == actual, (path, expected, actual)
    else: assert type(expected) is type(actual) and expected == actual, (path, expected, actual)
    return 1


# ----------------------------------------
def join(decisions: list, captures: dict, metadata: dict, sessions: list) -> dict:
    """
    機能: 独立判断だけを取得表へ結び、同q1最早とC1優先の全unionを作る。
    引数: decisions(list)、captures/metadata(dict)、sessions(list)。返り値: dict。
    """
    events = {row['event_id']: row for row in captures['rows']}
    descriptors = metadata['population148']['cases']; cases = {row['case_id']: row for row in descriptors}
    assert len(events) == len(decisions) == len({row['event_id'] for row in decisions})
    assert set(events) == {row['event_id'] for row in decisions} and len(cases) == len(descriptors)
    assert captures['sessions'] == metadata['sessions'] == sessions
    selected = {name: {} for name in NAMES}; counts = {name: Counter() for name in NAMES}
    order = {session: i for i, session in enumerate(sessions)}
    for row in sorted(decisions, key=lambda r: (order[r['session']], r['q0_index'], r['q0_line'], r['event_id'])):
        cap = events[row['event_id']]
        assert (cap['session'], cap['contract']) == (row['session'], row['contract'])
        assert (cap['q0']['time'], cap['q0']['index'], cap['q0']['source_line']) == (row['q0_time'], row['q0_index'], row['q0_line'])
        for policy in NAMES:
            if row['decision']['conflicts'][policy]: counts[policy]['conflict_wait'] += 1
            side = row['decision']['directions'][policy]
            if not side: continue
            counts[policy]['born'] += 1; counts[policy][cap['status']] += 1
            if cap['status'] != 'filled': continue
            key = cap['case_id']; desc = cases[key]
            assert (desc['session'], desc['contract']) == (row['session'], row['contract'])
            if key in selected[policy]: counts[policy]['duplicate_q1'] += 1; continue
            stream_key = 'buy_stream' if side == 1 else 'sell_stream'
            assert cap[stream_key] == desc[stream_key]
            hits = [hit for hit in row['decision']['evidence'] if hit['order_side'] == side and hit['rule'] == ('N15' if policy == 'NN15' else policy)]
            selected[policy][key] = {'case_id': key, 'session': row['session'], 'side': side, 'stream': cap[stream_key],
                'event_id': row['event_id'], 'feature_ref': row['event_id'], 'q0_time': row['q0_time'],
                'q0_index': row['q0_index'], 'q0_line': row['q0_line'], '成立ID': sorted({h['rule'] for h in hits}), 'evidence': hits, 'origin': policy}
    legacy = {row['case_id']: {'case_id': row['case_id'], 'session': row['session'], 'side': row['original_side'],
              'stream': 'original', 'event_id': None, 'feature_ref': None, 'origin': 'C1'} for row in descriptors if row['c1_reused']}
    assert len(legacy) == 87
    policies = {name: list(value.values()) for name, value in selected.items()}; policies['C1'] = list(legacy.values()); overlap = {}
    for policy, source in (('U15', 'NN15'), ('U30', 'N30'), ('U60', 'N60')):
        merged = dict(legacy); alias = []
        for key, row in selected[source].items():
            if key in legacy: alias.append({'case_id': key, 'legacy_side': legacy[key]['side'], 'new_side': row['side'], 'opposite': legacy[key]['side'] != row['side']})
            else: merged[key] = row
        policies[policy] = list(merged.values()); overlap[policy] = alias
    return {'政策': policies, '候補と取得': {name: dict(value) for name, value in counts.items()},
            '旧C1重複': overlap, '全73場': sessions, '選択時の金融ラベル利用': False}


# ----------------------------------------
def main() -> None:
    """
    機能: Root F1通知後だけ全q0を先に再構成し取得/旧対照を後結合する。
    引数: CLI --f0/--f1/--book/--run-dir/--output-dir(Path)と各sha256(str)。返り値: None。
    """
    parser = argparse.ArgumentParser()
    for name in ('f0', 'f1', 'book', 'run-dir', 'output-dir'): parser.add_argument('--' + name, type=Path, required=True)
    for name in ('f0-sha256', 'f1-sha256', 'book-sha256'): parser.add_argument('--' + name, required=True)
    args = parser.parse_args(); f0 = read(args.f0, args.f0_sha256); f1 = read(args.f1, args.f1_sha256); book = read(args.book, args.book_sha256)
    assert f0['試行'] == f1['試行'] == book['trial'] == 153 and f1['前段階SHA256'] == args.f0_sha256
    files = {**f0['ファイル'], **f1['ファイル']}; assert all(f1['ファイル'].get(p) == h for p, h in f0['ファイル'].items())
    before = {p: (sha(ROOT / p), (ROOT / p).stat().st_size, (ROOT / p).stat().st_mtime_ns) for p in files}
    assert all(before[p][0] == h for p, h in files.items())
    assert sha(condition.ORACLE_PATH) == 'cb33520e3f8a0db584b8dd02d6a3c509adba7a35b9ae6ebb8e0419ecacba12aa'
    refs = book['features_source']; value = refs['features']; features = read(ROOT / value['path'], value['sha256'], value['decoded_sha256'])
    value = book['range_input']; high = read(ROOT / value['path'], value['sha256'], value['decoded_sha256'])
    assert features['success'] and features['trial'] == 148 and not features['financial_labels_used'] and features['selected_trade_count'] is None
    assert high['success'] and high['schema'] == 'prior_time_range_v1' and not high['financial_labels_used']
    columns = [row['name'] for row in features['catalog']]; sessions = features['sessions']
    assert columns == sorted(set(columns)) and len(columns) == 100 and len(sessions) == 73 and high['sessions'] == sessions
    measurements = {}; seen = set(); source_counts = Counter()
    for scene in high['scenes']:
        bars = {bar['id']: bar for bar in scene['bars']}; assert len(bars) == len(scene['bars'])
        for row in scene['rows']:
            assert row['event_id'] not in seen; seen.add(row['event_id']); source_counts['all_q0'] += 1
            if row['eligible']:
                assert row['r_ref'] == row['slot_refs'][-1] == row['delivered_refs'][-1]
                measurements[row['event_id']] = (scene, bars, row); source_counts['eligible'] += 1
    assert source_counts == {'all_q0': 40544, 'eligible': 35339} and len(features['rows']) == 35339
    path = args.run_dir / 'q0の判断.json'; expected_sha = files[path.resolve().relative_to(ROOT).as_posix()]
    stream_proof = {}; iterator = iter(rows(path, stream_proof)); minimal = []; cells = 0; digest = hashlib.sha256(); flags = Counter()
    for i, feature in enumerate(features['rows']):
        scene, bars, measured = measurements.pop(feature['event_id']); q = measured['q0']; r = bars[measured['r_ref']]
        meta = {'event_id': feature['event_id'], 'session': feature['session'], 'contract': feature['contract'],
                'session_index': sessions.index(feature['session']), 'q0_time': q['time'], 'q0_index': q['index'], 'q0_line': q['source_line']}
        assert (scene['session'], scene['contract']) == (meta['session'], meta['contract'])
        original_q = feature['metadata']['q0']
        assert all(q[key] == original_q[key] for key in ('time', 'index', 'source_line', 'last', 'quote_ok', 'normal_bbo'))
        for key in ('bid', 'ask'):
            ok = type(original_q[key]) in (int, float) and math.isfinite(original_q[key]) and original_q[key] > 0
            assert q[key + '_known'] is ok and q[key] == (original_q[key] if ok else None)
        assert stamp(r['stamp']) == stamp(q)
        assert r['end'] <= r['available_at'] <= q['time'] and r['price_known'] and r['closed'] and not r['missing']
        assert [ref['id'] for ref in feature['metadata']['short_refs']] == measured['slot_refs']
        for ref in feature['metadata']['short_refs']:
            b = bars[ref['id']]
            assert (ref['session'], ref['contract']) == (meta['session'], meta['contract'])
            assert all(ref[key] == b[key] for key in ('id', 'start', 'end', 'available_at', 'stamp', 'price_known', 'volume_known', 'closed'))
            assert all(a <= z for a, z in zip(stamp(b['stamp']), stamp(q)))
        for width in (15, 30, 60):
            w = measured['prior_ranges'][str(width)]
            assert (w['from'], w['to'], w['duration_seconds']) == (r['start'] - width * 60, r['start'], width * 60)
        dto = {'eligible': True, 'q0': q, 'r': r, 'prior_ranges': measured['prior_ranges']}
        assert feature['buy']['side'] == 1 and feature['sell']['side'] == -1
        expected = {**meta, 'r_ref': r['id'], **condition.reconstruct(feature['buy']['x'], feature['sell']['x'], columns, dto)}
        actual = next(iterator); cells += equal(expected, actual, 'q0/' + str(i))
        digest.update(json.dumps(expected, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()); digest.update(b'\n')
        for policy, side in expected['decision']['directions'].items(): flags[policy + '/' + str(side)] += 1
        minimal.append({**meta, 'decision': expected['decision']})
    assert not measurements
    try: next(iterator)
    except StopIteration: pass
    else: raise AssertionError('余分なq0')
    assert stream_proof['sha256'] == expected_sha
    # ----------------------------------------
    # 全新q0が一致した後にだけ、取得対応・metadata・固定152選択を構造として読む。
    value = refs['captures']; captures = read(ROOT / value['path'], value['sha256'], value['decoded_sha256'])
    value = refs['metadata']; metadata = read(ROOT / value['path'], value['sha256'], value['decoded_sha256'])
    linked = join(minimal, captures, metadata, sessions)
    control = book['fixed152_control']; value = control['selection']; old = read(ROOT / value['path'], value['sha256'], value['decoded_sha256'])
    value = control['f1']; oldf1 = read(ROOT / value['path'], value['sha256'])
    assert oldf1['ファイル']['work/152複合回復の評価/入口選択/選択対応.json'] == control['selection']['decoded_sha256']
    assert old['成功'] and old['試行'] == 152 and old['選択時の金融ラベル利用'] is False
    assert {r['case_id']: r for r in old['政策']['C1']} == {r['case_id']: r for r in linked['政策']['C1']}
    for destination, source in (('B152', 'B0'), ('UB152', 'U1')):
        assert len(old['政策'][source]) == control['expected_counts'][destination]
        linked['政策'][destination] = copy.deepcopy(old['政策'][source])
    linked['固定152同体'] = {'成功': True, 'B152件数': 614, 'UB152件数': 697, 'C1全値同体': True, '対照を新出生へ未使用': True}
    expected = {'成功': True, '試行': 153, '主政策': 'U15', 'book_sha256': args.book_sha256,
                '高安入力解凍SHA256': book['range_input']['decoded_sha256'],
                '固定152選択解凍SHA256': control['selection']['decoded_sha256'], **linked}
    selected_path = args.run_dir / '選択対応.json'; actual = read(selected_path, files[selected_path.resolve().relative_to(ROOT).as_posix()])
    cells += equal(expected, actual, '選択対応')
    assert before == {p: (sha(ROOT / p), (ROOT / p).stat().st_size, (ROOT / p).stat().st_mtime_ns) for p in files}
    proof = {'成功': True, '編集停止': True, '試行': 153, 'F0_SHA256': args.f0_sha256, 'F1_SHA256': args.f1_sha256,
             'bookSHA256': args.book_sha256, '全q0': len(minimal), '末端比較': cells, '独立oracle由来': str(condition.ORACLE_PATH.relative_to(ROOT)),
             '全branch条件known_pass_観測値/役割/由来一致': True, '全政策/最早同q1/C1優先/固定152一致': True,
             '政策別取得数': {key: len(value) for key, value in linked['政策'].items()}, '判断方向分布': dict(flags),
             '正規再構成q0のSHA256': digest.hexdigest(), '巨大判断JSONの全bytes読取': stream_proof,
             '全固定源前後同体': {p: value[0] for p, value in before.items()},
             '純判断全件照合後に取得/旧対照を構造読取': True, '作者logic153/runner/import': False,
             '金融/観測/教師/Raw/追加2場/新しい選び直し': False,
             '限界': '保存100Xと先行高安を固定入力として用いる。100数式・高安元生成・真受信・firstnormal・実約定・金融は再検査しない。'}
    args.output_dir.mkdir(parents=True, exist_ok=True); target = args.output_dir / '監査の確認.json'
    with target.open('x', encoding='utf-8', newline='\n') as output: json.dump(proof, output, ensure_ascii=False, indent=2); output.write('\n')
    print(json.dumps({'成功': True, '全q0': len(minimal), '末端比較': cells, '政策別取得数': proof['政策別取得数'], 'SHA256': sha(target)}, ensure_ascii=False))


if __name__ == '__main__': main()
