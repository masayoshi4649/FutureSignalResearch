"""153の当時条件を、停止済み独立oracleと別表現の条件表から再構成する。"""
from pathlib import Path
import importlib.util
import math

ROOT = Path(__file__).resolve().parents[2]
ORACLE_PATH = ROOT / 'work/153独立出生の実行前レビュー/独立人工.py'
spec = importlib.util.spec_from_file_location('停止独立153oracle', ORACLE_PATH)
old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
R, TREND, ATR, DIST = old.R, old.TREND, old.ATR, old.DIST
POLICIES = ('R0', 'PB', 'BR15', 'RV15', 'N15', 'N30', 'N60')


def gate(checks: dict, values: dict) -> dict:
    """
    機能: 独立な全required規則からknown/passと理由・観測値を組み立てる。
    引数: checks(dict)、values(dict)。返り値: dict。
    """
    known = all(value is not None for value in checks.values())
    return {'known': known, 'pass': all(checks.values()) if known else None,
            'false': [key for key, value in checks.items() if value is False],
            'unknown': [key for key, value in checks.items() if value is None],
            'checks': checks, 'values': values}


# ----------------------------------------
def relation(a, op: str, b) -> bool | None:
    """
    機能: 未知をfalseにせず、対象演算子の比較を行う。
    引数: a/b(float|None)、op(str)。返り値: bool|None。
    """
    if a is None or b is None: return None
    return {'>': a > b, '>=': a >= b, '<': a < b, '<=': a <= b}[op]


# ----------------------------------------
def reconstruct(buy: list, sell: list, columns: list, measured: dict) -> dict:
    """
    機能: 全by_side条件表・方向・role/originを作者Sourceなしで再構成する。
    引数: buy/sell(list)、columns(list[str])、measured(dict)。返り値: dict。
    """
    index = {key: i for i, key in enumerate(columns)}
    padded = []
    for vector in (buy, sell):
        reordered = [None] * 100
        for key in old.REQUIRED: reordered[old.INDEX[key]] = vector[index[key]]
        padded.append(reordered)
    independent = old.oracle(*padded, measured)
    out = {}; q, r = measured['q0'], measured['r']; o = r['ohlc'] or {}
    for side, vector in ((1, buy), (-1, sell)):
        x = {key: old.known(vector[index[key]]) for key in old.REQUIRED}
        live = None if x[R[1]] is None or x[R[2]] is None else math.fsum((x[R[1]], x[R[2]]))
        r_values = {key: x[key] for key in R}; r_values['live_reclaim'] = live
        r_known = all(x[key] is not None for key in R)
        recovery = {'known': r_known, 'value': (
            min(x[R[0]], live, x[R[3]], x[R[4]]) > 0 and x[R[5]] >= 1) if r_known else None, 'values': r_values}
        price = q['ask' if side == 1 else 'bid'] if q['normal_bbo'] else None
        spread = q['ask'] - q['bid'] if q['normal_bbo'] else None
        atr, distance = x[ATR], x[DIST]
        ema = independent['sides'][str(side)]['ema']; band = atr * .25 if atr is not None and atr > 0 else None
        common = gate({'eligible': measured['eligible'], 'R': recovery['value'], 'normal_bbo': q['normal_bbo'],
            'spread_positive': relation(spread, '>', 0), 'spread_max20': relation(spread, '<=', 20),
            'gap_abs_max1': relation(abs(x[R[2]]) if x[R[2]] is not None else None, '<=', 1),
            'ema8_chase_max1': relation(distance, '<=', 1), 'atr5_positive': relation(atr, '>', 0)},
            {'atr5': atr, 'entry_price_q0': price, 'ema8_distance_atr5': distance,
             'last_close_gap_atr5': x[R[2]], 'spread': spread})
        trend = gate({**{key: relation(x[key], '>', 0) for key in TREND},
            'adx15_above25': relation(x['m15_adx'], '>', 25), 'adx15_delta_nonnegative': relation(x['m15_adx_delta'], '>=', 0)},
            {key: x[key] for key in (*TREND, 'm15_adx', 'm15_adx_delta')})
        op = side * (o['open'] - ema) if o and ema is not None else None
        cp = side * (o['close'] - ema) if o and ema is not None else None
        lp = side * (q['last'] - ema) if q['last'] is not None and ema is not None else None
        pb = gate({'common': common['pass'], 'trend': trend['pass'], 'r_open_nonpositive': relation(op, '<=', 0),
            'r_close_positive': relation(cp, '>', 0), 'last_positive': relation(lp, '>', 0),
            'entry_distance_positive': relation(distance, '>', 0), 'entry_distance_max_half': relation(distance, '<=', .5)},
            {'ema8_q0': ema, 'r_open_to_ema8': op, 'r_close_to_ema8': cp, 'last_to_ema8': lp, 'entry_distance_atr5': distance})
        branch = {'R0': common, 'R': recovery, 'Trend': trend, 'PB': pb, 'BR': {}, 'RV': {},
                  'geometry': {'r_ref': r['id'], 'ema8_q0': ema, 'entry_price_q0': price, 'atr5': atr, 'band': band}}
        for width in (15, 30, 60):
            w = measured['prior_ranges'][str(width)]; low, high = w['low'], w['high']
            forward, opposite = (high, low) if side == 1 else (low, high)
            close_delta = side * (o['close'] - forward) if o and forward is not None else None
            last_delta = side * (q['last'] - forward) if q['last'] is not None and forward is not None else None
            br = gate({'common': common['pass'], 'trend': trend['pass'], 'window_known': w['known'],
                'close_beyond_band': relation(close_delta, '>', band), 'last_beyond_band': relation(last_delta, '>', band),
                'volume_at_least_1_25': relation(x[R[5]], '>=', 1.25)},
                {'window_minutes': width, 'lower': low, 'upper': high, 'band': band,
                 'close_forward_difference': close_delta, 'last_forward_difference': last_delta})
            extreme = o.get('low' if side == 1 else 'high')
            intrusion = side * (extreme - opposite) if extreme is not None and opposite is not None else None
            inner_low = low + band if low is not None and band is not None else None
            inner_high = high - band if high is not None and band is not None else None
            rv = gate({'common': common['pass'], 'old_ema30_opposite': relation(x[TREND[2]], '<', 0),
                'old_di30_opposite': relation(x[TREND[5]], '<', 0), 'adx15_delta_negative': relation(x['m15_adx_delta'], '<', 0),
                'di15_now_favorable': relation(x[TREND[4]], '>', 0), 'di5_now_favorable': relation(x[TREND[3]], '>', 0),
                'window_known': w['known'], 'width_more_two_bands': relation(w['range_points'], '>', 2 * band if band is not None else None),
                'opposite_extreme_outside': relation(intrusion, '<', -band if band is not None else None),
                'close_above_inner_low': relation(o.get('close'), '>', inner_low), 'close_below_inner_high': relation(o.get('close'), '<', inner_high),
                'last_above_inner_low': relation(q['last'], '>', inner_low), 'last_below_inner_high': relation(q['last'], '<', inner_high),
                'volume_at_least_1_25': relation(x[R[5]], '>=', 1.25)},
                {'window_minutes': width, 'lower': low, 'upper': high, 'band': band,
                 'opposite_extreme_difference': intrusion, 'inner_low': inner_low, 'inner_high': inner_high})
            branch['BR'][str(width)], branch['RV'][str(width)] = br, rv
            flag = old.tri_or([pb['pass'], br['pass'], rv['pass']])
            branch['N' + str(width)] = {'known': flag is not None, 'pass': flag,
                'origins': [name for name, value in [('PB', pb['pass']), ('BR' + str(width), br['pass']), ('RV' + str(width), rv['pass'])] if value is True]}
            assert br['pass'] is independent['sides'][str(side)]['flags']['BR' + str(width)]
            assert rv['pass'] is independent['sides'][str(side)]['flags']['RV' + str(width)]
        assert common['pass'] is independent['sides'][str(side)]['flags']['R0']
        assert pb['pass'] is independent['sides'][str(side)]['flags']['PB']
        out[str(side)] = branch
    evidence = []
    for policy in POLICIES:
        for side in (1, -1):
            branch = out[str(side)]
            selected = branch['BR']['15'] if policy == 'BR15' else branch['RV']['15'] if policy == 'RV15' else branch[policy]
            if selected['pass'] is True:
                evidence.append({'rule': policy, 'signal_side': side, 'order_side': side,
                    'roles': ['構造', '勢い', '量'] if policy == 'R0' else ['方向', '強度', '構造', '勢い', '量'],
                    'origins': list(branch.get(policy, {}).get('origins', [policy]))})
    directions = dict(independent['directions']); conflicts = dict(independent['conflicts'])
    directions['NN15'] = directions['N15']; conflicts['NN15'] = conflicts['N15']
    return {'technical': out, 'decision': {'directions': directions, 'conflicts': conflicts, 'evidence': evidence}}
