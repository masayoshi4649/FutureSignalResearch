"""自然本文なしで153の16政策・旧152対照・三表・累計を検査する。"""
from pathlib import Path
import copy
import gzip
import hashlib
import importlib.util
import json
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def module(path: Path, name: str):
    """
    機能: mainを実行せず人工部品と算術だけを読む。
    引数: path(Path)、name(str)。返り値: ModuleType。
    """
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


m = module(HERE / '集計する.py', 'finance153artificial')
previous = module(ROOT / 'work/152複合回復の金融集計/人工検査.py', 'fixture152for153')


def fixture(empty: bool = False) -> tuple:
    """
    機能: 旧87と旧152対照を保ち、新規case1を含む16政策を人工で作る。
    引数: empty(bool)。返り値: tupleはrecords/場/固定/選択/meta/算術/members。
    """
    records, sessions, fixed, old, meta, parent, arith, members = previous.fixture()
    policies = {'C1': copy.deepcopy(old['政策']['C1']),
                'B152': copy.deepcopy(old['政策']['B0']), 'UB152': copy.deepcopy(old['政策']['U1'])}
    legacy = {row['case_id']: row for row in policies['C1']}
    new_key = '人工00/new153'
    records[new_key] = copy.deepcopy(records['人工00/0'])
    record = records[new_key]
    record['case']['id'] = new_key
    for stream in ('original', 'reverse', 'chart_original', 'chart_reverse'):
        record['case'][stream]['entry']['time'] = 110
        record['case'][stream]['entry']['index'] = 20
        record['case'][stream]['entry']['source_line'] = 21
    descriptor = copy.deepcopy(meta['population148']['cases'][0])
    descriptor['case_id'] = new_key
    meta['population148']['cases'].append(descriptor)
    row = copy.deepcopy(old['政策']['P65'][0])
    row.update(case_id=new_key, origin='PB', event_id='new153', feature_ref='new153')
    for policy, candidates in [('R0', [row, *old['政策']['P65']]), ('PB', [row]),
                               ('BR15', old['政策']['P65'][:1]), ('RV15', old['政策']['P65'][1:2])]:
        policies[policy] = [{**copy.deepcopy(item), 'origin': policy, '成立ID': [policy]} for item in candidates] if not empty else []
    groups = {'N15': ['PB', 'BR15', 'RV15'], 'N30': ['PB'], 'N60': ['RV15']}
    for policy, children in groups.items():
        combined = {}
        for child in children:
            for item in policies[child]:
                combined.setdefault(item['case_id'], {**copy.deepcopy(item), 'origin': policy})
        policies[policy] = list(combined.values())
    overlaps = {}
    for union, new in [('U15', 'N15'), ('U30', 'N30'), ('U60', 'N60')]:
        combined = copy.deepcopy(legacy)
        for item in policies[new]:
            combined.setdefault(item['case_id'], copy.deepcopy(item))
        policies[union] = list(reversed(combined.values()))
        overlaps[union] = [{'case_id': item['case_id'], 'opposite': item['side'] != legacy[item['case_id']]['side']}
                           for item in policies[new] if item['case_id'] in legacy]
    policies['NN15'] = copy.deepcopy(policies['N15'])
    selection = {'成功': True, '試行': 153, '選択時の金融ラベル利用': False,
                 '政策': policies, '旧C1重複': overlaps, '候補と取得': {}, '全73場': sessions}
    parent.POLICIES = m.POLICIES
    arith.POLICIES = m.POLICIES
    arith.selected = m.selected
    return m.bind_choices(records, members, selection, False), sessions, fixed, selection, meta, parent, arith, members


class Tests(unittest.TestCase):
    """153 Sourceや自然金融を実行しない7主群。"""

    def test_960三表とC1優先と実逆(self) -> None:
        """
        機能: 新caseを足した主88件と960/47/68列、C1優先・同q1実逆を確認する。
        引数: self(Tests)。返り値: None。
        """
        records, sessions, fixed, selection, meta, parent, arith, _ = fixture()
        values, p, f, goals, overlaps = parent.calculate(records, sessions, fixed['scenes'], arith)
        tables, curves = m.tables(records, sessions, values, p, f, overlaps, selection, meta, parent, arith)
        self.assertEqual([(len(t['rows']), len(t['headers'])) for t in tables], [(960, 34), (88, 47), (73, 68)])
        self.assertEqual(records['人工00/0']['choices']['BR15']['side'], 1)
        self.assertEqual(records['人工00/0']['choices']['U15']['side'], -1)
        self.assertEqual(records['人工00/0']['choices']['RU15']['side'], 1)
        self.assertEqual(records['人工00/0']['choices']['RU15']['source_selected_side'], -1)
        self.assertEqual(curves['U15'][sessions[-1]]['累計既知差引'], values['all']['U15']['BBO']['3600']['125']['ifd_net5_sum'])
        self.assertNotIn('NN15', values['all'])
        entry_times = [row[tables[1]['headers'].index('取得JST')] for row in tables[1]['rows']]
        self.assertEqual(entry_times, sorted(entry_times))

    def test_旧152別名120条件(self) -> None:
        """
        機能: 旧B0/U1への別名対応を全120条件2880セルで比較し差1を拒否する。
        引数: self(Tests)。返り値: None。
        """
        records, sessions, fixed, _, _, parent, arith, _ = fixture()
        values, *_ = parent.calculate(records, sessions, fixed['scenes'], arith)
        prior = {'集計': {part: {'B0': copy.deepcopy(value['B152']), 'U1': copy.deepcopy(value['UB152'])}
                         for part, value in values.items()}}
        proof = m.prior152_check(values, prior)
        self.assertEqual((proof['条件数'], proof['統計セル数']), (120, 2880))
        prior['集計']['validation']['U1']['Last']['1800']['25']['entries'] += 1
        with self.assertRaises(AssertionError):
            m.prior152_check(values, prior)

    def test_空新群と全73とLastnull(self) -> None:
        """
        機能: 新規0でも旧87/73場と960行を残し、未定率/Last金額をnullにする。
        引数: self(Tests)。返り値: None。
        """
        records, sessions, fixed, selection, meta, parent, arith, _ = fixture(True)
        values, p, f, _, overlaps = parent.calculate(records, sessions, fixed['scenes'], arith)
        tables, _ = m.tables(records, sessions, values, p, f, overlaps, selection, meta, parent, arith)
        self.assertEqual(values['all']['N15']['BBO']['3600']['125']['entries'], 0)
        self.assertIsNone(values['all']['N15']['BBO']['3600']['125']['resolved_rate'])
        self.assertEqual(p['all']['N15']['取得場数'], 0)
        self.assertEqual(len(tables[2]['rows']), 73)
        self.assertIsNone(values['all']['U15']['Last']['3600']['125']['ifd_net5_sum'])

    def test_C1上書きと重複を拒否(self) -> None:
        """
        機能: C1優先破壊、別union欠落、同policy重複を拒否する。
        引数: self(Tests)。返り値: None。
        """
        records, _, _, selection, _, _, _, members = fixture()
        for key in ('U15', 'U30', 'U60', 'UB152'):
            damaged = copy.deepcopy(selection)
            damaged['政策'][key][0]['side'] *= -1
            with self.assertRaises(AssertionError):
                m.bind_choices(records, members, damaged, False)
        damaged = copy.deepcopy(selection)
        damaged['政策']['N15'].append(copy.deepcopy(damaged['政策']['N15'][0]))
        with self.assertRaises(AssertionError):
            m.bind_choices(records, members, damaged, False)

    def test_H不足touch費用未知累計(self) -> None:
        """
        機能: 不足でも既知touchを保ち、C5=1077と未知累計非回復を維持する。
        引数: self(Tests)。返り値: None。
        """
        records, _, _, _, _, _, arith, _ = fixture()
        record = records['人工00/0']
        observed = m.selected(record, 'U15', 'BBO')
        observed['outcomes'][1]['status'] = 'censored'
        observed['outcomes'][1]['endpoint'] = None
        stats = arith.stats([record], 'U15', 'BBO', 3600, 125)
        self.assertEqual((stats['complete'], stats['ifd_known'], stats['ifd_net5_sum']), (0, 1, 12500 - 1077))
        first = m.cumulative_step({}, {'ifd_net5_profit': 10, 'ifd_net5_loss': 0, 'ifd_unknown': 1})
        next_row = m.cumulative_step(first, {'ifd_net5_profit': 20, 'ifd_net5_loss': 5, 'ifd_unknown': 0})
        self.assertEqual(next_row['累計既知差引'], 25)
        self.assertIsNone(next_row['累計全件確定差引'])

    def test_別F1F2とgzipCRC(self) -> None:
        """
        機能: 固定段階の同票/入替と圧縮CRC/解凍SHAの不一致を拒否する。
        引数: self(Tests)。返り値: None。
        """
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            selection = root / '選択.json'
            selection.write_bytes(b'{}')
            h = m.sha(selection)
            f1, f2 = root / 'F1.json', root / 'F2.json'
            f1.write_text(json.dumps({'成功': True, '試行': 153, 'ファイル': {str(selection): h}}), encoding='utf-8')
            a = m.sha(f1)
            f2.write_text(json.dumps({'成功': True, '試行': 153, 'ファイル': {str(selection): h, str(f1): a}}), encoding='utf-8')
            m.verify_freezes(f1, a, f2, m.sha(f2), selection, h)
            with self.assertRaises(AssertionError):
                m.verify_freezes(f1, a, f1, a, selection, h)
            with self.assertRaises((KeyError, AssertionError)):
                m.verify_freezes(f2, m.sha(f2), f1, a, selection, h)
            path = root / '人工.json.gz'
            raw = '{"日本語":true}'.encode('utf-8')
            path.write_bytes(gzip.compress(raw, mtime=0))
            self.assertEqual(m.load(path, m.sha(path), hashlib.sha256(raw).hexdigest()), {'日本語': True})
            with self.assertRaises(AssertionError):
                m.load(path, m.sha(path), '0' * 64)
            body = bytearray(path.read_bytes()); body[-8] ^= 1; path.write_bytes(body)
            with self.assertRaises((OSError, EOFError)):
                m.load(path, m.sha(path))

    def test_補助aliasは主へ二重加算しない(self) -> None:
        """
        機能: NN15を金融外の同体aliasに限定し、方向を変えたaliasを拒否する。
        引数: self(Tests)。返り値: None。
        """
        records, _, _, selection, _, _, _, members = fixture()
        self.assertNotIn('NN15', m.POLICIES)
        selection['政策']['NN15'][0]['side'] *= -1
        with self.assertRaises(AssertionError):
            m.bind_choices(records, members, selection, False)


if __name__ == '__main__':
    unittest.main(verbosity=2)
