"""153金融は実行せず、人工・Source AST・固定依存だけを確認して停止する。"""
from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import os
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def sha(path: Path) -> str:
    """
    機能: Sourceの物理指紋を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def function_ast(path: Path, name: str) -> str:
    """
    機能: 数式/I_O/累計の指定関数を位置情報を除くASTへ射影する。
    引数: path(Path)、name(str)。返り値: str。
    """
    node = next(n for n in ast.parse(path.read_text(encoding='utf-8')).body
                if isinstance(n, ast.FunctionDef) and n.name == name)
    return ast.dump(node, include_attributes=False)


def main() -> None:
    """
    機能: 自然入力を読まず7人工とAST5同体を検査し、準備/停止票を新規保存する。
    引数: なし。返り値: None。旧152Sourceや金融正本は不変更。
    """
    spec = importlib.util.spec_from_file_location('finance153_prepare', HERE / '集計する.py')
    source = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(source)
    deferred = (source.PRIOR152, source.OLD_PAIRS, source.OLD_SUMMARY)
    paths = [HERE / name for name in ('集計する.py', '人工検査.py', '条件.md', '準備する.py', '由来を作る.py')]
    paths += [p for p in source.SOURCES if p not in deferred]
    paths += [ROOT / 'work' / folder / '人工検査.py' for folder in
              ('152複合回復の金融集計', '151過去場判別の金融集計', '150構造状態の金融集計', '148母集団の診断集計')]
    paths = list(dict.fromkeys(paths))
    before = {p: sha(p) for p in paths}
    assert all(before[p] == expected for p, expected in source.SOURCES.items() if p not in deferred)
    for p in HERE.glob('*.py'):
        parsed = ast.parse(p.read_text(encoding='utf-8'))
        for node in ast.walk(parsed):
            if isinstance(node, ast.FunctionDef):
                comment = ast.get_docstring(node)
                assert comment and '\n' in comment and all(key in comment for key in ('機能', '引数', '返り値'))
    copied = {name: function_ast(HERE / '集計する.py', name) == function_ast(source.ANCESTOR152, name)
              for name in ('sha', 'load', 'module', 'selected', 'cumulative_step')}
    assert all(copied.values())
    result = subprocess.run([sys.executable, '-X', 'utf8', str(HERE / '人工検査.py')],
        capture_output=True, cwd=ROOT,
        env={**os.environ, 'PYTHONUTF8': '1', 'PYTHONIOENCODING': 'utf-8', 'PYTHONDONTWRITEBYTECODE': '1'})
    output, error = result.stdout.decode('utf-8', 'strict'), result.stderr.decode('utf-8', 'strict')
    assert result.returncode == 0 and '\ufffd' not in output + error
    assert before == {p: sha(p) for p in paths}
    proof = {'成功': True, '試行': 153, '自然153採否_容量_金融': False,
        '自然特徴_先行高安_観測_旧152金融の本文読取': False,
        '新学習_再予測_新Raw_CSV_追加2場': False,
        '人工主数': 7, 'UTF8_strict_構文_関数コメント': True,
        '152基本5関数AST同体': copied, '全源前後同体': True,
        '源': [{'path': p.relative_to(ROOT).as_posix(), 'sha256': h, 'bytes': p.stat().st_size}
               for p, h in before.items()],
        '後段のみ読む金融正本': [{'path': p.relative_to(ROOT).as_posix(), 'sha256': source.SOURCES[p],
                          '準備時の物理bytes読取': False} for p in deferred],
        '三表契約': {'正逆比較': [960, 34], '入口別診断': ['U15可変件数・旧87保護', 47], '全セッション': [73, 68]},
        '固定対照': 'B152=旧152B0/UB152=旧152U1を120条件2880キー同体',
        '主': 'U15', '全場累計': ['U15', 'N15', 'C1'],
        '固定票': 'F1選択後とF2金融前を別票別SHAで照合、F2からF1を参照',
        '独立性': '作者は152/149/124算術の継承。Root141の別算術検算とは別。',
        '人工結果': {'終了値': result.returncode, '標準出力': output, '標準エラー': error}}
    ready = HERE / '準備の確認.json'
    assert not ready.exists() and not (HERE / '停止.json').exists()
    ready.write_bytes((json.dumps(proof, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    stop = {'成功': True, '編集停止': True, '試行': 153, '自然未実行': True,
            '準備SHA256': sha(ready), '自源': {p.name: h for p, h in before.items() if p.parent == HERE}}
    (HERE / '停止.json').write_bytes((json.dumps(stop, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    print(json.dumps({'成功': True, '準備SHA256': sha(ready), '停止SHA256': sha(HERE / '停止.json'),
                      '集計SourceSHA256': sha(HERE / '集計する.py')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
