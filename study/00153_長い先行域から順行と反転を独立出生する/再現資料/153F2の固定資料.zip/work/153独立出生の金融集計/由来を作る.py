"""停止152金融集計を別コピーし、153の政策結合だけへ適合する。"""
from pathlib import Path
import hashlib
import re

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent


def replace_function(text: str, name: str, replacement: str) -> str:
    """
    機能: 指定した関数一個だけを、由来が分かる固定本文で置き換える。
    引数: text/name/replacement(str)。返り値: str。
    """
    pattern = re.compile(r'(?ms)^def ' + re.escape(name) + r'\(.*?(?=^def |^if __name__)')
    text, count = pattern.subn(lambda _: replacement + '\n\n', text)
    assert count == 1
    return text


def main() -> None:
    """
    機能: 152原本を変更せず153政策/主/cumulative/controlへ適合したSourceを作る。
    引数: なし。返り値: None。自然JSONを開かない。
    """
    original = ROOT / 'work/152複合回復の金融集計/集計する.py'
    body = original.read_bytes()
    assert hashlib.sha256(body).hexdigest() == 'fc46fe84b3d22a44b2fd930ecad7baa7d16257bd57138222b94eebd7f05d62fc'
    text = body.decode('utf-8').replace('152', '153')
    for left, right in [('P65', 'B152'), ('U65', 'UB152'), ('A0', 'PB'), ('B0', 'N15'), ('U0', 'U30'), ('U1', 'U15')]:
        text = text.replace(left, right)
    text = text.replace("ANCESTOR151=ROOT/'work/151過去場判別の金融集計/集計する.py'", "ANCESTOR152=ROOT/'work/152複合回復の金融集計/集計する.py'")
    text = text.replace("PRIOR151=ROOT/'study/00151_広い複合テクニカルを過去場だけで判別する/成果物/集計.json'", "PRIOR152=ROOT/'study/00152_強い反対背景を複合回復で切り替える/成果物/集計.json'")
    text = text.replace("SOURCES[ANCESTOR151]='1a4c23b47cc473f86434c5c30d138d0fc1e5c60bb08d276ae2117fbe6fab4b35'", "SOURCES[ANCESTOR152]='fc46fe84b3d22a44b2fd930ecad7baa7d16257bd57138222b94eebd7f05d62fc'")
    text = text.replace("SOURCES[PRIOR151]='ab002c2088784bb45ea86800550013ae44637f39d4bafb7a70e42814789ccd04'", "SOURCES[PRIOR152]='baa76c4a4827204ec3a4673eed4881f66ab2a0ad4d996de8cf8a5bc7e818add5'")
    start = text.index('POLICIES=')
    end = text.index('\n', start)
    text = text[:start] + "POLICIES=('C0','C1','RC1','B152','UB152','R0','PB','BR15','RV15','N15','U15','RU15','N30','U30','N60','U60')" + text[end:]
    binding = '''def bind_choices(records: dict,members: dict,selection: dict,strict: bool=True) -> dict:
    """
    機能: 153独立新出生と旧152固定対照をC1優先で結び、実逆を派生する。
    引数: records/members/selection(dict)、strict(bool)。返り値: dict。
    """
    assert selection['成功'] and selection['試行']==153 and selection['選択時の金融ラベル利用'] is False
    output={key:{**record,'choices':{}} for key,record in records.items()}
    direct=('C1','B152','UB152','R0','PB','BR15','RV15','N15','U15','N30','U30','N60','U60')
    policies={policy:copy.deepcopy(selection['政策'][policy]) for policy in direct}
    legacy={row['case_id']:row for row in policies['C1']}
    assert set(legacy)==members['C1'] and len(legacy)==len(policies['C1'])
    for union,new in [('UB152','B152'),('U15','N15'),('U30','N30'),('U60','N60')]:
        fresh={row['case_id']:row for row in policies[new]}
        combined={row['case_id']:row for row in policies[union]}
        assert len(fresh)==len(policies[new]) and len(combined)==len(policies[union])
        assert set(combined)==set(legacy)|set(fresh)
        for key,row in combined.items():
            expected=legacy[key] if key in legacy else fresh[key]
            assert all(row.get(field)==expected.get(field) for field in ('case_id','session','side','stream','event_id','feature_ref','q0_time','q0_index','q0_line'))
    for alias in ('NN15','NB15'):
        if alias in selection['政策']:
            rows=selection['政策'][alias]
            assert len(rows)==len(policies['N15'])
            assert {row['case_id']:(row['side'],row['stream']) for row in rows}=={row['case_id']:(row['side'],row['stream']) for row in policies['N15']}
    policies['C0']=[row for row in policies['C1'] if row['case_id'] in members['C0']]
    for dest,source in [('RC1','C1'),('RU15','U15')]:
        policies[dest]=[{**row,'side':-row['side'],'stream':'reverse' if row['stream']=='original' else 'original',
            'origin':dest,'counterfactual_reverse':True,'reverse_of_policy':source,
            'source_selected_side':row['side'],'source_selected_stream':row['stream']} for row in policies[source]]
    for policy,rows in policies.items():
        seen=set()
        for row in rows:
            key=row['case_id'];assert key not in seen;seen.add(key)
            record=output[key]
            assert record['session']==row['session'] and row['stream'] in ('original','reverse')
            assert row['side']==record['case'][row['stream']]['birth']['side']
            record['choices'][policy]=row
    if strict:assert len(policies['C0'])==81 and len(legacy)==87 and len(selection['全73場'])==73
    return output'''
    text = replace_function(text, 'bind_choices', binding)
    prior = '''def prior152_check(values: dict,prior: dict) -> dict:
    """
    機能: 旧152B0/U1を153固定別名B152/UB152へ全統計で照合する。
    引数: values/prior(dict)。返り値: dictは120条件/統計セル数。
    """
    count=cells=0
    for part in ('all','train','validation'):
        for policy,old in [('B152','B0'),('UB152','U1')]:
            for axis in AXES:
                for horizon in HORIZONS:
                    for width in WIDTHS:
                        actual=values[part][policy][axis][str(horizon)][str(width)]
                        expected=prior['集計'][part][old][axis][str(horizon)][str(width)]
                        assert actual==expected,(part,policy,old,axis,horizon,width)
                        count+=1;cells+=len(actual)
    assert count==120
    return {'成功':True,'旧試行':152,'政策対応':{'B152':'B0','UB152':'U1'},'全統計同体':True,'条件数':count,'統計セル数':cells}'''
    text = replace_function(text, 'prior151_check', prior)
    text = text.replace('len(comparisons)==660', 'len(comparisons)==960').replace('660比較', '960比較')
    text = text.replace("('B152','UB152','RB152')", "('B152','UB152')")
    text = text.replace("kind='固定B152対照'", "kind='旧152固定対照'")
    text = text.replace("prior151_check(values,load(PRIOR151,SOURCES[PRIOR151]))", "prior152_check(values,load(PRIOR152,SOURCES[PRIOR152]))")
    text = text.replace("'旧151_B152_UB152同体'", "'旧152_B0_U1同体'")
    text = text.replace("'継承B152予測と切替側の確信度は別':True,'NN15は接続aliasで金融政策外':True", "'新資格へ予測又は旧152選択を渡す':False,'補助aliasは金融政策外':True")
    text = text.replace("'継承151モデルは過去成熟教師で学習':True", "'旧152対照は継承151モデル由来':True")
    text = text.replace("'RB152':'B152の同q1反対BBO側',", '')
    text = text.replace("'主U15をU30/UB152へ結果後交換しない'", "'主U15をU30/U60や単独枝へ結果後交換しない'")
    text = text.replace('153固定予測参照', '153独立出生の固定選択').replace('予測後F1と金融前F2', '選択後F1と金融前F2')
    text = text.replace("f1=load(f1_path,f1_sha);f2=load(f2_path,f2_sha)", "f1=load(f1_path,f1_sha);f2=load(f2_path,f2_sha)\n    assert f1.get('成功') is True and f2.get('成功') is True and f1.get('試行')==f2.get('試行')==153")
    text = text.replace('元予測evidenceの向きは出典として保持', '元選択evidenceの向きは出典として保持')
    text = text.replace('link選択票の金融ラベル利用falseは過去成熟教師の学習不使用を意味しない', '152固定対照は過去学習由来だが153新資格へ予測を渡さない')
    target = HERE / '集計する.py'
    assert not target.exists()
    target.write_bytes(text.encode('utf-8'))


if __name__ == '__main__':
    main()
