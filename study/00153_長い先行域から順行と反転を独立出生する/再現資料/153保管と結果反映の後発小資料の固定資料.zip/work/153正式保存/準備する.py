"""保存器の人工と所有境界だけを確認する。自然153結果は開かない。"""
from pathlib import Path
import ast
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 小型Sourceと固定文書の物理指紋を得る。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 人工3群と構文、F0対象3MD/book/Source不変更を確認して準備票を残す。
    引数: なし。返り値: None。自然JSONと正式保管先へはI_Oしない。
    """
    own = [p for p in HERE.iterdir() if p.is_file() and p.suffix in ('.py', '.md')]
    formal = ROOT / 'study/00153_長い先行域から順行と反転を独立出生する'
    watched = [formal / name for name in ('README.md', '条件.md', '設定と結果.md')]
    watched += [ROOT / 'inputs/00153_先行高安の独立出生/条件.json',
                ROOT / 'work/153独立出生の入口/logic153.py', ROOT / 'work/153独立出生の入口/選択する.py',
                ROOT / 'work/153独立出生の金融集計/集計する.py', ROOT / 'work/151正式保存/保存部品.py']
    before = {p: sha(p) for p in own + watched}
    for p in own:
        if p.suffix != '.py':
            continue
        parsed = ast.parse(p.read_text(encoding='utf-8'))
        for node in ast.walk(parsed):
            if isinstance(node, ast.FunctionDef):
                comment = ast.get_docstring(node)
                assert comment and '\n' in comment and all(word in comment for word in ('機能', '引数', '返り値'))
    process = subprocess.run([sys.executable, '-X', 'utf8', str(HERE / '人工検査.py')],
        capture_output=True, env={**os.environ, 'PYTHONUTF8': '1', 'PYTHONIOENCODING': 'utf-8'})
    output = process.stdout.decode('utf-8', 'strict')
    error = process.stderr.decode('utf-8', 'strict')
    assert process.returncode == 0 and '\ufffd' not in output + error
    assert before == {p: sha(p) for p in before}
    proof = {'成功': True, '区分': '153保存器とREADME雛形の準備', '人工群': 3,
        '自然153結果_JSON_金融_価格入力_追加2場読取': False,
        '正式3MD_book_Source_旧152編集': False, 'F0対象前後同体': True,
        '自然保管の実行': False, 'UTF8_strict_構文_関数コメント': True,
        '段階通知flag無しはI_O前拒否': True, '新3JSONのみ各1gzip': True,
        '共有先行高安_100X_148観測_152対照の新複写': False,
        '源と監視対象': {p.relative_to(ROOT).as_posix(): h for p, h in before.items()},
        '人工結果': {'終了値': process.returncode, '標準出力': output, '標準エラー': error}}
    target = HERE / '準備の確認.json'
    assert not target.exists()
    target.write_bytes((json.dumps(proof, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    print(json.dumps({'成功': True, '準備SHA256': sha(target), '保存器SHA256': sha(HERE / '保存する.py')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
