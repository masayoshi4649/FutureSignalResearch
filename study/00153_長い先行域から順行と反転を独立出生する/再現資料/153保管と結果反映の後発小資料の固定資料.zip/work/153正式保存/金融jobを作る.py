"""Root通知済みの金融・CSV票だけを明示jobへ固定する。"""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 通知済み成果物の物理指紋を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 正本SHAを確認し、再計算せず保存するためのjobをwork内に作る。
    引数: なし。返り値: None。正式資料を更新しない。
    """
    runtime = ROOT / 'work/153独立出生の評価'
    finance = runtime / '金融集計'
    output = ROOT / 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/153_独立テクニカル入口'
    assert sha(finance / '集計.json') == 'f8f1c4695d553ec1f0e7883c479fe381c8c954f4f0469346b60507a255ee3e44'
    assert sha(finance / 'CSV用の表.json') == '522af29c83cb0df018dd4bdb959ee44373cfd677faf72d43d5b6271f3a95a769'
    entries = []
    for source, dest, mode in [(finance / '集計.json', '成果物/集計.json', '同体'),
        (finance / 'CSV用の表.json', '成果物/CSV用の表.json.gz', 'gzip'),
        (finance / '集計完了.json', '成果物/集計完了.json', '同体'),
        (runtime / '金融独立検算.json', '検査/金融独立検算.json', '同体'),
        (runtime / 'CSV独立再読.json', '検査/CSV独立再読.json', '同体'),
        (output / 'CSVの確認.json', '検査/CSV作成の確認.json', '同体')]:
        entries.append({'source': source.relative_to(ROOT).as_posix(), 'sha256': sha(source),
                        '正式相対path': dest, '形式': mode})
    job = {'試行': 153, 'Root結果通知後': True, '区分': '金融とCSV証跡', '保存': entries}
    path = HERE / '金融保存job.json'
    assert not path.exists()
    path.write_bytes((json.dumps(job, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    print(json.dumps({'成功': True, 'jobSHA256': sha(path)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
