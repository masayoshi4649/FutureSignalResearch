"""Rootが読取を許可した153金融正本から、work内の結果草稿だけを作る。"""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
FORMAL = ROOT / 'study/00153_長い先行域から順行と反転を独立出生する'
SUMMARY = ROOT / 'work/153独立出生の評価/金融集計/集計.json'


def sha(path: Path) -> str:
    """
    機能: 小型文書と金融正本の物理指紋を得る。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def number(value, decimals: int = 0) -> str:
    """
    機能: 未知を0にせず数値の表示だけを整える。
    引数: value(int|float|None)、decimals(int)。返り値: str。
    """
    return '未定義' if value is None else f'{value:,.{decimals}f}'


def table(data: dict, part: str, policies: list[str]) -> str:
    """
    機能: 保存H60±125実BBOの政策表を正本値だけから作る。
    引数: data(dict)、part(str)、policies(list[str])。返り値: str。
    """
    out = ['| 政策 | 取得 | 順/逆/未/不足 | 到達済率 | C5利益円 | 損失絶対円 | 差引円 | IFD未知 |',
           '| --- | ---: | --- | ---: | ---: | ---: | ---: | ---: |']
    for policy in policies:
        x = data['集計'][part][policy]['BBO']['3600']['125']
        rate = None if x['resolved_rate'] is None else x['resolved_rate'] * 100
        counts = '/'.join(str(x[key]) for key in ('forward', 'adverse', 'neither', 'censored'))
        out.append(f"| {policy} | {x['entries']} | {counts} | {number(rate, 2)}% | "
            f"{number(x['ifd_net5_profit'])} | {number(x['ifd_net5_loss'])} | {number(x['ifd_net5_sum'])} | {x['ifd_unknown']} |")
    return '\n'.join(out)


def main() -> None:
    """
    機能: 金融読取許可後の正本からwork草稿を保存し、正式不変更を記録する。
    引数: なし。返り値: None。新選択/Source価格入力/自然監査本文を読まない。
    """
    watched = [FORMAL / name for name in ('README.md', '条件.md', '設定と結果.md')]
    before = {p.name: sha(p) for p in watched}
    assert sha(SUMMARY) == 'f8f1c4695d553ec1f0e7883c479fe381c8c954f4f0469346b60507a255ee3e44'
    data = json.loads(SUMMARY.read_bytes())
    assert data['成功'] and data['試行'] == 153 and data['主政策'] == 'U15'
    policies = ['C0','C1','RC1','B152','UB152','R0','PB','BR15','RV15','N15','U15','RU15','N30','U30','N60','U60']
    assert set(data['集計']['all']) == set(policies)
    primary = data['集計']['all']['U15']['BBO']['3600']['125']
    new = data['集計']['all']['N15']['BBO']['3600']['125']
    frequency = data['頻度']['all']['U15']['全時間取得毎時']
    rate = primary['resolved_rate'] * 100
    whole = table(data, 'all', policies)
    front = table(data, 'train', ['C1','N15','U15','U30','U60','UB152'])
    back = table(data, 'validation', ['C1','N15','U15','U30','U60','UB152'])
    readme = f'''# 153 長い先行域から順行と反転を独立出生する

**正式反映前の結果草稿。自然監査の完了通知までは正式3MDを変更しない。** 主U15は{primary['entries']}取得/全73場、到達済率{rate:.4f}%だが平均{frequency:.6f}回/時で共同目標未達。新N15は{new['entries']}取得のみで、新入口の安定性を証明しない。窓30/60や単独枝へ主を交換しない。

## 全体・実BBO/H60±125

{whole}

1mini=100円/pt、往復77円+C5追加1,000円。利益・損失・差引はIFD既知小計、未知を0円にしていない。到達済分母、H完了分母、全取得分母を併記し、censorとneitherを分ける。入口IFD代用であり口座保有・可変数量・必須追尾の成果ではない。

主は全73min1を保持し先着率70%という数値条件を満たすが、93件/全720.9167時間という頻度は不足。新6件だけの率を一般化せず、旧C1全87の保護と新規の効果を分ける。共通R0の広い回復と、狭いPB/BR/RVを別に見て、狭い小群の率だけで独立新手法の採用達成としない。

## 前48場（参考）

{front}

## 後25場（参考）

{back}

全73場は既使用、152後の事後着想で前後も独立未知期ではない。長窓の可用性と新出生の容量、同case実方向変更と成立集合の違いを分ける。非成立の将来利益を機会損失として最適化しない。原因診断の新条件を153へ後付け採用しない。

## 入力・再現・閲覧の予定

新3JSONのみ各1gzipで保存し、先行高安/100X/148観測/152固定対照は共有する。条件/設定のF0全文prefixと設定済み513セルを保持し、結果は末尾へ追記する。独立960比較/23,040キー、CSV41,975セル/数値26,535セルと3画像のRoot確認は、自然選択の独立監査と分けて保管する。

この草稿はwork内のみ。F0/F1/F2原文先退避と自然監査成功後に、恒久入力・閲覧・再現・根拠・CSVリンクを実在化して正式へ反映する。新xlsxや新モデルを作らず、未知累計はnull非回復を守る。
'''
    (HERE / 'README結果草稿.md').write_bytes(readme.encode('utf-8'))
    appendix = '## 2026-11-12 実行結果（F0条件は不変更）\n\n' + whole + '\n\n共同目標未達。主交換/閾値変更なし。金融/自然監査の停止後に正式反映する。\n'
    (HERE / '結果追記草稿.md').write_bytes(appendix.encode('utf-8'))
    assert before == {p.name: sha(p) for p in watched}
    proof = {'成功': True, '区分': 'Root金融通知後のwork結果草稿', '正式反映': False,
        '正式3MD前後同体': before, '入力正本SHA256': sha(SUMMARY),
        '153自然選択又は新価格入力本文読取': False, '再計算_再選択_新学習': False,
        '草稿SHA256': sha(HERE / 'README結果草稿.md'), '結果追記SHA256': sha(HERE / '結果追記草稿.md')}
    (HERE / '結果草稿の確認.json').write_bytes((json.dumps(proof, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    print(json.dumps({'成功': True, '正式反映': False, '主件数': primary['entries'],
                      '率': rate, '頻度': frequency, '新N15': new['entries']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
