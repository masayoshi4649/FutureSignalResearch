"""153のCSV閲覧と、共有観測から固定選択を再集計する案内を恒久化する。"""
from pathlib import Path
import importlib.util
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
FORMAL = ROOT / 'study/00153_長い先行域から順行と反転を独立出生する'
OUTPUT = ROOT / 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/153_独立テクニカル入口'


def main() -> None:
    """
    機能: 既存CSV/保存資料をリンクし、Source復元・再集計範囲を記録する。
    引数: なし。返り値: None。新選択/金融計算/原板走査は行わない。
    """
    spec = importlib.util.spec_from_file_location('archive153_guides', HERE / '保存する.py')
    base = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(base)
    lib = base.library()
    index_path = FORMAL / '保管索引.json'
    index = json.loads(index_path.read_bytes())
    csv = sorted(OUTPUT.glob('*.csv'))
    images = sorted((OUTPUT / '支援画像').glob('*.png'))
    assert len(csv) == len(images) == 3
    index['CSV正本'] = [{'path': p.relative_to(ROOT).as_posix(), 'sha256': lib.sha(p), 'bytes': p.stat().st_size} for p in csv]
    index['Root視認の支援画像'] = [{'path': p.relative_to(ROOT).as_posix(), 'sha256': lib.sha(p)} for p in images]
    index['RootCSV検査通知'] = {'全セル': 41975, '数値セル': 26535, '画像': 3, '閲覧と算術は別検査': True}
    viewer = '''# 153のCSVを見る

最初は[全セッションCSV](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/153_独立テクニカル入口/全セッション.csv)を開く。全73場とU15/N15/C1の利益・損失・差引・未知・累計を残す。IFD未知が一度累積すれば全件確定差引はnullのままで、既知分小計と区別する。

[入口別CSV](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/153_独立テクニカル入口/入口別診断.csv)は主U15の93取得、[正逆比較CSV](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/153_独立テクニカル入口/正逆比較.csv)は16政策960比較。主はU15/全体/BBO/H60/±125で、窓30/60や良い小群へ交換していない。新xlsxは作らない。

主は46順18逆22未7不足・到達済み71.875%、全73場参加だが平均0.1290回/時で共同未達。新N15は4順0逆1未1不足/6取得にとどまり、100%は先着判明4件だけ。新6件IFDは全て既知でも、H完了が6件という意味ではない。金額は独立mini1枚の入口IFD代用で、口座収支・可変枚数・必須追尾は未評価。

[README](README.md)、[金融正本](成果物/集計.json)、[原因短報](根拠/独立出生が細った理由.md)、[再現手順](再現手順.md)へ分けた。RootはCSV41,975セル/数値26,535セルの独立再読と3支援画像の視認を完了。[作成票](検査/CSV作成の確認.json)、[再読票](検査/CSV独立再読.json)は[金融別算術](検査/金融独立検算.json)とは別証拠である。
'''
    replay = '''# 153の保存資料から再現する

[保管索引](保管索引.json)に元path・保存先・物理/解凍SHAを残した。[F0](検査/F0入口選択前.json)、[F1](検査/F1入口選択後.json)、[F2](検査/F2実金融集計前.json)を区別し、実行前3MDは[F0原文gzip](検査/F0実行前文書.json.gz)から復元する。現在の結果追記済みMDを実行前SHAへ使わない。設定済みV7 57行513セルはF0同体を保つ。

## 共有入力と153新生成

[153恒久入力](../../inputs/00153_先行高安の独立出生/README.md)にはr除外の先行高安とbook、F1新3JSON各1gzipを保存した。先行高安・100特徴・148の正逆観測・152の固定選択は共有参照し、原板・大入力を新たに複写していない。新モデルや教師もない。

必要なSource/人工はF0/F1/F2の小ZIP又は共有旧保存へ指紋で結ぶ。復元は元の相対構造を保持し、不足するwork源だけへ書く。現在のファイルが存在してSHAが違うときは上書きせず停止する。新しい作業根ではWindowsの記録済み絶対pathがあれば元と同じルートを用意し、暗黙の書換えをしない。

## 選択の再現

固定book・共有100X・r除外先行域を同event/q0へ結合し、全新q0判断を保存してからcaptures/meta/旧152対照を読む。SourceのCLI/人工/準備を停止源へ保存している。再実行は同指紋Source/入力と排他の未作成出力先を使い、P65を新資格にしない。旧B152/UB152は対照である。

[自然選択独立監査](検査/自然選択の独立監査.json)は作者logic/runnerをimportせず、全35,339q0/16,990,612末端/全政策と旧C1優先・固定152同体を照合した。初回は検査器のStampキー仮定で比較0停止し、検査器だけを修正して同じF1を監査した。元Source/自然値/閾値の変更や自然選択再実行ではなく、停止票と補修前小ZIPを後発の独立監査資料へ保存した。事前F0固定だったと遡及しない。

## 保存選択と共有観測から960比較を再集計する

```powershell
python -X utf8 'study/00153_長い先行域から順行と反転を独立出生する/再現資料/保存選択から再集計する.py' `
  --output-dir 'work/153再現用の新規出力'
```

不足する小型work源、固定F1/F2と選択対応だけを保存実体から復元する。共有148の4stream観測と凍結算術を用い、選択のやり直し・新モデル・Raw再走査を行わない。集計とtyped三表の全bytesを正本へ照合し、[再現票](検査/保存観測からの再現確認.json)へ記録する。独立[960比較/23,040キー](検査/金融独立検算.json)と[CSV再読](検査/CSV独立再読.json)は別検査である。

## 事後知見の境界

[原因短報](根拠/独立出生が細った理由.md)と対応JSONはR0・背景・PB/BR/RV・取得・実逆を分離した。入力可用性だけでも、R0を広げるだけでも目標の精度/頻度を同時に確認できなかった。153へ新閾値を後付けしない。全73既使用、前48/後25も未知期でなく、近接H60依存、真の高安/実受信時計の未認定、実mini/口座追尾未評価を維持する。
'''
    lib.write_new(FORMAL / '閲覧資料.md', viewer.encode('utf-8'))
    lib.write_new(FORMAL / '再現手順.md', replay.encode('utf-8'))
    script = HERE / '保存選択から再集計する.py'
    lib.save_file(script, FORMAL / '再現資料/保存選択から再集計する.py', lib.sha(script))
    proof = HERE / '保存選択の再集計/保存観測からの再現確認.json'
    assert json.loads(proof.read_bytes())['成功'] is True
    lib.save_file(proof, FORMAL / '検査/保存観測からの再現確認.json', lib.sha(proof))
    index['保存選択からの金融三表再現'] = {'保存元': '検査/保存観測からの再現確認.json',
        '正本と三表bytes同体': True, '新選択_新Raw走査': False}
    index_path.write_bytes(lib.json_bytes(index))
    print(json.dumps({'成功': True, '閲覧_再現_入力リンク': True}, ensure_ascii=False))


if __name__ == '__main__':
    main()
