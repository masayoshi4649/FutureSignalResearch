"""停止後の153自然監査・原因診断をF0へ遡及せず保管する。"""
from pathlib import Path
import argparse
import importlib.util
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
FORMAL = ROOT / 'study/00153_長い先行域から順行と反転を独立出生する'


def main() -> None:
    """
    機能: 明示停止票と小型源一式を保存し、後発の証跡として索引に追加する。
    引数: CLI phase(audit|cause)、folder/stop(Path)、stop-sha256(str)。返り値: None。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--phase', choices=('audit', 'cause'), required=True)
    parser.add_argument('--folder', type=Path, required=True)
    parser.add_argument('--stop', type=Path, required=True)
    parser.add_argument('--stop-sha256', required=True)
    args = parser.parse_args()
    args.folder, args.stop = args.folder.resolve(), args.stop.resolve()
    spec = importlib.util.spec_from_file_location('archive153_extra', HERE / '保存する.py')
    base = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(base)
    lib = base.library()
    assert lib.sha(args.stop) == args.stop_sha256
    stop = json.loads(args.stop.read_bytes())
    assert stop.get('成功') is True
    index_path = FORMAL / '保管索引.json'
    index = json.loads(index_path.read_bytes())
    key = '自然選択の独立監査' if args.phase == 'audit' else '独立出生の事後原因診断'
    assert key not in index
    existing = base.references(index)
    if args.phase == 'audit':
        files = {args.folder / name: info['SHA256'] for name, info in stop['保存対象'].items()}
        files[args.stop] = args.stop_sha256
        source = args.folder / '自然確認/監査の確認.json'
        saved = [lib.save_file(source, FORMAL / '検査/自然選択の独立監査.json', lib.sha(source))]
    else:
        files = {p: lib.sha(p) for p in args.folder.rglob('*') if p.is_file()
                 and p.suffix in ('.py', '.md', '.json', '.txt', '.zip') and '__pycache__' not in p.parts}
        saved = []
        for p, expected in files.items():
            if p.name == '短報.md':
                saved.append(lib.save_file(p, FORMAL / '根拠/独立出生が細った理由.md', expected))
            elif p.suffix == '.json' and p.stat().st_size > 100000:
                saved.append(lib.save_file(p, FORMAL / '根拠' / (p.stem + '.json.gz'), expected, True))
    for record in saved:
        existing[record['復元先']] = record
    refs = lib.resolve({p.relative_to(ROOT).as_posix(): expected for p, expected in files.items()}, key, existing)
    index[key] = {'停止SHA256': args.stop_sha256, '正本': saved, '全源復元参照': refs,
                  'F0_F1事前固定へ遡及': False, 'Source_閾値_主の変更': False}
    index_path.write_bytes(lib.json_bytes(index))
    print(json.dumps({'成功': True, '区分': key, '停止小源': len(files),
                       '索引SHA256': lib.sha(index_path)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
