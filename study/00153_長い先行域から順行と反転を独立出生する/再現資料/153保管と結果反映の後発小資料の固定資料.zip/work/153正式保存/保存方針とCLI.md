# 153正式保存の準備

2026-11-12。まだ153自然結果を読んでいない。所有はこの`work/153正式保存/`だけ。F0対象3MD/book/Source、旧152、既存入力は編集しない。以下は実行予定で、Rootから各段階path/SHAが通知されるまで実行しない。

## 保存するもの

- F0/F1/F2原本と、指紋が同じ実行前3MDを1つのgzipへ退避。結果追記前に済ませる。
- F0/F1/F2の必要な小型Source・人工・V7は新小ZIP又は既存恒久参照。元相対path/SHAを索引に残し、全保存bytesを再読照合する。
- **153新3JSONだけ**（q0判断、選択対応、選択確認）を各1gzipで`inputs/00153_先行高安の独立出生/`へ保存。新モデルは作らない。
- 金融集計正本、typed三表gzip、独立960比較票、CSV全セル再読票、作成票、後発の自然監査/原因診断はRootの結果通知後に明示jobで保存。
- 1分足×実時間15/30/60分の先行高安、100特徴、148の大正逆観測、152固定対照は既存の恒久実体を参照し、再複写しない。

事前固定と事後資料を混同せず、Source独立票の後発README等があれば固定段階を遡及して主張しない。正本の単なる全件転記、不要な途中版・大量画像・新xlsxを増やさない。

## 段階別CLI

```powershell
python -X utf8 work/153正式保存/保存する.py --stage F0 --freeze '<F0原本>' --sha256 '<Root通知SHA>' --execute-after-root-notice
python -X utf8 work/153正式保存/保存する.py --stage F1 --freeze '<F1原本>' --sha256 '<Root通知SHA>' --generated-dir '<新3JSONのfolder>' --execute-after-root-notice
python -X utf8 work/153正式保存/保存する.py --stage F2 --freeze '<F2原本>' --sha256 '<Root通知SHA>' --execute-after-root-notice
python -X utf8 work/153正式保存/保存する.py --stage 成果物 --job '<明示保存job.json>' --sha256 '<jobのSHA>' --execute-after-root-notice
```

F0保存前にRootの実行前3MD退避（`F0実行前文書/`）又は同指紋の現物を使う。F1はF0のSHA、F2はF1のSHAを明示結合する。同じ段階/保存先への再実行は上書きせず拒否する。金融は既に固定した選択から再集計し、新規選択や新Raw走査をしない。

## 結果文書の予定

金融結果と自然全件監査成功の通知後に、READMEを完了/主U15の合否へ更新し、条件/設定はF0全文prefixと設定済み57行513セルを保持して末尾へ結果を追記する。主U15、比較窓30/60、旧B152/UB152の区分は変えない。未知を含む金額、前48/後25、頻度/全73参加を別に残す。全期既使用、近接H60依存、入口IFDと口座追尾未評価を明記する。

最終確認は全固定源復元SHA、3gzip CRC/解凍SHA、条件prefix/513、正式リンク、保存選択/共有観測から正本とtyped三表bytesの再現を対象にする。Rootの独立960算術/CSV転記/画像確認とは証拠を分ける。
