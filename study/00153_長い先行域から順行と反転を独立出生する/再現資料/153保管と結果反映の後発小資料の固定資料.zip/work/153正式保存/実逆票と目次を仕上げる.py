"""R0実逆の独立票を後発保存し、既存文面を保持して試行への到達性を足す。"""
from pathlib import Path
import importlib.util
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
FORMAL = ROOT / 'study/00153_長い先行域から順行と反転を独立出生する'


def main() -> None:
    """
    機能: 通知済みR0独立確認2点と153/未掲載152の目次リンクを保存する。
    引数: なし。返り値: None。旧正式・Source・共通新知見本文を変更しない。
    """
    spec = importlib.util.spec_from_file_location('archive153_index', HERE / '保存する.py')
    base = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(base)
    lib = base.library()
    audit = ROOT / 'work/153原因診断の独立確認'
    assert lib.sha(audit / '独立確認.json') == '0425f7777d1c61f775d15899ada3ed05f401c5615d55c9a62eae9377388abd73'
    index_path = FORMAL / '保管索引.json'
    index = json.loads(index_path.read_bytes())
    saved = lib.save_file(audit / '独立確認.json', FORMAL / '検査/R0実逆の独立確認.json', lib.sha(audit / '独立確認.json'))
    refs = base.references(index)
    refs[saved['復元先']] = saved
    files = {p.relative_to(ROOT).as_posix(): lib.sha(p) for p in (audit / '確認する.py', audit / '独立確認.json')}
    index['R0実逆の独立確認'] = {'正本': saved, '全源復元参照': lib.resolve(files, 'R0実逆の独立確認', refs),
        '比較値': 144, '実逆も赤字': True, '新規則又は主変更': False, 'F0事前固定へ遡及': False}
    index_path.write_bytes(lib.json_bytes(index))
    changes = []
    for relative, prefix in [('README.md', 'study/'), ('study/README.md', ''),
                             ('docs/README.md', '../study/'), ('docs/議論/README.md', '../../study/')]:
        path = ROOT / relative
        before = path.read_bytes()
        nl = b'\r\n' if b'\r\n' in before[:300] else b'\n'
        line153 = f'[153：長い先行域から独立出生を検証]({prefix}00153_長い先行域から順行と反転を独立出生する/README.md)。主U15は93取得/全73場・46順18逆22未7不足、到達済み71.875%だが平均0.1290回/時で共同未達。新N15は6取得・先着判明4件のみ。C5既知利益604,611円/損失337,541円/差引+267,070円、未知3。960比較と自然全件を独立確認し窓30/60へ主交換なし。[CSVと分母]({prefix}00153_長い先行域から順行と反転を独立出生する/閲覧資料.md)。'
        line152 = f'[152：強い反対背景を複合回復で確認]({prefix}00152_強い反対背景を複合回復で切り替える/README.md)。主U1は697取得/全73場、到達済み62.63%・平均0.9668回/時で共同未達。C5既知差引+1,350,255円でも後25は49.13%/−240,706円。全体改善と18件の方向切替の悪化を分け、固定条件を保持した。[CSVと分母]({prefix}00152_強い反対背景を複合回復で切り替える/閲覧資料.md)。'
        assert b'00153_' not in before
        lines = [line153]
        if b'00152_' not in before:
            lines.append(line152)
        insertion = (nl + nl).join(line.encode('utf-8') for line in lines) + nl + nl
        # ----------------------------------------
        # Rootが最上段へ置いた共通新知見は残し、試行一覧の直前だけへ足す。
        marker = b'[151'
        position = before.find(marker)
        assert position >= 0
        after = before[:position] + insertion + before[position:]
        assert after.replace(insertion, b'', 1) == before
        path.write_bytes(after)
        changes.append({'path': relative, '追補のみ': True, '旧文面全bytes保持': True,
                        '現在SHA256': lib.sha(path)})
    (HERE / '目次追補の確認.json').write_bytes(lib.json_bytes({'成功': True, '変更': changes,
        '旧正式又はSource変更': False, 'Rootの共通知見リンクは最上段保持': True}))
    print(json.dumps({'成功': True, 'R0独立144値票保存': True, '目次追補': len(changes)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
