"""153の固定源復元・実行前prefix・設定513セル・リンクを最終確認する。"""
from pathlib import Path
import gzip
import importlib.util
import json
import re
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
FORMAL = ROOT / 'study/00153_長い先行域から順行と反転を独立出生する'


def main() -> None:
    """
    機能: 保管済み全源と結果文書を照合し、条件不変更・共同未達で停止する。
    引数: なし。返り値: None。Source/旧152以前/新採否は変更しない。
    """
    spec = importlib.util.spec_from_file_location('archive153_final', HERE / '保存する.py')
    base = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(base)
    lib = base.library()
    index_path = FORMAL / '保管索引.json'
    index = json.loads(index_path.read_bytes())
    refs = base.references(index)
    replay_script = HERE / '保存選択から再集計する.py'
    stored_script = FORMAL / '再現資料/保存選択から再集計する.py'
    assert lib.sha(replay_script) == lib.sha(stored_script)
    index['保存再集計Source'] = {'復元先': replay_script.relative_to(ROOT).as_posix(),
        '保存元': stored_script.relative_to(ROOT).as_posix(), '形式': '同体',
        '保存SHA256': lib.sha(stored_script), '解凍SHA256': lib.sha(replay_script),
        '保存bytes': stored_script.stat().st_size, '解凍bytes': replay_script.stat().st_size}
    refs[index['保存再集計Source']['復元先']] = index['保存再集計Source']
    extras = [p for p in HERE.glob('*.py')]
    extras += [HERE / name for name in ('保存方針とCLI.md', '準備の確認.json',
        '入力README追記の確認.json', '目次追補の確認.json', '結果反映の確認.json')]
    files = {p.relative_to(ROOT).as_posix(): lib.sha(p) for p in extras}
    if '保管と結果反映の後発小資料' not in index:
        index['保管と結果反映の後発小資料'] = lib.resolve(files, '保管と結果反映の後発小資料', refs)
        index['段階'] = 'F0/F1/F2・新3gzip・金融/CSV・独立監査/事後根拠・保存選択再現を保管。主U15共同未達で最終停止。'
        index_path.write_bytes(lib.json_bytes(index))
    else:
        for rel, expected in files.items():
            lib.check_reference(base.references(index['保管と結果反映の後発小資料'])[rel], expected)
    original = json.loads(gzip.decompress((FORMAL / '検査/F0実行前文書.json.gz').read_bytes()))
    before_docs = {Path(row['path']).name: row for row in original['文書']}
    docs = [FORMAL / name for name in ('README.md', '条件.md', '設定と結果.md')]
    fingerprints = {p.name: lib.sha(p) for p in docs}
    for name in ('条件.md', '設定と結果.md'):
        assert (FORMAL / name).read_bytes().startswith(before_docs[name]['本文'].encode('utf-8'))
    rows = []
    for text in (before_docs['設定と結果.md']['本文'], docs[2].read_text(encoding='utf-8')):
        rows.append([line for line in text.splitlines()
            if re.match(r'^\|\s+[A-Z]\d{2}\s+\|', line) and len(line.split('|')) == 13])
    assert rows[0] == rows[1] and len(rows[1]) == 57
    assert len({line.split('|')[1].strip() for line in rows[1]}) == 57
    assert all(len(line.split('|')[3:-1]) == 9 for line in rows[1])
    assert '全セルは未設定・未検証。' not in docs[2].read_text(encoding='utf-8')
    intro = docs[0].read_text(encoding='utf-8').split('\n\n')[1]
    assert '実行済み' in intro and '主U15' in intro and '共同目標未達' in intro
    summary = FORMAL / '成果物/集計.json'
    assert lib.sha(summary) == 'f8f1c4695d553ec1f0e7883c479fe381c8c954f4f0469346b60507a255ee3e44'
    data = json.loads(summary.read_bytes())
    assert data['主評価'] == {'全場最低1': True, '到達済70%': True, '全時間毎時1以上': False, '三目標共同': False}
    restored, unique, stable = {}, {}, {}
    for name, stage in index['固定段階'].items():
        frozen = json.loads((ROOT / stage['原文']['保存元']).read_bytes())
        saved = base.references(stage['全源復元参照'])
        restored[name] = 0
        for relative, expected in frozen['ファイル'].items():
            lib.check_reference(saved[relative], expected)
            restored[name] += 1
            unique[relative] = expected
            if not relative.startswith(FORMAL.relative_to(ROOT).as_posix() + '/'):
                assert lib.sha(ROOT / relative) == expected, relative
                stable[relative] = expected
    for record in index['153新生成3JSONを各1gzip保存'] + index['金融とCSV証跡']:
        lib.check_reference(record, record['解凍SHA256'])
    for key in ('自然選択の独立監査', '独立出生の事後原因診断', 'R0実逆の独立確認'):
        value = index[key]
        for rel, record in base.references(value['全源復元参照']).items():
            expected = record.get('解凍SHA256', record.get('sha256'))
            lib.check_reference(record, expected)
    for rel, expected in files.items():
        lib.check_reference(base.references(index['保管と結果反映の後発小資料'])[rel], expected)
    replay = json.loads((FORMAL / '検査/保存観測からの再現確認.json').read_bytes())
    assert replay['成功'] and replay['比較数'] == 960 and replay['正本と三表bytes再現']
    links = 0
    input_readme = ROOT / 'inputs/00153_先行高安の独立出生/README.md'
    for path in [*docs, FORMAL / '閲覧資料.md', FORMAL / '再現手順.md', input_readme]:
        for target in re.findall(r'\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
            if '://' in target or target.startswith('#'):
                continue
            local = unquote(target.strip('<>').split('#', 1)[0])
            assert (path.parent / local).exists(), (path.relative_to(ROOT).as_posix(), target)
            links += 1
    for relative in ('README.md', 'study/README.md', 'docs/README.md', 'docs/議論/README.md'):
        assert '00153_長い先行域から順行と反転を独立出生する/README.md' in (ROOT / relative).read_text(encoding='utf-8')
    mutation = json.loads((HERE / '入力README追記の確認.json').read_bytes())
    marker = '\n\n## 153新生成3JSON'.encode('utf-8')
    head = input_readme.read_bytes().split(marker, 1)[0]
    import hashlib
    assert hashlib.sha256(head).hexdigest() == mutation['追記前SHA256']
    assert fingerprints == {p.name: lib.sha(p) for p in docs}
    assert all(lib.sha(ROOT / rel) == expected for rel, expected in stable.items())
    author = {'成功': True, '試行': 153, '編集停止': True,
        '条件と設定F0全bytes_prefix保持': True,
        'V7': {'手法': 57, '尺度': 9, 'セル': 513, 'F0設定済み行全文同体': True},
        'README先頭': '実行済み・主U15共同目標未達',
        '新N15の100パーセントは4到達だけと明記': True,
        '主交換_閾値変更': False, '正式3MD': fingerprints,
        '全ローカルリンク実在': links, '4目次へ153追補': True,
        '入力README元全文prefix保持': True, '固定源復元件数': restored,
        '固定源unique': len(unique), 'Source前後同体': True,
        '新3JSON各1gzip再読同体': True, '正本とtyped三表bytes再現': True,
        '自然監査16990612_金融960比較23040キー_CSV41975は別票': True,
        'R0実逆144値独立確認も保存': True,
        '新モデル_共有大入力_原板_追加2場の新複写': False,
        '文書作者の自己確認と独立算術は別': True, '確認器SHA256': lib.sha(Path(__file__))}
    target = FORMAL / '検査/正式資料の最終反映確認.json'
    lib.write_new(target, lib.json_bytes(author))
    final = {'成功': True, '編集停止': True, '試行': 153,
        '保管索引SHA256': lib.sha(index_path), '作者最終票SHA256': lib.sha(target),
        'F0_F1_F2全固定源復元同体': restored, '全リンク_513_原文prefix': True,
        '保存選択から960比較と三表bytes再現': True,
        '主U15は率条件を満たすが頻度件数不足で共同未達': True,
        'Source_book_旧152以前不変更': True}
    final_path = FORMAL / '検査/正式保存の最終確認.json'
    lib.write_new(final_path, lib.json_bytes(final))
    stop = {**final, '正式最終票SHA256': lib.sha(final_path),
            '正式3MD': fingerprints, '保存Source': files}
    lib.write_new(HERE / '停止の確認.json', lib.json_bytes(stop))
    print(json.dumps({'成功': True, 'リンク': links, '513': True,
        '作者最終票SHA256': lib.sha(target), '正式保存最終票SHA256': lib.sha(final_path),
        '索引SHA256': lib.sha(index_path), '停止SHA256': lib.sha(HERE / '停止の確認.json')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
