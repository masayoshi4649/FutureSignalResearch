"""自然監査成功後だけ153の正式結果を反映し、F0条件/設定全文を保持する。"""
from pathlib import Path
import gzip
import hashlib
import importlib.util
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
FORMAL = ROOT / 'study/00153_長い先行域から順行と反転を独立出生する'
OUTPUT = '../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/153_独立テクニカル入口'


def sha(path: Path) -> str:
    """
    機能: 文書と通知済み正本の物理SHAを得る。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 固定結果と独立監査を確認しREADME更新/条件と設定への末尾追記を行う。
    引数: なし。返り値: None。Source/閾値/主/旧152を変更しない。
    """
    audit = FORMAL / '検査/自然選択の独立監査.json'
    assert sha(audit) == 'b94cb81789b82e1bf203d10490533fd3b1386586cfa1878fe7c2dfdc6cdcef27'
    assert json.loads(audit.read_bytes())['成功'] is True
    summary = FORMAL / '成果物/集計.json'
    assert sha(summary) == 'f8f1c4695d553ec1f0e7883c479fe381c8c954f4f0469346b60507a255ee3e44'
    data = json.loads(summary.read_bytes())
    old = json.loads(gzip.decompress((FORMAL / '検査/F0実行前文書.json.gz').read_bytes()))
    originals = {Path(row['path']).name: row['本文'].encode('utf-8') for row in old['文書']}
    assert all((FORMAL / name).read_bytes() == body for name, body in originals.items())
    spec = importlib.util.spec_from_file_location('format153_results', HERE / '結果稿を作る.py')
    formatting = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(formatting)
    policies = ['C0','C1','RC1','B152','UB152','R0','PB','BR15','RV15','N15','U15','RU15','N30','U30','N60','U60']
    whole = formatting.table(data, 'all', policies).replace('未定義%', '未定義')
    front = formatting.table(data, 'train', ['C1','N15','U15','U30','U60','UB152']).replace('未定義%', '未定義')
    back = formatting.table(data, 'validation', ['C1','N15','U15','U30','U60','UB152']).replace('未定義%', '未定義')
    primary = data['集計']['all']['U15']['BBO']['3600']['125']
    assert data['主評価'] == {'全場最低1': True, '到達済70%': True, '全時間毎時1以上': False, '三目標共同': False}
    readme = f'''# 153 長い先行域から順行と反転を独立出生する

**実行済み・主U15は共同目標未達。** 93取得/全73場、46順18逆22未到達7不足・到達済み71.875%で率条件は満たしたが、全時間平均0.1290回/時で頻度不足。新N15は6取得だけ、先着判明は4件で、安定した新入口の70%達成とは認定しない。主を比較窓30/60や単独枝へ交換していない。

## 検証した仮説

保存P65等の予測を資格にせず、全35,339適格q0から各側の1分実体・現在Last回復・5分Hist/RSI増分・同r量でRを判定した。5/15/30のEMA21増分/DI整合と15ADXの強度/非減速を背景にしたPB/BR、旧向きの失速と新側DI優位を伴うRVを比較した。先行域は1分足×実時間15/30/60分のr除外域で、15/30/60分足ではない。

主はN15=PB OR BR15 OR RV15を旧C1全87とC1優先統合したU15。PBはq0EMA8をrへ当てた観測形状で、当時arm済みや連続保持は未観測。RVのDIは現在優位で交差発生の観測ではない。[実行前条件](条件.md)と[設定済み513セル](設定と結果.md)はF0全文を保持し、そこに残る未実行表記はF0時点の記録、現在の状態は本READMEと末尾結果節で区別する。

## 全体結果・実BBO/H60±125

{whole}

数量独立1mini=100円/pt、往復77円+C5追加1,000円。金額はIFD既知小計で、未知を0円にしていない。主はC5利益604,611円/損失337,541円/差引+267,070円、既知90/未知3。H完了分母率46/86=53.49%、全取得分母率46/93=49.46%も併記する。

| 共同目標 | 実測 | 判定 |
| --- | --- | --- |
| 到達済み先着70%以上 | 46/64=71.875% | 数値条件達成 |
| 全73場min1 | 73/73 | 達成 |
| 全時間平均1回/時以上 | 93/720.9167h=0.129002回/時 | 未達 |
| 3条件共同 | 上記を同時判定 | **未達** |

旧C1の42順18逆/87取得と、新N15の4順0逆1未到達1不足/6取得を分ける。新N15の100%は4到達だけの少数群で、6件全勝を意味しない。新6件のIFDは全て既知で、H不足でも既知touchで清算できる場合を保持した。C5利益59,615円/損失3,077円/差引+56,538円。実逆N15の事後診断は0順5逆0未1不足/−84,462円で、1−pから推定していない。

PBは3取得、BR15も3取得、RV15は0。長窓比較N30/N60はPBと同じ3件のみで、率100%を見て主へ交換しない。共通R0は1,375取得でも45.11%・既知−2,919,488円であり、回復だけを広げれば精度を保てるとは確認できなかった。価格窓の可用性や広い候補数を売買の優位へ置き換えない。

## 前48・後25（全期既使用の参考区分）

### 前48場

{front}

### 後25場

{back}

後25の主U15は16順8逆4未2不足、66.67%、既知+64,767円/未知1。新N15は2件だけで、前後とも未知期間の性能を確認した試験ではない。旧B152/UB152は152正本と全120条件2,880キーで同体だった。予測由来の旧対照と、新しい独立出生の効果を混ぜない。

## どこで少なくなったか

保存された段階ではR0出生1,494→Trend78→PB4/BR15 4/RV15 0、取得3/3/0だった。厳しい背景と完成形の同時成立が小さく、長窓入力の可用率だけを原因にはできない。[原因短報](根拠/独立出生が細った理由.md)は判別段階・取得・実正逆を分けた事後知見で、153の条件を変更したものではない。129/145等の順次確認案との違いも残し、構造回復自体を新発見としない。

心理は「動力に沿う回復/端外維持」と「旧方向の失速中の突破失敗」を区別する仮説。真の支持抵抗、参加者の意思、将来の125pt持続を証明していない。後から良い枝・場・閾値を主へ選び直していない。

## 閲覧・保管・再現

[全セッションCSV]({OUTPUT}/全セッション.csv)から確認し、[入口別CSV]({OUTPUT}/入口別診断.csv)、[960比較CSV]({OUTPUT}/正逆比較.csv)で分解する。[閲覧資料](閲覧資料.md)、[金融正本](成果物/集計.json)、[入力案内](../../inputs/00153_先行高安の独立出生/README.md)、[保管索引](保管索引.json)、[再現手順](再現手順.md)へつながる。新xlsxは生成していない。

新3JSONだけを各1gzipで保存し、先行高安・148の100特徴/大観測・152固定対照は再複写しない。[自然全件監査](検査/自然選択の独立監査.json)は35,339q0/16,990,612末端、[金融別算術](検査/金融独立検算.json)は960比較/23,040キー、[CSV再読](検査/CSV独立再読.json)は41,975セル/数値26,535セル。Rootは3支援画像も視認した。検査器の初回Stampキー差による比較0停止は別履歴に保存し、同じF1のSource/自然値/閾値は変更していない。

全73場既使用、151/152後着想、近接H60/同場依存を残す。実miniの約定、可変枚数・建玉重複制約、必須利益追尾の口座収支は未評価。**153は頻度・新規件数が足りず採用達成とせず、固定条件を保持して次の問いへ進む。**
'''
    appendix = f'''

## 2026-11-12 実行結果（F0採用本文・設定513セルは不変更）

先頭の未実行はF0準備時点の原文として保持した。現在は自然選択/金融/全件監査済み。主U15は率条件71.875%と全73参加を満たすが、93取得/平均0.129002回/時で共同未達。新N15は6件・4到達だけで、新手法の安定性を認定しない。主交換・閾値変更なし。

{whole}

主はC5既知利益604,611円/損失337,541円/差引+267,070円、既知90/未知3。H完了46/86=53.49%、全取得46/93=49.46%。後25は66.67%/+64,767円・未知1。新N15は4順0逆1未1不足、IFD全6既知。R0の広い1,375件は45.11%で、量だけ増やして精度を保てる結果ではない。

1mini=100円/pt・往復77円+C5追加1,000円の入口IFD代用で、実口座/可変枚数/必須追尾を評価していない。全期既使用、前後も未知期でなく、未知を0へ補完しない。[結果](README.md) / [閲覧](閲覧資料.md) / [再現](再現手順.md)。
'''
    (FORMAL / 'README.md').write_bytes(readme.encode('utf-8'))
    for name in ('条件.md', '設定と結果.md'):
        (FORMAL / name).write_bytes(originals[name] + appendix.encode('utf-8'))
    proof = {'成功': True, '試行': 153, '主': 'U15', '共同未達': True,
        '自然監査SHA256': sha(audit), '金融正本SHA256': sha(summary),
        '条件と設定F0全bytes_prefix保持': True, '設定済み513セル変更': False,
        '主又は閾値変更': False, '旧152_Source_book変更': False,
        '正式3MD': {name: sha(FORMAL / name) for name in originals},
        '更新器SHA256': sha(Path(__file__))}
    (HERE / '結果反映の確認.json').write_bytes((json.dumps(proof, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    print(json.dumps(proof, ensure_ascii=False))


if __name__ == '__main__':
    main()
