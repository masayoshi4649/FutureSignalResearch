"""先行高安入力の既存README全文を保持し、153新3JSONの参照だけを追記する。"""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent


def main() -> None:
    """
    機能: 恒久入力案内へgzip物理/解凍指紋を付けて後発追加する。
    引数: なし。返り値: None。既存先行高安・book・100X等は変更しない。
    """
    formal = ROOT / 'study/00153_長い先行域から順行と反転を独立出生する'
    index = json.loads((formal / '保管索引.json').read_bytes())
    path = ROOT / 'inputs/00153_先行高安の独立出生/README.md'
    before = path.read_bytes()
    assert b'153\xe6\x96\xb0\xe7\x94\x9f\xe6\x88\x903JSON' not in before
    out = ['\n\n## 153新生成3JSON（F1後の追加）\n',
           '元の先行高安入力案内は全bytesを保持し、この節だけを追記した。新モデルはない。\n',
           '| 保存 | 物理bytes | 物理SHA256 | 解凍bytes | 解凍SHA256 |',
           '| --- | ---: | --- | ---: | --- |']
    for row in index['153新生成3JSONを各1gzip保存']:
        name = Path(row['保存元']).name
        out.append(f"| [{name}]({name}) | {row['保存bytes']:,} | `{row['保存SHA256']}` | {row['解凍bytes']:,} | `{row['解凍SHA256']}` |")
    out.append('\n各gzipの全CRC/解凍SHAを再読照合。先行高安/148の100特徴・観測/152固定対照は再複写していない。'
               '[正式結果](../../study/00153_長い先行域から順行と反転を独立出生する/README.md)・'
               '[保管索引](../../study/00153_長い先行域から順行と反転を独立出生する/保管索引.json)を参照する。\n')
    after = before + '\n'.join(out).encode('utf-8')
    path.write_bytes(after)
    assert path.read_bytes().startswith(before)
    proof = {'成功': True, '既存入力README全bytes_prefix保持': True,
             '追記前SHA256': hashlib.sha256(before).hexdigest(), '追記後SHA256': hashlib.sha256(after).hexdigest(),
             '先行高安_book_共有大入力の変更又は複写': False}
    (HERE / '入力README追記の確認.json').write_bytes((json.dumps(proof, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    print(json.dumps(proof, ensure_ascii=False))


if __name__ == '__main__':
    main()
