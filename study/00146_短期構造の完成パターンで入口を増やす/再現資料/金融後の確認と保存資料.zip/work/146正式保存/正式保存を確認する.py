"""146の保存指紋・正式文書・分母・リンクを最終確認する。新金融は実行しない。"""
from pathlib import Path
import gzip
import json
import re
import zipfile
from urllib.parse import unquote
from 保存部品 import ROOT,FORMAL,sha,json_bytes,write


def documents(raw: bytes) -> dict:
    """
    機能: gzip退避原文から復元先と本文を引く。
    引数: raw(bytes)はgzipJSON。
    返り値: dict[str,str]は原文。
    """
    return {item['path']:item['本文'] for item in json.loads(gzip.decompress(raw))['文書']}


# ----------------------------------------
def main() -> None:
    """
    機能: 保存済み証跡のみを照合し、成功時だけ編集停止票を作る。
    引数: なし。
    返り値: None。Source/Raw/価格CSV/新金融/旧成果を変更しない。
    """
    mpath=FORMAL/'保管索引.json';m=json.loads(mpath.read_bytes())
    checks=[];seen=set();archive_count=0;stored_count=0
    def inspect(item: object) -> None:
        """
        機能: 保存台帳を再帰してZIPとgzip/同体の指紋を確認する。
        引数: item(object)は台帳の任意要素。
        返り値: None。
        """
        nonlocal archive_count,stored_count
        if isinstance(item,list):
            for value in item:inspect(value)
        if not isinstance(item,dict):return
        if '保存元ZIP' in item and 'ZIP_SHA256' in item:
            p=ROOT/item['保存元ZIP'];key=(str(p),item['ZIP_SHA256'])
            if key not in seen:assert sha(p.read_bytes())==item['ZIP_SHA256'];seen.add(key);archive_count+=1
            entries=item.get('格納源',[item] if 'ZIP内path' in item else [])
            with zipfile.ZipFile(p) as saved:
                for entry in entries:assert sha(saved.read(entry.get('ZIP内path',entry.get('path'))))==entry['sha256']
        if 'ZIP' in item and 'ZIP_SHA256' in item and '格納源' in item:
            p=FORMAL/'再現資料'/item['ZIP'];key=(str(p),item['ZIP_SHA256'])
            if key not in seen:assert sha(p.read_bytes())==item['ZIP_SHA256'];seen.add(key);archive_count+=1
            with zipfile.ZipFile(p) as saved:
                for entry in item['格納源']:assert sha(saved.read(entry.get('ZIP内path',entry.get('path'))))==entry['sha256']
        if all(k in item for k in ('保存元','保存SHA256')):
            p=ROOT/item['保存元'];key=(str(p),item['保存SHA256'])
            if key not in seen:assert sha(p.read_bytes())==item['保存SHA256'];seen.add(key);stored_count+=1
            if '解凍SHA256' in item:
                raw=p.read_bytes();raw=gzip.decompress(raw) if item.get('形式')=='gzip' else raw
                assert sha(raw)==item['解凍SHA256']
        for value in item.values():inspect(value)
    inspect(m)
    for stage,expected in [('F0','3ee8c70b6c90e095b2d6873e8bd742b6603f2874d1914d0720d11969aef34325'),('F1','5086badf14bada442397e340d05766d06853a6cb5852765857e4262b5fc204a7')]:
        assert sha((FORMAL/('検査/F0出生前.json' if stage=='F0' else '検査/F1金融前.json')).read_bytes())==expected
    f0=json.loads((FORMAL/'検査/F0出生前.json').read_bytes());f1=json.loads((FORMAL/'検査/F1金融前.json').read_bytes())
    assert len(f0['ファイル'])==62 and len(f1['ファイル'])==81
    assert all(f1['ファイル'].get(name)==value for name,value in f0['ファイル'].items())
    before=documents((FORMAL/'検査/F0実行前文書.json.gz').read_bytes())
    condition=(FORMAL/'条件.md').read_text('utf8');prefix=before[FORMAL.relative_to(ROOT).as_posix()+'/条件.md']
    assert condition.startswith(prefix)
    old=before[FORMAL.relative_to(ROOT).as_posix()+'/設定と結果.md'];current=(FORMAL/'設定と結果.md').read_text('utf8')
    rows=lambda body:[line for line in body.splitlines() if re.match(r'^\| [A-Z]\d{2} \|',line)]
    assert rows(old)==rows(current) and len(rows(current))==57
    for row in rows(current):assert len(row.split('|')[3:-1])==9
    stop=json.loads((FORMAL/'検査/結果文書の停止.json').read_bytes())
    assert stop['成功'] and stop['元条件prefix/513セル保持']
    for item in stop['正式3MD']:assert sha((ROOT/item['path']).read_bytes())==item['sha256']
    summaryraw=(FORMAL/'成果物/集計.json').read_bytes();assert sha(summaryraw)=='70f1d57cd22febfba8c7cfe9515f633077b0f5a3bd9fe16e0c8278d8a1458d2d'
    summary=json.loads(summaryraw);primary=summary['主評価'];assert summary['成功']
    assert [primary[k] for k in ('順','逆','未到達','全H不足')]==[49,31,25,8]
    assert primary['到達済み率']==.6125 and not primary['到達済み先着70%以上'] and primary['全73場最低1取得'] and not primary['三項目すべて達成']
    assert abs(primary['全時間平均件数毎時']-.15674488498439487)<1e-15
    stats=summary['集計']['all']['U0']['BBO']['3600']['125']
    assert [stats[k] for k in ('entries','ifd_known','ifd_unknown','ifd_net5_profit','ifd_net5_loss','ifd_net5_sum')]==[113,110,3,641380,553850,87530]
    assert summary['取得集合数']=={'C0':81,'C1':87,'M1':20,'M3':6,'P0':26,'U0':113}
    assert summary['旧C0同体']['成功'] and summary['旧C1同体']['成功'] and summary['union']['同原行aliasで除いた取得数']==0
    mathproof=json.loads((FORMAL/'検査/短期数値と3分の独立確認.json').read_bytes())
    assert mathproof['成功'] and mathproof['比較']['公開足']==381 and mathproof['比較']['known確認']==3810 and mathproof['比較']['値確認']==3810
    funnel=json.loads((FORMAL/'検査/短期パターン非金融診断の停止.json').read_bytes());assert funnel['成功'] and funnel['編集停止'] and not funnel['金融ファイル読取']
    assert m['新26金融事後診断']
    separate=json.loads((FORMAL/'検査/金融別算術の確認.json').read_bytes());assert separate['成功'] and separate['比較数']==420 and separate['主要統計セル']==10080
    replay=json.loads((FORMAL/'検査/保存観測からの再現確認.json').read_bytes());assert replay['成功'] and replay['固定源数']==81 and replay['保存bytes復元数']==78 and len(replay['非複製'])==3
    assert replay['全420/参加頻度/union/phase/旧C0/C1同体'] and replay['三表JSON全bytes同体']
    reader=json.loads((FORMAL/'検査/CSV全セルの独立再読.json').read_bytes());assert reader['成功'] and reader['全データセル比較数']==29309 and reader['数値比較数']==18121
    visual=json.loads((FORMAL/'検査/CSV表示の目視確認.json').read_bytes());assert visual['成功'] and visual['試行']==146 and len(visual['三画像'])==3
    assert all((ROOT/m['CSV正本']/name).is_file() for name in visual['三画像'])
    for name,h in m['CSV_SHA256'].items():assert sha((ROOT/m['CSV正本']/name).read_bytes())==h
    # ----------------------------------------
    # 予定最終票自身だけは作成前なので存在判定を保留し、全ての他のリンクを確認する。
    count=0;missing=[];target=FORMAL/'検査/正式保存の最終確認.json'
    pages=list(FORMAL.rglob('*.md'))+[ROOT/m['CSV正本']/'README.md',ROOT/'inputs/00146_短期構造の入口/README.md']
    for page in pages:
        for link in re.findall(r'\]\(([^)]+)\)',page.read_text('utf8')):
            value=link.split('#',1)[0].strip('<>')
            if not value or re.match(r'^[a-zA-Z]+://',value):continue
            resolved=(page.parent/unquote(value)).resolve();count+=1
            if resolved!=target.resolve() and not resolved.exists():missing.append({'本文':str(page.relative_to(ROOT)),'先':link})
    assert not missing,missing
    for index in ('study/README.md','docs/README.md','docs/議論/README.md'):
        assert FORMAL.name in (ROOT/index).read_text('utf8')
    m['段階']='正式保存完了・編集停止。F0/F1原文/全81参照/78保存bytes/生成入力/観測/金融/CSV/数値独立人工/Source段階/新26事後/再集計を確認'
    m['最終確認']='検査/正式保存の最終確認.json';m['重大不足']=[];mpath.write_bytes(json_bytes(m))
    report={'成功':True,'試行':146,'編集停止':True,'重大不足':[],
        'F0全62/F1全81の指紋と前段包含':True,'全81復元参照/78保存bytes/非複製3':True,
        '保存ZIP確認数':archive_count,'保存ファイル確認数':stored_count,'原条件prefixと57手法513セル不変':True,
        '結果文書の停止SHA256':sha((FORMAL/'検査/結果文書の停止.json').read_bytes()),'正式4MD_SHA256':m['金融後正式文書SHA256'],
        '主U0':{'全取得':113,'全場':73,'順':49,'逆':31,'未到達':25,'不足':8,'到達済み率':.6125,'頻度毎時':primary['全時間平均件数毎時'],
            '利益C5':641380,'損失C5':553850,'既知差引C5':87530,'IFD既知':110,'IFD未知':3,'共同目標達成':False},
        '全420別算術10080セル':True,'保存観測から全420/三表JSONbytes再現':True,'CSV29309セル18121数値/Root3preview':True,
        '数値独立人工/Source非金融段階/新26金融事後を分離':True,'ローカルリンク確認数':count,'不足リンク':[],
        '3目次から到達':True,'追加2場/Raw価格CSV新読取':False,'新金融再計算':False,'旧145以前変更':False,
        '保管索引SHA256':sha(mpath.read_bytes()),'再現手順SHA256':sha((FORMAL/'再現手順.md').read_bytes()),
        '後発ZIP_SHA256':m['金融後の小資料']['ZIP_SHA256']}
    write(target,json_bytes(report))
    print(json.dumps({'成功':True,'最終確認SHA256':sha(target.read_bytes()),'保管索引SHA256':report['保管索引SHA256'],'重大不足':[]},ensure_ascii=False))


if __name__=='__main__':main()
