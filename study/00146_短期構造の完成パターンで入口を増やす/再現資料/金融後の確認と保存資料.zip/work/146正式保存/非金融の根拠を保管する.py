"""146の自然前数値人工と自然後非金融段階を区別して恒久保存する。"""
import gzip
import json
from pathlib import Path
from 保存部品 import ROOT,FORMAL,sha,save,write,json_bytes


def main() -> None:
    """
    機能: 停止済みの独立数値/Source段階票を一度保存し、原文と恒久リンク版を区別する。
    引数: なし。
    返り値: None。Source/原板/旧結果/正式3MDを変更しない。
    """
    mpath=FORMAL/'保管索引.json';m=json.loads(mpath.read_bytes())
    math=ROOT/'work/146短期数値と3分の独立検算';stop=math/'停止の確認.json'
    assert sha(stop.read_bytes())=='c80c1ea0da4ff8fa6f433d03b9aefdd8b554acb2224aa05720f37d25799b2370'
    proof=json.loads(stop.read_bytes());assert proof['成功'] and proof['編集停止']
    for name,item in proof['小型保存対象'].items():assert sha((math/name).read_bytes())==item['sha256']
    save(math/'独立確認.json',FORMAL/'検査/短期数値と3分の独立確認.json','db60e4d1d302a6281e09a1c7074857c862c07819e1d9cf27ec92bc73a600dd60')
    save(stop,FORMAL/'検査/短期数値と3分の停止.json',sha(stop.read_bytes()))
    m['短期数値人工ZIP']=save(math/'人工比較の票.zip',FORMAL/'根拠/短期数値の人工比較.zip',proof['小型保存対象']['人工比較の票.zip']['sha256'])
    source=ROOT/'work/146短期パターンの非金融診断';p=source/'停止の確認.json'
    assert sha(p.read_bytes())=='32dbf3c5d38e537b72b772dc7150c830d299be996c9be7b8bb7658d29bbad0b1'
    check=json.loads(p.read_bytes());assert check['成功'] and check['編集停止'] and not check['金融ファイル読取']
    for item in check['源と成果']:assert sha((ROOT/item['path']).read_bytes())==item['sha256']
    save(p,FORMAL/'検査/短期パターン非金融診断の停止.json',sha(p.read_bytes()))
    save(source/'結果/診断の確認.json',FORMAL/'検査/短期パターン段階の確認.json',sha((source/'結果/診断の確認.json').read_bytes()))
    m['短期非金融要約']=save(source/'結果/段階の要約.json',FORMAL/'根拠/短期パターン_段階の要約.json','9087c303c7fc3b27f2bbc282cb33c183e4363c7898c320f9928d6193bda310d4')
    detail=source/'結果/全73場の短期パターン段階.json.gz';raw=detail.read_bytes();decoded=gzip.decompress(raw)
    assert sha(decoded)==check['詳細gzip']['解凍sha256'] and len(decoded)==check['詳細gzip']['解凍bytes']
    m['短期非金融詳細']=save(detail,FORMAL/'根拠/全73場の短期パターン段階.json.gz','86d53dddd90bdaaa4c13bcdc33794491d84bba310c2824e4e8e2b5d7ccb785b4')
    m['短期非金融詳細']['内部gzipの解凍SHA256']=sha(decoded)
    report=source/'短期化で改善した段階と残った制限.md';body=report.read_text('utf8')
    assert sha(report.read_bytes())=='16c506560f30ff6d3e822c7ed04ed196c62e19105b3c119d01f84bb57aa14769'
    body+='\n恒久保存先: [段階要約](短期パターン_段階の要約.json)、[全73詳細gzip](全73場の短期パターン段階.json.gz)、[診断確認](../検査/短期パターン段階の確認.json)、[停止票](../検査/短期パターン非金融診断の停止.json)。コードと作者原短報は[後発ZIP](../再現資料/金融後の確認と保存資料.zip)へ保存する。\n'
    write(FORMAL/'根拠/短期化で改善した段階と残った制限.md',body.encode('utf8'))
    m['数値独立確認SHA256']='db60e4d1d302a6281e09a1c7074857c862c07819e1d9cf27ec92bc73a600dd60'
    m['非金融診断停止SHA256']=sha(p.read_bytes());m['非金融原短報SHA256']=sha(report.read_bytes())
    mpath.write_bytes(json_bytes(m))
    print(json.dumps({'成功':True,'数値人工/Source非金融/金融を分離':True,'大型Source/原板の新複写':False},ensure_ascii=False))


if __name__=='__main__':main()
