"""146の段階別保存器。通知されたpath/SHAだけを受け、正式3MDを変更しない。"""
from pathlib import Path
import gzip
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[2]
FORMAL=ROOT/'study/00146_短期構造の完成パターンで入口を増やす'
INPUTS=ROOT/'inputs/00146_短期構造の入口'


def sha(raw: bytes) -> str:
    """
    機能: 原文bytesのSHA256を求める。
    引数: raw(bytes)。
    返り値: strは指紋。
    """
    return hashlib.sha256(raw).hexdigest()


# ----------------------------------------
def json_bytes(value: dict) -> bytes:
    """
    機能: 日本語UTF-8の保存JSONへ変換する。
    引数: value(dict)。
    返り値: bytes。
    """
    return (json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode('utf-8')


# ----------------------------------------
def write(path: Path, raw: bytes) -> None:
    """
    機能: 未作成先だけへ原文を保存する。
    引数: path(Path)、raw(bytes)。
    返り値: None。
    """
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as out:out.write(raw)


# ----------------------------------------
def save(source: Path, target: Path, expected: str, packed: bool=False) -> dict:
    """
    機能: SHA照合した入力を各一度だけ同体又はgzip保存する。
    引数: source/target(Path)、expected(str)、packed(bool)。
    返り値: dictは復元情報。JSON内容は解析しない。
    """
    raw=source.read_bytes();assert sha(raw)==expected
    body=gzip.compress(raw,compresslevel=9,mtime=0) if packed else raw;write(target,body)
    assert (gzip.decompress(body) if packed else body)==raw
    return {'保存元':target.relative_to(ROOT).as_posix(),'復元先':source.relative_to(ROOT).as_posix(),
        '形式':'gzip' if packed else '同体','保存bytes':len(body),'保存SHA256':sha(body),'解凍bytes':len(raw),'解凍SHA256':expected}


# ----------------------------------------
def registries() -> tuple:
    """
    機能: 旧恒久保存索引から入力とコードの共有参照を作る。
    引数: なし。
    返り値: tuple[dict,dict]は復元先入力とコードSHA索引。自然データ本文は読まない。
    """
    inputs={};codes={}
    for number in (145,144,143,141,138,133):
        folder=next((ROOT/'study').glob(f'{number:05d}_*'));document=json.loads((folder/'保管索引.json').read_bytes());stack=[document]
        while stack:
            item=stack.pop()
            if isinstance(item,list):stack.extend(item);continue
            if not isinstance(item,dict):continue
            if all(k in item for k in ('保存元','復元先','保存SHA256','解凍SHA256')):inputs.setdefault(item['復元先'],item)
            if all(k in item for k in ('保存元ZIP','ZIP_SHA256','ZIP内path','sha256')):
                codes.setdefault(item['sha256'],{k:item[k] for k in ('保存元ZIP','ZIP_SHA256','ZIP内path','sha256')}|{'bytes':item.get('bytes')})
            if ('ZIP' in item or '保存元ZIP' in item) and '格納源' in item:
                path=ROOT/item['保存元ZIP'] if '保存元ZIP' in item else folder/'再現資料'/item['ZIP']
                for entry in item['格納源']:
                    h=entry.get('sha256');name=entry.get('ZIP内path',entry.get('path'))
                    if h and name:codes.setdefault(h,{'保存元ZIP':path.relative_to(ROOT).as_posix(),'ZIP_SHA256':item['ZIP_SHA256'],'ZIP内path':name,'sha256':h,'bytes':entry.get('bytes')})
            stack.extend(item.values())
    return inputs,codes


# ----------------------------------------
def snapshot(freeze: dict, stage: str, fingerprint: str) -> tuple:
    """
    機能: 固定された全MDを正式結果編集前の原文で保存する。
    引数: freeze(dict)、stage/fingerprint(str)。
    返り値: tupleは保存情報と文書復元参照。
    """
    docs=[]
    for name,h in freeze['ファイル'].items():
        p=Path(name)
        if p.suffix!='.md':continue
        raw=p.read_bytes();assert sha(raw)==h
        docs.append({'path':p.relative_to(ROOT).as_posix(),'sha256':h,'bytes':len(raw),'本文':raw.decode('utf-8')})
    assert sum(d['path'].startswith(FORMAL.relative_to(ROOT).as_posix()+'/') for d in docs)==3
    value={'試行':146,'段階':stage+'固定文書の原文退避','固定SHA256':fingerprint,'正式文書数':3,'文書数':len(docs),'文書':docs,
        '正式3MD変更':False,'事前固定の後造り':False}
    p=FORMAL/'検査'/f'{stage}実行前文書.json.gz';write(p,gzip.compress(json_bytes(value),mtime=0))
    info={'保存元':p.relative_to(ROOT).as_posix(),'保存SHA256':sha(p.read_bytes()),'正式文書数':3,'文書数':len(docs)}
    return info,[{'復元先':d['path'],'sha256':d['sha256'],'bytes':d['bytes'],'保存元':info['保存元'],'形式':'文書snapshot','抽出キー':d['path']} for d in docs]


# ----------------------------------------
def resolve(items: dict, stage: str, references: dict, docs: list) -> dict:
    """
    機能: 固定源をsnapshot/共有/小ZIP/非複製へ分けて完全参照を作る。
    引数: items(dict)、stage(str)、references(dict)、docs(list)。
    返り値: dict。177MBとexe/外部原板は本文を読まず非複製とする。
    """
    known,codes=registries();document={d['復元先']:d for d in docs}
    grouped={k:[] for k in ('文書snapshot','共有入力','共有コード','新固定源','意図して非複製','保存済み参照')};bodies={}
    for name,h in items.items():
        p=Path(name)
        if not p.is_relative_to(ROOT):
            grouped['意図して非複製'].append({'path':str(p),'sha256':h,'bytes':p.stat().st_size,'理由':'repository外の共用原板等。本文は読まず参照'});continue
        rel=p.relative_to(ROOT).as_posix()
        if rel in document:assert document[rel]['sha256']==h;grouped['文書snapshot'].append(document[rel]);continue
        if rel in references:assert references[rel]['解凍SHA256']==h;grouped['保存済み参照'].append(references[rel]);continue
        if rel=='work/122全場入力/入力.json' or p.suffix=='.exe' or p.suffix in ('.csv','.jsonl'):
            grouped['意図して非複製'].append({'path':rel,'sha256':h,'bytes':p.stat().st_size,'理由':'共用177MB/実行体/原価格。元手順・Go源からの復元に分けて本文を複写しない'});continue
        if rel in known and known[rel]['解凍SHA256']==h:
            ref=known[rel];raw=(ROOT/ref['保存元']).read_bytes();assert sha(raw)==ref['保存SHA256']
            decoded=gzip.decompress(raw) if ref['形式']=='gzip' else raw;assert sha(decoded)==h
            grouped['共有入力'].append(ref);continue
        if h in codes:
            ref={**codes[h],'復元先':rel};pzip=ROOT/ref['保存元ZIP'];assert sha(pzip.read_bytes())==ref['ZIP_SHA256']
            with zipfile.ZipFile(pzip) as z:assert sha(z.read(ref['ZIP内path']))==h
            grouped['共有コード'].append(ref);continue
        raw=p.read_bytes();assert sha(raw)==h and len(raw)<1_000_000,(rel,'大きい新入力は明示gzip保存先を指定する')
        grouped['新固定源'].append({'path':rel,'sha256':h,'bytes':len(raw)});bodies[rel]=raw
    assert sum(len(v) for v in grouped.values())==len(items)
    p=FORMAL/'再現資料'/f'146{stage}の固定資料.zip';p.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(p,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,raw in sorted(bodies.items()):z.writestr(name,raw)
    with zipfile.ZipFile(p) as z:
        assert z.testzip() is None
        for name,raw in bodies.items():assert z.read(name)==raw
    grouped['固定ZIP']={'ZIP':p.name,'ZIP_SHA256':sha(p.read_bytes()),'ZIP_bytes':p.stat().st_size,'格納源数':len(bodies),'格納源':grouped['新固定源']}
    return grouped


# ----------------------------------------
def f0(path: Path, fingerprint: str) -> None:
    """
    機能: Root通知後、F0原文/正式3MD/小コードを保存する。
    引数: path(Path)はRoot F0、fingerprint(str)は通知SHA。
    返り値: None。自然Sourceや金融結果を解析しない。
    """
    raw=path.read_bytes();assert sha(raw)==fingerprint;frozen=json.loads(raw);assert frozen['試行']==146
    original=save(path,FORMAL/'検査/F0出生前.json',fingerprint);snap,docs=snapshot(frozen,'F0',fingerprint)
    groups=resolve(frozen['ファイル'],'出生前',{},docs)
    prior=json.loads(next((ROOT/'study').glob('00138_*/保管索引.json')).read_bytes())
    index={'試行':146,'段階':'F0原文退避。自然結果/金融は未保存','F0_SHA256':fingerprint,'F0直接源数':len(frozen['ファイル']),
        'F0原文':original,'F0文書原文':snap,'F0復元参照':groups,'追加固定資料':groups['固定ZIP'],
        '共有入力':groups['共有入力'],'共有固定コード':groups['共有コード'],'意図して複製しない固定源':groups['意図して非複製'],
        '122巨大入力の復元':{'手順':'study/00122_E0固定条件を全セッションで検証する/再現資料/再現手順.md',
            'SHA256':'6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec','本文新複写/解析':False},
        'kernel共有源':prior['後段再現用の継承源'],'正式3MD変更':False,'新Raw/金融結果/追加2場読取':False}
    write(FORMAL/'保管索引.json',json_bytes(index))
    write(FORMAL/'検査/F0原文と源の保管確認.json',json_bytes({'成功':True,'試行':146,'F0_SHA256':fingerprint,
        '全源数':len(frozen['ファイル']),'全復元参照解決':True,'正式3MD先退避':True,'区分件数':{k:len(v) for k,v in groups.items() if isinstance(v,list)},'重大不足':[]}))


# ----------------------------------------
def f1(path: Path, fingerprint: str, source: Path, fixed: Path, metadata: Path, extras: list) -> None:
    """
    機能: Root通知後、F1原文とSource/固定/meta各一度gzip、増分を保存する。
    引数: path/source/fixed/metadata(Path)、fingerprint(str)、extras(list[Path])は小確認票。
    返り値: None。観測・損益を開かず正式3MDも変更しない。
    """
    raw=path.read_bytes();assert sha(raw)==fingerprint;frozen=json.loads(raw);assert frozen['試行']==146
    mpath=FORMAL/'保管索引.json';index=json.loads(mpath.read_bytes());old=json.loads((ROOT/index['F0原文']['保存元']).read_bytes())
    assert all(frozen['ファイル'][name]==h for name,h in old['ファイル'].items())
    original=save(path,FORMAL/'検査/F1金融前.json',fingerprint);snap,docs=snapshot(frozen,'F1',fingerprint)
    refs={index['F0原文']['復元先']:index['F0原文']};new=[]
    for p,name in ((source,'Sourceの出生と取得.json.gz'),(fixed,'固定取得入力.json.gz'),(metadata,'入口参照.json.gz')):
        record=save(p,INPUTS/name,frozen['ファイル'][str(p)],True);new.append(record);refs[record['復元先']]=record
    for p in extras:
        record=save(p,FORMAL/'検査'/p.name,frozen['ファイル'][str(p)]);refs[record['復元先']]=record
    addition={name:h for name,h in frozen['ファイル'].items() if name not in old['ファイル']}
    groups=resolve(addition,'金融前追加',refs,docs)
    index.update({'段階':'F0/F1原文とSource/固定/meta恒久保存。金融未保存','F1_SHA256':fingerprint,
        'F1直接源数':len(frozen['ファイル']),'F1増分源数':len(addition),'F1原文':original,'F1文書原文':snap,
        'F1増分復元参照':groups,'F1増分固定資料':groups['固定ZIP'],'新共用入力':new,'F1共有入力':groups['共有入力'],
        'F1共有コード':groups['共有コード'],'F1追加入力':groups['保存済み参照'],'正式3MD変更':False,'金融結果/Raw/追加2場読取':False})
    mpath.write_bytes(json_bytes(index))
    write(FORMAL/'検査/F1原文と増分の保管確認.json',json_bytes({'成功':True,'試行':146,'F1_SHA256':fingerprint,
        '全源数':len(frozen['ファイル']),'増分源数':len(addition),'全増分参照解決':True,'Source/固定/meta各一度gzip':True,
        '明示された新源/既存コードは指紋で新規と共有を区別':True,'正式3MD先退避':True,'重大不足':[]}))
