"""146の独立準備・結果確認・診断・保存器を後発小ZIPへまとめる。"""
from pathlib import Path
import json
import zipfile
from 保存部品 import ROOT,FORMAL,sha,json_bytes,save,write


def main() -> None:
    """
    機能: 全担当停止後の小成果を各一度保存し、固定前源と後発確認を区別する。
    引数: なし。金融診断の保存指示はRoot停止通知後に別JSONで指定する。
    返り値: None。Source/正式3MD/旧成果を変更しない。
    """
    own=ROOT/'work/146正式保存';p=FORMAL/'保管索引.json';m=json.loads(p.read_bytes())
    sources=[q for q in own.glob('*.py') if q.name!='保存観測から再集計する.py']
    sources += [own/'保存の準備.md',own/'準備の確認.json']
    specified={
        '146短期数値と3分の独立検算':['go.mod','main.go','独立比較する.py','確認を停止する.py','README.md'],
        '146短期完成パターンの因果レビュー':['overlay.json','独立人工_test.go','準備を確認する.py','準備の確認.json'],
        '146転送と運転の独立準備レビュー':['確認する.py','準備の確認.json'],
        '146短期パターンの非金融診断':['段階を診断する.py','人工検査.py','要点をまとめる.py','条件と分母.md','準備の確認.json','短期化で改善した段階と残った制限.md'],
        '146短期構造の金融集計':['準備の確認.json','採用仕様追補の確認.json'],
        '146正式結果を反映する':['更新する.py','確認する.py','文書反映の確認.json','停止の確認.json','Source要点.md','結果草稿.md'],
    }
    for folder,names in specified.items():sources += [ROOT/'work'/folder/n for n in names]
    result=ROOT/'work/146正式結果を反映する'
    for name,target in [('文書反映の確認.json','結果文書の確認.json'),('停止の確認.json','結果文書の停止.json')]:
        source=result/name;save(source,FORMAL/'検査'/target,sha(source.read_bytes()))
    visual=ROOT/'work/146短期完成の評価/CSV表示の目視確認.json'
    save(visual,FORMAL/'検査/CSV表示の目視確認.json',sha(visual.read_bytes()))
    instruction=own/'金融診断の保存指示.json';extra=json.loads(instruction.read_bytes());assert extra['停止済み'] and extra['条件変更なし']
    m['新26金融事後診断']=[]
    for item in extra['同体保存']:
        source=ROOT/item['元'];target=FORMAL/item['先'];m['新26金融事後診断'].append(save(source,target,item['sha256'],item.get('gzip',False)))
    for item in extra.get('本文リンク調整',[]):
        source=ROOT/item['元'];raw=source.read_bytes();assert sha(raw)==item['sha256'];body=raw.decode('utf8')
        for a,b in item['置換'].items():body=body.replace(a,b)
        target=FORMAL/item['先'];write(target,body.encode('utf8'))
        m['新26金融事後診断'].append({'保存元':target.relative_to(ROOT).as_posix(),'保存SHA256':sha(target.read_bytes()),'原文SHA256':item['sha256'],'変更は恒久リンクのみ':True})
    sources += [ROOT/name for name in extra['小ZIP']]+[instruction]
    zp=FORMAL/'再現資料/金融後の確認と保存資料.zip';entries=[];seen=set()
    with zipfile.ZipFile(zp,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for source in sorted(sources):
            raw=source.read_bytes();name=source.relative_to(ROOT).as_posix();assert len(raw)<1_000_000
            if name in seen:continue
            seen.add(name);archive.writestr(name,raw);entries.append({'復元先':name,'ZIP内path':name,'bytes':len(raw),'sha256':sha(raw)})
    with zipfile.ZipFile(zp) as archive:
        for item in entries:assert sha(archive.read(item['ZIP内path']))==item['sha256']
    m['金融後の小資料']={'保存元ZIP':zp.relative_to(ROOT).as_posix(),'ZIP_SHA256':sha(zp.read_bytes()),'格納源数':len(entries),'格納源':entries,'金融前固定への後付け':False}
    m['正式結果文書確認SHA256']=sha((FORMAL/'検査/結果文書の確認.json').read_bytes())
    m['金融後正式文書SHA256']={name:sha((FORMAL/name).read_bytes()) for name in ('README.md','条件.md','設定と結果.md','閲覧資料.md')}
    m['段階']='固定前原文/全81参照/金融/数値人工/Source段階/新26事後/再集計/CSV/結果文書を保存。最終確認待ち'
    p.write_bytes(json_bytes(m))
    print(json.dumps({'成功':True,'後発ZIP_SHA256':m['金融後の小資料']['ZIP_SHA256'],'格納源数':len(entries),'事前固定の後造り':False},ensure_ascii=False))


if __name__=='__main__':main()
