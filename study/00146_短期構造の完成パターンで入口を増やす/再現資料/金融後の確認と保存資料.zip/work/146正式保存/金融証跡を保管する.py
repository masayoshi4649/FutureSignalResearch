"""146のRoot別算術/CSVと保存観測再現を恒久保存する。正式3MDは変更しない。"""
from pathlib import Path
import json
from 保存部品 import ROOT,FORMAL,INPUTS,sha,save,write,json_bytes


def main() -> None:
    """
    機能: 金融完了通知後の小証跡を指紋照合し一度保存する。
    引数: なし。
    返り値: None。新金融/Raw/Source/CSVを生成しない。
    """
    own=ROOT/'work/146短期完成の評価';csv=ROOT/'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/146_短期完成パターン'
    p=FORMAL/'保管索引.json';m=json.loads(p.read_bytes())
    files=[(own/'出生の完了.json','出生の完了.json'),(own/'観測の完了.json','観測の完了.json'),
        (own/'転送の完了.json','転送の完了.json'),(own/'集計の完了.json','集計の完了.json'),
        (own/'金融評価/集計完了.json','集計器の完了.json'),(own/'金融別算術の確認.json','金融別算術の確認.json'),
        (own/'CSV独立再読.json','CSV全セルの独立再読.json'),(csv/'CSVの確認.json','CSV作成の確認.json'),
        (ROOT/'work/146保存観測の再現確認/保存観測からの再現確認.json','保存観測からの再現確認.json')]
    for source,name in files:save(source,FORMAL/'検査'/name,sha(source.read_bytes()))
    separate=json.loads((FORMAL/'検査/金融別算術の確認.json').read_bytes())
    assert separate['成功'] and separate['比較数']==420 and separate['主要統計セル']==10080
    assert sha((FORMAL/'検査/金融別算術の確認.json').read_bytes())=='85e0a677276e38372a5d92afa0aea46c3e4b48566a33a787dcae193ea4cf581d'
    reader=json.loads((FORMAL/'検査/CSV全セルの独立再読.json').read_bytes())
    assert reader['成功'] and reader['全データセル比較数']==29309 and reader['数値比較数']==18121
    m['CSV正本']=csv.relative_to(ROOT).as_posix();m['CSV_SHA256']={Path(t['CSV']['path']).name:t['CSV']['sha256'] for t in reader['表別']}
    for name,h in m['CSV_SHA256'].items():assert sha((csv/name).read_bytes())==h
    m['金融別算術SHA256']=sha((FORMAL/'検査/金融別算術の確認.json').read_bytes())
    m['保存観測再現SHA256']=sha((FORMAL/'検査/保存観測からの再現確認.json').read_bytes())
    assert m['保存観測再現SHA256']=='f3a8ae6091fedee43130a30db21332cca859e727d4a1a77ef9520a98c0b70f19'
    source=ROOT/'work/146正式保存/保存観測から再集計する.py'
    m['再集計器']=save(source,FORMAL/'再現資料/保存観測から再集計する.py',sha(source.read_bytes()))
    previous=json.loads(next((ROOT/'study').glob('00145_*/保管索引.json')).read_bytes())
    m['金融後の共有コード']=previous['金融後の共有コード']
    m['段階']='固定前原文/全81源/Source固定meta/観測/金融/Root別算術/CSV/保存再集計を保存。結果文書と非金融追補は後続'
    p.write_bytes(json_bytes(m))
    write(INPUTS/'README.md',('# 146の短期構造共用入力\n\nSource・固定取得・入口参照を各一度gzip保存。元bytes/圧縮指紋と復元先は[保管索引](../../study/'+FORMAL.name+'/保管索引.json)を参照する。Sourceの重複した価格参照を圧縮して保持し、原板・177MB派生・実行体は複製しない。\n').encode('utf8'))
    print(json.dumps({'成功':True,'420別算術/10080セル':True,'CSV29309/18121':True,'保存観測再現SHA256':m['保存観測再現SHA256']},ensure_ascii=False))


if __name__=='__main__':main()
