"""146非金融診断の場単位読取・未知・物理membershipを人工だけで確認する。"""
from pathlib import Path
import copy
import importlib.util
import json
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('diag146', HERE/'段階を診断する.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def scene_fixture(n: int) -> dict:
    """
    機能: 0足/0候補の人工場を作る。
    引数: n(int)。返り値: dict。
    """
    return {'success': True, 'session': f'人工{n:02d}_Day', 'contract': 'X', 'start': n*10000, 'end': n*10000+8000,
            'raw_passes': 1, 'raw': {'path': '人工・未読', 'sha256': 'a'*64}, 'actual_sha256': 'a'*64,
            'counts': {}, 'quality': {}, 'expected_quality': {}, 'stat_before': {}, 'stat_after': {},
            'bars': [], 'checks': [], 'events': [], 'groups': [], 'stats': {}}


def bar_fixture(width: int, start: int, index: int) -> dict:
    """
    機能: 初知Contextと未知数値を持つ人工正本足を作る。
    引数: width/start/index(int)。返り値: dict。
    """
    stamp = {'time': start+width+60, 'index': index, 'source_line': index+1}
    bar = {'id': f'b{width}/{start}', 'session': '人工00_Day', 'contract': 'X', 'width_seconds': width,
           'start': start, 'end': start+width, 'available_at': start+width+60, 'stamp': stamp,
           'price_known': True, 'volume_known': False, 'closed': True, 'volume': 0,
           'technical': {k: {'known': False, 'value': 0} for k in ('ema8', 'ema21', 'atr', 'histogram', 'previous_histogram', 'previous_atr')}}
    return {'bar': bar, 'context': {'at': dict(stamp), 'direction30': 0, 'fields': {}, 'refs': []}}


class ReaderFixture:
    """自然ファイルを開かない73場のreader互換。"""

    def __init__(self):
        """
        機能: 全場0件とtop metadataを初期化する。
        引数: self(ReaderFixture)。返り値: None。
        """
        self.top = {'success': True, 'trial': 146, 'financial_labels_used': False, 'source_positions_used': False,
                    'summary': {'候補数': 0, '物理取得数': 0, 'filled候補数': 0}}
        self.scenes = [scene_fixture(n) for n in range(73)]

    def __iter__(self):
        """
        機能: 人工場を固定順で返す。
        引数: self(ReaderFixture)。返り値: Iterator[dict]。
        """
        return iter(self.scenes)


class DiagnosisTests(unittest.TestCase):
    """出力の分母と読取境界を確認する。"""

    def test_場単位JSONと大きな文字列(self) -> None:
        """
        機能: buffer境界を越えるUTF-8値とscenes後のtop値を読む。
        引数: self(DiagnosisTests)。返り値: None。
        """
        value = {'success': True, '説明': 'あ'*700000, 'scenes': [{'x': 1}, {'x': 2}], 'summary': {'n': 2}}
        with tempfile.TemporaryDirectory() as name:
            p = Path(name)/'人工.json'; p.write_text(json.dumps(value, ensure_ascii=False), encoding='utf-8')
            reader = module.SceneReader(p)
            self.assertEqual(list(reader), value['scenes']); self.assertEqual(reader.top['summary'], {'n': 2})
            p.write_text('{"scenes":[] } 追加', encoding='utf-8')
            with self.assertRaises(AssertionError): list(module.SceneReader(p))

    def test_全73ゼロと未知助走(self) -> None:
        """
        機能: 全0場を保持し、価格既知と数値未知を区別する。
        引数: self(DiagnosisTests)。返り値: None。
        """
        reader = ReaderFixture(); result = module.diagnose(reader)
        self.assertEqual((result['全場数'], result['物理取得数'], len(result['未取得場'])), (73, 0, 73))
        s = scene_fixture(0); s['bars'] = [bar_fixture(60, i*60, i+1) for i in range(3)]
        s['bars'][0]['context']['refs'] = None
        r = s['bars'][-1]['bar']
        for family, count in (('A1', 1), ('B1', 0)):
            s['checks'].append({'family': family, 'width_seconds': 60, 'status': 'pattern_rejected',
                'at': r['stamp'], 'r': module.reference(r), 'used_refs': [],
                'gates': {'当場連続形状窓': {'known': True, 'value': count}, 'r_Hist側符号': {'known': False, 'value': 0}},
                'reasons': ['r_Hist側符号未知']})
        row = module.analyze_scene(s)
        self.assertEqual(row['family']['A1']['gates']['r_Hist側符号']['未知'], 1)
        self.assertEqual(row['family']['A1']['warmup']['p_histogram未知'], 1)

    def test_membershipと物理数(self) -> None:
        """
        機能: 両width所属でも1物理取得とし代表/Quote不一致を拒否する。
        引数: self(DiagnosisTests)。返り値: None。
        """
        s = scene_fixture(0); s['bars'] = [bar_fixture(60, 120, 3), bar_fixture(180, 0, 3)]
        q = {'clock': '人工', 'time': 241, 'index': 4, 'source_line': 5, 'last': 100, 'bid': 99, 'ask': 101, 'quote_ok': True}
        for known, family in zip(s['bars'], ('A1', 'A3')):
            ref = module.reference(known['bar']); s['events'].append({'id': family, 'family': family, 'width_seconds': known['bar']['width_seconds'],
                'group_id': 'g', 'status': 'filled', 'side': 1, 'entryQuote': q, 'arm': ref, 'confirm': ref})
        s['groups'] = [{'id': 'g', 'side': 1, 'status': 'filled', 'candidate_ids': ['A3', 'A1'],
                        'filled_candidate_ids': ['A3', 'A1'], 'representative_id': 'A3', 'entryQuote': q}]
        row = module.analyze_scene(s)
        self.assertEqual((row['filled候補数'], row['物理取得数'], row['membership']['両width']), (2, 1, 1))
        bad = copy.deepcopy(s); bad['groups'][0]['representative_id'] = 'A1'
        with self.assertRaises(AssertionError): module.analyze_scene(bad)


if __name__ == '__main__':
    unittest.main(verbosity=2)
