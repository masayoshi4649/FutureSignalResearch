"""保存済みの段階集計から小型の要点票を作る。金融は扱わない。"""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
DETAIL = HERE/'結果/全73場の短期パターン段階.json'


def sha(path: Path) -> str:
    """
    機能: 作業内の小型成果の指紋を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def summarize(detail: dict) -> dict:
    """
    機能: 非排他的な個別条件と説明順の累積分母を区別する。
    引数: detail(dict)。返り値: dict。
    """
    result = {key: detail[key] for key in ('全場数', '候補数', 'filled候補数', '物理取得数',
              '取得場数', '未取得場', 'hours', '物理平均毎h', 'membership_物理群', 'group_status', '未解決参照', 'Source参照')}
    result.update({'成功': True, '試行': 146, '金融参照': False, '元段階集計': {'path': str(DETAIL), 'sha256': sha(DETAIL)},
                   '段階順の意味': '既存gateの同時成立を説明用の順で数え直す。実装の評価順や独立した因果効果ではない。',
                   '全足': {}, 'family': {}})
    for width, counts in detail['全足_実配送'].items():
        denominator = counts['全配送足']
        result['全足'][width] = {'分母_全実配送足': denominator,
            'known件数と率': {key: {'件数': value, '率': value/denominator} for key, value in counts.items() if key != '全配送足'}}
    for family, source in detail['family'].items():
        rows = [(set(c['理由']), c['件数']) for c in source['理由の組']
                if '当場連続形状窓不成立' not in c['理由']]
        background = ['p初知背景', 'p初知ATR5正', 'r現在背景', 'r現在fresh']
        shape = ['o_EMA帯接触', 'p逆実体'] if family[0] == 'A' else ['前3本域正幅', '元方向端突破', '非両端突破', '域内終値', '反転実体']
        momentum = ['p_Hist実悪化', 'r_Hist側符号', 'r_Hist実改善'] if family[0] == 'A' else ['r_Hist側符号', 'r_Hist実改善']
        groups = [('背景', background), ('価格形状', shape), ('Hist位相', momentum),
                  ('同足量', ['p_r同足量確認']), ('r終値K', ['r終値K回復']),
                  ('TR上限', ['r_TR急変ガード']), ('配送strict', ['p_r知得の時刻とindexが厳密増加'])]

        def passed(names: list[str]) -> int:
            """
            機能: 保存済み複合理由から指定gateの全成立件数を数える。
            引数: names(list[str])。返り値: int。
            """
            return sum(count for reasons, count in rows if not any(
                name+suffix in reasons for name in names for suffix in ('不成立', '未知')))

        cumulative = []; names = []
        for label, gates in groups:
            names.extend(gates)
            cumulative.append({'追加した役割': label, '全成立数': passed(names)})
        status = source['status']
        technical = sum(status.get(k, 0) for k in ('birth_eligible', 'position_rejected', 'structure_rejected'))
        assert cumulative[-1]['全成立数'] == technical
        assert sum(count for _, count in rows) == source['pContext及び短期値の判別分母']
        result['family'][family] = {'判定数': source['判定数'], '形状窓成立': source['pContext及び短期値の判別分母'],
            '技術全条件成立': technical, 'status': status, '候補status': source['候補status'],
            '役割単独成立_互いに重複': {label: passed(gates) for label, gates in groups},
            '説明順の累積': cumulative, '個別gate': source['個別gate'],
            '何らかのgate未知': sum(count for reasons, count in rows if any(x.endswith('未知') for x in reasons)),
            '未知だけが残る判定': sum(count for reasons, count in rows if any(x.endswith('未知') for x in reasons)
                                  and not any(x.endswith('不成立') for x in reasons)),
            '形状窓不足の背景': source['形状窓不足の背景'], 'pContext不足_非排他的': source['pContext不足_非排他的'],
            '短期数値不足_非排他的': source['短期数値不足_非排他的']}
    return result


def render(result: dict) -> str:
    """
    機能: 主要段階と限界を短い日本語文書へ出力する。
    引数: result(dict)。返り値: str。
    """
    lines = ['# 146短期完成パターンの非金融診断', '', '確認日: 2026-11-12。保存Sourceだけを使用した。新金融・原板・CSV・追加2場は読んでいない。', '',
        '29候補のうち26候補が26物理取得になった。取得20場・未取得53場を残す。1分所属20・3分所属6・両幅所属0で、同時成立の水増しはない。720.9167時間に対し0.03607回/時であり、入口の頻度は依然不足する。', '',
        '## 実配送足の既知率', '', '|幅|全足|価格|EMA21|Hist|前Hist|', '|---|---:|---:|---:|---:|---:|']
    for width, row in result['全足'].items():
        values = row['known件数と率']; selected = [values[k] for k in ('価格known', 'ema21_known', 'histogram_known', 'previous_histogram_known')]
        cells = [str(width)+'秒', str(row['分母_全実配送足'])] + [str(v['件数'])+' ('+format(v['率'], '.1%')+')' for v in selected]
        lines.append('|'+ '|'.join(cells)+'|')
    lines += ['', '価格既知と数値助走済みは別である。未知価格・未closedで数値をcold resetする規約により、特に3分ではHistが全実配送足の41.3%にとどまる。同限月の配送済み数値carryがあっても、当場の欠測後の助走と形状履歴は補えない。前Hist列は短期数値票の可用性であり、判定は実際の隣接o/p/rのHist差を使う。この全足分母には新規限界以降・同Raw catch-upの足も含むため、以下の最新r判定数と同一ではない。', '',
        '## 段階別の削減', '', '|型|最新r判定|当場形状窓あり|技術全成立|幅不適合|完成時位置外|出生|取得|', '|---|---:|---:|---:|---:|---:|---:|---:|']
    for family, row in result['family'].items():
        s = row['status']; e = row['候補status']
        lines.append('|'+ '|'.join(map(str, (family, row['判定数'], row['形状窓成立'], row['技術全条件成立'],
            s.get('structure_rejected', 0), s.get('position_rejected', 0), s.get('birth_eligible', 0), e.get('filled', 0))))+'|')
    lines += ['', '形状窓はAがo/p/rの3本、Bが前3本+p/rの5本で、当場の価格既知・closed・連続格子を要求する。最新rであること、p/rの知得時刻とindexの双方strict増加も維持する。51技術完成→構造幅4件除外→完成時現在LastのK/cap域外18件除外→29出生で、出生後はB1の期限切れ2件・B3の実P位置外1件により26取得となる。これらの後段statusは排他的である。', '',
        '## 同時条件の内訳', '', '以下は形状窓ありを起点に、既存gateを背景→価格形状→Hist位相→同足量→r終値K→TR上限→配送strictの説明順で累積した数である。条件の実行順を変更したものではなく、先に置いた条件に失敗原因を一意に帰属させる表でもない。', '',
        '|型|形状窓|背景|価格形状も|Histも|量も|Kも|TRも|配送も|', '|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    for family, row in result['family'].items():
        lines.append('|'+ '|'.join(map(str, [family, row['形状窓成立']]+[x['全成立数'] for x in row['説明順の累積']]))+'|')
    lines += ['', 'Aの価格形状はoのEMA帯接触とpの逆実体、Hist位相はp悪化・r側符号・r実改善である。Bの価格形状は前3本正幅・元方向端突破・非両端突破・域内終値・反転実体、Hist位相はr側符号とr実改善である。p初知Contextとr現在背景を分け、p未知を後のrで補っていない。', '',
        '背景成立後にも、Aでは価格形状とHistの悪化→改善が同時に揃う部分が細く、Bでは端突破→域内回復の形状とHistが同時に揃う部分が細い。同足量・K・TRも追加で減らす。個別gateの非排他的件数は要約JSONへ残した。未知をすべて解消しても他の既知不成立が残る判定が多いため、Hist助走だけを全未成立の原因とはしない。', '',
        '## 145と比較して言える範囲', '',
        '145は持続arm682→技術confirm45→13出生→6取得、146は完成パターン51→29出生→26取得となった。出生候補に対する取得割合は13件中6件から29件中26件へ上がり、構造幅不適合も技術完成後は4件である。ただし145の幅234件はarm時点、146の4件は技術完成後の条件付き分母であり、直接の削減率比較はできない。両方の入口定義も異なり、短期化だけの因果効果や優位性は未確認である。', '',
        '現在位置だけを緩めても技術完成は51件にとどまり、仮に全件が別々に取得できても0.07074回/時である。これは頻度上限の楽観的な計数で、重複・競合・実P・期限を無視している。cap緩和だけで約1回/時へ届くとは言えない。次に検討するなら、助走品質、pで保存した背景とrの背景の役割、価格形状とHist符号確認の重なりを分けた新仮説が必要である。ここでは条件変更も成績による選別もしていない。', '',
        'Source.refs/短期足の正本結合で未解決は0。場頭Context.refs=nullは参照なしとして扱う診断器側の接続修正を行った。GEN/Sourceは変更していない。参照解決は保存票の整合確認であり、原CSV/Rawからの独立再計算ではない。', '',
        '## 再現と根拠', '',
        '- `段階を診断する.py --source <Source正本> --sha256 ec227abe02e77220cd7947c763cd6b7e0cc53f214d54f8faed11b1e461b78242 --output-dir <未作成先>`',
        '- `python 要点をまとめる.py` はその段階JSONから要点を再生成する。',
        '- `結果/診断の確認.json` は入力前後SHA/statと段階集計SHAを保存する。',
        '- `停止の確認.json` は人工、GEN不変、最終コード/要約/圧縮詳細の指紋を保存する。', '']
    return '\n'.join(lines)


def main() -> None:
    """
    機能: 既存集計から小型JSONと短報を生成する。
    引数: なし。返り値: None。
    """
    result = summarize(json.loads(DETAIL.read_text(encoding='utf-8')))
    (HERE/'結果/段階の要約.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    (HERE/'短期化で改善した段階と残った制限.md').write_text(render(result), encoding='utf-8')
    print(json.dumps({'success': True, 'candidate': result['候補数'], 'physical': result['物理取得数']}))


if __name__ == '__main__':
    main()
