"""146保存Sourceを場単位で読み、金融なしで短期パターンと物理取得を診断する。"""
from collections import Counter
from pathlib import Path
import argparse
import hashlib
import json

HERE = Path(__file__).resolve().parent
FAMILIES = ('A1', 'A3', 'B1', 'B3')


def file_sha(path: Path) -> str:
    """
    機能: 大型Sourceを複写せず固定サイズbufferでSHA確認する。
    引数: path(Path)。返り値: str。
    """
    h = hashlib.sha256()
    with path.open('rb') as handle:
        for body in iter(lambda: handle.read(1 << 20), b''): h.update(body)
    return h.hexdigest()


class SceneReader:
    """SourceのJSON topとscenesを順序を変えず場単位で読む。"""

    def __init__(self, path: Path):
        """
        機能: 入力参照とtop metadataを初期化する。
        引数: path(Path)。返り値: None。
        """
        self.path = path; self.top = {}

    def __iter__(self):
        """
        機能: 全Sourceを一括Dict化せずsceneごとにyieldする。
        引数: self(SceneReader)。返り値: Iterator[dict]。
        """
        decoder = json.JSONDecoder()
        with self.path.open('r', encoding='utf-8') as handle:
            buffer = ''; eof = False

            def fill() -> None:
                """
                機能: 次のUTF-8 JSON断片を追加する。
                引数: なし。返り値: None。
                """
                nonlocal buffer, eof
                body = handle.read(1 << 20); buffer += body; eof = not body

            def whitespace() -> None:
                """
                機能: token前の空白を除き必要な断片を読む。
                引数: なし。返り値: None。
                """
                nonlocal buffer
                while True:
                    buffer = buffer.lstrip()
                    if buffer or eof: return
                    fill()

            def token(character: str) -> None:
                """
                機能: 区切り文字を厳密に一つ消費する。
                引数: character(str)。返り値: None。
                """
                nonlocal buffer
                whitespace(); assert buffer.startswith(character), 'JSON区切り不正'
                buffer = buffer[len(character):]

            def node():
                """
                機能: 完全なJSON値を一つ読む。
                引数: なし。返り値: object。
                """
                nonlocal buffer
                whitespace()
                while True:
                    try: value, end = decoder.raw_decode(buffer)
                    except json.JSONDecodeError:
                        if eof: raise
                        fill(); continue
                    if end == len(buffer) and not eof:
                        fill(); continue
                    buffer = buffer[end:]; return value

            token('{'); first = True
            while True:
                whitespace()
                if buffer.startswith('}'): token('}'); break
                if not first: token(',')
                first = False; key = node(); assert isinstance(key, str); token(':')
                assert key not in self.top, 'top同名key重複'
                if key != 'scenes': self.top[key] = node(); continue
                self.top[key] = '場単位読取'; token('['); scene_first = True
                while True:
                    whitespace()
                    if buffer.startswith(']'): token(']'); break
                    if not scene_first: token(',')
                    scene_first = False; value = node(); assert isinstance(value, dict); yield value
            whitespace(); assert not buffer and eof, 'JSON末尾に追加内容'


def reference(bar: dict) -> dict:
    """
    機能: 保存短期足を同じRefへ写す。
    引数: bar(dict)。返り値: dict。
    """
    return {'id': bar['id'], 'width_seconds': bar['width_seconds'], 'end': bar['end'], 'delivered': bar['stamp']}


def val(fields: dict, key: str):
    """
    機能: unknownを0へ変えず値を読む。
    引数: fields(dict)、key(str)。返り値: number又はNone。
    """
    item = fields.get(key)
    return item['value'] if item and item['known'] else None


def counter_dict(counter: Counter) -> dict:
    """
    機能: 件数の降順で可読な集計を返す。
    引数: counter(Counter)。返り値: dict。
    """
    return dict(counter.most_common())


def new_family() -> dict:
    """
    機能: 異なる分母の累計を空で用意する。
    引数: なし。返り値: dict。
    """
    return {'checks': 0, 'context_checks': 0, 'status': Counter(), 'gates': {}, 'reasons': Counter(), 'combinations': Counter(),
            'window_causes': Counter(), 'p_context': Counter(), 'warmup': Counter(), 'events': Counter()}


def analyze_scene(scene: dict) -> dict:
    """
    機能: 正本足・判定・候補・groupを独立に結合して当場の非金融内訳を求める。
    引数: scene(dict)。返り値: dict。
    """
    assert scene['success'] and scene['raw_passes'] == 1 and scene['counts'] == scene['quality'] == scene['expected_quality']
    assert scene['actual_sha256'] == scene['raw']['sha256'] and scene['stat_before'] == scene['stat_after']
    all_bars = scene['bars']; by_id = {}; widths = {60: [], 180: []}; info = {}; latest_per_raw = {}
    bar_counts = {60: Counter(), 180: Counter()}; source_stats = scene['stats']
    unresolved = []
    for known in all_bars:
        b, context = known['bar'], known['context']; width = b['width_seconds']; assert width in widths and b['id'] not in by_id
        assert b['session'] == scene['session'] and b['contract'] == scene['contract']
        assert all(b['stamp'][k] == context['at'][k] for k in ('time', 'index', 'source_line'))
        assert b['end'] <= b['available_at'] <= b['stamp']['time']
        for r in context['refs'] or []:
            assert all(r['delivered'][k] <= context['at'][k] for k in ('time', 'index', 'source_line'))
        previous = widths[width][-1] if widths[width] else None
        if not b['price_known'] or not b['closed']: run, cause = 0, '価格未知又は未closed'
        elif previous is None: run, cause = 1, '場頭の履歴不足'
        elif previous['bar']['end'] != b['start']: run, cause = 1, '市場格子切断後'
        else:
            old = info[previous['bar']['id']]
            run, cause = (old['run']+1, old['cause']) if old['run'] else (1, '未知後の履歴再形成')
        info[b['id']] = {'index': len(widths[width]), 'run': run, 'cause': cause}
        widths[width].append(known); by_id[b['id']] = known
        key = (width, b['stamp']['time'], b['stamp']['index'], b['stamp']['source_line']); latest_per_raw[key] = b['id']
        counts = bar_counts[width]; counts['全配送足'] += 1; counts['価格known'] += bool(b['price_known']); counts['量known'] += bool(b['volume_known'])
        counts['既知量0'] += bool(b['volume_known'] and b['volume'] == 0)
        for name in ('ema8', 'ema21', 'atr', 'histogram', 'previous_histogram'):
            counts[name+'_known'] += bool(b['technical'][name]['known'])
    families = {f: new_family() for f in FAMILIES}
    checked_r = Counter()
    for ci, check in enumerate(scene['checks']):
        f = families[check['family']]; width = check['width_seconds']; f['checks'] += 1; f['status'][check['status']] += 1
        f['reasons'].update(set(check['reasons'])); f['combinations'][tuple(sorted(set(check['reasons'])))] += 1
        for name, value in check['gates'].items():
            count = f['gates'].setdefault(name, Counter()); count['未知' if not value['known'] else '成立' if value['value'] == 1 else '不成立'] += 1
        rid = check['r']['id']; known = by_id.get(rid)
        if known is None:
            unresolved.append({'locator': f"checks[{ci}].r", 'id': rid, 'reason': '正本足不在'}); continue
        r = known['bar']; assert reference(r) == check['r']
        assert all(r['stamp'][k] == check['at'][k] for k in ('time', 'index', 'source_line'))
        assert latest_per_raw[(width, r['stamp']['time'], r['stamp']['index'], r['stamp']['source_line'])] == rid
        checked_r[rid] += 1
        for used in check['used_refs']:
            pub = by_id.get(used['id'])
            if pub is None:
                unresolved.append({'locator': f"checks[{ci}].used_refs", 'id': used['id'], 'reason': '参照する短期/子足正本不在'}); continue
            assert reference(pub['bar']) == used
            assert all(used['delivered'][k] <= check['at'][k] for k in ('time', 'index', 'source_line'))
        need = 3 if check['family'][0] == 'A' else 5; run = info[rid]['run']
        assert check['gates']['当場連続形状窓']['value'] == int(run >= need)
        if run < need:
            f['window_causes'][info[rid]['cause']] += 1; continue
        f['context_checks'] += 1
        index = info[rid]['index']; p = widths[width][index-1]; o = widths[width][index-2]
        context = p['context']; fields = context['fields']
        assert p['bar']['end'] == r['start']
        for name in ('gap30', 'ema21_delta30', 'adx15', 'previous_adx15', 'adx_delta15', 'atr5'):
            if val(fields, name) is None: f['p_context'][name+'未知'] += 1
        if context['direction30'] == 0: f['p_context']['30方向d未定義'] += 1
        for w in (300, 900, 1800):
            if val(fields, 'price_known_'+str(w)) != 1: f['p_context'][str(w)+'価格又はfresh不足'] += 1
        if check['family'][0] == 'A' and val(fields, 'di_difference15') is None: f['p_context']['DI15差未知'] += 1
        roles = [('p', p, ('histogram',)), ('r', known, ('histogram', 'previous_atr'))]
        if check['family'][0] == 'A': roles.append(('o', o, ('ema8', 'ema21', 'histogram')))
        for role, pub, names in roles:
            for name in names:
                if not pub['bar']['technical'][name]['known']: f['warmup'][role+'_'+name+'未知'] += 1
    events = {e['id']: e for e in scene['events']}; assert len(events) == len(scene['events'])
    group_ids = set(); physical_rows = set(); memberships = Counter(); event_in_group = set(); group_status = Counter()
    for group in scene['groups']:
        assert group['id'] not in group_ids; group_ids.add(group['id']); group_status[group['status']] += 1
        candidates = [events[i] for i in group['candidate_ids']]
        assert all(e['group_id'] == group['id'] for e in candidates)
        event_in_group.update(e['id'] for e in candidates)
        if group['status'] != 'filled':
            assert group['entryQuote'] is None and not group['filled_candidate_ids']; continue
        filled = [events[i] for i in group['filled_candidate_ids']]; assert filled
        assert all(e['status'] == 'filled' and e['entryQuote'] == group['entryQuote'] and e['side'] == group['side'] for e in filled)
        representative = sorted(filled, key=lambda e: (-e['width_seconds'], e['family'][0], e['id']))[0]
        assert representative['id'] == group['representative_id']
        q = group['entryQuote']; key = (q['time'], q['index'], q['source_line']); assert key not in physical_rows; physical_rows.add(key)
        member = {e['width_seconds'] for e in filled}
        for w in member: memberships[str(w)] += 1
        if len(member) > 1: memberships['両width'] += 1
    for event in events.values():
        assert event['family'] in families and event['status'] != 'pending'
        families[event['family']]['events'][event['status']] += 1
        for role in ('arm', 'confirm'):
            r = event[role]; assert r['id'] in by_id and reference(by_id[r['id']]['bar']) == r
        assert event['id'] in event_in_group or event['status'] == 'suppressed'
    assert sum(1 for e in events.values() if e['status'] == 'filled') == sum(len(g['filled_candidate_ids']) for g in scene['groups'])
    hours = (scene['end']-300-scene['start'])/3600
    return {'session': scene['session'], 'contract': scene['contract'], 'hours': hours,
            'bars': {str(w): counter_dict(c) for w, c in bar_counts.items()}, 'family': families,
            '候補数': len(events), 'filled候補数': sum(e['status'] == 'filled' for e in events.values()),
            '物理取得数': len(physical_rows), 'membership': counter_dict(memberships), 'group_status': counter_dict(group_status),
            '複数filled候補の物理group数': sum(len(g['filled_candidate_ids']) > 1 for g in scene['groups']),
            '不一致参照': unresolved, 'Source統計': source_stats,
            '原板指紋': {'path': scene['raw']['path'], 'sha256': scene['actual_sha256'], 'stat': scene['stat_before']}}


def serialize_family(value: dict) -> dict:
    """
    機能: tuple複合理由とCounterをJSON向けに変換する。
    引数: value(dict)。返り値: dict。
    """
    return {'判定数': value['checks'], 'pContext及び短期値の判別分母': value['context_checks'], 'status': counter_dict(value['status']),
            '個別gate': {k: {'分母': sum(v.values()), **counter_dict(v)} for k, v in value['gates'].items()},
            '理由別_非排他的': counter_dict(value['reasons']),
            '理由の組': [{'理由': list(k), '件数': n} for k, n in value['combinations'].most_common()],
            '形状窓不足の背景': counter_dict(value['window_causes']), 'pContext不足_非排他的': counter_dict(value['p_context']),
            '短期数値不足_非排他的': counter_dict(value['warmup']), '候補status': counter_dict(value['events'])}


def diagnose(reader) -> dict:
    """
    機能: 全73場とfamily/widthを維持して足/候補/物理取得の分母を集計する。
    引数: reader(SceneReader又は人工互換)。返り値: dict。
    """
    sessions = []; per_scene = []; total = {f: new_family() for f in FAMILIES}; bars = {'60': Counter(), '180': Counter()}; statuses = Counter(); membership = Counter()
    for scene in reader:
        row = analyze_scene(scene); sessions.append(row['session'])
        for f in FAMILIES:
            src, dst = row['family'][f], total[f]; dst['checks'] += src['checks']; dst['context_checks'] += src['context_checks']
            for key in ('status', 'reasons', 'combinations', 'window_causes', 'p_context', 'warmup', 'events'): dst[key].update(src[key])
            for key, count in src['gates'].items(): dst['gates'].setdefault(key, Counter()).update(count)
            row['family'][f] = serialize_family(src)
        for w in bars: bars[w].update(row['bars'][w])
        statuses.update(row['group_status']); membership.update(row['membership']); per_scene.append(row)
    top = reader.top
    assert top['success'] and top['trial'] == 146 and not top['financial_labels_used'] and not top['source_positions_used']
    assert len(sessions) == len(set(sessions)) == 73 and sessions == sorted(sessions)
    candidate_count = sum(r['候補数'] for r in per_scene); fills = sum(r['物理取得数'] for r in per_scene); filled_candidates = sum(r['filled候補数'] for r in per_scene)
    assert candidate_count == top['summary']['候補数'] and fills == top['summary'].get('物理取得数', 0) and filled_candidates == top['summary'].get('filled候補数', 0)
    hours = sum(r['hours'] for r in per_scene)
    return {'成功': True, '試行': 146, '全場数': 73, '全足_実配送': {w: counter_dict(c) for w, c in bars.items()},
            'family': {f: serialize_family(v) for f, v in total.items()}, '候補数': candidate_count,
            'filled候補数': filled_candidates, '物理取得数': fills, 'membership_物理群': counter_dict(membership),
            'group_status': counter_dict(statuses), '取得場数': sum(r['物理取得数'] > 0 for r in per_scene),
            '未取得場': [r['session'] for r in per_scene if r['物理取得数'] == 0],
            'hours': hours, '物理平均毎h': fills/hours, '全73場': per_scene,
            '未解決参照': [{'session': r['session'], **x} for r in per_scene for x in r['不一致参照']],
            '限界': ['新Sourceだけの取得/頻度。旧C1/unionを加算していない。', 'foot数/最新rチェック数/候補数/filled候補数/物理数は別分母。',
                     'M1/M3の重複所属を独立な取引として加算しない。', '個別否定と複合理由は非排他的。未知をfalse/0へ埋めない。',
                     '参照不足は当該locatorで保存。入力122へ追補する場合は別許可/別出力とし将来のknown足を使わない。',
                     '金融・Raw・CSV追加読取・新条件採用は行っていない。']}


def main() -> None:
    """
    機能: Root完成通知後のSourceを指定SHAで場単位診断する。
    引数: CLIのsource/sha256/output-dir(str)。返り値: None。
    """
    parser = argparse.ArgumentParser(); parser.add_argument('--source', required=True); parser.add_argument('--sha256', required=True); parser.add_argument('--output-dir', required=True)
    args = parser.parse_args(); source = Path(args.source); target = Path(args.output_dir); assert not target.exists()
    assert len(args.sha256) == 64 and all(c in '0123456789abcdef' for c in args.sha256)
    before = source.stat(); assert file_sha(source) == args.sha256
    result = diagnose(SceneReader(source))
    assert source.stat().st_size == before.st_size and source.stat().st_mtime_ns == before.st_mtime_ns and file_sha(source) == args.sha256
    result['Source参照'] = {'path': str(source), 'sha256': args.sha256, 'bytes': before.st_size, 'mtime_ns': before.st_mtime_ns}
    target.mkdir(parents=True); output = target/'全73場の短期パターン段階.json'; output.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    proof = {'成功': True, '試行': 146, '非金融': True, 'Source参照': result['Source参照'],
             'コードSHA256': file_sha(Path(__file__)), '出力SHA256': file_sha(output),
             '原板_CSV_金融_追加2場読取': False, '元Source変更': False, '新条件採用': False}
    p = target/'診断の確認.json'; p.write_text(json.dumps(proof, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'success': True, 'proof_sha256': file_sha(p), 'candidates': result['候補数'], 'physical_fills': result['物理取得数'], 'unresolved': len(result['未解決参照'])}, ensure_ascii=True))


if __name__ == '__main__':
    main()
