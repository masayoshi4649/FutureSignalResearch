"""146の正式結果表とSource節を保存正本から別読取で照合する。"""

from pathlib import Path
import hashlib
import json
import re

ROOT=Path(__file__).resolve().parents[2]
OWN=Path(__file__).resolve().parent
FORMAL=ROOT/'study/00146_短期構造の完成パターンで入口を増やす'
POLICIES=('U0','P0','M1','M3','C1','C0','RU')


def checksum(path: Path) -> str:
    """
    機能: 保存内容の現在指紋を取得する。
    引数: path (Path) は確認対象。
    返り値: str はSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(text: str) -> list[list[str]]:
    """
    機能: Markdown表の行をセルへ分ける。
    引数: text (str) は本文。
    返り値: list[list[str]] は前後の空セルを除いた表行。
    """
    return [line.split('|')[1:-1] for line in text.splitlines() if line.startswith('|')]


def check_policy(section: str, values: dict, detailed: bool) -> int:
    """
    機能: 文書表を別に解析し、件数・率・利益損失の保存値と比較する。
    引数: section (str)、values (dict)、detailed (bool) は表本文/政策集計/三率指定。
    返り値: int は一致した数値要素数。
    """
    result=0
    selected=[row for row in rows(section) if row[0] in POLICIES and re.fullmatch(r'\d+ / \d+',row[1])]
    assert len(selected)==7
    for row in selected:
        value=values[row[0]]['BBO']['3600']['125']
        assert [int(x) for x in row[1].split('/')] == [value['entries'],value['sessions']]
        assert [int(x) for x in row[2].split('/')] == [value[k] for k in ('forward','adverse','neither','censored')]
        pairs=[(value['forward'],value['resolved'])]
        if detailed:pairs.extend([(value['forward'],value['complete']),(value['forward'],value['entries'])])
        for i,(numerator,denominator) in enumerate(pairs,3):
            expected='—（分母0）' if not denominator else f'{numerator/denominator:.2%}'
            assert row[i]==expected
        money_start=6 if detailed else 4
        keys=('ifd_net5_profit','ifd_net5_loss','ifd_net5_sum','ifd_unknown')
        for cell,key in zip(row[money_start:],keys,strict=True):
            assert (None if cell=='—' else int(cell.replace(',','')))==value[key]
        result+=13 if detailed else 11
    return result


def main() -> None:
    """
    機能: 三文書の表・Source節・保持領域・リンクを確認して停止する。
    引数: なし。新金融・Raw・価格CSVを再計算しない。
    返り値: None。最終SHAと照合範囲をJSONへ保存する。
    """
    report=json.loads((OWN/'文書反映の確認.json').read_bytes())
    source=Path(ROOT/'work/146短期パターンの非金融診断/短期化で改善した段階と残った制限.md').read_text(encoding='utf-8')
    summary=json.loads((ROOT/'work/146短期完成の評価/金融評価/集計.json').read_bytes())
    readme=(FORMAL/'README.md').read_text(encoding='utf-8')
    settings=(FORMAL/'設定と結果.md').read_text(encoding='utf-8')
    all_section=readme.split('## 実行結果\n',1)[1].split('### 前48場',1)[0]
    train=readme.split('### 前48場',1)[1].split('### 後25場',1)[0]
    validation=readme.split('### 後25場',1)[1].split('## 状態遷移と次の問い',1)[0]
    result_checks=check_policy(all_section,summary['集計']['all'],True)
    result_checks+=check_policy(train,summary['集計']['train'],False)
    result_checks+=check_policy(validation,summary['集計']['validation'],False)
    result_checks+=check_policy(settings.split('## 固定後の実行結果',1)[1],summary['集計']['all'],True)

    # ----------------------------------------
    # 説明順の累積と排他的後段を混同せず、停止短報の元値を確認する。
    source_checks=0
    for family in ('A1','A3','B1','B3'):
        original=next(row for row in rows(source) if row[0]==family and len(row)==8)
        actual=next(row for row in rows(readme) if row[0]==family and len(row)==8)
        assert [int(x.replace(',','')) for x in actual[1:]]==[int(x) for x in original[1:]]
        source_checks+=7
        cumulative=next(row for row in rows(source) if row[0]==family and len(row)==9)
        found=re.search(family+r'は([\d,→]+)',readme).group(1)
        assert [int(x.replace(',','')) for x in found.split('→')]==[int(x) for x in cumulative[1:]]
        source_checks+=8
    normalize=lambda value:value.replace(',','').replace(' ','').replace('（','(').replace('）',')')
    for width in ('60秒','180秒'):
        original=next(row for row in rows(source) if row[0]==width)
        actual=next(row for row in rows(readme) if row[0]==width)
        assert [normalize(x) for x in actual[1:]]==[normalize(x) for x in original[1:5]]
        source_checks+=4

    # ----------------------------------------
    # 編集範囲を三文書に限定し、元条件と共有源の指紋を保持する。
    for row in report['保護対象前後同体']:
        assert checksum(ROOT/row['path'])==row['sha256']
    for row in report['成果物']:
        assert checksum(ROOT/row['path'])==row['sha256']
    links=0
    missing=[]
    for name in ('README.md','条件.md','設定と結果.md'):
        path=FORMAL/name
        for target in re.findall(r'\]\(([^)]+)\)',path.read_text(encoding='utf-8')):
            target=target.split('#',1)[0]
            if target and '://' not in target:
                if not (path.parent/target).resolve().exists():missing.append((name,target))
                links+=1
    assert not missing,missing
    proof={'成功':True,'試行':146,'状態':'正式結果三文書を停止','正式3MD':report['成果物'],
        '文書反映SHA256':checksum(OWN/'文書反映の確認.json'),'更新器SHA256':checksum(OWN/'更新する.py'),
        '確認器SHA256':checksum(Path(__file__)),'結果草稿SHA256':checksum(OWN/'結果草稿.md'),
        'Source要点SHA256':checksum(OWN/'Source要点.md'),'金融表の数値要素照合':result_checks,
        '停止Source短報との数値要素照合':source_checks,'元条件prefix/513セル保持':True,
        '保護対象ファイル数':len(report['保護対象前後同体']),'保護対象前後同体':True,
        'ローカルリンク実在':links,'主/条件/取得集合の結果後変更':False,
        'Docs目次閲覧資料編集':False,'金融Source再実行':False,'RawCSV追加2場読取':False}
    raw=(json.dumps(proof,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    (OWN/'停止の確認.json').write_bytes(raw)
    print(json.dumps({'proof_sha256':hashlib.sha256(raw).hexdigest(),'result_fields':result_checks,'source_fields':source_checks,'links':links}))


if __name__=='__main__':
    main()
