"""146の元条件・513セルを保ち、保存された実行結果を正式三文書へ追記する。"""

from pathlib import Path
import argparse
import gzip
import hashlib
import json
import re

ROOT=Path(__file__).resolve().parents[2]
OWN=Path(__file__).resolve().parent
FORMAL=ROOT/'study/00146_短期構造の完成パターンで入口を増やす'
SUMMARY=ROOT/'work/146短期完成の評価/金融評価/集計.json'
TABLES=ROOT/'work/146短期完成の評価/金融評価/CSV用の表.json'
SUMMARY_SHA='70f1d57cd22febfba8c7cfe9515f633077b0f5a3bd9fe16e0c8278d8a1458d2d'
TABLES_SHA='fdda133a0ea3ad5f561db9cd19416b17592b0aec981a612ddde068ea57dd79a2'
BACKUP_SHA='18970d51857a19c8d6f1828244542a4ca5f2a7f7e389abc9ba773473f5ff4b77'
SOURCE_REPORT=ROOT/'work/146短期パターンの非金融診断/短期化で改善した段階と残った制限.md'
SOURCE_REPORT_SHA='16c506560f30ff6d3e822c7ed04ed196c62e19105b3c119d01f84bb57aa14769'
POLICIES=('U0','P0','M1','M3','C1','C0','RU')


def fingerprint(path: Path) -> dict:
    """
    機能: 保存bytesのサイズと指紋を取得する。
    引数: path (Path) は既存ファイル。
    返り値: dict は相対パス/bytes/sha256。
    """
    raw=path.read_bytes()
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def percent(value: float | None) -> str:
    """
    機能: 率の分母0を数値0と分けて表示する。
    引数: value (float | None) は保存率。
    返り値: str は百分率又は分母0の説明。
    """
    return '—（分母0）' if value is None else f'{value:.2%}'


def money(value: int | None) -> str:
    """
    機能: 金額の対象0件/既知0件を0円へ補完しない。
    引数: value (int | None) は保存済み金額。
    返り値: str は円整数又は未集計の記号。
    """
    return '—' if value is None else f'{value:,}'


def table(data: dict, scope: str, detailed: bool) -> str:
    """
    機能: 政策ごとの取得集合を混ぜずBBO/H60/125を表にする。
    引数: data (dict)、scope (str)、detailed (bool) は正本・区分・三分母の表示指定。
    返り値: str は七政策のMarkdown表。
    """
    heading='|政策|取得/取得場|順/逆/未到達/不足|到達済み率|'
    if detailed:heading+='H完了分母率|全取得分母率|'
    heading+='C5利益円|C5損失円|C5既知差引円|金額未知件|\n'
    result=heading+'|'+'|'.join(['---']*(10 if detailed else 8))+'|\n'
    for policy in POLICIES:
        value=data['集計'][scope][policy]['BBO']['3600']['125']
        values=[policy,f"{value['entries']} / {value['sessions']}",
                '/'.join(str(value[k]) for k in ('forward','adverse','neither','censored')),
                percent(value['resolved_rate'])]
        if detailed:
            values.extend([percent(value['complete_rate']),percent(value['forward']/value['entries'] if value['entries'] else None)])
        values.extend([money(value['ifd_net5_profit']),money(value['ifd_net5_loss']),money(value['ifd_net5_sum']),str(value['ifd_unknown'])])
        result+='|'+'|'.join(values)+'|\n'
    return result


def cause_section() -> str:
    """
    機能: 停止済みSource診断から用意した原因節だけを取り込む。
    引数: なし。結果文書専有workの要点を参照する。
    返り値: str は確定済み原因節、未準備なら草稿用の明示。
    """
    path=OWN/'Source要点.md'
    if path.exists():
        assert fingerprint(SOURCE_REPORT)['sha256']==SOURCE_REPORT_SHA
        return path.read_text(encoding='utf-8')
    return 'Sourceの停止診断を確認後に原因節を追記する。自然Source・Rawを本更新器で走査しない。\n'


def result_section(data: dict) -> str:
    """
    機能: 指定正本の主結果・七政策・前後・保存境界を草稿へ組み立てる。
    引数: data (dict) はSHA確認済み146集計。
    返り値: str は現在結果のMarkdown。
    """
    return '''## 実行結果

全73場の自然Source・固定取得・実BBO正逆観測・420比較を実行した。主U0は113取得/全73場参加、49順/31逆/25未到達/8全H不足、到達済み49/80＝61.25%。H完了分母49/105＝46.67%、全取得分母49/113＝43.36%である。**全場最低1は達成したが、70%と平均概ね1件/時は未達。共同目標未達で、この入口拡張を採用達成とはしない。**

''' + table(data,'all',True) + '''
主U0のC5利益641,380円/損失553,850円、既知差引+87,530円（PF約1.16）、110件既知/3件未知。追加滑り0の費用条件では+197,530円。独立mini1枚100円/pt、往復税込77円、C5は追加往復10pt＝1,000円を控除した入口IFD代用であり、片側10枚・同時保有・資金制約・実IFD・利益追尾を備えた口座収支ではない。全H不足8と金額未知3は別で、H不足でも既知touchをIFD既知にできる。Last金額nullを0円へ補完しない。

旧145の全87をC1として保持し、旧81だけのC0はそのsubsetで二重加算していない。C1は42順/18逆/21未到達/6不足＝70.00%、C5既知差引+210,532円で旧145同体。新P0の26取得は7順/13逆/4未到達/2不足＝35.00%、C5利益96,384円/損失219,386円/既知差引−123,002円で、追加した取引が主の率と既知収支を下げた。利益を得た新入口だけを残す選別はしない。

M1は1分所属20取得/17場・40.00%、M3は3分所属6取得/4場・20.00%。M1/M3は所属であり独立な二標本とは扱わない。今回両幅所属は0、旧C1と新P0の同原行alias重複も0で、物理U0=87+26=113だった。Source候補数や同groupの構成員を回数へ水増ししていない。旧C0全81/4stream/60条件、旧C1全87/4stream/60条件の同体を確認した。

RUは旧C1も含むU0全113件を同時点の実BBO反対側で診断し、25順/63逆/17未到達/8不足＝28.41%、C5利益371,305円/損失959,775円/既知差引−588,470円。これは新P0単独の反転ではない。1−61.25%や1−35%で反対率を作らず、RUの主交換も行っていない。

全時間の分母はΣ(scene.end−300−scene.start)＝720時間55分。U0の113/720.9167＝0.15674488498439487件/時は、旧C1の0.12068件/時から増えたが、概ね1件/時へ届かない。新P0単独は0.03607件/時・20/73場で、未取得53場も残す。全場参加は旧C1を保護したunionとしての結果で、新stream単独で満たしたものではない。

### 前48場

''' + table(data,'train',False) + '''
### 後25場

''' + table(data,'validation',False) + '''
表の金額「—」は取得0件で金額を集計しない欄で、0円とは異なる。前48の主U0は33/18/20/5＝64.71%、C5既知差引+110,302円・未知2。後25は16/13/5/3＝55.17%、−22,772円・未知1。全期既使用で、前48/後25は記述区分であり、後25を独立未知期や今回の未使用検証とは呼ばない。

## 状態遷移と次の問い

''' + cause_section() + '''
## 閲覧・再現・限界

正本は[集計](成果物/集計.json)。全件は[全セッションCSV](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/146_短期完成パターン/全セッション.csv)、[420条件CSV](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/146_短期完成パターン/正逆比較.csv)、[基礎113入口CSV](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/146_短期完成パターン/入口別診断.csv)へ進む。Rootの別算術は420比較/10,080主要統計セルを照合済みで、CSVの確認状況は保存記録へ分けて残す。xlsxは生成しない。

Source・固定取得・参照metadataは[恒久入力](../../inputs/00146_短期構造の入口/)へ各一度だけgzip保存する。保存元は[Source](../../inputs/00146_短期構造の入口/Sourceの出生と取得.json.gz)、[固定取得入力](../../inputs/00146_短期構造の入口/固定取得入力.json.gz)、[入口参照](../../inputs/00146_短期構造の入口/入口参照.json.gz)。F0/F1の実行前文書・固定コード・正逆観測からの再集計は[保管索引](保管索引.json)と[再現手順](再現手順.md)を参照する。Raw/大入力の不要な重複生成を避ける。

結果後に採用条件・背景ADX・幅・cap・足幅・未知処置・取得集合を変更していない。短期化・Iの定義・認識方式・数値助走を同時に変えた複合評価で、時計又は指標単独の効果としない。mini実板・実receivedAt・反転側の注文適格性再構築・実IFD/必須利益追尾・片側10枚口座の収支は未検証。追加2場の価格も未読を維持する。
'''


def main() -> None:
    """
    機能: 草稿を作り、適用指定時だけ退避済みの正式三文書へ結果を反映する。
    引数: CLI --mode (str) は草稿又は適用。
    返り値: None。条件prefixと513セルを保持し、Source/金融/旧145/目次は編集しない。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--mode',choices=('草稿','適用'),default='草稿');args=parser.parse_args()
    assert fingerprint(SUMMARY)['sha256']==SUMMARY_SHA and fingerprint(TABLES)['sha256']==TABLES_SHA
    data=json.loads(SUMMARY.read_bytes());assert data['試行']==146 and data['主政策']=='U0'
    assert data['取得集合数']=={'C0':81,'C1':87,'M1':20,'M3':6,'P0':26,'U0':113}
    assert not data['主評価']['三項目すべて達成']
    draft=result_section(data)
    (OWN/'結果草稿.md').write_text('# 146・正式結果の草稿\n\n'+draft,encoding='utf-8',newline='\n')
    if args.mode=='草稿':
        print(json.dumps({'draft_sha256':fingerprint(OWN/'結果草稿.md')['sha256'],'formal_changed':False}));return
    assert (OWN/'Source要点.md').exists(),'Source停止診断の節を先に用意する'
    backup=FORMAL/'検査/F1原文と増分の保管確認.json';assert fingerprint(backup)['sha256']==BACKUP_SHA
    snapshot=json.loads(gzip.decompress((FORMAL/'検査/F1実行前文書.json.gz').read_bytes()))
    stored={item['path'].replace('\\','/'):item for item in snapshot['文書']}
    original={}
    for name in ('README.md','条件.md','設定と結果.md'):
        path=FORMAL/name;item=stored[path.relative_to(ROOT).as_posix()];raw=item['本文'].encode('utf-8')
        assert hashlib.sha256(raw).hexdigest()==item['sha256']
        original[name]=raw
    protected=[SUMMARY,TABLES,ROOT/'work/146_短期完成パターン入口の採用仕様.md',
        ROOT/'work/146短期groupと旧87を固定取得へ渡す.py',ROOT/'work/146出生と金融を分離して実行する.py',
        ROOT/'work/146短期構造の金融集計/集計する.py',ROOT/'work/146短期完成の評価/固定入力/固定取得入力.json',
        ROOT/'work/146短期完成の評価/固定入力/入口参照.json']
    protected += [p for p in (ROOT/'work/146短期構造の入口').rglob('*') if p.is_file() and p.suffix in ('.go','.mod','.exe')]
    protected += list((ROOT/'study/00145_押戻し完了と失敗突破を別の構造イベントで評価する').glob('*.md'))
    before=[fingerprint(p) for p in protected]
    readme=original['README.md'].decode('utf-8')
    readme=readme.replace('試行00146。2026-11-12、完全仕様の正式準備。Source実装・事前人工の完了前で、自然生成・新出生/取得・率/損益は未実行。旧145全87をC1として保持し、新しい1分/3分の物理取得P0とのunion U0を主として事前固定する。',
        '試行00146。2026-11-12、全73場の自然生成・実取得・正逆観測と420比較を実行した。旧C1全87を保持し、新P0の26物理取得を足した主U0は113取得・先着61.25%・平均0.15674件/時。全場参加は達成、70%と頻度は未達で共同目標未達。')
    readme=readme.replace('新数値は未生成。','新数値は下の実行結果へ追記した。')
    readme=readme.replace('Source実装人工・入力SHA結合・新件数・先着率・損益を完了したとは主張しない。',
        'Sourceの作者16＋独立状態4群、別数値数学の独立確認、入力SHA結合と自然全73場・保存正逆の420比較を実行した。F0/F1の実行前正式原文は退避し、元条件は変更していない。')
    (FORMAL/'README.md').write_text(readme.rstrip()+'\n\n'+draft,encoding='utf-8',newline='\n')
    condition_note='''

## 固定後の実行案内

上記はF0/F1固定時の採用条件・review・未実行の記録を保持した本文であり、現在の未実行宣言ではない。自然全73場、取得、実正逆420比較とRoot別算術照合を完了。主U0は113取得、49順31逆25未到達8不足、到達済み61.25%・平均0.15674件/時で70%と頻度は未達、全場最低1のみ達成した。[実行結果](README.md#実行結果)を参照する。

採用数式・背景・初Context・構造I/cap・厳密3本・物理/所属・時計・取得集合は結果後に変更していない。元条件本文と513セル、実行前3MDをF0/F1 snapshotへ保持し、追記後の文書を実行前と同一SHAとは扱わない。workパスは実行時識別名であり、恒久保存との対応は[保管索引](保管索引.json)と[再現手順](再現手順.md)に記録する。
'''
    (FORMAL/'条件.md').write_bytes(original['条件.md']+condition_note.encode('utf-8'))
    note=('> 現在は実行済み。主U0は113取得・先着61.25%・平均0.15674件/時で共同目標未達。'
          '以下の準備/未実行表はF0/F1時点の原文記録であり、現在結果は末尾の[固定後の実行結果](#固定後の実行結果)へ追記した。\n\n').encode('utf-8')
    raw=original['設定と結果.md'];boundary=raw.index(b'\n',raw.index(b'\n')+1)+1
    tail='\n\n## 固定後の実行結果\n\n全73場/実BBO/H60/同幅±125、146E01の現在結果。上の513セル・設定ID・未実行表はF0/F1原文を保持する。\n\n'+table(data,'all',True)+'\n'
    tail+='主は49/80＝61.25%、H完了49/105＝46.67%、全取得49/113＝43.36%。全場最低1だけ達成、70%と平均概ね1件/時は未達で共同目標未達。旧C1全87とC0subset全81は同体。新P0は26取得・35.00%・C5既知差引−123,002円で、主の率と既知収支を下げた。M1/M3は所属で、実行で両幅所属0でも一般に独立標本へ加算しない。\n\n'
    tail+='独立mini1枚100円/pt、往復77円、C5追加1,000円、Last金額null。主110件既知/3件未知と全H不足8は区別。複合評価を単独指標の効果や利益追尾/口座収支へ読み替えない。前後区分・funnel・恒久保存・CSVは[実行結果](README.md#実行結果)を参照する。\n'
    (FORMAL/'設定と結果.md').write_bytes(raw[:boundary]+note+raw[boundary:]+tail.encode('utf-8'))
    assert (FORMAL/'条件.md').read_bytes().startswith(original['条件.md'])
    assert (FORMAL/'設定と結果.md').read_bytes().replace(note,b'',1).startswith(original['設定と結果.md'])
    rows=lambda text:[line for line in text.splitlines() if re.match(r'^\| [A-Z]\d{2} \|',line)]
    oldrows=rows(original['設定と結果.md'].decode('utf-8'));newrows=rows((FORMAL/'設定と結果.md').read_text(encoding='utf-8'))
    assert oldrows==newrows and len(oldrows)==57 and all(len(line.split('|')[3:-1])==9 for line in oldrows)
    assert [fingerprint(p) for p in protected]==before
    proof={'成功':True,'試行':146,'状態':'正式三文書の結果反映を停止','F1原文退避SHA256':BACKUP_SHA,
        '成果物':[fingerprint(FORMAL/name) for name in ('README.md','条件.md','設定と結果.md')],
        '指定正本':[fingerprint(SUMMARY),fingerprint(TABLES),fingerprint(SOURCE_REPORT)],'条件prefix完全同体':True,'設定注記以外元原文prefix同体':True,
        '汎用表':{'版':7,'手法':57,'尺度':9,'セル':513,'全行文字同体':True},'保護対象前後同体':before,
        '目次閲覧資料編集':False,'Source金融再計算':False,'RawCSV追加2場読取':False,
        '更新器SHA256':fingerprint(Path(__file__))['sha256'],'Source節SHA256':fingerprint(OWN/'Source要点.md')['sha256']}
    (OWN/'文書反映の確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps({'formal':[x['sha256'] for x in proof['成果物']],'proof_sha256':fingerprint(OWN/'文書反映の確認.json')['sha256']}))


if __name__=='__main__':
    main()
