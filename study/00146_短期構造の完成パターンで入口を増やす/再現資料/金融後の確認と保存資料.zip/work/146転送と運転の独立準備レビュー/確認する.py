"""146の橋渡しと運転順を、自然入力を読まず人工fixtureだけで確認する。"""

from pathlib import Path
import ast
import copy
import hashlib
import importlib.util
import json
import runpy

ROOT=Path(__file__).resolve().parents[2]
OWN=Path(__file__).resolve().parent
BRIDGE=ROOT/'work/146短期groupと旧87を固定取得へ渡す.py'
TEST=ROOT/'work/146転送の人工検査.py'
DRIVER=ROOT/'work/146出生と金融を分離して実行する.py'


def info(path: Path) -> dict:
    """
    機能: レビューしたコードのSHAとサイズを保存する。
    引数: path (Path) は確認対象のコード。
    返り値: dict はパス/sha256/bytes。
    """
    raw=path.read_bytes()
    return {'path':path.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}


def main() -> None:
    """
    機能: Root人工14群と独立5群、F0/F1順序を確認する。
    引数: なし。Rootの自然CLI mainは実行しない。
    返り値: None。コード前後同体と純粋な接続検査を保存する。
    """
    before=[info(p) for p in (BRIDGE,TEST,DRIVER)]
    module=runpy.run_path(str(TEST),run_name='人工fixtureだけ')
    module['main']()
    bridge=module['m'];fixture=module['fixture']
    checks=[]
    fixed,meta,source=fixture()
    untouched=copy.deepcopy((fixed,meta,source))
    f,r=bridge.build(fixed,meta,source)
    assert (fixed,meta,source)==untouched
    checks.append('入力三辞書の非改変')

    # ----------------------------------------
    # groupの片幅だけ通った場合に、適格所属を推定しないことを確認する。
    fixed,meta,source=fixture()
    for scene in source['scenes']:
        one,three=scene['events'];three['status']='entry_position_rejected';three['entryQuote']=None
        group=scene['groups'][0];group['filled_candidate_ids']=[one['id']];group['representative_id']=one['id']
    _,r=bridge.build(fixed,meta,source)
    assert all(e['widths']==[60] and len(e['origins'])==1 for e in r['entries'] if e['model']=='P0')
    checks.append('片widthのみ実P適格ならその所属だけ保持')

    # ----------------------------------------
    # C1は旧C0だけへ縮めず、旧A/Bも全値を残す。
    fixed,meta,source=fixture()
    old=meta['entries'][1];old['model']='A0';old['baseline']=False;old['id']='旧A0の人工取得'
    fixed['scenes'][1]['entries'][0]['id']=old['id']
    _,r=bridge.build(fixed,meta,source)
    c1=[e for e in r['entries'] if e['model']=='C1']
    assert len(c1)==2 and sum(e['baseline'] for e in c1)==1
    assert next(e for e in c1 if e['legacy_model']=='A0')['id']==old['id']
    checks.append('旧A0取得をC1へ保持しC0subsetと分離')

    # ----------------------------------------
    # p/rが別indexでも同時刻なら厳密配送順を満たさない。
    fixed,meta,source=fixture();scene=source['scenes'][0]
    scene['bars'][0]['bar']['stamp']['time']=scene['bars'][1]['bar']['stamp']['time']
    scene['bars'][0]['context']['at']['time']=scene['bars'][0]['bar']['stamp']['time']
    scene['events'][0]['arm']['delivered']['time']=scene['bars'][0]['bar']['stamp']['time']
    try:bridge.build(fixed,meta,source)
    except AssertionError:pass
    else:raise AssertionError('別index/同時刻p/rを拒否しない')
    checks.append('別indexでも同時刻p/rは拒否')

    # ----------------------------------------
    # W=125/cap0は実P/LastがKちょうどなら等号を許す。
    fixed,meta,source=fixture()
    for i,scene in enumerate(source['scenes']):
        group=scene['groups'][0]
        for quote in (group['birth'],group['entryQuote']):quote.update({'last':120,'bid':115,'ask':120})
        for bar in scene['bars']:
            if '/p/' in bar['bar']['id']:bar['bar']['ohlc']['low']=5
        for event in scene['events']:
            event['birth'].update(group['birth']);event['entryQuote'].update(group['entryQuote']);event['entry_price']=120
            event['structure'].update({'i':-5,'width':125,'cap':0})
        if i==0:
            fixed['scenes'][i]['entries'][0]['entry'].update(group['entryQuote'])
            meta['entries'][i]['entry_quote'].update(group['entryQuote'])
    _,r=bridge.build(fixed,meta,source)
    assert len([e for e in r['entries'] if e['model']=='P0'])==2
    checks.append('構造125/cap0のLastと実P等号を許可')

    # ----------------------------------------
    # 静的に運転順・旧固定・独立算術の事前固定を確認する。
    text=DRIVER.read_text(encoding='utf-8')
    assert "--execute-after-f0" in text and "'--workers','1'" in text
    assert "146金融を別算術で確認する.py" in text and "141金融集計を独立に確認する.py" in text
    assert "helper.verify(frozen)" in text and "helper.verify(finance)" in text
    assert "'主':'U0=旧145全87(C1)＋新物理group(P0)、同原行C1優先'" in text
    for path in (BRIDGE,TEST,DRIVER):ast.parse(path.read_text(encoding='utf-8'))
    assert before==[info(p) for p in (BRIDGE,TEST,DRIVER)]
    proof={'成功':True,'試行':146,'状態':'金融前の純接続レビューを停止','Root人工主群':14,
           '独立人工主群':len(checks),'独立人工':checks,'構文確認':3,'前後同体':before,
           '静的review':'C1全値copy/C0subset・group物理1/filledだけ所属・p/r/Context/ATR5/K/I/実P/TTL・F0→Source→固定→F1→観測/集計と独立算術2源を確認。',
           'Source自然RawCSV金融追加2場読取':False,'Rootコード編集':False,
           '本確認器SHA256':info(Path(__file__))['sha256']}
    raw=(json.dumps(proof,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    (OWN/'準備の確認.json').write_bytes(raw)
    print(json.dumps({'proof_sha256':hashlib.sha256(raw).hexdigest(),'independent':len(checks)},ensure_ascii=True))


if __name__=='__main__':
    main()
