// 人工Minuteだけを公開NewShortへ通し、標準式との比較用に公開票を保存します。
package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"os"

	short "shortpattern146"
)

type minuteInput struct {
	Deliver bool         `json:"deliver"`
	Minute  short.Minute `json:"minute"`
}
type sessionInput struct {
	ID       string        `json:"id"`
	Contract string        `json:"contract"`
	Start    float64       `json:"start"`
	End      float64       `json:"end"`
	Carry    bool          `json:"carry"`
	Minutes  []minuteInput `json:"minutes"`
}
type example struct {
	ID       string         `json:"id"`
	Sessions []sessionInput `json:"sessions"`
}
type outputSession struct {
	ID      string           `json:"id"`
	Bars    []short.ShortBar `json:"bars"`
	Stats   map[string]int   `json:"stats"`
	Skipped int              `json:"undelivered"`
}
type outputExample struct {
	ID       string          `json:"id"`
	Sessions []outputSession `json:"sessions"`
}

// run は人工入力を公開APIへ渡し、内部状態を読まず結果票だけを保存します。
//
// 引数: input/output(string)は人工JSONと未作成出力のpathです。
// 返り値: error は読み込み・公開API・保存の異常です。
func run(input, output string) error {
	raw, err := os.ReadFile(input)
	if err != nil {
		return err
	}
	var suite []example
	if err = json.Unmarshal(raw, &suite); err != nil {
		return err
	}
	result := []outputExample{}
	for _, item := range suite {
		tracker := short.NewShort()
		current := outputExample{ID: item.ID, Sessions: []outputSession{}}
		for _, scene := range item.Sessions {
			if err = tracker.StartSession(scene.ID, scene.Contract, scene.Start, scene.End, scene.Carry); err != nil {
				return err
			}
			s := outputSession{ID: scene.ID, Bars: []short.ShortBar{}}
			for _, m := range scene.Minutes {
				if !m.Deliver {
					s.Skipped++
					continue
				}
				bars, addErr := tracker.Add(m.Minute)
				if addErr != nil {
					return fmt.Errorf("人工%s/%s: %w", item.ID, m.Minute.ID, addErr)
				}
				s.Bars = append(s.Bars, bars...)
			}
			s.Stats = tracker.Stats()
			current.Sessions = append(current.Sessions, s)
		}
		result = append(result, current)
	}
	body, err := json.MarshalIndent(result, "", "  ")
	if err != nil {
		return err
	}
	file, err := os.OpenFile(output, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if err != nil {
		return err
	}
	defer file.Close()
	_, err = file.Write(append(body, '\n'))
	return err
}

// main は明示した人工JSONだけを使用する独立実行入口です。
//
// 引数: --input/--output(string)は必須の人工入力と未作成出力です。
// 返り値: ありません。不正時は非零終了します。
func main() {
	input := flag.String("input", "", "人工入力JSON")
	output := flag.String("output", "", "人工結果JSON")
	flag.Parse()
	if *input == "" || *output == "" {
		fmt.Fprintln(os.Stderr, "人工入力/出力が必要")
		os.Exit(2)
	}
	if err := run(*input, *output); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
