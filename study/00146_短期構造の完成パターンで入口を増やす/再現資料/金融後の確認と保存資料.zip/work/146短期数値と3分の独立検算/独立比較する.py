"""人工Minuteを公開NewShortへ通し、Python標準式から作った期待値へ比較する。"""
from pathlib import Path
import argparse
import copy
import hashlib
import json
import math
import subprocess
from collections import Counter

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
GEN=ROOT/'work/146短期構造の入口'
OLD=ROOT/'work/128Raw価格時計の全場足生成/internal/basenumeric'
FIELDS=('ema8','ema21','ema8_delta','ema21_delta','gap','atr','previous_atr','tr','histogram','previous_histogram')


def sha(path: Path) -> str:
    """
    機能: 明示したコード又は人工ファイルの指紋を計算する。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def save(path: Path,value: object) -> None:
    """
    機能: 未作成先へ日本語UTF-8 JSONを保存する。
    引数: path(Path)、value(object)は人工値又は検査票。
    返り値: None。
    """
    with path.open('x',encoding='utf8') as out:json.dump(value,out,ensure_ascii=False,indent=2,allow_nan=False);out.write('\n')


# ----------------------------------------
def public(value: float|None) -> dict:
    """
    機能: 期待値の既知性を既知0と区別する。
    引数: value(float|None)。
    返り値: dictはknown/value。
    """
    return {'known':value is not None,'value':value if value is not None else 0}


# ----------------------------------------
class StandardNumeric:
    """初期SMA、標準EMA、Wilder ATRをPythonだけで計算する。"""
    def __init__(self) -> None:
        """
        機能: 価格列とEMA/ATRの既知前値をcold初期化する。
        引数: なし。
        返り値: None。
        """
        self.closes=[];self.ranges=[];self.macds=[]
        self.ema={p:None for p in (8,21,12,26,9)};self.atr=None;self.hist=None

    def process(self,bar: dict) -> dict:
        """
        機能: 一つの人工確定足から公開使用値の独立期待値を求める。
        引数: bar(dict)はknown/OHLCを持つ足。
        返り値: dictは10公開指標のknown/value。量は価格算術へ入力しない。
        """
        if not bar['price_known'] or not bar['closed']:
            self.__init__();return {name:public(None) for name in FIELDS}
        price=bar['ohlc'];old8=self.ema[8];old21=self.ema[21];oldatr=self.atr;oldhist=self.hist
        previous=self.closes[-1] if self.closes else None
        tr=price['high']-price['low']
        if previous is not None:tr=max(tr,abs(price['high']-previous),abs(price['low']-previous))
        self.closes.append(price['close']);self.ranges.append(tr)
        for period in (8,21,12,26):
            alpha=2/(period+1)
            if len(self.closes)==period:self.ema[period]=math.fsum(self.closes)/period
            elif len(self.closes)>period:self.ema[period]=(1-alpha)*self.ema[period]+alpha*price['close']
        if len(self.ranges)==14:self.atr=math.fsum(self.ranges)/14
        elif len(self.ranges)>14:self.atr=(13/14)*self.atr+tr/14
        if self.ema[12] is not None and self.ema[26] is not None:
            macd=self.ema[12]-self.ema[26];self.macds.append(macd)
            if len(self.macds)==9:self.ema[9]=math.fsum(self.macds)/9
            elif len(self.macds)>9:self.ema[9]=.8*self.ema[9]+.2*macd
            if self.ema[9] is not None:self.hist=macd-self.ema[9]
        return {k:public(v) for k,v in {'ema8':self.ema[8],'ema21':self.ema[21],
            'ema8_delta':None if old8 is None else self.ema[8]-old8,
            'ema21_delta':None if old21 is None else self.ema[21]-old21,
            'gap':None if self.ema[8] is None or self.ema[21] is None else self.ema[8]-self.ema[21],
            'atr':self.atr,'previous_atr':oldatr,'tr':tr,'histogram':self.hist,'previous_histogram':oldhist}.items()}


# ----------------------------------------
def make_session(name: str,contract: str,start: int,count: int,carry: bool=False,delivered: int|None=None,changes: dict|None=None) -> dict:
    """
    機能: 非単調価格・出来高を持つ当場の人工1分格子を作る。
    引数: name/contract(str)、start/count(int)、carry(bool)、delivered(int|None)、changes(dict|None)。
    返り値: dictは人工場。未配送末尾は存在してもNewShortへ渡さない。
    """
    values=[];changes=changes or {}
    for i in range(1,count+1):
        c=10000+((start//1000)%11)*30+.7*i+3*(i%11-5)+(25 if i%5==0 else 0)
        op=c+(-4 if i%2 else 5);high=max(op,c)+7+i%3;low=min(op,c)-5-i%4
        end=start+60*i
        m={'id':name+'/'+str(i),'session':name,'contract':contract,'start':end-60,'end':end,'available_at':end+60,
            'stamp':{'time':end+60,'index':i,'source_line':i+1},'ohlc':{'open':op,'high':high,'low':low,'close':c},
            'volume':(i*7)%31,'price_known':True,'volume_known':True,'closed':True,'missing':False}
        m.update(copy.deepcopy(changes.get(i,{})))
        values.append({'deliver':i<=(delivered if delivered is not None else count),'minute':m})
    return {'id':name,'contract':contract,'start':start,'end':start+count*60,'carry':carry,'minutes':values}


# ----------------------------------------
def suite() -> list:
    """
    機能: 助走/未知reset/量非reset/配送prefixcarry/3分既知性の限定人工群を作る。
    引数: なし。
    返り値: listは7群の人工入力。
    """
    first=make_session('過去配送','C',1000000,132,delivered=130,changes={41:{'volume_known':False},42:{'volume':0}})
    catchup=make_session('同Raw配送','C',4000000,9)
    for item in catchup['minutes'][:3]:item['minute']['stamp']={'time':4000240,'index':3,'source_line':4}
    return [
        {'id':'助走と配送prefixの同限月carry','sessions':[first,make_session('次場同限月','C',1010000,5,True),
            make_session('異限月cold','NEXT',1020000,5,True),make_session('継承要求なし','NEXT',1030000,5,False)]},
        {'id':'価格未知と未閉鎖とmissingのreset','sessions':[make_session('未知reset','C',2000000,120,changes={
            36:{'volume_known':False},42:{'price_known':False},85:{'closed':False},114:{'missing':True}})]},
        {'id':'既知0量と末尾端数','sessions':[make_session('既知0量','C',3000000,5,changes={i:{'volume':0} for i in range(1,6)})]},
        {'id':'価格未知と量既知の分離','sessions':[make_session('価格だけ未知','C',3100000,3,changes={2:{'price_known':False}})]},
        {'id':'量未知と価格既知の分離','sessions':[make_session('量だけ未知','C',3200000,3,changes={2:{'volume_known':False}})]},
        {'id':'未閉鎖子は両方未知','sessions':[make_session('未閉鎖','C',3300000,3,changes={2:{'closed':False}})]},
        {'id':'同Rawの実三本集約','sessions':[catchup]},
    ]


# ----------------------------------------
def expected(scenarios: list) -> list:
    """
    機能: 1分/3分を独立形成しPython標準数式で公開票の期待値を作る。
    引数: scenarios(list)は人工入力。
    返り値: listは場ごとの公開票と件数。作者Go/Python算術をimportしない。
    """
    results=[]
    for item in scenarios:
        numeric={60:StandardNumeric(),180:StandardNumeric()};prior_contract=None;scenes=[]
        for scene in item['sessions']:
            carried=scene['carry'] and prior_contract==scene['contract']
            if not carried:numeric={60:StandardNumeric(),180:StandardNumeric()}
            children=[];bars=[];stats=Counter();undelivered=0
            if carried:stats['numeric_carried']=1
            for value in scene['minutes']:
                if not value['deliver']:undelivered+=1;continue
                m=value['minute'];closed=m['closed'] and not m['missing'];pk=m['price_known'] and closed;vk=m['volume_known'] and closed
                one={k:copy.deepcopy(m[k]) for k in ('id','session','contract','start','end','available_at','stamp')}
                one.update({'width_seconds':60,'closed':closed,'price_known':pk,'volume_known':vk,
                    'ohlc':copy.deepcopy(m['ohlc']) if pk else dict.fromkeys(('open','high','low','close'),0),'volume':m['volume'] if vk else 0,'children':[]})
                one['technical']=numeric[60].process(one);bars.append(one);stats['minutes']+=1
                stats['price_known_1m' if pk else 'numeric_reset_1m']+=1
                if vk:stats['volume_known_1m']+=1
                group_start=scene['start']+((m['start']-scene['start'])//180)*180
                if group_start+180>scene['end']:stats['partial_3m_minutes']+=1;continue
                children.append(one)
                if len(children)!=3:continue
                a,z=children[0],children[-1];pknown=all(c['price_known'] and c['closed'] for c in children);vknown=all(c['volume_known'] and c['closed'] for c in children)
                three={'id':f"146/{scene['id']}/180/{a['start']:.0f}",'session':scene['id'],'contract':scene['contract'],
                    'width_seconds':180,'start':a['start'],'end':z['end'],'available_at':z['end']+60,'stamp':copy.deepcopy(z['stamp']),
                    'price_known':pknown,'volume_known':vknown,'closed':all(c['closed'] for c in children),
                    'ohlc':{'open':a['ohlc']['open'],'high':max(c['ohlc']['high'] for c in children),'low':min(c['ohlc']['low'] for c in children),'close':z['ohlc']['close']} if pknown else dict.fromkeys(('open','high','low','close'),0),
                    'volume':math.fsum(c['volume'] for c in children) if vknown else 0,
                    'children':[{'id':c['id'],'width_seconds':60,'end':c['end'],'delivered':copy.deepcopy(c['stamp'])} for c in children]}
                three['technical']=numeric[180].process(three);bars.append(three);stats['bars_3m']+=1
                stats['price_known_3m' if pknown else 'numeric_reset_3m']+=1
                if vknown:stats['volume_known_3m']+=1
                children=[]
            scenes.append({'id':scene['id'],'bars':bars,'stats':dict(stats),'undelivered':undelivered});prior_contract=scene['contract']
        results.append({'id':item['id'],'sessions':scenes})
    return results


# ----------------------------------------
def compare(wanted: list,actual: list) -> dict:
    """
    機能: 公開10指標の既知性/値と1分・3分の価格/量/参照/件数を照合する。
    引数: wanted/actual(list)は独立期待値とGo公開結果。
    返り値: dictは件数と最大絶対差。浮動誤差は絶対1e-9/相対1e-12まで。
    """
    assert len(wanted)==len(actual);fields=Counter();max_error=0.;bars=0
    for e,a in zip(wanted,actual):
        assert e['id']==a['id'] and len(e['sessions'])==len(a['sessions'])
        for es,as_ in zip(e['sessions'],a['sessions']):
            assert es['id']==as_['id'] and es['stats']==as_['stats'] and es['undelivered']==as_['undelivered'] and len(es['bars'])==len(as_['bars'])
            for eb,ab in zip(es['bars'],as_['bars']):
                bars+=1
                for name in ('id','session','contract','width_seconds','start','end','available_at','stamp','price_known','volume_known','closed','ohlc','volume','children'):assert eb[name]==ab[name],(es['id'],eb['id'],name)
                for name in FIELDS:
                    v,w=eb['technical'][name],ab['technical'][name];assert v['known']==w['known'],(eb['id'],name,v,w)
                    error=abs(v['value']-w['value']);max_error=max(max_error,error)
                    assert math.isclose(v['value'],w['value'],rel_tol=1e-12,abs_tol=1e-9),(eb['id'],name,v,w)
                    fields['known確認']+=1;fields['値確認']+=1;fields['既知の値']+=int(v['known'])
    return {'成功':True,'公開足':bars,**dict(fields),'最大絶対差':max_error,'絶対許容':1e-9,'相対許容':1e-12}


# ----------------------------------------
def main() -> None:
    """
    機能: 人工だけを準備し、作者停止通知後に限り公開Go部品と独立式を照合する。
    引数: --prepare(bool)、--verify(bool)、--author-stopped(bool)は自然前人工の段階指定。
    返り値: None。新金融/Raw/CSV/Source自然入力を開かずGENを変更しない。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--prepare',action='store_true');parser.add_argument('--verify',action='store_true');parser.add_argument('--author-stopped',action='store_true');args=parser.parse_args()
    assert args.prepare != args.verify
    if args.prepare:
        items=suite();save(HERE/'人工入力.json',items);save(HERE/'Python標準式の期待値.json',expected(items))
        print(json.dumps({'成功':True,'人工群':len(items),'Go実行':False,'自然入力読取':False},ensure_ascii=False));return
    assert args.author_stopped,'作者停止通知前に最終Go実行しない'
    before={str(p.relative_to(ROOT)):sha(p) for p in list(GEN.rglob('*.go'))+[GEN/'go.mod']}
    identical={}
    for name in ('bridge.go','numeric.go','pivot.go','types.go'):
        a=OLD/name;b=GEN/'internal/basenumeric'/name;assert a.read_bytes()==b.read_bytes()
        identical[name]={'旧128SHA256':sha(a),'新146SHA256':sha(b),'bytes':a.stat().st_size}
    run=subprocess.run(['go','run','.','--input',str(HERE/'人工入力.json'),'--output',str(HERE/'Go公開結果.json')],cwd=HERE,text=True,encoding='utf8',capture_output=True)
    assert run.returncode==0,run.stdout+run.stderr
    wanted=json.loads((HERE/'Python標準式の期待値.json').read_bytes());actual=json.loads((HERE/'Go公開結果.json').read_bytes());result=compare(wanted,actual)
    assert before=={str(p.relative_to(ROOT)):sha(p) for p in list(GEN.rglob('*.go'))+[GEN/'go.mod']}
    proof={'成功':True,'試行':146,'区分':'自然前・人工による短期数値/3分の別算術確認','人員分離':'Source部品作者review131/本独立確認archive130',
        '作者Python/128/146算術import':False,'公開NewShort/StartSession/Addだけを使用':True,'private reflect観測':False,
        '人工群':len(actual),'比較':result,'旧128private4源完全同体':identical,'Sourceコード前後不変':before,
        '対象':'EMA8/21/増分/Gap、標準EMA12/26/Signal9からの公開Hist/前Hist、Wilder ATR14/前ATR/TR、known/助走/未知reset/量未知非reset/同限月配送prefixcarry/異限月cold/3分OHLC量/子ref/端数',
        '未対象':'売買state/背景Contextの適格性/自然品質/利確損切り/金融/戦略精度。EMA12/26/Signal9のprivate値は直接観測せず使用値Histで照合。',
        '自然Raw/CSV/金融/Source出力/追加2場読取':False,'GEN変更':False,
        '人工入力SHA256':sha(HERE/'人工入力.json'),'期待値SHA256':sha(HERE/'Python標準式の期待値.json'),'Go公開結果SHA256':sha(HERE/'Go公開結果.json')}
    save(HERE/'独立確認.json',proof);print(json.dumps({'成功':True,'独立確認SHA256':sha(HERE/'独立確認.json'),'比較':result},ensure_ascii=False))


if __name__=='__main__':main()
