"""146短期数値の初回独立照合を停止し、人工票を1ZIPへまとめる。"""
from pathlib import Path
import json
import zipfile
from 独立比較する import ROOT,HERE,GEN,sha,save


def main() -> None:
    """
    機能: 作者停止票とGo前後不変を接続し、小型の保存対象を確定する。
    引数: なし。
    返り値: None。GEN/人工値/自然資料を変更しない。
    """
    author=GEN/'準備の確認.json';assert sha(author)=='a144becad036990b47d5893b866b416d4e6818482813b7673aeb99b3f05d09af'
    original=json.loads(author.read_bytes());assert original['成功'] and original['編集停止']
    p=HERE/'独立確認.json';assert sha(p)=='db60e4d1d302a6281e09a1c7074857c862c07819e1d9cf27ec92bc73a600dd60'
    result=json.loads(p.read_bytes());assert result['成功'] and result['比較']['公開足']==381
    current=result['Sourceコード前後不変']
    assert all(sha(ROOT/name)==h for name,h in current.items())
    for item in original['源']:
        if item['path'] in current:assert item['sha256']==current[item['path']]
    target=HERE/'人工比較の票.zip';records=[]
    with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as out:
        for name in ('人工入力.json','Python標準式の期待値.json','Go公開結果.json'):
            raw=(HERE/name).read_bytes();out.writestr(name,raw);records.append({'ZIP内path':name,'bytes':len(raw),'sha256':sha(HERE/name)})
    with zipfile.ZipFile(target) as archive:
        import hashlib
        for item in records:assert hashlib.sha256(archive.read(item['ZIP内path'])).hexdigest()==item['sha256']
    names=('go.mod','main.go','独立比較する.py','確認を停止する.py','README.md','独立確認.json','人工比較の票.zip')
    final={'成功':True,'試行':146,'編集停止':True,'初回Go比較成功':True,'作者最終停止SHA256':sha(author),'独立確認SHA256':sha(p),
        '比較':result['比較'],'旧128private4源完全同体':True,'GEN前後不変':True,'private reflect観測':False,
        '小型保存対象':{name:{'bytes':(HERE/name).stat().st_size,'sha256':sha(HERE/name)} for name in names},
        '人工票ZIP内':records,'plain3JSONの正式複写不要':True,'停止票自身も保存':True,
        '自然Raw/CSV/新金融/Source出力/追加2場読取':False,'売買stateや戦略精度の確認':False,'重大不足':[]}
    save(HERE/'停止の確認.json',final);print(json.dumps({'成功':True,'停止SHA256':sha(HERE/'停止の確認.json'),'人工ZIP_SHA256':sha(target),'重大不足':[]},ensure_ascii=False))


if __name__=='__main__':main()
