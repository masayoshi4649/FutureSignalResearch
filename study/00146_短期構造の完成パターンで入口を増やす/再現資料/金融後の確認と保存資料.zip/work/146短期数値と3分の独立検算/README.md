# 146の短期数値と3分を別算術で確認する

2026-11-12。Source数値部品の作者review131と、本確認archive130を分けた自然前の人工検査である。Goの公開 `NewShort/StartSession/Add/Stats` へ人工Minuteだけを渡す。GENファイルを書き換えず、private reflectや作者Python/128/146算術のimportを使わない。

Pythonは終値列から初期SMAを作り、その後 `EMA=α×今回値＋(1−α)×前EMA`、`α=2/(n+1)` を計算する。EMA8/21/12/26、MACD12−26のSignal9、Hist=MACD−Signalを独立に計算する。TRは高安差と前終値からの高安距離の最大、ATR14は初期14TR平均の後Wilder更新とする。EMA12/26/Signal9のprivate値を直接確認したとはせず、戦略が使用する公開Hist/前Histへ一致を要求する。

対象公開値はEMA8/21・実増分・Gap、ATR/前ATR/TR、Hist/前Histの10項目。knownと値をともに確認し、浮動誤差は絶対1e−9/相対1e−12までとする。通常の助走はEMA8/21が8/21本、ATRが14本、Histが34本、前Histが35本で、3分は3分自身の本数を使う。未知を既知0へ置き換えない。

7人工群には非単調価格、量未知による価格数値の非reset、既知0量、価格未知/未閉鎖/missingによるreset、同限月の配送prefixだけのcarry、異限月/継承指定なしcold、1分と3分の独立助走、厳密3本のOHLC/量/子ref、価格既知と量既知の分離、末尾端数、同Rawで知る3子を含める。前場132本のうち130本だけ配送し、EOF未配送2本と未完成3分子を次場へ足さない。

```powershell
python -X utf8 "work/146短期数値と3分の独立検算/独立比較する.py" --prepare
# 作者の最終停止通知後だけ実行する。各出力は未作成である必要がある。
python -X utf8 "work/146短期数値と3分の独立検算/独立比較する.py" --verify --author-stopped
```

最終比較では旧128 private basenumericのbridge/numeric/pivot/typesの4源と新コピーのbytes/SHA完全同体を先に検査し、全Go源とgo.modの前後不変も残す。[独立確認](独立確認.json)が最終結果であり、未生成なら比較完了とは扱わない。Goは1.24.2 windows/amd64、Pythonは3.14.3。runnerのgo.modはローカルSource/118/三時間軸へのreplaceだけである。

売買state・背景Contextの適格性・自然品質・金融・精度は対象外。人工成功を自然CSV/Rawの受信完全性や先着率改善の証拠としない。自然Raw/CSV・Source出力・新金融・追加2場は読まない。

## 確認結果

作者停止通知（準備SHA `a144beca…05d09af`）後の初回Go実行で成功した。7人工群、381公開足、10指標のknown 3,810確認・値3,810比較が一致し、最大絶対差は `7.275957614183426e−12`。旧128 private4源は新コピーとbytes/SHAが完全同体、SourceのGo源とgo.modも実行前後不変だった。私有EMA12/26/Signal値の直接確認ではなく、使用する公開Histの独立算術一致である。

最小の恒久保存は[停止票](停止の確認.json)に列挙するコード・README・独立確認と[人工票ZIP](人工比較の票.zip)だけでよい。3つのplain人工JSONはZIPと重複して正式コピーしない。停止票自身も保存対象である。
