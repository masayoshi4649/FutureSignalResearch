package shortpattern146

import (
	"fmt"
	"testing"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// reviewQuote146 は、値幅検査を可能にする架空Rawを作ります。
//
// 引数: time(float64)、index(int64)、last(float64)は人工の時計と価格です。
// 返り値: Quote は正常BBO付きの架空値です。
func reviewQuote146(time float64, index int64, last float64) Quote {
	return Quote{Time: time, Index: index, SourceLine: index + 1, Last: last, Bid: last - 5, Ask: last + 5, QuoteOK: true, Clock: "人工価格時計"}
}

// reviewSnapshot146 は、既存Bankの自然入力を読まずA背景を作ります。
//
// 引数: q(Quote)、known(bool)は現在Rawと背景既知性です。
// 返り値: rules.Snapshot は5/15/30の人工背景です。
func reviewSnapshot146(q Quote, known bool) rules.Snapshot {
	s := rules.Snapshot{SessionID: "S", Contract: "C", AsOf: rq(q), Frames: map[int]rules.Publication{}, Refs: []rules.Ref{}}
	for _, width := range []int{300, 900, 1800} {
		tech := rules.Technical{Gap: rules.Value{Known: known, Value: 1}, EMA21Delta: rules.Value{Known: known, Value: 1}, ATR: rules.Value{Known: known, Value: 100}}
		frame := rules.ChartFrame{ID: fmt.Sprintf("人工背景%d", width), SessionID: "S", Contract: "C", Width: width, End: 0, PriceKnown: true, Technical: tech}
		s.Frames[width] = rules.Publication{Stamp: rules.Stamp{Time: 60, Index: 0, Line: 1}, Frame: rules.Frame{Frame: frame, DMI: rules.DMI{
			PlusDI: rules.Value{Known: known, Value: 30}, MinusDI: rules.Value{Known: known, Value: 10},
			ADX: rules.Value{Known: known, Value: 25}, PreviousADX: rules.Value{Known: known, Value: 24}}}}
	}
	return s
}

// reviewBar146 は、Aのo/p/rパターン用の既知短期足を作ります。
//
// 引数: number(int)はo/p/rの位置、q(Quote)はその実配送Rawです。
// 返り値: ShortBar は数値器を呼ばない人工の確定足です。
func reviewBar146(number int, q Quote) ShortBar {
	bar := ShortBar{ID: fmt.Sprintf("人工短期%d", number), Session: "S", Contract: "C", Width: 60,
		Start: float64((number - 1) * 60), End: float64(number * 60), AvailableAt: float64(number*60 + 60),
		Stamp: rules.Stamp{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine)}, PriceKnown: true, VolumeKnown: true, Closed: true,
		Volume: 10, Children: []rules.Ref{}, Technical: rules.Technical{EMA8: v(110), EMA21: v(120), ATR: v(100), PreviousATR: v(100), TR: v(30)}}
	switch number {
	case 1:
		bar.OHLC = rules.OHLC{Open: 110, High: 125, Low: 100, Close: 120}
		bar.Technical.Histogram = v(2)
	case 2:
		bar.OHLC = rules.OHLC{Open: 125, High: 130, Low: 100, Close: 115}
		bar.Technical.Histogram = v(-1)
	case 3:
		bar.OHLC = rules.OHLC{Open: 120, High: 150, Low: 80, Close: 145}
		bar.Technical.Histogram = v(3)
	}
	return bar
}

// TestReview146CompletePatternHasNoPriorI は、p知得時に仮Iを監視しない新定義を確認します。
//
// 引数: t(*testing.T)は独立人工です。
// 返り値: ありません。源の数値器は使いません。
func TestReview146CompletePatternHasNoPriorI(t *testing.T) {
	d := NewDetector(Scene{Session: "S", Contract: "C", Start: 0, End: 9000, ForceClose: 8700})
	for i, last := range []float64{120, 85, 145} {
		q := reviewQuote146(float64((i+2)*60), int64(i+1), last)
		if err := d.Observe(reviewSnapshot146(q, true), q, []ShortBar{reviewBar146(i+1, q)}); err != nil {
			t.Fatal(err)
		}
	}
	if len(d.Events) != 1 || d.pending == nil {
		t.Fatal("p時の仮I監視で完成パターンを失った", d.Stats)
	}
	e := d.Events[0]
	if e.Structure.K != 140 || e.Structure.I != 70 || e.Structure.Width != 70 || e.Structure.Cap != 55 || e.Arm.End != 120 || e.Confirm.End != 180 {
		t.Fatal(e)
	}
	q := reviewQuote146(241, 4, 145)
	if err := d.Observe(reviewSnapshot146(q, true), q, nil); err != nil {
		t.Fatal(err)
	}
	if d.Groups[0].Status != "filled" || *e.EntryPrice != 150 || d.Stats["物理取得"] != 1 {
		t.Fatal("別Raw実Pで取得できない", e)
	}
}

// TestReview146InitialUnknownCannotBeRepaired は、p未知をr現在背景で埋めないことを確認します。
//
// 引数: t(*testing.T)は独立人工です。
// 返り値: ありません。
func TestReview146InitialUnknownCannotBeRepaired(t *testing.T) {
	d := NewDetector(Scene{Session: "S", Contract: "C", Start: 0, End: 9000, ForceClose: 8700})
	for i := 1; i <= 3; i++ {
		q := reviewQuote146(float64((i+1)*60), int64(i), 145)
		if err := d.Observe(reviewSnapshot146(q, i != 2), q, []ShortBar{reviewBar146(i, q)}); err != nil {
			t.Fatal(err)
		}
	}
	if len(d.Events) != 0 || d.Bars[1].Context.Fields["atr5"].Known {
		t.Fatal("p初Contextをrで補完")
	}
	q := reviewQuote146(241, 4, 145)
	if err := d.Observe(reviewSnapshot146(q, true), q, nil); err != nil {
		t.Fatal(err)
	}
	if len(d.Events) != 0 {
		t.Fatal("同じ完成rを後Rawで再利用")
	}
}

// TestReview146SameRawPairRejected は、同Rawのcatch-upを過去準備済みへ偽装しないことを確認します。
//
// 引数: t(*testing.T)は独立人工です。
// 返り値: ありません。
func TestReview146SameRawPairRejected(t *testing.T) {
	d := NewDetector(Scene{Session: "S", Contract: "C", Start: 0, End: 9000, ForceClose: 8700})
	q := reviewQuote146(240, 1, 145)
	batch := []ShortBar{}
	for i := 1; i <= 3; i++ {
		batch = append(batch, reviewBar146(i, q))
	}
	if err := d.Observe(reviewSnapshot146(q, true), q, batch); err != nil {
		t.Fatal(err)
	}
	if len(d.Events) != 0 || len(d.Checks) != 2 {
		t.Fatal("同Raw過去p/r連鎖又は古いr全件を判断")
	}
	q = reviewQuote146(241, 2, 145)
	if err := d.Observe(reviewSnapshot146(q, true), q, nil); err != nil {
		t.Fatal(err)
	}
	if len(d.Events) != 0 {
		t.Fatal("同Raw不成立rを後で復活")
	}
}

// TestReview146OnlyOneWidthCanFill は、同方向groupの候補別実P域と物理一件を確認します。
//
// 引数: t(*testing.T)は独立人工です。
// 返り値: ありません。
func TestReview146OnlyOneWidthCanFill(t *testing.T) {
	d := NewDetector(Scene{Session: "S", Contract: "C", Start: 0, End: 9000, ForceClose: 8700})
	birth := reviewQuote146(240, 3, 145)
	d.pending = &Group{ID: "人工group", Side: 1, Birth: birth, Status: "pending", CandidateIDs: []string{"1", "3"}, FilledIDs: []string{}}
	group := d.pending
	d.Groups = append(d.Groups, group)
	for _, width := range []int{60, 180} {
		cap := 20.0
		if width == 180 {
			cap = 2
		}
		family := "A1"
		if width == 180 {
			family = "A3"
		}
		e := &Event{ID: fmt.Sprint(width), Family: family, Width: width, Side: 1, Status: "pending", Birth: birth, Expires: 270,
			Structure: Structure{K: 145, I: 100, Width: 45, Cap: cap, ArmATR: cap}, Refs: []rules.Ref{}, Reasons: []string{}, Trace: []Trace{}}
		d.active = append(d.active, e)
		d.Events = append(d.Events, e)
		d.latest[width] = KnownBar{Bar: ShortBar{Width: width, End: 180, PriceKnown: true, Closed: true}}
	}
	q := reviewQuote146(241, 4, 145)
	if err := d.processPending(q, makeContext(reviewSnapshot146(q, true), q)); err != nil {
		t.Fatal(err)
	}
	if d.Events[0].Status != "filled" || d.Events[1].Status != "entry_position_rejected" || d.pending != nil || group.Status != "filled" || group.RepresentativeID != "60" || len(group.FilledIDs) != 1 {
		t.Fatal("候補の個別取得域が混ざった")
	}
	if d.Stats["物理取得"] != 1 {
		t.Fatal("両幅を二物理へ水増し")
	}
}
