"""作者最終版へ独立状態人工を束縛し、自然入力なしで全test/vet/buildを確認する。"""

from pathlib import Path
import hashlib
import json
import re
import subprocess

ROOT=Path(__file__).resolve().parents[2]
OWN=Path(__file__).resolve().parent
SOURCE=ROOT/'work/146短期構造の入口'
AUTHOR=SOURCE/'準備の確認.json'
AUTHOR_SHA='a144becad036990b47d5893b866b416d4e6818482813b7673aeb99b3f05d09af'
EXE_SHA='7c908f60d7f94c524f8a31cf06c21cd48a52f6ec57a3c613aedc14bcfb3f463a'


def info(path: Path) -> dict:
    """
    機能: コード・証跡・実行体の現在指紋を取得する。
    引数: path (Path) は確認対象。
    返り値: dict は相対パス/bytes/sha256。
    """
    raw=path.read_bytes()
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def main() -> None:
    """
    機能: 最終37源とexeを照合し、状態人工4群を含めた全検査を実行する。
    引数: なし。作者準備runner・自然Source CLIは実行しない。
    返り値: None。検査後同体・役割分担・未検証範囲を保存する。
    """
    assert info(AUTHOR)['sha256']==AUTHOR_SHA
    author=json.loads(AUTHOR.read_bytes())
    assert author['成功'] and author['編集停止'] and len(author['源'])==37
    targets=[]
    for item in author['源']+[author['実行ファイル']]:
        path=ROOT/item['path'];actual=info(path)
        assert actual['sha256']==item['sha256'] and actual['bytes']==item['bytes']
        targets.append(path)
    assert author['実行ファイル']['sha256']==EXE_SHA
    targets.append(AUTHOR)
    before=[info(path) for path in targets]
    commands=[['go','test','-count=1','-v','-overlay='+str(OWN/'overlay.json'),'./...'],
              ['go','vet','./...'],['go','build','./...']]
    results=[]
    for command in commands:
        completed=subprocess.run(command,cwd=SOURCE,capture_output=True,text=True,encoding='utf-8',check=False)
        results.append({'実行列':command,'終了コード':completed.returncode,'標準出力':completed.stdout,'標準エラー':completed.stderr})
        assert completed.returncode==0,results[-1]
    stdout=results[0]['標準出力']
    assert len(re.findall(r'^=== RUN   TestReview146',stdout,re.M))==4
    assert len(re.findall(r'^--- PASS:',stdout,re.M))==20
    assert [info(path) for path in targets]==before
    proof={'成功':True,'試行':146,'状態':'金融前のSource因果レビューを停止','確認日':'2026-11-12',
        '作者最終proofSHA256':AUTHOR_SHA,'実行ファイルSHA256':EXE_SHA,'最終37源とexe及び作者proof前後同体':before,
        '作者主人工':16,'独立状態人工':4,'全主人工':20,'確認':results,
        '独立確認の対象':['p時の仮I監視を置かずr極値でIを初固定','p初Context未知をrで補完しない/後Raw同r復活なし',
                           '同Rawcatchupのp/rを遡及準備せず最新rだけ判定','同方向groupで片幅だけ実P適格・有効候補の代表/物理1件'],
        '静的確認':'state/context/scannerの初Context凍結・全背景pub先配送・各幅最新/strict順・現在背景と歴史分離・候補別pending・逆競合/後着抑止・EOF未配送不投入・品質成功後場順次carryを採用d43abc95へ照合。',
        '役割境界':'本agentはshort.go/short_test.go/internal basenumeric複写/短期数値由来の作者。ここで数値数学を独立検算したとは主張せず、Rootの旧4源同体とarchive130のPython標準式381足比較へ分離する。',
        '重大未解決':False,'作者準備runner再実行':False,'Source作者源編集':False,
        '自然SourceRawCSV金融追加2場読取':False,
        '独立源':[info(OWN/'独立人工_test.go'),info(OWN/'overlay.json'),info(Path(__file__))]}
    raw=(json.dumps(proof,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    (OWN/'準備の確認.json').write_bytes(raw)
    print(json.dumps({'proof_sha256':hashlib.sha256(raw).hexdigest(),'sources':37,'tests':20,'independent_state':4}))


if __name__=='__main__':
    main()
