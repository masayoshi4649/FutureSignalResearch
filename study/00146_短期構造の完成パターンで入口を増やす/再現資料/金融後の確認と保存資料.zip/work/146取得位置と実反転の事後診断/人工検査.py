"""未知、区分境界、保存実正逆のIFD優先を人工で確認する。"""
from pathlib import Path
import importlib.util
import unittest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('diagnosis146', HERE/'診断する.py')
diagnosis = importlib.util.module_from_spec(spec); spec.loader.exec_module(diagnosis)
arithmetic = diagnosis.module(diagnosis.CALCULATE, 'arithmetic141test146')


class DiagnosisTests(unittest.TestCase):
    """個別の診断式とIFDの既知/未知を確認する。"""

    def test_未知と尺度(self) -> None:
        """
        機能: 未知と0を区別し、0除算を未知にする。
        引数: self(DiagnosisTests)。返り値: None。
        """
        self.assertIsNone(diagnosis.number({'known': False, 'value': 0}))
        self.assertEqual(diagnosis.number({'known': True, 'value': 0}), 0)
        self.assertIsNone(diagnosis.ratio(1, 0)); self.assertEqual(diagnosis.ratio(0, 1), 0)

    def test_物理鏡像と位相(self) -> None:
        """
        機能: 価格系反転時のnative符号変換とゼロ境界を確認する。
        引数: self(DiagnosisTests)。返り値: None。
        """
        self.assertEqual(diagnosis.side_value(-2, -1), diagnosis.side_value(2, 1))
        self.assertEqual(diagnosis.momentum_level(1, -1), '不一致')
        self.assertEqual(diagnosis.momentum_level(1, 0), 'ゼロを含む')
        self.assertEqual(diagnosis.momentum_level(None, 1), '未知')

    def test_H不足でも既知touchを先にする(self) -> None:
        """
        機能: H不足時も既知touch清算を残し、77+1000円を控除する。
        引数: self(DiagnosisTests)。返り値: None。
        """
        stream = {'birth': {'side': 1}, 'entry_price': 100,
            'outcomes': [{'seconds': 3600, 'status': 'censored', 'endpoint': None,
                'touches': [{'width': 125, 'direction': 1, 'quote': {'last': 226, 'bid': 225, 'ask': 227}}]}]}
        case = {'original': stream}
        value = arithmetic.calculate([('人工', case)], False, 'BBO', 3600, 125)
        self.assertEqual((value['complete'], value['ifd_known'], value['ifd_net5_sum']), (0, 1, 11423))
        self.assertIsNone(value['resolved_rate'])

    def test_未touch不足は未知(self) -> None:
        """
        機能: 観測不足を損益0へ補完しない。
        引数: self(DiagnosisTests)。返り値: None。
        """
        stream = {'birth': {'side': -1}, 'entry_price': 100,
            'outcomes': [{'seconds': 3600, 'status': 'censored', 'endpoint': None,
                'touches': [{'width': 125, 'direction': 0, 'quote': None}]}]}
        value = arithmetic.calculate([('人工', {'reverse': stream})], True, 'BBO', 3600, 125)
        self.assertEqual(value['ifd_unknown'], 1); self.assertIsNone(value['ifd_net5_sum'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
