"""診断JSONから全26の実数一覧と最小限の解釈を作る。"""
from pathlib import Path
from statistics import median
from collections import Counter
import json

HERE = Path(__file__).resolve().parent


def fmt(value) -> str:
    """
    機能: 未知を0へ変えず短い表示にする。
    引数: value(float又はNone)。返り値: str。
    """
    return '未知' if value is None else f'{value:.4g}'


def label(stats: dict) -> str:
    """
    機能: H完了先着をF/A/N、H不足をCで表す。
    引数: stats(dict)。返り値: str。
    """
    return 'C' if stats['censored'] else 'F' if stats['forward'] else 'A' if stats['adverse'] else 'N'


def render(data: dict) -> str:
    """
    機能: 意味区分の分母と小標本の限界を示す。
    引数: data(dict)。返り値: str。
    """
    groups = data['区分']; rows = data['全26']
    lines = ['# 146取得位置と実反転の事後診断', '', '確認日: 2026-11-12。新26物理取得・20場、未取得53場も残す。既使用73場の保存Source/当時refs/保存実正逆だけを使った。新価格・新出生・条件変更はない。全体35%という結果をRootから受け取った後、個別金融値を読む前に`区分と分母.md`を固定した。したがって事後説明であり未知期検証ではない。', '',
        '## nativeと同時点の実逆', '', '|集合|件数|向き|順/逆/未/不足|到達済率|C5利益|C5損失|差引|', '|---|---:|---|---|---:|---:|---:|---:|']
    for name in ('P0全26', '型:A1', '型:A3', '型:B1', '型:B3'):
        for direction, stats in groups[name].items():
            rate = '未定義' if stats['resolved_rate'] is None else format(stats['resolved_rate'], '.2%')
            counts = '/'.join(str(stats[k]) for k in ('forward', 'adverse', 'neither', 'censored'))
            cells = [name, stats['entries'], direction, counts, rate, stats['ifd_net5_profit'], stats['ifd_net5_loss'], stats['ifd_net5_sum']]
            lines.append('|'+ '|'.join(map(str,cells))+'|')
    matrix = Counter(label(row['native'])+'→'+label(row['inverse']) for row in rows)
    lines += ['', 'F=順行、A=逆行、N=未到達、C=観測不足。原→実逆は'+ '、'.join(k+' '+str(n)+'件' for k,n in matrix.items())+'。反転は1−勝率ではない。両方向ともIFD既知26/未知0で、H不足2件の既知touchも清算へ残している。H完了の先着率分母にはその2件を入れない。', '',
        '費用はmini1枚換算100円/pt、往復手数料77円と片道5pt相当の往復滑り1000円を控除したC5である。ラージBBOによる取得・清算の代用であり、mini実板の注文約定や口座収支を再生したものではない。逆側の注文geometryは再構築しておらず、同取得時計の方向診断である。', '',
        '## 当時の役割別の観測', '',
        '- 30分方向に整合する14件はA、逆らう12件はBのままだった。Bの元向きは3順8逆1未、実逆は8順3逆1未である。ADX15低下を反転の背景にしても、30分の持続方向が終わったという証拠にはならなかった、という次の問いを支える。ただし12例で新規則を採用しない。',
        '- 取得時の5分Hist水準と増分がnativeへ双方正なのは4件、双方負4件、不一致18件である。短期rのHistが正かつ実改善でも、背景5分の回復とは一致しない例が多い。15分は双方正9・双方負4・不一致12・未知1だった。未知1を0にしない。',
        '- s*(EMA21_5−実P)<0は21件、15分では16件だった。買いでは実PがEMA21より上、売りでは下という取得位置だが、該当しない群も不振である。単に「高値追いが全原因」とは言えない。EMAと実Pの距離、Hist、RSI増分、DIを全件一覧に残す。',
        '- W/ATR5は全26で1以下（最小0.2912・中央値0.5683・最大0.9420）。capは20件が125−W側、6件がATR5側で拘束された。狭い構造と取得適格性だけでは、その後の125pt方向性を保証しない。',
        '- rのHist/短期ATRは0.00571〜0.3326、中央値0.0982だった。0超0.1以下14件は4順7逆3未、0.1超12件は3順6逆1未2不足で、低振幅だけに不振を帰属できない。',
        '- 同幅r/p量比は1〜11.125、中央値1.527。1以上2未満18件は5順9逆2未2不足、2以上8件も2順4逆2未だった。量の増加を価格回復の強さと同一視しない。これはr/p数量比であり、出来高の通常時比較を行うRVOL5ではない。',
        '- r.Endから取得までは61〜172秒、中央値68秒。完成CSVのEnd+60秒モデル公表と実配送を経て現在BBOを検査するため、r終値そのもので取得したとは扱わない。', '',
        '一般的な心理仮説として、下位足の戻りと量増加はトレンド再開だけでなく、一時的な買戻し・戻り売りでも生じ得る。BのADX低下と短期回復を「上位トレンドの終了」に読み替えたことが弱点かもしれない。一方でA1は元/逆とも費用後赤字であり、一律反転でも解決しない。今後は上位方向・取得位置・背景の動力と短期回復の役割を分けた新仮説で検証する必要がある。市場参加者の実際の意図や注文フローはこの保存資料から断定できない。', '',
        '## 全26の実数', '',
        'E5/E15=s*(EMA21−実P)、H5=s*Hist5、dH5=s*ΔHist5、dRSI5=s*ΔRSI5、DI15=s*(+DI−−DI)。短H比=rのs*Hist/短期ATR、量比=r/p。値は取得時refsの背景で、短期量・短H比だけは確認rの確定票。実PはLastと別である。列が多いためIDはSource groupの末尾を用い、完全IDと全refは結果JSONに保持する。', '',
        '|場/ID|型|side|W/ATR5|cap|E5|E15|H5|dH5|dRSI5|DI15|短H比|量比|元→逆|C5元/逆|',
        '|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---|']
    for row in rows:
        t=row['technical']; b=t['background']['entry']; st=t['structure']; last_id=row['id'].split('/')[-1]
        cells=[row['session']+'/'+last_id,t['family'],t['native_side'],fmt(t['W_ATR5']),fmt(st['cap']),
            fmt(b['300']['ema21_minus_entry_signed']),fmt(b['900']['ema21_minus_entry_signed']),
            fmt(b['300']['hist_signed']),fmt(b['300']['hist_delta_signed']),fmt(b['300']['rsi_delta_signed']),
            fmt(b['900']['di_difference_signed']),fmt(t['r_hist_shortATR_signed']),fmt(t['r_p_volume_ratio']),
            label(row['native'])+'→'+label(row['inverse']),str(row['native']['ifd_net5_sum'])+'/'+str(row['inverse']['ifd_net5_sum'])]
        lines.append('|'+ '|'.join(map(str,cells))+'|')
    lines += ['', '全区分の既知符号別件数・先着・費用、出生/取得Quote・構造・当時p/r/取得refsは`結果.json`へ保存した。同一取得を複数の意味区分に示すので、区分間を加算しない。各familyは今回は重複所属0で全26を分割する。', '',
        '再現: `python 人工検査.py`、`python 診断する.py`（結果.json未作成先）、`python 短報を作る.py`。算術は凍結141独立calculateだけを再用し、Source担当自身による診断である。独立したSource再生・モデル選択・未知期検証の主張はしない。', '']
    return '\n'.join(lines)


def main() -> None:
    """
    機能: 保存JSONだけから短報を作る。
    引数: なし。返り値: None。
    """
    data=json.loads((HERE/'結果.json').read_bytes())
    (HERE/'全26の位置と実反転から分かったこと.md').write_text(render(data),encoding='utf-8')


if __name__ == '__main__':
    main()
