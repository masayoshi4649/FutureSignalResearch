"""保存26取得の構造と当時参照だけを結合し、保存実正逆を比較する。"""
from pathlib import Path
from collections import Counter
import importlib.util
import json
import math
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
SOURCE = ROOT/'work/146短期完成の評価/短期完成の出生と取得.json'
META = ROOT/'work/146短期完成の評価/固定入力/入口参照.json'
PAIRS = ROOT/'work/146短期完成の評価/固定取得の正逆観測.json'
BACKGROUND = ROOT/'work/122全場入力/入力.json'
READER = ROOT/'work/146短期パターンの非金融診断/段階を診断する.py'
CALCULATE = ROOT/'work/141金融集計を独立に確認する.py'


def module(path: Path, name: str):
    """
    機能: mainを実行せず凍結部品だけを私有importする。
    引数: path(Path)、name(str)。返り値: ModuleType。
    """
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value


def number(value: dict):
    """
    機能: 不足を0補完せず既知有限値を読む。
    引数: value(dict)。返り値: float又はNone。
    """
    if value.get('known'):
        x = value['value']; assert isinstance(x, (int, float)) and math.isfinite(x)
        return x
    return None


def side_value(value, side: int):
    """
    機能: 既知値だけをnative向きへ符号変換する。
    引数: value(float又はNone)、side(int)。返り値: float又はNone。
    """
    return value*side if value is not None else None


def delta(a, b):
    """
    機能: 両端既知の場合だけ差分を返す。
    引数: a/b(float又はNone)。返り値: float又はNone。
    """
    return a-b if a is not None and b is not None else None


def ratio(a, b):
    """
    機能: 正の既知分母に限って比を求める。
    引数: a/b(float又はNone)。返り値: float又はNone。
    """
    return a/b if a is not None and b is not None and b > 0 else None


def sign(value) -> str:
    """
    機能: 未知とゼロを分けて符号を示す。
    引数: value(float又はNone)。返り値: str。
    """
    return '未知' if value is None else '正' if value > 0 else '負' if value < 0 else 'ゼロ'


def momentum_level(hist, change) -> str:
    """
    機能: 水準と変化の組合せを固定意味区分へ写す。
    引数: hist/change(float又はNone)。返り値: str。
    """
    if hist is None or change is None: return '未知'
    if hist > 0 and change > 0: return '双方正'
    if hist < 0 and change < 0: return '双方負'
    if hist == 0 or change == 0: return 'ゼロを含む'
    return '不一致'


def make_pub_features(pub: dict, side: int) -> dict:
    """
    機能: 同じ公表に束縛された勢いとDMIをnative向きで保存する。
    引数: pub(dict)、side(int)。返り値: dict。
    """
    frame = pub['frame']['frame']; tech = frame['technical']; dmi = pub['frame']['dmi']
    hist = number(tech['histogram']); old = number(tech['previous_histogram'])
    rsi = number(tech['rsi']); previous_rsi = number(tech['previous_rsi'])
    h = side_value(hist, side); dh = side_value(delta(hist, old), side)
    return {'ref': {'id': frame['id'], 'width_seconds': frame['width_seconds'], 'end': frame['end'], 'delivered': pub['stamp']},
        'price_known': frame['price_known'], 'hist_signed': h, 'hist_delta_signed': dh,
        'hist_atr_signed': ratio(h, number(tech['atr'])), '位相': momentum_level(h, dh),
        'gap_signed': side_value(number(tech['gap']), side),
        'ema21_delta_signed': side_value(number(tech['ema21_delta']), side),
        'rsi_center_signed': side_value(delta(rsi, 50), side),
        'rsi_delta_signed': side_value(delta(rsi, previous_rsi), side),
        'di_difference_signed': side_value(delta(number(dmi['plus_di']), number(dmi['minus_di'])), side),
        'adx': number(dmi['adx']), 'adx_delta': delta(number(dmi['adx']), number(dmi['previous_adx']))}


def collect(meta: dict, reader) -> list[dict]:
    """
    機能: Sourceの候補/短期足を26物理取得へ全件対応させる。
    引数: meta(dict)、reader(SceneReader)。返り値: list[dict]。
    """
    new = {e['candidate_id']: e for e in meta['entries'] if e['model'] == 'P0'}; rows = []
    for scene in reader:
        bars = {item['bar']['id']: item for item in scene['bars']}
        events = {e['id']: e for e in scene['events']}
        for group in scene['groups']:
            if group['status'] != 'filled': continue
            entry = new[group['id']]; assert entry['entry_quote'] == group['entryQuote']
            assert set(group['filled_candidate_ids']) == {o['id'] for o in entry['origins']}
            origins = []
            for candidate_id in group['filled_candidate_ids']:
                event = events[candidate_id]; p = bars[event['arm']['id']]; r = bars[event['confirm']['id']]
                assert event['entryQuote'] == group['entryQuote'] and event['side'] == entry['native_side']
                origins.append({'event': event, 'p': p, 'r': r})
            assert len(origins) == 1, '今回は両幅所属0という保存Sourceの前提を検査する'
            rows.append({'id': entry['id'], 'session': scene['session'], 'contract': scene['contract'],
                'entry': entry, 'origins': origins})
    assert len(rows) == len(new) == 26
    return rows


def join_background(rows: list[dict], reader) -> None:
    """
    機能: 当時参照だけを同場/契約/幅/End/配送時点の全一致で結合する。
    引数: rows(list[dict])、reader(SceneReader)。返り値: None。
    """
    by_scene = {}
    for row in rows: by_scene.setdefault(row['session'], []).append(row)
    found = set()
    for scene in reader:
        targets = by_scene.get(scene['session'], [])
        if not targets: continue
        pubs = {p['frame']['frame']['id']: p for p in scene['publications']}
        for row in targets:
            assert row['contract'] == scene['contract']; origin = row['origins'][0]; side = row['entry']['native_side']
            times = [('p', origin['p']['context']['refs'], origin['p']['context']['at']),
                     ('r', origin['r']['context']['refs'], origin['r']['context']['at']),
                     ('entry', origin['event']['refs'], row['entry']['entry_quote'])]
            origin['background'] = {}
            for stage, refs, at in times:
                latest = {}
                for ref in refs or []:
                    width = ref['width_seconds']
                    if width not in (300, 900, 1800): continue
                    pub = pubs[ref['id']]; f = pub['frame']['frame']; stamp = pub['stamp']
                    assert f['session_id'] == row['session'] and f['contract'] == row['contract']
                    assert (f['id'], f['width_seconds'], f['end'], stamp) == (ref['id'], width, ref['end'], ref['delivered'])
                    assert f['end'] <= f['available_at'] <= f['delivery_at'] <= stamp['time'] <= at['time']
                    assert stamp['index'] <= at['index'] and stamp['source_line'] <= at['source_line']
                    key = (stamp['time'], stamp['index'], stamp['source_line'], f['end'])
                    if width not in latest or key > latest[width][0]: latest[width] = (key, pub)
                assert set(latest) == {300, 900, 1800}
                origin['background'][stage] = {str(w): make_pub_features(pub, side) for w, (_, pub) in latest.items()}
                for width, features in origin['background'][stage].items():
                    features['fresh_at_stage'] = at['time'] < features['ref']['end']+int(width)+60
                    if stage == 'entry':
                        pub = latest[int(width)][1]; t = pub['frame']['frame']['technical']
                        features['ema21_minus_entry_signed'] = side_value(delta(number(t['ema21']), origin['event']['entry_price']), side)
            found.add(row['id'])
    assert len(found) == len(rows)


def technical(row: dict) -> dict:
    """
    機能: 固定済み意味区分と連続尺度を保存当時情報から求める。
    引数: row(dict)。返り値: dict。
    """
    side = row['entry']['native_side']; origin = row['origins'][0]; e = origin['event']; p = origin['p']; r = origin['r']
    st = e['structure']; entry_price = e['entry_price']; t = r['bar']['technical']; signed_hist = side_value(number(t['histogram']), side)
    ratio_short = ratio(signed_hist, number(t['atr'])); volume_ratio = ratio(r['bar']['volume'] if r['bar']['volume_known'] else None,
        p['bar']['volume'] if p['bar']['volume_known'] else None)
    background = origin['background']; hist_delta = side_value(delta(number(t['histogram']), number(p['bar']['technical']['histogram'])), side)
    width_atr = ratio(st['width'], st['arm_atr']); risk_headroom = 125-st['width']
    binder = '両方' if st['arm_atr'] == risk_headroom else 'ATR5側' if st['arm_atr'] < risk_headroom else '125-W側'
    direction = {}
    for stage, context in [('p', p['context']), ('r', r['context'])]:
        d = context['direction30']; direction[stage] = '整合' if d == side else '逆' if d == -side else 'ゼロ又は未定義'
    pub30 = background['entry']['1800']; gap, slope = pub30['gap_signed'], pub30['ema21_delta_signed']
    direction['entry'] = '未知' if gap is None or slope is None else '整合' if gap > 0 and slope > 0 else '逆' if gap < 0 and slope < 0 else 'ゼロ又は不一致'
    result = {'family': e['family'], 'width_seconds': e['width_seconds'], 'native_side': side,
        'structure': st, 'entry_price': entry_price, 'entry_Last': e['entryQuote']['last'],
        '実P_K_signed': side*(entry_price-st['k']), '実P_I_risk': side*(entry_price-st['i']),
        'W_ATR5': width_atr, 'W_ATR5区分': '1以下' if width_atr <= 1 else '1超', 'cap拘束': binder,
        'r_hist_signed': signed_hist, 'r_hist_actual_delta_signed': hist_delta,
        'r_hist_shortATR_signed': ratio_short, 'r_hist_ATR5_signed': ratio(signed_hist, st['arm_atr']),
        'r_hist短期尺度': '未知' if ratio_short is None else '0超0.1以下' if 0 < ratio_short <= .1 else '0.1超' if ratio_short > .1 else '0以下',
        'r_p_volume_ratio': volume_ratio, '量比区分': '未知' if volume_ratio is None else '1以上2未満' if 1 <= volume_ratio < 2 else '2以上' if volume_ratio >= 2 else '1未満',
        '30方向': direction, 'background': background,
        'birth': e['birth'], 'entryQuote': e['entryQuote'], 'p_ref': e['arm'], 'r_ref': e['confirm'],
        'r_end_to_birth_seconds': e['birth']['time']-r['bar']['end'], 'r_end_to_entry_seconds': e['entryQuote']['time']-r['bar']['end'],
        'p_context_at': p['context']['at'], 'r_context_at': r['context']['at']}
    return result


def main() -> None:
    """
    機能: 全26の原/実逆と当時参照の診断成果を未作成先へ保存する。
    引数: なし。返り値: None。
    """
    reader = module(READER, 'reader146financial'); arithmetic = module(CALCULATE, 'independent141frozen')
    paths = [SOURCE, META, PAIRS, BACKGROUND, READER, CALCULATE, Path(__file__), HERE/'区分と分母.md']
    hashes = {str(p): reader.file_sha(p) for p in paths}
    assert hashes[str(SOURCE)] == 'ec227abe02e77220cd7947c763cd6b7e0cc53f214d54f8faed11b1e461b78242'
    assert hashes[str(BACKGROUND)] == '6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec'
    meta = json.loads(META.read_bytes()); paired = json.loads(PAIRS.read_bytes())
    rows = collect(meta, reader.SceneReader(SOURCE)); join_background(rows, reader.SceneReader(BACKGROUND))
    cases = {c['id']: (s['session'], c) for s in paired['scenes'] for c in s['cases']}
    observations = []; groups = {'P0全26': rows}
    for row in rows:
        sid, case = cases[row['id']]; assert sid == row['session'] and case['original_side'] == row['entry']['native_side']
        assert case['original']['entry'] == row['entry']['entry_quote']
        details = technical(row); observations.append({'id': row['id'], 'session': sid, 'technical': details,
            'native': arithmetic.calculate([(sid, case)], False, 'BBO', 3600, 125),
            'inverse': arithmetic.calculate([(sid, case)], True, 'BBO', 3600, 125)})
        groups.setdefault('型:'+details['family'], []).append(row)
        for name in ('W_ATR5区分', 'cap拘束', 'r_hist短期尺度', '量比区分'):
            groups.setdefault(name+':'+details[name], []).append(row)
        for stage in ('p', 'r', 'entry'):
            groups.setdefault('30方向_'+stage+':'+details['30方向'][stage], []).append(row)
        for stage in ('p', 'r', 'entry'):
            for width in ('300', '900'):
                level = details['background'][stage][width]['位相']
                groups.setdefault('Hist位相_'+stage+'_'+width+':'+level, []).append(row)
        for width in ('300', '900'):
            for feature in ('ema21_minus_entry_signed', 'hist_signed', 'hist_delta_signed', 'rsi_delta_signed', 'di_difference_signed'):
                value = details['background']['entry'][width][feature]
                groups.setdefault('取得_'+width+'_'+feature+':'+sign(value), []).append(row)
    aggregates = {key: {side: arithmetic.calculate([cases[r['id']] for r in members], inverse, 'BBO', 3600, 125)
        for side, inverse in [('native', False), ('inverse', True)]} for key, members in groups.items()}
    assert all(reader.file_sha(p) == hashes[str(p)] for p in paths)
    result = {'成功': True, '試行': 146, '全場数': len(meta['sessions']), '取得場数': len({r['session'] for r in rows}),
        '未取得場': [s for s in meta['sessions'] if s not in {r['session'] for r in rows}],
        '区分': aggregates, '全26': observations, '金融事後診断': True, '新条件採用': False,
        '原板_CSV_追加2場読取': False, '算術': '凍結141の独立calculate。146作者集計/124算術のimportなし。', '入力指紋': hashes}
    target = HERE/'結果.json'
    with target.open('x', encoding='utf-8') as out: json.dump(result, out, ensure_ascii=False, indent=2); out.write('\n')
    print(json.dumps({'success': True, 'total': aggregates['P0全26']}, ensure_ascii=True))


if __name__ == '__main__':
    main()
