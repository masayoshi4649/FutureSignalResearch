"""146の物理数とwidth所属を再構成し、作者算術を使わず420比較する。"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import math

ROOT=Path(__file__).resolve().parent.parent
CALCULATOR=ROOT/'work/141金融集計を独立に確認する.py'
CALCULATOR_SHA='30bd4aef8c2809699cb013f930cfbce152f3986fe8d3d3cc6b49452104c2269e'


def sha(path: Path) -> str:
    """
    機能: 保存bytesの指紋を返す。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: C0/C1/width所属/P0/unionを独立構成し全420統計・参加頻度を照合する。
    引数: CLI --folder(Path)は146実行先、--output(Path)は新規証跡。
    返り値: None。Raw/CSV/Sourceを再走査せず作者124/138/146関数も使わない。
    """
    p=argparse.ArgumentParser();p.add_argument('--folder',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();own=a.folder
    paths={'f1':own/'F1金融前.json','fixed':own/'固定入力/固定取得入力.json','meta':own/'固定入力/入口参照.json',
        'pairs':own/'固定取得の正逆観測.json','summary':own/'金融評価/集計.json','calculator':CALCULATOR,'code':Path(__file__).resolve()}
    hashes={k:sha(v) for k,v in paths.items()};assert hashes['calculator']==CALCULATOR_SHA
    spec=importlib.util.spec_from_file_location('146別算術',CALCULATOR);calc=importlib.util.module_from_spec(spec);spec.loader.exec_module(calc)
    f1,fixed,meta,pairs=[json.loads(paths[n].read_bytes()) for n in ('f1','fixed','meta','pairs')]
    assert f1['試行']==meta['trial']==146 and pairs['trial']==133
    assert meta['fixed_input_sha256']==pairs['input_sha256']==hashes['fixed']
    assert all(f1['ファイル'][str(paths[n].resolve())]==hashes[n] for n in ('fixed','meta','calculator','code'))
    entries={e['id']:e for e in meta['entries']};cases={c['id']:(sc['session'],c) for sc in pairs['scenes'] for c in sc['cases']}
    assert len(entries)==len(meta['entries'])==len(cases)==fixed['expected_entry_count'] and set(entries)==set(cases)
    sessions=[sc['session'] for sc in fixed['scenes']]
    assert sessions==meta['sessions']==[sc['session'] for sc in pairs['scenes']] and len(sessions)==73
    c1={key for key,e in entries.items() if e['model']=='C1'};p0=set(entries)-c1
    members={'C0':{key for key in c1 if entries[key]['baseline']},'C1':c1,
             'M1':set(),'M3':set(),'P0':p0}
    assert len(c1)==87 and len(members['C0'])==81 and all(entries[key]['model']=='P0' for key in p0)
    physical=set();grouped={}
    for key,e in entries.items():
        sid,case=cases[key];q=e['entry_quote'];stamp=(sid,e['contract'],q['time'],q['index'],q['source_line'])
        assert e['native_side']==case['original_side'] and q==case['original']['entry']
        if key in p0:
            assert stamp not in physical;physical.add(stamp)
            assert e['origins'] and len({o['id'] for o in e['origins']})==len(e['origins'])
            widths={o['width'] for o in e['origins']};assert widths<={60,180}
            assert all(o.get('side',e['native_side'])==e['native_side'] for o in e['origins'])
            if 60 in widths:members['M1'].add(key)
            if 180 in widths:members['M3'].add(key)
            if 'widths' in e:assert set(e['widths'])==widths
        else:
            assert e['legacy_model'] in ('C0','A0','B0') and e['baseline']==(e['legacy_model']=='C0')
        grouped.setdefault(stamp,[]).append(key)
    assert members['M1']|members['M3']==p0
    canonical=set();seen_alias=set()
    for u in meta['union']:
        q=u['entry_stamp'];stamp=(u['session'],u['contract'],q['time'],q['index'],q['source_line'])
        ids=grouped.pop(stamp);want=min(ids,key=lambda key:(entries[key]['model']!='C1',key))
        assert want==u['canonical_id'] and set(ids)==set(u['alias_ids'])
        assert u['alias_sides']=={key:entries[key]['native_side'] for key in ids}
        assert not seen_alias&set(ids);seen_alias.update(ids);canonical.add(want)
    assert not grouped and seen_alias==set(entries);members['U0']=canonical
    expected={};participation={};frequency={}
    for part,subset in (('all',sessions),('train',sessions[:48]),('validation',sessions[48:])):
        expected[part]={};participation[part]={};frequency[part]={}
        hours=sum((sc['end']-300-sc['start'])/3600 for sc in fixed['scenes'] if sc['session'] in subset)
        for model,keys in members.items():
            selected=[cases[key] for key in keys if cases[key][0] in subset];present={sid for sid,_ in selected}
            participation[part][model]=(len(selected),len(present),len(present)==len(subset));frequency[part][model]=len(selected)/hours
        for policy in ('C0','C1','M1','M3','P0','U0','RU'):
            selected=[cases[key] for key in members['U0' if policy=='RU' else policy] if cases[key][0] in subset]
            expected[part][policy]={axis:{str(h):{str(w):calc.calculate(selected,policy=='RU',axis,h,w)
                for w in (25,50,100,125,200)} for h in (1800,3600)} for axis in ('BBO','Last')}
    # ----------------------------------------
    # 集合と別算術の期待値が完成してから作者summaryを開きます。
    actual=json.loads(paths['summary'].read_bytes())
    assert actual['試行']==146 and actual['F1_SHA256']==hashes['f1'] and actual['自然結果SHA256']==hashes['pairs']
    comparisons=0;cells=0
    for part,policies in expected.items():
        for policy,axes in policies.items():
            for axis,horizons in axes.items():
                for h,widths in horizons.items():
                    for w,value in widths.items():
                        got=actual['集計'][part][policy][axis][h][w];assert set(value)==set(got)
                        for name,wanted in value.items():
                            if isinstance(wanted,float):assert math.isclose(wanted,got[name],rel_tol=1e-12,abs_tol=1e-9),(part,policy,axis,h,w,name)
                            else:assert wanted==got[name],(part,policy,axis,h,w,name,wanted,got[name])
                            cells+=1
                        comparisons+=1
        for model,(count,present,all_present) in participation[part].items():
            got=actual['参加'][part][model]
            assert got['取得数']==count and got['取得場数']==present and got['全場最低1取得']==all_present
            assert math.isclose(actual['頻度'][part][model]['全時間平均件数毎時'],frequency[part][model],rel_tol=1e-12)
    assert comparisons==420 and all(sha(path)==hashes[k] for k,path in paths.items())
    report={'成功':True,'試行':146,'比較数':comparisons,'主要統計セル':cells,'基礎取得':len(cases),'P0物理取得':len(p0),
        'M1所属':len(members['M1']),'M3所属':len(members['M3']),'両width所属':len(members['M1']&members['M3']),
        'union取得':len(canonical),'全73と参加頻度':True,'物理とmembershipを分離':True,
        '作者124/138/146関数import':False,'自然Raw/CSV/Source再走査':False,
        '入力':{str(path.resolve()):hashes[k] for k,path in paths.items()},'主U0':expected['all']['U0']['BBO']['3600']['125']}
    with a.output.open('x',encoding='utf-8',newline='\n') as f:
        json.dump(report,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps({'成功':True,'比較':comparisons,'統計セル':cells,'主U0':report['主U0']},ensure_ascii=False))


if __name__=='__main__':main()
