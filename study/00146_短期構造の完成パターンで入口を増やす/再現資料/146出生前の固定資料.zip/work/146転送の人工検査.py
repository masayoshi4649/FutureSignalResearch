"""146の物理取得・所属・旧87保護を人工資料だけで検査する。"""
from pathlib import Path
import copy
import importlib.util

CODE=Path(__file__).with_name('146短期groupと旧87を固定取得へ渡す.py')
spec=importlib.util.spec_from_file_location('146転送の純部品',CODE)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


def fixture() -> tuple[dict,dict,dict]:
    """
    機能: 二場の旧対照各1件と、両widthで適格な新group各1件を作る。
    引数: なし。
    返り値: tuple[dict,dict,dict]は固定入力/旧metadata/Source。
    """
    fixed={'scenes':[],'expected_entry_count':2};meta={'trial':145,'sessions':[],'entries':[]}
    source={'success':True,'trial':146,'scenes':[]}
    for number in range(2):
        start=10000*number;sid='人工場'+str(number);contract='人工限月'
        baseq={'time':start+421,'index':501,'source_line':502,'clock':'人工価格時計',
               'last':125,'bid':120,'ask':130,'quote_ok':True}
        scene={'session':sid,'contract':contract,'start':start,'end':start+8000,'force_close':start+7900,
               'raw':{'path':'人工原板','sha256':'0'*64},'expected_quality':{'人工':True},
               'entries':[{'id':'C0/'+sid,'side':-1,'entry':copy.deepcopy(baseq)}]}
        fixed['scenes'].append(scene);meta['sessions'].append(sid)
        meta['entries'].append({'id':'C0/'+sid,'session':sid,'contract':contract,'model':'C0',
            'candidate_id':sid,'native_side':-1,'baseline':True,'entry_quote':copy.deepcopy(baseq),'origins':[{'人工旧':True}]})
        birth={**baseq,'time':start+420,'index':500,'source_line':501}
        quote=copy.deepcopy(baseq)
        if number==1:quote.update({'time':start+422,'index':502,'source_line':503})
        group={'id':sid+'/group','side':1,'birth':birth,'entryQuote':quote,
               'candidate_ids':[],'filled_candidate_ids':[],'representative_id':sid+'/A3'}
        bars=[];events=[]
        for width,family in ((60,'A1'),(180,'A3')):
            ptime=start+(300 if width==60 else 180);pindex=300 if width==60 else 100
            p={'id':sid+'/p/'+str(width),'session':sid,'contract':contract,'width_seconds':width,
               'start':ptime-width,'end':ptime,'stamp':{'time':ptime+60,'index':pindex,'source_line':pindex+1},
               'price_known':True,'closed':True,'ohlc':{'open':105,'high':110,'low':90,'close':95}}
            r={'id':sid+'/r/'+str(width),'session':sid,'contract':contract,'width_seconds':width,
               'start':ptime,'end':start+360,'stamp':{'time':start+420,'index':500,'source_line':501},
               'price_known':True,'closed':True,'ohlc':{'open':100,'high':130,'low':95,'close':125}}
            for bar in (p,r):
                bars.append({'bar':bar,'context':{'at':{**birth,'time':bar['stamp']['time'],'index':bar['stamp']['index'],
                    'source_line':bar['stamp']['source_line']},'fields':{'atr5':{'known':True,'value':50}}}})
            refs=[{'id':bar['id'],'width_seconds':width,'end':bar['end'],'delivered':copy.deepcopy(bar['stamp'])} for bar in (p,r)]
            e={'id':sid+'/'+family,'family':family,'width_seconds':width,'side':1,'status':'filled','birth':copy.deepcopy(birth),
               'entryQuote':copy.deepcopy(quote),'entry_price':130,'expires':start+450,'group_id':group['id'],
               'structure':{'k':120,'i':80,'width':40,'cap':50,'arm_atr':50,'cap_atr_width_seconds':300},
               'arm':refs[0],'confirm':refs[1],'refs':refs}
            events.append(e);group['candidate_ids'].append(e['id']);group['filled_candidate_ids'].append(e['id'])
        source['scenes'].append({'success':True,'session':sid,'contract':contract,'actual_sha256':'0'*64,
            'stat_before':{'人工':True},'stat_after':{'人工':True},'counts':{'人工':True},'bars':bars,'events':events,'groups':[group]})
    return fixed,meta,source


# ----------------------------------------
def main() -> None:
    """
    機能: 両所属で物理1件・旧対照優先・時計/個別価格/競合矛盾の拒否を確認する。
    引数: なし。fixtureのみ使用する。
    返り値: None。自然資料は開かない。
    """
    fixed,meta,source=fixture();f,r=m.build(fixed,meta,source)
    assert f['expected_entry_count']==4 and len(r['union'])==3
    p0=[e for e in r['entries'] if e['model']=='P0']
    assert len(p0)==2 and all(e['widths']==[60,180] and len(e['origins'])==2 for e in p0)
    assert r['union'][0]['canonical_id']=='C0/人工場0' and set(r['union'][0]['alias_sides'].values())=={-1,1}
    old=[e for e in r['entries'] if e['model']=='C1']
    assert all({k:v for k,v in e.items() if k!='legacy_model'}=={**meta['entries'][i],'model':'C1'} for i,e in enumerate(old))
    empty=copy.deepcopy(source)
    for sc in empty['scenes']:sc['events']=[];sc['groups']=[];sc['bars']=[]
    ef,em=m.build(fixed,meta,empty)
    assert ef==fixed and len(em['union'])==2
    kinds=('逆方向候補混入','代表が1分優先','片候補P域外','filled欠落','物理重複','p知得未来',
           'p/r同Raw','pATR差替え','構造I差替え','TTL等号','数値助走を5分へ代用','候補bool方向')
    for kind in kinds:
        changed=copy.deepcopy(source);sc=changed['scenes'][0];e=sc['events'][0];g=sc['groups'][0]
        if kind=='逆方向候補混入':e['side']=-1
        elif kind=='代表が1分優先':g['representative_id']=e['id']
        elif kind=='片候補P域外':e['structure']['arm_atr']=5;e['structure']['cap']=5
        elif kind=='filled欠落':g['filled_candidate_ids'].remove(e['id'])
        elif kind=='物理重複':
            ng=copy.deepcopy(g);ng['id']='別group';ng['candidate_ids']=[];ng['filled_candidate_ids']=[]
            for original in list(sc['events']):
                ne=copy.deepcopy(original);ne['id']='別/'+ne['id'];ne['group_id']=ng['id'];sc['events'].append(ne)
                ng['candidate_ids'].append(ne['id']);ng['filled_candidate_ids'].append(ne['id'])
            ng['representative_id']='別/'+g['representative_id'];sc['groups'].append(ng)
        elif kind=='p知得未来':sc['bars'][0]['context']['at']['time']=1000
        elif kind=='p/r同Raw':
            sc['bars'][0]['bar']['stamp']=copy.deepcopy(sc['bars'][1]['bar']['stamp'])
            sc['bars'][0]['context']['at']=copy.deepcopy(sc['bars'][1]['context']['at'])
            e['arm']['delivered']=copy.deepcopy(sc['bars'][0]['bar']['stamp'])
        elif kind=='pATR差替え':sc['bars'][0]['context']['fields']['atr5']['value']=51
        elif kind=='構造I差替え':e['structure'].update({'i':79,'width':41})
        elif kind=='TTL等号':e['entryQuote']['time']=e['expires'];g['entryQuote']['time']=e['expires']
        elif kind=='数値助走を5分へ代用':e['structure']['cap_atr_width_seconds']=60
        else:e['side']=True
        try:m.build(fixed,meta,changed)
        except AssertionError:pass
        else:raise AssertionError('拒否漏れ: '+kind)
    print('人工14群成功。自然Raw/CSV/金融未読。')


if __name__=='__main__':main()
