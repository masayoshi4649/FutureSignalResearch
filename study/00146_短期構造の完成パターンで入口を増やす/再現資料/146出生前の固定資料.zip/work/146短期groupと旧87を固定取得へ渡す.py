"""146の候補所属と物理取得を分け、旧87を保護して固定133形式へ転送する。"""
from pathlib import Path
import argparse
import copy
import hashlib
import json
import math

ROOT=Path(__file__).resolve().parent.parent
OLD_FIXED=ROOT/'work/145構造イベントの評価/固定入力/固定取得入力.json'
OLD_META=ROOT/'work/145構造イベントの評価/固定入力/入口参照.json'
SHAS={OLD_FIXED:'d2becb3b1d6de656a6cc3f04d576d95d99693dfc42efc03582ed04d2be8784e8',
      OLD_META:'3a3a144c478fa45f85e03ad4b8e4461e420592da24088458c7aa1cb748c8eb8d'}
QUOTE_FIELDS=('time','index','source_line','last','bid','ask','quote_ok','clock')


def sha(path: Path) -> str:
    """
    機能: 保存bytesの指紋を返す。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def save(path: Path,value: dict) -> None:
    """
    機能: UTF-8 JSONを未作成先へ保存する。
    引数: path(Path)、value(dict)は保存先と値。
    返り値: None。
    """
    with path.open('x',encoding='utf-8',newline='\n') as f:
        json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')


# ----------------------------------------
def stamp_key(sid: str,contract: str,q: dict) -> tuple:
    """
    機能: 売買方向を加えず物理取得原行を識別する。
    引数: sid/contract(str)、q(dict)は場と取得Quote。
    返り値: tupleは場/限月/time/index/line。
    """
    return sid,contract,q['time'],q['index'],q['source_line']


# ----------------------------------------
def validate_event(e: dict,group: dict,bars: dict,scene: dict) -> None:
    """
    機能: 候補の個別実P適格性・固定構造とp/r知得を検査する。
    引数: e/group/bars/scene(dict)はSource保存票。
    返り値: None。不一致はAssertionErrorで拒否する。
    """
    required={'id','family','width_seconds','side','status','birth','entryQuote','entry_price','expires',
              'group_id','structure','arm','confirm','refs'}
    assert required<=e.keys() and e['status']=='filled' and e['group_id']==group['id']
    assert e['family'] in ('A1','A3','B1','B3') and type(e['side']) is int and e['side'] in (-1,1)
    width=60 if e['family'].endswith('1') else 180
    assert e['width_seconds']==width and e['side']==group['side']
    b,q=e['birth'],e['entryQuote'];s=e['side'];v=e['structure']
    assert all(e['entryQuote'][k]==group['entryQuote'][k] for k in QUOTE_FIELDS)
    assert all(b[k]==group['birth'][k] for k in QUOTE_FIELDS)
    assert q['clock'] and b['clock'] and q['quote_ok'] and 0<q['bid']<q['ask']
    limit=min(scene['force_close'],scene['end']-3900)
    assert b['time']<e['expires']<=min(b['time']+30,limit)
    assert b['time']+1<=q['time']<e['expires'] and q['index']>b['index'] and q['source_line']>b['source_line']
    assert v['cap_atr_width_seconds']==300
    assert all(type(v[k]) in (int,float) and math.isfinite(v[k]) for k in ('k','i','width','cap','arm_atr'))
    assert 0<v['width']<=125 and v['arm_atr']>0
    assert math.isclose(v['width'],s*(v['k']-v['i']),abs_tol=1e-9)
    assert math.isclose(v['cap'],min(v['arm_atr'],125-v['width']),abs_tol=1e-9)
    price=q['ask'] if s==1 else q['bid']
    assert price==e['entry_price'] and all(0<=s*(x-v['k'])<=v['cap'] for x in (b['last'],q['last'],price))
    assert 0<s*(price-v['i'])<=125
    selected=[]
    for ref in (e['arm'],e['confirm']):
        record=bars[ref['id']];bar=record['bar'];ctx=record['context']
        assert ref['width_seconds']==bar['width_seconds']==width and ref['end']==bar['end']
        assert ref['delivered']==bar['stamp']
        assert bar['session']==scene['session'] and bar['contract']==scene['contract']
        assert bar['price_known'] and bar['closed'] and bar['end']==bar['start']+width
        assert bar['stamp']['time']==ctx['at']['time'] and bar['stamp']['index']==ctx['at']['index']
        assert bar['stamp']['time']<=b['time'] and bar['stamp']['index']<=b['index'] and bar['stamp']['source_line']<=b['source_line']
        selected.append(record)
    p,r=[record['bar'] for record in selected]
    assert p['end']==r['start'] and p['stamp']['time']<r['stamp']['time'] and p['stamp']['index']<r['stamp']['index']
    assert r['stamp']['time']==b['time'] and r['stamp']['index']==b['index']
    op,orr=p['ohlc'],r['ohlc']
    want_k=op['high']+10 if s==1 else op['low']-10
    want_i=min(op['low'],orr['low'])-10 if s==1 else max(op['high'],orr['high'])+10
    assert v['k']==want_k and v['i']==want_i
    atr=selected[0]['context']['fields']['atr5']
    assert atr['known'] and atr['value']==v['arm_atr']


# ----------------------------------------
def build(old_fixed: dict,old_meta: dict,source: dict) -> tuple[dict,dict]:
    """
    機能: 旧87全値と新groupを保持し、width所属を物理取得へ束ねる。
    引数: old_fixed/old_meta/source(dict)は145固定票と146Source。
    返り値: tuple[dict,dict]は固定入力とmembership参照。金融を読まない。
    """
    assert old_meta['trial']==145 and source['success'] and source['trial']==146
    sessions=[s['session'] for s in old_fixed['scenes']]
    assert sessions==old_meta['sessions']==[s['session'] for s in source['scenes']]
    old_entries={e['id']:e for e in old_meta['entries']}
    assert len(old_entries)==old_fixed['expected_entry_count']
    by_scene={sid:[] for sid in sessions};specs={s['session']:s for s in old_fixed['scenes']}
    for e in old_meta['entries']:
        item=copy.deepcopy(e);item['legacy_model']=item['model'];item['model']='C1'
        assert item['legacy_model'] in ('C0','A0','B0') and item['baseline']==(item['legacy_model']=='C0')
        by_scene[item['session']].append(item)
    for sc in source['scenes']:
        sid=sc['session'];scene=specs[sid]
        assert sc['success'] and sc['stat_before']==sc['stat_after'] and sc['counts']==scene['expected_quality']
        assert sc['contract']==scene['contract'] and sc['actual_sha256']==scene['raw']['sha256']
        assert all(isinstance(sc[k],list) for k in ('events','groups','bars'))
        events={e['id']:e for e in sc['events']};bars={e['bar']['id']:e for e in sc['bars']}
        assert len(events)==len(sc['events']) and len(bars)==len(sc['bars'])
        seen_groups=set();used=set();physical=set()
        for gi,g in enumerate(sc['groups']):
            assert g['id'] not in seen_groups;seen_groups.add(g['id'])
            candidate_ids=g['candidate_ids'];filled=g['filled_candidate_ids']
            assert len(set(candidate_ids))==len(candidate_ids) and set(candidate_ids)<=set(events)
            assert len(set(filled))==len(filled) and set(filled)<=set(candidate_ids)
            assert {key for key in candidate_ids if events[key]['status']=='filled'}==set(filled)
            if not filled:continue
            assert g['entryQuote'] is not None and type(g['side']) is int and g['side'] in (-1,1)
            assert not set(filled)&used;used.update(filled)
            quote=g['entryQuote'];key=stamp_key(sid,sc['contract'],quote)
            assert key not in physical;physical.add(key)
            candidates=[events[key] for key in filled]
            for e in candidates:validate_event(e,g,bars,scene)
            chosen=min(candidates,key=lambda e:(-e['width_seconds'],e['family'][0]!='A',e['id']))
            assert g['representative_id']==chosen['id']
            origins=[{'id':e['id'],'family':e['family'],'width':e['width_seconds'],'side':e['side'],
                'source_locator':{'scene':sid,'group_index':gi,'candidate_id':e['id']},
                'birthQuote':copy.deepcopy(e['birth']),'structure':copy.deepcopy(e['structure']),
                'arm':copy.deepcopy(e['arm']),'confirm':copy.deepcopy(e['confirm']),
                'refs':copy.deepcopy(e['refs']),'refs_asof':'取得時点まで。短期bars/contextは各初回配送時点'} for e in candidates]
            by_scene[sid].append({'id':'P0/'+g['id'],'session':sid,'contract':sc['contract'],'model':'P0',
                'candidate_id':g['id'],'native_side':g['side'],'baseline':False,'entry_quote':copy.deepcopy(quote),
                'origins':origins,'widths':sorted({o['width'] for o in origins})})
        assert used=={key for key,e in events.items() if e['status']=='filled'}
    fixed={'scenes':[],'expected_entry_count':0}
    meta={'success':True,'trial':146,'sessions':sessions,'entries':[],'union':[],
        'dedup_key':'session/contract/取得time/index/source_line','dedup_priority':'C1→P0',
        'policies':['C0','C1','M1','M3','P0','U0','RU'],'financial_labels_used':False,'portfolio_replay':False}
    seen=set()
    for original in old_fixed['scenes']:
        sc=copy.deepcopy(original);sid=sc['session'];sc['entries']=[];grouped={};per_model=set()
        for e in sorted(by_scene[sid],key=lambda e:(e['entry_quote']['index'],e['model']!='C1',e['id'])):
            q=e['entry_quote'];key=stamp_key(sid,e['contract'],q)
            assert e['id'] not in seen and type(e['native_side']) is int and e['native_side'] in (-1,1)
            assert e['contract']==sc['contract'] and q['clock'] and q['quote_ok'] and 0<q['bid']<q['ask']
            assert sc['start']<=q['time']<min(sc['force_close'],sc['end']-3900)
            assert (e['model'],key) not in per_model
            per_model.add((e['model'],key));seen.add(e['id'])
            sc['entries'].append({'id':e['id'],'side':e['native_side'],'entry':copy.deepcopy(q)})
            meta['entries'].append(e);grouped.setdefault(key,[]).append(e)
        for key,items in grouped.items():
            chosen=min(items,key=lambda e:(e['model']!='C1',e['id']))
            assert all(all(e['entry_quote'][k]==chosen['entry_quote'][k] for k in QUOTE_FIELDS) for e in items)
            meta['union'].append({'canonical_id':chosen['id'],'alias_ids':[e['id'] for e in items],
                'alias_sides':{e['id']:e['native_side'] for e in items},'session':sid,'contract':sc['contract'],
                'entry_stamp':{'time':key[2],'index':key[3],'source_line':key[4]}})
        fixed['scenes'].append(sc);fixed['expected_entry_count']+=len(sc['entries'])
    before={(sc['session'],e['id']):e for sc in old_fixed['scenes'] for e in sc['entries']}
    after={(sc['session'],e['id']):e for sc in fixed['scenes'] for e in sc['entries'] if e['id'] in old_entries}
    assert before==after
    return fixed,meta


# ----------------------------------------
def main() -> None:
    """
    機能: F0と全入力指紋を照合し、旧87と新物理取得を金融前に保存する。
    引数: CLI f0/source/output-dir(Path)及び対応SHA(str)。
    返り値: None。新旧金融・原板・価格CSVを開かない。
    """
    p=argparse.ArgumentParser(description='146短期groupと旧87の非金融転送')
    for key in ('f0','source','output-dir'):p.add_argument('--'+key,type=Path,required=True)
    p.add_argument('--f0-sha256',required=True);p.add_argument('--sha256',required=True);args=p.parse_args()
    assert sha(args.f0)==args.f0_sha256 and sha(args.source)==args.sha256
    frozen=json.loads(args.f0.read_bytes());assert frozen['成功'] and frozen['試行']==146
    assert all(sha(Path(n))==h for n,h in frozen['ファイル'].items())
    assert frozen['ファイル'][str(Path(__file__).resolve())]==sha(Path(__file__).resolve())
    for path,h in SHAS.items():assert sha(path)==frozen['ファイル'][str(path)]==h
    fixed,meta=build(json.loads(OLD_FIXED.read_bytes()),json.loads(OLD_META.read_bytes()),json.loads(args.source.read_bytes()))
    assert sum(e['model']=='C1' for e in meta['entries'])==87 and sum(e['model']=='C1' and e['baseline'] for e in meta['entries'])==81
    for e in meta['entries']:
        if e['model']=='P0':
            for o in e['origins']:o['source_file_sha']=args.sha256
    dest=args.output_dir;dest.mkdir(parents=True,exist_ok=True)
    assert not any((dest/n).exists() for n in ('固定取得入力.json','入口参照.json','転送の確認.json'))
    save(dest/'固定取得入力.json',fixed)
    meta.update({'fixed_input_sha256':sha(dest/'固定取得入力.json'),'source_sha256':args.sha256,
                 'old_fixed_sha256':SHAS[OLD_FIXED],'old_metadata_sha256':SHAS[OLD_META]})
    save(dest/'入口参照.json',meta)
    assert all(sha(Path(n))==h for n,h in frozen['ファイル'].items())
    p0=[e for e in meta['entries'] if e['model']=='P0']
    result={'成功':True,'試行':146,'F0_SHA256':args.f0_sha256,'Source_SHA256':args.sha256,'旧87同体':True,
        '基礎C1':87,'P0物理取得':len(p0),'M1所属':sum(60 in e['widths'] for e in p0),
        'M3所属':sum(180 in e['widths'] for e in p0),'union取得':len(meta['union']),'金融参照':False,
        '固定入力SHA256':meta['fixed_input_sha256'],'入口参照SHA256':sha(dest/'入口参照.json')}
    save(dest/'転送の確認.json',result);print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':main()
