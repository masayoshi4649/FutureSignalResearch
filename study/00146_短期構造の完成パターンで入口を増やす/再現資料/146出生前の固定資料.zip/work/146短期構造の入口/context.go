package shortpattern146

import (
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"math"
)

// finite は時計・価格・派生値の有限性を確認します。
//
// 引数: values(...float64)。返り値: boolです。
func finite(values ...float64) bool {
	for _, v := range values {
		if math.IsNaN(v) || math.IsInf(v, 0) {
			return false
		}
	}
	return true
}

// normal は受信時計を仮定せず保存された最良BBOだけを確認します。
//
// 引数: q(Quote)。返り値: boolです。
func normal(q Quote) bool { return finite(q.Bid, q.Ask) && q.Bid > 0 && q.Ask > q.Bid }

// v は有限の既知値を作り非有限値を未知へします。
//
// 引数: x(float64)。返り値: rules.Valueです。
func v(x float64) rules.Value {
	if !finite(x) {
		return rules.Value{}
	}
	return rules.Value{Known: true, Value: x}
}

// diff は既知の両端の差だけを計算します。
//
// 引数: a/b(rules.Value)。返り値: rules.Valueです。
func diff(a, b rules.Value) rules.Value {
	if !a.Known || !b.Known {
		return rules.Value{}
	}
	return v(a.Value - b.Value)
}

// rq は背景Bankの要求型へ同一価格時計を写します。
//
// 引数: q(Quote)。返り値: rules.Quoteです。
func rq(q Quote) rules.Quote {
	return rules.Quote{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine), Last: q.Last}
}

// sign はゼロを方向なしとする符号です。
//
// 引数: x(float64)。返り値: intは−1/0/1です。
func sign(x float64) int {
	if x > 0 {
		return 1
	}
	if x < 0 {
		return -1
	}
	return 0
}

// merge は参照の全値を保ちID単位で重複を除きます。
//
// 引数: groups(...[]rules.Ref)。返り値: []rules.Refです。
func merge(groups ...[]rules.Ref) []rules.Ref {
	out := []rules.Ref{}
	seen := map[string]rules.Ref{}
	for _, g := range groups {
		for _, r := range g {
			if _, ok := seen[r.ID]; !ok {
				seen[r.ID] = r
				out = append(out, r)
			}
		}
	}
	return out
}

// makeContext は初回知得又は現在Rawの背景を独立mapへ凍結します。
//
// 引数: s(rules.Snapshot)、q(Quote)。返り値: Contextです。
func makeContext(s rules.Snapshot, q Quote) Context {
	c := Context{At: q, Fields: map[string]rules.Value{}, Refs: append([]rules.Ref(nil), s.Refs...)}
	for _, w := range []int{300, 900, 1800} {
		p, ok := s.Frames[w]
		known := ok && p.Frame.Frame.PriceKnown && q.Time < p.Frame.Frame.End+float64(w)+60
		c.Fields[fmt.Sprintf("price_known_%d", w)] = v(0)
		if known {
			c.Fields[fmt.Sprintf("price_known_%d", w)] = v(1)
		}
	}
	t := s.Frames[1800].Frame.Frame.Technical
	di := s.Frames[900].Frame.DMI
	c.Fields["gap30"], c.Fields["ema21_delta30"] = t.Gap, t.EMA21Delta
	c.Fields["plus_di15"], c.Fields["minus_di15"], c.Fields["adx15"], c.Fields["previous_adx15"] = di.PlusDI, di.MinusDI, di.ADX, di.PreviousADX
	c.Fields["di_difference15"], c.Fields["adx_delta15"] = diff(di.PlusDI, di.MinusDI), diff(di.ADX, di.PreviousADX)
	c.Fields["atr5"] = s.Frames[300].Frame.Frame.Technical.ATR
	if t.Gap.Known && t.EMA21Delta.Known && sign(t.Gap.Value) != 0 && sign(t.Gap.Value) == sign(t.EMA21Delta.Value) {
		c.Direction30 = sign(t.Gap.Value)
	}
	return c
}

// contextPass は145と同じA/B背景を初知と現在で区別して検査します。
//
// 引数: c(Context)、family(string)、side(int)、initial(bool)。返り値: boolです。
func contextPass(c Context, family string, side int, initial bool) bool {
	for _, w := range []int{300, 900, 1800} {
		x := c.Fields[fmt.Sprintf("price_known_%d", w)]
		if !x.Known || x.Value != 1 {
			return false
		}
	}
	for _, key := range []string{"gap30", "ema21_delta30", "adx15", "previous_adx15", "adx_delta15"} {
		if !c.Fields[key].Known {
			return false
		}
	}
	if family[0] == 'A' {
		di := c.Fields["di_difference15"]
		return side != 0 && c.Direction30 == side && di.Known && float64(side)*di.Value > 0 && c.Fields["adx_delta15"].Value >= 0
	}
	return c.Fields["adx_delta15"].Value < 0 && (!initial || (c.Direction30 != 0 && side == -c.Direction30))
}

// validateSnapshot は外部から渡す現在公表の因果とScopeを確認します。
//
// 引数: snapshot(rules.Snapshot)、q(Quote)、scene(Scene)。返り値: errorです。
func validateSnapshot(snapshot rules.Snapshot, q Quote, scene Scene) error {
	if snapshot.SessionID != scene.Session || snapshot.Contract != scene.Contract || snapshot.AsOf != rq(q) {
		return fmt.Errorf("現在Snapshotのscope/原行差")
	}
	for width, p := range snapshot.Frames {
		f := p.Frame.Frame
		if f.SessionID != scene.Session || f.Contract != scene.Contract || f.Width != width || (width != 300 && width != 900 && width != 1800) || f.End > q.Time || f.End > f.AvailableAt || f.AvailableAt > f.DeliveryAt || f.DeliveryAt > p.Stamp.Time || p.Stamp.Time > q.Time || p.Stamp.Index > int(q.Index) || p.Stamp.Line > int(q.SourceLine) {
			return fmt.Errorf("現在背景の未来参照又はScope差")
		}
	}
	return nil
}

// position はKから有利側cap以内を等号込みで確認します。
//
// 引数: side(int)、price(float64)、s(Structure)。返り値: boolです。
func position(side int, price float64, s Structure) bool {
	d := float64(side) * (price - s.K)
	return finite(price, d) && d >= 0 && d <= s.Cap
}
