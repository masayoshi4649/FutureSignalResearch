package basenumeric

type pivotBar struct {
	Ref  BarRef
	OHLC OHLC
}

type scaleState struct {
	Numeric   numeric
	Ring      [5]pivotBar
	RingCount int
	High      Pivot
	Low       Pivot
	HasAny    bool
}

// makePivot は確認時計と左右の実公表出典を付けたpivotを作ります。
//
// 引数: ring([5]pivotBar)、kind(string)、at(float64)は連続5足と今回の配送時計です。
// 返り値: Pivotは左2足strict/右2足tiesが成立した場合だけ既知です。
func makePivot(ring [5]pivotBar, kind string, at float64) Pivot {
	center := ring[2]
	price := center.OHLC.High
	passed := center.OHLC.High > ring[0].OHLC.High && center.OHLC.High > ring[1].OHLC.High && center.OHLC.High >= ring[3].OHLC.High && center.OHLC.High >= ring[4].OHLC.High
	if kind == "low" {
		price = center.OHLC.Low
		passed = center.OHLC.Low < ring[0].OHLC.Low && center.OHLC.Low < ring[1].OHLC.Low && center.OHLC.Low <= ring[3].OHLC.Low && center.OHLC.Low <= ring[4].OHLC.Low
	}
	if !passed {
		return Pivot{}
	}
	return Pivot{Known: true, Kind: kind, Price: price, CenterID: center.Ref.ID, CenterStart: center.Ref.Start, CenterEnd: center.Ref.End,
		ConfirmID: ring[4].Ref.ID, ConfirmEnd: ring[4].Ref.End, PublishedAt: at,
		Left: [2]BarRef{ring[0].Ref, ring[1].Ref}, Right: [2]BarRef{ring[3].Ref, ring[4].Ref}}
}

// apply は当場の連続足から数値と確認済みpivotを更新します。
//
// 引数: frame(Frame)は今回配送する価格/量の判明した足です。
// 返り値: Frameはprior/newを分けて指標を凍結した値です。
func (s *scaleState) apply(frame Frame) Frame {
	if !frame.PriceKnown {
		*s = scaleState{Numeric: freshNumeric(), HasAny: true}
		return frame
	}
	frame.PriorHigh, frame.PriorLow = s.High, s.Low
	frame.Technical = s.Numeric.apply(frame.OHLC, !s.HasAny)
	s.HasAny = true
	if s.RingCount < len(s.Ring) {
		s.Ring[s.RingCount] = pivotBar{BarRef{frame.ID, frame.Start, frame.End, frame.DeliveryAt}, frame.OHLC}
		s.RingCount++
	} else {
		copy(s.Ring[:4], s.Ring[1:])
		s.Ring[4] = pivotBar{BarRef{frame.ID, frame.Start, frame.End, frame.DeliveryAt}, frame.OHLC}
	}
	if s.RingCount == 5 {
		frame.NewHigh, frame.NewLow = makePivot(s.Ring, "high", frame.DeliveryAt), makePivot(s.Ring, "low", frame.DeliveryAt)
		if frame.NewHigh.Known {
			s.High = frame.NewHigh
		}
		if frame.NewLow.Known {
			s.Low = frame.NewLow
		}
	}
	return frame
}
