package basenumeric

import "math"

type mean struct {
	Period int
	Count  int
	Sum    float64
	Value  float64
	Known  bool
}

// updateEMA は初期SMAが揃った後だけEMAを更新します。
//
// 引数: x(float64)は正常終値又はMACDです。
// 返り値: ありません。期間前の途中平均を既知にしません。
func (m *mean) updateEMA(x float64) {
	if !m.Known {
		m.Count++
		m.Sum += x
		if m.Count == m.Period {
			m.Value, m.Known = m.Sum/float64(m.Period), true
		}
		return
	}
	m.Value += 2 / float64(m.Period+1) * (x - m.Value)
}

// updateWilder は初期SMAの後にWilder平均を更新します。
//
// 引数: x(float64)はTR又は価格差の正負成分です。
// 返り値: ありません。
func (m *mean) updateWilder(x float64) {
	if !m.Known {
		m.Count++
		m.Sum += x
		if m.Count == m.Period {
			m.Value, m.Known = m.Sum/float64(m.Period), true
		}
		return
	}
	m.Value = (m.Value*float64(m.Period-1) + x) / float64(m.Period)
}

// public は未知値を意味のあるゼロへ誤読させない型へ変換します。
//
// 引数: ありません。
// 返り値: Valueは既知性と既知の数値です。
func (m mean) public() Value {
	if !m.Known {
		return Value{}
	}
	return Value{true, m.Value}
}

type numeric struct {
	EMA8, EMA21, EMA12, EMA26, Signal mean
	Gain, Loss, ATR                   mean
	PreviousClose                     float64
	HasPreviousClose                  bool
	Histogram                         Value
	RSI                               Value
	Bars                              uint64
	Latest                            Technical
}

// freshNumeric は全て未知の同一定義の数値器を作ります。
//
// 引数: ありません。
// 返り値: numericは外部参照を持たない初期状態です。
func freshNumeric() numeric {
	return numeric{
		EMA8: mean{Period: 8}, EMA21: mean{Period: 21}, EMA12: mean{Period: 12}, EMA26: mean{Period: 26}, Signal: mean{Period: 9},
		Gain: mean{Period: 14}, Loss: mean{Period: 14}, ATR: mean{Period: 14},
	}
}

// difference は両端が既知の1足変化だけを返します。
//
// 引数: now/previous(Value)は今回値と直前足の値です。
// 返り値: Valueは差又は未知です。
func difference(now, previous Value) Value {
	if !now.Known || !previous.Known {
		return Value{}
	}
	return Value{true, now.Value - previous.Value}
}

// normalize は同じ確定足の既知で正のATRでだけ正規化します。
//
// 引数: value/atr(Value)は差と公表ATRです。
// 返り値: Valueは無次元値又は未知です。
func normalize(value, atr Value) Value {
	if !value.Known || !atr.Known || atr.Value <= 0 {
		return Value{}
	}
	return Value{true, value.Value / atr.Value}
}

// apply は一つの正常確定足を一度だけ数値器へ入力します。
//
// 引数: bar(OHLC)、firstInSession(bool)は確定価格と当場最初の公表指定です。
// 返り値: Technicalは今回の前値・傾き・数値履歴を含む値copyです。
func (n *numeric) apply(bar OHLC, firstInSession bool) Technical {
	t := Technical{PreviousEMA8: n.EMA8.public(), PreviousEMA21: n.EMA21.public(), PreviousATR: n.ATR.public(), PreviousRSI: n.RSI, PreviousHistogram: n.Histogram}
	tr := bar.High - bar.Low
	if n.HasPreviousClose {
		tr = math.Max(tr, math.Max(math.Abs(bar.High-n.PreviousClose), math.Abs(bar.Low-n.PreviousClose)))
		change := bar.Close - n.PreviousClose
		n.Gain.updateWilder(math.Max(change, 0))
		n.Loss.updateWilder(math.Max(-change, 0))
		if firstInSession {
			t.CrossSessionJump = Value{true, bar.Open - n.PreviousClose}
		}
	}
	n.ATR.updateWilder(tr)
	// ----------------------------------------
	// 平均値の並びと傾きを構成する価格EMAを更新します。
	n.EMA8.updateEMA(bar.Close)
	n.EMA21.updateEMA(bar.Close)
	n.EMA12.updateEMA(bar.Close)
	n.EMA26.updateEMA(bar.Close)
	// ----------------------------------------
	// RSIとMACDは価格平均の独立票とせず、各々の既知性を保持します。
	if n.Gain.Known && n.Loss.Known {
		rsi := 50.0
		if n.Loss.Value == 0 && n.Gain.Value > 0 {
			rsi = 100
		} else if n.Loss.Value > 0 {
			rsi = 100 - 100/(1+n.Gain.Value/n.Loss.Value)
		}
		n.RSI = Value{true, rsi}
	}
	if n.EMA12.Known && n.EMA26.Known {
		macd := n.EMA12.Value - n.EMA26.Value
		n.Signal.updateEMA(macd)
		if n.Signal.Known {
			n.Histogram = Value{true, macd - n.Signal.Value}
		}
	}
	// ----------------------------------------
	// 今回足と前足の差、同じ尺度のATRによる正規化を公開します。
	n.PreviousClose, n.HasPreviousClose = bar.Close, true
	n.Bars++
	t.HistoryBars = n.Bars
	t.EMA8, t.EMA21, t.ATR, t.TR = n.EMA8.public(), n.EMA21.public(), n.ATR.public(), Value{true, tr}
	t.EMA8Delta, t.EMA21Delta = difference(t.EMA8, t.PreviousEMA8), difference(t.EMA21, t.PreviousEMA21)
	t.Gap = difference(t.EMA8, t.EMA21)
	t.GapATR, t.EMA8DeltaATR, t.EMA21DeltaATR = normalize(t.Gap, t.ATR), normalize(t.EMA8Delta, t.ATR), normalize(t.EMA21Delta, t.ATR)
	t.RSI, t.Histogram = n.RSI, n.Histogram
	n.Latest = t
	return t
}
