package basenumeric

import (
	"encoding/json"
	"fmt"
	"math"
	"reflect"

	old "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
)

type State struct{ state scaleState }

// StartSession は数値だけを任意に継承し当場構造を消去します。
//
// 引数: carry(bool)は同限月のRaw由来数値を継承する指定。返り値: なし。
func (s *State) StartSession(carry bool) {
	n := freshNumeric()
	if carry {
		n = s.state.Numeric
	}
	s.state = scaleState{Numeric: n}
}

// allFinite は私有途中和も含む全浮動値を検査します。
//
// 引数: v(reflect.Value)は数値状態。返り値: boolは全浮動値が有限なら真。
func allFinite(v reflect.Value) bool {
	switch v.Kind() {
	case reflect.Float32, reflect.Float64:
		return !math.IsNaN(v.Float()) && !math.IsInf(v.Float(), 0)
	case reflect.Struct:
		for i := 0; i < v.NumField(); i++ {
			if !allFinite(v.Field(i)) {
				return false
			}
		}
	case reflect.Array:
		for i := 0; i < v.Len(); i++ {
			if !allFinite(v.Index(i)) {
				return false
			}
		}
	}
	return true
}

// Apply は確定Frameを原文数値器へ一度だけ入力します。
//
// 引数: f(old.Frame)は因果的に閉鎖済みの足。返り値: old.Frame/errorは数値付き足又は原子拒否。
func (s *State) Apply(f old.Frame) (old.Frame, error) {
	next := s.state
	body, err := json.Marshal(f)
	if err != nil {
		return old.Frame{}, err
	}
	var own Frame
	if err = json.Unmarshal(body, &own); err != nil {
		return old.Frame{}, err
	}
	result := next.apply(own)
	if !allFinite(reflect.ValueOf(next)) || !allFinite(reflect.ValueOf(result.Technical)) {
		return old.Frame{}, fmt.Errorf("Raw足の旧数値器が非有限")
	}
	body, err = json.Marshal(result)
	if err != nil {
		return old.Frame{}, err
	}
	var output old.Frame
	err = json.Unmarshal(body, &output)
	if err == nil {
		s.state = next
	}
	return output, err
}
