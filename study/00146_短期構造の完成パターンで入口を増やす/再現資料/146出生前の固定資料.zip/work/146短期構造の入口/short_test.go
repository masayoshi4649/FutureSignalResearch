package shortpattern146

import (
	"encoding/json"
	"fmt"
	"math"
	"testing"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// minute146 は、実データを使わない因果的な確定1分を作ります。
//
// 引数: session/contract(string)、start(float64)、number(int)、close(float64)は場と足位置/価格です。
// 返り値: Minute はEnd+60のモデル配送と正常OHLC/既知量を持ちます。
func minute146(session, contract string, start float64, number int, close float64) Minute {
	from := start + float64(number-1)*60
	return Minute{ID: fmt.Sprintf("%s/m%d", session, number), Session: session, Contract: contract,
		Start: from, End: from + 60, AvailableAt: from + 120,
		OHLC:   rules.OHLC{Open: close - 1, High: close + 3, Low: close - 4, Close: close},
		Volume: float64(number), PriceKnown: true, VolumeKnown: true, Closed: true,
		Stamp: rules.Stamp{Time: from + 120, Index: number, Line: number + 1}, CSVLine: number + 1}
}

// mustAdd146 は、純数値人工で一足を正常配送します。
//
// 引数: t(*testing.T)、tracker(*ShortTracker)、minute(Minute)は検査と人工足です。
// 返り値: []ShortBar は形成した短期足です。
func mustAdd146(t *testing.T, tracker *ShortTracker, minute Minute) []ShortBar {
	t.Helper()
	bars, err := tracker.Add(minute)
	if err != nil {
		t.Fatal(err)
	}
	return bars
}

// TestShort146StrictThree は、正確三本・半開境界・端数と同Raw子参照を確認します。
//
// 引数: t(*testing.T)は人工検査です。
// 返り値: ありません。不一致時は失敗します。
func TestShort146StrictThree(t *testing.T) {
	x := NewShort()
	if err := x.StartSession("S", "C", 0, 300, false); err != nil {
		t.Fatal(err)
	}
	var three ShortBar
	for i := 1; i <= 5; i++ {
		m := minute146("S", "C", 0, i, float64(100+i))
		if i <= 3 {
			m.Stamp = rules.Stamp{Time: 240, Index: 3, Line: 4}
		}
		m.Volume = 0
		out := mustAdd146(t, x, m)
		if i == 3 {
			if len(out) != 2 {
				t.Fatal("3本端で3分がない")
			}
			three = out[1]
		} else if len(out) != 1 {
			t.Fatal("端数又は途中の3分を生成")
		}
	}
	if three.Start != 0 || three.End != 180 || three.AvailableAt != 240 || three.Stamp.Index != 3 || len(three.Children) != 3 {
		t.Fatal(three)
	}
	if three.OHLC != (rules.OHLC{Open: 100, High: 106, Low: 97, Close: 103}) || !three.PriceKnown || !three.VolumeKnown || three.Volume != 0 {
		t.Fatal(three)
	}
	if x.Stats()["bars_3m"] != 1 || x.Stats()["partial_3m_minutes"] != 2 {
		t.Fatal(x.Stats())
	}
	stats := x.Stats()
	stats["minutes"] = 999
	if x.Stats()["minutes"] != 5 {
		t.Fatal("Statsが共有map")
	}
}

// TestShort146SeparateWarmup は、1分と3分の助走を独立した実本数で検査します。
//
// 引数: t(*testing.T)は人工検査です。
// 返り値: ありません。
func TestShort146SeparateWarmup(t *testing.T) {
	x := NewShort()
	if err := x.StartSession("S", "C", 0, 6120, false); err != nil {
		t.Fatal(err)
	}
	for i := 1; i <= 102; i++ {
		out := mustAdd146(t, x, minute146("S", "C", 0, i, 1000+float64(i)))
		one := out[0].Technical
		if one.EMA8.Known != (i >= 8) || one.EMA21.Known != (i >= 21) || one.ATR.Known != (i >= 14) || one.Histogram.Known != (i >= 34) || one.PreviousHistogram.Known != (i >= 35) {
			t.Fatalf("1分の助走%d: %+v", i, one)
		}
		if len(out) == 2 {
			n := i / 3
			v := out[1].Technical
			if v.EMA8.Known != (n >= 8) || v.EMA21.Known != (n >= 21) || v.ATR.Known != (n >= 14) || v.Histogram.Known != (n >= 34) {
				t.Fatalf("3分の助走%d: %+v", n, v)
			}
		}
	}
}

// TestShort146UnknownAndClosed は、価格未知resetと量未知の非resetを分けます。
//
// 引数: t(*testing.T)は人工検査です。
// 返り値: ありません。
func TestShort146UnknownAndClosed(t *testing.T) {
	x := NewShort()
	_ = x.StartSession("S", "C", 0, 2400, false)
	for i := 1; i <= 34; i++ {
		mustAdd146(t, x, minute146("S", "C", 0, i, 1000+float64(i)))
	}
	m := minute146("S", "C", 0, 35, 1035)
	m.VolumeKnown = false
	m.Volume = math.NaN()
	out := mustAdd146(t, x, m)
	if !out[0].Technical.Histogram.Known || out[0].VolumeKnown || out[0].Volume != 0 {
		t.Fatal("量未知が価格数値をresetした")
	}
	m = minute146("S", "C", 0, 36, 1036)
	m.Missing = true
	out = mustAdd146(t, x, m)
	if out[0].PriceKnown || out[0].Technical.Histogram.Known || out[1].PriceKnown || out[1].VolumeKnown {
		t.Fatal("欠分が既知又は圧縮された")
	}
	m = minute146("S", "C", 0, 37, 1037)
	if mustAdd146(t, x, m)[0].Technical.EMA8.Known {
		t.Fatal("未知後に数値をcarry")
	}
	m = minute146("S", "C", 0, 38, 1038)
	m.Closed = false
	out = mustAdd146(t, x, m)
	if out[0].PriceKnown || out[0].VolumeKnown || out[0].Technical.EMA8.Known {
		t.Fatal("未閉鎖足が数値を支持")
	}
	m = minute146("S", "C", 0, 39, 1039)
	out = mustAdd146(t, x, m)
	if out[1].PriceKnown || out[1].Closed {
		t.Fatal("3分の未閉鎖子を補完")
	}
}

// TestShort146PastOnlyCarry は、同限月の配送済み過去prefixだけを継承します。
//
// 引数: t(*testing.T)は人工検査です。
// 返り値: ありません。
func TestShort146PastOnlyCarry(t *testing.T) {
	x := NewShort()
	_ = x.StartSession("A", "C", 0, 3600, false)
	for i := 1; i <= 34; i++ {
		mustAdd146(t, x, minute146("A", "C", 0, i, 1000+float64(i)))
	}
	// EOF未配送の35〜60本は投入しないまま次場へ進みます。
	if err := x.StartSession("B", "C", 7200, 7380, true); err != nil {
		t.Fatal(err)
	}
	out := mustAdd146(t, x, minute146("B", "C", 7200, 1, 1100))
	if !out[0].Technical.PreviousHistogram.Known || out[0].Technical.TR.Value != 69 || x.Stats()["numeric_carried"] != 1 {
		t.Fatal("配送prefixの継承でない", out[0])
	}
	if len(out) != 1 || len(x.children) != 1 {
		t.Fatal("前場の3分子足をcarry")
	}
	if err := x.StartSession("C", "NEXT", 9000, 9180, true); err != nil {
		t.Fatal(err)
	}
	if mustAdd146(t, x, minute146("C", "NEXT", 9000, 1, 1200))[0].Technical.EMA8.Known {
		t.Fatal("異限月を継承")
	}
	if err := x.StartSession("BACK", "NEXT", 8000, 8180, true); err == nil {
		t.Fatal("未来の数値を過去へ継承")
	}
}

// TestShort146RejectAtomic は、欠分圧縮/未来配送/後退/不正価格を状態変更前に拒否します。
//
// 引数: t(*testing.T)は人工検査です。
// 返り値: ありません。
func TestShort146RejectAtomic(t *testing.T) {
	x := NewShort()
	_ = x.StartSession("S", "C", 0, 180, false)
	good := minute146("S", "C", 0, 1, 100)
	bad := []Minute{minute146("S", "C", 0, 2, 101), good, good, good}
	bad[1].Stamp.Time = 119
	bad[2].OHLC.High = 90
	bad[3].Volume = -1
	for _, m := range bad {
		if _, err := x.Add(m); err == nil || len(x.Stats()) != 0 || x.next != 0 {
			t.Fatal("拒否が非原子的")
		}
	}
	before := good
	_ = mustAdd146(t, x, good)
	if good != before {
		t.Fatal("入力が変更された")
	}
	if _, err := x.Add(good); err == nil || x.Stats()["minutes"] != 1 {
		t.Fatal("重複足を再利用")
	}
	m := minute146("S", "C", 0, 2, 101)
	m.Stamp.Index = 0
	if _, err := x.Add(m); err == nil {
		t.Fatal("配送index後退を許可")
	}
}

// TestShort146Mirror は、価格鏡像でHist/差分は反対、ATRは同じになることを確認します。
//
// 引数: t(*testing.T)は人工検査です。
// 返り値: ありません。
func TestShort146Mirror(t *testing.T) {
	x, y := NewShort(), NewShort()
	_ = x.StartSession("S", "C", 0, 6300, false)
	_ = y.StartSession("S", "C", 0, 6300, false)
	for i := 1; i <= 105; i++ {
		m := minute146("S", "C", 0, i, 10000+float64(i%11)+float64(i)/7)
		mirror := m
		mirror.OHLC = rules.OHLC{Open: 20000 - m.OHLC.Open, High: 20000 - m.OHLC.Low, Low: 20000 - m.OHLC.High, Close: 20000 - m.OHLC.Close}
		a, b := mustAdd146(t, x, m), mustAdd146(t, y, mirror)
		for j := range a {
			at, bt := a[j].Technical, b[j].Technical
			pairs := [][2]rules.Value{{at.Histogram, bt.Histogram}, {at.EMA8Delta, bt.EMA8Delta}, {at.Gap, bt.Gap}}
			for _, pair := range pairs {
				if pair[0].Known != pair[1].Known || (pair[0].Known && math.Abs(pair[0].Value+pair[1].Value) > 1e-9) {
					t.Fatal("鏡像差分不一致", i)
				}
			}
			if at.ATR.Known != bt.ATR.Known || (at.ATR.Known && math.Abs(at.ATR.Value-bt.ATR.Value) > 1e-9) {
				t.Fatal("ATR鏡像不一致", i)
			}
		}
	}
}

// TestShort146FrozenOutput は、過去の公開票が未来の数値更新で変化しないことを確認します。
//
// 引数: t(*testing.T)は人工検査です。
// 返り値: ありません。
func TestShort146FrozenOutput(t *testing.T) {
	x := NewShort()
	_ = x.StartSession("S", "C", 0, 6000, false)
	var frozen []ShortBar
	for i := 1; i <= 36; i++ {
		frozen = mustAdd146(t, x, minute146("S", "C", 0, i, 1000+float64(i)))
	}
	before, err := json.Marshal(frozen)
	if err != nil || len(frozen) != 2 {
		t.Fatal(err)
	}
	for _, bar := range frozen {
		for _, ref := range bar.Children {
			if ref.End > bar.End || ref.Delivered.Time > bar.Stamp.Time || ref.Delivered.Index > bar.Stamp.Index || ref.Delivered.Line > bar.Stamp.Line {
				t.Fatal("未来の子参照")
			}
		}
	}
	for i := 37; i <= 80; i++ {
		mustAdd146(t, x, minute146("S", "C", 0, i, 2000+float64(i)))
	}
	after, err := json.Marshal(frozen)
	if err != nil || string(before) != string(after) {
		t.Fatal("未来更新が公開済み票を変更", err)
	}
}
