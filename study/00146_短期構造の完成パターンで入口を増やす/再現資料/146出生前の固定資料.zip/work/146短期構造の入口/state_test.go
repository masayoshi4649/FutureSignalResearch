package shortpattern146

import (
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"math"
	"testing"
)

// quoteTest146 は正の価格と正常BBOの人工原行を作ります。
//
// 引数: at(float64)、index(int64)、last(float64)。返り値: Quoteです。
func quoteTest146(at float64, index int64, last float64) Quote {
	return Quote{Clock: fmt.Sprintf("人工/%g", at), Time: at, Index: index, SourceLine: index + 1, Last: last, Bid: last - 1, Ask: last + 1, QuoteOK: true}
}

// snapshotTest146 は現在原行に利用可能な三尺度背景を作ります。
//
// 引数: q(Quote)、direction(int)、decelerating(bool)、atr(float64)。返り値: rules.Snapshotです。
func snapshotTest146(q Quote, direction int, decelerating bool, atr float64) rules.Snapshot {
	s := rules.Snapshot{SessionID: "人工_Day", Contract: "X", AsOf: rq(q), Frames: map[int]rules.Publication{}}
	end := math.Floor((q.Time-60)/300) * 300
	for _, width := range []int{300, 900, 1800} {
		f := rules.ChartFrame{ID: fmt.Sprintf("bg/%d/%g", width, end), SessionID: s.SessionID, Contract: s.Contract, Width: width, Start: end - float64(width), End: end, AvailableAt: end + 60, DeliveryAt: q.Time, PriceKnown: true, OHLC: rules.OHLC{Open: 100, High: 200, Low: 1, Close: 100}, Technical: rules.Technical{Gap: v(float64(direction) * 10), EMA21Delta: v(float64(direction)), ATR: v(atr)}}
		adx := 21.
		if decelerating {
			adx = 19
		}
		di := rules.DMI{PlusDI: v(30), MinusDI: v(10), ADX: v(adx), PreviousADX: v(20)}
		if direction < 0 {
			di.PlusDI, di.MinusDI = di.MinusDI, di.PlusDI
		}
		p := rules.Publication{Stamp: rules.Stamp{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine)}, Frame: rules.Frame{Frame: f, DMI: di}}
		s.Frames[width] = p
		s.Refs = append(s.Refs, rules.Ref{ID: f.ID, Width: width, End: end, Delivered: p.Stamp})
	}
	return s
}

// barTest146 は短期数値の人工確定足を作ります。
//
// 引数: width(int)、start/at(float64)、index(int64)、ohlc(rules.OHLC)、hist(float64)。返り値: ShortBarです。
func barTest146(width int, start, at float64, index int64, ohlc rules.OHLC, hist float64) ShortBar {
	return ShortBar{ID: fmt.Sprintf("short/%d/%g", width, start), Session: "人工_Day", Contract: "X", Width: width, Start: start, End: start + float64(width), AvailableAt: start + float64(width) + 60, Stamp: rules.Stamp{Time: at, Index: int(index), Line: int(index + 1)}, PriceKnown: true, VolumeKnown: true, Closed: true, OHLC: ohlc, Volume: 100, Technical: rules.Technical{EMA8: v(100), EMA21: v(102), ATR: v(50), PreviousATR: v(50), TR: v(20), Histogram: v(hist), PreviousHistogram: v(-999)}, Children: []rules.Ref{}}
}

// mirrorBar146 は売買対称の価格・EMA・Histogramを作ります。
//
// 引数: b(ShortBar)、base(float64)。返り値: ShortBarです。
func mirrorBar146(b ShortBar, base float64) ShortBar {
	o := b.OHLC
	b.OHLC = rules.OHLC{Open: base - o.Open, High: base - o.Low, Low: base - o.High, Close: base - o.Close}
	b.Technical.EMA8.Value = base - b.Technical.EMA8.Value
	b.Technical.EMA21.Value = base - b.Technical.EMA21.Value
	b.Technical.Histogram.Value = -b.Technical.Histogram.Value
	b.Technical.PreviousHistogram.Value = -b.Technical.PreviousHistogram.Value
	return b
}

// sceneTest146 は人工場の空状態を作ります。
//
// 引数: なし。返り値: *Detectorです。
func sceneTest146() *Detector {
	return NewDetector(Scene{Session: "人工_Day", Contract: "X", Start: 0, End: 20000, ForceClose: 19500})
}

// observeTest146 は同Rawの全足を一つの現在背景へ渡します。
//
// 引数: t(*testing.T)、d(*Detector)、q(Quote)、direction(int)、b(bool)、atr(float64)、bars(...ShortBar)。返り値: ありません。
func observeTest146(t *testing.T, d *Detector, q Quote, direction int, b bool, atr float64, bars ...ShortBar) {
	t.Helper()
	if err := d.Observe(snapshotTest146(q, direction, b, atr), q, bars); err != nil {
		t.Fatal(err)
	}
}

// patternTest146 はA/Bの完成パターンを売買鏡像で実配送します。
//
// 引数: t(*testing.T)、side(int)、family(string)、width(int)。返り値: *Detectorです。
func patternTest146(t *testing.T, side int, family string, width int) *Detector {
	t.Helper()
	d := sceneTest146()
	count := 3
	if family == "B" {
		count = 5
	}
	for i := 0; i < count; i++ {
		o := rules.OHLC{Open: 100, High: 110, Low: 90, Close: 105}
		hist := 2.
		if i == count-2 {
			if family == "A" {
				o = rules.OHLC{Open: 106, High: 108, Low: 99, Close: 100}
				hist = 1
			} else {
				o = rules.OHLC{Open: 90, High: 108, Low: 80, Close: 100}
				hist = -2
			}
		}
		if i == count-1 {
			o = rules.OHLC{Open: 110, High: 130, Low: 108, Close: 120}
			hist = 3
		}
		at := float64((i+1)*width + 60)
		q := quoteTest146(at, int64(i+1), 100)
		bar := barTest146(width, float64(i*width), at, int64(i+1), o, hist)
		if i == count-1 {
			bar.Volume = 120
			q.Last = 120
			q.Bid = 119
			q.Ask = 121
		}
		direction := side
		if family == "B" {
			direction = -side
		}
		if side < 0 {
			bar = mirrorBar146(bar, 200)
			q.Last, q.Bid, q.Ask = 200-q.Last, 200-q.Ask, 200-q.Bid
		}
		atr := 50.
		if i == count-2 {
			atr = 20
			q.Last = 50
			if side < 0 {
				q.Last = 150
			}
		}
		if i == count-1 && family == "B" {
			direction = side
		}
		observeTest146(t, d, q, direction, family == "B", atr, bar)
	}
	return d
}

// Test146完成パターンと売買鏡像 は1/3分・A/B・p初知ATRとr現在背景を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test146完成パターンと売買鏡像(t *testing.T) {
	for _, width := range []int{60, 180} {
		for _, side := range []int{1, -1} {
			for _, family := range []string{"A", "B"} {
				d := patternTest146(t, side, family, width)
				if len(d.Events) != 1 || len(d.Groups) != 1 || d.Events[0].Side != side {
					t.Fatalf("%d %d %s: %+v", width, side, family, d.Checks)
				}
				event := d.Events[0]
				if event.Structure.ArmATR != 20 || event.Structure.Cap != 20 || event.Structure.CapATRWidth != 300 {
					t.Fatal("p ATR差替え", event.Structure)
				}
				q := quoteTest146(event.Birth.Time+1, event.Birth.Index+1, 120)
				if side < 0 {
					q.Last, q.Bid, q.Ask = 80, 79, 81
				}
				observeTest146(t, d, q, side, family == "B", 100)
				if event.Status != "filled" || d.Groups[0].Status != "filled" {
					t.Fatal(event)
				}
				if *event.EntryPrice != (func() float64 {
					if side > 0 {
						return q.Ask
					}
					return q.Bid
				})() {
					t.Fatal("実側価格")
				}
			}
		}
	}
}

// Test146新Iと未知pContext はp以前の仮I監視をせずrでIを固定することを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test146新Iと未知pContext(t *testing.T) {
	d := sceneTest146()
	for i := 0; i < 3; i++ {
		o := rules.OHLC{Open: 100, High: 110, Low: 90, Close: 105}
		hist := 2.
		last := 100.
		if i == 1 {
			o = rules.OHLC{Open: 106, High: 108, Low: 99, Close: 100}
			hist = 1
			last = 50
		}
		if i == 2 {
			o = rules.OHLC{Open: 110, High: 130, Low: 80, Close: 120}
			hist = 3
			last = 120
		}
		at := float64((i+1)*60 + 60)
		b := barTest146(60, float64(i*60), at, int64(i+1), o, hist)
		if i == 2 {
			b.Volume = 120
		}
		observeTest146(t, d, quoteTest146(at, int64(i+1), last), 1, false, 50, b)
	}
	if len(d.Events) != 1 || d.Events[0].Structure.I != 70 {
		t.Fatal("r低値をIへ反映しない")
	}
	d = sceneTest146()
	for i := 0; i < 3; i++ {
		o := rules.OHLC{Open: 100, High: 110, Low: 90, Close: 105}
		hist := 2.
		if i == 1 {
			o = rules.OHLC{Open: 106, High: 108, Low: 99, Close: 100}
			hist = 1
		}
		if i == 2 {
			o = rules.OHLC{Open: 110, High: 130, Low: 108, Close: 120}
			hist = 3
		}
		at := float64((i+1)*60 + 60)
		q := quoteTest146(at, int64(i+1), 120)
		b := barTest146(60, float64(i*60), at, int64(i+1), o, hist)
		if i == 2 {
			b.Volume = 120
		}
		snapshot := snapshotTest146(q, 1, false, 50)
		if i == 1 {
			p := snapshot.Frames[300]
			p.Frame.Frame.Technical.ATR = rules.Value{}
			snapshot.Frames[300] = p
		}
		if err := d.Observe(snapshot, q, []ShortBar{b}); err != nil {
			t.Fatal(err)
		}
	}
	if len(d.Events) != 0 {
		t.Fatal("p未知ATRを後で補った")
	}
}

// Test146同Rawと最新r消費 はcatchup完成足を同Rawで過去armにしないことを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test146同Rawと最新r消費(t *testing.T) {
	d := sceneTest146()
	o := barTest146(60, 0, 120, 1, rules.OHLC{Open: 100, High: 110, Low: 90, Close: 105}, 2)
	observeTest146(t, d, quoteTest146(120, 1, 100), 1, false, 50, o)
	p := barTest146(60, 60, 240, 2, rules.OHLC{Open: 106, High: 108, Low: 99, Close: 100}, 1)
	r := barTest146(60, 120, 240, 2, rules.OHLC{Open: 110, High: 130, Low: 108, Close: 120}, 3)
	r.Volume = 120
	observeTest146(t, d, quoteTest146(240, 2, 120), 1, false, 50, p, r)
	if len(d.Events) != 0 || len(d.Checks) != 4 {
		t.Fatal("catchupから出生又は古いpもr判定")
	}
	observeTest146(t, d, quoteTest146(241, 3, 120), 1, false, 50)
	if len(d.Events) != 0 {
		t.Fatal("同rを再評価")
	}
}

// pendingTest146 は候補別geometryを持つ同方向groupを人工で作ります。
//
// 引数: zeroCap(bool)。返り値: *Detectorです。
func pendingTest146(zeroCap bool) *Detector {
	d := sceneTest146()
	q := quoteTest146(1561, 20, 120)
	for _, width := range []int{60, 180} {
		st := Structure{K: 118, I: 89, Width: 29, Cap: 50, ArmATR: 50, CapATRWidth: 300}
		if width == 180 && zeroCap {
			st = Structure{K: 120, I: -5, Width: 125, Cap: 0, ArmATR: 50, CapATRWidth: 300}
		}
		e := &Event{ID: fmt.Sprint(width), Family: fmt.Sprintf("A%d", width/60), Width: width, Side: 1, Status: "pending", Birth: q, Expires: 1591, Structure: st, Refs: []rules.Ref{}, Reasons: []string{}, Trace: []Trace{}}
		d.Events = append(d.Events, e)
		d.latest[width] = KnownBar{Bar: barTest146(width, 1500-float64(width), 1561, 20, rules.OHLC{Open: 100, High: 130, Low: 90, Close: 120}, 3)}
	}
	g := &Group{ID: "g", Side: 1, Birth: q, Status: "pending", CandidateIDs: []string{"60", "180"}, FilledIDs: []string{}}
	d.Groups = append(d.Groups, g)
	d.pending = g
	d.active = d.Events
	return d
}

// Test146group個別適格性と代表 は同Quoteでも適格候補だけを物理1件のoriginsへ残します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test146group個別適格性と代表(t *testing.T) {
	for _, partial := range []bool{false, true} {
		d := pendingTest146(partial)
		q := quoteTest146(1562, 21, 120)
		observeTest146(t, d, q, 1, false, 50)
		g := d.Groups[0]
		if g.Status != "filled" || d.Stats["物理取得"] != 1 {
			t.Fatal(g)
		}
		if partial {
			if len(g.FilledIDs) != 1 || g.RepresentativeID != "60" || d.Events[1].Status != "entry_position_rejected" {
				t.Fatal(g)
			}
		} else if len(g.FilledIDs) != 2 || g.RepresentativeID != "180" {
			t.Fatal(g)
		}
	}
}

// Test146期限と最初正常 は別原行1秒、期限等号、Last/背景未知を候補ごとに検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test146期限と最初正常(t *testing.T) {
	for _, mode := range []string{"1秒前", "TTL", "Last", "背景", "短期未知", "悪BBO"} {
		d := pendingTest146(false)
		q := quoteTest146(1562, 21, 120)
		switch mode {
		case "1秒前":
			q.Time = 1561.5
		case "TTL":
			q.Time = 1591
		case "Last":
			q.Last = 117
		case "短期未知":
			x := d.latest[180]
			x.Bar.PriceKnown = false
			d.latest[180] = x
		case "悪BBO":
			q.QuoteOK = false
			q.Bid = 0
			q.Ask = 0
		}
		snapshot := snapshotTest146(q, 1, false, 50)
		if mode == "背景" {
			x := snapshot.Frames[900]
			x.Frame.DMI.PreviousADX = rules.Value{}
			snapshot.Frames[900] = x
		}
		if err := d.Observe(snapshot, q, nil); err != nil {
			t.Fatal(err)
		}
		switch mode {
		case "1秒前", "悪BBO":
			if d.pending == nil {
				t.Fatal("待機せず")
			}
		case "短期未知":
			if d.Events[0].Status != "filled" || d.Events[1].Status != "short_unknown" {
				t.Fatal(d.Events)
			}
		default:
			if d.pending != nil || d.Groups[0].EntryQuote != nil {
				t.Fatal("取消後も取得")
			}
		}
	}
}

// Test146未来参照とEOF はScope/知得不正とEOF仮気配を拒否します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test146未来参照とEOF(t *testing.T) {
	d := sceneTest146()
	q := quoteTest146(500, 1, 100)
	snapshot := snapshotTest146(q, 1, false, 50)
	p := snapshot.Frames[300]
	p.Stamp.Index = 2
	snapshot.Frames[300] = p
	if d.Observe(snapshot, q, nil) == nil {
		t.Fatal("未来公表受理")
	}
	d = pendingTest146(false)
	d.Finish()
	if d.Groups[0].Status != "eof_unfilled" || d.Events[0].EntryQuote != nil {
		t.Fatal("EOF仮取得")
	}
}
