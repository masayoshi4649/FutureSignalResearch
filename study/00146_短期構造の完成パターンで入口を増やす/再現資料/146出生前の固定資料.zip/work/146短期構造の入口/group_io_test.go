package shortpattern146

import (
	"bytes"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"os"
	"path/filepath"
	"testing"
	"time"
)

// Test146逆向き競合 は出生後の値や成績で片方向を選ばず全候補を取消します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test146逆向き競合(t *testing.T) {
	d := sceneTest146()
	q := quoteTest146(1561, 20, 120)
	c := makeContext(snapshotTest146(q, 1, true, 50), q)
	events := []*Event{{ID: "B1", Family: "B1", Width: 60, Side: 1, Status: "pending", Birth: q}, {ID: "B3", Family: "B3", Width: 180, Side: -1, Status: "pending", Birth: q}}
	d.Events = events
	d.submit(events, q, c)
	if len(d.Groups) != 1 || d.Groups[0].Status != "conflict" || d.Groups[0].Side != 0 || d.pending != nil {
		t.Fatal(d.Groups)
	}
	for _, e := range events {
		if e.Status != "conflict" || e.EntryQuote != nil {
			t.Fatal(e)
		}
	}
}

// Test146後着抑止と終了Raw は既groupが取得するRawも後着候補を追加しません。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test146後着抑止と終了Raw(t *testing.T) {
	for _, bad := range []bool{false, true} {
		d := sceneTest146()
		o := barTest146(60, 0, 120, 1, ohlc146(100, 110, 90, 105), 2)
		p := barTest146(60, 60, 180, 2, ohlc146(106, 108, 99, 100), 1)
		observeTest146(t, d, quoteTest146(120, 1, 100), 1, false, 50, o)
		observeTest146(t, d, quoteTest146(180, 2, 100), 1, false, 50, p)
		birth := quoteTest146(238, 2, 120)
		existing := &Event{ID: "既存", Family: "A3", Width: 180, Side: 1, Status: "pending", Birth: birth, Expires: 268, Structure: Structure{K: 118, I: 89, Width: 29, Cap: 50, ArmATR: 50, CapATRWidth: 300}, Reasons: []string{}, Trace: []Trace{}}
		g := &Group{ID: "既group", Side: 1, Birth: birth, Status: "pending", CandidateIDs: []string{existing.ID}, FilledIDs: []string{}}
		d.Events = append(d.Events, existing)
		d.Groups = append(d.Groups, g)
		d.pending = g
		d.active = []*Event{existing}
		d.latest[180] = KnownBar{Bar: barTest146(180, 0, 238, 2, ohlc146(100, 130, 90, 120), 3)}
		r := barTest146(60, 120, 240, 3, ohlc146(110, 130, 108, 120), 3)
		r.Volume = 120
		q := quoteTest146(240, 3, 120)
		if bad {
			q.QuoteOK = false
			q.Bid = 0
			q.Ask = 0
		}
		observeTest146(t, d, q, 1, false, 50, r)
		if len(d.Groups) != 1 || len(d.Events) != 2 || d.Events[1].Status != "suppressed" {
			t.Fatal("後着を新group化", d.Groups, d.Events)
		}
		if bad && d.pending == nil {
			t.Fatal("既pending喪失")
		}
		if !bad && d.pending != nil {
			t.Fatal("取得終了しない")
		}
		for _, check := range d.Checks[len(d.Checks)-2:] {
			if !check.Suppressed {
				t.Fatal("後着rの抑止maskなし")
			}
		}
	}
}

// ohlc146 は人工価格の型を短く記します。
//
// 引数: o/h/l/c(float64)。返り値: rules.OHLCです。
func ohlc146(o, h, l, c float64) rules.OHLC { return rules.OHLC{Open: o, High: h, Low: l, Close: c} }

// sceneIO146 は自然資料を使わずRaw/CSVの参照と期待品質を作ります。
//
// 引数: t(*testing.T)、compressed(bool)。返り値: Sceneです。
func sceneIO146(t *testing.T, compressed bool) Scene {
	t.Helper()
	var raw bytes.Buffer
	for i, at := range []int64{120, 121, 122} {
		row := map[string]any{"Symbol": "X", "CurrentPriceTime": time.Unix(at, 0).UTC().Format(time.RFC3339Nano), "CurrentPrice": 100.}
		for j := 1; j <= 10; j++ {
			row[fmt.Sprintf("Buy%d", j)] = map[string]float64{"Price": 90, "Qty": 1}
			row[fmt.Sprintf("Sell%d", j)] = map[string]float64{"Price": 110, "Qty": 1}
		}
		if i == 1 {
			row["Buy1"] = map[string]float64{"Price": 0, "Qty": 1}
		}
		b, e := json.Marshal(row)
		if e != nil {
			t.Fatal(e)
		}
		raw.Write(b)
		raw.WriteByte('\n')
	}
	body := raw.Bytes()
	if compressed {
		var z bytes.Buffer
		gz := gzip.NewWriter(&z)
		_, _ = gz.Write(body)
		_ = gz.Close()
		body = z.Bytes()
	}
	dir := t.TempDir()
	rawPath := filepath.Join(dir, "raw")
	if err := os.WriteFile(rawPath, body, 0600); err != nil {
		t.Fatal(err)
	}
	h := sha256.Sum256(body)
	csvBody := []byte("time,open,high,low,close,volume,volume_complete,closed\n1970-01-01T00:00:00Z,100,101,99,100,1,true,true\n1970-01-01T00:01:00Z,100,101,99,100,0,false,true\n")
	csvPath := filepath.Join(dir, "1分.csv")
	if err := os.WriteFile(csvPath, csvBody, 0600); err != nil {
		t.Fatal(err)
	}
	csvHash := sha256.Sum256(csvBody)
	return Scene{Session: "人工_Day", Contract: "X", Start: 0, End: 10200, ForceClose: 9000, Raw: FileRef{Path: rawPath, SHA256: hex.EncodeToString(h[:])}, CSV: FileRef{Path: csvPath, SHA256: hex.EncodeToString(csvHash[:]), Bytes: int64(len(csvBody))}, ExpectedAccepted: 3, ExpectedQuality: &Counts{Lines: 3, Accepted: 3, Delivered: 3, BadBBO: 1}}
}

// Test146CSVと原板一走査 は未知格子・EOF未配送・品質・0件配列を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test146CSVと原板一走査(t *testing.T) {
	for _, compressed := range []bool{false, true} {
		scene := sceneIO146(t, compressed)
		minutes, stats, err := loadCSV(scene)
		if err != nil {
			t.Fatal(err)
		}
		if stats.Missing != 163 || len(minutes) != 165 || minutes[1].VolumeKnown || minutes[1].Volume != 0 {
			t.Fatal("未知と0又は格子")
		}
		result, err := Generate([]Scene{scene}, 4, false)
		if err != nil {
			t.Fatal(err)
		}
		s := result.Scenes[0]
		if !result.Success || result.Trial != 146 || result.EffectiveWorkers != 1 || s.Counts != *scene.ExpectedQuality || s.RawPasses != 1 || s.Events == nil || s.Groups == nil || s.Bars == nil || len(s.Bars) != 1 || s.CSVStats.EOFUndelivered != 164 {
			t.Fatal(s)
		}
		scene.ExpectedQuality.BadBBO = 0
		if _, err = Generate([]Scene{scene}, 1, false); err == nil {
			t.Fatal("期待品質差受理")
		}
	}
	if _, err := Load("存在しない", "不正"); err == nil {
		t.Fatal("I/O前入力拒否なし")
	}
}
