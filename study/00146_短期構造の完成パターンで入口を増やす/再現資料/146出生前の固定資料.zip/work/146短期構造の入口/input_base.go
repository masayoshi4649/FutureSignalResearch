package shortpattern146

import (
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"strings"
)

const BackgroundSHA = "6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec"

// Validate は走査前に場順・品質分母・固定背景の因果列を検査します。
//
// 引数: scenes([]Scene)、all73(bool)。返り値: errorは不正入力です。falseは人工用です。
func Validate(scenes []Scene, all73 bool) error {
	if len(scenes) == 0 || all73 && len(scenes) != 73 {
		return fmt.Errorf("全73場入力が必要")
	}
	ids := map[string]bool{}
	days, nights, pubs := 0, 0, 0
	for i, s := range scenes {
		if s.Session == "" || s.Contract == "" || ids[s.Session] || !finite(s.Start, s.End, s.ForceClose) || s.End-3900 <= s.Start || s.ForceClose <= s.Start || s.ForceClose > s.End || s.Cutoff != 0 || s.Raw.Path == "" || s.Raw.Bytes < 0 || len(s.Raw.SHA256) != 64 || s.CSV.Path == "" || s.CSV.Bytes <= 0 || len(s.CSV.SHA256) != 64 || s.ExpectedQuality == nil || s.ExpectedAccepted <= 0 {
			return fmt.Errorf("場metadata不正:%s", s.Session)
		}
		for _, v := range []string{s.Raw.SHA256, s.CSV.SHA256} {
			if _, e := hex.DecodeString(v); e != nil {
				return e
			}
		}
		q := s.ExpectedQuality
		if q.Accepted != s.ExpectedAccepted || q.Delivered != q.Accepted || q.CutoffExcluded != 0 || q.Lines != q.Accepted+q.ClockMissing+q.ClockInvalid+q.Outside+q.Backward+q.LastNonPositive+q.LastNonFinite || q.BadBBO > q.Accepted {
			return fmt.Errorf("品質算術差:%s", s.Session)
		}
		if i > 0 && s.Start < scenes[i-1].End {
			return fmt.Errorf("場順差")
		}
		ids[s.Session] = true
		if strings.HasSuffix(s.Session, "_Day") {
			days++
		}
		if strings.HasSuffix(s.Session, "_Night") {
			nights++
		}
		previous, line := -1, -1
		for _, p := range s.Publications {
			f := p.Frame.Frame
			if f.SessionID != s.Session || f.Contract != s.Contract || p.Stamp.Index < previous || p.Stamp.Line < line || p.Stamp.Index < 0 || int64(p.Stamp.Index) >= s.ExpectedAccepted || p.Stamp.Time < s.Start || p.Stamp.Time > s.End {
				return fmt.Errorf("背景scope/順序不正:%s", s.Session)
			}
			previous, line = p.Stamp.Index, p.Stamp.Line
			pubs++
		}
	}
	if all73 && (days != 37 || nights != 36 || pubs != 12794) {
		return fmt.Errorf("固定73場/12794公表差")
	}
	return nil
}

// Load はSHA確認後だけ固定122背景と別CSV参照を結合します。
//
// 引数: path/expected/manifestPath/manifestSHA(string)。返り値: []Scene/errorです。価格CSV本文は読みません。
func loadSources(path, expected, manifestPath, manifestSHA string) ([]Scene, error) {
	if expected != BackgroundSHA || len(manifestSHA) != 64 {
		return nil, fmt.Errorf("固定入力SHA指定差")
	}
	if _, e := hex.DecodeString(manifestSHA); e != nil {
		return nil, e
	}
	body, e := os.ReadFile(path)
	if e != nil {
		return nil, e
	}
	if digest(body) != expected {
		return nil, fmt.Errorf("背景SHA差")
	}
	var input struct {
		Trial  int     `json:"trial"`
		Scenes []Scene `json:"scenes"`
	}
	if e = json.Unmarshal(body, &input); e != nil {
		return nil, e
	}
	if input.Trial != 122 {
		return nil, fmt.Errorf("背景試行122差")
	}
	body, e = os.ReadFile(manifestPath)
	if e != nil {
		return nil, e
	}
	if digest(body) != manifestSHA {
		return nil, fmt.Errorf("CSV参照SHA差")
	}
	var manifest struct {
		Success bool `json:"success"`
		Scenes  []struct {
			Session  string  `json:"session"`
			Contract string  `json:"contract"`
			CSV      FileRef `json:"csv"`
		} `json:"scenes"`
	}
	if e = json.Unmarshal(body, &manifest); e != nil {
		return nil, e
	}
	if !manifest.Success || len(manifest.Scenes) != len(input.Scenes) {
		return nil, fmt.Errorf("CSV参照場数差")
	}
	for i, m := range manifest.Scenes {
		if m.Session != input.Scenes[i].Session || m.Contract != input.Scenes[i].Contract {
			return nil, fmt.Errorf("CSV参照順/scope差")
		}
		input.Scenes[i].CSV = m.CSV
	}
	if e = Validate(input.Scenes, true); e != nil {
		return nil, e
	}
	return input.Scenes, nil
}
