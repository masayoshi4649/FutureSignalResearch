package shortpattern146

import (
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"math"
	"sort"
)

type Detector struct {
	Scene     Scene
	Bars      []KnownBar
	Events    []*Event
	Groups    []*Group
	Checks    []PatternCheck
	Stats     map[string]uint64
	windows   map[int][]KnownBar
	latest    map[int]KnownBar
	processed map[string]bool
	pending   *Group
	active    []*Event
	filled    map[string]bool
}

// NewDetector は口座保有や旧87を持たず当場の形状だけを作ります。
//
// 引数: scene(Scene)。返り値: *Detectorです。
func NewDetector(scene Scene) *Detector {
	return &Detector{Scene: scene, Bars: []KnownBar{}, Events: []*Event{}, Groups: []*Group{}, Checks: []PatternCheck{}, Stats: map[string]uint64{}, windows: map[int][]KnownBar{}, latest: map[int]KnownBar{}, processed: map[string]bool{}, filled: map[string]bool{}}
}

// limit はH60の観測を残す共通新規限界です。
//
// 引数: なし。返り値: float64です。
func (d *Detector) limit() float64 { return math.Min(d.Scene.ForceClose, d.Scene.End-3900) }

// addGate は未知と既知不成立を区別した個別条件を保存します。
//
// 引数: c(*PatternCheck)、key(string)、known/pass(bool)。返り値: ありません。
func addGate(c *PatternCheck, key string, known, pass bool) {
	x := rules.Value{}
	if known {
		x = v(0)
		if pass {
			x = v(1)
		}
	}
	c.Gates[key] = x
	if !known {
		c.Reasons = append(c.Reasons, key+"未知")
	} else if !pass {
		c.Reasons = append(c.Reasons, key+"不成立")
	}
}

// candidate は完成した連続窓からp初知Contextとr現在の新パターンだけを判定します。
//
// 引数: width(int)、family(string)、current(Context)、q(Quote)。返り値: *Event又はnilとPatternCheckです。
func (d *Detector) candidate(width int, family string, current Context, q Quote) (*Event, PatternCheck) {
	latest := d.latest[width]
	check := PatternCheck{Width: width, Family: family, At: q, R: shortRef(latest.Bar), UsedRefs: []rules.Ref{}, Gates: map[string]rules.Value{}, Fields: map[string]rules.Value{}, Reasons: []string{}, Status: "pattern_rejected"}
	w := d.windows[width]
	need := 3
	if family[0] == 'B' {
		need = 5
	}
	addGate(&check, "当場連続形状窓", true, len(w) >= need)
	if len(w) < need {
		return nil, check
	}
	list := w[len(w)-need:]
	p, r := list[len(list)-2], list[len(list)-1]
	side := p.Context.Direction30
	if family[0] == 'B' {
		side = -side
	}
	s := float64(side)
	for _, b := range list {
		check.UsedRefs = merge(check.UsedRefs, []rules.Ref{shortRef(b.Bar)}, b.Bar.Children)
	}
	addGate(&check, "p_r知得の時刻とindexが厳密増加", true, p.Bar.Stamp.Time < r.Bar.Stamp.Time && p.Bar.Stamp.Index < r.Bar.Stamp.Index)
	addGate(&check, "p初知背景", true, contextPass(p.Context, family, side, true))
	addGate(&check, "r現在背景", true, contextPass(current, family, side, false))
	addGate(&check, "r現在fresh", true, r.Bar.PriceKnown && r.Bar.Closed && q.Time < r.Bar.End+float64(width)+60)
	atr := p.Context.Fields["atr5"]
	check.Fields["p_context_atr5"] = atr
	addGate(&check, "p初知ATR5正", atr.Known, atr.Value > 0)
	t, pt := r.Bar.Technical, p.Bar.Technical
	body := s * (p.Bar.OHLC.Close - p.Bar.OHLC.Open)
	check.Fields["p_signed_body"] = v(body)
	k := p.Bar.OHLC.High + 10
	if side < 0 {
		k = p.Bar.OHLC.Low - 10
	}
	check.Fields["k"] = v(k)
	if family[0] == 'A' {
		o := list[len(list)-3].Bar
		dh := diff(pt.Histogram, o.Technical.Histogram)
		check.Fields["p_hist_delta"] = dh
		addGate(&check, "p逆実体", true, body < 0)
		addGate(&check, "p_Hist実悪化", dh.Known, s*dh.Value < 0)
		ema8, ema21 := o.Technical.EMA8, o.Technical.EMA21
		addGate(&check, "o_EMA帯接触", ema8.Known && ema21.Known, p.Bar.OHLC.High >= math.Min(ema8.Value, ema21.Value) && p.Bar.OHLC.Low <= math.Max(ema8.Value, ema21.Value))
	} else {
		low, high := math.Inf(1), math.Inf(-1)
		for _, b := range list[:3] {
			low = math.Min(low, b.Bar.OHLC.Low)
			high = math.Max(high, b.Bar.OHLC.High)
		}
		up, down := p.Bar.OHLC.High > high, p.Bar.OHLC.Low < low
		check.Fields["range_low"], check.Fields["range_high"] = v(low), v(high)
		addGate(&check, "前3本域正幅", true, high > low)
		addGate(&check, "元方向端突破", true, side < 0 && up || side > 0 && down)
		addGate(&check, "域内終値", true, p.Bar.OHLC.Close >= low && p.Bar.OHLC.Close <= high)
		addGate(&check, "反転実体", true, body > 0)
		addGate(&check, "非両端突破", true, !(up && down))
	}
	dh := diff(t.Histogram, pt.Histogram)
	check.Fields["r_hist_delta"] = dh
	check.Fields["r_hist"] = t.Histogram
	addGate(&check, "r終値K回復", true, s*(r.Bar.OHLC.Close-k) >= 0)
	addGate(&check, "r_Hist側符号", t.Histogram.Known, s*t.Histogram.Value > 0)
	addGate(&check, "r_Hist実改善", dh.Known, s*dh.Value > 0)
	addGate(&check, "p_r同足量確認", p.Bar.VolumeKnown && r.Bar.VolumeKnown, p.Bar.Volume > 0 && r.Bar.Volume > 0 && r.Bar.Volume >= p.Bar.Volume)
	addGate(&check, "r_TR急変ガード", t.TR.Known && t.PreviousATR.Known, t.TR.Value >= 0 && t.PreviousATR.Value > 0 && t.TR.Value <= 2*t.PreviousATR.Value)
	if len(check.Reasons) > 0 {
		return nil, check
	}
	d.Stats["技術完成/"+family]++
	check.Status = "technical_complete"
	i := math.Min(p.Bar.OHLC.Low, r.Bar.OHLC.Low) - 10
	if side < 0 {
		i = math.Max(p.Bar.OHLC.High, r.Bar.OHLC.High) + 10
	}
	widthPt := s * (k - i)
	st := Structure{K: k, I: i, Width: widthPt, Cap: math.Min(atr.Value, 125-widthPt), ArmATR: atr.Value, CapATRWidth: 300}
	check.Fields["i"], check.Fields["structure_width"], check.Fields["cap"] = v(i), v(widthPt), v(st.Cap)
	if !finite(k, i, widthPt, st.Cap) || widthPt <= 0 {
		return nil, check
	}
	if widthPt > 125 {
		check.Status = "structure_rejected"
		check.Reasons = append(check.Reasons, "構造幅125超")
		d.Stats["構造幅不適合/"+family]++
		return nil, check
	}
	if !position(side, q.Last, st) {
		check.Status = "position_rejected"
		check.Reasons = append(check.Reasons, "完成時現在LastがK/cap域外")
		d.Stats["完成時Last域外/"+family]++
		return nil, check
	}
	refs := merge(p.Context.Refs, current.Refs, check.UsedRefs)
	e := &Event{ID: fmt.Sprintf("%s/%s/%s/%d", d.Scene.Session, family, r.Bar.ID, q.Index), Family: family, Width: width, Side: side, Status: "pending", Birth: q, Expires: math.Min(q.Time+30, d.limit()), Structure: st, Arm: shortRef(p.Bar), Confirm: shortRef(r.Bar), Refs: refs, Fields: check.Fields, Reasons: []string{}, Trace: []Trace{}}
	check.Status = "birth_eligible"
	return e, check
}

// preferred は固定代表順を返します。
//
// 引数: a/b(*Event)。返り値: boolはaが先です。
func preferred(a, b *Event) bool {
	if a.Width != b.Width {
		return a.Width > b.Width
	}
	if a.Family[0] != b.Family[0] {
		return a.Family[0] < b.Family[0]
	}
	return a.ID < b.ID
}

// terminate は候補自身だけを取り消し現在参照を保存します。
//
// 引数: e(*Event)、status/reason(string)、q(Quote)、c(Context)。返り値: ありません。
func terminate(e *Event, status, reason string, q Quote, c Context) {
	z := q
	e.Status = status
	e.TerminationQuote = &z
	e.Reasons = append(e.Reasons, reason)
	e.Refs = merge(e.Refs, c.Refs)
	e.Trace = append(e.Trace, Trace{Stage: status, Reason: reason, At: q, Context: c, Fields: map[string]rules.Value{}})
}

// processPending はgroup内の各候補を独立検査し同Quoteの実取得をまとめます。
//
// 引数: q(Quote)、c(Context)。返り値: errorは物理取得の重複です。
func (d *Detector) processPending(q Quote, c Context) error {
	if d.pending == nil {
		return nil
	}
	group := d.pending
	alive := []*Event{}
	for _, e := range d.active {
		if e.Status != "pending" {
			continue
		}
		b, ok := d.latest[e.Width]
		switch {
		case q.Time >= d.limit():
			terminate(e, "force_close", "共通限界", q, c)
		case q.Time >= e.Expires:
			terminate(e, "unfilled_expired", "pending期限等号又は超過", q, c)
		case !contextPass(c, e.Family, e.Side, false):
			terminate(e, "background_lost", "現在背景未知又は否定", q, c)
		case !ok || !b.Bar.PriceKnown || !b.Bar.Closed || q.Time >= b.Bar.End+float64(e.Width)+60:
			terminate(e, "short_unknown", "現在短期足未知又はfresh不足", q, c)
		case float64(e.Side)*(q.Last-e.Structure.I) <= 0:
			terminate(e, "invalidation_reached", "現在LastがI到達", q, c)
		case !position(e.Side, q.Last, e.Structure):
			terminate(e, "last_position_rejected", "現在LastがK/cap域外", q, c)
		default:
			alive = append(alive, e)
		}
	}
	if len(alive) == 0 {
		group.Status = "all_cancelled"
		z := q
		group.TerminationQuote = &z
		d.pending = nil
		d.active = nil
		return nil
	}
	if q.Index <= group.Birth.Index || q.SourceLine <= group.Birth.SourceLine || q.Time < group.Birth.Time+1 || !q.QuoteOK || !normal(q) {
		return nil
	}
	filled := []*Event{}
	for _, e := range alive {
		price := q.Ask
		if e.Side < 0 {
			price = q.Bid
		}
		risk := float64(e.Side) * (price - e.Structure.I)
		e.Refs = merge(e.Refs, c.Refs)
		e.Trace = append(e.Trace, Trace{Stage: "最初正常実P評価", At: q, Context: c, Fields: map[string]rules.Value{"entry_price": v(price), "risk": v(risk)}})
		if !position(e.Side, price, e.Structure) || risk <= 0 || risk > 125 {
			terminate(e, "entry_position_rejected", "最初正常実側の固定域又はrisk不適合", q, c)
			continue
		}
		z := q
		e.Status = "filled"
		e.EntryQuote = &z
		e.EntryPrice = &price
		e.TerminationQuote = &z
		filled = append(filled, e)
		d.Stats["候補取得/"+e.Family]++
	}
	z := q
	group.TerminationQuote = &z
	if len(filled) > 0 {
		key := fmt.Sprintf("%g/%d/%d", q.Time, q.Index, q.SourceLine)
		if d.filled[key] {
			return fmt.Errorf("同原行の複数group取得矛盾")
		}
		d.filled[key] = true
		sort.Slice(filled, func(i, j int) bool { return preferred(filled[i], filled[j]) })
		group.Status = "filled"
		group.EntryQuote = &z
		group.RepresentativeID = filled[0].ID
		for _, e := range filled {
			group.FilledIDs = append(group.FilledIDs, e.ID)
		}
		d.Stats["物理取得"]++
	} else {
		group.Status = "all_cancelled"
	}
	d.pending = nil
	d.active = nil
	return nil
}

// Observe は全配送後のContextを凍結し各幅最新rだけを一回判定します。
//
// 引数: snapshot(rules.Snapshot)、q(Quote)、batch([]ShortBar)。返り値: errorです。
func (d *Detector) Observe(snapshot rules.Snapshot, q Quote, batch []ShortBar) error {
	if err := validateSnapshot(snapshot, q, d.Scene); err != nil {
		return err
	}
	d.Stats["採用Raw"]++
	current := makeContext(snapshot, q)
	newWidths := map[int]bool{}
	for _, bar := range batch {
		if bar.Session != d.Scene.Session || bar.Contract != d.Scene.Contract || (bar.Width != 60 && bar.Width != 180) || bar.Stamp.Time != q.Time || bar.Stamp.Index != int(q.Index) || bar.Stamp.Line != int(q.SourceLine) || bar.End > q.Time || bar.AvailableAt > q.Time {
			return fmt.Errorf("短期配送のscope/時計差")
		}
		known := KnownBar{Bar: bar, Context: current}
		d.Bars = append(d.Bars, known)
		d.latest[bar.Width] = known
		newWidths[bar.Width] = true
		w := d.windows[bar.Width]
		if !bar.PriceKnown || !bar.Closed {
			d.windows[bar.Width] = nil
			continue
		}
		if len(w) > 0 && w[len(w)-1].Bar.End != bar.Start {
			w = nil
		}
		w = append(w, known)
		if len(w) > 5 {
			w = append([]KnownBar(nil), w[len(w)-5:]...)
		}
		d.windows[bar.Width] = w
	}
	hadPending := d.pending != nil
	if err := d.processPending(q, current); err != nil {
		return err
	}
	candidates := []*Event{}
	for _, width := range []int{60, 180} {
		if !newWidths[width] {
			continue
		}
		r := d.latest[width]
		if d.processed[r.Bar.ID] {
			return fmt.Errorf("rID再配送矛盾")
		}
		d.processed[r.Bar.ID] = true
		d.Stats[fmt.Sprintf("新r/%d", width)]++
		if q.Time >= d.limit() {
			d.Stats["新r限界以後"]++
			continue
		}
		for _, letter := range []string{"A", "B"} {
			family := fmt.Sprintf("%s%d", letter, width/60)
			event, check := d.candidate(width, family, current, q)
			check.Suppressed = hadPending
			if event != nil && hadPending {
				check.Status = "suppressed"
			}
			d.Checks = append(d.Checks, check)
			if event == nil {
				continue
			}
			d.Events = append(d.Events, event)
			d.Stats["出生可能候補/"+family]++
			if hadPending {
				terminate(event, "suppressed", "既pending又はその終了Rawの後着候補", q, current)
				continue
			}
			candidates = append(candidates, event)
		}
	}
	if len(candidates) == 0 {
		return nil
	}
	d.submit(candidates, q, current)
	return nil
}

// submit は同Raw出生可能候補を固定順でgroup化し逆向き競合を全取消します。
//
// 引数: candidates([]*Event)、q(Quote)、current(Context)。返り値: ありません。
func (d *Detector) submit(candidates []*Event, q Quote, current Context) {
	sort.Slice(candidates, func(i, j int) bool { return preferred(candidates[i], candidates[j]) })
	side := candidates[0].Side
	conflict := false
	for _, e := range candidates {
		conflict = conflict || e.Side != side
	}
	g := &Group{ID: fmt.Sprintf("%s/group/%d", d.Scene.Session, q.Index), Side: side, Birth: q, CandidateIDs: []string{}, Status: "pending", FilledIDs: []string{}}
	for _, e := range candidates {
		e.GroupID = g.ID
		g.CandidateIDs = append(g.CandidateIDs, e.ID)
	}
	d.Groups = append(d.Groups, g)
	if conflict {
		g.Side = 0
		g.Status = "conflict"
		z := q
		g.TerminationQuote = &z
		for _, e := range candidates {
			terminate(e, "conflict", "同Rawの逆向き出生競合", q, current)
		}
		d.Stats["競合group"]++
		return
	}
	d.pending = g
	d.active = candidates
	d.Stats["group出生"]++
}

// Finish はEOFで気配を作らず未取得候補とgroupを終えます。
//
// 引数: なし。返り値: ありません。
func (d *Detector) Finish() {
	if d.pending == nil {
		return
	}
	d.pending.Status = "eof_unfilled"
	for _, e := range d.active {
		if e.Status == "pending" {
			e.Status = "eof_unfilled"
			e.Reasons = append(e.Reasons, "EOF")
		}
	}
	d.pending = nil
	d.active = nil
}
