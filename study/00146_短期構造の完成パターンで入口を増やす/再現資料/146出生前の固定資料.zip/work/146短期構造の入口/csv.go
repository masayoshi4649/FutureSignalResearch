package shortpattern146

import (
	"bytes"
	"crypto/sha256"
	"encoding/csv"
	"encoding/hex"
	"fmt"
	"io"
	"math"
	"os"
	"strconv"
	"strings"
	"time"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

type CSVStats struct {
	Reference      FileRef          `json:"reference"`
	Rows           int              `json:"rows"`
	GridMinutes    int              `json:"grid_minutes"`
	Missing        int              `json:"missing"`
	PriceKnown     int              `json:"price_known"`
	VolumeKnown    int              `json:"volume_known"`
	Delivered      int              `json:"delivered"`
	EOFUndelivered int              `json:"eof_undelivered"`
	StatBefore     map[string]int64 `json:"stat_before"`
	StatAfter      map[string]int64 `json:"stat_after"`
}

// digest は固定原本bytesのSHA256を求めます。
//
// 引数: body([]byte)。返り値: stringは小文字指紋です。
func digest(body []byte) string { v := sha256.Sum256(body); return hex.EncodeToString(v[:]) }

// statValue は価格値を含まないサイズ/更新時計を保存します。
//
// 引数: value(os.FileInfo)。返り値: map[string]int64です。
func statValue(value os.FileInfo) map[string]int64 {
	return map[string]int64{"bytes": value.Size(), "mtime_ns": value.ModTime().UnixNano()}
}

// number は欠測/非有限を既知0へ補わず返します。
//
// 引数: text(string)。返り値: float64/boolは内部値と既知性です。
func number(text string) (float64, bool) {
	if text == "" || strings.TrimSpace(text) != text {
		return 0, false
	}
	v, e := strconv.ParseFloat(text, 64)
	return v, e == nil && finite(v)
}

// loadCSV は全fileを固定し、最終品質maskを使わず元行からモデル格子を作ります。
//
// 引数: scene(Scene)。返り値: []Minute/CSVStats/error。構造不正は生成失敗で、過去出生を修正しません。
func loadCSV(scene Scene) ([]Minute, CSVStats, error) {
	ref := scene.CSV
	stats := CSVStats{Reference: ref}
	before, e := os.Stat(ref.Path)
	if e != nil {
		return nil, stats, e
	}
	stats.StatBefore = statValue(before)
	body, e := os.ReadFile(ref.Path)
	if e != nil {
		return nil, stats, e
	}
	if ref.Bytes <= 0 || int64(len(body)) != ref.Bytes || digest(body) != ref.SHA256 {
		return nil, stats, fmt.Errorf("CSV SHA/size差")
	}
	reader := csv.NewReader(bytes.NewReader(bytes.TrimPrefix(body, []byte{0xef, 0xbb, 0xbf})))
	header, e := reader.Read()
	if e != nil {
		return nil, stats, e
	}
	want := []string{"time", "open", "high", "low", "close", "volume", "volume_complete", "closed"}
	if len(header) != len(want) {
		return nil, stats, fmt.Errorf("CSVヘッダ不一致")
	}
	for i, k := range want {
		if header[i] != k {
			return nil, stats, fmt.Errorf("CSV列順/名前不一致")
		}
	}
	reader.FieldsPerRecord = 8
	byStart := map[float64]Minute{}
	previous := math.Inf(-1)
	for {
		row, err := reader.Read()
		if err == io.EOF {
			break
		}
		if err != nil {
			return nil, stats, fmt.Errorf("CSV構文不正")
		}
		stats.Rows++
		at, err := time.Parse(time.RFC3339Nano, row[0])
		if err != nil {
			return nil, stats, fmt.Errorf("CSV時計不正")
		}
		start := float64(at.UnixNano()) / 1e9
		if !finite(start) || start <= previous || math.Mod(start-scene.Start, 60) != 0 {
			return nil, stats, fmt.Errorf("CSV重複/後退/格子不正")
		}
		previous = start
		if start < scene.Start || start >= scene.End-300 {
			continue
		}
		line, _ := reader.FieldPos(0)
		m := Minute{ID: fmt.Sprintf("csv1m:%s:%.0f", ref.SHA256, start), Session: scene.Session, Contract: scene.Contract, Start: start, End: start + 60, AvailableAt: start + 120, CSV: ref, CSVLine: line, Closed: row[7] == "true"}
		values := []*float64{&m.OHLC.Open, &m.OHLC.High, &m.OHLC.Low, &m.OHLC.Close}
		known := true
		for i, p := range values {
			v, k := number(row[i+1])
			if !k {
				known = false
				v = 0
			}
			*p = v
		}
		o := m.OHLC
		m.PriceKnown = known && o.Low > 0 && o.High >= o.Low && o.Open >= o.Low && o.Open <= o.High && o.Close >= o.Low && o.Close <= o.High
		v, k := number(row[5])
		if k && v >= 0 {
			m.Volume = v
			m.VolumeKnown = row[6] == "true"
		}
		if row[6] != "true" && row[6] != "false" {
			m.VolumeKnown = false
		}
		if row[7] != "true" && row[7] != "false" {
			m.PriceKnown = false
			m.VolumeKnown = false
			m.Closed = false
		}
		byStart[start] = m
	}
	minutes := []Minute{}
	for start := scene.Start; start < scene.End-300; start += 60 {
		m, ok := byStart[start]
		if !ok {
			m = Minute{ID: fmt.Sprintf("csv1m-missing:%s:%.0f", ref.SHA256, start), Session: scene.Session, Contract: scene.Contract, Start: start, End: start + 60, AvailableAt: start + 120, CSV: ref, Missing: true}
			stats.Missing++
		}
		minutes = append(minutes, m)
		if m.PriceKnown && m.Closed {
			stats.PriceKnown++
		}
		if m.VolumeKnown && m.Closed {
			stats.VolumeKnown++
		}
	}
	stats.GridMinutes = len(minutes)
	after, e := os.Stat(ref.Path)
	if e != nil {
		return nil, stats, e
	}
	stats.StatAfter = statValue(after)
	if !os.SameFile(before, after) || before.Size() != after.Size() || !before.ModTime().Equal(after.ModTime()) {
		return nil, stats, fmt.Errorf("CSV前後stat差")
	}
	return minutes, stats, nil
}

// deliverMinutes はAvailableAt以後の最初の採用Rawへ元格子を順に配送します。
//
// 引数: all([]Minute)、cursor(*int)、q(Quote)。返り値: []Minuteは同Raw配送全部です。
func deliverMinutes(all []Minute, cursor *int, q Quote) []Minute {
	batch := []Minute{}
	for *cursor < len(all) && all[*cursor].AvailableAt <= q.Time {
		m := all[*cursor]
		m.Stamp = rules.Stamp{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine)}
		batch = append(batch, m)
		*cursor++
	}
	return batch
}
