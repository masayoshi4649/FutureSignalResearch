package shortpattern146

import (
	"fmt"
	"math"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	old "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
	"shortpattern146/internal/basenumeric"
)

// ShortTracker は、配送済み1分から独立した1分/3分の数値状態を更新します。
// 当場の価格形状や売買状態は持たず、同限月の過去場だけ数値を継承します。
type ShortTracker struct {
	session, contract string
	start, end, next  float64
	started, hasStamp bool
	stamp             rules.Stamp
	one, three        basenumeric.State
	children          []ShortBar
	seen              map[string]bool
	stats             map[string]int
}

// NewShort は、初回coldの短期数値器を作ります。
//
// 引数: ありません。
// 返り値: *ShortTracker は未開始で外部共有状態のない数値器です。
func NewShort() *ShortTracker {
	return &ShortTracker{stats: map[string]int{}, seen: map[string]bool{}}
}

// StartSession は、当場の格子と子足を初期化し過去の同限月数値だけを継承します。
//
// 引数: session/contract(string)は当場ID/限月、start/end(float64)は半開区間、carry(bool)は継承要求です。
// 返り値: error は不正時計又は過去場へ戻る要求で、拒否時は状態を変更しません。
func (t *ShortTracker) StartSession(session, contract string, start, end float64, carry bool) error {
	if session == "" || contract == "" || !shortFinite(start) || !shortFinite(end) || end <= start || math.Mod(end-start, 60) != 0 {
		return fmt.Errorf("短期場のID/限月/60秒格子が不正")
	}
	if t.started && (start < t.end || session == t.session) {
		return fmt.Errorf("短期数値を同場又は未来場から過去へ継承できない")
	}
	// ----------------------------------------
	// 価格数値だけを継承し、格子・子足・配送・件数は当場へ初期化します。
	useCarry := carry && t.started && contract == t.contract
	one, three := t.one, t.three
	one.StartSession(useCarry)
	three.StartSession(useCarry)
	*t = ShortTracker{session: session, contract: contract, start: start, end: end, next: start,
		started: true, one: one, three: three, children: []ShortBar{}, seen: map[string]bool{}, stats: map[string]int{}}
	if useCarry {
		t.stats["numeric_carried"] = 1
	}
	return nil
}

// shortFinite は、時計と価格の非有限値を判定します。
//
// 引数: value(float64)は確認値です。
// 返り値: bool は有限なら真です。
func shortFinite(value float64) bool {
	return !math.IsNaN(value) && !math.IsInf(value, 0)
}

// validMinute は、配送の非減少と欠分を詰めない当場格子を検査します。
//
// 引数: m(Minute)はMissingを含む次の実1分格子です。
// 返り値: error は時計/既知価格/既知量の矛盾です。
func (t *ShortTracker) validMinute(m Minute) error {
	if !t.started || m.Session != t.session || m.Contract != t.contract || m.ID == "" || t.seen[m.ID] {
		return fmt.Errorf("短期1分の当場/限月/IDが不正又は重複")
	}
	if !shortFinite(m.Start) || !shortFinite(m.End) || m.Start != t.next || m.End != m.Start+60 || m.End > t.end || !shortFinite(m.AvailableAt) || m.AvailableAt != m.End+60 {
		return fmt.Errorf("短期1分の実格子/利用可能時計が不正")
	}
	if !shortFinite(m.Stamp.Time) || m.Stamp.Time < m.AvailableAt || m.Stamp.Index < 0 || m.Stamp.Line < 1 {
		return fmt.Errorf("短期1分が利用可能前又は不正Rawへ配送された")
	}
	if t.hasStamp && (m.Stamp.Time < t.stamp.Time || m.Stamp.Index < t.stamp.Index || m.Stamp.Line < t.stamp.Line) {
		return fmt.Errorf("短期1分の配送が後退")
	}
	if m.PriceKnown && m.Closed && !m.Missing {
		p := m.OHLC
		if !shortFinite(p.Open) || !shortFinite(p.High) || !shortFinite(p.Low) || !shortFinite(p.Close) || p.Low <= 0 || p.High < p.Low || p.Open < p.Low || p.Open > p.High || p.Close < p.Low || p.Close > p.High {
			return fmt.Errorf("既知短期1分の価格形状が不正")
		}
	}
	if m.VolumeKnown && m.Closed && !m.Missing && (!shortFinite(m.Volume) || m.Volume < 0) {
		return fmt.Errorf("既知短期1分量が不正")
	}
	return nil
}

// shortValue は、元数値器の既知性をそのまま公開型へ移します。
//
// 引数: value(old.Value)は元数値器の値です。
// 返り値: rules.Value は未知を既知0へしない同じ値です。
func shortValue(value old.Value) rules.Value {
	return rules.Value{Known: value.Known, Value: value.Value}
}

// shortTechnical は、元数値器の公開指標を118型へ明示射影します。
//
// 引数: value(old.Technical)は各足幅で独立計算された値です。
// 返り値: rules.Technical は同じ尺度の指標/実前値です。
func shortTechnical(value old.Technical) rules.Technical {
	return rules.Technical{EMA8: shortValue(value.EMA8), EMA21: shortValue(value.EMA21),
		EMA8Delta: shortValue(value.EMA8Delta), EMA21Delta: shortValue(value.EMA21Delta), Gap: shortValue(value.Gap),
		ATR: shortValue(value.ATR), PreviousATR: shortValue(value.PreviousATR), TR: shortValue(value.TR),
		RSI: shortValue(value.RSI), PreviousRSI: shortValue(value.PreviousRSI),
		Histogram: shortValue(value.Histogram), PreviousHistogram: shortValue(value.PreviousHistogram)}
}

// applyShort は、未知も含む一足を元の私有数値器へ一度だけ入力します。
//
// 引数: state(*basenumeric.State)は当該幅の数値器、bar(ShortBar)は閉鎖/既知性付き足です。
// 返り値: ShortBar/error は同じ足の数値又は非有限計算の拒否です。
func applyShort(state *basenumeric.State, bar ShortBar) (ShortBar, error) {
	frame := old.Frame{ID: bar.ID, SessionID: bar.Session, Contract: bar.Contract, WidthSeconds: bar.Width,
		Start: bar.Start, End: bar.End, NominalAvailable: bar.AvailableAt, AvailableAt: bar.AvailableAt,
		ObservedAt: bar.Stamp.Time, DeliveryAt: bar.Stamp.Time, RecordOrdinal: uint64(bar.Stamp.Index),
		PriceKnown: bar.PriceKnown && bar.Closed, VolumeKnown: bar.VolumeKnown && bar.Closed,
		OHLC: old.OHLC{Open: bar.OHLC.Open, High: bar.OHLC.High, Low: bar.OHLC.Low, Close: bar.OHLC.Close}, Volume: bar.Volume}
	value, err := state.Apply(frame)
	if err != nil {
		return ShortBar{}, err
	}
	bar.Technical = shortTechnical(value.Technical)
	return bar, nil
}

// shortRef は、実際に配送した足へ幅と配送Rawの参照を結びます。
//
// 引数: bar(ShortBar)は既知性を含む確定足です。
// 返り値: rules.Ref は値を複製しない参照です。
func shortRef(bar ShortBar) rules.Ref {
	return rules.Ref{ID: bar.ID, Width: bar.Width, End: bar.End, Delivered: bar.Stamp}
}

// aggregateThree は、同場の実連続3本からOHLCと量の既知性を別に作ります。
//
// 引数: children([]ShortBar)は当場180秒格子の三つの1分です。
// 返り値: ShortBar は価格/量未知を補完せず最新子の配送Rawを持つ3分足です。
func aggregateThree(children []ShortBar) ShortBar {
	first, last := children[0], children[2]
	bar := ShortBar{ID: fmt.Sprintf("146/%s/180/%.0f", first.Session, first.Start), Session: first.Session, Contract: first.Contract,
		Width: 180, Start: first.Start, End: last.End, AvailableAt: last.End + 60, Stamp: last.Stamp,
		PriceKnown: true, VolumeKnown: true, Closed: true, Children: []rules.Ref{}}
	for i, child := range children {
		bar.Children = append(bar.Children, shortRef(child))
		bar.PriceKnown = bar.PriceKnown && child.PriceKnown && child.Closed
		bar.VolumeKnown = bar.VolumeKnown && child.VolumeKnown && child.Closed
		bar.Closed = bar.Closed && child.Closed
		if i == 0 {
			bar.OHLC = child.OHLC
		} else {
			bar.OHLC.High = math.Max(bar.OHLC.High, child.OHLC.High)
			bar.OHLC.Low = math.Min(bar.OHLC.Low, child.OHLC.Low)
			bar.OHLC.Close = child.OHLC.Close
		}
		bar.Volume += child.Volume
	}
	if !bar.PriceKnown {
		bar.OHLC = rules.OHLC{}
	}
	if !bar.VolumeKnown {
		bar.Volume = 0
	}
	return bar
}

// Add は、実1分を配送し180秒端でだけ3分を追加して各幅の数値を更新します。
//
// 引数: m(Minute)は次の60秒格子で、Missing足も明示します。
// 返り値: []ShortBar/error は1分と任意の3分の値copy、又は状態非変更の拒否です。
func (t *ShortTracker) Add(m Minute) ([]ShortBar, error) {
	if err := t.validMinute(m); err != nil {
		return nil, err
	}
	next := *t
	next.stats = t.Stats()
	next.seen = make(map[string]bool, len(t.seen)+1)
	for key, value := range t.seen {
		next.seen[key] = value
	}
	next.children = append([]ShortBar{}, t.children...)
	csv := m.CSV
	bar := ShortBar{ID: m.ID, Session: m.Session, Contract: m.Contract, Width: 60,
		Start: m.Start, End: m.End, AvailableAt: m.AvailableAt, Stamp: m.Stamp,
		PriceKnown: m.PriceKnown && m.Closed && !m.Missing, VolumeKnown: m.VolumeKnown && m.Closed && !m.Missing,
		Closed: m.Closed && !m.Missing, CSV: &csv, CSVLine: m.CSVLine, Children: []rules.Ref{}}
	if bar.PriceKnown {
		bar.OHLC = m.OHLC
	}
	if bar.VolumeKnown {
		bar.Volume = m.Volume
	}
	bar, err := applyShort(&next.one, bar)
	if err != nil {
		return nil, err
	}
	result := []ShortBar{bar}
	next.stats["minutes"]++
	if bar.PriceKnown {
		next.stats["price_known_1m"]++
	} else {
		next.stats["numeric_reset_1m"]++
	}
	if bar.VolumeKnown {
		next.stats["volume_known_1m"]++
	}
	// ----------------------------------------
	// 当場180秒格子の三本だけを集約し、末尾端数は数値へ投入しません。
	groupStart := t.start + 180*math.Floor((m.Start-t.start)/180)
	if groupStart+180 > t.end {
		next.stats["partial_3m_minutes"]++
	} else {
		next.children = append(next.children, bar)
		if len(next.children) == 3 {
			three := aggregateThree(next.children)
			three, err = applyShort(&next.three, three)
			if err != nil {
				return nil, err
			}
			result = append(result, three)
			next.children = []ShortBar{}
			next.stats["bars_3m"]++
			if three.PriceKnown {
				next.stats["price_known_3m"]++
			} else {
				next.stats["numeric_reset_3m"]++
			}
			if three.VolumeKnown {
				next.stats["volume_known_3m"]++
			}
		}
	}
	// ----------------------------------------
	// 両尺度の計算が正常終了した場合だけ、入力の消費を確定します。
	next.next, next.stamp, next.hasStamp = m.End, m.Stamp, true
	next.seen[m.ID] = true
	*t = next
	return result, nil
}

// Stats は、現在場の形成件数を外部変更できないcopyで返します。
//
// 引数: ありません。
// 返り値: map[string]int は当場の1分/3分/未知reset/端数の件数です。
func (t *ShortTracker) Stats() map[string]int {
	result := map[string]int{}
	for key, value := range t.stats {
		result[key] = value
	}
	return result
}
