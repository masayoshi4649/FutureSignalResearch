"""146のSource全源と依存・人工検査を自然実行前に固定する。"""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
SPEC = ROOT/'work/146_短期完成パターン入口の採用仕様.md'
SPEC_SHA = 'd43abc95616aa3fdb53fb4280da1069652cc889ff427a5517cd332ab8cd15b70'


def sha(path: Path) -> str:
    """
    機能: コード・文書・小参照の指紋を求める。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def record(path: Path) -> dict:
    """
    機能: 固定対象の小型参照を作る。
    引数: path(Path)。返り値: dictはpath/bytes/sha256。
    """
    return {'path': str(path.relative_to(ROOT)), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def command(args: list[str]) -> dict:
    """
    機能: 人工test/vet/buildだけを実行し終了を確認する。
    引数: args(list[str])。返り値: dictは引数/終了コード/出力。
    """
    result = subprocess.run(args, cwd=HERE, capture_output=True, encoding='utf-8', errors='replace')
    assert result.returncode == 0, result.stdout + result.stderr
    return {'引数': args, '終了コード': result.returncode, '標準出力': result.stdout, '標準エラー': result.stderr}


def main() -> None:
    """
    機能: 元式/再用同体と統合16人工を確認し最終proofを保存する。
    引数: なし。返り値: None。Source自然CLIを呼ばない。
    """
    assert sha(SPEC) == SPEC_SHA
    provenance = json.loads((HERE/'由来.json').read_text(encoding='utf-8'))
    for row in provenance['同体再用']:
        a, b = ROOT/row['source']['path'], ROOT/row['target']['path']
        assert sha(a) == row['source']['sha256'] and sha(b) == row['target']['sha256']
        assert a.read_bytes().replace(b'package vwmaentry141', b'package shortpattern146', 1) == b.read_bytes()
    numeric = json.loads((HERE/'短期数値の由来.json').read_text(encoding='utf-8'))
    for row in numeric['数値の由来']:
        a, b = ROOT/row['元'], ROOT/row['複写']
        assert sha(a) == row['元SHA256'] and sha(b) == row['複写SHA256'] and a.read_bytes() == b.read_bytes()
    for row in numeric['専有新規'] + numeric['射影の型依存']:
        assert sha(ROOT/row['path']) == row['sha256']
    reference = json.loads((HERE/'入力参照.json').read_text(encoding='utf-8'))
    assert reference['trial'] == 146
    assert reference['background']['sha256'] == '6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec'
    assert reference['csv_manifest']['sha256'] == '07e136e2b77a0029ddacd955abad16a9240373fa849ec96b553c2875e1e85147'
    for row in (reference['background'], reference['csv_manifest']):
        assert Path(row['path']).stat().st_size == row['bytes']
    sources = set(HERE.rglob('*.go')) | {HERE/'go.mod', Path(__file__).resolve(), SPEC}
    sources |= {p for p in HERE.glob('*') if p.suffix in ('.md', '.json') and p.name != '準備の確認.json'}
    for folder in ('work/三時間軸の公開器', 'work/118複数技法の入口条件'):
        sources |= {p for p in (ROOT/folder).glob('*.go') if not p.name.endswith('_test.go')}
        sources.add(ROOT/folder/'go.mod')
    before = {str(p): sha(p) for p in sources}
    checks = [command(['go', 'version']), command(['go', 'test', '-count=1', '-v', './...']),
              command(['go', 'vet', './...']), command(['go', 'build', '-o', '短期完成生成.exe', './cmd/run'])]
    assert before == {str(p): sha(p) for p in sources}
    proof = {'成功': True, '試行': 146, '編集停止': True, '人工主群数': 16, '確認': checks,
             '源': [record(p) for p in sorted(sources)], '実行ファイル': record(HERE/'短期完成生成.exe'),
             '採用仕様SHA256': SPEC_SHA, '小参照SHA256': sha(HERE/'入力参照.json'),
             '数値4源本文同体': True, 'CSV及びdecoder_package以外同体': True,
             '作者分担': {'short及び基底数値': 'review131', '状態とCSV_Raw統合': 'settings119'},
             '実効workers': 1, '数値carry': '前場全品質成功後・同限月の実配送prefixのみ',
             '自然CSV_Raw本文読取': False, '自然Source生成': False, '新金融読取': False,
             '追加2場読取': False, '旧源変更': False,
             '証明していない範囲': ['自然の取得/頻度/全場参加/先着率/利益', '実受信時刻', 'mini実板/実IFD/口座枚数/必須追尾']}
    out = HERE/'準備の確認.json'; out.write_text(json.dumps(proof, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'success': True, 'proof_sha256': sha(out), 'executable_sha256': sha(HERE/'短期完成生成.exe'), 'sources': len(sources)}, ensure_ascii=True))


if __name__ == '__main__':
    main()
