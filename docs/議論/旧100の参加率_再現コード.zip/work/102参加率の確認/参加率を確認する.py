"""既存P0の保存枠だけを新しい参加率分母へ再集計する。"""

from collections import Counter
from datetime import datetime,timedelta,timezone
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import sys


ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
JST=timezone(timedelta(hours=9))
COMPLETION=ROOT/'work/101短秒市場の再生/全54場/完了.json'
COMPLETION_SHA='6a2b90286827f24f0a3b5320282741a06e4ac77d3fc6a46172629ed8420dea16'
RESULT100=ROOT/'study/00100_費用後利益化の前後で保護を分ける/成果物/結果.json'
RESULT100_SHA='47a46a85bc30cf138effceba9cc899e33968430735c04e2aa271cc1561c839ba'
RESULT94=ROOT/'study/00094_連続出生を固定した個別利益追尾/成果物/結果.json'
RESULT94_SHA='f3696001625af9b6082555d2465349838483018a6fcc8f0d521624533f77ed36'
CORE_PATH=ROOT/'work/101保有技法の抽出実行案/保有枠の抽出.py'
CORE_SHA='799e407575b76951fe2879ece3a900b823916684c65dbbd941082cb8e7759950'
KEYS=tuple('E3S_B5Q_P0_C'+str(c)+'_D'+str(d) for c in (0,5) for d in (0,1))
ACTIONS={'新規':'NEW','保有':'HOLD','待機':'WAIT','判定不能':'UNKNOWN'}


def need(ok,label):
    """
    機能: 集合/時計/保存型の不一致を拒否する。
    引数: ok(bool)、label(str)は条件と出典。
    返り値: None。不成立時はValueError。
    """
    if not ok:raise ValueError(label)


def digest(path):
    """
    機能: 明示した小gzip/集約/コードだけをhashする。
    引数: path(Path)は許可ファイル。
    返り値: strはSHA256。Rawや巨大Nativeを探索しない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fixed_core():
    """
    機能: 既存字句射影だけをSHA付きimportする。
    引数: なし。
    返り値: moduleは固定799e。金融やSourceを再実行しない。
    """
    need(digest(CORE_PATH)==CORE_SHA,'固定parserSHA差')
    spec=importlib.util.spec_from_file_location('参加率の限定射影799e',CORE_PATH)
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
    return module


CORE=fixed_core()


def project(text,selector):
    """
    機能: 固定字句parserで許可fieldだけを展開する。
    引数: text(str)、selector(dict)はJSON本文と許可型。
    返り値: dictは限定値。S帳簿・損益・Source通知はskipする。
    """
    value,end=CORE.project_value(text,0,selector)
    need(CORE.whitespace(text,end)==len(text),'JSON末尾差')
    return value


def schedule(session,minutes):
    """
    機能: 半開区間の5分全枠から絶対15分時計を抽出する。
    引数: session(dict)、minutes(int)は保存開始/終了と5又は15。
    返り値: list[int]は[開始+1800,終了-1800)の予定枠。
    """
    need(minutes in (5,15),'時計は5/15分だけ')
    start,end=session['start'],session['end']
    need(type(start) in (int,float) and type(end) in (int,float) and start==int(start) and end==int(end),'整数価格時計')
    date=datetime.fromtimestamp(start,JST)
    anchor=date.replace(hour=9 if session['kind']=='Day' else 17,minute=15 if session['kind']=='Day' else 30,second=0,microsecond=0).timestamp()
    return [at for at in range(int(start+1800),int(end-1800),300)
            if minutes==5 or (at-anchor)%900==0]


def summarize(book,minutes,exclude_us):
    """
    機能: 保存行動を予定全枠へ結び、欠測をUNKNOWNとして分母に残す。
    引数: book(dict)、minutes(int)、exclude_us(bool)はP0限定保存値・抽出時計・US30分の分母除外。
    返り値: dictは枠計数/受理/実約定の別計数。仮想15分運転は作らない。
    """
    traces=book['grid_traces'] or []
    by_at={row['at']:row for row in traces}
    need(len(by_at)==len(traces),'保存grid重複')
    clock=schedule(book['session'],minutes)
    us=book['config']['us_open']
    us_known=book['session']['kind']=='Day' or us>0
    removed=[at for at in clock if exclude_us and book['session']['kind']=='Night' and us>0 and us<=at<us+1800]
    times=[at for at in clock if at not in set(removed)]
    out=Counter({'分母':len(times),'NEW':0,'HOLD':0,'WAIT':0,'UNKNOWN':0,'欠測枠':0,'US時計不明枠':0,
      'US除外枠':len(removed),'受理要求回数':0,'受理枚数':0,'実新規約定回数':0,'実新規約定枚数':0,
      '実新規約定あり枠':0,'枠開始時実保有あり枠':0,'同枠NEWかつ実保有':0,'枠内実新規約定または枠開始実保有':0})
    fills=[f for f in (book['fills'] or []) if f['action']=='new']
    for at in times:
        row=by_at.get(at)
        if row is None:
            out['UNKNOWN']+=1;out['欠測枠']+=1
        else:
            need(row['action'] in ACTIONS,'保存行動の型')
            action=ACTIONS[row['action']]
            if exclude_us and not us_known:
                action='UNKNOWN';out['US時計不明枠']+=1
            out[action]+=1
            out['受理要求回数']+=row['accepted_count'];out['受理枚数']+=row['accepted_quantity']
            held=row['open_buy']+row['open_sell']>0
            out['枠開始時実保有あり枠']+=held
            out['同枠NEWかつ実保有']+=held and action=='NEW'
            need((action!='NEW' or row['accepted_count']>0) and (action!='HOLD' or held),'NEW/HOLDの保存根拠差')
        actual=[f for f in fills if at<=f['quote']['time']<at+minutes*60]
        out['実新規約定回数']+=len(actual);out['実新規約定枚数']+=sum(f['quantity'] for f in actual)
        out['実新規約定あり枠']+=bool(actual)
        out['枠内実新規約定または枠開始実保有']+=bool(actual) or row is not None and row['open_buy']+row['open_sell']>0
    need(sum(out[k] for k in ('NEW','HOLD','WAIT','UNKNOWN'))==out['分母'],'分類の分母不一致')
    return dict(out)


def ratios(counts):
    """
    機能: NEW/HOLDの和集合を分子に率を付ける。
    引数: counts(dict)は排他的枠計数。
    返り値: dictは率0〜1と百分率、ユーザー指定25/50%への到達表示。
    """
    result=dict(counts);n=counts['NEW']+counts['HOLD'];den=counts['分母']
    result.update(参加分子=n,参加率=None if den==0 else n/den,参加率_pct=None if den==0 else n/den*100,
                  最低25pct到達=False if den==0 else n*4>=den,目標50pct到達=False if den==0 else n*2>=den)
    return result


def artificial():
    """
    機能: 日夜枠数/絶対15分/欠測分母/同枠一回の狭い人工を確認する。
    引数: なし。
    返り値: None。保存市場値は変更しない。
    """
    day=datetime(2026,9,21,8,45,tzinfo=JST).timestamp()
    night=datetime(2026,9,21,17,0,tzinfo=JST).timestamp()
    for kind,start,hours,n5,n15 in (('Day',day,7,72,24),('Night',night,13,144,48)):
        session=dict(kind=kind,start=start,end=start+hours*3600)
        need(len(schedule(session,5))==n5 and len(schedule(session,15))==n15,'人工の日夜予定枠')
    s=dict(kind='Day',start=day,end=day+7*3600);at=schedule(s,5)[0]
    b=dict(session=s,config={'us_open':0},fills=[],grid_traces=[dict(at=at,action='新規',accepted_count=1,accepted_quantity=2,open_buy=2,open_sell=0)])
    r=summarize(b,5,False)
    need(r['分母']==72 and r['NEW']==1 and r['HOLD']==0 and r['UNKNOWN']==71 and ratios(r)['参加分子']==1,'欠測維持と同枠一回')


def main():
    """
    機能: 完了54小gzipのP0限定値だけを集計し新規workへ保存する。
    引数: なし。固定100の行動集約/94小集約と明示された101金融54だけ。
    返り値: None。正式試行/売買/既存xlsxは変更しない。
    """
    artificial()
    need(digest(COMPLETION)==COMPLETION_SHA and digest(RESULT100)==RESULT100_SHA and digest(RESULT94)==RESULT94_SHA,'固定metadata/小集約SHA差')
    complete=json.loads(COMPLETION.read_text(encoding='utf-8'))
    need(complete['成功'] is True and complete['stage']=='full54' and complete['前後不変'] is True and len(complete['結果'])==54,'金融完了/54不足')
    allowed100=project(RESULT100.read_text(encoding='utf-8'),{'判断分類':{key:{'枠':True} for key in KEYS},
      '場別':[{'session':True,'key':True,'grid_metrics':True}]})
    expected_ids=sorted({r['session'] for r in allowed100['場別']})
    need(len(expected_ids)==54 and [r['session'] for r in complete['結果']]==expected_ids,'許可済み完全54場')
    value94=project(RESULT94.read_text(encoding='utf-8'),{'場数':True,'集計':{'S0_C0_D0':{'active_sessions':True,'positions':True}}})
    before={str(COMPLETION):COMPLETION_SHA,str(RESULT100):RESULT100_SHA,str(RESULT94):RESULT94_SHA,str(CORE_PATH):CORE_SHA}
    totals={key:{name:Counter() for name in ('5分_US除外なし','5分_US除外あり','15分_US除外なし','15分_US除外あり')} for key in KEYS}
    original={key:Counter({'分母':0,'NEW':0,'HOLD':0,'WAIT':0,'UNKNOWN':0}) for key in KEYS}
    details=[]
    selector={'session':True,'p0_100_match':True,'books':{key:{'session':True,'config':True,'grid_metrics':True,
      'grid_traces':[{'at':True,'action':True,'accepted_count':True,'accepted_quantity':True,'open_buy':True,'open_sell':True}],
      'fills':[{'id':True,'action':True,'quantity':True,'quote':{'time':True}}]} for key in KEYS}}
    for entry in complete['結果']:
        p=Path(entry['path']);need(p.is_file() and p.stat().st_size<2*1024*1024 and digest(p)==entry['sha256'],'指定小gzip/SHA差')
        before[str(p)]=entry['sha256']
        with gzip.open(p,'rt',encoding='utf-8') as stream:v=project(stream.read(),selector)
        need(v['session']==entry['session'] and v['p0_100_match']['full_json'] is True and v['p0_100_match']['excluded']==[]
             and v['p0_100_match']['keys']==list(KEYS) and entry['p0_books']==4 and entry['books']==12,'P0対100全JSON対照metadata')
        rows={}
        for key in KEYS:
            book=v['books'][key];need(book['session']['id']==entry['session'] and book['config']['entry_timing']=='B5Q','P0場/時計差')
            full=Counter(ACTIONS[t['action']] for t in (book['grid_traces'] or []))
            expected=allowed100['判断分類'][key]['枠']
            original[key]['分母']+=len(book['grid_traces'] or [])
            for name,count in full.items():original[key][name]+=count
            rows[key]={}
            for minutes in (5,15):
                for exclude in (False,True):
                    name=str(minutes)+'分_US除外'+('あり' if exclude else 'なし')
                    c=summarize(book,minutes,exclude);totals[key][name].update(c);rows[key][name]=c
        details.append({'session':entry['session'],'場種':book['session']['kind'],'枠集計':rows})
        print('保存枠集計 '+entry['session'],flush=True)
    for key in KEYS:
        expected=allowed100['判断分類'][key]['枠']
        need({name:original[key][eng] for name,eng in ACTIONS.items()}==expected,'元100の全既存分類と不一致')
        need(original[key]['分母']==6436,'元全既存6436分母差')
        need(totals[key]['5分_US除外なし']['分母']==5832 and totals[key]['15分_US除外なし']['分母']==1944,'主分母5832/1944差')
    after={p:digest(Path(p)) for p in before};need(before==after,'入力前後SHA差')
    classified={key:{name:ratios(dict(c)) for name,c in rates.items()} for key,rates in totals.items()}
    result={'成功':True,'確認日':'2026-11-09','正式採番102':False,
      '定義':{'主分母':'[Book.session.start+1800, Book.session.end−1800) の全予定5分枠。欠測も分母に残す。',
       '5分時計':'Day09:15〜15:10の72枠、Night17:30〜翌05:25の144枠。27開始日で5832。',
       '15分時計':'5分列から絶対JST Day09:15+15分n、Night17:30+15分nを抽出。Day24/Night48、全1944。',
       '15分の限界':'既存5分運転を15分時計で観測した集計。新規/退出を15分へ移した別運転ではない。',
       'US除外':'Nightのconfig.us_open <= t < us_open+1800 を分母から除く場合と残す場合。既存B5QのUS見送り自体は変更しない。',
       '分類':'保存行動の優先 NEW（受理新規あり）→HOLD（実保有あり）→UNKNOWN→WAIT。欠測はUNKNOWN。同枠保有と新規を二重加算しない。',
       '新規受理と実約定':'NEWは枠開始時の新規要求受理。実約定は別欄で[t,t+5分又は15分)の実new fill数/枚を記録。15分の受理と窓内fillは観測時計が異なる。',
       '参加率':'(NEW+HOLD)/全対象予定枠。受理新規枠数と実取得件数を同一視しない。',
       '副分母':'保存された全既存5分6436枠。開始quietも含む旧集計の参照で、新方針の主分母ではない。'},
      '主C0D0':classified[KEYS[0]],'全4感度':classified,'副表_全既存5分':{key:ratios(dict(c)) for key,c in original.items()},
      'S0':{'同時計保有率':None,'理由':'許可された94小集約/100結果にS0の各5分又は15分時点の保有履歴がない。取引あり場を保有参加率へ置換しない。',
       '参考_取引あり場':value94['集計']['S0_C0_D0']['active_sessions'],'参考_全場':value94['場数'],'参考_玉数':value94['集計']['S0_C0_D0']['positions']},
      'details':details,'入力SHA256前':before,'入力SHA256後':after,'前後不変':True,'金融完了SHA256':COMPLETION_SHA,
      'コードSHA256':digest(Path(__file__)),'人工':'日夜72/144・24/48、欠測維持、NEWと保有同枠の一回分類',
      '限界':'保存行動の観測で、枠間の全実保有時間率ではない。新15分戦略や新参加改善・未知期間を検証していない。',
      '巨大Native/Raw/CSV/Tape/Source/新金融/既存xlsx編集':0}
    with (HERE/'結果.json').open('x',encoding='utf-8',newline='\n') as stream:json.dump(result,stream,ensure_ascii=False,indent=2);stream.write('\n')
    lines=['# 新方針分母での既存E3S/P0参加率','',result['定義']['主分母'],result['定義']['15分時計'],'',
      '|時計/US30分の分母除外|分母|新規受理枠|保有枠|待機|不能|参加分子|参加率|','|---|---:|---:|---:|---:|---:|---:|---:|']
    for name,r in result['主C0D0'].items():lines.append('|'+name+'|'+'|'.join(str(r[k]) for k in ('分母','NEW','HOLD','WAIT','UNKNOWN','参加分子'))+'|'+format(r['参加率_pct'],'.4f')+'%|')
    lines+=['','新規と保有は同枠一回。NEWは受理であり実約定ではない。実new fill回数/枚数・窓内fillあり枠はJSONで別計数。5分から抽出した15分は既存運転の観測で、15分だけに売買を移した再生ではない。','',
      'US除外なしは既存の米国開始見送りを解除した売買ではない。US静観枠も分母へ残す集計。欠けた予定枠はUNKNOWNで分母に残す。','',
      '全既存6436枠の副表は旧100の新規24/保有13/待6378/不能21と一致する。主表は開始30分と末尾30分を除いた別分母なので混同しない。','',
      'S0は許可された小集約では同時計保有率を復元できず未検証。取引あり54/54場を参加率100%と呼ばない。','',
      'ユーザー指定の最低25%・目標50%に対する観測値であり、既存閾値/正式試行/方式/既存xlsxは変更していない。金融再生・原板・巨大Native・Source本文の読取は0。入力SHAと全4感度、場別の分母はJSONへ保存。','']
    (HERE/'メモ.md').write_text('\n'.join(lines),encoding='utf-8',newline='\n')
    print(json.dumps(result['主C0D0'],ensure_ascii=False))


if __name__=='__main__':main()
