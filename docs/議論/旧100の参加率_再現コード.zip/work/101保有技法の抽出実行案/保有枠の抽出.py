"""固定100からP0の必要fieldだけを射影し、実保有の技法可用性を数える。"""

from collections import Counter
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re


ROOT=Path(__file__).resolve().parents[2]
MODEL_PATH=ROOT/"work/101保有中の技法時計/抽出のコード案.py"
MODEL_SHA="6969e0718c1650397045fa084dc5c43e12cd8f25dc4aeca9ff4a3d22eb5b070b"
if hashlib.sha256(MODEL_PATH.read_bytes()).hexdigest()!=MODEL_SHA:raise ValueError("元型案SHA差")
SPEC=importlib.util.spec_from_file_location("固定101型案",MODEL_PATH);MODEL=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(MODEL)
PUBLIC_PATH=ROOT/"scripts/FAR5分枠の技法判定の監査/技法の保存照合.py"
PUBLIC_SHA="b5d1af7fb85d4446a47573a4389abfa433177189cb01d901bdd53a8a38b8d5e6"
if hashlib.sha256(PUBLIC_PATH.read_bytes()).hexdigest()!=PUBLIC_SHA:raise ValueError("固定96公開時計validator差")
PUBSPEC=importlib.util.spec_from_file_location("固定96公開型のみ101",PUBLIC_PATH);PUBLIC=importlib.util.module_from_spec(PUBSPEC);PUBSPEC.loader.exec_module(PUBLIC)
KEYS=MODEL.KEYS;need=MODEL.need
CLOCK={k:True for k in ("time","index","source_line")}
SOURCE={k:True for k in ("method","signal_id","kind","parent","source_id","quantity_micro","birth_quantity","birth_time")}|{"birth_quote":CLOCK}
ACTIVATION={"quote":CLOCK,"phase":True,"quantity":True,"reserved":True,"unit_net":True}
POSITION={k:True for k in ("id","entry_order_id","source_hold_id","side","initial_quantity","protection_active")}|{"source":SOURCE,"entry_quote":CLOCK,"closed_quote":CLOCK,"activation":ACTIVATION}
ORDER={k:True for k in MODEL.ORDER_FIELDS}|{"protection_point":{"phase":True},"native_close_signal_id":True,"native_close_notice_id":True}
FILL={k:True for k in ("id","order_id","position_id","action","quantity","reason")}|{"quote":CLOCK,"source":SOURCE}
BOOK={"session":True,"key":True,"config":True,"complete":True,"finished":True,"positions":[POSITION],"orders":[ORDER],"fills":[FILL],
      "source_events":[{"at":True,"phase":True,"order_id":True,"quote":True}],"grid_traces":[{"at":True,"quote":True,"quote_known":True}]}
SELECT={"trial":True,"version":True,"session":True,"actual_run_complete":True,"source_reexecuted":True,"charts_recomputed":True,"books":{k:BOOK for k in KEYS},"chart_grids":True,
        "gate_assessments":[{"key":True,"ordinal":True,"candidate":{"at":True},"assessment":{"decision":{"snapshot_id":True}}}]}


def whitespace(text: str,index: int) -> int:
    """
    機能: JSONの空白だけを進める。
    引数: text(str)、index(int)は本文と開始位置。
    返り値: intは次の非空白位置。
    """
    while index<len(text) and text[index] in " \r\n\t":index+=1
    return index


def skip_value(text: str,index: int) -> int:
    """
    機能: 不許可JSON値をPython値へ展開せず字句として飛ばす。
    引数: text(str)、index(int)は本文と値の先頭。
    返り値: intは値の直後。市場原JSONの妥当性は先行固定SHAに依存する。
    """
    index=whitespace(text,index);need(index<len(text),"JSON値欠落")
    if text[index]=='"':return json.decoder.scanstring(text,index+1,True)[1]
    if text[index] in "[{":
        stack=[text[index]];index+=1
        while stack:
            need(index<len(text),"JSON閉じ欠落")
            ch=text[index]
            if ch=='"':index=json.decoder.scanstring(text,index+1,True)[1];continue
            if ch in "[{":stack.append(ch)
            elif ch in "]}":need(stack.pop()==("[" if ch=="]" else "{"),"JSON括弧不整合")
            index+=1
        return index
    match=re.match(r'(?:null|true|false|-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?)',text[index:])
    need(match is not None,"JSON scalar型")
    end=index+match.end();need(end==len(text) or text[end] in " \t\r\n,]}","JSON scalar境界")
    return end


def project_value(text: str,index: int,selector) -> tuple:
    """
    機能: 明示fieldのJSONだけを再帰射影する。
    引数: text(str)、index(int)、selector(dict/list/bool)は本文/開始/許可型。
    返り値: tuple[object,int]は許可値と直後位置。禁止金額や峰を数値展開しない。
    """
    index=whitespace(text,index)
    if text.startswith("null",index):return None,index+4
    if selector is True:
        end=skip_value(text,index);return json.loads(text[index:end]),end
    if type(selector) is list:
        need(text[index]=='[',"射影array型");index=whitespace(text,index+1);result=[]
        if text[index]==']':return result,index+1
        while True:
            value,index=project_value(text,index,selector[0]);result.append(value);index=whitespace(text,index)
            if text[index]==']':return result,index+1
            need(text[index]==',',"array区切り");index=whitespace(text,index+1)
    need(type(selector) is dict and text[index]=='{',"射影object型");index=whitespace(text,index+1);result={};seen=set()
    if text[index]=='}':return result,index+1
    while True:
        need(text[index]=='"',"object key型");key,index=json.decoder.scanstring(text,index+1,True);need(key not in seen,"重複JSON key");seen.add(key)
        index=whitespace(text,index);need(text[index]==':',"object colon");index=whitespace(text,index+1)
        if key in selector:result[key],index=project_value(text,index,selector[key])
        else:index=skip_value(text,index)
        index=whitespace(text,index)
        if text[index]=='}':return result,index+1
        need(text[index]==',',"object区切り");index=whitespace(text,index+1)


def project_text(text: str) -> dict:
    """
    機能: 固定100本文を許可fieldへ最小化する。
    引数: text(str)は固定SHA確認後のJSON又は人工JSON。
    返り値: dictはP0四会計と共有技法のみ。
    """
    value,end=project_value(text,0,SELECT);need(whitespace(text,end)==len(text),"JSON余分本文なし");return value


def stamp_equal(a: dict,b: dict) -> bool:
    """
    機能: Source時計と原行の同一を三fieldで比べる。
    引数: a/b(dict)はquote出典。
    返り値: boolはtime/index/source_lineの完全一致。
    """
    return all(a[k]==b[k] for k in CLOCK)


def validate_history(book: dict,session: str) -> tuple:
    """
    機能: 射影した実玉/注文/Fillの所有と終了IDを厳密に結ぶ。
    引数: book(dict)、session(str)はP0履歴と場。
    返り値: tuple[dict,dict]は実玉/実Fill索引。別玉のFillで予約を解放しない。
    """
    cfg=book["config"];need(book["key"] in KEYS and cfg["policy"]=="P0" and cfg["gate_policy"]=="E3S" and cfg.get("harvest_policy","")=="" and cfg.get("risk_policy","")=="","固定P0/E3S/空政策")
    need(book["session"]["id"]==session and book["complete"] is True and book["finished"] is True,"固定完結P0")
    pp={p["id"]:p for p in book["positions"]};oo={o["id"]:o for o in book["orders"]};ff={f["id"]:f for f in book["fills"]}
    need(len(pp)==len(book["positions"]) and len(oo)==len(book["orders"]) and len(ff)==len(book["fills"]),"玉/注文/Fill ID重複なし")
    sources=set()
    for p in pp.values():
        key=MODEL.source_key(session,p["source"]);need(key not in sources,"同Source複数実玉なし");sources.add(key)
        need(p["closed_quote"] is not None and p["entry_quote"]["time"]<=p["closed_quote"]["time"] and p["protection_active"]==(p["activation"] is not None),"実取得/完結/Activation型")
        need(p["entry_order_id"] in oo,"実新規注文存在")
        fs=[f for f in ff.values() if f["position_id"]==p["id"]];news=[f for f in fs if f["action"]=="new"];closes=[f for f in fs if f["action"]=="close"]
        need(len(news)==1 and news[0]["quantity"]==p["initial_quantity"] and stamp_equal(news[0]["quote"],p["entry_quote"]),"実取得binding")
        entry=oo[p["entry_order_id"]]
        need(news[0]["order_id"]==p["entry_order_id"] and entry["kind"]=="entry" and entry["position_id"]==p["id"] and entry["fill_id"]==news[0]["id"],"実玉entry_order_id全結合")
        need(sum(f["quantity"] for f in closes)==p["initial_quantity"] and closes,"実全返済量")
        last=max(closes,key=lambda f:(f["quote"]["time"],f["quote"]["index"],f["quote"]["source_line"]))
        need(stamp_equal(last["quote"],p["closed_quote"]),"最終返済quote")
    for f in ff.values():
        need(f["position_id"] in pp and f["order_id"] in oo,"Fill所有/注文存在")
        o=oo[f["order_id"]];need(o["fill_id"]==f["id"] and o["position_id"]==f["position_id"] and o["quantity"]==f["quantity"] and f["action"]==("new" if o["kind"]=="entry" else "close"),"Fillと注文全結合")
        need(f["source"]==pp[f["position_id"]]["source"],"実Source出典全値でFill所有")
    for o in oo.values():
        if o["kind"]=="exit":
            need(o["status"]!="cancelled" and o["cancel_time"] is None,"固定100 exit取消は存在しない")
            if o["fill_id"]:
                need(o["fill_id"] in ff,"注文FillID存在");f=ff[o["fill_id"]]
                need(f["order_id"]==o["id"] and f["position_id"]==o["position_id"] and f["action"]=="close" and f["quantity"]==o["quantity"],"返済Fill全結合")
    return pp,ff


def normalize_slices(book: dict) -> dict:
    """
    機能: 既知のGo nil slice四欄だけを空listとして値コピーする。
    引数: book(dict)は射影済みP0。
    返り値: dictは新しい外側写像。missing/非listは拒否し、元入力を変えない。
    """
    out=dict(book)
    for name in ("positions","orders","fills","source_events"):
        need(name in book and (book[name] is None or type(book[name]) is list),"Go slice型/欠落:"+name)
        out[name]=[] if book[name] is None else book[name]
    return out


def force_proofs(book: dict,grid: dict) -> set:
    """
    機能: 同clockのForce先行予約を注文/SourceEvent/当枠quoteへ一意結合する。
    引数: book/grid(dict)は固定P0と当枠。
    返り値: set[str]は厳密証明済み注文ID。不足は推測せず元cutoffでunknown。
    """
    at=grid["at"];session=book["session"];forces={session["force_close"]}
    if session["kind"]=="Night":forces.add(book["config"]["us_open"]-900)
    if at not in forces or grid["quote"] is None:return set()
    if not (0<grid["quote"]["time"]<at and grid["quote"]["source_line"]>0 and grid["quote"]["index"]>=0):return set()
    proof=set()
    for o in book["orders"]:
        if o["kind"]!="exit" or o["request_time"]!=at or o["request_quote"]["time"]>=at or o["protection_point"] is not None:continue
        events=[e for e in book["source_events"] if e["order_id"]==o["id"]]
        if len(events)!=1:continue
        e=events[0]
        if e["at"]==at and e["phase"]=="source_close" and e["quote"]==o["request_quote"]==grid["quote"]:proof.add(o["id"])
    return proof


def availability(context: dict,grid: dict,session: str,side: int) -> dict:
    """
    機能: 基本EMA/価格/勢いと量/Spike/Recent3の可用性を個別計数する。
    引数: context/grid(dict)、session(str)、side(int)は公表文脈/当枠/場/実方向。
    返り値: dictは可用性と不足理由。exit採否/現在損益は計算しない。
    """
    at=grid["at"];ch=context["chart"];need(context["at"]==at and ch["scene"]["id"]==session,"同場当枠の公表文脈")
    PUBLIC.finite_tree(context);PUBLIC.validate_snapshot(ch,at);PUBLIC.validate_current_times(context["current"],at)
    for old_snapshot in context["recent3"]:PUBLIC.validate_snapshot(old_snapshot,at)
    old=MODEL.availability(context,grid,at,side);t=ch["chart"]["Technical"]
    for scale,limit in (("three",180),("fifteen",900)):
        bar=ch[scale]
        if bar["data_known"]:
            need(bar["available_at"]<=at,"既知足の論理公表未来なし")
            need(bar["bar_end"]==t["bar3_end" if scale=="three" else "bar15_end"],"足終端と指標出典")
    basic=old["price_fresh"] and old["three_published_fresh"] and old["fifteen_published_fresh"] and t["trend_known"] and t["exit_known"]
    recent=context["recent3"];sequence=len(recent)==3
    if sequence:
        sequence=all(x["scene"]==ch["scene"] and x["three"]["data_known"] and x["at"]==x["three"]["bar_end"] and x["three"]["available_at"]<=at for x in recent)
        sequence=sequence and all(recent[i]["at"]-recent[i-1]["at"]==180 for i in (1,2))
    q=grid["quote"];current=context["current"]
    current_bound=bool(old["current_quote_bound"] and q is not None and all(current[n]==q[n] for n in ("last","bid","ask")))
    values={"price_fresh":old["price_fresh"],"bar3_fresh":old["three_published_fresh"],"bar15_fresh":old["fifteen_published_fresh"],"ema_known":t["trend_known"],"momentum_known":t["exit_known"],
            "basic":bool(basic),"quantity":bool(current_bound and old["quantity_known"]),"spike":bool(t["spike_known"] and old["three_published_fresh"]),"recent3":bool(sequence)}
    values["exit3"]=bool(values["price_fresh"] and values["bar3_fresh"] and t["exit_known"])
    values["exit3_quantity"]=bool(values["exit3"] and values["quantity"])
    return {**values,"unavailable":[k for k in ("price_fresh","bar3_fresh","bar15_fresh","ema_known","momentum_known","quantity","spike","recent3") if not values[k]],"signal_evaluated":False}


def analyze(value: dict,scope: str) -> dict:
    """
    機能: 同じP0経路の四段階分母とSource別四感度を小型化する。
    引数: value(dict)は最小射影、scope(str)は人工/固定100。
    返り値: dictは実保有の可用性だけ。新exitや金額評価は作らない。
    """
    need(scope in ("人工","固定100") and set(value["books"])==set(KEYS),"scope/P0四集合")
    if scope=="固定100":need(value["trial"]==100 and value["actual_run_complete"] is True and value["source_reexecuted"] is False and value["charts_recomputed"] is False,"固定100包絡")
    session=value["session"];contexts={g["at"]:g for g in value["chart_grids"]};need(len(contexts)==len(value["chart_grids"]),"共有枠重複なし")
    result={"session":session,"scope":scope,"books":{},"sources":{}};clocks=None
    for key in KEYS:
        book=normalize_slices(value["books"][key]);pp,ff=validate_history(book,session);grids=book["grid_traces"];times=[g["at"] for g in grids]
        need(times==sorted(set(times)) and times==list(contexts),"実grid/共有公開の完全同列")
        if clocks is None:clocks=times
        need(times==clocks,"P0四つの同clock")
        counts=Counter({n:0 for n in ("positions","held_grids","basic_grids","activation_basic_grids","free_activation_basic_grids","reservation_unknown_grids","quantity_known_grids","spike_known_grids","recent3_known_grids","all_inputs_grids","all_free_activation_grids")});counts["positions"]=len(pp)
        rows=[];position_sets={n:set() for n in ("held","basic","activated_basic","free_activated_basic")}
        profiles={name:Counter({n:0 for n in ("held_grids","available_grids","activation_available_grids","free_activation_available_grids")}) for name in ("exit3","exit3_quantity")}
        profile_sets={name:{n:set() for n in ("held","available","activation_available","free_activation_available")} for name in profiles}
        for p in pp.values():
            source=MODEL.source_key(session,p["source"]);sid=json.dumps(list(source),ensure_ascii=False,separators=(",",":"))
            family=result["sources"].setdefault(sid,{"source":p["source"],"actual":{}});need(family["source"]==p["source"],"四感度のSource実出典同体")
            cells=[];final_fills=[f for f in ff.values() if f["position_id"]==p["id"] and f["action"]=="close"]
            last=max(final_fills,key=lambda f:(f["quote"]["time"],f["quote"]["index"],f["quote"]["source_line"]));order=next(o for o in book["orders"] if o["id"]==last["order_id"])
            for grid in grids:
                at=grid["at"]
                if not (p["entry_quote"]["time"]<at<=p["closed_quote"]["time"]):continue
                free=MODEL.free_at_grid(p,book["orders"],book["fills"],at,force_proofs(book,grid));a=availability(contexts[at],grid,session,p["side"]);activated=MODEL.activation_before_grid(p["activation"],at)
                need(free["quantity"]>0,"実保有枠の量")
                counts["held_grids"]+=1;position_sets["held"].add(p["id"])
                if a["basic"]:counts["basic_grids"]+=1;position_sets["basic"].add(p["id"])
                if a["basic"] and activated:counts["activation_basic_grids"]+=1;position_sets["activated_basic"].add(p["id"])
                eligible=a["basic"] and activated and free["known"] and free["free"]>0
                if eligible:counts["free_activation_basic_grids"]+=1;position_sets["free_activated_basic"].add(p["id"])
                counts["reservation_unknown_grids"]+=not free["known"]
                for field in ("quantity","spike","recent3"):counts[field+"_known_grids"]+=a[field]
                all_inputs=all(a[n] for n in ("basic","quantity","spike","recent3"));counts["all_inputs_grids"]+=all_inputs;counts["all_free_activation_grids"]+=all_inputs and eligible
                for name in profiles:
                    pc,ps=profiles[name],profile_sets[name];pc["held_grids"]+=1;ps["held"].add(p["id"])
                    if a[name]:pc["available_grids"]+=1;ps["available"].add(p["id"])
                    if a[name] and activated:pc["activation_available_grids"]+=1;ps["activation_available"].add(p["id"])
                    if a[name] and activated and free["known"] and free["free"]>0:pc["free_activation_available_grids"]+=1;ps["free_activation_available"].add(p["id"])
                profile_fourth={n:bool(a[n] and activated and free["known"] and free["free"]>0) for n in profiles}
                cells.append({"at":at,"snapshot_id":contexts[at]["snapshot_id"],"actual":free,"activation_before":activated,"inputs":a,"fourth_stage":eligible,"profile_fourth":profile_fourth,"current_u":None})
            row={"position_id":p["id"],"source_key":list(source),"side":p["side"],"initial_quantity":p["initial_quantity"],"entry_quote":p["entry_quote"],"closed_quote":p["closed_quote"],"activation":p["activation"],
                 "partial":len(final_fills)>1,"final_exit_cause":"P0保護" if order["protection_point"] is not None else "Source","final_exit_reason":last["reason"],"cells":cells}
            rows.append(row);family["actual"][key]={"position_id":p["id"],"held_grids":len(cells),"basic_grids":sum(c["inputs"]["basic"] for c in cells),"activation_basic_grids":sum(c["inputs"]["basic"] and c["activation_before"] for c in cells),"fourth_grids":sum(c["fourth_stage"] for c in cells),
                                                     "profiles":{n:{"available_grids":sum(c["inputs"][n] for c in cells),"activation_available_grids":sum(c["inputs"][n] and c["activation_before"] for c in cells),"fourth_grids":sum(c["profile_fourth"][n] for c in cells)} for n in profiles}}
        counts.update({name+"_positions":len(ids) for name,ids in position_sets.items()})
        for name in profiles:profiles[name].update({n+"_positions":len(ids) for n,ids in profile_sets[name].items()})
        result["books"][key]={"counts":dict(counts),"profiles":{n:dict(c) for n,c in profiles.items()},"positions":rows}
    result["source_count"]=len(result["sources"]);result["source_common_four"]=sum(len(x["actual"])==4 for x in result["sources"].values());return result
