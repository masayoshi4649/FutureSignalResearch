"""固定179と本日180の同じ費用・時計のセッション損益を比較する。"""
from pathlib import Path
import csv
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).parent


def fingerprint(path: Path) -> dict:
    """
    機能: 比較に使った固定CSVの物理指紋を取得する。
    引数: path(Path)は参照ファイル。
    返り値: dictは相対パス・サイズ・SHA256。
    """
    raw = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def main() -> None:
    """
    機能: Day41場の純損益順位と、夜間の既知損失例を分けて保存する。
    引数: なし。
    返り値: None。新政策・当日除外・閾値探索は実行しない。
    """
    directory = ROOT / 'outputs/00179_保有時間参加と終了前決済/179_全期_J035'
    paths = [directory / 'デイ.csv', directory / 'ナイト合計.csv',
             ROOT / 'outputs/00180_十一月十六日デイの固定適用/180_179主J035/集計.csv']
    tables = []
    for path in paths:
        with path.open(encoding='utf-8-sig', newline='') as stream:
            tables.append(list(csv.DictReader(stream)))
    days, nights, current = tables
    assert len(days) == len(nights) == 40 and len(current) == 1
    assert all(int(row['金融未知件数']) == 0 for row in days)
    assert int(current[0]['金融未知件数']) == 0
    now = float(current[0]['収支円_全件確定'])
    previous = sorted(days, key=lambda row: float(row['収支円_全件確定']))
    columns = ['セッション日', '利益円_既知', '損失円_既知', '収支円_全件確定', '取引回数']
    known_nights = [row for row in nights if int(row['金融未知件数']) == 0]
    body = {'成功': True, '新探索': False, '入力': [fingerprint(path) for path in paths],
        '比較範囲': '固定179主の過去40Dayと、同条件で固定適用した180の11月16日Day。',
        '今日収支': now, 'Day場数': 41, '今日より悪いDay数': sum(float(row['収支円_全件確定']) < now for row in days),
        '過去Day最悪5': [{key: row[key] for key in columns} for row in previous[:5]],
        '過去最悪に対する損失倍率': abs(now / float(previous[0]['収支円_全件確定'])),
        '過去Day損失総額の最大': max(float(row['損失円_既知']) for row in days),
        '今日の損失総額': float(current[0]['損失円']),
        '今日より悪い確定Night': [{key: row[key] for key in columns} for row in known_nights if float(row['収支円_全件確定']) < now],
        '注意': 'Nightに未知場があるため、Dayと合わせた厳密順位は確定しない。最大の記述は同条件のDay41場に限る。'}
    destination = HERE / '過去順位.json'
    if destination.exists():
        assert json.loads(destination.read_text(encoding='utf-8')) == body
    else:
        destination.write_text(json.dumps(body, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '今日': now, '過去Day最悪': previous[0]['収支円_全件確定'],
                      '今日より悪いDay数': body['今日より悪いDay数']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
