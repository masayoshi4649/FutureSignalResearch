"""固定180の取得7件について、当時特徴と固定規則の成立側を読み取り診断する。"""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import gzip
import hashlib
import importlib.util
import json
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
JST = timezone(timedelta(hours=9))
ADAPTER = ROOT / 'work/180本日デイ適用/純方向180.py'
RESULT = ROOT / 'work/180本日デイ適用/本日の固定結果.json.gz'
spec = importlib.util.spec_from_file_location('pure180_readonly_diagnosis', ADAPTER)
R = importlib.util.module_from_spec(spec)
spec.loader.exec_module(R)


def stamp(value: float) -> str:
    """
    機能: 観測時刻をJSTの可読文字列にする。
    引数: value(float)はUTCのUNIX秒。
    返り値: strはJST日時。
    """
    return datetime.fromtimestamp(float(value), JST).strftime('%Y-%m-%d %H:%M:%S')


def safe(value: object) -> object:
    """
    機能: NumPyと非有限値を標準JSONへ安全に写す。
    引数: value(object)は診断値。
    返り値: objectは標準JSON互換値。未知はNoneを維持する。
    """
    if isinstance(value, dict):
        return {str(k): safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, np.ndarray)):
        return [safe(v) for v in value]
    if isinstance(value, (np.bool_, bool)):
        return bool(value)
    if isinstance(value, (np.integer, int)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        return float(value) if np.isfinite(value) else None
    return value


def values(evaluator: object, side: int, event: int, names: list[str]) -> dict:
    """
    機能: 一つのq0から指定側の純特徴だけを抽出する。
    引数: evaluator(object)、side(int)は買0/売1、event(int)、names(list[str])。
    返り値: dict[str,float|None]は実側符号の値。正は当該売買方向に整合する。
    """
    return {name: safe(evaluator.factor(side, name)[0][event]) for name in names}


def clauses(evaluator: object, candidate: dict, side: int, event: int) -> list[dict]:
    """
    機能: 固定条件の値・既知性・成立を一件ずつ保存する。
    引数: evaluator(object)、candidate(dict)、side/event(int)。
    返り値: list[dict]は条件を変更せず説明可能にした票。
    """
    rows = []
    for item in candidate['conditions']:
        truth, known = evaluator.comparison(side, item)
        rows.append({**item, 'value': safe(evaluator.factor(side, item['factor'])[0][event]),
                     'known': bool(known[event]), 'passed': bool(truth[event])})
    return rows


def fmt(value: object, digits: int = 3) -> str:
    """
    機能: 診断表に未知と数値を短く表示する。
    引数: value(object)、digits(int)は小数桁。
    返り値: strは表示文字列。
    """
    return '未知' if value is None else f'{float(value):.{digits}f}'


def main() -> None:
    """
    機能: 本日取得の入力特徴・元条件・実方向とLCの全q0ファネルを診断する。
    引数: なし。
    返り値: None。固定Source・入力・180正本は変更しない。新候補を評価しない。
    """
    HERE.mkdir(parents=True, exist_ok=True)
    input_source = R.module(ROOT / 'work/180本日デイ適用/入力180.py', 'input180_diagnosis')
    loaded = input_source.load_context()
    features = loaded['features']
    frozen = R.module(ROOT / 'work/174追加七場適用/固定政策を適用する.py', 'old174_pure180')
    pure = R.module(ROOT / 'work/179量と構造の純入口/rules179.py', 'rules179_diagnosis180')
    static = R.module(ROOT / 'work/162複合入口候補/rules162.py', 'static162_diagnosis180')
    inherited, _ = R.policies()
    evaluator = pure.Evaluator179(features, [s['start'] for s in features.scenes])
    catalog = {r['id']: r for r in static.candidate_catalog()}
    raw_evaluators = {rule: static.PreparedEvaluator(features.buy_X, features.sell_X,
        list(features.columns), width) for rule, width in [('MP0057', 150), ('BO0065', 350)]}
    raw = {rule: ev.evaluate_one(catalog[rule]) for rule, ev in raw_evaluators.items()}
    directions = frozen.build_directions(features, [inherited])
    fixed = json.loads(gzip.decompress(RESULT.read_bytes()))
    row = next(r for r in fixed['rows'] if r['id'] == '全期_J035')
    assert len(row['selection']['events']) == 7
    source_paths = [ADAPTER, RESULT, ROOT / 'work/180本日デイ適用/入力180.py',
        ROOT / 'work/179量と構造の純入口/rules179.py',
        ROOT / 'work/162複合入口候補/rules162.py',
        ROOT / 'inputs/00180_20261116デイの固定適用入力/入口母集団/当時特徴.json.gz']
    before = [R.ref(p) for p in source_paths]

    # ----------------------------------------
    names = [f'm{m}_{field}' for m in (5, 15, 30) for field in
        ('ema21_delta_to_side', 'di_difference_to_side', 'hist_to_side',
         'hist_delta_to_side', 'rsi_center_to_side', 'rsi_delta_to_side', 'adx', 'adx_delta')]
    names += ['ema_up_count', 'di_up_count', 'long_up_votes', 'short_up_votes',
        'm5_gap_to_side', 'm5_hist_atr_to_side', 'm5_body_ratio_to_side',
        'm1_volume_relative_prior3', 'q0_last_minus_prior3_forward_edge_atr5_to_side',
        'q0_entry_minus_ema8_atr5_to_side', 'q0_spread_points', 'p175_local_allowed']
    trades = []
    for order, (event, actual_side, width, net) in enumerate(zip(row['selection']['events'],
        row['selection']['sides'], row['ledger']['width'], row['ledger']['net'], strict=True), 1):
        actual_direction = 1 if actual_side == 0 else -1
        active = sorted([rule for rule in inherited['options']['DAY']
            if directions[rule['birth_key']][event] != 0], key=lambda r: r['id'])
        assert active and len({int(directions[r['birth_key']][event]) for r in active}) == 1
        selected = active[0]
        assert int(directions[selected['birth_key']][event]) == actual_direction
        assert selected['width'] == width
        original_direction = int(raw[selected['rule']]['directions'][event])
        assert original_direction == (actual_direction if selected['orientation'] == 'NORMAL' else -actual_direction)
        source_side = 0 if original_direction == 1 else 1
        checks = clauses(raw_evaluators[selected['rule']], catalog[selected['rule']], source_side, event)
        assert all(c['known'] and c['passed'] for c in checks)
        trades.append({'番号': order, 'event': event, 'q0': features.q0_meta[event],
            'q0JST': stamp(features.q0_meta[event]['q0_time']),
            '取得JST': stamp(row['ledger']['entry_time'][order-1]),
            '取得価格': row['ledger']['entry_price'][order-1], '費用後損益': net,
            '採用固定規則': selected, '同時成立規則': [r['id'] for r in active],
            '元方向': '買い' if original_direction == 1 else '売り',
            '実方向': '買い' if actual_side == 0 else '売り',
            '元条件全成立': checks,
            '実方向特徴': values(evaluator, actual_side, event, names),
            '元方向特徴': values(evaluator, source_side, event, names),
            '上向き基準の特徴': values(evaluator, 0, event, names)})

    # ----------------------------------------
    lc = next(r for r in pure.candidate_catalog() if r['id'] == 'VLC0003_EDGE')
    allowed = evaluator._local_allowed175.astype(bool)
    first_published = np.flatnonzero(~allowed)
    per_condition = []
    lc_sides = []
    for side in (0, 1):
        joint = allowed.copy()
        detail = []
        for item in lc['conditions']:
            truth, known = evaluator.comparison(side, item)
            joint &= truth
            detail.append({**item, '局所許可14行の既知': int((known & allowed).sum()),
                '局所許可14行の成立': int((truth & allowed).sum()),
                '局所許可14行の未知': int((~known & allowed).sum()),
                '全353行の成立': int(truth.sum())})
        per_condition.append({'側': '買い' if side == 0 else '売り', '条件別': detail})
        lc_sides.append({'側': side, '許可中の全AND成立': int(joint.sum())})
    lc_result = evaluator.evaluate_one(lc)
    allowed_rows = []
    lc_names = ['m5_ema21_delta_to_side', 'm5_di_difference_to_side', 'm5_gap_to_side',
        'm5_hist_delta_to_side', 'm5_rsi_delta_to_side', 'm5_hist_delta_atr_to_side',
        'short_up_votes', 'p179_momentum', 'm5_rsi_center_to_side', 'p179_structure|LC|0|2',
        'm1_tr_atr5_ratio', 'm5_tr_previous_atr_ratio', 'q0_entry_minus_ema8_atr5_to_side']
    for event in np.flatnonzero(allowed):
        allowed_rows.append({'event': int(event), 'q0JST': stamp(features.q0_meta[event]['q0_time']),
            '買い': values(evaluator, 0, event, lc_names), '売り': values(evaluator, 1, event, lc_names)})
    diag_lc = {'全q0': len(features.q0_meta), '未公表ever許可q0': int(allowed.sum()),
        '未公表ever許可開始JST': stamp(features.q0_meta[int(np.flatnonzero(allowed)[0])]['q0_time']) if allowed.any() else None,
        '未公表ever許可末尾JST': stamp(features.q0_meta[int(np.flatnonzero(allowed)[-1])]['q0_time']) if allowed.any() else None,
        '初回15分Hist増分公表q0JST': stamp(features.q0_meta[int(first_published[0])]['q0_time']) if len(first_published) else None,
        '初回公表Hist増分買い基準': safe(evaluator.factor(0, 'm15_hist_delta_to_side')[0][int(first_published[0])]) if len(first_published) else None,
        '公表済みで禁止q0': int((~allowed).sum()), '純LC成立q0': int(np.count_nonzero(lc_result['directions'])),
        '局所許可中の全AND': lc_sides, '許可中の条件別': per_condition, '許可14行の当時値': allowed_rows,
        '取得7件の局所許可': [r['実方向特徴']['p175_local_allowed'] for r in trades]}
    assert [R.ref(p) for p in source_paths] == before
    result = {'成功': True, '対象': '固定180・2026-11-16_Dayの取得7件',
        '固定Source不変': True, '閾値変更と新政策探索': False, '入力とSource': before,
        '診断Source': R.ref(Path(__file__)), '取引': trades, 'LC全q0診断': diag_lc,
        '注意': ['当時特徴による条件の説明と、価格経路からみた結果因果の証明を区別する。',
            'BOの反転後に背景・動力を追加確認する条件は今回の固定政策にはない。',
            'ADXは強さであり、向きはEMA/DI等と分けて読む。相対量は観測累積差分量由来。',
            'この1日の事後診断を新しい条件の有効性証明としない。']}
    target = HERE / '入口診断.json'
    target.write_text(json.dumps(safe(result), ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    write_summary(result)
    print(json.dumps({'成功': True, '取引': 7, 'LC': {k: v for k, v in diag_lc.items()
        if k not in ('許可中の条件別', '許可14行の当時値')}, '出力': R.ref(target)}, ensure_ascii=False), flush=True)


def write_summary(result: dict) -> None:
    """
    機能: 7件を実方向の背景と元条件に分けた短いMarkdownへ写す。
    引数: result(dict)は固定条件の診断。
    返り値: None。数値はJSONを正本とし、小数丸めは表示だけ。
    """
    lines = ['# 11月16日デイ・固定入口の診断', '',
        '閾値・政策は変更せず、固定180の7取得を当時q0の特徴へ戻して確認した。数値正本は[入口診断.json](入口診断.json)。正の方向値は実際に建てた向きに整合、負は反対を表す。', '',
        '## ここで確認した問題', '',
        '旧BOの5件は、価格端突破と動力改善が揃った元方向を反転している。そのため5件すべて、実際の取得方向に対する5分Hist増分・RSI増分は負だった。9:45・11:31・14:38の買いは5/15/30分EMA傾きが全て下向きで、後2件はDIも全て売り向きだった。元方向の失速や買い向きの構造回復は必須条件にない。BOの5件は利益14,923円、損失76,308円、差引−61,385円。', '',
        'ただし全件が同じ問題ではない。9:11の買いは公表済み5/15分EMA・DIが買い向きだったが、足元の5分Hist・RSIは低下していた。MPの12:51・14:16売りは全3足EMA・DIが売り向き、MACD・RSI増分も売り向きだったが、ともに−150ptへ先着した。背景の整合だけでこの2件まで防げるとは言えない。売りが新しく加速したのか、下落終盤で反転しやすかったのかは、別の原板経路診断と合わせて判断する。', '',
        '## 実際の入口と背景', '',
        '|番号・取得|規則：元→実方向|損益|EMA21傾き5/15/30分（実方向pt）|DI差5/15/30分（実方向）|長期方向票|',
        '|---|---|---:|---|---|---|']
    for r in result['取引']:
        f = r['実方向特徴']
        ema = ' / '.join(fmt(f[f'm{m}_ema21_delta_to_side']) for m in (5, 15, 30))
        di = ' / '.join(fmt(f[f'm{m}_di_difference_to_side']) for m in (5, 15, 30))
        lines.append(f"|{r['番号']}・{r['取得JST'][11:]}|{r['採用固定規則']['rule']}：{r['元方向']}→{r['実方向']}|{r['費用後損益']:,.0f}円|{ema}|{di}|{fmt(f['long_up_votes'],0)}/4|")
    lines += ['', '## 動力・強さ・観測量', '',
        '|番号|5分Hist／増分（実方向）|15分Hist／増分（実方向）|RSI5の実値／実方向増分|15分ADX／増分|1分相対量|',
        '|---|---|---|---|---|---|']
    for r in result['取引']:
        f = r['実方向特徴']; buy = r['上向き基準の特徴']
        rsi = None if buy['m5_rsi_center_to_side'] is None else 50 + buy['m5_rsi_center_to_side']
        lines.append(f"|{r['番号']}|{fmt(f['m5_hist_to_side'])} / {fmt(f['m5_hist_delta_to_side'])}|{fmt(f['m15_hist_to_side'])} / {fmt(f['m15_hist_delta_to_side'])}|{fmt(rsi,2)} / {fmt(f['m5_rsi_delta_to_side'])}|{fmt(f['m15_adx'],2)} / {fmt(f['m15_adx_delta'])}|{fmt(f['m1_volume_relative_prior3'],2)}|")
    lines += ['', '## BOの反転前に成立したもの', '',
        'BO0065は価格端突破・実体・MACD/RSI増分・量が揃った**元方向をそのまま反転**する固定政策である。反転後の実方向に、複数足の回復・失速・構造回復を追加確認していない。', '',
        '|番号|元方向|直前3分端超え/ATR5（>0.25）|5分実体比（≥0.4）|5分Hist増分（>0）|5分RSI増分（>0）|RSI中心（≤15）|相対量（≥1）|',
        '|---|---|---:|---:|---:|---:|---:|---:|']
    for r in result['取引']:
        if r['採用固定規則']['rule'] != 'BO0065':
            continue
        f = r['元方向特徴']
        lines.append(f"|{r['番号']}|{r['元方向']}|{fmt(f['q0_last_minus_prior3_forward_edge_atr5_to_side'])}|{fmt(f['m5_body_ratio_to_side'])}|{fmt(f['m5_hist_delta_to_side'])}|{fmt(f['m5_rsi_delta_to_side'])}|{fmt(f['m5_rsi_center_to_side'])}|{fmt(f['m1_volume_relative_prior3'],2)}|")
    lc = result['LC全q0診断']
    lines += ['', '## LCが入らなかった範囲', '',
        f"LCの未公表ever許可は353q0中{lc['未公表ever許可q0']}q0、{lc['未公表ever許可開始JST']}～{lc['未公表ever許可末尾JST']}だった。15分Hist増分が{lc['初回15分Hist増分公表q0JST']}に初公表（買い基準{fmt(lc['初回公表Hist増分買い基準'])}）となり、その後{lc['公表済みで禁止q0']}q0は固定ゲートで禁止。取得7件は全て局所許可0。許可時間中も全AND成立は買い0・売り0で、純LC方向0だった。", '',
        '許可14行のうち短期指標が既知の10行では、買いはEMA8からの取得距離が1.668～3.859ATR5で、上限1.5を全10行で超過。売りは短期方向票が全10行で0/3、RSI中心が−33.10～−24.44で下限−10を全10行で下回った。前4行は5分指標等が未知。したがってLCは単に旧幹の優先順位で押し出されたのではなく、純入口自体が0だった。', '',
        '|LC条件|買い：許可14行の既知／成立|売り：許可14行の既知／成立|',
        '|---|---|---|']
    a, b = lc['許可中の条件別']
    for ac, bc in zip(a['条件別'], b['条件別'], strict=True):
        if ac['局所許可14行の成立'] < 14 or bc['局所許可14行の成立'] < 14:
            factor = ac['factor'].replace('|', '\\|')
            title = f"{factor} {ac['operator']} {ac['threshold']}"
            lines.append(f"|{title}|{ac['局所許可14行の既知']} / {ac['局所許可14行の成立']}|{bc['局所許可14行の既知']} / {bc['局所許可14行の成立']}|")
    lines += ['', 'EMA/DIや動力は診断用に取り出したものを含む。旧BO条件は背景EMA/DI・ADXを必須にしないため、ここで背景が逆だったことをもって計算バグとはしない。固定手法がその情報を実方向の確認に使っていない点が、研究上の不足である。', '',
        '1日だけで新しいフィルターの有効性を断定せず、当時条件の構造と損益を分けて記録する。実際の順行幅・逆行幅・利益の返却は別の原板経路診断で確認する。']
    (HERE / '入口診断.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')


if __name__ == '__main__':
    main()
