"""固定180の実保有内だけで、入口逆行と利益後赤字を分ける診断。"""
from pathlib import Path
import gzip
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'work/20261116_DAYの独立監査'))
from 全取引を手計算する import raw_records, fingerprint, jst, RAW

POINT_YEN = 100
FEE = 77
SLIPPAGE = 1000
COST = FEE + SLIPPAGE

# ----------------------------------------


def observation(row, points: float) -> dict:
    """
    機能: 正常な決済可能側BBOを、値幅・費用後評価額・原行・日時として保持する。
    引数: row(np.void)は原板一行、points(float)は方向を合わせた取得価格との差。
    返り値: dictはmini1枚の評価値。即時に同価格で注文成立する保証ではない。
    """
    return {
        '費用前pt': float(points),
        '費用後円': float(points * POINT_YEN - COST),
        'JST': jst(float(row['time'])),
        '原行': int(row['source_line']),
        'Bid': float(row['bid']),
        'Ask': float(row['ask']),
    }


def first_hit(prior: dict | None, row, points: float, width: float) -> dict | None:
    """
    機能: 実保有内で対称幅の順行側または逆行側へ初めて達した行を保存する。
    引数: prior(dict|None)は既到達、row(np.void)、points/width(float)は値幅。
    返り値: dict|Noneは最初の到達。保有内未到達はNoneで、後の経路を参照しない。
    """
    if prior is not None:
        return prior
    if points >= width or points <= -width:
        return {'先着': '順行' if points >= width else '逆行', **observation(row, points)}
    return None


def diagnose(records, ledger: dict, number: int) -> dict:
    """
    機能: 一建玉の保有中正常BBOを逐次走査し、利益化と損益減少を分ける。
    引数: records(np.ndarray)は原板復元全行、ledger(dict)は固定台帳、number(int)は0起算。
    返り値: dictはMFE/MAE・利益後赤字・固定幅と診断用125ptの最初到達。
    """
    assert ledger['known'][number]
    entry = int(ledger['entry_index'][number])
    last = int(ledger['exit_index'][number])
    side = int(ledger['side'][number])
    price = float(ledger['entry_price'][number])
    width = float(ledger['width'][number])
    final_net = float(ledger['net'][number])
    assert int(records[entry]['source_line']) == ledger['entry_line'][number]
    assert int(records[last]['source_line']) == ledger['exit_line'][number]
    high = low = first_gross = first_net = fixed_hit = reference_hit = None
    observations = 0
    for row in records[entry:last + 1]:
        if not row['normal']:
            continue
        mark = float(row['bid'] if side == 0 else row['ask'])
        points = (1 if side == 0 else -1) * (mark - price)
        current = observation(row, points)
        observations += 1
        if high is None or points > high['費用前pt']:
            high = current
        if low is None or points < low['費用前pt']:
            low = current
        if first_gross is None and points > 0:
            first_gross = current
        if first_net is None and current['費用後円'] > 0:
            first_net = current
        fixed_hit = first_hit(fixed_hit, row, points, width)
        reference_hit = first_hit(reference_hit, row, points, 125)
    assert observations and high is not None and low is not None
    exit_row = records[last]
    exit_mark = float(exit_row['bid'] if side == 0 else exit_row['ask'])
    realized_points = (1 if side == 0 else -1) * (exit_mark - price)
    assert realized_points * POINT_YEN - COST == final_net
    expected_label = 0 if fixed_hit is None else 1 if fixed_hit['先着'] == '順行' else -1
    assert expected_label == ledger['label'][number]
    positive = high['費用後円'] > 0
    category = '利益後赤字' if positive and final_net < 0 else '利益後黒字' if positive else '利益化なし'
    return {
        '番号': number + 1,
        'case_id': ledger['case_id'][number],
        '方向': '買い' if side == 0 else '売り',
        '取得JST': jst(float(ledger['entry_time'][number])),
        '取得原行': int(ledger['entry_line'][number]),
        '取得価格': price,
        '決済JST': jst(float(ledger['exit_time'][number])),
        '決済原行': int(ledger['exit_line'][number]),
        '決済価格': exit_mark,
        '決済損益pt': realized_points,
        '決済損益円': final_net,
        '決済理由': {1: '利確幅先着', 2: '損切幅先着', 3: '通常期限', 4: '終了前予定決済'}[ledger['status'][number]],
        'MFE': high,
        'MAE': low,
        '最初の費用前プラス': first_gross,
        '最初の費用後プラス': first_net,
        '利益化あり': positive,
        '分類': category,
        '失った最大利益円': high['費用後円'] - final_net if positive else None,
        '最高評価から決済までの減少円': high['費用後円'] - final_net,
        '固定IFD幅pt': width,
        '固定IFD幅の最初到達': fixed_hit,
        '診断125ptの最初到達': reference_hit,
        '実保有内正常BBO行数': observations,
    }

# ----------------------------------------


def totals(rows: list[dict]) -> dict:
    """
    機能: 実現損益・利益後赤字・利益化しない損失を重複なしで集計する。
    引数: rows(list[dict])は固有七建玉の診断。
    返り値: dictは分類別金額寄与。最高益の合計を実現可能な出口成績と扱わない。
    """
    profits = sum(max(0, row['決済損益円']) for row in rows)
    losses = -sum(min(0, row['決済損益円']) for row in rows)
    groups = {}
    for category in ['利益化なし', '利益後赤字', '利益後黒字']:
        selected = [row for row in rows if row['分類'] == category]
        negative = -sum(min(0, row['決済損益円']) for row in selected)
        groups[category] = {
            '取引番号': [row['番号'] for row in selected],
            '件数': len(selected),
            '利益円': sum(max(0, row['決済損益円']) for row in selected),
            '損失円': negative,
            '収支円': sum(row['決済損益円'] for row in selected),
            '全損失への割合': negative / losses if losses else None,
            '費用後最高益の合計円': sum(max(0, row['MFE']['費用後円']) for row in selected),
            '利益化後の最高益から決済への減少合計円': sum(row['失った最大利益円'] or 0 for row in selected),
        }
    first = {}
    for field in ['固定IFD幅の最初到達', '診断125ptの最初到達']:
        counts = {label: sum((row[field]['先着'] if row[field] else '保有内未到達') == label for row in rows)
                  for label in ['順行', '逆行', '保有内未到達']}
        arrived = counts['順行'] + counts['逆行']
        first[field] = {**counts, '到達済み順行率': counts['順行'] / arrived if arrived else None}
    sides = {}
    for side in ['買い', '売り']:
        selected = [row for row in rows if row['方向'] == side]
        sides[side] = {'件数': len(selected),
            '利益円': sum(max(0, row['決済損益円']) for row in selected),
            '損失円': -sum(min(0, row['決済損益円']) for row in selected),
            '収支円': sum(row['決済損益円'] for row in selected)}
    assert sum(row['件数'] for row in groups.values()) == len(rows)
    assert sum(row['収支円'] for row in groups.values()) == profits - losses
    return {'固有取引数': len(rows), '利益円': profits, '損失円': losses, '収支円': profits - losses,
            '往復手数料合計円': FEE * len(rows), '往復追加滑り合計円': SLIPPAGE * len(rows),
            '分類別': groups, '売買別': sides, '同幅先着': first,
            '利益化した件の最高益から決済への減少合計円': sum(row['失った最大利益円'] or 0 for row in rows)}

# ----------------------------------------


def main() -> None:
    """
    機能: 固定二政策を七固有取引として原板から診断し、担当workだけへ保存する。
    引数: なし。確定入口・出口・費用・Sourceの変更も、新しい出口の探索も行わない。
    返り値: None。出口診断.jsonを保存する。
    """
    result_path = ROOT / 'work/180本日デイ適用/本日の固定結果.json.gz'
    prior_path = ROOT / 'work/20261116_DAYの独立監査/全七取引とCSVの独立結果.json'
    sources = [RAW, result_path, prior_path, Path(__file__),
               ROOT / 'work/20261116_DAYの独立監査/全取引を手計算する.py']
    before = [fingerprint(path) for path in sources]
    assert before[0]['sha256'] == 'a8cb764a0667285461109b2d8c128e0e7d2e13af5e5bc642e634bb6c12b4d27d'
    assert before[1]['sha256'] == '0929f3a1e99c5a5a1c2871127739ba2abe137a82aba81358f55abd67544e77ba'
    data = json.loads(gzip.decompress(result_path.read_bytes()))
    prior = json.loads(prior_path.read_text(encoding='utf-8'))
    assert {row['id'] for row in data['rows']} == {'全期_J035', '旧178_新時計'}
    assert data['rows'][0]['ledger'] == data['rows'][1]['ledger']
    ledger = next(row['ledger'] for row in data['rows'] if row['id'] == '全期_J035')
    assert len(ledger['net']) == 7 and len(set(ledger['case_id'])) == 7
    records = raw_records()
    rows = [diagnose(records, ledger, number) for number in range(7)]
    previous = prior['政策']['全期_J035']['取引']
    for row, old in zip(rows, previous):
        assert row['番号'] == old['番号'] and row['決済損益円'] == old['手計算純損益']
        for label in ['MFE', 'MAE']:
            for key, suffix in [('費用前pt', '_pt'), ('費用後円', '_費用後円'), ('JST', '_JST'), ('原行', '_原行')]:
                assert row[label][key] == old['保有中'][label + suffix]
    summary = totals(rows)
    assert summary['利益円'] == 14923 and summary['損失円'] == 108462 and summary['収支円'] == -93539
    assert before == [fingerprint(path) for path in sources]
    proof = {'成功': True, '探索なし': True, '元入力不変': True, '入力': before,
             '二政策同台帳で重複を除外': True, '原板復元行数': len(records),
             '集計': summary, '取引': rows,
             '定義': [
                 '実際の取得原行から決済原行までを両端込みで走査し、Bid<Askの正常BBOだけを使う。',
                 '買い保有はBid、売り保有はAskで評価する。価格差×100円から往復手数料77円と追加滑り1,000円を控除する。',
                 'MFE/MAEは決済可能側評価の最大/最小で、MFE自体が負の場合も0へ切り上げない。',
                 '失った最大利益は費用後最高益が正の件だけの最高益−決済損益。最高評価からの減少とは区別する。',
                 '同値のMFE/MAEや到達は最初の原行を採り、同秒内の原行順も保持する。',
                 '固定IFD幅と診断125ptの先着は実保有内だけ。決済後の仮想経路や保有期限変更を評価しない。',
                 '各最高益で同時に決済できるとはしていない。最高益や減少額の合計は新出口の利益や損失改善額ではない。',
                 '当日の七件だけから将来の入口優位や最適な幅は推定しない。過去最悪の順位は本診断の対象外。',
             ]}
    (HERE / '出口診断.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '集計': summary}, ensure_ascii=False))


if __name__ == '__main__':
    main()
