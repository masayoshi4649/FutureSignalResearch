"""90〜100の固定文書と完成集約だけを、条件差を残して比較する。"""

from collections import defaultdict
from decimal import Decimal
import hashlib
import importlib.util
import json
from pathlib import Path
import sys


ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
CONC_PATH=ROOT/'work/101実現利益の集中/集中を確認する.py'
CONC_SHA='5494518595c62e02c8567eeaeb2745d891c2ab8657bab1df7f9b1f8494414671'
SENSES=((0,0),(0,1),(5,0),(5,1))
FAMILIES=(
 ('94-S0',94,'S0_', '連続・元Source出口S0','元三手法43のみ。外側gateなし','N',[(93,'D0の元連続基準は94の固定対照。D1は93未運転')]),
 ('94-P0',94,'P0_', '連続・正益後P0','元三手法43のみ。外側gateなし','N',[(95,'N/P0')]),
 ('94-P1',94,'P1_', '連続・残玉費用床P1','元三手法43のみ。外側gateなし','N',[]),
 ('95-B5',95,'B5_P0_', '5分・P0','追加技法なし。取得済Sourceを出生一回の枠で選ぶ','B5',[]),
 ('95-B5Q',95,'B5Q_P0_', '5分quiet・P0','追加技法なし。B5＋開始30分見送り','B5Q',[(96,'G0/P0'),(97,'G0/P0')]),
 ('96-A',96,'A_B5Q_P0_', '5分quiet・A/P0','A:3/15分EMA、MACD増分、Close位置/進行、取得ATR距離、RSI×TR警戒、現在量','B5Q',[(96,'AB/P0。集約/日別の観測同値、独立例を追加しない'),(97,'AB/P0')]),
 ('96-B',96,'B_B5Q_P0_', '5分quiet・B/P0','B:逆15分背景と3足の固定EMA線奪還/保持、Close/RSI後足確認、共通現在量等','B5Q',[]),
 ('97-G0-H0',97,'H0_B5Q_P0_', '5分quiet・G0/H0','追加技法なし。初strict u>0で未予約全残返済要求','B5Q',[(98,'G0/空Risk/H0'),(99,'G0/H0')]),
 ('97-AB-H0',97,'H0_AB_B5Q_P0_', '5分quiet・AB/H0','AまたはBの三値OR。利益後H0','B5Q',[(98,'AB/空Risk/H0')]),
 ('98-G0-R05',98,'R05_H0_B5Q_P0_', '5分quiet・G0/R05/H0','追加入口技法なし。利益前0.5ATR非緩和、幅20..125、未知125固定','B5Q',[]),
 ('98-AB-R05',98,'R05_H0_AB_B5Q_P0_', '5分quiet・AB/R05/H0','AB入口。利益前0.5ATR、利益後H0','B5Q',[]),
 ('98-G0-R10',98,'R10_H0_B5Q_P0_', '5分quiet・G0/R10/H0','追加入口技法なし。利益前1ATR非緩和、幅20..125、未知125固定','B5Q',[]),
 ('98-AB-R10',98,'R10_H0_AB_B5Q_P0_', '5分quiet・AB/R10/H0','AB入口。利益前1ATR、利益後H0','B5Q',[]),
 ('99-E3S-H0',99,'H0_E3S_B5Q_P0_', '5分quiet・E3(S)/H0','E3:現在時計/確定3・15/EMA背景/MACD増分/現在量/3・15分EMAの8check。E3SはRSI×TR警戒追加','B5Q',[(99,'E3/H0。観測同値で普遍同値ではない'),(100,'E3S/H0')]),
 ('100-E3S-P0',100,'E3S_B5Q_P0_', '5分quiet・E3S/P0','E3S入口、正益後もP0追尾継続。初正益即全残返済なし','B5Q',[]),
 ('100-E3S-HG',100,'HG_E3S_B5Q_P0_', '5分quiet・E3S/HG','E3S入口、費用前g>0/u<=0後は名目床0、u>0後H0へ不可逆','B5Q',[]),
)


def need(ok,label):
    """
    機能: 元集約と日別の不一致を拒否する。
    引数: ok(bool)、label(str)は条件と識別。
    返り値: None。不成立時はValueError。
    """
    if not ok:raise ValueError(label)


def sha(path):
    """
    機能: 明示した文書/集約だけの指紋を得る。
    引数: path(Path)は今回許可したファイル。
    返り値: strはSHA256。Native/Raw/Tapeを探索しない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_module():
    """
    機能: 固定済み開始日集中の純関数だけをimportする。
    引数: なし。
    返り値: moduleは549451版。市場を読むmainは呼ばない。
    """
    need(sha(CONC_PATH)==CONC_SHA,'集中純関数の固定SHA差')
    spec=importlib.util.spec_from_file_location('固定開始日集中5494',CONC_PATH)
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
    return module


CONC=load_module()


def start_days(value,key):
    """
    機能: 保存日別又は保存場別集約の純額だけを開始日へ合算する。
    引数: value(dict)、key(str)は完成結果と対象Actor。
    返り値: tuple[list, str]は27日分の実純額と使用欄。個別取引へ降りない。
    """
    if '日別' in value:
        rows=[r for r in value['日別'] if r['key']==key]
        need(len(rows)==27 and len({r['日'] for r in rows})==27 and all(r['場数']==2 for r in rows),'保存日別の27開始日')
        return [(r['日'],CONC.amount(r['totals']['net_yen'])) for r in rows],'保存日別27行'
    rows=[r for r in value['場別'] if r['key']==key]
    need(len(rows)==54 and len({r['session'] for r in rows})==54,'保存場別の54場')
    daily=defaultdict(Decimal);kinds=defaultdict(set)
    for row in rows:
        day,kind=row['session'].split('_')
        need(kind in ('Day','Night') and kind not in kinds[day],'同開始日の場重複')
        kinds[day].add(kind);daily[day]+=CONC.amount(row['totals']['net_yen'])
    need(len(daily)==27 and all(s=={'Day','Night'} for s in kinds.values()),'開始日ごとのDay/Night完全2場')
    return sorted(daily.items()),'既存場別のsession/key/totals.net_yenだけを開始日合算'


def compact_concentration(value):
    """
    機能: 集中純関数の結果を必要な記述統計だけへ縮める。
    引数: value(dict)は計算済み集中。
    返り値: dictはmin/max・正負ゼロ・寄与。日別全文の重複は保存しない。
    """
    names=('開始日数','実収支円','黒字開始日','赤字開始日','ゼロ開始日','最良開始日','最良日実収支円',
           '最良開始日を1つ除いた実収支円','各開始日を1つ除いた実収支min円','各開始日を1つ除いた実収支max円',
           '最良日の寄与_総純額分母','最良日の寄与_黒字日の正額合計分母')
    return {name:value[name] for name in names}


def case(value,key):
    """
    機能: 完成集約から一感度の取得/正益後赤字/純額と日別集中を取る。
    引数: value(dict)、key(str)は保存結果と実名Actor。
    返り値: dictは集約値。利益後赤字額が旧schemaに無ければnullとする。
    """
    total=value['集計'][key]
    days,method=start_days(value,key)
    concentration=CONC.concentration(days)
    need(CONC.amount(total['net_yen'])==CONC.amount(concentration['実収支円']),'日別/総純額差:'+key)
    need(CONC.amount(total['gross_yen'])-CONC.amount(total['fee_yen'])-CONC.amount(total['slip_yen'])==CONC.amount(total['net_yen']),'粗額と費用の整合:'+key)
    diagnostic=value.get('実現診断',{}).get(key,{})
    return {'key':key,'純額円':CONC.number(CONC.amount(total['net_yen'])),'実取得玉':total['positions'],
            '新規実枚':total['entry_quantity'],'u正益玉':total['unit_positive_positions'],
            'u正益後最終赤字玉':total['unit_positive_closed_negative'],
            'u正益後最終赤字額円':diagnostic.get('u正益後最終赤字額円'),
            'W正益玉':total['whole_positive_positions'],'W正益後最終赤字玉':total['whole_positive_closed_negative'],
            'W正益後最終赤字額円':diagnostic.get('W正益後最終赤字額円'),
            '日別の作り方':method,'集中':compact_concentration(concentration)}


def signature(value):
    """
    機能: 表で重複をまとめる対象の集約/日別署名を得る。
    引数: value(dict)は完成した一Actor。
    返り値: tupleは経済集約の一致確認用。実入口全field一致の代用にはしない。
    """
    fields=('純額円','実取得玉','新規実枚','u正益玉','u正益後最終赤字玉','W正益玉','W正益後最終赤字玉')
    return tuple(value[name] for name in fields),json.dumps(value['集中'],sort_keys=True,ensure_ascii=False)


def render(result):
    """
    機能: 条件群を順位付けせず小さな比較表へ整形する。
    引数: result(dict)は全11試行の出典と16系列。
    返り値: strは実現集約の比較と限界。
    """
    lines=['# 90〜100の直近手法を条件差ごとに比べる','',
      '確認日：2026-11-09。正式README・設定・完成結果JSONの集約だけを参照した。原板、Tape、Native、Source本文、新101途中出力は読まず、再金融はしていない。採用候補の順位や新しい合格条件は作らない。','',
      '比較の共通部分はmini・100円/pt・買売各側10枚・片道手数料38.5円、2026-09-21〜10-27の既使用54場。C0は指定手数料のみ、C5は追加5pt/片道の動的別運転、D0は後続正常行、D1は追加1価格秒。C5をC0から一定額だけ引いた値にはしない。ラージ板によるmini代理約定で、実mini流動性・真受信順・未知期間の安定利益は未証明。','',
      '## 直接同列にしない前段','',
      '|試行|複合条件と範囲|保存されている観測|同列比較できない理由|','|---|---|---|---|',
      '|90|旧E1/G1＋押戻し確定終値の逆側固定床|D0 −177,394→−176,894円、D1 −187,494→−186,594円|micro代理・66場・15分、往復122円/枚。下のmini P0とは同じ名前でも別規範|',
      '|91|旧E1/G1＋利確完了後の別event再参加|R1はD0 −182,276円、D1 −185,446円|90と同じmicro66場。再参加回数/同参照の複数世代も異なる|',
      '|92|現在E0＋独立i/p・H奪還→保持→v再開|H1は3玉49枚、D0 −20,378円、D1 −20,978円|micro66場・15分。少数化と損失減をmini収益改善へ換算しない|',
      '|93|元三手法の連続新規・元退出|mini359玉755枚、手数料のみ+2,839,865円、仮定5pt込み+2,084,865円|同mini54場だがD1/新全玉P0追尾なし。元micro gross不一致・暫定を維持。D0基礎は94S0固定対照へ接続|','',
      '## mini群の時計・複合条件・保護','',
      '94は連続出生で新規。95はN（連続）/B5（出生後の一回だけ5分枠）/B5Q（B5＋各開始30分見送り）を比較する。96以降の表はB5Q。Sourceの元43設定を共通土台とし、EMA/ATR/価格帯/短秒進行/二市場・板支持等の全内式をこのメモで再実装しない。','',
      'P0はstrict残玉費用後u>0で最低名目建値＋取得時固定2ATRの非緩和追尾。94P1は同じ2ATRに残玉単価の費用床を加える。H0は初u>0でSource後の未予約全残に返済を要求する。R05/R10は利益前の別ATR追尾で、利益後はH0。HGは利益前の粗順行後に名目床0、u>0以降H0へ移る。要求と実fill・費用後黒字は同義ではない。','',
      '|系列|複合条件の要点|','|---|---|']
    for family in result['系列']:
        lines.append('|'+family['ID']+' '+family['名称']+'|'+family['複合条件']+'|')
    lines += ['', 'AはEMA背景・MACD増分・Close/EMAと前Close進行・取得ATR距離・同時RSI/TR警戒・当時量を組み合わせる。Bは逆背景下の3足奪還/保持確認を加え、ABはA/Bの三値OR。E3は当時計/確定3・15分/EMA背景/MACD増分/現在量/3・15分EMAの8check、E3Sは同時急変警戒も加える。E3/Sでは旧AのClose位置/進行と取得ATR距離を採否から外す。現在量はDay OFI30、Night E08で別定義。個別指標の単独効果とはしない。','',
      '## 4感度の実現純額','',
      '|系列|C0/D0円|C0/D1円|C5/D0円|C5/D1円|','|---|---:|---:|---:|---:|']
    for family in result['系列']:
        lines.append('|'+family['ID']+'|'+ '|'.join(f"{row['純額円']:,}" for row in family['4感度'])+'|')
    lines += ['', '## 取得と利益後赤字・開始日集中','',
      '次表の配列はC0D0／C0D1／C5D0／C5D1の順。4感度が同じ値の場合だけ「4同」と省略した。u後赤字は分子が最終赤字玉、分母が当該運転でu正益を観測した玉。0/0は未観測であり0%成功ではない。分母が縮んだ結果を損失削減の証拠にしない。日別集中の表は主C0D0、4感度の全値とW分類・金額の記録有無はJSONへ残した。','',
      '|系列|実取得玉/枚・4順|u後赤字/u正益・4順|主C0D0最良日除外円|主C0D0最良日純額/全純額|','|---|---|---|---:|---:|']
    for family in result['系列']:
        cases=family['4感度']
        quantities=[str(r['実取得玉'])+'/'+str(r['新規実枚']) for r in cases]
        flags=[str(r['u正益後最終赤字玉'])+'/'+str(r['u正益玉']) for r in cases]
        quantity=quantities[0]+'（4同）' if len(set(quantities))==1 else '／'.join(quantities)
        flag=flags[0]+'（4同）' if len(set(flags))==1 else '／'.join(flags)
        row=cases[0]['集中'];part=row['最良日の寄与_総純額分母']
        ratio='未定義' if part['比率'] is None else format(Decimal(part['比率'])*100,'.2f')+'%'
        lines.append('|'+family['ID']+'|'+quantity+'|'+flag+'|'+str(row['最良開始日を1つ除いた実収支円'])+'|'+ratio+'|')
    lines += ['', '開始日はDay/Nightを同じ日付で合算した27日。94〜99は完成結果の場別session/key/totals.net_yenだけを開始日へ再集計、100は保存日別を使用し、全て総純額へ一致を検算した。最良日除外=総純額−最大日純額、1日ずつ除外min/maxも実集約の算術であり、約定の反事実再運転ではない。寄与の分母は全純額のため負額や100%超になり得る。総純額が赤字の比率は利益集中の強弱へ使わず、除外額と実赤字を読む。ゼロ収支/取引0では比率未定義。黒字日正額合計を分母にした別寄与もJSONへ残した。','',
      '## 重複した対照と、ここから言える範囲','']
    for family in result['系列']:
        if family['重複対照の参照']:
            lines.append('- '+family['ID']+'：'+'、'.join(str(n)+' '+text for n,text in family['重複対照の参照'])+'。')
    lines += ['', '重複は本表の集約/日別が同値であることを確認してまとめたもの。個々のSource/実入口全fieldをこの補助で再照合したのではない。同じ玉数・枚数だけで同実入口と断定せず、原試行の対照証拠と区別する。A=AB、E3=E3Sの観測重複や費用/遅延の反復を独立の市場例へ加算しない。','',
      '元の連続S0は同じmini期間で大きな実黒字だが、連続P0/P1を加えた結果や5分化は別の運転条件である。後段の厳しいA/ABは少数化と小さな主黒字を示すが、Bは実取得0で有効な反転選別の実証ではない。E3/Sは28玉56枚の複合入口とH0で主黒字になった一方、C5/D0は赤字。100のE3S/P0は4感度とも黒字だが最良日集中があり、H0/HGへの変更も全感度の純額を改善しない。','',
      'R05/R10やHGの利益後赤字件数の減少だけを見ると、利益化前で終わって正益分母から外れた損失を見落とす。純額・量・u/Wの分母を同時に読む。時計・quiet・資格・出口をまたぐ差は、特定のテクニカル一つや退出一つの因果効果へ帰属しない。','',
      '出力位相も区別する。93は元通知の連続返済で新MTM正益後赤字は未計測。94以降はpre_fill/after_sourceの口座MTM、95はSourceForce→Grid→raw、96以降はチャートtimer公開→grid→同秒rawを固定。97/98/100の追加出口要求はSource予約後の未予約残が対象。JSON集約の位相差を消して同じ指標と扱わない。','',
      'この比較は既使用54場の記述統計で、未知期間の利益安定性、実miniの約定、真の受信順を証明しない。未参加/決済後の仮想利益、MFE回収率、旧70%等の合格条件は使わず、新しい閾値・試行・採用方式は決めない。','',
      '## 出典と再現','',
      '詳細path/SHAと使用欄は `比較.json` に保存した。集中の純関数は549451版をSHA参照。再集計コードは同dirの `比較をまとめる.py`、入力全33ファイルと同純関数の前後SHAを検査する。','']
    for source in result['出典']:
        relative='../../'+source['dir']+'/'
        lines.append('- '+str(source['試行'])+'：['+source['dir']+']('+relative+'README.md)、[設定]('+relative+'設定と結果.md)、[結果集約]('+relative+'成果物/結果.json)。')
    return '\n'.join(lines)


def main():
    """
    機能: 90〜100の許可した33ファイルだけから比較JSON/MDを作る。
    引数: なし。入力は正式README/設定/成果物結果、出力は新規work。
    返り値: None。原試行・コード・条件を変更しない。
    """
    paths={n:next((ROOT/'study').glob(str(n).zfill(5)+'_*')) for n in range(90,101)}
    before={str(path):sha(path) for home in paths.values() for path in (home/'README.md',home/'設定と結果.md',home/'成果物/結果.json')}
    data={}
    sources=[]
    for n,home in paths.items():
        for name in ('README.md','設定と結果.md'):
            (home/name).read_text(encoding='utf-8')
        value=json.loads((home/'成果物/結果.json').read_text(encoding='utf-8'),parse_float=Decimal)
        need(value['試行']==n and value['場数']==(66 if n<93 else 54),'固定試行/場数差')
        if n>=94:
            need(value['成功'] is True,'未完の集約')
            data[n]=value
        sources.append({'試行':n,'dir':str(home.relative_to(ROOT)).replace('\\','/'),
                        'files':{name:before[str(home/name)] for name in ('README.md','設定と結果.md','成果物/結果.json')}})
    groups=[]
    for ident,n,prefix,title,technical,clock,aliases in FAMILIES:
        cases=[case(data[n],prefix+'C'+str(c)+'_D'+str(d)) for c,d in SENSES]
        groups.append({'ID':ident,'元試行':n,'名称':title,'複合条件':technical,'新規時計':clock,'4感度':cases,
                       '重複対照の参照':aliases})
    by_id={g['ID']:g for g in groups}
    comparisons=[('94-P0',95,'P0_'),('95-B5Q',96,'B5Q_P0_'),('95-B5Q',97,'B5Q_P0_'),
      ('96-A',96,'AB_B5Q_P0_'),('96-A',97,'AB_B5Q_P0_'),('97-G0-H0',98,'H0_B5Q_P0_'),
      ('97-G0-H0',99,'H0_B5Q_P0_'),('97-AB-H0',98,'H0_AB_B5Q_P0_'),
      ('99-E3S-H0',99,'H0_E3_B5Q_P0_'),('99-E3S-H0',100,'H0_E3S_B5Q_P0_')]
    for ident,n,prefix in comparisons:
        for i,(c,d) in enumerate(SENSES):
            other=case(data[n],prefix+'C'+str(c)+'_D'+str(d))
            need(signature(other)==signature(by_id[ident]['4感度'][i]),'重複対照の集約差:'+ident)
    after={path:sha(Path(path)) for path in before}
    need(before==after and sha(CONC_PATH)==CONC_SHA,'正式入力/純関数前後差')
    result={'成功':True,'確認日':'2026-11-09','試行範囲':[90,100],'順位付け':False,'系列':groups,'出典':sources,
      '4感度順':['C0D0','C0D1','C5D0','C5D1'],'対照集約一致検査':len(comparisons)*4,
      '集中純関数':{'path':str(CONC_PATH.relative_to(ROOT)).replace('\\','/'),'SHA256':CONC_SHA},
      '比較コードSHA256':sha(Path(__file__)),'正式入力SHA256前':before,'正式入力SHA256後':after,'前後不変':True,
      '非比較理由':{'90〜92':'micro/66場/15分/G1/122円往復','93':'mini54場の連続元退出・D1/新追尾なし・元gross再現不一致'},
      '使用欄':'完成metadata/集計/実現診断と、日別又は場別session/key/totals.net_yenだけ。README/設定。',
      '個別実入口の新独立照合':False,'Native/Raw/Tape/Source/途中101読取':0,'再金融/仮想約定/機会損失/MFE/旧70%評価':0,
      '未知期間の安定性実証':False,'正式変更/新閾値/新試行/方式採用':0}
    need(not (HERE/'比較.json').exists() and not (HERE/'メモ.md').exists(),'出力既存')
    (HERE/'比較.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (HERE/'メモ.md').write_text(render(result),encoding='utf-8',newline='\n')
    print('11試行/16系列/64感度・重複対照40検査0差')


if __name__=='__main__':
    main()
