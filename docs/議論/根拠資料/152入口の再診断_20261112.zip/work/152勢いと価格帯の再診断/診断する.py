"""固定B152だけを既定の勢い/価格帯区分へ写し、141算術で同q1正逆を診断する。"""
from pathlib import Path
from collections import Counter
import argparse
import copy
import hashlib
import importlib.util
import json
import math
import re
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
SCOPE=HERE/'区分票.md'
F1=ROOT/'work/154回帰環境の評価/F1入口選択後.json'
SELECT=ROOT/'work/154回帰環境の評価/入口選択/選択対応.json'
SUMMARY=ROOT/'work/154回帰環境の評価/金融集計/集計.json'
FEATURE=ROOT/'inputs/00148_全1分入口母集団/当時特徴.json.gz'
CATALOG=ROOT/'inputs/00148_全1分入口母集団/100特徴の列定義.json'
OBS=ROOT/'work/148全1分母集団の評価/固定取得の正逆観測.json'
DATA=ROOT/'work/151過去場判別/data151.py'
ARITH=ROOT/'work/141金融集計を独立に確認する.py'
EXPECTED={F1:'d3eb4ed12b2a62b46da3e0bc581e558f8a5a85514a0f56ac5bc4c6be12de942a',SUMMARY:'41b160e6918b7bdd58e8fcacf857ca036cb5f93720bde617d0c062169fe0deef',
    FEATURE:'464dad9dce7acb20f043c344e96c9fa6d19ab0049a9d557e6fc96f6d189abcb7',CATALOG:'c85223fbe1543e5457c28d4391f817534099d1af1d19664035c668ff5fe8a7b4',
    OBS:'d1b4cab8a258203f04b5c1d081f57d10ed2a0c58ce4cc160ef571d5fac0ceffc',DATA:'3b92ff77a28bf82e6cf8e5dc504cc5586f4101c1e28d0bc12b29bc7cd0efdd8c',
    ARITH:'30bd4aef8c2809699cb013f930cfbce152f3986fe8d3d3cc6b49452104c2269e'}
FEATURE_DECODED='572705d7db8529555c876eb1953f7d8e1cd1de0e554bf9de729a7d377e4d91af'
KEYS={'RSI':'m5_rsi_center_to_side','Hist':'m5_hist_to_side','HistΔ':'m5_hist_delta_to_side','BB':'q0_entry_minus_bbmean_sigma_to_side','量':'m1_volume_relative_prior3'}
RSI_LEVELS=('元方向過熱>=20','逆側過熱<=-20','間(-20,20)','未知')
SIGNS=('正','0','負','未知')
BB_LEVELS=('外側>=2','順側内[0,2)','反対側<0','未知')
VOLUME_LEVELS=('>=1','<1','未知')
DELTA_LEVELS=('失速Δ<0','非負Δ>=0','未知')


def sha(path: Path) -> str:
    """
    機能: 大きな物理ファイルをbufferで指紋化する。
    引数: path(Path)。返り値: str。
    """
    h=hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda:source.read(1<<20),b''):h.update(block)
    return h.hexdigest()


def module(path: Path,name: str) -> object:
    """
    機能: mainなしで固定feature reader又は141算術を私有importする。
    引数: path(Path)、name(str)。返り値: object。
    """
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m


def array_items(path: Path,key: str):
    """
    機能: 指紋確認済み整形JSONのトップ配列を一場ずつ読む。
    引数: path(Path)、key(str)。返り値: Iterator[dict]。
    """
    decoder=json.JSONDecoder();buffer='';found=False
    with path.open(encoding='utf-8') as source:
        while not found:
            chunk=source.read(1<<20)
            if not chunk:raise ValueError('トップ配列なし')
            buffer+=chunk;match=re.search(r'(?m)^  "'+re.escape(key)+r'": \[',buffer)
            if match:buffer=buffer[match.end():];found=True
        while True:
            buffer=buffer.lstrip()
            if buffer.startswith(']'):return
            if buffer.startswith(','):buffer=buffer[1:].lstrip()
            try:value,end=decoder.raw_decode(buffer)
            except json.JSONDecodeError:
                chunk=source.read(1<<20)
                if not chunk:raise ValueError('配列途中終了')
                buffer+=chunk;continue
            yield value;buffer=buffer[end:]


def bucket(axis: str,value) -> str:
    """
    機能: 先固定境界を丸めず、等号と未知を排他的に分類する。
    引数: axis(str)、value(float|None)。返り値: str。
    """
    if value is None:return '未知'
    assert type(value) in (int,float) and math.isfinite(value)
    if axis=='RSI':return RSI_LEVELS[0] if value>=20 else RSI_LEVELS[1] if value<=-20 else RSI_LEVELS[2]
    if axis=='sign':return '正' if value>0 else '負' if value<0 else '0'
    if axis=='BB':return BB_LEVELS[0] if value>=2 else BB_LEVELS[1] if value>=0 else BB_LEVELS[2]
    if axis=='量':return VOLUME_LEVELS[0] if value>=1 else VOLUME_LEVELS[1]
    if axis=='失速':return DELTA_LEVELS[0] if value<0 else DELTA_LEVELS[1]
    raise ValueError('未採用区分')


def classify(values: dict) -> dict:
    """
    機能: 元tの6値だけから単独と指定2交差のbinを固定する。
    引数: values(dict[str,float|None])。返り値: dict[str,str]。
    """
    rsi=bucket('RSI',values['RSI']);bb=bucket('BB',values['BB']);delta=bucket('失速',values['HistΔ'])
    return {'RSI':rsi,'MACD-Hist符号×Δ符号':bucket('sign',values['Hist'])+'/'+bucket('sign',values['HistΔ']),
        'BB':bb,'量':bucket('量',values['量']),'RSI×Hist失速':rsi+' / '+delta,'BB×Hist失速':bb+' / '+delta}


def levels() -> dict:
    """
    機能: 空群も保持する全事前区分名を返す。
    引数: なし。返り値: dict[str,list]。
    """
    return {'RSI':list(RSI_LEVELS),'MACD-Hist符号×Δ符号':[a+'/'+b for a in SIGNS for b in SIGNS],
        'BB':list(BB_LEVELS),'量':list(VOLUME_LEVELS),'RSI×Hist失速':[a+' / '+b for a in RSI_LEVELS for b in DELTA_LEVELS],
        'BB×Hist失速':[a+' / '+b for a in BB_LEVELS for b in DELTA_LEVELS]}


def concentration(rows: list,sessions: list) -> dict:
    """
    機能: 0場を含む最小/最大場数と名目H60連結群を計数する。
    引数: rows(list)、sessions(list)。返り値: dict。
    """
    count=Counter(r['session'] for r in rows);maximum=max(count.values(),default=0);components=[]
    for sid in sessions:
        current=[]
        for time in sorted(r['entry_time'] for r in rows if r['session']==sid):
            if not current or time>=current[-1][1]:current.append([time,time+3600,1])
            else:current[-1][1]=max(current[-1][1],time+3600);current[-1][2]+=1
        components.extend(current)
    return {'対象場数':len(sessions),'取得場数':len(count),'最小場件数_0含む':min((count[s] for s in sessions),default=0),
        '最小取得場件数':min(count.values(),default=0),'最大場件数':maximum,'最大件数場':[s for s in sessions if maximum and count[s]==maximum],
        '最大場比率':maximum/len(rows) if rows else None,'名目60分連結群数':len(components),'最大群件数':max((c[2] for c in components),default=0)}


def paired(rows: list,sessions: list,arithmetic: object) -> dict:
    """
    機能: 固定binを変えず同q1元/実逆を141別算術で計算する。
    引数: rows(list)、sessions(list)、arithmetic(object)。返り値: dict。
    """
    cases=[(r['session'],r['case']) for r in rows]
    native=arithmetic.calculate(cases,False,'BBO',3600,125);inverse=arithmetic.calculate(cases,True,'BBO',3600,125)
    # 正規化後の内部reverse旗は、元case格納方向との差の件数とは違うため報告しない。
    native.pop('flips');inverse.pop('flips')
    return {'元方向':native,'実逆':inverse,'集中と依存':concentration(rows,sessions)}


def normalize(case: dict,choice: dict) -> dict:
    """
    機能: 固定B152の格納streamを元方向へ正規化し実反対側を保持する。
    引数: case/choice(dict)。返り値: dictはoriginal/reverseだけ。
    """
    stream=choice['stream'];other='reverse' if stream=='original' else 'original';entry=case[stream]['entry'];side=case[stream]['birth']['side']
    assert side==choice['side'] and case[other]['birth']['side']==-side and case[other]['entry']==entry
    assert case[stream]['entry_price']==entry['ask' if side==1 else 'bid'] and entry['quote_ok'] and 0<entry['bid']<entry['ask']
    return {'original':case[stream],'reverse':case[other]}


def stratify(rows: list,sessions: list,arithmetic: object) -> dict:
    """
    機能: 全/既使用前後を固定単独/指定交差で比較し群和を検査する。
    引数: rows/list、sessions/list、arithmetic/object。返り値: dict。
    """
    out={}
    for part,scope in [('all',sessions),('train',sessions[:48]),('validation',sessions[48:])]:
        current=[r for r in rows if r['session'] in scope];whole=paired(current,scope,arithmetic);axes={}
        for axis,names in levels().items():
            axes[axis]={name:paired([r for r in current if r['bins'][axis]==name],scope,arithmetic) for name in names}
            for direction in ('元方向','実逆'):
                for key in ('entries','forward','adverse','neither','censored','ifd_known','ifd_unknown','ifd_net5_profit','ifd_net5_loss','ifd_net5_sum'):
                    assert sum(v[direction][key] or 0 for v in axes[axis].values())==(whole[direction][key] or 0),(part,axis,direction,key)
        out[part]={'全614の対応母集団':whole,'単独と指定交差':axes}
    return out


def main() -> None:
    """
    機能: 区分票固定後だけ選択614と特徴/正逆を読み小型集計を保存する。
    引数: CLI scope-sha256(str)、execute-after-scope(bool)。返り値: None。124/学習を呼ばない。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--scope-sha256',required=True);parser.add_argument('--execute-after-scope',action='store_true')
    args=parser.parse_args();assert args.execute_after_scope and sha(SCOPE)==args.scope_sha256
    refs={**EXPECTED,SCOPE:args.scope_sha256,Path(__file__):sha(Path(__file__))};assert all(sha(p)==h for p,h in refs.items())
    freeze=json.loads(F1.read_bytes());refs[SELECT]=freeze['ファイル'][SELECT.relative_to(ROOT).as_posix()];assert sha(SELECT)==refs[SELECT]
    before={str(p):[p.stat().st_size,p.stat().st_mtime_ns] for p in refs};selection=json.loads(SELECT.read_bytes());choices=selection['政策']['B152'];sessions=selection['全73場']
    assert len(choices)==len({r['case_id'] for r in choices})==614 and len(sessions)==73
    events={r['event_id']:r for r in choices};assert len(events)==614 and None not in events
    data=module(DATA,'feature_reader_b152');raw,evidence=data.read_ref(data.FileRef(FEATURE,refs[FEATURE],FEATURE_DECODED))
    catalog=json.loads(CATALOG.read_bytes());assert raw['catalog']==catalog and len(catalog)==100 and raw['sessions']==sessions
    assert raw['success'] and raw['trial']==148 and not raw['financial_labels_used'] and not raw['strategy_selected']
    index={c['name']:i for i,c in enumerate(catalog)};features={};seen=set()
    for item in raw['rows']:
        event=item['event_id'];assert event not in seen;seen.add(event)
        if event not in events:continue
        choice=events[event];q=item['metadata']['q0'];assert choice['session']==item['session'] and choice['feature_ref']==event
        assert (q['time'],q['index'],q['source_line'])==(choice['q0_time'],choice['q0_index'],choice['q0_line'])
        vector=item['buy' if choice['side']==1 else 'sell'];assert vector['side']==choice['side']
        values={name:vector['x'][index[column]] for name,column in KEYS.items()}
        features[event]={'session':item['session'],'contract':item['contract'],'values':values,'bins':classify(values)}
    assert len(seen)==35339 and set(features)==set(events);del raw
    needed={r['case_id'] for r in choices};cases={};scene_count=0
    for scene in array_items(OBS,'scenes'):
        assert scene['success'] and scene['session']==sessions[scene_count];scene_count+=1
        for case in scene['cases']:
            if case['id'] in needed:
                assert case['id'] not in cases;cases[case['id']]=(scene['session'],case)
    assert scene_count==73 and set(cases)==needed;rows=[];physical=set()
    for choice in choices:
        sid,case=cases[choice['case_id']];event=choice['event_id'];feature=features[event];normalized=normalize(case,choice)
        entry=normalized['original']['entry'];side=choice['side']
        assert sid==choice['session']==feature['session'];key=(sid,entry['time'],entry['index'],entry['source_line']);assert key not in physical;physical.add(key)
        rows.append({'session':sid,'event_id':event,'case_id':choice['case_id'],'side':side,'entry_time':entry['time'],'bins':feature['bins'],
            'case':normalized})
    del cases,features
    arithmetic=module(ARITH,'independent141forB152');result=stratify(rows,sessions,arithmetic);summary=json.loads(SUMMARY.read_bytes());checked=0
    for part in result:
        actual=result[part]['全614の対応母集団']['元方向'];expected=summary['集計'][part]['B152']['BBO']['3600']['125']
        for key in ('entries','sessions','forward','adverse','neither','censored','ifd_known','ifd_unknown','ifd_net5_profit','ifd_net5_loss','ifd_net5_sum'):
            assert actual[key]==expected[key],(part,key);checked+=1
    assert all(sha(p)==h for p,h in refs.items()) and before=={str(p):[p.stat().st_size,p.stat().st_mtime_ns] for p in refs}
    output={'成功':True,'用途':'固定B152614の事後再診断。新政策/閾値探索なし。','区分票SHA256':args.scope_sha256,'元方向':'固定B152.sideのq0買Ask/売Bid特徴、実逆もbinは元側固定',
        '正規化後の内部flips旗は元case格納側との差でないため不出力':True,
        '全期既使用':True,'同q1重複なし':True,'124又はモデル学習import':False,'金融算術':'固定Root141.calculateのみ','原典614主要値同体セル':checked,
        '入力':{p.relative_to(ROOT).as_posix():h for p,h in refs.items()},'features読取証跡':evidence,'全入力前後SHA_stat同体':True,
        '全件転載なし':True,'全期前後':result}
    target=HERE/'診断.json'
    with target.open('x',encoding='utf-8') as sink:json.dump(output,sink,ensure_ascii=False,indent=2,allow_nan=False);sink.write('\n')
    print(json.dumps({'成功':True,'全614':result['all']['全614の対応母集団'],'出力SHA256':sha(target)},ensure_ascii=False))


if __name__=='__main__':
    main()
