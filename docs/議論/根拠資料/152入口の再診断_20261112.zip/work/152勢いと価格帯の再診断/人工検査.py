"""固定境界・物理側正規化・群和と0場を小型人工で検査する。"""
from pathlib import Path
import copy
import importlib.util
import sys
import unittest

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('diagnoseB152',HERE/'診断する.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
arith=m.module(m.ARITH,'fixed141_B152_artificial')


def stream(side: int,direction: int,status: str='complete') -> dict:
    """
    機能: H不足でもtouch既知を表す人工BBO観測を作る。
    引数: side/direction(int)、status(str)。返り値: dict。
    """
    q={'time':100,'index':1,'source_line':2,'last':100,'bid':99,'ask':101,'quote_ok':True}
    touch={**q,'time':200,'index':2,'source_line':3,'bid':226,'ask':228}
    return {'birth':{'side':side},'entry':q,'entry_price':q['ask' if side==1 else 'bid'],
        'outcomes':[{'seconds':3600,'status':status,'touches':[{'width':125,'direction':direction,'quote':touch if direction else None}],
                     'endpoint':touch if status=='complete' else None}]}


class Tests(unittest.TestCase):
    def test_固定境界とknown0(self):
        """
        機能: RSI±20/BB0,2/量1/符号0を排他的に分類する。
        引数: self(Tests)。返り値: None。
        """
        self.assertEqual([m.bucket('RSI',v) for v in [-20,-19.9,19.9,20,None]],['逆側過熱<=-20','間(-20,20)','間(-20,20)','元方向過熱>=20','未知'])
        self.assertEqual([m.bucket('BB',v) for v in [-.1,0,1.99,2,None]],['反対側<0','順側内[0,2)','順側内[0,2)','外側>=2','未知'])
        self.assertEqual([m.bucket('量',v) for v in [0,1,None]],['<1','>=1','未知'])
        self.assertEqual([m.bucket('失速',v) for v in [-.1,0,1,None]],['失速Δ<0','非負Δ>=0','非負Δ>=0','未知'])
        self.assertEqual([m.bucket('sign',v) for v in [-1,0,1,None]],['負','0','正','未知'])

    def test_売格納から選択買へ正規化(self):
        """
        機能: case格納側と選択側を混ぜず、実逆は別価格で評価する。
        引数: self(Tests)。返り値: None。
        """
        stored={'original':stream(-1,-1),'reverse':stream(1,1)};before=copy.deepcopy(stored)
        normalized=m.normalize(stored,{'side':1,'stream':'reverse'})
        actual=arith.calculate([('人工',normalized)],False,'BBO',3600,125);reverse=arith.calculate([('人工',normalized)],True,'BBO',3600,125)
        self.assertEqual(actual['ifd_net5_sum'],125*100-1077);self.assertEqual(reverse['ifd_net5_sum'],-129*100-1077)
        self.assertEqual(stored,before)

    def test_H不足でもtouch既知と空率(self):
        """
        機能: H不完了をCに残しながら既知IFDを保持し空率をnullとする。
        引数: self(Tests)。返り値: None。
        """
        case={'original':stream(1,1,'censored'),'reverse':stream(-1,0,'censored')}
        first=arith.calculate([('人工',case)],False,'BBO',3600,125);second=arith.calculate([('人工',case)],True,'BBO',3600,125)
        self.assertEqual((first['censored'],first['ifd_known']),(1,1));self.assertEqual(second['ifd_unknown'],1)
        self.assertIsNone(arith.calculate([],False,'BBO',3600,125)['resolved_rate'])

    def test_群和と最大場数と元bin保持(self):
        """
        機能: 全分割で元実逆の群和が一致し、同じbinを使う。
        引数: self(Tests)。返り値: None。
        """
        sessions=[f'場{i:02}' for i in range(73)];rows=[]
        for i,values in enumerate([{'RSI':20,'Hist':1,'HistΔ':-1,'BB':2,'量':1},{'RSI':None,'Hist':None,'HistΔ':0,'BB':None,'量':0}]):
            rows.append({'session':sessions[0],'entry_time':100+i*60,'bins':m.classify(values),
                         'case':{'original':stream(1,1 if i==0 else 0),'reverse':stream(-1,-1)}})
        before=copy.deepcopy(rows);out=m.stratify(rows,sessions,arith)
        concentration=out['all']['全614の対応母集団']['集中と依存']
        self.assertEqual((concentration['最小場件数_0含む'],concentration['最大場件数']),(0,2))
        self.assertEqual(concentration['最大件数場'],[sessions[0]]);self.assertEqual(concentration['最大群件数'],2)
        self.assertEqual(out['validation']['全614の対応母集団']['元方向']['entries'],0)
        self.assertEqual(rows,before)


if __name__=='__main__':
    unittest.main(verbosity=2)
