"""固定B152の実体と現在価格を区分し、その後だけ同q1実正逆を診断する。"""
from pathlib import Path
from collections import Counter
import gzip
import hashlib
import importlib.util
import json
import math
import re

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
MATH_PATH = ROOT / 'work/141金融集計を独立に確認する.py'
MATH_SHA = '30bd4aef8c2809699cb013f930cfbce152f3986fe8d3d3cc6b49452104c2269e'
PATHS = {
 'f1': ROOT / 'work/154回帰環境の評価/F1入口選択後.json',
 'f2': ROOT / 'work/154回帰環境の評価/F2実金融集計前.json',
 'selection': ROOT / 'work/154回帰環境の評価/入口選択/選択対応.json',
 'high': ROOT / 'inputs/00153_先行高安の独立出生/先行高安の入力.json.gz',
 'observations': ROOT / 'study/00148_全1分知得から入口品質の母集団を固定する/成果物/固定取得の正逆観測.json.gz',
 'baseline152': ROOT / 'study/00152_強い反対背景を複合回復で切り替える/成果物/集計.json',
 'summary154': ROOT / 'work/154回帰環境の評価/金融集計/集計.json',
 'definition': HERE / '区分の事前固定.md'}
GROUPS = {'実体': ('元t側', '反対', '実体0'), '始値': ('正', '等', '負'), '逆端': ('非破り', '破り'),
          '実体×始値': tuple(a + '/' + b for a in ('元t側', '反対', '実体0') for b in ('正', '等', '負'))}


def sha(path: Path) -> str:
    """
    機能: 明示入力の全物理指紋をstreamで求める。
    引数: path(Path)。返り値: str。
    """
    value = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1 << 20), b''): value.update(block)
    return value.hexdigest()


# ----------------------------------------
def read_gzip(path: Path, physical: str, decoded: str) -> dict:
    """
    機能: gzip全CRCと物理/解凍SHAを検証してJSONを読む。
    引数: path(Path)、physical/decoded(str)。返り値: dict。
    """
    assert sha(path) == physical
    with gzip.open(path, 'rb') as source: body = source.read()
    assert hashlib.sha256(body).hexdigest() == decoded
    return json.loads(body)


# ----------------------------------------
def array(path: Path, name: str, evidence: dict):
    """
    機能: 大JSON配列を1要素ずつ読み全解凍指紋/CRCを完読する。
    引数: path(Path)、name(str)、evidence(dict)。返り値: Iterator[dict]。
    """
    digest = hashlib.sha256(); size = 0; buffer = ''; decoder = json.JSONDecoder()
    opener = gzip.open if path.suffix == '.gz' else Path.open
    with opener(path, 'rt', encoding='utf-8', newline='') as source:
        def more() -> str:
            """
            機能: UTF8境界を保って全bytesを指紋へ加える。
            引数: なし。返り値: str。
            """
            nonlocal size
            value = source.read(1 << 20); raw = value.encode('utf-8'); digest.update(raw); size += len(raw); return value
        while True:
            value = more(); assert value, '配列がない'
            buffer += value; match = re.search(r'(?m)^  "' + re.escape(name) + r'": \[', buffer)
            if match: buffer = buffer[match.end():]; break
        while True:
            buffer = buffer.lstrip()
            if buffer.startswith(']'): break
            if buffer.startswith(','): buffer = buffer[1:].lstrip()
            try: item, end = decoder.raw_decode(buffer)
            except json.JSONDecodeError:
                value = more(); assert value, '配列途中終了'; buffer += value; continue
            yield item; buffer = buffer[end:]
        while more(): pass
    evidence.update(decoded_sha256=digest.hexdigest(), decoded_bytes=size, gzip_full_crc_checked=path.suffix == '.gz')


# ----------------------------------------
def stamp(value: dict) -> tuple:
    """
    機能: q0と保存Stampの両物理行schemaを統一する。
    引数: value(dict)。返り値: tuple。
    """
    return value['time'], value['index'], value['line'] if 'line' in value else value['source_line']


# ----------------------------------------
def classify(side: int, row: dict, r: dict) -> tuple:
    """
    機能: 事前固定の実体/現在始値/逆端へ元B152方向で一意に分類する。
    引数: side(int)、row/r(dict)。返り値: tuple[str,str,str]。
    """
    assert type(side) is int and side in (-1, 1)
    q = row['q0']; assert row['eligible'] and q['last_known'] and r['price_known'] and r['closed'] and not r['missing']
    assert stamp(r['stamp']) == stamp(q) and r['end'] <= r['available_at'] <= q['time']
    assert all(type(v) in (int, float) and math.isfinite(v) for v in (q['last'], *r['ohlc'].values()))
    d_body = side * (r['ohlc']['close'] - r['ohlc']['open'])
    d_open = side * (q['last'] - r['ohlc']['open'])
    d_extreme = side * (q['last'] - r['ohlc']['low' if side == 1 else 'high'])
    return ('元t側' if d_body > 0 else '反対' if d_body < 0 else '実体0',
            '正' if d_open > 0 else '負' if d_open < 0 else '等', '破り' if d_extreme < 0 else '非破り')


# ----------------------------------------
def stat(value: dict) -> dict:
    """
    機能: 141結果の必要値だけを表示し空の損益nullを保つ。
    引数: value(dict)。返り値: dict。
    """
    fields = {'件数': 'entries', '場数': 'sessions', 'F': 'forward', 'A': 'adverse', 'N': 'neither', 'C': 'censored',
              '到達済率': 'resolved_rate', '完了分母率': 'complete_rate', 'IFD既知': 'ifd_known', 'IFD未知': 'ifd_unknown',
              'C5利益': 'ifd_net5_profit', 'C5損失絶対': 'ifd_net5_loss', 'C5差引': 'ifd_net5_sum', 'PF': 'ifd_net5_pf'}
    return {name: value[key] for name, key in fields.items()}


# ----------------------------------------
def group_name(pair: tuple, axis: str) -> str:
    """
    機能: 固定分類から各分割の名称を得る。
    引数: pair(tuple[str,str])、axis(str)。返り値: str。
    """
    return pair[0] if axis == '実体' else pair[1] if axis == '始値' else pair[2] if axis == '逆端' else '/'.join(pair[:2])


# ----------------------------------------
def main() -> None:
    """
    機能: 群固定・因果結合後にB152だけの実正逆を計算し、小票へ保存する。
    引数: なし。返り値: None。新条件/新q0/新選択/Rawを生成しない。
    """
    output = HERE / '診断.json'; assert not output.exists()
    assert sha(MATH_PATH) == MATH_SHA
    before = {key: {'sha256': sha(path), 'bytes': path.stat().st_size, 'mtime_ns': path.stat().st_mtime_ns} for key, path in PATHS.items()}
    assert before['f1']['sha256'] == 'd3eb4ed12b2a62b46da3e0bc581e558f8a5a85514a0f56ac5bc4c6be12de942a'
    assert before['f2']['sha256'] == 'c14dc4005bd9bbdb3ce7987beb63796e8e97cd677964bb3b536f8f15eb72f0a8'
    assert before['observations']['sha256'] == 'bd809bdf24400628817afee702063504c65682e6748a60e0f32d7690b7363c61'
    f1 = json.loads(PATHS['f1'].read_bytes()); f2 = json.loads(PATHS['f2'].read_bytes()); selection = json.loads(PATHS['selection'].read_bytes())
    for key in ('selection',):
        assert f1['ファイル'][PATHS[key].relative_to(ROOT).as_posix()] == before[key]['sha256']
        assert f2['ファイル'][PATHS[key].relative_to(ROOT).as_posix()] == before[key]['sha256']
    refs = selection['政策']['B152']; assert len(refs) == len({r['case_id'] for r in refs}) == 614
    sessions = selection['全73場']; assert len(sessions) == len(set(sessions)) == 73
    high = read_gzip(PATHS['high'], '2c020fed5b336ed0b417d8e72a07c6336ea475b09b9a2ff37f26ec4ce4d56bf8',
                     '8e145275dda385e4c2f87500978716654d10efb0903a4011f2bcc304a7906b14')
    assert high['sessions'] == sessions
    source = {}
    for scene in high['scenes']:
        bars = {bar['id']: bar for bar in scene['bars']}
        for row in scene['rows']:
            assert row['event_id'] not in source
            source[row['event_id']] = (scene['session'], scene['contract'], row, bars[row['r_ref']])
    assert len(source) == 40544
    groups, missing = {}, []
    for ref in refs:
        if ref['event_id'] not in source:
            missing.append({'case_id': ref['case_id'], 'event_id': ref['event_id'], '理由': '先行高安の台帳にeventなし'}); continue
        sid, contract, row, r = source[ref['event_id']]
        try:
            assert ref['session'] == sid
            assert stamp(row['q0']) == (ref['q0_time'], ref['q0_index'], ref['q0_line'])
            groups[ref['case_id']] = classify(ref['side'], row, r)
        except (KeyError, AssertionError, TypeError):
            missing.append({'case_id': ref['case_id'], 'event_id': ref['event_id'], '理由': 'r/当時価格/参照の不足又は不一致'})
    if missing:
        insufficient = {'成功': False, '固定B152全件': 614, '不足件数': len(missing), '除外して金融計算': False, '不足': missing}
        with (HERE / '不足の確認.json').open('x', encoding='utf-8') as target: json.dump(insufficient, target, ensure_ascii=False, indent=2)
        raise RuntimeError('614件を欠落のまま除外しない。不足票を参照。')
    assert len(groups) == 614
    # ----------------------------------------
    # ここまで金融観測未読。元方向の群を以後固定し実逆でも組み替えない。
    spec = importlib.util.spec_from_file_location('固定141独立算術_B152位置診断', MATH_PATH)
    mathematics = importlib.util.module_from_spec(spec); spec.loader.exec_module(mathematics)
    wanted = {ref['case_id']: ref for ref in refs}; cases = []; obs_evidence = {}; total_cases = scene_count = 0
    for scene in array(PATHS['observations'], 'scenes', obs_evidence):
        assert scene['success'] and scene['session'] == sessions[scene_count]; scene_count += 1; total_cases += len(scene['cases'])
        for case in scene['cases']:
            if case['id'] not in wanted: continue
            ref = wanted.pop(case['id']); stream = ref['stream']; other = 'reverse' if stream == 'original' else 'original'
            native, inverse = case[stream], case[other]
            assert native['birth']['side'] == ref['side'] and inverse['birth']['side'] == -ref['side']
            assert native['entry'] == inverse['entry'] and ref['session'] == scene['session']
            quote = native['entry']; assert quote['quote_ok'] and 0 < quote['bid'] < quote['ask']
            assert native['entry_price'] == quote['ask' if ref['side'] == 1 else 'bid']
            assert inverse['entry_price'] == quote['bid' if ref['side'] == 1 else 'ask']
            cases.append((scene['session'], {**case, 'original': native, 'reverse': inverse,
                'chart_original': case['chart_' + stream], 'chart_reverse': case['chart_' + other]}))
    assert not wanted and scene_count == 73 and total_cases == 31642
    assert obs_evidence['decoded_sha256'] == 'd1b4cab8a258203f04b5c1d081f57d10ed2a0c58ce4cc160ef571d5fac0ceffc'
    result = {}; sum_checks = 0
    for part, scope in (('all', sessions), ('train', sessions[:48]), ('validation', sessions[48:])):
        selected = [row for row in cases if row[0] in scope]; period = {'全B152': {}}
        for name, reverse in (('元方向', False), ('実逆', True)):
            period['全B152'][name] = stat(mathematics.calculate(selected, reverse, 'BBO', 3600, 125))
        for axis, labels in GROUPS.items():
            table = {}
            for label in labels:
                subset = [row for row in selected if group_name(groups[row[1]['id']], axis) == label]
                table[label] = {name: stat(mathematics.calculate(subset, reverse, 'BBO', 3600, 125)) for name, reverse in (('元方向', False), ('実逆', True))}
            period[axis] = table
            for name in ('元方向', '実逆'):
                whole = period['全B152'][name]
                for key in ('件数', 'F', 'A', 'N', 'C', 'IFD既知', 'IFD未知'):
                    assert sum(table[label][name][key] for label in labels) == whole[key]; sum_checks += 1
                for key in ('C5利益', 'C5損失絶対', 'C5差引'):
                    total = sum(table[label][name][key] for label in labels if table[label][name]['IFD既知'])
                    assert total == whole[key]; sum_checks += 1
        result[part] = period
    # ----------------------------------------
    # 元B152の全60条件を最後に旧152/現154へ照合する。群の選別へ使わない。
    baseline = json.loads(PATHS['baseline152'].read_bytes()); current = json.loads(PATHS['summary154'].read_bytes())
    assert baseline['試行'] == 152 and current['試行'] == 154
    assert current['F1_SHA256'] == before['f1']['sha256'] and current['F2_SHA256'] == before['f2']['sha256']
    baseline_checks = 0; baseline_conditions = 0
    for part, scope in (('all', sessions), ('train', sessions[:48]), ('validation', sessions[48:])):
        selected = [row for row in cases if row[0] in scope]
        for axis in ('BBO', 'Last'):
            for horizon in (1800, 3600):
                for width in (25, 50, 100, 125, 200):
                    expected = mathematics.calculate(selected, False, axis, horizon, width)
                    expected['flips'] = sum(ref['session'] in scope and ref['stream'] == 'reverse' for ref in refs)
                    a = baseline['集計'][part]['B0'][axis][str(horizon)][str(width)]
                    b = current['集計'][part]['B152'][axis][str(horizon)][str(width)]
                    assert set(expected) == set(a) == set(b)
                    for key, value in expected.items():
                        for actual in (a[key], b[key]):
                            if isinstance(value, float): assert math.isclose(value, actual, rel_tol=1e-12, abs_tol=1e-8), (part, axis, horizon, width, key)
                            else: assert value == actual, (part, axis, horizon, width, key, value, actual)
                            baseline_checks += 1
                    baseline_conditions += 1
    assert before == {key: {'sha256': sha(path), 'bytes': path.stat().st_size, 'mtime_ns': path.stat().st_mtime_ns} for key, path in PATHS.items()}
    assert sha(MATH_PATH) == MATH_SHA
    proof = {'成功': True, '編集停止': True, '対象': '旧152B0=固定154selection.B152全614', '区分': '実体/現在価格/逆端の事後診断、再採番無し',
             '入力': before, 'コードSHA256': sha(Path(__file__)), '独立算術': {'path': MATH_PATH.relative_to(ROOT).as_posix(), 'SHA256': MATH_SHA},
             '全614取得の金融診断': result, '対応不足': missing,
             '群合計B152同体の加法検査数': sum_checks,
             '旧152/現154全B152の同体条件数': baseline_conditions, '同体キー比較数': baseline_checks,
             '観測全gzip_CRC_解凍指紋': obs_evidence,
             '全入力前後同体': True, '分群は金融読取前に固定/実逆でも元tの群を保持': True,
             '作者logic154/金融124/原因金融算術import': False, '新条件_新q0_入替政策_Raw_追加2場': False,
             '全期間既使用': True, '独立mini1_IFD既知合算で口座ではない': True}
    with output.open('x', encoding='utf-8', newline='\n') as target:
        json.dump(proof, target, ensure_ascii=False, indent=2); target.write('\n')
    print(json.dumps({'成功': True, '群合計検査数': sum_checks, '全取得': len(cases), '旧新同体条件': baseline_conditions, 'SHA256': sha(output)}, ensure_ascii=False))


if __name__ == '__main__': main()
