"""固定B152小診断の全区分を短く案内し、後発事後資料として停止する。"""
from pathlib import Path
import hashlib
import json

HERE=Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 小診断の保存指紋を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def count(value: dict) -> str:
    """
    機能: 順/逆/未/不足を明示した短い表示にする。
    引数: value(dict)。返り値: str。
    """
    return '/'.join(str(value[key]) for key in ('F','A','N','C'))


def numeric(value: int | float | None,decimals: int=0) -> str:
    """
    機能: 空率/未知金額を0にしない表示を作る。
    引数: value(int|float|None)、decimals(int)。返り値: str。
    """
    return '未定義' if value is None else f'{value:,.{decimals}f}'


def table(groups: dict) -> str:
    """
    機能: 固定順の群を順位付けせず元/実逆で併記する。
    引数: groups(dict)。返り値: str。
    """
    lines=['| 区分 | 件数 | 元F/A/N/C | 元率 | 元C5利益/損失 | 元差引・未知 | 実逆F/A/N/C | 実逆率 | 実逆C5利益/損失 | 実逆差引・未知 |',
        '| --- | ---: | --- | ---: | ---: | ---: | --- | ---: | ---: | ---: |']
    for label,row in groups.items():
        a,b=row['元方向'],row['実逆'];ar=numeric(None if a['到達済率'] is None else a['到達済率']*100,2);br=numeric(None if b['到達済率'] is None else b['到達済率']*100,2)
        lines.append(f"| {label} | {a['件数']} | {count(a)} | {ar}% | {numeric(a['C5利益'])}/{numeric(a['C5損失絶対'])} | {numeric(a['C5差引'])}・{a['IFD未知']} | {count(b)} | {br}% | {numeric(b['C5利益'])}/{numeric(b['C5損失絶対'])} | {numeric(b['C5差引'])}・{b['IFD未知']} |")
    return '\n'.join(lines).replace('未定義%','未定義')


def main() -> None:
    """
    機能: 完了JSONから短報/停止票を作り、固定614の全分母と限界を示す。
    引数: なし。返り値: None。新計算/選択/閾値変更は行わない。
    """
    path=HERE/'診断.json';data=json.loads(path.read_bytes())
    assert data['成功'] and data['対象数']==614 and data['分群の加法検査数']==180 and data['固定B152正本比較値']==42
    all_value=data['前後']['all'];a,b=all_value['全B152']['元方向'],all_value['全B152']['実逆']
    lines=['# 固定B152：背景の向きとRSI過熱の持続を分ける',
        '', '2026-11-12。Root指定の固定B152全614取得を事前区分した事後診断。[区分の事前固定](区分の事前固定.md)と[全正本](診断.json)を分け、元152/154の条件・Source・正式を変更しない。',
        '',f"全体の元方向は{count(a)}・{numeric(a['到達済率']*100,2)}%、利益{numeric(a['C5利益'])}円/損失{numeric(a['C5損失絶対'])}円/差引{numeric(a['C5差引'])}円・未知{a['IFD未知']}。同q1実逆は{count(b)}・{numeric(b['到達済率']*100,2)}%、利益{numeric(b['C5利益'])}円/損失{numeric(b['C5損失絶対'])}円/差引{numeric(b['C5差引'])}円・未知{b['IFD未知']}。",'',
        '元tはB152の最終注文方向。100Xは買Ask/売Bidを別計算したt側を読み、一律negateしない。実逆でも群の側/所属を変えず、保存された同q1反対Bid/Askから独立141算術で評価する。H60±125・1mini100円/pt、往復77円+C5追加1000円の入口IFD代用で、口座収支ではない。','',
        '## 全期：単独区分','', 'EMAは5/15/30分EMA21の生増分が元t側へ全正/全負、0又は符号混在、必要値未知の4群。', '',table(all_value['分割']['EMA']), '',
        'RSI中心はt*(RSI5−50)。現在≥20で前中心=現在−Δも≥20なら持続、前<20なら新規越え。現在<20は非過熱、必要値未知は未知。20等号を含む。新規越えは異常スパイクの認定ではない。','',table(all_value['分割']['RSI']), '',
        '## 全期：交差（未知/空群も保持）','',table(all_value['分割']['交差']), '',
        '## 前48・後25の単独区分（両方既使用）']
    for part,title in [('train','前48'),('validation','後25')]:
        value=data['前後'][part];lines.extend(['',f'### {title}','','EMA：','',table(value['分割']['EMA']),'','RSI：','',table(value['分割']['RSI'])])
    lines.extend(['','## ΔRSIと最大集中場','',
        '| 全期RSI群 | Δ既知/未知 | 最小/Q25/中央値/Q75/最大 | 平均 | 最大場件数/群件数 | 最大集中場（同率全場） |',
        '| --- | --- | --- | ---: | --- | --- |'])
    for label,row in all_value['分割']['RSI'].items():
        d=row['RSI5生増分分布'];c=row['最大集中'];vals='/'.join(numeric(d[k],4) for k in ('最小','Q25','中央値','Q75','最大'))
        lines.append(f"| {label} | {d['known']}/{d['unknown']} | {vals} | {numeric(d['平均'],4)} | {c['最大件数']}/{row['元方向']['件数']} | {'・'.join(c['最大集中場']) or 'なし'} |")
    lines.extend(['','全単独/交差×全/前/後について、同じΔの分布と全対象場の件数/最大集中場を正本に保存した。群内の標本数が多くても、同場近接/H60の重複を独立化しない。','',
        '## 旧Gを最終B152側で見た非金融件数','',
        '各条件のfalse/unknownは重複する。最初のP65側で判定したGと、18方向切替等の後の最終B152側Gは別である。以下で元P65側のG否定理由を推測したり、新しい選別をしない。','',
        '| 区分 | 条件 | true | false | unknown | 分母 |','| --- | --- | ---: | ---: | ---: | ---: |'])
    for part,g in data['旧G最終側の非金融件数'].items():
        for key,counted in g['各条件'].items():lines.append(f"| {part} | {key}{'>25' if key=='m15_adx' else '<0'} | {counted['true']} | {counted['false']} | {counted['unknown']} | {g['分母']} |")
    lines.extend(['','## 検査と解釈の境界','',
        '全614のq0識別・時計・特徴参照と元最終側の分類を完成後に保存観測を読んだ。単独/交差のF/A/N/C・IFD既知未知・利益/損失/差引の加法180件、元B152の全/前/後42統計値が正本と同体。全入力前後SHA/statとgzip CRC/解凍SHAを確認した。最大集中場も区分ごとに保持している。','',
        '初回は観測sceneに存在しないcontractキーの直接要求で分類後・最初の該当観測で金融集計前に停止した。診断器のschema検査だけを補正し、分類/閾値/入力を変更せず再実行した。初回Source/準備/停止理由は[小履歴ZIP](初回schema検査の停止.zip)に残す。','',
        '全期既使用、前48/後25も独立未知期ではない。過熱持続/一時的越えという心理の分類と実績を同一視しない。良い少数群や交差を新規則/70達成と認定せず、条件探索・新政策・新主の採用を行っていない。Raw/新CSV/追加2場は読んでいない。'])
    target=HERE/'短報.md';assert not target.exists();target.write_bytes(('\n'.join(lines)+'\n').encode('utf-8'))
    files={p.name:sha(p) for p in HERE.iterdir() if p.is_file() and p.suffix in ('.py','.md','.json','.zip')}
    stop={'成功':True,'編集停止':True,'対象':'固定B152614の背景とRSI持続','対象数':614,'人工数':4,
        '分群加法180_元正本42一致':True,'全入力前後同体':True,'元152154正式_Source変更':False,
        '新採用又は70達成認定':False,'初回schema停止を小ZIPに分離':True,'保存対象':files}
    out=HERE/'停止の確認.json';assert not out.exists();out.write_bytes((json.dumps(stop,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    print(json.dumps({'成功':True,'診断SHA256':sha(path),'短報SHA256':sha(target),'停止SHA256':sha(out),
        'EMA':{k:(v['元方向']['件数'],v['元方向']['到達済率'],v['実逆']['到達済率']) for k,v in all_value['分割']['EMA'].items()},
        'RSI':{k:(v['元方向']['件数'],v['元方向']['到達済率'],v['実逆']['到達済率']) for k,v in all_value['分割']['RSI'].items()}},ensure_ascii=False))


if __name__=='__main__':
    main()
