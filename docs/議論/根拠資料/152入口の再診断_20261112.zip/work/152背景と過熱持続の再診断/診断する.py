"""固定B152の614取得を元側EMA背景とRSI過熱持続へ分け、同q1実逆と比較する。"""
from pathlib import Path
from collections import Counter
import argparse
import gzip
import hashlib
import importlib.util
import json
import math
import re
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
MATH_PATH=ROOT/'work/141金融集計を独立に確認する.py'
MATH_SHA='30bd4aef8c2809699cb013f930cfbce152f3986fe8d3d3cc6b49452104c2269e'
DATA_PATH=ROOT/'work/151過去場判別/data151.py'
DATA_SHA='3b92ff77a28bf82e6cf8e5dc504cc5586f4101c1e28d0bc12b29bc7cd0efdd8c'
RUNTIME=ROOT/'work/154回帰環境の評価'
PATHS={'f1':RUNTIME/'F1入口選択後.json','f2':RUNTIME/'F2実金融集計前.json',
    'selection':RUNTIME/'入口選択/選択対応.json',
    'features':ROOT/'inputs/00148_全1分入口母集団/当時特徴.json.gz',
    'fixed':ROOT/'inputs/00148_全1分入口母集団/固定取得入力.json.gz',
    'observations':ROOT/'study/00148_全1分知得から入口品質の母集団を固定する/成果物/固定取得の正逆観測.json.gz',
    'summary':ROOT/'study/00154_回帰で進行と往復を分けて短期回復から入る/成果物/集計.json',
    'definition':HERE/'区分の事前固定.md'}
SHA={'f1':'d3eb4ed12b2a62b46da3e0bc581e558f8a5a85514a0f56ac5bc4c6be12de942a',
    'f2':'c14dc4005bd9bbdb3ce7987beb63796e8e97cd677964bb3b536f8f15eb72f0a8',
    'selection':'f1a6d038c1f25ae703b7aef45c41fe4470899a531481abfd735e17c6128df5ea',
    'features':'464dad9dce7acb20f043c344e96c9fa6d19ab0049a9d557e6fc96f6d189abcb7',
    'fixed':'99f10a996ca6e8b6c428061f1b48624bbc479ec84c500a9633818d47e4298e2a',
    'observations':'bd809bdf24400628817afee702063504c65682e6748a60e0f32d7690b7363c61',
    'summary':'41b160e6918b7bdd58e8fcacf857ca036cb5f93720bde617d0c062169fe0deef'}
DECODED={'features':'572705d7db8529555c876eb1953f7d8e1cd1de0e554bf9de729a7d377e4d91af',
    'fixed':'12c43fe60e0ffd5ffa44bec7b5f7dd3d60bb92b291e0008db23587dcf19536d3',
    'observations':'d1b4cab8a258203f04b5c1d081f57d10ed2a0c58ce4cc160ef571d5fac0ceffc'}
EMA_KEYS=('m5_ema21_delta_to_side','m15_ema21_delta_to_side','m30_ema21_delta_to_side')
RSI_KEYS=('m5_rsi_center_to_side','m5_rsi_delta_to_side')
G_KEYS=('m30_ema21_delta_to_side','m30_di_difference_to_side','m15_di_difference_to_side','m15_adx')
EMA_GROUPS=('全正','全負','混在又は0','未知')
RSI_GROUPS=('持続','新規越え','非過熱','未知')
GROUPS={'EMA':EMA_GROUPS,'RSI':RSI_GROUPS,'交差':tuple(a+'/'+b for a in EMA_GROUPS for b in RSI_GROUPS)}
FIELDS={'件数':'entries','場数':'sessions','F':'forward','A':'adverse','N':'neither','C':'censored',
    '到達済率':'resolved_rate','完了分母率':'complete_rate','IFD既知':'ifd_known','IFD未知':'ifd_unknown',
    'C5利益':'ifd_net5_profit','C5損失絶対':'ifd_net5_loss','C5差引':'ifd_net5_sum','PF':'ifd_net5_pf'}


def sha(path: Path) -> str:
    """
    機能: 保存実体をbufferで全物理指紋化する。
    引数: path(Path)。返り値: str。
    """
    digest=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1<<20),b''):digest.update(block)
    return digest.hexdigest()


def module(path: Path,name: str):
    """
    機能: mainを呼ばず特徴射影又は141算術だけを読む。
    引数: path(Path)、name(str)。返り値: ModuleType。
    """
    spec=importlib.util.spec_from_file_location(name,path);out=importlib.util.module_from_spec(spec)
    sys.modules[name]=out;spec.loader.exec_module(out);return out


def number(value: int | float | None) -> float | None:
    """
    機能: None/NaNを未知へ、有限数値だけをfloatへ写す。
    引数: value(int|float|None)。返り値: float|None。bool/無限大を拒否する。
    """
    if value is None:return None
    if type(value) not in (int,float):raise ValueError('数値型不正')
    if math.isnan(value):return None
    if not math.isfinite(value):raise ValueError('非有限値')
    return float(value)


def classify(values: dict) -> dict:
    """
    機能: 金融を受け取らず元t向きEMA3値とRSI持続を固定区分へ写す。
    引数: values(dict[str,float|None])。返り値: dictは区分/前中心/Δ/各G旗。
    """
    v={key:number(values[key]) for key in set((*EMA_KEYS,*RSI_KEYS,*G_KEYS))}
    emas=[v[key] for key in EMA_KEYS]
    ema='未知' if any(x is None for x in emas) else '全正' if all(x>0 for x in emas) else '全負' if all(x<0 for x in emas) else '混在又は0'
    center,delta=(v[key] for key in RSI_KEYS)
    previous=center-delta if center is not None and delta is not None else None
    if previous is not None and not math.isfinite(previous):raise ValueError('前中心の派生overflow')
    rsi='未知' if center is None else '非過熱' if center<20 else '未知' if previous is None else '持続' if previous>=20 else '新規越え'
    flags={key:None if v[key] is None else v[key]<0 if key!=G_KEYS[-1] else v[key]>25 for key in G_KEYS}
    return {'EMA':ema,'RSI':rsi,'交差':ema+'/'+rsi,'RSI現在中心':center,'RSI前中心':previous,'RSI増分':delta,'G各条件':flags}


def distribution(values: list[float | None]) -> dict:
    """
    機能: 生RSI増分の分布を任意新binなしで記録する。
    引数: values(list[float|None])。返り値: dict。空分布はnullで残す。
    """
    data=sorted(x for x in values if x is not None)
    def quantile(p: float) -> float | None:
        """
        機能: 昇順標本へ線形補間の分位点を適用する。
        引数: p(float)。返り値: float|None。
        """
        if not data:return None
        position=(len(data)-1)*p;a=math.floor(position);b=math.ceil(position)
        return data[a]+(data[b]-data[a])*(position-a)
    return {'known':len(data),'unknown':len(values)-len(data),'最小':data[0] if data else None,
        'Q25':quantile(.25),'中央値':quantile(.5),'Q75':quantile(.75),'最大':data[-1] if data else None,
        '平均':sum(data)/len(data) if data else None,'新規越えを異常スパイクと認定':False}


def concentration(rows: list[tuple],scope: list[str]) -> dict:
    """
    機能: 全対象場を分母に残し件数最大の場と同率全場を記録する。
    引数: rows(list[tuple])、scope(list[str])。返り値: dict。
    """
    counts=Counter(sid for sid,_ in rows);maximum=max(counts.values(),default=0)
    return {'対象場数':len(scope),'取得場数':len(counts),'最大件数':maximum,
        '最大集中場':[sid for sid in scope if counts[sid]==maximum] if rows else [],
        '最大1場割合':maximum/len(rows) if rows else None,'場別件数':{sid:counts[sid] for sid in scope}}


def array(path: Path,name: str,evidence: dict):
    """
    機能: 共有大観測配列を場単位に読み全gzip CRC/解凍指紋まで完読する。
    引数: path(Path)、name(str)、evidence(dict)。返り値: Iterator[dict]。
    """
    digest=hashlib.sha256();size=0;buffer='';decoder=json.JSONDecoder()
    with gzip.open(path,'rt',encoding='utf-8',newline='') as stream:
        def more() -> str:
            """
            機能: UTF8テキストを読み元bytes指紋へ加える。
            引数: なし。返り値: str。
            """
            nonlocal size
            text=stream.read(1<<20);raw=text.encode('utf-8');digest.update(raw);size+=len(raw);return text
        while True:
            text=more();assert text,'配列なし';buffer+=text
            match=re.search(r'(?m)^  "'+re.escape(name)+r'": \[',buffer)
            if match:buffer=buffer[match.end():];break
        while True:
            buffer=buffer.lstrip()
            if buffer.startswith(']'):break
            if buffer.startswith(','):buffer=buffer[1:].lstrip()
            try:value,end=decoder.raw_decode(buffer)
            except json.JSONDecodeError:
                text=more();assert text,'配列途中終了';buffer+=text;continue
            yield value;buffer=buffer[end:]
        while more():pass
    evidence.update(decoded_sha256=digest.hexdigest(),decoded_bytes=size,gzip_full_crc_checked=True)


def stat(value: dict) -> dict:
    """
    機能: 141算術の必要統計だけを日本語の小票へ写す。
    引数: value(dict)。返り値: dict。空群利益/損失はnullを保持する。
    """
    return {key:value[field] for key,field in FIELDS.items()}


def main() -> None:
    """
    機能: 614の特徴分類を完成後に金融を読み元実逆/前後/交差と加法を保存する。
    引数: CLI --execute-after-root-notice(bool)。返り値: None。未通知なら本文I_O前拒否。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--execute-after-root-notice',action='store_true');args=parser.parse_args()
    if not args.execute_after_root_notice:parser.error('Root通知後だけ自然診断を実行する')
    output=HERE/'診断.json';assert not output.exists()
    assert sha(DATA_PATH)==DATA_SHA and sha(MATH_PATH)==MATH_SHA
    before={key:{'sha256':sha(path),'bytes':path.stat().st_size,'mtime_ns':path.stat().st_mtime_ns} for key,path in PATHS.items()}
    assert all(before[key]['sha256']==expected for key,expected in SHA.items())
    f1=json.loads(PATHS['f1'].read_bytes());f2=json.loads(PATHS['f2'].read_bytes());selection=json.loads(PATHS['selection'].read_bytes())
    rel=PATHS['selection'].relative_to(ROOT).as_posix()
    assert f1['ファイル'][rel]==f2['ファイル'][rel]==SHA['selection']
    refs=selection['政策']['B152'];sessions=selection['全73場']
    assert len(refs)==len({r['case_id'] for r in refs})==614 and len(sessions)==len(set(sessions))==73
    data=module(DATA_PATH,'data151_feature_only_background_research')
    features=data.load_feature_dataset(data.FileRef(PATHS['features'],SHA['features'],DECODED['features']),
        data.FileRef(PATHS['fixed'],SHA['fixed'],DECODED['fixed']))
    assert [scene['session'] for scene in features.scenes]==sessions
    index={name:i for i,name in enumerate(features.columns)};events={row['event_id']:i for i,row in enumerate(features.q0_meta)}
    required=set((*EMA_KEYS,*RSI_KEYS,*G_KEYS));assert required<=set(index)
    groups={};members=[]
    for ref in refs:
        i=events[ref['event_id']];meta=features.q0_meta[i]
        assert all(ref[field]==meta[field] for field in ('event_id','session','q0_time','q0_index','q0_line'))
        assert ref['feature_ref']==meta['event_id']
        assert ref['side'] in (-1,1) and type(ref['side']) is int
        vector=features.buy_X[i] if ref['side']==1 else features.sell_X[i]
        result=classify({key:vector[index[key]].item() for key in required})
        groups[ref['case_id']]=result
        members.append({'case_id':ref['case_id'],'event_id':ref['event_id'],'session':ref['session'],'contract':meta['contract'],
            'final_order_side':ref['side'],**result})
    assert len(groups)==614
    # ----------------------------------------
    # 全614の金融非依存区分が完成した後だけ保存正逆観測を読む。
    mathematics=module(MATH_PATH,'separate141_math_background_research')
    wanted={ref['case_id']:ref for ref in refs};cases=[];evidence={};scene_count=all_cases=0
    for scene in array(PATHS['observations'],'scenes',evidence):
        assert scene['success'] and scene['session']==sessions[scene_count];scene_count+=1;all_cases+=len(scene['cases'])
        for case in scene['cases']:
            if case['id'] not in wanted:continue
            ref=wanted.pop(case['id']);which=ref['stream'];other='reverse' if which=='original' else 'original'
            # 観測sceneはcontract列を持たない。固定148同体の既監査を継承し、場と当時特徴の限月を結ぶ。
            assert features.q0_meta[events[ref['event_id']]]['contract']==features.scenes[scene_count-1]['contract']
            native,inverse=case[which],case[other]
            assert native['birth']['side']==ref['side'] and inverse['birth']['side']==-ref['side']
            assert native['entry']==inverse['entry'] and ref['session']==scene['session']
            q=native['entry'];assert q['quote_ok'] and 0<q['bid']<q['ask']
            assert native['entry_price']==q['ask' if ref['side']==1 else 'bid']
            assert inverse['entry_price']==q['bid' if ref['side']==1 else 'ask']
            cases.append((scene['session'],{**case,'original':native,'reverse':inverse}))
    assert not wanted and scene_count==73 and all_cases==31642
    assert evidence['decoded_sha256']==DECODED['observations'] and len(cases)==614
    result={};checks=0;g_counts={}
    for part,scope in [('all',sessions),('train',sessions[:48]),('validation',sessions[48:])]:
        rows=[row for row in cases if row[0] in scope]
        total={name:stat(mathematics.calculate(rows,reverse,'BBO',3600,125)) for name,reverse in [('元方向',False),('実逆',True)]}
        period={'全B152':total,'最大集中':concentration(rows,scope),'分割':{}}
        for axis,labels in GROUPS.items():
            table={}
            for label in labels:
                subset=[row for row in rows if groups[row[1]['id']][axis]==label]
                table[label]={name:stat(mathematics.calculate(subset,reverse,'BBO',3600,125)) for name,reverse in [('元方向',False),('実逆',True)]}
                table[label]['最大集中']=concentration(subset,scope)
                table[label]['RSI5生増分分布']=distribution([groups[row[1]['id']]['RSI増分'] for row in subset])
            for side in ('元方向','実逆'):
                for key in ('件数','F','A','N','C','IFD既知','IFD未知'):
                    assert sum(table[label][side][key] for label in labels)==total[side][key];checks+=1
                for key in ('C5利益','C5損失絶対','C5差引'):
                    assert sum(table[label][side][key] for label in labels if table[label][side]['IFD既知'])==total[side][key];checks+=1
            period['分割'][axis]=table
        result[part]=period
        selected=[m for m in members if m['session'] in scope]
        g_counts[part]={'分母':len(selected),'各条件':{key:{'true':sum(m['G各条件'][key] is True for m in selected),
            'false':sum(m['G各条件'][key] is False for m in selected),'unknown':sum(m['G各条件'][key] is None for m in selected)} for key in G_KEYS},
            '条件間重複あり_合計を分母としない':True,'最終B152側_最初P65側とは別':True}
    # ----------------------------------------
    # 固定B152全体の元方向を金融正本へ最後に照合する。群定義には使わない。
    summary=json.loads(PATHS['summary'].read_bytes());cells=0
    for part in result:
        expected=summary['集計'][part]['B152']['BBO']['3600']['125']
        for key,field in FIELDS.items():assert result[part]['全B152']['元方向'][key]==expected[field];cells+=1
    assert before=={key:{'sha256':sha(path),'bytes':path.stat().st_size,'mtime_ns':path.stat().st_mtime_ns} for key,path in PATHS.items()}
    assert sha(DATA_PATH)==DATA_SHA and sha(MATH_PATH)==MATH_SHA
    proof={'成功':True,'区分':'固定B152背景とRSI過熱持続の事後診断','対象数':614,'全73場保持':True,
        '入力':before,'特徴射影だけ':{'path':DATA_PATH.relative_to(ROOT).as_posix(),'sha256':DATA_SHA,'教師_モデルAPI使用':False},
        '金融算術':{'path':MATH_PATH.relative_to(ROOT).as_posix(),'sha256':MATH_SHA,'124作者算術import':False},
        'コードSHA256':sha(Path(__file__)),'区分MD_SHA256':before['definition']['sha256'],
        '全区分完成後だけ金融観測読取':True,'実逆でも元最終t側区分を保持':True,
        '前後':result,'旧G最終側の非金融件数':g_counts,'614所属':members,
        '分群の加法検査数':checks,'固定B152正本比較値':cells,'観測全CRC_解凍指紋':evidence,
        '全入力前後同体':True,'新閾値_新政策_70達成認定_原因断定':False,'Raw_新CSV_追加2場読取':False,
        '初回schema停止は分類後金融集計前_観測にないcontract直接要求だけ補正':True,
        '全期既使用_近接H60依存_口座でない':True}
    with output.open('x',encoding='utf-8',newline='\n') as stream:json.dump(proof,stream,ensure_ascii=False,indent=2,allow_nan=False);stream.write('\n')
    print(json.dumps({'成功':True,'対象数':len(cases),'加法':checks,'正本値':cells,'JSON_SHA256':sha(output)},ensure_ascii=False))


if __name__=='__main__':
    main()
