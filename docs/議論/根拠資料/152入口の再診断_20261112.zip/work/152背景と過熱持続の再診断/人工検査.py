"""自然614や金融を開く前に区分境界・未知・符号・分布を人工確認する。"""
from pathlib import Path
import importlib.util
import math
import unittest

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('background_diagnostic_artificial',HERE/'診断する.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


def values() -> dict:
    """
    機能: GとRSI/EMA全既知の小型人工を返す。
    引数: なし。返り値: dict[str,float]。
    """
    return {**{key:1.0 for key in m.EMA_KEYS},**{key:-1.0 for key in m.G_KEYS[:-1]},m.G_KEYS[-1]:26.0,
        m.RSI_KEYS[0]:20.0,m.RSI_KEYS[1]:0.0}


class Tests(unittest.TestCase):
    """分類の境界を自然データと独立に確認する。"""

    def test_EMA全正全負0未知(self) -> None:
        """
        機能: 生増分3本の正負全一致/混在0/未知優先を検査する。
        引数: self(Tests)。返り値: None。
        """
        for data,label in [((1,1,1),'全正'),((-1,-1,-1),'全負'),((0,1,1),'混在又は0'),((1,-1,1),'混在又は0'),((1,None,-1),'未知')]:
            v=values();v.update(dict(zip(m.EMA_KEYS,data)));self.assertEqual(m.classify(v)['EMA'],label)

    def test_RSI等号と新規と未知(self) -> None:
        """
        機能: 過熱20等号/前中心20等号を含み非過熱に不要なΔを要求しない。
        引数: self(Tests)。返り値: None。
        """
        for center,delta,label in [(20,0,'持続'),(21,1,'持続'),(20,.1,'新規越え'),(19,None,'非過熱'),(20,None,'未知'),(None,1,'未知')]:
            v=values();v.update({m.RSI_KEYS[0]:center,m.RSI_KEYS[1]:delta});result=m.classify(v)
            self.assertEqual(result['RSI'],label)
            self.assertEqual(result['RSI前中心'],None if center is None or delta is None else center-delta)

    def test_G各条件と重複(self) -> None:
        """
        機能: Gを最終側の4条件として0/ADX25/未知を分離する。
        引数: self(Tests)。返り値: None。
        """
        v=values();self.assertTrue(all(m.classify(v)['G各条件'].values()))
        v[m.G_KEYS[0]]=0;v[m.G_KEYS[1]]=None;v[m.G_KEYS[-1]]=25
        flags=m.classify(v)['G各条件'];self.assertIs(flags[m.G_KEYS[0]],False);self.assertIsNone(flags[m.G_KEYS[1]]);self.assertIs(flags[m.G_KEYS[-1]],False)

    def test_非有限分布空場(self) -> None:
        """
        機能: NaN未知/inf拒否、分位補間、空分布/最大集中場を検査する。
        引数: self(Tests)。返り値: None。
        """
        self.assertIsNone(m.number(float('nan')))
        for value in (True,float('inf')):
            with self.assertRaises(ValueError):m.number(value)
        d=m.distribution([None,0.,2.,4.]);self.assertEqual((d['known'],d['unknown'],d['中央値'],d['Q25']),(3,1,2.,1.))
        self.assertIsNone(m.distribution([None])['平均'])
        c=m.concentration([('A',{}),('A',{}),('B',{}),('B',{})],['A','B','C'])
        self.assertEqual(c['最大集中場'],['A','B']);self.assertEqual(c['場別件数']['C'],0)


if __name__=='__main__':
    unittest.main(verbosity=2)
