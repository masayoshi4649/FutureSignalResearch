"""金融観測を読む前に、区分/純分類/人工を私有票へ固定する。"""
from pathlib import Path
import ast
import hashlib
import json
import os
import subprocess
import sys

HERE=Path(__file__).resolve().parent


def main() -> None:
    """
    機能: 自然入力なしで4人工・関数コメントを検査しSourceを固定する。
    引数: なし。返り値: None。元152/154正式/Sourceへ書き込まない。
    """
    paths=[p for p in HERE.iterdir() if p.suffix in ('.py','.md')]
    before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    for p in paths:
        if p.suffix=='.py':
            for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
                if isinstance(node,ast.FunctionDef):
                    doc=ast.get_docstring(node);assert doc and '\n' in doc and all(k in doc for k in ('機能','引数','返り値'))
    result=subprocess.run([sys.executable,'-X','utf8',str(HERE/'人工検査.py')],capture_output=True,
        env={**os.environ,'PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8','PYTHONDONTWRITEBYTECODE':'1'})
    stdout,stderr=result.stdout.decode('utf-8','strict'),result.stderr.decode('utf-8','strict')
    assert result.returncode==0 and before=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    proof={'成功':True,'区分':'金融自然読取前の純分類準備','人工数':4,'自然入力本文読取':False,
        '元正式_Source変更':False,'UTF8_strict_構文_関数コメント':True,'源':before,
        '人工':{'終了値':result.returncode,'stdout':stdout,'stderr':stderr}}
    target=HERE/'準備の確認_再確認.json';assert not target.exists()
    target.write_bytes((json.dumps(proof,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    print(hashlib.sha256(target.read_bytes()).hexdigest())


if __name__=='__main__':
    main()
