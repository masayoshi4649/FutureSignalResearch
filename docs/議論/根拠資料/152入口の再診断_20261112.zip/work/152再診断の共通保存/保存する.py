"""固定B152の3事後診断だけを共通根拠ZIPへ一度保存する。"""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
DEST=ROOT/'docs/議論/根拠資料'
NAME='152入口の再診断_20261112'
STOPS=[('取得位置',ROOT/'work/152取得位置の再診断/停止の確認.json','0524a2ca45f5b7d294b1d6ae0bf8d69147e0d2b837da938702ad09b1fbb62ef0'),
    ('勢いと価格帯',ROOT/'work/152勢いと価格帯の再診断/停止.json','2fb34640004934485ad0c900dcd86b066a1d88784284c3aeedbec7eba088b12f'),
    ('背景と過熱持続',ROOT/'work/152背景と過熱持続の再診断/停止の確認.json','2b193d8f8d616f3939dbc655a9e207cc53c356b3c0694af8a78a8cef6a30fa04')]


def sha(path: Path) -> str:
    """
    機能: 小診断源の物理指紋を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 3停止票の最小源と保存器を1ZIPへ格納し全byte再読/前後不変を検査する。
    引数: なし。返り値: None。正式152/154・大入力・Root執筆中MDを変更しない。
    """
    target=DEST/(NAME+'.zip');index_path=DEST/(NAME+'_索引.json')
    assert not target.exists() and not index_path.exists()
    files={};partitions=[]
    for label,stop_path,expected in STOPS:
        assert sha(stop_path)==expected;stop=json.loads(stop_path.read_bytes());assert stop['成功'] and stop['編集停止']
        selected={}
        if label=='取得位置':
            for info in stop['最小保存対象']:selected[ROOT/info['path']]=info['SHA256']
        elif label=='勢いと価格帯':
            selected={stop_path.parent/name:h for name,h in stop['ファイル'].items()}
        else:
            selected={stop_path.parent/name:h for name,h in stop['保存対象'].items()}
        selected[stop_path]=expected
        assert all(p.resolve().is_relative_to(stop_path.parent.resolve()) and p.stat().st_size<2_000_000 and sha(p)==h for p,h in selected.items())
        files.update(selected)
        partitions.append({'診断':label,'停止票':stop_path.relative_to(ROOT).as_posix(),'停止SHA256':expected,
            '最小源数':len(selected),'最小源':[p.relative_to(ROOT).as_posix() for p in selected]})
    files[Path(__file__).resolve()]=sha(Path(__file__))
    before={p:(sha(p),p.stat().st_size,p.stat().st_mtime_ns) for p in files}
    assert all(before[p][0]==expected for p,expected in files.items())
    watched=[next((ROOT/'study').glob(f'{number:05d}_*'))/name for number in (152,154) for name in ('README.md','条件.md','設定と結果.md')]
    formal_before={p.relative_to(ROOT).as_posix():sha(p) for p in watched}
    DEST.mkdir(parents=True,exist_ok=True);records=[]
    with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for path,expected in sorted(files.items(),key=lambda item:item[0].relative_to(ROOT).as_posix()):
            raw=path.read_bytes();assert hashlib.sha256(raw).hexdigest()==expected
            relative=path.relative_to(ROOT).as_posix();info=zipfile.ZipInfo(relative,date_time=(2026,11,12,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            archive.writestr(info,raw)
            records.append({'元path':relative,'ZIP内path':relative,'sha256':expected,'bytes':len(raw)})
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None and len(archive.namelist())==len(records)
        for record in records:
            body=archive.read(record['ZIP内path'])
            assert len(body)==record['bytes'] and hashlib.sha256(body).hexdigest()==record['sha256']
    assert before=={p:(sha(p),p.stat().st_size,p.stat().st_mtime_ns) for p in files}
    assert formal_before=={p.relative_to(ROOT).as_posix():sha(p) for p in watched}
    permanent=ROOT/'study/00154_回帰で進行と往復を分けて短期回復から入る/保管索引.json'
    formal_index=json.loads(permanent.read_bytes())
    selection=next(r for r in formal_index['154新生成3JSONを各1gzip保存'] if r['保存元'].endswith('/選択対応.json.gz'))
    index={'成功':True,'編集停止':True,'対象':'固定154selection.政策.B152全614、旧152B0同体の事後再診断3本',
        '方向':'B152の最終注文sideで元tの群を固定。同q1実逆でもbinを付け替えない。最初P65側Gと区別。',
        '金融算術':'3診断とも固定141.calculateで実Ask/Bid正逆を再計算。124作者算術やモデルの効果と混同しない。',
        '全期既使用':True,'少数群_前期限定_後4場集中':True,
        '新閾値_新切替_新政策_70達成認定':False,'利益保護又は実口座評価':False,
        '分割':partitions,'ZIP':{'path':target.relative_to(ROOT).as_posix(),'sha256':sha(target),'bytes':target.stat().st_size,
            '格納数':len(records),'全格納bytes再読_SHA_CRC一致':True},'格納源':records,
        '全小源前後SHA_stat同体':True,'152154正式3MD前後同体':formal_before,
        '巨大100X_観測_原板_追加2場の新複写又は再解析':False,
        '共有参照':[
            {'path':selection['保存元'],'sha256':selection['保存SHA256'],'decoded_sha256':selection['解凍SHA256']},
            {'path':'inputs/00148_全1分入口母集団/当時特徴.json.gz','sha256':'464dad9dce7acb20f043c344e96c9fa6d19ab0049a9d557e6fc96f6d189abcb7','decoded_sha256':'572705d7db8529555c876eb1953f7d8e1cd1de0e554bf9de729a7d377e4d91af'},
            {'path':'study/00148_全1分知得から入口品質の母集団を固定する/成果物/固定取得の正逆観測.json.gz','sha256':'bd809bdf24400628817afee702063504c65682e6748a60e0f32d7690b7363c61','decoded_sha256':'d1b4cab8a258203f04b5c1d081f57d10ed2a0c58ce4cc160ef571d5fac0ceffc'},
            {'path':'inputs/00153_先行高安の独立出生/先行高安の入力.json.gz','sha256':'2c020fed5b336ed0b417d8e72a07c6336ea475b09b9a2ff37f26ec4ce4d56bf8','decoded_sha256':'8e145275dda385e4c2f87500978716654d10efb0903a4011f2bcc304a7906b14'},
            {'path':'work/151過去場判別/data151.py','sha256':'3b92ff77a28bf82e6cf8e5dc504cc5586f4101c1e28d0bc12b29bc7cd0efdd8c','役割':'特徴射影のみ、教師/モデルAPI未使用'},
            {'path':'work/141金融集計を独立に確認する.py','sha256':'30bd4aef8c2809699cb013f930cfbce152f3986fe8d3d3cc6b49452104c2269e','役割':'独立別算術'},
            {'path':permanent.relative_to(ROOT).as_posix(),'sha256':sha(permanent),'役割':'154恒久選択と小源の既保存索引'}],
        '共有大入力は宣言指紋の参照のみ_本保存で再読計算なし':True,
        '初回schema検査停止は背景持続の小履歴ZIPへ分離':True,
        '復元':'ZIP内元相対work pathへ不足源だけ復元し、既存不一致を上書きしない。共有入力の指紋は各診断Sourceが検査する。',
        'Root執筆中の共通知見本文の編集':False,'保存器SHA256':sha(Path(__file__))}
    index_path.write_bytes((json.dumps(index,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    proof={'成功':True,'ZIP_SHA256':sha(target),'索引SHA256':sha(index_path),'源数':len(records),
        '3停止票SHA前後同体':{p.relative_to(ROOT).as_posix():h for _,p,h in STOPS},'全格納byte再読一致':True,
        '全小源前後不変':True,'152154正式不変更':True}
    out=HERE/'保存の確認.json';assert not out.exists();out.write_bytes((json.dumps(proof,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':
    main()
