"""自然再解析をせず停止集計だけから可用性短報と最終指紋を作る。"""
from pathlib import Path
from collections import Counter
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
RESULT_SHA = '51f44b40e7bbc7239ea10201eb0549fbef0a8c7532c16dfa92f78495283d6e30'


def fp(path: Path) -> dict:
    """
    機能: 小成果の物理指紋を保存する。
    引数: path(Path)。返り値: dict。
    """
    raw = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def cell(value: dict) -> str:
    """
    機能: 根拠の件数と率を短報表へ整形する。
    引数: value(dict)。返り値: str。
    """
    return f"{value['count']:,}（{value['rate']:.2%}）"


def main() -> None:
    """
    機能: 固定集計だけを読み、数値を転記せず短報を生成して停止する。
    引数: なし。返り値: None。147/148自然本文を再解析しない。
    """
    result_path = HERE / '可用性の集計.json'; assert fp(result_path)['sha256'] == RESULT_SHA
    data = json.loads(result_path.read_bytes()); table = []
    for name, label in [('all_q0', '全q0'), ('eligible_q0', '適格q0')]:
        scope = data['分母別'][name]
        for window in ('15', '30', '60'):
            flags = scope['windows'][window]
            table.append(f"|{label} {scope['denominator']:,}|{window}分|{cell(flags['grid_full'])}|{cell(flags['price_usable'])}|{cell(flags['joint_usable'])}|")
    bars = Counter()
    for scene in data['場別']: bars.update(scene['bar_flags'])
    first_unknown = data['初回VolumeUnknown']['count']
    ever = sum(s['scopes']['all_q0']['start_fixed_prefix']['vwap_finite_value_possible']['count'] > 0 for s in data['場別'])
    always = sum(s['scopes']['all_q0']['start_fixed_prefix']['vwap_finite_value_possible']['count'] == s['scopes']['all_q0']['denominator'] for s in data['場別'])
    all_prefix = data['分母別']['all_q0']['start_fixed_prefix']; eligible_prefix = data['分母別']['eligible_q0']['start_fixed_prefix']
    text = '''# 長い高安窓と当場Start固定足VWAPの可用性

2026-11-12。入力整備の非金融調査。新手法・新X・新モデル・152採番は行っていない。指定147 Source gzipと148出生台帳gzipだけを、人工3群/条件固定後に自然解析1回。Raw・新CSV・追加2場・金融・151出力は読んでいない。

**長い高安窓の情報は一定数利用できるが、完全高安や取引の優位を意味しない。当場Start固定足VWAPは全滅ではなく、初回の量未知により使えない場が多い。未知を飛ばす/アンカーをずらす救済はしていない。**

## 分母と当時履歴

全73場・43,124配送bar・40,544q0、うち適格35,339q0を全て残した。40,544件で同Raw全配送後の最新ID/直近4slotを照合し、43,124本の今回配送refsが一致。各barのEnd/AvailableAt/Stamp time/index/lineが当時q0を越えないことを確認した。

窓端Eは最新slot.End、範囲は厳密に[E−15/30/60分,E)。rを含む通常窓で、q0からの直近窓やrを除いた突破比較窓ではない。最新未知から古いknownへのfallback、欠測を詰めた本数補完はしない。

## 窓の可用件数

各率は左の分母。格子完備はMissing placeholderの存在を含み、価格可用は全足closed/price_known/非Missing、共同可用はそれに全足volume_knownを加えたもの。

|分母|範囲|全格子あり|価格可用|価格・量の共同可用|
|---|---|---:|---:|---:|
''' + '\n'.join(table) + f'''

共同可用の窓は今回すべて全足正量だった。既知量0は自然barで{bars['known_zero_volume']:,}本なので、自然件数ではstrict jointと加重寄与knownの差は出なかったが、価格未知×既知0量の人工は別に検査した。全格子・closed・各known・全足正量・合計正量を[集計JSON](可用性の集計.json)では別maskとして残す。

## 当場Start固定の足VWAP近似

全73場とも最初の配送slotはclosed/price_knownだった。初回volume_unknownは{first_unknown}/73場（{first_unknown/73:.2%}）。この47場では以後もStart-prefixの量が未知で、Start固定の完全値を計算しない。

HLC3×既知量/ΣVが有限に計算できるq0は、全q0で{cell(all_prefix['vwap_finite_value_possible'])} / 40,544、適格q0で{cell(eligible_prefix['vwap_finite_value_possible'])} / 35,339。一度以上可用なのは{ever}/73場、全q0で常に可用なのは{always}/73場だった。残りは初回又は途中の欠測/量未知を保持した。**Start+60への変更、途中の正常区間への再anchor、未知量を0とする補完は未採用・未実行。**

Start-prefix価格可用は全q0で{cell(all_prefix['price_usable'])}、適格q0で{cell(eligible_prefix['price_usable'])}。後の欠測が窓外へ出ればrollingは回復できる一方、固定prefixは回復しない。

## 観測と解釈の境界

全barの価格可用は{bars['price_usable']:,}/43,124、量/共同可用は{bars['volume_usable']:,}/43,124、Missing placeholderは{bars['missing']:,}本、量unknownは{bars['volume_unknown']:,}本だった。同Raw catch-upの最後だけをq0とするため、bar単位とq0単位の欠測数は同じでない。SourceのEOF未配送末尾を現在履歴へ加えていない。

この足VWAPは1分のHLC3近似で、約定ごとの真VWAP・提供VWAP・全参加者の平均建値ではない。完備flagも取引所/WSの全約定網羅を認定しない。観測高安は真の高安と区別する。可用率が高いことを入口の先着70%又は平均1/hの達成に読み替えず、欠測窓を落として良い群の成績を作っていない。

## 根拠と再現

[事前条件](集計条件.md)、[最小人工](最小人工.py)、[集計コード](可用性を数える.py)、[集計正本](可用性の集計.json)。自然開始には人工票SHAを必須とし、指定2入力の物理/解凍SHA・全gzip CRC・前後SHA/statが一致した後にだけ保存した。窓/量/anchorの定義を結果で変えていない。

自然解析の正本は既に停止している。短報の再生成は `python 短報を保存する.py` で集計正本だけから行えるが、自然集計器は既存正本へ上書きせず、再解析をここでは行わない。
'''
    memo = HERE / '短報.md'; memo.write_text(text, encoding='utf-8')
    names = ['集計条件.md', '可用性を数える.py', '最小人工.py', '人工のログ.txt', '人工の確認.json',
             '可用性の集計.json', '短報を保存する.py', '短報.md']
    proof = {'成功': True, '編集停止': True, '自然解析回数': 1, '最小人工主群': 3,
             '全73場/43124bar/40544q0/eligible35339': True, 'Start固定は全滅ではない': True,
             '新anchor/Source/新X/モデル/152採番/金融/Raw/CSV/151出力/追加2場': False,
             'Root指定2gzipのみ': True, '停止対象': [fp(HERE / name) for name in names]}
    stop = HERE / '停止の確認.json'; stop.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '短報SHA256': fp(memo)['sha256'], '停止SHA256': fp(stop)['sha256']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
