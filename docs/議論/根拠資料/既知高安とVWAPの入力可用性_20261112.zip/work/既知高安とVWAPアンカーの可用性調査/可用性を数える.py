"""許可済み147/148の2gzipから、窓/固定Startの情報可用性だけを数える。"""
from pathlib import Path
from collections import Counter, defaultdict
import argparse
import gzip
import hashlib
import json
import math
import re

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
INPUTS = {
    'parent147': (ROOT / 'inputs/00147_中位価格位置と実体回復/Sourceの出生と取得.json.gz',
                  'b99c49f06fe7e2306e59733b1cff26e3bb351f64edee220c98bc30b62c016d77',
                  'd42d25ec0fe41e8358c1227fd71b4377ffa90c96a8cf582f1ee4537ebf455d63'),
    'ledger148': (ROOT / 'inputs/00148_全1分入口母集団/出生台帳.json.gz',
                  '9d589488bca8e83be3fd23ed230b6f7cae176acbbe96dd2d04a62d3bbfb6e753',
                  '4f4d3ce3a652170d5d5f15941b591493592d5816bb0985c2e70c86b14323b219')}
MASKS = ('grid_full', 'no_missing', 'all_closed', 'all_price_known', 'all_volume_known',
         'price_usable', 'volume_usable', 'joint_usable', 'all_positive_volume',
         'positive_total_volume_known', 'contribution_prefix_complete', 'vwap_finite_value_possible')


def fingerprint(path: Path) -> dict:
    """
    機能: 指定入力の全物理SHA/statを検査する。
    引数: path(Path)。返り値: dict。
    """
    old = path.stat(); digest = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(4 << 20), b''): digest.update(chunk)
    now = path.stat(); assert (old.st_size, old.st_mtime_ns) == (now.st_size, now.st_mtime_ns)
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': old.st_size,
            'mtime_ns': old.st_mtime_ns, 'sha256': digest.hexdigest()}


def array_items(path: Path, name: str, evidence: dict):
    """
    機能: gzipのtop配列を一要素ずつ読み、終端までの解凍SHA/CRCを検査する。
    引数: path(Path)、name(str)、evidence(dict)は完読後の解凍指紋を受ける。
    返り値: Iterator[dict]。配列末尾後も全gzipを読み切り、途中成功にしない。
    """
    h = hashlib.sha256(); count = 0; decoder = json.JSONDecoder(); buffer = ''
    marker = re.compile(r'(?m)^  "' + re.escape(name) + r'": \[')
    with gzip.open(path, 'rt', encoding='utf-8', newline='') as source:
        def more() -> str:
            """
            機能: UTF-8文字境界を保ったまま元解凍bytesを指紋へ加える。
            引数: なし。返り値: str。
            """
            nonlocal count
            chunk = source.read(1 << 20); raw = chunk.encode('utf-8'); count += len(raw); h.update(raw)
            return chunk
        while True:
            chunk = more(); assert chunk, 'top配列なし'
            buffer += chunk; found = marker.search(buffer)
            if found: buffer = buffer[found.end():]; break
        while True:
            buffer = buffer.lstrip()
            if buffer.startswith(']'): break
            if buffer.startswith(','): buffer = buffer[1:].lstrip()
            try: value, end = decoder.raw_decode(buffer)
            except json.JSONDecodeError:
                chunk = more(); assert chunk, '配列途中で終了'; buffer += chunk; continue
            yield value
            buffer = buffer[end:]
        while more(): pass
    evidence.update({'decoded_sha256': h.hexdigest(), 'decoded_bytes': count, 'full_gzip_crc_checked': True})


def stamp(value: dict) -> tuple:
    """
    機能: Source Stamp又はQuoteの時刻/index/物理行を取り出す。
    引数: value(dict)。返り値: tuple[float,int,int]。
    """
    return value['time'], value['index'], value['line' if 'line' in value else 'source_line']


def slot_ref(bar: dict) -> dict:
    """
    機能: 148に保存された当時slot refを147足から再構成する。
    引数: bar(dict)。返り値: dict。
    """
    return {k: bar[k] for k in ('id', 'start', 'end', 'available_at', 'stamp', 'price_known', 'volume_known', 'closed')}


def usable(bar: dict) -> tuple:
    """
    機能: Missing/closed/価格/量を別々にし、既知V0の寄与を区別する。
    引数: bar(dict)。返り値: tuple[bool,bool,bool]は価格/量/加重寄与の可用性。
    """
    closed = bar['closed'] and not bar['missing']
    price = closed and bar['price_known']; volume = closed and bar['volume_known']
    contribution = volume and (bar['volume'] == 0 or price)
    return price, volume, contribution


def masks(bars: list[dict], start: float, end: float, expected: int) -> dict:
    """
    機能: 実時間格子の情報maskとStart固定足近似の計算可能性だけを返す。
    引数: bars(list[dict])、start/end(float)、expected(int)。返り値: dict[str,bool]。
    """
    grid = len(bars) == expected and expected > 0 and all(b['start'] == start + i * 60 and b['end'] == start + (i + 1) * 60 for i, b in enumerate(bars)) and end == start + expected * 60
    closed = grid and all(b['closed'] for b in bars)
    price = grid and all(usable(b)[0] for b in bars)
    volume = grid and all(usable(b)[1] for b in bars)
    contribution = grid and all(usable(b)[2] for b in bars)
    positive = False; finite_value = False
    if volume:
        total_volume = math.fsum(b['volume'] for b in bars)
        positive = math.isfinite(total_volume) and total_volume > 0
        if contribution and positive:
            try:
                products = [0. if b['volume'] == 0 else ((b['ohlc']['high'] + b['ohlc']['low'] + b['ohlc']['close']) / 3) * b['volume'] for b in bars]
                finite_value = all(math.isfinite(x) for x in products) and math.isfinite(math.fsum(products) / total_volume)
            except OverflowError: finite_value = False
    return {'grid_full': grid, 'no_missing': grid and not any(b['missing'] for b in bars),
            'all_closed': closed, 'all_price_known': grid and all(b['price_known'] for b in bars),
            'all_volume_known': grid and all(b['volume_known'] for b in bars),
            'price_usable': price, 'volume_usable': volume, 'joint_usable': price and volume,
            'all_positive_volume': volume and all(b['volume'] > 0 for b in bars),
            'positive_total_volume_known': positive, 'contribution_prefix_complete': contribution,
            'vwap_finite_value_possible': finite_value}


def new_scope() -> dict:
    """
    機能: 全q0又は適格q0の分母付き集計器を作る。
    引数: なし。返り値: dict。
    """
    return {'denominator': 0, 'windows': {str(n): Counter() for n in (15, 30, 60)},
            'start_fixed_prefix': Counter(), 'latest': Counter()}


def add_sample(scope: dict, windows: dict, prefix: dict, latest: dict) -> None:
    """
    機能: 指定分母だけに情報maskを加算する。
    引数: scope/windows/prefix/latest(dict)。返り値: None。
    """
    scope['denominator'] += 1
    for name, flags in windows.items():
        for key, yes in flags.items(): scope['windows'][name][key] += int(yes)
    for key, yes in prefix.items(): scope['start_fixed_prefix'][key] += int(yes)
    for key, yes in latest.items(): scope['latest'][key] += int(yes)


def inspect_scene(scene: dict, ledger: list[dict]) -> dict:
    """
    機能: 同Raw全配送後の履歴/refsを照合し、当場q0の各窓を計数する。
    引数: scene(dict)は147一場、ledger(list[dict])は148同場全q0。返り値: dict。
    """
    assert scene['success']; bars = scene['bars']; start = scene['start']
    assert bars and ledger
    for i, known in enumerate(bars):
        b = known['bar']; q = known['context']['at']; t, index, line = stamp(b['stamp'])
        assert b['session'] == scene['session'] and b['contract'] == scene['contract'] and b['width_seconds'] == 60
        assert b['start'] == start + i * 60 and b['end'] == b['start'] + 60 and b['end'] <= scene['end'] - 300
        assert b['available_at'] == b['end'] + 60 <= t and stamp(q) == (t, index, line)
        if i: assert all(a <= z for a, z in zip(stamp(bars[i - 1]['bar']['stamp']), (t, index, line)))
        if b['price_known']:
            o = b['ohlc']; assert all(math.isfinite(x) for x in o.values()) and o['low'] > 0 and o['low'] <= o['open'] <= o['high'] and o['low'] <= o['close'] <= o['high']
        if b['volume_known']: assert math.isfinite(b['volume']) and b['volume'] >= 0
    scopes = {'all_q0': new_scope(), 'eligible_q0': new_scope()}
    history = []; cursor = 0; checks = Counter(); previous = None
    for row in ledger:
        q = row['q0']; qstamp = stamp(q)
        assert row['session'] == scene['session'] and row['contract'] == scene['contract']
        if previous: assert qstamp[1:] > previous[1:] and qstamp[0] >= previous[0]
        previous = qstamp; batch = []
        while cursor < len(bars) and stamp(bars[cursor]['bar']['stamp'])[1] <= qstamp[1]:
            known = bars[cursor]; b = known['bar']
            assert stamp(b['stamp']) == qstamp and known['context']['at'] == q
            batch.append(b); history.append(b); cursor += 1
        assert batch and slot_ref(history[-1]) == row['latest_bar_ref']
        assert [slot_ref(b) for b in history[-4:]] == row['slot_refs']
        assert [slot_ref(b) for b in batch] == row['delivered_bar_refs']
        checks['q0_full_batch_latest_and_last4'] += 1; checks['delivered_ref_matches'] += len(batch)
        latest = history[-1]; end = latest['end']
        for b in history[-60:]:
            assert b['end'] <= b['available_at'] <= stamp(b['stamp'])[0] <= qstamp[0]
            assert stamp(b['stamp'])[1] <= qstamp[1] and stamp(b['stamp'])[2] <= qstamp[2]
        expected_eligible = latest['price_known'] and latest['closed'] and q['time'] < end + 120 and q['time'] < min(scene['force_close'], scene['end'] - 3900)
        assert row['eligible'] == expected_eligible
        window = {str(n): masks(history[-n:], end - n * 60, end, n) for n in (15, 30, 60)}
        prefix = masks(history, start, end, len(history))
        flags = {'price_unknown': not latest['price_known'], 'volume_unknown': not latest['volume_known'],
                 'not_closed': not latest['closed'], 'missing': latest['missing'],
                 'stale_120': q['time'] >= end + 120, 'same_raw_catchup': len(batch) > 1}
        add_sample(scopes['all_q0'], window, prefix, flags)
        if row['eligible']: add_sample(scopes['eligible_q0'], window, prefix, flags)
    assert cursor == len(bars)
    first = bars[0]['bar']
    all_bars = Counter()
    for known in bars:
        b = known['bar']
        for key, value in [('price_usable', usable(b)[0]), ('volume_usable', usable(b)[1]),
                           ('joint_usable', usable(b)[0] and usable(b)[1]), ('volume_unknown', not b['volume_known']),
                           ('known_zero_volume', b['volume_known'] and b['volume'] == 0), ('missing', b['missing'])]: all_bars[key] += int(value)
    return {'session': scene['session'], 'contract': scene['contract'], 'bars': len(bars), 'bar_flags': all_bars,
            'first_slot': {key: first[key] for key in ('missing', 'closed', 'price_known', 'volume_known')},
            'checks': checks, 'scopes': scopes}


def finish_scope(scope: dict) -> dict:
    """
    機能: 集計分母を保持してcount/rateを併記する。
    引数: scope(dict)。返り値: dict。
    """
    n = scope['denominator']
    def rates(counter: dict, keys: tuple = ()) -> dict:
        """
        機能: 全maskを0件も含めてcount/rateへ変換する。
        引数: counter(dict)、keys(tuple)は0件でも保持する列。返り値: dict。
        """
        return {key: {'count': counter.get(key, 0), 'rate': counter.get(key, 0) / n if n else None} for key in (keys or tuple(counter))}
    return {'denominator': n, 'windows': {key: rates(value, MASKS) for key, value in scope['windows'].items()},
            'start_fixed_prefix': rates(scope['start_fixed_prefix'], MASKS),
            'latest': rates(scope['latest'], ('price_unknown', 'volume_unknown', 'not_closed', 'missing', 'stale_120', 'same_raw_catchup'))}


def main() -> None:
    """
    機能: 最小人工停止票を要求し、指定2gzipの自然本文を一度だけ解析する。
    引数: CLI --人工SHA256(str)。返り値: None。新X/モデル/採番/金融を作らない。
    """
    parser = argparse.ArgumentParser(); parser.add_argument('--人工SHA256', required=True); args = parser.parse_args()
    test_path = HERE / '人工の確認.json'; assert fingerprint(test_path)['sha256'] == args.人工SHA256
    test = json.loads(test_path.read_bytes())
    assert test['成功'] and test['集計SourceSHA256'] == fingerprint(Path(__file__))['sha256']
    output = HERE / '可用性の集計.json'; assert not output.exists()
    before = {key: fingerprint(path) for key, (path, _, _) in INPUTS.items()}
    assert all(before[k]['sha256'] == value[1] for k, value in INPUTS.items())
    ledger_path = INPUTS['ledger148'][0]
    with gzip.open(ledger_path, 'rb') as source: body = source.read()
    assert hashlib.sha256(body).hexdigest() == INPUTS['ledger148'][2]
    ledger = json.loads(body); del body
    assert ledger['success'] and ledger['trial'] == 148 and not ledger['financial_labels_used']
    grouped = defaultdict(list)
    for row in ledger['rows']: grouped[row['session']].append(row)
    assert len(ledger['rows']) == 40544 and sum(r['eligible'] for r in ledger['rows']) == 35339 and len(grouped) == 73
    totals = {'all_q0': new_scope(), 'eligible_q0': new_scope()}; reports = []; decoded = {}
    for scene in array_items(INPUTS['parent147'][0], 'scenes', decoded):
        assert scene['session'] in grouped
        report = inspect_scene(scene, grouped.pop(scene['session'])); reports.append(report)
        for scope_name, value in report['scopes'].items():
            total = totals[scope_name]; total['denominator'] += value['denominator']
            for name in total['windows']: total['windows'][name].update(value['windows'][name])
            total['start_fixed_prefix'].update(value['start_fixed_prefix']); total['latest'].update(value['latest'])
        if len(reports) % 20 == 0: print(json.dumps({'非金融進捗場数': len(reports)}, ensure_ascii=False), flush=True)
    assert decoded['decoded_sha256'] == INPUTS['parent147'][2]
    assert not grouped and len(reports) == 73 and sum(r['bars'] for r in reports) == 43124
    assert totals['all_q0']['denominator'] == 40544 and totals['eligible_q0']['denominator'] == 35339
    assert before == {key: fingerprint(path) for key, (path, _, _) in INPUTS.items()}
    first = Counter()
    for report in reports:
        for key, value in report['first_slot'].items(): first[key] += int(value)
    for report in reports: report['scopes'] = {key: finish_scope(value) for key, value in report['scopes'].items()}
    result = {'成功': True, '目的': '高安/足近似VWAPの入力可用性のみ。新手法採用/152採番ではない。',
              '全場': 73, '全bar': 43124, '全q0': 40544, 'eligible_q0': 35339,
              '窓端': '最新配送slot.End=E、[E−15/30/60分,E)。rを含む通常窓。q0直近窓やr除外比較でない。',
              '全配送後の最新ID/4slot/EndAvailableStamp非未来全件一致': True,
              '分母別': {key: finish_scope(value) for key, value in totals.items()},
              '初回slotの場数': dict(first), '場別': reports,
              '初回VolumeUnknown': {'count': 73 - first['volume_known'], 'rate': (73 - first['volume_known']) / 73},
              'VWAP定義': '当場Start固定HLC3×既知量/ΣV。strict jointとV0寄与既知を区別。途中未知prefixは回復/再anchorしない。',
              '価格値/新X/モデル/閾値採用/金融/Raw/CSV/151出力/追加2場': False,
              '入力': before, 'Source147解凍': decoded,
              'ledger148解凍SHA256': INPUTS['ledger148'][2], '両gzip全CRC確認': True,
              '作者人工SHA256': args.人工SHA256, '集計SourceSHA256': fingerprint(Path(__file__))['sha256']}
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '場': 73, 'bar': 43124, 'q0': 40544, '集計SHA256': fingerprint(output)['sha256']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
