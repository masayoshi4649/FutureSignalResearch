"""自然本文を読む前に、窓端・未知・同Raw履歴照合を小人工で固定する。"""
from pathlib import Path
import copy
import hashlib
import importlib.util
import io
import json
import unittest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('可用性調査対象', HERE / '可用性を数える.py')
module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)


def bar(index: int, **updates) -> dict:
    """
    機能: 正確60秒格子の人工価格/量メタデータを作る。
    引数: index(int)、updates(dict)。返り値: dict。
    """
    result = {'id': f'b{index}', 'session': '人工', 'contract': '人工限月', 'width_seconds': 60,
              'start': index * 60, 'end': (index + 1) * 60, 'available_at': (index + 2) * 60,
              'stamp': {'time': (index + 2) * 60 + 10, 'index': index, 'line': index + 1},
              'ohlc': {'open': 100, 'high': 110, 'low': 90, 'close': 100}, 'volume': 1,
              'price_known': True, 'volume_known': True, 'closed': True, 'missing': False}
    result.update(updates)
    return result


class AvailabilityTests(unittest.TestCase):
    """最小3主群。自然147/148・価格CSV・金融を読まない。"""

    def test_01_exact_window_gap_unknown_and_recovery(self) -> None:
        """
        機能: [E−900,E)の15slot、欠分非圧縮、最新未知とrolling/prefix差を確認する。
        引数: self(AvailabilityTests)。返り値: None。
        """
        history = [bar(i) for i in range(30)]
        self.assertTrue(module.masks(history[:15], 0, 900, 15)['price_usable'])
        self.assertFalse(module.masks(history[:14], -60, 840, 15)['grid_full'])
        hole = history[:7] + history[8:15]
        self.assertFalse(module.masks(hole, 0, 900, 15)['grid_full'])
        history[14]['price_known'] = False
        self.assertFalse(module.masks(history[:15], 0, 900, 15)['price_usable'])
        self.assertFalse(module.masks(history[1:16], 60, 960, 15)['price_usable'])
        self.assertTrue(module.masks(history[15:], 900, 1800, 15)['price_usable'])
        self.assertFalse(module.masks(history, 0, 1800, 30)['price_usable'])

    def test_02_volume_unknown_zero_and_fixed_prefix(self) -> None:
        """
        機能: 未知量を0へ補わず、既知V0×価格未知の数学的寄与を区別する。
        引数: self(AvailabilityTests)。返り値: None。
        """
        history = [bar(0, price_known=False, volume=0), bar(1, volume=2)]
        flags = module.masks(history, 0, 120, 2)
        self.assertFalse(flags['joint_usable']); self.assertTrue(flags['contribution_prefix_complete'])
        self.assertTrue(flags['vwap_finite_value_possible'])
        history[0]['volume_known'] = False
        flags = module.masks(history, 0, 120, 2)
        self.assertFalse(flags['contribution_prefix_complete']); self.assertFalse(flags['vwap_finite_value_possible'])
        history += [bar(2)]
        self.assertFalse(module.masks(history, 0, 180, 3)['vwap_finite_value_possible'])
        zeros = [bar(0, volume=0), bar(1, volume=0)]
        self.assertTrue(module.masks(zeros, 0, 120, 2)['contribution_prefix_complete'])
        self.assertFalse(module.masks(zeros, 0, 120, 2)['vwap_finite_value_possible'])

    def test_03_batch_latest_last4_and_future_rejection(self) -> None:
        """
        機能: 同Raw catch-up全反映・最新未知非fallback・未来配送/旧ref不一致を拒否する。
        引数: self(AvailabilityTests)。返り値: None。
        """
        b = [bar(i) for i in range(3)]
        b[1]['stamp'] = b[2]['stamp'] = {'time': 250, 'index': 10, 'line': 11}
        b[2]['price_known'] = False
        known = [{'bar': x, 'context': {'at': {'time': x['stamp']['time'], 'index': x['stamp']['index'], 'source_line': x['stamp']['line']}}} for x in b]
        scene = {'success': True, 'session': '人工', 'contract': '人工限月', 'start': 0, 'end': 7200, 'force_close': 5000, 'bars': known}
        ledger = []
        for indices in ([0], [1, 2]):
            last = indices[-1]; history = b[:last + 1]
            ledger.append({'event_id': str(last), 'session': '人工', 'contract': '人工限月', 'q0': known[last]['context']['at'],
                           'latest_bar_ref': module.slot_ref(history[-1]), 'slot_refs': [module.slot_ref(x) for x in history[-4:]],
                           'delivered_bar_refs': [module.slot_ref(b[i]) for i in indices], 'eligible': last == 0})
        result = module.inspect_scene(scene, ledger)
        self.assertEqual(result['scopes']['all_q0']['denominator'], 2)
        self.assertEqual(result['scopes']['eligible_q0']['denominator'], 1)
        self.assertEqual(result['checks']['delivered_ref_matches'], 3)
        old_ref = copy.deepcopy(ledger); old_ref[1]['latest_bar_ref'] = module.slot_ref(b[1])
        with self.assertRaises(AssertionError): module.inspect_scene(scene, old_ref)
        future = copy.deepcopy(scene); future['bars'][2]['bar']['stamp']['time'] = 300
        with self.assertRaises(AssertionError): module.inspect_scene(future, ledger)


def main() -> None:
    """
    機能: 最小人工を先に成功させ自然開始用の指紋票を保存する。
    引数: なし。返り値: None。自然本文/新アンカー/新Xは作らない。
    """
    log = io.StringIO()
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(AvailabilityTests))
    log_path = HERE / '人工のログ.txt'; log_path.write_text(log.getvalue(), encoding='utf-8')
    assert result.wasSuccessful(), log.getvalue()
    proof = {'成功': True, '自然実行前の最小人工': result.testsRun, '窓': '[最新E−900/1800/3600,E)、rを含む',
             '未知/欠測非圧縮/古い良い足fallbackなし': True, '未知固定prefix非回復': True,
             '既知0量の寄与と未知量を区別': True, '新アンカー/金融/自然入力読取': False,
             '集計SourceSHA256': hashlib.sha256((HERE / '可用性を数える.py').read_bytes()).hexdigest(),
             '人工SourceSHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             'ログSHA256': hashlib.sha256(log_path.read_bytes()).hexdigest()}
    output = HERE / '人工の確認.json'; output.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '人工': result.testsRun, '人工SHA256': hashlib.sha256(output.read_bytes()).hexdigest()}, ensure_ascii=False))


if __name__ == '__main__':
    main()
