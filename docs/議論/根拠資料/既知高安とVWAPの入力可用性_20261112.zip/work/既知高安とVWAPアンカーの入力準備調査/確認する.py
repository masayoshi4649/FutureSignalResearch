"""コード/schema限定の未採用入力調査を指紋化し、自然未実行で停止する。"""
from pathlib import Path
import hashlib
import json

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
SOURCE=ROOT/'inputs/00147_中位価格位置と実体回復/Sourceの出生と取得.json.gz'


def sha(path: Path) -> str:
    """
    機能: 指定ファイルの物理bytesだけを指紋化する。
    引数: path(Path)。返り値: str。
    """
    digest=hashlib.sha256()
    with path.open('rb')as source:
        for block in iter(lambda:source.read(1<<20),b''):digest.update(block)
    return digest.hexdigest()


def main() -> None:
    """
    機能: 読取根拠と共有gzip参照を保存し、新計算なしで停止票を作る。
    引数: なし。返り値: None。
    """
    paths=[ROOT/'work/147中位位置からの実体回復'/name for name in ('types.go','csv.go','scanner.go','short.go','pattern.go','publications.go','go.mod')]
    paths += [ROOT/'work/148全1分知得の入口母集団'/name for name in ('types.go','parent_stream.go','input.go','population.go','publications.go','generate.go','go.mod')]
    paths += [ROOT/'work/118複数技法の入口条件/bank.go',ROOT/'docs/データと閲覧形式.md',ROOT/'docs/technical-analysis/指標/VWAP.md',ROOT/'docs/technical-analysis/指標/出来高加重移動平均線.md',ROOT/'docs/議論/配信元VWAPとセッション起算を確認する.md']
    before={p:sha(p)for p in paths};before_stat={str(p):[p.stat().st_size,p.stat().st_mtime_ns]for p in [*paths,SOURCE]};assert sha(SOURCE)=='b99c49f06fe7e2306e59733b1cff26e3bb351f64edee220c98bc30b62c016d77'and SOURCE.stat().st_size==10401387
    proof={'成功':True,'状態':'コード/schema/docs限定の未採用入力準備調査を停止','自然147stream実行':False,'自然Source本文解釈':False,'自然Raw又は新CSV':False,'追加2場':False,'金融ラベル又は新モデル':False,'新X生成':False,'新採番':False,'rolling15_30_60可用率':'未計数','旧offline率のonline転用':False,'原Source変更':False,
        '共有参照':{'path':str(SOURCE.relative_to(ROOT)).replace('\\','/'),'物理bytes':SOURCE.stat().st_size,'物理SHA256':sha(SOURCE),'宣言解凍SHA256':'d42d25ec0fe41e8358c1227fd71b4377ffa90c96a8cf582f1ee4537ebf455d63','今回解凍又はCRC再検査':False},
        '読取根拠源':[{'path':str(p.relative_to(ROOT)).replace('\\','/'),'sha256':h,'bytes':p.stat().st_size}for p,h in before.items()],
        '調査メモSHA256':sha(HERE/'調査メモ.md'),'確認コードSHA256':sha(Path(__file__)),'必要reader':'148 ReadParent(ParentRef,func(json.RawMessage)error)。全SHA/CRC/stat成功後だけ正式success。今回は実行していない。',
        '最小実装案':'別構造trackerで最大61slot/当場prefix/観測segmentを保持。At(q0)へbar.End/AvailableAt/Stampを検査し、r突破参照はr除外。118Bank不変更。',
        '主な限界':['閉鎖足Endの窓とq0価格時計の実時間窓は別','観測高安と真の全約定高安は別','部分量のHLC3加重近似と厳密当場/約定VWAPは別','過去未来pivot又は最長正常区間を後付けanchorにしない']}
    assert all(sha(p)==h for p,h in before.items())and before_stat=={str(p):[p.stat().st_size,p.stat().st_mtime_ns]for p in [*paths,SOURCE]}
    with (HERE/'確認票.json').open('x',encoding='utf-8')as target:json.dump(proof,target,ensure_ascii=False,indent=2,allow_nan=False);target.write('\n')
    files=[HERE/'調査メモ.md',Path(__file__),HERE/'確認票.json'];stop={'成功':True,'編集停止':True,'自然stream未実行':True,'率未計数':True,'停止ファイル':[{'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p)}for p in files]}
    with (HERE/'停止.json').open('x',encoding='utf-8')as target:json.dump(stop,target,ensure_ascii=False,indent=2);target.write('\n')
    print(json.dumps({'成功':True,'確認票SHA256':sha(HERE/'確認票.json'),'停止SHA256':sha(HERE/'停止.json')},ensure_ascii=False))


if __name__=='__main__':
    main()
