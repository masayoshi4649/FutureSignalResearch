# 既知高安と足VWAP近似の純部品API案

2026-11-12。未採用のAPI設計だけを保存する。実装・自然147/148本文の読取・可用率計数・新X・学習・金融は未実行。100列・151・旧Source・正式成果を変更しない。根拠は停止済み入力調査と147/148のコード/schemaであり、下記の観測状態が自然データでどの程度成立するかは未確認である。

## 入力と部品の境界

将来のGo package名は `knownstructure`、module名は実装採用時に確定する。ファイル/Raw/CSV/観測ラベル/q1/取引選択を受けず、147の配送済み1分と現在q0だけを受ける。118Bankへ短期足をAddせず、別の構造履歴を持つ。既存Sourceを再生成しない。

`Bar` は147 `ShortBar` と同じ ID/session/contract/start/end/available_at/stamp/OHLC/volume/price_known/volume_known/closed/missing を持ち、CSV物理SHA/行、147 Source物理・解凍SHAを由来に保持する。`AsOf` は q0の time/index/source_line、現在Last/Bid/Askと各known/正常BBOを分離して持つ。構造計算へ正常BBOを要求せず、実側位置だけに要求する。

`SessionSpec` は session/contract/start/continuous_end を持つ。市場区間は147の `[Start, End−300)`。当場短期履歴はcold開始し、過去場の足で15/30/60分の不足を埋めない。前場高安を将来追加するなら、別の同限月・元場由来付き出力とする。

## 最小API

| API案 | 型付き引数 | 返り値と機能 |
| --- | --- | --- |
| `New` | `session SessionSpec, spec MeasureSpec` | `(State,error)`。窓900/1800/3600秒と事前アンカー定義を固定し、未知の初期状態を作る |
| `Advance` | `state State, batch DeliveryBatch` | `(State,AdvanceReport,error)`。同Rawの配送足を元順に全反映し、入力を変更せず新状態を返す |
| `At` | `state State, q0 AsOf` | `(Snapshot,error)`。全配送後の通常窓、当場観測高安、prefix完備性、登録済みアンカーの足VWAP近似をcopyで返す |
| `PriorRange` | `state State, q0 AsOf, comparisonBarID string, durationSeconds int` | `(FrozenRange,error)`。比較足rを含めず、r.Startで終わる実時間域を現在q0で凍結する |
| `Position` | `rng RangeResult, basis RangeBasis, q0 AsOf, side int` | `(PositionResult,error)`。Last位置とその側の正常実BBO位置を別に計算する。±1以外のsideは拒否する |

`DeliveryBatch` は `At AsOf, Bars []Bar`。同Raw catch-upは一batchとし、全反映前に `At` を呼ばない。配送足がないq0でも空batchで処理済み時計を進める。bar.Stampはbatch.Atのtime/index/lineと完全一致、bar.Endは元格子順に厳密増加を要求する。同Stamp複数足を禁止しない。異batchでは時計/原行の後退、同ID改変を拒否する。重複同体IDを窓へ二重加算しない。先の実装では同ID再提示を無操作にするか入力errorにするかを一つに固定する。

`Advance` は正確1分格子を検証し、欠分は親SourceのMissing placeholderとして受ける。足をsortして後退を修復したり、未知を詰めて古い良い足で本数を補ったりしない。状態更新失敗時は旧Stateを維持する。`AdvanceReport` は今回更新ID/既知性喪失/segment開始終了/重複等の理由だけを返し、売買を判定しない。

## 時計と窓

- 全参照で `End <= AvailableAt <= Stamp.Time <= q0.Time`。当場の `Stamp.Index <= q0.Index` と `Stamp.Line <= q0.Line` も別々に検査する。同Timeでも後の原行は利用不可。147の `Context.At` とbar.Stampが同一初知Rawを示すことをadapterが照合する。
- CSV足は市場Start/End、モデル公表AvailableAt=End+60、実配送Stampを別保存する。receivedAtやライブ通信遅延を復元したとは呼ばない。
- 通常窓の端 `E` は最新配送slotの市場Endであり、既知な古い足へfallbackしない。未知/未closedの最新slotも最新として保持する。900秒なら厳密に `[E−900,E)` の15slotである。q0から直近15分とは異なるので、`latest_end`、`q0_time_minus_latest_end`、`latest_delivery_stamp` を返す。fresh閾値や待ち幅を本部品で新設しない。
- rの突破比較はW秒について `[r.Start−W,r.Start)`。r.End=Eなら `[E−60−W,E−60)` であり、`[E−W,r.Start)` のW−1分にはしない。rのOHLC/量を高安算出へ混ぜない。FrozenRangeにrID/比較区間/q0凍結時計/元refsを保存する。
- 同Rawで初知の過去足を現在q0の窓へ利用できるが、以前からarm済みだったとは扱わない。`PriorRange` の知得時刻は現在q0であってr.Startではない。
- `At` は最新処理済みRawと同一q0だけを許容する。状態へ将来足が入った後の過去照会や、未処理Raw区間を飛ばした未来照会を拒否する。過去判定が必要なら当時のSnapshotを別に保存する。

## 高安・価格位置・観測範囲

`RangeResult` は `from/to/duration_seconds/expected_slots/present_slots/closed_slots/price_known_slots/missing_slots/unknown_reasons/refs` を持つ。値は次の2系統を混ぜない。

1. `complete_range`：区間全slotが存在し、closedかつprice_knownであるときだけHigh/Lowをknownにする。当場開始前の不足は未知。古い欠測が窓外へ出た後はrolling完備性だけ回復できる。
2. `observed_range`：実配送・closed・price_knownの足に限定したHigh/Low。1本以上あれば観測極値は返せるが、区間の真の高安/完全高安へ改名しない。観測足の最初/最後時刻・内部hole・対象時間の被覆秒を付ける。

当場prefixはStartからEまでの連続完備を別maskで返す。一度欠測したprefixは後の正常足でtrueへ戻さない。`observed_contiguous_segment` はその時点までの正常な連続部分であり、欠測後に回復可能だが最長区間の事後選択をしない。最新足の未知性、格子の存在、価格のknown、数量のknownは独立に保存する。offline最終品質mask/最終session_completeで過去q0を巻き戻さない。

位置計算には `basis=complete_range|observed_range` を必須指定し、完全域未知から観測域へ自動fallbackしない。幅 `U−L>0` の位置はLastを `買=(Last−L)/(U−L)`、`売=(U−Last)/(U−L)` とし、実側は買Ask0/売Bid0を別計算する。clipせず域外値も残す。実側の買/売はspreadがあるため `1−x` で補完しない。幅0はHigh/Low自体を未知にせず `range_zero=true`、正規化位置だけunknown/nullにする。価格差ptも併記できるが、ATR正規化は未採用で本APIへ追加しない。

## HLC3×既知量の足VWAP近似

`MeasureSpec.Anchors []AnchorSpec` へ採用前にID/市場開始時刻/認識可能時刻/理由・由来refsを固定する。現段階でどのアンカーを売買へ用いるかは未採用。初期案では当場Start固定のみを任意登録できる設計とし、オンライン再開区間を用いる案は別anchor ID・別測定定義としてRoot採用後に加える。全期の有利な安値/高値/pivot/最長正常区間へ後から起点を動かさない。

計算は固定起点Aから最新Eまでの `Σ(((H+L+C)/3)×V)/ΣV`。全slotの配送時計を守り、未配送末尾をEOFで加えない。`AnchorSpec` に `market_start` と `decided_at` を分離し、出力利用可能時刻は少なくともdecided_at以後。過去起点を現在認識する案を採る場合でも、その起点当時から利用できたとしない。

`VWAPResult` は `anchor_id/start/end/decided_at/sum_volume/value/known/unknown_reasons/refs`、`volume_prefix_complete`、`strict_joint_prefix_complete`、`weighted_contribution_prefix_complete`、既知0量数/未知量数/価格未知正量数を持つ。

- 正量はvolume_known、closed、有限V>0、price_knownの有限OHLCからだけ加重寄与を作る。
- 既知V=0は未知量と区別する。closedかつvolume_knownでV=0なら価格未知でも数学上の寄与は0である。したがって厳格joint完備性がfalseでも、加重寄与完備性はtrueになり得る。欠分/未closedは寄与既知へ補わない。
- 初回又は途中volume_unknownを0補完しない。固定起点のprefixは未知を保持する。後の正常足で回復させず、未知寄与を飛ばした数値を完全値として返さない。
- ΣV=0、非有限な積/累積/割算はvalue unknown/null。全量0を価格0へ変えない。未知slotがあっても既知分の和は診断用に分離できるが、それを採用値としない。
- これは1分HLC3とCSV既知量による足近似で、約定ごとの真VWAP/厳密当場VWAP/提供VWAPではない。147のvolume_complete由来はWebSocket/取引所全約定網羅の保証でもない。

同じ式で固定実時間rolling窓の量加重平均を将来作るなら、累積anchor版と別の測定名/出力にする。今回は実装・採用しない。

## 根拠と心理の区別

2026-11-12確認。[CME Support and Resistance](https://www.cmegroup.com/education/courses/technical-analysis/support-and-resistance)は過去高安等を支持抵抗候補として説明する。ただし本データの15/30/60分端が重要価格だと検証したものではなく、3本端から窓を延ばすだけで70%へ改善する保証はない。

[StockCharts VWAP](https://chartschool.stockcharts.com/table-of-contents/technical-indicators-and-overlays/technical-overlays/volume-weighted-average-price-vwap)の足代表価格と量の式、[Anchored VWAP](https://chartschool.stockcharts.com/table-of-contents/technical-indicators-and-overlays/technical-overlays/anchored-vwap)の開始点の違いを測定整理に用いた。既知高安で注文が再び現れる、量の多い価格が比較基準になる、という心理は仮説である。本APIは支持/反転/突破/良い入口を自動認定しない。

## 実装採用時の人工案

正確900/1800/3600秒と場先頭不足、r除外で正確W分、同Time後原行拒否、同Raw catch-upを現在のみ使用、未来足/同ID改変拒否、欠測後rolling回復とprefix非回復、場跨ぎcold、幅0、売買実側spread差、初回量未知、既知0×価格未知、全量0、固定anchor知得前利用拒否、入力/返却copy非改変を最小人工とする。自然可用率や損益を見て条件を緩めない。

このAPI案までで停止する。I/O adapter・可用率・追加特徴への組込・自然実行・151モデル変更はRootの別採用後である。
