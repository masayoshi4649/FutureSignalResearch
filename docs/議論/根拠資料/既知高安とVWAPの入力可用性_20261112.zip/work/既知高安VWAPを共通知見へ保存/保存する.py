"""停止済み可用性の小成果だけを一ZIPと共通知見へ保存する。自然再解析しない。"""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
SURVEY = ROOT / 'work/既知高安とVWAPアンカーの可用性調査'
TARGET = ROOT / 'docs/議論/根拠資料'
ZIP = TARGET / '既知高安とVWAPの入力可用性_20261112.zip'
DOC = ROOT / 'docs/議論/長い高安とVWAPの欠測を分けて扱う.md'
INDEX = TARGET / '既知高安とVWAPの入力可用性_20261112_索引.json'
CHECK = TARGET / '既知高安とVWAPの入力可用性_20261112_保存確認.json'


def fp(path: Path) -> dict:
    """
    機能: 小成果bytesをSHA付き相対pathで記録する。
    引数: path(Path)。返り値: dict。
    """
    raw = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def rate(scope: dict, window: str, mask: str) -> str:
    """
    機能: 固定集計から件数と率を表示用に取得する。
    引数: scope(dict)、window/mask(str)。返り値: str。
    """
    item = scope['windows'][window][mask]
    return f"{item['count']:,} / {scope['denominator']:,}（{item['rate']:.2%}）"


def main() -> None:
    """
    機能: 一度だけZIP保存し全格納bytes再読照合後に索引/共通Doc/確認票を作る。
    引数: なし。返り値: None。大入力・新X・目次・既存試行を変更しない。
    """
    stop_path = SURVEY / '停止の確認.json'
    assert fp(stop_path)['sha256'] == '48b83cbdb8b3f68888a75edebcd6a6465e2d30e5dbe7500579dc4bead70533a1'
    stop = json.loads(stop_path.read_bytes()); files = [ROOT / item['path'] for item in stop['停止対象']]
    assert len(files) == 8 and all(fp(path) == item for path, item in zip(files, stop['停止対象']))
    files.append(stop_path)
    for folder, names in [('既知高安とVWAPアンカーの純部品', ('API案.md', '確認票.json', '停止.json')),
                          ('既知高安とVWAPアンカーの入力準備調査', ('調査メモ.md', '確認する.py', '確認票.json', '停止.json'))]:
        files.extend(ROOT / 'work' / folder / name for name in names)
    files.extend([ROOT / 'work/既知高安とVWAPアンカーの外部追補_20261112.md', Path(__file__)])
    assert len(files) == len(set(files)) == 18
    before = {path: fp(path) for path in files}
    data = json.loads((SURVEY / '可用性の集計.json').read_bytes())
    assert fp(SURVEY / '可用性の集計.json')['sha256'] == '51f44b40e7bbc7239ea10201eb0549fbef0a8c7532c16dfa92f78495283d6e30'
    api = ROOT / 'work/既知高安とVWAPアンカーの純部品'
    declared_api = json.loads((api / '停止.json').read_bytes())
    assert fp(api / 'API案.md')['sha256'] == declared_api['API案SHA256']
    assert fp(api / '確認票.json')['sha256'] == declared_api['確認票SHA256']
    for path in (ZIP, DOC, INDEX, CHECK):
        assert path.resolve().is_relative_to(ROOT.resolve()) and not path.exists()
    TARGET.mkdir(parents=True, exist_ok=True)
    # ----------------------------------------
    # ZIP内のpathはすべてrepo相対work path。共有大入力は格納しません。
    with zipfile.ZipFile(ZIP, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files:
            info = zipfile.ZipInfo(path.relative_to(ROOT).as_posix(), date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, path.read_bytes(), compresslevel=9)
    with zipfile.ZipFile(ZIP) as archive:
        assert archive.namelist() == [before[path]['path'] for path in files]
        assert archive.testzip() is None
        for path in files: assert archive.read(before[path]['path']) == path.read_bytes()
    assert before == {path: fp(path) for path in files}
    eligible = data['分母別']['eligible_q0']; all_q0 = data['分母別']['all_q0']
    lines = [f"|{w}分|{rate(eligible, w, 'price_usable')}|{rate(eligible, w, 'joint_usable')}|" for w in ('15', '30', '60')]
    text = '''# 長い高安とVWAPの欠測を分けて扱う

2026-11-12。入力可用性の調査であり、新しい入口手法・特徴・モデルの採用や先着70%達成を示さない。最小人工3群の後、固定した147/148の2gzipを自然解析1回。Raw・新CSV・追加2場・金融・151の出力は読んでいない。

## 長い高安窓に使える足はどれだけあるか

全73場・43,124配送bar・全40,544q0（適格35,339q0）を残した。同Raw全配送後の最新bar ID/直近4slot/配送refsと、End/AvailableAt/Stampの時刻・index・物理行が当時履歴に一致した。窓端Eは最新slot.Endで、通常窓は厳密な[E−15/30/60分,E)。rを含み、r突破用の先行窓やq0からの直近窓とは異なる。

適格q0を分母とする可用性は次のとおり。価格可用は区間全slotのclosed/price_known/非Missing、共同可用はそれにvolume_knownを加えたもの。

|窓|高安の価格可用|価格・量の共同可用|
|---|---:|---:|
''' + '\n'.join(lines) + f'''

全q0の価格可用率は15/30/60分で{all_q0['windows']['15']['price_usable']['rate']:.2%}/{all_q0['windows']['30']['price_usable']['rate']:.2%}/{all_q0['windows']['60']['price_usable']['rate']:.2%}。適格以外を勝手に除外した分母と混ぜない。未知slotを飛ばして古い足で本数を補わず、最新未知から古いknownへfallbackしない。

## 当場Start固定VWAP近似は別の欠測問題を持つ

足HLC3×既知量のStart固定近似が計算可能なのは、適格q0で7,946/35,339（22.49%）、全q0で9,213/40,544（22.72%）。最初のslotは73場ともclosed/price_knownだが、量未知は47/73場（64.38%）だった。Start固定の量prefixは一度未知になると後続足だけでは回復しない。一度以上可用なのは26場、全q0で常に可用なのは21場だった。

rolling窓は欠測が窓外へ出れば回復できる。一方、固定prefixは未知を残す。これを混ぜてStart+60へずらす、正常区間へ再anchorする、未知量を0にする救済は採用していない。既知量0×価格未知は加重寄与0になり得るのでstrict jointとcontribution-knownを別maskにしたが、今回の自然barに既知量0はなく件数差は出なかった。

## 時計と測定の限界

CSVの市場Start/End、モデル公表End+60、実配送Stampを分ける。q0はCurrentPriceTimeによる価格時計で、実受信時刻を復元したものではない。既知・closedの足が揃っても、取引所/WSの全約定網羅や真の全セッション高安を認定しない。観測高安と真値を分け、EOF未配送足を過去q0へ足さない。

HLC3×Vは足代表価格の近似で、約定ごとの真VWAP・提供VWAP・市場全員の建値とは異なる。支持抵抗や平均回帰への役割は仮説であり、今回の可用性から損益・125pt持続・頻度・70%の優位は確認していない。次に条件を加えるなら未知を残した別仕様で評価する。

## 固定根拠と共有入力

[調査8小点・API案・外部追補のZIP](根拠資料/既知高安とVWAPの入力可用性_20261112.zip)、[格納索引](根拠資料/既知高安とVWAPの入力可用性_20261112_索引.json)、[全格納bytesの保存確認](根拠資料/既知高安とVWAPの入力可用性_20261112_保存確認.json)。ZIPはrepo相対work pathで18小点を一度格納し、全件を再読して元bytesと一致確認した。大入力・新Xは複製していない。

共有原典は[147 Sourceの参照と由来](../../inputs/00147_中位価格位置と実体回復/README.md)と[148母集団の参照と由来](../../inputs/00148_全1分入口母集団/README.md)。ZIP内の集計JSONに物理/解凍SHA・全CRC・前後statを保持する。元研究や151を変更していない。

ZIP物理SHA256：`{fp(ZIP)['sha256']}`。外部一般論・心理仮説と今回の可用性実測はZIP内で分けている。目次更新は別担当へ依頼する。
'''
    DOC.write_text(text, encoding='utf-8')
    for link in (ROOT / 'inputs/00147_中位価格位置と実体回復/README.md', ROOT / 'inputs/00148_全1分入口母集団/README.md'): assert link.exists()
    index = {'成功': True, '確認日': '2026-11-12', 'ZIP': fp(ZIP), '共通Doc': fp(DOC),
             '全格納元bytesと再読一致': True, '格納数': len(files), '格納': list(before.values()),
             '共有大入力/新X複製': False, '自然再解析': False, '目次/既存正式変更': False}
    INDEX.write_text(json.dumps(index, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    check = {'成功': True, '編集停止': True, 'ZIP全CRC/格納bytes再読': True,
             '全18源前後同体': True, 'ZIP': fp(ZIP), '索引': fp(INDEX), '共通Doc': fp(DOC),
             '保存コード': fp(Path(__file__)), '自然再解析/大入力新X複製/目次変更': False}
    CHECK.write_text(json.dumps(check, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    (HERE / '保存の確認.json').write_bytes(CHECK.read_bytes())
    print(json.dumps({'成功': True, 'ZIP_SHA256': fp(ZIP)['sha256'], '格納': len(files),
                      '索引SHA256': fp(INDEX)['sha256'], '保存確認SHA256': fp(CHECK)['sha256']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
