"""位置1軸追補の全分母を短報へ写し、元票不変更で停止する。"""
from pathlib import Path
import ast
import hashlib
import json
import os
import subprocess
import sys

HERE=Path(__file__).resolve().parent
BASE=HERE.parent/'150広げた構造候補が弱まった理由'


def sha(path: Path) -> str:
    """
    機能: 小成果のbytes指紋を返す。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: UTF-8人工と全位置群を保存し、旧原因票と併せて停止確認する。
    引数: なし。返り値: None。
    """
    for p in HERE.glob('*.py'):ast.parse(p.read_text(encoding='utf-8'))
    process=subprocess.run([sys.executable,'-X','utf8',str(HERE/'人工検査.py')],capture_output=True,env={**os.environ,'PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8','PYTHONDONTWRITEBYTECODE':'1'});stdout=process.stdout.decode('utf-8','strict');stderr=process.stderr.decode('utf-8','strict');assert process.returncode==0 and '\ufffd'not in stdout+stderr
    with (HERE/'人工の確認.json').open('x',encoding='utf-8')as target:json.dump({'成功':True,'人工主群':2,'構文':True,'UTF8_strict':True,'標準出力':stdout,'標準エラー':stderr},target,ensure_ascii=False,indent=2);target.write('\n')
    data=json.loads((HERE/'追補.json').read_bytes());old_stop=json.loads((BASE/'停止.json').read_bytes());assert sha(BASE/'停止.json')=='3abedb0d400e01db97164d263792999f7c0c6a4ce0151b0acdaf6011669db5fe'and all(sha(BASE/x['name'])==x['sha256']for x in old_stop['停止ファイル'])
    text=['# FA/FDのsignal側取得位置1軸の追補','','元150・元原因票は不変更。追加位置1軸を先固定し、同じ取得q1の元注文/実逆を比較した。全期既使用・事後・選択biasがあり新条件採用はしていない。前48/後25とも未知期ではなく、未選択/未参加の機会利益と無関係である。','','## 位置範囲を戻しても今回の低下は解消しない','','signal位置[0.75,1.5]のFA920件は354F/401A/86N/79C、到達済46.89%、C5利益4,673,045円/損失6,281,729円/差引−1,608,684円、IFD未知28。FD598件は228F/258A/60N/52C、46.91%、利益3,038,210円/損失4,051,947円/差引−1,013,737円、未知17。どちらも旧位置範囲を維持しただけで70%や費用後優位を再現しない。','',
        '同じ中範囲は前/後でもFA200F/231A→154F/170A、FD126F/140A→102F/118Aと未達。実逆も全期FA319F/443A・−2,716,530円、FD206F/285A・−1,789,583円で改善しない。','',
        'signal<0.75群はFA322件124F/144A・−762,101円、FD210件80F/92A・−545,554円。中範囲より一律に大幅悪化しているとは言えず、「既に深く進んだ後の逆注文」だけが低下原因という説明は支持されなかった。>1.5はFA15/FD10件、未知は各2件であり、実逆率の良い小群を新規条件へ採用していない。','',
        '## 全区分の前後比較','','F/A/N/Cは順先着/逆先着/両方未到達/H不足。金額は各側IFD既知の小計。利益/損失・両側既知差は追補JSONの各群に保存した。','','| 期間 | 枝 | signal位置 | 件数 | 注文F/A/N/C | 注文C5円 | 実逆F/A/N/C | 実逆C5円 | 注文/逆未知 | 場/連結群 |','|---|---|---|---:|---|---:|---|---:|---|---|']
    for part,policies in data['全期前後'].items():
        for policy,value in policies.items():
            for level,group in value['signal位置1軸'].items():
                pair=group['実正逆'];a=pair['元方向'];b=pair['実逆'];dependency=group['依存'];text.append(f"| {part} | {policy} | {level} | {a['件数']} | {'/'.join(str(a[k])for k in 'FANC')} | {a['C5差引']} | {'/'.join(str(b[k])for k in 'FANC')} | {b['C5差引']} | {a['IFD未知']}/{b['IFD未知']} | {dependency['取得場数']}/{dependency['名目H60連結群数']} |")
    text+=['','全73場を保持し、各群の0件場もJSONに残した。名目[q1,q1+3600)のstrict連結は群ごとに数えるため、絞り込みで橋渡し区間が抜けて群数が増える場合がある。独立標本数や実保有件数ではなく、群間にも同時間帯の依存がある。','',
        '## signal側と注文側の価格は違う','','この列は買=(Ask0−L3)/(U3−L3)、売=(U3−Bid0)/(U3−L3)、clipなし。FA/FDはorder=−signalなので、signalのP0は逆注文側P0と異なる。買位置+売位置は1+spread/幅となり、1−xへ補完していない。binはq0で決まりq1価格を使わない。','',
        '注文側の同列は分布だけを保存し、その金融層別を追加していない。全期FAは<0.75が1,039、[0.75,1.5]が196、>1.5が22、未知2。FDは672/130/16/2。signal側の中範囲920/598件を、注文側の中範囲196/130件と混同しない。','',
        '## 用途と再現','','位置は構造幅と同時点spreadも含む比率で、現在の1軸比較から他の省略条件との相互作用や真の価格形成原因を断定していない。今回支持されなかった位置単独説明を固定記録として残し、良い小群への主交換をしない。','',
        '区分の固定.md→人工検査.py→追補する.py→短報を保存する.py。元停止診断の保存Quote再計算票を再用し、選択済み1259q0の位置1列だけを追加した。延べFA/FD 2079所属を全体取得数へ加算しない。新Raw/CSV/追加2場・未選択利益は使用せず、元FA/FD全6正逆対照、gzip物理/解凍SHA/CRC、全源SHA/statを確認した。']
    with (HERE/'短報.md').open('x',encoding='utf-8')as target:target.write('\n'.join(text)+'\n')
    files=sorted(p for p in HERE.iterdir()if p.is_file()and p.name!='停止.json');proof={'成功':True,'編集停止':True,'元150と元原因票不変更':True,'新条件採用':False,'新しい金融軸はsignal位置1軸のみ':True,'注文側は分布だけ':True,'停止ファイル':[{'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p)}for p in files]}
    with (HERE/'停止.json').open('x',encoding='utf-8')as target:json.dump(proof,target,ensure_ascii=False,indent=2);target.write('\n')
    print(json.dumps({'成功':True,'停止SHA256':sha(HERE/'停止.json')},ensure_ascii=False))


if __name__=='__main__':
    main()
