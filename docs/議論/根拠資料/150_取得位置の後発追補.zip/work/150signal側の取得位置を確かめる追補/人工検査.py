"""追加1軸の境界と両実側位置を独立に参照することを確認する。"""
from pathlib import Path
import importlib.util
import unittest

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('position150',HERE/'追補する.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


class Tests(unittest.TestCase):
    """自然なし2主群。"""

    def test_境界と未知(self) -> None:
        """
        機能: 0.75/1.5を中群に含め未知を0へ補完しない。
        引数: self(Tests)。返り値: None。
        """
        self.assertEqual([m.bucket(v)for v in (.74,.75,1.5,1.51,None)],['<0.75','[0.75,1.5]','[0.75,1.5]','>1.5','未知'])

    def test_signalとorderの実P0を分ける(self) -> None:
        """
        機能: 両保存列とAsk/Bidを独立に使い1−xへ差し替えない。
        引数: self(Tests)。返り値: None。
        """
        record={'buy':{'x':[.8]},'sell':{'x':[.3]},'metadata':{'q0':{'ask':101,'bid':99}}};v=m.both_positions(record,1,0);self.assertEqual((v['signal位置'],v['order位置'],v['signal_P0'],v['order_P0']),(.8,.3,101,99));self.assertNotEqual(v['order位置'],1-v['signal位置'])
        v=m.both_positions(record,-1,0);self.assertEqual((v['signal位置'],v['order位置'],v['signal_P0'],v['order_P0']),(.3,.8,99,101))


if __name__=='__main__':
    unittest.main(verbosity=2)
