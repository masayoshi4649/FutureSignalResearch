"""FA/FDのsignal側位置1軸だけを追加し同q1実正逆を比較する。"""
from pathlib import Path
import hashlib
import importlib.util
import json

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
BASE=ROOT/'work/150広げた構造候補が弱まった理由'
FEATURES=ROOT/'inputs/00148_全1分入口母集団/当時特徴.json.gz'
CATALOG=ROOT/'inputs/00148_全1分入口母集団/100特徴の列定義.json'
KEY='q0_entry_prior3_percent_to_side'
LEVELS=('<0.75','[0.75,1.5]','>1.5','未知')
EXPECTED={BASE/'停止.json':'3abedb0d400e01db97164d263792999f7c0c6a4ce0151b0acdaf6011669db5fe',BASE/'診断.json':'0326f0730eac831fa545f8d5dba6d8e6b84ef66f5f073147c10e63c432e0a097',BASE/'診断する.py':'131eaa47c71f8453187003e7c1140c799cb399a56c7e6b289c0ab4fd576e61b3',BASE/'正本照合と短報を保存する.py':'97e719f26b712dabfecab0a84c22d00574e3b11748be8310ff95dc37f75b542b',FEATURES:'464dad9dce7acb20f043c344e96c9fa6d19ab0049a9d557e6fc96f6d189abcb7',CATALOG:'c85223fbe1543e5457c28d4391f817534099d1af1d19664035c668ff5fe8a7b4',HERE/'区分の固定.md':'565058a4a01b74faf25bbcc2cab0764ea3572b6e58e0b8ae5784366fd7a64056'}


def module(path: Path,name: str):
    """
    機能: 元停止票の純関数をmain未実行で読み込む。
    引数: path(Path)、name(str)。返り値: ModuleType。
    """
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value


def bucket(value) -> str:
    """
    機能: 指定1軸の.75/1.5を中群へ包含する。
    引数: value(float又はNone)。返り値: str。
    """
    return '未知'if value is None else '<0.75'if value<.75 else '[0.75,1.5]'if value<=1.5 else '>1.5'


def both_positions(record: dict,signal_side: int,index: int) -> dict:
    """
    機能: 両向き保存Xから別々のsignal/order位置と実P0を得る。
    引数: record(dict)、signal_side(int)、index(int)。返り値: dict。
    """
    assert signal_side in (-1,1);signal='buy'if signal_side==1 else 'sell';order='sell'if signal_side==1 else 'buy';q0=record['metadata']['q0']
    return {'signal位置':record[signal]['x'][index],'order位置':record[order]['x'][index],'signal_P0':q0['ask']if signal_side==1 else q0['bid'],'order_P0':q0['bid']if signal_side==1 else q0['ask']}


def main() -> None:
    """
    機能: 元票を変えず選択済みq0位置だけを結合し前後別に保存する。
    引数: なし。返り値: None。
    """
    source=module(BASE/'診断する.py','fixed150position');dependency=module(BASE/'正本照合と短報を保存する.py','fixed150dependence');assert all(source.sha(p)==h for p,h in EXPECTED.items())and source.sha(FEATURES,True)=='572705d7db8529555c876eb1953f7d8e1cd1de0e554bf9de729a7d377e4d91af'
    before={**EXPECTED,Path(__file__):source.sha(Path(__file__))};stat={str(p):[p.stat().st_size,p.stat().st_mtime_ns]for p in before};old=json.loads((BASE/'診断.json').read_bytes());sessions=old['全73場'];rows=[r for r in old['詳細']if r['policy']in ('FA','FD')];needed={r['event_id']for r in rows};catalog=json.loads(CATALOG.read_bytes());index=next(i for i,c in enumerate(catalog)if c['name']==KEY);features={}
    for record in source.array_items(FEATURES,'rows'):
        if record['event_id']in needed:
            assert record['event_id']not in features
            features[record['event_id']]={'session':record['session'],'contract':record['contract'],'q0_time':record['metadata']['q0']['time'],'positions':{s:both_positions(record,s,index)for s in (-1,1)}}
    assert set(features)==needed
    for r in rows:
        f=features[r['event_id']];assert f['session']==r['session']and f['contract']==r['contract']and f['q0_time']==r['q0_time']and r['order_side']==-r['signal_side'];r['追加位置']=f['positions'][r['signal_side']];r['signal位置群']=bucket(r['追加位置']['signal位置']);r['order位置群']=bucket(r['追加位置']['order位置'])
    arithmetic=source.load_calculation();results={}
    for part,scope in [('all',sessions),('train',sessions[:48]),('validation',sessions[48:])]:
        results[part]={}
        for policy in ('FA','FD'):
            selected=[r for r in rows if r['policy']==policy and r['session']in scope];assert arithmetic.paired(selected)==old['層別'][part][policy]['全取得']
            groups={level:{'実正逆':arithmetic.paired([r for r in selected if r['signal位置群']==level]),'依存':dependency.dependence([r for r in selected if r['signal位置群']==level],scope)}for level in LEVELS};distribution={level:sum(r['order位置群']==level for r in selected)for level in LEVELS}
            assert sum(g['実正逆']['元方向']['件数']for g in groups.values())==len(selected)==sum(distribution.values())
            results[part][policy]={'全取得':arithmetic.paired(selected),'signal位置1軸':groups,'order位置の参考分布のみ':distribution}
    assert all(source.sha(p)==h for p,h in before.items())and stat=={str(p):[p.stat().st_size,p.stat().st_mtime_ns]for p in before}
    detail=[{k:r[k]for k in ('policy','session','contract','case_id','event_id','signal_side','order_side','q0_time','q1_time','追加位置','signal位置群','order位置群')}for r in rows]
    output={'成功':True,'全期事後':True,'新条件採用':False,'主又は元原因票変更':False,'全73場':sessions,'全期前後':results,'新規金融軸数':1,'注文側は分布だけ':True,'q1でbinを決めない':True,'追加位置詳細':detail,'限界':'全段階既使用・選択bias・小群・近接依存。未参加利益と無関係。'}
    with (HERE/'追補.json').open('x',encoding='utf-8')as target:json.dump(output,target,ensure_ascii=False,indent=2,allow_nan=False);target.write('\n')
    with (HERE/'実行の確認.json').open('x',encoding='utf-8')as target:json.dump({'成功':True,'元FA_FD全6対照同体':True,'全源SHA_stat前後一致':True,'gzip物理解凍同体':True,'源':{str(p.relative_to(ROOT)).replace('\\','/'):h for p,h in before.items()},'出力SHA256':source.sha(HERE/'追補.json'),'延べ':len(rows),'uniqueq0':len(needed)},target,ensure_ascii=False,indent=2);target.write('\n')
    print(json.dumps({'成功':True,'延べ':len(rows),'uniqueq0':len(needed),'追補SHA256':source.sha(HERE/'追補.json')},ensure_ascii=False))


if __name__=='__main__':
    main()
