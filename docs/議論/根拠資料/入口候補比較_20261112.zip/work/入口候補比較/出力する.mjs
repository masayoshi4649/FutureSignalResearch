import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {Workbook} from '@oai/artifact-tool';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '../..');
const input = path.join(here, '比較入力.json');
const output = path.resolve(process.argv[2]);

/**
 * ファイル又は文字列のSHA256を求める。
 * @param {Buffer|string} value - 指紋化する内容。
 * @returns {string} SHA256の十六進文字列。
 */
function sha(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

/**
 * CSVの値をRFC4180形式へ引用する。
 * @param {string|number|boolean|null} value - 型付きの一セル。
 * @returns {string} CSVへ書く文字列。
 */
function field(value) {
  const text = value === null ? '' : String(value);
  return /[",\r\n]/.test(text) ? '"' + text.replaceAll('"', '""') + '"' : text;
}

// ----------------------------------------
const bytes = await fs.readFile(input);
assert.equal(sha(bytes), '1293203ab5a1978fe0c6b8262837bc0d71084dc6ffa8e750ee8455bd8b9b46a6');
const data = JSON.parse(bytes);
assert.equal(data.rows.length, 9);
for (const [name, expected] of Object.entries(data.sources)) {
  assert.equal(sha(await fs.readFile(path.join(root, name))), expected, name);
}
const original = [data.headers, ...data.rows];
assert.ok(original.every(row => row.length === data.headers.length));
assert.ok(output.startsWith(path.join(root, 'outputs') + path.sep));
const workbook = Workbook.create();
const sheet = workbook.worksheets.add('入口候補比較');
const table = sheet.getRangeByIndexes(0, 0, original.length, data.headers.length);
table.values = original;
sheet.showGridLines = false;
table.format.font = {name: 'Arial', size: 10};
table.format.verticalAlignment = 'center';
sheet.getRange('A1:I10').format.rowHeight = 26;
sheet.getRange('A1:I1').format = {fill: '#334155', font: {name: 'Arial', size: 10, color: '#FFFFFF', bold: true},
  wrapText: true, horizontalAlignment: 'center', verticalAlignment: 'center', rowHeight: 48};
const widths = [180, 100, 82, 132, 132, 122, 122, 138, 112];
widths.forEach((width, j) => sheet.getRangeByIndexes(0, j, 10, 1).format.columnWidthPx = width);
for (const column of [1, 14, 15]) sheet.getRangeByIndexes(1, column, 9, 1).setNumberFormat('0.00%');
for (const column of [2, 5, 6, 7, 8, 9, 10, 11, 12, 13]) sheet.getRangeByIndexes(1, column, 9, 1).setNumberFormat('#,##0');
sheet.getRange('D2:D10').setNumberFormat('0.00');
sheet.getRange('E2:E10').setNumberFormat('0.000');
workbook.recalculate();
assert.deepEqual(table.values, original, '全210セルの元値と型');
assert.ok(table.formulas.flat().every(value => value === '' || value === null || value === undefined));
const inspected = await workbook.inspect({kind: 'table', range: '入口候補比較!A1:I10', include: 'values,formulas',
  tableMaxRows: 10, tableMaxCols: 9, maxChars: 1400});
const errors = await workbook.inspect({kind: 'match', searchTerm: '#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',
  options: {useRegex: true, maxResults: 10}, maxChars: 1000});
const body = '\uFEFF' + table.values.map(row => row.map(field).join(',')).join('\r\n') + '\r\n';
// 表示用画像だけ短い同義見出しにし、CSVは照合済みの元見出しを保持する。
sheet.getRange('D1:E1').values = [['平均回数／場', '平均回数／時']];
workbook.recalculate();
const preview = await workbook.render({sheetName: '入口候補比較', range: 'A1:I10', scale: 1, format: 'png'});
assert.equal(sha(await fs.readFile(input)), sha(bytes));
try { assert.equal(sha(await fs.readFile(path.join(output, '入口候補比較.csv'))), sha(body)); }
catch (error) { if (error.code !== 'ENOENT') throw error; }
await fs.mkdir(output, {recursive: true});
await fs.writeFile(path.join(output, '入口候補比較.csv'), body, {encoding: 'utf8', flag: 'w'});
await fs.writeFile(path.join(output, '表示確認.png'), new Uint8Array(await preview.arrayBuffer()), {flag: 'w'});
const proof = {成功: true, 確認日: data.確認日, 行: data.rows.length, 列: data.headers.length,
  全セル照合: original.length * data.headers.length, 金融再計算: false, 新バックテスト: false,
  入力SHA256: sha(bytes), 出力SHA256: sha(body), 正本指紋: data.sources,
  出力コードSHA256: sha(await fs.readFile(fileURLToPath(import.meta.url))),
  node: process.version, inspect: inspected.ndjson, エラー走査: errors.ndjson};
await fs.writeFile(path.join(output, '作成確認.json'), JSON.stringify(proof, null, 2) + '\n', {encoding: 'utf8', flag: 'w'});
console.log(JSON.stringify({成功: true, 行: data.rows.length, 列: data.headers.length, SHA256: sha(body)}));
