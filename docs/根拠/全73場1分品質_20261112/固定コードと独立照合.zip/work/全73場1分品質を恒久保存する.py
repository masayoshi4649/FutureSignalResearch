"""停止済みの73場1分品質監査を一度だけ恒久保存する。原CSVや価格は読まない。"""
from pathlib import Path
import gzip
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'work/全73場1分足の品質監査実行'
TARGET=ROOT/'docs/根拠/全73場1分品質_20261112'


def sha(raw: bytes) -> str:
    """
    機能: 保存原文の指紋を求める。
    引数: raw(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(raw).hexdigest()


# ----------------------------------------
def save(source: Path,target: Path,packed: bool=False) -> dict:
    """
    機能: 元正本の同体又はgzipを未作成先へ保存する。
    引数: source/target(Path)、packed(bool)。
    返り値: dictは由来/保存/復元指紋。元がgzipなら再圧縮しない。
    """
    raw=source.read_bytes();body=gzip.compress(raw,mtime=0) if packed else raw
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as f:f.write(body)
    return {'元参照':source.relative_to(ROOT).as_posix(),'保存元':target.relative_to(ROOT).as_posix(),'追加gzip':packed,
        '元bytes':len(raw),'元SHA256':sha(raw),'保存bytes':len(body),'保存SHA256':sha(body)}


# ----------------------------------------
def main() -> None:
    """
    機能: F0/品質mask/要約/独立証跡とコードを保存し共通知見へ案内する。
    引数: なし。
    返り値: None。CSV/原板/新金融/新入口/追加2場/旧試行は扱わない。
    """
    expected={'F0.json':'85dbb9c44bca26b3c5465b3652d6d801373f1bb75bd32c6d302dd0911f45529f',
        '結果/要約.json':'d5fe8f316a87540a3312576c3fa9f8e35b3cd6ccde1ce80ae6c4e03b3b0a72ad',
        '結果/品質監査.json.gz':'0f19e86d7dae0b6352d1970872fc5204a1d816720e81725674a006c3b80d24a0'}
    for name,h in expected.items():assert sha((RUN/name).read_bytes())==h
    outputs=[save(RUN/'結果/品質監査.json.gz',ROOT/'inputs/全73場1分品質_20261112/品質監査.json.gz')]
    for source,target,packed in [(RUN/'F0.json','F0.json',False),(RUN/'結果/要約.json','要約.json.gz',True),
        (RUN/'結果/監査の確認.json','作者の監査確認.json',False),(RUN/'監査の完了.json','Rootの監査完了.json',False),
        (ROOT/'work/全73場1分足品質の独立照合/独立照合.json','独立照合.json',False),
        (ROOT/'work/全73場1分足品質の独立照合/停止の確認.json','独立停止の確認.json',False)]:outputs.append(save(source,TARGET/target,packed))
    assert sha((TARGET/'独立照合.json').read_bytes())=='cf3c5958b42015704766e30dbc492bac127abda3de58099e681a9112c7172a87'
    f0=json.loads((RUN/'F0.json').read_bytes());declared=f0['ファイル'];source_registry=[];bodies={};csv=[];shared=[]
    for name,h in declared.items():
        p=Path(name)
        if p.suffix=='.csv':csv.append({'path':name,'sha256':h,'stat':f0['CSV固定時stat'][name]});continue
        rel=p.relative_to(ROOT).as_posix()
        if rel.startswith('inputs/'):shared.append({'path':rel,'sha256':h,'用途':'既存恒久入力又は保存確認。複写しない'});continue
        if rel=='work/133金融前を固定して実行する.py':
            m=json.loads(next((ROOT/'study').glob('00133_*/保管索引.json')).read_bytes());item=m['固定コード'];archive=next((ROOT/'study').glob('00133_*'))/'再現資料'/item['ZIP']
            assert sha(archive.read_bytes())==item['ZIP_SHA256']
            with zipfile.ZipFile(archive) as z:assert sha(z.read(rel))==h
            shared.append({'path':rel,'sha256':h,'保存元ZIP':archive.relative_to(ROOT).as_posix(),'ZIP_SHA256':item['ZIP_SHA256'],'ZIP内path':rel});continue
        raw=p.read_bytes();assert sha(raw)==h;bodies[rel]=raw
        source_registry.append({'path':rel,'sha256':h,'bytes':len(raw),'区分':'元F0固定源'})
    assert len(csv)==73 and len(source_registry)==7 and len(shared)==3
    for p in (ROOT/'work/全73場1分足品質の独立照合').iterdir():
        if not p.is_file() or p.name in ('独立照合.json','停止の確認.json'):continue
        rel=p.relative_to(ROOT).as_posix();raw=p.read_bytes();bodies[rel]=raw
        source_registry.append({'path':rel,'sha256':sha(raw),'bytes':len(raw),'区分':'後発独立照合源。注記訂正の追補も保存'})
    rel=Path(__file__).relative_to(ROOT).as_posix();raw=Path(__file__).read_bytes();bodies[rel]=raw
    source_registry.append({'path':rel,'sha256':sha(raw),'bytes':len(raw),'区分':'金融なしの恒久保存処理'})
    archive=TARGET/'固定コードと独立照合.zip'
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,raw in bodies.items():z.writestr(name,raw)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for x in source_registry:assert sha(z.read(x['path']))==x['sha256']
    index={'確認日':'2026-11-12','試行':None,'作業':'全73場1分足品質の停止済み監査の恒久保存','F0_SHA256':expected['F0.json'],
        '成果':outputs,'固定コードZIP':archive.name,'固定コードZIP_SHA256':sha(archive.read_bytes()),'コード源':source_registry,'共有参照':shared,
        '元CSV73参照':csv,'CSV本文複製/新数値解析/原板/金融/出生/追加2場/旧試行変更':False,
        '品質maskの扱い':'完成fileのoffline品質情報。オンライン出生へ未来mask/最長区間/最終完備性を流用しない'}
    save_body=(json.dumps(index,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    with (TARGET/'保管索引.json').open('xb') as f:f.write(save_body)
    report='''# 全73場の1分足品質と有限窓の可用性

2026-11-12。F0固定後に実行済みの**非金融・完成CSV品質監査**を恒久保存した。対象は既知73場（37デイ/36ナイト）の1分CSV、ザラバ格子43,255分。新しい価格再読・原板・金融・出生・追加2場の解析を本保存作業では行っていない。

|確認項目|結果|
|---|---:|
|格子全体の価格/量共同完備|21/73場|
|価格だけの格子全体完備|26/73場|
|欠けた分|2,586分|
|価格既知|40,669分|
|量既知・共同既知|各40,622分|
|生成器の量不完全flag|47分、全てCSV先頭データ行|
|既知量0/未知量0|各0分|
|終端に既知連続区間あり|73場|

独立実装が全43,255分のmask辞書、73場要約、件数を正本と照合した。UTF-8・ヘッダ・列数・構文・時刻不正、対象格子内の重複/後退等は各0だった。先頭の量不完全や途中欠分を0/前値で補わず、session_startからの完備性と後続の連続既知区間を分けた。

これは収集器CSVの保守的な共同既知maskで、通信受信/全約定完全性の証明ではない。joint=falseを全ての数学的VWAPが不可能という意味にせず、既知量0/価格未知の寄与0等の別定義も区別する。今回はVWAP/VWMA値を計算していない。

セッション起算の平均を必須とする案は、この入力規約では全場参加が難しい。局所の[VWMA](../technical-analysis/指標/出来高加重移動平均線.md)は後の連続20分等から回復できる別測定だが、「73場にどこか正常区間がある」だけで全場のVWMA20/背景/取得まで成立したとは言えない。元VWAPを途中起算へ改名せず、新しい測定と試行を分ける。

完成fileの最終mask・将来の最長正常区間・後続のエラーで、オンラインの過去出生やanchorを選ばない。新入口では現在までに配送済みの1分格子と品質だけを使い、最新分が不良なら古い良い分へ戻らない。[受信/価格/研究公表時計](../データと閲覧形式.md)も参照。

## 恒久資料と再現

- [F0](../根拠/全73場1分品質_20261112/F0.json)：85dbb9c4…、83源（73CSVと10参照源）を固定。
- [要約](../根拠/全73場1分品質_20261112/要約.json.gz)：解凍SHA d5fe8f31…。
- [全分品質mask](../../inputs/全73場1分品質_20261112/品質監査.json.gz)：圧縮SHA0f19e86d…、一度だけ保存。価格/量の生値を含まない。
- [作者の前後確認](../根拠/全73場1分品質_20261112/作者の監査確認.json)・[Root完了](../根拠/全73場1分品質_20261112/Rootの監査完了.json)。
- [独立照合](../根拠/全73場1分品質_20261112/独立照合.json)：cf3c5958…。注記文字列だけの初回不一致と補修もコードZIPへ残し、品質算術変更とは区別した。
- [保管索引](../根拠/全73場1分品質_20261112/保管索引.json)：73個の原CSV絶対参照・SHA/stat、共有metadata/105保存確認/133driver、固定/独立コードの完全指紋。
- [コードZIP](../根拠/全73場1分品質_20261112/固定コードと独立照合.zip)：元F0文書/人工/監査器/Rootdriverと、後発独立部品を分離保管。

再現は原CSV73個がF0の指紋を満たす環境で行う。ZIPをルート相当の新作業先へ復元し、共有metadata `inputs/00124_同入口正逆の共用入力/入力.json.gz` と133driverを保管索引の恒久先から参照する。原F0は保持し、パス変更時は金融後ではなく**品質監査後の再現用パス台帳**と明示して新しい宛先へ対応させる。利用するCLIは `監査する.py --f0 <台帳> --f0-sha256 <SHA> --metadata <共用gzip> --metadata-sha256 717f41674a4c99f94545a5e147495ae66498dbbc1afa48d7f34d04c40514843b --source-root <JP_OSE_Data> --output-dir <未作成先> --execute-after-f0`。同名成果を上書きせず、再現のため原CSVを正式領域へコピーしない。本保存ではこの自然CLIを再実行していない。

原板の別恒久先にある3場と元CSV所在の対応は105保存確認で解決したが、CSVとRawの全内容が同体だと証明したものではない。別sourceや量基準を成績で選ぶfallbackはこの監査に含めない。
'''
    doc=ROOT/'docs/議論/全73場の1分足品質と固定窓の可用性.md';doc.write_text(report,encoding='utf-8')
    for path,prefix in [(ROOT/'docs/README.md','議論/'),(ROOT/'docs/議論/README.md','')]:
        text=path.read_text('utf-8');title,rest=text.split('\n\n',1)
        note=f'入力品質（2026-11-12）：[全73場の1分足品質と固定窓の可用性]({prefix}全73場の1分足品質と固定窓の可用性.md)。共同完備21/73、欠分2,586、先頭の量不完全47分。全mask/独立照合/原CSV指紋/コードを恒久保存し、完成fileの品質とオンライン知得を分ける。'
        path.write_text(title+'\n\n'+note+'\n\n'+rest,encoding='utf-8')
    proof={'成功':True,'編集停止':True,'品質gzipを一度保存':True,'要約/独立/83源参照/固定コード恒久保存':True,
        '新CSV/原板/価格読取/金融/出生/追加2場/旧試行変更':False,'保管索引SHA256':sha(save_body),'コードZIP_SHA256':sha(archive.read_bytes()),
        '報告SHA256':sha(doc.read_bytes()),'重大不足':[]}
    p=TARGET/'保存の確認.json';p.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'保存確認SHA256':sha(p.read_bytes()),'品質gzipSHA256':expected['結果/品質監査.json.gz'],'コードZIP_SHA256':proof['コードZIP_SHA256']},ensure_ascii=False))


if __name__=='__main__':main()
