# 全73場の1分CSV品質を監査する準備

2026-11-12。採番なしの非金融品質監査部品。自然CSVの価格行はRoot F0後だけ解析する。原板・金融・新birth・追加2場は扱わない。[条件.md](条件.md)を正本、[準備の確認.json](準備の確認.json)を人工/コード証跡とする。

固定共用124metadataの73scene（Day37/Night36）と各sessionの`candle_1min.csv`を使い、ザラバのStart→End−300に期待する1分格子を照合する。OHLC型/形状、closed、量型/volume_complete、量known0とunknown0、欠足/重複/後退を分け、価格・量の生値を保存しない。

`session_complete`はこのザラバ格子のprefix完備性で、先頭不足/途中喪失後に後足から回復させない。後続正常足は`observed_contiguous_segment_known`の別区間として回復可能。上位のcurrent-knownと、どこかに既知区間があったexistsも分ける。時刻位置を決められない構文/時刻エラーは全域曖昧にする保守設計で、通常の欠分とは別である。

jointは価格AND量の既知を求める十分条件で、VWAP数学的計算の必要条件とは断定しない。既知量0/価格未知の寄与0という余地は既存maskから識別し、件数を別保存する。各weighted_mean_possible=falseが他の全測定も不可能という意味ではなく、今回VWAP値を計算した結果でもない。

**完成CSVを使うoffline可用性監査**であり、未来全fileのエラー/重複、最長正常区間、最終session_completeを出生当時のknownや事後anchor選択へ流用しない。将来のオンライン入口は、その時点までの処理済み公表と品質だけで遷移し、後続エラーで過去出生を巻き戻さない。

Rootdriverは`work/全73場の1分品質を固定して実行する.py`。F0でmetadata圧縮/解凍指紋・73CSVのSHA/stat・コード/文書を固定し、全源をverifyしてから`監査する.py`を起動する。CLI引数は`--f0/--f0-sha256 --metadata/--metadata-sha256 --source-root --output-dir --execute-after-f0`。CLI単独の実bytes SHA検査は各CSVのparse直前に行う。

出力は全分maskの`品質監査.json.gz`、73場の`要約.json`、前後SHA/statの`監査の確認.json`。生成器flagと監査knownを分け、CSVにない限月/A差Q差/受信完全性を認定しない。原本の複写・価格値・VWAP値・金融出力は作らない。
