"""全73CSV品質監査を人工bytes/tempfileだけで検査する。自然価格行は読まない。"""
from contextlib import redirect_stdout
from datetime import datetime,timezone,timedelta
import gzip
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from 品質 import HEADER,audit_csv

SPEC=importlib.util.spec_from_file_location('監査器',Path(__file__).with_name('監査する.py'))
M=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(M)


def scene(start: int=0,minutes: int=3) -> dict:
    """
    機能: ザラバ範囲だけを短縮した人工sceneを作る。
    引数: start/minutes(int)は開始と対象分数。
    返り値: dictは人工場。
    """
    return {'session':'2026-01-01_Day','contract':'人工限月','start':start,'end':start+minutes*60+300}


def row(at: int,volume: str='10',complete: str='true',closed: str='true',prices: tuple=('100','110','90','105')) -> str:
    """
    機能: 価格/量を使う人工CSV一行を作る。
    引数: at(int)、volume/complete/closed(str)、prices(tuple)は人工値。
    返り値: strはCSV一行。
    """
    clock=datetime.fromtimestamp(at,timezone(timedelta(hours=9))).isoformat()
    return ','.join([clock,*prices,volume,complete,closed])+'\n'


def body(rows: list,header: tuple=HEADER) -> bytes:
    """
    機能: 人工ヘッダと行をUTF-8へする。
    引数: rows(list[str])、header(tuple)は人工内容。
    返り値: bytesはCSV。
    """
    return (','.join(header)+'\n'+''.join(rows)).encode()


class Tests(unittest.TestCase):
    """自然入力を開かずprefix/区間/mask/固定CLIを検査する。"""
    def test_complete_zero_and_positive_denominator(self) -> None:
        """
        機能: known量0と加重平均分母0、正重み出現を分ける。
        引数: self(Tests)。返り値: None。
        """
        r=audit_csv(body([row(0,'0'),row(60,'0'),row(120,'10')]),scene())
        self.assertTrue(r['session_complete']);self.assertEqual(r['counts']['volume_known_zero_minutes'],2)
        self.assertFalse(r['masks'][0]['segment_weighted_mean_possible']);self.assertTrue(r['masks'][2]['segment_weighted_mean_possible'])
        self.assertTrue(all(m['volume_known'] for m in r['masks']))

    def test_missing_prefix_never_recovers(self) -> None:
        """
        機能: 先頭欠落を後の正常足でsession completeへ戻さない。
        引数: self(Tests)。返り値: None。
        """
        r=audit_csv(body([row(60),row(120)]),scene())
        self.assertFalse(r['session_complete']);self.assertTrue(r['observed_contiguous_segment_known']);self.assertTrue(r['observed_contiguous_segment_exists'])
        self.assertEqual(r['counts']['missing_minutes'],1);self.assertTrue(all(not m['session_complete'] for m in r['masks']))
        self.assertEqual(r['masks'][2]['segment_start'],60);self.assertEqual(r['segment_count'],1)

    def test_loss_and_recovery_distinct_from_prefix(self) -> None:
        """
        機能: 途中の量不完全でprefixを失い、後続は別segmentだけ回復する。
        引数: self(Tests)。返り値: None。
        """
        r=audit_csv(body([row(0),row(60,'0','false'),row(120)]),scene())
        self.assertEqual(r['counts']['volume_unknown_zero_minutes'],1);self.assertEqual(r['counts']['volume_known_zero_minutes'],0)
        self.assertEqual(r['masks'][1]['source_volume_complete'],False);self.assertTrue(r['masks'][1]['source_volume_complete_known'])
        self.assertEqual(r['masks'][1]['source_volume_cell_kind'],'zero')
        self.assertTrue(r['masks'][0]['session_complete']);self.assertFalse(r['masks'][1]['session_complete']);self.assertFalse(r['masks'][2]['session_complete'])
        self.assertTrue(r['masks'][2]['observed_contiguous_segment_known']);self.assertEqual(r['segment_count'],2);self.assertEqual(r['known_segment_breaks'],1)

    def test_values_flags_and_known_unknown_separation(self) -> None:
        """
        機能: OHLC不正、量の空欄/非有限/負、旗不明、closed falseを区別する。
        引数: self(Tests)。返り値: None。
        """
        variants=[row(0,prices=('0','110','0','105')),row(0,prices=('100','99','90','105')),row(0,'NaN'),row(0,''),row(0,'-1'),row(0,'0','unknown'),row(0,'0','true','false')]
        for text in variants:
            r=audit_csv(body([text,row(60),row(120)]),scene());self.assertFalse(r['session_complete']);self.assertTrue(r['observed_contiguous_segment_known'])
        r=audit_csv(body([row(0,prices=('NaN','110','90','105')),row(60),row(120)]),scene())
        self.assertFalse(r['masks'][0]['price_known']);self.assertTrue(r['masks'][0]['volume_known']);self.assertTrue(r['session_volume_complete'])
        r=audit_csv(body([row(0,'0',prices=('NaN','110','90','105')),row(60),row(120)]),scene())
        self.assertEqual(r['counts']['volume_known_zero_price_unknown_minutes'],1)
        self.assertTrue(r['masks'][0]['volume_known_zero']);self.assertFalse(r['masks'][0]['joint_known'])

    def test_duplicate_backward_and_missing_not_repaired(self) -> None:
        """
        機能: 重複を削除し後退をソートして完備化しない。
        引数: self(Tests)。返り値: None。
        """
        r=audit_csv(body([row(0),row(60),row(60),row(120)]),scene())
        self.assertEqual(r['counts']['duplicate_slots'],1);self.assertFalse(r['masks'][1]['joint_known']);self.assertFalse(r['session_complete'])
        r=audit_csv(body([row(0),row(120),row(60)]),scene())
        self.assertEqual(r['counts']['below_maximum_clock'],1);self.assertFalse(r['masks'][1]['joint_known']);self.assertFalse(r['session_complete'])
        r=audit_csv(body([row(0),row(120)]),scene())
        self.assertEqual(r['counts']['missing_minutes'],1);self.assertTrue(r['masks'][2]['observed_contiguous_segment_known'])

    def test_unlocated_ambiguity_and_scope_boundary(self) -> None:
        """
        機能: 時刻不明等の全域曖昧と、ザラバ終端以後のscopeを分ける。
        引数: self(Tests)。返り値: None。
        """
        for bad in ['invalid,100,110,90,105,10,true,true\n',row(30),row(0).replace('09:00:00','09:00:00.000000001'),row(0).replace('+09:00','+09:99'),row(0).replace('+09:00','+09:60')]:
            r=audit_csv(body([bad,row(60),row(120)]),scene());self.assertTrue(r['file_structure_ambiguous']);self.assertFalse(r['observed_contiguous_segment_exists'])
        r=audit_csv(body([row(0),row(60),row(120),row(180,'0','false','false'),row(480,'0','false','false')]),scene())
        self.assertTrue(r['session_complete']);self.assertEqual(r['expected_minutes'],3)
        self.assertEqual(r['scope_counts']['preclosing']['closed_false'],1);self.assertEqual(r['scope_counts']['after']['closed_false'],1)
        r=audit_csv(body([row(0),row(60),row(120,'0','true','false')]),scene())
        self.assertFalse(r['observed_contiguous_segment_known']);self.assertTrue(r['observed_contiguous_segment_exists'])
        r=audit_csv(body([row(0)],HEADER[:-1]),scene());self.assertFalse(r['header_valid']);self.assertFalse(r['session_complete'])

    def test_sha_guard_before_price_parse(self) -> None:
        """
        機能: F0未知SHAとCSV期待SHA差を価格セル解析前に拒否する。
        引数: self(Tests)。返り値: None。
        """
        args=['監査する.py','--f0','存在しない','--f0-sha256','unknown','--metadata','存在しない','--metadata-sha256',M.METADATA_SHA,'--source-root','存在しない','--output-dir','未作成','--execute-after-f0']
        with patch('sys.argv',args),patch.object(Path,'read_bytes',side_effect=RuntimeError('入力読取へ進んだ')):
            with self.assertRaises(AssertionError):M.main()
        with tempfile.TemporaryDirectory() as directory:
            p=Path(directory)/'人工.csv';p.write_bytes(body([row(0)]))
            with patch.object(M,'audit_csv',side_effect=RuntimeError('価格解析へ進んだ')):
                with self.assertRaises(AssertionError):M.audit_file(p,'0'*64,scene())

    def test_all73_cli_and_no_values_saved(self) -> None:
        """
        機能: 人工73場のF0/圧縮metadata/CSV全照合・前後SHA・gzip出力を検査する。
        引数: self(Tests)。返り値: None。自然価格行は読まない。
        """
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);source=root/'JP_OSE_Data';scenes=[];files={}
            for i in range(73):
                day=datetime(2026,1,1,tzinfo=timezone.utc)+timedelta(days=i);at=int(day.timestamp());sid=day.strftime('%Y-%m-%d')+('_Day' if i<37 else '_Night')
                s={'session':sid,'contract':'人工限月','start':at,'end':at+420};scenes.append(s)
                p=source/'future/NK225'/sid/'candle_1min.csv';p.parent.mkdir(parents=True)
                p.write_bytes(body([row(at,'123456.789',prices=('98765.432109','98770','98760','98766')),row(at+60)]));files[str(p.resolve())]=M.digest(p.read_bytes())
            decoded=json.dumps({'scenes':scenes}).encode();compressed=gzip.compress(decoded,mtime=0);mp=root/'metadata.json.gz';mp.write_bytes(compressed)
            ms=M.digest(compressed);ds=M.digest(decoded);files[str(mp.resolve())]=ms
            f0={'試行':None,'作業':M.WORK,'ファイル':files};fp=root/'F0.json';fp.write_text(json.dumps(f0),encoding='utf-8');fs=M.digest(fp.read_bytes());out=root/'結果'
            args=['監査する.py','--f0',str(fp),'--f0-sha256',fs,'--metadata',str(mp),'--metadata-sha256',ms,'--source-root',str(source),'--output-dir',str(out),'--execute-after-f0']
            with patch.object(M,'METADATA_SHA',ms),patch.object(M,'DECODED_SHA',ds),patch.object(M,'LOCAL',()),patch('sys.argv',args),redirect_stdout(io.StringIO()):M.main()
            summary=json.loads((out/'要約.json').read_bytes());detail=gzip.decompress((out/'品質監査.json.gz').read_bytes())
            self.assertEqual(summary['対象場数'],73);self.assertEqual(summary['対象分数'],146);self.assertEqual(summary['session_complete場数'],73)
            self.assertNotIn(b'98765.432109',detail);self.assertNotIn(b'123456.789',detail);self.assertIsNone(summary['累積代金量差アンカー可否'])
            before={n:M.digest(Path(n).read_bytes()) for n in files};self.assertEqual(before,files)


if __name__=='__main__':unittest.main(verbosity=2)
