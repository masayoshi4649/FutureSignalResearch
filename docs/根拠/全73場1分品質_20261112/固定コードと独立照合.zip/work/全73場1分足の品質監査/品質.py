"""1分CSVの値を保存せず、固定格子の品質maskへ射影する純部品。"""
from collections import Counter
import csv
from datetime import datetime
import io
import math
import re

HEADER=('time','open','high','low','close','volume','volume_complete','closed')
RFC3339=re.compile(r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.(\d{1,9}))?(?:Z|[+-]\d{2}:\d{2})$')


def numeric(text: str) -> tuple:
    """
    機能: 数値セルを有限性/空欄/0へ分類する。
    引数: text(str)はCSVセル。
    返り値: tuple[float|None,str]は内部値と種類。値は監査出力に残さない。
    """
    if text=='':return None,'empty'
    if text.strip()!=text:return None,'invalid'
    try:value=float(text)
    except ValueError:return None,'invalid'
    if not math.isfinite(value):return None,'nonfinite'
    return value,'negative' if value<0 else 'zero' if value==0 else 'positive'


def boolean(text: str) -> tuple:
    """
    機能: 完全性フラグを曖昧に補完せず解釈する。
    引数: text(str)はtrue/falseセル。
    返り値: tuple[bool,bool]はknownと真偽値。
    """
    return (True,text=='true') if text in ('true','false') else (False,False)


def clock(text: str) -> tuple:
    """
    機能: 元reader同様に時差付き分開始時計を解釈する。
    引数: text(str)はRFC3339文字列。
    返り値: tuple[float|None,bool]はUnix秒と非0小数秒フラグ。
    """
    match=RFC3339.fullmatch(text)
    if not match:return None,False
    if not text.endswith('Z') and (int(text[-5:-3])>23 or int(text[-2:])>59):return None,False
    try:d=datetime.fromisoformat(text.replace('Z','+00:00'));at=d.timestamp()
    except (ValueError,OverflowError):return None,False
    if d.tzinfo is None or not math.isfinite(at):return None,False
    return at, bool(match.group(1) and any(c!='0' for c in match.group(1)))


def audit_csv(body: bytes, scene: dict) -> dict:
    """
    機能: 一場CSVを固定1分格子へ照合し価格を残さず品質だけを返す。
    引数: body(bytes)、scene(dict)は固定CSVとsession/contract/start/end metadata。
    返り値: dictはcounts/mask/時刻。未知prefixを後足で回復させない。
    """
    start,end=scene['start'],scene['end'];finish=end-300
    assert math.isfinite(start) and math.isfinite(end) and finish>start and (finish-start)%60==0
    slots=int((finish-start)/60);counts=Counter({k:0 for k in ('records','utf8_invalid','header_invalid','row_width_invalid','multiline_record','clock_invalid','adjacent_backward','below_maximum_clock','off_grid_continuous','csv_parse_error','missing_minutes','duplicate_slots','duplicate_extra_records','backward_slots','price_known_minutes','volume_known_minutes','joint_known_minutes','volume_known_zero_minutes','volume_unknown_zero_minutes','volume_known_positive_minutes','volume_known_zero_price_unknown_minutes')});scope_counts={k:Counter() for k in ('before','continuous','preclosing','after')}
    indexed={};ambiguous=False;header_valid=False;previous=None;maximum=None;first_line=1
    try:text=body.decode('utf-8-sig')
    except UnicodeDecodeError:text='';ambiguous=True;counts['utf8_invalid']=1
    reader=csv.reader(io.StringIO(text,newline=''),strict=True)
    try:
        header=next(reader,None);header_valid=tuple(header or ())==HEADER
        if not header_valid:counts['header_invalid']=1;ambiguous=True
        while True:
            first_line=reader.line_num+1
            try:row=next(reader)
            except StopIteration:break
            counts['records']+=1
            if not header_valid:continue
            width_ok=len(row)==len(HEADER);multiline=reader.line_num!=first_line
            if not width_ok:counts['row_width_invalid']+=1
            if multiline:counts['multiline_record']+=1
            at,subsecond=clock(row[0]) if row else (None,False)
            if at is None:counts['clock_invalid']+=1;ambiguous=True;continue
            scope='before' if at<start else 'continuous' if at<finish else 'preclosing' if at<end else 'after'
            scope_counts[scope]['records']+=1
            backward=maximum is not None and at<maximum
            if previous is not None and at<previous:counts['adjacent_backward']+=1
            if backward:counts['below_maximum_clock']+=1
            previous=at;maximum=at if maximum is None else max(maximum,at)
            aligned=not subsecond and (at-start)%60==0
            if scope=='continuous' and not aligned:counts['off_grid_continuous']+=1;ambiguous=True
            if not width_ok or multiline:
                if scope=='continuous' and aligned:indexed.setdefault(at,[]).append({'source_line':first_line,'invalid_record':True,'backward':backward})
                continue
            ck,closed=boolean(row[7]);vk,complete=boolean(row[6]);volume,vkind=numeric(row[5])
            price=[numeric(c)[0] for c in row[1:5]];finite_price=all(v is not None for v in price)
            positive=finite_price and all(v>0 for v in price)
            shape=positive and price[1]>=max(price[0],price[3]) and price[2]<=min(price[0],price[3]) and price[1]>=price[2]
            volume_valid=volume is not None and volume>=0
            sc=scope_counts[scope]
            sc['closed_true' if ck and closed else 'closed_false' if ck else 'closed_unknown']+=1
            sc['volume_complete_true' if vk and complete else 'volume_complete_false' if vk else 'volume_complete_unknown']+=1
            sc['volume_cell_'+vkind]+=1
            if scope!='continuous' or not aligned:continue
            indexed.setdefault(at,[]).append({'source_line':first_line,'invalid_record':False,'backward':backward,
                'closed_known':ck,'closed':closed,'volume_complete_known':vk,'volume_complete':complete,
                'price_finite':finite_price,'price_positive':bool(positive),'price_shape':bool(shape),
                'volume_valid':volume_valid,'volume_cell_kind':vkind,'volume_zero':volume==0 if volume is not None else False,
                'volume_positive':volume>0 if volume is not None else False})
    except csv.Error:
        counts['csv_parse_error']+=1;ambiguous=True
    # ----------------------------------------
    # 原行をソートして採用/重複除去はしません。格子順は欠落位置とprefixを表示するためだけです。
    masks=[];price_prefix=True;volume_prefix=True;joint_prefix=True;prefix_positive=False
    segment_id=0;segment_start=None;segment_length=0;segment_positive=False;breaks=0;first_failure=None
    for i in range(slots):
        at=start+i*60;source=indexed.get(at,[]);missing=not source;duplicate=len(source)>1
        row=source[0] if len(source)==1 else {};invalid=bool(row.get('invalid_record',False));backward=any(r.get('backward') for r in source)
        structure=not ambiguous and not missing and not duplicate and not invalid and not backward
        closed=structure and row.get('closed_known',False) and row.get('closed',False)
        pk=bool(closed and row.get('price_finite',False) and row.get('price_positive',False) and row.get('price_shape',False))
        vk=bool(closed and row.get('volume_complete_known',False) and row.get('volume_complete',False) and row.get('volume_valid',False))
        joint=pk and vk;known_zero=vk and row.get('volume_zero',False);unknown_zero=not vk and any(r.get('volume_zero',False) for r in source)
        reasons=[]
        if ambiguous:reasons.append('file_structure_ambiguous')
        if missing:reasons.append('missing')
        if duplicate:reasons.append('duplicate')
        if backward:reasons.append('clock_backward')
        if invalid:reasons.append('invalid_record')
        if structure:
            for name in ('closed_known','closed','price_finite','price_positive','price_shape','volume_complete_known','volume_complete','volume_valid'):
                if not row.get(name,False):reasons.append(name)
        if not joint and first_failure is None:first_failure={'start':at,'reasons':list(reasons)}
        price_prefix=price_prefix and pk;volume_prefix=volume_prefix and vk;joint_prefix=joint_prefix and joint
        if joint_prefix:prefix_positive=prefix_positive or row.get('volume_positive',False)
        else:prefix_positive=False
        if joint:
            if segment_start is None:segment_id+=1;segment_start=at;segment_length=0;segment_positive=False
            segment_length+=1;segment_positive=segment_positive or row.get('volume_positive',False)
        else:
            if segment_start is not None:breaks+=1
            segment_start=None;segment_length=0;segment_positive=False
        counts['missing_minutes']+=missing;counts['duplicate_slots']+=duplicate;counts['duplicate_extra_records']+=max(0,len(source)-1)
        counts['backward_slots']+=backward;counts['price_known_minutes']+=pk;counts['volume_known_minutes']+=vk;counts['joint_known_minutes']+=joint
        counts['volume_known_zero_minutes']+=known_zero;counts['volume_unknown_zero_minutes']+=unknown_zero
        counts['volume_known_zero_price_unknown_minutes']+=bool(known_zero and not pk)
        counts['volume_known_positive_minutes']+=bool(vk and row.get('volume_positive',False))
        masks.append({'start':at,'end':at+60,'source_lines':[r['source_line'] for r in source],
            'source_closed_known':bool(len(source)==1 and not invalid and row.get('closed_known',False)),
            'source_closed':row.get('closed') if len(source)==1 and not invalid and row.get('closed_known',False) else None,
            'source_volume_complete_known':bool(len(source)==1 and not invalid and row.get('volume_complete_known',False)),
            'source_volume_complete':row.get('volume_complete') if len(source)==1 and not invalid and row.get('volume_complete_known',False) else None,
            'source_price_finite':row.get('price_finite') if len(source)==1 and not invalid else None,
            'source_price_shape':row.get('price_shape') if len(source)==1 and not invalid else None,
            'source_volume_numeric_valid':row.get('volume_valid') if len(source)==1 and not invalid else None,
            'source_volume_cell_kind':row.get('volume_cell_kind') if len(source)==1 and not invalid else None,
            'price_known':pk,'volume_known':vk,'volume_known_zero':bool(known_zero),'volume_unknown_zero':bool(unknown_zero),
            'joint_known':joint,'session_price_prefix_complete':bool(price_prefix),'session_volume_prefix_complete':bool(volume_prefix),
            'session_complete':bool(joint_prefix),'session_prefix_weighted_mean_possible':bool(joint_prefix and prefix_positive),
            'observed_contiguous_segment_known':bool(joint),'segment_id':segment_id if joint else None,
            'segment_start':segment_start,'segment_minutes':segment_length,'segment_positive_weight_seen':bool(segment_positive),
            'segment_weighted_mean_possible':bool(joint and segment_positive),'missing':missing,'duplicate':duplicate,'backward':bool(backward),'reasons':reasons})
    return {'session':scene['session'],'contract':scene['contract'],'start':start,'session_end':end,'continuous_end':finish,'expected_minutes':slots,
        'header_valid':header_valid,'file_structure_ambiguous':ambiguous,'counts':dict(counts),'scope_counts':{k:dict(v) for k,v in scope_counts.items()},
        'first_minute':masks[0],'first_prefix_failure':first_failure,'session_complete':bool(joint_prefix),
        'session_price_complete':bool(price_prefix),'session_volume_complete':bool(volume_prefix),
        'observed_contiguous_segment_known':masks[-1]['observed_contiguous_segment_known'],
        'observed_contiguous_segment_exists':any(m['observed_contiguous_segment_known'] for m in masks),
        'segment_count':segment_id,'known_segment_breaks':breaks,'masks':masks,
        'measurement_note':'OHLCV完備性という保守的な十分条件。known量0/価格未知の寄与0等を含む他の数学的可否を否定しない。WS/全約定の独立完全性、真session VWAPの認定ではない',
        'contract_join':'固定metadataのsession/pathへ結合。CSVに限月列はなく独立照合不可','price_or_volume_values_saved':False}
