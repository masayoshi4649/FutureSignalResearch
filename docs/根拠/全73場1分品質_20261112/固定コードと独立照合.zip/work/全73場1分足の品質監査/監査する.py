"""Root F0後だけ、固定73場の1分CSV品質を非金融で監査する。"""
import argparse
from collections import Counter
import gzip
import hashlib
import json
import os
from pathlib import Path
import re

from 品質 import audit_csv

HERE=Path(__file__).resolve().parent
METADATA_SHA='717f41674a4c99f94545a5e147495ae66498dbbc1afa48d7f34d04c40514843b'
DECODED_SHA='b2368b1f42c16e8c96a3acd098c58a902807a3b6a5023d6d4b1e75261f3ee51b'
WORK='全73場1分足の非金融品質監査'
LOCAL=('品質.py','監査する.py','人工検査.py','条件.md','README.md','準備の確認.json')


def digest(body: bytes) -> str:
    """
    機能: 明示bytesのSHA256を求める。
    引数: body(bytes)は対象。
    返り値: strは小文字指紋。
    """
    return hashlib.sha256(body).hexdigest()


def valid_sha(value: str) -> bool:
    """
    機能: 期待指紋の形式をファイル読取前に検査する。
    引数: value(str)は指紋。
    返り値: boolは64桁の小文字16進か。
    """
    return isinstance(value,str) and re.fullmatch('[0-9a-f]{64}',value) is not None


def file_stat(value: os.stat_result) -> dict:
    """
    機能: 価格値を含まないfile同一性を保存する。
    引数: value(os.stat_result)はstat。
    返り値: dictはサイズ/mtime/デバイス/識別子。
    """
    return {'bytes':value.st_size,'mtime_ns':value.st_mtime_ns,'device':value.st_dev,'file_id':value.st_ino}


def load_metadata(body: bytes) -> list:
    """
    機能: 共用124の圧縮/解凍指紋を確認し必要73sceneだけを選ぶ。
    引数: body(bytes)は共用gzip。
    返り値: list[dict]は識別/限月/時計だけ。entries/Raw値/金融は参照しない。
    """
    assert digest(body)==METADATA_SHA
    decoded=gzip.decompress(body);assert digest(decoded)==DECODED_SHA
    source=json.loads(decoded)['scenes']
    scenes=[{k:s[k] for k in ('session','contract','start','end')} for s in source]
    assert len(scenes)==73 and len({s['session'] for s in scenes})==73
    assert [s['session'] for s in scenes]==sorted(s['session'] for s in scenes)
    assert sum(s['session'].endswith('_Day') for s in scenes)==37 and sum(s['session'].endswith('_Night') for s in scenes)==36
    for i,s in enumerate(scenes):
        assert re.fullmatch(r'\d{4}-\d{2}-\d{2}_(Day|Night)',s['session']) and isinstance(s['contract'],str) and s['contract']
        assert s['end']>s['start'] and (s['end']-s['start'])%60==0 and s['end']-300>s['start']
        if i:assert s['start']>=scenes[i-1]['end']
    return scenes


def save(path: Path,data: dict) -> str:
    """
    機能: 新規JSON又はgzipへ品質情報だけを保存する。
    引数: path(Path)、data(dict)は出力先と品質内容。
    返り値: strは保存bytesのSHA256。
    """
    body=(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode('utf-8')
    if path.suffix=='.gz':body=gzip.compress(body,mtime=0)
    with path.open('xb') as stream:stream.write(body)
    return digest(body)


def audit_file(path: Path,expected: str,scene: dict) -> tuple:
    """
    機能: F0のCSV指紋に一致した同一bytesだけを1回解析する。
    引数: path(Path)、expected(str)、scene(dict)はCSV・期待SHA・場。
    返り値: tuple[dict,dict]は品質結果と前後file証跡。価格値は保存しない。
    """
    assert valid_sha(expected)
    before=file_stat(path.stat());body=path.read_bytes();assert digest(body)==expected
    report=audit_csv(body,scene)
    after=file_stat(path.stat());after_sha=digest(path.read_bytes());assert before==after and after_sha==expected
    evidence={'path':str(path.resolve()),'sha256':expected,'stat_before':before,'stat_after':after,'before_after_equal':True,'CSV_parse_passes':1,
        'contract_link':'metadataのsession/path結合。CSVに限月列なし、CSV側の独立同一限月証明ではない'}
    report['source']=evidence
    return report,evidence


def main() -> None:
    """
    機能: Root固定を確認して全73CSVを品質mask/時刻/countsだけへ射影する。
    引数: CLIのF0/metadataと各SHA、source-root/output-dir、execute-after-f0。
    返り値: None。新birth/Raw/金融/価格出力/追加2場は扱わない。
    """
    p=argparse.ArgumentParser(description=WORK)
    for name in ('f0','metadata'):
        p.add_argument('--'+name,type=Path,required=True);p.add_argument('--'+name+'-sha256',required=True)
    p.add_argument('--source-root',type=Path,required=True);p.add_argument('--output-dir',type=Path,required=True);p.add_argument('--execute-after-f0',action='store_true')
    args=p.parse_args()
    assert args.execute_after_f0 and valid_sha(args.f0_sha256) and args.metadata_sha256==METADATA_SHA
    assert not any((args.output_dir/n).exists() for n in ('品質監査.json.gz','要約.json','監査の確認.json'))
    f0_body=args.f0.read_bytes();assert digest(f0_body)==args.f0_sha256;f0=json.loads(f0_body)
    assert f0['試行'] is None and f0['作業']==WORK
    declared={Path(n).resolve():h for n,h in f0['ファイル'].items()}
    local={HERE/n:digest((HERE/n).read_bytes()) for n in LOCAL}
    assert all(declared[n.resolve()]==h for n,h in local.items())
    metadata=args.metadata.resolve();assert declared[metadata]==METADATA_SHA
    metadata_before=file_stat(metadata.stat());scenes=load_metadata(metadata.read_bytes())
    source_root=args.source_root.resolve();paths={s['session']:(source_root/'future/NK225'/s['session']/'candle_1min.csv').resolve() for s in scenes}
    assert len(paths)==73 and len(set(paths.values()))==73
    for path in paths.values():assert path.is_relative_to(source_root) and path in declared and valid_sha(declared[path])
    reports=[];evidence=[]
    # ----------------------------------------
    # 価格/数量セルの解析はF0・コード・metadata・対象73参照の全確認後だけです。
    for scene in scenes:
        path=paths[scene['session']];report,proof=audit_file(path,declared[path],scene);reports.append(report);evidence.append(proof)
        print(json.dumps({'場':scene['session'],'対象分数':report['expected_minutes'],'CSV解析1回':True},ensure_ascii=False))
    counts=Counter()
    for r in reports:counts.update(r['counts'])
    summary={'成功':True,'試行':None,'作業':WORK,'対象場数':73,'Day場数':37,'Night場数':36,'対象分数':sum(r['expected_minutes'] for r in reports),
        'session_complete場数':sum(r['session_complete'] for r in reports),'session_price_complete場数':sum(r['session_price_complete'] for r in reports),
        'session_volume_complete場数':sum(r['session_volume_complete'] for r in reports),
        'observed_contiguous_segment_known終端場数':sum(r['observed_contiguous_segment_known'] for r in reports),
        'observed_contiguous_segment_exists場数':sum(r['observed_contiguous_segment_exists'] for r in reports),
        'counts':dict(counts),'定義':'session_completeはSession.StartからEnd-300までのザラバCSV格子完備性。受信/全約定完全性ではない',
        'session_completeとobserved_segmentは別':True,'数学的HLC3量加重平均の正分母可否':'各maskは価格AND量既知という保守的な十分条件。falseは全測定での不可能を証明しない。既知量0なら価格未知でも寄与0の余地がある。VWAP値は計算しない',
        'known量0かつ価格未知分数':counts['volume_known_zero_price_unknown_minutes'],
        '累積代金量差アンカー可否':None,'累積代金量差の限界':'CSVに累積売買代金/累積数量/固有時計がなく、別監査が必要',
        'metadata圧縮SHA256':METADATA_SHA,'metadata解凍SHA256':DECODED_SHA,'F0_SHA256':args.f0_sha256,'原板又は金融又は新birth':False,
        '価格又は量の生値出力':False,'追加2場参照':False,'scenes':[{k:v for k,v in r.items() if k!='masks'} for r in reports]}
    for proof in evidence:
        path=Path(proof['path']);assert file_stat(path.stat())==proof['stat_before'] and digest(path.read_bytes())==proof['sha256']
    assert file_stat(metadata.stat())==metadata_before and digest(metadata.read_bytes())==METADATA_SHA
    assert digest(args.f0.read_bytes())==args.f0_sha256 and all(digest(n.read_bytes())==h for n,h in local.items())
    args.output_dir.mkdir(parents=True,exist_ok=True)
    detail=save(args.output_dir/'品質監査.json.gz',{'成功':True,'試行':None,'作業':WORK,'F0_SHA256':args.f0_sha256,'scenes':reports,'price_or_volume_values_saved':False})
    sh=save(args.output_dir/'要約.json',summary)
    save(args.output_dir/'監査の確認.json',{'成功':True,'作業':WORK,'試行':None,'F0_SHA256':args.f0_sha256,'前後不変':True,
        'metadata圧縮SHA256':METADATA_SHA,'metadata解凍SHA256':DECODED_SHA,'全CSV':evidence,'コードSHA256':{str(n):h for n,h in local.items()},
        '品質gzipSHA256':detail,'要約SHA256':sh,'品質解析回数':73,'価格数量値保存':False,'原板金融birth追加2場':False})
    print(json.dumps({'成功':True,'対象場数':73,'対象分数':summary['対象分数'],'品質gzipSHA256':detail,'要約SHA256':sh},ensure_ascii=False))


if __name__=='__main__':main()
