"""売買結果を使わず、既知73場の1分CSV品質だけをF0固定後に監査する。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import gzip
import hashlib
import importlib.util
import json
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
CODE = ROOT / 'work/全73場1分足の品質監査'
OWN = ROOT / 'work/全73場1分足の品質監査実行'
METADATA = ROOT / 'inputs/00124_同入口正逆の共用入力/入力.json.gz'
META_SHA = '717f41674a4c99f94545a5e147495ae66498dbbc1afa48d7f34d04c40514843b'
DECODED_SHA = 'b2368b1f42c16e8c96a3acd098c58a902807a3b6a5023d6d4b1e75261f3ee51b'
SOURCE = ROOT.parent / 'JP_OSE_Data'


def sha(path: Path) -> str:
    """
    機能: ファイルの全バイト指紋を求める。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def helper() -> object:
    """
    機能: 汎用JSON保存と指紋照合だけを既存モジュールから読む。
    引数: なし。
    返り値: objectはsave/verifyを持つ。金融mainは実行しない。
    """
    path = ROOT / 'work/133金融前を固定して実行する.py'
    spec = importlib.util.spec_from_file_location('1分品質の保存と固定照合', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# ----------------------------------------
def main() -> None:
    """
    機能: コードと全CSVの指紋を先に固定し、次の操作で品質監査だけを実行する。
    引数: CLI --mode(str)は固定又は監査。
    返り値: None。新しい価格指標・出生・金融ラベルは作らない。
    """
    parser = argparse.ArgumentParser(description='全73場1分足の非金融品質監査を固定する')
    parser.add_argument('--mode', choices=('固定', '監査'), required=True)
    args = parser.parse_args()
    h = helper()
    OWN.mkdir(parents=True, exist_ok=True)
    frozen_path = OWN / 'F0.json'
    if args.mode == '固定':
        assert sha(METADATA) == META_SHA
        decoded = gzip.decompress(METADATA.read_bytes())
        assert hashlib.sha256(decoded).hexdigest() == DECODED_SHA
        metadata = json.loads(decoded)
        scenes = metadata['scenes']
        assert len(scenes) == len({s['session'] for s in scenes}) == 73
        assert (CODE / '準備の確認.json').exists()
        assert sha(CODE / '準備の確認.json') == '60b79b968eb99fec8515bab5c2ad8bb47fd8b378e5f04cc5143dd86430b362ed'
        files = {METADATA, Path(__file__).resolve(), ROOT / 'work/133金融前を固定して実行する.py'}
        csvs = []
        storage = ROOT / 'inputs/105生成原板/保存の確認.json'
        storage_proof = json.loads(storage.read_bytes())
        assert storage_proof['成功'] and storage_proof['由来試行'] == 105
        stored = {item['session']: item for item in storage_proof['files']}
        alternate_storage = []
        for scene in scenes:
            assert re.fullmatch(r'2026-\d{2}-\d{2}_(Day|Night)', scene['session'])
            path = SOURCE / 'future/NK225' / scene['session'] / 'candle_1min.csv'
            assert path.is_file()
            raw_path = Path(scene['raw']['path']).resolve()
            if path.parent.resolve() != raw_path.parent:
                item = stored[scene['session']]
                assert Path(item['canonical']['path']).resolve() == raw_path
                assert item['canonical']['sha256'] == scene['raw']['sha256']
                assert Path(item['original_jsonl']['path']).resolve().parent == path.parent.resolve()
                alternate_storage.append({'session': scene['session'], 'raw': str(raw_path), 'CSV': str(path),
                    '対応': '105の既存保存確認にあるgzip恒久先と元JSONL所在。CSV内容とRaw内容の独立同体照合ではない'})
            files.add(path)
            csvs.append(path)
        assert len(csvs) == len(set(csvs)) == 73
        assert {s['session'] for s in alternate_storage} == set(stored)
        files.add(storage)
        files.update(p for p in CODE.rglob('*') if p.is_file() and p.suffix in ('.py', '.md', '.json'))
        fingerprints = {str(p): sha(p) for p in sorted(files)}
        stat = {str(p): {'bytes': p.stat().st_size, 'mtime_ns': p.stat().st_mtime_ns} for p in csvs}
        h.save(frozen_path, {'成功': True, '試行': None, '作業': '全73場1分足の非金融品質監査',
            'UTC': datetime.now(timezone.utc).isoformat(), 'metadata圧縮SHA256': META_SHA,
            'metadata解凍SHA256': DECODED_SHA, '対象場数': 73, 'CSV数': 73,
            '新価格行の数値解析': False, '新生入口と金融': False, '追加2場を探索': False,
            '用途': '完成fileのoffline品質監査。未来の全file mask/最長区間/最終完備性をオンライン出生やanchor選択へ流用しない',
            '保守的十分条件': 'joint/prefix falseを全VWAP定義の数学不能と断定しない。既知量0と価格未知を別計数',
            'source_root': str(SOURCE), 'CSV固定時stat': stat, '別保管Rawとの対応': alternate_storage,
            '固定前補修': 'RawとCSVの親path同体を仮定して停止した。105保存確認から3場の元所在対応を照合し、自然parse前に補修。',
            'ファイル': fingerprints})
        print(json.dumps({'F0_SHA256': sha(frozen_path), '固定ファイル数': len(files), 'CSV数': 73}, ensure_ascii=False))
        return
    fixed = json.loads(frozen_path.read_bytes())
    h.verify(fixed)
    command = [sys.executable, '-X', 'utf8', str(CODE / '監査する.py'), '--f0', str(frozen_path),
        '--f0-sha256', sha(frozen_path), '--metadata', str(METADATA), '--metadata-sha256', META_SHA,
        '--source-root', str(SOURCE), '--output-dir', str(OWN / '結果'), '--execute-after-f0']
    subprocess.run(command, cwd=ROOT, check=True)
    h.verify(fixed)
    output_files = [p for p in (OWN / '結果').rglob('*') if p.is_file()]
    assert output_files
    h.save(OWN / '監査の完了.json', {'成功': True, '作業': fixed['作業'], 'F0_SHA256': sha(frozen_path),
        '実行列': command, '全固定源前後同体': True, '新生入口と金融': False,
        '出力': {str(p): sha(p) for p in sorted(output_files)}, '追加2場を探索': False})


if __name__ == '__main__':
    main()
