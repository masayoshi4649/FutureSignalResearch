"""Root許可後の固定73CSVを独立算術で解析し、全品質maskと要約を照合する。"""
from collections import Counter
import argparse
import gzip
import hashlib
import json
from pathlib import Path

from 独立品質 import classify_csv

ROOT=Path(__file__).resolve().parents[2]
OWN=Path(__file__).resolve().parent
RUN=ROOT/'work/全73場1分足の品質監査実行'
PINS={
    'F0':(RUN/'F0.json','85dbb9c44bca26b3c5465b3652d6d801373f1bb75bd32c6d302dd0911f45529f'),
    'detail':(RUN/'結果/品質監査.json.gz','0f19e86d7dae0b6352d1970872fc5204a1d816720e81725674a006c3b80d24a0'),
    'summary':(RUN/'結果/要約.json','d5fe8f316a87540a3312576c3fa9f8e35b3cd6ccde1ce80ae6c4e03b3b0a72ad'),
    'metadata':(ROOT/'inputs/00124_同入口正逆の共用入力/入力.json.gz','717f41674a4c99f94545a5e147495ae66498dbbc1afa48d7f34d04c40514843b'),
}


def sha(path: Path) -> str:
    """
    機能: 許可されたコード/metadata/CSV/品質結果だけの指紋を取得する。
    引数: path(Path)は対象。
    返り値: strはSHA256。Raw原板は許可しない。
    """
    assert path.name not in ('book.jsonl','book.jsonl.gz')
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def stat(path: Path) -> dict:
    """
    機能: file同一性を価格値なしで取得する。
    引数: path(Path)は対象CSV。
    返り値: dictはsize/mtime/device/file_id。
    """
    s=path.stat();return {'bytes':s.st_size,'mtime_ns':s.st_mtime_ns,'device':s.st_dev,'file_id':s.st_ino}


# ----------------------------------------
def canonical(value: object) -> str:
    """
    機能: 品質構造だけの順序非依存指紋を作る。
    引数: value(object)は価格値を含まない品質出力。
    返り値: strはcanonical JSONのSHA256。
    """
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: F0全83源/3例外path/全73CSVを独立照合して小型proofだけ保存する。
    引数: CLI --execute-after-root-authorization(bool)はRoot明示許可後の実行。
    返り値: None。生値と正本mask全件を複製しない。
    """
    parser=argparse.ArgumentParser(description='固定73場CSV品質の独立照合')
    parser.add_argument('--execute-after-root-authorization',action='store_true',required=True);parser.parse_args()
    assert not (OWN/'独立照合.json').exists()
    preparation=json.loads((OWN/'準備の確認.json').read_bytes())
    initial_preparation_sha=sha(OWN/'準備の確認.json')
    supplement=OWN/'注記訂正の追補.json'
    if supplement.exists():
        preparation=json.loads(supplement.read_bytes())
        assert preparation['初回準備SHA256']==initial_preparation_sha
    for name,h in preparation['コードSHA256'].items():assert sha(OWN/name)==h
    for name,(path,h) in PINS.items():assert sha(path)==h,name
    f0=json.loads(PINS['F0'][0].read_bytes())
    assert f0['試行'] is None and f0['対象場数']==f0['CSV数']==73
    fixed={Path(name).resolve():h for name,h in f0['ファイル'].items()}
    assert len(fixed)==83
    for path,h in fixed.items():assert sha(path)==h,path
    decoded=gzip.decompress(PINS['metadata'][0].read_bytes())
    assert hashlib.sha256(decoded).hexdigest()=='b2368b1f42c16e8c96a3acd098c58a902807a3b6a5023d6d4b1e75261f3ee51b'
    raw_scenes=json.loads(decoded)['scenes']
    scenes=[{k:s[k] for k in ('session','contract','start','end')} for s in raw_scenes]
    assert len(scenes)==len({s['session'] for s in scenes})==73
    storage_path=ROOT/'inputs/105生成原板/保存の確認.json'
    assert storage_path.resolve() in fixed
    storage=json.loads(storage_path.read_bytes());assert storage['成功'] and storage['由来試行']==105
    stored={r['session']:r for r in storage['files']};alternates=[]
    source_root=Path(f0['source_root']).resolve()
    paths={s['session']:(source_root/'future/NK225'/s['session']/'candle_1min.csv').resolve() for s in scenes}
    assert set(paths.values())=={p for p in fixed if p.name=='candle_1min.csv'}
    for scene in raw_scenes:
        csv_path=paths[scene['session']];raw_path=Path(scene['raw']['path']).resolve()
        if csv_path.parent!=raw_path.parent:
            item=stored[scene['session']]
            assert Path(item['canonical']['path']).resolve()==raw_path and item['canonical']['sha256']==scene['raw']['sha256']
            assert Path(item['original_jsonl']['path']).resolve().parent==csv_path.parent
            alternates.append({'session':scene['session'],'raw':str(raw_path),'CSV':str(csv_path),
                '対応':'105の既存保存確認にあるgzip恒久先と元JSONL所在。CSV内容とRaw内容の独立同体照合ではない'})
    assert len(alternates)==3 and {a['session'] for a in alternates}==set(stored)
    assert alternates==f0['別保管Rawとの対応']
    detail=json.loads(gzip.decompress(PINS['detail'][0].read_bytes()));summary=json.loads(PINS['summary'][0].read_bytes())
    assert detail['F0_SHA256']==summary['F0_SHA256']==PINS['F0'][1]
    results=[];scene_proofs=[];all_counts=Counter();total_masks=0;incomplete_flags=[]
    for scene,wanted in zip(scenes,detail['scenes'],strict=True):
        path=paths[scene['session']];before=stat(path);body=path.read_bytes()
        assert hashlib.sha256(body).hexdigest()==fixed[path]
        assert before['bytes']==f0['CSV固定時stat'][str(path)]['bytes'] and before['mtime_ns']==f0['CSV固定時stat'][str(path)]['mtime_ns']
        actual=classify_csv(body,scene);after=stat(path);assert before==after and sha(path)==fixed[path]
        evidence={'path':str(path),'sha256':fixed[path],'stat_before':before,'stat_after':after,'before_after_equal':True,'CSV_parse_passes':1,
            'contract_link':'metadataのsession/path結合。CSVに限月列なし、CSV側の独立同一限月証明ではない'}
        actual['source']=evidence
        assert actual==wanted,scene['session']
        for mask in actual['masks']:
            if mask['source_volume_complete_known'] and mask['source_volume_complete'] is False:
                incomplete_flags.append({'session':scene['session'],'first_data_line':mask['source_lines']==[2],'start':mask['start']})
        total_masks+=len(actual['masks']);all_counts.update(actual['counts'])
        scene_proofs.append({'session':scene['session'],'minutes':actual['expected_minutes'],'quality_canonical_sha256':canonical(actual),
            'session_complete':actual['session_complete'],'session_price_complete':actual['session_price_complete'],
            'session_volume_complete':actual['session_volume_complete'],'segments':actual['segment_count']})
        results.append(actual)
    assert len(results)==73 and total_masks==43255
    assert summary['scenes']==[{k:v for k,v in r.items() if k!='masks'} for r in results]
    derived={'対象場数':len(results),'Day場数':sum(r['session'].endswith('_Day') for r in results),'Night場数':sum(r['session'].endswith('_Night') for r in results),
        '対象分数':total_masks,'session_complete場数':sum(r['session_complete'] for r in results),
        'session_price_complete場数':sum(r['session_price_complete'] for r in results),'session_volume_complete場数':sum(r['session_volume_complete'] for r in results),
        'observed_contiguous_segment_known終端場数':sum(r['observed_contiguous_segment_known'] for r in results),
        'observed_contiguous_segment_exists場数':sum(r['observed_contiguous_segment_exists'] for r in results),
        'counts':dict(all_counts),'known量0かつ価格未知分数':all_counts['volume_known_zero_price_unknown_minutes']}
    for key,value in derived.items():assert summary[key]==value,key
    assert summary['累積代金量差アンカー可否'] is None and summary['価格又は量の生値出力'] is False
    assert summary['追加2場参照'] is False and detail['price_or_volume_values_saved'] is False
    for name,(path,h) in PINS.items():assert sha(path)==h,name
    for path,h in fixed.items():assert sha(path)==h,path
    for name,h in preparation['コードSHA256'].items():assert sha(OWN/name)==h
    report={'成功':True,'段階':'Root許可後の73CSV独立品質照合・編集停止','試行':None,'F0_SHA256':PINS['F0'][1],
        '正本gzipSHA256':PINS['detail'][1],'正本要約SHA256':PINS['summary'][1],'F0全源一致':len(fixed),
        '全場一致':73,'全minute_mask辞書一致':total_masks,'全scene要約辞書一致':73,'要約独立再計数':derived,
        '別保管3場参照対応一致':alternates,'RawとCSV内容同体を証明':False,'生成量不完全flag数':len(incomplete_flags),
        '生成量不完全は全て先頭CSVデータ行か':all(r['first_data_line'] for r in incomplete_flags),
        '場別小型証跡':scene_proofs,'入力とコード前後同体':True,'作者_Root品質関数import':False,
        '生価格_量値保存':False,'Raw_金融_追加2場読取':False,'新birth又は141採番又は測定選定':False,
        '用途':'offline品質監査のみ。未来全file/最長区間/最終完備をオンラインborn/anchorへ使わない。joint falseは全VWAP数学不能の証明ではない。',
        '初回準備SHA256':initial_preparation_sha,'準備SHA256':sha(supplement) if supplement.exists() else initial_preparation_sha,
        '独立コードSHA256':preparation['コードSHA256']}
    with (OWN/'独立照合.json').open('x',encoding='utf-8') as stream:json.dump(report,stream,ensure_ascii=False,indent=2);stream.write('\n')
    print(json.dumps({'成功':True,'全場':73,'全mask':total_masks,'F0源':len(fixed),'独立照合SHA256':sha(OWN/'独立照合.json'),
        '量不完全flag':len(incomplete_flags),'全て先頭行':report['生成量不完全は全て先頭CSVデータ行か']},ensure_ascii=False))


if __name__=='__main__':main()
