"""停止仕様を独立に実装したCSV品質算術。作者モジュールをimportしない。"""
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
import csv
import io
import math
import re

COLS=('time','open','high','low','close','volume','volume_complete','closed')
COUNT_KEYS=('records','utf8_invalid','header_invalid','row_width_invalid','multiline_record','clock_invalid',
    'adjacent_backward','below_maximum_clock','off_grid_continuous','csv_parse_error','missing_minutes',
    'duplicate_slots','duplicate_extra_records','backward_slots','price_known_minutes','volume_known_minutes',
    'joint_known_minutes','volume_known_zero_minutes','volume_unknown_zero_minutes','volume_known_positive_minutes',
    'volume_known_zero_price_unknown_minutes')


def parse_number(cell: str) -> tuple:
    """
    機能: 数値を内部だけで解釈し、数量セルの分類を返す。
    引数: cell(str)は原セル。
    返り値: tuple[float|None,str]。有限原値は呼出し内でのみ使う。
    """
    if cell=='':return None,'empty'
    if cell!=cell.strip():return None,'invalid'
    try:n=float(cell)
    except ValueError:return None,'invalid'
    if not math.isfinite(n):return None,'nonfinite'
    if n<0:return n,'negative'
    return n,'zero' if n==0 else 'positive'


# ----------------------------------------
def parse_time(cell: str) -> tuple:
    """
    機能: RFC3339の各成分とoffset範囲を独立に検査する。
    引数: cell(str)はtimeラベル。
    返り値: tuple[float|None,bool]はUnix秒・非0小数秒の有無。
    """
    m=re.fullmatch(r'(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.(\d{1,9}))?(Z|[+-]\d{2}:\d{2})',cell)
    if m is None:return None,False
    year,month,day,hour,minute,second=(int(x) for x in m.groups()[:6]);fraction=m.group(7) or '';zone=m.group(8)
    offset=0
    if zone!='Z':
        zh,zm=int(zone[1:3]),int(zone[4:6])
        if zh>23 or zm>59:return None,False
        offset=(zh*60+zm)*(1 if zone[0]=='+' else -1)
    try:
        micros=int((fraction+'000000')[:6])
        at=datetime(year,month,day,hour,minute,second,micros,tzinfo=timezone(timedelta(minutes=offset))).timestamp()
    except (ValueError,OverflowError):return None,False
    return (at,any(x!='0' for x in fraction)) if math.isfinite(at) else (None,False)


# ----------------------------------------
def source_fields(cells: list[str], line: int, backward: bool) -> dict:
    """
    機能: 一意に置ける行の価格・数量・旗を値なしのbooleanへ射影する。
    引数: cells(list[str])、line(int)、backward(bool)は原行と原順状態。
    返り値: dictは品質だけ。価格・数量そのものは格納しない。
    """
    prices=[parse_number(x)[0] for x in cells[1:5]]
    price_finite=all(x is not None for x in prices)
    positive=price_finite and min(prices)>0
    shape=bool(positive and prices[2]<=min(prices[0],prices[3]) and max(prices[0],prices[3])<=prices[1] and prices[2]<=prices[1])
    volume,kind=parse_number(cells[5]);ck=cells[7] in ('true','false');vk=cells[6] in ('true','false')
    return {'source_line':line,'invalid_record':False,'backward':backward,'closed_known':ck,'closed':cells[7]=='true' if ck else False,
        'volume_complete_known':vk,'volume_complete':cells[6]=='true' if vk else False,
        'price_finite':price_finite,'price_positive':bool(positive),'price_shape':shape,
        'volume_valid':volume is not None and volume>=0,'volume_cell_kind':kind,
        'volume_zero':volume is not None and volume==0,'volume_positive':volume is not None and volume>0}


# ----------------------------------------
def classify_csv(body: bytes, scene: dict) -> dict:
    """
    機能: 一場CSVを独立に解析し、固定ザラバ格子と全品質maskを算出する。
    引数: body(bytes)、scene(dict)はCSVとsession/contract/start/end。
    返り値: dictは正本契約と同じ品質項目。値・VWAP・金融を含まない。
    """
    start=scene['start'];end=scene['end'];limit=end-300;size=int((limit-start)/60)
    assert size>0 and start+size*60==limit
    counts=Counter({k:0 for k in COUNT_KEYS});scopes={x:Counter() for x in ('before','continuous','preclosing','after')}
    grid=defaultdict(list);ambiguous=False;previous=None;largest=None
    try:text=body.decode('utf-8-sig')
    except UnicodeDecodeError:text='';ambiguous=True;counts['utf8_invalid']+=1
    reader=csv.reader(io.StringIO(text,newline=''),strict=True)
    header_ok=False
    try:
        header_ok=tuple(next(reader,[]) or ())==COLS
        if not header_ok:counts['header_invalid']+=1;ambiguous=True
        while True:
            line=reader.line_num+1
            try:cells=next(reader)
            except StopIteration:break
            counts['records']+=1
            if not header_ok:continue
            width=len(cells)==8;one_line=reader.line_num==line
            if not width:counts['row_width_invalid']+=1
            if not one_line:counts['multiline_record']+=1
            at,fraction=parse_time(cells[0]) if cells else (None,False)
            if at is None:counts['clock_invalid']+=1;ambiguous=True;continue
            area='before' if at<start else 'continuous' if at<limit else 'preclosing' if at<end else 'after'
            sc=scopes[area];sc['records']+=1
            backward=largest is not None and at<largest
            if previous is not None and at<previous:counts['adjacent_backward']+=1
            if backward:counts['below_maximum_clock']+=1
            previous=at;largest=at if largest is None else max(largest,at)
            on_grid=not fraction and (at-start)%60==0
            if area=='continuous' and not on_grid:counts['off_grid_continuous']+=1;ambiguous=True
            if not width or not one_line:
                if area=='continuous' and on_grid:grid[at].append({'source_line':line,'invalid_record':True,'backward':backward})
                continue
            flags=source_fields(cells,line,backward)
            sc['closed_true' if flags['closed_known'] and flags['closed'] else 'closed_false' if flags['closed_known'] else 'closed_unknown']+=1
            sc['volume_complete_true' if flags['volume_complete_known'] and flags['volume_complete'] else 'volume_complete_false' if flags['volume_complete_known'] else 'volume_complete_unknown']+=1
            sc['volume_cell_'+flags['volume_cell_kind']]+=1
            if area=='continuous' and on_grid:grid[at].append(flags)
    except csv.Error:counts['csv_parse_error']+=1;ambiguous=True
    masks=[];pp=True;vp=True;jp=True;prefix_positive=False;current_start=None;length=0;segment_id=0;positive_seen=False;breaks=0;first_failure=None
    checks=('closed_known','closed','price_finite','price_positive','price_shape','volume_complete_known','volume_complete','volume_valid')
    for index in range(size):
        at=start+60*index;items=grid.get(at,[]);unique=len(items)==1;value=items[0] if unique else {}
        absent=len(items)==0;duplicate=len(items)>1;backward=any(x.get('backward',False) for x in items);invalid=bool(value.get('invalid_record',False))
        structure=not(ambiguous or absent or duplicate or backward or invalid)
        closed=structure and value.get('closed_known',False) and value.get('closed',False)
        pk=bool(closed and all(value.get(k,False) for k in ('price_finite','price_positive','price_shape')))
        vk=bool(closed and all(value.get(k,False) for k in ('volume_complete_known','volume_complete','volume_valid')))
        joint=pk and vk;zero=bool(vk and value.get('volume_zero',False));unknown_zero=bool(not vk and any(x.get('volume_zero',False) for x in items))
        why=[]
        for flag,label in ((ambiguous,'file_structure_ambiguous'),(absent,'missing'),(duplicate,'duplicate'),(backward,'clock_backward'),(invalid,'invalid_record')):
            if flag:why.append(label)
        if structure:why += [k for k in checks if not value.get(k,False)]
        if not joint and first_failure is None:first_failure={'start':at,'reasons':why.copy()}
        pp=pp and pk;vp=vp and vk;jp=jp and joint
        prefix_positive=bool(jp and (prefix_positive or value.get('volume_positive',False)))
        if joint:
            if current_start is None:current_start=at;segment_id+=1;length=0;positive_seen=False
            length+=1;positive_seen=positive_seen or value.get('volume_positive',False)
        else:
            if current_start is not None:breaks+=1
            current_start=None;length=0;positive_seen=False
        additions={'missing_minutes':absent,'duplicate_slots':duplicate,'duplicate_extra_records':max(0,len(items)-1),
            'backward_slots':backward,'price_known_minutes':pk,'volume_known_minutes':vk,'joint_known_minutes':joint,
            'volume_known_zero_minutes':zero,'volume_unknown_zero_minutes':unknown_zero,
            'volume_known_positive_minutes':bool(vk and value.get('volume_positive',False)),
            'volume_known_zero_price_unknown_minutes':zero and not pk}
        for key,n in additions.items():counts[key]+=int(n)
        meaningful=unique and not invalid
        mask={'start':at,'end':at+60,'source_lines':[x['source_line'] for x in items],
            'source_closed_known':bool(meaningful and value.get('closed_known',False)),
            'source_closed':value.get('closed') if meaningful and value.get('closed_known',False) else None,
            'source_volume_complete_known':bool(meaningful and value.get('volume_complete_known',False)),
            'source_volume_complete':value.get('volume_complete') if meaningful and value.get('volume_complete_known',False) else None,
            'source_price_finite':value.get('price_finite') if meaningful else None,'source_price_shape':value.get('price_shape') if meaningful else None,
            'source_volume_numeric_valid':value.get('volume_valid') if meaningful else None,'source_volume_cell_kind':value.get('volume_cell_kind') if meaningful else None,
            'price_known':pk,'volume_known':vk,'volume_known_zero':zero,'volume_unknown_zero':unknown_zero,'joint_known':joint,
            'session_price_prefix_complete':bool(pp),'session_volume_prefix_complete':bool(vp),'session_complete':bool(jp),
            'session_prefix_weighted_mean_possible':bool(jp and prefix_positive),'observed_contiguous_segment_known':joint,
            'segment_id':segment_id if joint else None,'segment_start':current_start,'segment_minutes':length,
            'segment_positive_weight_seen':bool(positive_seen),'segment_weighted_mean_possible':bool(joint and positive_seen),
            'missing':absent,'duplicate':duplicate,'backward':bool(backward),'reasons':why}
        masks.append(mask)
    return {'session':scene['session'],'contract':scene['contract'],'start':start,'session_end':end,'continuous_end':limit,'expected_minutes':size,
        'header_valid':header_ok,'file_structure_ambiguous':ambiguous,'counts':dict(counts),'scope_counts':{k:dict(v) for k,v in scopes.items()},
        'first_minute':masks[0],'first_prefix_failure':first_failure,'session_complete':bool(jp),'session_price_complete':bool(pp),'session_volume_complete':bool(vp),
        'observed_contiguous_segment_known':masks[-1]['observed_contiguous_segment_known'],
        'observed_contiguous_segment_exists':any(m['observed_contiguous_segment_known'] for m in masks),
        'segment_count':segment_id,'known_segment_breaks':breaks,'masks':masks,
        'measurement_note':'OHLCV完備性という保守的な十分条件。known量0/価格未知の寄与0等を含む他の数学的可否を否定しない。WS/全約定の独立完全性、真session VWAPの認定ではない',
        'contract_join':'固定metadataのsession/pathへ結合。CSVに限月列はなく独立照合不可','price_or_volume_values_saved':False}
