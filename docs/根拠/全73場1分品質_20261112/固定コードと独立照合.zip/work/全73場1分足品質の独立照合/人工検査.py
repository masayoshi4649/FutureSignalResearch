"""独立品質算術を人工CSVだけで検査する。作者関数は呼ばない。"""
import csv
from datetime import datetime, timezone
import importlib.util
import io
from pathlib import Path
import unittest

P=Path(__file__).with_name('独立品質.py')
S=importlib.util.spec_from_file_location('独立品質の人工',P);M=importlib.util.module_from_spec(S);S.loader.exec_module(M)
BASE=datetime(2026,9,21,tzinfo=timezone.utc).timestamp()


def row(i: int, volume: str='1', flag: str='true', closed: str='true') -> list[str]:
    """
    機能: 人工時刻と人工OHLCVの1分行を作る。
    引数: i(int)、volume/flag/closed(str)は分位置とセル。
    返り値: list[str]は8セル。自然価格は使わない。
    """
    stamp=datetime.fromtimestamp(BASE+60*i,timezone.utc).isoformat().replace('+00:00','Z')
    return [stamp,'100','105','95','101',volume,flag,closed]


# ----------------------------------------
def calc(rows: list[list[str]], n: int=4) -> dict:
    """
    機能: 人工CSVを独立算術へ入力する。
    引数: rows(list[list[str]])、n(int)は行と対象分数。
    返り値: dictは値なし品質結果。
    """
    stream=io.StringIO(newline='');w=csv.writer(stream);w.writerow(M.COLS);w.writerows(rows)
    return M.classify_csv(stream.getvalue().encode(),{'session':'人工','contract':'人工','start':BASE,'end':BASE+60*n+300})


# ----------------------------------------
class Tests(unittest.TestCase):
    """独立算術そのものの境界を確認する。"""

    def test_grid_and_prefix_loss(self) -> None:
        """
        機能: 分開始/終端、欠足後prefix不可逆と区間回復を検査する。
        引数: self(Tests)。返り値: None。
        """
        r=calc([row(0),row(2),row(3),row(4,closed='false')])
        self.assertEqual([m['session_complete'] for m in r['masks']],[True,False,False,False])
        self.assertEqual(r['masks'][2]['segment_id'],2);self.assertEqual(r['masks'][0]['end'],BASE+60)
        self.assertEqual(r['scope_counts']['preclosing']['closed_false'],1)
        self.assertTrue(r['observed_contiguous_segment_known']);self.assertFalse(r['session_complete'])

    def test_zero_unknown_and_contribution(self) -> None:
        """
        機能: known0/unknown0/価格未知known0を区別する。
        引数: self(Tests)。返り値: None。
        """
        rows=[row(0,'0'),row(1,'0','false'),row(2,'0'),row(3,'1')];rows[2][1]=''
        r=calc(rows)
        self.assertEqual(r['counts']['volume_known_zero_minutes'],2)
        self.assertEqual(r['counts']['volume_unknown_zero_minutes'],1)
        self.assertEqual(r['counts']['volume_known_zero_price_unknown_minutes'],1)
        self.assertFalse(r['masks'][2]['joint_known']);self.assertTrue(r['masks'][2]['volume_known_zero'])

    def test_duplicates_backward_and_ambiguous_clock(self) -> None:
        """
        機能: 原順と一意性を修復せず、時計不明は全域曖昧とする。
        引数: self(Tests)。返り値: None。
        """
        dup=calc([row(0),row(1),row(1),row(2),row(3)])
        self.assertTrue(dup['masks'][1]['duplicate']);self.assertIsNone(dup['masks'][1]['source_closed'])
        back=calc([row(0),row(2),row(1),row(3)])
        self.assertTrue(back['masks'][1]['backward'])
        rows=[row(i) for i in range(4)];rows[1][0]='時刻不明'
        a=calc(rows);self.assertTrue(a['file_structure_ambiguous']);self.assertFalse(a['observed_contiguous_segment_exists'])

    def test_clock_and_numeric_validation(self) -> None:
        """
        機能: 不正offset/非0ナノ秒/非有限数値を区別する。
        引数: self(Tests)。返り値: None。
        """
        self.assertIsNone(M.parse_time('2026-09-21T09:00:00+09:99')[0])
        self.assertTrue(M.parse_time('2026-09-21T09:00:00.000000001+09:00')[1])
        rows=[row(i) for i in range(4)];rows[1][2]='NaN';rows[2][5]='-1'
        r=calc(rows);self.assertFalse(r['masks'][1]['price_known']);self.assertFalse(r['masks'][2]['volume_known'])

    def test_last_segment_and_source_flags(self) -> None:
        """
        機能: 区間存在と終端状態、生成旗とderived knownを区別する。
        引数: self(Tests)。返り値: None。
        """
        r=calc([row(0),row(1),row(2),row(3,closed='false')])
        self.assertTrue(r['observed_contiguous_segment_exists']);self.assertFalse(r['observed_contiguous_segment_known'])
        self.assertTrue(r['masks'][3]['source_closed_known']);self.assertFalse(r['masks'][3]['source_closed'])
        self.assertFalse(r['masks'][3]['price_known'])


if __name__=='__main__':unittest.main(verbosity=2)
