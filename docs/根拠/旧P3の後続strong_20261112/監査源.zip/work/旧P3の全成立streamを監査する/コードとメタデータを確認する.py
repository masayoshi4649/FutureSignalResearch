"""旧P3/L0とE1のfirst-only範囲を固定コードと既存metadataだけで監査する。"""
from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
META = ROOT/'work/137既知回復の評価/固定入力/方向と出生.json'
META_SHA = '86f33705ba40fd3ba1b845557a2368e44c2802635082fc3bad69346770103f93'
FILES = {
    '123 first-only': ('work/123全場参加の入口比較/entry.go', ('covered[policy] || hasPending123', 'supplements > 1')),
    '133 first-only': ('work/強い入口の探索期限を延ばす次仮説/Source入口の再生器/entry.go',
        ('covered[c.Policy] = true', 'if covered[c.Policy]', 'covered[policy] || hasPending133', 'supplements > 1', 'return s.Start + 10800', 'if c.Path != "E0"', 'func supplement133')),
    '133 technical': ('work/強い入口の探索期限を延ばす次仮説/Source入口の再生器/score.go',
        ('func score133', 'score :=', 'func strong133', 'c["RVOL5"].Value < 1', 'math.Abs(d.Score.Value) < .5', 'c["ADX5"].Value >= c["previous_ADX5"].Value')),
    '133 clock': ('work/強い入口の探索期限を延ばす次仮説/Source入口の再生器/clock.go', ('s.End-300-3600',)),
    '133 direction': ('work/強い入口の探索期限を延ばす次仮説/Source入口の再生器/direction.go', ('ratio.Value >= .5', 'histATR.Value >= .1', 'protected := path == "E0"')),
    '137 legacy': ('work/137既知回復をSourceへ接続する/Source再生器/entry.go', ('covered[policy] || hasPending133', 'supplements > 1', 'observer.Accepted')),
    '137 observer': ('work/137既知回復をSourceへ接続する/Source再生器/observer.go', ('func (o *e1Observer) Accepted', 'o.Detector.Observe', 'o.Events = append', 'o.Candidates = append', 'cancelled_e0_priority')),
    '137 frequency': ('work/137既知回復をSourceへ接続する/Source再生器/frequency.go', ('func frequencyE1Scene', 'for _, c := range extra', 'if c.Entry == nil', 'if seen[key]')),
    '137 full source': ('work/137既知回復をSourceへ接続する/Source再生器/run_e1.go', ('out.E1Events = observer.Events', 'out.E1Candidates = observer.Candidates', 'out.FrequencyA0')),
    '137 state': ('work/137公表時に既知の短期回復を確認する/state.go', ('if d.used[key]', 'q.Time-at < 600', 'd.used[key] = true', 'func (d *Detector) improve', 'func (d *Detector) recover')),
    '137 background': ('work/137公表時に既知の短期回復を確認する/helpers.go', ('func context', 's.RVOL5.Value < .5', 'd.ADX.Value < 20', 'func quantity', 'func rejection')),
    '137 selection': ('work/押戻し回復の取得を時系列で選ぶ/select.go', ('func Select', 'if !e0Seen && !complementSelected')),
    '118 notifications': ('work/118入口比較/entry.go', ('Signals          []Signal118', 'for bi < len(signals)', 'for _, p := range Policies118', 'if c.Policy == "M0"', 'holding = active')),
    '138 pool': ('work/全成立poolの非金融manifest/条件.md', ('旧137A0の81件', 'Raw即時128', '元Source保有状態に依存')),
}


def sha(body: bytes) -> str:
    """
    機能: 読取bytesの指紋を返す。
    引数: body(bytes)。返り値: str。
    """
    return hashlib.sha256(body).hexdigest()


def main() -> None:
    """
    機能: 正確なコード行と旧70の型内訳を保存する。
    引数: なし。返り値: None。新価格・金融・Raw・CSVを読まない。
    """
    before = {}; evidence = []
    for role, (relative, needles) in FILES.items():
        p = ROOT/relative; body = p.read_bytes(); before[p] = sha(body); lines = body.decode('utf-8-sig').splitlines()
        matches = []
        for needle in needles:
            hits = [{'line': i+1, 'text': line.strip()} for i, line in enumerate(lines) if needle in line]
            assert hits, (relative, needle)
            matches.append({'needle': needle, 'lines': hits})
        evidence.append({'role': role, 'path': relative, 'sha256': before[p], 'evidence': matches})
    body = META.read_bytes(); assert sha(body) == META_SHA
    meta = json.loads(body); rows = [r for r in meta['entries'] if r['model'] == 'A0']
    assert len(rows) == 81
    kinds = Counter((r['kind'], r['direction_policy']) for r in rows)
    l0 = [r for r in rows if r['kind'] == 'L0']; assert len(l0) == 70
    by_type = Counter((r['path'], r['strategy']) for r in l0)
    assert by_type == {('strong', 'trend'): 31, ('strong', 'reversal'): 1, ('deadline', 'deadline'): 38}
    assert all(r['direction_policy'] == 'fixedT8' for r in l0)
    assert all(r['direction_policy'] == 'pattern' for r in rows if r['kind'] == 'E1')
    assert all(sha(p.read_bytes()) == h for p, h in before.items()) and sha(META.read_bytes()) == META_SHA
    out = {'成功': True, '新採番': False, 'コード読取のみ': True, '元metadataの分類だけ読取': True,
        '元metadata': {'path': str(META.relative_to(ROOT)), 'sha256': META_SHA},
        '旧81の適用': [{'kind': k, 'direction_policy': p, 'count': n} for (k, p), n in sorted(kinds.items())],
        '旧L0補完70': [{'path': p, 'strategy': s, 'count': n} for (p, s), n in sorted(by_type.items())],
        '旧L0取得後続を全て生成した対照': '確認した123/133/137および138素材には無い。coveredでscore評価前に停止',
        '旧E1全stream': '137が技術状態制約内の全出生/要求/取得を保存、A0へ全取得追加済み',
        '注意': ['coveredは実口座保有ではなく、その場で既に取得したという永続参加フラグ',
                 'coveredだけ外すと3h以後deadlineが原行ごと再要求し、同じ状態の回数水増しを起こし得る',
                 '新5分ID+side等の消費/再準備は次試行でF0前に定義する対象で、ここでは採用しない'],
        'コード根拠': evidence, '原板CSV読取': False, '新Source生成': False, '新金融読取算出': False,
        '追加2場読取': False, '旧源変更': False, '前後SHA同体': True}
    path = OWN/'同一domain対照の有無.json'
    path.write_text(json.dumps(out, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'成功': True, 'sha256': sha(path.read_bytes()), '旧70型': out['旧L0補完70']}, ensure_ascii=True))


if __name__ == '__main__':
    main()
