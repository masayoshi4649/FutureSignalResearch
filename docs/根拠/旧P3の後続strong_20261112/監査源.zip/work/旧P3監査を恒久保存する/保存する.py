"""旧P3後続stream監査の小成果と14源の既存恒久参照を保存する。"""
from pathlib import Path
import gzip
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[2]
SOURCE=ROOT/'work/旧P3の全成立streamを監査する'
TARGET=ROOT/'docs/根拠/旧P3の後続strong_20261112'


def sha(raw: bytes) -> str:
    """
    機能: 明示した原文の指紋を求める。
    引数: raw(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(raw).hexdigest()


# ----------------------------------------
def groups(value: object) -> list:
    """
    機能: 保存索引からZIPと格納源の組を再帰列挙する。
    引数: value(object)はJSON要素。
    返り値: list[dict]。
    """
    out=[]
    if isinstance(value,dict):
        if ('ZIP' in value or '保存元ZIP' in value) and '格納源' in value:out.append(value)
        for nested in value.values():out.extend(groups(nested))
    elif isinstance(value,list):
        for nested in value:out.extend(groups(nested))
    return out


# ----------------------------------------
def descriptors(value: object) -> list:
    """
    機能: 一度保存済みの生成入力descriptorを再帰列挙する。
    引数: value(object)はJSON要素。
    返り値: list[dict]。
    """
    out=[]
    if isinstance(value,dict):
        if '保存元' in value and '解凍SHA256' in value:out.append(value)
        for nested in value.values():out.extend(descriptors(nested))
    elif isinstance(value,list):
        for nested in value:out.extend(descriptors(nested))
    return out


# ----------------------------------------
def main() -> None:
    """
    機能: 監査正本を一度保存し、既存133/137/138等からコード14源を共有する。
    引数: なし。
    返り値: None。旧試行/Source/新自然価格/新金融/144条件を操作しない。
    """
    proofraw=(SOURCE/'監査の確認.json').read_bytes();proof=json.loads(proofraw)
    assert proof['成功'] and proof['編集停止']
    for item in proof['保存資料']:assert sha(Path(item['path']).read_bytes())==item['sha256']
    auditraw=(SOURCE/'同一domain対照の有無.json').read_bytes();audit=json.loads(auditraw)
    needed={r['sha256']:r for r in audit['コード根拠']};assert len(needed)==14
    before={ROOT/r['path']:sha((ROOT/r['path']).read_bytes()) for r in needed.values()}
    assert all(before[ROOT/r['path']]==r['sha256'] for r in needed.values())
    found={};metadata=None
    indices=sorted((ROOT/'study').glob('*/保管索引.json'),reverse=True)
    for index in indices:
        doc=json.loads(index.read_bytes())
        for group in groups(doc):
            zp=ROOT/group['保存元ZIP'] if '保存元ZIP' in group else index.parent/'再現資料'/group['ZIP']
            entries=[e for e in group['格納源'] if e.get('sha256') in needed and e['sha256'] not in found]
            if not entries or not zp.exists():continue
            raw=zp.read_bytes();expected=group.get('ZIP_SHA256')
            if expected is not None:assert sha(raw)==expected
            with zipfile.ZipFile(zp) as z:
                for item in entries:
                    entry=item.get('ZIP内path',item.get('path'));body=z.read(entry);h=sha(body);assert h==item['sha256']
                    found[h]={'保存元ZIP':zp.relative_to(ROOT).as_posix(),'ZIP_SHA256':sha(raw),'ZIP内path':entry,'sha256':h,'bytes':len(body)}
        if metadata is None:
            for item in descriptors(doc):
                if item['解凍SHA256']==audit['元metadata']['sha256']:
                    raw=(ROOT/item['保存元']).read_bytes();assert sha(raw)==item['保存SHA256']
                    decoded=gzip.decompress(raw) if item['形式']=='gzip' else raw;assert sha(decoded)==item['解凍SHA256']
                    metadata=item;break
        if len(found)==14 and metadata is not None:break
    # ----------------------------------------
    # 古い保存索引に格納源がない場合も、既存ZIPのコードだけを候補にする。
    if len(found)<14:
        basenames={Path(r['path']).name for h,r in needed.items() if h not in found}
        for zp in sorted((ROOT/'study').glob('*/再現資料/*.zip')):
            with zipfile.ZipFile(zp) as z:
                for item in z.infolist():
                    if Path(item.filename).name not in basenames or item.file_size>1000000:continue
                    body=z.read(item);h=sha(body)
                    if h in needed and h not in found:found[h]={'保存元ZIP':zp.relative_to(ROOT).as_posix(),'ZIP_SHA256':sha(zp.read_bytes()),'ZIP内path':item.filename,'sha256':h,'bytes':len(body)}
            if len(found)==14:break
    assert len(found)==14,[(r['role'],r['path']) for h,r in needed.items() if h not in found]
    assert metadata is not None
    TARGET.mkdir(parents=True,exist_ok=True)
    (TARGET/'監査の確認.json').write_bytes(proofraw)
    (TARGET/'同一domain対照の有無.json').write_bytes(auditraw)
    archive=TARGET/'監査源.zip';items=[]
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name in ('コードとメタデータを確認する.py','同じ入口を増やした対照の有無.md'):
            p=SOURCE/name;raw=p.read_bytes();rel=p.relative_to(ROOT).as_posix();z.writestr(rel,raw);items.append({'path':rel,'sha256':sha(raw),'bytes':len(raw)})
        p=Path(__file__);raw=p.read_bytes();rel=p.relative_to(ROOT).as_posix();z.writestr(rel,raw);items.append({'path':rel,'sha256':sha(raw),'bytes':len(raw)})
    references=[{'役割':r['role'],'復元先':r['path'],**found[r['sha256']]} for r in audit['コード根拠']]
    index={'確認日':'2026-11-12','対象':'旧P3/L0後続strongの未評価対照の監査','新試行/144条件/新数値採用':False,
        '監査JSON_SHA256':sha(auditraw),'停止proof_SHA256':sha(proofraw),
        '監査源ZIP':{'保存元ZIP':archive.relative_to(ROOT).as_posix(),'ZIP_SHA256':sha(archive.read_bytes()),'ZIP_bytes':archive.stat().st_size,'格納源':items},
        'コード14源':references,'旧137分類metadata共有':metadata,'原板/巨大入力/古いコード源の新複写':False}
    (TARGET/'保管索引.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    assert all(sha(p.read_bytes())==h for p,h in before.items())
    print(json.dumps({'成功':True,'コード14源共有':True,'監査JSON_SHA256':sha(auditraw),'停止proof_SHA256':sha(proofraw),
        '保存索引SHA256':sha((TARGET/'保管索引.json').read_bytes()),'監査源ZIP_SHA256':sha(archive.read_bytes()),'ZIPbytes':archive.stat().st_size},ensure_ascii=False))


if __name__=='__main__':main()
