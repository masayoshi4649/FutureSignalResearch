"""旧L070のstrong/deadlineを分け、元P3方向とT8の保存実BBOだけを比較する。"""
from collections import Counter
from fractions import Fraction
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
FILES = {'metadata': ('work/137既知回復の評価/固定入力/方向と出生.json', '86f33705ba40fd3ba1b845557a2368e44c2802635082fc3bad69346770103f93'),
         'observed': ('work/138全成立入口の評価/固定取得の正逆観測.json', 'd272fc6f6768342ff67e1a9ec58b0b7307a0a5b07cc215ba5ff7bcb50865b742')}
LABELS = ('順行', '逆行', '未到達', 'H不足')


def sha(body: bytes) -> str:
    """
    機能: bytesのSHA256を求める。
    引数: body(bytes)。返り値: str。
    """
    return hashlib.sha256(body).hexdigest()


def measure(stream: dict) -> dict:
    """
    機能: H60±125先着と保存Quote清算のC5を独立計算する。
    引数: stream(dict)。返り値: dict。H不足touchは主率とIFDで分ける。
    """
    h = next(h for h in stream['outcomes'] if h['seconds'] == 3600)
    t = next(t for t in h['touches'] if t['width'] == 125)
    assert t['direction'] in (-1, 0, 1) and (t['quote'] is None) == (t['direction'] == 0)
    complete = h['status'] == 'complete'
    result = 'H不足' if not complete else '順行' if t['direction'] == 1 else '逆行' if t['direction'] == -1 else '未到達'
    q = t['quote'] if t['direction'] else h['endpoint'] if complete else None
    side = stream['birth']['side']; entry = stream['entry']
    assert stream['entry_price'] == (entry['ask'] if side == 1 else entry['bid'])
    money = None if q is None else 100*side*((q['bid'] if side == 1 else q['ask'])-stream['entry_price'])-1077
    return {'result': result, 'H_complete': complete, 'touch_direction': t['direction'],
            'IFD_known': q is not None, 'C5': money, 'exit_kind': '到達' if t['direction'] else '期限清算' if complete else '観測不足'}


def stats(rows: list, policy: str) -> dict:
    """
    機能: 全件・先着分母とC5利益損失未知を分ける。
    引数: rows(list)、policy(str)。返り値: dict。
    """
    c = Counter(r[policy]['result'] for r in rows)
    resolved = c['順行']+c['逆行']; complete = len(rows)-c['H不足']
    net = [r[policy]['C5'] for r in rows if r[policy]['IFD_known']]
    profit = sum(v for v in net if v > 0); loss = -sum(v for v in net if v < 0)
    return {'count': len(rows), **{k: c[k] for k in LABELS}, 'complete': complete,
        'resolved_fraction': str(Fraction(c['順行'], resolved)) if resolved else None,
        'resolved_rate': c['順行']/resolved if resolved else None,
        'complete_rate': c['順行']/complete if complete else None,
        'IFD_known': len(net), 'IFD_unknown': len(rows)-len(net),
        'C5_profit': profit, 'C5_loss_absolute': loss, 'C5_net': sum(net), 'C5_PF': profit/loss if loss else None}


def compare(rows: list) -> dict:
    """
    機能: 元P3→T8行列と同一ペア差を示す。
    引数: rows(list)。返り値: dict。
    """
    matrix = {a: {b: 0 for b in LABELS} for a in LABELS}
    pairs = []; known = Counter()
    for r in rows:
        a, b = r['source_P3'], r['fixed_T8']
        matrix[a['result']][b['result']] += 1; known[(a['IFD_known'], b['IFD_known'])] += 1
        if a['IFD_known'] and b['IFD_known']: pairs.append(b['C5']-a['C5'])
    return {'source_P3': stats(rows, 'source_P3'), 'fixed_T8': stats(rows, 'fixed_T8'),
        'direction_changed': sum(r['source_side'] != r['selected_side'] for r in rows),
        'matrix_source_to_T8': matrix, 'both_IFD_known': len(pairs), 'paired_C5_difference_T8_minus_source': sum(pairs),
        'source_known_to_T8_unknown': known[(True, False)], 'source_unknown_to_T8_known': known[(False, True)],
        'both_IFD_unknown': known[(False, False)]}


def main() -> None:
    """
    機能: 旧70だけを結合し強条件と期限補完を排他的に比較する。
    引数: なし。返り値: None。旧81全体や新しいSourceを混ぜない。
    """
    docs = {}
    for key, (path, expected) in FILES.items():
        b = (ROOT/path).read_bytes(); assert sha(b) == expected; docs[key] = json.loads(b)
    meta, observed = docs['metadata'], docs['observed']; rows = []
    selected = {r['id']: r for r in meta['entries'] if r['model'] == 'A0' and r['kind'] == 'L0'}
    assert len(selected) == 70
    seen = set()
    for scene in observed['scenes']:
        for case in scene['cases']:
            if not case['id'].startswith('C0/'):
                continue
            identity = case['id'][len('C0/'):]
            if identity not in selected:
                continue
            r = selected[identity]; assert r['direction_policy'] == 'fixedT8'
            assert r['source_side'] == r['birth']['side'] == r['direction']['source_side']
            assert r['selected_side'] == r['direction']['selected_side'] == r['direction']['t8_side']
            assert r['session'] == scene['session'] and case['original_side'] == r['selected_side']
            assert case['original']['entry'] == case['reverse']['entry'] == r['entryQuote']
            source_stream = case['original'] if r['source_side'] == r['selected_side'] else case['reverse']
            assert source_stream['birth']['side'] == r['source_side']
            rows.append({'id': identity, 'session': r['session'], 'path': r['path'], 'strategy': r['strategy'],
                'source_side': r['source_side'], 'selected_side': r['selected_side'],
                'source_stream_name': 'original' if source_stream is case['original'] else 'reverse',
                'source_P3': measure(source_stream), 'fixed_T8': measure(case['original'])})
            assert identity not in seen; seen.add(identity)
    assert seen == set(selected)
    strong = [r for r in rows if r['path'] == 'strong']; deadline = [r for r in rows if r['path'] == 'deadline']
    assert len(strong) == 32 and len(deadline) == 38
    assert Counter(r['strategy'] for r in strong) == {'trend': 31, 'reversal': 1}
    result = {'success': True, 'trial': None, 'main_scope': '旧L0補完70だけ、E0/E1非混合',
        'strong32': compare(strong), 'deadline38': compare(deadline), 'all_L0_70': compare(rows),
        'strong_trend31': compare([r for r in strong if r['strategy'] == 'trend']),
        'strong_reversal1': compare([r for r in strong if r['strategy'] == 'reversal']),
        'details': rows, 'sources': {k: {'path': p, 'sha256': h} for k, (p, h) in FILES.items()},
        'new_raw_or_source': False, 'new_parameters': False, 'unused_period_claim': False}
    assert all(sha((ROOT/p).read_bytes()) == h for p, h in FILES.values())
    p = OWN/'Strongと期限の元方向対T8.json'; p.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({k: result[k] for k in ('strong32', 'deadline38', 'strong_trend31', 'strong_reversal1')}, ensure_ascii=True))


if __name__ == '__main__':
    main()
