"""旧Strong32の元P3対T8を別根拠として追加し、旧監査は不変更で残す。"""
from pathlib import Path
import gzip
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[2]
SOURCE=ROOT/'work/旧Strongと期限補完の方向を分ける'
TARGET=ROOT/'docs/根拠/旧Strong32の方向比較_20261112'
DOC=ROOT/'docs/議論/旧P3の後続strongを全時間で評価する方針.md'


def sha(raw: bytes) -> str:
    """
    機能: 原文の指紋を求める。
    引数: raw(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(raw).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 停止比較を各一度保存し、既使用小群の結果を現在の方針へ追記する。
    引数: なし。
    返り値: None。旧監査根拠/旧試行/Source/143成果/144仕様は変更しない。
    """
    raw=(SOURCE/'比較の確認.json').read_bytes();assert sha(raw)=='17168b74d9d242c9f8cd2e06a93d8fec6a90bf6a530b104cba49335b6cb71f1a'
    proof=json.loads(raw);assert proof['成功'] and proof['編集停止']
    for item in proof['保存資料']:assert sha(Path(item['path']).read_bytes())==item['sha256']
    TARGET.mkdir(parents=True,exist_ok=True);(TARGET/'比較の確認.json').write_bytes(raw)
    data=(SOURCE/'Strongと期限の元方向対T8.json').read_bytes();packed=gzip.compress(data,mtime=0)
    with (TARGET/'Strongと期限の元方向対T8.json.gz').open('xb') as f:f.write(packed)
    before=DOC.read_bytes();assert sha(before)=='9747f6ccb02e24e4ba24aa5722f9ae0bdc602d06c714f59af88e54b5f5dc8620'
    archive=TARGET/'比較源と追補前文書.zip';members=[]
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in [SOURCE/'比較する.py',SOURCE/'旧StrongではT8が改善していた.md',DOC,Path(__file__)]:
            raw=p.read_bytes();rel=p.relative_to(ROOT).as_posix();z.writestr(rel,raw);members.append({'path':rel,'sha256':sha(raw),'bytes':len(raw)})
    oldindex=ROOT/'docs/根拠/旧P3の後続strong_20261112/保管索引.json';old=json.loads(oldindex.read_bytes())
    study=next((ROOT/'study').glob('00143_*'));m143=json.loads((study/'保管索引.json').read_bytes())
    observation=next(d for d in m143['共有入力'] if d['解凍SHA256']=='d272fc6f6768342ff67e1a9ec58b0b7307a0a5b07cc215ba5ff7bcb50865b742')
    index={'確認日':'2026-11-12','対象':'旧Strong32と期限38の保存取得方向比較・追補','比較停止SHA256':sha((TARGET/'比較の確認.json').read_bytes()),
        '比較JSON':{'保存元':(TARGET/'Strongと期限の元方向対T8.json.gz').relative_to(ROOT).as_posix(),'保存SHA256':sha(packed),'保存bytes':len(packed),'解凍SHA256':sha(data),'解凍bytes':len(data)},
        '比較源ZIP':{'保存元ZIP':archive.relative_to(ROOT).as_posix(),'ZIP_SHA256':sha(archive.read_bytes()),'ZIP_bytes':archive.stat().st_size,'格納源':members},
        '共有入力':[old['旧137分類metadata共有'],observation],
        '旧監査索引':{'path':oldindex.relative_to(ROOT).as_posix(),'sha256':sha(oldindex.read_bytes())},
        '追補前共通知見SHA256':sha(before),'旧監査と旧成果の変更':False,'新Raw/Source/先着観測/144条件変更':False}
    (TARGET/'保管索引.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    # ----------------------------------------
    body=before.decode('utf-8')
    oldstate='本監査時点で144の新条件・新件数・先着率・損益は未採用・未生成。新しいRaw走査や金融計算をした結果ではない。旧試行・Source・143の完成成果は変更しない。'
    newstate='監査当時は144の新条件・新件数・先着率・損益が未採用・未生成だった。その後、旧Strongの方向比較を追補し、144の採用仕様の策定へ進んだ。新streamの出生・取得・先着率・損益は本追補時点で未生成・未評価。旧監査当時の原文と根拠を保存したまま、旧試行・Source・143の完成成果は変更しない。'
    assert oldstate in body;body=body.replace(oldstate,newstate,1)
    body += '''
## 追補：旧Strong32の範囲では固定T8が改善していた

2026-11-12。旧C0のL0補完70だけをstrong32とdeadline38へ分け、元P3方向と固定T8の保存実BBOを比較した。E0の9件・E1の2件は混ぜていない。[停止確認](../根拠/旧Strong32の方向比較_20261112/比較の確認.json)と[全70件の比較票](../根拠/旧Strong32の方向比較_20261112/Strongと期限の元方向対T8.json.gz)を根拠にする。旧Sourceを再生成したものではない。

|旧入口群・方向|取得|順/逆/未到達/H不足|到達済み先着率|C5利益|C5損失絶対額|C5既知差引|
|---|---:|---|---:|---:|---:|---:|
|strong・元P3|32|10/14/3/5|41.67%|123,153円|233,386円|−110,233円|
|strong・固定T8|32|17/6/4/5|73.91%|218,537円|103,770円|+114,767円|
|deadline・元P3|38|9/16/12/1|36.00%|146,691円|255,617円|−108,926円|
|deadline・固定T8|38|15/11/11/1|57.69%|202,383円|195,309円|+7,074円|

strongの両側IFD既知は同じ29件、両未知3件で、T8のペア改善は+225,000円。既知集合の入替えによる差ではない。19件の方向を変更し、元勝ちを失った3件に対し、元負けを順行へ変えたのは10件だった。順行型31だけでも39.13%から72.73%へ改善し、反転型1件は元のまま1順だった。反転型1例から一般則を作らない。

73.91%=17/(17+6)は到達済み分母で、H完了分母では17/27=62.96%、全32では17/32=53.13%。H不足5とIFD未知3を分ける。C5は独立mini1枚100円/pt、往復77円と追加往復10pt=1,000円を控除した保存Quote清算代用であり、実IFD・反転注文geometry・同時口座の検証ではない。

この小さい既使用群では、元P3方向を一律保護するより固定T8を使う根拠があった。一方で、T8自体も既使用期から選ばれ、strongは初取得後の補完を止めた32件である。73.91%を後続の全strongや未知期へ外挿せず、この小群だけで全73場min1・平均1件/時の共同目標達成とはしない。deadlineがT8でも57.69%だったことも、strongと期限補完を同じ入口条件にしない根拠になる。

上の監査で挙げた再準備項目は、監査当時に新試行の事前固定を求めたもので、最新144の採用仕様を置き換えるものではない。144は同じstrong条件を全時間へ広げる別の検証として準備し、新しい全成立streamの実績を確認する。現時点で新しい件数・率・利益を作ったり、旧成績を変更したりしていない。

[追補の保管索引](../根拠/旧Strong32の方向比較_20261112/保管索引.json)は、元短報・比較コード・追補前の共通知見を[小型ZIP](../根拠/旧Strong32の方向比較_20261112/比較源と追補前文書.zip)へ一度保存し、旧137分類metadataと138観測を共有参照する。先の14源監査JSON・停止根拠は不変更である。
'''
    DOC.write_text(body,encoding='utf-8')
    for name in ('docs/README.md','docs/議論/README.md'):
        p=ROOT/name;text=p.read_text('utf-8');paragraph=next(s for s in text.split('\n\n') if '旧P3の未実施対照' in s)
        updated=paragraph.replace('144の条件/新数値は本監査では未採用・未生成、14源と停止根拠を恒久保存。',
            '追補で旧strong32は元41.67%/C5−110,233円→固定T8 73.91%/利益218,537円・損失103,770円・差引+114,767円、両既知29ペア+225,000円と確認。小既使用群から後続へ外挿せず、144採用仕様の準備へ進んだ。新streamの数値は未生成・未評価で、14源の旧監査原文/根拠は不変更。')
        assert updated!=paragraph;p.write_text(text.replace(paragraph,updated,1),encoding='utf-8')
    print(json.dumps({'成功':True,'共通知見SHA256':sha(DOC.read_bytes()),'比較JSON_SHA256':sha(data),'追補索引SHA256':sha((TARGET/'保管索引.json').read_bytes()),'小型ZIP_SHA256':sha(archive.read_bytes())},ensure_ascii=False))


if __name__=='__main__':main()
