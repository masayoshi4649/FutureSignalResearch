"""停止済みの受信時計監査を共通知見へ保存する。価格や金融は読まない。"""
from pathlib import Path
import hashlib
import json
import re
import zipfile

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'work/板の受信時計と価格時計の再確認'
TARGET=ROOT/'docs/根拠/板の時計_20261112'


def sha(raw: bytes) -> str:
    """
    機能: 原文の指紋を求める。
    引数: raw(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(raw).hexdigest()


# ----------------------------------------
def save(path: Path,raw: bytes) -> None:
    """
    機能: 新規保存先だけへ原文を書く。
    引数: path(Path)、raw(bytes)。
    返り値: None。
    """
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as f:f.write(raw)


# ----------------------------------------
def main() -> None:
    """
    機能: 停止MD/記録とコードの共有根拠を保存し、仕様と目次を短く追補する。
    引数: なし。
    返り値: None。Raw/CSV価格/新金融/採番/旧試行は変更しない。
    """
    expected={'README.md':'7beac05cd0db51ced538d0b42f0ae6953c26283af16a0094fe2a7e6888316786',
        '確認の記録.json':'ae2c2ea265e22a552c506c1e599567b641f7bcf0ad5d5d21ef57a5905e67e750',
        '品質監査案.md':'997df1133b0c08ced46c2cf133e0a6ed56e5d60e81916cd15d61840a5e5e2202'}
    for name,h in expected.items():
        raw=(SOURCE/name).read_bytes();assert sha(raw)==h
        save(TARGET/('停止時の調査.md' if name=='README.md' else name),raw)
    record=json.loads((TARGET/'確認の記録.json').read_bytes())
    previous=next((ROOT/'study').glob('00134_*'));manifest=json.loads((previous/'保管索引.json').read_bytes())
    prior=manifest['後発コード'];archive=previous/'再現資料'/prior['ZIP'];assert sha(archive.read_bytes())==prior['ZIP_SHA256']
    shared=[]
    with zipfile.ZipFile(archive) as z:
        for name in ('future_history_candles.go','future_history_candles_test.go'):
            entry=next(x for x in prior['格納源'] if x['path'].endswith('/'+name));raw=z.read(entry['path']);assert sha(raw)==entry['sha256']
            shared.append({'保存元ZIP':archive.relative_to(ROOT).as_posix(),'ZIP_SHA256':prior['ZIP_SHA256'],
                'ZIP内path':entry['path'],'sha256':entry['sha256'],'bytes':len(raw)})
    new=[];new_bodies={}
    for name in ('future_history_store.go','future_history_archive.go','kabus_websocket_snapshot.go'):
        source='../kabus-controller/'+name;raw=(ROOT/source).read_bytes();h=record['参照源'][source]['sha256'];assert sha(raw)==h
        entry='外部/kabus-controller/'+name;new.append({'元参照':source,'ZIP内path':entry,'sha256':h,'bytes':len(raw)});new_bodies[entry]=raw
    # ----------------------------------------
    doc=ROOT/'docs/データと閲覧形式.md';original=doc.read_bytes()
    assert sha(original)==record['参照源']['docs/データと閲覧形式.md']['sha256']
    new_bodies['追補前のデータと閲覧形式.md']=original
    new_bodies['work/受信時計の共通知見を保存する.py']=Path(__file__).read_bytes()
    fresh=TARGET/'今回の小型参照コード.zip'
    with zipfile.ZipFile(fresh,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,raw in new_bodies.items():z.writestr(name,raw)
    with zipfile.ZipFile(fresh) as z:
        assert z.testzip() is None
        for name,raw in new_bodies.items():assert z.read(name)==raw
    index={'確認日':'2026-11-12','用途':'停止済み非金融の受信時計監査の恒久根拠。新自然品質監査ではない',
        '停止原文SHA256':expected,'共有コード':shared,'今回保存コード':new,'今回ZIP':fresh.name,'今回ZIP_SHA256':sha(fresh.read_bytes()),
        '追補前仕様SHA256':sha(original),'134時の4源同SHA':'監査記録では4源。恒久134ZIPにある2源を共有参照し、未格納だったstore/archiveとWS処理源だけ今回保存',
        '原板/大入力複製/新価格読取/金融/新採番/旧試行改変':False}
    save(TARGET/'保管索引.json',(json.dumps(index,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    explanation='''# 板の受信時計に関する停止済み監査

2026-11-12、コード・仕様・既存134監査による確認。新Raw/価格CSV本文・金融・追加2場は読んでいない。全73場の自然品質監査や新試行の結果ではない。

- [停止時の調査](停止時の調査.md)：原文SHA7beac05c…を同体保存。
- [確認の記録](確認の記録.json)：原文SHAae2c2ea2…、参照源と確認範囲。
- [品質監査案](品質監査案.md)：停止時に作成した未実行の案。実行済み結果と混同しない。
- [保管索引](保管索引.json)：共有コード2源と今回の小型3源の完全指紋。
- [小型コードZIP](今回の小型参照コード.zip)：store/archive/WS処理源、追補前仕様、保存処理。
- [既存134のコードZIP](../../../study/00134_Raw公表時計で複合入口を再生成する/再現資料/検算と保管の追補コード.zip)：同SHAのcandles.go/test.goを共有参照し、複写しない。

監査記録の「134時のロガー4源と現在の一致」と、134でコード本文まで恒久格納済みであることは別。134ZIPで確認できたのは2源だったため、未格納のstore/archiveと受信処理源を今回だけ保存した。旧134の内容は変更していない。

SourceRecordのscalar.received保持と、readBoards前段によるCurrentPriceTime代入を区別する。CSVのclosed/volume_completeや研究のAvailableAt/DeliveryAtを、全メッセージの実受信完全性や実際の公表時刻を復元した証拠としない。限定2行のキー確認を全73場全行の不在証明へ外挿せず、Raw/CSVのライブ再現優劣も断定しない。
'''
    save(TARGET/'README.md',explanation.encode('utf-8'))
    addition='''### 受信時計・価格時計・研究公表時計の追補（2026-11-12）

元ロガーはメモリにローカル処理時刻receivedAt・商品内sequenceを持つが、book保存はpayloadだけで、これらを行ごとに付加しない。SourceRecord自体はscalar.receivedを保持する。一方、歴史再生の前段readBoardsがCurrentPriceTimeをTime/Receivedへ代入しているため、そのReceivedは実受信時刻ではない。133系Quoteも別の最小型として区別する。

CSVはreceivedAtで作業分と閉鎖を進め、価格・数量それぞれの時計でも採用可否を判定する。timeは足開始、closedは形成済み足の時間確定、volume_completeは数量基準等の旗であり、受信完全性の証明ではない。CSVには各更新のreceivedAt/ClosedAtがない。研究のAvailableAt/DeliveryAtも使用を許す公表・配送モデルで、失われた実受信時刻の復元ではない。

これはコードと既存の限定証跡による確認で、各日の稼働版・全73場全行の時計欄・別sidecarとの結合は未証明。少数のキー例から全行の実時計不在を断定せず、Raw/CSVの生WS再現の優劣も決めない。価格時計の長い間隔を通信断と同一視せず、足形成・数量・助走・配送窓の差を分ける。[停止済み監査と恒久根拠](根拠/板の時計_20261112/README.md)、[134の足定義監査](../study/00134_Raw公表時計で複合入口を再生成する/根拠/足定義の監査.md)。

'''
    text=original.decode('utf-8');marker='### 立会時間と即時清算';assert text.count(marker)==1
    doc.write_text(text.replace(marker,addition+marker),encoding='utf-8')
    docindex=ROOT/'docs/README.md';text=docindex.read_text('utf-8');title,rest=text.split('\n\n',1)
    note='データ時計の再確認（2026-11-12）：[受信時計・価格時計・研究公表時計](データと閲覧形式.md#受信時計価格時計研究公表時計の追補2026-11-12)。ロガー/Source/CSVの保持と代入を分け、closed等を受信完全性としない。[停止済みコード監査の根拠](根拠/板の時計_20261112/README.md)を恒久保存。全73場の自然品質監査やRaw/CSVの優劣の結論ではない。'
    docindex.write_text(title+'\n\n'+note+'\n\n'+rest,encoding='utf-8')
    # ----------------------------------------
    links=0
    for p in [TARGET/'README.md',TARGET/'停止時の調査.md',doc]:
        for target in re.findall(r'\]\(([^)]+)\)',p.read_text('utf-8')):
            if target.startswith(('https:','http:','#')):continue
            assert (p.parent/target.strip('<>').split('#',1)[0]).resolve().exists(),(p,target);links+=1
    for n,h in expected.items():assert sha((SOURCE/n).read_bytes())==h
    proof={'成功':True,'確認日':'2026-11-12','編集停止':True,'停止MD/記録/未実行案同体保存':True,'既存134共有コード':2,
        '新小型コード保存':3,'根拠がworkだけに依存':False,'仕様追補/目次更新':True,'新Raw/価格CSV/金融/採番/旧試行変更':False,
        '全73実時計不在/RawCSV優劣の断定':False,'ローカルリンク確認':links,'重大不足':[],
        '保管索引SHA256':sha((TARGET/'保管索引.json').read_bytes()),'仕様SHA256':sha(doc.read_bytes()),'目次SHA256':sha(docindex.read_bytes()),
        'コードSHA256':sha(Path(__file__).read_bytes())}
    save(TARGET/'保存の確認.json',(json.dumps(proof,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    print(json.dumps({'成功':True,'保存の確認SHA256':sha((TARGET/'保存の確認.json').read_bytes()),'保管索引SHA256':proof['保管索引SHA256'],'重大不足':[]},ensure_ascii=False))


if __name__=='__main__':main()
