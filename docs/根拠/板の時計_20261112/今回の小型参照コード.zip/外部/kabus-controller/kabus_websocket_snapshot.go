package main

import (
	"encoding/json"
	"sort"
	"strings"
	"sync"
	"time"
)

// kabusWebSocketSnapshotStore は、銘柄ごとに最後に受信完了したWebSocket JSONを保持します。
type kabusWebSocketSnapshotStore struct {
	mu               sync.RWMutex
	payloads         map[string]json.RawMessage
	orderObserver    func([]byte, time.Time)
	orderInvalidator func()
	marketObserver   func([]byte, time.Time)
	historyObserver  func(string, []byte, time.Time)
}

// newKabusWebSocketSnapshotStore は、WebSocket JSONを銘柄別に保存する空のストアを生成します。
//
// # 返り値
//   - *kabusWebSocketSnapshotStore : 並行更新と並行取得に対応する空のスナップショットストア
func newKabusWebSocketSnapshotStore() *kabusWebSocketSnapshotStore {
	return &kabusWebSocketSnapshotStore{
		payloads: make(map[string]json.RawMessage),
	}
}

// Update は、有効なJSONオブジェクトを銘柄の最新WebSocketデータとして保存します。
//
// JSONは空ではない文字列のSymbolを持つ必要があります。不正なJSON、配列、スカラー、
// SymbolがないJSONは保存せず、同じ銘柄の既存データも変更しません。
//
// # 引数
//   - payload : WebSocketで受信完了したJSON本文の[]byte
//
// # 返り値
//   - bool : 最新データとして保存した場合はtrue、それ以外はfalse
func (store *kabusWebSocketSnapshotStore) Update(payload []byte) bool {
	symbol, valid := kabusWebSocketSnapshotSymbol(payload)
	if !valid {
		return false
	}

	store.update(symbol, payload)
	return true
}

// Snapshot は、指定した銘柄順で受信済みの最新WebSocket JSONを独立した配列として取得します。
//
// 重複した銘柄は最初の指定だけを採用し、未受信の銘柄は結果へ含めません。
//
// # 引数
//   - symbols : 取得対象と順序を表す[]string
//
// # 返り値
//   - []json.RawMessage : 呼び出し後に内部更新の影響を受けない最新JSON配列
func (store *kabusWebSocketSnapshotStore) Snapshot(symbols []string) []json.RawMessage {
	store.mu.RLock()
	defer store.mu.RUnlock()

	payloads := make([]json.RawMessage, 0, len(symbols))
	seen := make(map[string]struct{}, len(symbols))
	for _, symbolValue := range symbols {
		symbol := strings.TrimSpace(symbolValue)
		if symbol == "" {
			continue
		}
		if _, exists := seen[symbol]; exists {
			continue
		}
		seen[symbol] = struct{}{}

		payload, exists := store.payloads[symbol]
		if !exists {
			continue
		}
		payloads = append(payloads, cloneKabusWebSocketJSON(payload))
	}
	return payloads
}

// SnapshotAll は、受信済みの全銘柄の最新WebSocket JSONを銘柄ID順で取得します。
//
// 登録状態に関係なく保存中の全銘柄を返します。保存値は更新時に置き換えられるため、
// ロック中は参照だけを集め、整列と複製はロックを解放してから実行します。
//
// # 引数
//   - なし
//
// # 返り値
//   - []json.RawMessage : 内部更新や返却後の書き換えに影響されない最新JSON配列
func (store *kabusWebSocketSnapshotStore) SnapshotAll() []json.RawMessage {
	type entry struct {
		symbol  string
		payload json.RawMessage
	}

	store.mu.RLock()
	entries := make([]entry, 0, len(store.payloads))
	for symbol, payload := range store.payloads {
		entries = append(entries, entry{symbol: symbol, payload: payload})
	}
	store.mu.RUnlock()

	// ----------------------------------------
	sort.Slice(entries, func(left int, right int) bool {
		return entries[left].symbol < entries[right].symbol
	})
	payloads := make([]json.RawMessage, 0, len(entries))
	for _, current := range entries {
		payloads = append(payloads, cloneKabusWebSocketJSON(current.payload))
	}
	return payloads
}

// Get は、指定した銘柄の最新WebSocket JSONを独立した値として取得します。
//
// # 引数
//   - symbolValue : WebSocket JSONのSymbolと照合する銘柄IDのstring
//
// # 返り値
//   - json.RawMessage : 呼び出し後に内部更新の影響を受けない最新JSON
//   - bool : 指定銘柄の受信済みJSONが存在する場合はtrue
func (store *kabusWebSocketSnapshotStore) Get(symbolValue string) (json.RawMessage, bool) {
	symbol := strings.TrimSpace(symbolValue)
	if symbol == "" {
		return nil, false
	}

	store.mu.RLock()
	defer store.mu.RUnlock()
	payload, exists := store.payloads[symbol]
	if !exists {
		return nil, false
	}
	return cloneKabusWebSocketJSON(payload), true
}

// ----------------------------------------

// update は、検証済みの銘柄とJSON本文を最新値として原子的に置き換えます。
//
// # 引数
//   - symbol : 検証済みの銘柄IDのstring
//   - payload : 検証済みのWebSocket JSON本文の[]byte
//
// # 返り値
//   - なし
func (store *kabusWebSocketSnapshotStore) update(symbol string, payload []byte) {
	clonedPayload := cloneKabusWebSocketJSON(payload)
	store.mu.Lock()
	store.payloads[symbol] = clonedPayload
	observer := store.orderObserver
	marketObserver := store.marketObserver
	historyObserver := store.historyObserver
	store.mu.Unlock()
	receivedAt := time.Now()
	if observer != nil {
		observer(clonedPayload, receivedAt)
	}
	if historyObserver != nil {
		historyObserver(symbol, clonedPayload, receivedAt)
	}
	if marketObserver != nil {
		marketObserver(clonedPayload, receivedAt)
	}
}

// ----------------------------------------

// setHistoryObserver は、保存済み値を再送せず、今後受信した生データの通知先を設定します。
//
// 引数:
//   - observer func(string, []byte, time.Time): 銘柄ID、共有の受信JSON、受信時刻を受け取る関数。
//     JSONを書き換えず、メモリー内の処理だけを実行し、WebSocketハブのロックを再取得しないこと。
//
// 返り値:
//   - なし。nilを指定すると履歴通知を解除します。
func (store *kabusWebSocketSnapshotStore) setHistoryObserver(observer func(string, []byte, time.Time)) {
	store.mu.Lock()
	store.historyObserver = observer
	store.mu.Unlock()
}

// setMarketObserver は、表示専用の初期値通知と後続PUSHの購読を設定します。
//
// 引数:
//   - observer func([]byte, time.Time): 板計算の通知先。ストアのロックを再取得してはいけません。
//
// 返り値:
//   - なし。注文監視には既存値を再送せず、市場表示だけへ初期値を渡します。
func (store *kabusWebSocketSnapshotStore) setMarketObserver(observer func([]byte, time.Time)) {
	store.mu.Lock()
	defer store.mu.Unlock()
	if observer != nil {
		for _, payload := range store.payloads {
			observer(cloneKabusWebSocketJSON(payload), time.Now())
		}
	}
	store.marketObserver = observer
}

// setOrderObserver は、保存済み値を再送せず受信イベントと接続中断の購読先を設定します。
//
// 引数:
//   - observer func([]byte, time.Time): メモリー内の価格評価だけを行う関数。
//   - invalidator func(): 接続中断で予約を停止する関数。
//
// 返り値:
//   - なし。購読先からWebSocketハブのロックを再取得してはいけません。
func (store *kabusWebSocketSnapshotStore) setOrderObserver(observer func([]byte, time.Time), invalidator func()) {
	store.mu.Lock()
	defer store.mu.Unlock()
	store.orderObserver, store.orderInvalidator = observer, invalidator
}

// invalidateOrders は、表示用スナップショットを保持したまま予約の旧観測を無効にします。
//
// 引数:
//   - なし。
//
// 返り値:
//   - なし。
func (store *kabusWebSocketSnapshotStore) invalidateOrders() {
	if store == nil {
		return
	}
	store.mu.RLock()
	callback := store.orderInvalidator
	store.mu.RUnlock()
	if callback != nil {
		callback()
	}
}

// kabusWebSocketSnapshotSymbol は、JSONオブジェクトから保存キーとなるSymbolを検証して取得します。
//
// # 引数
//   - payload : WebSocketで受信したJSON候補の[]byte
//
// # 返り値
//   - string : 前後の空白を除いた銘柄ID。検証失敗時は空文字列
//   - bool : 有効なJSONオブジェクトと銘柄IDを取得できた場合はtrue
func kabusWebSocketSnapshotSymbol(payload []byte) (string, bool) {
	var identity struct {
		Symbol *string `json:"Symbol"`
	}
	if err := json.Unmarshal(payload, &identity); err != nil || identity.Symbol == nil {
		return "", false
	}
	symbol := strings.TrimSpace(*identity.Symbol)
	return symbol, symbol != ""
}

// cloneKabusWebSocketJSON は、WebSocket JSONを共有元から独立したRawMessageへ複製します。
//
// # 引数
//   - payload : 複製元のJSON本文を表す[]byte
//
// # 返り値
//   - json.RawMessage : 元のスライスを変更しても影響を受けないJSON本文
func cloneKabusWebSocketJSON(payload []byte) json.RawMessage {
	clonedPayload := make(json.RawMessage, len(payload))
	copy(clonedPayload, payload)
	return clonedPayload
}
