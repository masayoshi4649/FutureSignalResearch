"""指数間の純時計可用性だけを、試行番号なしで正式保存する。"""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).parent
DEST=ROOT/'docs/データ監査/指数間の価格時計可用性'


def main() -> None:
    """
    機能: 最小の純計算正本・Source・確認票を正式文書から参照可能にする。
    引数: なし。
    返り値: None。原入力や金融結果は複製せず、既存の試行を変更しない。
    """
    DEST.mkdir(parents=True,exist_ok=True)
    for name in ('両指数の過去結合可用性.json.gz','人工確認.json','独立確認.json'):
        shutil.copyfile(HERE/name,DEST/name)
    sources=('可用性を確認する.py','過去結合を人工確認する.py','集計と入力を独立確認する.py','正式保存する.py')
    with zipfile.ZipFile(DEST/'Source.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for name in sources:
            member=zipfile.ZipInfo(name,date_time=(2026,11,18,0,0,0));member.compress_type=zipfile.ZIP_DEFLATED
            archive.writestr(member,(HERE/name).read_bytes())
    saved=[]
    for name in ('両指数の過去結合可用性.json.gz','人工確認.json','独立確認.json','Source.zip'):
        path=DEST/name;saved.append({'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,
                                   'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    with zipfile.ZipFile(DEST/'Source.zip') as archive:
        for name in sources:assert archive.read(name)==(HERE/name).read_bytes()
    index={'金融未使用':True,'相関や予測性能未計算':True,'対象場':81,'入力NPZ複製':False,'保存':saved,
           '再現':'Source.zipをwork直下の一つの作業フォルダへ展開し、可用性・人工確認・独立確認の順に実行。',
           '環境':'Python 3.14.3 / NumPy 2.5.4 / America/New_Yorkを解決できるタイムゾーンデータ'}
    (DEST/'保存索引.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'保存ファイル':len(saved)+1,'合計bytes':sum(r['bytes'] for r in saved)},ensure_ascii=False))


if __name__=='__main__':main()
