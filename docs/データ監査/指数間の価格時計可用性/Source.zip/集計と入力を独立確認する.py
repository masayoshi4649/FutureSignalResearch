"""金融を読まず、指数間の可用性集計と元入力の指紋を独立に照合する。"""
from pathlib import Path
import gzip
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).parent


def ref(path: Path) -> dict:
    """
    機能: 再現対象ファイルの内容指紋を求める。
    引数: path(Path)。
    返り値: dictは相対パス・容量・SHA256。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,
            'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


def main() -> None:
    """
    機能: 162入力、正式台帳、格子の再集計、夜間分割、正常BBOの上限を照合する。
    引数: なし。
    返り値: None。独立確認票を保存する。自然損益・相関・予測結果は参照しない。
    """
    result_path=HERE/'両指数の過去結合可用性.json.gz'
    result=json.loads(gzip.decompress(result_path.read_bytes()))
    assert result['金融未使用'] and result['相関や予測性能未計算']
    assert result['Source']==ref(HERE/'可用性を確認する.py')
    current={v['path']:ref(ROOT/v['path']) for v in result['入力']}
    assert len(current)==162 and all(current[v['path']]==v for v in result['入力'])

    # ----------------------------------------
    # 正式入力台帳と旧60場の契約メタデータを照合する。
    nk_path=ROOT/'inputs/NK225原順8列_20260921_20261116/入力台帳.json.gz'
    tp_path=ROOT/'inputs/TOPIX原順8列_20260921_20261116/台帳.json'
    old_path=ROOT/'study/00002_複数時間足と四系統の要因比較/入力台帳.json'
    nk=json.loads(gzip.decompress(nk_path.read_bytes()))
    tp=json.loads(tp_path.read_text(encoding='utf-8'))
    old=json.loads(old_path.read_text(encoding='utf-8'))
    assert len(nk['entries'])==len(tp['entries'])==81
    for row in nk['entries']:
        assert current[row['cache_relative']]['sha256']==row['sha256_cache']
    for row in tp['entries']:
        assert current[row['path']]['sha256']==row['sha256']
    contracts_nk=sorted({c for row in nk['entries'] for c in row['in_session_contract_codes']})
    contracts_tp=[];tp_old_count=0
    for row in old['entries']:
        if row['symbol']=='TOPIX':
            key='inputs/TOPIX原順8列_20260921_20261116/'+row['session']+'.npz'
            assert current[key]['sha256']==row['sha256_cache']
            contracts_tp.extend(row['in_session_contract_codes']);tp_old_count+=1
    assert contracts_nk==['161120018'] and sorted(set(contracts_tp))==['161120005'] and tp_old_count==60

    # ----------------------------------------
    # 主処理の合計欄を使わず場別行から集計し直し、夜間の分割も照合する。
    combined={};scene_rows={};checks=0
    for row in result['格子別']:
        key=f"{row['帯']}_遅延{row['遅延秒']}_鮮度{row['検索境界からの停滞上限秒']}"
        fields=('全格子','NK単独','TOPIX単独','両方','両BBO正常')
        total=combined.setdefault(key,{k:0 for k in fields})
        for k in fields:total[k]+=row[k]
        assert 0<=row['両BBO正常']<=row['両方']<=min(row['NK単独'],row['TOPIX単独'])<=row['全格子']
        assert row['格子からの経過上限秒']==row['遅延秒']+row['検索境界からの停滞上限秒']
        scene_rows[(row['場'],row['帯'],row['遅延秒'],row['検索境界からの停滞上限秒'])]=row
        checks+=2
    assert combined==result['合計'];checks+=len(combined)*5
    for (scene,band,d,s),row in scene_rows.items():
        if band=='NIGHT':
            pre=scene_rows[(scene,'PRE',d,s)];post=scene_rows[(scene,'POST',d,s)]
            for k in fields:
                assert row[k]==pre[k]+post[k];checks+=1
    for row in result['リターン端点の可用性'].values():
        assert 0<=row['同秒初回最終価格差あり']<=row['端点両指数既知']<=row['全格子']
        assert 0<=row['端点既知かつ両指数内部300秒超停滞なし']<=row['端点両指数既知']
        checks+=2
    for horizon in (60,300,900,1800):
        for key,value in result['リターン端点の可用性'][f'NIGHT_{horizon}秒'].items():
            assert value==sum(result['リターン端点の可用性'][f'{band}_{horizon}秒'][key] for band in ('PRE','POST'))
            checks+=1
    audit={'成功':True,'金融未使用':True,'入力照合ファイル':len(current),'集計照合項目':checks,
           '価格監査Source':result['Source'],'独立Source':ref(Path(__file__)),
           '入力正式台帳':[ref(nk_path),ref(tp_path),ref(old_path)],
           '限月確認':{'NK225':{'契約コード':contracts_nk,'確認場':81,'表示':'日経平均先物 26/12'},
                     'TOPIX':{'契約コード':sorted(set(contracts_tp)),'個別契約メタデータ確認場':60,
                              '81場正式台帳の対象宣言':tp['対象'],
                              '残り21場':'8列自体に銘柄コードなし。正式台帳の2026-12宣言を参照し、個別契約再確認とは区別。'}},
           '結果':ref(result_path)}
    (HERE/'独立確認.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'入力':162,'集計照合項目':checks},ensure_ascii=False))


if __name__=='__main__':main()
