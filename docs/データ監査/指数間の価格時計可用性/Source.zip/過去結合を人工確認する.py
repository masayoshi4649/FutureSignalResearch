"""価格時計の過去結合で未来・同秒最終値・逆行原行を採らないことを確認する。"""
from pathlib import Path
import hashlib
import json
import numpy as np
import 可用性を確認する as M


def main() -> None:
    """
    機能: 合成8列を使い過去向き・境界・時計後退・初回値の不変性を確認する。
    引数: なし。
    返り値: None。人工票を保存する。自然価格・金融は使わない。
    """
    folder=Path(__file__).parent;checks=[]
    def check(name: str,actual: object,expected: object) -> None:
        """
        機能: 合成値と期待値を照合する。
        引数: name(str)、actual/expected(object)。
        返り値: None。
        """
        np.testing.assert_array_equal(actual,expected);checks.append({'検査':name,'項目':np.asarray(expected).size})
    t=np.asarray([np.nan,1,10,5,10,11,20.]);last=np.asarray([np.nan,100,101,999,103,104,105.])
    path=folder/'人工8列.npz'
    np.savez_compressed(path,now=t,line=np.arange(1,8),last=last,bid=last-.5,ask=last+.5,
        valid=np.ones(7,bool),volume=np.arange(7.),volume_time=t)
    times,first,end,valid,q=M.timeline(path,0,20)
    check('逆行価格999を採らない',times,[1,10,11]);check('同秒は初回値',first,[100,101,104]);check('最終値は感応診断だけ',end,[100,103,104])
    indices,age=M.asof(times,np.asarray([10.,11.,12.]),1)
    check('同秒相手を使わない',indices,[0,1,2]);check('経過秒',[*age],[9,1,1])
    indices,age=M.asof(times,np.asarray([0.,1.,2.]),1)
    check('過去がなければ未知',indices,[-1,-1,0]);check('未来最近傍で埋めない',np.isinf(age),[True,True,False])
    indices,age=M.asof(np.array([]),np.asarray([1.,10.]),1)
    check('空入力は未知',indices,[-1,-1])
    check('後退原行計数',q['既到達時計より後退'],1)
    check('終了以後を使わない',times.max()<20,True)

    # ----------------------------------------
    # 仮定の公表遅延と、検索境界からの価格時計停滞を分ける。
    indices,age=M.asof(np.asarray([1.,61.,62.]),np.asarray([121.]),60)
    check('遅延検索境界を越える62を採らない',indices,[1])
    check('遅延込み総経過',age,[60.])
    check('検索境界からの停滞は0',age-60,[0.])
    indices,age=M.asof(np.asarray([1.,61.]),np.asarray([122.]),60)
    check('検索境界からの停滞は1',age-60,[1.])
    check('停滞上限0なら不成立',age-60<=0,[False])
    check('停滞上限1なら成立',age-60<=1,[True])
    result={'成功':True,'金融未使用':True,'項目':sum(v['項目'] for v in checks),'検査':checks,
        'SourceSHA':hashlib.sha256(Path(M.__file__).read_bytes()).hexdigest()}
    (folder/'人工確認.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(result['項目'])


if __name__=='__main__':main()
