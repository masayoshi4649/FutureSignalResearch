"""両指数8列の価格時計だけで、過去向き同時点結合の可用性を調べる。"""
from pathlib import Path
from datetime import datetime,timezone,timedelta
from collections import defaultdict
from zoneinfo import ZoneInfo
import gzip
import hashlib
import json
import numpy as np

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
ZONE=timezone(timedelta(hours=9))
FIELDS=('now','line','last','bid','ask','valid','volume','volume_time')
DELAYS=(1,5,30,60);AGES=(5,30,60,300);HORIZONS=(60,300,900,1800)


def ref(path: Path) -> dict:
    """
    機能: 今回読んだ入力の内容指紋を取る。
    引数: path(Path)。
    返り値: dictは相対パス・容量・SHA256。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


def bounds(scene: str) -> tuple:
    """
    機能: 共通81場の開始と末尾15分前の対象終了をUTC秒へ変換する。
    引数: scene(str)はYYYY-MM-DD_Day/Night。
    返り値: tuple[float,float]。
    """
    day=datetime.fromisoformat(scene[:10]).replace(tzinfo=ZONE)
    if scene.endswith('_Day'):return (day.replace(hour=8,minute=45).timestamp(),day.replace(hour=15,minute=30).timestamp())
    return (day.replace(hour=17).timestamp(),(day+timedelta(days=1)).replace(hour=5,minute=45).timestamp())


def timeline(path: Path,start: float,end: float) -> tuple:
    """
    機能: 原行順の逆行時計を除き、各秒の最初のLast観測を作る。
    引数: path(Path)、start/end(float)は対象場。
    返り値: tupleは時刻・初回Last・最終Last・正常BBO・品質。受信順の復元ではない。
    """
    with np.load(path,allow_pickle=False) as z:
        assert set(z.files)==set(FIELDS);data={k:z[k].copy() for k in FIELDS}
    n=len(data['now']);assert all(len(v)==n for v in data.values()) and np.all(np.diff(data['line'])>0)
    t=data['now'];finite=np.isfinite(t)
    maximum=np.maximum.accumulate(np.where(finite,t,-np.inf));previous=np.r_[-np.inf,maximum[:-1]]
    backward=finite&(t<previous);window=finite&(t>=start)&(t<end)
    usable=window&~backward&np.isfinite(data['last'])&(data['last']>0)
    ids=np.flatnonzero(usable);times=t[ids]
    if len(ids):
        unique,first,count=np.unique(times,return_index=True,return_counts=True)
        last=first+count-1;first_ids=ids[first];last_ids=ids[last]
        last_prices=data['last'][first_ids];end_prices=data['last'][last_ids]
        minimum=np.minimum.reduceat(data['last'][ids],first);maximum_price=np.maximum.reduceat(data['last'][ids],first)
        valid=data['valid'][first_ids]&np.isfinite(data['bid'][first_ids])&np.isfinite(data['ask'][first_ids])&(data['bid'][first_ids]>0)&(data['ask'][first_ids]>data['bid'][first_ids])
    else:unique=np.array([]);last_prices=end_prices=np.array([]);valid=np.array([],bool);count=minimum=maximum_price=np.array([])
    same=(t[1:]==t[:-1])&np.isfinite(t[1:]);lastchange=(data['last'][1:]!=data['last'][:-1])
    bbochange=(data['bid'][1:]!=data['bid'][:-1])|(data['ask'][1:]!=data['ask'][:-1])
    quality={'保存行':n,'価格時計有限':int(finite.sum()),'対象時間行':int(window.sum()),'既到達時計より後退':int(backward.sum()),
        '有効Last行':len(ids),'異なる価格時計':len(unique),'同秒複数Last価格':int(np.sum(maximum_price>minimum)),
        '同一価格時計でBBO変化':int(np.sum(same&bbochange)),'同一価格時計でLast変化':int(np.sum(same&lastchange)),
        '小数時計行':int(np.sum(finite&(t!=np.floor(t)))),'正常BBOの初回Last秒':int(valid.sum()),
        '初観測':float(unique[0]) if len(unique) else None,'終観測':float(unique[-1]) if len(unique) else None,
        '最大時計間隔秒':float(np.diff(unique).max()) if len(unique)>1 else None}
    return unique,last_prices,end_prices,valid,quality


def asof(times: np.ndarray,grid: np.ndarray,delay: int) -> tuple:
    """
    機能: 共通格子のdelay秒以前にある相手価格だけを選ぶ。
    引数: times/grid(np.ndarray[float])、delay(int)は1以上。
    返り値: tupleは添字・格子からの経過秒。過去観測なしは添字−1/経過inf。
    """
    assert delay>=1
    indices=np.searchsorted(times,grid-delay,side='right')-1
    age=np.full(len(grid),np.inf);valid=indices>=0
    age[valid]=grid[valid]-times[indices[valid]]
    assert np.all(age[valid]>=delay)
    return indices,age


def safe(value: object) -> object:
    """
    機能: NumPyと非有限値をUTF-8 JSON互換へ変換する。
    引数: value(object)。
    返り値: object。未知はNone。
    """
    if isinstance(value,dict):return {k:safe(v) for k,v in value.items()}
    if isinstance(value,(list,tuple,np.ndarray)):return [safe(v) for v in value]
    if isinstance(value,np.integer):return int(value)
    if isinstance(value,np.bool_):return bool(value)
    if isinstance(value,(float,np.floating)):return float(value) if np.isfinite(value) else None
    return value


def main() -> None:
    """
    機能: 全81場の共通1分格子で過去結合・遅延・欠測・各窓の端点可用性を集計する。
    引数: なし。
    返り値: None。金融/勝率/相関推定は使わず、元データも変更しない。
    """
    roots={s:ROOT/'inputs'/(s+'原順8列_20260921_20261116') for s in ('NK225','TOPIX')}
    scenes=sorted(p.stem for p in roots['NK225'].glob('2026*.npz'))
    assert scenes==sorted(p.stem for p in roots['TOPIX'].glob('2026*.npz')) and len(scenes)==81
    inputs=[];quality=[];metrics=[];ages=defaultdict(list);totals=defaultdict(lambda:defaultdict(int));returns=defaultdict(lambda:defaultdict(int))
    for scene in scenes:
        start,end=bounds(scene);grid=np.arange(start+60,end+1,60,dtype=float);band='DAY' if scene.endswith('_Day') else 'NIGHT'
        masks={band:np.ones(len(grid),bool)}
        if band=='NIGHT':
            boundary=datetime.fromisoformat(scene[:10]).replace(hour=9,minute=30,tzinfo=ZoneInfo('America/New_York')).timestamp()
            masks['PRE']=grid<boundary;masks['POST']=grid>=boundary
        data={}
        for symbol in roots:
            path=roots[symbol]/(scene+'.npz');inputs.append(ref(path));data[symbol]=timeline(path,start,end)
            quality.append({'商品':symbol,'場':scene,**data[symbol][-1]})
        for delay in DELAYS:
            chosen={s:asof(data[s][0],grid,delay) for s in roots}
            for s in roots:
                for part,mask in masks.items():ages[(s,part,delay)].extend(chosen[s][1][mask].tolist())
            for age_limit in AGES:
                ready={s:chosen[s][1]-delay<=age_limit for s in roots};paired=ready['NK225']&ready['TOPIX']
                both_bbo=np.ones(len(grid),bool)
                for s in roots:
                    idx=chosen[s][0];v=idx>=0;normal=np.zeros(len(grid),bool);normal[v]=data[s][3][idx[v]];both_bbo&=normal
                for part,mask in masks.items():
                    key=f'{part}_遅延{delay}_鮮度{age_limit}'
                    row={'場':scene,'帯':part,'遅延秒':delay,'検索境界からの停滞上限秒':age_limit,'格子からの経過上限秒':delay+age_limit,'全格子':int(mask.sum()),
                        'NK単独':int((ready['NK225']&mask).sum()),'TOPIX単独':int((ready['TOPIX']&mask).sum()),'両方':int((paired&mask).sum()),'両BBO正常':int((paired&both_bbo&mask).sum())}
                    metrics.append(row)
                    for k in ('全格子','NK単独','TOPIX単独','両方','両BBO正常'):totals[key][k]+=row[k]
                if delay==1 and age_limit==60:
                    for horizon in HORIZONS:
                        endpoints=paired.copy();changed=np.zeros(len(grid),bool);no_long_gap=np.ones(len(grid),bool)
                        for s in roots:
                            prior,oldage=asof(data[s][0],grid-horizon,delay)
                            valid=(prior>=0)&(oldage-delay<=age_limit);endpoints&=valid
                            nowidx=chosen[s][0];both=valid&(nowidx>=0)
                            changed[both]|=(data[s][1][prior[both]]!=data[s][2][prior[both]])|(data[s][1][nowidx[both]]!=data[s][2][nowidx[both]])
                            bad=np.r_[0,np.cumsum(np.diff(data[s][0])>300)]
                            no_long_gap[both]&=(bad[nowidx[both]]-bad[prior[both]])==0
                        for part,mask in masks.items():
                            k=f'{part}_{horizon}秒';returns[k]['全格子']+=int(mask.sum());returns[k]['端点両指数既知']+=int((endpoints&mask).sum());returns[k]['同秒初回最終価格差あり']+=int((endpoints&changed&mask).sum())
                            returns[k]['端点既知かつ両指数内部300秒超停滞なし']+=int((endpoints&no_long_gap&mask).sum())
        print(scene,flush=True)
    age_summary=[]
    for (s,band,delay),values in ages.items():
        a=np.asarray(values);finite=a[np.isfinite(a)]
        age_summary.append({'商品':s,'帯':band,'遅延':delay,'全格子':len(a),'過去観測なし':int(np.sum(~np.isfinite(a))),
            '経過秒p50p90p95p99最大':np.quantile(finite,[.5,.9,.95,.99,1]).tolist() if len(finite) else []})
    result={'金融未使用':True,'相関や予測性能未計算':True,'対象':scenes,'Source':ref(Path(__file__)),'入力':inputs,
        '注意':'価格時計の仮定as-of。真の受信/気配時計なし。同秒は相手に使わず、未来最近傍なし。初回Lastを主とし最終値との差も可用性だけ診断。鮮度欄は検索境界t-delayからの追加停滞上限で、格子からの総経過はdelay+停滞。停滞は配信欠測を直接意味しない。',
        '品質':quality,'格子別':metrics,'合計':dict(totals),'価格経過':age_summary,'リターン端点の可用性':dict(returns)}
    data=(json.dumps(safe(result),ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode()
    (HERE/'両指数の過去結合可用性.json.gz').write_bytes(gzip.compress(data,mtime=0))
    print(json.dumps({'合計':dict(totals),'リターン端点':dict(returns),'価格経過':age_summary},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
