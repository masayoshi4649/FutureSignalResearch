"""OBV符号・CMF位置/入替え・既知0/未知・時計/同体joinの最小人工。"""
import copy
import unittest
import 数量を測る as m


def fixture(n: int=31) -> tuple:
    """
    機能: 当場の規則的な価格/量と実配送q0を作る。
    引数: n(int)。返り値: tupleはrow/history。
    """
    bars=[]
    for i in range(n):
        c=100+i
        bars.append({'id':f'b{i}','session':'人工','contract':'X','width_seconds':60,'start':i*60,'end':(i+1)*60,
            'available_at':(i+2)*60,'stamp':{'time':(i+2)*60,'index':i,'line':i+1},
            'price_known':True,'volume_known':True,'closed':True,'missing':False,'volume':i+1,
            'ohlc':{'open':c,'high':c+1,'low':c-1,'close':c}})
    row={'event_id':'人工q0','eligible':True,'r_ref':bars[-1]['id'],
         'q0':{'time':bars[-1]['stamp']['time'],'index':n-1,'source_line':n}}
    return row,bars


def canonical(bar: dict) -> dict:
    """
    機能: 153にある量値なし正本へ写す。
    引数: bar(dict)。返り値: dict。
    """
    keys=('id','start','end','available_at','stamp','price_known','volume_known','closed','missing')
    return {**{k:copy.deepcopy(bar[k]) for k in keys},'ohlc':copy.deepcopy(bar['ohlc']) if bar['price_known'] else None}


class Tests(unittest.TestCase):
    def test_OBV_r含有と前Close足量不問(self):
        """
        機能: r含むw量を使い、符号用prev足の量未知を不問にする。
        引数: self(Tests)。返り値: None。
        """
        r,b=fixture();b[0]['volume_known']=False
        result=m.measure_row(r,b,0)
        for width in (5,15,30):
            x=result['obv'][str(width)];total=sum(v['volume'] for v in b[-width:])
            self.assertTrue(x['window_known']);self.assertEqual((x['change'],x['sum_volume'],x['ratio']),(total,total,1))
        b[-1]['ohlc'].update(open=129,high=130,low=128,close=129)
        x=m.measure_row(r,b,0)['obv']['5'];self.assertEqual(x['change'],sum(v['volume'] for v in b[-5:-1]))
        self.assertEqual(x['ratio'],x['change']/x['sum_volume'])

    def test_既知全量0と価格量unknown(self):
        """
        機能: 完全窓の分母0とデータ未知を別状態にする。
        引数: self(Tests)。返り値: None。
        """
        r,b=fixture()
        for bar in b:bar['volume']=0
        x=m.measure_row(r,b,0);o=x['obv']['30'];c=x['cmf20']['current']
        self.assertTrue(o['window_known']);self.assertEqual(o['change'],0);self.assertFalse(o['ratio_defined']);self.assertIsNone(o['ratio'])
        self.assertTrue(c['window_known']);self.assertEqual(c['money_flow_volume_sum'],0);self.assertIsNone(c['value'])
        b[-1]['price_known']=False;x=m.measure_row(r,b,0)
        self.assertFalse(x['cmf20']['current']['window_known']);self.assertTrue(x['cmf20']['current']['volume_sum_known'])
        self.assertEqual(x['cmf20']['current']['sum_volume'],0);self.assertIsNone(x['obv']['5']['change'])
        b[-1]['price_known']=True;b[-1]['volume_known']=False
        self.assertIsNone(m.measure_row(r,b,0)['obv']['5']['sum_volume'])

    def test_CMF平値0と1分窓入替え(self):
        """
        機能: H=Lは既知MFM0、前窓との差は脱落足でも動くことを確認する。
        引数: self(Tests)。返り値: None。
        """
        r,b=fixture()
        for bar in b:bar['ohlc']={'open':100,'high':100,'low':100,'close':100};bar['volume']=1
        x=m.measure_row(r,b,0)['cmf20'];self.assertEqual(x['current']['value'],0);self.assertEqual(x['current']['high_equals_low_count'],20)
        b[10]['ohlc']={'open':100,'high':102,'low':100,'close':100}
        x=m.measure_row(r,b,0)['cmf20'];self.assertEqual(x['current']['value'],0)
        self.assertEqual(x['previous']['value'],-1/20);self.assertEqual(x['delta'],1/20)
        b[10]['volume_known']=False;x=m.measure_row(r,b,0)['cmf20']
        self.assertTrue(x['current']['value_defined']);self.assertFalse(x['previous']['value_defined']);self.assertIsNone(x['delta'])

    def test_欠分未closedと未来scope拒否(self):
        """
        機能: 欠足を詰めず、未来/場違い/同時刻後行を拒否する。
        引数: self(Tests)。返り値: None。
        """
        r,b=fixture();del b[15];x=m.measure_row(r,b,0)
        self.assertFalse(x['obv']['30']['window_known']);self.assertEqual(x['obv']['30']['absent_count'],1)
        self.assertFalse(x['cmf20']['current']['window_known'])
        for kind in ('line','time','contract'):
            r,b=fixture()
            if kind=='contract':b[-2]['contract']='別限月'
            else:b[-2]['stamp'][kind]=r['q0']['source_line' if kind=='line' else 'time']+1
            with self.assertRaises(AssertionError):m.measure_row(r,b,0)
        r,b=fixture();b[-1]['closed']=False
        self.assertFalse(m.measure_row(r,b,0)['obv']['5']['window_known'])

    def test_鏡像同Raw配送と入力非改変(self):
        """
        機能: 価格反射でOBV/CMF符号だけを反転し同Raw過去足を許す。
        引数: self(Tests)。返り値: None。
        """
        r,b=fixture()
        for bar in b:bar['stamp']={'time':r['q0']['time'],'index':r['q0']['index'],'source_line':r['q0']['source_line']}
        before=copy.deepcopy((r,b));x=m.measure_row(r,b,0);mirror=copy.deepcopy(b)
        for bar in mirror:
            o=bar['ohlc'];bar['ohlc']={'open':300-o['open'],'high':300-o['low'],'low':300-o['high'],'close':300-o['close']}
        y=m.measure_row(r,mirror,0)
        for width in ('5','15','30'):self.assertEqual(x['obv'][width]['change'],-y['obv'][width]['change'])
        self.assertEqual(x['cmf20']['current']['value'],-y['cmf20']['current']['value']);self.assertEqual((r,b),before)

    def test_147と153の全値join(self):
        """
        機能: 量値なし153正本へ147の価格/旗/Stampを全同体結合する。
        引数: self(Tests)。返り値: None。
        """
        r,b=fixture();a={'success':True,'session':'人工','contract':'X','start':0,'end':2400,
            'bars':[{'bar':bar,'context':{'at':r['q0'] if bar['id']==r['r_ref'] else {'time':bar['stamp']['time'],'index':bar['stamp']['index'],'source_line':bar['stamp']['line']}}} for bar in b]}
        c={'session':'人工','contract':'X','start':0,'continuous_end':2100,'bars':[canonical(bar) for bar in b]}
        self.assertEqual(m.join_scene(a,c),b)
        c['bars'][10]['ohlc']['close']+=1
        with self.assertRaises(AssertionError):m.join_scene(a,c)
        r,b=fixture(1);r['eligible']=False;b[0]['volume_known']=False
        self.assertFalse(m.measure_row(r,b,0)['obv']['5']['window_known'])


if __name__=='__main__':
    unittest.main(verbosity=2)
