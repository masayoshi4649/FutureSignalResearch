"""全q0/prefixを純人工で照合し、gzip末尾と実行旗の境界を確認する。"""
from pathlib import Path
from unittest.mock import patch
import copy
import gzip
import hashlib
import json
import sys
import tempfile
import unittest
import 生成する as m
from 人工検査 import fixture,canonical


def scenes() -> tuple:
    """
    機能: 31配送足を4個のq0へまとめた2Sourceの人工場を作る。
    引数: なし。返り値: tuple[dict,dict]。
    """
    _,bars=fixture();rows=[];prefix=[];old=0
    for index,end in enumerate((8,16,24,31)):
        batch=bars[old:end];q={'time':batch[-1]['available_at'],'index':index,'source_line':index+1}
        for bar in batch:bar['stamp']={'time':q['time'],'index':q['index'],'line':q['source_line']}
        prefix.extend(batch);rows.append({'event_id':f'e{index}','eligible':index!=3,'r_ref':prefix[-1]['id'],
            'q0':q,'delivered_refs':[b['id'] for b in batch],'slot_refs':[b['id'] for b in prefix[-4:]]});old=end
    a={'success':True,'session':'人工','contract':'X','start':0,'end':2400,
       'bars':[{'bar':bar,'context':{'at':{'time':bar['stamp']['time'],'index':bar['stamp']['index'],'source_line':bar['stamp']['line']}}} for bar in bars]}
    b={'session':'人工','contract':'X','start':0,'continuous_end':2100,'bars':[canonical(bar) for bar in bars],'rows':rows}
    return a,b


class Tests(unittest.TestCase):
    def test_全q0と最大31prefixの保持(self):
        """
        機能: 同Rawcatchup/不適格/量unknownを残し参照改変を拒否する。
        引数: self(Tests)。返り値: None。
        """
        a,b=scenes();a['bars'][0]['bar']['volume_known']=b['bars'][0]['volume_known']=False
        before=copy.deepcopy((a,b));out=m.inspect_scene(a,b)
        self.assertEqual((a,b),before);self.assertEqual(len(out['rows']),4);self.assertEqual(len(out['volume_refs']),31)
        self.assertIsNone(out['volume_refs'][0]['volume']);self.assertFalse(out['rows'][-1]['eligible'])
        self.assertTrue(out['rows'][-1]['obv']['30']['window_known'])
        for key in ('slot_refs','delivered_refs','r_ref'):
            bad=copy.deepcopy(b)
            if key=='r_ref':bad['rows'][-1][key]='過去'
            else:bad['rows'][-1][key]=['過去']
            with self.assertRaises(AssertionError):m.inspect_scene(a,bad)

    def test_gzip末尾CRCと解凍指紋(self):
        """
        機能: 配列yield後も全末尾を読み、CRC破損/短縮を拒否する。
        引数: self(Tests)。返り値: None。
        """
        raw=(json.dumps({'scenes':[{'x':'日本'}],'tail':'末尾'},ensure_ascii=False,indent=2)+'\n').encode('utf-8')
        packed=gzip.compress(raw,mtime=0)
        with tempfile.TemporaryDirectory() as directory:
            p=Path(directory)/'人工.json.gz';p.write_bytes(packed);proof={}
            self.assertEqual(list(m.array_items(p,'scenes',proof)),[{'x':'日本'}])
            self.assertEqual(proof['decoded_sha256'],hashlib.sha256(raw).hexdigest());self.assertTrue(proof['full_gzip_crc_checked'])
            for bad in (packed[:-4],packed[:-8]+bytes([packed[-8]^1])+packed[-7:]):
                p.write_bytes(bad)
                with self.assertRaises((EOFError,OSError,gzip.BadGzipFile)):list(m.array_items(p,'scenes',{}))

    def test_明示レビュー旗なしは生成不可(self):
        """
        機能: Root明示実行旗なしでは入力/準備票を開く前に止まる。
        引数: self(Tests)。返り値: None。
        """
        with patch.object(sys,'argv',['生成する.py','--prepare-sha256','0'*64,'--output-dir','存在しない']),patch.object(m,'generate',side_effect=RuntimeError('生成禁止')) as called:
            with self.assertRaises(AssertionError):m.main()
            self.assertEqual(called.call_count,0)


if __name__=='__main__':
    unittest.main(verbosity=2)
