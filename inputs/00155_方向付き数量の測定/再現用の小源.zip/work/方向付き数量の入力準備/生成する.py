"""147の量と153の価格/全q0を因果結合し、採否なしの測定入力だけを生成する。"""
from pathlib import Path
from collections import Counter
import argparse
import gzip
import hashlib
import json
import re
import 数量を測る as core

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
INPUTS={'source147':{'path':'inputs/00147_中位価格位置と実体回復/Sourceの出生と取得.json.gz',
    'sha256':'b99c49f06fe7e2306e59733b1cff26e3bb351f64edee220c98bc30b62c016d77','decoded_sha256':'d42d25ec0fe41e8358c1227fd71b4377ffa90c96a8cf582f1ee4537ebf455d63'},
    'source153':{'path':'inputs/00153_先行高安の独立出生/先行高安の入力.json.gz',
    'sha256':'2c020fed5b336ed0b417d8e72a07c6336ea475b09b9a2ff37f26ec4ce4d56bf8','decoded_sha256':'8e145275dda385e4c2f87500978716654d10efb0903a4011f2bcc304a7906b14'}}


def sha(path: Path) -> str:
    """
    機能: 大きな物理入力をbufferで指紋化する。
    引数: path(Path)。返り値: str。
    """
    h=hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda:source.read(1<<20),b''):h.update(block)
    return h.hexdigest()


def fingerprint(path: Path) -> dict:
    """
    機能: 入力のSHA/サイズ/更新時刻を読取前後で固定する。
    引数: path(Path)。返り値: dict。
    """
    before=path.stat();digest=sha(path);after=path.stat()
    assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns)
    return {'sha256':digest,'bytes':before.st_size,'mtime_ns':before.st_mtime_ns}


def bad_number(token: str) -> None:
    """
    機能: JSON非標準の非有限リテラルを拒否する。
    引数: token(str)。返り値: None、常にValueError。
    """
    raise ValueError('非有限JSON:'+token)


def read_gzip(path: Path,decoded: str) -> tuple:
    """
    機能: 全CRC/解凍SHAを確認し解凍副本なしで153入力を読む。
    引数: path(Path)、decoded(str)。返り値: tupleはJSONと証跡。
    """
    with gzip.open(path,'rb') as source:body=source.read()
    assert hashlib.sha256(body).hexdigest()==decoded
    return json.loads(body,parse_constant=bad_number),{'decoded_sha256':decoded,'decoded_bytes':len(body),'full_gzip_crc_checked':True}


def array_items(path: Path,key: str,evidence: dict):
    """
    機能: 147を一場ずつ読取り、全解凍SHA/CRCを最後まで確認する。
    引数: path(Path)、key(str)、evidence(dict)。返り値: Iterator[dict]。
    """
    digest=hashlib.sha256();size=0;buffer='';decoder=json.JSONDecoder(parse_constant=bad_number)
    marker=re.compile(r'(?m)^  "'+re.escape(key)+r'": \[')
    with gzip.open(path,'rt',encoding='utf-8',newline='') as source:
        def more() -> str:
            """
            機能: UTF8境界を保って実際の全解凍bytesを指紋化する。
            引数: なし。返り値: str。
            """
            nonlocal size
            block=source.read(1<<20);raw=block.encode('utf-8');digest.update(raw);size+=len(raw);return block
        while True:
            block=more();assert block,'scenes配列なし';buffer+=block;match=marker.search(buffer)
            if match:buffer=buffer[match.end():];break
        while True:
            buffer=buffer.lstrip()
            if buffer.startswith(']'):break
            if buffer.startswith(','):buffer=buffer[1:].lstrip()
            try:value,end=decoder.raw_decode(buffer)
            except json.JSONDecodeError:
                block=more();assert block,'scenes途中終了';buffer+=block;continue
            yield value;buffer=buffer[end:]
        while more():pass
    evidence.update(decoded_sha256=digest.hexdigest(),decoded_bytes=size,full_gzip_crc_checked=True)


def update_counts(target: dict,row: dict) -> None:
    """
    機能: all/eligibleを落とさず、窓knownと値definedを別に数える。
    引数: target/row(dict)。返り値: None。
    """
    items={f'OBV{w}':row['obv'][str(w)] for w in core.OBV_WINDOWS}
    items.update(CMF20=row['cmf20']['current'],前CMF20=row['cmf20']['previous'])
    items['CMF20Δ']={'window_known':row['cmf20']['current']['window_known'] and row['cmf20']['previous']['window_known'],
                     'value_defined':row['cmf20']['delta_known'],'zero_total_volume':False}
    for name,item in items.items():
        count=target.setdefault(name,Counter());defined=item['ratio_defined'] if name.startswith('OBV') else item['value_defined']
        count['all_q0']+=1;count['eligible_q0']+=int(row['eligible'])
        count['window_known_all_q0']+=int(item['window_known']);count['window_known_eligible_q0']+=int(item['window_known'] and row['eligible'])
        count['value_defined_all_q0']+=int(defined);count['value_defined_eligible_q0']+=int(defined and row['eligible'])
        count['zero_total_volume_all_q0']+=int(item['zero_total_volume'])


def inspect_scene(scene147: dict,scene153: dict) -> dict:
    """
    機能: 旧採否を受け取らずbars/contextだけから全q0数量測定を作る。
    引数: scene147(dict)はallowlist済み、scene153(dict)。返り値: dict。
    """
    bars=core.join_scene(scene147,scene153);prefix=[];rows=[];cursor=0;previous=None;counts={};ids=set()
    for row in scene153['rows']:
        now=core.stamp(row['q0']);assert row['event_id'] not in ids;ids.add(row['event_id'])
        if previous is not None:assert now[0]>=previous[0] and now[1]>previous[1] and now[2]>previous[2]
        previous=now;batch=[]
        while cursor<len(bars) and core.stamp(bars[cursor]['stamp'])[1]<=now[1]:
            bar=bars[cursor];assert core.stamp(bar['stamp'])==now
            prefix.append(bar);batch.append(bar);cursor+=1
        assert batch and prefix[-1]['id']==row['r_ref']
        assert row['delivered_refs']==[b['id'] for b in batch] and row['slot_refs']==[b['id'] for b in prefix[-4:]]
        measured=core.measure_row(row,prefix[-31:],scene153['start'])
        measured['q0_stamp']={'time':now[0],'index':now[1],'source_line':now[2]}
        rows.append(measured);update_counts(counts,measured)
    assert cursor==len(bars)
    volume_refs=[{'id':b['id'],'source147_bar_index':i,'volume_known':b['volume_known'],
                 'volume':b['volume'] if b['volume_known'] else None} for i,b in enumerate(bars)]
    return {'session':scene153['session'],'contract':scene153['contract'],'start':scene153['start'],
        'continuous_end':scene153['continuous_end'],'volume_refs':volume_refs,'rows':rows,'counts':{k:dict(v) for k,v in counts.items()}}


def generate(output_dir: Path,preparation_sha: str) -> dict:
    """
    機能: レビュー後の固定2入力から測定gzipを一回だけ生成する。
    引数: output_dir(Path)、preparation_sha(str)。返り値: dictは完了証跡。
    """
    output=output_dir.resolve();assert output.is_relative_to(ROOT/'work') and not output.exists()
    ready=HERE/'準備の確認.json';assert sha(ready)==preparation_sha;preparation=json.loads(ready.read_bytes())
    assert preparation['成功'] and preparation['自然生成未実行']
    declared={ROOT/p:h for p,h in preparation['源'].items()};assert all(sha(p)==h for p,h in declared.items())
    source_stat={str(p):[p.stat().st_size,p.stat().st_mtime_ns] for p in declared}
    before={name:fingerprint(ROOT/ref['path']) for name,ref in INPUTS.items()}
    assert all(before[name]['sha256']==ref['sha256'] for name,ref in INPUTS.items())
    parent,evidence153=read_gzip(ROOT/INPUTS['source153']['path'],INPUTS['source153']['decoded_sha256'])
    assert parent['success'] and parent['schema']=='prior_time_range_v1' and not parent['strategy_selected'] and not parent['financial_labels_used']
    assert len(parent['sessions'])==len(set(parent['sessions']))==len(parent['scenes'])==73
    output.mkdir(parents=True);target=output/'方向付き数量の入力.json.gz';digest=hashlib.sha256();size=0
    total=Counter();counts={};evidence147={};written=[]
    with target.open('xb') as physical:
        with gzip.GzipFile(filename='',mode='wb',fileobj=physical,mtime=0,compresslevel=6) as zipped:
            def emit(text: str) -> None:
                """
                機能: 測定JSONをgzipへ直接書き同じ解凍bytesを指紋化する。
                引数: text(str)。返り値: None。
                """
                nonlocal size
                raw=text.encode('utf-8');zipped.write(raw);digest.update(raw);size+=len(raw)
            header={'schema':'directional_volume_v1','source_refs':INPUTS,'sessions':parent['sessions'],
                'obv_minutes':[5,15,30],'obv_window':'[r.End-w*60,r.End)、符号判定にさらに前1本Close、当w本量',
                'cmf_minutes':20,'cmf_previous':'同q0知得prefixで1分ずらした市場窓',
                'strategy_selected':False,'financial_labels_used':False,'selected_trade_count':None,'current100X_changed':False}
            emit(json.dumps(header,ensure_ascii=False,allow_nan=False)[:-1]+',"scenes":[')
            for i,scene in enumerate(array_items(ROOT/INPUTS['source147']['path'],'scenes',evidence147)):
                assert i<73 and scene['session']==parent['sessions'][i]
                allowed={k:scene[k] for k in ('success','session','contract','start','end')}
                allowed['bars']=[{'bar':known['bar'],'context':{'at':known['context']['at']}} for known in scene['bars']]
                report=inspect_scene(allowed,parent['scenes'][i])
                if i:emit(',')
                emit(json.dumps(report,ensure_ascii=False,separators=(',',':'),allow_nan=False));written.append(scene['session'])
                total['all_q0']+=len(report['rows']);total['eligible_q0']+=sum(r['eligible'] for r in report['rows']);total['bars_joined']+=len(report['volume_refs'])
                for name,value in report['counts'].items():counts.setdefault(name,Counter()).update(value)
                print(json.dumps({'測定済場':scene['session'],'累計q0':total['all_q0']},ensure_ascii=False),flush=True)
            assert evidence147['decoded_sha256']==INPUTS['source147']['decoded_sha256'] and written==parent['sessions']
            assert (total['all_q0'],total['eligible_q0'],total['bars_joined'])==(40544,35339,43124)
            assert before=={name:fingerprint(ROOT/ref['path']) for name,ref in INPUTS.items()}
            assert all(sha(p)==h for p,h in declared.items())
            assert source_stat=={str(p):[p.stat().st_size,p.stat().st_mtime_ns] for p in declared}
            tail={'success':True,'counts':dict(total),'window_counts':{k:dict(v) for k,v in counts.items()},
                  'all147_153_bar_ID_OHLC_masks_stamp_equal':True,'all_q0_prefix_refs_clock_equal':True}
            emit('],'+json.dumps(tail,ensure_ascii=False,separators=(',',':'),allow_nan=False)[1:]+'\n')
    proof={'成功':True,'自然生成回数':1,'新売買又は金融':False,'現在100X又はモデル変更':False,'Raw_CSV_追加2場読取':False,
        '147のevents_groups_checks_旧選択を測定へ未使用':True,'準備SHA256':preparation_sha,'入力':INPUTS,
        '入力前後SHA_stat同体':True,'元Source前後SHA_stat同体':True,'Source147全CRC':evidence147,'Source153全CRC':evidence153,
        '出力':{'path':target.relative_to(ROOT).as_posix(),'sha256':sha(target),'bytes':target.stat().st_size,
              'decoded_sha256':digest.hexdigest(),'decoded_bytes':size},'counts':dict(total),'window_counts':{k:dict(v) for k,v in counts.items()}}
    with (output/'生成の確認.json').open('x',encoding='utf-8') as sink:json.dump(proof,sink,ensure_ascii=False,indent=2,allow_nan=False);sink.write('\n')
    return proof


def main() -> None:
    """
    機能: Rootレビュー後の明示旗がある時だけ自然測定を開始する。
    引数: CLI prepare-sha256(str)/output-dir(Path)/execute-after-review(bool)。返り値: None。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--prepare-sha256',required=True);parser.add_argument('--output-dir',required=True,type=Path)
    parser.add_argument('--execute-after-review',action='store_true');args=parser.parse_args();assert args.execute_after_review
    print(json.dumps(generate(args.output_dir,args.prepare_sha256),ensure_ascii=False))


if __name__=='__main__':
    main()
