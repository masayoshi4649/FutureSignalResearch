"""当時配送prefixからOBV変化とCMFを測り、採否や方向選択を行わない。"""
import math

OBV_WINDOWS=(5,15,30)
CMF_WINDOW=20


def finite(value) -> bool:
    """
    機能: boolと非有限を実数から分ける。
    引数: value(object)。返り値: bool。
    """
    return type(value) in (int,float) and math.isfinite(value)


def stamp(value: dict) -> tuple:
    """
    機能: q0と147Stampの二つの物理行表記を正規化する。
    引数: value(dict)。返り値: tuple[float,int,int]。
    """
    time=value['time'];index=value['index'];line=value['line'] if 'line' in value else value['source_line']
    assert finite(time) and type(index) is int and index>=0 and type(line) is int and line>0
    return time,index,line


def validate_bar(bar: dict,now: tuple,session: str,contract: str,session_start: float) -> None:
    """
    機能: 当場格子/値型/配送済みを確認し、未知の内部0を既知にしない。
    引数: bar(dict)、now(tuple)、session/contract(str)、session_start(float)。返り値: None。
    """
    assert bar['session']==session and bar['contract']==contract and type(bar['width_seconds']) is int and bar['width_seconds']==60
    assert bar['id'] and all(finite(bar[k]) for k in ('start','end','available_at'))
    assert bar['start']>=session_start and (bar['start']-session_start)%60==0
    assert bar['end']==bar['start']+60 and bar['available_at']==bar['end']+60
    at=stamp(bar['stamp']);assert bar['available_at']<=at[0] and all(a<=b for a,b in zip(at,now))
    assert all(type(bar[k]) is bool for k in ('price_known','volume_known','closed','missing'))
    assert finite(bar['volume']) and bar['volume']>=0
    if bar['price_known']:
        o=bar['ohlc'];assert set(o)=={'open','high','low','close'} and all(finite(v) for v in o.values())
        assert 0<o['low']<=o['open']<=o['high'] and o['low']<=o['close']<=o['high']


def select_window(by_start: dict,start: float,end: float,session_start: float) -> tuple:
    """
    機能: 実時間格子を欠分圧縮せず選び、品質の個別maskを返す。
    引数: by_start(dict)、start/end/session_start(float)。返り値: tuple[list,dict]。
    """
    n=int((end-start)/60);assert n>0 and start+n*60==end
    positions=[start+i*60 for i in range(n)];feet=[by_start[t] for t in positions if t in by_start]
    absent=n-len(feet);before=sum(t<session_start for t in positions);missing=sum(b['missing'] for b in feet)
    not_closed=sum(not b['closed'] for b in feet);price_unknown=sum(not b['price_known'] for b in feet);volume_unknown=sum(not b['volume_known'] for b in feet)
    common=not(absent or missing or not_closed);price=common and not price_unknown;volume=common and not volume_unknown
    reasons=[]
    if before:reasons.append('before_session')
    if absent>before:reasons.append('absent_slot')
    if missing:reasons.append('missing')
    if not_closed:reasons.append('not_closed')
    if price_unknown:reasons.append('price_unknown')
    if volume_unknown:reasons.append('volume_unknown')
    record={'from':start,'to':end,'expected_count':n,'slot_record_count':len(feet),'absent_count':absent,'before_session_count':before,
        'missing_count':missing,'not_closed_count':not_closed,'price_known_count':len(feet)-price_unknown,'volume_known_count':len(feet)-volume_unknown,
        'price_window_known':price,'volume_window_known':volume,'window_known':price and volume,'unknown_reasons':reasons,
        'first_ref':by_start[start]['id'] if start in by_start else None,'last_ref':by_start[end-60]['id'] if end-60 in by_start else None}
    return feet,record


def obv(by_start: dict,end: float,width: int,session_start: float) -> dict:
    """
    機能: r含むw量とw+1CloseでローリングOBV変化を求める。
    引数: by_start(dict)、end/session_start(float)、width(int)。返り値: dict。
    """
    start=end-width*60;volume_feet,out=select_window(by_start,start,end,session_start)
    prices,price_mask=select_window(by_start,start-60,end,session_start)
    price_known=price_mask['price_window_known'];volume_known=out['volume_window_known'];known=price_known and volume_known
    reasons=list(out['unknown_reasons'])
    if not price_known:reasons.append('w_plus_one_close_unknown')
    total=math.fsum(b['volume'] for b in volume_feet) if volume_known else None;change=None
    if known:
        assert len(prices)==width+1 and len(volume_feet)==width
        terms=[]
        for previous,current in zip(prices,prices[1:]):
            delta=current['ohlc']['close']-previous['ohlc']['close']
            terms.append((1 if delta>0 else -1 if delta<0 else 0)*current['volume'])
        change=math.fsum(terms)
    out.update(price_window_known=price_known,window_known=known,unknown_reasons=reasons,expected_price_count=width+1,
        price_from=start-60,previous_close_ref=by_start[start-60]['id'] if start-60 in by_start else None,
        price_slot_record_count=price_mask['slot_record_count'],price_known_count=price_mask['price_known_count'],
        price_absent_count=price_mask['absent_count'],price_before_session_count=price_mask['before_session_count'],
        price_missing_count=price_mask['missing_count'],price_not_closed_count=price_mask['not_closed_count'],
        change=change,volume_sum_known=volume_known,sum_volume=total,ratio_defined=known and total>0,
        ratio=change/total if known and total>0 else None,zero_total_volume=volume_known and total==0)
    return out


def cmf(by_start: dict,end: float,session_start: float) -> dict:
    """
    機能: 20本HLC位置×量を計算し高安同値MFM0と分母0を分ける。
    引数: by_start(dict)、end/session_start(float)。返り値: dict。
    """
    feet,out=select_window(by_start,end-CMF_WINDOW*60,end,session_start)
    total=math.fsum(b['volume'] for b in feet) if out['volume_window_known'] else None;flow=None;flat=0
    if out['window_known']:
        terms=[]
        for bar in feet:
            o=bar['ohlc'];width=o['high']-o['low'];flat+=width==0
            multiplier=(2*o['close']-o['high']-o['low'])/width if width else 0.
            terms.append(multiplier*bar['volume'])
        flow=math.fsum(terms)
    defined=out['window_known'] and total>0
    out.update(volume_sum_known=out['volume_window_known'],sum_volume=total,money_flow_volume_sum=flow,
        value_defined=defined,value=flow/total if defined else None,
        zero_total_volume=out['volume_window_known'] and total==0,high_equals_low_count=flat if out['window_known'] else None)
    return out


def measure_row(row153: dict,history147: list,session_start: float) -> dict:
    """
    機能: 最新最大31slotの当時prefixから方向非依存の数量測定を返す。
    引数: row153(dict)、history147(list[dict])、session_start(float)。返り値: dict。
    """
    assert history147 and len(history147)<=31 and type(row153['eligible']) is bool
    r=history147[-1];now=stamp(row153['q0']);assert r['id']==row153['r_ref'] and stamp(r['stamp'])==now
    assert finite(session_start);session,contract=r['session'],r['contract'];by_start={};previous=None
    for bar in history147:
        validate_bar(bar,now,session,contract,session_start)
        assert bar['start'] not in by_start
        if previous is not None:assert bar['start']>previous['start'] and all(a<=b for a,b in zip(stamp(previous['stamp']),stamp(bar['stamp'])))
        by_start[bar['start']]=bar;previous=bar
    obvs={str(w):obv(by_start,r['end'],w,session_start) for w in OBV_WINDOWS}
    current=cmf(by_start,r['end'],session_start);previous=cmf(by_start,r['start'],session_start)
    delta_known=current['value_defined'] and previous['value_defined'];delta=current['value']-previous['value'] if delta_known else None
    result={'event_id':row153['event_id'],'eligible':row153['eligible'],'r_ref':r['id'],'obv':obvs,
        'cmf20':{'current':current,'previous':previous,'previous_asof':'同q0で知得済みの1分ずらした市場窓',
                 'delta_known':delta_known,'delta':delta}}
    for value in [delta,*[item[key] for item in obvs.values() for key in ('change','sum_volume','ratio')],
                  *[item[key] for item in (current,previous) for key in ('sum_volume','money_flow_volume_sum','value')]]:
        assert value is None or finite(value),'数量計算非有限'
    return result


def join_scene(scene147: dict,scene153: dict) -> list:
    """
    機能: 147の量を153正本と全足同体検査し既知性を保って結合する。
    引数: scene147/scene153(dict)。返り値: list[dict]は147barの参照。
    """
    assert scene147['success'] and (scene147['session'],scene147['contract'],scene147['start'],scene147['end']-300)==(scene153['session'],scene153['contract'],scene153['start'],scene153['continuous_end'])
    assert len(scene147['bars'])==len(scene153['bars']);out=[]
    for i,(known,canonical) in enumerate(zip(scene147['bars'],scene153['bars'])):
        bar=known['bar'];assert stamp(known['context']['at'])==stamp(bar['stamp'])
        assert bar['start']==scene147['start']+i*60 and bar['end']<=scene153['continuous_end']
        validate_bar(bar,stamp(bar['stamp']),scene147['session'],scene147['contract'],scene147['start'])
        for key in ('id','start','end','available_at','price_known','volume_known','closed','missing'):assert bar[key]==canonical[key],key
        assert stamp(bar['stamp'])==stamp(canonical['stamp'])
        assert (bar['ohlc'] if bar['price_known'] else None)==canonical['ohlc']
        out.append(bar)
    return out
