# 方向付き数量の測定入力準備

2026-11-12。売買判断を追加せず、既存147の配送済み1分量と153の正本価格・全40,544 q0を結合する準備である。適格35,339件だけへ絞らず、不適格q0も未知を含めて保存する。現在100特徴・モデル・旧選択は変更しない。自然生成はRootレビュー後の明示実行まで行わない。

## 入力と既知性

- `inputs/00147_中位価格位置と実体回復/Sourceの出生と取得.json.gz`：1分量、量既知フラグ、足の初配送Stamp、Context.At。
- `inputs/00153_先行高安の独立出生/先行高安の入力.json.gz`：当場1分正本OHLC、品質、全q0、r/配送batch/直近4slot参照。
- 物理gzip SHAと解凍bytes SHAを別に検査する。147はscene単位で復号し、解凍副本を保存しない。153もメモリ内で読み、入力の複製を作らない。

147のJSON sceneには旧注文・取得・判断属性も含まれ、復号時には同じオブジェクト内に存在する。測定へ渡すallowlistは場識別と `bars[].bar` / `bars[].context.at` だけである。旧events/groups/checks、旧選択、金融ラベルは計算へ渡さない。

147/153の全43,124足についてID、順序、開始・終了・可用時刻、Stamp、品質フラグ、既知OHLCを照合する。未知OHLCは数値0を同体根拠にせず、双方の未知状態を照合する。量は147の `volume_known` が正本で、未知時の内部0を既知量0にしない。出力 `volume_refs[].volume` は未知ならnullである。

CSV由来1分はStart、End=Start+60、モデルAvailableAt=End+60、実配送Stampを持つ。これは真の受信時刻を保存したRawネイティブ足という意味ではない。全測定は当場の実配送prefixだけを使い、同場・同限月・60秒格子を要求する。各参照のEnd/AvailableAt/Stamp.Timeはq0以前、Stamp.Index/Lineもq0以下とし、最新rのStampはq0と一致する。同Rawで初めて届いた過去足は現在の窓に使えるが、過去q0で既知だったとは扱わない。欠分・未知・未closedを詰めず、場を跨いでcarryしない。

## 純APIと式

`数量を測る.py` の `measure_row(row153: dict, history147: list[dict], session_start: float) -> dict` は、最新rを末尾とする最大31slotから非方向の測定を返す。`join_scene(scene147: dict, scene153: dict) -> list[dict]` が数量の由来と価格正本の同体を先に検査する。引数は変更しない。

OBV変化w=5/15/30はrを含む実時間窓 `[r.End−60w, r.End)` のw本について、`Σ sign(C_i−C_(i−1))×V_i` とする。符号判定にはさらに前1本の終値を要求するが、その前1本の量は要求しない。当w本の量合計と、合計量が正の時だけ変化/合計量を返す。終値同値は加減0、全量0の既知窓は変化0・比nullである。これは累積OBVの起算値ではなく、固定市場窓の変化量である。

CMF20はrを含む20本について、`MFM=(2C−H−L)/(H−L)`、`Σ(MFM×V)/ΣV`。H=LはMFM=0として既知、総量0は値未定義とする。価格未知×既知量0でも本測定のjoint窓は未知とし、量合計の別maskは既知0を保持する。これは保守的な全足既知要件であり、他の加重測定も全て数学的不能という主張ではない。

前CMF20は **同q0で知得済みprefixを使った、1分前へずらした市場窓** `[r.Start−1200, r.Start)` である。過去の知得時点を再現する値ではない。現・前の値がともに定義された時だけΔを返す。Δは新しい足の寄与と窓から外れる足の両方で変わるため、新たな資金流入だけを示す値とはしない。

## 出力契約

`方向付き数量の入力.json.gz`、schema=`directional_volume_v1`。

```text
top: source_refs, sessions, obv_minutes, cmf_minutes,
     strategy_selected=false, financial_labels_used=false,
     selected_trade_count=null, current100X_changed=false,
     scenes[], success, counts, window_counts
scene: session, contract, start, continuous_end, volume_refs[], rows[], counts
volume_ref: id, source147_bar_index, volume_known, volume(number|null)
row: event_id, eligible, r_ref, q0_stamp{time,index,source_line},
     obv{'5':window,'15':window,'30':window},
     cmf20{current:window,previous:window,previous_asof,delta_known,delta}
```

各windowはfrom/to、期待数、実slot数、欠測/未closed/価格量既知数、first_ref/last_ref、unknown_reasonsを持つ。OBVは `window_known, change, volume_sum_known, sum_volume, ratio_defined, ratio`、CMFは `window_known, volume_sum_known, sum_volume, value_defined, value` を持つ。window_knownと値definedを区別し、全量0を未知と混ぜない。量sumの個別maskは価格maskと独立する。価格OHLCは再転記せず、原典IDと窓範囲から参照する。

Source147全足join→全q0の配送prefix/slot/r照合→測定→全CRC・解凍SHA→全73場・40,544/35,339件照合→前後指紋一致の順で、最後にsuccessを確定する。失敗出力は正式な成功入力として扱わない。

## 人工・実行

`準備する.py` は純6群・生成器3群、構文・関数コメント、物理入力SHA/stat、源の前後同体を確認し、`準備の確認.json` と `停止.json` を未作成先に保存する。人工の子PythonはUTF-8を明示する。自然入力本文は開かない。

Rootレビュー後だけ、次を実行する。出力先は未作成のwork配下に限る。

```powershell
& 'work/複合テクニカル学習環境/Scripts/python.exe' -X utf8 'work/方向付き数量の入力準備/生成する.py' --prepare-sha256 '<準備の確認.jsonのSHA256>' --output-dir 'work/方向付き数量の自然入力' --execute-after-review
```

生成後の独立全件照合を経て `inputs/00155_方向付き数量の測定/` へgzip同体を一度だけ保存する予定で、現時点では未生成・未保存である。旧29 OBV、42/43 CMF、47/48 Forceの未達を保持し、今回を初検証又は単独有効性の確認とは呼ばない。今回の差は広い全1分母集団へ当時の方向付き量を因果結合する点である。新条件、閾値、売買容量、損益は本測定の検査対象外である。
