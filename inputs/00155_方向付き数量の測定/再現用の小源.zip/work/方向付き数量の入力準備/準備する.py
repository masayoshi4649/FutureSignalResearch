"""自然本文を開かず人工・物理指紋を確認し、測定源を停止する。"""
from pathlib import Path
import ast
import datetime
import hashlib
import json
import os
import subprocess
import sys
import 生成する as source

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def digest(path: Path) -> str:
    """
    機能: ファイルを復号せずSHA256へ射影する。
    引数: path(Path)。返り値: str。
    """
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1<<20),b''):h.update(block)
    return h.hexdigest()


def fingerprint(path: Path) -> dict:
    """
    機能: 読取中のstat不変を含めた物理指紋を返す。
    引数: path(Path)。返り値: dict。
    """
    a=path.stat();h=digest(path);b=path.stat()
    assert (a.st_size,a.st_mtime_ns)==(b.st_size,b.st_mtime_ns)
    return {'sha256':h,'bytes':a.st_size,'mtime_ns':a.st_mtime_ns}


def save(path: Path,value: dict) -> None:
    """
    機能: 既存票を上書きせずUTF8の小票を保存する。
    引数: path(Path)、value(dict)。返り値: None。
    """
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(value,stream,ensure_ascii=False,indent=2,allow_nan=False);stream.write('\n')


def main() -> None:
    """
    機能: 人工9群と構文・物理指紋を検査し自然未実行で停止する。
    引数: なし。返り値: None。
    """
    assert not (HERE/'準備の確認.json').exists() and not (HERE/'停止.json').exists()
    own=sorted([*HERE.glob('*.py'),HERE/'README.md'])
    provenance=[ROOT/'work/147中位位置からの実体回復'/name for name in ('types.go','csv.go','short.go')]
    provenance += [ROOT/'work/先行15_30_60分高安の入力生成'/name for name in ('先行高安.py','生成する.py','条件.md')]
    paths=own+provenance
    before={p.relative_to(ROOT).as_posix():fingerprint(p) for p in paths}
    parsed=[]
    for path in own:
        if path.suffix!='.py':continue
        code=path.read_text(encoding='utf-8');tree=ast.parse(code,filename=str(path));compile(tree,str(path),'exec')
        for node in ast.walk(tree):
            if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
                doc=ast.get_docstring(node);assert doc and '\n' in doc and all(word in doc for word in ('機能','引数','返り値')),(path.name,node.name)
        parsed.append(path.name)
    results=[];env=dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8')
    for name,count in (('人工検査.py',6),('人工検査_生成.py',3)):
        command=[sys.executable,'-X','utf8',str(HERE/name)]
        run=subprocess.run(command,cwd=HERE,env=env,capture_output=True,encoding='utf-8',errors='strict')
        assert run.returncode==0,(name,run.stdout,run.stderr)
        assert '\ufffd' not in run.stdout+run.stderr and f'Ran {count} tests' in run.stderr
        results.append({'人工':name,'主群数':count,'成功':True,'command':command,'stdout':run.stdout,'stderr':run.stderr})
    # ----------------------------------------
    # 自然入力はgzip物理bytesだけを指紋化し、本文を解凍しない。
    physical={}
    for name,ref in source.INPUTS.items():
        physical[name]={'path':ref['path'],**fingerprint(ROOT/ref['path']),'expected_decoded_sha256':ref['decoded_sha256']}
        assert physical[name]['sha256']==ref['sha256']
    after={p.relative_to(ROOT).as_posix():fingerprint(p) for p in paths};assert before==after
    proof={'成功':True,'自然生成未実行':True,'自然本文読取':False,'新売買又は金融':False,
        'Raw_CSV_追加2場読取':False,'時刻':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        '人工主群数':9,'人工':results,'構文と複数行関数コメント':parsed,
        '入力物理指紋のみ':physical,'源':{p:v['sha256'] for p,v in before.items()},'源stat':before,
        '源前後SHA_stat同体':True,'独立レビュー担当':'archive130（別所有folder、別Fraction oracle及び生成prefix人工）'}
    save(HERE/'準備の確認.json',proof)
    stop={'成功':True,'編集停止':True,'自然生成未実行':True,'源':proof['源'],
        '準備の確認SHA256':digest(HERE/'準備の確認.json'),'入力本文_新売買_金融_未読':True,
        '次段階':'Rootレビュー後の明示実行、独立全件照合後に同体gzip一度保存'}
    save(HERE/'停止.json',stop)
    print(json.dumps({'成功':True,'準備SHA256':stop['準備の確認SHA256'],'停止SHA256':digest(HERE/'停止.json')},ensure_ascii=False))


if __name__=='__main__':
    main()
