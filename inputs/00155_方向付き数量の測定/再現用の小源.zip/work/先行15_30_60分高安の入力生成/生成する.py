"""許可された147/148の2gzipだけから、先行高安の参照入力を一度生成する。"""
from pathlib import Path
from collections import defaultdict, Counter
import argparse
import gzip
import hashlib
import json
import re
import time
import 先行高安 as core

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
INPUTS = {
    'parent147': ('inputs/00147_中位価格位置と実体回復/Sourceの出生と取得.json.gz',
                  'b99c49f06fe7e2306e59733b1cff26e3bb351f64edee220c98bc30b62c016d77',
                  'd42d25ec0fe41e8358c1227fd71b4377ffa90c96a8cf582f1ee4537ebf455d63'),
    'ledger148': ('inputs/00148_全1分入口母集団/出生台帳.json.gz',
                  '9d589488bca8e83be3fd23ed230b6f7cae176acbbe96dd2d04a62d3bbfb6e753',
                  '4f4d3ce3a652170d5d5f15941b591493592d5816bb0985c2e70c86b14323b219')}


def fingerprint(path: Path) -> dict:
    """
    機能: 明示入力の物理SHA・サイズ・更新時刻を前後stat付きで得る。
    引数: path(Path)。返り値: dict。
    """
    before = path.stat(); digest = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1 << 20), b''): digest.update(block)
    after = path.stat()
    assert (before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns)
    return {'path': path.resolve().relative_to(ROOT).as_posix(), 'bytes': before.st_size,
            'mtime_ns': before.st_mtime_ns, 'sha256': digest.hexdigest()}


# ----------------------------------------
def read_gzip(path: Path, decoded: str) -> dict:
    """
    機能: 全gzip CRCと解凍SHAを照合し、plain副本を保存せず読む。
    引数: path(Path)、decoded(str)。返り値: dict。
    """
    with gzip.open(path, 'rb') as source: body = source.read()
    assert hashlib.sha256(body).hexdigest() == decoded
    return json.loads(body)


# ----------------------------------------
def array_items(path: Path, name: str, evidence: dict):
    """
    機能: 保存JSONのtop配列を場単位で読み、全解凍SHA・CRCを完読確認する。
    引数: path(Path)、name(str)、evidence(dict)。返り値: Iterator[dict]。
    """
    digest = hashlib.sha256(); size = 0; decoder = json.JSONDecoder(); buffer = ''
    marker = re.compile(r'(?m)^  "' + re.escape(name) + r'": \[')
    with gzip.open(path, 'rt', encoding='utf-8', newline='') as source:
        def more() -> str:
            """
            機能: 文字境界を維持して全解凍bytesを順に指紋へ加える。
            引数: なし。返り値: str。
            """
            nonlocal size
            block = source.read(1 << 20); raw = block.encode('utf-8')
            digest.update(raw); size += len(raw)
            return block
        while True:
            block = more(); assert block, 'top配列がない'
            buffer += block; found = marker.search(buffer)
            if found: buffer = buffer[found.end():]; break
        while True:
            buffer = buffer.lstrip()
            if buffer.startswith(']'): break
            if buffer.startswith(','): buffer = buffer[1:].lstrip()
            try: value, end = decoder.raw_decode(buffer)
            except json.JSONDecodeError:
                block = more(); assert block, 'top配列が途中終了した'
                buffer += block; continue
            yield value
            buffer = buffer[end:]
        while more(): pass
    evidence.update(decoded_sha256=digest.hexdigest(), decoded_bytes=size, full_gzip_crc_checked=True)


# ----------------------------------------
def generate(output_dir: Path, preparation_sha: str) -> dict:
    """
    機能: 準備票と固定2入力を照合し、全73場の入力gzipを新規作成する。
    引数: output_dir(Path)、preparation_sha(str)。返り値: dictは完了票。
    """
    target_dir = output_dir.resolve()
    assert target_dir.is_relative_to(ROOT / 'work'), '今回の作業入力はwork内だけ'
    ready_path = HERE / '準備の確認.json'
    assert fingerprint(ready_path)['sha256'] == preparation_sha
    ready = json.loads(ready_path.read_bytes())
    assert ready['成功'] and ready['自然本文読取'] is False
    assert all(fingerprint(HERE / name)['sha256'] == value for name, value in ready['固定源'].items())
    target_dir.mkdir(parents=True, exist_ok=True)
    output = target_dir / '先行高安の入力.json.gz'; proof_path = target_dir / '生成の確認.json'
    assert not output.exists() and not proof_path.exists()
    before = {key: fingerprint(ROOT / value[0]) for key, value in INPUTS.items()}
    assert all(before[key]['sha256'] == value[1] for key, value in INPUTS.items())
    started = time.monotonic()
    ledger = read_gzip(ROOT / INPUTS['ledger148'][0], INPUTS['ledger148'][2])
    assert ledger['success'] is True and ledger['trial'] == 148 and ledger['financial_labels_used'] is False
    assert ledger['strategy_selected'] is False and ledger['selected_trade_count'] is None
    assert ledger['selected_trade_frequency'] is None
    sessions = ledger['sessions']; assert len(sessions) == len(set(sessions)) == 73
    grouped = defaultdict(list)
    ids = set()
    for row in ledger['rows']:
        assert row['session'] in sessions and row['event_id'] not in ids
        ids.add(row['event_id']); grouped[row['session']].append(row)
    assert len(ledger['rows']) == 40544 and sum(row['eligible'] for row in ledger['rows']) == 35339
    assert set(grouped) == set(sessions)
    del ledger
    counts = Counter(); window_counts = {str(width): Counter() for width in core.WINDOWS}
    decoded, written_sessions, compact_sha, decoded_size = {}, [], hashlib.sha256(), 0
    with output.open('xb') as physical:
        with gzip.GzipFile(filename='', fileobj=physical, mode='wb', mtime=0) as zipped:
            def emit(value: str) -> None:
                """
                機能: 生成JSONをgzipへ直接書き、同じ解凍bytesの指紋を残す。
                引数: value(str)。返り値: None。
                """
                nonlocal decoded_size
                raw = value.encode('utf-8'); zipped.write(raw)
                compact_sha.update(raw); decoded_size += len(raw)
            header = {'schema': 'prior_time_range_v1', 'windows_minutes': list(core.WINDOWS),
                      'comparison_domain': '[r.Start-W,r.Start)、最新rを含めない実時間窓',
                      'source_refs': {key: {'path': value[0], 'sha256': value[1], 'decoded_sha256': value[2]}
                                      for key, value in INPUTS.items()},
                      'sessions': sessions, 'selected_trade_count': None, 'selected_trade_frequency': None,
                      'strategy_selected': False, 'financial_labels_used': False}
            emit(json.dumps(header, ensure_ascii=False, allow_nan=False)[:-1] + ',"scenes":[')
            for scene in array_items(ROOT / INPUTS['parent147'][0], 'scenes', decoded):
                assert scene['session'] == sessions[len(written_sessions)]
                # 価格利用は配送済みbarsと、そのq0を示すContext.Atに限定する。
                scoped = {key: scene[key] for key in ('success', 'session', 'contract', 'start', 'end', 'force_close', 'bars')}
                report = core.inspect_scene(scoped, grouped.pop(scene['session']))
                if written_sessions: emit(',')
                emit(json.dumps(report, ensure_ascii=False, separators=(',', ':'), allow_nan=False))
                written_sessions.append(scene['session']); counts.update(report['counts']); counts['bars'] += len(report['bars'])
                for key, value in report['window_counts'].items(): window_counts[key].update(value)
                if len(written_sessions) % 20 == 0:
                    print(json.dumps({'非金融進捗場数': len(written_sessions)}, ensure_ascii=False), flush=True)
            assert decoded['decoded_sha256'] == INPUTS['parent147'][2]
            assert not grouped and written_sessions == sessions
            assert counts['all_q0'] == 40544 and counts['eligible_q0'] == 35339 and counts['bars'] == 43124
            assert counts['delivered_bar_refs_checked'] == 43124
            assert before == {key: fingerprint(ROOT / value[0]) for key, value in INPUTS.items()}
            tail = {'success': True, 'counts': dict(counts), 'window_counts': {key: dict(value) for key, value in window_counts.items()},
                    'full_batch_latest_last4_clock_verified': True, 'complete_range_only': True,
                    'range_unknown_is_null': True, 'observed_high_low_fallback': False}
            emit('],' + json.dumps(tail, ensure_ascii=False, separators=(',', ':'), allow_nan=False)[1:] + '\n')
    result = {'成功': True, '自然生成回数': 1, '目的': '非金融の先行高安入力。採否/100X/新試行/金融を生成しない。',
              '準備SHA256': preparation_sha, '入力': before, 'Source147解凍': decoded,
              'ledger148解凍SHA256': INPUTS['ledger148'][2], '両gzip全CRC照合': True,
              '出力': {**fingerprint(output), 'decoded_sha256': compact_sha.hexdigest(), 'decoded_bytes': decoded_size},
              '全場': len(sessions), '全q0': counts['all_q0'], 'eligible_q0': counts['eligible_q0'],
              '全配送bar': counts['bars'], '件数': dict(counts), '窓件数': {key: dict(value) for key, value in window_counts.items()},
              '全入力前後SHA_stat同体': True, '全配送/最新/4slot/非未来時計一致': True,
              '価格利用範囲': '147配送barsとContext.At、148出生台帳だけ。rの未知は保持する。',
              '全窓barID配列/CSV参照/大入力の反復複写': False,
              '既存100X/採否/教師/金融/Raw/追加2場/新採番': False,
              'elapsed_seconds': time.monotonic() - started}
    with proof_path.open('x', encoding='utf-8', newline='\n') as target:
        json.dump(result, target, ensure_ascii=False, indent=2, allow_nan=False); target.write('\n')
    return result


# ----------------------------------------
def main() -> None:
    """
    機能: Rootの人工レビュー後の明示指定だけで自然生成を許可する。
    引数: CLI --prepare-sha256(str)、--output-dir(Path)、--execute-after-review(flag)。
    返り値: None。入力pathは許可済み2gzipへ固定し、出力はwork内だけへ新規作成する。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--prepare-sha256', required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--execute-after-review', action='store_true', required=True)
    args = parser.parse_args()
    result = generate(args.output_dir, args.prepare_sha256)
    print(json.dumps({'成功': True, '全q0': result['全q0'], '出力': result['出力']}, ensure_ascii=False))


if __name__ == '__main__': main()
