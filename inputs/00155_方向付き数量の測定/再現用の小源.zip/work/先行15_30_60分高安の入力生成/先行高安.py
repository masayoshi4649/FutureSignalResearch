"""配送済み1分履歴から、最新rを除く厳密な実時間窓だけを計測する純部品。"""
from collections import Counter
import math

WINDOWS = (15, 30, 60)
SLOT_FIELDS = ('id', 'start', 'end', 'available_at', 'stamp', 'price_known', 'volume_known', 'closed')


def finite(value: object) -> bool:
    """
    機能: boolと非有限を数値の既知値から除く。
    引数: value(object)。返り値: bool。
    """
    return type(value) in (int, float) and math.isfinite(value)


# ----------------------------------------
def stamp(value: dict) -> tuple:
    """
    機能: Source Stamp又はq0の時刻・index・物理行を厳密に取り出す。
    引数: value(dict)。返り値: tuple[float,int,int]。不正型は拒否する。
    """
    time, index = value['time'], value['index']
    line = value['line'] if 'line' in value else value['source_line']
    assert finite(time) and type(index) is int and index >= 0
    assert type(line) is int and line > 0
    return time, index, line


# ----------------------------------------
def slot_ref(bar: dict) -> dict:
    """
    機能: 148の当時slot参照を147足から再構成する。
    引数: bar(dict)。返り値: dict。入力は変更しない。
    """
    return {key: bar[key] for key in SLOT_FIELDS}


# ----------------------------------------
def validate_bar(bar: dict, q0: dict | None = None) -> None:
    """
    機能: 1分足の値・格子と、照会時点より未来でない配送を確認する。
    引数: bar(dict)、q0(dict|None)。返り値: None。品質未知はエラーにせず保持する。
    """
    assert type(bar['id']) is str and bar['id'] and bar['session'] and bar['contract']
    assert type(bar['width_seconds']) is int and bar['width_seconds'] == 60
    start, end, available = bar['start'], bar['end'], bar['available_at']
    assert all(finite(v) for v in (start, end, available)) and end == start + 60
    at = stamp(bar['stamp'])
    assert available == end + 60 and available <= at[0]
    for key in ('price_known', 'volume_known', 'closed', 'missing'):
        assert type(bar[key]) is bool
    if bar['price_known']:
        prices = bar['ohlc']
        assert set(prices) == {'open', 'high', 'low', 'close'}
        assert all(finite(v) for v in prices.values()) and prices['low'] > 0
        assert prices['low'] <= prices['open'] <= prices['high']
        assert prices['low'] <= prices['close'] <= prices['high']
    if q0 is not None:
        now = stamp(q0)
        assert all(left <= right for left, right in zip(at, now)), '未来配送を使用しない'


# ----------------------------------------
def compact_bar(bar: dict) -> dict:
    """
    機能: rと極値を復元できる最小のbar正本を一度だけ保存する。
    引数: bar(dict)。返り値: dict。CSV参照・背景・反復窓ID配列は含めない。
    """
    return {**slot_ref(bar), 'stamp': dict(bar['stamp']), 'missing': bar['missing'],
            'ohlc': dict(bar['ohlc']) if bar['price_known'] else None}


# ----------------------------------------
def compact_quote(quote: dict) -> dict:
    """
    機能: q0の時計と各価格の既知性を保持し、正常実BBOを独立に示す。
    引数: quote(dict)。返り値: dict。異常BBOを窓高安の除外理由にしない。
    """
    stamp(quote)
    assert type(quote['quote_ok']) is bool
    out = {key: quote[key] for key in ('time', 'index', 'source_line')}
    if 'clock' in quote:
        assert isinstance(quote['clock'], str)
        out['clock'] = quote['clock']
    for key in ('last', 'bid', 'ask'):
        ok = finite(quote[key]) and quote[key] > 0
        out[key] = quote[key] if ok else None
        out[key + '_known'] = ok
    out['quote_ok'] = quote['quote_ok']
    out['normal_bbo'] = (quote['quote_ok'] and out['bid_known'] and out['ask_known']
                         and quote['bid'] < quote['ask'])
    return out


# ----------------------------------------
def extreme_ref(bar: dict) -> dict:
    """
    機能: 最初の極値足のIDと市場時刻だけを参照として残す。
    引数: bar(dict)。返り値: dict。配送時刻は一度保存するbar正本へ参照する。
    """
    return {key: bar[key] for key in ('id', 'start', 'end')}


# ----------------------------------------
def prior_range(history: list[dict], q0: dict, session_start: float, minutes: int) -> dict:
    """
    機能: 最新rを除く[r.Start−W,r.Start)の完全既知高安だけを求める。
    引数: history(list[dict])は当場配送prefix、q0(dict)、session_start(float)、minutes(int)。
    返り値: dict。未知なら高安・極値参照・幅・range_zeroはnull。観測高安fallbackはしない。
    """
    assert history and type(minutes) is int and minutes in WINDOWS and finite(session_start)
    r = history[-1]
    validate_bar(r, q0)
    assert r['start'] >= session_start and (r['start'] - session_start) % 60 == 0
    start, end = r['start'] - minutes * 60, r['start']
    selected = [bar for bar in history[:-1] if start <= bar['start'] < end]
    by_start = {}
    for bar in selected:
        validate_bar(bar, q0)
        assert (bar['session'], bar['contract']) == (r['session'], r['contract'])
        assert bar['start'] >= session_start and (bar['start'] - session_start) % 60 == 0
        assert bar['start'] not in by_start and bar['id'] != r['id']
        by_start[bar['start']] = bar
    positions = [start + i * 60 for i in range(minutes)]
    ordered = [by_start[at] for at in positions if at in by_start]
    missing = sum(bar['missing'] for bar in ordered)
    closed = sum(bar['closed'] for bar in ordered)
    price = sum(bar['price_known'] for bar in ordered)
    count = len(ordered)
    absent = minutes - count
    before_session = sum(at < session_start for at in positions)
    reasons = []
    if before_session: reasons.append('before_session')
    if absent > before_session: reasons.append('absent_slot')
    if missing: reasons.append('missing')
    if closed != count: reasons.append('not_closed')
    if price != count: reasons.append('price_unknown')
    known = count == minutes and not reasons
    out = {'from': start, 'to': end, 'duration_seconds': minutes * 60,
           'expected_count': minutes, 'slot_record_count': count,
           'observed_count': count - missing, 'closed_count': closed,
           'price_known_count': price, 'missing_count': missing,
           'absent_count': absent, 'before_session_count': before_session,
           'known': known, 'unknown_reasons': reasons, 'high': None, 'low': None,
           'high_first_ref': None, 'low_first_ref': None, 'range_points': None, 'range_zero': None}
    if known:
        high = max(bar['ohlc']['high'] for bar in ordered)
        low = min(bar['ohlc']['low'] for bar in ordered)
        high_bar = next(bar for bar in ordered if bar['ohlc']['high'] == high)
        low_bar = next(bar for bar in ordered if bar['ohlc']['low'] == low)
        out.update(high=high, low=low, high_first_ref=extreme_ref(high_bar), low_first_ref=extreme_ref(low_bar),
                   range_points=high - low, range_zero=high == low)
    return out


# ----------------------------------------
def inspect_scene(scene: dict, ledger: list[dict]) -> dict:
    """
    機能: 同Raw全配送/4slot参照を照合し、全q0に3種類の先行窓を付ける。
    引数: scene(dict)は147一場のbars、ledger(list[dict])は148同場全q0。
    返り値: dictは当場bar最小正本・全q0・分母付き件数。採否・特徴・金融は参照しない。
    """
    assert scene['success'] is True and ledger and scene['bars']
    bars, start = scene['bars'], scene['start']
    previous = None
    for i, known in enumerate(bars):
        bar = known['bar']; validate_bar(bar)
        assert (bar['session'], bar['contract']) == (scene['session'], scene['contract'])
        assert bar['start'] == start + i * 60 and bar['end'] <= scene['end'] - 300
        at = stamp(bar['stamp'])
        assert stamp(known['context']['at']) == at
        if previous is not None:
            assert all(a <= b for a, b in zip(previous, at))
            if at != previous: assert at[1] > previous[1] and at[2] > previous[2]
        previous = at
    rows, history, cursor, previous = [], [], 0, None
    counts = Counter()
    windows = {str(width): Counter() for width in WINDOWS}
    ids = set()
    for source in ledger:
        q0 = source['q0']; now = stamp(q0)
        assert (source['session'], source['contract']) == (scene['session'], scene['contract'])
        assert source['event_id'] not in ids; ids.add(source['event_id'])
        if previous is not None:
            assert now[0] >= previous[0] and now[1] > previous[1] and now[2] > previous[2]
        previous = now; batch = []
        while cursor < len(bars) and stamp(bars[cursor]['bar']['stamp'])[1] <= now[1]:
            known = bars[cursor]; bar = known['bar']
            assert stamp(bar['stamp']) == now and known['context']['at'] == q0
            validate_bar(bar, q0); batch.append(bar); history.append(bar); cursor += 1
        assert batch, '配送のないRawをq0へ追加しない'
        r = history[-1]
        assert slot_ref(r) == source['latest_bar_ref']
        assert [slot_ref(bar) for bar in history[-4:]] == source['slot_refs']
        assert [slot_ref(bar) for bar in batch] == source['delivered_bar_refs']
        eligible = (r['price_known'] and r['closed'] and q0['time'] < r['end'] + 120
                    and q0['time'] < min(scene['force_close'], scene['end'] - 3900))
        assert type(source['eligible']) is bool and source['eligible'] == eligible
        assert source['feature_generated'] is eligible
        assert source['feature_ref'] == (source['event_id'] if eligible else None)
        ranges = {str(width): prior_range(history, q0, start, width) for width in WINDOWS}
        rows.append({'event_id': source['event_id'], 'eligible': eligible,
                     'quote_ref': {'source': 'ledger148', 'event_id': source['event_id']},
                     'q0': compact_quote(q0), 'r_ref': r['id'],
                     'slot_refs': [bar['id'] for bar in history[-4:]],
                     'delivered_refs': [bar['id'] for bar in batch], 'prior_ranges': ranges})
        counts['all_q0'] += 1; counts['eligible_q0'] += int(eligible)
        counts['delivered_bar_refs_checked'] += len(batch)
        counts['same_raw_catchup_q0'] += int(len(batch) > 1)
        for key, value in ranges.items():
            windows[key]['all_q0'] += 1; windows[key]['eligible_q0'] += int(eligible)
            windows[key]['known_all_q0'] += int(value['known'])
            windows[key]['known_eligible_q0'] += int(value['known'] and eligible)
            windows[key]['range_zero_all_q0'] += int(value['range_zero'] is True)
    assert cursor == len(bars), '未照合の配送barを残さない'
    assert len({known['bar']['id'] for known in bars}) == len(bars)
    return {'session': scene['session'], 'contract': scene['contract'], 'start': start,
            'continuous_end': scene['end'] - 300, 'bars': [compact_bar(known['bar']) for known in bars],
            'rows': rows, 'counts': dict(counts), 'window_counts': {key: dict(value) for key, value in windows.items()}}
