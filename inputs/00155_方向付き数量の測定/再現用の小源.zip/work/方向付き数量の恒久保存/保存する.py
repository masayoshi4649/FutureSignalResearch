"""数量の自然全件独立合格後、gzipを一度だけ恒久化し小さい再現源を保存する。"""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
SOURCE=ROOT/'work/方向付き数量の自然入力/方向付き数量の入力.json.gz'
GENERATED=SOURCE.parent/'生成の確認.json'
PREPARED=ROOT/'work/方向付き数量の入力準備/準備の確認.json'
DESTINATION=ROOT/'inputs/00155_方向付き数量の測定'
PHYSICAL='947dd612858e5560debe0c350c73eda2a12d821f515bd6f9627c2040676901d3'
DECODED='9b8ace0d3ec2649ab484762d3bf8dc35b0a229ebe3c384a6e875cc74252be4f0'


def sha(path: Path) -> str:
    """
    機能: ファイルの物理bytesを固定bufferで指紋化する。
    引数: path(Path)。返り値: str。
    """
    digest=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1<<20),b''):digest.update(block)
    return digest.hexdigest()


def fingerprint(path: Path) -> dict:
    """
    機能: SHAとサイズ・mtimeの読取中不変を確認する。
    引数: path(Path)。返り値: dict。
    """
    before=path.stat();digest=sha(path);after=path.stat()
    assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns)
    return {'sha256':digest,'bytes':before.st_size,'mtime_ns':before.st_mtime_ns}


def decoded(path: Path) -> dict:
    """
    機能: gzip末尾まで全CRCを確認し解凍SHAとサイズだけを求める。
    引数: path(Path)。返り値: dict。解凍副本や全JSONを保存しない。
    """
    digest=hashlib.sha256();count=0
    with gzip.open(path,'rb') as stream:
        for block in iter(lambda:stream.read(1<<20),b''):digest.update(block);count+=len(block)
    assert digest.hexdigest()==DECODED
    return {'decoded_sha256':digest.hexdigest(),'decoded_bytes':count,'full_gzip_crc_checked':True}


def save(path: Path,value: dict) -> None:
    """
    機能: 既存小票を上書きせずUTF8で保存する。
    引数: path(Path)、value(dict)。返り値: None。
    """
    with path.open('x',encoding='utf-8',newline='\n') as stream:json.dump(value,stream,ensure_ascii=False,indent=2,allow_nan=False);stream.write('\n')


def main() -> None:
    """
    機能: 指定独立票の成功と全指紋を確認し、唯一の恒久gzipと再現ZIPを作る。
    引数: CLI independent-proof(Path)/independent-sha256(str)。返り値: None。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--independent-proof',required=True,type=Path);parser.add_argument('--independent-sha256',required=True);args=parser.parse_args()
    args.independent_proof=args.independent_proof.resolve();resume=DESTINATION.exists()
    if resume:assert sorted(p.name for p in DESTINATION.iterdir())==[SOURCE.name],'保存完了先へ追記不可'
    assert sha(args.independent_proof)==args.independent_sha256
    independent=json.loads(args.independent_proof.read_bytes());assert independent['成功'] is True
    assert PHYSICAL in json.dumps(independent,ensure_ascii=False),'別測定の独立票'
    generated=json.loads(GENERATED.read_bytes());prepared=json.loads(PREPARED.read_bytes())
    assert generated['成功'] and generated['自然生成回数']==1 and generated['新売買又は金融'] is False
    assert generated['出力']['sha256']==PHYSICAL and generated['出力']['decoded_sha256']==DECODED
    assert generated['counts']=={'all_q0':40544,'eligible_q0':35339,'bars_joined':43124}
    assert sha(PREPARED)==generated['準備SHA256'] and prepared['成功']
    sources=[ROOT/path for path in prepared['源']]
    assert all(sha(ROOT/path)==value for path,value in prepared['源'].items())
    inputs=[ROOT/ref['path'] for ref in generated['入力'].values()]
    independent_sources=[args.independent_proof.parent/name for name in ('監査する.py','独立確認.json','README.md','停止の確認.json')]
    assert args.independent_proof in independent_sources and all(p.exists() for p in independent_sources)
    tracked=[SOURCE,GENERATED,PREPARED,*independent_sources,Path(__file__),*sources,*inputs]
    tracked=list(dict.fromkeys(tracked));before={str(p):fingerprint(p) for p in tracked}
    assert before[str(SOURCE)]['sha256']==PHYSICAL
    assert all(before[str(ROOT/ref['path'])]['sha256']==ref['sha256'] for ref in generated['入力'].values())
    source_crc=decoded(SOURCE);assert source_crc['decoded_bytes']==generated['出力']['decoded_bytes']==190388567
    # ----------------------------------------
    # 独立合格を確認した後にだけ物理gzipを一度保存し、副本解凍を作らない。
    target=DESTINATION/SOURCE.name
    if not resume:
        DESTINATION.mkdir()
        with SOURCE.open('rb') as source,target.open('xb') as sink:
            for block in iter(lambda:source.read(1<<20),b''):sink.write(block)
    assert fingerprint(target)['sha256']==PHYSICAL and target.stat().st_size==generated['出力']['bytes']==8215183
    target_crc=decoded(target);assert target_crc==source_crc
    selected=[*sources,PREPARED,PREPARED.parent/'停止.json',GENERATED,*independent_sources,Path(__file__)]
    selected=list(dict.fromkeys(selected));manifest={p.relative_to(ROOT).as_posix():sha(p) for p in selected}
    packed=DESTINATION/'再現用の小源.zip'
    with zipfile.ZipFile(packed,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for p in selected:
            info=zipfile.ZipInfo(p.relative_to(ROOT).as_posix(),date_time=(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            archive.writestr(info,p.read_bytes())
        archive.writestr('源の指紋.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    with zipfile.ZipFile(packed) as archive:
        assert archive.testzip() is None
        for name,value in manifest.items():assert hashlib.sha256(archive.read(name)).hexdigest()==value
    result_ref={'path':target.relative_to(ROOT).as_posix(),'sha256':PHYSICAL,'bytes':8215183,**target_crc}
    readme=f'''# 方向付き数量の測定入力

2026-11-12。Rootが自然測定を1回実行し、別担当の全件独立照合合格後に物理gzipを同体で一度保存した。新Raw/CSV/追加2場の読取、新売買採否・容量・損益・モデル変更は行っていない。100特徴と旧固定源は不変更。

## 正本と指紋

- 正本：`方向付き数量の入力.json.gz`、schema `directional_volume_v1`。
- 物理：8,215,183 bytes / SHA256 `{PHYSICAL}`。
- 解凍：190,388,567 bytes / SHA256 `{DECODED}`。
- 全73場・全40,544q0・適格35,339・元1分43,124足。元/保存gzipとも全CRC・解凍SHAが一致し、解凍副本は残していない。
- 独立全件票：`{args.independent_proof.relative_to(ROOT).as_posix()}`、SHA256 `{args.independent_sha256}`。その原票は[再現用小源ZIP](再現用の小源.zip)にも収録。

## 由来・式・時計

147の既知1分量と153のcanonical1分価格・全q0を全足ID/OHLC/品質/Stampで結合する。価格未知は双方の未知maskを照合し、内部0を既知価格とは扱わない。147JSON内の旧注文/取得属性は復号されるが、計算へ渡すのはbars/context.atだけ。旧events/選択/金融は採用しない。

OBV変化5/15/30はr含むw本の `Σ sign(C_i−C_prev)×V_i`。前Close用のw+1価格・当w本量が必要で、同値Closeは加減0。比はΣV>0時だけ。CMF20はr含む20本の `Σ((2C−H−L)/(H−L)×V)/ΣV`、H=LはMFM既知0、ΣV=0は値未定義。前CMFは同q0知得prefixの1分ずらした市場窓、Δは両値defined時のみ。入替えΔを新規資金流入そのものとは呼ばない。

各windowは実時間格子・known/defined・null・0・品質counts・窓端refsを分離。未知を0に補わず、欠分を詰めず、同場/同限月だけを使う。rの初配送Stamp=q0、過去足も全End/AvailableAt/Stamp.Time/Index/Line≤q0。CSV足モデルAvailableAt=End+60と実Raw初配送Stampを区別し、Rawネイティブ/実受信時刻の再現とは呼ばない。

## 再現

小源ZIP SHA256 `{sha(packed)}`。既存研究リポジトリの別作業コピーへ元の相対パスで展開し、源の指紋を確認する。巨大元入力147/153は下記共用gzipを参照し、ZIPへ重ねない。`work/方向付き数量の入力準備/生成する.py` を `--prepare-sha256 {generated['準備SHA256']} --output-dir work/方向付き数量の再現入力 --execute-after-review` で未作成先へ実行する。子Pythonは `work/複合テクニカル学習環境/Scripts/python.exe -X utf8`。元準備・停止票は過去の自然未実行時点を記録した原文であり、本保存後の状態へ書き換えない。

旧29 OBV/42-43 CMF/47-48 Forceの未達は保持する。今回は広い1分母集団への因果測定で、数量単独有効性の証明でも売買条件でもない。

## 共用元入力

```json
{json.dumps(generated['入力'],ensure_ascii=False,indent=2)}
```
'''
    (DESTINATION/'README.md').write_text(readme,encoding='utf-8',newline='\n')
    assert before=={str(p):fingerprint(p) for p in tracked}
    proof={'成功':True,'自然測定の追加実行':False,'恒久gzipコピー回数':1,'既存同体gzipから小票のみ再開':resume,'正本':result_ref,
        '元保存全CRC解凍SHA同体':True,'解凍副本保存':False,'源入力前後同体':True,
        '入力とSource前後':before,'独立票':{'path':args.independent_proof.relative_to(ROOT).as_posix(),'sha256':args.independent_sha256},
        '小源ZIP':{'path':packed.relative_to(ROOT).as_posix(),'sha256':sha(packed),'bytes':packed.stat().st_size,'源':manifest},
        'README_SHA256':sha(DESTINATION/'README.md'),'counts':generated['counts'],'window_counts':generated['window_counts'],
        '新売買_金融_モデル_100X変更':False,'Raw_CSV_追加2場読取':False}
    save(DESTINATION/'入力の保存確認.json',proof)
    print(json.dumps({'成功':True,'正本':result_ref,'保存確認SHA256':sha(DESTINATION/'入力の保存確認.json'),'小源ZIP_SHA256':sha(packed)},ensure_ascii=False))


if __name__=='__main__':
    main()
