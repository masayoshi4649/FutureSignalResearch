package midrecover147

import (
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

type ShortTracker struct {
	session, contract string
	start, end, next  float64
	previous          rules.Stamp
	has               bool
	stats             map[string]int
}

// NewShort は数値助走を持たない1分形状の配送検査器を作ります。
//
// 引数: なし。返り値: *ShortTrackerです。
func NewShort() *ShortTracker { return &ShortTracker{} }

// StartSession は形状/配送状態を毎場coldにします。
//
// 引数: session/contract(string)、start/end(float64)、carry(bool)は互換で常に不使用。返り値: errorです。
func (s *ShortTracker) StartSession(session, contract string, start, end float64, carry bool) error {
	if session == "" || contract == "" || !finite(start, end) || end <= start {
		return fmt.Errorf("1分場指定差")
	}
	*s = ShortTracker{session: session, contract: contract, start: start, end: end, next: start, stats: map[string]int{}}
	return nil
}

// Add は実配送prefixだけから正確1分格子の正本を一つ返します。
//
// 引数: m(Minute)。返り値: []ShortBar/errorです。
func (s *ShortTracker) Add(m Minute) ([]ShortBar, error) {
	if m.Session != s.session || m.Contract != s.contract || m.Start != s.next || m.End != m.Start+60 || m.End > s.end || m.AvailableAt != m.End+60 || m.Stamp.Time < m.AvailableAt || m.Stamp.Index < 0 || m.Stamp.Line < 1 {
		return nil, fmt.Errorf("1分配送scope/格子/時計差")
	}
	if s.has && (m.Stamp.Time < s.previous.Time || m.Stamp.Index < s.previous.Index || m.Stamp.Line < s.previous.Line) {
		return nil, fmt.Errorf("1分配送後退")
	}
	s.has = true
	s.previous = m.Stamp
	s.next = m.End
	s.stats["配送1分"]++
	ref := m.CSV
	b := ShortBar{ID: m.ID, Session: m.Session, Contract: m.Contract, Width: 60, Start: m.Start, End: m.End, AvailableAt: m.AvailableAt, Stamp: m.Stamp, PriceKnown: m.PriceKnown, VolumeKnown: m.VolumeKnown, Closed: m.Closed, Missing: m.Missing, OHLC: m.OHLC, Volume: m.Volume, CSV: &ref, CSVLine: m.CSVLine}
	return []ShortBar{b}, nil
}

// Stats は内部mapを公開せず当場件数を返します。
//
// 引数: なし。返り値: map[string]intです。
func (s *ShortTracker) Stats() map[string]int {
	out := map[string]int{}
	for k, v := range s.stats {
		out[k] = v
	}
	return out
}
