package midrecover147

import rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"

type ShortBar struct {
	ID          string      `json:"id"`
	Session     string      `json:"session"`
	Contract    string      `json:"contract"`
	Width       int         `json:"width_seconds"`
	Start       float64     `json:"start"`
	End         float64     `json:"end"`
	AvailableAt float64     `json:"available_at"`
	Stamp       rules.Stamp `json:"stamp"`
	PriceKnown  bool        `json:"price_known"`
	VolumeKnown bool        `json:"volume_known"`
	Closed      bool        `json:"closed"`
	Missing     bool        `json:"missing"`
	OHLC        rules.OHLC  `json:"ohlc"`
	Volume      float64     `json:"volume"`
	CSV         *FileRef    `json:"csv,omitempty"`
	CSVLine     int         `json:"csv_line,omitempty"`
}

type BBWindow struct {
	ID    string      `json:"id"`
	Bands rules.Bands `json:"bands"`
	Refs  []rules.Ref `json:"refs"`
}

type Context struct {
	At          Quote                  `json:"at"`
	Direction30 int                    `json:"direction30"`
	Fields      map[string]rules.Value `json:"fields"`
	Refs        []rules.Ref            `json:"refs"`
	BBWindowID  string                 `json:"bb_window_id"`
	BB15        rules.Bands            `json:"bb15"`
}

type KnownBar struct {
	Bar     ShortBar `json:"bar"`
	Context Context  `json:"context"`
}

type Scene struct {
	Session          string              `json:"session"`
	Contract         string              `json:"contract"`
	Start            float64             `json:"start"`
	End              float64             `json:"end"`
	ForceClose       float64             `json:"force_close"`
	Cutoff           float64             `json:"cutoff"`
	Raw              FileRef             `json:"raw"`
	ExpectedAccepted int64               `json:"expected_accepted"`
	ExpectedQuality  *Counts             `json:"expected_quality"`
	Publications     []rules.Publication `json:"publications"`
	CSV              FileRef             `json:"csv"`
}

type Structure struct {
	K           float64 `json:"k"`
	I           float64 `json:"i"`
	Width       float64 `json:"width"`
	Cap         float64 `json:"cap"`
	ArmATR      float64 `json:"arm_atr"`
	CapATRWidth int     `json:"cap_atr_width_seconds"`
	BBMean      float64 `json:"bb_mean"`
	BBForward   float64 `json:"bb_forward"`
	BBWindowID  string  `json:"bb_window_id"`
}

type Trace struct {
	Stage   string                 `json:"stage"`
	Reason  string                 `json:"reason"`
	At      Quote                  `json:"at"`
	Context Context                `json:"context"`
	Fields  map[string]rules.Value `json:"fields"`
}

type Event struct {
	ID               string                 `json:"id"`
	Family           string                 `json:"family"`
	Width            int                    `json:"width_seconds"`
	Side             int                    `json:"side"`
	Status           string                 `json:"status"`
	Birth            Quote                  `json:"birth"`
	EntryQuote       *Quote                 `json:"entryQuote"`
	EntryPrice       *float64               `json:"entry_price"`
	Expires          float64                `json:"expires"`
	GroupID          string                 `json:"group_id"`
	Structure        Structure              `json:"structure"`
	Arm              rules.Ref              `json:"arm"`
	Confirm          rules.Ref              `json:"confirm"`
	Refs             []rules.Ref            `json:"refs"`
	Fields           map[string]rules.Value `json:"fields"`
	Reasons          []string               `json:"reasons"`
	Trace            []Trace                `json:"trace"`
	TerminationQuote *Quote                 `json:"terminationQuote"`
}

type Group struct {
	ID               string   `json:"id"`
	Side             int      `json:"side"`
	Birth            Quote    `json:"birth"`
	CandidateIDs     []string `json:"candidate_ids"`
	Status           string   `json:"status"`
	EntryQuote       *Quote   `json:"entryQuote"`
	FilledIDs        []string `json:"filled_candidate_ids"`
	RepresentativeID string   `json:"representative_id"`
	TerminationQuote *Quote   `json:"terminationQuote"`
}

type PatternCheck struct {
	Width      int                    `json:"width_seconds"`
	Family     string                 `json:"family"`
	At         Quote                  `json:"at"`
	R          rules.Ref              `json:"r"`
	UsedRefs   []rules.Ref            `json:"used_refs"`
	Gates      map[string]rules.Value `json:"gates"`
	Fields     map[string]rules.Value `json:"fields"`
	Status     string                 `json:"status"`
	Suppressed bool                   `json:"suppressed_by_pending"`
	Reasons    []string               `json:"reasons"`
}
