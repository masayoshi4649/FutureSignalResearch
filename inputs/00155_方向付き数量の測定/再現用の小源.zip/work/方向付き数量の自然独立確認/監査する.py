"""147/153と数量測定を場単位で照合する。作者測定/生成器はimportしない。"""
from collections import Counter
import datetime
import gzip
import hashlib
import json
import math
from pathlib import Path
import re
import time
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
FILES={
    '147':('inputs/00147_中位価格位置と実体回復/Sourceの出生と取得.json.gz','b99c49f06fe7e2306e59733b1cff26e3bb351f64edee220c98bc30b62c016d77','d42d25ec0fe41e8358c1227fd71b4377ffa90c96a8cf582f1ee4537ebf455d63'),
    '153':('inputs/00153_先行高安の独立出生/先行高安の入力.json.gz','2c020fed5b336ed0b417d8e72a07c6336ea475b09b9a2ff37f26ec4ce4d56bf8','8e145275dda385e4c2f87500978716654d10efb0903a4011f2bcc304a7906b14'),
    '数量':('work/方向付き数量の自然入力/方向付き数量の入力.json.gz','947dd612858e5560debe0c350c73eda2a12d821f515bd6f9627c2040676901d3','9b8ace0d3ec2649ab484762d3bf8dc35b0a229ebe3c384a6e875cc74252be4f0')}
CHECK=Counter()
MAX_ERROR=0.


def fingerprint(path: Path) -> dict:
    """
    機能: 物理入力のSHAとstatを読取前後で確定する。
    引数: path(Path)。返り値: dict。
    """
    before=path.stat();h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):h.update(block)
    after=path.stat();assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns)
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':before.st_size,'mtime_ns':before.st_mtime_ns,'SHA256':h.hexdigest()}


# ----------------------------------------
def finite(value: object) -> bool:
    """
    機能: bool/非有限を既知数値から除く。
    引数: value(object)。返り値: bool。
    """
    return type(value) in (int,float) and math.isfinite(value)


# ----------------------------------------
def equal(actual: object,expected: object,where: str) -> None:
    """
    機能: 全key/null/型を保持し数値だけNumPy許容差で再帰照合する。
    引数: actual/expected(object)、where(str)。返り値: None。
    """
    global MAX_ERROR
    if isinstance(expected,dict):
        assert isinstance(actual,dict) and set(actual)==set(expected),(where,'keys')
        for key,value in expected.items():equal(actual[key],value,where+'/'+str(key))
    elif isinstance(expected,list):
        assert isinstance(actual,list) and len(actual)==len(expected),(where,'length')
        for i,value in enumerate(expected):equal(actual[i],value,where+'/'+str(i))
    elif type(expected) is float:
        assert finite(actual) and math.isclose(actual,expected,rel_tol=1e-12,abs_tol=1e-8),(where,actual,expected)
        MAX_ERROR=max(MAX_ERROR,abs(actual-expected));CHECK['numeric']+=1;CHECK['leaf']+=1
    else:
        assert actual==expected and (type(actual) is bool)==(type(expected) is bool),(where,actual,expected)
        CHECK['leaf']+=1


# ----------------------------------------
def stamp(value: dict) -> tuple:
    """
    機能: 行表記差を正規化して配送の3時計を得る。
    引数: value(dict)。返り値: tuple[float,int,int]。
    """
    result=(value['time'],value['index'],value.get('line',value.get('source_line')))
    assert finite(result[0]) and type(result[1]) is int and result[1]>=0
    assert type(result[2]) is int and result[2]>0
    return result


# ----------------------------------------
def scenes(path: Path,evidence: dict):
    """
    機能: gzipを場単位で読み、全CRC/解凍SHAを終端まで検査する。
    引数: path(Path)、evidence(dict)。返り値: Iterator[dict]。
    """
    h=hashlib.sha256();size=0;buffer='';decoder=json.JSONDecoder()
    with gzip.open(path,'rt',encoding='utf-8',newline='') as source:
        def more() -> str:
            """
            機能: UTF8境界を保つ読取と解凍bytes指紋を更新する。
            引数: なし。返り値: str。
            """
            nonlocal size
            block=source.read(524288);raw=block.encode('utf-8');h.update(raw);size+=len(raw);return block
        while True:
            block=more();assert block,'scenesなし';buffer+=block;found=re.search(r'"scenes"\s*:\s*\[',buffer)
            if found:
                head=buffer[:found.start()].rstrip().rstrip(',')+'}'
                evidence['header']=json.loads(head)
                buffer=buffer[found.end():];break
        while True:
            buffer=buffer.lstrip()
            if buffer.startswith(']'):buffer=buffer[1:];break
            if buffer.startswith(','):buffer=buffer[1:].lstrip()
            try:value,end=decoder.raw_decode(buffer)
            except json.JSONDecodeError:
                block=more();assert block,'scenes途中終了';buffer+=block;continue
            yield value;buffer=buffer[end:]
        while True:
            block=more()
            if not block:break
            buffer+=block
        tail=buffer.lstrip().removeprefix(',')
        evidence['tail']=json.loads('{'+tail)
    evidence.update(decoded_SHA256=h.hexdigest(),decoded_bytes=size,全gzip_CRC=True)


# ----------------------------------------
def window(bars: list,start_index: int,end_index: int,session_start: float) -> tuple:
    """
    機能: 足を詰めない市場格子窓の品質と端点参照を独立再構成する。
    引数: bars(list)、start_index/end_index(int)、session_start(float)。返り値: tuple[list,dict]。
    """
    n=end_index-start_index;part=bars[max(0,start_index):max(0,end_index)]
    absent=n-len(part);before=max(0,min(end_index,0)-start_index) if start_index<0 else 0
    missing=sum(x['missing'] for x in part);not_closed=sum(not x['closed'] for x in part)
    pk=sum(x['price_known'] for x in part);vk=sum(x['volume_known'] for x in part)
    common=not(absent or missing or not_closed);price=bool(common and pk==len(part));volume=bool(common and vk==len(part))
    reasons=[]
    for condition,name in [(before,'before_session'),(absent>before,'absent_slot'),(missing,'missing'),(not_closed,'not_closed'),(pk!=len(part),'price_unknown'),(vk!=len(part),'volume_unknown')]:
        if condition:reasons.append(name)
    out={'from':session_start+start_index*60,'to':session_start+end_index*60,'expected_count':n,'slot_record_count':len(part),
         'absent_count':absent,'before_session_count':before,'missing_count':missing,'not_closed_count':not_closed,
         'price_known_count':pk,'volume_known_count':vk,'price_window_known':price,'volume_window_known':volume,
         'window_known':price and volume,'unknown_reasons':reasons,
         'first_ref':bars[start_index]['id'] if 0<=start_index<len(bars) else None,
         'last_ref':bars[end_index-1]['id'] if 0<=end_index-1<len(bars) else None}
    return part,out


# ----------------------------------------
def quantities(bars: list,i: int,start: float) -> dict:
    """
    機能: NumPyの独立配列算術でr含むOBV3窓とCMF現前値を得る。
    引数: bars(list[dict])、i(int)は当時r、start(float)。返り値: dict。
    """
    out={}
    for w in (5,15,30):
        feet,m=window(bars,i-w+1,i+1,start);prices,p=window(bars,i-w,i+1,start)
        known=p['price_window_known'] and m['volume_window_known'];reasons=list(m['unknown_reasons'])
        if not p['price_window_known']:reasons.append('w_plus_one_close_unknown')
        total=float(np.sum(np.array([x['volume'] for x in feet],dtype=np.float64))) if m['volume_window_known'] else None
        change=None
        if known:
            closes=np.array([x['ohlc']['close'] for x in prices],dtype=np.float64)
            volumes=np.array([x['volume'] for x in feet],dtype=np.float64)
            change=float(np.dot(np.sign(np.diff(closes)),volumes))
        defined=bool(known and total>0)
        m.update(price_window_known=p['price_window_known'],window_known=known,unknown_reasons=reasons,
                 expected_price_count=w+1,price_from=start+(i-w)*60,previous_close_ref=bars[i-w]['id'] if i-w>=0 else None,
                 price_slot_record_count=p['slot_record_count'],price_known_count=p['price_known_count'],
                 price_absent_count=p['absent_count'],price_before_session_count=p['before_session_count'],
                 price_missing_count=p['missing_count'],price_not_closed_count=p['not_closed_count'],change=change,
                 volume_sum_known=m['volume_window_known'],sum_volume=total,ratio_defined=defined,ratio=change/total if defined else None,
                 zero_total_volume=bool(m['volume_window_known'] and total==0))
        out[str(w)]=m
    cmfs=[]
    for end in (i+1,i):
        feet,m=window(bars,end-20,end,start)
        total=float(np.sum(np.array([x['volume'] for x in feet],dtype=np.float64))) if m['volume_window_known'] else None
        flow=None;flat=None
        if m['window_known']:
            values=np.array([[x['ohlc']['high'],x['ohlc']['low'],x['ohlc']['close'],x['volume']] for x in feet],dtype=np.float64)
            widths=values[:,0]-values[:,1];mfm=np.zeros(len(feet),dtype=np.float64)
            np.divide(2*values[:,2]-values[:,0]-values[:,1],widths,out=mfm,where=widths!=0)
            flow=float(np.dot(mfm,values[:,3]));flat=int(np.count_nonzero(widths==0))
        defined=bool(m['window_known'] and total>0)
        m.update(volume_sum_known=m['volume_window_known'],sum_volume=total,money_flow_volume_sum=flow,
                 value_defined=defined,value=flow/total if defined else None,
                 zero_total_volume=bool(m['volume_window_known'] and total==0),high_equals_low_count=flat)
        cmfs.append(m)
    current,previous=cmfs;known=current['value_defined'] and previous['value_defined']
    return {'obv':out,'cmf20':{'current':current,'previous':previous,
            'previous_asof':'同q0で知得済みの1分ずらした市場窓','delta_known':known,
            'delta':current['value']-previous['value'] if known else None}}


# ----------------------------------------
def add_counts(target: dict,row: dict) -> None:
    """
    機能: all/eligible・窓known/値definedを分けて再計数する。
    引数: target/row(dict)。返り値: None。
    """
    entries={f'OBV{w}':row['obv'][str(w)] for w in (5,15,30)}
    entries.update(CMF20=row['cmf20']['current'],前CMF20=row['cmf20']['previous'])
    entries['CMF20Δ']={'window_known':row['cmf20']['current']['window_known'] and row['cmf20']['previous']['window_known'],
                       'value_defined':row['cmf20']['delta_known'],'zero_total_volume':False}
    for key,item in entries.items():
        c=target.setdefault(key,Counter());defined=item['ratio_defined'] if key.startswith('OBV') else item['value_defined']
        for name,value in [('all_q0',1),('eligible_q0',int(row['eligible'])),('window_known_all_q0',int(item['window_known'])),
            ('window_known_eligible_q0',int(item['window_known'] and row['eligible'])),('value_defined_all_q0',int(defined)),
            ('value_defined_eligible_q0',int(defined and row['eligible'])),('zero_total_volume_all_q0',int(item['zero_total_volume']))]:c[name]+=value


# ----------------------------------------
def inspect(a: dict,b: dict,c: dict,total: Counter,counts: dict) -> None:
    """
    機能: 一場の全bar・全q0・配送prefixと数量全窓を独立照合する。
    引数: a/b/c(dict)は147/153/数量、total(Counter)、counts(dict)。返り値: None。
    """
    scope=(a['session'],a['contract'],a['start'],a['end']-300)
    equal([b[k] for k in ('session','contract','start','continuous_end')],list(scope),'153場')
    equal([c[k] for k in ('session','contract','start','continuous_end')],list(scope),'数量場')
    assert a['success'] is True
    bars=[x['bar'] for x in a['bars']];assert len(bars)==len(b['bars'])==len(c['volume_refs'])
    last=None
    for i,(bar,canonical,quantity) in enumerate(zip(bars,b['bars'],c['volume_refs'],strict=True)):
        assert (bar['session'],bar['contract'])==scope[:2] and type(bar['width_seconds']) is int and bar['width_seconds']==60
        assert bar['start']==scope[2]+i*60 and bar['end']==bar['start']+60 and bar['available_at']==bar['end']+60
        now=stamp(bar['stamp']);assert bar['available_at']<=now[0]
        assert last is None or all(x<=y for x,y in zip(last,now));last=now
        equal(stamp(a['bars'][i]['context']['at']),now,'147足時点')
        assert finite(bar['volume']) and bar['volume']>=0
        for key in ('price_known','volume_known','closed','missing'):assert type(bar[key]) is bool
        for key in ('id','start','end','available_at','price_known','volume_known','closed','missing'):equal(bar[key],canonical[key],'153足/'+key)
        equal(stamp(canonical['stamp']),now,'153Stamp')
        equal(canonical['ohlc'],bar['ohlc'] if bar['price_known'] else None,'153OHLC')
        if bar['price_known']:
            p=bar['ohlc'];assert all(finite(x) for x in p.values()) and 0<p['low']<=p['open']<=p['high'] and p['low']<=p['close']<=p['high']
        equal(quantity,{'id':bar['id'],'source147_bar_index':i,'volume_known':bar['volume_known'],'volume':bar['volume'] if bar['volume_known'] else None},'数量参照')
    assert len(b['rows'])==len(c['rows']);cursor=0;last=None;seen=set();local={}
    for row,actual in zip(b['rows'],c['rows'],strict=True):
        now=stamp(row['q0']);assert row['event_id'] not in seen;seen.add(row['event_id'])
        assert last is None or now[0]>=last[0] and now[1]>last[1] and now[2]>last[2];last=now
        begin=cursor
        while cursor<len(bars) and stamp(bars[cursor]['stamp'])[1]<=now[1]:
            assert stamp(bars[cursor]['stamp'])==now;cursor+=1
        assert cursor>begin and bars[cursor-1]['id']==row['r_ref']
        equal(row['delivered_refs'],[x['id'] for x in bars[begin:cursor]],'配送refs')
        equal(row['slot_refs'],[x['id'] for x in bars[max(0,cursor-4):cursor]],'4slotrefs')
        assert all(x<=y for x,y in zip(stamp(bars[cursor-1]['stamp']),now))
        expected={'event_id':row['event_id'],'eligible':row['eligible'],'r_ref':row['r_ref'],
                  **quantities(bars,cursor-1,scope[2]),'q0_stamp':{'time':now[0],'index':now[1],'source_line':now[2]}}
        equal(actual,expected,scope[0]+'/'+row['event_id']);add_counts(local,expected);add_counts(counts,expected)
        total['all_q0']+=1;total['eligible_q0']+=int(row['eligible']);total['same_raw_catchup_q0']+=int(cursor-begin>1)
    assert cursor==len(bars)
    equal(c['counts'],{key:dict(value) for key,value in local.items()},'場counts')
    total['bars_joined']+=len(bars);total['sessions']+=1


# ----------------------------------------
def main() -> None:
    """
    機能: 許可された自然3入力を一走査し小型監査票だけを保存する。
    引数: なし。返り値: None。巨大入力/期待全leafの副本を生成しない。
    """
    started=time.monotonic();before={key:fingerprint(ROOT/value[0]) for key,value in FILES.items()}
    assert all(before[k]['SHA256']==v[1] for k,v in FILES.items())
    evidence={key:{} for key in FILES};total=Counter();counts={};names=[]
    streams=[scenes(ROOT/FILES[key][0],evidence[key]) for key in ('147','153','数量')]
    for a,b,c in zip(*streams,strict=True):
        inspect(a,b,c,total,counts);names.append(a['session'])
        print(json.dumps({'照合場':len(names),'全q0':total['all_q0']},ensure_ascii=False),flush=True)
    assert len(names)==len(set(names))==73 and total['all_q0']==40544 and total['eligible_q0']==35339 and total['bars_joined']==43124
    for key in FILES:assert evidence[key]['decoded_SHA256']==FILES[key][2] and evidence[key]['全gzip_CRC']
    equal(evidence['153']['header']['sessions'],names,'153全場順')
    equal(evidence['数量']['header']['sessions'],names,'数量全場順')
    tail=evidence['数量']['tail'];assert tail['success'] is True
    equal(tail['counts'],{k:total[k] for k in ('all_q0','eligible_q0','bars_joined')},'全counts')
    equal(tail['window_counts'],{k:dict(v) for k,v in counts.items()},'全窓counts')
    assert evidence['数量']['header']['schema']=='directional_volume_v1'
    assert evidence['数量']['header']['selected_trade_count'] is None and evidence['数量']['header']['strategy_selected'] is False
    assert evidence['数量']['header']['financial_labels_used'] is False and evidence['数量']['header']['current100X_changed'] is False
    after={key:fingerprint(ROOT/value[0]) for key,value in FILES.items()};assert before==after
    result={'成功':True,'作成UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'入力':before,
            '全入力前後SHA_stat同体':True,'全数':dict(total),'比較':dict(CHECK),'NumPy':np.__version__,
            '最大絶対数値差':MAX_ERROR,'全窓件数':{k:dict(v) for k,v in counts.items()},
            '全gzip':{key:{k:v for k,v in value.items() if k not in ('header','tail')} for key,value in evidence.items()},
            '作者測定_生成器import':False,'新売買_採否_金融_Raw_CSV_追加2場読取':False,
            '巨大副本_全leaf転記':False,'経過秒':time.monotonic()-started,
            'コードSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (HERE/'独立確認.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'比較':dict(CHECK),'全数':dict(total),'最大差':MAX_ERROR},ensure_ascii=False))


# ----------------------------------------
if __name__=='__main__':main()
