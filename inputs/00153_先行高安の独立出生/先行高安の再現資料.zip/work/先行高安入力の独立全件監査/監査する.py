"""許可された2入力と生成先行高安を、作者関数なしで独立照合する。"""
from pathlib import Path
from collections import Counter, defaultdict
import gzip
import hashlib
import json
import math
import re
import time

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
FILES = {
    'parent': ('inputs/00147_中位価格位置と実体回復/Sourceの出生と取得.json.gz',
        'b99c49f06fe7e2306e59733b1cff26e3bb351f64edee220c98bc30b62c016d77',
        'd42d25ec0fe41e8358c1227fd71b4377ffa90c96a8cf582f1ee4537ebf455d63'),
    'ledger': ('inputs/00148_全1分入口母集団/出生台帳.json.gz',
        '9d589488bca8e83be3fd23ed230b6f7cae176acbbe96dd2d04a62d3bbfb6e753',
        '4f4d3ce3a652170d5d5f15941b591493592d5816bb0985c2e70c86b14323b219'),
    'new': ('work/先行高安の自然入力/先行高安の入力.json.gz',
        '2c020fed5b336ed0b417d8e72a07c6336ea475b09b9a2ff37f26ec4ce4d56bf8',
        '8e145275dda385e4c2f87500978716654d10efb0903a4011f2bcc304a7906b14')}
REF_KEYS = ('id', 'start', 'end', 'available_at', 'stamp', 'price_known', 'volume_known', 'closed')
COMPARE = Counter()


def fingerprint(path: Path) -> dict:
    """
    機能: 読取許可されたファイルの物理指紋とstatを得る。
    引数: path(Path)。返り値: dict。
    """
    before = path.stat()
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    after = path.stat()
    assert (before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns)
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': before.st_size,
            'mtime_ns': before.st_mtime_ns, 'sha256': digest.hexdigest()}


def equal(actual, expected, where: str) -> None:
    """
    機能: 全keyとNULL/型を保持して保存値と独立計算値を再帰比較する。
    引数: actual/expected(object)、where(str)。返り値: None。
    """
    if isinstance(expected, dict):
        assert isinstance(actual, dict) and set(actual) == set(expected), (where, 'key')
        for key in expected:
            equal(actual[key], expected[key], where + '/' + str(key))
    elif isinstance(expected, list):
        assert isinstance(actual, list) and len(actual) == len(expected), (where, 'length')
        for i, value in enumerate(expected):
            equal(actual[i], value, where + '/' + str(i))
    else:
        assert actual == expected and (type(actual) is bool) == (type(expected) is bool), (where, actual, expected)
        COMPARE['leaf'] += 1


def stamp(record: dict) -> tuple:
    """
    機能: 足又はQuoteの配送順3値を共通形式で得る。
    引数: record(dict)。返り値: tuple[float,int,int]。
    """
    result = (record['time'], record['index'], record.get('line', record.get('source_line')))
    assert type(result[0]) in (int, float) and math.isfinite(result[0])
    assert type(result[1]) is int and result[1] >= 0
    assert type(result[2]) is int and result[2] > 0
    return result


def scene_values(path: Path, evidence: dict):
    """
    機能: 大きい147だけを場単位でstreamし、全解凍SHA/CRCを完読する。
    引数: path(Path)、evidence(dict)。返り値: Iterator[dict]。
    """
    decoder = json.JSONDecoder()
    digest = hashlib.sha256()
    size = 0
    buffer = ''
    with gzip.open(path, 'rt', encoding='utf-8', newline='') as stream:
        def read_more() -> str:
            """
            機能: UTF8文字境界を保って解凍全bytesを数える。
            引数: なし。返り値: str。
            """
            nonlocal size
            block = stream.read(524288)
            raw = block.encode('utf-8')
            digest.update(raw)
            size += len(raw)
            return block

        while True:
            block = read_more()
            assert block, '147 scenes開始がない'
            buffer += block
            found = re.search(r'(?m)^  "scenes": \[', buffer)
            if found:
                buffer = buffer[found.end():]
                break
        while True:
            buffer = buffer.lstrip()
            if buffer.startswith(']'):
                break
            if buffer.startswith(','):
                buffer = buffer[1:].lstrip()
            try:
                item, end = decoder.raw_decode(buffer)
            except json.JSONDecodeError:
                block = read_more()
                assert block, '147 scenes未完'
                buffer += block
                continue
            yield item
            buffer = buffer[end:]
        while read_more():
            pass
    evidence.update(decoded_sha256=digest.hexdigest(), decoded_bytes=size, full_crc=True)


def load(key: str, evidence: dict) -> dict:
    """
    機能: 小さい台帳/新入力を全gzip CRCと解凍SHA付きで読む。
    引数: key(str)、evidence(dict)。返り値: dict。
    """
    path, _, expected = FILES[key]
    raw = gzip.decompress((ROOT / path).read_bytes())
    actual = hashlib.sha256(raw).hexdigest()
    assert actual == expected
    evidence[key] = {'decoded_sha256': actual, 'decoded_bytes': len(raw), 'full_crc': True}
    return json.loads(raw)


def reference(bar: dict) -> dict:
    """
    機能: 台帳の足refと同じ8項目を元足から抽出する。
    引数: bar(dict)。返り値: dict。
    """
    return {key: bar[key] for key in REF_KEYS}


def quote_expected(q0: dict) -> dict:
    """
    機能: 各価格の有限正値と正常BBOを台帳の元値だけで再構成する。
    引数: q0(dict)。返り値: dict。
    """
    out = {key: q0[key] for key in ('time', 'index', 'source_line')}
    if 'clock' in q0:
        out['clock'] = q0['clock']
    for key in ('last', 'bid', 'ask'):
        value = q0[key]
        known = type(value) in (int, float) and math.isfinite(value) and value > 0
        out[key] = value if known else None
        out[key + '_known'] = known
    assert type(q0['quote_ok']) is bool
    out['quote_ok'] = q0['quote_ok']
    out['normal_bbo'] = bool(q0['quote_ok'] and out['bid_known'] and out['ask_known'] and out['bid'] < out['ask'])
    return out


def window_expected(prefix: list[dict], scene_start: float, minutes: int) -> dict:
    """
    機能: 時刻辞書で最新rを除く全格子を列挙し、独立に高安と最初の極値を求める。
    引数: prefix(list[dict])、scene_start(float)、minutes(int)。返り値: dict。
    """
    boundary = prefix[-1]['start']
    start = boundary - minutes * 60
    # ----------------------------------------
    # rを先に除き、実時間キーが一致する足だけを選ぶ。欠分を圧縮しない。
    history = {bar['start']: bar for bar in prefix[:-1]}
    times = [start + j * 60 for j in range(minutes)]
    selected = [history[t] for t in times if t in history]
    count = len(selected)
    absent = minutes - count
    pre = sum(t < scene_start for t in times)
    missing = sum(bar['missing'] for bar in selected)
    closed = sum(bar['closed'] for bar in selected)
    prices = sum(bar['price_known'] for bar in selected)
    flags = {'before_session': pre > 0, 'absent_slot': absent > pre,
             'missing': missing > 0, 'not_closed': closed < count, 'price_unknown': prices < count}
    reasons = [key for key, flag in flags.items() if flag]
    valid = count == minutes and not reasons
    result = {'from': start, 'to': boundary, 'duration_seconds': minutes * 60,
        'expected_count': minutes, 'slot_record_count': count, 'observed_count': count - missing,
        'closed_count': closed, 'price_known_count': prices, 'missing_count': missing,
        'absent_count': absent, 'before_session_count': pre,
        'known': valid, 'unknown_reasons': reasons, 'high': None, 'low': None,
        'high_first_ref': None, 'low_first_ref': None, 'range_points': None, 'range_zero': None}
    if valid:
        upper = max(selected, key=lambda b: b['ohlc']['high'])
        lower = min(selected, key=lambda b: b['ohlc']['low'])
        high, low = upper['ohlc']['high'], lower['ohlc']['low']
        result.update(high=high, low=low, range_points=high - low, range_zero=high == low,
                      high_first_ref={k: upper[k] for k in ('id', 'start', 'end')},
                      low_first_ref={k: lower[k] for k in ('id', 'start', 'end')})
    return result


def main() -> None:
    """
    機能: 全73場の2元入力から新先行高安の全件を別算術で照合する。
    引数: なし。返り値: None。作者Source・戦略・金融・Rawをimport/読取しない。
    """
    started = time.monotonic()
    ready = HERE / '人工の確認.json'
    assert json.loads(ready.read_bytes())['成功'] is True
    before = {key: fingerprint(ROOT / row[0]) for key, row in FILES.items()}
    assert all(before[key]['sha256'] == row[1] for key, row in FILES.items())
    decoded = {}
    ledger = load('ledger', decoded)
    result = load('new', decoded)
    assert decoded['new']['decoded_bytes'] == 116923668
    assert ledger['success'] and ledger['trial'] == 148
    assert ledger['financial_labels_used'] is False and ledger['strategy_selected'] is False
    sessions = ledger['sessions']
    assert len(sessions) == len(set(sessions)) == 73
    assert result['sessions'] == sessions and result['success'] is True
    assert result['schema'] == 'prior_time_range_v1' and result['windows_minutes'] == [15, 30, 60]
    assert result['comparison_domain'] == '[r.Start-W,r.Start)、最新rを含めない実時間窓'
    assert result['selected_trade_count'] is None and result['selected_trade_frequency'] is None
    assert result['strategy_selected'] is False and result['financial_labels_used'] is False
    for key, original in (('parent147', 'parent'), ('ledger148', 'ledger')):
        path, physical, plain = FILES[original]
        equal(result['source_refs'][key], {'path': path, 'sha256': physical, 'decoded_sha256': plain}, 'source/' + key)
    groups = defaultdict(list)
    ids = set()
    for event in ledger['rows']:
        assert event['event_id'] not in ids
        ids.add(event['event_id'])
        groups[event['session']].append(event)
    assert len(ids) == 40544 and sum(row['eligible'] for row in ledger['rows']) == 35339
    assert set(groups) == set(sessions)
    del ledger
    total, windows = Counter(), {str(w): Counter() for w in (15, 30, 60)}
    reason_counts = {str(w): Counter() for w in (15, 30, 60)}
    scene_proof = []
    parent_evidence = {}
    global_bar_ids = set()
    parents = scene_values(ROOT / FILES['parent'][0], parent_evidence)
    for scene_index, parent in enumerate(parents):
        sid = sessions[scene_index]
        assert parent['session'] == sid and parent['success']
        output = result['scenes'][scene_index]
        equal({k: output[k] for k in ('session', 'contract', 'start', 'continuous_end')},
              {'session': sid, 'contract': parent['contract'], 'start': parent['start'],
               'continuous_end': parent['end'] - 300}, 'scene/' + sid)
        raw_bars = [known['bar'] for known in parent['bars']]
        assert len({b['id'] for b in raw_bars}) == len(raw_bars) == len(output['bars'])
        for bar in raw_bars:
            assert bar['id'] not in global_bar_ids
            global_bar_ids.add(bar['id'])
        delivery = defaultdict(list)
        previous = None
        for j, (known, bar) in enumerate(zip(parent['bars'], raw_bars)):
            assert bar['session'] == sid and bar['contract'] == parent['contract']
            assert bar['width_seconds'] == 60 and bar['start'] == parent['start'] + j * 60
            assert bar['end'] == bar['start'] + 60 and bar['end'] <= parent['end'] - 300
            assert bar['available_at'] == bar['end'] + 60 <= stamp(bar['stamp'])[0]
            at = stamp(bar['stamp'])
            equal(stamp(known['context']['at']), at, 'context_stamp')
            if previous is not None:
                assert all(a <= b for a, b in zip(previous, at))
                if previous != at:
                    assert previous[1] < at[1] and previous[2] < at[2]
            previous = at
            for key in ('price_known', 'volume_known', 'closed', 'missing'):
                assert type(bar[key]) is bool
            if bar['price_known']:
                o, h, l, c = [bar['ohlc'][k] for k in ('open', 'high', 'low', 'close')]
                assert all(type(v) in (int, float) and math.isfinite(v) and v > 0 for v in (o, h, l, c))
                assert l <= min(o, c) <= max(o, c) <= h
            minimal = {**reference(bar), 'missing': bar['missing'],
                       'ohlc': dict(bar['ohlc']) if bar['price_known'] else None}
            equal(output['bars'][j], minimal, sid + '/minimal/' + str(j))
            delivery[at].append((j, known))
        events = groups.pop(sid)
        assert len(events) == len(output['rows']) == len(delivery)
        c, wc = Counter(), {str(w): Counter() for w in (15, 30, 60)}
        consumed = 0
        for event, row in zip(events, output['rows']):
            q = event['q0']
            now = stamp(q)
            items = delivery.pop(now)
            indices = [j for j, _ in items]
            assert indices == list(range(consumed, consumed + len(items)))
            consumed += len(items)
            for _, known in items:
                equal(known['context']['at'], q, sid + '/full_quote')
            prefix = raw_bars[:consumed]
            r = prefix[-1]
            assert all(a <= b for a, b in zip(stamp(r['stamp']), now))
            assert r['end'] <= r['available_at'] <= now[0]
            equal(event['latest_bar_ref'], reference(r), sid + '/r')
            equal(event['slot_refs'], [reference(b) for b in prefix[-4:]], sid + '/last4')
            equal(event['delivered_bar_refs'], [reference(k['bar']) for _, k in items], sid + '/batch')
            eligible = bool(r['price_known'] and r['closed'] and q['time'] < r['end'] + 120
                            and q['time'] < min(parent['force_close'], parent['end'] - 3900))
            assert event['eligible'] is eligible and event['feature_generated'] is eligible
            assert event['feature_ref'] == (event['event_id'] if eligible else None)
            computed = {}
            for width in (15, 30, 60):
                key = str(width)
                value = window_expected(prefix, parent['start'], width)
                computed[key] = value
                wc[key].update({'all_q0': 1, 'eligible_q0': int(eligible),
                    'known_all_q0': int(value['known']), 'known_eligible_q0': int(value['known'] and eligible),
                    'range_zero_all_q0': int(value['range_zero'] is True)})
                reason_counts[key].update(value['unknown_reasons'])
            expected_row = {'event_id': event['event_id'], 'eligible': eligible,
                'quote_ref': {'source': 'ledger148', 'event_id': event['event_id']},
                'q0': quote_expected(q), 'r_ref': r['id'], 'slot_refs': [b['id'] for b in prefix[-4:]],
                'delivered_refs': [k['bar']['id'] for _, k in items], 'prior_ranges': computed}
            equal(row, expected_row, sid + '/' + event['event_id'])
            c.update({'all_q0': 1, 'eligible_q0': int(eligible),
                      'delivered_bar_refs_checked': len(items), 'same_raw_catchup_q0': int(len(items) > 1)})
        assert consumed == len(raw_bars) and not delivery
        equal(output['counts'], dict(c), sid + '/counts')
        equal(output['window_counts'], {k: dict(v) for k, v in wc.items()}, sid + '/window_counts')
        total.update(c)
        total['bars'] += len(raw_bars)
        for key in windows:
            windows[key].update(wc[key])
        scene_proof.append({'session': sid, 'bars': len(raw_bars), 'q0': len(events),
                            'eligible': c['eligible_q0'], 'window_counts': {k: dict(v) for k, v in wc.items()}})
        if (scene_index + 1) % 20 == 0:
            print(json.dumps({'独立監査済み場': scene_index + 1}, ensure_ascii=False), flush=True)
    assert len(scene_proof) == 73 == len(result['scenes']) and not groups
    assert total['all_q0'] == 40544 and total['eligible_q0'] == 35339 and total['bars'] == 43124
    assert parent_evidence['decoded_sha256'] == FILES['parent'][2]
    equal(result['counts'], dict(total), 'all_counts')
    equal(result['window_counts'], {key: dict(value) for key, value in windows.items()}, 'all_windows')
    for key in ('full_batch_latest_last4_clock_verified', 'complete_range_only', 'range_unknown_is_null'):
        assert result[key] is True
    assert result['observed_high_low_fallback'] is False
    assert before == {key: fingerprint(ROOT / row[0]) for key, row in FILES.items()}
    proof = {'成功': True, '編集停止': True, '監査対象は非金融入力のみ': True,
        '作者Source_import': False, 'Root人工票の期待数値使用': False,
        '独立算術': '時刻辞書で[r.Start−W,r.Start)の全格子を列挙。r含む旧可用性と別。',
        '全場': 73, '全q0': total['all_q0'], 'eligible_q0': total['eligible_q0'],
        '全配送bar': total['bars'], '末端比較': COMPARE['leaf'], '件数': dict(total),
        '窓件数': {key: dict(value) for key, value in windows.items()},
        '未知理由は非排他': {key: dict(value) for key, value in reason_counts.items()},
        '全高安_極値最初IDと区間_ゼロ幅_NULL': True,
        '全quote_最新r_4refs_全配送_非未来時計': True,
        '価格未知のrを古いknownへfallback': False, '全最小bar正本同体': True,
        '入力指紋前後同体': before, '147全stream指紋': parent_evidence,
        '解凍指紋と全gzipCRC': decoded, 'SourceSHA256': fingerprint(Path(__file__))['sha256'],
        '人工票SHA256': fingerprint(ready)['sha256'],
        '新Strategy_採否_金融_Raw_新CSV_追加2場_新X': False,
        'elapsed_seconds': time.monotonic() - started}
    for name, value in [('全73場の照合件数.json', scene_proof), ('監査の確認.json', proof)]:
        target = HERE / name
        assert not target.exists()
        target.write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    print(json.dumps({'成功': True, '全q0': total['all_q0'], 'eligible': total['eligible_q0'],
        '末端比較': COMPARE['leaf'], '停止票SHA256': fingerprint(HERE / '監査の確認.json')['sha256']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
