"""独立高安算術のr除外・窓境界・未知・最初の極値を小人工で固定する。"""
from pathlib import Path
import hashlib
import importlib.util
import json
import unittest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('own_range_audit', HERE / '監査する.py')
own = importlib.util.module_from_spec(spec)
spec.loader.exec_module(own)


def bars(count: int) -> list[dict]:
    """
    機能: 市場格子と識別可能な価格を持つ人工prefixを生成する。
    引数: count(int)。返り値: list[dict]。
    """
    return [{'id': f'bar{i}', 'start': i * 60, 'end': (i + 1) * 60,
             'price_known': True, 'closed': True, 'missing': False,
             'ohlc': {'high': i + 101, 'low': i + 100}} for i in range(count)]


class Tests(unittest.TestCase):
    """自然入力を使わず独立算術の境界を確認する。"""

    def test_exact_window_and_unknown_r(self) -> None:
        """
        機能: 最古足を含み最新rの巨大値を除き、r未知でも窓既知を保つ。
        引数: self(Tests)。返り値: None。
        """
        source = bars(16)
        source[-1].update(price_known=False, closed=False, missing=True)
        source[-1]['ohlc'] = {'high': 99999, 'low': 1}
        result = own.window_expected(source, 0, 15)
        self.assertTrue(result['known'])
        self.assertEqual((result['from'], result['to']), (0, 900))
        self.assertEqual((result['high'], result['low']), (115, 100))
        self.assertEqual(result['high_first_ref']['id'], 'bar14')
        self.assertEqual(result['low_first_ref']['id'], 'bar0')

    def test_missing_and_no_compression(self) -> None:
        """
        機能: 格子欠落とMissing/品質未知を区別し、古い既知への圧縮をしない。
        引数: self(Tests)。返り値: None。
        """
        source = bars(17)
        removed = source.pop(5)
        result = own.window_expected(source, 0, 15)
        self.assertFalse(result['known'])
        self.assertEqual(result['absent_count'], 1)
        self.assertEqual(result['unknown_reasons'], ['absent_slot'])
        self.assertIsNone(result['high'])
        source.insert(5, removed)
        source[5].update(missing=True, price_known=False, closed=False)
        result = own.window_expected(source, 0, 15)
        self.assertEqual(result['unknown_reasons'], ['missing', 'not_closed', 'price_unknown'])
        self.assertIsNone(result['range_zero'])

    def test_before_session_and_first_tie(self) -> None:
        """
        機能: 当場前不足を前場で埋めず、同値極値の最初とゼロ幅を保つ。
        引数: self(Tests)。返り値: None。
        """
        result = own.window_expected(bars(11), 0, 15)
        self.assertEqual(result['before_session_count'], 5)
        self.assertEqual(result['unknown_reasons'], ['before_session'])
        source = bars(16)
        for b in source:
            b['ohlc'] = {'high': 101, 'low': 101}
        result = own.window_expected(source, 0, 15)
        self.assertTrue(result['known'] and result['range_zero'])
        self.assertEqual(result['high_first_ref']['id'], 'bar0')
        self.assertEqual(result['low_first_ref']['id'], 'bar0')

    def test_quote_finite_known(self) -> None:
        """
        機能: 異常BBOを窓未知と混ぜず各価格のknown/nullを保持する。
        引数: self(Tests)。返り値: None。
        """
        quote = {'time': 1000, 'index': 20, 'source_line': 21, 'last': 100,
                 'bid': float('nan'), 'ask': 102, 'quote_ok': True}
        result = own.quote_expected(quote)
        self.assertTrue(result['last_known'] and result['ask_known'])
        self.assertFalse(result['bid_known'] or result['normal_bbo'])
        self.assertIsNone(result['bid'])


if __name__ == '__main__':
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(Tests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    assert result.wasSuccessful()
    proof = {'成功': True, '人工群': result.testsRun, '自然入力読取': False,
             '作者Source_import': False, '独立算術SHA256': hashlib.sha256((HERE / '監査する.py').read_bytes()).hexdigest(),
             '人工SourceSHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (HERE / '人工の確認.json').write_bytes((json.dumps(proof, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
