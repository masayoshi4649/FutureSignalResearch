"""先行高安部品の除外境界と未知を、作者と別の人工値で検査する。"""
from pathlib import Path
from copy import deepcopy
import hashlib
import importlib.util
import json
import unittest

ROOT = Path(__file__).resolve().parent.parent
SOURCE = ROOT / 'work/先行15_30_60分高安の入力生成/先行高安.py'
SPEC = importlib.util.spec_from_file_location('先行高安の被検査源', SOURCE)
M = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)


def bars(count: int) -> list:
    """
    機能: 1分格子と配送が確定した人工履歴を作る。
    引数: count(int)。返り値: list[dict]。
    """
    return [{'id': str(i), 'session': '人工', 'contract': '人工限月',
        'width_seconds': 60, 'start': i * 60, 'end': (i + 1) * 60,
        'available_at': (i + 2) * 60,
        'stamp': {'time': (i + 2) * 60, 'index': i, 'line': i + 1},
        'price_known': True, 'volume_known': False, 'closed': True, 'missing': False,
        'ohlc': {'open': 101 + i, 'high': 102 + i, 'low': 100 + i, 'close': 101 + i}}
        for i in range(count)]


def q0(history: list) -> dict:
    """
    機能: 最新足の配送時刻を観測q0にする。
    引数: history(list[dict])。返り値: dict。
    """
    last = history[-1]['stamp']
    return {'time': last['time'], 'index': last['index'], 'source_line': last['line']}


class 独立窓検査(unittest.TestCase):
    """価格域を明示列から直接計算して部品と比較する。"""

    def test_r除外と正確な各窓(self) -> None:
        """
        機能: rだけの異常極値を除き、各窓の最初/最後/本数を別算術で確認する。
        引数: self(独立窓検査)。返り値: None。
        """
        history = bars(61)
        history[-1]['ohlc'] = {'open': 150, 'high': 999999, 'low': 1, 'close': 160}
        before = deepcopy(history)
        for width in (15, 30, 60):
            result = M.prior_range(history, q0(history), 0, width)
            expected = history[60 - width:60]
            self.assertTrue(result['known'])
            self.assertEqual(result['slot_record_count'], width)
            self.assertEqual(result['from'], (60 - width) * 60)
            self.assertEqual(result['to'], 3600)
            self.assertEqual(result['high'], max(b['ohlc']['high'] for b in expected))
            self.assertEqual(result['low'], min(b['ohlc']['low'] for b in expected))
            self.assertEqual(result['low_first_ref']['id'], str(60 - width))
            result['low_first_ref']['id'] = '返却値だけの変更'
        self.assertEqual(history, before)

    def test_未知と助走とゼロ幅(self) -> None:
        """
        機能: 欠分を詰めず、場先頭不足と後続窓回復・ゼロ幅を区別する。
        引数: self(独立窓検査)。返り値: None。
        """
        early = M.prior_range(bars(6), q0(bars(6)), 0, 15)
        self.assertFalse(early['known'])
        self.assertEqual((early['absent_count'], early['before_session_count']), (10, 10))
        history = bars(72)
        history[55].update(missing=True, price_known=False)
        unknown = M.prior_range(history[:61], q0(history[:61]), 0, 15)
        self.assertFalse(unknown['known'])
        self.assertIsNone(unknown['high'])
        self.assertEqual(unknown['missing_count'], 1)
        self.assertTrue(M.prior_range(history, q0(history), 0, 15)['known'])
        flat = bars(61)
        for bar in flat:
            bar['ohlc'] = {'open': 100, 'high': 100, 'low': 100, 'close': 100}
        zero = M.prior_range(flat, q0(flat), 0, 15)
        self.assertTrue(zero['known'] and zero['range_zero'])
        self.assertEqual((zero['range_points'], zero['high_first_ref']['id']), (0, '45'))

    def test_時刻と原行を別々に検査(self) -> None:
        """
        機能: 時刻だけ過去でも後のindex/lineを使わないことを確認する。
        引数: self(独立窓検査)。返り値: None。
        """
        for field, value in (('time', 999999), ('index', 999999), ('line', 999999)):
            history = bars(61)
            now = q0(history)
            history[55]['stamp'][field] = value
            with self.assertRaises(AssertionError):
                M.prior_range(history, now, 0, 15)


if __name__ == '__main__':
    before = hashlib.sha256(SOURCE.read_bytes()).hexdigest()
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(独立窓検査))
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == before
    if result.wasSuccessful():
        with (ROOT / 'work/先行高安のRoot独立確認.json').open('x', encoding='utf-8', newline='\n') as sink:
            json.dump({'成功': True, '自然入力': False, '人工群': result.testsRun,
                'Source前後SHA256': before, '実行SourceSHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},
                sink, ensure_ascii=False, indent=2)
            sink.write('\n')
    raise SystemExit(0 if result.wasSuccessful() else 1)
