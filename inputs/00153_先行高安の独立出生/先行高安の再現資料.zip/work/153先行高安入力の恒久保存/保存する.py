"""停止済みの先行高安入力と小型再現資料だけを一度恒久保存する。"""
from pathlib import Path
import datetime
import gzip
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
TARGET = ROOT / 'inputs/00153_先行高安の独立出生'
SOURCE = ROOT / 'work/先行高安の自然入力/先行高安の入力.json.gz'
PHYSICAL = '2c020fed5b336ed0b417d8e72a07c6336ea475b09b9a2ff37f26ec4ce4d56bf8'
DECODED = '8e145275dda385e4c2f87500978716654d10efb0903a4011f2bcc304a7906b14'


def sha(path: Path) -> str:
    """
    機能: 明示されたファイルの物理指紋をstreamで求める。
    引数: path(Path)。返り値: str。
    """
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1 << 20), b''): digest.update(block)
    return digest.hexdigest()


# ----------------------------------------
def decoded(path: Path) -> dict:
    """
    機能: JSON本文を解析・保存せずgzipを完読してCRCと解凍SHAを検査する。
    引数: path(Path)。返り値: dictは解凍指紋とサイズ。
    """
    digest = hashlib.sha256(); size = 0
    with gzip.open(path, 'rb') as source:
        for block in iter(lambda: source.read(1 << 20), b''):
            digest.update(block); size += len(block)
    return {'sha256': digest.hexdigest(), 'bytes': size, 'full_gzip_crc_checked': True}


# ----------------------------------------
def source_files() -> list[Path]:
    """
    機能: 停止票で列挙された小型源とRoot・自然確認だけを保存対象にする。
    引数: なし。返り値: list[Path]。原典2gzipや生成入力をZIPへ追加しない。
    """
    author = ROOT / 'work/先行15_30_60分高安の入力生成'
    independent = ROOT / 'work/先行高安入力の独立全件監査'
    stop = json.loads((author / '停止の確認.json').read_bytes())
    assert sha(author / '停止の確認.json') == '3a5ce52b6419117a35349f84a998c543977361f3256f7d380ccea64832f29c5f'
    files = []
    for name, digest in stop['保存対象'].items():
        path = author / name; assert sha(path) == digest; files.append(path)
    files.append(author / '停止の確認.json')
    stop = json.loads((independent / '停止の確認.json').read_bytes())
    assert sha(independent / '停止の確認.json') == '9ee9c3fa5bff7648838e475799ddeeacefb027ac543f34a6ef9015492dbc7f6c'
    for name, value in stop['保存対象'].items():
        path = independent / name; assert sha(path) == value['SHA256']; files.append(path)
    files.append(independent / '停止の確認.json')
    files += [ROOT / 'work/先行高安のRoot独立検査.py', ROOT / 'work/先行高安のRoot独立確認.json',
              ROOT / 'work/先行高安の自然入力/生成の確認.json', Path(__file__).resolve()]
    assert len(files) == len(set(files)) == 19
    assert all(path.suffix != '.gz' and path.stat().st_size < 1 << 20 for path in files)
    return files


# ----------------------------------------
def main() -> None:
    """
    機能: 入力1gzip・再現小ZIP・索引・README・保存確認を排他的に新規保存する。
    引数: なし。返り値: None。戦略153の採否・金融は参照又は生成しない。
    """
    TARGET.mkdir(parents=True, exist_ok=True)
    files = source_files()
    before = {path.relative_to(ROOT).as_posix(): {'sha256': sha(path), 'bytes': path.stat().st_size,
               'mtime_ns': path.stat().st_mtime_ns} for path in [SOURCE, *files]}
    assert sha(SOURCE) == PHYSICAL and SOURCE.stat().st_size == 5238666
    source_decoded = decoded(SOURCE)
    assert source_decoded['sha256'] == DECODED and source_decoded['bytes'] == 116923668
    dataset = TARGET / '先行高安の入力.json.gz'
    with SOURCE.open('rb') as source, dataset.open('xb') as output:
        for block in iter(lambda: source.read(1 << 20), b''): output.write(block)
    assert sha(dataset) == PHYSICAL and dataset.stat().st_size == 5238666
    assert decoded(dataset) == source_decoded
    archive_path = TARGET / '先行高安の再現資料.zip'
    entries = []
    with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files:
            name = path.relative_to(ROOT).as_posix(); body = path.read_bytes()
            archive.writestr(name, body)
            entries.append({'path': name, 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()})
    with zipfile.ZipFile(archive_path) as archive:
        assert archive.testzip() is None and archive.namelist() == [entry['path'] for entry in entries]
        for entry in entries:
            body = archive.read(entry['path'])
            assert len(body) == entry['bytes'] and hashlib.sha256(body).hexdigest() == entry['sha256']
    generated = json.loads((ROOT / 'work/先行高安の自然入力/生成の確認.json').read_bytes())
    independent = json.loads((ROOT / 'work/先行高安入力の独立全件監査/監査の確認.json').read_bytes())
    assert generated['成功'] and generated['出力']['sha256'] == PHYSICAL and independent['成功']
    assert generated['全q0'] == 40544 and generated['eligible_q0'] == 35339 and generated['全場'] == 73
    index = {'成功': True, '確認日': '2026-11-12',
             '入力': {'path': dataset.relative_to(ROOT).as_posix(), 'bytes': dataset.stat().st_size,
                      'sha256': PHYSICAL, 'decoded_sha256': DECODED, 'decoded_bytes': 116923668,
                      'full_gzip_crc_checked': True},
             '再現ZIP': {'path': archive_path.relative_to(ROOT).as_posix(), 'bytes': archive_path.stat().st_size,
                         'sha256': sha(archive_path), '全格納bytes/CRC再読一致': True, '格納数': len(entries)},
             '格納': entries,
             '共有入力': {key: {**value, 'decoded_sha256': (
                 'd42d25ec0fe41e8358c1227fd71b4377ffa90c96a8cf582f1ee4537ebf455d63' if key == 'parent147' else
                 '4f4d3ce3a652170d5d5f15941b591493592d5816bb0985c2e70c86b14323b219')}
                 for key, value in generated['入力'].items()},
             '原典2gzip/生成入力/100X/Rawを再現ZIPへ複写': False}
    index_path = TARGET / '先行高安の再現資料_索引.json'
    with index_path.open('x', encoding='utf-8', newline='\n') as output:
        json.dump(index, output, ensure_ascii=False, indent=2); output.write('\n')
    readme = '''# 153の先行高安入力

先行15・30・60分高安の非金融入力を一度だけ恒久保存した。153の戦略Sourceや採否・金融はここでは実行していない。全73場・全40,544q0、適格35,339q0、全43,124配送barを残す。取得・売買選択・参加頻度を表す件数ではない。

正本は[先行高安の入力.json.gz](先行高安の入力.json.gz)。5,238,666 bytes、物理SHA256は`2c020fed5b336ed0b417d8e72a07c6336ea475b09b9a2ff37f26ec4ce4d56bf8`。解凍116,923,668 bytes、解凍SHA256は`8e145275dda385e4c2f87500978716654d10efb0903a4011f2bcc304a7906b14`。元work生成物と保存先の両gzipを全完読し、CRC・解凍SHA・サイズと物理bytesを照合した。plain副本は保存しない。

## 比較域と未知

各q0の最新配送slotをrとし、窓は厳密な`[r.Start−W,r.Start)`、W=15/30/60分である。r自身と前場を含めず、欠測を飛ばして古い足で本数を補わない。旧可用性調査のrを含む`[r.End−W,r.End)`とは別測定である。

全Wslotが配送済み・非Missing・closed・価格既知の場合だけ`known=true`としてHigh/Low、同値極値の市場順で最初のbar ID/Start/End、幅・ゼロ幅を返す。不足・欠測・未closed・価格未知では値/極値参照/幅/ゼロ幅をnullとし、理由と各countを残す。観測高安へのfallbackはない。量未知・BBO異常を価格高安の既知性へ混ぜない。r自体の未知と先行窓の未知は別に保持する。

| r除外窓 | 全q0の既知 / 未知 | 適格q0の既知 / 未知 |
| --- | ---: | ---: |
| 15分 | 28,734 / 11,810 | 26,005 / 9,334 |
| 30分 | 24,528 / 16,016 | 22,127 / 13,212 |
| 60分 | 19,547 / 20,997 | 17,323 / 18,016 |

## schemaと利用

schema IDは`prior_time_range_v1`。top.scenesごとにsession/contract/start/continuous_end、bars、rowsを持つ。barの最小正本を一度保存し、各rowはr_ref・4slot ID・当Raw配送IDを参照する。全window bar ID配列や大量のCSV refsを反復しない。

- `scenes[].bars[]`：id/start/end/available_at/stamp、price_known/volume_known/closed/missing、価格既知時のohlc（open/high/low/close）、未知時はohlc=null。
- `scenes[].rows[]`：event_id/eligible/quote_ref、q0、r_ref、slot_refs、delivered_refs、prior_ranges。r_refを同場bars[].idへ結合する。
- `q0`：time/index/source_line、任意clock、last/bid/ask、各known、quote_ok、normal_bbo。正常Bid<Askと個別価格既知を区別する。
- `prior_ranges`：キー`15`/`30`/`60`。from/to/duration_seconds、expected_count/slot_record_count/observed_count/closed_count/price_known_count/missing_count/absent_count/before_session_count、known/unknown_reasons、high/low/high_first_ref/low_first_ref/range_points/range_zeroを持つ。

最新/全配送/4slot refs、全Quote、End/AvailableAt/Stampとq0の時刻・index・物理行を全件照合した。同Raw catch-upは全配送後のそのq0で利用し、以前から既知だったとはしない。市場時計・モデル公表・価格時計から実受信を復元したものでも、取引所の全約定網羅や真の市場高安を保証するものでもない。

## 由来と再現

原典は[147の共有Source](../00147_中位価格位置と実体回復/README.md)（gzip SHA `b99c49f06fe7e2306e59733b1cff26e3bb351f64edee220c98bc30b62c016d77`、解凍`d42d25ec0fe41e8358c1227fd71b4377ffa90c96a8cf582f1ee4537ebf455d63`）と[148出生台帳](../00148_全1分入口母集団/README.md)（gzip SHA `9d589488bca8e83be3fd23ed230b6f7cae176acbbe96dd2d04a62d3bbfb6e753`、解凍`4f4d3ce3a652170d5d5f15941b591493592d5816bb0985c2e70c86b14323b219`）だけである。今回この原典2gzip・100X・Raw・旧151/152は複写又は変更していない。

[再現資料ZIP](先行高安の再現資料.zip)には、生成純部品・生成器・条件・作者人工7群/構文/CLI準備、Root独立人工3群、自然生成の確認、独立全件監査の最小7点、保存器の計19小点を元repo相対pathで一度格納した。[格納索引](先行高安の再現資料_索引.json)に全member指紋と共有入力参照を残す。元2入力と新入力自体はZIPへ入れない。全格納bytesとCRCを再読した。

再現時はZIPの小源を元相対pathへ復元する。共有2原典を元pathで参照し、ZIP内`条件.md`のCLIで**新しいwork出力先**へ生成する。保存済みの本入力を上書きしない。独立監査はそのREADMEに従い新しい監査folderで行う（コード内に記録された当初のwork生成pathは、保存正本の同体bytesへの検証用参照を用意する）。今回は再生成・再監査を追加実行せず、停止した結果の同体保存を行った。

独立全件監査は作者算術をimportせず全6,990,803末端を一致確認した。主票SHAは`a539ee938669f7bcae875196a150eaa86d51b5cafafc7de0722dcd0925b57997`、停止票SHAは`9ee9c3fa5bff7648838e475799ddeeacefb027ac543f34a6ef9015492dbc7f6c`。100特徴、支持抵抗の効力、先着70%、金融成績の独立検算ではない。

[保存確認](入力の保存確認.json)。確認日：2026-11-12。
'''
    readme_path = TARGET / 'README.md'
    with readme_path.open('x', encoding='utf-8', newline='\n') as output: output.write(readme)
    after = {path.relative_to(ROOT).as_posix(): {'sha256': sha(path), 'bytes': path.stat().st_size,
             'mtime_ns': path.stat().st_mtime_ns} for path in [SOURCE, *files]}
    assert before == after
    proof = {'成功': True, '編集停止': True, 'UTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
             '区分': '153採用後の非金融入力恒久化だけ。戦略Source/採否/金融は未読未実行。',
             '元入力と保存入力の物理bytes一致': True, '元/保存gzip全CRC/解凍SHA/サイズ一致': True,
             '入力': index['入力'], '再現ZIP': index['再現ZIP'],
             'README_SHA256': sha(readme_path), '索引SHA256': sha(index_path),
             '自然生成/自然独立監査の追加実行': False,
             '全q0': 40544, 'eligible': 35339, '全場': 73, '全bar': 43124,
             '独立監査末端': 6990803, '全保存元前後SHA_stat同体': True,
             '原典2大gzip/100X/Raw/旧151152の複写又は変更': False,
             '入力の由来/全格納指紋': index_path.relative_to(ROOT).as_posix()}
    proof_path = TARGET / '入力の保存確認.json'
    with proof_path.open('x', encoding='utf-8', newline='\n') as output:
        json.dump(proof, output, ensure_ascii=False, indent=2); output.write('\n')
    print(json.dumps({'成功': True, '保存確認SHA256': sha(proof_path), '索引SHA256': sha(index_path),
                      '入力': index['入力'], '再現ZIP': index['再現ZIP']}, ensure_ascii=False, indent=2))


if __name__ == '__main__': main()
