"""自然生成前に人工・構文・CLI境界を固定し、Rootへ停止票を渡す。"""
from pathlib import Path
import datetime
import hashlib
import json
import py_compile
import subprocess
import sys

HERE = Path(__file__).resolve().parent
NAMES = ('先行高安.py', '生成する.py', '人工検査.py', '準備する.py', '条件.md')


def sha(path: Path) -> str:
    """
    機能: 小型準備源の物理指紋を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 人工7主群・構文・CLI拒否を実行し、自然未読の停止を固定する。
    引数: なし。返り値: None。許可2gzipもこの段階では開かない。
    """
    before = {name: sha(HERE / name) for name in NAMES}
    for name in NAMES:
        if name.endswith('.py'): py_compile.compile(str(HERE / name), doraise=True)
    artificial = subprocess.run([sys.executable, '-X', 'utf8', str(HERE / '人工検査.py')],
                                capture_output=True, text=True, encoding='utf-8')
    assert artificial.returncode == 0, artificial.stdout + artificial.stderr
    cli = []
    for arguments, expected in ((['--help'], 0), ([], 2), (['--prepare-sha256', '未承認', '--output-dir', 'work/未実行'], 2)):
        run = subprocess.run([sys.executable, '-X', 'utf8', str(HERE / '生成する.py'), *arguments],
                             capture_output=True, text=True, encoding='utf-8')
        assert run.returncode == expected, run.stdout + run.stderr
        cli.append({'arguments': arguments, 'exit_code': run.returncode})
    assert before == {name: sha(HERE / name) for name in NAMES}
    ready = {'成功': True, '区分': 'Rootレビュー待ちの自然前準備', '人工主群': 7,
             '構文確認': 4, 'CLI境界': cli, '固定源': before,
             '人工ログSHA256': sha(HERE / '人工のログ.txt'), '自然本文読取': False,
             '旧源/正式/100X/採否/金融/Raw/追加2場の変更又は読取': False}
    path = HERE / '準備の確認.json'
    with path.open('x', encoding='utf-8', newline='\n') as output:
        json.dump(ready, output, ensure_ascii=False, indent=2); output.write('\n')
    stop = {'成功': True, '編集停止': True, 'UTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            '準備SHA256': sha(path), '保存対象': {**before, '人工のログ.txt': sha(HERE / '人工のログ.txt'),
                                               '準備の確認.json': sha(path)},
            '自然生成はRootレビュー後の明示通知まで未実行': True,
            '入力': '固定147Source gzipと148出生台帳gzipの2点だけ。本文は未読。',
            '新試行番号/新100X/取引選択/金融': False}
    target = HERE / '停止の確認.json'
    with target.open('x', encoding='utf-8', newline='\n') as output:
        json.dump(stop, output, ensure_ascii=False, indent=2); output.write('\n')
    print(json.dumps({'成功': True, '準備SHA256': sha(path), '停止SHA256': sha(target)}, ensure_ascii=False))


if __name__ == '__main__': main()
