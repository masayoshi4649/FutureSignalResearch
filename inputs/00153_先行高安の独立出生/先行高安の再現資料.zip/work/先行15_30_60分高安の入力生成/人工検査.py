"""先行窓のr除外・時計・欠測・compact出力を自然本文なしで確かめる。"""
from pathlib import Path
import copy
import gzip
import hashlib
import importlib.util
import io
import json
import tempfile
import unittest
import 先行高安 as core

HERE = Path(__file__).resolve().parent


def bar(index: int, **updates) -> dict:
    """
    機能: 実時間60秒格子の人工足だけを作る。
    引数: index(int)、updates(dict)。返り値: dict。
    """
    result = {'id': f'b{index}', 'session': '人工場', 'contract': '人工限月', 'width_seconds': 60,
              'start': index * 60, 'end': (index + 1) * 60, 'available_at': (index + 2) * 60,
              'stamp': {'time': (index + 2) * 60 + 1, 'index': index, 'line': index + 1},
              'ohlc': {'open': 100 + index, 'high': 110 + index, 'low': 90 + index, 'close': 105 + index},
              'price_known': True, 'volume_known': True, 'closed': True, 'missing': False}
    result.update(updates)
    return result


# ----------------------------------------
def quote(value: dict) -> dict:
    """
    機能: 人工足の配送Rawと同一の人工q0を作る。
    引数: value(dict)。返り値: dict。
    """
    at = value['stamp']
    return {'clock': '人工', 'time': at['time'], 'index': at['index'], 'source_line': at['line'],
            'last': 100, 'bid': 99, 'ask': 101, 'quote_ok': True}


# ----------------------------------------
def fixture(bars: list[dict]) -> tuple:
    """
    機能: 全配送batchと最新/4slotの人工参照を明示構成する。
    引数: bars(list[dict])。返り値: tuple[dict,list]は人工scene/ledger。
    """
    scene = {'success': True, 'session': '人工場', 'contract': '人工限月', 'start': 0,
             'end': 72000, 'force_close': 70000,
             'bars': [{'bar': value, 'context': {'at': quote(value)}} for value in bars]}
    ledger = []; cursor = 0
    while cursor < len(bars):
        begin = cursor; at = bars[cursor]['stamp']
        while cursor < len(bars) and bars[cursor]['stamp'] == at: cursor += 1
        r = bars[cursor - 1]; q0 = quote(r); event = f'人工/{q0["index"]}/{q0["source_line"]}'
        eligible = r['price_known'] and r['closed'] and q0['time'] < r['end'] + 120
        ledger.append({'event_id': event, 'session': '人工場', 'contract': '人工限月', 'q0': q0,
                       'latest_bar_ref': core.slot_ref(r),
                       'slot_refs': [core.slot_ref(value) for value in bars[max(0, cursor - 4):cursor]],
                       'delivered_bar_refs': [core.slot_ref(value) for value in bars[begin:cursor]],
                       'eligible': eligible, 'feature_generated': eligible,
                       'feature_ref': event if eligible else None})
    return scene, ledger


class PriorRangeTests(unittest.TestCase):
    """自然価格・Source・台帳本文を読まない最小の独立した期待値検査。"""

    def test_01_exact_15_30_60_and_exclude_r(self) -> None:
        """
        機能: 全3窓の正確W分とr/左境界外の高安除外を確認する。
        引数: self(PriorRangeTests)。返り値: None。
        """
        history = [bar(i) for i in range(61)]
        history[-1]['ohlc'] = {'open': 100, 'high': 99999, 'low': 1, 'close': 100}
        for width, low in ((15, 135), (30, 120), (60, 90)):
            result = core.prior_range(history, quote(history[-1]), 0, width)
            self.assertTrue(result['known']); self.assertEqual(result['expected_count'], width)
            self.assertEqual((result['from'], result['to']), ((60 - width) * 60, 3600))
            self.assertEqual((result['high'], result['low']), (169, low))
            self.assertEqual(result['high_first_ref']['id'], 'b59')
        history[44]['ohlc'] = {'open': 100, 'high': 999, 'low': 2, 'close': 100}
        history[45]['ohlc']['high'] = 500
        result = core.prior_range(history, quote(history[-1]), 0, 15)
        self.assertEqual((result['high'], result['low']), (500, 135))
        self.assertEqual(result['high_first_ref'], {'id': 'b45', 'start': 2700, 'end': 2760})

    def test_02_ties_first_market_time_and_zero_range(self) -> None:
        """
        機能: 同値極値は市場順で最初を残し、幅0を高安未知へ変更しない。
        引数: self(PriorRangeTests)。返り値: None。
        """
        history = [bar(i) for i in range(61)]
        for i in (50, 55): history[i]['ohlc']['high'] = 888
        for i in (46, 52): history[i]['ohlc']['low'] = 1
        result = core.prior_range(history, quote(history[-1]), 0, 15)
        self.assertEqual((result['high_first_ref']['id'], result['low_first_ref']['id']), ('b50', 'b46'))
        for value in history[:-1]: value['ohlc'] = dict.fromkeys(('open', 'high', 'low', 'close'), 100)
        result = core.prior_range(history, quote(history[-1]), 0, 60)
        self.assertTrue(result['known']); self.assertTrue(result['range_zero'])
        self.assertEqual((result['high'], result['low'], result['range_points']), (100, 100, 0))

    def test_03_missing_unknown_unclosed_no_compression(self) -> None:
        """
        機能: 欠分・未closed・未知を飛ばさず、窓外へ出た場合だけ回復する。
        引数: self(PriorRangeTests)。返り値: None。
        """
        original = [bar(i) for i in range(61)]; q0 = quote(original[-1])
        absent = original[:50] + original[51:]
        result = core.prior_range(absent, q0, 0, 15)
        self.assertFalse(result['known']); self.assertEqual(result['absent_count'], 1)
        self.assertIsNone(result['high']); self.assertIsNone(result['range_zero'])
        for change, reason in (({'missing': True}, 'missing'), ({'closed': False}, 'not_closed'),
                               ({'price_known': False, 'ohlc': dict.fromkeys(('open', 'high', 'low', 'close'), 0)}, 'price_unknown')):
            history = copy.deepcopy(original); history[50].update(change)
            result = core.prior_range(history, q0, 0, 15)
            self.assertFalse(result['known']); self.assertIn(reason, result['unknown_reasons'])
            self.assertIsNone(result['high_first_ref'])
        original[5]['price_known'] = False
        self.assertTrue(core.prior_range(original, q0, 0, 15)['known'])
        self.assertFalse(core.prior_range(original, q0, 0, 60)['known'])
        original[50]['volume_known'] = False
        self.assertTrue(core.prior_range(original, q0, 0, 15)['known'])
        original[-1]['price_known'] = False; original[-1]['closed'] = False
        self.assertTrue(core.prior_range(original, q0, 0, 15)['known'])

    def test_04_session_start_and_no_carry(self) -> None:
        """
        機能: 場先頭不足は全W本を未知にし、他場で補った履歴を拒否する。
        引数: self(PriorRangeTests)。返り値: None。
        """
        history = [bar(0)]
        for width in core.WINDOWS:
            result = core.prior_range(history, quote(history[-1]), 0, width)
            self.assertFalse(result['known']); self.assertEqual(result['slot_record_count'], 0)
            self.assertEqual((result['absent_count'], result['before_session_count']), (width, width))
            self.assertIsNone(result['low'])
        history = [bar(i) for i in range(16)]; history[5]['session'] = '他場'
        with self.assertRaises(AssertionError): core.prior_range(history, quote(history[-1]), 0, 15)

    def test_05_same_raw_all_delivery_latest_unknown_and_refs(self) -> None:
        """
        機能: 同Raw catch-upを全反映し、最新未知非fallback・ref照合・非改変を確認する。
        引数: self(PriorRangeTests)。返り値: None。
        """
        history = [bar(i) for i in range(3)]
        history[1]['stamp'] = history[2]['stamp'] = {'time': 250, 'index': 10, 'line': 11}
        history[2]['price_known'] = False
        scene, ledger = fixture(history); before = copy.deepcopy((scene, ledger))
        result = core.inspect_scene(scene, ledger)
        self.assertEqual((scene, ledger), before)
        self.assertEqual(result['counts']['all_q0'], 2)
        self.assertEqual(result['counts']['same_raw_catchup_q0'], 1)
        self.assertEqual(result['rows'][-1]['r_ref'], 'b2')
        self.assertIsNone(result['bars'][-1]['ohlc'])
        self.assertFalse(result['rows'][-1]['eligible'])
        bad = copy.deepcopy(ledger); bad[-1]['latest_bar_ref'] = core.slot_ref(history[1])
        with self.assertRaises(AssertionError): core.inspect_scene(scene, bad)
        bad = copy.deepcopy(ledger); bad[-1]['slot_refs'] = bad[-1]['slot_refs'][1:]
        with self.assertRaises(AssertionError): core.inspect_scene(scene, bad)
        bad = copy.deepcopy(ledger); bad[-1]['delivered_bar_refs'].pop()
        with self.assertRaises(AssertionError): core.inspect_scene(scene, bad)

    def test_06_future_clock_line_and_bbo_independence(self) -> None:
        """
        機能: 同時刻後原行・未来時刻を拒否し、異常BBOは高安の既知性へ混ぜない。
        引数: self(PriorRangeTests)。返り値: None。
        """
        history = [bar(i) for i in range(16)]; q0 = quote(history[-1])
        for key, value in (('time', q0['time'] + 1), ('index', q0['index'] + 1), ('line', q0['source_line'] + 1)):
            bad = copy.deepcopy(history); bad[5]['stamp'][key] = value
            with self.assertRaises(AssertionError): core.prior_range(bad, q0, 0, 15)
        q0['quote_ok'] = False; q0['bid'] = 102; q0['ask'] = 101
        self.assertTrue(core.prior_range(history, q0, 0, 15)['known'])
        self.assertFalse(core.compact_quote(q0)['normal_bbo'])
        q0['bid'] = 0
        self.assertIsNone(core.compact_quote(q0)['bid'])
        with self.assertRaises(AssertionError): core.validate_bar(bar(1, price_known=1))

    def test_07_stream_gzip_crc_and_opaque_nonbars(self) -> None:
        """
        機能: 場単位読取の全bytes/CRCと、対象配列以外の不使用を人工で確認する。
        引数: self(PriorRangeTests)。返り値: None。
        """
        spec = importlib.util.spec_from_file_location('先行生成器', HERE / '生成する.py')
        generator = importlib.util.module_from_spec(spec); spec.loader.exec_module(generator)
        value = {'scenes': [{'session': '人工1'}, {'session': '人工2'}], '後続非利用': '人工だけ'}
        body = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
        with tempfile.TemporaryDirectory(prefix='prior_range_') as temporary:
            path = Path(temporary) / '人工.json.gz'; path.write_bytes(gzip.compress(body, mtime=0))
            evidence = {}; self.assertEqual(list(generator.array_items(path, 'scenes', evidence)), value['scenes'])
            self.assertEqual(evidence['decoded_sha256'], hashlib.sha256(body).hexdigest())
            self.assertTrue(evidence['full_gzip_crc_checked'])
            corrupted = bytearray(path.read_bytes()); corrupted[-8] ^= 1; path.write_bytes(corrupted)
            with self.assertRaises(gzip.BadGzipFile): list(generator.array_items(path, 'scenes', {}))


def main() -> None:
    """
    機能: 人工だけを実行し、後段の準備器が固定するログを保存する。
    引数: なし。返り値: None。許可2gzipの自然本文を読まない。
    """
    log = io.StringIO()
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(PriorRangeTests))
    (HERE / '人工のログ.txt').write_text(log.getvalue(), encoding='utf-8')
    assert result.wasSuccessful(), log.getvalue()
    print(json.dumps({'成功': True, '人工主群': result.testsRun}, ensure_ascii=False))


if __name__ == '__main__': main()
