"""共通時計を一度だけ保存し、純入口生成と金融部品のソースを原フォルダ構造で保管する。"""
import json
import sys
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import numpy as np
from 母集団 import HERE, ROOT, ref

DEST = ROOT/'inputs/00213_日経型TOPIXの純入口'
STUDY = next((ROOT/'study').glob('00213_*'))
FOLDERS = (('額面',HERE),('呼値',HERE/'呼値換算'))
CLOCKS = ('scene','time','index','line','q1_index','finish_time','finish_index','finish_line')


# ----------------------------------------
def save(path: Path, data: object) -> None:
    """
    機能：再現資源の索引を日本語UTF-8で保存する。
    引数：path（Path）は保存先、data（object）はJSON互換値。
    返り値：None。
    """
    path.write_text(json.dumps(data,ensure_ascii=False,indent=1)+'\n',encoding='utf-8')


# ----------------------------------------
def main() -> None:
    """
    機能：共通の時計、4つの固定条件、生成ソース、原入力の指紋を恒久化する。
    引数：なし。
    返り値：None。
    """
    DEST.mkdir(exist_ok=True)
    arrays, forms = {}, {}
    for mode, folder in FOLDERS:
        for name in ('基準179','純入口'):
            with np.load(folder/(name+'.npz'),allow_pickle=False) as data:
                forms[mode+name] = {}
                for k in data.files:
                    value = data[k]
                    shared = next((key for key,saved in arrays.items() if key.split('__')[-1]==k and
                                   saved.dtype==value.dtype and np.array_equal(saved,value)),None)
                    key = shared if shared else ('共通' if k in CLOCKS else mode+name)+'__'+k
                    if key in arrays:
                        np.testing.assert_array_equal(arrays[key],value)
                    else:
                        arrays[key] = value
                    forms[mode+name][k] = key
    assert all(all(mapping[k]=='共通__'+k for k in CLOCKS) for mapping in forms.values())
    np.savez_compressed(DEST/'全純入口.npz',**arrays)
    save(DEST/'候補列.json',forms)
    # ----------------------------------------
    raw_sources=[]
    native = json.loads((HERE/'母集団計画.json').read_bytes())
    for row in native['scenes']:
        raw_sources.append({'場':row['session'],**{k:{**row[k],
            'path':Path(row[k]['path']).relative_to(ROOT.parent/'JP_OSE_Data').as_posix()}
            for k in ('raw','csv_1m','csv_5m')}})
    save(DEST/'原板と分足の指紋.json',raw_sources)
    save(DEST/'保留の発生.json',{mode:json.loads((folder/'発生診断.json').read_bytes()) for mode,folder in FOLDERS})
    manifests=[json.loads((folder/'純部品の依存.json').read_bytes()) for _,folder in FOLDERS]
    assert manifests[0]==manifests[1]
    # ----------------------------------------
    paths={ROOT/r['path'] for r in manifests[0]}
    for path in [HERE/'入力を保存する.py',HERE/'純入口を作る.py',HERE/'母集団.py',HERE/'呼値を揃える.py',
                 ROOT/'work/173追加なしの因果再生/engine173.py',ROOT/'work/179終了前決済/early179.py',
                 ROOT/'work/163任意幅の数値化/arrays163.py',ROOT/'work/173追加なしの評価/metrics173.py']:
        paths.add(path)
    go_dirs=('166可変場の観測','未見入口の同体接続','三時間軸の公開器','115三時間軸と方向性の公開',
             '148全1分知得の入口母集団','118複数技法の入口条件','148全1分候補の当時特徴','三時間軸の市場入力口')
    for name in go_dirs:
        root = ROOT/'work'/name
        paths.add(root/'go.mod')
        paths.update(p for p in root.glob('*.go') if not p.name.endswith('_test.go'))
    paths.add(ROOT/'work/未見入口の同体接続/cmd/run/main.go')
    with ZipFile(DEST/'再現Source.zip','w',ZIP_DEFLATED,compresslevel=9) as archive:
        for path in sorted(paths):
            archive.write(path,path.relative_to(ROOT).as_posix())
    save(DEST/'保存索引.json',{'原板数':85,'確認日':'2026-11-19','判断数':len(arrays['共通__scene']),
        '入力':[{**ref(path),'path':path.name} for path in sorted(DEST.iterdir()) if path.suffix in ('.npz','.zip','.json')
              and path.name!='保存索引.json'],
        'ソース':[{**ref(path),'path':path.relative_to(ROOT).as_posix()} for path in sorted(paths)]})
    print('保存',len(paths),'部品、',len(arrays),'共有列')


if __name__=='__main__':
    main()
