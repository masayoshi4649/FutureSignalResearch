"""TOPIXの原板と確定CSVから、日経と同じ原行索引・100特徴・出生時計を再生する。"""
from datetime import datetime, timedelta, timezone
from pathlib import Path
import gzip
import hashlib
import json
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DATA = ROOT.parent / 'JP_OSE_Data/future/TOPIX'
INDEX = ROOT / 'work/166可変場の観測/可変場観測.exe'
BRIDGE = ROOT / 'work/未見入口の同体接続/入口同体接続.exe'
FIRST = '2026-09-21_Day'
LAST = '2026-11-18_Day'
JST = timezone(timedelta(hours=9))


# ----------------------------------------
def ref(path: Path) -> dict:
    """
    機能: 入力ファイルの物理指紋を取得する。
    引数: path(Path)は対象ファイル。
    返り値: dictはパス・バイト数・SHA256。
    """
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path':str(path), 'bytes':path.stat().st_size, 'sha256':digest}


# ----------------------------------------
def save(path: Path, value: dict) -> None:
    """
    機能: 入力仕様を日本語JSONで保存し、既存内容との一致を確認する。
    引数: path(Path)は出力先、value(dict)は記録内容。
    返り値: None。
    """
    if path.exists():
        assert json.loads(path.read_bytes()) == value, path
    else:
        path.write_text(json.dumps(value, ensure_ascii=False, separators=(',', ':'))+'\n', encoding='utf-8')


# ----------------------------------------
def main() -> None:
    """
    機能: 日経と同じ解析器で原板と確定CSVからTOPIXの当時入力を作る。
    引数: なし。
    返り値: None。
    """
    scenes = []
    for folder in sorted(DATA.iterdir()):
        if not folder.is_dir() or not FIRST <= folder.name <= LAST:
            continue
        raw = folder / 'book.jsonl.gz'
        if not raw.is_file():
            raw = folder / 'book.jsonl'
        with (gzip.open(raw,'rb') if raw.suffix=='.gz' else raw.open('rb')) as stream:
            contract = json.loads(stream.readline())['Symbol']
        day = folder.name.endswith('_Day')
        date = datetime.fromisoformat(folder.name[:10]).replace(tzinfo=JST)
        start = date + (timedelta(hours=8,minutes=45) if day else timedelta(hours=17))
        end = date + (timedelta(hours=15,minutes=45) if day else timedelta(days=1,hours=6))
        scenes.append({'session':folder.name,'contract':contract,'start':start.timestamp(),'end':end.timestamp(),
                       'force_close':end.timestamp()-600,'raw':ref(raw),'expected_accepted':0,'expected_quality':None,
                       'expected_raw_stat':{'bytes':raw.stat().st_size,'mtime_ns':raw.stat().st_mtime_ns},'entries':[]})
    assert len(scenes)==85
    empty=HERE/'索引計画.json'
    save(empty, {'trial':213,'scenes':scenes,'expected_entry_count':0})
    index_dir=HERE/'原行索引'
    manifest=index_dir/'manifest.json'
    if not manifest.is_file():
        subprocess.run([str(INDEX),'--mode','index','--input',str(empty),'--sha256',ref(empty)['sha256'],
                        '--output-dir',str(index_dir),'--workers','8'],check=True)
    records=json.loads(manifest.read_bytes())['scenes']
    targets=[]
    for scene,record in zip(scenes,records,strict=True):
        assert record['success'] and record['session']==scene['session']
        folder=DATA/scene['session']
        targets.append({**{k:scene[k] for k in ('session','contract','start','end','force_close','raw')},
                        'expected_accepted':record['rows'],'expected_quality':record['quality'],
                        'quote_index':ref(index_dir/record['index']['path']),
                        'csv_1m':ref(folder/'candle_1min.csv'),'csv_5m':ref(folder/'candle_5min.csv')})
    plan=HERE/'母集団計画.json'
    save(plan, {'trial':213,'version':1,'transport':'index48','history_through':'',
                'index_manifest':ref(manifest),'scenes':targets})
    destination=HERE/'母集団'
    if not (destination/'完了.json').is_file():
        subprocess.run([str(BRIDGE),'--execute-after-f0','--plan',str(plan),'--plan-sha',ref(plan)['sha256'],
                        '--plan-bytes',str(ref(plan)['bytes']),'--output',str(destination)],check=True)


if __name__=='__main__':
    main()
