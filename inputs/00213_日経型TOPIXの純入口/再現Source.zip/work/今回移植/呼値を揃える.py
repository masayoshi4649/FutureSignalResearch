"""TOPIXの原板価格と分足OHLCを日経と同じ呼値表記へ換算し同じGo部品へ渡す。"""
import csv
import gzip
import json
import subprocess
from pathlib import Path

import numpy as np
from 母集団 import HERE, BRIDGE, ref, save


# ----------------------------------------
def prices(source: Path, target: Path) -> dict:
    """
    機能：48バイト索引のLast・Bid・Askを20倍し、正常性・時計・行番号を保つ。
    引数：source、target（Path）は入力と換算先。
    返り値：dictは換算後の指紋。
    """
    content = bytearray(gzip.decompress(source.read_bytes()))
    assert content[:8] == b'NQIDX163' and (len(content)-8) % 48 == 0
    values = np.ndarray(((len(content)-8)//48, 3), dtype='<f8', buffer=content, offset=24, strides=(48,8))
    values *= 20
    target.write_bytes(gzip.compress(content, compresslevel=1, mtime=0))
    return ref(target)


# ----------------------------------------
def candles(source: Path, target: Path) -> dict:
    """
    機能：元CSVの価格4列だけを20倍し、量・確定状態・時計を保持する。
    引数：source、target（Path）は分足CSVの元と換算先。
    返り値：dictは換算後の指紋。
    """
    with source.open(encoding='utf-8-sig', newline='') as src, target.open('w', encoding='utf-8', newline='') as dst:
        rows, writer = csv.reader(src), csv.writer(dst, lineterminator='\n')
        header = next(rows)
        assert header[:5] == ['time','open','high','low','close']
        writer.writerow(header)
        for row in rows:
            for i in range(1,5):
                if row[i].strip():
                    row[i] = format(float(row[i]) * 20, '.17g')
            writer.writerow(row)
    return ref(target)


# ----------------------------------------
def main() -> None:
    """
    機能：共通原板に由来する派生索引を区別して記録し、換算側の当時入力を生成する。
    引数：なし。
    返り値：None。
    """
    folder = HERE / '呼値換算'
    folder.mkdir(exist_ok=True)
    plan = json.loads((HERE/'母集団計画.json').read_bytes())
    manifest = json.loads((HERE/'原行索引/manifest.json').read_bytes())
    for scene, item in zip(plan['scenes'], manifest['scenes'], strict=True):
        assert scene['session'] == item['session']
        original = Path(scene['quote_index']['path'])
        assert ref(original)['sha256'] == item['index']['sha256']
        new = prices(original, folder / original.name)
        scene['quote_index'] = new
        item['index'], item['index_bytes'] = {'path':new['path'], 'sha256':new['sha256']}, new['bytes']
        for k in ('csv_1m','csv_5m'):
            original = Path(scene[k]['path'])
            assert ref(original) == scene[k]
            scene[k] = candles(original, folder / (scene['session'] + '_' + original.name))
    manifest['派生'] = '価格3列20倍。元の品質指標は原板由来。換算索引は特徴計算のみ。'
    manifest_path = folder / 'manifest.json'
    save(manifest_path, manifest)
    plan['index_manifest'] = ref(manifest_path)
    plan_path = folder / '母集団計画.json'
    save(plan_path, plan)
    destination = folder / '母集団'
    if not (destination/'完了.json').is_file():
        subprocess.run([str(BRIDGE),'--execute-after-f0','--plan',str(plan_path),'--plan-sha',ref(plan_path)['sha256'],
                        '--plan-bytes',str(ref(plan_path)['bytes']),'--output',str(destination)],check=True)


if __name__ == '__main__':
    main()
