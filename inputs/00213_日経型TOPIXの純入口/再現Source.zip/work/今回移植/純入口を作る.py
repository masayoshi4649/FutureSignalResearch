"""固定199_02とその179基準を、Goが作った各商品の当時特徴から再生成する。"""
from argparse import ArgumentParser
from pathlib import Path
import json
import sys
import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0,str(ROOT/'work/194追加二場'))
sys.path.insert(0,str(ROOT/'work/195保留中Tの技術根拠'))


# ----------------------------------------
def compact(features: object, captures: list) -> dict:
    """
    機能：当時の取得、失効、q0価格を共通原行の整数識別に接続する。
    引数：features（FeatureDataset）は当時100特徴、captures（list）は取得対応。
    返り値：dictは場・q0・q1・終了時刻の列。q1の価格は入力しない。
    """
    by_id = {row['event_id']: row for row in captures}
    assert len(by_id) == len(captures) == len(features.q0_meta)
    records = [by_id[q['event_id']] for q in features.q0_meta]
    quotes = [r['q0'] for r in records]
    features.q0_prices = {k: np.asarray([q[k] for q in quotes]) for k in ('last','bid','ask','time')}
    features.q0_prices['line'] = np.array([q['source_line'] for q in quotes])
    features.q0_prices['normal'] = np.array([q['quote_ok'] for q in quotes],dtype=bool)
    index = np.array([q['index'] for q in quotes],dtype=np.int64)
    for q, m in zip(quotes,features.q0_meta,strict=True):
        assert (q['time'],q['index'],q['source_line']) == (m['q0_time'],m['q0_index'],m['q0_line'])
    # ----------------------------------------
    # 最大整数は同秒の全有限原行より後となり、旧engineの無限大終点と同じ比較をする。
    sentinel = int(np.iinfo(np.int64).max)
    finishes, acquired = [], []
    for record in records:
        quote = record.get('q1') if record['status']=='filled' else record.get('terminated_at')
        expiration = (record['expires'],sentinel,sentinel)
        if quote is None:
            final = expiration
        else:
            clock = (quote['time'],quote['index'],quote['source_line'])
            final = clock if record['status']=='filled' else min(clock, expiration)
        finishes.append(final)
        acquired.append(record['q1']['index'] if record['status']=='filled' else -1)
    return {'scene':np.array([m['session_index'] for m in features.q0_meta],dtype=np.int32),
            'index':index,'time':features.q0_prices['time'],'line':features.q0_prices['line'],
            'q1_index':np.array(acquired,dtype=np.int64),'finish_time':np.array([r[0] for r in finishes]),
            'finish_index':np.array([r[1] for r in finishes],dtype=np.int64),
            'finish_line':np.array([r[2] for r in finishes],dtype=np.int64)}


# ----------------------------------------
def main() -> None:
    """
    機能：候補決定後の金融結果を使わず、額面又は呼値換算による二つの入口を作る。
    引数：CLIの--folder（Path）は当時特徴の親フォルダ。
    返り値：None。純入口・保留カウント・依存一覧を当該フォルダへ記録する。
    """
    parser = ArgumentParser()
    parser.add_argument('--folder', type=Path, default=HERE)
    args = parser.parse_args()
    folder = args.folder.resolve()
    opened = set()

    def trace(event: str, data: tuple) -> None:
        """
        機能：実行中に開いた研究ソースと設定ファイルの位置を記録する。
        引数：event（str）は監査イベント名、data（tuple）は監査情報。
        返り値：None。
        """
        if event == 'open' and isinstance(data[0],str) and data[0].endswith(('.json','.json.gz','.npz','.py')):
            opened.add(data[0])

    sys.addaudithook(trace)
    import NK純接続194 as nk
    import rules195 as rules
    from 母集団 import ref
    common = nk.common()
    features, captures, _ = common.P.B.P.R168.BASE.load_features(folder / '母集団')
    clocks = compact(features,captures)
    del captures
    base = nk.build(features)['全期_J035']
    # 固定旧00を同時計算するのは空の参照候補集合を想定しない旧親APIとの互換のため。
    variants = rules.build(features,base,['E195_00','E195_05'])
    for name, bundle in [('基準179',base),('純入口',variants['bundles']['E195_05'])]:
        arrays = {**clocks, **{k:bundle[k] for k in ('added','mw','fw','hi')},
                  **{k:bundle['birth'][k] for k in ('core','branches','technical','tier')}}
        np.savez_compressed(folder / (name+'.npz'),**arrays)
    stats = {}
    for i,scene in enumerate(features.scenes):
        mask = clocks['scene'] == i
        d = variants['diagnostics']['E195_05']
        stats[scene['session']] = {'判断数':int(mask.sum()),'主幹元':int((base['birth']['core'][mask]!=0).sum()),
            '主幹199':int((arrays['core'][mask]!=0).sum()),
            **{k:int(np.count_nonzero(d[k][mask])) for k in ('guarded','risk_unknown','reverse_confirmed',
            'follow_confirmed','pending_t_signal','pending_t_blocked')}}
    (folder/'発生診断.json').write_text(json.dumps(stats,ensure_ascii=False,indent=1)+'\n',encoding='utf-8')
    # ----------------------------------------
    paths = {Path(value).resolve() for value in opened}
    paths.update(Path(m.__file__).resolve() for m in list(sys.modules.values()) if getattr(m,'__file__',None))
    wanted = []
    for path in sorted(paths):
        if not path.is_file() or not path.is_relative_to(ROOT) or path.is_relative_to(HERE):
            continue
        if 'site-packages' in path.parts or '複合テクニカル学習環境' in path.parts:
            continue
        if path.suffix not in ('.py','.gz','.json','.npz'):
            continue
        wanted.append({**ref(path),'path':path.relative_to(ROOT).as_posix()})
    (folder/'純部品の依存.json').write_text(json.dumps(wanted,ensure_ascii=False,indent=1)+'\n',encoding='utf-8')
    print('完了',folder,len(clocks['time']),flush=True)


if __name__=='__main__':
    main()
