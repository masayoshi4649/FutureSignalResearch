"""元153の配送prefixから回帰測定全窓を独立再構成し、数値をNumPy解と照合する。"""
from pathlib import Path
from collections import Counter
import gzip
import hashlib
import json
import math
import sys
import numpy as np

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
SOURCE=ROOT/'inputs/00153_先行高安の独立出生/先行高安の入力.json.gz'
RESULT=ROOT/'work/先行回帰の自然入力/先行回帰の入力.json.gz'
PREP=ROOT/'work/先行域の回帰入力の準備/準備の確認.json'
SOURCES={SOURCE:('2c020fed5b336ed0b417d8e72a07c6336ea475b09b9a2ff37f26ec4ce4d56bf8','8e145275dda385e4c2f87500978716654d10efb0903a4011f2bcc304a7906b14'),
    RESULT:('f0eef157e0559827e5d7d2f2d614b8ab4d3a98c27b8d463b02c2eec5e9325e98','7b05fa49f502ff8b25e7be11ffacde1898b3ca38bcb9d58835d8dc5f9d6e2387')}
PREP_SHA='8ef57cab4050bfd8a59c1b836ac53085aae3c8b8ef76a807908864b3236ae093'
WIDTHS=(15,30,60)


def sha(path: Path) -> str:
    """
    機能: 大きな物理入力をbufferで指紋化する。
    引数: path(Path)。返り値: str。
    """
    digest=hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda:source.read(1<<20),b''):digest.update(block)
    return digest.hexdigest()


def nonfinite(token: str) -> None:
    """
    機能: JSON標準外の数値リテラルを拒否する。
    引数: token(str)。返り値: None、常にValueError。
    """
    raise ValueError('非有限JSON:'+token)


def read_gzip(path: Path,physical: str,decoded: str) -> tuple:
    """
    機能: 物理/解凍SHAと全CRC/statを照合し副本なしで読む。
    引数: path(Path)、physical/decoded(str)。返り値: tupleはJSON値と証跡。
    """
    before=path.stat();assert sha(path)==physical
    with gzip.open(path,'rb') as source:body=source.read()
    assert hashlib.sha256(body).hexdigest()==decoded
    value=json.loads(body,parse_constant=nonfinite);after=path.stat()
    assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns) and sha(path)==physical
    return value,{'path':path.relative_to(ROOT).as_posix(),'physical_sha256':physical,'decoded_sha256':decoded,
        'physical_bytes':before.st_size,'decoded_bytes':len(body),'full_crc_checked':True,'stat_before':[before.st_size,before.st_mtime_ns],
        'stat_after':[after.st_size,after.st_mtime_ns]}


def stamp(value: dict) -> tuple:
    """
    機能: q0とSource Stampの時刻/採用行/物理行を取り出す。
    引数: value(dict)。返り値: tuple[float,int,int]。
    """
    time=value['time'];index=value['index'];line=value['line'] if 'line' in value else value['source_line']
    assert type(time) in (int,float) and math.isfinite(time)
    assert type(index) is int and index>=0 and type(line) is int and line>0
    return time,index,line


def finite(value) -> bool:
    """
    機能: boolや非有限を実数として受理しない。
    引数: value(object)。返り値: bool。
    """
    return type(value) in (int,float) and math.isfinite(value)


def numerical(closes: list) -> dict:
    """
    機能: 切片と中心化市場分の行列最小二乗をNumPyで独立に解く。
    引数: closes(list[float])。返り値: dictは標本内の7数値と4正本値。
    """
    values=np.asarray(closes,dtype=np.float64);n=len(values);assert n in WIDTHS and np.all(np.isfinite(values)) and np.all(values>0)
    x=np.arange(n,dtype=np.float64);x-=np.mean(x);design=np.column_stack((np.ones(n),x));y=values-values[0]
    coefficients,_,rank,_=np.linalg.lstsq(design,y,rcond=None);assert rank==2
    fitted=design@coefficients;residual=y-fitted;centered=y-np.mean(y)
    sse=float(np.dot(residual,residual));syy=float(np.dot(centered,centered));constant=all(v==closes[0] for v in closes)
    return {'points':n,'constant':constant,'first_close':closes[0],'last_close':closes[-1],
        'slope_pt_per_minute':float(coefficients[1]),'r_squared':None if constant else 1-sse/syy,
        'mean_close':float(values[0]+np.mean(y)),'population_std_close':float(np.std(y,ddof=0)),
        'residual_rmse':math.sqrt(sse/n),'fitted_first':float(values[0]+fitted[0]),'fitted_last':float(values[0]+fitted[-1])}


def compare_fit(actual: dict,closes: list,errors: dict) -> int:
    """
    機能: 作者関数をimportせず独立期待値へ全fit項目を照合する。
    引数: actual(dict)、closes(list)、errors(dict)。返り値: intは数値比較数。
    """
    expected=numerical(closes);assert set(actual)==set(expected)
    for key in ('points','constant','first_close','last_close'):assert actual[key]==expected[key],key
    checks=0
    for key,value in expected.items():
        if key in ('points','constant','first_close','last_close'):continue
        result=actual[key]
        if value is None:assert result is None
        else:
            assert finite(result);difference=abs(result-value)
            errors[key]=max(errors.get(key,0.),difference)
            tolerance=3e-11 if key in ('slope_pt_per_minute','r_squared','residual_rmse','population_std_close') else 3e-8
            assert difference<=tolerance,(key,result,value,difference)
        checks+=1
    return checks


def prior(prefix: dict,start: float,scene_start: float,width: int) -> tuple:
    """
    機能: q0までのprefixだけでr除外の実時間窓とknown/reasons/countsを再構成する。
    引数: prefix(dict[float,dict])、start/scene_start(float)、width(int)。返り値: tuple。
    """
    positions=[start-width*60+i*60 for i in range(width)];feet=[prefix[t] for t in positions if t in prefix]
    count=len(feet);missing=sum(b['missing'] for b in feet);closed=sum(b['closed'] for b in feet);prices=sum(b['price_known'] for b in feet)
    before=sum(t<scene_start for t in positions);absent=width-count;reasons=[]
    if before:reasons.append('before_session')
    if absent>before:reasons.append('absent_slot')
    if missing:reasons.append('missing')
    if closed<count:reasons.append('not_closed')
    if prices<count:reasons.append('price_unknown')
    counts={'expected_count':width,'slot_record_count':count,'observed_count':count-missing,'closed_count':closed,
        'price_known_count':prices,'missing_count':missing,'absent_count':absent,'before_session_count':before}
    return feet,count==width and not reasons,reasons,counts


def inspect(source: dict,result: dict) -> dict:
    """
    機能: 全場配送prefixを独立再生し全q0/全known窓/未知/refs/clockを照合する。
    引数: source/result(dict)。返り値: dictは数値/分母のみの小型結果。
    """
    assert source['success'] and source['schema']=='prior_time_range_v1' and result['success'] and result['schema']=='prior_close_ols_v1'
    assert not source['strategy_selected'] and not source['financial_labels_used'] and not result['strategy_selected'] and not result['financial_labels_used']
    assert source['sessions']==result['sessions'] and len(source['sessions'])==len(source['scenes'])==len(result['scenes'])==73
    assert source['windows_minutes']==result['windows_minutes']==list(WIDTHS)
    totals=Counter();windows={str(w):Counter() for w in WIDTHS};errors={};events=set();comparisons=0
    for original,measured in zip(source['scenes'],result['scenes']):
        assert (original['session'],original['contract'])==(measured['session'],measured['contract'])
        assert len(original['rows'])==len(measured['rows']);bars=original['bars'];prefix={};cursor=0;previous=None
        ids={b['id']:b for b in bars};assert len(ids)==len(bars)
        for i,bar in enumerate(bars):
            assert bar['start']==original['start']+i*60 and bar['end']==bar['start']+60<=original['continuous_end']
            assert bar['available_at']==bar['end']+60<=stamp(bar['stamp'])[0]
            assert all(type(bar[k]) is bool for k in ('closed','price_known','volume_known','missing'))
            if bar['price_known']:
                o=bar['ohlc'];assert set(o)=={'open','high','low','close'} and all(finite(v) for v in o.values())
                assert 0<o['low']<=o['open']<=o['high'] and o['low']<=o['close']<=o['high']
            else:assert bar['ohlc'] is None
        for row,out in zip(original['rows'],measured['rows']):
            event=row['event_id'];assert event not in events;events.add(event);now=stamp(row['q0'])
            if previous:assert now[0]>=previous[0] and now[1]>previous[1] and now[2]>previous[2]
            previous=now;batch=[]
            while cursor<len(bars) and stamp(bars[cursor]['stamp'])[1]<=now[1]:
                bar=bars[cursor];assert stamp(bar['stamp'])==now and bar['start'] not in prefix
                prefix[bar['start']]=bar;batch.append(bar);cursor+=1
            assert batch and row['r_ref']==batch[-1]['id']
            assert row['delivered_refs']==[b['id'] for b in batch] and row['slot_refs']==[b['id'] for b in list(prefix.values())[-4:]]
            assert row['quote_ref']=={'source':'ledger148','event_id':event}
            assert set(out)=={'event_id','eligible','r_ref','windows'} and all(out[k]==row[k] for k in ('event_id','eligible','r_ref'))
            assert type(row['eligible']) is bool and set(out['windows'])==set(map(str,WIDTHS))
            r=batch[-1];totals['all_q0']+=1;totals['eligible_q0']+=int(row['eligible']);totals['same_raw_catchup_q0']+=int(len(batch)>1)
            for width in WIDTHS:
                key=str(width);actual=out['windows'][key];saved=row['prior_ranges'][key]
                feet,known,reasons,counts=prior(prefix,r['start'],original['start'],width)
                assert actual['from']==saved['from']==r['start']-width*60 and actual['to']==saved['to']==r['start']
                assert actual['known'] is saved['known'] is known and actual['unknown_reasons']==saved['unknown_reasons']==reasons
                assert all(saved[k]==v for k,v in counts.items())
                for bar in feet:
                    assert bar['id']!=r['id'] and bar['end']<=r['start'] and all(a<=b for a,b in zip(stamp(bar['stamp']),now))
                    assert bar['end']<=bar['available_at']<=stamp(bar['stamp'])[0]<=now[0]
                wc=windows[key];wc['all_q0']+=1;wc['eligible_q0']+=int(row['eligible'])
                wc['known_all_q0']+=int(known);wc['known_eligible_q0']+=int(known and row['eligible'])
                if known:
                    assert set(actual)=={'from','to','known','unknown_reasons','fit','first_ref','last_ref'}
                    assert actual['first_ref']==feet[0]['id'] and actual['last_ref']==feet[-1]['id']
                    assert saved['high']==max(b['ohlc']['high'] for b in feet) and saved['low']==min(b['ohlc']['low'] for b in feet)
                    closes=[b['ohlc']['close'] for b in feet];comparisons+=compare_fit(actual['fit'],closes,errors)
                    constant=all(v==closes[0] for v in closes);wc['constant_all_q0']+=int(constant);wc['constant_eligible_q0']+=int(constant and row['eligible'])
                else:
                    assert set(actual)=={'from','to','known','unknown_reasons','fit'} and actual['fit'] is None
                    assert all(saved[k] is None for k in ('high','low','high_first_ref','low_first_ref','range_points','range_zero'))
        assert cursor==len(bars)
        if len(windows['15']) and len(events)%5000<600:print(json.dumps({'照合済場':original['session'],'累計q0':len(events)},ensure_ascii=False),flush=True)
    assert totals['all_q0']==40544 and totals['eligible_q0']==35339
    assert result['counts']=={k:totals[k] for k in ('all_q0','eligible_q0')}
    for width in WIDTHS:
        key=str(width);wc=dict(windows[key]);assert result['window_counts'][key]==wc
        for name in ('all_q0','eligible_q0','known_all_q0','known_eligible_q0'):assert source['window_counts'][key][name]==wc[name]
    assert [windows[str(w)]['known_eligible_q0'] for w in WIDTHS]==[26005,22127,17323]
    assert all(v['constant_all_q0']==0 for v in windows.values())
    return {'全q0':totals['all_q0'],'適格q0':totals['eligible_q0'],'全73場':73,'known窓数':sum(v['known_all_q0'] for v in windows.values()),
        '数学比較数':comparisons,'数値最大絶対差':errors,'窓別':{k:dict(v) for k,v in windows.items()},'全q0参照_時計_未知_分母一致':True}


def main() -> None:
    """
    機能: Root許可された元入力と測定gzipだけを読み短い確認票で停止する。
    引数: なし。返り値: None。作者測定関数/生成器をimportしない。
    """
    assert sha(PREP)==PREP_SHA;prepared=json.loads(PREP.read_bytes());declared={ROOT/p:h for p,h in prepared['源'].items()}
    assert all(sha(p)==h for p,h in declared.items());before={str(p):[p.stat().st_size,p.stat().st_mtime_ns] for p in declared}
    source,a=read_gzip(SOURCE,*SOURCES[SOURCE]);result,b=read_gzip(RESULT,*SOURCES[RESULT])
    assert result['source']=={'path':SOURCE.relative_to(ROOT).as_posix(),'sha256':SOURCES[SOURCE][0],'decoded_sha256':SOURCES[SOURCE][1]}
    checked=inspect(source,result)
    assert all(sha(p)==h for p,h in declared.items()) and before=={str(p):[p.stat().st_size,p.stat().st_mtime_ns] for p in declared}
    for path,evidence in ((SOURCE,a),(RESULT,b)):
        assert sha(path)==evidence['physical_sha256'] and [path.stat().st_size,path.stat().st_mtime_ns]==evidence['stat_before']
    output={'成功':True,'編集停止':True,'自然採否_容量_金融_新閾値評価':False,'作者測定算術import':False,
        'Raw_CSV_追加2場_観測label未読':True,'解凍副本なし':True,'入力':a,'測定':b,'準備SHA256':PREP_SHA,
        'NumPy版':np.__version__,'Python版':sys.version,'独立式':'numpy.linalg.lstsq、切片＋中心化実1分格子、ddof0標準偏差、sqrt(SSE/W) RMSE',
        '数値許容差':'傾き/R²/std/RMSE 3e-11、価格水準 3e-8。丸めで売買判定を変えた比較ではない。',
        **checked,'元Source全源前後SHA_stat同体':True,'検査器SHA256':sha(Path(__file__))}
    target=HERE/'独立確認.json'
    with target.open('x',encoding='utf-8') as sink:json.dump(output,sink,ensure_ascii=False,indent=2,allow_nan=False);sink.write('\n')
    print(json.dumps({'成功':True,**checked,'独立確認SHA256':sha(target)},ensure_ascii=False))


if __name__=='__main__':
    main()
