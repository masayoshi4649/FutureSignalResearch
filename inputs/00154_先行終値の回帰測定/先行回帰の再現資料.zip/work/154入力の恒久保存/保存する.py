"""154採用前提の回帰測定入力を物理同体で一度保存し、最小再現源を添える。"""
from pathlib import Path
import gzip
import hashlib
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
TARGET = ROOT / 'inputs/00154_先行終値の回帰測定'


def sha(path: Path) -> str:
    """
    機能: 生成物又は小Sourceをbuffer単位で指紋化する。
    引数: path(Path)。返り値: str。
    """
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    """
    機能: 通知済み回帰gzipと生成/人工/自然独立票を保存して全bytesを再読する。
    引数: なし。返り値: None。153/148を再複写せず、売買/容量/金融を計算しない。
    """
    original = ROOT / 'work/先行回帰の自然入力/先行回帰の入力.json.gz'
    physical = 'f0eef157e0559827e5d7d2f2d614b8ab4d3a98c27b8d463b02c2eec5e9325e98'
    decoded = '7b05fa49f502ff8b25e7be11ffacde1898b3ca38bcb9d58835d8dc5f9d6e2387'
    before = (original.stat().st_size, original.stat().st_mtime_ns, sha(original))
    assert before[0] == 6379417 and before[2] == physical
    assert not TARGET.exists()
    TARGET.mkdir()
    saved = TARGET / original.name
    shutil.copyfile(original, saved)
    assert sha(saved) == physical
    digest, count = hashlib.sha256(), 0
    with gzip.open(saved, 'rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
            count += len(block)
    assert digest.hexdigest() == decoded and count == 55041534
    assert before == (original.stat().st_size, original.stat().st_mtime_ns, sha(original))
    generation = ROOT / 'work/先行域の回帰入力の準備'
    ready_path = generation / '準備の確認.json'
    assert sha(ready_path) == '8ef57cab4050bfd8a59c1b836ac53085aae3c8b8ef76a807908864b3236ae093'
    ready = json.loads(ready_path.read_bytes())
    entries = {ROOT / rel: expected for rel, expected in ready['源'].items()}
    entries[ready_path] = sha(ready_path)
    natural = ROOT / 'work/先行回帰入力の自然独立確認'
    assert sha(natural / '独立確認.json') == '03ddcb0ce8edf9ca6aa5b65ebe81119fa3237d0f30e09bd2da5a7c5dd9b2315c'
    for path in (natural / '独立確認.json', natural / '照合する.py',
                 ROOT / 'work/先行回帰の自然入力/生成の確認.json', Path(__file__)):
        entries[path] = sha(path)
    bundle = TARGET / '先行回帰の再現資料.zip'
    records = []
    with zipfile.ZipFile(bundle, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path, expected in entries.items():
            raw = path.read_bytes()
            assert hashlib.sha256(raw).hexdigest() == expected
            relative = path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(relative, date_time=(2026, 11, 12, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, raw)
            records.append({'path': relative, 'sha256': expected, 'bytes': len(raw)})
    with zipfile.ZipFile(bundle) as archive:
        assert archive.testzip() is None
        for row in records:
            assert hashlib.sha256(archive.read(row['path'])).hexdigest() == row['sha256']
            assert sha(ROOT / row['path']) == row['sha256']
    independent = json.loads((natural / '独立確認.json').read_bytes())
    assert independent['成功'] and independent['全q0'] == 40544 and independent['適格q0'] == 35339
    assert independent['known窓数'] == 72809 and independent['数学比較数'] == 509663
    index = {'保存元ZIP': bundle.relative_to(ROOT).as_posix(), 'ZIP_SHA256': sha(bundle),
             'ZIP_bytes': bundle.stat().st_size, '格納源': records,
             '原153入力は共有': {'path': 'inputs/00153_先行高安の独立出生/先行高安の入力.json.gz',
                 'physical_sha256': '2c020fed5b336ed0b417d8e72a07c6336ea475b09b9a2ff37f26ec4ce4d56bf8',
                 'decoded_sha256': '8e145275dda385e4c2f87500978716654d10efb0903a4011f2bcc304a7906b14'}}
    (TARGET / '先行回帰の再現資料_索引.json').write_bytes((json.dumps(index, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    readme = '''# 154 先行終値の回帰測定

この保存は非金融の測定入力。154の自然売買/容量/金融は未実行で、手法の有効性や70%先着を意味しない。

正本は[先行回帰の入力.json.gz](先行回帰の入力.json.gz)、6,379,417 bytes。物理SHA256 `f0eef157e0559827e5d7d2f2d614b8ab4d3a98c27b8d463b02c2eec5e9325e98`、解凍55,041,534 bytes/SHA256 `7b05fa49f502ff8b25e7be11ffacde1898b3ca38bcb9d58835d8dc5f9d6e2387`。元work gzipを再圧縮せず一度同体保存し、全CRC/解凍SHAと元の前後stat/SHAを照合した。

[153の先行高安入力](../00153_先行高安の独立出生/README.md)を共有し、最新1分rを除く実時間15/30/60分の先行終値を測定する。範囲は `[r.Start−W,r.Start)` で、15/30/60分足そのものではない。欠測を詰めず、前場で不足を埋めない。参照市場時刻/配送順はq0以前に限定する。

OLSは切片と実1分格子を使い、傾きpt/分、R²、平均終値、母標準偏差(ddof0)、残差RMSE(sqrt(SSE/W))、両端の当てはめ値を保存する。定数系列のR²は未定義で、0補完しない。高いR²は標本内の直線性で、将来収益・方向の正解確率ではない。

全40,544q0・適格35,339・73場を保持。known72,809窓の509,663数値は、別NumPy2.5.4のlstsq標準式と独立に一致した。許容差は傾き/R²/std/RMSE 3e-11、価格水準3e-8で、閾値の売買判定を丸めて合わせた検査ではない。

[最小再現ZIP](先行回帰の再現資料.zip)と[索引](先行回帰の再現資料_索引.json)は元相対work pathを保つ。生成4源、準備票、私有660人工/Source、自然生成票、自然全件独立票/Sourceを格納し、旧途中票や巨大入力・100X・原板・観測は複写していない。再生成は同指紋の共有153入力と停止Sourceを隔離workへ復元して未作成出力先へ行う。既存正本は上書きしない。
'''
    (TARGET / 'README.md').write_bytes(readme.encode('utf-8'))
    proof = {'成功': True, '一度の物理同体保存': True, '生成売買_容量_金融': False,
        'Source_旧153_148変更又は大入力複写': False,
        '入力': {'path': saved.relative_to(ROOT).as_posix(), 'bytes': saved.stat().st_size,
                 'physical_sha256': sha(saved), 'decoded_sha256': decoded, 'decoded_bytes': count,
                 '全gzipCRCと解凍SHA': True},
        'ZIP_SHA256': sha(bundle), '全格納Source数': len(records), '全格納bytes再読同体': True,
        '準備SHA256': sha(ready_path), '独立自然票SHA256': sha(natural / '独立確認.json'),
        'NumPy比較数': 509663, '原入力前後stat_SHA同体': True}
    target = TARGET / '入力の保存確認.json'
    target.write_bytes((json.dumps(proof, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    (HERE / '保存の確認.json').write_bytes((json.dumps({**proof, '恒久保存票SHA256': sha(target)}, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    print(json.dumps({'成功': True, '恒久保存票SHA256': sha(target), 'ZIP_SHA256': sha(bundle),
                       '格納小源': len(records), '入力path': saved.relative_to(ROOT).as_posix()}, ensure_ascii=False))


if __name__ == '__main__':
    main()
