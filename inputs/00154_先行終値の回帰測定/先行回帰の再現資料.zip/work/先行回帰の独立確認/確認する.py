"""自然本文を開かずOLS測定だけをNumPy行列解と時計人工で照合する。"""
from pathlib import Path
import copy
import hashlib
import importlib.util
import json
import math
import sys
import numpy as np

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
SOURCE=ROOT/'work/先行域の回帰入力の準備/回帰を測る.py'
AUTHOR_TEST=ROOT/'work/先行域の回帰入力の準備/人工検査.py'
GENERATOR=ROOT/'work/先行域の回帰入力の準備/生成する.py'
README=ROOT/'work/先行域の回帰入力の準備/README.md'


def sha(path: Path) -> str:
    """
    機能: 固定源を変更せず物理SHAを得る。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def expected(values: list) -> dict:
    """
    機能: 中心xと価格差の行列最小二乗解を独立期待値にする。
    引数: values(list[float])。返り値: dict。
    """
    y=np.asarray(values,dtype=np.float64);n=len(y);x=np.arange(n,dtype=np.float64);x-=x.mean()
    offset=y-y[0];design=np.column_stack((np.ones(n),x));beta,_,rank,_=np.linalg.lstsq(design,offset,rcond=None)
    assert rank==2;pred=design@beta;residual=offset-pred;center=offset-offset.mean();sse=float(residual@residual);syy=float(center@center)
    return {'slope_pt_per_minute':float(beta[1]),'r_squared':1-sse/syy if syy>0 else None,'mean_close':float(y[0]+offset.mean()),
        'population_std_close':math.sqrt(syy/n),'residual_rmse':math.sqrt(sse/n),
        'fitted_first':float(y[0]+pred[0]),'fitted_last':float(y[0]+pred[-1])}


def scene() -> tuple:
    """
    機能: 実schemaのstamp.lineとq0.source_lineを持つ61本を作る。
    引数: なし。返り値: tupleはrow/id索引/start索引。
    """
    bars=[]
    for i in range(61):
        c=1000+i+(i%3)/4
        bars.append({'id':str(i),'start':i*60,'end':(i+1)*60,'available_at':(i+2)*60,
            'stamp':{'time':(i+2)*60,'index':i,'line':i+1},'closed':True,'price_known':True,'missing':False,
            'ohlc':{'open':c,'high':c+1,'low':c-1,'close':c}})
    row={'event_id':'人工','eligible':True,'r_ref':'60','q0':{'time':3720,'index':60,'source_line':61},'prior_ranges':{}}
    for width in (15,30,60):
        foot=bars[60-width:60]
        row['prior_ranges'][str(width)]={'from':(60-width)*60,'to':3600,'known':True,'unknown_reasons':[],
              'high':max(b['ohlc']['high'] for b in foot),'low':min(b['ohlc']['low'] for b in foot)}
    return row,{b['id']:b for b in bars},{b['start']:b for b in bars}


def must_reject(function: object,row: dict,ids: dict,starts: dict) -> None:
    """
    機能: 既知窓の不正を補完せず拒否することを検査する。
    引数: function(object)、row/ids/starts(dict)。返り値: None。
    """
    try:function(row,ids,starts)
    except (AssertionError,KeyError,ValueError):return
    raise AssertionError('不正を受理')


def main() -> None:
    """
    機能: NumPy独立解と意味境界を実行して小票1つで停止する。
    引数: なし。返り値: None。自然入力/ラベル/Source条件は読まない。
    """
    sys.dont_write_bytecode=True;sources=(SOURCE,AUTHOR_TEST,GENERATOR,README)
    before={str(p.relative_to(ROOT)).replace('\\','/'):sha(p) for p in sources}
    stats={str(p):[p.stat().st_size,p.stat().st_mtime_ns] for p in sources}
    spec=importlib.util.spec_from_file_location('regression_measure_review',SOURCE);core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)
    random=np.random.default_rng(153);columns=[]
    for n in (2,3,15,30,60):
        columns.extend([[1000.]*n,[1000+2*i for i in range(n)],[2000-3*i for i in range(n)],[1000.]*(n-1)+[1070.]])
        for _ in range(40):columns.append((68000+random.normal(0,12,n).cumsum()+random.uniform(-3,3)*np.arange(n)).tolist())
    maxima={k:0. for k in expected([1000,1001,1003])};comparisons=0
    for values in columns:
        for transformed in (values,[v+1e8 for v in values],[2*max(values)+100-v for v in values]):
            result=core.fit_closes(transformed);want=expected(transformed)
            for key,value in want.items():
                actual=result[key]
                if value is None:assert actual is None
                else:
                    error=abs(actual-value);maxima[key]=max(maxima[key],error)
                    tolerance=3e-11 if key in ('slope_pt_per_minute','r_squared','residual_rmse','population_std_close') else 3e-8
                    assert error<=tolerance,(key,actual,value,error)
                comparisons+=1
    for values in ([100], [100,None], [100,True], [100,math.nan], [100,math.inf], [100,0]):
        try:core.fit_closes(values)
        except ValueError:pass
        else:raise AssertionError('不正終値を受理')
    row,ids,starts=scene();unchanged=copy.deepcopy((row,ids,starts));measured=core.measure_row(row,ids,starts)
    assert (row,ids,starts)==unchanged
    for width in (15,30,60):
        result=measured['windows'][str(width)];assert result['first_ref']==str(60-width) and result['last_ref']=='59'
        assert result['fit']['points']==width
        want=core.fit_closes([ids[str(i)]['ohlc']['close'] for i in range(60-width,60)])
        assert result['fit']==want
    # ----------------------------------------
    # rの価格は比較窓に入らず、同Rawで初配送済みの過去足は参照できる。
    ids['60']['ohlc']={k:900000 for k in ('open','high','low','close')};assert core.measure_row(row,ids,starts)==measured
    ids['59']['stamp']={'time':3720,'index':60,'line':61};assert core.measure_row(row,ids,starts)==measured
    rejected=0
    for key in ('time','index','line'):
        r,b,s=copy.deepcopy(unchanged);b['59']['stamp'][key]=r['q0']['source_line' if key=='line' else key]+1
        must_reject(core.measure_row,r,b,s);rejected+=1
    for key in ('closed','price_known','missing'):
        r,b,s=copy.deepcopy(unchanged);b['59'][key]=key=='missing';must_reject(core.measure_row,r,b,s);rejected+=1
    for key in ('end','available_at'):
        r,b,s=copy.deepcopy(unchanged);b['59'][key]+=1;must_reject(core.measure_row,r,b,s);rejected+=1
    r,b,s=copy.deepcopy(unchanged);r['prior_ranges']['15']['from']+=60;must_reject(core.measure_row,r,b,s);rejected+=1
    for key in ('time','index','line'):
        r,b,s=copy.deepcopy(unchanged);b['60']['stamp'][key]+=1;must_reject(core.measure_row,r,b,s);rejected+=1
    r,b,s=copy.deepcopy(unchanged);b['59']['start']+=1;b['59']['end']+=1;b['59']['available_at']+=1
    must_reject(core.measure_row,r,b,s);rejected+=1
    r,b,s=copy.deepcopy(unchanged);b['59']=copy.deepcopy(b['59']);b['59']['ohlc']['close']+=.5
    must_reject(core.measure_row,r,b,s);rejected+=1
    r,b,s=copy.deepcopy(unchanged);r['prior_ranges']['15'].update(known=False,unknown_reasons=['欠分']);del s[45*60]
    r['prior_ranges']['30'].update(known=False,unknown_reasons=['欠分']);r['prior_ranges']['60'].update(known=False,unknown_reasons=['欠分'])
    unknown=core.measure_row(r,b,s);assert all(w['fit'] is None and not w['known'] for w in unknown['windows'].values())
    assert all(sha(ROOT/p)==h for p,h in before.items()) and stats=={str(p):[p.stat().st_size,p.stat().st_mtime_ns] for p in sources}
    result={'成功':True,'編集停止':True,'自然本文_金融_Raw_CSV_追加2場未読':True,'新売買条件又は閾値未採用':True,
        '独立数学':'numpy.linalg.lstsqの切片付き行列解。方向別なし。RMSE=sqrt(SSE/n)、R²定数null。',
        '人工価格列数':len(columns)*3,'数学比較数':comparisons,'最大絶対差':maxima,'既知窓の不正拒否数':rejected,
        '境界':['15/30/60実時間窓・r除外','r極値変更不変','最新までの配送因果time/index/line','同Raw既知過去足可',
                '未知窓はfit null、後足fallbackなし','入力非改変','不正終値拒否','平行移動/鏡像/直線/定数/末尾急変'],
        '上流の責任境界':['measure_rowは同場の正本id/start索引とprior_rangesの全metadata検査済みを受ける',
            'r初配送=q0とkey/bar.start/id一致は最終版で再検査。負stamp/known型等の入力schemaは固定153生成元の責任',
            '高R²は将来確率でない。窓knownと定数によるR² unknownは別状態'],
        '生成器静的確認':['入力物理/解凍SHAとgzip全CRC後に計算','全40544/適格35339と元known数一致',
            '未作成work出力へgzipだけ保存','元源と入力の前後SHA/stat確認','採否/方向/金融/ラベルの入力なし'],
        '源':before,'源前後SHA_stat同体':True,'独立確認コードSHA256':sha(Path(__file__))}
    target=HERE/'確認_最終.json'
    with target.open('x',encoding='utf-8') as output:json.dump(result,output,ensure_ascii=False,indent=2,allow_nan=False);output.write('\n')
    print(json.dumps({'成功':True,'数学比較数':comparisons,'人工列数':len(columns)*3,'確認SHA256':sha(target)},ensure_ascii=False))


if __name__=='__main__':
    main()
