"""回帰の意味と窓・未知・当時性を、小さな価格列で検査する。"""
import copy
import math
import unittest
from 回帰を測る import fit_closes, measure_row


def scene() -> tuple[dict, dict, dict]:
    """
    機能: rを含む61本の人工足と、r除外窓の参照を作る。
    引数: なし。返り値: tuple[dict,dict,dict]はq0行と2索引。
    """
    bars = []
    for i in range(61):
        price = 1000 + i
        bars.append({'id': str(i), 'start': i * 60, 'end': (i + 1) * 60,
            'available_at': (i + 2) * 60,
            'stamp': {'time': (i + 2) * 60, 'index': i, 'source_line': i + 1},
            'closed': True, 'price_known': True, 'missing': False,
            'ohlc': {'open': price, 'high': price, 'low': price, 'close': price}})
    bars[-1]['ohlc'] = {'open': 9999, 'high': 9999, 'low': 9999, 'close': 9999}
    row = {'event_id': '人工', 'eligible': True, 'r_ref': '60',
        'q0': {'time': 3720, 'index': 60, 'source_line': 61}, 'prior_ranges': {}}
    for width in (15, 30, 60):
        row['prior_ranges'][str(width)] = {'from': (60 - width) * 60, 'to': 3600,
            'known': True, 'unknown_reasons': [], 'high': 1059, 'low': 1060 - width}
    return row, {b['id']: b for b in bars}, {b['start']: b for b in bars}


class Tests(unittest.TestCase):
    def test_直線鏡像平行移動と定数(self) -> None:
        """
        機能: 直線・物理鏡像・価格水準移動・定数R²未定義を確認する。
        引数: self(Tests)。返り値: None。
        """
        for values, slope in [([100 + 2 * i for i in range(20)], 2), ([200 - 2 * i for i in range(20)], -2)]:
            result = fit_closes(values)
            self.assertEqual(result['slope_pt_per_minute'], slope)
            self.assertEqual(result['r_squared'], 1)
            self.assertEqual(result['residual_rmse'], 0)
            shifted = fit_closes([v + 10 ** 8 for v in values])
            self.assertEqual(shifted['slope_pt_per_minute'], slope)
            self.assertEqual(shifted['r_squared'], 1)
        flat = fit_closes([100] * 20)
        self.assertTrue(flat['constant'])
        self.assertEqual(flat['slope_pt_per_minute'], 0)
        self.assertIsNone(flat['r_squared'])

    def test_最後だけ急変と不正値(self) -> None:
        """
        機能: 教材の最後だけ急変した20点の解と、不正値拒否を確認する。
        引数: self(Tests)。返り値: None。
        """
        result = fit_closes([100] * 19 + [170])
        self.assertAlmostEqual(result['slope_pt_per_minute'], 1)
        self.assertAlmostEqual(result['r_squared'], 1 / 7)
        self.assertGreater(result['residual_rmse'], 0)
        for values in ([100], [100, None], [100, True], [100, math.nan], [100, math.inf], [100, 0]):
            with self.assertRaises(ValueError):
                fit_closes(values)

    def test_r除外と未知と後行(self) -> None:
        """
        機能: 当足極値を除外し、未知窓を補完せず、後行の参照を拒否する。
        引数: self(Tests)。返り値: None。
        """
        row, ids, starts = scene()
        before = copy.deepcopy((row, ids, starts))
        measured = measure_row(row, ids, starts)
        for width in (15, 30, 60):
            fitted = measured['windows'][str(width)]['fit']
            self.assertEqual(fitted['slope_pt_per_minute'], 1)
            self.assertEqual(fitted['r_squared'], 1)
            self.assertEqual(fitted['last_close'], 1059)
        self.assertEqual((row, ids, starts), before)
        row['prior_ranges']['15'].update(known=False, unknown_reasons=['欠分'])
        self.assertIsNone(measure_row(row, ids, starts)['windows']['15']['fit'])
        ids['59']['stamp']['source_line'] = 62
        with self.assertRaises(AssertionError):
            measure_row(row, ids, starts)


if __name__ == '__main__':
    unittest.main()
