"""既存の先行高安入力1点だけから回帰測定を追加し、売買や金融を選ばない。"""
from pathlib import Path
from collections import Counter
import argparse
import gzip
import hashlib
import json
from 回帰を測る import measure_row, WINDOWS

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
INPUT = ROOT / 'inputs/00153_先行高安の独立出生/先行高安の入力.json.gz'
INPUT_SHA = '2c020fed5b336ed0b417d8e72a07c6336ea475b09b9a2ff37f26ec4ce4d56bf8'
DECODED_SHA = '8e145275dda385e4c2f87500978716654d10efb0903a4011f2bcc304a7906b14'


def sha(path: Path) -> str:
    """
    機能: ファイルを小分けに物理指紋化する。
    引数: path(Path)。返り値: strはSHA256。
    """
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1048576), b''):
            digest.update(block)
    return digest.hexdigest()


# ----------------------------------------
def generate(source: dict) -> dict:
    """
    機能: 全場の全q0を保持し、既知先行終値だけから回帰を測定する。
    引数: source(dict)は指紋検証済みprior_time_range_v1入力。
    返り値: dictは測定値と件数。方向選択・ラベル・予測・金融は含まない。
    """
    assert source['success'] and source['schema'] == 'prior_time_range_v1'
    assert source['windows_minutes'] == list(WINDOWS) and len(source['sessions']) == 73
    scenes = []
    counts = Counter()
    windows = {str(w): Counter() for w in WINDOWS}
    for scene in source['scenes']:
        bars = scene['bars']
        ids = {b['id']: b for b in bars}
        starts = {b['start']: b for b in bars}
        assert len(ids) == len(starts) == len(bars)
        rows = []
        for row in scene['rows']:
            measured = measure_row(row, ids, starts)
            rows.append(measured)
            counts['all_q0'] += 1
            counts['eligible_q0'] += int(row['eligible'])
            for width, item in measured['windows'].items():
                wc = windows[width]
                wc['all_q0'] += 1
                wc['eligible_q0'] += int(row['eligible'])
                wc['known_all_q0'] += int(item['known'])
                wc['known_eligible_q0'] += int(item['known'] and row['eligible'])
                if item['known']:
                    wc['constant_all_q0'] += int(item['fit']['constant'])
                    wc['constant_eligible_q0'] += int(item['fit']['constant'] and row['eligible'])
        scenes.append({'session': scene['session'], 'contract': scene['contract'], 'rows': rows})
        print(json.dumps({'測定完了場': scene['session'], '累計q0': counts['all_q0']}, ensure_ascii=False), flush=True)
    assert [s['session'] for s in scenes] == source['sessions']
    assert counts['all_q0'] == 40544 and counts['eligible_q0'] == 35339
    for width, item in windows.items():
        for name in ('all_q0', 'eligible_q0', 'known_all_q0', 'known_eligible_q0'):
            assert item[name] == source['window_counts'][width][name], (width, name)
    return {'schema': 'prior_close_ols_v1', 'success': True, 'source': {
        'path': INPUT.relative_to(ROOT).as_posix(), 'sha256': INPUT_SHA, 'decoded_sha256': DECODED_SHA},
        'windows_minutes': list(WINDOWS), 'input_price': 'rを除く既知の連続1分確定終値',
        'OLS': '切片付き、x=0..W-1、傾き単位pt/分、R²はSxy²/(Sxx*Syy)',
        'residual_rmse': 'sqrt(SSE/W)、標本内記述であり自由度補正した残差標準偏差ではない',
        'constant': '窓はknown、slope=0、R²=null、他の標本内尺度は既知',
        'unknown_window': 'fit=null、欠分を詰めず過去の良い窓へ戻さない',
        'strategy_selected': False, 'financial_labels_used': False,
        'sessions': source['sessions'], 'scenes': scenes, 'counts': dict(counts),
        'window_counts': {k: dict(v) for k, v in windows.items()}}


# ----------------------------------------
def main() -> None:
    """
    機能: 純計算レビュー後の明示旗と準備票で、一度だけ測定入力を作る。
    引数: CLI prepare-sha256(str)、output-dir(Path)、execute-after-review(bool)。
    返り値: None。元入力・既存試行・売買条件・原板を変更しない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--prepare-sha256', required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--execute-after-review', action='store_true')
    args = parser.parse_args()
    assert args.execute_after_review, 'レビュー後の明示実行が必要'
    ready = HERE / '準備の確認.json'
    assert sha(ready) == args.prepare_sha256
    prepared = json.loads(ready.read_bytes())
    assert prepared['成功'] and prepared['自然測定は未実行']
    for name, expected in prepared['源'].items():
        assert sha(ROOT / name) == expected, name
    output = args.output_dir.resolve()
    assert output.is_relative_to(ROOT / 'work') and not output.exists()
    before = [INPUT.stat().st_size, INPUT.stat().st_mtime_ns]
    assert sha(INPUT) == INPUT_SHA
    with gzip.open(INPUT, 'rb') as stream:
        body = stream.read()
    assert hashlib.sha256(body).hexdigest() == DECODED_SHA
    source = json.loads(body)
    del body
    result = generate(source)
    output.mkdir(parents=True)
    raw = (json.dumps(result, ensure_ascii=False, separators=(',', ':'), allow_nan=False) + '\n').encode('utf-8')
    target = output / '先行回帰の入力.json.gz'
    with target.open('xb') as sink:
        with gzip.GzipFile(filename='', mode='wb', fileobj=sink, mtime=0, compresslevel=6) as compressed:
            compressed.write(raw)
    assert sha(INPUT) == INPUT_SHA and before == [INPUT.stat().st_size, INPUT.stat().st_mtime_ns]
    assert all(sha(ROOT / name) == expected for name, expected in prepared['源'].items())
    proof = {'成功': True, '売買条件又は金融の選択': False,
        '入力前後同体': True, '入力': result['source'], '準備SHA256': args.prepare_sha256,
        '出力': {'path': target.relative_to(ROOT).as_posix(), 'sha256': sha(target),
            'bytes': target.stat().st_size, 'decoded_sha256': hashlib.sha256(raw).hexdigest(), 'decoded_bytes': len(raw)},
        'counts': result['counts'], 'window_counts': result['window_counts']}
    with (output / '生成の確認.json').open('x', encoding='utf-8', newline='\n') as sink:
        json.dump(proof, sink, ensure_ascii=False, indent=2, allow_nan=False)
        sink.write('\n')
    print(json.dumps(proof, ensure_ascii=False))


if __name__ == '__main__':
    main()
