"""売買の採否と独立に、当時の先行確定終値へ切片付き回帰を当てる。"""
import math

WINDOWS = (15, 30, 60)


def fit_closes(closes: list[float]) -> dict:
    """
    機能: 等間隔終値の傾き・標本内説明度・残差を計算する。
    引数: closes(list[float])は古い順の正の有限終値、2点以上。
    返り値: dict。傾きはpt/1分、定数系列のR²は未定義のNone。
    """
    if len(closes) < 2 or any(type(v) not in (int, float) or not math.isfinite(v) or v <= 0 for v in closes):
        raise ValueError('2点以上の正の有限終値が必要')
    n = len(closes)
    # 差を先に取ることで、大きな価格水準による桁落ちを抑える。
    origin = closes[0]
    offsets = [v - origin for v in closes]
    mean_offset = math.fsum(offsets) / n
    mean_x = (n - 1) / 2
    sxx = n * (n * n - 1) / 12
    sxy = math.fsum((i - mean_x) * (v - mean_offset) for i, v in enumerate(offsets))
    syy = math.fsum((v - mean_offset) ** 2 for v in offsets)
    slope = sxy / sxx
    intercept_offset = mean_offset - slope * mean_x
    sse = math.fsum((v - (intercept_offset + slope * i)) ** 2 for i, v in enumerate(offsets))
    r2 = min(1.0, max(0.0, sxy * sxy / (sxx * syy))) if syy > 0 else None
    result = {'points': n, 'slope_pt_per_minute': slope,
        'r_squared': r2, 'constant': syy == 0,
        'mean_close': origin + mean_offset,
        'population_std_close': math.sqrt(syy / n),
        'residual_rmse': math.sqrt(sse / n),
        'fitted_first': origin + intercept_offset,
        'fitted_last': origin + intercept_offset + slope * (n - 1),
        'first_close': closes[0], 'last_close': closes[-1]}
    if any(v is not None and type(v) in (int, float) and not math.isfinite(v) for v in result.values()):
        raise ValueError('回帰計算の非有限値')
    return result


# ----------------------------------------
def measure_row(row: dict, bars_by_id: dict, bars_by_start: dict) -> dict:
    """
    機能: rを除外した完全な実時間窓だけを回帰測定し、未知を維持する。
    引数: row(dict)は153入力のq0行、bars_by_id/bars_by_start(dict)は同場の足。
    返り値: dict。各窓のknownは価格窓の既知性、R²未定義とは別。
    """
    r = bars_by_id[row['r_ref']]
    q = row['q0']
    assert r['id'] == row['r_ref'] and r['end'] == r['start'] + 60
    assert r['available_at'] == r['end'] + 60 <= q['time']
    stamp_r = r['stamp']
    assert (stamp_r['time'], stamp_r['index'], stamp_r.get('line', stamp_r.get('source_line'))) == (q['time'], q['index'], q['source_line'])
    out = {}
    for width in WINDOWS:
        prior = row['prior_ranges'][str(width)]
        start, end = r['start'] - width * 60, r['start']
        assert prior['from'] == start and prior['to'] == end
        item = {'from': start, 'to': end, 'known': prior['known'],
            'unknown_reasons': list(prior['unknown_reasons']), 'fit': None}
        if prior['known']:
            window = [bars_by_start[start + i * 60] for i in range(width)]
            for i, bar in enumerate(window):
                assert bar['start'] == start + i * 60 and bars_by_id[bar['id']] == bar
                assert bar['id'] != r['id'] and bar['closed'] and bar['price_known'] and not bar['missing']
                assert bar['end'] == bar['start'] + 60 and bar['available_at'] == bar['end'] + 60
                stamp = bar['stamp']
                assert bar['available_at'] <= stamp['time'] <= q['time']
                assert stamp['index'] <= q['index'] and stamp.get('line', stamp.get('source_line')) <= q['source_line']
            assert max(b['ohlc']['high'] for b in window) == prior['high']
            assert min(b['ohlc']['low'] for b in window) == prior['low']
            item['first_ref'], item['last_ref'] = window[0]['id'], window[-1]['id']
            item['fit'] = fit_closes([bar['ohlc']['close'] for bar in window])
        out[str(width)] = item
    return {'event_id': row['event_id'], 'eligible': row['eligible'],
        'r_ref': row['r_ref'], 'windows': out}
